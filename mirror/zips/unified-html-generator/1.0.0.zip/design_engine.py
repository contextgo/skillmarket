#!/usr/bin/env python3
"""
UI Prototype Generator - L6 UI System + L7 Components + L8 Reference Pictures + L9 DSL Design
Merged from phase-dsl + phase-prototype.
Provides design system tokens, component HTML templates, DSL schema, and reference image access.
Usage: python design_engine.py <command> [args...] [--json]
"""

import json
import sys
import re
from pathlib import Path

BASE_DIR = Path(__file__).parent

# ═══════════════════════════════════════════════════════════════
# File Index System - Maps L6, L7, L8 references/ MD files
# ═══════════════════════════════════════════════════════════════

LAYER_DIRS = {
    "L7": "L7-DesignSystem/references",
    "L8": "L8-Components/references",
    "L9": "L9-Reference/examples",
    "L10": "L10-DSL/references",
}


def _build_file_index():
    """Scan all references/ directories and build file index"""
    index = {}
    for layer, rel_dir in LAYER_DIRS.items():
        dir_path = BASE_DIR / rel_dir
        if dir_path.exists():
            files = []
            for f in sorted(dir_path.glob("*.md")):
                files.append({
                    "name": f.name,
                    "path": str(f.relative_to(BASE_DIR)),
                    "size": f.stat().st_size,
                    "lines": sum(1 for _ in open(f, encoding='utf-8', errors='ignore'))
                })
            # Also scan subdirectories for images
            png_dirs = {}
            for subdir in dir_path.iterdir():
                if subdir.is_dir():
                    pngs = list(subdir.glob("*.png"))
                    if pngs:
                        png_dirs[subdir.name] = [p.name for p in pngs]
            index[layer] = {"files": files, "image_dirs": png_dirs}
    return index


FILE_INDEX = _build_file_index()

# ═══════════════════════════════════════════════════════════════
# L6 - Design Systems (Tokens)
# ═══════════════════════════════════════════════════════════════

DESIGN_SYSTEMS = {
    "ftdesign": {
        "name": "FTDesign",
        "description": "企业级设计系统，蓝色主调，专业可信",
        "primary": "#005DEB",
        "tokens": {
            "brand": {
                "primary": "#005DEB",
                "primary_hover": "#436fb6",
                "primary_active": "#134CBF",
                "primary_bg": "#EFF0FA",
                "primary_border": "#8aaaf0",
                "blue_scale": ["#EFF0FA", "#CFD8F5", "#8aaaf0", "#5a83e8", "#436fb6", "#005DEB", "#134CBF", "#1040A0", "#0C3280"]
            },
            "functional": {
                "success": "#00A870", "success_light": "#E8F8F2",
                "warning": "#FF9C00", "warning_light": "#FFF3E0",
                "error": "#E34D59", "error_light": "#FEF0F1",
                "info": "#0052D9", "info_light": "#EBF2FF"
            },
            "neutral": {
                "grey_0": "#FFFFFF", "grey_1": "#F3F4F6", "grey_2": "#EAEBEE",
                "grey_3": "#E6E8EC", "grey_4": "#C5C8CE", "grey_5": "#9EA3AE",
                "grey_6": "#6B7280", "grey_7": "#39485E", "grey_8": "#1B2D51", "grey_9": "#0F1829"
            },
            "text": {
                "primary": "#39485E", "secondary": "#6B7280",
                "tertiary": "#9EA3AE", "disabled": "#C5C8CE"
            },
            "shadow": {
                "sm": "0 1px 4px rgba(0,0,0,0.06)",
                "md": "0 4px 12px rgba(0,0,0,0.08)",
                "lg": "0 8px 24px rgba(0,0,0,0.10)"
            },
            "radius": {"sm": "4px", "md": "6px", "lg": "8px"},
            "font_size": {"xs": "12px", "sm": "13px", "md": "14px", "lg": "16px", "xl": "20px", "2xl": "24px"},
            "spacing": [4, 8, 12, 16, 20, 24, 32, 48],
            "sidebar": {
                "bg": "#FFFFFF", "border": "#E6E8EC", "text": "#39485E",
                "active_bg": "#EFF0FA", "active_text": "#005DEB", "active_bar": "2px solid #005DEB"
            }
        },
        "css_file": "assets/css/ftdesign-vars.css",
        "components_css": "assets/css/base-components.css"
    },
    "antdesign": {
        "name": "Ant Design",
        "description": "通用中后台组件库，蓝色主调",
        "primary": "#1890ff",
        "tokens": {
            "brand": {
                "primary": "#1890ff",
                "primary_hover": "#40a9ff",
                "primary_active": "#096dd9",
                "primary_bg": "#e6f7ff",
                "primary_border": "#91d5ff"
            },
            "functional": {
                "success": "#52c41a", "success_light": "#f6ffed",
                "warning": "#faad14", "warning_light": "#fffbe6",
                "error": "#ff4d4f", "error_light": "#fff2f0",
                "info": "#1890ff", "info_light": "#e6f7ff"
            },
            "neutral": {
                "grey_0": "#FFFFFF", "grey_1": "#FAFAFA", "grey_2": "#F5F5F5",
                "grey_3": "#F0F0F0", "grey_4": "#D9D9D9", "grey_5": "#BFBFBF",
                "grey_6": "#8C8C8C", "grey_7": "#595959", "grey_8": "#434343", "grey_9": "#262626"
            },
            "text": {
                "primary": "#262626", "secondary": "#8C8C8C",
                "tertiary": "#BFBFBF", "disabled": "#D9D9D9"
            },
            "shadow": {
                "sm": "0 2px 8px rgba(0,0,0,0.06)",
                "md": "0 6px 16px rgba(0,0,0,0.08)",
                "lg": "0 12px 24px rgba(0,0,0,0.12)"
            },
            "radius": {"sm": "2px", "md": "4px", "lg": "8px"},
            "font_size": {"xs": "12px", "sm": "14px", "md": "14px", "lg": "16px", "xl": "20px", "2xl": "24px"},
            "spacing": [4, 8, 12, 16, 24, 32, 48],
            "sidebar": {
                "bg": "#001529", "border": "#001529", "text": "rgba(255,255,255,0.65)",
                "active_bg": "#1890ff", "active_text": "#FFFFFF", "active_bar": "3px solid #1890ff"
            }
        },
        "css_file": "assets/css/antdesign-vars.css"
    },
    "zhaoshanghong": {
        "name": "招商红设计系统",
        "description": "金融政务色彩系统，红色主调",
        "primary": "#C8102E",
        "tokens": {
            "brand": {
                "primary": "#C8102E",
                "primary_hover": "#E63950",
                "primary_active": "#A00D24",
                "primary_bg": "#FFF1F3",
                "primary_border": "#F5A0AB"
            },
            "functional": {
                "success": "#00A870", "success_light": "#E8F8F2",
                "warning": "#FF9C00", "warning_light": "#FFF3E0",
                "error": "#E34D59", "error_light": "#FEF0F1",
                "info": "#0052D9", "info_light": "#EBF2FF"
            },
            "neutral": {
                "grey_0": "#FFFFFF", "grey_1": "#F5F6F8", "grey_2": "#ECEEF1",
                "grey_3": "#E4E7EB", "grey_4": "#C1C6CC", "grey_5": "#929AA2",
                "grey_6": "#636B73", "grey_7": "#374151", "grey_8": "#1F2937", "grey_9": "#111827"
            },
            "text": {
                "primary": "#374151", "secondary": "#636B73",
                "tertiary": "#929AA2", "disabled": "#C1C6CC"
            },
            "shadow": {
                "sm": "0 1px 3px rgba(0,0,0,0.05)",
                "md": "0 4px 12px rgba(0,0,0,0.08)",
                "lg": "0 8px 24px rgba(0,0,0,0.10)"
            },
            "radius": {"sm": "4px", "md": "6px", "lg": "8px"},
            "font_size": {"xs": "12px", "sm": "13px", "md": "14px", "lg": "16px", "xl": "20px", "2xl": "24px"},
            "spacing": [4, 8, 12, 16, 20, 24, 32, 48],
            "sidebar": {
                "bg": "#FFFFFF", "border": "#E4E7EB", "text": "#374151",
                "active_bg": "#FFF1F3", "active_text": "#C8102E", "active_bar": "2px solid #C8102E"
            }
        },
        "file": "L7-DesignSystem/references/design-system-zhaoshanghong.md"
    }
}

# ═══════════════════════════════════════════════════════════════
# L7+ - Component Auxiliary Documents Index
# ═══════════════════════════════════════════════════════════════

COMPONENT_AUX_DOCS = {
    "component_usage": {"name": "纯CSS组件使用参考", "tech_stack": "纯HTML+CSS+Font Awesome 6.4.0 CDN+FTdesign CSS变量", "principle": "零框架依赖，ft-前缀类名，完整交互状态(hover/focus/active/disabled)", "file": "L8-Components/references/component_usage.md"},
    "empty_state": {"name": "空状态HTML模板", "types": ["empty(数据为空)", "developing(开发中)", "notfound(未找到)", "error(网络错误)"], "icons": {"empty": "fa-solid fa-inbox", "developing": "fa-solid fa-screwdriver-wrench", "notfound": "fa-solid fa-file-circle-question", "error": "fa-solid fa-circle-exclamation"}, "file": "L8-Components/references/empty_state_best_practices.md"},
    "ant_component": {"name": "Ant Design组件参考(React技术栈)", "principle": "功能层100%Ant Design原生，视觉层FTdesign色彩覆盖(只改color/bg-color/border-color)", "key_components": ["Typography", "Button", "Table", "Form", "Modal", "Select", "DatePicker", "Upload"], "file": "L8-Components/references/ant-component.md"},
    "ftd_component": {"name": "FTDesign组件参考(色彩层)", "principle": "功能层Ant Design原生，视觉层FTDesign(Blue-6 #005DEB)", "button_sizes": {"small": "h:24px p:0 8px fs:14px", "middle": "h:32px p:0 16px fs:14px", "large": "h:40px p:0 16px fs:16px"}, "file": "L8-Components/references/ftd-component.md"},
    "ftdesign_library": {"name": "FTdesign组件库规范", "components": ["Button(4类型)", "Navigation", "Tabs", "Menu", "List", "Form", "Selector", "Chart", "Icon"], "button_types": {"primary": "主操作提交", "default": "次要操作", "text": "弱操作链接", "danger": "删除危险操作"}, "file": "L8-Components/references/ftdesign-component-library.md"},
    "icons_usage": {"name": "Font Awesome图标指南", "version": "6.4.0", "cdn": "https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css", "formats": {"solid": "fa-solid fa-*", "regular": "fa-regular fa-*", "brands": "fa-brands fa-*"}, "usage": ["按钮内联图标", "表格操作列", "导航菜单", "状态指示"], "file": "L7-DesignSystem/references/icons_usage.md"},
    "icons_mapping": {"name": "图标映射表", "icon_library": "Font Awesome 6.4.0", "mappings": {"dashboard": "fa-solid fa-chart-line", "user": "fa-solid fa-users", "role": "fa-solid fa-user-tag", "permission": "fa-solid fa-shield-halved", "settings": "fa-solid fa-gears"}, "file": "L7-DesignSystem/references/icons-mapping.md"},
    "layout_practices": {"name": "HTML/CSS布局规范", "patterns": ["固定侧边栏(fixed 240px)", "非侧边栏(居中容器)", "筛选+操作Flex对齐"], "key_rules": ["侧边栏position:fixed", "主内容区margin-left:240px", "禁止body设display:flex", "React根用Fragment"], "file": "L8-Components/references/layout_best_practices.md"},
    "component_tokens": {"name": "组件令牌映射表", "format": "[类别]::[组件]::[变体]", "categories": ["GEN", "NAV", "ENT", "DISP", "LAY", "FB"], "file": "L8-Components/references/component_tokens.md"},
    "component_readme": {"name": "前端开发参考知识库索引", "core_docs": ["component_tokens.md", "color_system.md", "layout_best_practices.md", "empty_state_best_practices.md", "icons_usage.md"], "assets": ["ftdesign-vars.css(:root CSS变量)", "base-components.css(30类组件CSS)"], "file": "L8-Components/references/README.md"}
}

# ═══════════════════════════════════════════════════════════════
# L7 - Component Token → HTML Mapping
# ═══════════════════════════════════════════════════════════════

COMPONENT_TOKENS = {
    "GEN::Button::primary": {
        "html": '<button class="ft-btn ft-btn-primary"><i class="fa-solid fa-{icon}"></i> {text}</button>',
        "classes": ["ft-btn", "ft-btn-primary"],
        "description": "主按钮"
    },
    "GEN::Button::default": {
        "html": '<button class="ft-btn ft-btn-default"><i class="fa-solid fa-{icon}"></i> {text}</button>',
        "classes": ["ft-btn", "ft-btn-default"],
        "description": "默认按钮"
    },
    "GEN::Button::danger": {
        "html": '<button class="ft-btn ft-btn-danger">{text}</button>',
        "classes": ["ft-btn", "ft-btn-danger"],
        "description": "危险按钮"
    },
    "GEN::Button::ghost": {
        "html": '<button class="ft-btn ft-btn-ghost">{text}</button>',
        "classes": ["ft-btn", "ft-btn-ghost"],
        "description": "幽灵按钮"
    },
    "GEN::Button::text": {
        "html": '<button class="ft-btn ft-btn-text">{text}</button>',
        "classes": ["ft-btn", "ft-btn-text"],
        "description": "文字按钮"
    },
    "GEN::Button::primary::sm": {
        "html": '<button class="ft-btn ft-btn-primary ft-btn-sm">{text}</button>',
        "classes": ["ft-btn", "ft-btn-primary", "ft-btn-sm"],
        "description": "小号主按钮(高24px)"
    },
    "GEN::Button::primary::lg": {
        "html": '<button class="ft-btn ft-btn-primary ft-btn-lg">{text}</button>',
        "classes": ["ft-btn", "ft-btn-primary", "ft-btn-lg"],
        "description": "大号主按钮(高38px)"
    },
    "GEN::Tag::success": {
        "html": '<span class="ft-tag ft-tag-success">{text}</span>',
        "classes": ["ft-tag", "ft-tag-success"],
        "description": "成功标签"
    },
    "GEN::Tag::warning": {
        "html": '<span class="ft-tag ft-tag-warning">{text}</span>',
        "classes": ["ft-tag", "ft-tag-warning"],
        "description": "警告标签"
    },
    "GEN::Tag::error": {
        "html": '<span class="ft-tag ft-tag-error">{text}</span>',
        "classes": ["ft-tag", "ft-tag-error"],
        "description": "错误标签"
    },
    "GEN::Tag::info": {
        "html": '<span class="ft-tag ft-tag-info">{text}</span>',
        "classes": ["ft-tag", "ft-tag-info"],
        "description": "信息标签"
    },
    "GEN::Tag::default": {
        "html": '<span class="ft-tag ft-tag-default">{text}</span>',
        "classes": ["ft-tag", "ft-tag-default"],
        "description": "默认标签"
    },
    "ENT::Input::default": {
        "html": '<input class="ft-input no-icon" type="text" placeholder="{placeholder}">',
        "classes": ["ft-input", "no-icon"],
        "description": "默认输入框"
    },
    "ENT::Input::search": {
        "html": '<div class="ft-input-wrapper"><i class="fa-solid fa-magnifying-glass ft-input-icon"></i><input class="ft-input" placeholder="{placeholder}"></div>',
        "classes": ["ft-input-wrapper", "ft-input"],
        "description": "搜索输入框"
    },
    "ENT::Input::error": {
        "html": '<input class="ft-input no-icon error" type="text" placeholder="{placeholder}">',
        "classes": ["ft-input", "no-icon", "error"],
        "description": "错误状态输入框"
    },
    "ENT::Input::disabled": {
        "html": '<input class="ft-input no-icon" type="text" disabled>',
        "classes": ["ft-input", "no-icon"],
        "description": "禁用输入框"
    },
    "ENT::Select::default": {
        "html": '<div class="ft-select"><select><option>{text}</option></select><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>',
        "classes": ["ft-select"],
        "description": "下拉选择框"
    },
    "ENT::DatePicker::default": {
        "html": '<input class="ft-input no-icon" type="date">',
        "classes": ["ft-input", "no-icon"],
        "description": "日期选择"
    },
    "ENT::DatePicker::range": {
        "html": '<div style="display:flex;align-items:center;gap:8px"><input class="ft-input no-icon" type="date"><span>~</span><input class="ft-input no-icon" type="date"></div>',
        "classes": ["ft-input"],
        "description": "日期范围选择"
    },
    "ENT::Form::default": {
        "html": '<form class="ft-form"><div class="ft-form-item"><label class="ft-label">{label}</label><div class="ft-form-control">{content}</div></div></form>',
        "classes": ["ft-form", "ft-form-item", "ft-label"],
        "description": "表单"
    },
    "ENT::Form::required": {
        "html": '<label class="ft-label ft-label-required">{label}</label>',
        "classes": ["ft-label", "ft-label-required"],
        "description": "必填标签"
    },
    "ENT::Switch::on": {
        "html": '<label class="ft-switch"><div class="ft-switch-track on"><div class="ft-switch-thumb"></div></div><span class="ft-switch-label">{text}</span></label>',
        "classes": ["ft-switch", "ft-switch-track", "on"],
        "description": "开关（开）"
    },
    "ENT::Switch::off": {
        "html": '<label class="ft-switch"><div class="ft-switch-track"><div class="ft-switch-thumb"></div></div><span class="ft-switch-label">{text}</span></label>',
        "classes": ["ft-switch", "ft-switch-track"],
        "description": "开关（关）"
    },
    "DISP::Table::default": {
        "html": '<table class="ft-table"><thead><tr>{header_row}</tr></thead><tbody>{body_rows}</tbody></table>',
        "classes": ["ft-table"],
        "description": "基础表格"
    },
    "DISP::Table::selection": {
        "html": '<table class="ft-table"><thead><tr><th><input type="checkbox" class="ft-checkbox-all"></th>{header_row}</tr></thead><tbody>{body_rows}</tbody></table>',
        "classes": ["ft-table"],
        "description": "带复选框表格"
    },
    "DISP::Table::compact": {
        "html": '<table class="ft-table ft-table-compact">{table_content}</table>',
        "classes": ["ft-table", "ft-table-compact"],
        "description": "紧凑表格(行高32px)"
    },
    "DISP::Table::action-col": {
        "html": '<td class="ft-table-action"><button class="ft-btn ft-btn-text">编辑</button><span class="ft-divider-v"></span><button class="ft-btn ft-btn-text ft-text-danger">删除</button></td>',
        "classes": ["ft-table-action", "ft-btn-text", "ft-divider-v", "ft-text-danger"],
        "description": "操作列"
    },
    "DISP::Card::default": {
        "html": '<div class="page-content">{content}</div>',
        "classes": ["page-content"],
        "description": "内容卡片"
    },
    "DISP::Card::header": {
        "html": '<div class="page-header"><div class="page-breadcrumb">{breadcrumb}</div><h1 class="page-title">{title}</h1></div>',
        "classes": ["page-header", "page-breadcrumb", "page-title"],
        "description": "页头卡片"
    },
    "DISP::Card::stat": {
        "html": '<div class="stat-card"><div class="stat-icon"><i class="{icon}"></i></div><div class="stat-value">{value}</div><div class="stat-label">{label}</div></div>',
        "classes": ["stat-card", "stat-icon", "stat-value", "stat-label"],
        "description": "统计卡片(仪表盘)"
    },
    "DISP::Statistic::default": {
        "html": '<div class="ft-statistic"><div class="ft-statistic-title">{title}</div><div class="ft-statistic-value"><span class="ft-statistic-number">{value}</span><span class="ft-statistic-suffix">{suffix}</span></div></div>',
        "classes": ["ft-statistic"],
        "description": "统计数值"
    },
    "DISP::Progress::default": {
        "html": '<div class="ft-progress"><div class="ft-progress-track"><div class="ft-progress-bar" style="width:{percent}%"></div></div><span class="ft-progress-label">{percent}%</span></div>',
        "classes": ["ft-progress", "ft-progress-track", "ft-progress-bar"],
        "description": "进度条"
    },
    "DISP::Descriptions::2col": {
        "html": '<div class="ft-descriptions"><div class="ft-descriptions-body">{items}</div></div>',
        "classes": ["ft-descriptions"],
        "description": "描述列表(2列)"
    },
    "DISP::Timeline::default": {
        "html": '<ul class="ft-timeline"><li class="ft-timeline-item"><div class="ft-timeline-dot"></div><div class="ft-timeline-time">{time}</div><div class="ft-timeline-title">{title}</div><div class="ft-timeline-desc">{desc}</div></li></ul>',
        "classes": ["ft-timeline", "ft-timeline-item"],
        "description": "时间轴"
    },
    "DISP::Empty::default": {
        "html": '<div class="ft-empty"><i class="fa-solid fa-inbox ft-empty-icon"></i><p class="ft-empty-title">{title}</p><p class="ft-empty-desc">{desc}</p></div>',
        "classes": ["ft-empty", "ft-empty-icon"],
        "description": "空状态"
    },
    "DISP::Chart::bar": {
        "echarts_type": "bar",
        "config": "barMaxWidth:32, barBorderRadius:[4,4,0,0]",
        "description": "柱状图"
    },
    "DISP::Chart::line": {
        "echarts_type": "line",
        "config": "smooth:true, symbolSize:6",
        "description": "折线图"
    },
    "DISP::Chart::line-area": {
        "echarts_type": "line",
        "config": "smooth:true, areaStyle:{opacity:0.15}",
        "description": "面积折线图"
    },
    "DISP::Chart::pie": {
        "echarts_type": "pie",
        "config": "radius:['40%','65%']",
        "description": "环形饼图"
    },
    "NAV::Pagination::default": {
        "html": '<div class="ft-pagination"><span class="ft-page-info">共{total}条</span><button class="ft-page-btn">&laquo;</button><button class="ft-page-btn active">1</button><button class="ft-page-btn">&raquo;</button></div>',
        "classes": ["ft-pagination", "ft-page-btn"],
        "description": "分页器"
    },
    "NAV::Breadcrumb::default": {
        "html": '<div class="page-breadcrumb"><span>{items}</span></div>',
        "classes": ["page-breadcrumb"],
        "description": "面包屑导航"
    },
    "NAV::Menu::sidebar": {
        "html": '<aside class="ft-sidebar"><div class="sidebar-logo"><div class="logo-icon">D</div><span class="logo-text">{title}</span></div><nav class="sidebar-nav">{nav_items}</nav></aside>',
        "classes": ["ft-sidebar", "sidebar-logo", "sidebar-nav"],
        "description": "侧边栏导航"
    },
    "NAV::Menu::sidebar-item-active": {
        "html": '<div class="nav-item active"><i class="{icon}"></i><span>{text}</span></div>',
        "classes": ["nav-item", "active"],
        "description": "侧边栏激活菜单项"
    },
    "NAV::Menu::sidebar-item": {
        "html": '<div class="nav-item"><i class="{icon}"></i><span>{text}</span></div>',
        "classes": ["nav-item"],
        "description": "侧边栏菜单项"
    },
    "NAV::Tabs::default": {
        "html": '<div class="ft-tabs"><div class="ft-tabs-bar">{tabs}</div><div class="ft-tab-panel active">{content}</div></div>',
        "classes": ["ft-tabs", "ft-tabs-bar", "ft-tab", "active"],
        "description": "标签页"
    },
    "NAV::Steps::default": {
        "html": '<div class="ft-steps"><div class="ft-step done"><div class="ft-step-inner"><div class="ft-step-icon"><i class="fa-solid fa-check"></i></div><div class="ft-step-title">{title}</div></div></div></div>',
        "classes": ["ft-steps", "ft-step"],
        "description": "步骤条"
    },
    "LAY::Toolbar::default": {
        "html": '<div class="ft-toolbar"><div class="ft-filter-area">{filters}</div><div class="ft-action-area">{actions}</div></div>',
        "classes": ["ft-toolbar", "ft-filter-area", "ft-action-area"],
        "description": "工具栏"
    },
    "LAY::Grid::2col": {
        "html": '<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">{content}</div>',
        "css": "display:grid;grid-template-columns:1fr 1fr;gap:16px",
        "description": "2列网格"
    },
    "LAY::Grid::3col": {
        "html": '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px">{content}</div>',
        "css": "display:grid;grid-template-columns:repeat(3,1fr);gap:16px",
        "description": "3列网格"
    },
    "LAY::Grid::4col": {
        "html": '<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px">{content}</div>',
        "css": "display:grid;grid-template-columns:repeat(4,1fr);gap:16px",
        "description": "4列网格"
    },
    "FB::Modal::default": {
        "html": '<div class="ft-modal-overlay"><div class="ft-modal"><div class="ft-modal-header"><h3>{title}</h3><button class="ft-drawer-close"><i class="fa-solid fa-xmark"></i></button></div><div class="ft-modal-body">{content}</div><div class="ft-modal-footer"><button class="ft-btn ft-btn-default">取消</button><button class="ft-btn ft-btn-primary">确定</button></div></div></div>',
        "classes": ["ft-modal-overlay", "ft-modal"],
        "description": "对话框"
    },
    "FB::Drawer::default": {
        "html": '<div class="ft-drawer-overlay"><div class="ft-drawer"><div class="ft-drawer-header"><h3>{title}</h3><button class="ft-drawer-close"><i class="fa-solid fa-xmark"></i></button></div><div class="ft-drawer-body">{content}</div><div class="ft-drawer-footer"><button class="ft-btn ft-btn-default">取消</button><button class="ft-btn ft-btn-primary">确定</button></div></div></div>',
        "classes": ["ft-drawer-overlay", "ft-drawer"],
        "description": "抽屉(480px)"
    },
    "FB::Alert::success": {
        "html": '<div class="ft-alert ft-alert-success"><i class="fa-solid fa-check-circle"></i><div class="ft-alert-content"><div class="ft-alert-title">{title}</div><div class="ft-alert-desc">{desc}</div></div></div>',
        "classes": ["ft-alert", "ft-alert-success"],
        "description": "成功提示"
    },
    "FB::Alert::warning": {
        "html": '<div class="ft-alert ft-alert-warning"><i class="fa-solid fa-circle-exclamation"></i><div class="ft-alert-content"><div class="ft-alert-title">{title}</div><div class="ft-alert-desc">{desc}</div></div></div>',
        "classes": ["ft-alert", "ft-alert-warning"],
        "description": "警告提示"
    },
    "FB::Alert::error": {
        "html": '<div class="ft-alert ft-alert-error"><i class="fa-solid fa-circle-xmark"></i><div class="ft-alert-content"><div class="ft-alert-title">{title}</div><div class="ft-alert-desc">{desc}</div></div></div>',
        "classes": ["ft-alert", "ft-alert-error"],
        "description": "错误提示"
    },
    "FB::Alert::info": {
        "html": '<div class="ft-alert ft-alert-info"><i class="fa-solid fa-circle-info"></i><div class="ft-alert-content"><div class="ft-alert-title">{title}</div><div class="ft-alert-desc">{desc}</div></div></div>',
        "classes": ["ft-alert", "ft-alert-info"],
        "description": "信息提示"
    },
    "FB::Loading::page": {
        "html": '<div class="ft-loading"><div class="ft-spinner"></div><span class="ft-loading-text">加载中...</span></div>',
        "classes": ["ft-loading", "ft-spinner"],
        "description": "页面加载"
    },
    "GEN::Avatar::text": {
        "html": '<div class="ft-avatar">{char}</div>',
        "classes": ["ft-avatar"],
        "description": "文字头像"
    },
    "GEN::Badge::count": {
        "html": '<span class="ft-badge"><i class="fa-solid fa-bell"></i><span class="ft-badge-count">{count}</span></span>',
        "classes": ["ft-badge", "ft-badge-count"],
        "description": "数字徽标"
    },
    "GEN::Icon::plus": {"html": '<i class="fa-solid fa-plus"></i>', "description": "加号图标"},
    "GEN::Icon::edit": {"html": '<i class="fa-solid fa-pen-to-square"></i>', "description": "编辑图标"},
    "GEN::Icon::delete": {"html": '<i class="fa-solid fa-trash-can"></i>', "description": "删除图标"},
    "GEN::Icon::search": {"html": '<i class="fa-solid fa-magnifying-glass"></i>', "description": "搜索图标"},
    "GEN::Icon::download": {"html": '<i class="fa-solid fa-download"></i>', "description": "下载图标"},
    "GEN::Icon::upload": {"html": '<i class="fa-solid fa-upload"></i>', "description": "上传图标"},
    "GEN::Icon::filter": {"html": '<i class="fa-solid fa-filter"></i>', "description": "筛选图标"},
    "GEN::Icon::refresh": {"html": '<i class="fa-solid fa-rotate"></i>', "description": "刷新图标"},
    "GEN::Icon::more": {"html": '<i class="fa-solid fa-ellipsis"></i>', "description": "更多图标"},
    "GEN::Icon::close": {"html": '<i class="fa-solid fa-xmark"></i>', "description": "关闭图标"},
    "GEN::Icon::check": {"html": '<i class="fa-solid fa-check"></i>', "description": "确认图标"},
    "GEN::Icon::arrow-down": {"html": '<i class="fa-solid fa-chevron-down"></i>', "description": "下箭头"},
    "GEN::Icon::arrow-left": {"html": '<i class="fa-solid fa-chevron-left"></i>', "description": "左箭头"},
    "GEN::Icon::arrow-right": {"html": '<i class="fa-solid fa-chevron-right"></i>', "description": "右箭头"},
    "GEN::Typography::title::h1": {"html": '<h1 class="page-title">{text}</h1>', "classes": ["page-title"], "description": "页面标题"},
    "GEN::Typography::title::h2": {"html": '<h2 class="section-title">{text}</h2>', "classes": ["section-title"], "description": "区块标题"},
    "GEN::Typography::title::h3": {"html": '<h3 class="block-title">{text}</h3>', "classes": ["block-title"], "description": "模块标题"},
    "GEN::Typography::text::secondary": {"html": '<span class="text-secondary">{text}</span>', "classes": ["text-secondary"], "description": "次要文字"},
    "GEN::Typography::text::danger": {"html": '<span class="text-danger">{text}</span>', "classes": ["text-danger"], "description": "错误文字"},
    "GEN::Typography::link": {"html": '<a class="ft-link" href="#">{text}</a>', "classes": ["ft-link"], "description": "链接"},
    # Navigation - Extended
    "NAV::Dropdown::default": {
        "html": '<div class="ft-dropdown"><button class="ft-btn ft-btn-default">{text} <i class="fa-solid fa-chevron-down" style="font-size:10px;margin-left:4px"></i></button><div class="ft-dropdown-menu">{menu_items}</div></div>',
        "classes": ["ft-dropdown", "ft-dropdown-menu"],
        "description": "下拉菜单"
    },
    "NAV::Dropdown::item": {
        "html": '<div class="ft-dropdown-item"><i class="{icon}"></i><span>{text}</span></div>',
        "classes": ["ft-dropdown-item"],
        "description": "下拉菜单项"
    },
    "NAV::Menu::horizontal": {
        "html": '<nav class="ft-menu-horizontal">{menu_items}</nav>',
        "classes": ["ft-menu-horizontal"],
        "description": "水平导航菜单"
    },
    "NAV::Menu::horizontal-item": {
        "html": '<a class="ft-menu-item{active}">{text}</a>',
        "classes": ["ft-menu-item", "active"],
        "description": "水平菜单项"
    },
    "NAV::Tabs::nav-item": {
        "html": '<div class="ft-tab{active}">{text}</div>',
        "classes": ["ft-tab", "active"],
        "description": "标签页项"
    },
    "NAV::Steps::item": {
        "html": '<div class="ft-step{status}"><div class="ft-step-icon">{icon}</div><div class="ft-step-title">{title}</div><div class="ft-step-desc">{desc}</div></div>',
        "classes": ["ft-step"],
        "description": "步骤条项(status: done/current/wait/error)"
    },
    # Feedback - Extended
    "FB::Tooltip::default": {
        "html": '<span class="ft-tooltip" title="{text}">{content}</span>',
        "classes": ["ft-tooltip"],
        "description": "文字提示"
    },
    "FB::Popover::default": {
        "html": '<div class="ft-popover"><div class="ft-popover-trigger">{trigger}</div><div class="ft-popover-content"><div class="ft-popover-title">{title}</div><div class="ft-popover-inner">{content}</div></div></div>',
        "classes": ["ft-popover", "ft-popover-content"],
        "description": "气泡卡片"
    },
    "FB::Collapse::default": {
        "html": '<div class="ft-collapse">{panels}</div>',
        "classes": ["ft-collapse"],
        "description": "折叠面板"
    },
    "FB::Collapse::panel": {
        "html": '<div class="ft-collapse-panel"><div class="ft-collapse-header"><i class="fa-solid fa-chevron-right ft-collapse-arrow"></i><span>{title}</span></div><div class="ft-collapse-body">{content}</div></div>',
        "classes": ["ft-collapse-panel", "ft-collapse-header", "ft-collapse-body"],
        "description": "折叠面板项"
    },
    "FB::Tag::closeable": {
        "html": '<span class="ft-tag ft-tag-default">{text} <i class="fa-solid fa-xmark ft-tag-close"></i></span>',
        "classes": ["ft-tag", "ft-tag-close"],
        "description": "可关闭标签"
    },
    "FB::Spin::default": {
        "html": '<div class="ft-spin"><div class="ft-spinner"></div></div>',
        "classes": ["ft-spin", "ft-spinner"],
        "description": "加载中"
    },
    "FB::Skeleton::default": {
        "html": '<div class="ft-skeleton"><div class="ft-skeleton-avatar"></div><div class="ft-skeleton-content"><div class="ft-skeleton-title"></div><div class="ft-skeleton-paragraph"></div></div></div>',
        "classes": ["ft-skeleton", "ft-skeleton-avatar", "ft-skeleton-content"],
        "description": "骨架屏"
    },
    # Display - Extended
    "DISP::Descriptions::item": {
        "html": '<div class="ft-descriptions-item"><span class="ft-descriptions-label">{label}</span><span class="ft-descriptions-value">{value}</span></div>',
        "classes": ["ft-descriptions-item", "ft-descriptions-label", "ft-descriptions-value"],
        "description": "描述列表项"
    },
    "DISP::Tree::default": {
        "html": '<div class="ft-tree"><div class="ft-tree-node"><div class="ft-tree-node-content"><i class="fa-solid fa-chevron-right ft-tree-arrow"></i><i class="fa-solid fa-folder ft-tree-icon"></i><span>{text}</span></div><div class="ft-tree-children">{children}</div></div></div>',
        "classes": ["ft-tree", "ft-tree-node", "ft-tree-node-content"],
        "description": "树形控件"
    },
    "DISP::Tree::leaf": {
        "html": '<div class="ft-tree-node"><div class="ft-tree-node-content ft-tree-leaf"><i class="fa-solid fa-file ft-tree-icon"></i><span>{text}</span></div></div>',
        "classes": ["ft-tree-leaf"],
        "description": "树形叶子节点"
    },
    "DISP::Card::simple": {
        "html": '<div class="ft-card"><div class="ft-card-head"><span class="ft-card-title">{title}</span></div><div class="ft-card-body">{content}</div></div>',
        "classes": ["ft-card", "ft-card-head", "ft-card-body", "ft-card-title"],
        "description": "简单卡片"
    },
    "DISP::Card::grid": {
        "html": '<div class="ft-card-grid">{cards}</div>',
        "classes": ["ft-card-grid"],
        "description": "卡片网格容器"
    },
    "DISP::Divider::default": {
        "html": '<div class="ft-divider"><span class="ft-divider-text">{text}</span></div>',
        "classes": ["ft-divider", "ft-divider-text"],
        "description": "分割线"
    },
    "DISP::Image::default": {
        "html": '<div class="ft-image"><img src="{src}" alt="{alt}"></div>',
        "classes": ["ft-image"],
        "description": "图片"
    },
    # Entry - Extended
    "ENT::Upload::default": {
        "html": '<div class="ft-upload"><button class="ft-btn ft-btn-default"><i class="fa-solid fa-upload"></i> 上传文件</button></div>',
        "classes": ["ft-upload"],
        "description": "文件上传"
    },
    "ENT::Upload::drag": {
        "html": '<div class="ft-upload-dragger"><i class="fa-solid fa-cloud-arrow-up ft-upload-icon"></i><p class="ft-upload-text">点击或拖拽文件到此区域上传</p><p class="ft-upload-hint">{hint}</p></div>',
        "classes": ["ft-upload-dragger", "ft-upload-icon", "ft-upload-text"],
        "description": "拖拽上传"
    },
    "ENT::InputNumber::default": {
        "html": '<div class="ft-input-number"><button class="ft-input-number-btn ft-input-number-minus"><i class="fa-solid fa-minus"></i></button><input class="ft-input no-icon ft-input-number-input" type="number" value="{value}"><button class="ft-input-number-btn ft-input-number-plus"><i class="fa-solid fa-plus"></i></button></div>',
        "classes": ["ft-input-number", "ft-input-number-btn"],
        "description": "数字输入框"
    },
    "ENT::Radio::default": {
        "html": '<label class="ft-radio"><span class="ft-radio-inner"></span><span class="ft-radio-text">{text}</span></label>',
        "classes": ["ft-radio", "ft-radio-inner", "ft-radio-text"],
        "description": "单选框"
    },
    "ENT::Checkbox::default": {
        "html": '<label class="ft-checkbox"><span class="ft-checkbox-inner"></span><span class="ft-checkbox-text">{text}</span></label>',
        "classes": ["ft-checkbox", "ft-checkbox-inner", "ft-checkbox-text"],
        "description": "复选框"
    },
    "ENT::RadioGroup::default": {
        "html": '<div class="ft-radio-group">{radio_items}</div>',
        "classes": ["ft-radio-group"],
        "description": "单选框组"
    },
    "ENT::CheckboxGroup::default": {
        "html": '<div class="ft-checkbox-group">{checkbox_items}</div>',
        "classes": ["ft-checkbox-group"],
        "description": "复选框组"
    },
    "ENT::TextArea::default": {
        "html": '<textarea class="ft-textarea" placeholder="{placeholder}" rows="{rows}"></textarea>',
        "classes": ["ft-textarea"],
        "description": "多行文本框"
    },
    "ENT::Cascader::default": {
        "html": '<div class="ft-cascader"><input class="ft-input" placeholder="{placeholder}" readonly><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>',
        "classes": ["ft-cascader"],
        "description": "级联选择"
    },
    "ENT::Rate::default": {
        "html": '<div class="ft-rate">{stars}</div>',
        "classes": ["ft-rate"],
        "description": "评分"
    },
    # Layout - Extended
    "LAY::Grid::auto-fill": {
        "html": '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px">{content}</div>',
        "css": "display:grid;grid-template-columns:repeat(auto-fill,minmax(280px,1fr));gap:16px",
        "description": "自适应网格"
    },
    "LAY::Grid::sidebar": {
        "html": '<div style="display:grid;grid-template-columns:240px 1fr;gap:24px"><div class="sidebar">{sidebar}</div><div class="main">{main}</div></div>',
        "css": "display:grid;grid-template-columns:240px 1fr;gap:24px",
        "description": "侧栏+主体布局"
    },
    "LAY::Flex::between": {
        "html": '<div style="display:flex;align-items:center;justify-content:space-between">{content}</div>',
        "css": "display:flex;align-items:center;justify-content:space-between",
        "description": "两端对齐flex"
    },
    "LAY::Flex::start": {
        "html": '<div style="display:flex;align-items:center;gap:{gap}px">{content}</div>',
        "css": "display:flex;align-items:center;gap",
        "description": "起始对齐flex"
    },
    "LAY::Space::default": {
        "html": '<div class="ft-space" style="gap:8px">{items}</div>',
        "css": "gap:8px",
        "description": "间距容器"
    },
    # Extended Entry Components
    "ENT::TreeSelect::default": {
        "html": '<div class="ft-treeselect"><input class="ft-input" placeholder="{placeholder}" readonly><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>',
        "classes": ["ft-treeselect", "ft-input", "ft-select-arrow"],
        "description": "树形选择器"
    },
    "ENT::TreeSelect::multiple": {
        "html": '<div class="ft-treeselect ft-treeselect-multiple"><div class="ft-treeselect-tags">{tags}</div><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>',
        "classes": ["ft-treeselect", "ft-treeselect-multiple"],
        "description": "多选树形选择器"
    },
    "ENT::Transfer::default": {
        "html": '<div class="ft-transfer"><div class="ft-transfer-list"><div class="ft-transfer-header">{sourceTitle}</div><div class="ft-transfer-body">{sourceItems}</div></div><div class="ft-transfer-btns"><button class="ft-btn ft-btn-default ft-btn-sm"><i class="fa-solid fa-chevron-right"></i></button><button class="ft-btn ft-btn-default ft-btn-sm"><i class="fa-solid fa-chevron-left"></i></button></div><div class="ft-transfer-list"><div class="ft-transfer-header">{targetTitle}</div><div class="ft-transfer-body">{targetItems}</div></div></div>',
        "classes": ["ft-transfer", "ft-transfer-list", "ft-transfer-btns"],
        "description": "穿梭框"
    },
    "ENT::ColorPicker::default": {
        "html": '<div class="ft-colorpicker"><div class="ft-colorpicker-trigger"><span class="ft-colorpicker-color" style="background:{color}"></span><span class="ft-colorpicker-value">{color}</span></div></div>',
        "classes": ["ft-colorpicker", "ft-colorpicker-trigger", "ft-colorpicker-color"],
        "description": "颜色选择器"
    },
}

# ECharts color palette (must pass to every chart)
FT_CHART_COLORS = ["#005DEB", "#00A870", "#FF9C00", "#E34D59", "#0052D9", "#7B61FF", "#14C9C9"]

# ═══════════════════════════════════════════════════════════════
# L4 - Module Structure (referenced by prototype generation)
# ═══════════════════════════════════════════════════════════════

MODULE_STRUCTURE = {
    "four_layers": [
        {"level": 1, "name": "页面底层", "pattern": ".{page-name}-page", "examples": [".list-page", ".form-page", ".dashboard-page"], "params": {"max_width": "1200px", "padding": "24px", "bg": "#F5F5F5"}},
        {"level": 2, "name": "父级容器", "pattern": ".{page-name}-container", "examples": [".list-container", ".form-container"]},
        {"level": 3, "name": "模块容器", "pattern": ".{module-name}-module", "examples": [".header-module", ".filter-module", ".list-module", ".pagination-module"]},
        {"level": 4, "name": "子容器", "pattern": ".{element-name}", "examples": [".list-item", ".title-container", ".action-container"]},
    ],
    "standard_modules": {
        "header_module": {
            "name": "头部模块 (.header-module)",
            "structure": [".header-module__title-container", ".header-module__title", ".header-module__subtitle", ".header-module__action-container", ".header-module__action-btn"],
            "params": {"height": "64px", "bg": "#FFFFFF", "padding": "16px", "gap": "16px", "border_bottom": "1px solid #F0F0F0"},
            "variants": ["--compact (48px)", "--transparent (无背景)"]
        },
        "filter_module": {
            "name": "筛选模块 (.filter-module)",
            "structure": [".filter-module__search-container", ".filter-module__select-container", ".filter-module__tag-container"],
            "components": ["搜索框", "下拉筛选器", "标签筛选", "日期范围"],
            "responsive": {"desktop": "水平排列 间距12px", "mobile": "垂直堆叠 间距8px"}
        },
        "list_module": {
            "name": "列表模块 (.list-module)",
            "structure": [".list-item", ".list-item__left-container", ".list-item__main-container", ".list-item__right-container"],
            "item_params": {"height": "72px(紧凑)/88px(标准)", "padding": "16px", "divider": "1px solid #F0F0F0", "hover": "background-color: #FAFAFA"},
            "variants": ["--compact", "--expanded", "--selected", "--disabled"]
        },
        "pagination_module": {
            "name": "分页模块 (.pagination-module)",
            "structure": [".pagination-module__prev-btn", ".pagination-module__page-numbers", ".pagination-module__next-btn", ".pagination-module__info"],
            "params": {"max_visible": "7个页码", "align": "居中或右对齐"}
        }
    },
    "file": "4-Module-designer/references/module-structure.md"
}

# ═══════════════════════════════════════════════════════════════
# L9 - DSL Design (merged from phase-dsl)
# ═══════════════════════════════════════════════════════════════

DSL_TYPE_MAPPINGS = {
    # === General Components ===
    "Button": {"variants": ["primary", "default", "dashed", "text", "link", "danger", "ghost"], "props": ["type", "size", "icon", "loading", "disabled", "block", "shape"], "defaults": {"type": "default", "size": "middle", "loading": False, "disabled": False}, "token_ref": "GEN::Button::{variant}"},
    "Input": {"variants": ["default", "search", "password", "textarea", "number"], "props": ["placeholder", "value", "disabled", "readonly", "prefix", "suffix", "allowClear", "maxLength"], "defaults": {"disabled": False}, "token_ref": "ENT::Input::{variant}"},
    "Select": {"variants": ["default", "multiple", "tags", "searchable"], "props": ["options[]", "placeholder", "mode", "disabled", "allowClear", "showSearch"], "defaults": {"mode": "single", "disabled": False}, "token_ref": "ENT::Select::default"},
    "DatePicker": {"variants": ["default", "range", "month", "year"], "props": ["format", "placeholder", "disabled", "presets"], "defaults": {"format": "YYYY-MM-DD"}, "token_ref": "ENT::DatePicker::{variant}"},
    "TimePicker": {"props": ["format", "placeholder", "disabled"], "defaults": {"format": "HH:mm"}},
    "Switch": {"props": ["checked", "disabled", "size"], "defaults": {"checked": False, "size": "default"}, "token_ref": "ENT::Switch::{on|off}"},
    "Radio": {"props": ["options[]", "value", "disabled", "direction"], "defaults": {"direction": "horizontal"}, "token_ref": "ENT::Radio::default"},
    "Checkbox": {"props": ["options[]", "checked", "disabled", "indeterminate"], "defaults": {"checked": False}, "token_ref": "ENT::Checkbox::default"},
    "Upload": {"variants": ["default", "drag", "picture"], "props": ["action", "accept", "maxCount", "listType", "multiple"], "defaults": {"multiple": False, "maxCount": 5}, "token_ref": "ENT::Upload::{variant}"},
    "Rate": {"props": ["count", "value", "allowHalf", "allowClear"], "defaults": {"count": 5, "allowHalf": False}},
    "Slider": {"props": ["min", "max", "step", "range", "marks"], "defaults": {"min": 0, "max": 100, "step": 1}},
    "Cascader": {"props": ["options[]", "placeholder", "changeOnSelect", "multiple"], "defaults": {"changeOnSelect": False}, "token_ref": "ENT::Cascader::default"},
    "TreeSelect": {"props": ["treeData[]", "placeholder", "multiple", "treeCheckable"], "defaults": {"multiple": False}, "token_ref": "ENT::TreeSelect::default"},
    "Transfer": {"props": ["dataSource[]", "targetKeys[]", "selectedKeys[]", "render"], "defaults": {}, "token_ref": "ENT::Transfer::default"},
    "ColorPicker": {"props": ["value", "format", "presets"], "defaults": {"format": "hex"}, "token_ref": "ENT::ColorPicker::default"},
    # === Data Display ===
    "Table": {"variants": ["default", "bordered", "striped", "compact", "selection"], "props": ["columns[]", "dataSource[]", "pagination", "scroll", "size", "bordered", "rowSelection"], "defaults": {"size": "middle", "bordered": False, "pagination": {"pageSize": 20}}, "token_ref": "DISP::Table::{variant}"},
    "List": {"variants": ["default", "vertical", "grid"], "props": ["dataSource[]", "grid", "split", "loading"], "defaults": {"split": True, "loading": False}},
    "Card": {"variants": ["default", "simple", "meta", "stat", "bordered"], "props": ["title", "extra", "cover", "bordered", "hoverable", "loading"], "defaults": {"bordered": False, "hoverable": True}, "token_ref": "DISP::Card::{variant}"},
    "Tabs": {"variants": ["default", "card", "editable"], "props": ["items[]", "activeKey", "type", "tabPosition", "size"], "defaults": {"type": "line", "tabPosition": "top"}, "token_ref": "NAV::Tabs::{variant}"},
    "Descriptions": {"variants": ["default", "2col", "3col"], "props": ["items[]", "column", "bordered", "size"], "defaults": {"column": 2, "bordered": False, "size": "default"}, "token_ref": "DISP::Descriptions::{variant}"},
    "Timeline": {"variants": ["default", "alternate", "right"], "props": ["items[]", "mode", "pending"], "defaults": {"mode": "left"}, "token_ref": "DISP::Timeline::default"},
    "Tag": {"variants": ["default", "success", "warning", "error", "info", "closeable"], "props": ["color", "closable", "icon", "checked"], "defaults": {"closable": False}, "token_ref": "GEN::Tag::{variant}"},
    "Badge": {"variants": ["default", "dot", "count", "status"], "props": ["count", "status", "offset"], "defaults": {}, "token_ref": "GEN::Badge::{variant}"},
    "Avatar": {"variants": ["default", "text", "icon", "image", "group"], "props": ["size", "src", "icon"], "defaults": {"size": 40}, "token_ref": "GEN::Avatar::{variant}"},
    "Tooltip": {"props": ["title", "placement", "trigger"], "defaults": {"placement": "top", "trigger": "hover"}, "token_ref": "FB::Tooltip::default"},
    "Popover": {"props": ["title", "content", "trigger", "placement"], "defaults": {"trigger": "hover", "placement": "top"}, "token_ref": "FB::Popover::default"},
    "Collapse": {"props": ["items[]", "accordion", "bordered", "defaultActiveKey[]"], "defaults": {"accordion": False, "bordered": True}, "token_ref": "FB::Collapse::default"},
    "Empty": {"props": ["description", "image"], "defaults": {"description": "暂无数据"}, "token_ref": "DISP::Empty::default"},
    "Statistic": {"props": ["title", "value", "prefix", "suffix", "precision"], "defaults": {}, "token_ref": "DISP::Statistic::default"},
    "Progress": {"variants": ["default", "circle", "dashboard", "steps"], "props": ["percent", "status", "strokeColor", "format"], "defaults": {"status": "active"}, "token_ref": "DISP::Progress::{variant}"},
    "Tree": {"props": ["treeData[]", "checkable", "defaultExpandAll", "selectedKeys[]"], "defaults": {"checkable": False}, "token_ref": "DISP::Tree::default"},
    "Image": {"props": ["src", "alt", "preview", "width", "height", "fallback"], "defaults": {"preview": True}},
    "Divider": {"props": ["orientation", "dashed", "type"], "defaults": {"type": "horizontal"}, "token_ref": "DISP::Divider::default"},
    "Skeleton": {"props": ["avatar", "paragraph", "active", "loading"], "defaults": {"loading": True}, "token_ref": "FB::Skeleton::default"},
    "Spin": {"props": ["size", "tip", "spinning"], "defaults": {"spinning": True}, "token_ref": "FB::Spin::default"},
    # === Feedback Components ===
    "Alert": {"variants": ["success", "info", "warning", "error"], "props": ["message", "description", "closable", "showIcon"], "defaults": {"showIcon": True}, "token_ref": "FB::Alert::{variant}"},
    "Modal": {"variants": ["standard", "confirm", "info"], "props": ["title", "width", "footer", "closable", "maskClosable"], "defaults": {"width": 520}, "token_ref": "FB::Modal::default"},
    "Drawer": {"props": ["placement", "width", "title", "footer", "closable"], "defaults": {"placement": "right", "width": 480}, "token_ref": "FB::Drawer::default"},
    "Message": {"variants": ["success", "info", "warning", "error", "loading"], "props": ["content", "duration"], "defaults": {"duration": 3}},
    "Notification": {"props": ["type", "message", "description", "placement", "duration"], "defaults": {"placement": "topRight", "duration": 4.5}},
    "Result": {"variants": ["success", "error", "info", "warning", "404", "403", "500"], "props": ["title", "subTitle", "extra[]"], "defaults": {"status": "success"}},
    # === Navigation Components ===
    "Breadcrumb": {"props": ["items[]"], "token_ref": "NAV::Breadcrumb::default"},
    "Dropdown": {"props": ["items[]", "trigger", "placement"], "defaults": {"trigger": "hover"}, "token_ref": "NAV::Dropdown::default"},
    "Menu": {"variants": ["vertical", "horizontal", "inline"], "props": ["items[]", "mode", "theme", "selectedKeys[]"], "defaults": {"mode": "vertical", "theme": "light"}, "token_ref": "NAV::Menu::{variant}"},
    "Pagination": {"props": ["current", "total", "pageSize", "showQuickJumper", "showSizeChanger", "showTotal"], "defaults": {"current": 1, "pageSize": 20}, "token_ref": "NAV::Pagination::default"},
    "Steps": {"variants": ["default", "navigation", "arrow"], "props": ["items[]", "current", "direction", "status"], "defaults": {"direction": "horizontal", "status": "process"}, "token_ref": "NAV::Steps::default"},
    # === Layout Components ===
    "Space": {"props": ["size", "direction", "align"], "defaults": {"size": 8, "align": "center"}},
    "Flex": {"props": ["gap", "justify", "align", "wrap", "direction"], "defaults": {"gap": 16, "justify": "start"}},
    "Grid": {"variants": ["2col", "3col", "4col", "auto-fill"], "props": ["columns", "gutter", "gap"], "token_ref": "LAY::Grid::{variant}"},
    # === Special Components ===
    "Chart": {"variants": ["bar", "line", "line-area", "pie", "scatter", "radar"], "props": ["type", "data[]", "config", "color[]"], "defaults": {"color": FT_CHART_COLORS}, "token_ref": "DISP::Chart::{variant}"},
    "Form": {"variants": ["vertical", "horizontal", "inline"], "props": ["layout", "items[]", "labelCol", "wrapperCol"], "defaults": {"layout": "vertical"}, "token_ref": "ENT::Form::{variant}"},
}

DSL_VALIDATION_RULES = {
    "required_fields": {
        "metadata": ["project", "designSystem", "dslVersion"],
        "designTokens": ["colors.brand.primary", "typography.fontFamily", "spacing.unit"],
        "page": ["id", "name", "type"],
        "component": ["type"]
    },
    "format_rules": {
        "color": {"pattern": "^#[0-9A-Fa-f]{6}$", "message": "颜色值必须是有效的HEX格式"},
        "pageId": {"pattern": "^[a-z][a-z0-9-]*$", "message": "页面ID必须是kebab-case格式"},
        "spacing": {"pattern": "^\\d+px$", "message": "间距值必须包含px单位"},
        "dslVersion": {"pattern": "^\\d+\\.\\d+\\.\\d+$", "message": "版本号必须符合语义化版本规范"},
        "route": {"pattern": "^\\/.*", "message": "路由必须以/开头"}
    },
    "valid_page_types": ["list-page", "detail-page", "form-page", "dashboard-page", "config-page", "portal-page"],
    "file": "L10-DSL/references/validation-rules.md"
}

DSL_SCHEMA = {
    "version": "1.0.0",
    "title": "Phase Design DSL Schema",
    "$schema": "phase-design-dsl-v1.0.0",
    "root_keys": ["version", "metadata", "designTokens", "layout", "pages", "components"],
    "definitions": {
        "metadata": {"required": ["project", "designSystem", "dslVersion"], "properties": {"project": "string", "description": "string", "designSystem": "enum:[ftdesign,antd,custom]", "dslVersion": "string"}},
        "designTokens": {"required": ["colors", "typography", "spacing"], "properties": {"colors": {"brand": "{primary,hover,active,bg,border}", "functional": "{success,warning,error,info}", "neutral": "{grey-1~13}"}, "typography": "{fontFamily,fontSize,fontWeight,lineHeight}", "spacing": "{base,xs,sm,md,lg,xl}"}},
        "layout": {"properties": {"type": "enum:[sidebar-top,sidebar-only,top-only,fullwidth]", "header": "{height,fixed,background}", "sider": "{width,collapsedWidth,collapsible,background}", "content": "{padding,background,maxWidth}"}},
        "pages": {"type": "array", "item_properties": {"id": "string", "name": "string", "type": "enum:[dashboard,list,form,detail,result,portal,etc]", "layout": "string", "modules": "array", "components": "array"}},
        "components": {"type": "array", "item_properties": {"token": "string", "props": "object", "variants": "array"}}
    },
    "file": "L10-DSL/references/dsl-schema.json"
}


# ═══════════════════════════════════════════════════════════════
# Query Functions
# ═══════════════════════════════════════════════════════════════

def query_design_system(system_name):
    """Get design system tokens"""
    if system_name in DESIGN_SYSTEMS:
        return DESIGN_SYSTEMS[system_name]
    for key, sys in DESIGN_SYSTEMS.items():
        if system_name.lower() in key.lower():
            return sys
    return DESIGN_SYSTEMS["ftdesign"]


def generate_css_vars(system_name="ftdesign"):
    """Get CSS variables for a design system"""
    system = query_design_system(system_name)
    tokens = system["tokens"]
    lines = [":root {"]
    # Brand
    brand = tokens["brand"]
    lines.append(f"  --ft-primary: {brand['primary']};")
    if "primary_hover" in brand:
        lines.append(f"  --ft-primary-hover: {brand['primary_hover']};")
    if "primary_active" in brand:
        lines.append(f"  --ft-primary-active: {brand['primary_active']};")
    if "primary_bg" in brand:
        lines.append(f"  --ft-primary-bg: {brand['primary_bg']};")
    if "primary_border" in brand:
        lines.append(f"  --ft-primary-border: {brand['primary_border']};")
    # Functional
    func = tokens["functional"]
    lines.append(f"  --ft-success: {func['success']};")
    lines.append(f"  --ft-success-light: {func['success_light']};")
    lines.append(f"  --ft-warning: {func['warning']};")
    lines.append(f"  --ft-warning-light: {func['warning_light']};")
    lines.append(f"  --ft-error: {func['error']};")
    lines.append(f"  --ft-error-light: {func['error_light']};")
    lines.append(f"  --ft-info: {func['info']};")
    lines.append(f"  --ft-info-light: {func['info_light']};")
    # Neutral
    neutral = tokens.get("neutral", {})
    for k, v in neutral.items():
        var_name = k.replace("_", "-")
        lines.append(f"  --ft-{var_name}: {v};")
    # Text
    text = tokens.get("text", {})
    for k, v in text.items():
        var_name = k.replace("_", "-")
        lines.append(f"  --ft-text-{var_name}: {v};")
    # Shadow
    shadow = tokens.get("shadow", {})
    for k, v in shadow.items():
        lines.append(f"  --ft-shadow-{k}: {v};")
    # Radius
    radius = tokens.get("radius", {})
    for k, v in radius.items():
        lines.append(f"  --ft-radius-{k}: {v};")
    # Font size
    font = tokens.get("font_size", {})
    for k, v in font.items():
        lines.append(f"  --ft-font-{k}: {v};")
    # Spacing
    spacing = tokens.get("spacing", [])
    for i, v in enumerate(spacing):
        lines.append(f"  --ft-space-{i+1}: {v};")
    lines.append("}")
    return "\n".join(lines)


def query_component(token):
    """Get component HTML by token name"""
    if token in COMPONENT_TOKENS:
        return {"token": token, **COMPONENT_TOKENS[token]}
    # Fuzzy match
    token_upper = token.upper()
    for k, v in COMPONENT_TOKENS.items():
        if token_upper in k.upper() or k.upper() in token_upper:
            return {"token": k, **v}
    return None


def list_all_tokens():
    """List all available component tokens"""
    categories = {}
    for token, data in COMPONENT_TOKENS.items():
        cat = token.split("::")[0] if "::" in token else "GEN"
        if cat not in categories:
            categories[cat] = []
        categories[cat].append({"token": token, "description": data.get("description", "")})
    return categories


def get_component_aux():
    """Get component auxiliary documents index (L7)"""
    return COMPONENT_AUX_DOCS


def get_dsl_mapping(component_name):
    """Get DSL type mapping for a component"""
    if component_name in DSL_TYPE_MAPPINGS:
        return {"type": component_name, **DSL_TYPE_MAPPINGS[component_name]}
    # Fuzzy match
    name_lower = component_name.lower()
    for k, v in DSL_TYPE_MAPPINGS.items():
        if name_lower in k.lower() or k.lower() in name_lower:
            return {"type": k, **v}
    # List all available
    available = sorted(DSL_TYPE_MAPPINGS.keys())
    return {"error": f"Unknown component: {component_name}", "available_components": available, "total": len(available)}


def get_dsl_validation():
    """Get DSL validation rules"""
    return DSL_VALIDATION_RULES


def get_dsl_schema():
    """Get DSL schema structure"""
    return DSL_SCHEMA


def get_reference_images(page_type):
    """Get reference image paths for a page type"""
    ref_dir = BASE_DIR / "L9-Reference" / "examples"
    if not ref_dir.exists():
        return {"available": False, "message": "Reference images directory not found"}
    images = {}
    for subdir in ref_dir.iterdir():
        if subdir.is_dir():
            pngs = list(subdir.glob("*.png"))
            if pngs:
                images[subdir.name] = [p.name for p in pngs]
    return {"available": True, "categories": images}


def validate_design_rules(page_type, decisions):
    """Validate design decisions against rules - simplified version for prototype phase"""
    errors = []
    warnings = []
    suggestions = []

    # === Navigation Rules (7±2) ===
    nav_count = decisions.get("nav_items_count", 0)
    if nav_count > 9:
        errors.append(f"Navigation items ({nav_count}) exceed 7±2 rule limit (max 9)")
    elif nav_count > 7:
        warnings.append(f"Navigation items ({nav_count}) close to 7±2 limit, consider grouping")

    # === Design System Rules ===
    ds = decisions.get("design_system", "")
    if ds and ds not in DESIGN_SYSTEMS:
        warnings.append(f"Unknown design system: {ds}, fallback to ftdesign")

    # === Color Rules ===
    primary_color = decisions.get("primary_color", "")
    if primary_color and not re.match(r'^#[0-9A-Fa-f]{6}$', primary_color):
        errors.append(f"Invalid primary color format: {primary_color} (must be #RRGGBB)")

    # === Spacing Rules ===
    spacing = decisions.get("content_padding", "")
    if spacing and not re.match(r'^\d+px$', str(spacing)):
        errors.append(f"Invalid spacing format: {spacing} (must be Npx)")

    # === BEM Rules ===
    nesting_depth = decisions.get("max_nesting_depth", 0)
    if nesting_depth > 4:
        errors.append(f"CSS nesting depth ({nesting_depth}) exceeds 4-layer module structure limit")
    elif nesting_depth > 3:
        warnings.append(f"CSS nesting depth ({nesting_depth}) close to 4-layer limit")

    # === Component Rules ===
    uses_semantic_colors = decisions.get("uses_semantic_color_buttons", False)
    if uses_semantic_colors:
        errors.append("Buttons should not use semantic colors (success/error/warning) for selection state, use brand color instead")

    hardcoded_colors = decisions.get("has_hardcoded_colors", False)
    if hardcoded_colors:
        errors.append("Hardcoded color values detected, use CSS variables instead")

    uses_functional_icon_colors = decisions.get("uses_functional_icon_colors", False)
    if uses_functional_icon_colors:
        errors.append("Icons should not use functional colors, use --ft-text-secondary")

    # === Page-specific Rules ===
    if page_type == "dashboard":
        kpi_count = decisions.get("kpi_card_count", 0)
        if kpi_count > 0 and kpi_count < 3:
            warnings.append(f"Dashboard KPI cards ({kpi_count}) too few, recommended 4-8")
        elif kpi_count > 9:
            errors.append(f"Dashboard KPI cards ({kpi_count}) exceed 7±2 limit (max 9)")
        module_count = decisions.get("module_count", 0)
        if module_count > 9:
            errors.append(f"Dashboard modules ({module_count}) exceed 7±2 limit")
    elif page_type in ("list_table", "list"):
        has_filter = decisions.get("has_filter", False)
        has_pagination = decisions.get("has_pagination", False)
        if not has_filter:
            suggestions.append("List page should have filter area for search/sort")
        if not has_pagination:
            warnings.append("List page without pagination may cause performance issues")
    elif page_type == "form":
        field_count = decisions.get("field_count", 0)
        if field_count >= 15 and not decisions.get("has_tab_grouping"):
            suggestions.append(f"Form has {field_count} fields, consider tab grouping")
        elif field_count >= 7 and not decisions.get("has_field_grouping"):
            suggestions.append(f"Form has {field_count} fields, consider field grouping")
    elif page_type == "detail":
        has_tabs = decisions.get("has_tabs", False)
        if not has_tabs:
            suggestions.append("Detail page should have tabs for related information")

    # Score calculation
    score = 10 - len(errors) * 3 - len(warnings) * 1
    score = max(0, score)

    return {"errors": errors, "warnings": warnings, "suggestions": suggestions, "score": score}


# ═══════════════════════════════════════════════════════════════
# Reference File Read Functions
# ═══════════════════════════════════════════════════════════════

def read_ref(file_path):
    """Read a reference MD file by relative path. Returns file content."""
    file_path = file_path.replace("\\", "/")
    # Try direct path
    full_path = BASE_DIR / file_path
    if not full_path.exists():
        # Try with references/ prefix
        full_path = BASE_DIR / "references" / file_path
    if not full_path.exists():
        # Search across L6, L7, L8 layer directories
        for layer_dir in LAYER_DIRS.values():
            candidate = BASE_DIR / layer_dir / file_path
            if candidate.exists():
                full_path = candidate
                break
            # Try just filename
            name_only = Path(file_path).name
            candidate = BASE_DIR / layer_dir / name_only
            if candidate.exists():
                full_path = candidate
                break
    if not full_path.exists():
        return {"error": f"File not found: {file_path}", "available": False}
    try:
        content = full_path.read_text(encoding='utf-8')
        return {
            "path": str(full_path.relative_to(BASE_DIR)),
            "name": full_path.name,
            "size": len(content),
            "lines": content.count('\n') + 1,
            "content": content,
            "available": True
        }
    except Exception as e:
        return {"error": str(e), "available": False}


def list_refs(layer=None):
    """List all available reference files, optionally filtered by layer"""
    if layer:
        layer = layer.upper()
        if layer in FILE_INDEX:
            return {"layer": layer, **FILE_INDEX[layer]}
        # Try matching
        for k, v in FILE_INDEX.items():
            if layer in k:
                return {"layer": k, **v}
        return {"error": f"Unknown layer: {layer}. Use L6, L7, L8, or L9."}
    return FILE_INDEX


def search_refs(keyword):
    """Search for reference files by keyword (in filename or content)"""
    keyword = keyword.lower()
    results = []
    for layer, data in FILE_INDEX.items():
        for f in data.get("files", []):
            if keyword in f["name"].lower():
                results.append({"layer": layer, "file": f["name"], "path": f["path"], "match": "filename"})
                continue
            # Search content (first 2000 chars for speed)
            file_path = BASE_DIR / f["path"]
            if file_path.exists():
                try:
                    head = file_path.read_text(encoding='utf-8')[:3000].lower()
                    if keyword in head:
                        results.append({"layer": layer, "file": f["name"], "path": f["path"], "match": "content"})
                except Exception:
                    pass
    return results


# ═══════════════════════════════════════════════════════════════
# CLI Entry Point
# ═══════════════════════════════════════════════════════════════

def main():
    if len(sys.argv) < 2:
        print(json.dumps({
            "error": "Missing command",
            "usage": "python design_engine.py <command> [args]",
            "commands": [
                "get_design_system [name]",
                "get_css_vars [system_name]",
                "get_component <token>",
                "get_tokens [category_prefix]",
                "list_tokens",
                "get_component_aux",
                "get_ref_images [page_type]",
                "get_dsl_mapping <component_name>",
                "get_dsl_validation",
                "get_dsl_schema",
                "validate <page_type> <json_decisions>",
                "read_ref <file_path>",
                "list_refs [layer]",
                "search_refs <keyword>",
                "overview"
            ]
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    cmd = sys.argv[1]

    if cmd == "get_design_system":
        result = query_design_system(sys.argv[2] if len(sys.argv) > 2 else "ftdesign")
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "get_css_vars":
        result = generate_css_vars(sys.argv[2] if len(sys.argv) > 2 else "ftdesign")
        print(result)

    elif cmd == "get_component":
        result = query_component(sys.argv[2] if len(sys.argv) > 2 else "")
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "get_tokens":
        prefix = sys.argv[2] if len(sys.argv) > 2 else None
        all_tokens = list_all_tokens()
        if prefix:
            result = {k: v for k, v in all_tokens.items() if k.upper().startswith(prefix.upper())}
        else:
            result = all_tokens
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "list_tokens":
        result = list_all_tokens()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "get_component_aux":
        result = get_component_aux()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "get_ref_images":
        result = get_reference_images(sys.argv[2] if len(sys.argv) > 2 else "")
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "get_dsl_mapping":
        result = get_dsl_mapping(sys.argv[2] if len(sys.argv) > 2 else "")
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "get_dsl_validation":
        result = get_dsl_validation()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "get_dsl_schema":
        result = get_dsl_schema()
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "validate":
        page_type = sys.argv[2] if len(sys.argv) > 2 else ""
        decisions = json.loads(sys.argv[3]) if len(sys.argv) > 3 else {}
        result = validate_design_rules(page_type, decisions)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "read_ref":
        if len(sys.argv) < 3:
            print(json.dumps({"error": "Missing file path", "usage": "read_ref <file_path>"}))
        else:
            result = read_ref(" ".join(sys.argv[2:]))
            print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "list_refs":
        layer = sys.argv[2] if len(sys.argv) > 2 else None
        result = list_refs(layer)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "search_refs":
        keyword = sys.argv[2] if len(sys.argv) > 2 else ""
        result = search_refs(keyword)
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "overview":
        total_files = sum(len(d.get("files", [])) for d in FILE_INDEX.values())
        print(json.dumps({
            "name": "UI Prototype Generator (merged phase-dsl + phase-prototype)",
            "type": "L6 UI System + L7 Components + L8 Reference Pictures + L9 DSL Design",
            "available_commands": {
                "get_design_system": "Get design system tokens (FTDesign/AntDesign/Zhaoshanghong)",
                "get_css_vars": "Generate CSS variables string",
                "get_component": "Get component HTML by token",
                "list_tokens": "List all component tokens by category",
                "get_tokens": "Get component tokens by category prefix (GEN/DISP/ENT/NAV/LAY/FB)",
                "get_component_aux": "Get component auxiliary docs index (9 docs)",
                "get_ref_images": "Get reference image paths by page type",
                "get_dsl_mapping": "Get DSL type mapping for a component (60+ types)",
                "get_dsl_validation": "Get DSL validation rules",
                "get_dsl_schema": "Get DSL schema structure definition",
                "validate": "Validate design decisions against rules",
                "read_ref": "Read any reference MD file by path (L6/L7/L8/L9)",
                "list_refs": "List all reference files, optionally by layer (L6/L7/L8/L9)",
                "search_refs": "Search reference files by keyword",
            },
            "data_summary": {
                "design_systems": len(DESIGN_SYSTEMS),
                "component_tokens": len(COMPONENT_TOKENS),
                "dsl_type_mappings": len(DSL_TYPE_MAPPINGS),
                "component_aux_docs": len(COMPONENT_AUX_DOCS),
                "reference_files": total_files,
                "chart_colors": FT_CHART_COLORS,
            },
            "layers": {
                "L6": "UI Designer (FTDesign + AntDesign + Zhaoshanghong tokens)",
                "L7": "Component Designer (114 tokens + 9 auxiliary docs)",
                "L8": "Reference Pictures (directory scanning)",
                "L9": "DSL Design (60+ component mappings + validation + schema)",
            }
        }, ensure_ascii=False, indent=2))

    else:
        print(json.dumps({"error": f"Unknown command: {cmd}"}, ensure_ascii=False))


if __name__ == "__main__":
    main()
