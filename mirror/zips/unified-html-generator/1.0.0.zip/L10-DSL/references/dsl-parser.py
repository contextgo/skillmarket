#!/usr/bin/env python3
"""
DSL Parser - 解析 phase-design 输出的 DSL JSON，生成 HTML 原型
Usage: python dsl-parser.py <dsl-json-file> [--output <output.html>]
"""

import json
import sys
import re
from pathlib import Path
from datetime import datetime

# Add parent directory to path for importing design_engine
sys.path.insert(0, str(Path(__file__).parent.parent.parent))
from design_engine import COMPONENT_TOKENS, FT_CHART_COLORS, query_component


class DSLParser:
    """Parse DSL JSON and generate HTML prototype"""
    
    def __init__(self, dsl_data):
        self.dsl = dsl_data
        self.design_system = dsl_data.get('designSystem', {}).get('name', 'ftdesign')
        self.primary_color = dsl_data.get('designSystem', {}).get('primaryColor', '#005DEB')
        self.pages = dsl_data.get('pages', [])
        
    def parse_all_pages(self):
        """Parse all pages and generate HTML files"""
        results = []
        for page in self.pages:
            html = self.generate_page_html(page)
            results.append({
                'id': page['id'],
                'name': page['name'],
                'html': html
            })
        return results
    
    def generate_page_html(self, page):
        """Generate complete HTML for a single page"""
        page_type = page.get('type', 'list-page')
        page_name = page.get('name', '页面')
        components = page.get('components', [])
        
        # Build HTML structure
        html_parts = [
            self._generate_doctype(),
            self._generate_head(page_name),
            self._generate_body_start(),
            self._generate_sidebar(),
            self._generate_main_content(page, components),
            self._generate_body_end()
        ]
        
        return '\n'.join(html_parts)
    
    def _generate_doctype(self):
        return '<!DOCTYPE html>'
    
    def _generate_head(self, title):
        return f'''\n<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{title} - FTdesign</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
  <style>
{self._generate_css_variables()}
{self._generate_base_styles()}
  </style>
</head>'''
    
    def _generate_css_variables(self):
        """Generate CSS variables based on design system"""
        return f'''    /* ─── FTdesign CSS 变量 ─────────────────────────── */
    :root {{
      --ft-primary: {self.primary_color};
      --ft-primary-hover: #436fb6;
      --ft-primary-active: #134CBF;
      --ft-primary-bg: #EFF0FA;
      --ft-primary-border: #8aaaf0;
      --ft-success: #00A870; --ft-success-light: #E8F8F2;
      --ft-warning: #FF9C00; --ft-warning-light: #FFF3E0;
      --ft-error:   #E34D59; --ft-error-light:   #FEF0F1;
      --ft-info:    #0052D9; --ft-info-light:    #EBF2FF;
      --ft-grey-0: #FFFFFF; --ft-grey-1: #F3F4F6; --ft-grey-2: #EAEBEE;
      --ft-grey-3: #E6E8EC; --ft-grey-4: #C5C8CE; --ft-grey-5: #9EA3AE;
      --ft-grey-6: #6B7280; --ft-grey-7: #39485E; --ft-grey-8: #1B2D51;
      --ft-text-primary: #39485E; --ft-text-secondary: #6B7280;
      --ft-text-tertiary: #9EA3AE; --ft-text-disabled: #C5C8CE;
      --ft-border: #E6E8EC; --ft-border-hover: #8aaaf0;
      --ft-bg-page: #F3F4F6; --ft-bg-card: #FFFFFF;
      --ft-shadow-sm: 0 1px 4px rgba(0,0,0,0.06);
      --ft-shadow-md: 0 4px 12px rgba(0,0,0,0.08);
      --ft-radius-sm: 4px; --ft-radius-md: 6px; --ft-radius-lg: 8px;
      --ft-font-xs: 12px; --ft-font-sm: 13px; --ft-font-md: 14px;
      --ft-font-lg: 16px; --ft-font-xl: 20px;
    }}'''
    
    def _generate_base_styles(self):
        """Generate base component styles"""
        return '''    /* ─── 全局重置 ─────────────────────────────────── */
    *, *::before, *::after {{ box-sizing: border-box; margin: 0; padding: 0; }}
    body {{ font-family: -apple-system, BlinkMacSystemFont, 'PingFang SC', 'Helvetica Neue', sans-serif; background: var(--ft-bg-page); color: var(--ft-text-primary); }}
    button {{ font-family: inherit; cursor: pointer; }}
    input, select {{ font-family: inherit; }}

    /* ─── 侧边栏布局 ────────────────────────────────── */
    .ft-sidebar {{
      position: fixed; left: 0; top: 0; bottom: 0;
      width: 240px; background: var(--ft-grey-0);
      border-right: 1px solid var(--ft-grey-3);
      overflow-y: auto; z-index: 100;
    }}
    .sidebar-logo {{
      display: flex; align-items: center; gap: 10px;
      padding: 20px 16px; border-bottom: 1px solid var(--ft-grey-3);
    }}
    .logo-icon {{
      width: 32px; height: 32px; background: var(--ft-primary);
      border-radius: var(--ft-radius-md);
      display: flex; align-items: center; justify-content: center;
      color: #fff; font-size: 16px; flex-shrink: 0;
    }}
    .logo-text {{ font-size: var(--ft-font-lg); font-weight: 600; color: var(--ft-text-primary); }}
    .sidebar-nav {{ padding: 8px 0; }}
    .nav-section-title {{
      font-size: var(--ft-font-xs); color: var(--ft-text-tertiary);
      padding: 12px 16px 4px; text-transform: uppercase; letter-spacing: 0.05em;
    }}
    .nav-item {{
      display: flex; align-items: center; gap: 8px;
      padding: 10px 16px; margin: 2px 8px;
      border-radius: var(--ft-radius-sm);
      color: var(--ft-text-primary); font-size: var(--ft-font-md);
      cursor: pointer; transition: background 0.15s;
    }}
    .nav-item:hover {{ background: var(--ft-primary-bg); color: var(--ft-primary); }}
    .nav-item.active {{
      background: var(--ft-primary-bg); color: var(--ft-primary);
      border-left: 2px solid var(--ft-primary); padding-left: 14px;
    }}
    .nav-item i {{ font-size: 16px; flex-shrink: 0; }}

    /* ─── 主内容区 ──────────────────────────────────── */
    .ft-main {{ margin-left: 240px; min-height: 100vh; background: var(--ft-bg-page); padding: 24px; }}
    .page-header {{
      background: var(--ft-bg-card); border-radius: var(--ft-radius-lg);
      padding: 16px 20px; margin-bottom: 16px; box-shadow: var(--ft-shadow-sm);
    }}
    .page-breadcrumb {{
      display: flex; align-items: center; gap: 4px;
      font-size: var(--ft-font-xs); color: var(--ft-text-tertiary); margin-bottom: 6px;
    }}
    .page-breadcrumb span:last-child {{ color: var(--ft-text-secondary); }}
    .page-title {{ font-size: var(--ft-font-xl); font-weight: 600; color: var(--ft-text-primary); }}
    .page-content {{
      background: var(--ft-bg-card); border-radius: var(--ft-radius-lg);
      padding: 16px 20px; box-shadow: var(--ft-shadow-sm);
    }}

    /* ─── 按钮 ──────────────────────────────────────── */
    .ft-btn {{
      display: inline-flex; align-items: center; gap: 6px;
      padding: 0 14px; height: 32px; border-radius: var(--ft-radius-md);
      font-size: var(--ft-font-md); font-weight: 500;
      white-space: nowrap; transition: all 0.15s; border: none; outline: none;
    }}
    .ft-btn-primary {{ background: var(--ft-primary); color: #fff; border: 1px solid var(--ft-primary); }}
    .ft-btn-primary:hover {{ background: var(--ft-primary-hover); border-color: var(--ft-primary-hover); }}
    .ft-btn-default {{ background: #fff; color: var(--ft-text-primary); border: 1px solid var(--ft-border); }}
    .ft-btn-default:hover {{ border-color: var(--ft-primary); color: var(--ft-primary); }}
    .ft-btn-danger {{ background: var(--ft-error); color: #fff; border: 1px solid var(--ft-error); }}
    .ft-link-btn {{ background: none; border: none; color: var(--ft-primary); font-size: var(--ft-font-md); cursor: pointer; padding: 0 4px; }}
    .ft-link-btn:hover {{ text-decoration: underline; }}
    .ft-link-danger {{ color: var(--ft-error); }}

    /* ─── 输入框 / 下拉 ─────────────────────────────── */
    .ft-input-wrapper {{ position: relative; display: inline-flex; align-items: center; }}
    .ft-input-icon {{ position: absolute; left: 10px; color: var(--ft-text-tertiary); font-size: 14px; pointer-events: none; }}
    .ft-input {{
      height: 32px; padding: 0 10px 0 32px;
      border: 1px solid var(--ft-border); border-radius: var(--ft-radius-md);
      font-size: var(--ft-font-md); color: var(--ft-text-primary); outline: none; transition: border-color 0.15s;
    }}
    .ft-input:focus {{ border-color: var(--ft-primary-border); }}
    .ft-input::placeholder {{ color: var(--ft-text-tertiary); }}
    .ft-select {{ position: relative; display: inline-flex; align-items: center; }}
    .ft-select select {{
      height: 32px; padding: 0 32px 0 10px;
      border: 1px solid var(--ft-border); border-radius: var(--ft-radius-md);
      font-size: var(--ft-font-md); color: var(--ft-text-primary);
      background: #fff; appearance: none; outline: none; cursor: pointer;
    }}
    .ft-select select:focus {{ border-color: var(--ft-primary-border); }}
    .ft-select-arrow {{ position: absolute; right: 10px; color: var(--ft-text-tertiary); pointer-events: none; }}

    /* ─── 工具栏 ────────────────────────────────────── */
    .ft-toolbar {{
      display: flex; justify-content: space-between;
      align-items: flex-start; gap: 16px; flex-wrap: wrap; margin-bottom: 16px;
    }}
    .ft-filter-area, .ft-action-area {{ display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }}

    /* ─── 表格 ──────────────────────────────────────── */
    .ft-table {{ width: 100%; border-collapse: collapse; font-size: var(--ft-font-md); }}
    .ft-table th {{
      background: var(--ft-grey-1); color: var(--ft-text-secondary); font-weight: 500;
      padding: 10px 12px; text-align: left; border-bottom: 1px solid var(--ft-border); white-space: nowrap;
    }}
    .ft-table td {{ padding: 12px; color: var(--ft-text-primary); border-bottom: 1px solid var(--ft-grey-2); }}
    .ft-table tr:hover td {{ background: var(--ft-grey-1); }}
    .ft-table input[type="checkbox"] {{ cursor: pointer; }}

    /* ─── 状态标签 ──────────────────────────────────── */
    .ft-tag {{
      display: inline-flex; align-items: center;
      padding: 2px 8px; border-radius: var(--ft-radius-sm);
      font-size: var(--ft-font-xs); font-weight: 500; white-space: nowrap;
    }}
    .ft-tag-success {{ color: var(--ft-success); background: var(--ft-success-light); }}
    .ft-tag-warning {{ color: var(--ft-warning); background: var(--ft-warning-light); }}
    .ft-tag-error   {{ color: var(--ft-error);   background: var(--ft-error-light);   }}
    .ft-tag-info    {{ color: var(--ft-info);    background: var(--ft-info-light);    }}
    .ft-tag-default {{ color: var(--ft-text-secondary); background: var(--ft-grey-2); }}

    /* ─── 分页 ─────────────────────────────────────── */
    .ft-pagination {{ display: flex; align-items: center; gap: 4px; justify-content: flex-end; padding-top: 16px; }}
    .ft-page-info {{ font-size: var(--ft-font-sm); color: var(--ft-text-secondary); margin-right: 8px; }}
    .ft-page-btn {{
      width: 32px; height: 32px;
      display: inline-flex; align-items: center; justify-content: center;
      border: 1px solid var(--ft-border); border-radius: var(--ft-radius-sm);
      background: #fff; font-size: var(--ft-font-sm); color: var(--ft-text-primary); cursor: pointer;
    }}
    .ft-page-btn:hover {{ border-color: var(--ft-primary); color: var(--ft-primary); }}
    .ft-page-btn.active {{ background: var(--ft-primary); border-color: var(--ft-primary); color: #fff; }}'''
    
    def _generate_body_start(self):
        return '\n<body>'
    
    def _generate_body_end(self):
        return '\n</body>\n</html>'
    
    def _generate_sidebar(self):
        """Generate sidebar navigation"""
        return '''\n<!-- 侧边栏 -->
<aside class="ft-sidebar">
  <div class="sidebar-logo">
    <span class="logo-icon"><i class="fa-solid fa-layer-group"></i></span>
    <span class="logo-text">管理平台</span>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-item"><i class="fa-solid fa-chart-line"></i><span>仪表盘</span></div>
    <div class="nav-item active"><i class="fa-solid fa-users"></i><span>用户管理</span></div>
    <div class="nav-item"><i class="fa-solid fa-user-tag"></i><span>角色管理</span></div>
    <div class="nav-item"><i class="fa-solid fa-shield-halved"></i><span>权限管理</span></div>
    <div class="nav-item"><i class="fa-solid fa-gears"></i><span>系统设置</span></div>
  </nav>
</aside>'''
    
    def _generate_main_content(self, page, components):
        """Generate main content area based on page type"""
        page_type = page.get('type', 'list-page')
        page_name = page.get('name', '页面标题')
        
        html = f'''\n<!-- 主内容区 -->
<main class="ft-main">

  <!-- 页头 -->
  <div class="page-header">
    <div class="page-breadcrumb">
      <span>首页</span>
      <i class="fa-solid fa-chevron-right"></i>
      <span>{page_name}</span>
    </div>
    <h1 class="page-title">{page_name}</h1>
  </div>

  <!-- 内容卡片 -->
  <div class="page-content">'''
        
        # Add page-specific content based on type
        if page_type == 'list-page':
            html += self._generate_list_page_content(components)
        elif page_type == 'form-page':
            html += self._generate_form_page_content(components)
        elif page_type == 'detail-page':
            html += self._generate_detail_page_content(components)
        elif page_type == 'dashboard-page':
            html += self._generate_dashboard_page_content(components)
        else:
            html += self._generate_list_page_content(components)
        
        html += '''\n  </div>\n</main>'''
        return html
    
    def _generate_list_page_content(self, components):
        """Generate list page content with table"""
        return '''
    <!-- 工具栏：筛选区 + 操作区 -->
    <div class="ft-toolbar">
      <div class="ft-filter-area">
        <div class="ft-input-wrapper">
          <i class="fa-solid fa-magnifying-glass ft-input-icon"></i>
          <input class="ft-input" type="text" placeholder="搜索关键词" style="width:240px">
        </div>
        <div class="ft-select">
          <select><option>全部状态</option><option>启用</option><option>禁用</option></select>
          <i class="fa-solid fa-chevron-down ft-select-arrow"></i>
        </div>
      </div>
      <div class="ft-action-area">
        <button class="ft-btn ft-btn-primary"><i class="fa-solid fa-plus"></i> 新建</button>
        <button class="ft-btn ft-btn-default"><i class="fa-solid fa-download"></i> 导出</button>
      </div>
    </div>

    <!-- 数据表格 -->
    <table class="ft-table">
      <thead>
        <tr>
          <th style="width:40px"><input type="checkbox"></th>
          <th>名称</th>
          <th>状态</th>
          <th>创建时间</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td><input type="checkbox"></td>
          <td>示例数据 1</td>
          <td><span class="ft-tag ft-tag-success">已启用</span></td>
          <td>2026-01-15</td>
          <td>
            <button class="ft-link-btn">编辑</button>
            <button class="ft-link-btn ft-link-danger">删除</button>
          </td>
        </tr>
        <tr>
          <td><input type="checkbox"></td>
          <td>示例数据 2</td>
          <td><span class="ft-tag ft-tag-warning">待审核</span></td>
          <td>2026-01-20</td>
          <td>
            <button class="ft-link-btn">编辑</button>
            <button class="ft-link-btn ft-link-danger">删除</button>
          </td>
        </tr>
      </tbody>
    </table>

    <!-- 分页 -->
    <div class="ft-pagination">
      <span class="ft-page-info">共 50 条</span>
      <button class="ft-page-btn" disabled>«</button>
      <button class="ft-page-btn active">1</button>
      <button class="ft-page-btn">2</button>
      <button class="ft-page-btn">»</button>
    </div>'''
    
    def _generate_form_page_content(self, components):
        """Generate form page content"""
        return '''
    <!-- 表单 -->
    <form style="max-width: 600px;">
      <div style="margin-bottom: 16px;">
        <label style="display: block; margin-bottom: 6px; color: var(--ft-text-primary); font-size: var(--ft-font-md);">名称 <span style="color: var(--ft-error);">*</span></label>
        <input class="ft-input no-icon" type="text" placeholder="请输入名称" style="width: 100%; padding-left: 10px;">
      </div>
      <div style="margin-bottom: 16px;">
        <label style="display: block; margin-bottom: 6px; color: var(--ft-text-primary); font-size: var(--ft-font-md);">状态</label>
        <div class="ft-select" style="width: 100%;">
          <select style="width: 100%;"><option>启用</option><option>禁用</option></select>
          <i class="fa-solid fa-chevron-down ft-select-arrow"></i>
        </div>
      </div>
      <div style="margin-bottom: 16px;">
        <label style="display: block; margin-bottom: 6px; color: var(--ft-text-primary); font-size: var(--ft-font-md);">描述</label>
        <textarea class="ft-input no-icon" rows="4" placeholder="请输入描述" style="width: 100%; padding: 10px; height: auto; resize: vertical;"></textarea>
      </div>
      <div style="display: flex; gap: 8px; justify-content: flex-end;">
        <button type="button" class="ft-btn ft-btn-default">取消</button>
        <button type="submit" class="ft-btn ft-btn-primary">保存</button>
      </div>
    </form>'''
    
    def _generate_detail_page_content(self, components):
        """Generate detail page content"""
        return '''
    <!-- 详情信息 -->
    <div style="display: grid; grid-template-columns: 120px 1fr; gap: 16px 24px; margin-bottom: 24px;">
      <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-md);">名称</div>
      <div style="color: var(--ft-text-primary); font-size: var(--ft-font-md);">示例数据名称</div>
      
      <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-md);">状态</div>
      <div><span class="ft-tag ft-tag-success">已启用</span></div>
      
      <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-md);">创建时间</div>
      <div style="color: var(--ft-text-primary); font-size: var(--ft-font-md);">2026-01-15 10:30:00</div>
      
      <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-md);">描述</div>
      <div style="color: var(--ft-text-primary); font-size: var(--ft-font-md);">这是示例数据的详细描述信息。</div>
    </div>
    
    <div style="border-top: 1px solid var(--ft-border); padding-top: 16px; display: flex; gap: 8px; justify-content: flex-end;">
      <button class="ft-btn ft-btn-default"><i class="fa-solid fa-arrow-left"></i> 返回</button>
      <button class="ft-btn ft-btn-primary"><i class="fa-solid fa-pen-to-square"></i> 编辑</button>
    </div>'''
    
    def _generate_dashboard_page_content(self, components):
        """Generate dashboard page content with stats and charts placeholder"""
        return '''
    <!-- 统计卡片 -->
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 24px;">
      <div style="background: var(--ft-bg-card); padding: 20px; border-radius: var(--ft-radius-lg); box-shadow: var(--ft-shadow-sm);">
        <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-sm); margin-bottom: 8px;">总用户数</div>
        <div style="color: var(--ft-text-primary); font-size: 28px; font-weight: 600;">1,234</div>
        <div style="color: var(--ft-success); font-size: var(--ft-font-sm); margin-top: 4px;"><i class="fa-solid fa-arrow-up"></i> 12%</div>
      </div>
      <div style="background: var(--ft-bg-card); padding: 20px; border-radius: var(--ft-radius-lg); box-shadow: var(--ft-shadow-sm);">
        <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-sm); margin-bottom: 8px;">今日访问</div>
        <div style="color: var(--ft-text-primary); font-size: 28px; font-weight: 600;">856</div>
        <div style="color: var(--ft-success); font-size: var(--ft-font-sm); margin-top: 4px;"><i class="fa-solid fa-arrow-up"></i> 8%</div>
      </div>
      <div style="background: var(--ft-bg-card); padding: 20px; border-radius: var(--ft-radius-lg); box-shadow: var(--ft-shadow-sm);">
        <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-sm); margin-bottom: 8px;">订单数</div>
        <div style="color: var(--ft-text-primary); font-size: 28px; font-weight: 600;">328</div>
        <div style="color: var(--ft-error); font-size: var(--ft-font-sm); margin-top: 4px;"><i class="fa-solid fa-arrow-down"></i> 3%</div>
      </div>
      <div style="background: var(--ft-bg-card); padding: 20px; border-radius: var(--ft-radius-lg); box-shadow: var(--ft-shadow-sm);">
        <div style="color: var(--ft-text-secondary); font-size: var(--ft-font-sm); margin-bottom: 8px;">转化率</div>
        <div style="color: var(--ft-text-primary); font-size: 28px; font-weight: 600;">24.5%</div>
        <div style="color: var(--ft-success); font-size: var(--ft-font-sm); margin-top: 4px;"><i class="fa-solid fa-arrow-up"></i> 2%</div>
      </div>
    </div>
    
    <!-- 图表区域 -->
    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 16px;">
      <div style="background: var(--ft-bg-card); padding: 20px; border-radius: var(--ft-radius-lg); box-shadow: var(--ft-shadow-sm); height: 300px; display: flex; align-items: center; justify-content: center; color: var(--ft-text-tertiary);">
        <i class="fa-solid fa-chart-line" style="font-size: 48px; margin-right: 16px;"></i>
        <span>趋势图表区域</span>
      </div>
      <div style="background: var(--ft-bg-card); padding: 20px; border-radius: var(--ft-radius-lg); box-shadow: var(--ft-shadow-sm); height: 300px; display: flex; align-items: center; justify-content: center; color: var(--ft-text-tertiary);">
        <i class="fa-solid fa-chart-pie" style="font-size: 48px; margin-right: 16px;"></i>
        <span>占比图表区域</span>
      </div>
    </div>'''


def main():
    if len(sys.argv) < 2:
        print("Usage: python dsl-parser.py <dsl-json-file> [--output <output.html>]")
        print("\nExample:")
        print("  python dsl-parser.py example.dsl.json")
        print("  python dsl-parser.py example.dsl.json --output final.html")
        sys.exit(1)
    
    dsl_file = sys.argv[1]
    output_file = None
    
    if '--output' in sys.argv:
        idx = sys.argv.index('--output')
        if idx + 1 < len(sys.argv):
            output_file = sys.argv[idx + 1]
    
    # Read DSL JSON
    try:
        with open(dsl_file, 'r', encoding='utf-8') as f:
            dsl_data = json.load(f)
    except FileNotFoundError:
        print(f"Error: File not found: {dsl_file}")
        sys.exit(1)
    except json.JSONDecodeError as e:
        print(f"Error: Invalid JSON: {e}")
        sys.exit(1)
    
    # Parse DSL
    parser = DSLParser(dsl_data)
    pages = parser.parse_all_pages()
    
    # Output results
    if output_file:
        # If multiple pages, use first one for single output
        # Or generate multiple files
        if len(pages) == 1:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write(pages[0]['html'])
            print(f"Generated: {output_file}")
        else:
            # Generate multiple files
            base_name = Path(output_file).stem
            ext = Path(output_file).suffix
            for page in pages:
                filename = f"{base_name}-{page['id']}{ext}"
                with open(filename, 'w', encoding='utf-8') as f:
                    f.write(page['html'])
                print(f"Generated: {filename}")
    else:
        # Print to stdout
        for page in pages:
            print(f"\n<!-- Page: {page['name']} (ID: {page['id']}) -->")
            print(page['html'])


if __name__ == "__main__":
    main()
