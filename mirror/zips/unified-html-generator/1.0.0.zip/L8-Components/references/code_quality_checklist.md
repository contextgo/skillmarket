# 代码质量检查清单

生成 HTML 后必须执行以下检查，确保代码质量和规范合规。

---

## 一、CSS 检查

### 1.1 语法检查
- [ ] 每个 CSS 声明都有分号结尾
- [ ] CSS 变量格式正确：`var(--ft-xxx)`，不是 `var(--ft-xxx` 或 `--ft-xxx`
- [ ] 选择器 `{}` 成对匹配，没有遗漏的右大括号
- [ ] 没有双冒号错误（如 `color:: #005DEB` 应为 `color: #005DEB`）
- [ ] 属性值完整，没有截断（如 `#FF` 应为 `#005DEB`）

### 1.2 规范检查
- [ ] 无硬编码颜色值，全部使用 CSS 变量
- [ ] 无硬编码间距值，优先使用 `var(--ft-space-*)`
- [ ] 类名统一使用 `ft-` 前缀
- [ ] 侧边栏样式符合 FTdesign 规范

---

## 二、HTML 检查

### 2.1 语法检查
- [ ] 所有属性值都在引号内
- [ ] 标签闭合正确，没有遗漏的结束标签
- [ ] HTML 结构完整（`<!DOCTYPE>`、`<html>`、`<head>`、`<body>`）
- [ ] 注释正确闭合（`<!-- -->`）

### 2.2 规范检查
- [ ] 图标使用 Font Awesome 6.4.0 类名 `fa-solid fa-*`
- [ ] 不使用 Remix Icon (`ri-*`)
- [ ] 不使用 Emoji 表情符号
- [ ] 按钮和输入框高度统一（默认 32px）

---

## 三、FTdesign 规范检查

### 3.1 侧边栏规范
- [ ] 侧边栏浅色风格（`background: var(--ft-grey-0)` / `#FFFFFF`）
- [ ] 右侧边框 1px（`border-right: 1px solid var(--ft-grey-3)`）
- [ ] 文字颜色 `#39485E`（`var(--ft-grey-7)`）
- [ ] 激活状态背景 `#EFF0FA`（`var(--ft-brand-color-bg)`）
- [ ] 激活状态左侧 2px 高亮火柴棍（`border-left: 2px solid #005DEB`）
- [ ] 侧边栏固定定位（`position: fixed; width: 240px`）

### 3.2 主内容区规范
- [ ] 主内容区使用 `margin-left: 240px` 偏移
- [ ] 禁止在根元素使用 `display: flex` 布局
- [ ] 页面背景色 `#F3F4F6`（`var(--ft-bg-page)`）

### 3.3 按钮规范
- [ ] 主按钮使用品牌色（`background: #005DEB`）
- [ ] 按钮选中状态使用品牌色，不用功能色（success/warning/error）
- [ ] 按钮高度统一 32px（默认）

### 3.4 内容卡片规范
- [ ] 内容卡片白色背景（`background: #FFFFFF`）
- [ ] 24px 外边距/内边距
- [ ] 2px 或 4px 圆角

### 3.5 图标规范
- [ ] 统一使用 Font Awesome 6.4.0 CDN
- [ ] 类名格式：`fa-solid fa-{icon-name}`
- [ ] 常用图标映射正确：
  - 仪表盘：`fa-chart-line`
  - 用户管理：`fa-users`
  - 角色管理：`fa-user-tag`
  - 权限管理：`fa-shield-halved`
  - 系统设置：`fa-gears`

---

## 四、JavaScript 检查

### 4.1 语法检查
- [ ] 变量声明使用 `var`（兼容旧浏览器）
- [ ] 语句末尾有分号
- [ ] 括号 `{}` `()` 成对匹配

### 4.2 ECharts 检查
- [ ] 使用多 CDN 源降级加载
- [ ] 实现 `waitForECharts` 轮询机制
- [ ] 图表初始化在回调函数内执行
- [ ] 使用 FT_CHART_COLORS 色板

---

## 五、可运行性检查

### 5.1 完整性检查
- [ ] HTML 文件可直接在浏览器打开
- [ ] CSS 样式完整，无 404 资源
- [ ] 图标正常显示（Font Awesome CDN 可访问）
- [ ] 图表正常显示（ECharts CDN 可访问）

### 5.2 响应式检查
- [ ] 窗口缩放时布局正常
- [ ] 侧边栏始终固定
- [ ] 主内容区自适应

---

## 六、修复优先级

| 级别 | 问题类型 | 修复要求 |
|------|----------|----------|
| P0 | 语法错误 | 必须修复 |
| P1 | 规范违规 | 必须修复 |
| P2 | 样式不一致 | 建议修复 |
| P3 | 优化建议 | 可选修复 |

---

## 七、常见错误速查

| 错误 | 正确 |
|------|------|
| `class="ri-dashboard-line"` | `class="fa-solid fa-chart-line"` |
| `color:: #005DEB` | `color: #005DEB` |
| `var(--ft-primary` | `var(--ft-primary)` |
| `<div class="ft-sidebar" style="background:#001529">` | `<div class="ft-sidebar" style="background:#FFFFFF">` |
| `body { display: flex }` | 删除 body flex 样式 |
