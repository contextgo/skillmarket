# 组件令牌 → HTML 映射表

## 令牌格式

```
[类别]::[组件]::[变体]
```

**技术栈**：纯 HTML + CSS（FTdesign 原生类名）+ Font Awesome 6.4.0，零框架依赖

设计方案中的「组件令牌汇总」表格提供此格式，AI 生成代码前**必须**查询本文件，按令牌确定对应 HTML 结构和 CSS 类名。

## 类别速查
| 前缀 | 类别 | 说明 |
|------|------|------|
| `GEN::` | General | 通用组件 |
| `NAV::` | Navigation | 导航组件 |
| `ENT::` | Entry | 数据录入 |
| `DISP::` | Display | 数据展示 |
| `LAY::` | Layout | 布局组件 |
| `FB::` | Feedback | 反馈组件 |

---

## GEN — 通用组件

### Button 按钮

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `GEN::Button::primary` | `<button class="ft-btn ft-btn-primary"><i class="fa-solid fa-xxx"></i> 文字</button>` | `ft-btn-primary` |
| `GEN::Button::default` | `<button class="ft-btn ft-btn-default"><i class="fa-solid fa-xxx"></i> 文字</button>` | `ft-btn-default` |
| `GEN::Button::danger` | `<button class="ft-btn ft-btn-danger">文字</button>` | `ft-btn-danger` |
| `GEN::Button::ghost` | `<button class="ft-btn ft-btn-ghost">文字</button>` | `ft-btn-ghost` |
| `GEN::Button::text` | `<button class="ft-btn ft-btn-text">文字</button>` | `ft-btn-text` |
| `GEN::Button::link` | `<button class="ft-link-btn">文字</button>` | `ft-link-btn` |
| `GEN::Button::link-danger` | `<button class="ft-link-btn ft-link-danger">删除</button>` | `ft-link-danger` |
| `GEN::Button::loading` | `<button class="ft-btn ft-btn-primary ft-btn-loading"><span class="ft-btn-spinner"></span> 提交中</button>` | `ft-btn-loading` `ft-btn-spinner` |
| `GEN::Button::primary::sm` | `<button class="ft-btn ft-btn-primary ft-btn-sm">小按钮</button>` | `ft-btn-sm`（高24px）|
| `GEN::Button::primary::lg` | `<button class="ft-btn ft-btn-primary ft-btn-lg">大按钮</button>` | `ft-btn-lg`（高40px）|
| `GEN::Button::group` | `<div class="ft-btn-group"><button class="ft-btn ft-btn-default">A</button><button class="ft-btn ft-btn-default">B</button></div>` | `ft-btn-group` |

### Tag 状态标签

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `GEN::Tag::success` | `<span class="ft-tag ft-tag-success">已启用</span>` | `ft-tag-success` |
| `GEN::Tag::warning` | `<span class="ft-tag ft-tag-warning">待审核</span>` | `ft-tag-warning` |
| `GEN::Tag::error` | `<span class="ft-tag ft-tag-error">已禁用</span>` | `ft-tag-error` |
| `GEN::Tag::info` | `<span class="ft-tag ft-tag-info">进行中</span>` | `ft-tag-info` |
| `GEN::Tag::default` | `<span class="ft-tag ft-tag-default">草稿</span>` | `ft-tag-default` |

### Avatar 头像

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `GEN::Avatar::text` | `<div class="ft-avatar">张</div>` | `ft-avatar` |
| `GEN::Avatar::image` | `<div class="ft-avatar"><img src="..." alt="用户名"></div>` | `ft-avatar` |
| `GEN::Avatar::sm` | `<div class="ft-avatar ft-avatar-sm">A</div>` | `ft-avatar-sm` |
| `GEN::Avatar::lg` | `<div class="ft-avatar ft-avatar-lg">A</div>` | `ft-avatar-lg` |
| `GEN::Avatar::group` | `<div class="ft-avatar-group"><div class="ft-avatar">A</div><div class="ft-avatar">B</div></div>` | `ft-avatar-group` |

### Badge 徽标

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `GEN::Badge::count` | `<span class="ft-badge"><i class="fa-solid fa-bell"></i><span class="ft-badge-count">3</span></span>` | `ft-badge-count` |
| `GEN::Badge::dot` | `<span class="ft-badge"><i class="fa-solid fa-bell"></i><span class="ft-badge-dot"></span></span>` | `ft-badge-dot` |
| `GEN::Badge::status-success` | `<span class="ft-badge-status ft-badge-status-success"></span><span class="ft-badge-status-text">运行中</span>` | `ft-badge-status-success`（绿色圆点）|
| `GEN::Badge::status-warning` | `<span class="ft-badge-status ft-badge-status-warning"></span><span class="ft-badge-status-text">待处理</span>` | `ft-badge-status-warning`（橙色圆点）|
| `GEN::Badge::status-error` | `<span class="ft-badge-status ft-badge-status-error"></span><span class="ft-badge-status-text">已失败</span>` | `ft-badge-status-error`（红色圆点）|
| `GEN::Badge::status-default` | `<span class="ft-badge-status ft-badge-status-default"></span><span class="ft-badge-status-text">已停止</span>` | `ft-badge-status-default`（灰色圆点）|

### Divider 分割线

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `GEN::Divider::horizontal` | `<div class="ft-divider">可选文字</div>` | `ft-divider` |
| `GEN::Divider::vertical` | `<span class="ft-divider-v"></span>` | `ft-divider-v` |

### Icon 图标

| 令牌 | 对应 HTML | Font Awesome 类名 |
|------|-----------|----------------|
| `GEN::Icon::plus` | `<i class="fa-solid fa-plus"></i>` | `fa-solid fa-plus` |
| `GEN::Icon::edit` | `<i class="fa-solid fa-pen-to-square"></i>` | `fa-solid fa-pen-to-square` |
| `GEN::Icon::delete` | `<i class="fa-solid fa-trash-can"></i>` | `fa-solid fa-trash-can` |
| `GEN::Icon::search` | `<i class="fa-solid fa-magnifying-glass"></i>` | `fa-solid fa-magnifying-glass` |
| `GEN::Icon::download` | `<i class="fa-solid fa-download"></i>` | `fa-solid fa-download` |
| `GEN::Icon::upload` | `<i class="fa-solid fa-upload"></i>` | `fa-solid fa-upload` |
| `GEN::Icon::filter` | `<i class="fa-solid fa-filter"></i>` | `fa-solid fa-filter` |
| `GEN::Icon::refresh` | `<i class="fa-solid fa-rotate"></i>` | `fa-solid fa-rotate` |
| `GEN::Icon::more` | `<i class="fa-solid fa-ellipsis"></i>` | `fa-solid fa-ellipsis` |
| `GEN::Icon::arrow-down` | `<i class="fa-solid fa-chevron-down"></i>` | `fa-solid fa-chevron-down` |
| `GEN::Icon::arrow-up` | `<i class="fa-solid fa-chevron-up"></i>` | `fa-solid fa-chevron-up` |
| `GEN::Icon::arrow-left` | `<i class="fa-solid fa-chevron-left"></i>` | `fa-solid fa-chevron-left` |
| `GEN::Icon::arrow-right` | `<i class="fa-solid fa-chevron-right"></i>` | `fa-solid fa-chevron-right` |
| `GEN::Icon::close` | `<i class="fa-solid fa-xmark"></i>` | `fa-solid fa-xmark` |
| `GEN::Icon::check` | `<i class="fa-solid fa-check"></i>` | `fa-solid fa-check` |

### Typography 文本排版

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `GEN::Typography::title::h1` | `<h1 class="page-title">标题</h1>` | `page-title` |
| `GEN::Typography::title::h2` | `<h2 class="section-title">标题</h2>` | `section-title` |
| `GEN::Typography::title::h3` | `<h3 class="block-title">标题</h3>` | `block-title` |
| `GEN::Typography::text` | `<span>正文</span>` 或 `<p>正文</p>` | — |
| `GEN::Typography::text::secondary` | `<span class="text-secondary">次要</span>` | `text-secondary` |
| `GEN::Typography::text::danger` | `<span class="text-danger">错误</span>` | `text-danger` |
| `GEN::Typography::link` | `<a class="ft-link" href="#">链接</a>` | `ft-link` |

---

## NAV — 导航组件

### Pagination 分页器

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `NAV::Pagination::default` | `<div class="ft-pagination"><span class="ft-page-info">共N条</span><button class="ft-page-btn">«</button><button class="ft-page-btn active">1</button>...</div>` | `ft-pagination` `ft-page-btn` |

### Breadcrumb 面包屑

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `NAV::Breadcrumb::default` | `<div class="page-breadcrumb"><span>首页</span><i class="fa-solid fa-chevron-right"></i><span>当前页</span></div>` | `page-breadcrumb` |

### Menu 侧边栏导航

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `NAV::Menu::sidebar` | `<aside class="ft-sidebar"><div class="sidebar-logo">...</div><nav class="sidebar-nav"><div class="nav-item active">...</div></nav></aside>` | `ft-sidebar` `nav-item` |
| `NAV::Menu::sidebar-item` | `<div class="nav-item"><i class="fa-solid fa-xxx"></i><span>菜单名</span></div>` | `nav-item` |
| `NAV::Menu::sidebar-item-active` | `<div class="nav-item active">` | `nav-item active` |

### Tabs 标签页

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `NAV::Tabs::default` | `<div class="ft-tabs"><div class="ft-tabs-bar"><div class="ft-tab active">Tab1</div><div class="ft-tab">Tab2</div></div><div class="ft-tab-panel active">内容</div><div class="ft-tab-panel">内容2</div></div>` | `ft-tabs-bar` `ft-tab.active` `ft-tab-panel.active` |
| `NAV::Tabs::card` | `<div class="ft-tabs card">...` | `ft-tabs card` |
| `NAV::Tabs::with-badge` | `<div class="ft-tab">待处理<span class="ft-tab-badge">5</span></div>` | `ft-tab-badge` |

### Steps 步骤条

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `NAV::Steps::default` | `<div class="ft-steps"><div class="ft-step done"><div class="ft-step-inner"><div class="ft-step-icon"><i class="fa-solid fa-check"></i></div><div class="ft-step-title">步骤一</div></div></div><div class="ft-step active"><div class="ft-step-inner"><div class="ft-step-icon">2</div><div class="ft-step-title">步骤二</div></div></div></div>` | `ft-step.done` `ft-step.active` |
| `NAV::Steps::error` | `<div class="ft-step error">` | `ft-step.error` |

---

## ENT — 数据录入

### Input 输入框

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `ENT::Input::default` | `<input class="ft-input no-icon" type="text" placeholder="请输入">` | `ft-input no-icon` |
| `ENT::Input::search` | `<div class="ft-input-wrapper"><i class="fa-solid fa-magnifying-glass ft-input-icon"></i><input class="ft-input" placeholder="搜索..."></div>` | `ft-input-wrapper` `ft-input` |
| `ENT::Input::error` | `<input class="ft-input no-icon error" type="text">` | `ft-input error` |
| `ENT::Input::warning` | `<input class="ft-input no-icon warning" type="text">` | `ft-input warning` |
| `ENT::Input::disabled` | `<input class="ft-input no-icon" type="text" disabled>` | `disabled` 属性 |
| `ENT::Input::number` | `<input class="ft-input no-icon" type="number" placeholder="请输入数字">` | `type="number"` |
| `ENT::Input::password` | `<input class="ft-input no-icon" type="password" placeholder="请输入密码">` | `type="password"` |
| `ENT::Input::clear` | `<div class="ft-input-wrapper"><input class="ft-input" placeholder="请输入"><i class="fa-solid fa-circle-xmark ft-input-clear"></i></div>` | `ft-input-clear`（清除图标按钮）|

### Textarea 多行文本

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `ENT::Textarea::default` | `<textarea class="ft-textarea" rows="4" placeholder="请输入"></textarea>` | `ft-textarea` |

### Select 下拉选择

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `ENT::Select::default` | `<div class="ft-select"><select><option>选项</option></select><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>` | `ft-select` |
| `ENT::Select::multiple` | `<div class="ft-select ft-select-multiple"><select multiple>...</select></div>` | `ft-select-multiple` |
| `ENT::Select::search` | `<div class="ft-select"><input class="ft-input" placeholder="搜索选项..."><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>` | `ft-select`（内含搜索 input）|

### DatePicker 日期选择

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `ENT::DatePicker::default` | `<input class="ft-input no-icon" type="date">` | `type="date"` |
| `ENT::DatePicker::range` | `<div style="display:flex;align-items:center;gap:8px"><input class="ft-input no-icon" type="date"><span>~</span><input class="ft-input no-icon" type="date"></div>` | 两个 `ft-input` + 连字符 |
| `ENT::DatePicker::datetime` | `<input class="ft-input no-icon" type="datetime-local">` | `type="datetime-local"` |

### Upload 上传

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `ENT::Upload::button` | `<div class="ft-upload-btn"><input type="file" class="ft-upload-input" id="fileInput"><label for="fileInput" class="ft-btn ft-btn-default"><i class="fa-solid fa-upload"></i> 上传文件</label><span class="ft-upload-hint">支持 JPG/PNG，不超过 5MB</span></div>` | `ft-upload-btn` `ft-upload-input`（input隐藏，label触发）|
| `ENT::Upload::dragger` | `<div class="ft-upload-dragger" id="dropZone"><i class="fa-solid fa-cloud-arrow-up ft-upload-dragger-icon"></i><p class="ft-upload-dragger-title">点击或拖拽文件到此区域</p><p class="ft-upload-dragger-hint">支持单个或批量上传</p></div>` | `ft-upload-dragger`（拖入时加 `dragover` class）|
| `ENT::Upload::list` | `<ul class="ft-upload-list"><li class="ft-upload-item"><i class="fa-solid fa-file"></i><span class="ft-upload-name">文件名.pdf</span><span class="ft-upload-size">1.2MB</span><i class="fa-solid fa-xmark ft-upload-remove"></i></li><li class="ft-upload-item uploading"><span class="ft-upload-name">文件名.png</span><div class="ft-upload-progress-bar" style="width:60%"></div></li></ul>` | `ft-upload-list` `ft-upload-item`（上传中加 `uploading`）|
| `ENT::Upload::picture` | `<div class="ft-upload-picture-group"><div class="ft-upload-picture-item"><img src="..." alt="预览"><div class="ft-upload-picture-actions"><i class="fa-solid fa-eye"></i><i class="fa-solid fa-trash-can"></i></div></div><label for="pictureInput" class="ft-upload-picture-add"><i class="fa-solid fa-plus"></i><span>上传</span></label><input type="file" id="pictureInput" class="ft-upload-input" accept="image/*"></div>` | `ft-upload-picture-group` `ft-upload-picture-item` `ft-upload-picture-add` |

### 表单与选择控件

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `ENT::Form::default` | `<form class="ft-form"><div class="ft-form-item"><label class="ft-label">标签</label><div class="ft-form-control">...</div></div></form>` | `ft-form` `ft-form-item` `ft-label` |
| `ENT::Form::required` | `<label class="ft-label ft-label-required">标签</label>` | `ft-label-required`（前缀 `*`）|
| `ENT::Form::row` | `<div class="ft-form-row"><div class="ft-form-item">...</div><div class="ft-form-item">...</div></div>` | `ft-form-row`（2列）|
| `ENT::Checkbox::default` | `<label class="ft-checkbox"><input type="checkbox"><span class="ft-checkbox-box"></span><span>选项</span></label>` | `ft-checkbox` `ft-checkbox-box` |
| `ENT::Checkbox::group` | `<div class="ft-checkbox-group"><label class="ft-checkbox">...</label><label class="ft-checkbox">...</label></div>` | `ft-checkbox-group` |
| `ENT::Radio::group` | `<div class="ft-radio-group"><label class="ft-radio"><input type="radio" name="g" checked><span class="ft-radio-circle"></span><span>选项一</span></label><label class="ft-radio"><input type="radio" name="g"><span class="ft-radio-circle"></span><span>选项二</span></label></div>` | `ft-radio-group` `ft-radio` |
| `ENT::Switch::on` | `<label class="ft-switch"><div class="ft-switch-track on"><div class="ft-switch-thumb"></div></div><span class="ft-switch-label">已启用</span></label>` | `ft-switch-track on` |
| `ENT::Switch::off` | `<label class="ft-switch"><div class="ft-switch-track"><div class="ft-switch-thumb"></div></div><span class="ft-switch-label">已禁用</span></label>` | `ft-switch-track`（无 on）|
| `ENT::Slider::default` | `<input class="ft-slider" type="range" min="0" max="100" value="50">` | `ft-slider` |
| `ENT::TreeSelect::default` | `<div class="ft-treeselect"><input class="ft-input" placeholder="请选择" readonly><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>` | `ft-treeselect`（树形选择，点击展开树形面板） |
| `ENT::TreeSelect::multiple` | `<div class="ft-treeselect ft-treeselect-multiple"><div class="ft-treeselect-tags"><span class="ft-tag">选项1<i class="fa-solid fa-xmark ft-tag-close"></i></span></div><i class="fa-solid fa-chevron-down ft-select-arrow"></i></div>` | `ft-treeselect-multiple`（多选树形选择） |
| `ENT::Transfer::default` | `<div class="ft-transfer"><div class="ft-transfer-list"><div class="ft-transfer-header">源列表</div><div class="ft-transfer-body">...</div></div><div class="ft-transfer-btns"><button class="ft-btn ft-btn-default ft-btn-sm"><i class="fa-solid fa-chevron-right"></i></button></div><div class="ft-transfer-list"><div class="ft-transfer-header">目标列表</div><div class="ft-transfer-body">...</div></div></div>` | `ft-transfer`（穿梭框，含左右列表和操作按钮） |
| `ENT::ColorPicker::default` | `<div class="ft-colorpicker"><div class="ft-colorpicker-trigger"><span class="ft-colorpicker-color" style="background:#005DEB"></span><span class="ft-colorpicker-value">#005DEB</span></div></div>` | `ft-colorpicker`（颜色选择器） |

**注意**：TreeSelect、Transfer、ColorPicker 为复杂组件，上述为简化HTML结构，完整交互需配合JavaScript实现。

---

## DISP — 数据展示

### Table 表格

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `DISP::Table::default` | `<table class="ft-table"><thead><tr><th>列名</th></tr></thead><tbody>...</tbody></table>` | `ft-table`（无复选框）|
| `DISP::Table::selection` | `<table class="ft-table"><thead><tr><th><input type="checkbox" class="ft-checkbox-all"></th><th>列名</th></tr></thead><tbody><tr><td><input type="checkbox"></td>...</tr></tbody></table>` | `ft-table`（有复选框）|
| `DISP::Table::bordered` | `<table class="ft-table ft-table-bordered">...</table>` | `ft-table-bordered`（全边框）|
| `DISP::Table::compact` | `<table class="ft-table ft-table-compact">...</table>` | `ft-table-compact`（行高32px，适合密集数据）|
| `DISP::Table::striped` | `<table class="ft-table ft-table-striped">...</table>` | `ft-table-striped`（奇偶行背景交替）|
| `DISP::Table::sortable` | `<table class="ft-table"><thead><tr><th class="ft-th-sort"><span>列名</span><span class="ft-sort-icons"><i class="fa-solid fa-chevron-up"></i><i class="fa-solid fa-chevron-down"></i></span></th></tr></thead>...` | `ft-th-sort` `ft-sort-icons`（点击升降序）|
| `DISP::Table::filterable` | `<table class="ft-table"><thead><tr><th class="ft-th-filter"><span>列名</span><i class="fa-solid fa-filter ft-filter-icon active"></i></th></tr></thead>...` | `ft-th-filter` `ft-filter-icon`（激活时品牌色）|
| `DISP::Table::fixed-header` | `<div class="ft-table-wrapper" style="max-height:400px;overflow-y:auto"><table class="ft-table ft-table-fixed-header">...</table></div>` | `ft-table-wrapper` `ft-table-fixed-header`（固定表头滚动内容）|
| `DISP::Table::action-col` | `<td class="ft-table-action"><button class="ft-btn ft-btn-text">编辑</button><span class="ft-divider-v"></span><button class="ft-btn ft-btn-text ft-text-danger">删除</button></td>` | `ft-table-action`（操作列，文本按钮 + 竖分割线）|

### Card 卡片

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `DISP::Card::default` | `<div class="page-content">...</div>` | `page-content` |
| `DISP::Card::header` | `<div class="page-header"><div class="page-breadcrumb">...</div><h1 class="page-title">...</h1></div>` | `page-header` |
| `DISP::Card::stat` | `<div class="stat-card"><div class="stat-icon"><i class="fa-solid fa-xxx"></i></div><div class="stat-value">100</div><div class="stat-label">指标名</div></div>` | `stat-card`（仪表盘统计卡片）|

### Statistic 统计数值

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `DISP::Statistic::default` | `<div class="ft-statistic"><div class="ft-statistic-title">总用户数</div><div class="ft-statistic-value"><span class="ft-statistic-number">1,234</span><span class="ft-statistic-suffix">人</span></div></div>` | `ft-statistic` |
| `DISP::Statistic::trend-up` | `<div class="ft-statistic-trend up"><i class="fa-solid fa-arrow-up"></i>12.5%</div>` | `ft-statistic-trend up` |
| `DISP::Statistic::trend-down` | `<div class="ft-statistic-trend down"><i class="fa-solid fa-arrow-down"></i>3.2%</div>` | `ft-statistic-trend down` |

### Progress 进度条

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `DISP::Progress::default` | `<div class="ft-progress"><div class="ft-progress-track"><div class="ft-progress-bar" style="width:60%"></div></div><span class="ft-progress-label">60%</span></div>` | `ft-progress-track` `ft-progress-bar` |
| `DISP::Progress::success` | `<div class="ft-progress-bar success" style="width:100%">` | `ft-progress-bar success` |
| `DISP::Progress::warning` | `<div class="ft-progress-bar warning" style="width:75%">` | `ft-progress-bar warning` |

### Descriptions 描述列表

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `DISP::Descriptions::2col` | `<div class="ft-descriptions"><div class="ft-descriptions-body"><div class="ft-desc-item"><span class="ft-desc-label">字段：</span><span class="ft-desc-value">内容</span></div></div></div>` | `ft-descriptions` `ft-desc-item` |
| `DISP::Descriptions::3col` | `<div class="ft-descriptions col-3">...` | `ft-descriptions col-3` |
| `DISP::Descriptions::1col` | `<div class="ft-descriptions col-1">...` | `ft-descriptions col-1` |

### Timeline 时间轴

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `DISP::Timeline::default` | `<ul class="ft-timeline"><li class="ft-timeline-item"><div class="ft-timeline-dot"></div><div class="ft-timeline-time">2024-01-01</div><div class="ft-timeline-title">事件标题</div><div class="ft-timeline-desc">事件描述</div></li></ul>` | `ft-timeline` `ft-timeline-item` |
| `DISP::Timeline::success` | `<div class="ft-timeline-dot success">` | `ft-timeline-dot success` |
| `DISP::Timeline::error` | `<div class="ft-timeline-dot error">` | `ft-timeline-dot error` |

### Empty 空状态

| 令牌 | 对应 HTML | 图标 |
|------|-----------|------|
| `DISP::Empty::default` | `<div class="ft-empty"><i class="fa-solid fa-inbox ft-empty-icon"></i><p class="ft-empty-title">暂无数据</p><p class="ft-empty-desc">...</p></div>` | `fa-solid fa-inbox` |
| `DISP::Empty::developing` | 同上，图标换 `fa-solid fa-wrench ft-empty-icon--warning` | `fa-solid fa-wrench` |
| `DISP::Empty::notfound` | 同上，图标换 `fa-solid fa-magnifying-glass ft-empty-icon--error` | `fa-solid fa-magnifying-glass` |
| `DISP::Empty::error` | 同上，图标换 `fa-solid fa-circle-exclamation ft-empty-icon--error` | `fa-solid fa-circle-exclamation` |

### Chart 图表（ECharts CDN）

> CDN 地址（国内首选 BootCDN）：`https://cdn.bootcdn.net/ajax/libs/echarts/5.4.3/echarts.min.js`

| 令牌 | ECharts type | 关键配置 | 适用场景 |
|------|-------------|---------|---------|
| `DISP::Chart::bar` | `type:'bar'` | `barMaxWidth:32, barBorderRadius:[4,4,0,0]` | 对比/排行 |
| `DISP::Chart::line` | `type:'line'` | `smooth:true, symbolSize:6` | 趋势/时序 |
| `DISP::Chart::line-area` | `type:'line'` + `areaStyle:{opacity:0.15}` | 渐变填充 | 累计趋势 |
| `DISP::Chart::pie` | `type:'pie'` | `radius:['40%','65%']`（环形）| 占比分析 |
| `DISP::Chart::bar-stack` | `type:'bar'` + `stack:'total'` | 堆叠分组 | 多维对比 |
| `DISP::Chart::bar-h` | `type:'bar'`（横向，xAxis/yAxis 互换）| 横向排行 | 排行榜 |

**图表卡片 HTML 结构（三段式）**：

```html
<div class="content-card chart-card">
  <!-- ① 头部：标题 + 副标题 + 控制区 -->
  <div class="card-header">
    <div class="card-header-left">
      <span class="card-title">图表标题</span>
      <span class="card-subtitle">副标题说明（可选）</span>
    </div>
    <div class="card-header-right">
      <div class="chart-tab-group">
        <button class="chart-tab active">周</button>
        <button class="chart-tab">月</button>
      </div>
    </div>
  </div>
  <!-- ② 图表主体 + 示意标注 -->
  <div class="chart-body">
    <div id="chart-xxx" class="chart-container" style="height:220px"></div>
    <div class="chart-annotation">
      <span class="annotation-item"><i class="fa-solid fa-circle-info"></i> 数据说明：Mock / 近7日 / 按天聚合</span>
    </div>
  </div>
  <!-- ③ 底部摘要（可选）-->
  <div class="chart-footer">
    <div class="chart-stat"><span class="chart-stat-value">810</span><span class="chart-stat-label">本周总计</span></div>
    <div class="chart-stat"><span class="chart-stat-value trend-up">+12%</span><span class="chart-stat-label">环比上周</span></div>
  </div>
</div>
```

**FTdesign 色板（初始化每个图表时必须传入）**：

```javascript
const FT_CHART_COLORS = ['#005DEB','#00A870','#FF9C00','#E34D59','#0052D9','#7B61FF','#14C9C9'];
```

---

## LAY — 布局组件

### Layout 页面布局

| 令牌 | 对应 HTML | 关键 CSS |
|------|-----------|---------|
| `LAY::Sidebar::fixed` | `<aside class="ft-sidebar">` | `position:fixed; width:240px` |
| `LAY::Main::default` | `<main class="ft-main">` | `margin-left:240px` |

### Toolbar 工具栏

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `LAY::Toolbar::default` | `<div class="ft-toolbar"><div class="ft-filter-area">...</div><div class="ft-action-area">...</div></div>` | `ft-toolbar` |

### Grid 网格布局

| 令牌 | 对应 HTML | 关键 CSS |
|------|-----------|---------|
| `LAY::Grid::2col` | `<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px">` | inline style |
| `LAY::Grid::3col` | `<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px">` | inline style |
| `LAY::Grid::4col` | `<div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px">` | inline style |

### Space 间距

| 令牌 | 对应 HTML | 关键 CSS |
|------|-----------|---------|
| `LAY::Space::horizontal` | `<div style="display:flex;gap:8px;align-items:center">` | `display:flex; gap:8px; align-items:center` |
| `LAY::Space::vertical` | `<div style="display:flex;flex-direction:column;gap:8px">` | `display:flex; flex-direction:column; gap:8px` |

### Divider 布局分割线

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `LAY::Divider::horizontal` | `<div class="ft-divider"></div>` | `ft-divider` |
| `LAY::Divider::vertical` | `<span class="ft-divider-v"></span>` | `ft-divider-v` |

### Detail 详情布局（兼容旧令牌，建议迁移至 Descriptions）

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `LAY::Detail::label-value` | `<div class="detail-item"><span class="detail-label">标签：</span><span class="detail-value">内容</span></div>` | `detail-item` `detail-label` `detail-value` |
| `LAY::Detail::section` | `<div class="detail-section"><h3 class="section-title">分组标题</h3>...</div>` | `detail-section` `section-title` |

---

## FB — 反馈组件

### Modal 对话框

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `FB::Modal::default` | `<div class="ft-modal-overlay"><div class="ft-modal"><div class="ft-modal-header">标题<button class="modal-close">×</button></div><div class="ft-modal-body">内容</div><div class="ft-modal-footer">操作按钮</div></div></div>` | `ft-modal-overlay` `ft-modal` |
| `FB::Modal::confirm` | `<div class="ft-modal-overlay"><div class="ft-modal"><div class="ft-modal-header">确认操作</div><div class="ft-modal-body">确认信息</div><div class="ft-modal-footer"><button class="ft-btn ft-btn-default">取消</button><button class="ft-btn ft-btn-primary">确定</button></div></div></div>` | `ft-modal`（含确认/取消按钮）|
| `FB::Modal::sm` | `<div class="ft-modal ft-modal-sm">` | `ft-modal-sm`（480px）|
| `FB::Modal::lg` | `<div class="ft-modal ft-modal-lg">` | `ft-modal-lg`（800px）|

### Drawer 抽屉

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `FB::Drawer::default` | `<div class="ft-drawer-overlay"><div class="ft-drawer"><div class="ft-drawer-header">标题<button class="ft-drawer-close"><i class="fa-solid fa-xmark"></i></button></div><div class="ft-drawer-body">...</div><div class="ft-drawer-footer"><button class="ft-btn ft-btn-default">取消</button><button class="ft-btn ft-btn-primary">确定</button></div></div></div>` | `ft-drawer` `ft-drawer-header` `ft-drawer-body` `ft-drawer-footer` |
| `FB::Drawer::sm` | `<div class="ft-drawer ft-drawer-sm">` | `ft-drawer-sm`（360px）|
| `FB::Drawer::lg` | `<div class="ft-drawer ft-drawer-lg">` | `ft-drawer-lg`（600px）|

### Alert 警告提示

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `FB::Alert::success` | `<div class="ft-alert ft-alert-success"><i class="fa-solid fa-circle-check"></i><div class="ft-alert-content"><div class="ft-alert-title">成功标题</div><div class="ft-alert-desc">描述信息</div></div></div>` | `ft-alert ft-alert-success` |
| `FB::Alert::warning` | `<div class="ft-alert ft-alert-warning"><i class="fa-solid fa-circle-exclamation"></i>...` | `ft-alert ft-alert-warning` |
| `FB::Alert::error` | `<div class="ft-alert ft-alert-error"><i class="fa-solid fa-circle-xmark"></i>...` | `ft-alert ft-alert-error` |
| `FB::Alert::info` | `<div class="ft-alert ft-alert-info"><i class="fa-solid fa-circle-info"></i>...` | `ft-alert ft-alert-info` |

### Toast 提示

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `FB::Toast::success` | `<div class="ft-toast ft-toast-success"><i class="fa-solid fa-check"></i> 操作成功</div>` | `ft-toast-success` |
| `FB::Toast::error` | `<div class="ft-toast ft-toast-error"><i class="fa-solid fa-circle-exclamation"></i> 操作失败</div>` | `ft-toast-error` |
| `FB::Toast::warning` | `<div class="ft-toast ft-toast-warning"><i class="fa-solid fa-circle-exclamation"></i> 提示信息</div>` | `ft-toast-warning` |
| `FB::Toast::info` | `<div class="ft-toast ft-toast-info"><i class="fa-solid fa-circle-info"></i> 提示信息</div>` | `ft-toast-info` |

### Loading 加载中

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `FB::Loading::page` | `<div class="ft-loading"><div class="ft-spinner"></div><span class="ft-loading-text">加载中...</span></div>` | `ft-loading` `ft-spinner` |
| `FB::Loading::inline` | `<div class="ft-spinner ft-spinner-sm"></div>` | `ft-spinner ft-spinner-sm`（内联使用）|
| `FB::Loading::overlay` | `<div style="position:relative"><div class="ft-loading-overlay"><div class="ft-spinner"></div></div>内容</div>` | `ft-loading-overlay` |

### Popconfirm / Tooltip

| 令牌 | 对应 HTML | 关键 class |
|------|-----------|-----------|
| `FB::Popconfirm::default` | `<div class="ft-popconfirm"><div class="ft-popconfirm-content"><i class="fa-solid fa-circle-exclamation"></i><span>确认要执行此操作吗？</span></div><div class="ft-popconfirm-footer"><button class="ft-btn ft-btn-default ft-btn-sm">取消</button><button class="ft-btn ft-btn-primary ft-btn-sm">确定</button></div></div>` | `ft-popconfirm`（含确认/取消按钮）|
| `FB::Tooltip::default` | `<span class="ft-tooltip-wrap"><button ...>触发元素</button><div class="ft-tooltip" data-tooltip="提示文字">提示文字</div></span>` | `ft-tooltip`（`data-tooltip` 属性）|

---

## 令牌解析示例

设计方案中的「组件令牌汇总」：

| 组件令牌 | 解析结果 |
|---------|---------|
| `DISP::Table::selection` | 带复选框表格 → `<table class="ft-table">` 第一列加 `<input type="checkbox">` |
| `ENT::Input::search` | 搜索输入框 → `.ft-input-wrapper` 包裹 `.ft-input-icon` + `.ft-input` |
| `GEN::Button::primary` | 主按钮 → `<button class="ft-btn ft-btn-primary">` |
| `NAV::Pagination::default` | 分页器 → `<div class="ft-pagination">` |
| `GEN::Tag::success` | 成功标签 → `<span class="ft-tag ft-tag-success">` |
| `LAY::Toolbar::default` | 工具栏 → `.ft-toolbar` 含 `.ft-filter-area` + `.ft-action-area` |
| `FB::Alert::warning` | 警告提示 → `.ft-alert.ft-alert-warning` 含图标+标题+描述 |
| `NAV::Tabs::default` | 标签页 → `.ft-tabs-bar` 含多个 `.ft-tab`，激活项加 `.active` |
| `NAV::Steps::default` | 步骤条 → `.ft-steps` 含多个 `.ft-step`，已完成加 `.done`，当前加 `.active` |
| `ENT::Switch::on` | 开关（开）→ `.ft-switch-track.on` 包含 `.ft-switch-thumb` |
| `DISP::Progress::default` | 进度条 → `.ft-progress-track` 内 `.ft-progress-bar` 用 `style="width:N%"` |
| `FB::Drawer::default` | 抽屉 → `.ft-drawer-overlay` + `.ft-drawer`（含 header/body/footer）|
| `DISP::Descriptions::2col` | 描述列表（2列）→ `.ft-descriptions` 含多个 `.ft-desc-item` |
| `DISP::Timeline::default` | 时间轴 → `ul.ft-timeline` 含多个 `li.ft-timeline-item` |
| `GEN::Avatar::text` | 文字头像 → `<div class="ft-avatar">姓</div>` |
| `FB::Loading::page` | 页面加载 → `.ft-loading` 含 `.ft-spinner` |
| `FB::Modal::default` | 标准对话框 → `.ft-modal-overlay` + `.ft-modal`（含 header/body/footer）|
| `FB::Modal::sm` | 小对话框（480px）→ `.ft-modal.ft-modal-sm` |
| `ENT::Upload::dragger` | 拖拽上传 → `.ft-upload-dragger`（拖入时加 `dragover`）|
| `ENT::DatePicker::range` | 日期范围 → 两个 `ft-input`（`type="date"`）+ 连字符 |
| `GEN::Icon::edit` | 编辑图标 → `<i class="fa-solid fa-pen-to-square"></i>` |
| `GEN::Typography::title::h1` | 一级标题 → `<h1 class="page-title">` |
| `FB::Popconfirm::default` | 气泡确认 → `.ft-popconfirm` 含确认/取消按钮 |
| `ENT::Slider::default` | 滑动条 → `<input class="ft-slider" type="range">` |
| `ENT::TreeSelect::default` | 树形选择 → `.ft-treeselect` 含输入框和下拉箭头 |
| `ENT::Transfer::default` | 穿梭框 → `.ft-transfer` 含左右列表和操作按钮 |
| `ENT::ColorPicker::default` | 颜色选择器 → `.ft-colorpicker` 含颜色预览和值显示 |
| `LAY::Space::horizontal` | 水平间距容器 → `display:flex; gap:8px; align-items:center` |
