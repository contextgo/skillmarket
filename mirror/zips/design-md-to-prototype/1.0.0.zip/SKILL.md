---
name: design-md-to-prototype
description: 根据 Stitch DESIGN.md 和需求描述生成单个 HTML 文件原型。当用户要求从设计系统文档中生成原型、效果图或交互式预览时使用此技能——特别是他们提到 DESIGN.md、「原型」、「prototype」、「mockup」、「preview」或希望将设计可视化为可工作页面时。
---

# Design-md-to-Prototype Skill

你是一位精通前端工程的工程师，能够将设计规范转化为精美的单文件 HTML 原型。

## 输入来源

读取以下输入来构建原型：

1. **DESIGN.md** — 项目根目录下的设计系统文件。首先读取它来提取：
   - 颜色调色板（十六进制代码 + 各自用途）
   - 排版规则（字体族、字号、字重）
   - 组件样式（按钮、卡片、输入框、表格、标签等）
   - 布局原则（间距、网格、密度）

2. **需求** — 由用户在提示中提供，也可能在 `requirements.md`、`PRD.md` 等文件中。提取：
   - 页面结构和板块
   - 需要的表格、表单、图表
   - 导航元素（标签页、面包屑）

## 输出要求

生成一个**单个 `.html` 文件**，满足：
- 在任何浏览器中直接打开即可运行，无需构建步骤
- 完全自包含（所有 CSS 和 JS 内联）
- 包含让原型看起来真实的模拟数据

## 技术选型

**CSS:** 使用 CSS 变量编写自定义 CSS，变量值从 DESIGN.md 中提取的设计令牌。不使用任何框架——纯原生 CSS + 自定义属性。

**JavaScript:** 仅使用原生 JS，不需要框架。

**图表:** 通过 CDN 使用 ECharts（`https://cdn.jsdelivr.net/npm/echarts/dist/echarts.min.js`）。在 `<head>` 中加载，在 `</body>` 末尾的 script 块中初始化图表。

**图标:** 使用内联 SVG 图标或 Unicode 符号。如果需要 ArcoDesign 图标，通过 CDN 加载 ArcoDesign 图标集或使用简单 Unicode 替代方案。

**字体:** 遵循 DESIGN.md 中的字体族规则。如果未提及特定字体，使用系统默认栈：`-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "PingFang SC", "Microsoft YaHei", sans-serif`。

## 实现步骤

1. **读取 DESIGN.md**，将所有设计令牌提取到 `<style>` 块中作为 CSS 自定义属性：
    ```css
    :root {
      --color-primary: #007DFA;
      --color-success: #10B981;
      /* ... DESIGN.md 中的所有颜色 */
    }
    ```

2. **根据需求定义布局结构：**
   - 顶部导航栏（固定，如 DESIGN.md 所述）
   - 侧边栏（如需）
   - 主内容区域，包含卡片/板块

3. **将每个板块构建为自包含组件：**
   - 带模拟数据行的表格
   - 带真实输入值的表单
   - 使用 ECharts 的图表和合适的图表类型（柱状图、折线图、饼图等）

4. **添加让原型真实的模拟数据：**
   - 表格应包含 5-10 行真实的数据
   - 图表应展示有意义的分布
   - 表单应在适当位置预填值

5. **实现交互：**
   - 标签页之间的切换
   - 匹配 DESIGN.md 颜色的按钮悬停/激活状态
   - 侧边栏折叠切换（如适用）
   - 模态框/对话框交互（如需）

## 质量检查清单

输出文件前，验证：
- [ ] DESIGN.md 中的所有颜色都正确使用
- [ ] 排版精确匹配设计规范
- [ ] 表格有适当的样式和悬停状态
- [ ] 图表渲染正确且专业美观
- [ ] 按钮有 primary/secondary/danger 变体
- [ ] 页面在 1200px+ 视口宽度下看起来精致
- [ ] 除 ECharts CDN 外无外部依赖

## 常见模式

**导航栏：**
```html
<header class="top-nav">
  <div class="nav-brand">项目名称</div>
  <nav class="nav-items">...</nav>
  <div class="nav-actions">...</div>
</header>
```

**卡片：**
```html
<div class="card">
  <div class="card-header">标题 + 操作</div>
  <div class="card-body">内容</div>
</div>
```

**表格：**
```html
<table class="data-table">
  <thead>...</thead>
  <tbody>...模拟数据行...</tbody>
</table>
```

**标签：**
```html
<span class="tag tag-success">活跃</span>
```

## 提示

- 如果 DESIGN.md 提到 ArcoDesign，尝试用自定义 CSS 尽可能匹配其视觉风格
- 精确使用颜色调色板——不要发明新颜色
- 表格是企业仪表盘中主要的展示模式；确保它们看起来美观
- 如果 DESIGN.md 提供了「数据可视化」颜色系列，图表应使用该系列
