#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
write_task.py - 任务状态写入脚本
功能：
  1. 插入新任务（从 Inbox Markdown 文件解析后写入 SQLite）
  2. 更新任务状态（active → done / cancelled 等）
  3. 更新任务字段（schedule / ddl / priority / project）
  4. 每次写入同时：
     - 向 task_logs 表追加操作记录
     - 更新 tasks.updated_at（由 TRIGGER 自动维护）
     - 触发 sync_task_to_markdown(task_id)

用法：
  python write_task.py import --file "2026-04-03-播客规划输出.md"
  python write_task.py update --id "T-20260403-a3f91c" --status done --completed-at "2026-04-03T17:30:00"
  python write_task.py update --id "T-20260403-a3f91c" --schedule "2026-04-04" --priority high
  python write_task.py archive --dry-run
  python write_task.py archive
"""

import sys
import re
import os
import json
import random
import string
import sqlite3
import argparse
from pathlib import Path
from datetime import datetime, date, timedelta
from typing import Optional, Dict, Any, List, Tuple


def load_config() -> dict:
    """加载配置文件"""
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config['db_path'] = str(Path(config['db_path']).expanduser())
    return config


def get_connection(db_path: str) -> sqlite3.Connection:
    """建立 SQLite 连接并设置必要 PRAGMA"""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA synchronous=NORMAL')
    return conn


# ============================================================
# 任务 ID 生成
# ============================================================

def generate_task_id() -> str:
    """生成任务 ID：T-{YYYYMMDD}-{6位随机hex}"""
    today = date.today().strftime('%Y%m%d')
    hex_part = ''.join(random.choices('0123456789abcdef', k=6))
    return f'T-{today}-{hex_part}'


# ============================================================
# Markdown 解析
# ============================================================

def parse_markdown_file(filepath: str) -> Dict[str, Any]:
    """
    解析 Inbox Markdown 文件，提取 frontmatter 和正文。
    返回标准化的任务字典。
    """
    path = Path(filepath)
    if not path.exists():
        raise FileNotFoundError(f'文件不存在：{filepath}')

    content = path.read_text(encoding='utf-8')

    # 解析 frontmatter
    frontmatter: Dict[str, Any] = {}
    body = content
    fm_match = re.match(r'^---\s*\n(.*?)\n---\s*\n', content, re.DOTALL)
    if fm_match:
        fm_text = fm_match.group(1)
        body = content[fm_match.end():]
        frontmatter = _parse_yaml_simple(fm_text)

    # 提取标题（一级标题）
    title = ''
    title_match = re.search(r'^#\s+(.+)$', body, re.MULTILINE)
    if title_match:
        title = title_match.group(1).strip()
    elif 'title' in frontmatter:
        title = str(frontmatter['title'])
    else:
        # 从文件名推断标题：去掉日期前缀
        stem = path.stem
        title_part = re.sub(r'^\d{4}-\d{2}-\d{2}-', '', stem)
        title = title_part.replace('-', ' ')

    # 提取正文（去掉标题行）
    body_lines = body.strip().split('\n')
    body_clean = '\n'.join(
        line for line in body_lines
        if not line.strip().startswith('# ')
    ).strip()

    # 解析 tags（支持 YAML list 和单行格式）
    raw_tags = frontmatter.get('tags', [])
    if isinstance(raw_tags, list):
        tags = raw_tags
    elif isinstance(raw_tags, str):
        tags = [t.strip() for t in raw_tags.split(',') if t.strip()]
    else:
        tags = []

    # 推断 status：从 tags 中找 status 相关标签
    status = 'inbox'
    status_tags = {'inbox', 'active', 'done', 'cancelled', 'someday'}
    for tag in tags:
        tag_clean = tag.lstrip('#').lower()
        if tag_clean in status_tags:
            status = tag_clean
            break
    # frontmatter 中的 status 字段优先
    if 'status' in frontmatter:
        fm_status = str(frontmatter['status']).lower()
        if fm_status in status_tags:
            status = fm_status

    # 推断 area：从 tags 中找 work/life
    area = 'work'
    for tag in tags:
        tag_clean = tag.lstrip('#').lower()
        if tag_clean in ('work', 'life'):
            area = tag_clean
            break
    if 'area' in frontmatter:
        fm_area = str(frontmatter['area']).lower()
        if fm_area in ('work', 'life'):
            area = fm_area

    # 优先级
    priority = 'normal'
    priority_map = {'urgent': 'urgent', 'high': 'high', 'normal': 'normal', 'waiting': 'waiting'}
    if 'priority' in frontmatter:
        fp = str(frontmatter['priority']).lower()
        if fp in priority_map:
            priority = priority_map[fp]

    # 日期字段
    schedule_date = _normalize_date(frontmatter.get('schedule'))
    due_date = _normalize_date(frontmatter.get('ddl'))
    completed_at = _normalize_datetime(frontmatter.get('completed'))
    created_at = _normalize_datetime(frontmatter.get('created')) or datetime.now().isoformat()

    # 项目归属（优先 frontmatter，tag 次之）
    # 注意：空字符串视为 None（无项目），避免触发外键约束失败
    project_id = None
    if 'project' in frontmatter:
        _project_raw = str(frontmatter['project']).strip()
        project_id = _project_raw if _project_raw else None

    # 来源
    source = str(frontmatter.get('source', 'inbox'))

    # Bug A2 修复：import 时若 status=inbox 但已有 schedule_date，自动升级为 active
    # 设计方向2：有执行日期即视为已安排，无需等到晨间规划统一激活
    if status == 'inbox' and schedule_date:
        status = 'active'

    # 任务 ID（从 frontmatter 读取，避免重复导入时生成新 ID）
    existing_id = frontmatter.get('id', None)
    if existing_id:
        task_id = str(existing_id).strip()
    else:
        task_id = generate_task_id()

    return {
        'id': task_id,
        'title': title,
        'status': status,
        'priority': priority,
        'area': area,
        'project_id': project_id,
        'schedule_date': schedule_date,
        'due_date': due_date,
        'completed_at': completed_at,
        'created_at': created_at,
        'tags': json.dumps(tags, ensure_ascii=False),
        'body': body_clean if body_clean else None,
        'source': source,
        'md_filename': path.name,
    }


def _parse_yaml_simple(text: str) -> Dict[str, Any]:
    """
    简单 YAML 解析（不依赖第三方库）。
    支持：字符串值、带引号的值、列表（-开头）、多行 tags。
    """
    result: Dict[str, Any] = {}
    lines = text.split('\n')
    current_key = None
    current_list: Optional[List[str]] = None

    for line in lines:
        # 列表项
        if line.startswith('  - ') or line.startswith('- '):
            item = line.lstrip()
            if item.startswith('- '):
                item_val = item[2:].strip().strip('"').strip("'")
                if current_key and isinstance(current_list, list):
                    current_list.append(item_val)
            continue

        # 键值对
        kv_match = re.match(r'^(\w[\w\-]*)\s*:\s*(.*)', line)
        if kv_match:
            key = kv_match.group(1)
            val = kv_match.group(2).strip()

            # 保存之前的列表
            if current_key and current_list is not None:
                result[current_key] = current_list

            if val == '' or val is None:
                # 可能是列表开始
                current_key = key
                current_list = []
                result[key] = current_list
            else:
                current_key = None
                current_list = None
                # 去掉引号
                val = val.strip('"').strip("'")
                result[key] = val

    return result


def _normalize_date(val: Any) -> Optional[str]:
    """规范化日期字段为 YYYY-MM-DD 格式"""
    if not val:
        return None
    s = str(val).strip()
    if re.match(r'^\d{4}-\d{2}-\d{2}$', s):
        return s
    return None


def _normalize_datetime(val: Any) -> Optional[str]:
    """规范化日期时间字段为 ISO 8601 格式"""
    if not val:
        return None
    s = str(val).strip().strip('"').strip("'")
    # 支持 "2026-04-03 12:00" 和 "2026-04-03T12:00:00"
    if re.match(r'^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}', s):
        return s.replace(' ', 'T')
    return None


# ============================================================
# 数据库操作
# ============================================================

def insert_task(conn: sqlite3.Connection, task: Dict[str, Any]) -> str:
    """插入新任务，返回 task_id"""
    conn.execute(
        '''INSERT OR IGNORE INTO tasks
           (id, title, status, priority, area, project_id, schedule_date, due_date,
            completed_at, created_at, updated_at, tags, body, source, md_filename)
           VALUES (:id, :title, :status, :priority, :area, :project_id, :schedule_date, :due_date,
                   :completed_at, :created_at, :created_at, :tags, :body, :source, :md_filename)''',
        task
    )
    # 记录日志
    log_task_action(conn, task['id'], 'created',
                    old_value=None,
                    new_value=json.dumps({'status': task['status'], 'title': task['title']}, ensure_ascii=False),
                    context=task.get('source', 'manual'))
    return task['id']


def update_task_fields(conn: sqlite3.Connection, task_id: str,
                       updates: Dict[str, Any], context: str = 'manual') -> bool:
    """
    更新任务字段，自动记录日志。
    updates 只包含需要更新的字段（status / priority / schedule_date / due_date / project_id）。
    """
    if not updates:
        return False

    # 读取当前值用于日志
    current = conn.execute('SELECT * FROM tasks WHERE id = ?', (task_id,)).fetchone()
    if not current:
        print(f'[ERROR] 任务不存在：{task_id}')
        return False

    # 构建 SET 子句
    set_clauses = []
    params: List[Any] = []
    for field, value in updates.items():
        set_clauses.append(f'{field} = ?')
        params.append(value)
    params.append(task_id)

    conn.execute(
        f'UPDATE tasks SET {", ".join(set_clauses)} WHERE id = ?',
        params
    )

    # 判断记录哪种 action
    action = 'note_added'
    if 'status' in updates:
        old_status = current['status']
        new_status = updates['status']
        if new_status == 'done':
            action = 'completed'
        elif new_status == 'cancelled':
            action = 'cancelled'
        else:
            action = 'status_changed'
        log_task_action(conn, task_id, action,
                        old_value=json.dumps({'status': old_status}, ensure_ascii=False),
                        new_value=json.dumps({'status': new_status}, ensure_ascii=False),
                        context=context)
    if 'priority' in updates:
        log_task_action(conn, task_id, 'priority_changed',
                        old_value=json.dumps({'priority': current['priority']}, ensure_ascii=False),
                        new_value=json.dumps({'priority': updates['priority']}, ensure_ascii=False),
                        context=context)
    if 'schedule_date' in updates:
        log_task_action(conn, task_id, 'scheduled',
                        old_value=json.dumps({'schedule_date': current['schedule_date']}, ensure_ascii=False),
                        new_value=json.dumps({'schedule_date': updates['schedule_date']}, ensure_ascii=False),
                        context=context)
    if 'due_date' in updates:
        log_task_action(conn, task_id, 'due_set',
                        old_value=json.dumps({'due_date': current['due_date']}, ensure_ascii=False),
                        new_value=json.dumps({'due_date': updates['due_date']}, ensure_ascii=False),
                        context=context)
    if 'project_id' in updates:
        log_task_action(conn, task_id, 'project_assigned',
                        old_value=json.dumps({'project_id': current['project_id']}, ensure_ascii=False),
                        new_value=json.dumps({'project_id': updates['project_id']}, ensure_ascii=False),
                        context=context)
    if 'snooze_until' in updates:
        old_snooze = current['snooze_until'] if 'snooze_until' in current.keys() else None
        # 使用 note_added 动作（snooze_set 不在 CHECK 约束枚举中，SQLite 不支持直接修改约束）
        log_task_action(conn, task_id, 'note_added',
                        old_value=json.dumps({'snooze_until': old_snooze}, ensure_ascii=False),
                        new_value=json.dumps({'snooze_until': updates['snooze_until']}, ensure_ascii=False),
                        context='snooze')

    return True


def log_task_action(conn: sqlite3.Connection, task_id: str, action: str,
                    old_value: Optional[str], new_value: Optional[str],
                    context: Optional[str] = None,
                    raw_input: Optional[str] = None) -> None:
    """向 task_logs 追加操作记录"""
    conn.execute(
        'INSERT INTO task_logs (task_id, action, old_value, new_value, raw_input, context, logged_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        (task_id, action, old_value, new_value, raw_input, context, datetime.now().isoformat())
    )


def ensure_project(conn: sqlite3.Connection, project_id: str, area: str = 'work') -> None:
    """确保项目存在（不存在则自动创建）"""
    existing = conn.execute('SELECT id FROM projects WHERE id = ?', (project_id,)).fetchone()
    if not existing:
        conn.execute(
            'INSERT INTO projects (id, name, area) VALUES (?, ?, ?)',
            (project_id, project_id, area)
        )


def complete_habit(conn: sqlite3.Connection, habit_id: str, habit_date: str,
                   status: str = 'done', note: Optional[str] = None) -> bool:
    """
    完成或取消习惯打卡（幂等）。
    - 若 habit_instance 存在 → UPDATE（支持 cancelled → done 重改）
    - 若不存在 → INSERT
    - note 单独传入时（status=None 传 'done'）也能仅更新 note

    Returns True 表示成功，False 表示 habit_id 不存在。
    """
    # 验证 habit_id 存在
    habit_def = conn.execute(
        'SELECT id FROM habit_definitions WHERE id = ?', (habit_id,)
    ).fetchone()
    if not habit_def:
        print(f'[ERROR] 习惯不存在：{habit_id}')
        return False

    now = datetime.now().isoformat()
    completed_at = now if status == 'done' else None

    # 查询是否已有记录
    existing = conn.execute(
        'SELECT id, status FROM habit_instances WHERE habit_id = ? AND date = ?',
        (habit_id, habit_date)
    ).fetchone()

    if existing:
        # UPDATE：允许 cancelled → done 或 done → cancelled（习惯改正场景）
        update_fields = ['status = ?', 'completed_at = ?']
        params: List[Any] = [status, completed_at]
        if note is not None:
            update_fields.append('note = ?')
            params.append(note)
        params.append(existing['id'])
        conn.execute(
            f"UPDATE habit_instances SET {', '.join(update_fields)} WHERE id = ?",
            params
        )
        action = f'更新（{existing["status"]} → {status}）'
    else:
        # INSERT
        import random
        instance_id = f'HI-{habit_date.replace("-", "")}-{habit_id[-4:]}-{"".join(random.choices("0123456789abcdef", k=4))}'
        conn.execute(
            'INSERT INTO habit_instances (id, habit_id, date, status, completed_at, note) VALUES (?, ?, ?, ?, ?, ?)',
            (instance_id, habit_id, habit_date, status, completed_at, note)
        )
        action = '创建'

    print(f'[OK] 习惯打卡{action}：{habit_id}  {habit_date}  status={status}')
    return True


def batch_archive(conn: sqlite3.Connection, dry_run: bool = False) -> List[Dict[str, Any]]:
    """
    批量归档：将 status=done 且 completed_at < 7天前的任务软删除。
    返回符合条件的任务列表。
    """
    cutoff = (date.today() - timedelta(days=7)).isoformat()
    rows = conn.execute(
        '''SELECT id, title, completed_at FROM tasks
           WHERE status = 'done' AND is_deleted = 0
             AND completed_at IS NOT NULL AND completed_at < ?
           ORDER BY completed_at ASC''',
        (cutoff,)
    ).fetchall()

    tasks = [dict(r) for r in rows]

    if not dry_run and tasks:
        ids = [t['id'] for t in tasks]
        placeholders = ','.join('?' * len(ids))
        conn.execute(
            f"UPDATE tasks SET is_deleted = 1 WHERE id IN ({placeholders})",
            ids
        )
        for t in tasks:
            log_task_action(conn, t['id'], 'note_added',
                            old_value=json.dumps({'is_deleted': 0}, ensure_ascii=False),
                            new_value=json.dumps({'is_deleted': 1, 'reason': 'archive'}, ensure_ascii=False),
                            context='archive')

    return tasks


# ============================================================
# 项目月度目标（v3.0.4）
# ============================================================

def cmd_update_goal(args: argparse.Namespace, config: dict) -> None:
    """设置/修改项目月度目标"""
    project_id = args.project
    month = args.month
    goal = args.goal
    actual = getattr(args, 'actual', None)

    goal_id = f'{project_id}:{month}'
    db_path = config['db_path']
    conn = get_connection(db_path)
    try:
        # 统计该项目本月任务数
        done_count = conn.execute(
            "SELECT COUNT(*) FROM tasks WHERE is_deleted=0 AND project_id=? "
            "AND status='done' AND (completed_at LIKE ? OR schedule_date LIKE ?)",
            (project_id, f'{month}%', f'{month}%')
        ).fetchone()[0]
        active_count = conn.execute(
            "SELECT COUNT(*) FROM tasks WHERE is_deleted=0 AND project_id=? "
            "AND status='active' AND schedule_date LIKE ?",
            (project_id, f'{month}%')
        ).fetchone()[0]

        now_str = datetime.now().isoformat()
        conn.execute(
            """INSERT INTO project_goals (id, project_id, month, goal, actual_summary,
                task_done_count, task_active_count, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT(id) DO UPDATE SET
                goal=excluded.goal,
                actual_summary=COALESCE(excluded.actual_summary, actual_summary),
                task_done_count=excluded.task_done_count,
                task_active_count=excluded.task_active_count,
                updated_at=excluded.updated_at""",
            (goal_id, project_id, month, goal, actual,
             done_count, active_count, now_str, now_str)
        )
        conn.commit()
        print(f'[OK] 项目目标已设置：{project_id} · {month}')
        print(f'     🎯 目标：{goal}')
        if actual:
            print(f'     📊 实际：{actual}')
        print(f'     完成 {done_count} 项 · 进行中 {active_count} 项')
    finally:
        conn.close()


# ============================================================
# 命令行入口
# ============================================================

def cmd_import(args: argparse.Namespace, config: dict) -> None:
    """导入任务：从 JSON 字符串（v3.0 推荐）或 Markdown 文件"""
    json_str = getattr(args, 'json_str', None)

    if json_str:
        # v3.0 新模式：直接从 JSON 字符串导入
        try:
            task_data = json.loads(json_str)
        except json.JSONDecodeError as e:
            print(f'[ERROR] JSON 解析失败：{e}', file=sys.stderr)
            sys.exit(1)

        # 必填字段检查
        if not task_data.get('title'):
            print('[ERROR] JSON 缺少 title 字段', file=sys.stderr)
            sys.exit(1)

        # 生成 task_id
        from hashlib import md5
        date_str = date.today().strftime('%Y%m%d')
        hash_input = f"{task_data['title']}-{datetime.now().isoformat()}"
        short_hash = md5(hash_input.encode()).hexdigest()[:6]
        task_id = f'T-{date_str}-{short_hash}'

        # 组装任务字典（兼容 insert_task 的 SQL binding）
        now_str = datetime.now().isoformat()
        task = {
            'id': task_data.get('id', task_id),
            'title': task_data['title'],
            'status': task_data.get('status', 'inbox'),
            'priority': task_data.get('priority', 'normal'),
            'area': task_data.get('area', 'work'),
            'project_id': task_data.get('project', task_data.get('project_id', None)) or None,
            'schedule_date': task_data.get('schedule', task_data.get('schedule_date', None)),
            'due_date': task_data.get('ddl', task_data.get('due_date', None)),
            'completed_at': task_data.get('completed_at', None),
            'created_at': now_str,
            'tags': task_data.get('tags', '[]'),
            'body': task_data.get('body', ''),
            'source': task_data.get('source', 'inbox'),
            'md_filename': '',
        }

        # v3.0.1: status=done 时自动补全 completed_at
        if task['status'] == 'done' and not task.get('completed_at'):
            task['completed_at'] = now_str
            print(f'[INFO] status=done 但未指定 completed_at，已自动补全为 {now_str}', file=sys.stderr)

        # auto_activate: inbox + schedule_date → active
        if task['status'] == 'inbox' and task.get('schedule_date'):
            task['status'] = 'active'

        print(f'[INFO] 从 JSON 导入：{task["title"]}')
    elif args.file:
        # 旧模式：从 Markdown 文件导入
        filepath = args.file
        if not Path(filepath).is_absolute():
            inbox_path = config.get('inbox_path', '')
            if inbox_path:
                filepath = str(Path(inbox_path) / filepath)
        print(f'[INFO] 正在导入：{filepath}')
        task = parse_markdown_file(filepath)
    else:
        print('[ERROR] 必须提供 --json 或 --file 参数', file=sys.stderr)
        sys.exit(1)

    db_path = config['db_path']
    conn = get_connection(db_path)
    try:
        with conn:
            if task.get('project_id'):
                ensure_project(conn, task['project_id'], task.get('area', 'work'))
            task_id = insert_task(conn, task)
            raw = getattr(args, 'raw_input', None)
            if raw:
                log_task_action(conn, task_id, 'user_input',
                                old_value=None, new_value=None,
                                raw_input=raw, context='inbox')
        rocky_voice = config.get('rocky_voice', True)
        # 组装确认信息
        area_display = '💼 工作' if task.get('area') == 'work' else '🏠 生活'
        ddl_line = f'\n📅 DDL：{task["due_date"]}' if task.get('due_date') else ''
        schedule_line = f'\n🗓️ 执行：{task["schedule_date"]}' if task.get('schedule_date') else ''
        project_line = f' · {task["project_id"]}' if task.get('project_id') else ''
        confirm_body = (
            f'✅ 已记录：{task["title"]}\n'
            f'🏷️ {area_display}{project_line}{ddl_line}{schedule_line}\n'
            f'📍 已入收件箱'
        )
        print(f'CONFIRM_START')
        print(confirm_body)
        print(f'CONFIRM_END')
        if rocky_voice:
            print(f'💬 Rocky：Rocky 记住了。你不用记，Rocky 记忆完美。')
    finally:
        conn.close()


def cmd_update(args: argparse.Namespace, config: dict) -> None:
    """更新任务字段"""
    task_id = args.id
    updates: Dict[str, Any] = {}

    # 状态更新
    valid_statuses = {'inbox', 'active', 'done', 'cancelled', 'someday'}
    if args.status:
        if args.status not in valid_statuses:
            print(f'[ERROR] 无效状态：{args.status}，有效值：{sorted(valid_statuses)}')
            sys.exit(1)
        updates['status'] = args.status
        # done 时记录完成时间
        if args.status == 'done':
            completed_at = args.completed_at or datetime.now().isoformat()
            updates['completed_at'] = completed_at

    valid_priorities = {'urgent', 'high', 'normal', 'waiting'}
    if args.priority:
        if args.priority not in valid_priorities:
            print(f'[ERROR] 无效优先级：{args.priority}，有效值：{sorted(valid_priorities)}')
            sys.exit(1)
        updates['priority'] = args.priority

    if args.schedule:
        d = _normalize_date(args.schedule)
        if not d:
            print(f'[ERROR] 日期格式无效：{args.schedule}，请使用 YYYY-MM-DD')
            sys.exit(1)
        updates['schedule_date'] = d
        # Bug A 修复：设置执行日期时，若任务当前为 inbox 自动激活为 active
        conn_check = get_connection(config['db_path'])
        row = conn_check.execute(
            'SELECT status FROM tasks WHERE id=? AND is_deleted=0', (args.id,)
        ).fetchone()
        conn_check.close()
        if row and row[0] == 'inbox' and 'status' not in updates:
            updates['status'] = 'active'

    if args.ddl:
        d = _normalize_date(args.ddl)
        if not d:
            print(f'[ERROR] 日期格式无效：{args.ddl}，请使用 YYYY-MM-DD')
            sys.exit(1)
        updates['due_date'] = d

    if args.project:
        updates['project_id'] = args.project

    # snooze 参数处理
    if hasattr(args, 'snooze') and args.snooze:
        if args.snooze == 'clear':
            updates['snooze_until'] = None
        else:
            d = _normalize_date(args.snooze)
            if not d:
                print(f'[ERROR] snooze 日期格式无效：{args.snooze}，请使用 YYYY-MM-DD 或 "clear"')
                sys.exit(1)
            updates['snooze_until'] = d

    if not updates:
        print('[WARN] 未提供任何更新字段，请使用 --status / --priority / --schedule / --ddl / --project')
        return

    db_path = config['db_path']
    conn = get_connection(db_path)
    try:
        with conn:
            # 若涉及项目变更，先确保 projects 表有对应记录（避免外键约束报错）
            if args.project:
                ensure_project(conn, args.project)
            success = update_task_fields(conn, task_id, updates, context='manual')
        if success:
            updated_fields = ', '.join(f'{k}={v}' for k, v in updates.items())
            print(f'[OK] 任务更新成功：{task_id}  ({updated_fields})')
        else:
            print(f'[ERROR] 更新失败，任务不存在：{task_id}')
            sys.exit(1)
    finally:
        conn.close()


def cmd_archive(args: argparse.Namespace, config: dict) -> None:
    """批量归档完成任务"""
    dry_run = args.dry_run
    db_path = config['db_path']
    conn = get_connection(db_path)
    try:
        with conn:
            tasks = batch_archive(conn, dry_run=dry_run)
    finally:
        conn.close()

    if not tasks:
        print('[INFO] 没有符合归档条件的任务（done + 7天前）')
        return

    if dry_run:
        print(f'[DRY-RUN] 将归档以下 {len(tasks)} 个任务：')
    else:
        print(f'[OK] 已归档 {len(tasks)} 个任务：')

    for t in tasks:
        print(f'  {t["id"]}  {t["completed_at"]}  {t["title"][:40]}')


def cmd_complete_habit(args: argparse.Namespace, config: dict) -> None:
    """完成或取消今日习惯打卡"""
    db_path = config['db_path']
    conn = get_connection(db_path)
    try:
        with conn:
            success = complete_habit(
                conn,
                habit_id=args.habit_id,
                habit_date=args.date,
                status=args.status,
                note=args.note,
            )
        if not success:
            sys.exit(1)
    finally:
        conn.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro - 任务状态写入工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python write_task.py import --file "2026-04-03-播客规划输出.md"
  python write_task.py update --id T-20260403-a3f91c --status done
  python write_task.py update --id T-20260403-a3f91c --schedule 2026-04-04 --priority high
  python write_task.py archive --dry-run
  python write_task.py archive
        """
    )
    subparsers = parser.add_subparsers(dest='command', required=True)

    # import 子命令
    import_parser = subparsers.add_parser('import', help='导入任务（从 JSON 字符串或 Markdown 文件）')
    import_parser.add_argument('--file', default=None, help='Inbox Markdown 文件名或绝对路径（旧模式）')
    import_parser.add_argument('--json', dest='json_str', default=None,
                               help='任务 JSON 字符串（v3.0 推荐，跳过 Inbox 文件）')
    import_parser.add_argument('--raw-input', dest='raw_input', default=None,
                               help='用户原文（完整保留，写入 task_logs.raw_input）')

    # update 子命令
    update_parser = subparsers.add_parser('update', help='更新任务字段')
    update_parser.add_argument('--id', required=True, help='任务 ID（T-YYYYMMDD-xxxxxx）')
    update_parser.add_argument('--status', help='新状态：inbox/active/done/cancelled/someday')
    update_parser.add_argument('--priority', help='优先级：urgent/high/normal/waiting')
    update_parser.add_argument('--schedule', help='计划执行日期 YYYY-MM-DD')
    update_parser.add_argument('--ddl', help='截止日期 YYYY-MM-DD')
    update_parser.add_argument('--project', help='项目 ID（如 P-播客项目）')
    update_parser.add_argument('--completed-at', dest='completed_at',
                               help='完成时间（status=done 时可选）ISO 8601 格式')
    update_parser.add_argument('--snooze',
                               help='snooze 到指定日期（YYYY-MM-DD）后不再浮出；传 "clear" 清除 snooze')

    # archive 子命令
    archive_parser = subparsers.add_parser('archive', help='批量归档 done+7天前的任务')
    archive_parser.add_argument('--dry-run', action='store_true', help='预览，不实际执行')

    # complete-habit 子命令
    ch_parser = subparsers.add_parser('complete-habit', help='完成或取消今日习惯打卡')
    ch_parser.add_argument('--habit-id', dest='habit_id', required=True,
                           help='习惯 ID（如 HD-晨间跑步）')
    ch_parser.add_argument('--date', default=date.today().isoformat(),
                           help='打卡日期 YYYY-MM-DD（默认今天）')
    ch_parser.add_argument('--status', choices=['done', 'cancelled'], default='done',
                           help='打卡状态：done（完成）/ cancelled（跳过）')
    ch_parser.add_argument('--note', default=None,
                           help='打卡备注（如"完成30分钟"）')

    # update-goal 子命令（v3.0.4）
    goal_parser = subparsers.add_parser('update-goal', help='设置/修改项目月度目标')
    goal_parser.add_argument('--project', required=True, help='项目 ID（如 P-播客项目）')
    goal_parser.add_argument('--month', required=True, help='目标月份 YYYY-MM')
    goal_parser.add_argument('--goal', required=True, help='目标描述（一句话）')
    goal_parser.add_argument('--actual', default=None, help='实际进展摘要（月复盘时填写）')

    args = parser.parse_args()
    config = load_config()

    if args.command == 'import':
        cmd_import(args, config)
    elif args.command == 'update':
        cmd_update(args, config)
    elif args.command == 'archive':
        cmd_archive(args, config)
    elif args.command == 'complete-habit':
        cmd_complete_habit(args, config)
    elif args.command == 'update-goal':
        cmd_update_goal(args, config)


if __name__ == '__main__':
    main()
