#!/usr/bin/env python3
"""
render_table.py - LifeOps Pro 通用 Markdown 表格渲染脚本
版本：v3.0.0

主要用途：作为函数库被 build_plan.py 内部 import 调用。
CLI 入口仅供调试/开发使用，正常流程不直接调用此脚本。

依赖：纯 Python 标准库（json, sys, datetime, re, argparse）
输入：标准化 JSON（DailyPlan 结构）
输出：完整 Markdown 表格文本

用法：
  # 从 JSON 文件渲染
  python3 render_table.py --input /tmp/plan.json

  # 从 stdin 渲染（AI 调用时的主要方式）
  echo '{"date":"2026-04-03",...}' | python3 render_table.py

  # 指定渲染模式
  python3 render_table.py --input /tmp/plan.json --mode daily-plan
  python3 render_table.py --input /tmp/review.json --mode review
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any, Tuple

# ============================================================
# 枚举映射（与 schemas.py 保持一致）
# ============================================================

PRIORITY_DISPLAY: Dict[str, str] = {
    'urgent':  '🔴',
    'high':    '🟡',
    'normal':  '🟢',
    'waiting': '⏳',
}

AREA_DISPLAY: Dict[str, str] = {
    'work': '💼 工作',
    'life': '🏠 生活',
}

STATUS_DISPLAY: Dict[str, str] = {
    'inbox':     '📥 待安排',
    'active':    '🔄 进行中',
    'done':      '✅ 完成',
    'cancelled': '❌ 取消',
    'someday':   '📦 搁置',
}

# ============================================================
# 工具函数
# ============================================================

def _today_str() -> str:
    """返回今日日期字符串 YYYY-MM-DD"""
    return date.today().isoformat()


def _format_ddl(ddl_str: Optional[str], today: Optional[str] = None) -> str:
    """
    格式化 DDL 展示：
    - 只显示 MM-DD
    - 逾期加 🔥，今天到期加 🔔，明天到期加 ⚠️
    """
    if not ddl_str:
        return '—'
    try:
        ddl_date = date.fromisoformat(ddl_str)
        today_date = date.fromisoformat(today) if today else date.today()
        delta = (ddl_date - today_date).days
        mm_dd = ddl_date.strftime('%m-%d')
        if delta < 0:
            return f'{mm_dd} 🔥'
        elif delta == 0:
            return f'{mm_dd} 🔔'
        elif delta == 1:
            return f'{mm_dd} ⚠️'
        else:
            return mm_dd
    except (ValueError, TypeError):
        return ddl_str or '—'


def _ddl_badge(days_remaining: Optional[int]) -> str:
    """DDL 提醒表格中的剩余天数展示"""
    if days_remaining is None:
        return '—'
    if days_remaining < 0:
        return f'🔥 逾期{-days_remaining}天'
    elif days_remaining == 0:
        return '🔔 今天'
    elif days_remaining == 1:
        return '⚠️ 明天'
    else:
        return f'{days_remaining}天后'


def _ddl_advice(days_remaining: Optional[int]) -> str:
    """DDL 提醒建议文字"""
    if days_remaining is None:
        return '—'
    if days_remaining < 0:
        return '立即处理'
    elif days_remaining == 0:
        return '今日内完成'
    elif days_remaining <= 2:
        return '本周内完成'
    else:
        return '提前准备'


def _count_priorities(tasks: List[Dict[str, Any]]) -> str:
    """统计任务优先级分布，格式如 1🔴 1🟡 1⏳"""
    counts: Dict[str, int] = {'urgent': 0, 'high': 0, 'normal': 0, 'waiting': 0}
    for t in tasks:
        p = t.get('priority', 'normal')
        if p in counts:
            counts[p] += 1
    parts = []
    for key, emoji in [('urgent', '🔴'), ('high', '🟡'), ('normal', '🟢'), ('waiting', '⏳')]:
        if counts[key] > 0:
            parts.append(f'{counts[key]}{emoji}')
    return ' '.join(parts)


def _area_count_priorities(groups: List[Dict[str, Any]]) -> str:
    """汇总工作区/生活区的所有任务优先级分布"""
    all_tasks: List[Dict[str, Any]] = []
    for g in groups:
        all_tasks.extend(g.get('tasks', []))
    total = len(all_tasks)
    counts_str = _count_priorities(all_tasks)
    return f'{total} 项 · {counts_str}' if counts_str else f'{total} 项'


# ============================================================
# 核心渲染函数
# ============================================================

def render_task_table(
    groups: List[Dict[str, Any]],
    global_seq: List[int],
    today: Optional[str] = None,
) -> str:
    """
    渲染一组 ProjectGroup（同属同一 area）的任务表格
    global_seq: 传入一个长度为 1 的列表 [当前序号]，函数内部递增（模拟引用传递）
    """
    lines: List[str] = []

    for group in groups:
        tasks = group.get('tasks', [])
        if not tasks:
            continue

        name = group.get('name', '无项目任务')
        total = len(tasks)
        priority_stat = _count_priorities(tasks)
        stat_str = f'{total} 项 · {priority_stat}' if priority_stat else f'{total} 项'

        # 项目标题行（name 已含 emoji 前缀则不重复加 📂）
        _EMOJI_PREFIXES = ('📂', '📌', '🏃', '💼', '🏠', '📦')
        name_display = name if any(name.startswith(p) for p in _EMOJI_PREFIXES) else f'📂 {name}'
        lines.append(f'#### {name_display}（{stat_str}）')

        # 表头（统一 7 列：与 render_review.py 格式对齐）
        lines.append('| # | P | 任务 | 状态 | 执行时间 | DDL | 说明 |')
        lines.append('|---|---|------|------|----------|-----|------|')

        for task in tasks:
            seq = global_seq[0]
            global_seq[0] += 1

            priority = task.get('priority', 'normal')
            p_emoji = PRIORITY_DISPLAY.get(priority, '🟢')
            title = task.get('title', '')
            ddl_str = task.get('ddl', None)
            note = task.get('note', '')
            overdue_days = task.get('overdue_days', None)
            delayed = task.get('delayed', False)
            status = task.get('status', 'active')

            # done 状态加删除线（仅 md 格式，plain 格式不加）
            title_display = f'~~{title}~~' if status == 'done' else title

            # DDL 格式化
            ddl_display = _format_ddl(ddl_str, today)

            # 执行时间：优先显示 time_slot（用户指定），无则显示 —
            time_slot = task.get('time_slot')
            schedule_display = time_slot if time_slot else '—'

            # 状态列
            STATUS_DISPLAY = {
                'active':    '🔄 进行中',
                'inbox':     '📥 待安排',
                'done':      '✅ 完成',
                'cancelled': '❌ 取消',
                'someday':   '💤 搁置',
                'waiting':   '⏳ 等待',
            }
            status_display = STATUS_DISPLAY.get(status, status)
            # 逾期任务特殊标注
            if overdue_days and overdue_days > 0:
                status_display = f'🔥 逾期{overdue_days}天'
            elif delayed and status == 'active':
                status_display = '⏩ 顺延'

            # 说明列（等待中保留说明，其余用 note 或 —）
            note_parts: List[str] = []
            if priority == 'waiting' and note:
                note_parts.append(note)
            elif priority == 'waiting' and not note:
                note_parts.append('等待中')
            elif note and priority != 'waiting':
                note_parts.append(note)

            note_display = ' · '.join(note_parts) if note_parts else '—'

            lines.append(f'| {seq} | {p_emoji} | {title_display} | {status_display} | {schedule_display} | {ddl_display} | {note_display} |')

        lines.append('')  # 组间空行

    return '\n'.join(lines)


def render_habit_table(habits: List[Dict[str, Any]], start_seq: int = 0) -> 'Tuple[str, int]':
    """渲染习惯表格（统一 7 列，与任务表格格式对齐）

    start_seq: 全局序号起始值（0 表示用 —，>0 表示从该序号开始连续编号）

    返回：(rendered_markdown, next_seq)
      - rendered_markdown：渲染结果字符串
      - next_seq：习惯渲染完后下一个可用序号（供候选池接续）
    """
    if not habits:
        return '', start_seq

    done_count = sum(1 for h in habits if h.get('status') == 'done')
    pending_count = sum(1 for h in habits if h.get('status') == 'pending')
    cancelled_count = sum(1 for h in habits if h.get('status') == 'cancelled')

    # 统计行
    stat_parts = []
    if done_count:
        stat_parts.append(f'{done_count}✅')
    if pending_count:
        stat_parts.append(f'{pending_count}⏸️')
    if cancelled_count:
        stat_parts.append(f'{cancelled_count}❌')
    stat_str = ' '.join(stat_parts)

    lines: List[str] = [
        f'#### 🏃 今日习惯（{len(habits)} 项 · {stat_str}）',
        '| # | P | 任务 | 状态 | 执行时间 | DDL | 说明 |',
        '|---|---|------|------|----------|-----|------|',
    ]

    for i, habit in enumerate(habits):
        name = habit.get('name', '')
        time_str = habit.get('time', '')
        status = habit.get('status', 'pending')
        seq_display = str(start_seq + i) if start_seq > 0 else '—'

        if status == 'done':
            time_display = f'✅ {time_str}' if time_str else '✅'
            status_display = '✅ 完成'
        elif status == 'cancelled':
            time_display = time_str or '—'
            status_display = '❌ 已取消'
        else:
            time_display = f'⏰ {time_str}' if time_str else '⏰'
            status_display = '⏸️ 待完成'

        lines.append(f'| {seq_display} | 🟢 | {name} | {status_display} | {time_display} | — | — |')

    lines.append('')
    # 计算下一个可用序号
    next_seq = (start_seq + len(habits)) if start_seq > 0 else start_seq
    return '\n'.join(lines), next_seq


def render_task_plain(
    groups: List[Dict[str, Any]],
    global_seq: List[int],
    today: Optional[str] = None,
) -> str:
    """
    Plain 格式渲染任务列表（供企微 Bot / 纯文本场景使用）。
    去掉表头/分隔线/管道符，用缩进文本替代，DDL 只在有值时追加。
    """
    lines: List[str] = []
    for group in groups:
        tasks = group.get('tasks', [])
        if not tasks:
            continue
        name = group.get('name') or '无项目任务'
        total = len(tasks)
        _EMOJI_PREFIXES = ('📂', '📌', '🏃', '💼', '🏠', '📦')
        name_display = name if any(name.startswith(p) for p in _EMOJI_PREFIXES) else f'📂 {name}'
        lines.append(f'{name_display}（{total} 项）')
        for t in tasks:
            seq = global_seq[0]
            global_seq[0] += 1
            p_emoji = PRIORITY_DISPLAY.get(t.get('priority', 'normal'), '🟢')
            title = t.get('title', '')
            status = t.get('status', 'active')
            # 状态前缀：只有明确完成才加 ✅，进行中不加前缀，习惯待完成加 ⏸️
            status_prefix = '✅ ' if status == 'done' else ('❌ ' if status == 'cancelled' else '')
            ddl_raw = t.get('ddl') or ''
            ddl_suffix = f'  ⚠️ {ddl_raw}' if ddl_raw else ''
            lines.append(f'  {seq} {p_emoji} {status_prefix}{title}{ddl_suffix}')
        lines.append('')
    return '\n'.join(lines)


def render_habit_plain(
    habits: List[Dict[str, Any]],
    start_seq: int = 1,
) -> Tuple[str, int]:
    """Plain 格式渲染习惯列表"""
    if not habits:
        return '', start_seq
    lines = ['🏃 今日习惯']
    seq = start_seq
    for h in habits:
        name = h.get('name', '')
        status = h.get('status', 'pending')
        status_icon = {'done': '✅', 'cancelled': '❌', 'pending': '⏸️'}.get(status, '⏸️')
        lines.append(f'  {seq} {status_icon} {name}')
        seq += 1
    lines.append('')
    return '\n'.join(lines), seq


def render_daily_plan_plain(data: Dict[str, Any], no_candidate: bool = False) -> str:
    """
    Plain 格式渲染完整今日计划（企微 Bot / 纯文本场景）。
    去掉 Markdown 表格语法，保留所有信息，移动端可读。
    """
    plan_date = data.get('date', _today_str())
    projects: List[Dict[str, Any]] = data.get('projects', [])
    habits: List[Dict[str, Any]] = data.get('habits', [])
    delayed_tasks: List[Dict[str, Any]] = data.get('delayed_tasks', [])
    crossday_done: List[Dict[str, Any]] = data.get('crossday_done', [])
    candidate_pool: List[Dict[str, Any]] = data.get('candidate_pool', [])

    work_groups = [g for g in projects if g.get('area') == 'work']
    life_groups = [g for g in projects if g.get('area') == 'life']
    output_parts: List[str] = []
    global_seq = [1]

    if work_groups:
        work_tasks_all = [t for g in work_groups for t in g.get('tasks', [])]
        output_parts.append(f'💼 工作（{len(work_tasks_all)} 项）')
        output_parts.append(render_task_plain(work_groups, global_seq, today=plan_date))

    if life_groups:
        life_tasks_all = [t for g in life_groups for t in g.get('tasks', [])]
        output_parts.append(f'🏠 生活（{len(life_tasks_all)} 项）')
        output_parts.append(render_task_plain(life_groups, global_seq, today=plan_date))

    if habits:
        habit_text, next_seq = render_habit_plain(habits, start_seq=global_seq[0])
        output_parts.append(habit_text)
        global_seq[0] = next_seq

    if crossday_done:
        output_parts.append('⏮️ 跨日完成（昨日排期今日完成）')
        output_parts.append(render_task_plain(crossday_done, global_seq, today=plan_date))

    if candidate_pool and not no_candidate:
        output_parts.append(f'📦 候选任务（{len(candidate_pool)} 项待安排）')
        for i, t in enumerate(candidate_pool):
            seq = global_seq[0]
            global_seq[0] += 1
            p_emoji = PRIORITY_DISPLAY.get(t.get('priority', 'normal'), '🟢')
            title = t.get('title', '')
            output_parts.append(f'  {seq} {p_emoji} {title}')
        output_parts.append('')

    if delayed_tasks:
        output_parts.append('📌 延后事项')
        for t in delayed_tasks:
            output_parts.append(f'  · {t.get("title", "")}（顺延）')
        output_parts.append('')

    return '\n'.join(filter(None, output_parts))


def render_candidate_pool(
    tasks: List[Dict[str, Any]],
    today: Optional[str] = None,
    start_seq: int = 1,
) -> str:
    """
    渲染候选池表格
    start_seq: 序号起始值，应传入主任务最后序号+1，确保全局连续
    """
    if not tasks:
        return ''

    lines: List[str] = [
        '## 📦 其他候选事项',
        '| # | P | 任务 | 状态 | 执行时间 | DDL | 说明 |',
        '|---|---|------|------|----------|-----|------|',
    ]

    for i, task in enumerate(tasks, start_seq):
        priority = task.get('priority', 'normal')
        p_emoji = PRIORITY_DISPLAY.get(priority, '🟢')
        title = task.get('title', '')
        ddl_display = _format_ddl(task.get('ddl'), today)
        note = task.get('note', '') or '—'
        time_slot = task.get('time_slot') or '—'
        lines.append(f'| {i} | {p_emoji} | {title} | 📥 待安排 | {time_slot} | {ddl_display} | {note} |')

    lines.append('')
    return '\n'.join(lines)


def render_ddl_warnings(warnings: List[Dict[str, Any]]) -> str:
    """渲染 DDL 临近提醒表格"""
    if not warnings:
        return ''

    lines: List[str] = [
        '## ⚠️ DDL 临近提醒',
        '| 任务 | DDL | 剩余天数 | 建议 |',
        '|------|-----|----------|------|',
    ]

    for w in warnings:
        title = w.get('title', '')
        ddl = w.get('ddl', '')
        days = w.get('days_remaining', None)

        # DDL 只显示 MM-DD
        try:
            ddl_display = date.fromisoformat(ddl).strftime('%m-%d') if ddl else '—'
        except ValueError:
            ddl_display = ddl or '—'

        badge = _ddl_badge(days)
        advice = _ddl_advice(days)
        lines.append(f'| {title} | {ddl_display} | {badge} | {advice} |')

    lines.append('')
    return '\n'.join(lines)


def render_delayed_tasks(tasks: List[Dict[str, Any]]) -> str:
    """渲染延后事项列表"""
    if not tasks:
        return ''

    lines: List[str] = ['## 📌 延后事项']
    for task in tasks:
        title = task.get('title', '')
        lines.append(f'- 📝 **{title}**（昨日顺延）')

    lines.append('')
    return '\n'.join(lines)


# ============================================================
# 主渲染入口
# ============================================================

def render_daily_plan(data: Dict[str, Any], no_candidate: bool = False, fmt: str = 'md') -> str:
    """渲染完整的今日计划。
    fmt='plain' 时输出纯文本格式（企微 Bot / 移动端场景）。
    no_candidate=True 时不输出候选池（用于写入 Daily Note）。
    """
    if fmt == 'plain':
        return render_daily_plan_plain(data, no_candidate=no_candidate)
    plan_date = data.get('date', _today_str())

    # ── Schema 强制校验（防止静默失败）──────────────────────────
    # 检查顶层必填字段
    missing_fields = [f for f in ('date', 'projects', 'habits') if f not in data]
    if missing_fields:
        msg = (
            f'❌ render_table 失败：JSON 缺少必填字段 {missing_fields}\n'
            f'   期望字段：date, projects (List[ProjectGroup]), habits (List[Habit])\n'
            f'   实际字段：{list(data.keys())}\n'
            f'   请检查 JSON 是否符合 DailyPlan schema（参考 schemas.py）'
        )
        print(msg, file=sys.stderr)
        sys.exit(1)

    # 检查 projects 中是否存在非标准键（如 sections/project_id/area_tasks 等）
    non_standard_project_keys = set()
    for pg in data.get('projects', []):
        if not isinstance(pg, dict):
            continue
        if 'name' not in pg or 'area' not in pg or 'tasks' not in pg:
            non_standard_project_keys.update(pg.keys())
    if non_standard_project_keys:
        msg = (
            f'❌ render_table 失败：projects 中存在不符合 ProjectGroup schema 的字段\n'
            f'   发现字段：{non_standard_project_keys}\n'
            f'   ProjectGroup 必须包含：name (str), area (work|life), tasks (List[Task])\n'
            f'   请对照 schemas.py 修正 JSON 后重试'
        )
        print(msg, file=sys.stderr)
        sys.exit(1)

    # 检查 habits 中是否缺少必填字段
    for i, h in enumerate(data.get('habits', [])):
        if not isinstance(h, dict):
            continue
        missing_habit = [f for f in ('name', 'time', 'status') if f not in h]
        if missing_habit:
            msg = (
                f'❌ render_table 失败：habits[{i}] 缺少必填字段 {missing_habit}\n'
                f'   Habit 必须包含：name (str), time (str), status (done|pending|cancelled)\n'
                f'   实际字段：{list(h.keys())}'
            )
            print(msg, file=sys.stderr)
            sys.exit(1)
    # ─────────────────────────────────────────────────────────────

    projects: List[Dict[str, Any]] = data.get('projects', [])
    habits: List[Dict[str, Any]] = data.get('habits', [])
    candidate_pool: List[Dict[str, Any]] = data.get('candidate_pool', [])
    ddl_warnings: List[Dict[str, Any]] = data.get('ddl_warnings', [])
    delayed_tasks: List[Dict[str, Any]] = data.get('delayed_tasks', [])

    # 分区：work / life
    work_groups = [g for g in projects if g.get('area') == 'work']
    life_groups = [g for g in projects if g.get('area') == 'life']

    output_parts: List[str] = []

    # 全局序号（跨项目组连续）
    global_seq = [1]

    # 工作区
    if work_groups:
        work_tasks_all = [t for g in work_groups for t in g.get('tasks', [])]
        work_stat = f'{len(work_tasks_all)} 项 · {_count_priorities(work_tasks_all)}'
        output_parts.append(f'### {AREA_DISPLAY["work"]}（{work_stat}）\n')
        output_parts.append(render_task_table(work_groups, global_seq, today=plan_date))

    # 生活区
    if life_groups:
        life_tasks_all = [t for g in life_groups for t in g.get('tasks', [])]
        life_stat = f'{len(life_tasks_all)} 项 · {_count_priorities(life_tasks_all)}'
        output_parts.append(f'### {AREA_DISPLAY["life"]}（{life_stat}）\n')
        output_parts.append(render_task_table(life_groups, global_seq, today=plan_date))

    # 习惯（序号接续主任务全局序号）
    if habits:
        habit_rendered, next_seq = render_habit_table(habits, start_seq=global_seq[0])
        output_parts.append(habit_rendered)
        global_seq[0] = next_seq  # 更新全局序号，候选池从习惯结束后接续

    # 跨日完成区（midday 模式专用）：昨日排期今日完成的任务
    crossday_done: List[Dict[str, Any]] = data.get('crossday_done', [])
    if crossday_done:
        crossday_lines = ['## ⏮️ 跨日完成（昨日排期今日完成）', '']
        for group in crossday_done:
            name = group.get('name', '无项目任务')
            tasks = group.get('tasks', [])
            if not tasks:
                continue
            crossday_lines.append(f'#### 📂 {name}（{len(tasks)} 项）')
            crossday_lines.append('')
            crossday_lines.append('| # | P | 任务 | 状态 | 执行时间 | DDL | 说明 |')
            crossday_lines.append('|---|---|------|------|----------|-----|------|')
            for t in tasks:
                seq = global_seq[0]
                global_seq[0] += 1
                p_emoji = PRIORITY_DISPLAY.get(t.get('priority', 'normal'), '🟢')
                title = t.get('title', '')
                status_display = STATUS_DISPLAY.get(t.get('status', 'done'), '✅ 完成')
                time_slot = t.get('time_slot') or '—'
                ddl_raw = t.get('ddl') or ''
                ddl_display = _format_ddl(ddl_raw, plan_date) if ddl_raw else '—'
                note = t.get('note') or '—'
                crossday_lines.append(
                    f'| {seq} | {p_emoji} | {title} | {status_display} | {time_slot} | {ddl_display} | {note} |'
                )
            crossday_lines.append('')
        output_parts.append('\n'.join(crossday_lines))

    # 候选池（序号从习惯之后接续，全局连续不重叠）
    # no_candidate=True 时跳过（用于 Daily Note 写入，候选池不写入定稿区）
    if candidate_pool and not no_candidate:
        output_parts.append(render_candidate_pool(candidate_pool, today=plan_date, start_seq=global_seq[0]))

    # DDL 提醒
    if ddl_warnings:
        output_parts.append(render_ddl_warnings(ddl_warnings))

    # 延后事项
    if delayed_tasks:
        output_parts.append(render_delayed_tasks(delayed_tasks))

    return '\n'.join(filter(None, output_parts))


def render_review(data: Dict[str, Any]) -> str:
    """渲染复盘数据"""
    review_date = data.get('date', _today_str())
    work_planned = data.get('work_planned', 0)
    work_done = data.get('work_done', 0)
    life_planned = data.get('life_planned', 0)
    life_done = data.get('life_done', 0)
    unplanned_done = data.get('unplanned_done', 0)
    reflection = data.get('reflection', '')

    total_planned = work_planned + life_planned
    total_done = work_done + life_done + unplanned_done

    work_rate = f'{work_done}/{work_planned} ({int(work_done/work_planned*100)}%)' if work_planned > 0 else '—'
    life_rate = f'{life_done}/{life_planned} ({int(life_done/life_planned*100)}%)' if life_planned > 0 else '—'
    total_rate = f'{total_done - unplanned_done}/{total_planned} + {unplanned_done}计划外'

    lines: List[str] = [
        f'## 📊 {review_date} 复盘统计',
        '',
        '| 维度 | 计划 | 完成 | 完成率 |',
        '|------|------|------|--------|',
        f'| 💼 工作 | {work_planned} | {work_done} | {work_rate} |',
        f'| 🏠 生活 | {life_planned} | {life_done} | {life_rate} |',
        f'| 📌 计划外 | — | {unplanned_done} | — |',
        '',
    ]

    # 渲染项目完成情况
    projects: List[Dict[str, Any]] = data.get('projects', [])
    if projects:
        lines.append('### 📋 任务完成详情')
        global_seq = [1]
        work_groups = [g for g in projects if g.get('area') == 'work']
        life_groups = [g for g in projects if g.get('area') == 'life']
        if work_groups:
            lines.append(f'\n**{AREA_DISPLAY["work"]}**\n')
            lines.append(render_task_table(work_groups, global_seq))
        if life_groups:
            lines.append(f'\n**{AREA_DISPLAY["life"]}**\n')
            lines.append(render_task_table(life_groups, global_seq))

    # 习惯
    habits: List[Dict[str, Any]] = data.get('habits', [])
    if habits:
        habit_rendered, _ = render_habit_table(habits)  # render_review 不需要续接序号
        lines.append(habit_rendered)

    # 反思
    if reflection:
        lines.append('### 💬 今日收获与反思')
        lines.append('')
        lines.append(reflection)
        lines.append('')

    return '\n'.join(lines)


# ============================================================
# CLI 入口
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro 表格渲染脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument('--input', '-i', help='输入 JSON 文件路径（不指定则从 stdin 读取）')
    parser.add_argument('--format', '-f', choices=['md', 'plain'], default='md',
                        help='输出格式：md（默认，Markdown 表格）/ plain（纯文本，企微 Bot / 移动端场景）')
    parser.add_argument('--no-candidate', action='store_true',
                        help='不输出候选池（仅展示已激活任务）')
    parser.add_argument(
        '--mode', '-m',
        choices=['daily-plan', 'review', 'auto'],
        default='auto',
        help='渲染模式：daily-plan（今日计划）/ review（复盘）/ auto（自动检测，默认）',
    )
    args = parser.parse_args()

    # 读取 JSON
    if args.input:
        try:
            with open(args.input, 'r', encoding='utf-8') as f:
                raw = f.read()
        except FileNotFoundError:
            print(f'❌ 文件不存在：{args.input}', file=sys.stderr)
            sys.exit(1)
    else:
        raw = sys.stdin.read()

    if not raw.strip():
        print('❌ 输入为空', file=sys.stderr)
        sys.exit(1)

    # 解析 JSON（过滤 build_plan.py 附加的 TASK_SEQ_MAP 注释行）
    try:
        # 将注释行过滤掉后再解析（<!-- ... --> 不是有效 JSON）
        clean_lines = [line for line in raw.splitlines()
                       if not line.strip().startswith('<!--')]
        clean_raw = '\n'.join(clean_lines)
        data = json.loads(clean_raw)
    except json.JSONDecodeError as e:
        print(f'❌ JSON 解析失败：{e}', file=sys.stderr)
        sys.exit(1)

    # 自动检测模式
    mode = args.mode
    if mode == 'auto':
        # 有 projects + habits → daily-plan；有 reflection/work_planned → review
        if 'work_planned' in data or 'reflection' in data:
            mode = 'review'
        else:
            mode = 'daily-plan'

    # 渲染
    fmt = getattr(args, 'format', 'md')
    if mode == 'daily-plan':
        result = render_daily_plan(data, fmt=fmt)
    elif mode == 'review':
        result = render_review(data)
    else:
        result = render_daily_plan(data, no_candidate=getattr(args, 'no_candidate', False), fmt=fmt)

    # v3.0.1: 根据 mode 追加引导语
    if mode == 'daily-plan':
        result = result + '\n---\n以上是待安排事项，请确认处理方式。'
    elif mode == 'review':
        result = result + '\n---\n以上是复盘数据，有没有需要调整的？'

    # 统计任务总数（用于 RENDER_CHECK）
    task_count = sum(len(g.get('tasks', [])) for g in data.get('projects', []))
    task_count += len(data.get('habits', []))
    render_check = f'<!-- RENDER_CHECK: tasks={task_count} -->'

    # TASK_SEQ_MAP 注释
    seq_map = data.get('seq_map')
    seq_map_comment = ''
    if seq_map:
        plan_date = data.get('date', _today_str())
        plan_mode = data.get('mode', 'plan')
        session_id = f'{plan_mode}-plan-{plan_date}'
        import json as _json
        seq_map_comment = f'\n<!-- TASK_SEQ_MAP session={session_id} map={_json.dumps(seq_map, ensure_ascii=False)} -->'

    # v3.0：直接输出到 stdout
    print(result)
    if seq_map_comment:
        print(seq_map_comment)
    print(render_check)


# ============================================================
# 内嵌测试（直接运行时触发）
# ============================================================

def _self_test() -> None:
    """用一个手写的 DailyPlan JSON 测试输出格式"""
    sample = {
        "date": "2026-04-03",
        "projects": [
            {
                "name": "P-播客项目",
                "area": "work",
                "tasks": [
                    {
                        "id": "T-20260403-a3f91c",
                        "title": "后台/浮窗播放技术方案确认",
                        "priority": "urgent",
                        "area": "work",
                        "project": "P-播客项目",
                        "ddl": "2026-04-02",
                        "status": "active",
                        "note": "逾期1天",
                        "overdue_days": 1,
                        "delayed": False,
                    },
                    {
                        "id": "T-20260403-b7d820",
                        "title": "播客规划输出和沟通",
                        "priority": "high",
                        "area": "work",
                        "project": "P-播客项目",
                        "status": "active",
                        "note": "",
                    },
                    {
                        "id": "T-20260403-c1e2f3",
                        "title": "播客移动端字号调整",
                        "priority": "waiting",
                        "area": "work",
                        "project": "P-播客项目",
                        "ddl": "2026-04-07",
                        "status": "active",
                        "note": "等前端",
                    },
                ]
            },
            {
                "name": "无项目任务",
                "area": "life",
                "tasks": [
                    {
                        "id": "T-20260403-d4f5a6",
                        "title": "去超市买牛奶",
                        "priority": "normal",
                        "area": "life",
                        "status": "inbox",
                        "note": "",
                    },
                ]
            }
        ],
        "habits": [
            {"name": "晨间跑步", "time": "07:30", "status": "done"},
            {"name": "冥想练习", "time": "21:00", "status": "pending"},
        ],
        "candidate_pool": [
            {
                "id": "T-20260401-pool01",
                "title": "整理播客用户反馈文档",
                "priority": "normal",
                "area": "work",
                "status": "inbox",
                "note": "上周遗留",
            }
        ],
        "ddl_warnings": [
            {"task_id": "T-20260403-test01", "title": "知识卡数据初始化", "ddl": "2026-04-03", "days_remaining": 0},
            {"task_id": "T-20260403-a3f91c", "title": "后台技术方案确认", "ddl": "2026-04-02", "days_remaining": -1},
        ],
        "delayed_tasks": [
            {
                "id": "T-20260403-a3f91c",
                "title": "后台/浮窗播放技术方案确认",
                "priority": "urgent",
                "area": "work",
                "status": "active",
                "delayed": True,
            }
        ]
    }

    print("=" * 60)
    print("【render_table.py 自测 - daily-plan 模式】")
    print("=" * 60)
    result = render_daily_plan(sample)
    print(result)

    # 复盘模式
    review_sample = {
        "date": "2026-04-03",
        "projects": [
            {
                "name": "P-播客项目",
                "area": "work",
                "tasks": [
                    {
                        "id": "T-20260403-a3f91c",
                        "title": "后台/浮窗播放技术方案确认",
                        "priority": "urgent",
                        "area": "work",
                        "status": "done",
                        "note": "完成！",
                    }
                ]
            }
        ],
        "habits": [
            {"name": "晨间跑步", "time": "07:30", "status": "done"},
            {"name": "冥想练习", "time": "21:00", "status": "done"},
        ],
        "work_planned": 3,
        "work_done": 2,
        "life_planned": 1,
        "life_done": 1,
        "unplanned_done": 1,
        "reflection": "今日完成了核心技术方案讨论。今天天气不错，散步30分钟。",
    }

    print("\n" + "=" * 60)
    print("【render_table.py 自测 - review 模式】")
    print("=" * 60)
    result_review = render_review(review_sample)
    print(result_review)


if __name__ == '__main__':
    # 如果有参数则走 CLI，否则运行自测
    if len(sys.argv) > 1:
        main()
    else:
        _self_test()
