#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
create_habit_instance.py - LifeOps Pro 习惯实例创建脚本
版本：Phase 3
Python：3.9.6（使用 Optional[X]、List[X]、Dict[K,V]，从 typing 导入）

功能：
  1. 按习惯定义的 frequency 规则判断今天是否需要创建习惯实例
  2. 写入 SQLite（habit_instances 表）
  3. 创建对应的 Inbox Markdown 文件

频率规则：
  daily       每天
  weekday     周一至周五
  weekend     周六、周日
  mon,wed,fri 逗号分隔的星期缩写（支持 mon/tue/wed/thu/fri/sat/sun）

数据来源（优先级）：
  CLI 参数 --name --frequency --days（直接指定单个习惯）
  > LIFEOPS_DB_PATH 环境变量（测试注入临时 DB）
  > config.json db_path（生产 DB）
  > config.json habits_file（Markdown 文件解析，写入 DB 后缓存）

DB 表（兼容测试注入的简化结构）：
  habit_instances (
    id TEXT PK,
    habit_name TEXT,      -- 简化模式：直接存名称
    date TEXT,
    status TEXT DEFAULT 'pending',
    created_at TEXT,
    UNIQUE(habit_name, date)
  )

用法：
  # 为今日创建习惯实例（从 habits.md / DB 读取清单）
  python create_habit_instance.py --date 2026-04-03

  # 直接指定单个习惯（测试/脚本调用友好）
  python create_habit_instance.py --name 晨间跑步 --frequency weekly --days mon,wed,fri --date 2026-04-03

  # 预览（不实际写入）
  python create_habit_instance.py --date 2026-04-03 --dry-run

  # 列出今日习惯（不创建）
  python create_habit_instance.py --list --date 2026-04-03
"""

from __future__ import annotations

import argparse
import json
import os
import random
import re
import sqlite3
import sys
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


# ============================================================
# 星期映射
# ============================================================

# 星期英文缩写 → Python weekday() 值（0=Mon … 6=Sun）
WEEKDAY_MAP: Dict[str, int] = {
    'mon': 0, 'tue': 1, 'wed': 2, 'thu': 3,
    'fri': 4, 'sat': 5, 'sun': 6,
}

# 中文星期 → Python weekday() 值
WEEKDAY_ZH_MAP: Dict[str, int] = {
    '周一': 0, '星期一': 0,
    '周二': 1, '星期二': 1,
    '周三': 2, '星期三': 2,
    '周四': 3, '星期四': 3,
    '周五': 4, '星期五': 4,
    '周六': 5, '星期六': 5,
    '周日': 6, '周天': 6, '星期日': 6, '星期天': 6,
}

WEEKDAY_ZH: Dict[int, str] = {
    0: '星期一', 1: '星期二', 2: '星期三', 3: '星期四',
    4: '星期五', 5: '星期六', 6: '星期日',
}


# ============================================================
# 配置加载
# ============================================================

def load_config() -> dict:
    """加载 rocky-todo-list-buddy 配置文件"""
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config['db_path'] = str(Path(config['db_path']).expanduser())
    return config


def get_db_path(config: Optional[dict] = None) -> str:
    """
    获取数据库路径。
    优先级：LIFEOPS_DB_PATH 环境变量 > config['db_path']
    """
    env_path = os.environ.get('LIFEOPS_DB_PATH', '')
    if env_path:
        return env_path
    if config:
        return config['db_path']
    # 兜底：尝试加载配置
    try:
        cfg = load_config()
        return cfg['db_path']
    except Exception:
        raise RuntimeError('无法确定数据库路径，请设置 LIFEOPS_DB_PATH 环境变量或确保 config.json 存在')


# ============================================================
# 习惯定义数据结构
# ============================================================

class HabitDef:
    """习惯定义"""
    __slots__ = ('name', 'frequency', 'days', 'time', 'area', 'priority', 'note')

    def __init__(
        self,
        name: str,
        frequency: str,
        days: Optional[List[int]] = None,
        time: str = '',
        area: str = 'life',
        priority: str = 'normal',
        note: str = '',
    ) -> None:
        self.name = name
        self.frequency = frequency      # daily / weekday / weekend / custom
        self.days = days or []          # 自定义星期列表（weekday 数值 0-6）
        self.time = time
        self.area = area
        self.priority = priority
        self.note = note

    def should_run_on(self, target_date: date) -> bool:
        """判断该习惯是否应在 target_date 执行"""
        wd = target_date.weekday()  # 0=Mon … 6=Sun
        freq = self.frequency.lower().strip()

        if freq == 'daily' or freq == '每天':
            return True
        if freq in ('weekday', 'weekdays', '工作日'):
            return wd <= 4
        if freq in ('weekend', 'weekends', '周末'):
            return wd >= 5
        if self.days:
            return wd in self.days
        # 兜底：视为 daily
        return True

    def __repr__(self) -> str:
        return f'HabitDef(name={self.name!r}, frequency={self.frequency!r}, days={self.days})'


# ============================================================
# 频率解析
# ============================================================

def parse_frequency(freq_str: str, days_str: Optional[str] = None) -> Tuple[str, List[int]]:
    """
    解析频率字符串，返回 (normalized_frequency, weekday_list)。

    支持格式：
      daily / 每天
      weekday / 工作日
      weekend / 周末
      mon,wed,fri（英文缩写，逗号分隔）
      周三,周五,周六（中文，逗号分隔）

    days_str：CLI --days 参数（若提供则覆盖 freq_str 中的星期信息）
    """
    freq = freq_str.strip().lower()

    # 若有 --days 参数，优先用它
    if days_str:
        days = _parse_days_str(days_str)
        return 'custom', days

    # daily
    if freq in ('daily', '每天'):
        return 'daily', []

    # weekday
    if freq in ('weekday', 'weekdays', '工作日'):
        return 'weekday', []

    # weekend
    if freq in ('weekend', 'weekends', '周末'):
        return 'weekend', []

    # 尝试解析为逗号分隔的星期
    days = _parse_days_str(freq_str)
    if days:
        return 'custom', days

    # 未能识别：默认 daily
    return 'daily', []


def _parse_days_str(days_str: str) -> List[int]:
    """
    将逗号分隔的星期字符串解析为 weekday 数值列表。
    支持英文缩写（mon/tue/wed/thu/fri/sat/sun）和中文（周一/周二/.../周日）。
    """
    result: List[int] = []
    parts = [p.strip() for p in days_str.replace('，', ',').split(',') if p.strip()]
    for part in parts:
        low = part.lower()
        if low in WEEKDAY_MAP:
            result.append(WEEKDAY_MAP[low])
        elif part in WEEKDAY_ZH_MAP:
            result.append(WEEKDAY_ZH_MAP[part])
        else:
            # 尝试 "周X" 形式（X 为数字）
            m = re.match(r'^周([一二三四五六日天])$', part)
            if m:
                zh_key = '周' + m.group(1)
                if zh_key in WEEKDAY_ZH_MAP:
                    result.append(WEEKDAY_ZH_MAP[zh_key])
    return list(dict.fromkeys(result))  # 去重保序


# ============================================================
# habits.md 解析
# ============================================================

def parse_habits_md(filepath: str) -> List[HabitDef]:
    """
    解析 habits.md 中的「活跃习惯」表格，返回 HabitDef 列表。
    跳过「挂起习惯」（暂停状态）。
    """
    path = Path(filepath)
    if not path.exists():
        return []

    content = path.read_text(encoding='utf-8')
    habits: List[HabitDef] = []

    # 只解析「活跃习惯」区块
    active_section = ''
    in_active = False
    for line in content.split('\n'):
        if re.match(r'^##\s+活跃习惯', line):
            in_active = True
            continue
        if re.match(r'^##\s+', line) and in_active:
            in_active = False
        if in_active:
            active_section += line + '\n'

    if not active_section:
        return []

    # 解析 Markdown 表格行（跳过标题行和分隔行）
    for line in active_section.split('\n'):
        line = line.strip()
        if not line.startswith('|') or line.startswith('| ---') or line.startswith('|---'):
            continue
        cells = [c.strip() for c in line.strip('|').split('|')]
        if len(cells) < 2:
            continue
        # 跳过表头行（第一格为中文字段名）
        if cells[0] in ('习惯名称', '# ', '#'):
            continue

        name = cells[0]
        if not name:
            continue

        freq_raw = cells[1] if len(cells) > 1 else '每天'
        time_str = cells[2] if len(cells) > 2 else ''
        area     = cells[3] if len(cells) > 3 else 'life'
        # 频率为「暂停」时跳过
        if freq_raw.strip() in ('暂停', 'pause', 'paused'):
            continue

        norm_freq, days = parse_frequency(freq_raw)
        habits.append(HabitDef(
            name=name,
            frequency=norm_freq,
            days=days,
            time=time_str.strip(),
            area=area.strip() if area.strip() in ('work', 'life') else 'life',
        ))

    return habits


# ============================================================
# SQLite 操作
# ============================================================

def _get_conn(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    return conn


def _load_habits_from_db(db_path: str) -> List[HabitDef]:
    """从 DB habit_definitions 表加载活跃习惯定义（v3.0：DB 优先）"""
    conn = _get_conn(db_path)
    try:
        rows = conn.execute(
            'SELECT name, frequency, execution_days, area, priority '
            'FROM habit_definitions WHERE is_active = 1'
        ).fetchall()
    except Exception:
        return []
    finally:
        conn.close()

    habits: List[HabitDef] = []
    for row in rows:
        name = row['name']
        freq_raw = row['frequency'] or 'daily'
        exec_days_raw = row['execution_days'] or '[]'
        area = row['area'] or 'life'
        priority = row['priority'] or 'normal'

        # execution_days 是 JSON 数组字符串 '[2,4,5]'
        import json as _json
        try:
            exec_days = _json.loads(exec_days_raw)
        except (json.JSONDecodeError, TypeError):
            exec_days = []

        # 将 execution_days 列表转换为 days set
        days_set = frozenset(exec_days) if exec_days else frozenset()

        # 对 custom frequency，如果有 execution_days 则用
        if freq_raw == 'custom' and days_set:
            norm_freq = 'custom'
            days = days_set
        else:
            norm_freq, days = parse_frequency(freq_raw, None)

        habits.append(HabitDef(
            name=name,
            frequency=norm_freq,
            days=days,
            area=area,
            priority=priority,
        ))
    return habits


def _ensure_habit_instances_table(conn: sqlite3.Connection) -> None:
    """
    确保 habit_instances 表存在（兼容测试注入的简化结构）。
    若已存在，检测列结构决定使用哪种模式。
    """
    conn.execute('''
        CREATE TABLE IF NOT EXISTS habit_instances (
            id          TEXT NOT NULL PRIMARY KEY,
            habit_name  TEXT NOT NULL,
            date        TEXT NOT NULL,
            status      TEXT NOT NULL DEFAULT 'pending',
            created_at  TEXT NOT NULL,
            UNIQUE(habit_name, date)
        )
    ''')
    conn.commit()


def _detect_table_mode(conn: sqlite3.Connection) -> str:
    """
    检测 habit_instances 表的列结构，返回模式：
    'simple'：包含 habit_name 列（测试模式 / 简化模式）
    'full'  ：包含 habit_id 列（生产完整模式）
    """
    try:
        info = conn.execute("PRAGMA table_info(habit_instances)").fetchall()
        cols = {row[1] for row in info}  # row[1] = column name
        if 'habit_name' in cols:
            return 'simple'
        elif 'habit_id' in cols:
            return 'full'
        else:
            return 'simple'
    except Exception:
        return 'simple'


def _generate_instance_id() -> str:
    """生成习惯实例 ID：HI-{YYYYMMDD}-{6位随机hex}"""
    today = date.today().strftime('%Y%m%d')
    hex_part = ''.join(random.choices('0123456789abcdef', k=6))
    return f'HI-{today}-{hex_part}'


def create_instance_in_db(
    conn: sqlite3.Connection,
    habit: HabitDef,
    target_date: str,
    mode: str = 'simple',
) -> Optional[str]:
    """
    在 DB 中创建习惯实例（幂等：UNIQUE 约束保证同天同习惯只创建一次）。
    返回创建的实例 ID，若已存在则返回 None。
    """
    instance_id = _generate_instance_id()
    now = datetime.now().isoformat()

    try:
        if mode == 'simple':
            conn.execute(
                '''INSERT INTO habit_instances (id, habit_name, date, status, created_at)
                   VALUES (?, ?, ?, 'pending', ?)''',
                (instance_id, habit.name, target_date, now)
            )
        else:
            # 生产模式：需要 habit_id（从 habit_definitions 找）
            row = conn.execute(
                "SELECT id FROM habit_definitions WHERE name = ? AND is_active = 1",
                (habit.name,)
            ).fetchone()
            if row is None:
                # 自动创建 habit_definitions 记录
                habit_def_id = f'HD-{habit.name[:20]}'
                try:
                    conn.execute(
                        '''INSERT OR IGNORE INTO habit_definitions
                           (id, name, area, frequency, priority)
                           VALUES (?, ?, ?, ?, ?)''',
                        (habit_def_id, habit.name, habit.area, habit.frequency, habit.priority)
                    )
                except Exception:
                    pass
                habit_id = habit_def_id
            else:
                habit_id = row[0]

            conn.execute(
                '''INSERT INTO habit_instances (id, habit_id, date, status)
                   VALUES (?, ?, ?, 'pending')''',
                (instance_id, habit_id, target_date)
            )
        conn.commit()
        return instance_id
    except sqlite3.IntegrityError:
        # UNIQUE 约束触发：已存在
        conn.rollback()
        return None


# ============================================================
# Inbox Markdown 创建
# ============================================================

def create_inbox_md(
    config: dict,
    habit: HabitDef,
    target_date: str,
    instance_id: str,
) -> Optional[str]:
    """
    为习惯实例创建 Inbox Markdown 文件。
    文件名格式：{date}-habit-{safe_name}.md
    幂等：文件已存在则跳过。
    返回创建的文件路径，已存在返回 None。
    """
    inbox_path = Path(config.get('inbox_path', ''))
    if not inbox_path.exists():
        return None

    safe_name = re.sub(r'[^\w\u4e00-\u9fff-]', '', habit.name)
    filename = f'{target_date}-habit-{safe_name}.md'
    file_path = inbox_path / filename

    if file_path.exists():
        return None

    time_line = f'  schedule: "{habit.time}"\n' if habit.time else ''
    content = (
        f'---\n'
        f'id: {instance_id}\n'
        f'title: {habit.name}\n'
        f'tags:\n'
        f'  - "#inbox"\n'
        f'  - "#life"\n'
        f'  - "#habit"\n'
        f'area: {habit.area}\n'
        f'priority: {habit.priority}\n'
        f'created: "{target_date}"\n'
        f'{time_line}'
        f'habit: true\n'
        f'---\n'
        f'\n'
        f'# {habit.name}\n'
        f'\n'
        f'> 习惯任务 · {target_date} · 频率：{habit.frequency}\n'
    )

    try:
        file_path.write_text(content, encoding='utf-8')
        return str(file_path)
    except Exception as e:
        print(f'[WARN] 创建 Inbox 文件失败：{e}', file=sys.stderr)
        return None


# ============================================================
# 主逻辑
# ============================================================

def process_single_habit(
    habit: HabitDef,
    target_date: str,
    db_path: str,
    config: Optional[dict],
    dry_run: bool = False,
) -> Dict[str, Any]:
    """
    处理单个习惯：判断是否需要创建 → 写入 DB → 创建 Inbox 文件。
    返回结果字典 {name, should_run, created, instance_id, md_file, reason}。
    """
    d = date.fromisoformat(target_date)
    should_run = habit.should_run_on(d)
    weekday_str = WEEKDAY_ZH.get(d.weekday(), '')

    if not should_run:
        # 构建未执行原因
        if habit.frequency == 'weekday':
            reason = '仅工作日'
        elif habit.frequency == 'weekend':
            reason = '仅周末'
        elif habit.days:
            day_names = [WEEKDAY_ZH.get(w, str(w)) for w in sorted(habit.days)]
            reason = '、'.join(day_names)
        else:
            reason = habit.frequency
        return {
            'name': habit.name,
            'should_run': False,
            'created': False,
            'instance_id': None,
            'md_file': None,
            'reason': reason,
        }

    if dry_run:
        return {
            'name': habit.name,
            'should_run': True,
            'created': False,
            'instance_id': None,
            'md_file': None,
            'reason': 'dry-run',
        }

    # 写入 DB
    conn = _get_conn(db_path)
    try:
        _ensure_habit_instances_table(conn)
        mode = _detect_table_mode(conn)
        instance_id = create_instance_in_db(conn, habit, target_date, mode=mode)
    finally:
        conn.close()

    if instance_id is None:
        return {
            'name': habit.name,
            'should_run': True,
            'created': False,
            'instance_id': None,
            'md_file': None,
            'reason': '已存在（幂等跳过）',
        }

    # v3.0：不再创建 Inbox Markdown 文件，习惯实例只写 DB

    return {
        'name': habit.name,
        'should_run': True,
        'created': True,
        'instance_id': instance_id,
        'md_file': None,
        'reason': '',
    }


def run_for_date(
    target_date: str,
    habits: List[HabitDef],
    db_path: str,
    config: Optional[dict],
    dry_run: bool = False,
    list_only: bool = False,
) -> List[Dict[str, Any]]:
    """
    对给定日期和习惯列表执行批量处理，返回结果列表。
    """
    results = []
    d = date.fromisoformat(target_date)
    weekday_str = WEEKDAY_ZH.get(d.weekday(), '')

    for habit in habits:
        if list_only:
            should_run = habit.should_run_on(d)
            results.append({
                'name': habit.name,
                'should_run': should_run,
                'created': False,
                'instance_id': None,
                'md_file': None,
                'reason': 'list-only',
            })
        else:
            result = process_single_habit(habit, target_date, db_path, config, dry_run=dry_run)
            results.append(result)

    return results


def print_results(results: List[Dict[str, Any]], target_date: str) -> None:
    """格式化输出结果"""
    d = date.fromisoformat(target_date)
    weekday_str = WEEKDAY_ZH.get(d.weekday(), '')

    for r in results:
        name = r['name']
        if r.get('reason') == 'list-only':
            mark = '✅' if r['should_run'] else '⏭️ '
            note = '今天执行' if r['should_run'] else f'今天不是执行日'
            print(f'{mark} {name} → {note}')
        elif not r['should_run']:
            print(f'⏭️  {name} → 今天不是执行日（{r["reason"]}）')
        elif r.get('reason') == 'dry-run':
            print(f'🔍 [DRY-RUN] {name} → 将创建（{target_date}，{weekday_str}）')
        elif r['created']:
            md_note = f'，Inbox: {Path(r["md_file"]).name}' if r.get('md_file') else ''
            print(f'✅ {name} → 已创建（{target_date}，{weekday_str}）{md_note}')
        else:
            print(f'⏭️  {name} → {r.get("reason", "已跳过")}')


# ============================================================
# CLI 入口
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro - 习惯实例创建脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument(
        '--date',
        default=date.today().isoformat(),
        help='目标日期 YYYY-MM-DD（默认今天）',
    )
    parser.add_argument('--dry-run', action='store_true', help='预览，不实际写入')
    parser.add_argument('--list', action='store_true', help='仅列出今日应执行的习惯，不创建实例')

    # 直接指定单个习惯（测试/脚本调用友好）
    parser.add_argument('--name', help='习惯名称（指定时只处理此习惯）')
    parser.add_argument(
        '--frequency',
        default='daily',
        help='频率：daily / weekday / weekend / weekly（--days 搭配使用）',
    )
    parser.add_argument(
        '--days',
        help='执行日（逗号分隔的英文缩写，如 mon,wed,fri）',
    )

    args = parser.parse_args()

    # 加载配置（允许失败，降级到纯 DB 模式）
    config: Optional[dict] = None
    try:
        config = load_config()
    except Exception:
        pass

    db_path = get_db_path(config)

    # 构建习惯列表（v3.0：DB 优先，habits.md 作为 fallback）
    if args.name:
        # 直接指定单个习惯
        norm_freq, days = parse_frequency(args.frequency, args.days)
        habits = [HabitDef(name=args.name, frequency=norm_freq, days=days)]
    else:
        # 优先从 DB habit_definitions 表读取
        habits = _load_habits_from_db(db_path)
        if not habits and config and config.get('habits_file'):
            # DB 无数据时 fallback 到 habits.md
            habits = parse_habits_md(config['habits_file'])
            if habits:
                print(f'[INFO] 从 habits.md 加载了 {len(habits)} 个习惯定义（DB 为空，fallback）', file=sys.stderr)
        if not habits:
            print('[WARN] 无活跃习惯定义（DB 和 habits.md 均为空），退出', file=sys.stderr)
            sys.exit(0)

    results = run_for_date(
        target_date=args.date,
        habits=habits,
        db_path=db_path,
        config=config,
        dry_run=args.dry_run,
        list_only=args.list,
    )

    print_results(results, args.date)


# ============================================================
# 内嵌自测
# ============================================================

def _self_test() -> None:
    """验证频率解析和习惯执行日判断逻辑"""
    import tempfile
    import shutil

    print('【create_habit_instance.py 自测】')

    # 1. 频率解析
    freq, days = parse_frequency('daily')
    assert freq == 'daily' and days == [], f'daily 解析错误: {freq}, {days}'

    freq, days = parse_frequency('weekday')
    assert freq == 'weekday' and days == [], f'weekday 解析错误'

    freq, days = parse_frequency('每天')
    assert freq == 'daily', f'中文每天解析错误: {freq}'

    freq, days = parse_frequency('mon,wed,fri')
    assert freq == 'custom' and sorted(days) == [0, 2, 4], f'mon,wed,fri 解析错误: {days}'

    freq, days = parse_frequency('weekly', days_str='mon,wed,fri')
    assert freq == 'custom' and sorted(days) == [0, 2, 4], f'--days 覆盖解析错误: {days}'

    freq, days = parse_frequency('周三,周五,周六')
    assert freq == 'custom' and sorted(days) == [2, 4, 5], f'中文周几解析错误: {days}'
    print('✅ 频率解析：全部通过')

    # 2. 执行日判断
    # 2026-04-03 = 星期五（weekday=4）
    d_fri = date(2026, 4, 3)
    # 2026-04-05 = 星期日（weekday=6）
    d_sun = date(2026, 4, 5)

    h_daily  = HabitDef('冥想练习',  'daily',   [])
    h_weekday = HabitDef('工作冥想', 'weekday', [])
    h_weekend = HabitDef('周末跑步', 'weekend', [])
    h_custom  = HabitDef('晨间跑步',   'custom',  [2, 4, 5])  # 周三、五、六

    assert h_daily.should_run_on(d_fri),  'daily 周五应执行'
    assert h_daily.should_run_on(d_sun),  'daily 周日应执行'
    assert h_weekday.should_run_on(d_fri),  'weekday 周五应执行'
    assert not h_weekday.should_run_on(d_sun), 'weekday 周日不执行'
    assert not h_weekend.should_run_on(d_fri), 'weekend 周五不执行'
    assert h_weekend.should_run_on(d_sun),  'weekend 周日应执行'
    assert h_custom.should_run_on(d_fri),  'custom(wed,fri,sat) 周五应执行'
    assert not h_custom.should_run_on(d_sun), 'custom(wed,fri,sat) 周日不执行'
    print('✅ 执行日判断：全部通过')

    # 3. DB 写入测试（使用临时 DB）
    tmpdir = Path(tempfile.mkdtemp())
    test_db = str(tmpdir / 'test.db')
    os.environ['LIFEOPS_DB_PATH'] = test_db

    conn = _get_conn(test_db)
    _ensure_habit_instances_table(conn)
    mode = _detect_table_mode(conn)
    conn.close()
    assert mode == 'simple', f'临时 DB 应为 simple 模式，实际：{mode}'

    # 创建实例
    conn = _get_conn(test_db)
    _ensure_habit_instances_table(conn)
    result1 = create_instance_in_db(conn, h_daily, '2026-04-03', mode='simple')
    conn.close()
    assert result1 is not None, '第一次创建应返回 instance_id'
    print(f'✅ DB 写入：instance_id = {result1}')

    # 幂等测试
    conn = _get_conn(test_db)
    _ensure_habit_instances_table(conn)
    result2 = create_instance_in_db(conn, h_daily, '2026-04-03', mode='simple')
    conn.close()
    assert result2 is None, '重复创建应返回 None（幂等）'
    print('✅ 幂等性：重复创建返回 None')

    # 4. 完整流程测试
    results = run_for_date(
        target_date='2026-04-03',  # 周五
        habits=[h_daily, h_weekday, h_weekend, h_custom],
        db_path=test_db,
        config=None,
        dry_run=False,
    )
    assert len(results) == 4
    # daily 周五 → 创建（但 h_daily 上面已创建过，幂等跳过）
    assert results[0]['should_run'] is True
    # weekday 周五 → 创建
    assert results[1]['should_run'] is True and results[1]['created'] is True
    # weekend 周五 → 不执行
    assert results[2]['should_run'] is False
    # custom(wed,fri,sat) 周五 → 创建
    assert results[3]['should_run'] is True and results[3]['created'] is True
    print('✅ 完整流程：4 个习惯判断正确')

    print_results(results, '2026-04-03')

    # 清理
    del os.environ['LIFEOPS_DB_PATH']
    shutil.rmtree(tmpdir)
    print('\n🎉 所有自测通过！')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        main()
    else:
        _self_test()
