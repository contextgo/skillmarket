"""
schemas.py - LifeOps Pro Pydantic 数据模型
版本：Phase 1 → v2.0
Python：3.9.6（使用 Optional[X] 而非 X | Y 联合类型）
"""
from __future__ import annotations

import sys
from typing import List, Optional, Literal, Dict

# 兼容 pydantic v1 和 v2
try:
    from pydantic import BaseModel, Field
    import pydantic
    PYDANTIC_V2 = int(pydantic.VERSION.split('.')[0]) >= 2
except ImportError:
    raise RuntimeError("请先安装 pydantic：pip3 install pydantic")

# ============================================================
# 枚举值规范（英文，渲染层映射到 emoji）
# ============================================================

PRIORITY_DISPLAY = {
    'urgent':  '🔴',
    'high':    '🟡',
    'normal':  '🟢',
    'waiting': '⏳',
}

AREA_DISPLAY = {
    'work': '💼 工作',
    'life': '🏠 生活',
}

STATUS_DISPLAY = {
    'inbox':     '📥 待安排',
    'active':    '🔄 进行中',
    'done':      '✅ 完成',
    'cancelled': '❌ 取消',
    'someday':   '📦 搁置',
}

# ============================================================
# 数据模型
# ============================================================

class Task(BaseModel):
    """单个任务"""
    id: str                                   # 文件名（如 2026-04-03-xxx.md）或任务 ID
    title: str
    priority: Literal['urgent', 'high', 'normal', 'waiting']
    # ⚠️ waiting priority = ⏳ 等待他人（非任务状态），v2.4.0 规范
    area: Optional[Literal['work', 'life']] = None
    project: Optional[str] = None             # 项目名称，如 P-播客项目
    schedule: Optional[str] = None            # YYYY-MM-DD
    ddl: Optional[str] = None                 # YYYY-MM-DD
    status: Literal['inbox', 'active', 'done', 'cancelled', 'someday']
    # ⚠️ status 无 'waiting' 值（v2.4.0 废弃），等待用 priority='waiting' 表示
    note: str = ''
    overdue_days: Optional[int] = None        # DDL 已逾期的天数（负数=逾期）
    delayed: bool = False                     # 是否从上一日顺延
    time_slot: Optional[str] = None           # 用户指定的执行时间（如「上午」「15:00」「下午」）


class ProjectGroup(BaseModel):
    """项目分组（一个项目下的任务列表）"""
    name: str                                 # "P-播客项目" 或 "📌 日常任务"
    area: Literal['work', 'life']
    tasks: List[Task]


class Habit(BaseModel):
    """习惯任务"""
    name: str
    time: str                                 # "07:30"
    status: Literal['done', 'pending', 'cancelled']


class DDLWarning(BaseModel):
    """DDL 临近提醒"""
    task_id: str
    title: str
    ddl: str                                  # YYYY-MM-DD
    days_remaining: int                       # 负数表示已逾期


class DailyPlan(BaseModel):
    """今日完整计划（晨间规划 / 日间整理输出）"""
    date: str                                 # YYYY-MM-DD
    projects: List[ProjectGroup]
    habits: List[Habit]
    candidate_pool: List[Task] = []
    ddl_warnings: List[DDLWarning] = []
    delayed_tasks: List[Task] = []
    # v2.0 新增字段（可选，向后兼容）
    mode: Optional[Literal['morning', 'midday', 'next-day']] = None
    # seq_map: 序号 → task_id 映射（build_plan.py 自动填充，输出为 TASK_SEQ_MAP 注释供 Agent 上下文内联）
    seq_map: Optional[Dict[str, str]] = None


class ReviewData(BaseModel):
    """复盘输入数据"""
    date: str
    projects: List[ProjectGroup]
    habits: List[Habit]
    work_planned: int = 0
    work_done: int = 0
    life_planned: int = 0
    life_done: int = 0
    unplanned_done: int = 0
    reflection: str = ''                      # 今日收获与反思


# ============================================================
# 自检（直接运行时验证模型可实例化）
# ============================================================

def _self_test() -> None:
    """验证所有 Pydantic 模型可正常实例化"""
    print(f"pydantic 版本：{pydantic.VERSION}")

    # 测试 Task
    t1 = Task(
        id="2026-04-03-test001",
        title="后台/浮窗播放技术方案确认",
        priority="urgent",
        area="work",
        project="P-播客项目",
        ddl="2026-04-02",
        status="active",
        note="逾期1天",
        overdue_days=1,
        delayed=False,
    )
    t2 = Task(
        id="2026-04-03-test002",
        title="播客移动端字号调整",
        priority="waiting",
        area="work",
        project="P-播客项目",
        ddl="2026-04-07",
        status="active",
        note="⏳ 等前端",
    )
    t3 = Task(
        id="2026-04-03-test003",
        title="制定本周运动计划",
        priority="normal",
        area="life",
        status="inbox",
    )

    # 测试 ProjectGroup
    pg_work = ProjectGroup(
        name="P-播客项目",
        area="work",
        tasks=[t1, t2],
    )
    pg_life = ProjectGroup(
        name="📌 日常任务",
        area="life",
        tasks=[t3],
    )

    # 测试 Habit
    h1 = Habit(name="晨间跑步", time="07:30", status="done")
    h2 = Habit(name="冥想练习", time="21:00", status="pending")

    # 测试 DDLWarning
    w1 = DDLWarning(task_id="2026-04-03-test001", title="技术方案确认", ddl="2026-04-02", days_remaining=-1)
    w2 = DDLWarning(task_id="2026-04-03-test999", title="知识卡数据初始化", ddl="2026-04-03", days_remaining=0)

    # 测试 DailyPlan
    plan = DailyPlan(
        date="2026-04-03",
        projects=[pg_work, pg_life],
        habits=[h1, h2],
        candidate_pool=[],
        ddl_warnings=[w1, w2],
        delayed_tasks=[t1],
    )

    # 测试 ReviewData
    review = ReviewData(
        date="2026-04-03",
        projects=[pg_work, pg_life],
        habits=[h1, h2],
        work_planned=3,
        work_done=2,
        life_planned=1,
        life_done=1,
        unplanned_done=1,
        reflection="今日完成了核心技术方案讨论，生活区目标全达成。",
    )

    print("✅ Task 模型：验证通过")
    print("✅ ProjectGroup 模型：验证通过")
    print("✅ Habit 模型：验证通过")
    print("✅ DDLWarning 模型：验证通过")
    print("✅ DailyPlan 模型：验证通过")
    print("✅ ReviewData 模型：验证通过")
    print(f"\n示例 DailyPlan JSON（前 200 字符）：")
    print(plan.model_dump_json(indent=2)[:200] + "...")


if __name__ == '__main__':
    _self_test()
