#!/usr/bin/env python3
"""
query_weekly_review.py — 周复盘数据查询脚本
============================================
输出 render_review.py --mode weekly-round1/round2 所需的 JSON。

Usage:
  python query_weekly_review.py --round 1 --week 2026-W14
  python query_weekly_review.py --round 2 --week 2026-W14
"""
import argparse
import json
import sqlite3
import sys
from datetime import date, timedelta
from pathlib import Path


def get_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    return conn


def week_range(week_key: str):
    """根据 YYYY-WNN 返回 (week_start, week_end) ISO 日期字符串"""
    year, wnum = week_key.split('-W')
    # ISO 周：周一为第一天
    jan4 = date(int(year), 1, 4)
    week_start = jan4 + timedelta(weeks=int(wnum) - 1 - jan4.weekday()//7,
                                  days=-jan4.weekday())
    # 更稳妥：用 Python isocalendar
    d = date.fromisocalendar(int(year), int(wnum), 1)
    week_start = d
    week_end   = d + timedelta(days=6)
    return week_start.isoformat(), week_end.isoformat()


def next_week_range(week_key: str):
    year, wnum = week_key.split('-W')
    d = date.fromisocalendar(int(year), int(wnum), 1)
    nw_start = d + timedelta(weeks=1)
    nw_end   = nw_start + timedelta(days=6)
    # 计算下周的 week_key
    iso = nw_start.isocalendar()
    nw_key = f'{iso[0]}-W{iso[1]:02d}'
    return nw_key, nw_start.isoformat(), nw_end.isoformat()


def build_projects_view(tasks, week_start: str, area: str):
    """按项目分组，返回 {name, done_tasks, undone_tasks} 列表"""
    from collections import defaultdict
    proj_map = defaultdict(lambda: {'done': [], 'undone': []})

    for t in tasks:
        if t['area'] != area:
            continue
        proj_name = t['project_id'] or '无项目任务'
        is_unplanned = (not t['schedule_date']) or (t['schedule_date'] < week_start)
        entry = {
            'id':        t['id'],
            'title':     t['title'],
            'priority':  t['priority'],
            'unplanned': is_unplanned,
        }
        if t['status'] == 'done':
            proj_map[proj_name]['done'].append(entry)
        else:
            proj_map[proj_name]['undone'].append(entry)

    result = []
    for name, v in proj_map.items():
        if v['done'] or v['undone']:
            result.append({
                'name':        name,
                'done_tasks':  v['done'],
                'undone_tasks': v['undone'],
            })
    # 按完成数降序
    result.sort(key=lambda x: len(x['done_tasks']), reverse=True)
    return result


def query_round1(conn: sqlite3.Connection, week_key: str) -> dict:
    """第一轮：本周完成情况"""
    ws, we = week_range(week_key)

    # 本周完成任务（completed_at 在本周）
    done_rows = conn.execute("""
        SELECT id, title, area, priority, project_id, schedule_date, completed_at
        FROM tasks WHERE status='done' AND is_deleted=0
        AND date(completed_at) BETWEEN ? AND ?
        ORDER BY area, project_id, priority DESC
    """, (ws, we)).fetchall()

    # 本周计划但未完成（schedule_date 在本周，status=active）
    undone_rows = conn.execute("""
        SELECT id, title, area, priority, project_id, schedule_date
        FROM tasks WHERE status='active' AND is_deleted=0
        AND schedule_date BETWEEN ? AND ?
        ORDER BY area, project_id, priority DESC
    """, (ws, we)).fetchall()

    # 合并用于项目视图
    all_tasks = []
    for r in done_rows:
        all_tasks.append(dict(r) | {'status': 'done'})
    for r in undone_rows:
        all_tasks.append(dict(r) | {'status': 'active'})

    # 计划数（schedule_date 在本周）
    work_planned = conn.execute("""
        SELECT COUNT(*) as c FROM tasks WHERE is_deleted=0 AND area='work'
        AND schedule_date BETWEEN ? AND ?
    """, (ws, we)).fetchone()['c']
    life_planned = conn.execute("""
        SELECT COUNT(*) as c FROM tasks WHERE is_deleted=0 AND area='life'
        AND schedule_date BETWEEN ? AND ?
    """, (ws, we)).fetchone()['c']

    done_list = [dict(r) | {'status': 'done'} for r in done_rows]
    work_done_list = [t for t in done_list if t['area'] == 'work']
    life_done_list = [t for t in done_list if t['area'] == 'life']
    work_unplanned = len([t for t in work_done_list
                          if not t['schedule_date'] or t['schedule_date'] < ws])
    life_unplanned = len([t for t in life_done_list
                          if not t['schedule_date'] or t['schedule_date'] < ws])

    # 习惯统计（按名称）
    habit_rows = conn.execute("""
        SELECT hd.name, hi.status
        FROM habit_instances hi JOIN habit_definitions hd ON hi.habit_id=hd.id
        WHERE hi.date BETWEEN ? AND ?
        ORDER BY hd.name
    """, (ws, we)).fetchall()
    from collections import defaultdict
    habit_stat: dict = defaultdict(lambda: [0, 0])
    for h in habit_rows:
        habit_stat[h['name']][1] += 1
        if h['status'] == 'done':
            habit_stat[h['name']][0] += 1
    habits = [{'name': n, 'done': v[0], 'total': v[1]}
              for n, v in habit_stat.items()]

    # v3.0.4: 查当月项目目标（周复盘时展示月目标对照）
    from datetime import date as _date
    current_month = _date.fromisoformat(ws).strftime('%Y-%m')
    goal_rows = conn.execute("""
        SELECT project_id, goal FROM project_goals WHERE month = ?
    """, (current_month,)).fetchall()
    monthly_goals = {g['project_id']: g['goal'] for g in goal_rows}

    return {
        'week_key':       week_key,
        'week_range':     f'{ws} ~ {we}',
        'work_planned':   work_planned,
        'work_unplanned': work_unplanned,
        'work_done':      len(work_done_list),
        'life_planned':   life_planned,
        'life_unplanned': life_unplanned,
        'life_done':      len(life_done_list),
        'habits':         habits,
        'work_projects':  build_projects_view(all_tasks, ws, 'work'),
        'life_projects':  build_projects_view(all_tasks, ws, 'life'),
        'monthly_goals':  monthly_goals,
    }


def query_round2(conn: sqlite3.Connection, week_key: str) -> dict:
    """第二轮：下周计划视图"""
    nw_key, nw_start, nw_end = next_week_range(week_key)

    # 下周已安排任务
    scheduled = conn.execute("""
        SELECT id, title, area, priority, project_id, schedule_date, due_date, status
        FROM tasks WHERE status IN ('active','inbox') AND is_deleted=0
        AND schedule_date BETWEEN ? AND ?
        ORDER BY schedule_date, area, priority DESC
    """, (nw_start, nw_end)).fetchall()

    # 候选任务（inbox，无 schedule）
    candidate = conn.execute("""
        SELECT id, title, area, priority, project_id
        FROM tasks WHERE status='inbox' AND is_deleted=0
        AND (schedule_date IS NULL OR schedule_date > ?)
        ORDER BY area, priority DESC
        LIMIT 15
    """, (nw_end,)).fetchall()

    # 过期任务（active，schedule 在本周或更早）
    today = date.today().isoformat()
    overdue = conn.execute("""
        SELECT id, title, area, priority, project_id, schedule_date
        FROM tasks WHERE status='active' AND is_deleted=0
        AND schedule_date < ?
        AND (snooze_until IS NULL OR snooze_until <= ?)
        ORDER BY schedule_date, area
        LIMIT 20
    """, (nw_start, today)).fetchall()

    # 按项目分组下周任务
    from collections import defaultdict
    work_proj: dict = defaultdict(list)
    life_proj: dict = defaultdict(list)
    for t in scheduled:
        entry = {
            'id':            t['id'],
            'title':         t['title'],
            'priority':      t['priority'],
            'schedule_date': t['schedule_date'],
            'due_date':      t['due_date'],
            'status':        t['status'],
        }
        proj = t['project_id'] or '无项目任务'
        if t['area'] == 'work':
            work_proj[proj].append(entry)
        else:
            life_proj[proj].append(entry)

    def proj_list(proj_map: dict) -> list:
        return [{'name': k, 'tasks': v} for k, v in proj_map.items() if v]

    return {
        'next_week_key':   nw_key,
        'next_week_range': f'{nw_start} ~ {nw_end}',
        'work_projects':   proj_list(work_proj),
        'life_projects':   proj_list(life_proj),
        'candidate_pool':  [dict(r) for r in candidate],
        'overdue_tasks':   [dict(r) for r in overdue],
    }


# ============================================================
# 月复盘专用函数
# ============================================================

def month_range(month_key: str):
    """根据 YYYY-MM 返回 (month_start, month_end) ISO 日期字符串"""
    import calendar
    year, mon = int(month_key[:4]), int(month_key[5:7])
    last_day = calendar.monthrange(year, mon)[1]
    start = date(year, mon, 1).isoformat()
    end   = date(year, mon, last_day).isoformat()
    return start, end


def next_month_range(month_key: str):
    """返回 (next_month_key, next_start, next_end)"""
    import calendar
    year, mon = int(month_key[:4]), int(month_key[5:7])
    if mon == 12:
        nm_year, nm_mon = year + 1, 1
    else:
        nm_year, nm_mon = year, mon + 1
    nk = f'{nm_year}-{nm_mon:02d}'
    last_day = calendar.monthrange(nm_year, nm_mon)[1]
    ns = date(nm_year, nm_mon, 1).isoformat()
    ne = date(nm_year, nm_mon, last_day).isoformat()
    return nk, ns, ne


def query_month_round1(conn: sqlite3.Connection, month_key: str) -> dict:
    """月复盘第一轮：按项目维度展示本月进展 + 目标对照（v3.0.4）"""
    ms, me = month_range(month_key)

    # 按项目聚合本月任务统计
    project_stats = conn.execute("""
        SELECT project_id,
               COUNT(*) as total,
               SUM(CASE WHEN status='done' THEN 1 ELSE 0 END) as done_count,
               SUM(CASE WHEN status='active' THEN 1 ELSE 0 END) as active_count
        FROM tasks WHERE is_deleted=0
        AND (
            (status='done' AND date(completed_at) BETWEEN ? AND ?)
            OR (status='active' AND schedule_date BETWEEN ? AND ?)
            OR (status IN ('active','done') AND schedule_date BETWEEN ? AND ?)
        )
        GROUP BY project_id
        ORDER BY project_id
    """, (ms, me, ms, me, ms, me)).fetchall()

    # 查本月已完成的任务列表（用于 AI 提炼关键成果）
    done_tasks = conn.execute("""
        SELECT id, title, area, priority, project_id, completed_at
        FROM tasks WHERE status='done' AND is_deleted=0
        AND date(completed_at) BETWEEN ? AND ?
        ORDER BY project_id, completed_at
    """, (ms, me)).fetchall()

    # 查本月 project_goals
    goals = conn.execute("""
        SELECT project_id, goal, actual_summary
        FROM project_goals WHERE month = ?
    """, (month_key,)).fetchall()
    goal_map = {g['project_id']: dict(g) for g in goals}

    # 组装按项目分组的数据
    from collections import defaultdict
    done_by_project: dict = defaultdict(list)
    for t in done_tasks:
        done_by_project[t['project_id'] or '无项目任务'].append(dict(t))

    projects = []
    for row in project_stats:
        pid = row['project_id'] or '无项目任务'
        goal_info = goal_map.get(pid, {})
        projects.append({
            'project_id': pid,
            'goal': goal_info.get('goal', ''),
            'actual_summary': goal_info.get('actual_summary', ''),
            'done_count': row['done_count'],
            'active_count': row['active_count'],
            'done_tasks': done_by_project.get(pid, []),
        })

    # 总体统计（保持向后兼容）
    work_done = sum(1 for t in done_tasks if t['area'] == 'work')
    life_done = sum(1 for t in done_tasks if t['area'] == 'life')

    # 习惯统计
    habit_rows = conn.execute("""
        SELECT hd.name, hi.status
        FROM habit_instances hi JOIN habit_definitions hd ON hi.habit_id=hd.id
        WHERE hi.date BETWEEN ? AND ?
        ORDER BY hd.name
    """, (ms, me)).fetchall()
    from collections import defaultdict as _dd
    habit_stat: dict = _dd(lambda: [0, 0])
    for h in habit_rows:
        habit_stat[h['name']][1] += 1
        if h['status'] == 'done':
            habit_stat[h['name']][0] += 1
    habits = [{'name': n, 'done': v[0], 'total': v[1]}
              for n, v in habit_stat.items()]

    return {
        'month_key':    month_key,
        'month_range':  f'{ms} ~ {me}',
        'mode':         'monthly-round1-v2',  # 标记新版本
        'projects':     projects,
        'work_done':    work_done,
        'life_done':    life_done,
        'habits':       habits,
    }


def query_month_round2(conn: sqlite3.Connection, month_key: str) -> dict:
    """月复盘第二轮：定下月项目目标（v3.0.4）"""
    nm_key, nm_start, nm_end = next_month_range(month_key)

    # 查本月目标（用于对比展示）
    current_goals = conn.execute("""
        SELECT project_id, goal, actual_summary
        FROM project_goals WHERE month = ?
    """, (month_key,)).fetchall()
    goal_map = {g['project_id']: dict(g) for g in current_goals}

    # 查各项目下月积压任务数
    backlog = conn.execute("""
        SELECT project_id, COUNT(*) as cnt
        FROM tasks WHERE is_deleted=0 AND status IN ('active','inbox')
        AND (schedule_date IS NULL OR schedule_date >= ?)
        GROUP BY project_id
        ORDER BY project_id
    """, (nm_start,)).fetchall()
    backlog_map = {r['project_id']: r['cnt'] for r in backlog}

    # 有活跃任务的项目列表
    active_projects = conn.execute("""
        SELECT DISTINCT project_id FROM tasks
        WHERE is_deleted=0 AND status IN ('active','inbox')
        AND project_id IS NOT NULL AND project_id != ''
        ORDER BY project_id
    """).fetchall()

    projects = []
    for row in active_projects:
        pid = row['project_id']
        goal_info = goal_map.get(pid, {})
        projects.append({
            'project_id': pid,
            'current_goal': goal_info.get('goal', ''),
            'actual_summary': goal_info.get('actual_summary', ''),
            'backlog_count': backlog_map.get(pid, 0),
        })

    return {
        'month_key':        month_key,
        'next_month_key':   nm_key,
        'next_month_range': f'{nm_start} ~ {nm_end}',
        'mode':             'monthly-round2-v2',
        'projects':         projects,
    }


def main() -> None:
    parser = argparse.ArgumentParser(
        description='周/月复盘数据查询脚本，输出 render_review.py 所需 JSON',
    )
    parser.add_argument('--round', '-r', type=int, choices=[1, 2], required=True,
                        help='复盘轮次：1=本期回顾，2=下期规划')
    parser.add_argument('--week', '-w', default=None,
                        help='周标识，格式 YYYY-WNN（如 2026-W14）')
    parser.add_argument('--month', '-m', default=None,
                        help='月标识，格式 YYYY-MM（如 2026-04）')
    parser.add_argument('--output', '-o', default=None,
                        help='输出 JSON 文件路径（不指定则输出到 stdout）')
    args = parser.parse_args()

    # 参数校验：--week 和 --month 二选一
    if not args.week and not args.month:
        print('[ERROR] 必须指定 --week 或 --month', file=sys.stderr)
        sys.exit(1)
    if args.week and args.month:
        print('[ERROR] --week 和 --month 不能同时使用', file=sys.stderr)
        sys.exit(1)

    is_monthly = bool(args.month)

    # 加载 DB 路径
    config_path = Path(__file__).parent.parent / 'config.json'
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        db_path = config.get('db_path', str(Path.home() / '.rocky-todo-list-buddy/rocky.db'))
        db_path = str(Path(db_path).expanduser())
    except Exception:
        db_path = str(Path.home() / '.rocky-todo-list-buddy/rocky.db')

    if not Path(db_path).exists():
        print(f'[ERROR] 数据库不存在：{db_path}', file=sys.stderr)
        sys.exit(1)

    conn = get_connection(db_path)
    try:
        if is_monthly:
            if args.round == 1:
                data = query_month_round1(conn, args.month)
            else:
                data = query_month_round2(conn, args.month)
        else:
            if args.round == 1:
                data = query_round1(conn, args.week)
            else:
                data = query_round2(conn, args.week)
    finally:
        conn.close()

    result = json.dumps(data, ensure_ascii=False, indent=2)

    if args.output:
        Path(args.output).write_text(result, encoding='utf-8')
        period = args.month or args.week
        print(f'[OK] 复盘数据已写入：{args.output}', file=sys.stderr)
    else:
        print(result)


if __name__ == '__main__':
    main()
