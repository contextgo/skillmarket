#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
format_confirm.py - 模块收尾确认信息格式化脚本

功能：将各模块写入成功后的收尾信息以标准格式输出，
     Agent 把 CONFIRM_START/END 之间的内容原样贴入回复，不得修改。

用法：
  python format_confirm.py --module inbox-done --count 1 --detail "激活 2 / 取消 1 / 搁置 0"
  python format_confirm.py --module midday-done --work-done 3 --life-done 1 --remaining 4
  python format_confirm.py --module weekly-done --week 2026-W15
  python format_confirm.py --module monthly-done --month 2026-03
  python format_confirm.py --module history-done --count 12 --done 3 --cancelled 2 --deferred 7
  python format_confirm.py --module habit-done --date 2026-04-12 --done 2 --cancelled 1
"""

import argparse
import json
import sys
from pathlib import Path


def load_config() -> dict:
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    return json.loads(config_path.read_text(encoding='utf-8'))


ROCKY_LINES = {
    'inbox-done':    '💬 Rocky：Rocky 记住了。你不用记，Rocky 记忆完美。',
    'midday-done':   '💬 Rocky：下午继续，Rocky 帮你盯着。',
    'weekly-done':   '💬 Rocky：本周复盘完成。Rocky 已经记住了。',
    'monthly-done':  '💬 Rocky：本月复盘完成。Rocky 已经记住了。',
    'history-done':  '💬 Rocky：历史任务清干净了。人类脑子，没用玩意儿，陈述句。',
    'habit-done':    '💬 Rocky：习惯已补录。Rocky 帮你记着呢。',
}


def print_confirm(body: str, rocky_line: str, rocky_voice: bool):
    print('CONFIRM_START')
    print(body)
    print('CONFIRM_END')
    if rocky_voice and rocky_line:
        print(rocky_line)


def main():
    parser = argparse.ArgumentParser(description='模块收尾确认信息格式化')
    parser.add_argument('--module', required=True,
                        choices=['inbox-done', 'midday-done', 'weekly-done',
                                 'monthly-done', 'history-done', 'habit-done'],
                        help='模块类型')
    # 通用参数
    parser.add_argument('--count', type=int, default=0, help='总处理条数')
    parser.add_argument('--detail', default='', help='处理详情（如「激活 X / 取消 Y」）')
    # midday-done
    parser.add_argument('--work-done', type=int, default=0, help='工作已完成条数')
    parser.add_argument('--life-done', type=int, default=0, help='生活已完成条数')
    parser.add_argument('--remaining', type=int, default=0, help='剩余待处理条数')
    # weekly/monthly-done
    parser.add_argument('--week', default='', help='周期（YYYY-WNN）')
    parser.add_argument('--month', default='', help='月份（YYYY-MM）')
    # history-done
    parser.add_argument('--done', type=int, default=0, help='标记完成条数')
    parser.add_argument('--cancelled', type=int, default=0, help='取消条数')
    parser.add_argument('--deferred', type=int, default=0, help='顺延条数')
    # habit-done
    parser.add_argument('--date', default='', help='习惯补录日期')

    args = parser.parse_args()
    config = load_config()
    rocky_voice = config.get('rocky_voice', True)
    rocky_line = ROCKY_LINES.get(args.module, '')

    if args.module == 'inbox-done':
        detail = f'（{args.detail}）' if args.detail else ''
        body = (
            f'✅ 已处理 {args.count} 条待办{detail}\n'
            f'\n'
            f'{{build_plan --render --no-candidate 的 stdout 输出}}\n'
            f'\n'
            f'以上是更新后的今日安排，确认没问题就按这个来。'
        )
        # inbox-done 特殊：body 中有占位符，需要 AI 在 CONFIRM 外拼接 build_plan 输出
        # 所以只输出纯文字确认行，不含 build_plan 占位
        body = f'✅ 已处理 {args.count} 条待办{detail}'

    elif args.module == 'midday-done':
        remain_str = f'，还有 {args.remaining} 项待处理' if args.remaining else '，今日任务全部清零 🎉'
        body = (
            f'✅ 已更新（工作完成 {args.work_done} 项 / 生活完成 {args.life_done} 项）\n'
            f'下午继续{remain_str}。'
        )

    elif args.module == 'weekly-done':
        body = f'✅ {args.week} 周总结规划已完成。'

    elif args.module == 'monthly-done':
        body = f'✅ {args.month} 月总结规划已完成。'

    elif args.module == 'history-done':
        body = (
            f'✅ 历史任务已清理（共 {args.count} 条）\n'
            f'  完成 {args.done} · 取消 {args.cancelled} · 顺延 {args.deferred}'
        )

    elif args.module == 'habit-done':
        done_str = f'完成 {args.done} 条' if args.done else ''
        cancelled_str = f'未完成 {args.cancelled} 条' if args.cancelled else ''
        parts = ' · '.join(filter(None, [done_str, cancelled_str]))
        body = f'✅ {args.date} 习惯已补录（{parts}）'

    else:
        body = f'✅ {args.module} 完成'

    print_confirm(body, rocky_line, rocky_voice)


if __name__ == '__main__':
    main()
