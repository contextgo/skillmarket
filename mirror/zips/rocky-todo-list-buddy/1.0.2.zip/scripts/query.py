#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
query.py - 统一查询接口
功能：参数化查询，替代 AI 扫描文件，输出标准 JSON 供 AI 消费。

用法：
  python query.py --status active --schedule today
  python query.py --project P-播客项目 --status active
  python query.py --ddl-within 7 --area work
  python query.py --overdue
  python query.py --type habit --date-range 2026-03-31,2026-04-06
  python query.py --type review --period 2026-W14
  python query.py --status active --format summary
"""

import sys
import json
import sqlite3
import argparse
from pathlib import Path
from datetime import datetime, date, timedelta
from typing import Optional, List, Dict, Any


def load_config() -> dict:
    """加载配置文件"""
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config['db_path'] = str(Path(config['db_path']).expanduser())
    return config


def get_connection(db_path: str) -> sqlite3.Connection:
    """建立 SQLite 连接并设置必要 PRAGMA"""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA synchronous=NORMAL')
    return conn


# ============================================================
# 日期工具函数
# ============================================================

def today_str() -> str:
    return date.today().isoformat()


def tomorrow_str() -> str:
    return (date.today() + timedelta(days=1)).isoformat()


def week_start_str() -> str:
    """本周一"""
    d = date.today()
    return (d - timedelta(days=d.weekday())).isoformat()


def week_end_str() -> str:
    """本周日"""
    d = date.today()
    return (d - timedelta(days=d.weekday()) + timedelta(days=6)).isoformat()


def next_week_start_str() -> str:
    """下周一"""
    d = date.today()
    return (d - timedelta(days=d.weekday()) + timedelta(days=7)).isoformat()


def next_week_end_str() -> str:
    """下周日"""
    d = date.today()
    return (d - timedelta(days=d.weekday()) + timedelta(days=13)).isoformat()


def month_start_str() -> str:
    d = date.today()
    return d.replace(day=1).isoformat()


def month_end_str() -> str:
    d = date.today()
    if d.month == 12:
        end = d.replace(year=d.year + 1, month=1, day=1) - timedelta(days=1)
    else:
        end = d.replace(month=d.month + 1, day=1) - timedelta(days=1)
    return end.isoformat()


def next_month_start_str() -> str:
    d = date.today()
    if d.month == 12:
        return d.replace(year=d.year + 1, month=1, day=1).isoformat()
    return d.replace(month=d.month + 1, day=1).isoformat()


def next_month_end_str() -> str:
    d = date.today()
    if d.month == 11:
        end = d.replace(year=d.year, month=12, day=31)
    elif d.month == 12:
        end = d.replace(year=d.year + 1, month=2, day=1) - timedelta(days=1)
    else:
        end = d.replace(month=d.month + 2, day=1) - timedelta(days=1)
    return end.isoformat()


def calculate_overdue_days(due_date_str: Optional[str]) -> Optional[int]:
    """计算逾期天数（正数=逾期，负数=未到期，0=今天到期）"""
    if not due_date_str:
        return None
    try:
        due = date.fromisoformat(due_date_str)
        delta = (date.today() - due).days
        return delta if delta > 0 else None
    except ValueError:
        return None


# ============================================================
# 核心查询函数
# ============================================================

def query_tasks(conn: sqlite3.Connection, filters: Dict[str, Any], limit: Optional[int] = None) -> List[Dict[str, Any]]:
    """
    通用任务查询，支持多种过滤条件。
    返回标准化的任务字典列表。
    """
    conditions = ['t.is_deleted = 0']
    params: List[Any] = []
    today = today_str()

    # 状态过滤
    if filters.get('status'):
        conditions.append('t.status = ?')
        params.append(filters['status'])

    # area 过滤
    if filters.get('area'):
        conditions.append('t.area = ?')
        params.append(filters['area'])

    # project 过滤
    if filters.get('project'):
        conditions.append('t.project_id = ?')
        params.append(filters['project'])

    # schedule 过滤
    schedule = filters.get('schedule')
    if schedule == 'today':
        # 纳入 schedule_date=today 的任务，以及 due_date <= today（今天到期或已逾期）且未安排日期的任务
        # 使用 due_date <= today（即 due_date < tomorrow）以确保今天到期的任务也被捕获
        conditions.append(
            "(t.schedule_date = ? OR (t.due_date <= ? AND t.schedule_date IS NULL AND t.status NOT IN ('done','cancelled')))"
        )
        params.extend([today, today])
    elif schedule == 'tomorrow':
        conditions.append('t.schedule_date = ?')
        params.append(tomorrow_str())
    elif schedule == 'yesterday':
        conditions.append('t.schedule_date = ?')
        params.append((date.today() - timedelta(days=1)).isoformat())
    elif schedule == 'week':
        conditions.append('t.schedule_date BETWEEN ? AND ?')
        params.extend([week_start_str(), week_end_str()])
    elif schedule == 'next-week':
        conditions.append('t.schedule_date BETWEEN ? AND ?')
        params.extend([next_week_start_str(), next_week_end_str()])
    elif schedule == 'month':
        conditions.append('t.schedule_date BETWEEN ? AND ?')
        params.extend([month_start_str(), month_end_str()])
    elif schedule == 'next-month':
        conditions.append('t.schedule_date BETWEEN ? AND ?')
        params.extend([next_month_start_str(), next_month_end_str()])
    elif schedule:
        conditions.append('t.schedule_date = ?')
        params.append(schedule)

    # DDL within N days
    if filters.get('ddl_within') is not None:
        n = int(filters['ddl_within'])
        in_n_days = (date.today() + timedelta(days=n)).isoformat()
        conditions.append("t.due_date BETWEEN ? AND ? AND t.schedule_date IS NULL AND t.status NOT IN ('done','cancelled')")
        params.extend([today, in_n_days])

    # 仅逾期任务（DDL 过期）
    if filters.get('overdue'):
        conditions.append("t.due_date < ? AND t.status NOT IN ('done','cancelled')")
        params.append(today)

    # 计划日期已过（schedule < today）但未完成——过期未执行任务，用于候选池强制浮出
    if filters.get('overdue_schedule'):
        conditions.append(
            "t.schedule_date < ? AND t.schedule_date IS NOT NULL"
            " AND t.status NOT IN ('done','cancelled','someday')"
            " AND (t.snooze_until IS NULL OR t.snooze_until <= ?)"  # snooze_until<=today 时恢复浮出
        )
        params.append(today)
        params.append(today)  # snooze_filter: snooze_until <= today 表示 snooze 当天即恢复

    # 优先级过滤
    if filters.get('priority'):
        conditions.append('t.priority = ?')
        params.append(filters['priority'])

    # 无执行日期（schedule_date IS NULL）
    if filters.get('no_schedule'):
        conditions.append('t.schedule_date IS NULL')

    # 无 DDL（due_date IS NULL）
    if filters.get('no_ddl'):
        conditions.append('t.due_date IS NULL')

    # 今日已完成（completed_at = today）
    if filters.get('completed_today'):
        conditions.append("date(t.completed_at) = ?")
        params.append(today)

    # 本周已完成
    if filters.get('completed_week'):
        conditions.append("date(t.completed_at) BETWEEN ? AND ?")
        params.extend([week_start_str(), week_end_str()])

    # 本月已完成
    if filters.get('completed_month'):
        conditions.append("date(t.completed_at) BETWEEN ? AND ?")
        params.extend([month_start_str(), month_end_str()])

    where_clause = ' AND '.join(conditions)

    # 排序：优先级 + DDL
    order_clause = """
        CASE t.priority
            WHEN 'urgent' THEN 1
            WHEN 'high' THEN 2
            WHEN 'normal' THEN 3
            WHEN 'waiting' THEN 4
            ELSE 5
        END,
        t.due_date ASC NULLS LAST,
        t.schedule_date ASC NULLS LAST,
        t.created_at ASC
    """

    sql = f"""
        SELECT
            t.id, t.title, t.status, t.priority, t.area,
            t.project_id, t.schedule_date, t.due_date,
            t.completed_at, t.created_at, t.updated_at,
            t.tags, t.body, t.source, t.md_filename,
            p.name AS project_name
        FROM tasks t
        LEFT JOIN projects p ON t.project_id = p.id
        WHERE {where_clause}
        ORDER BY {order_clause}
    """
    if limit:
        sql += f' LIMIT {int(limit)}'

    rows = conn.execute(sql, params).fetchall()
    result = []
    for row in rows:
        d = dict(row)
        overdue_days = calculate_overdue_days(d.get('due_date'))
        result.append({
            'id': d['id'],
            'filename': d['md_filename'] or f"{d['created_at'][:10]}-{d['title'][:20]}.md",
            'title': d['title'],
            'status': d['status'],
            'priority': d['priority'],
            'area': d['area'],
            'project': d['project_id'],
            'schedule': d['schedule_date'],
            'ddl': d['due_date'],
            'overdue_days': overdue_days,
            'body': d['body'],
            'source': d['source'],
            'created_at': d['created_at'],
            'updated_at': d['updated_at'],
        })
    return result


def query_reviews(conn: sqlite3.Connection, period: Optional[str] = None,
                  review_type: Optional[str] = None) -> List[Dict[str, Any]]:
    """查询复盘记录"""
    conditions = ['1=1']
    params: List[Any] = []
    if period:
        conditions.append('period = ?')
        params.append(period)
    if review_type:
        conditions.append('type = ?')
        params.append(review_type)
    sql = f"SELECT * FROM reviews WHERE {' AND '.join(conditions)} ORDER BY created_at DESC"
    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


def query_habits(conn: sqlite3.Connection, date_range: Optional[str] = None) -> List[Dict[str, Any]]:
    """
    查询习惯完成情况。
    date_range 格式：YYYY-MM-DD,YYYY-MM-DD
    """
    conditions = ['hi.date IS NOT NULL']
    params: List[Any] = []
    if date_range:
        parts = date_range.split(',')
        if len(parts) == 2:
            conditions.append('hi.date BETWEEN ? AND ?')
            params.extend([parts[0].strip(), parts[1].strip()])
        else:
            conditions.append('hi.date = ?')
            params.append(date_range.strip())

    sql = f"""
        SELECT
            hi.id, hi.habit_id, hi.date, hi.status, hi.completed_at, hi.note,
            hd.name AS habit_name, hd.area, hd.frequency, hd.priority
        FROM habit_instances hi
        LEFT JOIN habit_definitions hd ON hi.habit_id = hd.id
        WHERE {' AND '.join(conditions)}
        ORDER BY hi.date ASC, hi.habit_id ASC
    """
    rows = conn.execute(sql, params).fetchall()
    return [dict(r) for r in rows]


# ============================================================
# 输出格式化
# ============================================================

PRIORITY_DISPLAY = {
    'urgent': '🔴 最重要',
    'high': '🟡 重要',
    'normal': '🟢 普通',
    'waiting': '⏳ 等待中',
}

STATUS_DISPLAY = {
    'inbox': '📥 待安排',
    'active': '🔄 进行中',
    'done': '✅ 完成',
    'cancelled': '❌ 取消',
    'someday': '📦 搁置',
}

AREA_DISPLAY = {
    'work': '💼 工作',
    'life': '🏠 生活',
}


def format_summary(tasks: List[Dict[str, Any]]) -> str:
    """输出简洁的摘要格式"""
    if not tasks:
        return '（无符合条件的任务）'

    lines = []
    for i, t in enumerate(tasks, 1):
        priority_icon = PRIORITY_DISPLAY.get(t['priority'], t['priority']).split()[0]
        status_icon = STATUS_DISPLAY.get(t['status'], t['status']).split()[0]
        overdue = f'  🔥逾期{t["overdue_days"]}天' if t.get('overdue_days') else ''
        project = f'  [{t["project"]}]' if t.get('project') else ''
        ddl = f'  DDL:{t["ddl"]}' if t.get('ddl') else ''
        lines.append(
            f'  {i:2}. {priority_icon}{status_icon} {t["title"]}{project}{ddl}{overdue}'
        )

    area_counts: Dict[str, int] = {}
    status_counts: Dict[str, int] = {}
    for t in tasks:
        area_counts[t['area']] = area_counts.get(t['area'], 0) + 1
        status_counts[t['status']] = status_counts.get(t['status'], 0) + 1

    summary_parts = [f'共 {len(tasks)} 条']
    for area, cnt in sorted(area_counts.items()):
        summary_parts.append(f'{AREA_DISPLAY.get(area, area)} {cnt}')

    return '=== 任务列表 ===\n' + '\n'.join(lines) + f'\n\n合计：{" | ".join(summary_parts)}'


def build_output(query_type: str, tasks: List[Dict[str, Any]],
                 filters: Dict[str, Any], output_format: str) -> str:
    """构建输出内容"""
    if output_format == 'summary':
        return format_summary(tasks)

    # JSON 格式
    result = {
        'query_time': datetime.now().isoformat(),
        'total': len(tasks),
        'filters': {k: v for k, v in filters.items() if v is not None and v is not False},
        'tasks': tasks,
    }
    return json.dumps(result, ensure_ascii=False, indent=2)


# ============================================================
# 命令行入口
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro - 统一查询接口',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python query.py --status active --schedule today
  python query.py --project P-播客项目 --status active
  python query.py --ddl-within 7 --area work
  python query.py --overdue
  python query.py --status active --format summary
  python query.py --type habit --date-range 2026-03-31,2026-04-06
  python query.py --type review --period 2026-W14
        """
    )

    # 过滤条件
    parser.add_argument('--status', help='状态过滤：active / inbox / done / cancelled / someday')
    parser.add_argument('--area', help='分区过滤：work / life')
    parser.add_argument('--project', help='项目名称（精确匹配，如 P-播客项目）')
    parser.add_argument('--schedule', help='执行日期：today / YYYY-MM-DD / week / month')
    parser.add_argument('--ddl-within', dest='ddl_within', type=int,
                        help='DDL 在 N 天内的任务')
    parser.add_argument('--overdue', action='store_true', help='仅逾期任务（ddl < today AND status 非完成）')
    parser.add_argument('--overdue-schedule', dest='overdue_schedule', action='store_true',
                        help='计划日期已过但未完成的任务（schedule < today，用于候选池强制浮出）')
    parser.add_argument('--priority', help='优先级过滤：urgent / high / normal / waiting')
    parser.add_argument('--no-schedule', dest='no_schedule', action='store_true',
                        help='仅无执行日期的任务（schedule_date IS NULL）')
    parser.add_argument('--no-ddl', dest='no_ddl', action='store_true',
                        help='仅无截止日期的任务（due_date IS NULL）')
    parser.add_argument('--completed-today', dest='completed_today', action='store_true',
                        help='今日已完成的任务（completed_at = today）')
    parser.add_argument('--completed-week', dest='completed_week', action='store_true',
                        help='本周已完成的任务')
    parser.add_argument('--completed-month', dest='completed_month', action='store_true',
                        help='本月已完成的任务')

    # 查询类型
    parser.add_argument('--type', choices=['tasks', 'review', 'habit', 'task-log', 'project-summary', 'project-goals'], default='tasks',
                        help='查询类型（默认 tasks）')
    parser.add_argument('--period', help='复盘周期（用于 --type review，如 2026-W14 / 2026-04）')
    parser.add_argument('--date-range', dest='date_range',
                        help='习惯日期范围（用于 --type habit，如 2026-03-31,2026-04-06）')
    parser.add_argument('--date', dest='date',
                        help='单日日期（用于 --type habit，支持 today / YYYY-MM-DD；优先于 --date-range）')

    # 输出控制
    parser.add_argument('--format', choices=['json', 'summary'], default='json',
                        help='输出格式（默认 json）')
    parser.add_argument('--limit', type=int, help='最多返回 N 条')

    args = parser.parse_args()
    config = load_config()
    db_path = config['db_path']

    # 检查数据库是否存在
    if not Path(db_path).exists():
        error = {
            'error': f'数据库不存在：{db_path}，请先运行 python db_init.py',
            'query_time': datetime.now().isoformat(),
        }
        print(json.dumps(error, ensure_ascii=False))
        sys.exit(1)

    conn = get_connection(db_path)
    try:
        filters = {
            'status': args.status,
            'area': args.area,
            'project': args.project,
            'schedule': args.schedule,
            'ddl_within': args.ddl_within,
            'overdue': args.overdue,
            'overdue_schedule': args.overdue_schedule,
            'priority': args.priority,
            'no_schedule': args.no_schedule,
            'no_ddl': args.no_ddl,
            'completed_today': args.completed_today,
            'completed_week': args.completed_week,
            'completed_month': args.completed_month,
        }

        if args.type == 'tasks':
            data = query_tasks(conn, filters, limit=args.limit)
            output = build_output('tasks', data, filters, args.format)
        elif args.type == 'review':
            data = query_reviews(conn, period=args.period)
            if args.format == 'summary':
                output = f'复盘记录：共 {len(data)} 条\n' + '\n'.join(
                    f'  {r.get("type")} | {r.get("period")} | 完成率(工作)={r.get("work_completion_rate")}%'
                    for r in data
                )
            else:
                output = json.dumps({
                    'query_time': datetime.now().isoformat(),
                    'total': len(data),
                    'filters': {'period': args.period},
                    'reviews': data,
                }, ensure_ascii=False, indent=2)
        elif args.type == 'habit':
            # --date 优先于 --date-range（修复 P03：--date today 的参数冲突）
            effective_date_range = args.date_range
            if args.date:
                d = today_str() if args.date == 'today' else args.date
                effective_date_range = f'{d},{d}'  # 单日转换为 date_range 格式
            data = query_habits(conn, date_range=effective_date_range)
            if args.format == 'summary':
                output = f'习惯记录：共 {len(data)} 条\n' + '\n'.join(
                    f'  {h.get("date")} {h.get("habit_name")} [{h.get("status")}]'
                    for h in data
                )
            else:
                output = json.dumps({
                    'query_time': datetime.now().isoformat(),
                    'total': len(data),
                    'filters': {'date_range': effective_date_range},
                    'habits': data,
                }, ensure_ascii=False, indent=2)
        elif args.type == 'project-summary':
            # 独立路由：查询项目级汇总（不复用 build_output）
            sql = """
                SELECT p.id, p.name, p.area, p.status, p.description,
                       COUNT(CASE WHEN t.status='active' AND t.is_deleted=0 THEN 1 END) AS active_count,
                       COUNT(CASE WHEN t.status='inbox' AND t.is_deleted=0 THEN 1 END) AS inbox_count,
                       COUNT(CASE WHEN t.status='done' AND t.is_deleted=0 THEN 1 END) AS done_count,
                       MIN(CASE WHEN t.status NOT IN ('done','cancelled') AND t.is_deleted=0 AND t.due_date IS NOT NULL
                                THEN t.due_date END) AS next_ddl
                FROM projects p
                LEFT JOIN tasks t ON t.project_id = p.id
                WHERE p.status != 'done'
                GROUP BY p.id
                ORDER BY p.area ASC, p.id ASC
            """
            rows = conn.execute(sql).fetchall()
            projects = []
            for row in rows:
                d = dict(row)
                projects.append({
                    'id': d['id'],
                    'name': d['name'],
                    'area': d['area'],
                    'status': d['status'],
                    'description': d['description'],
                    'active_count': d['active_count'] or 0,
                    'inbox_count': d['inbox_count'] or 0,
                    'done_count': d['done_count'] or 0,
                    'next_ddl': d['next_ddl'],
                })
            if args.format == 'summary':
                lines = []
                for i, p in enumerate(projects, 1):
                    area_icon = '💼' if p['area'] == 'work' else '🏠'
                    ddl_str = f'  DDL:{p["next_ddl"]}' if p.get('next_ddl') else ''
                    lines.append(
                        f'  {i:2}. {area_icon} {p["name"]}  '
                        f'进行中:{p["active_count"]}  待安排:{p["inbox_count"]}{ddl_str}'
                    )
                output = f'项目列表：共 {len(projects)} 个\n' + '\n'.join(lines)
            else:
                output = json.dumps({
                    'query_time': datetime.now().isoformat(),
                    'total': len(projects),
                    'projects': projects,
                }, ensure_ascii=False, indent=2)
        elif args.type == 'task-log':
            # 查询用户原文审计记录（替代 task-log.md）
            # 支持按日期过滤（--schedule today / YYYY-MM-DD）
            date_filter = None
            if args.schedule:
                if args.schedule == 'today':
                    date_filter = date.today().isoformat()
                elif args.schedule == 'yesterday':
                    date_filter = (date.today() - timedelta(days=1)).isoformat()
                else:
                    date_filter = args.schedule  # 直接用 YYYY-MM-DD

            sql = """
                SELECT tl.id, tl.task_id, tl.raw_input, tl.logged_at,
                       t.title, t.area, t.project_id
                FROM task_logs tl
                LEFT JOIN tasks t ON tl.task_id = t.id
                WHERE tl.action = 'user_input'
                  AND tl.raw_input IS NOT NULL
            """
            params: list = []
            if date_filter:
                sql += " AND date(tl.logged_at) = ?"
                params.append(date_filter)
            sql += " ORDER BY tl.logged_at DESC"
            if args.limit:
                sql += f" LIMIT {args.limit}"

            rows = conn.execute(sql, params).fetchall()
            logs = [dict(r) for r in rows]

            if args.format == 'summary':
                lines = []
                for log in logs:
                    ts = log.get('logged_at', '')[:16]
                    task_id = log.get('task_id', '')
                    title = log.get('title', task_id)
                    raw = log.get('raw_input', '').replace('\n', ' ')[:60]
                    lines.append(f'  [{ts}] {title}\n    原文：{raw}')
                output = f'原文记录：共 {len(logs)} 条\n' + '\n'.join(lines)
            else:
                output = json.dumps({
                    'query_time': datetime.now().isoformat(),
                    'total': len(logs),
                    'filters': {'date': date_filter},
                    'task_logs': logs,
                }, ensure_ascii=False, indent=2)
        elif args.type == 'project-goals':
            # 查询项目月度目标（v3.0.4）
            # 默认查当月，--date 可指定月份（YYYY-MM）
            month_filter = None
            if args.date:
                month_filter = args.date[:7]  # 取 YYYY-MM
            elif args.schedule and args.schedule not in ('today', 'yesterday'):
                month_filter = args.schedule[:7]
            else:
                month_filter = date.today().strftime('%Y-%m')

            rows = conn.execute('''
                SELECT pg.project_id, pg.month, pg.goal, pg.actual_summary,
                       pg.task_done_count, pg.task_active_count,
                       p.name as project_name
                FROM project_goals pg
                LEFT JOIN projects p ON pg.project_id = p.id
                WHERE pg.month = ?
                ORDER BY pg.project_id
            ''', (month_filter,)).fetchall()
            goals = [dict(r) for r in rows]

            if args.format == 'summary':
                if not goals:
                    output = f'{month_filter} 尚未设置项目目标'
                else:
                    lines = [f'📌 {month_filter} 项目目标\n']
                    for g in goals:
                        name = g.get('project_name') or g['project_id']
                        lines.append(f'📂 {name}')
                        lines.append(f'  🎯 目标：{g["goal"]}')
                        if g.get('actual_summary'):
                            lines.append(f'  📊 实际：{g["actual_summary"]}')
                        lines.append(f'  完成 {g.get("task_done_count", 0)} 项 · 进行中 {g.get("task_active_count", 0)} 项')
                        lines.append('')
                    output = '\n'.join(lines)
            else:
                output = json.dumps({
                    'query_time': datetime.now().isoformat(),
                    'month': month_filter,
                    'total': len(goals),
                    'goals': goals,
                }, ensure_ascii=False, indent=2)
        else:
            output = json.dumps({'error': f'未知 type：{args.type}'}, ensure_ascii=False)

        print(output)

    finally:
        conn.close()


if __name__ == '__main__':
    main()
