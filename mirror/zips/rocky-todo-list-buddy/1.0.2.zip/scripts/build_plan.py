#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_plan.py - LifeOps Pro 自动组装 DailyPlan JSON
版本：v3.0.0

功能：
  在单次 Python 调用内完成所有 query，合并结果，输出通过 schema 校验的 DailyPlan JSON。
  --render 模式下直接输出 Markdown 到 stdout（v3.0：不再支持 --render-output 写文件）。

  stdout 末尾包含 TASK_SEQ_MAP 注释，Agent 从中提取序号映射保存到对话上下文。

用法：
  # 渲染模式（推荐，直接输出 Markdown 到 stdout）
  python build_plan.py --date 2026-04-04 --mode morning --render
  python build_plan.py --date 2026-04-04 --mode midday --render
  python build_plan.py --date 2026-04-04 --mode next-day --render

  # JSON 模式（调试/数据导出用）
  python build_plan.py --date 2026-04-04 --mode morning --output /tmp/morning_plan.json

--mode 说明：
  morning  : 晨间规划（候选任务 + 习惯 + 过期浮出 + DDL 提醒）
  midday   : 日间盘点（今日进行中 + 今日完成 + 过期浮出）
  next-day : 规划明天（今日顺延 + 明日已有安排 + inbox 候选）
"""

from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional


# ── 配置加载 ──────────────────────────────────────────────────────────────────

def load_config() -> dict:
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config['db_path'] = str(Path(config['db_path']).expanduser())
    return config


def get_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA synchronous=NORMAL')
    return conn


# ── 日期工具 ──────────────────────────────────────────────────────────────────

def today_str() -> str:
    return date.today().isoformat()


def tomorrow_str() -> str:
    return (date.today() + timedelta(days=1)).isoformat()


def week_start_str() -> str:
    d = date.today()
    return (d - timedelta(days=d.weekday())).isoformat()


def week_end_str() -> str:
    d = date.today()
    return (d - timedelta(days=d.weekday()) + timedelta(days=6)).isoformat()


def next_week_start_str() -> str:
    d = date.today()
    return (d - timedelta(days=d.weekday()) + timedelta(days=7)).isoformat()


def next_week_end_str() -> str:
    d = date.today()
    return (d - timedelta(days=d.weekday()) + timedelta(days=13)).isoformat()


def in_n_days_str(n: int) -> str:
    return (date.today() + timedelta(days=n)).isoformat()


def calculate_overdue_days(due_date_str: Optional[str]) -> Optional[int]:
    if not due_date_str:
        return None
    try:
        due = date.fromisoformat(due_date_str)
        delta = (date.today() - due).days
        return delta if delta > 0 else None
    except ValueError:
        return None


# ── 数据库查询函数 ─────────────────────────────────────────────────────────────

BASE_TASK_SELECT = """
    SELECT
        t.id, t.title, t.status, t.priority, t.area,
        t.project_id, t.schedule_date, t.due_date,
        t.completed_at, t.created_at, t.md_filename,
        p.name AS project_name
    FROM tasks t
    LEFT JOIN projects p ON t.project_id = p.id
    WHERE t.is_deleted = 0
"""

ORDER_BY_PRIORITY = """
    ORDER BY
        CASE t.priority
            WHEN 'urgent' THEN 1
            WHEN 'high' THEN 2
            WHEN 'normal' THEN 3
            WHEN 'waiting' THEN 4
            ELSE 5
        END,
        t.due_date ASC NULLS LAST,
        t.schedule_date ASC NULLS LAST,
        t.created_at ASC
"""


def _row_to_task(row: sqlite3.Row) -> Dict[str, Any]:
    d = dict(row)
    return {
        'id': d['id'],
        'filename': d['md_filename'] or f"{d['created_at'][:10]}-{d['title'][:20]}.md",
        'title': d['title'],
        'status': d['status'],
        'priority': d['priority'],
        'area': d['area'],
        'project': d['project_id'],
        'schedule': d['schedule_date'],
        'ddl': d['due_date'],
        'overdue_days': calculate_overdue_days(d.get('due_date')),
        'body': None,
        'source': None,
        'created_at': d['created_at'],
        'updated_at': None,
    }


def query_today_candidates(conn: sqlite3.Connection, target_date: str) -> List[Dict[str, Any]]:
    """今日候选任务（schedule=target_date 或 due_date <= target_date 且无 schedule）"""
    sql = BASE_TASK_SELECT + """
        AND t.status NOT IN ('done', 'cancelled', 'someday')
        AND (
            t.schedule_date = ?
            OR (t.due_date <= ? AND t.schedule_date IS NULL)
        )
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql, [target_date, target_date]).fetchall()
    return [_row_to_task(r) for r in rows]


def query_overdue_schedule(conn: sqlite3.Connection, target_date: str) -> List[Dict[str, Any]]:
    """计划日期已过但未完成（含 snooze 过滤：snooze_until <= today 当天即恢复）"""
    sql = BASE_TASK_SELECT + """
        AND t.schedule_date < ?
        AND t.schedule_date IS NOT NULL
        AND t.status NOT IN ('done', 'cancelled', 'someday')
        AND (t.snooze_until IS NULL OR t.snooze_until <= ?)
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql, [target_date, target_date]).fetchall()
    return [_row_to_task(r) for r in rows]


def query_overdue_ddl(conn: sqlite3.Connection, target_date: str) -> List[Dict[str, Any]]:
    """DDL 已逾期"""
    sql = BASE_TASK_SELECT + """
        AND t.due_date < ?
        AND t.status NOT IN ('done', 'cancelled')
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql, [target_date]).fetchall()
    return [_row_to_task(r) for r in rows]


def query_ddl_within_n(conn: sqlite3.Connection, target_date: str, n: int) -> List[Dict[str, Any]]:
    """DDL N天内临近（无 schedule，避免与今日候选重复）"""
    in_n = in_n_days_str(n)
    sql = BASE_TASK_SELECT + """
        AND t.due_date BETWEEN ? AND ?
        AND t.schedule_date IS NULL
        AND t.status NOT IN ('done', 'cancelled')
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql, [target_date, in_n]).fetchall()
    return [_row_to_task(r) for r in rows]


def query_waiting(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """等待他人类任务"""
    sql = BASE_TASK_SELECT + """
        AND t.status = 'active'
        AND t.priority = 'waiting'
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql).fetchall()
    return [_row_to_task(r) for r in rows]


def query_inbox(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """inbox 候选池"""
    sql = BASE_TASK_SELECT + """
        AND t.status = 'inbox'
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql).fetchall()
    return [_row_to_task(r) for r in rows]


def query_done_today(conn: sqlite3.Connection, target_date: str) -> List[Dict[str, Any]]:
    """今日已完成"""
    sql = BASE_TASK_SELECT + """
        AND t.status = 'done'
        AND date(t.completed_at) = ?
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql, [target_date]).fetchall()
    return [_row_to_task(r) for r in rows]


def query_today_active(conn: sqlite3.Connection, target_date: str) -> List[Dict[str, Any]]:
    """今日进行中（schedule=today）"""
    sql = BASE_TASK_SELECT + """
        AND t.status = 'active'
        AND t.schedule_date = ?
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql, [target_date]).fetchall()
    return [_row_to_task(r) for r in rows]


def query_tomorrow_scheduled(conn: sqlite3.Connection, tomorrow: str) -> List[Dict[str, Any]]:
    """明日已有安排"""
    sql = BASE_TASK_SELECT + """
        AND t.status IN ('active', 'inbox')
        AND t.schedule_date = ?
    """ + ORDER_BY_PRIORITY
    rows = conn.execute(sql, [tomorrow]).fetchall()
    return [_row_to_task(r) for r in rows]


def query_habits(conn: sqlite3.Connection, target_date: str) -> List[Dict[str, Any]]:
    """今日习惯实例"""
    sql = """
        SELECT hi.id, hi.habit_id, hi.date, hi.status, hi.completed_at, hi.note,
               hd.name AS habit_name, hd.area, hd.frequency
        FROM habit_instances hi
        LEFT JOIN habit_definitions hd ON hi.habit_id = hd.id
        WHERE hi.date = ?
        ORDER BY hi.habit_id ASC
    """
    rows = conn.execute(sql, [target_date]).fetchall()
    habits = []
    for row in rows:
        d = dict(row)
        habits.append({
            'name': d['habit_name'] or d['habit_id'],
            'time': '',  # habit_instances 暂无 time 字段，留空
            'status': d['status'],
        })
    return habits


# ── 任务分组（按项目）─────────────────────────────────────────────────────────

def group_by_project(tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    将任务列表按项目分组，生成 ProjectGroup 结构。
    无项目的任务归入「无项目任务」。
    """
    groups: Dict[str, Dict[str, Any]] = {}
    order: List[str] = []

    for task in tasks:
        project_key = task.get('project') or '__daily__'
        if project_key not in groups:
            name = task['project'] if task.get('project') else '无项目任务'
            area = task.get('area') or 'work'
            groups[project_key] = {'name': name, 'area': area, 'tasks': []}
            order.append(project_key)
        groups[project_key]['tasks'].append({
            'id': task['id'],
            'title': task['title'],
            'priority': task['priority'],
            'area': task.get('area'),
            'project': task.get('project'),
            'schedule': task.get('schedule'),
            'ddl': task.get('ddl'),
            'status': task['status'],
            'note': '',
            'overdue_days': task.get('overdue_days'),
            'delayed': False,
            'time_slot': None,
        })

    return [groups[k] for k in order]


# ── DailyPlan 构建 ────────────────────────────────────────────────────────────

def build_seq_map(all_task_groups: List[List[Dict[str, Any]]], habits: List[Dict[str, Any]],
                  candidate_tasks: List[Dict[str, Any]]) -> Dict[str, str]:
    """
    构建序号→文件名映射（seq_map）。
    顺序：主任务（按 group 顺序）→ 习惯（有序号时）→ 候选池。
    value 为 md_filename，与 task_map.py 约定一致。
    """
    seq_map: Dict[str, str] = {}
    seq = 1

    # 主任务：遍历所有分组，值统一存 task_id（Agent 可直接用于 batch_update/write_task）
    for groups in all_task_groups:
        for group in groups:
            for task in group.get('tasks', []):
                task_id = task.get('id', '')
                seq_map[str(seq)] = task_id  # 直接存 task_id，不存 filename
                seq += 1

    # 习惯（序号指代习惯实例，存 habit 名称供识别）
    for habit in habits:
        seq_map[str(seq)] = f'habit:{habit.get("name", "unknown")}'
        seq += 1

    # 候选池
    for task in candidate_tasks:
        task_id = task.get('id', 'unknown')
        seq_map[str(seq)] = task_id
        seq += 1

    return seq_map


def _ensure_habit_instances(target_date: str) -> None:
    """
    晨间规划兜底：确保当日习惯实例已创建。
    即使昨晚复盘未执行，今天的习惯也会在晨间规划时自动补创建。
    调用 create_habit_instance.py（幂等，已存在不重复创建）。
    """
    import subprocess
    scripts_dir = Path(__file__).parent
    script = scripts_dir / 'create_habit_instance.py'
    if not script.exists():
        print(f'[WARN] create_habit_instance.py 不存在，跳过习惯兜底检查', file=sys.stderr)
        return
    result = subprocess.run(
        [sys.executable, str(script), '--date', target_date],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        print(f'[WARN] 习惯实例创建失败：{result.stderr.strip()}', file=sys.stderr)
    elif result.stdout.strip():
        # 有新创建的习惯，输出到 stderr 供调试（不污染 stdout）
        for line in result.stdout.strip().splitlines():
            if '已创建' in line:
                print(f'[INFO] 习惯兜底补创建：{line.strip()}', file=sys.stderr)


def build_morning_plan(conn: sqlite3.Connection, target_date: str) -> Dict[str, Any]:
    """晨间规划模式"""
    today = target_date

    # 1. 今日候选任务
    today_tasks = query_today_candidates(conn, today)

    # 2. 过期 schedule 任务（→ delayed_tasks）
    delayed = query_overdue_schedule(conn, today)

    # 3. DDL 逾期任务（→ ddl_warnings）
    overdue_ddl = query_overdue_ddl(conn, today)

    # 4. DDL 7天内临近（→ ddl_warnings）
    ddl_7 = query_ddl_within_n(conn, today, 7)

    # 5. 等待任务（融入主任务列表）
    waiting = query_waiting(conn)

    # 6. inbox 候选池（过滤掉已有 schedule_date 的任务，方向2：有日期=已激活active，不应出现在候选池）
    inbox_all = query_inbox(conn)
    inbox = [t for t in inbox_all if not t.get('schedule')]

    # 7. 今日习惯（兜底：自动创建当日缺失的习惯实例，无需依赖昨晚复盘）
    _ensure_habit_instances(today)
    habits = query_habits(conn, today)

    # 合并今日任务（含等待）并去重
    main_task_ids = {t['id'] for t in today_tasks}
    for t in waiting:
        if t['id'] not in main_task_ids:
            today_tasks.append(t)
            main_task_ids.add(t['id'])

    # 保留 filename 用于 seq_map
    for t in today_tasks:
        t['_filename'] = t.get('filename', f"{t['id']}.md")
    for t in inbox:
        t['_filename'] = t.get('filename', f"{t['id']}.md")

    # 构建项目分组（工作/生活分区）
    work_tasks = [t for t in today_tasks if t.get('area') == 'work']
    life_tasks = [t for t in today_tasks if t.get('area') != 'work']

    work_groups = group_by_project(work_tasks)
    life_groups = group_by_project(life_tasks)
    all_groups = work_groups + life_groups

    # DDL 提醒（合并逾期+临近，去重）
    ddl_warning_ids = set()
    ddl_warnings = []
    for t in overdue_ddl + ddl_7:
        if t['id'] not in ddl_warning_ids and t.get('ddl'):
            ddl_warning_ids.add(t['id'])
            try:
                days_remaining = (date.fromisoformat(t['ddl']) - date.fromisoformat(today)).days
            except ValueError:
                days_remaining = 0
            ddl_warnings.append({
                'task_id': t['id'],
                'title': t['title'],
                'ddl': t['ddl'],
                'days_remaining': days_remaining,
            })

    # 构建 seq_map（value = task_id，Agent 可直接用于操作）
    seq = 1
    seq_map: Dict[str, str] = {}
    for group in all_groups:
        for task in group['tasks']:
            task.pop('_filename', None)  # 清理内部字段
            seq_map[str(seq)] = task['id']
            seq += 1
    for habit in habits:
        seq_map[str(seq)] = f'habit:{habit.get("name", "unknown")}'
        seq += 1
    for task in inbox:
        task.pop('_filename', None)
        seq_map[str(seq)] = task['id']
        seq += 1

    # 候选池：清理 _filename
    candidate_pool = []
    for t in inbox:
        candidate_pool.append({
            'id': t['id'],
            'title': t['title'],
            'priority': t['priority'],
            'area': t.get('area'),
            'project': t.get('project'),
            'schedule': t.get('schedule'),
            'ddl': t.get('ddl'),
            'status': t['status'],
            'note': '',
            'overdue_days': t.get('overdue_days'),
            'delayed': False,
            'time_slot': None,
        })

    # delayed_tasks：清理内部字段
    delayed_tasks_clean = []
    for t in delayed:
        delayed_tasks_clean.append({
            'id': t['id'],
            'title': t['title'],
            'priority': t['priority'],
            'area': t.get('area'),
            'project': t.get('project'),
            'schedule': t.get('schedule'),
            'ddl': t.get('ddl'),
            'status': t['status'],
            'note': '今日顺延',
            'overdue_days': t.get('overdue_days'),
            'delayed': True,
            'time_slot': None,
        })

    return {
        'date': target_date,
        'mode': 'morning',
        'projects': all_groups,
        'habits': habits,
        'candidate_pool': candidate_pool,
        'ddl_warnings': ddl_warnings,
        'delayed_tasks': delayed_tasks_clean,
        'seq_map': seq_map,
    }


def build_midday_plan(conn: sqlite3.Connection, target_date: str) -> Dict[str, Any]:
    """日间盘点模式"""
    today = target_date

    # 今日进行中（schedule=today，status=active）
    active_tasks = query_today_active(conn, today)
    # 今日已完成（completed_at=today）
    done_tasks = query_done_today(conn, today)
    # 过期 schedule 浮出
    delayed = query_overdue_schedule(conn, today)
    # 习惯
    habits = query_habits(conn, today)

    # 区分「今日计划内完成」和「跨日完成（昨天排期今天完成）」
    # 今日计划内完成：schedule_date = today
    # 跨日完成（计划外/昨日顺延）：schedule_date != today 或 NULL
    done_today_planned   = [t for t in done_tasks if t.get('schedule') == today]
    done_today_crossday  = [t for t in done_tasks if t.get('schedule') != today]

    # 主视图：今日进行中 + 今日计划内完成
    all_tasks = active_tasks + done_today_planned
    work_tasks = [t for t in all_tasks if t.get('area') == 'work']
    life_tasks = [t for t in all_tasks if t.get('area') != 'work']

    all_groups = group_by_project(work_tasks) + group_by_project(life_tasks)

    # 跨日完成：归入 unplanned_done（计划外/顺延完成），在表格中单独展示
    crossday_groups = []
    if done_today_crossday:
        crossday_work = [t for t in done_today_crossday if t.get('area') == 'work']
        crossday_life = [t for t in done_today_crossday if t.get('area') != 'work']
        crossday_groups = group_by_project(crossday_work) + group_by_project(crossday_life)

    # seq_map：主视图 + 跨日完成区都参与序号，value = task_id
    seq = 1
    seq_map: Dict[str, str] = {}
    for group in all_groups + crossday_groups:
        for task in group['tasks']:
            seq_map[str(seq)] = task.get('id', 'unknown')
            seq += 1

    delayed_tasks_clean = []
    for t in delayed:
        delayed_tasks_clean.append({
            'id': t['id'],
            'title': t['title'],
            'priority': t['priority'],
            'area': t.get('area'),
            'project': t.get('project'),
            'schedule': t.get('schedule'),
            'ddl': t.get('ddl'),
            'status': t['status'],
            'note': '今日顺延',
            'overdue_days': t.get('overdue_days'),
            'delayed': True,
            'time_slot': None,
        })

    return {
        'date': target_date,
        'mode': 'midday',
        'projects': all_groups,
        'crossday_done': crossday_groups,   # 跨日完成（昨日排期今日完成）
        'habits': habits,
        'candidate_pool': [],
        'ddl_warnings': [],
        'delayed_tasks': delayed_tasks_clean,
        'seq_map': seq_map,
    }


def build_next_day_plan(conn: sqlite3.Connection, target_date: str) -> Dict[str, Any]:
    """规划明天模式"""
    today = target_date
    # v3.0.1 fix: tomorrow 基于 target_date 而非系统当前日期
    tomorrow = (date.fromisoformat(target_date) + timedelta(days=1)).isoformat()

    # 今日顺延（schedule=today 但未完成）
    today_remaining = query_today_candidates(conn, today)
    today_remaining = [t for t in today_remaining if t['status'] != 'done']

    # 明日已有安排
    tomorrow_tasks = query_tomorrow_scheduled(conn, tomorrow)

    # 过期 schedule 浮出
    delayed = query_overdue_schedule(conn, today)

    # inbox 候选
    # Bug B+C 修复：
    # - 过滤掉 schedule_date = tomorrow 的 inbox 任务（已在主任务区，避免双重展示）
    # - 过滤掉任何已有 schedule_date 的 inbox 任务（已安排的不应进候选池）
    inbox_all = query_inbox(conn)
    main_task_ids = {t['id'] for t in tomorrow_tasks}
    inbox = [
        t for t in inbox_all
        if t['id'] not in main_task_ids          # 不在主任务区
        and not t.get('schedule')                 # 没有执行日期
    ]

    # 明日习惯（从 habit_definitions 直接拿定义，因为明日实例还未创建）
    # 按执行日过滤：daily=每天，weekday=周一~五，weekend=周六~日，custom=按 execution_days
    from datetime import date as _date
    tomorrow_date = _date.fromisoformat(tomorrow)
    tomorrow_weekday = tomorrow_date.weekday()  # 0=Mon … 6=Sun

    habits_sql = """
        SELECT id, name, area, frequency, execution_days FROM habit_definitions
        WHERE is_active = 1 ORDER BY id ASC
    """
    habit_rows = conn.execute(habits_sql).fetchall()
    habits = []
    for r in habit_rows:
        freq = (r['frequency'] or 'daily').lower().strip()
        should_run = False
        if freq == 'daily':
            should_run = True
        elif freq in ('weekday', 'weekdays', '工作日'):
            should_run = tomorrow_weekday <= 4
        elif freq in ('weekend', 'weekends', '周末'):
            should_run = tomorrow_weekday >= 5
        elif freq == 'custom':
            try:
                import json as _json
                exec_days = _json.loads(r['execution_days'] or '[]')
                should_run = tomorrow_weekday in exec_days
            except Exception:
                should_run = True  # 解析失败兜底为执行
        else:
            should_run = True  # 未知频率兜底为执行

        if should_run:
            habits.append({'name': r['name'], 'time': '', 'status': 'pending'})

    # 合并今日顺延+明日已有，去重
    all_task_ids = set()
    main_tasks = []
    for t in today_remaining + tomorrow_tasks:
        if t['id'] not in all_task_ids:
            all_task_ids.add(t['id'])
            main_tasks.append(t)

    work_tasks = [t for t in main_tasks if t.get('area') == 'work']
    life_tasks = [t for t in main_tasks if t.get('area') != 'work']
    all_groups = group_by_project(work_tasks) + group_by_project(life_tasks)

    # seq_map，value = task_id
    seq = 1
    seq_map: Dict[str, str] = {}
    for group in all_groups:
        for task in group['tasks']:
            seq_map[str(seq)] = task.get('id', 'unknown')
            seq += 1
    for t in inbox:
        seq_map[str(seq)] = t.get('id', 'unknown')
        seq += 1

    # 候选池
    candidate_pool = [{
        'id': t['id'],
        'title': t['title'],
        'priority': t['priority'],
        'area': t.get('area'),
        'project': t.get('project'),
        'schedule': t.get('schedule'),
        'ddl': t.get('ddl'),
        'status': t['status'],
        'note': '',
        'overdue_days': t.get('overdue_days'),
        'delayed': False,
        'time_slot': None,
    } for t in inbox]

    delayed_tasks_clean = [{
        'id': t['id'],
        'title': t['title'],
        'priority': t['priority'],
        'area': t.get('area'),
        'project': t.get('project'),
        'schedule': t.get('schedule'),
        'ddl': t.get('ddl'),
        'status': t['status'],
        'note': '今日顺延',
        'overdue_days': t.get('overdue_days'),
        'delayed': True,
        'time_slot': None,
    } for t in delayed]

    return {
        'date': tomorrow,  # next-day 计划的日期是明天
        'mode': 'next-day',
        'projects': all_groups,
        'habits': habits,
        'candidate_pool': candidate_pool,
        'ddl_warnings': [],
        'delayed_tasks': delayed_tasks_clean,
        'seq_map': seq_map,
    }


# ── Schema 校验 ───────────────────────────────────────────────────────────────

def validate_plan(plan: Dict[str, Any]) -> bool:
    """用 schemas.py 的 DailyPlan 模型校验输出（内部直接 import）"""
    try:
        scripts_dir = Path(__file__).parent
        sys.path.insert(0, str(scripts_dir))
        from schemas import DailyPlan
        import pydantic
        PYDANTIC_V2 = int(pydantic.VERSION.split('.')[0]) >= 2
        if PYDANTIC_V2:
            DailyPlan.model_validate(plan)
        else:
            DailyPlan(**plan)
        return True
    except Exception as e:
        print(f'[ERROR] DailyPlan schema 校验失败：{e}', file=sys.stderr)
        return False


# ── 主入口 ────────────────────────────────────────────────────────────────────

def _render_quick_review(conn: sqlite3.Connection, rtype: str, key: str, config: dict) -> None:
    """
    快速版复盘草稿生成（--mode quick-review）
    输出：数据区（自动填充）+ 确认区（AI 推断 + 用户确认）
    末尾附 TASK_SEQ_MAP（用于序号操作）
    """
    from datetime import date
    rocky_voice = config.get('rocky_voice', True)

    # ── 1. 查询复盘数据 ──────────────────────────────────────────────────────
    if rtype == 'weekly':
        # 解析周 key（YYYY-WNN）
        import re
        m = re.match(r'(\d{4})-W(\d{2})', key)
        if not m:
            print(f'[ERROR] 无效的 weekly key：{key}（格式：YYYY-WNN）', file=sys.stderr)
            sys.exit(1)
        year, week = int(m.group(1)), int(m.group(2))
        # 计算周起止日期
        jan4 = date(year, 1, 4)
        week_start = jan4 - timedelta(days=jan4.weekday()) + timedelta(weeks=week-1)
        week_end = week_start + timedelta(days=6)
        period_label = f'{week_start.strftime("%m/%d")}-{week_end.strftime("%m/%d")}'
        date_range = (week_start.isoformat(), week_end.isoformat())
        next_period_label = '下周'
    else:
        # monthly
        import re
        m = re.match(r'(\d{4})-(\d{2})', key)
        if not m:
            print(f'[ERROR] 无效的 monthly key：{key}（格式：YYYY-MM）', file=sys.stderr)
            sys.exit(1)
        year, month = int(m.group(1)), int(m.group(2))
        import calendar
        last_day = calendar.monthrange(year, month)[1]
        week_start = date(year, month, 1)
        week_end = date(year, month, last_day)
        period_label = f'{year}/{month:02d}'
        date_range = (week_start.isoformat(), week_end.isoformat())
        next_period_label = '下月'

    # 查完成任务
    done_rows = conn.execute('''
        SELECT id, title, area, project_id, completed_at, schedule_date, source
        FROM tasks
        WHERE is_deleted=0 AND status='done'
        AND completed_at >= ? AND completed_at <= ?
        ORDER BY area, project_id, completed_at
    ''', (date_range[0] + 'T00:00:00', date_range[1] + 'T23:59:59')).fetchall()

    work_done = [r for r in done_rows if r['area'] == 'work']
    life_done = [r for r in done_rows if r['area'] == 'life']
    work_unplanned = [r for r in work_done if not r['schedule_date'] or r['source'] == 'unplanned']
    life_unplanned = [r for r in life_done if not r['schedule_date'] or r['source'] == 'unplanned']

    # 查习惯
    habit_rows = conn.execute('''
        SELECT hi.id, hd.name, hi.date, hi.status
        FROM habit_instances hi
        JOIN habit_definitions hd ON hi.habit_id = hd.id
        WHERE hi.date >= ? AND hi.date <= ?
        ORDER BY hd.name, hi.date
    ''', (date_range[0], date_range[1])).fetchall()

    # 查未完成/顺延
    overdue_rows = conn.execute('''
        SELECT id, title, area, project_id, schedule_date
        FROM tasks
        WHERE is_deleted=0 AND status='active'
        AND schedule_date >= ? AND schedule_date <= ?
        ORDER BY area, project_id
    ''', (date_range[0], date_range[1])).fetchall()

    # 查下期已安排
    next_start = (week_end + timedelta(days=1)).isoformat()
    next_end = (week_end + timedelta(days=31 if rtype=='monthly' else 7)).isoformat()
    next_rows = conn.execute('''
        SELECT id, title, area, project_id, schedule_date, priority
        FROM tasks
        WHERE is_deleted=0 AND status='active'
        AND schedule_date >= ? AND schedule_date <= ?
        ORDER BY priority DESC, area, title
    ''', (next_start, next_end)).fetchall()

    # ── 2. 渲染数据区 ─────────────────────────────────────────────────────────
    lines = []
    lines.append(f'━━━ 📊 {key}（{period_label}）数据（已自动填充）━━━')
    lines.append('')
    lines.append(f'**完成率：**')
    lines.append(f'  💼 工作：{len(work_done)} 项（计划外 {len(work_unplanned)} 项）')
    lines.append(f'  🏠 生活：{len(life_done)} 项（计划外 {len(life_unplanned)} 项）')

    # 习惯汇总
    habit_summary: Dict[str, Dict] = {}
    for h in habit_rows:
        name = h['name']
        if name not in habit_summary:
            habit_summary[name] = {'done': 0, 'cancelled': 0, 'pending': 0}
        habit_summary[name][h['status']] = habit_summary[name].get(h['status'], 0) + 1
    if habit_summary:
        parts = []
        for name, counts in habit_summary.items():
            done_c = counts.get('done', 0)
            total = sum(counts.values())
            parts.append(f'{name} ✅×{done_c}')
        lines.append(f'  🏃 习惯：{" · ".join(parts)}')

    if overdue_rows:
        lines.append('')
        lines.append(f'**未完成/顺延（{len(overdue_rows)} 项）：**')
        for r in overdue_rows[:5]:
            lines.append(f'  · {r["title"]}')
        if len(overdue_rows) > 5:
            lines.append(f'  · ...（共 {len(overdue_rows)} 项）')

    if next_rows:
        lines.append('')
        lines.append(f'**{next_period_label}已安排（{len(next_rows)} 项）：**')
        for r in next_rows[:5]:
            lines.append(f'  · {r["title"]}')
        if len(next_rows) > 5:
            lines.append(f'  · ...（共 {len(next_rows)} 项）')

    # ── 3. 渲染确认区 ─────────────────────────────────────────────────────────
    lines.append('')
    lines.append(f'━━━ ✏️ 请确认 ━━━')

    # ① 精力重心（按项目完成量推断）
    project_counts: Dict[str, int] = {}
    for r in work_done:
        pid = r['project_id'] or '无项目'
        project_counts[pid] = project_counts.get(pid, 0) + 1
    top_project = max(project_counts, key=lambda x: project_counts[x]) if project_counts else '（无数据）'
    lines.append(f'① {"本" + ("周" if rtype=="weekly" else "月")}精力重心：{top_project}（AI 基于完成量推断）')

    # ② 下期重点 3 件事
    top3 = next_rows[:3]
    if top3:
        lines.append(f'② {next_period_label}重点 3 件事：')
        for i, r in enumerate(top3, 1):
            lines.append(f'   {i}. {r["title"]}')
    else:
        lines.append(f'② {next_period_label}重点 3 件事：（暂无已安排任务，请补充）')

    lines.append(f'③ {"本" + ("周" if rtype=="weekly" else "月")}感悟：（选填）')
    lines.append('')
    lines.append('直接说「确认」全部接受，或「①改成 XX」「②第2条改成 XX」「③写：...」「③跳过」')

    # ── 4. TASK_SEQ_MAP（下期任务序号映射）──────────────────────────────────
    seq_map: Dict[str, str] = {}
    for i, r in enumerate(next_rows, 1):
        seq_map[str(i)] = r['id']
    seq_map_comment = f'<!-- TASK_SEQ_MAP session=quick-review-{key} map={json.dumps(seq_map, ensure_ascii=False)} -->'
    render_check = f'<!-- RENDER_CHECK: tasks={len(done_rows)} -->'

    print('\n'.join(lines))
    print(seq_map_comment)
    print(render_check)
    print(f'[OK] 快速复盘草稿生成完成（{rtype} {key}，完成 {len(done_rows)} 项）', file=sys.stderr)


def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro - 自动组装 DailyPlan JSON',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument('--date', default=date.today().isoformat(),
                        help='目标日期 YYYY-MM-DD（默认今天）')
    parser.add_argument(
        '--mode', choices=['morning', 'midday', 'next-day', 'quick-review'],
        default='morning',
        help='规划模式：morning（晨间）/ midday（日间盘点）/ next-day（规划明天）/ quick-review（快速复盘草稿）',
    )
    parser.add_argument('--output', '-o', default=None,
                        help='输出 JSON 文件路径（不指定则输出到 stdout）')
    parser.add_argument('--no-validate', action='store_true',
                        help='跳过 schema 校验（调试用）')
    parser.add_argument('--render', action='store_true',
                        help='渲染模式：内部完成 schema 校验 + 渲染，直接输出 Markdown 到 stdout')
    parser.add_argument('--format', '-f', choices=['md', 'plain'], default='md',
                        help='输出格式：md（默认）/ plain（纯文本，企微 Bot / 移动端场景）')
    parser.add_argument('--no-candidate', action='store_true',
                        help='渲染时不输出候选池（仅展示已激活任务）')
    # quick-review 专用参数
    parser.add_argument('--type', choices=['weekly', 'monthly'], default=None,
                        help='快速复盘类型（quick-review 模式必填）')
    parser.add_argument('--key', default=None,
                        help='快速复盘周期 key（如 2026-W15 或 2026-04）')
    args = parser.parse_args()

    config = load_config()
    db_path = config['db_path']

    if not Path(db_path).exists():
        print(f'[ERROR] 数据库不存在：{db_path}，请先运行 python db_init.py', file=sys.stderr)
        sys.exit(1)

    conn = get_connection(db_path)
    try:
        if args.mode == 'morning':
            plan = build_morning_plan(conn, args.date)
        elif args.mode == 'midday':
            plan = build_midday_plan(conn, args.date)
        elif args.mode == 'next-day':
            plan = build_next_day_plan(conn, args.date)
        elif args.mode == 'quick-review':
            if not args.type or not args.key:
                print('[ERROR] quick-review 模式需要 --type 和 --key 参数', file=sys.stderr)
                print('  示例：build_plan.py --mode quick-review --type weekly --key 2026-W15 --render', file=sys.stderr)
                sys.exit(1)
            _render_quick_review(conn, args.type, args.key, config)
            conn.close()
            return
        else:
            print(f'[ERROR] 未知 mode：{args.mode}', file=sys.stderr)
            sys.exit(1)
    finally:
        if args.mode != 'quick-review':
            conn.close()

    # Schema 校验（--render 模式下校验失败直接 exit 1，不降级）
    if not args.no_validate:
        valid = validate_plan(plan)
        if not valid:
            if args.render:
                print('[ERROR] Schema 校验失败，--render 模式不允许降级，请检查数据', file=sys.stderr)
                sys.exit(1)
            else:
                print('[WARN] Schema 校验失败，降级：跳过校验直接输出（请检查数据）', file=sys.stderr)
        else:
            print(f'[OK] DailyPlan schema 校验通过', file=sys.stderr)

    # 序列化
    json_str = json.dumps(plan, ensure_ascii=False, indent=2)

    # 构建 TASK_SEQ_MAP 注释
    seq_map = plan.get('seq_map', {})
    seq_map_comment = (
        f'\n<!-- TASK_SEQ_MAP session={args.mode}-plan-{plan["date"]} '
        f'map={json.dumps(seq_map, ensure_ascii=False)} -->'
    )

    # ── 写 JSON 文件（--output 时）
    if args.output:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            output_path.write_text(json_str, encoding='utf-8')
            # TASK_SEQ_MAP 注释附加到 JSON 文件末尾
            with open(args.output, 'a', encoding='utf-8') as f:
                f.write(seq_map_comment)
            print(f'[OK] DailyPlan JSON 已写入：{args.output}', file=sys.stderr)
            print(f'[INFO] seq_map 包含 {len(seq_map)} 条序号映射', file=sys.stderr)
        except OSError as e:
            print(f'[ERROR] JSON 文件写入失败：{e}', file=sys.stderr)
            sys.exit(1)

    # ── --render 模式：内部调用 render_table 渲染输出 Markdown
    if args.render:
        try:
            _scripts_dir = Path(__file__).parent
            import importlib.util as _ilu
            _spec = _ilu.spec_from_file_location('render_table', str(_scripts_dir / 'render_table.py'))
            if _spec is None or _spec.loader is None:
                raise ImportError('spec 加载失败')
            _rt = _ilu.module_from_spec(_spec)
            _spec.loader.exec_module(_rt)  # type: ignore
        except Exception as e:
            print(f'[ERROR] render_table 模块加载失败，请检查脚本目录：{e}', file=sys.stderr)
            sys.exit(1)

        # 调用 render_table 的核心渲染函数（与独立调用路径完全一致）
        try:
            markdown_out = _rt.render_daily_plan(
                plan,
                no_candidate=getattr(args, 'no_candidate', False),
                fmt=getattr(args, 'format', 'md'),
            )
        except Exception as e:
            print(f'[ERROR] 渲染失败：{e}', file=sys.stderr)
            sys.exit(1)

        # 统计任务总数（用于 RENDER_CHECK）
        task_count = sum(len(g.get('tasks', [])) for g in plan.get('projects', []))
        task_count += len(plan.get('habits', []))
        render_check = f'<!-- RENDER_CHECK: tasks={task_count} -->'

        # v3.0：渲染结果直接输出到 stdout（不再写文件）
        print(markdown_out)

        # v3.0.1: 根据 mode 输出引导语（消除 AI 额外写总结的动机）
        mode = args.mode
        no_candidate = getattr(args, 'no_candidate', False)
        rocky_voice = config.get('rocky_voice', True)
        delayed_count = len(plan.get('delayed_tasks', []))

        if mode == 'morning' and not no_candidate:
            print('\n---')
            if rocky_voice and delayed_count > 0:
                print(f'发现 {delayed_count} 条过期任务。人类的大脑没用！不过 Rocky 会帮你。')
            print('以上是今日候选任务。需要调整优先级、激活候选、顺延或处理过期任务吗？')
        elif mode == 'morning' and no_candidate:
            candidate_count = len(plan.get('candidate_pool', []))
            if rocky_voice:
                print(f'\n候选池 {candidate_count} 条未激活，保留 inbox 待下次安排。碰个拳🤜🤛？')
            else:
                print(f'\n候选池 {candidate_count} 条未激活，保留 inbox 待下次安排。')
        elif mode == 'midday':
            print('\n---')
            print('以上是今天的任务情况。哪些已完成？有计划外完成的事项吗？')
        elif mode == 'next-day':
            print('\n---')
            if rocky_voice:
                print('以上是明天的安排，需要调整吗？明天见，朋友。Rocky 都记着呢。')
            else:
                print('以上是明天的安排，需要调整吗？')

        print(seq_map_comment)
        print(render_check)
        print(f'[OK] 渲染完成（tasks={task_count}）', file=sys.stderr)
        return  # --render 模式下不再输出 JSON 到 stdout

    # ── 非 --render 模式：原有行为（--output 已处理；否则输出到 stdout）
    if not args.output:
        print(json_str)
        print(seq_map_comment)


if __name__ == '__main__':
    main()
