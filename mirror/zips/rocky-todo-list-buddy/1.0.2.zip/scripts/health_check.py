#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
health_check.py - LifeOps Pro 数据一致性检查脚本
版本：v3.0.0

功能：纯 SQLite 数据一致性检查（v3.0：不再检查 Markdown 文件）。

检查项：
  1. 状态一致性：done 任务必须有 completed_at，非 done 任务不应有 completed_at
  2. 日期逻辑：schedule_date/due_date 格式正确
  3. active 但无 schedule：active 状态任务是否缺少 schedule_date（建议安排）
  4. 孤儿 habit_instances：引用了不存在的 habit_definition
  5. 重复任务：相同 title + 相同 schedule_date 的重复记录

用法：
  python health_check.py           # 全量检查
  python health_check.py --fix     # 自动修复（补全 completed_at 等）
"""

import sys
import json
import sqlite3
import argparse
import re
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any


def load_config() -> dict:
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config['db_path'] = str(Path(config['db_path']).expanduser())
    return config


def get_connection(db_path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    return conn


# ============================================================
# 检查项实现
# ============================================================

def check_done_without_completed_at(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """检查 status=done 但 completed_at 为空的任务"""
    rows = conn.execute(
        "SELECT id, title, status, completed_at FROM tasks "
        "WHERE is_deleted=0 AND status='done' AND (completed_at IS NULL OR completed_at='')"
    ).fetchall()
    return [dict(r) for r in rows]


def check_completed_at_without_done(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """检查有 completed_at 但 status 不是 done 的任务"""
    rows = conn.execute(
        "SELECT id, title, status, completed_at FROM tasks "
        "WHERE is_deleted=0 AND status != 'done' AND completed_at IS NOT NULL AND completed_at != ''"
    ).fetchall()
    return [dict(r) for r in rows]


def check_active_without_schedule(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """检查 active 状态但没有 schedule_date 的任务（建议安排日期）"""
    rows = conn.execute(
        "SELECT id, title, priority, created_at FROM tasks "
        "WHERE is_deleted=0 AND status='active' AND (schedule_date IS NULL OR schedule_date='')"
    ).fetchall()
    return [dict(r) for r in rows]


def check_invalid_dates(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """检查日期格式异常（非 YYYY-MM-DD 格式）"""
    date_pattern = re.compile(r'^\d{4}-\d{2}-\d{2}')
    issues = []
    rows = conn.execute(
        "SELECT id, title, schedule_date, due_date FROM tasks WHERE is_deleted=0"
    ).fetchall()
    for r in rows:
        for field in ('schedule_date', 'due_date'):
            val = r[field]
            if val and not date_pattern.match(str(val)):
                issues.append({
                    'id': r['id'], 'title': r['title'],
                    'field': field, 'value': val,
                    'issue': f'{field} 格式异常'
                })
    return issues


def check_orphan_habit_instances(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """检查引用了不存在的 habit_definition 的 habit_instances"""
    try:
        rows = conn.execute(
            "SELECT hi.id, hi.habit_id, hi.target_date FROM habit_instances hi "
            "LEFT JOIN habit_definitions hd ON hi.habit_id = hd.id "
            "WHERE hd.id IS NULL"
        ).fetchall()
        return [dict(r) for r in rows]
    except sqlite3.OperationalError:
        return []


def check_duplicate_tasks(conn: sqlite3.Connection) -> List[Dict[str, Any]]:
    """检查相同 title + schedule_date 的重复任务"""
    rows = conn.execute(
        "SELECT title, schedule_date, COUNT(*) as cnt, GROUP_CONCAT(id) as ids "
        "FROM tasks WHERE is_deleted=0 AND status IN ('active', 'inbox') "
        "GROUP BY title, schedule_date HAVING cnt > 1"
    ).fetchall()
    return [dict(r) for r in rows]


# ============================================================
# 修复逻辑
# ============================================================

def fix_done_without_completed_at(conn: sqlite3.Connection, tasks: List[Dict]) -> int:
    """为 done 但无 completed_at 的任务补全 completed_at"""
    fixed = 0
    for t in tasks:
        conn.execute(
            "UPDATE tasks SET completed_at = updated_at WHERE id = ?",
            (t['id'],)
        )
        fixed += 1
    conn.commit()
    return fixed


# ============================================================
# 主函数
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro 数据一致性检查（v3.0 纯 SQLite）')
    parser.add_argument('--fix', action='store_true', help='自动修复可修复的问题')
    args = parser.parse_args()

    config = load_config()
    conn = get_connection(config['db_path'])

    total_issues = 0

    # 1. done 无 completed_at
    issues = check_done_without_completed_at(conn)
    if issues:
        print(f"⚠️  done 但无 completed_at：{len(issues)} 条")
        for t in issues:
            print(f"   {t['id']} | {t['title']}")
        if args.fix:
            fixed = fix_done_without_completed_at(conn, issues)
            print(f"   ✅ 已修复 {fixed} 条（用 updated_at 补全）")
        total_issues += len(issues)
    else:
        print("✅ done 任务 completed_at 检查通过")

    # 2. 有 completed_at 但非 done
    issues = check_completed_at_without_done(conn)
    if issues:
        print(f"⚠️  有 completed_at 但 status≠done：{len(issues)} 条")
        for t in issues:
            print(f"   {t['id']} | {t['title']} | status={t['status']} | completed_at={t['completed_at']}")
        total_issues += len(issues)
    else:
        print("✅ completed_at 与 status 一致性检查通过")

    # 3. active 无 schedule
    issues = check_active_without_schedule(conn)
    if issues:
        print(f"ℹ️  active 但无 schedule_date：{len(issues)} 条（建议安排日期）")
        for t in issues:
            print(f"   {t['id']} | {t['title']}")
        total_issues += len(issues)
    else:
        print("✅ active 任务 schedule_date 检查通过")

    # 4. 日期格式
    issues = check_invalid_dates(conn)
    if issues:
        print(f"⚠️  日期格式异常：{len(issues)} 条")
        for t in issues:
            print(f"   {t['id']} | {t['title']} | {t['field']}={t['value']}")
        total_issues += len(issues)
    else:
        print("✅ 日期格式检查通过")

    # 5. 孤儿 habit_instances
    issues = check_orphan_habit_instances(conn)
    if issues:
        print(f"⚠️  孤儿 habit_instances：{len(issues)} 条")
        for t in issues:
            print(f"   instance={t['id']} | habit_id={t['habit_id']}")
        total_issues += len(issues)
    else:
        print("✅ habit_instances 引用检查通过")

    # 6. 重复任务
    issues = check_duplicate_tasks(conn)
    if issues:
        print(f"⚠️  疑似重复任务：{len(issues)} 组")
        for t in issues:
            print(f"   {t['title']} | schedule={t['schedule_date']} | count={t['cnt']} | ids={t['ids']}")
        total_issues += len(issues)
    else:
        print("✅ 重复任务检查通过")

    conn.close()

    print(f"\n{'='*40}")
    if total_issues == 0:
        print("🎉 所有检查通过，数据库状态健康")
    else:
        print(f"共发现 {total_issues} 个问题")
        if not args.fix:
            print("提示：使用 --fix 自动修复可修复的问题")


if __name__ == '__main__':
    main()
