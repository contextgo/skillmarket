#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
batch_update.py - LifeOps Pro 批量任务操作脚本
版本：v1.0.0

功能：将多个任务操作合并为单次执行，消除 AI 多轮 tool call 的 round-trip 开销。
每个操作独立事务，单条失败不影响其他操作，全部结果汇总返回。

解决问题：N 个 write_task.py update 调用 = N 次 tool call + N 次上下文追加
使用本脚本：N 个操作 = 1 次 tool call，上下文追加量减少 ~80%

用法：
  # JSON 内联
  python batch_update.py --ops '[
    {"id": "T-xxx", "schedule": "2026-04-06"},
    {"id": "T-yyy", "status": "cancelled"},
    {"id": "T-zzz", "status": "done"},
    {"id": "T-aaa", "priority": "high", "schedule": "2026-04-07"}
  ]'

  # 从文件读取
  python batch_update.py --ops-file /tmp/ops.json

  # 预览模式（不实际写入）
  python batch_update.py --ops '[...]' --dry-run

支持的操作字段（与 write_task.py update 保持一致）：
  id          任务 ID（必填）
  status      新状态：inbox / active / done / cancelled / someday
  priority    优先级：urgent / high / normal / waiting
  schedule    计划执行日期 YYYY-MM-DD
  ddl         截止日期 YYYY-MM-DD
  project     项目 ID（如 P-播客项目）
  snooze      snooze 日期 YYYY-MM-DD，或 "clear" 清除
  completed_at 完成时间（status=done 时可选）ISO 8601 格式
"""

import argparse
import json
import sys
from datetime import datetime, date
from pathlib import Path
from typing import Any, Dict, List, Optional

# 复用 write_task.py 的核心函数
_SCRIPTS = Path(__file__).parent
sys.path.insert(0, str(_SCRIPTS))
from write_task import (
    load_config,
    get_connection,
    update_task_fields,
    ensure_project,
    _normalize_date,
    _normalize_datetime,
)


# ============================================================
# 操作解析
# ============================================================

VALID_STATUSES   = {'inbox', 'active', 'done', 'cancelled', 'someday'}
VALID_PRIORITIES = {'urgent', 'high', 'normal', 'waiting'}


def parse_op(op: Dict[str, Any], op_index: int) -> tuple[str, Dict[str, Any], Optional[str]]:
    """
    解析单条操作，返回 (task_id, updates_dict, error_msg)。
    error_msg 为 None 表示解析成功。
    """
    task_id = op.get('id', '').strip()
    if not task_id:
        return '', {}, f'op[{op_index}] 缺少 id 字段'

    updates: Dict[str, Any] = {}

    # status
    if 'status' in op:
        s = str(op['status']).lower()
        if s not in VALID_STATUSES:
            return task_id, {}, f'{task_id}: 无效 status={s}，有效值: {sorted(VALID_STATUSES)}'
        updates['status'] = s
        if s == 'done':
            if op.get('completed_at'):
                # 用户明确指定完成时间，直接使用
                completed_at = _normalize_datetime(op['completed_at']) or datetime.now().isoformat()
            else:
                # 未指定完成时间：若任务有历史排期（schedule_date < today），默认归排期日期
                # 避免补录昨天的任务时 completed_at 写成今天，污染今日统计
                schedule_date = _normalize_date(op.get('schedule', ''))
                today = date.today().isoformat()
                if schedule_date and schedule_date < today:
                    completed_at = schedule_date + ' 23:59:00'
                    if (date.today() - date.fromisoformat(schedule_date)).days > 30:
                        print(f'[WARN] {task_id}: 补录超过 30 天前的历史任务，completed_at 设为 {completed_at}')
                else:
                    completed_at = datetime.now().isoformat()
            updates['completed_at'] = completed_at

    # priority
    if 'priority' in op:
        p = str(op['priority']).lower()
        if p not in VALID_PRIORITIES:
            return task_id, {}, f'{task_id}: 无效 priority={p}，有效值: {sorted(VALID_PRIORITIES)}'
        updates['priority'] = p

    # schedule
    if 'schedule' in op:
        d = _normalize_date(op['schedule'])
        if not d:
            return task_id, {}, f'{task_id}: schedule 格式无效: {op["schedule"]}，请使用 YYYY-MM-DD'
        updates['schedule_date'] = d
        # Bug A 修复：设置 schedule_date 时，若任务当前为 inbox 则自动激活为 active
        # 用户说「安排到某天」本身即为确认行为，不需要等晨间规划二次确认
        # 注意：此处通过标记 _auto_activate=True，在执行层查询当前 status 后决定是否升级
        updates['_auto_activate'] = True

    # ddl
    if 'ddl' in op:
        d = _normalize_date(op['ddl'])
        if not d:
            return task_id, {}, f'{task_id}: ddl 格式无效: {op["ddl"]}，请使用 YYYY-MM-DD'
        updates['due_date'] = d

    # project
    if 'project' in op:
        updates['project_id'] = str(op['project']).strip()

    # snooze
    if 'snooze' in op:
        snooze_val = str(op['snooze']).strip()
        if snooze_val == 'clear':
            updates['snooze_until'] = None
        else:
            d = _normalize_date(snooze_val)
            if not d:
                return task_id, {}, f'{task_id}: snooze 格式无效: {snooze_val}，请使用 YYYY-MM-DD 或 "clear"'
            updates['snooze_until'] = d

    if not updates:
        return task_id, {}, f'{task_id}: 操作为空，请至少指定一个更新字段'

    return task_id, updates, None


# ============================================================
# 批量执行
# ============================================================

def batch_update(ops: List[Dict[str, Any]], db_path: str,
                 dry_run: bool = False) -> Dict[str, Any]:
    """
    批量执行任务更新操作。
    每个操作独立事务：单条失败不影响其他操作。
    返回结果汇总字典。
    """
    results = []
    success_count = 0
    skip_count = 0
    fail_count = 0

    conn = get_connection(db_path)

    for i, op in enumerate(ops):
        task_id, updates, parse_error = parse_op(op, i)

        if parse_error:
            results.append({
                'index': i,
                'id': task_id or f'op[{i}]',
                'status': 'error',
                'message': parse_error,
            })
            fail_count += 1
            continue

        if dry_run:
            results.append({
                'index': i,
                'id': task_id,
                'status': 'would_update',
                'updates': updates,
            })
            skip_count += 1
            continue

        # 实际执行，每条独立事务
        try:
            with conn:
                if 'project_id' in updates:
                    ensure_project(conn, updates['project_id'])
                # Bug A 修复：_auto_activate 标记处理
                auto_activate = updates.pop('_auto_activate', False)
                if auto_activate and 'status' not in updates:
                    # 查询当前 status，若为 inbox 则自动升级为 active
                    row = conn.execute(
                        'SELECT status FROM tasks WHERE id=? AND is_deleted=0', (task_id,)
                    ).fetchone()
                    if row and row[0] == 'inbox':
                        updates['status'] = 'active'
                success = update_task_fields(conn, task_id, updates, context='batch_update')

            if success:
                updated_fields = ', '.join(f'{k}={v}' for k, v in updates.items())
                results.append({
                    'index': i,
                    'id': task_id,
                    'status': 'ok',
                    'message': f'已更新: {updated_fields}',
                })
                success_count += 1
            else:
                results.append({
                    'index': i,
                    'id': task_id,
                    'status': 'not_found',
                    'message': f'任务不存在: {task_id}',
                })
                fail_count += 1

        except Exception as e:
            results.append({
                'index': i,
                'id': task_id,
                'status': 'error',
                'message': str(e),
            })
            fail_count += 1

    conn.close()

    return {
        'total': len(ops),
        'success': success_count,
        'skipped': skip_count,
        'failed': fail_count,
        'dry_run': dry_run,
        'results': results,
    }


# ============================================================
# 输出格式化
# ============================================================

def format_summary(result: Dict[str, Any]) -> str:
    """输出人类可读的汇总"""
    lines = []
    mode = '[DRY-RUN] ' if result['dry_run'] else ''
    total = result['total']
    success = result['success']
    failed = result['failed']
    skipped = result['skipped']

    if result['dry_run']:
        lines.append(f'[DRY-RUN] 预览 {total} 个操作（不实际写入）')
    else:
        lines.append(f'[OK] 批量更新完成：{total} 个操作，成功 {success}，失败 {failed}')

    for r in result['results']:
        idx = r['index']
        task_id = r['id']
        status = r['status']
        msg = r.get('message', '')

        if status == 'ok':
            lines.append(f'  ✅ [{idx}] {task_id}  {msg}')
        elif status == 'would_update':
            updates_str = ', '.join(f'{k}={v}' for k, v in r.get('updates', {}).items())
            lines.append(f'  🔍 [{idx}] {task_id}  将更新: {updates_str}')
        elif status == 'not_found':
            lines.append(f'  ⚠️  [{idx}] {task_id}  任务不存在')
        else:
            lines.append(f'  ❌ [{idx}] {task_id}  {msg}')

    return '\n'.join(lines)


# ============================================================
# CLI 入口
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro - 批量任务操作（减少 AI round-trip 开销）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 安排多个任务的执行日期
  python batch_update.py --ops '[
    {"id": "T-20260405-abc123", "schedule": "2026-04-06"},
    {"id": "T-20260405-def456", "schedule": "2026-04-07"},
    {"id": "T-20260405-ghi789", "status": "cancelled"}
  ]'

  # 预览模式
  python batch_update.py --ops '[...]' --dry-run

  # 从文件读取操作列表
  python batch_update.py --ops-file /tmp/batch_ops.json

  # 输出 JSON（供 AI 消费）
  python batch_update.py --ops '[...]' --format json
        """
    )
    parser.add_argument('--ops', help='JSON 格式的操作列表（内联）')
    parser.add_argument('--ops-file', dest='ops_file',
                        help='包含操作列表的 JSON 文件路径')
    parser.add_argument('--dry-run', action='store_true',
                        help='预览模式，不实际写入')
    parser.add_argument('--format', choices=['summary', 'json'], default='summary',
                        help='输出格式（默认 summary）')

    args = parser.parse_args()

    # 读取操作列表
    if args.ops:
        try:
            ops = json.loads(args.ops)
        except json.JSONDecodeError as e:
            print(f'[ERROR] --ops JSON 解析失败：{e}', file=sys.stderr)
            sys.exit(1)
    elif args.ops_file:
        ops_path = Path(args.ops_file)
        if not ops_path.exists():
            print(f'[ERROR] 文件不存在：{args.ops_file}', file=sys.stderr)
            sys.exit(1)
        try:
            ops = json.loads(ops_path.read_text(encoding='utf-8'))
        except json.JSONDecodeError as e:
            print(f'[ERROR] ops-file JSON 解析失败：{e}', file=sys.stderr)
            sys.exit(1)
    else:
        print('[ERROR] 请提供 --ops 或 --ops-file', file=sys.stderr)
        parser.print_help()
        sys.exit(1)

    if not isinstance(ops, list):
        print('[ERROR] ops 必须是 JSON 数组', file=sys.stderr)
        sys.exit(1)

    if len(ops) == 0:
        print('[WARN] 操作列表为空，无任何操作执行')
        return

    config = load_config()
    db_path = config['db_path']

    if not Path(db_path).exists():
        print(f'[ERROR] 数据库不存在：{db_path}，请先运行 python db_init.py', file=sys.stderr)
        sys.exit(1)

    result = batch_update(ops, db_path, dry_run=args.dry_run)

    if args.format == 'json':
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(format_summary(result))

    # 有失败项时返回非 0 退出码
    if result['failed'] > 0:
        sys.exit(1)


if __name__ == '__main__':
    main()
