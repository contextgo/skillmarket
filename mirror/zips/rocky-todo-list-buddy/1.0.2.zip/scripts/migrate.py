#!/usr/bin/env python3
"""
migrate.py - 存量 Inbox Markdown → SQLite 批量迁移工具

功能：
  --validate  扫描所有 Inbox 文件，报告可迁移数量及问题文件（不依赖数据库）
  --dry-run   模拟迁移，输出将要插入/更新的记录列表（不写入 SQLite）
  --run       正式迁移，批量写入 SQLite tasks 表
  --repair    对 --validate 发现的问题文件尝试自动修复

用法：
  python migrate.py --validate              # 先验证
  python migrate.py --dry-run              # 预览
  python migrate.py --run                  # 正式迁移
  python migrate.py --run --force          # 强制覆盖已存在记录
  python migrate.py --repair               # 修复问题文件

Python 版本：3.9.6
"""

from __future__ import annotations

import os
import re
import sys
import json
import uuid
import sqlite3
import argparse
import hashlib
from pathlib import Path
from datetime import datetime, date
from typing import Optional, Dict, List, Tuple

# ── 本地模块导入 ──────────────────────────────────────────────────────────────
# 优先用同目录的 scan_inbox，兼容直接运行和导入两种方式
_SCRIPT_DIR = Path(__file__).parent.resolve()
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from scan_inbox import (
    parse_md_file,
    load_config,
    scan_inbox,
    STATUS_KEYWORDS,
    YAMLParseError,
)


# ── 常量 ──────────────────────────────────────────────────────────────────────

VALID_STATUSES = {'inbox', 'active', 'done', 'cancelled', 'someday', 'waiting'}
VALID_PRIORITIES = {'urgent', 'high', 'normal', 'waiting'}


# ── 任务 ID 生成 ──────────────────────────────────────────────────────────────

def generate_task_id(filename: str) -> str:
    """
    生成任务 ID，格式：T-{YYYYMMDD}-{6位hex}
    日期从文件名提取（文件名格式 YYYY-MM-DD-xxx.md），
    若无法提取则使用今天日期。
    """
    stem = Path(filename).stem
    m = re.match(r'^(\d{4})-(\d{2})-(\d{2})-', stem)
    if m:
        date_part = f"{m.group(1)}{m.group(2)}{m.group(3)}"
    else:
        date_part = date.today().strftime('%Y%m%d')

    # 6位 hex：用文件名的 MD5 前6位，保证同文件名幂等
    hex_part = hashlib.md5(filename.encode('utf-8')).hexdigest()[:6]
    return f"T-{date_part}-{hex_part}"


# ── 字段覆盖率统计 ────────────────────────────────────────────────────────────

def compute_coverage(tasks: List[dict]) -> dict:
    """统计各字段覆盖率。"""
    total = len(tasks)
    if total == 0:
        return {}

    fields = ['project', 'schedule', 'ddl', 'priority', 'area', 'completed_at']
    coverage = {}
    for f in fields:
        count = sum(1 for t in tasks if t.get(f))
        coverage[f] = {'count': count, 'total': total,
                       'pct': f"{count / total * 100:.1f}%"}
    return coverage


# ── 状态分布统计 ──────────────────────────────────────────────────────────────

def compute_status_dist(tasks: List[dict]) -> dict:
    dist: Dict[str, int] = {}
    for t in tasks:
        s = t.get('status', 'unknown')
        dist[s] = dist.get(s, 0) + 1
    return dist


# ── 问题检测 ──────────────────────────────────────────────────────────────────

def detect_issues(task: dict) -> List[str]:
    """
    检测单个任务的数据问题，返回问题描述列表。
    空列表 = 无问题，可正常迁移。
    """
    issues = []

    # 1. YAML 损坏（parse_error 字段存在）
    if task.get('parse_error'):
        issues.append(f"YAML 解析失败: {task['parse_error']}")

    # 2. 无法识别 status
    status = task.get('status')
    if not status or status not in VALID_STATUSES:
        issues.append(f"无法识别的 status: {status!r}")

    # 3. 缺失标题
    title = task.get('title', '').strip()
    if not title:
        issues.append("缺失标题（title 为空）")

    # 4. 读取失败（有 error 字段）
    if task.get('error'):
        issues.append(f"读取失败: {task['error']}")

    return issues


# ══════════════════════════════════════════════════════════════════════════════
# 模式一：--validate
# ══════════════════════════════════════════════════════════════════════════════

def run_validate(inbox_path: str, verbose: bool = False) -> dict:
    """
    扫描所有 Inbox 文件，不依赖数据库，输出验证报告。

    返回：
      {
        'ok': [ task_dict, ... ],        # 可正常迁移
        'warning': [ {task, issues} ],   # 有小问题但可迁移
        'error': [ {task, issues} ],     # 严重问题，需人工处理
        'coverage': { field: {count, total, pct} },
        'status_dist': { status: count },
        'summary': { ok/warning/error/total counts }
      }
    """
    inbox_dir = Path(inbox_path)
    if not inbox_dir.exists():
        raise FileNotFoundError(f"Inbox 目录不存在: {inbox_path}")

    ok_tasks: List[dict] = []
    warning_tasks: List[dict] = []
    error_tasks: List[dict] = []

    for md_file in sorted(inbox_dir.glob('*.md')):
        if md_file.name.startswith('_'):
            continue

        task = parse_md_file(md_file)

        if task is None:
            error_tasks.append({'filename': md_file.name,
                                 'issues': ['parse_md_file 返回 None']})
            continue

        if task.get('error'):
            error_tasks.append({'filename': md_file.name,
                                 'issues': [f"读取失败: {task['error']}"]})
            continue

        issues = detect_issues(task)

        # YAML 损坏 → 严重错误
        if task.get('parse_error'):
            error_tasks.append({'filename': md_file.name,
                                 'task': task,
                                 'issues': issues})
        elif issues:
            warning_tasks.append({'filename': md_file.name,
                                   'task': task,
                                   'issues': issues})
        else:
            ok_tasks.append(task)

    all_tasks = ok_tasks + [e.get('task', {}) for e in warning_tasks if e.get('task')]
    coverage = compute_coverage(all_tasks)
    status_dist = compute_status_dist(all_tasks)

    return {
        'ok': ok_tasks,
        'warning': warning_tasks,
        'error': error_tasks,
        'coverage': coverage,
        'status_dist': status_dist,
        'summary': {
            'total': len(ok_tasks) + len(warning_tasks) + len(error_tasks),
            'ok': len(ok_tasks),
            'warning': len(warning_tasks),
            'error': len(error_tasks),
        }
    }


def print_validate_report(report: dict, verbose: bool = False) -> None:
    """格式化输出验证报告。"""
    s = report['summary']
    print("\n" + "═" * 60)
    print("  migrate.py --validate 结果报告")
    print("═" * 60)
    print(f"  总文件数  : {s['total']}")
    print(f"  ✅ 可迁移 : {s['ok']}")
    print(f"  ⚠️  有警告 : {s['warning']}（可迁移，建议先 --repair）")
    print(f"  ❌ 严重错误: {s['error']}（需人工处理）")

    # 状态分布
    print("\n  📊 状态分布：")
    for status, cnt in sorted(report['status_dist'].items()):
        print(f"    {status:<12}: {cnt}")

    # 字段覆盖率
    print("\n  📈 字段覆盖率：")
    for field, info in report['coverage'].items():
        bar_len = int(float(info['pct'].rstrip('%')) / 5)
        bar = '█' * bar_len + '░' * (20 - bar_len)
        print(f"    {field:<14}: [{bar}] {info['pct']:>6}  ({info['count']}/{info['total']})")

    # 警告列表
    if report['warning']:
        print("\n  ⚠️  警告文件：")
        for item in report['warning']:
            print(f"    {item['filename']}")
            for issue in item['issues']:
                print(f"      - {issue}")

    # 错误列表
    if report['error']:
        print("\n  ❌ 错误文件（需人工处理）：")
        for item in report['error']:
            print(f"    {item['filename']}")
            for issue in item['issues']:
                print(f"      - {issue}")

    print("═" * 60 + "\n")


# ══════════════════════════════════════════════════════════════════════════════
# 模式二：--dry-run
# ══════════════════════════════════════════════════════════════════════════════

def run_dry_run(inbox_path: str) -> List[dict]:
    """
    模拟迁移：解析所有可迁移文件，生成将要插入的记录列表，
    不写入数据库。
    """
    report = run_validate(inbox_path)
    records = []

    for task in report['ok']:
        task_id = generate_task_id(task['filename'])
        record = {
            'task_id': task_id,
            'filename': task['filename'],
            'title': task['title'],
            'status': task['status'],
            'priority': task.get('priority') or 'normal',
            'area': task.get('area'),
            'project': task.get('project'),
            'schedule': task.get('schedule'),
            'ddl': task.get('ddl'),
            'completed_at': task.get('completed_at'),
            'created': task.get('created'),
            'tags': json.dumps(task.get('tags', []), ensure_ascii=False),
            '_action': 'INSERT',
        }
        records.append(record)

    # warning 任务也可以迁移（降级处理）
    for item in report['warning']:
        task = item.get('task', {})
        if not task:
            continue
        task_id = generate_task_id(task['filename'])
        record = {
            'task_id': task_id,
            'filename': task['filename'],
            'title': task.get('title') or task['filename'],
            'status': task.get('status') or 'inbox',
            'priority': task.get('priority') or 'normal',
            'area': task.get('area'),
            'project': task.get('project'),
            'schedule': task.get('schedule'),
            'ddl': task.get('ddl'),
            'completed_at': task.get('completed_at'),
            'created': task.get('created'),
            'tags': json.dumps(task.get('tags', []), ensure_ascii=False),
            '_action': 'INSERT (with warnings)',
            '_warnings': item['issues'],
        }
        records.append(record)

    return records


def print_dry_run_report(records: List[dict]) -> None:
    """格式化输出 dry-run 预览。"""
    print("\n" + "═" * 60)
    print("  migrate.py --dry-run 预览（不写入数据库）")
    print("═" * 60)
    print(f"  将要迁移 {len(records)} 条记录：\n")
    for i, r in enumerate(records, 1):
        action = r.get('_action', 'INSERT')
        warns = r.get('_warnings', [])
        warn_str = f"  ⚠️  {'; '.join(warns)}" if warns else ""
        print(f"  [{i:03d}] {r['task_id']}  {r['_action']}")
        print(f"        文件: {r['filename']}")
        print(f"        标题: {r['title']}")
        print(f"        状态: {r['status']}  优先级: {r['priority']}  "
              f"area: {r.get('area') or '-'}  project: {r.get('project') or '-'}")
        if r.get('schedule'):
            print(f"        schedule: {r['schedule']}")
        if r.get('ddl'):
            print(f"        ddl: {r['ddl']}")
        if warn_str:
            print(f"       {warn_str}")
        print()
    print("═" * 60 + "\n")


# ══════════════════════════════════════════════════════════════════════════════
# 模式三：--run（正式迁移，依赖 db_init.py 已初始化数据库）
# ══════════════════════════════════════════════════════════════════════════════

def get_db_path(config: dict) -> Path:
    """获取并展开 db_path。"""
    raw = config.get('db_path', '~/.rocky-todo-list-buddy/rocky.db')
    return Path(raw).expanduser()


def write_task_id_to_frontmatter(filepath: Path, task_id: str) -> bool:
    """
    将 task_id 写回 Markdown 文件的 YAML frontmatter。
    如果 frontmatter 中已有 id 字段则跳过。
    返回 True = 写入成功，False = 跳过或失败。
    """
    try:
        content = filepath.read_text(encoding='utf-8')
    except Exception:
        return False

    # 已有 id 字段则跳过
    if re.search(r'^id\s*:', content, re.MULTILINE):
        return False

    # 在第一个 --- 后插入 id 字段（原子写入：先写 .tmp，再 rename）
    new_content = content.replace('---\n', f'---\nid: "{task_id}"\n', 1)
    if new_content == content:
        return False  # 没有找到 frontmatter 开头，不修改

    tmp_path = filepath.with_suffix('.tmp')
    try:
        tmp_path.write_text(new_content, encoding='utf-8')
        tmp_path.replace(filepath)
        return True
    except Exception:
        tmp_path.unlink(missing_ok=True)
        return False


def run_migrate(inbox_path: str, db_path: Path, force: bool = False) -> dict:
    """
    正式迁移：将所有可迁移的 Inbox 文件批量写入 SQLite。

    幂等规则：同文件名（md_filename）已存在 → force=False 跳过，force=True 覆盖。
    每条成功写入的记录都在 task_logs 表中记录 action='migrate_import'。
    迁移完成后将 task_id 写回 Inbox Markdown frontmatter（id 字段）。

    真实表 schema：
      tasks: id, title, status, priority, area, project_id, schedule_date, due_date,
             completed_at, created_at, updated_at, tags, body, source, md_filename,
             md_synced_at, is_deleted
      task_logs: id, task_id, action, old_value, new_value, context, logged_at

    返回：{'success': int, 'skipped': int, 'failed': int, 'details': []}
    """
    if not db_path.exists():
        raise FileNotFoundError(
            f"数据库文件不存在：{db_path}\n"
            "请先运行 `python db_init.py` 初始化数据库。"
        )

    records = run_dry_run(inbox_path)
    now = datetime.now().isoformat(timespec='seconds')

    success = 0
    skipped = 0
    failed = 0
    details = []

    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL;")
    conn.execute("PRAGMA foreign_keys=ON;")

    try:
        for rec in records:
            filename = rec['filename']
            task_id = rec['task_id']

            try:
                # 检查是否已存在（以 md_filename 字段判断幂等性）
                row = conn.execute(
                    "SELECT id FROM tasks WHERE md_filename = ? AND is_deleted = 0",
                    (filename,)
                ).fetchone()

                if row and not force:
                    skipped += 1
                    details.append({'filename': filename, 'result': 'skipped',
                                    'reason': '已存在（使用 --force 覆盖）'})
                    continue

                # ── 确保 projects 表中有对应记录（外键约束前提）──────────────────
                project_name = rec.get('project')
                if project_name:
                    conn.execute("""
                        INSERT OR IGNORE INTO projects
                            (id, name, status, created_at, updated_at)
                        VALUES (?, ?, 'active', ?, ?)
                    """, (project_name, project_name, now, now))

                if row and force:
                    # 更新已有记录
                    conn.execute("""
                        UPDATE tasks SET
                            title         = ?,
                            status        = ?,
                            priority      = ?,
                            area          = ?,
                            schedule_date = ?,
                            due_date      = ?,
                            completed_at  = ?,
                            tags          = ?,
                            updated_at    = ?
                        WHERE md_filename = ? AND is_deleted = 0
                    """, (
                        rec['title'],
                        rec['status'],
                        rec['priority'],
                        rec.get('area'),
                        rec.get('schedule'),
                        rec.get('ddl'),
                        rec.get('completed_at'),
                        rec['tags'],
                        now,
                        filename,
                    ))
                    # 查出实际 id（用于 task_logs）
                    real_id = conn.execute(
                        "SELECT id FROM tasks WHERE md_filename=? AND is_deleted=0",
                        (filename,)
                    ).fetchone()['id']
                    action_type = 'updated'
                else:
                    # 插入新记录
                    conn.execute("""
                        INSERT INTO tasks
                            (id, title, status, priority, area,
                             project_id,
                             schedule_date, due_date, completed_at,
                             tags, source, md_filename,
                             created_at, updated_at, is_deleted)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                    """, (
                        task_id,
                        rec['title'],
                        rec['status'],
                        rec['priority'],
                        rec.get('area'),
                        rec.get('project'),       # project_id 从 scan_inbox 的 project 字段读取
                        rec.get('schedule'),
                        rec.get('ddl'),
                        rec.get('completed_at'),
                        rec['tags'],
                        'migrate',
                        filename,
                        rec.get('created') or now[:10],
                        now,
                    ))
                    real_id = task_id
                    action_type = 'created'

                # 写入 task_logs（append-only，id 为 INTEGER 自增主键）
                log_action = 'created' if action_type == 'created' else 'note_added'
                conn.execute("""
                    INSERT INTO task_logs
                        (task_id, action, old_value, new_value, context, logged_at)
                    VALUES (?, ?, NULL, NULL, ?, ?)
                """, (real_id, log_action, 'migrate', now))

                conn.commit()
                success += 1

                # 将 task_id 写回 Inbox Markdown frontmatter
                inbox_file = Path(inbox_path) / filename
                write_task_id_to_frontmatter(inbox_file, real_id)

                details.append({'filename': filename, 'task_id': real_id,
                                 'result': action_type})

            except sqlite3.Error as e:
                conn.rollback()
                failed += 1
                details.append({'filename': filename, 'result': 'failed',
                                 'reason': str(e)})

    finally:
        conn.close()

    return {
        'success': success,
        'skipped': skipped,
        'failed': failed,
        'total': success + skipped + failed,
        'details': details,
    }


def print_migrate_report(result: dict) -> None:
    """格式化输出迁移结果。"""
    print("\n" + "═" * 60)
    print("  migrate.py --run 迁移结果")
    print("═" * 60)
    print(f"  总计  : {result['total']}")
    print(f"  ✅ 成功: {result['success']}")
    print(f"  ⏭️  跳过: {result['skipped']}（已存在）")
    print(f"  ❌ 失败: {result['failed']}")

    if result['failed'] > 0:
        print("\n  失败详情：")
        for d in result['details']:
            if d['result'] == 'failed':
                print(f"    {d['filename']}: {d.get('reason', '未知错误')}")

    print("═" * 60 + "\n")


# ══════════════════════════════════════════════════════════════════════════════
# 模式四：--repair
# ══════════════════════════════════════════════════════════════════════════════

def run_repair(inbox_path: str, dry_run: bool = False) -> dict:
    """
    对 --validate 发现的警告/错误文件尝试自动修复：
    - 补全缺失的 status tag（设为 inbox）
    - 设置默认 priority（normal）
    - 若 frontmatter 完全损坏，添加最小化 frontmatter

    dry_run=True 时只报告，不实际修改文件。

    返回：{'fixed': [filename], 'unfixable': [(filename, reason)], 'skipped': [filename]}
    """
    report = run_validate(inbox_path)
    inbox_dir = Path(inbox_path)

    fixable = report['warning'] + report['error']
    fixed = []
    unfixable = []
    skipped = []

    for item in fixable:
        filename = item['filename']
        filepath = inbox_dir / filename
        issues = item['issues']

        # 读取失败 → 无法自动修复
        if any('读取失败' in i for i in issues):
            unfixable.append((filename, '文件读取失败，需手动检查'))
            continue

        # YAML 完全损坏 → 需要人工处理
        if any('YAML 解析失败' in i for i in issues):
            unfixable.append((filename, 'YAML frontmatter 损坏，请手动修复'))
            continue

        try:
            content = filepath.read_text(encoding='utf-8')
        except Exception as e:
            unfixable.append((filename, f"读取失败: {e}"))
            continue

        modified = False
        task = item.get('task', {})

        # 修复 1：缺失 status tag
        if any('无法识别的 status' in i for i in issues):
            # 在 frontmatter 的 tags 列表中补充 inbox
            if '---' in content:
                # 尝试在 tags: [...] 中追加 inbox
                if re.search(r'^tags:', content, re.MULTILINE):
                    # 在 tags 后第一行 value 区追加
                    content = re.sub(
                        r'(tags:\s*\n)((?:[ \t]*-[^\n]*\n)*)',
                        r'\g<1>\g<2>  - inbox\n',
                        content, count=1
                    )
                else:
                    # frontmatter 无 tags 字段，在第一个 --- 后添加
                    content = content.replace(
                        '---\n', '---\ntags:\n  - inbox\n', 1
                    )
                modified = True

        # 修复 2：缺失 priority（目前 scan_inbox 默认 normal，这里只记录无需修改文件）
        # （priority 已在解析时默认化，文件本身不需要修改）

        if modified and not dry_run:
            try:
                filepath.write_text(content, encoding='utf-8')
                fixed.append(filename)
            except Exception as e:
                unfixable.append((filename, f"写入失败: {e}"))
        elif modified and dry_run:
            fixed.append(f"{filename} (dry-run)")
        else:
            skipped.append(filename)

    return {
        'fixed': fixed,
        'unfixable': unfixable,
        'skipped': skipped,
    }


def print_repair_report(result: dict, dry_run: bool = False) -> None:
    """格式化输出修复报告。"""
    mode = "（dry-run 预览）" if dry_run else ""
    print("\n" + "═" * 60)
    print(f"  migrate.py --repair 修复报告{mode}")
    print("═" * 60)
    print(f"  ✅ 已修复   : {len(result['fixed'])}")
    print(f"  ⏭️  无需修复 : {len(result['skipped'])}")
    print(f"  ❌ 无法自动修复: {len(result['unfixable'])}")

    if result['fixed']:
        print("\n  已修复文件：")
        for f in result['fixed']:
            print(f"    {f}")

    if result['unfixable']:
        print("\n  需人工处理：")
        for fname, reason in result['unfixable']:
            print(f"    {fname}: {reason}")
    print("═" * 60 + "\n")


# ══════════════════════════════════════════════════════════════════════════════
# CLI 入口
# ══════════════════════════════════════════════════════════════════════════════

def main() -> None:
    parser = argparse.ArgumentParser(
        description='migrate.py - 存量 Inbox Markdown → SQLite 批量迁移工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""示例:
  python migrate.py --validate              # 先验证（不依赖数据库）
  python migrate.py --dry-run              # 预览迁移记录
  python migrate.py --run                  # 正式迁移
  python migrate.py --run --force          # 强制覆盖已存在记录
  python migrate.py --repair               # 修复问题文件
  python migrate.py --repair --dry-run     # 预览修复（不修改文件）
""",
    )

    mode_group = parser.add_mutually_exclusive_group(required=True)
    mode_group.add_argument('--validate', action='store_true',
                            help='扫描并报告可迁移情况（不依赖数据库）')
    mode_group.add_argument('--dry-run', dest='dry_run', action='store_true',
                            help='模拟迁移，输出将要写入的记录（不写入 SQLite）')
    mode_group.add_argument('--run', action='store_true',
                            help='正式迁移，批量写入 SQLite')
    mode_group.add_argument('--repair', action='store_true',
                            help='修复 --validate 发现的问题文件')

    parser.add_argument('--force', action='store_true',
                        help='（配合 --run）强制覆盖已存在记录')
    parser.add_argument('--verbose', '-v', action='store_true',
                        help='输出详细日志')
    parser.add_argument('--json', dest='output_json', action='store_true',
                        help='以 JSON 格式输出结果（便于脚本解析）')
    parser.add_argument('--inbox', help='覆盖 config.json 中的 inbox_path（用于测试）')
    parser.add_argument('--db', help='覆盖 config.json 中的 db_path（用于测试）')

    args = parser.parse_args()

    # ── 加载配置 ────────────────────────────────────────────────────────────
    try:
        config = load_config()
    except FileNotFoundError as e:
        print(f"❌ {e}", file=sys.stderr)
        sys.exit(1)

    inbox_path = args.inbox or config.get('inbox_path', '')
    if not inbox_path:
        print("❌ config.json 中未配置 inbox_path", file=sys.stderr)
        sys.exit(1)

    db_path = Path(args.db).expanduser() if args.db else get_db_path(config)

    # ── 执行对应模式 ─────────────────────────────────────────────────────────
    try:
        if args.validate:
            report = run_validate(inbox_path, verbose=args.verbose)
            if args.output_json:
                # JSON 输出时隐去 ok/warning/error 中的大量任务详情，只保留 summary
                out = {
                    'summary': report['summary'],
                    'status_dist': report['status_dist'],
                    'coverage': report['coverage'],
                    'warning_files': [w['filename'] for w in report['warning']],
                    'error_files': [e['filename'] for e in report['error']],
                }
                print(json.dumps(out, ensure_ascii=False, indent=2))
            else:
                print_validate_report(report, verbose=args.verbose)

        elif args.dry_run:
            records = run_dry_run(inbox_path)
            if args.output_json:
                print(json.dumps(records, ensure_ascii=False, indent=2))
            else:
                print_dry_run_report(records)

        elif args.run:
            result = run_migrate(inbox_path, db_path, force=args.force)
            if args.output_json:
                print(json.dumps(result, ensure_ascii=False, indent=2))
            else:
                print_migrate_report(result)

        elif args.repair:
            result = run_repair(inbox_path, dry_run=args.dry_run)
            if args.output_json:
                print(json.dumps({
                    'fixed': result['fixed'],
                    'unfixable': [{'file': f, 'reason': r} for f, r in result['unfixable']],
                    'skipped': result['skipped'],
                }, ensure_ascii=False, indent=2))
            else:
                print_repair_report(result, dry_run=False)

    except FileNotFoundError as e:
        print(f"❌ {e}", file=sys.stderr)
        sys.exit(1)
    except Exception as e:
        print(f"❌ 未预期错误: {e}", file=sys.stderr)
        if args.verbose:
            import traceback
            traceback.print_exc()
        sys.exit(1)


if __name__ == '__main__':
    main()
