#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
db_init.py - 数据库初始化脚本
功能：
  1. 创建 ~/.rocky-todo-list-buddy/ 目录
  2. 建立所有表（tasks, projects, daily_notes, habit_definitions, habit_instances, reviews, task_logs, task_map, schema_version）
  3. 插入 schema_version 初始记录
  4. 幂等：可重复执行，已存在的表不报错

用法：
  python db_init.py           # 初始化数据库
  python db_init.py --reset   # 删除并重建（危险，需确认）
  python db_init.py --status  # 查看当前数据库状态
"""

import sys
import json
import sqlite3
import hashlib
import argparse
from pathlib import Path
from datetime import datetime
from typing import Optional


def load_config() -> dict:
    """加载配置文件"""
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config['db_path'] = str(Path(config['db_path']).expanduser())
    return config


def get_connection(db_path: str) -> sqlite3.Connection:
    """建立 SQLite 连接并设置必要 PRAGMA"""
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA foreign_keys=ON')
    conn.execute('PRAGMA synchronous=NORMAL')
    return conn


# 完整的建表 SQL（按依赖顺序排列：projects 先于 tasks）
SCHEMA_SQL = """
-- ============================================================
-- 基础设施：版本管理表
-- ============================================================
CREATE TABLE IF NOT EXISTS schema_version (
    version     INTEGER     NOT NULL,
    applied_at  TEXT        NOT NULL,
    description TEXT        NOT NULL,
    checksum    TEXT        NOT NULL,
    PRIMARY KEY (version)
);

-- ============================================================
-- 项目表（tasks 的外键依赖，必须先建）
-- ============================================================
CREATE TABLE IF NOT EXISTS projects (
    id          TEXT    NOT NULL,
    name        TEXT    NOT NULL,
    area        TEXT                    CHECK (area IS NULL OR area IN ('work','life')),
    status      TEXT    NOT NULL        DEFAULT 'active'
                CHECK (status IN ('active','paused','done','cancelled')),
    description TEXT,
    due_date    TEXT,
    created_at  TEXT    NOT NULL        DEFAULT (datetime('now')),
    updated_at  TEXT    NOT NULL        DEFAULT (datetime('now')),
    PRIMARY KEY (id)
);

-- ============================================================
-- 核心任务表
-- ============================================================
CREATE TABLE IF NOT EXISTS tasks (
    id              TEXT        NOT NULL,
    title           TEXT        NOT NULL,
    status          TEXT        NOT NULL    DEFAULT 'inbox'
                    CHECK (status IN ('inbox','active','done','cancelled','someday')),
    priority        TEXT        NOT NULL    DEFAULT 'normal'
                    CHECK (priority IN ('urgent','high','normal','waiting')),
    area            TEXT                    DEFAULT NULL
                    CHECK (area IS NULL OR area IN ('work','life')),
    project_id      TEXT,
    schedule_date   TEXT,
    due_date        TEXT,
    completed_at    TEXT,
    created_at      TEXT        NOT NULL    DEFAULT (datetime('now')),
    updated_at      TEXT        NOT NULL    DEFAULT (datetime('now')),
    tags            TEXT        NOT NULL    DEFAULT '[]'
                    CHECK (json_valid(tags)),
    body            TEXT,
    source          TEXT,
    md_filename     TEXT,
    md_synced_at    TEXT,
    is_deleted      INTEGER     NOT NULL    DEFAULT 0
                    CHECK (is_deleted IN (0,1)),
    PRIMARY KEY (id),
    FOREIGN KEY (project_id) REFERENCES projects(id)
                ON UPDATE CASCADE ON DELETE SET NULL
);

-- 自动维护 updated_at
CREATE TRIGGER IF NOT EXISTS tasks_updated_at
    AFTER UPDATE ON tasks FOR EACH ROW
    WHEN OLD.updated_at = NEW.updated_at
BEGIN
    UPDATE tasks SET updated_at = datetime('now') WHERE id = NEW.id;
END;

-- ============================================================
-- Daily Note 统计快照
-- ============================================================
CREATE TABLE IF NOT EXISTS daily_notes (
    date                TEXT    NOT NULL,
    md_path             TEXT    NOT NULL,
    work_planned        INTEGER DEFAULT 0,
    work_done           INTEGER DEFAULT 0,
    life_planned        INTEGER DEFAULT 0,
    life_done           INTEGER DEFAULT 0,
    unplanned_done      INTEGER DEFAULT 0,
    has_review          INTEGER DEFAULT 0   CHECK (has_review IN (0,1)),
    created_at          TEXT    NOT NULL    DEFAULT (datetime('now')),
    updated_at          TEXT    NOT NULL    DEFAULT (datetime('now')),
    PRIMARY KEY (date)
);

-- ============================================================
-- 习惯定义表
-- ============================================================
CREATE TABLE IF NOT EXISTS habit_definitions (
    id          TEXT    NOT NULL,
    name        TEXT    NOT NULL,
    area        TEXT    NOT NULL    CHECK (area IN ('work','life')),
    frequency   TEXT    NOT NULL    DEFAULT 'daily',
    priority    TEXT    NOT NULL    DEFAULT 'normal'
                CHECK (priority IN ('urgent','high','normal')),
    tags        TEXT    NOT NULL    DEFAULT '[]'    CHECK (json_valid(tags)),
    is_active   INTEGER NOT NULL    DEFAULT 1       CHECK (is_active IN (0,1)),
    created_at  TEXT    NOT NULL    DEFAULT (datetime('now')),
    PRIMARY KEY (id)
);

-- ============================================================
-- 习惯打卡记录
-- ============================================================
CREATE TABLE IF NOT EXISTS habit_instances (
    id              TEXT    NOT NULL,
    habit_id        TEXT    NOT NULL,
    task_id         TEXT,
    date            TEXT    NOT NULL,
    status          TEXT    NOT NULL    DEFAULT 'pending'
                    CHECK (status IN ('done','cancelled','pending')),
    completed_at    TEXT,
    note            TEXT,
    PRIMARY KEY (id),
    FOREIGN KEY (habit_id) REFERENCES habit_definitions(id) ON UPDATE CASCADE,
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE SET NULL,
    UNIQUE (habit_id, date)
);

-- ============================================================
-- 复盘报告元数据
-- ============================================================
CREATE TABLE IF NOT EXISTS reviews (
    id                      TEXT    NOT NULL,
    type                    TEXT    NOT NULL    CHECK (type IN ('daily','weekly','monthly')),
    period                  TEXT    NOT NULL,
    md_path                 TEXT    NOT NULL,
    work_completion_rate    REAL,
    life_completion_rate    REAL,
    total_tasks_done        INTEGER DEFAULT 0,
    highlight               TEXT,
    created_at              TEXT    NOT NULL    DEFAULT (datetime('now')),
    PRIMARY KEY (id),
    UNIQUE (type, period)
);

-- ============================================================
-- 操作日志（仅追加，不可篡改）
-- ============================================================
CREATE TABLE IF NOT EXISTS task_logs (
    id          INTEGER NOT NULL    PRIMARY KEY AUTOINCREMENT,
    task_id     TEXT    NOT NULL,
    action      TEXT    NOT NULL
                CHECK (action IN (
                    'created','status_changed','priority_changed',
                    'scheduled','due_set','completed','cancelled',
                    'project_assigned','md_synced','note_added',
                    'user_input'
                )),
    old_value   TEXT,
    new_value   TEXT,
    raw_input   TEXT,
    context     TEXT,
    logged_at   TEXT    NOT NULL    DEFAULT (datetime('now'))
);

-- 防篡改触发器
CREATE TRIGGER IF NOT EXISTS task_logs_no_update
    BEFORE UPDATE ON task_logs
BEGIN
    SELECT RAISE(ABORT, 'task_logs is append-only: UPDATE is forbidden');
END;

CREATE TRIGGER IF NOT EXISTS task_logs_no_delete
    BEFORE DELETE ON task_logs
BEGIN
    SELECT RAISE(ABORT, 'task_logs is append-only: DELETE is forbidden');
END;

-- ============================================================
-- 序号映射缓存（session 级别，TTL 7天）
-- ============================================================
CREATE TABLE IF NOT EXISTS task_map (
    session_id  TEXT    NOT NULL,
    seq_no      INTEGER NOT NULL,
    task_id     TEXT    NOT NULL,
    context     TEXT,
    created_at  TEXT    NOT NULL    DEFAULT (datetime('now')),
    PRIMARY KEY (session_id, seq_no),
    FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

-- ============================================================
-- 项目月度目标（v3.0.4）
-- ============================================================
CREATE TABLE IF NOT EXISTS project_goals (
    id           TEXT PRIMARY KEY,
    project_id   TEXT NOT NULL,
    month        TEXT NOT NULL,
    goal         TEXT NOT NULL,
    actual_summary TEXT,
    task_done_count   INTEGER DEFAULT 0,
    task_active_count INTEGER DEFAULT 0,
    created_at   TEXT DEFAULT (datetime('now')),
    updated_at   TEXT DEFAULT (datetime('now')),
    FOREIGN KEY (project_id) REFERENCES projects(id)
);
"""

# 索引 SQL（单独执行，方便幂等处理）
INDEX_SQL = """
CREATE INDEX IF NOT EXISTS idx_tasks_schedule_date ON tasks(schedule_date)
    WHERE status = 'active' AND is_deleted = 0;

CREATE INDEX IF NOT EXISTS idx_tasks_due_date ON tasks(due_date)
    WHERE status NOT IN ('done','cancelled') AND is_deleted = 0;

CREATE INDEX IF NOT EXISTS idx_tasks_project_status ON tasks(project_id, status, priority);

CREATE INDEX IF NOT EXISTS idx_tasks_completed_at ON tasks(completed_at)
    WHERE status = 'done';

CREATE INDEX IF NOT EXISTS idx_tasks_area_status ON tasks(area, status, completed_at);

CREATE INDEX IF NOT EXISTS idx_habit_instances_date ON habit_instances(date, habit_id, status);
"""

# schema_version 初始描述
SCHEMA_V1_DESCRIPTION = "Initial schema: tasks, projects, daily_notes, habit_definitions, habit_instances, reviews, task_logs, task_map"


def compute_checksum(sql: str) -> str:
    """计算 SQL 的 MD5 校验和"""
    return hashlib.md5(sql.encode('utf-8')).hexdigest()


def init_database(db_path: str) -> None:
    """初始化数据库（幂等）"""
    db_dir = Path(db_path).parent
    db_dir.mkdir(parents=True, exist_ok=True)

    conn = get_connection(db_path)
    try:
        with conn:
            # 执行建表 SQL
            conn.executescript(SCHEMA_SQL)
            # 执行建索引 SQL
            conn.executescript(INDEX_SQL)

            # 插入 schema_version 初始记录（只在首次执行时）
            existing = conn.execute(
                'SELECT version FROM schema_version WHERE version = 1'
            ).fetchone()
            if not existing:
                combined_sql = SCHEMA_SQL + INDEX_SQL
                conn.execute(
                    'INSERT INTO schema_version (version, applied_at, description, checksum) VALUES (?, ?, ?, ?)',
                    (1, datetime.now().isoformat(), SCHEMA_V1_DESCRIPTION, compute_checksum(combined_sql))
                )
        print(f'[OK] 数据库初始化成功：{db_path}')
        # 初始化完成后应用增量 migration
        apply_migrations(db_path)
    finally:
        conn.close()


# ============================================================
# 增量 Migration 管理
# ============================================================

# Migration 定义：{版本号: (描述, SQL列表)}
# SQL 列表中每条语句独立执行，支持 ALTER TABLE 等 DDL
MIGRATIONS: dict = {
    2: (
        "v2.0.0 snooze_until: tasks 表新增 snooze_until 字段",
        [
            "ALTER TABLE tasks ADD COLUMN snooze_until TEXT",
        ]
    ),
}


def apply_migrations(db_path: str) -> None:
    """
    应用增量 migration（幂等）。
    检查 schema_version 表中最大版本号，按序应用缺失的 migration。
    """
    if not Path(db_path).exists():
        return

    conn = get_connection(db_path)
    try:
        # 获取当前最大版本
        row = conn.execute('SELECT MAX(version) FROM schema_version').fetchone()
        current_version = row[0] if row and row[0] else 0

        applied = []
        for version in sorted(MIGRATIONS.keys()):
            if version <= current_version:
                continue

            description, sql_list = MIGRATIONS[version]
            print(f'[INFO] 应用 migration v{version}：{description}')

            with conn:
                for sql in sql_list:
                    try:
                        conn.execute(sql)
                        print(f'  [OK] {sql[:60]}...' if len(sql) > 60 else f'  [OK] {sql}')
                    except Exception as e:
                        err_msg = str(e)
                        # SQLite ALTER TABLE ADD COLUMN 在列已存在时报 duplicate column name
                        # 这是幂等保护：列已存在则跳过（正常情况）
                        if 'duplicate column name' in err_msg.lower():
                            print(f'  [SKIP] 列已存在，跳过：{err_msg}')
                        else:
                            print(f'  [ERROR] migration 执行失败：{err_msg}')
                            raise

                # 记录 migration 版本
                conn.execute(
                    'INSERT OR IGNORE INTO schema_version (version, applied_at, description, checksum) VALUES (?, ?, ?, ?)',
                    (version, datetime.now().isoformat(), description, compute_checksum('\n'.join(sql_list)))
                )
            applied.append(version)

        if applied:
            print(f'[OK] 已应用 migration：{applied}')
        else:
            print(f'[INFO] 数据库已是最新版本（schema v{current_version}）')

    finally:
        conn.close()


def reset_database(db_path: str) -> None:
    """删除并重建数据库（危险操作，需确认）"""
    db_file = Path(db_path)
    if db_file.exists():
        answer = input(f'⚠️  此操作将删除 {db_path} 中的所有数据！\n输入 "yes" 确认继续：')
        if answer.strip().lower() != 'yes':
            print('已取消。')
            return
        db_file.unlink()
        print(f'[INFO] 已删除旧数据库：{db_path}')
    init_database(db_path)


def show_status(db_path: str) -> None:
    """查看当前数据库状态"""
    db_file = Path(db_path)
    if not db_file.exists():
        print(f'[INFO] 数据库不存在：{db_path}')
        return

    conn = get_connection(db_path)
    try:
        # schema 版本
        versions = conn.execute('SELECT * FROM schema_version ORDER BY version').fetchall()
        print(f'\n数据库路径：{db_path}')
        print(f'文件大小：{db_file.stat().st_size} bytes\n')
        print('=== Schema 版本 ===')
        for v in versions:
            print(f'  版本 {v["version"]}  |  {v["applied_at"]}  |  {v["description"]}')

        # 各表记录数
        tables = ['tasks', 'projects', 'daily_notes', 'habit_definitions',
                  'habit_instances', 'reviews', 'task_logs', 'task_map']
        print('\n=== 表记录数 ===')
        for table in tables:
            try:
                count = conn.execute(f'SELECT COUNT(*) FROM {table}').fetchone()[0]
                print(f'  {table:<25} {count} 条')
            except sqlite3.OperationalError:
                print(f'  {table:<25} 表不存在')

        # 任务状态分布
        print('\n=== 任务状态分布 ===')
        rows = conn.execute(
            'SELECT status, COUNT(*) as cnt FROM tasks WHERE is_deleted = 0 GROUP BY status ORDER BY cnt DESC'
        ).fetchall()
        if rows:
            for r in rows:
                print(f'  {r["status"]:<15} {r["cnt"]} 条')
        else:
            print('  （暂无数据）')
    finally:
        conn.close()


def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro - 数据库初始化工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python db_init.py           # 初始化数据库 + 应用 migration（幂等）
  python db_init.py --migrate # 仅应用增量 migration（不重建表）
  python db_init.py --reset   # 删除并重建（危险）
  python db_init.py --status  # 查看当前状态
        """
    )
    parser.add_argument('--reset', action='store_true', help='删除并重建数据库（危险，需确认）')
    parser.add_argument('--status', action='store_true', help='查看当前数据库状态')
    parser.add_argument('--migrate', action='store_true', help='仅应用增量 migration（不重建表）')
    args = parser.parse_args()

    config = load_config()
    db_path = config['db_path']

    if args.status:
        show_status(db_path)
    elif args.reset:
        reset_database(db_path)
    elif args.migrate:
        apply_migrations(db_path)
    else:
        init_database(db_path)


if __name__ == '__main__':
    main()
