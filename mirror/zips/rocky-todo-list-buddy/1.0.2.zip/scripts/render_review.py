#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
render_review.py - LifeOps Pro 复盘报告渲染脚本
版本：v3.0.0

接收 ReviewData JSON，输出复盘报告 Markdown 到 stdout。
v3.0：不再支持 --write（写入 Daily Note），输出到 stdout 或 --output 文件。

用法：
  # stdout 输出（推荐）
  python render_review.py --input /tmp/review.json
  python render_review.py --input /tmp/review.json --mode weekly-round1

  # 写入独立文件（存档用）
  python render_review.py --input /tmp/review.json --output ~/.rocky-todo-list-buddy/reviews/daily/2026-04-10.md
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional


# ============================================================
# 枚举映射
# ============================================================

PRIORITY_DISPLAY: Dict[str, str] = {
    'urgent':  '🔴',
    'high':    '🟡',
    'normal':  '🟢',
    'waiting': '⏳',
}

# 任务最终状态映射（复盘专用）
FINAL_STATUS_DISPLAY: Dict[str, str] = {
    'done':      '✅ 完成',
    'cancelled': '❌ 取消',
    'delayed':   '⏩ 顺延',
    'waiting':   '⏳ 等待中',
    'active':    '🔄 进行中',
    'inbox':     '📥 待安排',
    'someday':   '📦 搁置',
}

# 复盘统计用 emoji（必须覆盖所有可能出现的状态值，否则统计行会显示 ?）
FINAL_STATUS_EMOJI: Dict[str, str] = {
    'done':      '✅',
    'cancelled': '❌',
    'delayed':   '⏩',
    'waiting':   '⏳',
    'active':    '🔄',   # 进行中（复盘时未更新状态的任务）
    'inbox':     '📥',   # 待安排
    'someday':   '📦',   # 搁置
}

WEEKDAY_ZH: Dict[int, str] = {
    0: '星期一',
    1: '星期二',
    2: '星期三',
    3: '星期四',
    4: '星期五',
    5: '星期六',
    6: '星期日',
}


# ============================================================
# 工具函数
# ============================================================

def _today_str() -> str:
    return date.today().isoformat()


def _format_date_display(date_str: str) -> str:
    try:
        d = date.fromisoformat(date_str)
        weekday = WEEKDAY_ZH.get(d.weekday(), '')
        return f'{date_str} {weekday}'
    except ValueError:
        return date_str


def _get_final_status(task: Dict[str, Any]) -> str:
    """
    获取任务的最终复盘状态。
    优先看 final_status 字段（复盘专用），其次看 status。
    若任务 delayed=True，返回 'delayed'。
    """
    if task.get('delayed', False) and task.get('status') != 'done':
        return 'delayed'
    fs = task.get('final_status', None)
    if fs:
        return fs
    status = task.get('status', 'active')
    return status


def _count_final_statuses(tasks: List[Dict[str, Any]]) -> str:
    """统计复盘任务的最终状态分布，格式如 4✅ 1⏩ 1⏳"""
    counts: Dict[str, int] = {}
    for task in tasks:
        fs = _get_final_status(task)
        counts[fs] = counts.get(fs, 0) + 1

    # 固定顺序展示
    order = ['done', 'delayed', 'cancelled', 'waiting', 'active', 'inbox', 'someday']
    parts = []
    for key in order:
        if key in counts:
            emoji = FINAL_STATUS_EMOJI.get(key, '?')
            parts.append(f'{counts[key]}{emoji}')
    # 其他未知状态：显示状态名而非 ?
    for key, cnt in counts.items():
        if key not in order:
            parts.append(f'{cnt}[{key}]')
    return ' '.join(parts)


def _count_priorities(tasks: List[Dict[str, Any]]) -> str:
    """统计任务优先级分布"""
    counts: Dict[str, int] = {'urgent': 0, 'high': 0, 'normal': 0, 'waiting': 0}
    for t in tasks:
        p = t.get('priority', 'normal')
        if p in counts:
            counts[p] += 1
    parts = []
    for key, emoji in [('urgent', '🔴'), ('high', '🟡'), ('normal', '🟢'), ('waiting', '⏳')]:
        if counts[key] > 0:
            parts.append(f'{counts[key]}{emoji}')
    return ' '.join(parts)


# ============================================================
# 核心渲染函数
# ============================================================

def render_review_task_table(
    group: Dict[str, Any],
    global_seq: List[int],
) -> str:
    """
    渲染单个项目组的复盘任务表格。
    统一 7 列：# | P | 任务 | 状态 | 执行时间 | DDL | 说明
    global_seq: 长度为 1 的列表，模拟引用传递（跨组序号连续）。
    """
    tasks = group.get('tasks', [])
    if not tasks:
        return ''

    name = group.get('name', '无项目任务')
    total = len(tasks)
    status_stat = _count_final_statuses(tasks)
    stat_str = f'{total} 项 · {status_stat}' if status_stat else f'{total} 项'

    lines: List[str] = []
    _EMOJI_PREFIXES = ('📂', '📌', '🏃', '💼', '🏠', '📦')
    name_display = name if any(name.startswith(p) for p in _EMOJI_PREFIXES) else f'📂 {name}'
    lines.append(f'##### {name_display}（{stat_str}）')
    lines.append('| # | P | 任务 | 状态 | 执行时间 | DDL | 说明 |')
    lines.append('|---|---|------|------|----------|-----|------|')

    for task in tasks:
        seq = global_seq[0]
        global_seq[0] += 1

        priority = task.get('priority', 'normal')
        p_emoji = PRIORITY_DISPLAY.get(priority, '🟢')
        title = task.get('title', '')
        final_status = _get_final_status(task)
        status_display = FINAL_STATUS_DISPLAY.get(final_status, final_status)

        time_slot = task.get('time_slot') or '—'
        ddl = task.get('ddl') or '—'
        if ddl and ddl != '—':
            try:
                from datetime import date as _date
                ddl_date = _date.fromisoformat(ddl)
                today_date = _date.today()
                delta = (ddl_date - today_date).days
                mm_dd = ddl_date.strftime('%m-%d')
                if delta < 0:
                    ddl = f'{mm_dd} 🔥'
                elif delta == 0:
                    ddl = f'{mm_dd} 🔔'
                elif delta == 1:
                    ddl = f'{mm_dd} ⚠️'
                else:
                    ddl = mm_dd
            except (ValueError, TypeError):
                pass

        note = task.get('note', '') or '—'
        if final_status == 'delayed' and (not task.get('note')):
            note = '顺延至明日'

        # 已完成/取消/顺延的任务标题加删除线
        if final_status in ('done', 'cancelled', 'delayed'):
            title = f'~~{title}~~'

        lines.append(f'| {seq} | {p_emoji} | {title} | {status_display} | {time_slot} | {ddl} | {note} |')

    lines.append('')
    return '\n'.join(lines)


def render_review_habits_table(habits: List[Dict[str, Any]], global_seq: List[int]) -> str:
    """
    渲染习惯复盘表格，统一 7 列，序号接续全局序号。
    global_seq: 长度为 1 的列表，函数内部递增。
    """
    if not habits:
        return ''

    done_count   = sum(1 for h in habits if h.get('status') == 'done')
    cancel_count = sum(1 for h in habits if h.get('status') == 'cancelled')

    stat_parts = []
    if done_count:
        stat_parts.append(f'{done_count}✅')
    if cancel_count:
        stat_parts.append(f'{cancel_count}❌')
    stat_str = ' '.join(stat_parts)

    header = f'##### 🏃 今日习惯（{len(habits)} 项'
    if stat_str:
        header += f' · {stat_str}'
    header += '）'

    lines: List[str] = [
        header,
        '| # | P | 任务 | 状态 | 执行时间 | DDL | 说明 |',
        '|---|---|------|------|----------|-----|------|',
    ]

    for habit in habits:
        seq = global_seq[0]
        global_seq[0] += 1

        name     = habit.get('name', '')
        time_str = habit.get('time', '') or '—'
        status   = habit.get('status', 'pending')

        if status == 'done':
            time_display   = f'✅ {time_str}' if time_str and time_str != '—' else '✅'
            status_display = '✅ 完成'
        elif status == 'cancelled':
            time_display   = time_str
            status_display = '❌ 取消'
        else:
            time_display   = f'⏰ {time_str}' if time_str and time_str != '—' else '⏰'
            status_display = '⏸️ 未完成'

        lines.append(f'| {seq} | 🟢 | {name} | {status_display} | {time_display} | — | — |')

    lines.append('')
    return '\n'.join(lines)


def render_next_day_plan(next_day_data: Dict[str, Any]) -> str:
    """
    渲染明日安排（第三轮输出）。
    工作/生活分区，按项目展示，无项目归入「无项目任务」。
    表头：# | P | 任务 | 执行时间 | DDL
    """
    if not next_day_data:
        return ''

    plan_date = next_day_data.get('date', '')
    projects  = next_day_data.get('projects', [])
    habits    = next_day_data.get('habits', [])

    work_groups = [g for g in projects if g.get('area') == 'work']
    life_groups = [g for g in projects if g.get('area') == 'life']

    lines: List[str] = []
    date_display = _format_date_display(plan_date) if plan_date else '明日'
    lines.append(f'### 📅 明日安排（{date_display}）')
    lines.append('')

    global_seq = [1]

    def _render_plan_group(group: Dict[str, Any]) -> str:
        tasks = group.get('tasks', [])
        if not tasks:
            return ''
        name = group.get('name', '无项目任务')
        _EP = ('📂', '📌', '🏃', '💼', '🏠', '📦')
        name_display = name if any(name.startswith(p) for p in _EP) else f'📂 {name}'
        grp_lines: List[str] = [
            f'**{name_display}**',
            '| # | P | 任务 | 执行时间 | DDL |',
            '|---|---|------|----------|-----|',
        ]
        for task in tasks:
            seq = global_seq[0]
            global_seq[0] += 1
            p_emoji = PRIORITY_DISPLAY.get(task.get('priority', 'normal'), '🟢')
            title = task.get('title', '')
            time_slot = task.get('time_slot') or '—'
            ddl = task.get('ddl') or '—'
            if ddl and ddl != '—':
                try:
                    from datetime import date as _date
                    ddl_date = _date.fromisoformat(ddl)
                    today_date = _date.today()
                    delta = (ddl_date - today_date).days
                    mm_dd = ddl_date.strftime('%m-%d')
                    if delta < 0:
                        ddl = f'{mm_dd} 🔥'
                    elif delta == 0:
                        ddl = f'{mm_dd} 🔔'
                    elif delta == 1:
                        ddl = f'{mm_dd} ⚠️'
                    else:
                        ddl = mm_dd
                except (ValueError, TypeError):
                    pass
            grp_lines.append(f'| {seq} | {p_emoji} | {title} | {time_slot} | {ddl} |')
        grp_lines.append('')
        return '\n'.join(grp_lines)

    # 工作区
    if work_groups:
        lines.append('**💼 工作**')
        lines.append('')
        for group in work_groups:
            text = _render_plan_group(group)
            if text:
                lines.append(text)

    # 生活区
    if life_groups:
        lines.append('**🏠 生活**')
        lines.append('')
        for group in life_groups:
            text = _render_plan_group(group)
            if text:
                lines.append(text)
    elif not life_groups:
        lines.append('**🏠 生活**（无）')
        lines.append('')

    # 习惯
    if habits:
        done_h = sum(1 for h in habits if h.get('status') == 'done')
        pending_h = sum(1 for h in habits if h.get('status') == 'pending')
        lines.append('**🏃 习惯**')
        lines.append('')
        lines.append('| # | P | 任务 | 执行时间 |')
        lines.append('|---|---|------|----------|')
        for habit in habits:
            seq = global_seq[0]
            global_seq[0] += 1
            name = habit.get('name', '')
            time_str = habit.get('time', '') or '—'
            lines.append(f'| {seq} | 🟢 | {name} | {time_str} |')
        lines.append('')

    return '\n'.join(lines)


# ============================================================
# 周复盘渲染函数
# ============================================================

def render_weekly_round1(data: Dict[str, Any]) -> str:
    """
    渲染周复盘第一轮：本周完成情况。
    data 结构：
      week_key: str               # 如 "2026-W14"
      week_range: str             # 如 "2026-03-30 ~ 2026-04-05"
      work_planned: int
      work_unplanned: int
      work_done: int
      life_planned: int
      life_unplanned: int
      life_done: int
      habits: list of {name, done, total}
      work_projects: list of {name, done_tasks: [...], undone_tasks: [...]}
      life_projects: list of {name, done_tasks: [...], undone_tasks: [...]}
    """
    week_key   = data.get('week_key', '')
    week_range = data.get('week_range', '')

    wp  = data.get('work_planned', 0)
    wu  = data.get('work_unplanned', 0)
    wd  = data.get('work_done', 0)
    lp  = data.get('life_planned', 0)
    lu  = data.get('life_unplanned', 0)
    ld  = data.get('life_done', 0)
    habits = data.get('habits', [])

    def rate(done: int, planned: int, unplanned: int) -> str:
        total = planned + unplanned
        if total == 0:
            return '—'
        pct = int(done / total * 100)
        return f'{done}/{total}（{pct}%）'

    lines: List[str] = [
        f'## 📅 {week_key} 周复盘（{week_range}）',
        '',
        '### 📊 本周总览',
        '',
        '| 维度 | 计划 | 计划外 | 完成 | 完成率 |',
        '|------|------|--------|------|--------|',
        f'| 💼 工作 | {wp} | {wu} | {wd} | {rate(wd, wp, wu)} |',
        f'| 🏠 生活 | {lp} | {lu} | {ld} | {rate(ld, lp, lu)} |',
    ]
    for h in habits:
        hname = h.get('name', '')
        hdone = h.get('done', 0)
        htotal = h.get('total', 0)
        hrate = f'{int(hdone/htotal*100)}%' if htotal > 0 else '—'
        lines.append(f'| 🏃 {hname} | {htotal} 次 | — | {hdone} 次 | {hrate} |')
    lines.append('')

    # v3.0.4: 月目标对照区块
    monthly_goals = data.get('monthly_goals', {})
    if monthly_goals:
        lines.append('### 📌 本月目标对照')
        lines.append('')
        # 从本周工作项目中提取项目名，与月目标对照
        all_project_names = set()
        for proj in data.get('work_projects', []):
            all_project_names.add(proj.get('name', ''))
        for proj in data.get('life_projects', []):
            all_project_names.add(proj.get('name', ''))

        for pid, goal in monthly_goals.items():
            # 找本周该项目的完成情况
            week_done = 0
            week_tasks_titles = []
            for proj in data.get('work_projects', []) + data.get('life_projects', []):
                if proj.get('name') == pid:
                    week_done = len(proj.get('done_tasks', []))
                    week_tasks_titles = [t.get('title', '') for t in proj.get('done_tasks', [])[:3]]
            lines.append(f'📂 {pid}')
            lines.append(f'  🎯 月目标：{goal}')
            if week_tasks_titles:
                lines.append(f'  📊 本周推进：{" · ".join(week_tasks_titles)}（{week_done} 项完成）')
            else:
                lines.append(f'  📊 本周推进：无')
            lines.append('')

    # ── 本周工作（按项目）
    work_projects = data.get('work_projects', [])
    if work_projects:
        lines.append('### 💼 本周工作')
        lines.append('')
        for proj in work_projects:
            proj_name  = proj.get('name', '无项目任务')
            done_tasks  = proj.get('done_tasks', [])
            undone_tasks = proj.get('undone_tasks', [])
            total_in_proj = len(done_tasks) + len(undone_tasks)
            lines.append(f'#### 📂 {proj_name}（完成 {len(done_tasks)}/{total_in_proj}）')
            lines.append('')
            lines.append('| 状态 | 任务 |')
            lines.append('|------|------|')
            for t in done_tasks:
                tag = '⭐ 计划外' if t.get('unplanned') else '📋 完成'
                lines.append(f'| {tag} | {t.get("title", "")} |')
            for t in undone_tasks:
                lines.append(f'| 🔄 未完成 | {t.get("title", "")} |')
            lines.append('')

    # ── 本周生活（按项目）
    life_projects = data.get('life_projects', [])
    if life_projects:
        lines.append('### 🏠 本周生活')
        lines.append('')
        for proj in life_projects:
            proj_name  = proj.get('name', '无项目任务')
            done_tasks  = proj.get('done_tasks', [])
            undone_tasks = proj.get('undone_tasks', [])
            total_in_proj = len(done_tasks) + len(undone_tasks)
            lines.append(f'#### 📂 {proj_name}（完成 {len(done_tasks)}/{total_in_proj}）')
            lines.append('')
            lines.append('| 状态 | 任务 |')
            lines.append('|------|------|')
            for t in done_tasks:
                tag = '⭐ 计划外' if t.get('unplanned') else '📋 完成'
                lines.append(f'| {tag} | {t.get("title", "")} |')
            for t in undone_tasks:
                lines.append(f'| 🔄 未完成 | {t.get("title", "")} |')
            lines.append('')

    # ── 总结引导语
    # 找出完成任务最多的项目
    all_projs = work_projects + life_projects
    top_proj = None
    top_cnt  = 0
    for proj in all_projs:
        cnt = len(proj.get('done_tasks', []))
        if cnt > top_cnt:
            top_cnt  = cnt
            top_proj = proj.get('name', '')

    undone_total = sum(len(p.get('undone_tasks', [])) for p in all_projs)
    undone_projs = [p['name'] for p in all_projs if p.get('undone_tasks')]

    lines.append('---')
    lines.append('')
    if top_proj and top_cnt > 0:
        lines.append(
            f'本周完成任务最多的项目是 **{top_proj}（{top_cnt} 项）**，主要精力集中于此。'
        )
    if undone_total > 0:
        undone_str = '、'.join(undone_projs[:3])
        lines.append(
            f'有 **{undone_total} 项**计划任务未完成，主要集中在 {undone_str}，下周需要重点跟进。'
        )
    lines.append('')
    lines.append('本周有没有遗漏的完成事项，或想记录的感悟？')

    return '\n'.join(lines)


def render_weekly_round2(data: Dict[str, Any]) -> str:
    """
    渲染周复盘第二轮：下周计划视图。
    data 结构：
      next_week_key: str
      next_week_range: str
      work_projects: list of {name, tasks: [{id, title, priority, schedule_date, due_date, status}]}
      life_projects: list of {name, tasks: [...]}
      candidate_pool: list of {id, title, area, priority, project_id}
      overdue_tasks: list of {id, title, area, priority, schedule_date}
      seq_map: dict  # 全局序号映射
    """
    next_week_key   = data.get('next_week_key', '')
    next_week_range = data.get('next_week_range', '')

    PRIORITY_EMOJI = {'urgent': '🔴', 'high': '🟡', 'normal': '🟢', 'waiting': '⏳'}
    WEEKDAY_MAP = {'Mon':'周一','Tue':'周二','Wed':'周三','Thu':'周四',
                   'Fri':'周五','Sat':'周六','Sun':'周日'}

    def weekday(date_str: str) -> str:
        if not date_str:
            return '—'
        try:
            from datetime import date as _date
            d = _date.fromisoformat(date_str)
            eng = d.strftime('%a')
            return WEEKDAY_MAP.get(eng, date_str)
        except Exception:
            return date_str

    def ddl_display(due: str) -> str:
        if not due:
            return '—'
        from datetime import date as _date
        try:
            delta = (_date.fromisoformat(due) - _date.today()).days
            if delta < 0:
                return f'{due} 🔥'
            elif delta == 0:
                return f'{due} ⚠️今天'
            elif delta <= 3:
                return f'{due} ⚠️{delta}天'
            return due
        except Exception:
            return due

    global_seq = [1]
    seq_map: dict = {}
    lines: List[str] = [
        f'## 🗓️ 下周计划（{next_week_key} · {next_week_range}）',
        '',
    ]

    def render_proj_section(projects: List[Dict], area_label: str) -> None:
        if not projects:
            return
        lines.append(f'### {area_label}')
        lines.append('')
        for proj in projects:
            pname = proj.get('name', '无项目任务')
            tasks = proj.get('tasks', [])
            if not tasks:
                continue
            lines.append(f'#### 📂 {pname}（{len(tasks)} 项）')
            lines.append('')
            lines.append('| # | P | 任务 | 执行日 | DDL |')
            lines.append('|---|---|------|--------|-----|')
            for t in tasks:
                seq = global_seq[0]
                global_seq[0] += 1
                tid   = t.get('id', '')
                seq_map[str(seq)] = tid
                p_emoji = PRIORITY_EMOJI.get(t.get('priority', 'normal'), '🟢')
                title   = t.get('title', '')
                sched   = weekday(t.get('schedule_date', ''))
                due     = ddl_display(t.get('due_date', ''))
                lines.append(f'| {seq} | {p_emoji} | {title} | {sched} | {due} |')
            lines.append('')

    render_proj_section(data.get('work_projects', []), '💼 下周工作')
    render_proj_section(data.get('life_projects', []), '🏠 下周生活')

    # ── 候选任务
    candidate = data.get('candidate_pool', [])
    if candidate:
        lines.append('### 📦 候选任务（待安排）')
        lines.append('')
        lines.append('| # | P | 任务 | 项目 | 分区 |')
        lines.append('|---|---|------|------|------|')
        for t in candidate:
            seq = global_seq[0]
            global_seq[0] += 1
            tid     = t.get('id', '')
            seq_map[str(seq)] = tid
            p_emoji = PRIORITY_EMOJI.get(t.get('priority', 'normal'), '🟢')
            title   = t.get('title', '')
            proj    = t.get('project_id') or '无项目'
            area    = '💼' if t.get('area') == 'work' else '🏠'
            lines.append(f'| {seq} | {p_emoji} | {title} | {proj} | {area} |')
        lines.append('')

    # ── 过期任务
    overdue = data.get('overdue_tasks', [])
    if overdue:
        lines.append('### ⏩ 过期任务（需处理）')
        lines.append('')
        lines.append('| # | P | 任务 | 原计划日 | 分区 |')
        lines.append('|---|---|------|----------|------|')
        for t in overdue:
            seq = global_seq[0]
            global_seq[0] += 1
            tid     = t.get('id', '')
            seq_map[str(seq)] = tid
            p_emoji = PRIORITY_EMOJI.get(t.get('priority', 'normal'), '🟢')
            title   = t.get('title', '')
            sched   = t.get('schedule_date', '—')
            area    = '💼' if t.get('area') == 'work' else '🏠'
            lines.append(f'| {seq} | {p_emoji} | {title} | {sched} | {area} |')
        lines.append('')

    # ── 询问三件事
    lines.append('---')
    lines.append('')
    lines.append('以上是下周的完整视图。')
    lines.append('')
    lines.append('**请告诉我下周最重要的 3 件事是什么？**')
    lines.append('（可以用序号指定已有任务，也可以自由填写新事项）')

    # TASK_SEQ_MAP 注释
    import json as _json
    lines.append(
        f'\n<!-- TASK_SEQ_MAP session=weekly-round2-{next_week_key} '
        f'map={_json.dumps(seq_map, ensure_ascii=False)} -->'
    )

    return '\n'.join(lines)


# ============================================================
# 月复盘渲染函数（复用周复盘逻辑，差异仅在文案和 key 名）
# ============================================================

def render_monthly_round1(data: Dict[str, Any]) -> str:
    """渲染月复盘第一轮：按项目维度展示本月进展 + 目标对照（v3.0.4）"""
    month_key = data.get('month_key', '')
    month_range = data.get('month_range', '')
    projects = data.get('projects', [])
    habits = data.get('habits', [])

    parts: List[str] = []
    parts.append(f'## 📅 {month_key} 月复盘（{month_range}）')
    parts.append('')

    if projects:
        parts.append('### 📂 项目进展')
        parts.append('')
        for p in projects:
            pid = p.get('project_id', '无项目任务')
            goal = p.get('goal', '')
            done = p.get('done_count', 0)
            active = p.get('active_count', 0)
            done_tasks = p.get('done_tasks', [])

            parts.append(f'#### 📂 {pid}')
            if goal:
                parts.append(f'  🎯 月目标：{goal}')
            else:
                parts.append(f'  🎯 月目标：（未设置）')
            parts.append(f'  📊 完成 {done} 项 · 进行中 {active} 项')

            # 列出已完成的任务标题（供 AI 提炼关键成果）
            if done_tasks:
                parts.append(f'  💡 已完成任务：')
                for t in done_tasks[:8]:  # 最多展示 8 条
                    parts.append(f'    - {t.get("title", "")}')
            parts.append('')

    if habits:
        parts.append('### 🏃 本月习惯')
        for h in habits:
            pct = f'{h["done"]}/{h["total"]}' if h['total'] > 0 else '0/0'
            rate = round(h['done'] / h['total'] * 100) if h['total'] > 0 else 0
            parts.append(f'  {h["name"]}：{pct}（{rate}%）')
        parts.append('')

    return '\n'.join(parts)


def render_monthly_round2(data: Dict[str, Any]) -> str:
    """渲染月复盘第二轮：定下月项目目标（v3.0.4）"""
    month_key = data.get('month_key', '')
    nm_key = data.get('next_month_key', '')
    nm_range = data.get('next_month_range', '')
    projects = data.get('projects', [])

    parts: List[str] = []
    parts.append(f'## 🗓️ {nm_key} 目标规划（{nm_range}）')
    parts.append('')

    if projects:
        for p in projects:
            pid = p.get('project_id', '')
            current_goal = p.get('current_goal', '')
            actual = p.get('actual_summary', '')
            backlog = p.get('backlog_count', 0)

            parts.append(f'#### 📂 {pid}')
            if current_goal:
                actual_str = actual if actual else '（待填写）'
                parts.append(f'  {month_key} 目标：{current_goal} → 实际：{actual_str}')
            parts.append(f'  当前积压：{backlog} 项')
            parts.append(f'  建议下月目标：（请 AI 根据积压任务建议，或用户直接填写）')
            parts.append('')

    return '\n'.join(parts)


def render_evening_review(data: Dict[str, Any], next_day_data: Optional[Dict[str, Any]] = None) -> str:
    """
    渲染完整的每日复盘报告（evening-review section）。

    data: ReviewData JSON（今日复盘数据）
    next_day_data: DailyPlan JSON（明日计划数据，可选，用于第三轮「明日安排」）
    """
    review_date   = data.get('date', _today_str())
    projects: List[Dict[str, Any]] = data.get('projects', [])
    habits: List[Dict[str, Any]]   = data.get('habits', [])
    work_planned   = int(data.get('work_planned', 0))
    work_done      = int(data.get('work_done', 0))
    work_unplanned = int(data.get('work_unplanned', 0))
    life_planned   = int(data.get('life_planned', 0))
    life_done      = int(data.get('life_done', 0))
    life_unplanned = int(data.get('life_unplanned', 0))
    # 兼容旧字段 unplanned_done（不区分工作/生活）
    unplanned_done = int(data.get('unplanned_done', 0))
    if unplanned_done and not work_unplanned and not life_unplanned:
        work_unplanned = unplanned_done  # 旧数据兜底：全归工作区
    reflection = data.get('reflection', '') or ''

    work_groups = [g for g in projects if g.get('area') == 'work']
    life_groups = [g for g in projects if g.get('area') == 'life']

    output_parts: List[str] = []
    global_seq = [1]

    # ── 标题
    output_parts.append(f'## 🌙 每日复盘 — {review_date}')
    output_parts.append('')

    # ── 任务最终确认（第一轮）
    output_parts.append('### 📋 今日任务最终确认')
    output_parts.append('')

    if work_groups:
        work_tasks_all = [t for g in work_groups for t in g.get('tasks', [])]
        w_stat  = _count_final_statuses(work_tasks_all)
        w_total = len(work_tasks_all)
        w_header = f'{w_total} 项 · {w_stat}' if w_stat else f'{w_total} 项'
        output_parts.append(f'#### 💼 工作区（{w_header}）')
        output_parts.append('')
        for group in work_groups:
            t = render_review_task_table(group, global_seq)
            if t:
                output_parts.append(t)
    else:
        output_parts.append('#### 💼 工作区（0 项）')
        output_parts.append('')

    if life_groups:
        life_tasks_all = [t for g in life_groups for t in g.get('tasks', [])]
        l_stat  = _count_final_statuses(life_tasks_all)
        l_total = len(life_tasks_all)
        l_header = f'{l_total} 项 · {l_stat}' if l_stat else f'{l_total} 项'
        output_parts.append(f'#### 🏠 生活区（{l_header}）')
        output_parts.append('')
        for group in life_groups:
            t = render_review_task_table(group, global_seq)
            if t:
                output_parts.append(t)

    # 习惯（序号接续全局）
    if habits:
        output_parts.append('#### 🏃 今日习惯')
        output_parts.append('')
        output_parts.append(render_review_habits_table(habits, global_seq))

    # ── 分割线
    output_parts.append('---')
    output_parts.append('')

    # ── 今日小结（新表格：计划 | 计划外 | 完成 | 完成率）
    output_parts.append('### 📊 今日小结')
    output_parts.append('')

    # 自动推算（如果 JSON 未提供则从 projects 数据计算）
    if not work_planned:
        work_planned = sum(len(g.get('tasks', [])) for g in work_groups)
    if not work_done:
        work_done = sum(
            1 for g in work_groups for t in g.get('tasks', [])
            if _get_final_status(t) == 'done'
        )
    if not life_planned:
        life_planned = sum(len(g.get('tasks', [])) for g in life_groups)
    if not life_done:
        life_done = sum(
            1 for g in life_groups for t in g.get('tasks', [])
            if _get_final_status(t) == 'done'
        )

    def _rate(done: int, planned: int, unplanned: int) -> str:
        total = planned + unplanned
        if total == 0:
            return '—'
        pct = int(done / total * 100)
        return f'{done}/{total}（{pct}%）'

    habit_done    = sum(1 for h in habits if h.get('status') == 'done')
    habit_total   = len(habits)
    habit_rate    = f'{habit_done}/{habit_total}（{int(habit_done/habit_total*100) if habit_total else 0}%）' if habit_total else '—'
    habit_names   = ' · '.join(
        ('✅ ' if h.get('status') == 'done' else '❌ ') + h.get('name', '')
        for h in habits
    ) if habits else '—'

    output_parts.append('| 维度 | 计划 | 计划外 | 完成 | 完成率 |')
    output_parts.append('|------|------|--------|------|--------|')
    output_parts.append(
        f'| 💼 工作 | {work_planned} | {work_unplanned} | {work_done + work_unplanned} | '
        f'{_rate(work_done + work_unplanned, work_planned, work_unplanned)} |'
    )
    output_parts.append(
        f'| 🏠 生活 | {life_planned} | {life_unplanned} | {life_done + life_unplanned} | '
        f'{_rate(life_done + life_unplanned, life_planned, life_unplanned)} |'
    )
    output_parts.append(
        f'| 🏃 习惯 | {habit_total} | 0 | {habit_done} | {habit_rate} |'
    )
    output_parts.append('')
    if habits:
        output_parts.append(f'习惯详情：{habit_names}')
        output_parts.append('')

    # ── 明日安排（如果传入 next_day_data）
    if next_day_data:
        output_parts.append(render_next_day_plan(next_day_data))

    # ── 今日收获
    output_parts.append('### 💡 今日收获')
    output_parts.append('')
    output_parts.append(reflection if reflection.strip() else '（无）')
    output_parts.append('')

    return '\n'.join(output_parts)


# ============================================================
# 配置加载（用于 --write 模式）
# ============================================================

def load_config() -> dict:
    config_path = Path(__file__).resolve().parent.parent / 'config.json'
    config = json.loads(config_path.read_text(encoding='utf-8'))
    config['db_path'] = str(Path(config['db_path']).expanduser())
    return config


# ============================================================
# CLI 入口
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro - 每日复盘报告渲染脚本',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument('--input', '-i', help='输入 JSON 文件路径（不指定则从 stdin 读取）')
    parser.add_argument('--output', '-o', default=None,
                        help='将渲染结果写入指定文件路径（不指定则输出到 stdout）')
    parser.add_argument('--format', '-f', choices=['md', 'plain'], default='md',
                        help='输出格式：md（默认）/ plain（纯文本，企微 Bot / 移动端场景）')
    parser.add_argument(
        '--mode',
        choices=['daily', 'weekly-round1', 'weekly-round2', 'monthly-round1', 'monthly-round2'],
        default='daily',
        help='渲染模式：daily / weekly-round1/2 / monthly-round1/2',
    )
    args = parser.parse_args()

    # 读取 JSON
    if args.input:
        try:
            with open(args.input, 'r', encoding='utf-8') as f:
                raw = f.read()
        except FileNotFoundError:
            print(f'❌ 文件不存在：{args.input}', file=sys.stderr)
            sys.exit(1)
    else:
        raw = sys.stdin.read()

    if not raw.strip():
        print('❌ 输入为空', file=sys.stderr)
        sys.exit(1)

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        print(f'❌ JSON 解析失败：{e}', file=sys.stderr)
        sys.exit(1)

    mode = getattr(args, 'mode', 'daily')
    if mode == 'weekly-round1':
        result = render_weekly_round1(data)
    elif mode == 'weekly-round2':
        result = render_weekly_round2(data)
    elif mode == 'monthly-round1':
        result = render_monthly_round1(data)
    elif mode == 'monthly-round2':
        result = render_monthly_round2(data)
    else:
        result = render_evening_review(data)

    # v3.0.1: 根据 mode 追加引导语
    GUIDE_LINES = {
        'daily': '\n---\n以上是今天的完成情况。请告诉我：\n1. 任务调整（如 #3 完成、#5 顺延明天）\n2. 计划外完成的事项\n3. 今天有什么感悟或收获？（没有可以不写）',
        'weekly-round1': '\n---\n以上是本周回顾。请告诉我任务调整和本周感悟（没有可以不写）。',
        'weekly-round2': '\n---\n以上是下周完整视图，请告诉我下周最重要的 3 件事。',
        'monthly-round1': '\n---\n以上是本月回顾。请告诉我任务调整和本月感悟（没有可以不写）。',
        'monthly-round2': '\n---\n以上是下月完整视图，请告诉我下月最重要的 3 件事。',
    }
    guide = GUIDE_LINES.get(mode, '')
    if guide:
        result = result + guide

    # v3.0：输出到 stdout 或 --output 文件（不再写 Daily Note）
    if getattr(args, 'output', None):
        table_rows = sum(1 for line in result.splitlines()
                         if line.startswith('|') and not line.startswith('|---') and '任务' not in line and '---' not in line)
        render_check = f'<!-- RENDER_CHECK: rows={table_rows} -->'
        content = result + '\n' + render_check + '\n'
        try:
            out_path = Path(args.output)
            out_path.parent.mkdir(parents=True, exist_ok=True)
            out_path.write_text(content, encoding='utf-8')
            print(f'[OK] 渲染结果已写入：{args.output}（rows={table_rows}）', file=sys.stderr)
        except Exception as e:
            print(f'[ERROR] 渲染文件写入失败：{e}', file=sys.stderr)
            sys.exit(1)
    else:
        print(result)


# ============================================================
# 内嵌自测
# ============================================================

def _self_test() -> None:
    """使用样本 JSON 验证复盘报告输出格式"""
    sample: Dict[str, Any] = {
        'date': '2026-04-03',
        'projects': [
            {
                'name': 'P-播客项目',
                'area': 'work',
                'tasks': [
                    {
                        'id': 'T-20260403-a3f91c',
                        'title': '后台/浮窗播放技术方案确认',
                        'priority': 'urgent',
                        'area': 'work',
                        'status': 'active',
                        'final_status': 'delayed',
                        'note': '明天处理',
                        'delayed': True,
                        'time_slot': '上午',
                        'ddl': '2026-04-05',
                    },
                    {
                        'id': 'T-20260403-b7d820',
                        'title': '播客规划输出和沟通',
                        'priority': 'urgent',
                        'area': 'work',
                        'status': 'done',
                        'note': '',
                        'time_slot': '下午',
                    },
                ],
            },
            {
                'name': '无项目任务',
                'area': 'work',
                'tasks': [
                    {
                        'id': 'T-20260403-d4f5a6',
                        'title': '知识卡数据初始化',
                        'priority': 'normal',
                        'area': 'work',
                        'status': 'done',
                        'note': '',
                    },
                ],
            },
            {
                'name': '无项目任务',
                'area': 'life',
                'tasks': [
                    {
                        'id': 'T-20260403-f6a7b8',
                        'title': '去超市买牛奶',
                        'priority': 'normal',
                        'area': 'life',
                        'status': 'done',
                        'note': '',
                    },
                ],
            },
        ],
        'habits': [
            {'name': '晨间跑步', 'time': '07:30', 'status': 'done'},
            {'name': '冥想练习', 'time': '21:00', 'status': 'cancelled'},
        ],
        'work_planned': 3,
        'work_done': 2,
        'work_unplanned': 0,
        'life_planned': 1,
        'life_done': 1,
        'life_unplanned': 0,
        'unplanned_done': 0,
        'reflection': '今日完成了核心技术方案讨论。今天天气不错，散步30分钟。',
    }

    next_day_sample: Dict[str, Any] = {
        'date': '2026-04-04',
        'projects': [
            {
                'name': 'P-播客项目',
                'area': 'work',
                'tasks': [
                    {
                        'id': 'T-20260403-a3f91c',
                        'title': '后台/浮窗播放技术方案确认',
                        'priority': 'urgent',
                        'area': 'work',
                        'status': 'active',
                        'ddl': '2026-04-05',
                    },
                ],
            },
        ],
        'habits': [
            {'name': '晨间跑步', 'time': '07:30', 'status': 'pending'},
        ],
    }

    print('=' * 60)
    print('【render_review.py 自测 - 每日复盘报告（v2.1 新格式）】')
    print('=' * 60)
    result = render_evening_review(sample, next_day_data=next_day_sample)
    print(result)

    # 验证关键内容
    assert '## 🌙 每日复盘' in result, '应有复盘标题'
    assert '### 📋 今日任务最终确认' in result, '应有任务确认区'
    assert '⏩ 顺延' in result, '应包含顺延状态'
    assert '✅ 完成' in result, '应包含完成状态'
    assert '### 📊 今日小结' in result, '应有今日小结'
    assert '### 💡 今日收获' in result, '应有收获区'
    assert '今日完成了核心技术方案讨论' in result, '应包含用户反思内容'
    assert '- [ ]' not in result, '复盘报告不应包含 checkbox'
    # 统一6列：执行时间 和 DDL 列存在
    assert '执行时间' in result, '应有执行时间列'
    assert 'DDL' in result, '应有DDL列'
    # 习惯序号接续（任务有 1,2,3，习惯从 4 开始）
    assert '| 4 |' in result, '习惯序号应接续主任务（从4开始）'
    # 今日小结表格
    assert '计划外' in result, '今日小结应有计划外列'
    # 明日安排
    assert '明日安排' in result, '应有明日安排'
    assert '📅' in result, '明日安排应有日历 emoji'
    print('\n✅ 所有断言通过！')
    print('✅ 新格式：统一7列 + 习惯接续序号 + 今日小结表格 + 明日安排按项目')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        main()
    else:
        _self_test()
