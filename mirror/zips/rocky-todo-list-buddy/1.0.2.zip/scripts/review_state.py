#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
review_state.py - LifeOps Pro 流程状态追踪脚本 v4.0

支持：
  - 晨间规划（morning_plan）：4 步状态机，防止跳步
  - 每日/每周/每月复盘（daily/weekly/monthly）：三轮 + 感悟卡口状态机

状态持久化到 ~/.rocky-todo-list-buddy/review_state.json，每步必须通过脚本推进。

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【晨间规划状态机（morning_plan）v4.0】

Key 格式：morning_plan:YYYY-MM-DD

步骤顺序（step 编号）：
  1 = previewed       候选池+计划表已展示给用户（build_plan --render stdout）
  2 = user_confirmed  用户已确认今日计划（stop-wait 点已通过）
  3 = db_written      数据库已写入（激活任务/处理过期/更新状态）
  4 = done            晨间规划完成

卡口规则：
  - done 前：必须 step >= 3（db_written）

子命令（morning_plan 专用）：
  advance --to {step}   推进到指定步骤（只能向前，不能后退）
  assert-step --min {n} 断言当前步骤 >= n，用于外部卡口检查（失败则 exit 1）
  check                 查看当前步骤
  done                  标记完成（强制验证 step >= 3）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
【复盘状态机（daily/weekly/monthly）v4.0】

Key 格式：
  daily   → "daily:YYYY-MM-DD"
  weekly  → "weekly:YYYY-WNN"
  monthly → "monthly:YYYY-MM"

轮次流转（v3.0.3 简化为 2 轮）：
  round1（回顾 + 感悟）→ round2（规划 + 收尾）→ done

  - round1：展示完成情况，用户一次性回复任务调整和感悟
  - round2：展示明日/下周/下月计划，用户确认后收尾

子命令（复盘类型）：
  start              开始复盘，进入第一轮（已在进行中则拒绝）
  present-round1     标记第一轮已展示给用户（解锁 next 到第二轮）
  next               完成当前轮次，进入下一轮
  check              查看当前轮次状态（入口必须第一个调用）
  done               标记复盘完成（强制验证 round2_done）
  status             查看最近所有类型的复盘状态（无需 --type/--key）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
用法示例：

  # 晨间规划
  python review_state.py check       --type morning_plan --key 2026-04-07
  python review_state.py advance     --type morning_plan --key 2026-04-07 --to previewed
  python review_state.py advance     --type morning_plan --key 2026-04-07 --to user_confirmed
  python review_state.py assert-step --type morning_plan --key 2026-04-07 --min 2
  python review_state.py advance     --type morning_plan --key 2026-04-07 --to db_written
  python review_state.py done        --type morning_plan --key 2026-04-07

  # 复盘（v4.0 简化为 2 轮）
  python review_state.py start          --type daily   --key 2026-04-04
  python review_state.py check          --type daily   --key 2026-04-04
  python review_state.py present-round1 --type daily   --key 2026-04-04   # 展示后标记
  python review_state.py next           --type daily   --key 2026-04-04   # round1 → round2
  python review_state.py done           --type daily   --key 2026-04-04   # round2 完成后

  python review_state.py start  --type weekly  --key 2026-W15
  python review_state.py start  --type monthly --key 2026-04
  python review_state.py status
"""

from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Optional

# ── 常量 ──────────────────────────────────────────────────────────────────────

STATE_FILE      = Path.home() / '.rocky-todo-list-buddy' / 'review_state.json'
STATE_FILE_TEST = Path.home() / '.rocky-todo-list-buddy' / 'review_state_test.json'

SKILL_ROOT = Path(__file__).resolve().parent.parent

def _get_db_path() -> Path:
    """从 config.json 读取 db_path，fallback 到默认值"""
    cfg_file = SKILL_ROOT / 'config.json'
    if cfg_file.exists():
        cfg = json.loads(cfg_file.read_text())
        return Path(cfg.get('db_path', '~/.rocky-todo-list-buddy/rocky.db')).expanduser()
    return Path.home() / '.rocky-todo-list-buddy' / 'rocky.db'


def _is_test_key(key: str) -> bool:
    """判断是否为沙盒演练 key（以 test- 开头）"""
    return key.startswith('test-')

REVIEW_TYPES = ('daily', 'weekly', 'monthly')
ALL_TYPES = ('morning_plan', 'daily', 'weekly', 'monthly')

# ── backlog 扫描窗口（按类型，单位：天）──────────────────────────────────────
# 每日复盘不扫描（策略：漏记不补）
BACKLOG_SCAN_DAYS: Dict[str, int] = {
    'weekly':  14,
    'monthly': 60,
}

# ── 晨间规划步骤定义 ──────────────────────────────────────────────────────────

# 步骤名称 → 编号映射
MORNING_STEPS: Dict[str, int] = {
    'previewed':      1,
    'user_confirmed': 2,
    'db_written':     3,
    'done':           4,
}

# 步骤编号 → 名称
MORNING_STEP_NAMES: Dict[int, str] = {v: k for k, v in MORNING_STEPS.items()}

# 步骤描述（面向 Agent 的提示）
MORNING_STEP_DESC: Dict[int, str] = {
    1: '候选池+计划表已展示给用户（build_plan --render 直接 stdout）',
    2: '用户已确认今日计划 🛑 停等点已通过',
    3: '数据库已写入（激活任务、处理过期、更新状态）',
    4: '晨间规划完成',
}

# 每步完成后的下一步提示
MORNING_NEXT_HINT: Dict[int, str] = {
    1: '🛑 停等用户确认今日计划，用户确认后调用: advance --to user_confirmed',
    2: '执行 batch_update.py 写入数据库（激活 inbox 任务/更新过期任务），完成后调用: advance --to db_written',
    3: '调用: done --type morning_plan',
    4: '晨间规划已全部完成',
}

# ── 复盘类型定义 ──────────────────────────────────────────────────────────────

ROUNDS: Dict[str, Dict[int, str]] = {
    'daily': {
        1: '第一轮：回顾今天 + 感悟',
        2: '第二轮：规划明天 + 收尾',
    },
    'weekly': {
        1: '第一轮：回顾本周 + 感悟',
        2: '第二轮：规划下周 + 收尾',
    },
    'monthly': {
        1: '第一轮：回顾本月 + 感悟',
        2: '第二轮：规划下月 + 收尾',
    },
}

ROUND_STOP_HINT: Dict[str, Dict[int, str]] = {
    'daily': {
        1: '展示今日完成情况后 🛑 停等用户反馈（任务调整 + 感悟，一次性输入）',
        2: '展示明日计划后 🛑 停等用户确认，确认后收尾',
    },
    'weekly': {
        1: '展示本周回顾后 🛑 停等用户反馈（任务调整 + 感悟）',
        2: '展示下周规划后 🛑 停等用户确认最重要 3 件事，确认后收尾',
    },
    'monthly': {
        1: '展示本月回顾后 🛑 停等用户反馈（任务调整 + 感悟）',
        2: '展示下月规划后 🛑 停等用户确认最重要 3 件事，确认后收尾',
    },
}

TYPE_DISPLAY = {
    'morning_plan': '晨间规划',
    'daily':        '每日复盘',
    'weekly':       '每周复盘',
    'monthly':      '每月复盘',
}


# ── 状态读写 ──────────────────────────────────────────────────────────────────

def _get_state_file(key: str = '') -> Path:
    """根据 key 返回对应的状态文件（test- 前缀走沙盒文件，空 key 走生产文件）"""
    return STATE_FILE_TEST if (key and _is_test_key(key)) else STATE_FILE


def _load_state(key: str = '') -> Dict[str, Any]:
    sf = _get_state_file(key)
    if sf.exists():
        try:
            return json.loads(sf.read_text(encoding='utf-8'))
        except (json.JSONDecodeError, IOError):
            pass
    return {}


def _save_state(state: Dict[str, Any], key: str = '') -> None:
    sf = _get_state_file(key)
    sf.parent.mkdir(parents=True, exist_ok=True)
    tmp = sf.with_suffix('.tmp')
    tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
    tmp.replace(sf)


def _now() -> str:
    return datetime.now().strftime('%Y-%m-%d %H:%M:%S')


def _state_key(review_type: str, key: str) -> str:
    return f'{review_type}:{key}'


# ══════════════════════════════════════════════════════════════════════════════
# 晨间规划状态机
# ══════════════════════════════════════════════════════════════════════════════

def _scan_backlog(exclude_key: str = '') -> list:
    """
    扫描漏记的周/月复盘（不扫每日复盘）。
    按各类型窗口期过滤，排除今天和已完成的记录。
    月复盘额外受 system_start_date 和 backlog_monthly_window_days 限制。
    返回：[{"type": "weekly", "key": "2026-W14", "days_ago": 8}, ...]
    """
    import sqlite3
    from datetime import date, timedelta

    today = date.today()
    today_str = today.isoformat()
    results = []

    # 读取 config（system_start_date + backlog_monthly_window_days）
    try:
        cfg_path = Path(__file__).resolve().parent.parent / 'config.json'
        cfg = json.loads(cfg_path.read_text())
        system_start = date.fromisoformat(cfg.get('system_start_date', '2000-01-01'))
        monthly_window = int(cfg.get('backlog_monthly_window_days', 60))
    except Exception:
        system_start = date(2000, 1, 1)
        monthly_window = 60

    # 先从状态文件找已存在（in_progress 或 done）的 key，便于判断"已有记录"
    state = _load_state()
    existing_done = set()
    for sk, entry in state.items():
        if entry.get('done'):
            existing_done.add(sk)

    for rtype, days in BACKLOG_SCAN_DAYS.items():
        # 月复盘：窗口期取 config 的 backlog_monthly_window_days
        if rtype == 'monthly':
            days = monthly_window
        cutoff = today - timedelta(days=days)

        # 生成该类型在窗口内所有应有的 key
        expected_keys = []
        if rtype == 'weekly':
            # 生成窗口内每周的 ISO week key（YYYY-WNN），排除当前周
            cur = cutoff
            current_week = today.isocalendar()[:2]  # (year, week)
            while cur <= today:
                y, w, _ = cur.isocalendar()
                if (y, w) != current_week:
                    wkey = f"{y}-W{w:02d}"
                    expected_keys.append((wkey, cur))
                cur += timedelta(days=7)
        elif rtype == 'monthly':
            # 生成窗口内每月的 key（YYYY-MM），排除当前月
            # 额外过滤：早于 system_start_date 的月份跳过
            y, m = cutoff.year, cutoff.month
            while True:
                if y > today.year or (y == today.year and m >= today.month):
                    break
                mkey = f"{y}-{m:02d}"
                mdate = date(y, m, 1)
                # system_start_date 过滤（早于系统启动时间的月份跳过）
                if mdate >= system_start:
                    expected_keys.append((mkey, mdate))
                m += 1
                if m > 12:
                    m = 1
                    y += 1

        for ekey, edate in expected_keys:
            sk = _state_key(rtype, ekey)
            if sk in existing_done:
                continue  # 已完成，不列入 backlog
            entry = state.get(sk)
            if entry and entry.get('done'):
                continue
            # 没有记录，或有记录但未完成 → 列为 backlog
            days_ago = (today - edate).days
            results.append({
                'type': rtype,
                'key': ekey,
                'days_ago': days_ago,
                'recommend': 'quick' if days_ago >= 3 else 'full',
            })

    # 按时间顺序排列（oldest first）
    results.sort(key=lambda x: x['key'])
    return results


def mp_check(key: str) -> int:
    """
    检查晨间规划当前步骤。
    返回：当前步骤编号（0=尚未开始，1-5=步骤编号，-1=已完成）
    输出结构化文本供 Agent 读取。
    同时扫描 backlog（漏记的周/月复盘），附加在输出末尾。
    """
    state = _load_state(key)
    sk = _state_key('morning_plan', key)
    entry = state.get(sk)

    if not entry:
        print(f"STATE: not_started")
        print(f"TYPE: morning_plan")
        print(f"KEY: {key}")
        print(f"ACTION: 调用 `review_state.py advance --type morning_plan --key {key} --to previewed` 开始晨间规划")
        _print_backlog(key)
        _check_upgrade()
        return 0

    if entry.get('done'):
        print(f"STATE: done")
        print(f"TYPE: morning_plan")
        print(f"KEY: {key}")
        print(f"COMPLETED_AT: {entry.get('completed_at', '?')}")
        print(f"ACTION: 今日晨间规划已完成，无需重复执行")
        return -1

    current_step = entry.get('step', 1)
    step_name = MORNING_STEP_NAMES.get(current_step, '?')
    step_desc = MORNING_STEP_DESC.get(current_step, '')
    next_hint = MORNING_NEXT_HINT.get(current_step, '')

    print(f"STATE: in_progress")
    print(f"TYPE: morning_plan")
    print(f"KEY: {key}")
    print(f"CURRENT_STEP: {current_step}")
    print(f"STEP_NAME: {step_name}")
    print(f"STEP_DESC: {step_desc}")
    print(f"")
    print(f"进度：")
    for n in range(1, 5):
        icon = '✅' if n < current_step else ('🔄' if n == current_step else '⏸️')
        print(f"  {icon} step{n} {MORNING_STEP_DESC.get(n, '')}")
    print(f"")
    print(f"ACTION: {next_hint}")
    _print_backlog(key)
    return current_step


def _check_upgrade() -> None:
    """调用 check_update.py，有新版本时输出 UPGRADE 行"""
    try:
        import subprocess
        scripts_dir = Path(__file__).parent
        check_update = scripts_dir / 'check_update.py'
        if check_update.exists():
            result = subprocess.run(
                [sys.executable, str(check_update)],
                capture_output=True, text=True, timeout=4
            )
            if result.stdout.strip():
                print(result.stdout.strip())
    except Exception:
        pass  # 静默失败，不影响主流程


def _print_backlog(exclude_key: str = '') -> None:
    """扫描并打印前置处理信息（四步顺序：普通任务清理→习惯补打卡→漏记复盘）"""
    # 第一步：历史未处理普通任务（排除习惯）
    overdue_groups = _scan_overdue_active()
    if overdue_groups:
        _print_overdue_active(overdue_groups)

    # 第二步：习惯补打卡（≤14天询问，>14天已静默 cancelled）
    habit_groups = _scan_overdue_habits()
    if habit_groups:
        _print_overdue_habits(habit_groups)

    # 第三步：漏记周/月复盘
    backlog = _scan_backlog(exclude_key)
    if backlog:
        print(f"")
        print(f"BACKLOG: {len(backlog)}")
        for item in backlog:
            rec = '（建议快速版）' if item['recommend'] == 'quick' else '（可做完整版）'
            print(f"  BACKLOG_ITEM: type={item['type']} key={item['key']} days_ago={item['days_ago']} {rec}")
        print(f"")
        print(f"ROCKY: 💬 Rocky：漏掉了，bad bad bad。人类脑子，没用玩意儿，陈述句。")


def _scan_overdue_active(window_days: int = 14) -> list:
    """
    扫描 schedule_date < today AND status = active 的普通任务（排除习惯任务）。
    按日期分组返回，窗口默认 14 天。
    返回：[{"date": "2026-04-12", "tasks": [{"id": "T-xxx", "title": "...", "area": "work"}, ...]}, ...]
    """
    import sqlite3
    from datetime import date, timedelta

    today = date.today()
    window_start = (today - timedelta(days=window_days)).isoformat()
    today_str = today.isoformat()

    db_path = _get_db_path()
    if not db_path.exists():
        return []

    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row
        rows = conn.execute("""
            SELECT id, title, area, schedule_date, priority
            FROM tasks
            WHERE is_deleted = 0
              AND status = 'active'
              AND (tags IS NULL OR tags NOT LIKE '%习惯%')
              AND schedule_date IS NOT NULL
              AND schedule_date >= ?
              AND schedule_date < ?
            ORDER BY schedule_date ASC, priority DESC
        """, (window_start, today_str)).fetchall()
        conn.close()
    except Exception:
        return []

    # 按日期分组
    by_date = {}
    for row in rows:
        d = row['schedule_date']
        if d not in by_date:
            by_date[d] = []
        by_date[d].append({
            'id': row['id'],
            'title': row['title'],
            'area': row['area'],
            'priority': row['priority'],
        })

    return [{'date': d, 'tasks': ts} for d, ts in sorted(by_date.items())]


def _scan_overdue_habits(window_days: int = 14) -> list:
    """
    扫描 schedule_date < today AND status = active AND tags LIKE '%习惯%' 的习惯任务。
    窗口内（≤14天）按日期分组返回；超出窗口的直接静默 cancelled（在此函数中执行）。
    返回：[{"date": "2026-04-12", "habits": [{"id": "T-xxx", "title": "..."}, ...]}, ...]
    """
    import sqlite3
    from datetime import date, timedelta

    today = date.today()
    today_str = today.isoformat()
    window_start = (today - timedelta(days=window_days)).isoformat()

    db_path = _get_db_path()
    if not db_path.exists():
        return []

    try:
        conn = sqlite3.connect(str(db_path))
        conn.row_factory = sqlite3.Row

        # 超出窗口的习惯任务静默 cancelled
        conn.execute("""
            UPDATE tasks SET status = 'cancelled'
            WHERE is_deleted = 0
              AND tags LIKE '%习惯%'
              AND status = 'active'
              AND schedule_date IS NOT NULL
              AND schedule_date < ?
        """, (window_start,))
        conn.commit()

        # 窗口内的习惯任务返回给用户确认
        rows = conn.execute("""
            SELECT id, title, schedule_date
            FROM tasks
            WHERE is_deleted = 0
              AND tags LIKE '%习惯%'
              AND status = 'active'
              AND schedule_date IS NOT NULL
              AND schedule_date >= ?
              AND schedule_date < ?
            ORDER BY schedule_date ASC
        """, (window_start, today_str)).fetchall()
        conn.close()
    except Exception:
        return []

    by_date = {}
    for row in rows:
        d = row['schedule_date']
        if d not in by_date:
            by_date[d] = []
        by_date[d].append({'id': row['id'], 'title': row['title']})

    return [{'date': d, 'habits': hs} for d, hs in sorted(by_date.items())]


def _print_overdue_habits(groups: list) -> None:
    """打印习惯补打卡提示"""
    if not groups:
        return
    total_days = len(groups)
    print(f"")
    print(f"OVERDUE_HABITS: {total_days}")
    for g in groups:
        habit_names = ' · '.join(h['title'] for h in g['habits'])
        print(f"  HABIT_DATE: {g['date']} count={len(g['habits'])}")
        for h in g['habits']:
            print(f"    HABIT_TASK: id={h['id']} title={h['title']}")


def _print_overdue_active(groups: list) -> None:
    """打印历史未处理普通任务清单"""
    if not groups:
        return
    total = sum(len(g['tasks']) for g in groups)
    print(f"")
    print(f"OVERDUE_ACTIVE: {total}")
    for g in groups:
        print(f"  OVERDUE_DATE: {g['date']} count={len(g['tasks'])}")
        for t in g['tasks']:
            print(f"    OVERDUE_TASK: id={t['id']} title={t['title']}")


def mp_advance(key: str, to_step_name: str) -> None:
    """
    推进晨间规划到指定步骤（只能向前，不能跳步）。
    to_step_name: previewed / user_confirmed / db_written
    """
    if to_step_name not in MORNING_STEPS:
        print(f"❌ 无效步骤名：{to_step_name}，合法值：{list(MORNING_STEPS.keys())}", file=sys.stderr)
        sys.exit(1)

    target_step = MORNING_STEPS[to_step_name]

    state = _load_state(key)
    sk = _state_key('morning_plan', key)
    entry = state.get(sk, {})

    if entry.get('done'):
        print(f"✅ 今日晨间规划（{key}）已完成，无需重复推进。")
        sys.exit(0)

    current_step = entry.get('step', 0)

    if target_step <= current_step:
        print(f"⚠️  当前已处于 step{current_step}（{MORNING_STEP_NAMES.get(current_step,'?')}），"
              f"不能后退到 step{target_step}（{to_step_name}）", file=sys.stderr)
        sys.exit(1)

    if target_step > current_step + 1:
        print(f"⚠️  不能跨步推进：当前 step{current_step}，目标 step{target_step}，"
              f"必须逐步推进（下一步应为 step{current_step + 1}：{MORNING_STEP_NAMES.get(current_step + 1, '?')}）", file=sys.stderr)
        sys.exit(1)

    # 写入新步骤
    if not entry:
        entry = {
            'type': 'morning_plan',
            'key': key,
            'done': False,
            'started_at': _now(),
        }
    entry['step'] = target_step
    entry[f'step{target_step}_at'] = _now()
    state[sk] = entry
    _save_state(state, key)

    desc = MORNING_STEP_DESC.get(target_step, '')
    next_hint = MORNING_NEXT_HINT.get(target_step, '')
    print(f"✅ 晨间规划（{key}）推进到 step{target_step}：{to_step_name}")
    print(f"   {desc}")
    print(f"   下一步：{next_hint}")


def mp_assert_step(key: str, min_step: int) -> None:
    """
    断言晨间规划当前步骤 >= min_step。
    用于外部卡口检查（如 write_daily.py 调用前）。
    失败则输出错误信息并 exit(1)。
    """
    state = _load_state(key)
    sk = _state_key('morning_plan', key)
    entry = state.get(sk)

    if not entry:
        print(f"❌ [卡口拦截] 晨间规划（{key}）尚未开始", file=sys.stderr)
        print(f"   write_daily morning-plan 写入前，必须完成 step{min_step}（{MORNING_STEP_NAMES.get(min_step, '?')}）", file=sys.stderr)
        print(f"   请按顺序执行晨间规划流程", file=sys.stderr)
        sys.exit(1)

    if entry.get('done'):
        # 已完成的自然满足所有条件
        print(f"ASSERT_PASS: step >= {min_step} (already done)")
        sys.exit(0)

    current_step = entry.get('step', 0)
    if current_step >= min_step:
        step_name = MORNING_STEP_NAMES.get(current_step, '?')
        print(f"ASSERT_PASS: current_step={current_step}({step_name}) >= min={min_step}")
        sys.exit(0)
    else:
        min_name = MORNING_STEP_NAMES.get(min_step, '?')
        cur_name = MORNING_STEP_NAMES.get(current_step, 'not_started')
        print(f"❌ [卡口拦截] 晨间规划步骤不足", file=sys.stderr)
        print(f"   要求：step >= {min_step}（{min_name}）", file=sys.stderr)
        print(f"   当前：step = {current_step}（{cur_name}）", file=sys.stderr)
        print(f"", file=sys.stderr)
        required_actions = []
        for s in range(current_step + 1, min_step + 1):
            required_actions.append(f"  step{s}：{MORNING_STEP_DESC.get(s, '')} → advance --to {MORNING_STEP_NAMES.get(s, '?')}")
        if required_actions:
            print(f"   需要先完成：", file=sys.stderr)
            for a in required_actions:
                print(a, file=sys.stderr)
        sys.exit(1)


def mp_done(key: str) -> None:
    """标记晨间规划完成（强制验证 step >= 3 即已 db_written）。"""
    state = _load_state(key)
    sk = _state_key('morning_plan', key)
    entry = state.get(sk)

    if not entry:
        print(f"❌ 晨间规划（{key}）尚未开始", file=sys.stderr)
        sys.exit(1)

    if entry.get('done'):
        print(f"✅ 晨间规划（{key}）已完成，无需重复调用。")
        sys.exit(0)

    current_step = entry.get('step', 0)

    # 强制检查：必须已完成 db_written（step >= 3）
    if current_step < 3:
        missing = []
        for s in range(current_step + 1, 4):
            missing.append(f"  step{s}：{MORNING_STEP_DESC.get(s, '')}")
        print(f"❌ [卡口拦截] 不能标记完成：尚有步骤未完成", file=sys.stderr)
        print(f"   当前 step = {current_step}（{MORNING_STEP_NAMES.get(current_step, 'not_started')}）", file=sys.stderr)
        print(f"   未完成步骤：", file=sys.stderr)
        for m in missing:
            print(m, file=sys.stderr)
        sys.exit(1)

    entry['step'] = 4
    entry['done'] = True
    entry['completed_at'] = _now()
    state[sk] = entry
    _save_state(state, key)

    print(f"✅ 晨间规划（{key}）全部完成！")
    print(f"   step1 预览 ✅ · step2 用户确认 ✅ · step3 DB写入 ✅")


# ══════════════════════════════════════════════════════════════════════════════
# 复盘状态机（保持 v2.0 原有逻辑不变）
# ══════════════════════════════════════════════════════════════════════════════

def cmd_start(review_type: str, key: str) -> None:
    state = _load_state(key)
    sk = _state_key(review_type, key)
    existing = state.get(sk)
    rounds = ROUNDS[review_type]
    hints = ROUND_STOP_HINT[review_type]
    type_display = TYPE_DISPLAY.get(review_type, review_type)

    if existing and existing.get('round', 0) > 0 and not existing.get('done', False):
        started_date = existing.get('started_at', '')[:10]  # YYYY-MM-DD
        today = datetime.now().strftime('%Y-%m-%d')
        if started_date and started_date != today:
            # 跨日遗留状态：备份旧状态 + WARN + 重置，不阻断流程
            stale_key = f'{sk}_stale_{started_date}'
            state[stale_key] = existing
            print(f"[WARN] 检测到跨日遗留状态（{type_display} {key}，上次启动：{started_date}）")
            print(f"   旧状态已备份至 key: {stale_key}，本次重新开始")
            # 继续执行，覆盖写入新状态
        else:
            # 同天：正常阻止重复启动
            current_round = existing['round']
            print(f"⚠️  {type_display}（{key}）已在进行中（当前：{rounds.get(current_round, '?')}）")
            print(f"   请用 `review_state.py check --type {review_type} --key {key}` 查看状态")
            print(f"   如需强制重置，请手动删除 {_get_state_file(key)}")
            sys.exit(1)

    state[sk] = {
        'type': review_type,
        'key': key,
        'round': 1,
        'done': False,
        'started_at': _now(),
        'round1_done': False,
        'round2_done': False,
        'round3_done': False,
    }
    _save_state(state, key)

    print(f"✅ 开始 {type_display}（{key}）")
    print(f"📍 当前轮次：{rounds[1]}")
    print(f"🛑 停等点：{hints[1]}")


def cmd_next(review_type: str, key: str) -> None:
    state = _load_state(key)
    sk = _state_key(review_type, key)
    entry = state.get(sk)
    rounds = ROUNDS[review_type]
    hints = ROUND_STOP_HINT[review_type]
    type_display = TYPE_DISPLAY.get(review_type, review_type)

    if not entry:
        print(f"❌ {type_display}（{key}）尚未开始，请先执行 start", file=sys.stderr)
        sys.exit(1)

    if entry.get('done'):
        print(f"✅ {type_display}（{key}）已完成，无需继续。")
        sys.exit(0)

    current_round = entry.get('round', 1)

    # round1 → round2：强制检查 round1_presented 卡口
    if current_round == 1:
        if not entry.get('round1_presented'):
            print(f"❌ [卡口拦截] 第一轮尚未展示给用户！", file=sys.stderr)
            print(f"   展示后调用: review_state.py present-round1 --type {review_type} --key {key}", file=sys.stderr)
            sys.exit(1)

    # v3.0.3: 2 轮制，round2 是最后一轮
    if current_round >= 2:
        print(f"⚠️  已是最后一轮（第二轮），请用 `done` 标记完成。", file=sys.stderr)
        sys.exit(1)

    next_round = current_round + 1

    entry[f'round{current_round}_done'] = True
    entry['round'] = next_round
    entry[f'round{next_round}_started_at'] = _now()
    state[sk] = entry
    _save_state(state, key)

    print(f"✅ {rounds[current_round]} 完成")
    print(f"📍 当前轮次：{rounds[next_round]}")
    print(f"🛑 停等点：{hints[next_round]}")


def cmd_check(review_type: str, key: str) -> int:
    state = _load_state(key)
    sk = _state_key(review_type, key)
    entry = state.get(sk)
    rounds = ROUNDS[review_type]
    hints = ROUND_STOP_HINT[review_type]
    type_display = TYPE_DISPLAY.get(review_type, review_type)

    if not entry:
        print(f"STATE: not_started")
        print(f"TYPE: {review_type}")
        print(f"KEY: {key}")
        print(f"ACTION: 请执行 `review_state.py start --type {review_type} --key {key}` 开始{type_display}")
        return 1

    if entry.get('done'):
        print(f"STATE: done")
        print(f"TYPE: {review_type}")
        print(f"KEY: {key}")
        print(f"COMPLETED_AT: {entry.get('completed_at', '?')}")
        print(f"ACTION: {type_display}（{key}）已完成，无需重复执行")
        return 2

    current_round = entry.get('round', 1)
    r1 = '✅' if entry.get('round1_done') else ('🔄' if current_round == 1 else '⏭️')
    r2 = '✅' if entry.get('round2_done') else ('🔄' if current_round == 2 else ('⏭️' if current_round > 2 else '⏸️'))
    r3 = '✅' if entry.get('round3_done') else ('🔄' if current_round == 3 else '⏸️')

    print(f"STATE: in_progress")
    print(f"TYPE: {review_type}")
    print(f"KEY: {key}")
    print(f"CURRENT_ROUND: {current_round}")
    print(f"ROUND_NAME: {rounds.get(current_round, '?')}")
    print(f"STOP_HINT: {hints.get(current_round, '')}")
    print(f"")
    print(f"进度：")
    print(f"  {r1} {rounds[1]}")
    print(f"  {r2} {rounds[2]}")
    print(f"  {r3} {rounds[3]}")
    print(f"")
    print(f"ACTION: 执行{rounds[current_round]}，完成后调用 `review_state.py next --type {review_type} --key {key}`")
    return 0


def cmd_present_round1(review_type: str, key: str) -> None:
    """
    Fix D：标记第一轮已展示给用户（round1_presented）。
    调用时机：build_plan.py --mode midday --render 渲染 + cat 展示给用户后。
    解锁 next 从 round1 推进到 round2。
    """
    state = _load_state(key)
    sk = _state_key(review_type, key)
    entry = state.get(sk)
    type_display = TYPE_DISPLAY.get(review_type, review_type)

    if not entry:
        print(f"❌ {type_display}（{key}）尚未开始", file=sys.stderr)
        sys.exit(1)

    if entry.get('done'):
        print(f"✅ {type_display}（{key}）已完成。")
        sys.exit(0)

    if entry.get('round1_presented'):
        print(f"✅ 第一轮已标记为展示，可直接调用 next 推进。")
        sys.exit(0)

    entry['round1_presented'] = True
    entry['round1_presented_at'] = _now()
    state[sk] = entry
    _save_state(state, key)
    print(f"✅ 第一轮已展示确认（{key}）")
    print(f"   现在可调用: review_state.py next --type {review_type} --key {key}")


def cmd_quick_start(review_type: str, key: str) -> None:
    """
    快速版复盘：开始（标记为 quick_started）。
    调用时机：展示草稿给用户时。
    独立两步流转，不复用正常复盘状态机。
    """
    if review_type not in REVIEW_TYPES:
        print(f"❌ quick-start 仅支持复盘类型：{REVIEW_TYPES}", file=sys.stderr)
        sys.exit(1)

    state = _load_state(key)
    sk = _state_key(review_type, key)
    entry = state.get(sk)
    type_display = TYPE_DISPLAY.get(review_type, review_type)

    if entry and entry.get('done'):
        print(f"✅ {type_display}（{key}）已完成，无需重复执行。")
        sys.exit(0)

    state[sk] = {
        'type': review_type,
        'key': key,
        'done': False,
        'quick_mode': True,
        'quick_started': True,
        'started_at': _now(),
    }
    _save_state(state, key)
    print(f"✅ 快速版 {type_display}（{key}）已开始，草稿展示中")
    print(f"   用户确认后调用: review_state.py quick-done --type {review_type} --key {key}")


def cmd_quick_done(review_type: str, key: str) -> None:
    """
    快速版复盘：完成（用户确认草稿并写入后调用）。
    标记为 done，后续 backlog 扫描不再弹出此 key。
    """
    if review_type not in REVIEW_TYPES:
        print(f"❌ quick-done 仅支持复盘类型：{REVIEW_TYPES}", file=sys.stderr)
        sys.exit(1)

    state = _load_state(key)
    sk = _state_key(review_type, key)
    entry = state.get(sk)
    type_display = TYPE_DISPLAY.get(review_type, review_type)

    if not entry:
        print(f"❌ {type_display}（{key}）未找到记录，请先调用 quick-start", file=sys.stderr)
        sys.exit(1)

    if entry.get('done'):
        print(f"✅ {type_display}（{key}）已完成，无需重复调用。")
        sys.exit(0)

    entry['done'] = True
    entry['completed_at'] = _now()
    state[sk] = entry
    _save_state(state, key)

    print(f"✅ 快速版 {type_display}（{key}）完成！报告已写入。")


def cmd_done(review_type: str, key: str) -> None:
    """
    通用 done：
      - morning_plan → 调用 mp_done
      - 复盘类型    → 检查 round2_done 卡口
    """
    if review_type == 'morning_plan':
        mp_done(key)
        return

    state = _load_state(key)
    sk = _state_key(review_type, key)
    entry = state.get(sk)
    rounds = ROUNDS[review_type]
    type_display = TYPE_DISPLAY.get(review_type, review_type)

    if not entry:
        print(f"❌ {type_display}（{key}）尚未开始", file=sys.stderr)
        sys.exit(1)

    if entry.get('done'):
        print(f"✅ {type_display}（{key}）已完成，无需重复调用。")
        sys.exit(0)

    if not entry.get('round2_done'):
        current_round = entry.get('round', 1)
        # v3.0.3: round2 时直接允许 done（自动标记 round2_done）
        if current_round == 2:
            entry['round2_done'] = True
        else:
            print(f"⚠️  {rounds[2]} 尚未完成，不能直接标记完成！", file=sys.stderr)
            print(f"   当前轮次：{rounds.get(current_round, '?')}", file=sys.stderr)
            sys.exit(1)

    entry['done'] = True
    entry['completed_at'] = _now()
    state[sk] = entry
    _save_state(state, key)

    print(f"✅ {type_display}（{key}）全部完成！")
    print(f"   {rounds[1]} ✅ · {rounds[2]} ✅")


def cmd_status() -> None:
    state = _load_state()  # 查生产文件，无 key
    if not state:
        print("（无流程记录）")
        return

    sorted_keys = sorted(state.keys(), reverse=True)[:15]
    print(f"{'类型':<10} {'期号':<16} {'状态':<10} {'当前进度':<28} {'时间'}")
    print('─' * 80)
    for sk in sorted_keys:
        entry = state[sk]
        review_type = entry.get('type', sk.split(':')[0] if ':' in sk else '?')
        key = entry.get('key', sk.split(':')[1] if ':' in sk else sk)
        type_display = TYPE_DISPLAY.get(review_type, review_type)

        if review_type == 'morning_plan':
            if entry.get('done'):
                status_str = '✅ 已完成'
                progress_str = 'step4 全部完成'
                time_str = entry.get('completed_at', '')
            else:
                current_step = entry.get('step', 0)
                status_str = '🔄 进行中'
                progress_str = f"step{current_step} {MORNING_STEP_NAMES.get(current_step, '?')}"
                time_str = entry.get(f'step{current_step}_at', entry.get('started_at', ''))
        else:
            rounds = ROUNDS.get(review_type, {})
            if entry.get('done'):
                status_str = '✅ 已完成'
                progress_str = '全部完成'
                time_str = entry.get('completed_at', '')
            else:
                current_round = entry.get('round', 1)
                status_str = '🔄 进行中'
                progress_str = rounds.get(current_round, '?')
                time_str = entry.get(f'round{current_round}_started_at', entry.get('started_at', ''))

        print(f"{type_display:<10} {key:<16} {status_str:<10} {progress_str:<28} {time_str}")


# ── CLI 入口 ──────────────────────────────────────────────────────────────────

def _add_type_key_args(p: argparse.ArgumentParser, choices=None) -> None:
    p.add_argument(
        '--type', dest='review_type', required=True,
        choices=choices or list(ALL_TYPES),
        help='流程类型：morning_plan / daily / weekly / monthly',
    )
    p.add_argument('--key', required=True, help='期号（morning_plan=YYYY-MM-DD，daily=YYYY-MM-DD 等）')


def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro 流程状态追踪 v3.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    sub = parser.add_subparsers(dest='cmd', required=True)

    # ── morning_plan 专用子命令 ──
    p_advance = sub.add_parser('advance', help='晨间规划：推进到指定步骤')
    _add_type_key_args(p_advance, choices=['morning_plan'])
    p_advance.add_argument('--to', required=True, dest='to_step',
                           choices=list(MORNING_STEPS.keys()),
                           help='目标步骤名：previewed/user_confirmed/db_written')

    p_assert = sub.add_parser('assert-step', help='晨间规划：卡口断言（step >= min）')
    _add_type_key_args(p_assert, choices=['morning_plan'])
    p_assert.add_argument('--min', required=True, type=int, dest='min_step',
                          help='最小步骤编号（1-3）')

    # ── 通用子命令（morning_plan + 复盘共用 check / done） ──
    p_check = sub.add_parser('check', help='查看当前状态（晨间规划和复盘通用）')
    _add_type_key_args(p_check)

    p_done = sub.add_parser('done', help='标记完成（晨间规划和复盘通用）')
    _add_type_key_args(p_done)

    # ── 复盘专用子命令 ──
    p_start = sub.add_parser('start', help='复盘：开始（进入第一轮）')
    _add_type_key_args(p_start, choices=list(REVIEW_TYPES))

    p_next = sub.add_parser('next', help='复盘：完成当前轮次，进入下一轮')
    _add_type_key_args(p_next, choices=list(REVIEW_TYPES))

    p_present = sub.add_parser('present-round1', help='复盘：标记第一轮已展示给用户（解锁 next 到第二轮）')
    _add_type_key_args(p_present, choices=list(REVIEW_TYPES))

    sub.add_parser('status', help='查看所有最近流程状态（无需 --type/--key）')

    # ── 漏记扫描（主动触发）──
    sub.add_parser('scan-backlog', help='主动扫描漏记的周/月复盘（无需 --type/--key）')

    # ── 快速版复盘专用子命令 ──
    p_qs = sub.add_parser('quick-start', help='快速版复盘：开始（展示草稿时调用）')
    _add_type_key_args(p_qs, choices=list(REVIEW_TYPES))

    p_qd = sub.add_parser('quick-done', help='快速版复盘：完成（用户确认写入后调用）')
    _add_type_key_args(p_qd, choices=list(REVIEW_TYPES))

    args = parser.parse_args()

    if args.cmd == 'advance':
        mp_advance(args.key, args.to_step)
    elif args.cmd == 'assert-step':
        mp_assert_step(args.key, args.min_step)
    elif args.cmd == 'check':
        if args.review_type == 'morning_plan':
            sys.exit(mp_check(args.key))
        else:
            sys.exit(cmd_check(args.review_type, args.key))
    elif args.cmd == 'done':
        cmd_done(args.review_type, args.key)
    elif args.cmd == 'start':
        cmd_start(args.review_type, args.key)
    elif args.cmd == 'next':
        cmd_next(args.review_type, args.key)
    elif args.cmd == 'present-round1':
        cmd_present_round1(args.review_type, args.key)
    elif args.cmd == 'status':
        cmd_status()
    elif args.cmd == 'scan-backlog':
        backlog = _scan_backlog()
        if not backlog:
            print("✅ 没有漏记的复盘记录")
        else:
            print(f"检测到 {len(backlog)} 条漏记：")
            for item in backlog:
                rec = '建议快速版' if item['recommend'] == 'quick' else '可做完整版'
                print(f"  · {item['key']}（{TYPE_DISPLAY.get(item['type'], item['type'])}）"
                      f" 已过 {item['days_ago']} 天，{rec}")
    elif args.cmd == 'quick-start':
        cmd_quick_start(args.review_type, args.key)
    elif args.cmd == 'quick-done':
        cmd_quick_done(args.review_type, args.key)


# ── 内嵌自测 ──────────────────────────────────────────────────────────────────

def _self_test() -> None:
    import tempfile
    global STATE_FILE

    with tempfile.TemporaryDirectory() as tmpdir:
        STATE_FILE = Path(tmpdir) / 'review_state.json'
        print('【review_state.py v3.0 自测】')

        # ══════════════════════════════════════════════
        # 1. morning_plan 正常完整流程
        # ══════════════════════════════════════════════
        print('\n=== 1. morning_plan 完整流程 ===')
        date = '2026-04-07'

        ret = mp_check(date)
        assert ret == 0, f"未开始应返回 0，实际 {ret}"

        mp_advance(date, 'previewed')
        s = _load_state(); assert s[f'morning_plan:{date}']['step'] == 1
        print("  ✅ step1 previewed")

        mp_advance(date, 'user_confirmed')
        s = _load_state(); assert s[f'morning_plan:{date}']['step'] == 2
        print("  ✅ step2 user_confirmed")

        # assert-step: step >= 2 应通过（exit(0) 也算通过）
        try:
            mp_assert_step(date, 2)
        except SystemExit as e:
            assert e.code == 0, f"assert-step --min 2 不应失败，实际 exit({e.code})"
        print("  ✅ assert-step --min 2 通过")

        mp_advance(date, 'db_written')
        s = _load_state(); assert s[f'morning_plan:{date}']['step'] == 3
        print("  ✅ step3 db_written")

        mp_done(date)
        s = _load_state(); assert s[f'morning_plan:{date}']['done']
        assert s[f'morning_plan:{date}']['step'] == 4
        print("  ✅ done 成功")

        ret = mp_check(date)
        assert ret == -1, f"完成后应返回 -1，实际 {ret}"
        print("  ✅ morning_plan 完整流程全通过")

        # ══════════════════════════════════════════════
        # 2. morning_plan 跳步保护：assert-step 卡口
        # ══════════════════════════════════════════════
        print('\n=== 2. morning_plan 跳步保护 ===')
        date2 = '2026-04-08'

        # 未开始时 assert-step 应失败
        try:
            mp_assert_step(date2, 2)
            assert False, "未开始时 assert-step 应拒绝"
        except SystemExit as e:
            assert e.code == 1
            print("  ✅ 未开始时 assert-step --min 2 正确拒绝")

        # 只完成 step1，assert-step --min 2 应失败
        mp_advance(date2, 'previewed')
        try:
            mp_assert_step(date2, 2)
            assert False, "step1 时 assert-step --min 2 应拒绝"
        except SystemExit as e:
            assert e.code == 1
            print("  ✅ step1 时 assert-step --min 2 正确拒绝")

        # 跨步推进应失败
        try:
            mp_advance(date2, 'db_written')  # 跳过 user_confirmed
            assert False, "跨步推进应失败"
        except SystemExit as e:
            assert e.code == 1
            print("  ✅ 跨步推进正确拒绝")

        # done 前 step < 4 应失败
        mp_advance(date2, 'user_confirmed')
        try:
            mp_done(date2)
            assert False, "step2 时 done 应拒绝"
        except SystemExit as e:
            assert e.code == 1
            print("  ✅ step2 时 done 正确拒绝（DN 未写入）")

        print("  ✅ morning_plan 跳步保护全通过")

        # ══════════════════════════════════════════════
        # 3. 复盘完整流程（daily，含新 reflect 步骤）
        # ══════════════════════════════════════════════
        print('\n=== 3. daily 复盘完整流程（含 reflect）===')
        rdate = '2026-04-06'

        ret = cmd_check('daily', rdate)
        assert ret == 1

        cmd_start('daily', rdate)
        cmd_next('daily', rdate)   # round1 → round2
        cmd_next('daily', rdate)   # round2 → reflection_prompted（停等感悟）
        s = _load_state()
        assert s[f'daily:{rdate}'].get('reflection_prompted'), "应已进入 reflection_prompted"
        assert not s[f'daily:{rdate}'].get('reflection_confirmed'), "尚未确认感悟"
        print("  ✅ next×2 后进入 reflection_prompted")

        # done 前未 reflect → 应被拒绝
        try:
            cmd_done('daily', rdate)
            assert False, "未 reflect 时 done 应拒绝"
        except SystemExit as e:
            assert e.code == 1
            print("  ✅ 未 reflect 时 done 正确拒绝")

        # reflect --skip（无感悟）
        cmd_reflect('daily', rdate, skip=True)
        s = _load_state()
        assert s[f'daily:{rdate}'].get('reflection_confirmed'), "reflect --skip 后应 confirmed"
        assert s[f'daily:{rdate}']['round'] == 3, "应进入 round3"
        print("  ✅ reflect --skip 成功，进入 round3")

        cmd_done('daily', rdate)
        s = _load_state(); assert s[f'daily:{rdate}']['done']
        print("  ✅ done 成功")
        print("  ✅ daily 复盘完整流程全通过")

        # ══════════════════════════════════════════════
        # 3b. reflect（有感悟）流程
        # ══════════════════════════════════════════════
        print('\n=== 3b. daily 复盘 reflect（有感悟）===')
        rdate_b = '2026-04-03'
        cmd_start('daily', rdate_b)
        cmd_next('daily', rdate_b)
        cmd_next('daily', rdate_b)  # → reflection_prompted
        cmd_reflect('daily', rdate_b, skip=False)  # 有感悟，已写入
        s = _load_state()
        assert s[f'daily:{rdate_b}'].get('reflection_confirmed')
        assert not s[f'daily:{rdate_b}'].get('reflection_skipped')
        print("  ✅ reflect（有感悟）正确标记 confirmed，skipped=False")
        cmd_done('daily', rdate_b)
        print("  ✅ 有感悟完整流程全通过")

        # ══════════════════════════════════════════════
        # 4. 复盘跳轮保护
        # ══════════════════════════════════════════════
        print('\n=== 4. 复盘跳轮保护 ===')
        rdate2 = '2026-04-05'
        cmd_start('daily', rdate2)
        cmd_next('daily', rdate2)  # 到第二轮
        # 手动把 round 设为 3 但 round2_done=False，模拟跳步
        s = _load_state()
        s[f'daily:{rdate2}']['round'] = 3
        _save_state(s)
        try:
            cmd_done('daily', rdate2)
            assert False, "应拒绝跳过第二轮"
        except SystemExit as e:
            assert e.code == 1
            print("  ✅ 跳过第二轮正确拒绝")

        # ══════════════════════════════════════════════
        # 5. status 展示
        # ══════════════════════════════════════════════
        print('\n=== 5. status 展示 ===')
        cmd_status()

        print('\n✅ v3.1 全部自测通过！（morning_plan + daily reflect卡口 + 跳步/跳轮保护）')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        main()
    else:
        _self_test()
