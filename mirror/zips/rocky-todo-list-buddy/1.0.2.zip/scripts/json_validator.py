#!/usr/bin/env python3
"""
json_validator.py - LifeOps Pro JSON 校验 + 重试机制
版本：Phase 1
功能：
  1. 从输入文本中提取 JSON（处理 AI 夹带的前后缀文字）
  2. 用 schemas.py 的 Pydantic 模型校验结构
  3. 校验失败时输出具体错误信息（供 AI 重试时参考）

用法：
  # 校验 AI 输出（DailyPlan 结构）
  echo '{"date":"2026-04-03", "projects": [...]}' | python3 json_validator.py --schema DailyPlan

  # 从文件校验
  python3 json_validator.py --input /tmp/plan.json --schema DailyPlan

  # 列出所有可用 schema
  python3 json_validator.py --list-schemas

退出码：
  0 = 校验通过
  1 = 校验失败（Pydantic 错误）
  2 = JSON 解析失败（格式错误）
  3 = 未知 schema 名称
  4 = 输入为空
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import os
from typing import Dict, Any, Optional, List, Tuple, Type

# ============================================================
# 加载 schemas.py（支持直接运行和脚本目录引用两种方式）
# ============================================================

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if _SCRIPT_DIR not in sys.path:
    sys.path.insert(0, _SCRIPT_DIR)

try:
    from schemas import (
        Task, ProjectGroup, Habit, DDLWarning, DailyPlan, ReviewData
    )
    import pydantic
    PYDANTIC_V2 = int(pydantic.VERSION.split('.')[0]) >= 2
except ImportError as e:
    print(f'❌ 无法加载 schemas.py：{e}', file=sys.stderr)
    print('请确保 schemas.py 在同一目录下，且 pydantic 已安装。', file=sys.stderr)
    sys.exit(3)

# ============================================================
# Schema 注册表
# ============================================================

SCHEMA_MAP: Dict[str, Any] = {
    'Task':         Task,
    'ProjectGroup': ProjectGroup,
    'Habit':        Habit,
    'DDLWarning':   DDLWarning,
    'DailyPlan':    DailyPlan,
    'ReviewData':   ReviewData,
}

# ============================================================
# JSON 提取工具（处理 AI 夹带的前后缀文字）
# ============================================================

def extract_json(text: str) -> Tuple[Optional[str], str]:
    """
    从文本中提取 JSON 块。
    支持：
    - 纯 JSON
    - 带 markdown 代码块（```json ... ``` 或 ``` ... ```）
    - 夹在普通文字中的 JSON
    返回 (json_str, hint) 其中 hint 描述提取方式
    """
    text = text.strip()
    if not text:
        return None, 'empty'

    # 1. 尝试直接解析（最快路径）
    if text.startswith('{') or text.startswith('['):
        try:
            json.loads(text)
            return text, 'direct'
        except json.JSONDecodeError:
            pass

    # 2. 尝试 markdown 代码块
    patterns = [
        r'```json\s*\n([\s\S]*?)\n```',
        r'```\s*\n([\s\S]*?)\n```',
        r'```json\s*([\s\S]*?)```',
        r'```\s*([\s\S]*?)```',
    ]
    for pattern in patterns:
        m = re.search(pattern, text, re.IGNORECASE)
        if m:
            candidate = m.group(1).strip()
            try:
                json.loads(candidate)
                return candidate, f'markdown-code-block'
            except json.JSONDecodeError:
                continue

    # 3. 尝试从文本中找最大 JSON 对象（贪心匹配）
    # 找到第一个 { 或 [ 到最后一个 } 或 ]
    start_idx = -1
    start_char = None
    end_char = None
    for i, ch in enumerate(text):
        if ch in ('{', '['):
            start_idx = i
            start_char = ch
            end_char = '}' if ch == '{' else ']'
            break

    if start_idx >= 0 and end_char:
        # 从末尾找对应结束符
        end_idx = len(text) - 1
        while end_idx >= start_idx:
            if text[end_idx] == end_char:
                candidate = text[start_idx:end_idx + 1]
                try:
                    json.loads(candidate)
                    return candidate, 'extracted-from-text'
                except json.JSONDecodeError:
                    end_idx -= 1
            else:
                end_idx -= 1

    return None, 'not-found'


# ============================================================
# 校验核心逻辑
# ============================================================

def format_pydantic_errors(exc: Exception) -> List[str]:
    """将 Pydantic 验证错误转换为人类可读的错误列表"""
    errors: List[str] = []
    if PYDANTIC_V2:
        # pydantic v2：exc.errors() 返回标准错误列表
        for err in exc.errors():
            loc = ' -> '.join(str(x) for x in err.get('loc', []))
            msg = err.get('msg', '')
            input_val = err.get('input', None)
            url = err.get('url', '')

            # 格式化枚举错误（更友好）
            if 'literal_error' in err.get('type', '') or 'enum' in err.get('type', ''):
                ctx = err.get('ctx', {})
                expected = ctx.get('expected', None)
                if expected:
                    msg = f"值不合法，期望: {expected}，实际收到: {repr(input_val)}"
                else:
                    msg = f"值不合法: {repr(input_val)}"
            elif 'missing' in err.get('type', ''):
                msg = f"必填字段缺失"
            elif input_val is not None:
                msg = f"{msg}（收到: {repr(input_val)}）"

            if loc:
                errors.append(f"  - {loc}: {msg}")
            else:
                errors.append(f"  - {msg}")
    else:
        # pydantic v1
        try:
            for err in exc.errors():
                loc = ' -> '.join(str(x) for x in err.get('loc', []))
                msg = err.get('msg', '')
                errors.append(f"  - {loc}: {msg}" if loc else f"  - {msg}")
        except Exception:
            errors.append(f"  - {str(exc)}")

    return errors


def validate(
    json_str: str,
    schema_name: str,
    verbose: bool = False,
) -> Tuple[bool, str, Optional[Any]]:
    """
    校验 JSON 字符串是否符合指定 schema。
    返回 (success, message, parsed_obj)
    """
    # 获取 schema 类
    schema_cls = SCHEMA_MAP.get(schema_name)
    if schema_cls is None:
        available = ', '.join(sorted(SCHEMA_MAP.keys()))
        return False, f"❌ 未知 schema：{schema_name}（可用：{available}）", None

    # 解析 JSON
    try:
        data = json.loads(json_str)
    except json.JSONDecodeError as e:
        return False, f"❌ JSON 解析失败：{e}", None

    # Pydantic 校验
    try:
        if PYDANTIC_V2:
            obj = schema_cls.model_validate(data)
        else:
            obj = schema_cls(**data)

        if verbose:
            if PYDANTIC_V2:
                pretty = obj.model_dump_json(indent=2)
            else:
                pretty = obj.json(indent=2)
            return True, f"✅ 校验通过\n\n解析结果：\n{pretty}", obj
        else:
            return True, "✅ 校验通过", obj

    except Exception as exc:
        # 判断是否是 pydantic ValidationError
        exc_type = type(exc).__name__
        if 'ValidationError' in exc_type:
            error_lines = format_pydantic_errors(exc)
            msg = "❌ 校验失败：\n" + "\n".join(error_lines)
        else:
            msg = f"❌ 校验异常（{exc_type}）：{exc}"
        return False, msg, None


# ============================================================
# CLI 入口
# ============================================================

def main() -> None:
    parser = argparse.ArgumentParser(
        description='LifeOps Pro JSON 校验工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument('--input', '-i', help='输入 JSON 文件路径（不指定则从 stdin 读取）')
    parser.add_argument(
        '--schema', '-s',
        default='DailyPlan',
        help=f'使用的 schema 名称，默认 DailyPlan（可用：{", ".join(sorted(SCHEMA_MAP.keys()))}）',
    )
    parser.add_argument('--list-schemas', '-l', action='store_true', help='列出所有可用 schema')
    parser.add_argument('--verbose', '-v', action='store_true', help='输出解析结果详情')
    parser.add_argument('--extract-only', action='store_true', help='只提取 JSON，不校验')
    args = parser.parse_args()

    # 列出 schema
    if args.list_schemas:
        print("📋 可用 Schema：")
        for name in sorted(SCHEMA_MAP.keys()):
            cls = SCHEMA_MAP[name]
            print(f"  - {name}")
        return

    # 读取输入
    if args.input:
        try:
            with open(args.input, 'r', encoding='utf-8') as f:
                raw = f.read()
        except FileNotFoundError:
            print(f'❌ 文件不存在：{args.input}', file=sys.stderr)
            sys.exit(1)
    else:
        raw = sys.stdin.read()

    if not raw.strip():
        print('❌ 输入为空', file=sys.stderr)
        sys.exit(4)

    # 提取 JSON
    json_str, hint = extract_json(raw)
    if json_str is None:
        print(f'❌ 无法从输入中提取 JSON（{hint}）', file=sys.stderr)
        print('提示：支持纯 JSON、markdown 代码块、夹在文字中的 JSON', file=sys.stderr)
        sys.exit(2)

    if hint != 'direct' and not args.extract_only:
        print(f'ℹ️  JSON 提取方式：{hint}', file=sys.stderr)

    # 仅提取模式
    if args.extract_only:
        print(json.dumps(json.loads(json_str), ensure_ascii=False, indent=2))
        return

    # 校验
    success, message, obj = validate(json_str, args.schema, verbose=args.verbose)
    print(message)

    if not success:
        # 输出重试提示
        print('\n💡 修复建议：', file=sys.stderr)
        print('  1. 检查枚举值是否正确（priority: urgent/high/normal/waiting，status: inbox/active/done/cancelled/someday）', file=sys.stderr)
        print('  2. 检查必填字段是否完整（id, title, priority, status）', file=sys.stderr)
        print('  3. 日期格式必须为 YYYY-MM-DD', file=sys.stderr)
        sys.exit(1)

    sys.exit(0)


# ============================================================
# 内嵌自测
# ============================================================

def _self_test() -> None:
    """测试校验成功和失败两种场景"""
    print("=" * 60)
    print("【json_validator.py 自测】")
    print("=" * 60)
    print(f"pydantic 版本：{pydantic.VERSION} (v{'2' if PYDANTIC_V2 else '1'})")
    print()

    # --- 测试1：校验通过 ---
    print("── 测试1：DailyPlan 校验通过 ──")
    valid_json = json.dumps({
        "date": "2026-04-03",
        "projects": [
            {
                "name": "P-播客项目",
                "area": "work",
                "tasks": [
                    {
                        "id": "T-20260403-a3f91c",
                        "title": "后台/浮窗播放技术方案确认",
                        "priority": "urgent",
                        "area": "work",
                        "status": "active",
                    }
                ]
            }
        ],
        "habits": [
            {"name": "晨间跑步", "time": "07:30", "status": "done"}
        ],
    })
    success, msg, _ = validate(valid_json, 'DailyPlan')
    print(msg)
    assert success, "测试1 应通过"
    print()

    # --- 测试2：priority 枚举值错误 ---
    print("── 测试2：priority 枚举值错误（most-important 不合法） ──")
    invalid_priority_json = json.dumps({
        "date": "2026-04-03",
        "projects": [
            {
                "name": "P-播客项目",
                "area": "work",
                "tasks": [
                    {
                        "id": "T-20260403-a3f91c",
                        "title": "后台/浮窗播放技术方案确认",
                        "priority": "most-important",   # ❌ 非法值
                        "area": "work",
                        "status": "active",
                    }
                ]
            }
        ],
        "habits": [],
    })
    success, msg, _ = validate(invalid_priority_json, 'DailyPlan')
    print(msg)
    assert not success, "测试2 应失败"
    print()

    # --- 测试3：必填字段缺失 ---
    print("── 测试3：Habit.status 必填字段缺失 ──")
    missing_field_json = json.dumps({
        "date": "2026-04-03",
        "projects": [],
        "habits": [
            {"name": "晨间跑步", "time": "07:30"}  # ❌ 缺少 status
        ],
    })
    success, msg, _ = validate(missing_field_json, 'DailyPlan')
    print(msg)
    assert not success, "测试3 应失败"
    print()

    # --- 测试4：从带前缀文字的 AI 输出中提取 JSON ---
    print("── 测试4：从 AI 混杂输出中提取 JSON ──")
    ai_output = '''
好的，以下是今日计划的 JSON 结构：

```json
{
  "date": "2026-04-03",
  "projects": [],
  "habits": [
    {"name": "冥想", "time": "08:00", "status": "pending"}
  ]
}
```

请确认是否符合您的要求。
'''
    json_str, hint = extract_json(ai_output)
    print(f"提取方式：{hint}")
    assert json_str is not None, "应成功提取 JSON"
    success, msg, _ = validate(json_str, 'DailyPlan')
    print(msg)
    assert success, "测试4 应通过"
    print()

    # --- 测试5：status 包含已废弃的 waiting ---
    print("── 测试5：status='waiting' 已废弃，应校验失败 ──")
    deprecated_status_json = json.dumps({
        "date": "2026-04-03",
        "projects": [
            {
                "name": "日常",
                "area": "work",
                "tasks": [
                    {
                        "id": "T-001",
                        "title": "等待对方确认",
                        "priority": "waiting",
                        "area": "work",
                        "status": "waiting",   # ❌ 已废弃（v2.4.0）
                    }
                ]
            }
        ],
        "habits": [],
    })
    success, msg, _ = validate(deprecated_status_json, 'DailyPlan')
    print(msg)
    assert not success, "测试5 应失败（status='waiting' 已废弃）"
    print()

    # --- 测试6：ReviewData 校验通过 ---
    print("── 测试6：ReviewData 校验通过 ──")
    review_json = json.dumps({
        "date": "2026-04-03",
        "projects": [],
        "habits": [],
        "work_planned": 3,
        "work_done": 2,
        "life_planned": 1,
        "life_done": 1,
        "unplanned_done": 0,
        "reflection": "今日收获颇丰。",
    })
    success, msg, _ = validate(review_json, 'ReviewData')
    print(msg)
    assert success, "测试6 应通过"
    print()

    print("=" * 60)
    print("✅ 所有自测通过！")
    print("=" * 60)


if __name__ == '__main__':
    if len(sys.argv) > 1:
        main()
    else:
        _self_test()
