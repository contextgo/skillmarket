#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
check_update.py - Rocky Todo List Buddy 版本检测

功能：
  - 检查 SkillHub 上是否有新版本（每 24 小时最多检查一次）
  - 有新版本时输出 UPGRADE 行，供 Agent 透传给用户
  - 网络失败时静默退出，不影响主流程

用法：
  python check_update.py           # 正常检查（受 24h TTL 限制）
  python check_update.py --force   # 强制检查，忽略 TTL 缓存

输出格式（有新版本时）：
  UPGRADE: ⚠️ 有新版本 v{remote}（当前 v{local}），说「更新 Rocky」一键升级

触发词集成：
  Agent 在展示 check 输出时，如发现 UPGRADE: 行，原样贴出给用户。
"""

import sys
import json
import time
import argparse
import urllib.request
from pathlib import Path
from typing import Optional

# ── 配置 ────────────────────────────────────────────────────────
SKILL_DIR    = Path(__file__).resolve().parent.parent  # 自发现
CACHE_FILE   = Path.home() / '.rocky-todo-list-buddy/update_check_cache.json'
CONFIG_FILE  = SKILL_DIR / 'config.json'
TTL_SECONDS  = 86400  # 24 小时

# SkillHub API（已验证可用）
# 方式一：详情接口 → latestVersion.version
REMOTE_API_URL = 'https://api.skillhub.cn/api/v1/skills/rocky-todo-list-buddy'
# 方式二：文件 raw 接口 → config.json 重定向到 COS
REMOTE_FILE_URL = 'https://api.skillhub.cn/api/v1/skills/rocky-todo-list-buddy/file?path=config.json'

REQUEST_TIMEOUT = 3  # 秒


def get_local_version() -> str:
    try:
        config = json.loads(CONFIG_FILE.read_text(encoding='utf-8'))
        return config.get('version', '0.0.0')
    except Exception:
        return '0.0.0'


def load_cache() -> dict:
    try:
        if CACHE_FILE.exists():
            return json.loads(CACHE_FILE.read_text(encoding='utf-8'))
    except Exception:
        pass
    return {}


def save_cache(remote_version: str):
    try:
        CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        cache = {
            'checked_at': time.time(),
            'remote_version': remote_version
        }
        CACHE_FILE.write_text(json.dumps(cache), encoding='utf-8')
    except Exception:
        pass


def should_check(force: bool) -> bool:
    if force:
        return True
    cache = load_cache()
    last_check = cache.get('checked_at', 0)
    return (time.time() - last_check) >= TTL_SECONDS


def fetch_remote_version() -> Optional[str]:
    """尝试从 SkillHub 获取远端版本号，优先用详情 API，fallback 到文件接口"""
    # 方式一：详情 API（latestVersion.version）
    try:
        req = urllib.request.Request(REMOTE_API_URL, headers={'User-Agent': 'rocky-todo-updater'})
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            ver = data.get('latestVersion', {}).get('version', '')
            if ver:
                return ver
    except Exception:
        pass

    # 方式二：文件接口（重定向到 COS，读 config.json 的 version）
    try:
        req = urllib.request.Request(REMOTE_FILE_URL, headers={'User-Agent': 'rocky-todo-updater'})
        with urllib.request.urlopen(req, timeout=REQUEST_TIMEOUT) as resp:
            data = json.loads(resp.read().decode('utf-8'))
            ver = data.get('version', '')
            if ver:
                return ver
    except Exception:
        pass

    return None


def version_tuple(v: str) -> tuple:
    """把 '2.12.0' 转为 (2, 12, 0) 方便比较"""
    try:
        return tuple(int(x) for x in v.strip('v').split('.'))
    except Exception:
        return (0, 0, 0)


def main():
    parser = argparse.ArgumentParser(description='Rocky 版本检测')
    parser.add_argument('--force', '-f', action='store_true', help='强制检查，忽略 24h TTL 缓存')
    args = parser.parse_args()

    if not should_check(args.force):
        sys.exit(0)  # TTL 未到，静默退出

    remote_version = fetch_remote_version()

    if remote_version is None:
        sys.exit(0)  # 网络失败，静默退出

    # 写入缓存（无论有没有新版本）
    save_cache(remote_version)

    local_version = get_local_version()

    if version_tuple(remote_version) > version_tuple(local_version):
        print(f'UPGRADE: ⚠️ 有新版本 v{remote_version}（当前 v{local_version}），说「更新 Rocky」一键升级')


if __name__ == '__main__':
    main()
