#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
setup.py - Rocky Todo List Buddy 首次安装配置引导

功能：
  1. 引导用户完成基础配置
  2. 自动检测并写入 system_start_date
  3. 创建 ~/.rocky-todo-list-buddy/ 目录和默认 config.json
  4. 调用 db_init.py 初始化数据库

用法：
  python scripts/setup.py          # 交互式安装
  python scripts/setup.py --quiet  # 静默安装（全部使用默认值）
"""

import sys
import json
import argparse
import subprocess
from pathlib import Path
from datetime import date

SKILL_DIR   = Path(__file__).resolve().parent.parent  # 自发现：脚本位置反推 skill 根目录
DATA_DIR    = Path.home() / '.rocky-todo-list-buddy'
CONFIG_FILE = SKILL_DIR / 'config.json'
TEMPLATE_FILE = SKILL_DIR / 'config.template.json'


def load_template() -> dict:
    if TEMPLATE_FILE.exists():
        return json.loads(TEMPLATE_FILE.read_text(encoding='utf-8'))
    # 内建默认值
    return {
        "db_path": "~/.rocky-todo-list-buddy/rocky.db",
        "scripts_path": str(SKILL_DIR / 'scripts'),
        "reviews_path": "~/.rocky-todo-list-buddy/reviews/",
        "rocky_voice": True,
        "system_start_date": "",
        "backlog_monthly_window_days": 31
    }


def ask(prompt: str, default: str = '') -> str:
    """带默认值的用户输入"""
    if default:
        ans = input(f'{prompt} [{default}]: ').strip()
        return ans if ans else default
    return input(f'{prompt}: ').strip()


def run_setup(quiet: bool = False):
    print('='*50)
    print('Rocky Todo List Buddy — 安装配置向导')
    print('='*50)
    print()

    config = load_template()

    # 1. 写入 system_start_date
    today = date.today().isoformat()
    config['system_start_date'] = today
    print(f'✅ 系统启动日期：{today}')

    # 2. 创建数据目录
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    (DATA_DIR / 'reviews').mkdir(exist_ok=True)
    print(f'✅ 数据目录已创建：{DATA_DIR}')

    # 3. 写入 config.json（habits_file 已废弃，习惯定义统一通过 SQLite 管理）
    CONFIG_FILE.write_text(
        json.dumps(config, ensure_ascii=False, indent=2),
        encoding='utf-8'
    )
    print(f'\n✅ 配置文件已写入：{CONFIG_FILE}')

    # 5. 初始化数据库
    db_init = SKILL_DIR / 'scripts/db_init.py'
    if db_init.exists():
        result = subprocess.run(
            [sys.executable, str(db_init)],
            capture_output=True, text=True
        )
        if result.returncode == 0:
            print('✅ 数据库初始化完成')
        else:
            print(f'⚠️  数据库初始化失败：{result.stderr}')
    else:
        print('⚠️  未找到 db_init.py，请手动运行数据库初始化')

    print()
    print('='*50)
    print('✅ Rocky Todo List Buddy 安装完成！')
    print()
    print('使用方式：在 WorkBuddy 对话中说「记一下 todo」即可开始')
    print('='*50)


def main():
    parser = argparse.ArgumentParser(description='Rocky Todo List Buddy 安装配置')
    parser.add_argument('--quiet', '-q', action='store_true', help='静默安装（使用默认值）')
    args = parser.parse_args()
    run_setup(quiet=args.quiet)


if __name__ == '__main__':
    main()
