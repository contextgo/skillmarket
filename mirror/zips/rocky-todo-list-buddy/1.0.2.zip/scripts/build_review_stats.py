#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_review_stats.py - 复盘统计数据查询脚本 v1.0

职责：从 SQLite 精确查询指定日期的任务完成统计，输出结构化 JSON。
Agent 必须在组装 ReviewData JSON 之前先调用此脚本获取精确数字，
禁止手算或从对话上下文估算。

用法：
  python build_review_stats.py --date 2026-04-07
  python build_review_stats.py --date 2026-04-07 --format text

输出（JSON 模式，默认）：
  {
    "date": "2026-04-07",
    "work": {
      "planned": 6,       # schedule_date=date，status IN (active,done)，area=work
      "done": 4,          # schedule_date=date，status=done，area=work
      "unplanned_done": 0 # completed_at 在当日 but schedule_date != date 或 null，area=work
    },
    "life": {
      "planned": 0,
      "done": 0,
      "unplanned_done": 0
    },
    "habits": [
      {"name": "冥想练习", "status": "done"},
      {"name": "阅读打卡", "status": "pending"}
    ],
    "summary": {
      "work_planned": 6,
      "work_unplanned": 0,
      "work_done": 4,
      "work_rate": "4/6（67%）",
      "life_planned": 0,
      "life_unplanned": 0,
      "life_done": 0,
      "life_rate": "—"
    }
  }

输出（text 模式）：
  💼 工作：计划 6 项 · 计划外 0 项 · 完成 4 项 · 完成率 4/6（67%）
  🏠 生活：计划 0 项 · 计划外 0 项 · 完成 0 项 · —
  🏃 习惯：✅ 冥想练习 · ⏸️ 阅读打卡
"""

from __future__ import annotations

import argparse
import json
import sqlite3
import subprocess
import sys
from pathlib import Path

SCRIPTS_DIR = Path(__file__).parent
SKILL_ROOT  = SCRIPTS_DIR.parent

def _get_db_path() -> Path:
    """从 config.json 读取 db_path，fallback 到默认值"""
    cfg_file = SKILL_ROOT / 'config.json'
    if cfg_file.exists():
        cfg = json.loads(cfg_file.read_text())
        return Path(cfg.get('db_path', '~/.rocky-todo-list-buddy/rocky.db')).expanduser()
    return Path.home() / '.rocky-todo-list-buddy' / 'rocky.db'

def _get_conn() -> sqlite3.Connection:
    db_path = _get_db_path()
    if not db_path.exists():
        print(f"[ERROR] 数据库不存在：{db_path}", file=sys.stderr)
        sys.exit(1)
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    return conn


def query_stats(date: str) -> dict:
    conn = _get_conn()
    cur = conn.cursor()

    result = {
        'date': date,
        'work': {'planned': 0, 'done': 0, 'unplanned_done': 0},
        'life': {'planned': 0, 'done': 0, 'unplanned_done': 0},
        'habits': [],
    }

    for area in ('work', 'life'):
        # 计划数：schedule_date=date AND status IN (active,done) AND area=area
        # 注意：inbox 状态的任务未被激活，不计入计划
        cur.execute("""
            SELECT COUNT(*) as cnt FROM tasks
            WHERE is_deleted=0
              AND area=?
              AND schedule_date=?
              AND status IN ('active','done')
        """, (area, date))
        row = cur.fetchone()
        result[area]['planned'] = row['cnt'] if row else 0

        # 完成数：schedule_date=date AND status=done AND area=area
        cur.execute("""
            SELECT COUNT(*) as cnt FROM tasks
            WHERE is_deleted=0
              AND area=?
              AND schedule_date=?
              AND status='done'
        """, (area, date))
        row = cur.fetchone()
        result[area]['done'] = row['cnt'] if row else 0

        # 计划外完成：completed_at 在当日，但 schedule_date != date 或 null
        cur.execute("""
            SELECT COUNT(*) as cnt FROM tasks
            WHERE is_deleted=0
              AND area=?
              AND status='done'
              AND date(completed_at) = ?
              AND (schedule_date != ? OR schedule_date IS NULL)
        """, (area, date, date))
        row = cur.fetchone()
        result[area]['unplanned_done'] = row['cnt'] if row else 0

    # 习惯：先查 habit_instances，若今日无记录则自动兜底创建再查
    cur.execute("SELECT COUNT(*) as cnt FROM habit_instances WHERE date = ?", (date,))
    habit_count = cur.fetchone()['cnt']

    if habit_count == 0:
        # 今日无习惯实例，自动调用 create_habit_instance.py 补创建（幂等）
        create_script = SCRIPTS_DIR / 'create_habit_instance.py'
        if create_script.exists():
            try:
                subprocess.run(
                    [sys.executable, str(create_script), '--date', date],
                    capture_output=True, timeout=10
                )
                print(f'[INFO] 今日习惯实例不存在，已自动补创建（{date}）', file=sys.stderr)
            except Exception as e:
                print(f'[WARN] 自动补创建习惯实例失败：{e}', file=sys.stderr)

    # 查 habit_instances（简化模式：habit_name 列；生产模式：JOIN habit_definitions）
    # 尝试 JOIN 生产模式，失败则 fallback 到简化模式
    try:
        cur.execute("""
            SELECT hi.status, hd.name as habit_name
            FROM habit_instances hi
            JOIN habit_definitions hd ON hi.habit_id = hd.id
            WHERE hi.date = ?
            ORDER BY hd.name
        """, (date,))
        rows = cur.fetchall()
        if rows:
            result['habits'] = [{'name': r['habit_name'], 'status': r['status']} for r in rows]
        else:
            raise ValueError('JOIN 无结果，尝试简化模式')
    except Exception:
        # fallback：简化模式（habit_name 列直接存储）
        try:
            cur.execute("""
                SELECT habit_name, status FROM habit_instances
                WHERE date = ? ORDER BY habit_name
            """, (date,))
            rows = cur.fetchall()
            result['habits'] = [{'name': r['habit_name'], 'status': r['status']} for r in rows]
        except Exception:
            result['habits'] = []

    conn.close()

    # 生成 summary
    def _rate(done: int, planned: int, unplanned: int) -> str:
        total = planned + unplanned
        if total == 0:
            return '—'
        pct = round(done / total * 100)
        return f"{done}/{total}（{pct}%）"

    w = result['work']
    l = result['life']
    # work_done = 今日实际完成（计划内 + 计划外）；work_planned_done = 仅计划内完成
    work_actual = w['done'] + w['unplanned_done']
    life_actual = l['done'] + l['unplanned_done']
    result['summary'] = {
        'work_planned':      w['planned'],
        'work_unplanned':    w['unplanned_done'],
        'work_planned_done': w['done'],           # 计划内完成数（原 work_done）
        'work_done':         work_actual,          # 今日实际完成总数（含计划外）
        'work_rate':         _rate(work_actual, w['planned'], w['unplanned_done']),
        'life_planned':      l['planned'],
        'life_unplanned':    l['unplanned_done'],
        'life_planned_done': l['done'],
        'life_done':         life_actual,
        'life_rate':         _rate(life_actual, l['planned'], l['unplanned_done']),
    }

    return result


def format_text(stats: dict) -> str:
    s = stats['summary']
    lines = []
    lines.append(f"💼 工作：计划 {s['work_planned']} 项 · 计划外 {s['work_unplanned']} 项 · 完成 {s['work_done']} 项 · 完成率 {s['work_rate']}")
    lines.append(f"🏠 生活：计划 {s['life_planned']} 项 · 计划外 {s['life_unplanned']} 项 · 完成 {s['life_done']} 项 · {s['life_rate']}")

    habit_parts = []
    for h in stats['habits']:
        icon = '✅' if h['status'] == 'done' else ('❌' if h['status'] == 'cancelled' else '⏸️')
        habit_parts.append(f"{icon} {h['name']}")
    habit_str = ' · '.join(habit_parts) if habit_parts else '（无习惯记录）'
    lines.append(f"🏃 习惯：{habit_str}")
    return '\n'.join(lines)


def main() -> None:
    parser = argparse.ArgumentParser(
        description='复盘统计数据查询 v1.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    parser.add_argument('--date', required=True, help='统计日期，格式 YYYY-MM-DD')
    parser.add_argument('--format', choices=['json', 'text'], default='json',
                        help='输出格式：json（默认）或 text（人类可读）')
    args = parser.parse_args()

    stats = query_stats(args.date)

    if args.format == 'text':
        # rocky_voice 话术
        try:
            import json as _json
            _cfg_path = Path(__file__).resolve().parent.parent / 'config.json'
            _cfg = _json.loads(_cfg_path.read_text())
            rocky_voice = _cfg.get('rocky_voice', True)
        except Exception:
            rocky_voice = True

        print(format_text(stats))

        if rocky_voice:
            # 计算总完成率
            total_done = stats.get('work_done', 0) + stats.get('life_done', 0)
            total_planned = stats.get('work_planned', 0) + stats.get('life_planned', 0)
            total = total_done + stats.get('work_unplanned', 0) + stats.get('life_unplanned', 0)
            rate = total_done / total if total > 0 else 0
            if rate >= 0.8:
                print('good! good! good!')
            elif rate <= 0.4 and total > 0:
                print('bad! bad! bad!')
    else:
        print(json.dumps(stats, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
