
### ### 模块一：收件箱快记
# 1. AI 组装 Markdown frontmatter 并写入 {INBOX}/{YYYY-MM-DD}-{短标题}.md
# 2. 导入 SQLite，同时写入用户原文到 task_logs（--raw-input 必填）
python {SCRIPTS}/write_task.py import \
  --file "{INBOX}/{filename}.md" \
  --raw-input "用户原始输入原文（完整保留，不加工）"

### ### 模块二：待办安排
# 1. 未安排的新事项
python {SCRIPTS}/query.py --status inbox

# 2. DDL 逾期未完成
python {SCRIPTS}/query.py --overdue --status active

# 3. 已激活但无执行日期（无 schedule 无 ddl）
python {SCRIPTS}/query.py --status active --no-schedule --no-ddl

# 4. 计划日期已过但未完成（规则10：过期任务强制浮出）→ 必须放入 delayed_tasks 区块
python {SCRIPTS}/query.py --overdue-schedule

### ### 模块二：待办安排
python {SCRIPTS}/json_validator.py --input /tmp/inbox_view_{YYYY-MM-DD}.json --schema DailyPlan
python {SCRIPTS}/render_table.py --input /tmp/inbox_view_{YYYY-MM-DD}.json --mode daily-plan

### ### 模块二：待办安排
# 安排执行：inbox → active，设置优先级和日期
python {SCRIPTS}/write_task.py update --id {task_id} --status active --priority {p} --schedule {date}

# 取消
python {SCRIPTS}/write_task.py update --id {task_id} --status cancelled

# 搁置
python {SCRIPTS}/write_task.py update --id {task_id} --status someday

### ### 模块三：任务盘点
# 同步今日 Daily Note checkbox → SQLite（确保状态一致性）
python {SCRIPTS}/sync_md_to_db.py --date {YYYY-MM-DD}

### ### 模块三：任务盘点
python {SCRIPTS}/query.py --status active --schedule today
python {SCRIPTS}/query.py --status done --completed-today
# 过期任务强制浮出（规则10）
python {SCRIPTS}/query.py --overdue-schedule

### ### 模块三：任务盘点
python {SCRIPTS}/json_validator.py --input /tmp/daily_review_{YYYY-MM-DD}.json --schema DailyPlan
python {SCRIPTS}/render_table.py --input /tmp/daily_review_{YYYY-MM-DD}.json --mode daily-plan

### ### 模块三：任务盘点
# 标记完成
python {SCRIPTS}/write_task.py update \
  --id {task_id} \
  --status done \
  --completed-at "{YYYY-MM-DDTHH:mm:ss}"

# 计划外完成（新任务，直接 done）：先创建 Inbox 文件，再 import
python {SCRIPTS}/write_task.py import --file "{INBOX}/{filename}.md" --raw-input "{用户原文}"
python {SCRIPTS}/write_task.py update --id {task_id} --status done --completed-at "..."

### ### 模块三：任务盘点
# v2.8.0：序号映射改为上下文内联，无需调用 task_map.py
# 从 render_table.py 输出末尾的 TASK_SEQ_MAP 注释提取 map，保存在对话上下文

### ### 模块三：任务盘点
python {SCRIPTS}/query.py --status active --schedule week
python {SCRIPTS}/query.py --status done --completed-week
python {SCRIPTS}/query.py --status active --priority waiting
python {SCRIPTS}/query.py --status inbox
python {SCRIPTS}/query.py --status active --no-schedule --no-ddl
python {SCRIPTS}/query.py --status someday
python {SCRIPTS}/query.py --type habit --date-range {week_start},{week_end}
# 过期任务强制浮出（规则10）
python {SCRIPTS}/query.py --overdue-schedule

### ### 模块三：任务盘点
python {SCRIPTS}/json_validator.py --input /tmp/midweek_view_{YYYY-MM-DD}.json --schema DailyPlan
python {SCRIPTS}/render_table.py --input /tmp/midweek_view_{YYYY-MM-DD}.json --mode daily-plan

### ### 模块三：任务盘点
python {SCRIPTS}/write_task.py update --id {task_id} --schedule {date} --priority {p}
python {SCRIPTS}/write_task.py update --id {task_id} --status active --schedule {date}
python {SCRIPTS}/write_task.py update --id {task_id} --status active

### ### 模块四：晨间规划
# 一键获取今日完整计划数据（替代原 6 次独立 query.py 调用）
python {SCRIPTS}/build_plan.py --date {YYYY-MM-DD} --mode morning --output /tmp/morning_plan_{YYYY-MM-DD}.json

### ### 模块四：晨间规划
# 降级为手动 6 次查询（与 v1.x 兼容）
python {SCRIPTS}/query.py --status active --schedule today
python {SCRIPTS}/query.py --overdue
python {SCRIPTS}/query.py --overdue-schedule
python {SCRIPTS}/query.py --status active --priority waiting
python {SCRIPTS}/query.py --ddl-within 7 --status active
python {SCRIPTS}/query.py --status inbox

### ### 模块四：晨间规划
python {SCRIPTS}/create_habit_instance.py --date {YYYY-MM-DD} --dry-run
python {SCRIPTS}/create_habit_instance.py --date {YYYY-MM-DD}

### ### 模块四：晨间规划
# Step 1（v2.8.0 更新）：build_plan.py 内部已校验 JSON + 直接渲染，无需单独调用 json_validator
# Step 2：调用脚本渲染，将输出原样展示给用户（参见主 SKILL.md 规则13：--render-output + cat）
python {SCRIPTS}/build_plan.py --date {YYYY-MM-DD} --mode morning --render --render-output /tmp/morning_display.md
# Step 3（v2.8.0）：序号映射改为上下文内联，从渲染文件末尾 TASK_SEQ_MAP 注释提取 map
# 禁止调用 task_map.py create

### ### 模块四：晨间规划
# 将用户选择的 inbox 任务激活
python {SCRIPTS}/write_task.py update --id {task_id} --status active

# 过期任务 snooze N天（N天内不再浮出）
python {SCRIPTS}/write_task.py update --id {task_id} --snooze {N天后日期}
# 清除 snooze（立即恢复浮出）
python {SCRIPTS}/write_task.py update --id {task_id} --snooze clear

# 写入 Daily Note 定稿区
python {SCRIPTS}/write_daily.py write \
  --date {YYYY-MM-DD} \
  --section morning-plan \
  --content "..."

### ### 模块五：项目视图
# 获取所有活跃项目列表（含任务统计）
python {SCRIPTS}/query.py --type project-summary --format summary

# 查看单个项目详情
python {SCRIPTS}/query.py --project P-播客项目 --status active
python {SCRIPTS}/query.py --project P-播客项目 --status inbox
python {SCRIPTS}/query.py --project P-播客项目 --status done --completed-week

### ### 模块五：项目视图
python {SCRIPTS}/json_validator.py --input /tmp/project_view_{YYYY-MM-DD}.json --schema DailyPlan
python {SCRIPTS}/render_table.py --input /tmp/project_view_{YYYY-MM-DD}.json --mode daily-plan

### ### 模块五：项目视图
# 标记习惯完成
python {SCRIPTS}/write_task.py complete-habit --habit-id {HD-xxx} --date {YYYY-MM-DD}
# 标记习惯跳过
python {SCRIPTS}/write_task.py complete-habit --habit-id {HD-xxx} --date {YYYY-MM-DD} --status cancelled
# 带备注
python {SCRIPTS}/write_task.py complete-habit --habit-id {HD-xxx} --date {YYYY-MM-DD} --note "完成30分钟"
# 查询今日习惯
python {SCRIPTS}/query.py --type habit --date today

### ### 模块六：复盘
python {SCRIPTS}/review_state.py check --type {daily|weekly|monthly} --key {key}
# not_started 时：
python {SCRIPTS}/review_state.py start --type {daily|weekly|monthly} --key {key}

### ### 模块六：复盘
# daily 类型才需要同步当日 checkbox
python {SCRIPTS}/sync_md_to_db.py --date {YYYY-MM-DD}   # 仅 --type daily

### ### 模块六：复盘
# daily
python {SCRIPTS}/query.py --status active --schedule today
python {SCRIPTS}/query.py --status done --completed-today

# weekly
python {SCRIPTS}/query.py --status done --completed-week
python {SCRIPTS}/query.py --status active --schedule week
python {SCRIPTS}/query.py --type habit --date-range {week_start},{week_end}
python {SCRIPTS}/query.py --status someday

# monthly
python {SCRIPTS}/query.py --status done --completed-month
python {SCRIPTS}/query.py --type habit --date-range {month_start},{month_end}
python {SCRIPTS}/query.py --type project-summary
python {SCRIPTS}/query.py --status someday

### ### 模块六：复盘
# daily 用 render_review.py
python {SCRIPTS}/render_review.py --input /tmp/review_{key}.json

# weekly/monthly 用 render_table.py（项目视角汇总表）
python {SCRIPTS}/render_table.py --input /tmp/review_{key}.json --mode daily-plan

### ### 模块六：复盘
python {SCRIPTS}/write_task.py update --id {task_id} --status done --completed-at "..."
python {SCRIPTS}/write_task.py update --id {task_id} --status cancelled
# 计划外完成
python {SCRIPTS}/write_task.py import --file "{INBOX}/{filename}.md" --raw-input "{用户原文}"
python {SCRIPTS}/write_task.py update --id {task_id} --status done --completed-at "..."

# ✅ 第一轮完成，推进到第二轮（必须调用）
python {SCRIPTS}/review_state.py next --type {type} --key {key}

### ### 模块六：复盘
# daily：规划明天
python {SCRIPTS}/query.py --status active --schedule today     # 今日顺延
python {SCRIPTS}/query.py --status active --schedule tomorrow  # 明日已有安排
python {SCRIPTS}/query.py --ddl-within 1 --status active       # 明日 DDL
python {SCRIPTS}/query.py --overdue
python {SCRIPTS}/query.py --overdue-schedule                   # 规则10
python {SCRIPTS}/query.py --status inbox

# weekly：规划下周
python {SCRIPTS}/query.py --status active --schedule next-week
python {SCRIPTS}/query.py --ddl-within 14 --status active
python {SCRIPTS}/query.py --status inbox
python {SCRIPTS}/query.py --overdue-schedule                   # 规则10

# monthly：规划下月
python {SCRIPTS}/query.py --status active --schedule next-month
python {SCRIPTS}/query.py --ddl-within 31 --status active
python {SCRIPTS}/query.py --status inbox
python {SCRIPTS}/query.py --overdue-schedule                   # 规则10

### ### 模块六：复盘
python {SCRIPTS}/create_habit_instance.py --date {tomorrow_date}   # 仅 daily

### ### 模块六：复盘
python {SCRIPTS}/json_validator.py --input /tmp/next_plan_{key}.json --schema DailyPlan
python {SCRIPTS}/render_table.py --input /tmp/next_plan_{key}.json --mode daily-plan

### ### 模块六：复盘
# ✅ 第二轮完成，推进到第三轮（必须调用）
python {SCRIPTS}/review_state.py next --type {type} --key {key}

### ### 模块六：复盘
# daily：写入复盘报告 + 明日计划
python {SCRIPTS}/render_review.py --input /tmp/review_{YYYY-MM-DD}.json \
  --write --date {YYYY-MM-DD} --section evening-review
python {SCRIPTS}/write_daily.py write \
  --date {YYYY-MM-DD} \
  --section next-day-plan \
  --content "..."

# weekly：写入周复盘报告到独立文件（路径：{REVIEWS}/Weekly/W-{YYYY}-W{周数}.md）
# 注意：weekly/monthly 复盘报告写入独立 Markdown 文件，不调用 write_daily.py
# AI 直接用 write_to_file 将复盘内容写入 {REVIEWS}/Weekly/W-{YYYY}-W{week_num}.md

# monthly：写入月复盘报告到独立文件（路径：{REVIEWS}/Monthly/M-{YYYY}-{MM}.md）
# AI 直接用 write_to_file 将复盘内容写入 {REVIEWS}/Monthly/M-{YYYY}-{MM}.md

# weekly/monthly 第三轮：静默执行归档（无需用户确认）
python {SCRIPTS}/write_task.py archive

# ✅ 标记复盘完成（必须调用）
python {SCRIPTS}/review_state.py done --type {type} --key {key}
