# Rocky Todo List Buddy 版本记录

> 本文件由 SKILL.md 迁出，不影响 skill 执行。Agent 无需在执行任务时读取本文件。

## 版本记录

| 版本 | 日期 | 变更内容 |
|------|------|---------|
| v2.5.0 | 2026-04-07 | 渲染展示架构升级（方案B）：render_table.py / render_review.py / build_plan.py 均加 --output/--render-output 参数，渲染结果写文件；新增全局规则13（渲染→文件→cat，禁止Agent手动转述）；SKILL.md 所有展示步骤改为 --output + cat 两步，速查表补充规则13行；RENDER_CHECK 注释机制（tasks=N / rows=N）用于截断检测 |
| v2.4.1 | 2026-04-07 | 每日复盘写入卡口：write_daily --section evening-review 要求 daily review 已 start；--section next-day-plan 要求 round >= 3（第二轮已完成）；两处均复用 review_state.py check 状态解析，失败 exit(1) 拒绝写入 |
| v2.4.0 | 2026-04-07 | 晨间规划状态机保护：review_state.py 扩展支持 morning_plan 类型（5步状态机：previewed→user_confirmed→db_written→dn_written→done）；write_daily.py write --section morning-plan 加卡口检查，step < 2 时物理拒绝写入；SKILL.md 模块四 SOP 重写为 5 步强制链路；速查表补充 ①-⑥ 步骤标注 |
| v2.3.2 | 2026-04-07 | bugfix：build_plan.py next-day 习惯加执行日过滤（execution_days 字段）；habit_definitions 新增 HD-阅读打卡（daily，life）；SKILL.md 版本升至 v2.3.2 |
| v2.3.1 | 2026-04-06 | 月复盘展示升级：query_weekly_review.py 扩展 --month 参数；render_review.py 新增 monthly-round1/2 模式（复用周复盘逻辑，差异仅文案）；SKILL.md 速查表和三B章节同步更新 |
| v2.3.0 | 2026-04-06 | 周复盘展示升级：新增 query_weekly_review.py（第一/二轮数据查询）+ render_review.py 新增 weekly-round1/round2 渲染模式；第一轮按项目分组展示完成/未完成，含总结引导语；第二轮按项目+周天表格展示，含候选池/过期任务/三件事询问；task_map 序号映射贯穿第二轮 |
| v2.2.6 | 2026-04-05 | 补全所有模块收尾对话格式约束（三B章节） |
| v2.2.5 | 2026-04-05 | SKILL.md 补充模块四对话回复格式约束（方案B：原样复现render输出）|
| v2.2.4 | 2026-04-05 | 三处格式修复：习惯区 #####→####、--no-candidate 参数、DN 测试残留清理 |
| v2.2.0 | 2026-04-05 | 性能优化：新增 batch_update.py（N个操作合并为1次tool call，消除多轮round-trip开销，收益~80%上下文减少）；SKILL.md 速查表标注批量操作优先 |
| v2.1.0 | 2026-04-04 | UX 优化：①复盘第一轮统一7列表格（含执行时间/DDL），习惯接续全局序号；②复盘第二轮延后/候选默认全量展示（无需额外指令）；③今日小结改为「计划/计划外/完成/完成率」四列表格；④明日安排改为工作/生活分区按项目表格；⑤无项目任务命名统一为「无项目任务」（废弃「日常任务」） |
| v2.0.0 | 2026-04-04 | 新功能批次：build_plan.py（单入口自动组装 DailyPlan）+ 模块五（项目视图）+ 习惯标准化（complete-habit/--type habit --date）+ snooze 机制（--snooze/snooze_until 字段/migration v2）；schemas.py 新增 seq_map/mode 字段；render_table.py 支持 TASK_SEQ_MAP 注释透传 |
| v1.7.1 | 2026-04-04 | bugfix：①query.py --schedule today 修复 due_date <= today（原 < 导致今天到期任务丢失）；②SKILL.md 模块六第三轮 weekly/monthly 写入改为直接写独立文件（原错误使用 write_daily.py --section weekly-review 会报错） |
| v1.7.0 | 2026-04-04 | SKILL.md 完整重写：模块三+三B合并、六A/六B/六C合并、模块九废弃（归档静默化）；P1/P2/P6/P9/P13同步落地 |
| v1.5.0 | 2026-04-04 | 代码修复：query.py 补全 schedule 分支（tomorrow/next-week/next-month）；加 --priority/--no-schedule/--no-ddl/--completed-xxx；write_task ensure_project；health_check 扩展；删除 render_daily.py |
| v1.4.0 | 2026-04-04 | query.py 加 --overdue-schedule；全局规则10过期任务强制浮出；7个模块统一加查询 |
| v1.3.0 | 2026-04-04 | 全局规则加第9条禁止AI手写表格；模块二/三/三B/四展示步骤改为强制调用 render_table.py |
| v1.2.0 | 2026-04-04 | review_state.py 扩展支持 weekly/monthly；六B/六C 加状态机保障；模块九加 dry-run 卡口；模块一 Step 0 顺序锁 |
| v1.1.0 | 2026-04-04 | 新增 review_state.py 复盘状态机；模块六A 改为状态机入口强制检查 |
| v1.0.0 | 2026-04-03 | 初始版本，脚本化架构全模块 SOP，基于 lifeops v2.4.0 升级 |

---

## v1.7.0 架构变化说明

1. **模块三合并**：日间整理 + 周间整理 → 统一为「任务盘点」，用 `--scope today/week` 区分视图。SOP 公共逻辑只维护一份。

2. **模块六合并**：每日/每周/每月复盘 → 统一为「复盘」，用 `--type daily/weekly/monthly` 区分。三轮结构、状态机调用、渲染方式完全统一，差异部分单独标注。

3. **模块九废弃**：归档不再作为独立模块。归档在周/月复盘第三轮写入后**自动静默执行**（`write_task.py archive`，无参数，不停等用户确认）。归档 = SQLite `is_deleted=1`，不移动 Markdown 文件。

4. **P1 落地**：write_daily.py 统一使用 `write --section {name} --content "..."` 格式，删除 SKILL.md 中所有不存在的子命令引用（write-plan/write-weekly-review/write-monthly-review/write-midweek/update-checkbox）。

5. **P2 落地**：全局规则 11 强制要求：render_table.py 调用前必须先通过 json_validator.py 校验。

6. **P6 落地**：模块三（今日盘点）和模块六（daily 第一轮）数据收集前，先调用 `sync_md_to_db.py` 同步当日 checkbox 状态到 SQLite。

7. **P9 落地**：模块一明确只录入、不激活；任务激活统一在模块四定稿时执行。

8. **P13 落地**：模块四加预览→修改→确认写入三步流程，中间调整不触发 DN 写入，确认后统一写入。
