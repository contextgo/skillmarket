## ☀️ 今日定稿计划（YYYY-MM-DD HH:mm 定稿）

### 💼 工作区（N 项 · ...）

#### 📂 P-播客项目
...（render_table.py 的表格输出）

#### 🏃 今日习惯（N 项）
...（render_table.py 的习惯表格输出）
```

---

### 模块五：项目视图

**触发词**：看项目进展、某项目怎么样了、项目盘点、项目全貌、所有项目

**数据收集**：
```bash
# 获取所有活跃项目列表（含任务统计）
python {SCRIPTS}/query.py --type project-summary --format summary

# 查看单个项目详情
python {SCRIPTS}/query.py --project P-播客项目 --status active
python {SCRIPTS}/query.py --project P-播客项目 --status inbox
python {SCRIPTS}/query.py --project P-播客项目 --status done --completed-week
```

**AI 职责**：
- 汇总各项目健康状态（进行中数量 / 待安排 / DDL 临近）
- 识别"沉默项目"（long time no active tasks）
- 生成项目视角表格展示

**渲染步骤**：
```bash
python {SCRIPTS}/json_validator.py --input /tmp/project_view_{YYYY-MM-DD}.json --schema DailyPlan
python {SCRIPTS}/render_table.py --input /tmp/project_view_{YYYY-MM-DD}.json --mode daily-plan
```

> ⚠️ **AI 不得自行拼写 Markdown 表格，必须使用 render_table.py 输出。**

🛑 **停等点**：展示项目全貌后停等用户反馈。

**习惯标准化写入**（完成习惯打卡）：
```bash
# 标记习惯完成
python {SCRIPTS}/write_task.py complete-habit --habit-id {HD-xxx} --date {YYYY-MM-DD}
# 标记习惯跳过
python {SCRIPTS}/write_task.py complete-habit --habit-id {HD-xxx} --date {YYYY-MM-DD} --status cancelled
# 带备注
python {SCRIPTS}/write_task.py complete-habit --habit-id {HD-xxx} --date {YYYY-MM-DD} --note "完成30分钟"
# 查询今日习惯
python {SCRIPTS}/query.py --type habit --date today
```

---

### 模块六：复盘

**触发词**：
- **每日复盘**：复盘、今天完成了、晚间复盘、今日总结、21:00 自动化触发
- **每周复盘**：周复盘、本周总结、周日 21:00 自动化触发
- **每月复盘**：月复盘、本月总结、每月最后一天 21:00 自动化触发

**--type 参数**：`daily` / `weekly` / `monthly`

> ⚠️ **SOP 保障机制：状态机强制三轮顺序执行**
>
> 本模块通过 `review_state.py` 追踪复盘轮次。Key 格式：
> - daily → `YYYY-MM-DD`
> - weekly → `YYYY-WNN`（如 `2026-W15`）
> - monthly → `YYYY-MM`
>
> | 步骤 | 脚本调用 | 时机 |
> |------|---------|------|
> | 进入模块六 | `review_state.py check --type {type} --key {key}` | **第一个动作** |
> | 未开始 → 第一轮 | `review_state.py start --type {type} --key {key}` | check 返回 `not_started` 时 |
> | 第一轮完成 → 第二轮 | `review_state.py next --type {type} --key {key}` | 用户确认后 |
> | 第二轮完成 → 第三轮 | `review_state.py next --type {type} --key {key}` | 用户确认后 |
> | 第三轮完成 | `review_state.py done --type {type} --key {key}` | 写入成功后 |
>
> **check 返回 `done` → 直接告知用户复盘已完成，不重复执行。**

---

#### 入口（必须第一个动作）

```bash
python {SCRIPTS}/review_state.py check --type {daily|weekly|monthly} --key {key}
# not_started 时：
python {SCRIPTS}/review_state.py start --type {daily|weekly|monthly} --key {key}
```

---

#### 第一轮：回顾

**数据收集前**（P6 落地：先同步 checkbox 状态，仅 daily 类型）：
```bash
# daily 类型才需要同步当日 checkbox
python {SCRIPTS}/sync_md_to_db.py --date {YYYY-MM-DD}   # 仅 --type daily
```

**数据收集**（按类型）：

```bash
# daily
python {SCRIPTS}/query.py --status active --schedule today
python {SCRIPTS}/query.py --status done --completed-today

# weekly
python {SCRIPTS}/query.py --status done --completed-week
python {SCRIPTS}/query.py --status active --schedule week
python {SCRIPTS}/query.py --type habit --date-range {week_start},{week_end}
python {SCRIPTS}/query.py --status someday

# monthly
python {SCRIPTS}/query.py --status done --completed-month
python {SCRIPTS}/query.py --type habit --date-range {month_start},{month_end}
python {SCRIPTS}/query.py --type project-summary
python {SCRIPTS}/query.py --status someday
```

**AI 职责**：
- daily：生成今日任务最终确认表（项目视角，状态列：✅/⏸️/⏩/❌），计算完成率
- weekly：分析本周完成率趋势、识别重复顺延的任务、生成亮点和反思
- monthly：月度完成率 + Area 健康度 + 搁置事项全量检视

**渲染**：
```bash
# daily 用 render_review.py
python {SCRIPTS}/render_review.py --input /tmp/review_{key}.json

# weekly/monthly 用 render_table.py（项目视角汇总表）
python {SCRIPTS}/render_table.py --input /tmp/review_{key}.json --mode daily-plan
```

询问用户：状态调整、计划外完成补录、新增任务、今日/本周/本月收获与反思。

🛑 **停等点 A**：展示回顾 + 询问后停等用户确认。

**用户回复后执行**：
```bash
python {SCRIPTS}/write_task.py update --id {task_id} --status done --completed-at "..."
python {SCRIPTS}/write_task.py update --id {task_id} --status cancelled
# 计划外完成
python {SCRIPTS}/write_task.py import --file "{INBOX}/{filename}.md" --raw-input "{用户原文}"
python {SCRIPTS}/write_task.py update --id {task_id} --status done --completed-at "..."

# ✅ 第一轮完成，推进到第二轮（必须调用）
python {SCRIPTS}/review_state.py next --type {type} --key {key}
```

---

#### 第二轮：规划下期

> **前置检查**：确认 `check` 输出 `CURRENT_ROUND: 2` 后再执行。

**数据收集**：
```bash
# daily：规划明天
python {SCRIPTS}/query.py --status active --schedule today     # 今日顺延
python {SCRIPTS}/query.py --status active --schedule tomorrow  # 明日已有安排
python {SCRIPTS}/query.py --ddl-within 1 --status active       # 明日 DDL
python {SCRIPTS}/query.py --overdue
python {SCRIPTS}/query.py --overdue-schedule                   # 规则10
python {SCRIPTS}/query.py --status inbox

# weekly：规划下周
python {SCRIPTS}/query.py --status active --schedule next-week
python {SCRIPTS}/query.py --ddl-within 14 --status active
python {SCRIPTS}/query.py --status inbox
python {SCRIPTS}/query.py --overdue-schedule                   # 规则10

# monthly：规划下月
python {SCRIPTS}/query.py --status active --schedule next-month
python {SCRIPTS}/query.py --ddl-within 31 --status active
python {SCRIPTS}/query.py --status inbox
python {SCRIPTS}/query.py --overdue-schedule                   # 规则10
```

**习惯实例创建**（daily 复盘时为明天创建）：
```bash
python {SCRIPTS}/create_habit_instance.py --date {tomorrow_date}   # 仅 daily
```

**输出规范（第二轮一次性全量展示，无需用户额外指令）**：

> ⚠️ **必须在同一次回复中展示以下所有区块，不得等用户追问：**
> 1. **明日计划**（今日顺延 + 明日已有安排）按工作/生活分区、按项目表格展示
> 2. **⏩ 延后事项**（overdue-schedule 结果）按工作/生活分区、按项目表格展示，含「重排至」和「原计划」列
> 3. **📦 候选事项**（inbox 结果）按工作/生活分区、按项目表格展示

**渲染步骤**：
```bash
python {SCRIPTS}/json_validator.py --input /tmp/next_plan_{key}.json --schema DailyPlan
python {SCRIPTS}/render_table.py --input /tmp/next_plan_{key}.json --mode daily-plan
```

🛑 **停等点 B**：展示建议计划（含延后 + 候选）后停等用户确认。

**延后事项展示格式**（AI 手工组装，按项目分区，含原计划列）：
```markdown
**⏩ 延后事项**

**💼 工作**

📂 {项目名}
| # | P | 任务 | 原计划 | 重排至 |
|---|---|------|--------|--------|
| N | 🟡 | 任务标题 | 04-01 | 04-08 |
```

**候选事项展示格式**（AI 手工组装，按项目分区）：
```markdown
**📦 候选事项（inbox，待激活）**

**💼 工作**

📂 {项目名 / 无项目任务}
| # | P | 任务 | 说明 |
|---|---|------|------|
| N | 🟢 | 任务标题 | — |
```

**用户确认后执行**：
```bash
# ✅ 第二轮完成，推进到第三轮（必须调用）
python {SCRIPTS}/review_state.py next --type {type} --key {key}
```

---

#### 第三轮：写入

> **前置检查**：确认 `check` 输出 `CURRENT_ROUND: 3` 后再执行。

```bash
# daily：写入复盘报告 + 明日计划
python {SCRIPTS}/render_review.py --input /tmp/review_{YYYY-MM-DD}.json \
  --write --date {YYYY-MM-DD} --section evening-review
python {SCRIPTS}/write_daily.py write \
  --date {YYYY-MM-DD} \
  --section next-day-plan \
  --content "..."

# weekly：写入周复盘报告到独立文件（路径：{REVIEWS}/Weekly/W-{YYYY}-W{周数}.md）
# 注意：weekly/monthly 复盘报告写入独立 Markdown 文件，不调用 write_daily.py
# AI 直接用 write_to_file 将复盘内容写入 {REVIEWS}/Weekly/W-{YYYY}-W{week_num}.md

# monthly：写入月复盘报告到独立文件（路径：{REVIEWS}/Monthly/M-{YYYY}-{MM}.md）
# AI 直接用 write_to_file 将复盘内容写入 {REVIEWS}/Monthly/M-{YYYY}-{MM}.md

# weekly/monthly 第三轮：静默执行归档（无需用户确认）
python {SCRIPTS}/write_task.py archive

# ✅ 标记复盘完成（必须调用）
python {SCRIPTS}/review_state.py done --type {type} --key {key}
```

输出确认：
- daily：「✅ 今日复盘完成，明日计划已生成。晚安！」
- weekly：「✅ 本周复盘完成，下周计划已生成！」
- monthly：「✅ 本月复盘完成，下月规划已生成！」

---

