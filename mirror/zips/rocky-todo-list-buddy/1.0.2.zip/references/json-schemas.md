## 四、JSON 输出规范

**AI 输出 JSON 时必须遵守 schemas.py 中定义的模型结构，且必须通过 json_validator.py 校验（规则11）。**

### 4.1 任务字段规范

```json
{
  "id": "T-20260403-a3f91c",
  "title": "完成播客脚本终稿",
  "status": "active",
  "priority": "high",
  "area": "work",
  "project_id": "P-播客项目",
  "schedule_date": "2026-04-03",
  "due_date": "2026-04-08",
  "completed_at": null,
  "tags": [],
  "body": "",
  "source": "inbox"
}
```

**枚举值约束（严格，不得使用中文或 emoji）：**
- `status`：`inbox` / `active` / `done` / `cancelled` / `someday`
- `priority`：`urgent` / `high` / `normal` / `waiting`
- `area`：`work` / `life`

### 4.2 write_task.py 期望格式

AI 在写入时，通过先创建 Markdown 文件（使用标准 frontmatter 格式），再调用 `write_task.py import` 完成导入，而非直接传 JSON。

### 4.3 query.py 输出格式

```json
{
  "tasks": [...],
  "total": N,
  "query_time": "2026-04-03T09:42:00"
}
```

---

