#!/usr/bin/env python3
"""
Bug-Fixer Ultimate - 合并版
结合 bug-fixer + bug-fixer-pro 的最佳能力

设计理念:
- P0/P1: 确定性规则，毫秒级本地处理
- P2/P3: AI深度分析，复杂问题交给LLM
- 自进化: 从历史修复中学习

作者: AI创新引擎
灵感: mini-SWE-agent, bug-fixer, bug-fixer-pro
"""

import os
import re
import json
import argparse
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Optional, Tuple

# ============================================================
# 配置
# ============================================================
CONFIG = {
    "memory_dir": ".bug_fixes_memory",
    "max_history": 100,
    "ai_threshold": 0.6,
    "auto_fix_threshold": 0.95,
}

# API配置
API_URL = "https://api.siliconflow.cn/v1/chat/completions"
API_KEY = os.environ.get("SILICONFLOW_API_KEY", "")

# ============================================================
# 确定性规则 - P0/P1 (自动修复/建议修复)
# ============================================================
DETERMINISTIC_RULES = [
    # P0 - 自动修复 (置信度 95%+)
    {
        "id": "date_sort_no_reverse",
        "level": "P0",
        "severity": "medium",
        "pattern": r"(\.sort\(|sorted\()([^)]+)(\))",
        "check": lambda m, ctx: any(
            f in ctx["line"].lower()
            for f in ["created", "modified", "date", "time", "updated", "timestamp", "redirect"]
        ) and "reverse" not in ctx["line"],
        "fix": lambda m: m.group(1) + m.group(2) + ", reverse=True" + m.group(3),
        "message": "日期排序缺少 reverse=True",
        "auto_fix": True,
    },
    {
        "id": "nested_append",
        "level": "P0",
        "severity": "low",
        "pattern": r"\.append\(\s*\[",
        "check": lambda m, ctx: True,
        "fix": lambda m: ".extend(",
        "message": ".append([...]) 会创建嵌套列表",
        "auto_fix": True,
    },
    {
        "id": "assignment_in_condition",
        "level": "P0",
        "severity": "high",
        "pattern": r"if\s+(\w+)\s*=\s*(\w+)",
        "check": lambda m, ctx: "==" not in ctx["line"] and "if" in ctx["line"],
        "fix": lambda m: f"if {m.group(1)} == {m.group(2)}",
        "message": "条件中使用了赋值而非比较",
        "auto_fix": True,
    },
    # P1 - 建议修复 (置信度 80%+)
    {
        "id": "mutable_default",
        "level": "P1",
        "severity": "medium",
        "pattern": r"def\s+\w+\([^)]*=\s*(\[\]|\{\}|set\(\))",
        "check": lambda m, ctx: True,
        "fix": lambda m: "requires human review",
        "message": "可变默认参数可能导致意外行为",
        "auto_fix": False,
    },
    {
        "id": "bare_except",
        "level": "P1",
        "severity": "medium",
        "pattern": r"except\s*:",
        "check": lambda m, ctx: True,
        "fix": lambda m: "except Exception:",
        "message": "裸except语句捕获所有异常",
        "auto_fix": False,
    },
    {
        "id": "hardcoded_path",
        "level": "P1",
        "severity": "low",
        "pattern": r"['\"][A-Z]:\\\\|['\"]\/home\/",
        "check": lambda m, ctx: True,
        "fix": lambda m: "使用 os.path 或 Pathlib",
        "message": "硬编码路径可能导致跨平台问题",
        "auto_fix": False,
    },
    {
        "id": "unclosed_resource",
        "level": "P1",
        "severity": "high",
        "pattern": r"open\([^)]+\)(?!\s+as)",
        "check": lambda m, ctx: "with" not in ctx["line"],
        "fix": lambda m: "使用 with open() 确保关闭",
        "message": "文件资源未正确关闭",
        "auto_fix": False,
    },
]


# ============================================================
# AI系统提示词
# ============================================================
SYSTEM_PROMPT = """你是一个代码Bug修复助手。

任务流程：
1. 扫描代码找出所有潜在Bug
2. 分类：
   - P0: 确定性bug，可自动修复
   - P1: 建议修复，需要确认
   - P2: 复杂问题，AI深度分析
3. 返回JSON格式结果

【P0自动修复规则】
- if/for/def/while 缺少冒号 → 添加冒号
- if x = y（赋值）→ if x == y（比较）
- 日期排序缺少 reverse=True → 添加 reverse=True
- .append([...]) 创建嵌套列表 → 改为 .extend([...])

【P1建议修复规则】
- 可变默认参数 def foo(data=[]) → 内部初始化
- 裸except: → except Exception:
- 硬编码路径 → 使用os.path

【P2/P3 AI深度分析】
- 业务逻辑错误
- 空指针/类型错误
- 安全漏洞（SQL注入、XSS等）
- 性能问题
- 并发/线程安全问题

返回格式：
{
  "status": "ok|fixed|needs_review",
  "bugs_found": 数量,
  "auto_fixed": 数量,
  "needs_review": 数量,
  "details": [
    {
      "level": "P0|P1|P2|P3",
      "line": 行号或null,
      "issue": "问题描述",
      "fix": "修复方案或'requires human review'"
    }
  ],
  "summary": "一行总结"
}"""


# ============================================================
# 记忆系统
# ============================================================
class FixMemory:
    """自进化记忆系统"""

    def __init__(self, memory_dir: str = CONFIG["memory_dir"]):
        self.memory_dir = Path(memory_dir)
        self.memory_dir.mkdir(exist_ok=True)
        self.history_file = self.memory_dir / "fix_history.json"
        self.patterns_file = self.memory_dir / "learned_patterns.json"

    def load_history(self) -> List[Dict]:
        if self.history_file.exists():
            with open(self.history_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []

    def save_fix(self, bug: Dict, fix: Dict, success: bool):
        history = self.load_history()
        record = {
            "timestamp": datetime.now().isoformat(),
            "bug": bug,
            "fix": fix,
            "success": success
        }
        history.append(record)
        if len(history) > CONFIG["max_history"]:
            history = history[-CONFIG["max_history"]:]
        with open(self.history_file, 'w', encoding='utf-8') as f:
            json.dump(history, f, indent=2, ensure_ascii=False)

    def get_similar_fixes(self, error_pattern: str) -> List[Dict]:
        history = self.load_history()
        return [
            h for h in history
            if h.get("success") and error_pattern.lower() in str(h.get("bug", "")).lower()
        ]

    def learn_pattern(self, pattern: str, solution: str):
        patterns = self.load_patterns()
        existing = next((p for p in patterns if p["pattern"] == pattern), None)
        if existing:
            existing["count"] += 1
        else:
            patterns.append({"pattern": pattern, "solution": solution, "count": 1})
        self.save_patterns(patterns)

    def load_patterns(self) -> List[Dict]:
        if self.patterns_file.exists():
            with open(self.patterns_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        return []

    def save_patterns(self, patterns: List[Dict]):
        with open(self.patterns_file, 'w', encoding='utf-8') as f:
            json.dump(patterns, f, indent=2, ensure_ascii=False)


# ============================================================
# 本地规则扫描
# ============================================================
def scan_deterministic(code: str, filepath: str = "input") -> List[Dict]:
    """确定性规则扫描 - P0/P1"""
    bugs = []
    lines = code.split("\n")

    for i, line in enumerate(lines, 1):
        ctx = {"line": line, "line_num": i, "filepath": filepath}

        for rule in DETERMINISTIC_RULES:
            for match in re.finditer(rule["pattern"], line):
                if rule["check"](match, ctx):
                    bugs.append({
                        "level": rule["level"],
                        "severity": rule["severity"],
                        "line": i,
                        "rule_id": rule["id"],
                        "issue": rule["message"],
                        "fix": rule["fix"](match) if rule["auto_fix"] else rule["message"],
                        "auto_fix": rule["auto_fix"],
                        "match": match.group(),
                    })
                    break  # 每行每种规则只报一次

    return bugs


# ============================================================
# AI分析
# ============================================================
def ai_analyze(code: str, filename: str = "input") -> Optional[Dict]:
    """调用 DeepSeek 深度分析"""
    if not API_KEY:
        return None

    try:
        import requests

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": f"分析代码，找出Bug并修复：\n\n文件名: {filename}\n\n```{filename.split('.')[-1] if '.' in filename else 'python'}\n{code}\n```"}
        ]

        response = requests.post(
            API_URL,
            headers={
                "Authorization": f"Bearer {API_KEY}",
                "Content-Type": "application/json"
            },
            json={
                "model": "deepseek-ai/DeepSeek-V3",
                "messages": messages,
                "temperature": 0.1,
                "max_tokens": 4096
            },
            timeout=60
        )

        if response.status_code == 200:
            result = response.json()
            content = result["choices"][0]["message"]["content"]

            # 提取JSON
            if "```json" in content:
                content = content.split("```json")[1].split("```")[0]
            elif "```" in content:
                content = content.split("```")[1].split("```")[0]

            return json.loads(content.strip())
        else:
            return {"error": f"API error: {response.status_code}"}

    except Exception as e:
        return {"error": str(e)}


# ============================================================
# 自动修复
# ============================================================
def apply_auto_fix(code: str, bugs: List[Dict]) -> Tuple[str, List[Dict]]:
    """应用P0级别的自动修复"""
    fixed_code = code
    fixed_list = []

    for bug in bugs:
        if bug.get("level") != "P0" or not bug.get("auto_fix"):
            continue

        issue = bug["issue"]
        rule_id = bug["rule_id"]

        if rule_id == "date_sort_no_reverse":
            fixed_code = re.sub(
                r"(\.sort\(|sorted\()([^)]+)(\))",
                lambda m: m.group(1) + m.group(2) + ", reverse=True" + m.group(3),
                fixed_code
            )
            fixed_list.append({"rule": rule_id, "issue": issue})

        elif rule_id == "nested_append":
            fixed_code = fixed_code.replace(".append([", ".extend([")
            fixed_list.append({"rule": rule_id, "issue": issue})

        elif rule_id == "assignment_in_condition":
            fixed_code = re.sub(
                r"if\s+(\w+)\s*=\s*(\w+)",
                lambda m: f"if {m.group(1)} == {m.group(2)}",
                fixed_code
            )
            fixed_list.append({"rule": rule_id, "issue": issue})

    return fixed_code, fixed_list


# ============================================================
# 主分析器
# ============================================================
class BugFixerUltimate:
    """Bug-Fixer Ultimate 主类"""

    def __init__(self, memory_dir: str = CONFIG["memory_dir"]):
        self.memory = FixMemory(memory_dir)
        self.all_issues = []
        self.stats = {"scanned": 0, "bugs_found": 0, "auto_fixed": 0, "needs_review": 0}

    def analyze(self, code: str, filename: str = "input", use_ai: bool = True) -> Dict:
        """完整分析流程"""
        self.stats["scanned"] += 1

        # 1. 确定性规则扫描 (P0/P1)
        local_bugs = scan_deterministic(code, filename)
        self.all_issues.extend(local_bugs)

        # 2. 统计
        self.stats["bugs_found"] += len(local_bugs)
        p0_bugs = [b for b in local_bugs if b["level"] == "P0"]
        p1_bugs = [b for b in local_bugs if b["level"] == "P1"]

        # 3. 检查记忆库相似修复
        for bug in local_bugs:
            similar = self.memory.get_similar_fixes(bug.get("issue", ""))
            if similar:
                bug["known_fix"] = similar[0]["fix"] if similar else None
                bug["learned"] = True

        # 4. 检查是否需要AI分析 (P1高置信度或无本地规则命中)
        needs_ai = len(local_bugs) == 0 or any(b["severity"] == "high" for b in local_bugs)

        ai_result = None
        if use_ai and API_KEY and needs_ai:
            ai_result = ai_analyze(code, filename)

        # 5. 生成报告
        result = {
            "status": "ok",
            "scanned": filename,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "bugs_found": len(local_bugs),
            "auto_fixable": len(p0_bugs),
            "needs_review": len(p1_bugs),
            "ai_analyzed": ai_result is not None,
            "details": local_bugs,
            "summary": f"扫描完成，发现{len(local_bugs)}个Bug，{len(p0_bugs)}个可自动修复",
        }

        return result

    def fix(self, code: str, bugs: List[Dict]) -> Tuple[str, List[Dict]]:
        """应用自动修复"""
        return apply_auto_fix(code, bugs)

    def learn(self, bug: Dict, fix: Dict, success: bool = True):
        """学习修复经验"""
        self.memory.save_fix(bug, fix, success)
        if success:
            self.memory.learn_pattern(bug.get("issue", ""), fix.get("solution", ""))

    def generate_report(self) -> str:
        """生成Markdown报告"""
        if not self.all_issues:
            return "✅ 未发现问题"

        by_level = {"P0": [], "P1": [], "P2": [], "P3": []}
        for issue in self.all_issues:
            level = issue.get("level", "P3")
            if level in by_level:
                by_level[level].append(issue)

        lines = ["## Bug-Fixer Ultimate 修复报告", ""]
        lines.append(f"**扫描时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        lines.append(f"**发现问题**: {len(self.all_issues)} 个")
        lines.append("")

        # P0
        if by_level["P0"]:
            lines.append("### 🚨 P0 - 自动修复 (置信度 95%+)")
            for issue in by_level["P0"]:
                known = " [已知修复]" if issue.get("learned") else ""
                lines.append(f"- `[{issue['scanned']}:{issue['line']}]` {issue['issue']}{known}")
            lines.append("")

        # P1
        if by_level["P1"]:
            lines.append("### ⚠️ P1 - 建议修复 (置信度 80%+)")
            for issue in by_level["P1"]:
                known = " [已知修复]" if issue.get("learned") else ""
                lines.append(f"- `[{issue['scanned']}:{issue['line']}]` {issue['issue']}{known}")
                lines.append(f"  - 建议: {issue['fix']}")
            lines.append("")

        # 统计
        lines.append("### 📊 统计")
        lines.append(f"| 等级 | 数量 | 处理 |")
        lines.append(f"|------|------|------|")
        lines.append(f"| P0 | {len(by_level['P0'])} | 自动修复 |")
        lines.append(f"| P1 | {len(by_level['P1'])} | 建议修复 |")

        return "\n".join(lines)


# ============================================================
# CLI入口
# ============================================================
def main():
    parser = argparse.ArgumentParser(description='Bug-Fixer Ultimate - 终极版')
    parser.add_argument('command', choices=['scan', 'fix', 'analyze'], help='命令')
    parser.add_argument('path', help='文件或目录路径')
    parser.add_argument('--auto-fix', action='store_true', help='自动修复P0问题')
    parser.add_argument('--no-ai', action='store_true', help='禁用AI分析')

    args = parser.parse_args()

    fixer = BugFixerUltimate()

    if args.command == 'scan':
        path = Path(args.path)
        if path.is_file():
            code = path.read_text(encoding='utf-8')
            result = fixer.analyze(code, path.name, use_ai=not args.no_ai)
            print(fixer.generate_report())
        elif path.is_dir():
            for ext in ['.py', '.js', '.ts', '.java', '.go']:
                for file in path.rglob(f'*{ext}'):
                    if '__pycache__' in str(file) or 'node_modules' in str(file):
                        continue
                    try:
                        code = file.read_text(encoding='utf-8')
                        fixer.analyze(code, file.name, use_ai=not args.no_ai)
                    except:
                        pass
            print(fixer.generate_report())

    elif args.command == 'fix':
        print("🔧 修复功能: 请使用 --auto-fix 参数")

    elif args.command == 'analyze':
        print("🤖 AI深度分析: 默认启用，使用 --no-ai 禁用")


if __name__ == '__main__':
    main()
