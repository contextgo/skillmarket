# Bug-Fixer Ultimate 🎯

合并 `bug-fixer` + `bug-fixer-pro` 的最佳能力

## 核心特性

| 特性 | bug-fixer | bug-fixer-pro | bug-fixer-ultimate |
|------|-----------|---------------|-------------------|
| 确定性规则 | ✅ 6条 | ✅ 4条 | ✅ **7条** |
| 自动修复 | ✅ | ❌ | ✅ |
| AI深度分析 | ✅ DeepSeek | ❌ | ✅ |
| 自进化记忆 | ❌ | ✅ | ✅ |
| 多语言支持 | 仅Python | ✅ 6种 | ✅ **6种** |
| 零依赖 | ❌ | ✅ | ✅ |

## 安装

```bash
# 无需安装，Python 3.8+ 即可运行
python bug_fixer_ultimate.py --help

# 可选：配置API密钥（启用AI分析）
export SILICONFLOW_API_KEY=your_key_here
```

## 快速开始

```bash
# 扫描当前目录
python bug_fixer_ultimate.py scan .

# 扫描并自动修复P0问题
python bug_fixer_ultimate.py scan . --auto-fix

# 禁用AI分析（纯本地规则）
python bug_fixer_ultimate.py scan . --no-ai
```

## 设计理念

**简单场景用本地规则，复杂场景用AI**

```
输入代码
   ↓
┌──────────────────┐
│  P0/P1: 本地规则  │  ← 毫秒级，零依赖
│  (确定性扫描)     │
└──────────────────┘
   ↓
┌──────────────────┐
│  P2/P3: AI分析   │  ← 仅复杂场景调用
│  (条件触发)       │
└──────────────────┘
   ↓
自进化记忆
```

## 质量对比

| Skill | agent-benchmark评分 | 等级 |
|-------|-------------------|------|
| bug-fixer-ultimate | **92** | **A- (90-94)** |
| bug-fixer-pro | 87 | B+ |
| bug-fixer | 79 | C |

## 项目结构

```
bug-fixer-ultimate/
├── SKILL.md              # Skill描述
├── bug_fixer_ultimate.py # 核心代码 (~350行)
└── README.md             # 本文件
```

## 灵感来源

- [mini-SWE-agent](https://github.com/SWE-agent/mini-swe-agent) - 100行代码的Agent奇迹
- [bug-fixer](../bug-fixer/) - DeepSeek API集成版
- [bug-fixer-pro](../bug-fixer-pro/) - 自进化记忆版

## 更新日志

- **2026-04-06**: 初始版本
  - 合并两个版本的最佳能力
  - 7条确定性规则
  - 自进化记忆系统
  - 条件触发AI分析
