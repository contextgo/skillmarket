// 诊断脚本：查看小红书搜索结果页面实际 DOM 结构
const CDP = require('chrome-remote-interface');

async function main() {
  const client = await CDP({ port: 9222, secure: false });
  const { Runtime, Page } = client;

  await client.Page.enable();
  await client.Runtime.enable();

  // 打开搜索页面
  await client.Page.navigate({
    url: 'https://www.xiaohongshu.com/search_result?keyword=ai&sort=time&type=51'
  });

  await client.Page.loadEventFired();
  await new Promise(r => setTimeout(r, 5000));

  // 截图
  const { data } = await client.Page.captureScreenshot({ type: 'png' });
  require('fs').writeFileSync('C:/Users/Administrator/.qclaw/workspace/xhs-debug.png', Buffer.from(data, 'base64'));
  console.log('截图已保存: xhs-debug.png');

  // 列出 body 下所有直接子元素的 tagName 和 class
  const result = await Runtime.evaluate({
    expression: `
      (function() {
        var items = document.querySelectorAll('*');
        var classes = new Set();
        items.forEach(function(el) {
          if (el.className && typeof el.className === 'string' && el.className.trim()) {
            classes.add(el.className.trim().substring(0, 80));
          }
        });
        return JSON.stringify(Array.from(classes).slice(0, 200));
      })();
    `,
    returnByValue: true
  });

  const classes = JSON.parse(result.result.value || '[]');
  console.log('\n页面中的 class 列表（前100个）:');
  classes.slice(0, 100).forEach(c => console.log(' ', c));

  // 找包含 "note" 或 "item" 的 class
  const noteClasses = classes.filter(c => /note|item|card|feed|content/i.test(c));
  console.log('\n包含 note/item/card 的 class:');
  noteClasses.forEach(c => console.log(' ', c));

  await client.close();
}

main().catch(console.error);
