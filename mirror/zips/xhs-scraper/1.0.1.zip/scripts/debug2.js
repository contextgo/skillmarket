// 深度诊断：小红书笔记的 DOM 结构
const CDP = require('chrome-remote-interface');

async function main() {
  const client = await CDP({ port: 9222, secure: false });
  const { Runtime, Page } = client;
  await client.Page.enable();
  await client.Runtime.enable();

  await client.Page.navigate({
    url: 'https://www.xiaohongshu.com/search_result?keyword=ai&sort=time&type=51'
  });
  await client.Page.loadEventFired();
  await new Promise(r => setTimeout(r, 5000));

  // 获取第一个 note-item 的完整 HTML
  const result = await Runtime.evaluate({
    expression: `
      (function() {
        var note = document.querySelector('.note-item');
        if (!note) return '没有找到 .note-item';
        return note.outerHTML.substring(0, 2000);
      })();
    `,
    returnByValue: true
  });

  console.log('第一个 note-item HTML:');
  console.log(result.result.value);

  // 测试提取逻辑
  const extractResult = await Runtime.evaluate({
    expression: `
      (function() {
        var notes = [];
        document.querySelectorAll('.note-item').forEach(function(item) {
          var title = (item.querySelector('[class*="title"]') || {}).textContent || '';
          var author = (item.querySelector('[class*="name"]') || {}).textContent || '';
          var date = (item.querySelector('[class*="time"]') || {}).textContent || '';
          var likes = (item.querySelector('[class*="count"]') || {}).textContent || '';
          var link = (item.querySelector('a') || {}).href || '';
          notes.push({ title: title.trim(), author: author.trim(), date: date.trim(), likes: likes.trim(), link: link });
        });
        return JSON.stringify(notes.slice(0, 3));
      })();
    `,
    returnByValue: true
  });

  console.log('\n提取测试结果（前3条）:');
  console.log(extractResult.result.value);

  await client.close();
}

main().catch(console.error);
