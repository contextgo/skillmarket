/**
 * 小红书笔记采集脚本 - Claude关键词 本月发布 500赞以上
 */
const CONFIG = {
  keyword: 'Claude',        // 搜索关键词
  minLikes: 500,             // 最低点赞数
  dateFrom: '2026-04-01',    // 本月1日起
  dateTo: '2026-04-27',      // 今天
  browser: 'chrome',         // 浏览器
  maxScrolls: 30,            // 滚动轮数（足够了）
};

const CDP = require('chrome-remote-interface');
const fs = require('fs');

const BROWSER_PORTS = { chrome: 9222, edge: 9223 };

function parseDate(dateStr, now = new Date()) {
  if (!dateStr) return null;
  if (dateStr === '今天') return now.toISOString().split('T')[0];
  if (dateStr === '昨天') {
    const d = new Date(now); d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  }
  const m = dateStr.match(/^(\d+)天前$/);
  if (m) { const d = new Date(now); d.setDate(d.getDate() - parseInt(m[1])); return d.toISOString().split('T')[0]; }
  const m2 = dateStr.match(/^(\d{2})-(\d{2})$/);
  if (m2) return `2026-${m2[1]}-${m2[2]}`;
  if (dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) return dateStr;
  return null;
}

function parseLikes(s) {
  if (!s) return 0;
  let str = s.replace(/,/g, '').replace(/赞/g, '').trim();
  const w = str.match(/^([\d.]+)万$/);
  if (w) return Math.round(parseFloat(w[1]) * 10000);
  const w2 = str.match(/^([\d.]+)w$/i);
  if (w2) return Math.round(parseFloat(w2[1]) * 10000);
  return parseInt(str) || 0;
}

function buildSearchUrl(kw) {
  return `https://www.xiaohongshu.com/search_result?keyword=${encodeURIComponent(kw)}&sort=time&type=51`;
}

async function scrape(client) {
  const { Runtime, Page } = client;

  await Runtime.evaluate({
    expression: `
      (function() {
        window.__noteMap = new Map();
        window.__extract = function() {
          var items = document.querySelectorAll('[class*="noteItem"], .feeds-item, .search-result-item, [class*="feed"]');
          items.forEach(function(item) {
            try {
              var titleEl = item.querySelector('[class*="title"], h2, [class*="desc"], [class*="content"]');
              var authorEl = item.querySelector('[class*="author"], [class*="user"], [class*="nick"]');
              var dateEl = item.querySelector('[class*="date"], [class*="time"], time');
              var likesEl = item.querySelector('[class*="like"], [class*="count"], [class*="num"]');
              var linkEl = item.querySelector('a[href*="xhs"], a[href*="xiaohongshu"]');

              var title = titleEl ? titleEl.textContent.trim() : '';
              if (!title || title.length < 5) return;
              if (window.__noteMap.has(title)) return;

              var note = {
                title: title.substring(0, 80),
                author: authorEl ? authorEl.textContent.trim() : '',
                date: dateEl ? dateEl.textContent.trim() : '',
                likes: likesEl ? likesEl.textContent.trim() : '0',
                link: linkEl ? linkEl.href : ''
              };
              window.__noteMap.set(title, note);
            } catch(e) {}
          });
        };
        window.__scroll = async function(max) {
          for (var i = 0; i < max; i++) {
            window.scrollTo(0, document.body.scrollHeight);
            await new Promise(r => setTimeout(r, 2000));
            window.__extract();
            if (window.__noteMap.size > 0) {
              var last = Array.from(window.__noteMap.values()).pop();
              console.log('轮次 ' + (i+1) + '/' + max + ' | 累计: ' + window.__noteMap.size + ' | 最新: ' + last.title.substring(0,30));
            } else {
              console.log('轮次 ' + (i+1) + '/' + max + ' | 累计: ' + window.__noteMap.size);
            }
          }
        };
      })();
    `
  });

  await Page.loadEventFired();
  await new Promise(r => setTimeout(r, 3000));

  console.log('==============================================');
  console.log('小红书爆款笔记采集器 | Claude | 本月发布 | 500赞+');
  console.log('==============================================');
  console.log(`\n开始采集: ${CONFIG.keyword}`);
  console.log(`时间范围: ${CONFIG.dateFrom} ~ ${CONFIG.dateTo}`);
  console.log(`点赞要求: ≥${CONFIG.minLikes}`);
  console.log(`滚动次数: ${CONFIG.maxScrolls}\n`);

  // 等待注入完成
  await new Promise(r => setTimeout(r, 1000));

  console.log('开始滚动加载...\n');
  await Runtime.callFunctionOn({ functionDeclaration: `function() { return window.__scroll(${CONFIG.maxScrolls}); }` });
  await new Promise(r => setTimeout(r, CONFIG.maxScrolls * 2000 + 3000));

  const result = await Runtime.evaluate({ expression: 'JSON.stringify(Array.from(window.__noteMap.values()))' });
  const notes = JSON.parse(result.result.value || '[]');

  console.log('\n滚动完毕，提取完成！\n');

  const now = new Date();
  const filtered = notes.filter(n => {
    const likes = parseLikes(n.likes);
    if (likes < CONFIG.minLikes) return false;
    const date = parseDate(n.date, now);
    if (!date) return true;
    if (CONFIG.dateFrom && date < CONFIG.dateFrom) return false;
    if (CONFIG.dateTo && date > CONFIG.dateTo) return false;
    return true;
  });

  console.log('='.repeat(50));
  console.log(`符合条件的笔记: ${filtered.length} 条\n`);

  filtered.forEach((n, i) => {
    const d = parseDate(n.date, now) || n.date;
    const l = parseLikes(n.likes);
    const ls = l >= 10000 ? (l/10000).toFixed(1)+'万' : l+'赞';
    console.log(`${i+1}. ${n.title}`);
    console.log(`   作者: ${n.author} | 日期: ${d} | 点赞: ${ls}`);
    console.log(`   链接: ${n.link}\n`);
  });

  const outFile = `xhs-Claude-${Date.now()}.json`;
  fs.writeFileSync(outFile, JSON.stringify(filtered, null, 2));
  console.log(`结果已保存: ${outFile}`);
}

async function main() {
  const port = BROWSER_PORTS[CONFIG.browser] || 9222;
  console.log(`连接 Chrome (端口 ${port})...`);
  let client;
  try {
    client = await CDP({ port, secure: false });
    await client.Page.enable();
    await client.Runtime.enable();
    await client.Page.navigate({ url: buildSearchUrl(CONFIG.keyword) });
    await scrape(client);
  } catch (err) {
    console.error('连接错误:', err.message);
    console.log('\n请确保 Chrome 已开启调试端口: --remote-debugging-port=9222');
  } finally {
    if (client) await client.close();
  }
}

main();