// 诊断：获取第一个 note-item 的完整结构
const CDP = require('chrome-remote-interface');

async function main() {
  const client = await CDP({ port: 9222, secure: false });
  const { Runtime, Page } = client;
  await client.Page.enable();
  await client.Runtime.enable();

  await client.Page.navigate({
    url: 'https://www.xiaohongshu.com/search_result?keyword=ai&sort=time&type=51'
  });
  await client.Page.loadEventFired();
  await new Promise(r => setTimeout(r, 5000));

  const result = await Runtime.evaluate({
    expression: `
      (function() {
        var note = document.querySelector('.note-item');
        if (!note) return '没有找到 .note-item';
        return note.innerHTML;
      })();
    `,
    returnByValue: true
  });

  console.log('note-item innerHTML:');
  console.log(result.result.value.substring(0, 3000));

  await client.close();
}

main().catch(console.error);
