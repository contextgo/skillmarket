/**
 * 小红书笔记详情页互动数据采集（收藏数 + 评论数）
 * 
 * 功能：访问笔记详情页，仅提取点赞/收藏/评论数字
 * 风控策略：
 *   - 批次处理（每批50条）
 *   - 随机间隔（3-8秒）
 *   - 自动重试（触发风控后等待更长）
 *   - 飞书表格状态同步
 * 
 * 使用方式：
 *   node fetch-interactions.js
 */
const CDP = require('chrome-remote-interface');
const fs = require('fs');
const path = require('path');

// ========== 配置 ==========
const CONFIG = {
  // 飞书多维表格配置（已有）
  feishu: {
    appToken: 'Z4vpbRLXQaEsEPs0IREcCkTZnee',
    tableId: 'tblGMUNmoqh8c3Cr',
    // 字段名（根据你的表格结构调整）
    linkField: '笔记链接',      // 链接字段
    likesField: '点赞数',       // 点赞数字段
    collectField: '收藏数',     // 收藏数字段（需要手动在飞书表格里新增）
    commentField: '评论数',     // 评论数字段（需要手动在飞书表格里新增）
    statusField: '采集状态',    // 状态字段
  },
  
  // 采集控制
  batchSize: 50,        // 每批处理多少条
  batchGapMs: 90 * 60 * 1000,  // 批次间隔（90分钟 = 1.5小时）
  minDelayMs: 3000,     // 最小访问间隔（毫秒）
  maxDelayMs: 8000,    // 最大访问间隔（毫秒）
  
  // 如果全部从飞书读取，设为 true；否则从本地 JSON 读取
  useFeishu: true,
  
  // 本地 JSON 文件（不使用飞书时）
  inputFile: 'C:/Users/Administrator/.qclaw/workspace/xhs-deepseek-1777391913997.json',
  
  // 输出文件
  outputFile: 'C:/Users/Administrator/.qclaw/workspace/xhs-interactions.json',
};

// ========== 工具函数 ==========
function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

function randomDelay() {
  return CONFIG.minDelayMs + Math.random() * (CONFIG.maxDelayMs - CONFIG.minDelayMs);
}

function parseCount(s) {
  if (!s || s === '赞' || s === '收藏' || s === '评论') return 0;
  const str = String(s).replace(/,/g, '').replace(/[^\d.w万]/g, '').trim();
  if (/万/.test(str)) {
    const n = parseFloat(str.replace('万', ''));
    return Math.round(n * 10000);
  }
  return parseInt(str) || 0;
}

function extractNoteId(url) {
  // 从各种格式提取笔记ID
  const patterns = [
    /\/explore\/([a-f0-9]+)/i,
    /\/search_result\/([a-f0-9]+)/i,
    /note\/([a-f0-9]+)/i,
  ];
  for (const p of patterns) {
    const m = url.match(p);
    if (m) return m[1];
  }
  return null;
}

// ========== Chrome 连接 ==========
async function connectBrowser() {
  const client = await CDP({ port: 9222, secure: false });
  await client.Page.enable();
  await client.Runtime.enable();
  
  // 反检测：移除 webdriver 标志
  await client.Runtime.evaluate({
    expression: `
      Object.defineProperty(navigator, 'webdriver', {get: () => false});
      window.cdc_adoQpoasnfa76pfcZLmcfl_Array = undefined;
      window.cdc_adoQpoasnfa76pfcZLmcfl_Promise = undefined;
      window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol = undefined;
    `,
    returnByValue: false
  });
  
  return client;
}

// ========== 访问单条笔记，提取互动数据 ==========
async function fetchNoteInteractions(client, url, retryCount = 0) {
  const { Page, Runtime } = client;
  const maxRetries = 3;
  
  try {
    // 1. 导航到笔记页面
    await Page.navigate({ url });
    await Page.loadEventFired();
    
    // 等待页面基本加载
    await sleep(2000 + Math.random() * 2000);
    
    // 2. 等待页面主要内容出现
    let attempts = 0;
    while (attempts < 5) {
      const ready = await Runtime.evaluate({
        expression: `!!(document.querySelector('.note-content') || document.querySelector('.detail-desc') || document.querySelector('[class*="note"]'))`,
        returnByValue: true
      });
      if (ready.result.value) break;
      await sleep(1500);
      attempts++;
    }
    
    // 3. 提取互动数据
    const data = await Runtime.evaluate({
      expression: `
        (function() {
          var result = {
            likes: 0, collects: 0, comments: 0,
            rawLikes: '', rawCollects: '', rawComments: '',
            success: false, error: ''
          };
          
          try {
            // 方式1：找 .count 类型的元素（点赞/收藏/评论）
            var counts = document.querySelectorAll('[class*="count"]');
            counts.forEach(function(el) {
              var txt = el.textContent.trim();
              // 点赞 通常是数字 + 赞
              if (/\\d+.*赞/.test(txt) || /赞/.test(txt)) {
                result.rawLikes = txt;
                result.likes = parseInt(txt.replace(/[^\\d]/g,'')) || 0;
              }
              // 收藏
              else if (/收藏/.test(txt)) {
                result.rawCollects = txt;
              }
              // 评论
              else if (/评论/.test(txt) || /评论/.test(el.parentElement?.textContent || '')) {
                result.rawComments = txt;
              }
            });
            
            // 方式2：找 .social 区域的文本
            var social = document.querySelector('[class*="social"]') || 
                        document.querySelector('[class*="interact"]') ||
                        document.querySelector('[class*="action"]');
            if (social) {
              var text = social.textContent;
              // 提取所有数字+文字组合
              var matches = text.match(/(\\d[\\d.w]*)\\s*(赞|收藏|评论)/g);
              if (matches) {
                matches.forEach(function(m) {
                  if (/赞/.test(m)) result.rawLikes = m;
                  if (/收藏/.test(m)) result.rawCollects = m;
                  if (/评论/.test(m)) result.rawComments = m;
                });
              }
            }
            
            // 方式3：找底部固定的点赞/收藏/评论栏
            var bottomBar = document.querySelector('.bottom-actions') ||
                           document.querySelector('[class*="bottom"]');
            if (bottomBar) {
              var spans = bottomBar.querySelectorAll('span, em');
              spans.forEach(function(s) {
                var txt = s.textContent.trim();
                if (/^\\d/.test(txt) && /赞/.test(s.parentElement?.textContent || '')) {
                  result.rawLikes = txt;
                  result.likes = parseInt(txt.replace(/[^\\d]/g,'')) || 0;
                }
              });
            }
            
            // 方式4：直接搜索包含"赞"数字的元素
            var allSpans = document.querySelectorAll('span, em, div');
            allSpans.forEach(function(el) {
              var txt = el.textContent.trim();
              // 点赞数格式：1.2万赞 或 1234赞
              if (/^\\d[\\d.]*[w万]?赞$/.test(txt) && !result.rawLikes) {
                result.rawLikes = txt;
                result.likes = parseCount(txt);
              }
              // 收藏数格式
              if (/^\\d[\\d.]*[w万]?收藏$/.test(txt) && !result.rawCollects) {
                result.rawCollects = txt;
                result.collects = parseCount(txt);
              }
              // 评论数格式
              if (/^\\d[\\d.]*[w万]?评论$/.test(txt) && !result.rawComments) {
                result.rawComments = txt;
                result.comments = parseCount(txt);
              }
            });
            
            result.success = !!(result.rawLikes || result.rawCollects || result.rawComments);
          } catch(e) {
            result.error = e.message;
          }
          
          return result;
        })()
      `,
      returnByValue: true
    });
    
    const interaction = data.result.value || {};
    return {
      url,
      success: interaction.success || false,
      likes: interaction.likes || 0,
      collects: interaction.collects || 0,
      comments: interaction.comments || 0,
      rawLikes: interaction.rawLikes || '',
      rawCollects: interaction.rawCollects || '',
      rawComments: interaction.rawComments || '',
      error: interaction.error || '',
    };
    
  } catch (err) {
    // 如果是风控页面（验证码/404）
    if (err.message.includes('Navigation') || retryCount < maxRetries) {
      const waitTime = Math.pow(2, retryCount) * 30000; // 30s, 60s, 120s
      console.log(`  ⏳ 触发风控，等待 ${waitTime/1000}秒... (重试 ${retryCount + 1}/${maxRetries})`);
      await sleep(waitTime);
      return fetchNoteInteractions(client, url, retryCount + 1);
    }
    return { url, success: false, error: err.message };
  }
}

// ========== 从飞书读取待采集链接 ==========
async function fetchFromFeishu() {
  try {
    const { feishu_bitable_list_records } = require('./feishu-api.js');
    const records = await feishu_bitable_list_records(
      CONFIG.feishu.appToken,
      CONFIG.feishu.tableId,
      500
    );
    
    // 筛选未采集的记录
    return records.filter(r => {
      const fields = r.fields || {};
      const status = fields[CONFIG.feishu.statusField] || '';
      const link = fields[CONFIG.feishu.linkField] || '';
      return link && !status.includes('已采');
    }).map(r => ({
      recordId: r.record_id,
      link: r.fields[CONFIG.feishu.linkField] || '',
      title: r.fields['标题'] || r.fields['标题'] || '',
    }));
  } catch (e) {
    console.log('飞书读取失败，将使用本地文件:', e.message);
    return null;
  }
}

// ========== 主流程 ==========
async function main() {
  console.log('='.repeat(60));
  console.log('📱 小红书互动数据采集（收藏 + 评论）');
  console.log('='.repeat(60));
  console.log(`配置：每批 ${CONFIG.batchSize} 条，间隔 ${CONFIG.minDelayMs/1000}-${CONFIG.maxDelayMs/1000}秒`);
  console.log('');
  
  // 1. 读取待采集数据
  let notes = [];
  
  if (CONFIG.useFeishu) {
    const feishuNotes = await fetchFromFeishu();
    if (feishuNotes) {
      notes = feishuNotes;
      console.log(`📋 从飞书读取到 ${notes.length} 条待采集笔记`);
    }
  }
  
  if (!notes.length) {
    // 回退到本地 JSON
    if (fs.existsSync(CONFIG.inputFile)) {
      const raw = JSON.parse(fs.readFileSync(CONFIG.inputFile, 'utf8'));
      notes = raw.map((n, i) => ({
        recordId: null,
        link: n.笔记链接 || n.link || '',
        title: n.标题 || n.title || '',
        index: i,
      })).filter(n => n.link);
      console.log(`📁 从本地文件读取到 ${notes.length} 条笔记`);
    } else {
      console.log('❌ 没有找到数据源，请先采集笔记链接');
      return;
    }
  }
  
  console.log(`🎯 共 ${notes.length} 条笔记待采集`);
  console.log(`📦 分 ${Math.ceil(notes.length / CONFIG.batchSize)} 批次处理\n`);
  
  // 2. 连接 Chrome
  console.log('🔗 连接 Chrome...');
  let client;
  try {
    client = await connectBrowser();
    console.log('✅ Chrome 连接成功\n');
  } catch (err) {
    console.log('❌ Chrome 连接失败:', err.message);
    console.log('请确保 Chrome 已开启调试端口: --remote-debugging-port=9222');
    return;
  }
  
  // 3. 分批次处理
  const results = [];
  const batchCount = Math.ceil(notes.length / CONFIG.batchSize);
  
  for (let batch = 0; batch < batchCount; batch++) {
    const batchStart = batch * CONFIG.batchSize;
    const batchEnd = Math.min(batchStart + CONFIG.batchSize, notes.length);
    const batchNotes = notes.slice(batchStart, batchEnd);
    
    console.log(`\n📦 批次 ${batch + 1}/${batchCount} (${batchStart + 1}-${batchEnd} 条)`);
    console.log('-'.repeat(40));
    
    for (let i = 0; i < batchNotes.length; i++) {
      const note = batchNotes[i];
      const progress = `[${batchStart + i + 1}/${notes.length}]`;
      
      if (!note.link) {
        console.log(`${progress} ⏭️  跳过（无链接）: ${note.title}`);
        continue;
      }
      
      console.log(`${progress} 访问: ${note.title.substring(0, 30)}...`);
      
      const result = await fetchNoteInteractions(client, note.link);
      results.push({ ...note, ...result });
      
      if (result.success) {
        console.log(`   ✅ 赞:${result.rawLikes} 收藏:${result.rawCollects} 评论:${result.rawComments}`);
      } else {
        console.log(`   ⚠️  未提取到数据: ${result.error || '结构变更'}`);
      }
      
      // 间隔（最后一条除外）
      if (i < batchNotes.length - 1) {
        const delay = randomDelay();
        console.log(`   💤 等待 ${Math.round(delay/1000)}秒...`);
        await sleep(delay);
      }
    }
    
    // 批次间隔（最后一批除外）
    if (batch < batchCount - 1) {
      const gapMin = CONFIG.batchGapMs / 60000;
      console.log(`\n⏸️  批次完成，休息 ${gapMin} 分钟...`);
      await sleep(CONFIG.batchGapMs);
    }
  }
  
  await client.close();
  
  // 4. 保存结果
  console.log('\n' + '='.repeat(60));
  console.log('📊 采集完成\n');
  
  const successCount = results.filter(r => r.success).length;
  console.log(`成功: ${successCount}/${results.length} 条`);
  
  // 格式化输出
  results.forEach((r, i) => {
    if (r.success) {
      const likes = r.likes >= 10000 ? (r.likes/10000).toFixed(1)+'万' : r.likes+'赞';
      const collects = r.collects >= 10000 ? (r.collects/10000).toFixed(1)+'万' : r.collects;
      const comments = r.comments >= 10000 ? (r.comments/10000).toFixed(1)+'万' : r.comments;
      console.log(`【${i+1}】${r.title.substring(0,25)} | 👍${likes} | ⭐${collects} | 💬${comments}`);
    }
  });
  
  // 保存 JSON
  fs.writeFileSync(CONFIG.outputFile, JSON.stringify(results, null, 2));
  console.log(`\n💾 结果已保存: ${CONFIG.outputFile}`);
  
  return results;
}

// ========== 入口 ==========
main().catch(console.error);
