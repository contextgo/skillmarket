/**
 * 小红书笔记采集脚本 v4（2026-04-27 修复版）
 * 修复 CSS 选择器以适配小红书当前页面结构
 */
const CDP = require('chrome-remote-interface');
const fs = require('fs');

const CONFIG = {
  keyword: '小红书爆款选题',
  minLikes: 1000,
  dateFrom: '2026-04-01',
  dateTo: '2026-04-29',
  browser: 'chrome',
  maxScrolls: 80,
};

const BROWSER_PORTS = { chrome: 9222, edge: 9223 };

function parseDate(dateStr, now = new Date()) {
  if (!dateStr) return null;
  // 处理 "昨天 HH:MM" 格式
  const yesterdayTime = dateStr.match(/^昨天\s+(\d{1,2}:\d{2})$/);
  if (yesterdayTime) {
    const d = new Date(now); d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  }
  if (dateStr === '今天') return now.toISOString().split('T')[0];
  if (dateStr === '昨天') {
    const d = new Date(now); d.setDate(d.getDate() - 1);
    return d.toISOString().split('T')[0];
  }
  const hm = dateStr.match(/^(\d+)小时前$/);
  if (hm) return now.toISOString().split('T')[0];
  const m = dateStr.match(/^(\d+)天前$/);
  if (m) { const d = new Date(now); d.setDate(d.getDate() - parseInt(m[1])); return d.toISOString().split('T')[0]; }
  const m2 = dateStr.match(/^(\d{2})-(\d{2})$/);
  if (m2) return `2026-${m2[1]}-${m2[2]}`;
  if (dateStr.match(/^\d{4}-\d{2}-\d{2}$/)) return dateStr;
  return null;
}

function parseLikes(s) {
  if (!s) return 0;
  let str = s.replace(/,/g, '').replace(/赞/g, '').trim();
  const w = str.match(/^([\d.]+)万$/);
  if (w) return Math.round(parseFloat(w[1]) * 10000);
  const w2 = str.match(/^([\d.]+)w$/i);
  if (w2) return Math.round(parseFloat(w2[1]) * 10000);
  return parseInt(str) || 0;
}

function buildSearchUrl(kw) {
  return `https://www.xiaohongshu.com/search_result?keyword=${encodeURIComponent(kw)}&sort=time&type=51`;
}

async function scrape(client) {
  const { Runtime, Page } = client;

  await Page.loadEventFired();
  await new Promise(r => setTimeout(r, 3000));

  console.log(`\n采集: ${CONFIG.keyword} | ${CONFIG.dateFrom} ~ ${CONFIG.dateTo} | 点赞≥${CONFIG.minLikes}\n`);

  // 初始化
  await Runtime.evaluate({
    expression: `window.__noteMap = window.__noteMap || new Map()`,
    returnByValue: false
  });

  for (let i = 0; i < CONFIG.maxScrolls; i++) {
    await Runtime.evaluate({
      expression: `window.scrollTo(0, document.body.scrollHeight)`,
      returnByValue: false
    });
    await new Promise(r => setTimeout(r, 3000));

    // 提取当前可见笔记
    await Runtime.evaluate({
      expression: `
        (function() {
          document.querySelectorAll('.note-item').forEach(function(item) {
            try {
              var titleEl = item.querySelector('.title span');
              var title = titleEl ? titleEl.textContent : '';
              if (!title || window.__noteMap.has(title)) return;

              var nameEl = item.querySelector('.name');
              var timeEl = item.querySelector('.time');
              var countEl = item.querySelector('.count');
              
              // 获取搜索链接（带完整参数，点击后会正确跳转）
              var searchEl = item.querySelector('a.cover[href*="/search_result/"]') || 
                             item.querySelector('a[href*="/search_result/"]');
              var searchHref = searchEl ? searchEl.getAttribute('href') : '';
              var searchLink = searchHref ? 'https://www.xiaohongshu.com' + searchHref : '';
              
              var note = {
                title: title.trim().substring(0, 60),
                author: nameEl ? nameEl.textContent.trim() : '',
                date: timeEl ? timeEl.textContent.trim() : '',
                likes: countEl ? countEl.textContent.trim() : '0',
                link: searchLink
              };
              window.__noteMap.set(title, note);
            } catch(e) {}
          });
        })();
      `,
      returnByValue: false
    });

    if (i % 10 === 0 || i === CONFIG.maxScrolls - 1) {
      const countResult = await Runtime.evaluate({
        expression: `window.__noteMap ? window.__noteMap.size : 0`,
        returnByValue: true
      });
      console.log(`轮次 ${i + 1} / ${CONFIG.maxScrolls}，累计提取: ${countResult.result.value} 条`);
    }
  }

  console.log('\n正在读取采集数据...');

  const result = await Runtime.evaluate({
    expression: `JSON.stringify(Array.from(window.__noteMap.values()))`,
    returnByValue: true
  });

  const notes = JSON.parse(result.result.value || '[]');
  const now = new Date();

  const filtered = notes.filter(n => {
    const likes = parseLikes(n.likes);
    if (likes < CONFIG.minLikes) return false;
    const date = parseDate(n.date, now);
    // 无法解析日期的笔记，排除（更严格过滤）
    if (!date) {
      console.log(`[过滤] 无法解析日期: ${n.date} - "${n.title}"`);
      return false;
    }
    if (CONFIG.dateFrom && date < CONFIG.dateFrom) {
      console.log(`[过滤] 日期 ${date} < ${CONFIG.dateFrom}: "${n.title}"`);
      return false;
    }
    if (CONFIG.dateTo && date > CONFIG.dateTo) {
      console.log(`[过滤] 日期 ${date} > ${CONFIG.dateTo}: "${n.title}"`);
      return false;
    }
    return true;
  });

  const output = filtered.map((n, i) => {
    const d = parseDate(n.date, now) || n.date;
    const l = parseLikes(n.likes);
    const ls = l >= 10000 ? (l / 10000).toFixed(1) + '万' : l + '赞';
    return {
      序号: i + 1,
      标题: n.title,
      作者: n.author,
      发布日期: d,
      点赞数: ls,
      笔记链接: n.link || '（未获取到链接）'
    };
  });

  console.log('\n' + '='.repeat(60));
  console.log(`采集结果: ${filtered.length} 条 | 关键词: ${CONFIG.keyword}\n`);

  output.forEach(n => {
    console.log(`【${n.序号}】${n.标题}`);
    console.log(`    作者: ${n.作者} | 日期: ${n.发布日期} | 点赞: ${n.点赞数}`);
    console.log(`    链接: ${n.笔记链接}`);
    console.log();
  });

  const ts = Date.now();
  const savePath = `C:/Users/Administrator/.qclaw/workspace/xhs-${CONFIG.keyword}-${ts}.json`;
  fs.writeFileSync(savePath, JSON.stringify(filtered, null, 2));
  console.log(`JSON 已保存: ${savePath}`);
}

async function main() {
  const port = BROWSER_PORTS[CONFIG.browser] || 9222;
  console.log(`连接 Chrome (${port})...`);
  let client;
  try {
    client = await CDP({ port, secure: false });
    await client.Page.enable();
    await client.Runtime.enable();
    await client.Page.navigate({ url: buildSearchUrl(CONFIG.keyword) });
    await scrape(client);
  } catch (err) {
    console.error('错误:', err.message);
    console.log('\n请确保 Chrome 已开启调试端口: --remote-debugging-port=9222');
  } finally {
    if (client) await client.close();
  }
}

main();
