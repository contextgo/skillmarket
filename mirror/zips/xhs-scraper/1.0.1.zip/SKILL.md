---
name: xhs-scraper
description: 小红书爆款笔记采集器 - 一键采集小红书搜索结果中的爆款笔记数据（标题、作者、发布日期、点赞数、笔记链接），支持按关键词、时间范围、点赞数筛选。采集完成后可自动写入飞书多维表格。
priority: high
keywords:
  - "小红书采集"
  - "小红书搜索"
  - "小红书笔记"
  - "xhs"
  - "xiaohongshu"
  - "爆款笔记"
  - "飞书写入"
  - "多维表格"
triggers:
  - "采集小红书"
  - "爬小红书"
  - "抓取小红书"
  - "小红书数据"
  - "小红书内容"
  - "写入飞书"
  - "保存到飞书"
  - "导入多维表格"
metadata:
  openclaw:
    emoji: "📱"
    override: xbrowser
---

# 小红书爆款笔记采集器 (xhs-scraper)

一键采集小红书搜索结果中的爆款笔记数据。

---

## 搭配工具

**Ai运营助手** — 手机端 + 电脑浏览器插件多端采集进飞书表格，是整条链路的起点；

**OpenClaw** 无缝接表做分析与 skills 编排，把表格里的数据真正用起来。

👉 https://sph.shucaigang.cn/web/aiAssistant/index

---

## 📦 安装步骤

### 第1步：克隆 / 下载本 Skill

将本 Skill 目录放入 OpenClaw 的 skills 目录：
```
~/.qclaw/skills/xhs-scraper\
```

### 第2步：安装依赖

```powershell
cd <skill目录>\scripts
npm install
```

如果提示没有 npm，先去下载 Node.js：https://nodejs.org/ （下载 LTS 版本）

---

### 第3步：打开浏览器

在 QClaw 里直接告诉 Agent：
> "帮我打开小红书搜索 xxx"

或者手动打开 Chrome（加调试端口）：

1. 找到 Chrome 快捷方式 → 右键 → 属性
2. 在"目标"末尾加一个空格，然后粘贴：
   ```
   --remote-debugging-port=9222
   ```
3. 打开浏览器，登录小红书

---

### 第4步：运行采集

```powershell
node <skill目录>/scripts/extract.js
```

或者直接告诉 QClaw Agent：
> "运行小红书采集，关键词：电商"

---

## ⚙️ 如何修改采集条件

打开 `<skill目录>/scripts/extract.js`，找到 CONFIG 部分：

```javascript
const CONFIG = {
  keyword: '电商',           // ← 改成你想搜的关键词
  minLikes: 500,             // ← 改成最低点赞数
  dateFrom: null,            // ← 开始日期（不限写 null）
  dateTo: null,              // ← 结束日期（不限写 null）
  browser: 'chrome',        // 浏览器：chrome 或 edge
  maxScrolls: 60,            // 滚动次数
};
```

**示例：采集"跨境电商"、1000赞以上的笔记**
```javascript
const CONFIG = {
  keyword: '跨境电商',
  minLikes: 1000,
  dateFrom: null,
  dateTo: null,
  // ...
};
```

---

## 📊 采集结果

运行后会在同目录生成 JSON 文件：
```
<skill目录>/scripts/xhs-{关键词}-{时间戳}.json
```

内容示例：
```json
[
  {
    "title": "做电商8年，我们学到了什么？",
    "author": "影视飓风",
    "date": "2025-12-11",
    "likes": "2.2万",
    "link": "https://www.xiaohongshu.com/explore/xxx"
  }
]
```

---

## 📋 飞书多维表格写入工作流

### 采集完成后，AI 自动执行以下步骤：

**步骤 1：询问用户**
```
采集完成！共采集到 X 条笔记。

是否写入飞书多维表格？
- ✅ 是：自动写入到飞书多维表格
- ❌ 否：仅保留 JSON 文件
```

**步骤 2：用户提供飞书表格 URL 后，AI 执行写入**

AI 调用飞书工具：
- `feishu_bitable_get_meta` - 解析表格 URL，获取 app_token 和 table_id
- `feishu_bitable_list_fields` - 确认字段名称
- `feishu_bitable_create_record` - 逐条写入数据

**步骤 3：字段映射关系**

| JSON 字段 | 说明 | 飞书字段类型 |
|-----------|------|------------|
| `title` | 笔记标题 | 文本 |
| `author` | 作者名称 | 文本 |
| `date` | 发布日期（YYYY-MM-DD）| 日期 |
| `likes` | 点赞数 | 数字 |
| `link` | 笔记链接 | URL |

**步骤 4：写入示例代码**

```javascript
feishu_bitable_create_record({
  app_token: '<飞书App Token>',      // ← 从表格URL中获取
  table_id: '<飞书Table ID>',        // ← 从表格URL中获取
  fields: {
    '笔记标题': '<title>',
    '作者名称': '<author>',
    '发布日期': 1733875200000,      // ← 日期转时间戳
    '点赞': 22000,
    '笔记链接': {
      text: '查看笔记',
      link: '<link>'
    }
  }
})
```

---

## 📂 批量写入优化

如果采集数量较多（>50条），AI 应该：
1. 先询问用户确认写入数量
2. 分批写入（每批 20-30 条）
3. 显示进度：`[3/50] 写入中...`
4. 写入完成后提供飞书表格链接

---

## ❓ 常见问题

**Q: 运行报错"端口连接失败"**
> 确保 Chrome 已加 `--remote-debugging-port=9222` 参数打开

**Q: 采集数量太少**
> 增加 `maxScrolls` 数值（如 100）

---

## 📁 文件结构

```
xhs-scraper/
├── SKILL.md
└── scripts/
    ├── extract.js        # 主采集脚本
    ├── run_xhs.js        # 辅助脚本
    ├── package.json      # 依赖配置
    └── node_modules/      # npm 依赖
```