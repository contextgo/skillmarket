---
name: springboot-mybatis
description: 为SpringBoot项目添加数据库和持久层配置。包含MySQL Connector、MyBatisPlus、分页插件、自动填充。此技能依赖于springboot-init生成的基础项目结构。
version: 1.0.0
author: CodeArts
---

# SpringBoot MyBatis增强技能

## 技能描述
为SpringBoot项目添加数据库和持久层配置，包含MySQL Connector、MyBatisPlus、分页插件、自动填充处理器。

## 使用场景
当用户需要在已有的SpringBoot项目基础上添加数据库和持久层配置时使用此技能。

## 依赖关系
此技能依赖于 springboot-init 技能生成的基础项目结构。

## 技能参数
- `artifactId`: 项目artifactId (必填)
- `packageName`: 主包名 (必填)
- `projectName`: 项目名称 (可选,默认使用artifactId)
- `author`: 作者信息 (可选,默认"CodeArts")

## 技能执行流程

### 1. 参数验证
- 验证必填参数
- 定位项目路径

### 2. 更新pom.xml
- 添加MySQL Connector依赖
- 添加MyBatisPlus依赖（自动从Maven Central搜索最新版本）
- 添加mybatis-plus-jsqlparser依赖（用于分页插件，从3.5.9+版本分离）

### 3. 更新application.yml
- 添加数据源配置
- 添加MyBatisPlus配置（驼峰映射、SQL日志、逻辑删除）

### 4. 生成配置类
- 生成MybatisPlusConfig配置类（分页插件）
- 生成MyMetaObjectHandler自动填充处理器

## 包含的依赖
- com.mysql:mysql-connector-j
- com.baomidou:mybatis-plus-spring-boot3-starter
- com.baomidou:mybatis-plus-jsqlparser

## 功能说明

### MybatisPlusConfig配置类
- 配置MybatisPlusInterceptor
- 添加PaginationInnerInterceptor分页插件

### MyMetaObjectHandler自动填充处理器
- insertFill: 自动填充createTime和createUser
- updateFill: 自动填充updateTime和updateUser
- 使用UserContext获取当前用户

## 代码规范
- 所有方法入参必须判空
- 方法返回值避免返回null
- 使用Objects进行判空检查
- 所有类必须包含标准注释

## 输出结果
- 更新后的pom.xml
- 更新后的application.yml
- config/MybatisPlusConfig.java - MyBatisPlus配置类
- config/MyMetaObjectHandler.java - 自动填充处理器

## 脚本执行
执行脚本添加MyBatisPlus增强：
```bash
python .trae/skills/springboot-mybatis/scripts/mybatis.py <artifactId> <packageName> [projectName] [springBootVersion] [author]
```
示例：
```bash
python .trae/skills/springboot-mybatis/scripts/mybatis.py demo com.example Demo 3.5 CodeArts
```
