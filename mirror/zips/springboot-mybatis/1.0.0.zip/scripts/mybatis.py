#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SpringBoot MyBatis增强
功能：为项目添加数据库和持久层配置

@author: CodeArts
@date: 2026-04-17
"""

import os
import re
import sys
import urllib.request
from datetime import datetime


class SpringBootMybatis:

    DEFAULT_VERSIONS = {
        "3.5": {
            "mybatis_plus": "3.5.16",
            "mybatis_starter": "mybatis-plus-spring-boot3-starter",
            "mysql": "8.0.33"
        },
        "3.2": {
            "mybatis_plus": "3.5.16",
            "mybatis_starter": "mybatis-plus-spring-boot3-starter",
            "mysql": "8.0.33"
        },
        "3.1": {
            "mybatis_plus": "3.5.16",
            "mybatis_starter": "mybatis-plus-spring-boot3-starter",
            "mysql": "8.0.33"
        },
        "2.7": {
            "mybatis_plus": "3.5.3",
            "mybatis_starter": "mybatis-plus-boot-starter",
            "mysql": "8.0.29"
        }
    }

    MAVEN_CENTRAL_API = "https://repo.maven.apache.org/maven2"

    def __init__(self, artifact_id: str, package_name: str, project_name: str = None, spring_boot_version: str = "3.5", **kwargs):
        if not artifact_id or not package_name:
            raise ValueError("artifactId和packageName不能为空")

        self.artifact_id = artifact_id
        self.package_name = package_name
        self.project_name = project_name or artifact_id
        self.spring_boot_version = spring_boot_version
        self.author = kwargs.get("author", "CodeArts")
        self.create_time = datetime.now().strftime("%Y-%m-%d")

        version_key = spring_boot_version.split(".")[0] + "." + spring_boot_version.split(".")[1]
        if version_key not in self.DEFAULT_VERSIONS:
            version_key = "3.5"
        self.version_key = version_key

        self.project_dir = os.getcwd()
        package_path = package_name.replace(".", os.sep)
        self.src_main_java = os.path.join(self.project_dir, "src", "main", "java", package_path)
        self.src_main_resources = os.path.join(self.project_dir, "src", "main", "resources")
        self.pom_path = os.path.join(self.project_dir, "pom.xml")

        self._resolve_versions()

    def _check_network(self) -> bool:
        try:
            req = urllib.request.Request("https://repo.maven.apache.org/maven2", headers={"User-Agent": "Mozilla/5.0"})
            urllib.request.urlopen(req, timeout=3)
            return True
        except Exception:
            return False

    def _fetch_latest_version(self, group_id: str, artifact_id: str) -> str:
        try:
            url = f"{self.MAVEN_CENTRAL_API}/{group_id.replace('.', '/')}/{artifact_id}/maven-metadata.xml"
            req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=5) as response:
                content = response.read().decode("utf-8")

            release_match = re.search(r'<release>([\d.]+)</release>', content)
            if release_match:
                return release_match.group(1)

            latest_match = re.search(r'<latest>([\d.]+)</latest>', content)
            if latest_match:
                return latest_match.group(1)

            versions = re.findall(r'<version>([\d.]+)</version>', content)
            if versions:
                return versions[-1]

        except Exception:
            pass

        return None

    def _resolve_versions(self):
        print("解析依赖版本...")

        has_network = self._check_network()

        default_mybatis_plus = self.DEFAULT_VERSIONS[self.version_key]["mybatis_plus"]
        default_mysql = self.DEFAULT_VERSIONS[self.version_key]["mysql"]
        self.mybatis_starter = self.DEFAULT_VERSIONS[self.version_key]["mybatis_starter"]

        if has_network:
            print("网络可用，搜索最新稳定版本...")

            latest_mybatis_plus = self._fetch_latest_version("com.baomidou", self.mybatis_starter)
            if latest_mybatis_plus:
                self.versions = {
                    "mybatis_plus": latest_mybatis_plus,
                    "mysql": default_mysql
                }
                print(f"  {self.mybatis_starter}: {latest_mybatis_plus} (在线)")
            else:
                self.versions = {
                    "mybatis_plus": default_mybatis_plus,
                    "mysql": default_mysql
                }
                print(f"  {self.mybatis_starter}: {default_mybatis_plus} (默认)")

            print(f"  mysql-connector-j: {default_mysql} (默认)")
        else:
            print("网络不可用，使用默认版本...")
            self.versions = {
                "mybatis_plus": default_mybatis_plus,
                "mysql": default_mysql
            }
            print(f"  {self.mybatis_starter}: {default_mybatis_plus}")
            print(f"  mysql-connector-j: {default_mysql}")

    def generate(self):
        print(f"开始添加MyBatis增强...")

        self._update_pom_xml()
        self._update_application_yml()

        self._ensure_package_structure()
        self._generate_mybatis_plus_config()
        self._generate_my_meta_object_handler()

        print(f"\n[OK] MyBatis增强添加成功!")
        print(f"更新文件:")
        print(f"  - pom.xml")
        print(f"  - src/main/resources/application.yml")
        print(f"生成文件:")
        print(f"  - config/MybatisPlusConfig.java")
        print(f"  - config/MyMetaObjectHandler.java")

    def _update_pom_xml(self):
        print("更新pom.xml...")

        if not os.path.exists(self.pom_path):
            print("错误: pom.xml不存在，请先运行springboot-init")
            sys.exit(1)

        with open(self.pom_path, "r", encoding="utf-8") as f:
            content = f.read()

        mybatis_dep = f'''
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>{self.mybatis_starter}</artifactId>
            <version>${{mybatis-plus.version}}</version>
        </dependency>'''

        jsqlparser_dep = f'''
        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-jsqlparser</artifactId>
            <version>${{mybatis-plus.version}}</version>
        </dependency>'''

        mysql_dep = f'''
        <dependency>
            <groupId>com.mysql</groupId>
            <artifactId>mysql-connector-j</artifactId>
            <version>${{mysql.version}}</version>
        </dependency>'''

        if "mybatis-plus" not in content:
            content = content.replace(
                "</dependencies>",
                mybatis_dep + "\n    </dependencies>"
            )

        if "mybatis-plus-jsqlparser" not in content:
            content = content.replace(
                "</dependencies>",
                jsqlparser_dep + "\n    </dependencies>"
            )

        if "mysql-connector-j" not in content:
            content = content.replace(
                "</dependencies>",
                mysql_dep + "\n    </dependencies>"
            )

        version_props = f"""        <mybatis-plus.version>{self.versions['mybatis_plus']}</mybatis-plus.version>
        <mysql.version>{self.versions['mysql']}</mysql.version>"""

        prop_pattern = re.compile(r'<mybatis-plus\.version>[\d.]+</mybatis-plus\.version>')
        if not prop_pattern.search(content):
            if "</properties>" in content:
                content = content.replace("</properties>", version_props + "\n    </properties>", 1)

        with open(self.pom_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _update_application_yml(self):
        print("更新application.yml...")

        yml_path = os.path.join(self.src_main_resources, "application.yml")

        if not os.path.exists(yml_path):
            print("错误: application.yml不存在，请先运行springboot-init")
            sys.exit(1)

        content = f'''# Server Configuration
server:
  port: 8080

# Spring Configuration
spring:
  application:
    name: {self.project_name}

  datasource:
    driver-class-name: com.mysql.cj.jdbc.Driver
    url: jdbc:mysql://localhost:3306/{self.artifact_id}?useUnicode=true&characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true
    username: root
    password: root

# MyBatis Plus Configuration
mybatis-plus:
  configuration:
    map-underscore-to-camel-case: true
    log-impl: org.apache.ibatis.logging.stdout.StdOutImpl
  global-config:
    db-config:
      logic-delete-field: deleted
      logic-delete-value: 1
      logic-not-delete-value: 0

# Logging Configuration
logging:
  level:
    {self.package_name}.mapper: debug
'''

        with open(yml_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _ensure_package_structure(self):
        dir_path = os.path.join(self.src_main_java, "config")
        os.makedirs(dir_path, exist_ok=True)

    def _generate_mybatis_plus_config(self):
        print("生成MybatisPlusConfig配置类...")

        content = f'''package {self.package_name}.config;

import com.baomidou.mybatisplus.extension.plugins.MybatisPlusInterceptor;
import com.baomidou.mybatisplus.extension.plugins.inner.PaginationInnerInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * MyBatis Plus配置类
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Configuration
public class MybatisPlusConfig {{

    @Bean
    public MybatisPlusInterceptor mybatisPlusInterceptor() {{
        MybatisPlusInterceptor interceptor = new MybatisPlusInterceptor();
        interceptor.addInnerInterceptor(new PaginationInnerInterceptor());
        return interceptor;
    }}
}}
'''

        file_path = os.path.join(self.src_main_java, "config", "MybatisPlusConfig.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)

    def _generate_my_meta_object_handler(self):
        print("生成MyMetaObjectHandler自动填充处理器...")

        content = f'''package {self.package_name}.config;

import {self.package_name}.util.UserContext;
import com.baomidou.mybatisplus.core.handlers.MetaObjectHandler;
import org.apache.ibatis.reflection.MetaObject;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.Objects;

/**
 * MyBatis Plus自动填充处理器
 *
 * @author {self.author}
 * @date {self.create_time}
 */
@Component
public class MyMetaObjectHandler implements MetaObjectHandler {{

    @Override
    public void insertFill(MetaObject metaObject) {{
        if (Objects.nonNull(metaObject)) {{
            this.strictInsertFill(metaObject, "createTime", LocalDateTime.class, LocalDateTime.now());
            this.strictInsertFill(metaObject, "createUser", String.class, UserContext.getUserCode());
            this.strictInsertFill(metaObject, "updateTime", LocalDateTime.class, LocalDateTime.now());
            this.strictInsertFill(metaObject, "updateUser", String.class, UserContext.getUserCode());
        }}
    }}

    @Override
    public void updateFill(MetaObject metaObject) {{
        if (Objects.nonNull(metaObject)) {{
            this.strictUpdateFill(metaObject, "updateTime", LocalDateTime.class, LocalDateTime.now());
            this.strictUpdateFill(metaObject, "updateUser", String.class, UserContext.getUserCode());
        }}
    }}
}}
'''

        file_path = os.path.join(self.src_main_java, "config", "MyMetaObjectHandler.java")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(content)


def main():
    if len(sys.argv) < 3:
        print("用法: python mybatis.py <artifactId> <packageName> [projectName] [springBootVersion] [author]")
        print("示例: python mybatis.py demo com.example Demo 3.5 CodeArts")
        sys.exit(1)

    artifact_id = sys.argv[1]
    package_name = sys.argv[2]
    project_name = sys.argv[3] if len(sys.argv) > 3 else None
    spring_boot_version = sys.argv[4] if len(sys.argv) > 4 else "3.5"
    author = sys.argv[5] if len(sys.argv) > 5 else "CodeArts"

    mybatis = SpringBootMybatis(artifact_id, package_name, project_name, spring_boot_version, author=author)
    mybatis.generate()


if __name__ == "__main__":
    main()
