#!/usr/bin/env python3
"""
通用查询CLI

用法:
  # 讲师查询
  python scripts/db_query.py --type lecturer --action list
  python scripts/db_query.py --type lecturer --action get --id 讲师A
  python scripts/db_query.py --type lecturer --action lite --id 讲师A
  python scripts/db_query.py --type lecturer --action compare --id 讲师A --id2 讲师B
  python scripts/db_query.py --type lecturer --action references --id 讲师A

  # 知识库查询
  python scripts/db_query.py --type knowledge --action list
  python scripts/db_query.py --type knowledge --action search --query "养生"
  python scripts/db_query.py --type knowledge --action search --query "养生" --category 产品目录
  python scripts/db_query.py --type knowledge --action get --id "产品目录/产品A/产品背书.txt"
  python scripts/db_query.py --type knowledge --action context --query "产品A产品特点" --max-tokens 1000

  # 系列文案查询
  python scripts/db_query.py --type series --action list
  python scripts/db_query.py --type series --action progress --id AI科普系列
  python scripts/db_query.py --type series --action summaries --id AI科普系列

  # 文案生成上下文
  python scripts/db_query.py --type context --lecturer 讲师A --query "养生保健"
"""

import argparse
import json
import sys
from pathlib import Path

SKILL_ROOT = str(Path(__file__).resolve().parent.parent)
if SKILL_ROOT not in sys.path:
    sys.path.insert(0, SKILL_ROOT)

from scripts.core.db_manager import DatabaseManager, resolve_db_path
from scripts.core.lecturer_service import LecturerService
from scripts.core.knowledge_service import KnowledgeService
from scripts.core.copywriting_service import CopywritingService


def _build_tree(root: Path, base_name: str = None) -> dict:
    """递归构建目录树，返回结构化JSON"""
    if not root.exists():
        return {"exists": False, "path": str(root)}

    name = base_name or root.name
    result = {"name": name, "type": "dir", "children": []}

    # 排序：目录在前，文件在后，各自按名称排序
    items = sorted(root.iterdir(), key=lambda p: (p.is_file(), p.name))

    for item in items:
        if item.name.startswith(".") or item.name == "__pycache__":
            continue
        if item.is_dir():
            result["children"].append(_build_tree(item))
        else:
            size = item.stat().st_size
            if size >= 1024 * 1024:
                size_str = f"{size / 1024 / 1024:.1f}MB"
            elif size >= 1024:
                size_str = f"{size / 1024:.1f}KB"
            else:
                size_str = f"{size}B"
            result["children"].append({
                "name": item.name,
                "type": "file",
                "size": size_str,
            })

    return result


def main():
    parser = argparse.ArgumentParser(description="Aicwos 数据查询")
    parser.add_argument("--type", required=True,
                        choices=["lecturer", "knowledge", "series", "context", "behavior", "fs"],
                        help="查询类型")
    parser.add_argument("--action", required=True, help="操作: list/get/lite/compare/references/search/context/summaries/progress")
    parser.add_argument("--id", default=None, help="讲师ID或文档ID")
    parser.add_argument("--id2", default=None, help="对比用第二个ID")
    parser.add_argument("--query", default=None, help="搜索查询词")
    parser.add_argument("--category", default=None, help="知识分类过滤")
    parser.add_argument("--product", default=None, help="产品过滤")
    parser.add_argument("--top-k", type=int, default=5, help="返回条数")
    parser.add_argument("--max-tokens", type=int, default=1000, help="上下文token预算")
    parser.add_argument("--lecturer", default=None, help="文案生成上下文-讲师ID")
    parser.add_argument("--series-id", default=None, help="系列ID（context类型可选）")
    parser.add_argument("--data-dir", required=True, help="控制台目录路径")
    args = parser.parse_args()

    try:
        resolved_db = resolve_db_path(None, args.data_dir)
    except ValueError as e:
        print(json.dumps({"status": "error", "message": str(e)}, ensure_ascii=False))
        return

    db = DatabaseManager(resolved_db)
    data_dir = args.data_dir
    result = None

    try:
        if args.type == "lecturer":
            svc = LecturerService(db)
            if args.action == "list":
                result = svc.list_lecturers()
            elif args.action == "get":
                result = svc.get_profile(args.id)
            elif args.action == "lite":
                result = svc.get_lite(args.id)
            elif args.action == "compare":
                result = svc.compare(args.id, args.id2)
            elif args.action == "references":
                result = svc.get_reference_samples(args.id)
            elif args.action == "quantitative":
                result = svc.get_quantitative(args.id)
            else:
                result = {"error": f"未知action: {args.action}"}

        elif args.type == "knowledge":
            svc = KnowledgeService(db)
            if args.action == "list":
                result = svc.list_categories()
            elif args.action == "search":
                result = svc.search(args.query, top_k=args.top_k,
                                     category=args.category)
            elif args.action == "get":
                result = svc.get_doc(args.id)
            elif args.action == "context":
                result = svc.get_relevant_context(args.query,
                                                    max_tokens=args.max_tokens)
            elif args.action == "docs":
                result = svc.list_docs_by_category(args.category)
            else:
                result = {"error": f"未知action: {args.action}"}

        elif args.type == "series":
            svc = CopywritingService(db, data_dir=data_dir)
            if args.action == "list":
                result = svc.list_series(args.lecturer)
            elif args.action == "progress":
                result = svc.get_series_progress(args.id)
            elif args.action == "summaries":
                result = svc.get_episode_summaries(args.id)
            elif args.action == "content":
                ep_num = int(args.id2) if args.id2 else 1
                result = {"content": svc.get_episode_content(args.id, ep_num)}
            else:
                result = {"error": f"未知action: {args.action}"}

        elif args.type == "context":
            svc = CopywritingService(db, data_dir=data_dir)
            result = svc.get_generation_context(
                lecturer_id=args.lecturer,
                topic=args.query or "",
                knowledge_query=args.query,
                series_id=args.series_id,
                max_knowledge_tokens=args.max_tokens,
            )

        elif args.type == "behavior":
            svc = CopywritingService(db, data_dir=data_dir)
            if args.action == "list":
                result = svc.load_behavior_rules()
            elif args.action in ("add", "remove", "update"):
                if not args.id:
                    result = {"error": "需要 --id 指定规则ID"}
                else:
                    rules = svc.load_behavior_rules()
                    # --id 前缀判断类型: A=allowed, F=forbidden
                    rules_type = "allowed" if args.id.startswith("R") else "forbidden"
                    rule_list = rules[rules_type]
                    if args.action == "add":
                        # --query 作为新规则的JSON
                        if not args.query:
                            result = {"error": "add需要 --query 传入规则JSON"}
                        else:
                            try:
                                new_rule = json.loads(args.query)
                                if "id" not in new_rule:
                                    new_rule["id"] = args.id
                                rule_list.append(new_rule)
                                result = svc.save_behavior_rules(rules_type, rule_list)
                            except json.JSONDecodeError:
                                result = {"error": "--query 不是有效JSON"}
                    elif args.action == "remove":
                        rule_list = [r for r in rule_list if r.get("id") != args.id]
                        result = svc.save_behavior_rules(rules_type, rule_list)
                    elif args.action == "update":
                        if not args.query:
                            result = {"error": "update需要 --query 传入更新后的规则JSON"}
                        else:
                            try:
                                updated = json.loads(args.query)
                                found = False
                                for i, r in enumerate(rule_list):
                                    if r.get("id") == args.id:
                                        rule_list[i] = updated
                                        found = True
                                        break
                                if found:
                                    result = svc.save_behavior_rules(rules_type, rule_list)
                                else:
                                    result = {"error": f"规则 {args.id} 不存在"}
                            except json.JSONDecodeError:
                                result = {"error": "--query 不是有效JSON"}
            else:
                result = {"error": f"未知action: {args.action}，可用: list/add/remove/update"}

        elif args.type == "fs":
            # 文件系统浏览：查看知识库集/讲师列表的目录和文件
            if not data_dir:
                result = {"error": "需要 --data-dir 指定数据目录"}
            else:
                data_path = Path(data_dir)
                if args.action == "tree":
                    # 查看完整目录树
                    result = _build_tree(data_path)
                elif args.action == "knowledge":
                    # 仅查看知识库集
                    result = _build_tree(data_path / "知识库集", base_name="知识库集")
                elif args.action == "lecturers":
                    # 仅查看讲师列表
                    result = _build_tree(data_path / "讲师列表", base_name="讲师列表")
                else:
                    result = {"error": f"未知action: {args.action}，可用: tree/knowledge/lecturers"}
    except Exception as e:
        result = {"error": str(e)}
    finally:
        db.close()

    print(json.dumps(result, ensure_ascii=False, indent=2, default=str))


if __name__ == "__main__":
    main()
