#!/usr/bin/env python3
"""
知识库云端同步

从云端拉取公共知识库，采用公共层+私有层架构：
- 公共层：云端权威，同步时覆盖；用户想定制就复制到私有层
- 私有层：纯本地，云端不管不碰
- 同名覆盖：私有层优先级 > 公共层

增量比对基于时间戳：远程文件 updated_at 比本地新则下载更新。

用法:
  python scripts/knowledge_sync.py --data-dir ./控制台
  python scripts/knowledge_sync.py --data-dir ./控制台 --force
  python scripts/knowledge_sync.py --data-dir ./控制台 --dry-run
  python scripts/knowledge_sync.py --data-dir ./控制台 --generate
"""

import argparse
import json
import sys
import urllib.request
import urllib.error
import urllib.parse
from datetime import datetime
from pathlib import Path

SKILL_ROOT = str(Path(__file__).resolve().parent.parent)
if SKILL_ROOT not in sys.path:
    sys.path.insert(0, SKILL_ROOT)


def now_str() -> str:
    """当前时间，格式：2026-04-19 21:02:35"""
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def parse_time(s: str) -> datetime:
    """解析时间字符串，兼容多种格式"""
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d:%H:%M:%S",
                "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except ValueError:
            continue
    # 兜底：返回最早时间，表示未知
    return datetime(2000, 1, 1)


def time_newer(t1: str, t2: str) -> bool:
    """t1 比 t2 新返回 True"""
    return parse_time(t1) > parse_time(t2)


def version_gt(v1: str, v2: str) -> bool:
    """比较语义化版本号，v1 > v2 返回True"""
    def parse(v):
        parts = v.lstrip("v").split(".")
        return [int(p) for p in parts[:3]]
    try:
        return parse(v1) > parse(v2)
    except (ValueError, IndexError):
        return v1 != v2


def fetch_json(url: str, timeout: int = 15) -> dict:
    """拉取远程JSON"""
    req = urllib.request.Request(url, headers={"User-Agent": "aicwos-sync/1.0"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def load_workspace(data_dir: Path) -> dict:
    """加载workspace.json"""
    ws_path = data_dir / "workspace.json"
    if ws_path.exists():
        return json.loads(ws_path.read_text(encoding="utf-8"))
    return {}


def load_local_manifest(data_dir: Path) -> dict:
    """加载本地manifest"""
    mf_path = data_dir / "知识库集" / "manifest.json"
    if mf_path.exists():
        return json.loads(mf_path.read_text(encoding="utf-8"))
    return {"version": "0", "updated_at": "2000-01-01 00:00:00", "files": []}


def save_local_manifest(data_dir: Path, manifest: dict):
    """保存本地manifest"""
    mf_path = data_dir / "知识库集" / "manifest.json"
    mf_path.parent.mkdir(parents=True, exist_ok=True)
    mf_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")


def sync_knowledge(data_dir: Path, force: bool = False, dry_run: bool = False) -> dict:
    """
    执行知识库同步

    1. 从workspace.json读取base_url
    2. 拼接 manifest_url = base_url + "/manifest.json"
    3. 拉取远程manifest.json
    4. 比对版本号和文件时间戳
    5. 增量同步公共层文件（新增/时间戳更新/标记下线）
    6. 更新本地manifest
    """
    ws = load_workspace(data_dir)
    sync_cfg = ws.get("knowledge_sync", {})
    base_url = sync_cfg.get("base_url", "").rstrip("/")

    if not base_url:
        return {"status": "no_config", "message": "workspace.json中未配置knowledge_sync.base_url。请向用户询问云端知识库地址，然后写入workspace.json的knowledge_sync.base_url字段。"}

    manifest_url = base_url + "/manifest.json"

    # 拉取远程manifest
    try:
        remote = fetch_json(manifest_url)
    except Exception as e:
        return {"status": "fetch_error", "message": f"拉取远程manifest失败: {e}"}

    # 本地manifest
    local = load_local_manifest(data_dir)

    # 版本比对
    remote_ver = remote.get("version", "0")
    local_ver = local.get("version", "0")

    if not force and not version_gt(remote_ver, local_ver):
        return {"status": "up_to_date", "local_version": local_ver, "remote_version": remote_ver}

    # base_url优先使用本地配置，远程manifest中的base_url仅作备用
    remote_base = remote.get("base_url", "")
    effective_base = base_url or remote_base

    # 以path为key建索引
    remote_files = {f["path"]: f for f in remote.get("files", [])}
    local_files = {f["path"]: f for f in local.get("files", [])}

    public_dir = data_dir / "知识库集" / "公共"

    added = []
    updated = []
    removed = []
    errors = []

    # 新增和修改（基于时间戳比对）
    for path, rf in remote_files.items():
        local_file = public_dir / path
        remote_time = rf.get("updated_at", "2000-01-01 00:00:00")

        if path not in local_files:
            # 新增
            action = "add"
        else:
            local_time = local_files[path].get("updated_at", "2000-01-01 00:00:00")
            if time_newer(remote_time, local_time):
                # 远程时间更新 → 需要下载
                action = "update"
            elif not local_file.exists():
                # 本地文件被删了，重新下载
                action = "update"
            else:
                continue

        if dry_run:
            if action == "add":
                added.append(path)
            else:
                updated.append(path)
            continue

        # 下载（URL中的中文路径需要percent-encoding）
        download_url = f"{effective_base}/{urllib.parse.quote(path, safe='/')}"
        try:
            req = urllib.request.Request(download_url, headers={"User-Agent": "aicwos-sync/1.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                content = resp.read()

            local_file.parent.mkdir(parents=True, exist_ok=True)
            local_file.write_bytes(content)

            if action == "add":
                added.append(path)
            else:
                updated.append(path)
        except Exception as e:
            errors.append(f"下载失败 {path}: {e}")

    # 标记下线（不删除文件）
    for path in local_files:
        if path not in remote_files:
            local_file = public_dir / path
            if local_file.exists():
                offline_file = public_dir / (path + ".offline")
                if not dry_run:
                    local_file.rename(offline_file)
                removed.append(path)

    # 更新本地manifest
    if not dry_run:
        save_local_manifest(data_dir, remote)

    return {
        "status": "synced" if not dry_run else "dry_run",
        "local_version": local_ver,
        "remote_version": remote_ver,
        "added": added,
        "updated": updated,
        "removed": removed,
        "errors": errors,
    }


def generate_manifest(data_dir: Path, version: str = "1.0.0") -> dict:
    """
    从本地公共层目录生成manifest.json（供云端维护者使用）

    base_url从workspace.json的knowledge_sync.base_url读取，不再硬编码。

    用法: python scripts/knowledge_sync.py --data-dir ./控制台 --generate --version 1.0.0
    """
    ws = load_workspace(data_dir)
    sync_cfg = ws.get("knowledge_sync", {})
    base_url = sync_cfg.get("base_url", "").rstrip("/")
    if not base_url:
        return {"status": "error", "message": "workspace.json中未配置knowledge_sync.base_url"}

    public_dir = data_dir / "知识库集" / "公共"
    if not public_dir.exists():
        return {"status": "error", "message": "公共层目录不存在"}

    files = []
    for f in sorted(public_dir.rglob("*")):
        if not f.is_file() or f.name.endswith(".offline"):
            continue
        rel = f.relative_to(public_dir)
        # 取文件修改时间作为updated_at
        mtime = datetime.fromtimestamp(f.stat().st_mtime).strftime("%Y-%m-%d %H:%M:%S")
        files.append({
            "path": str(rel).replace("\\", "/"),
            "size": f.stat().st_size,
            "updated_at": mtime,
        })

    manifest = {
        "version": version,
        "description": "口播文案知识库集",
        "updated_at": now_str(),
        "base_url": base_url,
        "files": files,
    }

    print(json.dumps(manifest, ensure_ascii=False, indent=2))
    return manifest


def main():
    parser = argparse.ArgumentParser(description="知识库云端同步")
    parser.add_argument("--data-dir", required=True, help="数据目录路径（含workspace.json）")
    parser.add_argument("--force", action="store_true", help="强制同步，忽略版本号")
    parser.add_argument("--dry-run", action="store_true", help="仅检查，不下载")
    parser.add_argument("--generate", action="store_true", help="从本地公共层生成manifest.json")
    parser.add_argument("--version", default="1.0.0", help="生成manifest时的版本号")
    args = parser.parse_args()

    data_dir = Path(args.data_dir)

    if args.generate:
        generate_manifest(data_dir, args.version)
    else:
        result = sync_knowledge(data_dir, force=args.force, dry_run=args.dry_run)
        print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
