# 文案生成流程

架构核心设计：
1. 文案生成时只加载轻量画像（~400 tokens），不全量读取profile.json
2. 知识库精准检索，只返回相关段落，不读整个文件
3. 系列文案连续性只读摘要，不读全文

## 获取生成上下文

一条命令获取文案生成所需的全部数据：

```bash
python scripts/db_query.py --type context --lecturer 讲师A --query "养生保健"
```

返回：
- `profile`: 轻量画像（lecturer_name + qualitative + persona_mapping + style_dimensions）
- `reference_samples`: 参考示例
- `knowledge_context`: token预算内的精准知识段落

## 单篇文案生成

1. 获取生成上下文（上述命令）
2. 加载风格模板：见 [script-styles.md](script-styles.md)
3. 融合画像+参考示例+知识段落+风格 → 生成文案
4. 保存文案（智能体写入文件）

## 系列文案

1. 制定系列计划（智能体生成）
2. 保存计划到数据库
3. 逐集生成，每集保存到数据库（含100字摘要+衔接点）

**连续性优化**：生成第N集时只读前N-1集的摘要（每集~100字），不读全文。

```bash
# 查看系列摘要（连续性用）
python scripts/db_query.py --type series --action summaries --id <系列名>
```

## 系列进度

```bash
python scripts/db_query.py --type series --action progress --id <系列名>
python scripts/db_query.py --type series --action list
```
