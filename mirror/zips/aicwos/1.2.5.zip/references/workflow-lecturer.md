# 讲师管理流程

画像数据存储在SQLite，按需加载字段，不再全量读取profile.json。

## 新增讲师画像

1. 接收用户文案样本或口头描述
2. 确认讲师名字（中文，如`讲师B`、`讲师A`）
3. 调用分析脚本：`python scripts/lecturer_analyzer.py --input <文件> --lecturer <名称>` 或 `--text "<文案>"`
4. 脚本自动将定量分析结果写入数据库（首次创建或增量合并）
5. 智能体推断定性特征，构建完整画像，通过 `db_query.py` 写入
6. 查看摘要：`python scripts/db_query.py --type lecturer --action lite --id <名称>`

## 查看讲师列表

```bash
python scripts/db_query.py --type lecturer --action list
```

## 查看讲师详情

- 轻量版（文案生成用，~400 tokens）：`--action lite`
- 完整版（管理用）：`--action get`

## 修改讲师画像

- **加新样本**：运行 `lecturer_analyzer.py --lecturer <名称> --input <新文件> --merge`
  - 自动加权合并定量数据（旧权重=旧样本数/总样本数）
  - 首次学习时旧权重=0，直接使用新数据
- **改属性**：智能体修改后通过db_query写入

## 删除/恢复讲师

删除操作移入回收站（含.meta.json记录原始路径），清理时永久删除。

## 对比讲师

```bash
python scripts/db_query.py --type lecturer --action compare --id 讲师A --id2 讲师B
```
