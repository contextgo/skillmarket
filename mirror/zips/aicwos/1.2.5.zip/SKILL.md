---
name: aicwos
version: 1.2.5
description: 基于SQLite+FTS5+向量检索的口播文案生成与讲师风格自学习技能，支持精准知识段落检索和轻量画像加载，大幅降低上下文消耗；当用户需要制作口播文案、学习讲师风格、管理讲师画像、批量生产短视频脚本或生成系列连续口播时使用
dependency:
  python:
    - jieba>=0.42.1
    - onnxruntime>=1.16.0
    - numpy>=1.24.0
---

# Aicwos - AI Copywriting Skills

## 首次使用引导

当用户首次使用本技能时，智能体必须按以下步骤逐项引导用户完成初始化。每完成一步，向用户确认后再进入下一步。

1. **初始化数据库与控制台目录** — 用户只需指定一个存放位置（如"桌面"、"D盘"），脚本会在该位置下**强制**创建名为"控制台"的文件夹：
   - 向用户询问："请告诉我控制台文件夹存放在哪个位置？例如：桌面、D盘、E盘等。"
   - 执行 `python scripts/db_init.py --setup --parent-dir "<用户指定的位置>"`
   - **重要**：必须使用 `--parent-dir` 参数（不是 `--data-dir`），脚本会自动在指定位置下创建名为"控制台"的文件夹，文件夹名称由代码强制为"控制台"，智能体不可自行改名或使用其他路径
   - 自动完成：创建"控制台"文件夹、SQLite数据库（`控制台/aicwos.db`）、全部表结构、控制台基础目录结构（回收站、讲师列表、知识库集/公共/公共行为、知识库集/私有）和默认文件（workspace.json、允许行为.json、禁止行为.json）
   - 脚本输出中包含 `console_dir` 字段，即控制台完整路径，后续步骤需使用此路径作为 `--data-dir` 的值
   - 完成后告知用户："数据库和控制台目录已创建完成，路径：`<console_dir>`，数据库位于：`<console_dir>/aicwos.db`"

2. **配置知识库云端地址** — 读取 workspace.json 的 `knowledge_sync.base_url`，若为空则向用户询问：
   - "请提供知识库云端存储地址（如 https://your-bucket.cos.ap-beijing.myqcloud.com/knowledge），我会帮你配置好。配置后可自动同步公共知识库（产品资料、行为规则等），不配置也不影响本地功能。"
   - 用户提供地址后，智能体写入 workspace.json 的 `base_url` 字段
   - 执行 `python scripts/knowledge_sync.py --data-dir "<控制台目录>"` 完成首次同步
   - 若用户暂时没有云端地址，告知："可以跳过，后续说'配置知识库地址'即可补配。"

3. **下载语义模型（可选）** — 向用户说明：
   - "是否下载语义检索模型（约98MB）？下载后支持语义匹配（如搜'家用保健设备'也能找到产品A），不下载则仅支持关键词检索。推荐下载。"
   - 用户同意：执行 `python scripts/db_init.py --download-model --data-dir "<控制台目录>"`
   - 用户拒绝：告知："后续可随时说'下载模型'来安装。"

4. **同步数据到数据库** — 执行 `python scripts/db_sync.py --direction to-db --data-dir "<控制台目录>"`，将控制台下的默认行为规则、云端同步的知识文件等全部写入数据库，建立检索索引。完成后告知用户："初始化全部完成，可以开始使用了。"

全部完成后，向用户总结当前状态：数据库、模型、云端同步、本地数据各是否就绪。

## 核心能力

| 维度 | 常规方案 | 本方案 | 改进 |
|------|---------|--------|------|
| 画像加载 | 全量profile.json(~2500t) | 轻量lite(~400t) | -84% |
| 知识检索 | 读整个文件(~1500t) | 精准段落(~400t) | -73% |
| 系列连续性 | 读前集全文(~320t/集) | 只读摘要(~60t/集) | -81% |
| 知识搜索 | 无（只能按目录浏览） | FTS5+向量混合检索 | 新增 |
| 语义匹配 | 无 | text2vec ONNX INT8 768维 | 新增(~98MB) |

## 任务目标
- 本 Skill 用于：生成高质量视频口播文案，通过SQLite+FTS5+向量检索实现精准知识调取和轻量画像加载
- 能力包含：讲师风格自学习、画像按需加载、知识库段落级检索、系列文案摘要连续性、FTS5+向量混合搜索
- 触发条件：用户需要撰写口播文案、学习/管理讲师风格、批量生产短视频脚本、生成系列连续口播、管理公共知识资料

## 工作区结构

```
控制台/
├── workspace.json           # 工作区配置（含知识库同步地址）
├── 讲师列表/{讲师}/
│   ├── profile.json         # 讲师画像
│   ├── 样本/                # 讲师样本文案
│   │   └── 样本_*.txt
│   └── 系列文案/            # 系列文案（纯正文，用户直接查看/编辑）
│       └── {系列名}/
│           ├── E01_春季养肝.txt
│           ├── E02_春季养脾.txt
│           └── ...
├── 知识库集/
│   ├── 公共/                ← 云端同步，只读（产品知识、认证、行为规则等）
│   │   ├── 产品目录/        ← 按产品名聚合，产品属性和背书放一起
│   │   │   └── {产品名}/
│   │   │       ├── 产品属性.txt
│   │   │       └── 产品背书.txt
│   │   ├── 企业文化/
│   │   └── 公共行为/
│   │       ├── 允许行为.json
│   │       └── 禁止行为.json
│   ├── 私有/                ← 本地管理，用户自由编辑（竞品分析、话术模板等）
│   │   └── {自定义分类}/
│   └── manifest.json        ← 本地版本记录
└── 回收站/                  # 已删除数据
```

文案.txt文件为纯正文，不带任何元数据头。摘要、hook_next等AI内部元数据仅存数据库。

**知识库优先级**：私有层 > 公共层。同名文件以私有层为准，云端同步不碰私有层。
**行为规则保存**：用户修改行为规则时自动写入私有层，云端更新公共层不会覆盖用户定制。

**核心原则**：
1. 数据库是查询层，文件是编辑层——用户可直接编辑txt，脚本同步到DB
2. 轻量加载——文案生成只加载必要字段，不读全量画像
3. 精准检索——知识库返回相关段落，不读整个文件
4. 安全删除——移入回收站+.meta.json，可精确恢复

## 操作步骤

### 自然语言指令映射

用户不会输入CLI命令，智能体需将自然语言翻译为对应操作：

| 用户说 | 智能体执行 |
|--------|-----------|
| **讲师管理** | |
| 学一下这个讲师的风格 / 帮我学习XX | `lecturer_analyzer.py --lecturer <名称> --text "<文案>"` → 构建画像 → `db_sync.py` 同步 |
| 我有哪些讲师 / 讲师列表 | `db_query.py --type lecturer --action list` |
| XX老师什么风格 / 看看XX老师的画像 | `db_query.py --type lecturer --action lite --id <名称>` |
| 把XX的口头禅改成YY / 修改XX的画像 | 编辑 profile.json → `db_sync.py --direction to-db` 同步 |
| 给XX加几篇新文案 / 增量学习 | `lecturer_analyzer.py --lecturer <名称> --merge --text "<文案>"` |
| XX的画像不要了 / 删除XX讲师 | 移入回收站 + .meta.json（见 workflow-lecturer.md） |
| 把XX恢复回来 / 恢复讲师 | 从回收站恢复（见 workflow-lecturer.md） |
| XX和YY有什么区别 / 对比讲师 | `db_query.py --type lecturer --action compare --id XX --id2 YY` |
| 把XX的数据发给我 / 导出讲师 | `lecturer_transfer.py --action export --lecturer XX --data-dir <目录> --output <输出目录>` |
| 导入讲师 / 把XX的数据加进来 | `lecturer_transfer.py --action import --source <讲师目录> --data-dir <目录> --sync` |
| **文案生成** | |
| 帮我写个口播 / 写篇文案 | `db_query.py --type context` 获取上下文 → 生成 → `db_sync.py` 同步 |
| 写个N集系列口播 / 写系列 | 见 workflow-copywriting.md |
| 继续写XX系列 | `db_query.py --type series --action summaries --id <系列名>` → 生成下一集 |
| XX系列写到哪了 / 系列进度 | `db_query.py --type series --action progress --id <系列名>` |
| 换个风格重写 | 见 workflow-copywriting.md |
| **知识库管理** | |
| 知识库里有什么 / 看看知识库 | `db_query.py --type fs --action knowledge --data-dir <目录>` |
| 看看有哪些讲师 / 讲师列表 | `db_query.py --type fs --action lecturers --data-dir <目录>` |
| 看看完整目录 / 所有文件 | `db_query.py --type fs --action tree --data-dir <目录>` |
| 把XX加到知识库 / 添加知识 | 创建文件到知识库集/私有/ → `db_sync.py --direction to-db` 同步 |
| 旧版资料不要了 / 删除知识 | 移入回收站 + .meta.json（见 workflow-knowledge.md） |
| **行为规则** | |
| 看看行为规则 / 禁止哪些词 | `db_query.py --type behavior --action list --data-dir <目录>` |
| 禁止用XX / 不允许出现XX | 读禁止行为.json → 不存在则add，已存在则告知 |
| 必须用XX / 一定要说XX | 读允许行为.json → 不存在则add，已存在则告知 |
| **云端同步** | |
| 同步知识库 / 更新知识库 | 检查 base_url 是否已配置 → `knowledge_sync.py --data-dir <目录>` |
| 配置知识库地址 / 同步地址改一下 | 编辑 workspace.json 的 knowledge_sync.base_url |
| 查看当前同步地址 | 读取 workspace.json 的 knowledge_sync.base_url |
| **系统操作** | |
| 初始化 / 刚开始用 / 第一次用 | 执行"首次使用引导"4个步骤 |
| 回收站清空吧 / 清理回收站 | 删除回收站内容（永久删除，不可恢复） |
| 数据存在哪里 / 查看数据目录 | 读取 workspace.json 的 data_dir 字段 |

### workspace.json 配置

知识库云端同步地址配置在 `控制台/workspace.json` 中：

```json
{
  "data_dir": "./控制台",
  "trash_dir": "./控制台/回收站",
  "version": "2.0",
  "knowledge_sync": {
    "base_url": "",
    "auto_sync": true
  }
}
```

- `base_url`：知识库云端根地址，初始为空。首次使用时智能体引导用户配置（见"首次使用引导"第2步）。manifest.json 自动拼接为 `base_url/manifest.json`，文件名不可改
- `auto_sync`：预留字段，控制是否在技能启动时自动同步

### 讲师管理
- 详细流程见 [references/workflow-lecturer.md](references/workflow-lecturer.md)
- 分析讲师风格：`python scripts/lecturer_analyzer.py --input <文件> --lecturer <名称>`
- 增量学习：追加 `--merge`
- 查看画像：`python scripts/db_query.py --type lecturer --action lite --id <名称>`

### 知识库管理
- 详细流程见 [references/workflow-knowledge.md](references/workflow-knowledge.md)
- 检索知识：`python scripts/db_query.py --type knowledge --action search --query "关键词"`
- 获取上下文：`python scripts/db_query.py --type knowledge --action context --query "主题" --max-tokens 1000`
- 批量导入：`python scripts/db_sync.py --direction to-db --data-dir <目录>`

### 知识库云端同步
- 同步配置在 `workspace.json` 的 `knowledge_sync` 字段中
- 执行同步：`python scripts/knowledge_sync.py --data-dir <目录>`
- 仅检查：`python scripts/knowledge_sync.py --data-dir <目录> --dry-run`
- 强制同步：`python scripts/knowledge_sync.py --data-dir <目录> --force`
- 生成manifest：`python scripts/knowledge_sync.py --data-dir <目录> --generate --version 1.0.0`（云端维护者用）
- 同步策略：远程版本 > 本地版本时才同步，增量下载（新增/修改），下线文件标记.offline不删除

### 文案生成
- 详细流程见 [references/workflow-copywriting.md](references/workflow-copywriting.md)
- 一键获取生成上下文：`python scripts/db_query.py --type context --action context --lecturer <名称> --query <主题> --data-dir <目录>`
- 系列进度：`python scripts/db_query.py --type series --action summaries --id <系列名>`
- 生成上下文自动包含行为规则（允许行为+禁止行为），无需单独加载

### 文件系统浏览
- 完整目录树：`python scripts/db_query.py --type fs --action tree --data-dir <目录>`
- 仅知识库集：`python scripts/db_query.py --type fs --action knowledge --data-dir <目录>`
- 仅讲师列表：`python scripts/db_query.py --type fs --action lecturers --data-dir <目录>`
- 目录不存在时返回 `exists: false`，不报错

### 行为规则管理
- 查看所有规则：`python scripts/db_query.py --type behavior --action list --data-dir <目录>`
- 添加允许规则：`python scripts/db_query.py --type behavior --action add --id R006 --query '{"id":"R006","category":"产品表述","pattern":"官方正品","usage":"强调正品保障","priority":2}' --data-dir <目录>`
- 添加禁止规则：`python scripts/db_query.py --type behavior --action add --id B010 --query '{"id":"B010","category":"虚假承诺","pattern":"永不复发","reason":"不可承诺不复发","replacement":"持续调理巩固","severity":"critical"}' --data-dir <目录>`
- 修改规则：`python scripts/db_query.py --type behavior --action update --id B010 --query '<新规则JSON>' --data-dir <目录>`
- 删除规则：`python scripts/db_query.py --type behavior --action remove --id R006 --data-dir <目录>`
- 自然语言更新：用户可直接说"禁止使用'根治'"或"添加必须说'产品A'"，智能体自动操作JSON文件
- 冲突优先级：**允许 > 禁止**。若禁止规则的pattern中有任何一个词与允许规则重叠，该条禁止规则整条被覆盖（原文不动，加载时自动过滤），返回结果中`overridden`字段列出被覆盖的规则及原因

### 数据同步
- 文件→数据库：`python scripts/db_sync.py --direction to-db --data-dir <目录>`
- 数据库→文件：`python scripts/db_sync.py --direction to-files --data-dir <目录>`

## 使用示例

### 示例1：学习讲师风格并写文案
- 用户："这是讲师B的5篇口播 [粘贴文案]"
- 步骤：lecturer_analyzer.py分析 → 智能体构建画像 → 写入DB → 用户说"用讲师B风格写个养生口播" → db_query获取上下文 → 生成文案
- 关键：`lecturer_analyzer.py --lecturer 讲师B --text "<文案>"`

### 示例2：知识库精准检索
- 用户："参考产品A的产品背书写个口播"
- 步骤：db_query搜索 → 返回相关段落(非整个文件) → 融入文案
- 关键：`db_query.py --type knowledge --action context --query "产品A 产品背书"`

### 示例3：系列文案连续性
- 用户："继续写AI系列第6集"
- 步骤：db_query获取前5集摘要(非全文) → 保证连续性 → 生成第6集 → 保存摘要到DB
- 关键：`db_query.py --type series --action summaries --id AI系列`

### 示例4：行为规则控制
- 用户："禁止文案里出现'治愈'"
- 步骤：智能体读取禁止行为.json → 发现已存在B001覆盖 → 告知用户
- 用户："添加一条：必须用'产品A'全称，不能简称"
- 步骤：智能体往允许行为.json追加规则R006 → 下次生成自动生效
- 关键：直接说自然语言即可，无需手动编辑JSON

## 资源索引
- 讲师管理流程：见 [references/workflow-lecturer.md](references/workflow-lecturer.md)
- 知识库管理流程：见 [references/workflow-knowledge.md](references/workflow-knowledge.md)
- 文案生成流程：见 [references/workflow-copywriting.md](references/workflow-copywriting.md)
- 画像格式规范：见 [references/profile-format.md](references/profile-format.md)（生成/验证画像时读取）
- 风格与文风参考：见 [references/script-styles.md](references/script-styles.md)（确认风格参数时读取）
- 模型配置：见 [assets/model_config.json](assets/model_config.json)（模型下载配置）
- 初始化脚本：[scripts/db_init.py](scripts/db_init.py)（首次初始化用 `--setup --parent-dir <存放位置>`，脚本强制创建"控制台"文件夹；下载模型用 `--download-model --data-dir <控制台目录>`）
- 查询脚本：[scripts/db_query.py](scripts/db_query.py)（讲师/知识/系列查询）
- 分析脚本：[scripts/lecturer_analyzer.py](scripts/lecturer_analyzer.py)（讲师风格分析+增量合并）
- 同步脚本：[scripts/db_sync.py](scripts/db_sync.py)（文件↔DB双向同步）
- 导入导出脚本：[scripts/lecturer_transfer.py](scripts/lecturer_transfer.py)（讲师跨用户迁移，含重名合并/覆盖、知识引用检测）

## 注意事项
- 首次使用必须运行 `db_init.py --setup --parent-dir <存放位置>` 初始化，脚本会在指定位置下强制创建"控制台"文件夹，不可用 `--data-dir` 替代
- 语义模型为可选，未安装时自动降级为纯FTS5检索，不影响核心功能
- 文件层可直接编辑（txt/json），编辑后运行 `db_sync.py --direction to-db` 同步
- 文案生成时使用 `--action lite` 加载轻量画像，管理时使用 `--action get` 加载完整画像
- 知识检索优先使用 `--action context` 获取token预算内的精准内容
- 系列文案连续性使用 `--action summaries` 获取摘要，不读全文
- 口播文案保持口语化，字数偏差不超过10%
- 画像增量合并采用加权策略，详见 profile-format.md
