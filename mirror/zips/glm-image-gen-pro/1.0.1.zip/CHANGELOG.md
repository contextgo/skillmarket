# Changelog / 更新日志

All notable changes to this project will be documented in this file.

## [1.1.0] - 2026-04-11

### Added / 新增
- **Video `--no-watermark` support** - 视频生成支持 `--no-watermark` 参数关闭水印
- **Video `--image-file` support** - 视频生成支持 `--image-file` 参数直接使用本地图片
- **README.md** - 新增商店展示用 README 文档
- **Output delivery rules** - 强制要求生成后直接发送文件给用户

### Changed / 优化
- **SKILL.md** - 完善去水印免责条款签署路径说明
- **SKILL.md** - 视频参数文档同步更新
- **脚本自动检测 API Key** - 支持从 `~/.workbuddy/api_keys.json` 读取配置

## [1.0.3] - 2026-03-26

### Added / 新增
- **Image generation** - 支持 glm-image、cogview-4、cogview-3-flash 模型
- **Video generation** - CogVideoX-2 模型支持文生视频和图生视频
- **HD quality mode** - 高清质量模式
- **Aspect ratio options** - 多种尺寸比例支持
- **Content safety filter** - 内容安全过滤

## [1.0.0] - 2026-03-20

### Added / 新增
- Initial release / 初始版本
- Basic image generation / 基础图片生成功能
