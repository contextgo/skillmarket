#!/usr/bin/env python3
"""
GLM Video Generation CLI - ZhiPu CogVideoX API client

Usage:
    python glm_video_cli.py generate --prompt "一只猫在草地上奔跑"
    python glm_video_cli.py generate --prompt "飞机在空中旋转" --image-url "https://example.com/image.png"
    python glm_video_cli.py query --task-id "xxx"

Requirements:
    pip install zhipuai

API Docs: https://docs.bigmodel.cn/cn/guide/models/video-generation/cogvideox-2
"""

import argparse
import json
import os
import sys
import time
import urllib.request

# Try to import zhipuai SDK
try:
    from zhipuai import ZhipuAI
    HAS_SDK = True
except ImportError:
    HAS_SDK = False


def load_zhipu_key() -> str:
    """Load Zhipu API key from config file or environment."""
    api_key = os.environ.get("ZHIPU_API_KEY")
    if api_key:
        return api_key
    
    config_path = os.path.join(os.path.expanduser("~"), ".workbuddy", "api_keys.json")
    if os.path.exists(config_path):
        try:
            with open(config_path, "r", encoding="utf-8") as f:
                config = json.load(f)
                if config.get("zhipu", {}).get("api_key"):
                    return config["zhipu"]["api_key"]
        except Exception:
            pass
    return None


def create_video(client: ZhipuAI, prompt: str, image_url: str = None, 
                 image_file: str = None, model: str = "cogvideox-2",
                 watermark_enabled: bool = True):
    """Create a video generation task.
    
    Supports either image_url (public URL) or image_file (local file path).
    Local files will be converted to base64 data URI.
    """
    kwargs = {"model": model, "prompt": prompt}
    
    if image_file:
        # Convert local image to base64 data URI
        import base64
        with open(image_file, "rb") as f:
            img_data = base64.b64encode(f.read()).decode("utf-8")
        # Detect image type from extension
        ext = os.path.splitext(image_file)[1].lower()
        if ext in [".jpg", ".jpeg"]:
            mime = "image/jpeg"
        elif ext == ".png":
            mime = "image/png"
        elif ext == ".webp":
            mime = "image/webp"
        else:
            mime = "image/jpeg"
        kwargs["image_url"] = f"data:{mime};base64,{img_data}"
    elif image_url:
        kwargs["image_url"] = image_url
    
    # Add watermark control if user wants to disable it
    if not watermark_enabled:
        kwargs["watermark_enabled"] = False
    
    response = client.videos.generations(**kwargs)
    return {
        "ok": True,
        "task_id": response.id,
        "task_status": response.task_status,
    }


def get_video_result(client: ZhipuAI, task_id: str):
    """Get video generation result by task ID."""
    response = client.videos.retrieve_videos_result(id=task_id)
    
    status = response.task_status
    video_url = None
    if status == "SUCCESS" and hasattr(response, "video_result") and response.video_result:
        video_url = response.video_result[0].url
    
    return {
        "ok": True,
        "task_id": task_id,
        "task_status": status,
        "video_url": video_url,
    }


def generate_video(client: ZhipuAI, prompt: str, image_url: str = None, image_file: str = None,
                   poll_interval: int = 30, max_wait: int = 600, watermark_enabled: bool = True):
    """
    Create video and poll for result.
    Returns dict with video_url on success.
    """
    # Create task
    result = create_video(client, prompt, image_url, image_file, watermark_enabled=watermark_enabled)
    task_id = result.get("task_id")
    print(f"Task created: {task_id}", flush=True)
    
    # Poll for result
    start_time = time.time()
    while time.time() - start_time < max_wait:
        status_result = get_video_result(client, task_id)
        status = status_result["task_status"]
        print(f"Status: {status}", flush=True)
        
        if status == "SUCCESS":
            return {
                "ok": True,
                "video_url": status_result["video_url"],
                "task_id": task_id,
            }
        elif status == "FAIL":
            return {"ok": False, "error": {"code": "GENERATION_FAILED", "message": "Video generation failed"}}
        
        time.sleep(poll_interval)
    
    return {"ok": False, "error": {"code": "TIMEOUT", "message": f"Timeout after {max_wait}s"}}


def download_video(url: str, save_path: str) -> bool:
    """Download video from URL to local file."""
    try:
        urllib.request.urlretrieve(url, save_path)
        return True
    except Exception:
        return False


def main():
    # Reconfigure stdout for UTF-8
    sys.stdout.reconfigure(encoding='utf-8')
    
    parser = argparse.ArgumentParser(description="Generate videos using ZhiPu CogVideoX API")
    
    if not HAS_SDK:
        print(json.dumps({
            "ok": False,
            "error": {
                "code": "MISSING_SDK",
                "message": "zhipuai SDK not installed. Run: pip install zhipuai"
            }
        }, ensure_ascii=False))
        sys.exit(1)
    
    subparsers = parser.add_subparsers(dest="command", help="Commands")
    
    # Create video
    create_parser = subparsers.add_parser("create", help="Create video generation task")
    create_parser.add_argument("-p", "--prompt", required=True, help="Video description")
    create_parser.add_argument("-i", "--image-url", help="Image URL for image-to-video")
    create_parser.add_argument("-f", "--image-file", help="Local image file for image-to-video")
    create_parser.add_argument("-m", "--model", default="cogvideox-2", help="Model name")
    create_parser.add_argument("--no-watermark", action="store_true", help="Disable watermark (requires signed disclaimer)")
    
    # Query result
    query_parser = subparsers.add_parser("query", help="Query video generation result")
    query_parser.add_argument("-t", "--task-id", required=True, help="Task ID to query")
    
    # Generate (create + wait)
    gen_parser = subparsers.add_parser("generate", help="Create and wait for video")
    gen_parser.add_argument("-p", "--prompt", required=True, help="Video description")
    gen_parser.add_argument("-i", "--image-url", help="Image URL for image-to-video")
    gen_parser.add_argument("-f", "--image-file", help="Local image file for image-to-video")
    gen_parser.add_argument("-s", "--save", help="Save video to local file")
    gen_parser.add_argument("--no-watermark", action="store_true", help="Disable watermark (requires signed disclaimer)")
    gen_parser.add_argument("--interval", type=int, default=30, help="Poll interval (seconds)")
    gen_parser.add_argument("--timeout", type=int, default=600, help="Max wait time (seconds)")
    
    args = parser.parse_args()
    
    # Get API key
    api_key = load_zhipu_key()
    if not api_key:
        print(json.dumps({
            "ok": False,
            "error": {
                "code": "MISSING_API_KEY",
                "message": "ZHIPU_API_KEY not configured. Add to api_keys.json or set environment variable."
            }
        }, ensure_ascii=False))
        sys.exit(1)
    
    client = ZhipuAI(api_key=api_key)
    
    if args.command == "create":
        watermark_enabled = not getattr(args, 'no_watermark', False)
        result = create_video(client, args.prompt, args.image_url, args.image_file, args.model, watermark_enabled)
        print(json.dumps(result, ensure_ascii=False))
    
    elif args.command == "query":
        result = get_video_result(client, args.task_id)
        print(json.dumps(result, ensure_ascii=False))
        if result["task_status"] == "SUCCESS":
            print(f"Video URL: {result['video_url']}")
    
    elif args.command == "generate":
        print(f"Generating video: {args.prompt}", flush=True)
        watermark_enabled = not getattr(args, 'no_watermark', False)
        result = generate_video(client, args.prompt, args.image_url, args.image_file,
                               args.interval, args.timeout, watermark_enabled)
        
        if result["ok"]:
            print(json.dumps({
                "ok": True,
                "video_url": result["video_url"],
                "task_id": result["task_id"],
            }, ensure_ascii=False))
            
            # Download if save path specified
            if args.save:
                print(f"Downloading to {args.save}...", flush=True)
                if download_video(result["video_url"], args.save):
                    print(json.dumps({
                        "ok": True,
                        "video_url": result["video_url"],
                        "saved_file": os.path.abspath(args.save),
                    }, ensure_ascii=False))
                else:
                    print(json.dumps({
                        "ok": True,
                        "video_url": result["video_url"],
                        "download_failed": True,
                    }, ensure_ascii=False))
        else:
            print(json.dumps(result, ensure_ascii=False))
            sys.exit(1)
    
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
