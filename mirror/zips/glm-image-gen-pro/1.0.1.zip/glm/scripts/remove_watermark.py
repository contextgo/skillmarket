#!/usr/bin/env python3
"""
Remove watermark from images using OpenCV inpaint algorithm.
Detects light-colored watermark text and intelligently fills the area.
"""

import argparse
import os
import sys
import numpy as np
import cv2
from PIL import Image


def is_watermark_pixel(r, g, b, brightness_threshold=180, saturation_threshold=30):
    """Detect if pixel is likely watermark text (light gray/white)."""
    r, g, b = int(r), int(g), int(b)
    brightness = (r + g + b) / 3.0
    max_c = max(r, g, b)
    min_c = min(r, g, b)
    saturation = 0.0 if max_c == 0 else (max_c - min_c) / 255.0
    return brightness > brightness_threshold and saturation < saturation_threshold / 255.0


def remove_watermark(input_path: str, output_path: str = None,
                     brightness_threshold: int = 180,
                     scan_width: int = 220,
                     scan_height: int = 60,
                     method: str = "telea") -> str:
    """
    Remove watermark using OpenCV inpaint (TELEA or NS algorithms).
    
    Args:
        input_path: Input image path
        output_path: Output image path
        brightness_threshold: Threshold for watermark detection (default: 180)
        scan_width: Width to scan from right edge (default: 220)
        scan_height: Height to scan from bottom (default: 60)
        method: "telea" (fast, good quality) or "ns" (Navier-Stokes, slower but often better)
    """
    if not os.path.exists(input_path):
        print(f"Error: File not found: {input_path}")
        sys.exit(1)
    
    # Read image with OpenCV
    img = cv2.imread(input_path)
    if img is None:
        print(f"Error: Could not read image: {input_path}")
        sys.exit(1)
    
    height, width = img.shape[:2]
    
    # Create mask for watermark region
    x1 = max(0, width - scan_width)
    y1 = max(0, height - scan_height)
    
    # Initialize mask (0 = keep, 255 = inpaint)
    mask = np.zeros((height, width), dtype=np.uint8)
    
    # Detect watermark pixels and add to mask
    for y in range(y1, height):
        for x in range(x1, width):
            b, g, r = img[y, x]
            if is_watermark_pixel(r, g, b, brightness_threshold):
                mask[y, x] = 255
    
    # Dilate mask slightly to ensure complete coverage
    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.dilate(mask, kernel, iterations=1)
    
    # Inpaint using selected method
    if method.lower() == "ns":
        result = cv2.inpaint(img, mask, 3, cv2.INPAINT_NS)
    else:
        result = cv2.inpaint(img, mask, 3, cv2.INPAINT_TELEA)
    
    # Generate output path
    if output_path is None:
        name, ext = os.path.splitext(input_path)
        output_path = f"{name}_nowm{ext}"
    
    # Save result
    cv2.imwrite(output_path, result)
    return output_path


def main():
    parser = argparse.ArgumentParser(description="Remove watermark using OpenCV inpaint")
    parser.add_argument("input", help="Input image path")
    parser.add_argument("-o", "--output", help="Output image path (optional)")
    parser.add_argument("-t", "--threshold", type=int, default=180,
                        help="Brightness threshold (default: 180)")
    parser.add_argument("-w", "--width", type=int, default=220,
                        help="Scan width from right (default: 220)")
    parser.add_argument("-H", "--height", type=int, default=60,
                        help="Scan height from bottom (default: 60)")
    parser.add_argument("-m", "--method", choices=["telea", "ns"], default="telea",
                        help="Inpaint method: telea (fast) or ns (often better)")
    
    args = parser.parse_args()
    
    output = remove_watermark(
        args.input, args.output,
        brightness_threshold=args.threshold,
        scan_width=args.width,
        scan_height=args.height,
        method=args.method
    )
    print(f"Watermark removed. Saved to: {output}")


if __name__ == "__main__":
    main()
