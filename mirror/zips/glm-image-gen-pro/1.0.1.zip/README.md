# 智谱AI 图片视频生成 Pro

基于智谱AI官方API的图片和视频生成工具。

## 功能特点

- **文生图**：支持 glm-image、cogview-4、cogview-3-flash 多模型
- **图生视频**：CogVideoX-2，6秒视频，0.5元/次
- **本地图片直传**：图生视频支持本地文件，无需先上传网络 ⭐
- **无水印**：签署免责条款后可关闭水印

## 快速开始

### 1. 配置API Key

```bash
export ZHIPU_API_KEY="你的智谱API密钥"
```

### 2. 生成图片

```bash
python scripts/glm_image_cli.py --prompt "一只橘猫在阳光下打哈欠" --save cat.png
```

### 3. 生成视频

```bash
# 文生视频
python scripts/glm_video_cli.py generate --prompt "小狗在草地上奔跑"

# 图生视频（本地图片）
python scripts/glm_video_cli.py generate --prompt "风吹动树叶" --image-file photo.jpg
```

## 定价

| 模型 | 价格 |
|------|------|
| glm-image | 0.1元/张 |
| cogview-4 | 0.5元/张 |
| cogview-3-flash | 0.05元/张 |
| CogVideoX-2 | 0.5元/次（6秒） |

新用户有免费额度。

## 无水印设置

1. 登录 [智谱AI开放平台](https://open.bigmodel.cn/)
2. 个人中心 → 安全管理 → 去水印管理
3. 签署免责条款

之后加上 `--no-watermark` 参数即可。

## API来源

本技能基于 [智谱AI开放平台](https://open.bigmodel.cn/) 的官方API开发。
