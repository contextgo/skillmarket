---
name: glm-image-gen-pro
description:
  基于智谱AI（GLM/CogVideoX）官方API的图片和视频生成技能。
  支持文生图、图生视频（本地图片直传）、无水印输出、高清质量。
  适用于AI绘图、短视频创作、商业素材生成等场景。
metadata:
  openclaw:
    requires:
      env:
        - ZHIPU_API_KEY
      bins:
        - python
    primaryEnv: ZHIPU_API_KEY
    emoji: "🎨"
---

# 智谱AI 图片视频生成 Pro

基于智谱AI官方API的增强版图片和视频生成工具。

## 核心能力

| 功能 | 说明 |
|------|------|
| **文生图** | glm-image / cogview-4 / cogview-3-flash 多模型可选 |
| **图生视频** | CogVideoX-2，6秒视频，支持本地图片直传 |
| **无水印** | 签署免责条款后可关闭水印 |
| **高清质量** | HD模式生成更精细的图片 |

## 前置配置

### 1. 获取API Key

访问 [智谱AI开放平台](https://open.bigmodel.cn/) → 个人中心 → API Keys

### 2. 配置Key

**方式一：环境变量**
```bash
export ZHIPU_API_KEY="你的密钥"
```

**方式二：配置文件**（位于 `~/.workbuddy/api_keys.json`）
```json
{
  "zhipu": {
    "api_key": "你的密钥"
  }
}
```

## 图片生成

### 基本用法

```bash
python scripts/glm_image_cli.py --prompt "一只橘猫在阳光下打哈欠" --save cat.png
```

### 指定尺寸

```bash
python scripts/glm_image_cli.py --prompt "赛博朋克城市夜景" --size 1728x960 --save cyberpunk.png
```

### 指定模型

| 模型 | 说明 | 价格 |
|------|------|------|
| glm-image | 默认模型，质量好 | 0.1元/张 |
| cogview-4 | 高质量，适合细节图 | 0.5元/张 |
| cogview-3-flash | 快速生成 | 0.05元/张 |

```bash
python scripts/glm_image_cli.py --prompt "..." --model cogview-4
```

### 无水印

**首次使用需签署免责条款：**
1. 登录 [智谱AI开放平台](https://open.bigmodel.cn/)
2. 个人中心 → 安全管理 → 去水印管理
3. 签署免责条款并完成实名认证

```bash
python scripts/glm_image_cli.py --prompt "商业设计素材" --no-watermark --save logo.png
```

## 视频生成

### 文生视频

```bash
python scripts/glm_video_cli.py generate --prompt "小狗在草地上快乐奔跑" --save video.mp4
```

### 图生视频（网络图片）

```bash
python scripts/glm_video_cli.py generate --prompt "风吹动树叶" --image-url "https://example.com/photo.jpg"
```

### 图生视频（本地图片）⭐

```bash
python scripts/glm_video_cli.py generate --prompt "竹筏缓缓前行" --image-file "photo.jpg"
```

> 本技能特色：支持直接传入本地图片，无需先上传到网络

### 无水印视频

```bash
python scripts/glm_video_cli.py generate --prompt "自然风光" --no-watermark --save video.mp4
```

## 参数说明

### 图片参数

| 参数 | 必填 | 说明 |
|------|:----:|------|
| `-p, --prompt` | ✅ | 图片描述 |
| `-m, --model` | | 模型：glm-image / cogview-4 / cogview-3-flash |
| `-s, --size` | | 尺寸，如 1280x1280 |
| `-q, --quality` | | 质量：hd（默认）/ standard |
| `--no-watermark` | | 关闭水印 |
| `--save` | | 保存路径 |

### 视频参数

| 参数 | 必填 | 说明 |
|------|:----:|------|
| `-p, --prompt` | ✅ | 视频描述 |
| `-i, --image-url` | | 网络图片URL |
| `-f, --image-file` | | 本地图片路径 |
| `--no-watermark` | | 关闭水印 |
| `-s, --save` | | 保存路径 |
| `--interval` | | 轮询间隔（默认30秒） |
| `--timeout` | | 最大等待（默认600秒） |

## 提示词技巧

### 推荐写法

- **具体细节**：`"一只橘色的英国短毛猫，绿色眼睛，坐在木质窗台上"`
- **风格关键词**：`"赛博朋克风格"`, `"中国水墨画"`, `"油画质感"`
- **光线描述**：`"阳光明媚"`, `"柔和逆光"`, `"电影感灯光"`
- **镜头语言**：`"特写镜头"`, `"广角视角"`, `"俯视角度"`

### 视频提示词

- **运镜**：`"缓慢推进"`, `"摇镜头"`, `"环绕拍摄"`
- **动作**：`"小狗奔跑"`, `"风吹动窗帘"`, `"水面泛起涟漪"`
- **氛围**：`"宁静悠闲"`, `"热闹欢快"`, `"神秘悬疑"`

## 输出规则

**重要**：生成完成后，必须：
1. 使用 `deliver_attachments` 工具直接发送文件给用户
2. 显示本地保存路径
3. 显示临时URL（如有）
4. 提醒用户及时保存

## 常见问题

### Q: 视频生成需要多久？
A: 通常60-90秒完成，可在智谱控制台查看进度。

### Q: 水印怎么彻底关闭？
A: 需在智谱开放平台签署免责条款，位置：个人中心 → 安全管理 → 去水印管理

### Q: 本地图片支持哪些格式？
A: 支持 JPG、PNG、WebP 格式。

## 错误处理

| 错误码 | 说明 | 解决 |
|--------|------|------|
| MISSING_API_KEY | 未配置Key | 配置 ZHIPU_API_KEY |
| RATE_LIMIT | 请求过于频繁 | 稍后再试 |
| CONTENT_FILTER | 内容审核未通过 | 修改提示词 |
| TIMEOUT | 视频生成超时 | 增加 --timeout |

## API文档

- [智谱AI开放平台](https://open.bigmodel.cn/)
- [图片生成API](https://docs.bigmodel.cn/)
- [视频生成API](https://docs.bigmodel.cn/)
