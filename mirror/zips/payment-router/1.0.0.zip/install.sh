#!/bin/bash
# 支付路由决策器 Skill 安装脚本
# Payment Router

set -e

SKILL_NAME="payment-router"
SKILL_DIR="$HOME/.openclaw/workspace/skills/$SKILL_NAME"

echo ""
echo "═══════════════════════════════════════════════════"
echo "  支付路由决策器 Skill"
echo "  Payment Router"
echo "═══════════════════════════════════════════════════"
echo ""
echo "  智能推荐最优支付方案"
echo ""
echo "═══════════════════════════════════════════════════"
echo ""

# 检查目录是否存在
if [ -d "$SKILL_DIR" ]; then
  echo "📁 Skill 目录已存在，正在更新..."
else
  echo "📁 创建 Skill 目录..."
  mkdir -p "$SKILL_DIR"
fi

# 复制文件
echo "📄 安装 SKILL.md..."
cat > "$SKILL_DIR/SKILL.md" << 'SKILL_EOF'
---
name: payment-router
display_name: 支付路由决策器
description: 智能推荐最优支付方案。基于业务场景、用户群体、费率、接入难度等因素，自动推荐最合适的支付渠道。
version: 1.0.0
author: 叶建国
homepage: https://github.com/openclaw/payment-router
tags:
  - 支付
  - 路由决策
  - 支付宝
  - 微信支付
  - 抖音支付
license: MIT
compatibility:
  - openclaw
  - skillhub
---

# 支付路由决策器

> 🧭 智能推荐 | 三大主流渠道 | 场景全覆盖 | 决策辅助

## 简介

支付路由决策器是一个智能支付方案推荐工具。

**适用场景**：当用户提到"用什么支付好"、"支付渠道选择"、"支付方案推荐"时使用此 Skill。

## 快速决策

| 场景 | 推荐排序 |
|------|----------|
| 电商购物 | 微信 > 支付宝 > 抖音 |
| 直播带货 | 抖音 > 支付宝 > 微信 |
| 线下门店 | 支付宝 > 微信 > 抖音 |
| App内支付 | 支付宝 > 微信 > 抖音 |
| 小程序 | 微信 > 支付宝 > 抖音 |

## 相关技能

- alipay-payment-integration
- wechat-pay-integration
- douyin-pay-integration

SKILL_EOF

echo ""
echo "═══════════════════════════════════════════════════"
echo "  ✅ 安装完成！"
echo "═══════════════════════════════════════════════════"
echo ""
echo "📚 使用说明："
echo ""
echo "  当用户提到以下关键词时自动触发："
echo "    - 用什么支付好"
echo "    - 支付渠道选择"
echo "    - 支付宝还是微信"
echo "    - 接入哪个支付"
echo "    - 支付方案推荐"
echo ""
echo "📖 完整文档请阅读："
echo "    $SKILL_DIR/SKILL.md"
echo ""
echo "═══════════════════════════════════════════════════"
