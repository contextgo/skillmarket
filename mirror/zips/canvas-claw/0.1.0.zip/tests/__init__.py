"""Tests for canvas-claw."""
