#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
attraction-ootd 数据采集脚本
使用 Tavily API 搜索：深圳天气 + 丝袜穿搭 + 当季流行趋势 + 男性心理学
输出结构化 JSON，供 Claude 生成最终穿搭推送
"""

import json
import os
import sys
from datetime import datetime

import requests

# Windows 下 stdout 重定向时默认用系统 ANSI 码页（cp936）写文件，
# 导致下游按 UTF-8 读全乱码。这里强制 stdout/stderr 为 UTF-8。
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
if hasattr(sys.stderr, "reconfigure"):
    sys.stderr.reconfigure(encoding="utf-8")

TAVILY_API_URL = "https://api.tavily.com/search"
CURRENT_YEAR = str(datetime.now().year)


def get_current_season():
    month = datetime.now().month
    if month in (3, 4, 5):
        return "春季"
    elif month in (6, 7, 8):
        return "夏季"
    elif month in (9, 10, 11):
        return "秋季"
    else:
        return "冬季"


SEASON = get_current_season()


def tavily_search(query, api_key, max_results=5, exclude_domains=None, include_domains=None):
    """调用 Tavily Search API"""
    payload = {
        "query": query,
        "api_key": api_key,
        "max_results": max_results,
        "search_depth": "basic",
        "include_answer": True,
    }
    if exclude_domains:
        payload["exclude_domains"] = exclude_domains
    if include_domains:
        payload["include_domains"] = include_domains
    try:
        resp = requests.post(TAVILY_API_URL, json=payload, timeout=30)
        resp.raise_for_status()
        data = resp.json()
        # 清洗结果中的特殊字符，防止后续 JSON 序列化出错
        if "answer" in data and data["answer"]:
            data["answer"] = _sanitize(data["answer"])
        for r in data.get("results", []):
            for field in ("title", "content", "url"):
                if field in r and r[field]:
                    r[field] = _sanitize(r[field])
        return data
    except Exception as e:
        return {"error": str(e), "query": query}


def _sanitize(text):
    """清洗文本中的控制字符和可能导致 JSON 解析失败的特殊字符"""
    if not text:
        return text
    # 移除控制字符（保留换行和制表符）
    cleaned = []
    for ch in text:
        code = ord(ch)
        if code < 32 and code not in (10, 13, 9):
            continue
        cleaned.append(ch)
    return "".join(cleaned)


def search_weather(api_key):
    """获取深圳天气，优先中文实时天气站，排除历史气候数据站"""
    today = datetime.now().strftime("%Y年%m月%d日")
    # 优先站：中国天气网 / 深圳气象局 / 墨迹 / 天气后报；排除历史气候统计站
    return tavily_search(
        f"深圳 {today} 今日实时天气预报 气温 湿度",
        api_key,
        max_results=5,
        exclude_domains=[
            "climate-data.org",
            "zh.climate-data.org",
            "weatherspark.com",
        ],
    )


def search_silk_stockings(api_key):
    """抓取丝袜穿搭内容，覆盖肉丝/黑丝/灰丝三种"""
    result = tavily_search(f"丝袜穿搭 {SEASON} {CURRENT_YEAR}", api_key, max_results=5)
    color_result = tavily_search("肉丝 黑丝 灰丝 穿搭区别 选择技巧", api_key, max_results=3)
    main_articles = result.get("results", [])
    color_articles = color_result.get("results", [])
    combined = main_articles + color_articles
    has_current_year = False
    for r in main_articles:
        if CURRENT_YEAR in r.get("title", "") or CURRENT_YEAR in r.get("content", ""):
            has_current_year = True
            break
    if not has_current_year:
        result_fallback = tavily_search(f"丝袜穿搭 {SEASON}", api_key, max_results=5)
        if result_fallback.get("results"):
            combined = result_fallback.get("results", []) + color_articles
    result["results"] = combined
    answer_parts = []
    if result.get("answer"):
        answer_parts.append(result["answer"])
    if color_result.get("answer"):
        answer_parts.append(color_result["answer"])
    result["answer"] = " ".join(answer_parts)
    return result


def search_fashion_trends(api_key):
    """搜索当季流行趋势"""
    return tavily_search(f"{CURRENT_YEAR} {SEASON} 女装流行趋势 流行单品", api_key, max_results=5)


def search_psychology(api_key):
    """搜索男性心理学引用，包含丝袜控/丝袜癖心理。排除电商/种草，避免抓到商品页。"""
    # 排除电商与测评种草站，优先学术/知识/书评内容
    exclude = [
        "taobao.com", "tmall.com", "jd.com", "1688.com",
        "pinduoduo.com", "alibaba.com",
        "smzdm.com", "xiaohongshu.com",
    ]
    result1 = tavily_search(
        "男性视觉吸引力 心理学 研究 书籍 原文摘录",
        api_key, max_results=5, exclude_domains=exclude,
    )
    result2 = tavily_search(
        "丝袜控 恋物 心理学 研究 文献",
        api_key, max_results=5, exclude_domains=exclude,
    )
    combined_refs = result1.get("results", []) + result2.get("results", [])
    answer_parts = []
    if result1.get("answer"):
        answer_parts.append(result1["answer"])
    if result2.get("answer"):
        answer_parts.append(result2["answer"])
    if result1.get("error"):
        return result1
    result1["results"] = combined_refs
    result1["answer"] = " ".join(answer_parts)
    return result1


def extract_weather_info(data):
    """从搜索结果中提取天气信息"""
    answer = data.get("answer", "")
    results = data.get("results", [])
    sources = []
    for r in results[:2]:
        sources.append({
            "title": r.get("title", ""),
            "content": r.get("content", "")[:200],
            "url": r.get("url", ""),
        })
    return {"answer": answer, "sources": sources}


def extract_silk_info(data):
    """从搜索结果中提取丝袜穿搭信息"""
    answer = data.get("answer", "")
    results = data.get("results", [])
    articles = []
    for r in results[:3]:
        articles.append({
            "title": r.get("title", ""),
            "content": r.get("content", "")[:300],
            "url": r.get("url", ""),
        })
    return {"answer": answer, "articles": articles}


def extract_trends_info(data):
    """从搜索结果中提取流行趋势信息"""
    answer = data.get("answer", "")
    results = data.get("results", [])
    trends = []
    for r in results[:3]:
        trends.append({
            "title": r.get("title", ""),
            "content": r.get("content", "")[:300],
            "url": r.get("url", ""),
        })
    return {"answer": answer, "trends": trends}


def extract_psychology_info(data):
    """从搜索结果中提取心理学引用"""
    answer = data.get("answer", "")
    results = data.get("results", [])
    refs = []
    for r in results[:2]:
        refs.append({
            "title": r.get("title", ""),
            "content": r.get("content", "")[:300],
            "url": r.get("url", ""),
        })
    return {"answer": answer, "refs": refs}


def main():
    api_key = os.environ.get("TAVILY_API_KEY", "")
    if not api_key:
        print(json.dumps({
            "error": "缺少 TAVILY_API_KEY 环境变量，请设置后重试",
            "hint": "export TAVILY_API_KEY=your_key_here"
        }, ensure_ascii=False, indent=2))
        sys.exit(1)

    print(f"正在搜索：深圳天气 / 丝袜穿搭{SEASON} / {CURRENT_YEAR}{SEASON}流行趋势 / 男性心理学引用...", file=sys.stderr)

    weather_data = search_weather(api_key)
    silk_data = search_silk_stockings(api_key)
    trends_data = search_fashion_trends(api_key)
    psych_data = search_psychology(api_key)

    output = {
        "date": datetime.now().strftime("%Y-%m-%d"),
        "season": SEASON,
        "year": CURRENT_YEAR,
        "weather": extract_weather_info(weather_data),
        "silk_stockings": extract_silk_info(silk_data),
        "fashion_trends": extract_trends_info(trends_data),
        "psychology": extract_psychology_info(psych_data),
    }

    errors = []
    if weather_data.get("error"):
        errors.append(f"天气搜索失败: {weather_data['error']}")
    if silk_data.get("error"):
        errors.append(f"丝袜搜索失败: {silk_data['error']}")
    if trends_data.get("error"):
        errors.append(f"流行趋势搜索失败: {trends_data['error']}")
    if psych_data.get("error"):
        errors.append(f"心理学搜索失败: {psych_data['error']}")
    if errors:
        output["errors"] = errors

    print(json.dumps(output, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
