# Wiki（速查）

知识库树、路径门禁、`outputs`/`log.md` 托管与摄入/查询/反馈工作流：**Read** `{baseDir}/skills/wiki-maintainer/SKILL.md`。`/gen`～`/val` 细则：**Read** `{baseDir}/skills/sql-generator/SKILL.md`。

要点：**`{{WIKI_ROOT}}` 未设置且无法推断时，须请用户选择知识库根并确认后再访问**；确认后若缺 **`raw/`、`wiki/`、`outputs/`**，按 **`references/exec-runbook.md` §0.1** 引导脚手架（须用户同意后再写入）。取数前须按 **§0.3** 引导：**向 `raw/` 投放资料 → `/ingest`**，再让用户继续 SQL 流程。未显式授权**不写** `wiki/` 内除脚手架占位文件以外的实质内容（概念文、`tabledetail.md` 等）；`/gen` `/mod` 主流程与审查拦截以同捆 **`sql-generator`** 为准，并须经过同捆 **`sql-review-controller`**；`outputs/` 与 `wiki/log.md` 行模板见 **`wiki-maintainer` §3**。
