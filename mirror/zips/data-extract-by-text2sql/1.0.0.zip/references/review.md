# 审查（速查）

全文、六步工作流与 JSON：**Read** `{baseDir}/skills/sql-review-controller/SKILL.md`。

`route` 常见值：`direct_sql` | `review_form` | `blocking_prompt` | `final_result` | `error`。对外展示 **`final_sql`** 前必须经过此处或等价流程。
