# 执行手册（`data-extract` 包内，与 `skills/` 同捆）

执行任何子步骤前，**先完成** `{baseDir}/references/router.md` 中的 `RouterInput` / `RouterDecision`，并在步骤结束后**再输出**下一轮路由。

---

## 0. 根路径（先于 A～D）

| 根 | 规则 |
|----|------|
| **`{{WIKI_ROOT}}`** | 若项目配置/环境变量/对话上下文中**均未**给出可解析的知识库根，**停止**依赖知识库的读写，向用户说明需要**手动选择**根目录（建议绝对路径），待用户**明确确认**后再进入 D 或依赖 KB 的 B 步。用户已确认根但磁盘上**尚无**约定子目录时，按 **§0.1** 引导脚手架（须用户同意后再写入）。 |

### 0.1 知识库冷启动（`{{WIKI_ROOT}}` 脚手架）

在用户**已书面确认** `{{WIKI_ROOT}}` 后、进入依赖 `wiki/` 的 B/D 步之前，若下列目录**尚不存在**，应在对话中**主动说明用途并询问是否创建**（仅当用户明确同意后再用 **Write** 创建文件/目录）：

| 路径（均相对于 `{{WIKI_ROOT}}`） | 用途 |
|----------------------------------|------|
| **`raw/`** | 原始资料真理源（`.sql`、表格、文档等），供 `/ingest` 与口径追溯。 |
| **`wiki/`** | Markdown 知识库（概念文、`tabledetail.md`、`few-shot/` 等）。 |
| **`outputs/`** | 按用户需求生成的 SQL 存档，**非**权威口径来源。 |

**推荐一并说明的可选子目录**（可空目录，便于后续扩展）：`wiki/references/`（字典与参考片段）、`wiki/few-shot/`（范例 SQL）。

**最小可读写引导**（用户同意创建文件时）：在 `wiki/` 下放置极简 **`index.md`**（一行说明「待补充索引，请 `/ingest` 或手工维护」或按 `wiki-maintainer` 索引格式先建占位）与 **`log.md`**（首条可为 `## [日期] init | 知识库脚手架初始化`）。**`tabledetail.md` / 概念文**不要求一步写满；无表字典时 SQL 链将依赖 **KB 闸**与用户补充材料（见 `sql-generator`）。

### 0.3 Raw→Wiki 就绪闸（强制截断，先于 B3）

在 **`{{WIKI_ROOT}}` 已确认**且 **§0.1** 三目录已存在（或刚建好）之后，凡用户意图为 **`/gen`** 或等价「生成可执行取数 SQL」、且依赖团队知识库口径时，**必须先**满足下面两段；**未满足则截断**：不得进入 **B3**（撰写 `initial_sql`），不得将猜测表字段的 SQL 当作合规交付；仅允许输出**引导清单**、路由到 **`wiki-maintainer` 摄入模式**，或等用户完成后再回到路由 **A**。

| 阶段 | 条件（须同时满足，除非下方「豁免」） | 未满足时的交付 |
|------|----------------------------------------|----------------|
| **① Raw 投放** | `{{WIKI_ROOT}}/raw/` 下已有**用户准备**的可摄入资料（如建表/导数 SQL、`.csv`、字典 `.md`、字段说明等），**或**用户当次对话**完整粘贴**等价资料并声明纳入本轮依据。 | 说明应向 `raw/` 放入哪些类型文件、给出示例命名；提示勿在空 `raw/` 上直接要生产 SQL。 |
| **② Wiki 编译** | 已执行 **`/ingest`**（或经用户授权的等价手工更新），且 **`wiki/tabledetail.md`**（及 `wiki/index.md` 等导航）**已反映**本次取数所需表/字段的可检索条目。 | 明确要求先 **`/ingest`** 指定 `raw/` 文件（见 `wiki-maintainer` 摄入模式）；未完成前 **停止** SQL 生成主链。 |

**豁免（与 KB 闸一致）**：若用户**当次对话**书面提供的表结构/枚举/`DESCRIBE` 输出**已**被 KB 闸认定为足够写 `initial_sql`，可在回复中**显式注明**「§0.3 以对话材料替代 raw 文件」，再进入 B3；**不得**在既无 `raw/` 资料又无当次书面结构时静默豁免。

**与 KB 闸的关系**：§0.3 管「有没有经过 **raw→wiki 编译** 这一组织过程」；`sql-generator` 的 **KB 闸**管「证据是否够写这条 SQL」。两道闸**都通过**才进入 B3。

---

## A. 路由（每轮任务入口）

1. **Read** `{baseDir}/skills/skill-router/SKILL.md`（全文或至少「何时必须启用」「输入输出」「反模式」）。  
2. 按该文件输出 **`RouterInput` + `RouterDecision`**：`next_skill` 只填一个；`reinvoke_router_after` 在 SQL / 知识库链未结束时多为 `true`。  
3. 按 `RouterDecision` 的 `next_skill` 进入下方 **B～D** 之一；执行完子技能后回到步骤 1。

---

## B. 自然语言取数（SQL）

**Read** `{baseDir}/skills/sql-generator/SKILL.md`。须依次满足：**§0** 路径确认 → **§0.1** 脚手架（若缺）→ **§0.3 Raw→Wiki 就绪闸** → 再进入 **B3** 及以后。若刚完成 **§0.1** 仅有空树：先执行 **§0.3**，**截断**至引导用户填充 **`raw/`** 并 **`/ingest`**；**KB 闸**（`sql-generator`）在证据不足时同样只交 `kb_gaps` + `required_input`。

| 顺序 | 动作 |
|:---:|------|
| B1 | 意图归类：`/gen` `/mod` `/exp` `/val`（见该文「0) 意图路由」）。 |
| B2 | `/gen`：确认参数 → 按该文约定读取知识库下索引、字典、概念文、Few-shot 等 → **资料闸**（该文「需求要素审查」）→ 不过闸则只交 `kb_gaps` + `required_input`。 |
| B3 | 写 `initial_sql` + 生成前自检清单。 |
| B4 | **Read** `{baseDir}/skills/sql-review-controller/SKILL.md`，按其中 **标准工作流 6 步** 与 **输入/输出 JSON 协议** 处理；仅 JSON 输出规则以该文为准。 |
| B5 | 按 `route`：`direct_sql` / `final_result` → 对外给 `final_sql`；`review_form` → 展示表单，用户**单次**回复后再次走 B4；`blocking_prompt` → 不交可执行终稿。 |
| B6 | 安全启发式检查、`trace_id` 元数据、询问是否写入产物目录（格式见 `sql-generator` 与 `wiki-maintainer` 相关章节）。 |

`/mod`：读用户 SQL → 改 `initial_sql` → 从 B4 起同审查链。`/exp`、`/val`：按 `sql-generator` 对应小节，**不**产出新的 `final_sql`（除非审查链另有约定）。

---

## C. SQL 审查（单独被路由到时）

若主流程未内置带跑审查、用户只要审查：**Read** `{baseDir}/skills/sql-review-controller/SKILL.md`，从「标准工作流」第 1 步起执行，严格 **仅输出 JSON**（除非宿主约定双模式）。

---

## D. 知识库（Markdown）

**Read** `{baseDir}/skills/wiki-maintainer/SKILL.md`。

| 顺序 | 动作 |
|:---:|------|
| D1 | 确认 `{{WIKI_ROOT}}`：有配置则用；**无则请用户选择知识库根并确认**，未确认前不写 `wiki/`。根已确认但缺 `raw/`、`wiki/`、`outputs/` 时，按 **§0.1** 引导脚手架。 |
| D1b | 若用户下一步要取数：在 **§0.3** 未通过前，优先引导 **`raw/` 投放** → **`/ingest`（wiki 编译）**，再回到路由或 B 步。 |
| D2 | 按意图进入：摄入、查询、SQL 工程、反馈学习等（见该文工作流章节）。 |
| D3 | SQL 工程下 **`/gen` `/mod`**：主流程与审查拦截以同捆 **`skills/sql-generator/SKILL.md`** 为准；`initial_sql` 终审协议以 **`skills/sql-review-controller/SKILL.md`** 为准。 |
| D4 | 写入类操作遵守该文「更新门禁」：未显式授权不改知识库树内文件。 |
| D5 | 变更日志行格式见该文审查交接与摄入相关小节。 |

---

## `RouterDecision.next_skill` 与 Read 路径（建议）

| next_skill 取值 | 对应 Read |
|-----------------|-----------|
| `sql-generator` | `skills/sql-generator/SKILL.md` |
| `sql-review-controller` | `skills/sql-review-controller/SKILL.md` |
| `wiki-maintainer` | `skills/wiki-maintainer/SKILL.md` |
| `skill-router` | 再次路由（少用；避免套娃） |

若宿主将本包注册为单一技能名，仍通过 **Read 上表相对路径** 加载子文档；`next_skill` 可填子技能逻辑名以便审计。

**可选**：流程复盘或接入新团队时，可 Read `{baseDir}/references/improvement-loop.md` 做泛化自检（非强制步骤）。
