# KB 闸（速查）

全文与检查单：**Read** `{baseDir}/skills/sql-generator/SKILL.md` 中「需求要素审查（KB 闸，强制）」。

要点：写 **`initial_sql`** 前须先满足 **`references/exec-runbook.md` §0.3**（**`raw/`** 有料且已 **`/ingest`** 编译进 **`tabledetail.md`** 等，或 §0.3 豁免），再列要素并对照 `wiki/` 与 `wiki/references/`；硬缺口则只交 **`kb_gaps` + `required_input`**，不写可执行 SQL。与 **`sql-review-controller`** 分工：先 **raw→wiki 组织过程**，再 **KB 资料**，后 **语义审查**。
