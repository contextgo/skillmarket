# 路由（速查）

完整规则与决策树：**Read** `{baseDir}/skills/skill-router/SKILL.md`。

每次 **RouterInput / RouterDecision** 须含：`user_goal`、`phase`、`state`（`done_steps` / `artifacts`）、`last_skill`、`last_skill_result_summary`；`RouterDecision` 须含唯一 `next_skill`、`handoff_brief`、`reinvoke_router_after`。

**刷新时机**：换阶段、改需求、调工具/写文件、审查返回后、写 wiki 前——见 `{baseDir}/references/exec-runbook.md` §A。
