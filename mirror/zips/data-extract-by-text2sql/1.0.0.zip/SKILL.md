---
name: data-extract
version: 1.0.0
description: >-
  可搬迁的取数与知识协作技能包：元路由后串行执行 NL SQL 生成/修改、资料闸、语义审查 JSON 闭环，以及 Markdown 知识库（raw→ingest→wiki，含 §0.3 就绪闸）。
  缺路径或缺 raw/编译证据时截断引导，不臆造生产 SQL；{{WIKI_ROOT}} 与 {{SQL_ENGINE}} 由宿主配置，正文不绑厂商与地域。不含长期记忆（请单独安装 memory 包）。安装后按本 SKILL Read references/ 与 skills/。
---

# data-extract（同捆技能包）

本目录为**可搬迁的技能包**：根目录 `SKILL.md` 为总控；**`skills/`** 下为子技能正文（名称见下表）。执行时**必须 Read 对应文件**，不要凭对话记忆冒充已读。

**对外分发**：若将本包提供给组织外或公共注册表，请先按贵司规范**审查、删减或替换** `skills/` 内可能带有示例业务口径、表名样例或内部路径的段落；总控层已避免写入具体环境路径。

## 安装（泛化）

1. 将本文件夹整体放入宿主文档规定的 **Agent/IDE 技能目录**（具体路径以宿主说明为准，本文件不绑定某一产品安装位）。  
2. 保持 **`skills/`** 目录树相对位置不变；子技能之间的依赖已指向同捆相对路径 **`skills/sql-review-controller/SKILL.md`**。  
3. **`{{WIKI_ROOT}}`**（知识库根）不在本包内。若宿主**未**在配置或环境变量中设定、且当前工作区也无法唯一推断时：**必须先请用户手动选择**知识库根目录（建议给绝对路径），用户**书面确认**后再读写；确认前对知识库树**只读或不访问**。  
4. **冷启动脚手架（推荐）**：用户确认 `{{WIKI_ROOT}}` 后，若磁盘上尚不存在约定子树，应在流程中**主动说明并协助创建**（须用户同意后再 **Write** 落盘）——见 `references/exec-runbook.md` **§0.1**。

## 总执行顺序（每次用户任务）

| # | 做什么 |
|---|--------|
| 1 | **Read** `{baseDir}/references/exec-runbook.md`，按 **A～D** 节执行。 |
| 2 | **Read** `{baseDir}/skills/skill-router/SKILL.md`，输出 `RouterInput` / `RouterDecision`。 |
| 3 | 按 `next_skill`：**Read** `skills/<name>/SKILL.md`（路径相对本包根），严格按该文执行；SQL 主链须覆盖 **sql-generator → sql-review-controller**。 |
| 4 | 子技能结束后更新 `state`，回到步骤 2，直到 `next_skill: none` 且可交付。 |

**冷启动**：依赖 `{{WIKI_ROOT}}` 的步骤前，若目录不存在，按 `references/exec-runbook.md` **§0.1** 引导创建。取数 SQL（**`/gen`**）在路径就绪后还须通过 **§0.3**：**先填充 `raw/` → `/ingest`（wiki 编译）**，再进入 **B** 的 `initial_sql` 步骤。

## 子能力入口

| 能力 | 打开 |
|------|------|
| 路由 | `{baseDir}/skills/skill-router/SKILL.md` |
| 写 SQL / 资料闸 | `{baseDir}/skills/sql-generator/SKILL.md` |
| 审查 JSON | `{baseDir}/skills/sql-review-controller/SKILL.md` |
| 知识库 | `{baseDir}/skills/wiki-maintainer/SKILL.md` |

## 补充材料

| 文件 | 用途 |
|------|------|
| `{baseDir}/references/exec-runbook.md` | 逐步执行表（A～D） |
| `{baseDir}/references/router.md` | 路由字段速查 |
| `{baseDir}/references/kb-gate.md` | 资料闸速查 |
| `{baseDir}/references/review.md` | 审查路由速查 |
| `{baseDir}/references/wiki.md` | 知识库门禁速查 |
| `{baseDir}/references/improvement-loop.md` | 持续改进与闭环自检（泛化，可选） |

## 占位符

- **`{{WIKI_ROOT}}`**：知识库根（含 `wiki/`、`raw/`、`outputs/` 等约定子树）。**未设置且无法从上下文唯一确定时**：请用户选择路径（绝对路径或相对工作区根）并确认后再继续。  
- **`{{SQL_ENGINE}}`**：目标数仓引擎标识，由项目配置，本总控不举例具体品牌。

## 与独立记忆包的关系

需要「双层记忆」写入与检索链时，请单独安装同仓库 **`data-analysis/memory/`** 技能目录（根为 `SKILL.md`，`name: double-layer-memory`）。**本包总控与执行手册不包含记忆环节**，也不在路由表中挂载该技能。
