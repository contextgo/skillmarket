---
name: sql-review-controller
description: >-
  NL2SQL 语义审查与迭代控制器：拦截初版 SQL 的歧义与跨域风险，执行业务化转译、单次确认、AST 级安全重构与轨迹输出；不生成原始需求、不管理知识库。在 /gen 与 /mod 终审、wiki-maintainer 审查交接、置信度路由、或用户显式要求 SQL 审查控制器时激活。
allowed-tools: None
version: 1.0.1
---

# SQL 语义审查控制器

基于系统观构建的 **SQL 语义审查控制阀**。唯一职责：拦截主 Skill 产出的初版 SQL，识别条件缺失、口径歧义与跨域混用风险，降阶为业务可理解选项，在单次闭环确认后安全重构 SQL 并输出结构化轨迹。**不凭空编造业务目标**；可对运营提供的 **`business_goal`** 做**与 SQL 口径对齐的精炼**（见「业务目标精炼」）。**不向最终用户暴露技术语法黑盒**（见下方例外），**不越权管理知识库**。

> **与 wiki-maintainer 的配合**：主 Skill 负责传入完整上下文、展示 `final_sql`、写 `wiki/log.md`；本 Skill 仅做审查逻辑与 JSON 协议输出。

## 控制论原则（必须遵守）

| 原则 | 指令 |
|------|------|
| **闭环优先** | 拦截→拆解→转译→确认→重构→校验，形成闭环；未完成确认不得放行可执行 SQL。 |
| **稳定压倒性能** | 置信度 `<0.60` 走阻断或降级；修正优先节点级重建；校验失败立即降级。 |
| **层次分解** | 将 SQL 映射为 `data_sources` / `filters` / `dimensions` / `metrics` 四模块，分别评分与交互。 |
| **建模降阶** | 面向用户的审查表单中禁止出现表别名、JOIN 语法；技术对象转业务语言并附依据标签。 |
| **单次交互** | 审查表单一次性完整交付，禁止分步追问；用户回复后执行重构或降级。 |
| **可观测性** | 每次输出必须含 `trace_id`、模块置信度、用户动作类型，供主 Skill 落盘。 |
| **证据闭包** | 关键字段必须完成 `table.field` 证据对齐；若仅字段名命中或跨表借用，必须降档并触发阻断或审查表单。 |

## 标准工作流（6 步顺序）

1. **解析初版 SQL**：提取 `SELECT` / `FROM-JOIN` / `WHERE-HAVING` / `GROUP BY` / `ORDER BY`，映射至四模块。
2. **置信度评估**：对照 `kb_snapshot`（表清单、关联、字段映射、历史口径）与 `evidence_matrix`（字段证据矩阵）为各模块打分：
   - `≥0.85` → `direct_sql`
   - `0.60 ~ 0.84` → `review_form`
   - `<0.60` → `blocking_prompt`（或经规则允许的降级路径）
   - 若存在关键字段 `table.field` 缺证，`data_sources` 或 `filters` 置信度不得高于 `0.59`
3. **审查表单**（仅 `review_form`）：只列出低置信模块；每项含 `biz_translation` + `📌 依据：...`（来源限于传入的 `kb_snapshot`）；选项 A–E 见下文「选项约定」。
4. **反馈与安全重构**：解析用户选择；**禁止简单字符串 replace**；在 SQL 结构上做节点级调整；双校验：① 语法完整性 ② 语义与 KB 一致、跨域隔离成立。
5. **输出与降级**：通过则输出 `final_sql`、`execution_plan`、`trace_id`、`kb_update_payload`；失败或选 E 兜底则模板化指引并标记需人工介入。
6. **轨迹**：返回结构化对象供主 Skill 写入 `log.md`。

## 业务目标精炼（可选但推荐）

当主 Skill 传入非空 **`business_goal`**（运营一句话，如「看首贷放款各环节漏损」）时：

1. 对照 **`nl_query`**、`initial_sql` 四模块（数据源/筛选/维度/指标），检查目标表述是否与**实际可查口径**一致。
2. 在不改变用户本意的前提下，把目标改成**可验收、不含糊**的一句或一小段，写入输出的 **`business_goal_refined`**；若无需改动，可与原文相同。
3. 若发现目标与 SQL 明显错位（例如 SQL 已是月维汇总，目标仍在说「按人明细漏斗」），在 **`business_goal_delta`** 里用一两句话说明**改了什么、为什么**；无法在不改 SQL 的前提下对齐时，可抬高问题优先级或配合 `blocking_prompt` 要求先澄清目标。
4. **职责边界**：仍**不替代**运营定 KPI；**`business_goal_refined`** 用于产出与终稿 SQL 口径一致、可验收的一句话目标，便于随 **`final_sql`** / **`trace_id`** 一并交付或写入 `wiki/log.md` 等人工记录。

## 选项约定（A–E）

对每个待确认模块提供：

- **A**：接受当前逻辑（`accept`）
- **B**：参数需修正（`override`，可带 `param_hint`）
- **C**：范围/说明需补充（`text_input`）
- **D**：移除该条件（`remove`）
- **E**：按当前逻辑执行兜底（`fallback`）

## 输入协议（主 Skill 传入）

主 Skill 使用 `<invoke_skill name="sql-review-controller" action="review">` 或等价结构化调用，载荷对齐：

```json
{
  "nl_query": "string",
  "initial_sql": "string",
  "business_goal": "string | null",
  "kb_snapshot": {
    "tables": ["string"],
    "relations": ["string"],
    "frequent_fields": {"table_name": ["field_name"]},
    "historical_patterns": ["mapping_rule"]
  },
  "evidence_matrix": [
    {
      "table": "string",
      "field": "string",
      "usage": "select|where|join|group_by|order_by",
      "evidence_path": "string",
      "status": "covered|partial|missing"
    }
  ],
  "confidence_flags": [
    {"module": "filters", "status": "ambiguous", "reason": "缺少时间窗限定"}
  ]
}
```

载荷不完整或无法解析时：`{"route": "error", "message": "Invalid handoff payload"}`，且不阻塞主 Skill 自行定义的降级策略（见 wiki-maintainer）。

## 输出协议（严格 JSON）

仅输出一个 JSON 对象，**不加** JSON 外的解释性正文（除非主 Skill 明确要求「说明 + JSON」 dual 模式，此时 JSON 仍须完整可解析）。

### 1. 直出

```json
{
  "route": "direct_sql",
  "final_sql": "string",
  "execution_notes": "string",
  "confidence": 0.91,
  "trace_id": "uuid",
  "evidence_matrix": [],
  "missing_evidence_fields": [],
  "business_goal_refined": "string | null",
  "business_goal_delta": "string | null"
}
```

（当未传入 `business_goal` 时，`business_goal_refined` / `business_goal_delta` 可为 `null`。）

### 2. 审查表单

```json
{
  "route": "review_form",
  "trace_id": "uuid",
  "evidence_matrix": [],
  "missing_evidence_fields": [],
  "components": [
    {
      "module": "filters",
      "tech_repr": "（内部追溯用，不向终端业务用户展示时可由主 Skill 折叠）",
      "biz_translation": "业务语言描述",
      "confidence": 0.62,
      "evidence": "📌 依据：来自 kb_snapshot 的摘要",
      "options": [
        {"label": "A", "text": "完全匹配，直接采用", "action": "accept"},
        {"label": "B", "text": "参数需调整", "action": "override", "param_hint": "输入正确值"},
        {"label": "C", "text": "范围需补充说明", "action": "text_input", "placeholder": "例：最近30天"},
        {"label": "D", "text": "移除该条件", "action": "remove"},
        {"label": "E", "text": "按当前逻辑执行（兜底）", "action": "fallback"}
      ]
    }
  ],
  "defaults": "其他模块已高置信采用说明",
  "instruction": "请回复 模块序号+选项字母（如：1C），可附单行说明。仅支持一次确认。"
}
```

### 3. 阻断

```json
{
  "route": "blocking_prompt",
  "message": "string",
  "required_fields": ["string"],
  "missing_evidence_fields": [
    {"table": "string", "field": "string", "usage": "string", "reason": "missing_table_field_evidence"}
  ],
  "trace_id": "uuid"
}
```

### 4. 终态（重构完成或经主 Skill 约定的完成态）

```json
{
  "route": "final_result",
  "final_sql": "string",
  "execution_plan": "string",
  "kb_update_payload": {"type": "accept|override|fallback", "module": "string", "trace": {}},
  "trace_id": "uuid",
  "evidence_matrix": [],
  "missing_evidence_fields": [],
  "business_goal_refined": "string | null",
  "business_goal_delta": "string | null"
}
```

## 强制约束

1. **对用户零技术暴露**：审查表单中不向业务用户展示 `tech_repr` 中的字段名/SQL 片段；主 Skill 若需在开发者视图展示 `initial_sql`，与本 Skill 输出分离。
2. **单次闭环**：禁止「还需要调整其他部分吗」类追问。
3. **AST 级安全重建**：无法保证结构完整性时走 `blocking_prompt` 或降级，禁止正则盲改。
4. **依据标签**：`biz_translation` 对应项须有 `📌 依据`，且依据只能来自传入的 `kb_snapshot`；无依据则降置信度档位。
5. **字段归属强校验**：`SELECT` / `WHERE` / `JOIN ON` 等关键字段若无 **`table.field` 且该列在目标表上真实存在** 的证据（与 `sql-generator`「列物理存在性闸」一致），不得输出 `direct_sql`；不得以「常见必有列」补证。
6. **缺证可观测**：`review_form` / `blocking_prompt` 必须返回 `missing_evidence_fields`，禁止仅给笼统“信息不足”。
7. **职责边界**：不主动读 raw/wiki；不修改知识库；不直接写 `outputs/`。仅处理传入上下文与用户单次反馈。
8. **trace_id**：每次响应携带，便于 `gen → review → final` 链路关联。

## 与 wiki-maintainer 的交接

- **触发**：`/gen`、`/mod` 在展示给用户之前将 `nl_query`、`initial_sql`、`kb_snapshot`、`confidence_flags` 传入；若运营已一句话概括目标，一并传入 **`business_goal`**，便于输出 **`business_goal_refined`**。
- **挂起**：`review_form` 发出后，由主 Skill 展示表单并等待用户一次回复。
- **恢复**：用户回复后再次调用，携带选择结果，输出 `final_result` 或继续 `blocking_prompt`。
- **日志**：主 Skill 将 `trace_id`、`route`、动作用一行写入 `wiki/log.md`（行模板见 `wiki-maintainer` §3「`wiki/log.md`」小节）。

## 参考示例

**审查表单（节选）**：

```json
{
  "route": "review_form",
  "trace_id": "a1b2c3d4-e5f6-7890-abcd-ef1234567890",
  "components": [
    {
      "module": "filters",
      "tech_repr": "status = '1' AND region = '华东'",
      "biz_translation": "仅统计已支付订单，且区域限定为华东",
      "confidence": 0.65,
      "evidence": "📌 依据：kb_snapshot 中 status 映射与历史复用率；region 枚举边界未完全确认",
      "options": [
        {"label": "A", "text": "完全匹配", "action": "accept"},
        {"label": "B", "text": "区域需调整", "action": "override", "param_hint": "输入正确区域"},
        {"label": "C", "text": "时间/状态范围补充", "action": "text_input"},
        {"label": "D", "text": "移除条件", "action": "remove"},
        {"label": "E", "text": "按原逻辑执行", "action": "fallback"}
      ]
    }
  ],
  "defaults": "数据源与聚合指标置信度>0.85。",
  "instruction": "请回复 1+选项字母，可附单行说明。仅一次确认。"
}
```
