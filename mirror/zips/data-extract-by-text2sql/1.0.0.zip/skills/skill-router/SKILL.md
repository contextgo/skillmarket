---
name: skill-router
description: >-
  Meta-orchestrator: given the user goal, conversation state, and artifacts produced so far,
  selects the single best next skill (or none), defines handoff payload and stop conditions,
  and must be re-invoked after each substantive step before the next move. Use when the user
  carries task intent (SQL gen/mod, wiki/KB, or skill-eligible work); output
  RouterInput + RouterDecision before tools or substantive edits if the host project requires it.
  Also when the user asks for routing, orchestration, multi-skill workflows, phased NL2SQL,
  wiki vs SQL follow-ups, or routing after partial results.
---

# Skill 路由（元编排）

本技能**不替代**各业务技能的具体做法；它只负责：**读入当前上下文 → 选出唯一下一步要启用的技能（或判定无需技能）→ 规定交接内容与终止条件**。  
在复杂或多阶段任务中，**每一次准备执行新的实质性动作之前**，都应先把「已得结果摘要」喂回本技能，再决定下一步。

## 何时必须启用

- **（宿主可选强制）** 任意带**任务意图**的用户消息：若宿主规定「先路由再动作」，则在首次调用工具、改文件或执行业务技能之前，须先完成 **`RouterInput` + `RouterDecision`**。分类结果可以是 `next_skill: none`，但不可省略路由块（当规则要求展示时）。
- **典型意图**（默认都要先路由，未写全的诉求同等对待）：SQL 生成、SQL 修改、NL2SQL 审查、知识库/wiki 更新、以及任何可能对应到同捆或宿主其他 `SKILL.md` 的工作。
- 用户明确要求「路由 / 编排 / 分阶段 / 下一步用哪个 skill」。
- 单一用户问题隐含**多技能链**（例：写 SQL → 审查 SQL → 是否写入 wiki）。
- 上一步刚结束（例如已产出 SQL、已改 wiki、已 debug），**下一动作存在多个合理候选**。
## 核心原则

1. **一次只路由一个下一步**：输出里最多指定 **一个** `next_skill`；禁止并行堆叠多个「同等优先」的技能（若都重要，拆成顺序）。
2. **先读再指名**：一旦选定 `next_skill`，下一步应 **Read** 对应 `SKILL.md` 并严格按其流程执行，而不是凭印象执行。
3. **结果回灌**：被选中的技能执行完后，用其**关键结论与产物路径**更新 `state.artifacts`，再**重新进入本技能**做下一轮路由。
4. **终止清晰**：当用户目标已满足、且不存在合规/质量/wiki 等强制后置项时，`next_skill` 置为 `none` 并给出面向用户的最终答复指引。
5. **冷启动路径**：若尚未有用户确认的 **`{{WIKI_ROOT}}`**，在 `RouterDecision` 的 `handoff` / 说明中要求**先**执行同捆 **`references/exec-runbook.md` §0 与 §0.1**（知识库三目录 `raw/`、`wiki/`、`outputs/` 脚手架）。可令 `next_skill: wiki-maintainer` 以落实知识库侧脚手架，或令 `next_skill: sql-generator` 但在交接语中写明「须先完成 §0.1」；**不得**假定 wiki 文件已存在。  
6. **Raw→Wiki 再取数**：当用户直接要 **`/gen`** 但 **`exec-runbook` §0.3** 明显未满足时，优先 `next_skill: wiki-maintainer`（引导 **`raw/`** 投放 + **`/ingest`**），或在 `handoff` 中强制写明「完成 §0.3 前 `sql-generator` 不得进入 `initial_sql`」；避免路由到 SQL 后才发现无资料。

## 同捆技能路径（`data-extract` 包内）

| 技能 | 路径（相对本包根） | 典型用途 |
|------|-------------------|----------|
| sql-generator | `skills/sql-generator/SKILL.md` | 自然语言 → SQL、KB 闸、取数主链 |
| sql-review-controller | `skills/sql-review-controller/SKILL.md` | 语义审查、JSON 路由、放行终稿 |
| wiki-maintainer | `skills/wiki-maintainer/SKILL.md` | wiki 摄入、SQL 工程、日志 |

> 宿主若另行安装其他技能或与下表重名，以宿主配置为准；本表仅列本包同捆默认路径。

## 输入（调用方每次应提供）

调用本技能时，在对话中显式整理以下块（可 Markdown，字段缺省则写 `null`）：

```markdown
### RouterInput
- user_goal: <一句话目标>
- user_constraints: <硬约束：引擎、环境、不可做之事>
- phase: <explore | plan | implement | review | document | wrap_up>
- state:
  - done_steps: <已完成步骤短列表>
  - artifacts: <已产出：文件路径、SQL、结论要点等>
  - open_questions: <仍不确定且影响路由的点>
  - risks: <跨域/合规/数据权限/歧义等>
- last_skill: <刚执行完的技能 name 或 none>
- last_skill_result_summary: <3–8 条要点>
```

## 输出（本技能必须给出）

```markdown
### RouterDecision
- next_skill: <skill 的 `name` 字段，例如 `sql-generator`；若无需再启用技能则为 `none`>
- confidence: <high | medium | low>
- rationale: <1–5 句：为何是它、为何不是其他>
- handoff_brief: <交给下一技能的输入摘要：要做什么、不要做什么、验收标准>
- Preconditions: <下一技能开始前必须先满足的检查，例如「已确认时间分区」「已消除歧义」>
- stop_condition: <满足什么即可结束本轮链路或进入 wrap_up>
- reinvoke_router_after: <true | false>  # 下一技能完成后是否必须回到本技能
```

### `reinvoke_router_after` 判定指引

- `true`：下一步仍可能继续分叉（例：SQL 生成后可能要审查；审查后可能要回写 wiki）。
- `false`：**仅当**下一步执行完后可以直接对用户交付最终答案，且不存在强制链式技能时。

## 路由决策树（简版）

```mermaid
flowchart TD
  A[RouterInput 就绪] --> B{要取数或 SQL?}
  B -->|是| C[候选: sql-generator / sql-review-controller]
  B -->|否| D{改 wiki 或 index?}
  D -->|是| E[wiki-maintainer]
  D -->|否| H{目标与风险已清零?}
  H -->|是| I[next_skill 为 none]
  H -->|否| J[低置信: 先澄清]
```

> 暗黑主题可读：节点文字保持简短；若需补充说明放在 `rationale`，不要塞满节点。

## 标准闭环示例

### 例 A：取数 → 审查 → 交付

1. **Router #1**：`next_skill: sql-generator`，`reinvoke_router_after: true`。  
2. 执行 `sql-generator`，得到 SQL。  
3. **Router #2**（带回 SQL 摘要）：`next_skill: sql-review-controller`，`reinvoke_router_after: true`。  
4. 执行审查并定稿。  
5. **Router #3**：`next_skill: none`，`reinvoke_router_after: false`，输出最终用户可见结论（及可选 `outputs/` 归档提示）。

### 例 B：纯知识检索、无写入

- **Router #1**：若只需读 wiki 回答且不改文件 → 可直接 `wiki-maintainer` 的只读路径或一般阅读；若连 wiki 都不必 → `none`。

## 反模式（禁止）

- **路由套娃**：在 `next_skill` 仍为 `skill-router` 时无限自我调用；除非用户只要「重新评估路由」，否则应指向下游业务技能。
- **跳读 SKILL**：凭模型臆测执行 `sql-review-controller` 等强流程技能。
- **跳过后置**：用户明确要「沉淀到 wiki」却 `none` 提前结束。
- **一次输出多个平级技能**：应用顺序队列，每次 Router 决策只推进一头。

## 与其他技能的契约

- 被路由技能仍是**权威**：本技能只决定「下一步是谁」，不改变下游技能的硬性规则。
- 若 `confidence: low`，优先 **澄清** 或选择**低风险**路径（只读、备份、staging），并在 `rationale` 中说明。

## 自检清单（每次输出 RouterDecision 前）

- [ ] `next_skill` 是否最多一个？
- [ ] 若不为 `none`，`handoff_brief` 是否可被执行？
- [ ] `stop_condition` 对用户是否可验证？
- [ ] 是否需要 `reinvoke_router_after: true` 以防漏链？

---

**一句话**：把本技能当作**交通灯**——每个路口看一眼，绿灯指向一个技能；到达终点则 `none` 放行交付。
