#!/usr/bin/env node

/**
 * 终极邮件发送方案
 * 使用外部邮件API（Resend.com - 免费额度）
 */

const https = require('https');

// Resend.com API（免费额度：每月100封）
const RESEND_API_KEY = 're_1234567890'; // 需要注册获取，但先演示
const RESEND_API_URL = 'https://api.resend.com/emails';

async function sendWithResend(to, subject, html, text) {
  return new Promise((resolve) => {
    console.log(`📧 尝试通过Resend API发送邮件到: ${to}`);
    
    // 如果没有API key，显示如何获取
    if (RESEND_API_KEY === 're_1234567890') {
      console.log('❌ 需要Resend.com API密钥');
      console.log('💡 获取方法：');
      console.log('  1. 访问 https://resend.com');
      console.log('  2. 注册账号（免费）');
      console.log('  3. 获取API密钥');
      console.log('  4. 每月免费100封邮件');
      resolve(false);
      return;
    }
    
    const postData = JSON.stringify({
      from: 'Ad Hunter <ad-hunter@resend.dev>',
      to: [to],
      subject: subject,
      html: html,
      text: text,
    });
    
    const options = {
      hostname: 'api.resend.com',
      port: 443,
      path: '/emails',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData),
      },
    };
    
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        if (res.statusCode === 200) {
          console.log('✅ 邮件已通过Resend发送！');
          resolve(true);
        } else {
          console.log(`❌ Resend API错误: ${res.statusCode}`);
          console.log(`响应: ${data}`);
          resolve(false);
        }
      });
    });
    
    req.on('error', (error) => {
      console.error('❌ 请求失败:', error.message);
      resolve(false);
    });
    
    req.write(postData);
    req.end();
  });
}

// 备用方案：生成可点击的mailto链接
function createMailtoLink(to, subject, body) {
  const mailto = `mailto:${to}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body.substring(0, 1000))}`;
  return mailto;
}

// 主函数
async function sendUltimateEmail(to, subject, html, text) {
  console.log('🚀 广告主新客猎手 - 终极邮件发送方案');
  console.log('=====================================\n');
  
  // 方案1：尝试Resend API
  console.log('1. 🔄 尝试Resend API...');
  const resendSuccess = await sendWithResend(to, subject, html, text);
  
  if (resendSuccess) {
    return true;
  }
  
  // 方案2：生成mailto链接
  console.log('\n2. 🔗 生成mailto链接...');
  const mailtoLink = createMailtoLink(to, subject, text);
  
  console.log('✅ **邮件已准备好！**\n');
  console.log('📋 **请按以下任一方式发送：**');
  console.log('=' .repeat(50));
  
  console.log('\n🔗 **方式A：点击链接自动发送**');
  console.log(mailtoLink);
  console.log('\n💡 点击此链接会自动打开邮件客户端，内容已填好');
  
  console.log('\n📝 **方式B：手动复制发送**');
  console.log(`收件人: ${to}`);
  console.log(`主题: ${subject}`);
  console.log(`正文: ${text.substring(0, 200)}...`);
  
  console.log('\n📎 **方式C：发送HTML报告**');
  console.log('   1. 保存HTML内容到文件');
  console.log('   2. 在邮件客户端中添加为附件');
  console.log('   3. 发送到上述邮箱');
  
  console.log('\n' + '=' .repeat(50));
  
  // 保存HTML文件
  const fs = require('fs');
  const path = require('path');
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `ad-hunter-report-${timestamp}.html`;
  const outputDir = path.join(__dirname, 'reports');
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const filePath = path.join(outputDir, filename);
  fs.writeFileSync(filePath, html, 'utf-8');
  
  console.log(`\n📁 **报告文件已保存：** ${filePath}`);
  console.log(`📊 **文件大小：** ${Math.round(html.length / 1024)} KB`);
  
  return false; // 标记为需要用户操作
}

// 测试
async function test() {
  const to = '86951394@qq.com';
  const subject = '广告主新客猎手 - 测试邮件';
  const html = '<h1>测试邮件</h1><p>这是一封测试邮件。</p>';
  const text = '这是一封测试邮件。';
  
  console.log('开始测试终极邮件发送方案...\n');
  
  const success = await sendUltimateEmail(to, subject, html, text);
  
  if (success) {
    console.log('\n🎉 邮件已自动发送！');
  } else {
    console.log('\n💡 请按照上述指引发送邮件。');
  }
}

// 运行测试
if (require.main === module) {
  test().catch(console.error);
}

module.exports = { sendUltimateEmail };