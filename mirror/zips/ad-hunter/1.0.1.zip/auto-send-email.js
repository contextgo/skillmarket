#!/usr/bin/env node

/**
 * 自动发送邮件 - 使用OpenClaw exec调用邮件API
 * 这是真正的自动发送方案
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');

const execAsync = promisify(exec);

// 邮件API配置（使用Mailgun示例 - 免费额度）
const MAILGUN_API_KEY = process.env.MAILGUN_API_KEY || 'key-xxxxxx';
const MAILGUN_DOMAIN = process.env.MAILGUN_DOMAIN || 'sandboxxxxxxx.mailgun.org';

async function sendWithMailgun(to, subject, html, text) {
  try {
    console.log(`📧 通过Mailgun API发送邮件到: ${to}`);
    
    if (MAILGUN_API_KEY.includes('xxxxxx')) {
      console.log('❌ 需要配置Mailgun API密钥');
      console.log('💡 获取方法：');
      console.log('  1. 访问 https://www.mailgun.com');
      console.log('  2. 注册免费账号');
      console.log('  3. 获取API密钥和域名');
      console.log('  4. 每月免费10,000封邮件');
      return false;
    }
    
    // 使用curl调用Mailgun API
    const curlCommand = `curl -s --user 'api:${MAILGUN_API_KEY}' \
      https://api.mailgun.net/v3/${MAILGUN_DOMAIN}/messages \
      -F from='广告主新客猎手 <mailgun@${MAILGUN_DOMAIN}>' \
      -F to='${to}' \
      -F subject='${subject}' \
      -F text='${text.substring(0, 1000)}' \
      -F html='${html.substring(0, 5000)}'`;
    
    console.log('执行Mailgun API请求...');
    const { stdout, stderr } = await execAsync(curlCommand);
    
    if (stderr) {
      console.error('Mailgun错误:', stderr);
      return false;
    }
    
    const result = JSON.parse(stdout || '{}');
    if (result.id) {
      console.log(`✅ 邮件已发送！消息ID: ${result.id}`);
      return true;
    } else {
      console.log('❌ 邮件发送失败:', stdout);
      return false;
    }
    
  } catch (error) {
    console.error('Mailgun发送失败:', error.message);
    return false;
  }
}

// 备用方案：生成自动发送脚本
function createAutoSendScript(to, subject, html, text) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const scriptContent = `#!/bin/bash

# 广告主新客猎手 - 自动邮件发送脚本
# 生成时间: ${new Date().toLocaleString()}

echo "🚀 广告主新客猎手邮件发送脚本"
echo "=============================="
echo ""

# 检查Mailgun配置
if [ -z "$MAILGUN_API_KEY" ] || [ -z "$MAILGUN_DOMAIN" ]; then
  echo "❌ 未配置Mailgun环境变量"
  echo ""
  echo "💡 配置方法："
  echo "  1. 注册Mailgun: https://www.mailgun.com"
  echo "  2. 获取API密钥和域名"
  echo "  3. 设置环境变量："
  echo "     export MAILGUN_API_KEY='your-api-key'"
  echo "     export MAILGUN_DOMAIN='your-domain.mailgun.org'"
  echo "  4. 重新运行此脚本"
  echo ""
  exit 1
fi

# 发送邮件
echo "📧 正在发送邮件到: ${to}"
echo "📋 主题: ${subject}"

curl -s --user "api:\$MAILGUN_API_KEY" \\
  https://api.mailgun.net/v3/\$MAILGUN_DOMAIN/messages \\
  -F from='广告主新客猎手 <mailgun@'\$MAILGUN_DOMAIN'>' \\
  -F to='${to}' \\
  -F subject='${subject}' \\
  -F text='${text.substring(0, 1000).replace(/'/g, "'\"'\"'")}' \\
  -F html='${html.substring(0, 5000).replace(/'/g, "'\"'\"'")}'

if [ \$? -eq 0 ]; then
  echo ""
  echo "✅ 邮件发送成功！"
  echo "💡 请检查邮箱: ${to}"
else
  echo ""
  echo "❌ 邮件发送失败"
  echo "💡 请检查Mailgun配置"
fi
`;

  const scriptDir = path.join(__dirname, 'auto-send-scripts');
  if (!fs.existsSync(scriptDir)) {
    fs.mkdirSync(scriptDir, { recursive: true });
  }
  
  const scriptFile = path.join(scriptDir, `send-email-${timestamp}.sh`);
  fs.writeFileSync(scriptFile, scriptContent, 'utf-8');
  fs.chmodSync(scriptFile, '755');
  
  return scriptFile;
}

// 主函数
async function sendAutoEmail(to, subject, html, text) {
  console.log('🚀 广告主新客猎手 - 自动邮件发送');
  console.log('================================\n');
  
  // 尝试使用Mailgun发送
  console.log('1. 🔄 尝试通过Mailgun API发送...');
  const mailgunSuccess = await sendWithMailgun(to, subject, html, text);
  
  if (mailgunSuccess) {
    console.log('\n🎉 邮件已自动发送！');
    return true;
  }
  
  // 生成自动发送脚本
  console.log('\n2. 📝 生成自动发送脚本...');
  const scriptFile = createAutoSendScript(to, subject, html, text);
  
  console.log('✅ **自动发送脚本已生成！**\n');
  console.log('📋 **使用方法：**');
  console.log('=' .repeat(50));
  console.log(`\n🔧 **步骤1：配置Mailgun（一次性的）**`);
  console.log('   1. 访问 https://www.mailgun.com');
  console.log('   2. 注册免费账号');
  console.log('   3. 获取API密钥和沙箱域名');
  console.log('   4. 设置环境变量：');
  console.log('      export MAILGUN_API_KEY="your-key"');
  console.log('      export MAILGUN_DOMAIN="your-domain.mailgun.org"');
  
  console.log(`\n🚀 **步骤2：运行自动发送脚本**`);
  console.log(`   chmod +x "${scriptFile}"`);
  console.log(`   "${scriptFile}"`);
  
  console.log(`\n📧 **步骤3：检查邮箱**`);
  console.log(`   收件人: ${to}`);
  console.log(`   主题: ${subject}`);
  
  console.log('\n' + '=' .repeat(50));
  
  console.log(`\n📁 **脚本位置：** ${scriptFile}`);
  console.log(`📊 **脚本大小：** ${Math.round(fs.statSync(scriptFile).size / 1024)} KB`);
  
  // 保存HTML报告
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const filename = `ad-hunter-report-${timestamp}.html`;
  const outputDir = path.join(__dirname, 'reports');
  
  if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
  }
  
  const filePath = path.join(outputDir, filename);
  fs.writeFileSync(filePath, html, 'utf-8');
  
  console.log(`\n📄 **报告文件：** ${filePath}`);
  
  return false; // 标记为需要用户运行脚本
}

// 立即发送化妆品行业报告
async function sendCosmeticsReport() {
  console.log('🎯 立即发送化妆品行业报告');
  console.log('========================\n');
  
  // 读取最新的报告
  const reportsDir = path.join(__dirname, 'reports');
  const files = fs.readdirSync(reportsDir)
    .filter(f => f.includes('ad-hunter-report') && f.endsWith('.html'))
    .sort()
    .reverse();
  
  if (files.length === 0) {
    console.log('❌ 没有找到报告文件');
    return;
  }
  
  const latestReport = files[0];
  const reportPath = path.join(reportsDir, latestReport);
  const htmlContent = fs.readFileSync(reportPath, 'utf-8');
  
  // 提取信息
  const titleMatch = htmlContent.match(/<title>([^<]+)<\/title>/);
  const subject = titleMatch ? titleMatch[1] : '广告主新客猎手商机报告';
  
  // 提取文本内容
  const bodyStart = htmlContent.indexOf('<body>');
  const bodyEnd = htmlContent.indexOf('</body>');
  let textContent = htmlContent.substring(bodyStart + 6, bodyEnd)
    .replace(/<[^>]+>/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
  
  const to = '86951394@qq.com';
  
  console.log(`📊 报告信息：`);
  console.log(`   • 文件: ${latestReport}`);
  console.log(`   • 大小: ${Math.round(htmlContent.length / 1024)} KB`);
  console.log(`   • 收件人: ${to}`);
  console.log(`   • 主题: ${subject}`);
  console.log('');
  
  // 发送邮件
  await sendAutoEmail(to, subject, htmlContent, textContent);
}

// 运行
if (require.main === module) {
  sendCosmeticsReport().catch(console.error);
}

module.exports = { sendAutoEmail, sendCosmeticsReport };