#!/usr/bin/env node

/**
 * 一键发送化妆品行业报告到指定邮箱
 * 用户只需运行此脚本，就会自动收到邮件
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const os = require('os');

// 配置
const TARGET_EMAIL = '86951394@qq.com';
const INDUSTRY = '化妆品';
const SEND_TIME = '09:00';

console.log('🎯 广告主新客猎手 - 一键发送化妆品行业报告');
console.log('============================================\n');

// 步骤1：搜索化妆品行业商机
console.log('🔍 步骤1：搜索化妆品行业商机...');
exec('node dist/cli.js start -i "化妆品"', (error, stdout, stderr) => {
  if (error) {
    console.error('❌ 搜索失败:', error.message);
    return;
  }
  
  // 提取临时用户ID
  const tempUserIdMatch = stdout.match(/临时用户ID：\s*(temp_\d+)/);
  if (!tempUserIdMatch) {
    console.error('❌ 无法获取临时用户ID');
    console.log(stdout);
    return;
  }
  
  const tempUserId = tempUserIdMatch[1];
  console.log(`✅ 搜索完成！临时用户ID: ${tempUserId}`);
  
  // 步骤2：完成设置并发送邮件
  console.log('\n📧 步骤2：发送邮件到你的邮箱...');
  const command = `node dist/cli.js complete -u "${tempUserId}" -e "${TARGET_EMAIL}" -t "${SEND_TIME}"`;
  
  exec(command, (error2, stdout2, stderr2) => {
    if (error2) {
      console.error('❌ 发送失败:', error2.message);
      return;
    }
    
    console.log(stdout2);
    
    // 步骤3：提供用户友好的指引
    console.log('\n🎉 步骤3：邮件已准备好！');
    console.log('============================================');
    
    // 查找最新生成的报告文件
    const reportsDir = path.join(__dirname, 'reports');
    if (fs.existsSync(reportsDir)) {
      const files = fs.readdirSync(reportsDir)
        .filter(f => f.includes('ad-hunter-report'))
        .sort()
        .reverse();
      
      if (files.length > 0) {
        const latestReport = path.join(reportsDir, files[0]);
        console.log(`📄 报告文件: ${latestReport}`);
        
        // 尝试自动打开报告
        const platform = os.platform();
        let openCommand = '';
        
        if (platform === 'darwin') {
          openCommand = `open "${latestReport}"`;
        } else if (platform === 'win32') {
          openCommand = `start "${latestReport}"`;
        } else if (platform === 'linux') {
          openCommand = `xdg-open "${latestReport}"`;
        }
        
        if (openCommand) {
          console.log('\n🔓 正在自动打开报告文件...');
          exec(openCommand, (error3) => {
            if (error3) {
              console.log('⚠️ 无法自动打开，请手动打开文件查看');
            }
          });
        }
      }
    }
    
    console.log('\n💡 **下一步操作：**');
    console.log('   1. 检查你的邮箱 ' + TARGET_EMAIL);
    console.log('   2. 邮件客户端会自动打开（或已打开）');
    console.log('   3. 点击"发送"按钮即可收到邮件');
    console.log('   4. 从明天开始，每天 ' + SEND_TIME + ' 自动收到新报告');
    
    console.log('\n🔧 **你的配置：**');
    console.log('   用户ID: ' + tempUserId);
    console.log('   监控行业: ' + INDUSTRY);
    console.log('   接收邮箱: ' + TARGET_EMAIL);
    console.log('   发送时间: 每天 ' + SEND_TIME);
    
    console.log('\n🚀 **测试其他功能：**');
    console.log('   # 立即获取最新商机');
    console.log('   node dist/cli.js run -u "' + tempUserId + '"');
    console.log('');
    console.log('   # 修改为其他行业');
    console.log('   node dist/cli.js update -u "' + tempUserId + '" -i "美妆"');
    console.log('');
    console.log('   # 修改发送时间');
    console.log('   node dist/cli.js update -u "' + tempUserId + '" -t "10:00"');
    
    console.log('\n✅ **完成！** 你现在可以收到化妆品行业的商机报告了！');
  });
});