#!/usr/bin/env node

/**
 * 最简单的邮件发送方案 - 使用系统mail命令
 * macOS自带，无需配置
 */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const { promisify } = require('util');

const execAsync = promisify(exec);

async function sendSimpleEmail(to, subject, text) {
  try {
    console.log(`📧 使用系统mail命令发送邮件到: ${to}`);
    console.log(`📋 主题: ${subject}`);
    
    // 创建临时文件
    const tempFile = path.join('/tmp', `email-${Date.now()}.txt`);
    fs.writeFileSync(tempFile, text, 'utf-8');
    
    // 使用mail命令发送
    // -s: 主题
    // < : 从文件读取内容
    const command = `mail -s "${subject}" "${to}" < "${tempFile}"`;
    
    console.log(`执行命令: ${command}`);
    const { stdout, stderr } = await execAsync(command);
    
    if (stderr) {
      console.warn('警告:', stderr);
    }
    
    // 清理临时文件
    fs.unlinkSync(tempFile);
    
    console.log('✅ 邮件发送命令已执行！');
    console.log('💡 邮件可能已进入发送队列，请稍后检查邮箱');
    
    return true;
    
  } catch (error) {
    console.error('❌ 邮件发送失败:', error.message);
    
    // 备用方案：显示邮件内容，让用户手动发送
    console.log('\n📧 **邮件内容（请手动复制发送）：**');
    console.log('=' .repeat(50));
    console.log(`收件人: ${to}`);
    console.log(`主题: ${subject}`);
    console.log('\n内容:');
    console.log(text.substring(0, 500) + '...');
    console.log('=' .repeat(50));
    
    return false;
  }
}

// 测试发送
async function test() {
  const to = '86951394@qq.com';
  const subject = '广告主新客猎手测试邮件';
  const text = `这是一封测试邮件，确认邮件发送功能正常工作。

邮件详情：
- 发送时间: ${new Date().toLocaleString()}
- 发送方式: 系统mail命令
- 状态: 测试中

如果收到此邮件，说明广告主新客猎手的邮件发送功能正常工作。

祝好！
广告主新客猎手团队`;

  console.log('🚀 测试系统mail命令邮件发送');
  console.log('============================\n');
  
  const success = await sendSimpleEmail(to, subject, text);
  
  if (success) {
    console.log('\n🎉 测试完成！请检查邮箱是否收到测试邮件。');
  } else {
    console.log('\n⚠️ 测试失败，请手动发送邮件。');
  }
}

// 运行测试
test().catch(console.error);