// 测试邮件发送功能
const nodemailer = require('nodemailer');

async function testEmail() {
  console.log('测试邮件发送功能...');
  
  // 方法1：使用环境变量中的授权码
  const password = process.env.QQ_EMAIL_PASSWORD;
  
  if (!password) {
    console.log('❌ 未设置QQ邮箱授权码环境变量 QQ_EMAIL_PASSWORD');
    console.log('请先获取QQ邮箱授权码：');
    console.log('1. 登录QQ邮箱 → 设置 → 账户');
    console.log('2. 找到"POP3/IMAP/SMTP/Exchange/CardDAV/CalDAV服务"');
    console.log('3. 开启"IMAP/SMTP服务"，获取授权码');
    console.log('4. 设置环境变量: export QQ_EMAIL_PASSWORD=你的授权码');
    return false;
  }
  
  try {
    // 创建邮件传输器
    const transporter = nodemailer.createTransport({
      host: 'smtp.qq.com',
      port: 465,
      secure: true,
      auth: {
        user: '86951394@qq.com',
        pass: password
      }
    });
    
    // 测试连接
    console.log('测试SMTP连接...');
    await transporter.verify();
    console.log('✅ SMTP连接成功！');
    
    // 发送测试邮件
    const testMailOptions = {
      from: '"广告主新客猎手测试" <86951394@qq.com>',
      to: '86951394@qq.com',
      subject: '广告主新客猎手 - 测试邮件',
      text: '这是一封测试邮件，确认邮件发送功能正常工作。',
      html: '<h1>广告主新客猎手测试</h1><p>这是一封测试邮件，确认邮件发送功能正常工作。</p>'
    };
    
    console.log('发送测试邮件...');
    const info = await transporter.sendMail(testMailOptions);
    
    console.log(`✅ 测试邮件发送成功！消息ID: ${info.messageId}`);
    console.log(`📨 邮件已发送到: 86951394@qq.com`);
    
    return true;
    
  } catch (error) {
    console.error('❌ 邮件发送失败:', error.message);
    
    if (error.code === 'EAUTH') {
      console.log('可能的原因：');
      console.log('1. 授权码错误');
      console.log('2. 未开启SMTP服务');
      console.log('3. 邮箱账户被限制');
    }
    
    return false;
  }
}

// 运行测试
testEmail().then(success => {
  if (success) {
    console.log('\n🎉 邮件发送功能测试成功！');
  } else {
    console.log('\n⚠️ 邮件发送功能测试失败，将使用备用方案。');
  }
  process.exit(success ? 0 : 1);
});