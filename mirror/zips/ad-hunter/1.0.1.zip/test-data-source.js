#!/usr/bin/env node

// 测试数据来源更新
const { generateEmailContent } = require('./dist/email-sender.js');
const { OpportunityType } = require('./dist/news-fetcher.js');

// 创建测试数据
const testOpportunities = [
  {
    type: OpportunityType.NEW_COMPANY,
    company: "测试金融科技公司",
    title: "新金融科技公司成立",
    summary: "一家专注于区块链技术的金融科技公司在北京正式成立，注册资本1亿元。",
    link: "https://example.com/fintech-new",
    confidence: 85,
    details: {
      amount: "1亿元",
      region: "北京",
      investors: ["红杉资本", "腾讯投资"]
    }
  },
  {
    type: OpportunityType.NEW_PRODUCT,
    company: "某银行",
    title: "数字人民币新产品发布",
    summary: "某银行发布全新数字人民币钱包产品，支持多种支付场景。",
    link: "https://example.com/digital-yuan",
    confidence: 78,
    details: {
      product: "数字人民币钱包"
    }
  }
];

// 生成邮件内容
const emailContent = generateEmailContent("金融", testOpportunities);

console.log('📧 **测试报告生成**');
console.log('================\n');

console.log('✅ **邮件主题：**');
console.log(emailContent.subject);
console.log('');

console.log('✅ **数据来源显示（HTML页脚）：**');
const htmlLines = emailContent.html.split('\n');
const footerLine = htmlLines.find(line => line.includes('数据来源：'));
console.log(footerLine || '未找到数据来源行');
console.log('');

console.log('✅ **数据来源显示（纯文本）：**');
const textLines = emailContent.text.split('\n');
const textSourceLine = textLines.find(line => line.includes('数据来源：'));
console.log(textSourceLine || '未找到数据来源行');
console.log('');

console.log('📋 **预期显示：**');
console.log('   HTML: 数据来源：国内公开新闻媒体');
console.log('   文本: 数据来源：国内公开新闻媒体');
console.log('');

// 检查是否已更新
if (footerLine && footerLine.includes('国内公开新闻媒体')) {
  console.log('🎉 **数据来源已成功更新！**');
} else {
  console.log('⚠️ **数据来源未更新，请检查代码**');
}