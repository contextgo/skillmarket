#!/usr/bin/env node

// 测试QQ邮箱SMTP连接
const { testQQEmailConnection, sendCosmeticsReport } = require('./dist/qq-email-sender.js');

async function main() {
  console.log('🚀 测试QQ邮箱SMTP连接和发送');
  console.log('============================\n');
  
  // 测试连接
  console.log('1. 🔧 测试SMTP连接...');
  const connectionSuccess = await testQQEmailConnection();
  
  if (!connectionSuccess) {
    console.log('\n❌ SMTP连接测试失败，无法发送邮件');
    return;
  }
  
  console.log('\n2. 🎯 发送化妆品行业报告...');
  const reportSuccess = await sendCosmeticsReport();
  
  if (reportSuccess) {
    console.log('\n🎉 **邮件已自动发送！**');
    console.log('================================');
    console.log('✅ **Skill自己完成了所有步骤：**');
    console.log('   1. 连接QQ邮箱SMTP服务器');
    console.log('   2. 读取化妆品行业报告');
    console.log('   3. 自动发送邮件到 86951394@qq.com');
    console.log('   4. 保存本地副本');
    console.log('');
    console.log('📧 **请立即检查你的QQ邮箱！**');
    console.log('   收件人: 86951394@qq.com');
    console.log('   主题: 【广告主新客猎手】化妆品行业商机报告');
    console.log('');
    console.log('🚀 **广告主新客猎手现在完全合格！**');
  } else {
    console.log('\n❌ 报告发送失败');
  }
}

main().catch(console.error);