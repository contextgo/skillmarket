#!/usr/bin/env node

/**
 * 最简单的一键发送邮件方案
 * 直接生成邮件内容，用户复制粘贴即可
 */

const fs = require('fs');
const path = require('path');

console.log('📧 广告主新客猎手 - 一键发送邮件方案');
console.log('=====================================\n');

// 读取最新的报告
const reportsDir = path.join(__dirname, 'reports');
const files = fs.readdirSync(reportsDir)
  .filter(f => f.includes('ad-hunter-report') && f.endsWith('.html'))
  .sort()
  .reverse();

if (files.length === 0) {
  console.log('❌ 没有找到报告文件');
  process.exit(1);
}

const latestReport = files[0];
const reportPath = path.join(reportsDir, latestReport);
const htmlContent = fs.readFileSync(reportPath, 'utf-8');

// 提取报告信息
const titleMatch = htmlContent.match(/<title>([^<]+)<\/title>/);
const subject = titleMatch ? titleMatch[1] : '广告主新客猎手商机报告';

// 提取正文内容（简化版）
const bodyStart = htmlContent.indexOf('<body>');
const bodyEnd = htmlContent.indexOf('</body>');
let bodyContent = htmlContent.substring(bodyStart + 6, bodyEnd);

// 简化HTML内容
bodyContent = bodyContent
  .replace(/<style[^>]*>[\s\S]*?<\/style>/gi, '')
  .replace(/<script[^>]*>[\s\S]*?<\/script>/gi, '')
  .replace(/<[^>]+>/g, ' ')
  .replace(/\s+/g, ' ')
  .trim()
  .substring(0, 2000);

const targetEmail = '86951394@qq.com';

console.log('✅ **邮件已准备好！**\n');

console.log('📋 **请按以下步骤操作：**');
console.log('=====================================');
console.log('1. 📧 打开你的QQ邮箱：mail.qq.com');
console.log('2. 📝 点击"写邮件"');
console.log('3. 📨 填写以下信息：');
console.log('');
console.log(`   收件人: ${targetEmail}`);
console.log(`   主题: ${subject}`);
console.log(`   正文: ${bodyContent.substring(0, 500)}...`);
console.log('');
console.log('4. 📎 添加附件：');
console.log(`   文件: ${reportPath}`);
console.log('');
console.log('5. 🚀 点击"发送"按钮');
console.log('=====================================\n');

console.log('💡 **或者使用这个mailto链接（点击即可）：**');
const mailtoLink = `mailto:${targetEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(bodyContent.substring(0, 1000))}`;
console.log(mailtoLink);
console.log('');

console.log('📊 **报告摘要：**');
console.log('• 文件大小: ' + Math.round(htmlContent.length / 1024) + 'KB');
console.log('• 生成时间: ' + latestReport.match(/\d{4}-\d{2}-\d{2}T\d{2}-\d{2}-\d{2}/)?.[0]?.replace(/-/g, ':') || '刚刚');
console.log('• 保存位置: ' + reportPath);
console.log('');

console.log('🎯 **商机内容预览：**');
// 提取商机信息
const opportunityMatches = bodyContent.match(/【[^】]+】[^。]+。/g);
if (opportunityMatches) {
  opportunityMatches.slice(0, 3).forEach((match, i) => {
    console.log(`${i + 1}. ${match}`);
  });
  if (opportunityMatches.length > 3) {
    console.log(`   ...还有${opportunityMatches.length - 3}个商机`);
  }
}

console.log('\n✅ **完成！请按照以上步骤发送邮件。**');