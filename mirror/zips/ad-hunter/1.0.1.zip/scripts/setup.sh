#!/bin/bash
# 广告主新客猎手安装脚本

set -e

echo "🔧 安装广告主新客猎手..."
echo "=========================="
echo ""

# 检查Node.js版本
echo "📦 检查Node.js版本..."
node_version=$(node --version 2>/dev/null || echo "none")
if [[ $node_version == "none" ]]; then
    echo "❌ 未安装Node.js，请先安装Node.js 14+"
    exit 1
fi

echo "✅ Node.js版本: $node_version"
echo ""

# 安装依赖
echo "📦 安装依赖..."
npm install
echo "✅ 依赖安装完成"
echo ""

# 编译TypeScript
echo "🔨 编译TypeScript..."
npm run build
echo "✅ 编译完成"
echo ""

# 创建数据目录
echo "📁 创建数据目录..."
mkdir -p data/configs
echo "✅ 数据目录创建完成"
echo ""

# 测试编译结果
echo "🧪 测试编译结果..."
if [ -f "dist/cli.js" ]; then
    echo "✅ CLI编译成功"
else
    echo "❌ CLI编译失败"
    exit 1
fi

echo ""
echo "🎉 广告主新客猎手安装完成！"
echo ""
echo "🚀 使用方法："
echo "1. 设置向导：./dist/cli.js wizard"
echo "2. 命令行设置：./dist/cli.js setup -u 'user123' -i '汽车' -e 'email@example.com'"
echo "3. 立即运行：./dist/cli.js run -u 'user123'"
echo ""
echo "📖 更多信息请查看 README.md"