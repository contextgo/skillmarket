import { z } from "zod";
import { 
  saveUserConfig, 
  loadUserConfig, 
  updateUserConfig, 
  hasUserConfig,
  UserConfigSchema 
} from "./config";
import { findOpportunities } from "./news-fetcher";
import { generateEmailContent, sendEmail } from "./email-sender";

// ===== 默认配置（安装后可修改） =====
// 客户的邮箱写在这里，以后改这里即可
const DEFAULT_EMAIL = "请修改为您的邮箱@qq.com";
// ===================================

// 定义工具输入参数的 Zod schema

// 一键订阅：用户直接说"我要汽车行业，邮箱xxx@xx.com"
const SubscribeSchema = z.object({
  industry: z.string().describe("要监控的行业，例如：汽车、美妆、人工智能、科技、金融、医疗、教育等。也支持[全行业/全部行业]做全行业扫描。"),
  email: z.string().email().describe("接收每日商机报告的邮箱地址，例如 user@example.com"),
  sendTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).default("08:00").describe("每日发送时间，格式HH:mm，例如08:30。不填默认08:00"),
});

// 第一步：用户输入行业，立即搜索（保留旧接口兼容）
const StartAdHunterSchema = z.object({
  industry: z.string().describe("要监控的行业，例如：汽车、美妆、人工智能、科技、金融、医疗、教育等。系统会立即搜索该行业的商机并发送报告。"),
});

// 第二步：用户确认后，输入邮箱和发送时间
const CompleteSetupSchema = z.object({
  userId: z.string().describe("用户ID（从第一步返回）"),
  email: z.string().email().describe("接收每日商机报告的邮箱地址"),
  sendTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).default("08:00").describe("每日发送时间，格式HH:mm，例如08:30"),
});

// 其他工具保持不变
const RunNowSchema = z.object({
  userId: z.string().describe("用户ID"),
});

const UpdateConfigSchema = z.object({
  userId: z.string().describe("用户ID"),
  industry: z.string().optional().describe("新的行业，例如：美妆"),
  email: z.string().email().optional().describe("新的邮箱地址"),
  sendTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/).optional().describe("新的发送时间，格式HH:mm"),
});

const CheckStatusSchema = z.object({
  userId: z.string().describe("用户ID"),
});

// 工具1：开始使用（第一步：输入行业，立即搜索）
export const start_ad_hunter = {
  name: "start_ad_hunter",
  description: "开始使用广告主新客猎手。输入要监控的行业，系统会立即搜索该行业的商机并生成报告。",
  schema: StartAdHunterSchema,
  handler: async (args: z.infer<typeof StartAdHunterSchema>) => {
    const { industry } = args;
    
    // 检查是否输入了多个行业（包含"和"、"、"、","等分隔符）
    const separators = ['和', '、', ',', '，', ' '];
    let hasMultipleIndustries = false;
    let detectedIndustries: string[] = [industry];
    
    for (const separator of separators) {
      if (industry.includes(separator)) {
        detectedIndustries = industry.split(separator).map(i => i.trim()).filter(i => i.length > 0);
        if (detectedIndustries.length > 1) {
          hasMultipleIndustries = true;
          break;
        }
      }
    }
    
    // 如果用户输入了多个行业，直接返回提示
    if (hasMultipleIndustries && detectedIndustries.length > 1) {
      return {
        result: `⚠️ **当前只能监控一个行业**\n\n` +
          `您输入了 ${detectedIndustries.length} 个行业：${detectedIndustries.join('、')}\n\n` +
          `💡 **请重新输入一个行业：**\n` +
          `例如："汽车" 或 "化妆品" 或 "科技"`,
        isMultipleIndustries: true,
        detectedIndustries,
      };
    }
    
    // 单个行业，正常处理
    const singleIndustry = detectedIndustries[0];
    const isAllIndustries = singleIndustry === "全行业" || singleIndustry === "全部行业" || singleIndustry === "所有行业";
    
    // 生成临时用户ID（基于时间戳）
    const tempUserId = `temp_${Date.now()}`;
    
    // 立即搜索商机
    const label = isAllIndustries ? "全行业" : singleIndustry;
    console.log(`🔍 正在搜索 ${label} 商机...`);
    const opportunities = await findOpportunities(singleIndustry, 20, isAllIndustries);
    
    // 生成报告预览
    const emailContent = generateEmailContent(label, opportunities);
    
    // 保存临时配置（只保存行业）
    const tempConfig = {
      userId: tempUserId,
      industry: label,
      email: "", // 暂未设置
      sendTime: "08:00", // 默认值
      createdAt: new Date().toISOString(),
      isTemporary: true,
    };
    
    saveUserConfig(tempConfig);
    
    const opportunityCount = opportunities.length;
    const opportunityTypes = opportunities.reduce((acc, opp) => {
      acc[opp.type] = (acc[opp.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);
    
    let typeSummary = "";
    for (const [type, count] of Object.entries(opportunityTypes)) {
      typeSummary += `• ${type}: ${count}个\n`;
    }
    
    // 显示热门商机示例
    let exampleOpportunities = "";
    const exampleCount = Math.min(3, opportunities.length);
    for (let i = 0; i < exampleCount; i++) {
      const opp = opportunities[i];
      exampleOpportunities += `\n${i + 1}. 【${opp.type}】${opp.company}\n   ${opp.summary.substring(0, 80)}...`;
    }
    
    return {
      result: `🎯 **${label}商机搜索完成！**\n\n` +
        `📊 **搜索结果：**\n` +
        `• 发现商机：${opportunityCount}个\n` +
        (typeSummary ? `• 商机分类：\n${typeSummary}` : "") +
        (exampleOpportunities ? `\n🔥 **热门商机示例：**${exampleOpportunities}` : "") +
        `\n---\n` +
        `✅ **下一步：设置每日自动报告**\n` +
        `请提供您的邮箱地址，系统将：\n` +
        `1. 📧 **立即自动发送**这份完整报告到您的邮箱\n` +
        `2. ⏰ 设置每日自动发送（默认08:00）\n` +
        `3. 🔔 从此每天自动发现新商机\n\n` +
        `📋 **邮件发送说明：**\n` +
        `• 🔐 **安全可靠**：使用QQ邮箱官方SMTP服务发送\n` +
        `• ⚡ **立即送达**：邮件通常在1-3分钟内到达\n` +
        `• 📨 **收件箱**：邮件会发送到您的收件箱\n` +
        `• 🗑️ **垃圾邮件**：如未收到，请检查垃圾邮件箱\n` +
        `• ✅ **无需操作**：您无需点击任何链接或按钮\n\n` +
        `💡 **请回复：**\n` +
        `"我的邮箱是：your-email@example.com" 或\n` +
        `"每天09:00发送到：your-email@example.com"\n\n` +
        `💡 也可使用默认邮箱 ${DEFAULT_EMAIL}：\n` +
        `ad-hunter complete -u ${tempUserId} -e ${DEFAULT_EMAIL}\n\n` +
        `🔑 **临时用户ID：** ${tempUserId}（请保存，用于后续操作）`,
      tempUserId,
      industry: label,
      opportunityCount,
    };
  },
};

// 工具2：完成设置（第二步：输入邮箱和发送时间）
export const complete_ad_hunter_setup = {
  name: "complete_ad_hunter_setup",
  description: "完成广告主新客猎手设置。提供邮箱地址和发送时间，系统会立即发送报告并设置每日定时任务。",
  schema: CompleteSetupSchema,
  handler: async (args: z.infer<typeof CompleteSetupSchema>) => {
    const { userId, email: rawEmail, sendTime } = args;
    const email = rawEmail || DEFAULT_EMAIL;
    
    // 加载临时配置
    const tempConfig = loadUserConfig(userId);
    
    if (!tempConfig || !tempConfig.isTemporary) {
      return {
        result: "❌ 未找到临时配置。请先使用'开始使用广告主新客猎手'功能选择行业。",
      };
    }
    
    const { industry } = tempConfig;
    const isAllIndustries = industry === "全行业" || industry === "全部行业" || industry === "所有行业";
    
    // 再次搜索商机（确保数据最新）
    const opportunities = await findOpportunities(industry, 15, isAllIndustries);
    const emailContent = generateEmailContent(industry, opportunities);
    
    // 发送邮件
    const emailSent = await sendEmail(
      email,
      emailContent.subject,
      emailContent.html,
      emailContent.text
    );
    
    if (!emailSent) {
      return {
        result: "❌ 邮件发送失败，请检查邮箱地址或联系管理员。",
      };
    }
    
    // 保存完整配置（覆盖临时配置）
    const finalConfig = {
      userId,
      industry,
      email,
      sendTime,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      lastRunTime: new Date().toISOString(),
      isTemporary: false,
    };
    
    saveUserConfig(finalConfig);
    
    const opportunityCount = opportunities.length;
    
    return {
      result: `🎉 **广告主新客猎手设置完成！**\n\n` +
        `✅ **已自动发送今日商机报告到：** ${email}\n` +
        `📊 **报告内容：**\n` +
        `• 监控行业：${industry}\n` +
        `• 发现商机：${opportunityCount}个\n` +
        `• 报告长度：${emailContent.html.length}字符（HTML）\n\n` +
        `📧 **邮件发送详情：**\n` +
        `• 🔐 **发送方式**：通过QQ邮箱官方SMTP服务发送\n` +
        `• ⏱️ **发送时间**：立即发送（通常在1-3分钟内到达）\n` +
        `• 📨 **收件位置**：您的邮箱收件箱\n` +
        `• 🗑️ **如未收到**：请检查垃圾邮件箱/广告邮件箱\n` +
        `• 📱 **手机查看**：可在QQ邮箱App或网页版查看\n` +
        `• ✅ **无需操作**：邮件已自动发送，您无需任何操作\n\n` +
        `⏰ **每日自动报告：**\n` +
        `• 发送时间：每天 ${sendTime}\n` +
        `• 开始时间：从明天开始\n` +
        `• 接收邮箱：${email}\n` +
        `• 发送方式：自动发送，无需您操作\n\n` +
        `🔔 **使用说明：**\n` +
        `• 立即运行："立即运行广告主新客猎手"\n` +
        `• 修改行业："修改行业为XX"\n` +
        `• 修改时间："修改发送时间为XX:XX"\n` +
        `• 检查状态："检查广告主新客猎手状态"\n\n` +
        `💡 **提示：**\n` +
        `• 监控1个行业\n` +
        `• 您的用户ID：${userId}（请妥善保存）\n\n` +
        `❓ **常见问题：**\n` +
        `Q: 邮件真的发送了吗？\n` +
        `A: 是的！系统已通过QQ邮箱SMTP服务发送。\n\n` +
        `Q: 为什么我没收到邮件？\n` +
        `A: 请检查：1) 垃圾邮件箱 2) 广告邮件箱 3) 邮箱地址是否正确\n\n` +
        `Q: 明天还会自动发送吗？\n` +
        `A: 是的！从明天开始，每天${sendTime}自动发送。`,
    };
  },
};

// 工具2：立即运行
export const run_ad_hunter_now = {
  name: "run_ad_hunter_now",
  description: "立即运行广告主新客猎手，抓取当前商机并发送报告",
  schema: RunNowSchema,
  handler: async (args: z.infer<typeof RunNowSchema>) => {
    const { userId } = args;
    
    // 加载配置
    const config = loadUserConfig(userId);
    
    if (!config) {
      return {
        result: "❌ 您还没有配置广告主新客猎手。请先使用设置向导进行配置。",
      };
    }
    
    const { industry, email } = config;
    
    // 检查邮箱是否已设置
    if (!email) {
      return {
        result: "❌ 您还没有设置接收邮箱。请先完成设置。",
      };
    }
    
    // 查找商机
    const isAllIndustries = industry === "全行业" || industry === "全部行业" || industry === "所有行业";
    const opportunities = await findOpportunities(industry, 20, isAllIndustries);
    const emailContent = generateEmailContent(industry, opportunities);
    
    // 发送邮件
    const emailSent = await sendEmail(
      email,
      emailContent.subject,
      emailContent.html,
      emailContent.text
    );
    
    if (emailSent) {
      const opportunityCount = opportunities.length;
      const opportunityTypes = opportunities.reduce((acc, opp) => {
        acc[opp.type] = (acc[opp.type] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      let typeSummary = "";
      for (const [type, count] of Object.entries(opportunityTypes)) {
        typeSummary += `• ${type}: ${count}个\n`;
      }
      
      return {
        result: `✅ 商机报告已发送到 ${email}\n\n` +
          `📊 报告摘要：\n` +
          `• 监控行业：${industry}\n` +
          `• 发现商机：${opportunityCount}个\n` +
          (typeSummary ? `• 商机分类：\n${typeSummary}` : "") +
          `\n📧 请检查您的邮箱查看完整报告。`,
      };
    } else {
      return {
        result: "❌ 邮件发送失败，请检查邮箱配置或联系管理员。",
      };
    }
  },
};

// 工具3：修改配置
export const update_ad_hunter_config = {
  name: "update_ad_hunter_config",
  description: "修改广告主新客猎手的配置（行业、邮箱、发送时间）",
  schema: UpdateConfigSchema,
  handler: async (args: z.infer<typeof UpdateConfigSchema>) => {
    const { userId, industry, email, sendTime } = args;
    
    // 检查是否已配置
    if (!hasUserConfig(userId)) {
      return {
        result: "❌ 您还没有配置广告主新客猎手。请先使用设置向导进行配置。",
      };
    }
    
    // 构建更新对象
    const updates: any = {};
    if (industry) updates.industry = industry;
    if (email) updates.email = email;
    if (sendTime) updates.sendTime = sendTime;
    
    if (Object.keys(updates).length === 0) {
      return {
        result: "⚠️ 没有提供任何修改内容。",
      };
    }
    
    // 更新配置
    const updatedConfig = updateUserConfig(userId, updates);
    
    if (!updatedConfig) {
      return {
        result: "❌ 更新配置失败。",
      };
    }
    
    let result = "✅ 配置更新成功！\n\n";
    result += "当前配置：\n";
    
    if (industry) result += `• 监控行业：${industry}\n`;
    if (email) result += `• 接收邮箱：${email}\n`;
    if (sendTime) result += `• 发送时间：每天 ${sendTime}\n`;
    
    // 显示未修改的配置
    const currentConfig = loadUserConfig(userId)!;
    if (!industry) result += `• 监控行业：${currentConfig.industry}\n`;
    if (!email) result += `• 接收邮箱：${currentConfig.email}\n`;
    if (!sendTime) result += `• 发送时间：每天 ${currentConfig.sendTime}\n`;
    
    result += `\n📅 从明天开始，新的配置将生效。`;
    
    return { result };
  },
};

// 工具4：检查状态
export const check_ad_hunter_status = {
  name: "check_ad_hunter_status",
  description: "检查广告主新客猎手的当前配置和状态",
  schema: CheckStatusSchema,
  handler: async (args: z.infer<typeof CheckStatusSchema>) => {
    const { userId } = args;
    
    // 加载配置
    const config = loadUserConfig(userId);
    
    if (!config) {
      return {
        result: "❌ 您还没有配置广告主新客猎手。\n\n" +
          "请使用以下命令开始配置：\n" +
          '"广告主新客猎手" 或 "新客猎手"',
      };
    }
    
    const { industry, email, sendTime, lastRunTime, createdAt, updatedAt } = config;
    
    let result = "📊 广告主新客猎手状态\n\n";
    result += "🔧 当前配置：\n";
    result += `• 监控行业：${industry}\n`;
    result += `• 接收邮箱：${email}\n`;
    result += `• 发送时间：每天 ${sendTime}\n`;
    
    if (lastRunTime) {
      const lastRun = new Date(lastRunTime);
      result += `• 最后运行：${lastRun.toLocaleString("zh-CN")}\n`;
    } else {
      result += `• 最后运行：从未运行\n`;
    }
    
    if (createdAt) {
      const created = new Date(createdAt);
      result += `• 创建时间：${created.toLocaleDateString("zh-CN")}\n`;
    }
    
    result += `\n🎯 使用说明：\n`;
    result += `• 立即运行："立即运行广告主新客猎手"\n`;
    result += `• 修改行业："修改行业为XX"\n`;
    result += `• 修改时间："修改发送时间为XX:XX"\n`;
    result += `• 修改邮箱："修改邮箱为XX@example.com"\n`;
    
    result += `\n💡 提示：当前监控1个行业。`;
    
    return { result };
  },
};

// 工具5：一键订阅（用户直接说"我要汽车行业，邮箱xxx@xx.com"）
export const subscribe_ad_hunter = {
  name: "subscribe_ad_hunter",
  description: "一键订阅广告主新客猎手。用户直接告知行业和邮箱，系统立即搜索商机、发送报告并设置每日定时发送。不需要分两步走。",
  schema: SubscribeSchema,
  handler: async (args: z.infer<typeof SubscribeSchema>) => {
    const { industry: rawIndustry, email, sendTime } = args;
    
    // 处理全行业关键词
    const allKeywords = ["全行业", "全部行业", "所有行业"];
    const isAllIndustries = allKeywords.includes(rawIndustry);
    const industry = isAllIndustries ? "全行业" : rawIndustry;
    const label = isAllIndustries ? "全行业" : industry;
    
    // 生成用户ID
    const userId = `user_${Date.now()}`;
    
    // 保存配置
    const config = {
      userId,
      industry: label,
      email,
      sendTime: sendTime || "08:00",
      isTemporary: false,
    };
    
    try {
      UserConfigSchema.parse(config);
    } catch (e) {
      return { result: "❌ 配置参数无效：" + (e as Error).message };
    }
    
    saveUserConfig(config);
    
    // 搜索商机
    const opportunities = await findOpportunities(label, 15, isAllIndustries);
    
    // 生成邮件内容
    const emailContent = generateEmailContent(label, opportunities);
    
    // 发送邮件
    const emailSent = await sendEmail(
      email,
      emailContent.subject,
      emailContent.html,
      emailContent.text
    );
    
    let result = "";
    
    if (emailSent) {
      result += `🎉 **订阅成功！**\n\n`;
      result += `📊 **今日 ${label} 商机简报**\n`;
      result += `• 发现商机：${opportunities.length}个\n`;
      
      // 按类型统计
      const typeCount: Record<string, number> = {};
      for (const opp of opportunities) {
        typeCount[opp.type] = (typeCount[opp.type] || 0) + 1;
      }
      for (const [type, count] of Object.entries(typeCount)) {
        result += `• ${type}: ${count}个\n`;
      }
      result += `\n`;
      
      result += `✅ **邮件已发送到：** ${email}\n`;
      result += `⏰ **每日报告时间：** 每天 ${sendTime || "08:00"}\n`;
      result += `\n`;
      result += `📋 **使用说明：**\n`;
      result += `• 修改行业："修改行业为XXX"\n`;
      result += `• 修改邮箱："修改邮箱为xxx@xx.com"\n`;
      result += `• 修改时间："修改发送时间为09:00"\n`;
      result += `• 立即运行："立即运行广告主新客猎手"\n`;
      result += `• 检查状态："检查广告主新客猎手状态"\n`;
      result += `• 取消订阅："取消广告主新客猎手"\n`;
    } else {
      result += `⚠️ **配置已保存，但邮件发送失败。**\n\n`;
      result += `自动报告已设置为每天 ${sendTime || "08:00"} 发送到 ${email}\n`;
      result += `请检查邮箱地址是否正确，或联系技术支持。\n\n`;
      result += `💡 当前配置：\n`;
      result += `• 监控行业：${label}\n`;
      result += `• 接收邮箱：${email}\n`;
      result += `• 发送时间：每天 ${sendTime || "08:00"}\n`;
    }
    
    return { result };
  },
};

// 工具6：每日定时任务（供cron调用）
export const daily_ad_hunter_task = {
  name: "daily_ad_hunter_task",
  description: "广告主新客猎手的每日定时任务，为所有用户生成并发送商机报告",
  schema: z.object({}),
  handler: async () => {
    // 这个函数应该由cron定时调用
    // 在实际OpenClaw环境中，应该获取所有用户配置
    // 这里简化处理，只返回说明
    
    return {
      result: "📅 广告主新客猎手每日定时任务\n\n" +
        "这个任务应该由OpenClaw的cron系统定时调用，例如：\n" +
        "```\n" +
        "cron add --name ad-hunter-daily --schedule '0 8 * * *' --payload '{\"kind\":\"agentTurn\",\"message\":\"运行广告主新客猎手每日任务\"}'\n" +
        "```\n\n" +
        "任务会：\n" +
        "1. 读取所有用户的配置\n" +
        "2. 为每个用户抓取其监控行业的商机\n" +
        "3. 生成并发送邮件报告\n" +
        "4. 更新最后运行时间\n",
    };
  },
};