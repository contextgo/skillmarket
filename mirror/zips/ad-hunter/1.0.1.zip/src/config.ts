import { z } from "zod";
import fs from "fs";
import path from "path";

// 用户配置schema
export const UserConfigSchema = z.object({
  userId: z.string(),
  industry: z.string().min(1, "行业不能为空"),
  email: z.string().email("邮箱格式不正确").optional().or(z.literal("")),
  sendTime: z.string().regex(/^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/, "时间格式应为HH:mm"),
  lastRunTime: z.string().optional(),
  createdAt: z.string().optional(),
  updatedAt: z.string().optional(),
  isTemporary: z.boolean().optional().default(false),
});

export type UserConfig = z.infer<typeof UserConfigSchema>;

// 配置存储路径
const CONFIG_DIR = path.join(process.cwd(), "data", "configs");
const CONFIG_FILE_EXT = ".json";

// 确保配置目录存在
function ensureConfigDir() {
  if (!fs.existsSync(CONFIG_DIR)) {
    fs.mkdirSync(CONFIG_DIR, { recursive: true });
  }
}

// 获取用户配置文件路径
function getUserConfigPath(userId: string): string {
  return path.join(CONFIG_DIR, `${userId}${CONFIG_FILE_EXT}`);
}

// 保存用户配置
export function saveUserConfig(config: UserConfig): void {
  ensureConfigDir();
  
  const now = new Date().toISOString();
  const configToSave = {
    ...config,
    updatedAt: now,
    createdAt: config.createdAt || now,
  };
  
  fs.writeFileSync(
    getUserConfigPath(config.userId),
    JSON.stringify(configToSave, null, 2),
    "utf-8"
  );
}

// 加载用户配置
export function loadUserConfig(userId: string): UserConfig | null {
  const configPath = getUserConfigPath(userId);
  
  if (!fs.existsSync(configPath)) {
    return null;
  }
  
  try {
    const rawData = fs.readFileSync(configPath, "utf-8");
    const parsed = JSON.parse(rawData);
    return UserConfigSchema.parse(parsed);
  } catch (error) {
    console.error(`加载用户配置失败 (${userId}):`, error);
    return null;
  }
}

// 删除用户配置
export function deleteUserConfig(userId: string): boolean {
  const configPath = getUserConfigPath(userId);
  
  if (fs.existsSync(configPath)) {
    fs.unlinkSync(configPath);
    return true;
  }
  
  return false;
}

// 更新用户配置
export function updateUserConfig(
  userId: string, 
  updates: Partial<Omit<UserConfig, "userId">>
): UserConfig | null {
  const existing = loadUserConfig(userId);
  
  if (!existing) {
    return null;
  }
  
  const updatedConfig = {
    ...existing,
    ...updates,
    updatedAt: new Date().toISOString(),
  };
  
  saveUserConfig(updatedConfig);
  return updatedConfig;
}

// 检查用户是否已配置
export function hasUserConfig(userId: string): boolean {
  return loadUserConfig(userId) !== null;
}

// 获取所有用户配置（用于定时任务）
export function getAllUserConfigs(): UserConfig[] {
  ensureConfigDir();
  
  const configs: UserConfig[] = [];
  
  try {
    const files = fs.readdirSync(CONFIG_DIR);
    
    for (const file of files) {
      if (file.endsWith(CONFIG_FILE_EXT)) {
        const userId = file.replace(CONFIG_FILE_EXT, "");
        const config = loadUserConfig(userId);
        
        if (config) {
          configs.push(config);
        }
      }
    }
  } catch (error) {
    console.error("获取所有用户配置失败:", error);
  }
  
  return configs;
}