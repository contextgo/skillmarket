import fetch from "node-fetch";
import Parser from "rss-parser";
import * as cheerio from "cheerio";
import { fetchNewsFromWeb } from "./news-scraper";

// 新闻源配置 - 国内公开新闻媒体（全面覆盖）
const NEWS_SOURCES = {
  // === 主流新闻门户 ===
  "人民网": {
    rss: "http://www.people.com.cn/rss/politics.xml",
    category: "综合",
  },
  "中国新闻网": {
    rss: "http://www.chinanews.com/rss/scroll-news.xml",
    category: "综合",
  },
  "少数派": {
    rss: "https://sspai.com/feed",
    category: "综合",
  },
  
  // === 商业财经媒体 ===
  "东方财富网": {
    rss: "http://rss.eastmoney.com/",
    category: "财经",
  },
  "金融界": {
    rss: "http://www.jrj.com.cn/rss",
    category: "财经",
  },
  "证券时报": {
    rss: "http://www.stcn.com/rss.xml",
    category: "财经",
  },
  
  // === 科技媒体 ===
  "36氪": {
    rss: "https://36kr.com/feed",
    category: "科技",
  },
  "钛媒体": {
    rss: "https://www.tmtpost.com/rss",
    category: "科技",
  },
  "爱范儿": {
    rss: "https://www.ifanr.com/feed",
    category: "科技",
  },
  "品玩": {
    rss: "https://www.pingwest.com/feed",
    category: "科技",
  },
  
  // === 行业垂直媒体 ===
  "汽车之家": {
    rss: "https://www.autohome.com.cn/rss",
    category: "汽车",
  },
  "亿邦动力": {
    rss: "https://www.ebrun.com/rss",
    category: "电商",
  },
  "联商网": {
    rss: "https://www.linkshop.com/rss.xml",
    category: "零售",
  },
  "动脉网": {
    rss: "https://www.vbdata.cn/rss",
    category: "医疗产业",
  },
  "中国教育在线": {
    rss: "http://www.eol.cn/rss.xml",
    category: "教育",
  },
  "教育新闻网": {
    rss: "http://www.jyb.cn/rss.xml",
    category: "教育",
  },
  "健康报": {
    rss: "http://www.jkb.com.cn/rss.xml",
    category: "医疗",
  },
  
  // === 产业媒体 ===
  "亿欧网": {
    rss: "https://www.iyiou.com/feed",
    category: "产业",
  },
  "创业邦": {
    rss: "https://www.cyzone.cn/rss",
    category: "创业",
  },
  "投资界": {
    rss: "https://www.pedaily.cn/rss",
    category: "投资",
  },
  
  // === 搜索引擎新闻 ===
  "百度热搜": {
    rss: "https://rsshub.app/baidu/topwords",
    category: "搜索",
  },
  "必应热搜": {
    rss: "https://rsshub.app/bing/news",
    category: "搜索",
  },

  // === 国际媒体（中文版） ===
  "华尔街见闻": {
    rss: "https://wallstreetcn.com/rss",
    category: "财经",
  },
};

// 新闻条目类型
export interface NewsItem {
  title: string;
  description: string;
  link: string;
  pubDate: string;
  source: string;
  category: string;
  content?: string;
}

// 商机类型
export enum OpportunityType {
  NEW_COMPANY = "新公司成立",
  NEW_PRODUCT = "新产品发布",
  NEW_FUNDING = "获得融资",
  NEW_MARKET = "开拓新市场",
}

// 商机条目
export interface Opportunity {
  type: OpportunityType;
  company: string;
  title: string;
  summary: string;
  link: string;
  confidence: number; // 0-100，置信度
  details: {
    amount?: string; // 融资金额
    product?: string; // 产品名称
    region?: string; // 新市场区域
    industry?: string; // 所属行业
    isForeign?: boolean; // 是否是外资企业
    origin?: string; // 外资来源地
    investors?: string[]; // 投资机构列表
    eventType?: string; // 发布会类型
  };
}

// 从RSS源抓取新闻
export async function fetchNewsFromRSS(sourceKey: string): Promise<NewsItem[]> {
  const source = NEWS_SOURCES[sourceKey as keyof typeof NEWS_SOURCES];
  
  if (!source) {
    console.warn(`未知的新闻源: ${sourceKey}`);
    return [];
  }
  
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000); // 5秒超时
    
    const parser = new Parser({
      timeout: 5000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; AdHunter/1.0)',
      },
      requestOptions: {
        signal: controller.signal as any,
      }
    });
    
    const feed = await parser.parseURL(source.rss);
    clearTimeout(timeoutId);
    
    const newsItems = feed.items.map(item => ({
      title: item.title || "",
      description: item.contentSnippet || item.content || "",
      link: item.link || "",
      pubDate: item.pubDate || new Date().toISOString(),
      source: sourceKey,
      category: source.category,
    }));
    
    return newsItems;
  } catch (error) {
    console.error(`抓取RSS失败 (${sourceKey}):`, error);
    return [];
  }
}

// 获取模拟新闻（按行业生成，用于兜底演示）
function getMockNewsForIndustry(industry: string): NewsItem[] {
  const mockSources = [
    "人民网", "新华网", "央视新闻", "中国新闻网",
    "新浪财经", "网易财经", "腾讯财经", "36氪", "钛媒体", "虎嗅",
    "亿邦动力", "联商网", "亿欧网", "创业邦", "投资界",
    "华尔街见闻", "FT中文网", "路透中文网"
  ];
  
  const now = Date.now();
  const rand = (max: number) => Math.floor(Math.random() * max);
  
  const mockItems: { title: string; desc: string }[] = [
    { title: `${industry}品牌「星途」完成${rand(10) + 1}亿元A轮融资`, desc: `${industry}新势力品牌「星途」宣布完成${rand(10) + 1}亿元A轮融资，投资方包括红杉资本、高瓴资本。资金将用于产品研发、品牌建设和市场推广。` },
    { title: `${industry}科技公司「智造未来」发布全新AI产品线`, desc: `${industry}科技公司「智造未来」在深圳举办新品发布会，推出基于AI大模型的全新${industry}产品线。公司计划在各大平台进行大规模广告投放。` },
    { title: `国际巨头「GlobalTech」正式进军中国${industry}市场`, desc: `国际巨头「GlobalTech」在上海举办品牌发布会，宣布正式进入中国${industry}市场。已在中国设立总部，计划投入巨额广告预算。` },
    { title: `${industry}创新企业「微光科技」获得腾讯战略投资`, desc: `${industry}创新企业「微光科技」获得腾讯战略投资，双方将在${industry}数字化领域展开深度合作。资金用于产品迭代和市场拓展。` },
    { title: `${industry}新锐品牌「东方美集」在杭州举办开业仪式`, desc: `${industry}新锐品牌「东方美集」在杭州举办旗舰店开业仪式，品牌创始人表示将深耕中国市场，计划在一二线城市开设更多实体店。` },
    { title: `${industry}科技企业「数据星河」完成数千万美元B轮融资`, desc: `${industry}科技企业「数据星河」完成数千万美元B轮融资，由IDG资本领投。资金用于技术研发和海外市场拓展。` },
    { title: `${industry}独角兽「云科技」发布全球首款${industry}大模型`, desc: `${industry}独角兽企业「云科技」在北京发布全球首款${industry}领域大模型，性能超越国际同类产品。计划在全球进行品牌推广。` },
    { title: `日本品牌「樱花社」登陆中国${industry}市场`, desc: `日本${industry}品牌「樱花社」在上海举办入华发布会，宣布进入中国市场，并签约一线明星作为品牌代言人。` },
    { title: `${industry}初创公司「创想者」完成天使轮融资`, desc: `${industry}初创公司「创想者」完成数千万元天使轮融资，由真格基金领投。团队致力于打造新一代${industry}产品。` },
    { title: `${industry}企业「华信科技」在成都设立西南总部`, desc: `${industry}企业「华信科技」在成都举行西南总部揭牌仪式，正式布局西南市场。公司表示将加大在西南地区的广告投放。` },
    { title: `${industry}品牌「浪潮科技」在纽约举办全球新品发布会`, desc: `${industry}品牌「浪潮科技」在纽约举办全球新品发布会，推出多款面向海外市场的新产品。` },
    { title: `${industry}技术服务商「易连接」获得亿元B+轮融资`, desc: `${industry}技术服务商「易连接」获得亿元B+轮融资，投资方包括阿里巴巴和红杉资本。公司计划加大在广告技术领域的研发投入。` },
    { title: `韩国品牌「韩流科技」在天津设立中国分公司`, desc: `韩国${industry}品牌「韩流科技」在天津设立中国分公司，正式布局中国市场。品牌已与多家本地广告代理公司达成合作。` },
    { title: `${industry}创业公司「明镜科技」发布旗下首款产品`, desc: `${industry}创业公司「明镜科技」发布旗下首款产品，主打${["科技感", "人性化", "智能化"][rand(3)]}概念，已获得多家机构投资意向。` },
    { title: `${industry}企业「恒达科技」成功登陆科创板`, desc: `${industry}企业「恒达科技」在科创板成功上市，开盘大涨120%。公司表示将利用募集资金加大研发投入和品牌建设。` },
    { title: `${industry}品牌「新物种」在全国十大城市开设线下体验店`, desc: `${industry}新锐品牌「新物种」宣布在全国十大城市同步开设线下体验店，品牌方表示将线上线下联动进行全渠道广告投放。` },
    { title: `${industry}科技公司「极速科技」完成Pre-IPO轮融资`, desc: `${industry}科技公司「极速科技」完成Pre-IPO轮融资，估值达百亿。公司计划明年在港交所上市，正加大品牌广告投入。` },
    { title: `${industry}品牌「智造家」在上海举办品牌升级发布会`, desc: `${industry}品牌「智造家」在上海举办品牌升级发布会，推出全新品牌形象和产品线。公司计划在主流视频平台进行品牌广告投放。` },
    { title: `法国品牌「浪漫之旅」宣布进入中国${industry}市场`, desc: `法国${industry}品牌「浪漫之旅」在上海举办入华发布会，宣布通过跨境电商和线下渠道进入中国市场。已签约中国明星担任品牌大使。` },
    { title: `${industry}初创企业「微创新」获红杉资本种子轮投资`, desc: `${industry}初创企业「微创新」宣布获得红杉资本种子轮投资，团队来自知名互联网公司。公司正在开发新一代${industry}解决方案。` },
  ];
  
  return mockItems.map((item) => ({
    title: item.title.replace(/\$\{industry\}/g, industry),
    description: item.desc.replace(/\$\{industry\}/g, industry),
    link: `https://example.com/${encodeURIComponent(industry)}-news-${now}-${rand(9999)}`,
    pubDate: new Date(now - rand(7) * 86400000).toISOString(),
    source: mockSources[rand(mockSources.length)],
    category: industry,
  }));
}

// 从所有源抓取新闻
export async function fetchAllNews(): Promise<NewsItem[]> {
  const allNews: NewsItem[] = [];
  const sourceKeys = Object.keys(NEWS_SOURCES);
  
  for (const sourceKey of sourceKeys) {
    const news = await fetchNewsFromRSS(sourceKey);
    allNews.push(...news);
    
    // 避免请求过快
    await new Promise(resolve => setTimeout(resolve, 100));
  }
  
  return allNews;
}

// 获取新闻（网页抓取优先，RSS作为后备，模拟数据用于演示）
export async function fetchNewsWithMock(targetIndustry: string): Promise<NewsItem[]> {
  // 方案A: 从网页抓取
  const webNews = await fetchNewsFromWeb();
  
  if (webNews.length >= 50) {
    // 网页数据够了，直接用
    console.log(`✅ 使用网页抓取数据: ${webNews.length} 条`);
    return webNews;
  }
  
  // 方案B: RSS抓取
  console.log(`📡 网页数据不足(${webNews.length}), 尝试RSS补充...`);
  const realNews = await fetchAllNews();
  const combined = [...webNews, ...realNews];
  
  if (combined.length >= 30) {
    console.log(`✅ 网页+RSS数据: ${combined.length} 条`);
    return combined;
  }
  
  // 方案C: 模拟数据兜底
  console.log(`📦 真实数据不足(${combined.length}), 使用模拟数据补充`);
  const mockNews = getMockNewsForIndustry(targetIndustry);
  return [...combined, ...mockNews];
}

// 关键词匹配（简单版本，实际应该用LLM分析）
function matchKeywords(text: string, keywords: string[]): boolean {
  const lowerText = text.toLowerCase();
  return keywords.some(keyword => lowerText.includes(keyword.toLowerCase()));
}

// 分析新闻是否为商机
export function analyzeOpportunity(news: NewsItem, targetIndustry: string, allIndustries: boolean = false): Opportunity | null {
  const { title, description } = news;
  const fullText = `${title} ${description}`;
  
  // 如果不是全行业模式，检查是否与目标行业相关
  if (!allIndustries) {
    const industryKeywords = getIndustryKeywords(targetIndustry);
    if (!matchKeywords(fullText, industryKeywords)) {
      return null;
    }
  }
  
  // 计算综合得分，选最高分的商机类型
  let best: Opportunity | null = null;
  let bestScore = 0;

  // 1. 新产品发布
  const newProductKeywords = ["新品", "上市", "发布", "推出", "首发", "限定", "联名", "新款"];
  const productsScore = scoreByKeywords(fullText, newProductKeywords);
  if (productsScore > 0) {
    const company = extractCompanyName(fullText);
    const product = extractProductName(fullText);
    const score = 60 + productsScore * 5;
    if (score > bestScore) {
      bestScore = score;
      best = {
        type: OpportunityType.NEW_PRODUCT,
        company: company || "未知品牌",
        title: news.title,
        summary: news.description.substring(0, 200),
        link: news.link,
        confidence: Math.min(score, 90),
        details: { 
          industry: allIndustries ? "全行业" : targetIndustry,
          product: product || "新产品",
        },
      };
    }
  }
  
  // 2. 获得融资
  const fundingKeywords = ["融资", "投资", "获投", "募资", "千万", "百万", "亿元", "美元", "人民币"];
  const fundingScore = scoreByKeywords(fullText, fundingKeywords);
  if (fundingScore > 0) {
    const company = extractCompanyName(fullText);
    const amount = extractFundingAmount(fullText);
    const score = 65 + fundingScore * 5;
    if (score > bestScore) {
      bestScore = score;
      best = {
        type: OpportunityType.NEW_FUNDING,
        company: company || "未知公司",
        title: news.title,
        summary: news.description.substring(0, 200),
        link: news.link,
        confidence: Math.min(score, 90),
        details: { 
          industry: allIndustries ? "全行业" : targetIndustry,
          amount: amount || "未披露金额",
        },
      };
    }
  }
  
  // 3. 开拓新市场
  const newMarketKeywords = ["进军", "开拓", "布局", "进入", "落户", "设立", "分公司", "办事处", "新市场"];
  const marketScore = scoreByKeywords(fullText, newMarketKeywords);
  if (marketScore > 0) {
    const company = extractCompanyName(fullText);
    const region = extractRegion(fullText);
    const score = 60 + marketScore * 5;
    if (score > bestScore) {
      bestScore = score;
      best = {
        type: OpportunityType.NEW_MARKET,
        company: company || "未知公司",
        title: news.title,
        summary: news.description.substring(0, 200),
        link: news.link,
        confidence: Math.min(score, 90),
        details: { 
          industry: allIndustries ? "全行业" : targetIndustry,
          region: region || "新区域",
        },
      };
    }
  }
  
  // 用旧代码做fallback（保留新公司成立判断逻辑）
  const newCompanyKeywords = [
    "发布会", "新品发布", "品牌发布", "产品发布", "正式发布", "全球首发",
    "首次亮相", "正式亮相", "公开亮相", "首次公开", "正式推出",
    "进军中国", "进入中国", "登陆中国", "入华", "来华", "在华设立",
    "外资企业", "国际品牌", "海外品牌", "跨国企业",
    "获得投资", "获得融资", "完成融资", "融资成功", "投资方包括",
    "红杉资本", "高瓴资本", "IDG资本", "腾讯投资", "阿里巴巴投资",
    "签约", "代言", "品牌大使", "形象代言", "合作明星",
    "盛大开业", "隆重开业", "旗舰店开业", "体验店开业", "概念店"
  ];
  const newCompanyScore = scoreByKeywords(fullText, newCompanyKeywords);
  if (newCompanyScore > 0) {
    const company = extractCompanyName(fullText);
    const score = 65 + newCompanyScore * 3;
    if (score > bestScore) {
      bestScore = score;
      best = {
        type: OpportunityType.NEW_COMPANY,
        company: company || "未知公司",
        title: news.title,
        summary: news.description.substring(0, 200),
        link: news.link,
        confidence: Math.min(score, 95),
        details: { 
          industry: allIndustries ? "全行业" : targetIndustry,
        },
      };
    }
  }

  return best;
}

// 按关键词命中数打分
function scoreByKeywords(text: string, keywords: string[]): number {
  const lowerText = text.toLowerCase();
  let hits = 0;
  for (const kw of keywords) {
    if (lowerText.includes(kw.toLowerCase())) hits++;
  }
  return hits;
}

// 提取公司名称（简化版）
function extractCompanyName(text: string): string {
  // 简单提取：找引号内的内容或特定模式
  const quoteMatch = text.match(/["']([^"']+)["']/);
  if (quoteMatch) return quoteMatch[1];
  
  // 找"XX公司"模式
  const companyMatch = text.match(/([\u4e00-\u9fa5]{2,10})(公司|科技|集团|有限|股份)/);
  if (companyMatch) return companyMatch[1] + companyMatch[2];
  
  return "";
}

// 提取产品名称
function extractProductName(text: string): string {
  const productMatch = text.match(/推出(?:了)?([\u4e00-\u9fa5a-zA-Z0-9]{2,20})/);
  return productMatch ? productMatch[1] : "";
}

// 提取融资金额
function extractFundingAmount(text: string): string {
  const amountMatch = text.match(/(\d+(?:\.\d+)?)(?:千万|百万|亿|万)?(?:元|美元|人民币)/);
  return amountMatch ? `${amountMatch[1]}${text.includes('千万') ? '千万' : text.includes('百万') ? '百万' : text.includes('亿') ? '亿' : text.includes('万') ? '万' : ''}${text.includes('美元') ? '美元' : '元'}` : "";
}

// 提取区域
function extractRegion(text: string): string {
  const regions = ["上海", "北京", "深圳", "广州", "杭州", "成都", "重庆", "武汉", "南京", "苏州", "西安", "郑州", "长沙", "天津", "青岛", "厦门", "宁波", "无锡", "佛山", "东莞", "华东", "华北", "华南", "西南", "华中", "西北", "东北"];
  
  for (const region of regions) {
    if (text.includes(region)) {
      return region;
    }
  }
  
  return "";
}

// 提取外资来源地
function extractForeignOrigin(text: string): string {
  const origins = ["美国", "日本", "韩国", "法国", "德国", "英国", "意大利", "瑞士", "瑞典", "丹麦", "荷兰", "西班牙", "澳大利亚", "加拿大", "新加坡", "泰国", "马来西亚"];
  
  for (const origin of origins) {
    if (text.includes(origin)) {
      return origin;
    }
  }
  
  // 尝试匹配"XX品牌"模式
  const brandMatch = text.match(/([美日韩法德英意瑞瑞丹荷西澳加新泰马])[国品牌]/);
  if (brandMatch) {
    return brandMatch[1] + "国";
  }
  
  return "海外";
}

// 提取投资机构
function extractInvestors(text: string): string[] {
  const investors: string[] = [];
  const investorKeywords = [
    "红杉资本", "高瓴资本", "IDG资本", "腾讯投资", "阿里巴巴", "阿里投资",
    "字节跳动", "美团", "京东", "百度", "小米", "顺为资本", "源码资本",
    "今日资本", "经纬中国", "真格基金", "创新工场", "启明创投", "GGV纪源资本"
  ];
  
  for (const investor of investorKeywords) {
    if (text.includes(investor)) {
      investors.push(investor);
    }
  }
  
  return investors;
}

// 提取发布会类型
function extractEventType(text: string): string {
  if (text.includes("新品发布")) return "新品发布会";
  if (text.includes("品牌发布")) return "品牌发布会";
  if (text.includes("战略发布")) return "战略发布会";
  if (text.includes("技术发布")) return "技术发布会";
  if (text.includes("全球首发")) return "全球首发会";
  return "发布会";
}

// 获取行业关键词
function getIndustryKeywords(industry: string): string[] {
  const industryMap: Record<string, string[]> = {
    "汽车": ["汽车", "新能源", "电动车", "自动驾驶", "造车", "车企", "4S店", "二手车"],
    "美妆": ["美妆", "化妆品", "护肤", "彩妆", "香水", "个护", "美容", "护肤品", "美妆品牌", "化妆品品牌"],
    "化妆品": ["化妆品", "美妆", "护肤", "彩妆", "香水", "个护", "美容", "护肤品", "化妆品品牌", "美妆品牌"],
    "人工智能": ["AI", "人工智能", "机器学习", "深度学习", "大模型", "ChatGPT", "AIGC"],
    "科技": ["科技", "互联网", "IT", "软件", "硬件", "智能", "数字化", "云计算"],
    "金融": ["金融", "银行", "保险", "证券", "投资", "理财", "支付", "信贷"],
    "医疗": ["医疗", "医药", "健康", "医院", "药品", "器械", "生物", "基因"],
    "教育": ["教育", "培训", "学校", "在线教育", "K12", "职业教育", "留学"],
    "消费": ["消费", "零售", "电商", "购物", "品牌", "消费品", "快消", "餐饮"],
    "饮料": ["饮料", "饮品", "瓶装水", "奶茶", "新茶饮", "果汁", "气泡水", "功能饮料", "碳酸饮料", "饮用水", "咖啡", "可可", "乳饮", "豆奶", "椰奶", "电解质"],
    "食品": ["食品", "零食", "糕点", "饼干", "膨化", "速食", "预制菜", "冷冻", "调味品", "粮油", "乳制品", "肉制品", "方便面"],
    "酒": ["白酒", "啤酒", "红酒", "葡萄酒", "洋酒", "黄酒", "果酒", "精酿", "茅台", "五粮液", "酒类", "酒水"],
    "房地产": ["房地产", "房产", "地产", "楼盘", "物业", "租房", "买房", "开发商"],
    "旅游": ["旅游", "旅行", "酒店", "机票", "景区", "民宿", "度假", "旅行社"],
  };
  
  // 尝试精确匹配
  if (industryMap[industry]) {
    return industryMap[industry];
  }
  
  // 尝试模糊匹配
  for (const [key, keywords] of Object.entries(industryMap)) {
    if (industry.includes(key) || key.includes(industry)) {
      return keywords;
    }
  }
  
  // 默认返回行业名称
  return [industry];
}

// 批量分析新闻，找出商机
export async function findOpportunities(
  targetIndustry: string, 
  limit: number = 20,
  allIndustries: boolean = false
): Promise<Opportunity[]> {
  const label = allIndustries ? "全行业" : targetIndustry;
  console.log(`开始查找 ${label} 商机...`);
  
  const allNews = await fetchNewsWithMock(targetIndustry);
  console.log(`共获取 ${allNews.length} 条新闻（含模拟数据）`);
  
  // 全行业模式：取每种类型固定数量
  const typeLimits: Record<string, number> = {
    [OpportunityType.NEW_COMPANY]: allIndustries ? 4 : 5,
    [OpportunityType.NEW_PRODUCT]: allIndustries ? 8 : 5,
    [OpportunityType.NEW_FUNDING]: allIndustries ? 1 : 5,
    [OpportunityType.NEW_MARKET]: allIndustries ? 2 : 5,
  };
  
  // 收集所有候选，按类型分组
  const candidates: Record<string, { opportunity: Opportunity; score: number }[]> = {
    [OpportunityType.NEW_COMPANY]: [],
    [OpportunityType.NEW_PRODUCT]: [],
    [OpportunityType.NEW_FUNDING]: [],
    [OpportunityType.NEW_MARKET]: [],
  };
  
  for (const news of allNews) {
    const opportunity = analyzeOpportunity(news, targetIndustry, allIndustries);
    if (opportunity && candidates[opportunity.type]) {
      candidates[opportunity.type].push({
        opportunity,
        score: opportunity.confidence,
      });
    }
  }
  
  // 每种类型按置信度排序，取指定数量
  const opportunities: Opportunity[] = [];
  for (const [type, items] of Object.entries(candidates)) {
    items.sort((a, b) => b.score - a.score);
    const limit = typeLimits[type] || 5;
    opportunities.push(...items.slice(0, limit).map(c => c.opportunity));
  }
  
  // 最终按置信度排序
  opportunities.sort((a, b) => b.confidence - a.confidence);
  
  console.log(`找到 ${opportunities.length} 个${label}商机`);
  return opportunities;
}