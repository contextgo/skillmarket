/**
 * 真正的自动邮件发送器
 * 使用系统sendmail命令发送邮件（无需配置）
 */

import { exec } from 'child_process';
import fs from 'fs';
import path from 'path';
import { promisify } from 'util';

const execAsync = promisify(exec);

// 使用系统sendmail发送邮件（最可靠的方式）
export async function sendRealEmail(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<boolean> {
  try {
    console.log(`📧 正在发送邮件到: ${to}`);
    console.log(`📋 主题: ${subject}`);
    
    // 方法1：使用sendmail命令（Unix/Linux/macOS系统自带）
    const sendmailPath = '/usr/sbin/sendmail';
    
    if (fs.existsSync(sendmailPath)) {
      return await sendWithSendmail(to, subject, html, text);
    }
    
    // 方法2：使用mail命令（macOS自带）
    const mailPath = '/usr/bin/mail';
    if (fs.existsSync(mailPath)) {
      return await sendWithMailCommand(to, subject, text);
    }
    
    // 方法3：使用Python的smtplib（跨平台）
    return await sendWithPython(to, subject, html, text);
    
  } catch (error: any) {
    console.error('❌ 邮件发送失败:', error.message);
    
    // 最后的手段：生成邮件文件，让用户手动发送
    return await createEmailFile(to, subject, html, text);
  }
}

// 方法1：使用sendmail命令
async function sendWithSendmail(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<boolean> {
  try {
    // 创建邮件内容
    const emailContent = `From: "广告主新客猎手" <noreply@ad-hunter.com>
To: ${to}
Subject: ${subject}
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: 8bit

${html}`;
    
    // 临时文件
    const tempFile = path.join('/tmp', `email-${Date.now()}.txt`);
    fs.writeFileSync(tempFile, emailContent, 'utf-8');
    
    // 使用sendmail发送
    const sendmailPath = '/usr/sbin/sendmail';
    const command = `cat "${tempFile}" | ${sendmailPath} -t`;
    await execAsync(command);
    
    // 清理临时文件
    fs.unlinkSync(tempFile);
    
    console.log('✅ 邮件已通过sendmail发送！');
    return true;
    
  } catch (error: any) {
    console.error('sendmail发送失败:', error.message);
    return false;
  }
}

// 方法2：使用mail命令（简单文本邮件）
async function sendWithMailCommand(
  to: string,
  subject: string,
  text: string
): Promise<boolean> {
  try {
    // 截取前1000字符（mail命令限制）
    const shortText = text.substring(0, 1000);
    
    const command = `echo "${shortText.replace(/"/g, '\\"')}" | mail -s "${subject}" "${to}"`;
    await execAsync(command);
    
    console.log('✅ 邮件已通过mail命令发送！');
    return true;
    
  } catch (error: any) {
    console.error('mail命令发送失败:', error.message);
    return false;
  }
}

// 方法3：使用Python发送（跨平台）
async function sendWithPython(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<boolean> {
  try {
    // 创建Python脚本
    const pythonScript = `
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import sys

to_email = "${to}"
subject = "${subject.replace(/"/g, '\\"')}"
html_content = """${html.replace(/"/g, '\\"')}"""
text_content = """${text.substring(0, 1000).replace(/"/g, '\\"')}"""

# 创建邮件
msg = MIMEMultipart('alternative')
msg['Subject'] = subject
msg['From'] = '广告主新客猎手 <noreply@ad-hunter.com>'
msg['To'] = to_email

# 添加文本和HTML版本
part1 = MIMEText(text_content, 'plain')
part2 = MIMEText(html_content, 'html')
msg.attach(part1)
msg.attach(part2)

try:
    # 尝试使用本地sendmail
    import subprocess
    sendmail = subprocess.Popen(["/usr/sbin/sendmail", "-t"], stdin=subprocess.PIPE)
    sendmail.communicate(msg.as_string().encode())
    print("邮件发送成功（通过sendmail）")
    sys.exit(0)
except:
    # 尝试使用Gmail SMTP（需要配置）
    print("无法通过sendmail发送，请配置SMTP")
    sys.exit(1)
`;
    
    const scriptFile = path.join('/tmp', `send-email-${Date.now()}.py`);
    fs.writeFileSync(scriptFile, pythonScript, 'utf-8');
    
    const command = `python3 "${scriptFile}"`;
    const { stdout, stderr } = await execAsync(command);
    
    if (stdout.includes('邮件发送成功')) {
      console.log('✅ 邮件已通过Python发送！');
      fs.unlinkSync(scriptFile);
      return true;
    }
    
    fs.unlinkSync(scriptFile);
    return false;
    
  } catch (error: any) {
    console.error('Python发送失败:', error.message);
    return false;
  }
}

// 方法4：使用curl调用邮件API（最可靠）
async function sendWithCurlAPI(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<boolean> {
  try {
    console.log('📧 尝试通过邮件API发送...');
    
    // 使用一个公开的邮件发送API（示例）
    // 实际使用时需要注册相应的服务
    
    // 保存HTML到临时文件
    const tempHtmlFile = path.join('/tmp', `email-${Date.now()}.html`);
    fs.writeFileSync(tempHtmlFile, html, 'utf-8');
    
    // 使用curl发送（示例命令）
    const curlCommand = `curl -X POST https://api.example.com/send-email \
      -H "Content-Type: application/json" \
      -d '{
        "to": "${to}",
        "subject": "${subject}",
        "html": "${html.substring(0, 100).replace(/"/g, '\\"')}...",
        "text": "${text.substring(0, 200).replace(/"/g, '\\"')}..."
      }'`;
    
    console.log('💡 邮件API发送命令（示例）:');
    console.log(curlCommand);
    
    // 在实际环境中，这里应该调用真实的邮件API
    // 例如：SendGrid、Mailgun、Amazon SES等
    
    // 暂时返回false，表示需要用户操作
    return false;
    
  } catch (error: any) {
    console.error('邮件API发送失败:', error.message);
    return false;
  }
}

// 方法5：生成邮件文件（最后的手段）
async function createEmailFile(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<boolean> {
  try {
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const outputDir = path.join(process.cwd(), 'emails-to-send');
    
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    // 创建邮件文件
    const emailFile = path.join(outputDir, `email-${timestamp}.eml`);
    const emailContent = `To: ${to}
Subject: ${subject}
Content-Type: text/html; charset=UTF-8

${html}`;
    
    fs.writeFileSync(emailFile, emailContent, 'utf-8');
    
    // 创建发送脚本
    const scriptContent = `#!/bin/bash
echo "请使用以下命令发送邮件："
echo ""
echo "方法1：使用sendmail"
echo "  cat '${emailFile}' | /usr/sbin/sendmail -t"
echo ""
echo "方法2：使用mail命令"
echo "  mail -s '${subject}' ${to} < '${emailFile}'"
echo ""
echo "方法3：手动复制到邮件客户端"
echo "  收件人: ${to}"
echo "  主题: ${subject}"
echo "  内容: 查看附件HTML"
echo ""
echo "邮件文件: ${emailFile}"
`;
    
    const scriptFile = path.join(outputDir, `send-instructions-${timestamp}.sh`);
    fs.writeFileSync(scriptFile, scriptContent, 'utf-8');
    fs.chmodSync(scriptFile, '755');
    
    console.log(`📁 邮件已保存到: ${emailFile}`);
    console.log(`📝 发送指引: ${scriptFile}`);
    console.log('💡 请运行发送指引脚本查看发送方法');
    
    return false; // 标记为需要手动发送
    
  } catch (error: any) {
    console.error('创建邮件文件失败:', error.message);
    return false;
  }
}

// 测试邮件发送功能
export async function testEmailSending(): Promise<boolean> {
  console.log('🔧 测试邮件发送功能...');
  
  // 测试sendmail
  const sendmailPath = '/usr/sbin/sendmail';
  const mailPath = '/usr/bin/mail';
  
  console.log(`📋 系统检查:`);
  console.log(`  • sendmail: ${fs.existsSync(sendmailPath) ? '✅ 可用' : '❌ 不可用'}`);
  console.log(`  • mail命令: ${fs.existsSync(mailPath) ? '✅ 可用' : '❌ 不可用'}`);
  
  // 检查Python
  try {
    await execAsync('python3 --version');
    console.log('  • Python3: ✅ 可用');
  } catch {
    console.log('  • Python3: ❌ 不可用');
  }
  
  // 尝试发送测试邮件
  console.log('\n🚀 尝试发送测试邮件...');
  
  const testTo = '86951394@qq.com';
  const testSubject = '广告主新客猎手 - 测试邮件';
  const testText = '这是一封测试邮件，确认邮件发送功能正常工作。';
  const testHtml = '<h1>测试邮件</h1><p>这是一封测试邮件。</p>';
  
  return await sendRealEmail(testTo, testSubject, testHtml, testText);
}