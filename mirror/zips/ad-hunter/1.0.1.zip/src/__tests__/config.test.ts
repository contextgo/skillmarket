import { 
  saveUserConfig, 
  loadUserConfig, 
  updateUserConfig, 
  deleteUserConfig,
  hasUserConfig,
  getAllUserConfigs 
} from '../config';

// 模拟文件系统
jest.mock('fs', () => ({
  existsSync: jest.fn(),
  mkdirSync: jest.fn(),
  writeFileSync: jest.fn(),
  readFileSync: jest.fn(),
  unlinkSync: jest.fn(),
  readdirSync: jest.fn(),
}));

import fs from 'fs';

describe('配置管理', () => {
  const mockUserId = 'test-user-123';
  const mockConfig = {
    userId: mockUserId,
    industry: '汽车',
    email: 'test@example.com',
    sendTime: '08:30',
  };

  beforeEach(() => {
    jest.clearAllMocks();
  });

  test('保存用户配置', () => {
    (fs.existsSync as jest.Mock).mockReturnValue(false);
    
    saveUserConfig(mockConfig);
    
    expect(fs.mkdirSync).toHaveBeenCalled();
    expect(fs.writeFileSync).toHaveBeenCalled();
    
    const writeCall = (fs.writeFileSync as jest.Mock).mock.calls[0];
    const writtenData = JSON.parse(writeCall[1]);
    
    expect(writtenData.userId).toBe(mockUserId);
    expect(writtenData.industry).toBe('汽车');
    expect(writtenData.email).toBe('test@example.com');
    expect(writtenData.sendTime).toBe('08:30');
    expect(writtenData.createdAt).toBeDefined();
    expect(writtenData.updatedAt).toBeDefined();
  });

  test('加载用户配置', () => {
    const mockConfigData = JSON.stringify({
      ...mockConfig,
      createdAt: '2024-01-01T00:00:00Z',
      updatedAt: '2024-01-01T00:00:00Z',
    });
    
    (fs.existsSync as jest.Mock).mockReturnValue(true);
    (fs.readFileSync as jest.Mock).mockReturnValue(mockConfigData);
    
    const loadedConfig = loadUserConfig(mockUserId);
    
    expect(loadedConfig).not.toBeNull();
    expect(loadedConfig!.userId).toBe(mockUserId);
    expect(loadedConfig!.industry).toBe('汽车');
  });

  test('加载不存在的配置返回null', () => {
    (fs.existsSync as jest.Mock).mockReturnValue(false);
    
    const loadedConfig = loadUserConfig('non-existent-user');
    
    expect(loadedConfig).toBeNull();
  });

  test('更新用户配置', () => {
    const existingConfig = {
      ...mockConfig,
      createdAt: '2024-01-01T00:00:00Z',
      updatedAt: '2024-01-01T00:00:00Z',
    };
    
    (fs.existsSync as jest.Mock).mockReturnValue(true);
    (fs.readFileSync as jest.Mock).mockReturnValue(JSON.stringify(existingConfig));
    
    const updatedConfig = updateUserConfig(mockUserId, {
      industry: '美妆',
      sendTime: '09:00',
    });
    
    expect(updatedConfig).not.toBeNull();
    expect(updatedConfig!.industry).toBe('美妆');
    expect(updatedConfig!.sendTime).toBe('09:00');
    expect(updatedConfig!.email).toBe('test@example.com'); // 保持不变
    expect(updatedConfig!.updatedAt).not.toBe('2024-01-01T00:00:00Z'); // 应该更新
  });

  test('更新不存在的配置返回null', () => {
    (fs.existsSync as jest.Mock).mockReturnValue(false);
    
    const updatedConfig = updateUserConfig('non-existent-user', {
      industry: '美妆',
    });
    
    expect(updatedConfig).toBeNull();
  });

  test('检查用户配置是否存在', () => {
    (fs.existsSync as jest.Mock)
      .mockReturnValueOnce(true)  // 第一次调用
      .mockReturnValueOnce(false); // 第二次调用
    
    expect(hasUserConfig(mockUserId)).toBe(true);
    expect(hasUserConfig('non-existent-user')).toBe(false);
  });

  test('删除用户配置', () => {
    (fs.existsSync as jest.Mock).mockReturnValue(true);
    
    const deleted = deleteUserConfig(mockUserId);
    
    expect(deleted).toBe(true);
    expect(fs.unlinkSync).toHaveBeenCalled();
  });

  test('删除不存在的配置返回false', () => {
    (fs.existsSync as jest.Mock).mockReturnValue(false);
    
    const deleted = deleteUserConfig('non-existent-user');
    
    expect(deleted).toBe(false);
    expect(fs.unlinkSync).not.toHaveBeenCalled();
  });

  test('获取所有用户配置', () => {
    const mockFiles = ['user1.json', 'user2.json'];
    const mockConfig1 = JSON.stringify({
      userId: 'user1',
      industry: '汽车',
      email: 'user1@example.com',
      sendTime: '08:00',
      createdAt: '2024-01-01T00:00:00Z',
      updatedAt: '2024-01-01T00:00:00Z',
    });
    const mockConfig2 = JSON.stringify({
      userId: 'user2',
      industry: '美妆',
      email: 'user2@example.com',
      sendTime: '09:00',
      createdAt: '2024-01-01T00:00:00Z',
      updatedAt: '2024-01-01T00:00:00Z',
    });
    
    (fs.readdirSync as jest.Mock).mockReturnValue(mockFiles);
    (fs.existsSync as jest.Mock).mockReturnValue(true);
    (fs.readFileSync as jest.Mock)
      .mockReturnValueOnce(mockConfig1)
      .mockReturnValueOnce(mockConfig2);
    
    const allConfigs = getAllUserConfigs();
    
    expect(allConfigs).toHaveLength(2);
    expect(allConfigs[0].userId).toBe('user1');
    expect(allConfigs[0].industry).toBe('汽车');
    expect(allConfigs[1].userId).toBe('user2');
    expect(allConfigs[1].industry).toBe('美妆');
  });
});