#!/usr/bin/env node

import { program } from 'commander';
import fs from 'fs';
import path from 'path';
import { 
  start_ad_hunter,
  complete_ad_hunter_setup,
  run_ad_hunter_now, 
  update_ad_hunter_config, 
  check_ad_hunter_status,
  daily_ad_hunter_task 
} from './tools.js';

program
  .name('ad-hunter')
  .description('广告主新客猎手 - 每日自动扫描指定行业内的新公司、新产品、新融资、新市场新闻')
  .version('1.0.0');

// 第一步：开始使用（输入行业，立即搜索）
program
  .command('start')
  .description('开始使用广告主新客猎手。输入行业，立即搜索商机')
  .requiredOption('-i, --industry <industry>', '监控行业，例如：汽车、美妆、人工智能、科技、金融等')
  .action(async (options) => {
    try {
      const result = await start_ad_hunter.handler({
        industry: options.industry,
      });
      
      console.log(result.result);
      if (result.tempUserId) {
        console.log(`\n💡 临时用户ID: ${result.tempUserId}`);
        console.log(`📧 下一步: ad-hunter complete -u ${result.tempUserId} -e your-email@example.com`);
      }
    } catch (error) {
      console.error('开始失败:', error);
      process.exit(1);
    }
  });

// 第二步：完成设置（输入邮箱和发送时间）
program
  .command('complete')
  .description('完成广告主新客猎手设置。提供邮箱和发送时间')
  .requiredOption('-u, --user-id <id>', '临时用户ID（从start命令获取）')
  .requiredOption('-e, --email <email>', '接收每日报告的邮箱地址')
  .option('-t, --send-time <time>', '每日发送时间，格式HH:mm，默认08:00', '08:00')
  .action(async (options) => {
    try {
      const result = await complete_ad_hunter_setup.handler({
        userId: options.userId,
        email: options.email,
        sendTime: options.sendTime,
      });
      
      console.log(result.result);
    } catch (error) {
      console.error('完成设置失败:', error);
      process.exit(1);
    }
  });

// 立即运行命令
program
  .command('run')
  .description('立即运行广告主新客猎手')
  .requiredOption('-u, --user-id <id>', '用户ID')
  .action(async (options) => {
    try {
      const result = await run_ad_hunter_now.handler({
        userId: options.userId,
      });
      
      console.log(result.result);
    } catch (error) {
      console.error('运行失败:', error);
      process.exit(1);
    }
  });

// 修改配置命令
program
  .command('update')
  .description('修改配置')
  .requiredOption('-u, --user-id <id>', '用户ID')
  .option('-i, --industry <industry>', '新的监控行业')
  .option('-e, --email <email>', '新的接收邮箱')
  .option('-t, --send-time <time>', '新的发送时间，格式HH:mm')
  .action(async (options) => {
    try {
      const updates: any = {};
      if (options.industry) updates.industry = options.industry;
      if (options.email) updates.email = options.email;
      if (options.sendTime) updates.sendTime = options.sendTime;
      
      const result = await update_ad_hunter_config.handler({
        userId: options.userId,
        ...updates,
      });
      
      console.log(result.result);
    } catch (error) {
      console.error('修改配置失败:', error);
      process.exit(1);
    }
  });

// 检查状态命令
program
  .command('status')
  .description('检查当前状态')
  .requiredOption('-u, --user-id <id>', '用户ID')
  .action(async (options) => {
    try {
      const result = await check_ad_hunter_status.handler({
        userId: options.userId,
      });
      
      console.log(result.result);
    } catch (error) {
      console.error('检查状态失败:', error);
      process.exit(1);
    }
  });

// 每日任务命令（供cron调用）
program
  .command('daily-task')
  .description('运行每日定时任务（供cron调用）')
  .action(async () => {
    try {
      const result = await daily_ad_hunter_task.handler();
      console.log(result.result);
    } catch (error) {
      console.error('每日任务失败:', error);
      process.exit(1);
    }
  });

// 示例命令
program
  .command('example')
  .description('显示使用示例')
  .action(() => {
    console.log(`
广告主新客猎手使用示例：

1. 开始使用（输入行业，立即搜索）：
   $ ad-hunter start -i "汽车"
   → 系统立即搜索汽车行业商机，显示结果

2. 完成设置（输入邮箱，立即发送报告）：
   $ ad-hunter complete -u "temp_1234567890" -e "sales@example.com" -t "08:30"
   → 立即发送报告到邮箱，设置每日定时发送

3. 立即运行（随时获取最新商机）：
   $ ad-hunter run -u "user123"

4. 修改配置：
   $ ad-hunter update -u "user123" -i "美妆" -t "09:00"

5. 检查状态：
   $ ad-hunter status -u "user123"

6. 设置每日定时任务（OpenClaw cron）：
   $ ad-hunter daily-task

支持的行业示例：
• 汽车、美妆、人工智能、科技、金融、医疗、教育、消费、房地产、旅游

监控1个行业
    `);
  });

// 交互式设置向导
program
  .command('wizard')
  .description('交互式设置向导')
  .action(async () => {
    const readline = require('readline').createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    
    const ask = (question: string): Promise<string> => {
      return new Promise((resolve) => {
        readline.question(question, (answer: string) => {
          resolve(answer.trim());
        });
      });
    };
    
    try {
      console.log('🎯 广告主新客猎手设置向导\n');
      
      // 第一步：输入行业，立即搜索
      console.log('📊 第一步：选择监控行业');
      const industry = await ask('要监控哪个行业？（例如：汽车、美妆、人工智能）：');
      
      console.log(`\n🔍 正在搜索 ${industry} 行业的商机...`);
      const startResult = await start_ad_hunter.handler({ industry });
      
      console.log(startResult.result);
      
      // 第二步：输入邮箱和发送时间
      console.log('\n📧 第二步：设置每日报告');
      const email = await ask('接收每日报告的邮箱地址：');
      const sendTime = await ask('每日发送时间（格式HH:mm，默认08:00）：') || '08:00';
      
      if (!startResult.tempUserId) {
        throw new Error('未获取到临时用户ID');
      }
      
      console.log('\n✅ 正在完成设置...\n');
      
      const completeResult = await complete_ad_hunter_setup.handler({
        userId: startResult.tempUserId,
        email,
        sendTime,
      });
      
      console.log(completeResult.result);
      
    } catch (error) {
      console.error('设置失败:', error);
    } finally {
      readline.close();
    }
  });

program.parse();