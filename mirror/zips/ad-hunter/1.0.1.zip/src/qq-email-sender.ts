/**
 * QQ邮箱SMTP邮件发送器
 * 使用真正的QQ邮箱发送邮件
 */

import nodemailer from 'nodemailer';

// QQ邮箱SMTP配置
const QQ_EMAIL_CONFIG = {
  host: 'smtp.qq.com',
  port: 465,
  secure: true, // 使用SSL
  auth: {
    user: '86951394@qq.com', // 发件人邮箱
    pass: 'bnmoixtawvwwcaie' // QQ邮箱授权码
  }
};

// 创建邮件传输器
let transporter: nodemailer.Transporter | null = null;

function createTransporter() {
  if (!transporter) {
    transporter = nodemailer.createTransport(QQ_EMAIL_CONFIG);
    
    // 验证连接
    transporter.verify((error) => {
      if (error) {
        console.error('❌ QQ邮箱SMTP连接失败:', error.message);
        console.log('💡 请检查：');
        console.log('   1. 邮箱地址是否正确: 86951394@qq.com');
        console.log('   2. 授权码是否正确: bnmoixtawvwwcaie');
        console.log('   3. 是否开启了SMTP服务');
        transporter = null;
      } else {
        console.log('✅ QQ邮箱SMTP连接成功！');
      }
    });
  }
  return transporter;
}

/**
 * 使用QQ邮箱发送邮件
 */
export async function sendWithQQEmail(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<boolean> {
  try {
    console.log(`📧 使用QQ邮箱发送邮件到: ${to}`);
    console.log(`📋 主题: ${subject}`);
    console.log(`📊 内容长度: HTML=${html.length}字符, Text=${text.length}字符`);
    
    const transporter = createTransporter();
    if (!transporter) {
      throw new Error('邮件传输器未初始化');
    }
    
    // 邮件选项
    const mailOptions = {
      from: '"广告主新客猎手" <86951394@qq.com>',
      to: to,
      subject: subject,
      html: html,
      text: text,
      // 添加邮件头，避免被识别为垃圾邮件
      headers: {
        'X-Priority': '1',
        'X-MSMail-Priority': 'High',
        'Importance': 'high',
        'X-Mailer': '广告主新客猎手 v1.0'
      }
    };
    
    console.log('正在发送邮件...');
    const info = await transporter.sendMail(mailOptions);
    
    console.log(`✅ 邮件发送成功！`);
    console.log(`📨 消息ID: ${info.messageId}`);
    console.log(`📧 收件人: ${to}`);
    console.log(`⏰ 发送时间: ${new Date().toLocaleString()}`);
    
    return true;
    
  } catch (error: any) {
    console.error('❌ QQ邮箱发送失败:', error.message);
    
    // 详细错误信息
    if (error.code === 'EAUTH') {
      console.log('💡 认证失败，请检查：');
      console.log('   1. QQ邮箱授权码是否正确');
      console.log('   2. 是否开启了SMTP服务');
      console.log('   3. 授权码是否已过期');
    } else if (error.code === 'ECONNECTION') {
      console.log('💡 连接失败，请检查网络或SMTP配置');
    }
    
    return false;
  }
}

/**
 * 测试QQ邮箱连接
 */
export async function testQQEmailConnection(): Promise<boolean> {
  try {
    console.log('🔧 测试QQ邮箱SMTP连接...');
    
    const testTransporter = nodemailer.createTransport(QQ_EMAIL_CONFIG);
    
    // 验证连接
    await testTransporter.verify();
    console.log('✅ QQ邮箱SMTP连接测试成功！');
    
    // 发送测试邮件
    console.log('🚀 发送测试邮件...');
    const testInfo = await testTransporter.sendMail({
      from: '"广告主新客猎手" <86951394@qq.com>',
      to: '86951394@qq.com',
      subject: '广告主新客猎手 - SMTP连接测试',
      text: '这是一封测试邮件，确认QQ邮箱SMTP连接正常工作。\n\n发送时间: ' + new Date().toLocaleString(),
      html: '<h1>测试邮件</h1><p>这是一封测试邮件，确认QQ邮箱SMTP连接正常工作。</p><p>发送时间: ' + new Date().toLocaleString() + '</p>'
    });
    
    console.log(`✅ 测试邮件发送成功！消息ID: ${testInfo.messageId}`);
    console.log('💡 请检查QQ邮箱是否收到测试邮件');
    
    return true;
    
  } catch (error: any) {
    console.error('❌ QQ邮箱测试失败:', error.message);
    
    if (error.code === 'EAUTH') {
      console.log('\n🔑 **认证问题解决方案：**');
      console.log('1. 登录QQ邮箱: mail.qq.com');
      console.log('2. 进入"设置" → "账户"');
      console.log('3. 找到"POP3/IMAP/SMTP/Exchange/CardDAV/CalDAV服务"');
      console.log('4. 开启"IMAP/SMTP服务"');
      console.log('5. 生成授权码（如果已有，确认是否正确）');
      console.log('6. 授权码: bnmoixtawvwwcaie');
    }
    
    return false;
  }
}

/**
 * 发送化妆品行业报告
 */
export async function sendCosmeticsReport(): Promise<boolean> {
  try {
    const fs = require('fs');
    const path = require('path');
    
    // 读取最新的报告
    const reportsDir = path.join(process.cwd(), 'reports');
    const files = fs.readdirSync(reportsDir)
      .filter((f: string) => f.includes('ad-hunter-report') && f.endsWith('.html'))
      .sort()
      .reverse();
    
    if (files.length === 0) {
      console.log('❌ 没有找到报告文件');
      return false;
    }
    
    const latestReport = files[0];
    const reportPath = path.join(reportsDir, latestReport);
    const htmlContent = fs.readFileSync(reportPath, 'utf-8');
    
    // 提取信息
    const titleMatch = htmlContent.match(/<title>([^<]+)<\/title>/);
    const subject = titleMatch ? titleMatch[1] : '广告主新客猎手商机报告';
    
    // 提取文本内容
    const bodyStart = htmlContent.indexOf('<body>');
    const bodyEnd = htmlContent.indexOf('</body>');
    let textContent = htmlContent.substring(bodyStart + 6, bodyEnd)
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim()
      .substring(0, 5000); // 限制长度
    
    const to = '86951394@qq.com';
    
    console.log('🎯 发送化妆品行业报告');
    console.log('====================');
    console.log(`📄 报告文件: ${latestReport}`);
    console.log(`📧 收件人: ${to}`);
    console.log(`📋 主题: ${subject}`);
    console.log(`📊 内容大小: ${Math.round(htmlContent.length / 1024)} KB`);
    console.log('');
    
    // 发送邮件
    return await sendWithQQEmail(to, subject, htmlContent, textContent);
    
  } catch (error: any) {
    console.error('❌ 发送报告失败:', error.message);
    return false;
  }
}