import { Opportunity, OpportunityType } from "./news-fetcher";

// 邮件模板
export function generateEmailContent(
  industry: string,
  opportunities: Opportunity[],
  date: Date = new Date()
): { subject: string; html: string; text: string } {
  const formattedDate = date.toLocaleDateString("zh-CN", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  
  const subject = `【广告主新客猎手】${industry}行业商机报告 ${formattedDate}`;
  
  // 按类型分组
  const groupedOpportunities: Record<OpportunityType, Opportunity[]> = {
    [OpportunityType.NEW_COMPANY]: [],
    [OpportunityType.NEW_PRODUCT]: [],
    [OpportunityType.NEW_FUNDING]: [],
    [OpportunityType.NEW_MARKET]: [],
  };
  
  opportunities.forEach(opp => {
    groupedOpportunities[opp.type].push(opp);
  });
  
  // 生成HTML内容
  let html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 800px; margin: 0 auto; padding: 20px; }
    .header { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 30px; }
    .header h1 { margin: 0; font-size: 24px; }
    .header p { margin: 10px 0 0; opacity: 0.9; }
    .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 30px; }
    .stat-card { background: #f8f9fa; padding: 20px; border-radius: 8px; text-align: center; border-left: 4px solid #667eea; }
    .stat-number { font-size: 28px; font-weight: bold; color: #667eea; }
    .stat-label { font-size: 14px; color: #666; margin-top: 5px; }
    .opportunity-section { margin-bottom: 30px; }
    .section-title { font-size: 20px; font-weight: bold; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 2px solid #eee; }
    .opportunity-card { background: white; border: 1px solid #e9ecef; border-radius: 8px; padding: 20px; margin-bottom: 15px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
    .opportunity-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
    .opportunity-type { display: inline-block; padding: 4px 12px; border-radius: 20px; font-size: 12px; font-weight: bold; }
    .type-new-company { background: #e3f2fd; color: #1976d2; }
    .type-new-product { background: #f3e5f5; color: #7b1fa2; }
    .type-new-funding { background: #e8f5e9; color: #388e3c; }
    .type-new-market { background: #fff3e0; color: #f57c00; }
    .company-name { font-size: 18px; font-weight: bold; color: #333; }
    .confidence { font-size: 12px; color: #666; }
    .summary { margin: 15px 0; color: #555; line-height: 1.5; }
    .details { background: #f8f9fa; padding: 15px; border-radius: 6px; margin: 15px 0; }
    .detail-item { margin-bottom: 8px; }
    .detail-label { font-weight: bold; color: #666; }
    .link { color: #667eea; text-decoration: none; }
    .link:hover { text-decoration: underline; }
    .footer { margin-top: 40px; padding-top: 20px; border-top: 1px solid #eee; text-align: center; color: #666; font-size: 14px; }
    .tag { display: inline-block; background: #f0f0f0; padding: 2px 8px; border-radius: 4px; font-size: 12px; margin-right: 5px; margin-bottom: 5px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>广告主新客猎手</h1>
    <p>${industry}行业商机报告 · ${formattedDate}</p>
  </div>
  
  <div class="stats">
    <div class="stat-card">
      <div class="stat-number">${opportunities.length}</div>
      <div class="stat-label">今日商机总数</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${groupedOpportunities[OpportunityType.NEW_COMPANY].length}</div>
      <div class="stat-label">新公司成立</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${groupedOpportunities[OpportunityType.NEW_PRODUCT].length}</div>
      <div class="stat-label">新产品发布</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${groupedOpportunities[OpportunityType.NEW_FUNDING].length}</div>
      <div class="stat-label">获得融资</div>
    </div>
    <div class="stat-card">
      <div class="stat-number">${groupedOpportunities[OpportunityType.NEW_MARKET].length}</div>
      <div class="stat-label">开拓新市场</div>
    </div>
  </div>
  `;
  
  // 添加各类型商机
  const typeConfigs = [
    { 
      type: OpportunityType.NEW_COMPANY, 
      title: "🏢 新公司成立",
      typeClass: "type-new-company"
    },
    { 
      type: OpportunityType.NEW_PRODUCT, 
      title: "📦 新产品发布", 
      typeClass: "type-new-product"
    },
    { 
      type: OpportunityType.NEW_FUNDING, 
      title: "💰 获得融资", 
      typeClass: "type-new-funding"
    },
    { 
      type: OpportunityType.NEW_MARKET, 
      title: "🌍 开拓新市场", 
      typeClass: "type-new-market"
    },
  ];
  
  for (const config of typeConfigs) {
    const typeOpportunities = groupedOpportunities[config.type];
    
    if (typeOpportunities.length > 0) {
      html += `
      <div class="opportunity-section">
        <div class="section-title">${config.title}（${typeOpportunities.length}个）</div>
      `;
      
      for (const opp of typeOpportunities) {
        html += `
        <div class="opportunity-card">
          <div class="opportunity-header">
            <div>
              <span class="opportunity-type ${config.typeClass}">${opp.type}</span>
              <span class="company-name">${opp.company}</span>
            </div>
            <div class="confidence">置信度: ${opp.confidence}%</div>
          </div>
          
          <div class="summary">${opp.summary}</div>
          
          <div class="details">
            ${opp.details.amount ? `<div class="detail-item"><span class="detail-label">融资金额:</span> ${opp.details.amount}</div>` : ''}
            ${opp.details.product ? `<div class="detail-item"><span class="detail-label">产品名称:</span> ${opp.details.product}</div>` : ''}
            ${opp.details.region ? `<div class="detail-item"><span class="detail-label">新市场区域:</span> ${opp.details.region}</div>` : ''}
            ${opp.details.isForeign ? `<div class="detail-item"><span class="detail-label">外资企业:</span> ${opp.details.origin || '海外品牌'}</div>` : ''}
            ${opp.details.investors ? `<div class="detail-item"><span class="detail-label">投资机构:</span> ${opp.details.investors.join('、')}</div>` : ''}
            ${opp.details.eventType ? `<div class="detail-item"><span class="detail-label">发布会类型:</span> ${opp.details.eventType}</div>` : ''}
            <div class="detail-item"><span class="detail-label">原文链接:</span> <a href="${opp.link}" class="link" target="_blank">${opp.link}</a></div>
          </div>
        </div>
        `;
      }
      
      html += `</div>`;
    }
  }
  
  // 如果没有商机
  if (opportunities.length === 0) {
    html += `
    <div style="text-align: center; padding: 40px 20px; background: #f8f9fa; border-radius: 8px;">
      <div style="font-size: 48px; margin-bottom: 20px;">📭</div>
      <h3 style="margin: 0 0 10px; color: #666;">今日暂无商机</h3>
      <p style="color: #888; margin: 0;">今天在${industry}行业没有发现符合条件的商机，明天继续为您监控。</p>
    </div>
    `;
  }
  
  // 页脚
  html += `
  <div class="footer">
    <p>本报告由 <strong>广告主新客猎手</strong> 自动生成</p>
    <p>监控1个行业 · 如需修改配置请联系系统管理员</p>
    <p style="font-size: 12px; color: #999; margin-top: 20px;">
      数据来源：国内公开新闻媒体<br>
      生成时间：${new Date().toLocaleString("zh-CN")}
    </p>
  </div>
</body>
</html>
  `;
  
  // 生成纯文本版本
  let text = `${subject}\n\n`;
  text += `行业：${industry}\n`;
  text += `日期：${formattedDate}\n`;
  text += `商机总数：${opportunities.length}\n\n`;
  
  for (const config of typeConfigs) {
    const typeOpportunities = groupedOpportunities[config.type];
    
    if (typeOpportunities.length > 0) {
      text += `${config.title}（${typeOpportunities.length}个）\n`;
      text += "=".repeat(40) + "\n\n";
      
      for (const opp of typeOpportunities) {
        text += `[${opp.type}] ${opp.company}\n`;
        text += `摘要：${opp.summary}\n`;
        if (opp.details.amount) text += `融资金额：${opp.details.amount}\n`;
        if (opp.details.product) text += `产品名称：${opp.details.product}\n`;
        if (opp.details.region) text += `新市场区域：${opp.details.region}\n`;
        text += `链接：${opp.link}\n\n`;
      }
    }
  }
  
  if (opportunities.length === 0) {
    text += "今日在" + industry + "行业没有发现符合条件的商机，明天继续为您监控。\n\n";
  }
  
  text += "---\n";
  text += "本报告由广告主新客猎手自动生成\n";
  text += "监控1个行业\n";
  text += "数据来源：国内公开新闻媒体\n";
  text += "生成时间：" + new Date().toLocaleString("zh-CN") + "\n";
  
  return { subject, html, text };
}

// 导入QQ邮箱发送器
import { sendWithQQEmail } from './qq-email-sender.js';

// 发送邮件（使用QQ邮箱SMTP真正自动发送）
export async function sendEmail(
  to: string,
  subject: string,
  html: string,
  text: string
): Promise<boolean> {
  try {
    console.log(`📧 正在通过QQ邮箱发送邮件到: ${to}`);
    console.log(`📋 主题: ${subject}`);
    console.log(`📊 内容长度: HTML=${html.length}字符, Text=${text.length}字符`);
    
    // 使用QQ邮箱SMTP发送
    const success = await sendWithQQEmail(to, subject, html, text);
    
    if (success) {
      console.log(`✅ 邮件已成功发送到: ${to}`);
      
      // 同时保存本地副本
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
      const filename = `ad-hunter-report-${timestamp}.html`;
      const fs = require('fs');
      const path = require('path');
      
      const outputDir = path.join(process.cwd(), 'reports');
      if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
      }
      
      const filePath = path.join(outputDir, filename);
      fs.writeFileSync(filePath, html, 'utf-8');
      console.log(`📁 报告已保存到本地: ${filePath}`);
      
      return true;
    } else {
      console.log('⚠️ QQ邮箱发送失败，请检查配置');
      return false;
    }
    
  } catch (error: any) {
    console.error("❌ 邮件发送失败:", error.message);
    return false;
  }
}