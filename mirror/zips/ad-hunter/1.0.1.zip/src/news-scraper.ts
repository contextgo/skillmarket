/**
 * 新闻网页抓取器
 * 替代RSS方案，直接从新闻网站抓取热门新闻
 */

import fetch from "node-fetch";
import * as cheerio from "cheerio";
import type { NewsItem } from "./news-fetcher";

// 可稳定访问的新闻源（2026年4月验证有效）
const NEWS_SCRAPERS: {
  name: string;
  category: string;
  url: string;
  parser: ($: cheerio.CheerioAPI) => ScrapedArticle[];
  enabled: boolean;
}[] = [
  {
    name: "新浪新闻",
    category: "综合",
    url: "https://news.sina.com.cn/",
    enabled: false, // 先禁用，下面用web_fetch
    parser: ($) => {
      const articles: ScrapedArticle[] = [];
      $("a").each((_, el) => {
        const title = $(el).text().trim();
        const href = $(el).attr("href") || "";
        if (title.length > 10 && href && !href.startsWith("javascript")) {
          articles.push({
            title: title.substring(0, 100),
            link: href.startsWith("http") ? href : `https://news.sina.com.cn${href}`,
          });
        }
      });
      return articles.slice(0, 30);
    },
  },
];

interface ScrapedArticle {
  title: string;
  link: string;
}

// 可抓取的实际页面源
const CRAWL_SOURCES = [
  {
    name: "36氪-快讯",
    category: "科技",
    url: "https://36kr.com/newsflashes",
    selectors: {
      article: "a.article-item-title, .newsflash-item, .newsflash-title, a[href*='/newsflashes/']",
      title: "",
      link: "href",
    },
  },
  {
    name: "36氪-资讯",
    category: "科技",
    url: "https://36kr.com/information/",
    selectors: {
      article: "a.article-item-title, .kr-article-item a, a[href*='/p/']",
      title: "",
      link: "href",
    },
  },
  {
    name: "财新网",
    category: "财经",
    url: "https://www.caixin.com/",
    selectors: {
      article: "a, h4 a, h3 a, li a",
      title: "",
      link: "href",
    },
  },
  {
    name: "第一财经",
    category: "财经",
    url: "https://www.yicai.com/",
    selectors: {
      article: "a, h3 a, .news-title a, .f-col a",
      title: "",
      link: "href",
    },
  },
  {
    name: "亿欧",
    category: "科技",
    url: "https://www.iyiou.com/",
    selectors: {
      article: "a, .post-item a, .card-item a, h3 a",
      title: "",
      link: "href",
    },
  },
  {
    name: "虎嗅",
    category: "科技",
    url: "https://www.huxiu.com/",
    selectors: {
      article: "a, .article-item a, h3 a, .story-item a",
      title: "",
      link: "href",
    },
  },
  {
    name: "澎湃新闻",
    category: "综合",
    url: "https://www.thepaper.cn/",
    selectors: {
      article: "a, h3 a, .list-item a, .news-item a",
      title: "",
      link: "href",
    },
  },
  {
    name: "界面新闻",
    category: "财经",
    url: "https://www.jiemian.com/",
    selectors: {
      article: "a, .story-item a, h3 a, .item a",
      title: "",
      link: "href",
    },
  },
  {
    name: "极客公园",
    category: "科技",
    url: "https://www.geekpark.net/",
    selectors: {
      article: "a, .article-item a, h3 a",
      title: "",
      link: "href",
    },
  },
  {
    name: "好奇心日报",
    category: "综合",
    url: "https://www.qdaily.com/",
    selectors: {
      article: "a, .grid-item a, h3 a, .package-comment a",
      title: "",
      link: "href",
    },
  },
  {
    name: "凤凰科技",
    category: "科技",
    url: "https://tech.ifeng.com/",
    selectors: {
      article: "a, h3 a, li a, .news-item a",
      title: "",
      link: "href",
    },
  },
];

/**
 * 从单个网页源抓取文章列表
 */
async function scrapeFromSource(source: typeof CRAWL_SOURCES[0]): Promise<NewsItem[]> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    const response = await fetch(source.url, {
      signal: controller.signal as any,
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
      },
    });

    clearTimeout(timeoutId);

    if (!response.ok) {
      console.warn(`[抓取失败] ${source.name}: HTTP ${response.status}`);
      return [];
    }

    const html = await response.text();
    const $ = cheerio.load(html);
    const items: NewsItem[] = [];

    // 收集页面上所有链接
    const seenLinks = new Set<string>();
    $("a").each((_, el) => {
      const $el = $(el);
      const title = $el.text().trim().replace(/\s+/g, " ");
      const href = $el.attr("href") || "";

      // 过滤条件：标题够长、不是空链接、不是JS、不是广告/导航
      if (
        title.length < 8 || 
        title.length > 100 ||
        !href ||
        href.startsWith("javascript") ||
        href.startsWith("#") ||
        href.startsWith("//") ||
        /(login|register|about|contact|help|privacy|terms)/i.test(href) ||
        /(广告|推广|赞助|AD)/.test(title)
      ) {
        return;
      }

      // 规范化链接
      let fullLink = href;
      try {
        fullLink = new URL(href, source.url).href;
      } catch {
        return;
      }

      // 去重
      if (seenLinks.has(fullLink)) return;
      seenLinks.add(fullLink);

      items.push({
        title,
        description: title,
        link: fullLink,
        pubDate: new Date().toISOString(),
        source: source.name,
        category: source.category,
      });
    });

    // 过滤出真正的新闻链接（优先短URL和有意义的路径）
    const filtered = items.filter((item) => {
      const path = new URL(item.link).pathname;
      // 排除首页、分类页等
      if (path === "/" || path === "/index.html") return false;
      // 标题中有实际内容
      return item.title.length >= 8;
    });

    // 去重标题相似的内容
    const unique: NewsItem[] = [];
    const seenTitles = new Set<string>();
    for (const item of filtered) {
      const key = item.title.substring(0, 20);
      if (!seenTitles.has(key)) {
        seenTitles.add(key);
        unique.push(item);
      }
    }

    console.log(`[${source.name}] 抓取到 ${unique.length} 条新闻`);
    return unique.slice(0, 20);
  } catch (error: any) {
    if (error.name === "AbortError") {
      console.warn(`[超时] ${source.name}: 请求超时`);
    } else {
      console.warn(`[抓取失败] ${source.name}: ${error.message || error}`);
    }
    return [];
  }
}

/**
 * 从所有网页源抓取新闻（替代RSS）
 */
export async function fetchNewsFromWeb(): Promise<NewsItem[]> {
  console.log("\n🌐 开始从网页抓取新闻...");
  
  const allNews: NewsItem[] = [];
  const results = await Promise.allSettled(
    CRAWL_SOURCES.map((source) => scrapeFromSource(source))
  );

  for (const result of results) {
    if (result.status === "fulfilled") {
      allNews.push(...result.value);
    }
  }

  console.log(`✅ 网页抓取完成: 共 ${allNews.length} 条新闻\n`);
  return allNews;
}

/**
 * 抓取单篇文章的详细内容
 */
export async function fetchArticleContent(url: string): Promise<string> {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    const response = await fetch(url, {
      signal: controller.signal as any,
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
      },
    });

    clearTimeout(timeoutId);

    if (!response.ok) return "";

    const html = await response.text();
    const $ = cheerio.load(html);

    // 移除无用元素
    $("script, style, nav, footer, header, aside, .ad, .banner").remove();

    // 尝试提取正文
    const articleSelectors = [
      "article",
      ".article-content",
      ".content",
      "#content",
      ".post-content",
      ".main-content",
      ".article-detail",
      ".detail-content",
    ];

    for (const selector of articleSelectors) {
      const el = $(selector);
      if (el.length > 0) {
        const text = el.text().trim();
        if (text.length > 100) {
          return text.substring(0, 500);
        }
      }
    }

    // fallback: 取 body 文本
    return $("body").text().trim().substring(0, 500);
  } catch {
    return "";
  }
}
