#!/usr/bin/env node

// 测试更新后的新闻源
const { fetchNewsWithMock } = require('./dist/news-fetcher.js');

async function test() {
  console.log('🚀 测试更新后的新闻源系统');
  console.log('==========================\n');
  
  console.log('1. 🔍 搜索金融行业新闻...');
  const news = await fetchNewsWithMock('金融');
  
  console.log(`✅ 找到 ${news.length} 条新闻`);
  console.log('\n2. 📊 新闻来源统计：');
  
  const sourceCount = {};
  news.forEach(item => {
    sourceCount[item.source] = (sourceCount[item.source] || 0) + 1;
  });
  
  for (const [source, count] of Object.entries(sourceCount)) {
    console.log(`   • ${source}: ${count}条`);
  }
  
  console.log('\n3. 📰 最新新闻示例：');
  const recentNews = news.slice(0, 3);
  recentNews.forEach((item, i) => {
    console.log(`\n   ${i + 1}. ${item.title}`);
    console.log(`      来源: ${item.source}`);
    console.log(`      摘要: ${item.description.substring(0, 80)}...`);
  });
  
  console.log('\n4. 📋 数据来源显示：');
  console.log('   邮件中将显示: "数据来源：国内公开新闻媒体"');
  console.log('   实际搜索范围: ' + Object.keys(sourceCount).join('、'));
}

test().catch(console.error);