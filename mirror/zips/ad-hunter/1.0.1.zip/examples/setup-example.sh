#!/bin/bash
# 广告主新客猎手使用示例

echo "🎯 广告主新客猎手使用示例"
echo "=========================="
echo ""

# 1. 设置向导
echo "1. 首次设置（交互式）："
echo "   ad-hunter wizard"
echo ""

# 2. 命令行设置
echo "2. 命令行设置："
echo "   ad-hunter setup \\"
echo "     -u \"user123\" \\"
echo "     -i \"汽车\" \\"
echo "     -e \"sales@example.com\" \\"
echo "     -t \"08:30\""
echo ""

# 3. 立即运行
echo "3. 立即运行："
echo "   ad-hunter run -u \"user123\""
echo ""

# 4. 修改配置
echo "4. 修改配置："
echo "   ad-hunter update \\"
echo "     -u \"user123\" \\"
echo "     -i \"美妆\" \\"
echo "     -t \"09:00\""
echo ""

# 5. 检查状态
echo "5. 检查状态："
echo "   ad-hunter status -u \"user123\""
echo ""

# 6. 设置定时任务
echo "6. 设置OpenClaw定时任务："
echo "   # 每天08:30运行"
echo "   openclaw cron add \\"
echo "     --name ad-hunter-daily \\"
echo "     --schedule '30 8 * * *' \\"
echo "     --payload '{\"kind\":\"agentTurn\",\"message\":\"运行广告主新客猎手每日任务\"}'"
echo ""

echo "📊 支持的行业："
echo "• 汽车、美妆、人工智能、科技、金融"
echo "• 医疗、教育、消费、房地产、旅游"
echo ""

echo "💡 提示："
echo "• 免费版：监控1个行业"
echo "• 进阶版：监控5个行业（9.9元/月）"
echo "• 报告每天自动发送到指定邮箱"