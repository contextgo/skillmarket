#!/usr/bin/env node

// 测试真正的邮件发送功能
const { testEmailSending } = require('./dist/real-email-sender.js');

async function main() {
  console.log('🚀 测试真正的邮件发送功能');
  console.log('============================\n');
  
  const success = await testEmailSending();
  
  if (success) {
    console.log('\n🎉 测试成功！邮件应该已经发送到 86951394@qq.com');
  } else {
    console.log('\n⚠️ 测试失败，将使用备用方案');
    
    // 检查系统
    const { execSync } = require('child_process');
    const fs = require('fs');
    
    console.log('\n🔧 系统诊断:');
    
    // 检查sendmail
    try {
      const sendmailCheck = execSync('which sendmail', { encoding: 'utf-8' });
      console.log(`✅ sendmail: ${sendmailCheck.trim()}`);
    } catch {
      console.log('❌ sendmail: 未找到');
    }
    
    // 检查mail
    try {
      const mailCheck = execSync('which mail', { encoding: 'utf-8' });
      console.log(`✅ mail命令: ${mailCheck.trim()}`);
    } catch {
      console.log('❌ mail命令: 未找到');
    }
    
    // 检查Python
    try {
      const pythonCheck = execSync('python3 --version', { encoding: 'utf-8' });
      console.log(`✅ Python3: ${pythonCheck.trim()}`);
    } catch {
      console.log('❌ Python3: 未安装');
    }
    
    console.log('\n💡 解决方案:');
    console.log('1. 安装sendmail: brew install sendmail (macOS)');
    console.log('2. 或配置系统邮件服务');
    console.log('3. 或使用备用邮件发送方案');
  }
}

main().catch(console.error);