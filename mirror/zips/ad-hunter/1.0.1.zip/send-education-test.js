#!/usr/bin/env node

/**
 * 测试发送教育行业报告（使用更新后的数据来源）
 */

const { exec } = require('child_process');
const { promisify } = require('util');
const execAsync = promisify(exec);

async function sendEducationReport() {
  console.log('🎓 测试发送教育行业报告');
  console.log('======================\n');
  
  try {
    // 1. 搜索教育行业
    console.log('1. 🔍 搜索教育行业...');
    const startResult = await execAsync('node dist/cli.js start -i "教育"', { timeout: 15000 });
    
    // 提取临时用户ID
    const tempUserIdMatch = startResult.stdout.match(/临时用户ID：\s*(temp_\d+)/);
    if (!tempUserIdMatch) {
      console.log('❌ 无法获取临时用户ID');
      console.log(startResult.stdout);
      return;
    }
    
    const tempUserId = tempUserIdMatch[1];
    console.log(`✅ 搜索完成！临时用户ID: ${tempUserId}`);
    
    // 2. 发送邮件
    console.log('\n2. 📧 发送邮件...');
    const completeResult = await execAsync(`node dist/cli.js complete -u "${tempUserId}" -e "86951394@qq.com" -t "09:00"`, { timeout: 15000 });
    
    console.log(completeResult.stdout);
    
    // 3. 检查数据来源
    console.log('\n3. 📋 检查数据来源更新...');
    
    // 查找最新报告
    const { stdout: lsResult } = await execAsync('ls -t reports/*.html | head -1');
    const latestReport = lsResult.trim();
    
    if (latestReport) {
      const { stdout: tailResult } = await execAsync(`tail -5 "${latestReport}"`);
      console.log('最新报告页脚：');
      console.log(tailResult);
      
      if (tailResult.includes('国内公开新闻媒体')) {
        console.log('\n✅ **数据来源已成功更新为"国内公开新闻媒体"！**');
      } else {
        console.log('\n⚠️ 数据来源未更新');
      }
    }
    
    console.log('\n🎉 **测试完成！**');
    console.log('   请检查QQ邮箱是否收到教育行业报告');
    console.log('   确认数据来源显示为"国内公开新闻媒体"');
    
  } catch (error) {
    console.error('❌ 测试失败:', error.message);
    
    // 直接测试数据来源
    console.log('\n🔧 **直接测试数据来源：**');
    
    const testScript = `
const { generateEmailContent } = require('./dist/email-sender.js');
const { OpportunityType } = require('./dist/news-fetcher.js');

const testOpp = [{
  type: OpportunityType.NEW_COMPANY,
  company: "测试公司",
  title: "测试",
  summary: "测试",
  link: "https://example.com",
  confidence: 80,
  details: {}
}];

const content = generateEmailContent("教育", testOpp);
console.log('数据来源显示：');
console.log(content.text.split('\\n').find(l => l.includes('数据来源：')));
`;
    
    const fs = require('fs');
    fs.writeFileSync('/tmp/test-source.js', testScript);
    
    const { stdout } = await execAsync('node /tmp/test-source.js');
    console.log(stdout);
  }
}

sendEducationReport().catch(console.error);