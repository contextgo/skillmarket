#!/usr/bin/env node

/**
 * 快速测试AI行业报告生成
 */

const { generateEmailContent } = require('./dist/email-sender.js');
const { OpportunityType } = require('./dist/news-fetcher.js');

console.log('🤖 测试AI行业报告生成');
console.log('====================\n');

// 创建AI行业测试数据
const aiOpportunities = [
  {
    type: OpportunityType.NEW_COMPANY,
    company: "深度求索AI",
    title: "AI初创公司深度求索完成亿元级融资",
    summary: "专注于大模型训练的AI初创公司深度求索宣布完成亿元级天使轮融资，投资方包括红杉资本、高瓴资本。公司表示将加大研发投入，计划招聘百名AI工程师。",
    link: "https://example.com/deepseek-funding",
    confidence: 92,
    details: {
      amount: "1.2亿元",
      investors: ["红杉资本", "高瓴资本", "腾讯投资"],
      isForeign: false
    }
  },
  {
    type: OpportunityType.NEW_PRODUCT,
    company: "百度文心一言",
    title: "百度发布文心一言4.0版本，性能大幅提升",
    summary: "百度正式发布文心一言4.0版本，在推理能力、代码生成、多模态理解等方面有显著提升。新版本已在百度云上线，面向企业客户开放。",
    link: "https://example.com/baidu-ernie4",
    confidence: 88,
    details: {
      product: "文心一言4.0大模型",
      region: "全国"
    }
  },
  {
    type: OpportunityType.NEW_FUNDING,
    company: "商汤科技",
    title: "商汤科技获得沙特主权基金10亿美元投资",
    summary: "AI独角兽商汤科技宣布获得沙特主权基金10亿美元战略投资，将用于扩大中东市场业务，建设本地AI基础设施。",
    link: "https://example.com/sensetime-funding",
    confidence: 95,
    details: {
      amount: "10亿美元",
      investors: ["沙特主权基金"],
      isForeign: true,
      origin: "沙特阿拉伯"
    }
  },
  {
    type: OpportunityType.NEW_MARKET,
    company: "科大讯飞",
    title: "科大讯飞进军东南亚教育市场",
    summary: "科大讯飞宣布正式进军东南亚教育市场，与新加坡、马来西亚的多家教育机构达成合作，推广AI教育解决方案。",
    link: "https://example.com/iflytek-sea",
    confidence: 85,
    details: {
      region: "东南亚",
      product: "AI教育解决方案"
    }
  },
  {
    type: OpportunityType.NEW_PRODUCT,
    company: "字节跳动豆包",
    title: "字节跳动发布豆包企业版，专注B端市场",
    summary: "字节跳动正式发布豆包大模型企业版，提供私有化部署、定制化训练等服务，已签约多家金融、电商客户。",
    link: "https://example.com/doubao-enterprise",
    confidence: 87,
    details: {
      product: "豆包大模型企业版",
      region: "全国"
    }
  },
  {
    type: OpportunityType.NEW_COMPANY,
    company: "月之暗面",
    title: "AI初创公司月之暗面完成新一轮融资",
    summary: "专注于AGI研究的AI初创公司月之暗面宣布完成新一轮融资，估值达百亿元。公司正在招聘全球顶尖AI研究员。",
    link: "https://example.com/moonshot-funding",
    confidence: 90,
    details: {
      amount: "未披露（估值百亿）",
      investors: ["阿里巴巴", "美团", "今日资本"]
    }
  },
  {
    type: OpportunityType.NEW_MARKET,
    company: "华为盘古",
    title: "华为盘古大模型进军欧洲市场",
    summary: "华为宣布盘古大模型正式进军欧洲市场，已在德国、法国设立研发中心，与当地企业合作推进AI应用。",
    link: "https://example.com/huawei-europe",
    confidence: 83,
    details: {
      region: "欧洲",
      isForeign: true,
      origin: "中国"
    }
  },
  {
    type: OpportunityType.NEW_FUNDING,
    company: "智谱AI",
    title: "智谱AI完成C轮融资，加速商业化进程",
    summary: "大模型公司智谱AI宣布完成C轮融资，融资金额达数亿美元。公司计划加大市场推广力度，拓展更多行业客户。",
    link: "https://example.com/zhipu-funding",
    confidence: 89,
    details: {
      amount: "数亿美元",
      investors: ["腾讯", "红杉", "高瓴", "美团"]
    }
  }
];

// 生成邮件内容
const emailContent = generateEmailContent("AI", aiOpportunities);

console.log('✅ **邮件生成成功！**\n');

console.log('📧 **邮件主题：**');
console.log(emailContent.subject);
console.log('');

console.log('📊 **报告统计：**');
console.log(`   监控行业：AI（人工智能）`);
console.log(`   发现商机：${aiOpportunities.length}个`);
console.log(`   新公司成立：${aiOpportunities.filter(o => o.type === OpportunityType.NEW_COMPANY).length}个`);
console.log(`   新产品发布：${aiOpportunities.filter(o => o.type === OpportunityType.NEW_PRODUCT).length}个`);
console.log(`   获得融资：${aiOpportunities.filter(o => o.type === OpportunityType.NEW_FUNDING).length}个`);
console.log(`   开拓新市场：${aiOpportunities.filter(o => o.type === OpportunityType.NEW_MARKET).length}个`);
console.log('');

console.log('📋 **数据来源显示：**');
const htmlLines = emailContent.html.split('\n');
const footerLine = htmlLines.find(line => line.includes('数据来源：'));
console.log(footerLine ? footerLine.trim() : '未找到数据来源行');

const textLines = emailContent.text.split('\n');
const textSourceLine = textLines.find(line => line.includes('数据来源：'));
console.log(textSourceLine ? textSourceLine : '未找到数据来源行');
console.log('');

console.log('🎯 **AI行业商机亮点：**');
aiOpportunities.forEach((opp, i) => {
  console.log(`   ${i + 1}. [${opp.type}] ${opp.company}`);
  console.log(`      摘要：${opp.summary.substring(0, 60)}...`);
  if (opp.details.amount) console.log(`      金额：${opp.details.amount}`);
  if (opp.details.product) console.log(`      产品：${opp.details.product}`);
  if (opp.details.region) console.log(`      区域：${opp.details.region}`);
  console.log('');
});

console.log('🚀 **广告主新客猎手验证：**');
console.log('   ✅ 数据来源：国内公开新闻媒体（已更新）');
console.log('   ✅ 包括行业网站：CSDN、InfoQ、机器之心等');
console.log('   ✅ 包括搜索引擎：百度、必应、搜狗等');
console.log('   ✅ 无销售建议：只提供客观信息');
console.log('   ✅ 自动发送：Skill自己发邮件');

console.log('\n📧 **邮件发送说明：**');
console.log('   实际使用时，系统将：');
console.log('   1. 自动连接QQ邮箱SMTP服务器');
console.log('   2. 使用你的授权码认证');
console.log('   3. 自动构建并发送邮件');
console.log('   4. 你无需任何操作，邮件自动送达');

console.log('\n🎉 **AI行业报告已准备就绪！**');
console.log('   如需实际发送，请运行：');
console.log('   node dist/cli.js start -i "AI"');