#!/usr/bin/env python3
"""
Space Duck — Multi-turn chat (peck_session) with another connected duck.

INTENT: Maintain a continuing conversation with one peer using the
        backend's peck_session machinery (rate / daily / budget gated).
CALLS:  POST <api>/beak/agent/message    — send one round (signed HMAC-SHA256)
        GET  <api>/beak/peck/session     — read session state
        POST <api>/beak/peck/stop        — end an open session
AUTH:   Beak Key from ~/.space-duck/config.json (chmod 600).
HMAC:   Phase E v2 envelope (BRIEF v0.1.7 §E). Signature =
        HMAC-SHA256(beak_key, canonical_v2_json) over 8 canonical fields:
        from_spaceduck_id, to_spaceduck_id, conversation_id, turn_index,
        intent, scopes_asserted (sorted), timestamp, message_hash. For
        multi-turn, conversation_id = session_id and turn_index = round.
        Legacy v1 sunsets 2026-06-05.

A peck_session is created automatically on round 0 — the server returns a
session_id that subsequent rounds reference via conversation_id /
_peck_session_id. Use --show to inspect; --stop to terminate.

Usage:
  # Start a new conversation (round 0)
  python3 chat.py --to <spaceduck_id> --message "Got a minute?" \
      [--goal "design review"] [--max-rounds 10]

  # Continue an existing session (round N)
  python3 chat.py --session <PS-id> --message "Follow-up question"

  # Inspect session state
  python3 chat.py --show <PS-id>

  # Stop a session
  python3 chat.py --stop <PS-id>
"""
import argparse, hashlib, hmac, json, secrets, sys, time
import urllib.error, urllib.parse, urllib.request
from pathlib import Path

CONFIG_PATH = Path.home() / '.space-duck' / 'config.json'

def load_config():
    if not CONFIG_PATH.exists():
        print('ERROR: No Space Duck config found. Run setup.py first.')
        sys.exit(1)
    return json.loads(CONFIG_PATH.read_text())

def _v2_canonical(env):
    """Server-matched canonical JSON for the Phase E envelope."""
    canonical = {
        'from_spaceduck_id': str(env.get('from_spaceduck_id', '')),
        'to_spaceduck_id':   str(env.get('to_spaceduck_id', '')),
        'conversation_id':   str(env.get('conversation_id', '')),
        'turn_index':        int(env.get('turn_index', 0) or 0),
        'intent':            str(env.get('intent', '')),
        'scopes_asserted':   sorted(env.get('scopes_asserted') or []),
        'timestamp':         int(env.get('timestamp', 0) or 0),
        'message_hash':      str(env.get('message_hash', '')),
    }
    return json.dumps(canonical, sort_keys=True, separators=(',', ':'))

def _v2_sign(env, beak_key):
    return hmac.new(beak_key.encode(), _v2_canonical(env).encode(), hashlib.sha256).hexdigest()

def _post(url, payload):
    req = urllib.request.Request(
        url, data=json.dumps(payload).encode(),
        headers={'Content-Type': 'application/json'}, method='POST')
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())

def _get(url):
    req = urllib.request.Request(url, method='GET')
    with urllib.request.urlopen(req, timeout=15) as r:
        return json.loads(r.read())

def _http_err(e, hint=None):
    body = e.read().decode()
    print(f'ERROR: HTTP {e.code} — {body}')
    if hint:
        print(f'  Hint: {hint}')
    sys.exit(1)

def send_round(cfg, target_id, message, session_id=None, goal=None,
               max_rounds=10, peck_type='query', turn_index=0):
    api  = cfg.get('api_base', 'https://beak.spaceduckling.com')
    sdid = cfg.get('spaceduck_id', '')
    bk   = cfg.get('beak_key', '')
    if not sdid or not bk:
        print('ERROR: spaceduck_id or beak_key missing from config.')
        sys.exit(1)

    peck_id      = 'peck_' + secrets.token_urlsafe(12)
    timestamp    = int(time.time())
    message_hash = hashlib.sha256(message.encode()).hexdigest()

    # Multi-turn: conversation_id = real session_id, turn_index = current round.
    # Round 0 (no session yet): conversation_id = peck_id, turn_index = 0.
    conv_id = session_id or peck_id
    env_v2 = {
        'from_spaceduck_id': sdid,
        'to_spaceduck_id':   target_id,
        'conversation_id':   conv_id,
        'turn_index':        int(turn_index),
        'intent':            peck_type,
        'scopes_asserted':   [],
        'timestamp':          timestamp,
        'message_hash':       message_hash,
    }
    signature = _v2_sign(env_v2, bk)

    payload = {
        'envelope_version':     '2',
        'sender_spaceduck_id':  sdid,
        'beak_key':             bk,
        'target_spaceduck_id':  target_id,
        'message':              message,
        'message_hash':         message_hash,
        'peck_type':            peck_type,
        'peck_id':              peck_id,
        'conversation_id':      conv_id,
        'turn_index':           int(turn_index),
        'intent':               peck_type,
        'scopes_asserted':      [],
        'timestamp':            timestamp,
        'signature':            signature,
        '_peck_max_rounds':     max_rounds,
    }
    if session_id:
        payload['_peck_session_id'] = session_id
    if goal:
        payload['goal'] = goal

    try:
        resp = _post(f'{api}/beak/agent/message', payload)
    except urllib.error.HTTPError as e:
        if e.code == 403:
            _http_err(e, hint='peck blocked — target may not be peck\'d to you, '
                              'or rate/daily/budget limit reached. Check '
                              'permissions.py to see gating.')
        _http_err(e)
    except Exception as e:
        print(f'ERROR: {e}')
        sys.exit(1)

    sid = resp.get('session_id') or resp.get('_peck_session_id') or session_id or '(new)'
    print(f'✅ Round delivered to {target_id}')
    print(f'   Peck ID: {peck_id}')
    print(f'   Session: {sid}')
    if 'channels' in resp:
        print(f'   Channels: {", ".join(resp["channels"])}')
    print()
    print('  → Continue:  python3 chat.py --session %s --message "..."' % sid)
    print('  → Inspect:   python3 chat.py --show %s' % sid)
    print('  → Stop:      python3 chat.py --stop %s' % sid)
    return resp

def show_session(cfg, session_id):
    api = cfg.get('api_base', 'https://beak.spaceduckling.com')
    qs  = urllib.parse.urlencode({'session_id': session_id})
    try:
        data = _get(f'{api}/beak/peck/session?{qs}')
    except urllib.error.HTTPError as e:
        _http_err(e)
    except Exception as e:
        print(f'ERROR: {e}')
        sys.exit(1)

    print(f'💬 Session {data.get("session_id", session_id)}')
    print(f'   Status:    {data.get("status", "?")}')
    print(f'   Round:     {data.get("current_round", 0)} / {data.get("max_rounds", "?")}')
    print(f'   Initiator: {data.get("initiator", "?")}')
    print(f'   Target:    {data.get("target", "?")}')
    if data.get('goal'):
        print(f'   Goal:      {data["goal"]}')
    if data.get('cost_usd') is not None:
        print(f'   Cost:      ${data["cost_usd"]:.4f}  '
              f'(in: {data.get("tokens_in", 0)}, out: {data.get("tokens_out", 0)})')
    if data.get('flock_task_id'):
        print(f'   Flock:     {data["flock_task_id"]}')
    return data

def stop_session(cfg, session_id):
    api  = cfg.get('api_base', 'https://beak.spaceduckling.com')
    sdid = cfg.get('spaceduck_id', '')
    bk   = cfg.get('beak_key', '')
    payload = {'session_id': session_id, 'spaceduck_id': sdid, 'beak_key': bk}
    try:
        resp = _post(f'{api}/beak/peck/stop', payload)
    except urllib.error.HTTPError as e:
        _http_err(e)
    except Exception as e:
        print(f'ERROR: {e}')
        sys.exit(1)
    print(f'🛑 Session {session_id} stopped.')
    return resp

if __name__ == '__main__':
    p = argparse.ArgumentParser(description='Multi-turn chat over peck_session')
    p.add_argument('--to', metavar='SPACEDUCK_ID', help='Target duck (for round 0)')
    p.add_argument('--session', metavar='PS_ID', help='Continue an existing session')
    p.add_argument('--message', '-m', help='Message to send this round')
    p.add_argument('--goal', help='Optional goal label (round 0 only)')
    p.add_argument('--max-rounds', type=int, default=10, help='Cap on rounds (default 10)')
    p.add_argument('--peck-type', default='query',
                   choices=['notify', 'query', 'data_request', 'task_delegation'])
    p.add_argument('--show', metavar='PS_ID', help='Show session state and exit')
    p.add_argument('--stop', metavar='PS_ID', help='Stop an open session and exit')
    args = p.parse_args()

    cfg = load_config()

    if args.show:
        show_session(cfg, args.show); sys.exit(0)
    if args.stop:
        stop_session(cfg, args.stop); sys.exit(0)

    if not args.message:
        p.error('--message is required (unless --show / --stop)')
    if args.session:
        # The backend pulls target from the session; we still need a target
        # field + turn_index in the signed v2 envelope. Resolve via session lookup.
        sess = show_session(cfg, args.session)
        target = sess.get('target') or sess.get('initiator') or ''
        if not target:
            print('ERROR: could not resolve target from session.')
            sys.exit(1)
        next_turn = int(sess.get('current_round', 0) or 0)
        send_round(cfg, target, args.message, session_id=args.session,
                   max_rounds=args.max_rounds, peck_type=args.peck_type,
                   turn_index=next_turn)
    elif args.to:
        send_round(cfg, args.to, args.message, goal=args.goal,
                   max_rounds=args.max_rounds, peck_type=args.peck_type,
                   turn_index=0)
    else:
        p.error('--to (new) or --session (continue) is required')
