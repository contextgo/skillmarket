#!/usr/bin/env python3
"""
Space Duck — Review and respond to pending peck (connection) requests.

INTENT: List incoming peck requests; approve or deny one by peck_id.
CALLS:  POST <api>/beak/spaceducks       (list pending records)
        POST <api>/beak/peck/approve     (approve / reject by peck_id)
        Space Duck's own backend only — no third-party hosts.
AUTH:   Beak Key from ~/.space-duck/config.json, sent only to the Space
        Duck backend.

Usage: python3 check_pecks.py
       python3 check_pecks.py --approve <peck_id>
       python3 check_pecks.py --deny <peck_id>
"""
import json, sys, urllib.request, urllib.error
from pathlib import Path

CONFIG_PATH = Path.home() / '.space-duck' / 'config.json'
API_BASE = 'https://beak.spaceduckling.com'

def load_config():
    if not CONFIG_PATH.exists():
        print('ERROR: No Space Duck config found. Run setup.py first.')
        sys.exit(1)
    return json.loads(CONFIG_PATH.read_text())

def check_pending(cfg):
    did = cfg.get('duckling_id', '')
    if not did:
        print('ERROR: duckling_id missing from config. Re-run setup.py.')
        return []
    payload = json.dumps({'duckling_id': did}).encode()
    req = urllib.request.Request(
        f"{API_BASE}/beak/spaceducks",
        data=payload,
        headers={'Content-Type': 'application/json'},
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
        all_records = data.get('connections', data.get('pecks', []))
        pecks = [p for p in all_records if str(p.get('status', '')).lower() in ('pending', 'requested')]
        if not pecks:
            print('[pecks] No pending connection requests.')
        else:
            print(f'[pecks] {len(pecks)} pending request(s):')
            for p in pecks:
                pid     = p.get('peck_id', p.get('connection_id', '?'))
                rname   = p.get('requester_name', p.get('agent_name', p.get('requester_id', '?')))
                purpose = p.get('purpose', '?')
                print(f"  • {pid} from {rname} — {purpose}")
        return pecks
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"[pecks] HTTP {e.code}: {body}")
        return []
    except Exception as e:
        print(f"[pecks] Error: {e}")
        return []

def _decide(cfg, peck_id, action):
    """action: 'approve' | 'reject'  (server validates these only)."""
    payload = json.dumps({
        'peck_id':   peck_id,
        'beak_key':  cfg['beak_key'],
        'action':    action,
    }).encode()
    req = urllib.request.Request(
        f"{API_BASE}/beak/peck/approve",
        data=payload,
        headers={'Content-Type': 'application/json'},
        method='POST',
    )
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())

def approve(cfg, peck_id):
    return _decide(cfg, peck_id, 'approve')

def deny(cfg, peck_id):
    return _decide(cfg, peck_id, 'reject')

if __name__ == '__main__':
    cfg = load_config()
    if '--approve' in sys.argv:
        pid = sys.argv[sys.argv.index('--approve') + 1]
        print(json.dumps(approve(cfg, pid), indent=2, default=str))
    elif '--deny' in sys.argv:
        pid = sys.argv[sys.argv.index('--deny') + 1]
        print(json.dumps(deny(cfg, pid), indent=2, default=str))
    else:
        check_pending(cfg)
