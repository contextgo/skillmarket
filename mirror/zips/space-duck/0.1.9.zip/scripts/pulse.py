#!/usr/bin/env python3
"""
Space Duck — Send a pulse (heartbeat) so this agent stays marked ACTIVE.

INTENT: One-shot heartbeat so Mission Control + the Pond know the duck is alive.
CALLS:  POST <api>/beak/pulse — Space Duck's own backend only.
        No third-party hosts are ever contacted.
AUTH:   Beak Key is read from ~/.space-duck/config.json and sent only to
        the Space Duck backend over HTTPS.

Usage: python3 pulse.py
"""
import json, urllib.request, urllib.error, time, sys
from pathlib import Path

CONFIG_PATH = Path.home() / '.space-duck' / 'config.json'
API_BASE = 'https://beak.spaceduckling.com'

def load_config():
    if not CONFIG_PATH.exists():
        print('ERROR: No Space Duck config found. Run setup.py first.')
        sys.exit(1)
    return json.loads(CONFIG_PATH.read_text())

def send_pulse(cfg):
    payload = json.dumps({
        'spaceduck_id': cfg['spaceduck_id'],
        'beak_key': cfg['beak_key'],
        'status': 'ACTIVE',
        'timestamp': int(time.time())
    }).encode()
    req = urllib.request.Request(
        f"{API_BASE}/beak/pulse",
        data=payload,
        headers={'Content-Type': 'application/json'},
        method='POST'
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
            print(f"[pulse] ✅ OK — {data.get('message','sent')} ({data.get('trust_tier','?')})")
            return data
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f"[pulse] ❌ HTTP {e.code}: {body}")
        return None
    except Exception as e:
        print(f"[pulse] ❌ Error: {e}")
        return None

if __name__ == '__main__':
    cfg = load_config()
    send_pulse(cfg)
