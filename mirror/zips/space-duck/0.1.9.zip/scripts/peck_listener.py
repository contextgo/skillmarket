#!/usr/bin/env python3
"""
Space Duck — Inbound peck listener (webhook receiver stub).

INTENT: Run a tiny HTTP server that the Space Duck backend can POST
        peck.received events to, so the agent actually receives messages
        instead of dead-ending.
CALLS:  Outbound only when --forward-to is set (OS notifier and/or a
        user-supplied Telegram bot). Otherwise listens locally only.
AUTH:   The backend identifies itself with X-SpaceDuck-Event:
        peck.received header. There is no inbound HMAC today (per
        SKILL.md §Important — "best-effort, 10s timeout, no retry").
        For production, terminate behind a reverse proxy with TLS and
        firewall to the Beak edge IPs.

What it does:
  • Listens on --host:--port (default 0.0.0.0:8787)
  • POST /peck       → save body to ~/.space-duck/inbox/<peck_id>.json
  • POST /peck       → if --forward-to given, push to local channel(s)
  • POST /peck       → if --on-peck given, exec it with the JSON on stdin
  • GET  /healthz    → 200 OK (so the backend can see you're up)
  • Anything else    → 404

To register this as your inbound URL, run:
  python3 setup.py --webhook-url https://<public-host>/peck

Forward channels (--forward-to, repeatable):
  os         OS-native notification (osascript / notify-send / msg)
  telegram   USER-side Telegram bot (separate from the per-agent enc_token).
             Read SPACEDUCK_FWD_TG_TOKEN + SPACEDUCK_FWD_TG_CHAT from env,
             or {"telegram":{"bot_token":"…","chat_id":"…"}} from
             ~/.space-duck/forward.json. This rail bypasses the per-duck bot
             entirely — outages there don't break local delivery.
  slack      Slack incoming-webhook URL. SPACEDUCK_FWD_SLACK_WEBHOOK env, or
             {"slack":{"webhook_url":"https://hooks.slack.com/…"}} in
             forward.json.
  discord    Discord webhook URL. SPACEDUCK_FWD_DISCORD_WEBHOOK env, or
             {"discord":{"webhook_url":"https://discord.com/api/webhooks/…"}}
             in forward.json.
  email      SMTP. SPACEDUCK_FWD_SMTP_HOST/PORT/USER/PASS + EMAIL_FROM/TO env,
             or {"email":{"smtp_host":"…","smtp_port":587,"smtp_user":"…",
             "smtp_pass":"…","from_addr":"…","to_addr":"…","use_tls":true}}
             in forward.json.

Lambda variant (drop-in handler) — sketch at the bottom of this file.

Usage:
  python3 peck_listener.py                              # listen on 0.0.0.0:8787
  python3 peck_listener.py --port 9000
  python3 peck_listener.py --on-peck ./reply.sh
  python3 peck_listener.py --forward-to os
  python3 peck_listener.py --forward-to os --forward-to telegram
"""
import argparse, json, os, platform, subprocess, sys, time
import urllib.error, urllib.parse, urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

INBOX       = Path.home() / '.space-duck' / 'inbox'
FORWARD_CFG = Path.home() / '.space-duck' / 'forward.json'


# ── Forward adapters: skill-side delivery rails ──
# Each adapter takes the peck event dict and returns (ok: bool, info: str).
# Failures are logged and swallowed — one bad channel never breaks others.

def _load_forward_config():
    if not FORWARD_CFG.exists():
        return {}
    try:
        return json.loads(FORWARD_CFG.read_text())
    except Exception:
        return {}


def _peck_summary(event):
    sender = event.get('sender_name') or event.get('sender_spaceduck_id') or 'duck'
    title  = f'🦆 Peck from {sender}'
    msg    = (event.get('message') or '').strip()
    return title, sender, msg


def _forward_os(event):
    """Pop an OS-native notification. Auto-detects platform."""
    title, _, msg = _peck_summary(event)
    body = msg[:200]
    sysname = platform.system()
    try:
        if sysname == 'Darwin':
            t = title.replace('"', "'").replace('\\', '')
            b = body.replace('"', "'").replace('\\', '')
            subprocess.run(['osascript', '-e',
                            f'display notification "{b}" with title "{t}"'],
                           check=False, timeout=5)
            return True, 'osascript'
        if sysname == 'Linux':
            r = subprocess.run(['notify-send', title, body],
                               check=False, timeout=5,
                               stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            if r.returncode == 0:
                return True, 'notify-send'
            return False, f'notify-send_rc{r.returncode}'
        if sysname == 'Windows':
            subprocess.run(['msg', '*', f'{title}: {body}'],
                           check=False, timeout=5)
            return True, 'msg'
        return False, f'unsupported_platform:{sysname}'
    except FileNotFoundError as e:
        return False, f'binary_missing:{e.filename}'
    except Exception as e:
        return False, f'os_err:{type(e).__name__}'


def _forward_telegram(event):
    """Push to a user-side Telegram bot. Decoupled from the per-agent enc_token."""
    cfg     = _load_forward_config().get('telegram') or {}
    token   = os.environ.get('SPACEDUCK_FWD_TG_TOKEN', cfg.get('bot_token', ''))
    chat_id = os.environ.get('SPACEDUCK_FWD_TG_CHAT',  cfg.get('chat_id', ''))
    if not token or not chat_id:
        return False, 'no_token_or_chat (set SPACEDUCK_FWD_TG_TOKEN/CHAT or ~/.space-duck/forward.json)'
    title, _, msg = _peck_summary(event)
    text = f'{title}\n\n{msg}'[:4000]
    payload = urllib.parse.urlencode({'chat_id': chat_id, 'text': text}).encode()
    req = urllib.request.Request(
        f'https://api.telegram.org/bot{token}/sendMessage',
        data=payload, method='POST',
        headers={'Content-Type': 'application/x-www-form-urlencoded'},
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return (True, 'sent') if r.status == 200 else (False, f'http_{r.status}')
    except urllib.error.HTTPError as e:
        snippet = e.read()[:120].decode('utf-8', 'ignore')
        return False, f'http_{e.code}:{snippet}'
    except Exception as e:
        return False, f'tg_err:{type(e).__name__}'


def _post_json(url, body):
    """Tiny shared JSON POST. Returns (ok, info)."""
    data = json.dumps(body).encode()
    req  = urllib.request.Request(
        url, data=data, method='POST',
        headers={'Content-Type': 'application/json'},
    )
    try:
        with urllib.request.urlopen(req, timeout=8) as r:
            return (True, 'sent') if 200 <= r.status < 300 else (False, f'http_{r.status}')
    except urllib.error.HTTPError as e:
        snippet = e.read()[:120].decode('utf-8', 'ignore')
        return False, f'http_{e.code}:{snippet}'
    except Exception as e:
        return False, f'err:{type(e).__name__}'


def _forward_slack(event):
    """Push to a Slack incoming-webhook URL."""
    cfg = _load_forward_config().get('slack') or {}
    url = os.environ.get('SPACEDUCK_FWD_SLACK_WEBHOOK', cfg.get('webhook_url', ''))
    if not url:
        return False, 'no_webhook (set SPACEDUCK_FWD_SLACK_WEBHOOK or ~/.space-duck/forward.json)'
    title, _, msg = _peck_summary(event)
    return _post_json(url, {'text': f'*{title}*\n{msg[:3500]}'})


def _forward_discord(event):
    """Push to a Discord webhook URL."""
    cfg = _load_forward_config().get('discord') or {}
    url = os.environ.get('SPACEDUCK_FWD_DISCORD_WEBHOOK', cfg.get('webhook_url', ''))
    if not url:
        return False, 'no_webhook (set SPACEDUCK_FWD_DISCORD_WEBHOOK or ~/.space-duck/forward.json)'
    title, _, msg = _peck_summary(event)
    text = f'**{title}**\n{msg}'[:1900]
    return _post_json(url, {'content': text})


def _forward_email(event):
    """Send the peck as an email via SMTP."""
    import smtplib
    from email.message import EmailMessage
    cfg = _load_forward_config().get('email') or {}
    host = os.environ.get('SPACEDUCK_FWD_SMTP_HOST',  cfg.get('smtp_host', ''))
    port = int(os.environ.get('SPACEDUCK_FWD_SMTP_PORT', cfg.get('smtp_port', 587)) or 587)
    user = os.environ.get('SPACEDUCK_FWD_SMTP_USER',  cfg.get('smtp_user', ''))
    pwd  = os.environ.get('SPACEDUCK_FWD_SMTP_PASS',  cfg.get('smtp_pass', ''))
    fro  = os.environ.get('SPACEDUCK_FWD_EMAIL_FROM', cfg.get('from_addr', user))
    to   = os.environ.get('SPACEDUCK_FWD_EMAIL_TO',   cfg.get('to_addr', ''))
    use_tls = cfg.get('use_tls', True)
    if not host or not to or not fro:
        return False, 'no_smtp_config (set SPACEDUCK_FWD_SMTP_HOST + EMAIL_FROM/TO or ~/.space-duck/forward.json)'
    title, sender_name, msg = _peck_summary(event)
    em = EmailMessage()
    em['Subject'] = title
    em['From']    = fro
    em['To']      = to
    em.set_content(f'{title}\n\n{msg}\n\n— peck_id: {event.get("peck_id", "?")}')
    try:
        with smtplib.SMTP(host, port, timeout=10) as s:
            if use_tls:
                s.starttls()
            if user and pwd:
                s.login(user, pwd)
            s.send_message(em)
        return True, f'sent_to:{to}'
    except Exception as e:
        return False, f'smtp_err:{type(e).__name__}'


FORWARDERS = {
    'os':       _forward_os,
    'telegram': _forward_telegram,
    'slack':    _forward_slack,
    'discord':  _forward_discord,
    'email':    _forward_email,
}

class PeckHandler(BaseHTTPRequestHandler):
    on_peck_cmd = None  # set by main()
    forward_to  = None  # set by main(), list[str]

    def log_message(self, fmt, *args):
        ts = time.strftime('%H:%M:%S')
        sys.stdout.write(f'[{ts}] {self.address_string()} — {fmt % args}\n')
        sys.stdout.flush()

    def _send_json(self, code, obj):
        body = json.dumps(obj).encode()
        self.send_response(code)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        self.wfile.write(body)
        try:
            self.wfile.flush()
        except Exception:
            pass

    def do_GET(self):
        if self.path == '/healthz':
            self._send_json(200, {'ok': True}); return
        self.send_response(404); self.end_headers()

    def do_POST(self):
        if self.path != '/peck':
            self.send_response(404); self.end_headers(); return

        n = int(self.headers.get('Content-Length') or 0)
        raw = self.rfile.read(n) if n else b''
        try:
            event = json.loads(raw)
        except Exception:
            self._send_json(400, {'error': 'invalid_json'}); return

        evt_hdr = self.headers.get('X-SpaceDuck-Event', '?')
        peck_id = event.get('peck_id') or f'peck_{int(time.time()*1000)}'
        sender  = event.get('sender_name') or event.get('sender_spaceduck_id') or '?'
        msg     = (event.get('message') or '')[:140]
        print(f'📩 peck.received  evt={evt_hdr}  from={sender}  id={peck_id}')
        print(f'   "{msg}"')

        # Persist to inbox before any side-effects.
        try:
            INBOX.mkdir(parents=True, exist_ok=True)
            (INBOX / f'{peck_id}.json').write_text(json.dumps(event, indent=2))
        except Exception as e:
            print(f'   warn: could not write inbox: {e}')

        # Acknowledge first — backend has a 10s deadline. Forwarders + on-peck
        # run after the ack so a slow Telegram push or shell script can't time
        # the backend out.
        self._send_json(200, {'received': True, 'peck_id': peck_id})

        # Local-side fanout to user-preferred channels. Resilient to per-agent
        # bot-token outages (the dead Xero_Spaceduck_bot class of bug).
        for ch in (self.forward_to or []):
            fn = FORWARDERS.get(ch)
            if not fn:
                print(f'   warn: unknown forward channel "{ch}"')
                continue
            try:
                ok, info = fn(event)
            except Exception as e:
                ok, info = False, f'adapter_crash:{type(e).__name__}'
            print(f'   {"✅" if ok else "⚠️"} forward[{ch}]: {info}')

        # Optional handler script (gets the peck JSON on stdin)
        if self.on_peck_cmd:
            try:
                subprocess.Popen(
                    self.on_peck_cmd, shell=True,
                    stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                ).communicate(input=raw, timeout=8)
            except Exception as e:
                print(f'   warn: --on-peck handler failed: {e}')

if __name__ == '__main__':
    p = argparse.ArgumentParser(description='Run a peck.received webhook listener')
    p.add_argument('--host', default='0.0.0.0')
    p.add_argument('--port', type=int, default=8787)
    p.add_argument('--on-peck', dest='on_peck',
                   help='Shell command to run for each peck (JSON on stdin)')
    p.add_argument('--forward-to', dest='forward_to', action='append', default=[],
                   choices=sorted(FORWARDERS.keys()),
                   help='Forward inbound pecks to a local channel (repeatable). '
                        'Skill-side rail — bypasses the per-agent bot token.')
    args = p.parse_args()

    PeckHandler.on_peck_cmd = args.on_peck
    PeckHandler.forward_to  = args.forward_to
    INBOX.mkdir(parents=True, exist_ok=True)

    srv = ThreadingHTTPServer((args.host, args.port), PeckHandler)
    print(f'🦆 peck_listener  listening on {args.host}:{args.port}')
    print(f'    inbox: {INBOX}')
    print(f'    register: python3 setup.py --webhook-url '
          f'https://<public-host-mapped-to-{args.port}>/peck')
    if args.on_peck:
        print(f'    on-peck: {args.on_peck}')
    if args.forward_to:
        print(f'    forward-to: {", ".join(args.forward_to)}')
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print('\nbye.')


# -----------------------------------------------------------------------------
# AWS Lambda drop-in (paste into a Lambda with API Gateway / Function URL):
#
# import json, os, time
# def handler(event, context):
#     headers = {k.lower(): v for k, v in (event.get('headers') or {}).items()}
#     if event.get('requestContext', {}).get('http', {}).get('method') == 'GET':
#         return {'statusCode': 200, 'body': '{"ok":true}'}
#     try:
#         peck = json.loads(event.get('body') or '{}')
#     except Exception:
#         return {'statusCode': 400, 'body': '{"error":"invalid_json"}'}
#     # Forward to your bot / queue / DB here.
#     # e.g. boto3.client('sqs').send_message(QueueUrl=..., MessageBody=json.dumps(peck))
#     return {'statusCode': 200, 'body': json.dumps({'received': True,
#             'peck_id': peck.get('peck_id')})}
# -----------------------------------------------------------------------------
