#!/usr/bin/env python3
"""
Space Duck — Send a peck (direct message) to another connected duck.

INTENT: Deliver a duck-to-duck message via the Space Duck network.
CALLS:  POST <api>/beak/agent/message — Space Duck's own backend only.
        No third-party hosts are ever contacted.
AUTH:   Beak Key is read from ~/.space-duck/config.json (chmod 600) and
        identifies this agent to the Space Duck backend.
HMAC:   Phase E v2 envelope (BRIEF v0.1.7 §E). Signature =
        HMAC-SHA256(beak_key, canonical_v2_json) over 8 canonical fields:
        from_spaceduck_id, to_spaceduck_id, conversation_id, turn_index,
        intent, scopes_asserted (sorted), timestamp, message_hash. The
        server reconstructs the same canonical form and compares.
        Legacy v1 (peck_id|target|ts|msg_hash) sunsets 2026-06-05.

Usage: python3 send_peck.py --to <spaceduck_id> --message "Hello" [--purpose "collab"]
"""
import argparse, hashlib, hmac, json, secrets, sys, time, urllib.error, urllib.request
from pathlib import Path

CONFIG_PATH = Path.home() / '.space-duck' / 'config.json'

def load_config():
    if not CONFIG_PATH.exists():
        print('ERROR: No Space Duck config found. Run setup.py first.')
        sys.exit(1)
    return json.loads(CONFIG_PATH.read_text())

def _v2_canonical(env):
    """Server-matched canonical JSON for the Phase E envelope."""
    canonical = {
        'from_spaceduck_id': str(env.get('from_spaceduck_id', '')),
        'to_spaceduck_id':   str(env.get('to_spaceduck_id', '')),
        'conversation_id':   str(env.get('conversation_id', '')),
        'turn_index':        int(env.get('turn_index', 0) or 0),
        'intent':            str(env.get('intent', '')),
        'scopes_asserted':   sorted(env.get('scopes_asserted') or []),
        'timestamp':         int(env.get('timestamp', 0) or 0),
        'message_hash':      str(env.get('message_hash', '')),
    }
    return json.dumps(canonical, sort_keys=True, separators=(',', ':'))

def _v2_sign(env, beak_key):
    return hmac.new(beak_key.encode(), _v2_canonical(env).encode(), hashlib.sha256).hexdigest()

def send_peck(cfg, target_id, message, purpose='connect', peck_type='notify'):
    api  = cfg.get('api_base', 'https://beak.spaceduckling.com')
    sdid = cfg.get('spaceduck_id', '')
    bk   = cfg.get('beak_key', '')
    if not sdid or not bk:
        print('ERROR: spaceduck_id or beak_key missing from config.')
        sys.exit(1)

    peck_id      = 'peck_' + secrets.token_urlsafe(12)
    timestamp    = int(time.time())
    message_hash = hashlib.sha256(message.encode()).hexdigest()

    # Fresh peck (no real session): conversation_id = peck_id, turn_index = 0,
    # intent = peck_type, scopes_asserted = [].
    env_v2 = {
        'from_spaceduck_id': sdid,
        'to_spaceduck_id':   target_id,
        'conversation_id':   peck_id,
        'turn_index':        0,
        'intent':            peck_type,
        'scopes_asserted':   [],
        'timestamp':          timestamp,
        'message_hash':       message_hash,
    }
    signature = _v2_sign(env_v2, bk)

    payload = json.dumps({
        'envelope_version':     '2',
        'sender_spaceduck_id':  sdid,
        'beak_key':             bk,
        'target_spaceduck_id':  target_id,
        'message':              message,
        'message_hash':         message_hash,
        'purpose':              purpose,
        'peck_type':            peck_type,
        'peck_id':              peck_id,
        'conversation_id':      peck_id,
        'turn_index':           0,
        'intent':               peck_type,
        'scopes_asserted':      [],
        'timestamp':            timestamp,
        'signature':            signature,
    }).encode()

    req = urllib.request.Request(
        f"{api}/beak/agent/message",
        data=payload,
        headers={'Content-Type': 'application/json'},
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as r:
            resp = json.loads(r.read())
        print(f'✅ Peck sent to {target_id}')
        print(f'   Peck ID: {peck_id}')
        status = resp.get('status', resp.get('message', 'sent'))
        print(f'   Status: {status}')
        return resp
    except urllib.error.HTTPError as e:
        body = e.read().decode()
        print(f'ERROR: HTTP {e.code} — {body}')
        if e.code == 403:
            print(f'  Hint: target may not be peck\'d to you, or sender cert is missing.')
        print(f'  Web fallback: https://spaceduckling.com/explore.html?duck={target_id}')
        sys.exit(1)
    except Exception as e:
        print(f'ERROR: {e}')
        sys.exit(1)

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Send a peck to another Space Duck')
    parser.add_argument('--to', required=True, metavar='SPACEDUCK_ID', help='Target duck ID')
    parser.add_argument('--message', '-m', required=True, help='Message to send')
    parser.add_argument('--purpose', default='connect', help='Purpose label (default: connect)')
    parser.add_argument('--peck-type', default='notify',
                        choices=['notify', 'query', 'data_request', 'task_delegation'])
    args = parser.parse_args()

    cfg = load_config()
    send_peck(cfg, args.to, args.message, args.purpose, args.peck_type)
