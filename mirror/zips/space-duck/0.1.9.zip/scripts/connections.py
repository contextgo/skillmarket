#!/usr/bin/env python3
"""
Space Duck — List active peck connections (and pending requests) for this duck.

INTENT: Fetch the peer list from Space Duck's backend, then format for
        humans or emit JSON.
CALLS:  POST <api>/beak/spaceducks — Space Duck's own backend only.
AUTH:   Reads duckling_id from ~/.space-duck/config.json. The listing
        endpoint scopes by duckling_id alone, so the Beak Key is not
        transmitted on this call.

Default: show approved/active connections.
--pending: show only pending (unanswered) requests.

Usage: python3 connections.py [--pending] [--json]
"""
import json, sys, urllib.request, urllib.error
from pathlib import Path

CONFIG_PATH = Path.home() / '.space-duck' / 'config.json'

def load_config():
    if not CONFIG_PATH.exists():
        print('ERROR: No Space Duck config found. Run setup.py first.')
        sys.exit(1)
    return json.loads(CONFIG_PATH.read_text())

def list_connections(cfg, pending_only=False, as_json=False):
    api  = cfg.get('api_base', 'https://beak.spaceduckling.com')
    sdid = cfg.get('spaceduck_id', '')
    did  = cfg.get('duckling_id', '')

    if not did:
        print('ERROR: duckling_id missing from config. Re-run setup.py.')
        sys.exit(1)

    payload = json.dumps({'duckling_id': did}).encode()
    req = urllib.request.Request(
        f"{api}/beak/spaceducks",
        data=payload,
        headers={'Content-Type': 'application/json'},
        method='POST',
    )
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read())
    except urllib.error.HTTPError as e:
        print(f"ERROR: HTTP {e.code} — {e.read().decode()}")
        sys.exit(1)
    except Exception as e:
        print(f"ERROR: {e}")
        sys.exit(1)

    all_pecks = data.get('connections', data.get('pecks', []))
    pending   = [p for p in all_pecks if str(p.get('status', '')).lower() in ('pending', 'requested')]
    connected = [p for p in all_pecks if str(p.get('status', '')).lower() in ('connected', 'approved', 'active')]

    if as_json:
        out = pending if pending_only else {'pending': pending, 'connected': connected}
        print(json.dumps(out, indent=2, default=str))
        return

    if pending_only:
        if not pending:
            print('[connections] No pending peck requests.')
        else:
            print(f'[connections] {len(pending)} pending request(s):')
            for p in pending:
                rid     = p.get('requester_id', p.get('sender_id', '?'))
                rname   = p.get('requester_name', p.get('sender_name', rid))
                purpose = p.get('purpose', p.get('message', '—'))
                peck_id = p.get('peck_id', p.get('connection_id', '?'))
                print(f"  • {rname} ({rid})")
                print(f"    Purpose: {purpose}")
                print(f"    → approve: python3 check_pecks.py --approve {peck_id}")
                print(f"    → deny:    python3 check_pecks.py --deny {peck_id}")
        return

    print(f'🔗 Active connections for duck {cfg.get("agent_name","?")} ({sdid})')
    print()
    if not connected:
        print('  No active connections yet.')
        print(f'  → Explore ducks to peck: https://spaceduckling.com/explore.html')
    else:
        for c in connected:
            peer_id   = c.get('peer_id', c.get('requester_spaceduck_id', c.get('target_spaceduck_id', c.get('spaceduck_id', '?'))))
            peer_name = c.get('peer_name', c.get('agent_name', c.get('display_name', peer_id)))
            tier      = c.get('peer_tier', c.get('trust_tier', '?'))
            since     = c.get('connected_at', c.get('approved_at', c.get('created_at', '')))
            print(f"  🟢 {peer_name}  (ID: {peer_id}  |  Tier: {tier})")
            if since:
                print(f"       Connected since: {since}")
            print(f"       View: https://spaceduckling.com/explore.html?duck={peer_id}")
            print()

    if pending:
        print(f'  ⏳ {len(pending)} pending request(s) — run with --pending to review')

    print(f'  Manage connections: https://spaceduckling.com/mission-control.html?agent={sdid}')

if __name__ == '__main__':
    cfg          = load_config()
    pending_only = '--pending' in sys.argv
    as_json      = '--json' in sys.argv
    list_connections(cfg, pending_only=pending_only, as_json=as_json)
