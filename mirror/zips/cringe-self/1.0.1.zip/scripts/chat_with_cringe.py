#!/usr/bin/env python3
"""
沉浸式黑历史对话脚本
模拟和过去的自己聊天的体验
"""
import json
import os
import random
import sys


def load_persona(persona_dir):
    """加载人格文件"""
    with open(os.path.join(persona_dir, "metadata.json"), "r", encoding="utf-8") as f:
        metadata = json.load(f)
    
    persona_md = ""
    memory_md = ""
    
    persona_path = os.path.join(persona_dir, "persona.md")
    memory_path = os.path.join(persona_dir, "memory.md")
    
    if os.path.exists(persona_path):
        with open(persona_path, "r", encoding="utf-8") as f:
            persona_md = f.read()
    
    if os.path.exists(memory_path):
        with open(memory_path, "r", encoding="utf-8") as f:
            memory_md = f.read()
    
    return metadata, persona_md, memory_md


def list_personas():
    """列出所有已创建的人格"""
    base_dir = os.path.expanduser("~/.qclaw/skills/cringe-self/exes")
    if not os.path.exists(base_dir):
        return []
    
    personas = []
    for item in os.listdir(base_dir):
        item_path = os.path.join(base_dir, item)
        if os.path.isdir(item_path):
            metadata_path = os.path.join(item_path, "metadata.json")
            if os.path.exists(metadata_path):
                with open(metadata_path, "r", encoding="utf-8") as f:
                    metadata = json.load(f)
                personas.append({
                    "dir": item_path,
                    "name": metadata.get("name", item),
                    "period": metadata.get("basic", {}).get("year_range", "未知")
                })
    return personas


def print_chat_header(name, period):
    print(f"""
╔══════════════════════════════════════════════════╗
║  🕰️  穿越模式已启动                              ║
║  正在连接: {name:<20}           ║
║  时间坐标: {period:<20}           ║
╚══════════════════════════════════════════════════╝

💡 提示: 输入 'exit' 退出, 'help' 查看可用话题
""")


def get_response_style(metadata):
    """根据元数据生成回复风格"""
    basic = metadata.get("basic", {})
    persona = metadata.get("persona", {})
    
    nickname = basic.get("nickname", "我")
    styles = persona.get("speaking_style", ["中二"])
    catchphrases = persona.get("catchphrases", [])
    
    return {
        "nickname": nickname,
        "styles": styles,
        "catchphrases": catchphrases
    }


def generate_response(user_input, metadata, memories):
    """
    模拟黑历史自己的回复
    实际使用时由 LLM 根据 persona 和 memory 生成
    """
    style = get_response_style(metadata)
    nickname = style["nickname"]
    catchphrases = style["catchphrases"]
    
    # 简单的关键词匹配（演示用）
    responses = []
    
    if any(kw in user_input for kw in ["在吗", "在不在", "在？"]):
        responses = [
            f"{nickname}日理万机，你有事？",
            f"在啊，刚打完一把LOL。",
            f"{random.choice(catchphrases) if catchphrases else '说吧'}"
        ]
    elif any(kw in user_input for kw in ["签名", "说说", "空间"]):
        sigs = memories.get("signatures", [])
        if sigs:
            responses = [
                f"你说这个？『{random.choice(sigs)}』—— 当时觉得酷毙了",
                f"别提了，那个签名我现在看了都想找个地缝钻进去",
                f"你截图了吗？千万别截图啊！"
            ]
        else:
            responses = [f"{nickname}的签名当然是机密"]
    elif any(kw in user_input for kw in ["朋友", "同学", "小明"]):
        friends = memories.get("friends", [])
        if friends:
            responses = [
                f"{random.choice(friends)}？那小子现在怎么样了",
                f"记得啊，当年我们一起通宵打游戏",
                f"别提了，那货欠我五块钱还没还"
            ]
        else:
            responses = [f"{nickname}的朋友遍天下，你说哪个？"]
    elif any(kw in user_input for kw in ["建议", "忠告", "告诉我"]):
        responses = [
            f"{nickname}的建议都是人生哲理：别在QQ空间发矫情文学，会被截图的",
            f"珍惜那个愿意听你吹牛的朋友，十年后你们可能天各一方",
            f"厚刘海不会让你变帅，它只会让你看起来像个傻子"
        ]
    elif any(kw in user_input for kw in ["现在", "未来", "以后"]):
        responses = [
            f"以后的事谁说得准，{nickname}只活在当下",
            f"你问这个干嘛？难道你是穿越来的？",
            f"{nickname}以后肯定是个传奇人物"
        ]
    else:
        default_catch = random.choice(catchphrases) if catchphrases else "你不懂"
        responses = [
            f"{default_catch}",
            f"{nickname}觉得你在说废话",
            f"所以呢？",
            f"这事儿{nickname}早就看透了"
        ]
    
    return random.choice(responses)


def print_help():
    print("""
📖 可用话题:
   基础对话: "在吗", "你好"
   黑历史:   "看看我当时的签名", "还记得那个说说吗"
   朋友:     "小明现在怎么样", "还记得我们班那个谁吗"
   成长:     "给现在的我一些建议", "你觉得我以后怎么样"
   退出:     输入 'exit' 或 'quit'
""")


def main():
    personas = list_personas()
    
    if not personas:
        print("❌ 还没有创建任何黑历史人格")
        print("请先运行: python scripts/create_cringe_self.py")
        sys.exit(1)
    
    # 选择人格
    print("🎭 选择要召唤的黑历史自己:\n")
    for i, p in enumerate(personas, 1):
        print(f"  {i}. {p['name']} ({p['period']})")
    
    choice = input("\n选择编号: ").strip()
    try:
        selected = personas[int(choice) - 1]
    except (ValueError, IndexError):
        print("无效选择")
        sys.exit(1)
    
    # 加载人格
    metadata, persona_md, memory_md = load_persona(selected["dir"])
    memories = metadata.get("memories", {})
    
    # 开始对话
    print_chat_header(selected["name"], selected["period"])
    
    # 开场白
    nickname = metadata.get("basic", {}).get("nickname", "哥")
    print(f"【{nickname}】> 哟，未来的我？找我啥事？\n")
    
    while True:
        try:
            user_input = input("【现在的你】> ").strip()
        except EOFError:
            break
        
        if not user_input:
            continue
        
        if user_input.lower() in ["exit", "quit", "退出"]:
            print(f"\n【{nickname}】> 走了，别忘了我。")
            break
        
        if user_input.lower() in ["help", "帮助", "?"]:
            print_help()
            continue
        
        response = generate_response(user_input, metadata, memories)
        print(f"【{nickname}】> {response}\n")


if __name__ == "__main__":
    main()
