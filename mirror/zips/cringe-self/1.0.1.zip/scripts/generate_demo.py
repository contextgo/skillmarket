#!/usr/bin/env python3
"""
生成演示对话截图的文本版本
用于投稿时的配图
"""

DEMO_CONVERSATIONS = [
    {
        "title": "场景一：给建议",
        "persona": "2012年高中生（自称：哥）",
        "dialogue": [
            ("现在的你", "给现在的我一些建议吧"),
            ("哥", "哥的建议都是人生哲理："),
            ("哥", "别他妈在QQ空间发矫情文学了"),
            ("哥", "会被截图留档的"),
            ("哥", "厚刘海不会让你变帅"),
            ("哥", "它只会让你看起来像个傻子"),
            ("哥", "还有..."),
            ("哥", "珍惜那个愿意听你吹牛的朋友"),
            ("哥", "十年后你们可能天各一方"),
        ]
    },
    {
        "title": "场景二：品鉴签名",
        "persona": "2008年初中生（自称：硪）",
        "dialogue": [
            ("现在的你", "看看我当时的签名："),
            ("现在的你", '\"硪的吢裡呮冇伱，伱永远不会冇硪\"'),
            ("硪", "好家伙"),
            ("硪", "火星文+矫情文学双重debuff"),
            ("硪", "这是2010年前后的QQ空间标配签名"),
            ("硪", "当时的你觉得这叫'文艺'"),
            ("硪", "现在的你看完想找个地缝钻进去"),
            ("硪", "但是！"),
            ("硪", "十五岁的你写这句话的时候"),
            ("硪", "是真的相信的"),
        ]
    },
    {
        "title": "场景三：回忆朋友",
        "persona": "2012年高中生（自称：哥）",
        "dialogue": [
            ("现在的你", "还记得小明吗"),
            ("哥", "哦那个杀马特？"),
            ("哥", "他后来怎么样了"),
            ("现在的你", "他现在在送外卖"),
            ("哥", "哈？？"),
            ("哥", "就那个说要成为美发界传奇的小明？？"),
            ("哥", "人生真是充满意外"),
            ("哥", "..."),
            ("哥", "那他头发还那么多吗"),
        ]
    }
]


def print_demo(conversation):
    """打印单个演示对话"""
    print(f"\n{'='*60}")
    print(f"📱 {conversation['title']}")
    print(f"🎭 人格：{conversation['persona']}")
    print(f"{'='*60}\n")
    
    for speaker, text in conversation['dialogue']:
        if speaker == "现在的你":
            print(f"┌─ [现在的你]")
            print(f"│  {text}")
            print(f"└─")
        else:
            print(f"    ┌─ [{speaker}]")
            print(f"    │  {text}")
            print(f"    └─")
    print()


def print_all_demos():
    """打印所有演示对话"""
    print("""
╔══════════════════════════════════════════════════════════════╗
║           🕰️  黑历史穿越机 · 演示对话合集                      ║
║           用于投稿配图 / 视频录屏 / 朋友圈分享                 ║
╚══════════════════════════════════════════════════════════════╝
""")
    
    for demo in DEMO_CONVERSATIONS:
        print_demo(demo)
    
    print(f"\n{'='*60}")
    print("💡 提示：")
    print("   - 复制以上内容到代码编辑器/终端截图")
    print("   - 或使用终端录屏工具（如 asciinema）")
    print("   - 也可以用 QClaw 实际运行后截图")
    print(f"{'='*60}\n")


def export_for_video():
    """导出适合视频字幕的格式"""
    print("\n" + "="*60)
    print("📹 视频字幕版")
    print("="*60 + "\n")
    
    for demo in DEMO_CONVERSATIONS:
        print(f"\n【{demo['title']}】")
        print(f"人格：{demo['persona']}\n")
        
        for speaker, text in demo['dialogue']:
            prefix = "我：" if speaker == "现在的你" else f"{speaker}："
            print(f"{prefix}{text}")
        print()


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "--video":
        export_for_video()
    else:
        print_all_demos()
