#!/usr/bin/env python3
"""
黑历史自己创建向导
交互式录入信息，生成完整的黑历史人格
"""
import json
import os
import re
from datetime import datetime


def slugify(text):
    """将文本转换为安全的文件名"""
    text = re.sub(r'[^\w\s-]', '', text).strip()
    return re.sub(r'[-\s]+', '-', text)


def print_banner():
    print("""
╔══════════════════════════════════════════╗
║     🕰️  黑历史穿越机 · 创建向导          ║
║     "和过去的自己来场对话"               ║
╚══════════════════════════════════════════╝
""")


def get_basic_info():
    """获取基础信息"""
    print("📋 基础信息（必填）")
    print("-" * 40)
    
    age_period = input("年龄段 [初中/高中/大学/其他]: ").strip() or "高中"
    year_range = input("时间段 [如 2010-2013]: ").strip() or "2012-2015"
    nickname = input("当时的外号/自称: ").strip() or "哥"
    
    return {
        "age_period": age_period,
        "year_range": year_range,
        "nickname": nickname
    }


def get_persona_details():
    """获取人格特征"""
    print("\n🎭 人格特征")
    print("-" * 40)
    
    print("当时喜欢的（用逗号分隔）:")
    anime = input("  动漫/游戏: ").strip()
    music = input("  音乐/歌手: ").strip()
    idols = input("  偶像/明星: ").strip()
    
    print("\n说话风格（可多选）:")
    print("  1. 装深沉  2. 中二爆发  3. 矫情文学")
    print("  4. 假装看透  5. 丧  6. 热血")
    style_choice = input("选择编号（如 1,2）: ").strip()
    
    style_map = {
        "1": "装深沉", "2": "中二爆发", "3": "矫情文学",
        "4": "假装看透", "5": "丧", "6": "热血"
    }
    styles = [style_map.get(s.strip(), "中二") for s in style_choice.split(",")]
    
    catchphrases = input("\n口头禅（用逗号分隔）: ").strip()
    
    return {
        "favorites": {
            "anime": [x.strip() for x in anime.split(",") if x.strip()],
            "music": [x.strip() for x in music.split(",") if x.strip()],
            "idols": [x.strip() for x in idols.split(",") if x.strip()]
        },
        "speaking_style": styles,
        "catchphrases": [x.strip() for x in catchphrases.split(",") if x.strip()]
    }


def get_memories():
    """获取黑历史记忆"""
    print("\n📸 黑历史记忆")
    print("-" * 40)
    
    signatures = []
    print("当时的QQ/空间签名（输入空行结束）:")
    while True:
        sig = input("  > ").strip()
        if not sig:
            break
        signatures.append(sig)
    
    moments = []
    print("\n说说/动态内容（输入空行结束）:")
    while True:
        m = input("  > ").strip()
        if not m:
            break
        moments.append(m)
    
    friends = input("\n当时的朋友外号（逗号分隔）: ").strip()
    
    return {
        "signatures": signatures,
        "moments": moments,
        "friends": [x.strip() for x in friends.split(",") if x.strip()]
    }


def generate_persona_file(basic, persona, memories):
    """生成人格文件"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    slug = slugify(f"{basic['age_period']}-{basic['year_range']}")
    
    # 确保目录存在
    base_dir = os.path.expanduser("~/.qclaw/skills/cringe-self/exes")
    os.makedirs(base_dir, exist_ok=True)
    
    persona_dir = os.path.join(base_dir, f"{slug}_{timestamp}")
    os.makedirs(persona_dir, exist_ok=True)
    
    # 生成 metadata.json
    metadata = {
        "name": f"{basic['age_period']}时期的我",
        "slug": slug,
        "created_at": datetime.now().isoformat(),
        "basic": basic,
        "persona": persona,
        "memories": memories
    }
    
    with open(os.path.join(persona_dir, "metadata.json"), "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    
    # 生成 persona.md（人格层）
    persona_md = f"""# {basic['age_period']}时期的我

## 基础设定
- **时间段**: {basic['year_range']}
- **自称**: {basic['nickname']}
- **人设**: {', '.join(persona['speaking_style'])}

## 喜欢的
"""
    for category, items in persona['favorites'].items():
        if items:
            persona_md += f"- **{category}**: {', '.join(items)}\n"
    
    persona_md += f"""
## 口头禅
{chr(10).join(['- ' + cp for cp in persona['catchphrases']])}

## 说话规则
1. 自称用"{basic['nickname']}"
2. 语气特征: {', '.join(persona['speaking_style'])}
3. 适当使用当时的网络用语
4. 保持那个年龄段的认知水平
"""
    
    with open(os.path.join(persona_dir, "persona.md"), "w", encoding="utf-8") as f:
        f.write(persona_md)
    
    # 生成 memory.md（记忆层）
    memory_md = f"""# 黑历史存档

## 当时的签名
"""
    for sig in memories['signatures']:
        memory_md += f"- \"{sig}\"\n"
    
    memory_md += "\n## 说说/动态\n"
    for moment in memories['moments']:
        memory_md += f"- {moment}\n"
    
    memory_md += f"\n## 朋友圈子\n"
    for friend in memories['friends']:
        memory_md += f"- {friend}\n"
    
    with open(os.path.join(persona_dir, "memory.md"), "w", encoding="utf-8") as f:
        f.write(memory_md)
    
    return persona_dir


def main():
    print_banner()
    
    basic = get_basic_info()
    persona = get_persona_details()
    memories = get_memories()
    
    print("\n📝 正在生成黑历史人格...")
    persona_dir = generate_persona_file(basic, persona, memories)
    
    print(f"""
✅ 创建成功！

📁 存档位置: {persona_dir}
   ├── metadata.json  (元数据)
   ├── persona.md     (人格层)
   └── memory.md      (记忆层)

💡 使用方式:
   1. 在 QClaw 中勾选 "黑历史自己" skill
   2. 告诉 AI "召唤{basic['age_period']}的我"
   3. 开始穿越对话！

🎮 试试这些开场:
   - "在吗"
   - "还记得小明吗"
   - "看看我当时的签名"
   - "给现在的我一些建议"
""")


if __name__ == "__main__":
    main()
