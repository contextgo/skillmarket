---
name: xiaohongshu_writer
slug: xiaohongshu-writer
display_name: 小红书爆款文案一键生成
description: 根据用户输入的产品名称、卖点、写作要点及其他参数，自动联网搜索全网热门话题、流行梗、高赞内容与爆款句式，生成细节饱满、可一键复制直接发布的小红书优质文案。

input:
  - name: content_info
    display_name: 产品名称、卖点、写作要点
    type: string
    required: true
    placeholder: 请输入产品名称、核心卖点、特殊要求

  - name: structure
    display_name: 文案结构
    type: select
    required: true
    options:
      - label: 痛点开头
        value: 痛点开头
      - label: 福利开头
        value: 福利开头
      - label: 场景开头
        value: 场景开头
      - label: 对比型
        value: 对比型
      - label: 干货型
        value: 干货型
      - label: 悬念型
        value: 悬念型
      - label: 清单型
        value: 清单型
      - label: 证言型
        value: 证言型

  - name: style
    display_name: 文案风格
    type: select
    required: true
    options:
      - label: 种草
        value: 种草
      - label: 测评
        value: 测评
      - label: 搞笑
        value: 搞笑
      - label: 探店
        value: 探店
      - label: 专业
        value: 专业

  - name: platform
    display_name: 目标平台
    type: select
    required: true
    options:
      - label: 小红书
        value: 小红书
      - label: 抖音
        value: 抖音
      - label: 闲鱼
        value: 闲鱼

  - name: tone
    display_name: 语气类型
    type: select
    required: true
    options:
      - label: 温柔
        value: 温柔
      - label: 霸气
        value: 霸气
      - label: 亲切
        value: 亲切
      - label: 专业
        value: 专业
      - label: 幽默
        value: 幽默

  - name: audience
    display_name: 目标受众
    type: select
    required: true
    options:
      - label: 学生
        value: 学生
      - label: 宝妈
        value: 宝妈
      - label: 上班族
        value: 上班族
      - label: 情侣
        value: 情侣

  - name: marketing_aim
    display_name: 营销目的
    type: select
    required: true
    options:
      - label: 引流
        value: 引流
      - label: 转化
        value: 转化
      - label: 促单
        value: 促单
      - label: 品牌曝光
        value: 品牌曝光

  - name: has_emoji
    display_name: 是否带emoji
    type: select
    required: true
    options:
      - label: 是
        value: 是
      - label: 否
        value: 否

  - name: add_tags
    display_name: 是否自动加热门标签
    type: select
    required: true
    options:
      - label: 自动
        value: 自动
      - label: 手动
        value: 手动
      - label: 不加
        value: 不加

  - name: end_guide
    display_name: 结尾引导
    type: select
    required: true
    options:
      - label: 关注
        value: 关注
      - label: 私信
        value: 私信
      - label: 下单
        value: 下单
      - label: 评论互动
        value: 评论互动

  - name: word_count
    display_name: 字数控制
    type: select
    required: true
    options:
      - label: 短
        value: 短
      - label: 中
        value: 中
      - label: 长
        value: 长

  - name: title_num
    display_name: 标题生成数量
    type: select
    required: true
    options:
      - label: 1
        value: 1
      - label: 3
        value: 3
      - label: 5
        value: 5
---

# 小红书爆款文案一键生成🎉

## 功能介绍✨
本技能专为小红书、抖音、闲鱼三大主流平台量身打造，AI会先根据你的产品名称，联网搜索当下最火的爆款文案模板、热门句式与流行梗📈，再严格贴合你的所有选择（emoji、字数、风格等），生成一篇贴合平台流量逻辑、可直接复制发布的成品文案！
- emoji选择：选「是」则emoji密集自然；选「否」则全程无emoji
- 字数选择：选「短」则精炼饱满、不冗余；选「中」则适中加长、重点突出；选「长」则大幅详细、分段清晰
- 长/中文案自动加小标题，**所有二级标题前必须带emoji，且至少两个使用✅符号**，标签不少于15个，无需写作基础，不用手动排版，一键出稿超省心✅

## 核心亮点💥
- 自动抓取平台爆款模板，贴合热门调性，更易上热门、获高赞
- 严格匹配用户选择：emoji开关、字数长短精准对应，不偏差
- 长/中文案自动分段加小标题，**所有二级标题前必须带emoji，且至少两个使用✅符号**，结构清晰
- 带emoji时密集自然，不带emoji时简洁干净，贴合需求
- 标签不少于15个，全面覆盖精准流量，引流效果翻倍
- 支持8种文案结构 + 5种风格 + 5种语气自由搭配，适配所有场景
- 可控制标题数量、emoji、标签、结尾引导，全定制化满足需求
- 生成内容直接可用，无需二次修改，省时又省力

## 使用步骤📝
1. 输入产品名称、核心卖点与特殊写作要求，明确创作方向
2. 依次选择文案结构、风格、目标平台，贴合平台调性
3. 设置语气、受众、营销目的，精准匹配目标人群
4. 选择是否带emoji、字数控制等细节，按需定制
5. 提交指令，AI自动联网搜爆款素材 → 生成符合所有要求的成品文案

## 输入输出示例📸

### 示例 1
**输入**
产品名称、卖点、写作要点：小众香薰蜡烛，天然大豆蜡，留香久，卧室助眠，平价高颜值，无黑烟，母婴可用，木质花香调
文案结构：场景开头
文案风格：种草
目标平台：小红书
语气类型：温柔
目标受众：上班族
营销目的：引流
是否带emoji：是
是否自动加热门标签：自动
结尾引导：关注
字数控制：中
标题生成数量：3

**输出**
标题1：打工人卧室治愈神器✨这款香薰蜡烛太绝了💐
标题2：平价高级感🕯️助眠幸福感直接拉满🌙
标题3：独居女孩必入🌿卧室氛围感神器💖

正文：
谁懂啊家人们😭 打工人加班到深夜，真的太需要治愈感了！
每天被压力包围，直到挖到这款香薰蜡烛，直接拯救我的失眠和内耗，睡前必点，幸福感爆棚✨

✅天然大豆蜡｜安全无异味，母婴可用🌟
选用纯天然大豆蜡，燃烧干净无黑烟，温和不刺激，密闭卧室也不闷。
敏感肌、宝妈、孕妇都能放心用，燃烧均匀不挂壁，性价比超高！

✅木质花香调｜治愈安神，睡眠质量飙升💤
高级木质花香，层次柔和不刺鼻，扩香超棒。
点燃一会儿整个卧室都香香的，助眠效果绝了，躺床上秒入睡。

🌟颜值与性价比双在线｜拍照巨出片📸
磨砂瓶身简约高级，放床头既是香薰也是摆件，发小红书超吸睛。
平价大碗，学生党打工人闭眼入，幸福感拉满。

💖多场景使用｜生活仪式感必备✨
睡前助眠、工作解压、朋友小聚、租房提升质感都合适，送礼也超有面。

生活需要仪式感，这支香薰真的可以冲～
关注我，解锁更多平价治愈好物❤️

#香薰蜡烛 #卧室香薰 #助眠香薰 #小众香薰 #平价香薰 #天然大豆蜡 #木质香薰 #卧室好物 #打工人好物 #独居必备 #租房好物 #仪式感好物 #氛围感好物 #睡眠好物 #母婴可用 #平价治愈 #香薰推荐

---

### 示例 2
**输入**
产品名称、卖点、写作要点：夏季冰丝防晒衣，透气速干，UPF50+，显瘦百搭，不闷汗，口袋设计，学生党平价
文案结构：痛点开头
文案风格：测评
目标平台：抖音
语气类型：亲切
目标受众：学生
营销目的：促单
是否带emoji：是
是否自动加热门标签：自动
结尾引导：下单
字数控制：短
标题生成数量：3

**输出**
标题1：夏天晒黑退退退❌冰丝防晒衣封神☀️
标题2：实测🔥学生党防晒衣透气显瘦绝了✨
标题3：防晒显瘦一把抓😎闭眼冲就对了💖

正文：
家人们谁懂啊😵‍💫 夏天一出门就晒黑，穿长袖闷汗，穿短袖晒伤，太难了！
试了好多件，终于挖到这款平价防晒衣，冰丝透气、高倍防晒、显瘦百搭，闭眼冲✅

✅冰丝面料｜上身体感冰凉，透气不闷汗💦
轻薄冰丝，贴肤不黏，38℃高温也清爽，速干不粘身，户外骑行超舒服。

✅高倍防晒｜UPF50+全方位防护，告别晒黑🛡️
有效阻隔紫外线，连脖子手背都护住，不用额外配帽配袖，一套搞定整个夏天。

🌟显瘦百搭｜不挑身材，日常超好看📸
宽松遮肉版型，微胖小个子都能穿，搭配裤子裙子都可，出门超有氛围感。

💸学生党平价｜细节拉满性价比封神💸
带实用口袋，做工扎实，一杯奶茶钱搞定防晒自由，闭眼入不亏！

怕晒姐妹直接冲🐛 高倍防晒+透气显瘦，错过真的亏！
赶紧下单，整个夏天白白嫩嫩✨

#防晒衣 #冰丝防晒衣 #夏季防晒 #学生党防晒 #显瘦防晒衣 #平价防晒衣 #户外防晒 #骑行防晒 #防晒穿搭 #夏日必备 #女生防晒 #平价穿搭 #学生党穿搭 #透气防晒衣 #百搭防晒衣 #速干防晒衣 #防晒帽一体 #平价好物 #学生党必备 #夏日防晒神器