---
name: plate-swap
description: 美食换盘与创意摄影技能。上传菜品照片，智能替换餐具/桌面/背景，支持多种镜头视角（俯拍/近景/特写），多平台尺寸适配，融合 UI/UX 设计美学原则。适用于美食博主、餐厅宣传、社媒分享。触发词：换盘子、美食摄影、菜品美化。
---

# 美食换盘与创意摄影技能

上传菜品照片 → 换盘换背景 → 创意镜头 → 导出社媒尺寸

---

## ⚠️ 核心原则（必须遵守）

---

### 🚨🚨🚨 最高优先级原则：永远不要改变菜品本身的样子！

> **这是不可违反的铁律**：用户上传照片是有意义的，必须基于这张照片来创作。
> 
> **记住：** 换盘是换盘，镜头是镜头，菜品本身永远是同一个菜品！
> 
> **每次生成前问自己：** 我是在从用户原图推算新角度，还是凭空生成一个新菜品？
> 
> **如果你生成了一个和原图不一样的菜品，你就失败了。**

---

### 1. 必须基于用户上传的照片生成

**正确做法：**
- 使用 wan2.7-image 图像编辑模式
- **完全保留用户菜品的原貌**：形状、色泽、质感、摆盘位置、酱汁分布、每一片肉的位置
- 只改变：镜头角度、餐具、背景、光线
- 不同镜头角度 = 从原图推算该角度的样子，不是重新生成

**错误做法：**
- ❌ 凭空生成一个新菜品
- ❌ 改变菜品的色泽、形状、摆盘
- ❌ 忽略用户上传的参考图
- ❌ 不同角度重新生成一个"类似的"菜品
- ❌ 提示词里只描述菜品类型，不强调"从原图保留"

### 2. 镜头变换 = 从原图推算新角度
> **关键**：不同镜头角度必须基于原图推算，不是重新生成一个类似的菜品。

#### 第一步：识别原图镜头角度
在生成前，先分析用户上传的照片是什么角度：
- **俯拍**：从正上方看，看到的是菜品的平面布局，盘子是圆形/椭圆形
- **近景（45度）**：从侧面斜上方看，能看到菜品的立体感和高度
- **特写**：非常贴近，只看到菜品的局部细节

#### 第二步：推算目标角度
根据原图角度和目标角度，推算变换逻辑：

| 原图角度 | 目标角度 | 推算逻辑 |
|---------|---------|---------|
| 俯拍 | 特写 | **放大推算**：相机zoom in，看到的是同一道菜的放大版。每一片肉、每一滴酱汁的位置、形状、颜色都是原图的放大，不是重新画 |
| 俯拍 | 近景（45度）| **视角推算**：相机从正上方移到侧面。原来是平铺的肉片，现在能看到侧面的厚度；原来看不到汤汁深度，现在能看到液面 |
| 近景 | 特写 | **放大推算**：从45度视角继续贴近，细节更清晰 |
| 近景 | 俯拍 | **反向推算**：从侧面视角回到正上方，立体的侧面信息展平成平面布局 |

#### 第三步：提示词必须包含的推算指令

**特写（Close-up）提示词模板：**
```
CRITICAL: This is an IMAGE EDITING task, NOT a generation task.

Reference image shows: [俯拍/近景] of [菜品描述，包括每一片肉的位置、颜色、纹理]

Task: Create an EXTREME CLOSE-UP shot of the EXACT SAME DISH.

Camera movement: Imagine the camera physically zoomed in to the dish. 
You are seeing the SAME beef slices, SAME sauce, SAME everything - just magnified.

The close-up must show:
- The exact same beef slices from the reference (same position, same color reddish-brown, same white fat edges, same texture pattern)
- The exact same sauce (same orange-yellow color, same glistening oily sheen)
- The exact same ingredients at the exact same positions

DO NOT generate a new dish. DO NOT change any ingredient's appearance. 
This is the original dish zoomed in.

[Then describe plate/background/style changes]
```

**近景（45度 Side Angle）提示词模板：**
```
CRITICAL: This is an IMAGE EDITING task, NOT a generation task.

Reference image shows: [俯拍] of [菜品描述]

Task: Transform to a 45-degree side angle view of the EXACT SAME DISH.

Camera movement: Imagine the camera physically moved from directly above to a 45-degree angle on the side.
You are seeing the SAME dish from a different viewpoint.

Geometry calculation:
- If reference shows beef slices lying flat, the side view should show their edge/thickness
- If reference shows sauce on surface, the side view should show sauce depth and surface angle
- The arrangement of ingredients stays the same, just viewed from a different angle

The food appearance must match:
- Same beef slices (same number, same relative positions to each other, same color)
- Same sauce (same color, same coverage area)
- Same ingredients, same arrangement

DO NOT generate a new dish. This is camera perspective transformation.

[Then describe plate/background/style changes]
```

**错误做法：**
- ❌ 提示词只写"a close-up of braised eggs"（没有推算指令）
- ❌ 提示词只描述风格，不说明如何从原图推算
- ❌ 生成一个"类似的"菜品
- ❌ 菜品的样子和原图不一致
- ❌ 每一片肉的位置、颜色、纹理和原图不一样

### 3. 换盘 = 替换餐具/背景，保留菜品
- 保留用户的菜品（形状、色泽、质感不变）
- 替换：餐具、桌面、背景
- 调整：光线、色调（符合新场景，更有食欲感）

### 4. 必须使用 wan2.7-image 模型生图
> **重要**：本 skill 强制使用万相2.7（wan2.7-image）模型，**禁止使用 coze 内置 image_generate**。

#### 前置要求
用户需要配置 **DASHSCOPE_API_KEY**（阿里云灵积平台 API Key）：
- 申请地址：https://dashscope.console.aliyun.com/
- 配置方式：设置环境变量 `DASHSCOPE_API_KEY` 或写入 SECRET.md

#### 正确调用方式
```python
import requests
import os

api_key = os.getenv("DASHSCOPE_API_KEY")
api_url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation"

# 1. 调用 wan2.7-image API
payload = {
    "model": "wan2.7-image",
    "input": {
        "messages": [{
            "role": "user",
            "content": [
                {"image": "用户图片URL"},
                {"text": "编辑指令"}
            ]
        }]
    },
    "parameters": {"size": "1080*1440", "n": 1}
}

response = requests.post(api_url, headers={"Authorization": f"Bearer {api_key}"}, json=payload)
result = response.json()

# 2. 提取阿里云 OSS 临时链接
oss_url = result["output"]["choices"][0]["message"]["content"][0]["image"]

# 3. ⚠️ 必须下载图片保存到本地
img_response = requests.get(oss_url)
save_path = "./imgs/菜品名_风格.jpg"
with open(save_path, "wb") as f:
    f.write(img_response.content)

# 4. 用 computer:// 协议发送给用户
# 消息中写：[图片名称](computer://imgs/菜品名_风格.jpg)
```

#### ⚠️ 关键注意事项
- **阿里云 OSS 链接是临时的**，会过期，必须下载保存
- **禁止使用 image_generate 工具**，效果不符合要求
- **禁止直接发送 OSS 临时链接**，用户会看不到图片
- 用 `computer://` 协议发送本地文件给用户

#### 如果用户没有 DASHSCOPE_API_KEY
提示用户：
```
⚠️ 本技能需要配置阿里云 DASHSCOPE_API_KEY
申请地址：https://dashscope.console.aliyun.com/
配置后写入 SECRET.md 或设置环境变量
```

### 5. 光线必须适配新场景
换盘/换背景时，光线也要跟着变：
- 新场景 = 新光线
- 光线要让菜品更有食欲感
- 不能保留原来的烂光线

---

## 🎨 设计美学原则（融合 UI/UX 精髓）

### 视觉层级五要素

| 要素 | 在美食图中的应用 |
|------|------------------|
| **大小** | 菜品最大、餐具中等、背景最小 |
| **颜色** | 菜品高饱和、餐具中性色、背景低饱和 |
| **留白** | 菜品周围必须有呼吸空间（20-30%） |
| **对比** | 深色菜品配浅色餐具，浅色菜品配深色餐具 |
| **距离** | 相关元素靠近 |

### 色彩系统

| 菜品色调 | 推荐餐具色 | 效果 |
|----------|------------|------|
| 暖色（红烧、咖喱） | 冷色（青花、深灰） | 对比突出 |
| 冷色（清蒸、刺身） | 暖色（木纹、米白） | 温润和谐 |
| 深色（酱汁重） | 浅色（白瓷、浅灰） | 明暗反差 |
| 浅色（清淡菜） | 深色（黑陶、深木） | 层次分明 |

---

## 使用流程（分步引导）

### 第一步：上传菜品图
```
🍽️ 欢迎使用美食换盘技能！

请先上传您的菜品照片：
```

---

### 第二步：选择功能

```
我看到了您的菜品，请选择您需要的功能：

1️⃣ 换盘美化 - 换个更有质感的餐具和背景
2️⃣ 创意镜头 - 换个拍摄角度（俯拍/近景/特写）
3️⃣ 全套套餐 - 换盘+镜头一起来

请输入数字（1-3）：
```

---

### 第三步：选择风格

```
请选择您喜欢的餐具风格：

1️⃣ 中式青花 - 传统典雅，青花瓷盘
2️⃣ 日式简约 - 素雅禅意，素色陶瓷
3️⃣ 西式优雅 - 精致高级，白瓷金边
4️⃣ ins风 - 现代简约，莫兰迪色调
5️⃣ 复古文艺 - 做旧质感，大地色调
6️⃣ 自然质朴 - 原木竹编，田园风格
7️⃣ 韩式清新 - 浅色系，温柔治愈
8️⃣ 港式茶餐厅 - 怀旧复古，市井气息
9️⃣ 法式浪漫 - 精致摆盘，优雅烛光
🔟 新中式国潮 - 传统元素+现代设计
1️⃣1️⃣ 🎲 AI帮你选 - 根据菜品自动匹配最佳风格
1️⃣2️⃣ 📷 提供我自己的餐具图

请输入数字（1-12）：
```

---

### 第四步：选择镜头视角

```
请选择拍摄角度：

1️⃣ 俯拍全景 - 完整展示餐桌氛围
2️⃣ 近景夹取 - 筷子夹起食物，食欲感爆棚
3️⃣ 菜品特写 - 贴近拍摄，突出纹理细节

请输入数字（1-3）：
```

---

### 第五步：选择输出尺寸

```
请选择输出尺寸（适配不同社媒平台）：

1️⃣ 小红书封面 - 3:4 竖版 (1080×1440)
2️⃣ 朋友圈/微博 - 1:1 方形 (1080×1080)
3️⃣ 抖音封面 - 9:16 竖版 (1080×1920)
4️⃣ B站封面 - 16:9 横版 (1920×1080)
5️⃣ 公众号封面 - 2.35:1 宽幅 (900×383)
6️⃣ 自定义尺寸 - 自己输入宽×高

请输入数字（1-6）：
```

---

### 第六步：选择生成张数

```
🖼️ 请输入生成图片数量（1-12张，默认1张）：

请输入数字：
```

---

### 第七步：生成结果

```
🍳 正在生成您的美食大片...

[展示生成结果]

💡 您可以：
- 选择最满意的一张
- 告诉我需要调整的地方
- 重新生成其他风格
```

---

## 风格库详解

### 1️⃣ 中式青花
- **特点**：传统青花瓷盘，古典雅致
- **适用菜品**：红烧肉、清蒸鱼、中式炒菜
- **配色**：深蓝+白，与暖色菜品形成冷暖对比

### 2️⃣ 日式简约
- **特点**：素色陶瓷，留白意境，禅意美学
- **适用菜品**：寿司、刺身、清淡料理
- **配色**：米白+灰，突出食材本色

### 3️⃣ 西式优雅
- **特点**：白瓷金边，精致高级
- **适用菜品**：牛排、意面、甜点
- **配色**：纯白+金，高级感拉满

### 4️⃣ ins风
- **特点**：纯色简约，几何造型，网红滤镜
- **适用菜品**：轻食、沙拉、早午餐
- **配色**：莫兰迪色系，柔和高级

### 5️⃣ 复古文艺
- **特点**：做旧质感，复古花纹，怀旧氛围
- **适用菜品**：家常菜、烘焙
- **配色**：大地色系，温暖怀旧

### 6️⃣ 自然质朴
- **特点**：木质、石板、竹编，田园风格
- **适用菜品**：烧烤、农家菜
- **配色**：原木色+绿植点缀

### 7️⃣ 韩式清新
- **特点**：浅色系，温柔治愈，ins韩风
- **适用菜品**：韩式拌饭、炸鸡、汤品
- **配色**：奶白+浅粉/浅蓝，少女心

### 8️⃣ 港式茶餐厅
- **特点**：怀旧复古，市井气息，港风滤镜
- **适用菜品**：奶茶、菠萝包、茶餐厅菜品
- **配色**：复古绿+暖黄，港味十足

### 9️⃣ 法式浪漫
- **特点**：精致摆盘，优雅烛光，浪漫氛围
- **适用菜品**：法餐、红酒、精致甜点
- **配色**：深色背景+金色点缀，奢华感

### 🔟 新中式国潮
- **特点**：传统元素+现代设计，国风美学
- **适用菜品**：中式创意菜、茶点
- **配色**：朱红+墨绿+金，东方韵味

### 1️⃣1️⃣ 🎲 AI帮你选
根据菜品特征自动匹配最佳风格：

| 菜品类型 | AI 自动选择 |
|----------|-------------|
| 红烧/酱汁重 | 中式青花 + 俯拍全景 |
| 清蒸/清淡 | 日式简约 + 菜品特写 |
| 寿司/刺身 | 日式简约 + 近景夹取 |
| 牛排/西餐 | 西式优雅 + 菜品特写 |
| 沙拉/轻食 | ins风 + 俯拍全景 |
| 家常菜 | 复古文艺 + 俯拍全景 |
| 烧烤/烤肉 | 自然质朴 + 近景夹取 |
| 甜点/烘焙 | 法式浪漫 + 菜品特写 |
| 韩式料理 | 韩式清新 + 俯拍全景 |
| 港式茶点 | 港式茶餐厅 + 近景夹取 |
| 中式创意菜 | 新中式国潮 + 俯拍全景 |

---

## 输出尺寸对照表

| 平台 | 比例 | 尺寸 | 适用场景 |
|------|------|------|----------|
| 小红书封面 | 3:4 | 1080×1440 | 笔记封面 |
| 朋友圈/微博 | 1:1 | 1080×1080 | 九宫格 |
| 抖音封面 | 9:16 | 1080×1920 | 短视频封面 |
| B站封面 | 16:9 | 1920×1080 | 视频封面 |
| 公众号封面 | 2.35:1 | 900×383 | 文章封面 |

---

## 快捷指令

熟悉流程的用户可以一句话描述需求：

```
用户：帮我把红烧肉换成青花盘，俯拍，小红书尺寸
系统：收到！正在生成...

用户：AI帮我选，番茄炒蛋，朋友圈尺寸，生成2张
系统：好的！根据番茄炒蛋特征，我选择日式简约风格...
```

---

## 提示词生成规范

生成图像时，提示词必须包含：

```
1. 保留原菜品：the exact same dish from the reference image
2. 新餐具风格：[选定的风格描述]
3. 新背景：[对应的背景描述]
4. 光线要求：warm appetizing lighting, golden hour glow
5. 视角要求：[俯拍/近景/特写]
6. 留白要求：20-30% negative space
```

**示例：**
```
Take the exact tomato scrambled eggs from this reference image 
and place on a vintage ceramic plate with aged patina and warm 
earth tones. Rustic wooden farmhouse table background. Add warm 
golden-hour lighting that makes the food glisten and look delicious. 
Close-up angle showing texture detail. 25% negative space around dish.
```

---

## 技术架构

### 依赖
- 万相2.7 API（wan2.7-image 模型）
- 需配置环境变量 DASHSCOPE_API_KEY

### 文件结构
```
plate-swap/
├── SKILL.md              # 本文档
├── scripts/
│   ├── generate.py       # 图像生成模块
│   ├── styles.py         # 风格库定义
│   └── swap.py           # 主流程脚本
└── references/           # 参考素材
```

---

## 注意事项

### API Key 配置
```bash
export DASHSCOPE_API_KEY="your-api-key"
```

### 图片要求
- 菜品图需清晰，主体明确
- 建议尺寸：1024×1024 以上
- 支持格式：jpg、png、webp

### 最佳实践
1. 光线充足的照片效果更好
2. 背景简洁的菜品图更容易融合
3. 高清原图能保留更多细节
4. **留白是高级感的关键**

---

## 更新日志

### v3.0 (2026-04-12)
- 🗑️ 去掉文字功能（避免遮挡菜品）
- 🔢 生成张数用户自输入，默认1张
- 🎨 风格库扩展至12种（新增韩式、港式、法式、国潮）
- 📱 多平台尺寸适配（小红书/朋友圈/抖音/B站/公众号）
- 🎲 新增"AI帮你选"智能匹配风格
- 🚫 去掉小红书封面专项功能
