#!/usr/bin/env python3
"""
美食换盘与创意摄影主脚本
"""

import os
import sys
import argparse
from typing import Optional, Dict, List, Any

# 导入模块
from generate import WanxiangGenerator
from styles import (
    PLATE_STYLES, CAMERA_ANGLES, TEXT_MODES, 
    DEFAULT_COMBINATIONS, generate_scene_prompt, get_camera_instruction
)


class FoodPhotographySkill:
    """美食换盘与创意摄影技能"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        初始化技能
        
        Args:
            api_key: API密钥（可选，不传则从环境变量读取）
        """
        self.generator = WanxiangGenerator(api_key=api_key)
    
    def interactive_mode(self):
        """交互式模式"""
        print("=" * 50)
        print("🍽️  欢迎使用美食换盘与创意摄影技能")
        print("=" * 50)
        
        # 第一步：选择功能模式
        print("\n请选择您需要的功能：")
        print("1️⃣ 换盘美化 - 替换餐具/桌面/背景")
        print("2️⃣ 创意镜头 - 近景/特写拍摄")
        print("3️⃣ 小红书封面 - 带文字的封面图")
        print("4️⃣ 全套套餐 - 换盘+镜头+封面一起")
        
        mode = input("\n请输入数字选择（1-4）：").strip()
        
        # 第二步：上传菜品图
        print("\n📷 请上传您的菜品照片（输入图片URL）：")
        food_image_url = input().strip()
        
        if not food_image_url:
            print("❌ 未提供菜品图片URL")
            return
        
        # 第三步：选择风格
        print("\n🍽️  请选择餐具风格：")
        plate_list = list(PLATE_STYLES.items())
        for i, (name, style) in enumerate(plate_list, 1):
            print(f"  {i}. {name}: {style['description']}")
        print(f"  {len(plate_list) + 1}. 提供我自己的餐具图")
        
        plate_choice = input("\n请输入数字选择：").strip()
        
        # 第四步：选择镜头视角
        print("\n📐 请选择镜头视角：")
        angle_list = list(CAMERA_ANGLES.items())
        for i, (name, angle) in enumerate(angle_list, 1):
            print(f"  {i}. {name}: {angle['description']}")
        
        angle_choice = input("\n请输入数字选择：").strip()
        
        # 第五步：选择文字模式
        print("\n📝 请选择文字显示模式：")
        for key, mode in TEXT_MODES.items():
            print(f"  {key}. {mode['name']}: {mode['description']}")
        
        text_choice = input("\n请输入字母选择：").strip().upper()
        
        # 收集文字信息（如果需要）
        text_info = {}
        if text_choice in ["A", "C"]:
            print("\n请输入菜品信息：")
            text_info["name_cn"] = input("  菜名（中文）：").strip()
            text_info["name_en"] = input("  菜名（英文，可选）：").strip()
            
            if text_choice == "C":
                text_info["ingredients"] = input("  主要食材：").strip()
                text_info["calories"] = input("  卡路里（千卡）：").strip()
        
        # 第六步：选择生成张数
        print("\n🖼️  请选择生成图片数量：")
        print("  1. 生成 1 张")
        print("  2. 生成 2 张")
        print("  3. 生成 3 张")
        print("  4. 生成 4 张（推荐）")
        
        n_choice = input("\n请输入数字选择（1-4）：").strip()
        
        try:
            n = int(n_choice)
            n = max(1, min(4, n))  # 限制在1-4范围内
        except:
            n = 4  # 默认4张
        
        print(f"\n✅ 将生成 {n} 张不同风格的图片")
        
        # 执行生成
        self._generate_images(
            food_image_url=food_image_url,
            plate_choice=plate_choice,
            angle_choice=angle_choice,
            text_choice=text_choice,
            text_info=text_info,
            n=n
        )
    
    def _generate_images(
        self,
        food_image_url: str,
        plate_choice: str,
        angle_choice: str,
        text_choice: str,
        text_info: Dict,
        n: int = 4
    ):
        """执行图像生成"""
        print("\n🍳 正在生成您的美食大片...")
        
        # 获取风格
        plate_list = list(PLATE_STYLES.keys())
        angle_list = list(CAMERA_ANGLES.keys())
        
        # 解析选择
        try:
            plate_idx = int(plate_choice) - 1
            plate_style = plate_list[plate_idx] if 0 <= plate_idx < len(plate_list) else "中式青花"
        except:
            plate_style = "中式青花"
        
        try:
            angle_idx = int(angle_choice) - 1
            camera_angle = angle_list[angle_idx] if 0 <= angle_idx < len(angle_list) else "俯拍全景"
        except:
            camera_angle = "俯拍全景"
        
        # 使用默认组合生成4张不同风格
        results = []
        for combo in DEFAULT_COMBINATIONS[:n]:
            print(f"\n🎨 生成风格: {combo['name']}...")
            
            # 生成场景提示词
            scene_prompt = generate_scene_prompt(
                combo["plate"],
                combo["table"],
                combo["background"]
            )
            
            # 获取镜头指令
            camera_instruction = get_camera_instruction(camera_angle)
            
            # 构建完整指令
            edit_instruction = f"把图片中的菜品放在{scene_prompt}，{camera_instruction}，美食摄影风格，自然光线，高质量"
            
            # 调用API
            result = self.generator.image_edit(
                image_url=food_image_url,
                edit_instruction=edit_instruction,
                n=1
            )
            
            # 提取图片URL
            urls = WanxiangGenerator.extract_image_urls(result)
            
            results.append({
                "style_name": combo["name"],
                "plate": combo["plate"],
                "table": combo["table"],
                "background": combo["background"],
                "urls": urls,
                "text_mode": text_choice,
                "text_info": text_info
            })
        
        # 输出结果
        self._display_results(results)
    
    def _display_results(self, results: List[Dict]):
        """显示结果"""
        print("\n" + "=" * 50)
        print("✅ 生成完成！")
        print("=" * 50)
        
        for i, result in enumerate(results, 1):
            print(f"\n{i}️⃣ {result['style_name']}")
            print(f"   餐具: {result['plate']} | 桌面: {result['table']}")
            print(f"   图片: {result['urls'][0] if result['urls'] else '生成失败'}")
            
            # 文字信息
            if result['text_mode'] != "B" and result['text_info']:
                info = result['text_info']
                print(f"   文字: {info.get('name_cn', '')}")
                if result['text_mode'] == "C":
                    print(f"   食材: {info.get('ingredients', '')}")
                    print(f"   卡路里: {info.get('calories', '')}千卡")
    
    def quick_swap(
        self,
        food_image_url: str,
        style: str = "中式经典",
        camera_angle: str = "俯拍全景",
        n: int = 4
    ) -> List[str]:
        """
        快速换盘
        
        Args:
            food_image_url: 菜品图URL
            style: 风格名称
            camera_angle: 镜头视角
            n: 生成数量
        
        Returns:
            图片URL列表
        """
        combo = None
        for c in DEFAULT_COMBINATIONS:
            if c["name"] == style:
                combo = c
                break
        
        if not combo:
            combo = DEFAULT_COMBINATIONS[0]
        
        scene_prompt = generate_scene_prompt(
            combo["plate"],
            combo["table"],
            combo["background"]
        )
        
        camera_instruction = get_camera_instruction(camera_angle)
        
        edit_instruction = f"把图片中的菜品放在{scene_prompt}，{camera_instruction}，美食摄影风格，自然光线，高质量"
        
        result = self.generator.image_edit(
            image_url=food_image_url,
            edit_instruction=edit_instruction,
            n=n
        )
        
        return WanxiangGenerator.extract_image_urls(result)


def main():
    parser = argparse.ArgumentParser(
        description='美食换盘与创意摄影工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  # 交互式模式
  python swap.py
  
  # 快速换盘
  python swap.py --food "菜品图URL" --style "中式经典"
  
  # 指定镜头
  python swap.py --food "菜品图URL" --angle "近景夹取"
  
  # 列出所有风格
  python swap.py --list-styles
        """
    )
    
    parser.add_argument('--food', '-f', help='菜品图URL')
    parser.add_argument('--style', '-s', help='风格名称')
    parser.add_argument('--angle', '-a', help='镜头视角')
    parser.add_argument('--n', '-n', type=int, default=4, help='生成数量')
    parser.add_argument('--api-key', '-k', help='API Key（可选，优先从环境变量读取）')
    parser.add_argument('--list-styles', action='store_true', help='列出所有风格选项')
    parser.add_argument('--interactive', '-i', action='store_true', help='交互式模式')
    
    args = parser.parse_args()
    
    # 列出风格
    if args.list_styles:
        from styles import list_all_styles
        list_all_styles()
        return
    
    # 创建技能实例
    skill = FoodPhotographySkill(api_key=args.api_key)
    
    # 交互式模式
    if args.interactive or not args.food:
        skill.interactive_mode()
        return
    
    # 快速模式
    try:
        style = args.style or "中式经典"
        angle = args.angle or "俯拍全景"
        
        print(f"🍳 快速换盘中...")
        print(f"   风格: {style}")
        print(f"   镜头: {angle}")
        
        urls = skill.quick_swap(
            food_image_url=args.food,
            style=style,
            camera_angle=angle,
            n=args.n
        )
        
        print("\n✅ 生成完成！")
        for i, url in enumerate(urls, 1):
            print(f"  {i}. {url}")
        
    except Exception as e:
        print(f"❌ 生成失败: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
