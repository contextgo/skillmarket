#!/usr/bin/env python3
"""
万相2.7图像生成模块
整合文生图和图像编辑能力
"""

import os
import requests
from typing import Optional, List, Dict, Any


class WanxiangGenerator:
    """万相2.7图像生成器"""
    
    def __init__(self, api_key: Optional[str] = None):
        """
        初始化生成器
        
        Args:
            api_key: API密钥，如果不传则从环境变量读取
        """
        self.api_key = api_key or os.getenv("DASHSCOPE_API_KEY")
        if not self.api_key:
            raise ValueError("未找到 DASHSCOPE_API_KEY，请设置环境变量或在初始化时传入")
        
        self.api_url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/multimodal-generation/generation"
        self.model = "wan2.7-image"
    
    def text_to_image(
        self,
        prompt: str,
        width: int = 1024,
        height: int = 1024,
        n: int = 1,
        enable_sequential: bool = False
    ) -> Dict[str, Any]:
        """
        文生图
        
        Args:
            prompt: 图像描述
            width: 图像宽度
            height: 图像高度
            n: 生成数量（1-4）
            enable_sequential: 是否启用连续生成（多图风格一致）
        
        Returns:
            API响应
        """
        # 验证尺寸
        self._validate_size(width, height)
        
        size_str = f"{width}*{height}"
        
        response = requests.post(
            self.api_url,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}'
            },
            json={
                "model": self.model,
                "input": {
                    "messages": [{
                        "role": "user",
                        "content": [{"text": prompt}]
                    }]
                },
                "parameters": {
                    "size": size_str,
                    "n": n,
                    "watermark": False
                }
            },
            timeout=120
        )
        
        return response.json()
    
    def image_edit(
        self,
        image_url: str,
        edit_instruction: str,
        additional_images: Optional[List[str]] = None,
        bbox_list: Optional[List[List]] = None,
        width: int = 1024,
        height: int = 1024,
        n: int = 1
    ) -> Dict[str, Any]:
        """
        图像编辑
        
        Args:
            image_url: 原图URL
            edit_instruction: 编辑指令
            additional_images: 额外图片URL列表（用于融合）
            bbox_list: bbox坐标列表
            width: 输出宽度
            height: 输出高度
            n: 生成数量
        
        Returns:
            API响应
        """
        self._validate_size(width, height)
        
        # 构建content
        content = [{"image": image_url}]
        
        if additional_images:
            for img_url in additional_images:
                content.append({"image": img_url})
        
        content.append({"text": edit_instruction})
        
        # 构建参数
        parameters = {
            "size": f"{width}*{height}",
            "n": n,
            "watermark": False
        }
        
        if bbox_list:
            parameters["bbox_list"] = bbox_list
        
        response = requests.post(
            self.api_url,
            headers={
                'Content-Type': 'application/json',
                'Authorization': f'Bearer {self.api_key}'
            },
            json={
                "model": self.model,
                "input": {
                    "messages": [{
                        "role": "user",
                        "content": content
                    }]
                },
                "parameters": parameters
            },
            timeout=120
        )
        
        return response.json()
    
    def food_plate_swap(
        self,
        food_image_url: str,
        style_prompt: str,
        camera_angle: str = "俯拍全景",
        n: int = 1
    ) -> Dict[str, Any]:
        """
        美食换盘专用接口
        
        Args:
            food_image_url: 菜品图URL
            style_prompt: 风格描述
            camera_angle: 镜头角度（俯拍全景/近景夹取/菜品特写）
            n: 生成数量
        
        Returns:
            API响应
        """
        # 根据镜头角度调整指令
        angle_instructions = {
            "俯拍全景": "保持完整餐具和桌面展示",
            "近景夹取": "筷子夹起食物的近景特写，动态感强",
            "菜品特写": "贴近菜品本身的微距特写，突出质感和细节"
        }
        
        angle_instruction = angle_instructions.get(camera_angle, angle_instructions["俯拍全景"])
        
        edit_instruction = f"把图片中的菜品放在{style_prompt}，{angle_instruction}，美食摄影风格，自然光线，高质量"
        
        return self.image_edit(
            image_url=food_image_url,
            edit_instruction=edit_instruction,
            n=n
        )
    
    def _validate_size(self, width: int, height: int):
        """验证尺寸是否符合要求"""
        min_pixels = 768 * 768
        max_pixels = 2048 * 2048
        min_ratio = 1 / 8
        max_ratio = 8 / 1
        
        total_pixels = width * height
        ratio = width / height
        
        if total_pixels < min_pixels or total_pixels > max_pixels:
            raise ValueError(f"总像素 {total_pixels} 超出范围 [{min_pixels}, {max_pixels}]")
        
        if ratio < min_ratio or ratio > max_ratio:
            raise ValueError(f"宽高比 {ratio:.2f} 超出范围 [{min_ratio:.2f}, {max_ratio:.2f}]")
    
    @staticmethod
    def extract_image_urls(response: Dict[str, Any]) -> List[str]:
        """
        从API响应中提取图片URL
        
        Args:
            response: API响应
        
        Returns:
            图片URL列表
        """
        urls = []
        try:
            choices = response.get("output", {}).get("choices", [])
            for choice in choices:
                content = choice.get("message", {}).get("content", [])
                for item in content:
                    if item.get("type") == "image":
                        urls.append(item.get("image"))
        except Exception:
            pass
        return urls
