"""
换盘技能风格库定义
包含餐具风格、桌面风格、背景风格、镜头视角、文字模式
"""

# 餐具风格库
PLATE_STYLES = {
    "中式青花": {
        "description": "传统青花瓷盘，古典雅致",
        "suitable_for": ["红烧肉", "清蒸鱼", "炒菜", "中式菜肴"],
        "prompt": "精美的青花瓷盘，中国传统蓝白花纹，古典优雅，瓷器质感，摆在桌面上"
    },
    "日式简约": {
        "description": "素色陶瓷，留白意境",
        "suitable_for": ["寿司", "刺身", "日式料理", "清淡菜肴"],
        "prompt": "日式陶瓷盘，素色简约，留白意境，禅意美学，简洁线条"
    },
    "西式优雅": {
        "description": "白瓷金边，精致高级",
        "suitable_for": ["牛排", "意面", "甜点", "西餐"],
        "prompt": "精致的白色瓷盘，金边装饰，西式优雅，高级感，摆盘艺术"
    },
    "ins风": {
        "description": "纯色简约，几何造型",
        "suitable_for": ["轻食", "沙拉", "早午餐", "咖啡"],
        "prompt": "ins风简约餐盘，纯色几何造型，现代简约设计，时尚感"
    },
    "复古文艺": {
        "description": "做旧质感，复古花纹",
        "suitable_for": ["家常菜", "烘焙", "甜点"],
        "prompt": "复古陶瓷盘，做旧质感，复古花纹，文艺气息，怀旧风格"
    },
    "自然质朴": {
        "description": "木质、石板、竹编",
        "suitable_for": ["烧烤", "农家菜", "rustic料理"],
        "prompt": "木质餐板或石板，自然纹理，质朴质感，原木风格"
    }
}

# 桌面风格库
TABLE_STYLES = {
    "原木桌面": {
        "description": "自然温馨",
        "prompt": "浅色原木桌面，自然纹理，温暖色调"
    },
    "深木桌面": {
        "description": "沉稳大气",
        "prompt": "深色木质桌面，质感厚重，沉稳大气"
    },
    "大理石台面": {
        "description": "高级精致",
        "prompt": "白色大理石台面，灰色纹理，高级精致"
    },
    "纯色桌布": {
        "description": "简洁干净",
        "prompt": "白色/米色/灰色桌布，平整无褶皱，简洁干净"
    },
    "格子桌布": {
        "description": "文艺复古",
        "prompt": "红白格子桌布，温馨田园风，文艺气息"
    },
    "藤编餐垫": {
        "description": "自然质朴",
        "prompt": "藤编餐垫，自然纹理，质朴风格"
    }
}

# 背景风格库
BACKGROUND_STYLES = {
    "纯色背景": {
        "description": "简洁聚焦",
        "prompt": "纯白背景，干净简洁"
    },
    "窗边自然光": {
        "description": "温暖明亮",
        "prompt": "窗边自然光，阳光洒落，温暖明亮"
    },
    "绿植点缀": {
        "description": "清新自然",
        "prompt": "背景有绿植点缀，清新自然，生机盎然"
    },
    "文艺咖啡馆": {
        "description": "氛围感强",
        "prompt": "文艺咖啡馆背景，温馨氛围，生活气息"
    },
    "温馨家居": {
        "description": "生活气息",
        "prompt": "温馨家居环境，生活化场景，温暖舒适"
    }
}

# 镜头视角库
CAMERA_ANGLES = {
    "俯拍全景": {
        "description": "完整展示餐具+桌面+背景",
        "instruction": "45度俯拍视角，完整展示餐具和桌面布局，氛围感强",
        "suitable_for": ["展示整体", "氛围图", "场景图"]
    },
    "近景夹取": {
        "description": "筷子夹起食物的特写",
        "instruction": "筷子夹起食物的近景特写镜头，动态感强，食欲感爆棚，背景虚化",
        "suitable_for": ["动态展示", "食欲感", "短视频封面"]
    },
    "菜品特写": {
        "description": "贴近菜品本身，突出质感",
        "instruction": "贴近菜品本身的微距特写，突出质感和细节，纹理清晰，质感细腻",
        "suitable_for": ["细节展示", "质感图", "特写图"]
    }
}

# 文字模式库
TEXT_MODES = {
    "A": {
        "name": "只显示菜名",
        "description": "中英文大字标题，小红书风格",
        "example": """
        ┌─────────────────┐
        │                 │
        │   番茄炒蛋      │
        │                 │
        │  TOMATO EGG     │
        │                 │
        │    [菜品图]     │
        │                 │
        └─────────────────┘
        """,
        "fields": ["菜名（中文）", "菜名（英文，可选）"]
    },
    "B": {
        "name": "不显示文字",
        "description": "纯图片展示",
        "example": """
        ┌─────────────────┐
        │                 │
        │                 │
        │    [菜品图]     │
        │                 │
        │                 │
        └─────────────────┘
        """,
        "fields": []
    },
    "C": {
        "name": "完整信息",
        "description": "菜名 + 食材 + 卡路里",
        "example": """
        ┌─────────────────┐
        │   番茄炒蛋      │
        │  TOMATO EGG     │
        │                 │
        │    [菜品图]     │
        │                 │
        │ 🥚 食材：鸡蛋   │
        │ 🍅 番茄        │
        │ 🔥 卡路里：180  │
        └─────────────────┘
        """,
        "fields": ["菜名（中文）", "菜名（英文，可选）", "主要食材", "卡路里（千卡）"]
    }
}

# 默认推荐组合
DEFAULT_COMBINATIONS = [
    {
        "name": "中式经典",
        "plate": "中式青花",
        "table": "原木桌面",
        "background": "纯色背景"
    },
    {
        "name": "日式禅意",
        "plate": "日式简约",
        "table": "深木桌面",
        "background": "窗边自然光"
    },
    {
        "name": "西式优雅",
        "plate": "西式优雅",
        "table": "大理石台面",
        "background": "纯色背景"
    },
    {
        "name": "ins时尚",
        "plate": "ins风",
        "table": "大理石台面",
        "background": "窗边自然光"
    },
    {
        "name": "复古文艺",
        "plate": "复古文艺",
        "table": "格子桌布",
        "background": "温馨家居"
    },
    {
        "name": "自然质朴",
        "plate": "自然质朴",
        "table": "藤编餐垫",
        "background": "绿植点缀"
    }
]

# 小红书风格字体和配色
XIAOHONGSHU_STYLES = {
    "超大字标题": {
        "description": "字体占画面30-40%，醒目",
        "font_size_ratio": 0.35,
        "style": "bold"
    },
    "手写体": {
        "description": "文艺清新，手写风格",
        "font_size_ratio": 0.25,
        "style": "handwritten"
    },
    "撞色设计": {
        "description": "高饱和度色彩搭配",
        "colors": ["#FF6B6B", "#4ECDC4", "#FFE66D", "#95E1D3"],
        "style": "vibrant"
    },
    "文艺细字": {
        "description": "清新淡雅，细线条字体",
        "font_size_ratio": 0.20,
        "style": "light"
    }
}


def get_style_combination(style_name: str) -> dict:
    """获取风格组合"""
    for combo in DEFAULT_COMBINATIONS:
        if combo["name"] == style_name:
            return combo
    return None


def generate_scene_prompt(plate_style: str, table_style: str, background_style: str) -> str:
    """
    生成场景提示词
    
    Args:
        plate_style: 餐具风格名称
        table_style: 桌面风格名称
        background_style: 背景风格名称
    
    Returns:
        完整的场景提示词
    """
    plate = PLATE_STYLES.get(plate_style, {})
    table = TABLE_STYLES.get(table_style, {})
    background = BACKGROUND_STYLES.get(background_style, {})
    
    prompt = f"{plate.get('prompt', '')}，{table.get('prompt', '')}，{background.get('prompt', '')}，美食摄影风格，自然光线，高质量"
    return prompt


def get_camera_instruction(camera_angle: str) -> str:
    """获取镜头视角指令"""
    return CAMERA_ANGLES.get(camera_angle, {}).get("instruction", "")


def list_all_styles():
    """列出所有风格选项"""
    print("🍽️  餐具风格:")
    for i, (name, style) in enumerate(PLATE_STYLES.items(), 1):
        print(f"  {i}. {name}: {style['description']}")
    
    print("\n📐 镜头视角:")
    for i, (name, angle) in enumerate(CAMERA_ANGLES.items(), 1):
        print(f"  {i}. {name}: {angle['description']}")
    
    print("\n📝 文字模式:")
    for key, mode in TEXT_MODES.items():
        print(f"  {key}. {mode['name']}: {mode['description']}")


if __name__ == "__main__":
    list_all_styles()
