# 美食换盘与创意摄影技能

🍽️ 一站式美食图片解决方案：换盘、创意镜头、小红书封面

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置API Key

⚠️ **重要**：本技能不包含API Key，使用前必须配置

**方式一：环境变量（推荐）**
```bash
export DASHSCOPE_API_KEY="your-api-key-here"
```

**方式二：初始化时传入**
```python
from scripts.swap import FoodPhotographySkill

skill = FoodPhotographySkill(api_key="your-api-key-here")
```

### 3. 使用方式

**交互式模式**
```bash
python scripts/swap.py
```

**快速换盘**
```bash
python scripts/swap.py --food "菜品图URL" --style "中式经典"
```

**指定镜头**
```bash
python scripts/swap.py --food "菜品图URL" --angle "近景夹取"
```

**查看所有风格**
```bash
python scripts/swap.py --list-styles
```

## 功能特点

### 🍽️ 智能换盘
- 6种餐具风格：中式青花、日式简约、西式优雅、ins风、复古文艺、自然质朴
- 自动生成餐具+桌面+背景
- 支持用户提供自己的餐具图

### 📷 创意镜头
- **俯拍全景**：完整展示餐具和桌面
- **近景夹取**：筷子夹起食物的特写
- **菜品特写**：贴近菜品本身的微距

### ✨ 小红书风格
- 超大字标题封面
- 中英文双语
- 撞色设计

### 📝 文字模式
- **模式A**：只显示菜名（中英文大字）
- **模式B**：不显示文字
- **模式C**：菜名 + 食材 + 卡路里

## API说明

### 获取万相2.7 API Key

1. 访问 [阿里云万相](https://dashscope.aliyun.com/)
2. 注册并开通服务
3. 在控制台获取API Key

### API费用

使用万相2.7 API会产生费用，具体请参考阿里云官方定价

## 文件说明

```
plate-swap/
├── SKILL.md              # 完整功能文档
├── README.md             # 本文件
├── requirements.txt      # Python依赖
└── scripts/
    ├── swap.py           # 主流程脚本
    ├── generate.py       # 图像生成模块
    └── styles.py         # 风格库定义
```

## 常见问题

**Q: 为什么需要API Key？**
A: 本技能使用阿里云万相2.7 API进行图像生成和编辑

**Q: API Key安全吗？**
A: 本技能不会保存或传输您的API Key，仅用于调用阿里云API

**Q: 生成图片需要多久？**
A: 单张图片约10-30秒，4张约40-120秒

**Q: 支持哪些图片格式？**
A: 支持 jpg、png、webp 格式

## 技术支持

如有问题，请查看 SKILL.md 获取完整文档

## 许可证

MIT License
