---
name: vision-locator
version: 1.0.0
author: 玲瑶
description: |
  视觉金字塔定位器：模拟人类看屏幕的方式，分层放大精准定位 UI 元素。
  
  触发词：截图定位、屏幕查找、找按钮、找图标、找元素、定位UI、
  屏幕自动化、找到按钮位置、屏幕点击、视觉定位、图像查找、
  find button、screen locate、UI automation、元素定位、
  坐标查找、在屏幕上找、屏幕识别、OCR定位、视觉识别、
  精准点击、自动点击位置
  
  使用场景：
  - RPA 自动化：精准定位按钮/输入框进行自动化操作
  - 游戏自动化：定位游戏界面元素
  - 测试自动化：UI 自动化测试中定位元素
  - 辅助功能：帮助用户找到屏幕上的特定元素
---

# VisionLocator 视觉金字塔定位器

## 能做什么

VisionLocator 模拟人类视觉的「先全局扫视 → 再细节聚焦」方式，在屏幕上精准定位任何 UI 元素。

### 核心特性

- **多层级递归放大** — 从全屏到像素级，精度达 0.125px
- **候选区域智能筛选** — 支持精确/模糊/语义/位置加权 4 种匹配模式
- **LLaVA 语义验证** — 用视觉语言模型二次确认找到的元素
- **坐标变换器** — 自动补偿放大比例，确保返回真实屏幕坐标

## 工作原理

```
全屏截图 (1920x1080)
    ↓ OCR + 快速扫描
候选区域列表 [区域A, 区域B, 区域C]
    ↓ 按匹配分数排序
放大最佳候选区 (2x)
    ↓ 精细 OCR
更精准候选列表
    ↓ 递归 (最多 9 层)
找到目标元素 → 返回真实坐标
```

## 快速使用

```python
from vision_locator import VisionLocator

locator = VisionLocator()

# 在屏幕上查找"确认"按钮
result = locator.find("确认")
if result:
    x, y = result.x, result.y
    print(f"找到！坐标: ({x}, {y})")
    # 配合 pyautogui 点击
    import pyautogui
    pyautogui.click(x, y)

# 模糊匹配
result = locator.find("确认", match_mode="fuzzy")

# 带截图路径
result = locator.find_in_image("确认", image_path="screenshot.png")

# 查找所有匹配
results = locator.find_all("按钮")
```

## 精度层级

| 层级 | 精度 | 适用场景 |
|------|------|---------|
| L0 全屏 | 1px | 快速扫描，确定大致区域 |
| L1 区域 | 0.5px | 缩小范围 |
| L2 精细 | 0.25px | 精准识别 |
| L3 微观 | 0.125px | 极小元素、密集界面 |

## 匹配模式

| 模式 | 说明 |
|------|------|
| exact | 精确匹配，区分大小写 |
| fuzzy | 模糊匹配，允许部分字符偏差 |
| semantic | 语义匹配，"提交" ≈ "确认" ≈ "OK" |
| position | 位置加权，优先屏幕特定区域 |

## 依赖

- Python 3.8+
- `Pillow` — 截图处理
- `rapidocr-onnxruntime` 或 `easyocr` — OCR 识别
- `pyautogui` — 屏幕截图（可替换）
- Ollama + LLaVA（可选，用于语义验证）
