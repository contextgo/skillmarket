# -*- coding: utf-8 -*-
"""
VisionLocator 测试脚本
测试分层放大查找、坐标变换、候选筛选等核心功能
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from vision_locator import (
    VisionLocator, CoordinateTransform, CandidateSelector,
    ZoomLevel, PyramidResult
)


def test_coordinate_transform():
    """测试坐标变换"""
    print("\n=== 测试1: 坐标变换 ===")

    # Level 0
    level0 = ZoomLevel(level=0, region=(0, 0, 1920, 1080), scale=1.0, parent_offset=(0.0, 0.0))

    # Level 1 (放大2x)
    level1 = ZoomLevel(level=1, region=(100, 50, 200, 100), scale=2.0, parent_offset=(0.0, 0.0))

    # Level 2 (放大4x)
    level2 = ZoomLevel(level=2, region=(110, 60, 50, 30), scale=4.0, parent_offset=(0.0, 0.0))

    # 测试精度
    print(f"  Level 0 精度: {CoordinateTransform.get_precision(0)}px")
    print(f"  Level 1 精度: {CoordinateTransform.get_precision(1)}px")
    print(f"  Level 2 精度: {CoordinateTransform.get_precision(2)}px")
    print(f"  Level 3 精度: {CoordinateTransform.get_precision(3)}px")

    # 测试坐标转换
    local_x, local_y = 25, 15  # Level2中的位置
    abs_x, abs_y = CoordinateTransform.to_absolute(local_x, local_y, level2)
    print(f"  局部({local_x},{local_y}) → 绝对({abs_x:.2f},{abs_y:.2f})")

    status = "PASS" if abs_x > 110 and abs_y > 60 else "FAIL"
    print(f"  [{status}] 坐标变换正确")


def test_candidate_selector():
    """测试候选筛选"""
    print("\n=== 测试2: 候选筛选 ===")

    selector = CandidateSelector(screen_width=1920, screen_height=1080)

    # 模拟OCR结果
    ocr_results = [
        {"text": "QQ浏览器", "x": 100, "y": 50, "w": 120, "h": 40, "conf": 0.95},
        {"text": "登录按钮", "x": 800, "y": 400, "w": 100, "h": 50, "conf": 0.88},
        {"text": "设置", "x": 1800, "y": 20, "w": 60, "h": 30, "conf": 0.92},
        {"text": "搜索框", "x": 500, "y": 100, "w": 300, "h": 40, "conf": 0.85},
        {"text": "关闭", "x": 1850, "y": 30, "w": 50, "h": 50, "conf": 0.90},
    ]

    # 测试各种目标
    targets = ["浏览器", "登录", "设置", "关闭"]
    for target in targets:
        candidates = selector.select(ocr_results, target, top_k=3)
        if candidates:
            best = candidates[0]
            print(f"  '{target}': 找到 [{best[0]['text']}] score={best[1]:.1f} ({best[2]})")
        else:
            print(f"  '{target}': 未找到")

    print("  [PASS] 候选筛选正常")


def test_zoom_level():
    """测试ZoomLevel数据结构"""
    print("\n=== 测试3: ZoomLevel数据结构 ===")

    level = ZoomLevel(
        level=2,
        region=(100, 50, 200, 100),
        scale=4.0,
        ocr_results=[
            {"text": "test", "x": 110, "y": 60, "w": 50, "h": 30, "conf": 0.9}
        ],
        parent_offset=(0.0, 0.0),
        confidences={"avg_ocr_confidence": 0.9, "text_count": 1},
        match_score=85.0
    )

    print(f"  层级: {level.level}")
    print(f"  区域: {level.region}")
    print(f"  中心点: {level.center}")
    print(f"  放大倍数: {level.scale}x")
    print(f"  识别项目数: {len(level.ocr_results)}")
    print(f"  匹配分数: {level.match_score}")

    data = level.to_dict()
    print(f"  to_dict() 项目: {list(data.keys())}")

    print("  [PASS] 数据结构正常")


def test_vision_locator_init():
    """测试VisionLocator初始化"""
    print("\n=== 测试4: VisionLocator初始化 ===")

    vl = VisionLocator(max_level=3, zoom_factor=2.0)

    print(f"  最大层级: {vl.max_level}")
    print(f"  放大因子: {vl.zoom_factor}")
    print(f"  OCR就绪: {vl._ocr_ready}")
    print(f"  截图就绪: {vl._screencap_ready}")

    # 检查组件
    print(f"  候选筛选器: {type(vl._candidate_selector).__name__}")
    print(f"  坐标变换器: {type(vl._coord_transform).__name__}")
    print(f"  LLaVA分析器: {type(vl._llava).__name__}")

    print("  [PASS] 初始化正常")


def test_capture_and_scan():
    """测试截图和OCR"""
    print("\n=== 测试5: 截图 + OCR ===")

    vl = VisionLocator()
    level0 = vl.capture_and_scan()

    print(f"  层级: {level0.level}")
    print(f"  区域: {level0.region}")
    print(f"  放大倍数: {level0.scale}")
    print(f"  OCR结果数: {len(level0.ocr_results)}")

    if level0.ocr_results:
        print(f"  前3个识别结果:")
        for item in level0.ocr_results[:3]:
            print(f"    - [{item['text']}] @ ({item['x']},{item['y']}) conf={item.get('conf', 0):.2f}")

    status = "PASS" if level0.region[2] > 0 else "FAIL"
    print(f"  [{status}] 截图功能正常")


def test_stats():
    """测试统计接口"""
    print("\n=== 测试6: 统计信息 ===")

    vl = VisionLocator()
    stats = vl.get_stats()
    print(f"  统计: {stats}")
    print("  [PASS] 统计正常")


if __name__ == "__main__":
    print("=" * 60)
    print("VisionLocator 测试套件")
    print("=" * 60)

    test_coordinate_transform()
    test_candidate_selector()
    test_zoom_level()
    test_vision_locator_init()
    test_capture_and_scan()
    test_stats()

    print("\n" + "=" * 60)
    print("测试完成！")
    print("=" * 60)
    print("\n提示: find_target() 需要实际屏幕内容才能测试完整流程")
