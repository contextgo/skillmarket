# VisionLocator 视觉金字塔查找器

> 让AI像人一样看屏幕——从全屏扫视到细节聚焦

## 核心理念

人怎么看屏幕，AI就应该怎么看。

1. **扫视全屏** — 快速发现可疑区域
2. **聚焦放大** — 细节信息逐渐清晰
3. **精确定位** — 坐标精度达0.125px

## 核心功能

### 1. 分层放大架构
- Level 0: 全屏截图 + OCR粗扫（精度 1px）
- Level 1: 裁剪放大2x + 精细OCR（精度 0.5px）
- Level 2: 再次放大2x + LLaVA理解（精度 0.25px）
- Level 3: 可选深层分析（精度 0.125px）

### 2. 智能候选筛选
- **精确匹配**：关键词完全包含
- **模糊匹配**：编辑距离 <= 2
- **语义关联**：同义词词典扩展
- **位置加权**：屏幕中央区域优先

### 3. 坐标变换引擎
- 各层级之间坐标无损转换
- 支持局部坐标 ↔ 绝对坐标互转
- 精度计算：Level N → 精度 = 1/(2^N) px

### 4. LLaVA 深度理解（可选）
- 对放大后的图像进行语义分析
- 验证候选区域是否真正匹配
- 输出元素类型和详细描述

### 5. OCR 引擎兼容
- RapidOCR（推荐，速度快）
- EasyOCR（精度高）
- 自定义引擎（只需实现 `recognize(image)` 方法）

## 安装

```bash
pip install pillow mss numpy
pip install rapidocr-onnxruntime  # 推荐
# 或
pip install easyocr  # 备选

# 可选：LLaVA 支持
pip install requests
```

## 快速使用

```python
from vision_locator import VisionLocator

# 初始化
vl = VisionLocator()

# 查找目标
result = vl.find_target("QQ浏览器图标")

if result.found:
    print(f"找到！坐标: ({result.abs_coords[0]:.1f}, {result.abs_coords[1]:.1f})")
    print(f"置信度: {result.confidence:.2f}")
    print(f"使用层级: {result.zoom_levels_used}")
    print(f"总耗时: {result.total_time_ms}ms")
else:
    print(f"未找到: {result.error}")

# 查看详细层级信息
for level in result.all_levels:
    print(f"Level {level.level}: 识别 {len(level.ocr_results)} 项")
```

## 进阶配置

```python
vl = VisionLocator(
    ocr_engine=None,           # 自动检测
    llava_client=None,         # LLaVA分析器
    max_level=3,              # 最大放大层级
    zoom_factor=2.0,           # 放大倍数
    screen_width=1920,         # 屏幕宽度
    screen_height=1080         # 屏幕高度
)
```

## 查找结果

```python
@dataclass
class PyramidResult:
    found: bool              # 是否找到
    target: Dict             # 目标信息
    abs_coords: Tuple        # 屏幕绝对坐标 (x, y)
    region: Tuple            # 目标区域 (x, y, w, h)
    confidence: float        # 置信度
    zoom_levels_used: int    # 使用的层级数
    total_time_ms: int       # 总耗时
    all_levels: List         # 所有层级的详细信息
    error: str               # 错误信息
```

## 适用场景

- **桌面自动化**：精确点击按钮/图标
- **RPA机器人**：UI元素定位
- **视觉测试**：截图对比分析
- **辅助功能**：帮助视障用户
- **游戏脚本**：识别UI元素

## 与其他方案的区别

| 方案 | 原理 | 精度 | 抗干扰 |
|------|------|------|--------|
| 像素匹配 | 完全相同像素 | 1px | 差 |
| 模板匹配 | 图像相似度 | ~5px | 中 |
| OCR单次 | 文字识别 | ~10px | 差 |
| **VisionLocator** | **分层放大** | **0.125px** | **强** |

## 工作流程

```
全屏截图 → OCR粗扫 → 发现候选
    ↓
选择Top5候选区域
    ↓
逐个放大检查（最多3层）
    ↓
LLaVA语义验证（可选）
    ↓
返回最高置信度结果
```

## 技术细节

- 依赖：Python 3.8+, Pillow, mss
- OCR推荐：RapidOCR（ONNX推理，高速）
- LLaVA可选：需Ollama + llava:7b模型
- 响应时间：100-500ms（取决于层级数）

## License

MIT License
