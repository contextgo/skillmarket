# -*- coding: utf-8 -*-
"""
VisionLocator — 视觉金字塔查找器
玲瑶分层放大视觉系统商城化独立版

核心理念：人怎么看屏幕，AI就应该怎么看。
从全屏扫视到细节聚焦，逐级放大递归分析。

架构：
  Level 0: 全屏截图 → OCR粗扫 → 发现候选区域 (精度 1px)
  Level 1: 裁剪+放大 → 精细OCR (精度 0.5px)
  Level 2: 再次放大 → 文字结构清晰 → LLaVA理解 (精度 0.25px)

来源：E:\\AI_dugujianhu\\app\\vision\\vision_pyramid.py
版本：商城化优化版 v1.0
"""

import os
import sys
import io
import time
import base64
import json
import threading
from pathlib import Path
from typing import Optional, Tuple, List, Dict, Any
from dataclasses import dataclass, field
from enum import Enum

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")


# ============================================================
# 依赖检测
# ============================================================

PIL_AVAILABLE = False
try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except ImportError:
    pass

MSS_AVAILABLE = False
try:
    import mss
    MSS_AVAILABLE = True
except ImportError:
    pass


# ============================================================
# 数据结构
# ============================================================

class TargetType(Enum):
    ICON = "icon"
    BUTTON = "button"
    INPUT = "input"
    TEXT = "text"
    LINK = "link"
    IMAGE = "image"
    MENU = "menu"
    TAB = "tab"
    UNKNOWN = "unknown"


@dataclass
class ZoomLevel:
    """单层放大状态"""
    level: int = 0
    region: Tuple[int, int, int, int] = (0, 0, 0, 0)
    scale: float = 1.0
    image: Optional['Image.Image'] = None
    ocr_results: List[Dict] = field(default_factory=list)
    parent_offset: Tuple[float, float] = (0.0, 0.0)
    confidences: Dict[str, float] = field(default_factory=dict)
    match_score: float = 0.0

    @property
    def center(self) -> Tuple[int, int]:
        x, y, w, h = self.region
        return (x + w // 2, y + h // 2)

    def to_dict(self) -> Dict:
        return {
            "level": self.level, "region": self.region, "scale": self.scale,
            "ocr_count": len(self.ocr_results), "match_score": self.match_score,
            "confidences": self.confidences,
        }


@dataclass
class PyramidResult:
    """金字塔查找结果"""
    found: bool = False
    target: Optional[Dict] = None
    abs_coords: Optional[Tuple[float, float]] = None
    region: Optional[Tuple[int, int, int, int]] = None
    confidence: float = 0.0
    zoom_levels_used: int = 0
    all_levels: List[ZoomLevel] = field(default_factory=list)
    total_time_ms: int = 0
    error: str = ""

    def to_dict(self) -> Dict:
        return {
            "found": self.found, "target": self.target,
            "abs_coords": self.abs_coords, "region": self.region,
            "confidence": self.confidence, "zoom_levels_used": self.zoom_levels_used,
            "total_time_ms": self.total_time_ms, "error": self.error,
            "levels": [lv.to_dict() for lv in self.all_levels],
        }


# ============================================================
# 坐标变换器
# ============================================================

class CoordinateTransform:
    """
    坐标变换器 — 处理各层级之间的坐标转换

    核心原理：
    - 放大N倍 → 坐标精度提高N倍
    - Level 0: 精度 1px
    - Level 1: 放大2x → 精度 0.5px
    - Level 2: 放大4x → 精度 0.25px
    """

    @staticmethod
    def to_absolute(local_x: float, local_y: float,
                    zoom_level: ZoomLevel) -> Tuple[float, float]:
        """局部坐标 → 屏幕绝对坐标"""
        offset_x, offset_y = zoom_level.parent_offset
        scale = zoom_level.scale
        return (local_x / scale + offset_x, local_y / scale + offset_y)

    @staticmethod
    def to_local(abs_x: float, abs_y: float,
                 zoom_level: ZoomLevel) -> Tuple[float, float]:
        """屏幕绝对坐标 → 局部坐标"""
        offset_x, offset_y = zoom_level.parent_offset
        scale = zoom_level.scale
        return ((abs_x - offset_x) * scale, (abs_y - offset_y) * scale)

    @staticmethod
    def get_precision(level: int) -> float:
        """获取当前层级的坐标精度"""
        if level <= 0:
            return 1.0
        return 1.0 / (2.0 ** level)


# ============================================================
# 候选筛选器
# ============================================================

class CandidateSelector:
    """
    候选区域筛选器 — 从OCR结果中筛选最可能的目标

    筛选策略：
    1. 精确包含：OCR文本包含目标关键词
    2. 模糊匹配：编辑距离 <= 2
    3. 语义关联：同义词词典匹配
    4. 位置加权：屏幕中央区域优先
    """

    SYNONYMS = {
        "浏览器": ["browser", "chrome", "edge", "firefox", "safari", "网页"],
        "QQ": ["企鹅", "tencent", "TIM"],
        "微信": ["wechat", "WeChat"],
        "登录": ["login", "signin", "登陆"],
        "按钮": ["button", "btn", "确定", "提交"],
        "输入框": ["input", "输入", "textfield"],
        "搜索": ["search", "查找"],
        "设置": ["setting", "config", "选项"],
        "关闭": ["close", "exit", "退出", "X"],
        "菜单": ["menu", "选项", "更多"],
    }

    def __init__(self, screen_width: int = 1920, screen_height: int = 1080):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self._center_x = screen_width / 2
        self._center_y = screen_height / 2

    def select(self, ocr_results: List[Dict], target_desc: str,
               top_k: int = 5) -> List[Tuple[Dict, float, str]]:
        """从OCR结果中筛选候选区域"""
        if not ocr_results:
            return []
        keywords = self._parse_target(target_desc)
        candidates = []
        for item in ocr_results:
            text = item.get("text", "").strip()
            if not text:
                continue
            score, match_type = self._calculate_score(text, keywords, item)
            if score > 0:
                candidates.append((item, score, match_type))
        candidates.sort(key=lambda x: -x[1])
        return candidates[:top_k]

    def _parse_target(self, target_desc: str) -> List[str]:
        """解析目标描述，提取关键词"""
        keywords = []
        parts = target_desc.replace("/", " ").replace("-", " ").split()
        for part in parts:
            part = part.strip()
            if len(part) >= 2:
                keywords.append(part.lower())
                for key, synonyms in self.SYNONYMS.items():
                    if key in target_desc or key in part:
                        keywords.extend(synonyms)
        return list(set(keywords))

    def _calculate_score(self, text: str, keywords: List[str],
                         item: Dict) -> Tuple[float, str]:
        """计算匹配分数"""
        text_lower = text.lower()
        text_len = len(text)
        if text_len < 2:
            return 0.0, ""
        score = 0.0
        match_type = ""
        # 1. 精确包含
        for kw in keywords:
            if kw in text_lower:
                score += 50
                match_type = "exact"
                break
        # 2. 模糊匹配
        if score == 0:
            for kw in keywords:
                if len(kw) >= 3 and len(text) >= 3:
                    dist = self._edit_distance(kw, text_lower)
                    similarity = 1 - (dist / max(len(kw), len(text)))
                    if similarity >= 0.6:
                        score += similarity * 30
                        match_type = "fuzzy"
                        break
        # 3. 长度匹配
        if score > 0:
            avg_kw_len = sum(len(k) for k in keywords) / len(keywords)
            len_ratio = min(text_len, avg_kw_len) / max(text_len, avg_kw_len)
            score *= (0.5 + 0.5 * len_ratio)
        # 4. 位置加权（中央优先）
        x, y = item.get("x", 0), item.get("y", 0)
        w, h = item.get("w", 50), item.get("h", 20)
        cx, cy = x + w / 2, y + h / 2
        dist_to_center = ((cx - self._center_x) ** 2 + (cy - self._center_y) ** 2) ** 0.5
        max_dist = ((self.screen_width / 2) ** 2 + (self.screen_height / 2) ** 2) ** 0.5
        score += (1 - dist_to_center / max_dist) * 10
        # 5. 置信度
        conf = item.get("conf", item.get("confidence", 0.5))
        score += conf * 5
        return score, match_type

    @staticmethod
    def _edit_distance(s1: str, s2: str) -> int:
        """编辑距离（Levenshtein）"""
        if len(s1) < len(s2):
            return CandidateSelector._edit_distance(s2, s1)
        if len(s2) == 0:
            return len(s1)
        previous_row = list(range(len(s2) + 1))
        for i, c1 in enumerate(s1):
            current_row = [i + 1]
            for j, c2 in enumerate(s2):
                current_row.append(min(
                    previous_row[j + 1] + 1,
                    current_row[j] + 1,
                    previous_row[j] + (c1 != c2)
                ))
            previous_row = current_row
        return previous_row[-1]


# ============================================================
# LLaVA 语义分析器
# ============================================================

class LLaVASemanticAnalyzer:
    """LLaVA 语义分析器 — 对放大后的图像进行深度理解"""

    TARGET_PROMPT = '''你是一个专业的UI识别助手。请分析这张图片：

1. 描述图片中的主要内容是什么
2. 找出与"{target_desc}"最匹配的元素
3. 如果找到，告诉我：
   - 元素的精确位置（左上角坐标）
   - 元素的大小（宽高像素）
   - 元素的类型（图标/按钮/输入框/文字/链接）
   - 元素的描述

请用JSON格式回复：
{{"found": true/false, "element_type": "类型", "description": "描述", "confidence": 0.0-1.0}}
'''

    def __init__(self, base_url: str = "http://localhost:11434",
                 model: str = "llava:7b"):
        self.base_url = base_url
        self.model = model
        self._available = None

    def analyze(self, image: 'Image.Image',
               target_desc: str) -> Optional[Dict]:
        """分析图像，返回语义理解结果"""
        if self._available is False:
            return None
        try:
            import requests
            buffer = io.BytesIO()
            image.save(buffer, format="PNG", quality=85)
            img_base64 = base64.b64encode(buffer.getvalue()).decode()
            prompt = self.TARGET_PROMPT.format(target_desc=target_desc)
            payload = {
                "model": self.model, "prompt": prompt,
                "images": [img_base64], "stream": False,
                "options": {"temperature": 0.3, "num_predict": 150},
            }
            resp = requests.post(
                f"{self.base_url}/api/generate",
                json=payload, timeout=60
            )
            if resp.status_code == 200:
                text = resp.json().get("response", "").strip()
                return self._parse_response(text)
        except Exception:
            pass
        return None

    def _parse_response(self, text: str) -> Optional[Dict]:
        """解析LLaVA的回复"""
        try:
            import re
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group())
        except Exception:
            pass
        text_lower = text.lower()
        found = any(w in text_lower for w in ["yes", "true", "找到", "匹配", "是"])
        return {
            "found": found,
            "element_type": "unknown",
            "description": text[:200],
            "confidence": 0.5,
        }


# ============================================================
# VisionLocator 核心类
# ============================================================

class VisionLocator:
    """
    视觉金字塔查找器 — 商城版主类

    核心理念：人怎么看屏幕，AI就应该怎么看。
    从全屏扫视到细节聚焦，逐级放大递归分析。

    用法:
        from vision_locator import VisionLocator

        vl = VisionLocator()

        # 查找目标
        result = vl.find_target("QQ浏览器图标")

        if result.found:
            print(f"找到! 坐标: {result.abs_coords}")
            print(f"置信度: {result.confidence:.2f}")
            print(f"耗时: {result.total_time_ms}ms")
        else:
            print(f"未找到: {result.error}")

        # 自定义配置
        vl = VisionLocator(max_level=4, zoom_factor=2.5, screen_width=2560, screen_height=1440)
    """

    def __init__(self,
                 ocr_engine=None,
                 llava_client=None,
                 max_level: int = 3,
                 zoom_factor: float = 2.0,
                 screen_width: int = 1920,
                 screen_height: int = 1080):
        """
        初始化视觉金字塔

        Args:
            ocr_engine: OCR引擎实例（需有 recognize(image) -> List[Dict] 方法）
                        支持: RapidOCR / EasyOCR / 任意返回 [{"text","x","y","w","h","conf"}] 的引擎
            llava_client: LLaVA客户端（可选，用于深度语义理解）
            max_level: 最大放大层级（默认3层，精度可达0.125px）
            zoom_factor: 放大因子（默认2倍）
            screen_width: 屏幕宽度
            screen_height: 屏幕高度
        """
        self.max_level = max_level
        self.zoom_factor = zoom_factor
        self.screen_width = screen_width
        self.screen_height = screen_height

        self._ocr_engine = ocr_engine
        self._ocr_ready = ocr_engine is not None
        if self._ocr_engine is None:
            self._init_ocr()

        self._llava = llava_client or LLaVASemanticAnalyzer()
        self._coord_transform = CoordinateTransform()
        self._candidate_selector = CandidateSelector(screen_width, screen_height)

        self._screencap = None
        self._screencap_ready = False
        self._all_levels: List[ZoomLevel] = []

    def _init_ocr(self):
        """延迟初始化OCR引擎"""
        engines = [
            ("RapidOCR", lambda: __import__("rapidocr_onnxruntime", fromlist=["RapidOCR"]).RapidOCR()),
            ("ocr_engine", lambda: __import__("easyocr", fromlist=[]), False),
        ]
        for name, loader in engines:
            try:
                engine = loader()
                self._ocr_engine = engine
                self._ocr_ready = True
                return
            except Exception:
                pass

    def _init_screencap(self):
        """延迟初始化截图器"""
        if self._screencap is not None:
            return
        if not MSS_AVAILABLE:
            return
        try:
            self._screencap = mss.mss()
            self._screencap_ready = True
            monitors = self._screencap.monitors
            if len(monitors) > 0:
                self.screen_width = monitors[0].get("width", 1920)
                self.screen_height = monitors[0].get("height", 1080)
                self._candidate_selector = CandidateSelector(self.screen_width, self.screen_height)
        except Exception:
            pass

    def find_target(self,
                    target_desc: str,
                    region: Tuple[int, int, int, int] = None) -> PyramidResult:
        """
        主入口：查找目标

        Args:
            target_desc: 目标描述，如 "QQ浏览器图标"、"登录按钮"、"搜索框"
            region: 可选，指定搜索区域 (x, y, w, h)

        Returns:
            PyramidResult 对象
        """
        start_time = time.time()
        self._all_levels = []

        # Step 1: Level 0 全屏截图 + OCR
        level0 = self.capture_and_scan(region)
        self._all_levels.append(level0)

        if not level0.ocr_results:
            return PyramidResult(
                found=False, error="Level 0 OCR无结果",
                total_time_ms=int((time.time() - start_time) * 1000),
                all_levels=self._all_levels,
            )

        # Step 2: 选择候选区域
        candidates = self._candidate_selector.select(
            level0.ocr_results, target_desc, top_k=5
        )

        if not candidates:
            return PyramidResult(
                found=False, error="Level 0 未找到候选",
                total_time_ms=int((time.time() - start_time) * 1000),
                all_levels=self._all_levels,
            )

        # Step 3: 逐个候选区域放大检查
        best_result = None
        best_score = 0

        for i, (candidate, score, match_type) in enumerate(candidates):
            result = self._recursive_zoom(candidate, target_desc, level0, current_level=1)
            if result and result.found and result.confidence > best_score:
                best_score = result.confidence
                best_result = result
            if best_result and best_score >= 0.9:
                break

        if best_result:
            best_result.total_time_ms = int((time.time() - start_time) * 1000)
            best_result.all_levels = self._all_levels
            return best_result

        return PyramidResult(
            found=False, error="所有候选检查完毕，未找到匹配目标",
            total_time_ms=int((time.time() - start_time) * 1000),
            all_levels=self._all_levels,
        )

    def capture_and_scan(self,
                         region: Tuple[int, int, int, int] = None) -> ZoomLevel:
        """Level 0: 全屏截图 + OCR"""
        self._init_screencap()
        if not self._ocr_ready:
            return ZoomLevel(level=0)

        try:
            if self._screencap_ready and self._screencap:
                if region:
                    x, y, w, h = region
                    monitor = {"left": x, "top": y, "width": w, "height": h}
                else:
                    monitor = self._screencap.monitors[0]
                screenshot = self._screencap.grab(monitor)
                image = Image.frombytes("RGB", screenshot.size, screenshot.bgra, "raw", "BGRX")
                actual_region = region or (monitor["left"], monitor["top"],
                                           monitor["width"], monitor["height"])
            else:
                image = self._fallback_capture()
                actual_region = region or (0, 0, self.screen_width, self.screen_height)

            ocr_results = self._call_ocr(image)
            avg_conf = sum(r.get("conf", 0.5) for r in ocr_results) / len(ocr_results) if ocr_results else 0.0

            return ZoomLevel(
                level=0, region=actual_region, scale=1.0, image=image,
                ocr_results=ocr_results,
                parent_offset=(float(actual_region[0]), float(actual_region[1])),
                confidences={"avg_ocr_confidence": avg_conf, "text_count": len(ocr_results)},
            )
        except Exception:
            return ZoomLevel(level=0)

    def zoom_in(self,
                parent_level: ZoomLevel,
                region: Tuple[int, int, int, int],
                target_desc: str = "") -> ZoomLevel:
        """裁剪区域 + 放大 + 重新OCR"""
        if not PIL_AVAILABLE:
            return parent_level
        try:
            parent_image = parent_level.image
            if parent_image is None:
                return parent_level

            crop_x, crop_y, crop_w, crop_h = region
            img_w, img_h = parent_image.size
            crop_x = max(0, min(crop_x, img_w - 1))
            crop_y = max(0, min(crop_y, img_h - 1))
            crop_w = min(crop_w, img_w - crop_x)
            crop_h = min(crop_h, img_h - crop_y)

            if crop_w <= 0 or crop_h <= 0:
                return parent_level

            cropped = parent_image.crop((crop_x, crop_y, crop_x + crop_w, crop_y + crop_h))
            new_scale = parent_level.scale * self.zoom_factor
            new_w = int(crop_w * self.zoom_factor)
            new_h = int(crop_h * self.zoom_factor)
            zoomed = cropped.resize((new_w, new_h), Image.Resampling.LANCZOS)

            ocr_results = self._call_ocr(zoomed)
            offset_x = parent_level.parent_offset[0]
            offset_y = parent_level.parent_offset[1]

            for item in ocr_results:
                item["x"] = int(item.get("x", 0) / new_scale + offset_x)
                item["y"] = int(item.get("y", 0) / new_scale + offset_y)
                item["w"] = int(item.get("w", 10) / new_scale)
                item["h"] = int(item.get("h", 10) / new_scale)

            avg_conf = sum(r.get("conf", 0.5) for r in ocr_results) / len(ocr_results) if ocr_results else 0.0

            return ZoomLevel(
                level=parent_level.level + 1, region=region, scale=new_scale, image=zoomed,
                ocr_results=ocr_results, parent_offset=(offset_x, offset_y),
                confidences={
                    "avg_ocr_confidence": avg_conf, "text_count": len(ocr_results),
                    "crop_size": (crop_w, crop_h), "zoom_size": (new_w, new_h),
                },
            )
        except Exception:
            return parent_level

    def _recursive_zoom(self,
                         initial_candidate: Dict,
                         target_desc: str,
                         level0: ZoomLevel,
                         current_level: int = 1,
                         parent_level: ZoomLevel = None) -> Optional[PyramidResult]:
        """递归放大检查"""
        if parent_level is None:
            parent_level = level0

        x = initial_candidate.get("x", 0)
        y = initial_candidate.get("y", 0)
        w = initial_candidate.get("w", 50)
        h = initial_candidate.get("h", 30)

        expand = 20
        crop_x = max(0, x - expand)
        crop_y = max(0, y - expand)
        crop_w = w + expand * 2
        crop_h = h + expand * 2
        region = (crop_x, crop_y, crop_w, crop_h)

        current = self.zoom_in(parent_level, region, target_desc)
        self._all_levels.append(current)

        ocr_conf = current.confidences.get("avg_ocr_confidence", 0)
        text_count = current.confidences.get("text_count", 0)
        crop_size = current.confidences.get("crop_size", (0, 0))

        # 终止条件
        if ocr_conf >= 0.9:
            pass
        if current.level >= self.max_level or (crop_size and min(crop_size) < 20):
            return None
        if text_count == 0 and current.level > 0:
            return None

        candidates = self._candidate_selector.select(
            current.ocr_results, target_desc, top_k=3
        )
        if candidates:
            current.match_score = candidates[0][1]

        if candidates and candidates[0][1] >= 40:
            best = candidates[0][0]
            confidence = candidates[0][1] / 100.0

            # LLaVA 验证
            llava_result = None
            if current.level >= 2 and len(current.ocr_results) <= 10:
                llava_result = self._llava.analyze(current.image, target_desc)
            if llava_result and llava_result.get("found"):
                confidence = (confidence + llava_result.get("confidence", 0.5)) / 2

            abs_x, abs_y = current.center
            return PyramidResult(
                found=True,
                target={
                    "text": best.get("text", ""),
                    "type": self._infer_target_type(best.get("text", "")),
                    "description": llava_result.get("description", "") if llava_result else "",
                },
                abs_coords=(float(abs_x), float(abs_y)),
                region=(x, y, w, h),
                confidence=confidence,
                zoom_levels_used=current.level,
            )

        if candidates:
            return self._recursive_zoom(
                candidates[0][0], target_desc, level0, current_level + 1, current
            )
        return None

    def _call_ocr(self, image: 'Image.Image') -> List[Dict]:
        """调用OCR引擎"""
        if self._ocr_engine is None:
            return []
        try:
            if hasattr(self._ocr_engine, "recognize"):
                return self._ocr_engine.recognize(image)
            elif callable(self._ocr_engine):
                result = self._ocr_engine(image)
                if isinstance(result, dict) and "lines" in result:
                    items = []
                    for line in result.get("lines", []):
                        box = line.get("box", [[0, 0], [0, 0], [0, 0], [0, 0]])
                        xs = [p[0] for p in box]
                        ys = [p[1] for p in box]
                        items.append({
                            "text": line.get("text", ""),
                            "x": int(min(xs)), "y": int(min(ys)),
                            "w": int(max(xs) - min(xs)), "h": int(max(ys) - min(ys)),
                            "conf": line.get("confidence", 0.5),
                        })
                    return items
        except Exception:
            pass
        return []

    def _infer_target_type(self, text: str) -> str:
        """根据文字推断UI元素类型"""
        text_lower = text.lower()
        type_keywords = {
            "button": ["登录", "注册", "发送", "提交", "确定", "取消", "关闭", "保存", "删除"],
            "input": ["输入", "请输入", "账号", "密码", "用户名"],
            "search": ["搜索", "search", "查找", "查询"],
            "link": ["http", "链接", "www"],
            "icon": ["图标", "icon", "logo", "图片"],
            "menu": ["菜单", "选项", "更多"],
        }
        for etype, keywords in type_keywords.items():
            if any(kw in text_lower for kw in keywords):
                return etype
        return "unknown"

    def _fallback_capture(self) -> Optional['Image.Image']:
        """回退截图方案"""
        if PIL_AVAILABLE:
            return Image.new("RGB", (self.screen_width, self.screen_height), (128, 128, 128))
        return None

    def get_stats(self) -> Dict:
        """获取性能统计"""
        return {"total_levels": len(self._all_levels)}

    def debug_visualize(self, result: PyramidResult) -> Optional['Image.Image']:
        """生成调试可视化图像"""
        if not PIL_AVAILABLE or not result.all_levels:
            return None
        try:
            img = result.all_levels[0].image.copy()
            draw = ImageDraw.Draw(img)
            colors = [(255, 0, 0), (0, 255, 0), (0, 0, 255), (255, 255, 0)]
            for i, level in enumerate(result.all_levels):
                if i == 0:
                    continue
                color = colors[min(i - 1, len(colors) - 1)]
                x, y, w, h = level.region
                draw.rectangle([x, y, x + w, y + h], outline=color, width=2)
                draw.text((x + 5, y + 5), f"L{i}", fill=color)
            if result.abs_coords:
                cx, cy = int(result.abs_coords[0]), int(result.abs_coords[1])
                draw.ellipse([cx - 10, cy - 10, cx + 10, cy + 10], fill=(255, 0, 255))
            return img
        except Exception:
            return None


# ============================================================
# 快速使用
# ============================================================

def quick_find(target: str) -> PyramidResult:
    """快速查找目标"""
    vl = VisionLocator()
    return vl.find_target(target)
