---
# 核心元数据（OpenClaw 识别的关键，必须有！）
name: document-summary
slug: document-summary
description: Summarizes technical documents into structured markdown.
version: 1.0.2
author: kelevis
tags: ["document", "summary", "markdown", "technical"]
metadata: {"clawdbot":{"emoji":"📝"}}
---

# Document Summary 📝

## Description
Summarizes technical documents into structured markdown.

## Invocation
This skill activates when the user intent matches:
- summarize
- summary
- analyze document
- extract key points

## Inputs
- content (string, required)
  The document text to analyze.

## Behavior
You are a professional technical analyst.

When invoked:
1. Read the provided content.
2. Produce output in Markdown format.
3. Structure output as:
   - ## Summary (Max 5 lines)
   - ## Key Points (Bullet list)
   - ## Risks (Potential risks or concerns)

## Output Format
Return valid Markdown only.