#!/usr/bin/env python3
"""
Cursor Chat Analysis Report Generator
Reads analysis JSON data and generates a formatted .xlsx report.

Usage:
    python cursor_chat_analyze.py <input.json> [--output output.xlsx]
"""

import sys
import os
import json
import argparse

OPENPYXL_TARGET_VERSION = "3.1.5"
OPENPYXL_MIN_VERSION_TUPLE = (3, 1, 0)

def ensure_openpyxl():
    """Check openpyxl is installed with required version. Exit with install instructions if not."""
    try:
        import openpyxl
        ver = tuple(int(x) for x in openpyxl.__version__.split(".")[:3])
        if ver < OPENPYXL_MIN_VERSION_TUPLE:
            print(f"Error: openpyxl {openpyxl.__version__} is too old (need >={'.'.join(str(x) for x in OPENPYXL_MIN_VERSION_TUPLE)})", file=sys.stderr)
            print(f"Run: pip install openpyxl=={OPENPYXL_TARGET_VERSION}", file=sys.stderr)
            sys.exit(1)
        return openpyxl
    except ImportError:
        print("Error: openpyxl is not installed.", file=sys.stderr)
        print(f"Run: pip install openpyxl=={OPENPYXL_TARGET_VERSION}", file=sys.stderr)
        sys.exit(1)


def create_report(data, output_path):
    """Create the xlsx report from analysis data."""
    openpyxl = ensure_openpyxl()
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    from openpyxl.utils import get_column_letter

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "聊天记录分析"

    # Column headers (Chinese, concise)
    headers = [
        "问题描述",
        "对话次数",
        "初始提示词",
        "最终解决提示词",
        "解决关键",
        "提示词策略",
        "优化建议",
        "备注",
    ]

    # Header styles
    header_font = Font(name="Microsoft YaHei", bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    thin_border = Border(
        left=Side(style="thin"),
        right=Side(style="thin"),
        top=Side(style="thin"),
        bottom=Side(style="thin"),
    )

    # Write headers
    for col_idx, header in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=header)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
        cell.border = thin_border

    # Column widths
    col_widths = [35, 10, 55, 55, 45, 40, 45, 35]
    for i, width in enumerate(col_widths, 1):
        ws.column_dimensions[get_column_letter(i)].width = width

    # Row styles
    cell_font = Font(name="Microsoft YaHei", size=10)
    cell_alignment = Alignment(vertical="top", wrap_text=True)

    # Write data rows
    problems = data.get("problems", [])
    for row_idx, problem in enumerate(problems, 2):
        values = [
            problem.get("problem_description", ""),
            problem.get("conversation_count", ""),
            problem.get("initial_prompt", ""),
            problem.get("final_prompt", ""),
            problem.get("key_resolution", ""),
            problem.get("prompt_strategy", ""),
            problem.get("optimization_suggestion", ""),
            problem.get("remark", ""),
        ]
        for col_idx, value in enumerate(values, 1):
            cell = ws.cell(row=row_idx, column=col_idx, value=value)
            cell.font = cell_font
            cell.alignment = cell_alignment
            cell.border = thin_border

        # Auto row height (approximate)
        max_lines = 1
        for v in values:
            if v:
                lines = str(v).count("\n") + 1
                max_lines = max(max_lines, lines)
        ws.row_dimensions[row_idx].height = min(max(20, max_lines * 15), 400)

    # --- Summary section: 2 empty rows after data, then summary ---
    summary_data = data.get("summary", {})
    summary_row = len(problems) + 2 + 2  # data end + 2 empty rows

    summary_title_font = Font(name="Microsoft YaHei", bold=True, size=12, color="4472C4")
    summary_header_font = Font(name="Microsoft YaHei", bold=True, size=11)
    summary_font = Font(name="Microsoft YaHei", size=10)
    summary_alignment = Alignment(vertical="top", wrap_text=True)

    # Title
    ws.merge_cells(start_row=summary_row, start_column=1, end_row=summary_row, end_column=len(headers))
    title_cell = ws.cell(row=summary_row, column=1, value="总结：提示词优化建议 & 通用规则")
    title_cell.font = summary_title_font
    title_cell.alignment = Alignment(horizontal="left", vertical="center")

    summary_row += 1

    # Prompt optimization suggestions
    suggestions = summary_data.get("prompt_suggestions", [])
    if suggestions:
        ws.merge_cells(start_row=summary_row, start_column=1, end_row=summary_row, end_column=len(headers))
        h = ws.cell(row=summary_row, column=1, value="提示词优化建议")
        h.font = summary_header_font
        summary_row += 1

        for sug in suggestions:
            ws.merge_cells(start_row=summary_row, start_column=1, end_row=summary_row, end_column=len(headers))
            c = ws.cell(row=summary_row, column=1, value=f"• {sug}")
            c.font = summary_font
            c.alignment = summary_alignment
            ws.row_dimensions[summary_row].height = max(20, sug.count("\n") * 15 + 20)
            summary_row += 1

        summary_row += 1  # blank row

    # Universal rules
    rules = summary_data.get("universal_rules", "")
    if rules:
        ws.merge_cells(start_row=summary_row, start_column=1, end_row=summary_row, end_column=len(headers))
        h = ws.cell(row=summary_row, column=1, value="通用提示词规则")
        h.font = summary_header_font
        summary_row += 1

        for line in rules.split("\n"):
            line = line.strip()
            if not line:
                continue
            ws.merge_cells(start_row=summary_row, start_column=1, end_row=summary_row, end_column=len(headers))
            c = ws.cell(row=summary_row, column=1, value=line)
            c.font = summary_font
            c.alignment = summary_alignment
            ws.row_dimensions[summary_row].height = 20
            summary_row += 1

    # Freeze top row
    ws.freeze_panes = "A2"

    # Auto filter (only for data table)
    ws.auto_filter.ref = f"A1:{get_column_letter(len(headers))}{len(problems) + 1}"

    wb.save(output_path)
    print(f"Report saved to: {output_path}")
    print(f"Total problems analyzed: {len(problems)}")


def main():
    parser = argparse.ArgumentParser(description="Generate Cursor Chat Analysis Report")
    parser.add_argument("input", help="Input JSON file with analysis data")
    parser.add_argument("--output", "-o", help="Output xlsx file path", default=None)
    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}", file=sys.stderr)
        sys.exit(1)

    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    if not data.get("problems"):
        print("Error: No problems found in input data", file=sys.stderr)
        sys.exit(1)

    output_path = args.output
    if not output_path:
        # Default output: same directory as input, with _report.xlsx suffix
        base = os.path.splitext(args.input)[0]
        output_path = base + "_report.xlsx"

    create_report(data, output_path)


if __name__ == "__main__":
    main()
