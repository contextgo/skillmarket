---
name: stock-alert-workflow
description: Automated stock earnings surprise alert workflow. Scans recent earnings for EPS beats >10%, fetches 30-day analyst ratings, and pushes formatted alerts via WhatsApp. Use for earnings surprise monitoring, analyst rating tracking, and WhatsApp notification delivery.
tags: ['stocks', 'earnings', 'alerts', 'whatsapp', 'analyst-ratings', 'workflow']
metadata:
  {
    "clawdbot":
      {
        "emoji": "🔔",
        "requires": { "bins": ["uv", "wacli"], "env": [] },
        "install":
          [
            {
              "id": "uv-brew",
              "kind": "brew",
              "formula": "uv",
              "bins": ["uv"],
              "label": "Install uv (brew)",
            },
          ],
      },
  }
---

# Stock Alert Workflow (v1.0.0)

Automated earnings surprise alert pipeline: detect EPS beats >10%, enrich with 30-day analyst ratings, push via WhatsApp.

## Workflow Overview

```
Earnings Scan → Filter (>10% surprise) → Analyst Rating Enrichment → WhatsApp Push
```

1. **Earnings Scan**: Fetches recent quarterly EPS data via Yahoo Finance for a watchlist of tickers
2. **Surprise Filter**: Keeps only stocks where actual EPS beat estimates by >10%
3. **Analyst Enrichment**: For each surprise stock, searches 30-day analyst upgrades/downgrades/initiations
4. **WhatsApp Push**: Formats and delivers a concise alert card to the configured WhatsApp contact

## Quick Start

### Scan a watchlist and push alerts

```bash
uv run {baseDir}/scripts/earnings_surprise_alert.py --watchlist AAPL,MSFT,NVDA,GOOGL,META
```

### Scan with custom surprise threshold

```bash
uv run {baseDir}/scripts/earnings_surprise_alert.py --watchlist AAPL,MSFT --threshold 15
```

### Scan S&P 500 top holdings (built-in)

```bash
uv run {baseDir}/scripts/earnings_surprise_alert.py --sp500-top
```

### Dry run (no WhatsApp push, print to console)

```bash
uv run {baseDir}/scripts/earnings_surprise_alert.py --watchlist AAPL,MSFT --dry-run
```

### Scan with specific WhatsApp recipient

```bash
uv run {baseDir}/scripts/earnings_surprise_alert.py --watchlist AAPL,MSFT --whatsapp-to "+1234567890"
```

### Output JSON for programmatic use

```bash
uv run {baseDir}/scripts/earnings_surprise_alert.py --watchlist AAPL,MSFT --output json
```

## CLI Reference

| Flag | Description | Default |
|------|-------------|---------|
| `--watchlist` | Comma-separated ticker symbols | Required (or `--sp500-top`) |
| `--sp500-top` | Scan top 50 S&P 500 holdings | false |
| `--threshold` | EPS surprise % threshold | 10 |
| `--whatsapp-to` | WhatsApp recipient phone number | `STOCK_ALERT_WHATSAPP_TO` env var |
| `--dry-run` | Print alerts without pushing to WhatsApp | false |
| `--output` | Output format: `text` or `json` | text |
| `--verbose` | Verbose logging to stderr | false |
| `--analyst-days` | Lookback days for analyst ratings | 30 |

## Alert Format

Example WhatsApp message:

```
📊 EARNINGS SURPRISE ALERT
━━━━━━━━━━━━━━━━━━━━━
🟢 NVDA (NVIDIA Corp)
   EPS: $1.32 vs $1.10 est. (+20.0% beat)
   Revenue: $30.0B vs $28.5B est.
   Quarter: Q4 FY2025

📈 Recent Analyst Ratings (30d):
   • Buy — Goldman Sachs (May 5)
   • Overweight — Morgan Stanley (May 3)
   • Buy — JPMorgan (Apr 28)
   Consensus: Strong Buy (4/4 bullish)

⏰ Scanned: 2026-05-07 03:45 CST
⚠️ Not financial advice
```

## WhatsApp Integration

### Prerequisites

1. **wacli** must be installed and authenticated (`wacli login`)
2. Set the default recipient via environment variable:

```bash
export STOCK_ALERT_WHATSAPP_TO="+1234567890"
```

Or pass `--whatsapp-to` on each run.

### Sending via wacli

The script shells out to:

```bash
wacli send --to "+1234567890" --text "..."
```

## Cron Scheduling

Set up daily earnings scans during earnings season:

```bash
# Weekdays at 8:00 AM (after market opens)
openclaw cron add --name "earnings-surprise-scan" \
  --schedule "0 8 * * 1-5" \
  --payload '{"kind":"agentTurn","message":"Run earnings surprise scan: uv run ~/.openclaw/workspace/skills/stock-alert-workflow/scripts/earnings_surprise_alert.py --sp500-top --whatsapp-to +1234567890"}'
```

## Data Sources

- **Earnings data**: Yahoo Finance (`yfinance`) — EPS actuals, estimates, revenue
- **Analyst ratings**: Yahoo Finance recommendations + web search fallback
- **WhatsApp delivery**: `wacli` CLI

## Limitations

- Yahoo Finance earnings data may lag by 15-20 minutes
- Analyst recommendation data from yfinance may not include all recent changes
- wacli requires an active WhatsApp session
- Rate limiting: scans ~50 tickers/minute to avoid yfinance throttling
- US markets only

## Error Handling

- Invalid tickers: skipped with warning
- No earnings data: skipped silently
- WhatsApp send failure: logged, does not halt remaining alerts
- yfinance API failure: retries 3x with exponential backoff