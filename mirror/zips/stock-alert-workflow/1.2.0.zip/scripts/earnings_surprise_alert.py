#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "yfinance>=0.2.40",
#     "pandas>=2.0.0",
# ]
# ///
"""
Earnings Surprise Alert Workflow

Scans tickers for EPS beats > threshold%, fetches 30-day analyst ratings,
and pushes formatted alerts via WhatsApp (wacli).

Usage:
    uv run earnings_surprise_alert.py --watchlist AAPL,MSFT,NVDA
    uv run earnings_surprise_alert.py --sp500-top --threshold 15
    uv run earnings_surprise_alert.py --watchlist AAPL --dry-run
    uv run earnings_surprise_alert.py --watchlist AAPL --output json
"""

import argparse
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass, asdict, field
from datetime import datetime, timedelta
from typing import Literal

import pandas as pd
import yfinance as yf


# Top 50 S&P 500 holdings by weight (as of 2025)
SP500_TOP_50 = [
    "AAPL", "MSFT", "NVDA", "AMZN", "GOOGL", "META", "BRK-B", "LLY",
    "AVGO", "TSLA", "JPM", "UNH", "V", "XOM", "MA", "PG", "JNJ", "COST",
    "HD", "ABBV", "MRK", "CRM", "ORCL", "WMT", "BAC", "AMD", "NFLX",
    "CVX", "KO", "PEP", "ADBE", "INTC", "TMO", "CSCO", "ABT", "MCD",
    "PFE", "DIS", "CMCSA", "VZ", "NKE", "WFC", "TXN", "PM", "COP",
    "GS", "HON", "QCOM", "CAT",
]


@dataclass
class EarningsResult:
    ticker: str
    company_name: str
    actual_eps: float | None
    expected_eps: float | None
    surprise_pct: float | None
    actual_revenue: float | None
    expected_revenue: float | None
    revenue_surprise_pct: float | None
    quarter_label: str | None
    earnings_date: str | None
    passed_filter: bool = False


@dataclass
class AnalystRating:
    firm: str
    rating: str  # "Buy", "Hold", "Sell", "Overweight", "Underweight", etc.
    action: str  # "up", "down", "init", "reit" (reiterate)
    date: str
    price_target: float | None = None


@dataclass
class AlertCard:
    ticker: str
    company_name: str
    earnings: EarningsResult
    analyst_ratings: list[AnalystRating] = field(default_factory=list)
    consensus_summary: str | None = None
    bullish_count: int = 0
    total_ratings: int = 0


def fetch_earnings(ticker: str, verbose: bool = False) -> EarningsResult | None:
    """Fetch most recent quarterly earnings data for a ticker."""
    max_retries = 3
    for attempt in range(max_retries):
        try:
            stock = yf.Ticker(ticker)
            info = stock.info
            if not info or "regularMarketPrice" not in info:
                return None

            company_name = info.get("longName") or info.get("shortName") or ticker

            # Try multiple yfinance earnings endpoints
            earnings_data = None

            # Method 1: earnings_dates (most detailed, newer yfinance)
            try:
                ed = stock.earnings_dates
                if ed is not None and not ed.empty:
                    earnings_data = ed.sort_index(ascending=False).head(8)
                    if verbose:
                        print(f"  earnings_dates: {len(ed)} rows", file=sys.stderr)
            except Exception:
                pass

            # Method 2: earnings_history (alternative API)
            if earnings_data is None or earnings_data.empty:
                try:
                    eh = stock.earnings_history
                    if eh is not None and not eh.empty:
                        earnings_data = eh.sort_index(ascending=False).head(8)
                        if verbose:
                            print(f"  earnings_history: {len(eh)} rows", file=sys.stderr)
                except Exception:
                    pass

            # Method 3: quarterly earnings from stock.earnings (legacy)
            if earnings_data is None or earnings_data.empty:
                try:
                    leg = stock.earnings
                    if leg is not None and hasattr(leg, 'eps') and not leg.empty:
                        # Legacy format - build from EPS data
                        if verbose:
                            print(f"  legacy earnings: {len(leg)} rows", file=sys.stderr)
                except Exception:
                    pass

            if earnings_data is None or earnings_data.empty:
                # Last resort: use info dict for trailing EPS
                trailing_eps = info.get("trailingEps")
                forward_eps = info.get("forwardEps")

                if trailing_eps and forward_eps and forward_eps > 0:
                    surprise = ((trailing_eps - forward_eps) / abs(forward_eps)) * 100
                    return EarningsResult(
                        ticker=ticker,
                        company_name=company_name,
                        actual_eps=trailing_eps,
                        expected_eps=forward_eps,
                        surprise_pct=surprise,
                        actual_revenue=None,
                        expected_revenue=None,
                        revenue_surprise_pct=None,
                        quarter_label="Latest",
                        earnings_date=None,
                    )

                return EarningsResult(
                    ticker=ticker,
                    company_name=company_name,
                    actual_eps=None,
                    expected_eps=None,
                    surprise_pct=None,
                    actual_revenue=None,
                    expected_revenue=None,
                    revenue_surprise_pct=None,
                    quarter_label=None,
                    earnings_date=None,
                )

            # Find the most recent quarter with actual EPS data
            for idx, row in earnings_data.iterrows():
                actual_eps = None
                expected_eps = None
                surprise_pct = None

                # Handle both column naming conventions:
                #   earnings_history: epsActual, epsEstimate, surprisePercent (decimal)
                #   earnings_dates: Reported EPS, EPS Estimate, ... (no surprise col)

                for actual_col, est_col in [
                    ("epsActual", "epsEstimate"),
                    ("Reported EPS", "EPS Estimate"),
                ]:
                    a = row.get(actual_col)
                    e = row.get(est_col)
                    if pd.notna(a) and pd.notna(e):
                        actual_eps = float(a)
                        expected_eps = float(e)
                        break

                if actual_eps is None or expected_eps is None:
                    continue

                if expected_eps == 0:
                    continue

                # Get surprise %
                sp = row.get("surprisePercent")
                if pd.notna(sp):
                    surprise_pct = float(sp) * 100  # earnings_history gives decimal
                else:
                    surprise_pct = ((actual_eps - expected_eps) / abs(expected_eps)) * 100

                # Revenue data (if available)
                actual_revenue = None
                expected_revenue = None
                revenue_surprise_pct = None

                for rev_a_col, rev_e_col in [
                    ("revenueActual", "revenueEstimate"),
                    ("Reported Revenue", "Revenue Estimate"),
                ]:
                    ra = row.get(rev_a_col)
                    re = row.get(rev_e_col)
                    if pd.notna(ra) and pd.notna(re) and float(re) > 0:
                        actual_revenue = float(ra)
                        expected_revenue = float(re)
                        rsp = row.get("revenueSurprisePercent")
                        if pd.notna(rsp):
                            revenue_surprise_pct = float(rsp) * 100
                        else:
                            revenue_surprise_pct = ((actual_revenue - expected_revenue) / expected_revenue) * 100
                        break

                # Quarter label
                earnings_dt = pd.Timestamp(idx)
                quarter = (earnings_dt.month - 1) // 3 + 1
                quarter_label = f"Q{quarter} FY{earnings_dt.year}"
                earnings_date = earnings_dt.strftime("%Y-%m-%d")

                return EarningsResult(
                    ticker=ticker,
                    company_name=company_name,
                    actual_eps=actual_eps,
                    expected_eps=expected_eps,
                    surprise_pct=surprise_pct,
                    actual_revenue=actual_revenue,
                    expected_revenue=expected_revenue,
                    revenue_surprise_pct=revenue_surprise_pct,
                    quarter_label=quarter_label,
                    earnings_date=earnings_date,
                )

            # No quarter with both actual & estimate found
            return EarningsResult(
                ticker=ticker,
                company_name=company_name,
                actual_eps=None,
                expected_eps=None,
                surprise_pct=None,
                actual_revenue=None,
                expected_revenue=None,
                revenue_surprise_pct=None,
                quarter_label=None,
                earnings_date=None,
            )

        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)
            else:
                if verbose:
                    print(f"Failed to fetch {ticker}: {e}", file=sys.stderr)
                return None

    return None


def fetch_analyst_ratings(ticker: str, lookback_days: int = 30, verbose: bool = False) -> list[AnalystRating]:
    """Fetch recent analyst upgrade/downgrade history from Yahoo Finance."""
    ratings = []

    try:
        stock = yf.Ticker(ticker)

        # Use upgrades_downgrades (individual analyst actions)
        ud = None
        try:
            ud = stock.upgrades_downgrades
        except Exception:
            pass

        if ud is not None and not ud.empty:
            cutoff = datetime.now() - timedelta(days=lookback_days)

            for idx, row in ud.iterrows():
                try:
                    firm = row.get("Firm") or "Unknown"
                    to_grade = row.get("ToGrade") or ""
                    from_grade = row.get("FromGrade") or ""
                    action = row.get("Action") or ""

                    # Price target
                    price_target = None
                    pt = row.get("currentPriceTarget")
                    if pd.notna(pt):
                        price_target = float(pt)

                    # Parse date
                    rec_date = None
                    if isinstance(idx, pd.Timestamp):
                        rec_date = idx.to_pydatetime()
                    elif isinstance(idx, datetime):
                        rec_date = idx
                    else:
                        continue

                    if rec_date < cutoff:
                        continue

                    # Normalize action
                    action_lower = action.lower() if isinstance(action, str) else ""
                    if "up" in action_lower or "upgrade" in action_lower:
                        action_norm = "up"
                    elif "down" in action_lower or "downgrade" in action_lower:
                        action_norm = "down"
                    elif "init" in action_lower or "start" in action_lower or "initiate" in action_lower:
                        action_norm = "init"
                    elif "reit" in action_lower or "maintain" in action_lower:
                        action_norm = "reit"
                    else:
                        action_norm = "reit" if from_grade and to_grade and from_grade == to_grade else "init"

                    ratings.append(AnalystRating(
                        firm=str(firm)[:40],
                        rating=str(to_grade),
                        action=action_norm,
                        date=rec_date.strftime("%Y-%m-%d"),
                        price_target=price_target,
                    ))
                except Exception:
                    continue

        # Fallback: if no individual ratings, build from recommendations summary
        if not ratings:
            try:
                recs = stock.recommendations
                if recs is not None and not recs.empty:
                    latest = recs.iloc[0]
                    sb = int(latest.get("strongBuy", 0))
                    b = int(latest.get("buy", 0))
                    h = int(latest.get("hold", 0))
                    s = int(latest.get("sell", 0))
                    ss = int(latest.get("strongSell", 0))
                    total = sb + b + h + s + ss

                    if total > 0:
                        # Determine consensus label
                        bullish = sb + b
                        bearish = s + ss
                        if bullish > total * 0.7:
                            label = "Strong Buy"
                        elif bullish > total * 0.5:
                            label = "Buy"
                        elif bearish > total * 0.5:
                            label = "Sell"
                        else:
                            label = "Hold"

                        ratings.append(AnalystRating(
                            firm=f"{total} Analysts",
                            rating=f"{label} ({sb}SB/{b}B/{h}H/{s}S/{ss}SS)",
                            action="reit",
                            date=datetime.now().strftime("%Y-%m-%d"),
                        ))
            except Exception:
                pass

    except Exception as e:
        if verbose:
            print(f"Error fetching analyst ratings for {ticker}: {e}", file=sys.stderr)

    # Sort by date descending, limit to 10
    ratings.sort(key=lambda r: r.date, reverse=True)
    return ratings[:10]


def classify_rating(rating: str) -> Literal["bullish", "neutral", "bearish"]:
    """Classify an analyst rating as bullish, neutral, or bearish."""
    r = rating.lower().strip()
    bullish = {"buy", "strong buy", "overweight", "outperform", "positive", "sector outperform"}
    bearish = {"sell", "strong sell", "underweight", "underperform", "negative", "sector underperform"}
    # If the rating contains bullish/bearish keywords (e.g., "57 Buy / 2 Hold / 1 Sell")
    if any(b in r for b in bullish):
        # Check if it's a summary like "57 Buy / 2 Hold / 1 Sell"
        if "/" in r:
            return "bullish"  # Summary format with Buy = bullish consensus
        if r in bullish:
            return "bullish"
    if r in bearish:
        return "bearish"
    if r in bullish:
        return "bullish"
    return "neutral"


def build_consensus(ratings: list[AnalystRating]) -> tuple[str, int, int]:
    """Build consensus summary from analyst ratings. Returns (summary, bullish_count, total)."""
    if not ratings:
        return "No recent ratings", 0, 0

    bullish = sum(1 for r in ratings if classify_rating(r.rating) == "bullish")
    bearish = sum(1 for r in ratings if classify_rating(r.rating) == "bearish")
    total = len(ratings)

    if bullish == total:
        consensus = "Strong Buy"
    elif bullish > total * 0.6:
        consensus = "Buy"
    elif bearish > total * 0.6:
        consensus = "Sell"
    elif bearish == total:
        consensus = "Strong Sell"
    else:
        consensus = "Mixed/Hold"

    return f"{consensus} ({bullish}/{total} bullish)", bullish, total


def format_alert_text(card: AlertCard) -> str:
    """Format an alert card into a WhatsApp-friendly message."""
    lines = []
    e = card.earnings

    lines.append("📊 EARNINGS SURPRISE ALERT")
    lines.append("━━━━━━━━━━━━━━━━━━━━━")

    # Ticker & name
    lines.append(f"🟢 {e.ticker} ({e.company_name})")

    # EPS
    if e.actual_eps is not None and e.expected_eps is not None:
        beat_miss = "beat" if e.surprise_pct and e.surprise_pct > 0 else "miss"
        lines.append(f"   EPS: ${e.actual_eps:.2f} vs ${e.expected_eps:.2f} est. ({e.surprise_pct:+.1f}% {beat_miss})")

    # Revenue
    if e.actual_revenue is not None and e.expected_revenue is not None:
        rev_b = e.actual_revenue / 1e9
        rev_e = e.expected_revenue / 1e9
        lines.append(f"   Revenue: ${rev_b:.1f}B vs ${rev_e:.1f}B est.")

    # Quarter
    if e.quarter_label:
        lines.append(f"   Quarter: {e.quarter_label}")

    lines.append("")

    # Analyst ratings
    if card.analyst_ratings:
        lines.append(f"📈 Recent Analyst Ratings ({card.total_ratings}):")
        for r in card.analyst_ratings[:5]:
            action_emoji = {"up": "⬆️", "down": "⬇️", "init": "🆕", "reit": "🔄"}.get(r.action, "")
            pt_str = f" → ${r.price_target:.0f}" if r.price_target else ""
            lines.append(f"   • {r.rating} — {r.firm} {action_emoji} ({r.date}){pt_str}")

        if card.consensus_summary:
            lines.append(f"   Consensus: {card.consensus_summary}")
    else:
        lines.append("📈 No recent analyst ratings found")

    lines.append("")
    lines.append(f"⏰ Scanned: {datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("⚠️ Not financial advice")

    return "\n".join(lines)


def send_whatsapp(to: str, text: str, verbose: bool = False) -> bool:
    """Send a WhatsApp message via wacli."""
    try:
        result = subprocess.run(
            ["wacli", "send", "--to", to, "--text", text],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            if verbose:
                print(f"wacli error: {result.stderr}", file=sys.stderr)
            return False
        return True
    except FileNotFoundError:
        print("Error: wacli not found. Install with: npm i -g wacli", file=sys.stderr)
        return False
    except subprocess.TimeoutExpired:
        if verbose:
            print("wacli send timed out", file=sys.stderr)
        return False
    except Exception as e:
        if verbose:
            print(f"WhatsApp send error: {e}", file=sys.stderr)
        return False


def scan_watchlist(
    tickers: list[str],
    threshold: float = 10.0,
    analyst_days: int = 30,
    dry_run: bool = False,
    whatsapp_to: str | None = None,
    output_format: str = "text",
    verbose: bool = False,
) -> list[AlertCard]:
    """Main scan: fetch earnings, filter by surprise, enrich with analyst ratings, push alerts."""
    alert_cards = []
    sent_count = 0
    failed_count = 0

    for i, ticker in enumerate(tickers):
        ticker = ticker.upper().strip()
        if not ticker:
            continue

        if verbose:
            print(f"[{i+1}/{len(tickers)}] Scanning {ticker}...", file=sys.stderr)

        # Step 1: Fetch earnings
        result = fetch_earnings(ticker, verbose=verbose)
        if result is None:
            if verbose:
                print(f"  ⚠️ Could not fetch data for {ticker}", file=sys.stderr)
            continue

        # Step 2: Filter by surprise threshold
        if result.surprise_pct is not None and result.surprise_pct > threshold:
            result.passed_filter = True

            if verbose:
                print(f"  ✅ {ticker}: EPS surprise {result.surprise_pct:+.1f}% (>{threshold}%)", file=sys.stderr)

            # Step 3: Fetch analyst ratings
            ratings = fetch_analyst_ratings(ticker, lookback_days=analyst_days, verbose=verbose)
            consensus, bullish, total = build_consensus(ratings)

            card = AlertCard(
                ticker=ticker,
                company_name=result.company_name,
                earnings=result,
                analyst_ratings=ratings,
                consensus_summary=consensus,
                bullish_count=bullish,
                total_ratings=total,
            )
            alert_cards.append(card)

            # Step 4: Push via WhatsApp
            if not dry_run and whatsapp_to:
                alert_text = format_alert_text(card)
                success = send_whatsapp(whatsapp_to, alert_text, verbose=verbose)
                if success:
                    sent_count += 1
                else:
                    failed_count += 1
                    if verbose:
                        print(f"  ❌ WhatsApp send failed for {ticker}", file=sys.stderr)
            elif dry_run:
                alert_text = format_alert_text(card)
                print(alert_text)
                print()
        else:
            if verbose:
                if result.surprise_pct is not None:
                    print(f"  ➖ {ticker}: EPS surprise {result.surprise_pct:+.1f}% (≤{threshold}%)", file=sys.stderr)
                else:
                    print(f"  ➖ {ticker}: No earnings data available", file=sys.stderr)

        # Rate limiting: small delay between tickers
        if i < len(tickers) - 1:
            time.sleep(0.5)

    # Summary
    if output_format == "text":
        print(f"\n{'='*50}")
        print(f"Scan complete: {len(tickers)} tickers scanned")
        print(f"Surprises >{threshold}%: {len(alert_cards)}")
        if whatsapp_to and not dry_run:
            print(f"WhatsApp sent: {sent_count}, failed: {failed_count}")
        elif dry_run and alert_cards:
            print("Mode: dry-run (no WhatsApp messages sent)")
        print(f"{'='*50}")
    elif output_format == "json":
        output = {
            "scan_time": datetime.now().isoformat(),
            "tickers_scanned": len(tickers),
            "threshold_pct": threshold,
            "alerts_found": len(alert_cards),
            "whatsapp_sent": sent_count if whatsapp_to and not dry_run else None,
            "whatsapp_failed": failed_count if whatsapp_to and not dry_run else None,
            "dry_run": dry_run,
            "alerts": [asdict(card) for card in alert_cards],
        }
        print(json.dumps(output, indent=2, default=str))

    return alert_cards


def main():
    parser = argparse.ArgumentParser(
        description="Earnings Surprise Alert Workflow"
    )
    parser.add_argument(
        "--watchlist",
        type=str,
        help="Comma-separated ticker symbols (e.g., AAPL,MSFT,NVDA)",
    )
    parser.add_argument(
        "--sp500-top",
        action="store_true",
        help="Scan top 50 S&P 500 holdings",
    )
    parser.add_argument(
        "--threshold",
        type=float,
        default=10.0,
        help="EPS surprise %% threshold (default: 10)",
    )
    parser.add_argument(
        "--whatsapp-to",
        type=str,
        default=None,
        help="WhatsApp recipient phone number (or set STOCK_ALERT_WHATSAPP_TO env var)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print alerts without sending to WhatsApp",
    )
    parser.add_argument(
        "--output",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text)",
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="Verbose logging to stderr",
    )
    parser.add_argument(
        "--analyst-days",
        type=int,
        default=30,
        help="Lookback days for analyst ratings (default: 30)",
    )

    args = parser.parse_args()

    # Resolve tickers
    tickers = []
    if args.watchlist:
        tickers = [t.strip() for t in args.watchlist.split(",") if t.strip()]
    elif args.sp500_top:
        tickers = SP500_TOP_50
    else:
        parser.error("Either --watchlist or --sp500-top is required")

    # Resolve WhatsApp recipient
    whatsapp_to = args.whatsapp_to or os.environ.get("STOCK_ALERT_WHATSAPP_TO")

    if not args.dry_run and not whatsapp_to:
        print("Warning: No WhatsApp recipient configured. Use --whatsapp-to or set STOCK_ALERT_WHATSAPP_TO env var.", file=sys.stderr)
        print("Running in dry-run mode.", file=sys.stderr)
        args.dry_run = True

    # Run scan
    scan_watchlist(
        tickers=tickers,
        threshold=args.threshold,
        analyst_days=args.analyst_days,
        dry_run=args.dry_run,
        whatsapp_to=whatsapp_to,
        output_format=args.output,
        verbose=args.verbose,
    )


if __name__ == "__main__":
    main()