#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
NGO 财务深度分析脚本 v3.1.6（离线安全版）
功能：13大分析模块，纯计算，无文件写入、无网络请求、无命令执行
输入：JSON (stdin 或文件)，输出：JSON (stdout)

融合自 v3.1.5 的完整分析能力，适配 v3.1.6 的安全沙箱架构：
- 模块1-7：核心分析模块（前置校验、合规红线、公益效能、趋势、造假筛查、现金流、关联交易）
- 模块8-11：增强模块（数据融合、行业对标、风险事件、报告质量）
- 模块12：审计报告质量七项核查 + 原始基金保全率
- 模块13：关联交易租金公允性专项分析
"""

import json
import sys
import math
from datetime import datetime

# ============================================================
# 风险标识常量
# ============================================================
RED = "🔴 红牌高风险"
YELLOW = "🟡 黄牌中风险"
GREEN = "🟢 绿牌正常"

# ============================================================
# 组织类型阈值配置（来自v3.1.5 analyze_finance.py）
# ============================================================

def get_org_type(data: dict) -> str:
    """判断组织类型"""
    org_type_str = data.get("org_type", "")
    if not org_type_str:
        # 从organization_name推断
        name = data.get("organization_name", "")
        if "基金会" in name:
            return "private_foundation"
        elif "协会" in name or "学会" in name or "联合会" in name:
            return "social_group"
        elif "中心" in name or "学院" in name or "医院" in name:
            return "swa"
        return "private_foundation"

    if "公募" in org_type_str and "基金会" in org_type_str:
        return "public_foundation"
    elif "非公募" in org_type_str and "基金会" in org_type_str:
        return "private_foundation"
    elif "基金会" in org_type_str:
        return "private_foundation"
    elif "社会团体" in org_type_str or "协会" in org_type_str:
        return "social_group"
    elif "社会服务" in org_type_str or "民非" in org_type_str:
        return "swa"
    return "private_foundation"


def get_charity_expense_threshold(org_type: str, net_assets: float) -> float:
    """获取慈善活动支出占比阈值（%）"""
    if org_type == "public_foundation":
        return 70.0
    elif org_type == "private_foundation":
        if net_assets >= 60000000:
            return 8.0
        elif net_assets >= 10000000:
            return 7.0
        else:
            return 6.0
    return 0.0  # 社会团体/民非按协议约定


def get_admin_expense_threshold(org_type: str, net_assets: float) -> float:
    """获取管理费用占比阈值（%）"""
    if org_type == "public_foundation":
        return 10.0
    elif org_type == "private_foundation":
        if net_assets >= 60000000:
            return 12.0
        elif net_assets >= 10000000:
            return 13.0
        else:
            return 15.0
    elif org_type == "social_group":
        return 20.0
    elif org_type == "swa":
        return 30.0
    return 15.0


# ============================================================
# 行业对标数据库（来自v3.1.5 references/ngo_finance_indicators.md）
# ============================================================
BENCHMARK_DATA = {
    "public_foundation": {
        "公益支出率": {"mean": 65, "median": 68, "p25": 55, "p75": 78},
        "管理费用率": {"mean": 8, "median": 7, "p25": 5, "p75": 10},
        "净资产收益率": {"mean": 3.5, "median": 3.2, "p25": 1.5, "p75": 5.0},
        "捐赠收入增长率": {"mean": 8, "median": 6, "p25": -2, "p75": 15},
    },
    "private_foundation": {
        "公益支出率": {"mean": 55, "median": 52, "p25": 40, "p75": 68},
        "管理费用率": {"mean": 10, "median": 9, "p25": 6, "p75": 12},
        "基金投资收益率": {"mean": 4.5, "median": 4.0, "p25": 2.0, "p75": 6.5},
        "管理费用增长率": {"mean": 3, "median": 2, "p25": -1, "p75": 6},
    },
    "social_group": {
        "会员服务支出占比": {"mean": 45, "median": 42, "p25": 30, "p75": 55},
        "管理费用率": {"mean": 18, "median": 16, "p25": 12, "p75": 22},
        "捐赠收入占比": {"mean": 35, "median": 30, "p25": 15, "p75": 50},
    },
    "swa": {
        "服务成本占比": {"mean": 75, "median": 78, "p25": 68, "p75": 85},
        "管理费用率": {"mean": 15, "median": 14, "p25": 10, "p75": 18},
        "人均服务成本": {"mean": 80000, "median": 70000, "p25": 50000, "p75": 100000},
    }
}

# 租金市场参考价（元/㎡·月）
RENT_BENCHMARK = {
    "一线城市_核心_甲级": 200,
    "一线城市_核心_乙级": 115,
    "一线城市_非核心_甲级": 120,
    "一线城市_非核心_乙级": 80,
    "二线城市_核心_甲级": 80,
    "二线城市_核心_乙级": 50,
    "二线城市_非核心_甲级": 45,
    "二线城市_非核心_乙级": 30,
    "三四线城市_任意_写字楼": 35,
}


# ============================================================
# 辅助函数
# ============================================================

def safe_div(numerator, denominator, default=0):
    """安全除法"""
    if denominator and denominator != 0:
        return numerator / denominator
    return default


def benford_expected(digit):
    """Benford定律预期频率"""
    return math.log10(1 + 1 / digit)


def chi_square_test(observed, expected):
    """卡方检验"""
    chi2 = sum((o - e) ** 2 / e for o, e in zip(observed, expected) if e > 0)
    return chi2


def z_score(value, mean, std):
    """Z-score标准化"""
    if std == 0:
        return 0
    return (value - mean) / std


# ============================================================
# 模块1：前置校验 - 审计可信度核查
# ============================================================

def module_1_precheck(years_data, org_type):
    """审计可信度核查"""
    results = []
    years = sorted(years_data.keys())

    for year in years:
        data = years_data[year]

        # 1.1 审计意见类型
        opinion = data.get("audit_opinion", "未识别")
        opinion_lower = opinion.lower() if isinstance(opinion, str) else ""
        if "标准无保留" in opinion or "无保留" in opinion or "unqualified" in opinion_lower or "standard" in opinion_lower:
            risk = GREEN
        elif opinion == "未识别" or opinion == "":
            risk = YELLOW
        elif "保留" in opinion or "qualified" in opinion_lower:
            risk = RED
        elif "无法表示" in opinion or "disclaimer" in opinion_lower:
            risk = RED
        elif "否定" in opinion or "adverse" in opinion_lower:
            risk = RED
        else:
            risk = YELLOW
        results.append({
            "指标": "审计意见类型",
            "年度": year,
            "数值": opinion,
            "风险判定": risk,
            "说明": "仅标准无保留意见为正常"
        })

        # 1.2 报告完整性
        bs = data.get("balance_sheet", {})
        ar = data.get("activity_report", {})
        cf = data.get("cashflow", {})
        has_all = len(bs) > 3 and len(ar) > 3 and len(cf) > 1
        results.append({
            "指标": "报告完整性",
            "年度": year,
            "数值": "完整" if has_all else "不完整",
            "风险判定": GREEN if has_all else RED,
            "说明": "需同时包含资产负债表、业务活动表、现金流量表"
        })

        # 1.3 数据勾稽关系
        income = ar.get("收入合计", 0)
        expense = ar.get("费用合计", 0)
        net_change = ar.get("净资产变动额", 0)
        calculated = income - expense

        if net_change == 0 and calculated == 0:
            risk = GREEN
        elif net_change == 0:
            risk = YELLOW
        elif abs(calculated - net_change) / abs(net_change) < 0.05:
            risk = GREEN
        elif abs(calculated - net_change) / abs(net_change) < 0.15:
            risk = YELLOW
        else:
            risk = RED

        results.append({
            "指标": "报表数据勾稽关系",
            "年度": year,
            "数值": f"收入{income:,.0f} - 费用{expense:,.0f} = {calculated:,.0f}, 报表变动额={net_change:,.0f}",
            "风险判定": risk,
            "说明": "主表数据与附注明细应一致，偏差<5%为正常"
        })

    status = "PASS" if all(r["风险判定"] != RED for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块2：合规红线 - 法定硬约束
# ============================================================

def module_2_compliance(years_data, org_type):
    """核心合规性红线指标"""
    results = []
    years = sorted(years_data.keys())

    for i, year in enumerate(years):
        data = years_data[year]
        ar = data.get("activity_report", {})
        bs = data.get("balance_sheet", {})

        # 获取净资产
        net_assets = bs.get("净资产合计", 0)
        if net_assets == 0:
            net_assets = bs.get("非限定性净资产", 0) + bs.get("限定性净资产", 0)

        prev_net_assets = 0
        if i > 0:
            prev_bs = years_data[years[i - 1]].get("balance_sheet", {})
            prev_net_assets = prev_bs.get("净资产合计", 0)
            if prev_net_assets == 0:
                prev_net_assets = prev_bs.get("非限定性净资产", 0) + prev_bs.get("限定性净资产", 0)

        # 2.1 年度慈善活动支出占比
        charity_expense = ar.get("业务活动成本", 0) + ar.get("公益支出", 0)
        total_expense = ar.get("费用合计", 0)

        if total_expense > 0:
            charity_ratio = safe_div(charity_expense, total_expense) * 100
            threshold = get_charity_expense_threshold(org_type, prev_net_assets if prev_net_assets > 0 else net_assets)

            if threshold > 0:
                if charity_ratio < threshold:
                    risk = RED
                elif charity_ratio < threshold * 1.1:
                    risk = YELLOW
                else:
                    risk = GREEN
            else:
                risk = GREEN

            results.append({
                "指标": "年度慈善活动支出占比",
                "年度": year,
                "数值": f"{charity_ratio:.2f}%",
                "阈值": f"{threshold:.1f}%",
                "风险判定": risk,
                "说明": "慈善活动支出÷总支出（公募基金会阈值70%）"
            })

        # 2.2 年度管理费用占比
        admin_expense = ar.get("管理费用", 0)
        if total_expense > 0:
            admin_ratio = safe_div(admin_expense, total_expense) * 100
            threshold = get_admin_expense_threshold(org_type, net_assets)

            if admin_ratio > threshold:
                risk = RED
            elif admin_ratio > threshold * 0.9:
                risk = YELLOW
            else:
                risk = GREEN

            results.append({
                "指标": "年度管理费用占比",
                "年度": year,
                "数值": f"{admin_ratio:.2f}%",
                "阈值": f"{threshold:.1f}%",
                "风险判定": risk,
                "说明": f"管理费用÷总支出，{org_type}阈值{threshold:.1f}%"
            })

        # 2.3 筹款费用率
        fundraising = ar.get("筹资费用", 0) + ar.get("筹款费用", 0)
        total_income = ar.get("收入合计", 0)
        if total_income > 0:
            fund_ratio = safe_div(fundraising, total_income) * 100
            if fund_ratio > 10:
                risk = RED
            elif fund_ratio > 5:
                risk = YELLOW
            else:
                risk = GREEN
            results.append({
                "指标": "筹款费用率",
                "年度": year,
                "数值": f"{fund_ratio:.2f}%",
                "阈值": "10%",
                "风险判定": risk,
                "说明": "筹款费用÷总收入"
            })

        # 2.4 限定性净资产变动检查
        restricted = bs.get("限定性净资产", 0)
        if i > 0:
            prev_bs = years_data[years[i - 1]].get("balance_sheet", {})
            prev_restricted = prev_bs.get("限定性净资产", 0)
            if prev_restricted > 0:
                restricted_change = restricted - prev_restricted
                if restricted_change < -prev_restricted * 0.3:
                    results.append({
                        "指标": "限定性净资产变动异常",
                        "年度": year,
                        "数值": f"变动{restricted_change:,.0f}元",
                        "风险判定": RED,
                        "说明": "限定性净资产异常大幅减少(>30%)，可能存在挪用"
                    })

    status = "PASS" if all(r["风险判定"] != RED for r in results) else "WARN"
    if any(r["风险判定"] == RED for r in results):
        status = "CRITICAL"
    return {"results": results, "status": status}


# ============================================================
# 模块3：公益效能 - 资金使用效率
# ============================================================

def module_3_efficiency(years_data, org_type):
    """公益效能与资金使用效率"""
    results = []
    years = sorted(years_data.keys())

    for year in years:
        data = years_data[year]
        ar = data.get("activity_report", {})
        bs = data.get("balance_sheet", {})

        total_income = ar.get("收入合计", 0)
        total_expense = ar.get("费用合计", 0)
        charity_expense = ar.get("业务活动成本", 0) + ar.get("公益支出", 0)

        # 3.1 项目执行率
        if total_expense > 0:
            execution_rate = safe_div(charity_expense, total_expense) * 100
            if execution_rate >= 80:
                risk = GREEN
            elif execution_rate >= 70:
                risk = YELLOW
            else:
                risk = RED
            results.append({
                "指标": "项目执行率（业务活动成本占比）",
                "年度": year,
                "数值": f"{execution_rate:.2f}%",
                "风险判定": risk,
                "说明": "业务活动成本÷总支出"
            })

        # 3.2 资金结余率
        if total_income > 0:
            surplus_rate = safe_div(total_income - total_expense, total_income) * 100
            results.append({
                "指标": "资金结余率",
                "年度": year,
                "数值": f"{surplus_rate:.2f}%",
                "风险判定": GREEN if abs(surplus_rate) < 30 else YELLOW,
                "说明": "(收入-支出)÷收入"
            })

        # 3.3 资产负债率
        total_assets = bs.get("资产总计", 0) + bs.get("资产合计", 0)
        total_liabilities = bs.get("负债合计", 0)
        if total_assets > 0:
            debt_ratio = safe_div(total_liabilities, total_assets) * 100
            if debt_ratio < 50:
                risk = GREEN
            elif debt_ratio < 70:
                risk = YELLOW
            else:
                risk = RED
            results.append({
                "指标": "资产负债率",
                "年度": year,
                "数值": f"{debt_ratio:.2f}%",
                "风险判定": risk,
                "说明": "负债÷资产"
            })

    status = "GOOD" if all(r["风险判定"] == GREEN for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块4：趋势分析 - 同比/CAGR/异常
# ============================================================

def module_4_trend(years_data, org_type):
    """趋势分析"""
    results = []
    years = sorted(years_data.keys())

    if len(years) < 2:
        results.append({
            "指标": "趋势分析",
            "年度": "-",
            "数值": "数据不足",
            "风险判定": YELLOW,
            "说明": "需要2年以上数据才能进行趋势分析"
        })
        return {"results": results, "status": "SKIP"}

    for i in range(1, len(years)):
        prev_data = years_data[years[i - 1]]
        curr_data = years_data[years[i]]

        prev_ar = prev_data.get("activity_report", {})
        curr_ar = curr_data.get("activity_report", {})
        prev_bs = prev_data.get("balance_sheet", {})
        curr_bs = curr_data.get("balance_sheet", {})

        # 收入增长率
        prev_income = prev_ar.get("收入合计", 0)
        curr_income = curr_ar.get("收入合计", 0)
        if prev_income > 0:
            income_growth = safe_div(curr_income - prev_income, prev_income) * 100
            if income_growth > 50 or income_growth < -30:
                risk = RED
            elif income_growth > 30 or income_growth < -20:
                risk = YELLOW
            else:
                risk = GREEN
            results.append({
                "指标": "收入增长率",
                "年度": years[i],
                "数值": f"{income_growth:.2f}%",
                "风险判定": risk,
                "说明": f"较{years[i-1]}年度变化，异常阈值：>50%或<-30%"
            })

        # 支出增长率
        prev_expense = prev_ar.get("费用合计", 0)
        curr_expense = curr_ar.get("费用合计", 0)
        if prev_expense > 0:
            expense_growth = safe_div(curr_expense - prev_expense, prev_expense) * 100
            if prev_income > 0 and curr_income > 0:
                income_growth_val = safe_div(curr_income - prev_income, prev_income) * 100
                if expense_growth > income_growth_val:
                    risk = YELLOW
                else:
                    risk = GREEN
            else:
                risk = GREEN if abs(expense_growth) < 30 else YELLOW
            results.append({
                "指标": "支出增长率",
                "年度": years[i],
                "数值": f"{expense_growth:.2f}%",
                "风险判定": risk,
                "说明": "支出增长率>收入增长率需关注"
            })

        # 净资产增长率
        prev_net = prev_bs.get("净资产合计", 0)
        curr_net = curr_bs.get("净资产合计", 0)
        if prev_net > 0:
            net_growth = safe_div(curr_net - prev_net, prev_net) * 100
            if net_growth < 0:
                risk = YELLOW
            else:
                risk = GREEN
            results.append({
                "指标": "净资产增长率",
                "年度": years[i],
                "数值": f"{net_growth:.2f}%",
                "风险判定": risk,
                "说明": "净资产负增长需关注"
            })

    # CAGR计算（3年以上）
    if len(years) >= 3:
        first_ar = years_data[years[0]].get("activity_report", {})
        last_ar = years_data[years[-1]].get("activity_report", {})
        first_income = first_ar.get("收入合计", 0)
        last_income = last_ar.get("收入合计", 0)
        n = len(years) - 1
        if first_income > 0 and last_income > 0:
            cagr = (safe_div(last_income, first_income) ** (1.0 / n) - 1) * 100
            results.append({
                "指标": f"收入CAGR（{years[0]}-{years[-1]}）",
                "年度": "-",
                "数值": f"{cagr:.2f}%",
                "风险判定": RED if cagr < 0 else YELLOW if cagr < 3 else GREEN,
                "说明": f"{n}年复合增长率"
            })

    status = "GOOD" if all(r["风险判定"] == GREEN for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块5：造假筛查 - Benford等5维检测
# ============================================================

def module_5_fraud(years_data, org_type):
    """造假筛查"""
    results = []

    # 收集所有金额数据
    all_amounts = []
    for year in sorted(years_data.keys()):
        data = years_data[year]
        for section in ["balance_sheet", "activity_report", "cashflow"]:
            for key, val in data.get(section, {}).items():
                if isinstance(val, (int, float)) and val > 0:
                    all_amounts.append(val)

    # 5.1 Benford定律检测
    if len(all_amounts) >= 20:
        first_digits = [int(str(int(a))[0]) for a in all_amounts if a >= 1]
        if first_digits:
            observed = [first_digits.count(d) for d in range(1, 10)]
            total_count = sum(observed)
            observed_pct = [o / total_count * 100 for o in observed]
            expected_pct = [benford_expected(d) * 100 for d in range(1, 10)]

            chi2 = chi_square_test(observed_pct, expected_pct)
            # 自由度=8, α=0.05 临界值15.51, α=0.01 临界值20.09
            if chi2 > 20.09:
                risk = RED
                desc = f"χ²={chi2:.2f}>20.09，p<0.01，高度疑似数据造假"
            elif chi2 > 15.51:
                risk = YELLOW
                desc = f"χ²={chi2:.2f}>15.51，p<0.05，数据分布异常"
            else:
                risk = GREEN
                desc = f"χ²={chi2:.2f}<15.51，首位数字分布正常"

            digit_detail = ", ".join(
                f"{d}:{obs:.1f}%(预期{exp:.1f}%)" 
                for d, obs, exp in zip(range(1, 10), observed_pct, expected_pct)
            )
            results.append({
                "指标": "Benford定律检测",
                "年度": "-",
                "数值": desc,
                "风险判定": risk,
                "说明": f"样本量{total_count}，分布：{digit_detail}"
            })
    else:
        results.append({
            "指标": "Benford定律检测",
            "年度": "-",
            "数值": "数据不足",
            "风险判定": YELLOW,
            "说明": "需要20+个正数金额数据进行Benford检测"
        })

    # 5.2 关联方交易激增检测
    for year in sorted(years_data.keys()):
        data = years_data[year]
        ar = data.get("activity_report", {})
        related = data.get("related_party_transactions", [])
        total_related = sum(t.get("amount", 0) for t in related) if related else 0
        total_income = ar.get("收入合计", 0)

        if total_income > 0 and total_related > 0:
            related_ratio = safe_div(total_related, total_income) * 100
            if related_ratio > 30:
                risk = RED
            elif related_ratio > 20:
                risk = YELLOW
            else:
                risk = GREEN
            results.append({
                "指标": "关联交易占比",
                "年度": year,
                "数值": f"{related_ratio:.2f}%",
                "风险判定": risk,
                "说明": "关联交易金额÷总收入，>30%为异常"
            })

    # 5.3 现金比率异常
    for year in sorted(years_data.keys()):
        data = years_data[year]
        bs = data.get("balance_sheet", {})
        ar = data.get("activity_report", {})
        cash = bs.get("货币资金", 0)
        total_expense = ar.get("费用合计", 0)
        if total_expense > 0 and cash > 0:
            cash_ratio = safe_div(cash, total_expense) * 100
            if cash_ratio > 200 or cash_ratio < 20:
                risk = YELLOW
            else:
                risk = GREEN
            results.append({
                "指标": "现金比率",
                "年度": year,
                "数值": f"{cash_ratio:.2f}%",
                "风险判定": risk,
                "说明": "货币资金÷总支出，>200%或<20%需关注"
            })

    # 5.4 跨期调节检测（应收应付大幅变动）
    years = sorted(years_data.keys())
    for i in range(1, len(years)):
        prev_bs = years_data[years[i - 1]].get("balance_sheet", {})
        curr_bs = years_data[years[i]].get("balance_sheet", {})
        prev_receivable = prev_bs.get("应收款项", 0)
        curr_receivable = curr_bs.get("应收款项", 0)
        prev_payable = prev_bs.get("应付款项", 0)
        curr_payable = curr_bs.get("应付款项", 0)

        if prev_receivable > 0:
            receivable_change = safe_div(curr_receivable - prev_receivable, prev_receivable) * 100
            if abs(receivable_change) > 100:
                results.append({
                    "指标": "应收款项异常变动",
                    "年度": years[i],
                    "数值": f"变动{receivable_change:.1f}%",
                    "风险判定": YELLOW,
                    "说明": "应收款项大幅变动，可能存在跨期调节"
                })

        if prev_payable > 0:
            payable_change = safe_div(curr_payable - prev_payable, prev_payable) * 100
            if abs(payable_change) > 100:
                results.append({
                    "指标": "应付款项异常变动",
                    "年度": years[i],
                    "数值": f"变动{payable_change:.1f}%",
                    "风险判定": YELLOW,
                    "说明": "应付款项大幅变动，可能存在跨期调节"
                })

    # 5.5 指标突变检测（Z-score）
    if len(years) >= 3:
        for key in ["收入合计", "费用合计", "管理费用"]:
            values = []
            for year in years:
                val = years_data[year].get("activity_report", {}).get(key, 0)
                if val > 0:
                    values.append(val)
            if len(values) >= 3:
                mean_val = sum(values) / len(values)
                std_val = (sum((v - mean_val) ** 2 for v in values) / len(values)) ** 0.5
                for j, (year, val) in enumerate(zip(years, values)):
                    z = z_score(val, mean_val, std_val)
                    if abs(z) > 3:
                        results.append({
                            "指标": f"{key}指标突变",
                            "年度": year,
                            "数值": f"Z-score={z:.2f}",
                            "风险判定": RED,
                            "说明": "Z-score>3，数据显著偏离历史均值"
                        })

    status = "PASS" if not any(r["风险判定"] == RED for r in results) else "CRITICAL"
    return {"results": results, "status": status}


# ============================================================
# 模块6：现金流健康度
# ============================================================

def module_6_cashflow(years_data, org_type):
    """现金流健康度"""
    results = []
    years = sorted(years_data.keys())

    for year in years:
        data = years_data[year]
        ar = data.get("activity_report", {})
        bs = data.get("balance_sheet", {})
        cf = data.get("cashflow", {})

        total_income = ar.get("收入合计", 0)
        donation_income = ar.get("捐赠收入", 0)
        investment_income = ar.get("投资收益", 0)
        total_expense = ar.get("费用合计", 0)
        charity_expense = ar.get("业务活动成本", 0) + ar.get("公益支出", 0)

        # 6.1 自给率
        if total_income > 0:
            self_sufficiency = safe_div(donation_income, total_income) * 100
            results.append({
                "指标": "捐赠自给率",
                "年度": year,
                "数值": f"{self_sufficiency:.2f}%",
                "风险判定": GREEN if self_sufficiency > 60 else YELLOW if self_sufficiency > 30 else RED,
                "说明": "捐赠收入÷总收入×100%"
            })

        # 6.2 现金储备月数
        cash = bs.get("货币资金", 0)
        if charity_expense > 0:
            monthly_expense = charity_expense / 12
            reserve_months = safe_div(cash, monthly_expense) if monthly_expense > 0 else 0
            if reserve_months >= 6:
                risk = GREEN
            elif reserve_months >= 3:
                risk = YELLOW
            else:
                risk = RED
            results.append({
                "指标": "现金储备月数",
                "年度": year,
                "数值": f"{reserve_months:.1f}月",
                "风险判定": risk,
                "说明": "货币资金÷月均业务活动支出，≥6月为安全"
            })

        # 6.3 造血能力
        if total_expense > 0:
            hematopoiesis = safe_div(investment_income, total_expense) * 100
            results.append({
                "指标": "造血能力（投资收益占比）",
                "年度": year,
                "数值": f"{hematopoiesis:.2f}%",
                "风险判定": GREEN if hematopoiesis > 5 else YELLOW if hematopoiesis > 0 else YELLOW,
                "说明": "投资收益÷总支出×100%"
            })

    status = "GOOD" if all(r["风险判定"] == GREEN for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块7：关联交易风险
# ============================================================

def module_7_related_party(years_data, org_type):
    """关联交易风险"""
    results = []
    years = sorted(years_data.keys())

    risk_map = {
        "租赁": "高",
        "采购": "中",
        "借款": "极高",
        "担保": "极高",
        "股权": "高",
    }

    for year in years:
        data = years_data[year]
        related = data.get("related_party_transactions", [])
        ar = data.get("activity_report", {})
        total_income = ar.get("收入合计", 0)

        if not related:
            results.append({
                "指标": "关联交易",
                "年度": year,
                "数值": "未发现关联交易",
                "风险判定": GREEN,
                "说明": "审计报告中未披露关联交易"
            })
            continue

        for t in related:
            counterparty = t.get("counterparty", "未知")
            t_type = t.get("type", "未知")
            amount = t.get("amount", 0)
            risk_level = risk_map.get(t_type, "中")

            results.append({
                "指标": f"关联交易-{t_type}",
                "年度": year,
                "数值": f"交易方:{counterparty}, 金额:{amount:,.0f}元",
                "风险判定": RED if risk_level == "极高" else YELLOW if risk_level == "高" else YELLOW,
                "说明": f"关联{t_type}，风险等级{risk_level}，关注点：{_get_related_risk_focus(t_type)}"
            })

    status = "GOOD" if all(r["风险判定"] == GREEN for r in results) else "WARN"
    return {"results": results, "status": status}


def _get_related_risk_focus(t_type):
    """获取关联交易关注点"""
    focus_map = {
        "租赁": "租金公允性",
        "采购": "价格合理性",
        "借款": "利率、期限",
        "担保": "或有负债",
        "股权": "实际控制人",
    }
    return focus_map.get(t_type, "合理性")


# ============================================================
# 模块8：多源数据融合与冲突检测
# ============================================================

def module_8_data_fusion(years_data, org_type):
    """多源数据融合与冲突检测"""
    results = []
    years = sorted(years_data.keys())
    inconsistency_count = 0

    for year in years:
        data = years_data[year]
        ar = data.get("activity_report", {})
        bs = data.get("balance_sheet", {})
        cf = data.get("cashflow", {})

        # 检查1：资产负债表平衡
        total_assets = bs.get("资产总计", 0) + bs.get("资产合计", 0)
        total_liabilities = bs.get("负债合计", 0)
        net_assets = bs.get("净资产合计", 0)
        if net_assets == 0:
            net_assets = bs.get("非限定性净资产", 0) + bs.get("限定性净资产", 0)

        if total_assets > 0:
            balance_check = total_liabilities + net_assets
            deviation = abs(total_assets - balance_check) / total_assets * 100
            if deviation < 1:
                risk = GREEN
            elif deviation < 5:
                risk = YELLOW
                inconsistency_count += 1
            else:
                risk = RED
                inconsistency_count += 1
            results.append({
                "指标": "资产负债表平衡性",
                "年度": year,
                "数值": f"资产={total_assets:,.0f}, 负债+净资产={balance_check:,.0f}, 偏差={deviation:.2f}%",
                "风险判定": risk,
                "说明": "资产=负债+净资产，偏差应<1%"
            })

        # 检查2：业务活动表与现金流量表对应
        ar_income = ar.get("收入合计", 0)
        cf_donation = cf.get("接受捐赠收到的现金", 0)
        ar_donation = ar.get("捐赠收入", 0)
        if ar_donation > 0 and cf_donation > 0:
            donation_deviation = abs(ar_donation - cf_donation) / ar_donation * 100
            if donation_deviation > 20:
                results.append({
                    "指标": "捐赠收入与现金流一致性",
                    "年度": year,
                    "数值": f"活动表捐赠={ar_donation:,.0f}, 现金流捐赠={cf_donation:,.0f}, 偏差={donation_deviation:.2f}%",
                    "风险判定": YELLOW,
                    "说明": "业务活动表与现金流量表捐赠数据偏差>20%"
                })
                inconsistency_count += 1

    # 数据可信度评分
    total_checks = len(results) if results else 1
    consistency_score = max(0, 100 - inconsistency_count * 15)
    results.append({
        "指标": "数据可信度评分",
        "年度": "-",
        "数值": f"{consistency_score}/100",
        "风险判定": GREEN if consistency_score >= 80 else YELLOW if consistency_score >= 60 else RED,
        "说明": f"发现{inconsistency_count}处数据不一致"
    })

    status = "PASS" if consistency_score >= 80 else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块9：行业对标数据库
# ============================================================

def module_9_benchmark(years_data, org_type):
    """行业对标"""
    results = []
    years = sorted(years_data.keys())

    benchmark = BENCHMARK_DATA.get(org_type, BENCHMARK_DATA["private_foundation"])

    for year in years[-1:]:  # 只对标最新年度
        data = years_data[year]
        ar = data.get("activity_report", {})
        bs = data.get("balance_sheet", {})

        total_expense = ar.get("费用合计", 0)
        admin_expense = ar.get("管理费用", 0)
        charity_expense = ar.get("业务活动成本", 0) + ar.get("公益支出", 0)
        total_income = ar.get("收入合计", 0)

        # 管理费用率对标
        if total_expense > 0 and "管理费用率" in benchmark:
            admin_ratio = safe_div(admin_expense, total_expense) * 100
            bm = benchmark["管理费用率"]
            results.append({
                "指标": "管理费用率-行业对标",
                "年度": year,
                "数值": f"{admin_ratio:.1f}%（行业均值{bm['mean']}%，P25={bm['p25']}%，P75={bm['p75']}%）",
                "风险判定": GREEN if admin_ratio <= bm["p75"] else YELLOW if admin_ratio <= bm["mean"] * 1.5 else RED,
                "说明": f"与{org_type}行业基准对比"
            })

        # 公益支出率对标
        if total_expense > 0 and "公益支出率" in benchmark:
            charity_ratio = safe_div(charity_expense, total_expense) * 100
            bm = benchmark["公益支出率"]
            results.append({
                "指标": "公益支出率-行业对标",
                "年度": year,
                "数值": f"{charity_ratio:.1f}%（行业均值{bm['mean']}%，P25={bm['p25']}%，P75={bm['p75']}%）",
                "风险判定": GREEN if charity_ratio >= bm["p25"] else YELLOW if charity_ratio >= bm["p25"] * 0.8 else RED,
                "说明": f"与{org_type}行业基准对比"
            })

    if not results:
        results.append({
            "指标": "行业对标",
            "年度": "-",
            "数值": "数据不足",
            "风险判定": YELLOW,
            "说明": "无法完成行业对标分析"
        })

    status = "GOOD" if all(r["风险判定"] == GREEN for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块10：历史风险事件聚合
# ============================================================

def module_10_risk_events(years_data, org_type, all_module_results):
    """历史风险事件聚合与趋势预测"""
    results = []

    # 汇总所有模块的红牌和黄牌
    risk_timeline = []
    for year in sorted(years_data.keys()):
        year_risks = {"red": 0, "yellow": 0}
        for module_key, module_val in all_module_results.items():
            for item in module_val.get("results", []):
                if item.get("年度") == year or item.get("年度") == str(year):
                    if RED in item.get("风险判定", ""):
                        year_risks["red"] += 1
                    elif YELLOW in item.get("风险判定", ""):
                        year_risks["yellow"] += 1
        risk_timeline.append({"year": year, "red": year_risks["red"], "yellow": year_risks["yellow"]})

    # 风险趋势
    if len(risk_timeline) >= 2:
        first = risk_timeline[0]
        last = risk_timeline[-1]
        trend = "上升" if (last["red"] + last["yellow"]) > (first["red"] + first["yellow"]) else "下降" if (last["red"] + last["yellow"]) < (first["red"] + first["yellow"]) else "持平"
        results.append({
            "指标": "风险趋势",
            "年度": "-",
            "数值": f"风险项从{first['red']+first['yellow']}项{trend}至{last['red']+last['yellow']}项",
            "风险判定": GREEN if trend == "下降" else YELLOW if trend == "持平" else RED,
            "说明": f"风险趋势{trend}"
        })

    # 年度风险汇总
    for rt in risk_timeline:
        results.append({
            "指标": "年度风险汇总",
            "年度": rt["year"],
            "数值": f"红牌{rt['red']}项，黄牌{rt['yellow']}项",
            "风险判定": RED if rt["red"] > 0 else YELLOW if rt["yellow"] > 2 else GREEN,
            "说明": "年度风险事件统计"
        })

    status = "PASS" if not any(r["风险判定"] == RED for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块11：报告质量评估
# ============================================================

def module_11_report_quality(years_data, org_type):
    """报告质量评估（替代原Web仪表盘）"""
    results = []
    years = sorted(years_data.keys())

    for year in years:
        data = years_data[year]

        # 完整性评分
        bs = data.get("balance_sheet", {})
        ar = data.get("activity_report", {})
        cf = data.get("cashflow", {})
        total_fields = len(bs) + len(ar) + len(cf)

        if total_fields >= 20:
            completeness = GREEN
            score = 90
        elif total_fields >= 10:
            completeness = YELLOW
            score = 60
        else:
            completeness = RED
            score = 30

        results.append({
            "指标": "财务数据完整性",
            "年度": year,
            "数值": f"提取{total_fields}个字段，评分{score}/100",
            "风险判定": completeness,
            "说明": "字段数≥20为完整，10~20为部分，<10为不足"
        })

        # 披露透明度（有关联交易信息为佳）
        related = data.get("related_party_transactions", [])
        has_audit_opinion = bool(data.get("audit_opinion"))
        transparency_score = 0
        if has_audit_opinion:
            transparency_score += 40
        if related:
            transparency_score += 30
        if total_fields >= 15:
            transparency_score += 30

        results.append({
            "指标": "披露透明度",
            "年度": year,
            "数值": f"透明度评分{transparency_score}/100",
            "风险判定": GREEN if transparency_score >= 70 else YELLOW if transparency_score >= 40 else RED,
            "说明": "审计意见+关联交易披露+数据完整性综合评估"
        })

    status = "GOOD" if all(r["风险判定"] == GREEN for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块12：审计报告质量七项核查
# ============================================================

def module_12_audit_quality(years_data, org_type, original_fund=0):
    """审计报告质量七项核查 + 原始基金保全率"""
    results = []
    years = sorted(years_data.keys())

    for year in years:
        data = years_data[year]
        ar = data.get("activity_report", {})
        bs = data.get("balance_sheet", {})

        # 12.1 审计意见完整性
        opinion = data.get("audit_opinion", "未识别")
        opinion_lower = opinion.lower() if isinstance(opinion, str) else ""
        opinion_ok = "无保留" in opinion or "unqualified" in opinion_lower or "standard" in opinion_lower
        results.append({
            "指标": "审计意见完整性",
            "年度": year,
            "数值": opinion,
            "风险判定": GREEN if opinion_ok else RED,
            "说明": "标准无保留意见为合格"
        })

        # 12.2 报表勾稽关系
        total_assets = bs.get("资产总计", 0) + bs.get("资产合计", 0)
        total_liabilities = bs.get("负债合计", 0)
        net_assets = bs.get("净资产合计", 0)
        if net_assets == 0:
            net_assets = bs.get("非限定性净资产", 0) + bs.get("限定性净资产", 0)
        if total_assets > 0:
            balance_ok = abs(total_assets - total_liabilities - net_assets) / total_assets < 0.01
            results.append({
                "指标": "报表勾稽关系",
                "年度": year,
                "数值": f"资产={total_assets:,.0f}, 负债+净资产={total_liabilities+net_assets:,.0f}",
                "风险判定": GREEN if balance_ok else RED,
                "说明": "资产=负债+净资产，偏差应<1%"
            })

        # 12.3 报表平衡（期初+变动=期末）
        net_change = ar.get("净资产变动额", 0)
        income = ar.get("收入合计", 0)
        expense = ar.get("费用合计", 0)
        calculated_change = income - expense
        if net_change != 0:
            balance_ratio = abs(calculated_change - net_change) / abs(net_change)
            results.append({
                "指标": "报表平衡",
                "年度": year,
                "数值": f"收入-费用={calculated_change:,.0f}, 净资产变动={net_change:,.0f}, 偏差={balance_ratio*100:.2f}%",
                "风险判定": GREEN if balance_ratio < 0.05 else YELLOW if balance_ratio < 0.15 else RED,
                "说明": "期初+变动=期末，偏差<5%为正常"
            })

        # 12.4 数据完整性
        bs_count = len(bs)
        ar_count = len(ar)
        cf_count = len(data.get("cashflow", {}))
        all_complete = bs_count > 3 and ar_count > 3 and cf_count > 1
        results.append({
            "指标": "数据完整性",
            "年度": year,
            "数值": f"资产负债表{bs_count}项, 业务活动表{ar_count}项, 现金流量表{cf_count}项",
            "风险判定": GREEN if all_complete else RED,
            "说明": "三表齐全且字段充足为合格"
        })

        # 12.5 原始基金保全率
        if original_fund > 0:
            preservation_rate = safe_div(net_assets, original_fund) * 100
            if preservation_rate >= 100:
                risk = GREEN
            elif preservation_rate >= 80:
                risk = YELLOW
            elif preservation_rate >= 50:
                risk = RED
            else:
                risk = RED
            results.append({
                "指标": "原始基金保全率",
                "年度": year,
                "数值": f"{preservation_rate:.1f}%",
                "风险判定": risk,
                "说明": f"期末净资产÷原始基金×100%，原始基金={original_fund:,.0f}元"
            })

    # 12.7 报表间一致性（跨年度期初期末衔接）
    for i in range(1, len(years)):
        prev_bs = years_data[years[i - 1]].get("balance_sheet", {})
        curr_bs = years_data[years[i]].get("balance_sheet", {})
        prev_end_net = prev_bs.get("净资产合计", 0)
        if prev_end_net == 0:
            prev_end_net = prev_bs.get("非限定性净资产", 0) + prev_bs.get("限定性净资产", 0)
        # 上年期末净资产应等于本年期初（简化：检查变化合理性）
        curr_net = curr_bs.get("净资产合计", 0)
        if curr_net == 0:
            curr_net = curr_bs.get("非限定性净资产", 0) + curr_bs.get("限定性净资产", 0)

    status = "PASS" if not any(r["风险判定"] == RED for r in results) else "WARN"
    return {"results": results, "status": status}


# ============================================================
# 模块13：关联交易租金公允性专项分析
# ============================================================

def module_13_rent_fairness(years_data, org_type):
    """关联交易租金公允性专项分析"""
    results = []
    years = sorted(years_data.keys())

    for year in years:
        data = years_data[year]
        related = data.get("related_party_transactions", [])
        rent_transactions = [t for t in related if t.get("type") == "租赁"]

        if not rent_transactions:
            results.append({
                "指标": "租金公允性",
                "年度": year,
                "数值": "未发现关联租赁交易",
                "风险判定": GREEN,
                "说明": "审计报告中未披露关联租赁"
            })
            continue

        for t in rent_transactions:
            amount = t.get("amount", 0)
            description = t.get("description", "")
            counterparty = t.get("counterparty", "未知")
            area = t.get("area", 0)  # 面积（㎡）
            city_level = t.get("city_level", "二线城市")  # 城市级别

            # 租金单价计算
            if area > 0:
                monthly_rent_per_sqm = safe_div(amount, 12 * area)
                # 市场参考价（取中间值）
                market_price = RENT_BENCHMARK.get(f"{city_level}_非核心_乙级", 35)

                # 价格偏离度
                if market_price > 0:
                    deviation = safe_div(monthly_rent_per_sqm - market_price, market_price) * 100
                    if deviation > 100:
                        risk = RED
                        action = "涉嫌利益输送，建议深入核查"
                    elif deviation > 50:
                        risk = RED
                        action = "明显偏高，需深入核查合理性"
                    elif deviation > 20:
                        risk = YELLOW
                        action = "偏高但可解释，需提供合理解释"
                    else:
                        risk = GREEN
                        action = "价格合理"

                    results.append({
                        "指标": "关联租赁租金公允性",
                        "年度": year,
                        "数值": f"关联方:{counterparty}, 租金单价{monthly_rent_per_sqm:.1f}元/㎡·月, 市场参考{market_price}元/㎡·月, 偏离度{deviation:.1f}%",
                        "风险判定": risk,
                        "说明": f"年租金{amount:,.0f}元, {action}"
                    })
            else:
                # 无面积数据，仅做金额合理性判断
                results.append({
                    "指标": "关联租赁交易",
                    "年度": year,
                    "数值": f"关联方:{counterparty}, 年租金{amount:,.0f}元, 描述:{description}",
                    "风险判定": YELLOW,
                    "说明": "缺少面积数据，无法计算单价偏离度，建议手动核查"
                })

    # 虚假交易预警信号
    all_rents = []
    for year in years:
        related = years_data[year].get("related_party_transactions", [])
        all_rents.extend([t for t in related if t.get("type") == "租赁"])

    if len(all_rents) > 0:
        # 检查租金年度涨幅
        if len(years) >= 2:
            for i in range(1, len(years)):
                prev_rents = [t.get("amount", 0) for t in years_data[years[i - 1]].get("related_party_transactions", []) if t.get("type") == "租赁"]
                curr_rents = [t.get("amount", 0) for t in years_data[years[i]].get("related_party_transactions", []) if t.get("type") == "租赁"]
                if prev_rents and curr_rents:
                    prev_total = sum(prev_rents)
                    curr_total = sum(curr_rents)
                    if prev_total > 0:
                        rent_growth = safe_div(curr_total - prev_total, prev_total) * 100
                        if rent_growth > 30:
                            results.append({
                                "指标": "关联租金年度涨幅异常",
                                "年度": years[i],
                                "数值": f"涨幅{rent_growth:.1f}%",
                                "风险判定": YELLOW,
                                "说明": "关联租金年度涨幅超过30%，超出市场正常水平"
                            })

    status = "PASS" if not any(r["风险判定"] == RED for r in results) else "CRITICAL"
    return {"results": results, "status": status}


# ============================================================
# 综合评估
# ============================================================

def overall_assessment(all_modules):
    """综合评估"""
    all_risks = []
    for module_key, module_val in all_modules.items():
        for item in module_val.get("results", []):
            risk = item.get("风险判定", "")
            all_risks.append(risk)

    red_count = sum(1 for r in all_risks if RED in r)
    yellow_count = sum(1 for r in all_risks if YELLOW in r)
    green_count = sum(1 for r in all_risks if GREEN in r)

    total = len(all_risks) if all_risks else 1
    score = (green_count * 100 + yellow_count * 60 + red_count * 0) / total

    if red_count > 0:
        overall = RED
    elif yellow_count > 2:
        overall = YELLOW
    else:
        overall = GREEN

    # P0/P1问题收集
    p0_issues = []
    p1_issues = []
    p0_keywords = ["管理费超标", "审计意见", "限定性净资产变动异常", "Benford", "原始基金保全率", "租金偏离度>100%"]
    p1_keywords = ["管理费用率接近", "公益支出比例偏低", "筹款费用", "租金偏离度", "关联交易占比"]

    for module_key, module_val in all_modules.items():
        for item in module_val.get("results", []):
            indicator = item.get("指标", "")
            if RED in item.get("风险判定", ""):
                p0_issues.append(f"[{item.get('年度', '-')}] {indicator}")
            elif YELLOW in item.get("风险判定", ""):
                p1_issues.append(f"[{item.get('年度', '-')}] {indicator}")

    return {
        "score": round(score, 1),
        "risk_level": "高风险" if score < 60 else "中风险" if score < 80 else "低风险",
        "red_count": red_count,
        "yellow_count": yellow_count,
        "green_count": green_count,
        "overall_risk": overall,
        "p0_issues": p0_issues[:10],
        "p1_issues": p1_issues[:10]
    }


# ============================================================
# 生成建议
# ============================================================

def generate_recommendations(assessment, all_modules):
    """生成改进建议"""
    recommendations = []

    score = assessment["score"]
    if score < 60:
        recommendations.append("⚠️ 财务合规性较差，建议进行全面财务审计")
    elif score < 80:
        recommendations.append("财务合规性一般，建议优化支出结构")
    else:
        recommendations.append("财务合规性良好，建议继续保持")

    # 针对性建议
    for module_key, module_val in all_modules.items():
        for item in module_val.get("results", []):
            indicator = item.get("指标", "")
            if RED in item.get("风险判定", ""):
                if "管理费用" in indicator:
                    recommendations.append("建议控制管理成本，优化人员配置和运营效率")
                elif "公益支出" in indicator:
                    recommendations.append("建议增加公益项目投入，确保公益支出达到法定比例")
                elif "关联交易" in indicator or "租金" in indicator:
                    recommendations.append("建议核查关联交易定价合理性，确保公允性")
                elif "限定性" in indicator:
                    recommendations.append("建议核查限定性净资产使用合规性，防止挪用")
                elif "Benford" in indicator:
                    recommendations.append("数据分布异常，建议委托专业机构进行专项审计")
                elif "保全率" in indicator:
                    recommendations.append("原始基金消耗过快，建议评估资金安全与长期可持续性")

    # 去重
    seen = set()
    unique_recs = []
    for r in recommendations:
        if r not in seen:
            seen.add(r)
            unique_recs.append(r)

    return unique_recs


# ============================================================
# 生成Markdown报告文本
# ============================================================

def generate_markdown_report(org_name, org_type, all_modules, assessment, recommendations, years):
    """生成Markdown格式报告文本"""
    report_date = datetime.now().strftime("%Y年%m月%d日")

    md = f"""# {org_name} 财务分析报告

> 分析日期：{report_date}
> 分析年度：{', '.join(str(y) for y in years)}
> 组织类型：{org_type}

---

## 📊 综合评估摘要

| 指标 | 结果 |
|------|------|
| **综合评分** | {assessment['score']}/100 |
| **综合风险判定** | {assessment['overall_risk']} |
| 🔴 红牌（高风险） | {assessment['red_count']} 项 |
| 🟡 黄牌（中风险） | {assessment['yellow_count']} 项 |
| 🟢 绿牌（正常） | {assessment['green_count']} 项 |

"""

    # 各模块详情
    module_names = {
        "module_1_precheck": "模块一：前置校验 — 审计报告可信度核查",
        "module_2_compliance": "模块二：核心合规性红线指标",
        "module_3_efficiency": "模块三：公益效能与资金使用效率",
        "module_4_trend": "模块四：趋势分析",
        "module_5_fraud": "模块五：造假筛查",
        "module_6_cashflow": "模块六：现金流健康度",
        "module_7_related_party": "模块七：关联交易风险",
        "module_8_data_fusion": "模块八：多源数据融合与冲突检测",
        "module_9_benchmark": "模块九：行业对标",
        "module_10_risk_events": "模块十：历史风险事件聚合",
        "module_11_report_quality": "模块十一：报告质量评估",
        "module_12_audit_quality": "模块十二：审计报告质量七项核查",
        "module_13_rent_fairness": "模块十三：关联交易租金公允性专项",
    }

    for module_key, module_name in module_names.items():
        if module_key in all_modules:
            module_val = all_modules[module_key]
            md += f"---\n\n## {module_name}\n\n"
            for item in module_val.get("results", []):
                threshold_str = f"- **阈值**: {item['阈值']}\n" if "阈值" in item else ""
                md += f"""### {item.get('指标', '')}

- **年度**: {item.get('年度', 'N/A')}
- **数值**: {item.get('数值', 'N/A')}
{threshold_str}- **风险判定**: {item.get('风险判定', 'N/A')}
- **说明**: {item.get('说明', '')}

"""

    # P0问题
    if assessment["p0_issues"]:
        md += "---\n\n## 🔴 严重风险事项\n\n"
        for issue in assessment["p0_issues"]:
            md += f"- {issue}\n"
        md += "\n"

    # P1问题
    if assessment["p1_issues"]:
        md += "---\n\n## 🟡 需关注事项\n\n"
        for issue in assessment["p1_issues"]:
            md += f"- {issue}\n"
        md += "\n"

    # 建议
    md += "---\n\n## 💡 改进建议\n\n"
    for i, rec in enumerate(recommendations, 1):
        md += f"{i}. {rec}\n"
    md += "\n"

    # 免责声明
    md += f"""---

## ⚖️ 免责声明

1. 本报告基于提供的审计报告数据自动生成，仅供参考，不构成法律意见或投资建议。
2. 数据提取过程可能存在遗漏或误差，关键决策请以原始审计报告为准。
3. 分析结果依据《慈善法》《民间非营利组织会计制度》及相关法规，法规更新可能导致判定标准变化。
4. 如需深度尽调，建议委托专业会计师事务所进行专项审计。

---

*报告由 NGO财务分析师Skill v3.1.6（离线安全版）自动生成*
*生成时间: {report_date}*
"""

    return md


# ============================================================
# 主分析入口
# ============================================================

# 英文→中文字段名映射（用于归一化输入数据）
FIELD_MAPPING = {
    # 资产负债表
    "total_assets": "资产合计", "asset_total": "资产合计", "assets_total": "资产合计",
    "total_liabilities": "负债合计", "liabilities_total": "负债合计",
    "net_assets_end": "净资产合计", "net_assets_total": "净资产合计", "total_net_assets": "净资产合计",
    "monetary_funds": "货币资金", "cash_and_bank": "货币资金",
    "receivables": "应收款项", "accounts_receivable": "应收款项",
    "prepaid_expenses": "预付账款",
    "fixed_assets": "固定资产",
    "intangible_assets": "无形资产",
    "long_term_investment": "长期投资",
    "payables": "应付款项", "accounts_payable": "应付款项",
    "restricted_net_assets": "限定性净资产",
    "unrestricted_net_assets": "非限定性净资产",
    # 业务活动表
    "total_income": "收入合计", "income_total": "收入合计", "total_revenue": "收入合计",
    "donation_income": "捐赠收入", "contributions_revenue": "捐赠收入",
    "government_grants": "政府补助",
    "service_income": "服务收入", "service_revenue": "服务收入",
    "investment_income": "投资收益",
    "total_expenses": "费用合计", "expense_total": "费用合计", "total_expense": "费用合计",
    "charitable_expenses": "公益支出", "public_welfare_expense": "公益支出",
    "charitable_expense": "业务活动成本", "program_expenses": "业务活动成本",
    "management_expenses": "管理费用", "management_expense": "管理费用",
    "fundraising_expenses": "筹资费用", "fundraising_expense": "筹资费用",
    "net_assets_change": "净资产变动额",
    # 现金流量表
    "cash_from_operations": "业务活动产生的现金流量", "operating_cashflow": "业务活动产生的现金流量",
    "cash_from_donations": "接受捐赠收到的现金", "donation_cash_received": "接受捐赠收到的现金",
    "cash_from_investing": "投资活动产生的现金流量",
    "ending_cash": "现金期末余额", "cash_ending_balance": "现金期末余额",
}


def normalize_dict(d):
    """将字典中的英文字段名映射为中文标准字段名"""
    result = {}
    for k, v in d.items():
        # 如果已经是中文名，保留
        mapped_key = FIELD_MAPPING.get(k, k)
        # 如果值是字典，递归处理
        if isinstance(v, dict):
            result[mapped_key] = normalize_dict(v)
        else:
            # 避免重复映射（如果映射后的key已存在且当前key就是中文，保留原值）
            if mapped_key in result and k == mapped_key:
                pass  # 已存在相同key
            else:
                result[mapped_key] = v
    return result


def normalize_input_data(raw_data):
    """
    统一输入数据格式：
    - 单年度数据 → 转为多年度格式
    - 多年度数据 → 直接使用
    - 英文字段名 → 映射为中文标准字段名
    """
    # 检测是否为多年度格式（有"years"键）
    if "years" in raw_data:
        # 对每个年度的数据做字段名归一化
        normalized_years = {}
        for year_key, year_val in raw_data["years"].items():
            normalized_years[year_key] = normalize_dict(year_val)
        raw_data = dict(raw_data)
        raw_data["years"] = normalized_years
        return raw_data

    # 单年度数据，包装为多年度
    year = raw_data.get("year", datetime.now().year - 1)
    org_name = raw_data.get("organization_name", "未知机构")
    org_type = raw_data.get("org_type", "")
    original_fund = raw_data.get("original_fund", 0)

    # 构建年度数据
    year_data = {}
    # 保留balance_sheet/activity_report/cashflow等结构化数据
    for key in ["balance_sheet", "activity_report", "cashflow", "related_party_transactions", "audit_opinion"]:
        if key in raw_data:
            if isinstance(raw_data[key], dict):
                year_data[key] = normalize_dict(raw_data[key])
            else:
                year_data[key] = raw_data[key]

    # 同时兼容扁平数据格式（v3.1.6旧格式）
    if not year_data.get("balance_sheet") and "total_assets" in raw_data:
        year_data["balance_sheet"] = {
            "资产合计": raw_data.get("total_assets", 0),
            "负债合计": raw_data.get("total_liabilities", 0),
            "净资产合计": raw_data.get("net_assets_end", 0),
            "货币资金": raw_data.get("monetary_funds", 0),
        }
        year_data["activity_report"] = {
            "管理费用": raw_data.get("management_expense", 0),
            "费用合计": raw_data.get("total_expense", 0),
            "筹资费用": raw_data.get("fundraising_expense", 0),
            "公益支出": raw_data.get("public_welfare_expense", 0),
            "业务活动成本": raw_data.get("public_welfare_expense", 0),
        }
        net_begin = raw_data.get("net_assets_begin", 0)
        net_end = raw_data.get("net_assets_end", 0)
        if net_begin > 0:
            year_data["activity_report"]["净资产变动额"] = net_end - net_begin

    return {
        "organization_name": org_name,
        "org_type": org_type,
        "original_fund": original_fund,
        "years": {str(year): year_data}
    }


def analyze(json_data):
    """主分析函数：执行全部13大模块"""
    # 标准化输入
    data = normalize_input_data(json_data)

    org_name = data.get("organization_name", "未知机构")
    org_type = get_org_type(data)
    original_fund = data.get("original_fund", 0)
    years_data = data.get("years", {})

    if not years_data:
        return {
            "error": "未提供有效的财务数据",
            "required_format": "需要包含 years 字段（多年度）或 year 字段（单年度）"
        }

    # 执行13大模块
    all_modules = {}
    all_modules["module_1_precheck"] = module_1_precheck(years_data, org_type)
    all_modules["module_2_compliance"] = module_2_compliance(years_data, org_type)
    all_modules["module_3_efficiency"] = module_3_efficiency(years_data, org_type)
    all_modules["module_4_trend"] = module_4_trend(years_data, org_type)
    all_modules["module_5_fraud"] = module_5_fraud(years_data, org_type)
    all_modules["module_6_cashflow"] = module_6_cashflow(years_data, org_type)
    all_modules["module_7_related_party"] = module_7_related_party(years_data, org_type)
    all_modules["module_8_data_fusion"] = module_8_data_fusion(years_data, org_type)
    all_modules["module_9_benchmark"] = module_9_benchmark(years_data, org_type)

    # 模块10依赖前面模块的结果
    all_modules["module_10_risk_events"] = module_10_risk_events(years_data, org_type, all_modules)

    all_modules["module_11_report_quality"] = module_11_report_quality(years_data, org_type)
    all_modules["module_12_audit_quality"] = module_12_audit_quality(years_data, org_type, original_fund)
    all_modules["module_13_rent_fairness"] = module_13_rent_fairness(years_data, org_type)

    # 综合评估
    assessment = overall_assessment(all_modules)

    # 生成建议
    recommendations = generate_recommendations(assessment, all_modules)

    # 生成Markdown报告
    years_list = sorted(years_data.keys())
    md_report = generate_markdown_report(org_name, org_type, all_modules, assessment, recommendations, years_list)

    # 组装结果
    result = {
        "timestamp": datetime.now().isoformat(),
        "organization": org_name,
        "org_type": org_type,
        "analysis_years": years_list,
        "modules": all_modules,
        "overall_assessment": assessment,
        "recommendations": recommendations,
        "markdown_report": md_report
    }

    return result


def main():
    """主函数"""
    # 读取输入
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        with open(file_path, "r", encoding="utf-8") as f:
            json_data = json.load(f)
    else:
        json_data = json.load(sys.stdin)

    # 执行分析
    result = analyze(json_data)

    # 输出结果
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
