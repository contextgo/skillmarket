#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
PDF 财务数据提取脚本（离线安全版 v3.1.6增强）
功能：从 PDF 提取60+字段财务数据，输出结构化 JSON 到 stdout
输入：PDF 文件路径（命令行参数）
输出：JSON（stdout）

增强说明（v3.1.6）：
- 支持资产负债表10+字段提取
- 支持业务活动表10+字段提取
- 支持现金流量表5+字段提取
- 支持关联交易信息提取
- 支持审计意见类型提取
- 兼容旧版扁平格式输出
"""

import json
import sys
import re


def extract_text_from_pdf(pdf_path):
    """提取 PDF 文本内容"""
    try:
        import pdfplumber
        with pdfplumber.open(pdf_path) as pdf:
            text = ""
            for page in pdf.pages:
                page_text = page.extract_text()
                if page_text:
                    text += page_text + "\n"
            return text
    except ImportError:
        return json.dumps({
            "error": "缺少 pdfplumber 库，请运行: pip install pdfplumber"
        }, ensure_ascii=False)


def extract_amount(text, *patterns):
    """从文本中提取金额（支持多个正则模式依次尝试）"""
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            try:
                return float(match.group(1).replace(",", "").replace("，", "").replace(" ", ""))
            except (ValueError, IndexError):
                continue
    return 0


def parse_balance_sheet(text):
    """解析资产负债表（10+字段）"""
    bs = {}

    # 资产端
    bs["货币资金"] = extract_amount(text,
        r"(?:货币资金|现金及银行存款|Cash\s*and\s*Bank)\D*?([\d,]+\.?\d*)",
    )
    bs["应收款项"] = extract_amount(text,
        r"(?:应收款项|应收账款|应收票据|Accounts?\s*Receivable)\D*?([\d,]+\.?\d*)",
    )
    bs["预付账款"] = extract_amount(text,
        r"(?:预付账款|预付款项|Prepaid\s*Expenses?)\D*?([\d,]+\.?\d*)",
    )
    bs["固定资产"] = extract_amount(text,
        r"(?:固定资产净值|固定资产|Fixed\s*Assets?)\D*?([\d,]+\.?\d*)",
    )
    bs["无形资产"] = extract_amount(text,
        r"(?:无形资产|Intangible\s*Assets?)\D*?([\d,]+\.?\d*)",
    )
    bs["长期投资"] = extract_amount(text,
        r"(?:长期投资|长期股权投资|Long[- ]term\s*Investment)\D*?([\d,]+\.?\d*)",
    )

    # 资产合计
    bs["资产合计"] = extract_amount(text,
        r"(?:资产总计|资产合计|Total\s*Assets)\D*?([\d,]+\.?\d*)",
    )

    # 负债端
    bs["应付款项"] = extract_amount(text,
        r"(?:应付款项|应付账款|Accounts?\s*Payable)\D*?([\d,]+\.?\d*)",
    )
    bs["预收账款"] = extract_amount(text,
        r"(?:预收账款|预收款项|Deferred\s*Revenue)\D*?([\d,]+\.?\d*)",
    )
    bs["负债合计"] = extract_amount(text,
        r"(?:负债合计|负债总计|Total\s*Liabilities)\D*?([\d,]+\.?\d*)",
    )

    # 净资产端
    bs["限定性净资产"] = extract_amount(text,
        r"(?:限定性净资产|Restricted\s*Net\s*Assets?)\D*?([\d,]+\.?\d*)",
    )
    bs["非限定性净资产"] = extract_amount(text,
        r"(?:非限定性净资产|Unrestricted\s*Net\s*Assets?)\D*?([\d,]+\.?\d*)",
    )
    bs["净资产合计"] = extract_amount(text,
        r"(?:净资产合计|净资产总计|Total\s*Net\s*Assets?)\D*?([\d,]+\.?\d*)",
    )

    # 过滤掉0值字段（可能是未匹配到）
    bs = {k: v for k, v in bs.items() if v != 0}

    return bs


def parse_activity_report(text):
    """解析业务活动表（10+字段）"""
    ar = {}

    # 收入端
    ar["捐赠收入"] = extract_amount(text,
        r"(?:捐赠收入|Donation\s*Income|Contributions?\s*Revenue)\D*?([\d,]+\.?\d*)",
    )
    ar["政府补助"] = extract_amount(text,
        r"(?:政府补助|Government\s*Grants?)\D*?([\d,]+\.?\d*)",
    )
    ar["服务收入"] = extract_amount(text,
        r"(?:提供服务收入|服务收入|Service\s*Revenue)\D*?([\d,]+\.?\d*)",
    )
    ar["投资收益"] = extract_amount(text,
        r"(?:投资收益|Investment\s*Income)\D*?([\d,]+\.?\d*)",
    )
    ar["收入合计"] = extract_amount(text,
        r"(?:收入合计|收入总计|Total\s*Income|Total\s*Revenue)\D*?([\d,]+\.?\d*)",
    )

    # 支出端
    ar["业务活动成本"] = extract_amount(text,
        r"(?:业务活动成本|业务活动支出|项目支出|Program\s*Expenses?)\D*?([\d,]+\.?\d*)",
    )
    ar["公益支出"] = extract_amount(text,
        r"(?:公益支出|慈善支出|Charitable\s*Expenses?|Public\s*Welfare\s*Expenses?)\D*?([\d,]+\.?\d*)",
    )
    ar["管理费用"] = extract_amount(text,
        r"(?:管理费用|Management\s*Expenses?)\D*?([\d,]+\.?\d*)",
    )
    ar["筹资费用"] = extract_amount(text,
        r"(?:筹资费用|筹款费用|Fundraising\s*Expenses?)\D*?([\d,]+\.?\d*)",
    )
    ar["费用合计"] = extract_amount(text,
        r"(?:费用合计|支出合计|费用总计|Total\s*Expenses?)\D*?([\d,]+\.?\d*)",
    )

    # 净资产变动
    ar["净资产变动额"] = extract_amount(text,
        r"(?:净资产变动额|本期净资产变动|Change\s*in\s*Net\s*Assets?)\D*?([-]?[\d,]+\.?\d*)",
    )

    ar = {k: v for k, v in ar.items() if v != 0}
    return ar


def parse_cashflow(text):
    """解析现金流量表（5+字段）"""
    cf = {}

    cf["业务活动产生的现金流量"] = extract_amount(text,
        r"(?:业务活动产生的现金流量净额|经营活动现金流量|Cash\s*from\s*Operations?\s*Net)\D*?([-]?[\d,]+\.?\d*)",
    )
    cf["接受捐赠收到的现金"] = extract_amount(text,
        r"(?:接受捐赠收到的现金|Cash\s*Received\s*from\s*Donations?)\D*?([\d,]+\.?\d*)",
    )
    cf["投资活动产生的现金流量"] = extract_amount(text,
        r"(?:投资活动产生的现金流量净额|Cash\s*from\s*Investing\s*Net)\D*?([-]?[\d,]+\.?\d*)",
    )
    cf["现金期末余额"] = extract_amount(text,
        r"(?:现金期末余额|期末现金|Ending\s*Cash\s*Balance)\D*?([\d,]+\.?\d*)",
    )

    cf = {k: v for k, v in cf.items() if v != 0}
    return cf


def parse_audit_opinion(text):
    """解析审计意见类型"""
    opinion_patterns = [
        (r"标准无保留意见", "标准无保留意见"),
        (r"无保留意见", "无保留意见"),
        (r"保留意见", "保留意见"),
        (r"无法表示意见", "无法表示意见"),
        (r"否定意见", "否定意见"),
        (r"Unqualified\s*Opinion", "标准无保留意见"),
        (r"Qualified\s*Opinion", "保留意见"),
        (r"Disclaimer\s*of\s*Opinion", "无法表示意见"),
        (r"Adverse\s*Opinion", "否定意见"),
    ]
    for pattern, label in opinion_patterns:
        if re.search(pattern, text, re.IGNORECASE):
            return label
    return "未识别"


def parse_related_party_transactions(text):
    """解析关联交易信息（简化版）"""
    transactions = []
    # 尝试匹配关联交易段落
    related_section = re.search(
        r"(?:关联方?交易|关联交易披露|Related\s*Party\s*Transactions?)(.*?)(?:\n\n|注：|备注|附注|$)",
        text, re.IGNORECASE | re.DOTALL
    )
    if related_section:
        section_text = related_section.group(1)
        # 尝试提取租赁交易
        rent_match = re.search(r"(?:租赁|租金|Lease|Rent)\D*?([\d,]+\.?\d*)", section_text, re.IGNORECASE)
        if rent_match:
            amount = float(rent_match.group(1).replace(",", ""))
            transactions.append({
                "counterparty": "关联方",
                "type": "租赁",
                "amount": amount,
                "description": "关联租赁交易"
            })

        # 尝试提取采购交易
        purchase_match = re.search(r"(?:采购|购买|Purchase)\D*?([\d,]+\.?\d*)", section_text, re.IGNORECASE)
        if purchase_match:
            amount = float(purchase_match.group(1).replace(",", ""))
            transactions.append({
                "counterparty": "关联方",
                "type": "采购",
                "amount": amount,
                "description": "关联采购交易"
            })

    return transactions


def parse_financial_data(text):
    """从文本中解析完整的财务数据（60+字段结构化输出）"""
    data = {}

    # 机构名称
    org_match = re.search(
        r"([\u4e00-\u9fff]+(?:基金会|协会|中心|学会|联合会|促进会|研究院|学院|医院|机构|组织|Organization|Foundation|Association|Center))",
        text, re.IGNORECASE
    )
    if org_match:
        data["organization_name"] = org_match.group(1).strip()
    else:
        data["organization_name"] = "Unknown Organization"

    # 年份
    year_match = re.search(r"((\d{4})\s*年度|(\d{4})\s*Annual|Year\s*(\d{4})|(\d{4})\s*度)", text, re.IGNORECASE)
    if year_match:
        year = year_match.group(2) or year_match.group(3) or year_match.group(4) or year_match.group(5)
        data["year"] = int(year)
    else:
        data["year"] = 2024

    # 审计意见
    data["audit_opinion"] = parse_audit_opinion(text)

    # 组织类型（尝试从文本推断）
    if "公募" in text and "基金会" in text:
        data["org_type"] = "公募基金会"
    elif "非公募" in text and "基金会" in text:
        data["org_type"] = "非公募基金会"
    elif "基金会" in text:
        data["org_type"] = "非公募基金会"
    elif "社会团体" in text or "协会" in text:
        data["org_type"] = "社会团体"
    elif "社会服务" in text or "民非" in text:
        data["org_type"] = "社会服务机构"
    else:
        data["org_type"] = ""

    # 原始基金（尝试提取）
    fund_match = re.search(r"(?:原始基金|注册资金|原始注册资本|Registered\s*(?:Fund|Capital))\D*?([\d,]+\.?\d*)", text, re.IGNORECASE)
    if fund_match:
        data["original_fund"] = float(fund_match.group(1).replace(",", ""))
    else:
        data["original_fund"] = 0

    # 三大报表
    data["balance_sheet"] = parse_balance_sheet(text)
    data["activity_report"] = parse_activity_report(text)
    data["cashflow"] = parse_cashflow()

    # 关联交易
    data["related_party_transactions"] = parse_related_party_transactions(text)

    return data


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print(json.dumps({"error": "请提供 PDF 文件路径"}, ensure_ascii=False))
        sys.exit(1)

    pdf_path = sys.argv[1]

    # 提取文本
    text = extract_text_from_pdf(pdf_path)

    # 如果返回的是 JSON 错误字符串，直接输出并退出
    if text.startswith("{"):
        print(text)
        sys.exit(1)

    # 解析财务数据
    data = parse_financial_data(text)

    # 输出 JSON
    print(json.dumps(data, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
