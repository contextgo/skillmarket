---
name: tcm-mcp-integration
description: Configure and troubleshoot TCM AI Engine MCP servers over SSE for agents, IDEs, workflow engines, and MCP clients. Use when the user asks to connect TCM knowledge graph, health records, resource recommendation, or TCM NLP/diagnostic MCP services to Claude Desktop, OpenClaw, Cursor, Dify, LangChain, or similar clients.
version: 1.0.0
tags:
  - mcp
  - tcm
  - sse
  - agent
  - integration
env:
  - name: TCM_MCP_HOST
    description: Hostname or IP address of the TCM AI Engine MCP server, without protocol or port.
    required: true
  - name: TCM_MCP_API_KEY
    description: Bearer token used by TCM AI Engine MCP services for Authorization.
    required: true
---

# TCM MCP Integration

Use this skill when configuring an AI agent, MCP client, IDE, or workflow engine to call the TCM AI Engine MCP services.

## Core Facts

All TCM AI Engine MCP services are exposed through SSE.

- Transport: `sse`
- Auth: HTTP Bearer token
- Header: `Authorization: Bearer <TCM_MCP_API_KEY>`
- Host placeholder: `<TCM_MCP_HOST>`
- Never publish real production API keys in config examples, logs, screenshots, or committed files.

If the user has not provided a host or API key, ask for them or use placeholders. For local/dev examples only, the default key may be shown as `<TCM_MCP_API_KEY>` instead of a literal secret.

## Service Catalog

| Service | Endpoint | Main capabilities |
| --- | --- | --- |
| TCM Knowledge Graph | `http://<TCM_MCP_HOST>:9991/sse` | Search TCM knowledge, get entity reasoning paths, read herb cards |
| Health Records & Report | `http://<TCM_MCP_HOST>:9992/sse` | Query health metrics, summarize annual reports, read latest reports |
| Resource & Recommendation | `http://<TCM_MCP_HOST>:9993/sse` | Search doctors, recommend health packages, search articles/videos |
| TCM NLP & Diagnostic | `http://<TCM_MCP_HOST>:9994/sse` | Normalize symptoms, extract TCM entities |

## Tools And Resources

### TCM Knowledge Graph Server

Endpoint: `http://<TCM_MCP_HOST>:9991/sse`

- Tool: `search_tcm_knowledge` - Query TCM graph relationships among symptoms, herbs, formulas, and related concepts.
- Tool: `get_entity_paths` - Retrieve reasoning paths between multiple TCM entities.
- Resource: `tcm://herb/{name}` - Read a structured herb encyclopedia card.

### Health Records & Report Server

Endpoint: `http://<TCM_MCP_HOST>:9992/sse`

- Tool: `query_health_metrics` - Query recent trends for a user's health metrics such as blood pressure and blood glucose.
- Tool: `summarize_annual_report` - Extract and summarize abnormal findings in a user's physical examination report.
- Resource: `report://user/{uid}/latest` - Return the user's latest complete physical examination report in Markdown.

### Resource & Recommendation Server

Endpoint: `http://<TCM_MCP_HOST>:9993/sse`

- Tool: `search_doctors` - Find doctors by department or symptom.
- Tool: `recommend_health_packages` - Recommend related TCM conditioning service packages.
- Tool: `search_articles_videos` - Search TCM educational articles and videos.

### TCM NLP & Diagnostic Server

Endpoint: `http://<TCM_MCP_HOST>:9994/sse`

- Tool: `normalize_symptoms` - Normalize colloquial complaints such as "脑袋疼" into standard TCM symptoms such as "头痛".
- Tool: `extract_tcm_entities` - Extract TCM entities from long text, backed by the underlying Ahocorasick automaton.

## Configuration Workflow

1. Identify which TCM service or services the user needs.
2. Confirm the MCP client type: Claude Desktop, OpenClaw, Cursor, Dify, LangChain, or another SSE-compatible client.
3. Ask for or infer `TCM_MCP_HOST`.
4. Use `TCM_MCP_API_KEY` or a secret manager/environment variable instead of embedding a production token.
5. Generate the smallest working configuration for the chosen client.
6. Tell the user how to verify the connection by checking whether tools and resources are discovered from the server's MCP schema.

## Client Configuration Patterns

### Claude Desktop Or OpenClaw Through SSE Bridge

Use this pattern when the desktop client only supports local `stdio` MCP processes. It launches a local Node.js bridge to connect to the remote SSE endpoint.

Requires Node.js and `npx`.

```json
{
  "mcpServers": {
    "tcm_knowledge": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://<TCM_MCP_HOST>:9991/sse",
        "--header",
        "Authorization: Bearer <TCM_MCP_API_KEY>"
      ]
    },
    "health_report": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://<TCM_MCP_HOST>:9992/sse",
        "--header",
        "Authorization: Bearer <TCM_MCP_API_KEY>"
      ]
    }
  }
}
```

Add the other services only when needed:

```json
{
  "mcpServers": {
    "resource_recommendation": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://<TCM_MCP_HOST>:9993/sse",
        "--header",
        "Authorization: Bearer <TCM_MCP_API_KEY>"
      ]
    },
    "tcm_nlp": {
      "command": "npx",
      "args": [
        "-y",
        "@modelcontextprotocol/client-sse",
        "--url",
        "http://<TCM_MCP_HOST>:9994/sse",
        "--header",
        "Authorization: Bearer <TCM_MCP_API_KEY>"
      ]
    }
  }
}
```

### Cursor Or IDE With Native SSE MCP Support

Use this pattern when the client lets the user add an MCP server with URL and headers directly.

- Type: `sse`
- URL: `http://<TCM_MCP_HOST>:9991/sse`
- Headers:

```json
{
  "Authorization": "Bearer <TCM_MCP_API_KEY>"
}
```

Repeat for ports `9992`, `9993`, and `9994` when those services are required.

### Generic JSON Configuration

Use this pattern for clients that accept a JSON representation of SSE MCP servers.

```json
{
  "mcpServers": {
    "tcm_knowledge": {
      "transport": "sse",
      "url": "http://<TCM_MCP_HOST>:9991/sse",
      "headers": {
        "Authorization": "Bearer <TCM_MCP_API_KEY>"
      }
    },
    "tcm_nlp": {
      "transport": "sse",
      "url": "http://<TCM_MCP_HOST>:9994/sse",
      "headers": {
        "Authorization": "Bearer <TCM_MCP_API_KEY>"
      }
    }
  }
}
```

If a specific client requires different field names, adapt the fields while preserving the same endpoint, SSE transport, and Authorization header.

## Schema Discovery

Do not ask the user to look for Swagger documentation for these MCP services. MCP clients discover available tools and resources during initialization from the server-provided JSON Schema.

After connection succeeds, verify that the expected tools/resources appear in the client:

- `search_tcm_knowledge`
- `get_entity_paths`
- `query_health_metrics`
- `summarize_annual_report`
- `search_doctors`
- `recommend_health_packages`
- `search_articles_videos`
- `normalize_symptoms`
- `extract_tcm_entities`
- `tcm://herb/{name}`
- `report://user/{uid}/latest`

## Troubleshooting

- If no tools appear, verify the SSE URL, port, network access, and Authorization header.
- If authentication fails, confirm the token configured in the server environment variable such as `MCP_API_KEY`.
- If a desktop client cannot connect to SSE directly, use the Node.js `@modelcontextprotocol/client-sse` bridge.
- If only some capabilities are needed, configure only the corresponding MCP service to reduce tool clutter.
- If the client stores configuration in a committed repo, use environment variables or local ignored config files for secrets.
- If the server is behind HTTPS, a reverse proxy, or a gateway, preserve the `/sse` path and Authorization header forwarding.

## Response Style

When helping a user, provide:

1. The exact config snippet for their client.
2. A short explanation of which services are enabled.
3. A verification step that checks whether MCP tools/resources are discovered.
4. A reminder to replace placeholders with their actual host and API key without exposing secrets.
