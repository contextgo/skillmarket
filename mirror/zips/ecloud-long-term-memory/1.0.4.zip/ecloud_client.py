import datetime
import hashlib
import hmac
import json
import logging
import socket
import uuid
from urllib.error import URLError, HTTPError
from urllib.parse import quote_plus, unquote_plus
from urllib.request import Request, urlopen

logger = logging.getLogger("ltm-handler")
# logging.basicConfig()
logger.setLevel(logging.INFO)


ACCESS_KEY = "AccessKey"
TIMESTAMP = "Timestamp"
TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%SZ"
SIGNATURE = "Signature"
SECRET_KEY_PREFIX = "BC_SIGNATURE&"
SIGNATURE_METHOD_KEY = "SignatureMethod"
SIGNATURE_METHOD_VAL = "HmacSHA1"
SIGNATURE_VERSION_KEY = "SignatureVersion"
SIGNATURE_VERSION_VAL = "V2.0"
SIGNATURE_NONCE = "SignatureNonce"


# ── 签名工具函数 ──────────────────────────────────────────
def _percent_encode(text):
    return quote_plus(str(text)).replace('+', '%20').replace('*', '%2A').replace('%7E', '~')


def _sha256_hex(text):
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def _hmac_sha1_hex(text, secret_key):
    return hmac.new(
        secret_key.encode('utf-8'),
        text.encode('utf-8'),
        hashlib.sha1,
    ).hexdigest()



class EcloudClient:
    def __init__(self, ak: str, sk: str, host: str= 'https://console.ecloud.10086.cn', pool_id: str='CIDC-RP-48'):
        self.ak = ak
        self.sk = sk
        self.host = host
        self.pool_id = pool_id
        if not self.ak or not self.sk :
            raise ValueError("ak, sk 必须全部提供")


    def _generate_signature(self, method, path, query_params):
        params = {}
        for k, v in query_params.items():
            if v is None:
                continue
            params[k] = json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list)) else str(v)

        params[ACCESS_KEY] = self.ak
        params[SIGNATURE_METHOD_KEY] = SIGNATURE_METHOD_VAL
        params[SIGNATURE_VERSION_KEY] = SIGNATURE_VERSION_VAL
        params[TIMESTAMP] = datetime.datetime.now().strftime(TIMESTAMP_FORMAT)
        params[SIGNATURE_NONCE] = str(uuid.uuid4()).replace("-", "")

        sorted_keys = sorted(params.keys())
        canonical_qs = "&".join(
            f"{_percent_encode(k)}={_percent_encode(params[k])}" for k in sorted_keys
        )

        hash_string = _sha256_hex(canonical_qs)
        servlet_path = unquote_plus(path)
        string_to_sign = f"{method.upper()}\n{_percent_encode(servlet_path)}\n{hash_string}"
        signature = _hmac_sha1_hex(string_to_sign, SECRET_KEY_PREFIX + self.sk)

        logger.debug("签名生成: method=%s path=%s nonce=%s", method, path, params[SIGNATURE_NONCE])

        return signature, canonical_qs

    # ── HTTP 请求（使用 urllib）─────────────────────────────────
    def send_request(self, method, path, payload):
        """通过 urllib 发送带 AKSK 签名的请求"""
        request_id = str(uuid.uuid4())[:8]
        logger.info("[%s] >>> %s %s", request_id, method, path)
        logger.debug("[%s] 请求体: %s", request_id,
                     json.dumps(payload, ensure_ascii=False)[:2000] if payload else "(empty)")

        try:
            signature, canonical_qs = self._generate_signature(method, path, payload or {})
        except Exception as e:
            logger.error("[%s] 签名生成失败: %s", request_id, e, exc_info=True)
            return {"error": f"签名生成失败: {e}"}
        signed_qs = f"{SIGNATURE}={_percent_encode(signature)}"
        url = f"{self.host}{path}?{canonical_qs}&{signed_qs}"

        logger.debug("[%s] URL: %s", request_id, url[:300] + "..." if len(url) > 300 else url)

        headers = {
            "Content-Type": "application/json",
            "Pool-Id": self.pool_id,
        }

        # 准备请求数据
        data = None
        if payload:
            data = json.dumps(payload).encode('utf-8')
            headers["Content-Length"] = str(len(data))

        # 创建请求
        req = Request(url, data=data, headers=headers, method=method.upper())

        try:
            # 发送请求
            with urlopen(req, timeout=15) as response:
                elapsed_ms = 0  # urllib 不直接提供 elapsed 时间
                response_data = response.read()
                status_code = response.getcode()

                logger.info("[%s] <<< HTTP %d (%d bytes)",
                            request_id, status_code, len(response_data))

                if not response_data.strip():
                    logger.info("[%s] 响应体为空 (操作可能成功)", request_id)
                    return {"status": "success"}

                data = json.loads(response_data.decode('utf-8'))
                logger.debug("[%s] 响应体: %s", request_id,
                             json.dumps(data, ensure_ascii=False)[:2000])
                return data

        except HTTPError as e:
            # HTTP 错误响应（4xx, 5xx）
            error_body = e.read().decode('utf-8') if e.fp else ''
            logger.error("[%s] HTTP 错误 %d: %s", request_id, e.code, error_body[:1000])
            return {"error": f"HTTP {e.code}: {error_body[:500]}"}

        except URLError as e:
            logger.error("[%s] URL 错误: %s", request_id, e.reason)
            return {"error": f"连接失败: {e.reason}"}

        except socket.timeout:
            logger.error("[%s] 请求超时 (15s)", request_id)
            return {"error": "请求超时，请稍后重试"}

        except json.JSONDecodeError as e:
            logger.error("[%s] JSON 解析失败: %s", request_id, e)
            return {"error": f"响应解析失败: {str(e)}"}

        except Exception as e:
            logger.error("[%s] 未知异常: %s", request_id, e, exc_info=True)
            return {"error": str(e)}
