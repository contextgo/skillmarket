#!/usr/bin/env python3
"""
长期记忆 Skill - memory_client.py
"""

import datetime
import hashlib
import hmac
import io
import json
import logging
import os
import sys
import uuid
from logging.handlers import RotatingFileHandler
from urllib.parse import quote_plus, unquote_plus
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
import socket

if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

# ── 日志配置 ──────────────────────────────────────────────
LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
os.makedirs(LOG_DIR, exist_ok=True)
LOG_FILE = os.path.join(LOG_DIR, "ltm-handler.log")

logger = logging.getLogger("ltm-handler")
logger.setLevel(logging.DEBUG)

_fh = RotatingFileHandler(LOG_FILE, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8")
_fh.setFormatter(logging.Formatter(
    "%(asctime)s | %(levelname)-5s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
))
logger.addHandler(_fh)

logger.info("=" * 60)
logger.info("handler.py 模块加载")

# ── 环境变量加载（支持多工具）──────────────────────────────────
from pathlib import Path

def load_env_file(env_path):
    """加载 .env 文件"""
    if not env_path.exists():
        return {}

    env_vars = {}
    with open(env_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
            if '=' in line:
                key, value = line.split('=', 1)
                # 移除可能的引号
                value = value.strip().strip('"').strip("'")
                env_vars[key.strip()] = value
    return env_vars


def get_env_with_fallback(key, default=None):
    """从多个来源获取环境变量（优先级：进程环境 > .env文件 > 默认值）"""
    # 1. 先检查是否已经设置（进程环境变量）
    value = os.getenv(key)
    if value:
        return value

    # 2. 尝试加载 .env 文件（仅在第一次调用时加载）
    if not hasattr(get_env_with_fallback, '_env_cache'):
        get_env_with_fallback._env_cache = {}

        # 按优先级搜索 .env 文件
        env_paths = [
            Path.cwd() / '.env',                    # 当前目录
            Path.home() / '.openclaw' / '.env',     # OpenClaw 全局
            Path.home() / '.config' / 'openclaw' / '.env',  # 备选
            Path.home() / '.config' / 'mobileclaw' / '.env',  # 备选
            Path.home() / '.env',                   # 用户根目录
        ]

        for env_path in env_paths:
            if env_path.is_file():
                get_env_with_fallback._env_cache.update(load_env_file(env_path))
                logger.debug(f"已加载环境变量文件: {env_path}")
                break  # 找到第一个就停止

    # 3. 从缓存的环境变量中获取
    if key in get_env_with_fallback._env_cache:
        return get_env_with_fallback._env_cache[key]

    # 4. 返回默认值
    return default


# ── 环境变量配置 ──────────────────────────────────────────
HOST = get_env_with_fallback("MEMORY_BASE_URL", "https://console.ecloud.10086.cn")
AK = get_env_with_fallback("MEMORY_AK", "")
SK = get_env_with_fallback("MEMORY_SK", "")
MEMORY_LIBRARY_ID = get_env_with_fallback("MEMORY_LIBRARY_ID", "")
USER_ID = get_env_with_fallback("MEMORY_USER_ID", "openclaw_user")
POOL_ID = get_env_with_fallback("MEMORY_POOL_ID", "CIDC-RP-48")
SSL_VERIFY = '31015' not in HOST


logger.info("配置: HOST=%s  USER_ID=%s  LIBRARY_ID=%s  AK=%s  SSL_VERIFY=%s",
            HOST, USER_ID, MEMORY_LIBRARY_ID,
            (AK[:6] + "****") if AK else "(empty)",
            SSL_VERIFY)

if not HOST or not AK or not SK:
    logger.error("关键环境变量缺失! HOST=%s AK=%s SK=%s",
                 bool(HOST), bool(AK), bool(SK))

# 禁用 SSL 验证警告（如果需要）
if not SSL_VERIFY:
    import ssl
    ssl._create_default_https_context = ssl._create_unverified_context
    logger.warning("ssl is disabled")

SEARCH_PATH = "/api/web/routes/long-memory-api/memories/search/"
ADD_PATH = "/api/web/routes/long-memory-api/memories"
LIST_PATH = "/api/web/routes/long-memory-api/memories"

from ecloud_client import EcloudClient
client = EcloudClient(AK, SK, HOST, POOL_ID)

# ══════════════════════════════════════════════════════════
# 以下函数由 manifest.json 中 api.functions 声明
# OpenClaw 根据 manifest 自动发现并注册为可调用工具
# 函数参数名必须和 manifest.json 中 parameters.properties 的 key 一致
# ══════════════════════════════════════════════════════════

def save_memory(message: str):
    """
    存储记忆：将对话消息发送给记忆服务，系统自动提取关键事实。
    对应 manifest.json 中的 save_memory 函数。

    参数:
        message: 用户原话
    """
    logger.info("===== save_memory 被调用 | %s 消息 =====", len(message))

    # 修正：使用传入的 message 参数，而不是 sys.argv
    messages = [
        {"role": "user", "content": message},
        {"role": "assistant", "content": "好的"}
    ]
    for i, msg in enumerate(messages):
        logger.debug("  消息[%d] role=%s content=%s",
                     i, msg.get("role"), msg.get("content", "")[:200])

    payload = {
        "user_id": USER_ID,
        "run_id": "",
        "memory_library_id": MEMORY_LIBRARY_ID,
        "agent_id": "",
        "meta_data": {"source": "openclaw"},
        "message": messages,
    }

    result = client.send_request("POST", ADD_PATH, payload)
    return result



def search_memory(query, limit=5):
    """
    检索记忆：基于语义搜索用户的历史记忆。
    对应 manifest.json 中的 search_memory 函数。

    参数:
        query (str): 搜索关键词或语义描述
        limit (int): 返回数量，默认 5
    """
    logger.info("===== search_memory 被调用 | query='%s' limit=%d =====", query, limit)

    payload = {
        "user_id": USER_ID,
        "run_id": "",
        "agent_id": "",
        "query": query,
        "memory_library_id": MEMORY_LIBRARY_ID,
        "limit": limit,
        "time_start": None,
        "time_end": None,
    }

    result = client.send_request("POST", SEARCH_PATH, payload)
    return result





def list_all(page=1, size=50):
    """获取所有记忆"""
    params = {
        "memory_library_id": MEMORY_LIBRARY_ID,
        'user_id': USER_ID,
        'page': page,
        'size': size
    }
    result = client.send_request("GET", LIST_PATH, params)
    return result



# ── 命令行测试入口 ────────────────────────────────────────

if __name__ == "__main__":
    print(f"日志文件: {LOG_FILE}")
    print(f"HOST: {HOST}")
    print(f"AK: {(AK[:6] + '****') if AK else '(empty)'}")
    print(f"LIBRARY_ID: {MEMORY_LIBRARY_ID}")
    print(f"SSL_VERIFY: {SSL_VERIFY}")
    print()
    if len(sys.argv) > 1 and sys.argv[1] == "search":
        q = sys.argv[2] if len(sys.argv) > 2 else "用户基本信息"
        limit = int(sys.argv[3]) if len(sys.argv) > 3 else 5
        r = search_memory(q, limit)
        print(json.dumps(r, ensure_ascii=False, indent=2))

    elif len(sys.argv) > 1 and sys.argv[1] == "save":
        if len(sys.argv) > 2:
            r = save_memory(sys.argv[2])
        else:
            r = save_memory("测试消息")
        print(json.dumps(r, ensure_ascii=False, indent=2))
    elif len(sys.argv) > 1 and sys.argv[1] == "list_all":
        page = sys.argv[2] if len(sys.argv) > 2 else 1
        limit = int(sys.argv[3]) if len(sys.argv) > 3 else 50
        r = list_all(int(page), int(limit))
        print(json.dumps(r, ensure_ascii=False, indent=2))
    else:
        print("用法:")
        print(f"  python {sys.argv[0]} search <查询词> [limit]")
        print(f"  python {sys.argv[0]} save '<用户原话>'")