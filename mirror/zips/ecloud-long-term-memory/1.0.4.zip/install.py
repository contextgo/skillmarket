#!/usr/bin/env python3
"""
ecloud-long-term-memory 安装脚本
自动配置系统使用ecloud-long-term-memory作为记忆
"""

import os
import sys
import shutil
import datetime
from pathlib import Path

# 配置路径
WORKSPACE_DIR = Path.home() / ".openclaw" / "workspace"
BACKUP_DIR = WORKSPACE_DIR / "backups"
SKILL_DIR = Path(__file__).parent

def create_backup():
    """创建配置文件备份"""
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"config_backup_{timestamp}"
    
    print(f"📦 创建备份目录: {backup_path}")
    backup_path.mkdir(parents=True, exist_ok=True)
    
    # 备份重要文件
    files_to_backup = [
        "AGENTS.md",
        "SOUL.md",
        "HEARTBEAT.md",
        "MEMORY.md"
    ]
    
    for filename in files_to_backup:
        source = WORKSPACE_DIR / filename
        if source.exists():
            dest = backup_path / filename
            shutil.copy2(source, dest)
            print(f"  ✓ 备份: {filename}")
    
    # 备份memory目录
    memory_dir = WORKSPACE_DIR / "memory"
    if memory_dir.exists():
        dest_dir = backup_path / "memory"
        shutil.copytree(memory_dir, dest_dir, dirs_exist_ok=True)
        print(f"  ✓ 备份: memory/ 目录")
    
    return backup_path

def update_agents_md():
    """修改AGENTS.md文件，禁用本地记忆"""
    agents_path = WORKSPACE_DIR / "AGENTS.md"
    
    if not agents_path.exists():
        print(f"❌ 找不到AGENTS.md文件: {agents_path}")
        return False
    
    with open(agents_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 修改Session Startup部分 - 移除本地记忆读取
    old_startup = """## Session Startup

Before doing anything else:

1. Read `SOUL.md` — this is who you are
2. Read `USER.md` — this is who you're helping
3. Read `memory/YYYY-MM-DD.md` (today + yesterday) for recent context
4. **If in MAIN SESSION** (direct chat with your human): Also read `MEMORY.md`

Don't ask permission. Just do it."""
    
    new_startup = """## Session Startup

Before doing anything else:

1. Read `SOUL.md` — this is who you are
2. Read `USER.md` — this is who you're helping
3. **使用ecloud-long-term-memory技能**加载最近的记忆上下文

Don't ask permission. Just do it."""
    
    content = content.replace(old_startup, new_startup)
    
    # 修改Memory部分 - 替换为ecloud-long-term-memory说明
    old_memory_section = """## Memory

You wake up fresh each session. These files are your continuity:

- **Daily notes:** `memory/YYYY-MM-DD.md` (create `memory/` if needed) — raw logs of what happened
- **Long-term:** `MEMORY.md` — your curated memories, like a human's long-term memory

Capture what matters. Decisions, context, things to remember. Skip the secrets unless asked to keep them.

### 🧠 MEMORY.md - Your Long-Term Memory

- **ONLY load in main session** (direct chats with your human)
- **DO NOT load in shared contexts** (Discord, group chats, sessions with other people)
- This is for **security** — contains personal context that shouldn't leak to strangers
- You can **read, edit, and update** MEMORY.md freely in main sessions
- Write significant events, thoughts, decisions, opinions, lessons learned
- This is your curated memory — the distilled essence, not raw logs
- Over time, review your daily files and update MEMORY.md with what's worth keeping

### 📝 Write It Down - No "Mental Notes"!

- **Memory is limited** — if you want to remember something, WRITE IT TO A FILE
- "Mental notes" don't survive session restarts. Files do.
- When someone says "remember this" → update `memory/YYYY-MM-DD.md` or relevant file
- When you learn a lesson → update AGENTS.md, TOOLS.md, or the relevant skill
- When you make a mistake → document it so future-you doesn't repeat it
- **Text > Brain** 📝"""
    
    new_memory_section = """## Memory - ecloud-long-term-memory 专用

**⚠️ 重要：已禁用本地markdown记忆系统**

你每次会话都是全新的开始。ecloud-long-term-memory是你的唯一记忆系统, 不要再使用内置的memory_search和memory_save方法

### 🧠 ecloud-long-term-memory 使用规则

1. **所有记忆操作必须通过ecloud-long-term-memory技能完成**
   - 存储记忆：使用 `python memory_client.py save '内容'`
   - 搜索记忆：使用 `python memory_client.py search "关键词" [数量]`
   - 查看所有记忆：使用 `python memory_client.py search "用户的所有记忆" 20`

2. **禁止使用本地markdown文件作为记忆**
   - 不要读取或写入 `memory/YYYY-MM-DD.md` 文件
   - 不要读取或写入 `MEMORY.md` 文件
   - 不要创建本地记忆文件

3. **记忆操作时机**
   - 当用户提供个人信息时 → 立即存储到云端
   - 当需要回忆信息时 → 从云端搜索
   - 当用户询问"你还记得什么"时 → 搜索"用户的所有信息"

### 📝 云端记忆优势
- **持久性**: 记忆在会话间保留
- **可搜索**: 支持自然语言搜索
- **安全**: 记忆存储在云端，本地不留痕迹
- **结构化**: 自动评分和相关性排序

### ⚠️ 注意事项
- 需要网络连接才能访问记忆
- 重要信息建议双重确认
- 发现矛盾信息时先确认再更新"""
    
    content = content.replace(old_memory_section, new_memory_section)
    
    # 修改Heartbeats部分 - 移除本地记忆维护
    old_heartbeat_memory = """### 🔄 Memory Maintenance (During Heartbeats)

Periodically (every few days), use a heartbeat to:

1. Read through recent `memory/YYYY-MM-DD.md` files
2. Identify significant events, lessons, or insights worth keeping long-term
3. Update `MEMORY.md` with distilled learnings
4. Remove outdated info from MEMORY.md that's no longer relevant

Think of it like a human reviewing their journal and updating their mental model. Daily files are raw notes; MEMORY.md is curated wisdom."""
    
    new_heartbeat_memory = """### 🔄 云端记忆维护 (During Heartbeats)

定期（每几天一次），用心跳检查来：

1. 使用 `python memory_client.py search "最近的重要事件" 10` 查看近期记忆
2. 整理和总结重要的学习、决策和经历
3. 删除或更新过时、不准确的记忆（通过新的save操作覆盖）

云端记忆会自动处理相关性和时效性，但需要定期人工审查以确保准确性。"""
    
    content = content.replace(old_heartbeat_memory, new_heartbeat_memory)
    
    # 写入修改后的内容
    with open(agents_path, 'w', encoding='utf-8') as f:
        f.write(content)
    
    print(f"✓ 更新: AGENTS.md - 已禁用本地记忆，启用ecloud-long-term-memory")
    return True

def update_soul_md():
    """更新SOUL.md文件，添加记忆使用说明"""
    soul_path = WORKSPACE_DIR / "SOUL.md"
    
    if not soul_path.exists():
        print(f"⚠️ 找不到SOUL.md文件，跳过更新")
        return True
    
    with open(soul_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 在文件末尾添加记忆使用说明
    memory_note = """

## 记忆系统说明

**已配置为只使用ecloud-long-term-memory作为记忆系统**

### 使用规则：
1. 所有记忆操作必须通过ecloud-long-term-memory技能完成
2. 禁止使用本地markdown文件（memory/目录和MEMORY.md）作为记忆
3. 当用户提供信息时，立即存储到云端
4. 当需要回忆时，从云端搜索相关记忆

### 常用命令：
- 存储记忆：`python memory_client.py save '内容'`
- 搜索记忆：`python memory_client.py search "关键词" 数量`
- 查看所有：`python memory_client.py search "用户的所有记忆" 20`

### 优势：
- 记忆在会话间持久保存
- 支持自然语言搜索
- 本地不留痕迹，更安全"""
    
    # 检查是否已添加过说明
    if "ecloud-long-term-memory" not in content:
        with open(soul_path, 'a', encoding='utf-8') as f:
            f.write(memory_note)
        print(f"✓ 更新: SOUL.md - 添加了记忆系统说明")
    
    return True

def create_memory_migration_note():
    """创建记忆迁移说明文件"""
    migration_path = WORKSPACE_DIR / "MEMORY_MIGRATION.md"
    
    migration_content = """# 记忆系统迁移说明

## 迁移完成时间
{timestamp}

## 变更概述
已从本地markdown记忆系统迁移到ecloud-long-term-memory云端记忆系统

## 配置变更
1. **禁用本地记忆**：
   - 不再自动读取 `memory/YYYY-MM-DD.md` 文件
   - 不再自动读取 `MEMORY.md` 文件
   - 不再创建本地记忆文件

2. **启用云端记忆**：
   - 所有记忆操作通过 `memory_client.py` 脚本完成
   - 记忆存储在云端，支持跨会话访问
   - 支持自然语言搜索和相关性排序

3. **会话启动流程更新**：
   - 启动时不再加载本地记忆文件
   - 需要通过ecloud-long-term-memory技能手动加载记忆

## 使用指南

### 存储记忆
当用户提供需要记住的信息时：
```bash
python memory_client.py save '用户提供的具体信息'
```

### 搜索记忆
当需要回忆信息时：
```bash
# 搜索特定信息
python memory_client.py search "搜索关键词" 10

# 查看所有记忆
python memory_client.py search "用户的所有记忆" 20
```

### 常见问题
1. **如何查看我之前记录的内容？**
   - 运行：`python memory_client.py search "用户的所有信息" 20`

2. **网络连接中断怎么办？**
   - 云端记忆需要网络连接
   - 重要信息建议在本地也有备份

3. **如何迁移旧的本地记忆？**
   - 查看备份目录中的记忆文件
   - 手动将重要信息存储到云端

## 备份信息
原始配置文件已备份到：{backup_path}

## 恢复说明
如需恢复本地记忆系统：
1. 从备份目录恢复配置文件
2. 删除或注释SOUL.md中的记忆系统说明
3. 重新启用AGENTS.md中的本地记忆相关部分
""".format(
        timestamp=datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        backup_path=BACKUP_DIR
    )
    
    with open(migration_path, 'w', encoding='utf-8') as f:
        f.write(migration_content)
    
    print(f"✓ 创建: MEMORY_MIGRATION.md - 记忆迁移说明文档")
    return True

def check_skill_availability():
    """检查ecloud-long-term-memory技能是否可用"""
    memory_client = SKILL_DIR / "memory_client.py"
    
    if not memory_client.exists():
        print(f"❌ 找不到memory_client.py文件: {memory_client}")
        return False
    
    # 检查Python环境
    try:
        import subprocess
        result = subprocess.run(
            ["python3", "--version"],
            capture_output=True,
            text=True
        )
        print(f"✓ Python环境: {result.stdout.strip()}")
    except Exception as e:
        print(f"⚠️ Python环境检查失败: {e}")
    
    return True

def main():
    """主安装函数"""
    print("=" * 60)
    print("ecloud-long-term-memory 安装脚本")
    print("=" * 60)
    print("将配置系统只使用云端记忆，禁用本地markdown记忆")
    print()
    
    # 检查技能可用性
    print("🔍 检查ecloud-long-term-memory技能...")
    if not check_skill_availability():
        print("❌ ecloud-long-term-memory技能不可用，安装中止")
        return 1
    
    # 创建备份
    print("\n📦 创建配置文件备份...")
    backup_path = create_backup()
    print(f"   备份已保存到: {backup_path}")
    
    # 更新配置文件
    print("\n⚙️ 更新配置文件...")
    
    if not update_agents_md():
        print("❌ 更新AGENTS.md失败")
        return 1
    
    if not update_soul_md():
        print("❌ 更新SOUL.md失败")
        return 1
    
    # 创建迁移说明
    print("\n📝 创建迁移文档...")
    create_memory_migration_note()
    
    # 完成提示
    print("\n" + "=" * 60)
    print("✅ 安装完成！")
    print("=" * 60)
    print()
    print("配置变更总结：")
    print("1. ✅ AGENTS.md - 已禁用本地记忆，启用云端记忆")
    print("2. ✅ SOUL.md - 添加了记忆系统使用说明")
    print("3. ✅ 创建了配置文件备份")
    print("4. ✅ 创建了记忆迁移说明文档")
    print()
    print("下一步操作：")
    print("1. 重启OpenClaw会话以使配置生效")
    print("2. 查看 MEMORY_MIGRATION.md 了解详细变更")
    print("3. 如有旧的本地记忆需要迁移，请手动处理")
    print("4. 测试记忆功能：")
    print("   - 存储测试: python memory_client.py save '测试记忆内容'")
    print("   - 搜索测试: python memory_client.py search '测试' 5")
    print()
    print("⚠️ 注意：")
    print("- 云端记忆需要网络连接")
    print("- 重要信息建议双重备份")
    print("- 如有问题，可从备份目录恢复配置")
    
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\n❌ 安装被用户中断")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ 安装过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)