# ecloud-long-term-memory

基于中国移动云记忆服务的长期记忆系统，为 OpenClaw 提供云端记忆存储和语义搜索能力。

## 特性

- 🧠 **云端存储**：记忆永久保存，跨会话共享
- 🔍 **语义搜索**：支持自然语言查询，智能匹配相关记忆
- 🔐 **安全认证**：AK/SK 签名认证，确保数据安全
- 📝 **自动提取**：系统自动从对话中提取关键事实
- ⚡ **高性能**：毫秒级检索响应

## 安装

```bash
# 通过 ClawHub 安装
clawhub install ecloud-long-term-memory

```

## 配置

在 `~/.openclaw/.env` 中添加：

```env
MEMORY_AK=你的AccessKey
MEMORY_SK=你的SecretKey
MEMORY_LIBRARY_ID=你的记忆库ID
MEMORY_USER_ID=openclaw_user
```

## 使用方法

### 保存记忆
```bash
python memory_client.py save '我喜欢喝美式咖啡'
```

### 搜索记忆
```bash
python memory_client.py search '我喜欢喝什么' 5
```

### 列出所有记忆
```bash
python memory_client.py list_all 1 50
```

## 在 OpenClaw 中使用

安装后，OpenClaw 会自动识别此技能。只需对助手说：

- "记住我叫张三"
- "我之前说过什么"
- "搜索我的职业信息"

## 依赖

- Python 3.7+
- 网络连接（访问移动云服务）

## 许可证

MIT