"""
CTP 直连数据 Skill - 使用示例
精简版，完整示例见 SKILL.md
"""

# ===========================================
# 快速开始
# ===========================================

def quick_start_example():
    """快速开始示例"""
    from ctp_connector import CTPMarketData, CTPTrader
    
    # 行情订阅
    md = CTPMarketData(config_path="config/ctp_config.yaml")
    md.connect()
    md.login()
    md.subscribe(["cu2506", "al2506"])
    
    # 交易下单
    trader = CTPTrader(config_path="config/ctp_config.yaml")
    trader.connect()
    trader.login()
    account = trader.query_account()
    
    return md, trader


def order_example():
    """下单示例"""
    from ctp_connector import CTPTrader
    
    trader = CTPTrader(config_path="config/ctp_config.yaml")
    trader.connect()
    trader.login()
    
    # 市价下单
    order = trader.insert_order(
        instrument="cu2506",
        direction="buy",
        offset="open",
        volume=1,
        order_type="market"
    )
    
    # 限价下单
    order = trader.insert_order(
        instrument="cu2506",
        direction="sell",
        offset="close",
        price=75000,
        volume=1,
        order_type="limit"
    )
    
    return order


def query_example():
    """查询示例"""
    from ctp_connector import CTPTrader
    
    trader = CTPTrader(config_path="config/ctp_config.yaml")
    trader.connect()
    trader.login()
    
    # 查询账户
    account = trader.query_account()
    print(f"可用资金: {account.available}")
    
    # 查询持仓
    positions = trader.query_positions()
    for pos in positions:
        print(f"{pos.instrument}: 多头{pos.long_vol}")
    
    # 查询委托
    orders = trader.query_orders()
    
    return account, positions, orders


if __name__ == "__main__":
    print("CTP Connector 使用示例")
    print("详细示例请查看 SKILL.md")
