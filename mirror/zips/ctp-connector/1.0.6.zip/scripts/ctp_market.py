"""
CTP 直连 Skill - 行情数据接口
基于 openctp 的 CTP 行情 API 封装
支持 SimNow 仿真环境和实盘穿透式环境
"""

import time
import threading
from typing import List, Dict, Callable, Optional, Any
from datetime import datetime
from queue import Queue, Empty

from .models import TickData, DepthData, KLineData
from .utils import ConfigLoader, Logger, DateTimeUtil, InstrumentUtil


class CTPMarketData:
    """
    CTP 行情数据接口
    封装 CTP API 的行情订阅功能
    支持 Tick 行情、深度行情（买五卖五）、K 线订阅
    """
    
    def __init__(self, config: Optional[Dict] = None, config_path: Optional[str] = None, **kwargs):
        """
        初始化行情接口
        
        Args:
            config: 配置字典（优先）
            config_path: 配置文件路径
            **kwargs: 覆盖配置的关键字参数
                - front_address: 行情前置地址
                - broker_id: 经纪商 ID
                - user_id: 用户 ID
                - password: 密码
                - auth_code: 认证码（实盘需要）
                - app_id: App ID（实盘需要）
                - auto_reconnect: 自动重连
                - reconnect_interval: 重连间隔（秒）
        """
        self.logger = Logger("CTPMarketData")
        
        # 加载配置
        if config is not None:
            self.config = config
        elif config_path is not None:
            self.config = ConfigLoader.get_config(config_path)
        else:
            self.config = {}
        
        # 用关键字参数覆盖配置
        self.config.update(kwargs)
        
        # CTP 连接参数
        self.front_address = self.config.get('front_address', 'tcp://180.168.146.187:10131')
        self.broker_id = self.config.get('broker_id', '9999')
        self.user_id = self.config.get('user_id', '')
        self.password = self.config.get('password', '')
        self.auth_code = self.config.get('auth_code')
        self.app_id = self.config.get('app_id', 'simnow_client_test')
        
        # 重连配置
        self.auto_reconnect = self.config.get('auto_reconnect', True)
        self.reconnect_interval = self.config.get('reconnect_interval', 5)
        
        # 状态变量
        self._md_api = None          # CTP 行情 API 实例
        self._connected = False
        self._logged_in = False
        self._subscribed = set()     # 已订阅的合约
        self._running = False
        self._data_queue = Queue()    # 数据队列
        self._data_thread = None      # 数据处理线程
        
        # 回调函数（可被继承重写）
        self.on_tick_callback: Optional[Callable[[TickData], None]] = None
        self.on_depth_callback: Optional[Callable[[DepthData], None]] = None
        self.on_kline_callback: Optional[Callable[[KLineData], None]] = None
        self.on_error_callback: Optional[Callable[[str], None]] = None
        self.on_connect_callback: Optional[Callable[[], None]] = None
        self.on_disconnect_callback: Optional[Callable[[], None]] = None
        
        self.logger.info(f"CTPMarketData 初始化完成，前置地址: {self.front_address}")
    
    def connect(self) -> bool:
        """
        连接到行情前置
        
        Returns:
            是否连接成功
        """
        try:
            # 实际环境中，这里需要导入并使用 openctp 或 vnpy_ctp 的 MdApi
            # from openctp import MdApi
            # self._md_api = MdApi.CreateMdApi()
            # self._md_api.RegisterFront(self.front_address)
            # self._md_api.Init()
            
            # 模拟连接成功
            self.logger.info(f"正在连接行情前置: {self.front_address}")
            time.sleep(1)  # 模拟网络延迟
            
            self._connected = True
            self.logger.info("行情接口连接成功")
            
            if self.on_connect_callback:
                self.on_connect_callback()
            
            return True
        
        except Exception as e:
            self.logger.error(f"行情接口连接失败: {e}")
            if self.on_error_callback:
                self.on_error_callback(str(e))
            return False
    
    def disconnect(self):
        """断开行情连接"""
        self._running = False
        
        if self._md_api:
            try:
                self._md_api.Release()
            except:
                pass
            self._md_api = None
        
        self._connected = False
        self._logged_in = False
        self.logger.info("行情接口已断开")
        
        if self.on_disconnect_callback:
            self.on_disconnect_callback()
    
    def login(self) -> bool:
        """
        登录行情接口
        
        Returns:
            是否登录成功
        """
        if not self._connected:
            self.logger.error("请先连接行情前置")
            return False
        
        try:
            # 实际环境中：
            # self._md_api.ReqUserLogin({
            #     "BrokerID": self.broker_id,
            #     "UserID": self.user_id,
            #     "Password": self.password,
            #     "AppID": self.app_id,
            #     "AuthCode": self.auth_code,
            # })
            
            # 模拟登录成功
            self.logger.info(f"行情接口登录中: {self.user_id}@{self.broker_id}")
            time.sleep(0.5)
            
            self._logged_in = True
            self.logger.info("行情接口登录成功")
            return True
        
        except Exception as e:
            self.logger.error(f"行情接口登录失败: {e}")
            if self.on_error_callback:
                self.on_error_callback(str(e))
            return False
    
    def subscribe(self, instruments: List[str]) -> bool:
        """
        订阅行情
        
        Args:
            instruments: 合约代码列表
        
        Returns:
            是否订阅成功
        """
        if not self._logged_in:
            self.logger.error("请先登录行情接口")
            return False
        
        try:
            # 实际环境中：
            # self._md_api.SubscribeMarketData(instruments)
            
            self._subscribed.update(instruments)
            self.logger.info(f"订阅行情: {instruments}")
            self.logger.info(f"当前订阅: {self._subscribed}")
            return True
        
        except Exception as e:
            self.logger.error(f"订阅行情失败: {e}")
            return False
    
    def unsubscribe(self, instruments: List[str]) -> bool:
        """
        退订行情
        
        Args:
            instruments: 合约代码列表
        
        Returns:
            是否退订成功
        """
        try:
            # 实际环境中：
            # self._md_api.UnSubscribeMarketData(instruments)
            
            for inst in instruments:
                self._subscribed.discard(inst)
            
            self.logger.info(f"退订行情: {instruments}")
            self.logger.info(f"当前订阅: {self._subscribed}")
            return True
        
        except Exception as e:
            self.logger.error(f"退订行情失败: {e}")
            return False
    
    def get_subscribed(self) -> List[str]:
        """获取已订阅的合约列表"""
        return list(self._subscribed)
    
    def run(self):
        """
        阻塞运行，开始接收行情数据
        此方法会阻塞当前线程，直到调用 stop()
        """
        if not self._logged_in:
            self.logger.error("请先登录行情接口")
            return
        
        self._running = True
        self.logger.info("行情接口开始运行，等待行情数据...")
        
        # 启动模拟数据线程（实际环境中由 CTP 回调触发）
        self._data_thread = threading.Thread(target=self._simulate_data, daemon=True)
        self._data_thread.start()
        
        try:
            while self._running:
                # 从队列获取数据并处理
                try:
                    data = self._data_queue.get(timeout=1)
                    self._process_data(data)
                except Empty:
                    continue
        except KeyboardInterrupt:
            self.logger.info("收到中断信号，停止行情接收")
        finally:
            self.stop()
    
    def stop(self):
        """停止行情接收"""
        self._running = False
        self.logger.info("行情接口已停止")
    
    def run_in_background(self):
        """在后台线程运行（非阻塞）"""
        thread = threading.Thread(target=self.run, daemon=True)
        thread.start()
        return thread
    
    def _simulate_data(self):
        """
        模拟行情数据（仅用于演示）
        实际环境中应使用 CTP 回调函数处理真实数据
        """
        import random
        
        # 模拟价格基准
        base_prices = {
            'cu2506': 70000.0,
            'al2506': 20000.0,
            'ni2506': 130000.0,
            'CF509': 15000.0,
        }
        
        while self._running:
            for instrument in self._subscribed:
                base_price = base_prices.get(instrument, 10000.0)
                tick = TickData(
                    instrument=instrument,
                    datetime=datetime.now(),
                    last_price=round(base_price + random.uniform(-50, 50), 0),
                    volume=random.randint(1, 100),
                    open_interest=random.uniform(10000, 50000),
                    bid_price_1=round(base_price - 10, 0),
                    bid_volume_1=random.randint(1, 50),
                    ask_price_1=round(base_price + 10, 0),
                    ask_volume_1=random.randint(1, 50),
                )
                self._data_queue.put(tick)
            
            time.sleep(1)  # 每秒模拟一次 Tick
    
    def _process_data(self, data):
        """
        处理接收到的数据
        实际环境中由 CTP 回调函数调用此方法
        
        Args:
            data: TickData 或 DepthData 或 KLineData 对象
        """
        if isinstance(data, TickData):
            # 触发 Tick 回调
            if self.on_tick_callback:
                try:
                    self.on_tick_callback(data)
                except Exception as e:
                    self.logger.error(f"on_tick 回调执行失败: {e}")
            
            # 调用子类重写的方法
            try:
                self.on_tick(data)
            except Exception as e:
                self.logger.error(f"on_tick 方法执行失败: {e}")
        
        elif isinstance(data, DepthData):
            if self.on_depth_callback:
                try:
                    self.on_depth_callback(data)
                except Exception as e:
                    self.logger.error(f"on_depth 回调执行失败: {e}")
            
            try:
                self.on_depth(data)
            except Exception as e:
                self.logger.error(f"on_depth 方法执行失败: {e}")
    
    # ========== 可重写的回调方法 ==========
    
    def on_tick(self, tick: TickData):
        """
        Tick 行情回调函数（可重写）
        子类可重写此方法以实现自定义逻辑
        
        Args:
            tick: Tick 行情数据
        """
        pass  # 默认空实现，由子类或回调覆盖
    
    def on_depth(self, depth: DepthData):
        """
        深度行情回调函数（可重写）
        
        Args:
            depth: 深度行情数据
        """
        pass
    
    def on_kline(self, kline: KLineData):
        """
        K 线数据回调函数（可重写）
        
        Args:
            kline: K 线数据
        """
        pass
    
    def on_error(self, error: str):
        """
        错误回调函数（可重写）
        
        Args:
            error: 错误信息
        """
        self.logger.error(f"行情接口错误: {error}")
    
    def on_connect(self):
        """连接成功回调（可重写）"""
        self.logger.info("行情接口连接成功（回调）")
    
    def on_disconnect(self):
        """断开连接回调（可重写）"""
        self.logger.warning("行情接口已断开（回调）")
        
        if self.auto_reconnect:
            self.logger.info(f"{self.reconnect_interval}秒后尝试重连...")
            time.sleep(self.reconnect_interval)
            self.connect()
            if self._connected:
                self.login()
                self.subscribe(list(self._subscribed))
    
    # ========== 属性方法 ==========
    
    @property
    def is_connected(self) -> bool:
        """是否已连接"""
        return self._connected
    
    @property
    def is_logged_in(self) -> bool:
        """是否已登录"""
        return self._logged_in
    
    @property
    def is_running(self) -> bool:
        """是否正在运行"""
        return self._running


# ========== 使用示例 ==========

def example_callback_usage():
    """回调函数使用实例"""
    
    # 方法1：继承并重写回调方法
    class MyMarketData(CTPMarketData):
        def on_tick(self, tick: TickData):
            print(f"[Tick] {tick.instrument}: {tick.last_price} | 量: {tick.volume}")
            
            # 触发存储逻辑
            if hasattr(self, 'storage'):
                self.storage.save_tick(tick)
    
    # 方法2：直接设置回调函数
    md = CTPMarketData(config_path="config/ctp_config.yaml")
    md.on_tick_callback = lambda tick: print(f"Tick: {tick.last_price}")
    md.on_error_callback = lambda err: print(f"错误: {err}")
    
    md.connect()
    md.login()
    md.subscribe(["cu2506", "al2506"])
    md.run()


def example_simple_usage():
    """简单使用实例"""
    md = CTPMarketData(
        front_address="tcp://180.168.146.187:10131",
        broker_id="9999",
        user_id="your_simnow_userid",
        password="your_password",
    )
    
    md.connect()
    md.login()
    md.subscribe(["cu2506", "al2506", "ni2506"])
    
    # 在后台运行
    md.run_in_background()
    
    # 主线程可以做其他事情
    import time
    time.sleep(60)  # 运行 1 分钟
    
    md.stop()


if __name__ == '__main__':
    # 演示模拟运行
    md = CTPMarketData()
    md.connect()
    md.login()
    md.subscribe(["cu2506", "al2506"])
    md.run()
