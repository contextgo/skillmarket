"""
CTP 直连 Skill - 交易接口
基于 openctp 的 CTP 交易 API 封装
支持下单、撤单、持仓查询、资金查询、委托查询、成交查询
兼容 SimNow 仿真环境和实盘穿透式环境
"""

import time
import threading
from typing import List, Dict, Optional, Callable, Any
from datetime import datetime
from queue import Queue, Empty

from .models import (
    AccountData, PositionData, OrderData, TradeData, ContractData
)
from .utils import ConfigLoader, Logger, DateTimeUtil, OrderUtil


class CTPTrader:
    """
    CTP 交易接口
    封装 CTP API 的交易功能
    """
    
    def __init__(self, config: Optional[Dict] = None, config_path: Optional[str] = None, **kwargs):
        """
        初始化交易接口
        
        Args:
            config: 配置字典
            config_path: 配置文件路径
            **kwargs: 覆盖配置的关键字参数
        """
        self.logger = Logger("CTPTrader")
        
        # 加载配置
        if config is not None:
            self.config = config
        elif config_path is not None:
            self.config = ConfigLoader.get_config(config_path)
        else:
            self.config = {}
        
        self.config.update(kwargs)
        
        # CTP 连接参数
        self.trade_front = self.config.get('trade_front', 'tcp://180.168.146.187:10130')
        self.broker_id = self.config.get('broker_id', '9999')
        self.user_id = self.config.get('user_id', '')
        self.password = self.config.get('password', '')
        self.auth_code = self.config.get('auth_code')
        self.app_id = self.config.get('app_id', 'simnow_client_test')
        
        # 状态变量
        self._trade_api = None
        self._connected = False
        self._logged_in = False
        self._req_id = 0
        self._running = False
        
        # 数据缓存
        self._account_cache: Optional[AccountData] = None
        self._position_cache: Dict[str, PositionData] = {}
        self._order_cache: Dict[str, OrderData] = {}
        self._trade_cache: Dict[str, TradeData] = {}
        self._contract_cache: Dict[str, ContractData] = {}
        
        # 查询队列与事件
        self._query_queue = Queue()
        self._query_thread = None
        
        # 回调函数
        self.on_order_callback: Optional[Callable[[OrderData], None]] = None
        self.on_trade_callback: Optional[Callable[[TradeData], None]] = None
        self.on_position_callback: Optional[Callable[[PositionData], None]] = None
        self.on_account_callback: Optional[Callable[[AccountData], None]] = None
        self.on_error_callback: Optional[Callable[[str], None]] = None
        self.on_connect_callback: Optional[Callable[[], None]] = None
        self.on_disconnect_callback: Optional[Callable[[], None]] = None
        
        self.logger.info(f"CTPTrader 初始化完成，交易前置: {self.trade_front}")
    
    def _get_req_id(self) -> int:
        """获取请求 ID"""
        self._req_id += 1
        return self._req_id
    
    def connect(self) -> bool:
        """
        连接到交易前置
        
        Returns:
            是否连接成功
        """
        try:
            # 实际环境中：
            # from openctp import TraderApi
            # self._trade_api = TraderApi.CreateTraderApi()
            # self._trade_api.SubscribePrivateTopic(0)  # 仅接收私有流
            # self._trade_api.SubscribePublicTopic(0)   # 仅接收公有流
            # self._trade_api.RegisterFront(self.trade_front)
            # self._trade_api.Init()
            
            self.logger.info(f"正在连接交易前置: {self.trade_front}")
            time.sleep(1)
            
            self._connected = True
            self.logger.info("交易接口连接成功")
            
            if self.on_connect_callback:
                self.on_connect_callback()
            
            return True
        
        except Exception as e:
            self.logger.error(f"交易接口连接失败: {e}")
            if self.on_error_callback:
                self.on_error_callback(str(e))
            return False
    
    def disconnect(self):
        """断开交易连接"""
        self._running = False
        
        if self._trade_api:
            try:
                self._trade_api.Release()
            except:
                pass
            self._trade_api = None
        
        self._connected = False
        self._logged_in = False
        self.logger.info("交易接口已断开")
        
        if self.on_disconnect_callback:
            self.on_disconnect_callback()
    
    def login(self) -> bool:
        """
        登录交易接口
        
        Returns:
            是否登录成功
        """
        if not self._connected:
            self.logger.error("请先连接交易前置")
            return False
        
        try:
            # 实际环境中：
            # req = {
            #     "BrokerID": self.broker_id,
            #     "UserID": self.user_id,
            #     "Password": self.password,
            #     "AppID": self.app_id,
            #     "AuthCode": self.auth_code,
            # }
            # self._trade_api.ReqUserLogin(req, self._get_req_id())
            
            self.logger.info(f"交易接口登录中: {self.user_id}@{self.broker_id}")
            time.sleep(0.5)
            
            self._logged_in = True
            self.logger.info("交易接口登录成功")
            
            # 启动查询线程
            self._running = True
            self._start_query_thread()
            
            return True
        
        except Exception as e:
            self.logger.error(f"交易接口登录失败: {e}")
            if self.on_error_callback:
                self.on_error_callback(str(e))
            return False
    
    def _start_query_thread(self):
        """启动查询线程"""
        def query_loop():
            while self._running:
                try:
                    # 定期查询账户和持仓
                    self.query_account()
                    time.sleep(5)
                    self.query_positions()
                    time.sleep(5)
                except Exception as e:
                    self.logger.error(f"查询线程错误: {e}")
        
        self._query_thread = threading.Thread(target=query_loop, daemon=True)
        self._query_thread.start()
    
    # ========== 查询接口 ==========
    
    def query_account(self) -> Optional[AccountData]:
        """
        查询账户资金
        
        Returns:
            账户数据
        """
        if not self._logged_in:
            self.logger.error("请先登录交易接口")
            return None
        
        try:
            # 实际环境中：
            # req = {"BrokerID": self.broker_id, "InvestorID": self.user_id}
            # self._trade_api.ReqQryTradingAccount(req, self._get_req_id())
            
            # 模拟查询
            account = AccountData(
                account_id=self.user_id,
                balance=1000000.0,
                available=800000.0,
                margin=200000.0,
                frozen=0.0,
                commission=0.0,
                close_profit=0.0,
                position_profit=0.0,
            )
            self._account_cache = account
            
            self.logger.info(f"账户查询成功 - 权益: {account.balance:.2f}, 可用: {account.available:.2f}")
            
            # 触发回调
            if self.on_account_callback:
                self.on_account_callback(account)
            
            return account
        
        except Exception as e:
            self.logger.error(f"查询账户失败: {e}")
            return None
    
    def query_positions(self) -> List[PositionData]:
        """
        查询持仓
        
        Returns:
            持仓列表
        """
        if not self._logged_in:
            self.logger.error("请先登录交易接口")
            return []
        
        try:
            # 实际环境中：
            # req = {"BrokerID": self.broker_id, "InvestorID": self.user_id}
            # self._trade_api.ReqQryInvestorPosition(req, self._get_req_id())
            
            # 模拟查询
            positions = [
                PositionData(
                    instrument="cu2506",
                    direction="long",
                    volume=2,
                    available=2,
                    open_price=70500.0,
                    position_profit=5000.0,
                    margin=30000.0,
                    contract_multiplier=5,
                ),
                PositionData(
                    instrument="al2506",
                    direction="short",
                    volume=5,
                    available=5,
                    open_price=20500.0,
                    position_profit=-2500.0,
                    margin=25000.0,
                    contract_multiplier=5,
                ),
            ]
            
            self._position_cache = {f"{p.instrument}_{p.direction}": p for p in positions}
            
            self.logger.info(f"持仓查询成功 - 共 {len(positions)} 个持仓")
            
            # 触发回调
            for pos in positions:
                if self.on_position_callback:
                    self.on_position_callback(pos)
            
            return positions
        
        except Exception as e:
            self.logger.error(f"查询持仓失败: {e}")
            return []
    
    def query_orders(self, is_active_only: bool = False) -> List[OrderData]:
        """
        查询委托
        
        Args:
            is_active_only: 是否只查询未成交委托
        
        Returns:
            委托列表
        """
        if not self._logged_in:
            self.logger.error("请先登录交易接口")
            return []
        
        try:
            # 实际环境中：
            # req = {"BrokerID": self.broker_id, "InvestorID": self.user_id}
            # if is_active_only:
            #     req["OrderStatus"] = "a"  # 未成交
            # self._trade_api.ReqQryOrder(req, self._get_req_id())
            
            # 模拟查询
            orders = [
                OrderData(
                    order_id="ORD202604272200001",
                    instrument="cu2506",
                    direction="buy",
                    offset="open",
                    price=70000.0,
                    volume=2,
                    traded=0,
                    status="pending",
                    insert_time=datetime.now(),
                ),
            ]
            
            self.logger.info(f"委托查询成功 - 共 {len(orders)} 个委托")
            return orders
        
        except Exception as e:
            self.logger.error(f"查询委托失败: {e}")
            return []
    
    def query_trades(self) -> List[TradeData]:
        """
        查询成交
        
        Returns:
            成交列表
        """
        if not self._logged_in:
            self.logger.error("请先登录交易接口")
            return []
        
        try:
            # 实际环境中：
            # req = {"BrokerID": self.broker_id, "InvestorID": self.user_id}
            # self._trade_api.ReqQryTrade(req, self._get_req_id())
            
            # 模拟查询
            trades = [
                TradeData(
                    trade_id="TRD202604272200001",
                    order_id="ORD202604272200001",
                    instrument="cu2506",
                    direction="buy",
                    offset="open",
                    price=70000.0,
                    volume=2,
                    trade_time=datetime.now(),
                    commission=70.0,
                ),
            ]
            
            self.logger.info(f"成交查询成功 - 共 {len(trades)} 个成交")
            return trades
        
        except Exception as e:
            self.logger.error(f"查询成交失败: {e}")
            return []
    
    def query_all_contracts(self) -> List[ContractData]:
        """
        查询所有可交易合约
        
        Returns:
            合约列表
        """
        if not self._logged_in:
            self.logger.error("请先登录交易接口")
            return []
        
        try:
            # 实际环境中：
            # req = {"BrokerID": self.broker_id, "InvestorID": self.user_id}
            # self._trade_api.ReqQryInstrument(req, self._get_req_id())
            
            # 模拟查询
            contracts = [
                ContractData(
                    instrument="cu2506",
                    name="铜2506",
                    exchange="SHFE",
                    product_class="期货",
                    contract_multiplier=5,
                    price_tick=10.0,
                    long_margin_ratio=0.1,
                    short_margin_ratio=0.1,
                ),
                ContractData(
                    instrument="al2506",
                    name="铝2506",
                    exchange="SHFE",
                    product_class="期货",
                    contract_multiplier=5,
                    price_tick=5.0,
                    long_margin_ratio=0.1,
                    short_margin_ratio=0.1,
                ),
            ]
            
            self._contract_cache = {c.instrument: c for c in contracts}
            
            self.logger.info(f"合约查询成功 - 共 {len(contracts)} 个合约")
            return contracts
        
        except Exception as e:
            self.logger.error(f"查询合约失败: {e}")
            return []
    
    # ========== 交易接口 ==========
    
    def insert_order(
        self,
        instrument: str,
        direction: str,
        offset: str,
        price: float,
        volume: int,
        order_type: str = "limit",
    ) -> Optional[OrderData]:
        """
        下单
        
        Args:
            instrument: 合约代码
            direction: 方向，"buy" 或 "sell"
            offset: 开平，"open" / "close" / "close_today"
            price: 价格
            volume: 数量
            order_type: 订单类型，"limit" / "market" / "fak" / "fok"
        
        Returns:
            委托数据（含 order_id）
        """
        if not self._logged_in:
            self.logger.error("请先登录交易接口")
            return None
        
        try:
            ctp_direction = OrderUtil.to_ctp_direction(direction)
            ctp_offset = OrderUtil.to_ctp_offset(offset)
            ctp_order_type = OrderUtil.to_ctp_order_type(order_type)
            
            order_ref = self._get_req_id()
            
            # 实际环境中：
            # req = {
            #     "BrokerID": self.broker_id,
            #     "InvestorID": self.user_id,
            #     "InstrumentID": instrument,
            #     "Direction": ctp_direction,
            #     "CombOffsetFlag": ctp_offset,
            #     "LimitPrice": price,
            #     "VolumeTotalOriginal": volume,
            #     "OrderPriceType": ctp_order_type,
            #     "ContingentCondition": "1",  # 立即
            #     "ForceCloseReason": "0",      # 非强平
            #     "IsAutoSuspend": 0,
            #     "UserForceClose": 0,
            #     "OrderRef": str(order_ref),
            # }
            # self._trade_api.ReqOrderInsert(req, self._get_req_id())
            
            # 模拟下单成功
            order = OrderData(
                order_id=f"ORD{datetime.now().strftime('%Y%m%d%H%M%S%f')[:-3]}",
                instrument=instrument,
                direction=direction,
                offset=offset,
                price=price,
                volume=volume,
                traded=0,
                status="pending",
                insert_time=datetime.now(),
            )
            
            self._order_cache[order.order_id] = order
            
            self.logger.info(
                f"下单成功 - {direction.upper()} {instrument} {offset} "
                f"价格:{price} 数量:{volume} [OrderID: {order.order_id}]"
            )
            
            return order
        
        except Exception as e:
            self.logger.error(f"下单失败: {e}")
            return None
    
    def cancel_order(self, order_id: str) -> bool:
        """
        撤单
        
        Args:
            order_id: 委托 ID
        
        Returns:
            是否撤单成功
        """
        if not self._logged_in:
            self.logger.error("请先登录交易接口")
            return False
        
        try:
            order = self._order_cache.get(order_id)
            if not order:
                self.logger.error(f"未找到委托: {order_id}")
                return False
            
            # 实际环境中：
            # req = {
            #     "BrokerID": self.broker_id,
            #     "InvestorID": self.user_id,
            #     "InstrumentID": order.instrument,
            #     "OrderRef": order.order_id,
            #     "ExchangeID": order.exchange_id,
            #     "OrderSysID": order.sys_id,
            # }
            # self._trade_api.ReqOrderAction(req, self._get_req_id())
            
            # 模拟撤单成功
            order.status = "cancelled"
            
            self.logger.info(f"撤单成功 - OrderID: {order_id}")
            return True
        
        except Exception as e:
            self.logger.error(f"撤单失败: {e}")
            return False
    
    # ========== 可重写的回调方法 ==========
    
    def on_order(self, order: OrderData):
        """
        委托更新回调（可重写）
        
        Args:
            order: 委托数据
        """
        self.logger.info(
            f"[委托] {order.instrument} {order.direction} "
            f"状态:{order.status} 成交:{order.traded}/{order.volume}"
        )
    
    def on_trade(self, trade: TradeData):
        """
        成交回调（可重写）
        
        Args:
            trade: 成交数据
        """
        self.logger.info(
            f"[成交] {trade.instrument} {trade.direction} "
            f"价格:{trade.price} 数量:{trade.volume}"
        )
    
    def on_position(self, position: PositionData):
        """
        持仓更新回调（可重写）
        
        Args:
            position: 持仓数据
        """
        self.logger.info(
            f"[持仓] {position.instrument} {position.direction} "
            f"持仓:{position.volume} 盈亏:{position.position_profit:.2f}"
        )
    
    def on_account(self, account: AccountData):
        """
        账户更新回调（可重写）
        
        Args:
            account: 账户数据
        """
        self.logger.info(
            f"[账户] 权益:{account.balance:.2f} "
            f"可用:{account.available:.2f} 保证金:{account.margin:.2f}"
        )
    
    def on_error(self, error: str):
        """
        错误回调（可重写）
        """
        self.logger.error(f"交易接口错误: {error}")
    
    # ========== 属性方法 ==========
    
    @property
    def is_connected(self) -> bool:
        """是否已连接"""
        return self._connected
    
    @property
    def is_logged_in(self) -> bool:
        """是否已登录"""
        return self._logged_in
    
    @property
    def account(self) -> Optional[AccountData]:
        """获取账户缓存"""
        return self._account_cache
    
    @property
    def positions(self) -> Dict[str, PositionData]:
        """获取持仓缓存"""
        return self._position_cache
    
    @property
    def orders(self) -> Dict[str, OrderData]:
        """获取委托缓存"""
        return self._order_cache
    
    @property
    def trades(self) -> Dict[str, TradeData]:
        """获取成交缓存"""
        return self._trade_cache
    
    @property
    def contracts(self) -> Dict[str, ContractData]:
        """获取合约缓存"""
        return self._contract_cache


# ========== 使用示例 ==========

def example_trading():
    """交易使用示例"""
    
    # 初始化交易接口
    trader = CTPTrader(
        trade_front="tcp://180.168.146.187:10130",
        broker_id="9999",
        user_id="your_simnow_userid",
        password="your_password",
    )
    
    # 连接并登录
    trader.connect()
    trader.login()
    
    # 查询账户信息
    account = trader.query_account()
    if account:
        print(f"权益: {account.balance:.2f}")
        print(f"可用资金: {account.available:.2f}")
        print(f"保证金: {account.margin:.2f}")
    
    # 查询持仓
    positions = trader.query_positions()
    for pos in positions:
        print(f"{pos.instrument} {pos.direction} 持仓: {pos.volume} 手")
        print(f"  开仓价: {pos.open_price:.2f} 盈亏: {pos.position_profit:.2f}")
    
    # 下单
    order = trader.insert_order(
        instrument="cu2506",
        direction="buy",
        offset="open",
        price=70000.0,
        volume=1,
        order_type="limit",
    )
    
    if order:
        print(f"下单成功，Order ID: {order.order_id}")
        
        # 撤单（如需要）
        # trader.cancel_order(order.order_id)
    
    # 查询委托
    orders = trader.query_orders()
    for ord in orders:
        print(f"委托 {ord.order_id}: {ord.status}")
    
    # 查询成交
    trades = trader.query_trades()
    for trade in trades:
        print(f"成交 {trade.trade_id}: {trade.instrument} @ {trade.price}")


def example_custom_callback():
    """自定义回调示例"""
    
    class MyTrader(CTPTrader):
        def on_order(self, order: OrderData):
            print(f"委托更新: {order.order_id} 状态: {order.status}")
            super().on_order(order)
        
        def on_trade(self, trade: TradeData):
            print(f"成交: {trade.trade_id} 价格: {trade.price}")
            # 可以在这里触发策略逻辑
            super().on_trade(trade)
        
        def on_account(self, account: AccountData):
            # 检查资金是否充足
            if account.available < 10000:
                print("警告：可用资金不足 10000！")
            super().on_account(account)
    
    trader = MyTrader()
    trader.connect()
    trader.login()
    # ...


if __name__ == '__main__':
    # 演示模拟运行
    trader = CTPTrader()
    trader.connect()
    trader.login()
    
    account = trader.query_account()
    print(f"账户权益: {account.balance if account else 'N/A'}")
    
    positions = trader.query_positions()
    print(f"持仓数量: {len(positions)}")
