"""
测试数据模型
"""

import unittest
from datetime import datetime
from scripts.models import (
    TickData, DepthData, KLineData,
    AccountData, PositionData, OrderData, TradeData, ContractData
)


class TestTickData(unittest.TestCase):
    """测试 TickData 数据模型"""

    def test_tick_creation(self):
        """测试 Tick 数据创建"""
        tick = TickData(
            instrument="cu2506",
            datetime=datetime.now(),
            last_price=70000.0,
            volume=100,
            open_interest=50000.0,
            bid_price_1=69990.0,
            bid_volume_1=50,
            ask_price_1=70010.0,
            ask_volume_1=50,
            upper_limit=75000.0,
            lower_limit=65000.0,
        )
        self.assertEqual(tick.instrument, "cu2506")
        self.assertEqual(tick.last_price, 70000.0)

    def test_tick_default_values(self):
        """测试 Tick 默认值"""
        tick = TickData(
            instrument="cu2506",
            datetime=datetime.now(),
            last_price=70000.0,
            volume=100,
        )
        self.assertEqual(tick.open_interest, 0.0)
        self.assertEqual(tick.bid_volume_1, 0)


class TestAccountData(unittest.TestCase):
    """测试 AccountData 数据模型"""

    def test_account_creation(self):
        """测试账户数据创建"""
        account = AccountData(
            account_id="test_user",
            balance=1000000.0,
            available=800000.0,
            margin=200000.0,
            frozen=0.0,
        )
        self.assertEqual(account.account_id, "test_user")
        self.assertEqual(account.balance, 1000000.0)
        self.assertEqual(account.available, 800000.0)


class TestPositionData(unittest.TestCase):
    """测试 PositionData 数据模型"""

    def test_position_creation(self):
        """测试持仓数据创建"""
        position = PositionData(
            instrument="cu2506",
            direction="long",
            volume=2,
            available=2,
            open_price=70500.0,
            position_profit=5000.0,
        )
        self.assertEqual(position.instrument, "cu2506")
        self.assertEqual(position.direction, "long")
        self.assertEqual(position.volume, 2)


class TestOrderData(unittest.TestCase):
    """测试 OrderData 数据模型"""

    def test_order_creation(self):
        """测试委托数据创建"""
        order = OrderData(
            order_id="ORD20260101120000",
            instrument="cu2506",
            direction="buy",
            offset="open",
            price=70000.0,
            volume=1,
            traded=0,
            status="pending",
            insert_time=datetime.now(),
        )
        self.assertEqual(order.order_id, "ORD20260101120000")
        self.assertEqual(order.status, "pending")


class TestTradeData(unittest.TestCase):
    """测试 TradeData 数据模型"""

    def test_trade_creation(self):
        """测试成交数据创建"""
        trade = TradeData(
            trade_id="TRD20260101120000",
            order_id="ORD20260101120000",
            instrument="cu2506",
            direction="buy",
            offset="open",
            price=70000.0,
            volume=1,
            trade_time=datetime.now(),
        )
        self.assertEqual(trade.trade_id, "TRD20260101120000")
        self.assertEqual(trade.volume, 1)


class TestContractData(unittest.TestCase):
    """测试 ContractData 数据模型"""

    def test_contract_creation(self):
        """测试合约数据创建"""
        contract = ContractData(
            instrument="cu2506",
            name="沪铜2506",
            exchange="SHFE",
            product_class="期货",
            contract_multiplier=5,
            price_tick=10.0,
        )
        self.assertEqual(contract.instrument, "cu2506")
        self.assertEqual(contract.exchange, "SHFE")


if __name__ == '__main__':
    unittest.main()
