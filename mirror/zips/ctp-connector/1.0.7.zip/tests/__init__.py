"""
CTP Connector 单元测试
=====================

运行测试:
    python -m pytest tests/
    python -m pytest tests/ -v

覆盖率测试:
    python -m pytest tests/ --cov=scripts --cov-report=html
"""

import sys
import os

# 添加 scripts 目录到路径
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
