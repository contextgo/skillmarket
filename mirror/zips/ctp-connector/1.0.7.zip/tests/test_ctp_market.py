"""
测试行情接口
"""

import unittest
from unittest.mock import Mock, patch
from scripts.ctp_market import CTPMarketData
from scripts.models import TickData


class TestCTPMarketData(unittest.TestCase):
    """测试 CTP 行情接口"""

    def setUp(self):
        """测试前准备"""
        self.valid_config = {
            "front_address": "tcp://180.168.146.187:10131",
            "broker_id": "9999",
            "user_id": "test_user",
            "password": "test_pass",
        }

    def test_init_with_valid_config(self):
        """测试使用有效配置初始化"""
        md = CTPMarketData(config=self.valid_config)
        self.assertEqual(md.front_address, "tcp://180.168.146.187:10131")
        self.assertEqual(md.broker_id, "9999")
        self.assertEqual(md.user_id, "test_user")

    def test_init_missing_required_config(self):
        """测试缺少必需配置时抛出异常"""
        invalid_config = {
            "broker_id": "9999",
            "user_id": "test_user",
            # 缺少 password
        }
        with self.assertRaises(ValueError) as context:
            CTPMarketData(config=invalid_config)
        self.assertIn("配置项缺失", str(context.exception))

    def test_connect(self):
        """测试连接"""
        md = CTPMarketData(config=self.valid_config)
        result = md.connect()
        self.assertTrue(result)
        self.assertTrue(md.is_connected)

    def test_login_without_connect(self):
        """测试未连接时登录失败"""
        md = CTPMarketData(config=self.valid_config)
        result = md.login()
        self.assertFalse(result)

    def test_login_after_connect(self):
        """测试连接后登录"""
        md = CTPMarketData(config=self.valid_config)
        md.connect()
        result = md.login()
        self.assertTrue(result)
        self.assertTrue(md.is_logged_in)

    def test_subscribe_without_login(self):
        """测试未登录时订阅失败"""
        md = CTPMarketData(config=self.valid_config)
        result = md.subscribe(["cu2506"])
        self.assertFalse(result)

    def test_subscribe_after_login(self):
        """测试登录后订阅"""
        md = CTPMarketData(config=self.valid_config)
        md.connect()
        md.login()
        result = md.subscribe(["cu2506", "al2506"])
        self.assertTrue(result)
        self.assertIn("cu2506", md.get_subscribed())
        self.assertIn("al2506", md.get_subscribed())

    def test_unsubscribe(self):
        """测试退订"""
        md = CTPMarketData(config=self.valid_config)
        md.connect()
        md.login()
        md.subscribe(["cu2506", "al2506"])
        result = md.unsubscribe(["cu2506"])
        self.assertTrue(result)
        self.assertNotIn("cu2506", md.get_subscribed())
        self.assertIn("al2506", md.get_subscribed())

    def test_auto_reconnect_default(self):
        """测试默认自动重连"""
        md = CTPMarketData(config=self.valid_config)
        self.assertTrue(md.auto_reconnect)
        self.assertEqual(md.reconnect_interval, 5)

    def test_custom_reconnect_config(self):
        """测试自定义重连配置"""
        config = {**self.valid_config, "auto_reconnect": False, "reconnect_interval": 10}
        md = CTPMarketData(config=config)
        self.assertFalse(md.auto_reconnect)
        self.assertEqual(md.reconnect_interval, 10)


class TestCTPMarketDataCallbacks(unittest.TestCase):
    """测试行情接口回调"""

    def setUp(self):
        self.valid_config = {
            "front_address": "tcp://180.168.146.187:10131",
            "broker_id": "9999",
            "user_id": "test_user",
            "password": "test_pass",
        }

    def test_on_tick_callback(self):
        """测试 Tick 回调"""
        md = CTPMarketData(config=self.valid_config)
        callback_called = [False]

        def mock_callback(tick):
            callback_called[0] = True

        md.on_tick_callback = mock_callback

        # 模拟 Tick 数据
        tick = TickData(
            instrument="cu2506",
            datetime=__import__('datetime').datetime.now(),
            last_price=70000.0,
            volume=100,
        )
        md._process_data(tick)

        self.assertTrue(callback_called[0])


if __name__ == '__main__':
    unittest.main()
