"""
测试交易接口
"""

import unittest
from scripts.ctp_trade import CTPTrader
from scripts.models import AccountData, PositionData, OrderData


class TestCTPTrader(unittest.TestCase):
    """测试 CTP 交易接口"""

    def setUp(self):
        """测试前准备"""
        self.valid_config = {
            "trade_front": "tcp://180.168.146.187:10130",
            "broker_id": "9999",
            "user_id": "test_user",
            "password": "test_pass",
        }

    def test_init_with_valid_config(self):
        """测试使用有效配置初始化"""
        trader = CTPTrader(config=self.valid_config)
        self.assertEqual(trader.trade_front, "tcp://180.168.146.187:10130")
        self.assertEqual(trader.broker_id, "9999")
        self.assertEqual(trader.user_id, "test_user")

    def test_init_missing_required_config(self):
        """测试缺少必需配置时抛出异常"""
        invalid_config = {
            "broker_id": "9999",
            "user_id": "test_user",
            # 缺少 password
        }
        with self.assertRaises(ValueError) as context:
            CTPTrader(config=invalid_config)
        self.assertIn("配置项缺失", str(context.exception))

    def test_connect(self):
        """测试连接"""
        trader = CTPTrader(config=self.valid_config)
        result = trader.connect()
        self.assertTrue(result)
        self.assertTrue(trader.is_connected)

    def test_login_without_connect(self):
        """测试未连接时登录失败"""
        trader = CTPTrader(config=self.valid_config)
        result = trader.login()
        self.assertFalse(result)

    def test_login_after_connect(self):
        """测试连接后登录"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        result = trader.login()
        self.assertTrue(result)
        self.assertTrue(trader.is_logged_in)

    def test_query_account_without_login(self):
        """测试未登录时查询失败"""
        trader = CTPTrader(config=self.valid_config)
        result = trader.query_account()
        self.assertIsNone(result)

    def test_query_account_after_login(self):
        """测试登录后查询账户"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()
        account = trader.query_account()
        self.assertIsNotNone(account)
        self.assertIsInstance(account, AccountData)
        self.assertEqual(account.account_id, "test_user")

    def test_query_positions(self):
        """测试查询持仓"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()
        positions = trader.query_positions()
        self.assertIsInstance(positions, list)

    def test_query_orders(self):
        """测试查询委托"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()
        orders = trader.query_orders()
        self.assertIsInstance(orders, list)

    def test_query_trades(self):
        """测试查询成交"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()
        trades = trader.query_trades()
        self.assertIsInstance(trades, list)

    def test_insert_order_valid(self):
        """测试有效下单"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()
        order = trader.insert_order(
            instrument="cu2506",
            direction="buy",
            offset="open",
            price=70000.0,
            volume=1,
        )
        self.assertIsNotNone(order)
        self.assertIsInstance(order, OrderData)
        self.assertEqual(order.instrument, "cu2506")
        self.assertEqual(order.direction, "buy")

    def test_insert_order_invalid_direction(self):
        """测试无效方向下单失败"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()
        order = trader.insert_order(
            instrument="cu2506",
            direction="invalid",  # 无效方向
            offset="open",
            price=70000.0,
            volume=1,
        )
        self.assertIsNone(order)

    def test_cancel_order(self):
        """测试撤单"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()
        order = trader.insert_order(
            instrument="cu2506",
            direction="buy",
            offset="open",
            price=70000.0,
            volume=1,
        )
        if order:
            result = trader.cancel_order(order.order_id)
            self.assertTrue(result)

    def test_properties(self):
        """测试属性方法"""
        trader = CTPTrader(config=self.valid_config)
        trader.connect()
        trader.login()

        self.assertFalse(trader.is_connected)  # 已断开模拟
        self.assertFalse(trader.is_logged_in)


class TestCTPTraderCallbacks(unittest.TestCase):
    """测试交易接口回调"""

    def setUp(self):
        self.valid_config = {
            "trade_front": "tcp://180.168.146.187:10130",
            "broker_id": "9999",
            "user_id": "test_user",
            "password": "test_pass",
        }

    def test_on_order_callback(self):
        """测试委托回调"""
        trader = CTPTrader(config=self.valid_config)
        callback_called = [False]

        def mock_callback(order):
            callback_called[0] = True

        trader.on_order_callback = mock_callback
        trader.connect()
        trader.login()

        order = trader.insert_order(
            instrument="cu2506",
            direction="buy",
            offset="open",
            price=70000.0,
            volume=1,
        )

        # 回调会被触发
        self.assertIsNotNone(order)


if __name__ == '__main__':
    unittest.main()
