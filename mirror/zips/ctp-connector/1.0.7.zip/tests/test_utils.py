"""
测试工具函数
"""

import unittest
import os
import tempfile
from scripts.utils import (
    ConfigLoader, Logger, DateTimeUtil, OrderUtil,
    InstrumentUtil, ConfigValidator, HealthChecker,
    mask_sensitive, mask_dict, SENSITIVE_FIELDS
)


class TestMaskSensitive(unittest.TestCase):
    """测试敏感信息脱敏"""

    def test_mask_short_string(self):
        """测试短字符串脱敏"""
        result = mask_sensitive("abc", visible=4)
        self.assertEqual(result, "***")

    def test_mask_long_string(self):
        """测试长字符串脱敏"""
        result = mask_sensitive("password123", visible=4)
        self.assertEqual(result, "pass*******")

    def test_mask_empty_string(self):
        """测试空字符串脱敏"""
        result = mask_sensitive("")
        self.assertEqual(result, "")

    def test_mask_none(self):
        """测试 None 脱敏"""
        result = mask_sensitive(None)
        self.assertEqual(result, "")


class TestMaskDict(unittest.TestCase):
    """测试字典脱敏"""

    def test_mask_dict_password(self):
        """测试密码字段脱敏"""
        data = {"username": "test", "password": "secret123"}
        result = mask_dict(data)
        self.assertEqual(result["username"], "test")
        self.assertEqual(result["password"], "secr********")

    def test_mask_dict_nested(self):
        """测试嵌套字典脱敏"""
        data = {
            "user": {"password": "secret"},
            "api_key": "key123"
        }
        result = mask_dict(data)
        self.assertEqual(result["user"]["password"], "****")
        self.assertEqual(result["api_key"], "key*")


class TestConfigValidator(unittest.TestCase):
    """测试配置验证器"""

    def test_simnow_valid_config(self):
        """测试 SimNow 有效配置"""
        config = {
            "user_id": "test_user",
            "password": "test_pass",
        }
        result = ConfigValidator.validate(config, env="simnow")
        self.assertTrue(result["valid"])
        self.assertEqual(len(result["missing"]), 0)

    def test_simnow_missing_user_id(self):
        """测试 SimNow 缺少 user_id"""
        config = {
            "password": "test_pass",
        }
        result = ConfigValidator.validate(config, env="simnow")
        self.assertFalse(result["valid"])
        self.assertIn("user_id", result["missing"])

    def test_production_valid_config(self):
        """测试实盘有效配置"""
        config = {
            "user_id": "test_user",
            "password": "test_pass",
            "broker_id": "9999",
            "front_address": "tcp://test.com:1234",
            "trade_front": "tcp://test.com:5678",
            "auth_code": "1234567890123456",
        }
        result = ConfigValidator.validate(config, env="production")
        self.assertTrue(result["valid"])

    def test_production_missing_auth_code(self):
        """测试实盘缺少 auth_code"""
        config = {
            "user_id": "test_user",
            "password": "test_pass",
            "broker_id": "9999",
            "front_address": "tcp://test.com:1234",
            "trade_front": "tcp://test.com:5678",
        }
        result = ConfigValidator.validate(config, env="production")
        self.assertFalse(result["valid"])
        self.assertIn("实盘环境必须配置auth_code", result["errors"])


class TestOrderUtil(unittest.TestCase):
    """测试订单工具"""

    def test_validate_direction_valid(self):
        """测试有效方向"""
        self.assertTrue(OrderUtil.validate_direction("buy"))
        self.assertTrue(OrderUtil.validate_direction("sell"))
        self.assertTrue(OrderUtil.validate_direction("BUY"))

    def test_validate_direction_invalid(self):
        """测试无效方向"""
        self.assertFalse(OrderUtil.validate_direction("hold"))

    def test_validate_offset_valid(self):
        """测试有效开平仓"""
        self.assertTrue(OrderUtil.validate_offset("open"))
        self.assertTrue(OrderUtil.validate_offset("close"))
        self.assertTrue(OrderUtil.validate_offset("close_today"))

    def test_validate_order_type_valid(self):
        """测试有效订单类型"""
        self.assertTrue(OrderUtil.validate_order_type("limit"))
        self.assertTrue(OrderUtil.validate_order_type("market"))
        self.assertTrue(OrderUtil.validate_order_type("fok"))
        self.assertTrue(OrderUtil.validate_order_type("fak"))

    def test_to_ctp_direction(self):
        """测试转换为 CTP 方向代码"""
        self.assertEqual(OrderUtil.to_ctp_direction("buy"), "0")
        self.assertEqual(OrderUtil.to_ctp_direction("sell"), "1")


class TestInstrumentUtil(unittest.TestCase):
    """测试合约工具"""

    def test_normalize_instrument(self):
        """测试合约标准化"""
        self.assertEqual(InstrumentUtil.normalize_instrument("CU2506"), "cu2506")
        self.assertEqual(InstrumentUtil.normalize_instrument(" cu2506 "), "cu2506")

    def test_get_exchange_shfe(self):
        """测试获取上期所"""
        self.assertEqual(InstrumentUtil.get_exchange("cu2506"), "SHFE")
        self.assertEqual(InstrumentUtil.get_exchange("au2506"), "SHFE")

    def test_get_exchange_dce(self):
        """测试获取大商所"""
        self.assertEqual(InstrumentUtil.get_exchange("m2506"), "DCE")
        self.assertEqual(InstrumentUtil.get_exchange("i2506"), "DCE")

    def test_format_instrument(self):
        """测试格式化合约"""
        result = InstrumentUtil.format_instrument("cu2506", "SHFE")
        self.assertEqual(result, "SHFE.cu2506")


class TestDateTimeUtil(unittest.TestCase):
    """测试日期时间工具"""

    def test_today_format(self):
        """测试日期格式"""
        today = DateTimeUtil.today()
        self.assertEqual(len(today), 10)
        self.assertEqual(today.count('-'), 2)

    def test_timestamp_format(self):
        """测试时间戳格式"""
        ts = DateTimeUtil.timestamp()
        self.assertEqual(len(ts), 14)
        self.assertTrue(ts.isdigit())


class TestHealthChecker(unittest.TestCase):
    """测试健康检查器"""

    def test_system_check(self):
        """测试系统检查"""
        result = HealthChecker.system_check()
        self.assertEqual(result["status"], "ok")
        self.assertIn("platform", result)
        self.assertIn("python_version", result)


if __name__ == '__main__':
    unittest.main()
