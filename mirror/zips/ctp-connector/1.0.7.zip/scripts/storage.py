"""
CTP 直连 Skill - 数据存储模块
支持 CSV、JSON、SQLite、MySQL、MongoDB 等多种存储方式
"""

import os
import json
import csv
from typing import List, Optional, Dict, Any
from datetime import datetime
from pathlib import Path

from .models import TickData, TradeData, OrderData, PositionData, AccountData
from .utils import Logger, ensure_dir


class BaseStorage:
    """存储基类"""
    
    def __init__(self):
        self.logger = Logger(self.__class__.__name__)
    
    def save_tick(self, tick: TickData) -> bool:
        """保存 Tick 数据"""
        raise NotImplementedError
    
    def save_trade(self, trade: TradeData) -> bool:
        """保存成交数据"""
        raise NotImplementedError
    
    def save_order(self, order: OrderData) -> bool:
        """保存委托数据"""
        raise NotImplementedError
    
    def save_position(self, position: PositionData) -> bool:
        """保存持仓数据"""
        raise NotImplementedError
    
    def save_account(self, account: AccountData) -> bool:
        """保存账户数据"""
        raise NotImplementedError
    
    def close(self):
        """关闭存储连接"""
        pass


class CSVStorage(BaseStorage):
    """
    CSV 文件存储
    适合简单场景，按日期分文件存储
    """
    
    def __init__(self, path: str = "./data", format: str = "csv"):
        """
        Args:
            path: 存储路径
            format: 文件格式，csv 或 json
        """
        super().__init__()
        self.path = Path(path)
        self.format = format.lower()
        ensure_dir(self.path)
        
        # 文件句柄缓存
        self._files: Dict[str, Any] = {}
        self._writers: Dict[str, Any] = {}
    
    def _get_file_path(self, instrument: str, data_type: str) -> Path:
        """获取文件路径"""
        today = datetime.now().strftime('%Y%m%d')
        filename = f"{instrument}_{data_type}_{today}.{self.format}"
        return self.path / filename
    
    def _get_writer(self, instrument: str, data_type: str, fieldnames: List[str]):
        """获取或创建 CSV writer"""
        key = f"{instrument}_{data_type}"
        
        if key not in self._writers:
            filepath = self._get_file_path(instrument, data_type)
            file_exists = filepath.exists()
            
            f = open(filepath, 'a', newline='', encoding='utf-8')
            self._files[key] = f
            
            if self.format == 'csv':
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                if not file_exists:
                    writer.writeheader()
                self._writers[key] = writer
            else:
                self._writers[key] = f
        
        return self._writers[key]
    
    def save_tick(self, tick: TickData) -> bool:
        """保存 Tick 数据到 CSV"""
        try:
            data = tick.to_dict()
            fieldnames = list(data.keys())
            
            if self.format == 'csv':
                writer = self._get_writer(tick.instrument, 'tick', fieldnames)
                writer.writerow(data)
            else:
                filepath = self._get_file_path(tick.instrument, 'tick')
                with open(filepath, 'a', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                    f.write('\n')
            
            return True
        except Exception as e:
            self.logger.error(f"保存 Tick 失败: {e}")
            return False
    
    def save_trade(self, trade: TradeData) -> bool:
        """保存成交数据"""
        try:
            data = trade.to_dict()
            
            if self.format == 'csv':
                fieldnames = list(data.keys())
                writer = self._get_writer(trade.instrument, 'trade', fieldnames)
                writer.writerow(data)
            else:
                filepath = self._get_file_path(trade.instrument, 'trade')
                with open(filepath, 'a', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                    f.write('\n')
            
            return True
        except Exception as e:
            self.logger.error(f"保存 Trade 失败: {e}")
            return False
    
    def save_order(self, order: OrderData) -> bool:
        """保存委托数据"""
        try:
            data = order.to_dict()
            
            if self.format == 'csv':
                fieldnames = list(data.keys())
                writer = self._get_writer(order.instrument, 'order', fieldnames)
                writer.writerow(data)
            else:
                filepath = self._get_file_path(order.instrument, 'order')
                with open(filepath, 'a', encoding='utf-8') as f:
                    json.dump(data, f, ensure_ascii=False)
                    f.write('\n')
            
            return True
        except Exception as e:
            self.logger.error(f"保存 Order 失败: {e}")
            return False
    
    def save_position(self, position: PositionData) -> bool:
        """保存持仓数据（快照）"""
        try:
            data = position.to_dict()
            filepath = self.path / f"position_{datetime.now().strftime('%Y%m%d')}.json"
            
            # 读取现有数据
            positions = []
            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    positions = json.load(f)
            
            # 更新或添加
            key = f"{position.instrument}_{position.direction}"
            updated = False
            for i, p in enumerate(positions):
                if f"{p['instrument']}_{p['direction']}" == key:
                    positions[i] = data
                    updated = True
                    break
            
            if not updated:
                positions.append(data)
            
            # 写回文件
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(positions, f, ensure_ascii=False, indent=2)
            
            return True
        except Exception as e:
            self.logger.error(f"保存 Position 失败: {e}")
            return False
    
    def save_account(self, account: AccountData) -> bool:
        """保存账户数据（快照）"""
        try:
            data = account.to_dict()
            filepath = self.path / f"account_{datetime.now().strftime('%Y%m%d')}.json"
            
            # 追加模式
            accounts = []
            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    accounts = json.load(f)
            
            accounts.append({
                **data,
                'timestamp': datetime.now().isoformat()
            })
            
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(accounts, f, ensure_ascii=False, indent=2)
            
            return True
        except Exception as e:
            self.logger.error(f"保存 Account 失败: {e}")
            return False
    
    def close(self):
        """关闭所有文件句柄"""
        for f in self._files.values():
            try:
                f.close()
            except:
                pass
        self._files.clear()
        self._writers.clear()


class SQLStorage(BaseStorage):
    """
    SQL 数据库存储（SQLite / MySQL）
    使用 SQLAlchemy 进行 ORM 操作
    """
    
    def __init__(self, connection: str = "sqlite:///ctp_data.db"):
        """
        Args:
            connection: 数据库连接字符串
                - SQLite: sqlite:///path/to/db.db
                - MySQL: mysql+pymysql://user:pass@host/dbname
        """
        super().__init__()
        self.connection = connection
        
        try:
            from sqlalchemy import create_engine, Column, String, Float, Integer, DateTime
            from sqlalchemy.ext.declarative import declarative_base
            from sqlalchemy.orm import sessionmaker
            
            self.engine = create_engine(connection, echo=False)
            self.Session = sessionmaker(bind=self.engine)
            self.Base = declarative_base()
            
            # 定义表结构
            self._define_tables()
            
            # 创建表
            self.Base.metadata.create_all(self.engine)
            
            self.logger.info(f"数据库连接成功: {connection}")
        
        except ImportError:
            self.logger.error("请先安装 SQLAlchemy: pip install sqlalchemy")
            raise
        except Exception as e:
            self.logger.error(f"数据库连接失败: {e}")
            raise
    
    def _define_tables(self):
        """定义数据库表结构"""
        Base = self.Base
        
        class TickTable(Base):
            __tablename__ = 'ticks'
            id = Column(Integer, primary_key=True)
            instrument = Column(String(20), index=True)
            datetime = Column(DateTime, index=True)
            last_price = Column(Float)
            volume = Column(Integer)
            open_interest = Column(Float)
            bid_price_1 = Column(Float)
            bid_volume_1 = Column(Integer)
            ask_price_1 = Column(Float)
            ask_volume_1 = Column(Integer)
        
        class TradeTable(Base):
            __tablename__ = 'trades'
            id = Column(Integer, primary_key=True)
            trade_id = Column(String(50), unique=True)
            order_id = Column(String(50))
            instrument = Column(String(20), index=True)
            direction = Column(String(10))
            offset = Column(String(20))
            price = Column(Float)
            volume = Column(Integer)
            trade_time = Column(DateTime)
            commission = Column(Float)
        
        class OrderTable(Base):
            __tablename__ = 'orders'
            id = Column(Integer, primary_key=True)
            order_id = Column(String(50), unique=True)
            instrument = Column(String(20), index=True)
            direction = Column(String(10))
            offset = Column(String(20))
            price = Column(Float)
            volume = Column(Integer)
            traded = Column(Integer)
            status = Column(String(20))
            insert_time = Column(DateTime)
        
        self.TickTable = TickTable
        self.TradeTable = TradeTable
        self.OrderTable = OrderTable
    
    def save_tick(self, tick: TickData) -> bool:
        """保存 Tick 到数据库"""
        try:
            session = self.Session()
            record = self.TickTable(
                instrument=tick.instrument,
                datetime=tick.datetime,
                last_price=tick.last_price,
                volume=tick.volume,
                open_interest=tick.open_interest,
                bid_price_1=tick.bid_price_1,
                bid_volume_1=tick.bid_volume_1,
                ask_price_1=tick.ask_price_1,
                ask_volume_1=tick.ask_volume_1,
            )
            session.add(record)
            session.commit()
            session.close()
            return True
        except Exception as e:
            self.logger.error(f"保存 Tick 到数据库失败: {e}")
            return False
    
    def save_trade(self, trade: TradeData) -> bool:
        """保存成交到数据库"""
        try:
            session = self.Session()
            record = self.TradeTable(
                trade_id=trade.trade_id,
                order_id=trade.order_id,
                instrument=trade.instrument,
                direction=trade.direction,
                offset=trade.offset,
                price=trade.price,
                volume=trade.volume,
                trade_time=trade.trade_time,
                commission=trade.commission,
            )
            session.add(record)
            session.commit()
            session.close()
            return True
        except Exception as e:
            self.logger.error(f"保存 Trade 到数据库失败: {e}")
            return False
    
    def save_order(self, order: OrderData) -> bool:
        """保存委托到数据库"""
        try:
            session = self.Session()
            
            # 检查是否已存在
            existing = session.query(self.OrderTable).filter_by(order_id=order.order_id).first()
            
            if existing:
                # 更新
                existing.traded = order.traded
                existing.status = order.status
            else:
                # 新建
                record = self.OrderTable(
                    order_id=order.order_id,
                    instrument=order.instrument,
                    direction=order.direction,
                    offset=order.offset,
                    price=order.price,
                    volume=order.volume,
                    traded=order.traded,
                    status=order.status,
                    insert_time=order.insert_time,
                )
                session.add(record)
            
            session.commit()
            session.close()
            return True
        except Exception as e:
            self.logger.error(f"保存 Order 到数据库失败: {e}")
            return False
    
    def query_ticks(self, instrument: str, start: datetime, end: datetime) -> List[TickData]:
        """查询 Tick 数据"""
        try:
            session = self.Session()
            records = session.query(self.TickTable).filter(
                self.TickTable.instrument == instrument,
                self.TickTable.datetime >= start,
                self.TickTable.datetime <= end,
            ).all()
            
            ticks = []
            for r in records:
                ticks.append(TickData(
                    instrument=r.instrument,
                    datetime=r.datetime,
                    last_price=r.last_price,
                    volume=r.volume,
                    open_interest=r.open_interest,
                    bid_price_1=r.bid_price_1,
                    bid_volume_1=r.bid_volume_1,
                    ask_price_1=r.ask_price_1,
                    ask_volume_1=r.ask_volume_1,
                ))
            
            session.close()
            return ticks
        except Exception as e:
            self.logger.error(f"查询 Tick 失败: {e}")
            return []


class MongoStorage(BaseStorage):
    """
    MongoDB 存储
    适合高频数据写入和灵活查询
    """
    
    def __init__(self, uri: str = "mongodb://localhost:27017", db: str = "ctp_data"):
        """
        Args:
            uri: MongoDB 连接 URI
            db: 数据库名称
        """
        super().__init__()
        self.uri = uri
        self.db_name = db
        
        try:
            from pymongo import MongoClient, ASCENDING
            
            self.client = MongoClient(uri)
            self.db = self.client[db]
            
            # 创建索引
            self.db.ticks.create_index([("instrument", ASCENDING), ("datetime", ASCENDING)])
            self.db.trades.create_index([("instrument", ASCENDING), ("trade_time", ASCENDING)])
            self.db.orders.create_index([("order_id", ASCENDING)])
            
            self.logger.info(f"MongoDB 连接成功: {uri}/{db}")
        
        except ImportError:
            self.logger.error("请先安装 pymongo: pip install pymongo")
            raise
        except Exception as e:
            self.logger.error(f"MongoDB 连接失败: {e}")
            raise
    
    def save_tick(self, tick: TickData) -> bool:
        """保存 Tick 到 MongoDB"""
        try:
            self.db.ticks.insert_one(tick.to_dict())
            return True
        except Exception as e:
            self.logger.error(f"保存 Tick 到 MongoDB 失败: {e}")
            return False
    
    def save_trade(self, trade: TradeData) -> bool:
        """保存成交到 MongoDB"""
        try:
            self.db.trades.insert_one(trade.to_dict())
            return True
        except Exception as e:
            self.logger.error(f"保存 Trade 到 MongoDB 失败: {e}")
            return False
    
    def save_order(self, order: OrderData) -> bool:
        """保存委托到 MongoDB"""
        try:
            self.db.orders.update_one(
                {"order_id": order.order_id},
                {"$set": order.to_dict()},
                upsert=True
            )
            return True
        except Exception as e:
            self.logger.error(f"保存 Order 到 MongoDB 失败: {e}")
            return False
    
    def save_position(self, position: PositionData) -> bool:
        """保存持仓到 MongoDB"""
        try:
            key = f"{position.instrument}_{position.direction}"
            self.db.positions.update_one(
                {"_id": key},
                {"$set": position.to_dict()},
                upsert=True
            )
            return True
        except Exception as e:
            self.logger.error(f"保存 Position 到 MongoDB 失败: {e}")
            return False
    
    def save_account(self, account: AccountData) -> bool:
        """保存账户到 MongoDB"""
        try:
            self.db.accounts.insert_one({
                **account.to_dict(),
                "timestamp": datetime.now()
            })
            return True
        except Exception as e:
            self.logger.error(f"保存 Account 到 MongoDB 失败: {e}")
            return False
    
    def close(self):
        """关闭 MongoDB 连接"""
        if hasattr(self, 'client'):
            self.client.close()


# ========== 使用示例 ==========

def example_csv_storage():
    """CSV 存储示例"""
    storage = CSVStorage(path="./data/csv", format="csv")
    
    tick = TickData(
        instrument="cu2506",
        datetime=datetime.now(),
        last_price=70500.0,
        volume=100,
        open_interest=50000.0,
    )
    
    storage.save_tick(tick)
    storage.close()


def example_sql_storage():
    """SQL 存储示例"""
    storage = SQLStorage(connection="sqlite:///ctp_data.db")
    
    tick = TickData(
        instrument="cu2506",
        datetime=datetime.now(),
        last_price=70500.0,
        volume=100,
        open_interest=50000.0,
    )
    
    storage.save_tick(tick)
    
    # 查询
    ticks = storage.query_ticks(
        instrument="cu2506",
        start=datetime(2025, 4, 1),
        end=datetime(2025, 4, 30),
    )
    print(f"查询到 {len(ticks)} 条 Tick")


def example_mongo_storage():
    """MongoDB 存储示例"""
    storage = MongoStorage(uri="mongodb://localhost:27017", db="ctp_data")
    
    tick = TickData(
        instrument="cu2506",
        datetime=datetime.now(),
        last_price=70500.0,
        volume=100,
        open_interest=50000.0,
    )
    
    storage.save_tick(tick)
    storage.close()


if __name__ == '__main__':
    example_csv_storage()
