"""
CTP 直连 Skill - 回测支持模块
支持行情数据录制、回放、以及回测框架集成
"""

import os
import json
import csv
from typing import List, Iterator, Optional, Callable, Dict
from datetime import datetime, timedelta
from pathlib import Path

from .models import TickData, TradeData, OrderData, KLineData
from .utils import Logger, DateTimeUtil


class DataRecorder:
    """
    行情数据录制器
    录制 CTP 行情数据到本地文件，用于后续回测
    """
    
    def __init__(
        self,
        config_path: str = "config/ctp_config.yaml",
        instruments: List[str] = None,
        output_path: str = "./data/recording",
        format: str = "csv",
        duration: Optional[str] = None,
    ):
        """
        初始化数据录制器
        
        Args:
            config_path: CTP 配置文件路径
            instruments: 要录制的合约列表
            output_path: 输出路径
            format: 文件格式，csv / json / parquet
            duration: 录制时长，如 "1h", "1d", "30m"
        """
        self.logger = Logger("DataRecorder")
        self.config_path = config_path
        self.instruments = instruments or []
        self.output_path = Path(output_path)
        self.format = format.lower()
        self.duration = duration
        
        self.output_path.mkdir(parents=True, exist_ok=True)
        
        self._running = False
        self._start_time = None
        self._files: Dict[str, Any] = {}
        self._writers: Dict[str, Any] = {}
    
    def _get_file_path(self, instrument: str) -> Path:
        """获取录制文件路径"""
        date_str = datetime.now().strftime('%Y%m%d')
        filename = f"{instrument}_{date_str}.{self.format}"
        return self.output_path / filename
    
    def _get_writer(self, instrument: str, fieldnames: List[str]):
        """获取或创建文件 writer"""
        if instrument not in self._writers:
            filepath = self._get_file_path(instrument)
            file_exists = filepath.exists()
            
            f = open(filepath, 'a', newline='', encoding='utf-8')
            self._files[instrument] = f
            
            if self.format == 'csv':
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                if not file_exists:
                    writer.writeheader()
                self._writers[instrument] = writer
            else:
                self._writers[instrument] = f
        
        return self._writers[instrument]
    
    def _parse_duration(self, duration: str) -> timedelta:
        """解析时长字符串"""
        if not duration:
            return timedelta(days=1)
        
        unit = duration[-1]
        value = int(duration[:-1])
        
        if unit == 's':
            return timedelta(seconds=value)
        elif unit == 'm':
            return timedelta(minutes=value)
        elif unit == 'h':
            return timedelta(hours=value)
        elif unit == 'd':
            return timedelta(days=value)
        else:
            return timedelta(days=1)
    
    def run(self):
        """
        开始录制
        此方法会阻塞直到录制完成
        """
        from .ctp_market import CTPMarketData
        
        self._running = True
        self._start_time = datetime.now()
        
        # 初始化行情接口
        md = CTPMarketData(config_path=self.config_path)
        
        # 设置回调
        md.on_tick_callback = self._on_tick
        
        # 连接并订阅
        if not md.connect():
            self.logger.error("行情连接失败")
            return
        
        if not md.login():
            self.logger.error("行情登录失败")
            return
        
        md.subscribe(self.instruments)
        
        self.logger.info(f"开始录制 {self.instruments}，时长: {self.duration or '无限'}")
        
        # 计算结束时间
        end_time = None
        if self.duration:
            end_time = self._start_time + self._parse_duration(self.duration)
        
        try:
            while self._running:
                # 检查是否超时
                if end_time and datetime.now() >= end_time:
                    self.logger.info("录制时长到达，停止录制")
                    break
                
                # 简单轮询
                import time
                time.sleep(0.1)
        
        except KeyboardInterrupt:
            self.logger.info("收到中断信号，停止录制")
        
        finally:
            md.disconnect()
            self._close_files()
            self.logger.info("录制结束")
    
    def _on_tick(self, tick: TickData):
        """Tick 数据回调"""
        try:
            data = tick.to_dict()
            fieldnames = list(data.keys())
            
            if self.format == 'csv':
                writer = self._get_writer(tick.instrument, fieldnames)
                writer.writerow(data)
            elif self.format == 'json':
                f = self._files.get(tick.instrument)
                if not f:
                    filepath = self._get_file_path(tick.instrument)
                    f = open(filepath, 'a', encoding='utf-8')
                    self._files[tick.instrument] = f
                json.dump(data, f, ensure_ascii=False)
                f.write('\n')
            
            # 每 100 条打印一次日志
            if tick.volume % 100 == 0:
                self.logger.info(f"录制 {tick.instrument}: {tick.last_price}")
        
        except Exception as e:
            self.logger.error(f"录制 Tick 失败: {e}")
    
    def _close_files(self):
        """关闭所有文件"""
        for f in self._files.values():
            try:
                f.close()
            except:
                pass
        self._files.clear()
        self._writers.clear()
    
    def stop(self):
        """停止录制"""
        self._running = False


class DataPlayback:
    """
    行情数据回放器
    从本地文件读取历史行情数据，用于回测
    """
    
    def __init__(
        self,
        data_path: str,
        speed: float = 1.0,
        start_time: Optional[datetime] = None,
        end_time: Optional[datetime] = None,
    ):
        """
        初始化数据回放器
        
        Args:
            data_path: 数据文件路径或目录
            speed: 回放速度，1.0 表示原速，2.0 表示 2 倍速
            start_time: 开始时间过滤
            end_time: 结束时间过滤
        """
        self.logger = Logger("DataPlayback")
        self.data_path = Path(data_path)
        self.speed = speed
        self.start_time = start_time
        self.end_time = end_time
        
        self._data_cache: List[TickData] = []
        self._current_index = 0
        self._last_timestamp = None
    
    def load(self) -> List[TickData]:
        """
        加载数据文件
        
        Returns:
            Tick 数据列表
        """
        ticks = []
        
        if self.data_path.is_file():
            files = [self.data_path]
        else:
            files = list(self.data_path.glob("*.csv")) + list(self.data_path.glob("*.json"))
        
        for filepath in files:
            self.logger.info(f"加载数据文件: {filepath}")
            
            if filepath.suffix == '.csv':
                ticks.extend(self._load_csv(filepath))
            elif filepath.suffix == '.json':
                ticks.extend(self._load_json(filepath))
        
        # 按时间排序
        ticks.sort(key=lambda x: x.datetime)
        
        # 时间过滤
        if self.start_time:
            ticks = [t for t in ticks if t.datetime >= self.start_time]
        if self.end_time:
            ticks = [t for t in ticks if t.datetime <= self.end_time]
        
        self._data_cache = ticks
        self.logger.info(f"共加载 {len(ticks)} 条 Tick 数据")
        
        return ticks
    
    def _load_csv(self, filepath: Path) -> List[TickData]:
        """加载 CSV 文件"""
        ticks = []
        with open(filepath, 'r', encoding='utf-8') as f:
            reader = csv.DictReader(f)
            for row in reader:
                try:
                    tick = TickData.from_dict(row)
                    ticks.append(tick)
                except Exception as e:
                    self.logger.warning(f"解析行失败: {e}")
        return ticks
    
    def _load_json(self, filepath: Path) -> List[TickData]:
        """加载 JSON 文件"""
        ticks = []
        with open(filepath, 'r', encoding='utf-8') as f:
            for line in f:
                try:
                    data = json.loads(line.strip())
                    tick = TickData.from_dict(data)
                    ticks.append(tick)
                except Exception as e:
                    self.logger.warning(f"解析行失败: {e}")
        return ticks
    
    def __iter__(self) -> Iterator[TickData]:
        """迭代器接口"""
        return self
    
    def __next__(self) -> TickData:
        """获取下一条数据"""
        import time
        
        if self._current_index >= len(self._data_cache):
            raise StopIteration
        
        tick = self._data_cache[self._current_index]
        
        # 模拟时间延迟
        if self._last_timestamp and self.speed > 0:
            time_diff = (tick.datetime - self._last_timestamp).total_seconds()
            sleep_time = time_diff / self.speed
            if sleep_time > 0:
                time.sleep(min(sleep_time, 1))  # 最多等待 1 秒
        
        self._last_timestamp = tick.datetime
        self._current_index += 1
        
        return tick
    
    def reset(self):
        """重置回放位置"""
        self._current_index = 0
        self._last_timestamp = None
    
    def seek(self, timestamp: datetime):
        """跳转到指定时间"""
        for i, tick in enumerate(self._data_cache):
            if tick.datetime >= timestamp:
                self._current_index = i
                break


class BacktestEngine:
    """
    回测引擎
    整合数据回放、策略执行、结果统计
    """
    
    def __init__(
        self,
        data_path: str,
        initial_capital: float = 1000000.0,
        commission_rate: float = 0.0001,
        slippage: float = 0.0,
    ):
        """
        初始化回测引擎
        
        Args:
            data_path: 数据文件路径
            initial_capital: 初始资金
            commission_rate: 手续费率
            slippage: 滑点
        """
        self.logger = Logger("BacktestEngine")
        self.data_path = data_path
        self.initial_capital = initial_capital
        self.commission_rate = commission_rate
        self.slippage = slippage
        
        self.playback = DataPlayback(data_path)
        self.strategy: Optional[Callable] = None
        
        # 回测状态
        self.current_time: Optional[datetime] = None
        self.capital = initial_capital
        self.positions: Dict[str, Dict] = {}
        self.orders: List[OrderData] = []
        self.trades: List[TradeData] = []
        self.daily_stats: List[Dict] = []
        
        # 净值曲线
        self.nav_history: List[Dict] = []
    
    def set_strategy(self, strategy: Callable):
        """
        设置策略函数
        
        Args:
            strategy: 策略函数，接收 (tick, context) 参数
        """
        self.strategy = strategy
    
    def run(self):
        """
        运行回测
        """
        if not self.strategy:
            self.logger.error("请先设置策略")
            return
        
        # 加载数据
        self.playback.load()
        
        self.logger.info("开始回测...")
        
        for tick in self.playback:
            self.current_time = tick.datetime
            
            # 更新持仓市值
            self._update_positions(tick)
            
            # 执行策略
            context = self._create_context()
            self.strategy(tick, context)
            
            # 记录净值
            self._record_nav()
        
        self.logger.info("回测结束")
        self._generate_report()
    
    def _update_positions(self, tick: TickData):
        """更新持仓市值"""
        for instrument, pos in self.positions.items():
            if instrument == tick.instrument:
                pos['current_price'] = tick.last_price
                pos['market_value'] = pos['volume'] * tick.last_price
                pos['pnl'] = (tick.last_price - pos['open_price']) * pos['volume']
    
    def _create_context(self):
        """创建策略上下文"""
        return {
            'capital': self.capital,
            'positions': self.positions,
            'orders': self.orders,
            'trades': self.trades,
            'buy': self._buy,
            'sell': self._sell,
            'get_position': self._get_position,
        }
    
    def _buy(self, instrument: str, price: float, volume: int):
        """买入（回测模拟）"""
        cost = price * volume
        commission = cost * self.commission_rate
        total_cost = cost + commission
        
        if total_cost > self.capital:
            self.logger.warning(f"资金不足，无法买入 {instrument}")
            return
        
        self.capital -= total_cost
        
        if instrument not in self.positions:
            self.positions[instrument] = {
                'volume': 0,
                'open_price': price,
            }
        
        self.positions[instrument]['volume'] += volume
        
        # 记录订单
        order = OrderData(
            order_id=f"BT{len(self.orders)+1}",
            instrument=instrument,
            direction="buy",
            offset="open",
            price=price,
            volume=volume,
            traded=volume,
            status="filled",
            insert_time=self.current_time,
        )
        self.orders.append(order)
        
        # 记录成交
        trade = TradeData(
            trade_id=f"TR{len(self.trades)+1}",
            order_id=order.order_id,
            instrument=instrument,
            direction="buy",
            offset="open",
            price=price,
            volume=volume,
            trade_time=self.current_time,
            commission=commission,
        )
        self.trades.append(trade)
        
        self.logger.info(f"买入 {instrument} {volume} @ {price}")
    
    def _sell(self, instrument: str, price: float, volume: int):
        """卖出（回测模拟）"""
        pos = self.positions.get(instrument)
        if not pos or pos['volume'] < volume:
            self.logger.warning(f"持仓不足，无法卖出 {instrument}")
            return
        
        proceeds = price * volume
        commission = proceeds * self.commission_rate
        net_proceeds = proceeds - commission
        
        self.capital += net_proceeds
        pos['volume'] -= volume
        
        if pos['volume'] == 0:
            del self.positions[instrument]
        
        # 记录订单
        order = OrderData(
            order_id=f"BT{len(self.orders)+1}",
            instrument=instrument,
            direction="sell",
            offset="close",
            price=price,
            volume=volume,
            traded=volume,
            status="filled",
            insert_time=self.current_time,
        )
        self.orders.append(order)
        
        # 记录成交
        trade = TradeData(
            trade_id=f"TR{len(self.trades)+1}",
            order_id=order.order_id,
            instrument=instrument,
            direction="sell",
            offset="close",
            price=price,
            volume=volume,
            trade_time=self.current_time,
            commission=commission,
        )
        self.trades.append(trade)
        
        self.logger.info(f"卖出 {instrument} {volume} @ {price}")
    
    def _get_position(self, instrument: str) -> Dict:
        """获取持仓"""
        return self.positions.get(instrument, {'volume': 0})
    
    def _record_nav(self):
        """记录净值"""
        position_value = sum(
            pos.get('market_value', 0)
            for pos in self.positions.values()
        )
        
        total_value = self.capital + position_value
        
        self.nav_history.append({
            'datetime': self.current_time,
            'capital': self.capital,
            'position_value': position_value,
            'total_value': total_value,
            'positions': len(self.positions),
        })
    
    def _generate_report(self):
        """生成回测报告"""
        if not self.nav_history:
            return
        
        initial = self.nav_history[0]['total_value']
        final = self.nav_history[-1]['total_value']
        
        total_return = (final - initial) / initial
        
        self.logger.info("=" * 50)
        self.logger.info("回测报告")
        self.logger.info("=" * 50)
        self.logger.info(f"初始资金: {initial:,.2f}")
        self.logger.info(f"最终资金: {final:,.2f}")
        self.logger.info(f"总收益率: {total_return*100:.2f}%")
        self.logger.info(f"总交易次数: {len(self.trades)}")
        self.logger.info(f"总委托次数: {len(self.orders)}")
        self.logger.info("=" * 50)
    
    def save_report(self, path: str):
        """保存回测报告"""
        report = {
            'initial_capital': self.initial_capital,
            'final_capital': self.capital,
            'total_trades': len(self.trades),
            'total_orders': len(self.orders),
            'nav_history': self.nav_history,
            'trades': [t.to_dict() for t in self.trades],
        }
        
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        
        self.logger.info(f"报告已保存: {path}")


# ========== 使用示例 ==========

def example_recording():
    """录制数据示例"""
    recorder = DataRecorder(
        config_path="config/ctp_config.yaml",
        instruments=["cu2506", "al2506"],
        output_path="./data/recording",
        format="csv",
        duration="1h",  # 录制 1 小时
    )
    
    recorder.run()


def example_playback():
    """回放数据示例"""
    playback = DataPlayback(
        data_path="./data/recording/cu2506_20250427.csv",
        speed=10.0,  # 10 倍速回放
    )
    
    playback.load()
    
    for tick in playback:
        print(f"{tick.datetime} {tick.instrument} {tick.last_price}")


def example_backtest():
    """回测示例"""
    
    # 定义简单策略：均线突破
    def ma_strategy(tick, context):
        # 这里简化处理，实际应该维护价格序列计算均线
        if tick.last_price > tick.bid_price_1 * 1.001:  # 模拟突破
            if context['get_position'](tick.instrument)['volume'] == 0:
                context['buy'](tick.instrument, tick.last_price, 1)
        elif tick.last_price < tick.ask_price_1 * 0.999:
            if context['get_position'](tick.instrument)['volume'] > 0:
                context['sell'](tick.instrument, tick.last_price, 1)
    
    # 创建回测引擎
    engine = BacktestEngine(
        data_path="./data/recording",
        initial_capital=1000000.0,
        commission_rate=0.0001,
    )
    
    engine.set_strategy(ma_strategy)
    engine.run()
    
    # 保存报告
    engine.save_report("./backtest_report.json")


if __name__ == '__main__':
    # 演示回放
    print("数据回放演示...")
    example_playback()
