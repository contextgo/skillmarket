"""
CTP 直连数据 Skill
================

功能特性：
- 行情数据订阅（Tick、深度行情）
- 交易功能（下单、撤单、持仓/资金查询）
- 支持 SimNow 仿真环境和实盘穿透式环境
- 数据存储（CSV、JSON、SQLite、MySQL、MongoDB）
- 实时推送（ZeroMQ、WebSocket、Redis）
- 回测支持（数据录制、回放、回测引擎）

安全特性：
- 支持 .env 环境变量配置（敏感信息不写入配置文件）
- 日志自动脱敏（密码、认证码等敏感信息不记录）
- 完整异常捕获（防止信息泄露）
- 配置验证器（检查必需字段）
- 健康检查接口

快速开始：
    from ctp_connector import CTPMarketData, CTPTrader

    # 行情接口
    md = CTPMarketData(config_path="config/ctp_config.yaml")
    md.connect()
    md.login()
    md.subscribe(["cu2506", "al2506"])
    md.run()

    # 交易接口
    trader = CTPTrader(config_path="config/ctp_config.yaml")
    trader.connect()
    trader.login()
    account = trader.query_account()
    order = trader.insert_order("cu2506", "buy", "open", 70000, 1)

配置验证：
    from ctp_connector import ConfigValidator

    result = ConfigValidator.validate(config)
    if not result["valid"]:
        print(f"缺少字段: {result['missing']}")

健康检查：
    from ctp_connector import HealthChecker

    status = HealthChecker.check_ctp_connection(trader)
    print(f"状态: {status['status']}")

版本: 1.0.7
更新日期: 2026-04-28
"""

__version__ = "1.0.7"
__author__ = "CTP Connector"

# 核心接口
from .ctp_market import CTPMarketData
from .ctp_trade import CTPTrader

# 数据模型
from .models import (
    TickData,
    DepthData,
    KLineData,
    AccountData,
    PositionData,
    OrderData,
    TradeData,
    ContractData,
)

# 数据存储
from .storage import DataRecorder, DataPlayback

# 实时推送
from .streaming import ZeroMQPublisher, WebSocketPublisher, RedisPublisher

# 工具函数
from .utils import (
    ConfigLoader,
    Logger,
    DateTimeUtil,
    OrderUtil,
    InstrumentUtil,
    ConfigValidator,
    HealthChecker,
    mask_sensitive,
    mask_dict,
    SENSITIVE_FIELDS,
)

# 回测引擎
from .backtest import BacktestEngine

__all__ = [
    # 版本信息
    "__version__",
    # 核心接口
    "CTPMarketData",
    "CTPTrader",
    # 数据模型
    "TickData",
    "DepthData",
    "KLineData",
    "AccountData",
    "PositionData",
    "OrderData",
    "TradeData",
    "ContractData",
    # 数据存储
    "DataRecorder",
    "DataPlayback",
    # 实时推送
    "ZeroMQPublisher",
    "WebSocketPublisher",
    "RedisPublisher",
    # 工具函数
    "ConfigLoader",
    "Logger",
    "DateTimeUtil",
    "OrderUtil",
    "InstrumentUtil",
    "ConfigValidator",
    "HealthChecker",
    "mask_sensitive",
    "mask_dict",
    "SENSITIVE_FIELDS",
    # 回测
    "BacktestEngine",
]
