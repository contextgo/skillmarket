"""
CTP 直连 Skill - 实时数据推送模块
支持 ZeroMQ、WebSocket、Redis 等多种推送方式
用于将 CTP 行情/交易数据实时推送到分析脚本或策略程序
"""

import json
import threading
import time
from typing import Optional, Callable, Any
from datetime import datetime

from .models import TickData, TradeData, OrderData, PositionData, AccountData
from .utils import Logger


class BasePublisher:
    """数据推送基类"""
    
    def __init__(self, address: str):
        """
        初始化推送器
        
        Args:
            address: 推送地址
        """
        self.address = address
        self.logger = Logger(f"{self.__class__.__name__}")
        self._running = False
        self._context = None
    
    def start(self):
        """启动推送服务"""
        self._running = True
        self.logger.info(f"{self.__class__.__name__} 启动: {self.address}")
    
    def stop(self):
        """停止推送服务"""
        self._running = False
        self.logger.info(f"{self.__class__.__name__} 已停止")
    
    def publish(self, topic: str, data: Any) -> bool:
        """
        推送数据
        
        Args:
            topic: 主题（如 tick/cu2506, trade, order 等）
            data: 数据对象（TickData/TradeData 等）
        
        Returns:
            是否推送成功
        """
        raise NotImplementedError
    
    def close(self):
        """关闭连接"""
        self._running = False


class ZMQPublisher(BasePublisher):
    """
    ZeroMQ 发布器
    高性能推送，适合量化策略、高频数据分析
    PUB/SUB 模式，支持多个订阅者
    """
    
    def __init__(self, address: str = "tcp://127.0.0.1:5555"):
        """
        Args:
            address: ZMQ 地址，如 "tcp://127.0.0.1:5555"
        """
        super().__init__(address)
        self._socket = None
        self._lock = threading.Lock()
    
    def start(self):
        """启动 ZMQ PUB 套接字"""
        try:
            import zmq
            
            self._context = zmq.Context()
            self._socket = self._context.socket(zmq.PUB)
            self._socket.bind(self.address)
            
            # 等待连接建立
            time.sleep(0.5)
            
            super().start()
        except ImportError:
            self.logger.error("请先安装 pyzmq: pip install pyzmq")
            raise
        except Exception as e:
            self.logger.error(f"ZMQ 启动失败: {e}")
            raise
    
    def publish(self, topic: str, data: Any) -> bool:
        """
        推送数据
        
        Args:
            topic: 主题
            data: 数据字典或数据对象
        """
        if not self._running or not self._socket:
            return False
        
        try:
            with self._lock:
                # 序列化数据
                if hasattr(data, 'to_dict'):
                    payload = data.to_dict()
                elif isinstance(data, dict):
                    payload = data
                else:
                    payload = str(data)
                
                message = json.dumps({
                    'topic': topic,
                    'timestamp': datetime.now().isoformat(),
                    'data': payload,
                }, ensure_ascii=False)
                
                # ZMQ 发送：topic + message
                self._socket.send_multipart([
                    topic.encode('utf-8'),
                    message.encode('utf-8')
                ])
            
            return True
        
        except Exception as e:
            self.logger.error(f"ZMQ 推送失败: {e}")
            return False
    
    def close(self):
        """关闭 ZMQ 连接"""
        self._running = False
        try:
            if self._socket:
                self._socket.close()
            if self._context:
                self._context.term()
        except Exception as e:
            self.logger.error(f"ZMQ 关闭失败: {e}")


class ZMQSubscriber:
    """
    ZeroMQ 订阅器
    用于分析脚本/策略程序接收数据
    """
    
    def __init__(self, address: str = "tcp://127.0.0.1:5555"):
        """
        Args:
            address: ZMQ 地址
        """
        self.address = address
        self.logger = Logger("ZMQSubscriber")
        self._context = None
        self._socket = None
    
    def connect(self):
        """连接到发布者"""
        try:
            import zmq
            
            self._context = zmq.Context()
            self._socket = self._context.socket(zmq.SUB)
            self._socket.connect(self.address)
            
            self.logger.info(f"ZMQ 订阅器连接成功: {self.address}")
            return True
        except ImportError:
            self.logger.error("请先安装 pyzmq: pip install pyzmq")
            return False
        except Exception as e:
            self.logger.error(f"ZMQ 连接失败: {e}")
            return False
    
    def subscribe(self, topic: str = ""):
        """
        订阅主题
        
        Args:
            topic: 主题过滤，空字符串表示订阅所有
        """
        if self._socket:
            self._socket.setsockopt_string(zmq.SUBSCRIBE, topic)
            self.logger.info(f"已订阅主题: {topic if topic else 'ALL'}")
    
    def receive(self, timeout: Optional[int] = None) -> Optional[dict]:
        """
        接收数据
        
        Args:
            timeout: 超时时间（毫秒），None 表示阻塞等待
        
        Returns:
            数据字典 {'topic': ..., 'timestamp': ..., 'data': ...}
        """
        if not self._socket:
            return None
        
        try:
            if timeout is not None:
                if self._socket.poll(timeout) == 0:
                    return None
            
            topic_bytes, msg_bytes = self._socket.recv_multipart()
            message = json.loads(msg_bytes.decode('utf-8'))
            return message
        
        except Exception as e:
            self.logger.error(f"ZMQ 接收失败: {e}")
            return None
    
    def close(self):
        """关闭连接"""
        try:
            if self._socket:
                self._socket.close()
            if self._context:
                self._context.term()
        except Exception as e:
            self.logger.error(f"ZMQ 关闭失败: {e}")


class WebSocketServer(BasePublisher):
    """
    WebSocket 服务器
    适合 Web 前端实时展示、多客户端订阅
    """
    
    def __init__(self, host: str = "0.0.0.0", port: int = 8765):
        """
        Args:
            host: 监听地址
            port: 监听端口
        """
        address = f"{host}:{port}"
        super().__init__(address)
        self.host = host
        self.port = port
        self._server = None
        self._clients = set()
        self._loop = None
        self._thread = None
    
    def start(self):
        """启动 WebSocket 服务器"""
        try:
            import asyncio
            import websockets
            
            async def handler(websocket, path):
                self._clients.add(websocket)
                self.logger.info(f"新客户端连接，当前: {len(self._clients)}")
                try:
                    # 保持连接
                    async for message in websocket:
                        pass
                except websockets.exceptions.ConnectionClosed:
                    pass
                finally:
                    self._clients.remove(websocket)
                    self.logger.info(f"客户端断开，当前: {len(self._clients)}")
            
            async def start_server():
                self._server = await websockets.serve(
                    handler, self.host, self.port
                )
                self.logger.info(f"WebSocket 服务器启动: {self.address}")
                await self._server.wait_closed()
            
            self._loop = asyncio.new_event_loop()
            self._thread = threading.Thread(
                target=lambda: self._loop.run_until_complete(start_server()),
                daemon=True
            )
            self._thread.start()
            
            self._running = True
        
        except ImportError:
            self.logger.error("请先安装 websockets: pip install websockets")
            raise
        except Exception as e:
            self.logger.error(f"WebSocket 启动失败: {e}")
            raise
    
    def publish(self, topic: str, data: Any) -> bool:
        """向所有连接的客户端推送数据"""
        if not self._running or not self._clients:
            return False
        
        try:
            import asyncio
            
            # 序列化数据
            if hasattr(data, 'to_dict'):
                payload = data.to_dict()
            elif isinstance(data, dict):
                payload = data
            else:
                payload = str(data)
            
            message = json.dumps({
                'topic': topic,
                'timestamp': datetime.now().isoformat(),
                'data': payload,
            }, ensure_ascii=False)
            
            # 异步发送
            async def send_to_all():
                if self._clients:
                    await asyncio.wait([client.send(message) for client in self._clients])
            
            asyncio.run_coroutine_threadsafe(send_to_all(), self._loop)
            return True
        
        except Exception as e:
            self.logger.error(f"WebSocket 推送失败: {e}")
            return False
    
    def close(self):
        """关闭 WebSocket 服务器"""
        self._running = False
        try:
            if self._server:
                self._server.close()
        except Exception as e:
            self.logger.error(f"WebSocket 关闭失败: {e}")


class RedisPublisher(BasePublisher):
    """
    Redis 发布器
    适合分布式系统、多服务订阅
    使用 Redis Pub/Sub 功能
    """
    
    def __init__(self, host: str = "localhost", port: int = 6379, db: int = 0):
        """
        Args:
            host: Redis 主机
            port: Redis 端口
            db: Redis 数据库编号
        """
        address = f"redis://{host}:{port}/{db}"
        super().__init__(address)
        self.host = host
        self.port = port
        self.db = db
        self._redis_client = None
    
    def start(self):
        """连接 Redis"""
        try:
            import redis
            
            self._redis_client = redis.Redis(
                host=self.host,
                port=self.port,
                db=self.db,
                decode_responses=False,  # 我们需要 bytes
            )
            
            # 测试连接
            self._redis_client.ping()
            
            super().start()
        
        except ImportError:
            self.logger.error("请先安装 redis: pip install redis")
            raise
        except Exception as e:
            self.logger.error(f"Redis 连接失败: {e}")
            raise
    
    def publish(self, topic: str, data: Any) -> bool:
        """
        发布消息到 Redis 频道
        
        Args:
            topic: Redis 频道名称
            data: 数据
        """
        if not self._running or not self._redis_client:
            return False
        
        try:
            # 序列化数据
            if hasattr(data, 'to_dict'):
                payload = data.to_dict()
            elif isinstance(data, dict):
                payload = data
            else:
                payload = {'data': str(data)}
            
            message = json.dumps({
                'topic': topic,
                'timestamp': datetime.now().isoformat(),
                'data': payload,
            }, ensure_ascii=False)
            
            self._redis_client.publish(topic, message)
            return True
        
        except Exception as e:
            self.logger.error(f"Redis 发布失败: {e}")
            return False
    
    def close(self):
        """关闭 Redis 连接"""
        self._running = False
        try:
            if self._redis_client:
                self._redis_client.close()
        except Exception as e:
            self.logger.error(f"Redis 关闭失败: {e}")


class RedisSubscriber:
    """
    Redis 订阅器
    """
    
    def __init__(self, host: str = "localhost", port: int = 6379, db: int = 0):
        self.host = host
        self.port = port
        self.db = db
        self.logger = Logger("RedisSubscriber")
        self._redis_client = None
        self._pubsub = None
    
    def connect(self):
        """连接 Redis"""
        try:
            import redis
            
            self._redis_client = redis.Redis(
                host=self.host,
                port=self.port,
                db=self.db,
                decode_responses=True,
            )
            self._pubsub = self._redis_client.pubsub()
            self.logger.info(f"Redis 订阅器连接成功")
            return True
        except Exception as e:
            self.logger.error(f"Redis 连接失败: {e}")
            return False
    
    def subscribe(self, *channels):
        """订阅频道"""
        if self._pubsub:
            self._pubsub.subscribe(*channels)
            self.logger.info(f"已订阅频道: {channels}")
    
    def listen(self):
        """
        监听消息（生成器）
        Yields:
            消息字典
        """
        if not self._pubsub:
            return
        
        for message in self._pubsub.listen():
            if message['type'] == 'message':
                try:
                    data = json.loads(message['data'])
                    yield data
                except Exception as e:
                    self.logger.error(f"解析 Redis 消息失败: {e}")
    
    def close(self):
        """关闭连接"""
        try:
            if self._pubsub:
                self._pubsub.unsubscribe()
            if self._redis_client:
                self._redis_client.close()
        except Exception as e:
            self.logger.error(f"Redis 关闭失败: {e}")


# ========== 数据推送适配器 ==========

class DataPusher:
    """
    数据推送适配器
    将 CTP 数据一键推送到多个目标
    """
    
    def __init__(self):
        self.publishers = []
        self.logger = Logger("DataPusher")
    
    def add_publisher(self, publisher: BasePublisher):
        """添加推送器"""
        publisher.start()
        self.publishers.append(publisher)
        self.logger.info(f"添加推送器: {publisher.__class__.__name__}")
    
    def push_tick(self, tick: TickData):
        """推送 Tick 数据"""
        topic = f"tick.{tick.instrument}"
        for pub in self.publishers:
            pub.publish(topic, tick)
    
    def push_trade(self, trade: TradeData):
        """推送成交数据"""
        topic = f"trade.{trade.instrument}"
        for pub in self.publishers:
            pub.publish(topic, trade)
    
    def push_order(self, order: OrderData):
        """推送委托数据"""
        topic = f"order.{order.instrument}"
        for pub in self.publishers:
            pub.publish(topic, order)
    
    def push_position(self, position: PositionData):
        """推送持仓数据"""
        topic = f"position.{position.instrument}"
        for pub in self.publishers:
            pub.publish(topic, position)
    
    def push_account(self, account: AccountData):
        """推送账户数据"""
        topic = "account"
        for pub in self.publishers:
            pub.publish(topic, account)
    
    def close(self):
        """关闭所有推送器"""
        for pub in self.publishers:
            try:
                pub.close()
            except Exception as e:
                self.logger.error(f"关闭推送器失败: {e}")


# ========== 使用示例 ==========

def example_zmq_push():
    """ZMQ 推送示例"""
    publisher = ZMQPublisher(address="tcp://127.0.0.1:5555")
    publisher.start()
    
    # 推送 Tick 数据
    from .models import TickData
    from datetime import datetime
    
    tick = TickData(
        instrument="cu2506",
        datetime=datetime.now(),
        last_price=70500.0,
        volume=50,
    )
    
    publisher.publish("tick.cu2506", tick)
    publisher.close()


def example_zmq_subscribe():
    """ZMQ 订阅示例"""
    subscriber = ZMQSubscriber(address="tcp://127.0.0.1:5555")
    subscriber.connect()
    subscriber.subscribe("tick.")  # 订阅所有 tick 主题
    
    print("等待数据...")
    while True:
        message = subscriber.receive(timeout=1000)
        if message:
            print(f"收到数据: {message['topic']}")
            print(f"数据内容: {message['data']}")
    
    subscriber.close()


def example_websocket():
    """WebSocket 推送示例"""
    server = WebSocketServer(host="0.0.0.0", port=8765)
    server.start()
    
    # 模拟推送
    import time
    from .models import TickData
    
    for i in range(10):
        tick = TickData(
            instrument="cu2506",
            datetime=datetime.now(),
            last_price=70500.0 + i * 10,
            volume=100 + i,
        )
        server.publish("tick.cu2506", tick)
        time.sleep(1)
    
    server.close()


def example_data_pusher():
    """数据推送适配器示例（多目标推送）"""
    pusher = DataPusher()
    
    # 添加多个推送器
    zmq_pub = ZMQPublisher(address="tcp://127.0.0.1:5555")
    ws_server = WebSocketServer(host="0.0.0.0", port=8765)
    
    pusher.add_publisher(zmq_pub)
    pusher.add_publisher(ws_server)
    
    # 推送数据（同时到 ZMQ 和 WebSocket）
    from .models import TickData
    
    tick = TickData(
        instrument="cu2506",
        datetime=datetime.now(),
        last_price=70500.0,
    )
    
    pusher.push_tick(tick)
    
    time.sleep(5)
    pusher.close()


if __name__ == '__main__':
    # 演示 ZMQ 推送
    print("启动 ZMQ 推送器...")
    example_zmq_push()
