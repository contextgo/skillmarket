"""
CTP 直连 Skill - 工具函数
提供配置加载、日志、时间处理等通用功能
"""

import os
import re
import yaml
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, Any, Optional

# 尝试加载 python-dotenv（可选依赖）
try:
    from dotenv import load_dotenv
    # 自动加载 .env 文件
    load_dotenv()
except ImportError:
    pass


# 敏感字段列表
SENSITIVE_FIELDS = [
    'password', 'pwd', 'passwd', 'secret',
    'auth_code', 'authcode', 'apikey', 'api_key',
    'token', 'access_token', 'refresh_token',
    'private_key', 'public_key', 'cert', 'key',
    'credential', 'credential_id', 'credential_secret',
    'app_secret', 'client_secret', 'api_secret',
    'bearer', 'authorization', 'cookie', 'session_id',
]


class ConfigLoader:
    """
    配置加载器

    支持 YAML 和 JSON 格式的配置文件加载
    支持从环境变量覆盖敏感配置
    """

    @staticmethod
    def load_yaml(path: str) -> Dict[str, Any]:
        """
        加载 YAML 配置文件（带异常处理）

        Args:
            path: YAML 文件路径

        Returns:
            配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: YAML 解析错误
            RuntimeError: 其他加载错误
        """
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"配置文件不存在: {path}")
        except yaml.YAMLError as e:
            raise ValueError(f"YAML解析错误: {path}, 错误: {e}")
        except Exception as e:
            raise RuntimeError(f"配置文件加载失败: {path}, 错误: {e}")

    @staticmethod
    def load_json(path: str) -> Dict[str, Any]:
        """
        加载 JSON 配置文件（带异常处理）

        Args:
            path: JSON 文件路径

        Returns:
            配置字典

        Raises:
            FileNotFoundError: 文件不存在
            ValueError: JSON 解析错误
            RuntimeError: 其他加载错误
        """
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            raise FileNotFoundError(f"配置文件不存在: {path}")
        except json.JSONDecodeError as e:
            raise ValueError(f"JSON解析错误: {path}, 错误: {e}")
        except Exception as e:
            raise RuntimeError(f"配置文件加载失败: {path}, 错误: {e}")

    @staticmethod
    def get_config(config_path: str) -> Dict[str, Any]:
        """
        获取配置，支持 YAML 和 JSON 格式
        自动根据当前环境选择配置
        支持从环境变量读取敏感信息

        Args:
            config_path: 配置文件路径

        Returns:
            合并后的配置字典
        """
        if not os.path.exists(config_path):
            raise FileNotFoundError(f"配置文件不存在: {config_path}")

        try:
            if config_path.endswith('.yaml') or config_path.endswith('.yml'):
                config = ConfigLoader.load_yaml(config_path)
            elif config_path.endswith('.json'):
                config = ConfigLoader.load_json(config_path)
            else:
                raise ValueError(f"不支持的配置文件格式: {config_path}")
        except Exception:
            raise

        # 获取当前环境配置
        env = config.get('environment', 'simnow')
        env_config = config.get(env, {})

        # 从环境变量覆盖敏感配置
        env_overrides = ConfigLoader._load_env_overrides(env)
        env_config = {**env_config, **env_overrides}

        # 合并通用配置和环境配置
        merged = {
            'environment': env,
            **env_config,
            'output': config.get('output', {}),
            'subscriptions': config.get('subscriptions', []),
        }

        return merged

    @staticmethod
    def _load_env_overrides(env: str) -> Dict[str, Any]:
        """
        从环境变量加载配置覆盖
        支持 SIMNOW_* 和 PROD_* 前缀

        Args:
            env: 环境名称 (simnow/production)

        Returns:
            环境变量配置字典
        """
        overrides = {}

        # SimNow 环境
        if env == 'simnow':
            prefix = 'SIMNOW_'
            env_mappings = {
                f'{prefix}BROKER_ID': 'broker_id',
                f'{prefix}USER_ID': 'user_id',
                f'{prefix}PASSWORD': 'password',
                f'{prefix}AUTH_CODE': 'auth_code',
                f'{prefix}APP_ID': 'app_id',
                f'{prefix}MD_FRONT': 'front_address',
                f'{prefix}TRADE_FRONT': 'trade_front',
            }
        # 实盘环境
        else:
            prefix = 'PROD_'
            env_mappings = {
                f'{prefix}BROKER_ID': 'broker_id',
                f'{prefix}USER_ID': 'user_id',
                f'{prefix}PASSWORD': 'password',
                f'{prefix}AUTH_CODE': 'auth_code',
                f'{prefix}APP_ID': 'app_id',
                f'{prefix}MD_FRONT': 'front_address',
                f'{prefix}TRADE_FRONT': 'trade_front',
            }

        for env_key, config_key in env_mappings.items():
            value = os.getenv(env_key)
            if value:
                overrides[config_key] = value

        return overrides


def mask_sensitive(value: str, visible: int = 4) -> str:
    """
    脱敏敏感信息
    只显示前visible个字符，其余用*代替

    Args:
        value: 原始值
        visible: 显示前几位，默认4位

    Returns:
        脱敏后的字符串
    """
    if not value or len(value) <= visible:
        return '*' * len(value) if value else ''
    return value[:visible] + '*' * (len(value) - visible)


def mask_dict(data: Dict[str, Any], sensitive_fields: Optional[list] = None) -> Dict[str, Any]:
    """
    对字典中的敏感字段进行脱敏

    Args:
        data: 原始字典
        sensitive_fields: 敏感字段列表，默认使用 SENSITIVE_FIELDS

    Returns:
        脱敏后的字典
    """
    if sensitive_fields is None:
        sensitive_fields = SENSITIVE_FIELDS

    result = {}
    for key, value in data.items():
        # 检查是否是敏感字段
        key_lower = key.lower()
        is_sensitive = any(s in key_lower for s in sensitive_fields)

        if is_sensitive and isinstance(value, str):
            result[key] = mask_sensitive(value)
        elif isinstance(value, dict):
            result[key] = mask_dict(value, sensitive_fields)
        else:
            result[key] = value

    return result


class Logger:
    """
    日志管理器（带敏感信息脱敏）

    单例模式实现，避免重复初始化
    自动脱敏日志中的敏感信息
    """

    _instance = None

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self, name: str = "CTP", level: int = logging.INFO, log_file: Optional[str] = None):
        if hasattr(self, 'initialized'):
            return

        self.initialized = True
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)

        # 清除已有 handler
        self.logger.handlers = []

        # 控制台输出
        console_handler = logging.StreamHandler()
        console_handler.setLevel(level)
        console_format = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(console_format)
        self.logger.addHandler(console_handler)

        # 文件输出
        if log_file:
            try:
                os.makedirs(os.path.dirname(log_file), exist_ok=True)
                file_handler = logging.FileHandler(log_file, encoding='utf-8')
                file_handler.setLevel(level)
                file_format = logging.Formatter(
                    '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                    datefmt='%Y-%m-%d %H:%M:%S'
                )
                file_handler.setFormatter(file_format)
                self.logger.addHandler(file_handler)
            except Exception as e:
                # 文件写入失败不影响主功能
                self.logger.warning(f"日志文件创建失败: {e}")

    def _sanitize_message(self, message: str) -> str:
        """
        脱敏日志消息中的敏感信息

        支持多种格式：
        - password: "secret"
        - password="secret"
        - password=secret
        - "password": "secret"
        - password: secret
        - password=123456
        - password:123456

        Args:
            message: 原始日志消息

        Returns:
            脱敏后的消息
        """
        if not isinstance(message, str):
            return str(message)

        # 定义脱敏模式
        patterns = [
            # 密码脱敏 - 多种格式
            (r'(password["\']?\s*[:=]\s*["\']?)([^"\'\s,}\]\)]+)', r'\1****'),
            # auth_code 脱敏
            (r'(auth_?code["\']?\s*[:=]\s*["\']?)([^"\'\s,}\]\)]+)', r'\1****'),
            # api_key 脱敏
            (r'(api_?key["\']?\s*[:=]\s*["\']?)([^"\'\s,}\]\)]+)', r'\1****'),
            # token 脱敏
            (r'(token["\']?\s*[:=]\s*["\']?)([^"\'\s,}\]\)]+)', r'\1****'),
            # secret 脱敏
            (r'(secret["\']?\s*[:=]\s*["\']?)([^"\'\s,}\]\)]+)', r'\1****'),
            # 用户ID脱敏（部分）
            (r'(user_?id["\']?\s*[:=]\s*["\']?)([^"\'\s,}\]\)]+)', r'\1****'),
            # 密码脱敏（中文）
            (r'((?:密码|口令|凭证)["\']?\s*[:=]\s*["\']?)([^"\'\s,}\]\)]+)', r'\1****'),
        ]

        for pattern, replacement in patterns:
            message = re.sub(pattern, replacement, message, flags=re.IGNORECASE)

        return message

    def debug(self, message: str, *args, **kwargs):
        """记录 DEBUG 级别日志"""
        self.logger.debug(self._sanitize_message(message), *args, **kwargs)

    def info(self, message: str, *args, **kwargs):
        """记录 INFO 级别日志"""
        self.logger.info(self._sanitize_message(message), *args, **kwargs)

    def warning(self, message: str, *args, **kwargs):
        """记录 WARNING 级别日志"""
        self.logger.warning(self._sanitize_message(message), *args, **kwargs)

    def error(self, message: str, *args, **kwargs):
        """记录 ERROR 级别日志"""
        self.logger.error(self._sanitize_message(message), *args, **kwargs)

    def critical(self, message: str, *args, **kwargs):
        """记录 CRITICAL 级别日志"""
        self.logger.critical(self._sanitize_message(message), *args, **kwargs)

    def log(self, level: int, message: str, *args, **kwargs):
        """记录指定级别日志"""
        self.logger.log(level, self._sanitize_message(message), *args, **kwargs)


class DateTimeUtil:
    """日期时间工具类"""

    @staticmethod
    def now() -> datetime:
        """获取当前时间"""
        return datetime.now()

    @staticmethod
    def today() -> str:
        """获取当前日期字符串 (YYYY-MM-DD)"""
        return datetime.now().strftime('%Y-%m-%d')

    @staticmethod
    def timestamp() -> str:
        """获取时间戳字符串 (YYYYMMDDHHMMSS)"""
        return datetime.now().strftime('%Y%m%d%H%M%S')

    @staticmethod
    def format(dt: datetime, fmt: str = '%Y-%m-%d %H:%M:%S') -> str:
        """格式化日期时间"""
        return dt.strftime(fmt)


class OrderUtil:
    """订单工具类"""

    @staticmethod
    def generate_order_id() -> str:
        """生成唯一订单ID"""
        import time
        import random
        return f"ORD{datetime.now().strftime('%Y%m%d%H%M%S')}{random.randint(1000, 9999)}"

    @staticmethod
    def validate_direction(direction: str) -> bool:
        """验证交易方向"""
        return direction.lower() in ['buy', 'sell']

    @staticmethod
    def validate_offset(offset: str) -> bool:
        """验证开平仓"""
        return offset.lower() in ['open', 'close', 'close_today', 'close_yesterday']

    @staticmethod
    def validate_order_type(order_type: str) -> bool:
        """验证订单类型"""
        return order_type.lower() in ['limit', 'market', 'fok', 'fak', 'stop']

    @staticmethod
    def to_ctp_direction(direction: str) -> str:
        """转换为 CTP 方向代码"""
        mapping = {'buy': '0', 'sell': '1'}
        return mapping.get(direction.lower(), '0')

    @staticmethod
    def to_ctp_offset(offset: str) -> str:
        """转换为 CTP 开平代码"""
        mapping = {
            'open': '0',
            'close': '1',
            'force_close': '2',
            'close_today': '3',
            'close_yesterday': '4'
        }
        return mapping.get(offset.lower(), '0')

    @staticmethod
    def to_ctp_order_type(order_type: str) -> str:
        """转换为 CTP 订单类型代码"""
        mapping = {
            'limit': '2',
            'market': '1',
            'fok': '3',
            'fak': '4',
            'stop': '5'
        }
        return mapping.get(order_type.lower(), '2')


# ===========================================
# 配置验证器
# ===========================================

class ConfigValidator:
    """
    配置验证器

    验证配置文件是否包含必需的字段
    支持 SimNow 和实盘环境的不同验证规则
    """

    # SimNow 环境必需字段
    SIMNOW_REQUIRED = ['user_id', 'password']

    # 实盘环境必需字段
    PROD_REQUIRED = ['user_id', 'password', 'broker_id', 'front_address', 'trade_front']

    @classmethod
    def validate(cls, config: dict, env: str = None) -> dict:
        """
        验证配置完整性

        Args:
            config: 配置字典
            env: 环境名称，None时自动检测

        Returns:
            dict: {
                "valid": bool,
                "missing": list,
                "warnings": list,
                "errors": list
            }
        """
        if env is None:
            env = config.get('environment', 'simnow')

        result = {
            "valid": True,
            "missing": [],
            "warnings": [],
            "errors": []
        }

        # 确定必需字段
        if env == 'simnow':
            required_fields = cls.SIMNOW_REQUIRED
        else:
            required_fields = cls.PROD_REQUIRED

        # 检查必需字段
        for field in required_fields:
            value = config.get(field)
            if not value or (isinstance(value, str) and value.startswith('${')):
                result["missing"].append(field)
                result["valid"] = False

        # 特殊验证
        if env == 'simnow':
            # SimNow环境检查认证码
            auth_code = config.get('auth_code')
            if auth_code and len(auth_code) != 16:
                result["warnings"].append("SimNow认证码长度应为16位")

        if env == 'production':
            # 实盘环境必须有认证码
            auth_code = config.get('auth_code')
            if not auth_code or (isinstance(auth_code, str) and auth_code.startswith('${')):
                result["errors"].append("实盘环境必须配置auth_code")
                result["valid"] = False

            # 验证前置地址格式
            front_address = config.get('front_address')
            if front_address and not front_address.startswith('tcp://'):
                result["warnings"].append("前置地址应以 tcp:// 开头")

        return result

    @staticmethod
    def get_missing_fields(config: dict) -> list:
        """获取缺失的必需字段列表"""
        validation = ConfigValidator.validate(config)
        return validation.get("missing", [])

    @staticmethod
    def print_validation_report(config: dict, env: str = None):
        """打印配置验证报告"""
        result = ConfigValidator.validate(config, env)

        print("=" * 50)
        print("配置验证报告")
        print("=" * 50)
        print(f"状态: {'✅ 通过' if result['valid'] else '❌ 失败'}")

        if result['missing']:
            print(f"\n缺失字段: {', '.join(result['missing'])}")
        if result['warnings']:
            print(f"\n警告: {', '.join(result['warnings'])}")
        if result['errors']:
            print(f"\n错误: {', '.join(result['errors'])}")

        print("=" * 50)
        return result


# ===========================================
# 健康检查
# ===========================================

class HealthChecker:
    """
    健康检查器

    检查 CTP 连接状态和系统健康
    """

    @staticmethod
    def check_ctp_connection(md_or_trader) -> dict:
        """
        检查CTP连接状态

        Args:
            md_or_trader: CTPMarketData 或 CTPTrader 实例

        Returns:
            dict: 健康检查结果
        """
        result = {
            "component": type(md_or_trader).__name__,
            "status": "unknown",
            "connected": False,
            "logged_in": False,
            "details": {}
        }

        try:
            # 检查连接状态
            if hasattr(md_or_trader, '_connected'):
                result["connected"] = md_or_trader._connected
            if hasattr(md_or_trader, '_logged_in'):
                result["logged_in"] = md_or_trader._logged_in

            # 检查配置
            config = getattr(md_or_trader, 'config', {})
            result["details"]["environment"] = config.get('environment', 'unknown')
            result["details"]["has_user_id"] = bool(config.get('user_id'))
            result["details"]["has_broker_id"] = bool(config.get('broker_id'))

            # 确定状态
            if result["connected"] and result["logged_in"]:
                result["status"] = "healthy"
            elif result["connected"]:
                result["status"] = "connected_not_logged_in"
            else:
                result["status"] = "disconnected"

        except Exception as e:
            result["status"] = "error"
            result["details"]["error"] = str(e)

        return result

    @staticmethod
    def system_check() -> dict:
        """
        系统健康检查

        Returns:
            dict: 系统状态信息
        """
        import platform
        import sys

        return {
            "platform": platform.platform(),
            "python_version": sys.version,
            "status": "ok",
            "timestamp": datetime.now().isoformat()
        }

    @staticmethod
    def print_health_report(md_or_trader):
        """打印健康检查报告"""
        result = HealthChecker.check_ctp_connection(md_or_trader)

        print("=" * 50)
        print("CTP 健康检查报告")
        print("=" * 50)
        print(f"组件: {result['component']}")
        print(f"状态: {result['status']}")
        print(f"已连接: {'是' if result['connected'] else '否'}")
        print(f"已登录: {'是' if result['logged_in'] else '否'}")
        print(f"\n详情:")
        for key, value in result['details'].items():
            print(f"  {key}: {value}")
        print("=" * 50)


# ===========================================
# InstrumentUtil 工具
# ===========================================

class InstrumentUtil:
    """合约工具类"""

    # 交易所代码映射
    EXCHANGE_MAP = {
        'SHFE': '上海期货',
        'DCE': '大连商品',
        'CZCE': '郑州商品',
        'CFFEX': '中金所',
        'INE': '上期能源',
    }

    @staticmethod
    def normalize_instrument(instrument: str) -> str:
        """
        标准化合约代码格式

        Examples:
            "cu2506" -> "cu2506"
            "CU2506" -> "cu2506"

        Args:
            instrument: 合约代码

        Returns:
            标准化后的合约代码（小写）
        """
        return instrument.lower().strip()

    @staticmethod
    def get_exchange(instrument: str) -> str:
        """
        从合约代码推断交易所

        Examples:
            "cu2506" -> "SHFE"

        Args:
            instrument: 合约代码

        Returns:
            交易所代码
        """
        instrument = instrument.lower()

        # 简单规则
        if instrument in ['ag', 'au', 'cu', 'al', 'zn', 'pb', 'ni', 'sn', 'rb', 'hc', 'bu', 'ru', 'ss']:
            return 'SHFE'
        elif instrument in ['i', 'j', 'jm', 'm', 'y', 'p', 'c', 'cs', 'v', 'l', 'pp', 'eb', 'eg']:
            return 'DCE'
        elif len(instrument) <= 3 and any(c.isalpha() for c in instrument):
            return 'CZCE'
        else:
            return 'UNKNOWN'

    @staticmethod
    def format_instrument(instrument: str, exchange: str = None) -> str:
        """
        格式化合约代码

        Args:
            instrument: 合约代码
            exchange: 交易所代码

        Returns:
            格式化后的合约代码
        """
        instrument = InstrumentUtil.normalize_instrument(instrument)
        if exchange:
            return f"{exchange}.{instrument}"
        return instrument

    @staticmethod
    def get_contract_info(instrument: str) -> dict:
        """
        获取合约信息

        Args:
            instrument: 合约代码

        Returns:
            合约信息字典
        """
        exchange = InstrumentUtil.get_exchange(instrument)
        return {
            'instrument': instrument,
            'exchange': exchange,
            'exchange_name': InstrumentUtil.EXCHANGE_MAP.get(exchange, '未知'),
            'normalized': InstrumentUtil.normalize_instrument(instrument),
        }
