"""
CTP 直连 Skill - 数据模型定义
定义所有 CTP 数据相关的数据类
"""

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List, Dict


@dataclass
class TickData:
    """Tick 行情数据"""
    instrument: str                    # 合约代码
    datetime: datetime                 # 时间戳
    last_price: float                  # 最新价
    volume: int                        # 成交量
    open_interest: float               # 持仓量
    turnover: float = 0.0             # 成交额
    
    # 买档
    bid_price_1: float = 0.0
    bid_volume_1: int = 0
    bid_price_2: float = 0.0
    bid_volume_2: int = 0
    bid_price_3: float = 0.0
    bid_volume_3: int = 0
    bid_price_4: float = 0.0
    bid_volume_4: int = 0
    bid_price_5: float = 0.0
    bid_volume_5: int = 0
    
    # 卖档
    ask_price_1: float = 0.0
    ask_volume_1: int = 0
    ask_price_2: float = 0.0
    ask_volume_2: int = 0
    ask_price_3: float = 0.0
    ask_volume_3: int = 0
    ask_price_4: float = 0.0
    ask_volume_4: int = 0
    ask_price_5: float = 0.0
    ask_volume_5: int = 0
    
    # 涨跌幅
    open_price: float = 0.0          # 开盘价
    high_price: float = 0.0           # 最高价
    low_price: float = 0.0            # 最低价
    pre_close: float = 0.0            # 昨收价
    upper_limit: float = 0.0          # 涨停价
    lower_limit: float = 0.0          # 跌停价
    average_price: float = 0.0         # 当日均价
    
    def to_dict(self) -> dict:
        """转换为字典"""
        return {
            "instrument": self.instrument,
            "datetime": self.datetime.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
            "last_price": self.last_price,
            "volume": self.volume,
            "open_interest": self.open_interest,
            "turnover": self.turnover,
            "bid_price_1": self.bid_price_1,
            "bid_volume_1": self.bid_volume_1,
            "ask_price_1": self.ask_price_1,
            "ask_volume_1": self.ask_volume_1,
            "open_price": self.open_price,
            "high_price": self.high_price,
            "low_price": self.low_price,
            "pre_close": self.pre_close,
            "upper_limit": self.upper_limit,
            "lower_limit": self.lower_limit,
            "average_price": self.average_price,
        }
    
    @classmethod
    def from_dict(cls, data: dict) -> "TickData":
        """从字典创建"""
        dt = data.get("datetime")
        if isinstance(dt, str):
            dt = datetime.strptime(dt, "%Y-%m-%d %H:%M:%S.%f")
        return cls(
            instrument=data.get("instrument", ""),
            datetime=dt,
            last_price=float(data.get("last_price", 0)),
            volume=int(data.get("volume", 0)),
            open_interest=float(data.get("open_interest", 0)),
            turnover=float(data.get("turnover", 0)),
            bid_price_1=float(data.get("bid_price_1", 0)),
            bid_volume_1=int(data.get("bid_volume_1", 0)),
            ask_price_1=float(data.get("ask_price_1", 0)),
            ask_volume_1=int(data.get("ask_volume_1", 0)),
            open_price=float(data.get("open_price", 0)),
            high_price=float(data.get("high_price", 0)),
            low_price=float(data.get("low_price", 0)),
            pre_close=float(data.get("pre_close", 0)),
            upper_limit=float(data.get("upper_limit", 0)),
            lower_limit=float(data.get("lower_limit", 0)),
            average_price=float(data.get("average_price", 0)),
        )


@dataclass
class DepthData:
    """深度行情数据（买五卖五）"""
    instrument: str
    datetime: datetime
    last_price: float = 0.0
    volume: int = 0
    open_interest: float = 0.0
    bids: List[dict] = field(default_factory=list)   # [{"price": x, "volume": y}, ...]
    asks: List[dict] = field(default_factory=list)   # [{"price": x, "volume": y}, ...]
    
    def to_dict(self) -> dict:
        return {
            "instrument": self.instrument,
            "datetime": self.datetime.strftime("%Y-%m-%d %H:%M:%S"),
            "last_price": self.last_price,
            "volume": self.volume,
            "open_interest": self.open_interest,
            "bids": self.bids,
            "asks": self.asks,
        }


@dataclass
class KLineData:
    """K 线数据"""
    instrument: str
    interval: str                      # "1m", "5m", "15m", "30m", "1h", "1d"
    datetime: datetime
    open_price: float = 0.0
    high_price: float = 0.0
    low_price: float = 0.0
    close_price: float = 0.0
    volume: int = 0
    open_interest: float = 0.0
    
    def to_dict(self) -> dict:
        return {
            "instrument": self.instrument,
            "interval": self.interval,
            "datetime": self.datetime.strftime("%Y-%m-%d %H:%M:%S"),
            "open": self.open_price,
            "high": self.high_price,
            "low": self.low_price,
            "close": self.close_price,
            "volume": self.volume,
            "open_interest": self.open_interest,
        }


@dataclass
class AccountData:
    """账户数据"""
    account_id: str
    balance: float = 0.0              # 权益
    available: float = 0.0            # 可用资金
    margin: float = 0.0               # 保证金
    frozen: float = 0.0               # 冻结资金
    commission: float = 0.0           # 手续费
    close_profit: float = 0.0         # 平仓盈亏
    position_profit: float = 0.0      # 持仓盈亏
    risk_degree: float = 0.0          # 风险度
    
    def to_dict(self) -> dict:
        return {
            "account_id": self.account_id,
            "balance": round(self.balance, 2),
            "available": round(self.available, 2),
            "margin": round(self.margin, 2),
            "frozen": round(self.frozen, 2),
            "commission": round(self.commission, 2),
            "close_profit": round(self.close_profit, 2),
            "position_profit": round(self.position_profit, 2),
            "risk_degree": round(self.risk_degree, 4),
        }


@dataclass
class PositionData:
    """持仓数据"""
    instrument: str
    direction: str                     # "long" / "short"
    volume: int = 0                    # 总持仓
    available: int = 0                 # 可平持仓
    open_price: float = 0.0           # 开仓均价
    position_profit: float = 0.0       # 持仓盈亏
    margin: float = 0.0               # 占用保证金
    contract_multiplier: int = 1       # 合约乘数
    
    @property
    def market_value(self) -> float:
        """持仓市值"""
        return self.volume * self.open_price * self.contract_multiplier
    
    @property
    def profit_ratio(self) -> float:
        """盈亏比例"""
        if self.market_value == 0:
            return 0.0
        return self.position_profit / self.market_value
    
    def to_dict(self) -> dict:
        return {
            "instrument": self.instrument,
            "direction": self.direction,
            "volume": self.volume,
            "available": self.available,
            "open_price": round(self.open_price, 2),
            "position_profit": round(self.position_profit, 2),
            "margin": round(self.margin, 2),
            "market_value": round(self.market_value, 2),
            "profit_ratio": round(self.profit_ratio, 4),
        }


@dataclass
class OrderData:
    """委托数据"""
    order_id: str                      # 报单编号
    instrument: str
    direction: str                     # "buy" / "sel"
    offset: str                        # "open" / "close" / "close_today"
    price: float = 0.0
    volume: int = 0
    traded: int = 0                    # 已成交数量
    status: str = ""                   # "pending" / "partial" / "filled" / "cancelled" / "rejected"
    insert_time: Optional[datetime] = None
    update_time: Optional[datetime] = None
    error_msg: str = ""
    
    def to_dict(self) -> dict:
        return {
            "order_id": self.order_id,
            "instrument": self.instrument,
            "direction": self.direction,
            "offset": self.offset,
            "price": self.price,
            "volume": self.volume,
            "traded": self.traded,
            "status": self.status,
            "insert_time": self.insert_time.strftime("%Y-%m-%d %H:%M:%S") if self.insert_time else "",
            "update_time": self.update_time.strftime("%Y-%m-%d %H:%M:%S") if self.update_time else "",
            "error_msg": self.error_msg,
        }


@dataclass
class TradeData:
    """成交数据"""
    trade_id: str
    order_id: str
    instrument: str
    direction: str                     # "buy" / "sel"
    offset: str                        # "open" / "close" / "close_today"
    price: float = 0.0
    volume: int = 0
    trade_time: Optional[datetime] = None
    commission: float = 0.0           # 手续费
    
    def to_dict(self) -> dict:
        return {
            "trade_id": self.trade_id,
            "order_id": self.order_id,
            "instrument": self.instrument,
            "direction": self.direction,
            "offset": self.offset,
            "price": self.price,
            "volume": self.volume,
            "trade_time": self.trade_time.strftime("%Y-%m-%d %H:%M:%S") if self.trade_time else "",
            "commission": round(self.commission, 2),
        }


@dataclass
class ContractData:
    """合约信息"""
    instrument: str
    name: str = ""
    exchange: str = ""                 # "SHFE", "DCE", "CZCE", "CFFEX", "INE"
    product_class: str = ""            # "期货" / "期权"
    contract_multiplier: int = 1        # 合约乘数
    price_tick: float = 0.0           # 最小变动价位
    volume_tick: int = 1               # 最小变动数量
    max_market_order_volume: int = 0   # 市价单最大量
    min_market_order_volume: int = 0   # 市价单最小量
    max_limit_order_volume: int = 0    # 限价单最大量
    min_limit_order_volume: int = 0    # 限价单最小量
    long_margin_ratio: float = 0.0    # 多头保证金率
    short_margin_ratio: float = 0.0   # 空头保证金率
    
    def to_dict(self) -> dict:
        return {
            "instrument": self.instrument,
            "name": self.name,
            "exchange": self.exchange,
            "product_class": self.product_class,
            "contract_multiplier": self.contract_multiplier,
            "price_tick": self.price_tick,
            "long_margin_ratio": self.long_margin_ratio,
            "short_margin_ratio": self.short_margin_ratio,
        }


@dataclass
class LogData:
    """日志数据"""
    level: str                          # "INFO", "WARNING", "ERROR", "DEBUG"
    message: str
    datetime: datetime = None
    
    def __post_init__(self):
        if self.datetime is None:
            self.datetime = datetime.now()
    
    def __str__(self):
        return f"[{self.datetime.strftime('%Y-%m-%d %H:%M:%S')}] [{self.level}] {self.message}"
