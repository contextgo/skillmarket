# 评分公式详细说明

## 总分计算

```
if direction_wrong:
    total = 0
else:
    total = direction + alpha + timing + drawdown + actionability
```

满分 100 分。方向错误直接 0 分，不再计算其他维度。

---

## 1. 方向正确性 (direction) — 满分 50

```
change = (end_price - base_price) / base_price

if direction == "看涨":
    if change > 0.005:  score = 50
    elif change < -0.005: score = 0  (且整条预测 total = 0)
    else: score = 25  (横盘)

if direction == "看跌":
    if change < -0.005: score = 50
    elif change > 0.005: score = 0  (且整条预测 total = 0)
    else: score = 25  (横盘)

if direction == "中性":
    if abs(change) <= 0.05: score = 50  (确实没大动)
    else: score = 0  (且整条预测 total = 0)
```

- `base_price`: predict_date 当天收盘价（如当天非交易日，取最近一个交易日）
- `end_price`: predict_date + time_horizon 那天收盘价（同上取最近交易日）
- 窗口未到期时 `end_price` 用最新收盘价，标记「未到期-暂估」

## 2. 超额收益 (alpha) — 满分 20

仅方向正确时计算。

```
asset_return = (end_price - base_price) / base_price
bench_return = (bench_end - bench_base) / bench_base  // 沪深300同期

if direction == "看涨":
    alpha = asset_return - bench_return
elif direction == "看跌":
    alpha = bench_return - asset_return  // 跌得比大盘多 = 正alpha
elif direction == "中性":
    alpha = 1 - abs(asset_return)  // 越稳定越好，直接给满分比例

if alpha >= 0.05: score = 20
elif alpha > 0:   score = (alpha / 0.05) * 20
else:             score = 0
```

## 3. 时效性 (timing) — 满分 15

仅方向正确时计算。衡量预测方向多快兑现。

```
// 找到窗口期内第一个交易日收盘价突破 base_price 的日期
// fulfill_day = 从 predict_date 起第几个交易日兑现
// total_days = 窗口期内总交易日数

ratio = fulfill_day / total_days

if ratio <= 0.25: score = 15
elif ratio <= 0.50: score = 10
elif ratio <= 0.75: score = 6
elif ratio <= 1.0:  score = 3
else:               score = 0  // 未兑现
```

- 看涨：收盘价 > base_price 即为兑现
- 看跌：收盘价 < base_price 即为兑现
- 中性：不计算时效性，直接给 15 分（因为"不动"本身就是持续兑现）

## 4. 过程风险 (drawdown) — 满分 10

仅方向正确时计算。衡量跟随建议过程中的最大回撤。

```
// 看涨：从 base_price 到窗口结束，过程中的最大回撤
max_drawdown = max((peak - trough) / peak)  // 标准最大回撤公式

// 看跌：反向计算（做空的最大浮亏 = 最大反弹幅度）
// 中性：取绝对值最大偏离

if max_drawdown < 0.03:  score = 10
elif max_drawdown < 0.08: score = 7
elif max_drawdown < 0.15: score = 4
else:                     score = 1
```

## 5. 可操作性 (actionability) — 满分 5

仅方向正确时计算。根据 LLM 解析出的信息完整度打分：

```
score = 0
if has_asset:      score += 2.0    // 有明确标的
if has_direction:  score += 1.5    // 有明确方向
if has_timeframe:  score += 0.75   // 有时间框架
if has_target:     score += 0.75   // 有目标价
```

---

## 边界情况汇总

| 情况 | 处理方式 |
|------|----------|
| 方向错误 | 整条预测 total = 0，跳过其他维度 |
| 窗口未到期 | 用最新收盘价临时结算，标记「未到期-暂估」 |
| 一条预测多个标的 | LLM 拆分为多条，编号 `#N-1`, `#N-2`，独立评分 |
| 预测日非交易日 | 取之后最近一个交易日的收盘价 |
| 标的代码无法匹配 | 标记「无法识别」，该条不评分，不计入统计 |
| 方向为中性 | 涨跌幅 < 5% 算对；时效性直接给满分 |
