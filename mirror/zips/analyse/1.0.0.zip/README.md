# Financial Prediction Verifier

一个用于验证金融观点、投资判断和市场预测的发布版。

它会读取一个简单的三列表格，调用 Kimi API 从自然语言里抽取标的、方向、时间窗口和目标价，然后抓取对应市场数据并生成评分报告。

## 运行要求

- Node.js 18+
- 可用的 Kimi 开放平台 API Key
- 无需 `npm install`

## 目录结构

```text
financial-prediction-verifier-v1.0.0/
├── SKILL.md
├── README.md
├── _meta.json
├── reference.md
├── examples/
│   └── sample_predictions.csv
└── scripts/
    ├── verify.mjs
    └── .env.local.example
```

## 配置方式

支持以下环境变量：

- `KIMI_API_KEY`
- `LLM_API_KEY`
- `MOONSHOT_API_KEY`
- `LLM_BASE_URL`
- `LLM_MODEL`

推荐方式一：直接在命令前设置环境变量。

```bash
KIMI_API_KEY=sk-xxx node scripts/verify.mjs examples/sample_predictions.csv
```

推荐方式二：复制 `scripts/.env.local.example` 为 `scripts/.env.local`，填入自己的 key。

```bash
cp scripts/.env.local.example scripts/.env.local
node scripts/verify.mjs examples/sample_predictions.csv
```

## 输入格式

CSV 必须包含以下列：

```csv
predictor,predict_date,prediction_text
小明,2025-12-15,黄金还能再涨一段时间
小红,2026-01-10,后面可以关注下隆基绿能
```

## 输出文件

运行完成后会在输入文件同目录生成：

- `{input}_report.md`
- `{input}_scores.csv`

## 说明

- 发布包不包含 `node_modules`
- `scripts/verify.mjs` 已包含运行所需的应用代码与依赖
- 不要在发布包中放入真实的 `scripts/.env.local`
