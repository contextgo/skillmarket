#!/usr/bin/env node

// verify.ts
import { readFileSync as readFileSync2 } from "fs";
import { basename, relative } from "path";

// node_modules/csv-parse/lib/api/CsvError.js
var CsvError = class _CsvError extends Error {
  constructor(code, message, options, ...contexts) {
    if (Array.isArray(message)) message = message.join(" ").trim();
    super(message);
    if (Error.captureStackTrace !== void 0) {
      Error.captureStackTrace(this, _CsvError);
    }
    this.code = code;
    for (const context of contexts) {
      for (const key in context) {
        const value = context[key];
        this[key] = Buffer.isBuffer(value) ? value.toString(options.encoding) : value == null ? value : JSON.parse(JSON.stringify(value));
      }
    }
  }
};

// node_modules/csv-parse/lib/utils/is_object.js
var is_object = function(obj) {
  return typeof obj === "object" && obj !== null && !Array.isArray(obj);
};

// node_modules/csv-parse/lib/api/normalize_columns_array.js
var normalize_columns_array = function(columns) {
  const normalizedColumns = [];
  for (let i = 0, l = columns.length; i < l; i++) {
    const column = columns[i];
    if (column === void 0 || column === null || column === false) {
      normalizedColumns[i] = { disabled: true };
    } else if (typeof column === "string") {
      normalizedColumns[i] = { name: column };
    } else if (is_object(column)) {
      if (typeof column.name !== "string") {
        throw new CsvError("CSV_OPTION_COLUMNS_MISSING_NAME", [
          "Option columns missing name:",
          `property "name" is required at position ${i}`,
          "when column is an object literal"
        ]);
      }
      normalizedColumns[i] = column;
    } else {
      throw new CsvError("CSV_INVALID_COLUMN_DEFINITION", [
        "Invalid column definition:",
        "expect a string or a literal object,",
        `got ${JSON.stringify(column)} at position ${i}`
      ]);
    }
  }
  return normalizedColumns;
};

// node_modules/csv-parse/lib/utils/ResizeableBuffer.js
var ResizeableBuffer = class {
  constructor(size = 100) {
    this.size = size;
    this.length = 0;
    this.buf = Buffer.allocUnsafe(size);
  }
  prepend(val) {
    if (Buffer.isBuffer(val)) {
      const length = this.length + val.length;
      if (length >= this.size) {
        this.resize();
        if (length >= this.size) {
          throw Error("INVALID_BUFFER_STATE");
        }
      }
      const buf = this.buf;
      this.buf = Buffer.allocUnsafe(this.size);
      val.copy(this.buf, 0);
      buf.copy(this.buf, val.length);
      this.length += val.length;
    } else {
      const length = this.length++;
      if (length === this.size) {
        this.resize();
      }
      const buf = this.clone();
      this.buf[0] = val;
      buf.copy(this.buf, 1, 0, length);
    }
  }
  append(val) {
    const length = this.length++;
    if (length === this.size) {
      this.resize();
    }
    this.buf[length] = val;
  }
  clone() {
    return Buffer.from(this.buf.slice(0, this.length));
  }
  resize() {
    const length = this.length;
    this.size = this.size * 2;
    const buf = Buffer.allocUnsafe(this.size);
    this.buf.copy(buf, 0, 0, length);
    this.buf = buf;
  }
  toString(encoding) {
    if (encoding) {
      return this.buf.slice(0, this.length).toString(encoding);
    } else {
      return Uint8Array.prototype.slice.call(this.buf.slice(0, this.length));
    }
  }
  toJSON() {
    return this.toString("utf8");
  }
  reset() {
    this.length = 0;
  }
};
var ResizeableBuffer_default = ResizeableBuffer;

// node_modules/csv-parse/lib/api/init_state.js
var np = 12;
var cr = 13;
var nl = 10;
var space = 32;
var tab = 9;
var init_state = function(options) {
  return {
    bomSkipped: false,
    bufBytesStart: 0,
    castField: options.cast_function,
    commenting: false,
    // Current error encountered by a record
    error: void 0,
    enabled: options.from_line === 1,
    escaping: false,
    escapeIsQuote: Buffer.isBuffer(options.escape) && Buffer.isBuffer(options.quote) && Buffer.compare(options.escape, options.quote) === 0,
    // columns can be `false`, `true`, `Array`
    expectedRecordLength: Array.isArray(options.columns) ? options.columns.length : void 0,
    field: new ResizeableBuffer_default(20),
    firstLineToHeaders: options.cast_first_line_to_header,
    needMoreDataSize: Math.max(
      // Skip if the remaining buffer smaller than comment
      options.comment !== null ? options.comment.length : 0,
      ...options.delimiter.map((delimiter) => delimiter.length),
      // Skip if the remaining buffer can be escape sequence
      options.quote !== null ? options.quote.length : 0
    ),
    previousBuf: void 0,
    quoting: false,
    stop: false,
    rawBuffer: new ResizeableBuffer_default(100),
    record: [],
    recordHasError: false,
    record_length: 0,
    recordDelimiterMaxLength: options.record_delimiter.length === 0 ? 0 : Math.max(...options.record_delimiter.map((v) => v.length)),
    trimChars: [
      Buffer.from(" ", options.encoding)[0],
      Buffer.from("	", options.encoding)[0]
    ],
    wasQuoting: false,
    wasRowDelimiter: false,
    timchars: [
      Buffer.from(Buffer.from([cr], "utf8").toString(), options.encoding),
      Buffer.from(Buffer.from([nl], "utf8").toString(), options.encoding),
      Buffer.from(Buffer.from([np], "utf8").toString(), options.encoding),
      Buffer.from(Buffer.from([space], "utf8").toString(), options.encoding),
      Buffer.from(Buffer.from([tab], "utf8").toString(), options.encoding)
    ]
  };
};

// node_modules/csv-parse/lib/utils/underscore.js
var underscore = function(str) {
  return str.replace(/([A-Z])/g, function(_, match) {
    return "_" + match.toLowerCase();
  });
};

// node_modules/csv-parse/lib/api/normalize_options.js
var normalize_options = function(opts) {
  const options = {};
  for (const opt in opts) {
    options[underscore(opt)] = opts[opt];
  }
  if (options.encoding === void 0 || options.encoding === true) {
    options.encoding = "utf8";
  } else if (options.encoding === null || options.encoding === false) {
    options.encoding = null;
  } else if (typeof options.encoding !== "string" && options.encoding !== null) {
    throw new CsvError(
      "CSV_INVALID_OPTION_ENCODING",
      [
        "Invalid option encoding:",
        "encoding must be a string or null to return a buffer,",
        `got ${JSON.stringify(options.encoding)}`
      ],
      options
    );
  }
  if (options.bom === void 0 || options.bom === null || options.bom === false) {
    options.bom = false;
  } else if (options.bom !== true) {
    throw new CsvError(
      "CSV_INVALID_OPTION_BOM",
      [
        "Invalid option bom:",
        "bom must be true,",
        `got ${JSON.stringify(options.bom)}`
      ],
      options
    );
  }
  options.cast_function = null;
  if (options.cast === void 0 || options.cast === null || options.cast === false || options.cast === "") {
    options.cast = void 0;
  } else if (typeof options.cast === "function") {
    options.cast_function = options.cast;
    options.cast = true;
  } else if (options.cast !== true) {
    throw new CsvError(
      "CSV_INVALID_OPTION_CAST",
      [
        "Invalid option cast:",
        "cast must be true or a function,",
        `got ${JSON.stringify(options.cast)}`
      ],
      options
    );
  }
  if (options.cast_date === void 0 || options.cast_date === null || options.cast_date === false || options.cast_date === "") {
    options.cast_date = false;
  } else if (options.cast_date === true) {
    options.cast_date = function(value) {
      const date = Date.parse(value);
      return !isNaN(date) ? new Date(date) : value;
    };
  } else if (typeof options.cast_date !== "function") {
    throw new CsvError(
      "CSV_INVALID_OPTION_CAST_DATE",
      [
        "Invalid option cast_date:",
        "cast_date must be true or a function,",
        `got ${JSON.stringify(options.cast_date)}`
      ],
      options
    );
  }
  options.cast_first_line_to_header = null;
  if (options.columns === true) {
    options.cast_first_line_to_header = void 0;
  } else if (typeof options.columns === "function") {
    options.cast_first_line_to_header = options.columns;
    options.columns = true;
  } else if (Array.isArray(options.columns)) {
    options.columns = normalize_columns_array(options.columns);
  } else if (options.columns === void 0 || options.columns === null || options.columns === false) {
    options.columns = false;
  } else {
    throw new CsvError(
      "CSV_INVALID_OPTION_COLUMNS",
      [
        "Invalid option columns:",
        "expect an array, a function or true,",
        `got ${JSON.stringify(options.columns)}`
      ],
      options
    );
  }
  if (options.group_columns_by_name === void 0 || options.group_columns_by_name === null || options.group_columns_by_name === false) {
    options.group_columns_by_name = false;
  } else if (options.group_columns_by_name !== true) {
    throw new CsvError(
      "CSV_INVALID_OPTION_GROUP_COLUMNS_BY_NAME",
      [
        "Invalid option group_columns_by_name:",
        "expect an boolean,",
        `got ${JSON.stringify(options.group_columns_by_name)}`
      ],
      options
    );
  } else if (options.columns === false) {
    throw new CsvError(
      "CSV_INVALID_OPTION_GROUP_COLUMNS_BY_NAME",
      [
        "Invalid option group_columns_by_name:",
        "the `columns` mode must be activated."
      ],
      options
    );
  }
  if (options.comment === void 0 || options.comment === null || options.comment === false || options.comment === "") {
    options.comment = null;
  } else {
    if (typeof options.comment === "string") {
      options.comment = Buffer.from(options.comment, options.encoding);
    }
    if (!Buffer.isBuffer(options.comment)) {
      throw new CsvError(
        "CSV_INVALID_OPTION_COMMENT",
        [
          "Invalid option comment:",
          "comment must be a buffer or a string,",
          `got ${JSON.stringify(options.comment)}`
        ],
        options
      );
    }
  }
  if (options.comment_no_infix === void 0 || options.comment_no_infix === null || options.comment_no_infix === false) {
    options.comment_no_infix = false;
  } else if (options.comment_no_infix !== true) {
    throw new CsvError(
      "CSV_INVALID_OPTION_COMMENT",
      [
        "Invalid option comment_no_infix:",
        "value must be a boolean,",
        `got ${JSON.stringify(options.comment_no_infix)}`
      ],
      options
    );
  }
  const delimiter_json = JSON.stringify(options.delimiter);
  if (!Array.isArray(options.delimiter))
    options.delimiter = [options.delimiter];
  if (options.delimiter.length === 0) {
    throw new CsvError(
      "CSV_INVALID_OPTION_DELIMITER",
      [
        "Invalid option delimiter:",
        "delimiter must be a non empty string or buffer or array of string|buffer,",
        `got ${delimiter_json}`
      ],
      options
    );
  }
  options.delimiter = options.delimiter.map(function(delimiter) {
    if (delimiter === void 0 || delimiter === null || delimiter === false) {
      return Buffer.from(",", options.encoding);
    }
    if (typeof delimiter === "string") {
      delimiter = Buffer.from(delimiter, options.encoding);
    }
    if (!Buffer.isBuffer(delimiter) || delimiter.length === 0) {
      throw new CsvError(
        "CSV_INVALID_OPTION_DELIMITER",
        [
          "Invalid option delimiter:",
          "delimiter must be a non empty string or buffer or array of string|buffer,",
          `got ${delimiter_json}`
        ],
        options
      );
    }
    return delimiter;
  });
  if (options.escape === void 0 || options.escape === true) {
    options.escape = Buffer.from('"', options.encoding);
  } else if (typeof options.escape === "string") {
    options.escape = Buffer.from(options.escape, options.encoding);
  } else if (options.escape === null || options.escape === false) {
    options.escape = null;
  }
  if (options.escape !== null) {
    if (!Buffer.isBuffer(options.escape)) {
      throw new Error(
        `Invalid Option: escape must be a buffer, a string or a boolean, got ${JSON.stringify(options.escape)}`
      );
    }
  }
  if (options.from === void 0 || options.from === null) {
    options.from = 1;
  } else {
    if (typeof options.from === "string" && /\d+/.test(options.from)) {
      options.from = parseInt(options.from);
    }
    if (Number.isInteger(options.from)) {
      if (options.from < 0) {
        throw new Error(
          `Invalid Option: from must be a positive integer, got ${JSON.stringify(opts.from)}`
        );
      }
    } else {
      throw new Error(
        `Invalid Option: from must be an integer, got ${JSON.stringify(options.from)}`
      );
    }
  }
  if (options.from_line === void 0 || options.from_line === null) {
    options.from_line = 1;
  } else {
    if (typeof options.from_line === "string" && /\d+/.test(options.from_line)) {
      options.from_line = parseInt(options.from_line);
    }
    if (Number.isInteger(options.from_line)) {
      if (options.from_line <= 0) {
        throw new Error(
          `Invalid Option: from_line must be a positive integer greater than 0, got ${JSON.stringify(opts.from_line)}`
        );
      }
    } else {
      throw new Error(
        `Invalid Option: from_line must be an integer, got ${JSON.stringify(opts.from_line)}`
      );
    }
  }
  if (options.ignore_last_delimiters === void 0 || options.ignore_last_delimiters === null) {
    options.ignore_last_delimiters = false;
  } else if (typeof options.ignore_last_delimiters === "number") {
    options.ignore_last_delimiters = Math.floor(options.ignore_last_delimiters);
    if (options.ignore_last_delimiters === 0) {
      options.ignore_last_delimiters = false;
    }
  } else if (typeof options.ignore_last_delimiters !== "boolean") {
    throw new CsvError(
      "CSV_INVALID_OPTION_IGNORE_LAST_DELIMITERS",
      [
        "Invalid option `ignore_last_delimiters`:",
        "the value must be a boolean value or an integer,",
        `got ${JSON.stringify(options.ignore_last_delimiters)}`
      ],
      options
    );
  }
  if (options.ignore_last_delimiters === true && options.columns === false) {
    throw new CsvError(
      "CSV_IGNORE_LAST_DELIMITERS_REQUIRES_COLUMNS",
      [
        "The option `ignore_last_delimiters`",
        "requires the activation of the `columns` option"
      ],
      options
    );
  }
  if (options.info === void 0 || options.info === null || options.info === false) {
    options.info = false;
  } else if (options.info !== true) {
    throw new Error(
      `Invalid Option: info must be true, got ${JSON.stringify(options.info)}`
    );
  }
  if (options.max_record_size === void 0 || options.max_record_size === null || options.max_record_size === false) {
    options.max_record_size = 0;
  } else if (Number.isInteger(options.max_record_size) && options.max_record_size >= 0) {
  } else if (typeof options.max_record_size === "string" && /\d+/.test(options.max_record_size)) {
    options.max_record_size = parseInt(options.max_record_size);
  } else {
    throw new Error(
      `Invalid Option: max_record_size must be a positive integer, got ${JSON.stringify(options.max_record_size)}`
    );
  }
  if (options.objname === void 0 || options.objname === null || options.objname === false) {
    options.objname = void 0;
  } else if (Buffer.isBuffer(options.objname)) {
    if (options.objname.length === 0) {
      throw new Error(`Invalid Option: objname must be a non empty buffer`);
    }
    if (options.encoding === null) {
    } else {
      options.objname = options.objname.toString(options.encoding);
    }
  } else if (typeof options.objname === "string") {
    if (options.objname.length === 0) {
      throw new Error(`Invalid Option: objname must be a non empty string`);
    }
  } else if (typeof options.objname === "number") {
  } else {
    throw new Error(
      `Invalid Option: objname must be a string or a buffer, got ${options.objname}`
    );
  }
  if (options.objname !== void 0) {
    if (typeof options.objname === "number") {
      if (options.columns !== false) {
        throw Error(
          "Invalid Option: objname index cannot be combined with columns or be defined as a field"
        );
      }
    } else {
      if (options.columns === false) {
        throw Error(
          "Invalid Option: objname field must be combined with columns or be defined as an index"
        );
      }
    }
  }
  if (options.on_record === void 0 || options.on_record === null) {
    options.on_record = void 0;
  } else if (typeof options.on_record !== "function") {
    throw new CsvError(
      "CSV_INVALID_OPTION_ON_RECORD",
      [
        "Invalid option `on_record`:",
        "expect a function,",
        `got ${JSON.stringify(options.on_record)}`
      ],
      options
    );
  }
  if (options.on_skip !== void 0 && options.on_skip !== null && typeof options.on_skip !== "function") {
    throw new Error(
      `Invalid Option: on_skip must be a function, got ${JSON.stringify(options.on_skip)}`
    );
  }
  if (options.quote === null || options.quote === false || options.quote === "") {
    options.quote = null;
  } else {
    if (options.quote === void 0 || options.quote === true) {
      options.quote = Buffer.from('"', options.encoding);
    } else if (typeof options.quote === "string") {
      options.quote = Buffer.from(options.quote, options.encoding);
    }
    if (!Buffer.isBuffer(options.quote)) {
      throw new Error(
        `Invalid Option: quote must be a buffer or a string, got ${JSON.stringify(options.quote)}`
      );
    }
  }
  if (options.raw === void 0 || options.raw === null || options.raw === false) {
    options.raw = false;
  } else if (options.raw !== true) {
    throw new Error(
      `Invalid Option: raw must be true, got ${JSON.stringify(options.raw)}`
    );
  }
  if (options.record_delimiter === void 0) {
    options.record_delimiter = [];
  } else if (typeof options.record_delimiter === "string" || Buffer.isBuffer(options.record_delimiter)) {
    if (options.record_delimiter.length === 0) {
      throw new CsvError(
        "CSV_INVALID_OPTION_RECORD_DELIMITER",
        [
          "Invalid option `record_delimiter`:",
          "value must be a non empty string or buffer,",
          `got ${JSON.stringify(options.record_delimiter)}`
        ],
        options
      );
    }
    options.record_delimiter = [options.record_delimiter];
  } else if (!Array.isArray(options.record_delimiter)) {
    throw new CsvError(
      "CSV_INVALID_OPTION_RECORD_DELIMITER",
      [
        "Invalid option `record_delimiter`:",
        "value must be a string, a buffer or array of string|buffer,",
        `got ${JSON.stringify(options.record_delimiter)}`
      ],
      options
    );
  }
  options.record_delimiter = options.record_delimiter.map(function(rd, i) {
    if (typeof rd !== "string" && !Buffer.isBuffer(rd)) {
      throw new CsvError(
        "CSV_INVALID_OPTION_RECORD_DELIMITER",
        [
          "Invalid option `record_delimiter`:",
          "value must be a string, a buffer or array of string|buffer",
          `at index ${i},`,
          `got ${JSON.stringify(rd)}`
        ],
        options
      );
    } else if (rd.length === 0) {
      throw new CsvError(
        "CSV_INVALID_OPTION_RECORD_DELIMITER",
        [
          "Invalid option `record_delimiter`:",
          "value must be a non empty string or buffer",
          `at index ${i},`,
          `got ${JSON.stringify(rd)}`
        ],
        options
      );
    }
    if (typeof rd === "string") {
      rd = Buffer.from(rd, options.encoding);
    }
    return rd;
  });
  if (typeof options.relax_column_count === "boolean") {
  } else if (options.relax_column_count === void 0 || options.relax_column_count === null) {
    options.relax_column_count = false;
  } else {
    throw new Error(
      `Invalid Option: relax_column_count must be a boolean, got ${JSON.stringify(options.relax_column_count)}`
    );
  }
  if (typeof options.relax_column_count_less === "boolean") {
  } else if (options.relax_column_count_less === void 0 || options.relax_column_count_less === null) {
    options.relax_column_count_less = false;
  } else {
    throw new Error(
      `Invalid Option: relax_column_count_less must be a boolean, got ${JSON.stringify(options.relax_column_count_less)}`
    );
  }
  if (typeof options.relax_column_count_more === "boolean") {
  } else if (options.relax_column_count_more === void 0 || options.relax_column_count_more === null) {
    options.relax_column_count_more = false;
  } else {
    throw new Error(
      `Invalid Option: relax_column_count_more must be a boolean, got ${JSON.stringify(options.relax_column_count_more)}`
    );
  }
  if (typeof options.relax_quotes === "boolean") {
  } else if (options.relax_quotes === void 0 || options.relax_quotes === null) {
    options.relax_quotes = false;
  } else {
    throw new Error(
      `Invalid Option: relax_quotes must be a boolean, got ${JSON.stringify(options.relax_quotes)}`
    );
  }
  if (typeof options.skip_empty_lines === "boolean") {
  } else if (options.skip_empty_lines === void 0 || options.skip_empty_lines === null) {
    options.skip_empty_lines = false;
  } else {
    throw new Error(
      `Invalid Option: skip_empty_lines must be a boolean, got ${JSON.stringify(options.skip_empty_lines)}`
    );
  }
  if (typeof options.skip_records_with_empty_values === "boolean") {
  } else if (options.skip_records_with_empty_values === void 0 || options.skip_records_with_empty_values === null) {
    options.skip_records_with_empty_values = false;
  } else {
    throw new Error(
      `Invalid Option: skip_records_with_empty_values must be a boolean, got ${JSON.stringify(options.skip_records_with_empty_values)}`
    );
  }
  if (typeof options.skip_records_with_error === "boolean") {
  } else if (options.skip_records_with_error === void 0 || options.skip_records_with_error === null) {
    options.skip_records_with_error = false;
  } else {
    throw new Error(
      `Invalid Option: skip_records_with_error must be a boolean, got ${JSON.stringify(options.skip_records_with_error)}`
    );
  }
  if (options.rtrim === void 0 || options.rtrim === null || options.rtrim === false) {
    options.rtrim = false;
  } else if (options.rtrim !== true) {
    throw new Error(
      `Invalid Option: rtrim must be a boolean, got ${JSON.stringify(options.rtrim)}`
    );
  }
  if (options.ltrim === void 0 || options.ltrim === null || options.ltrim === false) {
    options.ltrim = false;
  } else if (options.ltrim !== true) {
    throw new Error(
      `Invalid Option: ltrim must be a boolean, got ${JSON.stringify(options.ltrim)}`
    );
  }
  if (options.trim === void 0 || options.trim === null || options.trim === false) {
    options.trim = false;
  } else if (options.trim !== true) {
    throw new Error(
      `Invalid Option: trim must be a boolean, got ${JSON.stringify(options.trim)}`
    );
  }
  if (options.trim === true && opts.ltrim !== false) {
    options.ltrim = true;
  } else if (options.ltrim !== true) {
    options.ltrim = false;
  }
  if (options.trim === true && opts.rtrim !== false) {
    options.rtrim = true;
  } else if (options.rtrim !== true) {
    options.rtrim = false;
  }
  if (options.to === void 0 || options.to === null) {
    options.to = -1;
  } else {
    if (typeof options.to === "string" && /\d+/.test(options.to)) {
      options.to = parseInt(options.to);
    }
    if (Number.isInteger(options.to)) {
      if (options.to <= 0) {
        throw new Error(
          `Invalid Option: to must be a positive integer greater than 0, got ${JSON.stringify(opts.to)}`
        );
      }
    } else {
      throw new Error(
        `Invalid Option: to must be an integer, got ${JSON.stringify(opts.to)}`
      );
    }
  }
  if (options.to_line === void 0 || options.to_line === null) {
    options.to_line = -1;
  } else {
    if (typeof options.to_line === "string" && /\d+/.test(options.to_line)) {
      options.to_line = parseInt(options.to_line);
    }
    if (Number.isInteger(options.to_line)) {
      if (options.to_line <= 0) {
        throw new Error(
          `Invalid Option: to_line must be a positive integer greater than 0, got ${JSON.stringify(opts.to_line)}`
        );
      }
    } else {
      throw new Error(
        `Invalid Option: to_line must be an integer, got ${JSON.stringify(opts.to_line)}`
      );
    }
  }
  return options;
};

// node_modules/csv-parse/lib/api/index.js
var isRecordEmpty = function(record) {
  return record.every(
    (field) => field == null || field.toString && field.toString().trim() === ""
  );
};
var cr2 = 13;
var nl2 = 10;
var boms = {
  // Note, the following are equals:
  // Buffer.from("\ufeff")
  // Buffer.from([239, 187, 191])
  // Buffer.from('EFBBBF', 'hex')
  utf8: Buffer.from([239, 187, 191]),
  // Note, the following are equals:
  // Buffer.from "\ufeff", 'utf16le
  // Buffer.from([255, 254])
  utf16le: Buffer.from([255, 254])
};
var transform = function(original_options = {}) {
  const info = {
    bytes: 0,
    comment_lines: 0,
    empty_lines: 0,
    invalid_field_length: 0,
    lines: 1,
    records: 0
  };
  const options = normalize_options(original_options);
  return {
    info,
    original_options,
    options,
    state: init_state(options),
    __needMoreData: function(i, bufLen, end) {
      if (end) return false;
      const { encoding, escape, quote } = this.options;
      const { quoting, needMoreDataSize, recordDelimiterMaxLength } = this.state;
      const numOfCharLeft = bufLen - i - 1;
      const requiredLength = Math.max(
        needMoreDataSize,
        // Skip if the remaining buffer smaller than record delimiter
        // If "record_delimiter" is yet to be discovered:
        // 1. It is equals to `[]` and "recordDelimiterMaxLength" equals `0`
        // 2. We set the length to windows line ending in the current encoding
        // Note, that encoding is known from user or bom discovery at that point
        // recordDelimiterMaxLength,
        recordDelimiterMaxLength === 0 ? Buffer.from("\r\n", encoding).length : recordDelimiterMaxLength,
        // Skip if remaining buffer can be an escaped quote
        quoting ? (escape === null ? 0 : escape.length) + quote.length : 0,
        // Skip if remaining buffer can be record delimiter following the closing quote
        quoting ? quote.length + recordDelimiterMaxLength : 0
      );
      return numOfCharLeft < requiredLength;
    },
    // Central parser implementation
    parse: function(nextBuf, end, push, close) {
      const {
        bom,
        comment_no_infix,
        encoding,
        from_line,
        ltrim,
        max_record_size,
        raw,
        relax_quotes,
        rtrim,
        skip_empty_lines,
        to,
        to_line
      } = this.options;
      let { comment, escape, quote, record_delimiter } = this.options;
      const { bomSkipped, previousBuf, rawBuffer, escapeIsQuote } = this.state;
      let buf;
      if (previousBuf === void 0) {
        if (nextBuf === void 0) {
          close();
          return;
        } else {
          buf = nextBuf;
        }
      } else if (previousBuf !== void 0 && nextBuf === void 0) {
        buf = previousBuf;
      } else {
        buf = Buffer.concat([previousBuf, nextBuf]);
      }
      if (bomSkipped === false) {
        if (bom === false) {
          this.state.bomSkipped = true;
        } else if (buf.length < 3) {
          if (end === false) {
            this.state.previousBuf = buf;
            return;
          }
        } else {
          for (const encoding2 in boms) {
            if (boms[encoding2].compare(buf, 0, boms[encoding2].length) === 0) {
              const bomLength = boms[encoding2].length;
              this.state.bufBytesStart += bomLength;
              buf = buf.slice(bomLength);
              this.options = normalize_options({
                ...this.original_options,
                encoding: encoding2
              });
              ({ comment, escape, quote } = this.options);
              break;
            }
          }
          this.state.bomSkipped = true;
        }
      }
      const bufLen = buf.length;
      let pos;
      for (pos = 0; pos < bufLen; pos++) {
        if (this.__needMoreData(pos, bufLen, end)) {
          break;
        }
        if (this.state.wasRowDelimiter === true) {
          this.info.lines++;
          this.state.wasRowDelimiter = false;
        }
        if (to_line !== -1 && this.info.lines > to_line) {
          this.state.stop = true;
          close();
          return;
        }
        if (this.state.quoting === false && record_delimiter.length === 0) {
          const record_delimiterCount = this.__autoDiscoverRecordDelimiter(
            buf,
            pos
          );
          if (record_delimiterCount) {
            record_delimiter = this.options.record_delimiter;
          }
        }
        const chr = buf[pos];
        if (raw === true) {
          rawBuffer.append(chr);
        }
        if ((chr === cr2 || chr === nl2) && this.state.wasRowDelimiter === false) {
          this.state.wasRowDelimiter = true;
        }
        if (this.state.escaping === true) {
          this.state.escaping = false;
        } else {
          if (escape !== null && this.state.quoting === true && this.__isEscape(buf, pos, chr) && pos + escape.length < bufLen) {
            if (escapeIsQuote) {
              if (this.__isQuote(buf, pos + escape.length)) {
                this.state.escaping = true;
                pos += escape.length - 1;
                continue;
              }
            } else {
              this.state.escaping = true;
              pos += escape.length - 1;
              continue;
            }
          }
          if (this.state.commenting === false && this.__isQuote(buf, pos)) {
            if (this.state.quoting === true) {
              const nextChr = buf[pos + quote.length];
              const isNextChrTrimable = rtrim && this.__isCharTrimable(buf, pos + quote.length);
              const isNextChrComment = comment !== null && this.__compareBytes(comment, buf, pos + quote.length, nextChr);
              const isNextChrDelimiter = this.__isDelimiter(
                buf,
                pos + quote.length,
                nextChr
              );
              const isNextChrRecordDelimiter = record_delimiter.length === 0 ? this.__autoDiscoverRecordDelimiter(buf, pos + quote.length) : this.__isRecordDelimiter(nextChr, buf, pos + quote.length);
              if (escape !== null && this.__isEscape(buf, pos, chr) && this.__isQuote(buf, pos + escape.length)) {
                pos += escape.length - 1;
              } else if (!nextChr || isNextChrDelimiter || isNextChrRecordDelimiter || isNextChrComment || isNextChrTrimable) {
                this.state.quoting = false;
                this.state.wasQuoting = true;
                pos += quote.length - 1;
                continue;
              } else if (relax_quotes === false) {
                const err = this.__error(
                  new CsvError(
                    "CSV_INVALID_CLOSING_QUOTE",
                    [
                      "Invalid Closing Quote:",
                      `got "${String.fromCharCode(nextChr)}"`,
                      `at line ${this.info.lines}`,
                      "instead of delimiter, record delimiter, trimable character",
                      "(if activated) or comment"
                    ],
                    this.options,
                    this.__infoField()
                  )
                );
                if (err !== void 0) return err;
              } else {
                this.state.quoting = false;
                this.state.wasQuoting = true;
                this.state.field.prepend(quote);
                pos += quote.length - 1;
              }
            } else {
              if (this.state.field.length !== 0) {
                if (relax_quotes === false) {
                  const info2 = this.__infoField();
                  const bom2 = Object.keys(boms).map(
                    (b) => boms[b].equals(this.state.field.toString()) ? b : false
                  ).filter(Boolean)[0];
                  const err = this.__error(
                    new CsvError(
                      "INVALID_OPENING_QUOTE",
                      [
                        "Invalid Opening Quote:",
                        `a quote is found on field ${JSON.stringify(info2.column)} at line ${info2.lines}, value is ${JSON.stringify(this.state.field.toString(encoding))}`,
                        bom2 ? `(${bom2} bom)` : void 0
                      ],
                      this.options,
                      info2,
                      {
                        field: this.state.field
                      }
                    )
                  );
                  if (err !== void 0) return err;
                }
              } else {
                this.state.quoting = true;
                pos += quote.length - 1;
                continue;
              }
            }
          }
          if (this.state.quoting === false) {
            const recordDelimiterLength = this.__isRecordDelimiter(
              chr,
              buf,
              pos
            );
            if (recordDelimiterLength !== 0) {
              const skipCommentLine = this.state.commenting && this.state.wasQuoting === false && this.state.record.length === 0 && this.state.field.length === 0;
              if (skipCommentLine) {
                this.info.comment_lines++;
              } else {
                if (this.state.enabled === false && this.info.lines + (this.state.wasRowDelimiter === true ? 1 : 0) >= from_line) {
                  this.state.enabled = true;
                  this.__resetField();
                  this.__resetRecord();
                  pos += recordDelimiterLength - 1;
                  continue;
                }
                if (skip_empty_lines === true && this.state.wasQuoting === false && this.state.record.length === 0 && this.state.field.length === 0) {
                  this.info.empty_lines++;
                  pos += recordDelimiterLength - 1;
                  continue;
                }
                this.info.bytes = this.state.bufBytesStart + pos;
                const errField = this.__onField();
                if (errField !== void 0) return errField;
                this.info.bytes = this.state.bufBytesStart + pos + recordDelimiterLength;
                const errRecord = this.__onRecord(push);
                if (errRecord !== void 0) return errRecord;
                if (to !== -1 && this.info.records >= to) {
                  this.state.stop = true;
                  close();
                  return;
                }
              }
              this.state.commenting = false;
              pos += recordDelimiterLength - 1;
              continue;
            }
            if (this.state.commenting) {
              continue;
            }
            if (comment !== null && (comment_no_infix === false || this.state.record.length === 0 && this.state.field.length === 0)) {
              const commentCount = this.__compareBytes(comment, buf, pos, chr);
              if (commentCount !== 0) {
                this.state.commenting = true;
                continue;
              }
            }
            const delimiterLength = this.__isDelimiter(buf, pos, chr);
            if (delimiterLength !== 0) {
              this.info.bytes = this.state.bufBytesStart + pos;
              const errField = this.__onField();
              if (errField !== void 0) return errField;
              pos += delimiterLength - 1;
              continue;
            }
          }
        }
        if (this.state.commenting === false) {
          if (max_record_size !== 0 && this.state.record_length + this.state.field.length > max_record_size) {
            return this.__error(
              new CsvError(
                "CSV_MAX_RECORD_SIZE",
                [
                  "Max Record Size:",
                  "record exceed the maximum number of tolerated bytes",
                  `of ${max_record_size}`,
                  `at line ${this.info.lines}`
                ],
                this.options,
                this.__infoField()
              )
            );
          }
        }
        const lappend = ltrim === false || this.state.quoting === true || this.state.field.length !== 0 || !this.__isCharTrimable(buf, pos);
        const rappend = rtrim === false || this.state.wasQuoting === false;
        if (lappend === true && rappend === true) {
          this.state.field.append(chr);
        } else if (rtrim === true && !this.__isCharTrimable(buf, pos)) {
          return this.__error(
            new CsvError(
              "CSV_NON_TRIMABLE_CHAR_AFTER_CLOSING_QUOTE",
              [
                "Invalid Closing Quote:",
                "found non trimable byte after quote",
                `at line ${this.info.lines}`
              ],
              this.options,
              this.__infoField()
            )
          );
        } else {
          if (lappend === false) {
            pos += this.__isCharTrimable(buf, pos) - 1;
          }
          continue;
        }
      }
      if (end === true) {
        if (this.state.quoting === true) {
          const err = this.__error(
            new CsvError(
              "CSV_QUOTE_NOT_CLOSED",
              [
                "Quote Not Closed:",
                `the parsing is finished with an opening quote at line ${this.info.lines}`
              ],
              this.options,
              this.__infoField()
            )
          );
          if (err !== void 0) return err;
        } else {
          if (this.state.wasQuoting === true || this.state.record.length !== 0 || this.state.field.length !== 0) {
            this.info.bytes = this.state.bufBytesStart + pos;
            const errField = this.__onField();
            if (errField !== void 0) return errField;
            const errRecord = this.__onRecord(push);
            if (errRecord !== void 0) return errRecord;
          } else if (this.state.wasRowDelimiter === true) {
            this.info.empty_lines++;
          } else if (this.state.commenting === true) {
            this.info.comment_lines++;
          }
        }
      } else {
        this.state.bufBytesStart += pos;
        this.state.previousBuf = buf.slice(pos);
      }
      if (this.state.wasRowDelimiter === true) {
        this.info.lines++;
        this.state.wasRowDelimiter = false;
      }
    },
    __onRecord: function(push) {
      const {
        columns,
        group_columns_by_name,
        encoding,
        info: info2,
        from,
        relax_column_count,
        relax_column_count_less,
        relax_column_count_more,
        raw,
        skip_records_with_empty_values
      } = this.options;
      const { enabled, record } = this.state;
      if (enabled === false) {
        return this.__resetRecord();
      }
      const recordLength = record.length;
      if (columns === true) {
        if (skip_records_with_empty_values === true && isRecordEmpty(record)) {
          this.__resetRecord();
          return;
        }
        return this.__firstLineToColumns(record);
      }
      if (columns === false && this.info.records === 0) {
        this.state.expectedRecordLength = recordLength;
      }
      if (recordLength !== this.state.expectedRecordLength) {
        const err = columns === false ? new CsvError(
          "CSV_RECORD_INCONSISTENT_FIELDS_LENGTH",
          [
            "Invalid Record Length:",
            `expect ${this.state.expectedRecordLength},`,
            `got ${recordLength} on line ${this.info.lines}`
          ],
          this.options,
          this.__infoField(),
          {
            record
          }
        ) : new CsvError(
          "CSV_RECORD_INCONSISTENT_COLUMNS",
          [
            "Invalid Record Length:",
            `columns length is ${columns.length},`,
            // rename columns
            `got ${recordLength} on line ${this.info.lines}`
          ],
          this.options,
          this.__infoField(),
          {
            record
          }
        );
        if (relax_column_count === true || relax_column_count_less === true && recordLength < this.state.expectedRecordLength || relax_column_count_more === true && recordLength > this.state.expectedRecordLength) {
          this.info.invalid_field_length++;
          this.state.error = err;
        } else {
          const finalErr = this.__error(err);
          if (finalErr) return finalErr;
        }
      }
      if (skip_records_with_empty_values === true && isRecordEmpty(record)) {
        this.__resetRecord();
        return;
      }
      if (this.state.recordHasError === true) {
        this.__resetRecord();
        this.state.recordHasError = false;
        return;
      }
      this.info.records++;
      if (from === 1 || this.info.records >= from) {
        const { objname } = this.options;
        if (columns !== false) {
          const obj = {};
          for (let i = 0, l = record.length; i < l; i++) {
            if (columns[i] === void 0 || columns[i].disabled) continue;
            if (group_columns_by_name === true && obj[columns[i].name] !== void 0) {
              if (Array.isArray(obj[columns[i].name])) {
                obj[columns[i].name] = obj[columns[i].name].concat(record[i]);
              } else {
                obj[columns[i].name] = [obj[columns[i].name], record[i]];
              }
            } else {
              obj[columns[i].name] = record[i];
            }
          }
          if (raw === true || info2 === true) {
            const extRecord = Object.assign(
              { record: obj },
              raw === true ? { raw: this.state.rawBuffer.toString(encoding) } : {},
              info2 === true ? { info: this.__infoRecord() } : {}
            );
            const err = this.__push(
              objname === void 0 ? extRecord : [obj[objname], extRecord],
              push
            );
            if (err) {
              return err;
            }
          } else {
            const err = this.__push(
              objname === void 0 ? obj : [obj[objname], obj],
              push
            );
            if (err) {
              return err;
            }
          }
        } else {
          if (raw === true || info2 === true) {
            const extRecord = Object.assign(
              { record },
              raw === true ? { raw: this.state.rawBuffer.toString(encoding) } : {},
              info2 === true ? { info: this.__infoRecord() } : {}
            );
            const err = this.__push(
              objname === void 0 ? extRecord : [record[objname], extRecord],
              push
            );
            if (err) {
              return err;
            }
          } else {
            const err = this.__push(
              objname === void 0 ? record : [record[objname], record],
              push
            );
            if (err) {
              return err;
            }
          }
        }
      }
      this.__resetRecord();
    },
    __firstLineToColumns: function(record) {
      const { firstLineToHeaders } = this.state;
      try {
        const headers = firstLineToHeaders === void 0 ? record : firstLineToHeaders.call(null, record);
        if (!Array.isArray(headers)) {
          return this.__error(
            new CsvError(
              "CSV_INVALID_COLUMN_MAPPING",
              [
                "Invalid Column Mapping:",
                "expect an array from column function,",
                `got ${JSON.stringify(headers)}`
              ],
              this.options,
              this.__infoField(),
              {
                headers
              }
            )
          );
        }
        const normalizedHeaders = normalize_columns_array(headers);
        this.state.expectedRecordLength = normalizedHeaders.length;
        this.options.columns = normalizedHeaders;
        this.__resetRecord();
        return;
      } catch (err) {
        return err;
      }
    },
    __resetRecord: function() {
      if (this.options.raw === true) {
        this.state.rawBuffer.reset();
      }
      this.state.error = void 0;
      this.state.record = [];
      this.state.record_length = 0;
    },
    __onField: function() {
      const { cast, encoding, rtrim, max_record_size } = this.options;
      const { enabled, wasQuoting } = this.state;
      if (enabled === false) {
        return this.__resetField();
      }
      let field = this.state.field.toString(encoding);
      if (rtrim === true && wasQuoting === false) {
        field = field.trimRight();
      }
      if (cast === true) {
        const [err, f] = this.__cast(field);
        if (err !== void 0) return err;
        field = f;
      }
      this.state.record.push(field);
      if (max_record_size !== 0 && typeof field === "string") {
        this.state.record_length += field.length;
      }
      this.__resetField();
    },
    __resetField: function() {
      this.state.field.reset();
      this.state.wasQuoting = false;
    },
    __push: function(record, push) {
      const { on_record } = this.options;
      if (on_record !== void 0) {
        const info2 = this.__infoRecord();
        try {
          record = on_record.call(null, record, info2);
        } catch (err) {
          return err;
        }
        if (record === void 0 || record === null) {
          return;
        }
      }
      push(record);
    },
    // Return a tuple with the error and the casted value
    __cast: function(field) {
      const { columns, relax_column_count } = this.options;
      const isColumns = Array.isArray(columns);
      if (isColumns === true && relax_column_count && this.options.columns.length <= this.state.record.length) {
        return [void 0, void 0];
      }
      if (this.state.castField !== null) {
        try {
          const info2 = this.__infoField();
          return [void 0, this.state.castField.call(null, field, info2)];
        } catch (err) {
          return [err];
        }
      }
      if (this.__isFloat(field)) {
        return [void 0, parseFloat(field)];
      } else if (this.options.cast_date !== false) {
        const info2 = this.__infoField();
        return [void 0, this.options.cast_date.call(null, field, info2)];
      }
      return [void 0, field];
    },
    // Helper to test if a character is a space or a line delimiter
    __isCharTrimable: function(buf, pos) {
      const isTrim = (buf2, pos2) => {
        const { timchars } = this.state;
        loop1: for (let i = 0; i < timchars.length; i++) {
          const timchar = timchars[i];
          for (let j = 0; j < timchar.length; j++) {
            if (timchar[j] !== buf2[pos2 + j]) continue loop1;
          }
          return timchar.length;
        }
        return 0;
      };
      return isTrim(buf, pos);
    },
    // Keep it in case we implement the `cast_int` option
    // __isInt(value){
    //   // return Number.isInteger(parseInt(value))
    //   // return !isNaN( parseInt( obj ) );
    //   return /^(\-|\+)?[1-9][0-9]*$/.test(value)
    // }
    __isFloat: function(value) {
      return value - parseFloat(value) + 1 >= 0;
    },
    __compareBytes: function(sourceBuf, targetBuf, targetPos, firstByte) {
      if (sourceBuf[0] !== firstByte) return 0;
      const sourceLength = sourceBuf.length;
      for (let i = 1; i < sourceLength; i++) {
        if (sourceBuf[i] !== targetBuf[targetPos + i]) return 0;
      }
      return sourceLength;
    },
    __isDelimiter: function(buf, pos, chr) {
      const { delimiter, ignore_last_delimiters } = this.options;
      if (ignore_last_delimiters === true && this.state.record.length === this.options.columns.length - 1) {
        return 0;
      } else if (ignore_last_delimiters !== false && typeof ignore_last_delimiters === "number" && this.state.record.length === ignore_last_delimiters - 1) {
        return 0;
      }
      loop1: for (let i = 0; i < delimiter.length; i++) {
        const del = delimiter[i];
        if (del[0] === chr) {
          for (let j = 1; j < del.length; j++) {
            if (del[j] !== buf[pos + j]) continue loop1;
          }
          return del.length;
        }
      }
      return 0;
    },
    __isRecordDelimiter: function(chr, buf, pos) {
      const { record_delimiter } = this.options;
      const recordDelimiterLength = record_delimiter.length;
      loop1: for (let i = 0; i < recordDelimiterLength; i++) {
        const rd = record_delimiter[i];
        const rdLength = rd.length;
        if (rd[0] !== chr) {
          continue;
        }
        for (let j = 1; j < rdLength; j++) {
          if (rd[j] !== buf[pos + j]) {
            continue loop1;
          }
        }
        return rd.length;
      }
      return 0;
    },
    __isEscape: function(buf, pos, chr) {
      const { escape } = this.options;
      if (escape === null) return false;
      const l = escape.length;
      if (escape[0] === chr) {
        for (let i = 0; i < l; i++) {
          if (escape[i] !== buf[pos + i]) {
            return false;
          }
        }
        return true;
      }
      return false;
    },
    __isQuote: function(buf, pos) {
      const { quote } = this.options;
      if (quote === null) return false;
      const l = quote.length;
      for (let i = 0; i < l; i++) {
        if (quote[i] !== buf[pos + i]) {
          return false;
        }
      }
      return true;
    },
    __autoDiscoverRecordDelimiter: function(buf, pos) {
      const { encoding } = this.options;
      const rds = [
        // Important, the windows line ending must be before mac os 9
        Buffer.from("\r\n", encoding),
        Buffer.from("\n", encoding),
        Buffer.from("\r", encoding)
      ];
      loop: for (let i = 0; i < rds.length; i++) {
        const l = rds[i].length;
        for (let j = 0; j < l; j++) {
          if (rds[i][j] !== buf[pos + j]) {
            continue loop;
          }
        }
        this.options.record_delimiter.push(rds[i]);
        this.state.recordDelimiterMaxLength = rds[i].length;
        return rds[i].length;
      }
      return 0;
    },
    __error: function(msg) {
      const { encoding, raw, skip_records_with_error } = this.options;
      const err = typeof msg === "string" ? new Error(msg) : msg;
      if (skip_records_with_error) {
        this.state.recordHasError = true;
        if (this.options.on_skip !== void 0) {
          this.options.on_skip(
            err,
            raw ? this.state.rawBuffer.toString(encoding) : void 0
          );
        }
        return void 0;
      } else {
        return err;
      }
    },
    __infoDataSet: function() {
      return {
        ...this.info,
        columns: this.options.columns
      };
    },
    __infoRecord: function() {
      const { columns, raw, encoding } = this.options;
      return {
        ...this.__infoDataSet(),
        error: this.state.error,
        header: columns === true,
        index: this.state.record.length,
        raw: raw ? this.state.rawBuffer.toString(encoding) : void 0
      };
    },
    __infoField: function() {
      const { columns } = this.options;
      const isColumns = Array.isArray(columns);
      return {
        ...this.__infoRecord(),
        column: isColumns === true ? columns.length > this.state.record.length ? columns[this.state.record.length].name : null : this.state.record.length,
        quoting: this.state.wasQuoting
      };
    }
  };
};

// node_modules/csv-parse/lib/sync.js
var parse = function(data, opts = {}) {
  if (typeof data === "string") {
    data = Buffer.from(data);
  }
  const records = opts && opts.objname ? {} : [];
  const parser = transform(opts);
  const push = (record) => {
    if (parser.options.objname === void 0) records.push(record);
    else {
      records[record[0]] = record[1];
    }
  };
  const close = () => {
  };
  const err1 = parser.parse(data, false, push, close);
  if (err1 !== void 0) throw err1;
  const err2 = parser.parse(void 0, true, push, close);
  if (err2 !== void 0) throw err2;
  return records;
};

// config.ts
import { existsSync, readFileSync } from "fs";
var DEFAULT_LLM_PROVIDER = "Kimi";
var DEFAULT_LLM_BASE_URL = "https://api.moonshot.cn/v1";
var DEFAULT_LLM_MODEL = "kimi-k2.5";
var LLM_API_KEY_ENV_NAMES = [
  "LLM_API_KEY",
  "KIMI_API_KEY",
  "MOONSHOT_API_KEY"
];
var localEnvLoaded = false;
function loadLocalEnvFile() {
  if (localEnvLoaded) return;
  localEnvLoaded = true;
  const localEnvPath = new URL("./.env.local", import.meta.url);
  if (!existsSync(localEnvPath)) return;
  const content = readFileSync(localEnvPath, "utf-8");
  for (const rawLine of content.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith("#")) continue;
    const eqIndex = line.indexOf("=");
    if (eqIndex <= 0) continue;
    const key = line.slice(0, eqIndex).trim();
    let value = line.slice(eqIndex + 1).trim();
    if (value.startsWith('"') && value.endsWith('"') || value.startsWith("'") && value.endsWith("'")) {
      value = value.slice(1, -1);
    }
    if (!process.env[key]) {
      process.env[key] = value;
    }
  }
}
function getEnv(name) {
  const value = process.env[name]?.trim();
  return value ? value : void 0;
}
function normalizeBaseURL(baseURL) {
  return baseURL.replace(/\/+$/, "");
}
function loadLLMConfig() {
  loadLocalEnvFile();
  const apiKeyEntry = LLM_API_KEY_ENV_NAMES.find((name) => getEnv(name));
  const apiKey = apiKeyEntry ? getEnv(apiKeyEntry) : void 0;
  if (!apiKey) {
    throw new Error(
      `\u672A\u8BBE\u7F6E\u6A21\u578B API Key\uFF0C\u8BF7\u914D\u7F6E ${LLM_API_KEY_ENV_NAMES.join(" / ")} \u4E4B\u4E00`
    );
  }
  const baseURL = normalizeBaseURL(
    getEnv("LLM_BASE_URL") ?? DEFAULT_LLM_BASE_URL
  );
  const model = getEnv("LLM_MODEL") ?? DEFAULT_LLM_MODEL;
  return {
    providerLabel: DEFAULT_LLM_PROVIDER,
    apiKey,
    apiKeyEnvName: apiKeyEntry ?? LLM_API_KEY_ENV_NAMES[1],
    baseURL,
    chatCompletionsURL: `${baseURL}/chat/completions`,
    model
  };
}

// parser.ts
var BATCH_SIZE = 10;
var SYSTEM_PROMPT = `\u4F60\u662F\u4E00\u4E2A\u91D1\u878D\u9884\u6D4B\u89E3\u6790\u52A9\u624B\u3002\u7ED9\u4F60\u4E00\u6279\u91D1\u878D\u9884\u6D4B\u6587\u672C\uFF0C\u8BF7\u4ECE\u6BCF\u6761\u9884\u6D4B\u4E2D\u63D0\u53D6\u7ED3\u6784\u5316\u4FE1\u606F\u3002

\u5BF9\u4E8E\u6BCF\u6761\u9884\u6D4B\uFF0C\u63D0\u53D6\u4EE5\u4E0B\u5B57\u6BB5\uFF1A
- assets: \u6570\u7EC4\uFF0C\u6BCF\u4E2A\u5143\u7D20\u4EE3\u8868\u4E00\u4E2A\u6807\u7684\u5224\u65AD\uFF0C\u5305\u542B\uFF1A
  - asset_name: \u6807\u7684\u540D\u79F0\uFF08\u5982"\u9EC4\u91D1"\u3001"\u9686\u57FA\u7EFF\u80FD"\u3001"\u6CAA\u6DF1300"\uFF09
  - asset_type: stock / etf / commodity / index
  - direction: \u770B\u6DA8 / \u770B\u8DCC / \u4E2D\u6027
  - time_horizon_days: \u9884\u6D4B\u65F6\u95F4\u7A97\u53E3\uFF08\u5929\u6570\uFF09\uFF0C\u4ECE\u8BED\u5883\u63A8\u65AD\u3002\u5982\u679C\u8BF4"\u77ED\u671F"=30\u5929\uFF0C"\u4E00\u6BB5\u65F6\u95F4"=60\u5929\uFF0C"\u4E0A\u534A\u5E74/\u4E0B\u534A\u5E74"=180\u5929\uFF0C"\u4ECA\u5E74"=365\u5929\uFF0C\u65E0\u660E\u786E\u63D0\u793A=60\u5929
  - target_price: \u76EE\u6807\u4EF7\uFF08\u6570\u5B57\uFF0C\u5982\u65E0\u5219null\uFF09
  - confidence_hint: \u5F3A\u70C8\u63A8\u8350 / \u4E00\u822C\u5EFA\u8BAE / \u4EC5\u4F9B\u53C2\u8003

\u5982\u679C\u4E00\u6761\u9884\u6D4B\u63D0\u5230\u591A\u4E2A\u6807\u7684\u6216\u591A\u4E2A\u65B9\u5411\u5224\u65AD\uFF0C\u62C6\u5206\u4E3A\u591A\u4E2A asset \u5BF9\u8C61\u3002

\u8FD4\u56DE\u4E25\u683C\u7684 JSON \u6570\u7EC4\uFF0C\u6BCF\u4E2A\u5143\u7D20\u5BF9\u5E94\u4E00\u6761\u8F93\u5165\u9884\u6D4B\uFF0C\u683C\u5F0F\uFF1A
[
  {
    "id": 1,
    "assets": [
      {
        "asset_name": "\u9EC4\u91D1",
        "asset_type": "commodity",
        "direction": "\u770B\u6DA8",
        "time_horizon_days": 60,
        "target_price": null,
        "confidence_hint": "\u4E00\u822C\u5EFA\u8BAE"
      }
    ]
  }
]

\u53EA\u8FD4\u56DE JSON\uFF0C\u4E0D\u8981\u5176\u4ED6\u6587\u5B57\u3002`;
async function callLLM(config, predictions) {
  const userContent = predictions.map((p) => `[ID=${p.id}] (${p.predict_date}) ${p.prediction_text}`).join("\n\n");
  const res = await fetch(config.chatCompletionsURL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${config.apiKey}`
    },
    body: JSON.stringify({
      model: config.model,
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        { role: "user", content: userContent }
      ],
      temperature: 1,
      response_format: { type: "json_object" }
    })
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`${config.providerLabel} API error ${res.status}: ${text}`);
  }
  const data = await res.json();
  const content = data.choices[0].message.content;
  try {
    const parsed = JSON.parse(content);
    if (Array.isArray(parsed)) return parsed;
    if (parsed.results && Array.isArray(parsed.results)) return parsed.results;
    if (parsed.data && Array.isArray(parsed.data)) return parsed.data;
    for (const v of Object.values(parsed)) {
      if (Array.isArray(v)) return v;
    }
    throw new Error("Unexpected response structure");
  } catch (e) {
    throw new Error(`Failed to parse LLM response: ${content.slice(0, 500)}`);
  }
}
async function parsePredictions(config, predictions) {
  const results = [];
  const batches = [];
  for (let i = 0; i < predictions.length; i += BATCH_SIZE) {
    batches.push(predictions.slice(i, i + BATCH_SIZE));
  }
  console.log(
    `[Parser] \u5171 ${predictions.length} \u6761\u9884\u6D4B\uFF0C\u5206 ${batches.length} \u6279\u8C03\u7528 ${config.providerLabel} API...`
  );
  for (let bi = 0; bi < batches.length; bi++) {
    const batch = batches[bi];
    console.log(
      `[Parser] \u7B2C ${bi + 1}/${batches.length} \u6279\uFF08${batch.length} \u6761\uFF09...`
    );
    const llmResults = await callLLM(config, batch);
    const predMap = new Map(batch.map((p) => [p.id, p]));
    for (const lr of llmResults) {
      const pred = predMap.get(lr.id);
      if (!pred) continue;
      const assets = lr.assets || [];
      if (assets.length === 0) {
        results.push({
          original_id: pred.id,
          sub_id: 1,
          predictor: pred.predictor,
          predict_date: pred.predict_date,
          prediction_text: pred.prediction_text,
          asset_name: "\u672A\u8BC6\u522B",
          asset_code: null,
          asset_type: "stock",
          direction: "\u4E2D\u6027",
          time_horizon_days: 60,
          target_price: null,
          confidence_hint: "\u4EC5\u4F9B\u53C2\u8003",
          has_asset: false,
          has_direction: false,
          has_timeframe: false,
          has_target: false
        });
        continue;
      }
      for (let ai = 0; ai < assets.length; ai++) {
        const a = assets[ai];
        const dir = ["\u770B\u6DA8", "\u770B\u8DCC", "\u4E2D\u6027"].includes(
          a.direction
        ) ? a.direction : "\u4E2D\u6027";
        results.push({
          original_id: pred.id,
          sub_id: ai + 1,
          predictor: pred.predictor,
          predict_date: pred.predict_date,
          prediction_text: pred.prediction_text,
          asset_name: a.asset_name || "\u672A\u8BC6\u522B",
          asset_code: null,
          // resolved later by fetcher
          asset_type: a.asset_type || "stock",
          direction: dir,
          time_horizon_days: a.time_horizon_days || 60,
          target_price: a.target_price ?? null,
          confidence_hint: a.confidence_hint || "\u4E00\u822C\u5EFA\u8BAE",
          has_asset: !!a.asset_name,
          has_direction: dir !== "\u4E2D\u6027",
          has_timeframe: a.time_horizon_days !== 60,
          // non-default means explicitly mentioned
          has_target: a.target_price != null
        });
      }
    }
    if (bi < batches.length - 1) {
      await new Promise((r) => setTimeout(r, 500));
    }
  }
  console.log(
    `[Parser] \u89E3\u6790\u5B8C\u6210\uFF0C\u5171\u4EA7\u751F ${results.length} \u6761\u5224\u65AD\uFF08\u542B\u62C6\u5206\uFF09`
  );
  return results;
}

// fetcher.ts
var stockListCache = null;
async function fetchJSON(url) {
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
      Referer: "https://finance.eastmoney.com/"
    }
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} for ${url}`);
  return res.json();
}
async function loadStockList() {
  if (stockListCache) return stockListCache;
  console.log("[Fetcher] \u52A0\u8F7D A \u80A1/ETF \u80A1\u7968\u5217\u8868...");
  const map = /* @__PURE__ */ new Map();
  for (const fs of [
    "m:0+t:6,7,8",
    // 深市 A 股
    "m:1+t:2,23",
    // 沪市 A 股
    "m:0+t:13",
    // 深市 ETF
    "m:1+t:12"
    // 沪市 ETF
  ]) {
    const url = `https://push2.eastmoney.com/api/qt/clist/get?pn=1&pz=10000&fs=${encodeURIComponent(fs)}&fields=f12,f13,f14`;
    try {
      const data = await fetchJSON(url);
      const items = data?.data?.diff;
      if (!items) continue;
      for (const item of Object.values(items)) {
        const code = String(item.f12);
        const market = Number(item.f13);
        const name = String(item.f14);
        map.set(name, { code, market });
        map.set(code, { code, market });
      }
    } catch (e) {
      console.warn(`[Fetcher] \u52A0\u8F7D\u5217\u8868\u5931\u8D25 (${fs}):`, e.message);
    }
  }
  console.log(`[Fetcher] \u5DF2\u52A0\u8F7D ${map.size} \u6761\u80A1\u7968/ETF \u6620\u5C04`);
  stockListCache = map;
  return map;
}
var COMMODITY_MAP = {
  \u9EC4\u91D1: "AU0",
  \u767D\u94F6: "AG0",
  \u539F\u6CB9: "SC0",
  \u94DC: "CU0",
  \u94DD: "AL0",
  \u87BA\u7EB9\u94A2: "RB0",
  \u94C1\u77FF\u77F3: "I0",
  \u7126\u7164: "JM0",
  \u7126\u70AD: "J0",
  \u8C46\u7C95: "M0",
  \u68D5\u6988\u6CB9: "P0",
  \u5929\u7136\u6C14: "NG0"
};
var INDEX_MAP = {
  \u4E0A\u8BC1\u6307\u6570: { secid: "1.000001" },
  \u4E0A\u8BC1\u7EFC\u6307: { secid: "1.000001" },
  \u6CAA\u6DF1300: { secid: "1.000300" },
  \u6DF1\u8BC1\u6210\u6307: { secid: "0.399001" },
  \u521B\u4E1A\u677F\u6307: { secid: "0.399006" },
  \u79D1\u521B50: { secid: "1.000688" },
  \u4E2D\u8BC1500: { secid: "1.000905" },
  \u4E2D\u8BC11000: { secid: "1.000852" },
  A\u80A1: { secid: "1.000001" }
  // default to 上证
};
var CSI300_SECID = "1.000300";
async function resolveAssetCode(judgment) {
  const name = judgment.asset_name;
  for (const [key, val] of Object.entries(INDEX_MAP)) {
    if (name.includes(key)) {
      return { secid: val.secid, source: "eastmoney" };
    }
  }
  for (const [key, val] of Object.entries(COMMODITY_MAP)) {
    if (name.includes(key)) {
      return { secid: val, source: "sina" };
    }
  }
  const stockList = await loadStockList();
  const direct = stockList.get(name);
  if (direct) {
    return { secid: `${direct.market}.${direct.code}`, source: "eastmoney" };
  }
  if (judgment.asset_code) {
    const byCode = stockList.get(judgment.asset_code);
    if (byCode) {
      return {
        secid: `${byCode.market}.${byCode.code}`,
        source: "eastmoney"
      };
    }
  }
  for (const [stockName, info] of stockList) {
    if (stockName.includes(name) || name.includes(stockName)) {
      return { secid: `${info.market}.${info.code}`, source: "eastmoney" };
    }
  }
  return { secid: null, source: null };
}
async function fetchEastmoneyBars(secid, startDate, endDate) {
  const beg = startDate.replace(/-/g, "");
  const end = endDate.replace(/-/g, "");
  const url = `https://push2his.eastmoney.com/api/qt/stock/kline/get?secid=${secid}&fields1=f1,f2,f3,f4,f5,f6&fields2=f51,f52,f53,f54,f55,f56&klt=101&fqt=1&beg=${beg}&end=${end}`;
  const data = await fetchJSON(url);
  const klines = data?.data?.klines || [];
  return klines.map((line) => {
    const [date, open, close, high, low, volume] = line.split(",");
    return {
      date,
      open: Number(open),
      close: Number(close),
      high: Number(high),
      low: Number(low),
      volume: Number(volume)
    };
  });
}
async function fetchSinaCommodityBars(symbol, startDate, endDate) {
  const url = `https://stock.finance.sina.com.cn/futures/api/jsonp.php/var/InnerFuturesNewService.getDailyKLine?symbol=${symbol}`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
      Referer: "https://finance.sina.com.cn/"
    }
  });
  const text = await res.text();
  const match = text.match(/\((\[[\s\S]*\])\)/);
  if (!match) return [];
  try {
    const arr = JSON.parse(match[1]);
    return arr.filter((item) => {
      const d = item.d;
      return d >= startDate && d <= endDate;
    }).map((item) => ({
      date: item.d,
      open: Number(item.o),
      close: Number(item.c),
      high: Number(item.h),
      low: Number(item.l),
      volume: Number(item.v)
    }));
  } catch {
    return [];
  }
}
function addDays(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
function today() {
  return (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
}
async function fetchMarketData(judgment) {
  const { secid, source } = await resolveAssetCode(judgment);
  if (!secid || !source) return null;
  judgment.asset_code = secid;
  const startDate = judgment.predict_date;
  const rawEndDate = addDays(startDate, judgment.time_horizon_days);
  const todayStr = today();
  const is_expired = rawEndDate <= todayStr;
  const endDate = is_expired ? rawEndDate : todayStr;
  const bufferStart = addDays(startDate, -5);
  let asset_bars;
  if (source === "eastmoney") {
    asset_bars = await fetchEastmoneyBars(secid, bufferStart, endDate);
  } else {
    asset_bars = await fetchSinaCommodityBars(secid, bufferStart, endDate);
  }
  const bench_bars = await fetchEastmoneyBars(
    CSI300_SECID,
    bufferStart,
    endDate
  );
  return { asset_bars, bench_bars, is_expired };
}

// scorer.ts
function findClosestBar(bars, targetDate, direction) {
  if (bars.length === 0) return null;
  if (direction === "forward") {
    for (const bar of bars) {
      if (bar.date >= targetDate) return bar;
    }
    return bars[bars.length - 1];
  } else {
    for (let i = bars.length - 1; i >= 0; i--) {
      if (bars[i].date <= targetDate) return bars[i];
    }
    return bars[0];
  }
}
function addDays2(dateStr, days) {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}
function scoreDirection(direction, change) {
  if (direction === "\u770B\u6DA8") {
    if (change > 5e-3) return { score: 50, correct: true };
    if (change < -5e-3) return { score: 0, correct: false };
    return { score: 25, correct: true };
  }
  if (direction === "\u770B\u8DCC") {
    if (change < -5e-3) return { score: 50, correct: true };
    if (change > 5e-3) return { score: 0, correct: false };
    return { score: 25, correct: true };
  }
  if (Math.abs(change) <= 0.05) return { score: 50, correct: true };
  return { score: 0, correct: false };
}
function scoreAlpha(direction, assetReturn, benchReturn) {
  let alpha;
  if (direction === "\u770B\u6DA8") {
    alpha = assetReturn - benchReturn;
  } else if (direction === "\u770B\u8DCC") {
    alpha = benchReturn - assetReturn;
  } else {
    alpha = 1 - Math.abs(assetReturn);
    alpha = Math.min(alpha, 0.05);
  }
  if (alpha >= 0.05) return 20;
  if (alpha > 0) return alpha / 0.05 * 20;
  return 0;
}
function scoreTiming(direction, basePrice, bars, predictDate, windowEndDate) {
  if (direction === "\u4E2D\u6027") return 15;
  const windowBars = bars.filter(
    (b) => b.date > predictDate && b.date <= windowEndDate
  );
  if (windowBars.length === 0) return 0;
  const totalDays = windowBars.length;
  let fulfillDay = -1;
  for (let i = 0; i < windowBars.length; i++) {
    const close = windowBars[i].close;
    if (direction === "\u770B\u6DA8" && close > basePrice) {
      fulfillDay = i + 1;
      break;
    }
    if (direction === "\u770B\u8DCC" && close < basePrice) {
      fulfillDay = i + 1;
      break;
    }
  }
  if (fulfillDay < 0) return 0;
  const ratio = fulfillDay / totalDays;
  if (ratio <= 0.25) return 15;
  if (ratio <= 0.5) return 10;
  if (ratio <= 0.75) return 6;
  return 3;
}
function scoreDrawdown(direction, basePrice, bars, predictDate) {
  const windowBars = bars.filter((b) => b.date > predictDate);
  if (windowBars.length === 0) return { score: 10, maxDrawdown: 0 };
  let maxDrawdown = 0;
  if (direction === "\u770B\u6DA8" || direction === "\u4E2D\u6027") {
    let peak = basePrice;
    for (const bar of windowBars) {
      if (bar.close > peak) peak = bar.close;
      const dd = (peak - bar.close) / peak;
      if (dd > maxDrawdown) maxDrawdown = dd;
    }
  } else {
    let trough = basePrice;
    for (const bar of windowBars) {
      if (bar.close < trough) trough = bar.close;
      const rally = (bar.close - trough) / trough;
      if (rally > maxDrawdown) maxDrawdown = rally;
    }
  }
  let score;
  if (maxDrawdown < 0.03) score = 10;
  else if (maxDrawdown < 0.08) score = 7;
  else if (maxDrawdown < 0.15) score = 4;
  else score = 1;
  return { score, maxDrawdown };
}
function scoreActionability(judgment) {
  let score = 0;
  if (judgment.has_asset) score += 2;
  if (judgment.has_direction) score += 1.5;
  if (judgment.has_timeframe) score += 0.75;
  if (judgment.has_target) score += 0.75;
  return score;
}
function scoreJudgment(judgment, assetBars, benchBars, isExpired) {
  const windowEndDate = addDays2(
    judgment.predict_date,
    judgment.time_horizon_days
  );
  const todayStr = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
  const effectiveEndDate = isExpired ? windowEndDate : todayStr;
  const baseBar = findClosestBar(
    assetBars,
    judgment.predict_date,
    "forward"
  );
  const benchBaseBar = findClosestBar(
    benchBars,
    judgment.predict_date,
    "forward"
  );
  if (!baseBar || !benchBaseBar) {
    return {
      ...judgment,
      scores: {
        direction: 0,
        alpha: 0,
        timing: 0,
        drawdown: 0,
        actionability: 0,
        total: 0,
        direction_correct: false
      },
      base_price: null,
      end_price: null,
      asset_return: null,
      bench_return: null,
      max_drawdown: null,
      is_expired: isExpired,
      error: "\u65E0\u6CD5\u83B7\u53D6\u57FA\u51C6\u65E5\u884C\u60C5\u6570\u636E"
    };
  }
  const endBar = findClosestBar(assetBars, effectiveEndDate, "backward");
  const benchEndBar = findClosestBar(benchBars, effectiveEndDate, "backward");
  if (!endBar || !benchEndBar) {
    return {
      ...judgment,
      scores: {
        direction: 0,
        alpha: 0,
        timing: 0,
        drawdown: 0,
        actionability: 0,
        total: 0,
        direction_correct: false
      },
      base_price: baseBar.close,
      end_price: null,
      asset_return: null,
      bench_return: null,
      max_drawdown: null,
      is_expired: isExpired,
      error: "\u65E0\u6CD5\u83B7\u53D6\u7ED3\u7B97\u65E5\u884C\u60C5\u6570\u636E"
    };
  }
  const basePrice = baseBar.close;
  const endPrice = endBar.close;
  const assetReturn = (endPrice - basePrice) / basePrice;
  const benchReturn = (benchEndBar.close - benchBaseBar.close) / benchBaseBar.close;
  const { score: dirScore, correct: dirCorrect } = scoreDirection(
    judgment.direction,
    assetReturn
  );
  if (!dirCorrect) {
    return {
      ...judgment,
      scores: {
        direction: 0,
        alpha: 0,
        timing: 0,
        drawdown: 0,
        actionability: 0,
        total: 0,
        direction_correct: false
      },
      base_price: basePrice,
      end_price: endPrice,
      asset_return: assetReturn,
      bench_return: benchReturn,
      max_drawdown: null,
      is_expired: isExpired,
      error: null
    };
  }
  const alphaScore = scoreAlpha(judgment.direction, assetReturn, benchReturn);
  const timingScore = scoreTiming(
    judgment.direction,
    basePrice,
    assetBars,
    judgment.predict_date,
    effectiveEndDate
  );
  const { score: ddScore, maxDrawdown } = scoreDrawdown(
    judgment.direction,
    basePrice,
    assetBars,
    judgment.predict_date
  );
  const actScore = scoreActionability(judgment);
  const total = dirScore + alphaScore + timingScore + ddScore + actScore;
  return {
    ...judgment,
    scores: {
      direction: dirScore,
      alpha: Math.round(alphaScore * 10) / 10,
      timing: timingScore,
      drawdown: ddScore,
      actionability: actScore,
      total: Math.round(total * 10) / 10,
      direction_correct: true
    },
    base_price: basePrice,
    end_price: endPrice,
    asset_return: assetReturn,
    bench_return: benchReturn,
    max_drawdown: maxDrawdown,
    is_expired: isExpired,
    error: null
  };
}

// reporter.ts
import { writeFileSync } from "fs";
function pct(n) {
  if (n == null) return "N/A";
  return (n * 100).toFixed(2) + "%";
}
function fmt(n, decimals = 1) {
  if (n == null) return "N/A";
  return n.toFixed(decimals);
}
function judgmentLabel(j) {
  return `#${j.original_id}${j.sub_id > 1 ? `-${j.sub_id}` : ""}`;
}
function generateReport(scored, outputPath) {
  const now = (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
  const scorable = scored.filter((s) => !s.error);
  const errored = scored.filter((s) => !!s.error);
  const expired = scorable.filter((s) => s.is_expired);
  const interim = scorable.filter((s) => !s.is_expired);
  const dirCorrect = scorable.filter((s) => s.scores.direction_correct).length;
  const dirTotal = scorable.length;
  const hitRate = dirTotal > 0 ? (dirCorrect / dirTotal * 100).toFixed(1) : "0";
  const avgScore = dirTotal > 0 ? (scorable.reduce((sum, s) => sum + s.scores.total, 0) / dirTotal).toFixed(1) : "0";
  const predictorMap = /* @__PURE__ */ new Map();
  for (const s of scorable) {
    const p = predictorMap.get(s.predictor) || {
      total: 0,
      correct: 0,
      scoreSum: 0
    };
    p.total++;
    if (s.scores.direction_correct) p.correct++;
    p.scoreSum += s.scores.total;
    predictorMap.set(s.predictor, p);
  }
  const predictorRank = [...predictorMap.entries()].map(([name, stats]) => ({
    name,
    ...stats,
    hitRate: stats.total > 0 ? stats.correct / stats.total : 0,
    avgScore: stats.total > 0 ? stats.scoreSum / stats.total : 0
  })).sort((a, b) => b.avgScore - a.avgScore);
  const typeLabels = {
    stock: "A \u80A1\u4E2A\u80A1",
    etf: "ETF",
    commodity: "\u9EC4\u91D1/\u5546\u54C1",
    index: "\u6307\u6570"
  };
  const typeMap = /* @__PURE__ */ new Map();
  for (const s of scorable) {
    const t = typeMap.get(s.asset_type) || {
      total: 0,
      correct: 0,
      scoreSum: 0
    };
    t.total++;
    if (s.scores.direction_correct) t.correct++;
    t.scoreSum += s.scores.total;
    typeMap.set(s.asset_type, t);
  }
  const sorted = [...scorable].sort(
    (a, b) => b.scores.total - a.scores.total
  );
  const top5 = sorted.slice(0, 5);
  const bottom5 = sorted.slice(-5).reverse();
  const lines = [];
  const L = (s) => lines.push(s);
  L("# \u91D1\u878D\u9884\u6D4B\u9A8C\u8BC1\u62A5\u544A");
  L(`\u751F\u6210\u65F6\u95F4: ${now} | \u5224\u65AD\u603B\u6570: ${scorable.length} \u6761\uFF08\u542B\u62C6\u5206\uFF09`);
  L("");
  L("## \u603B\u89C8");
  L(`- \u65B9\u5411\u547D\u4E2D\u7387: ${dirCorrect}/${dirTotal} (${hitRate}%)`);
  L(`- \u5E73\u5747\u603B\u5206: ${avgScore} / 100`);
  if (predictorRank.length > 0) {
    L(
      `- \u6700\u4F73\u9884\u6D4B\u4EBA: ${predictorRank[0].name}\uFF08\u5747\u5206 ${predictorRank[0].avgScore.toFixed(1)}\uFF09`
    );
  }
  if (interim.length > 0) {
    L(`- \u672A\u5230\u671F\u6682\u4F30: ${interim.length} \u6761`);
  }
  if (errored.length > 0) {
    L(`- \u65E0\u6CD5\u8BC4\u5206: ${errored.length} \u6761\uFF08\u6807\u7684\u65E0\u6CD5\u8BC6\u522B\u7B49\uFF09`);
  }
  L("");
  if (predictorRank.length > 0) {
    L("## \u9884\u6D4B\u4EBA\u6392\u540D");
    L("| \u6392\u540D | \u9884\u6D4B\u4EBA | \u9884\u6D4B\u6570 | \u547D\u4E2D\u7387 | \u5E73\u5747\u5206 |");
    L("|------|--------|--------|--------|--------|");
    predictorRank.forEach((p, i) => {
      L(
        `| ${i + 1} | ${p.name} | ${p.total} | ${(p.hitRate * 100).toFixed(0)}% | ${p.avgScore.toFixed(1)} |`
      );
    });
    L("");
  }
  if (top5.length > 0) {
    L("## Top 5 \u6700\u51C6\u9884\u6D4B");
    L(
      "| \u7F16\u53F7 | \u9884\u6D4B\u4EBA | \u6807\u7684 | \u65B9\u5411 | \u6DA8\u8DCC\u5E45 | \u65B9\u5411 | \u8D85\u989D | \u65F6\u6548 | \u56DE\u64A4 | \u64CD\u4F5C | \u603B\u5206 | \u72B6\u6001 |"
    );
    L(
      "|------|--------|------|------|--------|------|------|------|------|------|------|------|"
    );
    for (const s of top5) {
      const status = s.is_expired ? "\u5DF2\u5230\u671F" : "\u6682\u4F30";
      L(
        `| ${judgmentLabel(s)} | ${s.predictor} | ${s.asset_name} | ${s.direction} | ${pct(s.asset_return)} | ${s.scores.direction} | ${fmt(s.scores.alpha)} | ${s.scores.timing} | ${s.scores.drawdown} | ${s.scores.actionability} | **${fmt(s.scores.total)}** | ${status} |`
      );
    }
    L("");
  }
  if (bottom5.length > 0) {
    L("## Top 5 \u6700\u79BB\u8C31\u9884\u6D4B");
    L(
      "| \u7F16\u53F7 | \u9884\u6D4B\u4EBA | \u6807\u7684 | \u65B9\u5411 | \u6DA8\u8DCC\u5E45 | \u65B9\u5411 | \u8D85\u989D | \u65F6\u6548 | \u56DE\u64A4 | \u64CD\u4F5C | \u603B\u5206 | \u72B6\u6001 |"
    );
    L(
      "|------|--------|------|------|--------|------|------|------|------|------|------|------|"
    );
    for (const s of bottom5) {
      const status = s.is_expired ? "\u5DF2\u5230\u671F" : "\u6682\u4F30";
      L(
        `| ${judgmentLabel(s)} | ${s.predictor} | ${s.asset_name} | ${s.direction} | ${pct(s.asset_return)} | ${s.scores.direction} | ${fmt(s.scores.alpha)} | ${s.scores.timing} | ${s.scores.drawdown} | ${s.scores.actionability} | **${fmt(s.scores.total)}** | ${status} |`
      );
    }
    L("");
  }
  if (typeMap.size > 0) {
    L("## \u6309\u8D44\u4EA7\u7C7B\u522B\u7EDF\u8BA1");
    for (const [type, stats] of typeMap) {
      const label = typeLabels[type] || type;
      const rate = stats.total > 0 ? (stats.correct / stats.total * 100).toFixed(0) : "0";
      const avg = stats.total > 0 ? (stats.scoreSum / stats.total).toFixed(1) : "0";
      L(`- ${label}: \u547D\u4E2D\u7387 ${rate}%, \u5747\u5206 ${avg}`);
    }
    L("");
  }
  if (interim.length > 0) {
    L("## \u672A\u5230\u671F-\u6682\u4F30\u9884\u6D4B");
    L("> \u4EE5\u4E0B\u9884\u6D4B\u7684\u65F6\u95F4\u7A97\u53E3\u5C1A\u672A\u7ED3\u675F\uFF0C\u4F7F\u7528\u5F53\u524D\u6700\u65B0\u4EF7\u683C\u4E34\u65F6\u7ED3\u7B97\u3002\u53EF\u91CD\u8DD1\u811A\u672C\u66F4\u65B0\u3002");
    L("");
    for (const s of interim) {
      L(
        `- ${judgmentLabel(s)} ${s.predictor}: ${s.asset_name}(${s.direction}) \u2192 \u6682\u4F30 ${fmt(s.scores.total)} \u5206`
      );
    }
    L("");
  }
  if (errored.length > 0) {
    L("## \u65E0\u6CD5\u8BC4\u5206\u7684\u9884\u6D4B");
    for (const s of errored) {
      L(
        `- ${judgmentLabel(s)} ${s.predictor}: ${s.asset_name} \u2014 ${s.error}`
      );
    }
    L("");
  }
  const report = lines.join("\n");
  writeFileSync(outputPath, report, "utf-8");
  console.log(`[Reporter] \u62A5\u544A\u5DF2\u5199\u5165: ${outputPath}`);
}
function generateCSV(scored, outputPath) {
  const headers = [
    "\u7F16\u53F7",
    "\u9884\u6D4B\u4EBA",
    "\u9884\u6D4B\u65E5\u671F",
    "\u6807\u7684",
    "\u6807\u7684\u7C7B\u578B",
    "\u6807\u7684\u4EE3\u7801",
    "\u65B9\u5411",
    "\u7A97\u53E3(\u5929)",
    "\u76EE\u6807\u4EF7",
    "\u57FA\u51C6\u4EF7",
    "\u7ED3\u7B97\u4EF7",
    "\u6DA8\u8DCC\u5E45",
    "\u6CAA\u6DF1300\u540C\u671F",
    "\u6700\u5927\u56DE\u64A4",
    "\u65B9\u5411\u5206",
    "\u8D85\u989D\u5206",
    "\u65F6\u6548\u5206",
    "\u56DE\u64A4\u5206",
    "\u64CD\u4F5C\u5206",
    "\u603B\u5206",
    "\u65B9\u5411\u6B63\u786E",
    "\u72B6\u6001",
    "\u9519\u8BEF",
    "\u539F\u6587"
  ];
  const rows = scored.map((s) => {
    const status = s.error ? "\u9519\u8BEF" : s.is_expired ? "\u5DF2\u5230\u671F" : "\u672A\u5230\u671F-\u6682\u4F30";
    return [
      judgmentLabel(s),
      s.predictor,
      s.predict_date,
      s.asset_name,
      s.asset_type,
      s.asset_code || "",
      s.direction,
      s.time_horizon_days,
      s.target_price ?? "",
      s.base_price ?? "",
      s.end_price ?? "",
      s.asset_return != null ? pct(s.asset_return) : "",
      s.bench_return != null ? pct(s.bench_return) : "",
      s.max_drawdown != null ? pct(s.max_drawdown) : "",
      s.scores.direction,
      s.scores.alpha,
      s.scores.timing,
      s.scores.drawdown,
      s.scores.actionability,
      s.scores.total,
      s.scores.direction_correct ? "\u662F" : "\u5426",
      status,
      s.error || "",
      `"${s.prediction_text.replace(/"/g, '""')}"`
    ].join(",");
  });
  const csv = [headers.join(","), ...rows].join("\n");
  writeFileSync(outputPath, "\uFEFF" + csv, "utf-8");
  console.log(`[Reporter] \u8BC4\u5206\u660E\u7EC6\u5DF2\u5199\u5165: ${outputPath}`);
}

// verify.ts
async function main() {
  const csvPath = process.argv[2];
  if (!csvPath) {
    const invokedPath = process.argv[1] ? relative(process.cwd(), process.argv[1]) : "verify.mjs";
    const scriptName = invokedPath && !invokedPath.startsWith("..") ? invokedPath : basename(process.argv[1] || "verify.mjs");
    const examplePath = scriptName.includes("/") ? "examples/sample_predictions.csv" : "../examples/sample_predictions.csv";
    console.error(
      `\u7528\u6CD5: KIMI_API_KEY=sk-xxx node ${scriptName} <CSV\u6587\u4EF6\u8DEF\u5F84>`
    );
    console.error(
      `\u793A\u4F8B: KIMI_API_KEY=sk-xxx node ${scriptName} ${examplePath}`
    );
    console.error("\u6216\u5728 scripts/.env.local \u4E2D\u8BBE\u7F6E KIMI_API_KEY=sk-xxx");
    console.error(
      `\u53EF\u9009\u8986\u76D6: LLM_MODEL=${DEFAULT_LLM_MODEL} LLM_BASE_URL=${DEFAULT_LLM_BASE_URL}`
    );
    process.exit(1);
  }
  let llmConfig;
  try {
    llmConfig = loadLLMConfig();
  } catch (error) {
    console.error(`\u9519\u8BEF: ${error.message}`);
    console.error("\u8BF7\u8BBE\u7F6E: export KIMI_API_KEY=sk-xxx");
    console.error("\u6216\u5728 scripts/.env.local \u4E2D\u8BBE\u7F6E KIMI_API_KEY=sk-xxx");
    console.error("\u4E5F\u652F\u6301: export LLM_API_KEY=sk-xxx \u6216 export MOONSHOT_API_KEY=sk-xxx");
    process.exit(1);
  }
  console.log(`
[Step 1/5] \u8BFB\u53D6 CSV: ${csvPath}`);
  const csvContent = readFileSync2(csvPath, "utf-8");
  const records = parse(csvContent, {
    columns: true,
    skip_empty_lines: true,
    trim: true,
    bom: true
  });
  const required = ["predictor", "predict_date", "prediction_text"];
  for (const col of required) {
    if (!records[0] || !(col in records[0])) {
      console.error(`\u9519\u8BEF: CSV \u7F3A\u5C11\u5FC5\u586B\u5217 "${col}"`);
      console.error(`CSV \u9700\u8981 3 \u5217: ${required.join(", ")}`);
      process.exit(1);
    }
  }
  const predictions = records.map((r, i) => ({
    id: i + 1,
    predictor: r.predictor,
    predict_date: r.predict_date,
    prediction_text: r.prediction_text
  }));
  console.log(`  \u5171 ${predictions.length} \u6761\u9884\u6D4B`);
  console.log(
    `
[Step 2/5] \u8C03\u7528 ${llmConfig.providerLabel} API \u89E3\u6790\u9884\u6D4B\u6587\u672C...`
  );
  console.log(
    `  \u6A21\u578B\u914D\u7F6E: ${llmConfig.model} @ ${llmConfig.baseURL} (${llmConfig.apiKeyEnvName})`
  );
  const judgments = await parsePredictions(llmConfig, predictions);
  console.log(
    `  \u89E3\u6790\u5B8C\u6210: ${predictions.length} \u6761\u539F\u59CB\u9884\u6D4B \u2192 ${judgments.length} \u6761\u5224\u65AD`
  );
  console.log(`
[Step 3/5] \u62C9\u53D6\u884C\u60C5\u6570\u636E\u5E76\u8BC4\u5206...`);
  const scored = [];
  for (let i = 0; i < judgments.length; i++) {
    const j = judgments[i];
    const label = `#${j.original_id}${j.sub_id > 1 ? `-${j.sub_id}` : ""}`;
    process.stdout.write(
      `  [${i + 1}/${judgments.length}] ${label} ${j.asset_name}(${j.direction})... `
    );
    const market = await fetchMarketData(j);
    if (!market) {
      console.log("\u274C \u6807\u7684\u65E0\u6CD5\u8BC6\u522B");
      scored.push({
        ...j,
        scores: {
          direction: 0,
          alpha: 0,
          timing: 0,
          drawdown: 0,
          actionability: 0,
          total: 0,
          direction_correct: false
        },
        base_price: null,
        end_price: null,
        asset_return: null,
        bench_return: null,
        max_drawdown: null,
        is_expired: false,
        error: "\u6807\u7684\u65E0\u6CD5\u8BC6\u522B: " + j.asset_name
      });
      continue;
    }
    const result = scoreJudgment(
      j,
      market.asset_bars,
      market.bench_bars,
      market.is_expired
    );
    scored.push(result);
    const status = result.error ? `\u274C ${result.error}` : result.is_expired ? `\u2705 ${result.scores.total}\u5206` : `\u23F3 ${result.scores.total}\u5206(\u6682\u4F30)`;
    console.log(status);
    await new Promise((r) => setTimeout(r, 300));
  }
  console.log(`
[Step 4/5] \u751F\u6210\u62A5\u544A...`);
  const baseName = csvPath.replace(/\.(csv|xlsx?)$/i, "");
  const reportPath = baseName + "_report.md";
  generateReport(scored, reportPath);
  console.log(`
[Step 5/5] \u751F\u6210\u8BC4\u5206\u660E\u7EC6 CSV...`);
  const csvOutPath = baseName + "_scores.csv";
  generateCSV(scored, csvOutPath);
  const scorable = scored.filter((s) => !s.error);
  const correct = scorable.filter((s) => s.scores.direction_correct).length;
  const avg = scorable.length > 0 ? (scorable.reduce((sum, s) => sum + s.scores.total, 0) / scorable.length).toFixed(1) : "0";
  const interimCount = scorable.filter((s) => !s.is_expired).length;
  console.log(`
${"=".repeat(50)}`);
  console.log(`\u9A8C\u8BC1\u5B8C\u6210!`);
  console.log(`  \u5224\u65AD\u603B\u6570: ${scored.length} (\u539F\u59CB ${predictions.length} \u6761)`);
  console.log(
    `  \u65B9\u5411\u547D\u4E2D: ${correct}/${scorable.length} (${scorable.length > 0 ? (correct / scorable.length * 100).toFixed(1) : 0}%)`
  );
  console.log(`  \u5E73\u5747\u5F97\u5206: ${avg} / 100`);
  if (interimCount > 0) {
    console.log(`  \u672A\u5230\u671F\u6682\u4F30: ${interimCount} \u6761`);
  }
  if (scored.length - scorable.length > 0) {
    console.log(`  \u65E0\u6CD5\u8BC4\u5206: ${scored.length - scorable.length} \u6761`);
  }
  console.log(`  \u62A5\u544A: ${reportPath}`);
  console.log(`  \u660E\u7EC6: ${csvOutPath}`);
  console.log(`${"=".repeat(50)}
`);
}
main().catch((e) => {
  console.error("\u6267\u884C\u51FA\u9519:", e);
  process.exit(1);
});
