---
name: financial-prediction-verifier
description: >-
  Verify financial predictions (stocks, ETFs, commodities) against real market
  data. Reads a CSV with predictor, date, and prediction text, auto-parses
  assets/direction/time horizon via Kimi API, fetches free market data from
  Eastmoney/Sina, scores on 5 weighted dimensions, and generates a Markdown
  report plus detail CSV.
---

# Financial Prediction Verifier

## Overview

Score financial predictions against real market data. Input: a simple 3-column CSV. Output: a scored Markdown report plus detail CSV.

For usage notes, see [README.md](README.md). For scoring formulas, see [reference.md](reference.md).

## Prerequisites

- Node.js >= 18
- Kimi API Key via `KIMI_API_KEY`
- Optional local private file: `scripts/.env.local`
- Optional unified overrides: `LLM_API_KEY`, `LLM_MODEL`, `LLM_BASE_URL`
- No `npm install` required

## Quick Start

```bash
cd ~/.cursor/skills/financial-prediction-verifier
KIMI_API_KEY=sk-xxx node scripts/verify.mjs /path/to/predictions.csv
```

也支持把 key 放在本地私有文件 `scripts/.env.local`，这样运行时无需每次手动 export。

```bash
cp scripts/.env.local.example scripts/.env.local
node scripts/verify.mjs /path/to/predictions.csv
```

## Input CSV Format

Only 3 columns required:

```csv
predictor,predict_date,prediction_text
小明,2025-12-15,黄金还能再涨一段时间
小红,2026-01-10,后面可以关注下隆基绿能
```

- `predictor`: Who made the prediction
- `predict_date`: When the prediction was made (YYYY-MM-DD)
- `prediction_text`: The raw prediction text

## Output

Two files written next to the input CSV:

- `{input}_report.md`
- `{input}_scores.csv`
