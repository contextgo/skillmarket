#!/usr/bin/env python3
"""
LSBX专业知识库构建框架 ES 公共版 v1.0.2 — 地址管理器
功能：读取并验证默认路径，返回路径状态和文件列表
"""

import sys
import io
import json
from pathlib import Path
from datetime import datetime

# 强制 UTF-8 输出（解决 Windows 控制台 GBK 编码问题）
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
sys.stdin = io.TextIOWrapper(sys.stdin.buffer, encoding="utf-8", errors="replace")

VERSION = "ES 公共版 v1.0.2"

DEFAULT_PATH = Path(r"G:\移动固态硬盘pssd\1675可持续进化的知识库体系（自用）")
CONFIG_FILE = Path(__file__).parent.parent / "共享" / "配置.json"
CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)


def show_help():
    print(f"""LSBX地址管理器 {VERSION}

用法：
  python 地址管理器.py                    # 验证默认路径
  python 地址管理器.py <路径>             # 验证指定路径
  python 地址管理器.py --init             # 初始化默认路径
  python 地址管理器.py --set <路径>       # 设置默认路径
  python 地址管理器.py -h / --help        # 显示帮助

描述：
  验证知识库体系路径是否可读，返回状态和文件列表。
  若默认路径不存在，提示用户手动指定。
""")


def validate_path(path: Path) -> dict:
    """验证路径，返回状态和基本信息"""
    result = {
        "path": str(path),
        "exists": False,
        "readable": False,
        "writable": False,
        "is_knowledge_base_root": False,
        "folders": [],
        "files": [],
        "error": None
    }

    if not path.exists():
        result["error"] = "路径不存在"
        return result

    result["exists"] = True

    try:
        # 检查可读性
        list(path.iterdir())
        result["readable"] = True
    except PermissionError:
        result["error"] = "权限不足，无法读取"
        return result

    # 检查可写性
    test_file = path / ".write_test"
    try:
        test_file.touch()
        test_file.unlink()
        result["writable"] = True
    except (PermissionError, OSError):
        result["error"] = "权限不足，无法写入"

    # 检查是否为知识库根目录
    knowledge_base = path / "知识库"
    memory_base = path / "记忆库"
    log_base = path / "日志"
    shared_base = path / "共享"

    result["is_knowledge_base_root"] = (
        knowledge_base.exists() or
        memory_base.exists() or
        log_base.exists()
    )

    # 列出子目录
    for item in sorted(path.iterdir()):
        if item.name.startswith("."):
            continue
        if item.is_dir():
            result["folders"].append({
                "name": item.name,
                "type": "folder",
                "path": str(item)
            })
        else:
            result["files"].append({
                "name": item.name,
                "type": item.suffix,
                "path": str(item)
            })

    return result


def print_result(result: dict):
    """格式化输出验证结果"""
    path = result["path"]

    if not result["exists"]:
        print(f"\n❌ 路径不存在：{path}")
        print("请手动指定正确的路径。")
        return

    print(f"\n✅ 路径验证通过：{path}")

    if result["error"]:
        print(f"⚠️  警告：{result['error']}")

    print(f"   可读：{'✅' if result['readable'] else '❌'}")
    print(f"   可写：{'✅' if result['writable'] else '❌'}")

    if result["is_knowledge_base_root"]:
        print("   类型：✅ 知识库体系根目录")
    else:
        print("   类型：⚠️  普通目录（未检测到知识库结构）")

    if result["folders"]:
        print(f"\n📁 子目录（{len(result['folders'])} 个）：")
        for f in result["folders"]:
            marker = "📚" if f["name"] == "知识库" else "🧠" if f["name"] == "记忆库" else "📋" if f["name"] == "日志" else "📦" if f["name"] == "共享" else "📂"
            print(f"   {marker} {f['name']}")

    if result["files"]:
        print(f"\n📄 文件（{len(result['files'])} 个）：")
        for f in result["files"][:10]:
            print(f"   📄 {f['name']}")
        if len(result["files"]) > 10:
            print(f"   ... 还有 {len(result['files']) - 10} 个文件")


def save_config(path: Path):
    """保存配置"""
    config = {
        "default_path": str(path),
        "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "version": VERSION
    }
    try:
        CONFIG_FILE.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"✅ 默认路径已保存：{path}")
    except Exception as e:
        print(f"❌ 保存配置失败：{e}")


def load_config() -> Path:
    """加载配置中的默认路径"""
    if CONFIG_FILE.exists():
        try:
            config = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
            saved = config.get("default_path", "")
            if saved:
                return Path(saved)
        except Exception:
            pass
    return DEFAULT_PATH


def init_default_path():
    """初始化默认路径目录结构"""
    root = DEFAULT_PATH

    folders_to_create = [
        root / "知识库" / "0-元数据",
        root / "知识库" / "1-技术体系",
        root / "知识库" / "2-学习体系",
        root / "知识库" / "3-职业发展",
        root / "知识库" / "4-个人成长",
        root / "知识库" / "5-知识资产",
        root / "知识库" / "Z-归档",
        root / "记忆库" / "0-元数据",
        root / "记忆库" / "共享",
        root / "日志" / "0-元数据",
        root / "日志" / "汇总",
        root / "共享",
    ]

    created = []
    errors = []

    for folder in folders_to_create:
        try:
            folder.mkdir(parents=True, exist_ok=True)
            created.append(str(folder.relative_to(root)))
        except Exception as e:
            errors.append(f"{folder}: {e}")

    if created:
        print(f"\n✅ 目录初始化完成（{len(created)} 个）：")
        for c in created:
            print(f"   📁 {c}")

    if errors:
        print(f"\n⚠️  失败（{len(errors)} 个）：")
        for e in errors:
            print(f"   ❌ {e}")

    save_config(root)
    return root


def main():
    args = sys.argv[1:]

    if not args or "-h" in args or "--help" in args:
        show_help()
        return

    if "--init" in args:
        result = init_default_path()
        print_result(validate_path(result))
        return

    if "--set" in args:
        idx = args.index("--set")
        if idx + 1 < len(args):
            new_path = Path(args[idx + 1])
            save_config(new_path)
            print_result(validate_path(new_path))
            return

    # 验证路径
    if args:
        target_path = Path(args[0])
    else:
        target_path = load_config()

    result = validate_path(target_path)
    print_result(result)


if __name__ == "__main__":
    main()
