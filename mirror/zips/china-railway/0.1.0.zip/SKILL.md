---
name: china-railway
description: "Information assistant for 中国中铁 China Railway. Search products, news, financials, and official resources for 中国中铁 China Railway."
metadata:
  { "openclaw": { "emoji": "🏢", "version": "0.1.0", "author": "hanxueyuan", "tags": ["brand","china-railway","enterprise-info"] } }
---

# 中国中铁 China Railway — Information Assistant

Query products, news, stock prices, financial reports, and official resources for **中国中铁 China Railway**.

## About

- **Company**: 中国中铁 China Railway
- **Industry**: Railway construction
- **Official Website**: https://www.crec.cn

## What This Skill Does

When activated, this skill helps you:

1. **Product Search** — Find and compare 中国中铁 China Railway products, pricing, and availability
2. **News & Updates** — Get the latest news, press releases, and announcements
3. **Financial Info** — Stock price, market cap, earnings reports (for public companies)
4. **Official Resources** — Direct links to official websites, support pages, and documentation
5. **Competitor Comparison** — Compare with competitors in the same industry

## Usage Examples

- "What are the latest 中国中铁 China Railway products?"
- "Show me 中国中铁 China Railway stock price"
- "Compare 中国中铁 China Railway with competitors"
- "Find 中国中铁 China Railway official support page"
- "What's new at 中国中铁 China Railway?"

## How It Works

This skill uses web search to fetch real-time information about 中国中铁 China Railway from:
- Official website: https://www.crec.cn
- Financial data providers
- News aggregators
- Product databases

## Instructions for Agent

When this skill is triggered:
1. Identify the user's specific query about 中国中铁 China Railway
2. Use web search tools to find current information
3. Prioritize official sources (https://www.crec.cn)
4. Present results in a structured, easy-to-read format
5. Include direct links to sources

## Author

Created by hanxueyuan | Part of the Agent Commerce ecosystem
License: MIT
