import base64
import mimetypes
import os
import sys
from pathlib import Path

from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()

DEFAULT_VIDEO = getEnv("GEMMA4_DEFAULT_VIDEO") or ""


def getEnv(name: str, default: str | None = None) -> str | None:
    return os.environ.get(name, default)


def readVideoAsDataUri(path: Path) -> str:
    mime, _ = mimetypes.guess_type(str(path))
    mime = mime or "video/mp4"
    data = path.read_bytes()
    b64 = base64.b64encode(data).decode("utf-8")
    return f"data:{mime};base64,{b64}"


def createClient(baseUrl: str, apiKey: str) -> OpenAI:
    return OpenAI(base_url=baseUrl, api_key=apiKey, timeout=300.0)


def analyzeVideo(client: OpenAI, model: str, videoUri: str, prompt: str) -> str:
    response = client.chat.completions.create(
        model=model,
        messages=[
            {
                "role": "user",
                "content": [
                    {"type": "video_url", "video_url": {"url": videoUri}},
                    {"type": "text", "text": prompt},
                ],
            }
        ],
        max_tokens=2048,
        temperature=1.0,
        top_p=0.95,
        extra_body={"top_k": 64},
    )
    return str(response.choices[0].message.content or "")


def main() -> None:
    baseUrl = getEnv("GEMMA4_BASE_URL")
    apiKey = getEnv("GEMMA4_API_KEY")
    model = getEnv("GEMMA4_MODEL")

    missing = []
    if not baseUrl:
        missing.append("GEMMA4_BASE_URL")
    if not apiKey:
        missing.append("GEMMA4_API_KEY")
    if not model:
        missing.append("GEMMA4_MODEL")

    if missing:
        print("缺少以下环境变量，请先设置：")
        for var in missing:
            print(f"  - {var}")
        print("\n示例：")
        print('  export GEMMA4_BASE_URL="http://192.168.101.131:18081/v1"')
        print('  export GEMMA4_API_KEY="dummy"')
        print('  export GEMMA4_MODEL="gemma4-31b"')
        sys.exit(1)

    videoPathStr = sys.argv[1] if len(sys.argv) > 1 else DEFAULT_VIDEO
    if not videoPathStr:
        print("用法: python scripts/analyze_video.py <视频路径>")
        print("或在 .env 中设置 GEMMA4_DEFAULT_VIDEO 作为默认视频路径")
        sys.exit(1)

    videoPath = Path(videoPathStr)

    if not videoPath.exists():
        print(f"文件不存在: {videoPath.absolute()}")
        sys.exit(1)

    fileSizeKb = videoPath.stat().st_size // 1024
    print(f"读取视频: {videoPath.name} ({fileSizeKb} KB)")

    videoUri = readVideoAsDataUri(videoPath)
    print(f"Base64 编码完成，约 {len(videoUri) // 1024} KB，开始调用模型...")

    client = createClient(str(baseUrl), str(apiKey))

    try:
        result = analyzeVideo(client, str(model), videoUri, "请用中文详细描述这个视频里发生了什么。")
        print("\n=== 模型输出 ===")
        print(result)
    except Exception as e:
        print(f"\n请求失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
