# gemma4-video-analysis

使用gemma4模型分析视频文件