/**
 * 商品详情页Word文档生成模板
 * 
 * 使用方法：
 * 1. 根据实际产品信息修改content对象
 * 2. 运行：node create_docx_template.js
 * 3. 生成的文档将保存在指定路径
 */

const { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, LevelFormat } = require('docx');
const fs = require('fs');

// ============================================
// 配置区域：根据实际产品修改以下内容
// ============================================

const config = {
  // 文档标题
  title: '🎈 企鹅悠悠球 · 详情页文案',
  subtitle: '鹅童节限定款 | QQ企鹅官方正版授权',
  
  // 输出路径
  outputPath: '/Users/emo/Documents/儿童节/企鹅悠悠球-详情页文案.docx',
  
  // 详情页内容模块
  sections: [
    {
      title: '🎈 品牌开场',
      content: [
        { text: '还记得你的第一个悠悠球吗？', bold: true, size: 28 },
        { text: '' },
        { text: '一根细绳，两个圆盘' },
        { text: '就能玩上一整天的快乐呀～' },
        // ... 更多内容
      ]
    },
    {
      title: '🐧 产品故事',
      content: [
        { text: '为什么是企鹅悠悠球呀？', bold: true, size: 28 },
        // ... 更多内容
      ]
    },
    // ... 更多模块
  ]
};

// ============================================
// 文档生成逻辑（一般不需要修改）
// ============================================

function createParagraph(item) {
  if (typeof item === 'string') {
    return new Paragraph({
      children: [new TextRun({ text: item, font: 'Microsoft YaHei', size: 24 })]
    });
  }
  
  return new Paragraph({
    children: [new TextRun({ 
      text: item.text, 
      font: 'Microsoft YaHei', 
      size: item.size || 24,
      bold: item.bold || false
    })]
  });
}

function generateDocument() {
  const children = [
    // 标题
    new Paragraph({
      heading: HeadingLevel.HEADING_1,
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ 
        text: config.title, 
        bold: true, 
        size: 40, 
        font: 'Microsoft YaHei' 
      })]
    }),
    // 副标题
    new Paragraph({
      alignment: AlignmentType.CENTER,
      children: [new TextRun({ 
        text: config.subtitle, 
        size: 24, 
        font: 'Microsoft YaHei' 
      })]
    }),
    new Paragraph({ children: [new TextRun('')] }),
  ];

  // 添加各个模块
  config.sections.forEach(section => {
    // 模块标题
    children.push(new Paragraph({
      heading: HeadingLevel.HEADING_2,
      children: [new TextRun({ 
        text: section.title, 
        bold: true, 
        font: 'Microsoft YaHei' 
      })]
    }));
    
    // 模块内容
    section.content.forEach(item => {
      children.push(createParagraph(item));
    });
    
    // 模块间距
    children.push(new Paragraph({ children: [new TextRun('')] }));
  });

  const doc = new Document({
    styles: {
      default: { 
        document: { 
          run: { font: 'Microsoft YaHei', size: 24 } 
        } 
      }
    },
    sections: [{
      properties: {
        page: {
          size: { width: 11906, height: 16838 },
          margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
        }
      },
      children: children
    }]
  });

  return doc;
}

// 生成文档
const doc = generateDocument();

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync(config.outputPath, buffer);
  console.log(`✅ Word文档已生成：${config.outputPath}`);
}).catch(err => {
  console.error('❌ 生成失败：', err);
});
