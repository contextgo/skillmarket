---
name: product-detail-page
description: This skill should be used when the user needs to create product detail page copy for e-commerce or social media marketing. It helps analyze existing product pages, research market positioning, generate compelling product copy with appropriate tone, and output as Word documents. Trigger phrases include: "做商品详情页", "生成产品详情页", "商品详情页文案", "帮我写详情页", "产品详情页", "详情页制作", "电商详情页".
---

# 商品详情页制作

## 概述

本skill帮助用户创建专业的商品详情页文案，适用于电商平台（微信小店、淘宝等）和社交媒体（小红书、视频号等）。支持分析现有详情页风格、研究竞品宣传套路、生成符合产品调性的文案，并输出为Word文档。

## 工作流程

### 第一步：收集产品信息

询问用户以下信息：
1. **产品类型**：是什么产品？品类、主打款式、价格区间
2. **目标平台**：主要发布在哪里？（微信小店、小红书、淘宝等）
3. **参考案例**：是否有现有的详情页可以参考风格？
4. **产品图片**：产品包装图、实物图等视觉素材
5. **核心卖点**：产品最大的特色是什么？
6. **目标用户**：面向什么人群？（年龄、性别、消费习惯）

### 第二步：分析现有风格（如有参考）

如果用户提供了参考详情页：
1. 分析文案结构（几张图、每页内容）
2. 提炼语气风格（正式/活泼/可爱/专业）
3. 总结常用表达（谐音梗、语气词、句式特点）
4. 识别品牌元素（slogan、签名、固定格式）

### 第三步：研究市场宣传套路

针对产品类型，搜索市场上的宣传方式：
1. 使用web_search搜索同类产品的营销文案
2. 了解行业通用的卖点表达方式
3. 收集目标用户的心理诉求

### 第四步：生成详情页文案

根据收集的信息，生成详情页内容：

**标准结构（可根据需求调整）：**
- 品牌开场/钩子（引起兴趣）
- 产品故事（情感共鸣）
- 产品参数（规格信息）
- 设计细节（卖点展示）
- 玩法/功能教学（使用说明）
- 场景展示（适用场景）
- 限量/收藏价值（稀缺性）

**文案风格指南：**
- 根据产品调性选择语气（儿童产品用活泼可爱语气，加"啦～""呀～""哦～"等语气词）
- 避免过度营销词汇，保持真诚
- 多用短句、分行，提升可读性
- 适当使用emoji增加视觉吸引力

### 第五步：输出文档

1. 生成Markdown格式文案
2. 转换为Word文档（.docx）
3. 保存到用户指定目录

## 使用示例

### 示例1：儿童玩具详情页

**用户输入：**
"帮我做一个儿童节悠悠球的详情页，这是产品图。"

**执行流程：**
1. 询问产品信息（价格、材质、尺寸等）
2. 研究悠悠球市场宣传套路
3. 生成适合儿童节的活泼可爱文案
4. 加入语气词（"啦～""呀～""哦～"）
5. 输出Word文档

### 示例2：参考现有风格

**用户输入：**
"参考我之前发的龙虾鹅详情页风格，帮我写一个新的企鹅悠悠球详情页。"

**执行流程：**
1. 分析龙虾鹅详情页的风格特征
2. 提取品牌元素和语气特点
3. 应用到新产品上
4. 保持风格一致性

## 技术实现

### 生成Word文档

使用docx-js库生成Word文档：

```javascript
const { Document, Packer, Paragraph, TextRun } = require('docx');
const fs = require('fs');

const doc = new Document({
  sections: [{
    properties: {
      page: {
        size: { width: 11906, height: 16838 },
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 }
      }
    },
    children: [
      // 段落内容
    ]
  }]
});

Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync('output.docx', buffer);
});
```

### 运行环境要求

- Node.js环境
- docx模块：`npm install docx`
- 字体：Microsoft YaHei（微软雅黑）

## 注意事项

1. **语气适配**：根据产品类型调整语气（儿童产品活泼、专业产品严谨）
2. **平台适配**：不同平台详情页结构不同（小红书重图文、微信小店重转化）
3. **用户确认**：生成过程中及时与用户确认方向
4. **迭代优化**：根据用户反馈调整文案内容

## 资源

### scripts/
- `create_docx.js` - 生成Word文档的Node.js脚本模板

### references/
- 无（可根据需要添加产品类别参考文档）

### assets/
- 无（可根据需要添加文档模板）
