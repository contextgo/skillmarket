#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
功能清单生成器
从各类文档中提取功能清单并生成 Excel 表格
"""

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill
from datetime import datetime
import os


def create_feature_list_excel(features, output_path=None):
    """
    生成功能清单 Excel 文件
    
    Args:
        features: 列表，每个元素是字典，包含各级功能和描述
        output_path: 输出文件路径，默认为 功能清单_YYYYMMDD.xlsx
    
    Returns:
        生成的文件路径
    """
    if output_path is None:
        today = datetime.now().strftime("%Y%m%d")
        output_path = f"功能清单_{today}.xlsx"
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "功能清单"
    
    # 确定最大层级
    chinese_nums = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十"]
    max_level = 1
    for feature in features:
        for key in feature.keys():
            if "级功能" in key:
                # 提取中文数字并转换为级别
                for i, num in enumerate(chinese_nums, 1):
                    if key.startswith(num):
                        max_level = max(max_level, i)
                        break
    
    # 设置表头（使用中文数字）
    chinese_nums = ["一", "二", "三", "四", "五", "六", "七", "八", "九", "十"]
    headers = [f"{chinese_nums[i-1]}级功能" for i in range(1, max_level + 1)] + ["功能描述"]
    ws.append(headers)
    
    # 设置表头样式
    header_font = Font(bold=True, size=11, color="FFFFFF")
    header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
    header_alignment = Alignment(horizontal="center", vertical="center")
    
    for col in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = header_alignment
    
    # 填充数据
    for feature in features:
        row_data = []
        for i in range(1, max_level + 1):
            row_data.append(feature.get(f"{chinese_nums[i-1]}级功能", ""))
        row_data.append(feature.get("功能描述", ""))
        ws.append(row_data)
    
    # 合并单元格
    merge_cells(ws, max_level)
    
    # 设置列宽
    for i in range(1, max_level + 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(i)].width = 20
    ws.column_dimensions[openpyxl.utils.get_column_letter(max_level + 1)].width = 60
    
    # 设置所有单元格样式
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=len(headers)):
        for cell in row:
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    
    # 设置行高
    for row in range(2, ws.max_row + 1):
        ws.row_dimensions[row].height = 30
    
    wb.save(output_path)
    print(f"✅ 功能清单已保存至: {os.path.abspath(output_path)}")
    return output_path


def merge_cells(ws, max_level):
    """
    合并相同层级的单元格
    
    Args:
        ws: Worksheet 对象
        max_level: 最大功能层级数
    """
    # 按列合并（一级功能到最后一级功能列）
    for col_idx in range(1, max_level + 1):
        current_value = None
        start_row = 2
        
        for row_idx in range(2, ws.max_row + 1):
            cell_value = ws.cell(row=row_idx, column=col_idx).value
            
            if cell_value != current_value:
                # 合并之前的单元格
                if current_value is not None and start_row < row_idx - 1:
                    ws.merge_cells(start_row=start_row, start_column=col_idx, 
                                   end_row=row_idx - 1, end_column=col_idx)
                current_value = cell_value
                start_row = row_idx
        
        # 处理最后一组
        if current_value is not None and start_row < ws.max_row:
            ws.merge_cells(start_row=start_row, start_column=col_idx, 
                           end_row=ws.max_row, end_column=col_idx)


# 示例用法
if __name__ == "__main__":
    # 示例数据
    sample_features = [
        {
            "一级功能": "用户管理",
            "二级功能": "用户注册",
            "三级功能": "手机号注册",
            "功能描述": "支持通过手机号接收验证码完成账号注册"
        },
        {
            "一级功能": "用户管理",
            "二级功能": "用户注册",
            "三级功能": "邮箱注册",
            "功能描述": "支持通过邮箱验证完成账号注册"
        },
        {
            "一级功能": "用户管理",
            "二级功能": "用户登录",
            "三级功能": "密码登录",
            "功能描述": "支持使用账号密码进行登录"
        },
        {
            "一级功能": "用户管理",
            "二级功能": "用户登录",
            "三级功能": "短信验证码登录",
            "功能描述": "支持使用短信验证码进行快捷登录"
        },
        {
            "一级功能": "订单管理",
            "二级功能": "订单创建",
            "三级功能": "",
            "功能描述": "支持用户创建新订单，选择商品和数量"
        },
        {
            "一级功能": "订单管理",
            "二级功能": "订单查询",
            "三级功能": "",
            "功能描述": "支持按时间、状态、订单号等条件查询订单"
        },
    ]
    
    create_feature_list_excel(sample_features, "示例_功能清单.xlsx")
