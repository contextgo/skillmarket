---
name: feature-list-extractor
description: 从投标文件、技术协议、方案文档、会议记录等文档中提取功能清单，并生成层级化的 Excel 表格。当用户需要整理功能清单、提取文档中的功能点、生成 .xlsx 格式的功能清单表格时使用。
---

# 功能清单提取器

## 用途

帮助产品经理从各类文档（投标文件、技术协议、方案文档、会议记录等）中提取并整理功能清单，生成结构化的 Excel 表格。

## 输出格式

生成的 Excel 表格包含以下列：
- 一级功能
- 二级功能
- 三级功能
- ...（四级功能及以上根据实际需要扩展层级）
- 功能描述

## 工作流程

### 1. 读取文档

读取用户提供的文档内容，支持以下格式：
- .docx (Word 文档)
- .pdf (PDF 文档)
- .txt (文本文件)
- .md (Markdown 文件)
- 直接粘贴的文本内容

### 2. 分析功能结构

识别文档中的功能层级关系：
- **一级功能**：主要功能模块或系统
- **二级功能**：一级功能下的子模块
- **三级功能**：二级功能下的具体功能点
- **功能描述**：该功能的详细说明

### 3. 提取功能点

从文档中提取以下信息：
- 功能名称（按层级归类）
- 功能描述（尽可能详细）
- 功能之间的层级关系

### 4. 生成 Excel 文件

使用 Python 的 openpyxl 库生成 Excel 文件：
- 创建表格并设置表头
- 填充功能数据
- 合并相同层级的单元格
- 设置合适的列宽和格式

## 单元格合并规则

1. **纵向合并**：同一父级功能下的相同子功能需要合并单元格
2. **合并范围**：
   - 一级功能列：合并该一级功能下的所有行
   - 二级功能列：合并该二级功能下的所有行
   - 以此类推
3. **保留值**：合并后的单元格保留第一个值

## Python 代码模板

```python
import openpyxl
from openpyxl.styles import Alignment, Font, Border, Side
from openpyxl.utils import get_column_letter

def create_feature_list_excel(features, output_path):
    """
    生成功能清单 Excel 文件
    
    features: 列表，每个元素是字典，包含各级功能和描述
    例如：
    [
        {
            "一级功能": "用户管理",
            "二级功能": "用户注册",
            "三级功能": "手机号注册",
            "功能描述": "支持通过手机号注册账号"
        },
        ...
    ]
    """
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "功能清单"
    
    # 设置表头
    headers = ["一级功能", "二级功能", "三级功能", "功能描述"]
    ws.append(headers)
    
    # 设置表头样式
    header_font = Font(bold=True, size=12)
    header_alignment = Alignment(horizontal="center", vertical="center")
    for col in range(1, len(headers) + 1):
        cell = ws.cell(row=1, column=col)
        cell.font = header_font
        cell.alignment = header_alignment
    
    # 填充数据
    for feature in features:
        row_data = [
            feature.get("一级功能", ""),
            feature.get("二级功能", ""),
            feature.get("三级功能", ""),
            feature.get("功能描述", "")
        ]
        ws.append(row_data)
    
    # 合并单元格
    merge_cells(ws, features)
    
    # 设置列宽
    ws.column_dimensions["A"].width = 20
    ws.column_dimensions["B"].width = 20
    ws.column_dimensions["C"].width = 20
    ws.column_dimensions["D"].width = 50
    
    # 设置所有单元格样式
    for row in ws.iter_rows(min_row=1, max_row=ws.max_row, min_col=1, max_col=len(headers)):
        for cell in row:
            cell.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
    
    wb.save(output_path)
    print(f"功能清单已保存至: {output_path}")

def merge_cells(ws, features):
    """合并相同层级的单元格"""
    # 按列合并
    for col_idx in range(1, 4):  # 一级、二级、三级功能列
        current_value = None
        start_row = 2
        
        for row_idx in range(2, ws.max_row + 1):
            cell_value = ws.cell(row=row_idx, column=col_idx).value
            
            if cell_value != current_value:
                # 合并之前的单元格
                if current_value is not None and start_row < row_idx - 1:
                    ws.merge_cells(start_row=start_row, start_column=col_idx, 
                                   end_row=row_idx - 1, end_column=col_idx)
                current_value = cell_value
                start_row = row_idx
        
        # 处理最后一组
        if current_value is not None and start_row < ws.max_row:
            ws.merge_cells(start_row=start_row, start_column=col_idx, 
                           end_row=ws.max_row, end_column=col_idx)
```

## 使用示例

**用户输入**：
"请帮我从这份投标文件整理功能清单"

**处理步骤**：
1. 读取用户提供的投标文件
2. 识别文档结构，提取功能层级
3. 整理成功能清单数据结构
4. 生成 Excel 文件并保存

**输出文件**：
- 文件名：`功能清单_YYYYMMDD.xlsx`
- 位置：当前工作目录

## 注意事项

1. 如果文档格式混乱，可能需要手动调整提取结果
2. 功能层级最多支持到三级，如有需要可扩展
3. 功能描述尽量保持原文，必要时进行精简
4. 合并单元格后，Excel 文件可能需要手动调整格式
