#!/usr/bin/env python3
from __future__ import annotations

import argparse
import logging
import os
import sys
import urllib.parse
from pathlib import Path

from mineru_api import FileSpec, MineruError, resolve_mode, run_agent_mode, run_precise_mode, save_outputs


LOGGER = logging.getLogger("mineru_doc_to_markdown")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="使用 MinerU 将文档转为 Markdown")
    parser.add_argument("inputs", nargs="+", help="本地文件路径或远程 URL")
    parser.add_argument("--token", help="MinerU Token，默认读取 MINERU_API_TOKEN")
    parser.add_argument("--output-dir", default="outputs/mineru", help="输出目录")
    parser.add_argument("--log-file", default="logs/mineru_markdown.log", help="日志文件")
    parser.add_argument("--mode", default="auto", choices=["auto", "precise", "agent"])
    parser.add_argument("--model-version", default="vlm", choices=["pipeline", "vlm", "MinerU-HTML"])
    parser.add_argument("--language", default="ch")
    parser.add_argument("--poll-interval", type=float, default=5.0)
    parser.add_argument("--timeout", type=float, default=900.0)
    parser.add_argument("--page-ranges", default=None)
    parser.add_argument("--enable-table", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--enable-formula", action=argparse.BooleanOptionalAction, default=True)
    parser.add_argument("--is-ocr", action="store_true")
    parser.add_argument("--no-cache", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    token = args.token or os.getenv("MINERU_API_TOKEN")
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    setup_logging(Path(args.log_file).resolve())
    specs = [to_file_spec(item) for item in args.inputs]

    if has_mixed_inputs(specs):
        print("[ERROR] 本次命令请只传本地文件或只传远程 URL，不要混用。", file=sys.stderr)
        return 1

    mode = resolve_mode(args.mode, token)
    LOGGER.info("当前模式：%s", mode)

    try:
        if mode == "precise":
            if not token:
                raise MineruError("精准模式需要 MINERU_API_TOKEN 或 --token。")
            results = run_precise_mode(token, specs, args, LOGGER)
        else:
            results = run_agent_mode(specs, args, LOGGER)
        return save_outputs(results, output_dir, mode, LOGGER)
    except MineruError as exc:
        LOGGER.error("处理失败：%s", exc)
        print(f"[ERROR] {exc}", file=sys.stderr)
        return 1


def setup_logging(log_file: Path) -> None:
    log_file.parent.mkdir(parents=True, exist_ok=True)
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[
            logging.FileHandler(log_file, encoding="utf-8"),
            logging.StreamHandler(sys.stdout),
        ],
    )


def to_file_spec(raw_input: str) -> FileSpec:
    parsed = urllib.parse.urlparse(raw_input)
    if parsed.scheme in {"http", "https"} and parsed.netloc:
        name = Path(parsed.path).name or "remote-file"
        return FileSpec(source=raw_input, name=name, is_remote=True)
    path = Path(raw_input).expanduser().resolve()
    if not path.exists():
        raise MineruError(f"文件不存在：{path}")
    return FileSpec(source=str(path), name=path.name, is_remote=False)


def has_mixed_inputs(specs: list[FileSpec]) -> bool:
    return any(item.is_remote for item in specs) and any(not item.is_remote for item in specs)


if __name__ == "__main__":
    raise SystemExit(main())
