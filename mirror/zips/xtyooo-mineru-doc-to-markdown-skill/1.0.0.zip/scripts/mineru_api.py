from __future__ import annotations

import http.client
import json
import time
import urllib.error
import urllib.request
import zipfile
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
from typing import Any


@dataclass(slots=True)
class FileSpec:
    source: str
    name: str
    is_remote: bool


@dataclass(slots=True)
class ExtractResult:
    file_name: str
    state: str
    full_zip_url: str | None = None
    markdown_url: str | None = None
    err_msg: str | None = None


class MineruError(RuntimeError):
    pass


def resolve_mode(raw_mode: str, token: str | None) -> str:
    if raw_mode == "auto":
        return "precise" if token else "agent"
    return raw_mode


def run_precise_mode(
    token: str,
    specs: list[FileSpec],
    args: Any,
    logger: Any,
) -> list[ExtractResult]:
    batch_id = submit_remote_batch(token, specs, args) if specs[0].is_remote else submit_local_batch(token, specs, args, logger)
    logger.info("精准模式任务已提交，batch_id=%s", batch_id)
    return wait_for_precise_batch(token, batch_id, args.poll_interval, args.timeout, logger)


def run_agent_mode(specs: list[FileSpec], args: Any, logger: Any) -> list[ExtractResult]:
    results: list[ExtractResult] = []
    for spec in specs:
        task_id = submit_agent_task(spec, args, logger)
        logger.info("轻量模式任务已提交，task_id=%s file=%s", task_id, spec.name)
        results.append(wait_for_agent_task(task_id, spec.name, args.poll_interval, args.timeout, logger))
    return results


def submit_local_batch(token: str, specs: list[FileSpec], args: Any, logger: Any) -> str:
    payload = {
        "files": [build_precise_file_payload(item.name, args.page_ranges, args.is_ocr) for item in specs],
        "model_version": args.model_version,
        "language": args.language,
        "enable_formula": args.enable_formula,
        "enable_table": args.enable_table,
    }
    response = request_json_with_token("POST", "https://mineru.net/api/v4/file-urls/batch", payload, token)
    batch_id = str(response["data"]["batch_id"])
    upload_urls = response["data"].get("file_urls", [])
    if len(upload_urls) != len(specs):
        raise MineruError("上传地址数量与文件数量不一致。")

    for upload_url, item in zip(upload_urls, specs, strict=True):
        upload_binary(upload_url, Path(item.source))
        logger.info("精准模式上传成功：%s", item.name)
    return batch_id


def submit_remote_batch(token: str, specs: list[FileSpec], args: Any) -> str:
    payload = {
        "files": [
            {
                "url": item.source,
                "data_id": Path(item.name).stem,
                **({"page_ranges": args.page_ranges} if args.page_ranges else {}),
                **({"is_ocr": True} if args.is_ocr else {}),
            }
            for item in specs
        ],
        "model_version": args.model_version,
        "language": args.language,
        "enable_formula": args.enable_formula,
        "enable_table": args.enable_table,
        "no_cache": args.no_cache,
    }
    response = request_json_with_token("POST", "https://mineru.net/api/v4/extract/task/batch", payload, token)
    return str(response["data"]["batch_id"])


def wait_for_precise_batch(token: str, batch_id: str, poll_interval: float, timeout: float, logger: Any) -> list[ExtractResult]:
    start = time.monotonic()
    while True:
        response = request_json_with_token("GET", f"https://mineru.net/api/v4/extract-results/batch/{batch_id}", None, token)
        raw_results = response["data"].get("extract_result", [])
        results = [
            ExtractResult(
                file_name=str(item.get("file_name", "")),
                state=str(item.get("state", "")),
                full_zip_url=item.get("full_zip_url"),
                err_msg=item.get("err_msg"),
            )
            for item in raw_results
        ]
        states = {item.state for item in results}
        if states and states.issubset({"done", "failed"}):
            return results
        if time.monotonic() - start > timeout:
            raise MineruError(f"精准模式轮询超时，batch_id={batch_id}")
        logger.info("精准模式等待中，当前状态：%s", ", ".join(sorted(states)) if states else "empty")
        time.sleep(poll_interval)


def submit_agent_task(spec: FileSpec, args: Any, logger: Any) -> str:
    if spec.is_remote:
        payload: dict[str, Any] = {
            "url": spec.source,
            "file_name": spec.name,
            "language": args.language,
            "enable_table": args.enable_table,
            "is_ocr": args.is_ocr,
            "enable_formula": args.enable_formula,
        }
        if args.page_ranges:
            payload["page_range"] = to_agent_page_range(args.page_ranges)
        response = request_json_without_token("POST", "https://mineru.net/api/v1/agent/parse/url", payload)
        return str(response["data"]["task_id"])

    payload = {
        "file_name": spec.name,
        "language": args.language,
        "enable_table": args.enable_table,
        "is_ocr": args.is_ocr,
        "enable_formula": args.enable_formula,
    }
    if args.page_ranges:
        payload["page_range"] = to_agent_page_range(args.page_ranges)
    response = request_json_without_token("POST", "https://mineru.net/api/v1/agent/parse/file", payload)
    task_id = str(response["data"]["task_id"])
    upload_binary(str(response["data"]["file_url"]), Path(spec.source))
    logger.info("轻量模式上传成功：%s", spec.name)
    return task_id


def wait_for_agent_task(task_id: str, file_name: str, poll_interval: float, timeout: float, logger: Any) -> ExtractResult:
    start = time.monotonic()
    while True:
        response = request_json_without_token("GET", f"https://mineru.net/api/v1/agent/parse/{task_id}", None)
        data = response["data"]
        state = str(data.get("state", ""))
        if state == "done":
            return ExtractResult(file_name=file_name, state=state, markdown_url=data.get("markdown_url"))
        if state == "failed":
            return ExtractResult(file_name=file_name, state=state, err_msg=data.get("err_msg"))
        if time.monotonic() - start > timeout:
            raise MineruError(f"轻量模式轮询超时，task_id={task_id}")
        logger.info("轻量模式等待中，file=%s state=%s", file_name, state)
        time.sleep(poll_interval)


def save_outputs(results: list[ExtractResult], output_dir: Path, mode: str, logger: Any) -> int:
    failed = [item for item in results if item.state == "failed"]
    for item in failed:
        logger.error("%s 解析失败：%s", item.file_name, item.err_msg or "未知错误")
        print(f"[FAILED] {item.file_name}: {item.err_msg or '未知错误'}")

    success = [item for item in results if item.state == "done"]
    for item in success:
        markdown_path = output_dir / f"{Path(item.file_name).stem}.md"
        if mode == "precise":
            if not item.full_zip_url:
                raise MineruError(f"{item.file_name} 缺少 full_zip_url")
            zip_bytes = download_bytes(item.full_zip_url)
            (output_dir / f"{Path(item.file_name).stem}.zip").write_bytes(zip_bytes)
            markdown_text = extract_full_md(zip_bytes)
        else:
            if not item.markdown_url:
                raise MineruError(f"{item.file_name} 缺少 markdown_url")
            markdown_text = download_bytes(item.markdown_url).decode("utf-8")
        markdown_path.write_text(markdown_text, encoding="utf-8")
        print(f"[OK] {item.file_name} -> {markdown_path}")
        preview = "\n".join(markdown_text.splitlines()[:8]).strip()
        if preview:
            print(preview)
            print("-" * 40)
    return 1 if failed else 0


def extract_full_md(zip_bytes: bytes) -> str:
    with zipfile.ZipFile(BytesIO(zip_bytes)) as archive:
        try:
            return archive.read("full.md").decode("utf-8")
        except KeyError as exc:
            raise MineruError("结果压缩包中未找到 full.md") from exc


def download_bytes(url: str) -> bytes:
    request = urllib.request.Request(url, method="GET")
    with urllib.request.urlopen(request, timeout=120) as response:
        return response.read()


def upload_binary(url: str, file_path: Path) -> None:
    parsed = urllib.parse.urlparse(url)
    connection_cls = http.client.HTTPSConnection if parsed.scheme == "https" else http.client.HTTPConnection
    body = file_path.read_bytes()
    target = parsed.path or "/"
    if parsed.query:
        target = f"{target}?{parsed.query}"

    connection = connection_cls(parsed.netloc, timeout=120)
    try:
        connection.request("PUT", target, body=body, headers={"Content-Length": str(len(body))})
        response = connection.getresponse()
        response.read()
        if response.status not in (200, 201):
            raise MineruError(f"{file_path.name} 上传失败，HTTP {response.status}")
    finally:
        connection.close()


def build_precise_file_payload(file_name: str, page_ranges: str | None, is_ocr: bool) -> dict[str, Any]:
    payload: dict[str, Any] = {"name": file_name, "data_id": Path(file_name).stem}
    if page_ranges:
        payload["page_ranges"] = page_ranges
    if is_ocr:
        payload["is_ocr"] = True
    return payload


def to_agent_page_range(page_ranges: str) -> str:
    return page_ranges.split(",", maxsplit=1)[0] if "," in page_ranges else page_ranges


def request_json_with_token(method: str, url: str, payload: dict[str, Any] | None, token: str) -> dict[str, Any]:
    return request_json(method, url, payload, {"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "*/*"})


def request_json_without_token(method: str, url: str, payload: dict[str, Any] | None) -> dict[str, Any]:
    return request_json(method, url, payload, {"Content-Type": "application/json", "Accept": "*/*"})


def request_json(method: str, url: str, payload: dict[str, Any] | None, headers: dict[str, str]) -> dict[str, Any]:
    data = None if payload is None else json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=data, method=method, headers=headers)
    try:
        with urllib.request.urlopen(request, timeout=120) as response:
            body = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        error_body = exc.read().decode("utf-8", errors="ignore")
        raise MineruError(f"HTTP {exc.code}: {error_body or exc.reason}") from exc

    result = json.loads(body)
    if result.get("code") != 0:
        raise MineruError(f"MinerU 接口失败: code={result.get('code')} msg={result.get('msg')}")
    return result
