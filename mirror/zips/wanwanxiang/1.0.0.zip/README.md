# wanwanxiang-skill

这是 `6 道菜碗碗香` 的 Skill 目录。

## 建议上传到 GitHub 的内容

把这个文件夹整体上传：

- `SKILL.md`
- `skill.json`
- `README.md`

## MCP 地址

当前 MCP 地址：

`https://wanwanxiang.2300203862.workers.dev/mcp`

## 适合怎么发给别人

可以把这个目录放到 GitHub 仓库里，然后把仓库地址或这个目录地址发给别人的 AI。

AI 侧通常至少需要看到：

1. `SKILL.md`
2. `skill.json`
3. MCP 地址

## 说明

- 菜单问题应该优先调用菜单工具
- FAQ 只做建议问题和关键词粗匹配
- 通知、节假日安排、问卷提醒等内容，来自飞书 `高频问题与通知` 表
