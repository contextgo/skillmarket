# -*- coding: utf-8 -*-
"""
未来7天逐3小时天气预报美妆解读
用法: python3 beauty_weather.py --city 北京
      python3 beauty_weather.py --city_id 101010100
"""

import sys
import os
import json
import argparse
import urllib.request
import urllib.error
import ssl
from datetime import datetime

# 导入城市数据
sys.path.insert(0, os.path.dirname(__file__))
from city_data import CITY_DB

# 忽略自签名证书
_SSL_CTX = ssl.create_default_context()
_SSL_CTX.check_hostname = False
_SSL_CTX.verify_mode = ssl.CERT_NONE

# ──────────────────────────────────────────────
# 城市模糊匹配
# ──────────────────────────────────────────────
def find_city(query: str):
    """模糊匹配城市，返回 (city_name, city_id) 或 None"""
    query = query.strip()
    # 1. 精确匹配
    if query in CITY_DB:
        return query, CITY_DB[query]
    # 2. 正向模糊：用户输入包含在城市名中（如"杭"→"杭州"）
    candidates = [(name, cid) for name, cid in CITY_DB.items() if query in name]
    if candidates:
        candidates.sort(key=lambda x: len(x[0]))
        return candidates[0]
    # 3. 反向模糊：城市名包含在用户输入中（如"公安县"→"公安"）
    candidates = [(name, cid) for name, cid in CITY_DB.items() if name in query]
    if candidates:
        # 优先返回匹配最长的城市名（最精确）
        candidates.sort(key=lambda x: len(x[0]), reverse=True)
        return candidates[0]
    return None


# ──────────────────────────────────────────────
# 数据获取
# ──────────────────────────────────────────────
BASE_URL = "https://diga2026-1252033877.cos.ap-beijing.myqcloud.com/kg3hour"

def fetch_beauty_data(city_id: str) -> list:
    url = f"{BASE_URL}/{city_id}beauty.json"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=15, context=_SSL_CTX) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw)
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"数据获取失败 (HTTP {e.code})：城市ID {city_id} 暂无数据")
    except Exception as e:
        raise RuntimeError(f"网络请求失败：{e}")


# ──────────────────────────────────────────────
# 时间辅助
# ──────────────────────────────────────────────
def get_day_label(date_str: str, today_str: str) -> str:
    try:
        d = datetime.strptime(date_str[:10], "%Y-%m-%d")
        t = datetime.strptime(today_str[:10], "%Y-%m-%d")
        diff = (d - t).days
        weekdays = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]
        wd = weekdays[d.weekday()]
        if diff == 0:
            return f"今天（{wd}）"
        elif diff == 1:
            return f"明天（{wd}）"
        elif diff == 2:
            return f"后天（{wd}）"
        elif diff > 0:
            return f"{d.strftime('%m月%d日')}（{wd}）"
        else:
            return d.strftime('%m月%d日')
    except Exception:
        return date_str[:10]


def get_period_label(hour: int) -> str:
    if 0 <= hour < 3:
        return "深夜"
    elif 3 <= hour < 6:
        return "凌晨"
    elif 6 <= hour < 9:
        return "清晨"
    elif 9 <= hour < 12:
        return "上午"
    elif 12 <= hour < 15:
        return "午间"
    elif 15 <= hour < 18:
        return "下午"
    elif 18 <= hour < 21:
        return "傍晚"
    else:
        return "晚间"


# ──────────────────────────────────────────────
# 输出格式化
# ──────────────────────────────────────────────
def format_output(city_name: str, records: list) -> str:
    lines = []
    today = datetime.now().strftime("%Y-%m-%d")

    lines.append("")
    lines.append("=" * 60)
    lines.append(f"  💄 {city_name} · 未来7天美妆天气深度解读")
    lines.append(f"  🕐 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("=" * 60)
    lines.append("")

    # 按日期分组
    grouped = {}
    date_order = []
    for rec in records:
        date_key = rec.get("date", "")[:10]
        if not date_key:
            continue
        if date_key not in grouped:
            grouped[date_key] = []
            date_order.append(date_key)
        grouped[date_key].append(rec)

    if not grouped:
        lines.append("⚠️  未获取到有效数据")
        return "\n".join(lines)

    for date_key in date_order[:7]:
        day_label = get_day_label(date_key, today)
        slots = grouped[date_key]

        lines.append(f"📅  {day_label}  [{date_key}]")
        lines.append("━" * 60)

        for rec in slots:
            hour = rec.get("hour", 0)
            try:
                hour = int(hour)
            except (TypeError, ValueError):
                hour = 0
            period = get_period_label(hour)
            word = (rec.get("word") or "").strip()
            content = (rec.get("content") or "").strip()

            lines.append(f"")
            lines.append(f"  ⏰ {hour:02d}:00  {period}")
            lines.append(f"  {'─' * 50}")

            if word:
                lines.append(f"  💬 核心要点：{word}")

            if content:
                lines.append("")
                # 格式化 content 段落，每行加缩进
                for para_line in content.split("\n"):
                    para_line = para_line.strip()
                    if para_line:
                        lines.append(f"  {para_line}")
                    else:
                        lines.append("")

        lines.append("")
        lines.append("━" * 60)
        lines.append("")

    lines.append("=" * 60)
    lines.append("  以上为完整美妆天气深度解读，祝您每天妆容完美！💋")
    lines.append("=" * 60)
    lines.append("")

    return "\n".join(lines)


# ──────────────────────────────────────────────
# 主入口
# ──────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="未来7天逐3小时天气美妆解读")
    parser.add_argument("--city", type=str, help="城市名称（支持模糊匹配）", default="")
    parser.add_argument("--city_id", type=str, help="城市ID（如 101010100）", default="")
    args = parser.parse_args()

    city_id = ""
    city_name = ""

    if args.city_id:
        city_id = args.city_id.strip()
        for name, cid in CITY_DB.items():
            if cid == city_id:
                city_name = name
                break
        if not city_name:
            city_name = f"城市{city_id}"
    elif args.city:
        match = find_city(args.city)
        if match is None:
            print(f"❌ 未找到城市「{args.city}」，请尝试更精确的城市名称")
            print("提示：支持全国3000+城市及部分国际城市")
            sys.exit(1)
        city_name, city_id = match
    else:
        print("请提供城市参数，例如：")
        print("  python3 beauty_weather.py --city 北京")
        print("  python3 beauty_weather.py --city_id 101010100")
        sys.exit(1)

    print(f"🔍 正在获取 {city_name}（{city_id}）的美妆天气解读数据…")

    try:
        records = fetch_beauty_data(city_id)
    except RuntimeError as e:
        print(f"❌ {e}")
        sys.exit(1)

    if not isinstance(records, list):
        print("❌ 数据格式异常，请稍后重试")
        sys.exit(1)

    output = format_output(city_name, records)
    print(output)


if __name__ == "__main__":
    main()
