/**
 * 六项防治指标计算脚本
 * 
 * 用法：
 * node calculate_indicators.js --input <项目数据.json> --output <输出目录>
 * 
 * 示例：
 * node calculate_indicators.js --input ../项目数据.json --output ./
 */

const fs = require('fs');
const path = require('path');
const { Command } = require('commander');

// 解析命令行参数
const program = new Command();
program
  .option('-i, --input <path>', '项目数据JSON文件路径')
  .option('-o, --output <path>', '输出目录路径')
  .parse(process.argv);
const options = program.opts();

if (!options.input) {
  console.error('错误：请指定项目数据文件路径 (--input)');
  process.exit(1);
}

if (!options.output) {
  console.error('错误：请指定输出目录路径 (--output)');
  process.exit(1);
}

// 读取项目数据
const projectData = JSON.parse(fs.readFileSync(options.input, 'utf8'));

/**
 * 六项防治指标计算
 */
class IndicatorCalculator {
  constructor(data) {
    this.data = data;
  }

  /**
   * 1. 水土流失治理度
   * 公式：治理面积 / 扰动面积 × 100%
   */
  calculate治理度() {
    const { 占地面积, 分区数据 } = this.data;
    
    // 扰动面积 = 占地面积 - 不扰动面积（如硬化场地）
    const 扰动面积 = 分区数据.reduce((sum, zone) => {
      const 非硬化面积 = zone.占地面积 * (1 - (zone.硬化率 || 0));
      return sum + 非硬化面积;
    }, 0);
    
    // 治理面积 = 扰动面积 - 未治理面积
    const 治理面积 = 分区数据.reduce((sum, zone) => {
      return sum + (zone.已治理面积 || zone.占地面积);
    }, 0);
    
    const 治理度 = (治理面积 / 扰动面积 * 100).toFixed(2);
    
    return {
      指标: '水土流失治理度',
      目标值: '≥87%',
      计算值: `${治理度}%`,
      达标: parseFloat(治理度) >= 87,
      治理面积: 治理面积.toFixed(2),
      扰动面积: 扰动面积.toFixed(2),
      计算公式: '治理面积 / 扰动面积 × 100%'
    };
  }

  /**
   * 2. 土壤流失控制比
   * 公式：治理后侵蚀模数 / 容许侵蚀模数
   */
  calculate控制比() {
    const { 土壤侵蚀, 措施配置 } = this.data;
    
    const 容许侵蚀模数 = 土壤侵蚀.容许值 || 500; // t/km²·a
    
    // 治理后侵蚀模数估算（简化计算）
    let 治理后侵蚀模数 = 土壤侵蚀.背景值;
    
    // 根据措施配置降低侵蚀模数
    if (措施配置.护坡) {
      治理后侵蚀模数 *= 0.3; // 护坡降低70%
    }
    if (措施配置.植被覆盖) {
      治理后侵蚀模数 *= (1 - 措施配置.植被覆盖);
    }
    if (措施配置.截排水) {
      治理后侵蚀模数 *= 0.7; // 截排水降低30%
    }
    
    const 控制比 = (治理后侵蚀模数 / 容许侵蚀模数).toFixed(2);
    
    return {
      指标: '土壤流失控制比',
      目标值: '≥1.0',
      计算值: 控制比,
      达标: parseFloat(控制比) >= 1.0,
      治理后侵蚀模数: 治理后侵蚀模数.toFixed(2),
      容许侵蚀模数: 容许侵蚀模数.toFixed(2),
      计算公式: '治理后侵蚀模数 / 容许侵蚀模数'
    };
  }

  /**
   * 3. 渣土防护率
   * 公式：已防护弃渣量 / 弃渣总量 × 100%
   */
  calculate渣土防护率() {
    const { 土石方, 防护措施 } = this.data;
    
    const 弃方总量 = 土石方.弃方量 || 0;
    const 松散系数 = 1.3;
    const 弃渣松散方 = 弃方总量 * 松散系数;
    
    // 防护措施折算
    let 已防护方 = 0;
    
    if (防护措施.挡墙) {
      // 1m³挡墙约防护20m³渣
      已防护方 += 防护措施.挡墙 * 20;
    }
    if (防护措施.覆盖) {
      // 覆盖按实际覆盖体积
      已防护方 += 防护措施.覆盖;
    }
    if (防护措施.拦挡) {
      // 拦挡折算
      已防护方 += 防护措施.拦挡 * 15;
    }
    
    const 防护率 = (Math.min(已防护方 / 弃渣松散方, 1) * 100).toFixed(2);
    
    return {
      指标: '渣土防护率',
      目标值: '≥90%',
      计算值: `${防护率}%`,
      达标: parseFloat(防护率) >= 90,
      已防护弃渣方: 已防护方.toFixed(2),
      弃渣松散方: 弃渣松散方.toFixed(2),
      计算公式: '已防护弃渣量 / 弃渣总量 × 100%'
    };
  }

  /**
   * 4. 表土保护率
   * 公式：保护表土量 / 可剥离表土量 × 100%
   */
  calculate表土保护率() {
    const { 占地面积, 表土剥离, 表土回覆 } = this.data;
    
    const 表土厚度 = 表土剥离?.厚度 || 0.3; // m
    const 可剥离表土量 = 占地面积 * 表土厚度 * 10000; // m³
    
    // 已保护表土量 = 已剥离并防护的表土
    const 已保护表土量 = Math.min(
      (表土剥离?.已剥离量 || 可剥离表土量 * 0.95),
      表土回覆?.需回覆量 || 0
    );
    
    const 保护率 = (已保护表土量 / 可剥离表土量 * 100).toFixed(2);
    
    return {
      指标: '表土保护率',
      目标值: '≥95%',
      计算值: `${保护率}%`,
      达标: parseFloat(保护率) >= 95,
      已保护表土量: 已保护表土量.toFixed(2),
      可剥离表土量: 可剥离表土量.toFixed(2),
      计算公式: '保护表土量 / 可剥离表土量 × 100%'
    };
  }

  /**
   * 5. 林草植被恢复率
   * 公式：恢复林草面积 / 可恢复面积 × 100%
   */
  calculate林草恢复率() {
    const { 分区数据, 绿化配置 } = this.data;
    
    // 可恢复面积统计
    let 可恢复面积 = 0;
    let 恢复林草面积 = 0;
    
    分区数据.forEach(zone => {
      const 绿化面积 = zone.绿化面积 || 0;
      可恢复面积 += 绿化面积;
      恢复林草面积 += 绿化面积 * (绿化配置?.恢复率 || 0.9);
    });
    
    const 恢复率 = (恢复林草面积 / 可恢复面积 * 100).toFixed(2);
    
    return {
      指标: '林草植被恢复率',
      目标值: '≥89%',
      计算值: `${恢复率}%`,
      达标: parseFloat(恢复率) >= 89,
      恢复林草面积: 恢复林草面积.toFixed(2),
      可恢复面积: 可恢复面积.toFixed(2),
      计算公式: '恢复林草面积 / 可恢复面积 × 100%'
    };
  }

  /**
   * 6. 林草覆盖率
   * 公式：林草面积 / 防治责任范围 × 100%
   */
  calculate林草覆盖率() {
    const { 防治责任范围, 分区数据 } = this.data;
    
    // 林草面积统计
    let 林草面积 = 0;
    分区数据.forEach(zone => {
      // 乔木、灌木、草地计入，硬化场地不计入
      林草面积 += zone.林草面积 || zone.绿化面积 * 0.8;
    });
    
    const 覆盖率 = (林草面积 / 防治责任范围 * 100).toFixed(2);
    
    return {
      指标: '林草覆盖率',
      目标值: '≥21%',
      计算值: `${覆盖率}%`,
      达标: parseFloat(覆盖率) >= 21,
      林草面积: 林草面积.toFixed(2),
      防治责任范围: 防治责任范围.toFixed(2),
      计算公式: '林草面积 / 防治责任范围 × 100%'
    };
  }

  /**
   * 计算全部指标
   */
  calculateAll() {
    return {
      项目名称: this.data.项目名称,
      计算日期: new Date().toISOString().split('T')[0],
      指标结果: [
        this.calculate治理度(),
        this.calculate控制比(),
        this.calculate渣土防护率(),
        this.calculate表土保护率(),
        this.calculate林草恢复率(),
        this.calculate林草覆盖率()
      ]
    };
  }
}

// 执行计算
const calculator = new IndicatorCalculator(projectData);
const result = calculator.calculateAll();

// 输出结果
const outputPath = path.join(options.output, '防治指标计算结果.json');
fs.mkdirSync(options.output, { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(result, null, 2), 'utf8');

console.log('\n===== 六项防治指标计算结果 =====');
console.log(`项目名称：${result.项目名称}`);
console.log(`计算日期：${result.计算日期}\n`);

result.指标结果.forEach(item => {
  const 状态 = item.达标 ? '✓ 达标' : '✗ 未达标';
  console.log(`${item.指标}：${item.计算值} ${状态}`);
  console.log(`  目标值：${item.目标值}`);
  console.log(`  公式：${item.计算公式}`);
  console.log('');
});

console.log(`\n结果已保存至：${outputPath}`);
