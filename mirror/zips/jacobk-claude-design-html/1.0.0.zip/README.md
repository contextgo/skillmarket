## 技能文档

### 基本信息
- 技能名: `html-design-master`
- 创建人: @jacobkwang (via 超级Q仔)
- 版本: v1.0.0
- 更新时间: 2026-04-23

### 适用场景
当需要用 HTML/CSS/JS 创建专业级视觉产物时使用：

- 📊 幻灯片 / PPT / Deck
- 📱 交互原型 / App Mockup
- 🎬 动画 / Motion Design
- 🏠 Landing Page / 营销页
- 🎨 设计系统 / UI Kit
- 📈 数据可视化仪表盘

### 前置条件
- 无特殊前置条件
- 推荐配合 `wecom-send-media` 技能使用（用于发送生成的 HTML 文件）

### 设计哲学来源
本技能的设计原则和工作流程提炼自 Claude Design（Anthropic）的 System Prompt，核心理念包括：

1. **专家-经理角色模型** — AI 是设计师（有判断力），用户是经理（拍板）
2. **反 AI 味设计** — 硬性规则避免渐变滥用、emoji 堆砌、烂字体
3. **提问驱动** — 新任务必须主动提问收集上下文
4. **多变体探索** — 默认给 3+ 个方案让用户选
5. **Tweaks 可调面板** — 非技术用户也能微调设计参数

### 使用示例
```
帮我设计一个产品 landing page
做一套 10 页的公司介绍 deck
把这个 PRD 做成交互原型
设计一个管理后台的 dashboard
```

### 注意事项
⚠️ 本技能生成的是 HTML 文件，不是图片
⚠️ 复杂原型可能需要较长生成时间
⚠️ 需要真实图片素材时会使用占位符，用户可后续替换

### 已知问题
- [ ] 暂无

### 相关技能
- `canvas-design`: 静态艺术品/海报设计（输出 PNG/PDF）
- `pptx`: PowerPoint 文件操作（输出 .pptx）
- `wecom-send-media`: 通过企微发送生成的文件

### 参考资料
- `references/original-claude-design-prompt.md` — Claude Design 原始 System Prompt（73KB 完整版）
