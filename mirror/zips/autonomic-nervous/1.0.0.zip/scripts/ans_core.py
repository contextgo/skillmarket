"""
自主神经系统核心
整合所有自主调节功能
"""

import json
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime

from load_balancer import get_load_balancer, SystemState


class AutonomicNervousSystem:
    """自主神经系统"""
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy" / "dreams"
        self.data_dir = data_dir
        
        self.recovery_file = self.data_dir / "recovery-log.json"
        self.load_balancer = get_load_balancer()
    
    def check_system(self, context_tokens: int = 0,
                    is_urgent: bool = False) -> Dict:
        """
        系统健康检查
        
        Args:
            context_tokens: 上下文token数
            is_urgent: 是否紧急
            
        Returns:
            系统状态报告
        """
        # 更新状态
        state = self.load_balancer.update_state(context_tokens, is_urgent)
        
        # 时间感知
        hour = datetime.now().hour
        time_mode = self._get_time_mode(hour)
        
        # 生成报告
        report = {
            "mode": state.mode,
            "load_percentage": round(state.load_percentage, 1),
            "consecutive_steps": state.consecutive_steps,
            "time_mode": time_mode,
            "active_skills": state.active_skills,
            "suppressed_skills": state.suppressed_skills,
            "recommendation": self.load_balancer.get_recommendation()
        }
        
        return report
    
    def _get_time_mode(self, hour: int) -> str:
        """根据时间获取模式"""
        if 9 <= hour < 18:
            return "work_hours"  # 工作时间：快节奏
        elif 23 <= hour or hour < 6:
            return "late_night"  # 深夜：谨慎模式
        else:
            return "off_hours"   # 非工作时间：从容
    
    def should_cooldown(self) -> bool:
        """检查是否需要冷却"""
        return self.load_balancer.current_state.consecutive_steps >= 5
    
    def get_active_skills(self) -> List[str]:
        """获取当前激活的技能"""
        return self.load_balancer.current_state.active_skills
    
    def is_high_load(self) -> bool:
        """检查是否高负荷"""
        return self.load_balancer.current_state.load_percentage > 70
    
    def record_recovery(self):
        """记录恢复"""
        recovery_entry = {
            "timestamp": datetime.now().isoformat(),
            "previous_steps": self.load_balancer.current_state.consecutive_steps,
            "previous_load": self.load_balancer.current_state.load_percentage
        }
        
        recoveries = []
        if self.recovery_file.exists():
            try:
                with open(self.recovery_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    recoveries = data.get("recoveries", [])
            except:
                pass
        
        recoveries.append(recovery_entry)
        
        with open(self.recovery_file, 'w', encoding='utf-8') as f:
            json.dump({
                "recoveries": recoveries[-50:],  # 只保留最近50条
                "updated_at": datetime.now().isoformat()
            }, f, ensure_ascii=False, indent=2)
        
        # 重置状态
        self.load_balancer._trigger_cooldown()
    
    def get_system_summary(self) -> Dict:
        """获取系统摘要"""
        state = self.load_balancer.current_state
        
        return {
            "current_mode": state.mode,
            "load": f"{state.load_percentage:.0f}%",
            "steps_since_recovery": state.consecutive_steps,
            "skills_active": len(state.active_skills),
            "skills_suppressed": len(state.suppressed_skills)
        }


# 单例
_ans_instance: Optional[AutonomicNervousSystem] = None


def get_ans() -> AutonomicNervousSystem:
    global _ans_instance
    if _ans_instance is None:
        _ans_instance = AutonomicNervousSystem()
    return _ans_instance
