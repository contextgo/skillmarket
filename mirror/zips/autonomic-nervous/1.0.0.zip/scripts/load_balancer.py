"""
认知负荷均衡器
管理系统负载和资源分配
"""

import json
from pathlib import Path
from typing import Dict, List, Optional
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class SystemState:
    """系统状态"""
    mode: str  # parasympathetic, sympathetic, emergency
    load_percentage: float
    consecutive_steps: int
    last_recovery: str
    active_skills: List[str]
    suppressed_skills: List[str]


class LoadBalancer:
    """认知负荷均衡器"""
    
    # 负荷阈值
    LOW_LOAD = 30
    MEDIUM_LOAD = 50
    HIGH_LOAD = 70
    CRITICAL_LOAD = 85
    
    # 冷却阈值
    COOLDOWN_THRESHOLD = 5
    
    def __init__(self, data_dir: Optional[Path] = None):
        if data_dir is None:
            data_dir = Path.home() / ".workbuddy" / "dreams"
        self.data_dir = data_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        
        self.state_file = self.data_dir / "ans-state.json"
        self.load_history_file = self.data_dir / "load-history.json"
        
        self.current_state: Optional[SystemState] = None
        self.load_history: List[Dict] = []
        self._load_state()
    
    def _load_state(self):
        """加载状态"""
        if self.state_file.exists():
            try:
                with open(self.state_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.current_state = SystemState(
                        mode=data.get("mode", "parasympathetic"),
                        load_percentage=data.get("load_percentage", 0),
                        consecutive_steps=data.get("consecutive_steps", 0),
                        last_recovery=data.get("last_recovery", datetime.now().isoformat()),
                        active_skills=data.get("active_skills", []),
                        suppressed_skills=data.get("suppressed_skills", [])
                    )
            except:
                self._initialize_state()
        else:
            self._initialize_state()
        
        if self.load_history_file.exists():
            try:
                with open(self.load_history_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.load_history = data.get("history", [])
            except:
                pass
    
    def _initialize_state(self):
        """初始化状态"""
        self.current_state = SystemState(
            mode="parasympathetic",
            load_percentage=0,
            consecutive_steps=0,
            last_recovery=datetime.now().isoformat(),
            active_skills=["all"],
            suppressed_skills=[]
        )
        self._save_state()
    
    def _save_state(self):
        """保存状态"""
        if self.current_state:
            with open(self.state_file, 'w', encoding='utf-8') as f:
                json.dump(asdict(self.current_state), f, ensure_ascii=False, indent=2)
    
    def calculate_load(self, context_tokens: int, 
                       max_tokens: int = 8000) -> float:
        """
        计算认知负荷
        
        Args:
            context_tokens: 当前上下文token数
            max_tokens: 最大token数
            
        Returns:
            负荷百分比
        """
        load = (context_tokens / max_tokens) * 100
        
        # 记录历史
        self.load_history.append({
            "timestamp": datetime.now().isoformat(),
            "load": load,
            "tokens": context_tokens
        })
        
        # 只保留最近100条
        self.load_history = self.load_history[-100:]
        
        with open(self.load_history_file, 'w', encoding='utf-8') as f:
            json.dump({"history": self.load_history}, f, ensure_ascii=False, indent=2)
        
        return load
    
    def update_state(self, context_tokens: int, 
                     is_urgent: bool = False) -> SystemState:
        """
        更新系统状态
        
        Args:
            context_tokens: 上下文token数
            is_urgent: 是否紧急任务
            
        Returns:
            更新后的状态
        """
        load = self.calculate_load(context_tokens)
        
        # 增加连续步骤计数
        self.current_state.consecutive_steps += 1
        self.current_state.load_percentage = load
        
        # 确定模式
        if is_urgent:
            self.current_state.mode = "sympathetic"
        elif load > self.CRITICAL_LOAD:
            self.current_state.mode = "emergency"
        elif load > self.HIGH_LOAD:
            self.current_state.mode = "sympathetic"
        else:
            self.current_state.mode = "parasympathetic"
        
        # 根据负荷调整技能
        self._adjust_skills_by_load(load)
        
        # 检查是否需要冷却
        if self.current_state.consecutive_steps >= self.COOLDOWN_THRESHOLD:
            if load > self.HIGH_LOAD:
                self._trigger_cooldown()
        
        self._save_state()
        return self.current_state
    
    def _adjust_skills_by_load(self, load: float):
        """根据负荷调整技能"""
        if load < self.LOW_LOAD:
            # 低负荷：全系统运行
            self.current_state.active_skills = ["all"]
            self.current_state.suppressed_skills = []
        elif load < self.MEDIUM_LOAD:
            # 中负荷：关闭self-talk
            self.current_state.active_skills = ["bionic-guard", "bionic-cognition", "habit-loop"]
            self.current_state.suppressed_skills = ["self-talk"]
        elif load < self.HIGH_LOAD:
            # 高负荷：只保留核心
            self.current_state.active_skills = ["bionic-guard", "habit-loop"]
            self.current_state.suppressed_skills = ["self-talk", "swarm-intelligence", "bionic-reasoning"]
        else:
            # 临界：最小化
            self.current_state.active_skills = ["habit-loop"]
            self.current_state.suppressed_skills = ["self-talk", "swarm-intelligence", "bionic-reasoning", "bionic-cognition"]
    
    def _trigger_cooldown(self):
        """触发冷却"""
        self.current_state.consecutive_steps = 0
        self.current_state.last_recovery = datetime.now().isoformat()
        self.current_state.mode = "parasympathetic"
    
    def get_recommendation(self) -> str:
        """获取建议"""
        if self.current_state.load_percentage > self.CRITICAL_LOAD:
            return "建议拆分任务，当前认知负荷过高"
        elif self.current_state.consecutive_steps >= self.COOLDOWN_THRESHOLD:
            return "建议短暂休息，已连续高强度执行"
        return ""
    
    def is_skill_active(self, skill_name: str) -> bool:
        """检查技能是否激活"""
        if "all" in self.current_state.active_skills:
            return True
        return skill_name in self.current_state.active_skills


# 单例
_load_balancer_instance: Optional[LoadBalancer] = None


def get_load_balancer() -> LoadBalancer:
    global _load_balancer_instance
    if _load_balancer_instance is None:
        _load_balancer_instance = LoadBalancer()
    return _load_balancer_instance
