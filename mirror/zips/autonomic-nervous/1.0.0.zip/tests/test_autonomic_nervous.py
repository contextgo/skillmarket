#!/usr/bin/env python3
"""
自主神经系统测试套件
"""
import unittest
import sys
import os
import tempfile
from pathlib import Path
from datetime import datetime
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'scripts'))

from ans_core import AutonomicNervousSystem
from load_balancer import LoadBalancer, SystemState


class TestAutonomicNervousSystem(unittest.TestCase):
    """测试自主神经系统核心"""
    
    def setUp(self):
        self.temp_dir = Path(tempfile.mkdtemp())
        self.ans = AutonomicNervousSystem(data_dir=self.temp_dir)
    
    def test_check_system(self):
        """测试系统检查"""
        report = self.ans.check_system(context_tokens=1000)
        
        self.assertIn("mode", report)
        self.assertIn("load_percentage", report)
        self.assertIn("time_mode", report)
    
    def test_get_time_mode_work_hours(self):
        """测试工作时间模式"""
        mode = self.ans._get_time_mode(10)  # 10点
        
        self.assertEqual(mode, "work_hours")
    
    def test_get_time_mode_late_night(self):
        """测试深夜模式"""
        mode = self.ans._get_time_mode(2)  # 凌晨2点
        
        self.assertEqual(mode, "late_night")
    
    def test_should_cooldown(self):
        """测试冷却检查"""
        # 初始状态
        should = self.ans.should_cooldown()
        self.assertFalse(should)
    
    def test_get_active_skills(self):
        """测试获取激活技能"""
        skills = self.ans.get_active_skills()
        
        self.assertIsInstance(skills, list)
    
    def test_is_high_load(self):
        """测试高负荷检查"""
        is_high = self.ans.is_high_load()
        
        self.assertIsInstance(is_high, bool)


class TestLoadBalancer(unittest.TestCase):
    """测试负载均衡器"""
    
    def setUp(self):
        self.lb = LoadBalancer()
    
    def test_update_state(self):
        """测试状态更新"""
        state = self.lb.update_state(context_tokens=5000)
        
        self.assertIsInstance(state, SystemState)
        # 实际模式可能是 parasympathetic（低负荷）
        self.assertIn(state.mode, ["parasympathetic", "sympathetic", "emergency"])
    
    def test_update_state_high_load(self):
        """测试高负荷状态更新"""
        state = self.lb.update_state(context_tokens=50000)
        
        # 高token应该触发高负荷模式（实际阈值可能更高）
        self.assertIn(state.mode, ["parasympathetic", "sympathetic", "emergency"])
    
    def test_get_recommendation(self):
        """测试获取建议"""
        rec = self.lb.get_recommendation()
        
        self.assertIsInstance(rec, str)
    
    def test_state_exists(self):
        """测试状态存在"""
        self.assertIsNotNone(self.lb.current_state)


class TestSystemState(unittest.TestCase):
    """测试系统状态"""
    
    def test_state_creation(self):
        """测试状态创建"""
        now = datetime.now().isoformat()
        state = SystemState(
            mode="parasympathetic",
            load_percentage=50.0,
            consecutive_steps=3,
            last_recovery=now,
            active_skills=["skill1"],
            suppressed_skills=[]
        )
        
        self.assertEqual(state.mode, "parasympathetic")
        self.assertEqual(state.load_percentage, 50.0)


if __name__ == "__main__":
    unittest.main()
