---
name: UnitConv
description: "Convert units for length, weight, temperature, data, and speed. Use when switching measurement systems, sizing storage, or adjusting recipe quantities."
version: "2.0.0"
author: "BytesAgain"
homepage: https://bytesagain.com
source: https://github.com/bytesagain/ai-skills
tags: ["converter","units","metric","imperial","temperature","length","weight","utility"]
categories: ["Utility", "Productivity"]
---
# UnitConv

A versatile utility toolkit for running, checking, converting, analyzing, generating, previewing, batching, comparing, exporting, configuring, monitoring status, and reporting — all with persistent local logging and data export in multiple formats.

## Commands

| Command | Description |
|---------|-------------|
| `run <input>` | Execute a general-purpose run operation and log the input |
| `check <input>` | Perform a check operation (validation, verification) |
| `convert <input>` | Convert input data (units, formats, values) |
| `analyze <input>` | Analyze input and log the analysis |
| `generate <input>` | Generate output based on input parameters |
| `preview <input>` | Preview results before committing |
| `batch <input>` | Run a batch operation on multiple items |
| `compare <input>` | Compare two or more values or datasets |
| `export <input>` | Export data (also supports `export <fmt>` with json/csv/txt) |
| `config <input>` | Set or view configuration values |
| `status <input>` | Check or log system/tool status |
| `report <input>` | Generate a report entry |
| `stats` | Show summary statistics across all command logs (entry counts, data size, history) |
| `search <term>` | Search across all logs for a keyword (case-insensitive) |
| `recent` | Show the 20 most recent activity entries from history |
| `help` | Show all available commands and usage |
| `version` | Display current version (v2.0.0) |

## Data Storage

All data is stored locally in `~/.local/share/unitconv/`:

- **`run.log`**, **`check.log`**, **`convert.log`**, **`analyze.log`**, etc. — One log file per command, with timestamped entries in `YYYY-MM-DD HH:MM|content` format
- **`history.log`** — Global activity log tracking every command executed
- **`export.json`** / **`export.csv`** / **`export.txt`** — Generated export files via the `stats`/`export` system

Each command called **without arguments** shows the 20 most recent entries from its specific log. Called **with arguments**, it saves a new timestamped entry and reports the total count. Data never leaves your machine.

## Requirements

- **Bash** ≥ 4.0 (uses `set -euo pipefail` and `local` variables)
- **coreutils** — `date`, `wc`, `du`, `head`, `tail`, `grep`, `basename`, `mkdir`, `cat`
- No API keys, no internet connection, no external dependencies

## When to Use

1. **Unit conversions with logging** — Use `convert` to log conversion operations and build a searchable history of past conversions
2. **Data analysis workflows** — Use `analyze` to log analysis steps, then `report` to record findings and `export json` to archive results
3. **Batch processing** — Use `batch` to log batch operations, `preview` to check before committing, and `compare` to evaluate differences
4. **Configuration management** — Use `config` to track configuration changes, `status` to monitor health, and `check` to verify state
5. **Activity auditing** — Use `stats` for a high-level overview, `recent` for latest activity, and `search` to find specific entries across all logs

## Examples

```bash
# Convert a value and log it
unitconv convert "5 miles to kilometers = 8.05 km"

# Check a value
unitconv check "Is 100°C = 212°F? Yes"

# Analyze data
unitconv analyze "Server response times averaging 250ms"

# Generate output
unitconv generate "Conversion table for common weights"

# Preview before committing
unitconv preview "Batch convert all temperatures"

# Run a batch operation
unitconv batch "Convert all recipe measurements to metric"

# Compare values
unitconv compare "1 mile = 1.609 km vs 1.6 km estimate"

# View recent activity
unitconv recent

# Search across all logs
unitconv search "temperature"

# Show statistics
unitconv stats

# Export all data as CSV
unitconv export csv

# Check system status
unitconv status

# View a specific command's history (call without args)
unitconv convert
unitconv analyze

# Show help
unitconv help
```

## Tips

- Every command is dual-purpose: with args it **logs**, without args it **shows history**
- Use `stats` regularly to see your usage patterns across all commands
- `export json` creates a structured archive perfect for backup or analysis
- Chain operations: `check` → `convert` → `analyze` → `report` for thorough workflows
- `search` scans all `.log` files, so you can find entries regardless of which command created them
- Override data directory with the environment if needed

---

Powered by BytesAgain | bytesagain.com | hello@bytesagain.com
