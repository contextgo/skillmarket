#!/usr/bin/env python3
"""
小红书亲子游玩笔记 - 批量自动化工作流
一键完成：图片处理 + 文案生成
"""

import os
import sys
import json
import base64
from datetime import datetime
from PIL import Image, ImageEnhance, ImageFilter, ImageDraw
import numpy as np


class BatchWorkflow:
    """批量处理工作流"""
    
    def __init__(self, intensity=0.35):
        self.intensity = intensity
        self.results = []
    
    def process_images(self, image_paths, output_dir=None):
        """
        批量处理图片（支持文件路径或PIL Image对象）
        
        Args:
            image_paths: 图片路径列表或PIL Image对象列表
            output_dir: 输出目录
        
        Returns:
            处理后的图片路径列表或PIL Image对象列表
        """
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)
        
        processed_paths = []
        
        for i, img_input in enumerate(image_paths, 1):
            print(f"🖼️  正在处理第 {i}/{len(image_paths)} 张图片...")
            
            try:
                # 判断输入类型
                if isinstance(img_input, Image.Image):
                    # 输入是PIL Image对象（来自WorkBuddy内存）
                    processed_img = self.add_morning_sunlight_to_image(img_input)
                    if output_dir:
                        output_path = os.path.join(output_dir, f"sunlight_image_{i}.jpg")
                        processed_img.save(output_path, quality=95)
                        processed_paths.append(output_path)
                    else:
                        processed_paths.append(processed_img)
                    print(f"   ✅ 完成: 图片 {i}")
                else:
                    # 输入是文件路径
                    if output_dir:
                        filename = os.path.basename(img_input)
                        output_path = os.path.join(output_dir, f"sunlight_{filename}")
                    else:
                        base, ext = os.path.splitext(img_input)
                        output_path = f"{base}_sunlight{ext}"
                    
                    result_path = self.add_morning_sunlight(img_input, output_path)
                    processed_paths.append(result_path)
                    print(f"   ✅ 完成: {os.path.basename(result_path)}")
                
            except Exception as e:
                print(f"   ❌ 失败: {e}")
        
        return processed_paths
    
    def add_morning_sunlight_to_image(self, img):
        """
        直接处理PIL Image对象（用于WorkBuddy内存图片）
        
        Args:
            img: PIL Image对象
        
        Returns:
            处理后的PIL Image对象
        """
        # 转换为RGBA模式
        img = img.convert('RGBA')
        width, height = img.size
        
        # 创建阳光效果层
        sunlight = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(sunlight)
        
        # 光源位置：左上方45度
        light_x = int(width * 0.2)
        light_y = int(height * 0.15)
        
        # 创建径向渐变光晕
        max_radius = int(max(width, height) * 0.8)
        for r in range(max_radius, 0, -3):
            alpha = int(35 * self.intensity * (1 - r / max_radius))
            color = (255, 240, 200, alpha)
            draw.ellipse(
                [light_x - r, light_y - r, light_x + r, light_y + r],
                fill=color
            )
        
        # 添加光束效果
        beam_layers = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        beam_draw = ImageDraw.Draw(beam_layers)
        
        for angle in [-25, -10, 5, 20]:
            beam_end_x = light_x + int(max(width, height) * 0.85 * np.cos(np.radians(angle + 45)))
            beam_end_y = light_y + int(max(width, height) * 0.85 * np.sin(np.radians(angle + 45)))
            
            beam_alpha = int(20 * self.intensity)
            beam_draw.line(
                [(light_x, light_y), (beam_end_x, beam_end_y)],
                fill=(255, 245, 220, beam_alpha),
                width=int(max(width, height) * 0.06)
            )
        
        beam_layers = beam_layers.filter(ImageFilter.GaussianBlur(radius=25))
        sunlight = Image.alpha_composite(sunlight, beam_layers)
        
        # 合并阳光层与原图
        img_with_light = Image.alpha_composite(img, sunlight)
        img_rgb = img_with_light.convert('RGB')
        
        # 调整色温（偏暖）
        r, g, b = img_rgb.split()
        r = r.point(lambda i: min(255, int(i * 1.06)))
        b = b.point(lambda i: int(i * 0.94))
        img_warm = Image.merge('RGB', (r, g, b))
        
        # 增强对比度
        enhancer = ImageEnhance.Contrast(img_warm)
        img_contrast = enhancer.enhance(1.12)
        
        # 轻微增强清晰度
        enhancer = ImageEnhance.Sharpness(img_contrast)
        img_sharp = enhancer.enhance(1.15)
        
        # 添加暗角效果
        img_final = self.add_vignette_to_image(img_sharp, intensity=0.18)
        
        return img_final
    
    def add_vignette_to_image(self, image, intensity=0.18):
        """为PIL Image对象添加暗角效果"""
        width, height = image.size
        
        mask = Image.new('L', (width, height), 255)
        center_x, center_y = width // 2, height // 2
        max_dist = np.sqrt(center_x**2 + center_y**2)
        
        for y in range(0, height, 2):
            for x in range(0, width, 2):
                dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                factor = dist / max_dist
                darkness = int(255 * (1 - intensity * factor**2))
                mask.putpixel((x, y), darkness)
                if x + 1 < width:
                    mask.putpixel((x + 1, y), darkness)
                if y + 1 < height:
                    mask.putpixel((x, y + 1), darkness)
                    if x + 1 < width:
                        mask.putpixel((x + 1, y + 1), darkness)
        
        mask = mask.filter(ImageFilter.GaussianBlur(radius=min(width, height) // 12))
        return Image.composite(image, Image.new('RGB', (width, height), (0, 0, 0)), mask)
    
    def add_morning_sunlight(self, image_path, output_path):
        """
        为图片添加早上9点的阳光效果
        """
        # 打开图片
        img = Image.open(image_path).convert('RGBA')
        width, height = img.size
        
        # 创建阳光效果层
        sunlight = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        draw = ImageDraw.Draw(sunlight)
        
        # 光源位置：左上方45度
        light_x = int(width * 0.2)
        light_y = int(height * 0.15)
        
        # 创建径向渐变光晕
        max_radius = int(max(width, height) * 0.8)
        for r in range(max_radius, 0, -3):
            alpha = int(35 * self.intensity * (1 - r / max_radius))
            color = (255, 240, 200, alpha)
            draw.ellipse(
                [light_x - r, light_y - r, light_x + r, light_y + r],
                fill=color
            )
        
        # 添加光束效果
        beam_layers = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        beam_draw = ImageDraw.Draw(beam_layers)
        
        for angle in [-25, -10, 5, 20]:
            beam_end_x = light_x + int(max(width, height) * 0.85 * np.cos(np.radians(angle + 45)))
            beam_end_y = light_y + int(max(width, height) * 0.85 * np.sin(np.radians(angle + 45)))
            
            beam_alpha = int(20 * self.intensity)
            beam_draw.line(
                [(light_x, light_y), (beam_end_x, beam_end_y)],
                fill=(255, 245, 220, beam_alpha),
                width=int(max(width, height) * 0.06)
            )
        
        beam_layers = beam_layers.filter(ImageFilter.GaussianBlur(radius=25))
        sunlight = Image.alpha_composite(sunlight, beam_layers)
        
        # 合并阳光层与原图
        img_with_light = Image.alpha_composite(img, sunlight)
        img_rgb = img_with_light.convert('RGB')
        
        # 调整色温（偏暖）
        r, g, b = img_rgb.split()
        r = r.point(lambda i: min(255, int(i * 1.06)))
        b = b.point(lambda i: int(i * 0.94))
        img_warm = Image.merge('RGB', (r, g, b))
        
        # 增强对比度
        enhancer = ImageEnhance.Contrast(img_warm)
        img_contrast = enhancer.enhance(1.12)
        
        # 轻微增强清晰度
        enhancer = ImageEnhance.Sharpness(img_contrast)
        img_sharp = enhancer.enhance(1.15)
        
        # 添加暗角效果
        img_final = self.add_vignette(img_sharp, intensity=0.18)
        
        # 保存结果
        img_final.save(output_path, quality=95)
        
        return output_path
    
    def add_vignette(self, image, intensity=0.18):
        """添加暗角效果"""
        width, height = image.size
        
        mask = Image.new('L', (width, height), 255)
        center_x, center_y = width // 2, height // 2
        max_dist = np.sqrt(center_x**2 + center_y**2)
        
        # 使用更高效的渐变生成
        for y in range(0, height, 2):
            for x in range(0, width, 2):
                dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
                factor = dist / max_dist
                darkness = int(255 * (1 - intensity * factor**2))
                mask.putpixel((x, y), darkness)
                if x + 1 < width:
                    mask.putpixel((x + 1, y), darkness)
                if y + 1 < height:
                    mask.putpixel((x, y + 1), darkness)
                    if x + 1 < width:
                        mask.putpixel((x + 1, y + 1), darkness)
        
        mask = mask.filter(ImageFilter.GaussianBlur(radius=min(width, height) // 12))
        return Image.composite(image, Image.new('RGB', (width, height), (0, 0, 0)), mask)
    
    def generate_note(self, scene_info=None):
        """
        生成小红书文案
        """
        from text_generator import XiaohongshuTextGenerator
        
        generator = XiaohongshuTextGenerator()
        return generator.generate_full_note("park_slide", scene_info)
    
    def run_full_workflow(self, image_paths, scene_info=None, output_dir=None, verbose=True):
        """
        运行完整工作流（支持文件路径或PIL Image对象）
        
        Args:
            image_paths: 图片路径列表或PIL Image对象列表
            scene_info: 场景信息
            output_dir: 输出目录
            verbose: 是否打印详细日志
        
        Returns:
            处理结果字典
        """
        if verbose:
            print("="*60)
            print("🚀 小红书亲子游玩笔记 - 批量处理工作流")
            print("="*60)
            print()
        
        # 步骤1：处理图片
        if verbose:
            print("📸 步骤 1/2: 图片阳光效果处理")
            print("-"*60)
        processed_images = self.process_images(image_paths, output_dir)
        if verbose:
            print(f"✅ 图片处理完成: {len(processed_images)}/{len(image_paths)} 张")
            print()
        
        # 步骤2：生成文案
        if verbose:
            print("📝 步骤 2/2: 生成小红书文案")
            print("-"*60)
        note_content = self.generate_note(scene_info)
        if verbose:
            print("✅ 文案生成完成")
            print()
        
        # 汇总结果
        result = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "input_count": len(image_paths),
            "processed_count": len(processed_images),
            "processed_images": processed_images,
            "note": note_content
        }
        
        # 输出报告
        if verbose:
            self.print_report(result)
        
        return result
    
    def process_from_workbuddy(self, images, scene_description=None):
        """
        专为WorkBuddy小程序/微信对话框设计的处理接口
        
        Args:
            images: PIL Image对象列表（WorkBuddy传入的内存图片）
            scene_description: 用户提供的场景描述（可选）
        
        Returns:
            处理结果字典，包含处理后的图片和文案
        """
        # 解析场景信息
        scene_info = None
        if scene_description:
            scene_info = {
                "feature": scene_description,
                "park_name": "成都公园" if "成都" in scene_description else "",
            }
        
        # 运行工作流（不打印日志，返回结构化结果）
        result = self.run_full_workflow(
            image_paths=images,
            scene_info=scene_info,
            output_dir=None,
            verbose=False
        )
        
        return result
    
    def print_report(self, result):
        """打印处理报告"""
        print("="*60)
        print("📊 处理报告")
        print("="*60)
        print(f"处理时间: {result['timestamp']}")
        print(f"处理图片: {result['processed_count']}/{result['input_count']} 张")
        print()
        
        if result['processed_images']:
            print("📁 输出文件:")
            for img_path in result['processed_images']:
                print(f"   • {img_path}")
            print()
        
        print("📝 标题选项:")
        for i, title in enumerate(result['note']['titles'], 1):
            print(f"   {i}. {title}")
        print()
        
        print("="*60)
        print("✨ 所有处理完成！可以直接发布到小红书了~")
        print("="*60)


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='小红书亲子游玩笔记 - 批量自动化工作流')
    parser.add_argument('images', nargs='+', help='输入图片路径（支持多张）')
    parser.add_argument('-o', '--output', help='输出目录')
    parser.add_argument('-i', '--intensity', type=float, default=0.35,
                        help='阳光强度 (0.0-1.0, 默认0.35)')
    parser.add_argument('--scene-info', type=str,
                        help='场景信息JSON字符串')
    parser.add_argument('--save-report', type=str,
                        help='保存报告到文件')
    
    args = parser.parse_args()
    
    # 解析场景信息
    scene_info = None
    if args.scene_info:
        try:
            scene_info = json.loads(args.scene_info)
        except json.JSONDecodeError:
            print("警告：场景信息JSON解析失败，使用默认设置")
    
    # 运行工作流
    workflow = BatchWorkflow(intensity=args.intensity)
    result = workflow.run_full_workflow(args.images, scene_info, args.output)
    
    # 保存报告
    if args.save_report:
        with open(args.save_report, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"\n📄 详细报告已保存: {args.save_report}")


if __name__ == '__main__':
    main()
