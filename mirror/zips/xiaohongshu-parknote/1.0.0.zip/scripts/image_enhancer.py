#!/usr/bin/env python3
"""
小红书亲子游玩笔记 - 图片阳光效果增强器
为照片添加早上9点的自然阳光效果，提升层次感和高级感
"""

import os
import sys
from PIL import Image, ImageEnhance, ImageFilter, ImageDraw
import numpy as np


def add_morning_sunlight(image_path, output_path=None, intensity=0.35):
    """
    为图片添加早上9点的阳光效果
    
    Args:
        image_path: 输入图片路径
        output_path: 输出图片路径（默认为原图路径加_sunlight后缀）
        intensity: 阳光强度 (0.0-1.0)
    
    Returns:
        输出图片路径
    """
    if output_path is None:
        base, ext = os.path.splitext(image_path)
        output_path = f"{base}_sunlight{ext}"
    
    # 打开图片
    img = Image.open(image_path).convert('RGBA')
    width, height = img.size
    
    # 创建阳光效果层
    sunlight = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(sunlight)
    
    # 光源位置：左上方45度
    light_x = int(width * 0.2)
    light_y = int(height * 0.15)
    
    # 创建径向渐变光晕
    max_radius = int(max(width, height) * 0.8)
    for r in range(max_radius, 0, -2):
        alpha = int(40 * intensity * (1 - r / max_radius))
        color = (255, 240, 200, alpha)  # 温暖的阳光色
        draw.ellipse(
            [light_x - r, light_y - r, light_x + r, light_y + r],
            fill=color
        )
    
    # 添加光束效果
    beam_layers = Image.new('RGBA', (width, height), (0, 0, 0, 0))
    beam_draw = ImageDraw.Draw(beam_layers)
    
    # 绘制几条主要光束
    for angle in [-30, -15, 0, 15, 30]:
        beam_end_x = light_x + int(max(width, height) * 0.9 * np.cos(np.radians(angle + 45)))
        beam_end_y = light_y + int(max(width, height) * 0.9 * np.sin(np.radians(angle + 45)))
        
        beam_alpha = int(25 * intensity)
        beam_draw.line(
            [(light_x, light_y), (beam_end_x, beam_end_y)],
            fill=(255, 245, 220, beam_alpha),
            width=int(max(width, height) * 0.08)
        )
    
    # 模糊光束使其更自然
    beam_layers = beam_layers.filter(ImageFilter.GaussianBlur(radius=20))
    
    # 合并光束和光晕
    sunlight = Image.alpha_composite(sunlight, beam_layers)
    
    # 将阳光层与原图合并
    img_with_light = Image.alpha_composite(img, sunlight)
    
    # 转换为RGB进行后续调整
    img_rgb = img_with_light.convert('RGB')
    
    # 调整色温（偏暖）
    r, g, b = img_rgb.split()
    r = r.point(lambda i: min(255, int(i * 1.05)))  # 增强红色
    b = b.point(lambda i: int(i * 0.95))  # 减弱蓝色
    img_warm = Image.merge('RGB', (r, g, b))
    
    # 增强对比度
    enhancer = ImageEnhance.Contrast(img_warm)
    img_contrast = enhancer.enhance(1.15)
    
    # 轻微增强清晰度
    enhancer = ImageEnhance.Sharpness(img_contrast)
    img_sharp = enhancer.enhance(1.2)
    
    # 添加暗角效果（Vignette）
    img_final = add_vignette(img_sharp, intensity=0.2)
    
    # 保存结果
    img_final.save(output_path, quality=95)
    
    return output_path


def add_vignette(image, intensity=0.2):
    """
    为图片添加暗角效果
    
    Args:
        image: PIL Image对象
        intensity: 暗角强度 (0.0-1.0)
    
    Returns:
        处理后的图片
    """
    width, height = image.size
    
    # 创建暗角遮罩
    mask = Image.new('L', (width, height), 255)
    draw = ImageDraw.Draw(mask)
    
    # 计算中心点和最大距离
    center_x, center_y = width // 2, height // 2
    max_dist = np.sqrt(center_x**2 + center_y**2)
    
    # 创建径向渐变暗角
    for y in range(height):
        for x in range(width):
            dist = np.sqrt((x - center_x)**2 + (y - center_y)**2)
            factor = dist / max_dist
            # 边缘变暗，中心保持明亮
            darkness = int(255 * (1 - intensity * factor**2))
            mask.putpixel((x, y), darkness)
    
    # 模糊遮罩使其更自然
    mask = mask.filter(ImageFilter.GaussianBlur(radius=min(width, height) // 10))
    
    # 应用遮罩
    return Image.composite(image, Image.new('RGB', (width, height), (0, 0, 0)), mask)


def batch_process(input_dir, output_dir=None, intensity=0.35):
    """
    批量处理文件夹中的图片
    
    Args:
        input_dir: 输入文件夹路径
        output_dir: 输出文件夹路径（默认为input_dir/sunlight）
        intensity: 阳光强度
    
    Returns:
        处理后的文件列表
    """
    if output_dir is None:
        output_dir = os.path.join(input_dir, 'sunlight')
    
    os.makedirs(output_dir, exist_ok=True)
    
    processed_files = []
    valid_extensions = {'.jpg', '.jpeg', '.png', '.bmp', '.tiff', '.webp'}
    
    for filename in os.listdir(input_dir):
        ext = os.path.splitext(filename)[1].lower()
        if ext in valid_extensions:
            input_path = os.path.join(input_dir, filename)
            output_path = os.path.join(output_dir, filename)
            
            try:
                result_path = add_morning_sunlight(input_path, output_path, intensity)
                processed_files.append(result_path)
                print(f"✅ 已处理: {filename}")
            except Exception as e:
                print(f"❌ 处理失败 {filename}: {e}")
    
    return processed_files


if __name__ == '__main__':
    import argparse
    
    parser = argparse.ArgumentParser(description='为图片添加早晨阳光效果')
    parser.add_argument('input', help='输入图片路径或文件夹')
    parser.add_argument('-o', '--output', help='输出路径')
    parser.add_argument('-i', '--intensity', type=float, default=0.35, 
                        help='阳光强度 (0.0-1.0, 默认0.35)')
    parser.add_argument('-b', '--batch', action='store_true',
                        help='批量处理文件夹中的所有图片')
    
    args = parser.parse_args()
    
    if args.batch or os.path.isdir(args.input):
        results = batch_process(args.input, args.output, args.intensity)
        print(f"\n🎉 批量处理完成！共处理 {len(results)} 张图片")
        if args.output:
            print(f"📁 输出目录: {args.output}")
        else:
            print(f"📁 输出目录: {os.path.join(args.input, 'sunlight')}")
    else:
        result = add_morning_sunlight(args.input, args.output, args.intensity)
        print(f"🎉 处理完成！")
        print(f"📷 输出文件: {result}")
