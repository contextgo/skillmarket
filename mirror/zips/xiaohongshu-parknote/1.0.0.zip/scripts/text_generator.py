#!/usr/bin/env python3
"""
小红书亲子游玩笔记 - 文案生成器
根据场景自动生成小红书风格的标题和正文
"""

import random
import json
from datetime import datetime


class XiaohongshuTextGenerator:
    """小红书文案生成器"""
    
    def __init__(self):
        self.templates = self._load_templates()
    
    def _load_templates(self):
        """加载文案模板"""
        return {
            "titles": {
                "park_slide": [
                    "成都这个{park_adj}公园，娃玩到不想回家！{emoji}",
                    "藏在市区的宝藏公园｜{feature}🌈",
                    "周末遛娃新发现！这个公园太适合{activity}了{emoji}",
                    "{park_adj}遛娃圣地｜{highlight}✨",
                    "免费！成都这个公园让娃嗨玩一整天🎈",
                    "亲测好去处｜{park_name}的{feature}绝了！",
                    "成都妈妈必藏！{feature}的公园在这里{emoji}",
                ],
                "outdoor": [
                    "成都{distance}直达｜这个{place_adj}太适合带娃了！🚗",
                    "逃离城市！周末带娃来这里{activity}🌲",
                    "小众亲子游｜90%成都人不知道的{place_type}✨",
                    "{season}遛娃好去处｜{place_adj}推荐{emoji}",
                    "带娃去{activity}！成都周边这个{place_type}美翻了🌿",
                    "亲子一日游｜{place_name}攻略请收好📖",
                    "成都周边{distance}｜{feature}的秘境🌳",
                ],
                "general": [
                    "成都遛娃｜{highlight}的{place_type}{emoji}",
                    "{activity}好去处｜{park_adj}推荐✨",
                    "周末去哪儿？{feature}让娃开心一整天🎉",
                    "亲测分享｜成都{place_adj}打卡📍",
                ]
            },
            "openings": [
                "姐妹们！最近发现了一个{adj}的地方，赶紧来分享！",
                "带娃{activity}发现了这个{adj}的{place_type}，太惊喜了！",
                "周末不知道去哪儿？这个{adj}的{place_type}强烈推荐！",
                "又挖到一个宝藏遛娃地！{adj}还{feature}。",
                "亲测不踩雷！这个{place_type}真的{adj}。",
            ],
            "highlights": [
                "🎢 {feature}，娃玩得不亦乐乎",
                "🌳 {nature_feature}，空气超好",
                "📸 {photo_spot}，拍照超出片",
                "🍃 {facility}，设施很完善",
                "🎪 {activity}，适合{age_group}",
                "🌿 {green_space}，可以野餐",
                "🚗 {transport}，很方便",
                "🆓 {price_info}，性价比超高",
            ],
            "closings": [
                "总之是个{summary}的好地方，推荐给大家！记得点赞收藏哦～",
                "{activity}一整天，娃开心我也轻松！快带娃去打卡吧！",
                "这个{place_type}真的{adj}，成都的妈妈们快冲！",
                "周末遛娃不知道去哪儿？来这里准没错！",
                "喜欢的话记得关注我，持续分享成都遛娃好去处！",
            ],
            "hashtags": [
                "#成都遛娃", "#成都公园", "#亲子游玩", "#周末去哪儿",
                "#成都周边游", "#带娃日常", "#免费遛娃", "#户外亲子",
                "#成都生活", "#遛娃好去处", "#亲子时光", "#成都探店",
                "#带娃出行", "#成都旅游", "#亲子活动", "#周末遛娃"
            ]
        }
    
    def generate_titles(self, scene_type="park_slide", scene_info=None, count=3):
        """
        生成标题选项
        
        Args:
            scene_type: 场景类型 (park_slide/outdoor/general)
            scene_info: 场景信息字典
            count: 生成标题数量
        
        Returns:
            标题列表
        """
        scene_info = scene_info or {}
        templates = self.templates["titles"].get(scene_type, self.templates["titles"]["general"])
        
        # 填充模板变量
        variables = {
            "park_adj": random.choice(["宝藏", "神仙", "绝绝子", "超棒", "隐藏", "小众"]),
            "place_adj": random.choice(["神仙", "宝藏", "绝美", "小众", "治愈", "宝藏"]),
            "feature": scene_info.get("feature", random.choice([
                "超大草坪+彩色滑梯", "绝美湖景", "超大沙坑", "森林氧吧",
                "无动力设施", "亲子农场", "水上乐园"
            ])),
            "highlight": scene_info.get("highlight", random.choice([
                "超大滑梯", "绝美风景", "设施超全", "人少景美"
            ])),
            "activity": scene_info.get("activity", random.choice([
                "放电", "打卡", "嗨玩", "遛娃", "拍照", "撒欢"
            ])),
            "emoji": random.choice(["🎈", "✨", "🌈", "💕", "🎉", "🌟"]),
            "park_name": scene_info.get("park_name", "这个公园"),
            "place_name": scene_info.get("place_name", "这个地方"),
            "place_type": scene_info.get("place_type", random.choice(["公园", "遛娃地", "亲子乐园"])),
            "distance": scene_info.get("distance", random.choice(["1h", "40分钟", "半小时"])),
            "season": scene_info.get("season", "春夏"),
        }
        
        titles = []
        selected_templates = random.sample(templates, min(count, len(templates)))
        
        for template in selected_templates:
            try:
                title = template.format(**variables)
                titles.append(title)
            except KeyError:
                continue
        
        return titles[:count]
    
    def generate_content(self, scene_type="park_slide", scene_info=None):
        """
        生成正文内容
        
        Args:
            scene_type: 场景类型
            scene_info: 场景信息字典
        
        Returns:
            正文文本
        """
        scene_info = scene_info or {}
        
        # 构建场景变量
        variables = {
            "adj": random.choice(["超棒", "宝藏", "绝美", "小众", "神仙", "治愈"]),
            "activity": scene_info.get("activity", random.choice(["遛娃", "放电", "打卡", "玩"])),
            "place_type": scene_info.get("place_type", random.choice(["公园", "地方", "遛娃地"])),
            "feature": scene_info.get("feature", random.choice(["设施很全", "风景超美", "人很少"])),
            "nature_feature": scene_info.get("nature_feature", random.choice(["绿树成荫", "湖水清澈", "草坪超大"])),
            "photo_spot": scene_info.get("photo_spot", random.choice(["湖边", "草坪上", "滑梯旁"])),
            "facility": scene_info.get("facility", random.choice(["有厕所", "有休息区", "有餐饮"])),
            "age_group": scene_info.get("age_group", random.choice(["2-8岁", "全年龄段", "小朋友"])),
            "green_space": scene_info.get("green_space", random.choice(["大片草坪", "树荫下", "湖边草地"])),
            "transport": scene_info.get("transport", random.choice(["地铁直达", "停车方便", "公交可达"])),
            "price_info": scene_info.get("price_info", random.choice(["完全免费", "性价比超高", "门票便宜"])),
            "summary": scene_info.get("summary", random.choice(["值得N刷", "遛娃首选", "超治愈"])),
        }
        
        # 生成开头
        opening_template = random.choice(self.templates["openings"])
        opening = opening_template.format(**variables)
        
        # 生成地点介绍
        location_info = scene_info.get("location", {})
        location_text = self._generate_location_section(location_info)
        
        # 生成游玩亮点
        highlights = self._generate_highlights(variables)
        
        # 生成实用信息
        practical_info = self._generate_practical_info(scene_info)
        
        # 生成结尾
        closing_template = random.choice(self.templates["closings"])
        closing = closing_template.format(**variables)
        
        # 生成话题标签
        hashtags = self._generate_hashtags()
        
        # 组合正文
        content_parts = [
            opening,
            "",
            location_text,
            "",
            "【游玩亮点】",
            highlights,
            "",
            practical_info,
            "",
            closing,
            "",
            hashtags,
        ]
        
        return "\n".join(content_parts)
    
    def _generate_location_section(self, location_info):
        """生成地点介绍段落"""
        name = location_info.get("name", "这个宝藏公园")
        area = location_info.get("area", "成都市区")
        transport = location_info.get("transport", "地铁/自驾都很方便")
        
        return f"📍地点：{name}\n🗺️位置：{area}\n🚗交通：{transport}"
    
    def _generate_highlights(self, variables):
        """生成游玩亮点列表"""
        highlight_templates = self.templates["highlights"]
        selected = random.sample(highlight_templates, min(4, len(highlight_templates)))
        
        highlights = []
        for template in selected:
            try:
                highlight = template.format(**variables)
                highlights.append(highlight)
            except KeyError:
                continue
        
        return "\n".join(highlights)
    
    def _generate_practical_info(self, scene_info):
        """生成实用信息段落"""
        info = scene_info.get("practical", {})
        
        lines = ["【实用信息】"]
        
        ticket = info.get("ticket", "🎫 门票：免费")
        lines.append(ticket)
        
        hours = info.get("hours", "⏰ 开放时间：全天开放")
        lines.append(hours)
        
        parking = info.get("parking", "🅿️ 停车：路边可停/有停车场")
        lines.append(parking)
        
        facilities = info.get("facilities", "🍔 周边：有便利店/餐厅")
        lines.append(facilities)
        
        tips = info.get("tips", "💡 小贴士：建议早上去，人少空气好")
        lines.append(tips)
        
        return "\n".join(lines)
    
    def _generate_hashtags(self, count=10):
        """生成话题标签"""
        all_hashtags = self.templates["hashtags"]
        selected = random.sample(all_hashtags, min(count, len(all_hashtags)))
        return " ".join(selected)
    
    def generate_full_note(self, scene_type="park_slide", scene_info=None):
        """
        生成完整的笔记内容
        
        Returns:
            包含标题选项和正文的字典
        """
        titles = self.generate_titles(scene_type, scene_info, count=3)
        content = self.generate_content(scene_type, scene_info)
        
        return {
            "titles": titles,
            "content": content,
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }


def main():
    """命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='生成小红书文案')
    parser.add_argument('--scene', default='park_slide', 
                        choices=['park_slide', 'outdoor', 'general'],
                        help='场景类型')
    parser.add_argument('--info', type=str, 
                        help='场景信息JSON字符串')
    parser.add_argument('--output', type=str,
                        help='输出文件路径')
    
    args = parser.parse_args()
    
    # 解析场景信息
    scene_info = {}
    if args.info:
        try:
            scene_info = json.loads(args.info)
        except json.JSONDecodeError:
            print("警告：场景信息JSON解析失败，使用默认设置")
    
    # 生成文案
    generator = XiaohongshuTextGenerator()
    result = generator.generate_full_note(args.scene, scene_info)
    
    # 输出结果
    output_text = f"""
{'='*50}
📝 小红书笔记生成结果
{'='*50}

【标题选项】
"""
    for i, title in enumerate(result['titles'], 1):
        output_text += f"{i}. {title}\n"
    
    output_text += f"""
{'='*50}

【正文内容】
{result['content']}

{'='*50}
"""
    
    print(output_text)
    
    # 保存到文件
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(output_text)
        print(f"\n✅ 已保存到: {args.output}")
    
    # 同时输出JSON格式供程序调用
    print("\n📊 JSON格式输出：")
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
