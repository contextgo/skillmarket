#!/usr/bin/env node
import { tmrFetch, parseArgs } from "./_lib.mjs";

const { help, positional } = parseArgs(process.argv);
if (help || !positional[0]) {
  console.error("Usage: withdraw-proposal.mjs <session-id>");
  process.exit(2);
}

const data = await tmrFetch("POST", `/negotiations/${positional[0]}/withdraw`);
console.log(`Proposal withdrawn for session ${positional[0]} — status: ${data.status}`);
console.log(JSON.stringify(data, null, 2));
