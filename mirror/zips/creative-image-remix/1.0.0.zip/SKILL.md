---
name: creative-image-remix
description: "AI image creative remix studio — style transfer, reference-based creation, scene swap, series generation, style fusion, material conversion, era shift, composition restructure, lineart/coloring, IP/cartoon, ArtStation-style reference mapping. Triggers: 风格转换, style transfer, 转绘, 重绘, 风格迁移, 参考风格, 照着画, 仿照风格, 换风格, 吉卜力风, 赛博朋克, 水彩风, 像素风, 油画风, 3D黏土, 换背景, 换场景, 场景替换, 表情包, 系列图, 四季, 昼夜变化, 风格融合, style fusion, 混搭风格, 材质转换, 乐高风, 毛线风, 金属质感, 水晶质感, 玻璃质感, 年代穿越, 80年代, 复古风, 未来风, 中世纪, 构图重构, 横转竖, 竖转横, 全景图, 换视角, 线稿, 上色, 填色, sketch, lineart, coloring, IP化, 卡通化, Q版, 吉祥物, cartoon, chibi, mascot, 改图, remix image, restyle, image remix, 图片风格, 图片转换, 创意图, 帮我画, 重新画, 照着这个画, 画一个类似的, 把这张图变成, convert image style, image to image, img2img, ArtStation 风格, artstation.com, A站风格, 作品集质感, 概念设计风格"
description_zh: "AI 图像创意工坊 — 风格转换、参考再创作、场景替换、系列化扩展、风格融合、材质转换、年代穿越、构图重构、线稿互转、IP卡通化，并支持 ArtStation 风格参考映射。"
version: 1.1.0
allowed-tools: Read,Write,Bash,ImageGen
---

# 🎨 Creative Image Remix — AI 图像创意工坊

将一张图变出无限可能。十大创意能力，一个 skill 搞定。

---

## 能力总览

| # | 能力 | 命令关键词 | 简述 |
|---|------|-----------|------|
| 1 | 风格转换 | `style`, `风格` | 一键转换成不同艺术风格 |
| 2 | 参考再创作 | `reference`, `参考` | 参考原图风格，生成全新主体 |
| 3 | 场景替换 | `scene`, `场景`, `换背景` | 保留主体，替换环境 |
| 4 | 系列化扩展 | `series`, `系列`, `表情包` | 一图生多图（四季/昼夜/情绪） |
| 5 | 风格融合 | `fusion`, `融合`, `混搭` | 两张图的风格融合 |
| 6 | 材质转换 | `material`, `材质` | 变成乐高/毛线/金属/水晶等 |
| 7 | 年代穿越 | `era`, `年代`, `穿越` | 同主体不同时代呈现 |
| 8 | 构图重构 | `compose`, `构图`, `视角` | 改变画幅、视角、构图 |
| 9 | 线稿互转 | `lineart`, `线稿`, `上色` | 照片转线稿 / 线稿上色 |
| 10 | IP 卡通化 | `cartoon`, `IP`, `Q版`, `卡通` | 真实照片转卡通/Q版/吉祥物 |

---

## 通用工作流 (MUST FOLLOW)

### Phase 0: 意图识别

用户发来请求时，按以下顺序判断：

1. **有图 + 有明确指令** → 直接进入对应能力的 Phase 2（跳过询问）
2. **有图 + 意图模糊** → 进入 Phase 1 分析图片，给出建议选项
3. **无图 + 有描述** → 询问是否有参考图，没有则走纯文生图
4. **无图 + 无描述** → 引导用户描述需求或提供图片

### Phase 1: 图片分析 & 建议 (当需要时)

分析用户提供的图片，输出：

**若用户提到 `ArtStation` / `artstation.com` / `A站风格`**：
- 不把它理解成某一个具体作者的署名风格
- 先映射到 `references/artstation-style-reference.md` 中的常见专业方向（概念设计 / 场景设计 / 角色设计 / 风格化3D）
- 如果用户没说清楚，默认给出 3 个候选方向：概念设计向、作品集插画向、风格化3D向

```
📸 图片分析：
- 主体：[识别到的主要对象]
- 风格：[当前图片的艺术风格]
- 色调：[主要色彩倾向]
- 构图：[构图方式]
- 氛围：[整体氛围感受]

🎯 推荐创意方向（选一个或多个）：
1. [建议A] — [简要说明效果]
2. [建议B] — [简要说明效果]
3. [建议C] — [简要说明效果]
4. 🎨 自定义 — 告诉我你想要什么
```

### Phase 2: Prompt 构建 & 生成

根据用户选择，使用对应能力模块的 prompt 模板构建最终 prompt，调用 `image_gen` 生成。

**默认视觉规则（除非用户明确要求覆盖）**:
- 新生成的配图不要添加发光、外发光、投影、地面阴影或悬浮阴影效果
- 参考图即使存在发光或投影，也只学习其材质、构图、配色和风格语言，不直接复制这些特效

### Phase 3: 迭代优化

生成后询问：
- ✅ 满意 → 结束
- 🔄 微调 → 用户说调整点，重新生成
- ❌ 重来 → 回到 Phase 1

生成完成后，固定追加一句：
- "如果你需要，我可以继续使用 @skill://bg-removal 帮你去除背景。"

---

## 能力模块详细定义

---

### 1. 🎭 风格转换 (Style Transfer)

**触发词**: 风格转换、转绘、换风格、转成XX风、一键变风格、style transfer

**预置风格库** (参见 `references/style-dictionary.md`):

| 风格 | Prompt 关键词 |
|------|-------------|
| 吉卜力 | `Studio Ghibli style, anime, soft watercolor, warm pastoral, hand-drawn feel, Miyazaki aesthetic` |
| 赛博朋克 | `cyberpunk, neon lights, dark futuristic city, holographic, glitch art, high contrast` |
| 水彩 | `watercolor painting, soft edges, wet-on-wet technique, flowing pigments, paper texture` |
| 油画 | `oil painting, thick brushstrokes, impasto technique, rich colors, canvas texture, classical art` |
| 像素风 | `pixel art, 16-bit retro game style, limited color palette, crisp pixels, nostalgic` |
| 3D 黏土 | `3D clay render, Claymation style, soft rounded shapes, pastel colors, cute miniature` |
| 浮世绘 | `ukiyo-e style, Japanese woodblock print, flat color areas, bold outlines, Edo period` |
| 波普艺术 | `pop art, Andy Warhol style, bold colors, halftone dots, comic book aesthetic` |
| 蒸汽波 | `vaporwave aesthetic, pink and cyan, retro 80s, marble statues, glitch, grid` |
| 极简线条 | `minimalist line art, single continuous line, clean white background, elegant simplicity` |
| 漫画 | `manga style, Japanese comic, clean linework, screentone shading, dynamic poses` |
| 写实摄影 | `photorealistic, 8K, sharp detail, professional photography, natural lighting` |

**Prompt 模板**:
```
[TARGET_STYLE keywords], depicting [SUBJECT_DESCRIPTION from original image],
[COMPOSITION notes], [MOOD/ATMOSPHERE], [COLOR_PALETTE],
high quality, detailed, masterful execution
```

**工作流**:
1. 分析原图主体、构图、色调
2. 若用户未指定风格 → 推荐 3 个最适合的风格（附预览描述）
3. 用户选择后 → 构建 prompt → 生成
4. 可追加「保留XX元素」「加强XX感觉」等微调

---

### 2. 🖌️ 参考再创作 (Reference-based Creation)

**触发词**: 参考风格、照着画、仿照风格、画一个类似的、参考这张图画、reference style、ArtStation 风格、A站风格、artstation.com

**核心逻辑**: 提取原图的「风格DNA」（色调、笔触、氛围、光影），应用到全新主体上。

**ArtStation 参考模式**:
- 当用户要求“做成 ArtStation 风格”时，优先参考 `references/artstation-style-reference.md`
- 先判断是角色、场景、插画还是风格化 3D
- 再用“内容类型 + 题材 + 世界观 + 氛围标签”的方式拼装 prompt
- 默认生成“作品集级完成度 / 概念设计感 / 专业展示感”，而不是简单套一个模糊的站点名

**Prompt 模板**:
```
In the style of [EXTRACTED_STYLE: color palette, brush technique, lighting, mood],
create [NEW_SUBJECT_DESCRIPTION],
maintaining the same [artistic approach / color harmony / atmosphere],
[ADDITIONAL_DETAILS], high quality, cohesive style
```

**工作流**:
1. 深度分析原图风格 DNA：
   - 色彩体系（暖/冷、饱和度、主色调）
   - 笔触/渲染方式（细腻/粗犷/平涂/渐变）
   - 光影处理（自然光/戏剧光/平面光）
   - 氛围关键词
2. 输出风格摘要给用户确认
3. 用户描述新主体 → 融合风格 DNA → 生成

---

### 3. 🌍 场景替换 (Scene Swap)

**触发词**: 换背景、换场景、场景替换、把TA放到XX、换个环境

**Prompt 模板**:
```
[SUBJECT_DESCRIPTION] in [NEW_SCENE/ENVIRONMENT],
[LIGHTING_MATCHING], [PERSPECTIVE_MATCHING],
maintaining the subject's [KEY_FEATURES: clothing, pose, expression],
seamless integration, natural composition, [QUALITY_TAGS]
```

**预置场景**:
- 🏙️ 赛博都市 / 🌸 樱花小径 / 🏔️ 雪山之巅 / 🌊 海边落日
- 🚀 太空舱内 / 🏛️ 古希腊神殿 / 🌲 魔法森林 / 🎪 霓虹游乐场
- 📖 书中世界 / ☁️ 云端之上 / 🔬 微观世界 / 🎭 舞台聚光灯下

**工作流**:
1. 识别原图主体特征
2. 若用户未指定场景 → 推荐 3~5 个反差感强的场景
3. 注意光影一致性提示（新场景光源方向需匹配主体）

---

### 4. 📚 系列化扩展 (Series Generation)

**触发词**: 系列图、表情包、四季、昼夜变化、一套图、批量生成、情绪变化

**系列维度**:

| 维度 | 变体 | 适用场景 |
|------|------|---------|
| 四季 | 春/夏/秋/冬 | 风景、建筑、人物穿搭 |
| 昼夜 | 黎明/正午/黄昏/深夜 | 城市、风景 |
| 情绪 | 开心/悲伤/愤怒/惊讶/无聊/兴奋 | 人物、IP、表情包 |
| 天气 | 晴/雨/雪/雾/雷暴 | 风景、建筑 |
| 成长 | 幼年/少年/青年/中年/老年 | 人物、生物 |
| 元素 | 火/水/冰/雷/风 | 角色、特效 |

**Prompt 模板** (每张):
```
[BASE_SUBJECT_DESCRIPTION], [SERIES_DIMENSION: specific variant],
[VARIANT_SPECIFIC_DETAILS: lighting, colors, mood, accessories],
consistent character design, same art style throughout, [QUALITY_TAGS]
```

**工作流**:
1. 确认基础主体
2. 选择系列维度 → 展示将要生成的变体清单
3. 用户确认 → 逐张生成（每张 prompt 在基础上加入变体差异）
4. 强调一致性：同一角色/主体外观保持统一

---

### 5. 🧬 风格融合 (Style Fusion)

**触发词**: 风格融合、混搭、两种风格合一、style fusion、A+B风格

**核心逻辑**: 从图A提取风格X，从图B提取风格Y，融合生成第三种独特风格。

**Prompt 模板**:
```
A creative fusion of [STYLE_A: key characteristics] and [STYLE_B: key characteristics],
depicting [SUBJECT],
blending [A's color palette] with [B's texture/technique],
combining [A's mood] and [B's composition approach],
unique hybrid aesthetic, harmonious blend, [QUALITY_TAGS]
```

**工作流**:
1. 分别分析两张图的风格特征
2. 输出融合方案预览：
   ```
   🧬 风格融合方案：
   图A 贡献：[色彩体系 / 氛围 / ...]
   图B 贡献：[笔触 / 构图 / ...]
   融合预期：[描述融合后的效果]
   ```
3. 用户确认或调整权重 → 生成

---

### 6. 💎 材质转换 (Material Conversion)

**触发词**: 材质转换、乐高风、毛线风、金属质感、水晶、玻璃、木雕、纸艺

**预置材质**:

| 材质 | Prompt 关键词 |
|------|-------------|
| 乐高 | `LEGO brick build, blocky construction, plastic texture, colorful bricks, toy aesthetic` |
| 毛线 | `knitted yarn art, crochet texture, soft wool, warm cozy feel, handcraft aesthetic` |
| 金属 | `polished metal sculpture, chrome finish, reflective surface, industrial, sleek` |
| 水晶 | `crystal sculpture, transparent, light refraction, prismatic colors, gemstone quality` |
| 玻璃 | `blown glass art, translucent, smooth surface, delicate, Murano glass style` |
| 木雕 | `wooden carving, woodgrain texture, traditional craft, warm tones, hand-carved detail` |
| 纸艺 | `paper craft, origami, layered paper cut, kirigami, delicate folds, paper texture` |
| 冰雕 | `ice sculpture, frozen, translucent blue, cold environment, crystalline detail` |
| 黄金 | `solid gold sculpture, 24K gold, luxurious, gleaming, ornate detail, precious metal` |
| 气球 | `balloon art, inflated latex, shiny surface, balloon animal style, playful, party aesthetic` |

**Prompt 模板**:
```
[SUBJECT_DESCRIPTION] made entirely of [MATERIAL],
[MATERIAL_SPECIFIC_DETAILS: texture, reflections, physical properties],
[LIGHTING_FOR_MATERIAL], studio photography, [QUALITY_TAGS]
```

---

### 7. ⏳ 年代穿越 (Era Shift)

**触发词**: 年代穿越、80年代、复古、未来、中世纪、穿越时空、不同时代

**预置年代**:

| 年代 | Prompt 关键词 |
|------|-------------|
| 远古 | `prehistoric era, cave painting style, primitive, earth tones, ancient` |
| 古埃及 | `ancient Egyptian style, hieroglyphics, gold and lapis lazuli, pharaoh aesthetic` |
| 中世纪 | `medieval style, illuminated manuscript, Gothic architecture, knight era` |
| 文艺复兴 | `Renaissance painting, classical composition, chiaroscuro, oil on canvas, 15th century` |
| 1920s | `Art Deco, roaring twenties, jazz age, geometric patterns, gold and black, glamour` |
| 1960s | `1960s mod style, psychedelic, flower power, bold patterns, retro` |
| 1980s | `1980s aesthetic, synthwave, neon, VHS, Memphis design, retro-futuristic` |
| 2000s | `Y2K aesthetic, early digital, chrome, bubbly design, millennium style` |
| 近未来 | `near future, 2050, sleek technology, holographic, minimalist sci-fi` |
| 远未来 | `far future, 3000 AD, post-human, alien technology, cosmic scale, transcendent` |

**Prompt 模板**:
```
[SUBJECT_DESCRIPTION] reimagined in the [TARGET_ERA],
[ERA_SPECIFIC_VISUAL_LANGUAGE], [PERIOD_APPROPRIATE_DETAILS],
[COLOR_PALETTE_OF_ERA], authentic period feel, [QUALITY_TAGS]
```

---

### 8. 📐 构图重构 (Composition Restructure)

**触发词**: 构图重构、横转竖、竖转横、全景图、换视角、鸟瞰、仰视、特写

**构图选项**:

| 构图 | 说明 | Prompt 关键词 |
|------|------|-------------|
| 特写 | 聚焦细节 | `extreme close-up, macro detail, shallow depth of field` |
| 中景 | 半身/环境 | `medium shot, environmental portrait, balanced composition` |
| 全景 | 宏大场景 | `wide panoramic view, landscape orientation, vast scale` |
| 鸟瞰 | 俯视 | `bird's eye view, top-down perspective, aerial photography` |
| 虫视 | 仰视 | `worm's eye view, low angle, dramatic perspective, looking up` |
| 对称 | 中轴对称 | `symmetrical composition, centered, mirror-like balance` |
| 三分法 | 经典构图 | `rule of thirds, off-center subject, balanced negative space` |
| 框中框 | 自然取景框 | `frame within frame, natural framing, doorway/window composition` |

**Prompt 模板**:
```
[SUBJECT_DESCRIPTION], [NEW_COMPOSITION_TYPE],
[PERSPECTIVE_DETAILS], [ASPECT_RATIO_HINT],
[DEPTH_AND_FOCUS_DETAILS], cinematic composition, [QUALITY_TAGS]
```

**画幅映射** (用于 image_gen size 参数):
- 横幅/全景 → `1536x1024`
- 竖幅/手机屏 → `1024x1536`
- 正方形/社交媒体 → `1024x1024`

---

### 9. ✏️ 线稿互转 (Lineart ↔ Color)

**触发词**: 线稿、上色、填色、sketch、lineart、coloring、黑白线条、涂色

**两个方向**:

#### 9A: 照片/彩图 → 线稿
```
Clean line art drawing of [SUBJECT_DESCRIPTION],
black ink on white background, [LINE_STYLE: thin/bold/varied weight],
no color, no shading, [DETAIL_LEVEL: minimal/detailed/architectural],
suitable for coloring book, crisp lines
```

**线条风格选项**:
- 简约线条（适合涂色本）
- 建筑制图（精确、硬朗）
- 漫画线条（粗细变化、动感）
- 装饰线条（繁复花纹）

#### 9B: 线稿 → 上色
```
Fully colored and shaded illustration based on this line drawing,
[COLOR_STYLE: watercolor/digital/cel-shaded/realistic],
[COLOR_PALETTE_DESCRIPTION], [LIGHTING_DIRECTION],
maintaining the original line work, vibrant and polished, [QUALITY_TAGS]
```

**上色风格选项**:
- 水彩晕染
- 数字平涂（动画风）
- 赛璐璐（日本动画）
- 写实渲染

---

### 10. 🧸 IP 卡通化 (Character IP / Cartoonify)

**触发词**: IP化、卡通化、Q版、吉祥物、chibi、cartoon、mascot、可爱版

**卡通化等级**:

| 等级 | 风格 | Prompt 关键词 |
|------|------|-------------|
| 轻度 | 略微卡通化，保留辨识度 | `slightly stylized portrait, soft features, illustration style` |
| 中度 | 明显卡通，大眼圆脸 | `cartoon character, animated style, expressive features, vibrant` |
| Q版 | 大头小身，2~3头身 | `chibi style, 2-head-tall proportion, super deformed, kawaii, cute` |
| 吉祥物 | 圆润简洁，适合品牌 | `mascot design, simple shapes, friendly, approachable, brand-safe` |
| 像素角色 | 游戏风格像素小人 | `pixel art character, 32x32 sprite, retro game character, 8-bit` |

**Prompt 模板**:
```
[CARTOON_LEVEL] version of [SUBJECT_DESCRIPTION],
[SPECIFIC_STYLE_KEYWORDS], [EXPRESSION: cheerful/cool/determined],
[BACKGROUND: simple/themed/none],
consistent design suitable for IP/branding, [QUALITY_TAGS]
```

**工作流**:
1. 分析原图人物/对象特征（五官、发型、服饰、标志性元素）
2. 推荐 2~3 个卡通化等级预览
3. 用户选择 → 生成 → 可追加多表情/多姿势系列

---

## Prompt 工程通用规则

### 质量控制词 (按需添加)
```
高质量通用: high quality, detailed, masterful, professional
写实向: 8K, photorealistic, sharp focus, professional photography, RAW photo
插画向: beautiful illustration, artstation trending, detailed artwork
3D向: 3D render, octane render, cinema 4D, physically based rendering
```

### 负面提示词 (心里有数，构建 prompt 时规避)
```
避免: blurry, low quality, distorted, deformed, ugly, bad anatomy,
      watermark, text overlay, cropped, out of frame
```

### Prompt 结构公式
```
[STYLE/MEDIUM] + [SUBJECT] + [ACTION/POSE] + [ENVIRONMENT/SCENE] +
[LIGHTING] + [COLOR PALETTE] + [MOOD/ATMOSPHERE] + [QUALITY TAGS]
```

---

## 多能力组合 (高级用法)

用户可以组合多个能力，例如：
- 「把这张照片转成吉卜力风，然后做一套四季系列」= 风格转换 + 系列化
- 「参考这张图的风格，画一只猫，做成乐高版」= 参考再创作 + 材质转换
- 「把这张竖图改成横幅全景，然后转水彩风」= 构图重构 + 风格转换

**处理组合请求时**：按依赖顺序逐步执行，每步确认后再进入下一步。

---

## 交互语气

- 分析图片时像一个有审美品位的艺术总监
- 给建议时给出具体的视觉描述，让用户能「脑补」效果
- 生成前用一句话总结即将生成的效果
- 不满意时积极引导微调方向，而非简单重复
