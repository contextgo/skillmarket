# Examples · Creative Image Remix

本目录提供 3 组实战案例，展示 Creative Image Remix 的「参考再创作」能力。

## 快速预览

在浏览器打开 `showcase.html` 即可看到完整案例对比页面（左侧参考图 → 右侧 AI 生成图）。

## 案例清单

| # | 参考风格 | 原图主体 | 生成主体 | 能力 |
|---|---------|---------|---------|------|
| 01 | 毛绒挂件 / 吉祥物 | 鸭吉吉 | 狗狗 | 参考再创作 |
| 02 | 8-bit / 16-bit 像素 | 柯基 | 老虎 | 风格迁移 |
| 03 | 赛博朋克机甲 | 龙虾 | 螃蟹 | 风格迁移 |

## 目录结构

```
examples/
├── showcase.html      # 案例展示页（在浏览器打开即可）
├── README.md          # 本文件
└── assets/            # 案例图（6 张，每组 2 张：参考 + 生成）
    ├── ref-duck.png   ref-corgo.png   ref-lobster.png
    └── gen-dog.png    gen-tiger.png   gen-crab.png
```

## 复现方法

对着 skill 说话即可触发，例如：

- **Case 01** — 「参考这张毛绒挂件，帮我画一只狗」
- **Case 02** — 「参考这个像素风，画一只老虎」
- **Case 03** — 「参考这只机甲龙虾的风格，帮我画一只螃蟹」

Skill 会自动分析参考图的风格 DNA（色彩、笔触、氛围、轮廓语言），并把同样的风格应用到你指定的新主体上。
