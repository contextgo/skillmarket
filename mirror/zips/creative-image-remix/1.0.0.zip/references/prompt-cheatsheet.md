# 📝 Prompt Engineering Cheatsheet

构建高质量 image_gen prompt 的速查手册。

---

## 黄金公式

```
[MEDIUM/STYLE] of [SUBJECT] [ACTION/STATE],
in [ENVIRONMENT/SETTING],
[LIGHTING], [COLOR PALETTE], [MOOD/ATMOSPHERE],
[CAMERA/COMPOSITION], [QUALITY TAGS]
```

### 各段说明

| 段落 | 作用 | 示例 |
|------|------|------|
| Medium/Style | 定义整体艺术方向 | `oil painting`, `digital illustration`, `3D render` |
| Subject | 画面主体 | `a young woman with short black hair wearing a red scarf` |
| Action/State | 主体动作或状态 | `standing at the edge of a cliff`, `reading a book` |
| Environment | 场景环境 | `in a misty bamboo forest`, `on a neon-lit street` |
| Lighting | 光影 | `golden hour sunlight`, `dramatic Rembrandt lighting` |
| Color Palette | 色调 | `warm earth tones`, `cool blue and silver palette` |
| Mood | 氛围 | `peaceful and contemplative`, `energetic and vibrant` |
| Camera | 视角构图 | `wide angle`, `close-up portrait`, `bird's eye view` |
| Quality | 质量控制 | `8K, highly detailed, masterful, professional` |

---

## 质量控制词分级

### Tier 1: 通用高质量
```
high quality, detailed, professional, well-crafted
```

### Tier 2: 写实/摄影向
```
8K resolution, photorealistic, ultra-detailed, sharp focus,
professional photography, DSLR quality, RAW photo, natural lighting
```

### Tier 3: 插画/艺术向
```
beautiful illustration, artstation quality, trending on artstation,
detailed artwork, masterpiece, best quality
```

### Tier 4: 3D 渲染向
```
3D render, octane render, unreal engine 5, physically based rendering,
cinema 4D, ray tracing, global illumination, subsurface scattering
```

---

## 常见陷阱与解决

| 问题 | 原因 | 解决方法 |
|------|------|---------|
| 图片模糊 | 缺少质量词 | 添加 `sharp, detailed, high resolution` |
| 风格不明显 | 风格词太少或位置靠后 | 风格词放最前面，增加具体描述 |
| 多个主体混乱 | 描述不够具体 | 明确主体层级，用 `in the foreground/background` 区分 |
| 颜色不对 | 颜色描述太笼统 | 用具体色名+场景，如 `warm amber sunset tones` |
| 构图不好 | 没指定构图 | 明确添加构图词如 `centered composition, rule of thirds` |
| 风格混杂 | 堆了太多矛盾词 | 减少关键词，保持风格一致性 |

---

## Size 选择指南

| 场景 | 推荐尺寸 | image_gen size |
|------|---------|----------------|
| 方形头像/社交媒体 | 1:1 | `1024x1024` |
| 横幅/风景/桌面壁纸 | 3:2 | `1536x1024` |
| 竖幅/手机壁纸/海报 | 2:3 | `1024x1536` |
| 默认 | 1:1 | `1024x1024` |

---

## 风格强度控制

想要**更强**的风格化效果：
- 在风格词后加 `style, aesthetic, inspired by [ARTIST]`
- 重复风格的核心视觉特征
- 添加具体的视觉细节描述

想要**更弱**的风格化效果（更接近原图）：
- 减少风格词数量
- 添加 `subtle`, `hint of`, `slightly influenced by`
- 增加写实/摄影类关键词来「稀释」风格
