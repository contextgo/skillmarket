# ArtStation 风格参考词库

> 用途：当用户说“做成 ArtStation 风格”“参考 artstation.com 的感觉”“像 ArtStation 上那类作品”时，不把它理解成单一画师风格，而是映射为 ArtStation 平台上常见的专业视觉方向组合。

## 使用原则

1. 优先提炼平台常见方向，而不是点名模仿某个具体作者。
2. 先判断用户要的是：角色、场景、插画、还是风格化 3D。
3. 再从下方词库里组合“题材 + 风格 + 氛围 + 呈现方式”。
4. 默认延续用户既有规则：不要自动加发光、外发光、投影、阴影效果。

## 四大主方向

| 方向 | 适用场景 | 核心关键词 |
|------|----------|-----------|
| Concept Art 概念设计 | 世界观设定、关键帧、影视/游戏前期探索 | `concept art`, `visual development`, `keyframe`, `worldbuilding`, `mood painting`, `color script` |
| Environment 场景设计 | 地图、主城、地牢、遗迹、自然场景 | `environment design`, `landscape`, `background art`, `architecture`, `cityscape`, `interior`, `exterior` |
| Character 角色设计 | 英雄、怪物、NPC、装备、立绘 | `character design`, `costume design`, `armor design`, `weapon design`, `portrait`, `turnaround` |
| Stylized 3D 风格化三维 | 游戏道具、Q版角色、风格化场景、diorama | `stylized 3D`, `hand-painted 3D`, `game art`, `props`, `diorama`, `lookdev`, `render` |

## 视觉风格标签

### 造型风格
- `stylized`
- `semi-realistic`
- `realistic`
- `painterly`
- `graphic`
- `anime-inspired`
- `cartoon-inspired`
- `hand-painted`
- `cel-shaded`

### 世界观标签
- `fantasy`
- `dark fantasy`
- `high fantasy`
- `sci-fi`
- `cyberpunk`
- `steampunk`
- `post-apocalyptic`
- `medieval`
- `gothic`

### 氛围标签
- `cinematic`
- `moody`
- `atmospheric`
- `dramatic`
- `epic`
- `whimsical`
- `colorful`
- `muted palette`
- `gritty`

## 常用组合模板

### 1. ArtStation 角色概念图
```text
ArtStation-quality character concept art, [world setting], [subject],
[stylized or semi-realistic], strong silhouette, costume design focus,
clean material separation, presentation-ready, highly polished
```

### 2. ArtStation 场景概念图
```text
ArtStation-quality environment concept art, [scene], [world setting],
cinematic composition, strong depth layers, readable focal hierarchy,
production-level visual development, highly polished
```

### 3. ArtStation 风格化 3D 游戏图
```text
ArtStation-quality stylized 3D game art, [subject], hand-painted feel,
clean shapes, readable forms, game-ready lookdev, polished render,
rich material definition, professional portfolio presentation
```

### 4. ArtStation 插画 / Key Visual
```text
ArtStation-quality fantasy illustration, [subject or scene],
cinematic storytelling, portfolio-grade finish, dynamic composition,
high visual impact, polished details
```

## 检索/映射建议

当用户提“ArtStation 风格”但没说细分方向时，优先给 3 个备选：

1. **概念设计向**：更像游戏前期设定图，强调世界观和设计感
2. **作品集插画向**：更完整、更有冲击力，像宣传图/Key Visual
3. **风格化 3D 向**：更像游戏资产展示，形体清晰、材质明确

## Prompt 拼装公式

```text
ArtStation-quality + [内容类型] + [题材] + [世界观] + [造型风格] + [氛围标签] + [呈现方式]
```

示例：
```text
ArtStation-quality environment concept art, fantasy strategy game castle frontier,
medieval worldbuilding, semi-realistic, cinematic, atmospheric,
production-level visual development, highly polished, no glow, no drop shadow
```
