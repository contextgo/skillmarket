# 🎨 Style Dictionary — 风格词库速查手册

本文档是 `creative-image-remix` skill 的风格 prompt 关键词参考库。
AI 在构建 prompt 时应查阅此文件，选取最合适的关键词组合。

---

## 1. 艺术流派 (Art Movements)

### 东方
| 风格 | 英文关键词 | 视觉特征 |
|------|-----------|---------|
| 水墨画 | `Chinese ink wash painting, sumi-e, xuan paper, black ink, minimalist brushwork` | 留白、墨色浓淡、毛笔笔触 |
| 工笔画 | `Chinese gongbi painting, meticulous brushwork, fine detail, silk painting, mineral pigments` | 精细线条、矿物颜料、工整 |
| 浮世绘 | `ukiyo-e, Japanese woodblock print, flat colors, bold outlines, Edo period, Hokusai style` | 平涂、粗轮廓、浪花纹样 |
| 敦煌壁画 | `Dunhuang mural style, Tang dynasty art, Buddhist art, mineral colors, flying apsaras` | 飞天、矿物色、金粉 |

### 西方经典
| 风格 | 英文关键词 | 视觉特征 |
|------|-----------|---------|
| 文艺复兴 | `Renaissance painting, classical composition, chiaroscuro, sfumato, oil on wood panel` | 明暗对比、透视法、宗教题材 |
| 巴洛克 | `Baroque painting, dramatic lighting, rich colors, dynamic composition, Caravaggio style` | 戏剧光影、奢华、动态 |
| 印象派 | `Impressionist painting, visible brushstrokes, light effects, plein air, Monet style` | 可见笔触、光影变化、户外 |
| 后印象派 | `Post-Impressionist, bold colors, geometric forms, Van Gogh swirls, Cézanne structure` | 大胆色彩、几何形态 |
| 表现主义 | `Expressionism, distorted forms, intense colors, emotional, Munch style` | 变形、强烈情绪、不安 |
| 超现实主义 | `Surrealism, dreamlike, impossible scenes, Dalí melting clocks, Magritte paradox` | 梦境、不可能场景 |
| 立体主义 | `Cubism, fragmented forms, multiple perspectives, Picasso style, geometric abstraction` | 碎片化、多角度 |

### 现当代
| 风格 | 英文关键词 | 视觉特征 |
|------|-----------|---------|
| 波普艺术 | `Pop Art, Andy Warhol, bold colors, halftone dots, consumer culture, screen print` | 鲜艳、网点、商业化 |
| 极简主义 | `Minimalism, simple forms, limited palette, negative space, clean lines, reductive` | 极简、大面积留白 |
| 抽象表现 | `Abstract Expressionism, action painting, color field, Pollock drip, Rothko blocks` | 泼洒、色块、非具象 |
| 街头涂鸦 | `street art, graffiti, spray paint, Banksy style, urban wall, stencil art` | 喷漆、城市墙面、反叛 |

---

## 2. 数字/现代风格 (Digital & Modern)

| 风格 | 英文关键词 | 视觉特征 |
|------|-----------|---------|
| 赛博朋克 | `cyberpunk, neon glow, dark futuristic, holographic, rain-soaked streets, Blade Runner` | 霓虹、暗色、未来都市 |
| 蒸汽波 | `vaporwave, pink and cyan gradient, retro 80s, marble bust, Japanese text, grid` | 粉紫渐变、复古、网格 |
| 蒸汽朋克 | `steampunk, Victorian era, brass gears, copper pipes, clockwork, goggles` | 齿轮、黄铜、维多利亚 |
| 合成波 | `synthwave, retrowave, sunset gradient, chrome, DeLorean, neon grid, 1980s` | 落日渐变、霓虹网格 |
| 低多边形 | `low poly art, geometric facets, triangular mesh, 3D render, flat shading` | 三角面片、几何感 |
| 等距像素 | `isometric pixel art, diorama, tiny world, detailed miniature, 16-bit` | 等距视角、微缩世界 |
| Glitch Art | `glitch art, data corruption, pixel sorting, RGB shift, digital distortion` | 数据错误、RGB偏移 |
| 酸性设计 | `acid graphics, Y2K, chrome 3D text, warped shapes, rave aesthetic, toxic green` | 液态金属、扭曲、酸性色 |

---

## 3. 插画风格 (Illustration Styles)

| 风格 | 英文关键词 | 适用场景 |
|------|-----------|---------|
| 吉卜力 | `Studio Ghibli, anime, soft watercolor sky, pastoral, hand-drawn, Miyazaki, warm lighting` | 温暖日常、自然风景 |
| 新海诚 | `Makoto Shinkai style, detailed sky, lens flare, vivid colors, photorealistic anime background` | 都市风景、天空 |
| 迪士尼 | `Disney animation style, expressive characters, vibrant, storybook, magical` | 角色设计、童话 |
| 扁平插画 | `flat illustration, vector style, simple shapes, limited palette, editorial illustration` | UI/商业插画 |
| 儿童绘本 | `children's book illustration, whimsical, soft colors, friendly characters, storybook` | 童话、儿童内容 |
| 概念艺术 | `concept art, digital painting, cinematic, matte painting, environment design` | 场景设定、影视 |
| 暗黑奇幻 | `dark fantasy illustration, gothic, dramatic lighting, detailed armor, epic scale` | 游戏、奇幻题材 |
| 线条插画 | `line illustration, ink drawing, fine lines, cross-hatching, editorial style` | 编辑/杂志插图 |

---

## 4. 摄影风格 (Photography Styles)

| 风格 | 英文关键词 |
|------|-----------|
| 人像大片 | `portrait photography, 85mm lens, bokeh, studio lighting, professional, editorial` |
| 胶片感 | `film photography, Kodak Portra 400, grain, warm tones, analog, 35mm` |
| 黑白摄影 | `black and white photography, high contrast, monochrome, dramatic shadows, Ansel Adams` |
| 微距摄影 | `macro photography, extreme close-up, shallow DOF, water droplets, detailed texture` |
| 航拍 | `aerial photography, drone view, bird's eye, landscape, DJI, vast scale` |
| 长曝光 | `long exposure photography, light trails, silky water, star trails, night` |
| 双重曝光 | `double exposure photography, overlay, transparent layers, dreamy, composite` |
| 移轴 | `tilt-shift photography, miniature effect, selective focus, toy-like, urban` |

---

## 5. 材质关键词库 (Material Keywords)

| 材质 | 核心关键词 | 光影提示 |
|------|-----------|---------|
| 乐高 | `LEGO bricks, plastic ABS texture, snap-fit joints, colorful blocks, toy photography` | `soft studio light, product shot` |
| 毛线 | `knitted, crochet, yarn texture, wool fibers, handmade, cozy` | `warm natural light, shallow DOF` |
| 金属 | `polished chrome, brushed steel, metallic sheen, reflections, industrial` | `studio HDRI, specular highlights` |
| 水晶 | `crystal, faceted gem, light refraction, prismatic, transparent, sparkling` | `rim light, caustics, dark background` |
| 玻璃 | `blown glass, Murano, translucent, smooth, delicate, light transmission` | `backlit, soft gradient background` |
| 木雕 | `carved wood, oak/walnut grain, traditional woodworking, chisel marks` | `warm directional light, wood workshop` |
| 纸艺 | `paper craft, origami, kirigami, layered paper, cut-out, quilling` | `even soft light, white background` |
| 冰雕 | `carved ice, translucent blue, frozen, crystalline, smooth surface` | `cool blue backlight, dark environment` |
| 陶瓷 | `ceramic, porcelain, glazed surface, kiln-fired, pottery, delft blue` | `natural light, neutral background` |
| 气球 | `balloon sculpture, latex, inflated, shiny, party, twisted balloon art` | `bright cheerful lighting` |

---

## 6. 光影与氛围 (Lighting & Mood)

### 光影
| 光影类型 | 关键词 |
|---------|--------|
| 黄金时刻 | `golden hour, warm sunlight, long shadows, orange glow` |
| 蓝调时刻 | `blue hour, twilight, cool ambient, serene` |
| 伦勃朗光 | `Rembrandt lighting, dramatic, triangle shadow on cheek, chiaroscuro` |
| 霓虹灯 | `neon lighting, colorful glow, urban night, pink/cyan/purple` |
| 体积光 | `volumetric lighting, god rays, atmospheric, fog, light beams` |
| 环境光 | `ambient occlusion, soft shadow, indirect lighting, natural` |
| 逆光 | `backlit, silhouette, rim light, halo effect, lens flare` |
| 聚光灯 | `spotlight, dramatic, single light source, dark background, theater` |

### 氛围
| 氛围 | 关键词 |
|------|--------|
| 温暖治愈 | `warm, cozy, healing, soft, nostalgic, heartwarming` |
| 冷酷帅气 | `cool, edgy, dark, sleek, sharp, cybernetic` |
| 梦幻缥缈 | `dreamy, ethereal, otherworldly, soft focus, misty, magical` |
| 史诗宏大 | `epic, grand, majestic, cinematic, awe-inspiring, monumental` |
| 恐怖诡异 | `eerie, unsettling, dark, horror, ominous, creepy atmosphere` |
| 清新自然 | `fresh, natural, bright, airy, organic, spring-like` |
| 复古怀旧 | `vintage, retro, nostalgic, aged, sepia tones, old photograph` |
| 未来科技 | `futuristic, high-tech, holographic, sleek, advanced, sci-fi` |

---

## 7. 色彩方案速查 (Color Palette Quick Reference)

| 方案名 | 色彩描述 | 适用风格 |
|--------|---------|---------|
| 莫兰迪 | `muted, desaturated, dusty pastels, Morandi palette, soft gray undertones` | 高级感、文艺 |
| 赛博霓虹 | `neon pink, electric cyan, purple, high saturation, dark background` | 赛博朋克、未来 |
| 大地色系 | `earth tones, terracotta, olive, sand, warm brown, natural` | 自然、有机、复古 |
| 糖果色 | `candy colors, pastel pink, mint, lavender, baby blue, sweet` | 可爱、少女、轻松 |
| 单色系 | `monochromatic, shades of [COLOR], tonal, sophisticated, unified` | 极简、高级 |
| 撞色 | `complementary colors, high contrast, bold, vibrant, eye-catching` | 波普、活力 |
| 日式和风 | `Japanese traditional colors, indigo, vermillion, matcha green, washi` | 和风、传统 |
| 北欧 | `Scandinavian palette, white, light wood, muted blue, sage green, clean` | 极简、现代 |

---

_此词库持续更新。使用时根据用户需求组合关键词，不要死板照搬，灵活调配。_
