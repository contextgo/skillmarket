#!/usr/bin/env python3
"""
Image Analyzer — 图片基础信息分析工具
用于 creative-image-remix skill 的 Phase 1 图片预分析。

用法: python3 analyze_image.py <image_path>

输出：图片的基础元数据（尺寸、格式、色彩空间、主色调）
"""

import sys
import os
import json


def analyze_image(image_path: str) -> dict:
    """分析图片基础信息，不依赖重型库。"""
    result = {
        "path": image_path,
        "filename": os.path.basename(image_path),
        "file_size_bytes": 0,
        "file_size_human": "",
        "format": "unknown",
        "width": None,
        "height": None,
        "aspect_ratio": None,
        "orientation": "unknown",
    }

    # File size
    try:
        size = os.path.getsize(image_path)
        result["file_size_bytes"] = size
        if size < 1024:
            result["file_size_human"] = f"{size} B"
        elif size < 1024 * 1024:
            result["file_size_human"] = f"{size / 1024:.1f} KB"
        else:
            result["file_size_human"] = f"{size / (1024 * 1024):.1f} MB"
    except OSError:
        pass

    # Format detection by extension
    ext = os.path.splitext(image_path)[1].lower()
    format_map = {
        ".jpg": "JPEG", ".jpeg": "JPEG", ".png": "PNG",
        ".gif": "GIF", ".webp": "WebP", ".bmp": "BMP",
        ".tiff": "TIFF", ".tif": "TIFF", ".svg": "SVG",
        ".heic": "HEIC", ".heif": "HEIF", ".avif": "AVIF",
    }
    result["format"] = format_map.get(ext, ext.upper().lstrip("."))

    # Try to get dimensions using PIL if available
    try:
        from PIL import Image
        with Image.open(image_path) as img:
            w, h = img.size
            result["width"] = w
            result["height"] = h
            result["format"] = img.format or result["format"]
            result["color_mode"] = img.mode

            # Aspect ratio
            from math import gcd
            g = gcd(w, h)
            result["aspect_ratio"] = f"{w // g}:{h // g}"

            # Orientation
            if w > h:
                result["orientation"] = "landscape"
            elif h > w:
                result["orientation"] = "portrait"
            else:
                result["orientation"] = "square"

            # Dominant colors (basic sampling)
            try:
                small = img.copy()
                small.thumbnail((100, 100))
                if small.mode != "RGB":
                    small = small.convert("RGB")
                pixels = list(small.getdata())
                # Simple k=5 color frequency
                from collections import Counter
                # Quantize to reduce unique colors
                quantized = []
                for r, g_val, b in pixels:
                    quantized.append((r // 32 * 32, g_val // 32 * 32, b // 32 * 32))
                top_colors = Counter(quantized).most_common(5)
                result["dominant_colors"] = [
                    {"rgb": list(c), "hex": "#{:02x}{:02x}{:02x}".format(*c), "percentage": f"{n / len(quantized) * 100:.1f}%"}
                    for c, n in top_colors
                ]
            except Exception:
                result["dominant_colors"] = []

    except ImportError:
        # PIL not available — try basic header parsing for PNG/JPEG
        try:
            with open(image_path, "rb") as f:
                header = f.read(32)

                # PNG: width/height at bytes 16-23
                if header[:8] == b"\x89PNG\r\n\x1a\n":
                    import struct
                    w = struct.unpack(">I", header[16:20])[0]
                    h = struct.unpack(">I", header[20:24])[0]
                    result["width"] = w
                    result["height"] = h
                    result["format"] = "PNG"

                # JPEG: need to find SOF marker
                elif header[:2] == b"\xff\xd8":
                    result["format"] = "JPEG"
                    f.seek(0)
                    data = f.read()
                    import struct
                    i = 2
                    while i < len(data) - 9:
                        if data[i] == 0xFF:
                            marker = data[i + 1]
                            if marker in (0xC0, 0xC1, 0xC2):
                                h = struct.unpack(">H", data[i + 5:i + 7])[0]
                                w = struct.unpack(">H", data[i + 7:i + 9])[0]
                                result["width"] = w
                                result["height"] = h
                                break
                            else:
                                length = struct.unpack(">H", data[i + 2:i + 4])[0]
                                i += 2 + length
                        else:
                            i += 1

            if result["width"] and result["height"]:
                w, h = result["width"], result["height"]
                from math import gcd
                g = gcd(w, h)
                result["aspect_ratio"] = f"{w // g}:{h // g}"
                if w > h:
                    result["orientation"] = "landscape"
                elif h > w:
                    result["orientation"] = "portrait"
                else:
                    result["orientation"] = "square"

        except Exception:
            pass
    except Exception:
        pass

    return result


def suggest_remix_size(orientation: str, width: int = None, height: int = None) -> dict:
    """根据原图信息推荐生成尺寸。"""
    suggestions = {
        "landscape": {"size": "1536x1024", "note": "横幅 3:2，适合风景/全景"},
        "portrait": {"size": "1024x1536", "note": "竖幅 2:3，适合人像/手机壁纸"},
        "square": {"size": "1024x1024", "note": "正方形 1:1，适合社交媒体/头像"},
        "unknown": {"size": "1024x1024", "note": "默认正方形"},
    }
    return suggestions.get(orientation, suggestions["unknown"])


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 analyze_image.py <image_path>")
        sys.exit(1)

    path = sys.argv[1]
    if not os.path.exists(path):
        print(json.dumps({"error": f"文件不存在: {path}"}, ensure_ascii=False, indent=2))
        sys.exit(1)

    info = analyze_image(path)
    size_suggestion = suggest_remix_size(info.get("orientation", "unknown"), info.get("width"), info.get("height"))
    info["suggested_gen_size"] = size_suggestion

    print(json.dumps(info, ensure_ascii=False, indent=2))
