#!/usr/bin/env python3
"""
Prompt Builder — 结构化 Prompt 构建工具
根据 SKILL.md 中的模板和 style-dictionary 自动组装 prompt。

用法: python3 build_prompt.py --mode <MODE> [OPTIONS]

Modes:
  style       风格转换
  reference   参考再创作
  scene       场景替换
  series      系列化扩展
  fusion      风格融合
  material    材质转换
  era         年代穿越
  compose     构图重构
  lineart     线稿互转
  cartoon     IP卡通化
"""

import argparse
import json
import sys


# === 风格词库（核心子集，完整版见 references/style-dictionary.md）===
STYLE_PRESETS = {
    "ghibli": "Studio Ghibli style, anime, soft watercolor, warm pastoral, hand-drawn feel, Miyazaki aesthetic",
    "cyberpunk": "cyberpunk, neon lights, dark futuristic city, holographic, glitch art, high contrast",
    "watercolor": "watercolor painting, soft edges, wet-on-wet technique, flowing pigments, paper texture",
    "oil": "oil painting, thick brushstrokes, impasto technique, rich colors, canvas texture, classical art",
    "pixel": "pixel art, 16-bit retro game style, limited color palette, crisp pixels, nostalgic",
    "clay": "3D clay render, Claymation style, soft rounded shapes, pastel colors, cute miniature",
    "ukiyoe": "ukiyo-e style, Japanese woodblock print, flat color areas, bold outlines, Edo period",
    "popart": "pop art, Andy Warhol style, bold colors, halftone dots, comic book aesthetic",
    "vaporwave": "vaporwave aesthetic, pink and cyan, retro 80s, marble statues, glitch, grid",
    "minimal_line": "minimalist line art, single continuous line, clean white background, elegant simplicity",
    "manga": "manga style, Japanese comic, clean linework, screentone shading, dynamic poses",
    "photo": "photorealistic, 8K, sharp detail, professional photography, natural lighting",
    "ink_wash": "Chinese ink wash painting, sumi-e, xuan paper, black ink, minimalist brushwork",
    "renaissance": "Renaissance painting, classical composition, chiaroscuro, sfumato, oil on wood panel",
    "impressionist": "Impressionist painting, visible brushstrokes, light effects, plein air, Monet style",
    "surreal": "Surrealism, dreamlike, impossible scenes, Dalí style, Magritte paradox",
    "steampunk": "steampunk, Victorian era, brass gears, copper pipes, clockwork, goggles",
    "synthwave": "synthwave, retrowave, sunset gradient, chrome, neon grid, 1980s",
    "shinkai": "Makoto Shinkai style, detailed sky, lens flare, vivid colors, photorealistic anime background",
    "flat": "flat illustration, vector style, simple shapes, limited palette, editorial illustration",
}

MATERIAL_PRESETS = {
    "lego": "LEGO brick build, blocky construction, plastic texture, colorful bricks, toy aesthetic",
    "yarn": "knitted yarn art, crochet texture, soft wool, warm cozy feel, handcraft aesthetic",
    "metal": "polished metal sculpture, chrome finish, reflective surface, industrial, sleek",
    "crystal": "crystal sculpture, transparent, light refraction, prismatic colors, gemstone quality",
    "glass": "blown glass art, translucent, smooth surface, delicate, Murano glass style",
    "wood": "wooden carving, woodgrain texture, traditional craft, warm tones, hand-carved detail",
    "paper": "paper craft, origami, layered paper cut, kirigami, delicate folds, paper texture",
    "ice": "ice sculpture, frozen, translucent blue, cold environment, crystalline detail",
    "gold": "solid gold sculpture, 24K gold, luxurious, gleaming, ornate detail, precious metal",
    "balloon": "balloon art, inflated latex, shiny surface, balloon animal style, playful, party aesthetic",
    "ceramic": "ceramic porcelain, glazed surface, kiln-fired, pottery, delicate",
}

ERA_PRESETS = {
    "prehistoric": "prehistoric era, cave painting style, primitive, earth tones, ancient",
    "egypt": "ancient Egyptian style, hieroglyphics, gold and lapis lazuli, pharaoh aesthetic",
    "medieval": "medieval style, illuminated manuscript, Gothic architecture, knight era",
    "renaissance": "Renaissance painting, classical composition, chiaroscuro, 15th century",
    "1920s": "Art Deco, roaring twenties, jazz age, geometric patterns, gold and black, glamour",
    "1960s": "1960s mod style, psychedelic, flower power, bold patterns, retro",
    "1980s": "1980s aesthetic, synthwave, neon, VHS, Memphis design, retro-futuristic",
    "y2k": "Y2K aesthetic, early digital, chrome, bubbly design, millennium style",
    "near_future": "near future 2050, sleek technology, holographic, minimalist sci-fi",
    "far_future": "far future 3000 AD, post-human, alien technology, cosmic scale, transcendent",
}

CARTOON_LEVELS = {
    "light": "slightly stylized portrait, soft features, illustration style",
    "medium": "cartoon character, animated style, expressive features, vibrant",
    "chibi": "chibi style, 2-head-tall proportion, super deformed, kawaii, cute",
    "mascot": "mascot design, simple shapes, friendly, approachable, brand-safe",
    "pixel_char": "pixel art character, 32x32 sprite, retro game character, 8-bit",
}

QUALITY_TIERS = {
    "general": "high quality, detailed, masterful, professional",
    "photo": "8K, photorealistic, ultra-detailed, sharp focus, professional photography, RAW photo",
    "illustration": "beautiful illustration, artstation quality, detailed artwork, masterpiece",
    "3d": "3D render, octane render, ray tracing, physically based rendering, cinema 4D",
}


def build_style_prompt(subject: str, style: str, mood: str = "", quality: str = "general") -> str:
    style_kw = STYLE_PRESETS.get(style, style)
    quality_kw = QUALITY_TIERS.get(quality, QUALITY_TIERS["general"])
    parts = [style_kw, f"depicting {subject}"]
    if mood:
        parts.append(mood)
    parts.append(quality_kw)
    return ", ".join(parts)


def build_material_prompt(subject: str, material: str, quality: str = "general") -> str:
    mat_kw = MATERIAL_PRESETS.get(material, material)
    quality_kw = QUALITY_TIERS.get(quality, QUALITY_TIERS["general"])
    return f"{subject} made entirely of {mat_kw}, studio photography, {quality_kw}"


def build_era_prompt(subject: str, era: str, quality: str = "general") -> str:
    era_kw = ERA_PRESETS.get(era, era)
    quality_kw = QUALITY_TIERS.get(quality, QUALITY_TIERS["general"])
    return f"{subject} reimagined in {era_kw}, authentic period feel, {quality_kw}"


def build_cartoon_prompt(subject: str, level: str, expression: str = "cheerful", quality: str = "illustration") -> str:
    level_kw = CARTOON_LEVELS.get(level, CARTOON_LEVELS["medium"])
    quality_kw = QUALITY_TIERS.get(quality, QUALITY_TIERS["illustration"])
    return f"{level_kw} version of {subject}, {expression} expression, consistent design suitable for IP/branding, {quality_kw}"


def list_presets(category: str) -> dict:
    maps = {
        "style": STYLE_PRESETS,
        "material": MATERIAL_PRESETS,
        "era": ERA_PRESETS,
        "cartoon": CARTOON_LEVELS,
        "quality": QUALITY_TIERS,
    }
    return maps.get(category, {})


def main():
    parser = argparse.ArgumentParser(description="Prompt Builder for creative-image-remix")
    sub = parser.add_subparsers(dest="mode")

    # Style
    p_style = sub.add_parser("style")
    p_style.add_argument("--subject", required=True)
    p_style.add_argument("--style", required=True)
    p_style.add_argument("--mood", default="")
    p_style.add_argument("--quality", default="general")

    # Material
    p_mat = sub.add_parser("material")
    p_mat.add_argument("--subject", required=True)
    p_mat.add_argument("--material", required=True)
    p_mat.add_argument("--quality", default="general")

    # Era
    p_era = sub.add_parser("era")
    p_era.add_argument("--subject", required=True)
    p_era.add_argument("--era", required=True)
    p_era.add_argument("--quality", default="general")

    # Cartoon
    p_car = sub.add_parser("cartoon")
    p_car.add_argument("--subject", required=True)
    p_car.add_argument("--level", default="medium")
    p_car.add_argument("--expression", default="cheerful")
    p_car.add_argument("--quality", default="illustration")

    # List presets
    p_list = sub.add_parser("list")
    p_list.add_argument("--category", required=True, choices=["style", "material", "era", "cartoon", "quality"])

    args = parser.parse_args()

    if args.mode == "style":
        prompt = build_style_prompt(args.subject, args.style, args.mood, args.quality)
        print(json.dumps({"prompt": prompt, "style_key": args.style}, ensure_ascii=False, indent=2))

    elif args.mode == "material":
        prompt = build_material_prompt(args.subject, args.material, args.quality)
        print(json.dumps({"prompt": prompt, "material_key": args.material}, ensure_ascii=False, indent=2))

    elif args.mode == "era":
        prompt = build_era_prompt(args.subject, args.era, args.quality)
        print(json.dumps({"prompt": prompt, "era_key": args.era}, ensure_ascii=False, indent=2))

    elif args.mode == "cartoon":
        prompt = build_cartoon_prompt(args.subject, args.level, args.expression, args.quality)
        print(json.dumps({"prompt": prompt, "cartoon_level": args.level}, ensure_ascii=False, indent=2))

    elif args.mode == "list":
        presets = list_presets(args.category)
        print(json.dumps(presets, ensure_ascii=False, indent=2))

    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
