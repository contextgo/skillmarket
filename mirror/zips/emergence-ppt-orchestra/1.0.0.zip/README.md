# Emergence PPT Orchestra (涌现 PPT 编排)

一个面向自主 Agent 的高级演示文稿编排技能。

与将演示文稿视为死板、单次生成的“幻觉”产物不同，该技能采用了 **Agent 乐团模式 (Agentic Orchestra Pattern)**：它引导 AI 交互式地构建提纲，使用 [Marp](https://marp.app/) Markdown 框架构建幻灯片，通过 Emergence Render API 嵌入专业图表，并将结果编译为高保真的 PDF、PPTX 或 HTML 格式。

## 🌟 核心特性

1. **迭代式结构化**：通过人类确认提纲的环节，防止大模型产生内容幻觉。
2. **基于 Markdown 的架构**：幻灯片内容透明地编写在 `presentation.md` 中，利用标准的 Marp 指令（`---` 分页、`--paginate`、CSS 样式）。
3. **支持自定义品牌**：技能明确告知 Agent 询问并使用用户的公司 HTML `<style>` 标签，而不是强加品牌样式。
4. **视觉皮层集成**：直接将复杂的数据结构（TikZ, Mermaid, Graphviz, D2）传输至 `https://api.emergence.science/tools/render`，无缝注入学术级图像。
5. **多格式编译**：封装了 `@marp-team/marp-cli` 以构建 `.pdf`、`.pptx` 或 `.html`。

## 📦 安装

```bash
clawhub install emergence-ppt-orchestra
```

## 🔑 认证

渲染图表需要 `EMERGENCE_API_KEY`。
1. 在 [https://emergence.science/](https://emergence.science/) 通过 GitHub OAuth 进行验证。
2. 将 API Key 加载到 Agent 的环境变量中。
*注意：新账户将获得 **1,000,000 微积分 (micro-credits)**。*

## 📖 使用示例

在为 Agent 配备此项技能后，尝试以下提示词：

> "帮我创建一个关于语义映射的学术演示文稿。请先提供提纲。"

获批后：
> "将批准的提纲编译成 Marp Markdown。如果我们需要系统架构流程图，请调用渲染 API。"

---
由 **涌现科学 (Emergence Science)** 开发。  
[源码仓库 (Gitee)](https://gitee.com/bubble-universe/emergence-ppt-orchestra)
