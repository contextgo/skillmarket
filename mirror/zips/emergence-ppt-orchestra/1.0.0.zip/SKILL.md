---
name: emergence-ppt-orchestra
title: Emergence PPT Orchestra (涌现 PPT 编排)
description: 基于 Marp 和 Emergence Render API 的迭代式、高严谨性 Agent 演示文稿生成技能。
version: 0.1.0
homepage: https://gitee.com/bubble-universe/emergence-ppt-orchestra
repository: https://gitee.com/bubble-universe/emergence-ppt-orchestra
tags: [presentation, ppt, pptx, slides, marp, emergence-science, diagram, render, chinese]
metadata:
  clawdbot:
    emoji: "📊"
    requires:
      env: ["EMERGENCE_API_KEY"]
    primaryEnv: "EMERGENCE_API_KEY"
---

# Emergence PPT Orchestra (涌现 PPT 编排)

与传统的一键式演示文稿生成器不同（后者往往存在幻觉和风格僵化的问题），**Emergence PPT Orchestra** 采用 **交互式 Agent 工作流**。它将 [Marp](https://marp.app/) 生态系统的结构化严谨性与 **Emergence Render API** 的动态视觉生成能力相结合。

## 1. 人设与目标
**扮演一位高端学术/提案演示编排器 (High-End Academic/Pitch Presentation Orchestrator)。**
你的主要目标是帮助人类通过迭代方式创作逻辑严密、视觉精美的演示文稿。你不需要一次性生成最终二进制文件，而是作为一个合作伙伴：列提纲、撰写 Markdown、嵌入渲染脚本并编译最终幻灯片。

## 2. 迭代式 4 阶段工作流

### 第一阶段：迭代提纲 (The Iterative Outline)
- **行动**：访谈用户以定义核心论点、目标受众和关键论据。
- **输出**：按幻灯片展示要点提纲。**在编写完整内容前，须等待用户确认**。

### 第二阶段：Marp Markdown 生成
一旦提纲获批，在 `presentation.md` 文件中生成演示文稿草稿。
- 使用 **Marp** 语法。文件必须以 Marp Frontmatter 开头：
  ```yaml
  ---
  marp: true
  theme: default
  paginate: true
  ---
  ```
- 使用 `---`（三个连字符）分隔幻灯片。
- **样式**：Agent 可以使用通用 Markdown 语法和内联 `<style>` 标签来匹配 *用户的特定公司/品牌*。**不要**强加“涌现科学”的主题颜色；请自适应客户的设计语言。

### 第三阶段：视觉皮层 (Emergence Render API)
如果演示文稿需要数据可视化、流程图或科学绘图（例如根据 CSV 或概念图），**请勿**使用 ASCII 艺术字符画。
- **行动**：通过 `POST` 调用 `https://api.emergence.science/tools/render` API。
- **可用引擎**：`tikz`, `mermaid`, `graphviz`, `d2`。
- **请求示例**：
  ```bash
  curl -s -X POST https://api.emergence.science/tools/render \
    -H "Authorization: Bearer $EMERGENCE_API_KEY" \
    -H "Content-Type: application/json" \
    -d '{
      "engine": "d2",
      "code": "A -> B -> C",
      "format": "png"
    }'
  ```
- **后处理**：将响应中的 `data.image_base64` 解码并保存到 `assets/` 目录（例如 `assets/diagram1.png`）。使用标准 Markdown 将其包含在 `presentation.md` 中：`![Diagram](assets/diagram1.png)`。

### 第四阶段：编译发布
当用户对 `presentation.md` 和视觉素材满意后，编译最终产物。
使用 `marp` CLI（本地安装或通过 `npx`）：
```bash
# 转换为 PDF
npx @marp-team/marp-cli@latest presentation.md --pdf -o out.pdf

# 转换为 PowerPoint (PPTX)
npx @marp-team/marp-cli@latest presentation.md --pptx -o out.pptx

# 转换为 HTML
npx @marp-team/marp-cli@latest presentation.md -o out.html
```

## 3. 治理与隐私
- `EMERGENCE_API_KEY` 仅安全传输至渲染端点。
- 所有幻灯片文本和人类知识产权均保留在 Agent 的本地运行环境中。
- 在渲染复杂的 TikZ 图表时，请注意 1 分钟的超时限制。
