"""
南方电网·企业管理咨询类招标公告自动监测脚本
=============================================
数据来源：南方电网供应链统一服务平台 https://www.bidding.csg.cn
招标公告列表：/zbgg/index.jhtml
详情页：/zbgg/{id}.jhtml
每一有效公告必须点进详情页，检查「招标文件获取截止时间」是否在有效期内。
"""

import os
import re
import sys
import time
import requests
from datetime import datetime, timedelta
from pathlib import Path

# 强制 stdout/stderr 使用 UTF-8，避免 Windows PowerShell 的 GBK 编码崩溃
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")

# ──────────────────────────────────────────────────────────────
# [有效] 可自定义配置区
# ──────────────────────────────────────────────────────────────
CONFIG = {
    # ───── 初筛关键词：标题含任一即纳入候选 ─────
    # 用户提供的企业管理咨询类关键词
    "search_keywords": [
        "咨询", "管理", "战略", "规划", "顾问",
        "智库", "研究", "对标", "改革", "组织",
        "人力", "绩效", "薪酬", "人才", "培训",
        "文化", "品牌", "风控", "合规", "治理",
        "创新", "转型", "提升", "优化",
        "企业管理", "人力资源", "组织变革", "流程优化",
        "战略规划", "品牌策划", "文化建设的", "风控体系",
    ],

    # ───── 精筛：排除非企业管理咨询的咨询类型 ─────
    "non_mgmt_consulting": [
        # 技术/软件/系统类
        "技术咨询", "软件咨询", "系统咨询", "平台咨询", "开发咨询",
        "信息化咨询", "数字化咨询",
        # 工程/设计/造价类
        "工程咨询", "设计咨询", "造价咨询", "勘察咨询", "监理咨询",
        "检测咨询", "测试咨询", "评估咨询",
        # 其他非管理类
        "法律咨询", "税务咨询", "财务咨询", "会计咨询",
    ],

    # ───── 标题含这些词时直接排除（明显非咨询类） ─────
    # 注意：不在此列的词汇，不意味着一定通过，仍需经过后续的精筛和语义确认
    # 假阳性规则已移除（V5）：改用详情页正文内容分析，而非仅靠标题关键词排除
    "title_exclude": [
        "设备", "电缆", "母线", "土建", "施工", "维修", "维保",
        "物资", "车辆", "保洁", "劳务", "发电机", "储能",
        "杆塔", "线路", "变压器", "开关柜", "绝缘子",
        "配电", "输电", "变电", "发电", "电缆敷设",
        "勘察设计", "设计", "监理", "造价",
        "材料", "器材", "配件", "零件",
        # ★ 新增（2026-05-06）：技术系统/软件开发类
        "可视化系统", "系统升级改造", "系统建设项目", "V1.0", "V2.0",
        "系统开发", "软件开发", "平台开发", "信息化建设",
        # ★ 新增（2026-05-06）：工程/设备改造类
        "热水系统", "光伏改造", "空气能", "热水系统改造", "光伏空气能",
        "光伏项目", "储能项目", "充电桩", "换电站",
        "电气改造", "机电改造", "设施改造",
    ],

    # ───── 时间范围 ─────
    # 回溯天数：抓取发布日期在最近 N 天内的公告
    "lookback_days": 7,

    # 每次最多翻多少页列表页
    "max_list_pages": 20,

    # 招标文件获取截止时间必须晚于「当前时间 + 缓冲小时数」
    # 设为 0 表示「截止时间还没到」即为有效
    "valid_buffer_hours": 0,

    # Excel 输出文件名
    "output_excel": "南网管理咨询招标公告.xlsx",

    # 列表页基础 URL（招标公告）
    "list_url": "https://www.bidding.csg.cn/zbgg/index.jhtml",
    # 非招标公告列表页（公开谈判采购等）
    "fzbgg_list_url": "https://www.bidding.csg.cn/fzbgg/index.jhtml",
}

SCRIPT_DIR = Path(__file__).parent.resolve()

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9",
    "Referer": "https://www.bidding.csg.cn/zbcg/index.jhtml",
}

# ──────────────────────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────────────────────
def log(msg: str):
    print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}", flush=True)


def parse_cn_datetime(s: str) -> datetime | None:
    """
    解析中文时间字符串 -> datetime
    支持格式：
      YYYY年MM月DD日HH时MM分SS秒（允许月/日之间有空格，如"05月 11 日"）
      YYYY-MM-DD HH:MM:SS
    """
    if not s:
        return None
    try:
        # 格式1：2026年05月08日22时00分00秒（允许各段之间有空格）
        # 前提：调用方已将数字内空格规范化（如 "0 4" → "04"），此处只需处理段间空格
        m = re.search(
            r'(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日'
            r'(?:\s*(\d{1,2})\s*时\s*(\d{1,2})\s*分(?:\s*(\d{1,2})\s*秒)?)?',
            s
        )
        if m:
            year   = int(m.group(1))
            month  = int(m.group(2))
            day    = int(m.group(3))
            hour   = int(m.group(4)) if m.group(4) else 0
            minute = int(m.group(5)) if m.group(5) else 0
            second = int(m.group(6)) if m.group(6) else 0
            return datetime(year, month, day, hour, minute, second)
        # 格式2：2026-05-08 22:00:00
        m2 = re.search(r'(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})', s)
        if m2:
            return datetime(
                int(m2.group(1)), int(m2.group(2)), int(m2.group(3)),
                int(m2.group(4)), int(m2.group(5)), int(m2.group(6))
            )
    except Exception:
        pass
    return None


def fetch_html(url: str, timeout: int = 20, retry: int = 3) -> str:
    """获取页面 HTML，带重试"""
    for attempt in range(1, retry + 1):
        try:
            resp = requests.get(url, headers=HEADERS, timeout=timeout)
            resp.raise_for_status()
            resp.encoding = resp.apparent_encoding or "utf-8"
            return resp.text
        except Exception as e:
            log(f"  [警告]  请求失败（{attempt}/{retry}）{url}: {e}")
            if attempt < retry:
                time.sleep(3 * attempt)
    return ""


def extract_detail_times(html: str) -> dict:
    """
    从详情页 HTML 中提取关键时间。
    返回 dict，包含：
      - file_start  : 招标文件获取开始时间（datetime 或 None）
      - file_end    : 招标文件获取截止时间（datetime 或 None）
      - bid_deadline: 投标截止时间（datetime 或 None）
    """
    result = {"file_start": None, "file_end": None, "bid_deadline": None}

    # 去掉 script/style 标签，避免干扰
    text = re.sub(r'<script[^>]*>.*?</script>', ' ', html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', ' ', text, flags=re.DOTALL | re.IGNORECASE)
    # 去掉所有 HTML 标签，变成纯文本
    text = re.sub(r'<[^>]+>', ' ', text)
    text = re.sub(r'\s+', ' ', text).strip()

    # ★ 重要：某些页面（如询比采购类）HTML 将月份/日期/时间数字拆出空格（如 "04" → "0 4"），
    #   导致正则无法正确匹配（贪婪回溯会将空格错误分配给相邻组件）。
    #   解决方案：将所有「数字-空格-数字」模式中的空格去掉，使 "0 4" → "04"
    #   注意：只去掉「数字-空格-数字」三元组中的空格，保留「年-空格-月」「月-空格-日」等合法分隔
    text_normalized = re.sub(r'(\d)\s+(\d)', r'\1\2', text)

    # 中文时间正则（允许日期/时间之间有任意空白，如"2026年 04 月 30 日"）
    # 前提：text_normalized 已处理了数字内空格，月份/日期均为正常数字
    cn_time_pattern = r'\d{4}\s*年\s*\d{1,2}\s*月\s*\d{1,2}\s*日(?:\s*\d{1,2}\s*时\s*\d{1,2}\s*分(?:\s*\d{1,2}\s*秒)?)?'

    def find_time_after_label(label: str, txt: str):
        """在 txt 中找到 label 后，在后续 150 字符内提取第一个时间"""
        idx = txt.find(label)
        if idx < 0:
            return None
        snippet = txt[idx:idx + 150]
        m = re.search(cn_time_pattern, snippet)
        if m:
            return parse_cn_datetime(m.group(0))
        # 备用：YYYY-MM-DD HH:MM:SS 格式
        m2 = re.search(r'\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}', snippet)
        if m2:
            return parse_cn_datetime(m2.group(0))
        return None

    # ── 按标签精准提取（最可靠）─────
    # 招标文件获取开始时间
    # ★ 重要：部分页面HTML结构将"获取开始时间"标签拆分为"获取开始 时间"（中间有空格或换行），
    #   清理HTML标签后变成"获取开始 时间："，不是"获取开始时间："，故两个变体都要查
    for label in ["获取开始时间", "获取开始 时间", "文件获取开始时间", "招标文件获取开始时间",
                 "采购文件获取开始时间", "招标文件获取开始", "获取开始", "发售开始时间"]:
        if result["file_start"] is None:
            result["file_start"] = find_time_after_label(label, text_normalized)

    # 招标文件获取截止/结束时间
    # ★ 同样处理"获取结束 时间"的HTML拆分情况
    for label in ["获取截止时间", "获取结束时间", "获取结束 时间", "文件获取截止时间",
                 "招标文件获取截止时间", "招标文件获取结束时间", "报名截止时间",
                 "采购文件获取截止时间", "获取截止", "获取结束", "发售截止时间",
                 "文件发售截止", "购标截止时间"]:
        if result["file_end"] is None:
            result["file_end"] = find_time_after_label(label, text_normalized)

    # 投标文件递交截止时间 / 投标截止时间
    for label in ["投标截止时间", "投标文件递交截止时间", "递交截止时间", "响应截止时间",
                 "投标文件递交截止", "投标截止", "响应截止", "递交截止"]:
        if result["bid_deadline"] is None:
            result["bid_deadline"] = find_time_after_label(label, text_normalized)

    # ── 备用：标签法失败时用位置推断 ──
    # ★ 重要修复：过滤掉正文中的历史参考日期（如招标公告正文里引用的历史文献日期、合同签订日期等），
    #   这些日期不应作为采购文件获取时间。本次过滤：只保留 >= 2020-01-01 的时间戳
    if result["file_start"] is None or result["file_end"] is None or result["bid_deadline"] is None:
        all_times_raw = re.findall(cn_time_pattern, text_normalized)
        all_dt = [parse_cn_datetime(t) for t in all_times_raw]
        all_dt = [t for t in all_dt if t is not None and t.year >= 2020]
        all_dt.sort()

        if len(all_dt) >= 2:
            if result["file_start"] is None and len(all_dt) >= 1:
                result["file_start"] = all_dt[0]
            if result["file_end"] is None and len(all_dt) >= 2:
                result["file_end"] = all_dt[1]
            if result["bid_deadline"] is None and len(all_dt) >= 3:
                # 最后一个（最大）时间通常是投标截止
                result["bid_deadline"] = all_dt[-1]

    return result



def extract_detail_content(html: str) -> str:
    """从详情页 HTML 中提取公告正文文本（用于内容分析）"""
    # 去掉 script / style 标签块
    text = re.sub(r'<script[^>]*>.*?</script>', ' ', html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r'<style[^>]*>.*?</style>', ' ', text, flags=re.DOTALL | re.IGNORECASE)
    # 去掉所有 HTML 标签
    text = re.sub(r'<[^>]+>', ' ', text)
    # 合并多余空白
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def is_valid_announcement(html: str) -> tuple:
    """
    判断一条招标公告是否有效：
    1. 点进详情页，提取「招标文件获取截止时间」
    2. 截止时间 > 当前时间  → 有效
       截止时间 <= 当前时间 → 无效（已过期）
    3. 兜底逻辑：询比采购类公告如果没有截止时间但有开始时间，
       且开始时间已过但距今不超过7天，视为潜在有效公告
    返回 (is_valid: bool, times: dict)
    """
    times = extract_detail_times(html)
    file_end = times.get("file_end")
    file_start = times.get("file_start")

    if file_end is None:
        # ── 兜底逻辑：询比采购类公告 ──
        # 对于没有截止时间的公告，检查开始时间
        if file_start is not None:
            now = datetime.now()
            # 开始时间已过且距今不超过7天，视为有效
            if file_start <= now and (now - file_start).days <= 7:
                return True, times
        # 无法提取截止时间且不满足兜底条件，视为无效
        return False, times

    now = datetime.now()
    buffer = timedelta(hours=CONFIG["valid_buffer_hours"])
    return file_end > (now + buffer), times


def is_relevant(title: str, content: str = "") -> tuple:
    """
    标题相关性过滤——企业管理咨询类招标公告。
    返回 (passed: bool, reason: str)

    三阶段过滤：
      1. 粗筛：含搜索关键词 且 不含排除词
      2. 排除非企业管理咨询的咨询类型（技术/工程/造价咨询等）
      3. 排除「假阳性」模式（标题含关键词但实际不是管理咨询）
         最终确认标题语义确实是企业管理咨询方向
    """
    t = title.strip()

    # ── 阶段1：粗筛 —— 排除明显非咨询类 ──
    for exc in CONFIG["title_exclude"]:
        if exc in t:
            return False, f"排除词[{exc}]"

    # 必须含至少一个搜索关键词
    matched_kws = []
    for kw in CONFIG["search_keywords"]:
        if kw in t:
            matched_kws.append(kw)
    if not matched_kws:
        return False, "不含关键词"

    # ── 阶段2：排除非企业管理咨询的咨询类型 ──
    for non_mgmt in CONFIG["non_mgmt_consulting"]:
        if non_mgmt in t:
            return False, f"非管理咨询类型[{non_mgmt}]"


    # ── 阶段3：语义确认（标题+正文内容双重验证） ──
    # 标题必须明确指向「企业管理咨询」服务
    # 通过以下任一方式确认：
    mgmt_confirm_keywords = [
        # 明确的管理咨询类
        "管理咨询", "企业管理咨询", "战略咨询", "经营咨询",
        "人力资源咨询", "组织变革咨询", "绩效咨询",
        "流程优化咨询", "风控咨询", "合规咨询", "治理咨询",
        "文化咨询", "品牌咨询", "营销咨询",
        "变革咨询", "转型咨询",
        # 带咨询后缀的服务
        "咨询服务", "顾问服务",
        # 明确的人才/人力/组织发展服务
        "人才测评", "人才发展", "领导力", "综合素质测评",
        "组织诊断", "组织效能", "组织架构优化",
        # 课题研究/专题研究类（用户明确：调度规划专题等研究类属于管理咨询）
        "课题研究", "专题研究", "专题报告", "调研报告",
        "调度规划专题", "规划专题", "管理专题",
        "研究咨询", "决策咨询", "政策研究",
        # ★ 新增：管理创新/创新研究类（2026-05-06 用户反馈）
        "管理创新", "创新研究", "专项研究", "研究项目",
        "创新项目", "管理创新项目",
        # ★ 新增：虚拟电厂专题研究（2026-05-06 用户反馈）
        "虚拟电厂",
        # 战略/规划类（仅限企业管理方向，不含电网/工程规划）
        "战略规划（且不含电网|电力|输电|变电|基建|前期）",
        "管理提升", "对标管理", "国企改革", "三项制度",
        # 薪酬/绩效体系设计
        "薪酬体系", "绩效考核体系", "绩效管理体系",
        # 企业文化/品牌建设
        "企业文化建设", "品牌建设", "企业文化",
        # 风控/合规/治理体系建设
        "风控体系", "合规体系", "治理机制",
        "内部控制", "内控体系",
    ]

    # 检查是否命中确认关键词
    confirmed = False
    confirm_reason = ""
    for ck in mgmt_confirm_keywords:
        # 处理带括号的复合条件
        if "（且不含" in ck:
            base = ck.split("（且不含")[0]
            excludes = ck.split("）")[0].split("不含")[1].split("|")
            if base in t and not any(ex in t for ex in excludes):
                confirmed = True
                confirm_reason = ck
                break
        elif ck in t:
            confirmed = True
            confirm_reason = ck
            break


    # ── 标题未确认时，用正文内容再试一次 ──
    if not confirmed and content:
        for ck in mgmt_confirm_keywords:
            if "（且不含" in ck:
                base = ck.split("（且不含")[0]
                excludes = ck.split("）")[0].split("不含")[1].split("|")
                if base in content and not any(ex in content for ex in excludes):
                    confirmed = True
                    confirm_reason = f"正文内容确认[{base}]"
                    break
            elif ck in content:
                confirmed = True
                confirm_reason = f"正文内容确认[{ck}]"
                break
        # 兜底：正文含咨询且含管理类词汇
        if not confirmed and "咨询" in content:
            if any(m in content for m in ["管理", "战略", "组织", "人力", "人力资源", "绩效"]):
                confirmed = True
                confirm_reason = "正文:咨询+管理类词汇"

    if not confirmed:
        # 最后兜底：如果含"咨询"二字 + 管理相关词汇组合，也通过
        if "咨询" in t and any(m in t for m in ["管理", "战略", "组织", "人力", "人力资源", "绩效"]):
            confirmed = True
            confirm_reason = "咨询+管理类词汇"
        else:
            return False, "无法确认为企业管理咨询类"

    return True, f"确认[{confirm_reason}]（匹配关键词:{', '.join(matched_kws[:3])}）"


# ──────────────────────────────────────────────────────────────
# 列表页解析
# ──────────────────────────────────────────────────────────────
def parse_list_page(html: str) -> list:
    """
    解析招标公告列表页 HTML，提取每条公告的：
      - title     : 公告标题
      - url       : 详情页相对路径（如 /zbgg/1200428715.jhtml）
      - detail_url: 完整详情页 URL
      - pub_date  : 发布日期（datetime.date 或 None）
    返回 list of dict。
    """
    items = []

    # 策略：先按行分割，找包含 /zbgg/数字.jhtml 的段落
    # 公告列表通常在 <li> 或 <tr> 中，包含标题链接和日期
    # 日期格式通常为 YYYY-MM-DD 或 YYYY/MM/DD

    # 方法1：找所有 /zbgg/ 或 /fzbgg/ 数字.jhtml 链接
    link_pattern = r'href="(/zbgg/\d+\.jhtml|/fzbgg/\d+\.jhtml)"[^>]*>([^<]+)</a>'
    link_matches = re.findall(link_pattern, html)

    # 方法2：在链接附近找日期（YYYY-MM-DD 或 YYYY/MM/DD）
    # 先去掉所有 HTML 标签，保留文本和链接
    # 对每个链接，向前/向后搜索日期
    for url, title in link_matches:
        title = title.strip()
        # 过滤：排除明确的非采购类公告（中标公示、成交结果、废标通知等）
        # 注意：不能用正向过滤（要求含"招标/采购/公告"），因为列表页标题可能被截断，
        #       导致"询比采购公告"末尾被截成"公..."，正向词匹配失败 → 正确公告被误丢
        _EXCLUDE_TYPES = ["中标公示", "中标结果", "成交公示", "成交结果",
                          "废标公告", "终止公告", "流标公告", "异常公告", "澄清公告"]
        if any(ex in title for ex in _EXCLUDE_TYPES):
            continue
        # 保留基本门槛：至少含一个与采购相关的汉字（防止导航链接等噪音混入）
        if not any(c in title for c in ["标", "购", "公", "服", "项"]):
            continue

        # 在这个链接附近搜索日期
        # 找到链接在 HTML 中的位置
        url_pos = html.find(f'href="{url}"')
        pub_date = None
        if url_pos >= 0:
            # 向前200字符 + 向后200字符 范围内搜索日期
            snippet = html[max(0, url_pos - 200):url_pos + 200]
            # YYYY-MM-DD 格式
            date_m = re.search(r'(\d{4}-\d{2}-\d{2})', snippet)
            if date_m:
                try:
                    pub_date = datetime.strptime(date_m.group(1), "%Y-%m-%d").date()
                except Exception:
                    pass
            # YYYY/MM/DD 格式
            if pub_date is None:
                date_m2 = re.search(r'(\d{4}/\d{2}/\d{2})', snippet)
                if date_m2:
                    try:
                        pub_date = datetime.strptime(date_m2.group(1), "%Y/%m/%d").date()
                    except Exception:
                        pass

        items.append({
            "title": title,
            "url": url,
            "detail_url": f"https://www.bidding.csg.cn{url}",
            "pub_date": pub_date,
            "source": "招标公告" if url.startswith("/zbgg/") else "非招标公告",
        })

    # 去重（同一条公告可能在页面出现多次）
    seen = set()
    unique = []
    for item in items:
        if item["url"] not in seen:
            seen.add(item["url"])
            unique.append(item)

    return unique


def fetch_list_page(page_no: int, base_url: str = "") -> str:
    """获取第 N 页列表页 HTML，base_url 为空时默认取 zbgg 列表"""
    if not base_url:
        base_url = CONFIG["list_url"]
    if page_no <= 1:
        url = base_url
    else:
        url = base_url.replace("index.jhtml", f"index_{page_no}.jhtml")
    return fetch_html(url)


# ──────────────────────────────────────────────────────────────
# Excel 操作
# ──────────────────────────────────────────────────────────────
DATA_HEADERS = [
    "抓取日期",      # 本次执行日期，方便区分每次运行结果
    "公告标题",
    "招标单位",
    "发布日期",
    "文件获取开始时间",
    "文件获取截止时间",
    "投标递交截止时间",
    "详情链接",
    "来源",              # 招标公告 / 非招标公告
    "公告URL",           # 用于去重，存储原始URL文本
]

STATS_LABELS = [
    ("total_fetched",       "总共抓取到公告数"),
    ("zb_cg_count",         "其中: 招标/采购公告数"),
    ("coarse_passed",       "通过粗筛（含搜索关键词）"),
    ("fine_passed",         "通过精筛（企业管理咨询类确认）"),
    ("detail_fetched",      "成功进入详情页检查"),
    ("detail_fetch_fail",   "详情页获取失败"),
    ("time_extract_fail",   "招标文件获取截止时间提取失败"),
    ("content_excluded",    "正文内容分析排除（非管理咨询类）"),
    ("expired",             "已过期（招标文件获取截止时间已过）"),
    ("valid",               "有效（未过期，已写入本表）"),
]


def _merge_date_column(ws, col: int, header_row: int):
    """
    对指定列（col，1-based），将连续相同值的单元格合并（跳过表头行）。
    合并后居中显示，保留边框。
    """
    from openpyxl.styles import Alignment, Border, Side
    from openpyxl.utils import get_column_letter

    max_row = ws.max_row
    if max_row <= header_row:
        return  # 没有数据行

    thin = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )

    # 先取消已有合并（避免重复合并报错）
    col_letter = get_column_letter(col)
    merges_to_remove = [
        rng for rng in ws.merged_cells.ranges
        if rng.min_col == col and rng.max_col == col
    ]
    for rng in merges_to_remove:
        ws.unmerge_cells(str(rng))

    # 重新扫描并合并连续相同值
    start_row = header_row + 1
    current_val = ws.cell(row=start_row, column=col).value
    group_start = start_row

    for r in range(start_row + 1, max_row + 2):  # +2 以触发最后一组处理
        val = ws.cell(row=r, column=col).value if r <= max_row else object()  # sentinel
        if val != current_val or r > max_row:
            group_end = r - 1
            if group_end > group_start:
                ws.merge_cells(
                    start_row=group_start, start_column=col,
                    end_row=group_end, end_column=col
                )
            # 设置合并后单元格样式
            c = ws.cell(row=group_start, column=col)
            c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=False)
            c.border = thin
            # 更新追踪
            current_val = val
            group_start = r


def write_to_excel(items: list, stats: dict) -> tuple:
    """
    将有效公告和统计数据写入 Excel。
    结构：
      Sheet1「统计汇总」：每次运行的统计数据 + 日期备注
      Sheet2「有效公告」 ：详细的有效公告数据（追加模式）
    返回 (new_count, skip_count)
    """
    try:
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        os.system(f"{sys.executable} -m pip install openpyxl -q")
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
        from openpyxl.utils import get_column_letter

    excel_path = SCRIPT_DIR / CONFIG["output_excel"]
    run_time = datetime.now().strftime("%Y-%m-%d %H:%M")

    if excel_path.exists():
        wb = openpyxl.load_workbook(excel_path)
    else:
        wb = openpyxl.Workbook()

    # ══════════════════════════════════════
    # Sheet1: 统计汇总
    # ══════════════════════════════════════
    stats_sheet_name = "统计汇总"
    data_sheet_name = "有效公告"

    if stats_sheet_name in wb.sheetnames:
        ws_stats = wb[stats_sheet_name]
    else:
        ws_stats = wb.create_sheet(stats_sheet_name, 0)
        # 表头
        ws_stats.append(["执行日期"] + [label for _, label in STATS_LABELS] + ["备注"])
        sh = PatternFill(start_color="2E75B6", end_color="2E75B6", fill_type="solid")
        sf = Font(name="微软雅黑", bold=True, color="FFFFFF", size=10)
        for c in ws_stats[1]:
            c.fill = sh; c.font = sf; c.alignment = Alignment(horizontal="center", vertical="center")

    # 追加本次统计数据行
    run_date = datetime.now().strftime("%Y-%m-%d")
    stats_row = [run_date]
    for key, label in STATS_LABELS:
        val = stats.get(key, 0)
        stats_row.append(val)
    stats_row.append(f"回溯{CONFIG['lookback_days']}天")
    ws_stats.append(stats_row)

    # 统计表样式
    s_border = Border(
        left=Side(style="thin"), right=Side(style="thin"),
        top=Side(style="thin"), bottom=Side(style="thin"),
    )
    last_r = ws_stats.max_row
    alt = PatternFill(start_color="DEEBF7", end_color="DEEBF7", fill_type="solid") if last_r % 2 == 0 else None
    for ci, c in enumerate(ws_stats[last_r], 1):
        c.border = s_border
        c.alignment = Alignment(horizontal="center" if ci > 1 else "left", vertical="center")
        if alt:
            c.fill = alt

    # 对统计汇总的「执行日期」列（第1列）合并同日期单元格
    _merge_date_column(ws_stats, col=1, header_row=1)

    # 统计表列宽（执行日期 + 10项统计 + 备注 = 12列）
    sw = [14, 16, 18, 18, 22, 18, 16, 24, 22, 14, 14, 14]
    for i, w in enumerate(sw, 1):
        ws_stats.column_dimensions[get_column_letter(i)].width = w

    # ══════════════════════════════════════
    # Sheet2: 有效公告明细
    # ══════════════════════════════════════
    if data_sheet_name in wb.sheetnames:
        ws_data = wb[data_sheet_name]
        # 读取已有URL去重（第10列存储原始URL文本；兼容旧格式第9列）
        existing_urls = set()
        for r in ws_data.iter_rows(min_row=2, values_only=True):
            # 第10列（index 9）优先，其次第9列（index 8，旧格式）
            url_val = r[9] if len(r) >= 10 else None
            if not url_val and len(r) >= 9:
                url_val = r[8]
            if url_val:
                existing_urls.add(str(url_val))
    else:
        ws_data = wb.create_sheet(data_sheet_name, 1)
        ws_data.append(DATA_HEADERS)
        dhf = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
        dhf_font = Font(name="微软雅黑", bold=True, color="FFFFFF", size=10)
        for c in ws_data[1]:
            c.fill = dhf; c.font = dhf_font; c.alignment = Alignment(horizontal="center", vertical="center")
        existing_urls = set()

    # ★ 去重策略2：从已有Excel读取"标题+招标单位"组合（跨运行去重）
    existing_dedup_keys = set()
    if 'ws_data' in locals() and hasattr(ws_data, 'iter_rows'):
        for r in ws_data.iter_rows(min_row=2, values_only=True):
            title = str(r[1]) if len(r) > 1 and r[1] else ''  # 第2列是标题
            org = str(r[2]) if len(r) > 2 and r[2] else ''    # 第3列是招标单位
            if title or org:
                existing_dedup_keys.add(f'{title}|{org}')

    # 写入有效公告数据
    new_count = 0
    skip_count = 0
    d_border = Border(
        left=Side(style="thin", color="BFBFBF"), right=Side(style="thin", color="BFBFBF"),
        top=Side(style="thin", color="BFBFBF"), bottom=Side(style="thin", color="BFBFBF"),
    )
    link_font = Font(name="微软雅黑", color="0563C1", underline="single", size=9)

    for item in items:
        url = item.get("detail_url", "")

        # ★ 去重策略1：基于URL精确去重（原有逻辑）
        if url in existing_urls:
            skip_count += 1
            continue

        # ★ 去重策略2：基于"标题+招标单位"组合去重（跨运行去重）
        dedup_key = f"{item.get('title', '')}|{item.get('org', '')}"
        if dedup_key in existing_dedup_keys:
            skip_count += 1
            continue

        # 记录已处理的"标题+招标单位"组合（防止同一次运行中重复）
        if dedup_key.strip('|'):
            existing_dedup_keys.add(dedup_key)

        row_data = [
            run_date,                          # 抓取日期
            item.get("title", ""),              # 公告标题
            item.get("org", ""),                # 招标单位
            item.get("pub_date", ""),           # 发布日期
            item.get("file_start", ""),         # 文件获取开始时间
            item.get("file_end", ""),           # 文件获取截止时间
            item.get("bid_deadline", ""),       # 投标递交截止时间
            url,                                # 详情链接（直接显示URL地址）
            item.get("source", ""),              # 来源（招标公告 / 非招标公告）
            url,                                # 公告URL（文本，用于去重，隐藏列）
        ]
        ws_data.append(row_data)
        rn = ws_data.max_row
        fc = "EBF3FB" if rn % 2 == 0 else "FFFFFF"
        rf = PatternFill(start_color=fc, end_color=fc, fill_type="solid")

        for ci, c in enumerate(ws_data[rn], 1):
            c.fill = rf; c.border = d_border
            c.alignment = Alignment(vertical="center", wrap_text=True)

        # 第8列：显示URL文本，同时设为可点击超链接
        lc = ws_data.cell(row=rn, column=8)
        lc.value = url
        lc.hyperlink = url
        lc.font = link_font
        lc.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)

        existing_urls.add(url)
        new_count += 1

    # ── 对「抓取日期」列（第1列）按日期合并同值单元格 ──
    _merge_date_column(ws_data, col=1, header_row=1)

    # 数据表列宽
    dw = [13, 55, 28, 12, 20, 20, 20, 50, 12, 50]
    for i, w in enumerate(dw, 1):
        ws_data.column_dimensions[get_column_letter(i)].width = w
    # 第10列（J列）改为与详情链接同宽，不再隐藏（避免行高异常）
    ws_data.freeze_panes = "A2"

    # 保存 Excel 文件
    try:
        wb.save(excel_path)
        log(f"    [保存]  {excel_path.name}")
    except PermissionError:
        # 主文件被占用，尝试写入备用文件
        if excel_path.stem.endswith("_备用"):
            backup_path = excel_path  # 已经是备用文件
        else:
            backup_path = excel_path.parent / (excel_path.stem + "_备用.xlsx")
        try:
            wb.save(backup_path)
            log(f"    [备用]  Excel 被占用，已写入备用文件：{backup_path.name}")
        except Exception as e2:
            log(f"    [错误]  备用文件写入也失败：{e2}")
            return 0, 0
    return new_count, skip_count


# ──────────────────────────────────────────────────────────────
# 主流程
# ──────────────────────────────────────────────────────────────
def main():
    log("=" * 60)
    log("[启动] 南方电网·管理咨询招标监测任务启动")
    log(f"   数据来源  ：www.bidding.csg.cn/zbgg/（招标公告）")
    log(f"              + www.bidding.csg.cn/fzbgg/（非招标公告）")
    log(f"   回溯范围  ：最近 {CONFIG['lookback_days']} 天发布的公告")
    log(f"   有效性规则：文件获取截止时间 > 当前时间")
    log(f"   关键词数  ：{len(CONFIG['search_keywords'])} 个初筛 + 精筛")
    log("=" * 60)

    # ───── 统计数据 ─────
    stats = {
        "total_fetched": 0,        # 总共抓取到多少条公告
        "zb_cg_count": 0,          # 招标/采购公告数量
        "coarse_passed": 0,        # 通过粗筛（含关键词且不含排除词）
        "fine_passed": 0,          # 通过精筛（确认是企业管理咨询类）
        "detail_fetched": 0,       # 成功进入详情页检查的数量
        "valid": 0,                # 有效（未过期）数量
        "expired": 0,              # 已过期数量
        "time_extract_fail": 0,    # 时间提取失败数量
        "detail_fetch_fail": 0,    # 详情页获取失败数量
    }

    valid_items = []          # 最终有效公告
    seen_urls = set()         # 防止翻页时抓取重复（相对URL）
    valid_seen_urls = set()   # 防止 valid_items 中重复（绝对URL）

    today = datetime.now().date()
    cutoff_date = today - timedelta(days=CONFIG["lookback_days"])

    # ───── 两个频道并行遍历 ─────
    sources = [
        ("招标公告",   CONFIG["list_url"]),
        ("非招标公告", CONFIG["fzbgg_list_url"]),
    ]

    for src_name, base_url in sources:
        log(f"\n{'='*50}")
        log(f"[{src_name}] 开始抓取 {base_url}")
        log(f"{'='*50}")

        for page in range(1, CONFIG["max_list_pages"] + 1):
            log(f"  [{src_name}] 第 {page} 页...")
            html = fetch_list_page(page, base_url)
            if not html:
                log(f"    [警告] {src_name}列表页获取失败，停止翻页")
                break

            items = parse_list_page(html)
            log(f"    → 本页解析到 {len(items)} 条公告")
            stats["total_fetched"] += len(items)

            if not items:
                log(f"    → 本页无公告，停止翻页")
                break

            # 检查本页最旧公告是否已超出回溯范围
            dates = [it["pub_date"] for it in items if it.get("pub_date")]
            if dates and min(dates) < cutoff_date:
                log(f"    → 本页最旧公告 {min(dates)} 已超出范围（{cutoff_date}），停止翻页")
                items = [it for it in items if it.get("pub_date") is None or it["pub_date"] >= cutoff_date]
                if not items:
                    break

            # 对本页每条公告处理
            for item in items:
                url = item["url"]
                if url in seen_urls:
                    continue
                seen_urls.add(url)

                title = item["title"]

                # 统计：招标/采购公告
                if "招标" in title or "采购" in title:
                    stats["zb_cg_count"] += 1

                # 第一步：关键词粗筛 + 文本分析精筛
                passed, reason = is_relevant(title)
                if not passed:
                    log(f"    [过滤] {title[:35]}... [{reason}]")
                    continue
                stats["coarse_passed"] += 1
                stats["fine_passed"] += 1

                log(f"    [精筛] {title[:40]}... [{reason}]")

                # 第二步：点进详情页，检查有效期
                detail_html = fetch_html(item["detail_url"], retry=2)
                if not detail_html:
                    log(f"      [警告] 详情页获取失败，跳过")
                    stats["detail_fetch_fail"] += 1
                    time.sleep(1)
                    continue
                stats["detail_fetched"] += 1

                # 正文内容二次确认
                content = extract_detail_content(detail_html)
                is_rel, rel_reason = is_relevant(title, content)
                if not is_rel:
                    log(f"      [内容排除] {title[:30]}... [{rel_reason}]")
                    stats["content_excluded"] = stats.get("content_excluded", 0) + 1
                    continue
                log(f"      [内容确认] {rel_reason}")

                valid, times = is_valid_announcement(detail_html)
                if not valid:
                    fe = times.get("file_end")
                    if fe is None:
                        log(f"      [失败] 时间提取失败，跳过")
                        stats["time_extract_fail"] += 1
                    else:
                        log(f"      [过期] 截止：{fe}，跳过")
                        stats["expired"] += 1
                    time.sleep(0.5)
                    continue

                # 有效！
                stats["valid"] += 1
                item["file_start"]    = str(times.get("file_start") or "")
                item["file_end"]      = str(times.get("file_end")   or "")
                item["bid_deadline"]  = str(times.get("bid_deadline") or "")
                item["source"]        = src_name

                # 提取招标人/招标单位（多策略，优先级从高到低）
                org = None

                # 清理HTML标签后的纯文本
                clean_html = re.sub(r'<script[^>]*>.*?</script>', ' ', detail_html, flags=re.DOTALL | re.IGNORECASE)
                clean_html = re.sub(r'<style[^>]*>.*?</style>', ' ', clean_html, flags=re.DOTALL | re.IGNORECASE)
                clean_text = re.sub(r'<[^>]+>', ' ', clean_html)
                clean_text = re.sub(r'\s+', ' ', clean_text)

                # ★ 策略1：尝试从HTML表格结构中提取（通常在页面开头的项目信息表中）
                # 匹配格式如: <td>招标人</td><td>xxx公司</td>
                table_pattern = r'>(?:招标人|招标单位|采购人)[^\u4e00-\u9fa5]*</(?:td|div)>\s*<(?:td|div)[^>]*>\s*([^\s，,。<\n]{2,50}公司[^\s，,。<\n]*)'
                table_match = re.search(table_pattern, detail_html)
                if table_match:
                    potential_org = table_match.group(1).strip()
                    # 验证提取的是公司名称（应包含"公司"）
                    if '公司' in potential_org:
                        org = potential_org

                # ★ 策略2：传统正则，但排除常见误匹配词（如"有权开展现场核查"）
                if not org:
                    # 这些词后面跟的不是真正的招标单位
                    fake_org_patterns = [
                        "有权开展", "进行核查", "开展核查", "进行处理",
                        "追究法律责任", "进行处理", "列入黑名单",
                    ]
                    raw_pattern = r'招标[人单位][为：:\s]*([^\s，,。\n]{2,60})'
                    for org_match in re.finditer(raw_pattern, clean_text):
                        potential_org = org_match.group(1).strip()
                        # 排除假阳性
                        if any(fp in potential_org for fp in fake_org_patterns):
                            continue
                        # 排除不含"公司"且不是"中心"/"局"等单位的
                        if '公司' in potential_org or '中心' in potential_org or '局' in potential_org:
                            org = potential_org
                            break

                # ★ 策略3：从标题中提取公司名称作为兜底
                if not org:
                    title_org_patterns = [
                        r'^(南方电网[^，,。\s]{0,30}公司)',
                        r'^(海南电网[^，,。\s]{0,30}公司)',
                        r'^(广东电网[^，,。\s]{0,30}公司)',
                        r'^(广西电网[^，,。\s]{0,30}公司)',
                        r'^(云南电网[^，,。\s]{0,30}公司)',
                        r'^(贵州电网[^，,。\s]{0,30}公司)',
                        r'^(广州供电[^，,。\s]{0,30}(公司|局))',
                        r'^(深圳供电[^，,。\s]{0,30}(公司|局))',
                        r'^([^\s，。]{2,20}电网[^\s，。]{0,30}(公司|局))',
                    ]
                    for p in title_org_patterns:
                        m = re.match(p, item["title"])
                        if m:
                            org = m.group(1).strip()
                            break

                if org:
                    item["org"] = org
                    item["pub_date"] = item["pub_date"].strftime("%Y-%m-%d")

                detail_url = item["detail_url"]
                if detail_url in valid_seen_urls:
                    log(f"      [去重] 本次已有该公告，跳过")
                    continue
                valid_seen_urls.add(detail_url)
                valid_items.append(item)
                log(f"    [有效] 开始：{times.get('file_start')}｜截止：{times.get('file_end')}｜来源：{src_name}")

            time.sleep(1)  # 翻页间隔

        log(f"\n[{src_name}] 抓取完成")
        if src_name == "招标公告":
            log("[切换] 暂停2秒后切换至非招标公告频道...")
            time.sleep(2)

    # ───── 输出完整统计数据 ─────
    log("\n" + "=" * 60)
    log("[统计] 本次监测完整统计：")
    log("=" * 60)
    log(f"  ① 总共抓取到公告数　：{stats['total_fetched']} 条")
    log(f"  ② 招标/采购公告数　：{stats['zb_cg_count']} 条")
    log(f"  ③ 通过粗筛（含关键词）：{stats['coarse_passed']} 条")
    log(f"  ④ 通过精筛（企业管理咨询类）：{stats['fine_passed']} 条")
    log(f"  ⑤ 成功进入详情页检查：{stats['detail_fetched']} 条")
    log(f"  ⑥ 详情页获取失败　　：{stats['detail_fetch_fail']} 条")
    log(f"  ⑦ 时间提取失败　　　：{stats['time_extract_fail']} 条")
    log(f"  ⑧ 已过期（招标文件获取截止） ：{stats['expired']} 条")
    log(f"  ⑨ 有效（未过期）　　：{stats['valid']} 条")
    log("=" * 60)

    if not valid_items:
        log("ℹ️  暂无符合条件的有效招标公告")
        log("=" * 60)
        return

    # 写入 Excel（统计汇总 + 有效公告明细 + 详情链接为超链接）
    log(f"\n[写入] 写入 Excel（统计汇总Sheet + 公告明细Sheet）...")
    new_count, skip_count = write_to_excel(valid_items, stats)
    excel_path = SCRIPT_DIR / CONFIG["output_excel"]
    log(f"[有效] 完成！新增 {new_count} 条，跳过重复 {skip_count} 条")
    log(f"[文件] 文件：{excel_path}")

    # 打印有效公告摘要
    log("")
    log("─" * 60)
    log(f"[摘要] 本次新增有效企业管理咨询招标公告（共 {len(valid_items)} 条）：")
    log("─" * 60)
    for i, it in enumerate(valid_items, 1):
        fe = it.get('file_end', '?')
        log(f"  {i}. 【截止 {fe}】{it['title'][:50]}")
    log("─" * 60)

    log("")
    log("=" * 60)
    log("[完成] 监测任务完成！")
    log("=" * 60)


if __name__ == "__main__":
    main()
