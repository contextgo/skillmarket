# 南网招标监测·CONFIG 参数完整参考 (V7.2)

## CONFIG 字典完整参数

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `search_keywords` | list[str] | 32个词 | 初筛关键词，标题含任一即纳入候选 |
| `non_mgmt_consulting` | list[str] | 18个词 | 精筛排除词，含这些词的"咨询"标题将被过滤 |
| `title_exclude` | list[str] | 35+个词 | 直接排除，含任一即过滤，不进入后续阶段 |
| `lookback_days` | int | 7 | 回溯天数，建议 7~14 天 |
| `max_list_pages` | int | 20 | 最大翻页数，防止无限翻页 |
| `valid_buffer_hours` | int | 0 | 有效期缓冲小时数，0=截止时间未到即有效 |
| `output_excel` | str | 南网管理咨询招标公告.xlsx | Excel 输出文件名 |
| `list_url` | str | bidding.csg.cn/zbgg/... | 招标公告列表页 |
| `fzbgg_list_url` | str | bidding.csg.cn/fzbgg/... | 非招标公告（含询比采购）列表页 |

## 常量配置（一般不需修改）

```python
# Excel 表头（10列）
DATA_HEADERS = [
    "抓取日期", "公告标题", "招标单位", "发布日期",
    "文件获取开始时间", "文件获取截止时间", "投标递交截止时间",
    "详情链接", "来源", "公告URL",
]

# 统计指标（10项，对应统计汇总Sheet的10列）
STATS_LABELS = [
    ("total_fetched",      "总共抓取到公告数"),
    ("zb_cg_count",        "其中: 招标/采购公告数"),
    ("coarse_passed",      "通过粗筛（含搜索关键词）"),
    ("fine_passed",        "通过精筛（企业管理咨询类确认）"),
    ("detail_fetched",     "成功进入详情页检查"),
    ("detail_fetch_fail",  "详情页获取失败"),
    ("time_extract_fail",  "招标文件获取截止时间提取失败"),
    ("content_excluded",   "正文内容分析排除（非管理咨询类）"),
    ("expired",            "已过期（招标文件获取截止时间已过）"),
    ("valid",              "有效（未过期，已写入本表）"),
]

# 有效公告Sheet列宽（V7.2：J列改为50，不再隐藏）
DATA_WIDTHS = [13, 55, 28, 12, 20, 20, 20, 50, 12, 50]
# 统计汇总Sheet列宽
STATS_WIDTHS = [14, 16, 18, 18, 22, 18, 16, 24, 22, 14, 14, 14]
```

## Excel 结构说明（V7.2）

### Sheet1「统计汇总」
12列：执行日期 + 10项统计指标 + 备注

### Sheet2「有效公告」
10列：DATA_HEADERS 定义

**V7.2 重要变更**：J列（公告URL列）宽从0改为50，不再隐藏。
- 原因：J列宽度为0且被隐藏时，Excel会出现行高异常（行间距过大）
- 修复：将J列宽设为50（与H列详情链接同宽），取消隐藏属性
