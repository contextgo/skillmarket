# URL

Generate a claude-sessions web URL from a session ID.

## URL Format

```
http://localhost:5174/#project={project-key}&session={session-id}
```

## Project Key Conversion

| Environment | Path | Project Key |
|-------------|------|-------------|
| Windows | `C:\Users\user\path\repo` | `C--Users-user-path-repo` |
| WSL | `/mnt/c/Users/user/path/repo` | `-mnt-c-Users-user-path-repo` |
| macOS | `/Users/es6kr/path/repo` | `-Users-es6kr-path-repo` |

Rule: Replace all non-alphanumeric characters with `-`

## Procedure

### 1. Get Session ID

Use `/session id` for the current session, or receive an ID directly.

### 2. Generate Project Key

Derive from CWD automatically:

```bash
# Windows (Git Bash)
pwd | sed 's|^/c/|C--| ; s|/|-|g'

# WSL
pwd | sed 's|/|-|g ; s|^-||'
```

### 3. Compose URL

```
http://localhost:5174/#project={project-key}&session={session-id}
```

## Usage

```bash
/session url                    # URL for current session
/session url <session-id>       # URL for a specific session
```

## Notes

- Active sessions may not load in claude-sessions (jsonl not yet closed)
- Project-only view: `http://localhost:5174/#project={project-key}` (omit session param)
