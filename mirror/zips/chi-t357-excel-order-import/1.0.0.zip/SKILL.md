---
name: excel-order-import
description: 将 Excel 订单资料汇入 MS SQL 数据库（正航T357）。使用时机：用户要汇入 Excel 订购单到数据库、要把正航T357订单资料写入 MS SQL、要把 Excel 转成 SQL INSERT。
---

# Excel 订单汇入 SKILL

将 Excel 格式的订单资料汇入 MS SQL 数据库的 `ordBillMain`（订单主档）和 `ordBillSub`（订单明细）表格。

## 用途

将 Excel 格式的订单资料汇入到 MS SQL 数据库。

## 前提

- MS SQL Server 已安装并可连接
- Excel 档案格式：
  - 第1行：栏位名称（英文）
  - 第2行：栏位名称（中文）
  - 第3行：资料

## 用法

```bash
python3 /home/tsai/.openclaw/workspace/excel_order_import.py <Excel文件路径> <SQL Server IP>
```

例如：
```bash
python3 /home/tsai/.openclaw/workspace/excel_order_import.py /home/tsai/文件/ord_20260310001.xlsx 192.168.1.41
```

## Excel 格式

### 訂單主檔 (ordBillMain)

必须包含的栏位：
- BillNO（订单号码）
- BillDate（订单日期）
- CustomerID（客户代号）
- CustomerName（客户名称）
- 其他栏位可以为空白

### 訂單明細 (ordBillSub)

必须包含的栏位：
- BillNO（订单号码，需与主档相同）
- RowNO（明细序号）
- SerNO（序号）
- ProdID（产品代号）
- ProdName（产品名称）
- Quantity（数量）
- 其他栏位可以为空白

## 数据库连接

预设连接资讯：
- Server: <IP>\chixm
- User: sa
- Password: chi
- Database: CHIComp07

## 注意事项

1. 中文栏位使用 N'' 语法储存（支持 Big5 编码）
2. 空值会自动转为空白字串
3. 订单号码不可重复（否则会报错）
