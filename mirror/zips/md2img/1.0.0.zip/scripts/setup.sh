#!/usr/bin/env bash
# setup.sh — Check and install dependencies for md2img skill
# Safe to run multiple times — skips already-installed components.

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

NEED_NPM_INSTALL=false
NEED_CHROMIUM=false
ALL_OK=true

echo "🔍 Checking environment..."
echo ""

# ── 1. Node.js ──────────────────────────────────────────────────────────────
if ! command -v node &>/dev/null; then
  echo "❌ Node.js not found."
  echo "   Install it with: brew install node"
  exit 1
fi

NODE_VER=$(node -e "console.log(process.versions.node.split('.')[0])")
if [ "$NODE_VER" -lt 16 ]; then
  echo "❌ Node.js 16+ required. Current: $(node --version)"
  echo "   Upgrade with: brew upgrade node"
  exit 1
fi
echo "✅ Node.js $(node --version) — OK"

# ── 2. npm packages ──────────────────────────────────────────────────────────
check_pkg() {
  node -e "require('$1')" 2>/dev/null
}

MISSING_PKGS=()
for pkg in playwright marked highlight.js; do
  if check_pkg "$pkg"; then
    echo "✅ npm:$pkg — already installed"
  else
    echo "⬇️  npm:$pkg — missing"
    MISSING_PKGS+=("$pkg")
    NEED_NPM_INSTALL=true
  fi
done

# ── 3. Playwright Chromium browser ──────────────────────────────────────────
# Use `playwright install --dry-run` to check if Chromium is already present
CHROMIUM_STATUS=$(npx playwright install --dry-run chromium 2>&1 || true)
if echo "$CHROMIUM_STATUS" | grep -q "chromium.*already installed\|browser.*up to date\|Skipping"; then
  echo "✅ Playwright Chromium — already installed"
elif node -e "
const {chromium}=require('playwright');
const p=chromium.executablePath();
const fs=require('fs');
process.exit(fs.existsSync(p)?0:1);
" 2>/dev/null; then
  echo "✅ Playwright Chromium — already installed"
else
  echo "⬇️  Playwright Chromium — missing"
  NEED_CHROMIUM=true
fi

echo ""

# ── Install only what's missing ──────────────────────────────────────────────
if [ "$NEED_NPM_INSTALL" = true ]; then
  # Create package.json if missing
  if [ ! -f package.json ]; then
    cat > package.json <<'EOF'
{
  "name": "md2img",
  "version": "1.0.0",
  "description": "Markdown to high-DPI image converter",
  "main": "md2img.js",
  "dependencies": {
    "playwright": "^1.44.0",
    "marked": "^12.0.0",
    "highlight.js": "^11.9.0"
  }
}
EOF
  fi

  echo "📦 Installing missing npm packages: ${MISSING_PKGS[*]}"
  # Try official registry first, fall back to mirror
  npm install --prefer-offline 2>/dev/null \
    || npm install --registry https://registry.npmmirror.com
  echo ""
fi

if [ "$NEED_CHROMIUM" = true ]; then
  echo "🌐 Installing Playwright Chromium browser..."
  npx playwright install chromium
  echo ""
fi

if [ "$NEED_NPM_INSTALL" = false ] && [ "$NEED_CHROMIUM" = false ]; then
  echo "🎉 Everything already installed — nothing to do!"
else
  echo "✅ Setup complete!"
fi

echo ""
echo "📌 Usage:"
echo "   node md2img.js <your-file.md>"
echo "   node md2img.js <your-file.md> --theme dark"
echo "   node md2img.js <your-file.md> -f jpeg -q 92"
