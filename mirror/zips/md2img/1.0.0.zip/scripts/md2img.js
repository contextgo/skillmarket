#!/usr/bin/env node
/**
 * md2img.js — Markdown → High-DPI Screenshot
 *
 * Designed for:
 *   - iPhone Retina clarity (3x deviceScaleFactor)
 *   - WeChat Moments sharing (survives WeChat compression)
 *
 * Usage:
 *   node md2img.js <input.md> [options]
 *
 * Options:
 *   -o, --output <path>       Output image path (default: <input>.png)
 *   -w, --width <px>          Logical viewport width in CSS px (default: 390)
 *   -s, --scale <n>           Device scale factor (default: 3)
 *   -f, --format <png|jpeg>   Output format (default: png)
 *   -q, --quality <0-100>     JPEG quality (default: 92, ignored for PNG)
 *   --theme <light|dark>      Color theme (default: light)
 *   --padding <px>            Body padding in CSS px (default: 28)
 *   --font-size <px>          Base font size in CSS px (default: 17)
 *   --no-code-highlight       Disable syntax highlighting
 *   --multi                   Split output into multiple images (one per H1 section)
 *
 * Requirements (auto-installed by SKILL.md workflow):
 *   npm install playwright marked highlight.js
 *   npx playwright install chromium
 */

'use strict';

const fs = require('fs');
const path = require('path');
const { chromium } = require('playwright');
const { marked } = require('marked');
const hljs = require('highlight.js');

// ─── CLI parsing ────────────────────────────────────────────────────────────

function parseArgs(argv) {
  const args = argv.slice(2);
  const opts = {
    input: null,
    output: null,
    width: 390,       // iPhone 14 logical width (CSS px)
    scale: 3,         // 3× → 1170px physical (survives WeChat compression)
    format: 'png',
    quality: 92,
    theme: 'light',
    padding: 28,
    fontSize: 17,
    codeHighlight: true,
    multi: false,
  };

  for (let i = 0; i < args.length; i++) {
    const a = args[i];
    if (!a.startsWith('-')) { opts.input = a; continue; }
    const next = () => args[++i];
    switch (a) {
      case '-o': case '--output':        opts.output = next(); break;
      case '-w': case '--width':         opts.width = parseInt(next()); break;
      case '-s': case '--scale':         opts.scale = parseFloat(next()); break;
      case '-f': case '--format':        opts.format = next(); break;
      case '-q': case '--quality':       opts.quality = parseInt(next()); break;
      case '--theme':                    opts.theme = next(); break;
      case '--padding':                  opts.padding = parseInt(next()); break;
      case '--font-size':                opts.fontSize = parseInt(next()); break;
      case '--no-code-highlight':        opts.codeHighlight = false; break;
      case '--multi':                    opts.multi = true; break;
    }
  }

  if (!opts.input) {
    console.error('Usage: node md2img.js <input.md> [options]');
    process.exit(1);
  }
  if (!opts.output) {
    const ext = opts.format === 'jpeg' ? 'jpg' : 'png';
    opts.output = opts.input.replace(/\.md$/i, '') + '.' + ext;
  }
  return opts;
}

// ─── Markdown → HTML ─────────────────────────────────────────────────────────

function renderMarkdown(mdText, opts) {
  marked.setOptions({
    highlight: opts.codeHighlight
      ? (code, lang) => {
          const language = hljs.getLanguage(lang) ? lang : 'plaintext';
          return hljs.highlight(code, { language }).value;
        }
      : null,
    langPrefix: 'hljs language-',
    breaks: true,
    gfm: true,
  });
  return marked(mdText);
}

// ─── CSS themes ──────────────────────────────────────────────────────────────

function getThemeCSS(theme, fontSize, padding) {
  const isDark = theme === 'dark';
  const bg = isDark ? '#1a1a1a' : '#ffffff';
  const text = isDark ? '#e8e8e8' : '#1a1a1a';
  const subtext = isDark ? '#a0a0a0' : '#666666';
  const border = isDark ? '#333' : '#e5e5e5';
  const codeBg = isDark ? '#2a2a2a' : '#f6f8fa';
  const codeText = isDark ? '#e8e8e8' : '#333';
  const blockquoteBg = isDark ? '#252525' : '#f8f9fa';
  const blockquoteBorder = isDark ? '#4a9eff' : '#0969da';
  const tableBg = isDark ? '#222' : '#fff';
  const tableAlt = isDark ? '#2a2a2a' : '#f6f8fa';

  return `
    /* ── Reset & Base ── */
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    html, body {
      background: ${bg};
      color: ${text};
      font-family: -apple-system, 'PingFang SC', 'Hiragino Sans GB',
                   'Microsoft YaHei', 'Segoe UI', sans-serif;
      font-size: ${fontSize}px;
      line-height: 1.75;
      -webkit-font-smoothing: antialiased;
      -moz-osx-font-smoothing: grayscale;
    }

    .md-body {
      max-width: 100%;
      padding: ${padding}px;
      word-break: break-word;
      overflow-wrap: break-word;
    }

    /* ── Headings ── */
    h1, h2, h3, h4, h5, h6 {
      font-weight: 700;
      line-height: 1.35;
      margin-top: 1.4em;
      margin-bottom: 0.5em;
      color: ${text};
    }
    h1 { font-size: 1.65em; border-bottom: 2px solid ${border}; padding-bottom: 0.3em; margin-top: 0.5em; }
    h2 { font-size: 1.35em; border-bottom: 1px solid ${border}; padding-bottom: 0.2em; }
    h3 { font-size: 1.15em; }
    h4 { font-size: 1.05em; }
    h5, h6 { font-size: 0.95em; color: ${subtext}; }

    /* ── Paragraph & spacing ── */
    p { margin: 0.8em 0; }
    a { color: #0969da; text-decoration: none; }
    a:hover { text-decoration: underline; }

    /* ── Lists ── */
    ul, ol { margin: 0.6em 0 0.6em 1.5em; }
    li { margin: 0.25em 0; }
    li > ul, li > ol { margin: 0.2em 0 0.2em 1.2em; }

    /* ── Inline code ── */
    code {
      background: ${codeBg};
      color: ${codeText};
      font-family: 'SF Mono', 'Fira Code', 'Consolas', monospace;
      font-size: 0.88em;
      padding: 0.15em 0.4em;
      border-radius: 4px;
    }

    /* ── Code blocks ── */
    pre {
      background: ${codeBg};
      border-radius: 8px;
      overflow-x: auto;
      padding: 1em 1.1em;
      margin: 1em 0;
      font-size: 0.85em;
      line-height: 1.6;
      border: 1px solid ${border};
    }
    pre code {
      background: none;
      padding: 0;
      font-size: inherit;
      border-radius: 0;
    }

    /* ── Blockquote ── */
    blockquote {
      background: ${blockquoteBg};
      border-left: 4px solid ${blockquoteBorder};
      border-radius: 0 6px 6px 0;
      padding: 0.6em 1em;
      margin: 1em 0;
      color: ${subtext};
    }
    blockquote p { margin: 0.3em 0; }

    /* ── Horizontal rule ── */
    hr {
      border: none;
      border-top: 1px solid ${border};
      margin: 1.5em 0;
    }

    /* ── Images ── */
    img {
      max-width: 100%;
      border-radius: 6px;
      display: block;
      margin: 0.8em auto;
    }

    /* ── Tables ── */
    table {
      border-collapse: collapse;
      width: 100%;
      margin: 1em 0;
      font-size: 0.92em;
      background: ${tableBg};
      border-radius: 8px;
      overflow: hidden;
    }
    th, td {
      border: 1px solid ${border};
      padding: 0.5em 0.8em;
      text-align: left;
    }
    th {
      background: ${codeBg};
      font-weight: 600;
    }
    tr:nth-child(even) td { background: ${tableAlt}; }

    /* ── Task list ── */
    input[type="checkbox"] { margin-right: 0.4em; }

    /* ── Highlight.js theme (GitHub-style) ── */
    .hljs-keyword, .hljs-selector-tag, .hljs-literal, .hljs-built_in { color: ${isDark ? '#ff7b72' : '#cf222e'}; }
    .hljs-string, .hljs-title, .hljs-name { color: ${isDark ? '#a5d6ff' : '#0a3069'}; }
    .hljs-comment, .hljs-quote { color: ${isDark ? '#8b949e' : '#6e7781'}; font-style: italic; }
    .hljs-number, .hljs-symbol { color: ${isDark ? '#79c0ff' : '#0550ae'}; }
    .hljs-attr, .hljs-variable, .hljs-template-variable { color: ${isDark ? '#ffa657' : '#953800'}; }
    .hljs-type, .hljs-class .hljs-title { color: ${isDark ? '#e3b341' : '#24292f'}; }
    .hljs-regexp, .hljs-link { color: ${isDark ? '#7ee787' : '#116329'}; }

    /* ── Footer watermark (optional) ── */
    .md-footer {
      margin-top: 2em;
      padding-top: 0.8em;
      border-top: 1px solid ${border};
      font-size: 0.78em;
      color: ${subtext};
      text-align: center;
    }
  `;
}

// ─── Build full HTML ──────────────────────────────────────────────────────────

function buildHTML(bodyHTML, opts) {
  const css = getThemeCSS(opts.theme, opts.fontSize, opts.padding);
  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>md2img</title>
  <style>${css}</style>
</head>
<body>
  <div class="md-body">
    ${bodyHTML}
  </div>
</body>
</html>`;
}

// ─── Screenshot (single) ─────────────────────────────────────────────────────

async function screenshot(page, outputPath, opts) {
  const screenshotOpts = {
    path: outputPath,
    fullPage: true,
    type: opts.format === 'jpeg' ? 'jpeg' : 'png',
  };
  if (opts.format === 'jpeg') screenshotOpts.quality = opts.quality;
  await page.screenshot(screenshotOpts);
}

// ─── Split into sections by H1 ───────────────────────────────────────────────

function splitByH1(mdText) {
  const lines = mdText.split('\n');
  const sections = [];
  let current = [];
  let hasH1 = false;

  for (const line of lines) {
    if (/^# /.test(line)) {
      if (hasH1 && current.length) sections.push(current.join('\n'));
      current = [line];
      hasH1 = true;
    } else {
      current.push(line);
    }
  }
  if (current.length) sections.push(current.join('\n'));
  return sections.length ? sections : [mdText];
}

// ─── Main ────────────────────────────────────────────────────────────────────

async function main() {
  const opts = parseArgs(process.argv);

  if (!fs.existsSync(opts.input)) {
    console.error(`File not found: ${opts.input}`);
    process.exit(1);
  }

  const mdText = fs.readFileSync(opts.input, 'utf8');
  const sections = opts.multi ? splitByH1(mdText) : [mdText];

  console.log(`📄 Input:  ${opts.input}`);
  console.log(`🖼  Format: ${opts.format.toUpperCase()}${opts.format === 'jpeg' ? ` (quality ${opts.quality})` : ''}`);
  console.log(`📐 Viewport: ${opts.width}px × ${opts.scale}× = ${opts.width * opts.scale}px physical width`);
  console.log(`🎨 Theme: ${opts.theme}`);

  const browser = await chromium.launch({ headless: true });
  const outputs = [];

  for (let i = 0; i < sections.length; i++) {
    const bodyHTML = renderMarkdown(sections[i], opts);
    const html = buildHTML(bodyHTML, opts);

    // CRITICAL: deviceScaleFactor must be set at context level, NOT page level.
    // This is the correct way to get true Retina (physical) pixels in Playwright.
    const context = await browser.newContext({
      deviceScaleFactor: opts.scale,
      viewport: {
        width: opts.width,
        height: 800,  // initial height; fullPage screenshot ignores this
      },
    });
    const page = await context.newPage();

    await page.setContent(html, { waitUntil: 'networkidle' });
    // Wait for fonts and layout to stabilize
    await page.waitForTimeout(300);

    let outPath = opts.output;
    if (sections.length > 1) {
      const ext = path.extname(opts.output);
      const base = opts.output.slice(0, -ext.length);
      outPath = `${base}_${String(i + 1).padStart(2, '0')}${ext}`;
    }

    await screenshot(page, outPath, opts);
    outputs.push(outPath);
    console.log(`✅ Saved: ${outPath}`);
    await context.close();
  }

  await browser.close();

  // Print summary
  console.log('\n📊 Summary:');
  for (const out of outputs) {
    const stat = fs.statSync(out);
    const kb = (stat.size / 1024).toFixed(1);
    console.log(`   ${path.basename(out)}  (${kb} KB)`);
  }
  console.log('\n✨ Done! Optimized for iPhone + WeChat Moments sharing.');
}

main().catch(err => {
  console.error('Error:', err.message);
  process.exit(1);
});
