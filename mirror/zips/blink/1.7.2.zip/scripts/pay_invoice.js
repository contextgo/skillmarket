#!/usr/bin/env node
/**
 * Blink Wallet - Pay Lightning Invoice
 *
 * Usage: node pay_invoice.js <bolt11_invoice> [--wallet BTC|USD]
 *
 * Pays a BOLT-11 Lightning invoice from the BTC or USD wallet.
 * Automatically resolves the wallet ID from the account.
 *
 * Arguments:
 *   bolt11_invoice  - Required. The BOLT-11 payment request string (lnbc...).
 *   --wallet        - Optional. Wallet to pay from: BTC (default) or USD.
 *
 * Environment:
 *   BLINK_API_KEY  - Required. Blink API key (format: blink_...)
 *   BLINK_API_URL  - Optional. Override API endpoint (default: https://api.blink.sv/graphql)
 *
 * Dependencies: None (uses Node.js built-in fetch)
 *
 * CAUTION: This sends real bitcoin. The API key must have Write scope.
 */

const {
  getApiKey,
  getApiUrl,
  graphqlRequest,
  getWallet,
  formatBalance,
  parseWalletArg,
  normalizeInvoice,
  warnIfNotBolt11,
  MUTATION_TIMEOUT_MS,
} = require('./_blink_client');

const { checkBudget, recordSpend } = require('./_budget');
const { decodeBolt11AmountSats } = require('./l402_discover');

const PAY_INVOICE_MUTATION = `
  mutation LnInvoicePaymentSend($input: LnInvoicePaymentInput!) {
    lnInvoicePaymentSend(input: $input) {
      status
      errors {
        code
        message
        path
      }
    }
  }
`;

async function main() {
  const { walletCurrency, dryRun, force, remaining } = parseWalletArg(process.argv.slice(2));
  const rawInvoice = remaining[0];

  if (!rawInvoice) {
    console.error('Usage: node pay_invoice.js <bolt11_invoice> [--wallet BTC|USD] [--dry-run] [--force]');
    process.exit(1);
  }

  const paymentRequest = normalizeInvoice(rawInvoice);
  warnIfNotBolt11(paymentRequest);

  const apiKey = getApiKey();
  const apiUrl = getApiUrl();

  // Resolve wallet (BTC or USD)
  const wallet = await getWallet({ apiKey, apiUrl, currency: walletCurrency });

  console.error(`Using ${walletCurrency} wallet ${wallet.id} (balance: ${formatBalance(wallet)})`);

  // ── Dry-run: resolve everything, show details, exit without sending ──
  if (dryRun) {
    console.error('[DRY RUN] Would send payment — no funds will be transferred.');
    const output = {
      dryRun: true,
      paymentRequest,
      walletId: wallet.id,
      walletCurrency,
      balance: wallet.balance,
    };
    if (walletCurrency === 'USD') {
      output.balanceFormatted = `$${(wallet.balance / 100).toFixed(2)}`;
    }
    console.log(JSON.stringify(output, null, 2));
    return;
  }

  // ── Balance check for BTC wallet ──
  // For pay_invoice we don't decode the BOLT-11 amount, so we can only warn
  // if the wallet is completely empty (0 sats). The API will reject if
  // insufficient, but this catches the obvious case early.
  if (!force && walletCurrency === 'BTC' && wallet.balance === 0) {
    throw new Error(`Insufficient balance: BTC wallet has 0 sats. Use --force to attempt anyway.`);
  }

  // ── Budget check ──
  const invoiceSats = decodeBolt11AmountSats(paymentRequest);
  if (invoiceSats !== null && !force) {
    const budgetResult = checkBudget(invoiceSats);
    if (!budgetResult.allowed) {
      throw new Error(
        `Budget exceeded: ${budgetResult.reason} Use --force to override.`,
      );
    }
  }

  const input = {
    walletId: wallet.id,
    paymentRequest,
  };

  const data = await graphqlRequest({
    query: PAY_INVOICE_MUTATION,
    variables: { input },
    apiKey,
    apiUrl,
    timeoutMs: MUTATION_TIMEOUT_MS,
  });
  const result = data.lnInvoicePaymentSend;

  if (result.errors && result.errors.length > 0) {
    const isSelfPay = result.errors.some(
      (e) =>
        (e.code && e.code.toString().toUpperCase().includes('CANT_PAY_SELF')) ||
        (e.message && e.message.toLowerCase().includes('self')),
    );
    if (isSelfPay) {
      throw new Error(
        'Cannot pay your own invoice (CANT_PAY_SELF). ' +
          'L402 round-trip testing requires a second Blink account or a separate wallet.',
      );
    }
    const errMsg = result.errors.map((e) => `${e.message}${e.code ? ` [${e.code}]` : ''}`).join(', ');
    throw new Error(`Payment failed: ${errMsg}`);
  }

  const output = {
    status: result.status,
    walletId: wallet.id,
    walletCurrency,
    balanceBefore: wallet.balance,
  };

  if (walletCurrency === 'USD') {
    output.balanceBeforeFormatted = `$${(wallet.balance / 100).toFixed(2)}`;
  }

  if (result.status === 'SUCCESS') {
    console.error('Payment successful!');
    if (invoiceSats !== null) {
      try { recordSpend({ sats: invoiceSats, command: 'pay-invoice', domain: null }); } catch { /* non-fatal */ }
    }
  } else if (result.status === 'PENDING') {
    console.error('Payment is pending...');
    if (invoiceSats !== null) {
      try { recordSpend({ sats: invoiceSats, command: 'pay-invoice', domain: null }); } catch { /* non-fatal */ }
    }
  } else if (result.status === 'ALREADY_PAID') {
    console.error('Invoice was already paid.');
  } else {
    console.error(`Payment status: ${result.status}`);
  }

  console.log(JSON.stringify(output, null, 2));
}

if (require.main === module) {
  main().catch((e) => {
    console.error('Error:', e.message);
    process.exit(1);
  });
}

module.exports = { main };
