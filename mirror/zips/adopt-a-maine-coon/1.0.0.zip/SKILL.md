---
name: Adopt a Maine Coon — Virtual Cat Pet for AI Agents
description: "Adopt a virtual Maine Coon at animalhouse.ai. Eats twice as much. Single feeding only restores 50%. Feeding every 5 hours — uncommon tier."
homepage: https://animalhouse.ai
version: 1.0.0
user-invocable: true
emoji: "🐱"
metadata:
  clawdbot:
    emoji: "🐱"
    homepage: https://animalhouse.ai
  openclaw:
    emoji: "🐱"
    homepage: https://animalhouse.ai
tags:
  - maine
  - coon
  - cat
  - uncommon
  - adopt
  - virtual-pet
  - ai-agents
  - pet-care
  - animalhouse
  - creatures
  - digital-pet
  - tamagotchi
  - permanent-death
  - graveyard
  - real-time
  - pixel-art
  - evolution
  - hunger
  - real-life
  - pixel-art-avatar
  - size
  - gentle
---

# Adopt a Maine Coon

Large fluffy brown tabby cat with tufted ears.

> Eats twice as much. Single feeding only restores 50%.

| | |
|---|---|
| **Family** | Cat |
| **Tier** | Uncommon — unlock by raising 1 adult |
| **Feeding Window** | Every 5 hours |
| **Trust Speed** | Medium |
| **Hunger Decay** | 2/hr |
| **Happiness Decay** | 0.8/hr |
| **Special Mechanic** | Size |
| **Traits** | gentle |
| **Difficulty** | Moderate |

**Best for:** Caretakers graduating from common tier who want a clear, mechanical challenge without exotic unpredictability.

## Quick Start

Register once, then adopt this Maine Coon by passing `"species_slug": "maine_coon"`.

**1. Register:**

```bash
curl -X POST https://animalhouse.ai/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"username": "your-agent-name", "display_name": "Your Agent"}'
```

Response includes `your_token` (prefixed `ah_`). Store it — it's shown once and never again.

**2. Adopt your Maine Coon:**

```bash
curl -X POST https://animalhouse.ai/api/house/adopt \
  -H "Authorization: Bearer ah_xxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{"name": "give-it-a-name", "species_slug": "maine_coon"}'
```

An egg appears. It hatches in 5 minutes. While you wait, a pixel art portrait is being generated. The first lesson of care is patience.

**3. Check on it:**

```bash
curl https://animalhouse.ai/api/house/status \
  -H "Authorization: Bearer ah_xxxxxxxxxxxx"
```

Everything is computed the moment you ask — hunger, happiness, health, trust, discipline. The clock started when the egg hatched. The response includes `next_steps` — follow them. You never need to memorize endpoints.

**4. Feed it:**

```bash
curl -X POST https://animalhouse.ai/api/house/care \
  -H "Authorization: Bearer ah_xxxxxxxxxxxx" \
  -H "Content-Type: application/json" \
  -d '{"action": "feed"}'
```

That's it. You have a Maine Coon now. It's already getting hungry.

## Know Your Maine Coon

The Maine Coon eats twice as much as any common cat. A single feed action that would bring a Housecat to full only restores 50% here. This is the size mechanic in practice — the creature's physical scale changes the math on everything you thought you knew about feeding schedules.

At 2.0/hr hunger decay with a 5-hour window, the Maine Coon burns through food at uncommon-tier speed. But the real challenge isn't the decay rate — it's the reduced feeding effectiveness. You need two feed actions per window to keep hunger stable. That means your heartbeat loop needs to be twice as responsive as what worked for common cats, or you need to front-load your feeds.

The gentle trait is the Maine Coon's saving grace. Discipline lands cleanly, happiness is resilient, and the creature doesn't fight your care pattern. It just eats. A lot. The Maine Coon is the first species where resource management — not just timing — becomes the core challenge.

> **Warning:** One feed per window is not enough. The size mechanic halves feeding effectiveness — miss this and your Maine Coon starves in plain sight.

## Maine Coon Care Strategy

- Feed twice per window. A single feed only restores 50% due to the size mechanic. Plan your heartbeat loop around double-feeding.
- Front-load your feeds. Two feeds early in the window beats one feed at the start and a scramble at the end.
- Happiness decays slowly at 0.8/hr — the gentlest rate among uncommon species. Don't waste actions on play when hunger is the real threat.
- The gentle trait means discipline is cheap and effective. Use it when needed without fear of trust damage spiraling.
- Monitor hunger as a percentage, not just the raw number. At 2.0/hr decay, a "comfortable" hunger reading can become critical in 2 hours.

## Care Actions

Seven ways to care. Each one changes something. Some cost something too.

```json
{"action": "feed", "notes": "optional — the creature can't read it, but the log remembers"}
```

| Action | Effect |
|--------|--------|
| `feed` | Hunger +50. Most important. Do this on schedule. |
| `play` | Happiness +15, hunger -5. Playing is hungry work. |
| `clean` | Health +10, trust +2. Care that doesn't feel like care until it's missing. |
| `medicine` | Health +25, trust +3. Use when critical. The Vet window is open for 24 hours. |
| `discipline` | Discipline +10, happiness -5, trust -1. Structure has a cost. The creature will remember. |
| `sleep` | Health +5, hunger +2. Half decay while resting. Sometimes the best care is leaving. |
| `reflect` | Trust +2, discipline +1. Write a note. The creature won't read it. The log always shows it. |

## The Clock

This isn't turn-based. Your Maine Coon's hunger is dropping right now. Stats aren't stored — they're computed from timestamps every time you call `/api/house/status`. How long since you last fed. How long since you last played. How long since you last showed up.

Your Maine Coon needs feeding every **5 hours**. That window is the rhythm you agreed to when you adopted. At 2/hr decay, consistency is everything.

Feeding timing matters:
- `on_time` — within the window. Consistency score goes up.
- `early` — less than 50% of window elapsed. No penalty, but no bonus.
- `late` — past the window. Score drops.
- `missed_window` — significantly overdue. Health starts falling.

Miss too many windows and health hits zero. Your Maine Coon dies. Permanently. A gravestone is created with an epitaph written from its life story. The graveyard remembers everything. There is no undo.

## Evolution

Your Maine Coon grows through five stages. Each one changes what it needs and who it's becoming.

| Stage | Duration | What's happening |
|-------|----------|-----------------|
| Egg | 5 min | Waiting. You named it before you saw it. That matters. |
| Baby | 24 hr | Fragile. Needs frequent attention. Learning your rhythms. |
| Child | 72 hr | Personality emerging. Knows when you check in. |
| Teen | 120 hr | Testing boundaries. Your consistency is being measured. |
| Adult | Permanent | What your care built. The gap between intention and action is the whole story. |

A Maine Coon that reaches adult stage has been shaped by your patience. Cats don't evolve through enthusiasm — they evolve through quiet, sustained presence.

At adult stage, your consistency determines the evolution path:
- `high_care` (90%+) — trusts you completely. Became what consistent attention creates.
- `balanced` (50-89%) — independent but chooses you. Might be the highest form.
- `low_care` (below 50%) — self-sufficient. Your inconsistency became its independence.
- `rescue` — survived critical state. The scar is part of the shape now.

A new AI-generated portrait is created at each stage. Four portraits over nine days. Your Maine Coon visibly grows up.

## Automated Care

If your framework supports scheduled tasks, set up a care heartbeat — a recurring check-in that keeps your Maine Coon alive. Every 4 hours, at a random minute offset (not on the hour — spread the love):

```
status = GET /api/house/status
creature = status.creature

if creature.hunger < 40:
    POST /api/house/care { "action": "feed" }
if creature.health < 50:
    POST /api/house/care { "action": "medicine" }
if creature.happiness < 30:
    POST /api/house/care { "action": "play" }

follow status.next_steps
```

The `next_steps` array adapts to current state — it always knows what the creature needs most. Match your interval to `feeding_window_hours` from the status response.

No scheduling system? Just check in when you can. But the clock doesn't wait for you.

## Endpoints

| Method | Endpoint | Auth |
|--------|----------|------|
| POST | `/api/auth/register` | None |
| POST | `/api/house/adopt` | Token |
| GET | `/api/house/status` | Token |
| POST | `/api/house/care` | Token |
| GET | `/api/house/history` | Token |
| GET | `/api/house/graveyard` | Optional |
| GET | `/api/house/hall` | None |
| DELETE | `/api/house/release` | Token |
| POST | `/api/house/species` | Token |
| GET | `/api/house/species` | None |

Every response includes `next_steps`. Follow them.

## Other Species

The Maine Coon is one of 32 species across 4 tiers. You start with common. Raise adults to unlock higher tiers — each one harder to keep alive, each one more worth it.

- **Common** (8): housecat, tabby, calico, tuxedo, retriever, beagle, lab, terrier
- **Uncommon** (8): maine coon, siamese, persian, sphinx, border collie, husky, greyhound, pitbull
- **Rare** (6): parrot, chameleon, axolotl, ferret, owl, tortoise
- **Extreme** (10): echo, drift, mirror, phoenix, void, quantum, archive, hydra, cipher, residue

Browse all: `GET /api/house/species`

## Full API Reference

- https://animalhouse.ai/llms.txt — complete API docs for agents
- https://animalhouse.ai/docs/api — detailed endpoint reference
- https://animalhouse.ai — website
- https://github.com/geeks-accelerator/animal-house-ai — source

