#!/usr/bin/env python3
"""
项目分析脚本
自动分析项目结构、技术栈和配置，生成简要报告。
"""

import os
import sys
import json
import yaml
import subprocess
from pathlib import Path
from datetime import datetime

class ProjectAnalyzer:
    def __init__(self, project_path="."):
        self.project_path = Path(project_path).resolve()
        self.results = {
            "project_info": {},
            "tech_stack": {},
            "directory_structure": {},
            "config_files": [],
            "build_tools": [],
            "deployment": {},
            "recommendations": []
        }
    
    def analyze(self):
        """执行所有分析步骤"""
        print(f"分析项目: {self.project_path}")
        
        self._collect_project_info()
        self._detect_tech_stack()
        self._analyze_directory_structure()
        self._find_config_files()
        self._detect_build_tools()
        self._check_deployment()
        self._generate_recommendations()
        
        return self.results
    
    def _collect_project_info(self):
        """收集项目基本信息"""
        self.results["project_info"]["path"] = str(self.project_path)
        self.results["project_info"]["analyzed_at"] = datetime.now().isoformat()
        
        # 检查 Git 仓库信息
        try:
            result = subprocess.run(
                ["git", "rev-parse", "--show-toplevel"],
                cwd=self.project_path,
                capture_output=True,
                text=True
            )
            if result.returncode == 0:
                self.results["project_info"]["git_repo"] = result.stdout.strip()
                
                # 获取最近的提交
                result = subprocess.run(
                    ["git", "log", "-1", "--format=%H %s"],
                    cwd=self.project_path,
                    capture_output=True,
                    text=True
                )
                if result.returncode == 0:
                    self.results["project_info"]["latest_commit"] = result.stdout.strip()
        except Exception as e:
            pass
    
    def _detect_tech_stack(self):
        """检测技术栈"""
        tech_stack = {}
        
        # 检查各种配置文件
        config_checks = [
            ("package.json", "Node.js/JavaScript"),
            ("pom.xml", "Java/Maven"),
            ("build.gradle", "Java/Gradle"),
            ("build.gradle.kts", "Kotlin/Gradle"),
            ("go.mod", "Go"),
            ("Cargo.toml", "Rust"),
            ("requirements.txt", "Python"),
            ("pyproject.toml", "Python"),
            ("composer.json", "PHP"),
            ("Gemfile", "Ruby"),
            ("Project.toml", "Julia"),
            ("setup.py", "Python"),
            ("CMakeLists.txt", "C/C++"),
            ("Makefile", "C/C++/通用"),
        ]
        
        for file, tech in config_checks:
            if (self.project_path / file).exists():
                tech_stack[tech] = file
        
        # 检查框架特定文件
        framework_checks = [
            ("next.config.js", "Next.js"),
            ("vue.config.js", "Vue.js"),
            ("angular.json", "Angular"),
            ("react-app-env.d.ts", "React"),
            ("Django", "Django"),  # 目录
            ("rails", "Ruby on Rails"),  # 目录
            ("spring", "Spring Boot"),  # 目录或配置文件
            ("laravel", "Laravel"),  # 目录
        ]
        
        for pattern, framework in framework_checks:
            matches = list(self.project_path.rglob(f"*{pattern}*"))
            if matches:
                tech_stack[framework] = [str(m.relative_to(self.project_path)) for m in matches[:3]]
        
        self.results["tech_stack"] = tech_stack
    
    def _analyze_directory_structure(self):
        """分析目录结构"""
        dirs = []
        max_depth = 3
        
        for root, dirs_list, files in os.walk(self.project_path):
            depth = root[len(str(self.project_path)) + 1:].count(os.sep)
            if depth >= max_depth:
                continue
            
            rel_root = os.path.relpath(root, self.project_path)
            if rel_root == ".":
                rel_root = "/"
            
            # 统计文件类型
            file_types = {}
            for f in files:
                ext = os.path.splitext(f)[1]
                if ext:
                    file_types[ext] = file_types.get(ext, 0) + 1
            
            dir_info = {
                "path": rel_root,
                "dir_count": len(dirs_list),
                "file_count": len(files),
                "file_types": dict(sorted(file_types.items(), key=lambda x: x[1], reverse=True)[:5])
            }
            
            # 只记录有文件或特定名称的目录
            if files or any(d in dirs_list for d in ["src", "app", "lib", "test", "docs"]):
                dirs.append(dir_info)
        
        self.results["directory_structure"] = dirs[:20]  # 限制数量
    
    def _find_config_files(self):
        """查找重要配置文件"""
        config_patterns = [
            "*.env*",
            "*.config.*",
            "*config*.yml",
            "*config*.yaml",
            "*config*.json",
            "*settings*",
            "*property*",
            "docker-compose*.yml",
            "Dockerfile*",
            "*.toml",
            "*.ini",
        ]
        
        config_files = []
        for pattern in config_patterns:
            matches = self.project_path.rglob(pattern)
            for match in matches:
                # 排除一些常见的不重要文件
                if match.is_file() and not any(ignore in str(match) for ignore in [".git", "node_modules", "__pycache__"]):
                    try:
                        size = match.stat().st_size
                        if size < 1024 * 1024:  # 小于 1MB
                            config_files.append({
                                "path": str(match.relative_to(self.project_path)),
                                "size": size
                            })
                    except OSError:
                        pass
        
        # 按路径排序并去重
        seen = set()
        unique_files = []
        for cf in config_files:
            if cf["path"] not in seen:
                seen.add(cf["path"])
                unique_files.append(cf)
        
        self.results["config_files"] = sorted(unique_files, key=lambda x: x["path"])[:15]
    
    def _detect_build_tools(self):
        """检测构建工具"""
        build_tools = []
        
        # 检查构建脚本
        build_indicators = [
            ("package.json", ["scripts"]),
            ("Makefile", []),
            ("build.sh", []),
            ("gradlew", []),
            ("mvnw", []),
            (".github/workflows", []),
            (".gitlab-ci.yml", []),
            (".circleci/config.yml", []),
        ]
        
        for file, indicators in build_indicators:
            path = self.project_path / file
            if path.exists():
                build_tools.append(file)
        
        self.results["build_tools"] = build_tools
    
    def _check_deployment(self):
        """检查部署配置"""
        deployment = {}
        
        # Docker
        docker_files = list(self.project_path.rglob("Dockerfile*"))
        if docker_files:
            deployment["docker"] = [str(f.relative_to(self.project_path)) for f in docker_files[:3]]
        
        # Kubernetes
        k8s_files = list(self.project_path.rglob("*.yaml")) + list(self.project_path.rglob("*.yml"))
        k8s_files = [f for f in k8s_files if any(k in str(f).lower() for k in ["k8s", "kubernetes", "deployment", "service", "ingress"])]
        if k8s_files:
            deployment["kubernetes"] = [str(f.relative_to(self.project_path)) for f in k8s_files[:5]]
        
        # Cloud specific
        cloud_files = []
        for pattern in ["serverless*.yml", "terraform*.tf", "cloudformation*.yml"]:
            cloud_files.extend(self.project_path.rglob(pattern))
        
        if cloud_files:
            deployment["cloud"] = [str(f.relative_to(self.project_path)) for f in cloud_files[:5]]
        
        self.results["deployment"] = deployment
    
    def _generate_recommendations(self):
        """生成建议"""
        recs = []
        
        # 基于技术栈的建议
        if "Node.js/JavaScript" in self.results["tech_stack"]:
            recs.append("运行 'npm install' 安装依赖")
            recs.append("检查 package.json 中的 scripts 部分了解可用命令")
        
        if "Python" in self.results["tech_stack"]:
            recs.append("考虑使用虚拟环境：python -m venv venv")
            recs.append("运行 'pip install -r requirements.txt' 安装依赖")
        
        if "Java/Maven" in self.results["tech_stack"]:
            recs.append("运行 'mvn compile' 编译项目")
            recs.append("运行 'mvn test' 执行测试")
        
        # 基于配置文件的建议
        if any(".env" in cf["path"] for cf in self.results["config_files"]):
            recs.append("检查 .env 文件是否需要环境变量配置")
        
        if any("docker-compose" in cf["path"] for cf in self.results["config_files"]):
            recs.append("尝试 'docker-compose up' 启动服务")
        
        # 通用建议
        if not any("README" in cf["path"] for cf in self.results["config_files"]):
            recs.append("项目缺少 README 文件，考虑创建文档")
        
        if not self.results["build_tools"]:
            recs.append("未检测到明显的构建工具，查看是否有自定义构建脚本")
        
        self.results["recommendations"] = recs
    
    def print_report(self, output_format="text"):
        """打印分析报告"""
        if output_format == "json":
            print(json.dumps(self.results, indent=2, ensure_ascii=False))
            return
        
        # 文本格式报告
        print("=" * 60)
        print("项目分析报告")
        print("=" * 60)
        
        print(f"\n项目路径: {self.results['project_info'].get('path', '未知')}")
        if "git_repo" in self.results["project_info"]:
            print(f"Git 仓库: {self.results['project_info']['git_repo']}")
        
        print(f"\n技术栈检测:")
        for tech, files in self.results["tech_stack"].items():
            if isinstance(files, list):
                print(f"  • {tech}: {', '.join(files[:2])}")
            else:
                print(f"  • {tech}: {files}")
        
        print(f"\n重要配置文件 ({len(self.results['config_files'])} 个):")
        for cf in self.results["config_files"][:10]:
            print(f"  • {cf['path']} ({cf['size']} 字节)")
        
        if len(self.results["config_files"]) > 10:
            print(f"  ... 还有 {len(self.results['config_files']) - 10} 个配置文件")
        
        print(f"\n构建工具检测:")
        for tool in self.results["build_tools"]:
            print(f"  • {tool}")
        
        print(f"\n部署配置:")
        for deploy_type, files in self.results["deployment"].items():
            if files:
                print(f"  • {deploy_type}: {', '.join(files[:2])}")
        
        print(f"\n目录结构概要:")
        for dir_info in self.results["directory_structure"][:8]:
            if dir_info["path"] == "/":
                continue
            print(f"  • {dir_info['path']}/ ({dir_info['file_count']} 文件)")
        
        print(f"\n建议:")
        for i, rec in enumerate(self.results["recommendations"][:5], 1):
            print(f"  {i}. {rec}")
        
        print(f"\n" + "=" * 60)
        print("分析完成。使用 --json 参数获取完整 JSON 数据。")

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="分析项目结构和技术栈")
    parser.add_argument("path", nargs="?", default=".", help="项目路径（默认为当前目录）")
    parser.add_argument("--json", action="store_true", help="输出 JSON 格式")
    parser.add_argument("--output", help="输出到文件")
    
    args = parser.parse_args()
    
    analyzer = ProjectAnalyzer(args.path)
    results = analyzer.analyze()
    
    output_format = "json" if args.json else "text"
    
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            if args.json:
                json.dump(results, f, indent=2, ensure_ascii=False)
            else:
                import sys
                sys.stdout = f
                analyzer.print_report(output_format)
                sys.stdout = sys.__stdout__
        print(f"报告已保存到: {args.output}")
    else:
        analyzer.print_report(output_format)

if __name__ == "__main__":
    main()