#!/bin/bash
# 快速检测项目技术栈的脚本

set -e

PROJECT_PATH="${1:-.}"
cd "$PROJECT_PATH" || exit 1

echo "=== 项目技术栈检测 ==="
echo "项目路径: $(pwd)"
echo "检测时间: $(date)"
echo

# 检测函数
detect_file() {
    local file=$1
    local description=$2
    if [ -f "$file" ] || [ -d "$file" ]; then
        echo "✓ $description ($file)"
        return 0
    fi
    return 1
}

# 编程语言和运行时
echo "--- 编程语言检测 ---"
detect_file "package.json" "Node.js/JavaScript" ||
detect_file "pom.xml" "Java/Maven" ||
detect_file "build.gradle" "Java/Gradle" ||
detect_file "build.gradle.kts" "Kotlin/Gradle" ||
detect_file "go.mod" "Go" ||
detect_file "Cargo.toml" "Rust" ||
detect_file "requirements.txt" "Python" ||
detect_file "pyproject.toml" "Python" ||
detect_file "composer.json" "PHP" ||
detect_file "Gemfile" "Ruby" ||
detect_file "Project.toml" "Julia" ||
detect_file "setup.py" "Python" ||
detect_file "CMakeLists.txt" "C/C++" ||
detect_file "Makefile" "C/C++/通用" ||
echo "未检测到常见语言配置文件"

# 前端框架
echo
echo "--- 前端框架检测 ---"
detect_file "next.config.js" "Next.js" ||
detect_file "vue.config.js" "Vue.js" ||
detect_file "angular.json" "Angular" ||
detect_file "react-app-env.d.ts" "React" ||
detect_file "src/main.jsx" "React (JSX)" ||
detect_file "src/main.tsx" "React (TSX)" ||
echo "未检测到明显的前端框架"

# 后端框架
echo
echo "--- 后端框架检测 ---"
if [ -d "Django" ] || find . -name "settings.py" -type f | grep -q .; then
    echo "✓ Django (Python)"
elif [ -d "rails" ] || [ -f "Gemfile" ] && grep -q "rails" Gemfile 2>/dev/null; then
    echo "✓ Ruby on Rails"
elif [ -d "spring" ] || find . -name "Application.java" -type f | grep -q .; then
    echo "✓ Spring Boot (Java)"
elif [ -d "laravel" ] || [ -f "artisan" ]; then
    echo "✓ Laravel (PHP)"
else
    echo "未检测到明显的后端框架"
fi

# 构建工具
echo
echo "--- 构建工具检测 ---"
detect_file "package.json" "npm/yarn" &&
    (grep -q "scripts" package.json && echo "  - 包含 npm scripts")

detect_file "Makefile" "Make" ||
detect_file "build.sh" "Shell 构建脚本" ||
detect_file "gradlew" "Gradle Wrapper" ||
detect_file "mvnw" "Maven Wrapper" ||
echo "未检测到明显的构建工具"

# 容器化
echo
echo "--- 容器化检测 ---"
detect_file "Dockerfile" "Docker" ||
detect_file "docker-compose.yml" "Docker Compose" ||
echo "未检测到容器化配置"

# CI/CD
echo
echo "--- CI/CD 检测 ---"
detect_file ".github/workflows" "GitHub Actions" ||
detect_file ".gitlab-ci.yml" "GitLab CI" ||
detect_file ".circleci/config.yml" "CircleCI" ||
detect_file ".travis.yml" "Travis CI" ||
echo "未检测到 CI/CD 配置"

# 配置文件
echo
echo "--- 配置文件检测 ---"
config_files=$(find . -maxdepth 2 -type f \( \
    -name "*.env*" -o \
    -name "*config*.yml" -o \
    -name "*config*.yaml" -o \
    -name "*config*.json" -o \
    -name "*.toml" -o \
    -name "*.ini" \
\) 2>/dev/null | head -10)

if [ -n "$config_files" ]; then
    echo "找到配置文件:"
    echo "$config_files" | sed 's/^/  • /'
else
    echo "未检测到常见配置文件"
fi

# 目录结构
echo
echo "--- 关键目录检测 ---"
important_dirs=("src" "app" "lib" "test" "tests" "spec" "docs" "config" "public" "static")
found_dirs=()
for dir in "${important_dirs[@]}"; do
    if [ -d "$dir" ]; then
        found_dirs+=("$dir")
    fi
done

if [ ${#found_dirs[@]} -gt 0 ]; then
    echo "存在关键目录: ${found_dirs[*]}"
else
    echo "未检测到常见的关键目录"
    echo "当前目录内容:"
    ls -la | head -10
fi

echo
echo "=== 检测完成 ==="
echo
echo "建议后续步骤:"
echo "1. 查看 README.md 文件（如果存在）"
echo "2. 运行项目分析脚本: python scripts/analyze_project.py"
echo "3. 尝试构建项目: 根据检测到的构建工具运行相应命令"
echo "4. 运行测试: 查找测试目录并执行测试"