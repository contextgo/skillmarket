---
name: project-onboarding
description: |
  帮助开发者快速了解新项目的技能。当开发者加入新团队、接手新项目，  或需要快速熟悉项目结构、技术栈、配置、部署和开发流程时使用。
  技能提供系统化的探索步骤、检查清单和自动化脚本，以加速项目上手过程。
  使用此技能的场景包括：用户刚加入公司、收到新项目代码库、需要了解如何开始开发、
  想知道项目如何构建和部署、寻找重要配置文件、理解代码组织结构等。
compatibility:
  tools:
    - bash
    - read
    - glob
    - grep
---

# 项目入职指南

## 概述

本技能旨在帮助开发者快速了解一个新项目。当你刚加入一个团队、接手一个陌生代码库，
或者需要快速评估一个项目的技术栈、架构和开发流程时，本技能提供一套系统化的探索方法。

通过遵循本指南，你将能够：
- 快速识别项目的技术栈和框架
- 理解项目的目录结构和代码组织
- 找到关键配置文件和环境设置
- 了解项目的构建、测试和部署流程
- 获得开始开发新功能的具体步骤

## 快速开始

如果你是第一次使用本技能，可以按以下步骤快速开始：

1. **运行项目分析脚本**（如果可用）：
   ```bash
   python scripts/analyze_project.py
   ```

2. **查看项目概览**：
   - 检查根目录下的配置文件（package.json, pom.xml, build.gradle, Dockerfile 等）
   - 查看 README.md 和任何文档目录

3. **执行核心检查清单**（见下文）

## 详细探索步骤

### 1. 识别项目类型和入口点

首先，确定项目是什么类型（Web 应用、移动应用、后端服务、库等）以及如何启动它。

```bash
# 查看根目录下的文件
ls -la

# 寻找常见的项目入口文件
find . -maxdepth 2 -name "*.json" -o -name "*.yml" -o -name "*.yaml" -o -name "*.xml" -o -name "*.gradle" -o -name "*.toml" | head -20

# 检查是否有 Docker 相关文件
ls -la | grep -E "(Dockerfile|docker-compose|.dockerignore)"
```

### 2. 分析技术栈

通过配置文件识别项目使用的技术：

```bash
# 检查 Node.js 项目
if [ -f "package.json" ]; then
  cat package.json | grep -E "(name|version|dependencies|devDependencies|scripts)"
fi

# 检查 Python 项目
if [ -f "requirements.txt" ]; then
  head -20 requirements.txt
fi
if [ -f "pyproject.toml" ]; then
  cat pyproject.toml | head -50
fi

# 检查 Java 项目
if [ -f "pom.xml" ]; then
  cat pom.xml | grep -E "(groupId|artifactId|version|dependencies)" | head -20
fi
if [ -f "build.gradle" ]; then
  cat build.gradle | head -50
fi

# 检查 Go 项目
if [ -f "go.mod" ]; then
  cat go.mod
fi
```

### 3. 探索目录结构

理解项目的代码组织方式：

```bash
# 查看主要目录
find . -type d -maxdepth 2 | sort

# 查看源代码目录（通常为 src/, app/, lib/, 等）
ls -la src/ 2>/dev/null || ls -la app/ 2>/dev/null || ls -la lib/ 2>/dev/null

# 查看测试目录
find . -type d -name "*test*" -o -name "*spec*" | head -10
```

### 4. 查找重要配置

配置文件往往包含项目运行所需的关键信息：

```bash
# 环境配置文件
find . -name ".env*" -o -name "config*" -o -name "settings*" | head -10

# 数据库配置
grep -r "DATABASE_URL\|DB_HOST\|DB_PASSWORD" . --include="*.yml" --include="*.yaml" --include="*.json" --include="*.properties" 2>/dev/null | head -5

# API 密钥和敏感配置（注意安全）
find . -name "*.key" -o -name "*.pem" -o -name "*secret*" | head -5
```

### 5. 了解构建和测试流程

项目如何构建、测试和运行：

```bash
# 查看构建脚本
cat package.json 2>/dev/null | grep -A5 -B5 "scripts"
cat Makefile 2>/dev/null | head -30

# 尝试运行测试
if [ -f "package.json" ]; then
  npm test -- --dry-run 2>/dev/null || echo "查看 package.json 中的 test 脚本"
fi

# 检查 CI/CD 配置
find . -name ".github" -type d -o -name ".gitlab" -type d -o -name ".circleci" -type d | head -5
```

### 6. 发现部署方式

项目如何部署到生产环境：

```bash
# 查找部署配置
find . -name "Dockerfile" -o -name "docker-compose*.yml" -o -name "*.sh" | grep -i deploy | head -10

# 检查云服务配置
find . -name "serverless*.yml" -o -name "terraform*.tf" -o -name "k8s*.yaml" -o -name "helm" -type d | head -10

# 查看 .github/workflows 或 .gitlab-ci.yml
ls -la .github/workflows/ 2>/dev/null || cat .gitlab-ci.yml 2>/dev/null | head -30
```

### 7. 查找文档

项目文档是了解项目的最佳资源：

```bash
# 查找 README 文件
find . -name "README*" -o -name "CONTRIBUTING*" | head -5

# 查看 docs/ 目录
ls -la docs/ 2>/dev/null

# 查找代码注释中的设计文档
grep -r "TODO\|FIXME\|HACK\|NOTE" . --include="*.js" --include="*.py" --include="*.java" --include="*.go" 2>/dev/null | head -10
```

## 检查清单

使用以下检查清单确保你覆盖了所有重要方面：

### 项目基础
- [ ] 项目名称和版本是什么？
- [ ] 项目使用什么编程语言和框架？
- [ ] 项目依赖哪些外部库？
- [ ] 项目使用什么构建工具？

### 代码结构
- [ ] 源代码放在哪个目录？
- [ ] 测试代码放在哪个目录？
- [ ] 静态资源（图片、样式）放在哪里？
- [ ] 配置文件在哪里？

### 开发环境
- [ ] 如何设置开发环境？
- [ ] 需要安装哪些工具和运行时？
- [ ] 如何启动开发服务器？
- [ ] 如何运行测试？

### 构建与部署
- [ ] 如何构建项目？
- [ ] 如何运行代码质量检查？
- [ ] 项目如何部署？
- [ ] 使用了哪些云服务或基础设施？

### 团队协作
- [ ] 项目的 Git 工作流程是什么？
- [ ] 代码审查流程如何？
- [ ] 如何提交 Bug 报告或功能请求？

## 自动化脚本

本技能提供以下脚本帮助你自动分析项目：

### analyze_project.py

一个 Python 脚本，自动收集项目信息并生成报告。

**使用方法：**
```bash
python scripts/analyze_project.py
```

**功能：**
- 识别项目类型和技术栈
- 分析目录结构
- 提取关键配置信息
- 生成 HTML 或 Markdown 报告

### tech_stack_detector.sh

一个 Shell 脚本，快速检测项目使用的技术。

**使用方法：**
```bash
bash scripts/tech_stack_detector.sh
```

## 常见问题解答

### 1. 我应该从哪里开始？
从 README.md 开始，然后运行项目分析脚本。如果 README 缺失或过时，按照本指南的步骤逐一探索。

### 2. 如何知道项目是否正常运行？
尝试运行项目的测试套件。如果测试通过，说明项目基本健康。然后尝试在开发模式下启动项目。

### 3. 找不到配置文件怎么办？
查看示例配置文件（如 .env.example, config.sample.yml），或询问团队成员。不要猜测生产环境配置。

### 4. 如何开始开发新功能？
1. 确保你能在本地运行项目
2. 查看现有代码的编码风格和模式
3. 找到相关模块的测试示例
4. 遵循团队的 Git 工作流程

## 下一步行动

根据你的探索结果，选择以下行动之一：

1. **设置开发环境**：按照找到的说明安装依赖并启动项目
2. **运行测试**：确保现有功能正常工作
3. **阅读核心代码**：深入理解业务逻辑
4. **尝试小修改**：修复一个简单的 Bug 或添加日志
5. **与团队沟通**：确认你的理解是否正确

## 提示与技巧

- **保持好奇心**：不要害怕深入代码，但也要知道何时停止
- **善用搜索**：使用 `grep` 或 IDE 的搜索功能查找特定代码
- **记录发现**：将你的发现记录下来，方便日后参考和分享给其他新成员
- **逐步深入**：先了解整体架构，再深入具体模块

---

*本技能旨在加速你的项目上手过程，但无法替代与团队成员的沟通和代码的深入阅读。*
*如果你发现本技能缺少某些特定技术的指导，请考虑扩展它以适应你的需求。*