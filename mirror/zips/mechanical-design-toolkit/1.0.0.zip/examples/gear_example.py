#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
齿轮计算示例
计算模数3、齿数20的锥齿轮几何参数和强度
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from scripts.gear_calculator import BevelGear, query_tolerance


def main():
    print("=" * 60)
    print("锥齿轮计算示例")
    print("=" * 60)
    
    # 创建锥齿轮
    gear = BevelGear(
        module=3,
        teeth=20,
        pressure_angle=20,
        face_width=25
    )
    
    # 1. 几何参数计算
    print("\n【1. 几何参数计算】")
    print("-" * 60)
    geometry = gear.calculate_geometry()
    for key, value in geometry.items():
        print(f"  {key}: {value}")
    
    # 2. 接触强度校核
    print("\n【2. 齿面接触强度校核】")
    print("-" * 60)
    contact_result = gear.check_contact_strength(
        torque=500,  # N·m
        pinion_teeth=20,
        gear_teeth=40,
        material="40Cr"
    )
    for key, value in contact_result.items():
        print(f"  {key}: {value}")
    
    # 3. 弯曲强度校核
    print("\n【3. 齿根弯曲强度校核】")
    print("-" * 60)
    bending_result = gear.check_bending_strength(
        torque=500,
        pinion_teeth=20,
        gear_teeth=40,
        material="40Cr"
    )
    for key, value in bending_result.items():
        print(f"  {key}: {value}")
    
    # 4. 公差查询
    print("\n【4. 公差查询 (7级精度)】")
    print("-" * 60)
    tolerance = query_tolerance(
        tolerance_class="7",
        module=3,
        gear_type="bevel"
    )
    for key, value in tolerance.items():
        print(f"  {key}: {value}")
    
    print("\n" + "=" * 60)
    print("计算完成！")
    print("=" * 60)


if __name__ == "__main__":
    main()
