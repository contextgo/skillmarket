#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
螺栓强度校核示例
M16、8.8级螺栓的强度校核
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from scripts.bolt_calculator import BoltStrength


def main():
    print("=" * 60)
    print("螺栓强度校核示例")
    print("=" * 60)
    
    # 创建螺栓对象
    print("\n【螺栓参数】")
    print("-" * 60)
    bolt = BoltStrength(grade='8.8', diameter='M16')
    print(f"  性能等级: {bolt.grade}")
    print(f"  屈服强度: {bolt.params['sigma_s']} MPa")
    print(f"  抗拉强度: {bolt.params['sigma_b']} MPa")
    print(f"  许用剪应力: {bolt.params['tau']} MPa")
    print(f"  应力截面积: {bolt.stress_area} mm²")
    
    # 1. 拉伸强度校核
    print("\n【1. 拉伸强度校核】")
    print("-" * 60)
    result1 = bolt.check_tension(force=50000, safety_factor=1.5)
    for key, value in result1.items():
        print(f"  {key}: {value}")
    
    # 2. 拉伸+扭转复合校核
    print("\n【2. 拉伸+扭转复合强度校核】")
    print("-" * 60)
    result2 = bolt.check_tension_torsion(
        tension_force=50000,
        torque=150,
        safety_factor=1.5
    )
    for key, value in result2.items():
        print(f"  {key}: {value}")
    
    # 3. 剪切强度校核
    print("\n【3. 剪切强度校核】")
    print("-" * 60)
    result3 = bolt.check_shear(force=30000, safety_factor=1.5)
    for key, value in result3.items():
        print(f"  {key}: {value}")
    
    # 4. 预紧力计算
    print("\n【4. 预紧力计算】")
    print("-" * 60)
    result4 = bolt.calculate_preload(torque=150, friction_coeff=0.15)
    for key, value in result4.items():
        print(f"  {key}: {value}")
    
    print("\n" + "=" * 60)
    print("校核完成！")
    print("=" * 60)


if __name__ == "__main__":
    main()
