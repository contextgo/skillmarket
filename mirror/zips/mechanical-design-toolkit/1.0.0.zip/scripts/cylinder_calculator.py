#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
气缸计算引擎 (Cylinder Calculator)
支持SC系列气缸参数查询、推力/拉力计算、气耗量计算
符合JB/T 6440标准
"""

from typing import Dict, List


class CylinderCalculator:
    """气缸计算类"""
    
    # SC系列气缸参数
    SC_SERIES = {
        'SC32': {
            'bore_mm': 32,
            'rod_diameter_mm': 12,
            'max_stroke_mm': 500,
            'port_size': 'G1/8',
            'theoretical_force_N_per_01MPa': 80
        },
        'SC40': {
            'bore_mm': 40,
            'rod_diameter_mm': 16,
            'max_stroke_mm': 600,
            'port_size': 'G1/4',
            'theoretical_force_N_per_01MPa': 125
        },
        'SC50': {
            'bore_mm': 50,
            'rod_diameter_mm': 20,
            'max_stroke_mm': 800,
            'port_size': 'G1/4',
            'theoretical_force_N_per_01MPa': 196
        },
        'SC63': {
            'bore_mm': 63,
            'rod_diameter_mm': 20,
            'max_stroke_mm': 1000,
            'port_size': 'G3/8',
            'theoretical_force_N_per_01MPa': 311
        },
        'SC80': {
            'bore_mm': 80,
            'rod_diameter_mm': 25,
            'max_stroke_mm': 1200,
            'port_size': 'G1/2',
            'theoretical_force_N_per_01MPa': 502
        },
        'SC100': {
            'bore_mm': 100,
            'rod_diameter_mm': 30,
            'max_stroke_mm': 1500,
            'port_size': 'G1/2',
            'theoretical_force_N_per_01MPa': 785
        },
        'SC125': {
            'bore_mm': 125,
            'rod_diameter_mm': 35,
            'max_stroke_mm': 1500,
            'port_size': 'G3/4',
            'theoretical_force_N_per_01MPa': 1227
        }
    }
    
    def __init__(self, model: str):
        """
        初始化气缸参数
        
        Args:
            model: 气缸型号 ('SC63', 'SC100' 等)
        """
        self.model = model
        self.params = self.SC_SERIES.get(model, self.SC_SERIES['SC63'])
        
    def calculate_force(self, pressure: float = 0.6, 
                        efficiency: float = 0.85) -> Dict:
        """
        计算推力和拉力
        
        Args:
            pressure: 工作压力 (MPa)
            efficiency: 效率系数
            
        Returns:
            推力计算结果
        """
        D = self.params['bore_mm']
        d = self.params['rod_diameter_mm']
        
        # 活塞面积
        A_push = math.pi * D**2 / 4 / 100  # dm²
        A_pull = math.pi * (D**2 - d**2) / 4 / 100  # dm²
        
        # 理论推力/拉力
        F_push_theo = A_push * pressure * 100  # N
        F_pull_theo = A_pull * pressure * 100  # N
        
        # 实际推力/拉力 (考虑效率)
        F_push = F_push_theo * efficiency
        F_pull = F_pull_theo * efficiency
        
        return {
            'model': self.model,
            'bore_mm': D,
            'rod_diameter_mm': d,
            'pressure_MPa': pressure,
            'efficiency': efficiency,
            'push_force_N': round(F_push, 1),
            'push_force_kgf': round(F_push / 9.81, 1),
            'pull_force_N': round(F_pull, 1),
            'pull_force_kgf': round(F_pull / 9.81, 1),
            'theoretical_push_force_N': round(F_push_theo, 1),
            'theoretical_pull_force_N': round(F_pull_theo, 1)
        }
    
    def calculate_air_consumption(self, stroke: float, 
                                  cycle_time: float = 10) -> Dict:
        """
        计算空气消耗量
        
        Args:
            stroke: 行程 (mm)
            cycle_time: 循环时间 (s)
            
        Returns:
            气耗量计算结果
        """
        D = self.params['bore_mm']
        
        # 单程排量 (L)
        V_single = math.pi * D**2 / 4 * stroke / 1000000  # L
        
        # 每分钟循环次数
        cycles_per_min = 60 / cycle_time
        
        # 每分钟空气消耗量 (L/min, 自由空气)
        # 假设工作压力0.6MPa，则压缩比约为7
        compression_ratio = 7
        Q = V_single * 2 * cycles_per_min * compression_ratio  # 往返
        
        return {
            'model': self.model,
            'bore_mm': D,
            'stroke_mm': stroke,
            'cycle_time_s': cycle_time,
            'single_stroke_volume_L': round(V_single, 3),
            'cycles_per_minute': round(cycles_per_min, 2),
            'air_consumption_L_min': round(Q, 1),
            'compression_ratio': compression_ratio,
            'note': '按工作压力0.6MPa计算'
        }
    
    def recommend_valve(self) -> Dict:
        """
        推荐电磁阀
        
        Returns:
            电磁阀推荐结果
        """
        port = self.params['port_size']
        
        # 根据接口尺寸推荐阀型号
        valve_map = {
            'G1/8': '4V110-06',
            'G1/4': '4V210-08',
            'G3/8': '4V310-10',
            'G1/2': '4V410-15'
        }
        
        valve = valve_map.get(port, '4V210-08')
        
        return {
            'cylinder_model': self.model,
            'port_size': port,
            'recommended_valve': valve,
            'valve_port_size': port,
            'note': '推荐电磁阀型号(仅供参考)'
        }
    
    @classmethod
    def list_all_models(cls) -> List[str]:
        """列出所有可用型号"""
        return list(cls.SC_SERIES.keys())


if __name__ == "__main__":
    import math
    
    # 示例1：SC63气缸推力计算
    print("=== SC63气缸推力计算 ===")
    cyl1 = CylinderCalculator('SC63')
    result1 = cyl1.calculate_force(pressure=0.6, efficiency=0.85)
    for key, value in result1.items():
        print(f"{key}: {value}")
    
    print("\n=== SC80气缸气耗量计算 ===")
    cyl2 = CylinderCalculator('SC80')
    result2 = cyl2.calculate_air_consumption(stroke=200, cycle_time=10)
    for key, value in result2.items():
        print(f"{key}: {value}")
    
    print("\n=== 电磁阀推荐 ===")
    result3 = cyl2.recommend_valve()
    for key, value in result3.items():
        print(f"{key}: {value}")
