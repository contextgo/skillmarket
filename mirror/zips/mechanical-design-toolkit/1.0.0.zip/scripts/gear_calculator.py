#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
齿轮计算引擎 (Gear Calculation Engine)
支持锥齿轮几何计算、公差查询、强度校核
符合GB/T 10062、GB/T 11365标准
"""

import math
import json
from typing import Dict, Tuple, Optional


class BevelGear:
    """锥齿轮计算类"""
    
    def __init__(self, module: float, teeth: int, pressure_angle: float = 20,
                 face_width: float = None, shaft_angle: float = 90):
        """
        初始化锥齿轮参数
        
        Args:
            module: 模数 (mm)
            teeth: 齿数
            pressure_angle: 压力角 (度)
            face_width: 齿宽 (mm)
            shaft_angle: 轴交角 (度)
        """
        self.module = module
        self.teeth = teeth
        self.pressure_angle = pressure_angle
        self.shaft_angle = shaft_angle
        self.face_width = face_width
        
        # 计算派生参数
        self.pitch_diameter = module * teeth  # 节圆直径
        self.addendum = module  # 齿顶高
        self.dedendum = 1.2 * module  # 齿根高
        
    def calculate_geometry(self) -> Dict:
        """
        计算锥齿轮几何参数
        
        Returns:
            包含几何参数的字典
        """
        m = self.module
        z = self.teeth
        d = self.pitch_diameter
        
        # 节锥角 (假设轴交角90°)
        delta = math.atan2(z, self.teeth) if self.shaft_angle == 90 else \
                math.atan(math.sin(math.radians(self.shaft_angle)) / 
                         (self.teeth/self.teeth + math.cos(math.radians(self.shaft_angle))))
        
        # 齿顶圆直径
        da = d + 2 * m * math.cos(delta)
        
        # 齿根圆直径
        df = d - 2 * 1.2 * m * math.cos(delta)
        
        # 顶锥角
        delta_a = delta + math.atan(m / (0.5 * d))
        
        # 根锥角
        delta_f = delta - math.atan(1.2 * m / (0.5 * d))
        
        # 锥距
        R = d / (2 * math.sin(delta))
        
        # 齿宽（如果未指定，取R/3）
        b = self.face_width if self.face_width else R / 3
        
        return {
            'pitch_diameter_mm': round(d, 3),
            'addendum_circle_diameter_mm': round(da, 3),
            'dedendum_circle_diameter_mm': round(df, 3),
            'pitch_cone_angle_deg': round(math.degrees(delta), 3),
            'addendum_cone_angle_deg': round(math.degrees(delta_a), 3),
            'dedendum_cone_angle_deg': round(math.degrees(delta_f), 3),
            'cone_distance_mm': round(R, 3),
            'face_width_mm': round(b, 3),
            'module_mm': m,
            'teeth_number': z
        }
    
    def check_contact_strength(self, torque: float, pinion_teeth: int,
                               gear_teeth: int, material: str = "40Cr") -> Dict:
        """
        齿面接触强度校核 (GB/T 10062)
        
        Args:
            torque: 小齿轮扭矩 (N·m)
            pinion_teeth: 小齿轮齿数
            gear_teeth: 大齿轮齿数
            material: 材料
            
        Returns:
            强度校核结果
        """
        # 计算载荷
        T1 = torque * 1000  # 转换为N·mm
        u = gear_teeth / pinion_teeth  # 传动比
        
        # 节点区域系数 (简化计算)
        ZH = 2.5
        
        # 弹性系数 (钢-钢)
        ZE = 189.8  # MPa^0.5
        
        # 重合度系数
        Z_epsilon = 0.9
        
        # 螺旋角系数
        Z_beta = 1.0
        
        # 使用系数 (假设均匀载荷)
        KA = 1.0
        
        # 动载系数
        KV = 1.1
        
        # 齿向载荷分布系数
        KH_beta = 1.1
        
        # 齿间载荷分配系数
        KH_alpha = 1.2
        
        # 综合系数
        K = KA * KV * KH_beta * KH_alpha
        
        # 小齿轮分度圆直径
        d1 = self.module * pinion_teeth
        
        # 齿宽
        b = self.face_width if self.face_width else d1 / 2
        
        # 接触应力
        sigma_H = ZE * ZH * Z_epsilon * Z_beta * \
                  math.sqrt((2 * T1 * K) / (b * d1**2) * (u + 1) / u)
        
        # 许用接触应力 (根据材料)
        sigma_H_lim = self._get_contact_fatigue_limit(material)
        
        # 安全系数
        SH = sigma_H_lim / sigma_H
        
        return {
            'contact_stress_MPa': round(sigma_H, 2),
            'allowable_contact_stress_MPa': round(sigma_H_lim, 2),
            'safety_factor': round(SH, 2),
            'status': 'PASS' if SH >= 1.0 else 'FAIL'
        }
    
    def check_bending_strength(self, torque: float, pinion_teeth: int,
                               gear_teeth: int, material: str = "40Cr") -> Dict:
        """
        齿根弯曲强度校核 (GB/T 10062)
        
        Args:
            torque: 小齿轮扭矩 (N·m)
            pinion_teeth: 小齿轮齿数
            gear_teeth: 大齿轮齿数
            material: 材料
            
        Returns:
            强度校核结果
        """
        T1 = torque * 1000  # N·mm
        u = gear_teeth / pinion_teeth
        
        # 齿形系数 (简化，实际应根据齿数和变位系数查表)
        YFa1 = 2.8 if pinion_teeth >= 20 else 3.2
        YFa2 = 2.5 if gear_teeth >= 30 else 2.8
        
        # 应力修正系数
        YSa1 = 1.55
        YSa2 = 1.55
        
        # 重合度系数
        Y_epsilon = 0.7
        
        # 螺旋角系数
        Y_beta = 1.0
        
        # 使用系数
        KA = 1.0
        
        # 动载系数
        KV = 1.1
        
        # 齿向载荷分布系数
        KF_beta = 1.1
        
        # 齿间载荷分配系数
        KF_alpha = 1.2
        
        K = KA * KV * KF_beta * KF_alpha
        
        # 小齿轮分度圆直径
        d1 = self.module * pinion_teeth
        
        # 齿宽
        b = self.face_width if self.face_width else d1 / 2
        
        # 弯曲应力
        sigma_F1 = (2 * T1 * K * YFa1 * YSa1 * Y_epsilon * Y_beta) / (b * d1 * self.module)
        sigma_F2 = sigma_F1 * (YFa2 * YSa2) / (YFa1 * YSa1)
        
        # 许用弯曲应力
        sigma_F_lim = self._get_bending_fatigue_limit(material)
        
        # 安全系数
        SF1 = sigma_F_lim / sigma_F1
        SF2 = sigma_F_lim / sigma_F2
        
        return {
            'pinion_bending_stress_MPa': round(sigma_F1, 2),
            'gear_bending_stress_MPa': round(sigma_F2, 2),
            'allowable_bending_stress_MPa': round(sigma_F_lim, 2),
            'pinion_safety_factor': round(SF1, 2),
            'gear_safety_factor': round(SF2, 2),
            'status': 'PASS' if min(SF1, SF2) >= 1.0 else 'FAIL'
        }
    
    def _get_contact_fatigue_limit(self, material: str) -> float:
        """获取接触疲劳极限"""
        limits = {
            "40Cr": 700,      # 调质
            "45": 550,         # 调质
            "20CrMnTi": 1100, # 渗碳淬火
            "42CrMo": 750,    # 调质
        }
        return limits.get(material, 600)
    
    def _get_bending_fatigue_limit(self, material: str) -> float:
        """获取弯曲疲劳极限"""
        limits = {
            "40Cr": 300,      # 调质
            "45": 220,         # 调质
            "20CrMnTi": 400,  # 渗碳淬火
            "42CrMo": 320,    # 调质
        }
        return limits.get(material, 250)


def query_tolerance(tolerance_class: str, module: float, 
                    gear_type: str = "bevel") -> Dict:
    """
    查询锥齿轮公差 (GB/T 11365)
    
    Args:
        tolerance_class: 公差等级 (如 "6"、"7"、"8")
        module: 模数
        gear_type: 齿轮类型 ("bevel" 或 "cylindrical")
        
    Returns:
        公差值字典
    """
    # 公差等级对应的系数 (简化)
    tolerance_factors = {
        "5": 0.8,
        "6": 1.0,
        "7": 1.25,
        "8": 1.6,
        "9": 2.0,
    }
    
    factor = tolerance_factors.get(tolerance_class, 1.25)
    
    # 基本公差 (μm) - 简化公式
    fi_prime = factor * 0.8 * module  # 切向综合公差
    fi_double = factor * 0.4 * module  # 一齿切向综合公差
    Fp = factor * 1.25 * module       # 齿距累积公差
    fpt = factor * 0.35 * module      # 单个齿距偏差
    
    return {
        'tolerance_class': tolerance_class,
        'module_mm': module,
        'Fi_prime_um': round(fi_prime, 2),
        'fi_double_um': round(fi_double, 2),
        'Fp_um': round(Fp, 2),
        'fpt_um': round(fpt, 2),
    }


if __name__ == "__main__":
    # 示例：计算模数3、齿数20的锥齿轮
    gear = BevelGear(module=3, teeth=20, pressure_angle=20)
    
    print("=== 几何参数计算 ===")
    geometry = gear.calculate_geometry()
    for key, value in geometry.items():
        print(f"{key}: {value}")
    
    print("\n=== 接触强度校核 ===")
    contact_result = gear.check_contact_strength(
        torque=500, pinion_teeth=20, gear_teeth=40, material="40Cr"
    )
    for key, value in contact_result.items():
        print(f"{key}: {value}")
    
    print("\n=== 弯曲强度校核 ===")
    bending_result = gear.check_bending_strength(
        torque=500, pinion_teeth=20, gear_teeth=40, material="40Cr"
    )
    for key, value in bending_result.items():
        print(f"{key}: {value}")
    
    print("\n=== 公差查询 ===")
    tolerance = query_tolerance(tolerance_class="7", module=3)
    for key, value in tolerance.items():
        print(f"{key}: {value}")
