#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
螺旋传动计算引擎 (Screw Drive Calculator)
支持螺纹强度校核、驱动扭矩/效率、功率/推力计算
符合GB/T 5796标准
"""

import math
from typing import Dict


class ScrewCalculator:
    """螺旋传动计算类"""
    
    # 螺纹参数 (简化)
    THREAD_PARAMS = {
        'M6': {'pitch': 1.0, 'major_dia': 6, 'minor_dia': 4.773},
        'M8': {'pitch': 1.25, 'major_dia': 8, 'minor_dia': 6.466},
        'M10': {'pitch': 1.5, 'major_dia': 10, 'minor_dia': 8.160},
        'M12': {'pitch': 1.75, 'major_dia': 12, 'minor_dia': 9.853},
        'M16': {'pitch': 2.0, 'major_dia': 16, 'minor_dia': 13.546},
        'M20': {'pitch': 2.5, 'major_dia': 20, 'minor_dia': 16.933},
        'M24': {'pitch': 3.0, 'major_dia': 24, 'minor_dia': 20.319},
        'M30': {'pitch': 3.5, 'major_dia': 30, 'minor_dia': 25.706},
        'Tr10x2': {'pitch': 2.0, 'major_dia': 10, 'minor_dia': 7.5},
        'Tr16x4': {'pitch': 4.0, 'major_dia': 16, 'minor_dia': 11.5},
        'Tr20x4': {'pitch': 4.0, 'major_dia': 20, 'minor_dia': 15.5},
        'Tr24x5': {'pitch': 5.0, 'major_dia': 24, 'minor_dia': 18.5},
        'Tr32x6': {'pitch': 6.0, 'major_dia': 32, 'minor_dia': 25.0},
        'Tr40x7': {'pitch': 7.0, 'major_dia': 40, 'minor_dia': 32.0},
    }
    
    def __init__(self, thread_type: str):
        """
        初始化螺纹参数
        
        Args:
            thread_type: 螺纹类型 ('M16', 'Tr40x7' 等)
        """
        self.thread_type = thread_type
        self.params = self.THREAD_PARAMS.get(thread_type, 
                                            {'pitch': 2.0, 'major_dia': 16, 'minor_dia': 13.546})
        
    def check_strength(self, axial_force: float, friction_coef: float = 0.15) -> Dict:
        """
        螺纹强度校核
        
        Args:
            axial_force: 轴向力 (N)
            friction_coef: 摩擦系数
            
        Returns:
            强度校核结果
        """
        d2 = (self.params['major_dia'] + self.params['minor_dia']) / 2  # 中径
        d3 = self.params['minor_dia']  # 小径
        
        # 螺纹接触面积 (简化：按6圈螺纹计算)
        A_thread = math.pi * d2 * self.params['pitch'] * 6
        
        # 剪切应力
        tau = axial_force / A_thread
        
        # 弯曲应力 (简化)
        M = axial_force * self.params['pitch'] / 2
        W = math.pi * d3**3 / 32
        sigma_b = M / W
        
        # 相当应力
        sigma_eq = math.sqrt(sigma_b**2 + 3 * tau**2)
        
        return {
            'thread_type': self.thread_type,
            'axial_force_N': axial_force,
            'shear_stress_MPa': round(tau, 2),
            'bending_stress_MPa': round(sigma_b, 2),
            'equivalent_stress_MPa': round(sigma_eq, 2),
            'note': '螺纹强度校核(简化计算)'
        }
    
    def calculate_torque(self, axial_force: float, 
                          friction_coef: float = 0.15) -> Dict:
        """
        计算驱动扭矩
        
        Args:
            axial_force: 轴向力 (N)
            friction_coef: 摩擦系数
            
        Returns:
            扭矩计算结果
        """
        d2 = (self.params['major_dia'] + self.params['minor_dia']) / 2
        p = self.params['pitch']
        
        # 当量摩擦角
        rho_prime = math.atan(friction_coef / math.cos(30 * math.pi / 180))
        
        # 螺纹升角
        lambda_angle = math.atan(p / (math.pi * d2))
        
        # 驱动扭矩 (简化公式)
        T = axial_force * d2 / 2 * math.tan(lambda_angle + rho_prime) / 1000  # N·m
        
        # 效率
        eta = math.tan(lambda_angle) / math.tan(lambda_angle + rho_prime)
        
        return {
            'thread_type': self.thread_type,
            'axial_force_N': axial_force,
            'drive_torque_Nm': round(T, 2),
            'lead_angle_deg': round(math.degrees(lambda_angle), 2),
            'efficiency_percent': round(eta * 100, 1),
            'friction_coefficient': friction_coef
        }
    
    def calculate_power(self, axial_force: float, speed: float,
                        friction_coef: float = 0.15) -> Dict:
        """
        计算功率
        
        Args:
            axial_force: 轴向力 (N)
            speed: 线速度 (mm/min)
            friction_coef: 摩擦系数
            
        Returns:
            功率计算结果
        """
        # 驱动扭矩
        torque_result = self.calculate_torque(axial_force, friction_coef)
        T = torque_result['drive_torque_Nm']
        
        # 转速 (从线速度换算)
        p = self.params['pitch']
        n = speed / (p * 60)  # rpm
        
        # 功率
        P = T * n * 2 * math.pi / 60000  # kW
        
        return {
            'thread_type': self.thread_type,
            'axial_force_N': axial_force,
            'linear_speed_mm_min': speed,
            'rotational_speed_rpm': round(n, 2),
            'drive_torque_Nm': T,
            'power_kW': round(P, 3),
            'efficiency_percent': torque_result['efficiency_percent']
        }
    
    def calculate_thrust(self, torque: float, 
                         friction_coef: float = 0.15) -> Dict:
        """
        从扭矩计算推力
        
        Args:
            torque: 驱动扭矩 (N·m)
            friction_coef: 摩擦系数
            
        Returns:
            推力计算结果
        """
        d2 = (self.params['major_dia'] + self.params['minor_dia']) / 2
        p = self.params['pitch']
        
        # 当量摩擦角
        rho_prime = math.atan(friction_coef / math.cos(30 * math.pi / 180))
        
        # 螺纹升角
        lambda_angle = math.atan(p / (math.pi * d2))
        
        # 轴向力 (从扭矩反算)
        F = 2 * torque * 1000 / (d2 * math.tan(lambda_angle + rho_prime))
        
        return {
            'thread_type': self.thread_type,
            'input_torque_Nm': torque,
            'axial_force_N': round(F, 2),
            'axial_force_kN': round(F / 1000, 2),
            'lead_angle_deg': round(math.degrees(lambda_angle), 2),
            'friction_coefficient': friction_coef
        }


class TrapezoidalScrew(ScrewCalculator):
    """梯形螺纹螺旋传动类"""
    
    def __init__(self, diameter: float, pitch: float):
        """
        初始化梯形螺纹
        
        Args:
            diameter: 公称直径 (mm)
            pitch: 螺距 (mm)
        """
        self.diameter = diameter
        self.pitch = pitch
        self.params = {
            'pitch': pitch,
            'major_dia': diameter,
            'minor_dia': diameter - 1.25 * pitch  # 简化
        }
        self.thread_type = f'Tr{int(diameter)}x{int(pitch)}'


if __name__ == "__main__":
    # 示例1：M20螺纹强度校核
    print("=== M20螺纹强度校核 ===")
    screw1 = ScrewCalculator('M20')
    result1 = screw1.check_strength(axial_force=50000)
    for key, value in result1.items():
        print(f"{key}: {value}")
    
    print("\n=== Tr40x7驱动扭矩计算 ===")
    screw2 = ScrewCalculator('Tr40x7')
    result2 = screw2.calculate_torque(axial_force=100000, friction_coef=0.12)
    for key, value in result2.items():
        print(f"{key}: {value}")
    
    print("\n=== 功率计算 ===")
    result3 = screw2.calculate_power(axial_force=100000, speed=500, friction_coef=0.12)
    for key, value in result3.items():
        print(f"{key}: {value}")
    
    print("\n=== 扭矩-推力换算 ===")
    result4 = screw2.calculate_thrust(torque=500, friction_coef=0.12)
    for key, value in result4.items():
        print(f"{key}: {value}")
