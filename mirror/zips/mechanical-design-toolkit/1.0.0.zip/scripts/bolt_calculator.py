#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
螺栓强度校核引擎 (Bolt Strength Calculator)
支持8种螺栓校核场景
符合GB/T 5780、GB/T 3098.1标准
"""

import math
from typing import Dict, Tuple, Optional, List


class BoltStrength:
    """螺栓强度校核类"""
    
    # 螺栓性能等级对应的力学参数 (MPa)
    GRADE_PARAMS = {
        '4.6': {'sigma_s': 240, 'sigma_b': 400, 'tau': 160},
        '4.8': {'sigma_s': 320, 'sigma_b': 400, 'tau': 210},
        '5.6': {'sigma_s': 300, 'sigma_b': 500, 'tau': 200},
        '5.8': {'sigma_s': 400, 'sigma_b': 500, 'tau': 260},
        '6.8': {'sigma_s': 480, 'sigma_b': 600, 'tau': 320},
        '8.8': {'sigma_s': 640, 'sigma_b': 800, 'tau': 420},
        '9.8': {'sigma_s': 720, 'sigma_b': 900, 'tau': 480},
        '10.9': {'sigma_s': 900, 'sigma_b': 1000, 'tau': 600},
        '12.9': {'sigma_s': 1080, 'sigma_b': 1200, 'tau': 720},
    }
    
    # 螺栓公称直径对应的应力截面积 (mm²)
    STRESS_AREA = {
        'M6': 20.1, 'M8': 36.6, 'M10': 58.0, 'M12': 84.3,
        'M14': 115, 'M16': 157, 'M18': 192, 'M20': 245,
        'M22': 303, 'M24': 353, 'M27': 459, 'M30': 561,
        'M33': 694, 'M36': 817, 'M39': 976, 'M42': 1120,
        'M45': 1310, 'M48': 1470, 'M52': 1760, 'M56': 2030,
        'M60': 2360, 'M64': 2680,
    }
    
    def __init__(self, grade: str, diameter: str):
        """
        初始化螺栓参数
        
        Args:
            grade: 性能等级 (如 "8.8", "10.9")
            diameter: 公称直径 (如 "M16", "M20")
        """
        self.grade = grade
        self.diameter = diameter
        self.params = self.GRADE_PARAMS.get(grade, {'sigma_s': 240, 'sigma_b': 400, 'tau': 160})
        self.stress_area = self.STRESS_AREA.get(diameter, 157)  # 默认M16
        
    def check_tension(self, force: float, safety_factor: float = 1.5) -> Dict:
        """
        普通螺栓拉伸强度校核
        
        Args:
            force: 拉伸载荷 (N)
            safety_factor: 安全系数
            
        Returns:
            校核结果字典
        """
        sigma_s = self.params['sigma_s']
        A_s = self.stress_area
        
        # 拉应力
        sigma = force / A_s
        
        # 许用拉应力
        sigma_allow = sigma_s / safety_factor
        
        # 安全系数
        SF = sigma_allow / sigma
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'load_N': force,
            'stress_MPa': round(sigma, 2),
            'allowable_stress_MPa': round(sigma_allow, 2),
            'safety_factor': round(SF, 2),
            'status': status,
            'stress_area_mm2': A_s,
            'yield_strength_MPa': sigma_s
        }
    
    def check_tension_torsion(self, tension_force: float, torque: float,
                               safety_factor: float = 1.5) -> Dict:
        """
        普通螺栓拉伸+扭转复合强度校核
        
        Args:
            tension_force: 拉伸载荷 (N)
            torque: 扭矩 (N·m)
            safety_factor: 安全系数
            
        Returns:
            校核结果字典
        """
        sigma_s = self.params['sigma_s']
        tau_s = self.params['tau']
        A_s = self.stress_area
        
        # 拉应力
        sigma = tension_force / A_s
        
        # 扭转剪应力 (简化计算)
        # 等效为螺纹摩擦扭矩
        d2 = self._get_thread_pitch_diameter()
        tau = torque * 1000 / (0.2 * d2 * A_s)  # 简化公式
        
        # 相当应力 (第四强度理论)
        sigma_eq = math.sqrt(sigma**2 + 3 * tau**2)
        
        # 许用相当应力
        sigma_eq_allow = sigma_s / safety_factor
        
        # 安全系数
        SF = sigma_eq_allow / sigma_eq
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'tension_force_N': tension_force,
            'torque_Nm': torque,
            'tensile_stress_MPa': round(sigma, 2),
            'torsional_stress_MPa': round(tau, 2),
            'equivalent_stress_MPa': round(sigma_eq, 2),
            'allowable_stress_MPa': round(sigma_eq_allow, 2),
            'safety_factor': round(SF, 2),
            'status': status
        }
    
    def check_shear(self, force: float, safety_factor: float = 1.5,
                     hole_diameter: float = None) -> Dict:
        """
        铰制孔螺栓剪切强度校核
        
        Args:
            force: 剪切载荷 (N)
            safety_factor: 安全系数
            hole_diameter: 铰制孔直径 (mm)，默认等于螺栓直径
            
        Returns:
            校核结果字典
        """
        tau_s = self.params['tau']
        
        # 铰制孔螺栓的剪切面积
        if hole_diameter is None:
            # 默认取螺栓杆直径
            hole_diameter = self._get_bolt_diameter()
        
        A_shear = math.pi * (hole_diameter / 2)**2
        
        # 剪应力
        tau = force / A_shear
        
        # 许用剪应力
        tau_allow = tau_s / safety_factor
        
        # 安全系数
        SF = tau_allow / tau
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'shear_force_N': force,
            'shear_stress_MPa': round(tau, 2),
            'allowable_shear_stress_MPa': round(tau_allow, 2),
            'safety_factor': round(SF, 2),
            'shear_area_mm2': round(A_shear, 2),
            'status': status
        }
    
    def check_bearing(self, force: float, thickness: float,
                       safety_factor: float = 1.5) -> Dict:
        """
        铰制孔螺栓挤压强度校核
        
        Args:
            force: 挤压载荷 (N)
            thickness: 被连接件厚度 (mm)
            safety_factor: 安全系数
            
        Returns:
            校核结果字典
        """
        sigma_s = self.params['sigma_s']
        
        # 挤压面积
        d = self._get_bolt_diameter()
        A_bearing = d * thickness
        
        # 挤压应力
        sigma_b = force / A_bearing
        
        # 许用挤压应力 (取材料屈服强度的1.5倍)
        sigma_b_allow = 1.5 * sigma_s / safety_factor
        
        # 安全系数
        SF = sigma_b_allow / sigma_b
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'bearing_force_N': force,
            'bearing_stress_MPa': round(sigma_b, 2),
            'allowable_bearing_stress_MPa': round(sigma_b_allow, 2),
            'safety_factor': round(SF, 2),
            'bearing_area_mm2': round(A_bearing, 2),
            'status': status
        }
    
    def calculate_preload(self, torque: float, friction_coeff: float = 0.15) -> Dict:
        """
        计算预紧力
        
        Args:
            torque: 拧紧扭矩 (N·m)
            friction_coeff: 螺纹摩擦系数
            
        Returns:
            预紧力计算结果
        """
        d2 = self._get_thread_pitch_diameter()
        d_w = self._get_wrench_size()  # 螺母支承面平均直径
        
        # 扭矩系数
        K = 0.16  # 典型值
        
        # 预紧力 (简化公式: T = K * d * F)
        d = self._get_bolt_diameter()
        F_pre = torque * 1000 / (K * d)
        
        # 预紧应力
        sigma_pre = F_pre / self.stress_area
        
        return {
            'torque_Nm': torque,
            'preload_N': round(F_pre, 2),
            'preload_stress_MPa': round(sigma_pre, 2),
            'torque_coefficient': K,
            'friction_coefficient': friction_coeff
        }
    
    def _get_bolt_diameter(self) -> float:
        """获取螺栓直径 (mm)"""
        return float(self.diameter.replace('M', ''))
    
    def _get_thread_pitch_diameter(self) -> float:
        """获取螺纹中径 (简化计算)"""
        d = self._get_bolt_diameter()
        # 粗略估计: d2 ≈ 0.9 * d
        return 0.9 * d
    
    def _get_wrench_size(self) -> float:
        """获取扳手尺寸对应的支承面直径"""
        wrench_sizes = {
            'M6': 10, 'M8': 13, 'M10': 16, 'M12': 18,
            'M16': 24, 'M20': 30, 'M24': 36, 'M30': 46,
        }
        return wrench_sizes.get(self.diameter, 24)
    
    @classmethod
    def get_available_grades(cls) -> List[str]:
        """获取所有可用的性能等级"""
        return list(cls.GRADE_PARAMS.keys())
    
    @classmethod
    def get_available_diameters(cls) -> List[str]:
        """获取所有可用的公称直径"""
        return list(cls.STRESS_AREA.keys())


if __name__ == "__main__":
    # 示例1：M16、8.8级螺栓拉伸强度校核
    print("=== 示例1：拉伸强度校核 ===")
    bolt1 = BoltStrength(grade='8.8', diameter='M16')
    result1 = bolt1.check_tension(force=50000, safety_factor=1.5)
    for key, value in result1.items():
        print(f"{key}: {value}")
    
    print("\n=== 示例2：拉伸+扭转复合校核 ===")
    result2 = bolt1.check_tension_torsion(
        tension_force=50000, torque=150, safety_factor=1.5
    )
    for key, value in result2.items():
        print(f"{key}: {value}")
    
    print("\n=== 示例3：剪切强度校核 ===")
    result3 = bolt1.check_shear(force=30000, safety_factor=1.5)
    for key, value in result3.items():
        print(f"{key}: {value}")
    
    print("\n=== 示例4：预紧力计算 ===")
    result4 = bolt1.calculate_preload(torque=150, friction_coeff=0.15)
    for key, value in result4.items():
        print(f"{key}: {value}")
