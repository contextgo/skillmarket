#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
链传动设计引擎 (Chain Drive Calculator)
支持A/B系列滚子链选型、链轮参数计算
符合GB/T 1243标准
"""

import math
from typing import Dict, List


class ChainCalculator:
    """链传动计算类"""
    
    # 滚子链参数 (部分)
    CHAIN_DATA = {
        '06B': {'pitch': 9.525, 'roller_diameter': 6.35, 'min_width': 5.72, 'tensile_strength': 8900},
        '08B': {'pitch': 12.7, 'roller_diameter': 8.51, 'min_width': 7.75, 'tensile_strength': 17800},
        '10A': {'pitch': 15.875, 'roller_diameter': 10.16, 'min_width': 9.4, 'tensile_strength': 22000},
        '12A': {'pitch': 19.05, 'roller_diameter': 11.91, 'min_width': 12.57, 'tensile_strength': 31300},
        '16A': {'pitch': 25.4, 'roller_diameter': 15.88, 'min_width': 15.75, 'tensile_strength': 55600},
        '20A': {'pitch': 31.75, 'roller_diameter': 19.05, 'min_width': 18.9, 'tensile_strength': 86700},
        '24A': {'pitch': 38.1, 'roller_diameter': 22.23, 'min_width': 25.22, 'tensile_strength': 124500},
        '28A': {'pitch': 44.45, 'roller_diameter': 25.4, 'min_width': 31.55, 'tensile_strength': 169000},
        '32A': {'pitch': 50.8, 'roller_diameter': 28.58, 'min_width': 37.8, 'tensile_strength': 222400},
        '40A': {'pitch': 63.5, 'roller_diameter': 39.68, 'min_width': 47.8, 'tensile_strength': 347000},
    }
    
    def __init__(self, power: float, speed: float, series: str = 'A'):
        """
        初始化链传动参数
        
        Args:
            power: 传递功率 (kW)
            speed: 小链轮转速 (rpm)
            series: 系列 ('A' 或 'B')
        """
        self.power = power
        self.speed = speed
        self.series = series
        
    def select_chain(self, service_factor: float = 1.2) -> Dict:
        """
        链传动选型
        
        Args:
            service_factor: 工况系数
            
        Returns:
            选型结果字典
        """
        # 计算功率
        Pc = self.power * service_factor
        
        # 根据功率和转速选择链号 (简化逻辑)
        if Pc <= 0.5:
            chain_id = '06B' if self.series == 'B' else '06B'
        elif Pc <= 1.5:
            chain_id = '08B' if self.series == 'B' else '10A'
        elif Pc <= 3.0:
            chain_id = '10A' if self.series == 'A' else '08B'
        elif Pc <= 7.5:
            chain_id = '12A' if self.series == 'A' else '10B'
        elif Pc <= 15:
            chain_id = '16A' if self.series == 'A' else '16B'
        elif Pc <= 30:
            chain_id = '20A' if self.series == 'A' else '20B'
        elif Pc <= 50:
            chain_id = '24A' if self.series == 'A' else '24B'
        elif Pc <= 75:
            chain_id = '28A' if self.series == 'A' else '28B'
        elif Pc <= 120:
            chain_id = '32A' if self.series == 'A' else '32B'
        else:
            chain_id = '40A' if self.series == 'A' else '40B'
            
        # 获取链参数
        chain_data = self.CHAIN_DATA.get(chain_id, self.CHAIN_DATA['10A'])
        pitch = chain_data['pitch']
        
        # 推荐小链轮齿数
        if self.speed <= 100:
            z1_recommended = 17
        elif self.speed <= 500:
            z1_recommended = 21
        elif self.speed <= 1000:
            z1_recommended = 25
        elif self.speed <= 1500:
            z1_recommended = 27
        else:
            z1_recommended = 31
            
        # 计算链速
        v = pitch * z1_recommended * self.speed / (60000)
        
        return {
            'chain_id': chain_id,
            'series': self.series,
            'pitch_mm': pitch,
            'design_power_kW': round(Pc, 2),
            'recommended_pinion_teeth': z1_recommended,
            'chain_speed_m_s': round(v, 2),
            'tensile_strength_N': chain_data['tensile_strength'],
            'service_factor': service_factor
        }
    
    def calculate_sprocket(self, chain_id: str, teeth: int) -> Dict:
        """
        计算链轮参数
        
        Args:
            chain_id: 链号
            teeth: 齿数
            
        Returns:
            链轮参数字典
        """
        if chain_id not in self.CHAIN_DATA:
            return {'error': f'未找到链号 {chain_id}'}
            
        chain_data = self.CHAIN_DATA[chain_id]
        p = chain_data['pitch']
        
        # 分度圆直径
        d = p / math.sin(math.pi / teeth)
        
        # 齿顶圆直径 (偶数齿/奇数齿公式)
        if teeth % 2 == 0:
            da = p * (1 + 1 / math.sin(math.pi / teeth))
        else:
            da = p * (1 + 1 / math.tan(math.pi / teeth))
            
        # 齿根圆直径
        df = d - 2 * chain_data['roller_diameter']
        
        return {
            'chain_id': chain_id,
            'teeth': teeth,
            'pitch_mm': p,
            'pitch_circle_diameter_mm': round(d, 2),
            'addendum_circle_diameter_mm': round(da, 2),
            'dedendum_circle_diameter_mm': round(df, 2),
            'roller_diameter_mm': chain_data['roller_diameter']
        }
    
    def calculate_power_transmission(self, chain_id: str, teeth: int,
                                    speed: float) -> Dict:
        """
        计算传动功率（用于输送辊道等）
        
        Args:
            chain_id: 链号
            teeth: 链轮齿数
            speed: 链速 (m/min)
            
        Returns:
            功率计算结果
        """
        chain_data = self.CHAIN_DATA.get(chain_id, self.CHAIN_DATA['10A'])
        
        # 单排链传递功率 (简化公式)
        P_single = chain_data['tensile_strength'] * 0.1 / 1000  # kW
        
        return {
            'chain_id': chain_id,
            'single_row_power_kW': round(P_single, 2),
            'speed_m_min': speed,
            'note': '实际传递功率需考虑工况系数、润滑条件等'
        }


if __name__ == "__main__":
    # 示例1：链传动选型
    print("=== 链传动选型 ===")
    calc = ChainCalculator(power=10, speed=960, series='A')
    result = calc.select_chain(service_factor=1.2)
    for key, value in result.items():
        print(f"{key}: {value}")
    
    print("\n=== 链轮参数计算 ===")
    sprocket = calc.calculate_sprocket(chain_id='12A', teeth=19)
    for key, value in sprocket.items():
        print(f"{key}: {value}")
    
    print("\n=== 输送功率计算 ===")
    power = calc.calculate_power_transmission(chain_id='12A', teeth=19, speed=20)
    for key, value in power.items():
        print(f"{key}: {value}")
