#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
硬度换算引擎 (Hardness Converter)
支持HB/HR/HV/HS硬度单位相互换算
符合GB/T 1172标准
"""

from typing import Dict


class HardnessConverter:
    """硬度换算类"""
    
    # 近似换算系数 (简化，实际应使用查表插值)
    CONVERSION_TABLE = {
        'HRC_to_HB': {
            '20': 225, '25': 245, '30': 285, '35': 320,
            '40': 365, '45': 410, '50': 455, '55': 530,
            '60': 600, '65': 670
        },
        'HB_to_HRC': {
            200: 14, 225: 20, 245: 25, 285: 30,
            320: 35, 365: 40, 410: 45, 455: 50,
            530: 55, 600: 60, 670: 65
        }
    }
    
    @staticmethod
    def hrc_to_hb(hrc: float) -> Dict:
        """
        HRC换算为HB
        
        Args:
            hrc: 洛氏硬度C标尺
            
        Returns:
            换算结果
        """
        # 查表插值 (简化)
        table = HardnessConverter.CONVERSION_TABLE['HRC_to_HB']
        
        # 找到相邻的两个键值
        keys = sorted([int(k) for k in table.keys()])
        
        if hrc <= keys[0]:
            hb = table[str(keys[0])]
        elif hrc >= keys[-1]:
            hb = table[str(keys[-1])]
        else:
            # 线性插值
            for i in range(len(keys) - 1):
                if keys[i] <= hrc <= keys[i+1]:
                    hb1 = table[str(keys[i])]
                    hb2 = table[str(keys[i+1])]
                    hb = hb1 + (hb2 - hb1) * (hrc - keys[i]) / (keys[i+1] - keys[i])
                    break
            else:
                hb = 200
        
        return {
            'input_HRC': hrc,
            'converted_HB': round(hb, 1),
            'standard': 'GB/T 1172',
            'note': '近似换算，精确值请查标准表格'
        }
    
    @staticmethod
    def hb_to_hrc(hb: float) -> Dict:
        """
        HB换算为HRC
        
        Args:
            hb: 布氏硬度
            
        Returns:
            换算结果
        """
        # 反过来查表
        table = HardnessConverter.CONVERSION_TABLE['HB_to_HRC']
        
        keys = sorted(table.keys())
        
        if hb <= keys[0]:
            hrc = table[keys[0]]
        elif hb >= keys[-1]:
            hrc = table[keys[-1]]
        else:
            # 线性插值
            for i in range(len(keys) - 1):
                if keys[i] <= hb <= keys[i+1]:
                    hrc1 = table[keys[i]]
                    hrc2 = table[keys[i+1]]
                    hrc = hrc1 + (hrc2 - hrc1) * (hb - keys[i]) / (keys[i+1] - keys[i])
                    break
            else:
                hrc = 20
        
        return {
            'input_HB': hb,
            'converted_HRC': round(hrc, 1),
            'standard': 'GB/T 1172',
            'note': '近似换算，精确值请查标准表格'
        }
    
    @staticmethod
    def hv_to_hb(hv: float) -> Dict:
        """
        HV换算为HB (近似)
        
        Args:
            hv: 维氏硬度
            
        Returns:
            换算结果
        """
        # 近似关系: HB ≈ HV (当HB < 450时)
        if hv <= 450:
            hb = hv
        else:
            hb = hv * 0.95  # 粗略修正
            
        return {
            'input_HV': hv,
            'approximated_HB': round(hb, 1),
            'standard': 'GB/T 1172',
            'note': 'HV与HB在450以下相近'
        }
    
    @staticmethod
    def hb_to_hv(hb: float) -> Dict:
        """
        HB换算为HV (近似)
        
        Args:
            hb: 布氏硬度
            
        Returns:
            换算结果
        """
        if hb <= 450:
            hv = hb
        else:
            hv = hb / 0.95
            
        return {
            'input_HB': hb,
            'approximated_HV': round(hv, 1),
            'standard': 'GB/T 1172',
            'note': '近似换算'
        }
    
    @staticmethod
    def hs_to_hb(hs: float) -> Dict:
        """
        HS换算为HB (近似)
        
        Args:
            hs: 肖氏硬度
            
        Returns:
            换算结果
        """
        # 近似公式: HB ≈ HS × 6.5
        hb = hs * 6.5
            
        return {
            'input_HS': hs,
            'approximated_HB': round(hb, 1),
            'formula': 'HB ≈ HS × 6.5',
            'note': '近似换算'
        }
    
    @staticmethod
    def convert(input_value: float, from_unit: str, 
               to_unit: str) -> Dict:
        """
        通用硬度换算接口
        
        Args:
            input_value: 输入硬度值
            from_unit: 原单位 ('HB', 'HRC', 'HV', 'HS')
            to_unit: 目标单位
            
        Returns:
            换算结果
        """
        if from_unit == 'HRC' and to_unit == 'HB':
            return HardnessConverter.hrc_to_hb(input_value)
        elif from_unit == 'HB' and to_unit == 'HRC':
            return HardnessConverter.hb_to_hrc(input_value)
        elif from_unit == 'HV' and to_unit == 'HB':
            return HardnessConverter.hv_to_hb(input_value)
        elif from_unit == 'HB' and to_unit == 'HV':
            return HardnessConverter.hb_to_hv(input_value)
        elif from_unit == 'HS' and to_unit == 'HB':
            return HardnessConverter.hs_to_hb(input_value)
        else:
            return {
                'error': f'不支持的换算: {from_unit} -> {to_unit}',
                'supported': ['HRC<->HB', 'HV<->HB', 'HS->HB']
            }


if __name__ == "__main__":
    # 示例1：HRC30换算为HB
    print("=== HRC -> HB ===")
    result1 = HardnessConverter.hrc_to_hb(30)
    for key, value in result1.items():
        print(f"{key}: {value}")
    
    print("\n=== HB -> HRC ===")
    result2 = HardnessConverter.hb_to_hrc(285)
    for key, value in result2.items():
        print(f"{key}: {value}")
    
    print("\n=== HV -> HB ===")
    result3 = HardnessConverter.hv_to_hb(300)
    for key, value in result3.items():
        print(f"{key}: {value}")
    
    print("\n=== 通用换算接口 ===")
    result4 = HardnessConverter.convert(50, 'HRC', 'HB')
    for key, value in result4.items():
        print(f"{key}: {value}")
