#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
公差配合查询引擎 (Tolerance and Fit Calculator)
支持ISO公差等级、轴孔配合查询
符合GB/T 1800.1、GB/T 1801标准
"""

import math
from typing import Dict, List, Tuple


class ToleranceFit:
    """公差配合查询类"""
    
    # ISO公差等级对应的公差单位公式系数
    # IT = a * i  (i = 0.45 * d^(1/3) + 0.001 * d)
    # 不同等级对应的a值
    IT_COEFFICIENTS = {
        'IT01': 0.3, 'IT0': 0.5, 'IT1': 0.8, 'IT2': 1.2,
        'IT3': 1.6, 'IT4': 2.5, 'IT5': 4, 'IT6': 6,
        'IT7': 10, 'IT8': 13, 'IT9': 25, 'IT10': 40,
        'IT11': 64, 'IT12': 100, 'IT13': 160, 'IT14': 250,
        'IT15': 400, 'IT16': 640, 'IT17': 1000, 'IT18': 1600
    }
    
    # 基本偏差系列 (轴的)
    SHAFT_DEVIATIONS = {
        'c': {'type': 'gap', 'formula': 'c = -0.34D + 9.2'},
        'd': {'type': 'gap', 'formula': 'd = -16D^0.44'},
        'e': {'type': 'gap', 'formula': 'e = -11D^0.41'},
        'f': {'type': 'gap', 'formula': 'f = -5.5D^0.41'},
        'g': {'type': 'gap', 'formula': 'g = -2.5D^0.34'},
        'h': {'type': 'base', 'formula': 'h = 0'},
        'js': {'type': 'transition', 'formula': 'js = ±IT/2'},
        'k': {'type': 'transition', 'formula': 'k = +0.6D^0.33'},
        'm': {'type': 'transition', 'formula': 'm = +IT7 - 2.5D^0.34'},
        'n': {'type': 'transition', 'formula': 'n = +5D^0.34'},
        'p': {'type': 'interference', 'formula': 'p = +IT7 + 0'},
        'r': {'type': 'interference', 'formula': 'r = +0.8D^0.2'},
        's': {'type': 'interference', 'formula': 's = +D^0.4'},
        't': {'type': 'interference', 'formula': 't = +0.9D^0.4'},
        'u': {'type': 'interference', 'formula': 'u = +1.4D^0.41'},
    }
    
    # 基本偏差系列 (孔的)
    HOLE_DEVIATIONS = {
        'C': {'type': 'gap', 'formula': 'C = +0.34D + 9.2'},
        'D': {'type': 'gap', 'formula': 'D = +16D^0.44'},
        'E': {'type': 'gap', 'formula': 'E = +11D^0.41'},
        'F': {'type': 'gap', 'formula': 'F = +5.5D^0.41'},
        'G': {'type': 'gap', 'formula': 'G = +2.5D^0.34'},
        'H': {'type': 'base', 'formula': 'H = 0'},
        'JS': {'type': 'transition', 'formula': 'JS = ±IT/2'},
        'K': {'type': 'transition', 'formula': 'K = -IT7 + 0.6D^0.33'},
        'M': {'type': 'transition', 'formula': 'M = -IT7 + 2.5D^0.34'},
        'N': {'type': 'transition', 'formula': 'N = -IT7 + 5D^0.34'},
        'P': {'type': 'interference', 'formula': 'P = -IT7 + 0'},
        'R': {'type': 'interference', 'formula': 'R = -0.8D^0.2'},
        'S': {'type': 'interference', 'formula': 'S = -D^0.4'},
    }
    
    def __init__(self, basic_size: float):
        """
        初始化公差配合参数
        
        Args:
            basic_size: 基本尺寸 (mm)
        """
        self.basic_size = basic_size
        self.D = basic_size  # 尺寸分段的计算用D
        
    def calculate_standard_tolerance(self, tolerance_grade: str) -> Dict:
        """
        计算标准公差值 (IT值)
        
        Args:
            tolerance_grade: 公差等级 ('IT01'~'IT18')
            
        Returns:
            标准公差值 (μm)
        """
        # 计算公差单位 i (μm)
        # i = 0.45 * D^(1/3) + 0.001 * D  (D单位: mm)
        i = 0.45 * (self.D ** (1/3)) + 0.001 * self.D
        
        # 获取系数
        a = self.IT_COEFFICIENTS.get(tolerance_grade, 10)
        
        # 标准公差
        IT = a * i
        
        return {
            'basic_size_mm': self.basic_size,
            'tolerance_grade': tolerance_grade,
            'tolerance_unit_i_um': round(i, 2),
            'coefficient_a': a,
            'standard_tolerance_um': round(IT, 1),
            'standard_tolerance_mm': round(IT / 1000, 4),
            'note': '标准公差值(GB/T 1800.1)'
        }
    
    def query_shaft_deviation(self, deviation_code: str, 
                              tolerance_grade: str) -> Dict:
        """
        查询轴的基本偏差
        
        Args:
            deviation_code: 偏差代号 ('c', 'd', 'e', ... 'u')
            tolerance_grade: 公差等级 ('IT5'~'IT18')
            
        Returns:
            偏差值字典
        """
        if deviation_code not in self.SHAFT_DEVIATIONS:
            return {'error': f'不支持的轴偏差代号: {deviation_code}'}
        
        # 简化计算：根据尺寸分段查表
        # 此处仅提供示例算法，实际应查GB/T 1800.1表
        D = self.basic_size
        
        # 示例：h偏差 (基准轴)
        if deviation_code == 'h':
            upper_dev = 0  # μm
            lower_dev = -self._get_approx_IT(tolerance_grade)  # 简化
        # 示例：g偏差
        elif deviation_code == 'g':
            upper_dev = -2.5 * (D ** 0.34) * 1000  # 简化为μm
            lower_dev = upper_dev - self._get_approx_IT(tolerance_grade)
        # 其他偏差省略...
        else:
            upper_dev = 0
            lower_dev = -self._get_approx_IT(tolerance_grade)
        
        return {
            'basic_size_mm': D,
            'deviation_code': deviation_code,
            'tolerance_grade': tolerance_grade,
            'upper_deviation_um': round(upper_dev, 1),
            'lower_deviation_um': round(lower_dev, 1),
            'upper_deviation_mm': round(upper_dev / 1000, 4),
            'lower_deviation_mm': round(lower_dev / 1000, 4),
            'tolerance_um': round(abs(upper_dev - lower_dev), 1),
            'type': self.SHAFT_DEVIATIONS[deviation_code]['type'],
            'note': '轴基本偏差(简化计算)，精确值请查GB/T 1800.1'
        }
    
    def query_hole_deviation(self, deviation_code: str,
                              tolerance_grade: str) -> Dict:
        """
        查询孔的基本偏差
        
        Args:
            deviation_code: 偏差代号 ('C', 'D', 'E', ... 'S')
            tolerance_grade: 公差等级
            
        Returns:
            偏差值字典
        """
        if deviation_code not in self.HOLE_DEVIATIONS:
            return {'error': f'不支持的孔偏差代号: {deviation_code}'}
        
        D = self.basic_size
        
        # 示例：H偏差 (基准孔)
        if deviation_code == 'H':
            lower_dev = 0  # μm
            upper_dev = self._get_approx_IT(tolerance_grade)
        # 示例：G偏差
        elif deviation_code == 'G':
            lower_dev = 2.5 * (D ** 0.34) * 1000  # 简化为μm
            upper_dev = lower_dev + self._get_approx_IT(tolerance_grade)
        else:
            lower_dev = 0
            upper_dev = self._get_approx_IT(tolerance_grade)
        
        return {
            'basic_size_mm': D,
            'deviation_code': deviation_code,
            'tolerance_grade': tolerance_grade,
            'lower_deviation_um': round(lower_dev, 1),
            'upper_deviation_um': round(upper_dev, 1),
            'lower_deviation_mm': round(lower_dev / 1000, 4),
            'upper_deviation_mm': round(upper_dev / 1000, 4),
            'tolerance_um': round(abs(upper_dev - lower_dev), 1),
            'type': self.HOLE_DEVIATIONS[deviation_code]['type'],
            'note': '孔基本偏差(简化计算)，精确值请查GB/T 1800.1'
        }
    
    def calculate_fit(self, hole_fit: str, shaft_fit: str) -> Dict:
        """
        计算配合间隙/过盈
        
        Args:
            hole_fit: 孔配合代号 (如 'H7')
            shaft_fit: 轴配合代号 (如 'g6')
            
        Returns:
            配合参数
        """
        # 解析配合代号
        hole_dev = hole_fit[0]
        hole_grade = 'IT' + hole_fit[1:]
        shaft_dev = shaft_fit[0].lower()
        shaft_grade = 'IT' + shaft_fit[1:]
        
        # 查询孔偏差
        hole_deviation = self.query_hole_deviation(hole_dev, hole_grade)
        if 'error' in hole_deviation:
            return hole_deviation
        
        # 查询轴偏差
        shaft_deviation = self.query_shaft_deviation(shaft_dev, shaft_grade)
        if 'error' in shaft_deviation:
            return shaft_deviation
        
        # 计算配合
        # 间隙 = 孔下限 - 轴上限
        # 过盈 = 轴下限 - 孔上限
        hole_min = hole_deviation['lower_deviation_um']
        hole_max = hole_deviation['upper_deviation_um']
        shaft_min = shaft_deviation['lower_deviation_um']
        shaft_max = shaft_deviation['upper_deviation_um']
        
        clearance_min = hole_min - shaft_max  # 最小间隙
        clearance_max = hole_max - shaft_min  # 最大间隙
        
        # 判断配合类型
        if clearance_min >= 0 and clearance_max >= 0:
            fit_type = '间隙配合 (Clearance Fit)'
            interference_min = 0
            interference_max = 0
        elif clearance_min < 0 and clearance_max <= 0:
            fit_type = '过盈配合 (Interference Fit)'
            interference_min = -clearance_max  # 最小过盈
            interference_max = -clearance_min  # 最大过盈
            clearance_min = 0
            clearance_max = 0
        else:
            fit_type = '过渡配合 (Transition Fit)'
            interference_min = -clearance_max if clearance_max < 0 else 0
            interference_max = -clearance_min if clearance_min < 0 else 0
            clearance_min = clearance_min if clearance_min > 0 else 0
            clearance_max = clearance_max if clearance_max > 0 else 0
        
        return {
            'basic_size_mm': self.basic_size,
            'hole_fit': hole_fit,
            'shaft_fit': shaft_fit,
            'fit_type': fit_type,
            'hole_deviation_um': f"{hole_min}~{hole_max}",
            'shaft_deviation_um': f"{shaft_min}~{shaft_max}",
            'min_clearance_um': round(clearance_min, 1),
            'max_clearance_um': round(clearance_max, 1),
            'min_interference_um': round(interference_min, 1),
            'max_interference_um': round(interference_max, 1),
            'standard': 'GB/T 1801'
        }
    
    def _get_approx_IT(self, tolerance_grade: str) -> float:
        """获取近似IT值 (μm)"""
        grade_num = int(tolerance_grade.replace('IT', ''))
        # 简化：IT = 10 * grade_num (μm) 仅用于演示
        return 10 * grade_num
    
    @classmethod
    def list_shaft_deviations(cls) -> List[str]:
        """列出所有轴偏差代号"""
        return list(cls.SHAFT_DEVIATIONS.keys())
    
    @classmethod
    def list_hole_deviations(cls) -> List[str]:
        """列出所有孔偏差代号"""
        return list(cls.HOLE_DEVIATIONS.keys())
    
    @classmethod
    def get_fit_recommendations(cls, application: str) -> Dict:
        """
        根据应用场景推荐配合
        
        Args:
            application: 应用场景 ('bearing', 'gear', 'shaft', 'housing')
            
        Returns:
            推荐配合
        """
        recommendations = {
            'bearing': {
                'description': '滚动轴承配合',
                'hole': 'H7', 'shaft': 'k6',
                'note': '内圈与轴：k6，外圈与孔：H7'
            },
            'gear': {
                'description': '齿轮配合',
                'hole': 'H7', 'shaft': 'r6',
                'note': '齿轮与轴通常采用过盈配合'
            },
            'shaft': {
                'description': '精密轴配合',
                'hole': 'H7', 'shaft': 'g6',
                'note': '高精度滑动配合'
            },
            'housing': {
                'description': '箱体孔配合',
                'hole': 'H8', 'shaft': 'h7',
                'note': '一般公差配合'
            }
        }
        return recommendations.get(application, {'error': '未找到推荐配合'})


if __name__ == "__main__":
    # 示例1：计算标准公差
    print("=== 标准公差计算 (基本尺寸50mm) ===")
    tf = ToleranceFit(basic_size=50)
    result1 = tf.calculate_standard_tolerance(tolerance_grade='IT7')
    for key, value in result1.items():
        print(f"  {key}: {value}")
    
    print("\n=== 轴基本偏差查询 (h7) ===")
    result2 = tf.query_shaft_deviation(deviation_code='h', tolerance_grade='IT7')
    for key, value in result2.items():
        print(f"  {key}: {value}")
    
    print("\n=== 孔基本偏差查询 (H7) ===")
    result3 = tf.query_hole_deviation(deviation_code='H', tolerance_grade='IT7')
    for key, value in result3.items():
        print(f"  {key}: {value}")
    
    print("\n=== 配合计算 (H7/g6) ===")
    result4 = tf.calculate_fit(hole_fit='H7', shaft_fit='g6')
    for key, value in result4.items():
        print(f"  {key}: {value}")
    
    print("\n=== 配合推荐 (轴承应用) ===")
    result5 = ToleranceFit.get_fit_recommendations('bearing')
    for key, value in result5.items():
        print(f"  {key}: {value}")
