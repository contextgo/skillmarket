#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
键连接计算引擎 (Key Connection Calculator)
支持平键、楔键、花键强度校核
符合GB/T 1095、GB/T 1144标准
"""

import math
from typing import Dict, List


class KeyCalculator:
    """键连接计算类"""
    
    # 平键尺寸 (简化)
    FLAT_KEY_SIZES = {
        6: {'b': 6, 'h': 6, 't': 3.5, 't1': 2.8},
        8: {'b': 8, 'h': 7, 't': 4.0, 't1': 3.3},
        10: {'b': 10, 'h': 8, 't': 5.0, 't1': 3.3},
        12: {'b': 12, 'h': 8, 't': 5.0, 't1': 3.3},
        14: {'b': 14, 'h': 9, 't': 5.5, 't1': 3.8},
        16: {'b': 16, 'h': 10, 't': 6.0, 't1': 4.3},
        18: {'b': 18, 'h': 11, 't': 7.0, 't1': 4.4},
        20: {'b': 20, 'h': 12, 't': 7.5, 't1': 4.9},
        22: {'b': 22, 'h': 14, 't': 9.0, 't1': 5.4},
        25: {'b': 25, 'h': 14, 't': 9.0, 't1': 5.4},
        28: {'b': 28, 'h': 16, 't': 10.0, 't1': 6.4},
        32: {'b': 32, 'h': 18, 't': 11.0, 't1': 7.4},
        36: {'b': 36, 'h': 20, 't': 12.0, 't1': 8.4},
        40: {'b': 40, 'h': 22, 't': 13.0, 't1': 9.4},
        45: {'b': 45, 'h': 25, 't': 15.0, 't1': 10.4},
        50: {'b': 50, 'h': 28, 't': 17.0, 't1': 11.4},
    }
    
    def __init__(self, shaft_diameter: float):
        """
        初始化键参数
        
        Args:
            shaft_diameter: 轴径 (mm)
        """
        self.shaft_diameter = shaft_diameter
        # 自动选择键尺寸
        self.key_size = self._select_key_size(shaft_diameter)
        
    def _select_key_size(self, d: float) -> Dict:
        """根据轴径选择键尺寸"""
        for d_key in sorted(self.FLAT_KEY_SIZES.keys()):
            if d <= d_key * 3:  # 简化匹配规则
                return self.FLAT_KEY_SIZES[d_key]
        # 默认最大
        return self.FLAT_KEY_SIZES[50]
    
    def check_flat_key(self, torque: float, length: float,
                       material: str = "45") -> Dict:
        """
        平键强度校核
        
        Args:
            torque: 传递扭矩 (N·m)
            length: 键长 (mm)
            material: 键材料
            
        Returns:
            校核结果
        """
        b = self.key_size['b']
        h = self.key_size['h']
        d = self.shaft_diameter
        
        # 挤压应力 (工作面)
        # 假设载荷在键工作面上均匀分布
        A_squeeze = length * h / 2  # 简化为三角形分布
        F = torque * 1000 / (d / 2)  # 圆周力
        sigma_squeeze = F / A_squeeze

        # 剪应力
        A_shear = b * length
        tau = F / A_shear
        
        # 许用应力 (简化)
        if material == "45":
            sigma_allow = 120  # MPa
            tau_allow = 80  # MPa
        else:
            sigma_allow = 100
            tau_allow = 60
            
        # 安全系数
        SF_squeeze = sigma_allow / sigma_squeeze
        SF_shear = tau_allow / tau
        
        status = 'PASS' if min(SF_squeeze, SF_shear) >= 1.0 else 'FAIL'
        
        return {
            'shaft_diameter_mm': d,
            'key_size': f"{b}×{h}",
            'key_length_mm': length,
            'torque_Nm': torque,
            'circumferential_force_N': round(F, 2),
            'squeeze_stress_MPa': round(sigma_squeeze, 2),
            'shear_stress_MPa': round(tau, 2),
            'allowable_squeeze_stress_MPa': sigma_allow,
            'allowable_shear_stress_MPa': tau_allow,
            'safety_factor_squeeze': round(SF_squeeze, 2),
            'safety_factor_shear': round(SF_shear, 2),
            'status': status,
            'standard': 'GB/T 1095'
        }
    
    def check_spline(self, torque: float, teeth: int = 6,
                     material: str = "45") -> Dict:
        """
        花键强度校核 (简化)
        
        Args:
            torque: 扭矩 (N·m)
            teeth: 齿数
            material: 材料
            
        Returns:
            校核结果
        """
        d = self.shaft_diameter
        
        # 花键平均直径 (简化)
        d_m = d * 0.8
        
        # 挤压应力
        h = d * 0.1  # 齿高
        A_squeeze = math.pi * d_m * h * teeth * 0.8  # 简化
        F = torque * 1000 / (d_m / 2)
        sigma_squeeze = F / A_squeeze
        
        # 许用应力
        sigma_allow = 100 if material == "45" else 80
        
        SF = sigma_allow / sigma_squeeze
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'shaft_diameter_mm': d,
            'spline_teeth': teeth,
            'torque_Nm': torque,
            'squeeze_stress_MPa': round(sigma_squeeze, 2),
            'allowable_stress_MPa': sigma_allow,
            'safety_factor': round(SF, 2),
            'status': status,
            'note': '花键强度校核(简化计算)'
        }
    
    @classmethod
    def list_key_sizes(cls, shaft_diameter: float = None) -> List[Dict]:
        """列出可用的键尺寸"""
        if shaft_diameter:
            # 返回适合的键
            calculator = cls(shaft_diameter)
            return [calculator.key_size]
        else:
            # 返回所有键尺寸
            return [{'shaft_d': k, **v} for k, v in cls.FLAT_KEY_SIZES.items()]


if __name__ == "__main__":
    # 示例1：平键强度校核
    print("=== 平键强度校核 ===")
    kc = KeyCalculator(shaft_diameter=50)
    result = kc.check_flat_key(torque=500, length=50, material="45")
    for k, v in result.items():
        print(f"  {k}: {v}")
    
    print("\n=== 花键强度校核 ===")
    result2 = kc.check_spline(torque=800, teeth=8, material="45")
    for k, v in result2.items():
        print(f"  {k}: {v}")
