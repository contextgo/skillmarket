#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
截面强度校核引擎 (Cross Section Strength Calculator)
支持10种截面类型、型材数据库(GB/T 706)
符合材料力学、GB/T 706标准
"""

import math
from typing import Dict, Tuple, Optional, List


class CrossSection:
    """截面强度计算类"""
    
    # 截面类型枚举
    SECTION_TYPES = [
        'rectangular',      # 矩形
        'hollow_rect',      # 空心矩形
        'circular',         # 圆形
        'hollow_circ',      # 空心圆
        'i_beam',          # 工字钢
        'h_beam',          # H型钢
        'channel',          # 槽钢
        'angle',            # 角钢
        't_beam',          # T型钢
        'custom'            # 自定义
    ]
    
    def __init__(self, section_type: str, dimensions: Dict):
        """
        初始化截面参数
        
        Args:
            section_type: 截面类型
            dimensions: 截面尺寸字典
                - rectangular: {b, h}
                - hollow_rect: {b, h, t1, t2}
                - circular: {d}
                - hollow_circ: {d, t}
                - i_beam: {h, b, tw, tf}
                - h_beam: {h, b, tw, tf}
                - channel: {h, b, tw, tf}
                - angle: {b, d} 或 {b1, b2, d}
                - t_beam: {h, b, tw, tf}
        """
        self.section_type = section_type
        self.dimensions = dimensions
        
    def calculate_properties(self) -> Dict:
        """
        计算截面几何特性
        
        Returns:
            包含截面几何参数的字典
        """
        if self.section_type == 'rectangular':
            return self._rectangular_properties()
        elif self.section_type == 'hollow_rect':
            return self._hollow_rect_properties()
        elif self.section_type == 'circular':
            return self._circular_properties()
        elif self.section_type == 'hollow_circ':
            return self._hollow_circ_properties()
        elif self.section_type in ['i_beam', 'h_beam']:
            return self._i_beam_properties()
        elif self.section_type == 'channel':
            return self._channel_properties()
        elif self.section_type == 'angle':
            return self._angle_properties()
        elif self.section_type == 't_beam':
            return self._t_beam_properties()
        else:
            raise ValueError(f"不支持的截面类型: {self.section_type}")
    
    def _rectangular_properties(self) -> Dict:
        """矩形截面几何特性"""
        b = self.dimensions['b']  # 宽度
        h = self.dimensions['h']  # 高度
        
        A = b * h                      # 面积
        Ix = b * h**3 / 12            # 对x轴惯性矩
        Iy = h * b**3 / 12            # 对y轴惯性矩
        Wx = Ix / (h / 2)            # 抗弯截面系数
        Wy = Iy / (b / 2)            # 抗弯截面系数
        Ip = Ix + Iy                  # 极惯性矩
        Wt = Ip / (math.sqrt(b**2 + h**2) / 2)  # 抗扭截面系数(近似)
        
        return {
            'area_mm2': round(A, 2),
            'moment_inertia_x_mm4': round(Ix, 2),
            'moment_inertia_y_mm4': round(Iy, 2),
            'section_modulus_x_mm3': round(Wx, 2),
            'section_modulus_y_mm3': round(Wy, 2),
            'polar_moment_mm4': round(Ip, 2),
            'torsion_modulus_mm3': round(Wt, 2)
        }
    
    def _circular_properties(self) -> Dict:
        """圆形截面几何特性"""
        d = self.dimensions['d']
        
        A = math.pi * d**2 / 4
        I = math.pi * d**4 / 64
        W = math.pi * d**3 / 32
        Ip = 2 * I
        Wt = W  # 圆截面抗扭截面系数等于抗弯截面系数
        
        return {
            'area_mm2': round(A, 2),
            'moment_inertia_mm4': round(I, 2),
            'section_modulus_mm3': round(W, 2),
            'polar_moment_mm4': round(Ip, 2),
            'torsion_modulus_mm3': round(Wt, 2)
        }
    
    def _hollow_circ_properties(self) -> Dict:
        """空心圆截面几何特性"""
        d = self.dimensions['d']    # 外径
        t = self.dimensions['t']    # 壁厚
        di = d - 2 * t              # 内径
        
        A = math.pi * (d**2 - di**2) / 4
        I = math.pi * (d**4 - di**4) / 64
        W = math.pi * (d**4 - di**4) / (32 * d)
        Ip = 2 * I
        Wt = W
        
        return {
            'area_mm2': round(A, 2),
            'outer_diameter_mm': d,
            'inner_diameter_mm': di,
            'moment_inertia_mm4': round(I, 2),
            'section_modulus_mm3': round(W, 2),
            'polar_moment_mm4': round(Ip, 2),
            'torsion_modulus_mm3': round(Wt, 2)
        }
    
    def _hollow_rect_properties(self) -> Dict:
        """空心矩形截面几何特性"""
        b = self.dimensions['b']    # 外宽
        h = self.dimensions['h']    # 外高
        t1 = self.dimensions['t1']  # 壁厚(宽方向)
        t2 = self.dimensions['t2']  # 壁厚(高方向)
        
        bi = b - 2 * t1  # 内宽
        hi = h - 2 * t2  # 内高
        
        A = b * h - bi * hi
        Ix = (b * h**3 - bi * hi**3) / 12
        Iy = (h * b**3 - hi * bi**3) / 12
        Wx = Ix / (h / 2)
        Wy = Iy / (b / 2)
        
        return {
            'area_mm2': round(A, 2),
            'moment_inertia_x_mm4': round(Ix, 2),
            'moment_inertia_y_mm4': round(Iy, 2),
            'section_modulus_x_mm3': round(Wx, 2),
            'section_modulus_y_mm3': round(Wy, 2)
        }
    
    def _i_beam_properties(self) -> Dict:
        """工字钢/H型钢几何特性"""
        h = self.dimensions['h']    # 高度
        b = self.dimensions['b']    # 翼缘宽度
        tw = self.dimensions['tw']  # 腹板厚度
        tf = self.dimensions['tf']  # 翼缘厚度
        
        # 面积
        A = 2 * b * tf + (h - 2 * tf) * tw
        
        # 对x轴惯性矩
        Ix = b * h**3 / 12 - (b - tw) * (h - 2 * tf)**3 / 12
        
        # 对y轴惯性矩
        Iy = 2 * (tf * b**3 / 12) + (h - 2 * tf) * tw**3 / 12
        
        Wx = Ix / (h / 2)
        Wy = Iy / (b / 2)
        
        return {
            'area_mm2': round(A, 2),
            'height_mm': h,
            'flange_width_mm': b,
            'web_thickness_mm': tw,
            'flange_thickness_mm': tf,
            'moment_inertia_x_mm4': round(Ix, 2),
            'moment_inertia_y_mm4': round(Iy, 2),
            'section_modulus_x_mm3': round(Wx, 2),
            'section_modulus_y_mm3': round(Wy, 2)
        }
    
    def _channel_properties(self) -> Dict:
        """槽钢几何特性 (简化计算)"""
        h = self.dimensions['h']
        b = self.dimensions['b']
        tw = self.dimensions['tw']
        tf = self.dimensions['tf']
        
        # 面积
        A = 2 * b * tf + (h - 2 * tf) * tw
        
        # 对x轴惯性矩
        Ix = b * h**3 / 12 - (b - tw) * (h - 2 * tf)**3 / 12
        
        # 对y轴惯性矩 (需要考虑翼缘不对称)
        # 简化：按对称计算
        Iy = 2 * (tf * b**3 / 12) + (h - 2 * tf) * tw**3 / 12
        
        Wx = Ix / (h / 2)
        
        return {
            'area_mm2': round(A, 2),
            'moment_inertia_x_mm4': round(Ix, 2),
            'moment_inertia_y_mm4': round(Iy, 2),
            'section_modulus_x_mm3': round(Wx, 2)
        }
    
    def _angle_properties(self) -> Dict:
        """角钢几何特性 (简化计算)"""
        if 'b2' in self.dimensions:  # 不等边角钢
            b1 = self.dimensions['b1']
            b2 = self.dimensions['b2']
            d = self.dimensions['d']
            # 简化计算
            A = d * (b1 + b2 - d)
        else:  # 等边角钢
            b = self.dimensions['b']
            d = self.dimensions['d']
            A = 2 * b * d - d**2
        
        return {
            'area_mm2': round(A, 2),
            'note': '角钢截面特性已简化，精确计算请查GB/T 706'
        }
    
    def _t_beam_properties(self) -> Dict:
        """T型钢几何特性"""
        h = self.dimensions['h']
        b = self.dimensions['b']
        tw = self.dimensions['tw']
        tf = self.dimensions['tf']
        
        # 面积
        A = b * tf + (h - tf) * tw
        
        # 形心位置 (从顶部算起)
        yc = (b * tf * tf / 2 + (h - tf) * tw * (tf + (h - tf) / 2)) / A
        
        # 对形心轴惯性矩
        Ix = (b * tf**3 / 12 + b * tf * (tf / 2 - yc)**2 +
              (h - tf) * tw**3 / 12 + (h - tf) * tw * (tf + (h - tf) / 2 - yc)**2)
        
        Wx_top = Ix / yc
        Wx_bottom = Ix / (h - yc)
        
        return {
            'area_mm2': round(A, 2),
            'centroid_mm': round(yc, 2),
            'moment_inertia_x_mm4': round(Ix, 2),
            'section_modulus_top_mm3': round(Wx_top, 2),
            'section_modulus_bottom_mm3': round(Wx_bottom, 2)
        }


class StrengthCheck:
    """强度校核类"""
    
    def __init__(self, section: CrossSection, material: Dict):
        """
        初始化强度校核
        
        Args:
            section: 截面对象
            material: 材料参数 {'E': 210000, 'sigma_s': 235, 'tau_s': 140}
        """
        self.section = section
        self.material = material
        self.props = section.calculate_properties()
        
    def check_tension(self, force: float, safety_factor: float = 1.5) -> Dict:
        """
        拉伸/压缩强度校核
        
        Args:
            force: 轴向力 (N)，拉力为正，压力为负
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        A = self.props['area_mm2']
        sigma_s = self.material['sigma_s']
        
        # 正应力
        sigma = abs(force) / A
        
        # 许用应力
        sigma_allow = sigma_s / safety_factor
        
        # 安全系数
        SF = sigma_allow / sigma
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'force_N': force,
            'stress_MPa': round(sigma, 2),
            'allowable_stress_MPa': round(sigma_allow, 2),
            'safety_factor': round(SF, 2),
            'status': status,
            'area_mm2': A
        }
    
    def check_shear(self, force: float, safety_factor: float = 1.5) -> Dict:
        """
        剪切强度校核
        
        Args:
            force: 剪切力 (N)
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        A = self.props['area_mm2']
        tau_s = self.material.get('tau_s', 0.6 * self.material['sigma_s'])
        
        # 剪应力 (假设沿面积A剪切)
        tau = force / A
        
        # 许用剪应力
        tau_allow = tau_s / safety_factor
        
        # 安全系数
        SF = tau_allow / tau
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'shear_force_N': force,
            'shear_stress_MPa': round(tau, 2),
            'allowable_shear_stress_MPa': round(tau_allow, 2),
            'safety_factor': round(SF, 2),
            'status': status
        }
    
    def check_bending(self, moment: float, axis: str = 'x',
                      safety_factor: float = 1.5) -> Dict:
        """
        弯曲强度校核
        
        Args:
            moment: 弯矩 (N·mm)
            axis: 弯曲平面 ('x' 或 'y')
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        sigma_s = self.material['sigma_s']
        
        if axis == 'x':
            W = self.props.get('section_modulus_x_mm3', 0)
        else:
            W = self.props.get('section_modulus_y_mm3', 0)
        
        if W == 0:
            return {'error': '该截面无抗弯截面系数数据'}
        
        # 弯曲应力
        sigma = moment / W
        
        # 许用应力
        sigma_allow = sigma_s / safety_factor
        
        # 安全系数
        SF = sigma_allow / sigma
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'bending_moment_Nmm': moment,
            'axis': axis,
            'bending_stress_MPa': round(sigma, 2),
            'allowable_stress_MPa': round(sigma_allow, 2),
            'safety_factor': round(SF, 2),
            'status': status,
            'section_modulus_mm3': W
        }
    
    def check_torsion(self, torque: float, safety_factor: float = 1.5) -> Dict:
        """
        扭转强度校核
        
        Args:
            torque: 扭矩 (N·mm)
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        tau_s = self.material.get('tau_s', 0.6 * self.material['sigma_s'])
        
        Wt = self.props.get('torsion_modulus_mm3', 
                           self.props.get('section_modulus_x_mm3', 0))
        
        if Wt == 0:
            return {'error': '该截面无抗扭截面系数数据'}
        
        # 扭转剪应力
        tau = torque / Wt
        
        # 许用剪应力
        tau_allow = tau_s / safety_factor
        
        # 安全系数
        SF = tau_allow / tau
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'torque_Nmm': torque,
            'torsional_stress_MPa': round(tau, 2),
            'allowable_shear_stress_MPa': round(tau_allow, 2),
            'safety_factor': round(SF, 2),
            'status': status,
            'torsion_modulus_mm3': Wt
        }
    
    def check_von_mises(self, N: float, M: float, T: float,
                        safety_factor: float = 1.5) -> Dict:
        """
        von Mises组合应力校核 (第四强度理论)
        
        Args:
            N: 轴向力 (N)
            M: 弯矩 (N·mm)
            T: 扭矩 (N·mm)
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        sigma_s = self.material['sigma_s']
        
        # 正应力 (拉伸/压缩 + 弯曲)
        A = self.props['area_mm2']
        W = self.props.get('section_modulus_x_mm3', 1)
        sigma = abs(N) / A + abs(M) / W
        
        # 剪应力 (扭转)
        Wt = self.props.get('torsion_modulus_mm3', W)
        tau = abs(T) / Wt
        
        # von Mises相当应力
        sigma_eq = math.sqrt(sigma**2 + 3 * tau**2)
        
        # 许用应力
        sigma_allow = sigma_s / safety_factor
        
        # 安全系数
        SF = sigma_allow / sigma_eq
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'axial_force_N': N,
            'bending_moment_Nmm': M,
            'torque_Nmm': T,
            'normal_stress_MPa': round(sigma, 2),
            'shear_stress_MPa': round(tau, 2),
            'equivalent_stress_MPa': round(sigma_eq, 2),
            'allowable_stress_MPa': round(sigma_allow, 2),
            'safety_factor': round(SF, 2),
            'status': status
        }


if __name__ == "__main__":
    # 示例1：矩形截面几何特性
    print("=== 示例1：矩形截面 50×100mm ===")
    rect = CrossSection('rectangular', {'b': 50, 'h': 100})
    props = rect.calculate_properties()
    for key, value in props.items():
        print(f"{key}: {value}")
    
    # 示例2：圆形截面几何特性
    print("\n=== 示例2：圆形截面 d=60mm ===")
    circ = CrossSection('circular', {'d': 60})
    props = circ.calculate_properties()
    for key, value in props.items():
        print(f"{key}: {value}")
    
    # 示例3：H型钢几何特性
    print("\n=== 示例3：H型钢 200×200×8×12 ===")
    h_beam = CrossSection('h_beam', {'h': 200, 'b': 200, 'tw': 8, 'tf': 12})
    props = h_beam.calculate_properties()
    for key, value in props.items():
        print(f"{key}: {value}")
    
    # 示例4：弯曲强度校核
    print("\n=== 示例4：H型钢弯曲强度校核 ===")
    material = {'E': 210000, 'sigma_s': 235, 'tau_s': 140}
    checker = StrengthCheck(h_beam, material)
    result = checker.check_bending(moment=50000*1000, axis='x', safety_factor=1.5)
    for key, value in result.items():
        print(f"{key}: {value}")
