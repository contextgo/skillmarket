#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
轴强度计算引擎 (Shaft Calculator)
支持轴结构参数、强度校核、疲劳强度计算
符合GB/T 1220、机械设计手册
"""

import math
from typing import Dict, List


class ShaftCalculator:
    """轴强度计算类"""
    
    # 轴材料性能 (简化)
    MATERIAL_PROPERTIES = {
        '45': {'sigma_s': 355, 'sigma_b': 600, 'tau_s': 200, 'E': 210000},
        '40Cr': {'sigma_s': 785, 'sigma_b': 980, 'tau_s': 420, 'E': 210000},
        '42CrMo': {'sigma_s': 930, 'sigma_b': 1080, 'tau_s': 500, 'E': 210000},
        '20CrMnTi': {'sigma_s': 835, 'sigma_b': 1080, 'tau_s': 450, 'E': 210000},
    }
    
    def __init__(self, diameter: float, material: str = "45"):
        """
        初始化轴参数
        
        Args:
            diameter: 轴径 (mm)
            material: 材料
        """
        self.d = diameter
        self.material = material
        self.props = self.MATERIAL_PROPERTIES.get(
            material, self.MATERIAL_PROPERTIES['45']
        )
        
    def check_torsion_strength(self, torque: float, 
                               safety_factor: float = 1.5) -> Dict:
        """
        扭转强度校核 (按第三强度理论)
        
        Args:
            torque: 扭矩 (N·m)
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        T = torque * 1000  # N·mm
        d = self.d
        
        # 扭转剪应力
        tau_T = T / (math.pi * d**3 / 16)
        
        # 许用剪应力
        tau_allow = self.props['tau_s'] / safety_factor
        
        # 安全系数
        SF = tau_allow / tau_T
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'shaft_diameter_mm': d,
            'material': self.material,
            'torque_Nm': torque,
            'torsional_shear_stress_MPa': round(tau_T, 2),
            'allowable_shear_stress_MPa': round(tau_allow, 2),
            'safety_factor': round(SF, 2),
            'required_safety_factor': safety_factor,
            'status': status,
            'theory': '第三强度理论'
        }
    
    def check_bending_strength(self, bending_moment: float,
                                safety_factor: float = 1.5) -> Dict:
        """
        弯曲强度校核
        
        Args:
            bending_moment: 弯矩 (N·m)
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        M = bending_moment * 1000  # N·mm
        d = self.d
        
        # 弯曲应力
        sigma_b = M / (math.pi * d**3 / 32)
        
        # 许用弯曲应力
        sigma_allow = self.props['sigma_s'] / safety_factor
        
        # 安全系数
        SF = sigma_allow / sigma_b
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'shaft_diameter_mm': d,
            'material': self.material,
            'bending_moment_Nm': bending_moment,
            'bending_stress_MPa': round(sigma_b, 2),
            'allowable_stress_MPa': round(sigma_allow, 2),
            'safety_factor': round(SF, 2),
            'required_safety_factor': safety_factor,
            'status': status
        }
    
    def check_combined_strength(self, torque: float, 
                                  bending_moment: float,
                                  axial_force: float = 0,
                                  safety_factor: float = 1.5) -> Dict:
        """
        组合强度校核 (按第四强度理论)
        
        Args:
            torque: 扭矩 (N·m)
            bending_moment: 弯矩 (N·m)
            axial_force: 轴向力 (N)
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        T = torque * 1000
        M = bending_moment * 1000
        d = self.d
        
        # 正应力 (弯曲 + 拉伸/压缩)
        sigma = M / (math.pi * d**3 / 32) + axial_force / (math.pi * d**2 / 4)
        
        # 剪应力 (扭转)
        tau = T / (math.pi * d**3 / 16)
        
        # von Mises相当应力 (第四强度理论)
        sigma_eq = math.sqrt(sigma**2 + 3 * tau**2)
        
        # 许用应力
        sigma_allow = self.props['sigma_s'] / safety_factor
        
        # 安全系数
        SF = sigma_allow / sigma_eq
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'shaft_diameter_mm': d,
            'material': self.material,
            'torque_Nm': torque,
            'bending_moment_Nm': bending_moment,
            'axial_force_N': axial_force,
            'normal_stress_MPa': round(sigma, 2),
            'shear_stress_MPa': round(tau, 2),
            'equivalent_stress_MPa': round(sigma_eq, 2),
            'allowable_stress_MPa': round(sigma_allow, 2),
            'safety_factor': round(SF, 2),
            'required_safety_factor': safety_factor,
            'status': status,
            'theory': '第四强度理论(von Mises)'
        }
    
    def calculate_critical_speed(self, length: float, 
                                 support_type: str = 'simply') -> Dict:
        """
        计算临界转速 (简化)
        
        Args:
            length: 轴长度 (mm)
            support_type: 支承类型 ('simply'=简支, 'cantilever'=悬臂)
            
        Returns:
            临界转速
        """
        d = self.d
        E = self.props['E'] * 1000  # MPa -> N/mm²
        rho = 7850 * 1e-12  # kg/mm³
        
        # 轴转动惯量
        I = math.pi * d**4 / 64  # mm⁴
        
        # 轴质量 (简化)
        m = rho * math.pi * d**2 / 4 * length  # kg
        
        if support_type == 'simply':
            # 简支梁一阶临界转速
            fn = (math.pi / 2)**2 * math.sqrt(E * I / (m * length**3)) / (2 * math.pi)
        else:
            # 悬臂梁一阶临界转速
            fn = 1.875**2 / (2 * math.pi) * math.sqrt(E * I / (m * length**3))
            
        return {
            'shaft_diameter_mm': d,
            'length_mm': length,
            'support_type': support_type,
            'critical_speed_rpm': round(fn * 60, 1),
            'note': '临界转速计算(简化)，实际需考虑多质量分布'
        }
    
    @classmethod
    def recommend_diameter(cls, torque: float, 
                             material: str = "45",
                             safety_factor: float = 1.5) -> Dict:
        """
        根据扭矩推荐轴径
        
        Args:
            torque: 扭矩 (N·m)
            material: 材料
            safety_factor: 安全系数
            
        Returns:
            推荐轴径
        """
        props = cls.MATERIAL_PROPERTIES.get(material, cls.MATERIAL_PROPERTIES['45'])
        T = torque * 1000  # N·mm
        tau_allow = props['tau_s'] / safety_factor
        
        # 根据扭转强度估算轴径
        d = ((16 * T) / (math.pi * tau_allow))**(1/3)
        
        # 圆整到标准值
        standard_d = [10, 12, 15, 18, 20, 22, 25, 28, 30, 32, 35, 38, 40, 45, 50, 55, 60]
        for sd in standard_d:
            if sd >= d:
                recommended = sd
                break
        else:
            recommended = math.ceil(d / 5) * 5
            
        return {
            'torque_Nm': torque,
            'material': material,
            'calculated_diameter_mm': round(d, 2),
            'recommended_diameter_mm': recommended,
            'allowable_shear_stress_MPa': round(tau_allow, 2),
            'safety_factor': safety_factor
        }


if __name__ == "__main__":
    # 示例1：扭转强度校核
    print("=== 扭转强度校核 ===")
    shaft1 = ShaftCalculator(diameter=30, material="45")
    result1 = shaft1.check_torsion_strength(torque=500, safety_factor=1.5)
    for key, value in result1.items():
        print(f"  {key}: {value}")
    
    print("\n=== 组合强度校核 ===")
    result2 = shaft1.check_combined_strength(
        torque=500, 
        bending_moment=800, 
        axial_force=10000,
        safety_factor=1.5
    )
    for key, value in result2.items():
        print(f"  {key}: {value}")
    
    print("\n=== 临界转速计算 ===")
    result3 = shaft1.calculate_critical_speed(length=500, support_type='simply')
    for key, value in result3.items():
        print(f"  {key}: {value}")
    
    print("\n=== 推荐轴径 ===")
    result4 = ShaftCalculator.recommend_diameter(torque=800, material="40Cr")
    for key, value in result4.items():
        print(f"  {key}: {value}")
