#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
圆柱齿轮计算引擎 (Cylindrical Gear Calculator)
支持几何计算、强度校核、公差查询
符合GB/T 3374、GB/T 10095标准
"""

import math
from typing import Dict, List, Tuple


class CylindicalGear:
    """圆柱齿轮计算类"""
    
    # 法向模数系列
    MODULE_SERIES = [0.1, 0.12, 0.15, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.8,
                     1, 1.25, 1.5, 2, 2.5, 3, 4, 5, 6, 8, 10, 12, 16, 20, 25, 32, 40, 50]
    
    def __init__(self, module: float, teeth: int, pressure_angle: float = 20,
                 helix_angle: float = 0, tooth_width: float = None):
        """
        初始化圆柱齿轮参数
        
        Args:
            module: 法向模数 (mm)
            teeth: 齿数
            pressure_angle: 法向压力角 (度)
            helix_angle: 螺旋角 (度，右旋为正)
            tooth_width: 齿宽 (mm)
        """
        self.module = module
        self.teeth = teeth
        self.pressure_angle = pressure_angle
        self.helix_angle = helix_angle
        self.tooth_width = tooth_width or 10 * module  # 默认齿宽
        
        # 计算派生参数
        self.transverse_module = module / math.cos(math.radians(helix_angle)) if helix_angle != 0 else module
        self.pitch_diameter = self.transverse_module * teeth
        
    def calculate_geometry(self) -> Dict:
        """
        计算齿轮几何参数
        
        Returns:
            几何参数字典
        """
        m_n = self.module
        m_t = self.transverse_module
        z = self.teeth
        beta = math.radians(self.helix_angle)
        
        # 分度圆直径
        d = m_t * z
        
        # 齿顶高
        ha = m_n
        
        # 齿根高
        hf = 1.25 * m_n
        
        # 齿顶圆直径
        da = d + 2 * ha
        
        # 齿根圆直径
        df = d - 2 * hf
        
        # 基圆直径
        db = d * math.cos(math.radians(self.pressure_angle))
        
        # 中心距 (单级传动，假设配对齿轮齿数=1.5*z)
        z2 = round(z * 1.5)
        a = (z + z2) * m_t / 2
        
        # 齿宽系数
        psi_d = self.tooth_width / d
        
        return {
            'normal_module_mm': m_n,
            'transverse_module_mm': round(m_t, 3),
            'teeth_number': z,
            'helix_angle_deg': self.helix_angle,
            'pitch_diameter_mm': round(d, 3),
            'base_diameter_mm': round(db, 3),
            'addendum_circle_diameter_mm': round(da, 3),
            'dedendum_circle_diameter_mm': round(df, 3),
            'addendum_mm': round(ha, 3),
            'dedendum_mm': round(hf, 3),
            'tooth_width_mm': round(self.tooth_width, 1),
            'width_factor_psi_d': round(psi_d, 3),
            'center_distance_mm': round(a, 2),
            'mating_gear_teeth': z2
        }
    
    def check_contact_strength(self, torque: float, gear_teeth: int = None,
                                material: str = "40Cr", safety_factor: float = 1.0) -> Dict:
        """
        齿面接触强度校核 (GB/T 10095)
        
        Args:
            torque: 小齿轮扭矩 (N·m)
            gear_teeth: 大齿轮齿数 (默认1.5倍小齿轮)
            material: 材料
            safety_factor: 最小安全系数
            
        Returns:
            强度校核结果
        """
        T1 = torque * 1000  # N·mm
        z1 = self.teeth
        z2 = gear_teeth or round(z1 * 1.5)
        u = z2 / z1
        beta = math.radians(self.helix_angle)
        
        # 节点区域系数
        ZH = 2.5  # 直齿轮
        
        # 弹性系数 (钢-钢)
        ZE = 189.8  # MPa^0.5
        
        # 重合度系数
        Z_epsilon = 0.9
        
        # 螺旋角系数
        Z_beta = math.sqrt(math.cos(beta))
        
        # 使用系数
        KA = 1.0
        
        # 动载系数
        KV = 1.1
        
        # 齿向载荷分布系数
        KH_beta = 1.1
        
        # 齿间载荷分配系数
        KH_alpha = 1.2
        
        K = KA * KV * KH_beta * KH_alpha
        
        # 分度圆直径
        d1 = self.pitch_diameter
        
        # 齿宽
        b = self.tooth_width
        
        # 接触应力
        sigma_H = ZE * ZH * Z_epsilon * Z_beta * \
                  math.sqrt((2 * T1 * K) / (b * d1**2) * (u + 1) / u)
        
        # 许用接触应力
        sigma_H_lim = self._get_contact_fatigue_limit(material)
        
        # 安全系数
        SH = sigma_H_lim / sigma_H
        
        status = 'PASS' if SH >= safety_factor else 'FAIL'
        
        return {
            'input_torque_Nm': torque,
            'pinion_teeth': z1,
            'gear_teeth': z2,
            'transmission_ratio': round(u, 2),
            'contact_stress_MPa': round(sigma_H, 2),
            'allowable_contact_stress_MPa': round(sigma_H_lim, 2),
            'safety_factor_Sh': round(SH, 2),
            'required_safety_factor': safety_factor,
            'status': status,
            'note': '接触强度校核(GB/T 10095)'
        }
    
    def check_bending_strength(self, torque: float, gear_teeth: int = None,
                                material: str = "40Cr", safety_factor: float = 1.4) -> Dict:
        """
        齿根弯曲强度校核 (GB/T 10095)
        
        Args:
            torque: 小齿轮扭矩 (N·m)
            gear_teeth: 大齿轮齿数
            material: 材料
            safety_factor: 最小安全系数
            
        Returns:
            强度校核结果
        """
        T1 = torque * 1000
        z1 = self.teeth
        z2 = gear_teeth or round(z1 * 1.5)
        
        # 齿形系数 (简化)
        YFa1 = 2.8 if z1 >= 20 else 3.2
        YFa2 = 2.5 if z2 >= 30 else 2.8
        
        # 应力修正系数
        YSa1 = 1.55
        YSa2 = 1.55
        
        # 重合度系数
        Y_epsilon = 0.7
        
        # 螺旋角系数
        Y_beta = 1.0 if self.helix_angle == 0 else 0.85
        
        # 使用系数
        KA = 1.0
        
        # 动载系数
        KV = 1.1
        
        # 齿向载荷分布系数
        KF_beta = 1.1
        
        # 齿间载荷分配系数
        KF_alpha = 1.2
        
        K = KA * KV * KF_beta * KF_alpha
        
        # 分度圆直径
        d1 = self.pitch_diameter
        
        # 齿宽
        b = self.tooth_width
        
        # 弯曲应力
        sigma_F1 = (2 * T1 * K * YFa1 * YSa1 * Y_epsilon * Y_beta) / (b * d1 * self.module)
        sigma_F2 = sigma_F1 * (YFa2 * YSa2) / (YFa1 * YSa1)
        
        # 许用弯曲应力
        sigma_F_lim = self._get_bending_fatigue_limit(material)
        
        # 安全系数
        SF1 = sigma_F_lim / sigma_F1
        SF2 = sigma_F_lim / sigma_F2
        
        status = 'PASS' if min(SF1, SF2) >= safety_factor else 'FAIL'
        
        return {
            'input_torque_Nm': torque,
            'pinion_teeth': z1,
            'gear_teeth': z2,
            'pinion_bending_stress_MPa': round(sigma_F1, 2),
            'gear_bending_stress_MPa': round(sigma_F2, 2),
            'allowable_bending_stress_MPa': round(sigma_F_lim, 2),
            'pinion_safety_factor_SF': round(SF1, 2),
            'gear_safety_factor_SF': round(SF2, 2),
            'required_safety_factor': safety_factor,
            'status': status,
            'note': '弯曲强度校核(GB/T 10095)'
        }
    
    def _get_contact_fatigue_limit(self, material: str) -> float:
        """获取接触疲劳极限"""
        limits = {
            "40Cr": 700,      # 调质
            "45": 550,         # 调质
            "20CrMnTi": 1100, # 渗碳淬火
            "42CrMo": 750,    # 调质
            "38CrMoAlA": 850, # 渗氮
        }
        return limits.get(material, 600)
    
    def _get_bending_fatigue_limit(self, material: str) -> float:
        """获取弯曲疲劳极限"""
        limits = {
            "40Cr": 300,      # 调质
            "45": 220,         # 调质
            "20CrMnTi": 400,  # 渗碳淬火
            "42CrMo": 320,    # 调质
            "38CrMoAlA": 380, # 渗氮
        }
        return limits.get(material, 250)


class GearTolerance:
    """齿轮公差查询类"""
    
    # 精度等级
    TOLERANCE_CLASSES = ['5', '6', '7', '8', '9', '10']
    
    # 模数分段
    MODULE_RANGES = [(0.5, 2), (2, 3.5), (3.5, 6), (6, 10), (10, 16), (16, 25), (25, 40), (40, 70)]
    
    @classmethod
    def query_tolerance(cls, tolerance_class: str, module: float, 
                        gear_type: str = 'cylindrical') -> Dict:
        """
        查询齿轮公差 (GB/T 10095)
        
        Args:
            tolerance_class: 公差等级 ('5'~'10')
            module: 模数 (mm)
            gear_type: 齿轮类型 ('cylindrical' 或 'bevel')
            
        Returns:
            公差值字典
        """
        # 公差等级系数
        tolerance_factors = {
            '5': 0.63,
            '6': 1.0,
            '7': 1.25,
            '8': 1.6,
            '9': 2.0,
            '10': 2.5
        }
        
        factor = tolerance_factors.get(tolerance_class, 1.25)
        
        # 基本公差值 (μm) - 简化公式
        Fp = factor * 0.3 * module**0.5 * 25  # 齿距累积公差
        fpt = factor * 0.1 * module**0.5 * 8   # 单个齿距偏差
        Falpha = factor * 0.2 * module**0.5 * 10 # 齿廓总偏差
        Fbeta = factor * 0.1 * module**0.5 * 8   # 螺旋线总偏差
        
        return {
            'tolerance_class': tolerance_class,
            'module_mm': module,
            'Fp_um': round(Fp, 1),      # 齿距累积总偏差
            'fpt_um': round(fpt, 1),     # 单个齿距偏差
            'F_alpha_um': round(Falpha, 1), # 齿廓总偏差
            'F_beta_um': round(Fbeta, 1),   # 螺旋线总偏差
            'standard': 'GB/T 10095'
        }


if __name__ == "__main__":
    # 示例1：圆柱齿轮几何计算
    print("=== 圆柱齿轮几何计算 ===")
    gear = CylindicalGear(module=3, teeth=30, pressure_angle=20, helix_angle=0)
    geometry = gear.calculate_geometry()
    for key, value in geometry.items():
        print(f"{key}: {value}")
    
    print("\n=== 接触强度校核 ===")
    contact = gear.check_contact_strength(
        torque=500, gear_teeth=45, material="40Cr"
    )
    for key, value in contact.items():
        print(f"{key}: {value}")
    
    print("\n=== 弯曲强度校核 ===")
    bending = gear.check_bending_strength(
        torque=500, gear_teeth=45, material="40Cr"
    )
    for key, value in bending.items():
        print(f"{key}: {value}")
    
    print("\n=== 公差查询 (7级精度) ===")
    tolerance = GearTolerance.query_tolerance(
        tolerance_class='7', module=3
    )
    for key, value in tolerance.items():
        print(f"{key}: {value}")
