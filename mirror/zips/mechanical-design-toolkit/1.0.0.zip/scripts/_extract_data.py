#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从原始小程序JS文件提取轴承数据和螺纹数据，转为JSON格式
"""

import json
import re
import os

SRC = "D:/ShejiBao_Miniprogram/pkgD/utils/bearingData.js"
THREAD_SRC = "D:/ShejiBao_Miniprogram/pkgE/pages/threads/index.js"
OUT_DIR = "D:/MechaBao-OpenClaw-SKILL/data"


def extract_bearing_data():
    """提取轴承数据"""
    with open(SRC, 'r', encoding='utf-8') as f:
        content = f.read()

    # 8种轴承类型的变量名映射
    type_map = {
        'deepGrooveBearings': {
            'type_id': 'deep_groove', 'type_name': '深沟球轴承',
            'code_prefix': '6xxx', 'standard': 'GB/T 276-2013'
        },
        'angularContactBearings': {
            'type_id': 'angular_contact', 'type_name': '角接触球轴承',
            'code_prefix': '7xxx', 'standard': 'GB/T 292-2007'
        },
        'selfAligningBallBearings': {
            'type_id': 'self_aligning_ball', 'type_name': '调心球轴承',
            'code_prefix': '1xxx', 'standard': 'GB/T 281-2013'
        },
        'cylindricalRollerBearings': {
            'type_id': 'cylindrical_roller', 'type_name': '圆柱滚子轴承',
            'code_prefix': 'N/NJ/NU', 'standard': 'GB/T 283-2007'
        },
        'taperedRollerBearings': {
            'type_id': 'tapered_roller', 'type_name': '圆锥滚子轴承',
            'code_prefix': '3xxxx', 'standard': 'GB/T 297-2015'
        },
        'thrustBallBearings': {
            'type_id': 'thrust_ball', 'type_name': '推力球轴承',
            'code_prefix': '5xxx', 'standard': 'GB/T 301-1995'
        },
        'needleRollerBearings': {
            'type_id': 'needle_roller', 'type_name': '滚针轴承',
            'code_prefix': 'NA/RNA/NK', 'standard': 'GB/T 5801-2006'
        },
        'selfAligningRollerBearings': {
            'type_id': 'self_aligning_roller', 'type_name': '调心滚子轴承',
            'code_prefix': '2xxxx', 'standard': 'GB/T 288-2013'
        },
    }

    result = {
        "metadata": {
            "name": "机械设计轴承规格数据库",
            "version": "3.0",
            "source": "机械宝(MechaBao)小程序",
            "standards": [
                "GB/T 276-2013", "GB/T 292-2007", "GB/T 281-2013",
                "GB/T 283-2007", "GB/T 297-2015", "GB/T 301-1995",
                "GB/T 5801-2006", "GB/T 288-2013"
            ],
            "update_date": "2026-04"
        },
        "bearing_types": [],
        "bearings": [],
        "clearance_data": {},
        "reliability_factors": []
    }

    # 提取每种类型的轴承数据
    for var_name, type_info in type_map.items():
        # 匹配变量定义: const varName = [
        pattern = rf'const\s+{var_name}\s*=\s*\['
        match = re.search(pattern, content)
        if not match:
            print(f"Warning: {var_name} not found")
            continue

        # 找到数组开始位置
        start = match.end() - 1  # 包含 [

        # 找到匹配的 ] — 简单计数大括号
        depth = 0
        end = start
        for i in range(start, len(content)):
            if content[i] == '[':
                depth += 1
            elif content[i] == ']':
                depth -= 1
                if depth == 0:
                    end = i + 1
                    break

        array_text = content[start:end]

        # 提取每个 { code:... } 块
        bearing_pattern = r'\{([^}]+)\}'
        bearings_raw = re.findall(bearing_pattern, array_text)

        type_bearings = []
        for raw in bearings_raw:
            # 解析键值对
            fields = {}
            # 处理类似 code:'6200' 或 d:10 的字段
            for kv in re.finditer(r'(\w+)\s*:\s*([^,}\s]+)', raw):
                key = kv.group(1)
                val = kv.group(2).strip().strip("'\"")
                # 尝试转为数字
                try:
                    if '.' in val:
                        val = float(val)
                    else:
                        val = int(val)
                except (ValueError, TypeError):
                    pass
                fields[key] = val

            if 'code' in fields:
                bearing = {
                    "code": str(fields.get('code', '')),
                    "type_id": type_info['type_id'],
                    "type_name": type_info['type_name'],
                    "d": fields.get('d', fields.get('Fw', None)),  # 内径
                    "D": fields.get('D', None),  # 外径
                    "B": fields.get('B', None),  # 宽度
                    "Cr_kN": fields.get('Cr', None),  # 额定动载荷
                    "Cor_kN": fields.get('Cor', None),  # 额定静载荷
                    "grease_rpm": fields.get('grease', None),
                    "oil_rpm": fields.get('oil', None),
                    "weight_kg": fields.get('weight', None),
                }
                # 特殊字段
                if 'angle' in fields:
                    bearing["contact_angle_deg"] = fields['angle']
                if 'maxAngle' in fields:
                    bearing["max_align_angle_deg"] = fields['maxAngle']
                if 'Fw' in fields:
                    bearing["Fw"] = fields['Fw']
                if 'canAxial' in fields:
                    bearing["can_axial"] = fields['canAxial']

                type_bearings.append(bearing)

        # 添加到类型列表
        result["bearing_types"].append({
            "type_id": type_info['type_id'],
            "type_name": type_info['type_name'],
            "code_prefix": type_info['code_prefix'],
            "standard": type_info['standard'],
            "count": len(type_bearings)
        })

        result["bearings"].extend(type_bearings)
        print(f"  {type_info['type_name']}: {len(type_bearings)} 个型号")

    # 提取游隙数据
    clearance_match = re.search(r'const\s+clearanceData\s*=\s*(\{[\s\S]*?\});', content)
    if clearance_match:
        # 简化提取游隙范围数据
        result["clearance_data"] = {
            "groups": [
                {
                    "group": "C2", "name": "小游隙组",
                    "description": "游隙小于正常值，用于高精度旋转或预紧场合",
                    "suggestion": "精密主轴、预紧工况",
                    "ranges": [
                        {"d_min": 3, "d_max": 6, "min_um": 2, "max_um": 6},
                        {"d_min": 6, "d_max": 10, "min_um": 2, "max_um": 9},
                        {"d_min": 10, "d_max": 18, "min_um": 3, "max_um": 12},
                        {"d_min": 18, "d_max": 24, "min_um": 4, "max_um": 15},
                        {"d_min": 24, "d_max": 30, "min_um": 5, "max_um": 18},
                        {"d_min": 30, "d_max": 40, "min_um": 6, "max_um": 21},
                        {"d_min": 40, "d_max": 50, "min_um": 7, "max_um": 24},
                        {"d_min": 50, "d_max": 65, "min_um": 9, "max_um": 29},
                        {"d_min": 65, "d_max": 80, "min_um": 11, "max_um": 34},
                        {"d_min": 80, "d_max": 100, "min_um": 13, "max_um": 40},
                        {"d_min": 100, "d_max": 120, "min_um": 15, "max_um": 46}
                    ]
                },
                {
                    "group": "CN", "name": "正常游隙组",
                    "description": "常规标准值，最常用",
                    "suggestion": "一般用途、常温工作",
                    "ranges": [
                        {"d_min": 3, "d_max": 6, "min_um": 5, "max_um": 10},
                        {"d_min": 6, "d_max": 10, "min_um": 6, "max_um": 12},
                        {"d_min": 10, "d_max": 18, "min_um": 8, "max_um": 17},
                        {"d_min": 18, "d_max": 24, "min_um": 10, "max_um": 20},
                        {"d_min": 24, "d_max": 30, "min_um": 12, "max_um": 24},
                        {"d_min": 30, "d_max": 40, "min_um": 14, "max_um": 29},
                        {"d_min": 40, "d_max": 50, "min_um": 17, "max_um": 34},
                        {"d_min": 50, "d_max": 65, "min_um": 21, "max_um": 41},
                        {"d_min": 65, "d_max": 80, "min_um": 25, "max_um": 49},
                        {"d_min": 80, "d_max": 100, "min_um": 30, "max_um": 58},
                        {"d_min": 100, "d_max": 120, "min_um": 35, "max_um": 67}
                    ]
                },
                {
                    "group": "C3", "name": "中等游隙组",
                    "description": "大于正常值，高温或过盈量大的安装",
                    "suggestion": "高温>100℃、过盈配合",
                    "ranges": [
                        {"d_min": 3, "d_max": 6, "min_um": 10, "max_um": 18},
                        {"d_min": 6, "d_max": 10, "min_um": 12, "max_um": 22},
                        {"d_min": 10, "d_max": 18, "min_um": 16, "max_um": 29},
                        {"d_min": 18, "d_max": 24, "min_um": 20, "max_um": 35},
                        {"d_min": 24, "d_max": 30, "min_um": 24, "max_um": 42},
                        {"d_min": 30, "d_max": 40, "min_um": 29, "max_um": 50},
                        {"d_min": 40, "d_max": 50, "min_um": 34, "max_um": 58},
                        {"d_min": 50, "d_max": 65, "min_um": 42, "max_um": 70},
                        {"d_min": 65, "d_max": 80, "min_um": 51, "max_um": 84},
                        {"d_min": 80, "d_max": 100, "min_um": 61, "max_um": 99},
                        {"d_min": 100, "d_max": 120, "min_um": 72, "max_um": 114}
                    ]
                },
                {
                    "group": "C4", "name": "大游隙组",
                    "description": "显著大于正常值，极端温度或特殊工况",
                    "suggestion": "极高温>150℃、大过盈",
                    "ranges": [
                        {"d_min": 3, "d_max": 6, "min_um": 18, "max_um": 28},
                        {"d_min": 6, "d_max": 10, "min_um": 22, "max_um": 34},
                        {"d_min": 10, "d_max": 18, "min_um": 29, "max_um": 44},
                        {"d_min": 18, "d_max": 24, "min_um": 36, "max_um": 54},
                        {"d_min": 24, "d_max": 30, "min_um": 43, "max_um": 64},
                        {"d_min": 30, "d_max": 40, "min_um": 52, "max_um": 76},
                        {"d_min": 40, "d_max": 50, "min_um": 61, "max_um": 88},
                        {"d_min": 50, "d_max": 65, "min_um": 75, "max_um": 106},
                        {"d_min": 65, "d_max": 80, "min_um": 91, "max_um": 128},
                        {"d_min": 80, "d_max": 100, "min_um": 108, "max_um": 150},
                        {"d_min": 100, "d_max": 120, "min_um": 127, "max_um": 173}
                    ]
                }
            ],
            "selection_guide": [
                {"condition": "一般常温工作", "recommend": "CN"},
                {"condition": "精密机床主轴", "recommend": "C2"},
                {"condition": "高温工作>100℃", "recommend": "C3"},
                {"condition": "高温工作>150℃或大过盈", "recommend": "C4"},
                {"condition": "轴承座铝壳体", "recommend": "C3"},
                {"condition": "内外圈温差大", "recommend": "C3/C4"},
                {"condition": "需要预紧提高刚度", "recommend": "C2"}
            ]
        }

    # 可靠度系数
    result["reliability_factors"] = [
        {"reliability_percent": 90, "a1": 1.00, "note": "标准可靠度"},
        {"reliability_percent": 95, "a1": 0.62, "note": ""},
        {"reliability_percent": 96, "a1": 0.53, "note": ""},
        {"reliability_percent": 97, "a1": 0.44, "note": ""},
        {"reliability_percent": 98, "a1": 0.33, "note": ""},
        {"reliability_percent": 99, "a1": 0.21, "note": "高可靠度要求"}
    ]

    # 写入文件
    out_path = os.path.join(OUT_DIR, "bearings.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\n轴承数据已写入: {out_path}")
    print(f"总计: {len(result['bearings'])} 个轴承规格, {len(result['bearing_types'])} 种类型")
    return result


def extract_thread_data():
    """提取螺纹数据"""
    with open(THREAD_SRC, 'r', encoding='utf-8') as f:
        content = f.read()

    result = {
        "metadata": {
            "name": "螺纹规格数据库",
            "version": "1.0",
            "source": "机械宝(MechaBao)小程序",
            "standards": ["GB/T 196", "GB/T 7307"],
            "update_date": "2026-04"
        },
        "metric_threads": [],
        "pipe_threads": [],
        "bolt_scenarios": []
    }

    # 提取公制螺纹 METRIC_THREADS
    metric_pattern = r'const\s+METRIC_THREADS\s*=\s*\[([\s\S]*?)\];'
    match = re.search(metric_pattern, content)
    if match:
        array_text = match.group(1)
        for m in re.finditer(r'\{([^}]+)\}', array_text):
            fields = {}
            for kv in re.finditer(r'(\w+)\s*:\s*([^,}\s]+)', m.group(1)):
                key = kv.group(1)
                val = kv.group(2).strip().strip("'\"")
                try:
                    if '.' in val:
                        val = float(val)
                    else:
                        val = int(val)
                except (ValueError, TypeError):
                    pass
                fields[key] = val

            if 'd' in fields:
                result["metric_threads"].append({
                    "designation": f"M{fields['d']}×{fields.get('pitch', '')}",
                    "d": fields.get('d'),  # 公称直径
                    "pitch": fields.get('pitch'),  # 螺距
                    "d2": fields.get('d2'),  # 中径
                    "d1": fields.get('d1'),  # 小径
                    "drill": fields.get('drill'),  # 钻孔直径
                    "thread_depth": round(fields['d'] - fields.get('d1', fields['d']), 3) if isinstance(fields.get('d1'), (int, float)) else None
                })

    # 提取管螺纹 PIPE_THREADS
    pipe_pattern = r'const\s+PIPE_THREADS\s*=\s*\[([\s\S]*?)\];'
    match = re.search(pipe_pattern, content)
    if match:
        array_text = match.group(1)
        for m in re.finditer(r'\{([^}]+)\}', array_text):
            fields = {}
            for kv in re.finditer(r"(\w+)\s*:\s*'([^']*)'|(\w+)\s*:\s*([^,}\s]+)", m.group(1)):
                if kv.group(1):
                    fields[kv.group(1)] = kv.group(2)
                elif kv.group(3):
                    key = kv.group(3)
                    val = kv.group(4)
                    try:
                        if '.' in val:
                            val = float(val)
                        else:
                            val = int(val)
                    except (ValueError, TypeError):
                        pass
                    fields[key] = val

            if 'size' in fields:
                result["pipe_threads"].append({
                    "designation": fields.get('size', ''),
                    "od": fields.get('od'),  # 外径
                    "pitch": fields.get('pitch'),  # 螺距
                    "tpi": fields.get('tpi')  # 每英寸牙数
                })

    # 提取螺栓推荐场景 BOLT_SCENARIOS
    scenario_pattern = r"const\s+BOLT_SCENARIOS\s*=\s*\[([\s\S]*?)\];"
    match = re.search(scenario_pattern, content)
    if match:
        # 简化处理：手动构建数据
        result["bolt_scenarios"] = [
            {
                "id": "flange",
                "scenario": "法兰盘连接螺栓推荐",
                "description": "密封法兰、管道连接法兰",
                "recommendations": [
                    {"spec": "M12×1.75 强度8.8级", "desc": "DN50以下法兰，最常用规格"},
                    {"spec": "M16×2 强度8.8级", "desc": "DN80-150法兰，中型管道"},
                    {"spec": "M20×2.5 强度10.9级", "desc": "高压法兰，需要更大预紧力"}
                ]
            },
            {
                "id": "motor",
                "scenario": "电机安装螺栓推荐",
                "description": "电机底座固定到机座",
                "recommendations": [
                    {"spec": "M8×1.25 强度8.8级", "desc": "小型电机（<2.2kW）"},
                    {"spec": "M12×1.75 强度8.8级", "desc": "中型电机（2.2-22kW）"},
                    {"spec": "M16×2 强度8.8级", "desc": "大型电机（>22kW）"}
                ]
            },
            {
                "id": "bearing",
                "scenario": "轴承端盖螺栓推荐",
                "description": "轴承压盖固定螺栓",
                "recommendations": [
                    {"spec": "M6×1.0 强度6.8级", "desc": "小型轴承盖（d<50mm）"},
                    {"spec": "M8×1.25 强度8.8级", "desc": "中型轴承盖（d50-100mm）"},
                    {"spec": "M10×1.5 强度8.8级", "desc": "大型轴承盖（d>100mm）"}
                ]
            }
        ]

    # 写入文件
    out_path = os.path.join(OUT_DIR, "threads.json")
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    print(f"\n螺纹数据已写入: {out_path}")
    print(f"公制螺纹: {len(result['metric_threads'])} 种, 管螺纹: {len(result['pipe_threads'])} 种")
    return result


if __name__ == "__main__":
    print("=" * 50)
    print("提取轴承数据...")
    print("=" * 50)
    bearing_data = extract_bearing_data()

    print("\n" + "=" * 50)
    print("提取螺纹数据...")
    print("=" * 50)
    thread_data = extract_thread_data()

    print("\n" + "=" * 50)
    print("完成！")
    print("=" * 50)
