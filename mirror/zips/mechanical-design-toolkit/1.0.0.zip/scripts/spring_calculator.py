#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
弹簧计算引擎 (Spring Calculator)
支持圆柱螺旋弹簧、拉伸弹簧、扭转弹簧计算
符合GB/T 1239、GB/T 2089标准
"""

import math
from typing import Dict, List


class CompressionSpring:
    """压缩弹簧计算类"""
    
    # 弹簧材料性能 (简化)
    MATERIAL_PROPERTIES = {
        '65Mn': {'sigma_b': 1000, 'G': 79000, 'tau_s': 530},
        '60Si2MnA': {'sigma_b': 1600, 'G': 79000, 'tau_s': 800},
        '50CrVA': {'sigma_b': 1500, 'G': 79000, 'tau_s': 750},
        'SUS304': {'sigma_b': 600, 'G': 69000, 'tau_s': 350},
    }
    
    def __init__(self, wire_dia: float, coil_dia: float, 
                 total_coils: int, material: str = "65Mn"):
        """
        初始化弹簧参数
        
        Args:
            wire_dia: 线径 d (mm)
            coil_dia: 中径 D (mm)
            total_coils: 总圈数 n1
            material: 材料
        """
        self.d = wire_dia
        self.D = coil_dia
        self.n1 = total_coils
        self.material = material
        
        # 计算派生参数
        self.C = self.D / self.d  # 旋绕比
        self.working_coils = total_coils - 2  # 有效圈数 (两端并紧磨平)
        if self.working_coils < 2:
            self.working_coils = total_coils * 0.75  # 简化
            
        # 材料参数
        self.props = self.MATERIAL_PROPERTIES.get(
            material, self.MATERIAL_PROPERTIES['65Mn']
        )
        
    def calculate_stiffness(self) -> Dict:
        """
        计算弹簧刚度
        
        Returns:
            刚度计算结果
        """
        d = self.d
        D = self.D
        n = self.working_coils
        G = self.props['G']
        
        # 弹簧刚度
        k = (G * d**4) / (8 * D**3 * n)  # N/mm
        
        # 单圈刚度
        k_single = (G * d**4) / (8 * D**3)  # N/mm
        
        return {
            'wire_diameter_mm': d,
            'coil_diameter_mm': D,
            'winding_ratio_C': round(self.C, 2),
            'working_coils': round(n, 1),
            'shear_modulus_G_MPa': G,
            'stiffness_N_per_mm': round(k, 3),
            'single_coil_stiffness_N_per_mm': round(k_single, 3),
            'material': self.material
        }
    
    def calculate_deformation(self, force: float) -> Dict:
        """
        计算变形量
        
        Args:
            force: 载荷 (N)
            
        Returns:
            变形计算结果
        """
        k = (self.props['G'] * self.d**4) / (8 * self.D**3 * self.working_coils)
        
        # 变形量
        f = force / k  # mm
        
        # 弹簧自由高度 (简化假设)
        H0 = self.working_coils * self.d + 1.5 * self.d * 2  # 两端各1.5圈
        
        # 压并高度
        Hb = (self.n1 + 1.5) * self.d
        
        # 压并变形
        fb = H0 - Hb
        
        return {
            'load_N': force,
            'deformation_mm': round(f, 2),
            'stiffness_N_per_mm': round(k, 3),
            'free_height_mm': round(H0, 1),
            'solid_height_mm': round(Hb, 1),
            'solid_deformation_mm': round(fb, 2),
            'working_coils': round(self.working_coils, 1)
        }
    
    def check_shear_strength(self, force: float, 
                              safety_factor: float = 1.2) -> Dict:
        """
        剪切强度校核
        
        Args:
            force: 最大工作载荷 (N)
            safety_factor: 安全系数
            
        Returns:
            校核结果
        """
        d = self.d
        C = self.C
        
        # 曲度系数
        K = (4 * C - 1) / (4 * C - 4) + 0.615 / C
        
        # 最大剪应力
        tau_max = K * (8 * force * self.D) / (math.pi * d**3)
        
        # 许用剪应力
        tau_allow = self.props['tau_s'] / safety_factor
        
        # 安全系数
        SF = tau_allow / tau_max
        
        status = 'PASS' if SF >= 1.0 else 'FAIL'
        
        return {
            'max_load_N': force,
            'winding_ratio_C': round(C, 2),
            'curvature_factor_K': round(K, 3),
            'max_shear_stress_MPa': round(tau_max, 2),
            'allowable_shear_stress_MPa': round(tau_allow, 2),
            'safety_factor': round(SF, 2),
            'required_safety_factor': safety_factor,
            'status': status,
            'material': self.material,
            'standard': 'GB/T 1239'
        }
    
    def calculate_natural_frequency(self) -> Dict:
        """
        计算固有频率 (防止共振)
        
        Returns:
            频率计算结果
        """
        # 弹簧质量 (简化)
        rho = 7850  # 钢密度 kg/m³
        volume = math.pi * (self.d/2)**2 * math.pi * self.D * self.n1  # mm³
        mass = volume * 1e-9 * rho  # kg
        
        # 刚度
        k = (self.props['G'] * self.d**4) / (8 * self.D**3 * self.working_coils)  # N/mm
        k_N_per_m = k * 1000  # N/m
        
        # 固有频率
        f0 = (1 / (2 * math.pi)) * math.sqrt(k_N_per_m / mass)  # Hz
        
        return {
            'wire_diameter_mm': self.d,
            'coil_diameter_mm': self.D,
            'total_coils': self.n1,
            'mass_kg': round(mass, 6),
            'stiffness_N_per_m': round(k_N_per_m, 2),
            'natural_frequency_Hz': round(f0, 2),
            'note': '避免工作频率接近固有频率'
        }


class TensionSpring(CompressionSpring):
    """拉伸弹簧计算类 (继承压缩弹簧)"""
    
    def __init__(self, wire_dia: float, coil_dia: float,
                 total_coils: int, material: str = "65Mn"):
        super().__init__(wire_dia, coil_dia, total_coils, material)
        # 拉伸弹簧初拉力
        self.initial_tension = self._calculate_initial_tension()
        
    def _calculate_initial_tension(self) -> float:
        """计算初拉力 (简化)"""
        return 0.1 * self.props['tau_s'] * math.pi * self.d**2 / 4
    
    def calculate_force(self, deformation: float) -> Dict:
        """
        计算拉力
        
        Args:
            deformation: 变形量 (mm)
            
        Returns:
            拉力计算结果
        """
        k = (self.props['G'] * self.d**4) / (8 * self.D**3 * self.working_coils)
        
        # 拉力 (需克服初拉力)
        F = k * deformation + self.initial_tension
        
        return {
            'deformation_mm': deformation,
            'stiffness_N_per_mm': round(k, 3),
            'initial_tension_N': round(self.initial_tension, 2),
            'tension_force_N': round(F, 2),
            'note': '拉伸弹簧需克服初拉力'
        }


if __name__ == "__main__":
    # 示例1：压缩弹簧刚度计算
    print("=== 压缩弹簧刚度计算 ===")
    spring = CompressionSpring(wire_dia=5, coil_dia=30, total_coils=10)
    result1 = spring.calculate_stiffness()
    for key, value in result1.items():
        print(f"  {key}: {value}")
    
    print("\n=== 变形量计算 ===")
    result2 = spring.calculate_deformation(force=500)
    for key, value in result2.items():
        print(f"  {key}: {value}")
    
    print("\n=== 剪切强度校核 ===")
    result3 = spring.check_shear_strength(force=800, safety_factor=1.2)
    for key, value in result3.items():
        print(f"  {key}: {value}")
    
    print("\n=== 固有频率计算 ===")
    result4 = spring.calculate_natural_frequency()
    for key, value in result4.items():
        print(f"  {key}: {value}")
