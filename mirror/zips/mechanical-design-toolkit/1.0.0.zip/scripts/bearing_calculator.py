#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
轴承计算引擎 (Bearing Calculator) v3.0
支持8种轴承类型(596规格)、寿命计算、选型查询、游隙查询
符合 GB/T 276 / GB/T 292 / GB/T 283 / GB/T 297 / ISO 281 标准
数据来源: 机械宝(MechaBao)小程序 bearingData.js
"""

import math
import json
import os
from typing import Dict, Optional, List


# ==================== 数据加载 ====================
_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'data')
_BEARING_DATA = None

def _load_bearing_data() -> dict:
    """加载轴承数据库"""
    global _BEARING_DATA
    if _BEARING_DATA is None:
        db_path = os.path.join(_DATA_DIR, 'bearings.json')
        with open(db_path, 'r', encoding='utf-8') as f:
            _BEARING_DATA = json.load(f)
    return _BEARING_DATA


# ==================== 轴承寿命计算 ====================
class BearingLife:
    """轴承寿命计算类 (ISO 281)"""

    # 球轴承 vs 滚子轴承的寿命指数
    BALL_TYPES = {'deep_groove', 'angular_contact', 'self_aligning_ball', 'thrust_ball'}
    ROLLER_TYPES = {'cylindrical_roller', 'tapered_roller', 'needle_roller', 'self_aligning_roller'}

    def __init__(self, model: str, bearing_type: str = 'auto'):
        """
        初始化轴承参数

        Args:
            model: 轴承型号 (如 "6208", "NU2208")
            bearing_type: 轴承类型ID (auto=自动从数据库识别)
        """
        self.model = model
        self.bearing_type = bearing_type
        self._db_record = None

        # 尝试从数据库加载
        db = _load_bearing_data()
        for b in db['bearings']:
            if b['code'] == model:
                self._db_record = b
                if bearing_type == 'auto':
                    self.bearing_type = b['type_id']
                break

    def _is_ball_bearing(self) -> bool:
        return self.bearing_type in self.BALL_TYPES

    def _get_Cr(self) -> float:
        """获取额定动载荷 kN"""
        if self._db_record and self._db_record.get('Cr_kN'):
            return self._db_record['Cr_kN']
        # 估算
        d = self._get_inner_d()
        k = 5.0 if self._is_ball_bearing() else 8.0
        return k * (d ** 1.5)

    def _get_Cor(self) -> float:
        """获取额定静载荷 kN"""
        if self._db_record and self._db_record.get('Cor_kN'):
            return self._db_record['Cor_kN']
        return self._get_Cr() * 1.5

    def _get_inner_d(self) -> float:
        """获取内径 mm"""
        if self._db_record and self._db_record.get('d'):
            return self._db_record['d']
        # 从型号解析
        if len(self.model) >= 3:
            try:
                code = int(self.model[-2:])
                if code <= 3:
                    return 10 + (code - 1) * 5
                elif code in (22, 24, 26):
                    return 110 + (code - 22) * 10
                else:
                    return code * 5
            except ValueError:
                pass
        return 40

    def calculate_life(self, Fr: float = 5000, Fa: float = 0,
                       speed: float = 1000, reliability: float = 0.9) -> Dict:
        """
        计算轴承寿命 (ISO 281)

        Args:
            Fr: 径向载荷 (N)
            Fa: 轴向载荷 (N)
            speed: 转速 (rpm)
            reliability: 可靠度 (0.9=90%, 0.95=95%)

        Returns:
            寿命计算结果字典
        """
        Cr_N = self._get_Cr() * 1000  # kN → N
        P = self._calculate_equivalent_load(Fr, Fa)
        p = 3 if self._is_ball_bearing() else 10 / 3

        L10 = (Cr_N / P) ** p if P > 0 else 0
        a1 = self._reliability_factor(reliability)
        L10h = (L10 * a1 * 10 ** 6) / (60 * speed) if speed > 0 else 0

        result = {
            'model': self.model,
            'type_name': self._db_record['type_name'] if self._db_record else self.bearing_type,
            'basic_dynamic_load_rating_kN': round(self._get_Cr(), 2),
            'basic_static_load_rating_kN': round(self._get_Cor(), 2),
            'equivalent_dynamic_load_N': round(P, 2),
            'basic_rating_life_millions_rev': round(L10, 2),
            'reliability_factor_a1': round(a1, 3),
            'rating_life_hours': round(L10h, 2),
            'speed_rpm': speed,
            'reliability_percent': reliability * 100,
            'standard': 'ISO 281'
        }

        # 如果有数据库记录，补充尺寸信息
        if self._db_record:
            result['inner_diameter_mm'] = self._db_record.get('d')
            result['outer_diameter_mm'] = self._db_record.get('D')
            result['width_mm'] = self._db_record.get('B')
            result['grease_rpm'] = self._db_record.get('grease_rpm')
            result['oil_rpm'] = self._db_record.get('oil_rpm')
            result['weight_kg'] = self._db_record.get('weight_kg')

        return result

    def _calculate_equivalent_load(self, Fr: float, Fa: float) -> float:
        """计算当量动载荷"""
        if Fr <= 0 and Fa <= 0:
            return 0
        if Fr <= 0:
            return Fa

        e = 0.4  # 简化判断值
        if Fa / Fr <= e:
            return Fr
        else:
            X = 0.56
            Y = 1.5
            return X * Fr + Y * Fa

    def _reliability_factor(self, reliability: float) -> float:
        """可靠度修正系数 a1"""
        db = _load_bearing_data()
        for item in db.get('reliability_factors', []):
            if abs(item['reliability_percent'] / 100 - reliability) < 0.005:
                return item['a1']
        # 默认
        factors = {0.90: 1.0, 0.95: 0.62, 0.96: 0.53, 0.97: 0.44, 0.98: 0.33, 0.99: 0.21}
        return factors.get(reliability, 1.0)

    def calculate_static_safety(self, Fr: float = 5000, Fa: float = 0,
                                safety_factor: float = 2.0) -> Dict:
        """静强度校核"""
        C0 = self._get_Cor() * 1000  # kN → N
        P0 = max(Fr, 0.5 * Fr + Fa)
        S0 = C0 / P0 if P0 > 0 else 999

        return {
            'model': self.model,
            'basic_static_load_rating_kN': round(self._get_Cor(), 2),
            'equivalent_static_load_N': round(P0, 2),
            'static_safety_factor': round(S0, 2),
            'required_safety_factor': safety_factor,
            'status': 'PASS' if S0 >= safety_factor else 'FAIL'
        }


# ==================== 轴承数据库查询 ====================
class BearingDatabase:
    """轴承数据库查询类 (596规格)"""

    @classmethod
    def query(cls, model: str) -> Dict:
        """按型号精确查询轴承参数"""
        db = _load_bearing_data()
        for b in db['bearings']:
            if b['code'] == model:
                return b.copy()
        return {'model': model, 'error': f'未找到型号 {model}'}

    @classmethod
    def query_by_type(cls, type_id: str) -> List[Dict]:
        """按轴承类型查询所有规格"""
        db = _load_bearing_data()
        return [b for b in db['bearings'] if b['type_id'] == type_id]

    @classmethod
    def query_by_diameter(cls, inner_d: float, tolerance: float = 0.5) -> List[Dict]:
        """按内径范围查询"""
        db = _load_bearing_data()
        return [b for b in db['bearings']
                if b.get('d') is not None and abs(b['d'] - inner_d) <= tolerance]

    @classmethod
    def search(cls, keyword: str) -> List[Dict]:
        """关键词搜索 (型号/类型名)"""
        db = _load_bearing_data()
        kw = keyword.upper()
        results = []
        for b in db['bearings']:
            if kw in str(b.get('code', '')).upper() or kw in str(b.get('type_name', '')):
                results.append(b)
        return results

    @classmethod
    def list_types(cls) -> List[Dict]:
        """列出所有轴承类型"""
        db = _load_bearing_data()
        return db['bearing_types']

    @classmethod
    def list_all(cls) -> List[str]:
        """列出所有可用型号"""
        db = _load_bearing_data()
        return [b['code'] for b in db['bearings']]

    @classmethod
    def count(cls) -> int:
        """返回总规格数"""
        db = _load_bearing_data()
        return len(db['bearings'])


# ==================== 轴承游隙查询 ====================
class BearingClearance:
    """轴承游隙查询类"""

    @classmethod
    def query_clearance(cls, inner_d: float, clearance_class: str = 'CN') -> Dict:
        """
        查询轴承游隙

        Args:
            inner_d: 内径 (mm)
            clearance_class: 游隙等级 (C2/CN/C3/C4)

        Returns:
            游隙范围 (μm)
        """
        db = _load_bearing_data()
        for group in db['clearance_data']['groups']:
            if group['group'] == clearance_class:
                for r in group['ranges']:
                    if r['d_min'] <= inner_d < r['d_max']:
                        return {
                            'inner_d_mm': inner_d,
                            'clearance_class': clearance_class,
                            'class_name': group['name'],
                            'min_um': r['min_um'],
                            'max_um': r['max_um'],
                            'suggestion': group.get('suggestion', '')
                        }

        return {
            'inner_d_mm': inner_d,
            'clearance_class': clearance_class,
            'note': '游隙数据未找到，请参考厂家样本'
        }

    @classmethod
    def list_groups(cls) -> List[Dict]:
        """列出所有游隙组"""
        db = _load_bearing_data()
        return [{
            'group': g['group'],
            'name': g['name'],
            'description': g['description'],
            'suggestion': g.get('suggestion', '')
        } for g in db['clearance_data']['groups']]

    @classmethod
    def selection_guide(cls) -> List[Dict]:
        """游隙选择指南"""
        db = _load_bearing_data()
        return db['clearance_data'].get('selection_guide', [])


# ==================== 螺纹规格查询 ====================
class ThreadDatabase:
    """螺纹规格查询类"""

    _THREAD_DATA = None

    @classmethod
    def _load(cls) -> dict:
        if cls._THREAD_DATA is None:
            path = os.path.join(_DATA_DIR, 'threads.json')
            with open(path, 'r', encoding='utf-8') as f:
                cls._THREAD_DATA = json.load(f)
        return cls._THREAD_DATA

    @classmethod
    def query_metric(cls, diameter: float) -> Dict:
        """按公称直径查询公制螺纹"""
        data = cls._load()
        for t in data['metric_threads']:
            if t['d'] == diameter:
                return t
        # 尝试近似
        nearest = min(data['metric_threads'], key=lambda x: abs(x['d'] - diameter))
        return {**nearest, 'note': f'M{diameter} 不在标准表中，最近似规格'}

    @classmethod
    def query_pipe(cls, size: str) -> Optional[Dict]:
        """按规格查询管螺纹"""
        data = cls._load()
        for t in data['pipe_threads']:
            if t['designation'] == size:
                return t
        return None

    @classmethod
    def list_metric(cls) -> List[Dict]:
        """列出所有公制螺纹"""
        return cls._load()['metric_threads']

    @classmethod
    def list_pipe(cls) -> List[Dict]:
        """列出所有管螺纹"""
        return cls._load()['pipe_threads']

    @classmethod
    def bolt_recommendations(cls) -> List[Dict]:
        """获取螺栓推荐场景"""
        return cls._load()['bolt_scenarios']


# ==================== 主程序示例 ====================
if __name__ == "__main__":
    print("=" * 60)
    print("轴承计算引擎 v3.0 — 机械宝(MechaBao)")
    print("=" * 60)

    # 1. 查询轴承型号
    print("\n--- 示例1: 查询6208轴承参数 ---")
    info = BearingDatabase.query('6208')
    for k, v in info.items():
        print(f"  {k}: {v}")

    # 2. 按内径查询
    print("\n--- 示例2: 内径40mm的所有轴承 ---")
    d40 = BearingDatabase.query_by_diameter(40)
    for b in d40[:5]:
        print(f"  {b['code']} ({b['type_name']}) Cr={b['Cr_kN']}kN")
    print(f"  ... 共{len(d40)}种")

    # 3. 寿命计算
    print("\n--- 示例3: 6208轴承寿命计算 ---")
    bl = BearingLife('6208')
    life = bl.calculate_life(Fr=5000, Fa=2000, speed=1500, reliability=0.9)
    for k, v in life.items():
        print(f"  {k}: {v}")

    # 4. 游隙查询
    print("\n--- 示例4: 内径40mm C3游隙 ---")
    clr = BearingClearance.query_clearance(40, 'C3')
    for k, v in clr.items():
        print(f"  {k}: {v}")

    # 5. 螺纹查询
    print("\n--- 示例5: M10螺纹参数 ---")
    t = ThreadDatabase.query_metric(10)
    for k, v in t.items():
        print(f"  {k}: {v}")

    # 6. 管螺纹查询
    print("\n--- 示例6: G1/2\"管螺纹 ---")
    p = ThreadDatabase.query_pipe('G1/2"')
    if p:
        for k, v in p.items():
            print(f"  {k}: {v}")

    # 7. 统计
    print("\n--- 统计 ---")
    print(f"  轴承总规格: {BearingDatabase.count()}")
    for t in BearingDatabase.list_types():
        print(f"    {t['type_name']}: {t['count']}个 ({t['standard']})")
    print(f"  公制螺纹: {len(ThreadDatabase.list_metric())}种")
    print(f"  管螺纹: {len(ThreadDatabase.list_pipe())}种")
