#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
挠度计算引擎 (Deflection Calculator)
支持5种支承条件、6种载荷类型
符合材料力学理论
"""

import math
from typing import Dict, List, Tuple


class DeflectionCalculator:
    """挠度计算类"""
    
    # 支承条件类型
    SUPPORT_TYPES = {
        'simply_simply': '简支梁',
        'cantilever': '悬臂梁',
        'fixed_fixed': '两端固定梁',
        'fixed_simply': '一端固定一端简支',
        'continuous': '连续梁'
    }
    
    def __init__(self, length: float, EI: float = None, 
                 E: float = 210000, I: float = None):
        """
        初始化梁参数
        
        Args:
            length: 梁长度 (mm)
            EI: 抗弯刚度 (N·mm²)
            E: 弹性模量 (MPa)
            I: 截面惯性矩 (mm⁴)
        """
        self.length = length
        if EI:
            self.EI = EI
        elif I:
            self.EI = E * I
        else:
            self.EI = E * 10000  # 假设I=10000 mm⁴
            
    def calculate_simply_simply(self, load_type: str, 
                               load_value: float, 
                               position: float = None) -> Dict:
        """
        简支梁挠度计算
        
        Args:
            load_type: 载荷类型 ('point', 'uniform', 'triangular', 'moment')
            load_value: 载荷值 (N 或 N·mm)
            position: 集中力位置 (mm, 从左侧算起)
            
        Returns:
            挠度和转角结果
        """
        L = self.length
        EI = self.EI
        
        if load_type == 'point':
            # 集中力作用在位置a处
            a = position if position else L/2
            b = L - a
            
            # 最大挠度 (在跨中附近)
            if a >= b:
                y_max = load_value * b * (3*L**2 - 4*b**2)**1.5 / (9 * math.sqrt(3) * L * EI)
            else:
                y_max = load_value * a * (3*L**2 - 4*a**2)**1.5 / (9 * math.sqrt(3) * L * EI)
                
            # 跨中挠度
            y_mid = load_value * a * b * (L**2 - a**2 - b**2) / (6 * L * EI)
            
            return {
                'beam_type': '简支梁',
                'load_type': '集中力',
                'load_N': load_value,
                'position_mm': a,
                'max_deflection_mm': round(y_max, 4),
                'midspan_deflection_mm': round(y_mid, 4),
                'length_mm': L,
                'EI_Nmm2': EI
            }
            
        elif load_type == 'uniform':
            # 均布载荷
            q = load_value  # N/mm
            
            # 最大挠度 (跨中)
            y_max = 5 * q * L**4 / (384 * EI)
            
            # 跨中转角
            theta = q * L**3 / (24 * EI)
            
            return {
                'beam_type': '简支梁',
                'load_type': '均布载荷',
                'load_N_per_mm': q,
                'max_deflection_mm': round(y_max, 4),
                'midspan_rotation_rad': round(theta, 6),
                'length_mm': L,
                'EI_Nmm2': EI
            }
            
        elif load_type == 'moment':
            # 集中力偶
            M = load_value  # N·mm
            a = position if position else L/2
            
            # 转角
            theta_a = M * b / (3 * EI)  # 左端转角
            theta_b = M * a / (6 * EI)  # 右端转角
            
            # 最大挠度
            y_max = M * L**2 / (9 * math.sqrt(3) * EI)
            
            return {
                'beam_type': '简支梁',
                'load_type': '集中力偶',
                'moment_Nmm': M,
                'position_mm': a,
                'left_rotation_rad': round(theta_a, 6),
                'right_rotation_rad': round(theta_b, 6),
                'max_deflection_mm': round(y_max, 4),
                'length_mm': L,
                'EI_Nmm2': EI
            }
            
    def calculate_cantilever(self, load_type: str, 
                             load_value: float) -> Dict:
        """
        悬臂梁挠度计算
        
        Args:
            load_type: 载荷类型 ('point', 'uniform')
            load_value: 载荷值
            
        Returns:
            挠度和转角结果
        """
        L = self.length
        EI = self.EI
        
        if load_type == 'point':
            # 自由端集中力
            F = load_value
            
            # 自由端挠度
            y_free = F * L**3 / (3 * EI)
            
            # 自由端转角
            theta = F * L**2 / (2 * EI)
            
            return {
                'beam_type': '悬臂梁',
                'load_type': '自由端集中力',
                'load_N': F,
                'free_end_deflection_mm': round(y_free, 4),
                'free_end_rotation_rad': round(theta, 6),
                'length_mm': L,
                'EI_Nmm2': EI
            }
            
        elif load_type == 'uniform':
            # 均布载荷
            q = load_value  # N/mm
            
            # 自由端挠度
            y_free = q * L**4 / (8 * EI)
            
            # 自由端转角
            theta = q * L**3 / (6 * EI)
            
            return {
                'beam_type': '悬臂梁',
                'load_type': '均布载荷',
                'load_N_per_mm': q,
                'free_end_deflection_mm': round(y_free, 4),
                'free_end_rotation_rad': round(theta, 6),
                'length_mm': L,
                'EI_Nmm2': EI
            }
    
    def calculate_fixed_fixed(self, load_type: str,
                              load_value: float,
                              position: float = None) -> Dict:
        """
        两端固定梁挠度计算
        
        Args:
            load_type: 载荷类型 ('point', 'uniform')
            load_value: 载荷值
            position: 集中力位置
            
        Returns:
            挠度和转角结果
        """
        L = self.length
        EI = self.EI
        
        if load_type == 'point':
            # 集中力
            F = load_value
            a = position if position else L/2
            b = L - a
            
            # 最大挠度
            if abs(a - L/2) < 1e-6:  # 跨中加载
                y_max = F * L**3 / (192 * EI)
            else:
                y_max = F * a**3 * b**3 / (3 * L**3 * EI)
                
            return {
                'beam_type': '两端固定梁',
                'load_type': '集中力',
                'load_N': F,
                'position_mm': a,
                'max_deflection_mm': round(y_max, 4),
                'length_mm': L,
                'EI_Nmm2': EI
            }
            
        elif load_type == 'uniform':
            # 均布载荷
            q = load_value
            
            # 最大挠度 (跨中)
            y_max = q * L**4 / (384 * EI)
            
            return {
                'beam_type': '两端固定梁',
                'load_type': '均布载荷',
                'load_N_per_mm': q,
                'max_deflection_mm': round(y_max, 4),
                'length_mm': L,
                'EI_Nmm2': EI
            }


if __name__ == "__main__":
    # 示例1：简支梁跨中集中力
    print("=== 简支梁跨中集中力 ===")
    calc1 = DeflectionCalculator(length=1000, E=210000, I=50000)
    result1 = calc1.calculate_simply_simply(
        load_type='point', 
        load_value=10000, 
        position=500
    )
    for key, value in result1.items():
        print(f"{key}: {value}")
    
    print("\n=== 简支梁均布载荷 ===")
    result2 = calc1.calculate_simply_simply(
        load_type='uniform',
        load_value=10  # 10 N/mm
    )
    for key, value in result2.items():
        print(f"{key}: {value}")
    
    print("\n=== 悬臂梁自由端集中力 ===")
    calc2 = DeflectionCalculator(length=500, E=210000, I=50000)
    result3 = calc2.calculate_cantilever(
        load_type='point',
        load_value=5000
    )
    for key, value in result3.items():
        print(f"{key}: {value}")
