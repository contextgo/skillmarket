#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
齿形链计算引擎 (Silent Chain / Toothed Chain Calculator)
支持齿形链选型和参数计算
符合GB/T 10855标准
"""

import math
from typing import Dict, List


class SilentChainCalculator:
    """齿形链计算类"""
    
    # 齿形链参数 (部分常用规格)
    SILENT_CHAIN_DATA = {
        'CL06': {'pitch': 9.525, 'roller_diameter': 6.35, 'tensile_strength': 8900, 'width_range': [13.5, 25.4, 38.1]},
        'CL08': {'pitch': 12.7, 'roller_diameter': 8.51, 'tensile_strength': 17800, 'width_range': [16.6, 31.8, 47.6]},
        'CL10': {'pitch': 15.875, 'roller_diameter': 10.16, 'tensile_strength': 22000, 'width_range': [20.0, 38.1, 57.2]},
        'CL12': {'pitch': 19.05, 'roller_diameter': 11.91, 'tensile_strength': 31300, 'width_range': [25.4, 48.3, 72.2]},
        'CL16': {'pitch': 25.4, 'roller_diameter': 15.88, 'tensile_strength': 55600, 'width_range': [31.8, 60.3, 90.5]},
        'CL20': {'pitch': 31.75, 'roller_diameter': 19.05, 'tensile_strength': 86700, 'width_range': [38.1, 73.0, 109.5]},
        'CL24': {'pitch': 38.1, 'roller_diameter': 22.23, 'tensile_strength': 124500, 'width_range': [44.5, 85.7, 128.6]},
        'CL32': {'pitch': 50.8, 'roller_diameter': 28.58, 'tensile_strength': 222400, 'width_range': [57.2, 114.3, 171.5]},
    }
    
    def __init__(self, power: float, speed: float):
        """
        初始化齿形链参数
        
        Args:
            power: 传递功率 (kW)
            speed: 小链轮转速 (rpm)
        """
        self.power = power
        self.speed = speed
        
    def select_chain(self, service_factor: float = 1.2) -> Dict:
        """
        齿形链选型
        
        Args:
            service_factor: 工况系数
            
        Returns:
            选型结果字典
        """
        # 计算功率
        Pc = self.power * service_factor
        
        # 根据功率和转速选择链号 (简化逻辑)
        if Pc <= 1.0:
            chain_id = 'CL06'
        elif Pc <= 2.5:
            chain_id = 'CL08'
        elif Pc <= 5.0:
            chain_id = 'CL10'
        elif Pc <= 10:
            chain_id = 'CL12'
        elif Pc <= 20:
            chain_id = 'CL16'
        elif Pc <= 40:
            chain_id = 'CL20'
        elif Pc <= 75:
            chain_id = 'CL24'
        else:
            chain_id = 'CL32'
            
        # 获取链参数
        chain_data = self.SILENT_CHAIN_DATA.get(chain_id, self.SILENT_CHAIN_DATA['CL12'])
        pitch = chain_data['pitch']
        
        # 推荐小链轮齿数
        if self.speed <= 100:
            z1_recommended = 19
        elif self.speed <= 500:
            z1_recommended = 23
        elif self.speed <= 1000:
            z1_recommended = 27
        elif self.speed <= 1500:
            z1_recommended = 31
        else:
            z1_recommended = 35
            
        # 计算链速
        v = pitch * z1_recommended * self.speed / (60000)
        
        # 推荐链宽 (根据功率和节距)
        width_options = chain_data['width_range']
        # 简化：选择中间宽度
        recommended_width = width_options[1] if len(width_options) > 1 else width_options[0]
        
        return {
            'chain_id': chain_id,
            'pitch_mm': pitch,
            'design_power_kW': round(Pc, 2),
            'recommended_pinion_teeth': z1_recommended,
            'chain_speed_m_s': round(v, 2),
            'tensile_strength_N': chain_data['tensile_strength'],
            'recommended_width_mm': recommended_width,
            'width_options_mm': width_options,
            'service_factor': service_factor,
            'note': '齿形链( Silent Chain)'
        }
    
    def calculate_sprocket(self, chain_id: str, teeth: int) -> Dict:
        """
        计算链轮参数
        
        Args:
            chain_id: 链号
            teeth: 齿数
            
        Returns:
            链轮参数字典
        """
        if chain_id not in self.SILENT_CHAIN_DATA:
            return {'error': f'未找到链号 {chain_id}'}
            
        chain_data = self.SILENT_CHAIN_DATA[chain_id]
        p = chain_data['pitch']
        
        # 分度圆直径
        d = p / math.sin(math.pi / teeth)
        
        # 齿顶圆直径 (简化公式，不同于滚子链)
        da = p * (1 + 1 / math.sin(math.pi / teeth)) - 0.2 * p
        
        # 齿根圆直径
        df = d - 2 * chain_data['roller_diameter'] * 0.8
        
        # 量柱测量距 (简化)
        if teeth % 2 == 0:
            Mr = p * (1 + 1 / math.cos(math.pi / teeth)) + 2 * 0.5 * chain_data['roller_diameter']
        else:
            Mr = p * (1 + 1 / math.cos(math.pi / (2 * teeth))) + 2 * 0.5 * chain_data['roller_diameter']
        
        return {
            'chain_id': chain_id,
            'teeth': teeth,
            'pitch_mm': p,
            'pitch_circle_diameter_mm': round(d, 2),
            'addendum_circle_diameter_mm': round(da, 2),
            'dedendum_circle_diameter_mm': round(df, 2),
            'measurement_over_pins_mm': round(Mr, 2),
            'roller_diameter_mm': chain_data['roller_diameter'],
            'note': '齿形链轮参数'
        }
    
    def calculate_power_transmission(self, chain_id: str, 
                                    teeth: int, speed: float,
                                    width: float = None) -> Dict:
        """
        计算传动功率
        
        Args:
            chain_id: 链号
            teeth: 链轮齿数
            speed: 链速 (m/min)
            width: 链宽 (mm)，不提供则使用推荐值
            
        Returns:
            功率计算结果
        """
        chain_data = self.SILENT_CHAIN_DATA.get(chain_id, self.SILENT_CHAIN_DATA['CL12'])
        
        # 使用推荐宽度
        if width is None:
            width = chain_data['width_range'][1]
        
        # 单排链传递功率 (简化公式，实际需查制造商样本)
        # 齿形链的承载能力和宽度相关
        P_single = chain_data['tensile_strength'] * 0.1 * (width / 50) / 1000  # kW
        
        return {
            'chain_id': chain_id,
            'single_row_power_kW': round(P_single, 2),
            'speed_m_min': speed,
            'chain_width_mm': width,
            'note': '齿形链传递功率(简化计算)，实际请查厂家样本'
        }

    @classmethod
    def list_all_chains(cls) -> List[str]:
        """列出所有可用的齿形链型号"""
        return list(cls.SILENT_CHAIN_DATA.keys())


if __name__ == "__main__":
    # 示例1：齿形链选型
    print("=== 齿形链选型 ===")
    calc = SilentChainCalculator(power=7.5, speed=960)
    result = calc.select_chain(service_factor=1.2)
    for key, value in result.items():
        print(f"{key}: {value}")
    
    print("\n=== 齿形链轮参数计算 ===")
    sprocket = calc.calculate_sprocket(chain_id='CL12', teeth=21)
    for key, value in sprocket.items():
        print(f"{key}: {value}")
    
    print("\n=== 齿形链传动功率计算 ===")
    power = calc.calculate_power_transmission(
        chain_id='CL12', 
        teeth=21, 
        speed=15,
        width=48.3
    )
    for key, value in power.items():
        print(f"{key}: {value}")
