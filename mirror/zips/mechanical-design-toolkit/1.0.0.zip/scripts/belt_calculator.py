#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V带传动设计引擎 (V-Belt Drive Calculator)
支持Y~E型V带选型设计、校核计算
符合GB/T 11544标准
"""

import math
from typing import Dict, List, Tuple


class VBelCalculator:
    """V带传动计算类"""
    
    # V带型号参数
    BELT_TYPES = {
        'Y': {'section_area': 9.6, 'mass_per_m': 0.02, 'P0_ref': 0.15},
        'Z': {'section_area': 27, 'mass_per_m': 0.06, 'P0_ref': 0.35},
        'A': {'section_area': 81, 'mass_per_m': 0.17, 'P0_ref': 0.77},
        'B': {'section_area': 143, 'mass_per_m': 0.30, 'P0_ref': 1.64},
        'C': {'section_area': 252, 'mass_per_m': 0.52, 'P0_ref': 3.30},
        'D': {'section_area': 476, 'mass_per_m': 0.97, 'P0_ref': 6.24},
        'E': {'section_area': 780, 'mass_per_m': 1.60, 'P0_ref': 10.79}
    }
    
    def __init__(self, belt_type: str, power: float, speed: float):
        """
        初始化V带传动参数
        
        Args:
            belt_type: 带型 ('Y', 'Z', 'A', 'B', 'C', 'D', 'E')
            power: 传递功率 (kW)
            speed: 小带轮转速 (rpm)
        """
        self.belt_type = belt_type
        self.power = power
        self.speed = speed
        
    def select_belt(self, service_factor: float = 1.2) -> Dict:
        """
        V带选型
        
        Args:
            service_factor: 工况系数
            
        Returns:
            选型结果字典
        """
        # 设计功率
        Pd = self.power * service_factor
        
        # 查找P0表 (简化：根据转速和带型)
        n = self.speed
        belt_params = self.BELT_TYPES.get(self.belt_type, self.BELT_TYPES['A'])
        
        # 单根V带基本额定功率 (简化公式)
        if n <= 800:
            P0 = belt_params['P0_ref'] * 0.7
        elif n <= 1200:
            P0 = belt_params['P0_ref'] * 0.85
        elif n <= 1600:
            P0 = belt_params['P0_ref']
        elif n <= 2400:
            P0 = belt_params['P0_ref'] * 1.1
        else:
            P0 = belt_params['P0_ref'] * 1.2
            
        # 包角系数 (假设包角180°)
        K_alpha = 1.0
        
        # 带长系数 (假设)
        K_L = 1.0
        
        # 单根V带额定功率
        P1 = P0 * K_alpha * K_L
        
        # 所需V带根数
        z = math.ceil(Pd / P1)
        
        return {
            'belt_type': self.belt_type,
            'design_power_kW': round(Pd, 2),
            'single_belt_power_kW': round(P1, 2),
            'belt_count': z,
            'service_factor': service_factor,
            'speed_rpm': self.speed
        }
    
    def calculate_pulley(self, diameter: float) -> Dict:
        """
        计算带轮参数
        
        Args:
            diameter: 基准直径 (mm)
            
        Returns:
            带轮参数字典
        """
        # 带轮外径
        if self.belt_type == 'Y':
            da = diameter + 6.4
        elif self.belt_type == 'Z':
            da = diameter + 9.6
        elif self.belt_type == 'A':
            da = diameter + 12.8
        elif self.belt_type == 'B':
            da = diameter + 16.0
        elif self.belt_type == 'C':
            da = diameter + 21.2
        elif self.belt_type == 'D':
            da = diameter + 28.8
        else:  # E
            da = diameter + 38.4
            
        # 节圆直径 (等于基准直径)
        d = diameter
        
        # 带轮宽度 (假设2根带)
        if self.belt_type in ['Y', 'Z']:
            B = 15 * 2
        elif self.belt_type == 'A':
            B = 19 * 2
        elif self.belt_type == 'B':
            B = 24 * 2
        else:
            B = 29 * 2
            
        return {
            'belt_type': self.belt_type,
            'reference_diameter_mm': d,
            'outside_diameter_mm': round(da, 1),
            'pitch_diameter_mm': d,
            'pulley_width_mm': B
        }
    
    def check_wrap_angle(self, center_distance: float, 
                         d1: float, d2: float) -> Dict:
        """
        校核包角
        
        Args:
            center_distance: 中心距 (mm)
            d1: 小带轮直径 (mm)
            d2: 大带轮直径 (mm)
            
        Returns:
            包角校核结果
        """
        # 包角 (度)
        alpha = 180 - (d2 - d1) * 57.3 / center_distance
        
        # 包角系数
        if alpha >= 180:
            K_alpha = 1.0
        elif alpha >= 150:
            K_alpha = 0.92
        elif alpha >= 120:
            K_alpha = 0.83
        else:
            K_alpha = 0.75
            
        status = 'PASS' if alpha >= 120 else 'FAIL'
        
        return {
            'wrap_angle_deg': round(alpha, 1),
            'wrap_angle_factor': round(K_alpha, 2),
            'center_distance_mm': center_distance,
            'status': status
        }


if __name__ == "__main__":
    # 示例：设计A型V带传动
    print("=== V带选型设计 ===")
    calc = VBelCalculator(belt_type='A', power=7.5, speed=1450)
    result = calc.select_belt(service_factor=1.2)
    for key, value in result.items():
        print(f"{key}: {value}")
    
    print("\n=== 带轮参数计算 ===")
    pulley = calc.calculate_pulley(diameter=100)
    for key, value in pulley.items():
        print(f"{key}: {value}")
    
    print("\n=== 包角校核 ===")
    wrap = calc.check_wrap_angle(center_distance=500, d1=100, d2=250)
    for key, value in wrap.items():
        print(f"{key}: {value}")
