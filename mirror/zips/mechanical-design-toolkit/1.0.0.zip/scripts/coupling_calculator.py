#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
联轴器选型计算引擎 (Coupling Calculator)
支持LX弹性柱销联轴器、SWC万向联轴器选型
符合GB/T 3852标准
"""

import math
from typing import Dict, List


class CouplingCalculator:
    """联轴器选型计算类"""
    
    # 工况系数 KA
    SERVICE_FACTORS = {
        'uniform': {'motor': 1.0, 'turbine': 1.0, 'hydraulic': 1.0},
        'light_shock': {'motor': 1.25, 'turbine': 1.15, 'hydraulic': 1.1},
        'medium_shock': {'motor': 1.5, 'turbine': 1.35, 'hydraulic': 1.25},
        'heavy_shock': {'motor': 2.0, 'turbine': 1.75, 'hydraulic': 1.5}
    }
    
    # LX弹性柱销联轴器参数
    LX_COUPLINGS = {
        'LX1': {'nominal_torque_Nm': 250, 'max_speed_rpm': 8500, 'd_min': 12, 'd_max': 22},
        'LX2': {'nominal_torque_Nm': 560, 'max_speed_rpm': 6300, 'd_min': 20, 'd_max': 35},
        'LX3': {'nominal_torque_Nm': 1250, 'max_speed_rpm': 4750, 'd_min': 30, 'd_max': 48},
        'LX4': {'nominal_torque_Nm': 2500, 'max_speed_rpm': 3870, 'd_min': 40, 'd_max': 75},
        'LX5': {'nominal_torque_Nm': 5000, 'max_speed_rpm': 3300, 'd_min': 50, 'd_max': 90},
        'LX6': {'nominal_torque_Nm': 8000, 'max_speed_rpm': 2720, 'd_min': 60, 'd_max': 110},
        'LX7': {'nominal_torque_Nm': 11200, 'max_speed_rpm': 2360, 'd_min': 70, 'd_max': 125},
        'LX8': {'nominal_torque_Nm': 16000, 'max_speed_rpm': 2120, 'd_min': 80, 'd_max': 140},
        'LX9': {'nominal_torque_Nm': 22400, 'max_speed_rpm': 1850, 'd_min': 90, 'd_max': 160},
        'LX10': {'nominal_torque_Nm': 31500, 'max_speed_rpm': 1600, 'd_min': 100, 'd_max': 180},
    }
    
    # SWC万向联轴器参数
    SWC_COUPLINGS = {
        'SWC58': {'nominal_torque_Nm': 150, 'max_speed_rpm': 6000, 'max_angle_deg': 25},
        'SWC65': {'nominal_torque_Nm': 250, 'max_speed_rpm': 6000, 'max_angle_deg': 25},
        'SWC75': {'nominal_torque_Nm': 355, 'max_speed_rpm': 6000, 'max_angle_deg': 25},
        'SWC90': {'nominal_torque_Nm': 560, 'max_speed_rpm': 6000, 'max_angle_deg': 25},
        'SWC100': {'nominal_torque_Nm': 800, 'max_speed_rpm': 6000, 'max_angle_deg': 25},
        'SWC120': {'nominal_torque_Nm': 1250, 'max_speed_rpm': 5000, 'max_angle_deg': 25},
        'SWC150': {'nominal_torque_Nm': 2500, 'max_speed_rpm': 4000, 'max_angle_deg': 25},
        'SWC180': {'nominal_torque_Nm': 5000, 'max_speed_rpm': 3300, 'max_angle_deg': 25},
        'SWC200': {'nominal_torque_Nm': 7100, 'max_speed_rpm': 3000, 'max_angle_deg': 25},
        'SWC225': {'nominal_torque_Nm': 10000, 'max_speed_rpm': 2600, 'max_angle_deg': 25},
    }
    
    def __init__(self, power: float = None, speed: float = None, 
                 torque: float = None):
        """
        初始化联轴器参数
        
        Args:
            power: 传递功率 (kW)
            speed: 转速 (rpm)
            torque: 扭矩 (N·m) - 如提供则优先使用
        """
        if torque:
            self.torque = torque
        elif power and speed:
            self.torque = 9550 * power / speed
        else:
            self.torque = 0
            
        self.power = power
        self.speed = speed
        
    def calculate_design_torque(self, service_factor: float = 1.5) -> Dict:
        """
        计算设计扭矩
        
        Args:
            service_factor: 工况系数
            
        Returns:
            设计扭矩计算结果
        """
        T = self.torque
        T_calc = T * service_factor
        
        return {
            'nominal_torque_Nm': round(T, 2),
            'service_factor': service_factor,
            'calculated_torque_Nm': round(T_calc, 2),
            'power_kW': self.power,
            'speed_rpm': self.speed
        }
    
    def select_lx_coupling(self, shaft_dia: float, 
                           service_factor: float = 1.5) -> Dict:
        """
        选型LX弹性柱销联轴器
        
        Args:
            shaft_dia: 轴径 (mm)
            service_factor: 工况系数
            
        Returns:
            选型结果
        """
        T_calc = self.torque * service_factor
        
        # 查找合适的型号
        selected = None
        for model, params in self.LX_COUPLINGS.items():
            if (params['nominal_torque_Nm'] >= T_calc and 
                params['d_min'] <= shaft_dia <= params['d_max']):
                selected = {'model': model, **params}
                break
        
        if not selected:
            return {
                'error': '未找到合适的LX联轴器型号',
                'required_torque_Nm': round(T_calc, 2),
                'shaft_diameter_mm': shaft_dia
            }
        
        # 校核转速
        speed_ok = self.speed <= selected['max_speed_rpm'] if self.speed else True
        
        return {
            'selected_model': selected['model'],
            'type': 'LX弹性柱销联轴器',
            'nominal_torque_Nm': selected['nominal_torque_Nm'],
            'max_speed_rpm': selected['max_speed_rpm'],
            'shaft_diameter_range_mm': f"{selected['d_min']}~{selected['d_max']}",
            'calculated_torque_Nm': round(T_calc, 2),
            'speed_check': 'PASS' if speed_ok else 'FAIL',
            'service_factor': service_factor
        }
    
    def select_swc_coupling(self, angle: float = 10,
                            service_factor: float = 1.5) -> Dict:
        """
        选型SWC万向联轴器
        
        Args:
            angle: 轴交角 (度)
            service_factor: 工况系数
            
        Returns:
            选型结果
        """
        T_calc = self.torque * service_factor
        
        # 查找合适的型号
        selected = None
        for model, params in self.SWC_COUPLINGS.items():
            if params['nominal_torque_Nm'] >= T_calc:
                selected = {'model': model, **params}
                break
        
        if not selected:
            return {
                'error': '未找到合适的SWC联轴器型号',
                'required_torque_Nm': round(T_calc, 2)
            }
        
        # 校核转速和角度
        speed_ok = self.speed <= selected['max_speed_rpm'] if self.speed else True
        angle_ok = angle <= selected['max_angle_deg']
        
        return {
            'selected_model': selected['model'],
            'type': 'SWC十字轴万向联轴器',
            'nominal_torque_Nm': selected['nominal_torque_Nm'],
            'max_speed_rpm': selected['max_speed_rpm'],
            'max_angle_deg': selected['max_angle_deg'],
            'calculated_torque_Nm': round(T_calc, 2),
            'actual_angle_deg': angle,
            'speed_check': 'PASS' if speed_ok else 'FAIL',
            'angle_check': 'PASS' if angle_ok else 'FAIL',
            'service_factor': service_factor
        }
    
    @classmethod
    def get_service_factor(cls, load_type: str, driver_type: str = 'motor') -> float:
        """
        获取工况系数
        
        Args:
            load_type: 载荷类型 ('uniform', 'light_shock', 'medium_shock', 'heavy_shock')
            driver_type: 原动机类型 ('motor', 'turbine', 'hydraulic')
            
        Returns:
            工况系数 KA
        """
        return cls.SERVICE_FACTORS.get(load_type, {}).get(driver_type, 1.5)


if __name__ == "__main__":
    # 示例1：LX联轴器选型
    print("=== LX联轴器选型 ===")
    calc = CouplingCalculator(power=7.5, speed=960)
    result = calc.select_lx_coupling(shaft_dia=45, service_factor=1.5)
    for key, value in result.items():
        print(f"{key}: {value}")
    
    print("\n=== SWC万向联轴器选型 ===")
    calc2 = CouplingCalculator(power=15, speed=720)
    result2 = calc2.select_swc_coupling(angle=15, service_factor=1.5)
    for key, value in result2.items():
        print(f"{key}: {value}")
    
    print("\n=== 工况系数查询 ===")
    ka = CouplingCalculator.get_service_factor('medium_shock', 'motor')
    print(f"中等冲击、电动机驱动: KA = {ka}")
