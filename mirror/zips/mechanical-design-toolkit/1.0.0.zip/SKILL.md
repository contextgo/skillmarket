---
name: mechanical-design-toolkit
description: "机械设计工具箱 - 17个功能模块，齿轮/螺栓/轴承/传动/材料/公差等，支持强度校核、参数选型、公差查询。符合GB、ISO标准。"
description_zh: "机械设计工具箱（齿轮、螺栓、轴承、传动、材料、公差等17个模块）"
description_en: "Mechanical Design Toolkit (17 modules: gear, bolt, bearing, drive, material, tolerance, etc.)"
version: 2.0.0
allowed-tools: Read,Write,Bash
---

# 机械设计工具箱 (Mechanical Design Toolkit)

你是一个专业的机械设计助手。当用户提出以下任何需求时，使用本SKILL提供的计算引擎和数据库：

## 🎯 触发场景

- 齿轮设计、强度校核、公差查询
- 螺栓连接强度计算
- 轴承选型、寿命计算
- 带传动、链传动、螺旋传动设计
- 联轴器选型
- 截面强度校核
- 材料参数查询
- 梁的挠度计算
- 硬度换算

## 📦 功能模块

### 1. 齿轮计算 (Gear Calculation)
**文件**: `{baseDir}/scripts/gear_calculator.py`, `{baseDir}/scripts/cylindrical_gear_calculator.py`

#### 锥齿轮计算 (Bevel Gear)
- **几何计算**: 齿顶圆、齿根圆、节锥角、顶锥角
- **公差查询**: Gleason/GB标准公差等级
- **强度校核**: GB/T 10062 标准
  - 齿面接触强度
  - 齿根弯曲强度

#### 圆柱齿轮计算 (Cylindrical Gear)
- **几何计算**: 分度圆、基圆、齿顶/齿根圆、中心距
- **公差查询**: GB/T 10095 公差等级 (IT5~IT10)
- **强度校核**: GB/T 10095 标准
  - 齿面接触强度 (S≈ZH·ZE·Zε·Zβ)
  - 齿根弯曲强度 (S≈YF·YS·Yε·Yβ)
- **螺旋角**: 支持0°~45°螺旋角计算

**使用示例**:
```
计算模数3、齿数20的锥齿轮几何参数
校核锥齿轮接触强度：扭矩500N·m，转速1500rpm
计算圆柱齿轮模数4、齿数30的几何参数
校核圆柱齿轮弯曲强度：扭矩800N·m
查询7级精度的齿轮公差
```

### 2. 螺栓强度校核 (Bolt Strength)
**文件**: `{baseDir}/scripts/bolt_calculator.py`

#### 8种校核场景
1. 普通螺栓 - 拉伸强度
2. 普通螺栓 - 拉伸+扭转复合
3. 铰制孔螺栓 - 剪切强度
4. 铰制孔螺栓 - 挤压强度
5. 预紧力计算
6. 扭矩系数计算
7. 高强度螺栓摩擦型
8. 高强度螺栓承压型

**使用示例**:
```
M16螺栓抗拉强度校核，拉力20kN
计算8.8级M20螺栓的预紧力
```

### 3. 截面强度校核 (Cross Section Strength)
**文件**: `{baseDir}/scripts/section_calculator.py`

#### 10种截面类型
- 矩形、空心矩形
- 圆形、空心圆
- 工字钢 (GB/T 706)
- H型钢
- 槽钢
- 角钢
- T型钢
- 自定义截面

#### 4种强度校核
- 拉伸/压缩强度
- 剪切强度
- 扭转强度
- 弯曲强度
- von Mises组合应力

**使用示例**:
```
计算200×200×8 H型钢的强度
校核矩形截面50×100mm的弯曲应力
```

### 4. 带传动设计 (Belt Drive)
**文件**: `{baseDir}/scripts/belt_calculator.py`

#### V带设计
- **选型**: Y、Z、A、B、C、D、E型
- **功率曲线**: P0双线性插值
- **带轮参数**: 基准直径、槽型尺寸
- **校核计算**: 包角、带数、中心距

**使用示例**:
```
设计功率7.5kW、转速1450rpm的A型V带传动
查询A型V带P0功率表
```

### 5. 链传动设计 (Chain Drive)
**文件**: `{baseDir}/scripts/chain_calculator.py`, `{baseDir}/scripts/silent_chain_calculator.py`

#### 滚子链选型
- **系列**: A系列、B系列
- **规格**: 06B、08B、10A、12A等
- **链轮参数**: 齿数、节距、直径
  - 奇数齿公式
  - 偶数齿公式
- **功率计算**: 输送辊道功率

#### 齿形链选型 (Silent Chain)
- **链号**: CL06、CL08、CL10、CL12等
- **链宽**: 多规格可选
- **链轮参数**: 分度圆、齿顶圆、量柱测量距
- **特点**: 传动平稳、噪音低

**使用示例**:
```
选型10kW、转速960rpm的滚子链
计算20齿A系列链轮的几何参数
选型滚子链传动7.5kW、转速720rpm
查询CL12齿形链参数
计算齿形链轮21齿的几何参数
```

### 6. 螺旋传动 (Screw Drive)
**文件**: `{baseDir}/scripts/screw_calculator.py`

#### 螺纹计算
- **螺纹类型**: M、Tr、S系列
- **强度校核**: 拉伸、剪切、挤压
- **扭矩计算**: 驱动扭矩、效率
- **功率计算**: 推力、速度、功率
- **速查表**: 标准参数查询

**使用示例**:
```
Tr40×7螺旋传动的驱动扭矩计算
校核M20螺栓的螺纹强度
```

### 7. 轴承计算 (Bearing Calculation)
**文件**: `{baseDir}/scripts/bearing_calculator.py`, `{baseDir}/data/bearings.json`

#### 8种轴承类型 (596规格)
- 深沟球轴承 — 115规格 (GB/T 276-2013)
- 角接触球轴承 — 51规格 (GB/T 292-2007)
- 调心球轴承 — 37规格 (GB/T 281-2013)
- 圆柱滚子轴承 — 55规格 (GB/T 283-2007)
- 圆锥滚子轴承 — 70规格 (GB/T 297-2015)
- 推力球轴承 — 55规格 (GB/T 301-1995)
- 滚针轴承 — 158规格 (GB/T 5801-2006)
- 调心滚子轴承 — 55规格 (GB/T 288-2013)

#### 计算功能
- **寿命计算**: L10寿命、修正寿命(a1/a2/a3)
- **选型查询**: 按型号/内径/类型查询
- **游隙查询**: C2、CN、C3、C4游隙等级(含选型指南)
- **静强度校核**: 额定静载荷校核

**使用示例**:
```
计算6208轴承在径向力5000N下的寿命
查询NU2208轴承的尺寸参数
查询内径40mm的所有轴承规格
查询内径40mm的C3游隙范围
```

### 8. 联轴器选型 (Coupling Selection)
**文件**: `{baseDir}/scripts/coupling_calculator.py`

#### 联轴器类型
- **LX型**: 弹性柱销联轴器
- **SWC型**: 十字轴万向联轴器
- **伺服联轴器**: 高精密型

#### 计算功能
- **工况系数**: KA系数查询
- **扭矩计算**: 计算扭矩、选型扭矩
- **规格选型**: 根据参数自动匹配

**使用示例**:
```
选型传递扭矩500N·m的弹性柱销联轴器
计算SWC100万向联轴器的承载能力
```

### 9. 气缸计算 (Cylinder Calculation)
**文件**: `{baseDir}/scripts/cylinder_calculator.py`

#### SC系列气缸
- **缸径**: 32、40、50、63、80、100、125mm
- **推力计算**: 推出力、拉回力
- **耗气量**: 单程耗气量、每分钟耗气量
- **电磁阀选型**: 配管口径推荐

**使用示例**:
```
计算SC63×200气缸的推力和拉力
SC80气缸每分钟空气消耗量是多少
```

### 10. 材料数据库 (Material Database)
**文件**: `{baseDir}/data/materials.json`

#### 154种材料数据
- **黑色金属**: 碳素结构钢、合金钢、不锈钢
- **有色金属**: 铜合金、铝合金
- **非金属**: 工程塑料、橡胶、复合材料

#### 材料参数
- 弹性模量 E
- 泊松比 ν
- 密度 ρ
- 屈服强度 σs
- 抗拉强度 σb
- 硬度 HB/HRC

**使用示例**:
```
查询45号钢的材料参数
推荐用于齿轮材料的合金钢
```

### 11. 挠度计算 (Deflection Calculation)
**文件**: `{baseDir}/scripts/deflection_calculator.py`

#### 5种支承条件
- 简支梁
- 悬臂梁
- 两端固定梁
- 一端固定一端简支
- 连续梁

#### 6种载荷类型
- 集中力
- 均布载荷
- 三角形载荷
- 集中力偶
- 多载荷叠加
- 自定义载荷

**使用示例**:
```
计算简支梁在跨中集中力作用下的挠度
悬臂梁自由端受均布载荷的挠度计算
```

### 12. 硬度换算 (Hardness Conversion)
**文件**: `{baseDir}/scripts/hardness_converter.py`

#### 换算类型
- 布氏硬度 (HB)
- 洛氏硬度 (HRA、HRB、HRC)
- 维氏硬度 (HV)
- 肖氏硬度 (HS)

**使用示例**:
```
HRC30换算成HB是多少
HV300相当于多少HRC
```

### 13. 公差配合查询 (Tolerance and Fit)
**文件**: `{baseDir}/scripts/tolerance_fit_calculator.py`

#### 公差等级查询
- **ISO公差等级**: IT01~IT18共20个等级
- **标准公差计算**: 根据基本尺寸和等级自动计算
- **适用标准**: GB/T 1800.1、GB/T 1801

#### 基本偏差查询
- **轴偏差**: c, d, e, f, g, h, js, k, m, n, p, r, s, t, u
- **孔偏差**: C, D, E, F, G, H, JS, K, M, N, P, R, S
- **偏差值计算**: 根据基本尺寸和偏差代号查询

#### 配合类型
- **间隙配合**: H7/g6, H7/f7, H8/f8等
- **过渡配合**: H7/k6, H7/m6, H7/n6等
- **过盈配合**: H7/p6, H7/r6, H7/s6等

#### 配合推荐
- **滚动轴承配合**: 内圈k6/外圈H7
- **齿轮配合**: 推荐过盈配合
- **精密轴配合**: 推荐过渡配合

**使用示例**:
```
查询基本尺寸50mm、公差等级IT7的标准公差
查询轴偏差h7（基本尺寸30mm）
查询孔偏差H7（基本尺寸50mm）
计算配合H7/g6的间隙范围
推荐滚动轴承的配合
```

### 14. 键连接计算 (Key Connection)
**文件**: `{baseDir}/scripts/key_calculator.py`

#### 功能
- **平键强度校核**: 挤压、剪切强度
- **楔键强度校核**: 预紧力、摩擦力
- **花键计算**: 渐开线花键承载能力
- **键槽尺寸查询**: GB/T 1095、GB/T 1096

**使用示例**:
```
校核键12×8×50的强度
计算花键连接的承载能力
```

### 15. 轴强度计算 (Shaft Calculation)
**文件**: `{baseDir}/scripts/shaft_calculator.py`

#### 功能
- **结构参数**: 轴径、轴肩、过渡圆角
- **强度校核**: 按第三/第四强度理论
- **刚度计算**: 挠度、转角、临界转速
- **疲劳强度**: 无限寿命、有限寿命设计

**使用示例**:
```
计算轴的疲劳强度
校核轴的刚度
```

### 16. 弹簧计算 (Spring Calculation)
**文件**: `{baseDir}/scripts/spring_calculator.py`

#### 功能
- **圆柱螺旋弹簧**: 压缩、拉伸、扭转
- **弹簧参数**: 刚度、变形、应力
- **稳定性校核**: 长细比、失稳临界载荷
- **疲劳强度**: S-N曲线、无限寿命

**使用示例**:
```
设计圆柱压缩弹簧
计算弹簧的疲劳寿命
```

### 17. 螺纹规格查询 (Thread Specification)
**文件**: `{baseDir}/scripts/bearing_calculator.py` (ThreadDatabase类), `{baseDir}/data/threads.json`

#### 公制普通螺纹 (GB/T 196)
- 22种规格: M1~M48
- 参数: 螺距、中径d2、小径d1、钻孔直径
- 示例: M10×1.5 → d2=9.026, d1=8.376, drill=8.5

#### 管螺纹 (GB/T 7307)
- 9种规格: G1/8"~G2"
- 参数: 外径、螺距、每英寸牙数(TPI)

#### 螺栓推荐场景
- 法兰盘连接螺栓推荐
- 电机安装螺栓推荐
- 轴承端盖螺栓推荐

**使用示例**:
```
查询M10螺纹的中径和小径
查询G1/2管螺纹的参数
推荐法兰连接螺栓规格
```

## 🚀 使用方法

### 方式1: 直接调用Python脚本

```bash
# 齿轮计算
python {baseDir}/scripts/gear_calculator.py --type bevel --module 3 --teeth 20

# 螺栓校核
python {baseDir}/scripts/bolt_calculator.py --grade 8.8 --diameter M16 --force 20000

# 轴承寿命
python {baseDir}/scripts/bearing_calculator.py --model 6208 --Fr 5000 --life
```

### 方式2: Python API调用

```python
from scripts.gear_calculator import BevelGear
from scripts.bolt_calculator import BoltStrength
from scripts.bearing_calculator import BearingLife

# 锥齿轮计算
gear = BevelGear(module=3, teeth=20, pressure_angle=20)
result = gear.calculate_geometry()

# 螺栓校核
bolt = BoltStrength(grade='8.8', diameter='M16')
result = bolt.check_tension(force=20000)

# 轴承寿命
bearing = BearingLife(model='6208', Fr=5000, Fa=2000)
life = bearing.calculate_life()
```

### 方式3: 自然语言交互

直接向AI提问，AI会自动选择合适的计算引擎：

```
"帮我设计一个功率5.5kW、转速1450rpm的V带传动"
"M20的8.8级螺栓能承受多大的拉力？"
"查询6208轴承的外形尺寸"
"计算工字钢200×100×7×11的截面惯性矩"
```

## 📊 计算精度

- **公式标准**: 采用GB国家标准、ISO国际标准
- **材料数据**: 基于真实材料手册
- **公差等级**: IT01~IT18共20个等级
- **数值精度**: 保留4位有效数字

## 🔧 依赖要求

- Python 3.8+
- NumPy (用于矩阵运算)
- JSON (数据文件解析)

## 📝 数据文件

所有数据文件位于 `{baseDir}/data/` 目录：

- `materials.json` - 154种材料数据库
- `bearings.json` - 596种轴承规格(8类型) + 游隙数据 + 可靠度系数
- `threads.json` - 22种公制螺纹 + 9种管螺纹 + 螺栓场景推荐

## ⚠️ 注意事项

1. **安全系数**: 所有强度计算均需考虑安全系数，本SKILL提供的是理论计算值
2. **工况条件**: 实际工况可能超出标准适用范围，需人工判断
3. **材料离散性**: 材料性能存在离散性，计算结果为名义值
4. **标准更新**: 关注相关标准的最新版本

## 📚 参考标准

- GB/T 10062 锥齿轮强度计算
- GB/T 3077 合金结构钢
- GB/T 5780 六角头螺栓
- GB/T 276 深沟球轴承
- GB/T 706 热轧型钢
- ISO 6336 齿轮强度计算
- DIN 3965 锥齿轮公差

## 🎉 示例对话

**用户**: "我要设计一个锥齿轮传动，模数3，小齿轮20齿，大齿轮40齿，传递功率7.5kW，转速1450rpm，帮我计算几何参数并校核强度"

**AI响应**:
```
我将使用机械设计工具箱帮您计算锥齿轮传动。

【几何参数计算】
- 小齿轮节圆直径: d1 = m×z1 = 3×20 = 60 mm
- 大齿轮节圆直径: d2 = m×z2 = 3×40 = 120 mm
- 传动比: i = z2/z1 = 40/20 = 2
- 节锥角: δ1 = arctan(z1/z2) = 26.565°
- 顶锥角: δa1 = δ1 + arctan(ha*/R) = ...

【强度校核】
- 小齿轮扭矩: T1 = 9550×P/n1 = 49.3 N·m
- 接触应力: σH = ZE×√(FH×KT/(bd12)×(u+1)/u) = ...
- 弯曲应力: σF = (FE×KT)/(b×m×Y) = ...
- 结论: 强度满足要求 ✓

需要我提供详细计算过程吗？
```

---

## 📄 版本信息

- **版本**: 2.0.0
- **更新日期**: 2026-04
- **作者**: MechaBao Team
- **许可**: MIT License

## 🔗 相关链接

- GitHub: https://github.com/mechabao/mechanical-design-toolkit
- ClawHub: https://clawhub.ai/skills/mechanical-design-toolkit
- 问题反馈: https://github.com/mechabao/mechanical-design-toolkit/issues
