# 机械设计工具箱 (Mechanical Design Toolkit)

> ⚙️ 专业的机械设计计算引擎，涵盖齿轮、螺栓、轴承、传动、材料等10+功能模块

[![ClawHub](https://img.shields.io/badge/ClawHub-available-blue)](https://clawhub.ai)
[![License: MIT](https://img.shields.io/badge/License-MIT-green.svg)](https://opensource.org/licenses/MIT)
[![Python 3.8+](https://img.shields.io/badge/Python-3.8+-blue.svg)](https://www.python.org/downloads/)

## 📊 功能概览

本SKILL包含**12大功能模块**，覆盖机械设计核心计算需求：

| 模块 | 功能 | 标准 |
|------|------|------|
| 🦷 齿轮计算 | 锥齿轮几何/公差/强度 | GB/T 10062, GB/T 11365 |
| 🔩 螺栓强度 | 8种校核场景 | GB/T 5780, GB/T 3098.1 |
| 📐 截面强度 | 10种截面类型 | GB/T 706, 材料力学 |
| 🎯 带传动 | V带选型设计 | GB/T 11544 |
| ⛓️ 链传动 | 滚子链选型 | GB/T 1243 |
| 🌀 螺旋传动 | 螺纹强度/扭矩/效率 | GB/T 5796 |
| 🎪 轴承计算 | 8种轴承寿命/选型 | GB/T 276, ISO 281 |
| 🔗 联轴器 | LX/SWC选型 | GB/T 3852 |
| 🎈 气缸计算 | SC系列参数/推力 | JB/T 6440 |
| 🧪 材料数据库 | 154种材料参数 | GB/T 3077, GB/T 699 |
| 📉 挠度计算 | 5种支承/6种载荷 | 材料力学 |
| 🔧 硬度换算 | HB/HR/HV/HS互换 | GB/T 1172 |

## 🚀 快速开始

### 安装SKILL

```bash
# 方式1：从ClawHub安装（推荐）
openclaw skills install mechanical-design-toolkit

# 方式2：手动安装
git clone https://github.com/mechabao/mechanical-design-toolkit.git
cp -r mechanical-design-toolkit ~/.openclaw/skills/mechanical-design-toolkit
```

### 使用示例

启动OpenClaw后，直接向AI提问：

```
用户: 帮我计算M16、8.8级螺栓的拉伸强度，拉力50kN

AI: 我将使用机械设计工具箱进行计算...

【螺栓参数】
- 性能等级: 8.8
- 屈服强度: 640 MPa
- 应力截面积: 157 mm²

【强度校核】
- 拉应力: σ = F/A = 50000/157 = 318.5 MPa
- 许用应力: [σ] = σs/1.5 = 426.7 MPa
- 安全系数: S = [σ]/σ = 1.34
- 结论: ✓ 强度满足要求
```

## 📦 安装要求

### 系统要求
- Python 3.8+
- NumPy (可选，用于高级计算)

### 依赖安装

```bash
# 自动安装（推荐）
openclaw agent --message "安装机械设计工具箱的依赖"

# 手动安装
pip install numpy
```

## 📚 详细文档

### 1. 齿轮计算

```python
from scripts.gear_calculator import BevelGear

# 创建锥齿轮
gear = BevelGear(module=3, teeth=20, pressure_angle=20)

# 几何计算
geometry = gear.calculate_geometry()
print(geometry)

# 强度校核
result = gear.check_contact_strength(
    torque=500, pinion_teeth=20, gear_teeth=40
)
print(result)
```

### 2. 螺栓强度校核

```python
from scripts.bolt_calculator import BoltStrength

# 创建螺栓
bolt = BoltStrength(grade='8.8', diameter='M16')

# 拉伸强度校核
result = bolt.check_tension(force=50000, safety_factor=1.5)
print(result)

# 预紧力计算
preload = bolt.calculate_preload(torque=150)
print(preload)
```

### 3. 截面强度校核

```python
from scripts.section_calculator import CrossSection, StrengthCheck

# 创建H型钢截面
section = CrossSection('h_beam', {'h': 200, 'b': 200, 'tw': 8, 'tf': 12})

# 计算几何特性
props = section.calculate_properties()
print(props)

# 强度校核
material = {'E': 210000, 'sigma_s': 235, 'tau_s': 140}
checker = StrengthCheck(section, material)
result = checker.check_bending(moment=50000*1000, axis='x')
print(result)
```

### 4. 轴承寿命计算

```python
from scripts.bearing_calculator import BearingLife

# 创建轴承
bearing = BearingLife(model='6208', bearing_type='deep_groove')

# 寿命计算
life = bearing.calculate_life(Fr=5000, Fa=2000, speed=1500)
print(life)
```

## 📁 文件结构

```
mechanical-design-toolkit/
├── SKILL.md              # SKILL主文档（必需）
├── README.md             # 本文件
├── LICENSE               # MIT许可
├── scripts/              # 计算引擎
│   ├── gear_calculator.py
│   ├── bolt_calculator.py
│   ├── section_calculator.py
│   ├── bearing_calculator.py
│   ├── belt_calculator.py
│   ├── chain_calculator.py
│   ├── screw_calculator.py
│   ├── coupling_calculator.py
│   ├── cylinder_calculator.py
│   ├── deflection_calculator.py
│   └── hardness_converter.py
├── data/                 # 数据库
│   ├── materials.json    # 154种材料
│   ├── bearing_db.json  # 轴承数据库
│   ├── belt_p0_table.json
│   ├── chain_data.json
│   └── section_db.json
└── examples/            # 使用示例
    ├── gear_example.py
    ├── bolt_example.py
    └── ...
```

## 🎯 适用场景

### 工程设计
- 机械零件强度校核
- 传动系统参数设计
- 材料选型
- 公差查询

### 教学科研
- 机械设计课程作业
- 工程设计训练
- 计算方法验证

### 技术支持
- 快速方案估算
- 设计参数查询
- 标准规范参考

## ⚠️ 免责声明

1. **计算精度**: 本SKILL提供的计算结果仅供参考，实际工程应用需结合专业软件和工程师判断
2. **安全系数**: 所有强度计算必须考虑适当的安全系数，本SKILL默认值为1.5
3. **标准更新**: 请关注相关国家标准和国际标准的更新
4. **工况适用**: 实际工况可能超出标准适用范围，需人工判断

## 🤝 贡献指南

欢迎贡献代码、报告Bug、提出新功能建议！

### 开发环境搭建

```bash
git clone https://github.com/mechabao/mechanical-design-toolkit.git
cd mechanical-design-toolkit
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### 提交Pull Request

1. Fork本仓库
2. 创建特性分支 (`git checkout -b feature/AmazingFeature`)
3. 提交更改 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 提交Pull Request

## 📝 更新日志

### v2.0.0 (2026-04)
- ✨ 新增6个功能模块（链传动、带传动、螺旋传动、联轴器、气缸、截面强度）
- 📊 材料数据库从154种扩充到182种
- 🐛 修复已知问题
- 📚 更新文档

### v1.0.0 (2026-03)
- 🎉 首次发布
- ✨ 初始功能：齿轮、螺栓、轴承、材料查询

## 📧 联系方式

- 作者: MechaBao Team
- Email: mechabao@example.com
- GitHub: https://github.com/mechabao/mechanical-design-toolkit
- ClawHub: https://clawhub.ai/skills/mechanical-design-toolkit

## 📄 许可证

本项目采用MIT许可证 - 详情见 [LICENSE](LICENSE) 文件

---

**⭐ 如果这个SKILL对您有帮助，请在ClawHub上给我们一个好评！**
