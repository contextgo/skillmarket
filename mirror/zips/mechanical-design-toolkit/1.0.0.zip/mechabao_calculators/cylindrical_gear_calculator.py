"""
圆柱齿轮计算引擎 - cylindrical_gear_calculator.py
GB/T 1356-2001, GB/T 10095.1-2022, GB/T 10095.2-2023
支持：几何计算、公差查询、强度校核、螺旋角反算
"""

import math
from .gear_tolerance import GearToleranceCalculator

# ==================== 材料性能表 ====================
MATERIALS = {
    1: {'name': '调质钢', 'sigma_Hlim': 500, 'sigma_Flim': 200, 'YST': 2.0},
    2: {'name': '渗碳淬火钢', 'sigma_Hlim': 1400, 'sigma_Flim': 450, 'YST': 2.0},
    3: {'name': '氮化钢', 'sigma_Hlim': 1100, 'sigma_Flim': 400, 'YST': 2.0},
    4: {'name': '灰铸铁', 'sigma_Hlim': 350, 'sigma_Flim': 100, 'YST': 2.0},
}

# ==================== 主计算类 ====================
class CylindricalGearCalculator:
    """圆柱齿轮计算"""

    def __init__(self):
        self.tolerance_calc = GearToleranceCalculator()

    # ==================== 几何计算 ====================
    def calculate_geometry(self, m, z1, z2, x1=0, x2=0, alpha=20, beta=0, b=20):
        """
        计算圆柱齿轮几何参数
        :param m: 法向模数 (mm)
        :param z1: 小齿轮齿数
        :param z2: 大齿轮齿数
        :param x1: 小齿轮变位系数
        :param x2: 大齿轮变位系数
        :param alpha: 法向压力角 (°)
        :param beta: 螺旋角 (°)
        :param b: 齿宽 (mm)
        :return: 几何参数dict
        """
        alpha_rad = math.radians(alpha)
        beta_rad = math.radians(beta)

        # 分度圆直径
        d1 = m * z1 / math.cos(beta_rad)
        d2 = m * z2 / math.cos(beta_rad)

        # 基圆直径
        db1 = d1 * math.cos(alpha_rad)
        db2 = d2 * math.cos(alpha_rad)

        # 齿顶圆直径（标准齿高）
        ha1 = m * (1 + x1)
        ha2 = m * (1 + x2)
        da1 = d1 + 2 * ha1
        da2 = d2 + 2 * ha2

        # 齿根圆直径
        hf1 = m * (1.25 - x1)
        hf2 = m * (1.25 - x2)
        df1 = d1 - 2 * hf1
        df2 = d2 - 2 * hf2

        # 中心距
        a = m * (z1 + z2) / (2 * math.cos(beta_rad))

        # 传动比
        i = z2 / z1

        # 端面模数
        mt = m / math.cos(beta_rad)

        # 当量齿数
        cos3_beta = math.pow(math.cos(beta_rad), 3)
        zd1 = z1 / cos3_beta if cos3_beta != 0 else z1
        zd2 = z2 / cos3_beta if cos3_beta != 0 else z2

        # 公法线长度
        def calc_W(z, mn, alpha_deg, x):
            alpha_rad = math.radians(alpha_deg)
            inv_alpha = math.tan(alpha_rad) - alpha_rad
            k = math.floor(z * alpha_deg / 180 + 0.5)
            k = max(k, 2)
            zd = z / (math.cos(math.radians(beta)) ** 3) if beta != 0 else z
            W = mn * math.cos(alpha_rad) * (math.pi * (k - 0.5) + zd * inv_alpha)
            return round(W, 3), k

        W1, k1 = calc_W(z1, m, alpha, x1)
        W2, k2 = calc_W(z2, m, alpha, x2)

        return {
            'd1': round(d1, 2), 'd2': round(d2, 2),
            'db1': round(db1, 2), 'db2': round(db2, 2),
            'da1': round(da1, 2), 'da2': round(da2, 2),
            'df1': round(df1, 2), 'df2': round(df2, 2),
            'ha1': round(ha1, 2), 'ha2': round(ha2, 2),
            'hf1': round(hf1, 2), 'hf2': round(hf2, 2),
            'a': round(a, 2), 'i': round(i, 3),
            'mt': round(mt, 3),
            'W1': W1, 'k1': k1, 'W2': W2, 'k2': k2,
            'zd1': round(zd1, 1), 'zd2': round(zd2, 1),
        }

    # ==================== 强度校核 (GB/T 3480) ====================
    def calculate_strength(self, P, n1, mn, alpha_n, beta, b, z1, z2, x1, x2,
                           grade=7, mat1=2, mat2=2, hard1=55, hard2=55,
                           support=1, driver=1, driven=1, Lh=10000):
        """
        齿轮强度校核 (GB/T 3480)
        :param P: 传递功率 (kW)
        :param n1: 小齿轮转速 (r/min)
        :param mn: 法向模数 (mm)
        :param alpha_n: 法向压力角 (°)
        :param beta: 螺旋角 (°)
        :param b: 齿宽 (mm)
        :param z1: 小齿轮齿数
        :param z2: 大齿轮齿数
        :param x1: 小齿轮变位系数
        :param x2: 大齿轮变位系数
        :param grade: 精度等级 (1-12)
        :param mat1: 小齿轮材料类型 (1-4)
        :param mat2: 大齿轮材料类型 (1-4)
        :param hard1: 小齿轮硬度 (HB或HRC)
        :param hard2: 大齿轮硬度 (HB或HRC)
        :param support: 支承方式 (1-对称,2-非对称,3-悬臂)
        :param driver: 原动机类型 (1-均匀,2-轻微振动,3-中等振动)
        :param driven: 工作机特性 (1-均匀,2-轻微冲击,3-中等冲击,4-严重冲击)
        :param Lh: 预期寿命 (h)
        :return: 强度校核结果dict
        """
        beta_rad = math.radians(beta)
        alpha_n_rad = math.radians(alpha_n)

        # 端面压力角
        alpha_t = math.atan(math.tan(alpha_n_rad) / math.cos(beta_rad))
        alpha_t_deg = math.degrees(alpha_t)

        # 传动比
        u = z2 / z1

        # 扭矩
        T1 = 9550 * P / n1  # N·m

        # 标准中心距和实际中心距
        a0 = mn * (z1 + z2) / (2 * math.cos(beta_rad))

        # 啮合角
        alpha_t_prime = alpha_t  # 标准中心距时
        y = 0  # 中心距变动系数
        delta_y = 0  # 齿顶高变动系数

        # 分度圆直径
        d1 = mn * z1 / math.cos(beta_rad)
        d2 = mn * z2 / math.cos(beta_rad)

        # 齿顶圆直径
        ha_star = 1.0
        c_star = 0.25
        da1 = d1 + 2 * (ha_star + x1 - delta_y) * mn
        da2 = d2 + 2 * (ha_star + x2 - delta_y) * mn

        # 圆周速度
        v = math.pi * d1 * n1 / 60000.0  # m/s

        # 圆周力
        Ft = 2000 * T1 / d1  # N

        # ==================== 载荷系数 ====================
        # 使用系数 KA
        KA_table = {
            (1, 1): 1.00, (1, 2): 1.25, (1, 3): 1.50, (1, 4): 1.75,
            (2, 1): 1.10, (2, 2): 1.35, (2, 3): 1.60, (2, 4): 1.85,
            (3, 1): 1.25, (3, 2): 1.50, (3, 3): 1.75, (3, 4): 2.00
        }
        KA = KA_table.get((driver, driven), 1.25)

        # 动载系数 KV
        vz = v * z1 / 100
        if grade <= 7:
            if beta == 0:
                if v <= 3: KV = 1.05 + vz * 0.01
                elif v <= 8: KV = 1.10 + vz * 0.01
                elif v <= 12: KV = 1.15 + vz * 0.01
                else: KV = 1.25 + vz * 0.02
            else:
                if v <= 3: KV = 1.03 + vz * 0.005
                elif v <= 8: KV = 1.06 + vz * 0.005
                elif v <= 12: KV = 1.10 + vz * 0.005
                else: KV = 1.15 + vz * 0.01
        else:
            if beta == 0:
                if v <= 3: KV = 1.10 + vz * 0.02
                elif v <= 8: KV = 1.15 + vz * 0.02
                elif v <= 12: KV = 1.25 + vz * 0.03
                else: KV = 1.40 + vz * 0.04
            else:
                KV = 1.1 + vz * 0.02

        # 齿向载荷分布系数 KHβ
        phi_d = b / d1
        if support == 1:
            if phi_d <= 0.4: KHbeta = 1.05
            elif phi_d <= 0.6: KHbeta = 1.07
            elif phi_d <= 0.8: KHbeta = 1.10
            elif phi_d <= 1.0: KHbeta = 1.13
            elif phi_d <= 1.2: KHbeta = 1.17
            else: KHbeta = 1.22
        elif support == 2:
            if phi_d <= 0.4: KHbeta = 1.08
            elif phi_d <= 0.6: KHbeta = 1.12
            elif phi_d <= 0.8: KHbeta = 1.17
            elif phi_d <= 1.0: KHbeta = 1.23
            elif phi_d <= 1.2: KHbeta = 1.30
            else: KHbeta = 1.38
        else:
            if phi_d <= 0.4: KHbeta = 1.15
            elif phi_d <= 0.6: KHbeta = 1.25
            elif phi_d <= 0.8: KHbeta = 1.40
            elif phi_d <= 1.0: KHbeta = 1.60
            else: KHbeta = 1.80

        # 重合度
        alpha_a1 = math.acos(d1 * math.cos(alpha_t) / da1)
        alpha_a2 = math.acos(d2 * math.cos(alpha_t) / da2)
        eps_alpha = (z1 * (math.tan(alpha_a1) - math.tan(alpha_t)) +
                     z2 * (math.tan(alpha_a2) - math.tan(alpha_t))) / (2 * math.pi)
        eps_beta = b * math.sin(beta_rad) / (math.pi * mn)
        eps_gamma = eps_alpha + eps_beta if beta != 0 else eps_alpha

        # 齿间载荷分配系数
        hardened = (2 <= mat1 <= 3) or (2 <= mat2 <= 3)
        if grade <= 6:
            KHalpha = 1.0
        elif grade == 7:
            KHalpha = 1.05 if hardened else 1.0
        else:
            KHalpha = 1.15 if hardened else 1.1
        KFalpha = KHalpha

        K_H = KA * KV * KHbeta * KHalpha
        K_F = KA * KV * KHbeta * KFalpha

        # ==================== 接触强度 ====================
        beta_b = math.atan(math.tan(beta_rad) * math.cos(alpha_t))
        ZH = math.sqrt(2 * math.cos(beta_b) /
                        (math.cos(alpha_t) ** 2 * math.tan(alpha_t)))
        ZE = 189.8  # 钢-钢
        Z_eps = math.sqrt((4 - eps_alpha) / 3) if beta == 0 else (
            math.sqrt((4 - eps_alpha) / 3 * (1 - min(eps_beta, 1)) + min(eps_beta, 1) / eps_alpha)
            if eps_beta < 1 else math.sqrt(1 / eps_alpha)
        )
        Z_beta = math.sqrt(math.cos(beta_rad))

        sigma_H = ZH * ZE * Z_eps * Z_beta * math.sqrt(Ft / (b * d1) * (u + 1) / u * K_H)

        # 材料极限应力
        def get_sigma_Hlim(m, hb):
            if m == 1: return (hb - 180) * (200 / 100) + 500 if hb <= 280 else 700
            if m == 2: return 1400
            if m == 3: return 1100
            if m == 4: return 350
            return 1000

        sigma_Hlim1 = get_sigma_Hlim(mat1, hard1)
        sigma_Hlim2 = get_sigma_Hlim(mat2, hard2)

        # 寿命系数 ZNT
        def get_ZNT(NL, m):
            if m == 1:
                points = [(1e5, 1.5), (1e6, 1.3), (1e7, 1.1), (1e8, 1.0), (1e9, 0.95)]
            elif m in [2, 3]:
                points = [(1e5, 1.3), (1e6, 1.2), (1e7, 1.1), (1e8, 1.0), (1e9, 0.9)]
            else:
                return 1.0
            if NL <= points[0][0]: return points[0][1]
            for i in range(len(points) - 1):
                if points[i][0] <= NL <= points[i + 1][0]:
                    return points[i][1] + (points[i + 1][1] - points[i][1]) * \
                           (NL - points[i][0]) / (points[i + 1][0] - points[i][0])
            return points[-1][1]

        NL1 = 60 * n1 * Lh
        NL2 = NL1 / u
        ZNT1 = get_ZNT(NL1, mat1)
        ZNT2 = get_ZNT(NL2, mat2)

        SH_min = 1.1
        sigma_HP1 = sigma_Hlim1 * ZNT1 / SH_min
        sigma_HP2 = sigma_Hlim2 * ZNT2 / SH_min
        sigma_HP = min(sigma_HP1, sigma_HP2)
        SH = sigma_HP / sigma_H

        # ==================== 弯曲强度 ====================
        cos3_beta = math.pow(math.cos(beta_rad), 3)
        zv1 = z1 / cos3_beta if cos3_beta != 0 else z1
        zv2 = z2 / cos3_beta if cos3_beta != 0 else z2

        # 齿形系数 YFa
        def get_YFa(zv):
            data = {17: 2.97, 20: 2.80, 25: 2.62, 30: 2.52, 40: 2.40,
                     50: 2.33, 60: 2.28, 80: 2.22, 100: 2.18, 200: 2.12}
            keys = sorted(data.keys())
            if zv <= keys[0]: return data[keys[0]]
            if zv >= keys[-1]: return data[keys[-1]]
            for i in range(len(keys) - 1):
                if keys[i] <= zv <= keys[i + 1]:
                    return data[keys[i]] + (data[keys[i + 1]] - data[keys[i]]) * \
                           (zv - keys[i]) / (keys[i + 1] - keys[i])
            return 2.2

        # 应力修正系数 YSa
        def get_YSa(zv):
            data = {17: 1.52, 20: 1.55, 25: 1.59, 30: 1.625, 40: 1.67,
                     50: 1.70, 60: 1.73, 80: 1.78, 100: 1.80, 200: 1.86}
            keys = sorted(data.keys())
            if zv <= keys[0]: return data[keys[0]]
            if zv >= keys[-1]: return data[keys[-1]]
            for i in range(len(keys) - 1):
                if keys[i] <= zv <= keys[i + 1]:
                    return data[keys[i]] + (data[keys[i + 1]] - data[keys[i]]) * \
                           (zv - keys[i]) / (keys[i + 1] - keys[i])
            return 1.7

        YFa1, YFa2 = get_YFa(zv1), get_YFa(zv2)
        YSa1, YSa2 = get_YSa(zv1), get_YSa(zv2)

        eps_alpha_n = eps_alpha / (math.cos(beta_b) ** 2) if math.cos(beta_b) != 0 else eps_alpha
        Y_eps = 0.25 + 0.75 / eps_alpha_n

        if beta == 0:
            Y_beta = 1.0
        else:
            e_b = min(eps_beta, 1.0)
            Y_beta = 1 - e_b * beta / 120

        sigma_F1 = Ft / (b * mn) * YFa1 * YSa1 * Y_eps * Y_beta * K_F
        sigma_F2 = Ft / (b * mn) * YFa2 * YSa2 * Y_eps * Y_beta * K_F

        # 弯曲极限应力
        def get_sigma_Flim(m, hb):
            if m == 1: return 200 + (hb - 180) * (150 / 100)
            if m == 2: return 450
            if m == 3: return 400
            if m == 4: return 100
            return 300

        sigma_Flim1 = get_sigma_Flim(mat1, hard1)
        sigma_Flim2 = get_sigma_Flim(mat2, hard2)

        # 弯曲寿命系数 YNT
        def get_YNT(NL, m):
            if m == 1:
                points = [(1e4, 2.5), (1e5, 1.8), (1e6, 1.4), (1e7, 1.1), (1e8, 1.0)]
            elif m == 2:
                points = [(1e4, 2.5), (1e5, 1.7), (1e6, 1.4), (1e7, 1.1), (1e8, 0.95)]
            elif m == 3:
                points = [(1e4, 2.2), (1e5, 1.6), (1e6, 1.3), (1e7, 1.1), (1e8, 1.0)]
            else:
                return 1.0
            if NL <= points[0][0]: return points[0][1]
            for i in range(len(points) - 1):
                if points[i][0] <= NL <= points[i + 1][0]:
                    return points[i][1] + (points[i + 1][1] - points[i][1]) * \
                           (NL - points[i][0]) / (points[i + 1][0] - points[i][0])
            return points[-1][1]

        YST = 2.0
        YNT1 = get_YNT(NL1, mat1)
        YNT2 = get_YNT(NL2, mat2)
        SF_min = 1.4
        sigma_FP1 = sigma_Flim1 * YST * YNT1 / SF_min
        sigma_FP2 = sigma_Flim2 * YST * YNT2 / SF_min
        SF1 = sigma_FP1 / sigma_F1
        SF2 = sigma_FP2 / sigma_F2

        checkH = '✅ 通过' if SH >= SH_min else '❌ 不足'
        checkF1 = '✅ 通过' if SF1 >= SF_min else '❌ 不足'
        checkF2 = '✅ 通过' if SF2 >= SF_min else '❌ 不足'

        return {
            'a0': round(a0, 3), 'a': round(a0, 3),
            'd1': round(d1, 3), 'd2': round(d2, 3),
            'da1': round(da1, 3), 'da2': round(da2, 3),
            'v': round(v, 3), 'Ft': round(Ft, 1), 'u': round(u, 3),
            'eps_alpha': round(eps_alpha, 3), 'eps_beta': round(eps_beta, 3),
            'KA': round(KA, 3), 'KV': round(KV, 3),
            'KHbeta': round(KHbeta, 3), 'KHalpha': round(KHalpha, 3),
            'K_H': round(K_H, 3), 'K_F': round(K_F, 3),
            'Z_sum': round(ZH * ZE * Z_eps * Z_beta, 3),
            'sigma_H': round(sigma_H, 2),
            'sigma_HP': round(sigma_HP, 2),
            'SH': round(SH, 3), 'SH_min': SH_min, 'checkH': checkH,
            'YFa1': round(YFa1, 3), 'YSa1': round(YSa1, 3),
            'YFa2': round(YFa2, 3), 'YSa2': round(YSa2, 3),
            'sigma_F1': round(sigma_F1, 2), 'sigma_F2': round(sigma_F2, 2),
            'sigma_FP1': round(sigma_FP1, 2), 'sigma_FP2': round(sigma_FP2, 2),
            'SF1': round(SF1, 3), 'SF2': round(SF2, 3),
            'SF_min': SF_min,
            'checkF1': checkF1, 'checkF2': checkF2,
            'sigma_Hlim1': sigma_Hlim1, 'sigma_Hlim2': sigma_Hlim2,
            'sigma_Flim1': sigma_Flim1, 'sigma_Flim2': sigma_Flim2,
        }

    # ==================== 反算螺旋角 ====================
    def reverse_beta(self, m, z1, z2, a_target):
        """
        通过目标中心距反算螺旋角
        :param m: 模数 (mm)
        :param z1: 小齿轮齿数
        :param z2: 大齿轮齿数
        :param a_target: 目标中心距 (mm)
        :return: 反算结果dict
        """
        cos_beta = m * (z1 + z2) / (2 * a_target)

        if cos_beta > 1 or cos_beta < 0:
            return {'error': f'中心距 {a_target}mm 对应的螺旋角超出范围（0°~30°）'}

        beta = math.degrees(math.acos(cos_beta))
        d1 = m * z1 / cos_beta
        d2 = m * z2 / cos_beta
        mt = m / cos_beta
        a_calc = (d1 + d2) / 2

        return {
            'a_target': a_target,
            'cosBeta': round(cos_beta, 5),
            'beta': round(beta, 2),
            'd1': round(d1, 2),
            'd2': round(d2, 2),
            'mt': round(mt, 3),
            'a_calc': round(a_calc, 2),
            'note': f'反算得到螺旋角 β = {round(beta, 2)}°'
        }


# ==================== 便捷函数 ====================
def calculate_gear_geometry(m, z1, z2, **kwargs):
    """便捷函数：计算齿轮几何参数"""
    calc = CylindricalGearCalculator()
    return calc.calculate_geometry(m, z1, z2, **kwargs)


def calculate_gear_strength(P, n1, mn, z1, z2, **kwargs):
    """便捷函数：齿轮强度校核"""
    calc = CylindricalGearCalculator()
    return calc.calculate_strength(P, n1, mn, 20, 0, 20, z1, z2, **kwargs)


if __name__ == '__main__':
    # 测试
    calc = CylindricalGearCalculator()

    # 几何计算
    geo = calc.calculate_geometry(m=3, z1=20, z2=60)
    print("几何计算结果:")
    for k, v in geo.items():
        print(f"  {k}: {v}")

    print("\n" + "=" * 50 + "\n")

    # 强度校核
    strength = calc.calculate_strength(P=5.5, n1=1450, mn=3, z1=20, z2=60)
    print("强度校核结果:")
    for k, v in strength.items():
        print(f"  {k}: {v}")
