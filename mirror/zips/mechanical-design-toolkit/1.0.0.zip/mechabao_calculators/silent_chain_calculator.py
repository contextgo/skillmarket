"""
齿形链(无声链)设计计算引擎 - silent_chain_calculator.py
《机械设计手册》(成大先主编)第5版 第14篇 链传动
GB/T 10855-2016 / ISO 15606:2002
支持：完整10步齿形链设计计算、额定功率P0查询与插值、链轮几何参数、润滑方式判定
"""

import math
from typing import Dict, List, Tuple, Optional, Any


# =================== 齿形链基本参数表（GB/T 10855-2016 表1）====================
CHAIN_SPECS = {
    'CL04': {
        'label': 'CL04', 'p': 4.762, 't': 0.8, 'h': 5.9,
        'massPerM': 0.18, 'Qmin': 3560,
        'widthSeries': [6, 8, 10, 12, 16, 20, 25, 32, 40],
        'plateSeries': [4, 5, 7, 9, 11, 14, 17, 22, 28],
        'desc': '极轻载高速精密', 'coeffGroup': 'cl04'
    },
    'CL06': {
        'label': 'CL06', 'p': 9.525, 't': 1.0, 'h': 8.3,
        'massPerM': 0.60, 'Qmin': 8000,
        'widthSeries': [13.5, 16.5, 19.5, 22.5, 28.5, 34.5, 40.5, 46.5, 52.5],
        'plateSeries': [9, 11, 13, 15, 19, 23, 27, 31, 35],
        'desc': '轻载高速精密', 'coeffGroup': 'general'
    },
    'CL08': {
        'label': 'CL08', 'p': 12.700, 't': 1.3, 'h': 11.0,
        'massPerM': 1.15, 'Qmin': 17800,
        'widthSeries': [19.5, 22.5, 25.5, 28.5, 34.5, 40.5, 46.5, 52.5, 58.5, 64.5, 70.5],
        'plateSeries': [13, 15, 17, 19, 23, 27, 31, 35, 39, 43, 47],
        'desc': '通用型最常用', 'coeffGroup': 'general'
    },
    'CL10': {
        'label': 'CL10', 'p': 15.875, 't': 1.5, 'h': 14.0,
        'massPerM': 2.21, 'Qmin': 22200,
        'widthSeries': [30, 38, 46, 54, 62, 70, 78],
        'plateSeries': [15, 19, 23, 27, 31, 35, 39],
        'desc': '中等载荷中速', 'coeffGroup': 'general'
    },
    'CL12': {
        'label': 'CL12', 'p': 19.050, 't': 1.8, 'h': 16.0,
        'massPerM': 3.37, 'Qmin': 28900,
        'widthSeries': [38, 46, 54, 62, 70, 78, 86, 94],
        'plateSeries': [19, 23, 27, 31, 35, 39, 43, 47],
        'desc': '中重载荷低速中速', 'coeffGroup': 'general'
    },
    'CL16': {
        'label': 'CL16', 'p': 25.400, 't': 2.4, 'h': 21.4,
        'massPerM': 5.31, 'Qmin': 42300,
        'widthSeries': [45, 51, 57, 69, 81, 93, 105, 117],
        'plateSeries': [15, 17, 19, 23, 27, 31, 35, 39],
        'desc': '重载低速', 'coeffGroup': 'general'
    },
    'CL20': {
        'label': 'CL20', 'p': 31.750, 't': 3.0, 'h': 26.8,
        'massPerM': 8.42, 'Qmin': 62300,
        'widthSeries': [57, 69, 81, 93, 105, 117, 129],
        'plateSeries': [19, 23, 27, 31, 35, 39, 43],
        'desc': '大功率重载', 'coeffGroup': 'general'
    },
    'CL24': {
        'label': 'CL24', 'p': 38.100, 't': 3.6, 'h': 32.2,
        'massPerM': 12.22, 'Qmin': 89100,
        'widthSeries': [69, 81, 93, 105, 117, 129, 141],
        'plateSeries': [23, 27, 31, 35, 39, 43, 47],
        'desc': '超重载极低速', 'coeffGroup': 'general'
    },
    'CL32': {
        'label': 'CL32', 'p': 50.800, 't': 4.8, 'h': 42.9,
        'massPerM': 11.00, 'Qmin': 158000,
        'widthSeries': [63, 80, 100, 125, 160, 200, 250, 315, 400, 500],
        'plateSeries': [5, 6, 8, 10, 13, 16, 21, 26, 33, 42],
        'desc': '超大功率超重载', 'coeffGroup': 'general'
    }
}


# =================== 工况系数 f₁ 表 ====================
F1_TABLE = [
    {'label': '均匀平稳', 'value': 1.0, 'desc': '离心泵、通风机、轻型输送机'},
    {'label': '轻微冲击', 'value': 1.25, 'desc': '往复泵、离心压缩机、木工机械'},
    {'label': '中等冲击', 'value': 1.5, 'desc': '往复压缩机、重型机床、建筑机械'},
    {'label': '严重冲击', 'value': 1.75, 'desc': '锻压机械、球磨机、破碎机'},
    {'label': '极端冲击', 'value': 2.0, 'desc': '矿山挖掘机、重型破碎机、冲压机'}
]

# =================== 布置系数 f₅ ====================
F5_TABLE = [
    {'label': '水平传动（松边在下）', 'value': 1.15},
    {'label': '水平传动（松边在上）', 'value': 1.20},
    {'label': '垂直传动', 'value': 1.25},
    {'label': '倾斜传动（α≤45°）', 'value': 1.20}
]

# =================== 齿形链设计计算类 ====================
class SilentChainCalculator:
    """齿形链设计计算"""

    def __init__(self):
        pass

    # =================== 小链轮齿数系数 Kz ===================
    @staticmethod
    def calc_Kz(z1: int) -> float:
        """Kz = (z1/19)^1.08"""
        return math.pow(max(z1, 15) / 19, 1.08)

    # =================== 润滑方式判定 ===================
    @staticmethod
    def get_lubrication(v: float) -> str:
        if v < 0.5:
            return '定期涂脂润滑'
        elif v < 1.5:
            return '定期人工润滑'
        elif v < 4.0:
            return '滴油润滑'
        elif v < 8.0:
            return '油浴润滑'
        elif v < 12.0:
            return '飞溅润滑'
        else:
            return '压力喷油润滑'

    # =================== 线性插值 ===================
    @staticmethod
    def interp_array(arr_x: List[float], arr_y: List[float], x: float) -> Optional[float]:
        """在有序数组中按x插值y"""
        if not arr_x or not arr_x:
            return None
        if x <= arr_x[0]:
            return arr_y[0] if arr_y[0] is not None else None
        last = len(arr_x) - 1
        if x >= arr_x[last]:
            return arr_y[last] if arr_y[last] is not None else None
        for i in range(last):
            if arr_x[i] <= x <= arr_x[i + 1]:
                if arr_y[i] is not None and arr_y[i + 1] is not None:
                    t = (x - arr_x[i]) / (arr_x[i + 1] - arr_x[i])
                    return arr_y[i] + t * (arr_y[i + 1] - arr_y[i])
        return None

    # =================== 查询额定功率 P0 ===================
    def query_P0_by_width(self, chain_type: str, z1: int, n1: float, width: float) -> Optional[float]:
        """
        查询额定功率 P0 = 表值(每mm) × 链宽b(mm)
        按z1和n1双线性插值
        """
        from .silent_chain_data import get_P0_table
        tbl = get_P0_table(chain_type)
        if not tbl:
            return None

        rpm_list = tbl['rpmList']
        data = sorted(tbl['data'], key=lambda x: x['z1'])

        # 找z1的上下界
        lo = data[0]
        hi = data[-1]
        for row in data:
            if row['z1'] <= z1 and row['z1'] >= lo.get('z1', 0):
                lo = row
            if row['z1'] >= z1 and row['z1'] <= hi.get('z1', 999):
                hi = row

        # 在每个行内按n1插值
        p0_lo = self.interp_array(rpm_list, lo['p0List'], n1)
        p0_hi = self.interp_array(rpm_list, hi['p0List'], n1)

        if p0_lo is None and p0_hi is None:
            return None

        # z1方向插值
        if p0_hi is None:
            p0_per_mm = p0_lo
        elif p0_lo is None:
            p0_per_mm = p0_hi
        elif lo['z1'] == hi['z1']:
            p0_per_mm = p0_lo
        else:
            tz = (z1 - lo['z1']) / (hi['z1'] - lo['z1'])
            p0_per_mm = p0_lo + tz * (p0_hi - p0_lo)

        if p0_per_mm is None or p0_per_mm < 0:
            return None

        return p0_per_mm * width  # 实际P0 = 每mm功率 × 链宽

    # =================== 自动选择链宽 ===================
    def select_width(self, chain_type: str, z1: int, n1: float, Pd: float) -> Dict:
        """根据设计功率Pd自动选择最小满足要求的链宽"""
        chain = CHAIN_SPECS.get(chain_type)
        if not chain:
            return {'error': '无效链条型号'}

        for b in chain['widthSeries']:
            P0 = self.query_P0_by_width(chain_type, z1, n1, b)
            if P0 is not None and P0 >= Pd:
                return {'b': b, 'P0': P0}

        # 无合适宽度时估算
        first_b = chain['widthSeries'][0]
        ref_P0 = self.query_P0_by_width(chain_type, z1, n1, first_b)
        if ref_P0 is None or ref_P0 <= 0:
            return {'b': first_b, 'P0': None, 'estimated': True}

        b_est = (Pd / ref_P0) * first_b
        best_b = min((b for b in chain['widthSeries'] if b >= b_est), default=chain['widthSeries'][-1])
        return {
            'b': best_b,
            'P0': self.query_P0_by_width(chain_type, z1, n1, best_b),
            'estimated': True
        }

    # =================== 计算链节数 ===================
    @staticmethod
    def calc_chain_length(z1: int, z2: int, a_mm: float, p: float) -> Dict:
        """计算链节数 X"""
        X0 = 2 * a_mm / p + (z1 + z2) / 2 + ((z2 - z1) ** 2) * p / (4 * math.pi ** 2 * a_mm)
        X = math.floor(X0 / 2) * 2 if X0 % 2 < 0.5 else math.ceil(X0 / 2) * 2
        return {
            'X0': round(X0, 2),
            'X': X,
            'L_mm': X * p,
            'L_m': X * p / 1000
        }

    # =================== 精确中心距 ===================
    @staticmethod
    def calc_exact_center(z1: int, z2: int, X: float, p: float, a_input_mm: float) -> Dict:
        """计算精确中心距"""
        e = X - (z1 + z2) / 2
        term = e * e - 2 * ((z2 - z1) / math.pi) ** 2
        a_theo = p / 4 * (e + math.sqrt(term)) if term >= 0 else a_input_mm

        delta_ratio = 0.004  # Δa取理论值的0.3%~0.5%
        Delta_a = a_theo * delta_ratio
        a_actual = a_theo - Delta_a

        return {
            'a_theoretical': a_theo,
            'Delta_a': Delta_a,
            'a_actual': a_actual
        }

    # =================== 链轮几何参数（GB/T 10855-2016 表7）====================
    def sprocket_geom(self, z: int, p: float, chain: Dict) -> Dict:
        """
        链轮几何参数计算（GB/T 10855-2016 表7查表法）
        实际尺寸 = 系数 × 节距p
        """
        coeff_group = chain.get('coeffGroup', 'general')

        # 查表获取系数（需要导入系数表）
        from .silent_chain_data import lookup_sprocket_coeff
        coeff = lookup_sprocket_coeff(z, coeff_group)

        if not coeff:
            # 降级: 用公式估算
            d = p / math.sin(math.pi / z)
            return {
                'd': d, 'arc_da': d, 'rect_da': d,
                'MR': d, 'dg': d, 'dR': 0.625 * p,
                'fallback': True
            }

        # 实际尺寸 = 系数 × 节距p
        d = coeff['d'] * p
        arc_da = coeff['arc_da'] * p
        rect_da = coeff['rect_da'] * p
        MR = coeff['MR'] * p
        dg = coeff['dg'] * p
        dR = 0.625 * p  # 量柱直径 (GB/T 10855-2016 固定)

        return {
            'd': d, 'arc_da': arc_da, 'rect_da': rect_da,
            'MR': MR, 'dg': dg, 'dR': dR
        }

    # =================== 受力分析 ===================
    @staticmethod
    def force_analysis(Pd: float, v: float, chain: Dict, a_mm: float, f5: float) -> Dict:
        """受力分析"""
        F = Pd * 1000 / v if v > 0 else 999999  # 有效圆周力 N
        Fc = chain['massPerM'] * v * v  # 离心力 N
        Kf = 6  # 悬垂系数(水平)
        Ff = Kf * chain['massPerM'] * 9.81 * a_mm / 1000  # 悬垂拉力 N
        F_max = F + Fc + Ff
        Fq = f5 * F  # 轴压力 N

        return {'F': F, 'Fc': Fc, 'Ff': Ff, 'F_max': F_max, 'Fq': Fq}

    # =================== 强度校核 ===================
    @staticmethod
    def strength_check(chain: Dict, F_max: float, Fc: float) -> Dict:
        """强度校核"""
        S = chain['Qmin'] / F_max
        F_dynamic = max(F_max - (Fc or 0), F_max * 0.7)
        S_fatigue = chain['Qmin'] / (3 * F_dynamic)

        return {'S': S, 'S_fatigue': S_fatigue, 'Qmin': chain['Qmin']}

    # =================== 主设计函数 ===================
    def design_chain(self, params: Dict) -> Dict:
        """
        完整10步齿形链设计计算
        :param params: 包含 guideType, z1, z2, P, f1, n1, chainType, a0_mm, f5
        """
        guide_type = params.get('guideType', 'inner')
        z1 = int(params.get('z1', 36))
        z2 = int(params.get('z2', 36))
        P = float(params.get('P', 1.5))
        f1 = float(params.get('f1', 1.0))
        n1 = float(params.get('n1', 14))
        chain_type = params.get('chainType', 'CL08')
        a0_mm = float(params.get('a0_mm', 360))
        f5 = float(params.get('f5', 1.15))

        chain = CHAIN_SPECS.get(chain_type)
        if not chain:
            return {'error': '无效链条型号'}

        p = chain['p']

        # Step1: 校验传动比与齿数
        i_actual = z2 / z1
        warnings = []
        if z1 < 15:
            warnings.append('⚠ 小轮齿数Z₁<15，运转不稳')
        if z2 > 150:
            warnings.append('⚠ 大轮齿数Z₂>150')
        if i_actual > 7:
            warnings.append('⚠ 传动比i>7，建议二级传动')

        # Step2: 设计功率 Pd = P × f₁ / Kz
        Kz = self.calc_Kz(z1)
        Pd = P * f1 / Kz

        # Step3: 选链宽
        w_result = self.select_width(chain_type, z1, n1, Pd)

        # Step4: 链节数
        step4 = self.calc_chain_length(z1, z2, a0_mm, p)

        # Step5: 精确中心距
        step5 = self.calc_exact_center(z1, z2, step4['X'], p, a0_mm)

        # Step6: 链速
        v = z1 * p * n1 / 60000

        # Step7: 链轮几何参数
        sp1 = self.sprocket_geom(z1, p, chain)
        sp2 = self.sprocket_geom(z2, p, chain)

        # 包角
        a_center = step5['a_theoretical']
        alpha1 = 180 - 60 * (z2 - z1) / (a_center / p)
        alpha2 = 180 + 60 * (z2 - z1) / (a_center / p)

        # Step8: 受力分析
        step8 = self.force_analysis(Pd, v, chain, step5['a_actual'], f5)

        # Step9: 强度校核
        step9 = self.strength_check(chain, step8['F_max'], step8['Fc'])

        # Step10: 润滑方式
        lubrication = self.get_lubrication(v)

        # 链板片数
        plate_count = chain['plateSeries'][
            chain['widthSeries'].index(w_result['b'])
            if w_result['b'] in chain['widthSeries'] else len(chain['widthSeries']) // 2
        ]

        return {
            'input': {
                'chainType': chain_type, 'p': round(p, 3),
                'P': P, 'n1': n1, 'z1': z1, 'z2': z2,
                'guideType': guide_type, 'a0_mm': a0_mm
            },
            'i_actual': round(i_actual, 3),
            'warnings': warnings,
            'Kz': round(Kz, 4),
            'Pd': round(Pd, 2),
            'b_min': w_result.get('b'),
            'P0': w_result.get('P0'),
            'estimated': w_result.get('estimated', False),
            'plateCount': plate_count,
            'X0': step4['X0'], 'X': step4['X'],
            'L_mm': round(step4['L_mm'], 1),
            'L_m': round(step4['L_m'], 3),
            'a_theoretical': round(step5['a_theoretical'], 2),
            'a_actual': round(step5['a_actual'], 2),
            'Delta_a': round(step5['Delta_a'], 2),
            'v': round(v, 3),
            'n2': round(n1 * z1 / z2, 0),
            'sprocket1': {k: round(v, 3) for k, v in sp1.items() if isinstance(v, (int, float))},
            'sprocket2': {k: round(v, 3) for k, v in sp2.items() if isinstance(v, (int, float))},
            'alpha1': round(alpha1, 1), 'alpha2': round(alpha2, 1),
            'F': round(step8['F'], 1), 'Fc': round(step8['Fc'], 1),
            'Ff': round(step8['Ff'], 1), 'F_max': round(step8['F_max'], 1),
            'Fq': round(step8['Fq'], 1),
            'S': round(step9['S'], 2), 'S_fatigue': round(step9['S_fatigue'], 2),
            'Qmin': step9['Qmin'],
            'safetyPass': step9['S'] >= 3,
            'lubrication': lubrication
        }


# =================== 便捷函数 ====================
def design_chain(params: Dict) -> Dict:
    """便捷函数：齿形链设计"""
    calc = SilentChainCalculator()
    return calc.design_chain(params)


def query_P0(chain_type: str, z1: int, n1: float, width: float) -> Optional[float]:
    """便捷函数：查询额定功率"""
    calc = SilentChainCalculator()
    return calc.query_P0_by_width(chain_type, z1, n1, width)


if __name__ == '__main__':
    # 测试
    calc = SilentChainCalculator()

    params = {
        'guideType': 'inner',
        'z1': 36, 'z2': 36,
        'P': 1.5, 'f1': 1.0, 'n1': 14,
        'chainType': 'CL08', 'a0_mm': 360, 'f5': 1.15
    }

    result = calc.design_chain(params)
    if 'error' in result:
        print(f"错误: {result['error']}")
    else:
        print("齿形链设计结果:")
        for k, v in result.items():
            if k not in ['sprocket1', 'sprocket2', 'input']:
                print(f"  {k}: {v}")
