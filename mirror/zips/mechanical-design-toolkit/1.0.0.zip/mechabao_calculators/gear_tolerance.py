"""
齿轮公差计算引擎 - gear_tolerance.py
GB/T 10095.1-2022 圆柱齿轮 ISO齿面公差分级制
GB/T 10095.2-2023 圆柱齿轮 径向综合偏差
公式来源：标准正文公式(5)~(12)及附录E公式(E.1)
"""

import math


# ==================== GB/T 10095.1-2022 精度等级 ===================
TOLERANCE_GRADES = {
    0: '最高精度（特殊精密测量齿轮）',
    1: '超高精度（精密测量齿轮）',
    2: '极高精度（精密分度齿轮）',
    3: '高精度（精密机床分度齿轮）',
    4: '精密级（涡轮减速器、航空齿轮）',
    5: '高精度级（机床、航空、测量仪器）',
    6: '较高精度级（通用机床、液压泵）',
    7: '普通精度级（汽车、减速器、通用机械）',
    8: '中等精度级（摩托车、农机、起重机械）',
    9: '低精度级（重型机械、通用减速器）',
    10: '粗糙级（矿山机械、低速开式齿轮）',
    11: '较低精度级（开式齿轮、手动传动）',
    12: '最低精度级（粗糙开式齿轮）'
}

# ==================== GB/T 10095.2-2023 径向综合公差等级 ===================
RADIAL_GRADES = {
    30: 'R30（最高精度）', 31: 'R31', 32: 'R32', 33: 'R33', 34: 'R34',
    35: 'R35（极高精度）', 36: 'R36', 37: 'R37', 38: 'R38', 39: 'R39',
    40: 'R40（精密级）', 41: 'R41', 42: 'R42（较高精度级）', 43: 'R43',
    44: 'R44', 45: 'R45（普通精度级）', 46: 'R46', 47: 'R47',
    48: 'R48（中等精度级）', 49: 'R49', 50: 'R50（粗糙级）'
}


# ==================== GB/T 10095.1-2022 齿面公差公式 ===================
class GearToleranceFormulas:
    """公差公式计算（未圆整值）"""

    @staticmethod
    def fpt_T(mn, d, Q):
        """单个齿距公差 f_pt (μm) — 公式(5)"""
        return (0.001 * d + 0.4 * mn + 5) * math.pow(2, (Q - 5) / 2)

    @staticmethod
    def Fp_T(mn, d, Q):
        """齿距累积总公差 F_p (μm) — 公式(6)"""
        return (0.001 * d + 0.25 * math.sqrt(d) + 0.4 * mn + 5) * math.pow(2, (Q - 5) / 2)

    @staticmethod
    def fH_alpha_T(mn, d, Q):
        """齿廓倾斜公差 f_Hα (μm) — 公式(7)"""
        return (0.4 * mn + 0.001 * d + 4) * math.pow(2, (Q - 5) / 2)

    @staticmethod
    def ff_alpha_T(mn, Q):
        """齿廓形状公差 f_fα (μm) — 公式(8)"""
        return (0.55 * mn + 5) * math.pow(2, (Q - 5) / 2)

    @staticmethod
    def F_alpha_T(mn, d, Q):
        """齿廓总公差 F_α (μm) — 公式(9)"""
        fHa = GearToleranceFormulas.fH_alpha_T(mn, d, Q)
        ffa = GearToleranceFormulas.ff_alpha_T(mn, Q)
        return math.sqrt(fHa ** 2 + ffa ** 2)

    @staticmethod
    def fH_beta_T(d, b, Q):
        """螺旋线倾斜公差 f_Hβ (μm) — 公式(10)"""
        return (0.05 * math.sqrt(d) + 0.35 * math.sqrt(b) + 4) * math.pow(2, (Q - 5) / 2)

    @staticmethod
    def ff_beta_T(d, b, Q):
        """螺旋线形状公差 f_fβ (μm) — 公式(11)"""
        return (0.07 * math.sqrt(d) + 0.45 * math.sqrt(b) + 4) * math.pow(2, (Q - 5) / 2)

    @staticmethod
    def F_beta_T(d, b, Q):
        """螺旋线总公差 F_β (μm) — 公式(12)"""
        fHb = GearToleranceFormulas.fH_beta_T(d, b, Q)
        ffb = GearToleranceFormulas.ff_beta_T(d, b, Q)
        return math.sqrt(fHb ** 2 + ffb ** 2)

    @staticmethod
    def Fr_T(mn, d, Q):
        """径向跳动公差 F_r (μm) — 附录E 公式(E.1)"""
        return 0.9 * (0.002 * d + 0.55 * math.sqrt(d) + 0.7 * mn + 12) * math.pow(2, (Q - 5) / 2)


# ==================== GB/T 10095.2-2023 径向综合偏差近似公式 ===================
class RadialCompositeFormulas:
    """径向综合偏差计算（近似公式法）"""

    @staticmethod
    def Fi_T(mn, d, Q):
        """径向综合总公差 F''i (μm) — 近似公式"""
        return (3.0 * mn + 1.25 * math.sqrt(d) + 8.0) * math.pow(2, Q - 5)

    @staticmethod
    def fi_T(mn, d, Q):
        """一齿径向综合公差 f''i (μm) — 近似公式"""
        return (1.5 * mn + 0.8 * (d ** 0.25) + 3.2) * math.pow(2, Q - 5)


# ==================== 圆整规则 ===================
def round_flank_tolerance(value):
    """
    GB/T 10095.1-2022 / GB/T 10095.2-2023 统一圆整规则
    <5μm 保留1位小数；≥5μm 取整（0.5向上圆整）
    """
    if value < 5:
        return round(value * 10) / 10
    else:
        floor_val = math.floor(value)
        decimal = value - floor_val
        if abs(decimal - 0.5) < 1e-9:
            return floor_val + 1
        return round(value)


def round_tolerance(value):
    """
    GB/T 10095.2-2023 圆整规则（近似公式也使用此规则）
    就近圆整为整数；恰好0.5时向上圆整
    """
    floor_val = math.floor(value)
    decimal = value - floor_val
    if abs(decimal - 0.5) < 1e-9:
        return floor_val + 1
    return round(value)


# ==================== 主计算类 ===================
class GearToleranceCalculator:
    """齿轮公差计算主类"""

    # ---------- GB/T 10095.1-2022 齿面公差计算 ----------
    def calc_gear_tolerances(self, m, z, d, b, grade, a=None):
        """
        计算齿轮齿面各项公差值（公式法）
        依据 GB/T 10095.1-2022（等同 ISO 1328-1:2013）

        :param m: 法向模数 (mm)
        :param z: 齿数
        :param d: 分度圆直径 (mm)
        :param b: 齿宽 (mm)
        :param grade: 精度等级 (0-12)
        :param a: 中心距 (mm)，用于计算中心距公差
        :return: 各公差值dict
        """
        mn = float(m) if m else 3.0
        z = int(z) if z else 20
        d = float(d) if d else mn * z
        b = float(b) if b else 20.0
        grade = max(0, min(12, int(grade) if grade is not None else 7))
        center_distance = float(a) if a else d * 1.5

        # 齿距偏差
        fpt_raw = GearToleranceFormulas.fpt_T(mn, d, grade)

        # 齿廓偏差
        fH_alpha_raw = GearToleranceFormulas.fH_alpha_T(mn, d, grade)
        ff_alpha_raw = GearToleranceFormulas.ff_alpha_T(mn, grade)
        F_alpha_raw = GearToleranceFormulas.F_alpha_T(mn, d, grade)

        # 螺旋线偏差
        fH_beta_raw = GearToleranceFormulas.fH_beta_T(d, b, grade)
        ff_beta_raw = GearToleranceFormulas.ff_beta_T(d, b, grade)
        F_beta_raw = GearToleranceFormulas.F_beta_T(d, b, grade)

        # 径向跳动
        Fr_raw = GearToleranceFormulas.Fr_T(mn, d, grade)

        # 圆整
        fpt = round_flank_tolerance(fpt_raw)
        Fp_raw = GearToleranceFormulas.Fp_T(mn, d, grade)
        Fp = round_flank_tolerance(Fp_raw)
        fH_alpha = round_flank_tolerance(fH_alpha_raw)
        ff_alpha = round_flank_tolerance(ff_alpha_raw)
        F_alpha = round_flank_tolerance(F_alpha_raw)
        fH_beta = round_flank_tolerance(fH_beta_raw)
        ff_beta = round_flank_tolerance(ff_beta_raw)
        F_beta = round_flank_tolerance(F_beta_raw)
        Fr = round_flank_tolerance(Fr_raw)

        # 公法线长度变动公差 Fw（旧标准，保留兼容）
        Fw = round_flank_tolerance(Fr * 1.4)

        # k个齿距累积偏差 Fpk
        k = max(3, math.ceil(z / 8))
        Fpk = round_flank_tolerance(Fp * math.sqrt(min(k / z, 1.0)))

        # 中心距极限偏差 ±fa
        fa = self.calc_center_distance_tolerance(grade, center_distance)

        # 齿顶圆直径公差 IT
        da = d + 2 * mn
        IT = self.calc_tip_diameter_tolerance(da, grade)

        return {
            'grade': grade,
            'grade_desc': TOLERANCE_GRADES.get(grade, ''),
            'mn': mn,
            'z': z,
            'd': round(d, 2),
            'b': b,
            'tolerances': {
                'fpt': fpt,            # 单个齿距偏差 (μm)
                'Fp': Fp,              # 齿距累积总偏差 (μm)
                'Fpk': Fpk,            # k个齿距累积偏差 (μm)
                'k': k,                # Fpk跨齿数
                'fHa': fH_alpha,      # 齿廓倾斜公差 (μm)
                'ffa': ff_alpha,      # 齿廓形状公差 (μm)
                'Fa': F_alpha,        # 齿廓总公差 (μm)
                'fHb': fH_beta,       # 螺旋线倾斜公差 (μm)
                'ffb': ff_beta,      # 螺旋线形状公差 (μm)
                'Fb': F_beta,        # 螺旋线总公差 (μm)
                'Fr': Fr,              # 齿圈径向跳动 (μm)
                'Fw': Fw,              # 公法线长度变动 (μm)
                'fa': fa,              # 中心距极限偏差 ±fa (μm)
                'IT': IT,              # 齿顶圆直径公差 (μm)
            }
        }

    # ---------- GB/T 10095.2-2023 径向综合偏差 ----------
    def calc_radial_composite_tolerances(self, mn, d, R):
        """
        计算齿轮径向综合偏差公差值（R等级Q系数公式）
        依据 GB/T 10095.2-2023（等同 ISO 1328-2:2020）

        :param mn: 法向模数 (mm)
        :param d: 分度圆直径 (mm)
        :param R: 径向综合公差等级 (R30~R50)
        :return: 径向综合公差值dict
        """
        mn = float(mn) if mn else 3.0
        d = float(d) if d else 60.0
        R = max(30, min(50, int(R) if R is not None else 42))

        Q = math.pow(2, (R - 30) / 5)  # Q系数

        # 径向综合总公差 F''i
        Fi_raw = RadialCompositeFormulas.Fi_T(mn, d, R)
        Fi = round_tolerance(Fi_raw)

        # 一齿径向综合公差 f''i
        fi_raw = RadialCompositeFormulas.fi_T(mn, d, R)
        fi = round_tolerance(fi_raw)

        return {
            'R': R,
            'R_desc': RADIAL_GRADES.get(R, ''),
            'mn': mn,
            'd': d,
            'Q': round(Q, 6),
            'radial_tolerances': {
                'Fit': Fi,   # 径向综合总公差 F''i (μm)
                'fit': fi,   # 一齿径向综合公差 f''i (μm)
            }
        }

    # ---------- 中心距极限偏差 ----------
    def calc_center_distance_tolerance(self, grade, a):
        """
        计算中心距极限偏差 ±fa（GB/Z 18620.3）
        根据精度等级确定IT等级，再查IT公差表
        """
        if grade is None or a is None:
            return 0

        # 精度等级到IT等级的映射
        if 0 <= grade <= 6:
            it_grade = 7
        elif 7 <= grade <= 8:
            it_grade = 8
        elif 9 <= grade <= 10:
            it_grade = 9
        else:
            it_grade = 11

        # IT公差值表（GB/T 1800.2）— 单位：μm
        a = float(a)
        if a <= 10:
            tolerance = {'IT7': 15, 'IT8': 22, 'IT9': 36, 'IT11': 90}
        elif a <= 18:
            tolerance = {'IT7': 18, 'IT8': 27, 'IT9': 43, 'IT11': 110}
        elif a <= 30:
            tolerance = {'IT7': 21, 'IT8': 33, 'IT9': 52, 'IT11': 130}
        elif a <= 50:
            tolerance = {'IT7': 25, 'IT8': 39, 'IT9': 62, 'IT11': 160}
        elif a <= 80:
            tolerance = {'IT7': 30, 'IT8': 46, 'IT9': 74, 'IT11': 190}
        elif a <= 120:
            tolerance = {'IT7': 35, 'IT8': 54, 'IT9': 87, 'IT11': 220}
        elif a <= 180:
            tolerance = {'IT7': 40, 'IT8': 63, 'IT9': 100, 'IT11': 250}
        elif a <= 250:
            tolerance = {'IT7': 46, 'IT8': 72, 'IT9': 115, 'IT11': 290}
        elif a <= 315:
            tolerance = {'IT7': 52, 'IT8': 81, 'IT9': 130, 'IT11': 320}
        elif a <= 400:
            tolerance = {'IT7': 57, 'IT8': 89, 'IT9': 140, 'IT11': 360}
        elif a <= 500:
            tolerance = {'IT7': 63, 'IT8': 97, 'IT9': 155, 'IT11': 400}
        elif a <= 630:
            tolerance = {'IT7': 70, 'IT8': 110, 'IT9': 175, 'IT11': 440}
        elif a <= 800:
            tolerance = {'IT7': 80, 'IT8': 125, 'IT9': 200, 'IT11': 500}
        else:
            tolerance = {'IT7': 90, 'IT8': 140, 'IT9': 230, 'IT11': 570}

        return tolerance.get(f'IT{it_grade}', 0)

    # ---------- 齿顶圆直径公差 ----------
    def calc_tip_diameter_tolerance(self, da, grade):
        """计算齿顶圆直径公差 IT（GB/T 1800.2）"""
        if grade is None or da is None:
            return 0

        if grade <= 4:
            it_grade = 6
        elif grade <= 6:
            it_grade = 7
        elif grade <= 8:
            it_grade = 8
        elif grade <= 10:
            it_grade = 9
        else:
            it_grade = 10

        D = max(da, 1.0)
        i_factor = 0.45 * (D ** (1 / 3)) + 0.001 * D

        it_multipliers = {5: 7, 6: 10, 7: 16, 8: 25, 9: 40, 10: 64, 11: 100}
        return round(i_factor * it_multipliers.get(it_grade, 16))


# ==================== 便捷函数 ===================
def calc_gear_tolerances(m, z, d, b, grade, a=None):
    """便捷函数：计算齿轮齿面公差"""
    calc = GearToleranceCalculator()
    return calc.calc_gear_tolerances(m, z, d, b, grade, a)


def calc_radial_composite_tolerances(mn, d, R):
    """便捷函数：计算径向综合偏差"""
    calc = GearToleranceCalculator()
    return calc.calc_radial_composite_tolerances(mn, d, R)


def get_grade_applications():
    """获取所有精度等级的应用场景"""
    return TOLERANCE_GRADES


def get_radial_grade_applications():
    """获取所有径向综合公差等级"""
    return RADIAL_GRADES


if __name__ == '__main__':
    # 测试
    calc = GearToleranceCalculator()

    # 齿面公差
    result = calc.calc_gear_tolerances(m=3, z=20, d=60, b=20, grade=7, a=90)
    print("齿面公差结果:")
    for k, v in result.items():
        print(f"  {k}: {v}")
    print("\n" + "=" * 50 + "\n")

    # 径向综合偏差
    result2 = calc.calc_radial_composite_tolerances(mn=3, d=60, R=45)
    print("径向综合偏差结果:")
    for k, v in result2.items():
        print(f"  {k}: {v}")
