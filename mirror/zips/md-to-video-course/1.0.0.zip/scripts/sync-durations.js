#!/usr/bin/env node
/**
 * 同步脚本：读取 voiceover-durations.json，生成 Root.tsx 用的帧数配置
 * 运行: node scripts/sync-durations.js
 */

const fs = require("fs");
const path = require("path");

const DURATIONS_PATH = path.join(__dirname, "..", "src", "voiceover-durations.json");
const OUTPUT_PATH = path.join(__dirname, "..", "src", "chapter-frames.json");
const FPS = 60;
const OUTLINE_FRAMES = 240;
const PADDING_FRAMES = 30; // 每个场景结尾留白

if (!fs.existsSync(DURATIONS_PATH)) {
  console.error("❌ voiceover-durations.json 不存在，请先运行 scripts/generate-voiceover.sh");
  process.exit(1);
}

const durations = JSON.parse(fs.readFileSync(DURATIONS_PATH, "utf-8"));

const result = {};

for (const [chId, scenes] of Object.entries(durations)) {
  const sceneFrames = {};
  let total = OUTLINE_FRAMES;

  for (const [sceneId, duration] of Object.entries(scenes)) {
    const frames = Math.ceil(duration * FPS) + PADDING_FRAMES;
    sceneFrames[sceneId] = frames;
    total += frames;
  }

  result[chId] = {
    totalFrames: total,
    outlineFrames: OUTLINE_FRAMES,
    scenes: sceneFrames,
  };
}

fs.writeFileSync(OUTPUT_PATH, JSON.stringify(result, null, 2));

console.log("✅ chapter-frames.json 已生成");
console.log("");
for (const [chId, data] of Object.entries(result)) {
  const dur = (data.totalFrames / FPS).toFixed(1);
  console.log(`  ${chId}: ${data.totalFrames} frames (${dur}s) - ${Object.keys(data.scenes).length} scenes`);
}

const totalFrames = Object.values(result).reduce((sum, d) => sum + d.totalFrames, 0);
console.log(`\n📊 总计: ${totalFrames} frames (${(totalFrames / FPS / 60).toFixed(1)} min)`);
