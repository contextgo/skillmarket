# Standard Modal Template

## Structure

1. Title
- clear action intent

2. Body
- key context
- critical warning (if destructive)
- form area (if needed)

3. Footer
- primary action
- secondary action
- dangerous action (only when necessary)

## Form Modal Baseline (smart-admin)

When the modal contains a form, apply all rules below:

1. Wrap form area with `class="common-form"` and bind `ref="formContainerRef"`.
2. Use `useFormErrorScroll` for validation + scroll reset:
- `const { validateAndScroll, resetFormScroll, formContainerRef } = useFormErrorScroll();`
- submit with `await validateAndScroll(formModelRef);`
- after open call `resetFormScroll();`
3. Control mapping:
- single line text: `admin-input`
- upload: project upload component (for example `base-upload`) with business folder enum
- multiline text: `a-textarea` with `:maxlength` and `show-count`
- enum fields: `SmartEnumSelect`
4. `a-form-item name` must match `formModel` field exactly.

## Interaction Rules

- Open: focus first interactive control.
- Close: return focus to trigger element.
- ESC close: configurable by modal type.
- Mask close: disabled for destructive operations.

## Submit Rules

- Prevent duplicate submits while `submitting`.
- Keep modal open when submit fails.
- Close modal only after confirmed success.

## State Contract

- `idle`
- `submitting`
- `success`
- `error`

## Vue Example Skeleton

```vue
<script setup>
import { message } from "ant-design-vue";
import { deepClone, useFormReset, useLoading, useFormErrorScroll } from "admin-utils";
import { addAppApi, updateAppApi, findAppByIdApi } from "@/api/merchant-manage/app-manage-api";
import { FileEnum } from "@/constants/file-const";
import { formRules } from "../column";

const dialogVisible = ref(false);
const saveCallback = ref(null);

const [formModel, resetForm] = useFormReset({
  merchantId: null,
  appName: "",
  appIcon: null,
  reason: null,
  appDesc: null,
  loading: false,
});

const { loading, setLoading } = useLoading();

const formModelRef = ref();

const { validateAndScroll, resetFormScroll, formContainerRef } = useFormErrorScroll();

const isEdit = ref(false);

async function showDialog(form, callback) {
  dialogVisible.value = true;
  saveCallback.value = callback;
  resetForm({ removeExtraFields: true });
  setLoading(false);
  await nextTick();
  isEdit.value = !!form;
  formModelRef.value.clearValidate();
  if (form) {
    Object.assign(formModel, deepClone(form));
  }
  resetFormScroll();
}



function hideDialog() {
  dialogVisible.value = false;
}

function handleGetFileUrl(url) {
  formModelRef.value.validateFields(["appIcon"]);
}

async function handleOk() {
  await validateAndScroll(formModelRef);
  const api = isEdit.value ? updateAppApi : addAppApi;
  const params = {
    appName: formModel.appName,
    appIcon: formModel.appIcon,
    reason: formModel.reason,
    appDesc: formModel.appDesc,
  };
  setLoading(true);
  if (isEdit.value) {
    Object.assign(params, {
      id: formModel.id,
    });
  } else {
    Object.assign(params, {
      merchantId: formModel.merchantId,
    });
  }
  try {
    await api(params);
    message.success(isEdit.value ? "更新成功" : "新增成功");
    hideDialog();
    if (saveCallback.value) {
      saveCallback.value();
    }
  } finally {
    setLoading(false);
  }
}

defineExpose({
  showDialog,
  hideDialog,
});
</script>

<template>
  <admin-modal
    v-model="dialogVisible"
    :title="`${isEdit ? '编辑应用' : '新增应用'}`"
    :confirm-loading="loading"
    @ok="handleOk"
    @cancel="hideDialog"
    size="small"
  >
    <a-spin :spinning="formModel.loading">
      <div class="common-form" ref="formContainerRef">
        <a-form :model="formModel" layout="vertical" ref="formModelRef" :rules="formRules">
          <a-form-item name="merchantId" label="商户名称">
            <base-api-select
              :disabled="isEdit"
              v-model="formModel.merchantId"
              :field-names="{ label: 'merchantName', value: 'id' }"
              placeholder="请选择所属商户"
              :params="{ status: 1 }"
              api-type="MERCHANT"
              :focus-load="false"
            />
          </a-form-item>
          <a-form-item name="appName" label="应用名称">
            <admin-input v-model="formModel.appName" placeholder="请输入应用名称" :maxlength="50" />
          </a-form-item>
          <a-form-item label="应用图标" name="appLogo">
            <base-upload
              v-model="formModel.appIcon"
              :fileSizeLimit="5"
              @getFileUrl="handleGetFileUrl"
              list-type="picture-card"
              :accept="['png', 'jpg', 'jpeg', 'svg', 'webp']"
              :folder="FileEnum.APP_LOGO"
            />
          </a-form-item>
          <a-form-item label="创建原因" name="reason">
            <a-textarea
              v-model:value="formModel.reason"
              placeholder="请输入创建原因"
              allow-clear
              :autoSize="{ minRows: 2 }"
              :maxlength="300"
            />
          </a-form-item>
          <a-form-item label="应用描述" name="appDesc">
            <a-textarea
              v-model:value="formModel.appDesc"
              placeholder="请输入应用描述"
              allow-clear
              :autoSize="{ minRows: 2 }"
              :maxlength="300"
            />
          </a-form-item>
        </a-form>
      </div>
    </a-spin>
  </admin-modal>
</template>
```
