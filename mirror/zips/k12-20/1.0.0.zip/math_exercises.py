import random
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont('MSYH', 'C:/Windows/Fonts/msyh.ttc'))

def gen_q():
    op = random.choice([chr(43), chr(45)])
    if op == chr(43):
        a = random.randint(0, 10)
        b = random.randint(0, 20 - a)
    else:
        a = random.randint(1, 20)
        b = random.randint(0, a)
    return f'{a} {op} {b} = _______'

c = canvas.Canvas('math_exercises_20.pdf', pagesize=A4)
for p in range(1, 11):
    c.setFont('MSYH', 18)
    title = chr(50)+chr(48)+'以内加减法练习（第'+str(p)+'页）'
    c.drawString(105*mm - c.stringWidth(title)/2, 280*mm, title)
    c.setFont('MSYH', 14)
    cols, rows = 4, 15
    col_width = 45*mm
    row_height = 15*mm
    start_x = (210*mm - cols*col_width) / 2 + 10*mm
    start_y = 260*mm
    for i in range(60):
        col = i % cols
        row = i // cols
        c.drawString(start_x + col*col_width, start_y - row*row_height, gen_q())
    c.showPage()
c.save()
print(chr(68)+'one: math_exercises_20.pdf')
