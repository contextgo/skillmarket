---
name: k12-20
description: 生成K12阶段20以内加减法练习题PDF，支持自定义页数、题数、排版格式
---

# k12-20

生成 20 以内加减法练习题 PDF 文件。

## 环境

| Tool | 状态 |
|------|------|
| Python | 需已安装 |
| reportlab | 需已安装 (`pip install reportlab`) |

## 使用方法

```bash
cd .opencode/skills/k12-20
python math_exercises.py
```

## 参数配置

修改 `math_exercises.py` 中的变量：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `TOTAL_PAGES` | 30 | 页数 |
| `QUESTIONS_PER_PAGE` | 60 | 每页题数 |
| `cols` | 4 | 列数 |
| `rows` | 15 | 行数 |
| `font_size` | 14 | 正文字体大小 |
| `title_font_size` | 18 | 标题字体大小 |
| `underline_length` | 7 | 答题横线长度 |

## 输出

生成文件：`math_exercises_20.pdf`

## 示例

生成 10 页、每页 60 题：
```python
TOTAL_PAGES = 10
```

(End of file - total 34 lines)