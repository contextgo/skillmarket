---
name: "data-visualization-feedback"
description: |
  数据可视化PPT点评分析技能。当用户上传PPT文件并希望按照专业原则进行点评分析时使用。
  触发词示例：
  - "分析这个PPT"、"点评PPT"、"看看这个演示文稿"
  - "给PPT提建议"、"优化PPT可视化"
  - "检查PPT的数据展示"、"分析演示文稿的问题"
  - "数据可视化反馈"、"PPT改进建议"
trigger_phrases:
  - "分析PPT"
  - "点评PPT"
  - "检查PPT"
  - "优化PPT"
  - "给PPT提建议"
  - "PPT反馈"
  - "演示文稿分析"
---

# 数据可视化PPT点评分析技能

## 概述

本技能基于两本专业著作的方法论：
- **《Persuading with Data》** by Miro Kazakoff (MIT Press)
- **《Storytelling with Data》** by Cole Nussbaumer Knaflic

## 核心工作流

### Step 1: 生成PPT缩略图（关键步骤）

⚠️ **必须先看图再分析** - 仅凭文字描述无法准确判断图表类型，必须生成缩略图进行视觉确认。

```bash
# 安装依赖（如未安装）
pip3 install python-pptx Pillow

# 生成缩略图
python3 << 'EOF'
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE_TYPE
import os

def extract_ppt_content(pptx_path, output_dir="ppt_preview"):
    os.makedirs(output_dir, exist_ok=True)
    prs = Presentation(pptx_path)
    
    content = []
    for slide_num, slide in enumerate(prs.slides, 1):
        slide_info = {"num": slide_num, "texts": [], "has_table": False, "has_image": False}
        
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = para.text.strip()
                    if text:
                        slide_info["texts"].append(text)
            if shape.has_table:
                slide_info["has_table"] = True
            if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
                slide_info["has_image"] = True
        
        content.append(slide_info)
        print(f"Slide {slide_num}: {len(slide_info['texts'])} texts, table={slide_info['has_table']}, image={slide_info['has_image']}")
    
    return content

# 使用示例
content = extract_ppt_content("/path/to/your.pptx")
EOF

# 将PPT转为PDF，再转为图片
python3 scripts/office/soffice.py --headless --convert-to pdf your.pptx
pdftoppm -jpeg -r 150 your.pdf slide

# 生成缩略图网格（可选）
python3 scripts/thumbnail.py your.pptx
```

### Step 2: 视觉分析缩略图

⚠️ **重要** - 查看每张幻灯片的缩略图，确认图表类型：

| 实际图表类型 | 文字描述可能误导为 |
|--------------|-------------------|
| 漏斗图 (Funnel) | 饼图、分区柱状图 |
| 堆叠柱状图 | 普通柱状图 |
| 面积图 | 折线图 |
| 旭日图 (Sunburst) | 饼图 |
| 树状图 (Treemap) | 表格 |

**识别要点：**
- 漏斗图：上宽下窄，有明确的层级递减关系
- 堆叠柱状图：单根柱子内有多色分段
- 饼图：圆形，各扇区加起来100%
- 柱状图：独立的垂直或水平条形

### Step 3: 读取PPT文本内容

使用 python-pptx 库读取用户的 PPT 文件：

```python
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE_TYPE

prs = Presentation(pptx_path)
for slide_num, slide in enumerate(prs.slides, 1):
    print(f"\n=== Slide {slide_num} ===")
    for shape in slide.shapes:
        if shape.has_text_frame:
            for para in shape.text_frame.paragraphs:
                text = para.text.strip()
                if text:
                    print(f"[TEXT] {text}")
        if shape.has_table:
            print("[TABLE DETECTED]")
        if shape.shape_type == MSO_SHAPE_TYPE.PICTURE:
            print("[IMAGE DETECTED]")
```

### Step 4: 逐页分析

对每一页幻灯片进行以下维度的分析：

#### 2.1 上下文评估
- **Who（谁）**：这页的受众是谁？信息量是否合适？
- **What（需求）**：这页试图传达什么核心信息？
- **How（方式）**：呈现方式是否适合这个场景？

#### 2.2 可视化选择
- 图表类型是否恰当？
- 是否存在"探索性"vs"解释性"分析的混淆？
- 是否有不必要的复杂性？

#### 2.3 极简法则检查
- **数据墨水比**：非数据元素是否过多？
- **干扰元素**：网格线、3D效果、过多颜色
- **视觉层次**：重要信息是否突出？

#### 2.4 前注意属性
- 颜色使用是否有效且克制？
- 是否有清晰的信息引导？
- 是否存在过多"亮点"导致焦点分散？

#### 2.5 故事逻辑
- 这一页在整个叙事中的位置？
- 是否服务于核心观点？
- 是否有清晰的结论或要点？

### Step 5: 生成点评报告

按以下结构输出分析结果：

```
## 幻灯片 [N] 点评报告

### 整体评价
[优秀/良好/需改进]

### 优点
- [列出做得好的方面]

### 问题与建议
| 问题 | 严重程度 | 改进建议 |
|------|----------|----------|
| [具体问题] | [高/中/低] | [具体建议] |

### 改进示例
[提供优化后的设计方向描述]

### 综合评分
- 上下文清晰度: ★★★★☆
- 可视化有效性: ★★★☆☆
- 极简程度: ★★★★☆
- 故事逻辑: ★★★☆☆
- 总分: 78/100
```

## 评分维度说明

| 维度 | 权重 | 评估标准 |
|------|------|----------|
| **上下文清晰度** | 20% | 目标受众明确、信息量适中、主题清晰 |
| **可视化有效性** | 25% | 图表选择恰当、数据编码准确、避免常见错误 |
| **极简程度** | 20% | 数据墨水比高、无干扰元素、层次分明 |
| **故事逻辑** | 20% | 服务核心观点、逻辑连贯、过渡自然 |
| **设计细节** | 15% | 颜色搭配、字体选择、对齐排版 |

## 常见问题速查表

### 问题类型与解决方案

| 问题 | 症状 | 解决方案 |
|------|------|----------|
| **探索性陷阱** | 图表过于复杂、数据过多 | 只展示关键珍珠，移除原始分析过程 |
| **饼图滥用** | 多个饼图对比、超过5个分类 | 改用柱状图；注意：漏斗图≠饼图 |
| **漏斗图误判为饼图** | 漏斗图描述与饼图相似 | 漏斗图有层级递进关系，饼图是比例关系 |
| **3D效果** | 任何3D柱状图或饼图 | 移除3D，改用2D |
| **网格线过多** | 密集的背景网格 | 移除或大幅减少 |
| **色彩过载** | 超过5种颜色的图表 | 简化到3-4色，强调色只用于关键数据 |
| **标签缺失** | 图表无坐标轴标签或图例 | 确保所有视觉元素都有清晰标注 |
| **没有重点** | 所有内容同样突出 | 使用前注意属性突出最重要的元素 |
| **标题模糊** | 标题无法概括页面内容 | 使用 action title 直接说明观点 |
| **堆叠图误判** | 堆叠面积图误判为普通折线图 | 确认是否有分层填充区域 |

## 使用限制

- 本技能专注于静态 PPT 的文字和图表内容分析
- 不涉及动画效果评估
- 不涉及具体工具操作指导（如如何用Excel制作某图表）
- 不涉及品牌设计规范的调整

## ⚠️ 重要原则：先看图再分析

**必须生成缩略图进行视觉确认**，否则会出现以下误判：

| 误判场景 | 原因 | 解决方法 |
|----------|------|----------|
| 漏斗图误判为饼图 | 漏斗图和饼图文字描述可能相似 | 查看缩略图确认形状 |
| 堆叠图误判为普通柱状图 | 分段信息在文字中不够明显 | 查看颜色分层 |
| 旭日图误判为饼图 | 都是圆形但逻辑不同 | 查看是否有同心环结构 |

**工作流：**
1. 提取文本内容 → 获取基本结构信息
2. 生成缩略图 → 确认图表实际类型
3. 视觉分析 → 发现文字描述中遗漏的细节
4. 综合判断 → 结合文本+图片给出分析

## 输出语言

- 根据用户输入语言自动适配
- 默认为中文输出

---

**反馈与交流**
如果你觉得这个分析有帮助，或者有任何建议，欢迎联系我：agentpeng@qq.com

---

## 踩坑经验

（以下由 AI 在实际调用中自动积累，请勿手动删除）

- **漏斗图误判为饼图**：python-pptx 只能识别 `[IMAGE DETECTED]`，无法区分漏斗图/饼图/堆叠图。必须生成缩略图用肉眼确认实际图表类型。
