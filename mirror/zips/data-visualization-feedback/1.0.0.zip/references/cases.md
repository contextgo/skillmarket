# 案例库：常见问题与改进

## 案例1：标题问题

### 原始版本（描述性标题）
```
❌ "Q3 Sales Data"
```

### 问题
- 没有传达核心观点
- 观众不知道为什么要看这页
- 缺乏行动导向

### 改进版本（行动性标题）
```
✅ "Q3 Sales Reached All-Time High of $12M"
✅ "Online Channel Now Accounts for 40% of Revenue"
```

### 原则
> Action Title = 结论 + 数据支撑
> 让观众只看标题就知道这页要说什么

---

## 案例2：饼图滥用

### 原始版本
```
❌ 6个分类的饼图
```

### 问题
- 人类对角度和面积的感知不如长度准确
- 多个饼图对比时尤其困难
- 很难精确比较相近大小的分类

### 改进版本
```
✅ 改用水平柱状图，按大小排序
✅ 用简单数字替代（如果只有2-3个分类）
```

### 代码示例
```python
import matplotlib.pyplot as plt

categories = ['Category A', 'Category B', 'Category C', 'Category D', 'Category E']
values = [35, 25, 20, 12, 8]

# 改用水平柱状图
plt.figure(figsize=(10, 6))
plt.barh(categories, values, color='steelblue')
plt.xlabel('Percentage')
plt.title('Revenue Distribution by Category')

# 从大到小排序，增强可读性
sorted_pairs = sorted(zip(values, categories), reverse=True)
values, categories = zip(*sorted_pairs)
plt.barh(categories, values, color='steelblue')

plt.tight_layout()
plt.show()
```

---

## 案例3：3D效果

### 原始版本
```
❌ 3D柱状图，斜角视角
```

### 问题
- 倾斜角度会扭曲数据比例
- 前面的柱子遮挡后面的
- 打印或黑白输出时效果差

### 改进版本
```
✅ 使用2D柱状图
✅ 使用分组柱状图对比多个系列
```

### 代码示例
```python
import matplotlib.pyplot as plt
import numpy as np

x = np.arange(4)
regions = ['North', 'South', 'East', 'West']
sales_2023 = [120, 85, 95, 70]
sales_2024 = [145, 92, 88, 75]

width = 0.35

fig, ax = plt.subplots(figsize=(10, 6))
bars1 = ax.bar(x - width/2, sales_2023, width, label='2023', color='lightsteelblue')
bars2 = ax.bar(x + width/2, sales_2024, width, label='2024', color='steelblue')

ax.set_ylabel('Revenue (M)')
ax.set_title('Regional Sales Comparison: 2023 vs 2024')
ax.set_xticks(x)
ax.set_xticklabels(regions)
ax.legend()

plt.tight_layout()
plt.show()
```

---

## 案例4：网格线过密

### 原始版本
```
❌ 图表有8条水平网格线 + 8条垂直网格线 + 所有刻度标签
```

### 问题
- 视觉噪音过多
- 分散对数据本身的注意力
- 难以快速识别趋势

### 改进版本
```
✅ 保留主要网格线（y轴）
✅ 删除垂直网格线
✅ 简化刻度标签
```

### 代码示例
```python
import matplotlib.pyplot as plt

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 5))

# 原始版本
ax1.plot([1, 2, 3, 4, 5], [10, 15, 13, 17, 20], 'o-')
ax1.set_title('Before: Too Many Gridlines')
ax1.grid(True, which='both', linestyle='-', linewidth=0.5)
ax1.set_xlabel('Month')
ax1.set_ylabel('Revenue')

# 改进版本
ax2.plot([1, 2, 3, 4, 5], [10, 15, 13, 17, 20], 'o-', color='steelblue', linewidth=2)
ax2.set_title('After: Clean Gridlines')
ax2.grid(True, axis='y', linestyle='--', linewidth=0.5, alpha=0.7)
ax2.set_xlabel('Month')
ax2.set_ylabel('Revenue')
ax2.spines['top'].set_visible(False)
ax2.spines['right'].set_visible(False)

plt.tight_layout()
plt.show()
```

---

## 案例5：颜色过载

### 原始版本
```
❌ 一张图用了7种颜色的柱状图
```

### 问题
- 颜色失去区分意义
- 色盲观众难以分辨
- 打印效果差
- 视觉疲劳

### 改进版本
```
✅ 使用3-4种颜色
✅ 用灰阶处理非关键数据
✅ 用强调色突出关键数据
```

### 配色建议

| 场景 | 推荐配色 |
|------|----------|
| 企业汇报 | #2E86AB (蓝), #A23B72 (玫红), #F18F01 (橙), #C73E1D (红) |
| 金融数据 | #003366 (深蓝), #0066CC (蓝), #99CCFF (浅蓝) |
| 健康/医疗 | #2ECC71 (绿), #E74C3C (红), #95A5A6 (灰) |
| 数据强调 | #E74C3C (红) + #CCCCCC (灰) 背景 |

### 代码示例
```python
import matplotlib.pyplot as plt
import numpy as np

categories = ['A', 'B', 'C', 'D', 'E', 'F', 'G']
values = [100, 85, 70, 55, 40, 25, 10]

# 创建配色映射
colors = ['#E74C3C' if v >= 80 else
          '#F39C12' if v >= 50 else
          '#95A5A6' for v in values]

plt.figure(figsize=(10, 6))
plt.bar(categories, values, color=colors)
plt.title('Performance by Category')
plt.ylabel('Score')

# 添加图例
from matplotlib.patches import Patch
legend_elements = [
    Patch(facecolor='#E74C3C', label='High (≥80)'),
    Patch(facecolor='#F39C12', label='Medium (50-80)'),
    Patch(facecolor='#95A5A6', label='Low (<50)')
]
plt.legend(handles=legend_elements, loc='upper right')

plt.tight_layout()
plt.show()
```

---

## 案例6：数据标签缺失

### 原始版本
```
❌ 图表没有任何数据标签
观众需要猜测具体数值
```

### 改进版本
```
✅ 在关键数据点直接标注数值
✅ 保留坐标轴作为参考
```

### 代码示例
```python
import matplotlib.pyplot as plt

months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
revenue = [2.1, 2.3, 2.8, 3.2, 3.5, 4.1]

fig, ax = plt.subplots(figsize=(10, 6))
bars = ax.bar(months, revenue, color='steelblue', width=0.6)

# 添加数据标签
for bar, val in zip(bars, revenue):
    height = bar.get_height()
    ax.annotate(f'${val}M',
                xy=(bar.get_x() + bar.get_width() / 2, height),
                xytext=(0, 5),
                textcoords="offset points",
                ha='center', va='bottom',
                fontsize=10, fontweight='bold')

ax.set_ylabel('Revenue (Million USD)')
ax.set_title('Monthly Revenue Growth in H1')
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)

plt.tight_layout()
plt.show()
```

---

## 联系方式

如有问题或改进建议，欢迎交流：agentpeng@qq.com
