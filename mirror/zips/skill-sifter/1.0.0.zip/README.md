# Skill Sifter — AI Agent Skill 评估框架

## 简介

一套系统化的 Skill 质量评估框架，将评估过程从"凭感觉"升级为"有方法论"。

通过四层递进分析（定位 → 结构 → 缺陷 → 优化），对任意 Skill 文档进行系统化质量评估，输出结构化评估报告和可操作的优化建议。

## 核心方法论：四层递进分析法

```
Layer 1: 定位分析  →  它是什么？给谁用？什么类型？
Layer 2: 结构审计  →  内容分布合理吗？信息密度高吗？
Layer 3: 缺陷检测  →  有什么问题？（一致性/必要性/适配性）
Layer 4: 优化建议  →  怎么改更好？优先级如何？
```

## 文件结构

```
skill-sifter/
├── SKILL.md                           # 主评估框架（可作为 Skill 加载）
├── metadata.json                      # 元数据
├── README.md                          # 本文件
├── templates/
│   ├── evaluation-report.md           # 完整评估报告模板
│   ├── scorecard.md                   # 记分卡模板（填空式）
│   └── quick-checklist.md             # 5分钟快速检查清单
└── references/
    └── multi-doc-evaluation.md        # 多文档体系评估指南
```

## 使用方式

### 🚀 新手推荐路径（5 分钟）
直接打开 `templates/quick-checklist.md`，逐项打勾，统计通过率即可得出基础可用性判断。

### 完整评估（加载 SKILL.md 后自动执行）
1. 将 `SKILL.md` 加载为 Skill，向 Agent 发送：`请评估 <目标Skill路径>`
2. Agent 按 SKILL.md 中的「⚡ 快速执行入口」自动完成 Layer 1→4 分析
3. 输出完整报告（参照 `templates/evaluation-report.md` 格式）
4. 使用 `templates/scorecard.md` 填写结构化记分卡

### 快速检查（无需加载 Skill）
1. 打开 `templates/quick-checklist.md`
2. 对照目标 Skill 逐项填写 ✅/❌
3. 统计通过率，按清单底部「快速判定」表得出结论

## 评分体系

| 等级 | 分数 | 含义 |
|---|---|---|
| S | 90-100 | 卓越 — 可作为范例 |
| A | 80-89 | 优秀 — 生产可用 |
| B | 70-79 | 良好 — 基本可用 |
| C | 60-69 | 及格 — 需改进 |
| D | 60以下 | 不足 — 需重构 |

## 适用场景

- 评审新编写的 Skill 是否达到可用标准
- 诊断已有 Skill 为何效果不好
- 对比多个 Skill 方案选择最优
- 在发布前做质量门禁检查
