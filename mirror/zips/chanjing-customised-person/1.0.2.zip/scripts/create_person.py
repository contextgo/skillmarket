#!/usr/bin/env python3
"""
创建定制数字人任务。
用法:
  create_person --name "我的数字人" --file-id <file_id> [--train-type figure]
输出: 定制数字人 id（一行）
"""
import argparse
import json
import sys
import urllib.request
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from _auth import get_token

API_BASE = (__import__("os").environ.get("CHANJING_OPENAPI_BASE_URL") or __import__("os").environ.get("CHANJING_API_BASE") or "https://open-api.chanjing.cc").rstrip("/")


def main():
    parser = argparse.ArgumentParser(description="创建定制数字人任务")
    parser.add_argument("--name", required=True, help="定制数字人名称")
    parser.add_argument("--file-id", required=True, help="上传后的 file_id")
    parser.add_argument(
        "--callback",
        help="任务回调 URL（若提供，服务端可能向该地址 POST 任务结果，载荷可能含敏感信息）",
    )
    parser.add_argument(
        "--train-type",
        help="训练类型。文档表格明确写了 figure；错误码文案还出现 voice/both，若未确认能力，建议留空或使用 figure",
    )
    parser.add_argument("--language", choices=["cn", "en"], help="语种，默认由服务端决定")
    parser.add_argument(
        "--error-skip",
        action="store_true",
        help="跳过部分失败，目前主要用于跳过声音克隆失败",
    )
    parser.add_argument(
        "--resolution-rate",
        type=int,
        choices=[0, 1],
        default=0,
        help="数字人分辨率，0=1080p，1=4K",
    )
    args = parser.parse_args()

    body = {
        "name": args.name,
        "file_id": args.file_id,
        "error_skip": args.error_skip,
        "resolution_rate": args.resolution_rate,
    }
    if args.callback:
        body["callback"] = args.callback
    if args.train_type:
        body["train_type"] = args.train_type
    if args.language:
        body["language"] = args.language

    token, err = get_token()
    if err:
        print(err, file=sys.stderr)
        sys.exit(1)

    url = f"{API_BASE}/open/v1/create_customised_person"
    req = urllib.request.Request(
        url,
        data=json.dumps(body).encode("utf-8"),
        headers={"access_token": token, "Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read().decode("utf-8"))

    if result.get("code") != 0:
        print(result.get("msg", result), file=sys.stderr)
        sys.exit(1)

    person_id = result.get("data")
    if not person_id:
        print("响应无 data", file=sys.stderr)
        sys.exit(1)

    print(person_id)


if __name__ == "__main__":
    main()
