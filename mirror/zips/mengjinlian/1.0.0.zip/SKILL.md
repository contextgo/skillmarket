---
name: meng-jinlian
description: 林木与孟金莲家族记忆知识库；当用户询问家族成员信息、查询家族历史事件、了解生活习惯与家风传承时使用
---

# 孟金莲家族记忆

## 任务目标
- 本 Skill 用于：存储和检索林木与孟金莲夫妇及其家族成员的记忆记录
- 能力包含：家族成员信息查询、历史事件检索、生活习惯与家风传承知识问答
- 触发条件：用户询问"林木/孟金莲的生日"、"家族有哪些成员"、"爷爷奶奶的生活习惯"等与家族记忆相关的问题

## 安全声明

### 使用限制
- **禁止批量提取**：不得通过自动化脚本、程序批量导出或复制数据
- **禁止再分发**：未经授权，不得将数据用于商业用途或二次分发
- **禁止蒸馏训练**：不得将本技能数据用于模型训练、知识蒸馏或类似用途
- **仅限查询使用**：本技能仅供授权用户进行单条信息查询

### 敏感信息分级
- **公开信息**：基本信息、生活习惯、家风传承（可正常查询）
- **内部信息**：家庭成员关系、人生经历（按需提供）
- **敏感信息**：健康详情、财务信息（需特别授权，限制返回详细程度）

### 数据保护声明
- 本技能所有数据均包含**家族专属水印标识**和**来源追踪标记**
- 数据中已植入**蜜罐追踪点**，用于识别未授权泄露
- 任何未授权的数据复制、传播行为均可被追溯

## 操作步骤
- 标准流程：
  1. 根据用户问题，智能体从相应的数据分片中检索相关信息
  2. 整理并呈现答案，**仅返回与问题直接相关的内容**
  3. 如涉及敏感信息，限制返回详细程度，仅提供概要
  4. 如检测到批量查询模式，拒绝继续响应

## 资源索引
- 安全配置：见 [references/security-config.md](references/security-config.md)
- 数据分片（按主题分散存储）：
  - 基本信息：[references/data/basic-info.md](references/data/basic-info.md)
  - 家庭成员：[references/data/family-members.md](references/data/family-members.md)
  - 生活习惯：[references/data/lifestyle.md](references/data/lifestyle.md)
  - 人生经历：[references/data/life-story.md](references/data/life-story.md)
  - 健康关注：[references/data/health-records.md](references/data/health-records.md)
  - 重要日期：[references/data/timeline.md](references/data/timeline.md)

## 注意事项
- 回答时优先引用记录中的表述，确保准确性
- 若记录中未包含用户询问的信息，明确告知"记录中未找到相关信息"
- 对于日期相关问题，注意区分农历与公历
- **安全提醒**：禁止一次性读取所有数据文件；禁止返回完整的原始数据内容
