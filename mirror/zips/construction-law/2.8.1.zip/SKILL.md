---
name: construction-law
description: Construction contract analysis for FIDIC, NEC, PSSCOC, SIA, and JCT — covering notices, claims, EOTs, SOP timelines, delay, risk allocation, and dispute pathways, with strong Singapore support. Use when (1) analysing contract clauses, risk allocation, or obligations; (2) preparing or reviewing claims (delay, disruption, prolongation, EOT, loss & expense); (3) comparing contract forms or advising on procurement strategy; (4) drafting or reviewing notices, correspondence, or contract documents; (5) building obligations registers or notice calendars; (6) discussing dispute resolution (DAB/DAAB, adjudication, arbitration, mediation, CAB); (7) Singapore-specific construction law (SOP Act, BCA, SIArb); (8) MDB procurement frameworks (ADB, World Bank). NOT for: non-construction commercial contracts, pure property/real-estate conveyancing, or insurance law. Also assists with QS measurement checking (BOQ review, quantity verification, rate analysis, unit consistency).
---

# Construction Law: FIDIC, NEC, PSSCOC, SIA Claims & Notices

Analyze construction contracts, claims, notices, payment timelines, risk allocation, and dispute pathways across major standard forms, with strong international and Singapore-focused coverage.

## Why install this?

- ✅ Avoid missed notice deadlines and time-bar mistakes
- ✅ Structure claims and EOT submissions faster
- ✅ Compare contract risk and obligations more consistently
- ✅ Prompts for the correct contract form **and edition** before analysis

## Who this skill is for

This skill is built for:

- Construction lawyers
- In-house counsel
- Contract managers
- Commercial managers
- Quantity surveyors
- Claims consultants
- Project managers

## What this skill does

Use this skill to:

- Identify the correct contract form and edition before analysis
- Review clauses for obligations, rights, risks, and time-bars
- Generate notice calendars and obligations registers
- Draft structured claim, EOT, variation, and payment templates
- Compare FIDIC forms across key topics
- Calculate Singapore SOP Act payment timelines
- Assess delay events, concurrency, EOT exposure, and LD risk
- Triage dispute resolution pathways

## Supported forms and frameworks

- FIDIC
- NEC
- PSSCOC
- SIA Conditions
- JCT
- Singapore SOP Act workflows

## Why this skill matters

Construction outcomes often turn on details such as:

- the exact contract form and edition
- amended or bespoke clauses
- notice timing
- record quality
- causation
- quantification
- governing law

This skill helps you structure analysis quickly and consistently so you can spot risks early and avoid missing critical deadlines.

> 🇸🇬 **Singapore matters — BCA circular awareness:** BCA frequently updates SOP Act timelines, plan fees, CORENET-X procedures, BC1/structural codes, cost-sharing schemes, productivity grants, and buildability rules through circulars at https://www1.bca.gov.sg/resources/circulars/. If you maintain a local mirror (e.g. `bca-circulars/` in your workspace, refreshed via a weekly heartbeat task), check it before relying on general knowledge. See `references/singapore.md` for details.
>
> ℹ️ This skill does not fetch live BCA updates itself. If you maintain a local circulars mirror in your workspace, use it as an up-to-date reference alongside the skill.

## Start here

### Recommended for all users: Matter Intake

The intake mode triages a construction issue and produces a professional report with clause buckets, deadline checks, amendment warnings, confidence labels, and recommended next steps.

```bash
python3 scripts/construction_law.py intake
# or
python3 scripts/intake.py
```

Supports non-interactive mode for automation:
```bash
python3 scripts/intake.py --file matter.json --output report.md --save-matter answers.json
```

Use non-interactive mode for repeatable internal workflows, templates, or batch matter intake.

### Sample Matter Intake output

Example: delay / EOT issue under FIDIC Red 1999

```text
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
 MATTER INTAKE — OUTPUT REPORT
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Contract:   FIDIC Red 1999
Governing:  Singapore
Party:      Contractor
Issue:      Delay / Extension of Time (EOT)
Objective:  Both EOT and additional payment

1. ISSUE SUMMARY
This appears to be a delay / EOT issue arising from late
access to site. The likely focus is notice compliance,
EOT entitlement, causation, and supporting records.

2. LIKELY CLAUSE BUCKETS
- Clause 2.1   Right of Access to Site
- Clause 8.4   Extension of Time
- Clause 20.1  Contractor's Claims

3. DEADLINE / TIME-BAR CHECK
Trigger:   Awareness of delaying event
Deadline:  28 days from awareness
Status:    ⚠️ Notice not confirmed
Risk:      Potential time-bar if late notice applies

4. AMENDMENT SENSITIVITY FLAGS
- Notice periods may be amended
- EOT wording may be narrowed
- Particular Conditions may override the standard form

5. RECOMMENDED NEXT STEPS
- confirm exact clause wording and edition
- verify whether notice was served in time
- gather programme and contemporaneous records
- prepare claim narrative and supporting documents

6. CONFIDENCE LABELS
Deadline calculation:      High confidence
Clause identification:     High confidence
Entitlement position:      Needs review

This is a workflow and analysis aid only. It is not legal advice.
```

### Interactive Wizard

For tool-specific tasks (notices, claims, SOP calculator, etc.), use the wizard:

```bash
python3 scripts/construction_law.py wizard
# or
python3 scripts/wizard.py
```

### For power users: Unified CLI

```bash
python3 scripts/construction_law.py --list
python3 scripts/construction_law.py notices --form fidic-red
python3 scripts/construction_law.py claims --form fidic-red --type disruption-claim
python3 scripts/construction_law.py sop --claim-date 2026-05-15
python3 scripts/construction_law.py compare --forms red,yellow --topic claims
python3 scripts/construction_law.py obligations --form fidic-red
python3 scripts/construction_law.py register --form fidic-red --type both --output reg.xlsx
python3 scripts/construction_law.py delay --baseline-start 2026-05-01 --baseline-end 2026-12-31
```

## Critical rule: always confirm the contract edition first

Before any clause analysis, confirm:

- contract form
- edition/year
- governing law
- amendments or particular conditions
- whether bespoke terms override the standard form

Do not assume the latest edition applies.

### Common editions still in use

- PSSCOC: 2017, 2020
- PSSCOC D&B: 2014, 2020
- FIDIC: 1999, 2017
- SIA: 9th Ed, 11th Ed
- NEC: NEC3, NEC4

## Core workflows

### 1. Clause analysis

For any clause question, this skill helps you:

- identify the relevant clause
- explain the obligation, entitlement, or risk
- flag notice periods and time-bars
- cross-reference related clauses
- highlight where amendments may change the default position

### 2. Claims and EOT analysis

For delay, disruption, prolongation, and related claims, use this structure:

1. Entitlement
2. Causation
3. Notice compliance
4. Substantiation
5. Quantification

### 3. Notice calendars

Build notice calendars that capture:

- clause reference
- trigger event
- notice period
- recipient
- consequence of non-compliance

### 4. Risk allocation review

Assess whether risk is allocated to the party best able to:

1. identify it
2. control it
3. mitigate it
4. absorb it

### 5. Delay and LD exposure

Review:

- delay event chronology
- criticality
- concurrency
- potential EOT entitlement
- potential liquidated damages exposure

## Included tools

### Interactive Wizard

Guided prompts for common tasks.

```bash
python3 scripts/wizard.py
```

### Notice Calendar Generator

Generate notice and obligations calendars.

```bash
python3 scripts/notice_calendar.py --form fidic-red --format md
python3 scripts/notice_calendar.py --form psscoc --format csv --output notices.csv
```

### Claims Template Generator

Generate structured templates for claim notices and related submissions.

```bash
python3 scripts/claims_template.py --list
python3 scripts/claims_template.py --form fidic-red --type notice-of-claim --output notice.md
python3 scripts/claims_template.py --form psscoc --type eot-application --output eot.md
```

### Obligations Register Generator

Create obligations registers by party and category.

```bash
python3 scripts/obligations_register.py --form fidic-red --party both --format md
python3 scripts/obligations_register.py --form psscoc --party contractor --format csv --output obligations.csv
```

### SOP Act Payment Timeline Calculator

Calculate statutory payment deadlines from a Singapore payment claim date.

```bash
python3 scripts/sop_calculator.py --claim-date 2026-06-30
python3 scripts/sop_calculator.py --claim-date 2026-06-30 --response-period 14 --format csv --output timeline.csv
```

### FIDIC Contract Comparator

Compare FIDIC forms side by side.

```bash
python3 scripts/fidic_comparator.py --forms red,yellow,silver --topic risk
python3 scripts/fidic_comparator.py --forms red,silver --topic all --format csv --output comparison.csv
```

Topics: `overview`, `risk`, `claims`, `disputes`, `payment`, `termination`, `all`

### Delay Analysis Calculator

Assess delay events, concurrency, EOT exposure, and LD risk.

```bash
python3 scripts/delay_calculator.py --baseline-start 2026-05-11 --baseline-end 2030-05-10 \
  --add "Late access|2026-06-01|2026-06-30|employer|critical" \
  --add "Weather|2026-07-15|2026-07-25|neutral|critical"
```

### Excel Register Generator

Export notice calendars and obligations registers to .xlsx.

```bash
python3 scripts/excel_register.py --form fidic-red --type both --output contract_admin.xlsx --commencement 2026-05-11
python3 scripts/excel_register.py --form psscoc --type obligations --output obligations.xlsx
```

Requires: `openpyxl` (`pip3 install openpyxl`)

## Example outputs

### Notice calendar — concrete sample

```
Clause:    FIDIC 20.2.1
Trigger:   Event giving rise to claim
Deadline:  28 days from awareness
Recipient: Engineer
Risk:      Late notice may prejudice entitlement (time-bar)
```

### Notice calendar — fields

- Clause reference
- Trigger event
- Notice deadline
- Recipient
- Time-bar consequence

### Claims template

- Background
- Contract basis
- Event chronology
- Causation
- Notice compliance
- Relief sought
- Reservation of rights
- Supporting documents

### Obligations register

- Clause
- Obligation
- Responsible party
- Timing
- Priority
- Status
- Notes

## Best use cases

- preliminary clause review
- contract administration checklists
- claim structure and document preparation
- notice and deadline tracking
- form comparison
- SOP timeline calculation
- delay event triage

## Important limitations

This skill is a workflow and analysis aid. It is not a substitute for legal advice.

Use caution where:

- the contract is heavily amended
- bespoke EPC or project-specific drafting applies
- governing law may materially change the outcome
- local statutory regimes override standard form assumptions
- adjudication, arbitration, or court submissions require final review

Always verify:

- the contract edition
- amendments and particular conditions
- governing law
- notice requirements
- jurisdiction-specific treatment of concurrency, good faith, prevention, and time-bars

## Key principles

- Read the contract first
- Standard form positions mean little if amended
- Time-bars can be fatal
- Notice compliance should be checked before merits
- Concurrency treatment differs by jurisdiction
- Good faith is jurisdiction-specific
- Prevention issues may affect LD exposure
- Fitness for purpose and reasonable skill and care must be distinguished carefully

## Reference files

- references/fidic.md
- references/singapore.md
- references/claims.md
- references/disputes.md
- references/procurement.md

## Live knowledge sources (Singapore)

For up-to-date Singapore regulatory context, consult the **BCA circulars page** — the authoritative source for changes to SOP Act timelines, plan fees, CORENET-X, BC1/structural codes, cost-sharing schemes, productivity grants, and buildability requirements:

- **Source:** https://www1.bca.gov.sg/resources/circulars/
- **Recommended setup:** Maintain a local PDF mirror (e.g. `bca-circulars/` in your workspace) refreshed weekly via a heartbeat or cron task. Track seen titles in a `seen.json` index to detect new circulars.

When advising on Singapore matters touching SOP Act timelines, plan fees, CORENET-X, BC1/structural codes, cost-sharing schemes, productivity grants, or buildability requirements, **check the latest circulars first** before relying on general knowledge — BCA updates can change deadlines, rates, and procedural requirements.

If your local mirror looks stale (>2 weeks old), trigger a fresh fetch.

## 🔒 Security and safety

All Python scripts in this skill are designed as safe, local template and register generators.

- ✅ **No network access** — no API calls, no HTTP requests, no telemetry
- ✅ **No subprocess execution** — no shell commands, no external programs
- ✅ **No dynamic code loading** — sibling scripts are imported as plain Python modules (no `importlib`, no `exec`, no `eval`)
- ✅ **No filesystem traversal** — only writes to the user-specified `--output` path
- ✅ **Read-only static reference data** — contract clauses bundled with the skill
- ✅ **ClawScan:** Benign
- ✅ **Static analysis:** Benign
- ℹ️ VirusTotal status is shown on the listing page

**Safe to install and use.** 🛡️

## Changelog

### v2.8.1 (May 2026) — SOP holiday correctness fix
- **Sunday → Monday in-lieu rule now applied automatically.** Under the Holidays Act 1998 s.4(2), when a public holiday falls on a Sunday the following Monday is a public holiday in lieu. The previous bundled holiday list missed four such Mondays (1 Jun 2026 — Vesak in-lieu; 10 Aug 2026 — National Day in-lieu; 9 Nov 2026 — Deepavali in-lieu; 8 Feb 2027 — CNY Day 2 in-lieu). The SOP day arithmetic now derives in-lieu Mondays from the gazetted Sunday holidays automatically, so future gazette updates won't drift.
- This affects any SOP timeline whose computed window crosses a Sunday public holiday — deadlines could be off by one day under v2.8.0 and earlier. Re-run any SOP timelines you generated previously if the period crossed those dates.

### v2.8.0 (May 2026)
- **FIDIC Yellow Book 2017 added as a fully-supported form.** All 7 claim templates now have fidic-yellow versions (notice-of-claim, eot-application, variation-claim, interim-claim, disruption-claim, loss-and-expense, final-account). Templates are tailored to Plant & Design-Build context: design responsibility (Cl. 5), Employer's Requirements (Cl. 1.9), milestone-based payment (Schedule of Payments), Tests after Completion (Cl. 12), and the 8.5 EOT grounds.
- **fidic-yellow obligations register added** — 33 contractor obligations (including design-specific clauses 5.1–5.8) and 12 employer obligations.
- **Excel register now produces fidic-yellow obligations sheets** in addition to notices.
- All new templates are edition-tagged in the HTML comment header and visible body.
- Full support matrix is now **28 combos** (7 claim types × 4 forms: fidic-red, fidic-yellow, psscoc, sia). NEC4 and JCT remain pending.

### v2.7.0 (May 2026)
- **6 new claim templates** filling the PSSCOC + SIA gap: `eot-application`, `variation-claim`, and `interim-claim` now have full PSSCOC (7th Ed., 2014 rev. 2020) and SIA (9th Ed., 2010 rep. 2016) versions.
- All new templates are **edition-tagged** in an HTML comment header and in the visible body, so users know exactly which standard form edition the clauses correspond to.
- Interim-claim templates explicitly dual-purpose as SOP Act s.10 payment claims with the s.10(3) requirements ticked off.
- Full support matrix is now **21 combos** (7 claim types × 3 forms).

### v2.6.0 (May 2026)
- **SOP calculator now holiday-aware.** Periods are computed in SOP days (excluding Singapore public holidays per SOP Act s.2 read with the Holidays Act 1998). Previously used calendar-day arithmetic which silently produced wrong dates around holiday clusters.
- **SOP timeline conceptual fix.** Removed misleading min/max determination and payment-due rows; replaced with single statutory deadlines and an explicit s.17(2) +7-day extension note.
- **Argparse no longer crashes** on `claims_template.py` for `fidic-yellow`, `nec4`, or `jct` — unsupported forms are now rejected at parse time with a pointer to `--list`. Unsupported (form, type) combos within registered forms also fail with a helpful message.
- **Excel register no longer writes half-empty workbooks.** Pre-flight coverage check refuses combos like `--form fidic-yellow --type obligations` and prints what is supported.
- **Version sprawl resolved.** New `scripts/version.py` is the single source of truth; intake.py / wizard.py / delay_calculator.py / sop_calculator.py footers all aligned to v2.6.

