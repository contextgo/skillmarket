#!/usr/bin/env python3
"""
Singapore SOP Act Payment Timeline Calculator (v2.8.1)

Calculates statutory deadlines from a payment claim date, correctly applying
the SOP Act s.2 definition of "day":

    "day" means any day other than a public holiday within the meaning
    of the Holidays Act 1998.

This means every period under the SOP Act excludes Singapore public holidays
(Saturdays and Sundays still count as "days"). Calendar-day arithmetic is wrong.

Usage:
    python3 sop_calculator.py --claim-date 2026-06-30
    python3 sop_calculator.py --claim-date 2026-06-30 --response-period 14
    python3 sop_calculator.py --claim-date 2026-06-30 --format csv --output sop_timeline.csv

Notes on the conceptual model (v2.6.0 fix):
- Adjudicator's determination is ONE deadline (s.17(1)(b)): 7 days, extendable
  by up to 7 days with claimant's consent. Earlier versions modelled this as a
  min/max range, which is incorrect — there is one determination per
  adjudication, not two. The output now shows a single determination row with
  the statutory window (7 days, with the +7 extension flagged).
- Payment of adjudicated amount (s.22(1)) is 7 days after determination — also
  one deadline, not a range.
"""

import argparse
import sys
from datetime import datetime, date, timedelta

try:
    from version import VERSION
except ImportError:
    VERSION = "2.6.0"

# Singapore public holidays — gazetted dates (Holidays Act 1998).
# Update each year via MOM gazette.
# Source: https://www.mom.gov.sg/employment-practices/public-holidays
#
# Holidays Act 1998, s.4(2): where a public holiday falls on a Sunday, the
# following Monday is a public holiday in lieu. We derive the Monday in-lieu
# entries automatically via _add_sunday_in_lieu() rather than listing them
# manually — this prevents drift if the gazette dates above are updated.
# (Saturday holidays do NOT automatically generate an in-lieu under the Act.)
_GAZETTED_HOLIDAYS = {
    # 2025
    date(2025, 1, 1),  date(2025, 1, 29), date(2025, 1, 30),
    date(2025, 3, 31), date(2025, 4, 18), date(2025, 5, 1),
    date(2025, 5, 12), date(2025, 6, 7),  date(2025, 8, 9),
    date(2025, 10, 20), date(2025, 12, 25),
    # 2026 (gazetted)
    date(2026, 1, 1),  date(2026, 2, 17), date(2026, 2, 18),
    date(2026, 3, 21), date(2026, 4, 3),  date(2026, 5, 1),
    date(2026, 5, 31), date(2026, 5, 27),  # Vesak Day, Hari Raya Haji
    date(2026, 8, 9),  date(2026, 11, 8),  date(2026, 12, 25),
    # 2027 (provisional — verify when gazetted)
    date(2027, 1, 1),  date(2027, 2, 6),  date(2027, 2, 7),
    date(2027, 3, 26), date(2027, 5, 1),  date(2027, 5, 11),
    date(2027, 5, 21), date(2027, 8, 9),  date(2027, 10, 28),
    date(2027, 12, 25),
}


def _add_sunday_in_lieu(holidays):
    """For every Sunday holiday, add the following Monday as an in-lieu day
    (Holidays Act 1998, s.4(2)). If the Monday is itself already gazetted as a
    holiday, the next non-holiday weekday is used to avoid losing a day."""
    result = set(holidays)
    for d in list(holidays):
        if d.weekday() == 6:  # Sunday
            candidate = d + timedelta(days=1)
            # If the Monday is itself a gazetted holiday, push to the next day
            # that isn't already a holiday (Sat/Sun are not skipped — they're
            # ordinary days under the Act unless gazetted).
            while candidate in result:
                candidate = candidate + timedelta(days=1)
            result.add(candidate)
    return result


SG_PUBLIC_HOLIDAYS = _add_sunday_in_lieu(_GAZETTED_HOLIDAYS)


def is_sop_day(d: date) -> bool:
    """SOP Act s.2: a 'day' is any day that is NOT a public holiday.
    Saturdays and Sundays count as days."""
    return d not in SG_PUBLIC_HOLIDAYS


def add_sop_days(start: date, n: int) -> date:
    """Add n SOP-Act days (skipping SG public holidays) to start.
    The start date itself is not counted (standard 'within N days' reckoning).
    """
    if n == 0:
        return start
    cur = start
    remaining = n
    while remaining > 0:
        cur = cur + timedelta(days=1)
        if is_sop_day(cur):
            remaining -= 1
    return cur


def calc_timeline(claim_date_str, response_period=21, fmt="md", output=None):
    claim_date = datetime.strptime(claim_date_str, "%Y-%m-%d").date()

    # Section 11: Payment Response — within `response_period` days of claim.
    response_deadline = add_sop_days(claim_date, response_period)

    # Section 12: Entitlement to adjudicate arises after the dispute settlement
    # period (typically 7 days from response deadline; conservatively flagged).
    dispute_period_end = add_sop_days(response_deadline, 7)

    # Section 13: Adjudication application — within 7 days of entitlement.
    adjudication_app_deadline = add_sop_days(dispute_period_end, 7)

    # Section 15: Adjudication response — 7 days from receipt of application.
    adjudication_response_deadline = add_sop_days(adjudication_app_deadline, 7)

    # Section 17(1)(b): Determination — within 7 days of response deadline,
    # extendable by up to 7 days with claimant's consent (s.17(2)).
    determination_deadline = add_sop_days(adjudication_response_deadline, 7)
    determination_extended = add_sop_days(adjudication_response_deadline, 14)

    # Section 22(1): Payment of adjudicated amount — within 7 days of receipt
    # of the determination.
    payment_due = add_sop_days(determination_deadline, 7)

    # Section 23: Direct payment from principal — claimant may seek if
    # respondent fails to pay by the payment due date.
    direct_payment_available = add_sop_days(payment_due, 1)

    smash_grab_note = (
        "If NO payment response is served by the respondent (s.11), the "
        "respondent CANNOT raise withholding reasons in adjudication "
        "(s.15(3)). This is the 'smash and grab' exposure."
    )

    timeline = [
        {"date": claim_date, "event": "Payment Claim served",
         "section": "s.10", "action": "Claimant", "critical": True,
         "note": "Must state claimed amount and be served on respondent. Triggers the SOP clock."},
        {"date": response_deadline, "event": "Payment Response deadline",
         "section": "s.11", "action": "Respondent", "critical": True,
         "note": f"Within {response_period} SOP days. FAILURE = smash-and-grab exposure."},
        {"date": dispute_period_end, "event": "Dispute settlement period ends / entitlement to adjudicate arises",
         "section": "s.12", "action": "Both parties", "critical": False,
         "note": "If unpaid or disputed, claimant may apply for adjudication from this point."},
        {"date": adjudication_app_deadline, "event": "Adjudication application deadline",
         "section": "s.13", "action": "Claimant", "critical": True,
         "note": "Within 7 SOP days of entitlement. MISS THIS = lose the right to adjudicate this claim cycle."},
        {"date": adjudication_response_deadline, "event": "Adjudication response deadline",
         "section": "s.15", "action": "Respondent", "critical": True,
         "note": "7 SOP days from receipt of application."},
        {"date": determination_deadline, "event": "Adjudicator's determination deadline",
         "section": "s.17(1)(b)", "action": "Adjudicator", "critical": True,
         "note": (f"7 SOP days from adjudication response deadline. "
                  f"Extendable to {determination_extended.strftime('%d %b %Y')} "
                  f"(+7 days) with claimant's written consent under s.17(2).")},
        {"date": payment_due, "event": "Payment of adjudicated amount due",
         "section": "s.22(1)", "action": "Respondent", "critical": True,
         "note": "7 SOP days from receipt of determination. Temporarily binding — pay now, argue later."},
        {"date": direct_payment_available, "event": "Direct payment from principal available",
         "section": "s.23", "action": "Claimant", "critical": False,
         "note": "If respondent fails to pay the adjudicated amount, claimant may seek direct payment from principal."},
    ]

    # Compute D+ labels in SOP days from the claim date
    def sop_days_between(a: date, b: date) -> int:
        if b <= a:
            return 0
        cnt, cur = 0, a
        while cur < b:
            cur += timedelta(days=1)
            if is_sop_day(cur):
                cnt += 1
        return cnt

    for t in timeline:
        t["day"] = sop_days_between(claim_date, t["date"])

    if fmt == "md":
        lines = [
            "# SOP Act Payment Timeline",
            "",
            f"**Payment Claim Date:** {claim_date.strftime('%d %B %Y')} ({claim_date.strftime('%A')})",
            f"**Payment Response Period:** {response_period} SOP days",
            f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            "",
            "> All deadlines are computed in **SOP days** — Singapore public holidays "
            "are excluded (SOP Act s.2 read with the Holidays Act 1998). "
            "Saturdays and Sundays are NOT excluded.",
            "",
            "---",
            "",
            "## Timeline",
            "",
            "| Day | Date | Event | Section | Action By | Critical |",
            "|-----|------|-------|---------|-----------|----------|",
        ]
        for t in timeline:
            critical = "⚠️ YES" if t["critical"] else ""
            day_str = f"D+{t['day']}" if t['day'] > 0 else "D0"
            lines.append(
                f"| {day_str} | {t['date'].strftime('%d %b %Y')} ({t['date'].strftime('%a')}) "
                f"| {t['event']} | {t['section']} | {t['action']} | {critical} |"
            )

        lines.extend([
            "",
            "## Notes per row",
            "",
        ])
        for t in timeline:
            lines.append(f"- **{t['event']}** ({t['section']}): {t['note']}")

        lines.extend([
            "",
            "## Key Warnings",
            "",
            "### ⚠️ Smash and Grab",
            smash_grab_note,
            "",
            "### ⚠️ Time-Bar",
            "Adjudication application must be made within **7 SOP days** of entitlement arising. "
            "Missing this deadline = lose the right to adjudicate for this payment claim cycle.",
            "",
            "### ⚠️ Temporarily Binding",
            "An adjudication determination is **temporarily binding** — pay now, argue later. "
            "The adjudicated amount must be paid even if the respondent intends to challenge "
            "it in arbitration or court.",
            "",
            "### ⚠️ Cannot Contract Out",
            "Section 36: any provision in a contract that purports to exclude, modify, or "
            "restrict the operation of the SOP Act is **void**.",
            "",
            "### ⚠️ Holiday data must be kept current",
            "This calculator uses gazetted Singapore public holidays. Confirm the holiday "
            "list for the relevant year is up to date before relying on the output. "
            "Source: https://www.mom.gov.sg/employment-practices/public-holidays",
            "",
            "---",
            f"*Generated by Construction Law Skill v{VERSION}*",
        ])

        result = "\n".join(lines)
        if output:
            with open(output, 'w') as f:
                f.write(result)
            print(f"Timeline written to {output}")
        else:
            print(result)

    elif fmt == "csv":
        import csv
        out = open(output, 'w', newline='') if output else sys.stdout
        writer = csv.writer(out)
        writer.writerow(["Payment Claim Date", claim_date.strftime('%Y-%m-%d')])
        writer.writerow(["Response Period (SOP days)", response_period])
        writer.writerow(["Note", "All periods exclude SG public holidays per SOP Act s.2"])
        writer.writerow([])
        writer.writerow(["Day", "Date", "Day of Week", "Event", "Section",
                         "Action By", "Critical", "Notes"])
        for t in timeline:
            day_str = f"D+{t['day']}" if t['day'] > 0 else "D0"
            writer.writerow([day_str, t['date'].strftime('%Y-%m-%d'),
                             t['date'].strftime('%A'), t['event'],
                             t['section'], t['action'],
                             "YES" if t['critical'] else "", t['note']])
        if output:
            out.close()
            print(f"CSV written to {output}")


def main():
    parser = argparse.ArgumentParser(
        description="Singapore SOP Act Payment Timeline Calculator (holiday-aware)")
    parser.add_argument("--claim-date", required=True, help="Payment claim date (YYYY-MM-DD)")
    parser.add_argument("--response-period", type=int, default=21,
                        help="Payment response period in SOP days (default: 21)")
    parser.add_argument("--format", default="md", choices=["md", "csv"], help="Output format")
    parser.add_argument("--output", "-o", help="Output file path")
    args = parser.parse_args()
    calc_timeline(args.claim_date, args.response_period, args.format, args.output)


if __name__ == "__main__":
    main()
