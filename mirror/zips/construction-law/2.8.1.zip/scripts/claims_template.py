#!/usr/bin/env python3
"""
Claims Letter / Notice Template Generator
Generates structured claim notices, EOT applications, and response letters
based on contract form and claim type.

Usage:
    python3 claims_template.py --form fidic-red --type notice-of-claim --output notice.md
    python3 claims_template.py --form psscoc --type eot-application --output eot.md
    python3 claims_template.py --form sia --type variation-claim --output vo_claim.md
    python3 claims_template.py --form fidic-red --type interim-claim --output interim.md
    python3 claims_template.py --form fidic-red --type disruption-claim --output disruption.md
    python3 claims_template.py --list
"""

import argparse
import sys
from datetime import datetime

TEMPLATES = {
    "notice-of-claim": {
        "title": "Notice of Claim",
        "description": "Initial notice to preserve entitlement (time-bar compliance)",
        "forms": {
            "fidic-red": {
                "clause": "20.2.1",
                "period": "28 days from awareness",
                "template": """# NOTICE OF CLAIM
## Under Clause 20.2.1 of the Conditions of Contract

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Engineer:** [Engineer Name]
**Date:** {date}
**Ref:** [Reference Number]

---

**Dear [Engineer/Engineer's Representative],**

**RE: NOTICE OF CLAIM UNDER CLAUSE 20.2.1 — [Brief Description of Claim]**

We refer to the above-captioned Contract and hereby give notice pursuant to **Sub-Clause 20.2.1** of the Conditions of Contract (FIDIC Red Book 2017 Edition).

### 1. EVENT OR CIRCUMSTANCE GIVING RISE TO THE CLAIM

[Describe the event or circumstance. Be specific about what happened, when it happened, and where.]

The Contractor became aware of this event/circumstance on **[date of awareness]**.

This Notice is given within **28 days** of the date on which the Contractor became aware of the event or circumstance, in compliance with Sub-Clause 20.2.1.

### 2. CONTRACTUAL BASIS

The Contractor considers that it is entitled to:

- [ ] Extension of Time under Sub-Clause [8.4 / 8.5 / other]
- [ ] Additional Payment (Cost) under Sub-Clause [___]
- [ ] Additional Payment (Cost + Profit) under Sub-Clause [___]

The relevant Sub-Clauses giving rise to this entitlement are:
- **Sub-Clause [___]**: [Brief description of entitlement basis]

### 3. PRELIMINARY ESTIMATE OF IMPACT

**Time impact:** [Estimated delay in days/weeks — if known at this stage]
**Cost impact:** [Preliminary estimate — if quantifiable at this stage]

*Note: These are preliminary estimates only. A fully detailed claim will be submitted in accordance with Sub-Clause 20.2.4 within 84 days of this Notice.*

### 4. SUPPORTING RECORDS

The Contractor is maintaining contemporary records in accordance with Sub-Clause 20.2.3, including:
- Daily site records
- Progress photographs
- Correspondence
- Programme updates
- Resource records
- [Other relevant records]

### 5. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract and at law, including but not limited to the right to submit further claims and to update the particulars and quantum of this claim.

This Notice is given **without prejudice** to any other rights or remedies available to the Contractor.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
[Name and Title]

---
*cc: [Employer] / [Other parties as required]*
"""
            },
            "psscoc": {
                "clause": "23(1)",
                "period": "28 days from commencement of delay event",
                "template": """# APPLICATION FOR EXTENSION OF TIME
## Under Clause 23(1) of PSSCOC

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Government Agency]
**Contractor:** [Contractor Name]
**Superintending Officer:** [SO Name]
**Date:** {date}
**Ref:** [Reference Number]

---

**Dear [Superintending Officer],**

**RE: APPLICATION FOR EXTENSION OF TIME UNDER CLAUSE 23(1) — [Brief Description]**

We refer to the above Contract and hereby apply for an Extension of Time pursuant to **Clause 23(1)** of the Public Sector Standard Conditions of Contract.

### 1. CAUSE OF DELAY

[Describe the delay event in detail — what happened, when, how it affects the works]

The delay event commenced on **[date]**.

This application is made within **28 days** from the commencement of the delay event, in compliance with Clause 23(1).

### 2. GROUNDS FOR EOT

The Contractor applies for EOT on the following grounds under Clause 23:
- [ ] Variation Orders
- [ ] Exceptionally adverse weather conditions
- [ ] Delay caused by the Employer or SO
- [ ] Civil commotion, strikes, lockouts
- [ ] Force majeure
- [ ] Other: [specify]

### 3. IMPACT ON PROGRAMME

**Current Completion Date:** [date]
**Estimated delay:** [number] days
**Requested Revised Completion Date:** [date]

**Critical path impact:** [Describe how the delay event affects the critical path]

### 4. MITIGATION MEASURES

The Contractor has taken / is taking the following steps to mitigate delay:
- [Measure 1]
- [Measure 2]
- [Measure 3]

### 5. SUPPORTING DOCUMENTS

Enclosed:
- [ ] Updated programme showing delay impact
- [ ] Site diary / daily records for affected period
- [ ] Relevant correspondence
- [ ] Photographs
- [ ] Weather records (if applicable)
- [ ] Resource records

### 6. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract including any entitlement to costs arising from the delay.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "sia": {
                "clause": "23",
                "period": "Written notice required",
                "template": """# APPLICATION FOR EXTENSION OF TIME
## Under Clause 23 of the SIA Conditions

**Contract:** [Contract Title]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Architect:** [Architect Name]
**Date:** {date}
**Ref:** [Reference Number]

---

**Dear [Architect],**

**RE: APPLICATION FOR EXTENSION OF TIME — [Brief Description]**

We refer to the above Contract and hereby apply for an Extension of Time pursuant to **Clause 23** of the SIA Conditions of Building Contract (9th Edition).

### 1. DELAY EVENT
[Description of event causing delay]

### 2. CONTRACTUAL BASIS
[Relevant sub-clause of Clause 23]

### 3. IMPACT
**Current Completion Date:** [date]
**Delay period:** [number] days
**Requested Revised Completion Date:** [date]

### 4. MITIGATION
[Steps taken to minimise delay]

### 5. SUPPORTING DOCUMENTS
[List of enclosed documents]

### 6. RESERVATION OF RIGHTS
The Contractor reserves all rights under the Contract.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "fidic-yellow": {
                "clause": "20.2.1",
                "period": "28 days from awareness",
                "template": """<!-- Edition: FIDIC Conditions of Contract for Plant and Design-Build, Second Edition 2017 (Yellow Book). Verify clause numbering if a different edition applies. -->
# NOTICE OF CLAIM
## Under Sub-Clause 20.2.1 — FIDIC Yellow Book 2017 (Plant & Design-Build)

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Engineer:** [Engineer Name]
**Date:** {date}
**Ref:** [Reference Number]

---

**Dear [Engineer / Engineer's Representative],**

**RE: NOTICE OF CLAIM UNDER SUB-CLAUSE 20.2.1 — [Brief Description of Claim]**

We refer to the above-captioned Contract and hereby give notice pursuant to **Sub-Clause 20.2.1** of the Conditions of Contract (FIDIC Yellow Book 2017, Plant and Design-Build).

### 1. EVENT OR CIRCUMSTANCE GIVING RISE TO THE CLAIM

[Describe the event or circumstance. Be specific about what happened, when it happened, and where. Where the event relates to design (Employer's Requirements / Contractor's design / interfacing with the Employer's other contractors), state this expressly.]

The Contractor became aware of this event/circumstance on **[date of awareness]**.

This Notice is given within **28 days** of the date on which the Contractor became aware of the event or circumstance, in compliance with Sub-Clause 20.2.1.

### 2. CONTRACTUAL BASIS

The Contractor considers that it is entitled to:

- [ ] Extension of Time for Completion under Sub-Clause 8.5
- [ ] Additional Payment (Cost / Cost Plus Profit) under Sub-Clause [___]
- [ ] Relief in respect of Tests after Completion under Sub-Clause 12.4
- [ ] Relief in respect of an error in the Employer's Requirements under Sub-Clause 1.9
- [ ] Other entitlement under the Contract: [identify]

### 3. DESIGN-RELATED CONSIDERATIONS (where applicable)

Where the claim concerns the Contractor's design or the Employer's Requirements, identify:
- The relevant clause of the Employer's Requirements
- Whether an error in the Employer's Requirements is alleged (Sub-Clause 1.9)
- Any impact on the Contractor's design review periods under Sub-Clause 5.2

### 4. RESERVATION OF RIGHTS

A fully detailed claim under Sub-Clause 20.2.4 will follow within 84 days of the date on which the Contractor became aware (or such other period as the Engineer may agree). The Contractor reserves the right to update or supplement this Notice and the detailed claim in accordance with the Contract.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            }
        }
    },
    "eot-application": {
        "title": "EOT Application (Detailed)",
        "description": "Detailed extension of time application with delay analysis",
        "forms": {
            "fidic-red": {
                "clause": "20.2.4",
                "period": "84 days from Notice of Claim",
                "template": """# FULLY DETAILED CLAIM — EXTENSION OF TIME
## Under Sub-Clause 20.2.4 of the Conditions of Contract

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Engineer:** [Engineer Name]
**Date:** {date}
**Ref:** [Reference Number]

**Notice of Claim Ref:** [Reference to original 20.2.1 notice]
**Notice of Claim Date:** [Date of original notice]

---

### 1. EXECUTIVE SUMMARY

This fully detailed claim is submitted pursuant to Sub-Clause 20.2.4, within 84 days of the Notice of Claim dated [date].

**Summary of claim:**
- Extension of Time: [number] days
- Additional Cost: $[amount]
- Profit (if applicable): $[amount]

### 2. FACTUAL BACKGROUND

#### 2.1 Contract Overview
- Contract Sum: $[amount]
- Original Completion Date: [date]
- Current Completion Date: [date] (as extended)
- Commencement Date: [date]

#### 2.2 Chronology of Events
| Date | Event | Reference |
|------|-------|-----------|
| [date] | [Event description] | [Letter/drawing/instruction ref] |
| [date] | [Event description] | [Reference] |

### 3. CONTRACTUAL ENTITLEMENT

#### 3.1 Relevant Contract Provisions
[Quote relevant clauses verbatim]

#### 3.2 Analysis of Entitlement
[Demonstrate how the facts satisfy each element of the clause]

#### 3.3 Notice Compliance
- Date of awareness: [date]
- Notice given: [date]
- Period: [X] days (within 28-day requirement)

### 4. CAUSATION — DELAY ANALYSIS

#### 4.1 Methodology
[State the delay analysis method used: TIA / Impacted As-Planned / Collapsed As-Built / Windows]

#### 4.2 Baseline Programme
[Reference the approved programme used as baseline]

#### 4.3 Delay Events
| Event | Start | End | Duration | Critical? |
|-------|-------|-----|----------|-----------|
| [Description] | [date] | [date] | [X] days | Yes/No |

#### 4.4 Critical Path Impact
[Demonstrate how delay events affected the critical path]

#### 4.5 Conclusion on Time
**Total delay to critical path: [X] days**
**EOT requested: [X] days**
**Revised Completion Date: [date]**

### 5. QUANTIFICATION — COSTS

#### 5.1 Prolongation Costs
| Item | Monthly Rate | Period | Amount |
|------|-------------|--------|--------|
| Site staff | $[amount] | [X] months | $[amount] |
| Site facilities | $[amount] | [X] months | $[amount] |
| Plant & equipment | $[amount] | [X] months | $[amount] |
| Insurance | $[amount] | [X] months | $[amount] |
| Bonds | $[amount] | [X] months | $[amount] |
| **Subtotal** | | | **$[amount]** |

#### 5.2 Head Office Overhead (Emden Formula)
```
HO Overhead = (Contract Sum / Contract Period) × (HO% / 100) × Delay Period
            = ($[amount] / [X] months) × ([X]% / 100) × [X] months
            = $[amount]
```

#### 5.3 Additional Direct Costs
[Itemise any additional costs directly caused by the delay event]

#### 5.4 Finance Charges
[Interest on delayed payments, if applicable]

#### 5.5 Profit (if entitled)
[Calculate profit element if Sub-Clause provides for Cost + Profit]

#### 5.6 Summary of Costs
| Head | Amount |
|------|--------|
| Prolongation costs | $[amount] |
| HO overhead | $[amount] |
| Additional direct costs | $[amount] |
| Finance charges | $[amount] |
| Profit | $[amount] |
| **TOTAL CLAIM** | **$[amount]** |

### 6. SUPPORTING DOCUMENTS

| Document | Reference |
|----------|-----------|
| Approved baseline programme | [ref] |
| Updated/as-built programme | [ref] |
| Daily site records | [ref] |
| Correspondence | [ref] |
| Photographs | [ref] |
| Cost records / invoices | [ref] |
| Weather records | [ref] |
| Resource records | [ref] |

### 7. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract and at law. This claim may be updated as further information becomes available.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "psscoc": {
                "clause": "14.2 / 14.3",
                "period": "Within 28 days of the delay event becoming apparent (Cl. 14.2 condition precedent)",
                "template": """<!-- Edition: PSSCOC for Construction Works (7th Edition, 2014, reprinted with amendments 2020). Verify clause numbering if a different edition applies. -->
# EXTENSION OF TIME APPLICATION
## Under Clause 14.2 (Notice) and Clause 14.3 (Particulars) — PSSCOC for Construction Works (7th Ed., 2014)

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Superintending Officer (SO):** [SO Name]
**Date:** {date}
**Ref:** [Reference Number]

**Notice of Delay Ref (Cl. 14.2):** [Reference to original 28-day notice]
**Notice of Delay Date:** [Date of original notice]

> **Important — condition precedent.** Under Clause 14.2, written notice within **28 days** of the delay event becoming apparent is a **condition precedent** to entitlement. Confirm notice compliance before relying on this submission.

---

### 1. EXECUTIVE SUMMARY

This particulars submission is made pursuant to Clause 14.3, supplementing the Contractor's Clause 14.2 Notice of Delay dated [date].

**Summary:**
- Extension of Time sought: [X] days
- Revised Date for Completion: [date]
- (Costs, if any, claimed separately under Cl. 22 / Cl. 23 — see related submission ref [_])

### 2. FACTUAL BACKGROUND

#### 2.1 Contract Overview
- Contract Sum: S$[amount]
- Date for Possession: [date]
- Original Date for Completion: [date]
- Current Date for Completion (as previously extended): [date]

#### 2.2 Chronology of the Delay Event
| Date | Event | Reference |
|------|-------|-----------|
| [date] | [Event description] | [SO instruction / letter / drawing] |
| [date] | [Event description] | [Reference] |
| [date] | Notice of Delay served (Cl. 14.2) | [Reference] |

### 3. CONTRACTUAL ENTITLEMENT — RELEVANT EVENT

#### 3.1 Relevant Event Relied On
Clause 14.2 lists the qualifying delay events. The event(s) relied on:
- [ ] (a) Force majeure
- [ ] (b) Exceptionally adverse weather
- [ ] (c) Loss or damage from Excepted Risks
- [ ] (d) Civil commotion / strike / lockout
- [ ] (e) Compliance with SO's instructions (other than for Contractor's default)
- [ ] (f) Late receipt of further drawings or instructions where requested in good time
- [ ] (g) Delay by Employer / nominated subcontractor / supplier
- [ ] (h) Delay caused by other contractors employed by Employer
- [ ] (i) Failure to give possession of the Site or part thereof
- [ ] (j) Suspension under Clause 16
- [ ] (k) Any other ground for which the Contract entitles EOT

#### 3.2 Notice Compliance (Cl. 14.2)
- Date the delay became reasonably apparent: [date]
- Notice of Delay served: [date]
- Period elapsed: [X] days (must be within 28 days)
- **Condition precedent satisfied:** [Yes / No — explain]

#### 3.3 Particulars Submission (Cl. 14.3)
- Notice date + 28 days: [date]
- This particulars submission served: [date]
- Within 28 days of Notice: [Yes / No]

### 4. DELAY ANALYSIS

#### 4.1 Methodology
[State method: Time Impact Analysis / Impacted As-Planned / Collapsed As-Built / Windows. Explain choice having regard to programme quality and records available.]

#### 4.2 Baseline Programme
[Identify the approved programme under Clause 13 used as baseline; revision number; SO acceptance ref/date]

#### 4.3 Delay Event Impact
| Event | Start | End | Activity Affected | Float Available | Critical? |
|-------|-------|-----|-------------------|-----------------|-----------|
| [Description] | [date] | [date] | [Activity ID] | [X] days | Yes/No |

#### 4.4 Critical Path Impact
[Demonstrate how the relevant event affected the critical path; identify shifted longest path]

#### 4.5 Conclusion on Time
**Net delay to critical path: [X] days**
**EOT applied for: [X] days**
**Revised Date for Completion: [date]**

### 5. CONCURRENT DELAY (if applicable)

[Address any concurrent contractor-culpable delay. Note: PSSCOC does not codify a concurrency rule; common-law principles (Henry Boot / Walter Lilly approach) generally apply for time, with apportionment for cost.]

### 6. SUPPORTING DOCUMENTS

| Document | Reference |
|----------|-----------|
| Cl. 14.2 Notice of Delay | [ref] |
| Approved baseline programme | [ref] |
| Updated / as-built programme | [ref] |
| SO instructions relied on | [ref] |
| Daily site records | [ref] |
| Correspondence | [ref] |
| Weather records (if Cl. 14.2(b)) | [ref] |
| Photographs | [ref] |

### 7. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract, the Building and Construction Industry Security of Payment Act 2004, and at common law. This submission may be updated as further information becomes available, including any continuing effect of the delay event under Cl. 14.3.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "sia": {
                "clause": "23(1) and 23(2)",
                "period": "As soon as practicable after the cause of delay arises (Cl. 23(2))",
                "template": """<!-- Edition: SIA Conditions of Building Contract (Lump Sum Contract), 9th Edition (2010, reprinted September 2016). Verify clause numbering if a different edition applies. -->
# EXTENSION OF TIME APPLICATION
## Under Clause 23 — SIA Conditions of Building Contract (Lump Sum), 9th Ed. (2010, reprinted 2016)

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Architect:** [Architect Name]
**Date:** {date}
**Ref:** [Reference Number]

> **Important — notice and timing.** Under Cl. 23(2), written notice of delay must be given to the Architect **as soon as practicable** after the cause of delay arises (and in any event before the Date for Completion). Unlike PSSCOC Cl. 14.2, SIA does not impose a strict 28-day condition precedent, but late notice may prejudice causation evidence and the Architect's discretion.

---

### 1. EXECUTIVE SUMMARY

This application for extension of time is made under Clause 23.

**Summary:**
- Extension of Time sought: [X] weeks / days
- Revised Date for Completion: [date]
- (Loss & Expense, if any, claimed separately under Cl. 23(1)(q) read with Cl. 24 — see related submission ref [_])

### 2. FACTUAL BACKGROUND

#### 2.1 Contract Overview
- Contract Sum: S$[amount]
- Date for Possession: [date]
- Original Date for Completion: [date]
- Current Date for Completion (as previously extended): [date]

#### 2.2 Chronology of the Delay Event
| Date | Event | Reference |
|------|-------|-----------|
| [date] | [Event description] | [Architect's instruction / letter] |
| [date] | Notice of Delay served (Cl. 23(2)) | [Reference] |

### 3. RELEVANT EVENT — CL. 23(1)

The Contractor relies on the following ground(s) listed in Clause 23(1):

- [ ] (a) Force majeure
- [ ] (b) Inclement weather
- [ ] (c) Loss or damage by Excepted Risks
- [ ] (d) Civil commotion / strike / lockout
- [ ] (e) Architect's instructions other than for Contractor's default
- [ ] (f) Late receipt of necessary drawings, instructions or levels (where requested in good time)
- [ ] (g) Delay by Nominated Subcontractor / Nominated Supplier
- [ ] (h) Work by Employer's other contractors
- [ ] (i) Employer's failure to give possession of Site
- [ ] (j) Suspension of the Works
- [ ] (k) Variations under Clause 12
- [ ] (q) Any other matter giving rise to loss and expense entitling the Contractor to time
- [ ] Any other ground entitling EOT under the Contract

### 4. NOTICE OF DELAY — CL. 23(2)

- Date the cause of delay arose: [date]
- Date the Contractor became aware: [date]
- Notice of Delay served: [date]
- Particulars of expected effect provided: [date]

### 5. DELAY ANALYSIS

#### 5.1 Methodology
[State method used and reasons for choice.]

#### 5.2 Baseline Programme
[Identify accepted programme used as baseline.]

#### 5.3 Delay Event Impact
| Event | Start | End | Activity Affected | Float | Critical? |
|-------|-------|-----|-------------------|-------|-----------|
| [Description] | [date] | [date] | [Activity ID] | [X] days | Yes/No |

#### 5.4 Critical Path Impact
[Demonstrate impact on the critical path; identify the longest path post-impact.]

#### 5.5 Conclusion on Time
**Net delay to critical path: [X] days**
**EOT applied for: [X] weeks / days**
**Revised Date for Completion: [date]**

### 6. CONCURRENT DELAY (if applicable)

[Address any concurrent contractor-culpable delay. Singapore courts have generally followed common-law principles; SIA does not codify concurrency. Consider Malmaison-style approach for time and apportionment for any associated loss and expense.]

### 7. SUPPORTING DOCUMENTS

| Document | Reference |
|----------|-----------|
| Cl. 23(2) Notice of Delay | [ref] |
| Accepted programme | [ref] |
| Updated / as-built programme | [ref] |
| Architect's instructions relied on | [ref] |
| Daily site records | [ref] |
| Correspondence | [ref] |
| Weather records (if Cl. 23(1)(b)) | [ref] |
| Photographs | [ref] |

### 8. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract, the Building and Construction Industry Security of Payment Act 2004, and at common law. This application may be updated as further information becomes available.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "fidic-yellow": {
                "clause": "20.2.4 read with 8.5",
                "period": "84 days from Notice of Claim",
                "template": """<!-- Edition: FIDIC Conditions of Contract for Plant and Design-Build, Second Edition 2017 (Yellow Book). Verify clause numbering if a different edition applies. -->
# FULLY DETAILED CLAIM — EXTENSION OF TIME
## Under Sub-Clause 20.2.4 read with Sub-Clause 8.5 — FIDIC Yellow Book 2017

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Engineer:** [Engineer Name]
**Date:** {date}
**Ref:** [Reference Number]

**Notice of Claim Ref:** [Reference to original 20.2.1 notice]
**Notice of Claim Date:** [Date of original notice]

---

### 1. EXECUTIVE SUMMARY

This fully detailed claim is submitted pursuant to Sub-Clause 20.2.4, within 84 days of the Notice of Claim dated [date], and engages Sub-Clause 8.5 (Extension of Time for Completion).

**Summary of claim:**
- Extension of Time: [number] days
- Additional Cost (Cost / Cost Plus Profit per Sub-Clause invoked): $[amount]

### 2. RELEVANT GROUND UNDER SUB-CLAUSE 8.5

The Contractor relies on the following ground(s) under Sub-Clause 8.5:

- [ ] (a) A Variation
- [ ] (b) A cause of delay giving an entitlement to EOT under a Sub-Clause of these Conditions
- [ ] (c) Exceptionally adverse climatic conditions
- [ ] (d) Unforeseeable shortages in personnel or Goods caused by epidemic or governmental action
- [ ] (e) Any delay, impediment or prevention caused by or attributable to the Employer, Employer's Personnel, or Employer's other contractors
- [ ] (f) Any other matter listed in the Contract or in the Contract Data

### 3. DESIGN-RELATED CONSIDERATIONS

Where the delay engages the Contractor's design or interfaces with the Employer's Requirements, address:
- The clause(s) in Employer's Requirements relied on
- Any error in the Employer's Requirements (Sub-Clause 1.9) and the Engineer's response
- Whether design review periods (Sub-Clause 5.2) contributed to the critical-path impact
- Any redesign required and its sequencing impact

### 4. CAUSATION — DELAY ANALYSIS

#### 4.1 Methodology
[State delay analysis method used: TIA / Impacted As-Planned / Collapsed As-Built / Windows. Justify choice.]

#### 4.2 Baseline Programme
[Reference the accepted programme used as baseline; revision and Engineer's review status.]

#### 4.3 Delay Events
| Event | Start | End | Duration | Critical? |
|-------|-------|-----|----------|-----------|
| [Description] | [date] | [date] | [X] days | Yes/No |

#### 4.4 Critical Path Impact
[Demonstrate how delay events affected the critical path, including any shift in the longest path.]

#### 4.5 Conclusion on Time
**Total delay to critical path: [X] days**
**EOT requested: [X] days**
**Revised Time for Completion: [date]**

### 5. QUANTIFICATION

| Head | Sub-Clause / Basis | Amount |
|------|---------------------|--------|
| Prolongation costs (site staff, plant, facilities, insurance, bonds) | Cl. 8.5 + applicable Sub-Clause | $[amount] |
| Head office overhead (Emden / Hudson / Eichleay) | Established formula | $[amount] |
| Design / redesign cost (Yellow Book specific) | Cl. 5 + applicable Sub-Clause | $[amount] |
| Additional direct costs | Cost records | $[amount] |
| Finance charges | Cl. 14 | $[amount] |
| Profit (where Cost Plus Profit applies) | Sub-Clause invoked | $[amount] |
| **TOTAL** | | **$[amount]** |

### 6. SUPPORTING DOCUMENTS

| Document | Reference |
|----------|-----------|
| Notice of Claim (Sub-Clause 20.2.1) | [ref] |
| Approved baseline programme | [ref] |
| Updated / as-built programme | [ref] |
| Engineer's instructions and review responses (Sub-Clause 5.2) | [ref] |
| Daily site records | [ref] |
| Weather records (if Cl. 8.5(c)) | [ref] |
| Contemporaneous correspondence | [ref] |
| Cost records / payroll / invoices | [ref] |

### 7. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract and at law. This claim may be updated as further information becomes available, including any continuing or further effects of the relevant event.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            }
        }
    },
    "variation-claim": {
        "title": "Variation Valuation Claim",
        "description": "Claim for valuation of instructed variation",
        "forms": {
            "fidic-red": {
                "clause": "13.3",
                "period": "Per Engineer's instruction",
                "template": """# VARIATION VALUATION
## Under Sub-Clause 13.3 of the Conditions of Contract

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Variation Instruction Ref:** [Reference]
**Variation Instruction Date:** [Date]
**Date:** {date}
**Ref:** [Reference Number]

---

### 1. VARIATION INSTRUCTION

On [date], the Engineer issued [Instruction/Direction] Ref: [reference] instructing the following variation:

[Describe the variation — what work is added/omitted/changed]

### 2. VALUATION BASIS

The Contractor proposes the following valuation in accordance with Sub-Clause 13.3:

#### 2.1 Applicable Rates
- [ ] Contract rates (applicable to similar work)
- [ ] New rates (no similar work in BOQ)
- [ ] Daywork rates

#### 2.2 Breakdown

| Item | Description | Qty | Unit | Rate | Amount |
|------|-------------|-----|------|------|--------|
| 1 | [Description] | [qty] | [unit] | $[rate] | $[amount] |
| 2 | [Description] | [qty] | [unit] | $[rate] | $[amount] |
| | **Subtotal** | | | | **$[amount]** |
| | Profit & Overhead [X]% | | | | $[amount] |
| | **TOTAL** | | | | **$[amount]** |

### 3. TIME IMPACT

**Does this variation affect the programme?**
- [ ] Yes — EOT claim to follow under Clause 20.2
- [ ] No — variation can be absorbed within current programme

### 4. SUPPORTING DOCUMENTS

- [ ] Engineer's variation instruction
- [ ] Drawings / specifications
- [ ] Quotations from suppliers/subcontractors
- [ ] Rate build-up / cost breakdown
- [ ] Programme showing impact (if applicable)

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "psscoc": {
                "clause": "19.1 (Variations) and 20 (Valuation)",
                "period": "Per SO's directions and Cl. 20 valuation rules",
                "template": """<!-- Edition: PSSCOC for Construction Works (7th Edition, 2014, reprinted with amendments 2020). Verify clause numbering if a different edition applies. -->
# VARIATION VALUATION
## Under Clause 19 (Variations) and Clause 20 (Valuation of Variations) — PSSCOC for Construction Works (7th Ed., 2014)

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**SO Direction Ref (Cl. 19):** [Reference]
**SO Direction Date:** [Date]
**Date:** {date}
**Ref:** [Reference Number]

---

### 1. SUMMARY OF VARIATION

| Item | Detail |
|------|--------|
| SO Direction Ref | [ref] |
| Description | [Brief description of varied work] |
| Type | [ ] Addition  [ ] Omission  [ ] Substitution  [ ] Change in sequence/timing |
| Date directed | [date] |
| Date executed | [date / range] |
| Net value | S$[amount] |

### 2. CONTRACTUAL BASIS

#### 2.1 SO's Power to Direct Variations (Cl. 19.1)
The SO directed the variation by [SO Direction / Letter / Site Instruction] dated [date].

#### 2.2 Confirmation of Oral Direction (if applicable)
Where the direction was given orally, it was confirmed in writing within 7 days under Clause 19.4 by [reference].

### 3. VALUATION RULES — CLAUSE 20

Cl. 20 sets the order of priority for valuation:

- [ ] **Cl. 20.1(a) — Bill of Quantities / Schedule of Rates apply** (work of similar character, executed under similar conditions)
- [ ] **Cl. 20.1(b) — BQ rates as basis** (similar character but different conditions; rates adjusted)
- [ ] **Cl. 20.1(c) — Fair valuation** (work not of similar character; new rates/prices)
- [ ] **Cl. 20.2 — Daywork** (where SO so directs and work cannot otherwise be valued)

### 4. VALUATION DETAIL

#### 4.1 Quantities
| Item | Description | Unit | Qty | Source |
|------|-------------|------|-----|--------|
| [No.] | [Description] | [unit] | [qty] | [Drawing/measurement ref] |

#### 4.2 Rate Build-Up
| Item | Description | Unit | Rate (S$) | Source / Justification |
|------|-------------|------|-----------|------------------------|
| [No.] | [Description] | [unit] | [rate] | [BQ ref / Quotation / First-principles build-up] |

#### 4.3 Total Variation Value
| Item | Description | Qty | Rate (S$) | Amount (S$) |
|------|-------------|-----|-----------|-------------|
| [No.] | [Description] | [qty] | [rate] | [amount] |
| | | | **Subtotal** | **[amount]** |
| | | | Adjustments (preliminaries, OH&P) | [amount] |
| | | | **TOTAL** | **[amount]** |

### 5. PROGRAMME / TIME IMPACT

- [ ] No impact on Date for Completion
- [ ] EOT required — separate Cl. 14.2 Notice of Delay served, ref [_]

### 6. SUPPORTING DOCUMENTS

- SO Direction (Cl. 19) — ref [_]
- Confirmation of oral direction (if applicable, Cl. 19.4) — ref [_]
- Drawings / specifications — ref [_]
- Quotations from sub-contractors / suppliers — ref [_]
- Rate build-up working papers — ref [_]
- Daywork sheets (if Cl. 20.2 valuation) — ref [_]
- Programme impact analysis (if applicable) — ref [_]

### 7. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract, including any further valuation adjustments under Clause 20 and time-related entitlements under Clause 14.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "sia": {
                "clause": "12 (Variations) and 12(3) (Valuation)",
                "period": "Per Architect's instructions and Cl. 12(3) valuation rules",
                "template": """<!-- Edition: SIA Conditions of Building Contract (Lump Sum Contract), 9th Edition (2010, reprinted September 2016). Verify clause numbering if a different edition applies. -->
# VARIATION VALUATION
## Under Clause 12 — SIA Conditions of Building Contract (Lump Sum), 9th Ed. (2010, reprinted 2016)

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Architect's Instruction (AI) Ref:** [Reference]
**AI Date:** [Date]
**Date:** {date}
**Ref:** [Reference Number]

---

### 1. SUMMARY OF VARIATION

| Item | Detail |
|------|--------|
| Architect's Instruction Ref | [ref] |
| Description | [Brief description of varied work] |
| Type | [ ] Addition  [ ] Omission  [ ] Substitution  [ ] Change in sequence/timing |
| Date instructed | [date] |
| Date executed | [date / range] |
| Net value | S$[amount] |

### 2. CONTRACTUAL BASIS

#### 2.1 Architect's Authority to Order Variations (Cl. 1 and Cl. 12)
The Architect issued AI ref [_] dated [date] requiring the variation.

#### 2.2 Confirmation of Oral Instruction (if applicable)
Where the instruction was given orally, it has been confirmed in writing in accordance with Clause 1.

### 3. VALUATION RULES — CLAUSE 12(3)

Cl. 12(3) sets the priority for valuation:

- [ ] **Cl. 12(3)(a) — Contract rates apply** (work of similar character executed under similar conditions)
- [ ] **Cl. 12(3)(b) — Contract rates as basis** (similar character but different conditions; fair adjustment)
- [ ] **Cl. 12(3)(c) — Fair valuation / fair rates and prices** (work not of similar character)
- [ ] **Cl. 12(4) — Daywork** (where the Architect so directs)

### 4. VALUATION DETAIL

#### 4.1 Quantities
| Item | Description | Unit | Qty | Source |
|------|-------------|------|-----|--------|
| [No.] | [Description] | [unit] | [qty] | [Drawing / measurement] |

#### 4.2 Rate Build-Up
| Item | Description | Unit | Rate (S$) | Source / Justification |
|------|-------------|------|-----------|------------------------|
| [No.] | [Description] | [unit] | [rate] | [Contract Sum analysis / Quotation / First principles] |

#### 4.3 Total Variation Value
| Item | Description | Qty | Rate (S$) | Amount (S$) |
|------|-------------|-----|-----------|-------------|
| [No.] | [Description] | [qty] | [rate] | [amount] |
| | | | **Subtotal** | **[amount]** |
| | | | Adjustments (preliminaries, OH&P) | [amount] |
| | | | **TOTAL** | **[amount]** |

### 5. PROGRAMME / TIME IMPACT

- [ ] No impact on Date for Completion
- [ ] EOT required — separate Cl. 23(2) Notice of Delay served, ref [_]
- [ ] Loss & Expense follows under Cl. 23(1)(q) and Cl. 24, ref [_]

### 6. SUPPORTING DOCUMENTS

- Architect's Instruction — ref [_]
- Drawings / specifications — ref [_]
- Quotations from sub-contractors / suppliers — ref [_]
- Rate build-up working papers — ref [_]
- Daywork sheets (if Cl. 12(4) valuation) — ref [_]
- Programme impact analysis (if applicable) — ref [_]

### 7. RESERVATION OF RIGHTS

The Contractor reserves all rights under the Contract and at law, including further adjustments under Cl. 12(3) and any associated time / loss and expense entitlements under Cl. 23 / Cl. 24.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "fidic-yellow": {
                "clause": "13.3",
                "period": "Per Engineer's instruction / RFP",
                "template": """<!-- Edition: FIDIC Conditions of Contract for Plant and Design-Build, Second Edition 2017 (Yellow Book). Verify clause numbering if a different edition applies. -->
# VARIATION VALUATION
## Under Sub-Clause 13.3 — FIDIC Yellow Book 2017

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Variation Instruction Ref:** [Reference]
**Variation Instruction Date:** [Date]
**Date:** {date}
**Ref:** [Reference Number]

---

### 1. SUMMARY OF VARIATION

| Item | Detail |
|------|--------|
| Variation Ref | [ref] |
| Description | [Brief description of varied work] |
| Type | [ ] Addition  [ ] Omission  [ ] Substitution  [ ] Change to Employer's Requirements  [ ] Change in sequence/timing |
| Date instructed | [date] |
| Date executed | [date / range] |
| Net value | $[amount] |

### 2. CONTRACTUAL BASIS

#### 2.1 Initiation Route (Sub-Clause 13.1 / 13.3)
The Variation was initiated by:
- [ ] Engineer's Variation Instruction under Sub-Clause 13.1
- [ ] Engineer's Request for Proposal under Sub-Clause 13.3.2
- [ ] Value Engineering proposal by Contractor under Sub-Clause 13.2

#### 2.2 Design Impact (Yellow Book specific)
Where the Variation alters the Employer's Requirements or the Contractor's design, set out:
- The change to Employer's Requirements (clause / drawing / spec)
- Redesign required and design effort cost
- Fitness-for-purpose implications under Sub-Clause 4.1
- Any additional review period required under Sub-Clause 5.2

### 3. VALUATION RULES — SUB-CLAUSE 13.3.1

Valuation follows the priority:
- [ ] (a) Sums and rates quoted in the Schedules apply
- [ ] (b) Sums and rates in the Schedules used as basis with reasonable adjustment
- [ ] (c) Fair valuation by the Engineer
- [ ] Daywork under the Daywork Schedule (where applicable)

### 4. VALUATION DETAIL

#### 4.1 Quantities
| Item | Description | Unit | Qty | Source |
|------|-------------|------|-----|--------|
| [No.] | [Description] | [unit] | [qty] | [Drawing / measurement / Employer's Requirements ref] |

#### 4.2 Rate Build-Up
| Item | Description | Unit | Rate | Source / Justification |
|------|-------------|------|------|------------------------|
| [No.] | [Description] | [unit] | $[rate] | [Schedule rate / Quotation / First-principles build-up] |

#### 4.3 Total Variation Value
| Item | Description | Qty | Rate | Amount |
|------|-------------|-----|------|--------|
| [No.] | [Description] | [qty] | $[rate] | $[amount] |
| | | | **Subtotal** | **$[amount]** |
| | | | Adjustments (preliminaries, OH&P, design effort) | $[amount] |
| | | | **TOTAL** | **$[amount]** |

### 5. PROGRAMME / TIME IMPACT

- [ ] No impact on Time for Completion
- [ ] EOT required — Notice of Claim under Sub-Clause 20.2.1 served, ref [_]

### 6. SUPPORTING DOCUMENTS

- Variation Instruction / Request for Proposal
- Drawings / revised Employer's Requirements
- Quotations from sub-contractors / suppliers
- Rate build-up working papers
- Daywork sheets (if applicable)
- Programme impact analysis (if applicable)
- Design effort records (where redesign engaged)

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            }
        }
    },
    "interim-claim": {
        "title": "Interim Claim Statement",
        "description": "Progress claim / interim payment application",
        "forms": {
            "fidic-red": {
                "clause": "14.3",
                "period": "Monthly",
                "template": """# INTERIM PAYMENT APPLICATION No. [X]
## Under Sub-Clause 14.3 of the Conditions of Contract

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Period:** [Start Date] to [End Date]
**Date:** {date}
**Ref:** [Reference Number]

---

### SUMMARY

| Item | Amount |
|------|--------|
| A. Work done to date | $[amount] |
| B. Materials on site | $[amount] |
| C. Approved variations | $[amount] |
| D. Claims (assessed) | $[amount] |
| E. Price adjustments | $[amount] |
| **F. Gross valuation (A+B+C+D+E)** | **$[amount]** |
| G. Less retention [X]% | ($[amount]) |
| **H. Net valuation** | **$[amount]** |
| I. Less previous certifications | ($[amount]) |
| **J. Amount due this certificate** | **$[amount]** |

### BREAKDOWN OF WORK DONE

| BOQ Ref | Description | Contract Qty | Completed Qty | Rate | Amount |
|---------|-------------|-------------|---------------|------|--------|
| [ref] | [description] | [qty] | [qty] | $[rate] | $[amount] |

### VARIATIONS INCLUDED

| VO No. | Description | Amount |
|--------|-------------|--------|
| VO-[X] | [Description] | $[amount] |

### CLAIMS INCLUDED

| Claim No. | Description | Amount |
|-----------|-------------|--------|
| CLM-[X] | [Description] | $[amount] |

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "psscoc": {
                "clause": "32 (Interim Payments)",
                "period": "Monthly, on the date stipulated in the Contract; SOP Act parallel right under s.10",
                "template": """<!-- Edition: PSSCOC for Construction Works (7th Edition, 2014, reprinted with amendments 2020). Verify clause numbering if a different edition applies. -->
# INTERIM PAYMENT CLAIM
## Under Clause 32 — PSSCOC for Construction Works (7th Ed., 2014)
## (and also constituting a Payment Claim under s.10 of the Building and Construction Industry Security of Payment Act 2004)

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Superintending Officer (SO):** [SO Name]
**Payment Claim No.:** [No.]
**Period to which claim relates:** [start] to [end]
**Date of submission:** {date}
**Ref:** [Reference Number]

> This document is intended to operate concurrently as (a) a monthly interim payment application under Cl. 32 PSSCOC, and (b) a payment claim under s.10 of the Building and Construction Industry Security of Payment Act 2004 ("SOP Act"). The reference period and amounts are stated to satisfy s.10(3).

---

### 1. CONTRACT SUM RECONCILIATION

| Item | Amount (S$) |
|------|-------------|
| Original Contract Sum | [amount] |
| Add: Variations approved to date | [amount] |
| Add: Claims admitted to date | [amount] |
| Less: Omissions to date | [amount] |
| **Adjusted Contract Sum** | **[amount]** |

### 2. VALUATION OF WORK DONE

#### 2.1 Bill of Quantities Items
| BQ Ref | Description | Unit | BQ Qty | Rate (S$) | Cumulative Qty Done | Cumulative Value (S$) |
|--------|-------------|------|--------|-----------|----------------------|------------------------|
| [ref] | [description] | [unit] | [qty] | [rate] | [qty] | [amount] |

#### 2.2 Variations Included
| VO No. | Description | Cumulative Value (S$) |
|--------|-------------|------------------------|
| VO-[X] | [Description] | [amount] |

#### 2.3 Materials On-Site (Cl. 32 / contract conditions)
| Item | Quantity | Value (S$) | Vesting / Insurance Status |
|------|----------|-------------|----------------------------|
| [Description] | [qty] | [amount] | [Vested / Insured / Off-site approved] |

#### 2.4 Claims Included
| Claim No. | Description | Cumulative Value (S$) |
|-----------|-------------|------------------------|
| CLM-[X] | [Description] | [amount] |

### 3. SUMMARY — AMOUNT CLAIMED

| Heading | Amount (S$) |
|---------|-------------|
| Cumulative gross value of permanent work done | [amount] |
| Cumulative value of variations | [amount] |
| Cumulative value of materials on-site | [amount] |
| Cumulative value of claims | [amount] |
| **Cumulative Gross Valuation** | **[amount]** |
| Less: Retention (per Contract) | ([amount]) |
| Less: Previous Payments certified | ([amount]) |
| Less: Adjustments / set-offs notified by SO | ([amount]) |
| **Amount Now Claimed (excl. GST)** | **[amount]** |
| Add: GST @ [rate]% | [amount] |
| **TOTAL AMOUNT CLAIMED (incl. GST)** | **[amount]** |

### 4. SOP ACT REQUIREMENTS — SECTION 10

- [x] Identifies the Contract: [Contract title and reference]
- [x] Identifies the work to which it relates: [reference period]
- [x] States the claimed amount: S$[amount]
- [x] Served on the Respondent: [Employer name]
- [x] Reference period: [start] to [end]

### 5. SUPPORTING DOCUMENTS

- Measurement sheets / quantity build-ups
- Approved VOs
- Materials on-site schedule with vesting / insurance evidence
- Claim submissions (cross-references)
- Previous Payment Certificates

### 6. STATUTORY RIGHTS

The Contractor expressly reserves and intends to rely on its rights under the Building and Construction Industry Security of Payment Act 2004, including the right to seek adjudication if a Payment Response is not served within the statutory period, or if the Response disputes the claim.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "sia": {
                "clause": "31 (Progress Payments) read with Cl. 32 (Interim Certificates)",
                "period": "Monthly intervals as stated in the Contract; SOP Act parallel right under s.10",
                "template": """<!-- Edition: SIA Conditions of Building Contract (Lump Sum Contract), 9th Edition (2010, reprinted September 2016). Verify clause numbering if a different edition applies. -->
# INTERIM PAYMENT CLAIM
## Under Clause 31 (Progress Payments) and Clause 32 (Interim Certificates) — SIA 9th Ed. (2010, reprinted 2016)
## (and also constituting a Payment Claim under s.10 of the Building and Construction Industry Security of Payment Act 2004)

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Architect:** [Architect Name]
**Payment Claim No.:** [No.]
**Period to which claim relates:** [start] to [end]
**Date of submission:** {date}
**Ref:** [Reference Number]

> This document is intended to operate concurrently as (a) an interim payment application under Cl. 31 / 32 SIA, and (b) a payment claim under s.10 of the Building and Construction Industry Security of Payment Act 2004 ("SOP Act"). The reference period and amounts are stated to satisfy s.10(3).

---

### 1. CONTRACT SUM RECONCILIATION

| Item | Amount (S$) |
|------|-------------|
| Original Contract Sum | [amount] |
| Add: Variations approved (AIs to date) | [amount] |
| Add: Loss & expense admitted to date | [amount] |
| Less: Omissions to date | [amount] |
| **Adjusted Contract Sum** | **[amount]** |

### 2. VALUATION OF WORK DONE

#### 2.1 Trade / Section Breakdown (Lump Sum)
| Trade / Section | Lump Sum (S$) | % Complete | Cumulative Value (S$) |
|------------------|----------------|------------|------------------------|
| [Trade] | [amount] | [%] | [amount] |

#### 2.2 Variations (Architect's Instructions)
| AI Ref | Description | Cumulative Value (S$) |
|--------|-------------|------------------------|
| AI-[X] | [Description] | [amount] |

#### 2.3 Materials On-Site
| Item | Quantity | Value (S$) | Vesting / Insurance Status |
|------|----------|-------------|----------------------------|
| [Description] | [qty] | [amount] | [Vested / Insured / Off-site approved] |

#### 2.4 Loss & Expense Included
| Claim Ref | Description | Cumulative Value (S$) |
|-----------|-------------|------------------------|
| L&E-[X] | [Description] | [amount] |

### 3. SUMMARY — AMOUNT CLAIMED

| Heading | Amount (S$) |
|---------|-------------|
| Cumulative value of permanent work done | [amount] |
| Cumulative value of variations | [amount] |
| Cumulative value of materials on-site | [amount] |
| Cumulative value of loss & expense | [amount] |
| **Cumulative Gross Valuation** | **[amount]** |
| Less: Retention per Contract | ([amount]) |
| Less: Previous Interim Certificates | ([amount]) |
| Less: Architect's adjustments / set-offs | ([amount]) |
| **Amount Now Claimed (excl. GST)** | **[amount]** |
| Add: GST @ [rate]% | [amount] |
| **TOTAL AMOUNT CLAIMED (incl. GST)** | **[amount]** |

### 4. SOP ACT REQUIREMENTS — SECTION 10

- [x] Identifies the Contract: [Contract title and reference]
- [x] Identifies the work to which it relates: [reference period]
- [x] States the claimed amount: S$[amount]
- [x] Served on the Respondent: [Employer name]
- [x] Reference period: [start] to [end]

### 5. SUPPORTING DOCUMENTS

- Trade-by-trade valuation working papers
- Architect's Instructions to date (variations log)
- Materials on-site schedule with vesting / insurance evidence
- Loss & expense submissions (cross-references)
- Previous Interim Certificates

### 6. STATUTORY RIGHTS

The Contractor expressly reserves and intends to rely on its rights under the Building and Construction Industry Security of Payment Act 2004, including the right to seek adjudication if a Payment Response is not served within the statutory period, or if the Response disputes the claim.

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            },
            "fidic-yellow": {
                "clause": "14.3",
                "period": "Monthly per Schedule of Payments",
                "template": """<!-- Edition: FIDIC Conditions of Contract for Plant and Design-Build, Second Edition 2017 (Yellow Book). Verify clause numbering if a different edition applies. -->
# INTERIM PAYMENT STATEMENT
## Under Sub-Clause 14.3 — FIDIC Yellow Book 2017

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Statement No.:** [No.]
**Period to which Statement relates:** [start] to [end]
**Date of submission:** {date}
**Ref:** [Reference Number]

> Yellow Book payment is typically lump-sum / milestone-based per the Schedule of Payments. Adapt the breakdown below to the Contract's Schedule of Payments or Schedule of Prices.

---

### 1. CONTRACT PRICE RECONCILIATION

| Item | Amount |
|------|--------|
| Accepted Contract Amount | $[amount] |
| Add: Variations approved (Sub-Clause 13.3) | $[amount] |
| Add: Claims admitted | $[amount] |
| Less: Omissions | $[amount] |
| **Adjusted Contract Price** | **$[amount]** |

### 2. VALUATION OF WORKS DONE — SCHEDULE OF PAYMENTS

| Section / Milestone | Lump Sum | % Achieved | Cumulative Value |
|---------------------|----------|-----------|-------------------|
| [Milestone description] | $[amount] | [%] | $[amount] |

### 3. VARIATIONS INCLUDED

| Var. Ref | Description | Cumulative Value |
|----------|-------------|-------------------|
| VAR-[X] | [Description] | $[amount] |

### 4. PLANT, MATERIALS AND CONTRACTOR'S DOCUMENTS

| Item | Status | Value |
|------|--------|-------|
| Plant for the Works (on Site) | [On Site / Vested] | $[amount] |
| Plant for the Works (off Site, where Contract permits) | [Off-Site approved / Vested] | $[amount] |
| Materials | [On Site / Off Site approved] | $[amount] |
| Contractor's Documents (where Contract permits payment for design effort) | [Submitted / Reviewed] | $[amount] |

### 5. CLAIMS INCLUDED

| Claim Ref | Description | Cumulative Value |
|-----------|-------------|-------------------|
| CLM-[X] | [Description] | $[amount] |

### 6. SUMMARY — AMOUNT CLAIMED

| Heading | Amount |
|---------|--------|
| Cumulative gross valuation | $[amount] |
| Less: Retention per Contract | ($[amount]) |
| Less: Previous IPCs paid | ($[amount]) |
| Less: Adjustments / set-offs (Engineer's notice) | ($[amount]) |
| **Amount due in this Statement (excl. taxes)** | **$[amount]** |
| Add: Applicable taxes | $[amount] |
| **TOTAL AMOUNT CLAIMED** | **$[amount]** |

### 7. SUPPORTING DOCUMENTS

- Schedule of Payments / Schedule of Prices breakdown
- Milestone evidence (sign-offs / Engineer acceptance)
- Variations log with Engineer's determinations
- Plant & Materials schedule with vesting / insurance evidence
- Contractor's Documents review status (Sub-Clause 5.2)
- Claims log with cross-references

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            }
        }
    },
    "disruption-claim": {
        "title": "Disruption Claim",
        "description": "Loss of productivity / disruption claim (separate from delay)",
        "forms": {
            "fidic-red": {
                "clause": "20.2",
                "period": "28 days from awareness",
                "template": """# DISRUPTION CLAIM
## Under Sub-Clause 20.2 of the Conditions of Contract

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Engineer:** [Engineer Name]
**Date:** {date}
**Ref:** [Reference Number]

---

**Dear [Engineer/Engineer's Representative],**

## 1. Notice and Reservation of Rights

Pursuant to Sub-Clause 20.2.1, the Contractor hereby gives notice of a claim for additional Cost (and reasonable profit where applicable) arising from disruption to the Works — i.e. loss of productivity rather than (or in addition to) delay to the time for completion.

## 2. Disruption Event(s)

[Describe the events giving rise to disruption. Examples:]
- Out-of-sequence working caused by […]
- Trade stacking / over-resourcing in confined area […]
- Late information / RFI response delays […]
- Concurrent operations imposed by Employer / other contractors […]
- Acceleration / re-sequencing instruction

## 3. Causation & Productivity Loss

**Methodology used:** [Measured Mile / Earned Value / Project Comparison / Industry Studies (e.g. MCAA, Leonard) — specify]

| Period | Planned Output | Actual Output | Loss of Productivity |
|--------|----------------|---------------|---------------------|
| Unimpacted period | [units/manhour] | [units/manhour] | Baseline |
| Impacted period | [units/manhour] | [units/manhour] | [%] |

## 4. Quantum (Heads of Loss)

- Additional labour hours: [hrs] x [rate] = $[…]
- Additional plant: […]
- Site supervision overhead: […]
- Sub-contractor disruption pass-through: […]
- Reasonable profit: […]
- **Total claimed:** $[…]

## 5. Records Relied Upon

- Daily site records / allocation sheets
- Approved baseline programme & updates
- Productivity studies / industry benchmarks
- RFI / instruction logs
- Meeting minutes

## 6. Reservation

This claim is separate from any concurrent claim for extension of time. The Contractor reserves the right to amend, supplement, or expand this claim as further records and analysis become available.

Fully detailed claim to follow within 84 days pursuant to Sub-Clause 20.2.4.

Yours faithfully,

[Authorised Signatory]
"""
            },
            "psscoc": {
                "clause": "22.1",
                "period": "30 days from awareness",
                "template": """# DISRUPTION CLAIM
## Under Clause 22 (Loss & Expense) PSSCOC

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**SO:** [Superintending Officer]
**Date:** {date}

---

**Dear [SO],**

The Contractor hereby gives notice under Clause 22.1 of a claim for loss and expense arising from disruption to the regular progress of the Works (i.e. loss of productivity), not amounting solely to delay to the Date for Completion.

## 1. Disrupting Events

[List events under Clause 22.1 — e.g. late drawings, instructions, postponement, opening up, AI/SI imposing out-of-sequence work, employer's other contractors.]

## 2. Productivity Impact

Methodology: [Measured Mile / earned value / industry benchmark]

## 3. Heads of Loss & Expense

- Additional preliminaries
- Additional labour & plant unproductive time
- Sub-contractor disruption costs
- Site overheads & finance costs
- **Total:** $[…]

## 4. Substantiation

Further particulars and computations to be submitted within a reasonable time pursuant to Clause 22.1(2).

Yours faithfully,

[Authorised Signatory]
"""
            },
            "sia": {
                "clause": "23(1)(q)",
                "period": "As soon as it has become reasonably apparent",
                "template": """# DISRUPTION CLAIM
## Under Clause 23(1)(q) and Clause 24 SIA Conditions (9th Ed.)

**Date:** {date}

Please treat this as the Contractor's notice of intention to claim Loss & Expense for disruption to the regular progress of the Works.

## 1. Events
[…]

## 2. Productivity Methodology
[…]

## 3. Heads of Loss
[…]

Fully detailed submission to follow.

Yours faithfully,

[Authorised Signatory]
"""
            },
            "fidic-yellow": {
                "clause": "20.2 read with 8.5",
                "period": "28 days from awareness",
                "template": """<!-- Edition: FIDIC Conditions of Contract for Plant and Design-Build, Second Edition 2017 (Yellow Book). Verify clause numbering if a different edition applies. -->
# DISRUPTION CLAIM
## Under Sub-Clause 20.2 — FIDIC Yellow Book 2017

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Date:** {date}
**Ref:** [Reference Number]

---

### 1. NATURE OF DISRUPTION

[Describe the loss of productivity / disruption event(s). Disruption is loss of efficiency on the affected works; it is distinct from delay (which is critical-path impact). Disruption can occur without overall delay.]

### 2. CONTRACTUAL BASIS

Notice of Claim under Sub-Clause 20.2.1 served on [date]. This claim is for additional Cost (and Profit, where the underlying Sub-Clause entitles).

For Yellow Book contracts, identify the cause:
- [ ] Variations to the Employer's Requirements (Cl. 13)
- [ ] Engineer's review comments under Sub-Clause 5.2 forcing rework
- [ ] Late Engineer's instructions / late access
- [ ] Interfacing with Employer's other contractors (Cl. 4.6)
- [ ] Unforeseeable physical conditions (Cl. 4.12)
- [ ] Suspension under Cl. 8.9 / 16.1
- [ ] Other: [identify Sub-Clause]

### 3. METHODOLOGY

[State the disruption analysis method: Measured Mile / Earned Value / Industry Studies / Project Specific. Justify choice having regard to records available.]

### 4. QUANTIFICATION

| Resource | Planned Productivity | Actual Productivity | Loss | Value |
|----------|----------------------|---------------------|------|-------|
| [Trade / labour gang] | [units/hr] | [units/hr] | [%] | $[amount] |
| [Equipment] | [units/hr] | [units/hr] | [%] | $[amount] |

**Total disruption cost: $[amount]**
**Profit (where Cost Plus Profit applies): $[amount]**

### 5. SUPPORTING DOCUMENTS

- Daily allocation sheets
- Resource histograms (planned vs actual)
- Site diaries
- Photographs / time-lapse records
- Productivity baselines from undisrupted periods (Measured Mile)
- Engineer's review comments / instructions giving rise to disruption (where applicable)

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            }
        }
    },
    "loss-and-expense": {
        "title": "Loss & Expense Claim",
        "description": "Comprehensive loss and expense claim with quantum breakdown",
        "forms": {
            "fidic-red": {
                "clause": "20.2 / 8.5",
                "period": "28 days from awareness",
                "template": """# LOSS & EXPENSE CLAIM
## Under Sub-Clauses 20.2 and 8.5 of the Conditions of Contract

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Engineer:** [Engineer Name]
**Date:** {date}
**Ref:** [Reference Number]

---

**Dear [Engineer/Engineer's Representative],**

## 1. Notice and Reservation of Rights

Pursuant to Sub-Clause 20.2.1, the Contractor hereby submits this comprehensive Loss & Expense claim arising from [Event(s)] which has caused / will cause the Contractor to incur additional Cost (and reasonable profit where applicable) over and above that which would otherwise have been incurred.

## 2. Compensable Event(s)

| # | Date | Event | Clause Relied Upon |
|---|------|-------|-------------------|
| 1 | [date] | [event description] | [Cl. ref] |
| 2 | [date] | [event description] | [Cl. ref] |

## 3. Causation Chain

[Demonstrate the chain: Event → Effect on Works → Resource Impact → Cost. Use:]
- Programme impact analysis (TIA / windows / collapsed as-built)
- Resource records (allocation sheets, daywork)
- Productivity comparison (planned vs actual)
- Method statements affected

## 4. Quantum — Heads of Loss & Expense

### 4.1 Prolongation Costs
| Item | Period | Rate | Amount |
|------|--------|------|--------|
| Site staff | [days] | $/day | $[…] |
| Site establishment | [days] | $/day | $[…] |
| Plant on standby | [days] | $/day | $[…] |
| Insurance & bonds extension | [days] | $/day | $[…] |
| Head office overhead (Hudson/Emden/Eichleay) | [%] | — | $[…] |

### 4.2 Disruption Costs (loss of productivity)
| Trade/Activity | Planned hrs | Actual hrs | Loss | Rate | Amount |
|----------------|-------------|------------|------|------|--------|
| [trade] | [hrs] | [hrs] | [hrs] | $/hr | $[…] |

### 4.3 Direct Cost Impact
- Additional materials / wastage: $[…]
- Additional plant hire: $[…]
- Acceleration costs (if instructed): $[…]
- Sub-contractor pass-through: $[…]

### 4.4 Finance & Profit
- Financing charges on outstanding sums: $[…]
- Reasonable profit: [%] of Cost = $[…]

### 4.5 Total Claimed
**Total Loss & Expense: $[…]**

## 5. Substantiation & Records

- Daily site records / labour allocation sheets
- Approved baseline + monthly progress updates
- Plant returns and hire invoices
- Sub-contractor variations and back-to-back claims
- Method statements and impact assessments
- Photographs / video records
- Correspondence (RFIs, instructions, meeting minutes)

## 6. Concurrent Delay Position

[State position on concurrent delay if relevant. Cite Henry Boot v Malmaison apportionment principle, or City Inn v Shepherd Construction (Scottish approach), as applicable.]

## 7. Reservation

The Contractor reserves the right to amend, supplement, or expand this claim. Without prejudice to any other rights or remedies under the Contract or at law.

Fully detailed claim with full supporting evidence is attached / will follow within the timeframes set by Sub-Clause 20.2.4.

Yours faithfully,

[Authorised Signatory]

---

**Attachments:**
- Programme impact analysis
- Quantum build-up (Excel)
- Supporting evidence bundle
"""
            },
            "psscoc": {
                "clause": "22.1",
                "period": "30 days from awareness",
                "template": """# LOSS & EXPENSE CLAIM
## Under Clause 22 PSSCOC

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**SO:** [Superintending Officer]
**Date:** {date}

---

**Dear [SO],**

The Contractor submits this Loss & Expense claim under Clause 22.1 PSSCOC arising from matters listed at Clause 22.1(a)–(g) which have materially affected the regular progress of the Works.

## 1. Compensable Matters

| # | Clause 22.1 head | Date | Event |
|---|------------------|------|-------|
| 1 | [(a)–(g)] | [date] | [event] |

## 2. Heads of Loss & Expense

### Prolongation
- Time-related preliminaries
- Extended site staff & supervision
- Plant standby / extended hire
- Insurance / bond extension
- Head office overhead recovery (Hudson / Emden / Eichleay formula — specify)

### Disruption
- Loss of productivity (measured-mile basis)
- Out-of-sequence working
- Trade stacking / acceleration

### Direct Costs
- Additional materials / wastage
- Sub-contractor disruption costs

### Finance
- Interest on capital tied up (Wadsworth v Lydall)

## 3. Quantum Summary

| Head | Amount (S$) |
|------|------------|
| Prolongation | […] |
| Disruption | […] |
| Direct costs | […] |
| Finance | […] |
| **Total** | **[…]** |

## 4. Substantiation

Full supporting documentation per Clause 22.1(2) attached / to follow.

## 5. Reservation

The Contractor reserves the right to add further heads / amend quantum as evidence develops. Without prejudice to claims for EOT under Clause 14 / 23.

Yours faithfully,

[Authorised Signatory]
"""
            },
            "sia": {
                "clause": "24",
                "period": "As soon as reasonably apparent",
                "template": """# LOSS & EXPENSE CLAIM
## Under Clauses 23(1)(q) and 24 SIA Conditions (9th Ed.)

**Date:** {date}

---

This is the Contractor's claim for direct loss and/or expense pursuant to Clause 24 SIA Conditions arising from matters notified under Clause 23(1)(q).

## 1. Compensable Events
[List events with dates and Clause references]

## 2. Heads of Loss & Expense
- Prolongation: $[…]
- Disruption / loss of productivity: $[…]
- Direct costs: $[…]
- Finance charges: $[…]
- **Total:** $[…]

## 3. Substantiation
Full computations and supporting evidence attached.

Yours faithfully,

[Authorised Signatory]
"""
            },
            "fidic-yellow": {
                "clause": "20.2 read with relevant Sub-Clause",
                "period": "28 days from awareness",
                "template": """<!-- Edition: FIDIC Conditions of Contract for Plant and Design-Build, Second Edition 2017 (Yellow Book). Verify clause numbering if a different edition applies. -->
# LOSS & EXPENSE CLAIM
## Under Sub-Clause 20.2 — FIDIC Yellow Book 2017

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Date:** {date}
**Ref:** [Reference Number]

---

### 1. EVENT GIVING RISE TO LOSS & EXPENSE

[Describe the event(s). Identify the underlying Sub-Clause that entitles the Contractor to Cost (or Cost Plus Profit). Common Yellow Book grounds:
- 1.9 (errors in the Employer's Requirements)
- 4.6 (co-operation with Employer's other contractors)
- 4.12 (Unforeseeable physical conditions)
- 7.4 (Testing on Completion at Contractor's request)
- 8.5 + applicable Sub-Clause (EOT-related Cost)
- 8.9 (Suspension)
- 13 (Variations)
- 16.1 (Suspension by Contractor for non-payment)
- 17.x (Excepted Risks)]

### 2. NOTICE COMPLIANCE — SUB-CLAUSE 20.2.1

Notice of Claim served: [date]
Within 28 days of awareness: [Yes / No]

### 3. QUANTIFICATION

| Head | Sub-Clause / Basis | Amount |
|------|---------------------|--------|
| Prolongation costs | 8.5 + applicable Sub-Clause | $[amount] |
| Head office overhead (Emden / Hudson / Eichleay) | Established formula | $[amount] |
| Disruption / loss of productivity | (separate disruption analysis) | $[amount] |
| Design / redesign cost (Yellow Book specific) | Cl. 5 + applicable Sub-Clause | $[amount] |
| Additional resources | Cost records | $[amount] |
| Finance charges | Cl. 14.8 (delayed payment) | $[amount] |
| Profit (where Cost Plus Profit applies) | Sub-Clause invoked | $[amount] |
| **TOTAL** | | **$[amount]** |

### 4. CAUSATION

[Demonstrate the factual and contractual link between the event and each head of cost. For design-related events, show the impact on design effort, redesign cycles, and review periods.]

### 5. SUPPORTING DOCUMENTS

- Cost records / payroll / invoices
- Programme analysis (for prolongation period)
- Disruption analysis (for productivity loss)
- Design effort records (where design impact alleged)
- Subcontractor pass-through claims
- Finance / interest calculations

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            }
        }
    },
    "final-account": {
        "title": "Final Account Submission",
        "description": "Final account / final payment submission with full reconciliation",
        "forms": {
            "fidic-red": {
                "clause": "14.11 / 14.13",
                "period": "56 days after Performance Certificate",
                "template": """# FINAL ACCOUNT — STATEMENT AT COMPLETION / FINAL STATEMENT
## Under Sub-Clauses 14.10–14.13 of the Conditions of Contract

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**Engineer:** [Engineer Name]
**Date:** {date}
**Ref:** [Reference Number]

---

**Dear [Engineer/Engineer's Representative],**

In accordance with Sub-Clause 14.11 (Statement at Completion) / 14.13 (Final Statement), the Contractor submits this Final Account in respect of the Works.

## 1. Reconciliation Summary

| Item | Amount (S$) |
|------|-------------|
| **Original Contract Sum** | […] |
| Add: Approved Variations (net) | […] |
| Add: Provisional Sums adjusted (actual vs allowance) | […] |
| Add: Loss & Expense determined | […] |
| Add: Fluctuations / price adjustment | […] |
| Less: Omissions / contra-charges | ([…]) |
| Less: Liquidated Damages (if any) | ([…]) |
| **Adjusted Contract Sum (Final)** | **[…]** |
| Less: Total payments certified to date | ([…]) |
| **Final Amount Due** | **[…]** |

## 2. Variations Schedule

| VO# | Date | Description | Amount (S$) | Status |
|-----|------|-------------|------------|--------|
| VO-001 | [date] | [scope] | […] | Approved/Pending |

[Attach full VO register]

## 3. Provisional Sums Adjustment

| PS Ref | Description | Allowed | Actual | Net Adjustment |
|--------|-------------|---------|--------|----------------|

## 4. Outstanding Claims

| Claim Ref | Description | Amount Claimed | Amount Certified | Difference |
|-----------|-------------|----------------|------------------|------------|

## 5. Defects Liability Period

- DLP commenced: [date]
- Performance Certificate expected: [date]
- Outstanding defects: [list / none]
- Retention release: [scheduled date]

## 6. Discharge

Upon agreement and payment of the Final Amount Due, the Contractor shall provide the discharge required by Sub-Clause 14.12, **subject to** the express reservations set out below.

## 7. Reservations

The Contractor expressly reserves rights in respect of:
- [Outstanding claim 1 — ref]
- [Outstanding dispute — ref]
- [Pending VO determinations]

Without prejudice to any rights under the Contract or at law.

Yours faithfully,

[Authorised Signatory]

---

**Attachments:**
- Final Variations Register (Excel)
- Provisional Sums Adjustment Schedule
- Outstanding Claims Schedule
- Sub-contractor final accounts
- Discharge wording (subject to reservations)
"""
            },
            "psscoc": {
                "clause": "31",
                "period": "Within 3 months of Maintenance Certificate",
                "template": """# FINAL ACCOUNT (FINAL PAYMENT CERTIFICATE)
## Under Clause 31 PSSCOC

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Employer:** [Employer Name]
**Contractor:** [Contractor Name]
**SO:** [Superintending Officer]
**Date:** {date}

---

**Dear [SO],**

Pursuant to Clause 31 PSSCOC, the Contractor submits this Final Account for issue of the Final Payment Certificate.

## 1. Final Account Reconciliation

| Item | S$ |
|------|-----|
| Original Contract Sum | […] |
| Approved VOs (net) | […] |
| Provisional Sums adjusted | […] |
| Daywork | […] |
| Loss & Expense (Cl.22) | […] |
| Fluctuations (if applicable) | […] |
| Less: Omissions | ([…]) |
| Less: LD (Cl.32) | ([…]) |
| **Final Contract Sum** | **[…]** |
| Less: Interim payments | ([…]) |
| **Final Amount Due** | **[…]** |

## 2. Supporting Schedules

- VO Register (full list with SO instructions)
- Provisional Sum reconciliation
- Daywork records
- Outstanding claims reservation

## 3. Maintenance Period & Defects

- Maintenance Period commenced: [date]
- Maintenance Certificate expected: [date]
- Outstanding defects: [list / nil]

## 4. Reservations

The Contractor expressly reserves the right to pursue [outstanding claims / disputes] notwithstanding submission of this Final Account.

## 5. Release of Retention

Final release of retention sum requested upon issue of Maintenance Certificate per Clause 31.

Yours faithfully,

[Authorised Signatory]
"""
            },
            "sia": {
                "clause": "31(11)",
                "period": "Within 3 months of Maintenance Certificate",
                "template": """# FINAL ACCOUNT
## Under Clause 31(11) SIA Conditions (9th Ed.)

**Date:** {date}

---

Pursuant to Clause 31(11) SIA Conditions, the Contractor submits this Final Account.

## 1. Reconciliation

| Item | S$ |
|------|-----|
| Original Contract Sum | […] |
| Approved VOs (net) | […] |
| PC/Provisional Sums adjusted | […] |
| L&E (Cl.24) | […] |
| Less: Omissions / LD | ([…]) |
| **Final Sum** | **[…]** |
| Less: Interim Certificates | ([…]) |
| **Balance Due** | **[…]** |

## 2. Reservations
[Outstanding claims and disputes expressly reserved]

## 3. Maintenance Period
[Status of defects and Maintenance Certificate]

Yours faithfully,

[Authorised Signatory]
"""
            },
            "fidic-yellow": {
                "clause": "14.11 / 14.13",
                "period": "56 days after Performance Certificate",
                "template": """<!-- Edition: FIDIC Conditions of Contract for Plant and Design-Build, Second Edition 2017 (Yellow Book). Verify clause numbering if a different edition applies. -->
# FINAL STATEMENT
## Under Sub-Clause 14.11 — FIDIC Yellow Book 2017

**Contract:** [Contract Title]
**Contract No.:** [Contract Number]
**Performance Certificate Date:** [date]
**Date of submission:** {date}
**Ref:** [Reference Number]

> Submitted within 56 days of receiving the Performance Certificate per Sub-Clause 14.11 (Final Statement). The Final Payment Certificate is issued by the Engineer under Sub-Clause 14.13.

---

### 1. CONTRACT PRICE RECONCILIATION

| Item | Amount |
|------|--------|
| Accepted Contract Amount | $[amount] |
| Add: Variations approved (Cl. 13.3) | $[amount] |
| Add: Claims admitted | $[amount] |
| Add: Adjustments for changes in Laws (Cl. 13.6) | $[amount] |
| Less: Omissions | $[amount] |
| Less: Liquidated Damages (if any, Cl. 8.8) | ($[amount]) |
| **Final Contract Price** | **$[amount]** |

### 2. PAYMENTS RECEIVED

| IPC No. | Date | Amount |
|---------|------|--------|
| [X] | [date] | $[amount] |
| **Total Paid to Date** | | **$[amount]** |

### 3. AMOUNT DUE IN FINAL STATEMENT

| Heading | Amount |
|---------|--------|
| Final Contract Price | $[amount] |
| Less: Total previously paid | ($[amount]) |
| Less: Retention released to date | ($[amount]) |
| Add: Outstanding retention release (Cl. 14.9) | $[amount] |
| **Amount due in Final Statement** | **$[amount]** |

### 4. UNRESOLVED CLAIMS

[List any claims that are not agreed and remain in dispute. The Contractor expressly reserves rights in respect of these per Sub-Clause 14.12 (Discharge) and Sub-Clause 21 (Disputes and Arbitration).]

### 5. SUPPORTING DOCUMENTS

- Final Variation log
- Final Claims log (agreed and disputed)
- IPC summary (chronological)
- Retention reconciliation
- Performance Certificate (Sub-Clause 11.9)
- As-built records and operation/maintenance manuals (Sub-Clause 5.6)

Yours faithfully,

**[Contractor Name]**
[Authorised Signatory]
"""
            }
        }
    }
}

def list_templates():
    print("Available templates:\n")
    for key, tmpl in TEMPLATES.items():
        forms = ", ".join(tmpl["forms"].keys())
        print(f"  --type {key}")
        print(f"    {tmpl['title']}: {tmpl['description']}")
        print(f"    Available for: {forms}")
        print()

def generate_template(form, claim_type, output=None):
    if claim_type not in TEMPLATES:
        print(f"Error: Unknown type '{claim_type}'. Use --list to see available templates.")
        sys.exit(1)

    tmpl = TEMPLATES[claim_type]
    if form not in tmpl["forms"]:
        available = ", ".join(tmpl["forms"].keys())
        print(f"Error: Template '{claim_type}' not available for '{form}'. Available forms: {available}")
        sys.exit(1)

    form_tmpl = tmpl["forms"][form]
    content = form_tmpl["template"].format(date=datetime.now().strftime("%d %B %Y"))

    header = f"<!-- Template: {tmpl['title']} | Form: {form} | Clause: {form_tmpl['clause']} | Period: {form_tmpl['period']} -->\n"
    result = header + content

    if output:
        with open(output, 'w') as f:
            f.write(result)
        print(f"Template written to {output}")
    else:
        print(result)

def _supported_forms():
    """Forms that actually have at least one template registered."""
    forms = set()
    for tmpl in TEMPLATES.values():
        forms.update(tmpl.get("forms", {}).keys())
    # Stable order
    order = ["fidic-red", "fidic-yellow", "psscoc", "sia", "nec4", "jct"]
    return [f for f in order if f in forms] + sorted(f for f in forms if f not in order)


def main():
    supported_forms = _supported_forms()
    parser = argparse.ArgumentParser(description="Generate construction claims/notice templates")
    parser.add_argument("--form", choices=supported_forms,
                       help="Contract form (only forms with registered templates are accepted)")
    parser.add_argument("--type", dest="claim_type",
                       choices=list(TEMPLATES.keys()),
                       help="Template type")
    parser.add_argument("--output", "-o", help="Output file path")
    parser.add_argument("--list", action="store_true", help="List available templates")
    args = parser.parse_args()

    if args.list:
        list_templates()
        return

    if not args.form or not args.claim_type:
        parser.error("--form and --type are required (or use --list)")

    # Friendly error if combo unsupported
    tmpl = TEMPLATES.get(args.claim_type, {})
    if args.form not in tmpl.get("forms", {}):
        available = sorted(tmpl.get("forms", {}).keys())
        parser.error(
            f"No '{args.claim_type}' template registered for form '{args.form}'. "
            f"Available forms for this type: {available or 'none'}. "
            f"Use --list to see the full support matrix."
        )

    generate_template(args.form, args.claim_type, args.output)

if __name__ == "__main__":
    main()
