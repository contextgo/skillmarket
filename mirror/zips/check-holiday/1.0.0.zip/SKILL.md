---
name: holiday-checker
description: 判断中国大陆节假日。适用场景：查询指定日期是否为法定节假日、传统节日或周末；获取节假日名称、类型和连休信息；日程安排中标注节假日；计算工作日时排除节假日。
---

# Holiday Checker

## 概述

判断中国大陆指定日期的节假日状态，包括法定节假日、调休工作日、传统节日和周末。返回节假日名称、类型、连休信息和布尔值。

## 使用方法

### 1. 直接调用脚本（推荐）

使用 `scripts/check_holiday.py` 查询节假日信息：

```bash
python /home/linkspace/skills/holiday-checker/scripts/check_holiday.py "2026-01-01"
```

返回 JSON 格式结果：
```json
{
  "success": true,
  "date": "2026-01-01",
  "is_holiday": true,
  "holiday_name": "元旦",
  "holiday_type": "法定节假日",
  "rest_info": "连休3天：2026-01-01 至 2026-01-03"
}
```

**参数**:
- 日期字符串，格式 `YYYY-MM-DD`
- 省略参数时查询当天

### 2. 在代码中集成

将脚本作为模块导入：

```python
from pathlib import Path
import sys
sys.path.append('/home/linkspace/skills/holiday-checker/scripts')
from check_holiday import check_holiday

result = check_holiday("2026-02-17")
if result["success"] and result["is_holiday"]:
    print(f"这天是{result['holiday_name']}")
```

## 返回字段说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `success` | bool | 查询是否成功 |
| `date` | str | 查询的日期（YYYY-MM-DD） |
| `is_holiday` | bool | 是否为休息日 |
| `holiday_name` | str/null | 节假日名称（普通日期为 null） |
| `holiday_type` | str | 类型：法定节假日/调休工作日/周末/工作日 |
| `rest_info` | str/null | 连休信息，如"连休3天：2026-01-01 至 2026-01-03" |
| `error` | str | 错误信息（仅 success=false 时出现） |

## 传统节日查询

法定节假日外的传统节日（元宵、七夕、重阳等）信息存储在 `references/traditional_holidays.json`。

读取传统节日数据：

```python
import json
with open('/home/linkspace/skills/holiday-checker/references/traditional_holidays.json') as f:
    data = json.load(f)
    for holiday in data['holidays']:
        print(f"{holiday['name']} - {holiday['lunar_date']}")
```

注意：传统节日为农历日期，需要农历转换工具才能确定具体公历日期。本 skill 暂不提供农历转换功能。

## 常见场景示例

### 判断工作日

```python
result = check_holiday("2026-04-22")
is_working_day = result["success"] and not result["is_holiday"]
```

### 获取节假日连休期间的所有日期

结合返回的 `rest_info` 信息，解析起止日期后生成日期序列。

### 批量查询

```bash
for date in 2026-01-01 2026-01-02 2026-01-03; do
  python /home/linkspace/skills/holiday-checker/scripts/check_holiday.py "$date"
done
```

## 数据源说明

使用 GitHub 开源项目 [holiday-cn](https://github.com/NateScarlet/holiday-cn) 作为数据源，基于国务院官方公告，支持 2004 年至今。

详细的 API 参考见 `references/api_reference.md`。

## 注意事项

1. **网络依赖**: 首次查询某年份数据时需要网络连接
2. **年份范围**: 仅支持 2004-2030 年（取决于数据源更新）
3. **调休处理**: 自动识别调休工作日（`is_holiday=false` 但有 `holiday_name`）
4. **周末判断**: 非节假日期间的周六日自动识别为周末
