#!/usr/bin/env python3
"""
中国节假日查询脚本
使用 GitHub 开源数据源查询指定日期的节假日信息
"""

import requests
import json
import sys
from datetime import datetime
from typing import Optional, Dict, Any


def check_holiday(date_str: Optional[str] = None) -> Dict[str, Any]:
    """
    查询指定日期的节假日信息
    
    参数:
        date_str: 日期字符串，格式 YYYY-MM-DD，默认为当天
    
    返回:
        包含节假日信息的字典
    """
    # 解析日期
    if date_str is None:
        target_date = datetime.now()
    else:
        try:
            target_date = datetime.strptime(date_str, "%Y-%m-%d")
        except ValueError:
            return {
                "success": False,
                "error": "日期格式错误，请使用 YYYY-MM-DD 格式",
                "date": date_str
            }
    
    year = target_date.year
    date_only = target_date.strftime("%Y-%m-%d")
    
    # 调用 GitHub API 获取节假日数据
    url = f"https://raw.githubusercontent.com/NateScarlet/holiday-cn/master/{year}.json"
    
    try:
        response = requests.get(url, timeout=5)
        response.raise_for_status()
        data = response.json()
    except requests.exceptions.RequestException as e:
        return {
            "success": False,
            "error": f"API 调用失败: {str(e)}",
            "date": date_only
        }
    except json.JSONDecodeError:
        return {
            "success": False,
            "error": "API 返回数据格式错误",
            "date": date_only
        }
    
    # 查找指定日期的信息
    holiday_info = None
    for day in data.get("days", []):
        if day["date"] == date_only:
            holiday_info = day
            break
    
    # 构建返回结果
    if holiday_info:
        # 查找连休信息
        rest_info = get_rest_period(data["days"], holiday_info)
        
        return {
            "success": True,
            "date": date_only,
            "is_holiday": holiday_info["isOffDay"],
            "holiday_name": holiday_info["name"],
            "holiday_type": "法定节假日" if holiday_info["isOffDay"] else "调休工作日",
            "rest_info": rest_info
        }
    else:
        # 不在节假日数据中，为普通工作日或周末
        is_weekend = target_date.weekday() >= 5
        return {
            "success": True,
            "date": date_only,
            "is_holiday": is_weekend,
            "holiday_name": None,
            "holiday_type": "周末" if is_weekend else "工作日",
            "rest_info": None
        }


def get_rest_period(days: list, current_day: dict) -> Optional[str]:
    """
    获取连休信息
    
    参数:
        days: 所有节假日数据
        current_day: 当前日期信息
    
    返回:
        连休信息字符串，如 "连休3天：2026-01-01 至 2026-01-03"
    """
    if not current_day["isOffDay"]:
        return None
    
    holiday_name = current_day["name"]
    current_date = current_day["date"]
    
    # 找出同名节假日的所有休息日
    same_holiday_dates = []
    for day in days:
        if day["name"] == holiday_name and day["isOffDay"]:
            same_holiday_dates.append(day["date"])
    
    if len(same_holiday_dates) <= 1:
        return None
    
    same_holiday_dates.sort()
    start_date = same_holiday_dates[0]
    end_date = same_holiday_dates[-1]
    count = len(same_holiday_dates)
    
    return f"连休{count}天：{start_date} 至 {end_date}"


if __name__ == "__main__":
    # 命令行调用
    date_arg = sys.argv[1] if len(sys.argv) > 1 else None
    result = check_holiday(date_arg)
    print(json.dumps(result, ensure_ascii=False, indent=2))
