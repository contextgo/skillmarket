# 节假日数据源参考

## 主要数据源

### holiday-cn (GitHub)

**地址**: `https://raw.githubusercontent.com/NateScarlet/holiday-cn/master/{year}.json`

**覆盖范围**: 2004 年至今，每年更新

**数据格式**:
```json
{
  "year": 2026,
  "papers": ["https://www.gov.cn/..."],
  "days": [
    {
      "name": "元旦",
      "date": "2026-01-01",
      "isOffDay": true
    }
  ]
}
```

**字段说明**:
- `name`: 节假日名称（元旦、春节、清明节、劳动节、端午节、中秋节、国庆节）
- `date`: 日期字符串，格式 YYYY-MM-DD
- `isOffDay`: 是否为休息日（true=休息，false=调休需上班）

**特点**:
- 基于国务院官方公告
- 包含调休信息
- 数据更新及时
- 免费无需认证

## 传统节日处理

传统节日（元宵、七夕、重阳等）多为农历日期，需要农历转换：

1. **简化方案**: 仅返回农历日期描述（如"正月十五"），不进行公历转换
2. **完整方案**: 集成农历转换库（如 `lunarcalendar` 或 `zhdate`）

本 skill 采用简化方案，传统节日信息存储在 `references/traditional_holidays.json`。

## API 调用注意事项

1. **缓存建议**: 同一年份数据可缓存，减少 API 调用
2. **超时设置**: 建议设置 5 秒超时
3. **错误处理**: API 失败时降级为普通周末/工作日判断
4. **年份范围**: 查询前检查年份是否在支持范围内（2004-2030）
