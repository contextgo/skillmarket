# -*- coding: utf-8 -*-
"""
C4D Octane Scene Builder
=========================
在 Cinema 4D 脚本管理器中运行此脚本，根据 octane_scene.json 自动创建
Octane 材质并应用到导入的几何体上。

使用方式:
  1. 在 C4D 中导入 FBX/OBJ 几何体
  2. 打开脚本管理器 (Script Manager)
  3. 粘贴并运行此脚本
  4. 脚本会自动创建所有 Octane 材质并按映射关系应用

依赖: Cinema 4D + Octane Render 插件
兼容: C4D R21+
"""

import c4d
from c4d import documents
import json
import os

# ============================================================
# Octane 节点空间 ID
# ============================================================
OCTANE_NODESPACE = "com.otoy.octane.nodespace"

# Octane 材质节点类型 ID (常用)
OCTANE_NODES = {
    "universal": "OctaneUniversalMaterial",
    "specular": "OctaneSpecularMaterial",
    "diffuse": "OctaneDiffuseMaterial",
    "glossy": "OctaneGlossyMaterial",
    "metallic": "OctaneMetallicMaterial",
    "emission": "OctaneEmissionNode",
    "image_texture": "OctaneImageTextureNode",
    "rgb": "OctaneRGBNode",
    "float": "OctaneFloatNode",
    "mix": "OctaneMixMaterial",
    "noise": "OctaneNoiseNode",
    "bump": "OctaneBumpNode",
    "normal": "OctaneNormalMapNode",
    "transform": "OctaneTransformNode",
    "falloff": "OctaneFalloffNode",
    "output": "OctaneOutputNode",
    "scattering_medium": "OctaneScatteringMediumNode",
    "random_walk_medium": "OctaneRandomWalkMediumNode",
    "blackbody": "OctaneBlackBodyEmissionNode",
}


def get_octane_node_id(node_name):
    """获取 Octane 节点类型 ID"""
    return OCTANE_NODES.get(node_name.lower(), node_name)


def find_object_by_path(doc, path_str):
    """
    通过路径字符串在 C4D 场景中查找对象。
    支持格式: "Parent/Child/Grandchild"
    """
    if not path_str:
        return None

    parts = path_str.strip("/").split("/")
    if not parts or parts[0] == "":
        return None

    # 搜索根对象
    root = doc.GetFirstObject()
    target = None

    while root:
        if root.GetName() == parts[0]:
            target = root
            break
        root = root.GetNext()

    if not target or len(parts) == 1:
        return target

    # 搜索子对象
    for part in parts[1:]:
        child = target.GetDown()
        found = False
        while child:
            if child.GetName() == part:
                target = child
                found = True
                break
            child = child.GetNext()
        if not found:
            return None

    return target


def find_object_by_name_fuzzy(doc, name):
    """模糊搜索对象名称（支持不含 FBX 前缀的匹配）"""
    search_name = name.lower().strip()

    def traverse(obj):
        while obj:
            obj_name = obj.GetName().lower().strip()
            # 精确匹配
            if obj_name == search_name:
                return obj
            # 去掉 FBX 导入可能添加的前缀
            clean_name = obj_name.split("_")[-1] if "_" in obj_name else obj_name
            if clean_name == search_name:
                return obj
            # 部分匹配
            if search_name in obj_name or obj_name in search_name:
                return obj
            # 递归搜索子对象
            result = traverse(obj.GetDown())
            if result:
                return result
            obj = obj.GetNext()
        return None

    return traverse(doc.GetFirstObject())


def create_octane_universal_material(doc, mat_def, texture_base_dir=""):
    """
    创建 Octane Universal 材质并设置参数。

    Args:
        doc: C4D 文档
        mat_def: 材质定义字典 (来自 octane_scene.json)
        texture_base_dir: 贴图基础目录

    Returns:
        c4d.BaseMaterial: 创建的材质对象
    """
    # 创建基础材质
    mat = c4d.BaseMaterial(c4d.Mmaterial)
    mat.SetName(mat_def.get("name", "Octane_Material"))

    # 获取节点材质引用
    node_mat = mat.GetNodeMaterialReference()

    # 创建 Octane 节点空间
    graph = node_mat.CreateDefaultGraph(OCTANE_NODESPACE)
    if not graph:
        # 如果 Octane 节点空间不可用，退回基础材质
        print(f"  [WARN] Octane nodespace not available for: {mat_def['name']}")
        doc.InsertMaterial(mat)
        return mat

    # 查找已有的 Universal Material 节点
    master_node = None
    for node in graph.GetViewRoot().GetInnerNodes():
        if node.GetTypeName() == "OctaneUniversalMaterial":
            master_node = node
            break

    if not master_node:
        print(f"  [WARN] Cannot find Universal Material node for: {mat_def['name']}")
        doc.InsertMaterial(mat)
        return mat

    # 设置材质参数
    params = mat_def.get("parameters", {})
    textures = mat_def.get("textures", {})

    # 映射参数名到 Octane 节点端口
    param_port_map = {
        "albedo": "albedo",
        "specular": "specular",
        "metallic": "metallic",
        "roughness": "roughness",
        "ior": "ior",
        "transmission": "transmission",
        "opacity": "opacity",
        "emission": "emission",
        "anisotropy": "anisotropy",
        "normal": "normal",
        "bump": "bump",
        "displacement": "displacement",
    }

    for param_name, param_value in params.items():
        port_name = param_port_map.get(param_name)
        if not port_name:
            continue

        if isinstance(param_value, (int, float)):
            # 设置浮点值
            try:
                port = master_node.GetInputPorts().FindByName(port_name)
                if port:
                    port.SetDefaultValue(float(param_value))
            except Exception:
                pass
        elif isinstance(param_value, list) and len(param_value) >= 3:
            # 设置颜色值 (连接 RGB 节点)
            try:
                port = master_node.GetInputPorts().FindByName(port_name)
                if port:
                    # 尝试直接设置颜色
                    color = c4d.Vector(param_value[0], param_value[1], param_value[2])
                    port.SetDefaultValue(0.0)  # 占位
            except Exception:
                pass

    # 连接纹理贴图
    texture_port_map = {
        "albedo": "albedo",
        "specular": "specular",
        "roughness": "roughness",
        "metallic": "metallic",
        "normal": "normal",
        "bump": "bump",
        "opacity": "opacity",
        "transmission": "transmission",
        "emission": "emission",
        "displacement": "displacement",
    }

    for tex_channel, tex_path in textures.items():
        port_name = texture_port_map.get(tex_channel)
        if not port_name:
            continue

        # 解析贴图路径
        if texture_base_dir and not os.path.isabs(tex_path):
            full_path = os.path.join(texture_base_dir, tex_path)
        else:
            full_path = tex_path

        if not os.path.exists(full_path):
            # 尝试仅使用文件名
            full_path = os.path.join(texture_base_dir, os.path.basename(tex_path))

        if not os.path.exists(full_path):
            print(f"  [WARN] Texture not found: {tex_path}")
            continue

        # 创建 Image Texture 节点
        try:
            img_node = graph.CreateNode("OctaneImageTextureNode")
            if img_node:
                # 设置文件路径
                img_node_params = img_node.GetParams()
                # 尝试设置文件路径参数
                for pid in img_node_params:
                    pname = img_node_params[pid][c4d.DESC_NAME]
                    if "file" in pname.lower() or "image" in pname.lower():
                        img_node_params[pid] = full_path
                        break

                # 连接到主材质
                mat_port = master_node.GetInputPorts().FindByName(port_name)
                out_port = img_node.GetOutputPorts().FindByName("outColor")
                if mat_port and out_port:
                    graph.AddConnection(out_port, mat_port)

                print(f"  [TEX] Connected {os.path.basename(full_path)} -> {port_name}")
        except Exception as e:
            print(f"  [WARN] Failed to create texture node: {e}")

    # 处理特殊特性
    features = mat_def.get("features", [])

    # Coating Layer (清漆涂层)
    if "coating" in features:
        try:
            coating_val = params.get("coating", 1.0)
            port = master_node.GetInputPorts().FindByName("coating")
            if port:
                port.SetDefaultValue(float(coating_val))

            if "coating_roughness" in params:
                port = master_node.GetInputPorts().FindByName("coating_roughness")
                if port:
                    port.SetDefaultValue(float(params["coating_roughness"]))
        except Exception:
            pass

    # Sheen Layer (光泽层 - 用于布料)
    if "sheen" in features:
        try:
            sheen_val = params.get("sheen", 0.5)
            port = master_node.GetInputPorts().FindByName("sheen")
            if port:
                port.SetDefaultValue(float(sheen_val))
        except Exception:
            pass

    # Scattering Medium (SSS 次表面散射)
    if "scattering" in features:
        print(f"  [INFO] SSS detected for {mat_def['name']} - needs manual Medium setup")

    # 插入到文档
    doc.InsertMaterial(mat)
    return mat


def apply_material_mapping(doc, materials_dict, mapping_list):
    """根据映射关系将材质应用到场景对象"""
    applied = 0
    failed = 0

    for mapping in mapping_list:
        obj_path = mapping.get("object_path", "")
        mat_name = mapping.get("material_name", "")

        if not obj_path or not mat_name:
            continue

        # 查找对象
        obj = find_object_by_path(doc, obj_path)
        if not obj:
            obj = find_object_by_name_fuzzy(doc, obj_path.split("/")[-1] if "/" in obj_path else obj_path)

        if not obj:
            print(f"  [WARN] Object not found: {obj_path}")
            failed += 1
            continue

        # 查找材质
        mat = materials_dict.get(mat_name)
        if not mat:
            # 尝试模糊匹配
            for key in materials_dict:
                if mat_name.lower().replace(" ", "_") in key.lower().replace(" ", "_"):
                    mat = materials_dict[key]
                    break
                if key.lower().replace(" ", "_") in mat_name.lower().replace(" ", "_"):
                    mat = materials_dict[key]
                    break

        if not mat:
            print(f"  [WARN] Material not found: {mat_name}")
            failed += 1
            continue

        # 应用材质
        obj.SetMaterial(mat)
        # 添加材质标签
        tag = c4d.TextureTag()
        tag.SetMaterial(mat)
        obj.InsertTag(tag)
        applied += 1
        print(f"  [OK] Applied '{mat_name}' to '{obj.GetName()}'")

    return applied, failed


def rebuild_scene(octane_scene_path, texture_dir=""):
    """主场景重建函数"""
    print("=" * 60)
    print("C4D Octane Scene Builder v1.0")
    print("=" * 60)

    doc = documents.GetActiveDocument()
    if not doc:
        print("[ERROR] No active document!")
        return

    # 读取 octane_scene.json
    if not os.path.exists(octane_scene_path):
        print(f"[ERROR] File not found: {octane_scene_path}")
        return

    with open(octane_scene_path, 'r', encoding='utf-8') as f:
        scene = json.load(f)

    print(f"\n[...] 正在创建 {len(scene.get('materials', []))} 个 Octane 材质...")

    # 创建所有材质
    materials_dict = {}
    for mat_def in scene.get("materials", []):
        mat = create_octane_universal_material(doc, mat_def, texture_dir)
        if mat:
            materials_dict[mat_def["name"]] = mat
            print(f"  [OK] Created: {mat_def['name']} ({mat_def.get('source_type', 'N/A')} -> {mat_def.get('octane_type', 'Universal')})")

    # 应用材质映射
    mapping = scene.get("material_mapping", [])
    if mapping:
        print(f"\n[...] 正在应用 {len(mapping)} 个材质映射...")
        applied, failed = apply_material_mapping(doc, materials_dict, mapping)
        print(f"  成功: {applied}, 失败: {failed}")
    else:
        print("\n[INFO] 无材质映射数据，请手动应用材质")

    # 处理灯光
    lights = scene.get("lights", [])
    if lights:
        print(f"\n[INFO] 检测到 {len(lights)} 个灯光，需要手动设置 Octane Emission")

    # 处理环境
    envs = scene.get("environments", [])
    if envs:
        for env in envs:
            hdri = env.get("hdri_path")
            if hdri:
                print(f"\n[INFO] HDRI 环境: {os.path.basename(hdri)}")
                print("  请手动设置 Octane Environment > HDRI")

    # 刷新
    c4d.EventAdd()
    documents.SaveDocument(doc, doc.GetDocumentName(), c4d.SAVEDOCUMENTFLAGS_0)

    print("\n" + "=" * 60)
    print("[完成] 场景重建完成!")
    print(f"  创建材质: {len(materials_dict)}")
    print(f"  材质映射: {mapping and len(mapping) or 0}")
    print("=" * 60)

    # 输出注意事项
    notes = scene.get("conversion_notes", [])
    if notes:
        print("\n注意事项:")
        for note in notes:
            print(f"  {note}")


def main():
    """脚本入口"""
    import sys

    # 获取 JSON 路径（可从脚本管理器设置或使用默认路径）
    json_path = "octane_scene.json"
    texture_dir = "textures"

    # 查找 JSON 文件
    script_path = os.path.dirname(__file__) if '__file__' in dir() else os.getcwd()
    possible_paths = [
        json_path,
        os.path.join(script_path, json_path),
        os.path.join(os.path.expanduser("~"), json_path),
        os.path.join(os.path.expanduser("~"), "Desktop", json_path),
    ]

    found_path = None
    for p in possible_paths:
        if os.path.exists(p):
            found_path = p
            break

    if not found_path:
        print(f"[ERROR] 找不到 octane_scene.json")
        print(f"  请将 octane_scene.json 放在以下位置之一:")
        for p in possible_paths:
            print(f"    - {p}")
        return

    # 查找贴图目录
    possible_tex_dirs = [
        texture_dir,
        os.path.join(os.path.dirname(found_path), texture_dir),
    ]
    found_tex_dir = ""
    for d in possible_tex_dirs:
        if os.path.isdir(d):
            found_tex_dir = d
            break

    rebuild_scene(found_path, found_tex_dir)


if __name__ == "__main__":
    main()
