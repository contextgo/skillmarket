# -*- coding: utf-8 -*-
"""
KeyShot Material Extractor
===========================
在 KeyShot Pro 的脚本控制台 (Scripting Console) 中运行此脚本，
提取当前场景的所有材质、贴图、灯光、相机、环境数据，导出为 JSON 文件。

使用方式:
  1. 在 KeyShot 中打开 .bip 或 .ksp 文件
  2. 打开脚本控制台: Edit > Plugins > Scripting Console
  3. 粘贴本脚本代码并运行
  4. 输出文件将生成在场景所在目录

输出文件:
  - scene_data.json        : 场景完整数据 (材质、映射、灯光、相机等)
  - textures/              : 提取的所有贴图文件 (自动创建)

兼容: KeyShot Pro 2023.3+ (需要 Python 脚本支持)
"""

import lux
import json
import os
import shutil
import uuid

# ============================================================
# 配置选项 (可根据需要修改)
# ============================================================
OUTPUT_DIR = ""              # 输出目录，留空使用场景所在目录
EXPORT_GEOMETRY = True       # 是否同时导出几何体 (FBX/OBJ)
EXPORT_FORMAT = "FBX"        # 几何体导出格式: "FBX" 或 "OBJ"
COPY_TEXTURES = True         # 是否复制贴图到输出目录
INCLUDE_NODE_GRAPHS = True   # 是否包含材质节点图信息
VERBOSE = True               # 是否输出详细日志


# ============================================================
# 辅助函数
# ============================================================

def log(msg):
    """输出日志"""
    if VERBOSE:
        print(msg)


def get_output_dir():
    """获取输出目录路径"""
    if OUTPUT_DIR and os.path.isdir(OUTPUT_DIR):
        return OUTPUT_DIR

    # 尝试从当前场景获取路径
    scene_path = lux.getSceneFilePath()
    if scene_path:
        scene_dir = os.path.dirname(scene_path)
        if os.path.isdir(scene_dir):
            return scene_dir

    # 回退到桌面
    desktop = os.path.join(os.path.expanduser("~"), "Desktop")
    if os.path.isdir(desktop):
        return desktop

    return os.getcwd()


def ensure_dir(path):
    """确保目录存在"""
    if not os.path.isdir(path):
        os.makedirs(path, exist_ok=True)
    return path


def copy_texture(src_path, dest_dir):
    """
    复制贴图文件到目标目录。
    返回相对于 dest_dir 的路径。
    """
    if not src_path or not os.path.isfile(src_path):
        return src_path

    filename = os.path.basename(src_path)
    dest_path = os.path.join(dest_dir, filename)

    # 避免同名覆盖
    if os.path.exists(dest_path):
        name, ext = os.path.splitext(filename)
        dest_path = os.path.join(dest_dir, f"{name}_{uuid.uuid4().hex[:6]}{ext}")

    try:
        shutil.copy2(src_path, dest_path)
        return os.path.basename(dest_path)
    except Exception as e:
        log(f"  [WARN] Failed to copy texture {filename}: {e}")
        return src_path


def get_texture_absolute_path(tex_path, scene_dir):
    """
    将贴图路径转换为绝对路径。
    支持: 绝对路径、相对路径(相对场景)、文件名搜索
    """
    if not tex_path:
        return tex_path

    # 已经是绝对路径
    if os.path.isabs(tex_path) and os.path.isfile(tex_path):
        return tex_path

    # 相对路径 - 尝试相对于场景目录
    if scene_dir:
        abs_path = os.path.join(scene_dir, tex_path)
        if os.path.isfile(abs_path):
            return abs_path

    # 尝试在常见目录中搜索
    search_dirs = [
        scene_dir,
        os.path.join(scene_dir, "textures"),
        os.path.join(scene_dir, "Images"),
        os.path.join(os.path.dirname(scene_dir), "textures"),
    ]

    filename = os.path.basename(tex_path)
    for d in search_dirs:
        if d and os.path.isdir(d):
            candidate = os.path.join(d, filename)
            if os.path.isfile(candidate):
                return candidate

    return tex_path


# ============================================================
# 材质提取
# ============================================================

def extract_material_properties(material):
    """
    提取单个材质的所有属性。

    Returns:
        dict: {
            "name": str,
            "type": str,          # KeyShot 材质类型名
            "parameters": {},     # 参数名 -> {"type": str, "value": any}
            "textures": {},       # 通道名 -> 贴图路径
            "node_graph": [],     # 节点图连接列表
        }
    """
    mat_data = {
        "name": "Unnamed",
        "type": "Unknown",
        "parameters": {},
        "textures": {},
        "node_graph": [],
    }

    try:
        # 获取材质名称
        mat_data["name"] = lux.getMaterialName(material) or "Unnamed"

        # 获取材质类型
        mat_type = lux.getMaterialType(material)
        mat_data["type"] = mat_type or "Unknown"

        # 获取材质参数
        # KeyShot 材质类型及其关键参数
        param_definitions = get_param_definitions(mat_type)

        for param_name in param_definitions:
            try:
                value = lux.getMaterialProperty(material, param_name)
                if value is not None:
                    param_info = {"type": infer_param_type(value), "value": value}
                    mat_data["parameters"][param_name] = param_info
            except Exception:
                pass

        # 尝试通过通用接口获取更多参数
        try:
            # 遍历所有可能的参数
            common_params = [
                "Diffuse Color", "Specular Color", "Roughness", "Roughness X", "Roughness Y",
                "Refractive Index", "Index of Refraction", "IOR",
                "Metallic", "Anisotropy", "Anisotropy Rotation",
                "Opacity", "Transmission", "Diffuse Transmission",
                "Emission", "Emission Intensity", "Emission Color",
                "Bump Height", "Normal Map Intensity",
                "Thin Film", "Thin Film IOR", "Thin Film Thickness",
                "Subsurface Scattering", "Scattering Color", "SSS Radius",
                "Color", "Weight",
                "Coating Roughness", "Coating IOR",
                "Sheen", "Sheen Roughness",
                "Fake Shadows",
                "Alpha",
            ]
            for pname in common_params:
                if pname in mat_data["parameters"]:
                    continue
                try:
                    value = lux.getMaterialProperty(material, pname)
                    if value is not None:
                        mat_data["parameters"][pname] = {
                            "type": infer_param_type(value),
                            "value": value,
                        }
                except Exception:
                    pass
        except Exception:
            pass

        # 提取纹理贴图
        tex_channels = get_texture_channels(mat_type)
        scene_dir = get_output_dir()

        for channel_name in tex_channels:
            try:
                tex_path = lux.getMaterialTexture(material, channel_name)
                if tex_path:
                    abs_path = get_texture_absolute_path(tex_path, scene_dir)
                    mat_data["textures"][channel_name] = abs_path
            except Exception:
                pass

        # 提取节点图信息 (如果支持)
        if INCLUDE_NODE_GRAPHS:
            try:
                nodes = lux.getMaterialNodes(material)
                if nodes:
                    for node in nodes:
                        node_info = {}
                        try:
                            node_info["id"] = node.get("id", "")
                            node_info["type"] = node.get("type", "")
                            node_info["parameter"] = node.get("parameter", "")
                            node_info["file_path"] = node.get("file_path", "")

                            # 复制贴图
                            if node_info.get("file_path"):
                                abs_path = get_texture_absolute_path(
                                    node_info["file_path"], scene_dir
                                )
                                node_info["file_path"] = abs_path

                            mat_data["node_graph"].append(node_info)
                        except Exception:
                            pass
            except Exception:
                # lux.getMaterialNodes 可能不存在于所有版本
                pass

    except Exception as e:
        log(f"  [ERROR] Failed to extract material: {e}")

    return mat_data


def get_param_definitions(mat_type):
    """根据材质类型返回需要提取的参数列表"""
    # 基础参数 (所有材质通用)
    base_params = ["Diffuse Color", "Specular Color", "Roughness"]

    # 类型特定参数
    type_params = {
        "Diffuse": base_params + ["Opacity", "Bump Height", "Alpha"],
        "Flat": base_params + ["Color", "Opacity"],
        "Plastic": base_params + ["Refractive Index", "Opacity", "Bump Height"],
        "Metal": base_params + ["Roughness X", "Roughness Y", "Anisotropy", "Anisotropy Rotation", "Normal Map Intensity"],
        "Glass": base_params + ["Refractive Index", "Transmission", "Roughness", "Opacity", "Fake Shadows", "Thin Wall"],
        "Glass (Solid)": base_params + ["Refractive Index", "Transmission", "Roughness", "Opacity"],
        "Liquid": base_params + ["Refractive Index", "Transmission", "Roughness", "Opacity", "Fake Shadows"],
        "Paint": base_params + ["Coating Roughness", "Coating IOR", "Metallic", "Opacity"],
        "Metallic Paint": base_params + ["Coating Roughness", "Coating IOR", "Metallic", "Anisotropy", "Opacity"],
        "Anisotropic": base_params + ["Anisotropy", "Anisotropy Rotation", "Roughness X", "Roughness Y"],
        "Translucent": base_params + ["Subsurface Scattering", "Scattering Color", "SSS Radius", "Opacity"],
        "RealCloth": base_params + ["Sheen", "Sheen Roughness", "Opacity"],
        "Velvet": base_params + ["Sheen", "Sheen Roughness", "Opacity"],
        "Gem": base_params + ["Refractive Index", "Transmission", "Roughness", "Dispersion"],
        "Thin Film": base_params + ["Thin Film", "Thin Film IOR", "Thin Film Thickness", "Opacity"],
        "Emissive": base_params + ["Emission", "Emission Intensity", "Emission Color", "Temperature"],
        "Advanced": base_params + [
            "Metallic", "Refractive Index", "Transmission", "Diffuse Transmission",
            "Opacity", "Emission", "Anisotropy", "Subsurface Scattering",
            "Bump Height", "Normal Map Intensity",
        ],
        "Generic": base_params + [
            "Metallic", "Refractive Index", "Transmission", "Opacity",
            "Emission", "Anisotropy",
        ],
        "Dielectric": base_params + ["Refractive Index", "Transmission", "Roughness", "Opacity"],
        "Plastic (Cloudy)": base_params + ["Subsurface Scattering", "Scattering Color", "Refractive Index"],
        "Plastic (Transparent)": base_params + ["Refractive Index", "Transmission", "Roughness", "Opacity"],
        "Scattering Medium": ["Scattering Color", "Scattering Weight", "Phase", "Absorption Color"],
        "Measured": base_params + ["Opacity"],
    }

    return type_params.get(mat_type, type_params.get("Advanced", base_params))


def get_texture_channels(mat_type):
    """根据材质类型返回需要提取的贴图通道列表"""
    # 通用贴图通道
    common_channels = [
        "Diffuse Color", "Specular Color", "Roughness",
        "Bump", "Normal Map", "Opacity",
    ]

    # 类型扩展通道
    type_channels = {
        "Metal": common_channels + ["Roughness X", "Roughness Y", "Anisotropy"],
        "Glass": common_channels + ["Transmission", "Refractive Index"],
        "Glass (Solid)": common_channels + ["Transmission", "Refractive Index"],
        "Liquid": common_channels + ["Transmission", "Refractive Index"],
        "Paint": common_channels + ["Metallic"],
        "Metallic Paint": common_channels + ["Metallic", "Anisotropy"],
        "Emissive": common_channels + ["Emission"],
        "Anisotropic": common_channels + ["Anisotropy", "Anisotropy Rotation"],
        "Advanced": common_channels + [
            "Metallic", "Transmission", "Emission",
            "Refractive Index", "Displacement",
        ],
    }

    return type_channels.get(mat_type, type_channels.get("Advanced", common_channels))


def infer_param_type(value):
    """推断参数数据类型"""
    if isinstance(value, (int, float)):
        return "float"
    elif isinstance(value, list):
        return "color" if len(value) <= 4 else "vector"
    elif isinstance(value, bool):
        return "bool"
    elif isinstance(value, str):
        return "texture" if os.path.exists(value) or "." in value else "string"
    return "unknown"


# ============================================================
# 场景提取
# ============================================================

def extract_scene():
    """提取完整场景数据"""
    log("=" * 60)
    log("KeyShot Scene Extractor v1.0")
    log("=" * 60)

    output_dir = get_output_dir()
    texture_dir = ensure_dir(os.path.join(output_dir, "textures"))
    scene_dir = output_dir

    log(f"\n[INFO] Output directory: {output_dir}")
    log(f"[INFO] Texture directory: {texture_dir}")

    scene_data = {
        "version": "1.0",
        "source": "keyshot",
        "scene_file": lux.getSceneFilePath() or "Unknown",
        "materials": [],
        "material_mapping": [],
        "cameras": [],
        "environments": [],
        "lights": [],
        "geometry_path": None,
    }

    # ---- 1. 提取所有材质 ----
    log("\n[...] Extracting materials...")
    try:
        material_count = lux.getMaterialCount()
        log(f"  Found {material_count} materials")

        for i in range(material_count):
            try:
                material = lux.getMaterial(i)
                if material:
                    mat_data = extract_material_properties(material)
                    scene_data["materials"].append(mat_data)

                    # 复制贴图到输出目录
                    if COPY_TEXTURES:
                        for channel, tex_path in mat_data["textures"].items():
                            if tex_path and os.path.isfile(tex_path):
                                rel_path = copy_texture(tex_path, texture_dir)
                                mat_data["textures"][channel] = rel_path

                    # 从节点图中复制贴图
                    for node in mat_data.get("node_graph", []):
                        fpath = node.get("file_path")
                        if fpath and os.path.isfile(fpath):
                            rel_path = copy_texture(fpath, texture_dir)
                            node["file_path"] = rel_path

                    log(f"  [OK] {mat_data['name']} ({mat_data['type']})")
            except Exception as e:
                log(f"  [ERROR] Failed to extract material {i}: {e}")
    except Exception as e:
        log(f"  [ERROR] Failed to enumerate materials: {e}")
        log("  Trying alternative extraction method...")

        # 备选方法：尝试直接通过场景遍历
        try:
            root = lux.getSceneRoot()
            materials = extract_materials_recursive(root)
            scene_data["materials"] = materials
            log(f"  Extracted {len(materials)} materials via recursive method")
        except Exception as e2:
            log(f"  [ERROR] Recursive extraction also failed: {e2}")

    # ---- 2. 提取材质-对象映射 ----
    log("\n[...] Extracting material assignments...")
    try:
        object_count = lux.getObjectCount()
        log(f"  Found {object_count} objects")

        for i in range(object_count):
            try:
                obj = lux.getObject(i)
                if obj:
                    obj_name = lux.getObjectName(obj)
                    obj_path = lux.getObjectPath(obj)
                    mat_name = lux.getObjectMaterialName(obj)

                    if mat_name:
                        scene_data["material_mapping"].append({
                            "object_path": obj_path or obj_name,
                            "object_name": obj_name,
                            "material_name": mat_name,
                        })
            except Exception as e:
                log(f"  [WARN] Failed to get object {i}: {e}")
    except Exception as e:
        log(f"  [WARN] Failed to enumerate objects: {e}")

    log(f"  Total material mappings: {len(scene_data['material_mapping'])}")

    # ---- 3. 提取相机 ----
    log("\n[...] Extracting cameras...")
    try:
        camera_count = lux.getCameraCount()
        for i in range(camera_count):
            try:
                camera = lux.getCamera(i)
                if camera:
                    cam_data = {
                        "name": lux.getCameraName(camera) or f"Camera_{i}",
                        "position": list(lux.getCameraPosition(camera)) if callable(getattr(lux, 'getCameraPosition', None)) else [0, 0, 0],
                        "target": list(lux.getCameraTarget(camera)) if callable(getattr(lux, 'getCameraTarget', None)) else [0, 0, 0],
                        "fov": lux.getCameraFOV(camera) if callable(getattr(lux, 'getCameraFOV', None)) else 45,
                        "up": [0, 1, 0],
                    }
                    scene_data["cameras"].append(cam_data)
                    log(f"  [OK] {cam_data['name']}")
            except Exception as e:
                log(f"  [WARN] Failed to extract camera {i}: {e}")
    except Exception:
        log("  [INFO] Camera extraction not available")

    # ---- 4. 提取环境 ----
    log("\n[...] Extracting environments...")
    try:
        env_count = lux.getEnvironmentCount() if callable(getattr(lux, 'getEnvironmentCount', None)) else 0
        for i in range(env_count):
            try:
                env = lux.getEnvironment(i)
                if env:
                    env_data = {
                        "name": lux.getEnvironmentName(env) or f"Environment_{i}",
                        "hdri_path": lux.getEnvironmentHDRI(env) if callable(getattr(lux, 'getEnvironmentHDRI', None)) else None,
                        "rotation": lux.getEnvironmentRotation(env) if callable(getattr(lux, 'getEnvironmentRotation', None)) else 0,
                        "brightness": lux.getEnvironmentBrightness(env) if callable(getattr(lux, 'getEnvironmentBrightness', None)) else 1.0,
                    }
                    scene_data["environments"].append(env_data)

                    # 复制 HDRI
                    if env_data["hdri_path"] and os.path.isfile(env_data["hdri_path"]):
                        rel = copy_texture(env_data["hdri_path"], texture_dir)
                        env_data["hdri_path"] = rel

                    log(f"  [OK] {env_data['name']}")
            except Exception as e:
                log(f"  [WARN] Failed to extract environment {i}: {e}")
    except Exception:
        log("  [INFO] Environment extraction not available")

    # ---- 5. 提取灯光 ----
    log("\n[...] Extracting lights...")
    try:
        light_count = lux.getLightCount() if callable(getattr(lux, 'getLightCount', None)) else 0
        for i in range(light_count):
            try:
                light = lux.getLight(i)
                if light:
                    light_data = {
                        "name": lux.getLightName(light) or f"Light_{i}",
                        "type": lux.getLightType(light) if callable(getattr(lux, 'getLightType', None)) else "Area Light",
                        "parameters": {},
                    }

                    # 提取灯光属性
                    light_params = ["Color", "Intensity", "Power", "Temperature", "Width", "Height"]
                    for pname in light_params:
                        try:
                            val = lux.getLightProperty(light, pname)
                            if val is not None:
                                light_data["parameters"][pname] = val
                        except Exception:
                            pass

                    # 位置和方向
                    try:
                        light_data["position"] = list(lux.getLightPosition(light))
                        light_data["target"] = list(lux.getLightTarget(light))
                    except Exception:
                        pass

                    scene_data["lights"].append(light_data)
                    log(f"  [OK] {light_data['name']} ({light_data['type']})")
            except Exception as e:
                log(f"  [WARN] Failed to extract light {i}: {e}")
    except Exception:
        log("  [INFO] Light extraction not available")

    # ---- 6. 导出几何体 ----
    if EXPORT_GEOMETRY:
        log(f"\n[...] Exporting geometry ({EXPORT_FORMAT})...")
        try:
            scene_path = lux.getSceneFilePath()
            base_name = os.path.splitext(os.path.basename(scene_path))[0] if scene_path else "keyshot_scene"
            geom_filename = f"{base_name}.{EXPORT_FORMAT.lower()}"
            geom_path = os.path.join(output_dir, geom_filename)

            # 使用 KeyShot 内置导出
            if EXPORT_FORMAT.upper() == "FBX":
                lux.exportScene(geom_path, "FBX")
            elif EXPORT_FORMAT.upper() == "OBJ":
                lux.exportScene(geom_path, "OBJ")
            else:
                lux.exportScene(geom_path, "FBX")

            scene_data["geometry_path"] = geom_filename
            log(f"  [OK] Exported: {geom_path}")
        except Exception as e:
            log(f"  [WARN] Geometry export failed: {e}")
            log("  You can manually export geometry from KeyShot: File > Export")

    # ---- 7. 保存 JSON ----
    json_path = os.path.join(output_dir, "scene_data.json")
    try:
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(scene_data, f, indent=2, ensure_ascii=False)
        log(f"\n[OK] Scene data saved: {json_path}")
    except Exception as e:
        log(f"\n[ERROR] Failed to save JSON: {e}")

    # ---- 8. 生成统计报告 ----
    log("\n" + "=" * 60)
    log("Extraction Summary")
    log("=" * 60)
    log(f"  Materials:     {len(scene_data['materials'])}")
    log(f"  Mapping:       {len(scene_data['material_mapping'])}")
    log(f"  Cameras:       {len(scene_data['cameras'])}")
    log(f"  Environments:  {len(scene_data['environments'])}")
    log(f"  Lights:        {len(scene_data['lights'])}")
    log(f"  Geometry:      {scene_data.get('geometry_path') or 'Not exported'}")
    log(f"  Output dir:    {output_dir}")
    log("=" * 60)

    log("\n[DONE] Next steps:")
    log("  1. 将 scene_data.json 提供给 AI Agent 进行材质映射")
    log("  2. AI 将生成 octane_scene.json 和 C4D 重建脚本")
    log("  3. 在 C4D 中导入几何体并运行重建脚本")

    return scene_data


def extract_materials_recursive(node):
    """递归遍历场景树提取材质 (备选方法)"""
    materials = []
    try:
        # 检查当前节点是否有关联材质
        mat = lux.getNodeMaterial(node)
        if mat:
            mat_data = extract_material_properties(mat)
            materials.append(mat_data)

        # 递归处理子节点
        child_count = lux.getChildCount(node) if callable(getattr(lux, 'getChildCount', None)) else 0
        for i in range(child_count):
            child = lux.getChild(node, i)
            if child:
                materials.extend(extract_materials_recursive(child))
    except Exception:
        pass
    return materials


# ============================================================
# 主入口
# ============================================================

def main():
    """脚本主入口"""
    extract_scene()


# 在 KeyShot 脚本控制台中直接运行
main()
