# -*- coding: utf-8 -*-
"""
Material Mapping Engine: KeyShot -> Octane
=============================================
读取 scene_data.json，将 KeyShot 材质参数映射为 Octane 材质参数。

KeyShot 材质类型 -> Octane 材质策略映射:
  - Diffuse / Flat       -> Octane Universal (Metallic=0)
  - Plastic              -> Octane Universal (Metallic=0, Specular=0.5)
  - Metal                -> Octane Universal (Metallic=1)
  - Glass / Glass(Solid) -> Octane Universal (Transmission=1) 或 Specular
  - Liquid               -> Octane Specular (IOR ~1.33)
  - Paint                -> Octane Universal + Coating Layer
  - Anisotropic          -> Octane Universal (Anisotropy > 0)
  - Advanced             -> 根据参数智能判断
  - Translucent / SSS    -> Octane Universal + Medium (Scattering)
  - RealCloth / Velvet   -> Octane Universal + Sheen Layer
  - Gem                  -> Octane Specular (IOR ~2.42, Dispersion)
  - Metallic Paint       -> Octane Universal + Coating + Metallic
  - Emissive             -> Octane Universal + Emission
  - Area/Point/Spot/IES Light -> Octane Emission (Blackbody)
"""

import json
import os
import copy

# ============================================================
# KeyShot 材质类型 -> Octane 材质策略
# ============================================================

# KeyShot 材质参数名 -> Octane 参数名 的映射
PARAM_MAP = {
    # 基础参数
    "Diffuse Color": "albedo",
    "diffuse color": "albedo",
    "diffuse": "albedo",
    "Color": "albedo",
    "color": "albedo",

    # 高光
    "Specular Color": "specular",
    "specular color": "specular",
    "Specular": "specular",
    "specular": "specular",

    # 粗糙度
    "Roughness": "roughness",
    "roughness": "roughness",
    "Roughness X": "roughness",
    "Roughness Y": "roughness_y",

    # 折射率
    "Refractive Index": "ior",
    "IOR": "ior",
    "refractive index": "ior",
    "Index of Refraction": "ior",

    # 金属度
    "Metallic": "metallic",
    "metallic": "metallic",

    # 各向异性
    "Anisotropy": "anisotropy",
    "anisotropy": "anisotropy",
    "Anisotropy Rotation": "anisotropy_rotation",

    # 透明/透射
    "Opacity": "opacity",
    "opacity": "opacity",
    "Transmission": "transmission",
    "transmission": "transmission",
    "Diffuse Transmission": "diffuse_transmission",

    # 发光
    "Emission": "emission",
    "emission": "emission",

    # 薄膜
    "Thin Film": "thin_film",
    "Thin Film IOR": "thin_film_ior",
    "Thin Film Thickness": "thin_film_thickness",
}

# 贴图通道映射
TEXTURE_MAP = {
    "diffuse color": "albedo",
    "diffuse": "albedo",
    "color": "albedo",
    "specular color": "specular",
    "specular": "specular",
    "roughness": "roughness",
    "refractive index": "ior",
    "opacity": "opacity",
    "transmission": "transmission",
    "emission": "emission",
    "bump": "bump",
    "normal": "normal",
    "normal map": "normal",
    "displacement": "displacement",
    "metallic": "metallic",
    "anisotropy": "anisotropy",
}

# 材质类型策略
MATERIAL_STRATEGIES = {
    "Diffuse": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0, "specular": 0}
    },
    "Flat": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0, "specular": 0, "roughness": 1.0}
    },
    "Plastic": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0, "specular": 0.5, "roughness": 0.3}
    },
    "Metal": {
        "octane_type": "Universal",
        "defaults": {"metallic": 1.0, "specular": 0}
    },
    "Glass": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "transmission": 1.0,
            "ior": 1.5,
            "roughness": 0.0
        }
    },
    "Glass (Solid)": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "transmission": 1.0,
            "ior": 1.52,
            "roughness": 0.0
        }
    },
    "Liquid": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "transmission": 1.0,
            "ior": 1.33,
            "roughness": 0.0
        }
    },
    "Paint": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "coating": 1.0,
            "coating_roughness": 0.05,
            "coating_ior": 1.5
        },
        "use_coating": True
    },
    "Anisotropic": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0, "anisotropy": 0.8}
    },
    "Translucent": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0},
        "use_medium": "scattering"
    },
    "Advanced": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0},
        "auto_detect": True
    },
    "Generic": {
        "octane_type": "Universal",
        "defaults": {},
        "auto_detect": True
    },
    "Dielectric": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0}
    },
    "Gem": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "transmission": 1.0,
            "ior": 2.42,
            "dispersion": 0.05
        }
    },
    "Metallic Paint": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0.3,
            "coating": 1.0,
            "coating_roughness": 0.03,
            "coating_ior": 1.5
        },
        "use_coating": True
    },
    "RealCloth": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "specular": 0,
            "sheen": 0.5,
            "sheen_roughness": 0.6
        },
        "use_sheen": True
    },
    "Velvet": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "specular": 0,
            "sheen": 0.8,
            "sheen_roughness": 0.8
        },
        "use_sheen": True
    },
    "Scattering Medium": {
        "octane_type": "Universal",
        "defaults": {},
        "use_medium": "scattering"
    },
    "Translucent Medium": {
        "octane_type": "Universal",
        "defaults": {},
        "use_medium": "scattering"
    },
    "Plastic (Cloudy)": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0},
        "use_medium": "scattering"
    },
    "Plastic (Transparent)": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "transmission": 1.0,
            "ior": 1.49
        }
    },
    "Thin Film": {
        "octane_type": "Universal",
        "defaults": {
            "metallic": 0,
            "thin_film": 1.0,
            "thin_film_ior": 1.5
        }
    },
    "Emissive": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0, "emission": 1.0}
    },
    "Area Light": {
        "octane_type": "Emission",
        "defaults": {"power": 100, "temperature": 6500}
    },
    "Point Light": {
        "octane_type": "Emission",
        "defaults": {"power": 50, "temperature": 6500}
    },
    "Spot Light": {
        "octane_type": "Emission",
        "defaults": {"power": 75, "temperature": 6500}
    },
    "IES Light": {
        "octane_type": "Emission",
        "defaults": {"power": 100}
    },
    "Measured": {
        "octane_type": "Universal",
        "defaults": {"metallic": 0},
        "use_measured_brdf": True
    },
}


def normalize_keyshot_param_name(name):
    """规范化 KeyShot 参数名，支持模糊匹配"""
    return name.strip().lower()


def map_parameter(ks_name, ks_value, ks_type="float"):
    """将 KeyShot 参数映射为 Octane 参数"""
    normalizedName = normalize_keyshot_param_name(ks_name)

    # 查找映射
    oc_name = None
    for ks_key, oc_key in PARAM_MAP.items():
        if normalize_keyshot_param_name(ks_key) == normalizedName:
            oc_name = oc_key
            break

    if not oc_name:
        return None

    # 值转换
    if ks_type == "color" and isinstance(ks_value, list) and len(ks_value) >= 3:
        # KeyShot 颜色范围 0-1，Octane 也是 0-1，直接映射
        return {"octane_param": oc_name, "value": ks_value[:3], "type": "color"}
    elif ks_type == "float":
        return {"octane_param": oc_name, "value": float(ks_value), "type": "float"}
    elif ks_type == "bool":
        return {"octane_param": oc_name, "value": bool(ks_value), "type": "bool"}
    elif ks_type == "texture":
        return {"octane_param": oc_name, "value": str(ks_value), "type": "texture"}
    else:
        return {"octane_param": oc_name, "value": ks_value, "type": "unknown"}


def map_texture_channel(ks_texture_name):
    """将 KeyShot 贴图通道名映射为 Octane 通道名"""
    normalized = normalize_keyshot_param_name(ks_texture_name)
    for ks_key, oc_key in TEXTURE_MAP.items():
        if normalize_keyshot_param_name(ks_key) == normalized:
            return oc_key
    return normalized


def detect_advanced_type(params):
    """对 Advanced 材质自动检测类型特征"""
    has_transmission = False
    has_metallic = False
    has_emission = False
    has_sss = False

    for name, info in params.items():
        n = normalize_keyshot_param_name(name)
        val = info.get("value")

        if n in ("transmission", "specular transmission") and val and float(val) > 0.01:
            has_transmission = True
        if n == "metallic" and val and float(val) > 0.5:
            has_metallic = True
        if n in ("emission", "emissive") and val and float(val) > 0.01:
            has_emission = True
        if n in ("subsurface scattering", "sss", "scattering"):
            has_sss = True

    features = []
    if has_transmission:
        features.append("transparent")
    if has_metallic:
        features.append("metallic")
    if has_emission:
        features.append("emissive")
    if has_sss:
        features.append("sss")

    return features


def convert_material(ks_material):
    """
    将单个 KeyShot 材质转换为 Octane 材质定义。

    Returns:
        dict: Octane 材质定义，包含：
        - name: 材质名称
        - octane_type: Octane 材质类型
        - parameters: Octane 参数字典
        - textures: Octane 纹理贴图字典
        - features: 启用的特性列表 (coating, sheen, medium, etc.)
    """
    oc_material = {
        "name": ks_material.get("name", "Unnamed"),
        "octane_type": "Universal",
        "source_type": ks_material.get("type", "Unknown"),
        "parameters": {},
        "textures": {},
        "features": []
    }

    # 获取材质策略
    ks_type = ks_material.get("type", "Unknown")
    strategy = MATERIAL_STRATEGIES.get(ks_type, {
        "octane_type": "Universal",
        "defaults": {"metallic": 0},
        "auto_detect": True
    })

    # 设置默认值
    oc_material["octane_type"] = strategy.get("octane_type", "Universal")
    defaults = strategy.get("defaults", {})
    for key, val in defaults.items():
        oc_material["parameters"][key] = val

    # 检查特性
    if strategy.get("use_coating"):
        oc_material["features"].append("coating")
    if strategy.get("use_sheen"):
        oc_material["features"].append("sheen")
    if strategy.get("use_medium"):
        oc_material["features"].append(strategy["use_medium"])

    # 对 Advanced 材质进行自动检测
    if strategy.get("auto_detect"):
        features = detect_advanced_type(ks_material.get("parameters", {}))
        if "transparent" in features:
            oc_material["parameters"]["transmission"] = 1.0
        if "metallic" in features:
            oc_material["parameters"]["metallic"] = 1.0
            oc_material["parameters"]["specular"] = 0
        if "emissive" in features:
            oc_material["parameters"]["emission"] = 1.0
        if "sss" in features and "medium" not in oc_material["features"]:
            oc_material["features"].append("scattering")
        oc_material["_detected_features"] = features

    # 映射具体参数
    for param_name, param_info in ks_material.get("parameters", {}).items():
        ptype = param_info.get("type", "unknown")
        pvalue = param_info.get("value")

        if pvalue is None:
            continue

        mapped = map_parameter(param_name, pvalue, ptype)
        if mapped:
            oc_material["parameters"][mapped["octane_param"]] = mapped["value"]

    # 映射纹理贴图
    for tex_key, tex_path in ks_material.get("textures", {}).items():
        if not tex_path or not isinstance(tex_path, str):
            continue
        oc_channel = map_texture_channel(tex_key)
        oc_material["textures"][oc_channel] = tex_path

    # 从 node_graph 中提取额外的纹理路径
    for node in ks_material.get("node_graph", []):
        param = node.get("parameter", "")
        fpath = node.get("file_path")
        if fpath and isinstance(fpath, str):
            oc_channel = map_texture_channel(param)
            if oc_channel not in oc_material["textures"]:
                oc_material["textures"][oc_channel] = fpath

    return oc_material


def convert_scene(scene_data):
    """
    完整场景转换: KeyShot scene_data -> Octane scene_data

    Args:
        scene_data: 从 ks_extract_materials.py 导出的 JSON 数据

    Returns:
        dict: 包含 Octane 材质定义的转换数据
    """
    octane_scene = {
        "version": "1.0",
        "target": "octane_c4d",
        "materials": [],
        "material_mapping": [],
        "cameras": scene_data.get("cameras", []),
        "environments": [],
        "lights": [],
        "geometry_path": scene_data.get("geometry_path"),
        "conversion_notes": []
    }

    # 转换所有材质
    for ks_mat in scene_data.get("materials", []):
        oc_mat = convert_material(ks_mat)
        octane_scene["materials"].append(oc_mat)

    # 保留材质映射 (对象 -> 材质名称)
    octane_scene["material_mapping"] = scene_data.get("material_mapping", [])

    # 转换环境
    for ks_env in scene_data.get("environments", []):
        oc_env = {
            "name": ks_env.get("name", "Environment"),
            "hdri_path": ks_env.get("hdri_path"),
            "rotation": ks_env.get("rotation", 0),
            "brightness": ks_env.get("brightness", 1.0),
            "notes": "HDRI需要手动导入到C4D Octane Environment"
        }
        octane_scene["environments"].append(oc_env)

    # 转换灯光
    for ks_light in scene_data.get("lights", []):
        oc_light = {
            "name": ks_light.get("name"),
            "type": ks_light.get("type"),
            "parameters": ks_light.get("parameters", {}),
            "octane_strategy": "Blackbody Emission node",
            "notes": "灯光材质将转换为 Octane Emission 材质"
        }
        octane_scene["lights"].append(oc_light)

    # 转换注释
    octane_scene["conversion_notes"].extend([
        "1. FBX几何体需要手动导入到C4D中",
        "2. 材质将通过C4D Python脚本自动创建",
        "3. HDRI环境需要手动设置",
        "4. 部分复杂材质可能需要手动微调",
        "5. 纹理路径已统一映射到textures子目录"
    ])

    return octane_scene


def main():
    """独立运行模式：读取scene_data.json，输出octane_scene.json"""
    import sys

    input_path = sys.argv[1] if len(sys.argv) > 1 else "scene_data.json"
    output_path = sys.argv[2] if len(sys.argv) > 2 else "octane_scene.json"

    if not os.path.exists(input_path):
        print(f"Error: {input_path} not found")
        return

    with open(input_path, 'r', encoding='utf-8') as f:
        scene_data = json.load(f)

    octane_scene = convert_scene(scene_data)

    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(octane_scene, f, indent=2, ensure_ascii=False)

    print(f"Converted {len(octane_scene['materials'])} materials")
    print(f"Output: {output_path}")


if __name__ == "__main__":
    main()
