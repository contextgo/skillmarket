---
name: keyshot-to-c4d-octane
description: >
  将 KeyShot (.bip/.ksp) 场景文件转换为 Cinema 4D Octane 渲染场景。
  支持完整场景转换：几何体、材质参数映射、贴图、灯光、相机。
  三阶段混合式工作流：KeyShot提取 -> AI解析映射 -> C4D重建。
description_zh: "KeyShot 场景转 C4D Octane 渲染器 - 材质/场景完整转换工具"
description_en: "Convert KeyShot scenes to Cinema 4D Octane Render - Complete material and scene conversion"
version: 1.0.0
metadata:
  openclaw:
    requires:
      bins: []
    notes: >
      需要 KeyShot Pro (Python 脚本功能) 和 Cinema 4D + Octane Render 插件。
      本 Skill 生成可执行的 Python 脚本，由用户在对应软件中运行。
---

# KeyShot -> C4D Octane 场景转换工具

将 KeyShot 渲染场景（.bip / .ksp）完整转换为 Cinema 4D Octane 渲染场景，保证几何体、材质、贴图、灯光、相机等信息的完整性。

## 核心能力

- 材质类型智能映射：KeyShot 30+ 材质类型 -> Octane Universal Material
- 纹理贴图自动关联：漫反射/法线/凹凸/粗糙度/透明度等通道
- 特殊材质支持：车漆（Coating）、布料（Sheen）、玻璃（Transmission）、SSS（Scattering Medium）
- 场景结构保留：材质映射关系、灯光位置、相机参数
- 混合式工作流：自动为主，关键步骤可人工干预

## 系统要求

| 组件 | 要求 | 说明 |
|------|------|------|
| KeyShot | Pro 版（需 Python 脚本功能） | 用于提取材质数据 |
| Cinema 4D | R21 及以上 | 用于导入几何体和重建场景 |
| Octane Render | 已安装并激活 | C4D 渲染器插件 |
| Python | 3.6+ | KeyShot 和 C4D 内置 |

## 三阶段工作流

### 阶段一：KeyShot 数据提取（需 KeyShot Pro）

在 KeyShot 中执行材质提取脚本，导出场景数据：

1. 在 KeyShot 中打开 `.bip` 或 `.ksp` 文件
2. 打开 **脚本控制台** (Scripting Console)：菜单 `Edit > Plugins > Scripting Console`
3. 将 `scripts/ks_extract_materials.py` 的完整代码粘贴到控制台
4. 运行脚本
5. 等待导出完成，会在场景目录生成：
   - `scene_data.json` — 场景完整数据（材质、映射、相机、灯光等）
   - `geometry.fbx` — FBX 几何体（可选）
   - `textures/` — 所有贴图文件（自动从场景中提取）

**配置选项**（脚本顶部可修改）：

```python
OUTPUT_DIR = ""          # 输出目录，留空使用场景所在目录
EXPORT_GEOMETRY = True   # 是否同时导出 FBX 几何体
EXPORT_FORMAT = "FBX"    # 几何体格式: FBX / OBJ
```

### 阶段二：AI 智能映射（自动）

将提取的数据交给 AI Agent 处理：

1. 将 `scene_data.json` 的内容提供给 AI
2. AI 自动执行以下操作：
   - 解析 KeyShot 材质参数
   - 映射为 Octane Universal Material 参数
   - 生成 C4D 重建脚本 `c4d_build_scene.py`（含完整材质定义）
   - 输出 `octane_scene.json`（中间映射数据）

AI 在处理时会：
- 根据材质类型自动选择最优 Octane 策略
- 智能匹配纹理贴图通道
- 对 Advanced 材质进行特征检测（金属/透明/发光/SSS）
- 生成详细的手动微调建议

### 阶段三：C4D 场景重建（需 C4D + Octane）

在 Cinema 4D 中执行重建脚本：

1. 在 C4D 中导入阶段一导出的 `geometry.fbx`（或 OBJ）
2. 打开 **脚本管理器** (Script Manager)：菜单 `Scripts > Script Manager`
3. 将 AI 生成的 `c4d_build_scene.py` 代码粘贴到脚本管理器
4. 点击 **Execute** 运行脚本
5. 脚本自动创建所有 Octane 材质并按映射关系应用到几何体
6. 手动补充：HDRI 环境、灯光方向、相机角度（按提示操作）

## 材质映射参考表

### 基础材质

| KeyShot 类型 | Octane 策略 | 关键参数 |
|-------------|------------|---------|
| Diffuse | Universal (Metallic=0, Specular=0) | albedo |
| Flat | Universal (Metallic=0, Roughness=1.0) | albedo |
| Plastic | Universal (Metallic=0, Specular=0.5) | albedo, roughness |
| Metal | Universal (Metallic=1.0) | albedo, roughness, ior |
| Glass | Universal (Transmission=1.0, IOR=1.5) | transmission, ior, roughness |
| Glass (Solid) | Universal (Transmission=1.0, IOR=1.52) | transmission, ior |
| Liquid | Universal (Transmission=1.0, IOR=1.33) | transmission, ior |

### 高级材质

| KeyShot 类型 | Octane 策略 | 特殊处理 |
|-------------|------------|---------|
| Paint | Universal + Coating Layer | coating=1.0, coating_roughness=0.05 |
| Metallic Paint | Universal + Coating + Metallic | coating + metallic 混合 |
| Anisotropic | Universal (Anisotropy>0) | anisotropy 参数 |
| RealCloth | Universal + Sheen Layer | sheen=0.5, sheen_roughness=0.6 |
| Velvet | Universal + Sheen Layer | sheen=0.8, sheen_roughness=0.8 |
| Translucent | Universal + Scattering Medium | scattering, absorption |
| Gem | Universal (Transmission=1.0, IOR=2.42) | dispersion=0.05 |
| Thin Film | Universal + Thin Film Layer | thin_film=1.0 |
| Emissive | Universal + Emission | emission 强度 |

### 光源材质

| KeyShot 类型 | Octane 策略 | 说明 |
|-------------|------------|------|
| Area Light | Blackbody Emission | power + temperature |
| Point Light | Blackbody Emission | 功率约 50W |
| Spot Light | Blackbody Emission | 功率约 75W |
| IES Light | Blackbody Emission | 需要 IES 文件 |

### 参数映射

| KeyShot 参数 | Octane 参数 | 值范围 | 说明 |
|-------------|------------|-------|------|
| Diffuse Color | albedo | 0-1 RGB | 基础颜色 |
| Specular Color | specular | 0-1 RGB | 高光颜色/强度 |
| Roughness | roughness | 0-1 | 表面粗糙度 |
| Refractive Index | ior | 1.0-2.42 | 折射率 |
| Metallic | metallic | 0-1 | 金属度开关 |
| Opacity | opacity | 0-1 | 不透明度 |
| Transmission | transmission | 0-1 | 透射强度 |
| Emission | emission | 0+ | 自发光 |
| Bump | bump | 灰度图 | 凹凸贴图 |
| Normal Map | normal | RGB图 | 法线贴图 |
| Anisotropy | anisotropy | 0-1 | 各向异性 |

### 贴图通道映射

| KeyShot 通道 | Octane 通道 | 色彩空间建议 |
|-------------|------------|------------|
| Diffuse / Color | albedo | sRGB |
| Specular | specular | Linear |
| Roughness | roughness | Linear |
| Normal Map | normal | Non-color |
| Bump | bump | Linear |
| Opacity (Alpha) | opacity | Non-color |
| Emission | emission | sRGB |
| Refractive Index | ior | Linear |
| Metallic | metallic | Linear |

## 文件结构

```
keyshot-to-c4d-octane/
├── SKILL.md                      # 本文档
├── scripts/
│   ├── ks_extract_materials.py   # 阶段一：KeyShot 材质提取脚本
│   ├── material_mapper.py        # 阶段二：材质映射引擎
│   └── c4d_build_scene.py        # 阶段三：C4D 场景重建脚本
└── references/
    └── mapping_table.md          # 完整映射参考表
```

## 常见问题

### Q: KeyShot 脚本报错 "No module named lux"
A: 确保 KeyShot 为 Pro 版本，且在 KeyShot 内置的脚本控制台中运行（不要在外部 Python 中运行）。

### Q: C4D 脚本报错 "Octane nodespace not found"
A: 确保 Octane Render 插件已正确安装并激活，且 C4D 版本兼容。

### Q: 材质映射后效果有差异怎么办
A: KeyShot 和 Octane 的物理渲染模型有细微差异，建议：
1. 先检查贴图通道是否正确关联
2. 微调 roughness 和 specular 值
3. 玻璃材质注意 IOR 和 fake shadows 设置
4. SSS 材质可能需要手动调整 medium 参数

### Q: 几何体导入后材质丢失
A: FBX 导入时选择"Create Materials"选项，然后运行 C4D 重建脚本会自动重新创建 Octane 材质。

### Q: 支持哪些 KeyShot 版本
A: KeyShot 2023.3 及以上版本（需要 Python 3.x 脚本支持）。

### Q: KSP 文件如何处理
A: KSP 是 KeyShot Package（ZIP 格式），在 KeyShot 中直接打开即可。提取脚本会自动处理内部的所有资源。

## 已知限制

1. KeyShot 动画数据暂不支持转换（导出格式限制）
2. 复杂材质图网络（多节点连接）可能需要手动调整
3. KeyShot Measured (BRDF) 材质无法精确还原
4. HDRI 环境需要手动导入到 C4D Octane
5. IES 灯光需要手动关联 IES 文件路径
6. 贴图路径转换后可能需要手动重新指向

## 版本历史

- v1.0.0 (2026-04-03): 初始版本，支持基础/高级/光源材质转换
