# KeyShot -> Octane 完整映射参考表

## 一、材质类型策略映射

### 1.1 基础材质（10种）

| KeyShot 类型 | Octane 推荐类型 | Metallic | Specular | Transmission | IOR | Roughness | 特殊特性 |
|-------------|----------------|----------|----------|-------------|-----|-----------|---------|
| Diffuse | Universal | 0 | 0 | 0 | - | 0.5 | - |
| Flat | Universal | 0 | 0 | 0 | - | 1.0 | - |
| Glass | Universal | 0 | - | 1.0 | 1.50 | 0.0 | - |
| Glass (Solid) | Universal | 0 | - | 1.0 | 1.52 | 0.0 | - |
| Liquid | Universal | 0 | - | 1.0 | 1.33 | 0.0 | - |
| Metal | Universal | 1.0 | 0 | 0 | 依材质 | 0.2 | - |
| Paint | Universal | 0 | - | 0 | - | 0.3 | Coating |
| Plastic | Universal | 0 | 0.5 | 0 | - | 0.3 | - |
| Thin Film | Universal | 0 | - | 0 | - | 0.2 | Thin Film |
| Translucent | Universal | 0 | - | 0 | - | 0.3 | Scattering Medium |

### 1.2 高级材质（14种）

| KeyShot 类型 | Octane 推荐类型 | 策略说明 |
|-------------|----------------|---------|
| Advanced | Universal | 自动检测特征（金属/透明/发光/SSS） |
| Anisotropic | Universal | anisotropy > 0，拉丝方向 |
| Dielectric | Universal | Metallic=0，使用 IOR |
| Gem | Universal | IOR=2.42, Dispersion=0.05 |
| Generic | Universal | 自动检测特征 |
| Measured | Universal | 无法精确还原，使用近似参数 |
| Metallic Paint | Universal | Coating + Metallic 混合 |
| Multi-Layer Optics | Universal + Mix | 多层叠加，需要 Mix 材质 |
| Plastic (Cloudy) | Universal | Scattering Medium |
| Plastic (Transparent) | Universal | Transmission=1.0, IOR=1.49 |
| RealCloth | Universal | Sheen Layer |
| Scattering Medium | Universal | Scattering Medium |
| Translucent Medium | Universal | Scattering Medium |
| Velvet | Universal | Sheen Layer, 高粗糙度 |

### 1.3 光源材质（4种）

| KeyShot 类型 | Octane 策略 | Power 建议 | Temperature 建议 |
|-------------|------------|-----------|-----------------|
| Area Light | Blackbody Emission | 100W | 6500K (日光) |
| Point Light | Blackbody Emission | 50W | 6500K |
| Spot Light | Blackbody Emission | 75W | 6500K |
| IES Light | Blackbody Emission | 依IES文件 | - |

### 1.4 特殊材质（6种）

| KeyShot 类型 | Octane 处理方式 |
|-------------|---------------|
| Cutaway | 无直接对应，跳过或用 Clip Material |
| Emissive | Universal + Emission 通道 |
| Ground | C4D 无限地面替代 |
| Toon | Octane Toon Material |
| Wireframe | C4D 显示模式替代 |
| Xray | Universal + 低 Opacity |

## 二、参数值域映射

### 2.1 通用参数

| KeyShot 参数 | Octane 参数 | 值域 | 单位转换 |
|-------------|------------|------|---------|
| Diffuse Color | albedo | [0,1] RGB | 直接映射 |
| Specular Color | specular | [0,1] RGB | 直接映射 |
| Roughness | roughness | [0,1] | 直接映射 |
| Refractive Index | ior | 1.0 - 2.5 | 直接映射 |
| Metallic | metallic | 0 或 1 | 直接映射 |
| Opacity | opacity | [0,1] | 直接映射 |
| Emission | emission | 0+ | 直接映射 |
| Anisotropy | anisotropy | [0,1] | 直接映射 |
| Anisotropy Rotation | anisotropy_rotation | [0,360] | 度数映射 |
| Fresnel | falloff | [0,1] | 使用 Falloff 节点 |
| Samples | - | - | Octane 自动管理 |

### 2.2 折射/透射参数

| KeyShot 参数 | Octane 参数 | 说明 |
|-------------|------------|------|
| Specular Transmission | transmission | 透明透射 |
| Diffuse Transmission | diffuse_transmission | 半透明散射 |
| Roughness Transmission | transmission_roughness | 透射粗糙度 |
| IOR | ior | 折射率 |
| Thin Wall | thin_walled | 薄壁模式 |
| Fake Shadows | fake_shadows | 假阴影（快速渲染） |

### 2.3 贴图通道

| KeyShot 通道 | Octane 通道 | 色彩空间 | 类型 |
|-------------|------------|---------|------|
| Diffuse / Color | albedo | sRGB | RGB |
| Specular | specular | Linear | RGB |
| Roughness | roughness | Linear | Float |
| Refractive Index | ior | Linear | Float |
| Normal Map | normal | Non-color | RGB |
| Bump | bump | Linear | Float/RGB |
| Opacity | opacity | Non-color | Float |
| Emission | emission | sRGB | RGB |
| Metallic | metallic | Linear | Float |
| Anisotropy | anisotropy | Linear | Float |
| Displacement | displacement | Linear | Float |
| Label | - | - | 不支持直接映射 |

### 2.4 SSS 参数映射

| KeyShot SSS 参数 | Octane Scattering Medium 参数 | 说明 |
|-----------------|------------------------------|------|
| Subsurface Scattering | Scattering | 散射强度/颜色 |
| Scattering Color | Scattering (RGB) | RGB 控制波长依赖 |
| SSS Radius | Scattering (float) | 散射距离 |
| Phase | Phase | -1(后向) 到 +1(前向) |

## 三、常见 IOR 参考值

| 材质 | IOR 值 | 材质 | IOR 值 |
|------|--------|------|--------|
| 空气 | 1.000 | 蓝宝石 | 1.770 |
| 水 | 1.333 | 黄玉 | 1.630 |
| 塑料(通用) | 1.460 | 翡翠 | 1.570 |
| 玻璃(普通) | 1.520 | 红宝石 | 1.770 |
| 玻璃(铅) | 1.620 | 钻石 | 2.420 |
| 冰 | 1.310 | 琥珀 | 1.550 |
| 酒精 | 1.360 | 石英 | 1.544 |
| 丙烯酸 | 1.490 | 橡胶 | 1.520 |
| 亚克力 | 1.490 | 塑料(PMMA) | 1.491 |

## 四、Auto-Detect 智能检测规则

对 Advanced/Generic 等通用材质，通过以下规则自动判断目标类型：

1. **检测 Transmission > 0.01** -> 启用透明特性，设置 transmission 参数
2. **检测 Metallic > 0.5** -> 设为金属材质，metallic=1.0，关闭 specular
3. **检测 Emission > 0.01** -> 启用自发光特性
4. **检测 SSS/Scattering 参数** -> 启用 Scattering Medium
5. **检测 Anisotropy > 0** -> 启用各向异性
6. **同时检测 Transmission + Metallic** -> 玻璃/金属混合材质，使用 Mix 材质
7. **默认** -> 非金属不透明材质，metallic=0

## 五、贴图路径处理规则

1. KSP 文件中的贴图路径：解压后使用 `textures/` 子目录
2. 绝对路径：保持不变（跨机器使用时需手动修正）
3. 相对路径：相对于场景文件所在目录解析
4. 文件名匹配：支持大小写不敏感匹配
5. 色彩空间：根据通道类型自动设置（颜色用 sRGB，数据用 Linear）
