#!/usr/bin/env python3
"""
敏感词检测脚本

用于检测文本中的敏感词，支持自定义词库。

Usage:
    python sensitive_word_check.py <input_file> [--output <output_file>] [--dict <dict_file>]

Examples:
    python sensitive_word_check.py book.txt
    python sensitive_word_check.py book.txt --output report.json
    python sensitive_word_check.py book.txt --dict custom_words.txt
"""

import re
import json
import argparse
from pathlib import Path
from typing import List, Dict, Tuple
from collections import defaultdict


# 默认敏感词分类
DEFAULT_CATEGORIES = {
    "政治敏感": ["示例词1", "示例词2"],  # 实际使用时替换为真实词库
    "色情低俗": ["示例词3", "示例词4"],
    "暴力恐怖": ["示例词5", "示例词6"],
    "违禁药品": ["示例词7", "示例词8"],
    "宗教敏感": ["示例词9", "示例词10"],
    "广告违禁": ["最", "第一", "顶级", "极致", "完美"],  # 广告法违禁词示例
}


def load_dictionary(dict_path: str = None) -> Dict[str, List[str]]:
    """
    加载敏感词词典
    
    Args:
        dict_path: 自定义词典路径
    
    Returns:
        分类 -> 词表 的字典
    """
    if dict_path and Path(dict_path).exists():
        with open(dict_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return DEFAULT_CATEGORIES


def build_trie(words: List[str]) -> dict:
    """
    构建 Trie 树用于高效匹配
    
    Args:
        words: 词表
    
    Returns:
        Trie 树结构
    """
    trie = {}
    for word in words:
        node = trie
        for char in word:
            if char not in node:
                node[char] = {}
            node = node[char]
        node['#'] = True  # 结束标记
    return trie


def search_trie(text: str, trie: dict) -> List[Tuple[int, int, str]]:
    """
    在文本中搜索 Trie 树中的词
    
    Args:
        text: 待检测文本
        trie: Trie 树
    
    Returns:
        [(开始位置, 结束位置, 匹配词)] 列表
    """
    results = []
    n = len(text)
    
    for i in range(n):
        node = trie
        j = i
        word_chars = []
        
        while j < n and text[j] in node:
            node = node[text[j]]
            word_chars.append(text[j])
            j += 1
            
            if '#' in node:  # 找到一个完整词
                word = ''.join(word_chars)
                results.append((i, j, word))
    
    return results


def check_sensitive_words(
    text: str,
    dictionary: Dict[str, List[str]]
) -> Dict[str, List[Dict]]:
    """
    检测文本中的敏感词
    
    Args:
        text: 待检测文本
        dictionary: 敏感词词典
    
    Returns:
        检测结果 {分类: [{位置, 内容, 上下文}]}
    """
    results = defaultdict(list)
    
    for category, words in dictionary.items():
        if not words:
            continue
            
        trie = build_trie(words)
        matches = search_trie(text, trie)
        
        for start, end, word in matches:
            # 提取上下文（前后各20字）
            context_start = max(0, start - 20)
            context_end = min(len(text), end + 20)
            context = text[context_start:context_end]
            
            results[category].append({
                "word": word,
                "position": start,
                "line": text[:start].count('\n') + 1,
                "context": context
            })
    
    return dict(results)


def generate_report(
    results: Dict[str, List[Dict]],
    total_chars: int
) -> str:
    """
    生成检测报告
    
    Args:
        results: 检测结果
        total_chars: 总字符数
    
    Returns:
        Markdown 格式的报告
    """
    report = ["# 敏感词检测报告\n"]
    report.append(f"**检测范围**: {total_chars:,} 字符\n")
    
    total_found = sum(len(v) for v in results.values())
    report.append(f"**发现问题**: {total_found} 处\n")
    
    if not results or total_found == 0:
        report.append("\n✅ 未检测到敏感词\n")
        return ''.join(report)
    
    report.append("\n---\n")
    
    for category, items in results.items():
        if not items:
            continue
            
        report.append(f"\n## {category}\n")
        report.append(f"发现 {len(items)} 处\n\n")
        
        for item in items:
            report.append(f"- **第 {item['line']} 行**: `{item['word']}`\n")
            report.append(f"  > 上下文: ...{item['context']}...\n\n")
    
    return ''.join(report)


def main():
    parser = argparse.ArgumentParser(description='敏感词检测工具')
    parser.add_argument('input', help='输入文件路径')
    parser.add_argument('--output', '-o', help='输出报告路径')
    parser.add_argument('--dict', '-d', help='自定义词典路径')
    parser.add_argument('--format', '-f', choices=['markdown', 'json'], 
                       default='markdown', help='输出格式')
    
    args = parser.parse_args()
    
    # 读取输入文件
    input_path = Path(args.input)
    if not input_path.exists():
        print(f"❌ 错误: 文件不存在 - {args.input}")
        return 1
    
    with open(input_path, 'r', encoding='utf-8') as f:
        text = f.read()
    
    # 加载词典
    dictionary = load_dictionary(args.dict)
    
    # 检测敏感词
    results = check_sensitive_words(text, dictionary)
    
    # 生成报告
    if args.format == 'json':
        report = json.dumps({
            "total_chars": len(text),
            "total_issues": sum(len(v) for v in results.values()),
            "results": results
        }, ensure_ascii=False, indent=2)
    else:
        report = generate_report(results, len(text))
    
    # 输出
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"✅ 报告已保存: {args.output}")
    else:
        print(report)
    
    return 0


if __name__ == "__main__":
    exit(main())
