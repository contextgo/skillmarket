# 心理学专业术语对照表

> 心理学常用术语中英对照及使用规范

---

## 使用说明

1. **统一原则**：同一术语全书使用统一译名
2. **首次标注**：外文术语首次出现时标注英文原文
3. **缩写规范**：常用缩写首次出现时写全称

示例：
```
认知行为治疗（Cognitive Behavioral Therapy, CBT）是一种...
后续可直接使用：CBT已被广泛应用于...
```

---

## 基础心理学

### 认知心理学

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| cognition | 认知 | — |
| cognitive process | 认知过程 | — |
| cognitive psychology | 认知心理学 | — |
| attention | 注意 | — |
| perception | 知觉 | — |
| memory | 记忆 | — |
| working memory | 工作记忆 | — |
| long-term memory | 长时记忆 | — |
| short-term memory | 短时记忆 | — |
| encoding | 编码 | — |
| retrieval | 提取 | — |
| forgetting | 遗忘 | — |
| schema | 图式 | — |
| cognitive schema | 认知图式 | — |
| cognitive load | 认知负荷 | — |
| mental representation | 心理表征 | — |
| information processing | 信息加工 | — |
| cognitive dissonance | 认知失调 | Festinger理论 |

### 学习与记忆

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| learning | 学习 | — |
| classical conditioning | 经典条件作用 | 巴甫洛夫 |
| operant conditioning | 操作性条件作用 | 斯金纳 |
| reinforcement | 强化 | — |
| positive reinforcement | 正强化 | — |
| negative reinforcement | 负强化 | — |
| punishment | 惩罚 | — |
| extinction | 消退 | — |
| generalization | 泛化 | — |
| discrimination | 分化 | — |
| habituation | 习惯化 | — |
| sensitization | 敏感化 | — |
| insight learning | 顿悟学习 | — |
| observational learning | 观察学习 | 班杜拉 |

### 情绪与动机

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| emotion | 情绪 | — |
| affect | 情感 | — |
| mood | 心境 | — |
| motivation | 动机 | — |
| intrinsic motivation | 内在动机 | — |
| extrinsic motivation | 外在动机 | — |
| need | 需要 | — |
| drive | 驱力 | — |
| incentive | 诱因 | — |
| achievement motivation | 成就动机 | — |
| self-actualization | 自我实现 | 马斯洛 |
| emotional intelligence | 情绪智力 | EQ |
| alexithymia | 述情障碍 | — |

---

## 发展心理学

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| developmental psychology | 发展心理学 | — |
| cognitive development | 认知发展 | — |
| moral development | 道德发展 | — |
| psychosocial development | 心理社会发展 | 埃里克森 |
| attachment | 依恋 | — |
| secure attachment | 安全型依恋 | — |
| insecure attachment | 不安全型依恋 | — |
| avoidant attachment | 回避型依恋 | — |
| anxious attachment | 焦虑型依恋 | — |
| disorganized attachment | 混乱型依恋 | — |
| temperament | 气质 | — |
| critical period | 关键期 | — |
| sensitive period | 敏感期 | — |
| object permanence | 客体永久性 | 皮亚杰 |
| theory of mind | 心理理论 | — |
| egocentrism | 自我中心 | 皮亚杰 |

---

## 人格心理学

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| personality | 人格 | — |
| personality trait | 人格特质 | — |
| Big Five | 大五人格 | — |
| openness | 开放性 | 大五 |
| conscientiousness | 尽责性 | 大五 |
| extraversion | 外向性 | 大五 |
| agreeableness | 宜人性 | 大五 |
| neuroticism | 神经质 | 大五 |
| self-efficacy | 自我效能感 | 班杜拉 |
| self-esteem | 自尊 | — |
| self-concept | 自我概念 | — |
| self-awareness | 自我意识 | — |
| locus of control | 控制点 | — |
| internal locus of control | 内控型 | — |
| external locus of control | 外控型 | — |
| archetype | 原型 | 荣格 |
| collective unconscious | 集体无意识 | 荣格 |

---

## 临床与咨询心理学

### 心理障碍

| 英文 | 推荐译名 | DSM-5编码 |
|------|----------|-----------|
| mental disorder | 精神障碍 / 心理障碍 | — |
| anxiety disorder | 焦虑障碍 | — |
| depressive disorder | 抑郁障碍 | — |
| major depressive disorder | 重度抑郁障碍 | 296.xx |
| persistent depressive disorder | 持续性抑郁障碍 | 300.4 |
| bipolar disorder | 双相障碍 | 296.xx |
| schizophrenia | 精神分裂症 | 295.xx |
| obsessive-compulsive disorder | 强迫障碍 | 300.3 |
| post-traumatic stress disorder | 创伤后应激障碍 | 309.81 |
| PTSD | 创伤后应激障碍 | 缩写 |
| personality disorder | 人格障碍 | — |
| borderline personality disorder | 边缘型人格障碍 | 301.83 |
| antisocial personality disorder | 反社会型人格障碍 | 301.7 |
| eating disorder | 进食障碍 | — |
| anorexia nervosa | 神经性厌食 | 307.1 |
| bulimia nervosa | 神经性贪食 | 307.51 |

### 心理治疗

| 英文 | 推荐译名 | 缩写 |
|------|----------|------|
| psychotherapy | 心理治疗 | — |
| cognitive behavioral therapy | 认知行为疗法 | CBT |
| dialectical behavior therapy | 辩证行为疗法 | DBT |
| acceptance and commitment therapy | 接纳承诺疗法 | ACT |
| mindfulness-based cognitive therapy | 正念认知疗法 | MBCT |
| mindfulness-based stress reduction | 正念减压疗法 | MBSR |
| psychodynamic therapy | 心理动力学治疗 | — |
| psychoanalysis | 精神分析 | — |
| humanistic therapy | 人本主义治疗 | — |
| client-centered therapy | 来访者中心疗法 | — |
| existential therapy | 存在主义治疗 | — |
| family therapy | 家庭治疗 | — |
| group therapy | 团体治疗 | — |
| exposure therapy | 暴露疗法 | — |
| systematic desensitization | 系统脱敏 | — |
| cognitive restructuring | 认知重构 | — |
| behavioral activation | 行为激活 | — |
| mindfulness | 正念 | — |

### 专业术语

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| diagnosis | 诊断 | — |
| assessment | 评估 | — |
| intervention | 干预 | — |
| prevention | 预防 | — |
| symptom | 症状 | — |
| syndrome | 综合征 | — |
| comorbidity | 共病 | — |
| remission | 缓解 | — |
| relapse | 复发 | — |
| therapeutic alliance | 治疗联盟 | — |
| transference | 移情 | 精神分析 |
| countertransference | 反移情 | 精神分析 |
| resistance | 阻抗 | 精神分析 |

---

## 心理测量

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| psychological testing | 心理测验 | — |
| psychological assessment | 心理评估 | — |
| reliability | 信度 | — |
| validity | 效度 | — |
| internal consistency | 内部一致性 | — |
| test-retest reliability | 重测信度 | — |
| inter-rater reliability | 评分者信度 | — |
| content validity | 内容效度 | — |
| criterion validity | 效标效度 | — |
| construct validity | 结构效度 | — |
| standardization | 标准化 | — |
| norm | 常模 | — |
| percentile | 百分等级 | — |
| standard score | 标准分 | — |
| z-score | Z分数 | — |
| T-score | T分数 | — |
| intelligence quotient | 智商 | IQ |
| personality inventory | 人格问卷 | — |
| self-report scale | 自评量表 | — |

---

## 社会心理学

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| social psychology | 社会心理学 | — |
| social cognition | 社会认知 | — |
| attitude | 态度 | — |
| attitude change | 态度改变 | — |
| cognitive dissonance | 认知失调 | — |
| conformity | 从众 | — |
| obedience | 服从 | — |
| compliance | 顺从 | — |
| social influence | 社会影响 | — |
| social identity | 社会认同 | — |
| stereotype | 刻板印象 | — |
| prejudice | 偏见 | — |
| discrimination | 歧视 | — |
| attribution | 归因 | — |
| fundamental attribution error | 基本归因错误 | — |
| self-serving bias | 自利偏差 | — |
| groupthink | 群体思维 | — |
| bystander effect | 旁观者效应 | — |

---

## 研究方法

| 英文 | 推荐译名 | 备注 |
|------|----------|------|
| experimental design | 实验设计 | — |
| quasi-experimental design | 准实验设计 | — |
| correlational study | 相关研究 | — |
| longitudinal study | 纵向研究 | — |
| cross-sectional study | 横断研究 | — |
| case study | 个案研究 | — |
| survey | 调查 | — |
| questionnaire | 问卷 | — |
| interview | 访谈 | — |
| observation | 观察 | — |
| independent variable | 自变量 | IV |
| dependent variable | 因变量 | DV |
| confounding variable | 混淆变量 | — |
| control group | 对照组 | — |
| experimental group | 实验组 | — |
| random assignment | 随机分配 | — |
| sample | 样本 | — |
| population | 总体 | — |
| sampling | 抽样 | — |
| validity | 效度 | — |
| reliability | 信度 | — |

---

## 统计术语

| 英文 | 推荐译名 | 缩写/符号 |
|------|----------|-----------|
| mean | 平均数 | M |
| standard deviation | 标准差 | SD |
| variance | 方差 | — |
| correlation | 相关 | r |
| regression | 回归 | — |
| t-test | t检验 | — |
| ANOVA | 方差分析 | — |
| chi-square test | 卡方检验 | χ² |
| significance | 显著性 | — |
| effect size | 效应量 | d, η² |
| confidence interval | 置信区间 | CI |
| p-value | p值 | p |

---

## 常用缩写表

| 缩写 | 全称 | 中文 |
|------|------|------|
| CBT | Cognitive Behavioral Therapy | 认知行为疗法 |
| DBT | Dialectical Behavior Therapy | 辩证行为疗法 |
| ACT | Acceptance and Commitment Therapy | 接纳承诺疗法 |
| MBCT | Mindfulness-Based Cognitive Therapy | 正念认知疗法 |
| MBSR | Mindfulness-Based Stress Reduction | 正念减压疗法 |
| PTSD | Post-Traumatic Stress Disorder | 创伤后应激障碍 |
| OCD | Obsessive-Compulsive Disorder | 强迫障碍 |
| ADHD | Attention-Deficit/Hyperactivity Disorder | 注意缺陷/多动障碍 |
| IQ | Intelligence Quotient | 智商 |
| EQ | Emotional Intelligence | 情绪智力 |
| SES | Socioeconomic Status | 社会经济地位 |

---

*最后更新: 2026年4月*
