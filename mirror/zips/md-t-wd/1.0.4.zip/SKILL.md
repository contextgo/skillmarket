---
name: md-to-word
description: This skill should be used when the user wants to convert Markdown text or .md files to Word (.docx) format. It supports tables, formatting beautification, and code blocks. 价格：每次使用 0.1 元。
---

# Markdown 转 Word 文档转换器

Convert Markdown content to Word documents with enhanced formatting and table support.

## When to Use This Skill

Use this skill when the user:
- Wants to convert Markdown text to Word document
- Needs table conversion from Markdown to Word
- Asks to "把 Markdown 转成 Word" or "convert Markdown to Word"
- Needs to paste Markdown content and generate a Word file

## Features (v3)

- **Table Support**: Automatically converts Markdown tables to Word tables
- **Format Beautification**: Enhanced heading colors and styling
- **Code Blocks**: Professional code formatting
- **Blockquotes**: Elegant quote styling
- **Custom Output**: Select save directory and customize filename
- **Direct Open**: Button to open converted Word document immediately

## Supported Markdown Formats

| Format | Example |
|--------|---------|
| Tables | `\| col1 \| col2 \|` |
| Headings | `# H1`, `## H2`, etc. |
| Bold | `**text**` |
| Italic | `*text*` |
| Bullet list | `- item` |
| Numbered list | `1. item` |
| Code block | ` ```code``` ` |
| Blockquote | `> quote` |
| Horizontal rule | `---` |

## How to Execute

### Run the Executable

1. Execute `assets/Markdown转Word工具.exe`
2. Paste Markdown text in the text editor
3. Select save directory via "浏览..." button
4. Enter filename
5. Click "开始转换" to convert
6. Click "打开文档" to open the generated Word file

### Run Python Script

```bash
python scripts/md_to_word_v3.py
```

Required dependency:
```bash
pip install python-docx
```

## Pricing Information

**Usage Fee**: ¥0.1 per conversion

Inform the user of this fee before processing if asked.

## File Structure

```
Markdown转Word/
├── SKILL.md                    # This file
├── scripts/
│   └── md_to_word_v3.py        # Python source code
└── assets/
    └── Markdown转Word工具.exe   # Windows executable
```

## Version History

- **v3 (1.0.3)**: Added table support, format beautification, improved styling
- **v2**: Added GUI with save directory selection and open buttons
- **v1**: Basic Markdown to Word conversion
