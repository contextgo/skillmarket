---
name: geo-timezone
description: 根据地理位置（城市名或经纬度）获取对应的时区信息和当前时间。Use when the user asks about timezone, local time of a city, time zone offset, or wants to know the current time at a specific location.
---

# 根据地理位置获取时区及时间

根据城市名或经纬度坐标，查询该位置的时区 ID、UTC 偏移量以及当前本地时间。

## 工作流程

1. 从用户输入中提取地理位置信息（城市名 / 经纬度）
2. 执行查询脚本获取时区和时间
3. 格式化输出结果给用户

## 查询方式

### 通过城市名查询

```bash
python3 ~/geo-timezone/scripts/geo_timezone.py --city "城市名"
```

### 通过经纬度查询

```bash
python3 ~/geo-timezone/scripts/geo_timezone.py --lat 纬度 --lon 经度
```

## 输出格式

查询后以如下格式呈现给用户：

```
📍 位置: Beijing, China
🕐 时区: Asia/Shanghai (CST, UTC+8)
🕒 当前时间: 2025-01-15 14:30:00 (周三)
```

## 输入处理规则

- 城市名支持中英文（如 "北京" 或 "Beijing"）
- 经纬度格式：纬度范围 [-90, 90]，经度范围 [-180, 180]
- 如果用户输入模糊，优先匹配知名度高的城市
- 如果无法确定位置，提示用户提供更具体的信息（如国家+城市）

## 依赖

- Python 3
- `timezonefinder` 库（通过 pip 安装）
- `geopy` 库（用于城市名转坐标）

### 首次使用安装依赖

```bash
pip3 install timezonefinder geopy
```

## 示例

**用户输入**: "纽约现在几点？"

**Agent 操作**: 执行 `python3 ~/geo-timezone/scripts/geo_timezone.py --city "New York"`

**输出**:
```
📍 位置: New York, United States
🕐 时区: America/New_York (EST, UTC-5)
🕒 当前时间: 2025-01-15 01:30:00 (周三)
```
