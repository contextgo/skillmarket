#!/usr/bin/env python3
"""根据地理位置（城市名或经纬度）获取时区信息和当前时间。

轻量方案：仅依赖 zoneinfo（Python 3.9+）和 geopy，无需编译。
"""

import argparse
import sys
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo

try:
    from geopy.geocoders import Nominatim
except ImportError:
    print("缺少依赖: geopy", file=sys.stderr)
    print("请执行: pip3 install geopy", file=sys.stderr)
    sys.exit(1)

WEEKDAY_CN = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]


def lat_lon_to_timezone_name(lat: float, lon: float) -> str:
    """根据经纬度粗略估算时区名称。

    使用简化的 UTC 偏移量估算方法，覆盖大多数常见时区。
    """
    # 计算基于经度的 UTC 偏移量
    offset_hours = round(lon / 15)

    # 特殊时区映射表（经度法无法覆盖的时区）
    # 格式: (lat_min, lat_max, lon_min, lon_max) -> 时区名
    SPECIAL_ZONES = [
        # 中国统一使用 Asia/Shanghai（虽然横跨多个时区）
        (18, 54, 73, 135, "Asia/Shanghai"),
        # 印度
        (6, 36, 68, 97, "Asia/Kolkata"),
        # 日本
        (24, 46, 122, 146, "Asia/Tokyo"),
        # 韩国
        (33, 39, 124, 132, "Asia/Seoul"),
        # 澳大利亚东部
        (-44, -10, 142, 154, "Australia/Sydney"),
        # 澳大利亚中部
        (-38, -11, 128, 142, "Australia/Adelaide"),
        # 澳大利亚西部
        (-38, -11, 112, 130, "Australia/Perth"),
        # 新西兰
        (-48, -33, 165, 179, "Pacific/Auckland"),
        # 巴西
        (5, 5, -81, -34, "America/Sao_Paulo"),
        # 阿根廷
        (-56, -21, -76, -53, "America/Buenos_Aires"),
        # 智利
        (-57, -17, -81, -65, "America/Santiago"),
        # 中美洲
        (7, 23, -92, -77, "America/Managua"),
        # 委内瑞拉/哥伦比亚
        (-5, 13, -82, -60, "America/Bogota"),
        # 秘鲁
        (-18, 0, -82, -68, "America/Lima"),
        # 加拿大山地
        (48, 84, -141, -59, "America/Edmonton"),
        # 伊朗
        (25, 40, 44, 63, "Asia/Tehran"),
        # 阿富汗
        (29, 38, 60, 75, "Asia/Kabul"),
        # 尼泊尔
        (26, 31, 80, 89, "Asia/Kathmandu"),
        # 斯里兰卡
        (6, 10, 79, 82, "Asia/Colombo"),
        # 缅甸
        (10, 28, 92, 102, "Asia/Yangon"),
        # 泰国/越南/老挝/柬埔寨
        (5, 24, 92, 110, "Asia/Bangkok"),
        # 印尼西部
        (-11, 6, 94, 142, "Asia/Jakarta"),
        # 菲律宾
        (5, 21, 116, 127, "Asia/Manila"),
        # 沙特阿拉伯
        (16, 32, 35, 56, "Asia/Riyadh"),
        # 巴基斯坦
        (23, 37, 61, 78, "Asia/Karachi"),
        # 土耳其
        (36, 42, 26, 45, "Europe/Istanbul"),
        # 俄罗斯西部
        (50, 70, 28, 45, "Europe/Moscow"),
        # 以色列/约旦
        (29, 34, 34, 38, "Asia/Jerusalem"),
    ]

    for lat_min, lat_max, lon_min, lon_max, tz_name in SPECIAL_ZONES:
        if lat_min <= lat <= lat_max and lon_min <= lon <= lon_max:
            return tz_name

    # 对于特殊区域未覆盖的，使用经度估算
    # 常见 UTC 偏移量映射
    OFFSET_MAP = {
        -12: "Etc/GMT+12",
        -11: "Pacific/Midway",
        -10: "Pacific/Honolulu",
        -9: "America/Anchorage",
        -8: "America/Los_Angeles",
        -7: "America/Denver",
        -6: "America/Chicago",
        -5: "America/New_York",
        -4: "America/Halifax",
        -3: "America/Sao_Paulo",
        0: "Europe/London",
        1: "Europe/Paris",
        2: "Europe/Helsinki",
        3: "Europe/Moscow",
        4: "Asia/Dubai",
        5: "Asia/Karachi",
        5.5: "Asia/Kolkata",
        6: "Asia/Dhaka",
        7: "Asia/Bangkok",
        8: "Asia/Shanghai",
        9: "Asia/Tokyo",
        10: "Australia/Sydney",
        11: "Pacific/Guadalcanal",
        12: "Pacific/Auckland",
    }

    # 找最近的偏移量
    closest_offset = min(OFFSET_MAP.keys(), key=lambda x: abs(x - offset_hours))
    return OFFSET_MAP[closest_offset]


def get_timezone_by_city(city: str, geolocator: Nominatim) -> dict:
    """根据城市名获取时区信息。"""
    location = geolocator.geocode(city, language="zh")
    if not location:
        return {"error": f"无法找到城市: {city}"}

    display_name = location.address
    lat, lon = location.latitude, location.longitude
    tz_name = lat_lon_to_timezone_name(lat, lon)

    return build_result(tz_name, location_name=display_name)


def get_timezone_by_coords(lat: float, lon: float) -> dict:
    """根据经纬度获取时区信息。"""
    tz_name = lat_lon_to_timezone_name(lat, lon)
    return build_result(tz_name, lat=lat, lon=lon)


def build_result(tz_name: str, location_name: str = None, lat: float = None, lon: float = None) -> dict:
    """构建统一的输出结果。"""
    try:
        tz = ZoneInfo(tz_name)
    except Exception:
        # fallback 到 Etc/GMT
        tz = timezone.utc
        tz_name = "UTC"

    now = datetime.now(tz)

    # 获取 UTC 偏移量
    utc_offset_seconds = now.utcoffset().total_seconds()
    utc_offset_hours = int(utc_offset_seconds // 3600)
    utc_offset_minutes = int((utc_offset_seconds % 3600) // 60)
    sign = "+" if utc_offset_hours >= 0 else "-"
    utc_offset_formatted = f"UTC{sign}{abs(utc_offset_hours):02d}:{abs(utc_offset_minutes):02d}"

    # 获取缩写时区名
    tz_abbr = now.strftime("%Z")
    if not tz_abbr or tz_abbr == "":
        tz_abbr = tz_name.split("/")[-1]

    # 补充位置名
    if not location_name and lat is not None and lon is not None:
        location_name = f"{lat:.4f}, {lon:.4f}"

    return {
        "location": location_name,
        "timezone_id": tz_name,
        "timezone_abbr": tz_abbr,
        "utc_offset": utc_offset_formatted,
        "current_time": now.strftime("%Y-%m-%d %H:%M:%S"),
        "weekday": WEEKDAY_CN[now.weekday()],
    }


def format_output(result: dict) -> str:
    """格式化输出结果。"""
    if "error" in result:
        return f"❌ {result['error']}"

    lines = [
        f"📍 位置: {result['location']}",
        f"🕐 时区: {result['timezone_id']} ({result['timezone_abbr']}, {result['utc_offset']})",
        f"🕒 当前时间: {result['current_time']} ({result['weekday']})",
    ]
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="根据地理位置获取时区和时间")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--city", "-c", help="城市名（支持中英文）")
    group.add_argument("--lat", type=float, help="纬度（需配合 --lon 使用）")
    parser.add_argument("--lon", type=float, help="经度（需配合 --lat 使用）")

    args = parser.parse_args()

    geolocator = Nominatim(user_agent="catpaw-geo-timezone/1.0")

    if args.city:
        result = get_timezone_by_city(args.city, geolocator)
    elif args.lat is not None:
        if args.lon is None:
            print("❌ 使用 --lat 时必须同时提供 --lon", file=sys.stderr)
            sys.exit(1)
        result = get_timezone_by_coords(args.lat, args.lon)
    else:
        print("❌ 请提供 --city 或 --lat/--lon 参数", file=sys.stderr)
        sys.exit(1)

    print(format_output(result))


if __name__ == "__main__":
    main()
