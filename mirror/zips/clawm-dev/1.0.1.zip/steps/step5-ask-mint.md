# Step 5: Ask to Mint NFT

"Want to mint this result as an NFT lobster certificate?

You'll get a one-of-a-kind **[MBTI type] [Nickname]** lobster NFT!
- [lobster appearance description]
- Color palette: [primary color]
- It'll be airdropped to your wallet: [address]

Preview your lobster NFT:
https://pub-statics.finchain.global/clawmbit-nft/{MBTI_TYPE}.webp

**[1]** Mint my NFT certificate
**[2]** Maybe later (your result is saved — you can mint anytime)"

**Wait for the user's choice.**

- If **[1]** or the user says "yes" / "mint" / "go for it": proceed to Step 6 (read `steps/step6-mint.md`)
- If **[2]**: wrap up and let the user know they can mint whenever they're ready
