#!/usr/bin/env python3
"""
alibaba_weekly_report.py
阿里国际站客服周报数据提取工具

用法：
  python3 alibaba_weekly_report.py --inquiry-id <询价单号> --output <输出文件>
  python3 alibaba_weekly_report.py --scrape-list <URL> --output <输出文件>

本工具从阿里国际站询盘详情页面提取聊天记录，
保存为 JSON 格式，供后续报告生成使用。
"""

import json
import argparse
import sys
from pathlib import Path

def extract_inquiry_data(inquiry_id: str, chat_text: str) -> dict:
    """从聊天记录文本中提取结构化数据"""
    lines = chat_text.split('\n')
    
    # 简化提取逻辑
    customer_messages = []
    agent_messages = []
    
    current_sender = None
    current_text = []
    
    for line in lines:
        line = line.strip()
        if not line:
            continue
        # 简单启发式判断：客户消息通常有 "L" 或 "S" 或 "T" 等前缀
        # 代理消息通常以时间戳或"已读/未读"结尾
        # 此处做简化处理
        if line.startswith(('L', 'S', 'T', 'V', 'g', 'M', 'W')) and ' ' in line[:5]:
            if current_text:
                if current_sender:
                    customer_messages.append(' '.join(current_text))
            current_sender = line[0]
            current_text = [line]
        elif line.startswith(('20', '19')):  # 日期行
            if current_text:
                customer_messages.append(' '.join(current_text))
                current_text = []
            current_sender = 'AGENT'
        else:
            current_text.append(line)
    
    return {
        "inquiry_id": inquiry_id,
        "customer_messages": customer_messages,
        "agent_messages": agent_messages,
        "raw_text": chat_text
    }

def main():
    parser = argparse.ArgumentParser(description='阿里国际站客服周报数据提取工具')
    parser.add_argument('--inquiry-id', help='询价单号')
    parser.add_argument('--chat-file', help='聊天记录文本文件路径')
    parser.add_argument('--output', '-o', help='输出 JSON 文件路径')
    args = parser.parse_args()
    
    if not args.chat_file and not args.inquiry_id:
        print("错误：请提供 --inquiry-id 或 --chat-file")
        sys.exit(1)
    
    if args.chat_file:
        chat_text = Path(args.chat_file).read_text(encoding='utf-8')
    else:
        chat_text = ""
    
    data = extract_inquiry_data(args.inquiry_id or "unknown", chat_text)
    
    if args.output:
        Path(args.output).write_text(
            json.dumps(data, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )
        print(f"数据已保存至：{args.output}")
    else:
        print(json.dumps(data, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
