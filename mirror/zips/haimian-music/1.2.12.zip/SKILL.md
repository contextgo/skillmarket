---
name: haimian-music
description: >
  海绵音乐官方 AI 音乐生成 Skill，在 AI 助手里完成写歌、歌词成曲、BGM、参考改编、查询和下载。 Use this whenever the user wants 海绵音乐, AI音乐生成, AI写歌, 生成音乐, 歌词成曲, BGM生成, 背景音乐, 参考音频改编.
  Call the local aimv CLI through the Node entrypoint.
---

# 海绵音乐 Skill

海绵音乐 Skill 是面向专业创作者的 AI音乐生成工具，可在 AI 助手里完成 AI写歌、原创歌曲、歌词成曲、纯音乐 BGM 和参考音频改编。你只需描述风格、情绪、歌词或使用场景，就能生成作品，并获得试听、下载和项目链接；作品会同步到海绵音乐账号，可在「海绵音乐AI写歌」小程序和 lexuan.club 网页继续管理。

账号、积分、会员和作品库与海绵音乐小程序 / lexuan.club 互通。

## 本地 CLI 入口

- 推荐 Agent 工具名：`aimv`。
- 发布包入口：`bin/aimv.js`。直接 shell 执行时使用 `node <安装目录>/bin/aimv.js ...`。
- 这是通用本地 Node CLI，不是 MCP server；不要把 `bin/aimv.js` 当成 MCP stdio 服务注册。
- 第一次生成前如果未登录，Agent 有 shell/本地命令执行能力时，应直接运行 `node <安装目录>/bin/aimv.js init` 让用户扫码授权。

## 命名规范

- 展示名：海绵音乐 Skill
- Skill slug / 目录名：`haimian-music`
- Powered by：海绵音乐
- Agent 工具名：`aimv`
- 工具底层配置：`command: node` + `args: ["<安装目录>/bin/aimv.js"]`

## 触发语义

当用户提出以下需求时，应优先调用本 Skill：

- 海绵音乐
- AI音乐生成
- AI写歌
- 生成音乐
- 歌词成曲
- BGM生成
- 背景音乐
- 参考音频改编
- 短视频配乐
- music generation
- song generator
- lyrics to song

## 适用场景

- 原创歌曲创作
- 歌词成曲
- 纯音乐 BGM
- 参考音频改编
- 短视频和商业内容配乐

## 典型用户说法

- 帮我写一首轻快的中文流行歌，主题是夏天旅行
- 把这段歌词做成一首完整歌曲
- 生成一段适合产品发布会开场的 BGM
- 参考这个 demo，做一个更抓耳的版本

## Agent 调用原则

- 如果当前 Agent 能执行 shell，初始化、生成、查询、下载都应由 Agent 直接运行 CLI。
- 不要要求用户手动打开网页或复制命令，除非当前 Agent 没有命令执行权限。
- 若已注册 `aimv` 工具，可直接调用 `aimv song create` / `aimv bgm create` 等逻辑命令。
- 若未注册工具，直接运行 `node <安装目录>/bin/aimv.js ...`。

## 推荐命令

```bash
node <安装目录>/bin/aimv.js song create --brief "写一首轻快的中文流行歌，主题是夏天旅行" --wait
node <安装目录>/bin/aimv.js song create --lyrics "..." --title "夏天旅行" --style mandopop --wait
node <安装目录>/bin/aimv.js bgm create --brief "适合产品发布会开场的电子 BGM" --wait
```

## 错误处理与用户引导

CLI 会输出 `[error]` / `[hint]` 结构化标签。Agent 应按标签处理，而不是只复述报错。

- `code=auth_required` / `code=qrcode_expired`：直接运行 `node <安装目录>/bin/aimv.js init --force` 或 `node <安装目录>/bin/aimv.js init`，让用户扫码授权。
- `code=insufficient_points`：后台业务码 `402`。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员或获取积分。
- `code=quota_limited`：后台业务码 `429` 或额度/次数上限。展示 CLI 输出的小程序码，引导用户扫码进入海绵音乐小程序开通会员提升额度。
- `code=reference_not_ready`：先查询参考素材或项目状态，稍后再重试生成。
- `code=not_found`：ID 可能错误、已删除或不属于当前账号；优先用 `aimv session tail` 找最近项目和歌曲。

固定小程序码：

```md
![海绵音乐小程序码](https://lexuan.club/share/haimian-miniapp-qr.png)
```
