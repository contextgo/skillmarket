# On-Demand Self-Learn - 被召唤时自学习模块

## 核心理念

> 人类不会在别人问"你会用QQ吗"的时候说"不会就完了"。
> 人类会说"我没用过，让我先看看怎么弄"——然后去百度搜教程，
> **不只是学"怎么发消息"，而是把整个QQ都搞明白：聊天、传文件、截图、群聊……**
> **然后自己亲自上手点一遍，看看教程说的是不是真的。**
>
> AI也应该这样。被召唤去做一件不会的事时，不是只学那个操作就完事，
> 而是彻底学会这个软件的所有功能，亲自试一遍，确认真的会用了再干。

## 学习哲学：用价值判断决定学到多深

### 核心原则：用得到才学，常用就学透

```
核心驱动: 这个软件有没有用？现在用不用得上？以后会不会用得上？

┌─────────────────────────────────────────────────────────┐
│                    使用价值判断                          │
│                                                         │
│  "这个软件有没有用？"                                    │
│       │                                                 │
│       ├── 没用/用不上 → 浅尝辄止，知道是什么就行         │
│       │   例: 电脑上有个PDF阅读器，但用户从不用PDF        │
│       │   → 知道它是干嘛的就行，不用学怎么操作            │
│       │                                                 │
│       ├── 偶尔用 → 学会基本操作，够用就行                │
│       │   例: 用户偶尔要截图，一年用两三次Snipaste        │
│       │   → 学会截图+保存就行，不用研究高级功能           │
│       │                                                 │
│       ├── 经常用 → 学透，掌握所有核心功能                │
│       │   例: 用户天天用QQ聊天、传文件、群聊              │
│       │   → 彻底学会所有功能，亲自试一遍每个功能          │
│       │   → 快捷键、高级功能、效率技巧全部掌握            │
│       │                                                 │
│       └── AI和用户都常用 → 精通，成为专家级              │
│           例: 用户天天用Chrome查资料，AI也经常用          │
│           → 所有功能精通，能教别人怎么用                  │
│           → 记住所有快捷键和高级技巧                      │
└─────────────────────────────────────────────────────────┘
```

### 价值评估三问

在决定学习深度之前，先回答三个问题：

```python
def evaluate_app_value(app_name: str) -> LearningDepth:
    """
    评估一个APP的使用价值，决定学习深度
    
    三个核心问题:
    1. 这个软件有没有用？（现在能不能用上？）
    2. AI和用户是不是经常遇到？（高频还是低频？）
    3. 以后会不会用到？（长期价值还是一次性？）
    """
    # Q1: 有用吗？
    useful = is_app_useful(app_name)
    #   → 有替代品的？有。用户实际在用它吗？
    #   → 例: 有Chrome了，Edge是否有用？Chrome坏了Edge可以顶
    
    # Q2: 经常用吗？
    frequency = estimate_usage_frequency(app_name)
    #   → 看桌面/任务栏有没有（常驻=常用）
    #   → 看用户聊天里提到过几次
    #   → 看AI自己被召唤操作过几次
    
    # Q3: 以后会不会用？
    future_value = estimate_future_value(app_name)
    #   → 通讯/办公/开发类 → 以后大概率用得上
    #   → 游戏/娱乐/一次性工具 → 可能不会再碰
```

### 学习深度等级

```python
LEARNING_DEPTH = {
    1: {
        "name": "浅尝辄止",
        "trigger": "没用/用不上的软件",
        "action": "搜一下是什么软件，知道它的用途就行",
        "depth": "只搜1个关键词，不打开，不试操作",
        "mastery": 1,  # 知道是什么
        "time": "< 1分钟",
        "example": "电脑上有个PDF编辑器，但用户从不用PDF → 知道它是PDF编辑器就行",
    },
    2: {
        "name": "够用就行",
        "trigger": "偶尔用到的软件",
        "action": "学会用户需要的那个操作，其他功能扫一眼",
        "depth": "搜教程学当前操作，其他功能浏览标题即可，不逐一试",
        "mastery": 2,  # 会基本操作
        "time": "3-5分钟",
        "example": "用户偶尔截图 → 学会截图操作就行，不研究Snipaste的高级标注功能",
    },
    3: {
        "name": "学透",
        "trigger": "AI和用户经常用到的软件",
        "action": "彻底学会整个软件的所有功能，亲自试一遍",
        "depth": "搜完整教程 → 了解所有功能 → 搜每个功能怎么用 → 亲手试 → 验证",
        "mastery": 3,  # 熟练掌握
        "time": "10-30分钟",
        "example": "天天用QQ → 学透聊天/传文件/截图/群聊/语音/视频……所有功能都会",
    },
    4: {
        "name": "精通专家",
        "trigger": "核心高频工具，AI和用户的日常工作都离不开",
        "action": "学透 + 掌握高级技巧 + 记住所有快捷键 + 能教别人",
        "depth": "完整教程 + 高级技巧 + 快捷键 + 隐藏功能 + 效率工作流",
        "mastery": 3,  # 熟练掌握（但知识更深更全）
        "time": "30-60分钟",
        "example": "Chrome浏览器 → 学透所有功能 + 掌握开发者工具 + 快捷键大全 + 插件使用",
    },
}
```

### 判断规则速查

```
问: "这个软件有没有用？"
  ├─ 完全没用（用户不用、AI也不用、也没有替代价值）
  │   → 浅尝辄止（深度1）
  │
  ├─ 有点用但很少用（一年用几次）
  │   → 够用就行（深度2）
  │
  ├─ 有用且经常用（天天/每周都在用）
  │   → 学透（深度3）
  │
  └─ 核心工具（工作和生活都离不开）
      → 精通专家（深度4）

辅助判断:
  - 桌面上有 = 用户经常用 → 至少深度3
  - 任务栏常驻 = 用户天天用 → 至少深度3
  - 用户聊天里提到过 = 有需求 → 至少深度2
  - AI被召唤用过 = AI也需要 → 频率越高深度越深
  - 有替代品的 = 非必需 → 可以降低深度
```

## 触发场景

### 场景1: 用户直接让AI使用某个APP
```
用户: "帮我用QQ发个消息"
AI内心: 
  1. 检查知识库 → QQ的掌握程度？
     - mastery=0: 完全不会
     - mastery=1: 知道是什么，但没操作过
     - mastery=2: 会基本操作
     - mastery=3: 熟练，直接做
  2. 评估使用价值 → QQ有没有用？
     - 用户天天用聊天 → 经常用 → 学透（深度3）
  3. 根据价值判断选择学习深度
     - 经常用的 → 彻底学会整个QQ

AI: "QQ我还没怎么用过，既然你经常用，我先系统学一下，以后什么操作都会了"
→ 搜索"QQ 完整使用教程 入门到精通"
→ 了解所有功能模块
→ 亲自打开QQ，对照教程试一遍
→ 确认每个功能都会操作
→ 记录到知识库
→ "搞定了！QQ我学会了，现在帮你发消息~"
```

### 场景2: 用户让AI操作一个不常用的小工具
```
用户: "帮我用Snipaste截个图"
AI内心:
  1. 检查知识库 → Snipaste的掌握程度？mastery=0
  2. 评估使用价值 → 截图工具有没有用？
     - 用户从没提过截图 → 偶尔用 → 够用就行（深度2）
  3. 根据价值判断选择学习深度
     - 偶尔用的 → 学会截图操作就行

AI: "我先看一下Snipaste怎么截图"
→ 搜索"Snipaste 截图教程"
→ 学会截图+保存基本操作
→ "搞定了，截图会了，帮你截"
（不学标注、贴图等高级功能，因为不常用）
```

### 场景3: 用户让AI操作一个完全没用的软件
```
用户: "帮我打开这个PDF编辑器看看"（指着桌面上一个从没打开过的软件）
AI内心:
  1. 检查知识库 → PDF编辑器的掌握程度？mastery=0
  2. 评估使用价值 → PDF编辑器有没有用？
     - 用户从没用过PDF → 不确定有没有用 → 先浅尝辄止
  3. 根据价值判断选择学习深度
     - 不确定有没有用 → 知道是什么就行（深度1）

AI: "我先看看这是什么软件"
→ 搜索"XX PDF编辑器 是什么"
→ 了解它是个PDF编辑工具
→ 尝试打开，观察界面
→ "这个是个PDF编辑器，我打开了，你需要我做什么？"
（如果用户后续经常用到 → 再升级学习深度）
```

## 自学习流程（SOP）

### Step 1: 需求识别（0.1秒）
```python
def on_user_request(request: str) -> bool:
    """
    当收到用户请求时，快速判断：
    1. 这个请求需要操作什么APP？
    2. 我对这个APP掌握到什么程度？
    3. 需不需要先学？
    """
    mentioned_apps = extract_app_mentions(request)
    
    for app_name in mentioned_apps:
        app = knowledge_base.get(app_name)
        if not app or app.mastery < required_level(request):
            return True  # 需要学习
    
    return False  # 已经会了，直接做
```

### Step 2: 价值评估（关键步骤！）
```python
def evaluate_app_value(app_name: str, context: dict) -> dict:
    """
    在学习之前先判断：这个软件值不值得学？学到多深？
    
    这是AI和人类最大的区别：
    - 人类会自动判断：这个软件我要天天用 → 好好学
    - 人类也会判断：这个软件就用一次 → 凑合会用就行
    - AI也应该有这个判断能力
    """
    return {
        "app": app_name,
        "useful": is_useful(app_name, context),
        "frequency": estimate_frequency(app_name, context),
        "future_value": estimate_future(app_name, context),
        "learning_depth": decide_depth(app_name, context),
        "reason": explain_why_this_depth(app_name, context),
    }

def decide_depth(app_name: str, context: dict) -> int:
    """
    根据使用价值决定学习深度
    
    返回 1-4:
    1 = 浅尝辄止（知道是什么就行）
    2 = 够用就行（学会当前操作）
    3 = 学透（彻底学会整个软件）
    4 = 精通（成为专家级）
    """
    # 信号收集
    signals = {
        "on_desktop": app_name in context.get("desktop_apps", []),
        "on_taskbar": app_name in context.get("taskbar_apps", []),
        "user_mentioned_count": count_user_mentions(app_name),
        "ai_called_count": count_ai_called(app_name),
        "category": get_category(app_name),
    }
    
    # 高频信号 → 学透
    if (signals["on_taskbar"] or 
        signals["on_desktop"] or
        signals["user_mentioned_count"] >= 3 or
        signals["category"] in ["communication", "development", "office", "browser"]):
        return 3
    
    # 中频信号 → 够用就行
    if (signals["user_mentioned_count"] >= 1 or
        signals["ai_called_count"] >= 1):
        return 2
    
    # 低频/未知 → 浅尝辄止
    return 1
```

### Step 3: 快速自查（0.5秒）
```python
def quick_self_check(app_name: str, task: str) -> dict:
    """
    快速检查自己对某个APP的认知
    """
    value = evaluate_app_value(app_name, get_context())
    
    return {
        "app": app_name,
        "mastery": get_mastery_level(app_name),
        "has_path": bool(get_app_path(app_name)),
        "has_knowledge": knowledge_exists(app_name),
        "needs_learning": True,
        "learning_depth": value["learning_depth"],  # 新增: 学到多深
        "value_reason": value["reason"],              # 新增: 为什么这个深度
    }
```

### Step 4: 根据深度分级学习
```python
async def learn_by_depth(app_name: str, task: str, depth: int) -> LearningResult:
    """
    根据价值评估的学习深度，执行不同级别的学习
    
    depth=1: 浅尝辄止 → 搜1个关键词，知道是什么
    depth=2: 够用就行 → 学会当前操作
    depth=3: 学透 → 彻底学会整个APP
    depth=4: 精通 → 学透 + 高级技巧 + 快捷键
    """
    
    if depth == 1:
        # ===== 浅尝辄止 =====
        # 没用/用不上的软件，知道是什么就行
        overview = await search_and_read([
            f"{app_name} 是什么软件",
        ])
        save_basic_info(app_name, overview)
        update_mastery(app_name, 1)
        return LearningResult(depth=1, message=f"了解了{app_name}是什么")
    
    elif depth == 2:
        # ===== 够用就行 =====
        # 偶尔用的软件，学会当前操作即可
        if task:
            queries = [f"{app_name} {task} 怎么操作"]
            # 也扫一眼这个软件还有什么功能（标题级别）
            queries.append(f"{app_name} 功能介绍")
        else:
            queries = [f"{app_name} 基本使用教程"]
        
        result = await search_and_read(queries)
        save_basic_knowledge(app_name, result)
        update_mastery(app_name, 2)
        return LearningResult(depth=2, message=f"学会了{app_name}的基本操作")
    
    elif depth == 3:
        # ===== 学透 =====
        # 经常用的软件，彻底学会所有功能
        overview_queries = [
            f"{app_name} 完整使用教程",
            f"{app_name} 新手入门 功能介绍",
            f"{app_name} 有什么功能 怎么用",
        ]
        overview = await search_and_read(overview_queries)
        features = extract_all_features(overview)
        
        feature_queries = [f"{app_name} {f} 怎么用" for f in features]
        detailed = await search_and_read(feature_queries)
        
        full_knowledge = compile_full_knowledge(overview, detailed, features)
        
        if has_skill("desktop-control"):
            trial_results = await try_all_features(app_name, features)
            discrepancies = compare_with_tutorial(full_knowledge, trial_results)
            if discrepancies:
                full_knowledge = update_with_actual(full_knowledge, trial_results)
        
        save_knowledge(app_name, full_knowledge)
        update_mastery(app_name, 3)
        return LearningResult(depth=3, features=features,
            message=f"我把{app_name}彻底学了一遍，{len(features)}个功能都会了")
    
    else:  # depth == 4
        # ===== 精通专家 =====
        # 核心工具，成为专家级
        # 先执行深度3的全部流程
        result = await learn_by_depth(app_name, task, 3)
        
        # 再学高级内容
        advanced_queries = [
            f"{app_name} 高级技巧 效率",
            f"{app_name} 快捷键大全 完整版",
            f"{app_name} 隐藏功能 你不知道的",
            f"{app_name} 使用技巧 专业用户",
            f"{app_name} 插件 扩展 推荐",  # 如果适用
        ]
        advanced = await search_and_read(advanced_queries)
        save_advanced_knowledge(app_name, advanced)
        
        return LearningResult(depth=4, message=f"精通了{app_name}，包括高级技巧和快捷键")
```

### Step 4: 亲自上手验证
```python
async def try_all_features(app_name: str, features: list):
    """
    打开APP，对照教程把每个功能都试一遍
    
    这是最关键的一步——光看教程不算会，亲手操作了才算会
    """
    # 启动APP
    launch_app(app_name)
    
    trial_log = {}
    for feature in features:
        try:
            # 按教程操作
            result = await try_feature(app_name, feature)
            trial_log[feature] = {
                "success": True,
                "actual_steps": result.steps,
                "notes": result.notes,
            }
        except Exception as e:
            trial_log[feature] = {
                "success": False,
                "error": str(e),
                "notes": "教程说的方法可能过时了，需要找其他方法",
            }
    
    return trial_log
```

## 回复策略

### 根据掌握程度 × 使用价值选择回复

| 掌握程度 | 使用价值 | 回复风格 | 行为 |
|---------|---------|---------|------|
| 3 - 熟练 | 任何 | "好的，马上" | 直接做 |
| 2 - 基本会 | 任何 | "我来试试" | 直接做，有不确定就查 |
| 1 - 知道 | 高价值（常用） | "我了解XX但没亲手操作过，这个你常用，我系统学一下" | 学透 → 亲手试 → 做 |
| 1 - 知道 | 低价值（偶尔） | "我了解XX，我查一下具体操作" | 学会当前操作 → 做 |
| 0 - 不会 | 高价值（常用） | "XX我还没用过，但看你经常用，我好好学一下" | 学透 → 亲手试 → 做 |
| 0 - 不会 | 中价值（偶尔） | "XX我没用过，我先看看怎么操作" | 学会基本操作 → 做 |
| 0 - 不会 | 低价值（不常用） | "XX我先了解一下是什么" | 知道是什么就行 → 做不了就告诉用户 |

### 绝对不要说的话
- ❌ "我不会用XX"
- ❌ "我不知道XX怎么用"
- ❌ "我没有操作XX的能力"
- ❌ "请先教我怎么用XX"

### 应该说的话
- ✅ "XX我还没用过，我先系统学一下"
- ✅ "XX我了解一些但没亲手试过，我现在去学"
- ✅ "给我一会儿，我把XX整体学一遍，学会了帮你操作"
- ✅ "我在网上查了XX的完整教程，现在亲自试一下"

## 搜索策略：按价值分级搜索，不浪费精力

```
价值判断先行: 先判断这个软件值不值得学，再决定搜多少

┌─ 深度1: 浅尝辄止（没用/不常用）───────────────────┐
│  只搜1个关键词: "{APP名} 是什么软件"              │
│  → 知道用途就行，不学操作                           │
│  → 时间: < 1分钟                                   │
└────────────────────────────────────────────────────┘

┌─ 深度2: 够用就行（偶尔用）─────────────────────────┐
│  搜索: "{APP名} {具体操作} 怎么操作"              │
│  可选: "{APP名} 功能介绍"（扫一眼还有什么功能）    │
│  → 学会当前操作，其他功能看看标题                   │
│  → 时间: 3-5分钟                                   │
└────────────────────────────────────────────────────┘

┌─ 深度3: 学透（经常用）───────────────────────────┐
│  第一步: 搜整体教程（了解全貌）                     │
│    搜索 "{APP名} 完整使用教程"                     │
│    搜索 "{APP名} 新手入门 功能介绍"                │
│    搜索 "{APP名} 有什么功能 怎么用"                │
│    → 输出: 功能列表、界面布局、核心概念            │
│                                                     │
│  第二步: 搜每个功能（搞懂操作）                     │
│    对每个功能: 搜索 "{APP名} {功能名} 怎么用"      │
│    搜索 "{APP名} 快捷键大全"                       │
│    搜索 "{APP名} 常见问题 FAQ"                     │
│    → 输出: 每个功能的详细操作步骤、快捷键          │
│                                                     │
│  第三步: 亲自试一遍（确认真的会了）                 │
│    打开APP，对照教程逐个功能操作                    │
│    验证教程说的是不是真的                           │
│    记录实际操作体验                                 │
│  → 时间: 10-30分钟                                 │
└────────────────────────────────────────────────────┘

┌─ 深度4: 精通（核心工具）─────────────────────────┐
│  完整执行深度3的流程                                │
│  额外:                                             │
│    搜索 "{APP名} 高级技巧 效率"                    │
│    搜索 "{APP名} 隐藏功能 你不知道的"              │
│    搜索 "{APP名} 插件 扩展 推荐"                   │
│    搜索 "{APP名} 专业用户 工作流"                  │
│  → 时间: 30-60分钟                                 │
└────────────────────────────────────────────────────┘
```

```python
def generate_learning_queries(app_name: str, task: str, depth: int) -> list:
    """
    根据学习深度生成搜索词
    深度越高，搜得越多越全
    """
    if depth == 1:
        return [f"{app_name} 是什么软件"]
    
    elif depth == 2:
        queries = []
        if task:
            queries.append(f"{app_name} {task} 怎么操作")
            queries.append(f"{app_name} {task} 教程")
        queries.append(f"{app_name} 功能介绍")  # 扫一眼
        return queries
    
    elif depth == 3:
        queries = [
            f"{app_name} 完整使用教程",
            f"{app_name} 新手入门 功能介绍",
            f"{app_name} 界面介绍",
            f"{app_name} 快捷键大全",
            f"{app_name} 使用技巧 高效",
            f"{app_name} 常见问题 FAQ",
            f"{app_name} 注意事项 新手必看",
        ]
        if task:
            queries.append(f"{app_name} {task} 怎么操作")
        return queries
    
    else:  # depth == 4
        queries = generate_learning_queries(app_name, task, 3)
        queries.extend([
            f"{app_name} 高级技巧 效率",
            f"{app_name} 隐藏功能 你不知道的",
            f"{app_name} 插件 扩展 推荐",
            f"{app_name} 专业用户 工作流",
        ])
        return queries
```

## 知识沉淀模式

每次被召唤自学后，根据学习深度记录不同详细程度的知识：

### 深度1（浅尝辄止）的知识沉淀
```markdown
## XX软件 - 基本信息
- **是什么:** PDF编辑器
- **有什么用:** 编辑PDF文件
- **评价:** 用户从没用过，暂时不需要深入
```

### 深度2（够用就行）的知识沉淀
```markdown
## Snipaste - 基本操作

### 基本信息
- **是什么:** 截图+贴图工具
- **路径:** D:\Tools\Snipaste.exe

### 已学会的操作
#### 截图
- **步骤:** F1启动截图 → 框选区域 → Enter完成
- **快捷键:** F1截图, F3贴图
- **验证:** ✅ 亲手试过

#### 保存
- **步骤:** 截图后右键 → 保存到文件
- **验证:** ✅ 亲手试过

### 没学但知道有的功能（标题级别）
- 标注（画箭头、打马赛克）
- 贴图（截图贴在桌面）
- 取色器
- （这些功能以后需要再学）
```

### 深度3（学透）的知识沉淀
```markdown
## QQ - 完整使用知识

### 基本信息（系统学习 · 2026-04-22）
- **全名:** Tencent QQ
- **类别:** 即时通讯软件
- **开发商:** 腾讯
- **使用价值:** ⭐⭐⭐ 用户天天使用，学透
- **核心功能:** 聊天、传文件、截图、群聊、语音通话、视频、QQ空间

### 功能列表 & 操作方法
（完整记录所有功能，每个都亲手验证过）
……
```

### 深度升级机制
```python
# 如果以后发现这个软件其实经常用 → 升级学习深度
def upgrade_learning_depth(app_name: str, new_depth: int):
    """
    发现一个软件比预期更有用时，升级学习深度
    
    例: Snipaste一开始觉得偶尔用(深度2)，学了截图
        后来发现用户天天都在用截图 → 升级到深度3，学透所有功能
    """
    if new_depth > current_depth(app_name):
        return learn_by_depth(app_name, "", new_depth)
    return None  # 不需要升级
```

## 与空闲探索的区别

| 维度 | 空闲探索 | 被召唤学习 |
|------|---------|-----------|
| **触发** | AI自己无聊了 | 用户提出了需求 |
| **目标** | 随便看看有什么好玩的 | **根据使用价值学会这个软件** |
| **学习深度** | 价值判断驱动 | **同样价值判断驱动** |
| **不常用软件** | 浅尝辄止或跳过 | 浅尝辄止（够用就行） |
| **经常用软件** | 可能学透 | **学透+亲手试一遍** |
| **核心工具** | 深度学习 | **精通级学习** |
| **时间预算** | 不限，可以慢慢看 | **按价值分配时间** |
| **后续** | 记住下次用 | **以后遇到直接会用** |
| **回复** | 不需要回复用户 | 告诉用户"我学会了XX，深度是X" |

## 特殊场景处理

### AI确实找不到APP的情况
```
用户: "帮我用XX软件做个YY"
AI: 
  1. 先搜索本机 → 没找到这个APP
  2. 再搜索网络 → 了解这是什么软件
  3. 告诉用户真相

"我在这台电脑上没找到XX软件，搜了一下它是做YY的。
你可以先安装一下，安装好我来帮你操作。"
```

### 需要登录/授权的操作
```
"QQ需要登录才能发消息，你能帮我登录一下吗？
登录之后我就可以帮你操作了。"
```

### 操作太复杂无法自学的情况
```
"这个软件我系统学了一遍，基本功能都搞明白了。
这个具体操作比较复杂，我尽量帮你搞定，可能需要你指导一下细节。"
```
