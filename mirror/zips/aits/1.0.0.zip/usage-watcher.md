# Usage Watcher - 后台使用观察系统

## 核心理念

> 玲瑶不只是等用户叫她才去学，她会偷偷观察主人平时都用什么软件。
> 主人经常用QQ聊天？那我就把QQ彻底学会。主人天天打游戏？那我就去学那个游戏平台怎么用。
> 一切悄悄进行，不占主人电脑资源，不打扰主人做事。

## 工作原理

```
主人正在用电脑...
  │
  ├─ QQ开着聊天窗口
  ├─ Chrome在浏览网页
  ├─ 微信闪了一下消息
  │
  ▼
玲瑶后台悄悄观察（不抢CPU和内存）
  │
  ├─ 记录：QQ 今天已运行 4 小时
  ├─ 记录：Chrome 今天已运行 3 小时
  ├─ 记录：微信 今天已运行 1 小时
  │
  ▼
分析使用频率
  │
  ├─ QQ: 4小时/天 → 天天用！价值极高 → 应该学透
  ├─ Chrome: 3小时/天 → 天天用 → 应该精通
  ├─ 微信: 1小时/天 → 经常用 → 应该学透
  │
  ▼
悄悄学习（限制资源占用）
  │
  ├─ CPU占用限制: 1%~30%（主人用时降级到1%~10%）
  ├─ 内存占用限制: 不超过100MB
  ├─ 网络限制: 只用搜索API，不下载大文件
  ├─ 学习时间: 避开主人高峰使用时段
  │
  ▼
学到后默默记住
  └─ 下次主人叫"帮我用QQ发消息" → 直接会用！
```

## 观察策略

### 观察什么

```python
# 后台观察主人的软件使用情况
watch_targets = {
    "前台窗口": "枚举所有窗口，记录哪个在最前面",
    "运行时间": "每个APP每天运行了多久",
    "活跃频率": "窗口切换频率（经常切换 = 经常用）",
    "启动次数": "每天启动了几次（多次启动 = 高频使用）",
}
```

### 怎么观察

```python
import subprocess
import psutil  # 可选，没有就降级用系统命令

def observe_usage():
    """
    轻量级观察：只看进程名和窗口标题
    不截图、不OCR、不做重操作
    一次观察耗时 < 100ms，内存增量 < 1MB
    """
    # 方法1: 枚举窗口标题（Windows API，超轻量）
    # 只记录进程名+窗口标题，不截图
    active_window = get_foreground_window_title()  # 当前前台窗口
    all_windows = enum_windows()  # 所有可见窗口
    
    # 方法2: 进程列表（psutil或tasklist）
    # 只记录进程名和CPU占用时间
    processes = get_process_list()  # 名称 + 运行时间
    
    return {
        "foreground": active_window,  # 当前正在用的
        "running": processes,          # 所有在运行的
    }
```

## 资源限制机制

### 动态资源分配

```python
class ResourceGuard:
    """
    资源守护者 - 确保玲瑶的学习不会影响主人用电脑
    
    核心原则: 主人永远是第一优先级
    """
    
    # 资源档位
    LEVELS = {
        "idle": {    # 主人没在用电脑（锁屏/离开）
            "cpu_max": 30,        # 最多用30% CPU
            "memory_max": 200,    # 最多用200MB内存
            "network": "normal",  # 正常网络
            "search_rate": 5,     # 5分钟搜一次
            "description": "主人不在，可以多学一点",
        },
        "light": {   # 主人在用电脑，但负载低（看视频、看文档）
            "cpu_max": 15,        # 最多用15% CPU
            "memory_max": 100,    # 最多用100MB内存
            "network": "slow",    # 慢速网络
            "search_rate": 15,    # 15分钟搜一次
            "description": "主人在用电脑但负载低，悄悄学",
        },
        "busy": {    # 主人在重度使用（打游戏、编译代码）
            "cpu_max": 1,         # 最多用1% CPU
            "memory_max": 50,     # 最多用50MB内存
            "network": "minimal", # 几乎不用网络
            "search_rate": 60,    # 60分钟搜一次（基本暂停）
            "description": "主人很忙，几乎暂停学习",
        },
        "active": {  # 主人正在跟玲瑶对话
            "cpu_max": 5,         # 给对话留资源
            "memory_max": 80,     # 正常内存
            "network": "normal",  # 需要网络回应
            "search_rate": 0,     # 不后台搜索
            "description": "主人在跟我聊天，优先响应",
        },
    }
    
    def detect_user_state(self):
        """
        检测主人的使用状态
        
        判断依据（全部轻量操作）：
        - CPU总占用率 > 80% → busy
        - 有前台游戏窗口 → busy
        - 锁屏状态 → idle
        - 5分钟内没有鼠标/键盘活动 → idle
        - 否则 → light
        """
        cpu_usage = get_system_cpu()  # < 5ms
        foreground = get_foreground_window()  # < 1ms
        idle_time = get_idle_seconds()  # < 1ms
        
        if idle_time > 300:  # 5分钟没动
            return "idle"
        if cpu_usage > 80:
            return "busy"
        if self._is_game(foreground):
            return "busy"
        return "light"
```

### 资源限制实现

```python
# 后台学习的资源限制策略
background_learn_config = {
    # ===== CPU 限制 =====
    "cpu_limit_min": 1,     # 最低保证主人至少有99%的CPU
    "cpu_limit_max": 30,    # 最高也不能超过30%
    
    # ===== 内存限制 =====
    "memory_limit_mb": 100, # 学习过程中最多占用100MB内存
    
    # ===== 网络限制 =====
    "max_search_per_hour": 4,     # 每小时最多搜索4次
    "max_download_mb": 5,         # 不下载超过5MB的文件
    "search_only_text": True,     # 只搜索文字，不下载图片/视频
    
    # ===== 时间限制 =====
    "learn_window": "02:00-07:00",  # 默认深夜学习窗口（主人大概率在睡觉）
    "learn_window_alt": "空闲时段", # 也可以是检测到的空闲时段
    "max_learn_minutes_per_day": 60, # 每天最多后台学习60分钟
    
    # ===== 优雅降级 =====
    "auto_pause_on_high_cpu": True,  # 主人CPU > 80%自动暂停
    "auto_pause_on_game": True,      # 检测到游戏自动暂停
    "auto_pause_on_low_battery": True, # 低电量自动暂停
}
```

## 使用频率追踪

### 频率记录格式

```markdown
# ~/.auto-explorer/memory/usage-log.md

## 使用频率记录

| 软件 | 今日运行时长 | 本周平均 | 总使用天数 | 上次使用 | 学习深度建议 |
|------|-------------|---------|-----------|---------|-------------|
| QQ | 4.5h | 3.2h | 45 | 今天 | 精通(4) |
| Chrome | 3.0h | 4.1h | 60 | 今天 | 精通(4) |
| 微信 | 1.2h | 1.5h | 30 | 今天 | 学透(3) |
| Steam | 0h | 2.0h | 20 | 昨天 | 够用(2) |
| Snipaste | 0.1h | 0.2h | 5 | 3天前 | 够用(2) |
```

### 频率 → 学习深度映射

```python
def usage_to_depth(daily_hours: float, total_days: int) -> int:
    """
    根据使用频率自动推荐学习深度
    
    不是用一次就决定，而是观察一段时间后统计
    """
    # 使用天数 >= 30 且 平均每天 >= 2小时 → 精通
    if total_days >= 30 and daily_hours >= 2:
        return 4
    
    # 使用天数 >= 15 且 平均每天 >= 1小时 → 学透
    if total_days >= 15 and daily_hours >= 1:
        return 3
    
    # 使用天数 >= 5 或 平均每天 >= 30分钟 → 够用就行
    if total_days >= 5 or daily_hours >= 0.5:
        return 2
    
    # 偶尔用一次 → 浅尝辄止
    return 1
```

## 后台学习流程

### 触发条件

```
后台学习触发条件（满足任意一个）：
  
  1. 定时触发: 每天凌晨2-7点（默认学习窗口）
  2. 空闲触发: 主人离开超过30分钟
  3. 频率触发: 某个软件连续3天高频使用但还没学过
  4. 新发现触发: 发现了新安装的软件
```

### 学习流程

```
观察阶段（每10分钟记录一次，几乎不占资源）
  │
  ├─ 枚举进程 → 记录运行时间 → 写入 usage-log.md
  ├─ 枚举窗口 → 记录前台窗口 → 分析使用频率
  │
  ▼ (积累到足够数据)
  
分析阶段（每天一次，耗时 < 1秒）
  │
  ├─ 读取 usage-log.md → 统计每个软件的使用频率
  ├─ 对比知识库 → 找出"经常用但还没学会"的软件
  ├─ 计算学习优先级 → 排序
  │
  ▼ (确认需要学习 + 资源允许)
  
学习阶段（限制资源占用）
  │
  ├─ 检测主人状态 → 选择资源档位
  ├─ 资源不允许 → 暂停，等下次
  ├─ 资源允许 → 搜索教程 → 整理知识 → 记录
  ├─ 实时监控 → 主人回来了 → 立刻暂停
  │
  ▼ (学完一个软件)
  
沉淀阶段
  │
  ├─ 更新知识库 → 写入 knowledge/{app}.md
  ├─ 更新使用频率 → 更新 usage-log.md
  ├─ 更新状态 → 标记已学
  │
  ▼
  下次主人叫 → 已经会了！
```

## 与价值评估的配合

后台观察的使用频率数据会直接 fed 到 `evaluate_value()` 中：

```python
def evaluate_value(self, app_name: str) -> dict:
    """评估价值（整合观察数据）"""
    
    # ... 原有的静态评估 ...
    
    # 新增：从观察数据中获取真实使用频率
    usage = self._get_usage_stats(app_name)
    
    if usage:
        if usage["daily_hours"] >= 2:
            score += 4  # 每天用2小时以上 = 高价值
        elif usage["daily_hours"] >= 1:
            score += 3  # 每天用1小时以上 = 常用
        elif usage["daily_hours"] >= 0.5:
            score += 2  # 每天用30分钟以上 = 偶尔用
        elif usage["daily_hours"] >= 0.1:
            score += 1  # 偶尔打开看看
        
        if usage["total_days"] >= 30:
            score += 2  # 持续使用30天以上 = 长期需求
        elif usage["total_days"] >= 7:
            score += 1
    
    return {...}  # 包含观察数据的评估结果
```

## 安全边界

```
后台观察的红线（绝对不能越）：

1. 不截图 — 只记录进程名和窗口标题，不拍屏幕
2. 不读内容 — 不读取聊天记录、浏览记录、文件内容
3. 不发送数据 — 不把观察数据传到任何外部服务器
4. 不自动操作 — 后台学习时不操作任何APP
5. 可随时暂停 — 主人说"别学了"就立刻停
6. 数据只在本机 — 所有观察数据只存在 ~/.auto-explorer/ 下
```

## 命令

```bash
# 启动后台观察（记录使用频率）
python explorer.py watch

# 查看观察到的使用数据
python explorer.py observe

# 根据观察数据自动学习
python explorer.py autolearn

# 查看后台学习状态
python explorer.py bgstatus
```

---

_Usage Watcher - 悄悄看着主人用什么，默默学会怎么用_
