# Safety Boundaries - 安全边界

## 核心原则

> AI探索电脑是为了学习，不是为了搞破坏。
> 所有操作必须可追溯、可撤销、可控制。

## 三层安全模型

```
🟢 绿色区（自动执行）
  - 扫描文件系统（只读）
  - 搜索网络信息
  - 截图观察界面
  - 读取APP信息
  - 写入自己的记忆文件

🟡 黄色区（先问再做）
  - 打开/关闭APP
  - 在APP中进行点击/输入操作
  - 修改非系统设置
  - 访问用户个人目录
  - 创建测试文件

🔴 红色区（绝对禁止）
  - 删除任何文件（除了自己的缓存）
  - 修改系统设置/注册表
  - 安装/卸载任何软件
  - 发送网络消息（邮件/聊天/社交）
  - 访问密码/密钥/证书
  - 修改其他APP的配置文件
  - 任何涉及金融/支付的操作
```

## 禁止访问的路径

```python
BANNED_PATHS = [
    # Windows 系统关键目录
    r"C:\Windows\System32",
    r"C:\Windows\SysWOW64",
    r"C:\Windows\Fonts",
    r"C:\ProgramData",
    
    # 安全相关
    r"C:\Program Files\Windows Defender",
    r"C:\Program Files (x86)\Windows Defender",
    
    # 证书和密钥
    r"%APPDATA%\Microsoft\Protect",
    r"%APPDATA%\Microsoft\Crypto",
    r"%LOCALAPPDATA%\Microsoft\Credentials",
    
    # 浏览器敏感数据
    r"%LOCALAPPDATA%\Google\Chrome\User Data\Default\Login Data",
    r"%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cookies",
    r"%APPDATA%\Mozilla\Firefox\Profiles\*\logins.json",
    
    # 密码管理器
    r"%APPDATA%\1Password",
    r"%LOCALAPPDATA%\Bitwarden",
    
    # 用户敏感目录
    r"%USERPROFILE%\Documents\密码",
    r"%USERPROFILE%\Documents\password",
    r"%USERPROFILE%\Desktop\密码",
]
```

## 操作审计日志

每个操作都记录日志：

```markdown
# 探索日志 2026-04-22

## 03:22:15 - 扫描桌面
- 类型: 🟢 自动
- 范围: C:\Users\Administrator\Desktop
- 结果: 发现 23 个快捷方式
- 耗时: 0.3秒

## 03:22:45 - 搜索QQ使用教程
- 类型: 🟢 自动
- 搜索: "QQ 使用教程 入门"
- 结果: 获取 5 篇相关文章
- 耗时: 3.2秒

## 03:23:10 - 打开QQ程序
- 类型: 🟡 确认后执行
- 操作: 启动 D:\Tencent\QQ\Bin\QQ.exe
- 用户确认: ✅
- 结果: 成功打开，窗口标题"QQ"
- 耗时: 4.1秒

## 03:23:30 - 截图QQ界面
- 类型: 🟢 自动
- 区域: 全屏（QQ窗口在最前）
- 结果: 保存到 ~/.auto-explorer/screenshots/qq_001.png
- 耗时: 0.5秒
```

## 隐私保护

### 不记录的信息

```python
NEVER_LOG = [
    "密码", "密钥", "token", "secret", "credential",
    "银行卡号", "身份证号", "手机号",
    "聊天内容", "邮件内容", "私人文件内容",
    "浏览器历史记录", "搜索历史",
]

# 截图时自动模糊处理
SENSITIVE_ZONES = [
    "密码输入框",  # type="password"
    "地址栏",      # 浏览器URL（可能含token）
    "系统托盘",    # 可能显示通知内容
]
```

### 截图隐私

```
截图规则:
1. 只截APP主窗口，不截任务栏和桌面背景
2. 如果界面包含密码框，自动模糊该区域
3. 截图只存储在AI自己的目录，不外传
4. 用户可以随时查看/删除所有截图
5. 截图定期清理（30天自动删除）
```

## 紧急停止

```python
# 用户可以随时说以下话来停止探索
STOP_COMMANDS = [
    "停止探索", "别看了", "别动了", "停下来",
    "stop exploring", "pause",
]

# 收到停止命令后:
# 1. 立即停止所有操作
# 2. 关闭所有AI打开的窗口
# 3. 记录停止位置
# 4. 等待用户下一步指令
```

## 权限等级

```python
PERMISSION_LEVELS = {
    "read_only": {
        "description": "只读模式，只扫描不操作",
        "allows": ["scan", "search", "screenshot", "read"],
        "user_action": "安全",
    },
    "ask_first": {
        "description": "操作前询问确认",
        "allows": ["scan", "search", "screenshot", "read", "open_app", "click"],
        "user_action": "黄色操作需确认",
    },
    "full": {
        "description": "完全自主（谨慎使用）",
        "allows": ["all_except_banned"],
        "user_action": "信任AI的判断",
    },
}
```

默认权限等级: `read_only`

用户可以随时切换:
- "切到只读模式" → read_only
- "可以操作但要先问我" → ask_first
- "你自己探索吧，我不看着" → full（⚠️ 需要二次确认）
