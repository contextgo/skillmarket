# Memory & Decay - 记忆与遗忘系统

## 核心理念

> 人类的大脑不是硬盘，不会记住所有事情。
> 重要的记得牢，不常用的慢慢淡忘，完全不用的直接忘掉。
> AI也应该这样——有用的变成自己的知识，没用的就忘记。

## 三级记忆架构

```
┌─────────────────────────────────────────────────┐
│                  HOT MEMORY                      │
│         （热记忆 - 随时可调用）                    │
│                                                   │
│  容量: ≤100条                                      │
│  内容: 最常用的APP操作、快捷键、核心知识             │
│  加载: 每次对话自动加载                             │
│  示例: "QQ截图快捷键是Ctrl+Alt+A"                 │
│                                                   │
├─────────────────────────────────────────────────┤
│                  WARM MEMORY                     │
│         （温记忆 - 按需加载）                      │
│                                                   │
│  容量: 每个APP ≤200行                              │
│  内容: APP详细知识、操作流程、界面记忆               │
│  加载: 需要时从文件读取                             │
│  示例: "QQ的完整操作教程和界面布局"                │
│                                                   │
├─────────────────────────────────────────────────┤
│                  COLD MEMORY                     │
│         （冷记忆 - 归档存储）                      │
│                                                   │
│  容量: 无限制                                      │
│  内容: 过时知识、不常用APP、历史记录                 │
│  加载: 仅在用户明确查询时加载                        │
│  示例: "某个已卸载APP的操作记录"                    │
│                                                   │
└─────────────────────────────────────────────────┘
```

## 记忆生命周期

```
新知识产生
     │
     ▼
┌──────────┐
│ TENTATIVE │ ← 新学到的，暂存
│  临时记忆  │    需要验证是否真的有用
└─────┬────┘
      │ (被使用1次 → 确认)
      ▼
┌──────────┐
│   WARM   │ ← 有用，存入温记忆
│  温记忆   │    按需加载
└─────┬────┘
      │ (被使用3次以上)
      ▼
┌──────────┐
│   HOT    │ ← 高频使用，升级热记忆
│  热记忆   │    始终可用
└─────┬────┘
      │ (30天未使用)
      ▼
┌──────────┐
│   WARM   │ ← 降级回温记忆
│  降级    │
└─────┬────┘
      │ (90天未使用)
      ▼
┌──────────┐
│   COLD   │ ← 归档到冷记忆
│  归档    │
└─────┬────┘
      │ (180天未使用)
      ▼
┌──────────┐
│ EXPIRED  │ ← 可以删除
│  过期    │    （删除前通知用户）
└──────────┘
```

## 遗忘算法

```python
def calculate_decay_score(memory_entry):
    """
    计算记忆衰减分数 (0-1, 越高越容易被遗忘)
    """
    # 基础时间衰减
    days_since_last_use = (now - memory_entry.last_used).days
    days_since_created = (now - memory_entry.created).days
    
    # 时间衰减曲线（非线性的，前30天衰减慢，之后加速）
    if days_since_last_use < 7:
        time_factor = 0.0  # 一周内不会遗忘
    elif days_since_last_use < 30:
        time_factor = (days_since_last_use - 7) / 23 * 0.3  # 30天到0.3
    elif days_since_last_use < 90:
        time_factor = 0.3 + (days_since_last_use - 30) / 60 * 0.4  # 90天到0.7
    else:
        time_factor = min(0.7 + (days_since_last_use - 90) / 90 * 0.3, 1.0)
    
    # 使用频率加成（用得越多越不容易忘）
    use_count = memory_entry.use_count
    if use_count >= 10:
        frequency_factor = -0.3  # 高频使用，很难遗忘
    elif use_count >= 5:
        frequency_factor = -0.2
    elif use_count >= 3:
        frequency_factor = -0.1
    else:
        frequency_factor = 0.0
    
    # 重要性加成（核心知识不容易忘）
    if memory_entry.importance == "critical":
        importance_factor = -0.3
    elif memory_entry.importance == "useful":
        importance_factor = -0.1
    else:
        importance_factor = 0.0
    
    # 类别加成（AI相关的知识不容易忘）
    if memory_entry.category == "ai":
        category_factor = -0.2
    else:
        category_factor = 0.0
    
    decay_score = time_factor + frequency_factor + importance_factor + category_factor
    return max(0.0, min(1.0, decay_score))
```

## HOT Memory 格式

```markdown
# 热记忆

## 快捷操作
- QQ截图: Ctrl+Alt+A | 使用: 15次 | 上次: 今天
- 微信文件传输: 拖拽到聊天窗口 | 使用: 8次 | 上次: 昨天
- Chrome开发者工具: F12 | 使用: 20次 | 上次: 今天

## 常用路径
- QQ: D:\Tencent\QQ\Bin\QQ.exe
- 微信: C:\Program Files\Tencent\WeChat\WeChat.exe
- Chrome: C:\Program Files\Google\Chrome\Application\chrome.exe

## 界面记忆
- QQ登录界面: 需要扫码或密码
- Chrome地址栏: 顶部，可以按Ctrl+L快速聚焦

## 经验教训
- VS Code打开大文件会很慢，建议用其他编辑器
- QQ截图时不要截到密码框
- Windows Terminal比CMD好用得多
```

## 记忆合并

当同一个APP有多条记忆时，定期合并：

```python
def consolidate_memories(app_name):
    """
    合并同一APP的碎片化记忆
    """
    # 1. 收集所有相关记忆
    memories = search_memories(app_name)
    
    # 2. 按类型分组
    groups = {
        "basic_info": [],
        "operations": [],
        "shortcuts": [],
        "tips": [],
        "warnings": [],
    }
    
    # 3. 去重合并
    for group in groups:
        groups[group] = deduplicate(groups[group])
    
    # 4. 重写知识文件
    write_knowledge_file(app_name, groups)
    
    # 5. 清理旧记忆
    remove_old_memories(app_name)
```

## 记忆统计与报告

用户可以随时查看记忆状态：

```
📊 记忆系统报告

热记忆 (HOT): 42/100 条
  - 快捷操作: 15条
  - 常用路径: 12条
  - 界面记忆: 8条
  - 经验教训: 7条

温记忆 (WARM): 23 个APP
  - 最近活跃: QQ, Chrome, VS Code
  - 即将降级: 记事本 (28天未用)

冷记忆 (COLD): 15 个APP
  - 即将过期: 扫雷 (170天), 画图 (160天)

本周学习:
  - 新学: 2个APP (Telegram, Figma)
  - 升级热记忆: 5条
  - 降级冷记忆: 1个APP
```

## 跨电脑迁移

```
场景: AI从电脑A搬到电脑B

迁移策略:
1. 带走: 操作经验、快捷键、使用技巧（通用知识）
2. 不带走: 文件路径、界面截图、系统配置（环境相关）
3. 重新学习: APP是否存在于新电脑、路径是否变化

实现:
  导出通用知识 → 到新电脑后重新扫描 → 合并新旧知识
```
