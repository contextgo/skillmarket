"""
Auto Explorer v1.3.1 - AI自主探索电脑核心脚本
让AI像人类一样认识电脑上的所有APP

功能:
  - 环境扫描: 自动发现桌面/开始菜单/已安装APP
  - 被召唤自学: 用户叫用不会的APP时根据使用价值分级自学
  - 价值驱动: 不常用的浅尝辄止，经常用的彻底学透
  - 后台观察: 偷偷看主人用什么软件，根据真实使用频率悄悄自学
  - 记忆系统: 三级记忆(热/温/冷)，自动遗忘

用法:
  python explorer.py scan          # 扫描电脑环境
  python explorer.py learn QQ      # 学习某个APP
  python explorer.py explore       # 空闲探索（好奇心驱动）
  python explorer.py report        # 查看探索报告
  python explorer.py status        # 查看当前状态
  python explorer.py check QQ 发消息  # 自查掌握度
  python explorer.py ondemand QQ 发消息  # 价值驱动自学
  python explorer.py levelup QQ    # 提升掌握度
  python explorer.py value QQ      # 评估使用价值
  python explorer.py watch         # 后台观察使用频率
  python explorer.py observe       # 查看观察数据
  python explorer.py autolearn     # 根据观察数据自动学习
  python explorer.py bgstatus      # 查看后台学习状态

安全:
  - 不探索系统关键目录
  - 不存储敏感信息
  - 后台观察不截图不读内容
  - 所有操作有日志可查
"""

import os
import sys
import json
import shutil
import platform
import subprocess
from pathlib import Path
from datetime import datetime, timedelta
from dataclasses import dataclass, field, asdict
from typing import Optional, List, Dict


# ============================================================
# 配置
# ============================================================

BASE_DIR = os.path.expanduser("~/.auto-explorer")
PROFILE_DIR = os.path.join(BASE_DIR, "profile")
KNOWLEDGE_DIR = os.path.join(BASE_DIR, "knowledge")
MEMORY_DIR = os.path.join(BASE_DIR, "memory")
LOG_DIR = os.path.join(BASE_DIR, "exploration-log")
USAGE_LOG_FILE = os.path.join(MEMORY_DIR, "usage-log.md")
BG_STATE_FILE = os.path.join(BASE_DIR, "bg-state.json")

CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
STATE_FILE = os.path.join(BASE_DIR, "state.md")

# 最小安全路径集（不可通过配置删除）
MANDATORY_BANNED_PATHS = [
    r"C:\Windows\System32",
    r"C:\Windows\SysWOW64",
    r"C:\Windows\Fonts",
    r"C:\ProgramData",
    r"C:\Windows\Installer",
    r"C:\Windows\WinSxS",
]

# 完整默认禁止路径（用户可通过配置增减，但MANDATORY始终生效）
DEFAULT_CONFIG = {
    "auto_explore": True,
    "explore_interval_hours": 24,
    "max_search_per_app": 3,
    "memory_decay_days": 90,
    "safety_mode": "read_only",  # read_only | ask_first | full
    "banned_paths": [
        # Windows 系统关键目录
        r"C:\Windows\System32",
        r"C:\Windows\SysWOW64",
        r"C:\ProgramData",
        r"C:\Windows\Fonts",
        r"C:\Windows\Installer",
        r"C:\Windows\WinSxS",
        # 安全相关
        r"C:\Program Files\Windows Defender",
        r"C:\Program Files (x86)\Windows Defender",
        # 证书和密钥
        r"%APPDATA%\Microsoft\Protect",
        r"%APPDATA%\Microsoft\Crypto",
        r"%LOCALAPPDATA%\Microsoft\Credentials",
        # 浏览器敏感数据
        r"%LOCALAPPDATA%\Google\Chrome\User Data\Default\Login Data",
        r"%LOCALAPPDATA%\Google\Chrome\User Data\Default\Cookies",
        r"%APPDATA%\Mozilla\Firefox\Profiles",
        # 密码管理器
        r"%APPDATA%\1Password",
        r"%LOCALAPPDATA%\Bitwarden",
    ],
    "interest_keywords": [
        "AI", "LLM", "开发", "design", "效率",
        "browser", "editor", "terminal", "database",
    ],
    # ===== 后台学习配置 =====
    "background_learn": {
        "enabled": True,
        "cpu_min": 1,               # 主人忙时只用1% CPU
        "cpu_max": 30,              # 主人不在时最多30%
        "memory_max_mb": 100,       # 内存限制100MB
        "max_search_per_hour": 4,   # 每小时最多搜索4次
        "max_learn_minutes_day": 60,# 每天最多后台学60分钟
        "default_learn_window": "02:00-07:00",  # 默认深夜学习窗口
        "pause_on_game": True,      # 检测到游戏自动暂停
        "pause_on_high_cpu": True,  # 系统CPU>80%暂停
        "watch_interval_minutes": 10, # 观察间隔10分钟
    },
}

# ============================================================
# APP分类
# ============================================================

CATEGORIES = {
    "browser": {
        "keywords": ["chrome", "firefox", "edge", "safari", "opera", "brave", "浏览器",
                      "qq浏览器", "qqbrowser"],
        "icon": "🌐", "label": "浏览器",
    },
    "communication": {
        "keywords": ["qq", "wechat", "微信", "telegram", "discord", "slack", "skype",
                      "通讯", "聊天", "yy语音", "语音"],
        "icon": "💬", "label": "通讯",
    },
    "development": {
        "keywords": ["code", "vscode", "intellij", "pycharm", "idea", "vim", "neovim",
                      "git", "terminal", "cmd", "powershell", "wsl", "开发", "编程",
                      "workbuddy", "work buddy"],
        "icon": "💻", "label": "开发",
    },
    "office": {
        "keywords": ["word", "excel", "powerpoint", "wps", "office", "办公", "文档",
                      "百度网盘", "baidunetdisk"],
        "icon": "📄", "label": "办公",
    },
    "design": {
        "keywords": ["photoshop", "figma", "illustrator", "sketch", "design", "设计",
                      "premiere", "after effects", "blender"],
        "icon": "🎨", "label": "设计",
    },
    "media": {
        "keywords": ["music", "video", "player", "vlc", "spotify", "音乐", "视频", "播放"],
        "icon": "🎵", "label": "媒体",
    },
    "gaming": {
        "keywords": ["steam", "epic", "game", "游戏", "origin", "battle.net",
                      "wegame", "英雄联盟", "mumu", "模拟器"],
        "icon": "🎮", "label": "游戏",
    },
    "ai": {
        "keywords": ["ai", "llm", "ollama", "copilot", "chatgpt", "claude", "智能",
                      "midjourney", "stable diffusion", "cursor", "windsurf",
                      "ai服务器", "玲瑶", "本地模型"],
        "icon": "🤖", "label": "AI工具",
    },
    "system": {
        "keywords": ["task manager", "settings", "control panel", "registry", "系统",
                      "任务管理器", "设置", "控制面板", "hyper-v", "diskgenius",
                      "wiztree", "分区"],
        "icon": "⚙️", "label": "系统",
    },
    "tool": {
        "keywords": ["calc", "notepad", "paint", "screenshot", "recorder", "工具",
                      "snipaste", "everything", "listary", "utools", "优化",
                      "驱动", "管家"],
        "icon": "🔧", "label": "工具",
    },
    "other": {
        "keywords": [],
        "icon": "📦", "label": "其他",
    },
}

# 需要过滤掉的文件名关键词（卸载程序、辅助工具等）
FILTER_OUT_KEYWORDS = [
    "uninstall", "卸载", "uninst", "remover",
    "helper", "帮助", "readme", "license",
    "setup", "安装", "installer",
    "update", "更新", "updater",
    "crash", "report", "发送", "反馈",
    "activer", "激活", "kms",
    "config", "配置工具", "ksomisc",
    "service", "tray", "ace-",
    "inspect", "vmcreate", "vmimport",
    "extexport", "iediagcmd", "ieinstal",
    "detect", "check", "修复",
]

# ============================================================
# 数据结构
# ============================================================

@dataclass
class AppInfo:
    name: str
    path: str = ""
    category: str = "other"
    icon: str = "📦"
    version: str = ""
    description: str = ""
    mastery_level: int = 0  # 0=未知, 1=知道, 2=会基本, 3=熟练
    last_visited: str = ""
    visit_count: int = 0
    discovered_date: str = ""
    source: str = ""  # desktop/start_menu/installed/path
    learning_depth: int = 0  # 0=未评估, 1=浅尝辄止, 2=够用就行, 3=学透, 4=精通
    value_reason: str = ""  # 价值评估理由


@dataclass
class ExploreState:
    last_scan: str = ""
    last_explore: str = ""
    total_apps: int = 0
    learned_apps: int = 0
    current_target: str = ""
    explore_count: int = 0


@dataclass
class UsageRecord:
    """单次使用记录"""
    app_name: str
    timestamp: str = ""
    window_title: str = ""
    duration_minutes: float = 0


@dataclass
class BackgroundState:
    """后台学习状态"""
    is_learning: bool = False
    current_learning_app: str = ""
    today_learned_minutes: float = 0
    today_search_count: int = 0
    last_watch: str = ""
    last_autolearn: str = ""
    resource_level: str = "light"  # idle/light/busy/active
    paused_reason: str = ""  # 如果暂停了，为什么
    total_bg_learn_count: int = 0
    total_apps_bg_learned: int = 0


# ============================================================
# 核心类
# ============================================================

# 敏感内容关键词（匹配到的窗口标题会被脱敏）
SENSITIVE_TITLE_KEYWORDS = [
    "密码", "password", "passwd", "银行卡", "bank",
    "转账", "transfer", "薪资", "salary", "工资",
    "身份证", "id card", "社保", "公积金",
    "token", "secret", "api_key", "private_key",
    "登录", "login", "注册", "signup",
    "支付", "payment", "付款", "充值",
]

def _sanitize_window_title(title: str) -> str:
    """
    对窗口标题进行脱敏处理。
    如果标题包含敏感关键词，只保留APP名部分，过滤掉细节。
    如果整个标题都敏感，返回 [已脱敏]。
    """
    if not title:
        return ""
    title_lower = title.lower()
    for kw in SENSITIVE_TITLE_KEYWORDS:
        if kw in title_lower:
            # 尝试提取APP名（取第一个 " - " 或 " — " 之前的部分）
            for sep in [" - ", " — ", " – ", " | "]:
                if sep in title:
                    app_part = title.split(sep)[0].strip()
                    if app_part and len(app_part) < 30:
                        return f"{app_part} [已脱敏]"
            return "[已脱敏]"
    return title


def _sanitize_foreground_for_log(foreground: str) -> str:
    """对前台窗口标题做日志级脱敏（比 sanitize 更保守）"""
    if not foreground:
        return ""
    sanitized = _sanitize_window_title(foreground)
    # 日志中只保留APP名，去掉页面标题/文件名等细节
    for sep in [" - ", " — ", " – ", " | "]:
        if sep in sanitized and "[已脱敏]" not in sanitized:
            return sanitized.split(sep)[0].strip()
    return sanitized


class AutoExplorer:
    def __init__(self):
        self._init_dirs()
        self.config = self._load_config()
        self.state = self._load_state()
        self.apps: Dict[str, AppInfo] = {}
        self.os_type = platform.system().lower()

    # ---- 初始化 ----

    def _init_dirs(self):
        """创建所有必要目录"""
        for d in [BASE_DIR, PROFILE_DIR, KNOWLEDGE_DIR, MEMORY_DIR, LOG_DIR]:
            os.makedirs(d, exist_ok=True)

    def _load_config(self) -> dict:
        """加载配置"""
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        else:
            with open(CONFIG_FILE, "w", encoding="utf-8") as f:
                json.dump(DEFAULT_CONFIG, f, indent=2, ensure_ascii=False)
            return DEFAULT_CONFIG.copy()

    def _load_state(self) -> ExploreState:
        """加载状态"""
        state = ExploreState()
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("last_scan:"):
                        state.last_scan = line.split(":", 1)[1].strip()
                    elif line.startswith("last_explore:"):
                        state.last_explore = line.split(":", 1)[1].strip()
                    elif line.startswith("total_apps:"):
                        state.total_apps = int(line.split(":")[1].strip())
                    elif line.startswith("learned_apps:"):
                        state.learned_apps = int(line.split(":")[1].strip())
                    elif line.startswith("current_target:"):
                        state.current_target = line.split(":", 1)[1].strip()
                    elif line.startswith("explore_count:"):
                        state.explore_count = int(line.split(":")[1].strip())
        return state

    def _save_state(self):
        """保存状态"""
        with open(STATE_FILE, "w", encoding="utf-8") as f:
            f.write("# Auto Explorer State\n\n")
            f.write(f"last_scan: {self.state.last_scan}\n")
            f.write(f"last_explore: {self.state.last_explore}\n")
            f.write(f"total_apps: {self.state.total_apps}\n")
            f.write(f"learned_apps: {self.state.learned_apps}\n")
            f.write(f"current_target: {self.state.current_target}\n")
            f.write(f"explore_count: {self.state.explore_count}\n")
            f.write(f"\n_updated: {datetime.now().isoformat()}_\n")

    # ---- 扫描 ----

    def scan(self, level: int = 1) -> List[AppInfo]:
        """
        扫描电脑上的所有APP

        level:
          0 = 桌面+任务栏（闪电扫描）
          1 = +开始菜单+已安装程序
          2 = +PATH+用户目录
          3 = +注册表+系统服务
        """
        self._log(f"开始扫描 (Level {level})")
        found = []

        if self.os_type == "windows":
            found.extend(self._scan_windows(level))
        elif self.os_type == "darwin":
            found.extend(self._scan_macos(level))
        else:
            found.extend(self._scan_linux(level))

        # 去重
        seen = set()
        unique = []
        for app in found:
            key = app.name.lower()
            if key not in seen:
                seen.add(key)
                # 合并已有信息
                if app.name in self.apps:
                    old = self.apps[app.name]
                    if not app.path and old.path:
                        app.path = old.path
                    app.mastery_level = old.mastery_level
                    app.visit_count = old.visit_count
                    app.last_visited = old.last_visited
                else:
                    # 从知识文件恢复掌握度
                    app.mastery_level = self._get_saved_mastery(app.name)
                unique.append(app)

        self.apps = {a.name: a for a in unique}
        
        # 对所有APP进行分类
        for app in self.apps.values():
            self._classify_app(app)
        
        self.state.last_scan = datetime.now().isoformat()
        self.state.total_apps = len(self.apps)
        self._save_state()

        # 更新APP列表文件
        self._update_apps_file()

        self._log(f"扫描完成，发现 {len(self.apps)} 个程序")
        return unique

    def _get_saved_mastery(self, app_name: str) -> int:
        """从知识文件中恢复掌握度"""
        knowledge_path = os.path.join(KNOWLEDGE_DIR, f"{app_name}.md")
        if os.path.exists(knowledge_path):
            try:
                with open(knowledge_path, "r", encoding="utf-8") as f:
                    content = f.read()
                # 检查经验记录中的最高掌握度
                import re
                # 匹配 "掌握度提升 X→Y"
                matches = re.findall(r'掌握度提升 \d+→(\d+)', content)
                if matches:
                    return max(int(m) for m in matches)
                # 匹配 "掌握程度: ⭐⭐⭐"
                star_match = re.search(r'掌握程度: (⭐+)', content)
                if star_match:
                    return len(star_match.group(1))
            except Exception:
                pass
        return 0

    def _scan_windows(self, level: int) -> List[AppInfo]:
        """Windows环境扫描"""
        apps = []
        user_home = os.path.expanduser("~")

        # Level 0: 桌面
        desktop = os.path.join(user_home, "Desktop")
        if os.path.exists(desktop):
            apps.extend(self._scan_directory(desktop, "desktop"))

        # Level 1: 开始菜单 + 已安装
        if level >= 1:
            start_menus = [
                r"C:\ProgramData\Microsoft\Windows\Start Menu\Programs",
                os.path.join(user_home, r"AppData\Roaming\Microsoft\Windows\Start Menu\Programs"),
            ]
            for sm in start_menus:
                if os.path.exists(sm):
                    apps.extend(self._scan_directory(sm, "start_menu"))

            install_dirs = [
                r"C:\Program Files",
                r"C:\Program Files (x86)",
                os.path.join(user_home, r"AppData\Local\Programs"),
            ]
            for d in install_dirs:
                if os.path.exists(d):
                    apps.extend(self._scan_directory(d, "installed", depth=1))

        # Level 2: PATH中的程序
        if level >= 2:
            path_dirs = os.environ.get("PATH", "").split(";")
            for d in path_dirs:
                if d and os.path.exists(d):
                    apps.extend(self._scan_directory(d, "path", depth=0, exe_only=True))

        return apps

    def _scan_macos(self, level: int) -> List[AppInfo]:
        """macOS环境扫描"""
        apps = []

        # 桌面
        desktop = os.path.expanduser("~/Desktop")
        if os.path.exists(desktop):
            apps.extend(self._scan_directory(desktop, "desktop"))

        if level >= 1:
            # Applications
            for app_dir in ["/Applications", os.path.expanduser("~/Applications")]:
                if os.path.exists(app_dir):
                    apps.extend(self._scan_directory(app_dir, "installed", depth=1))

        return apps

    def _scan_linux(self, level: int) -> List[AppInfo]:
        """Linux环境扫描"""
        apps = []

        desktop = os.path.expanduser("~/Desktop")
        if os.path.exists(desktop):
            apps.extend(self._scan_directory(desktop, "desktop"))

        if level >= 1:
            for d in [
                "/usr/share/applications",
                "/usr/local/share/applications",
                os.path.expanduser("~/.local/share/applications"),
            ]:
                if os.path.exists(d):
                    apps.extend(self._scan_linux_desktop_files(d))

        return apps

    def _scan_directory(self, path: str, source: str,
                        depth: int = 2, exe_only: bool = False) -> List[AppInfo]:
        """扫描目录中的可执行文件/快捷方式"""
        apps = []
        path = os.path.normpath(path)

        # 安全检查
        if self._is_banned(path):
            return apps

        try:
            for entry in os.scandir(path):
                try:
                    if entry.is_file():
                        name_lower = entry.name.lower()

                        # 可执行文件
                        if name_lower.endswith((".exe", ".app", ".lnk")):
                            # 过滤掉卸载程序、辅助工具等
                            if any(kw in name_lower for kw in FILTER_OUT_KEYWORDS):
                                continue
                            # 过滤太短的文件名（可能是系统组件）
                            if len(entry.name) < 5:
                                continue
                            app_name = self._extract_app_name(entry.name)
                            exe_path = entry.path
                            if name_lower.endswith(".lnk"):
                                exe_path = self._resolve_lnk(entry.path)

                            if exe_path and not self._is_banned(exe_path):
                                apps.append(AppInfo(
                                    name=app_name,
                                    path=exe_path,
                                    source=source,
                                    discovered_date=datetime.now().isoformat(),
                                ))
                        elif exe_only and self._is_executable(entry.path):
                            apps.append(AppInfo(
                                name=entry.name,
                                path=entry.path,
                                source=source,
                                discovered_date=datetime.now().isoformat(),
                            ))

                    elif entry.is_dir() and depth > 0:
                        # 递归扫描子目录
                        apps.extend(self._scan_directory(
                            entry.path, source, depth=depth - 1, exe_only=exe_only
                        ))

                except (PermissionError, OSError):
                    continue

        except (PermissionError, OSError):
            pass

        return apps

    def _scan_linux_desktop_files(self, path: str) -> List[AppInfo]:
        """扫描Linux .desktop文件"""
        apps = []
        try:
            for entry in os.scandir(path):
                if entry.is_file() and entry.name.endswith(".desktop"):
                    try:
                        with open(entry.path, "r", encoding="utf-8") as f:
                            content = f.read()
                            name = self._extract_desktop_field(content, "Name")
                            exec_cmd = self._extract_desktop_field(content, "Exec")
                            if name and exec_cmd:
                                apps.append(AppInfo(
                                    name=name,
                                    path=exec_cmd.split()[0] if exec_cmd else "",
                                    source="desktop_entry",
                                    discovered_date=datetime.now().isoformat(),
                                ))
                    except (PermissionError, OSError):
                        continue
        except (PermissionError, OSError):
            pass
        return apps

    # ---- 学习 ----

    def learn(self, app_name: str) -> str:
        """
        学习一个APP
        返回学习报告，包含搜索到的信息和下一步建议

        注意: 这个脚本只负责扫描和生成知识模板
        实际的搜索和视觉操作需要AI Agent来执行
        """
        # 如果没有扫描数据，先加载
        if not self.apps:
            if self.state.total_apps > 0:
                self.scan(1)
            else:
                return "未找到APP，请先运行 scan 扫描电脑环境"

        # 查找APP
        app = self._find_app(app_name)
        if not app:
            return f"未找到APP: {app_name}\n请先运行 scan 扫描电脑环境"

        # 分类
        self._classify_app(app)

        # 生成知识模板
        knowledge_path = os.path.join(KNOWLEDGE_DIR, f"{app.name}.md")
        if not os.path.exists(knowledge_path):
            self._generate_knowledge_template(app, knowledge_path)

        # 更新状态
        app.last_visited = datetime.now().isoformat()
        app.visit_count += 1
        if app.mastery_level < 1:
            app.mastery_level = 1
        self._save_state()

        # 生成学习报告
        report = f"""# 学习报告: {app.name}

## 基本信息
- **名称:** {app.name}
- **类别:** {app.icon} {CATEGORIES[app.category]['label']}
- **路径:** {app.path or '未知'}
- **发现来源:** {app.source}
- **当前掌握程度:** {'⭐' * app.mastery_level} ({app.mastery_level}/3)

## 建议的搜索关键词
"""
        queries = [
            f"{app.name} 是什么软件",
            f"{app.name} 使用教程 入门",
            f"{app.name} 快捷键 操作技巧",
        ]
        for i, q in enumerate(queries, 1):
            report += f"{i}. {q}\n"

        report += f"""
## 下一步操作
- [ ] 搜索以上关键词，了解 {app.name}
- [ ] 将搜索到的信息写入知识文件: {knowledge_path}
- [ ] 如果有desktop-control技能，尝试打开 {app.name} 观察界面
- [ ] 记录操作经验

## 知识文件
{knowledge_path if os.path.exists(knowledge_path) else '（尚未创建）'}
"""
        self._log(f"开始学习: {app.name}")
        return report

    # ---- 探索 ----

    def explore(self) -> str:
        """
        空闲探索 - 基于好奇心选择一个APP去学习
        """
        # 确保有扫描数据
        if not self.apps:
            self.scan(1)

        # 找出未学习或了解最少的APP
        candidates = []
        for name, app in self.apps.items():
            if app.mastery_level < 3:
                curiosity = self._calculate_curiosity(app)
                candidates.append((name, app, curiosity))

        if not candidates:
            return "所有APP都已熟练掌握！进入反思模式吧。"

        # 按好奇心排序
        candidates.sort(key=lambda x: x[2], reverse=True)
        target = candidates[0]

        self.state.current_target = target[0]
        self.state.last_explore = datetime.now().isoformat()
        self.state.explore_count += 1
        self._save_state()

        self._log(f"好奇心驱动探索: {target[0]} (好奇心值: {target[2]:.0f})")

        lines = [
            "# 空闲探索",
            "",
            "## 当前状态",
            f"- 已发现 {len(self.apps)} 个APP",
            f"- 已学习 {self.state.learned_apps} 个",
            f"- 探索次数: {self.state.explore_count}",
            "",
            "## 好奇心推荐 TOP 10",
            "",
            "| 排名 | APP | 类别 | 好奇心 | 掌握 |",
            "|------|-----|------|--------|------|",
        ]

        for i, (name, app, curiosity) in enumerate(candidates[:10], 1):
            mastery = '⭐' * app.mastery_level + '☆' * (3 - app.mastery_level)
            cat = CATEGORIES.get(app.category, CATEGORIES["other"])
            lines.append(f"| {i} | {name} | {cat['icon']} | {curiosity:.0f} | {mastery} |")

        lines.append("")
        lines.append(f"## 推荐: {target[0]}")
        lines.append(f"好奇心值最高 ({target[2]:.0f}/100)")
        lines.append("")
        lines.append(f'运行 `python explorer.py learn "{target[0]}"` 开始学习')

        return "\n".join(lines)

    # ---- 被召唤自学习 ----

    def check(self, app_name: str, task: str = "") -> str:
        """
        自查: 对某个APP的某任务掌握度

        当用户叫AI做某事时，AI先自查。
        返回JSON格式的自查结果，方便AI Agent解析。
        """
        # 确保有扫描数据
        if not self.apps:
            if self.state.total_apps > 0:
                self.scan(1)
            else:
                self.scan(1)

        app = self._find_app(app_name)
        if not app:
            # 没找到APP，可能是本机未安装
            # 但检查是否有知识文件（可能之前学过）
            knowledge_file = os.path.join(KNOWLEDGE_DIR, f"{app_name}.md")
            has_knowledge = os.path.exists(knowledge_file)
            saved_mastery = self._get_saved_mastery(app_name) if has_knowledge else 0
            
            needs_learning = saved_mastery < 2
            suggested_searches = []
            if needs_learning:
                if task:
                    suggested_searches.append(f"{app_name} {task} 怎么操作")
                    suggested_searches.append(f"{app_name} {task} 教程")
                else:
                    suggested_searches.append(f"{app_name} 是什么软件")
                    suggested_searches.append(f"{app_name} 使用教程 入门")

            result = {
                "app": app_name,
                "found": False,
                "mastery": saved_mastery,
                "has_knowledge": has_knowledge,
                "has_path": False,
                "task": task,
                "action": "learn" if needs_learning else "execute",
                "message": f"本机未找到 {app_name}" + (f"，但我之前学过怎么用" if saved_mastery > 0 else ""),
                "suggested_searches": suggested_searches,
                "knowledge_file": knowledge_file if has_knowledge else None,
            }
            return json.dumps(result, ensure_ascii=False, indent=2)

        # 检查知识库
        knowledge_file = os.path.join(KNOWLEDGE_DIR, f"{app.name}.md")
        has_knowledge = os.path.exists(knowledge_file)

        # 检查是否有相关操作记录
        has_workflow = False
        if has_knowledge and task:
            try:
                with open(knowledge_file, "r", encoding="utf-8") as f:
                    content = f.read().lower()
                # 简单检查知识文件中是否提到了相关操作
                task_keywords = task.replace("怎么", "").replace("如何", "").split()
                for kw in task_keywords:
                    if kw in content:
                        has_workflow = True
                        break
            except Exception:
                pass

        # 判断是否需要学习
        needs_learning = app.mastery_level < 2 or (task and not has_workflow)

        # 价值评估（核心新逻辑！）
        value = self.evaluate_value(app.name)
        learning_depth = value["depth"]

        # 根据掌握度 × 学习深度生成搜索建议
        suggested_searches = []
        if needs_learning:
            if learning_depth == 1:
                # 浅尝辄止
                suggested_searches.append(f"{app.name} 是什么软件")
            elif learning_depth == 2:
                # 够用就行
                if task:
                    suggested_searches.append(f"{app.name} {task} 怎么操作")
                suggested_searches.append(f"{app.name} 功能介绍")
            elif learning_depth >= 3:
                # 学透/精通
                suggested_searches.append(f"{app.name} 完整使用教程")
                suggested_searches.append(f"{app.name} 新手入门 功能介绍")
                suggested_searches.append(f"{app.name} 快捷键大全")
                if task:
                    suggested_searches.append(f"{app.name} {task} 怎么操作")
            else:
                # 默认
                if task:
                    suggested_searches.append(f"{app.name} {task} 怎么操作")
                    suggested_searches.append(f"{app.name} {task} 教程")
                else:
                    suggested_searches.append(f"{app.name} 是什么软件")
                    suggested_searches.append(f"{app.name} 使用教程 入门")

        result = {
            "app": app.name,
            "found": True,
            "mastery": app.mastery_level,
            "has_knowledge": has_knowledge,
            "has_path": bool(app.path),
            "has_workflow": has_workflow,
            "task": task,
            "needs_learning": needs_learning,
            "action": "learn" if needs_learning else "execute",
            "learning_depth": learning_depth,
            "depth_name": value["depth_name"],
            "value_reason": value["reason"],
            "value_score": value["score"],
            "message": self._get_check_message(app, task, needs_learning, learning_depth),
            "suggested_searches": suggested_searches,
            "knowledge_file": knowledge_file if has_knowledge else None,
            "app_path": app.path,
        }
        return json.dumps(result, ensure_ascii=False, indent=2)

    def _get_check_message(self, app: AppInfo, task: str, needs_learning: bool, depth: int = 0) -> str:
        """生成自查后的回复消息（根据掌握程度 × 使用价值）"""
        if not needs_learning:
            if task:
                return f"我会用{app.name}的{task}操作，直接来吧"
            return f"我已经会用{app.name}了"
        
        depth_names = {0: "", 1: "浅尝辄止", 2: "够用就行", 3: "学透", 4: "精通"}
        
        if app.mastery_level == 0:
            if depth >= 3:
                return f"{app.name}我还没用过，但你经常用，我好好学一下，把整个软件都搞明白"
            elif depth == 2:
                return f"{app.name}我没用过，我先看看怎么操作"
            else:
                return f"{app.name}我先了解一下是什么"
        elif app.mastery_level == 1:
            if depth >= 3:
                return f"{app.name}我了解一些但没亲手操作过，这个你常用，我系统学一下"
            elif depth == 2:
                return f"{app.name}我了解一些，我查一下{task}怎么做" if task else f"{app.name}我了解一些，我查一下基本操作"
            else:
                return f"{app.name}我知道是什么，看看具体怎么用"
        else:
            return f"让我查一下{app.name}的{task}怎么做" if task else f"让我再熟悉一下{app.name}"

    def ondemand_learn(self, app_name: str, task: str, search_results: str = "") -> str:
        """
        被召唤自学 - 根据使用价值决定学习深度
        
        不是所有软件都学透，根据价值评估决定：
        - 不常用 → 学会基本操作就行
        - 经常用 → 彻底学会整个软件
        - 核心工具 → 精通专家级
        """
        # 确保有扫描数据
        if not self.apps:
            if self.state.total_apps > 0:
                self.scan(1)
            else:
                self.scan(1)

        app = self._find_app(app_name)
        app_name = app.name if app else app_name

        # 价值评估（关键步骤！）
        value = self.evaluate_value(app_name)
        depth = value["depth"]
        depth_name = value["depth_name"]

        # 确保知识文件存在
        knowledge_path = os.path.join(KNOWLEDGE_DIR, f"{app_name}.md")
        if not os.path.exists(knowledge_path):
            if app:
                self._generate_knowledge_template(app, knowledge_path)
            else:
                self._generate_knowledge_template(AppInfo(name=app_name), knowledge_path)

        # 根据学习深度生成不同的搜索计划
        search_plan = []
        
        if depth == 1:
            # 浅尝辄止：知道是什么就行
            search_plan.append({
                "query": f"{app_name} 是什么软件",
                "purpose": "了解这个软件的基本信息",
                "extract": ["软件用途", "开发公司", "一句话描述"],
            })
        
        elif depth == 2:
            # 够用就行：学会当前操作
            if task:
                search_plan.append({
                    "query": f"{app_name} {task} 怎么操作",
                    "purpose": "学会用户需要的具体操作",
                    "extract": ["操作步骤", "注意事项"],
                })
            search_plan.append({
                "query": f"{app_name} 功能介绍",
                "purpose": "扫一眼还有什么功能（标题级别）",
                "extract": ["功能列表"],
            })
        
        elif depth == 3:
            # 学透：彻底学会所有功能
            search_plan.append({
                "query": f"{app_name} 完整使用教程",
                "purpose": "了解这个软件的全貌和所有功能",
                "extract": ["功能列表", "界面布局", "核心概念", "基本操作"],
            })
            search_plan.append({
                "query": f"{app_name} 新手入门 功能介绍",
                "purpose": "系统了解每个功能模块",
                "extract": ["功能模块", "使用方法", "界面说明"],
            })
            search_plan.append({
                "query": f"{app_name} 快捷键大全",
                "purpose": "学习效率提升技巧",
                "extract": ["快捷键列表", "操作技巧"],
            })
            if task:
                search_plan.append({
                    "query": f"{app_name} {task} 怎么操作",
                    "purpose": "针对用户的具体需求深入了解",
                    "extract": ["操作步骤", "注意事项"],
                })
        
        else:  # depth == 4
            # 精通：学透 + 高级技巧
            search_plan.append({
                "query": f"{app_name} 完整使用教程",
                "purpose": "全面了解这个软件",
                "extract": ["功能列表", "界面布局", "核心概念"],
            })
            search_plan.append({
                "query": f"{app_name} 新手入门 功能介绍",
                "purpose": "系统了解每个功能模块",
                "extract": ["功能模块", "使用方法"],
            })
            search_plan.append({
                "query": f"{app_name} 快捷键大全",
                "purpose": "记住所有快捷键",
                "extract": ["快捷键列表"],
            })
            search_plan.append({
                "query": f"{app_name} 高级技巧 效率",
                "purpose": "学习高级使用技巧",
                "extract": ["高级功能", "效率技巧"],
            })
            search_plan.append({
                "query": f"{app_name} 隐藏功能 你不知道的",
                "purpose": "发现隐藏功能",
                "extract": ["隐藏功能", "特殊操作"],
            })
            if task:
                search_plan.append({
                    "query": f"{app_name} {task} 怎么操作",
                    "purpose": "针对用户的具体需求",
                    "extract": ["操作步骤", "注意事项"],
                })

        # 生成执行计划模板
        execution_plan = {
            "app": app_name,
            "task": task,
            "learning_depth": depth,
            "depth_name": depth_name,
            "value_reason": value["reason"],
            "app_path": app.path if app else "未找到，需要先确认安装位置",
            "steps": ["（等待AI Agent搜索后填写）"],
            "shortcuts": [],
            "notes": [],
        }

        # 记录学习意图
        self._log(f"被召唤学习: {app_name} - {task or '通用学习'} - {depth_name}(深度{depth})")

        # 生成报告
        lines = [
            f"# 被召唤自学习: {app_name}",
            "",
            f"## 任务",
            f"用户要求: {task or '了解如何使用'} {app_name}",
            f"当前掌握度: {'⭐' * (app.mastery_level if app else 0)} ({app.mastery_level if app else 0}/3)",
            "",
            f"## 价值评估",
            f"- **学习深度:** {depth_name} (深度 {depth}/4)",
            f"- **评估理由:** {value['reason']}",
            f"- **价值分数:** {value['score']}/10",
            "",
            "## AI Agent行动指南",
            "",
        ]

        if depth == 1:
            lines.append("### 浅尝辄止（知道是什么就行）")
            lines.append("这个软件不常用，不需要深入学习，了解一下基本信息即可：")
        elif depth == 2:
            lines.append("### 够用就行（学会当前操作即可）")
            lines.append("这个软件偶尔用，学会用户需要的操作就行，不用学透：")
        elif depth == 3:
            lines.append("### 学透（彻底学会整个软件）")
            lines.append("这个软件经常用，值得花时间彻底学会所有功能：")
        else:
            lines.append("### 精通（成为专家级）")
            lines.append("这是核心工具，AI和用户都离不开，要学透并掌握高级技巧：")
        
        lines.append("")

        for i, sp in enumerate(search_plan, 1):
            lines.append(f"**搜索{i}:** `{sp['query']}`")
            lines.append(f"- 目的: {sp['purpose']}")
            lines.append(f"- 提取: {', '.join(sp['extract'])}")
            lines.append("")

        # 根据深度给出不同的行动步骤
        if depth <= 1:
            lines.append("### 下一步")
            lines.append("1. 搜索上面的关键词")
            lines.append("2. 记录基本信息（是什么、有什么用）")
            lines.append("3. 完成，不需要深入操作")
            lines.append(f"4. 运行: `python explorer.py levelup {app_name}`")
        elif depth == 2:
            lines.append("### 下一步")
            lines.append("1. 搜索上面的关键词")
            lines.append(f"2. 学会{task or '基本操作'}")
            lines.append("3. 如果有desktop-control，亲自试一下")
            lines.append("4. 记录操作步骤到知识文件")
            lines.append("5. 完成，其他功能以后需要再学")
            lines.append(f"6. 运行: `python explorer.py levelup {app_name}`")
        else:
            lines.append("### 下一步")
            lines.append("1. 搜索上面的所有关键词")
            lines.append("2. 整理完整知识（所有功能都记录）")
            lines.append(f"3. 亲自打开{app_name}，对照教程试一遍每个功能")
            lines.append("4. 验证教程说的是不是真的")
            lines.append("5. 写入完整知识到知识文件")
            lines.append("6. 执行用户的任务")
            lines.append(f"7. 运行: `python explorer.py levelup {app_name}`")

        lines.append("")
        lines.append("### 学习成果")
        lines.append("```json")
        lines.append(json.dumps(execution_plan, ensure_ascii=False, indent=2))
        lines.append("```")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append(f"> 学习深度: {depth_name} (深度{depth})")
        lines.append(f"> 知识文件: {knowledge_path}")
        lines.append(f"> APP路径: {app.path if app else '未知'}")

        return "\n".join(lines)

    def levelup(self, app_name: str) -> str:
        """
        提升某个APP的掌握度

        在AI Agent完成自学后调用，记录学习成果
        """
        # 确保有扫描数据
        if not self.apps:
            if self.state.total_apps > 0:
                self.scan(1)
            else:
                self.scan(1)

        app = self._find_app(app_name)
        
        # 如果扫描中没找到，检查知识文件是否存在
        if not app:
            knowledge_path = os.path.join(KNOWLEDGE_DIR, f"{app_name}.md")
            if os.path.exists(knowledge_path):
                # 从知识文件读取当前掌握度
                old_level = self._get_saved_mastery(app_name)
                new_level = min(3, old_level + 1)
                # 直接更新知识文件
                with open(knowledge_path, "a", encoding="utf-8") as f:
                    f.write(f"\n- [{datetime.now().strftime('%Y-%m-%d')}] 掌握度提升 {old_level}→{new_level}")
                self._log(f"{app_name} 掌握度提升: {old_level} → {new_level}")
                mastery_labels = {0: "完全不会", 1: "知道是什么", 2: "会基本操作", 3: "熟练掌握"}
                new_mastery = '⭐' * new_level + '☆' * (3 - new_level)
                return f"{app_name} 掌握度提升: {old_level} → {new_level} ({new_mastery})\n当前状态: {mastery_labels[new_level]}"
            else:
                return f"未找到APP: {app_name}，也没有知识文件。请先运行 ondemand 生成学习计划"

        old_level = app.mastery_level
        app.mastery_level = min(3, app.mastery_level + 1)
        app.last_visited = datetime.now().isoformat()
        app.visit_count += 1

        # 更新知识文件
        knowledge_path = os.path.join(KNOWLEDGE_DIR, f"{app.name}.md")
        if os.path.exists(knowledge_path):
            try:
                with open(knowledge_path, "r", encoding="utf-8") as f:
                    content = f.read()
                # 更新掌握程度
                new_mastery = '⭐' * app.mastery_level + '☆' * (3 - app.mastery_level)
                content = content.replace(
                    f"掌握程度:",
                    f"掌握程度:"
                )
                # 在文件末尾追加经验
                experience = f"\n- [{datetime.now().strftime('%Y-%m-%d')}] 掌握度提升 {old_level}→{app.mastery_level}，当前{new_mastery}"
                with open(knowledge_path, "a", encoding="utf-8") as f:
                    f.write(experience)
            except Exception:
                pass

        self._save_state()
        self._log(f"{app.name} 掌握度提升: {old_level} → {app.mastery_level}")

        mastery_labels = {0: "完全不会", 1: "知道是什么", 2: "会基本操作", 3: "熟练掌握"}
        new_mastery = '⭐' * app.mastery_level + '☆' * (3 - app.mastery_level)

        return f"{app.name} 掌握度提升: {old_level} → {app.mastery_level} ({new_mastery})\n当前状态: {mastery_labels[app.mastery_level]}"

    # ---- 报告 ----

    def report(self) -> str:
        """生成探索报告"""
        if not self.apps:
            # 尝试从已有的apps.md加载
            apps_file = os.path.join(PROFILE_DIR, "apps.md")
            if os.path.exists(apps_file) and self.state.total_apps > 0:
                with open(apps_file, "r", encoding="utf-8") as f:
                    return f.read()
            return "还没有扫描过电脑，请先运行 scan"

        # 按类别分组
        grouped = {}
        for name, app in self.apps.items():
            cat = app.category
            if cat not in grouped:
                grouped[cat] = []
            grouped[cat].append(app)

        report = f"""# 探索报告

> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}
> 总APP数: {len(self.apps)}

"""

        for cat_key in ["ai", "browser", "communication", "development",
                        "office", "design", "media", "gaming", "tool",
                        "system", "other"]:
            if cat_key in grouped and grouped[cat_key]:
                cat = CATEGORIES[cat_key]
                report += f"## {cat['icon']} {cat['label']} ({len(grouped[cat_key])})\n\n"
                report += "| 名称 | 路径 | 掌握 |\n"
                report += "|------|------|------|\n"
                for app in sorted(grouped[cat_key], key=lambda a: -a.mastery_level):
                    mastery = '⭐' * app.mastery_level + '☆' * (3 - app.mastery_level)
                    path_short = (app.path or "未知")[:50]
                    report += f"| {app.name} | {path_short} | {mastery} |\n"
                report += "\n"

        return report

    # ---- 工具方法 ----

    def _is_banned(self, path: str) -> bool:
        """检查路径是否在禁止列表中（硬编码安全集 + 用户配置）"""
        path = os.path.normpath(path).lower()
        # 先检查硬编码最小安全集（不可通过配置绕过）
        for banned in MANDATORY_BANNED_PATHS:
            banned_norm = os.path.normpath(os.path.expandvars(banned)).lower()
            if path.startswith(banned_norm):
                return True
        # 再检查用户配置的禁止列表
        for banned in self.config.get("banned_paths", []):
            banned_norm = os.path.normpath(os.path.expandvars(banned)).lower()
            if path.startswith(banned_norm):
                return True
        return False

    def _check_permission(self, action: str) -> bool:
        """
        根据 safety_mode 检查操作是否被允许。
        
        safety_mode:
          - read_only: 只允许 scan/search/screenshot/read
          - ask_first: 允许 + open_app/click（但在实际操作中由AI确认）
          - full: 允许所有操作（除banned_paths外）
        """
        mode = self.config.get("safety_mode", "read_only")
        
        READ_ONLY_ACTIONS = {"scan", "search", "screenshot", "read", "watch", "observe"}
        
        if mode == "read_only":
            return action in READ_ONLY_ACTIONS
        elif mode == "ask_first":
            # 黄色区操作需要确认（由调用方处理，这里放行）
            return True
        else:  # full
            return True

    def _log_action(self, action: str, target: str, result: str):
        """记录操作审计日志"""
        safety = self.config.get("safety_mode", "read_only")
        READ_ONLY_ACTIONS = {"scan", "search", "screenshot", "read", "watch", "observe"}
        level = "green" if action in READ_ONLY_ACTIONS else "yellow"
        
        today = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(LOG_DIR, f"{today}.md")
        os.makedirs(LOG_DIR, exist_ok=True)
        
        timestamp = datetime.now().strftime("%H:%M:%S")
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"## {timestamp} - {action}\n")
            f.write(f"- 安全模式: {safety}\n")
            f.write(f"- 操作级别: {level}\n")
            f.write(f"- 目标: {target}\n")
            f.write(f"- 结果: {result}\n\n")

    def _extract_app_name(self, filename: str) -> str:
        """从文件名提取APP名称"""
        # 去掉扩展名
        for ext in [".exe", ".app", ".lnk", ".desktop"]:
            if filename.lower().endswith(ext):
                filename = filename[:-len(ext)]
        # 去掉常见后缀
        for suffix in [" Shortcut", ".lnk", " (x86)", " Launcher"]:
            filename = filename.replace(suffix, "")
        return filename.strip()

    def _resolve_lnk(self, lnk_path: str) -> str:
        """尝试解析.lnk快捷方式的目标路径"""
        try:
            import win32com.client
            shell = win32com.client.Dispatch("WScript.Shell")
            shortcut = shell.CreateShortCut(lnk_path)
            return shortcut.Targetpath
        except Exception:
            return ""

    def _is_executable(self, path: str) -> bool:
        """检查是否是可执行文件"""
        return os.path.isfile(path) and os.access(path, os.X_OK)

    def _classify_app(self, app: AppInfo):
        """根据名称分类APP"""
        name_lower = app.name.lower()
        best_match = "other"
        best_score = 0

        for cat_key, cat_info in CATEGORIES.items():
            score = 0
            for kw in cat_info["keywords"]:
                if kw.lower() in name_lower:
                    score += len(kw)  # 更长的匹配得分更高
            if score > best_score:
                best_score = score
                best_match = cat_key

        app.category = best_match
        app.icon = CATEGORIES[best_match]["icon"]

    def _extract_desktop_field(self, content: str, field: str) -> str:
        """从.desktop文件提取字段"""
        for line in content.split("\n"):
            if line.startswith(f"{field}="):
                return line.split("=", 1)[1].strip()
        return ""

    def _find_app(self, name: str) -> Optional[AppInfo]:
        """查找APP（支持模糊匹配，精确匹配优先）"""
        name_lower = name.lower()
        # 精确匹配
        for app_name, app in self.apps.items():
            if name_lower == app_name.lower():
                return app
        # 前缀匹配（"QQ" 匹配 "QQ" 而不是 "QQ浏览器"）
        for app_name, app in self.apps.items():
            if app_name.lower() == name_lower:
                return app
        # 名称包含匹配（按名称长度排序，优先短名称）
        contains = []
        for app_name, app in self.apps.items():
            if name_lower in app_name.lower() or app_name.lower() in name_lower:
                contains.append((len(app_name), app))
        if contains:
            # 优先返回名称最短的（最精确的）
            contains.sort(key=lambda x: x[0])
            return contains[0][1]
        return None

    def _calculate_curiosity(self, app: AppInfo) -> float:
        """计算好奇心值"""
        base = 30

        # 掌握度越低越好奇
        mastery_curiosity = (3 - app.mastery_level) * 20

        # 访问次数越少越好奇
        visit_curiosity = max(0, (5 - app.visit_count) * 5)

        # AI类别加成
        category_bonus = 15 if app.category == "ai" else 0

        # 兴趣关键词加成
        interest_bonus = 0
        for kw in self.config.get("interest_keywords", []):
            if kw.lower() in app.name.lower():
                interest_bonus += 5

        # 时间衰减（很久没看的更好奇）
        time_bonus = 0
        if app.last_visited:
            days = (datetime.now() - datetime.fromisoformat(app.last_visited)).days
            time_bonus = min(days, 20)
        else:
            time_bonus = 20  # 从未看过的

        return base + mastery_curiosity + visit_curiosity + category_bonus + interest_bonus + time_bonus

    def evaluate_value(self, app_name: str) -> dict:
        """
        评估一个APP的使用价值，决定学习深度
        
        核心问题: 这个软件有没有用？现在用不用得上？以后会不会用到？
        
        返回:
            depth: 1=浅尝辄止, 2=够用就行, 3=学透, 4=精通
            reason: 为什么这个深度
            signals: 判断依据
        """
        app = self._find_app(app_name)
        
        # 收集价值信号
        signals = {}
        signals["on_desktop"] = False
        signals["on_taskbar"] = False
        signals["user_mentioned"] = 0
        signals["ai_called"] = 0
        
        # 检查是否在桌面（来源是desktop）
        if app and app.source == "desktop":
            signals["on_desktop"] = True
        
        # 检查是否在常用路径（任务栏/开始菜单固定）
        if app and app.source == "start_menu":
            signals["on_start_menu"] = True
        
        # 类别价值
        category_value = {
            "communication": 3,  # 通讯软件大概率常用
            "development": 3,    # 开发工具大概率常用
            "office": 2,         # 办公工具常用
            "browser": 3,        # 浏览器核心工具
            "ai": 2,             # AI工具AI自己感兴趣
            "design": 1,
            "tool": 1,
            "media": 1,
            "gaming": 0,
            "system": 0,
            "other": 0,
        }
        
        cat = app.category if app else "other"
        cat_value = category_value.get(cat, 0)
        
        # 计算总分
        score = 0
        if signals.get("on_desktop"):
            score += 3  # 桌面有 → 经常用
        if signals.get("on_start_menu"):
            score += 1  # 开始菜单有 → 至少用过
        score += cat_value
        
        # 检查知识文件中的使用记录
        knowledge_path = os.path.join(KNOWLEDGE_DIR, f"{app_name}.md")
        if os.path.exists(knowledge_path):
            try:
                with open(knowledge_path, "r", encoding="utf-8") as f:
                    content = f.read()
                # 数经验记录条数
                experience_count = content.count("- [")
                if experience_count >= 10:
                    score += 3  # 很多经验记录 → 经常用
                elif experience_count >= 5:
                    score += 2
                elif experience_count >= 2:
                    score += 1
            except Exception:
                pass
        
        # 检查后台观察到的真实使用频率
        usage_data = self._parse_usage_log()
        if usage_data:
            app_usage_count = sum(1 for r in usage_data if r["app"].lower() == app_name.lower())
            total_records = len(usage_data)
            if app_usage_count >= 20 or (total_records > 0 and app_usage_count / total_records >= 0.3):
                score += 5  # 高频使用！必须精通
            elif app_usage_count >= 10 or (total_records > 0 and app_usage_count / total_records >= 0.15):
                score += 3  # 经常使用
            elif app_usage_count >= 3:
                score += 1  # 偶尔使用
        
        # 根据分数决定深度
        if score >= 7:
            depth = 4  # 精通
            reason = f"核心高频工具(分数{score})，彻底精通所有功能"
        elif score >= 5:
            depth = 3  # 学透
            reason = f"经常使用的软件(分数{score})，彻底学会所有功能"
        elif score >= 3:
            depth = 2  # 够用就行
            reason = f"偶尔使用的软件(分数{score})，学会基本操作即可"
        else:
            depth = 1  # 浅尝辄止
            reason = f"不常用/不确定有没有用(分数{score})，了解是什么就行"
        
        # 更新APP信息
        if app:
            app.learning_depth = depth
            app.value_reason = reason
        
        return {
            "app": app_name,
            "score": score,
            "depth": depth,
            "depth_name": {1: "浅尝辄止", 2: "够用就行", 3: "学透", 4: "精通"}[depth],
            "reason": reason,
            "signals": signals,
            "category_value": cat_value,
        }

    def _update_apps_file(self):
        """更新APP列表文件"""
        apps_file = os.path.join(PROFILE_DIR, "apps.md")
        os.makedirs(PROFILE_DIR, exist_ok=True)

        with open(apps_file, "w", encoding="utf-8") as f:
            f.write(f"# 已发现的应用程序\n\n")
            f.write(f"> 扫描时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
            f.write(f"> 共发现: {len(self.apps)} 个程序\n\n")

            # 按类别分组
            grouped = {}
            for name, app in self.apps.items():
                if app.category not in grouped:
                    grouped[app.category] = []
                grouped[app.category].append(app)

            for cat_key in ["ai", "browser", "communication", "development",
                            "office", "design", "media", "gaming", "tool",
                            "system", "other"]:
                if cat_key in grouped and grouped[cat_key]:
                    cat = CATEGORIES[cat_key]
                    f.write(f"## {cat['icon']} {cat['label']} ({len(grouped[cat_key])})\n\n")
                    f.write("| 名称 | 路径 | 掌握 |\n")
                    f.write("|------|------|------|\n")
                    for app in sorted(grouped[cat_key], key=lambda a: -a.mastery_level):
                        if app.mastery_level == 0:
                            status = "❓ 未知"
                        elif app.mastery_level == 1:
                            status = "⏳ 学习中"
                        elif app.mastery_level == 2:
                            status = "✅ 基本会"
                        else:
                            status = "🌟 熟练"
                        path_short = (app.path or "未知")[:60]
                        f.write(f"| {app.name} | {path_short} | {status} |\n")
                    f.write("\n")

    def _generate_knowledge_template(self, app: AppInfo, path: str):
        """生成APP知识模板"""
        os.makedirs(os.path.dirname(path), exist_ok=True)
        cat = CATEGORIES.get(app.category, CATEGORIES["other"])

        template = f"""# {app.name}

## 基本信息
- **全名:** {app.name}
- **类别:** {cat['icon']} {cat['label']}
- **路径:** {app.path or '未知'}
- **发现日期:** {app.discovered_date}
- **学习时间:** {datetime.now().strftime('%Y-%m-%d')}
- **掌握程度:** ⭐ (1/3)

## 一句话描述
（待填写 - 搜索后补充）

## 核心功能
（待填写 - 搜索后补充）

## 打开方式
```
方法1: {app.path if app.path else '待确认'}
方法2: （待补充）
```

## 界面布局
（待填写 - 打开APP后观察记录）

## 操作流程
### 基本操作
（待填写）

## 快捷键
（待填写）

## 注意事项
（待填写）

## 经验记录
- [{datetime.now().strftime('%Y-%m-%d')}] 初次发现，创建知识模板
"""
        with open(path, "w", encoding="utf-8") as f:
            f.write(template)

    def _log(self, message: str):
        """记录探索日志"""
        today = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(LOG_DIR, f"{today}.md")
        os.makedirs(LOG_DIR, exist_ok=True)

        timestamp = datetime.now().strftime("%H:%M:%S")
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(f"## {timestamp} - {message}\n\n")

    # ============================================================
    # 后台观察系统 (Usage Watcher)
    # ============================================================

    def _detect_user_state(self) -> str:
        """
        检测主人的使用状态（轻量级，耗时 < 10ms）
        
        返回: idle / light / busy
        """
        try:
            # 方法1: 检查CPU使用率
            try:
                import psutil
                cpu = psutil.cpu_percent(interval=0.1)
                if cpu > 80:
                    return "busy"
            except ImportError:
                # 没有psutil，用tasklist估算
                pass

            # 方法2: 检查前台窗口是否是游戏（使用脱敏前的标题判断）
            foreground = self._get_foreground_window()
            game_keywords = ["game", "steam", "wegame", "epic", "origin",
                             "英雄联盟", "league", "minecraft", "csgo",
                             "dota", "overwatch", "valorant", "gta",
                             "模拟器", "mumu", "雷电", "bluestacks"]
            if foreground:
                fg_lower = foreground.lower()
                for kw in game_keywords:
                    if kw in fg_lower:
                        return "busy"

            # 方法3: 检查空闲时间（Windows）
            try:
                import ctypes
                class LASTINPUTINFO(ctypes.Structure):
                    _fields_ = [("cbSize", ctypes.c_uint),
                                ("dwTime", ctypes.c_uint)]
                lii = LASTINPUTINFO()
                lii.cbSize = ctypes.sizeof(LASTINPUTINFO)
                ctypes.windll.user32.GetLastInputInfo(ctypes.byref(lii))
                millis = ctypes.windll.kernel32.GetTickCount() - lii.dwTime
                idle_seconds = millis / 1000
                if idle_seconds > 300:  # 5分钟没动
                    return "idle"
            except Exception:
                pass

            return "light"

        except Exception:
            return "light"

    def _get_foreground_window(self) -> str:
        """获取当前前台窗口标题（Windows，超轻量）"""
        try:
            import ctypes
            hwnd = ctypes.windll.user32.GetForegroundWindow()
            length = ctypes.windll.user32.GetWindowTextLengthW(hwnd)
            if length > 0:
                buf = ctypes.create_unicode_buffer(length + 1)
                ctypes.windll.user32.GetWindowTextW(hwnd, buf, length + 1)
                return buf.value
        except Exception:
            pass
        return ""

    def _get_running_processes(self) -> List[dict]:
        """获取当前运行的进程列表（轻量级）"""
        processes = []
        try:
            import psutil
            for proc in psutil.process_iter(["pid", "name", "cpu_percent", "memory_info"]):
                try:
                    info = proc.info
                    name = info.get("name") or ""
                    mem_info = info.get("memory_info")
                    mem_mb = round(mem_info.rss / 1024 / 1024, 1) if mem_info else 0
                    # 过滤系统进程
                    if any(kw in name.lower() for kw in
                           ["svchost", "csrss", "lsass", "services", "smss",
                            "wininit", "system", "idle", "registry"]):
                        continue
                    processes.append({
                        "name": name,
                        "pid": info.get("pid", 0),
                        "cpu": info.get("cpu_percent", 0) or 0,
                        "memory_mb": mem_mb,
                    })
                except (psutil.NoSuchProcess, psutil.AccessDenied, AttributeError):
                    continue
        except ImportError:
            # 没有psutil，根据平台选择回退方案
            try:
                if self.os_type == "windows":
                    result = subprocess.run(
                        ["tasklist", "/FO", "CSV", "/NH"],
                        capture_output=True, text=True, timeout=5
                    )
                    for line in result.stdout.strip().split("\n"):
                        parts = line.strip().strip('"').split('","')
                        if len(parts) >= 2:
                            processes.append({
                                "name": parts[0],
                                "pid": int(parts[1]) if parts[1].isdigit() else 0,
                                "cpu": 0,
                                "memory_mb": 0,
                            })
                else:
                    # macOS/Linux: 使用 ps 命令
                    result = subprocess.run(
                        ["ps", "aux", "--no-headers"],
                        capture_output=True, text=True, timeout=5
                    )
                    for line in result.stdout.strip().split("\n"):
                        parts = line.split(None, 10)
                        if len(parts) >= 11:
                            processes.append({
                                "name": os.path.basename(parts[10]).strip("()[]"),
                                "pid": int(parts[1]) if parts[1].isdigit() else 0,
                                "cpu": float(parts[2]) if parts[2].replace(".","").isdigit() else 0,
                                "memory_mb": float(parts[5]) / 1024 if parts[5].replace(".","").isdigit() else 0,
                            })
            except Exception:
                pass

        return processes

    def watch(self) -> str:
        """
        后台观察 - 记录当前正在使用的软件
        
        超轻量操作：只记录进程名和窗口标题
        不截图、不OCR、不读内容
        耗时 < 100ms，内存增量 < 1MB
        """
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M")
        
        # 获取前台窗口（对标题做脱敏处理）
        foreground = self._get_foreground_window()
        foreground_safe = _sanitize_window_title(foreground)
        
        # 获取进程列表
        processes = self._get_running_processes()
        
        # 提取APP名称（从进程名中识别已知APP）
        observed_apps = set()
        for proc in processes:
            app_name = self._process_name_to_app(proc["name"])
            if app_name and app_name not in ["系统进程", "后台服务"]:
                observed_apps.add(app_name)

        # 从前台窗口标题提取APP名（使用脱敏后的标题）
        fg_app = self._extract_app_from_title(foreground_safe) if foreground_safe else ""
        if fg_app:
            observed_apps.add(fg_app)

        # 检测主人状态
        user_state = self._detect_user_state()

        # 记录到使用日志（只记录脱敏后的信息）
        self._record_usage(timestamp, observed_apps, foreground_safe, user_state)

        # 更新后台状态
        bg_state = self._load_bg_state()
        bg_state.last_watch = datetime.now().isoformat()
        bg_state.resource_level = user_state
        self._save_bg_state(bg_state)

        self._log(f"后台观察: 检测到 {len(observed_apps)} 个活跃APP, 主人状态={user_state}")

        # 生成报告
        lines = [
            "# 后台观察报告",
            "",
            f"**时间:** {timestamp}",
            f"**主人状态:** {self._user_state_text(user_state)}",
            f"**前台窗口:** {foreground_safe or '（无）'}",
            "",
            f"## 活跃APP ({len(observed_apps)}个)",
            "",
            "| APP | 来源 |",
            "|-----|------|",
        ]

        for app in sorted(observed_apps):
            source = "前台窗口" if app == fg_app else "后台进程"
            lines.append(f"| {app} | {source} |")

        lines.append("")
        lines.append(f"## 资源限制 (当前档位: {user_state})")
        resource = self._get_resource_limit(user_state)
        lines.append(f"- CPU上限: {resource['cpu_max']}%")
        lines.append(f"- 内存上限: {resource['memory_max']}MB")
        lines.append(f"- 搜索频率: 每{resource['search_interval']}分钟")
        lines.append("")
        lines.append(f"使用数据已记录到: {USAGE_LOG_FILE}")

        return "\n".join(lines)

    def observe(self) -> str:
        """
        查看观察到的使用频率数据
        
        分析 usage-log.md 中的历史记录
        统计每个软件的使用频率
        """
        if not os.path.exists(USAGE_LOG_FILE):
            return "还没有观察数据，请先运行 watch 开始观察"

        # 读取使用日志
        usage_data = self._parse_usage_log()

        if not usage_data:
            return "使用日志中还没有有效数据"

        # 统计每个APP的使用次数
        app_counts = {}
        app_first_seen = {}
        app_last_seen = {}

        for record in usage_data:
            name = record["app"]
            app_counts[name] = app_counts.get(name, 0) + 1
            ts = record.get("timestamp", "")
            if ts:
                if name not in app_first_seen or ts < app_first_seen[name]:
                    app_first_seen[name] = ts
                if name not in app_last_seen or ts > app_last_seen[name]:
                    app_last_seen[name] = ts

        # 按使用次数排序
        sorted_apps = sorted(app_counts.items(), key=lambda x: -x[1])

        # 生成推荐
        lines = [
            "# 使用频率分析",
            "",
            f"> 分析时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"> 观察记录数: {len(usage_data)}",
            f"> 涉及APP数: {len(app_counts)}",
            "",
            "## 使用频率排行",
            "",
            "| 排名 | APP | 被观察到次数 | 学习深度建议 | 当前掌握度 |",
            "|------|-----|-------------|-------------|-----------|",
        ]

        for i, (name, count) in enumerate(sorted_apps[:20], 1):
            # 计算建议学习深度
            depth = self._usage_to_depth(count, len(app_counts))
            depth_name = {1: "浅尝辄止", 2: "够用就行", 3: "学透", 4: "精通"}.get(depth, "未评估")
            depth_emoji = {1: "🟢", 2: "🟡", 3: "🟠", 4: "🔴"}.get(depth, "⚪")

            # 查找当前掌握度
            app = self._find_app(name)
            mastery = app.mastery_level if app else self._get_saved_mastery(name)
            mastery_text = f"{'⭐' * mastery}{'☆' * (3 - mastery)}"

            # 判断是否已学够
            needs_learn = depth > mastery
            action = "需要学" if needs_learn else "已掌握"

            lines.append(
                f"| {i} | {name} | {count}次 | {depth_emoji} {depth_name} | {mastery_text} | {action} |"
            )

        # 找出"高频使用但还没学会"的APP
        needs_learning = []
        for name, count in sorted_apps:
            depth = self._usage_to_depth(count, len(app_counts))
            app = self._find_app(name)
            mastery = app.mastery_level if app else self._get_saved_mastery(name)
            if depth > mastery:
                needs_learning.append((name, count, depth, mastery))

        lines.append("")
        if needs_learning:
            lines.append("## 推荐学习（高频使用但还没学会）")
            lines.append("")
            for name, count, depth, mastery in needs_learning[:10]:
                depth_name = {1: "浅尝辄止", 2: "够用就行", 3: "学透", 4: "精通"}.get(depth)
                lines.append(f"- **{name}**: 被观察到{count}次，建议{depth_name}（当前掌握{mastery}）")
            lines.append("")
            lines.append("运行 `python explorer.py autolearn` 开始自动学习")
        else:
            lines.append("## 所有高频APP都已学会！")
            lines.append("继续观察，等待新的使用模式变化。")

        return "\n".join(lines)

    def autolearn(self) -> str:
        """
        根据观察数据自动学习
        
        流程：
        1. 检查资源是否允许
        2. 找出高频使用但还没学会的APP
        3. 按优先级排序
        4. 为最高优先级的APP生成学习计划
        """
        bg_config = self.config.get("background_learn", {})
        if not bg_config.get("enabled", True):
            return "后台学习已禁用。在 config.json 中设置 background_learn.enabled = true 启用。"

        # 检查主人状态
        user_state = self._detect_user_state()
        resource = self._get_resource_limit(user_state)

        if resource["search_interval"] == 0:
            bg_state = self._load_bg_state()
            bg_state.paused_reason = f"主人状态={user_state}，学习暂停"
            self._save_bg_state(bg_state)
            return f"当前主人状态={user_state}，不适合后台学习，已暂停。\n主人不在/空闲时自动恢复。"

        # 检查每日学习时间
        bg_state = self._load_bg_state()
        today_minutes = self._calc_today_learn_minutes()
        max_minutes = bg_config.get("max_learn_minutes_day", 60)
        if today_minutes >= max_minutes:
            return f"今日后台学习已达到上限 ({today_minutes:.0f}/{max_minutes}分钟)，明天继续。"

        # 加载使用数据
        if not os.path.exists(USAGE_LOG_FILE):
            return "还没有观察数据。请先运行 watch 积累使用数据。\n建议：让watch运行至少1-2天，积累足够数据后再自动学习。"

        usage_data = self._parse_usage_log()
        if not usage_data:
            return "使用日志中还没有有效数据。"

        # 统计使用频率
        app_counts = {}
        for record in usage_data:
            name = record["app"]
            app_counts[name] = app_counts.get(name, 0) + 1

        # 找出需要学习的APP
        candidates = []
        for name, count in app_counts.items():
            depth = self._usage_to_depth(count, len(app_counts))
            app = self._find_app(name)
            mastery = app.mastery_level if app else self._get_saved_mastery(name)
            if depth > mastery:
                candidates.append({
                    "name": name,
                    "count": count,
                    "target_depth": depth,
                    "current_mastery": mastery,
                    "priority": count * depth,  # 使用次数 × 目标深度 = 优先级
                })

        if not candidates:
            return "所有被观察到的APP都已学到对应深度！继续观察中..."

        candidates.sort(key=lambda x: -x["priority"])
        target = candidates[0]

        # 生成学习计划（调用现有的 ondemand_learn）
        depth_name = {1: "浅尝辄止", 2: "够用就行", 3: "学透", 4: "精通"}[target["target_depth"]]
        
        self._log(f"自动学习: {target['name']} (观察{target['count']}次, "
                  f"目标{depth_name}, 当前掌握{target['current_mastery']})")

        # 更新后台状态
        bg_state.current_learning_app = target["name"]
        bg_state.is_learning = True
        bg_state.last_autolearn = datetime.now().isoformat()
        bg_state.resource_level = user_state
        self._save_bg_state(bg_state)

        # 生成报告
        lines = [
            "# 自动学习计划",
            "",
            f"**时间:** {datetime.now().strftime('%Y-%m-%d %H:%M')}",
            f"**主人状态:** {self._user_state_text(user_state)}",
            f"**资源档位:** {user_state} (CPU上限{resource['cpu_max']}%)",
            f"**今日已学习:** {today_minutes:.0f}/{max_minutes}分钟",
            "",
            f"## 学习目标: {target['name']}",
            "",
            f"| 项目 | 值 |",
            f"|------|-----|",
            f"| 被观察到 | {target['count']}次 |",
            f"| 建议深度 | {depth_name} (深度{target['target_depth']}) |",
            f"| 当前掌握 | {'⭐' * target['current_mastery']}{'☆' * (3 - target['current_mastery'])} ({target['current_mastery']}/3) |",
            f"| 优先级 | {target['priority']} |",
            "",
            "## 待学习列表",
            "",
            "| 优先级 | APP | 观察次数 | 目标深度 | 当前掌握 |",
            "|--------|-----|---------|---------|---------|",
        ]

        for i, c in enumerate(candidates[:10], 1):
            c_depth = {1: "浅尝", 2: "够用", 3: "学透", 4: "精通"}.get(c["target_depth"])
            c_mastery = f"{'⭐' * c['current_mastery']}{'☆' * (3 - c['current_mastery'])}"
            highlight = " <-- 当前目标" if c["name"] == target["name"] else ""
            lines.append(f"| {c['priority']} | {c['name']} | {c['count']} | {c_depth} | {c_mastery} |{highlight}")

        lines.append("")
        lines.append("## 下一步")
        lines.append(f"AI Agent 应该用 `ondemand {target['name']}` 命令开始学习")
        lines.append(f"学习完成后用 `levelup {target['name']}` 更新掌握度")
        lines.append("")
        lines.append("> 提示：此学习计划会根据资源档位自动调整速度")
        lines.append("> 主人回来或CPU负载升高时会自动暂停")

        return "\n".join(lines)

    def bgstatus(self) -> str:
        """查看后台学习状态"""
        bg = self._load_bg_state()
        bg_config = self.config.get("background_learn", {})

        user_state = self._detect_user_state()
        resource = self._get_resource_limit(user_state)

        lines = [
            "# 后台学习状态",
            "",
            f"**最后观察:** {bg.last_watch or '从未'}",
            f"**最后学习:** {bg.last_autolearn or '从未'}",
            f"**当前目标:** {bg.current_learning_app or '无'}",
            f"**主人状态:** {self._user_state_text(user_state)}",
            f"**资源档位:** {user_state}",
            "",
            "## 资源使用",
            "",
            f"| 项目 | 限制 |",
            f"|------|------|",
            f"| CPU上限 | {resource['cpu_max']}% |",
            f"| 内存上限 | {resource['memory_max']}MB |",
            f"| 搜索间隔 | 每{resource['search_interval']}分钟 |",
            f"| 今日学习 | {self._calc_today_learn_minutes():.0f}/{bg_config.get('max_learn_minutes_day', 60)}分钟 |",
            f"| 今日搜索 | {bg.today_search_count}/{bg_config.get('max_search_per_hour', 4) * 24}次 |",
            "",
            "## 统计",
            "",
            f"- 后台学习总次数: {bg.total_bg_learn_count}",
            f"- 后台学会的APP数: {bg.total_apps_bg_learned}",
            f"- 后台学习已启用: {'是' if bg_config.get('enabled', True) else '否'}",
        ]

        if bg.paused_reason:
            lines.append(f"\n## 暂停原因\n{bg.paused_reason}")

        if not os.path.exists(USAGE_LOG_FILE):
            lines.append("\n> 还没有观察数据，运行 `watch` 开始观察")
        else:
            usage_data = self._parse_usage_log()
            lines.append(f"\n> 已积累 {len(usage_data)} 条观察记录")

        return "\n".join(lines)

    # ---- 后台辅助方法 ----

    def _process_name_to_app(self, process_name: str) -> str:
        """从进程名提取APP名称"""
        name = process_name.lower()

        # 已知进程名 → APP名映射
        process_map = {
            "qq.exe": "QQ",
            "wechat.exe": "微信",
            "tim.exe": "TIM",
            "chrome.exe": "Chrome",
            "msedge.exe": "Edge",
            "firefox.exe": "Firefox",
            "code.exe": "VS Code",
            "explorer.exe": "文件管理器",
            "steam.exe": "Steam",
            "wegame.exe": "WeGame",
            "spotify.exe": "Spotify",
            "notepad.exe": "记事本",
            "notepad++.exe": "Notepad++",
            "cmd.exe": "命令行",
            "windowsterminal.exe": "终端",
            "powershell.exe": "PowerShell",
            "taskmgr.exe": "任务管理器",
            "snipaste.exe": "Snipaste",
            "everything.exe": "Everything",
            "potplayer.exe": "PotPlayer",
            "baidunetdisk.exe": "百度网盘",
            "wps.exe": "WPS",
            "winword.exe": "Word",
            "excel.exe": "Excel",
        }

        # 精确匹配
        if name in process_map:
            return process_map[name]

        # 去掉.exe后缀尝试匹配
        bare = name.replace(".exe", "").replace(".app", "")
        if bare in process_map:
            return process_map[bare]

        # 过滤系统进程
        system_keywords = [
            "svchost", "csrss", "lsass", "smss", "services",
            "wininit", "system", "registry", "dllhost",
            "runtimebroker", "sihost", "taskhostw", "fontdrvhost",
            "conhost", "ctfmon", "dwm", "searchindexer",
            "securityhealth", "shellinfoshell", "startmenuexperience",
            "textinput", "windowsshell", "desktopwindowmanager",
            "spoolsv", "vmms", "vmcompute", "wmiprvse",
            "wmiregistrationservice", "memcompression", "lsaiso",
            "prevhost", "dashost", "atieclxx", "atiesrxx",
            "amdfendrsr", "amdow", "amdrsserv", "amdrssrcext",
            "crashpad_handler", "jhi_service", "ravcpl64",
            "aggregatorhost", "applicationframehost", "comppkgsrv",
            "video.ui", "searchfilterhost", "searchprotocolhost",
            "shellexperiencehost", "winlogon", "puwekro",
            "cncmd", "qmboottimeoptimizer", "qmaiservice64",
            "qmbsrv", "qqpcrtp", "qqpctray", "qqpyusercenter",
            "qqex", "minihomepagepro", "radeonsoftware",
        ]
        # 纯数字或太短的进程名，以及明显是系统服务的
        if len(bare) <= 3 and not bare.isalpha():
            return ""
        for kw in system_keywords:
            if kw in bare:
                return ""
        # 进程名全是小写且包含数字（大概率是系统服务）
        if bare == bare.lower() and any(c.isdigit() for c in bare):
            return ""

        # 返回进程名（去掉.exe）
        if len(bare) >= 3:
            return bare.capitalize()
        return ""

    def _extract_app_from_title(self, window_title: str) -> str:
        """从窗口标题提取APP名"""
        if not window_title:
            return ""

        title = window_title.lower()
        app_keywords = {
            "qq": "QQ", "微信": "微信", "wechat": "微信",
            "chrome": "Chrome", "edge": "Edge", "firefox": "Firefox",
            "visual studio code": "VS Code", "vs code": "VS Code",
            "steam": "Steam", "wegame": "WeGame",
            "notepad++": "Notepad++", "记事本": "记事本",
            "文件资源管理器": "文件管理器", "explorer": "文件管理器",
            "百度网盘": "百度网盘", "wps": "WPS",
            "word": "Word", "excel": "Excel",
            "potplayer": "PotPlayer", "spotify": "Spotify",
        }

        for kw, app_name in app_keywords.items():
            if kw in title:
                return app_name

        return ""

    def _record_usage(self, timestamp: str, apps: set,
                      foreground: str, user_state: str):
        """记录使用数据到 usage-log.md"""
        os.makedirs(os.path.dirname(USAGE_LOG_FILE), exist_ok=True)

        with open(USAGE_LOG_FILE, "a", encoding="utf-8") as f:
            f.write(f"## {timestamp}\n")
            f.write(f"- 状态: {user_state}\n")
            f.write(f"- 前台: {foreground or '无'}\n")
            f.write(f"- 活跃APP: {', '.join(sorted(apps))}\n\n")

    def _parse_usage_log(self) -> List[dict]:
        """解析使用日志"""
        records = []
        if not os.path.exists(USAGE_LOG_FILE):
            return records

        try:
            with open(USAGE_LOG_FILE, "r", encoding="utf-8") as f:
                content = f.read()

            import re
            # 匹配每个观察记录
            entries = re.findall(
                r'## ([\d\- :]+)\n- 状态: (\w+)\n- 前台: (.*?)\n- 活跃APP: (.+)\n',
                content
            )
            for ts, state, fg, apps_str in entries:
                for app in apps_str.split(", "):
                    app = app.strip()
                    if app:
                        records.append({
                            "app": app,
                            "timestamp": ts,
                            "user_state": state,
                            "foreground": fg,
                        })
        except Exception:
            pass

        return records

    def _usage_to_depth(self, count: int, total_records: int) -> int:
        """根据观察到的使用频率推荐学习深度"""
        if total_records == 0:
            return 1

        # 使用频率占比
        ratio = count / total_records

        if count >= 20 or ratio >= 0.3:
            return 4  # 精通（超过30%的时间都在用这个）
        elif count >= 10 or ratio >= 0.15:
            return 3  # 学透（15%以上）
        elif count >= 3 or ratio >= 0.05:
            return 2  # 够用就行
        else:
            return 1  # 浅尝辄止

    def _get_resource_limit(self, user_state: str) -> dict:
        """根据主人状态获取资源限制"""
        bg_config = self.config.get("background_learn", {})
        limits = {
            "idle": {
                "cpu_max": bg_config.get("cpu_max", 30),
                "memory_max": 200,
                "search_interval": 5,
            },
            "light": {
                "cpu_max": 15,
                "memory_max": 100,
                "search_interval": 15,
            },
            "busy": {
                "cpu_max": bg_config.get("cpu_min", 1),
                "memory_max": 50,
                "search_interval": 60,
            },
            "active": {
                "cpu_max": 5,
                "memory_max": 80,
                "search_interval": 0,  # 不后台搜索
            },
        }
        return limits.get(user_state, limits["light"])

    def _user_state_text(self, state: str) -> str:
        """用户状态转文字"""
        return {
            "idle": "离开/锁屏（可以认真学习）",
            "light": "轻度使用（悄悄学习）",
            "busy": "重度使用（几乎暂停）",
            "active": "正在对话（暂停学习）",
        }.get(state, state)

    def _load_bg_state(self) -> BackgroundState:
        """加载后台学习状态"""
        state = BackgroundState()
        if os.path.exists(BG_STATE_FILE):
            try:
                with open(BG_STATE_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                state.is_learning = data.get("is_learning", False)
                state.current_learning_app = data.get("current_learning_app", "")
                state.today_learned_minutes = data.get("today_learned_minutes", 0)
                state.today_search_count = data.get("today_search_count", 0)
                state.last_watch = data.get("last_watch", "")
                state.last_autolearn = data.get("last_autolearn", "")
                state.resource_level = data.get("resource_level", "light")
                state.paused_reason = data.get("paused_reason", "")
                state.total_bg_learn_count = data.get("total_bg_learn_count", 0)
                state.total_apps_bg_learned = data.get("total_apps_bg_learned", 0)
            except Exception:
                pass
        return state

    def _save_bg_state(self, state: BackgroundState):
        """保存后台学习状态"""
        data = {
            "is_learning": state.is_learning,
            "current_learning_app": state.current_learning_app,
            "today_learned_minutes": state.today_learned_minutes,
            "today_search_count": state.today_search_count,
            "last_watch": state.last_watch,
            "last_autolearn": state.last_autolearn,
            "resource_level": state.resource_level,
            "paused_reason": state.paused_reason,
            "total_bg_learn_count": state.total_bg_learn_count,
            "total_apps_bg_learned": state.total_apps_bg_learned,
            "_updated": datetime.now().isoformat(),
        }
        with open(BG_STATE_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def _calc_today_learn_minutes(self) -> float:
        """计算今日后台学习时长"""
        bg = self._load_bg_state()
        # 从日志中统计今天的学习记录
        today = datetime.now().strftime("%Y-%m-%d")
        log_file = os.path.join(LOG_DIR, f"{today}.md")
        if not os.path.exists(log_file):
            return bg.today_learned_minutes
        try:
            with open(log_file, "r", encoding="utf-8") as f:
                content = f.read()
            return content.count("自动学习") * 10  # 估算每次学习10分钟
        except Exception:
            return bg.today_learned_minutes


# ============================================================
# CLI
# ============================================================

def main():
    import sys
    import io

    # Windows控制台UTF-8输出
    if sys.platform == "win32":
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)

    explorer = AutoExplorer()
    command = sys.argv[1]

    if command == "scan":
        level = int(sys.argv[2]) if len(sys.argv) > 2 else 1
        apps = explorer.scan(level)
        print(f"扫描完成，发现 {len(apps)} 个程序")
        print(f"详细列表: {os.path.join(PROFILE_DIR, 'apps.md')}")

    elif command == "learn":
        if len(sys.argv) < 3:
            print("用法: python explorer.py learn <APP名称>")
            sys.exit(1)
        report = explorer.learn(sys.argv[2])
        print(report)

    elif command == "explore":
        report = explorer.explore()
        print(report)

    elif command == "report":
        report = explorer.report()
        print(report)

    elif command == "status":
        print(f"最后扫描: {explorer.state.last_scan or '从未'}")
        print(f"最后探索: {explorer.state.last_explore or '从未'}")
        print(f"APP总数: {explorer.state.total_apps}")
        print(f"已学习: {explorer.state.learned_apps}")
        print(f"当前目标: {explorer.state.current_target or '无'}")
        print(f"探索次数: {explorer.state.explore_count}")
        print(f"安全模式: {explorer.config.get('safety_mode', 'read_only')}")

    elif command == "check":
        if len(sys.argv) < 3:
            print("用法: python explorer.py check <APP名称> [任务]")
            print("例: python explorer.py check QQ 发消息")
            sys.exit(1)
        app_name = sys.argv[2]
        task = " ".join(sys.argv[3:]) if len(sys.argv) > 3 else ""
        result = explorer.check(app_name, task)
        print(result)

    elif command == "ondemand":
        if len(sys.argv) < 3:
            print("用法: python explorer.py ondemand <APP名称> [任务]")
            print("例: python explorer.py ondemand QQ 发消息")
            sys.exit(1)
        app_name = sys.argv[2]
        task = " ".join(sys.argv[3:]) if len(sys.argv) > 3 else ""
        report = explorer.ondemand_learn(app_name, task)
        print(report)

    elif command == "levelup":
        if len(sys.argv) < 3:
            print("用法: python explorer.py levelup <APP名称>")
            sys.exit(1)
        result = explorer.levelup(sys.argv[2])
        print(result)

    elif command == "value":
        if len(sys.argv) < 3:
            print("用法: python explorer.py value <APP名称>")
            print("例: python explorer.py value QQ")
            print("     python explorer.py value Photoshop")
            sys.exit(1)
        result = explorer.evaluate_value(sys.argv[2])
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif command == "watch":
        report = explorer.watch()
        print(report)

    elif command == "observe":
        report = explorer.observe()
        print(report)

    elif command == "autolearn":
        report = explorer.autolearn()
        print(report)

    elif command == "bgstatus":
        report = explorer.bgstatus()
        print(report)

    else:
        print(f"未知命令: {command}")
        print("可用命令: scan, learn, explore, report, status, check, ondemand, levelup, value, watch, observe, autolearn, bgstatus")


if __name__ == "__main__":
    main()
