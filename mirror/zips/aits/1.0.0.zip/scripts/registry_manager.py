"""
Registry Manager - APP知识库管理器
管理auto-explorer的知识文件，支持查询、更新、遗忘

用法:
  python registry_manager.py search QQ     # 搜索知识库
  python registry_manager.py list          # 列出所有已知APP
  python registry_manager.py update QQ     # 更新某个APP的知识
  python registry_manager.py forget QQ     # 遗忘某个APP
  python registry_manager.py decay         # 执行记忆衰减
  python registry_manager.py stats         # 记忆统计
"""

import os
import re
import json
from datetime import datetime, timedelta
from pathlib import Path

KNOWLEDGE_DIR = os.path.expanduser("~/.auto-explorer/knowledge")
MEMORY_DIR = os.path.expanduser("~/.auto-explorer/memory")
HOT_FILE = os.path.join(MEMORY_DIR, "hot.md")
WARM_DIR = os.path.join(MEMORY_DIR, "warm")
COLD_DIR = os.path.join(MEMORY_DIR, "cold")


def list_apps():
    """列出所有已录入知识的APP"""
    apps = []
    if os.path.exists(KNOWLEDGE_DIR):
        for f in os.listdir(KNOWLEDGE_DIR):
            if f.endswith(".md") and f != "_index.md":
                name = f[:-3]
                path = os.path.join(KNOWLEDGE_DIR, f)
                mtime = datetime.fromtimestamp(os.path.getmtime(path))
                size = os.path.getsize(path)
                apps.append({
                    "name": name,
                    "path": path,
                    "modified": mtime,
                    "size": size,
                })

    # 按修改时间排序
    apps.sort(key=lambda a: a["modified"], reverse=True)
    return apps


def search_knowledge(query: str) -> list:
    """在知识库中搜索"""
    query_lower = query.lower()
    results = []

    apps = list_apps()
    for app in apps:
        with open(app["path"], "r", encoding="utf-8") as f:
            content = f.read()

        # 检查匹配
        if query_lower in content.lower():
            # 提取匹配的行
            matching_lines = []
            for i, line in enumerate(content.split("\n"), 1):
                if query_lower in line.lower():
                    matching_lines.append(f"  L{i}: {line.strip()}")
                    if len(matching_lines) >= 5:
                        break

            results.append({
                "name": app["name"],
                "match_count": content.lower().count(query_lower),
                "lines": matching_lines,
            })

    results.sort(key=lambda r: r["match_count"], reverse=True)
    return results


def promote_to_hot(app_name: str, content: str, source: str = ""):
    """将知识提升到热记忆"""
    os.makedirs(MEMORY_DIR, exist_ok=True)

    entry = f"""
## {app_name}
- 来源: {source or "学习积累"}
- 更新: {datetime.now().strftime('%Y-%m-%d')}
- 内容: {content[:200]}
"""

    with open(HOT_FILE, "a", encoding="utf-8") as f:
        f.write(entry)


def demote_to_warm(app_name: str):
    """将知识从热记忆降级到温记忆"""
    if not os.path.exists(HOT_FILE):
        return

    with open(HOT_FILE, "r", encoding="utf-8") as f:
        lines = f.readlines()

    new_lines = []
    skip = False
    for line in lines:
        if f"## {app_name}" in line:
            skip = True
            continue
        if skip and line.startswith("## "):
            skip = False
        if not skip:
            new_lines.append(line)

    with open(HOT_FILE, "w", encoding="utf-8") as f:
        f.writelines(new_lines)


def demote_to_cold(app_name: str):
    """将知识从温记忆降到冷记忆"""
    os.makedirs(COLD_DIR, exist_ok=True)

    knowledge_path = os.path.join(KNOWLEDGE_DIR, f"{app_name}.md")
    if not os.path.exists(knowledge_path):
        return

    # 移动到冷记忆
    cold_path = os.path.join(COLD_DIR, f"{app_name}.md")
    import shutil
    shutil.move(knowledge_path, cold_path)


def run_decay():
    """
    执行记忆衰减
    - 30天未使用的温记忆 → 冷记忆
    - 90天未使用的冷记忆 → 标记为可删除
    """
    results = {"demoted_to_cold": [], "marked_expired": []}

    # 检查知识库
    if os.path.exists(KNOWLEDGE_DIR):
        for f in os.listdir(KNOWLEDGE_DIR):
            if not f.endswith(".md") or f == "_index.md":
                continue

            path = os.path.join(KNOWLEDGE_DIR, f)
            mtime = datetime.fromtimestamp(os.path.getmtime(path))
            days_inactive = (datetime.now() - mtime).days

            if days_inactive > 30:
                results["demoted_to_cold"].append({
                    "name": f[:-3],
                    "days_inactive": days_inactive,
                })
                # 实际降级（注释掉，只报告）
                # demote_to_cold(f[:-3])

    # 检查冷记忆
    if os.path.exists(COLD_DIR):
        for f in os.listdir(COLD_DIR):
            if not f.endswith(".md"):
                continue

            path = os.path.join(COLD_DIR, f)
            mtime = datetime.fromtimestamp(os.path.getmtime(path))
            days_inactive = (datetime.now() - mtime).days

            if days_inactive > 90:
                results["marked_expired"].append({
                    "name": f[:-3],
                    "days_inactive": days_inactive,
                })

    return results


def get_stats():
    """获取记忆系统统计"""
    stats = {
        "hot_entries": 0,
        "hot_size": 0,
        "warm_apps": 0,
        "cold_apps": 0,
        "total_knowledge_files": 0,
        "total_knowledge_size": 0,
    }

    # 热记忆
    if os.path.exists(HOT_FILE):
        content = open(HOT_FILE, "r", encoding="utf-8").read()
        stats["hot_entries"] = content.count("## ")
        stats["hot_size"] = len(content)

    # 知识库
    if os.path.exists(KNOWLEDGE_DIR):
        for f in os.listdir(KNOWLEDGE_DIR):
            if f.endswith(".md") and f != "_index.md":
                path = os.path.join(KNOWLEDGE_DIR, f)
                mtime = datetime.fromtimestamp(os.path.getmtime(path))
                days = (datetime.now() - mtime).days
                if days <= 30:
                    stats["warm_apps"] += 1
                else:
                    stats["cold_apps"] += 1  # 虽然在knowledge里但太久没用了
                stats["total_knowledge_files"] += 1
                stats["total_knowledge_size"] += os.path.getsize(path)

    # 冷记忆
    if os.path.exists(COLD_DIR):
        cold_count = len([f for f in os.listdir(COLD_DIR) if f.endswith(".md")])
        stats["cold_apps"] += cold_count

    return stats


def update_knowledge_index():
    """更新知识索引文件"""
    os.makedirs(KNOWLEDGE_DIR, exist_ok=True)
    index_path = os.path.join(KNOWLEDGE_DIR, "_index.md")

    apps = list_apps()

    with open(index_path, "w", encoding="utf-8") as f:
        f.write("# 知识库索引\n\n")
        f.write(f"> 更新时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
        f.write(f"> 共 {len(apps)} 个APP\n\n")
        f.write("| APP | 最后更新 | 大小 |\n")
        f.write("|-----|----------|------|\n")

        for app in apps:
            f.write(f"| {app['name']} | "
                    f"{app['modified'].strftime('%Y-%m-%d')} | "
                    f"{app['size']} bytes |\n")


def main():
    import sys

    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(0)

    command = sys.argv[1]

    if command == "list":
        apps = list_apps()
        if not apps:
            print("知识库为空")
        else:
            print(f"共 {len(apps)} 个APP:\n")
            for app in apps:
                print(f"  {app['name']}")
                print(f"    最后更新: {app['modified'].strftime('%Y-%m-%d')}")
                print(f"    文件大小: {app['size']} bytes")
                print()

    elif command == "search":
        if len(sys.argv) < 3:
            print("用法: python registry_manager.py search <关键词>")
            sys.exit(1)
        results = search_knowledge(sys.argv[2])
        if not results:
            print(f"未找到与 '{sys.argv[2]}' 相关的知识")
        else:
            for r in results:
                print(f"\n## {r['name']} (匹配 {r['match_count']} 处)")
                for line in r["lines"]:
                    print(line)

    elif command == "forget":
        if len(sys.argv) < 3:
            print("用法: python registry_manager.py forget <APP名称>")
            sys.exit(1)
        name = sys.argv[2]
        path = os.path.join(KNOWLEDGE_DIR, f"{name}.md")
        if os.path.exists(path):
            demote_to_warm(name)
            demote_to_cold(name)
            print(f"已将 {name} 移入冷记忆")
        else:
            print(f"未找到 {name} 的知识文件")

    elif command == "decay":
        results = run_decay()
        if results["demoted_to_cold"]:
            print("建议降级到冷记忆:")
            for r in results["demoted_to_cold"]:
                print(f"  - {r['name']} ({r['days_inactive']}天未用)")
        if results["marked_expired"]:
            print("建议删除:")
            for r in results["marked_expired"]:
                print(f"  - {r['name']} ({r['days_inactive']}天未用)")
        if not results["demoted_to_cold"] and not results["marked_expired"]:
            print("记忆系统状态良好，无需衰减")

    elif command == "stats":
        stats = get_stats()
        print("记忆系统统计\n")
        print(f"  热记忆: {stats['hot_entries']} 条 ({stats['hot_size']} bytes)")
        print(f"  温记忆: {stats['warm_apps']} 个APP")
        print(f"  冷记忆: {stats['cold_apps']} 个APP")
        print(f"  知识库总计: {stats['total_knowledge_files']} 个文件 ({stats['total_knowledge_size']} bytes)")

    elif command == "index":
        update_knowledge_index()
        print(f"索引已更新: {os.path.join(KNOWLEDGE_DIR, '_index.md')}")

    else:
        print(f"未知命令: {command}")


if __name__ == "__main__":
    main()
