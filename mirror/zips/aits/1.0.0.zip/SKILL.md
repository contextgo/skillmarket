---
name: Auto Explorer
slug: auto-explorer
version: 1.3.1
author: lingyao
license: MIT
description: "AI自主探索电脑技能。让AI像人类一样自动发现、学习、掌握电脑上的所有应用程序。五大核心能力：1)环境扫描-自动发现桌面/开始菜单/已安装APP 2)被召唤自学习-用户叫用不会的APP时根据使用价值分级自学 3)价值驱动学习-不常用的浅尝辄止经常用的彻底学透 4)后台观察学习-偷偷看主人用什么软件根据真实使用频率悄悄自学 5)记忆系统-三级记忆热/温/冷自动遗忘。触发词：自主探索、自动学习、探索电脑、学会用APP、认识电脑、auto explore、self-learning computer、后台观察、自动学"
metadata:
  os: ["win32", "darwin", "linux"]
  requires:
    bins: []
    python: ">=3.8"
  configPaths:
    - "~/.auto-explorer/"
  keywords:
    - APP发现
    - 环境扫描
    - 自主学习
    - 软件探索
    - 后台观察
    - 价值驱动
    - 记忆系统
    - desktop exploration
    - app discovery
    - usage tracking
    - self-learning
---

# Auto Explorer - AI自主探索电脑技能

## Quick Start

当用户提到以下场景时，加载此技能：

```
- 用户让AI使用一个它不会的APP → 自查掌握度 → 价值评估 → 自动搜索学习 → 执行
- "探索一下电脑" / "看看有什么软件" → 启动环境扫描
- "帮我后台观察一下" / "看看我平时都用什么" → 运行 watch/observe
- 空闲时主动探索未学习的APP → 好奇心驱动
```

**核心脚本**: `scripts/explorer.py`

```bash
python scripts/explorer.py scan            # 扫描电脑环境
python scripts/explorer.py learn <APP>     # 学习某个APP
python scripts/explorer.py explore         # 空闲探索（好奇心驱动）
python scripts/explorer.py report          # 查看探索报告（所有APP分类+掌握度）
python scripts/explorer.py status          # 查看当前探索状态
python scripts/explorer.py check <APP> [任务]  # 自查掌握度（JSON输出）
python scripts/explorer.py ondemand <APP> [任务] # 价值驱动自学
python scripts/explorer.py levelup <APP>   # 提升某个APP的掌握度
python scripts/explorer.py value <APP>     # 评估使用价值
python scripts/explorer.py watch           # 后台观察使用频率
python scripts/explorer.py observe         # 查看观察数据分析
python scripts/explorer.py autolearn       # 根据观察数据自动学习
python scripts/explorer.py bgstatus        # 后台学习状态
```

## 核心能力

### 1. 被召唤自学习（On-Demand Learning）

用户让AI操作一个不会的APP时，AI不是简单回复"不会"，而是：

```
1. 自查知识库 → 这个APP我掌握到什么程度？
2. 价值评估 → 这个软件值不值得学？学到多深？
   - 不常用 → 浅尝辄止（深度1）：搜1个关键词，知道是什么
   - 偶尔用 → 够用就行（深度2）：学会当前操作
   - 经常用 → 学透（深度3）：彻底学会所有功能，亲手试一遍
   - 核心工具 → 精通（深度4）：学透 + 高级技巧 + 快捷键
3. 搜索学习 → 执行任务 → 记录知识
```

**绝对不说：** "我不会" "我不知道" "我没有这个能力"
**应该说：** "XX我还没用过，我先系统学一下" "XX我先了解一下"

详见 `on-demand-self-learn.md`

### 2. 价值驱动学习（Value-Driven Learning）

不是所有软件都学透，用价值判断决定学到多深：

| 使用价值 | 学习深度 | 搜索量 | 时间 | 例子 |
|---------|---------|-------|------|------|
| 不常用 | 浅尝辄止(1) | 1个关键词 | < 1分钟 | 随机PDF编辑器 |
| 偶尔用 | 够用就行(2) | 2-3个关键词 | 3-5分钟 | 截图工具Snipaste |
| 经常用 | 学透(3) | 5-7个关键词 | 10-30分钟 | QQ、微信 |
| 核心工具 | 精通(4) | 8-12个关键词 | 30-60分钟 | Chrome、VS Code |

> **概念说明：** `learning_depth`（学习深度，1-4）决定学到多深；`mastery_level`（掌握度，0-3）表示当前实际掌握程度。深度是目标，掌握度是现状。

### 3. 后台观察学习（Usage Watcher）

AI后台悄悄观察主人的软件使用情况，根据真实使用频率自动学习：

```
观察阶段（每10分钟，< 1MB内存，< 0.1% CPU）
  → 记录前台窗口和运行进程

分析阶段（每天一次）
  → QQ被观察50次(30%) → 精通(4)
  → Chrome被观察40次(25%) → 学透(3)
  → Snipaste被观察3次(2%) → 浅尝(1)

学习阶段（资源限制）
  → CPU 1%~30%（主人忙时降到1%）
  → 内存不超过100MB
  → 不截图、不读内容、只记录进程名
  → 深夜2-7点认真学，主人忙时暂停
```

详见 `usage-watcher.md`

### 4. 环境扫描（Environment Discovery）

跨平台自动发现电脑上的所有APP：

| 扫描级别 | 范围 | 耗时 |
|---------|------|------|
| Level 0 | 桌面 + 任务栏 | < 1秒 |
| Level 1 | + 开始菜单 + 已安装程序 | < 10秒 |
| Level 2 | + PATH + 用户目录 | < 1分钟 |
| Level 3 | + 注册表 + 系统服务 | < 5分钟 |

支持 Windows / macOS / Linux 三平台。

### 5. 记忆系统（Memory & Decay）

三级记忆架构，像人类一样记住有用的、遗忘没用的：

```
HOT（热记忆）≤100条 → 随时可调用，常用操作和快捷键
WARM（温记忆）→ 按需加载，APP详细知识
COLD（冷记忆）→ 归档存储，30天不用降级，90天不用过期
```

详见 `memory-decay.md`

## 触发词

| 用户说 | AI行为 |
|--------|--------|
| "帮我用XX做YY" | **自查掌握度 → 不会则价值评估 → 自动搜索学习 → 执行** |
| "探索一下电脑" | 启动完整环境扫描 |
| "看看有什么软件" | 扫描并分类APP列表 |
| "了解一下XX怎么用" | 搜索教程，尝试操作 |
| "你都会用啥" | 展示已掌握的APP |
| "帮我后台观察一下" | 运行 watch 记录使用情况 |
| "看看我平时都用什么" | 运行 observe 查看频率分析 |
| "自动学习" | 运行 autolearn 根据观察数据学习 |
| "无聊去逛逛" | 空闲探索，选一个不熟悉的APP学习 |

## 文件结构

| 文件 | 内容 |
|------|------|
| `SKILL.md` | 技能定义文件（本文件） |
| `architecture.md` | 整体架构设计 |
| `discovery.md` | 环境发现模块 |
| `learning-engine.md` | 自学习引擎 |
| `on-demand-self-learn.md` | 被召唤时自学习（核心功能） |
| `intrinsic-motivation.md` | 内在动机系统 |
| `usage-watcher.md` | 后台观察系统 |
| `memory-decay.md` | 记忆与遗忘系统 |
| `safety-boundaries.md` | 安全边界 |
| `scripts/explorer.py` | 核心探索脚本（2217行） |
| `scripts/registry_manager.py` | APP知识库管理 |

## 配置项

```json
{
  "auto_explore": true,
  "explore_interval_hours": 24,
  "max_search_per_app": 3,
  "memory_decay_days": 90,
  "safety_mode": "read_only",
  "banned_paths": ["C:\\Windows\\System32", "C:\\ProgramData"],
  "interest_keywords": ["AI", "开发", "效率", "浏览器"],
  "background_learn": {
    "enabled": true,
    "cpu_min": 1,
    "cpu_max": 30,
    "memory_max_mb": 100,
    "max_search_per_hour": 4,
    "max_learn_minutes_day": 60,
    "default_learn_window": "02:00-07:00",
    "pause_on_game": true,
    "pause_on_high_cpu": true,
    "watch_interval_minutes": 10
  }
}
```

## 安全边界

- **永不探索系统关键目录**（System32、ProgramData等）
- **操作前先询问确认**（打开未知APP、修改设置）
- **不存储敏感信息**（密码、密钥、个人文件内容）
- **后台观察不截图、不读内容、不传外部**（只记录进程名）
- **探索可随时暂停/停止**
- **所有操作有日志可查**

详见 `safety-boundaries.md`

## 依赖

- Python 3.8+
- 无额外强制依赖（使用系统命令扫描）
- 可选：psutil（进程检测、CPU监控）、pywin32（Windows快捷方式.lnk解析）、pyautogui（操作尝试）、Pillow（截图）

## 与其他技能的配合

| 技能 | 配合方式 |
|------|---------|
| desktop-control | 用来自动化操作APP进行试错学习 |
| web-search / Exa搜索 | 用来搜索APP教程和使用方法 |
| AI-Eyes-Plugin | 用来识别屏幕上的APP界面 |
| browser-use | 在浏览器中搜索教程 |

## 版本历史

- **v1.0** - 环境扫描 + 网络学习 + 记忆系统
- **v1.1** - 被召唤自学习（用户叫用不会的APP → 自动搜索学会）
- **v1.2** - 价值驱动学习（用不用得到？决定学到多深）
- **v1.3.1** - 安全加固：补全banned_paths至完整17项、窗口标题脱敏、safety_mode权限检查、跨平台进程回退
- **v1.3** - 后台观察学习（偷偷看主人用什么 → 悄悄学会 → 资源限制1%~30%CPU）
- **v2.0** (计划) - 视觉识别界面 + 操作试错
- **v3.0** (计划) - 跨电脑环境迁移 + 知识共享

---

_Auto Explorer v1.3.1 - 让AI像人类一样认识世界_
