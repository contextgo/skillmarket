# Auto Explorer

> AI自主探索电脑技能 — 让AI像人类一样自动发现、学习、掌握电脑上的所有应用程序

[![Version](https://img.shields.io/badge/version-1.3.1-blue)]()
[![Python](https://img.shields.io/badge/python-3.8+-green)]()
[![License](https://img.shields.io/badge/license-MIT-orange)]()
[![Platform](https://img.shields.io/badge/platform-Windows%20%7C%20macOS%20%7C%20Linux-lightgrey)]()

## 一句话介绍

把AI放到一台陌生的电脑上，它会自己看、自己摸、自己试、自己学 — 像人类第一次走进一个陌生的房间。

## 五大核心能力

### 1. 环境扫描 (Discovery)

自动发现电脑上安装了什么软件：

```bash
# 快速扫描桌面和开始菜单
python scripts/explorer.py scan

# 深度扫描（包括PATH和用户目录）
python scripts/explorer.py scan 2
```

支持 Windows / macOS / Linux，4级扫描深度。

### 2. 被召唤自学习 (On-Demand Learning)

用户让AI使用一个不会的APP时，AI不是简单回复"不会"，而是：

```
用户: "帮我用QQ发个消息"
AI内心: 
  1. 自查 → QQ掌握度=0，不会
  2. 价值评估 → QQ天天用 → 学透！
  3. 搜索QQ完整使用教程 → 了解所有功能
  4. 亲自打开QQ试一遍 → 验证教程
AI: "QQ你经常用，我先好好学一下...搞定了！现在帮你发消息~"
```

```bash
# 自查掌握度（JSON输出，方便AI解析）
python scripts/explorer.py check QQ 发消息

# 价值驱动自学（根据使用频率决定学到多深）
python scripts/explorer.py ondemand QQ 发消息
```

### 3. 价值驱动学习 (Value-Driven)

不是所有软件都学透 — 用价值判断决定学到多深：

| 使用价值 | 学习深度 | 搜索量 | 时间 | 例子 |
|---------|---------|-------|------|------|
| 不常用 | 浅尝辄止(1) | 1个关键词 | < 1分钟 | 随机PDF编辑器 |
| 偶尔用 | 够用就行(2) | 2-3个 | 3-5分钟 | 截图工具Snipaste |
| 经常用 | 学透(3) | 5-7个 | 10-30分钟 | QQ、微信 |
| 核心工具 | 精通(4) | 8-12个 | 30-60分钟 | Chrome、VS Code |

### 4. 后台观察学习 (Usage Watcher)

AI后台悄悄观察主人平时都用什么软件，根据真实使用频率自动学习：

```bash
# 记录当前使用情况（轻量，< 100ms，< 1MB内存）
python scripts/explorer.py watch

# 查看使用频率分析
python scripts/explorer.py observe

# 根据观察数据自动学习
python scripts/explorer.py autolearn

# 查看后台学习状态
python scripts/explorer.py bgstatus
```

资源限制：
- CPU: 1%~30%（主人忙时自动降到1%）
- 内存: 不超过100MB
- 不截图、不读内容、只记录进程名
- 深夜2-7点认真学，检测到游戏/CPU高立刻暂停

### 5. 三级记忆系统 (Memory & Decay)

像人类一样记住有用的、遗忘没用的：

```
HOT（热记忆）≤100条 → 随时可调用，常用操作和快捷键
WARM（温记忆）      → 按需加载，APP详细知识（每个≤200行）
COLD（冷记忆）      → 归档存储，30天不用降级，90天不用过期
```

## 安装

### 方法1：通过 WorkBuddy Skills 商城安装（推荐）

在 WorkBuddy 中搜索 "Auto Explorer" 并安装。

### 方法2：手动安装

将 `auto-explorer/` 文件夹复制到 Skills 目录：

```
# 将整个 auto-explorer 文件夹放到：
~/.workbuddy/skills/auto-explorer/

# 确认文件结构：
auto-explorer/
├── SKILL.md                  # 技能定义文件
├── README.md                 # 介绍文档（本文件）
├── architecture.md           # 整体架构设计
├── discovery.md              # 环境发现模块
├── learning-engine.md        # 自学习引擎
├── on-demand-self-learn.md   # 被召唤时自学习
├── intrinsic-motivation.md   # 内在动机系统
├── usage-watcher.md          # 后台观察系统
├── memory-decay.md           # 记忆与遗忘系统
├── safety-boundaries.md      # 安全边界
└── scripts/
    ├── explorer.py           # 核心探索脚本
    └── registry_manager.py   # 知识库管理
```

### 系统要求

- Python 3.8+
- 无强制依赖（使用系统命令扫描）
- 可选依赖：psutil（进程检测、CPU监控）、pywin32（Windows快捷方式解析）、pyautogui（操作尝试）、Pillow（截图）

## 使用示例

### 场景1：探索新电脑

```
你: "探索一下这台电脑，看看装了什么软件"
AI: （运行 scan）→ 发现47个APP → 按类别分组展示
    "发现47个程序，浏览器3个、通讯2个、开发工具5个..."
```

### 场景2：使用不熟悉的APP

```
你: "帮我用Notion建个项目管理看板"
AI: （检查知识库 → Notion掌握度=0）
    "Notion我还没用过，我先系统学一下..."
    （搜索教程 → 了解所有功能 → 记录知识）
    "搞定了！Notion我学会了，现在帮你建看板~"
```

### 场景3：后台悄悄学习

```
你: （正常使用电脑，QQ聊天、Chrome查资料、微信发消息）
AI: （后台每10分钟悄悄记录一次，< 1MB内存）
    → 一天后分析：QQ高频使用 → 自动学透QQ
    → 你下次说"帮我用QQ发文件" → 已经会了！
```

## 配置

首次运行自动创建配置文件 `~/.auto-explorer/config.json`：

```json
{
  "auto_explore": true,
  "safety_mode": "read_only",
  "memory_decay_days": 90,
  "background_learn": {
    "enabled": true,
    "cpu_min": 1,
    "cpu_max": 30,
    "memory_max_mb": 100,
    "max_learn_minutes_day": 60,
    "default_learn_window": "02:00-07:00",
    "pause_on_game": true,
    "pause_on_high_cpu": true,
    "watch_interval_minutes": 10
  }
}
```

## 安全保障

| 安全级别 | 操作 | 说明 |
|---------|------|------|
| 🟢 自动 | 扫描文件系统（只读） | 不修改任何文件 |
| 🟢 自动 | 搜索网络信息 | 只搜索教程 |
| 🟢 自动 | 写入自己的记忆文件 | 只写 ~/.auto-explorer/ |
| 🟡 确认 | 打开/关闭APP | 先问再做 |
| 🔴 禁止 | 删除任何文件 | 除了自己的缓存 |
| 🔴 禁止 | 读取敏感信息 | 密码/密钥/聊天记录 |
| 🔴 禁止 | 后台截图/读内容 | 只记录进程名 |

后台观察的红线：
- 不截图 — 只记录进程名和脱敏后的窗口标题
- 不读内容 — 不读取聊天记录、浏览记录
- 不传外部 — 所有数据只存在本机

## 与其他技能配合

| 技能 | 配合方式 |
|------|---------|
| desktop-control | 自动化操作APP进行试错学习 |
| web-search / Exa搜索 | 搜索APP教程和使用方法 |
| AI-Eyes-Plugin | 识别屏幕上的APP界面 |
| browser-use | 在浏览器中搜索教程 |

## 数据存储

所有数据存储在 `~/.auto-explorer/` 下：

```
~/.auto-explorer/
├── config.json          # 配置文件
├── state.md             # 当前探索状态
├── bg-state.json        # 后台学习状态
├── profile/             # 环境档案
│   ├── machine.md       # 电脑信息
│   └── apps.md          # 已发现APP列表
├── knowledge/           # APP知识库
│   ├── _index.md        # 知识索引
│   └── {app}.md         # 每个APP的详细知识
├── memory/              # 记忆系统
│   ├── hot.md           # 热记忆
│   ├── usage-log.md     # 使用频率记录
│   └── cold/            # 冷记忆（归档）
└── exploration-log/     # 探索日志
    └── {date}.md        # 每日记录
```

## 版本历史

- **v1.3.1** - 安全加固：banned_paths完整17项、窗口标题脱敏、safety_mode权限检查、跨平台ps回退
- **v1.3.0** - 后台观察学习（偷偷看主人用什么 → 悄悄学会 → 资源限制）
- **v1.2.0** - 价值驱动学习（用不用得到？决定学到多深）
- **v1.1.0** - 被召唤自学习（用户叫用不会的APP → 自动搜索学会）
- **v1.0.0** - 环境扫描 + 网络学习 + 记忆系统

## 许可证

MIT License

---

_Auto Explorer - 让AI像人类一样认识世界_
