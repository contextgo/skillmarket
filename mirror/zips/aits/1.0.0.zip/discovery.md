# Discovery Module - 环境发现模块

## 目标

自动发现当前电脑上的所有可执行程序、快捷方式、浏览器书签和常用工具，建立完整的环境档案。

## 扫描策略

### Level 0：闪电扫描（< 1秒）

只扫最表面的东西，快速建立认知。

```python
# Windows
targets = [
    ("桌面", os.path.expanduser("~/Desktop")),
    ("任务栏", "C:/Users/{user}/AppData/Roaming/Microsoft/Internet Explorer/Quick Launch/User Pinned/TaskBar"),
]

# macOS
targets = [
    ("桌面", "~/Desktop"),
    ("Dock", "/Applications"),  # Dock里的通常是Applications的符号链接
]

# Linux
targets = [
    ("桌面", "~/Desktop"),
    ("面板", "/usr/share/applications"),
]
```

**识别方式：**
- `.lnk` → Windows快捷方式 → 用 `win32com` 解析目标路径
- `.app` → macOS应用包 → 读取 `Info.plist`
- `.desktop` → Linux桌面文件 → 读取 `Exec=` 字段

### Level 1：标准扫描（< 10秒）

加上开始菜单和已安装程序。

```python
# Windows
scan_paths = [
    # 开始菜单
    "C:/ProgramData/Microsoft/Windows/Start Menu/Programs",
    os.path.expanduser("~/AppData/Roaming/Microsoft/Windows/Start Menu/Programs"),
    # 已安装程序
    "C:/Program Files",
    "C:/Program Files (x86)",
    # 用户安装
    os.path.expanduser("~/AppData/Local/Programs"),
]

# macOS
scan_paths = [
    "/Applications",
    "~/Applications",
]

# Linux
scan_paths = [
    "/usr/share/applications",
    "/usr/local/share/applications",
    "~/.local/share/applications",
    "/snap/bin",
]
```

### Level 2：深度扫描（< 1分钟）

包括开发工具、环境变量、PATH中的程序。

```python
scan_paths += [
    # 环境变量 PATH 中的所有可执行文件
    *os.environ.get("PATH", "").split(os.pathsep),
    # 开发工具常见路径
    # Python, Node, Go, Rust, Java 等的安装目录
]
```

### Level 3：全面扫描（< 5分钟）

系统级扫描，包括注册表、系统服务等。

```python
# Windows: 注册表
# HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall
# HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall

# macOS: Spotlight索引
# mdfind "kMDItemKind == 'Application'"

# Linux: dpkg + snap + flatpak
# dpkg -l | grep ^ii
# snap list
# flatpak list
```

## APP识别流程

对每个发现的文件/快捷方式：

```
Step 1: 文件名分析
  - 去掉扩展名(.lnk, .app, .desktop, .exe)
  - 提取品牌名（"Google Chrome" → 品牌="Google", 名="Chrome"）
  - 初步猜测类别

Step 2: 本地信息提取
  - 文件图标（如果可以读取）
  - 文件版本信息（Windows: VERSIONINFO）
  - 安装日期/修改时间
  - 文件大小

Step 3: 网络验证（可选，对未知APP）
  - 搜索 "APP名称 是什么软件"
  - 获取官网信息
  - 确认软件类别和用途

Step 4: 分类与记录
  - 写入 knowledge/{app_name}.md
  - 更新 knowledge/_index.md
```

## 分类体系

```python
CATEGORIES = {
    "browser": {
        "keywords": ["browser", "浏览器", "chrome", "firefox", "edge", "safari", "opera"],
        "icon": "🌐",
    },
    "communication": {
        "keywords": ["chat", "通讯", "qq", "wechat", "微信", "telegram", "discord", "slack"],
        "icon": "💬",
    },
    "development": {
        "keywords": ["ide", "editor", "开发", "code", "vscode", "intellij", "git", "terminal"],
        "icon": "💻",
    },
    "office": {
        "keywords": ["office", "办公", "word", "excel", "powerpoint", "wps", "docs"],
        "icon": "📄",
    },
    "design": {
        "keywords": ["design", "设计", "photoshop", "figma", "illustrator", "sketch"],
        "icon": "🎨",
    },
    "media": {
        "keywords": ["music", "video", "音乐", "视频", "player", "vlc", "spotify"],
        "icon": "🎵",
    },
    "gaming": {
        "keywords": ["game", "游戏", "steam", "epic", "origin"],
        "icon": "🎮",
    },
    "system": {
        "keywords": ["system", "系统", "task", "manager", "settings", "设置"],
        "icon": "⚙️",
    },
    "tool": {
        "keywords": ["tool", "工具", "calc", "notepad", "截图", "录屏"],
        "icon": "🔧",
    },
    "ai": {
        "keywords": ["ai", "llm", "ollama", "copilot", "chatgpt", "智能"],
        "icon": "🤖",
    },
    "other": {
        "keywords": [],
        "icon": "📦",
    },
}
```

## 输出格式

扫描完成后生成 `profile/apps.md`：

```markdown
# 已发现的应用程序

> 扫描时间: 2026-04-22 03:22
> 扫描级别: Level 1
> 共发现: 47 个程序

## 🌐 浏览器 (3)
| 名称 | 路径 | 版本 | 状态 |
|------|------|------|------|
| Google Chrome | C:\Program Files\Google\Chrome\chrome.exe | 124.0 | ✅ 已学习 |
| Microsoft Edge | C:\Program Files (x86)\Microsoft\Edge\msedge.exe | 124.0 | ⏳ 未学习 |
| Firefox | C:\Program Files\Mozilla Firefox\firefox.exe | 125.0 | ❓ 未知 |

## 💬 通讯 (2)
| 名称 | 路径 | 版本 | 状态 |
|------|------|------|------|
| QQ | D:\Tencent\QQ\Bin\QQ.exe | 9.9.12 | ✅ 已学习 |
| 微信 | C:\Program Files\Tencent\WeChat\WeChat.exe | 3.9.11 | ⏳ 未学习 |

...
```

## 增量更新

不是每次都全量扫描，而是：
1. 首次：全量扫描
2. 后续：检查文件修改时间，只扫描变化的
3. 用户安装新APP后：下次扫描自动发现
4. 用户手动触发：随时可以重新扫描

## 浏览器书签扫描

除了本地APP，还扫描浏览器书签作为"线上工具"的发现：

```python
# Chrome 书签
chrome_bookmarks = os.path.expanduser(
    "~/AppData/Local/Google/Chrome/User Data/Default/Bookmarks"
)
# 解析 JSON，提取常用网站

# Edge 书签
edge_bookmarks = os.path.expanduser(
    "~/AppData/Local/Microsoft/Edge/User Data/Default/Bookmarks"
)
```

书签也纳入知识库，分类为"在线工具"。
