---
name: opensource-code-scan
description: 开源代码合规扫描与深度解读工具。对工蜂 Git 仓库触发 CodeCC 扫描，提供代码规范、安全漏洞、圈复杂度、重复率和 SCA 组件分析。Use when users mention '代码扫描', 'CodeCC', '代码检测', '安全漏洞', '合规检测', 'code scan', 'vulnerability scan', or 'opensource compliance check'.
---

# Opensource Code Scan

对工蜂 Git 仓库进行 CodeCC 代码扫描，提供代码规范、安全漏洞、圈复杂度、重复率及 SCA 组件分析的深度解读。

## 环境配置

- 若从 Agent 上下文中收到 base_url，直接使用
- 若为独立模式（无上下文），调用 `get_/api/getEnvironment` 获取环境标识并映射域名：
  - env = "dev" → {{BASE_URL}} = opensourcedev.woa.com
  - env = "prod" → {{BASE_URL}} = opensource.woa.com
  - 调用失败 → 默认 {{BASE_URL}} = opensource.woa.com
- OAuth 授权 URL 中的 redirect_uri 域名也需要使用 {{BASE_URL}}

## MCP 服务依赖

**本 Skill 依赖 `tosr-swagger-apis` MCP 服务。** 所有 API 调用均通过该 MCP 服务执行。

工具名格式为 `post_/api/{endpoint}`，完整列表：

| MCP 工具名 | 用途 |
|-----------|------|
| `post_/api/applicationProjectsCreate` | 静默创建临时申请单（获取 application_id） |
| `post_/api/applicationProjectsGet` | 验证 OAuth 授权状态（检查 gongfeng_url） |
| `post_/api/triggerCodeccScan` | 触发 CodeCC 扫描 |
| `post_/api/getCodeccScanStatus` | 查询扫描状态 |
| `post_/api/getCodeccDefectDimensions` | 获取缺陷维度统计（STANDARD/SECURITY/CCN/DUPC） |
| `post_/api/getCodeccSoftwareComponents` | 获取 SCA 组件分析 |

> 如果 MCP 服务未连接，提示用户：「本功能需要连接 tosr-swagger-apis MCP 服务，请确认 MCP 配置后重试。」

## Critical Rules

**OAuth 授权链接必须裸露输出。** 不加任何 Markdown 格式符号（`**`、`[]`、`()`），否则链接不可点击。URL 单独一行。

**`getCodeccScanStatus` 的 `id` 参数始终是申请单 ID。** 不是 `task_id`，不是 `scan_record_id`。

**`task_id` 存在类型差异。** `getCodeccScanStatus` 返回 string 类型的 `task_id`，传入 `getCodeccDefectDimensions` / `getCodeccSoftwareComponents` 时需转为 number。

**`type` 参数 vs `is_github` 参数。** `getCodeccScanStatus` 用 `"type": "gongfeng"`（string），`getCodeccDefectDimensions` / `getCodeccSoftwareComponents` 用 `"is_github": false`（boolean）。

**不向用户暴露"申请单"概念。** 独立模式下内部静默创建临时申请单获取 `application_id`，对用户透明。使用"初始化扫描环境"等措辞。

**集成模式下 `apply_id` 即 `application_id`。** 当对话上下文包含 `apply_id` 时，直接使用该 ID 作为后续所有 API 调用的 `application_id`，不再创建临时申请单。

## Workflow Decision Tree

```
Skill 被触发
    │
    ├─ 对话上下文包含 apply_id（集成模式）
    │    │
    │    ├─ Step 0A: 集成模式检测
    │    │    ├─ 调用 applicationProjectsGet 验证项目
    │    │    │    └─ 项目不存在 → 报错终止
    │    │    │
    │    │    ├─ 检查 gongfeng_url 字段
    │    │    │    ├─ 非空 → ✅ 已授权，跳过 Step 1 + Step 2
    │    │    │    └─ 为空 → 跳过 Step 1，进入 Step 2 授权
    │    │    │
    │    │    └─ 检查扫描状态（仅已授权时）
    │    │         ├─ 无记录 → 进入 Step 3 触发扫描
    │    │         ├─ scanning → 进入 Step 4 等待
    │    │         ├─ completed → 询问「查看结果 / 重新扫描」
    │    │         └─ failed → 询问「重新扫描？」
    │    │
    │    └─ 进入对应 Step 继续执行
    │
    └─ 未提供 apply_id（独立模式，行为不变）
         │
         ├─ 提供了工蜂仓库 URL → Step 0 验证 URL
         └─ 未提供 URL → 询问工蜂仓库地址
              │
         Step 0 → Step 1 → Step 2 → Step 3 → Step 4 → Step 5
```

## Step-by-Step Workflow

### Step 0A: 集成模式检测（仅当上下文包含 apply_id 时）

当对话上下文中包含结构化 JSON 且含有 `apply_id` 字段时（如 `{ "apply_id": 12345 }`），进入集成模式。此模式由其他 agent（主控、开源自测助手、材料填报助手）调用时触发。

**1. 验证项目存在：**

调用 `post_/api/applicationProjectsGet`：

```json
{
  "conditions": ["id = {apply_id}"]
}
```

- 成功 → 记录 `application_id = apply_id`，继续下一步
- 失败/不存在 → 告知「未找到对应的申请单（ID: {apply_id}），请确认 ID 是否正确」，终止

**2. 检测授权状态：**

检查返回结果中 `gongfeng_url` 字段：

- **非空** → 告知「✅ 工蜂授权已完成」，跳过 Step 1 和 Step 2，继续检测扫描状态
- **为空** → 需要授权，跳过 Step 1（不创建申请单），直接进入 Step 2（OAuth 授权）

**3. 检测扫描状态（仅在已授权时执行）：**

调用 `post_/api/getCodeccScanStatus`：

```json
{
  "id": {apply_id},
  "type": "gongfeng"
}
```

根据返回结果判断：

- **无记录**（无 `scan_record_id` 或响应为空）→ 直接进入 Step 3 触发扫描
- **扫描中**（`is_completed: false`）→ 进入 Step 4 等待，告知当前进度
- **扫描完成**（`is_completed: true`）→ 询问用户：
  > 检测到已有扫描记录（完成时间：{update_time}）。请选择：
  > 1. 查看已有扫描结果
  > 2. 重新触发扫描

  选择 1 → 从响应中提取 `task_id`，进入 Step 5 解读
  选择 2 → 进入 Step 3 重新扫描
- **扫描失败**（`message: "扫描失败"`）→ 询问「是否重新触发扫描？」
  选择是 → 进入 Step 3
  选择否 → 终止

---

### Step 0: 收集仓库信息（独立模式）

询问用户工蜂仓库地址。接受格式：

- `https://git.woa.com/org/repo`
- `https://git.woa.com/org/repo.git`

**验证规则：** URL 必须包含 `git.woa.com` 域名。如不符合，提示：

> 当前仅支持工蜂（git.woa.com）仓库扫描。请提供工蜂仓库地址。

**解析项目名称：** 从 URL 路径最后一段提取作为默认项目名（去掉 `.git` 后缀）。

### Step 1: 初始化扫描环境（独立模式）

**对用户的措辞：** 「⏳ 正在初始化扫描环境...」

调用 `post_/api/applicationProjectsCreate` 创建临时申请单。**项目名称必须在解析名后追加 `-{时间戳}`**，避免与已有申请单重名：

```json
{
  "name": "{从URL解析的项目名}-{时间戳}",
  "scene": "TOSR-1"
}
```

> 时间戳格式为 `YYYYMMDDHHmmss`，如 `my-project-20260319143500`。

记录返回的 `id` 为 `application_id`，后续所有步骤使用此 ID。

**如果创建失败：** 告知用户「扫描环境初始化失败，请稍后重试」，终止流程。

### Step 2: Git OAuth 授权

根据环境选择对应的 `client_id`：
- **dev 环境**（{{BASE_URL}} = opensourcedev.woa.com）：`client_id=9edbea706a4747c192bfd8f23405536c`
- **prod 环境**（{{BASE_URL}} = opensource.woa.com）：`client_id=6119e83a61b3441bbf3471c32a5331a5`

构造授权 URL，将 `{application_id}` 和 `{client_id}` 替换为实际值：

```
https://git.woa.com/oauth/authorize?access_type=offline&client_id={client_id}&redirect_uri=http%3A%2F%2F{{BASE_URL}}%2Fapi%2Foauth%2Fgongfeng%2Fcallback&response_type=code&scope=api+read_user+read_repository&state=appid%3A{application_id}
```

**向用户展示（注意 URL 单独一行裸露输出）：**

```
请点击以下链接完成工蜂仓库授权：

{授权URL}

授权完成后，请回复「Done」继续。
```

**用户回复 Done 后，执行零信任验证：**

调用 `post_/api/applicationProjectsGet`：

```json
{
  "conditions": ["id = {application_id}"]
}
```

检查返回结果中 `gongfeng_url` 字段：

- **非空** → 授权验证通过，告知用户「✅ 工蜂授权已确认完成」，继续下一步
- **为空** → 授权未完成，提示用户：

> 系统检测到工蜂授权尚未完成，请确认是否已在授权页面点击"允许"。
> 如已完成，系统可能需要几秒同步，请稍后再回复「Done」重试。

最多验证 3 次。3 次均失败时提示：

> 授权验证多次未通过，请检查网络或浏览器设置后重试。如问题持续，可联系管理员。

### Step 3: 触发扫描

调用 `post_/api/triggerCodeccScan`：

```json
{
  "application_id": {application_id}
}
```

**处理 `first_trigger` 场景：** 如果响应中包含 `first_trigger: true` 或 `task_id` 为空，自动重新调用一次 `triggerCodeccScan`。

**正常响应后：** 记录 `task_id`（string）和 `task_url`。

告知用户：

```
🚀 CodeCC 代码扫描已启动！

扫描进度查看：{task_url}

扫描通常需要几分钟到十几分钟，完成后您会收到邮件通知。
您也可以随时回复「查询状态」查看当前进度。
```

**触发失败时：** 告知用户失败原因。常见原因：
- 「未找到 OAuth 授权记录」→ 引导回 Step 2 重新授权
- 其他错误 → 展示错误信息 + CodeCC 平台链接

### Step 4: 轮询扫描状态

当用户回复「Done」、「查询状态」或类似意图时，调用 `post_/api/getCodeccScanStatus`：

```json
{
  "id": {application_id},
  "type": "gongfeng"
}
```

> ⚠️ `id` 传的是 `application_id`（申请单 ID），不是 `task_id`

根据 `is_completed` 和 `message` 字段判断状态：

**扫描中（`is_completed: false`, `message: "扫描进行中"`）：**

```
⏳ 扫描仍在进行中...

扫描进度查看：{task_url}

请稍后再次回复「查询状态」查看最新进度。
```

**扫描完成（`is_completed: true`）：** 从响应中提取 `task_id`，进入 Step 5。

**扫描失败（`message: "扫描失败"`）：**

```
❌ 扫描失败。

可能原因：仓库权限不足、仓库为空、或 CodeCC 服务异常。

您可以前往 CodeCC 平台查看详细信息：{task_url}

是否需要重新触发扫描？
```

如果用户选择重新触发，回到 Step 3。

### Step 5: 深度解读

将 `task_id` 从 string 转为 number（parseInt）。

**并行调用两个 API：**

1. `post_/api/getCodeccDefectDimensions`：

```json
{
  "task_id": {task_id_as_number},
  "is_github": false
}
```

2. `post_/api/getCodeccSoftwareComponents`：

```json
{
  "task_id": {task_id_as_number},
  "is_github": false
}
```

> ⚠️ 注意参数名是 `is_github`（boolean），不是 `type`（string）

**部分失败降级：** 如果某个 API 调用失败，展示成功获取的部分，并提示：

> 📌 部分数据获取失败，可前往 CodeCC 平台查看完整报告：{task_url}

**结果展示格式：**

```markdown
## 📊 扫描结果总览

### 代码缺陷维度

| 维度 | 严重 | 一般 | 提示 | 状态 |
|------|------|------|------|------|
| 代码规范 (STANDARD) | {total_serious} | {total_normal} | {total_prompt} | {状态图标} |
| 安全漏洞 (SECURITY) | {total_serious} | {total_normal} | {total_prompt} | {状态图标} |

| 维度 | 超高 | 高 | 中 | 低 | 状态 |
|------|------|-----|-----|-----|------|
| 圈复杂度 (CCN) | {super_high_count} | {high_count} | {medium_count} | {low_count} | {状态图标} |
| 重复率 (DUPC) | {dup_rate}% | {high_count} | {medium_count} | — | {状态图标} |

### 🔍 SCA 组件分析

- 组件总数: {package_count}（高风险: {high_package_count}, 中风险: {medium_package_count}, 低风险: {low_package_count}）
- 新增漏洞: {new_vul_count}（高: {new_high_vul_count}, 中: {new_medium_vul_count}, 低: {new_low_vul_count}）
- 许可证风险: {license_count}（高: {high_license_count}, 中: {medium_license_count}, 低: {low_license_count}）

## 💡 优化建议

{根据扫描结果，按优先级生成优化建议}

## 📋 合规性评估

{综合判断是否满足开源发布标准}
```

**状态图标判断规则：**
- ✅ 无严重问题
- ⚠️ 存在一般或提示级别问题
- ❌ 存在严重问题

**优化建议生成原则：**

1. 优先处理 SECURITY 维度的严重问题（安全漏洞）
2. 其次处理 STANDARD 维度的严重问题（代码规范）
3. 关注 CCN 超高复杂度函数（建议拆分）
4. 关注 DUPC 高重复率（建议抽取公共模块）
5. 关注 SCA 高风险组件（建议升级或替换）

**合规性评估逻辑：** 参考 [📋 结果解读指南](./references/result-interpretation-guide.md) 中的阈值标准。

## Error Handling

| 场景 | 处理方式 |
|------|---------|
| 集成模式 apply_id 对应项目不存在 | 告知「未找到对应的申请单」，终止 |
| URL 格式无效 | 提示仅支持 git.woa.com，请求重新输入 |
| 临时申请单创建失败 | 告知「初始化失败，请稍后重试」，终止 |
| OAuth 验证失败（3 次） | 告知可能原因，建议联系管理员 |
| 扫描触发失败 | 展示错误信息 + CodeCC 平台链接 |
| `first_trigger` 重试后仍失败 | 告知首次扫描初始化可能需要时间，建议稍后重试 |
| 扫描状态查询无记录 | 提示「还未发起扫描」，引导回 Step 3 |
| 扫描失败 | 展示可能原因 + CodeCC 链接，提供重新触发选项 |
| 维度 API 部分失败 | 展示成功部分 + CodeCC 平台 fallback 链接 |
| 维度 API 全部失败 | 告知「结果获取失败」+ CodeCC 平台链接查看 |

## Example Interaction

### 独立模式（用户直接使用）

**用户：** 帮我扫描一下这个仓库的代码 https://git.woa.com/example/my-project

**助手：**

⏳ 正在初始化扫描环境...

扫描环境已就绪。请点击以下链接完成工蜂仓库授权：

https://git.woa.com/oauth/authorize?access_type=offline&client_id={client_id}&redirect_uri=http%3A%2F%2F{{BASE_URL}}%2Fapi%2Foauth%2Fgongfeng%2Fcallback&response_type=code&scope=api+read_user+read_repository&state=appid%3A12345

授权完成后，请回复「Done」继续。

**用户：** Done

**助手：**

✅ 工蜂授权已确认完成

🚀 CodeCC 代码扫描已启动！

扫描进度查看：https://codecc.woa.com/codecc/PROJ_xxx/task/2570255/detail

扫描通常需要几分钟到十几分钟，您可以随时回复「查询状态」查看进度。

**用户：** 查询状态

**助手：**

## 📊 扫描结果总览

### 代码缺陷维度

| 维度 | 严重 | 一般 | 提示 | 状态 |
|------|------|------|------|------|
| 代码规范 (STANDARD) | 0 | 12 | 35 | ⚠️ |
| 安全漏洞 (SECURITY) | 2 | 5 | 1 | ❌ |

| 维度 | 超高 | 高 | 中 | 低 | 状态 |
|------|------|-----|-----|-----|------|
| 圈复杂度 (CCN) | 0 | 3 | 8 | 15 | ⚠️ |
| 重复率 (DUPC) | 4.2% | 2 | 5 | — | ⚠️ |

### 🔍 SCA 组件分析

- 组件总数: 45（高风险: 2, 中风险: 8, 低风险: 35）
- 新增漏洞: 3（高: 1, 中: 2, 低: 0）
- 许可证风险: 5（高: 0, 中: 3, 低: 2）

## 💡 优化建议

1. **[紧急] 安全漏洞**：发现 2 个严重安全漏洞，建议优先修复。前往 CodeCC 查看详情。
2. **[重要] SCA 高风险组件**：2 个高风险组件需要升级或替换。
3. **[建议] 圈复杂度**：3 个函数圈复杂度较高，建议拆分简化。
4. **[建议] 代码规范**：12 个一般规范问题待修复。

## 📋 合规性评估

⚠️ **暂未通过开源发布标准**：存在 2 个严重安全漏洞，需修复后重新扫描。

### 集成模式（由 Agent 调用）

**Agent 传入上下文：** `{ "apply_id": 6789 }`

**助手：**

正在检测申请单 6789 的扫描状态...

✅ 工蜂授权已完成

检测到已有扫描记录（完成时间：2026-03-19 14:30:00）。请选择：
1. 查看已有扫描结果
2. 重新触发扫描

**用户：** 1

**助手：**

## 📊 扫描结果总览

（展示完整的 4 维度 + SCA 分析结果，格式同独立模式）

## Reference Files

- [📋 CodeCC API 参考文档](./references/codecc-api-reference.md) — 加载时机：需要查看 API 参数/响应 schema 详情时
- [📊 结果解读指南](./references/result-interpretation-guide.md) — 加载时机：需要查看阈值标准、合规判断逻辑时
