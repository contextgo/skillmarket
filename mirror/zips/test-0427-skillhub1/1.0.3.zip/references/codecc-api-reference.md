# CodeCC API Reference

本文档为 Level 3 按需加载资源，包含所有 CodeCC 扫描相关 API 的完整请求/响应 schema。

---

## API 概览

| API | MCP 工具名 | 用途 |
|-----|-----------|------|
| applicationProjectsCreate | `post_/api/applicationProjectsCreate` | 创建临时申请单 |
| applicationProjectsGet | `post_/api/applicationProjectsGet` | 验证 OAuth 授权状态 |
| triggerCodeccScan | `post_/api/triggerCodeccScan` | 触发扫描 |
| getCodeccScanStatus | `post_/api/getCodeccScanStatus` | 查询扫描状态 |
| getCodeccDefectDimensions | `post_/api/getCodeccDefectDimensions` | 缺陷维度统计 |
| getCodeccSoftwareComponents | `post_/api/getCodeccSoftwareComponents` | SCA 组件分析 |

---

## 1. applicationProjectsCreate

创建临时申请单草稿，获取 `application_id`。

### Request

```json
{
  "name": "项目名称",
  "scene": "TOSR-1"
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | string | ✅ | 项目名称（1-50 字符） |
| scene | string | ✅ | 开源场景，固定传 `"TOSR-1"` |

### Response

```json
{
  "id": 12345,
  "code": "TOSR-12345",
  "name": "my-project",
  "scene": "TOSR-1",
  "phase": "开源自测",
  "status": "草稿"
}
```

关键字段：`id` — 后续所有 API 使用此值作为 `application_id`。

---

## 2. applicationProjectsGet

查询申请单信息，用于验证 OAuth 授权是否完成。

### Request

```json
{
  "conditions": ["id = {application_id}"]
}
```

> 注意：使用 gocrud 的 GetRequest 格式，`conditions` 是字符串数组。

### Response

```json
{
  "id": 12345,
  "name": "my-project",
  "gongfeng_url": "https://git.woa.com/org/repo",
  "apply_user": "username"
}
```

关键字段：`gongfeng_url` — 非空表示 OAuth 授权已完成。

---

## 3. triggerCodeccScan

触发 CodeCC 代码扫描。

### Request

```json
{
  "application_id": 12345
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| application_id | integer (int32) | ✅ | 申请单 ID |

### Response

```json
{
  "task_id": "2570255",
  "project_id": "CUSTOMPROJ_opensource-app",
  "build_id": "b-xxx-xxx",
  "message": "触发成功",
  "task_url": "https://codecc.woa.com/codecc/CUSTOMPROJ_xxx/task/2570255/detail"
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| task_id | **string** | CodeCC 任务 ID（⚠️ 是字符串，传入维度 API 需转为 number） |
| project_id | string | CodeCC 项目 ID |
| build_id | string | 构建 ID |
| task_url | string | CodeCC 任务详情页链接 |

### 前置条件

- OAuth 授权已完成（`git_oauth_records` 表中有对应记录）
- 申请单存在

### 错误场景

| 错误信息 | 原因 | 处理 |
|---------|------|------|
| `申请单不存在` | application_id 无效 | 检查 ID 是否正确 |
| `未找到OAuth授权记录，请先完成工蜂授权` | OAuth 未完成 | 引导回 OAuth 步骤 |
| `触发CodeCC扫描失败` | CodeCC 服务异常 | 稍后重试 |
| `CodeCC响应数据异常` + message | task_id 为空 | 可能是 first_trigger，重新触发 |

### first_trigger 处理

首次对新仓库扫描时，CodeCC 需要初始化项目配置。此时：
- `task_id` 可能为空
- 响应 message 可能包含初始化相关提示

**处理方式：** 自动重新调用一次 `triggerCodeccScan`。

---

## 4. getCodeccScanStatus

查询扫描任务状态。

### Request

```json
{
  "id": 12345,
  "type": "gongfeng"
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| id | integer (int32) | ✅ | **申请单 ID**（⚠️ 不是 task_id） |
| type | string | 否 | 扫描类型，默认 `"gongfeng"` |

> ⚠️ **关键：`id` 参数是申请单 ID（application_id），不是 triggerCodeccScan 返回的 task_id 或 scan_record_id。**

### Response

```json
{
  "scan_record_id": 1,
  "build_id": "b-xxx-xxx",
  "task_id": "2570255",
  "is_completed": true,
  "message": "扫描已完成",
  "task_url": "https://codecc.woa.com/codecc/CUSTOMPROJ_xxx/task/2570255/detail",
  "data": { },
  "update_time": "2026-03-19 12:00:00"
}
```

| 字段 | 类型 | 说明 |
|------|------|------|
| is_completed | boolean | 是否完成 |
| message | string | 状态描述：`扫描进行中` / `扫描已完成` / `扫描失败` |
| task_id | **string** | CodeCC 任务 ID（⚠️ 字符串类型） |
| task_url | string | CodeCC 任务详情页 |
| data | object | 扫描结果数据（仅完成时有值） |

### 状态值

| message | is_completed | 含义 |
|---------|-------------|------|
| `扫描进行中` | false | 扫描正在执行 |
| `扫描已完成` | true | 扫描成功完成 |
| `扫描失败` | false | 扫描执行失败 |

---

## 5. getCodeccDefectDimensions

查询 CodeCC 缺陷的四个维度统计数据。

### Request

```json
{
  "task_id": 2570255,
  "is_github": false
}
```

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| task_id | **integer** | ✅ | CodeCC 任务 ID（⚠️ 必须是数字，不是字符串） |
| is_github | **boolean** | 否 | 是否 GitHub 项目，工蜂传 `false`（⚠️ 与 getCodeccScanStatus 的 `type` 不同） |

> ⚠️ **参数差异：** 这里用 `is_github: false`（boolean），而 getCodeccScanStatus 用 `type: "gongfeng"`（string）。

### Response

```json
{
  "STANDARD": {
    "total_serious": 0,
    "total_normal": 12,
    "total_prompt": 35
  },
  "SECURITY": {
    "total_serious": 2,
    "total_normal": 5,
    "total_prompt": 1
  },
  "CCN": {
    "super_high_count": 0,
    "high_count": 3,
    "medium_count": 8,
    "low_count": 15
  },
  "DUPC": {
    "super_high_count": 0,
    "high_count": 2,
    "medium_count": 5,
    "dup_rate": 4.2
  }
}
```

### 维度字段说明

**STANDARD（代码规范）和 SECURITY（安全漏洞）：**

| 字段 | 类型 | 说明 |
|------|------|------|
| total_serious | int | 严重问题数 |
| total_normal | int | 一般问题数 |
| total_prompt | int | 提示问题数 |

**CCN（圈复杂度）：**

| 字段 | 类型 | 说明 |
|------|------|------|
| super_high_count | int | 超高复杂度函数数（圈复杂度 > 100） |
| high_count | int | 高复杂度函数数（圈复杂度 50-100） |
| medium_count | int | 中复杂度函数数（圈复杂度 20-50） |
| low_count | int | 低复杂度函数数（圈复杂度 < 20） |

**DUPC（重复率）：**

| 字段 | 类型 | 说明 |
|------|------|------|
| dup_rate | float | 代码重复率百分比 |
| super_high_count | int | 超高重复文件数 |
| high_count | int | 高重复文件数 |
| medium_count | int | 中重复文件数 |

---

## 6. getCodeccSoftwareComponents

查询 SCA（软件成分分析）结果。

### Request

```json
{
  "task_id": 2570255,
  "is_github": false
}
```

参数与 `getCodeccDefectDimensions` 完全一致。

### Response

```json
{
  "task_id": 2570255,
  "tool_name": "PECKER_SCA",
  "build_id": "b-xxx",
  "time": 1710835200,
  "defect_count": 3,
  "package_count": 45,
  "high_package_count": 2,
  "medium_package_count": 8,
  "low_package_count": 35,
  "unknown_package_count": 0,
  "new_vul_count": 3,
  "new_high_vul_count": 1,
  "new_medium_vul_count": 2,
  "new_low_vul_count": 0,
  "new_unknown_vul_count": 0,
  "license_count": 5,
  "high_license_count": 0,
  "medium_license_count": 3,
  "low_license_count": 2,
  "unknown_license_count": 0
}
```

| 分类 | 字段 | 说明 |
|------|------|------|
| **组件** | package_count | 组件总数 |
| | high/medium/low/unknown_package_count | 各风险等级组件数 |
| **漏洞** | new_vul_count | 新增漏洞总数 |
| | new_high/medium/low/unknown_vul_count | 各等级新增漏洞数 |
| **许可证** | license_count | 许可证总数 |
| | high/medium/low/unknown_license_count | 各风险等级许可证数 |

### 空数据处理

当 SCA 分析无数据时，API 返回空的 `SCARecord`（所有计数字段为 0）。此时应提示：

> SCA 组件分析暂无数据，可能该项目尚未使用第三方组件，或 SCA 工具尚未完成分析。

---

## 参数陷阱速查表

| 陷阱 | 详情 |
|------|------|
| **id vs application_id** | `getCodeccScanStatus` 用 `id`，`triggerCodeccScan` 用 `application_id`，都是申请单 ID |
| **type vs is_github** | 状态查询用 `type: "gongfeng"`，维度/SCA 查询用 `is_github: false` |
| **task_id 类型** | 状态查询返回 string，维度/SCA 查询要求 number，需要 parseInt 转换 |
| **conditions 格式** | applicationProjectsGet 使用 gocrud 格式：`{"conditions": ["id = 123"]}`，不是 `{"id": 123}` |
