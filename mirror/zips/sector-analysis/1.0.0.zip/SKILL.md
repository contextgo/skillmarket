---
name: sector-analysis
description: '对A股概念板块或行业板块进行多维度分析，涵盖行情、基本面、资金、消息、研报、相关个股及涨跌归因。当用户询问某板块现状、板块异动原因或多板块涨跌排行时触发。Use when: "分析XX板块", "半导体板块为何大涨", "今天哪些板块涨最多". Calls tools: sectortLatestPrice, sectorFunAnalysis, sectorCapAnalysis, sectorNewsAnalysis, sectorReportAnalysis, sectorRelatedStocks, sectorPriceChangeRank, sectorPriceFluctReason, sectorPriceChangeReason, sectorEventAnalysis, queryHotSector.'
compatibility: 'Requires DeepQ MCP Server. Preferred: streamableHttp with access_token. Fallback: stdio via npx @deepqtech/mcp-server-js. DEEPQ_API_KEY env var or default sWxMywZpIt8N62JXGNng.'
metadata:
  author: deepqtech
  version: "1.0"
---

# 板块分析

## MCP Server 配置

本技能依赖 **DeepQ MCP Server** 提供数据工具。使用前请确保已在 agent 中配置 MCP Server。

### 推荐：Streamable HTTP（无需本地安装）

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-streamable": {
      "type": "streamableHttp",
      "url": "https://cgi.deepq.tech:9198/mcp-servers/mcp?access_token=sWxMywZpIt8N62JXGNng"
    }
  }
}
```

> `access_token` 优先使用环境变量 `DEEPQ_API_KEY` 的值，未设置时使用默认值 `sWxMywZpIt8N62JXGNng`。

### 备选：Stdio 本地进程

```json
{
  "mcpServers": {
    "Deepq-all-in-one-auth-stdio": {
      "type": "stdio",
      "command": "npx",
      "args": ["-y", "@deepqtech/mcp-server-js@latest", "start"],
      "env": {
        "DEEPQ_API_KEY": "sWxMywZpIt8N62JXGNng"
      }
    }
  }
}
```

---

## 功能说明

围绕特定概念板块或行业板块，提供：
- **行情**：最新涨跌幅、成交量
- **基本面**：估值、盈利、财务数据
- **资金面**：主力流入流出、资金动向
- **消息面**：近期相关新闻资讯
- **研报面**：机构研究报告观点
- **相关个股**：板块内重要股票列表
- **涨跌排行**：多板块横向对比
- **涨跌归因**：板块异动原因解读

## 触发场景

- "分析一下新能源板块的现状"
- "半导体板块最近为什么这么强？"
- "今天哪些板块涨得最多？"
- "医药板块内有哪些值得关注的股票？"

## 执行步骤

### 第一步：确认板块名称

直接使用用户提供的板块名称作为 `query` 参数。如模糊，可先调用：

```json
调用工具: queryHotSector
参数: {}
```

### 第二步：综合板块分析（并行调用）

```json
调用工具: sectortLatestPrice
参数: { "query": "<板块名称>", "date": "YYYY-MM-DD" }

调用工具: sectorFunAnalysis
参数: { "query": "<板块名称>", "date": "YYYY-MM-DD" }

调用工具: sectorCapAnalysis
参数: { "query": "<板块名称>", "date": "YYYY-MM-DD" }

调用工具: sectorNewsAnalysis
参数: { "query": "<板块名称>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD", "maxCnt": "5" }

调用工具: sectorReportAnalysis
参数: { "query": "<板块名称>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD", "maxCnt": "3" }

调用工具: sectorRelatedStocks
参数: { "query": "<板块名称>", "sortBy": "change_ratio", "stockCnt": "5" }
```

### 第三步（按需）：涨跌归因

若用户关注板块近期异动原因：

```json
调用工具: sectorPriceFluctReason
参数: { "query": "<板块名称>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD", "maxCnt": "3" }

调用工具: sectorPriceChangeReason
参数: { "query": "<板块名称>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD" }

调用工具: sectorEventAnalysis
参数: { "keyword": "<板块名称>", "startDate": "YYYY-MM-DD", "endDate": "YYYY-MM-DD", "maxCnt": "3" }
```

### 第四步（按需）：多板块涨跌排行

```json
调用工具: sectorPriceChangeRank
参数: {
  "sectorType": "all",
  "priceDirection": "raise",
  "sectorCount": "10",
  "startDate": "YYYY-MM-DD",
  "endDate": "YYYY-MM-DD"
}
```

## sectorRelatedStocks 排序方式

| sortBy 值 | 说明 |
|---|---|
| `change_ratio` | 按当日涨跌幅降序（默认） |
| `market_value` | 按流通市值降序 |
| `relevance` | 按与板块相关度降序 |

## 注意事项

- `query` 支持概念板块名称（如"新能源"、"人工智能"）和行业板块名称（如"医药生物"、"电子"）。
- 时间范围建议不超过 30 天，以获得最准确的归因分析。
