#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys, io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

"""
赛华佗 · 五行体质计算器
用法: python constitution_calculator.py <年> <月> <日> <时辰>
时辰示例: 子时, 丑时, 寅时, 卯时, 辰时, 巳时, 午时, 未时, 申时, 酉时, 戌时, 亥时
"""

import sys

STEMS = ['甲', '乙', '丙', '丁', '戊', '己', '庚', '辛', '壬', '癸']
BRANCHES = ['子', '丑', '寅', '卯', '辰', '巳', '午', '未', '申', '酉', '戌', '亥']
ELEMENTS = ['木', '火', '土', '金', '水']
ZODIAC = {'子':'鼠','丑':'牛','寅':'虎','卯':'兔','辰':'龙','巳':'蛇',
          '午':'马','未':'羊','申':'猴','酉':'鸡','戌':'狗','亥':'猪'}

STEM_ELEMENT = {'甲':'木','乙':'木','丙':'火','丁':'火',
                 '戊':'土','己':'土','庚':'金','辛':'金','壬':'水','癸':'水'}
STEM_YINYANG = {'甲':'阳','乙':'阴','丙':'阳','丁':'阴',
                 '戊':'阳','己':'阴','庚':'阳','辛':'阴','壬':'阳','癸':'阴'}

BRANCH_ELEMENT = {'子':'水','丑':'土','寅':'木','卯':'木',
                   '辰':'土','巳':'火','午':'火','未':'土',
                   '申':'金','酉':'金','戌':'土','亥':'水'}
HOUR_ELEMENT = BRANCH_ELEMENT

MONTH_PEAK = [
    [('金','旺'),('水','相'),('木','死'),('火','囚'),('土','休')],
    [('金','旺'),('水','相'),('木','死'),('火','囚'),('土','休')],
    [('木','旺'),('火','相'),('土','死'),('金','囚'),('水','休')],
    [('木','旺'),('火','相'),('土','死'),('金','囚'),('水','休')],
    [('火','旺'),('土','相'),('金','死'),('水','囚'),('木','休')],
    [('火','旺'),('土','相'),('金','死'),('水','囚'),('木','休')],
    [('土','旺'),('金','相'),('水','死'),('木','囚'),('火','休')],
    [('土','旺'),('金','相'),('水','死'),('木','囚'),('火','休')],
    [('金','旺'),('水','相'),('木','死'),('火','囚'),('土','休')],
    [('金','旺'),('水','相'),('木','死'),('火','囚'),('土','休')],
    [('水','旺'),('木','相'),('火','死'),('土','囚'),('金','休')],
    [('水','旺'),('木','相'),('火','死'),('土','囚'),('金','休')],
]

CONSTITUTION_MAP = {
    ('水','金'): '气虚质',
    ('金','金'): '气虚质',
    ('水','土'): '痰湿质',
    ('金','火'): '阴虚质',
    ('木','火'): '阴虚质',
    ('火','火'): '阴虚质',
    ('木','木'): '气郁质',
    ('木','土'): '气郁质',
    ('火','土'): '湿热质',
    ('土','火'): '湿热质',
    ('土','土'): '痰湿质',
    ('水','木'): '血瘀质',
    ('水','水'): '阳虚质',
}

HOUR_NAMES = {
    '子时':'子', '丑时':'丑', '寅时':'寅', '卯时':'卯',
    '辰时':'辰', '巳时':'巳', '午时':'午', '未时':'未',
    '申时':'申', '酉时':'酉', '戌时':'戌', '亥时':'亥',
}

def get_stem(year):
    return STEMS[(year - 4) % 10]

def get_branch(year):
    return BRANCHES[(year - 4) % 12]

def calc_constitution(year, month, day, hour_str):
    stem = get_stem(year)
    branch = get_branch(year)
    stem_el = STEM_ELEMENT[stem]
    branch_el = BRANCH_ELEMENT[branch]
    yin_yang = STEM_YINYANG[stem]
    zodiac = ZODIAC[branch]

    hour_branch = HOUR_NAMES.get(hour_str, hour_str)
    hour_el = HOUR_ELEMENT[hour_branch]

    month_idx = max(0, min(11, month - 1))
    month_peaks = MONTH_PEAK[month_idx]
    month_peak_el = month_peaks[0][0]

    peak_scores = {el: 0 for el in ELEMENTS}
    peak_scores[stem_el] += 4
    peak_scores[branch_el] += 2
    peak_scores[hour_el] += 3
    peak_scores[month_peak_el] += 5

    max_el = max(peak_scores, key=peak_scores.get)
    min_el = min(peak_scores, key=peak_scores.get)
    total = sum(peak_scores.values())
    peak_range = peak_scores[max_el] - peak_scores[min_el]

    if peak_range <= 3 and peak_scores[max_el] >= total * 0.22:
        constitution = '平和质'
    else:
        constitution = CONSTITUTION_MAP.get((stem_el, branch_el), '气虚质')

    return {
        'year': year,
        'stem': stem,
        'branch': branch,
        'stem_element': stem_el,
        'yin_yang': yin_yang,
        'zodiac': zodiac,
        'birth_hour': hour_str,
        'hour_element': hour_el,
        'month_peak': month_peak_el,
        'scores': peak_scores,
        'dominant': max_el,
        'weak': min_el,
        'constitution': constitution,
        'total': total,
        'peak_range': peak_range,
    }

def print_report(r):
    month_labels = {'金':'申酉','火':'巳午','木':'寅卯','水':'亥子','土':'辰戌丑'}
    month_str = month_labels.get(r['month_peak'], str(r.get('month_peak', '')))
    print(f"\n{'='*30}")
    print(f"  赛华佗 · 五行体质分析报告")
    print(f"{'='*30}")
    print(f"\n【基础信息】")
    print(f"  出生：{r['year']}年")
    print(f"  时辰：{r['birth_hour']}（{r['hour_element']}旺）")
    print(f"  生肖：{r['zodiac']}（{r['branch']}）")
    print(f"  天干：{r['stem']}（{r['stem_element']}，{r['yin_yang']}）")

    print(f"\n【五行得分】")
    for el in ELEMENTS:
        score = r['scores'][el]
        pct = score / r['total'] * 100
        bar = '█' * score
        dominant_mark = ' ★主' if el == r['dominant'] else (' ·弱' if el == r['weak'] else '')
        print(f"  {el}：{score:2d}分 {bar} ({pct:.0f}%){dominant_mark}")

    print(f"\n【体质判定】{r['constitution']}")
    print(f"  主旺：{r['dominant']} | 偏弱：{r['weak']}")
    print(f"{'='*30}\n")

if __name__ == '__main__':
    if len(sys.argv) < 5:
        print(__doc__)
        print("示例: python constitution_calculator.py 1990 6 30 卯时")
        sys.exit(1)

    year = int(sys.argv[1])
    month = int(sys.argv[2])
    day = int(sys.argv[3])
    hour = sys.argv[4]

    month_idx = max(0, min(11, month - 1))
    month_peak = MONTH_PEAK[month_idx][0][0]

    report = calc_constitution(year, month, day, hour)
    report['month_peak'] = month_peak
    print_report(report)
    print("提示：此为基础计算，如需精准辨证，请咨询赛华佗本人。")
