"""体质追踪历史记录脚本

用法:
  python constitution_history.py add <日期> <体质类型> <主要证型> <简要描述>
  python constitution_history.py list          # 列出所有历史
  python constitution_history.py latest         # 查看最新记录
  python constitution_history.py summary        # 打印体质演变摘要
"""

import json
import sys
from pathlib import Path
from datetime import datetime

HISTORY_FILE = Path(__file__).parent.parent / "memory" / "tcm-constitution-history.md"


def ensure_dir():
    HISTORY_FILE.parent.mkdir(parents=True, exist_ok=True)


def load_history() -> list:
    if not HISTORY_FILE.exists():
        return []
    with open(HISTORY_FILE, "r", encoding="utf-8") as f:
        content = f.read()
    if not content.strip():
        return []
    # 尝试解析已有JSON列表
    try:
        return json.loads(content)
    except Exception:
        return []


def save_history(records: list):
    ensure_dir()
    with open(HISTORY_FILE, "w", encoding="utf-8") as f:
        f.write(json.dumps(records, ensure_ascii=False, indent=2, default=str))


def add_record(date: str, constitution: str, syndrome: str, description: str, constitution_score: dict = None):
    """添加一条体质记录。"""
    records = load_history()
    entry = {
        "date": date,
        "constitution": constitution,
        "syndrome": syndrome,
        "description": description,
        "recorded_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
    }
    if constitution_score:
        entry["constitution_score"] = constitution_score
    records.append(entry)
    save_history(records)
    print(f"[{date}] 体质记录已添加：{constitution} | {syndrome}")


def list_records():
    records = load_history()
    if not records:
        print("暂无体质历史记录。")
        return
    print(f"共 {len(records)} 条记录：\n")
    for r in records:
        print(f"  {r.get('date','?')} | {r.get('constitution','?')} | {r.get('syndrome','?')}")
        print(f"    {r.get('description','')}")
        print()


def show_latest():
    records = load_history()
    if not records:
        print("暂无体质历史记录。")
        return
    latest = records[-1]
    print(f"最新记录 [{latest.get('date','?')}]:")
    print(json.dumps(latest, ensure_ascii=False, indent=2, default=str))


def show_summary():
    records = load_history()
    if not records:
        print("暂无体质历史记录。")
        return
    print("=== 体质演变摘要 ===\n")
    for r in records:
        print(f"[{r.get('date','?')}]")
        print(f"  体质：{r.get('constitution','?')}")
        print(f"  证型：{r.get('syndrome','?')}")
        print(f"  描述：{r.get('description','?')}")
        print()


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "list"
    if cmd == "add":
        if len(sys.argv) < 6:
            print("用法: constitution_history.py add <日期> <体质类型> <主要证型> <简要描述>")
        else:
            add_record(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
    elif cmd == "list":
        list_records()
    elif cmd == "latest":
        show_latest()
    elif cmd == "summary":
        show_summary()
    else:
        print(__doc__)
