"""中医健康档案读写脚本

用法:
  python health_profile.py read           # 读取当前健康档案
  python health_profile.py append <文本>  # 追加一条记录
  python health_profile.py show          # 打印完整档案摘要
"""

import json
import sys
from pathlib import Path
from datetime import datetime

PROFILE_FILE = Path(__file__).parent.parent / "memory" / "tcm-health-profile.json"


def ensure_dir():
    PROFILE_FILE.parent.mkdir(parents=True, exist_ok=True)


def load_profile():
    if PROFILE_FILE.exists():
        with open(PROFILE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_profile(data):
    ensure_dir()
    with open(PROFILE_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2, default=str)


def read_profile():
    data = load_profile()
    if not data:
        print("暂无健康档案记录。")
    else:
        print(json.dumps(data, ensure_ascii=False, indent=2, default=str))


def append_note(text: str):
    data = load_profile()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    if "notes" not in data:
        data["notes"] = []
    data["notes"].append({"time": ts, "content": text})
    save_profile(data)
    print(f"[{ts}] 记录已追加。")


def append_diagnosis(syndrome: str, tea: str, acupoints: str, diet: str, warning: str, constitution: str = ""):
    """追加一次辨证记录到档案。"""
    data = load_profile()
    ts = datetime.now().strftime("%Y-%m-%d %H:%M")
    if "consultations" not in data:
        data["consultations"] = []
    entry = {
        "time": ts,
        "syndrome": syndrome,
        "tea": tea,
        "acupoints": acupoints,
        "diet": diet,
        "warning": warning,
        "constitution": constitution,
    }
    data["consultations"].append(entry)
    save_profile(data)
    print(f"[{ts}] 辨证记录已保存：{syndrome}")


if __name__ == "__main__":
    cmd = sys.argv[1] if len(sys.argv) > 1 else "read"
    if cmd == "read":
        read_profile()
    elif cmd == "append":
        if len(sys.argv) < 3:
            print("用法: python health_profile.py append <文本>")
        else:
            append_note(sys.argv[2])
    elif cmd == "show":
        read_profile()
    else:
        print(f"未知命令: {cmd}")
        print(__doc__)
