#!/usr/bin/env python3
"""将知识条目写入 knowledge_base.xlsx。

用法:
    python write_kb.py --input <knowledge_entries.json> --output <knowledge_base.xlsx>
    python write_kb.py --append <knowledge_entries.json> --target <knowledge_base.xlsx>

功能:
    - 从 JSON 文件读取知识条目列表
    - 写入或追加到 knowledge_base.xlsx
    - 单行英文表头（与 knowledge_base_final.xlsx 模板一致）
    - 自动编号（追加时从已有最大编号继续）
    - 验证 13 列完整性
"""

import argparse
import io
import json
import os
import re
import sys

# Windows 控制台编码修复
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
from pathlib import Path

# 13 列英文键名，与 knowledge_base_final.xlsx 模板一致
KB_COLUMNS = [
    "kb_id", "main_category", "sub_category", "phenomenon", "cause",
    "solution", "applicable_condition", "keywords", "severity", "estimated_time",
    "required_resources", "reference_spec", "source_case",
]

# 中文列名注释（仅用于参考，不写入表头）
CN_NAMES = {
    "kb_id": "知识ID", "main_category": "问题大类", "sub_category": "问题子类",
    "phenomenon": "现象描述", "cause": "原因分析", "solution": "解决方案",
    "applicable_condition": "适用条件", "keywords": "关键词", "severity": "严重等级",
    "estimated_time": "预计耗时", "required_resources": "所需资源",
    "reference_spec": "规范依据", "source_case": "案例来源",
}


def load_entries(json_path: str) -> list:
    """加载知识条目 JSON 文件。"""
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if isinstance(data, list):
        return data
    elif isinstance(data, dict) and "entries" in data:
        return data["entries"]
    else:
        return [data]


def validate_entry(entry: dict) -> list:
    """验证单个条目完整性，返回缺失字段列表。"""
    missing = []
    for key in KB_COLUMNS:
        if key not in entry or not str(entry.get(key, "")).strip():
            # kb_id 可自动生成，source_case 允许为空
            if key not in ("kb_id", "source_case"):
                missing.append(key)
    return missing


def auto_number(entries: list, existing_count: int = 0, prefix: str = "CASE") -> list:
    """为条目自动编号。"""
    for i, entry in enumerate(entries, 1):
        if not entry.get("kb_id"):
            entry["kb_id"] = f"{prefix}{existing_count + i:03d}"
    return entries


def write_new(xlsx_path: str, entries: list):
    """创建新的 knowledge_base.xlsx（单行英文表头，匹配模板格式）。"""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

    wb = Workbook()
    ws = wb.active
    ws.title = "Sheet1"

    # 行1: 英文键名（与模板 knowledge_base_final.xlsx 一致）
    header_font = Font(bold=True, size=11)
    header_fill = PatternFill(start_color="D9E1F2", end_color="D9E1F2", fill_type="solid")
    for col, en_key in enumerate(KB_COLUMNS, 1):
        cell = ws.cell(row=1, column=col, value=en_key)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

    # 行2+: 数据（无第二行表头）
    for row_idx, entry in enumerate(entries, 2):
        for col, key in enumerate(KB_COLUMNS, 1):
            value = entry.get(key, "")
            if value is None:
                value = ""
            ws.cell(row=row_idx, column=col, value=str(value))

    # 设置列宽（根据模板格式优化）
    col_widths = [14, 12, 20, 50, 50, 50, 18, 24, 10, 22, 24, 40, 22]
    for i, w in enumerate(col_widths, 1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = w

    # 冻结首行
    ws.freeze_panes = "A2"

    # 设置数据行自动换行
    thin_border = Border(
        left=Side(style='thin', color='D9D9D9'),
        right=Side(style='thin', color='D9D9D9'),
        top=Side(style='thin', color='D9D9D9'),
        bottom=Side(style='thin', color='D9D9D9'),
    )
    for row in range(2, len(entries) + 2):
        for col in range(1, len(KB_COLUMNS) + 1):
            cell = ws.cell(row=row, column=col)
            cell.border = thin_border
            cell.alignment = Alignment(vertical="center", wrap_text=True)

    wb.save(xlsx_path)
    print(f"已创建: {xlsx_path} ({len(entries)} 条)")


def append_entries(xlsx_path: str, entries: list):
    """追加知识条目到已有的 knowledge_base.xlsx。"""
    from openpyxl import load_workbook

    if not os.path.isfile(xlsx_path):
        print(f"文件不存在，将创建新文件: {xlsx_path}")
        write_new(xlsx_path, entries)
        return

    wb = load_workbook(xlsx_path)
    ws = wb.active

    # 统计已有条目数（行1是表头，从行2开始是数据）
    existing_count = 0
    if ws.max_row > 1:
        existing_count = ws.max_row - 1

    # 自动编号
    auto_number(entries, existing_count, "CASE")

    # 追加数据
    start_row = ws.max_row + 1
    for i, entry in enumerate(entries):
        row = start_row + i
        for col, key in enumerate(KB_COLUMNS, 1):
            value = entry.get(key, "")
            if value is None:
                value = ""
            ws.cell(row=row, column=col, value=str(value))

    wb.save(xlsx_path)
    print(f"已追加 {len(entries)} 条到 {xlsx_path} (起始行 {start_row})")


def main():
    parser = argparse.ArgumentParser(description="将知识条目写入 knowledge_base.xlsx")
    parser.add_argument("--input", required=True, help="知识条目 JSON 文件路径")
    parser.add_argument("--output", help="输出 xlsx 文件路径（默认覆盖 knowledge_base.xlsx）")
    parser.add_argument("--append", action="store_true", help="追加模式（不覆盖已有数据）")
    parser.add_argument("--validate-only", action="store_true", help="仅验证，不写入")
    parser.add_argument("--prefix", default="CASE", help="自动编号前缀（默认 CASE）")
    args = parser.parse_args()

    entries = load_entries(args.input)
    print(f"加载 {len(entries)} 条知识条目")

    # 验证
    errors = []
    for i, entry in enumerate(entries):
        missing = validate_entry(entry)
        if missing:
            errors.append(f"  条目 {i+1}: 缺失 {', '.join(missing)}")

    if errors:
        print(f"\n[WARNING] 验证警告 ({len(errors)} 条):")
        for e in errors[:20]:
            print(e)
        if len(errors) > 20:
            print(f"  ... 共 {len(errors)} 条警告")

    if args.validate_only:
        print("\n仅验证模式，未写入文件。")
        return

    # 确定 xlsx 路径
    xlsx_path = args.output
    if not xlsx_path:
        xlsx_path = os.path.join(os.getcwd(), "knowledge_base.xlsx")

    # 写入
    if args.append:
        append_entries(xlsx_path, entries)
    else:
        write_new(xlsx_path, entries)


if __name__ == "__main__":
    main()
