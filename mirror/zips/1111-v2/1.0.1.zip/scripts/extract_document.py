#!/usr/bin/env python3
"""从单个质量检验记录文档中提取结构化内容为 JSON。

用法:
    python extract_document.py <file_path> [--output <json_path>]
    python extract_document.py --batch <source_dir> [--output-dir <dir>]

支持的文档类型:
    - 监理回复文档（路径含"监理回复"/"质量检查回复"/"施工现场质量检查回复"）
    - 质监站检查问题（路径含"检查问题"）
    - 质监站整改回复（路径含"整改回复"）
    - 质量联检台账 (.xlsx)

功能:
    - 自动识别文档类型
    - 从 .docx 文件提取段落文本和表格数据
    - 从 .xlsx 文件提取表格数据
    - 输出结构化 JSON
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path


def identify_doc_type(filepath: str) -> str:
    """根据文件路径和名称识别文档类型。"""
    name = os.path.basename(filepath).lower()
    parent = os.path.basename(os.path.dirname(filepath)).lower()

    # 优先匹配：文件名关键词
    if any(kw in name for kw in ["监理回复", "质量检查回复", "施工现场质量检查回复", "质量联检回复", "质量联合检查记录回复"]):
        return "quality_inspection_reply"
    if any(kw in name for kw in ["整改回复", "监督执法记录整改回复"]):
        return "rectification_reply"
    if any(kw in name for kw in ["检查问题"]):
        return "inspection_problem"
    # 质量联检记录（子目录中的 .doc 文件）
    if "质量联检" in name or "质量联合检查记录" in name:
        if "回复" not in name:
            return "quality_inspection_record"
    # 台账文件
    if name.endswith(".xlsx") and "台账" in name:
        return "ledger"

    # 通过父目录名辅助判断
    if re.search(r"质量联检-\d+", parent):
        if "回复" in name:
            return "quality_inspection_reply"
        elif ".pdf" in name:
            return "quality_inspection_record"

    return "unknown"


def extract_from_docx(filepath: str) -> dict:
    """从 .docx 文件提取文本和表格。"""
    from docx import Document

    doc = Document(filepath)
    doc_type = identify_doc_type(filepath)

    result = {
        "file_path": filepath,
        "doc_type": doc_type,
        "project_name": "",
        "inspection_id": "",
        "inspection_date": "",
        "reply_date": "",
        "problems": [],
        "inspection_content": "",
        "raw_text": "",
    }

    # 提取段落文本
    paragraphs = []
    for p in doc.paragraphs:
        text = p.text.strip()
        if text:
            paragraphs.append(text)

    full_text = "\n".join(paragraphs)
    result["raw_text"] = full_text

    # 提取结构化信息
    result.update(_parse_paragraphs(paragraphs, doc_type))

    # 提取表格数据
    tables_data = []
    for table in doc.tables:
        table_rows = []
        for row in table.rows:
            cells = [cell.text.strip() for cell in row.cells]
            table_rows.append(cells)
        tables_data.append(table_rows)

    # 如果表格中有问题数据，解析表格
    if doc_type == "quality_inspection_reply" and tables_data:
        result.update(_parse_reply_table(tables_data))
    elif doc_type == "quality_inspection_record" and tables_data:
        result.update(_parse_inspection_record_table(tables_data))

    return result


def _parse_paragraphs(paragraphs: list, doc_type: str) -> dict:
    """从段落文本中解析结构化信息。"""
    info = {
        "project_name": "",
        "inspection_id": "",
        "inspection_date": "",
        "reply_date": "",
        "problems": [],
        "inspection_content": "",
    }

    full_text = "\n".join(paragraphs)

    # 提取工程名称
    m = re.search(r"工程名称[：:]\s*(.+?)(?:\n|$)", full_text)
    if m:
        info["project_name"] = m.group(1).strip()

    # 提取编号
    m = re.search(r"编号[：:]\s*(ZL-\d+|JD第\d+号|JD第\s*\d+\s*号)", full_text)
    if m:
        info["inspection_id"] = re.sub(r"\s+", "", m.group(1))

    # 提取检查时间
    m = re.search(r"检查时间[：:]\s*(\d{4}[\./年]\s*\d{1,2}[\./月]\s*\d{1,2}日?)", full_text)
    if m:
        info["inspection_date"] = re.sub(r"\s+", "", m.group(1))

    # 提取回复时间（监理回复表格类型）
    m = re.search(r"回复时间[：:]\s*(\d{4}[\./]\s*\d{1,2}[\./]\s*\d{1,2})", full_text)
    if m:
        info["reply_date"] = re.sub(r"\s+", "", m.group(1))

    # 提取检查内容
    content_match = re.search(r"(?:一、|1[\.、])\s*检查内容[：:]\s*\n?(.*?)(?=(?:二、|2[\.、])\s*检查情况)", full_text, re.DOTALL)
    if content_match:
        info["inspection_content"] = content_match.group(1).strip()

    # 提取发现问题（质监站检查问题类型）
    if doc_type in ("inspection_problem", "quality_inspection_record"):
        # 尝试多种标题匹配
        problem_section = None
        for header in [r"二、\s*检查情况及发现问题", r"二、\s*检查情况", r"检查情况及发现问题"]:
            m = re.search(rf"(?:{header})[：:]?\s*\n?(.*?)(?=当事人签认|三、|监督工作|$)", full_text, re.DOTALL)
            if m and m.group(1).strip():
                problem_section = m.group(1).strip()
                break

        if problem_section:
            # 按编号拆分问题（支持中文顿号、点号、顿号后无空格等格式）
            problems = re.split(r"(?=\d+[、.．\s])", problem_section)
            for p in problems:
                p = p.strip()
                if not p:
                    continue
                # 清理编号前缀
                p_clean = re.sub(r"^\d+[、.．]\s*", "", p).strip()
                if p_clean and len(p_clean) > 3:
                    info["problems"].append({
                        "seq": len(info["problems"]) + 1,
                        "description": p_clean,
                        "rectification": "",
                        "location": _extract_location(p_clean),
                    })

    # 提取整改回复内容
    if doc_type == "rectification_reply":
        rect_section = None
        for header in [r"整改[情况措施回复]", r"针对.*?问题.*?整改"]:
            m = re.search(rf"(?:{header})[：:]?\s*\n?(.*?)(?=特此报告|此致|当事人|$)", full_text, re.DOTALL | re.IGNORECASE)
            if m and m.group(1).strip():
                rect_section = m.group(1).strip()
                break
        if rect_section:
            # 按编号拆分
            items = re.split(r"(?=\d+[、.．\s])", rect_section)
            for item in items:
                item = item.strip()
                if not item:
                    continue
                item_clean = re.sub(r"^\d+[、.．]\s*", "", item).strip()
                if item_clean and len(item_clean) > 3:
                    info["problems"].append({
                        "seq": len(info["problems"]) + 1,
                        "description": "",
                        "rectification": item_clean,
                        "location": "",
                    })

    return info


def _parse_reply_table(tables_data: list) -> dict:
    """从监理回复表格中提取问题-整改对。"""
    info = {"problems": []}

    for table in tables_data:
        if len(table) < 3:
            continue

        # 查找表头行（含"问题描述"和"整改措施"）
        header_idx = -1
        for i, row in enumerate(table):
            row_text = " ".join(row)
            if "问题描述" in row_text and ("整改措施" in row_text or "整改照片" in row_text):
                header_idx = i
                break

        if header_idx < 0:
            continue

        # 解析数据行
        for row in table[header_idx + 1:]:
            # 跳过空行和签章行
            if not row or all(not c.strip() for c in row):
                continue
            if any(kw in "".join(row) for kw in ["整改单位", "负责人", "复查人"]):
                break

            # 提取序号、问题描述、整改措施
            seq = ""
            description = ""
            rectification = ""

            for cell in row:
                cell = cell.strip()
                if not cell:
                    continue
                if re.match(r"^\d+$", cell) and not seq:
                    seq = cell
                elif not description and len(cell) > 3:
                    description = cell
                elif description and len(cell) > 3 and cell != description:
                    rectification = cell
                    break

            if description:
                info["problems"].append({
                    "seq": int(seq) if seq.isdigit() else len(info["problems"]) + 1,
                    "description": description,
                    "rectification": rectification,
                    "location": _extract_location(description),
                })

    return info


def _parse_inspection_record_table(tables_data: list) -> dict:
    """从质量联合检查记录表格中提取问题（ZL-XXX 格式）。"""
    info = {"problems": [], "inspection_id": "", "inspection_date": ""}

    for table in tables_data:
        if len(table) < 3:
            continue

        # 查找表头行（含"序号"和"问题说明"）
        header_idx = -1
        for i, row in enumerate(table):
            row_text = " ".join(row)
            if "序号" in row_text and ("问题说明" in row_text or "部位" in row_text):
                header_idx = i
                break

        if header_idx < 0:
            # 也尝试从表头提取编号和日期
            for row in table[:5]:
                row_text = " ".join(row)
                if "编" in row_text and "号" in row_text:
                    for cell in row:
                        m = re.search(r"ZL-\d+", cell)
                        if m:
                            info["inspection_id"] = m.group(0)
                if "检查日期" in row_text:
                    for cell in row:
                        m = re.search(r"\d{4}.*?\d{1,2}.*?\d{1,2}", cell)
                        if m:
                            info["inspection_date"] = m.group(0)
            continue

        # 提取编号和日期（如果还没找到）
        for row in table[:header_idx]:
            row_text = " ".join(row)
            if not info["inspection_id"]:
                for cell in row:
                    m = re.search(r"ZL-\d+", cell)
                    if m:
                        info["inspection_id"] = m.group(0)
            if not info["inspection_date"]:
                for cell in row:
                    m = re.search(r"\d{4}.*?\d{1,2}.*?\d{1,2}", cell)
                    if m and "检查日期" in row_text:
                        info["inspection_date"] = m.group(0)

        # 解析数据行
        for row in table[header_idx + 1:]:
            if not row or all(not c.strip() for c in row):
                continue
            # 跳过非数据行
            row_text = " ".join(row)
            if any(kw in row_text for kw in ["整改要求", "整改单位", "本次质量联检主要检查项"]):
                # 但"本次质量联检主要检查项"可能包含有用的检查内容
                if "本次质量联检主要检查项" in row_text:
                    for cell in row:
                        cell = cell.strip()
                        if "主要检查项" in cell:
                            # 提取检查内容
                            m = re.search(r"主要检查项[：:]?\s*\n?(.*)", cell, re.DOTALL)
                            if m:
                                info["inspection_content"] = m.group(1).strip()[:500]
                continue

            # 提取序号和问题描述
            seq = ""
            description = ""
            rectification = ""
            location = ""

            for cell in row:
                cell = cell.strip()
                if not cell:
                    continue
                # 序号
                if re.match(r"^\d+$", cell) and not seq:
                    seq = cell
                # 问题描述（含"问题说明"/"部位"的列）
                elif not description and len(cell) > 5 and not re.match(r"^\d+天$", cell):
                    description = cell
                elif not rectification and "天" in cell and len(cell) < 10:
                    rectification = f"整改时限: {cell}"
                elif description and len(cell) > 5 and cell != description:
                    if not rectification:
                        rectification = cell

            if description:
                # 清理描述中的照片占位符
                description = re.sub(r"现场照片|照片\d*|[\d]+区:", "", description).strip()
                if description:
                    info["problems"].append({
                        "seq": int(seq) if seq.isdigit() else len(info["problems"]) + 1,
                        "description": description,
                        "rectification": rectification,
                        "location": _extract_location(description),
                    })

    return info


def _extract_location(text: str) -> str:
    """从问题描述中提取检查部位。"""
    # 匹配类似 "4区34#楼二层顶" "南区车库1-25轴至1-27轴交1-B轴" 等
    patterns = [
        r"(\d+区\d+#楼[^\s,，。；;]*?[层段])",
        r"([东西南北]区[^\s,，。；;]*?轴[^\s,，。；;]*)",
        r"(\d+区[：:][^\s,，。；;]{2,30})",
        r"([^\s,，。；;]{2,20}轴[^\s,，。；;]{0,20}轴)",
        r"(\d+层[^\s,，。；;]{0,10})",
        r"(B\d+层[^\s,，。；;]{0,10})",
    ]
    for pat in patterns:
        m = re.search(pat, text)
        if m:
            return m.group(1)
    return ""


def extract_from_xlsx(filepath: str) -> dict:
    """从 .xlsx 台账文件提取数据。"""
    import pandas as pd

    df = pd.read_excel(filepath, header=None)
    result = {
        "file_path": filepath,
        "doc_type": "ledger",
        "project_name": "",
        "inspection_id": "",
        "inspection_date": "",
        "reply_date": "",
        "problems": [],
        "inspection_content": "",
        "raw_text": "",
        "records": [],
    }

    # 台账通常从第3-4行开始有数据
    for _, row in df.iterrows():
        vals = [str(v).strip() if pd.notna(v) else "" for v in row]
        if vals[0] and re.match(r"(?:质量联检-|ZL-)\d+", vals[0]):
            record = {
                "inspection_id": vals[0],
                "inspection_date": vals[1] if len(vals) > 1 else "",
                "reply_date": vals[2] if len(vals) > 2 else "",
                "department": vals[3] if len(vals) > 3 else "",
            }
            result["records"].append(record)

    result["raw_text"] = "\n".join(
        f"{r['inspection_id']}\t{r['inspection_date']}\t{r['reply_date']}"
        for r in result["records"]
    )
    return result


def extract_document(filepath: str) -> dict:
    """提取单个文档的结构化内容。"""
    filepath = os.path.abspath(filepath)
    if not os.path.isfile(filepath):
        return {"file_path": filepath, "doc_type": "unknown", "error": "File not found"}

    ext = Path(filepath).suffix.lower()

    if ext == ".docx":
        return extract_from_docx(filepath)
    elif ext == ".xlsx":
        return extract_from_xlsx(filepath)
    elif ext == ".doc":
        # 尝试判断是否为 ZIP(docx) 格式
        with open(filepath, "rb") as f:
            header = f.read(4)
        if header[:2] == b"PK":
            return extract_from_docx(filepath)
        else:
            return {
                "file_path": filepath,
                "doc_type": identify_doc_type(filepath),
                "error": "OLE2 .doc file, needs conversion first. Run convert_doc_to_docx.py",
            }
    elif ext == ".pdf":
        return {
            "file_path": filepath,
            "doc_type": "scanned_pdf",
            "error": "Scanned PDF, no extractable text. Use corresponding .doc/.docx file instead.",
        }
    else:
        return {"file_path": filepath, "doc_type": "unknown", "error": f"Unsupported format: {ext}"}


def batch_extract(source_dir: str, output_dir: str = None) -> list:
    """批量提取目录下所有可读文档。"""
    results = []
    converted_dir = os.path.join(source_dir, ".workbuddy", "temp", "converted_docx")

    # 扫描所有 .docx 文件（原始 + 转换后的）
    docx_dirs = [source_dir]
    if os.path.isdir(converted_dir):
        docx_dirs.append(converted_dir)

    for scan_dir in docx_dirs:
        for root, _, files in os.walk(scan_dir):
            if ".workbuddy" in root and "converted_docx" not in root:
                continue
            for f in files:
                fp = os.path.join(root, f)
                ext = f.lower().split(".")[-1]
                if ext in ("docx", "xlsx"):
                    print(f"  提取: {os.path.relpath(fp, source_dir)} ... ", end="", flush=True)
                    r = extract_document(fp)
                    status = "OK" if "error" not in r else r["error"][:50]
                    problems_count = len(r.get("problems", []))
                    print(f"{status} ({problems_count} problems)")
                    results.append(r)
                elif ext == "doc":
                    # 跳过 OLE2 .doc（需先转换）
                    with open(fp, "rb") as fh:
                        header = fh.read(4)
                    if header[:2] == b"PK":
                        print(f"  提取: {os.path.relpath(fp, source_dir)} (ZIP/docx) ... ", end="", flush=True)
                        r = extract_document(fp)
                        print("OK")
                        results.append(r)

    # 保存结果
    if output_dir:
        os.makedirs(output_dir, exist_ok=True)
        out_path = os.path.join(output_dir, "extraction_results.json")
        with open(out_path, "w", encoding="utf-8") as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"\n结果已保存: {out_path}")

    return results


def main():
    parser = argparse.ArgumentParser(description="从质量检验记录文档提取结构化内容")
    parser.add_argument("file_path", nargs="?", help="单个文件路径")
    parser.add_argument("--batch", metavar="SOURCE_DIR", help="批量提取目录")
    parser.add_argument("--output", help="输出 JSON 文件路径")
    parser.add_argument("--output-dir", help="批量模式输出目录")
    args = parser.parse_args()

    if args.batch:
        results = batch_extract(args.batch, args.output_dir)
        print(f"\n提取完成: {len(results)} 个文件")
    elif args.file_path:
        result = extract_document(args.file_path)
        output = json.dumps(result, ensure_ascii=False, indent=2)
        if args.output:
            with open(args.output, "w", encoding="utf-8") as f:
                f.write(output)
            print(f"结果已保存: {args.output}")
        else:
            print(output)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
