#!/usr/bin/env python3
"""自动配对"检查问题"文件与"整改回复"文件。

用法:
    python pair_documents.py <source_dir> [--output <json_path>]

配对策略:
    - 质量联检: 通过子目录编号配对（质量联检-XXX/ 含记录+回复）
    - 每月检查: 通过文件名模式配对（YYYY.MM JD第XXX号 检查问题 ↔ 整改回复）
    - 建委检查: 通过日期配对（YYYY.MM.DD质监站检查问题 ↔ 监督执法记录整改回复(YYYY.MM.DD)）

输出:
    JSON 数组，每个元素包含 problem_file, reply_file, source_type, inspection_id
"""

import argparse
import json
import os
import re
import sys
from pathlib import Path


def pair_quality_inspections(base_dir: str) -> list:
    """配对质量联检子目录中的检查记录和回复。"""
    pairs = []
    qi_dir = os.path.join(base_dir, "2、监理组织质量联检记录")
    if not os.path.isdir(qi_dir):
        return pairs

    for entry in sorted(os.listdir(qi_dir)):
        entry_path = os.path.join(qi_dir, entry)
        if not os.path.isdir(entry_path):
            continue

        m = re.search(r"质量联检-(\d+)", entry)
        if not m:
            continue
        seq = m.group(1).zfill(3)

        # 查找子目录中的文件
        problem_file = None
        reply_file = None
        for f in os.listdir(entry_path):
            fp = os.path.join(entry_path, f)
            fl = f.lower()
            if "回复" in f:
                reply_file = fp
            elif fl.endswith(".pdf") or (fl.endswith(".doc") and "回复" not in f):
                problem_file = fp

        # 也查找独立目录外的 ZL-XXX 文件
        inspection_id = f"ZL-{seq}"

        pairs.append({
            "source_type": "quality_inspection",
            "inspection_id": inspection_id,
            "problem_file": problem_file or "",
            "reply_file": reply_file or "",
            "pairing_method": "subdirectory_number",
        })

    # 查找根目录下的 ZL-XXX .doc 文件
    for f in sorted(os.listdir(qi_dir)):
        fp = os.path.join(qi_dir, f)
        if not os.path.isfile(fp):
            continue
        m = re.match(r"ZL-(\d+)", f)
        if not m:
            continue
        seq = m.group(1).zfill(3)
        inspection_id = f"ZL-{seq}"

        # 检查是否已有配对
        existing = [p for p in pairs if p["inspection_id"] == inspection_id]
        if existing and not existing[0]["problem_file"]:
            existing[0]["problem_file"] = fp
        elif not existing:
            pairs.append({
                "source_type": "quality_inspection",
                "inspection_id": inspection_id,
                "problem_file": fp,
                "reply_file": "",
                "pairing_method": "filename_pattern",
            })

    return pairs


def pair_monthly_inspections(base_dir: str) -> list:
    """配对每月质监站检查问题和整改回复。"""
    pairs = []
    mi_dir = os.path.join(base_dir, "每月检查记录")
    if not os.path.isdir(mi_dir):
        return pairs

    # 按编号分组
    id_groups = {}
    for f in sorted(os.listdir(mi_dir)):
        fp = os.path.join(mi_dir, f)
        if not os.path.isfile(fp):
            continue

        # 提取编号 JD第XXX号
        m = re.search(r"JD第(\d+)号", f)
        if not m:
            continue
        jd_num = m.group(1).zfill(3)
        inspection_id = f"JD第{m.group(1)}号"

        is_problem = "检查问题" in f and "整改" not in f
        is_reply = "整改回复" in f

        if jd_num not in id_groups:
            id_groups[jd_num] = {"inspection_id": inspection_id, "problem": "", "reply": ""}

        if is_problem:
            id_groups[jd_num]["problem"] = fp
        elif is_reply:
            id_groups[jd_num]["reply"] = fp

    for jd_num, group in sorted(id_groups.items()):
        pairs.append({
            "source_type": "monthly_inspection",
            "inspection_id": group["inspection_id"],
            "problem_file": group["problem"],
            "reply_file": group["reply"],
            "pairing_method": "filename_jd_number",
        })

    return pairs


def pair_jianwei_inspections(base_dir: str) -> list:
    """配对三标建委检查问题和整改回复。"""
    pairs = []
    jw_dir = os.path.join(base_dir, "三标建委检查记录及回复")
    if not os.path.isdir(jw_dir):
        return pairs

    # 按日期分组
    date_groups = {}
    for f in sorted(os.listdir(jw_dir)):
        fp = os.path.join(jw_dir, f)
        if not os.path.isfile(fp):
            continue

        # 提取日期
        m = re.search(r"(\d{4}\.\d{2}\.\d{2})", f)
        if not m:
            continue
        date_str = m.group(1)

        is_problem = "检查问题" in f
        is_reply = "整改回复" in f

        if date_str not in date_groups:
            date_groups[date_str] = {"date": date_str, "problem": "", "reply": ""}

        if is_problem:
            date_groups[date_str]["problem"] = fp
        elif is_reply:
            date_groups[date_str]["reply"] = fp

    for date_str, group in sorted(date_groups.items()):
        pairs.append({
            "source_type": "jianwei_inspection",
            "inspection_id": f"JW-{date_str}",
            "problem_file": group["problem"],
            "reply_file": group["reply"],
            "pairing_method": "filename_date",
        })

    return pairs


def resolve_file_paths(pairs: list, converted_dir: str) -> list:
    """将 OLE2 .doc 路径替换为转换后的 .docx 路径（如存在）。"""
    if not os.path.isdir(converted_dir):
        return pairs

    converted_files = {}
    for f in os.listdir(converted_dir):
        if f.lower().endswith(".docx"):
            converted_files[Path(f).stem.lower()] = os.path.join(converted_dir, f)

    for pair in pairs:
        for key in ("problem_file", "reply_file"):
            fp = pair.get(key, "")
            if not fp or not os.path.isfile(fp):
                # 尝试从转换目录查找
                stem = Path(fp).stem.lower() if fp else ""
                # 也尝试用 inspection_id 查找
                insp_id = pair.get("inspection_id", "")
                for stem_key in [stem, insp_id.lower().replace("号", "").replace("第", "jd-")]:
                    if stem_key in converted_files:
                        pair[key] = converted_files[stem_key]
                        break
            elif fp.lower().endswith(".doc"):
                # 检查是否为 OLE2 格式
                with open(fp, "rb") as f:
                    header = f.read(4)
                if header[:4] == b"\xd0\xcf\x11\xe0":
                    stem = Path(fp).stem.lower()
                    if stem in converted_files:
                        pair[key] = converted_files[stem]

        # 如果 problem_file 是扫描版 PDF 且无 .doc 替代，
        # 使用 reply_file（监理回复文件同时包含问题描述和整改措施）
        prob = pair.get("problem_file", "")
        reply = pair.get("reply_file", "")
        if prob.lower().endswith(".pdf") and reply and reply.lower().endswith(".docx"):
            pair["problem_file"] = reply
            pair["note"] = "PDF is scanned, using reply file as problem source"

    return pairs


def main():
    parser = argparse.ArgumentParser(description="配对检查问题与整改回复文件")
    parser.add_argument("source_dir", help="质量检验记录根目录")
    parser.add_argument("--output", help="输出 JSON 文件路径")
    args = parser.parse_args()

    source_dir = os.path.abspath(args.source_dir)
    if not os.path.isdir(source_dir):
        print(f"错误: 目录不存在: {source_dir}", file=sys.stderr)
        sys.exit(1)

    # 执行三种配对
    qi_pairs = pair_quality_inspections(source_dir)
    mi_pairs = pair_monthly_inspections(source_dir)
    jw_pairs = pair_jianwei_inspections(source_dir)

    all_pairs = qi_pairs + mi_pairs + jw_pairs

    # 解析转换后的文件路径
    converted_dir = os.path.join(source_dir, ".workbuddy", "temp", "converted_docx")
    all_pairs = resolve_file_paths(all_pairs, converted_dir)

    # 统计
    total = len(all_pairs)
    full_pairs = sum(1 for p in all_pairs if p["problem_file"] and p["reply_file"])
    problem_only = sum(1 for p in all_pairs if p["problem_file"] and not p["reply_file"])
    reply_only = sum(1 for p in all_pairs if not p["problem_file"] and p["reply_file"])
    no_file = sum(1 for p in all_pairs if not p["problem_file"] and not p["reply_file"])

    print(f"配对结果: 总计 {total} 对")
    print(f"  完整配对（问题+回复）: {full_pairs}")
    print(f"  仅有问题: {problem_only}")
    print(f"  仅有回复: {reply_only}")
    print(f"  无文件: {no_file}")
    print(f"\n分类统计:")
    print(f"  质量联检: {len(qi_pairs)}")
    print(f"  每月检查: {len(mi_pairs)}")
    print(f"  建委检查: {len(jw_pairs)}")

    # 输出
    output_path = args.output
    if not output_path:
        output_path = os.path.join(source_dir, ".workbuddy", "temp", "document_pairs.json")

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(all_pairs, f, ensure_ascii=False, indent=2)
    print(f"\n配对结果已保存: {output_path}")


if __name__ == "__main__":
    main()
