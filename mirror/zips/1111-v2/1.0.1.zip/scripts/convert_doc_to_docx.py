#!/usr/bin/env python3
"""批量将 OLE2 格式 .doc 文件转换为 .docx 格式。

用法:
    python convert_doc_to_docx.py <source_dir> [--output-dir <dir>] [--dry-run] [--method auto|wordcom|libreoffice]

功能:
    - 递归扫描 source_dir 下所有 .doc 文件
    - 检测文件头：OLE2(d0cf11e0) 需转换，ZIP(504b) 跳过
    - 优先使用 Microsoft Word COM (Windows) 转换，备选 LibreOffice headless
    - 支持增量处理：已转换的文件不重复处理
    - 转换结果保存到 output-dir（默认 <source_dir>/.workbuddy/temp/converted_docx/）

转换方法:
    - wordcom: 使用 Microsoft Word COM 接口（Windows 上推荐，需安装 pywin32 + Microsoft Word）
    - libreoffice: 使用 LibreOffice headless 模式（跨平台，需安装 LibreOffice）
    - auto: 自动检测，优先 Word COM，备选 LibreOffice
"""

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path


def detect_format(filepath: str) -> str:
    """检测 .doc 文件的实际格式。"""
    with open(filepath, "rb") as f:
        header = f.read(4)
    if header[:4] == b"\xd0\xcf\x11\xe0":
        return "ole2"
    elif header[:2] == b"PK":
        return "zip_docx"
    else:
        return "unknown"


# ── Word COM 方法 ──────────────────────────────────────────

def check_word_com_available() -> bool:
    """检查 Word COM 是否可用。"""
    try:
        import win32com.client
        word = win32com.client.Dispatch("Word.Application")
        word.Quit()
        return True
    except Exception:
        return False


def convert_with_wordcom(ole2_files: list, output_dir: str, source_dir: str) -> list:
    """使用 Microsoft Word COM 批量转换 OLE2 .doc 文件。"""
    import win32com.client

    results = []
    word = None
    try:
        word = win32com.client.Dispatch("Word.Application")
        word.Visible = False
        # 禁用警告弹窗
        word.DisplayAlerts = 0  # wdAlertsNone

        for i, fp in enumerate(ole2_files, 1):
            rel = os.path.relpath(fp, source_dir)
            result = {
                "input": str(fp),
                "output": None,
                "status": "pending",
                "error": None,
                "duration_sec": 0,
            }
            start = time.time()
            try:
                out_name = Path(fp).stem + ".docx"
                out_path = os.path.join(output_dir, out_name)

                # 如果已存在则跳过
                if os.path.isfile(out_path):
                    result["output"] = out_path
                    result["status"] = "skipped"
                    result["duration_sec"] = round(time.time() - start, 1)
                    results.append(result)
                    print(f"  [{i}/{len(ole2_files)}] 跳过(已存在): {rel}")
                    continue

                doc = word.Documents.Open(fp)
                # wdFormatXMLDocument = 12
                doc.SaveAs2(out_path, FileFormat=12)
                doc.Close()

                elapsed = time.time() - start
                result["output"] = out_path
                result["status"] = "success"
                result["duration_sec"] = round(elapsed, 1)
                print(f"  [{i}/{len(ole2_files)}] 完成 ({elapsed:.1f}s): {rel}")
            except Exception as e:
                elapsed = time.time() - start
                result["status"] = "error"
                result["error"] = str(e)[:500]
                result["duration_sec"] = round(elapsed, 1)
                print(f"  [{i}/{len(ole2_files)}] 失败: {rel} - {str(e)[:100]}")
                # 尝试关闭可能残留的文档
                try:
                    word.Documents.Close()
                except Exception:
                    pass
            results.append(result)
    except Exception as e:
        print(f"Word COM 初始化失败: {e}", file=sys.stderr)
        # 标记所有未处理的文件为错误
        for r in results:
            if r["status"] == "pending":
                r["status"] = "error"
                r["error"] = f"Word COM failed: {str(e)[:200]}"
        for fp in ole2_files[len(results):]:
            results.append({
                "input": str(fp),
                "output": None,
                "status": "error",
                "error": f"Word COM failed: {str(e)[:200]}",
                "duration_sec": 0,
            })
    finally:
        if word:
            try:
                word.Quit()
            except Exception:
                pass
    return results


# ── LibreOffice 方法 ──────────────────────────────────────

def find_libreoffice() -> str:
    """查找系统中的 LibreOffice 可执行文件。"""
    candidates = [
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
        "/usr/bin/libreoffice",
        "/usr/bin/soffice",
        "/Applications/LibreOffice.app/Contents/MacOS/soffice",
    ]
    for path in candidates:
        if os.path.isfile(path):
            return path
    try:
        result = subprocess.run(
            ["where" if sys.platform == "win32" else "which", "soffice"],
            capture_output=True, text=True, timeout=5
        )
        if result.returncode == 0 and result.stdout.strip():
            return result.stdout.strip().split("\n")[0]
    except Exception:
        pass
    return ""


def convert_with_libreoffice(soffice: str, ole2_files: list, output_dir: str, source_dir: str) -> list:
    """使用 LibreOffice headless 模式逐个转换 OLE2 .doc 文件。"""
    results = []
    for i, fp in enumerate(ole2_files, 1):
        rel = os.path.relpath(fp, source_dir)
        result = {
            "input": str(fp),
            "output": None,
            "status": "pending",
            "error": None,
            "duration_sec": 0,
        }
        start = time.time()
        try:
            out_name = Path(fp).stem + ".docx"
            out_path = os.path.join(output_dir, out_name)

            # 如果已存在则跳过
            if os.path.isfile(out_path):
                result["output"] = out_path
                result["status"] = "skipped"
                result["duration_sec"] = round(time.time() - start, 1)
                results.append(result)
                print(f"  [{i}/{len(ole2_files)}] 跳过(已存在): {rel}")
                continue

            cmd = [soffice, "--headless", "--convert-to", "docx", "--outdir", output_dir, str(fp)]
            proc = subprocess.run(
                cmd, capture_output=True, text=True, timeout=300, encoding="utf-8", errors="replace"
            )
            elapsed = time.time() - start
            result["duration_sec"] = round(elapsed, 1)

            if proc.returncode == 0 and os.path.isfile(out_path):
                result["output"] = out_path
                result["status"] = "success"
                print(f"  [{i}/{len(ole2_files)}] 完成 ({elapsed:.1f}s): {rel}")
            else:
                result["status"] = "error"
                result["error"] = (proc.stderr or proc.stdout)[:500]
                print(f"  [{i}/{len(ole2_files)}] 失败: {rel}")
        except subprocess.TimeoutExpired:
            result["status"] = "error"
            result["error"] = "Timeout (>300s)"
            result["duration_sec"] = round(time.time() - start, 1)
            print(f"  [{i}/{len(ole2_files)}] 超时: {rel}")
        except Exception as e:
            result["status"] = "error"
            result["error"] = str(e)[:500]
            result["duration_sec"] = round(time.time() - start, 1)
            print(f"  [{i}/{len(ole2_files)}] 异常: {rel} - {str(e)[:100]}")
        results.append(result)
    return results


# ── 主流程 ────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="批量转换 OLE2 .doc → .docx")
    parser.add_argument("source_dir", help="包含 .doc 文件的根目录")
    parser.add_argument("--output-dir", help="转换后 .docx 输出目录（默认 source_dir/.workbuddy/temp/converted_docx/）")
    parser.add_argument("--dry-run", action="store_true", help="仅检测，不执行转换")
    parser.add_argument("--method", choices=["auto", "wordcom", "libreoffice"], default="auto",
                        help="转换方法：auto(自动检测)|wordcom|libreoffice")
    parser.add_argument("--json", action="store_true", help="以 JSON 格式输出结果")
    args = parser.parse_args()

    source_dir = os.path.abspath(args.source_dir)
    if not os.path.isdir(source_dir):
        print(f"错误: 目录不存在: {source_dir}", file=sys.stderr)
        sys.exit(1)

    output_dir = args.output_dir or os.path.join(source_dir, ".workbuddy", "temp", "converted_docx")

    # 1. 扫描所有 .doc 文件
    doc_files = []
    for root, _, files in os.walk(source_dir):
        if ".workbuddy" in root:
            continue
        for f in files:
            if f.lower().endswith(".doc"):
                doc_files.append(os.path.join(root, f))

    # 2. 分类
    ole2_files = []
    zip_files = []
    unknown_files = []
    for fp in doc_files:
        fmt = detect_format(fp)
        if fmt == "ole2":
            ole2_files.append(fp)
        elif fmt == "zip_docx":
            zip_files.append(fp)
        else:
            unknown_files.append(fp)

    print(f"扫描完成: {len(doc_files)} 个 .doc 文件")
    print(f"  OLE2 (需转换): {len(ole2_files)}")
    print(f"  ZIP/DOCX (跳过): {len(zip_files)}")
    print(f"  未知格式: {len(unknown_files)}")

    if args.dry_run:
        summary = {
            "total": len(doc_files),
            "ole2_need_convert": len(ole2_files),
            "zip_skip": len(zip_files),
            "unknown": len(unknown_files),
            "ole2_files": [os.path.relpath(fp, source_dir) for fp in ole2_files],
        }
        if args.json:
            print(json.dumps(summary, ensure_ascii=False, indent=2))
        else:
            for fp in ole2_files:
                rel = os.path.relpath(fp, source_dir)
                print(f"  [OLE2] {rel}")
        return

    if not ole2_files:
        print("无需转换的文件。")
        return

    # 3. 确定转换方法
    method = args.method
    use_wordcom = False
    use_libreoffice = False

    if method == "auto":
        if sys.platform == "win32" and check_word_com_available():
            use_wordcom = True
            print("自动选择: Microsoft Word COM")
        else:
            soffice = find_libreoffice()
            if soffice:
                use_libreoffice = True
                print(f"自动选择: LibreOffice ({soffice})")
            else:
                print("错误: 未找到可用的转换工具（需安装 Microsoft Word 或 LibreOffice）", file=sys.stderr)
                sys.exit(1)
    elif method == "wordcom":
        if not check_word_com_available():
            print("错误: Word COM 不可用（需安装 pywin32 和 Microsoft Word）", file=sys.stderr)
            sys.exit(1)
        use_wordcom = True
        print("使用: Microsoft Word COM")
    elif method == "libreoffice":
        soffice = find_libreoffice()
        if not soffice:
            print("错误: 未找到 LibreOffice", file=sys.stderr)
            sys.exit(1)
        use_libreoffice = True
        print(f"使用: LibreOffice ({soffice})")

    # 4. 创建输出目录
    os.makedirs(output_dir, exist_ok=True)

    # 5. 增量处理：跳过已转换的文件
    already_converted = set()
    if os.path.isdir(output_dir):
        for f in os.listdir(output_dir):
            if f.lower().endswith(".docx"):
                already_converted.add(Path(f).stem.lower())

    to_convert = []
    for fp in ole2_files:
        stem = Path(fp).stem.lower()
        if stem in already_converted:
            continue
        to_convert.append(fp)

    skipped = len(ole2_files) - len(to_convert)
    if not to_convert:
        print(f"所有文件已转换，无需重复处理（跳过 {skipped} 个）。")
        return

    print(f"待转换: {len(to_convert)} 个文件（跳过 {skipped} 个已转换）")

    # 6. 执行转换
    if use_wordcom:
        results = convert_with_wordcom(to_convert, output_dir, source_dir)
    else:
        results = convert_with_libreoffice(soffice, to_convert, output_dir, source_dir)

    # 7. 输出汇总
    success_count = sum(1 for r in results if r["status"] == "success")
    skipped_count = sum(1 for r in results if r["status"] == "skipped")
    error_count = sum(1 for r in results if r["status"] == "error")

    print(f"\n转换完成: 成功 {success_count}, 跳过 {skipped_count}, 失败 {error_count}")

    if error_count > 0:
        print("\n失败文件:")
        for r in results:
            if r["status"] == "error":
                rel = os.path.relpath(r["input"], source_dir) if r["input"] else "?"
                print(f"  {rel}: {r['error'][:150]}")

    if args.json:
        report = {
            "method": "wordcom" if use_wordcom else "libreoffice",
            "total": len(ole2_files),
            "converted": success_count,
            "skipped": skipped_count,
            "errors": error_count,
            "output_dir": output_dir,
            "results": results,
        }
        report_path = os.path.join(output_dir, "conversion_report.json")
        with open(report_path, "w", encoding="utf-8") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        print(f"详细报告已保存: {report_path}")


if __name__ == "__main__":
    main()
