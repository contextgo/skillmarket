import os, re, sys, shutil, subprocess, zipfile

def fix_image_captions(docx_path):
    """Fix image caption paragraphs: center align, smaller font, no italic."""
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Pt

    doc = Document(docx_path)
    count = 0

    for p in doc.paragraphs:
        text = p.text.strip()
        if re.match(r'^image\d+$', text):
            p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
            for run in p.runs:
                run.font.size = Pt(8)
                run.font.italic = False
                run.font.bold = False
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.space_after = Pt(4)
            count += 1

    doc.save(docx_path)
    return count

def md_to_docx(md_path, docx_path, ref_docx=None, fix_captions=True):
    """
    Convert markdown to docx using pandoc.
    - Embeds images from ./img/ directory
    - Preserves headings, tables, bold/italic formatting
    - Optionally uses a reference docx for styling
    - Fixes image captions: center aligned, 8pt, no italic
    """
    cmd_parts = ['pandoc', md_path, '-o', docx_path]
    if ref_docx and os.path.exists(ref_docx):
        cmd_parts.extend(['--reference-doc', ref_docx])

    result = subprocess.run(cmd_parts, capture_output=True, text=True)

    if result.returncode != 0:
        print(f"Pandoc error: {result.stderr}")
        return False

    # Verify images were embedded
    with zipfile.ZipFile(docx_path, 'r') as z:
        images = [f for f in z.namelist() if 'word/media/' in f]

    caption_count = 0
    if fix_captions:
        caption_count = fix_image_captions(docx_path)

    print(f"Converted {md_path} -> {docx_path}")
    print(f"  Embedded images: {len(images)}")
    if fix_captions:
        print(f"  Fixed {caption_count} image captions (centered, 8pt, no italic)")
    return True

if __name__ == '__main__':
    md_file = sys.argv[1] if len(sys.argv) > 1 else 'input.md'
    docx_file = sys.argv[2] if len(sys.argv) > 2 else 'output.docx'
    ref = sys.argv[3] if len(sys.argv) > 3 else None
    md_to_docx(md_file, docx_file, ref)
