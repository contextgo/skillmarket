from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Pt
from docx.oxml.ns import qn
import re, sys

def fix_image_captions(docx_path):
    doc = Document(docx_path)
    count = 0
    
    for p in doc.paragraphs:
        text = p.text.strip()
        if re.match(r'^image\d+$', text):
            # Center align
            p.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
            
            # Set smaller font size (8pt) for all runs
            for run in p.runs:
                run.font.size = Pt(8)
                run.font.italic = False
                run.font.bold = False
            
            # Add spacing
            p.paragraph_format.space_before = Pt(2)
            p.paragraph_format.space_after = Pt(4)
            count += 1
    
    doc.save(docx_path)
    print(f"Fixed {count} image caption paragraphs")

if __name__ == '__main__':
    docx_file = sys.argv[1] if len(sys.argv) > 1 else 'output.docx'
    fix_image_captions(docx_file)
