import os, re, sys, shutil

def fix_images_for_docx(md_path):
    """
    Ensure all image paths in markdown are relative and resolve correctly
    before pandoc conversion. Pandoc resolves paths relative to the md file.
    """
    with open(md_path, 'r', encoding='utf-8') as f:
        content = f.read()

    issues = []
    
    # Find all image references
    img_refs = re.findall(r'!\[([^\]]*)\]\(([^)]+)\)', content)
    
    for alt, src in img_refs:
        if not os.path.exists(src):
            issues.append(f"Image not found: {src}")
        elif src.startswith('http'):
            issues.append(f"Remote image (will be downloaded by pandoc): {src}")
    
    if issues:
        print("Image path issues found:")
        for issue in issues:
            print(f"  - {issue}")
    else:
        print(f"All {len(img_refs)} image references resolve correctly.")
    
    return len(issues) == 0

if __name__ == '__main__':
    md_file = sys.argv[1] if len(sys.argv) > 1 else 'input.md'
    fix_images_for_docx(md_file)
