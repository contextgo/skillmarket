# publication-chart-skill

publication-chart-skill is a standalone cross-platform skill for turning research results into **publication-grade scientific figures and tables**.

It is designed for agents running in **Claude Code**, **Codex**, or **OpenCode**, with **`pubfig>=0.3.0`** as the default agent-first JSON CLI figure engine and **`pubtab`** as the default table engine.

The goal is to help an agent choose the right artifact, produce a runnable route, export paper-ready outputs, and review the result against publication-quality expectations.

**Upstream toolchain references**

- **pubfig** — GitHub: <https://github.com/Galaxy-Dawn/pubfig> · PyPI: <https://pypi.org/project/pubfig/> · Examples: <https://github.com/Galaxy-Dawn/pubfig/tree/main/examples>
- **pubtab** — GitHub: <https://github.com/Galaxy-Dawn/pubtab> · PyPI: <https://pypi.org/project/pubtab/> · Examples: <https://github.com/Galaxy-Dawn/pubtab/tree/main/examples>

## How it works

<p align="center">
  <a href="https://github.com/Galaxy-Dawn/pubfig/blob/main/examples/bar_scatter.png"><img src="https://raw.githubusercontent.com/Galaxy-Dawn/pubfig/main/examples/bar_scatter.png" width="32%" alt="pubfig bar scatter example"></a>
  <a href="https://github.com/Galaxy-Dawn/pubfig/blob/main/examples/forest_plot.png"><img src="https://raw.githubusercontent.com/Galaxy-Dawn/pubfig/main/examples/forest_plot.png" width="32%" alt="pubfig forest plot example"></a>
  <a href="https://github.com/Galaxy-Dawn/pubfig/blob/main/examples/heatmap.png"><img src="https://raw.githubusercontent.com/Galaxy-Dawn/pubfig/main/examples/heatmap.png" width="32%" alt="pubfig heatmap example"></a>
</p>
<p align="center">
  <a href="https://github.com/Galaxy-Dawn/pubtab/blob/main/examples/table4.xlsx"><img src="https://raw.githubusercontent.com/Galaxy-Dawn/pubtab/main/examples/table4.png" width="32%" alt="pubtab table4 example"></a>
  <a href="https://github.com/Galaxy-Dawn/pubtab/blob/main/examples/table7.xlsx"><img src="https://raw.githubusercontent.com/Galaxy-Dawn/pubtab/main/examples/table7.png" width="32%" alt="pubtab table7 example"></a>
  <a href="https://github.com/Galaxy-Dawn/pubtab/blob/main/examples/table10.xlsx"><img src="https://raw.githubusercontent.com/Galaxy-Dawn/pubtab/main/examples/table10.png" width="32%" alt="pubtab table10 example"></a>
</p>

When this skill is triggered, the agent should not jump straight into plotting. It should first determine what the user is trying to communicate: a comparison, an ablation, a calibration result, a diagnostic summary, a benchmark table, or a mixed figure-plus-table deliverable.

From there, the skill chooses whether the result should be expressed as:

- a **figure**,
- a **table**,
- or a **figure + companion table**.

Once the representation is clear, the skill routes the request to:

- **`pubfig>=0.3.0` JSON CLI** for figures,
- **`pubtab`** for publication tables,
- or both when the section needs one visual summary and one exact-value artifact.

A strong default response should:

1. recommend the artifact type,
2. recommend the `pubfig` CLI / `pubtab` route,
3. provide the minimum runnable JSON spec plus CLI command,
4. specify the expected export files,
5. run a publication QA pass,
6. suggest targeted revisions if the request or current artifact is weak.

The repository also includes a small helper script, `scripts/ensure_publication_tooling.py`, so the agent can probe whether `pubfig>=0.3.0` and `pubtab` are installed, force-install missing dependencies into the active environment when runnable execution is required, and then continue with the real workflow instead of stopping at generic guidance.

If the environment is missing the required packages, the canonical pip install commands are:

```bash
python -m pip install --upgrade "pubfig>=0.3.0"
python -m pip install --upgrade pubtab
```

When the bundled helper is available, it remains the preferred route:

```bash
python3 scripts/ensure_publication_tooling.py --require pubfig --json
python3 scripts/ensure_publication_tooling.py --require pubtab --json
```

### Quick examples from pubfig and pubtab

A few representative routes from the underlying toolchain:

**pubfig CLI example**

For agents, prefer the JSON CLI introduced in `pubfig 0.3.0`. The skill should install or upgrade to `pubfig>=0.3.0`, validate the spec first, and then render it:

```json
{
  "schema_version": 1,
  "plot": {
    "kind": "line",
    "kwargs": {
      "data": [[0.78, 1.03, 1.15], [0.87, 1.01, 1.04]],
      "series_names": ["Baseline", "Method"]
    }
  },
  "export": {
    "mode": "save_figure",
    "path": "figure1.pdf",
    "spec": "nature",
    "width": "single"
  }
}
```

```bash
pubfig validate-spec figure.spec.json
pubfig render figure.spec.json
```

Related upstream examples:
- <https://github.com/Galaxy-Dawn/pubfig/blob/main/examples/gallery.py>
- <https://github.com/Galaxy-Dawn/pubfig/blob/main/examples/new_plot_showcases.py>
- <https://github.com/Galaxy-Dawn/pubfig/blob/main/examples/figma_workflow_demo.md>

**pubtab example**

```bash
pubtab xlsx2tex table.xlsx -o table.tex
pubtab preview table.tex -o table.png --dpi 300
```

Related upstream examples:
- <https://github.com/Galaxy-Dawn/pubtab/blob/main/examples/table4.xlsx>
- <https://github.com/Galaxy-Dawn/pubtab/blob/main/examples/table7.xlsx>
- <https://github.com/Galaxy-Dawn/pubtab/blob/main/examples/table10.xlsx>

## Installation

This repository is structured as a **single-skill repo** that works with the `skills` CLI.

Install it with:

```bash
npx skills add Galaxy-Dawn/publication-chart-skill
```

To inspect what the repo exposes before installing, run:

```bash
npx skills add Galaxy-Dawn/publication-chart-skill --list
```

If you want the skill installed globally for a specific agent, use the corresponding `skills` CLI flags. See the `skills` CLI documentation for agent-specific options and target paths.

## What's inside

The canonical payload lives directly in the repository root:

- `SKILL.md` — the main skill entrypoint
- `references/` — workflow guidance, recipes, QA guidance, and source-driven docs from `pubfig>=0.3.0` / `pubtab`
- `examples/` — example prompts and expected output shapes
- `scripts/ensure_publication_tooling.py` — environment probe + forced-install helper

The `references/` directory is where the skill explains how to map research communication tasks to concrete `pubfig` JSON CLI and `pubtab` routes. The `examples/` directory shows the expected interpretation style for benchmark figures, ablations, calibration plots, diagnostic figures, publication tables, and mixed figure-plus-table requests.

## Example requests

Typical requests that should trigger this skill include:

- “Make a publication-quality benchmark figure for these results.”
- “Should this ablation be a figure or a table?”
- “Turn this Excel benchmark sheet into a publication-ready LaTeX table.”
- “Review this weak scientific chart and give me a stronger figure/table route.”
- “I need one figure and one companion table for the Results section.”
- “Export a multi-panel paper figure and tell me whether Figma assembly is actually necessary.”
- “Use the `pubfig` CLI to turn these evaluation results into a paper-ready figure.”
- “Use `pubtab` to convert this workbook into a manuscript-ready table.”
