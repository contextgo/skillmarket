# Example 6 — Figure plus companion table for a results section

## Real user prompt

For this results section, I want one summary figure and one companion table: the figure should show the overall trend, and the table should preserve the exact metrics.

## What the skill should decide

- **artifact**: mixed deliverable
- **primary claim**: the reader should get both quick pattern perception and exact benchmark lookup
- **recommended route**: `pubfig>=0.3.0` JSON CLI for the figure + `pubtab` for the table
- **why this split**: one artifact cannot do both jobs well without becoming overloaded
- **what to avoid**: stuffing every number into the figure or forcing the whole section into a table only

## Deliverable contract

The response should give the user:

- one runnable figure spec,
- one workbook-to-table route,
- explicit output files for both artifacts,
- QA that explains the role split.

## Runnable route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-06-mixed

cat > temp/example-06-mixed/results_summary.spec.json <<'JSON'
{
  "schema_version": 1,
  "plot": {
    "kind": "grouped_scatter",
    "kwargs": {
      "data": [
        [[0.76, 0.77, 0.78, 0.79, 0.80], [0.88, 0.90, 0.91, 0.92, 0.94], [0.93, 0.95, 0.96, 0.97, 0.98]],
        [[0.80, 0.82, 0.83, 0.84, 0.85], [0.92, 0.94, 0.95, 0.96, 0.97], [0.99, 1.01, 1.02, 1.03, 1.04]],
        [[0.77, 0.79, 0.80, 0.81, 0.82], [0.90, 0.92, 0.93, 0.94, 0.95], [0.96, 0.98, 0.99, 1.00, 1.01]]
      ],
      "category_names": ["Dataset A", "Dataset B", "Dataset C"],
      "group_names": ["Baseline", "Method A", "Method B"],
      "title": "Overall benchmark pattern",
      "random_seed": 0
    }
  },
  "export": {
    "mode": "batch_export",
    "base_path": "results_summary",
    "formats": ["pdf", "png"],
    "spec": "nature",
    "width": "single",
    "dpi": 300
  }
}
JSON

cd temp/example-06-mixed
MPLBACKEND=Agg pubfig validate-spec results_summary.spec.json
MPLBACKEND=Agg pubfig render results_summary.spec.json
cd ../..

python3 - <<'PY'
from pathlib import Path
from openpyxl import Workbook

out = Path("temp/example-06-mixed")
wb = Workbook()
ws = wb.active
ws.title = "Results"
rows = [
    ["Method", "Dataset A", "Dataset B", "Dataset C", "Average"],
    ["Baseline", 0.770, 0.820, 0.790, 0.793],
    ["Method A", 0.901, 0.941, 0.919, 0.920],
    ["Method B", 0.951, 1.011, 0.981, 0.981],
]
for row in rows:
    ws.append(row)
wb.save(out / "results_table.xlsx")
PY

pubtab xlsx2tex \
  temp/example-06-mixed/results_table.xlsx \
  -o temp/example-06-mixed/results_table_preview.tex \
  --sheet Results

pubtab preview \
  temp/example-06-mixed/results_table_preview.tex \
  -o temp/example-06-mixed/results_table.png \
  --dpi 200

pubtab xlsx2tex \
  temp/example-06-mixed/results_table.xlsx \
  -o temp/example-06-mixed/results_table_final.tex \
  --sheet Results \
  --caption "Exact benchmark metrics for the results section." \
  --label "tab:results-main"
```

## Expected artifacts

Figure:

- `temp/example-06-mixed/results_summary.spec.json`
- `temp/example-06-mixed/results_summary.pdf`
- `temp/example-06-mixed/results_summary.png`

Table:

- `temp/example-06-mixed/results_table.xlsx`
- `temp/example-06-mixed/results_table_preview.tex`
- `temp/example-06-mixed/results_table.png`
- `temp/example-06-mixed/results_table_final.tex`

## Publication QA

- **role separation** — the figure answers “what is the pattern?” and the table answers “what are the exact numbers?”
- **redundancy control** — do not repeat the full table inside the figure
- **section fit** — this is the right route when a Results section needs both quick visual summary and precise lookup
- **stability** — the table can usually remain unchanged even if the figure later becomes part of a larger composite figure

## How to adapt it

- replace the figure runs and workbook values with your real outputs,
- keep figure and table filenames parallel so the section is easy to maintain,
- if the figure grows dense, split panels; if the table grows wide, move some detail to supplement.
