# Example 3 — Calibration diagnostic figure

## Real user prompt

I need a publication-quality evaluation figure showing whether my predicted probabilities are calibrated.

## What the skill should decide

- **artifact**: figure
- **primary claim**: the method is better calibrated than the baseline
- **recommended route**: `pubfig>=0.3.0` JSON CLI with `plot.kind = "calibration"`
- **why this chart**: the scientific question is about calibration behavior, not just ranking quality
- **what to avoid**: replacing calibration with ROC / PR curves unless the claim itself changes

## Deliverable contract

The response should give the user:

- one runnable `calibration.spec.json`,
- validation and render commands,
- exported figure files,
- QA on reference line, bins, and legend readability.

## Runnable route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-03-calibration

cat > temp/example-03-calibration/calibration.spec.json <<'JSON'
{
  "schema_version": 1,
  "plot": {
    "kind": "calibration",
    "kwargs": {
      "y_true": [
        [0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0],
        [0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0]
      ],
      "y_prob": [
        [0.08, 0.64, 0.77, 0.26, 0.88, 0.21, 0.71, 0.84, 0.33, 0.79, 0.91, 0.19],
        [0.14, 0.58, 0.70, 0.31, 0.81, 0.28, 0.66, 0.79, 0.39, 0.73, 0.86, 0.24]
      ],
      "series_names": ["Method", "Baseline"],
      "title": "Probability calibration",
      "show_hist": true
    }
  },
  "export": {
    "mode": "batch_export",
    "base_path": "calibration",
    "formats": ["pdf", "png"],
    "spec": "nature",
    "width": "single",
    "dpi": 300
  }
}
JSON

cd temp/example-03-calibration
MPLBACKEND=Agg pubfig validate-spec calibration.spec.json
MPLBACKEND=Agg pubfig render calibration.spec.json
ls -1 calibration.pdf calibration.png
```

## Expected artifacts

- `temp/example-03-calibration/calibration.spec.json`
- `temp/example-03-calibration/calibration.pdf`
- `temp/example-03-calibration/calibration.png`

## Publication QA

- **diagnostic fit** — the figure answers a calibration question directly
- **reference visibility** — the perfect-calibration line should be easy to interpret
- **legend discipline** — only compare models that belong in the same diagnostic panel
- **bin stability** — if the real dataset is small, discuss whether the chosen binning is stable enough

## How to adapt it

- replace `y_true` and `y_prob` with your actual labels and predicted probabilities,
- add or remove compared models through `series_names`,
- switch to ROC / PR only if the paper’s claim is about discrimination rather than calibration.
