# Example 1 — Benchmark comparison figure

## Real user prompt

Help me make a publication-quality benchmark comparison figure for three datasets. I want the overall improvement pattern to be easy to read, and I need paper-ready export files.

## What the skill should decide

- **artifact**: figure
- **primary claim**: the method improves performance consistently across datasets
- **recommended route**: `pubfig>=0.3.0` JSON CLI with `plot.kind = "bar_scatter"`
- **why this chart**: repeated runs matter here, so the figure should show both central tendency and spread
- **what to avoid**: a plain grouped bar chart that hides variance, or a figure overloaded with exact numeric annotations

## Deliverable contract

The response should give the user:

- one runnable `benchmark.spec.json`,
- `pubfig validate-spec benchmark.spec.json`,
- `pubfig render benchmark.spec.json`,
- explicit output files,
- a short QA note explaining when to add a companion table.

## Runnable route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-01-benchmark

cat > temp/example-01-benchmark/benchmark.spec.json <<'JSON'
{
  "schema_version": 1,
  "plot": {
    "kind": "bar_scatter",
    "kwargs": {
      "data": [
        [[0.73, 0.77, 0.78, 0.80, 0.82, 0.79], [0.90, 0.94, 0.97, 0.99, 1.01, 0.96]],
        [[0.83, 0.87, 0.89, 0.91, 0.90, 0.88], [1.02, 1.05, 1.08, 1.10, 1.12, 1.07]],
        [[0.78, 0.82, 0.84, 0.87, 0.86, 0.83], [0.94, 0.98, 1.00, 1.03, 1.05, 0.99]]
      ],
      "category_names": ["Dataset A", "Dataset B", "Dataset C"],
      "series_names": ["Baseline", "Method"],
      "title": "Benchmark comparison",
      "show_statistics": false,
      "random_seed": 0
    }
  },
  "export": {
    "mode": "batch_export",
    "base_path": "benchmark",
    "formats": ["pdf", "png"],
    "spec": "nature",
    "width": "single",
    "dpi": 300
  }
}
JSON

cd temp/example-01-benchmark
MPLBACKEND=Agg pubfig validate-spec benchmark.spec.json
MPLBACKEND=Agg pubfig render benchmark.spec.json
ls -1 benchmark.pdf benchmark.png
```

## Expected artifacts

- `temp/example-01-benchmark/benchmark.spec.json`
- `temp/example-01-benchmark/benchmark.pdf`
- `temp/example-01-benchmark/benchmark.png`

## Publication QA

- **claim fit** — the chart makes cross-dataset improvement easy to perceive
- **spread visibility** — scatter points justify this route over a plain bar chart
- **downscaling** — labels and legend should stay readable at paper size
- **handoff rule** — if exact metrics are important in the same section, pair this figure with a table instead of over-annotating the panel

## How to adapt it

- replace the nested `data` arrays with your real repeated runs,
- reorder `category_names` to match the story you want to tell,
- keep `batch_export` if you need both manuscript and review assets.
