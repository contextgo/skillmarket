# Example 7 — Multi-panel figure export for downstream assembly

## Real user prompt

I need two clean paper panels now and may assemble them later into a multi-panel main figure. Please export the panels cleanly rather than giving me one merged canvas.

## What the skill should decide

- **artifact**: multi-panel figure package
- **primary claim**: the user needs maintainable panels, not a one-off flattened figure
- **recommended route**: `pubfig>=0.3.0` JSON CLI with `export.mode = "export_panels"`
- **why this route**: panel assets should be versionable, reviewable, and reusable in composite assembly
- **what to avoid**: baking early layout decisions into a single monolithic image

## Deliverable contract

The response should give the user:

- one runnable `panels.spec.json`,
- `pubfig validate-spec panels.spec.json`,
- `pubfig render panels.spec.json`,
- a panel directory and `panel-index.json`,
- QA on whether the panels are already clean enough for downstream layout.

## Runnable route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-07-panels

cat > temp/example-07-panels/panels.spec.json <<'JSON'
{
  "schema_version": 1,
  "panels": [
    {
      "panel_id": "a",
      "kind": "bar_scatter",
      "kwargs": {
        "data": [
          [[0.73, 0.77, 0.80], [0.90, 0.94, 0.97]],
          [[0.83, 0.87, 0.90], [1.02, 1.05, 1.08]]
        ],
        "category_names": ["Dataset A", "Dataset B"],
        "series_names": ["Baseline", "Method"],
        "title": "Main benchmark",
        "show_statistics": false,
        "random_seed": 0
      }
    },
    {
      "panel_id": "b",
      "kind": "heatmap",
      "kwargs": {
        "data": [[1.0, 0.32, -0.18], [0.32, 1.0, 0.41], [-0.18, 0.41, 1.0]],
        "category_names": ["Feature 1", "Feature 2", "Feature 3"],
        "title": "Correlation pattern",
        "annotate": true
      }
    }
  ],
  "export": {
    "mode": "export_panels",
    "output_dir": "panels",
    "format": "svg",
    "overwrite": true,
    "index_file": true,
    "spec": "nature",
    "width": "single"
  }
}
JSON

cd temp/example-07-panels
MPLBACKEND=Agg pubfig validate-spec panels.spec.json
MPLBACKEND=Agg pubfig render panels.spec.json
find panels -maxdepth 1 -type f | sort
```

## Expected artifacts

- `temp/example-07-panels/panels.spec.json`
- `temp/example-07-panels/panels/a.svg`
- `temp/example-07-panels/panels/b.svg`
- `temp/example-07-panels/panels/panel-index.json`

## Publication QA

- **panel cleanliness** — each panel should stand on its own without extra layout clutter
- **assembly readiness** — panel assets and metadata should be stable enough for later composite work
- **format discipline** — SVG is appropriate here because the user may still assemble or edit downstream
- **escalation rule** — only move to Figma or another layout tool after the panel content itself is already strong

## How to adapt it

- swap in your own panel kinds and datasets,
- add more `panel_id` entries only when each panel has a distinct role,
- keep panel-first export when you expect iterative composite assembly later.
