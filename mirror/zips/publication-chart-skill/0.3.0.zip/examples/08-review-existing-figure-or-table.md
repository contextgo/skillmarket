# Example 8 — Review and redesign a weak existing deliverable

## Real user prompt

I currently have a weak benchmark figure and a draft table. Please tell me what is wrong, whether the final result should stay figure-only or become a figure + table pair, and give me a concrete revision route.

## What the skill should decide

- **artifact**: review / revision
- **primary claim**: the current deliverable is not strong enough, so the skill should redesign rather than just polish styling
- **recommended route**: split the final result into a cleaner benchmark figure plus a companion exact-value table
- **why this route**: weak chart choice and overloaded presentation should be corrected at the representation level
- **what to avoid**: superficial style edits that preserve a scientifically weak artifact

## What the critique should say

A strong review answer should explicitly call out issues such as:

- the figure makes cross-method comparison harder than it should,
- exact values are buried inside the visual instead of placed in a table,
- the table is not yet manuscript-ready,
- the final deliverable should become a **figure + table pair** rather than trying to force one artifact to do everything.

## Runnable revision route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-08-review

cat > temp/example-08-review/revised_figure.spec.json <<'JSON'
{
  "schema_version": 1,
  "plot": {
    "kind": "grouped_scatter",
    "kwargs": {
      "data": [
        [[0.71, 0.72, 0.74, 0.75], [0.78, 0.79, 0.81, 0.82], [0.84, 0.85, 0.87, 0.88]],
        [[0.67, 0.68, 0.70, 0.71], [0.74, 0.75, 0.77, 0.78], [0.80, 0.81, 0.83, 0.84]],
        [[0.73, 0.74, 0.76, 0.77], [0.80, 0.81, 0.83, 0.84], [0.86, 0.87, 0.89, 0.90]]
      ],
      "category_names": ["Dataset A", "Dataset B", "Dataset C"],
      "group_names": ["Model 1", "Model 2", "Model 3"],
      "title": "Revised benchmark comparison",
      "random_seed": 0
    }
  },
  "export": {
    "mode": "batch_export",
    "base_path": "revised_figure",
    "formats": ["pdf", "png"],
    "spec": "nature",
    "width": "single",
    "dpi": 300
  }
}
JSON

cd temp/example-08-review
MPLBACKEND=Agg pubfig validate-spec revised_figure.spec.json
MPLBACKEND=Agg pubfig render revised_figure.spec.json
cd ../..

python3 - <<'PY'
from pathlib import Path
from openpyxl import Workbook

out = Path("temp/example-08-review")
wb = Workbook()
ws = wb.active
ws.title = "Benchmark"
rows = [
    ["Method", "Dataset A", "Dataset B", "Dataset C", "Average"],
    ["Model 1", 0.731, 0.691, 0.751, 0.724],
    ["Model 2", 0.801, 0.761, 0.821, 0.794],
    ["Model 3", 0.861, 0.821, 0.881, 0.854],
]
for row in rows:
    ws.append(row)
wb.save(out / "revised_table.xlsx")
PY

pubtab xlsx2tex \
  temp/example-08-review/revised_table.xlsx \
  -o temp/example-08-review/revised_table_preview.tex \
  --sheet Benchmark

pubtab preview \
  temp/example-08-review/revised_table_preview.tex \
  -o temp/example-08-review/revised_table.png \
  --dpi 200
```

## Expected artifacts

- `temp/example-08-review/revised_figure.spec.json`
- `temp/example-08-review/revised_figure.pdf`
- `temp/example-08-review/revised_figure.png`
- `temp/example-08-review/revised_table.xlsx`
- `temp/example-08-review/revised_table_preview.tex`
- `temp/example-08-review/revised_table.png`

## Publication QA

- **revision depth** — this is a representation change, not a cosmetic change
- **artifact split** — the figure now communicates pattern; the table now carries exact values
- **readability** — the revised figure should support fast ranking and comparison
- **manuscript readiness** — the table still needs final caption / label before insertion into the paper

## How to adapt it

- start by naming the weaknesses in the current deliverable,
- then decide whether the result should become figure-only, table-only, or figure + table,
- only after that write the revised `pubfig` / `pubtab` route.
