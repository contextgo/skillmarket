# Example 5 — Publication-ready LaTeX table from Excel

## Real user prompt

Convert this benchmark workbook into a publication-ready LaTeX table and give me a preview before I paste it into the paper.

## What the skill should decide

- **artifact**: table
- **primary claim**: exact benchmark values matter more than visual pattern perception
- **recommended route**: `pubtab` preview-first workflow
- **why this route**: this is a manuscript-facing table problem, not a figure problem
- **what to avoid**: directly pasting raw spreadsheet content into the paper without previewing the final table body

## Deliverable contract

The response should give the user:

- a workbook input,
- one preview-first `.tex` export,
- one rendered preview image,
- one final manuscript-facing `.tex` export with caption / label,
- QA on width and table readability.

## Runnable route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-05-table

python3 - <<'PY'
from openpyxl import Workbook

wb = Workbook()
ws = wb.active
ws.title = "Benchmark"

rows = [
    ["Method", "Dataset A", "Dataset B", "Dataset C", "Average"],
    ["Baseline", 0.782, 0.881, 0.842, 0.835],
    ["Method",   0.961, 1.074, 0.998, 1.011],
]

for row in rows:
    ws.append(row)

wb.save("temp/example-05-table/benchmark.xlsx")
PY

pubtab xlsx2tex \
  temp/example-05-table/benchmark.xlsx \
  -o temp/example-05-table/benchmark_preview.tex \
  --sheet Benchmark

pubtab preview \
  temp/example-05-table/benchmark_preview.tex \
  -o temp/example-05-table/benchmark.png \
  --dpi 200

pubtab xlsx2tex \
  temp/example-05-table/benchmark.xlsx \
  -o temp/example-05-table/benchmark_final.tex \
  --sheet Benchmark \
  --caption "Main benchmark results." \
  --label "tab:benchmark"
```

## Expected artifacts

- `temp/example-05-table/benchmark.xlsx`
- `temp/example-05-table/benchmark_preview.tex`
- `temp/example-05-table/benchmark.png`
- `temp/example-05-table/benchmark_final.tex`

## Publication QA

- **artifact fit** — exact values justify a table-first route
- **preview-first check** — the preview image should be reviewed before the table is treated as final
- **manuscript readiness** — caption / label belong in the final export step
- **width risk** — if the table becomes too wide, explicitly switch to resize or span-column handling instead of shrinking blindly

## How to adapt it

- replace the workbook rows with your real benchmark values,
- omit `--sheet` only when you truly want all sheets exported,
- keep preview and final export as separate steps.
