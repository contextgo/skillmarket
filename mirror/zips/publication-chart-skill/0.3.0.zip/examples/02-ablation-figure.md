# Example 2 — Ablation contribution figure

## Real user prompt

Turn these ablation results into a paper-ready figure that makes the contribution of each component easy to read.

## What the skill should decide

- **artifact**: figure
- **primary claim**: each removed component causes a measurable drop relative to the full method
- **recommended route**: `pubfig>=0.3.0` JSON CLI with `plot.kind = "dumbbell"`
- **why this chart**: the key comparison is paired before-vs-after values, not raw category totals
- **what to avoid**: a decorative ablation chart that makes the baseline and delta hard to read

## Deliverable contract

The response should give the user:

- one runnable `ablation.spec.json`,
- validation and render commands,
- explicit paper-ready outputs,
- a QA note on ordering and baseline clarity.

## Runnable route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-02-ablation

cat > temp/example-02-ablation/ablation.spec.json <<'JSON'
{
  "schema_version": 1,
  "plot": {
    "kind": "dumbbell",
    "kwargs": {
      "start": [0.72, 0.81, 0.77, 0.69],
      "end": [0.79, 0.86, 0.83, 0.75],
      "category_names": ["No prompt tuning", "No adapter", "No subject token", "Full model frozen"],
      "left_label": "Ablated",
      "right_label": "Full method",
      "show_delta_labels": true,
      "title": "Ablation contribution by component"
    }
  },
  "export": {
    "mode": "batch_export",
    "base_path": "ablation",
    "formats": ["pdf", "png"],
    "spec": "nature",
    "width": "single",
    "dpi": 300
  }
}
JSON

cd temp/example-02-ablation
MPLBACKEND=Agg pubfig validate-spec ablation.spec.json
MPLBACKEND=Agg pubfig render ablation.spec.json
ls -1 ablation.pdf ablation.png
```

## Expected artifacts

- `temp/example-02-ablation/ablation.spec.json`
- `temp/example-02-ablation/ablation.pdf`
- `temp/example-02-ablation/ablation.png`

## Publication QA

- **baseline clarity** — readers should immediately see what “ablated” is compared against
- **ordering** — components should be ordered by scientific narrative or delta magnitude, not arbitrarily
- **delta readability** — the chart should make effect size obvious without extra prose
- **fallback rule** — if the ablation matrix becomes wide or high-dimensional, move exact values into a companion table

## How to adapt it

- replace `start` / `end` with your actual ablated-vs-full values,
- shorten long component names if the y-axis becomes crowded,
- keep `show_delta_labels` only if the panel still reads cleanly after downscaling.
