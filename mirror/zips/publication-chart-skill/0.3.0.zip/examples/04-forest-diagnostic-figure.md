# Example 4 — Forest plot for effect estimates

## Real user prompt

Help me convert these effect estimates and confidence intervals into a paper-quality figure.

## What the skill should decide

- **artifact**: figure
- **primary claim**: the effect sizes and their uncertainty should be readable at a glance
- **recommended route**: `pubfig>=0.3.0` JSON CLI with `plot.kind = "forest_plot"`
- **why this chart**: the paper needs interval-aware comparison, not just point estimates
- **what to avoid**: a plain bar chart or dense inline text labels that hide uncertainty structure

## Deliverable contract

The response should give the user:

- one runnable `forest.spec.json`,
- validation and render commands,
- explicit outputs,
- QA on reference line, label ordering, and CI readability.

## Runnable route (validated locally)

Run from the repository root:

```bash
mkdir -p temp/example-04-forest

cat > temp/example-04-forest/forest.spec.json <<'JSON'
{
  "schema_version": 1,
  "plot": {
    "kind": "forest_plot",
    "kwargs": {
      "effect": [1.12, 0.84, 1.36, 1.05],
      "ci_low": [0.98, 0.71, 1.10, 0.91],
      "ci_high": [1.29, 0.99, 1.68, 1.20],
      "labels": ["Hospital A", "Hospital B", "Hospital C", "Pooled"],
      "reference": 1.0,
      "title": "Effect estimates with 95% CI"
    }
  },
  "export": {
    "mode": "batch_export",
    "base_path": "forest",
    "formats": ["pdf", "png"],
    "spec": "nature",
    "width": "single",
    "dpi": 300
  }
}
JSON

cd temp/example-04-forest
MPLBACKEND=Agg pubfig validate-spec forest.spec.json
MPLBACKEND=Agg pubfig render forest.spec.json
ls -1 forest.pdf forest.png
```

## Expected artifacts

- `temp/example-04-forest/forest.spec.json`
- `temp/example-04-forest/forest.pdf`
- `temp/example-04-forest/forest.png`

## Publication QA

- **uncertainty fit** — confidence intervals are the main communication target here
- **reference interpretation** — the null/reference line should be immediately legible
- **ordering** — rows should follow cohort or analysis logic, not arbitrary order
- **appendix rule** — if the study has many subgroups, keep the main forest plot selective and move the full numeric table to appendix or supplement

## How to adapt it

- replace `effect`, `ci_low`, and `ci_high` with your real estimates,
- use a pooled row or summary row only if it is scientifically justified,
- keep labels short enough that the forest structure still dominates visually.
