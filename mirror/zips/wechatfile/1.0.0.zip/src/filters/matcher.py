import logging
from typing import Dict, List, Tuple

from src.collectors.models import PolicyItem

logger = logging.getLogger(__name__)


class KeywordFilter:
    def __init__(self, keywords, match_fields, case_sensitive=False):
        self.keywords = keywords
        self.match_fields = match_fields
        self.case_sensitive = case_sensitive

    def matches(self, policy_item: PolicyItem) -> Tuple[bool, List[str]]:
        matched_keywords = []

        for keyword in self.keywords:
            for field_name in self.match_fields:
                text = getattr(policy_item, field_name, "") or ""

                if not self.case_sensitive:
                    if keyword.lower() in text.lower():
                        matched_keywords.append(keyword)
                        break
                else:
                    if keyword in text:
                        matched_keywords.append(keyword)
                        break

        is_match = len(matched_keywords) > 0
        return is_match, matched_keywords

    def filter_all(self, items_dict: Dict[str, List[PolicyItem]]) -> Dict[str, List[Tuple[PolicyItem, List[str]]]]:
        filtered = {}

        for source_name, items in items_dict.items():
            matched_items = []
            for item in items:
                is_match, matched_keywords = self.matches(item)
                if is_match:
                    matched_items.append((item, matched_keywords))
            filtered[source_name] = matched_items

        total_matched = sum(len(v) for v in filtered.values())
        logger.info(f"关键词过滤完成，匹配 {total_matched} 条记录")

        return filtered
