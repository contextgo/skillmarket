import logging
import os

from src.utils.config import load_config

logger = logging.getLogger(__name__)


def load_keywords():
    config_path = os.getenv("KEYWORDS_CONFIG", "config/keywords.yaml")
    logger.info(f"加载关键词配置: {config_path}")

    config = load_config(config_path)

    keywords = config.get("keywords", [])
    match_mode = config.get("match_mode", "any")
    match_fields = config.get("match_fields", ["title", "summary"])
    case_sensitive = config.get("case_sensitive", False)

    logger.info(f"已加载 {len(keywords)} 个关键词, match_mode={match_mode}, match_fields={match_fields}, case_sensitive={case_sensitive}")

    return keywords, match_mode, match_fields, case_sensitive
