import logging
from datetime import datetime
from typing import Dict, List, Tuple

from src.collectors.models import PolicyItem

logger = logging.getLogger(__name__)

DATE_FORMATS = [
    "%Y-%m-%d",
    "%Y/%m/%d",
    "%Y年%m月%d日",
    "%Y-%m-%d %H:%M:%S",
    "%Y/%m/%d %H:%M:%S",
]


def _parse_date(date_str: str):
    if not date_str:
        return None
    for fmt in DATE_FORMATS:
        try:
            return datetime.strptime(date_str.strip(), fmt)
        except ValueError:
            continue
    return None


def sort_results(filtered_dict: Dict[str, List[Tuple[PolicyItem, List[str]]]]) -> Dict[str, List[Tuple[PolicyItem, List[str]]]]:
    sorted_dict = {}

    for source_name, items in filtered_dict.items():
        valid_dates = [item for item in items if _parse_date(item[0].publish_date) is not None]
        invalid_dates = [item for item in items if _parse_date(item[0].publish_date) is None]

        valid_dates.sort(key=lambda x: _parse_date(x[0].publish_date), reverse=True)

        sorted_dict[source_name] = valid_dates + invalid_dates

    logger.info("匹配结果排序完成")
    return sorted_dict


def get_summary(filtered_dict: Dict[str, List[Tuple[PolicyItem, List[str]]]], failed_sources: List[str]) -> dict:
    total_sources = len(filtered_dict) + len(failed_sources)
    matched_count = sum(len(items) for items in filtered_dict.values())
    per_source_count = {source: len(items) for source, items in filtered_dict.items()}

    source_names = list(filtered_dict.keys()) + failed_sources
    coverage = {
        "total_sources": total_sources,
        "matched_sources": len(filtered_dict),
        "failed_sources": len(failed_sources),
        "source_names": source_names,
    }

    summary = {
        "total_matched": matched_count,
        "per_source_count": per_source_count,
        "coverage": coverage,
    }

    if not filtered_dict:
        summary["empty_report"] = "今日暂无相关新政策"

    return summary
