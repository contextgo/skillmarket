import logging
import os
import time

import requests

logger = logging.getLogger(__name__)

WECHAT_MSG_MAX_BYTES = 4096


class WeChatNotifier:

    def __init__(self):
        self.webhook_url = os.getenv("WEBHOOK_URL", "")

    def is_configured(self) -> bool:
        return bool(self.webhook_url)

    def send_report(self, report_content: str, summary: dict):
        if not self.webhook_url:
            logger.warning("WEBHOOK_URL 未配置，跳过微信推送")
            return False, 0, 0

        messages = self._split_content(report_content)
        total = len(messages)
        sent = 0

        for idx, msg in enumerate(messages, 1):
            success = self._send_markdown(msg)
            if success:
                sent += 1
                logger.info(f"微信推送 [{idx}/{total}] 成功")
            else:
                logger.warning(f"微信推送 [{idx}/{total}] 失败")

        return sent == total, sent, total

    def _split_content(self, report_content: str):
        messages = []
        lines = report_content.split("\n")
        current = []

        for line in lines:
            candidate = "\n".join(current + [line])
            if len(candidate.encode("utf-8")) > WECHAT_MSG_MAX_BYTES:
                if current:
                    messages.append("\n".join(current))
                current = [line]
            else:
                current.append(line)

        if current:
            messages.append("\n".join(current))

        return messages

    def _send_markdown(self, content: str, max_retries: int = 3) -> bool:
        last_error = None
        for attempt in range(1, max_retries + 1):
            try:
                payload = {
                    "msgtype": "markdown",
                    "markdown": {
                        "content": content,
                    },
                }
                response = requests.post(
                    self.webhook_url,
                    json=payload,
                    timeout=15,
                )
                result = response.json()
                if result.get("errcode") == 0:
                    return True
                last_error = result
                logger.warning(f"微信推送返回错误 (第{attempt}/{max_retries}次): {last_error}")
            except Exception as e:
                last_error = str(e)
                logger.warning(f"微信推送异常 (第{attempt}/{max_retries}次): {last_error}")
            if attempt < max_retries:
                delay = 2 ** attempt
                time.sleep(delay)
        logger.error(f"微信推送最终失败 (已重试{max_retries}次): {last_error}")
        return False

    def send_text(self, text: str) -> bool:
        if not self.webhook_url:
            return False
        try:
            payload = {
                "msgtype": "text",
                "text": {
                    "content": text,
                },
            }
            response = requests.post(
                self.webhook_url,
                json=payload,
                timeout=15,
            )
            result = response.json()
            return result.get("errcode") == 0
        except Exception as e:
            logger.error(f"微信推送异常: {e}")
            return False
