import logging
import os

logger = logging.getLogger(__name__)


class ReportStorage:

    def __init__(self, output_dir="output"):
        self.output_dir = output_dir
        os.makedirs(self.output_dir, exist_ok=True)

    def save(self, report_content: str, date_str: str) -> str:
        dir_path = os.path.join(self.output_dir, date_str)
        os.makedirs(dir_path, exist_ok=True)

        file_path = os.path.join(dir_path, "report.md")
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(report_content)

        logger.info(f"报告已保存至: {file_path}")
        return file_path

    def get_output_dir(self) -> str:
        from datetime import date
        today = date.today().isoformat()
        return os.path.join(self.output_dir, today)
