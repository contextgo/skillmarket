import logging
from typing import Dict, List, Tuple

from src.collectors.models import PolicyItem

logger = logging.getLogger(__name__)


def generate_summary_stats(results: Dict[str, List[PolicyItem]], filtered_dict: Dict[str, List[Tuple[PolicyItem, List[str]]]], failed_sources: List[str]) -> dict:
    total_collected = sum(len(items) for items in results.values())
    matched_count = sum(len(items) for items in filtered_dict.values())

    success_sources = [name for name, items in results.items() if name not in failed_sources]
    success_count = len(success_sources)

    source_details = {}
    for source_name, items in results.items():
        source_details[source_name] = {
            "collected": len(items),
            "matched": len(filtered_dict.get(source_name, [])),
        }

    stats = {
        "total_collected": total_collected,
        "matched_count": matched_count,
        "success_sources": success_count,
        "failed_sources": list(failed_sources),
        "source_details": source_details,
    }

    logger.info(f"摘要统计: 总采集 {total_collected} 条, 匹配 {matched_count} 条, 成功源 {success_count} 个, 失败源 {len(failed_sources)} 个")
    return stats
