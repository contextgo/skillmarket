import logging
from datetime import datetime
from typing import Dict, List, Tuple

from src.collectors.models import PolicyItem

logger = logging.getLogger(__name__)


class DailyReportGenerator:

    def generate(self, filtered_dict: Dict[str, List[Tuple[PolicyItem, List[str]]]], summary: dict, failed_sources: List[str], date_str: str) -> str:
        matched_count = summary.get("total_matched", 0)
        if matched_count == 0:
            return self._generate_empty_report(date_str, summary, failed_sources)

        return self._generate_full_report(filtered_dict, summary, failed_sources, date_str)

    def _generate_full_report(self, filtered_dict, summary, failed_sources, date_str):
        formatted_date = self._format_date(date_str)
        now = datetime.now().strftime("%H:%M:%S")

        total_sources = summary.get("coverage", {}).get("total_sources", 0)
        success_sources = total_sources - len(failed_sources)
        matched_count = summary.get("total_matched", 0)

        failed_section = ""
        if failed_sources:
            failed_section = f"\n- 采集失败：{'、'.join(failed_sources)}"

        lines = []
        lines.append("# 🔍 数智洞察情报日报")
        lines.append("")
        lines.append(f"**日期**：{formatted_date}")
        lines.append(f"**生成时间**：{now}")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📊 今日概要")
        lines.append("")
        lines.append(f"- 总采集信息源：{total_sources} 个")
        lines.append(f"- 成功采集：{success_sources} 个")
        lines.append(f"- 匹配相关政策：{matched_count} 条")
        lines.append(failed_section)
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📋 政策详情")
        lines.append("")

        for source_name, items in filtered_dict.items():
            match_count = len(items)
            lines.append(f"### 📌 {source_name}（{match_count}条）")
            lines.append("")

            for idx, (item, _matched_keywords) in enumerate(items, 1):
                date_str_item = item.publish_date or "未知日期"
                url_str = item.url or "#"
                summary_text = item.summary or "暂无摘要"

                lines.append(f"{idx}. **{item.title}**")
                lines.append(f"   - 📅 {date_str_item} | [查看原文]({url_str})")
                lines.append(f"   - 📝 {summary_text}")
                lines.append("")

        lines.append("---")
        lines.append("")
        lines.append("> 🤖 本报告由数智洞察情报雷达自动生成")

        return "\n".join(lines)

    def _generate_empty_report(self, date_str, summary, failed_sources):
        formatted_date = self._format_date(date_str)
        now = datetime.now().strftime("%H:%M:%S")

        total_sources = summary.get("coverage", {}).get("total_sources", 0)
        success_sources = total_sources - len(failed_sources)

        lines = []
        lines.append("# 🔍 数智洞察情报日报")
        lines.append("")
        lines.append(f"**日期**：{formatted_date}")
        lines.append(f"**生成时间**：{now}")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📊 今日概要")
        lines.append("")
        lines.append(f"- 总采集信息源：{total_sources} 个")
        lines.append(f"- 成功采集：{success_sources} 个")
        lines.append(f"- 匹配相关政策：0 条")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("## 📋 政策详情")
        lines.append("")
        lines.append("> 今日暂无相关新政策")
        lines.append("")
        lines.append("---")
        lines.append("")
        lines.append("> 🤖 本报告由数智洞察情报雷达自动生成")

        return "\n".join(lines)

    def _format_date(self, date_str: str) -> str:
        if not date_str:
            return date_str
        for fmt in ["%Y-%m-%d", "%Y/%m/%d", "%Y年%m月%d日"]:
            try:
                dt = datetime.strptime(date_str.strip(), fmt)
                return dt.strftime("%Y-%m-%d")
            except ValueError:
                continue
        return date_str
