import logging
from datetime import date
from typing import Dict, List, Tuple

from src.collectors.models import PolicyItem
from src.reporters.template import DailyReportGenerator
from src.reporters.storage import ReportStorage
from src.reporters.cos_storage import COSStorage

logger = logging.getLogger(__name__)


def run_report_pipeline(filtered_dict: Dict[str, List[Tuple[PolicyItem, List[str]]]], summary: dict, results: Dict[str, List[PolicyItem]], failed_sources: List[str]):
    date_str = date.today().isoformat()

    generator = DailyReportGenerator()
    report_content = generator.generate(filtered_dict, summary, failed_sources, date_str)
    logger.info(f"Markdown 日报生成完成，长度: {len(report_content)} 字符")

    storage = ReportStorage()
    local_path = storage.save(report_content, date_str)
    logger.info(f"本地报告已保存: {local_path}")

    cos_storage = COSStorage()
    cos_url = cos_storage.upload(report_content, date_str)

    return report_content, local_path, cos_url
