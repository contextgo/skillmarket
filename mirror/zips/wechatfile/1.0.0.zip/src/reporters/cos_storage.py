import logging
import os

logger = logging.getLogger(__name__)


class COSStorage:

    def __init__(self):
        self.secret_id = os.getenv("TENCENT_COS_SECRET_ID", "")
        self.secret_key = os.getenv("TENCENT_COS_SECRET_KEY", "")
        self.region = os.getenv("TENCENT_COS_REGION", "")
        self.bucket = os.getenv("TENCENT_COS_BUCKET", "")
        self.disabled = not all([self.secret_id, self.secret_key, self.region, self.bucket])

        if self.disabled:
            logger.info("腾讯云 COS 配置不完整，云端存储已禁用")
        else:
            logger.info(f"腾讯云 COS 已配置: region={self.region}, bucket={self.bucket}")

    def is_enabled(self) -> bool:
        return not self.disabled

    def upload(self, report_content: str, date_str: str) -> str:
        if self.disabled:
            logger.info("COS 未启用，跳过上传")
            return ""

        cos_key = f"radar-reports/{date_str}/report.md"

        try:
            from qcloud_cos import CosConfig, CosS3Client

            cos_config = CosConfig(
                Region=self.region,
                SecretId=self.secret_id,
                SecretKey=self.secret_key,
            )
            client = CosS3Client(cos_config)

            response = client.put_object(
                Bucket=self.bucket,
                Key=cos_key,
                Body=report_content.encode("utf-8"),
                ContentType="text/markdown; charset=utf-8",
            )

            cos_url = f"https://{self.bucket}.cos.{self.region}.myqcloud.com/{cos_key}"
            logger.info(f"报告已上传至 COS: {cos_url}")
            return cos_url
        except ImportError:
            logger.warning("qcloud_cos 库未安装，无法上传至腾讯云 COS。请执行: pip install cos-python-sdk-v5")
            return ""
        except Exception as e:
            logger.error(f"上传至 COS 失败: {e}")
            return ""
