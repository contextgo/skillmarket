"""
数智洞察情报雷达 - 主入口
每日自动采集国家及四川省发改委、能源局、数据局、工信部、科技厅、经信厅等
关于人工智能、智能制造等最新政策，生成情报文档并推送微信。
"""
import argparse

from dotenv import load_dotenv

from src.utils.logger import get_logger

load_dotenv()

logger = get_logger("digital-insight-radar")


def run_pipeline():
    from src.collectors.manager import CollectorManager
    from src.filters.keyword_loader import load_keywords
    from src.filters.matcher import KeywordFilter
    from src.filters.sorter import sort_results, get_summary
    from src.reporters.pipeline import run_report_pipeline
    from src.reporters.summary import generate_summary_stats
    from src.notifiers.wechat import WeChatNotifier
    from src.scheduler.tracker import ExecutionTracker

    tracker = ExecutionTracker()
    tracker.record_start()
    logger.info("=== 数智洞察情报雷达启动 ===")

    try:
        logger.info("Step 1/4: 开始采集信息...")
        manager = CollectorManager()
        results, failed_sources = manager.collect_all()
        total_collected = sum(len(items) for items in results.values())
        logger.info(f"采集完成: {manager.get_collection_stats(results)}")

        logger.info("Step 2/4: 开始关键词过滤...")
        keywords, match_mode, match_fields, case_sensitive = load_keywords()
        filter_engine = KeywordFilter(keywords, match_fields, case_sensitive)
        filtered_dict = filter_engine.filter_all(results)
        filtered_dict = sort_results(filtered_dict)
        summary = get_summary(filtered_dict, failed_sources)
        logger.info(f"过滤完成: 匹配 {summary['total_matched']} 条政策")

        logger.info("Step 3/4: 开始生成情报文档...")
        report_content, local_path, cos_url = run_report_pipeline(
            filtered_dict, summary, results, failed_sources
        )
        logger.info(f"报告已保存: {local_path}")

        logger.info("Step 4/4: 开始推送微信...")
        notifier = WeChatNotifier()
        if notifier.is_configured():
            success, sent, total = notifier.send_report(report_content, summary)
            if success:
                logger.info(f"微信推送成功: {sent}/{total} 条消息")
            else:
                logger.warning(f"微信推送部分失败: {sent}/{total} 条消息")
        else:
            logger.warning("微信 Webhook 未配置，跳过推送。请设置 WEBHOOK_URL 环境变量")

        stats = generate_summary_stats(results, filtered_dict, failed_sources)
        tracker.record_success(stats)
        logger.info("=== 数智洞察情报雷达完成 ===")

    except Exception as e:
        logger.error(f"执行失败: {e}", exc_info=True)
        tracker.record_failure(str(e))


def main():
    parser = argparse.ArgumentParser(
        description="数智洞察情报雷达 - 政策情报自动采集与推送系统"
    )
    parser.add_argument(
        "--run-now",
        action="store_true",
        help="手动立即执行一次情报采集与推送",
    )
    parser.add_argument(
        "--schedule",
        action="store_true",
        help="以定时调度模式运行",
    )
    args = parser.parse_args()

    if args.run_now:
        logger.info("手动触发模式：立即执行情报采集")
        run_pipeline()
    elif args.schedule:
        logger.info("定时调度模式启动")
        from src.scheduler.job import DailyJob

        job = DailyJob()
        job.start(run_pipeline)
        try:
            import signal
            import sys

            signal.pause()
        except (KeyboardInterrupt, SystemExit):
            job.stop()
            logger.info("程序已退出")
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
