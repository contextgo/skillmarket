import logging
import time

import requests

logger = logging.getLogger(__name__)


class Fetcher:
    def __init__(self, user_agent, timeout=30, retry=3, retry_delay=5, request_delay=2):
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": user_agent})
        self.timeout = timeout
        self.retry = retry
        self.retry_delay = retry_delay
        self.request_delay = request_delay

    def fetch(self, url):
        last_error = None
        for attempt in range(1, self.retry + 1):
            try:
                logger.debug(f"请求 {url} (第 {attempt}/{self.retry} 次尝试)")
                response = self.session.get(url, timeout=self.timeout)
                response.encoding = response.apparent_encoding
                time.sleep(self.request_delay)
                return response.status_code, response.text
            except requests.RequestException as e:
                last_error = str(e)
                logger.warning(f"请求 {url} 失败 (第 {attempt}/{self.retry} 次): {last_error}")
                if attempt < self.retry:
                    time.sleep(self.retry_delay)

        logger.error(f"请求 {url} 最终失败: {last_error}")
        return None, last_error
