import logging
from urllib.parse import urljoin

from bs4 import BeautifulSoup

from src.collectors.models import PolicyItem

logger = logging.getLogger(__name__)


class SourceParser:
    def __init__(self, fetcher):
        self.fetcher = fetcher

    def parse(self, source_config):
        items = []
        source_name = source_config.get("name", "未知来源")

        try:
            status_code, html = self.fetcher.fetch(source_config["url"])
            if status_code is None:
                logger.error(f"抓取 [{source_name}] 失败: {html}")
                return items

            if status_code != 200:
                logger.warning(f"[{source_name}] 返回状态码 {status_code}")
                return items

            soup = BeautifulSoup(html, "lxml")

            list_selector = source_config.get("list_selector", "")
            if not list_selector:
                logger.warning(f"[{source_name}] 未配置 list_selector")
                return items

            list_items = soup.select(list_selector)
            logger.info(f"[{source_name}] 找到 {len(list_items)} 个条目")

            title_selector = source_config.get("title_selector", "a")
            date_selector = source_config.get("date_selector", "")
            link_selector = source_config.get("link_selector", "a")
            link_prefix = source_config.get("link_prefix", "")

            for item in list_items:
                try:
                    title_el = item.select_one(title_selector)
                    title = title_el.get_text(strip=True) if title_el else ""

                    date_el = item.select_one(date_selector) if date_selector else None
                    publish_date = date_el.get_text(strip=True) if date_el else ""

                    link_el = item.select_one(link_selector)
                    href = link_el.get("href", "") if link_el else ""
                    full_url = urljoin(link_prefix, href) if href and link_prefix else href

                    raw_text = item.get_text(" ", strip=True)

                    policy_item = PolicyItem(
                        title=title,
                        source_name=source_name,
                        publish_date=publish_date,
                        url=full_url,
                        raw_text=raw_text,
                    )
                    items.append(policy_item)
                except Exception as e:
                    logger.warning(f"[{source_name}] 解析条目出错: {e}")

        except Exception as e:
            logger.error(f"[{source_name}] 解析过程异常: {e}")

        return items
