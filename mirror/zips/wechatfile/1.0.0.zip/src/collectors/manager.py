import logging

from src.collectors.fetcher import Fetcher
from src.collectors.parser import SourceParser
from src.utils.config import load_config

logger = logging.getLogger(__name__)


class CollectorManager:
    def __init__(self, config_path="config/sources.yaml"):
        config = load_config(config_path)
        self.sources = config.get("sources", [])
        scrape_settings = config.get("scrape_settings", {})

        self.fetcher = Fetcher(
            user_agent=scrape_settings.get(
                "user_agent",
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
            ),
            timeout=scrape_settings.get("timeout", 30),
            retry=scrape_settings.get("retry", 3),
            retry_delay=scrape_settings.get("retry_delay", 5),
            request_delay=scrape_settings.get("request_delay", 2),
        )

        self.parser = SourceParser(self.fetcher)

    def collect_all(self):
        results = {}
        failed_sources = set()
        total_count = len(self.sources)

        for idx, source_config in enumerate(self.sources, 1):
            source_name = source_config.get("name", f"source_{idx}")
            logger.info(f"正在采集 [{idx}/{total_count}] {source_name} ...")

            try:
                items = self.parser.parse(source_config)
                results[source_name] = items
                logger.info(f"[{source_name}] 采集完成，获取 {len(items)} 条")
                if not items:
                    failed_sources.add(source_name)
            except Exception as e:
                logger.error(f"[{source_name}] 采集失败: {e}")
                results[source_name] = []
                failed_sources.add(source_name)

        logger.info(f"全部采集完成，共处理 {total_count} 个信息源")
        return results, list(failed_sources)

    def get_collection_stats(self, results):
        total_items = sum(len(items) for items in results.values())
        success_sources = [name for name, items in results.items() if items]
        failed_sources = [name for name, items in results.items() if not items]

        stats = {
            "total_items": total_items,
            "source_count": len(results),
            "success_count": len(success_sources),
            "failed_count": len(failed_sources),
            "success_sources": success_sources,
            "failed_sources": failed_sources,
        }
        return stats
