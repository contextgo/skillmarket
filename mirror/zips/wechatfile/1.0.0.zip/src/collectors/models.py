from dataclasses import dataclass


@dataclass
class PolicyItem:
    title: str
    source_name: str
    publish_date: str = ""
    summary: str = ""
    url: str = ""
    raw_text: str = ""

    def to_dict(self):
        return {
            "title": self.title,
            "source_name": self.source_name,
            "publish_date": self.publish_date,
            "summary": self.summary,
            "url": self.url,
            "raw_text": self.raw_text,
        }
