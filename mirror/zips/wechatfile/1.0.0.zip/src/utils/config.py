import os

import yaml


def load_config(config_path: str) -> dict:
    config_file = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), config_path)

    if not os.path.exists(config_file):
        raise FileNotFoundError(f"配置文件不存在: {config_file}")

    with open(config_file, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    return config or {}
