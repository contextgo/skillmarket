import os

from apscheduler.schedulers.background import BackgroundScheduler

from src.utils.logger import get_logger

logger = get_logger("digital-insight-radar.scheduler")


class DailyJob:
    def __init__(self, cron_expr=None):
        if cron_expr is None:
            cron_expr = os.getenv("SCHEDULE_CRON", "0 8 * * *")
        self.cron_expr = cron_expr
        self._scheduler = BackgroundScheduler()
        logger.info("DailyJob 初始化完成，cron 表达式: %s", self.cron_expr)

    def start(self, run_func):
        parts = self.cron_expr.strip().split()
        if len(parts) != 5:
            raise ValueError(f"无效的 cron 表达式: {self.cron_expr}")
        minute, hour, day, month, day_of_week = parts

        self._scheduler.add_job(
            run_func,
            trigger="cron",
            minute=minute,
            hour=hour,
            day=day,
            month=month,
            day_of_week=day_of_week,
            id="radar_daily_job",
            name="数智洞察情报雷达每日任务",
        )
        self._scheduler.start()
        logger.info("定时调度已启动，每日 %s:%s 执行", hour, minute)

    def stop(self):
        self._scheduler.shutdown(wait=False)
        logger.info("定时调度已关闭")
