import json
import os
from datetime import datetime
from typing import Optional

from src.utils.logger import get_logger

logger = get_logger("digital-insight-radar.tracker")

STATUS_FILE = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(__file__))),
    "logs",
    "execution_status.json",
)


class ExecutionTracker:
    def record_start(self):
        status = {
            "status": "running",
            "started_at": datetime.now().isoformat(),
            "finished_at": None,
            "stats": None,
            "error": None,
        }
        self._write(status)
        logger.info("执行状态已记录：运行中")

    def record_success(self, stats: Optional[dict] = None):
        status = self._read()
        status.update({
            "status": "success",
            "finished_at": datetime.now().isoformat(),
            "stats": stats,
            "error": None,
        })
        self._write(status)
        logger.info("执行状态已记录：成功")

    def record_failure(self, error: str):
        status = self._read()
        status.update({
            "status": "failure",
            "finished_at": datetime.now().isoformat(),
            "error": error,
        })
        self._write(status)
        logger.error("执行状态已记录：失败 — %s", error)

    def get_latest_status(self) -> dict:
        return self._read()

    def _read(self) -> dict:
        if not os.path.exists(STATUS_FILE):
            return {}
        with open(STATUS_FILE, "r", encoding="utf-8") as f:
            return json.load(f)

    def _write(self, status: dict):
        os.makedirs(os.path.dirname(STATUS_FILE), exist_ok=True)
        with open(STATUS_FILE, "w", encoding="utf-8") as f:
            json.dump(status, f, ensure_ascii=False, indent=2)
