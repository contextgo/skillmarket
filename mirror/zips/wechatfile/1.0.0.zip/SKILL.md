---
name: "digital-insight-radar"
description: "数智洞察情报雷达 - 每日自动采集国家及四川省发改委、能源局、数据局、工信部、科技厅、经信厅等关于人工智能、智能制造、工业智能、工业互联网、产业互联网、具身智能等最新政策，生成情报文档并推送企业微信"
---

# 数智洞察情报雷达

## 功能概述

每日自动从以下 8 个政府网站采集最新政策公告，按预设关键词过滤匹配，生成 Markdown 情报日报，并通过企业微信机器人推送到指定群聊。

### 信息源覆盖

| 级别 | 信息源 |
|------|--------|
| 国家级 | 国家发改委、国家能源局、国家数据局、工信部、科技部 |
| 四川省 | 四川省科技厅、四川省经信厅、四川省发改委（能源局） |

### 关键词列表

人工智能、智能制造、工业智能、工业互联网、产业互联网、具身智能、智能装备、数字化转型、大模型、算力、数据要素

## 触发方式

- **定时触发**：每日 08:00 自动执行
- **手动触发**：执行 `python src/main.py --run-now`

## 环境变量

| 变量名 | 必填 | 说明 |
|--------|------|------|
| `WEBHOOK_URL` | 是 | 企业微信机器人 Webhook 地址 |
| `TENCENT_COS_SECRET_ID` | 否 | 腾讯云 COS SecretId |
| `TENCENT_COS_SECRET_KEY` | 否 | 腾讯云 COS SecretKey |
| `TENCENT_COS_REGION` | 否 | 腾讯云 COS 地域，默认 ap-guangzhou |
| `TENCENT_COS_BUCKET` | 否 | 腾讯云 COS 存储桶名称 |
| `SCHEDULE_CRON` | 否 | 定时调度 cron 表达式，默认 `0 8 * * *` |
| `LOG_LEVEL` | 否 | 日志级别，默认 `INFO` |

## 执行流程

```
采集 → 过滤 → 生成报告 → 推送微信
  │       │        │           │
  │       │        │           └── 企业微信机器人，支持重试+分片
  │       │        └── Markdown 日报 + 本地存储 + COS 上传
  │       └── 标题+摘要双字段关键词匹配 + 按日期倒序
  └── 8 个政府网站，支持重试 + 频率控制
```

## 输出

- **本地日报**：`output/YYYY-MM-DD/report.md`
- **云端日报**：COS `radar-reports/YYYY-MM-DD/report.md`（需配置 COS 环境变量）
- **微信推送**：企业微信 Markdown 消息卡片

## 部署

### Docker 部署（推荐）

```bash
docker build -t digital-insight-radar .
docker run -d -e WEBHOOK_URL=https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=YOUR_KEY \
  --name digital-insight-radar digital-insight-radar
```

### 直接运行

```bash
pip install -r requirements.txt
cp .env.example .env
# 编辑 .env 填入 WEBHOOK_URL
python src/main.py --schedule   # 定时模式
python src/main.py --run-now    # 立即执行一次
```
