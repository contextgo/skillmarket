import json
import os
import sys
import zipfile

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

EXCLUDE_PATTERNS = [
    "__pycache__",
    ".git",
    "tests",
    "logs",
    "output",
    ".env",
    ".gitignore",
    "*.pyc",
    "*.pyo",
    ".DS_Store",
    "Thumbs.db",
]


def load_skill_json():
    skill_path = os.path.join(PROJECT_ROOT, "skill.json")
    if not os.path.exists(skill_path):
        print(f"错误: 找不到 skill.json 文件 ({skill_path})")
        sys.exit(1)
    with open(skill_path, "r", encoding="utf-8") as f:
        return json.load(f)


def validate_required_files():
    required = ["skill.json", "SKILL.md", "requirements.txt"]
    missing = []
    for f in required:
        path = os.path.join(PROJECT_ROOT, f)
        if not os.path.exists(path):
            missing.append(f)
    if missing:
        print(f"错误: 缺少必要文件: {', '.join(missing)}")
        sys.exit(1)


def should_exclude(name):
    for pattern in EXCLUDE_PATTERNS:
        if pattern.startswith("*."):
            ext = pattern[1:]
            if name.endswith(ext):
                return True
        elif name == pattern:
            return True
    return False


def package():
    validate_required_files()
    skill = load_skill_json()
    name = skill.get("name", "digital-insight-radar")
    version = skill.get("version", "1.0.0")

    zip_filename = f"{name}-v{version}.zip"
    zip_path = os.path.join(PROJECT_ROOT, zip_filename)

    file_count = 0

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(PROJECT_ROOT):
            dirs[:] = [d for d in dirs if not should_exclude(d)]

            rel_root = os.path.relpath(root, PROJECT_ROOT)
            if rel_root == ".":
                rel_root = ""

            for file in files:
                if should_exclude(file):
                    continue
                file_path = os.path.join(root, file)
                arcname = os.path.join(rel_root, file) if rel_root else file
                zf.write(file_path, arcname)
                file_count += 1

    zip_size = os.path.getsize(zip_path)
    zip_size_kb = zip_size / 1024

    print("=" * 50)
    print("  skillhub.cn 项目打包")
    print("=" * 50)
    print(f"  项目名称 : {name}")
    print(f"  版本号   : {version}")
    print(f"  描述     : {skill.get('description', '')}")
    print(f"  作者     : {skill.get('author', '')}")
    print(f"  运行时   : {skill.get('runtime', 'python')}")
    print(f"  入口     : {skill.get('entry', '')}")
    print("-" * 50)
    print(f"  打包文件 : {zip_filename}")
    print(f"  文件数量 : {file_count}")
    print(f"  文件大小 : {zip_size_kb:.1f} KB")
    print(f"  必要文件 : skill.json  SKILL.md  requirements.txt")
    print("=" * 50)

    category = skill.get("skillhub", {}).get("category", "")
    tags = skill.get("skillhub", {}).get("tags", [])
    if category:
        print(f"  分类     : {category}")
    if tags:
        print(f"  标签     : {', '.join(tags)}")

    return zip_path


if __name__ == "__main__":
    package()
