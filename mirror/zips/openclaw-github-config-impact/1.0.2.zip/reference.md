# Reference：GitHub、路径与 API

## 完整本地目录示例

```
{workspace}/
  g3fo-config/                          ← 项目根（repo slug）
    .openclaw-config-state.json         ← 元数据，在版本目录之外
    2026-04-01/
      配置文件/
        g3fo-dx-dev.yml
        g3fo-dx-dev-字段说明.md
    2026-04-08/
      配置文件/
        g3fo-dx-dev.yml
        g3fo-dx-dev-字段说明.md
```

当前只读：`g3fo-config/2026-04-08/...`（以 `state.latest_version_dir` 为准）。

## URL 解析

| 用户输入 | owner | repo | ref（若可解析） |
|----------|-------|------|-----------------|
| `https://github.com/acme/service` | acme | service | 默认分支 |
| `https://github.com/acme/service/tree/develop/配置文件` | acme | service | develop |
| `https://github.com/acme/service/blob/main/config/app.yml` | acme | service | main |

**GitHub Enterprise**：将 `https://github.com` 换为企业 host（如 `https://github.company.com`），Raw 与 API 基地址随之替换。

## Raw 文件

```
https://raw.githubusercontent.com/acme/service/main/配置文件/g3fo-user-dev.yml
```

`main` 换为分支名或 tag。须与 `state.remote_ref` 用于同步时的一致。

## 获取 ref 的 tip SHA（判断是否最新）

**分支**（示例，需 `Accept: application/vnd.github+json`，私有库带 `Authorization: Bearer TOKEN`）：

```http
GET https://api.github.com/repos/{owner}/{repo}/git/ref/heads/{branch}
```

响应中 `object.sha` 为当前分支指向的 commit（注意：这是 ref 对象，已是 commit SHA）。

**或直接取提交**：

```http
GET https://api.github.com/repos/{owner}/{repo}/commits/{ref}
```

`ref` 可为分支名或 tag；响应顶层 `sha` 为 commit。

**默认分支**（若用户未指定分支）：

```http
GET https://api.github.com/repos/{owner}/{repo}
```

读取 `default_branch`，再请求 `.../git/ref/heads/{default_branch}`。

**Tag**：`GET .../git/ref/tags/{tag}` 得到的是 tag 对象 SHA，需再 `GET .../git/tags/{sha}` 取 `object.sha` 才是真正的 commit（部分 API 封装已展开，以实际响应为准）。

将取得的 SHA 与 `.openclaw-config-state.json` 的 `commit_sha` **全量字符串**比较（忽略大小写亦可，但须完整 40 位）。

## Contents API（列目录、读文件）

```http
GET https://api.github.com/repos/{owner}/{repo}/contents/{path}?ref={ref}
```

目录返回 JSON 数组；文件含 `content`（base64）与 `encoding`。大文件注意 API 大小限制。

## 点分键展平（YAML）

```yaml
app:
  cache:
    caffeine:
      max-size: 200
```

→ `app.cache.caffeine.max-size` = `200`

Properties：`spring.datasource.url` 即为一维键，无需展平。

## 发现字段说明的启发式

1. 同目录 `{basename}-字段说明.md`
2. `{basename}.md` 且含「字段」「配置项」表头
3. 仓库 `README` 或 `docs/` 内「配置说明」锚点链接

## 私有仓库与 Token

- 环境变量常见名：`GITHUB_TOKEN`、`GH_TOKEN`。
- API 与部分 Raw 场景需在请求头加：`Authorization: Bearer <token>`。
- 若无法访问远程，按 SKILL 中「远程不可用时的降级」处理，不得静默使用过期快照。

## 可选进阶：按路径判断是否有变更

若不想在「无关提交」时也全量重拉配置，可对每个 `tracked_path` 使用：

```http
GET https://api.github.com/repos/{owner}/{repo}/commits?path={path}&sha={ref}
```

取最新一条提交与本地记录比较；实现成本更高，默认 skill 以 **tip SHA** 为准即可。
