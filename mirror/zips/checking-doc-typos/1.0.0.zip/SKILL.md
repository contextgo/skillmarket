---
name: "checking-doc-typos"
description: |
  检查中文 docx 文件中的错别字，在修订模式下修正错误并添加批注说明。Use when user asks to check typos, proofread, or correct misspellings in a Word document. Do NOT use for grammar checking, formatting fixes, or non-Chinese documents.
---

# Typo Checker - 错别字检查与修订

AI 辅助检查 Word 文档（docx / .doc）中的错别字，在修订模式下自动修正并添加批注说明。修正后的文档以 Word 原生修订追踪（tracked changes）标记所有修改，每处修改附有批注说明错误原因，原文档格式和排版完整保留。

> ⚠️ **.doc 格式支持**：本 skill 支持输入 `.doc` 格式文件。处理时会自动使用 pywin32（COM 自动化）调用 Microsoft Word 将 `.doc` 转换为 `.docx`，然后按标准流程处理。**要求**：Windows 系统 + 已安装 Microsoft Word + 已安装 pywin32 库。

## Use this skill when

- 用户要求检查中文 Word 文档（docx 或 .doc）中的错别字
- 用户要求对 Word 文档进行校对或文字纠错
- 用户提供了 .docx 或 .doc 文件并要求查找拼写错误或别字

## Do NOT use this skill when

- 用户要求检查语法问题（如语序、搭配不当）而非错别字——本 skill 只处理同音错别字、形近错别字、常见别字、漏字/多字、成语错字
- 用户要求修改文档格式、排版或样式——本 skill 只修改文本内容
- 用户处理的是非 Word 格式文件（如 .pdf、txt）——本 skill 仅支持 .docx 或 .doc
- 用户要求翻译文档或进行英文拼写检查——本 skill 专注于中文错别字

## Input

- `<input_docx>`: string  # 输入文件的绝对路径（.docx 或 .doc，如 `D:\docs\测试文件.docx`）

## Output

- `<output_docx>`: string  # 修正后 docx 文件的绝对路径，命名为 `原文件名_CheckOut_<timestamp>.docx`，位于输入文件同目录。
- `typos_found`: list<object>  # 发现的错别字列表，每项含 wrong、correct、reason、context、occurrence 字段
- `verification_passed`: boolean  # 内容完整性验证是否通过

## On Failure

- **输入文件不存在或格式错误**：向用户报告文件路径错误或文件不是有效的 .docx/.doc，停止执行。
- **文档为空或无可读文本**：向用户报告文档内容为空，停止执行。
- **未发现错别字**：向用户报告未发现错别字，不生成修正版文档
- **修正后验证失败（段落数量不一致、内容丢失等）**：禁止向用户输出文档，排查原因后重新执行修正步骤（第四步）和验证步骤（第五步），最多重试 3 次；若仍失败，向用户报告验证失败详情并建议人工检查
- **部分错别字未在文档中找到**：在结果中标注未找到的条目，继续处理其余条目，最终向用户报告哪些条目未匹配

## ⚠️ 关键禁止事项（开始前必读）

> **以下行为会导致输出文档内容丢失或损坏，严格禁止：**

1. **❌ 禁止自行编写修正脚本**：必须使用本 skill 提供的 `typo_fixer.py` 进行修正（见第四步）。自行编写脚本调用 `Document` 类的 `get_node` + `replace_node` 会导致 **严重内容丢失**——`replace_node` 会替换整个 `w:r` 节点，如果该节点包含除错别字外的其他文本，这些文本将全部丢失。
2. **❌ 禁止跳过验证步骤**：第五步的内容完整性验证是**强制性的**，不得跳过。未通过验证的文档 **禁止** 输出给用户。
3. **❌ 禁止在终端中直接执行多行 Python 代码**：本 skill 已提供 `typo_fixer.py`（含 `--extract-only` 文本提取功能）和 `verify.py`（验证功能）。**必须直接调用这些脚本**，禁止将多行 Python 代码粘贴到终端执行。多行 Python 代码在 PowerShell 的 `python -c` 中极易因引号嵌套、分号分隔、for/if 语句等导致语法错误。
4. **❌ 禁止直接调用 `Document` 类的 `get_node` + `replace_node` 修正错别字**：`replace_node` 会替换整个 `w:r` 节点，如果该节点包含除错别字外的其他文本，这些文本将全部丢失。必须使用 `typo_fixer.py`（见第四步），其内部已正确处理文本拆分逻辑。
5. **❌ 禁止在 skill 目录内创建工作文件夹**：工作文件夹**必须**创建在输出 docx 文件所在目录下。**禁止**在 `.trae/skills/checking-doc-typos/` 目录内创建。所有路径 **必须** 使用绝对路径 `<work_dir>`。**禁止**使用相对路径，因为不同命令的当前工作目录（cwd）可能不同，相对路径会导致在错误位置创建文件夹。

## 路径变量说明

本工作流程使用以下路径变量，请在开始前明确它们的值：

| 变量             | 含义                                         | 示例                                          |
|:-------------- |:------------------------------------------ |:------------------------------------------- |
| `<skill_name>` | 本 skill 的名称，同时也是输出 docx 文件中批注的作者名          | `checking-doc-typos`                        |
| `<skill_root>` | 本 skill 的根目录（包含 `scripts/` 和 `ooxml/` 的目录） | `D:\path\to\.trae\skills\checking-doc-typos` |
| `<input_docx>` | 输入文件的 **绝对路径**（docx 或 .doc）             | `D:\docs\测试文件.docx`                         |
| `<input_dir>`  | 输入 docx 文件所在目录的**绝对路径**                    | `D:\docs`                                   |
| `<timestamp>`  | 第一步获取的本地时间戳                               | `20260424_153025`                           |
| `<work_dir>`   | 工作文件夹的**绝对路径**                             | `D:\docs\checking-doc-typos_20260424_153025` |

> ⚠️ **所有路径必须使用绝对路径**。Windows 路径中的反斜杠 `\` 在 Python 中是转义字符，在命令行参数中直接使用原始路径即可（如 `D:\docs\file.docx`），**不要**手动添加额外转义。

## 工作流程

### 第一步：获取时间戳并创建工作文件夹

在开始任何操作之前，**必须先执行以下命令**获取当前本地时间戳：

```bash
python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"
```

将输出的时间戳记为 `<timestamp>`（例如输出 `20260424_153025`，则 `<timestamp>` = `20260424_153025`）。

> ⚠️ **必须实际执行此命令**，不得自行编造或猜测时间戳。禁止使用 `20260424_120000` 等占位时间戳。

然后定义工作文件夹路径。工作文件夹**必须**创建在输出 docx 文件所在的目录下，使用**绝对路径**：

- `<work_dir>` = `<input_dir>\<skill_name>_<timestamp>`（如 `D:\docs\checking-doc-typos_20260424_153025`）

> ⚠️ **工作文件夹位置禁止事项**：
> - **禁止**在 skill 目录（`.trae/skills/checking-doc-typos/`）内创建工作文件夹
> - **禁止**使用相对路径（如 `<skill_name>_<timestamp>/unpacked`），必须使用绝对路径（如 `<work_dir>\unpacked`）
> - 后续所有步骤中的路径 **必须** 使用 `<work_dir>` 绝对路径前缀

创建工作文件夹：

```bash
mkdir "<work_dir>"
```

后续步骤中除最终修正版 docx 外的所有中间产物都放在 `<work_dir>` 下。

### 第一步半：doc 格式自动转换（仅当输入为 .doc 时执行）

如果输入文件为 `.doc` 格式，`typo_fixer.py` 和 `verify.py` 会自动调用 `doc_converter.py`（基于 pywin32 COM 自动化）将 `.doc` 转换为临时 `.docx` 文件，处理完成后自动清理临时文件。**无需手动执行转换操作。**

> ⚠️ **.doc 转换前提条件**：
> - 必须在 Windows 系统上运行
> - 必须已安装 Microsoft Word（COM 组件）
> - 必须已安装 pywin32 库（`pip install pywin32`）

如果需要手动转换 `.doc` 文件，也可以直接调用：

```bash
python "<skill_root>\scripts\doc_converter.py" "<input_doc>" --output "<output_docx>"
```

### 第二步：提取文档文本

使用本 skill 提供的 `typo_fixer.py` 脚本提取 docx 文件的文本内容：

```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" --extract-only > "<work_dir>\extracted_text.txt"
```

> ⚠️ **禁止**使用 `python -c` 执行多行 Python 代码来提取文本，也 **禁止** 将提取代码保存为独立的 `.py` 文件。`typo_fixer.py` 已内置 `--extract-only` 参数，直接调用即可。
> ⚠️ **文本提取覆盖范围**：文本提取已覆盖正文段落、表格、页眉页脚和文本框（包括传统文本框 `w:txbxContent` 和现代形状文本框 `wps:txbx`）。脚注、尾注中的文字仍无法提取，如果文档包含这些元素，应提醒用户可能存在未检查到的区域。

### 第三步：AI 识别错别字

仔细阅读提取的文本，逐段检查以下类型的错误：

1. **同音错别字**：如"按装"→"安装"、"帐号"→"账号"
2. **形近错别字**：如"己经"→"已经"、"拔涉"→"跋涉"
3. **常见别字**：如"做贡献"→"作贡献"、"交代"→"交待"（视语境）
4. **漏字/多字**：如缺少"的、了"等助词
5. **成语错字**：如"按步就班"→"按部就班"、"一愁莫展"→"一筹莫展"

校对时可查阅同目录下的 `references/` 文件夹：
- `references/common-typos.md` — 常见错别字速查表（同音字、形近字、易错词组）
- `references/common-sentence-errors.md` — 常见病句类型（语序不当、搭配不当、成分残缺或赘余、结构混乱、表意不明、不合逻辑）

将发现的错别字整理为 JSON 格式，并保存为文件：

```json
[
  {
    "wrong": "按装",
    "correct": "安装",
    "reason": "同音错别字，'安'为正确写法",
    "context": "设备按装完毕"
  },
  {
    "wrong": "己经",
    "correct": "已经",
    "reason": "形近错别字，'已'为正确写法",
    "context": "己经完成验收"
  }
]
```

#### 精准定位：context 和 occurrence 字段

当同一错别字在文档中出现多次，但只需修正其中特定位置时，可使用 `context` 和 `occurrence` 字段实现精准定位。**不指定这两个字段时，`typo_fixer.py` 会修正文档中所有匹配处（默认行为）。**

| 字段 | 类型 | 说明 | 示例 |
|:-----|:-----|:-----|:-----|
| `context` | string | **上下文匹配**：只有当错别字所在段落的完整文本包含此字符串时，才执行修正。用于通过上下文唯一确定需要修正的位置 | `"降低安装成本"` |
| `occurrence` | integer | **第 N 次出现**：只修正文档中第 N 次出现的错别字（从 1 开始计数，按 XML 文档顺序）。用于同一错别字出现多次但只需修正特定位置的场景 | `2` |

**使用示例**：

```json
[
  {
    "wrong": "压榨",
    "correct": "榨取",
    "reason": "用词不当",
    "context": "降低安装工作量和安装成本"
  },
  {
    "wrong": "压榨",
    "correct": "榨取",
    "reason": "用词不当",
    "occurrence": 2
  }
]
```

- 第 1 条：只在包含"降低安装工作量和安装成本"的段落中修正"压榨"→"榨取"，其他段落中的"压榨"不受影响
- 第 2 条：只修正文档中第 2 次出现的"压榨"→"榨取"，第 1 次、第 3 次等不受影响

> ⚠️ **`context` 和 `occurrence` 可同时使用**：同时指定时，先用 `context` 过滤出匹配的段落，再在这些段落中按 `occurrence` 定位。大多数情况下只需使用其中一个即可。
> ⚠️ **`context` 应足够具体**以唯一标识目标段落。如果 `context` 匹配到多个段落且未指定 `occurrence`，这些段落中的错别字都会被修正。
> ⚠️ **`occurrence` 的计数基于 XML 文档顺序**（`getElementsByTagName("w:p")` 的遍历顺序），涵盖正文、表格、页眉页脚、文本框等所有区域，与 `python-docx` 的 `doc.paragraphs` 顺序不同。**禁止使用 `python-docx` 的段落索引来推算 `occurrence`。**
> ⚠️ **文件命名规则（必须严格遵守）**：将错别字列表保存为 JSON 文件时，文件必须放在工作文件夹 `<work_dir>` 下，文件名为 `typos_<timestamp>.json`，其中 `<timestamp>` 为第一步中实际执行命令获取的本地时间戳。**禁止自行编造时间戳**。**禁止使用** `typos.json`、`typos_to_fix.json` 等无时间戳的文件名。

### 第四步：在修订模式下修正错别字

使用本 skill 提供的 `typo_fixer.py` 脚本进行修正。该脚本会自动处理文本拆分、修订追踪标记和批注添加，不会丢失任何内容。

> ⚠️ **再次强调：必须使用 `typo_fixer.py`，禁止自行编写修正脚本。** 自行编写脚本调用 `Document` 类的 `get_node` + `replace_node` 会导致严重内容丢失，因为 `replace_node` 会替换整个 `w:r` 节点，而一个 `w:r` 节点可能包含除错别字外的其他文本，这些文本会随节点替换而丢失。`typo_fixer.py` 内部已正确处理了文本拆分逻辑（将 `w:r` 中的文本拆分为"错别字前文本 + 删除标记 + 插入标记 + 错别字后文本"），不会丢失任何内容。

#### 4.1 使用 typo_fixer.py 修正错别字（唯一正确方式）

**方式一：通过 JSON 文件传入错别字列表（推荐）**

```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" "<input_dir>\原文件名_CheckOut_<timestamp>.docx" --typos-file "<work_dir>\typos_<timestamp>.json"
```

**方式二：通过命令行参数传入错别字 JSON 字符串**

```bash
python "<skill_root>\scripts\typo_fixer.py" "<input_docx>" "<input_dir>\原文件名_CheckOut_<timestamp>.docx" --typos '[{"wrong":"按装","correct":"安装","reason":"同音错别字"}]'
```

> ⚠️ **Windows PowerShell 环境注意事项**：
> - ❌ **禁止**使用 `PYTHONPATH=<skill_root> python -m ...` 等 bash 语法设置环境变量，PowerShell 不支持此语法
> - **必须**使用 `python "<skill_root>\scripts\typo_fixer.py"` 直接调用脚本，脚本内部已自动处理 `sys.path`
> - 如果必须设置 PYTHONPATH，PowerShell 语法为 `$env:PYTHONPATH="<skill_root>"; python -m ...`

脚本执行后会输出处理统计信息，包括成功和失败的修正数量。请关注输出中的 `⚠️ 未找到文本` 条目，这些表示在文档中未找到对应的错别字文本。

> ⚠️ **如果修正失败数量大于 0**，需要检查原因：可能是错别字文本在文档中不存在（AI 误判），或文本跨越了多个 `w:r` 元素。对于后一种情况，`typo_fixer.py` 已内置处理逻辑，通常不会出现此问题。

#### 4.2 输出文件命名规则

> ⚠️ **文件命名规则（必须严格遵守）**：输出 docx 文件名必须为 `原文件名_CheckOut_<timestamp>.docx`，其中 `<timestamp>` 为第一步中实际执行命令获取的本地时间戳。此文件放在输入文件同目录下，**不放在**工作文件夹。**禁止自行编造时间戳**。**禁止使用** `原文件名_CheckOut.docx` 等无时间戳的文件名。

### 第五步：内容完整性验证（强制性）

> ⚠️ **本步骤为强制性步骤，不得跳过。** 未通过验证的文档 **禁止** 输出给用户。如果验证失败，必须排查原因并修正后重新执行第四步和第五步（见下方反馈闭环）。

使用本 skill 提供的 `verify.py` 脚本进行验证。

```bash
python "<skill_root>\scripts\verify.py" "<input_docx>" "<input_dir>\原文件名_CheckOut_<timestamp>.docx" "<work_dir>"
```

该脚本会自动执行以下三项验证：

1. **段落数量验证**：对比原始文档与修正文档的段落数量，确保一致
2. **模拟接受修订验证**：模拟"接受所有修订"，确认只有预期的错别字被修改，没有其他内容丢失
3. **文件结构验证**：确保修正文档保留了原始文档的所有文件，仅新增批注相关文件

> ⚠️ **禁止**使用 `python -c` 执行多行 Python 代码来验证，也 **禁止** 将验证代码保存为独立的 `.py` 文件。`verify.py` 已封装全部验证逻辑，直接调用即可。
> ⚠️ **如果任何验证项未通过（输出 ❌），必须排查原因并修正后再继续**，不得向用户输出有内容缺失的文档。常见原因：使用了自行编写的修正脚本而非 `typo_fixer.py`，导致 `w:r` 节点被整体替换而丢失非错别字文本。

#### 反馈闭环：验证失败时的处理流程

```
验证失败 → 排查原因 → 修正 typos JSON → 重新执行第四步 → 重新执行第五步
                                                    |                   |
                                                    +--- 最多重试 3 次---+
                                                                         |
                                                          3 次仍失败 → 向用户报告详情，建议人工检查
```

1. 如果验证失败，首先检查是否使用了 `typo_fixer.py`（而非自行编写脚本）
2. 检查 typos JSON 中的 `wrong` 字段是否与文档中的实际文本完全匹配
3. 修正 typos JSON 后，重新执行第四步（修正）和第五步（验证）
4. 最多重试 3 次；若仍失败，向用户报告验证失败详情并建议人工检查

### 第六步：输出结果

向用户报告检查结果：

```
📋 错别字检查完成
检查文件：xxx.docx
发现问题数：N
【修正清单】
1. "按装" → "安装"（同音错别字）
2. "己经" → "已经"（形近错别字）
3. "按步就班" → "按部就班"（成语错字）
4. "帐号" → "账号"（常见别字）
5. "拔涉" → "跋涉"（形近错别字）
已生成修订版文档：xxx_CheckOut_<timestamp>.docx
- 所有修改均以修订模式标记，可在 Word 中逐一接受/拒绝
- 每处修改附有批注说明
- 中间文件保存在：<work_dir>
```

## 重要规则

1. **只修改确定的错别字**：不确定的用词差异不要修改，可在批注中提出建议
2. **保留原格式**：替换文本时必须保留原 run 的 rPr（格式属性）
3. **最小化修改**：只标记实际更改的文本，未更改的文本不要放入 `<w:del>`/`<w:ins>` 标签
4. **每个修改都要有批注**：说明错别字类型和修改原因
5. **修订追踪规范**：
   - 删除文本使用 `<w:del>` + `<w:delText>`
   - 插入文本使用 `<w:ins>` + `<w:t>`
   - RSID 必须为 8 位十六进制（如 `00AB1234`）
6. **启用修订模式**：在 settings.xml 中添加 `<w:trackRevisions/>`
7. **⚠️ 文件命名必须带本地时间戳（严格遵守）**：
   - 在工作流开始前 **必须先执行** `python -c "from datetime import datetime; print(datetime.now().astimezone().strftime('%Y%m%d_%H%M%S'))"` 获取真实本地时间戳，记为 `<timestamp>`
   - 工作文件夹 **必须** 命名为 `<skill_name>_<timestamp>`（如 `checking-doc-typos_20260424_153025`），创建在输出 docx 文件所在目录下，使用绝对路径 `<work_dir>`
   - 中间产出的错别字 JSON 文件**必须**放在 `<work_dir>` 下，命名为 `typos_<timestamp>.json`。**禁止自行编造时间戳**。**禁止**使用 `typos.json`、`typos_to_fix.json` 等无时间戳的文件。
   - 最终产出的修正后 docx 文件**必须**命名为 `原文件名_CheckOut_<timestamp>.docx`，放在输入文件同目录下，**不放在**工作文件夹。**禁止自行编造时间戳**。**禁止**使用 `原文件名_CheckOut.docx` 等无时间戳的文件。
8. **⚠️ 工作文件夹管理**：
   - 所有中间产物（提取的文本、typos JSON、解压的 docx 内容等）**必须**放在 `<work_dir>` 中
   - 最终修正版 docx 文件**不放在**工作文件夹，放在输入文件同目录下
   - **⚠ 工作文件夹必须创建在输入 docx 文件所在目录下**。**禁止**在 skill 目录（`.trae/skills/checking-doc-typos/`）内创建工作文件夹
   - **⚠ 所有路径必须使用绝对路径**（基于 `<work_dir>`），**禁止**使用相对路径（如 `<skill_name>_<timestamp>/unpacked`），因为相对路径依赖于当前工作目录，不同命令的 cwd 可能不同，会导致在错误位置创建文件夹
9. **⚠ 必须使用 typo_fixer.py 进行修正**：
   - 本 skill 提供的 `typo_fixer.py` 已正确处理文本拆分逻辑，不会丢失内容
   - **禁止**自行编写修正脚本调用 `Document` 类的 `get_node` + `replace_node`，这会导致整个 `w:r` 节点被替换，丢失节点中除错别字外的所有文本
10. **⚠ 禁止在终端中直接执行多行 Python 代码**：
    - 本 skill 已提供 `typo_fixer.py`（含 `--extract-only` 文本提取功能）和 `verify.py`（验证功能）。**必须直接调用这些脚本**
    - **禁止**使用 `python -c` 执行多行 Python 代码（含 for 循环、if 语句、函数定义等），PowerShell 的引号嵌套和语句分隔规则与 bash 不同，极易导致语法错误
    - **禁止**将多行 Python 代码保存为独立的 `.py` 文件放在项目目录中
    - 所有功能应通过调用 skill 提供的脚本实现
11. **⚠ 验证步骤为强制性**：
    - 必须使用 `verify.py` 脚本执行第五步的三项验证（段落数量、模拟接受修订、文件结构）
    - 任何验证项未通过时，**禁止**向用户输出文档，必须排查原因并修正
    - 验证失败后按反馈闭环流程处理（最多重试 3 次）
12. **⚠️ Windows PowerShell 环境兼容性**：
    - **禁止**使用 bash 语法 `PYTHONPATH=xxx python -m ...` 设置环境变量，PowerShell 不支持此语法
    - **必须**使用 `python "<skill_root>\scripts\脚本名.py"` 直接调用脚本，脚本内部已自动处理 `sys.path`
    - Windows 路径中的反斜杠 `\` 在命令行参数中直接使用即可，**不要**手动添加额外转义

## 技术架构

```
checking-doc-typos/
├── SKILL.md                          # 本文档
├── references/                       # 参考资料
│  ├── common-typos.md               # 常见错别字速查表
│  └── common-sentence-errors.md     # 常见病句类型
├── scripts/
│  ├── __init__.py
│  ├── document.py                   # Document 类（OOXML 编辑器）
│  ├── utilities.py                  # XMLEditor 基类
│  ├── doc_converter.py              # .doc 转 .docx 转换（pywin32 COM 自动化）
│  ├── typo_fixer.py                 # 错别字修正主脚本（必须使用此脚本）
│  │                                #   --extract-only: 提取文本（第二步）
│  │                                #   --typos-file: 通过 JSON 文件修正（第四步）
│  │                                #   --typos: 通过命令行 JSON 修正（第四步）
│  │                                #   context 字段: 上下文匹配精准定位
│  │                                #   occurrence 字段: 指定第 N 次出现
│  ├── verify.py                     # 内容完整性验证脚本（第五步）
│  └── templates/                    # 批注相关 XML 模板
│      ├── comments.xml
│      ├── commentsExtended.xml
│      ├── commentsIds.xml
│      ├── commentsExtensible.xml
│      └── people.xml
├── ooxml/
│  └── scripts/
│      ├── unpack.py                 # docx 解压
│      ├── pack.py                   # docx 打包
│      └── validation/              # 验证工具
│          ├── __init__.py
│          ├── base.py
│          ├── docx.py
│          └── redlining.py
└── requirements.txt
```

## 依赖

- Python 3.10+
- defusedxml
- lxml
- python-docx（用于文本提取）
- pywin32（用于 .doc 转 .docx 转换，仅 Windows + Microsoft Word 环境需要）
