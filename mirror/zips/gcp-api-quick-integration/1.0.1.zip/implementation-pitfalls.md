# 签名底座实现：常见问题与必须对齐项

> 本文档来自真实对接排障经验。生成 **任意语言** 的签名/验签/HTTP 封装代码时，应逐条自检，避免客户重复踩坑。

## 1. 请求头与签名编码（最高频）

| 错误做法 | 后果 | 正确做法 |
|---------|------|----------|
| `X-AGCP-Auth` 使用 **Base64** 承载 RSA 签名 | 服务端按 **hex** 解析，报 `Bad signature length`（如 got 172 expecting 256） | 签名为 **小写十六进制**：`signatureHex = hexLower(rsaSha512Sign(...))` |
| `X-AGCP-Auth` 使用 **空格** 连接算法与签名 | 与规范不符，验签失败 | 使用 **冒号**：`GCP1-RSA-SHA512:<signatureHex>` |
| `X-AGCP-Date` 使用 **ISO-8601**（如 `2026-04-14T10:30:00Z`） | 待签串与网关不一致，验签失败 | 使用 **`yyyyMMddHHmmss`**（与规范一致，常用 **UTC**） |
| `X-AGCP-Send` 固定为 `json` 等任意字符串 | 与规范不符 | **`send = date + "000"`**（`date` 为上述 14 位串） |
| `X-AGCP-Crdt` 从 ISO 日期截取 | 与待签串/网关规则不一致 | **`keyid:yyyyMMdd:gcpservice`**，其中 `yyyyMMdd` 为 `date` 的前 8 位 |

**验签侧**必须从 `X-AGCP-Auth` 取出 **hex** 再 `hexDecode` 后调用 `RSA-SHA512-VERIFY`。若需兼容历史错误实现，可 **优先 hex**，解析失败再尝试 Base64（不推荐长期依赖）。

## 2. 待签串与摘要（不可协商）

- 五行换行符必须为 **`\n`**。
- 请求体摘要：`digestHex = hexLower(SHA256(UTF8(body)))`，**小写 hex**；其中 **`body` 必须与 HTTP 实体完全一致**（同一 UTF-8 字节序列）。
- `strToSign = algo + "\n" + date + "\n" + path + "\n" + query + "\n" + digestHex`。
- 响应验签时第四行为 **空 query**（见 `signing-and-verify-spec.md` 响应章节）。

### 2.1 JSON 请求体：值为 null 的字段不上送

- 合作方常见要求：**不要**在报文中出现 `"fieldName": null`（未赋值即视为不传该字段）。
- 实现：序列化请求 DTO 时使用 **`JsonInclude.Include.NON_NULL`**（或等价配置），使 **值为 `null` 的属性不出现在 JSON**；**摘要与签名必须基于该最终 JSON 字符串**（与 `RestTemplate` / 客户端实际上送内容一致）。
- **禁止**先用「含 null 的 JSON」算摘要、再发「去掉 null 的另一份 JSON」，否则验签失败。

## 3. 私钥与平台公钥格式

| 场景 | 建议 |
|------|------|
| 客户只配置 **无 PEM 头** 的 Base64 串 | 按 **PKCS#8 DER 的 Base64** 解码后构造私钥（与去掉 `BEGIN/END` 后的 PEM 体一致） |
| 客户配置 PEM 文件路径 | 读取文件全文再解析 |
| Java 8 环境 | **禁止**使用 `Path.of`、`Files.readString`、`String.isBlank` 等 **Java 11+** API；使用 `Paths.get`、`Files.readAllBytes` + `UTF-8`、`trim().isEmpty()` 等 |

错误处理提示文案应写清：**支持 PKCS#8 PEM 或无头 PKCS#8 Base64**；若客户是 PKCS#1（`BEGIN RSA PRIVATE KEY`），需引导先转为 PKCS#8。

## 4. Maven / Spring Boot 版本与客户环境

- 客户本机 **Maven 3.6.1** 等较旧版本时，**Spring Boot 3.x** 可能拉取要求更高 Maven 的插件，导致 **编译失败**。
- 若目标为 **Java 8** 或客户环境偏旧：优先 **Spring Boot 2.7.x** + `java.version=1.8`（或 11），并在文档中说明。
- 生成后建议给出：`mvn clean compile` / `mvn test`，避免 **`target/classes` 中旧 `application.properties` 残留** 导致“已改配置仍读旧值”。

## 5. 联调与测试分层

- **单元测试**若 Mock 了 HTTP 客户端，**不会**验证真实签名与网关；必须在交付说明中区分：
  - **单元测试**：快速回归、不连网。
  - **集成测试**：注入真实配置，走签名客户端打真实环境（可选环境变量门控，避免 CI 误打生产）。
- 集成测试内 **配置断言**应使用 **Java 8 兼容**写法（如自写 `notBlank(s)`），避免 `String.isBlank()`。

## 6. 可观测性（推荐）

- 在签名 HTTP 客户端中 **记录**：请求 URL、请求体、HTTP 状态、响应体原文。
- **请求头日志**应对 `X-AGCP-Auth`（完整签名）、`X-AGCP-Crdt`（keyid）做 **脱敏**（如 `GCP1-RSA-SHA512:***`、keyid 部分打码），避免密钥材料进日志。

## 7. 生成代码后的自检清单（底座）

- [ ] `X-AGCP-Auth` 为 **`算法:小写hex`**，**非** Base64
- [ ] `X-AGCP-Date` 为 **`yyyyMMddHHmmss`**
- [ ] `X-AGCP-Send` 为 **`date + "000"`**
- [ ] `X-AGCP-Crdt` 为 **`keyid:yyyyMMdd:gcpservice`**
- [ ] 验签使用 **hexDecode(签名)**，与请求侧一致
- [ ] 目标 JDK 下无 **高版本 API** 误用
- [ ] 私钥支持 **PEM 与无头 PKCS#8 Base64**
