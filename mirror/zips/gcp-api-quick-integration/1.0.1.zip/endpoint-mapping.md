# Endpoint Mapping

> 当前映射仅用于签名底座验证阶段，固定为 query 接口。

## Base URL

- test: `https://global-test.allinpay.com`
- prod: `https://global.allinpay.com`

## Query Parameters

query 必须包含：

- `authcus=<cusid>`
- `merid=<merid>`
- `reqid=<unique_id>`（建议时间戳或 UUID）

## Fixed Query API

### query

- path: `/gcpapi/card/applyquery`
- method: `POST`
- content-type: `application/json`
- request body:
  - `applyid` string
- purpose:
  - 用单接口验证请求签名与响应验签能力
