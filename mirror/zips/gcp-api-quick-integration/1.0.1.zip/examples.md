# Usage Examples

> 本文件示例均为“签名底座阶段”输入输出，不包含业务接口模型展开。

## Example 1: Python + query

客户输入：

`请用 python 生成 query 查询接口对接代码，环境 test。`

Skill 需要继续追问：

- `keyid`
- `cusid`
- `merid`
- 私钥来源（文件路径或环境变量名）
- `applyid`
- `platformPublicKey`（用于响应验签）

生成后至少包含：

- `config.py`
- `signer.py`
- `verifier.py`
- `gcp_client.py`
- `query.py`

## Example 2: Node.js + query

客户输入：

`帮我用 nodejs 快速接入 query 查询接口，生产环境。`

Skill 需要继续追问：

- `keyid`
- `cusid`
- `merid`
- 私钥
- `applyid`
- 平台公钥（用于响应验签）

生成后至少包含：

- `config.js`
- `signer.js`
- `verifier.js`
- `gcpClient.js`
- `query.js`

## Example 3: C# + query

客户输入：

`用 csharp 生成 query 查询接口的最小可运行代码。`

Skill 需要继续追问：

- `keyid`
- `cusid`
- `merid`
- 私钥
- `applyid`
- 平台公钥（用于响应验签）

生成后至少包含：

- `Config/GcpConfig.cs`
- `Gcp/Signer.cs`
- `Gcp/Verifier.cs`
- `Gcp/GcpClient.cs`
- `App/QueryApp.cs`

## 一次性输入模板（推荐）

客户可直接复制并填写以下模板，Skill 将按参数自动生成代码：

`语言=<任意编程语言>; 接口=query; 环境=<test|prod>; keyid=<...>; cusid=<...>; merid=<...>; privateKey=<...>; platformPublicKey=<...>; 业务参数={"applyid":"..."}`

## 下一阶段衔接示例

`我已经完成签名底座，请使用 gcp-api-organcus_business-model-generator Skill（内嵌第六章规范）继续生成业务接口模型（DTO、请求响应模型、业务服务层）。`
