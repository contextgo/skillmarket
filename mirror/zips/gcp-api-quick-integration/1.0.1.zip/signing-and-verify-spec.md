# Signing And Verify Spec

## 1. Canonical Inputs

- `algo` 固定：`GCP1-RSA-SHA512`
- `date`：`yyyyMMddHHmmss`（UTC 或系统统一时区，前后一致）
- `send`：`date + "000"`
- `path`：固定为 `/gcpapi/card/applyquery`
- `query`：至少包含 `authcus`、`merid`、`reqid`
- `body`：请求体原始字节（JSON 场景为 UTF-8 字节）

## 2. Request Signing Rules

1. `digestHex = hexLower( SHA256(bodyBytes) )`
2. `strToSign = algo + "\n" + date + "\n" + path + "\n" + query + "\n" + digestHex`
3. `signatureBytes = RSA-SHA512-SIGN(privateKey, UTF8(strToSign))`
4. `signatureHex = hexLower(signatureBytes)`

请求头：

- `X-AGCP-Date: <date>`
- `X-AGCP-Send: <send>`
- `X-AGCP-Auth: GCP1-RSA-SHA512:<signatureHex>`
- `X-AGCP-Crdt: <keyid>:<yyyyMMdd>:gcpservice`

## 3. Response Verify Rules

query 接口版本中，响应验签为必选项。

1. 从响应头读取：
   - `resDate = X-AGCP-Date`
   - `resAuth = X-AGCP-Auth`
2. 从 `resAuth` 取签名 hex：
   - `resSignatureHex = split(resAuth, ":")[1]`
3. 对响应体做摘要：
   - `resDigestHex = hexLower( SHA256(responseBodyBytes) )`
4. 构造验签串：
   - `resStrToVerify = algo + "\n" + resDate + "\n" + path + "\n" + "" + "\n" + resDigestHex`
5. 验签：
   - `ok = RSA-SHA512-VERIFY(platformPublicKey, UTF8(resStrToVerify), hexDecode(resSignatureHex))`

## 4. Pseudocode (Language Agnostic)

```text
function signRequest(privateKey, keyid, path, query, bodyBytes):
    algo = "GCP1-RSA-SHA512"
    date = formatNow("yyyyMMddHHmmss")
    send = date + "000"
    yyyyMMdd = date[0:8]

    digestHex = hexLower(sha256(bodyBytes))
    strToSign = algo + "\n" + date + "\n" + path + "\n" + query + "\n" + digestHex
    signatureHex = hexLower(rsaSha512Sign(privateKey, utf8Bytes(strToSign)))

    headers = {
      "X-AGCP-Date": date,
      "X-AGCP-Send": send,
      "X-AGCP-Auth": algo + ":" + signatureHex,
      "X-AGCP-Crdt": keyid + ":" + yyyyMMdd + ":gcpservice"
    }
    return headers

function verifyResponse(platformPublicKey, path, responseHeaders, responseBodyBytes):
    algo = "GCP1-RSA-SHA512"
    resDate = responseHeaders["X-AGCP-Date"]
    resAuth = responseHeaders["X-AGCP-Auth"]
    resSignatureHex = split(resAuth, ":")[1]

    resDigestHex = hexLower(sha256(responseBodyBytes))
    resStrToVerify = algo + "\n" + resDate + "\n" + path + "\n" + "" + "\n" + resDigestHex

    return rsaSha512Verify(
      platformPublicKey,
      utf8Bytes(resStrToVerify),
      hexDecode(resSignatureHex)
    )
```

## 5. Non-Negotiable Constraints

- `strToSign` 必须是 5 行，换行符为 `\n`。
- `digestHex` 与 `signatureHex` 必须是小写 hex。
- 不允许对 query 字段名做语义替换（`authcus/merid/reqid` 必须保留）。
- 不允许将私钥硬编码在源码中。

## 6. Error Handling Requirements

- 如果私钥格式错误：报错并提示支持格式（**优先 PKCS#8**：PEM 或无头 Base64；PKCS#1 需转换后再用）。
- 如果响应头缺失 `X-AGCP-Auth`：直接返回“无法验签”并给出原始响应头。
- 如果验签失败：输出待验签串与签名摘要前 16 字符，便于排查。

## 7. 常见实现错误（必读）

以下错误会导致网关验签失败或出现 **`Bad signature length`** 等异常，生成代码时 **禁止** 出现：

1. **用 Base64 代替 hex** 作为 `X-AGCP-Auth` 中签名载荷（规范为 **小写 hex**）。
2. **`X-AGCP-Auth` 使用空格** 连接算法与签名（必须为 **`:`**）。
3. **`X-AGCP-Date` 使用 ISO-8601** 等非 `yyyyMMddHHmmss` 格式。
4. **`X-AGCP-Send` 写死为 `json`** 等与 **`date + "000"`** 不符的值。
5. **`X-AGCP-Crdt` 日期段** 不是 **`date` 前 8 位 `yyyyMMdd`**。
6. 验签时对签名做 **Base64 解码** 而请求侧发的是 **hex**。

完整排障表与语言无关说明见同目录 **[implementation-pitfalls.md](implementation-pitfalls.md)**。
