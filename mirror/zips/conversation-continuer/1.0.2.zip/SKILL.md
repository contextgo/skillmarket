---
name: conversation-continuer
display_name: 对话续接器
description: 通过心跳机制自动检测并继续执行用户未完成的对话请求，0 Token检测保障连续性，避免用户重复触发。
version: 1.0.1
author: 叶建国
homepage: https://github.com/yourusername/conversation-continuer
tags:
  - 对话管理
  - 心跳检测
  - 任务续接
  - 自动化
license: MIT
compatibility:
  - openclaw
---

# 对话续接器

自动检测并继续执行用户未完成的对话请求，保障对话连续性。

## 核心设计

### 问题
- 用户发送请求 → OpenClaw 处理中 → 中断
- 用户需要再次手动触发才能继续

### 解决思路
1. **检测**：每次心跳检查是否有"未完成"的请求
2. **续接**：自动继续执行未完成的部分
3. **最小Token**：只读本地状态文件，0 token 检测

## Token 优化

```
Heartbeat 触发
    ↓
读取本地会话状态文件（0 token）
    ↓
检查是否有 pending 请求
    ↓ 有
继续执行（正常消耗token）
    ↓ 无
结束（0 token）
```

**核心原则**：检测本身0 token，只在确实需要继续时才消耗。

## 使用方式

### 1. 安装
```bash
skillhub install conversation-continuer
```

### 2. 配置 Heartbeat

在用户的 `HEARTBEAT.md` 中添加：

```markdown
## 对话连续性检查（0 token 检测）
- 运行: node ~/.openclaw/workspace/skills/conversation-continuer/scripts/check.js
```

### 3. 日常使用

```bash
# 添加新请求（由系统自动调用）
node tracker.js add '用户消息内容'

# 查看待处理请求
node tracker.js pending

# 查看所有请求
node tracker.js list
```

## 输入方式

用户正常使用即可，系统自动：
- 检测未完成的请求
- 标记请求状态
- 在心跳时自动续接

## 功能说明

| 功能 | 说明 |
|------|------|
| 状态追踪 | 记录请求状态：pending/running/completed/failed |
| 自动检测 | 心跳时0 token检测是否有待处理请求 |
| 安全限制 | 仅操作技能目录内文件，输入经过清理验证 |
| 自动清理 | 自动清理7天前的已完成/失败记录 |

## 输出结果

```
[对话续接器] 检查完成: 2个pending, 0个running

请求详情:
  - req_1234567890: 帮我查一下天气
  - req_1234567891: 生成一份报告

💡 正在继续执行...
```

## 技术细节

### 状态标记时机

当 OpenClaw 开始处理用户请求时：
1. 将请求写入 pending_requests
2. 状态设为 "pending"
3. 处理完成后改为 "completed"
4. 中断则保持 "pending"

### 最小 Token 策略

| 操作 | Token消耗 |
|------|----------|
| 读取状态文件 | **0** |
| 检查pending | **0** |
| 继续执行 | 正常消耗 |
| 写入状态 | **0** |

## 安全声明

### 权限需求
- **文件系统**：仅读写技能目录内的 `data/status.json` 文件
- **网络**：无需网络访问
- **外部命令**：不执行任何外部命令

### 安全特性
- 所有文件操作限制在技能目录内（路径验证）
- 用户输入经过清理和长度限制（最大1000字符）
- 命令白名单验证
- 文件权限设置为 0o600（仅所有者可读写）

### 数据存储
- 数据仅存储在本地 `~/.openclaw/workspace/skills/conversation-continuer/data/`
- 不传输到任何外部服务
- 不存储敏感信息（密码、密钥等）

## 文件结构

```
conversation-continuer/
├── SKILL.md
├── scripts/
│   ├── tracker.js      # 状态追踪器
│   └── check.js        # 检测脚本
└── data/
    └── status.json     # 状态文件（自动创建）
```

## 免责声明

本技能仅用于辅助管理对话状态，不保证100%续接成功率。用户应自行验证重要操作的结果。本技能不对因使用本工具造成的任何直接或间接损失承担责任。

## 更新日志

### v1.0.1
- 安全加固：路径验证、输入清理、命令白名单
- 添加完整安全声明和权限说明

### v1.0.0
- 初始版本发布
- 支持状态追踪和自动检测
- 0 Token 心跳检测
