#!/usr/bin/env node
/**
 * 对话续接器 - 状态追踪器
 * 用于记录和管理用户的对话请求状态
 * 
 * 安全说明：
 * - 所有文件操作限制在技能目录内
 * - 输入数据经过验证和清理
 * - 不执行外部命令或动态代码
 */

const fs = require('fs');
const path = require('path');

// 安全：限制操作目录在技能包内
const SKILL_ROOT = path.resolve(__dirname, '..');
const DATA_DIR = path.join(SKILL_ROOT, 'data');
const STATUS_FILE = path.join(DATA_DIR, 'status.json');

// 安全：验证路径在允许范围内
function isPathSafe(targetPath) {
  const resolved = path.resolve(targetPath);
  return resolved.startsWith(SKILL_ROOT);
}

// 安全：清理用户输入
function sanitizeInput(input) {
  if (typeof input !== 'string') return '';
  // 移除控制字符，限制长度
  return input.replace(/[\x00-\x1F\x7F]/g, '').substring(0, 1000);
}

// 确保目录存在
function ensureDir() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
}

// 加载状态
function loadStatus() {
  ensureDir();
  if (fs.existsSync(STATUS_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(STATUS_FILE, 'utf-8'));
    } catch (e) {
      return { pending_requests: [], last_check: null };
    }
  }
  return { pending_requests: [], last_check: null };
}

// 保存状态（安全版本）
function saveStatus(status) {
  ensureDir();
  if (!isPathSafe(STATUS_FILE)) {
    throw new Error('Invalid path: outside skill directory');
  }
  fs.writeFileSync(STATUS_FILE, JSON.stringify(status, null, 2), { mode: 0o600 });
}

// 添加新请求
function addRequest(userMessage, sessionKey = 'default') {
  const status = loadStatus();
  
  const request = {
    id: `req_${Date.now()}`,
    session_key: sessionKey,
    user_message: userMessage,
    status: 'pending',
    created_at: new Date().toISOString(),
    last_attempt: null,
    attempts: 0,
    result: null
  };
  
  status.pending_requests.push(request);
  saveStatus(status);
  
  return request.id;
}

// 更新请求状态
function updateRequest(requestId, updates) {
  const status = loadStatus();
  const request = status.pending_requests.find(r => r.id === requestId);
  
  if (request) {
    Object.assign(request, updates);
    request.last_attempt = new Date().toISOString();
    if (updates.status === 'running') {
      request.attempts = (request.attempts || 0) + 1;
    }
    saveStatus(status);
  }
  
  return request;
}

// 获取待处理请求
function getPendingRequests() {
  const status = loadStatus();
  return status.pending_requests.filter(r => r.status === 'pending');
}

// 获取正在运行的请求
function getRunningRequests() {
  const status = loadStatus();
  return status.pending_requests.filter(r => r.status === 'running');
}

// 清理已完成/失败的旧请求（保留7天）
function cleanup(olderThanDays = 7) {
  const status = loadStatus();
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - olderThanDays);
  
  status.pending_requests = status.pending_requests.filter(r => {
    const created = new Date(r.created_at);
    // 保留 pending 和 running，清理已完成超过N天的
    if (r.status === 'completed' || r.status === 'failed') {
      return created > cutoff;
    }
    return true;
  });
  
  saveStatus(status);
}

// 主检测函数 - 用于 Heartbeat
function checkAndContinue() {
  // 读取状态文件 - 0 Token
  const status = loadStatus();
  status.last_check = new Date().toISOString();
  
  // 找 pending 请求 - 0 Token
  const pending = status.pending_requests.filter(r => r.status === 'pending');
  const running = status.pending_requests.filter(r => r.status === 'running');
  
  console.log(`[对话续接器] 检查完成: ${pending.length}个pending, ${running.length}个running`);
  
  if (pending.length > 0) {
    return { 
      action: 'continue', 
      count: pending.length,
      requests: pending 
    };
  }
  
  // 无需消耗token的检测完成
  return { action: 'none', count: 0 };
}

// CLI 入口
if (require.main === module) {
  const args = process.argv.slice(2);
  const command = sanitizeInput(args[0]);
  
  // 安全：验证命令有效性
  const VALID_COMMANDS = ['add', 'list', 'pending', 'check', 'complete', 'fail', 'cleanup'];
  if (command && !VALID_COMMANDS.includes(command)) {
    console.error('Error: Invalid command');
    process.exit(1);
  }
  
  switch (command) {
    case 'add':
      const msg = sanitizeInput(args[1]) || '测试请求';
      const session = sanitizeInput(args[2]) || 'default';
      const id = addRequest(msg, session);
      console.log(`添加请求: ${id}`);
      break;
      
    case 'list':
      console.log(JSON.stringify(loadStatus(), null, 2));
      break;
      
    case 'pending':
      const pending = getPendingRequests();
      console.log(`待处理请求: ${pending.length}`);
      pending.forEach(p => console.log(`  - ${p.id}: ${p.user_message}`));
      break;
      
    case 'check':
      const result = checkAndContinue();
      console.log(JSON.stringify(result, null, 2));
      break;
      
    case 'complete':
      if (args[1]) {
        const reqId = sanitizeInput(args[1]);
        const resultText = sanitizeInput(args[2]) || '完成';
        updateRequest(reqId, { status: 'completed', result: resultText });
        console.log(`请求 ${reqId} 已标记为完成`);
      }
      break;
      
    case 'fail':
      if (args[1]) {
        const reqId = sanitizeInput(args[1]);
        const reason = sanitizeInput(args[2]) || '失败';
        updateRequest(reqId, { status: 'failed', result: reason });
        console.log(`请求 ${reqId} 已标记为失败`);
      }
      break;
      
    case 'cleanup':
      const days = parseInt(args[1], 10);
      if (isNaN(days) || days < 1 || days > 365) {
        console.error('Error: days must be between 1 and 365');
        process.exit(1);
      }
      cleanup(days);
      console.log('清理完成');
      break;
      
    default:
      console.log(`
对话续接器 - 状态追踪器

用法: node tracker.js [命令] [参数]

命令:
  add <消息> [会话]     添加新请求
  list                 列出所有请求
  pending              列出待处理请求
  check                检测并返回待处理请求
  complete <id> [结果] 标记请求完成
  fail <id> [原因]     标记请求失败
  cleanup [天数]       清理N天前的旧请求
      `);
  }
}

module.exports = {
  addRequest,
  updateRequest,
  getPendingRequests,
  getRunningRequests,
  checkAndContinue,
  cleanup,
  loadStatus,
};
