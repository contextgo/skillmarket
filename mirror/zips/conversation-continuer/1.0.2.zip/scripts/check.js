#!/usr/bin/env node
/**
 * 对话续接器 - 检测脚本
 * 用于 Heartbeat 调用
 * 
 * 核心原则：0 Token 检测
 * - 只读取本地状态文件
 * - 只在有pending任务时返回需要继续执行
 */

const tracker = require('./tracker.js');

console.log('========================================');
console.log('🔍 对话续接器 - 开始检测');
console.log('========================================');

// 执行检测 - 0 Token
const result = tracker.checkAndContinue();

if (result.action === 'continue') {
  console.log(`\n⚠️  发现 ${result.count} 个未完成的请求\n`);
  
  result.requests.forEach(req => {
    console.log(`  📝 请求ID: ${req.id}`);
    console.log(`  💬 用户消息: ${req.user_message}`);
    console.log(`  📅 创建时间: ${req.created_at}`);
    console.log(`  🔄 重试次数: ${req.attempts}`);
    console.log('');
  });
  
  console.log('💡 正在继续执行...\n');
  
  // 标记为运行中
  result.requests.forEach(req => {
    tracker.updateRequest(req.id, { status: 'running' });
  });
  
  // 这里可以添加实际的继续执行逻辑
  // 例如：调用 OpenClaw API 继续处理
  
  console.log('✅ 检测完成 - 如需继续执行请实现续接逻辑\n');
  
} else {
  console.log('✅ 无待处理请求 - 0 Token 消耗\n');
}

console.log('========================================');
