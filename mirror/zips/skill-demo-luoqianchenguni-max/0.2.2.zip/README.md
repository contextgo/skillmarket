﻿# Skill Demo + EasyBuy Skillpack (JS Browser Runtime)

This package runs all integrated skills directly with JavaScript + Playwright, without Chrome extension `browser.*` runtime.

## OpenClaw Usage (Natural Language)

In OpenClaw, type:
- `执行skill-demo`
- or `run skill-demo`

Then skill `hello` will automatically start full flow:
- open orders -> open order details -> run contact flow -> type/send message.

## What is integrated

- Skill entry: `skills/hello/skill.js`
- Unified runtime: `skills/_easybuy_browser_runtime.js`
- Skill registry/specs: `dist/skills/*.json`
- Playbooks: `dist/playbooks/*.json`
- Skill config: `skill.yaml` (all entries use `.js`)

Integrated skill names:

- `order_reader`
- `evidence_builder`
- `message_drafter`
- `form_filler`
- `amazon_product_detector`
- `amazon_orders_scraper`
- `amazon_orders_opener`
- `amazon_order_details_fetcher`
- `amazon_price_checker`
- `amazon_review_scraper`
- `amazon_contact_flow`
- `message_monitor`
- `price_alert_manager`
- `case_exporter`

## Validate skillpack

```powershell
node scripts/validate-skills.mjs --root . --playbooks-dir dist/playbooks
```

## Local debug command (optional)

```powershell
node -e "const { run } = require('./skills/hello/skill.js'); run('{\"action\":\"run_full_flow\",\"year\":2025,\"message\":\"I noticed a price drop after purchase and request a refund for the difference.\",\"auto_send\":false,\"browser\":{\"headless\":false,\"keepOpen\":true}}').then(console.log).catch(console.error);"
```
