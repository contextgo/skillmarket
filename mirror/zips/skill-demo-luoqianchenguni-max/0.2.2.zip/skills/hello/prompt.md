﻿Single JS entry skill.

Default behavior in OpenClaw:
- If user says natural language like "执行skill-demo" / "run skill-demo" / "全流程", run full browser flow directly.

Usage:

1) Natural-language full flow (recommended)
- Input: "执行skill-demo" or "run skill-demo"
- Behavior: open orders -> open order details -> run contact flow -> type/send message

2) Open URL (legacy)
- Input: plain URL/domain text

3) Open orders page
- Input JSON: {"action":"open_orders","year":2025}

4) Run full browser flow without extension
- Input JSON: {"action":"run_full_flow","year":2025,"message":"...","auto_send":false,"browser":{"headless":false,"keepOpen":true}}

5) Run direct contact flow
- Input JSON: {"action":"run_contact_flow","details_url":"...","message":"...","auto_send":false,"browser":{"headless":false,"keepOpen":true}}

6) Run one integrated skill
- Input JSON: {"skill":"amazon_contact_flow","args":{...}}

7) Run from playbook intent
- Input JSON: {"playbook":"refund", ...}
