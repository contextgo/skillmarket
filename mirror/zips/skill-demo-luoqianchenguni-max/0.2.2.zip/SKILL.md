﻿---
name: skill-demo
description: Run EasyBuy Amazon end-to-end browser workflow from natural-language commands (for example "执行skill-demo" or "run skill-demo"). Use when user wants one-shot full flow: open orders, open order details, run Amazon contact flow, and type/send message. Also supports explicit JSON actions and legacy URL-open behavior.
---

# Skill Demo

Primary behavior:
- Treat natural-language command like `执行skill-demo` as full-flow execution.
- Run full browser flow without extension runtime.

## Full-Flow Behavior

1. Open Amazon orders page (`year` from text if present, otherwise current year).
2. Find one order and open order details.
3. Run contact flow chain.
4. Type message and optionally auto-send.

Default runtime options for natural-language full flow:
- `headless: false`
- `keepOpen: true`
- `slowMo: 300`
- `timeoutMs: 60000`
- `debug: true`

## Input Modes

1. Natural language full flow:
- `执行skill-demo`
- `run skill-demo`
- `全流程`

2. JSON actions:
- `{"action":"run_full_flow", ...}`
- `{"action":"open_orders", ...}`
- `{"action":"run_contact_flow", ...}`
- `{"skill":"amazon_contact_flow","args":{...}}`

3. Legacy URL opener:
- Plain URL/domain still opens browser URL.

## Output

- Return runtime JSON result for skill/full-flow actions.
- Return one-line open status for URL mode.
