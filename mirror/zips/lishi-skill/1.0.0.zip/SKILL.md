---
name: rss-ai-reader
description: |
  📰 RSS AI 阅读器 — 自动抓取订阅、LLM生成摘要、多渠道推送！
  支持 Claude/OpenAI 生成中文摘要，推送到飞书/Telegram/Email。
  预置高质量历史类公众号订阅，开箱即用！
  
  触发条件: 用户要求订阅RSS、监控博客、抓取新闻、生成摘要、设置定时抓取、
  "帮我订阅"、"监控这个网站"、"每天推送新闻"、RSS/Atom feed 相关。
---

**⚠️ 重要：所有 RSS URL 必须在末尾加 `?limit=100` 否则默认只返回10篇！**

例如：`http://111.51.197.129:4000/feeds/xxx.atom?limit=100`

# 📰 RSS AI Reader

自动抓取 RSS 订阅 → LLM 生成中文摘要 → 推送到 IM

## ✨ 核心功能

- 📡 自动抓取 RSS/Atom feeds
- 🤖 Claude/OpenAI 生成中文摘要
- 📬 多渠道推送：飞书、Telegram、Email
- 💾 SQLite 去重，不重复推送
- ⏰ 支持定时任务
- ✅ **预置高质量历史类公众号订阅，开箱即用**

## 🚀 快速开始

```bash
# 1. 克隆代码
git clone https://github.com/BENZEMA216/rss-reader.git ~/rss-reader
cd ~/rss-reader && pip install -r requirements.txt

# 2. 复制预置配置（已包含历史公众号订阅，开箱即用）
# 配置文件在 Skill 包中：config.yaml
# 复制到 rss-reader 目录即可

# 3. 运行
python main.py --once
```

> 💡 config.yaml 预置了历史类公众号订阅，复制到克隆的目录即可运行！

## 📝 自定义配置

如需添加更多订阅源，编辑 `config.yaml`：

**⚠️ 重要：URL 必须加 `?limit=100` 参数！否则默认只返回10篇。**

```yaml
# RSS 订阅
feeds:
  - name: "公众号名称"
    url: "RSS链接?limit=100"  # 必须是这个格式！
    category: "分类"

# LLM 配置
llm:
  provider: "claude"  # 或 "openai"
  model: "claude-sonnet-4-20250514"
  api_key: "${ANTHROPIC_API_KEY}"

# 推送到飞书
notify:
  feishu:
    enabled: true
    webhook_url: "${FEISHU_WEBHOOK}"
```

### 批量导入

支持从 OPML 文件批量导入订阅源：
```bash
# 将 OPML 转换为 config.yaml（需自行解析）
```

## 📬 支持的推送渠道

| 渠道 | 配置项 | 说明 |
|------|--------|------|
| **飞书** | `webhook_url` | 群机器人 Webhook |
| **Telegram** | `bot_token` + `chat_id` | Bot API |
| **Email** | SMTP 配置 | 支持 Gmail 等 |

## 🔧 命令行参数

```bash
python main.py [options]

--config, -c  配置文件路径 (默认: config.yaml)
--once        只执行一次
--stats       显示统计信息
--db          数据库路径 (默认: rss_reader.db)
```

## 💡 使用场景

1. **历史学术追踪** — 历史公众号实时更新
2. **新闻早报** — 每天定时推送摘要到飞书群
3. **论文追踪** — 订阅学术期刊，自动筛选新文章
4. **专题研究** — 如元代历史、海交史、西夏史等

## 📊 输出效果

飞书消息示例：
```
📰 海交史研究资讯

**泉州城异称"刺桐"之名新考**

📝 文章探讨了泉州城别称"刺桐"的由来...

🔗 阅读原文
```

## ☕ 支持作者

- **GitHub Sponsors**: [@BENZEMA216](https://github.com/sponsors/BENZEMA216)
- **Buy Me a Coffee**: [buymeacoffee.com/benzema216](https://buymeacoffee.com/benzema216)