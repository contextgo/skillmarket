# 📰 toutiao-mcp-skill

> 今日头条 OpenClaw Skill - 通过 MCP 协议操作今日头条

[![License](https://img.shields.io/badge/License-Apache%202.0-blue?style=flat-square)](LICENSE)
[![Node.js](https://img.shields.io/badge/Node.js-18+-green?style=flat-square&logo=node.js)](https://nodejs.org/)

这是一个 OpenClaw Skill 配置，用于集成 [toutiao-mcp](https://github.com/sipingme/toutiao-mcp) MCP Server。

## 🏗️ 架构

```
OpenClaw/AI Agent
    ↓ (使用 Skill 配置)
toutiao-mcp-skill (本项目)
    ↓ (MCP Protocol - stdio)
toutiao-mcp (MCP Server)
    ↓ (Playwright)
今日头条网站
```

**说明**：
- 本 Skill 只包含配置和文档
- 实际功能由 `toutiao-mcp` MCP Server 提供
- OpenClaw 通过 MCP 协议调用 Server 的 6 个工具

## 📋 安装步骤

### 步骤 1：安装 MCP Server

```bash
# 从 npm 安装
npm install -g toutiao-mcp
npx playwright install chromium

# 或从源码构建
git clone https://github.com/sipingme/toutiao-mcp.git
cd toutiao-mcp
npm install
npx playwright install chromium
npm run build
```

### 步骤 2：配置 OpenClaw

在 OpenClaw 的 MCP 配置文件中添加：

```json
{
  "mcpServers": {
    "toutiao": {
      "command": "node",
      "args": [
        "/absolute/path/to/toutiao-mcp/dist/index.js"
      ],
      "env": {
        "PLAYWRIGHT_HEADLESS": "true",
        "COOKIES_FILE": "/absolute/path/to/data/cookies.json",
        "DATA_DIR": "/absolute/path/to/data"
      }
    }
  }
}
```

**注意**：请将路径替换为实际的绝对路径。

### 步骤 3：安装 Skill 文档

```bash
# 克隆 Skill 项目（包含文档和 SOP）
git clone https://github.com/sipingme/toutiao-mcp-skill.git
cp -r toutiao-mcp-skill ~/.openclaw/skills/toutiao/
```

## ✅ 验证安装

在 OpenClaw 对话中测试：

```
你: 帮我检查今日头条登录状态

AI: [调用 check_login_status 工具]
    已登录
```

## 🎯 可用功能

toutiao-mcp 提供 6 个 MCP 工具：

### 账号管理
- `login_with_credentials` - 登录今日头条
- `check_login_status` - 检查登录状态
- `logout` - 登出

### 内容发布
- `publish_article` - 发布图文文章
- `publish_micro_post` - 发布微头条
- `publish_xiaohongshu_data` - 批量发布小红书数据

## 📚 使用示例

### 示例 1：发布文章

```
你: 帮我发布一篇今日头条文章，标题是"Node.js 开发技巧"，
    内容是"分享几个实用的 Node.js 开发技巧..."，
    使用图片 /path/to/image.jpg

AI: [调用 publish_article 工具]
    ✅ 发布成功！
```

### 示例 2：发布微头条

```
你: 发布一条微头条："今天学习了 TypeScript 的高级类型"

AI: [调用 publish_micro_post 工具]
    ✅ 微头条发布成功！
```

### 示例 3：批量发布小红书数据

```
你: 把这些小红书数据发布到今日头条

AI: [调用 publish_xiaohongshu_data 工具]
    ✅ 批量发布完成，成功 5 条
```

## 📖 完整文档

- **[SKILL.md](./SKILL.md)** - 完整的 SOP 和使用指南
- **[references/quick-start.md](./references/quick-start.md)** - 快速开始
- **[references/faq.md](./references/faq.md)** - 常见问题
- **[references/troubleshooting.md](./references/troubleshooting.md)** - 故障排查

## ⚙️ 配置选项

### 环境变量

- `PLAYWRIGHT_HEADLESS` - 是否无头模式（默认 true）
- `COOKIES_FILE` - Cookie 文件路径
- `DATA_DIR` - 数据目录路径
- `LOG_LEVEL` - 日志级别

### MCP Server 通信

默认使用 stdio 通信，无需配置端口。

## 🔒 安全性

- ✅ Cookie 仅存储在本地
- ✅ 不上传数据到第三方
- ✅ 所有通信仅限今日头条官方网站
- ✅ 开源代码，可审计

## 🤝 贡献

欢迎贡献！请提交 Issue 或 Pull Request。

## 📜 许可证

Apache-2.0 License

## 🙏 致谢

- [toutiao-mcp](https://github.com/sipingme/toutiao-mcp) - 核心 MCP Server
- [Model Context Protocol](https://modelcontextprotocol.io/) - MCP 协议
- [Playwright](https://playwright.dev/) - 浏览器自动化

---

**让 AI 能够直接操作今日头条！** 🚀
