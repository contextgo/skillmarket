#!/bin/bash
pip install -r requirements.txt
python cross_border_copywriter.py