# -*- coding: utf-8 -*-
import json
import re
import requests
import time
import uuid
import os

# ==========================
# 本地唯一ID
# ==========================
USER_DATA_DIR = os.path.expanduser("~/.skill_data")
os.makedirs(USER_DATA_DIR, exist_ok=True)
UNIQUE_ID_PATH = os.path.join(USER_DATA_DIR, "unique_id")
USE_COUNT_PATH = os.path.join(USER_DATA_DIR, "use_count")

def get_unique_id():
    try:
        if os.path.exists(UNIQUE_ID_PATH):
            with open(UNIQUE_ID_PATH, "r", encoding="utf-8") as f:
                uid = f.read().strip()
                if uid and len(uid) > 10:
                    return uid
    except:
        pass
    new_uid = str(uuid.uuid4())
    try:
        with open(UNIQUE_ID_PATH, "w", encoding="utf-8") as f:
            f.write(new_uid)
    except:
        return f"user_{uuid.uuid4()}"
    return new_uid

def get_use_count():
    try:
        if os.path.exists(USE_COUNT_PATH):
            with open(USE_COUNT_PATH, "r", encoding="utf-8") as f:
                return int(f.read().strip())
    except:
        pass
    return 0

def increase_use_count():
    try:
        current = get_use_count()
        with open(USE_COUNT_PATH, "w", encoding="utf-8") as f:
            f.write(str(current + 1))
    except:
        pass

# ==========================
# AI 风格增强模板库
# ==========================
AI_STYLE_TEMPLATES = {
    "title": [
        "{main_key} {product}: Elevate Your Lifestyle with Premium Quality",
        "{product} Featuring {feature1} & {feature2}: The Perfect Daily Essential",
        "Professional Grade {product} with {feature1}, {feature2} & Long-Lasting Performance"
    ],
    "short": [
        "Discover the ultimate {product} designed for performance, durability, and modern daily use. Premium quality you can trust.",
        "Upgrade your routine with this high-performance {product} that combines style, functionality, and long-lasting durability.",
        "A must-have {product} for every household & gift. Built to last, designed to impress, trusted by worldwide customers."
    ],
    "long": [
        "Crafted with superior materials and precision engineering, this {product} delivers consistent performance and exceptional durability. Designed to fit seamlessly into home, office, and outdoor scenarios, it combines practicality with modern aesthetics. Optimized for search visibility and built to meet high-quality standards, it’s the reliable choice for daily use and gifting.",
        "Experience next-level comfort and functionality with this premium {product}. Built with {feature1}, {feature2}, and {feature3}, it offers outstanding usability while maintaining sleek, timeless design. Whether for personal use or as a thoughtful gift, this product combines value, quality, and style in one perfect package.",
        "Engineered for excellence, this {product} stands out with premium build quality, smart design, and reliable performance. It meets the demands of daily use while elevating your overall experience. Trusted by global buyers, optimized for {platform} search, and created to bring convenience and satisfaction to every user."
    ],
    "bullet": [
        "✔ {feature}: Enjoy improved performance and daily convenience.",
        "✔ {feature}: Built to last with premium materials and craftsmanship.",
        "✔ {feature}: Designed for comfort, practicality, and wide compatibility.",
        "✔ {feature}: Lightweight, stylish, and ideal for multiple scenarios."
    ]
}

# ==========================
# 主技能类
# ==========================
class CrossBorderCopywriter:
    def __init__(self):
        self.platform_limits = {
            "Amazon": {"title": 200, "short": 150, "long": 500, "bullet": 100},
            "Temu": {"title": 80, "short": 100, "long": 300, "bullet": 80},
            "SHEIN": {"title": 80, "short": 100, "long": 300, "bullet": 80},
            "TikTok Shop": {"title": 60, "short": 80, "long": 200, "bullet": 70},
            "Shopee": {"title": 120, "short": 120, "long": 400, "bullet": 90}
        }
        self.forbidden = {"最", "绝对", "第一", "唯一", "顶级", "100%", "特效", "根治"}

        self.PAY_API = {
            "check": "http://agreekk.bahamut.shop/api/wepayCode/check",
            "payOrder": "http://agreekk.bahamut.shop/api/wepayCode/payOrder"
        }

    # ==========================
    # 支付接口
    # ==========================
    def _req(self, url, timeout=7):
        try:
            r = requests.get(url, timeout=timeout)
            r.raise_for_status()
            return r.json()
        except:
            return None

    def is_paid(self, uid):
        d = self._req(f"{self.PAY_API['check']}?unionId={uid}")
        return d and d.get("success") and d.get("data") is True

    def get_qrcode(self, uid):
        d = self._req(f"{self.PAY_API['payOrder']}?unionId={uid}")
        return d.get("data") if d and d.get("success") else None

    def poll_pay(self, uid, t=4, i=6):
        for _ in range(t):
            if self.is_paid(uid):
                return True
            time.sleep(i)
        return False

    # ==========================
    # 自然语言解析
    # ==========================
    def parse_input(self, text):
        text = str(text).strip()
        lower = text.lower()
        params = {"product_name": "", "keywords": [], "features": [], "platform": "Amazon", "use_ai": False}

        if any(k in lower for k in ["ai", "高级", "增强", "流畅"]):
            params["use_ai"] = True

        match = re.search(r"[:：](.+?)(?:关键词|卖点|平台|$)", text)
        if match:
            params["product_name"] = match.group(1).strip()
        else:
            words = re.split(r"\s+", text)
            for w in words:
                if len(w) > 2 and not any(k in w for k in ["关键词", "卖点", "平台", "生成", "文案"]):
                    params["product_name"] = w
                    break

        match = re.search(r"关键词[:：](.+?)(?:卖点|平台|$)", text)
        if match:
            kws = re.split(r"[,，\s|]+", match.group(1).strip())
            params["keywords"] = [k for k in kws if k]

        match = re.search(r"卖点[:：](.+?)(?:关键词|平台|$)", text)
        if match:
            feats = re.split(r"[,，\s|]+", match.group(1).strip())
            params["features"] = [f for f in feats if f]

        for p in ["Amazon", "Temu", "Shopee", "TikTok", "SHEIN"]:
            if p in text or p.lower() in lower:
                params["platform"] = p
                break

        return params

    # ==========================
    # AI增强文案生成
    # ==========================
    def generate_ai_copy(self, params):
        product = params.get("product_name", "Premium Product")
        keywords = params.get("keywords", [product])
        features = params.get("features", ["Premium Quality", "Durable"])
        platform = params.get("platform", "Amazon")
        limit = self.platform_limits.get(platform, self.platform_limits["Amazon"])
        main_key = keywords[0]
        f1 = features[0] if len(features)>=1 else "Durability"
        f2 = features[1] if len(features)>=2 else "Performance"
        f3 = features[2] if len(features)>=3 else "Comfort"

        title = AI_STYLE_TEMPLATES["title"][hash(product) % 3].format(product=product, main_key=main_key, feature1=f1, feature2=f2)
        short = AI_STYLE_TEMPLATES["short"][hash(product) % 3].format(product=product)
        long = AI_STYLE_TEMPLATES["long"][hash(product) % 3].format(product=product, feature1=f1, feature2=f2, feature3=f3, platform=platform)
        bullets = [AI_STYLE_TEMPLATES["bullet"][i % 4].format(feature=f) for i, f in enumerate(features[:4])]
        tags = ", ".join(list(set(keywords + features + [product]))[:5])

        def clean(s):
            for w in self.forbidden:
                s = s.replace(w, "Premium")
            return s[:limit["title"]-3]+"..." if len(s) > limit["title"] else s

        return {
            "🔥AI_TITLE": clean(title),
            "🔥AI_SHORT_DESC": clean(short)[:limit["short"]],
            "🔥AI_LONG_DESC": clean(long)[:limit["long"]],
            "🔥AI_BULLETS": [clean(b)[:limit["bullet"]] for b in bullets],
            "🔥SEO_TAGS": clean(tags),
            "PLATFORM": platform
        }

    # ==========================
    # 标准SEO文案生成
    # ==========================
    def generate_seo_copy(self, params):
        product = params.get("product_name", "Premium Product")
        keywords = params.get("keywords", [product])
        features = params.get("features", ["High Quality", "Durable"])
        platform = params.get("platform", "Amazon")
        limit = self.platform_limits.get(platform)

        title = f"{keywords[0]} {product} {' '.join(keywords[1:2])}"[:limit["title"]]
        short = f"{product} with {', '.join(features[:2])}. Ideal for daily use & gift."[:limit["short"]]
        long = f"This {product} features {', '.join(features[:3])}, durable and practical for home, office, outdoor."[:limit["long"]]
        bullets = [f"{f}: Reliable quality for daily use" for f in features[:4]]
        tags = ", ".join(list(set(keywords + features))[:5])

        return {"SEO_TITLE": title, "SHORT_DESC": short, "LONG_DESC": long, "BULLETS": bullets, "TAGS": tags, "PLATFORM": platform}

    # ==========================
    # SkillHub 标准入口
    # ==========================
    def run(self, params, context=None):
        if isinstance(params, dict) and "content" in params:
            text = params["content"]
        else:
            text = str(params)

        uid = get_unique_id()
        parsed = self.parse_input(text)
        product = parsed.get("product_name", "")

        if not product:
            return {"reply": "请告诉我你的商品名称～\n例如：生成文案 无线蓝牙耳机"}

        if self.is_paid(uid):
            copy = self.generate_ai_copy(parsed) if parsed["use_ai"] else self.generate_seo_copy(parsed)
            return {"reply": "✅【永久会员】已生成\n\n" + json.dumps(copy, ensure_ascii=False, indent=2)}

        use_cnt = get_use_count()

        if use_cnt == 0:
            copy = self.generate_ai_copy(parsed) if parsed["use_ai"] else self.generate_seo_copy(parsed)
            increase_use_count()
            return {"reply": "✅【首次免费】\n\n" + json.dumps(copy, ensure_ascii=False, indent=2)}

        qrcode = self.get_qrcode(uid)
        if not qrcode:
            return {"reply": "⚠️ 支付服务暂时不可用"}

        if self.poll_pay(uid):
            copy = self.generate_ai_copy(parsed)
            return {"reply": "✅ 支付成功！永久解锁\n\n" + json.dumps(copy, ensure_ascii=False, indent=2)}

        return {
            "reply": "⚠️ 免费次数已用完\n🔥 仅需1元，永久解锁：\n● AI高级文案\n● 多平台SEO\n● 无限次使用",
            "image": qrcode
        }

skill = CrossBorderCopywriter()