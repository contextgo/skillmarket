import requests
import json
from .config import API_BASE_URL

class JX3APIClient:
    """剑网3 API 客户端"""

    def __init__(self, base_url=None):
        self.base_url = base_url or API_BASE_URL
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'JX3APISkill/1.0',
            'Content-Type': 'application/json'
        })

    def _request(self, endpoint, method="GET", params=None, data=None):
        """统一请求方法"""
        url = f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        try:
            if method.upper() == "GET":
                response = self.session.get(url, params=params, timeout=10)
            elif method.upper() == "POST":
                response = self.session.post(url, params=params, json=data, timeout=10)
            else:
                return {"code": 400, "msg": f"不支持的请求方法: {method}", "data": None}

            response.raise_for_status()
            result = response.json()
            return result
        except requests.exceptions.Timeout:
            return {"code": 408, "msg": "请求超时，请稍后重试", "data": None}
        except requests.exceptions.RequestException as e:
            return {"code": 500, "msg": f"请求失败: {str(e)}", "data": None}
        except json.JSONDecodeError:
            return {"code": 500, "msg": "响应数据解析失败", "data": None}

    def _resolve_server_name(self, server_name):
        """
        解析服务器名称，支持简称和模糊匹配
        
        Args:
            server_name: 用户输入的服务器名称（可能是简称或不完整名称）
            
        Returns:
            解析后的主服务器名称，如果解析失败则返回原始输入
        """
        result = self._request("server/master", params={"name": server_name})
        
        if result.get("code") == 200 and result.get("data"):
            data = result["data"]
            return data.get("name", server_name)
        
        return server_name

    def get_active_calendar(self, server=None, num=0):
        """
        查询日常活动日历
        
        Args:
            server: 服务器名称（可选，支持简称）
            num: 日期偏移值，0=今天，1=明天，2=后天（默认0）
            
        Returns:
            日常活动信息，包括大战、战场、矿车、门派、救援、幸运、美人图等
        """
        params = {"num": num}
        if server:
            params["server"] = self._resolve_server_name(server)
        return self._request("active/calendar", params=params)

    def get_server_check(self, server=None, check_type=1):
        """
        查询服务器的当前状态，包括维护、正常、繁忙和爆满等状态信息。
        
        Args:
            server: 服务器名称（可选，不传则返回所有服务器状态，支持简称）
            check_type: 检查类型，1=开服检查，2=状态检查（默认1）
            
        Returns:
            服务器当前状态信息（维护/正常/繁忙/爆满）
            服务器开服状态信息（已开服/未开服）
        """
        params = {"type": check_type}
        if server:
            params["server"] = self._resolve_server_name(server)
        return self._request("status/check", params=params)

    def get_news_announce(self, limit=10):
        """
        查询官方公告
        
        Args:
            limit: 返回公告数量（1-50，默认10）
            
        Returns:
            公告列表
        """
        params = {"limit": limit}
        return self._request("news/announce", params=params)

    def get_active_celebs(self, server):
        """
        查询世界首领
        
        Args:
            server: 服务器名称（支持简称）
            
        Returns:
            世界首领信息
        """
        params = {"server": self._resolve_server_name(server)}
        return self._request("active/celebs", params=params)

    def get_active_monster(self, server):
        """
        查询野外首领
        
        Args:
            server: 服务器名称（支持简称）
            
        Returns:
            野外首领信息
        """
        params = {"server": self._resolve_server_name(server)}
        return self._request("active/monster", params=params)

    def get_luck_adventure(self, server, name=None):
        """
        查询奇遇信息
        
        Args:
            server: 服务器名称（支持简称）
            name: 玩家名称（可选）
            
        Returns:
            奇遇信息
        """
        params = {"server": self._resolve_server_name(server)}
        if name:
            params["name"] = name
        return self._request("luck/adventure", params=params)

    def get_role_attribute(self, server, name):
        """
        查询角色属性
        
        Args:
            server: 服务器名称（支持简称）
            name: 角色名称
            
        Returns:
            角色属性信息
        """
        params = {"server": self._resolve_server_name(server), "name": name}
        return self._request("role/attribute", params=params)

    def get_role_detailed(self, server, name):
        """
        查询角色详情
        
        Args:
            server: 服务器名称（支持简称）
            name: 角色名称
            
        Returns:
            角色详情信息
        """
        params = {"server": self._resolve_server_name(server), "name": name}
        return self._request("role/detailed", params=params)

    def get_school_skills(self, school):
        """
        查询门派技能
        
        Args:
            school: 门派名称
            
        Returns:
            门派技能信息
        """
        params = {"school": school}
        return self._request("school/skills", params=params)

    def get_server_event(self, server=None):
        """
        查询服务器活动
        
        Args:
            server: 服务器名称（可选，支持简称）
            
        Returns:
            服务器活动信息
        """
        params = {}
        if server:
            params["server"] = self._resolve_server_name(server)
        return self._request("server/event", params=params)

    def get_server_master(self):
        """
        查询开服时间表
        
        Returns:
            开服时间表信息
        """
        return self._request("server/master")

    def get_server_sand(self, server):
        """
        查询沙盘信息
        
        Args:
            server: 服务器名称（支持简称）
            
        Returns:
            沙盘信息
        """
        params = {"server": self._resolve_server_name(server)}
        return self._request("server/sand", params=params)


def get_client(base_url=None):
    """获取JX3 API客户端实例"""
    return JX3APIClient(base_url)
