# JX3API Skill

基于 [jx3api](https://www.jx3api.com) 的剑网3游戏助手技能，提供日常查询、服务器状态、公告查询等功能。

## 安装

```bash
pip install -r requirements.txt
```

## 快速开始

```python
from jx3api import get_client

client = get_client()
result = client.get_active_calendar()
print(result)
```

## 功能列表

| 功能 | 方法 | 说明 |
|------|------|------|
| 日常活动查询 | `get_active_calendar` | 查询今天/明天/后天的日常任务 |
| 服务器状态 | `get_server_status` | 查询服务器状态（维护/正常/繁忙/爆满） |
| 开服状态 | `get_server_check` | 查询服务器是否开服 |
| 官方公告 | `get_news_announce` | 获取官方公告列表 |
| 世界首领 | `get_active_celebs` | 查询世界首领信息 |
| 野外首领 | `get_active_monster` | 查询野外首领信息 |
| 奇遇查询 | `get_luck_adventure` | 查询角色奇遇记录 |
| 角色属性 | `get_role_attribute` | 查询角色装备属性 |
| 角色详情 | `get_role_detailed` | 查询角色详细信息 |
| 门派技能 | `get_school_skills` | 查询门派技能信息 |
| 服务器活动 | `get_server_event` | 查询服务器活动 |
| 开服时间表 | `get_server_master` | 查询开服时间表 |
| 沙盘信息 | `get_server_sand` | 查询阵营沙盘信息 |

---

## API 详细说明

### 1. 查询日常活动 (active-calendar)

查询今天、明天、后天的日常任务信息。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 否 | 服务器名称，用于获取美人图数据 |
| num | int | 否 | 日期偏移值：0=今天，1=明天，2=后天，默认0 |

**输入示例：**

```python
client = get_client()

# 查询今日日常
result = client.get_active_calendar()

# 查询指定服务器今日日常
result = client.get_active_calendar(server="长安城")

# 查询明日日常
result = client.get_active_calendar(num=1)
```

**输出示例：**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "date": "2026-04-01",
    "week": "三",
    "war": "大战！英雄冰川宫宝库",
    "battle": "云湖天池",
    "orecar": "跨服·河西瀚漠",
    "school": "纯阳·山门卫道",
    "rescue": "藏剑·乱世",
    "luck": ["嗷呜", "丰丰", "圆圆"],
    "card": ["银雾湖", "狼牙堡·战兽山", "狼牙堡·燕然峰"],
    "team": ["千岛湖·温泉战倭;侠客岛·雾岛寻丹", "已删除;已删除;已删除", "会战弓月城;雷域大泽;狼牙堡·狼神殿"]
  },
  "time": 1733646979
}
```

**字段说明：**

| 字段 | 说明 |
|------|------|
| date | 日期 |
| week | 星期 |
| war | 今日大战副本 |
| battle | 今日战场 |
| orecar | 矿车跑商地图 |
| school | 门派任务（周一周二周四） |
| rescue | 救援任务 |
| luck | 今日幸运玩家 |
| card | 美人图（周三周五周六周日） |
| team | 团队副本 |

---

### 2. 查询服务器状态 (server-status)

查询指定服务器的当前状态。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 是 | 服务器名称 |

**输入示例：**

```python
result = client.get_server_status(server="长安城")
```

**输出示例：**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zone": "电信区",
    "server": "长安城",
    "status": "拥挤"
  },
  "time": 1723007064
}
```

**状态说明：**
- 维护：服务器正在维护
- 正常：服务器正常运行
- 繁忙：服务器负载较高
- 拥挤：服务器人数较多
- 爆满：服务器人数已满

---

### 3. 查询开服状态 (server-check)

查询服务器是否开服或维护中。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 否 | 服务器名称，不传则返回所有服务器 |

**输入示例：**

```python
# 查询指定服务器
result = client.get_server_check(server="长安城")

# 查询所有服务器
result = client.get_server_check()
```

**输出示例：**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "id": 1,
    "zone": "电信区",
    "server": "长安城",
    "status": 1,
    "time": 1722977456
  },
  "time": 1723006935
}
```

**status字段：**
- 0：维护中
- 1：已开服

---

### 4. 查询官方公告 (news-announce)

获取官方最新维护公告。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| limit | int | 否 | 返回条数，1-50，默认10 |

**输入示例：**

```python
result = client.get_news_announce(limit=5)
```

**输出示例：**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 2607,
      "token": 1334235,
      "class": "官方公告",
      "title": "12月5日1.0.0.8799版本更新公告",
      "date": "12/05",
      "url": "https://jx3.xoyo.com/announce/gg.html?id=1334235"
    }
  ],
  "time": 1733666196
}
```

---

### 5. 查询世界首领 (active-celebs)

查询世界首领刷新信息。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 是 | 服务器名称 |

**输入示例：**

```python
result = client.get_active_celebs(server="长安城")
```

---

### 6. 查询野外首领 (active-monster)

查询野外首领刷新信息。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 是 | 服务器名称 |

**输入示例：**

```python
result = client.get_active_monster(server="长安城")
```

---

### 7. 查询奇遇信息 (luck-adventure)

查询指定角色的奇遇触发记录。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 是 | 服务器名称 |
| name | string | 否 | 角色名称 |

**输入示例：**

```python
result = client.get_luck_adventure(server="梦江南", name="玩家名称")
```

**输出示例：**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "zone": "电信五区",
      "server": "梦江南",
      "name": "玩家名称",
      "event": "泛天河",
      "level": 1,
      "status": 1,
      "time": 1708092604
    }
  ],
  "time": 1723011369
}
```

---

### 8. 查询角色属性 (role-attribute)

查询指定角色的装备属性详情。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 是 | 服务器名称 |
| name | string | 是 | 角色名称 |

**输入示例：**

```python
result = client.get_role_attribute(server="唯我独尊", name="角色名称")
```

---

### 9. 查询角色详情 (role-detailed)

查询指定角色的详细信息。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 是 | 服务器名称 |
| name | string | 是 | 角色名称 |

**输入示例：**

```python
result = client.get_role_detailed(server="长安城", name="角色名称")
```

---

### 10. 查询门派技能 (school-skills)

查询指定门派的技能信息。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| school | string | 是 | 门派名称 |

**输入示例：**

```python
result = client.get_school_skills(school="万花")
```

---

### 11. 查询服务器活动 (server-event)

查询服务器活动信息。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 否 | 服务器名称 |

**输入示例：**

```python
result = client.get_server_event(server="长安城")
```

---

### 12. 查询开服时间表 (server-master)

查询服务器开服时间表。

**输入示例：**

```python
result = client.get_server_master()
```

---

### 13. 查询沙盘信息 (server-sand)

查询阵营沙盘信息。

**请求参数：**

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| server | string | 是 | 服务器名称 |

**输入示例：**

```python
result = client.get_server_sand(server="长安城")
```

---

## 错误处理

所有API返回统一的错误格式：

```json
{
  "code": 500,
  "msg": "请求失败: 具体错误信息",
  "data": null
}
```

**常见错误码：**

| 错误码 | 说明 |
|--------|------|
| 200 | 成功 |
| 400 | 请求参数错误 |
| 408 | 请求超时 |
| 500 | 服务器错误 |

---

## 运行示例

```bash
python example.py
```

---

## 注意事项

1. 部分接口需要VIP权限才能访问
2. 角色查询类接口可能需要额外配置token
3. 美人图数据仅在周三、周五、周六、周日提供
4. 世界首领仅在周三、周五存在

---

## API来源

数据来源于 [jx3api.com](https://www.jx3api.com)，仅供学习交流使用。
