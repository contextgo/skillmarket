> **请求说明**

此接口用于查询客户端师徒系统的信息，包括徒弟或师傅的角色信息及相关描述。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/member/teacher
```

> **请求参数**

```json
{
  "server": "长安城",
  "keyword": "徒弟",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的师徒信息。
- [×] `[keyword]` 输入关键字模糊匹配，使用 =关键字 可完全匹配。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zone": "电信五区",
    "server": "梦江南",
    "data": [
      {
        "roleId": 31501253,
        "roleName": "愿神",
        "roleLevel": 120,
        "campName": "恶人谷",
        "tongName": "爱神",
        "tongMasterName": "自愿",
        "bodyId": 1,
        "bodyName": "成男",
        "forceId": 6,
        "forceName": "五毒",
        "comment": "随便扩点！！！！！！！",
        "time": 1713009468
      }
    ]
  },
  "time": 1713009549
}
```