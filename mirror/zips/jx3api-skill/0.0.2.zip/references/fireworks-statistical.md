> **请求说明**

此接口用于统计指定烟花的赠送与接收记录。

> **请求权限**

``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/fireworks/statistical
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "name": "真橙之心",
  "limit": 1,
  "token": "..."
}
```

- [√] `[server]` 指定目标区服，查找该区服的相关信息。
- [√] `[name]` 指定烟花名称，统计该烟花的相关记录。
- [×] `[limit]` 限制返回记录的数量，默认值为 20，可选范围为 1-50。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。请替换为您获取的实际 Token。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 1052715,
      "zone": "电信区",
      "server": "唯我独尊",
      "name": "真橙之心",
      "map_name": "扬州",
      "sender": "郭炜炜@西山居",
      "receive": "风月的男宠",
      "mode": 1,
      "status": 1,
      "time": 1741288960
    }
  ],
  "time": 1713010801
}
```