> **请求说明**

此接口用于随机读取一张符合条件的角色名片。

> **请求权限**

``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/show/random
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "body": "萝莉",
  "force": "万花",
  "token": "YOUR_TOKEN"
}
```

[×] 可选的 `[server]` 目标区服名称，用于查询指定区服的角色名片。
<br>
[×] 可选的 `[body]` 角色体型名称，用于筛选目标体型的名片。
<br>
[×] 可选的 `[force]` 门派名称，用于筛选目标门派的名片。
<br>
[√] 必选的 `[token]` 站点标识，用于验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信区",
    "serverName": "唯我独尊",
    "roleName": "苏廿七",
    "showHash": "dd55e7e2f3eea5ecca9279bc5cfbb8d0",
    "showAvatar": "https://www.jx3api.com/cache/51700f1668779a940bb64f0e67e73fe2.png",
    "showStatus": 2
  },
  "time": 1733676724
}
```