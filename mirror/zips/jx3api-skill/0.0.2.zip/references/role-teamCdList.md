> **请求说明**

此接口用于查询指定角色的副本进度记录，包括角色所属服务器、副本信息、BOSS击杀进度等详细内容。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/role/teamCdList
```

> **请求参数**

```json
{
  "server": "梦江南",
  "name": "无根生",
  "ticket": "...",
  "token": "..."
}
```

- [√] `[server]` 指定目标区服，查询该区服的角色记录。
- [√] `[name]` 指定角色名称，查询该角色的副本记录。
- [√] `[ticket]` 推栏标识，用于验证请求权限。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信区",
    "serverName": "梦江南",
    "roleName": "无根生",
    "roleId": "26838186",
    "globalRoleId": "270215977654603771",
    "forceName": "万花",
    "forceId": "2",
    "bodyName": "萝莉",
    "bodyId": "6",
    "tongName": "笑谈风雪不负卿",
    "tongId": "36516",
    "campName": "恶人谷",
    "campId": "2",
    "personName": "点心大大",
    "personId": "576049dd73cb4daf9524d001f5aac899",
    "personAvatar": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/e68443a936574f538527793548c90667/avatar.jpg/896e2e085bc54e9881029b2c2c101e14.jpg",
    "data": [
      {
        "mapIcon": "https://dl.pvp.xoyo.com/prod/icons/maps/426.jpg?v=2",
        "mapId": "426",
        "mapName": "敖龙岛",
        "mapType": "10人普通",
        "bossCount": 6,
        "bossFinished": 6,
        "bossProgress": [
          {
            "finished": true,
            "icon": "",
            "index": "688",
            "name": "铁黎",
            "progressId": "1"
          },
          {
            "finished": true,
            "icon": "",
            "index": "689",
            "name": "陈徽",
            "progressId": "2"
          },
          {
            "finished": true,
            "icon": "",
            "index": "690",
            "name": "藤原武裔",
            "progressId": "3"
          },
          {
            "finished": true,
            "icon": "",
            "index": "691",
            "name": "源思弦",
            "progressId": "4"
          },
          {
            "finished": true,
            "icon": "",
            "index": "692",
            "name": "驺吾",
            "progressId": "5"
          },
          {
            "finished": true,
            "icon": "",
            "index": "693",
            "name": "方有崖",
            "progressId": "6"
          }
        ]
      }
    ]
  },
  "time": 1723011091
}
```