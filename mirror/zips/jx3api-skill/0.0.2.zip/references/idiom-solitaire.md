> **请求说明**

此接口用于成语接龙，通过输入一个成语，返回可以接龙的下一个成语。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/idiom/solitaire
```

> **请求参数**

```json
{
  "name": "望子成龙"
}
```

- [√] `[name]` 输入的四字成语，用于进行成语接龙。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "question": {
      "id": 22903,
      "name": "望子成龙",
      "tone": "wàng zǐ chéng lóng",
      "pinyin": "wang zi cheng long",
      "abbreviation": "wzcl",
      "first": "wang",
      "last": "long",
      "derivation": "无",
      "example": "家长要有望子成龙的愿望，更要有培养和教育孩子成材的行动。",
      "explanation": "希望自己的子女能在学业和事业上有成就。"
    },
    "answer": {
      "id": 11814,
      "name": "祲威盛容",
      "tone": "lóng wēi shèng róng",
      "pinyin": "long wei sheng rong",
      "abbreviation": "lwsr",
      "first": "long",
      "last": "rong",
      "derivation": "无",
      "example": "无",
      "explanation": "庄重的声威和盛大的仪容。"
    }
  },
  "time": 1733679254
}
```
