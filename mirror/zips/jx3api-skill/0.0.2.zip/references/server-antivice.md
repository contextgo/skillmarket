> **请求说明**

此接口用于查询诛恶事件，包括事件触发的服务器、地图及时间等详细信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/server/antivice
```

> **请求参数**

```json
{
  "token": "YOUR_TOKEN"
}
```

- [√] `[token]` 站点标识，用于验证请求权限，请替换为您的实际 Token。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 36200,
      "zone": "双线区",
      "server": "飞龙在天",
      "map_name": "烂柯山·1号分线",
      "time": 1733675339
    }
  ],
  "time": 1733675681
}
```