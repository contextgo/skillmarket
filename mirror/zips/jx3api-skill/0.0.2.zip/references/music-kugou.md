> **请求说明**

此接口用于通过酷狗音乐平台搜索指定歌曲名称，并返回相关音乐的 ID、名称和歌手信息。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/music/kugou
```

> **请求参数**

```json
{
  "name": "么么哒"
}
```

- [√] `[name]` 歌曲名称，用于搜索酷狗音乐的相关内容。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "SongName": "么么哒",
      "AlbumID": "1027087",
      "FileHash": "664AC63EDFB50EECE6A7553686BE9D8E",
      "SQFileHash": "CE0DDCFDA638500768618D83DC702749",
      "HQFileHash": "A17DF6188ECDEF68FE716646B5480E77",
      "MvHash": "FE4CA5D733560BFB99D90F609C2CBC0D",
      "Audioid": 19817185,
      "SingerName": "莫露露",
      "PlayUrl": "",
      "Img": ""
    },
    {
      "SongName": "么么哒 (DJ版)",
      "AlbumID": "35638475",
      "FileHash": "671D1F655454CD2BEA855AA96E51381E",
      "SQFileHash": "DA5719BCC6CB6B1062FDA0140C1F5D7A",
      "HQFileHash": "74FD55DECC53E6F31FE7297F4F81D8D1",
      "MvHash": "FE4CA5D733560BFB99D90F609C2CBC0D",
      "Audioid": 28953937,
      "SingerName": "莫露露",
      "PlayUrl": "",
      "Img": ""
    },
    {
      "SongName": "么么哒 (女生版)",
      "AlbumID": "",
      "FileHash": "8CC59BAC825BD56A9CD315C46597DDEF",
      "SQFileHash": "",
      "HQFileHash": "",
      "MvHash": "",
      "Audioid": 66614823,
      "SingerName": "沐星欣儿",
      "PlayUrl": "",
      "Img": ""
    },
    {
      "SongName": "中国么么哒",
      "AlbumID": "1985700",
      "FileHash": "F265BD2D64DD79A81BB2DC5217C59841",
      "SQFileHash": "0398E6820A7F5C4F6FE2060AC370B978",
      "HQFileHash": "F61966597AD0086AE7EB10380F9D1F34",
      "MvHash": "8C0E67C07E34907F8332BF4917DB85EC",
      "Audioid": 25926144,
      "SingerName": "陈心蕊",
      "PlayUrl": "",
      "Img": ""
    },
    {
      "SongName": "中国么么哒",
      "AlbumID": "106499710",
      "FileHash": "B512361A9EBD0813C86515D28D433CCE",
      "SQFileHash": "",
      "HQFileHash": "4F8ACAD26FF6801036A1BA46382AE380",
      "MvHash": "",
      "Audioid": 395822726,
      "SingerName": "童声学院",
      "PlayUrl": "",
      "Img": ""
    }
  ],
  "time": 1733679679
}
```