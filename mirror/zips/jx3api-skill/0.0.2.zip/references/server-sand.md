> **请求说明**

此接口用于查询指定服务器的阵营沙盘据点信息，包括据点所属帮会、帮主及阵营等详细信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/server/sand
```

> **请求参数**

```json
{
  "server": "长安城"
}
```

- [√] `[server]` 指定目标区服的名称，查询该区服的沙盘据点信息。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zone": "电信区",
    "server": "长安城",
    "reset": 0,
    "update": 1733674498,
    "data": [
      {
        "tongId": 69203,
        "tongName": "犹是春闺梦里人",
        "castleId": 91,
        "castleName": "秋雨堡",
        "masterId": 26682654,
        "masterName": "小约警官",
        "campId": 2,
        "campName": "恶人谷"
      }
    ]
  },
  "time": 1733675369
}
```