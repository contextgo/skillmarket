> **请求说明**

此接口用于根据区服简称搜索主服务器及其附属服务器的详细信息。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/server/master
```

> **请求参数**

```json
{
  "name": "双梦镇"
}
```

- [√] `[name]` 指定目标区服的简称或名称，查询其主次服务器的详细信息。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "id": "0502",
    "zone": "电信区",
    "name": "梦江南",
    "column": "c",
    "duowan": {
      "浩气盟": [
        32968
      ],
      "恶人谷": [
        36911
      ]
    },
    "abbreviation": [
      "双梦镇",
      "双梦"
    ],
    "subordinate": [
      "梦江南",
      "枫泾古镇",
      "如梦令"
    ]
  },
  "time": 1723006672
}
```