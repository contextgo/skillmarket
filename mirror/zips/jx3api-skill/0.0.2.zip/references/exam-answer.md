> **请求说明**

此接口用于科举考试时的答案查询，支持模糊查询和拼音首字母查询。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/exam/answer
```

> **请求参数**

```json
{
  "subject": "古琴有几根弦",
  "limit": 1
}
```

- [×] `[subject]` 输入科举试题的题目内容，支持模糊查询或拼音首字母查询。例如输入 古琴 或 GQ。
- [×] `[limit]` 限制返回的答案数量，默认值为 10，取值范围为 1-20。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 885,
      "question": "单选题：古琴有几根弦？",
      "answer": "七根",
      "correctness": 1,
      "index": 2,
      "pinyin": "DXTGQYJGX"
    }
  ],
  "time": 1725571291
}
```
