> **请求说明**

此接口用于查询指定角色的详细信息，包括角色所属服务器、门派、阵营、帮会等内容。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/role/detailed
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "name": "夜温言@长安城",
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的角色记录。
- [√] `[name]` 指定角色名称，查询该角色的详细信息。
- [√] `[ticket]` 推栏标识，用于验证请求权限。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信区",
    "serverName": "唯我独尊",
    "roleName": "夜温言@长安城",
    "roleId": "26468709",
    "globalRoleId": "288230376159033247",
    "forceName": "万花",
    "forceId": "2",
    "bodyName": "萝莉",
    "bodyId": "6",
    "tongName": "满目星辰皆是你",
    "tongId": "40574",
    "campName": "中立",
    "campId": "0",
    "personName": "...",
    "personId": "c5153c2ea2864081b70eb915595a45ea",
    "personAvatar": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/cda8b816adf542a290c9c5722c6bfb0a/avatar.jpg/5425ad76b32940718f419d8b82d80894.jpg"
  },
  "time": 1723008167
}
```