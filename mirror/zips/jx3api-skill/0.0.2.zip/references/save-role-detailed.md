> **请求说明**

此接口用于保存或更新指定角色的详细信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/save/role/detailed
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "roleid": "26468709",
  "ticket": "...",
  "token": "..."
}
```

- [√] `[server]` 目标区服名称，用于查找对应区服的角色信息。
- [√] `[roleId]` 角色 UID，唯一标识角色的记录。
- [√] `[ticket]` 推栏标识，用于验证请求权限。
- [√] `[token]` 站点标识，用于验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信五区",
    "serverName": "唯我独尊",
    "roleName": "夜温言@长安城",
    "roleId": "26468709",
    "globalRoleId": "288230376159033247",
    "forceName": "万花",
    "forceId": "2",
    "bodyName": "萝莉",
    "bodyId": "6",
    "tongName": null,
    "tongId": null,
    "campName": "中立",
    "campId": "0",
    "personName": "",
    "personId": "c5153c2ea2864081b70eb915595a45ea",
    "personAvatar": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/cda8b816adf542a290c9c5722c6bfb0a/avatar.jpg/5425ad76b32940718f419d8b82d80894.jpg"
  },
  "time": 1713266636
}
```
