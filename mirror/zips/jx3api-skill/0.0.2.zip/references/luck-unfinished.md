> **请求说明**

此接口用于查询指定角色的未触发奇遇列表。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/luck/unfinished
```

> **请求参数**

```json
{
  "server": "梦江南",
  "name": "狸嫁",
  "ticket": "YOUR_TUILAN_tOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的相关奇遇记录。
- [√] `[name]` 指定角色名称，查询该角色的未触发奇遇。
- [×] `[ticket]` 推栏标识，用于检查奇遇记录的完整性；若未提供或输入错误，则不检查数据的完整性。请替换为您实际的推栏 Token (YOUR_TUILAN_TOKEN)。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "name": "泛天河",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "万灵当歌",
      "type": "绝世奇遇",
      "level": 2
    },
    {
      "name": "赴九幽",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "惜往日",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "韶华故",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "三尺青锋",
      "type": "绝世奇遇",
      "level": 2
    },
    {
      "name": "丹青记",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "天涯无归",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "舞众生",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "侠行囧途",
      "type": "绝世奇遇",
      "level": 2
    },
    {
      "name": "东海客",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "儿女事",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "关外商",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "兽王佩",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "北行镖",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "太行道",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "子夜歌",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "寻猫记",
      "type": "宠物奇遇",
      "level": 1
    },
    {
      "name": "少年行",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "尘网中",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "平生心愿",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "幽海牧",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "归乡路",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "归安志·安",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "归安志·归",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "念旧林",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "戎马边",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "故园风雨",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "故岁辞",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "枉叹恨",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "枫林酒",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "沧海笛",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "瀛洲梦",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "烟花戏·春",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "烟花戏·风",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "烹调法",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "白月皎",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "白雪忆",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "破晓鸣",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "秘宝图",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "童蒙志",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "红衣歌",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "缘来会·瓜",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "至尊宝",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "莫贪杯",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "重洋客",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "锋芒展",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "锻剑女",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "青草歌",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "风雨意",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "乱世舞姬",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "醉烟波",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "扶摇九天",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "一枝栖",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "镜中琴音",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "劝学记",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "流年如虹",
      "type": "绝世奇遇",
      "level": 2
    },
    {
      "name": "炼狱厨神",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "拜春擂",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "兔江湖",
      "type": "绝世奇遇",
      "level": 2
    },
    {
      "name": "度人心",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "白日梦",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "旧宴承欢",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "茶馆奇缘",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "庆舞良宵",
      "type": "世界奇遇",
      "level": 1
    },
    {
      "name": "荆轲刺",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "烟花戏·月",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "烟花戏·秋",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "谜书生",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "江湖录",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "滴水恩",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "缘来会·铃",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "胜负局",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "客江干",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "竹马情",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "捉妖记",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "沙海谣",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "稚子心",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "孩童书",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "乱红鸾",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "归安志·志",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "捉贼记",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "滇南行",
      "type": "宠物奇遇",
      "level": 3
    },
    {
      "name": "露园事",
      "type": "宠物奇遇",
      "level": 3
    }
  ],
  "time": 1735838957
}
```