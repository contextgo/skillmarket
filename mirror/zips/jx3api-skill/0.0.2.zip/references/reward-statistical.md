> **请求说明**

此接口用于统计副本掉落的贵重物品记录，包括物品名称、掉落角色和地图等详细信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/reward/statistical
```

> **请求参数**

```json
{
  "server": "长安城",
  "name": "太一玄晶",
  "limit": 10,
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的物品掉落记录。
- [√] `[name]` 指定物品名称，查询该物品的掉落记录。
- [×] `[limit]` 限制返回记录的数量，默认值为 20，可选范围为 1-100。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 523718,
      "zone": "电信区",
      "server": "长安城",
      "name": "太一玄晶",
      "role_name": "郭四月",
      "map_name": "25人普通冷龙峰",
      "source": 1,
      "time": 1728765037
    }
  ],
  "time": 1713010674
}
```