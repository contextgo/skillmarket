> **请求说明**

此接口用于查询指定角色的奇遇触发记录，包括奇遇事件、状态及触发时间。注意，数据可能存在遗漏。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/luck/adventure
```

> **请求参数**

```json
{
  "server": "梦江南",
  "name": "狸嫁",
  "ticket": "YOUR_TUILAN_tOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的相关奇遇记录。
- [√] `[name]` 指定角色名称，查询该角色的奇遇触发记录。
- [×] `[ticket]` 推栏标识，用于检查奇遇记录的完整性；若未提供或输入错误，则不检查数据的完整性。请替换为您实际的推栏 Token (YOUR_TUILAN_TOKEN)。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "zone": "电信五区",
      "server": "梦江南",
      "name": "狸嫁",
      "event": "泛天河",
      "level": 1,
      "status": 1,
      "time": 1708092604
    }
  ],
  "time": 1723011369
}
```