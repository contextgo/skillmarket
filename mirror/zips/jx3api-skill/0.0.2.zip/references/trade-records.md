> **请求说明**

此接口用于统计指定物品的黑市价格信息，包括成交、出售、收购等详细记录。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/trade/records
```

> **请求参数**

```json
{
  "server": "梦江南",
  "name": "狐金",
  "token": "YOUR_TOKEN"
}
```

- [×] `[server]` 目标区服名称，查询指定区服的记录，默认值为全区服。
- [√] `[name]` 物品名称，查询与该物品相关的价格信息。
- [√] `[token]` 站点标识，用于验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "class": "发型",
    "subclass": "金发",
    "name": "金发·璨月蝶心",
    "alias": "狐金",
    "cost": "280.00",
    "desc": "2016/04/28上架发售，不绑定限时3周。售价280。",
    "date": "2016-04-28",
    "view": "https://static.nicemoe.cn/preview/url/e7e58e651961f471a7d4d9616f98f1df9a6e0810d48b17e898620554942228d2.png",
    "list": [
      [
        {
          "id": "681601",
          "index": 541,
          "zone": "电信区",
          "server": "斗转星移",
          "value": 40000,
          "sale": 5,
          "token": "b291f22d17913d10af",
          "date": "2025-03-06",
          "source": 1,
          "status": 1
        },
        {
          "id": "681595",
          "index": 541,
          "zone": "电信区",
          "server": "斗转星移",
          "value": 41000,
          "sale": 5,
          "token": "b295fe32cf5e6e15e9",
          "date": "2025-02-26",
          "source": 1,
          "status": 1
        },
        {
          "id": "681591",
          "index": 541,
          "zone": "电信区",
          "server": "唯我独尊",
          "value": 44500,
          "sale": 5,
          "token": "b296f0c79fbb8588af",
          "date": "2025-02-21",
          "source": 1,
          "status": 1
        },
        {
          "id": "681589",
          "index": 541,
          "zone": "电信区",
          "server": "蝶恋花",
          "value": 46888,
          "sale": 5,
          "token": "b29ac13317e033d820",
          "date": "2025-02-17",
          "source": 1,
          "status": 1
        },
        {
          "id": "681586",
          "index": 541,
          "zone": "电信区",
          "server": "龙争虎斗",
          "value": 48999,
          "sale": 5,
          "token": "b299323887c7c1da03",
          "date": "2025-01-21",
          "source": 1,
          "status": 1
        },
        {
          "id": "681578",
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 56789,
          "sale": 5,
          "token": "b29ac9227961c39b03",
          "date": "2025-01-06",
          "source": 1,
          "status": 1
        },
        {
          "id": "681573",
          "index": 541,
          "zone": "电信区",
          "server": "蝶恋花",
          "value": 66666,
          "sale": 5,
          "token": "b2971ecd3204db14de",
          "date": "2024-12-05",
          "source": 1,
          "status": 1
        },
        {
          "id": "681557",
          "index": 541,
          "zone": "电信区",
          "server": "唯我独尊",
          "value": 74500,
          "sale": 5,
          "token": "b29637ae8dab2bb680",
          "date": "2024-10-31",
          "source": 1,
          "status": 1
        },
        {
          "id": "681558",
          "index": 541,
          "zone": "电信区",
          "server": "剑胆琴心",
          "value": 70400,
          "sale": 5,
          "token": "b29a5a197865f91e03",
          "date": "2024-10-25",
          "source": 1,
          "status": 1
        },
        {
          "id": "681559",
          "index": 541,
          "zone": "电信区",
          "server": "唯我独尊",
          "value": 75500,
          "sale": 5,
          "token": "b29671c392ea10be1f",
          "date": "2024-10-16",
          "source": 1,
          "status": 1
        }
      ],
      [
        {
          "id": "681600",
          "index": 541,
          "zone": "双线区",
          "server": "飞龙在天",
          "value": 41500,
          "sale": 5,
          "token": "b295538104077621de",
          "date": "2025-03-02",
          "source": 1,
          "status": 1
        },
        {
          "id": "681594",
          "index": 541,
          "zone": "双线区",
          "server": "天鹅坪",
          "value": 40000,
          "sale": 5,
          "token": "b29d587b79022a606a",
          "date": "2025-02-26",
          "source": 1,
          "status": 1
        },
        {
          "id": "681587",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 50000,
          "sale": 5,
          "token": "b290740a8522b5b80b",
          "date": "2025-01-21",
          "source": 1,
          "status": 1
        },
        {
          "id": "681576",
          "index": 541,
          "zone": "双线区",
          "server": "飞龙在天",
          "value": 62000,
          "sale": 5,
          "token": "b29226d2d639656409",
          "date": "2024-12-26",
          "source": 1,
          "status": 1
        },
        {
          "id": "681552",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 80799,
          "sale": 5,
          "token": "b295472415bcfc3605",
          "date": "2024-08-26",
          "source": 1,
          "status": 1
        },
        {
          "id": "681547",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 80000,
          "sale": 5,
          "token": "b292a93b688b21f1d4",
          "date": "2024-08-04",
          "source": 1,
          "status": 1
        },
        {
          "id": "681528",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 69999,
          "sale": 5,
          "token": "b29731b9026fb64e62",
          "date": "2024-07-27",
          "source": 1,
          "status": 1
        },
        {
          "id": "681522",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 63988,
          "sale": 5,
          "token": "b290d9ee2531f1d36c",
          "date": "2024-07-24",
          "source": 1,
          "status": 1
        },
        {
          "id": "681520",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 66666,
          "sale": 5,
          "token": "b29d03f32b5b287c1d",
          "date": "2024-07-23",
          "source": 1,
          "status": 1
        },
        {
          "id": "681505",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 56000,
          "sale": 5,
          "token": "b29793c06040170c3f",
          "date": "2024-07-11",
          "source": 1,
          "status": 1
        }
      ],
      [],
      [
        {
          "id": "1199377583960838144",
          "index": 541,
          "zone": "电信区",
          "server": "幽月轮",
          "value": 45000,
          "sale": 7,
          "remaining_time": 429105,
          "token": "b29c6622bb8ce5be0a",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1206611548544585728",
          "index": 541,
          "zone": "电信区",
          "server": "绝代天骄",
          "value": 45263,
          "sale": 7,
          "remaining_time": 215212,
          "token": "b29a6459dd351d566a",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1206564022590984192",
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 50000,
          "sale": 7,
          "remaining_time": 186504,
          "token": "b2954907e723bd3a8b",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1154765823304093696",
          "index": 541,
          "zone": "电信区",
          "server": "幽月轮",
          "value": 52000,
          "sale": 7,
          "remaining_time": 378965,
          "token": "b293d20a28f7ace7f5",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1237385259667771392",
          "index": 541,
          "zone": "电信区",
          "server": "绝代天骄",
          "value": 55555,
          "sale": 7,
          "remaining_time": 294800,
          "token": "b29fcf20f67aaec2e8",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1236744812345053184",
          "index": 541,
          "zone": "电信区",
          "server": "唯我独尊",
          "value": 55888,
          "sale": 7,
          "remaining_time": 142331,
          "token": "b29e7f3ee2fa4d46d2",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1126199117839872000",
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 60000,
          "sale": 7,
          "remaining_time": 386336,
          "token": "b29560a18cf20fda6e",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1174444152578961408",
          "index": 541,
          "zone": "电信区",
          "server": "绝代天骄",
          "value": 79999,
          "sale": 7,
          "remaining_time": 43224,
          "token": "b29ca3a34337134c17",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1211898052510633984",
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 88888,
          "sale": 7,
          "remaining_time": 79437,
          "token": "b29c1cb6731f357ba4",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        }
      ],
      [
        {
          "id": "1235131131228213248",
          "index": 541,
          "zone": "双线区",
          "server": "破阵子",
          "value": 43521,
          "sale": 6,
          "remaining_time": 792930,
          "token": "b29216dd5c5d01ebed",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1227196695843786752",
          "index": 541,
          "zone": "电信区",
          "server": "龙争虎斗",
          "value": 46999,
          "sale": 6,
          "remaining_time": 433948,
          "token": "b295812ef3c6ca06e0",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1235946062557827072",
          "index": 541,
          "zone": "电信区",
          "server": "蝶恋花",
          "value": 47000,
          "sale": 6,
          "remaining_time": 816368,
          "token": "b29e12a4bbf7524ee1",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1152163736661610496",
          "index": 541,
          "zone": "双线区",
          "server": "天鹅坪",
          "value": 48500,
          "sale": 6,
          "remaining_time": 473567,
          "token": "b298ef8b2027605e49",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1201925671864127488",
          "index": 541,
          "zone": "电信区",
          "server": "斗转星移",
          "value": 51888,
          "sale": 6,
          "remaining_time": 454992,
          "token": "b29af73f9ee1dc4db5",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1013427915476168704",
          "index": 541,
          "zone": "电信区",
          "server": "长安城",
          "value": 52000,
          "sale": 6,
          "remaining_time": 189358,
          "token": "b296f57c3e042ee4cd",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1235950501705699328",
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 52222,
          "sale": 6,
          "remaining_time": 816731,
          "token": "b2916718f7cb48dbfd",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1220330282643771392",
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 53000,
          "sale": 6,
          "remaining_time": 764834,
          "token": "b2936b29c86d417df8",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1196776087742140416",
          "index": 541,
          "zone": "双线区",
          "server": "天鹅坪",
          "value": 53222,
          "sale": 6,
          "remaining_time": 608941,
          "token": "b29e1974d5d53e1252",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        },
        {
          "id": "1220986905718484992",
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 55000,
          "sale": 6,
          "remaining_time": 100980,
          "token": "b29b256f5666f920e5",
          "date": "2025-05-09",
          "source": 4,
          "status": 1
        }
      ],
      [
        {
          "id": 681578,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 56789,
          "sale": 5,
          "token": "b29ac9227961c39b03",
          "date": "2025-01-06",
          "source": 1,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681560,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 78000,
          "sale": 5,
          "token": "b2997bfe6891f6f09a",
          "date": "2024-10-06",
          "source": 1,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681563,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 79999,
          "sale": 5,
          "token": "b293aafa1d331171ba",
          "date": "2024-09-08",
          "source": 1,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681556,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 82000,
          "sale": 5,
          "token": "b29d8697aff7c72832",
          "date": "2024-08-28",
          "source": 1,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681553,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 81999,
          "sale": 5,
          "token": "b2945df26aa84a08ad",
          "date": "2024-08-27",
          "source": 1,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681564,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 80300,
          "sale": 5,
          "token": "b29430ddef067f1309",
          "date": "2024-08-24",
          "source": 2,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681565,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 78300,
          "sale": 5,
          "token": "b2952961ff8f762b07",
          "date": "2024-08-04",
          "source": 2,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681548,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 78300,
          "sale": 5,
          "token": "b29824d26efdc22d61",
          "date": "2024-08-04",
          "source": 1,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681546,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 84500,
          "sale": 5,
          "token": "b290c93f450a5cb2ee",
          "date": "2024-08-04",
          "source": 1,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        },
        {
          "id": 681542,
          "index": 541,
          "zone": "电信区",
          "server": "梦江南",
          "value": 78300,
          "sale": 2,
          "token": "b29c870695224f6b65",
          "date": "2024-08-04",
          "source": 2,
          "status": 1,
          "datetime": "2025-03-10 00:35:20"
        }
      ]
    ]
  },
  "time": 1746759506
}
```

- **sale**：交易状态，含义如下：
    - **1**：出售
    - **2**：收购
    - **3**：想出
    - **4**：想收
    - **5**：成交
    - **6**：正出

- **data**：多层结构，含义如下：
    - **0**：电信区
    - **1**：双线区
    - **2**：无界区
    - **3**：公示期
    - **4**：正售中
    - **5**：服务器(根据`[server]`返回结果)
