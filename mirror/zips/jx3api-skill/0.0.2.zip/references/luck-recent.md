> **请求说明**

此接口用于查询指定区服中近期触发的奇遇记录，包括触发者、奇遇名称及状态等信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/luck/recent
```

> **请求参数**

```json
{
  "server": "梦江南",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的奇遇记录。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 966717,
      "zone": "电信区",
      "server": "长安城",
      "name": "小锦鲤",
      "event": "塞外宝驹",
      "status": 1,
      "time": 1733669498
    }
  ],
  "time": 1733669640
}
```