> **请求说明**

此接口用于查询名剑大会的排行榜信息，包括排名、分数、胜率等详细数据。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/arena/awesome
```

> **请求参数**

```json
{
  "mode": 33,
  "limit": 2,
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [×] `[mode]` 指定比赛模式，查询该模式的排行榜信息，默认值为 33（名剑 3v3）。
- [×] `[limit]` 限制返回记录的数量，默认值为 20，可选范围为 1-100。
- [√] `[ticket]` 推栏标识，用于验证请求权限。请替换为您的实际推栏 Token (YOUR_TUILAN_TOKEN)。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "zoneName": "电信五区",
      "serverName": "梦江南",
      "roleName": "繁声·梦江南",
      "forceName": "北天药宗",
      "avatarUrl": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/231ff921f72a48fdb241828fa2ad4d14/avatar.jpg/60c5448af6ab4c17b2bae714f9ac10c6.jpg",
      "rankNum": "1",
      "score": "3194",
      "upNum": "2",
      "winRate": "74%"
    }
  ],
  "time": 1713009239
}
```