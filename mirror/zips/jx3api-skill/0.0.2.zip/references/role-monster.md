> **请求说明**

此接口用于查询指定角色的游戏精力、耐力以及技能等级和相关信息。

> **请求权限**

```VIP2```

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/role/monster
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "name": "夜温言@长安城",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的角色记录。
- [√] `[name]` 指定角色名称，查询该角色的精耐与技能等级记录。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信区",
    "serverName": "唯我独尊",
    "roleName": "夜温言@长安城",
    "roleId": "26468709",
    "globalRoleId": "288230376159033247",
    "gameEnergy": "73960",
    "gameStamina": "76840",
    "skillCount": "99",
    "skillList": [
      {
        "bDeprecated": false,
        "dwInSkillID": 28029,
        "dwOutSkillID": 30535,
        "nColor": 6,
        "nCost": 1,
        "nLevel": 7,
        "szBossName": "冯度",
        "szSkillName": "空穴来风",
        "szType": "2;8"
      },
      {
        "bDeprecated": false,
        "dwInSkillID": 28030,
        "dwOutSkillID": 30599,
        "nColor": 2,
        "nCost": 1,
        "nLevel": 6,
        "szBossName": "上衫勇刀",
        "szSkillName": "一刀柄锤",
        "szType": "2;10;11"
      }
    ],
    "updateTime": 1724093741
  },
  "time": 1725599858
}
```