> **请求说明**

此接口用于查询指定角色在资历方面的完成分布，包括分类及子分类下的完成情况。

> **请求权限**

``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/tuilan/achievement
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "name": "夜温言@长安城",
  "class": 1,
  "subclass": "秘境",
  "ticket": "...",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 目标服务器名称，用于查询该服务器的角色数据。
- [√] `[name]` 角色名称，用于查找指定角色的资历分布信息。
- [√] `[class]` 资历主分类，整数类型。例如 1 表示某一具体分类。可选值：**1**：**江湖行**，**2**：**独步江湖**， **3**：**江湖行** + **独步江湖**
- [√] `[subclass]` 资历子分类，字符串类型。可选值：**杂闻**、**武学**、**修为**、**装备**、**技艺**、**阅读**、**任务**、**足迹**、**战斗**、**声望**、**秘境**、**帮会**、**阵营**、**节日**、**活动**、**风雨江湖路**、**家园**、**剑侠录**
- [√] `[ticket]` 推栏标识，用于验证请求权限。
- [√] `[token]` 站点标识，用于验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信区",
    "serverName": "唯我独尊",
    "roleName": "夜温言@长安城",
    "roleId": "26468709",
    "globalRoleId": "288230376159033247",
    "forceName": "万花",
    "forceId": "2",
    "bodyName": "萝莉",
    "bodyId": "6",
    "tongName": null,
    "tongId": null,
    "campName": "中立",
    "campId": "0",
    "personName": "",
    "personId": "c5153c2ea2864081b70eb915595a45ea",
    "personAvatar": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/cda8b816adf542a290c9c5722c6bfb0a/avatar.jpg/5425ad76b32940718f419d8b82d80894.jpg",
    "data": {
      "total": {
        "": {
          "pieces": {
            "total": 13,
            "speed": 8
          },
          "seniority": {
            "total": 580,
            "speed": 340
          }
        },
        "秘境总览": {
          "pieces": {
            "total": 57,
            "speed": 31
          },
          "seniority": {
            "total": 1915,
            "speed": 945
          }
        },
        "秘境任务": {
          "pieces": {
            "total": 30,
            "speed": 6
          },
          "seniority": {
            "total": 605,
            "speed": 120
          }
        },
        "风起稻香·五人秘境": {
          "pieces": {
            "total": 20,
            "speed": 20
          },
          "seniority": {
            "total": 455,
            "speed": 455
          }
        },
        "风起稻香·团队秘境": {
          "pieces": {
            "total": 12,
            "speed": 11
          },
          "seniority": {
            "total": 380,
            "speed": 350
          }
        },
        "风起稻香·五人传说": {
          "pieces": {
            "total": 17,
            "speed": 17
          },
          "seniority": {
            "total": 455,
            "speed": 455
          }
        },
        "风起稻香·团队传说": {
          "pieces": {
            "total": 15,
            "speed": 15
          },
          "seniority": {
            "total": 450,
            "speed": 450
          }
        },
        "巴蜀风云·五人秘境": {
          "pieces": {
            "total": 17,
            "speed": 16
          },
          "seniority": {
            "total": 415,
            "speed": 385
          }
        },
        "巴蜀风云·团队秘境": {
          "pieces": {
            "total": 45,
            "speed": 39
          },
          "seniority": {
            "total": 1420,
            "speed": 1225
          }
        },
        "巴蜀风云·五人传说": {
          "pieces": {
            "total": 112,
            "speed": 103
          },
          "seniority": {
            "total": 2745,
            "speed": 2530
          }
        },
        "巴蜀风云·团队传说": {
          "pieces": {
            "total": 292,
            "speed": 258
          },
          "seniority": {
            "total": 8275,
            "speed": 7265
          }
        },
        "安史之乱·五人秘境": {
          "pieces": {
            "total": 19,
            "speed": 19
          },
          "seniority": {
            "total": 445,
            "speed": 445
          }
        },
        "安史之乱·团队秘境": {
          "pieces": {
            "total": 84,
            "speed": 81
          },
          "seniority": {
            "total": 2360,
            "speed": 2275
          }
        },
        "安史之乱·五人传说": {
          "pieces": {
            "total": 69,
            "speed": 65
          },
          "seniority": {
            "total": 1625,
            "speed": 1540
          }
        },
        "安史之乱·团队传说": {
          "pieces": {
            "total": 212,
            "speed": 175
          },
          "seniority": {
            "total": 5840,
            "speed": 4790
          }
        },
        "剑胆琴心·五人秘境": {
          "pieces": {
            "total": 36,
            "speed": 36
          },
          "seniority": {
            "total": 870,
            "speed": 870
          }
        },
        "剑胆琴心·五人传说": {
          "pieces": {
            "total": 87,
            "speed": 72
          },
          "seniority": {
            "total": 2030,
            "speed": 1705
          }
        },
        "剑胆琴心·团队秘境": {
          "pieces": {
            "total": 120,
            "speed": 113
          },
          "seniority": {
            "total": 3270,
            "speed": 3075
          }
        },
        "剑胆琴心·团队传说": {
          "pieces": {
            "total": 256,
            "speed": 205
          },
          "seniority": {
            "total": 6640,
            "speed": 5345
          }
        },
        "世外蓬莱·五人秘境": {
          "pieces": {
            "total": 22,
            "speed": 19
          },
          "seniority": {
            "total": 525,
            "speed": 450
          }
        },
        "世外蓬莱·五人传说": {
          "pieces": {
            "total": 73,
            "speed": 55
          },
          "seniority": {
            "total": 1530,
            "speed": 1105
          }
        },
        "世外蓬莱·团队秘境": {
          "pieces": {
            "total": 92,
            "speed": 87
          },
          "seniority": {
            "total": 2550,
            "speed": 2460
          }
        },
        "世外蓬莱·团队传说": {
          "pieces": {
            "total": 340,
            "speed": 311
          },
          "seniority": {
            "total": 9710,
            "speed": 8910
          }
        },
        "奉天证道·五人秘境": {
          "pieces": {
            "total": 28,
            "speed": 28
          },
          "seniority": {
            "total": 660,
            "speed": 660
          }
        },
        "奉天证道·团队秘境": {
          "pieces": {
            "total": 84,
            "speed": 83
          },
          "seniority": {
            "total": 2380,
            "speed": 2350
          }
        },
        "奉天证道·团队传说": {
          "pieces": {
            "total": 232,
            "speed": 219
          },
          "seniority": {
            "total": 6595,
            "speed": 6265
          }
        },
        "奉天证道·五人传说": {
          "pieces": {
            "total": 61,
            "speed": 61
          },
          "seniority": {
            "total": 1370,
            "speed": 1370
          }
        },
        "横刀断浪·五人秘境": {
          "pieces": {
            "total": 24,
            "speed": 12
          },
          "seniority": {
            "total": 570,
            "speed": 295
          }
        },
        "横刀断浪·五人传说": {
          "pieces": {
            "total": 48,
            "speed": 23
          },
          "seniority": {
            "total": 1075,
            "speed": 555
          }
        },
        "横刀断浪·团队秘境": {
          "pieces": {
            "total": 81,
            "speed": 67
          },
          "seniority": {
            "total": 2295,
            "speed": 1905
          }
        },
        "横刀断浪·团队传说": {
          "pieces": {
            "total": 173,
            "speed": 150
          },
          "seniority": {
            "total": 5025,
            "speed": 4375
          }
        },
        "百战异闻录": {
          "pieces": {
            "total": 78,
            "speed": 72
          },
          "seniority": {
            "total": 1585,
            "speed": 1425
          }
        }
      },
      "dungeons": {
        "冷龙峰": {
          "10人普通": {
            "pieces": {
              "total": 12,
              "speed": 0
            },
            "seniority": {
              "total": 300,
              "speed": 0
            }
          },
          "25人普通": {
            "pieces": {
              "total": 19,
              "speed": 16
            },
            "seniority": {
              "total": 570,
              "speed": 480
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 24,
              "speed": 22
            },
            "seniority": {
              "total": 720,
              "speed": 660
            }
          }
        },
        "栖灵洞天·旧事": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 0
            },
            "seniority": {
              "total": 125,
              "speed": 0
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "九老洞": {
          "10人普通": {
            "pieces": {
              "total": 16,
              "speed": 16
            },
            "seniority": {
              "total": 400,
              "speed": 400
            }
          },
          "25人普通": {
            "pieces": {
              "total": 23,
              "speed": 17
            },
            "seniority": {
              "total": 690,
              "speed": 510
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 32,
              "speed": 29
            },
            "seniority": {
              "total": 960,
              "speed": 870
            }
          }
        },
        "鹿桥驿": {
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 6,
              "speed": 0
            },
            "seniority": {
              "total": 150,
              "speed": 0
            }
          }
        },
        "武狱黑牢": {
          "10人普通": {
            "pieces": {
              "total": 17,
              "speed": 16
            },
            "seniority": {
              "total": 425,
              "speed": 400
            }
          },
          "25人普通": {
            "pieces": {
              "total": 23,
              "speed": 21
            },
            "seniority": {
              "total": 690,
              "speed": 630
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 29,
              "speed": 27
            },
            "seniority": {
              "total": 870,
              "speed": 810
            }
          }
        },
        "江天夜宴": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 0
            },
            "seniority": {
              "total": 125,
              "speed": 0
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "幽藤馆": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 0
            },
            "seniority": {
              "total": 125,
              "speed": 0
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "镇海阁地井": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 0
            },
            "seniority": {
              "total": 125,
              "speed": 0
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "沃石院": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 0
            },
            "seniority": {
              "total": 125,
              "speed": 0
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "西津渡": {
          "10人普通": {
            "pieces": {
              "total": 15,
              "speed": 14
            },
            "seniority": {
              "total": 375,
              "speed": 350
            }
          },
          "25人普通": {
            "pieces": {
              "total": 20,
              "speed": 18
            },
            "seniority": {
              "total": 600,
              "speed": 540
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 24,
              "speed": 21
            },
            "seniority": {
              "total": 720,
              "speed": 630
            }
          }
        },
        "河阳之战": {
          "10人普通": {
            "pieces": {
              "total": 19,
              "speed": 19
            },
            "seniority": {
              "total": 475,
              "speed": 475
            }
          },
          "25人普通": {
            "pieces": {
              "total": 20,
              "speed": 15
            },
            "seniority": {
              "total": 600,
              "speed": 450
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 26,
              "speed": 26
            },
            "seniority": {
              "total": 780,
              "speed": 780
            }
          }
        },
        "武氏别院": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "雷域大泽": {
          "10人普通": {
            "pieces": {
              "total": 26,
              "speed": 19
            },
            "seniority": {
              "total": 625,
              "speed": 470
            }
          },
          "25人普通": {
            "pieces": {
              "total": 25,
              "speed": 24
            },
            "seniority": {
              "total": 750,
              "speed": 720
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 29,
              "speed": 29
            },
            "seniority": {
              "total": 870,
              "speed": 870
            }
          }
        },
        "漳水南路": {
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 145,
              "speed": 145
            }
          }
        },
        "白帝江关": {
          "10人普通": {
            "pieces": {
              "total": 27,
              "speed": 26
            },
            "seniority": {
              "total": 670,
              "speed": 645
            }
          },
          "25人普通": {
            "pieces": {
              "total": 29,
              "speed": 29
            },
            "seniority": {
              "total": 870,
              "speed": 870
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 36,
              "speed": 36
            },
            "seniority": {
              "total": 1080,
              "speed": 1080
            }
          }
        },
        "月落三星": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "达摩洞": {
          "10人普通": {
            "pieces": {
              "total": 20,
              "speed": 20
            },
            "seniority": {
              "total": 500,
              "speed": 500
            }
          },
          "25人普通": {
            "pieces": {
              "total": 27,
              "speed": 27
            },
            "seniority": {
              "total": 805,
              "speed": 805
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 31,
              "speed": 31
            },
            "seniority": {
              "total": 925,
              "speed": 925
            }
          }
        },
        "罗汉门": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "梧桐山庄": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "梦入集真岛": {
          "5人普通": {
            "pieces": {
              "total": 8,
              "speed": 8
            },
            "seniority": {
              "total": 165,
              "speed": 165
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 8,
              "speed": 8
            },
            "seniority": {
              "total": 200,
              "speed": 200
            }
          }
        },
        "剑冢惊变": {
          "5人普通": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 145,
              "speed": 145
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "范阳夜变": {
          "10人普通": {
            "pieces": {
              "total": 24,
              "speed": 21
            },
            "seniority": {
              "total": 595,
              "speed": 525
            }
          },
          "25人普通": {
            "pieces": {
              "total": 24,
              "speed": 24
            },
            "seniority": {
              "total": 720,
              "speed": 720
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 33,
              "speed": 31
            },
            "seniority": {
              "total": 930,
              "speed": 930
            }
          }
        },
        "玄鹤别院": {
          "5人普通": {
            "pieces": {
              "total": 4,
              "speed": 4
            },
            "seniority": {
              "total": 85,
              "speed": 85
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 4
            },
            "seniority": {
              "total": 175,
              "speed": 100
            }
          }
        },
        "敖龙岛": {
          "10人普通": {
            "pieces": {
              "total": 28,
              "speed": 27
            },
            "seniority": {
              "total": 700,
              "speed": 675
            }
          },
          "25人普通": {
            "pieces": {
              "total": 32,
              "speed": 24
            },
            "seniority": {
              "total": 960,
              "speed": 720
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 36,
              "speed": 35
            },
            "seniority": {
              "total": 1080,
              "speed": 1050
            }
          }
        },
        "周天屿": {
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 4
            },
            "seniority": {
              "total": 175,
              "speed": 100
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 7,
              "speed": 0
            },
            "seniority": {
              "total": 175,
              "speed": 0
            }
          }
        },
        "尘归海·饕餮洞": {
          "10人普通": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 175,
              "speed": 175
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 8,
              "speed": 8
            },
            "seniority": {
              "total": 240,
              "speed": 240
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 9,
              "speed": 9
            },
            "seniority": {
              "total": 270,
              "speed": 270
            }
          }
        },
        "尘归海·巨冥湾": {
          "10人普通": {
            "pieces": {
              "total": 36,
              "speed": 33
            },
            "seniority": {
              "total": 900,
              "speed": 825
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 37,
              "speed": 37
            },
            "seniority": {
              "total": 1110,
              "speed": 1110
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 38,
              "speed": 38
            },
            "seniority": {
              "total": 1140,
              "speed": 1140
            }
          }
        },
        "冰火岛·青莲狱": {
          "10人普通": {
            "pieces": {
              "total": 7,
              "speed": 4
            },
            "seniority": {
              "total": 175,
              "speed": 100
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 10,
              "speed": 0
            },
            "seniority": {
              "total": 300,
              "speed": 0
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 11,
              "speed": 11
            },
            "seniority": {
              "total": 330,
              "speed": 330
            }
          }
        },
        "迷渊岛": {
          "5人英雄": {
            "pieces": {
              "total": 11,
              "speed": 10
            },
            "seniority": {
              "total": 205,
              "speed": 180
            }
          },
          "5人普通": {
            "pieces": {
              "total": 10,
              "speed": 10
            },
            "seniority": {
              "total": 130,
              "speed": 130
            }
          }
        },
        "九辩馆": {
          "5人普通": {
            "pieces": {
              "total": 7,
              "speed": 4
            },
            "seniority": {
              "total": 140,
              "speed": 80
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 8,
              "speed": 6
            },
            "seniority": {
              "total": 200,
              "speed": 150
            }
          }
        },
        "冰火岛·荒血路": {
          "10人普通": {
            "pieces": {
              "total": 27,
              "speed": 24
            },
            "seniority": {
              "total": 685,
              "speed": 610
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 32,
              "speed": 32
            },
            "seniority": {
              "total": 960,
              "speed": 960
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 32,
              "speed": 32
            },
            "seniority": {
              "total": 960,
              "speed": 960
            }
          }
        },
        "镜泊湖": {
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 5
            },
            "seniority": {
              "total": 120,
              "speed": 100
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "大衍盘丝洞": {
          "5人普通": {
            "pieces": {
              "total": 5,
              "speed": 4
            },
            "seniority": {
              "total": 100,
              "speed": 80
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "泥兰洞天": {
          "5人普通": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 100,
              "speed": 100
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "狼牙堡·狼神殿": {
          "10人普通": {
            "pieces": {
              "total": 18,
              "speed": 15
            },
            "seniority": {
              "total": 365,
              "speed": 315
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 16,
              "speed": 8
            },
            "seniority": {
              "total": 310,
              "speed": 175
            }
          }
        },
        "狼牙堡·辉天堑": {
          "10人普通": {
            "pieces": {
              "total": 27,
              "speed": 24
            },
            "seniority": {
              "total": 625,
              "speed": 545
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 26,
              "speed": 26
            },
            "seniority": {
              "total": 635,
              "speed": 635
            }
          }
        },
        "稻香秘事": {
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 155,
              "speed": 155
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          }
        },
        "银雾湖": {
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 6
            },
            "seniority": {
              "total": 160,
              "speed": 130
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 6,
              "speed": 5
            },
            "seniority": {
              "total": 150,
              "speed": 125
            }
          }
        },
        "狼牙堡·燕然峰": {
          "10人普通": {
            "pieces": {
              "total": 8,
              "speed": 7
            },
            "seniority": {
              "total": 200,
              "speed": 175
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 10,
              "speed": 8
            },
            "seniority": {
              "total": 300,
              "speed": 240
            }
          }
        },
        "狼牙堡·战兽山": {
          "10人普通": {
            "pieces": {
              "total": 19,
              "speed": 12
            },
            "seniority": {
              "total": 475,
              "speed": 300
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 20,
              "speed": 12
            },
            "seniority": {
              "total": 600,
              "speed": 360
            }
          }
        },
        "风雷刀谷·千雷殿": {
          "10人普通": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 175,
              "speed": 175
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 7,
              "speed": 6
            },
            "seniority": {
              "total": 210,
              "speed": 180
            }
          }
        },
        "风雷刀谷·锻刀厅": {
          "10人普通": {
            "pieces": {
              "total": 18,
              "speed": 17
            },
            "seniority": {
              "total": 450,
              "speed": 425
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 16,
              "speed": 14
            },
            "seniority": {
              "total": 480,
              "speed": 420
            }
          }
        },
        "刀轮海厅": {
          "5人英雄": {
            "pieces": {
              "total": 11,
              "speed": 9
            },
            "seniority": {
              "total": 280,
              "speed": 225
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 11,
              "speed": 9
            },
            "seniority": {
              "total": 275,
              "speed": 225
            }
          }
        },
        "夕颜阁": {
          "5人普通": {
            "pieces": {
              "total": 4,
              "speed": 1
            },
            "seniority": {
              "total": 80,
              "speed": 20
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "白帝水宫": {
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 175,
              "speed": 175
            }
          }
        },
        "上阳宫·双曜亭": {
          "10人普通": {
            "pieces": {
              "total": 9,
              "speed": 5
            },
            "seniority": {
              "total": 225,
              "speed": 125
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 13,
              "speed": 11
            },
            "seniority": {
              "total": 390,
              "speed": 330
            }
          }
        },
        "上阳宫·观风殿": {
          "10人普通": {
            "pieces": {
              "total": 15,
              "speed": 9
            },
            "seniority": {
              "total": 375,
              "speed": 225
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 20,
              "speed": 14
            },
            "seniority": {
              "total": 600,
              "speed": 420
            }
          }
        },
        "永王行宫·花月别院": {
          "10人普通": {
            "pieces": {
              "total": 9,
              "speed": 8
            },
            "seniority": {
              "total": 225,
              "speed": 200
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 12,
              "speed": 12
            },
            "seniority": {
              "total": 360,
              "speed": 360
            }
          },
          "10人挑战": {
            "pieces": {
              "total": 11,
              "speed": 11
            },
            "seniority": {
              "total": 275,
              "speed": 275
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 12,
              "speed": 10
            },
            "seniority": {
              "total": 360,
              "speed": 300
            }
          }
        },
        "永王行宫·仙侣庭园": {
          "10人普通": {
            "pieces": {
              "total": 19,
              "speed": 19
            },
            "seniority": {
              "total": 475,
              "speed": 475
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 20,
              "speed": 20
            },
            "seniority": {
              "total": 600,
              "speed": 600
            }
          },
          "10人挑战": {
            "pieces": {
              "total": 21,
              "speed": 21
            },
            "seniority": {
              "total": 525,
              "speed": 525
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 22,
              "speed": 21
            },
            "seniority": {
              "total": 660,
              "speed": 630
            }
          }
        },
        "微山书院": {
          "5人普通": {
            "pieces": {
              "total": 4,
              "speed": 3
            },
            "seniority": {
              "total": 80,
              "speed": 60
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "引仙水榭": {
          "5人普通": {
            "pieces": {
              "total": 4,
              "speed": 1
            },
            "seniority": {
              "total": 80,
              "speed": 20
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "梵空禅院": {
          "5人普通": {
            "pieces": {
              "total": 7,
              "speed": 6
            },
            "seniority": {
              "total": 140,
              "speed": 120
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 8,
              "speed": 7
            },
            "seniority": {
              "total": 200,
              "speed": 175
            }
          }
        },
        "阴山圣泉": {
          "5人普通": {
            "pieces": {
              "total": 4,
              "speed": 2
            },
            "seniority": {
              "total": 80,
              "speed": 40
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "天泣林": {
          "5人普通": {
            "pieces": {
              "total": 4,
              "speed": 4
            },
            "seniority": {
              "total": 80,
              "speed": 80
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "璨翠海厅": {
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 5
            },
            "seniority": {
              "total": 95,
              "speed": 80
            }
          },
          "5人挑战": {
            "pieces": {
              "total": 6,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 105
            }
          }
        },
        "雁门关之役": {
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 175,
              "speed": 175
            }
          },
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "太原之战·逐虎驱狼": {
          "10人普通": {
            "pieces": {
              "total": 13,
              "speed": 11
            },
            "seniority": {
              "total": 330,
              "speed": 280
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 13,
              "speed": 11
            },
            "seniority": {
              "total": 390,
              "speed": 330
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 13,
              "speed": 10
            },
            "seniority": {
              "total": 410,
              "speed": 320
            }
          },
          "10人挑战": {
            "pieces": {
              "total": 13,
              "speed": 11
            },
            "seniority": {
              "total": 330,
              "speed": 280
            }
          }
        },
        "太原之战·夜守孤城": {
          "10人普通": {
            "pieces": {
              "total": 10,
              "speed": 10
            },
            "seniority": {
              "total": 255,
              "speed": 255
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 10,
              "speed": 7
            },
            "seniority": {
              "total": 300,
              "speed": 210
            }
          },
          "25人挑战": {
            "pieces": {
              "total": 9,
              "speed": 5
            },
            "seniority": {
              "total": 270,
              "speed": 150
            }
          },
          "10人挑战": {
            "pieces": {
              "total": 10,
              "speed": 10
            },
            "seniority": {
              "total": 255,
              "speed": 255
            }
          }
        },
        "春明门": {
          "5人英雄": {
            "pieces": {
              "total": 9,
              "speed": 7
            },
            "seniority": {
              "total": 240,
              "speed": 175
            }
          }
        },
        "墨家秘殿": {
          "5人英雄": {
            "pieces": {
              "total": 9,
              "speed": 7
            },
            "seniority": {
              "total": 240,
              "speed": 175
            }
          }
        },
        "秦皇陵": {
          "10人普通": {
            "pieces": {
              "total": 14,
              "speed": 13
            },
            "seniority": {
              "total": 355,
              "speed": 330
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 14,
              "speed": 14
            },
            "seniority": {
              "total": 420,
              "speed": 420
            }
          }
        },
        "直城门": {
          "5人英雄": {
            "pieces": {
              "total": 10,
              "speed": 7
            },
            "seniority": {
              "total": 265,
              "speed": 175
            }
          }
        },
        "风雪稻香村": {
          "10人普通": {
            "pieces": {
              "total": 21,
              "speed": 19
            },
            "seniority": {
              "total": 530,
              "speed": 480
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 13,
              "speed": 7
            },
            "seniority": {
              "total": 390,
              "speed": 210
            }
          }
        },
        "血战天策": {
          "10人普通": {
            "pieces": {
              "total": 30,
              "speed": 30
            },
            "seniority": {
              "total": 755,
              "speed": 755
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 31,
              "speed": 30
            },
            "seniority": {
              "total": 930,
              "speed": 900
            }
          }
        },
        "流离岛": {
          "5人普通": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 100,
              "speed": 100
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 5,
              "speed": 5
            },
            "seniority": {
              "total": 125,
              "speed": 125
            }
          }
        },
        "大明宫": {
          "10人普通": {
            "pieces": {
              "total": 25,
              "speed": 20
            },
            "seniority": {
              "total": 635,
              "speed": 510
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 25,
              "speed": 22
            },
            "seniority": {
              "total": 750,
              "speed": 660
            }
          }
        },
        "华清宫回忆录": {
          "5人英雄": {
            "pieces": {
              "total": 9,
              "speed": 8
            },
            "seniority": {
              "total": 240,
              "speed": 215
            }
          }
        },
        "华清宫": {
          "5人普通": {
            "pieces": {
              "total": 8,
              "speed": 8
            },
            "seniority": {
              "total": 200,
              "speed": 200
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 8,
              "speed": 8
            },
            "seniority": {
              "total": 200,
              "speed": 200
            }
          }
        },
        "战宝军械库": {
          "10人普通": {
            "pieces": {
              "total": 16,
              "speed": 14
            },
            "seniority": {
              "total": 415,
              "speed": 360
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 16,
              "speed": 12
            },
            "seniority": {
              "total": 480,
              "speed": 360
            }
          }
        },
        "一线天": {
          "5人英雄": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 150,
              "speed": 150
            }
          },
          "5人普通": {
            "pieces": {
              "total": 2,
              "speed": 2
            },
            "seniority": {
              "total": 50,
              "speed": 50
            }
          }
        },
        "光明顶秘道": {
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 3
            },
            "seniority": {
              "total": 175,
              "speed": 75
            }
          },
          "5人普通": {
            "pieces": {
              "total": 6,
              "speed": 4
            },
            "seniority": {
              "total": 120,
              "speed": 80
            }
          }
        },
        "南诏皇宫": {
          "10人普通": {
            "pieces": {
              "total": 19,
              "speed": 19
            },
            "seniority": {
              "total": 485,
              "speed": 485
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 29,
              "speed": 26
            },
            "seniority": {
              "total": 865,
              "speed": 775
            }
          }
        },
        "会战唐门": {
          "10人普通": {
            "pieces": {
              "total": 14,
              "speed": 14
            },
            "seniority": {
              "total": 360,
              "speed": 360
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 14,
              "speed": 14
            },
            "seniority": {
              "total": 425,
              "speed": 425
            }
          }
        },
        "烛龙殿": {
          "25人英雄": {
            "pieces": {
              "total": 20,
              "speed": 20
            },
            "seniority": {
              "total": 610,
              "speed": 610
            }
          },
          "10人普通": {
            "pieces": {
              "total": 19,
              "speed": 18
            },
            "seniority": {
              "total": 480,
              "speed": 455
            }
          }
        },
        "持国天王回忆录": {
          "10人普通": {
            "pieces": {
              "total": 15,
              "speed": 10
            },
            "seniority": {
              "total": 385,
              "speed": 255
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 17,
              "speed": 4
            },
            "seniority": {
              "total": 510,
              "speed": 120
            }
          }
        },
        "唐门密室": {
          "5人普通": {
            "pieces": {
              "total": 9,
              "speed": 9
            },
            "seniority": {
              "total": 190,
              "speed": 190
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 9,
              "speed": 5
            },
            "seniority": {
              "total": 230,
              "speed": 125
            }
          }
        },
        "荻花洞窟": {
          "10人普通": {
            "pieces": {
              "total": 6,
              "speed": 6
            },
            "seniority": {
              "total": 155,
              "speed": 155
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 6,
              "speed": 4
            },
            "seniority": {
              "total": 185,
              "speed": 125
            }
          }
        },
        "寂灭厅": {
          "5人普通": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 180,
              "speed": 180
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 180,
              "speed": 180
            }
          }
        },
        "龙渊泽": {
          "10人普通": {
            "pieces": {
              "total": 15,
              "speed": 15
            },
            "seniority": {
              "total": 380,
              "speed": 380
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 15,
              "speed": 15
            },
            "seniority": {
              "total": 460,
              "speed": 460
            }
          },
          "25人普通": {
            "pieces": {
              "total": 15,
              "speed": 15
            },
            "seniority": {
              "total": 455,
              "speed": 455
            }
          },
          "10人英雄": {
            "pieces": {
              "total": 15,
              "speed": 15
            },
            "seniority": {
              "total": 455,
              "speed": 455
            }
          }
        },
        "无量宫": {
          "5人普通": {
            "pieces": {
              "total": 8,
              "speed": 8
            },
            "seniority": {
              "total": 200,
              "speed": 200
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 7,
              "speed": 7
            },
            "seniority": {
              "total": 175,
              "speed": 175
            }
          }
        },
        "法王窟": {
          "5人普通": {
            "pieces": {
              "total": 11,
              "speed": 11
            },
            "seniority": {
              "total": 275,
              "speed": 275
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 11,
              "speed": 11
            },
            "seniority": {
              "total": 275,
              "speed": 275
            }
          }
        },
        "毒神殿": {
          "5人普通": {
            "pieces": {
              "total": 9,
              "speed": 9
            },
            "seniority": {
              "total": 225,
              "speed": 225
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 9,
              "speed": 9
            },
            "seniority": {
              "total": 225,
              "speed": 225
            }
          }
        },
        "仙踪林": {
          "5人普通": {
            "pieces": {
              "total": 9,
              "speed": 9
            },
            "seniority": {
              "total": 225,
              "speed": 225
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 9,
              "speed": 9
            },
            "seniority": {
              "total": 225,
              "speed": 225
            }
          },
          "历程5人普通": {
            "pieces": {
              "total": 9,
              "speed": 9
            },
            "seniority": {
              "total": 180,
              "speed": 180
            }
          }
        },
        "荻花圣殿": {
          "10人普通": {
            "pieces": {
              "total": 30,
              "speed": 28
            },
            "seniority": {
              "total": 775,
              "speed": 715
            }
          },
          "10人英雄": {
            "pieces": {
              "total": 28,
              "speed": 22
            },
            "seniority": {
              "total": 860,
              "speed": 670
            }
          },
          "25人普通": {
            "pieces": {
              "total": 31,
              "speed": 25
            },
            "seniority": {
              "total": 940,
              "speed": 760
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 27,
              "speed": 27
            },
            "seniority": {
              "total": 830,
              "speed": 830
            }
          }
        },
        "荻花宫后山": {
          "10人普通": {
            "pieces": {
              "total": 2,
              "speed": 1
            },
            "seniority": {
              "total": 60,
              "speed": 30
            }
          },
          "10人英雄": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 90,
              "speed": 90
            }
          }
        },
        "宫中神武遗迹": {
          "10人普通": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 90,
              "speed": 90
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 95,
              "speed": 95
            }
          },
          "25人普通": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 90,
              "speed": 90
            }
          }
        },
        "持国天王殿": {
          "10人普通": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 90,
              "speed": 90
            }
          },
          "25人普通": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 90,
              "speed": 90
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 95,
              "speed": 95
            }
          }
        },
        "剑冢": {
          "5人普通": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 20,
              "speed": 20
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 25,
              "speed": 25
            }
          }
        },
        "风雨稻香村": {
          "5人普通": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 20,
              "speed": 20
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 2,
              "speed": 2
            },
            "seniority": {
              "total": 55,
              "speed": 55
            }
          }
        },
        "天子峰": {
          "5人普通": {
            "pieces": {
              "total": 20,
              "speed": 1
            },
            "seniority": {
              "total": 405,
              "speed": 25
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 4,
              "speed": 4
            },
            "seniority": {
              "total": 95,
              "speed": 95
            }
          }
        },
        "战宝迦兰": {
          "10人普通": {
            "pieces": {
              "total": 2,
              "speed": 2
            },
            "seniority": {
              "total": 60,
              "speed": 60
            }
          },
          "25人英雄": {
            "pieces": {
              "total": 3,
              "speed": 2
            },
            "seniority": {
              "total": 95,
              "speed": 70
            }
          }
        },
        "日轮山城": {
          "5人普通": {
            "pieces": {
              "total": 5,
              "speed": 4
            },
            "seniority": {
              "total": 110,
              "speed": 90
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 4,
              "speed": 4
            },
            "seniority": {
              "total": 115,
              "speed": 115
            }
          }
        },
        "荻花宫前山": {
          "5人普通": {
            "pieces": {
              "total": 3,
              "speed": 2
            },
            "seniority": {
              "total": 60,
              "speed": 40
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 4,
              "speed": 4
            },
            "seniority": {
              "total": 100,
              "speed": 100
            }
          }
        },
        "天地三才阵": {
          "5人普通": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 20,
              "speed": 20
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 25,
              "speed": 25
            }
          }
        },
        "空雾峰": {
          "5人普通": {
            "pieces": {
              "total": 2,
              "speed": 2
            },
            "seniority": {
              "total": 40,
              "speed": 40
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 2,
              "speed": 2
            },
            "seniority": {
              "total": 55,
              "speed": 55
            }
          }
        },
        "无盐岛": {
          "5人普通": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 60,
              "speed": 60
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 25,
              "speed": 25
            }
          }
        },
        "天工坊": {
          "5人普通": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 20,
              "speed": 20
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 1,
              "speed": 1
            },
            "seniority": {
              "total": 25,
              "speed": 25
            }
          }
        },
        "灵霄峡": {
          "5人普通": {
            "pieces": {
              "total": 3,
              "speed": 3
            },
            "seniority": {
              "total": 60,
              "speed": 60
            }
          },
          "5人英雄": {
            "pieces": {
              "total": 2,
              "speed": 2
            },
            "seniority": {
              "total": 55,
              "speed": 55
            }
          }
        }
      },
      "maps": {
        "稻香村": {
          "pieces": {
            "total": 11,
            "speed": 0
          },
          "seniority": {
            "total": 190,
            "speed": 0
          }
        },
        "稻香村·前尘": {
          "pieces": {
            "total": 9,
            "speed": 9
          },
          "seniority": {
            "total": 150,
            "speed": 150
          }
        },
        "浩气盟": {
          "pieces": {
            "total": 22,
            "speed": 19
          },
          "seniority": {
            "total": 710,
            "speed": 605
          }
        },
        "恶人谷": {
          "pieces": {
            "total": 21,
            "speed": 13
          },
          "seniority": {
            "total": 680,
            "speed": 395
          }
        },
        "扬州": {
          "pieces": {
            "total": 24,
            "speed": 11
          },
          "seniority": {
            "total": 595,
            "speed": 195
          }
        },
        "洛阳城": {
          "pieces": {
            "total": 21,
            "speed": 10
          },
          "seniority": {
            "total": 560,
            "speed": 240
          }
        },
        "太原": {
          "pieces": {
            "total": 23,
            "speed": 16
          },
          "seniority": {
            "total": 645,
            "speed": 420
          }
        },
        "长安城": {
          "pieces": {
            "total": 30,
            "speed": 12
          },
          "seniority": {
            "total": 765,
            "speed": 285
          }
        },
        "成都": {
          "pieces": {
            "total": 12,
            "speed": 11
          },
          "seniority": {
            "total": 255,
            "speed": 235
          }
        },
        "侠客岛": {
          "pieces": {
            "total": 29,
            "speed": 17
          },
          "seniority": {
            "total": 715,
            "speed": 410
          }
        },
        "洛阳": {
          "pieces": {
            "total": 23,
            "speed": 16
          },
          "seniority": {
            "total": 555,
            "speed": 315
          }
        },
        "长安": {
          "pieces": {
            "total": 12,
            "speed": 10
          },
          "seniority": {
            "total": 275,
            "speed": 205
          }
        },
        "枫华谷": {
          "pieces": {
            "total": 7,
            "speed": 7
          },
          "seniority": {
            "total": 140,
            "speed": 140
          }
        },
        "藏剑山庄": {
          "pieces": {
            "total": 16,
            "speed": 7
          },
          "seniority": {
            "total": 325,
            "speed": 140
          }
        },
        "刀宗": {
          "pieces": {
            "total": 16,
            "speed": 7
          },
          "seniority": {
            "total": 325,
            "speed": 150
          }
        },
        "七秀": {
          "pieces": {
            "total": 15,
            "speed": 5
          },
          "seniority": {
            "total": 310,
            "speed": 100
          }
        },
        "五毒": {
          "pieces": {
            "total": 20,
            "speed": 8
          },
          "seniority": {
            "total": 425,
            "speed": 170
          }
        },
        "少林": {
          "pieces": {
            "total": 15,
            "speed": 6
          },
          "seniority": {
            "total": 310,
            "speed": 125
          }
        },
        "苍云": {
          "pieces": {
            "total": 24,
            "speed": 13
          },
          "seniority": {
            "total": 495,
            "speed": 255
          }
        },
        "蓬莱": {
          "pieces": {
            "total": 15,
            "speed": 6
          },
          "seniority": {
            "total": 305,
            "speed": 115
          }
        },
        "天策": {
          "pieces": {
            "total": 15,
            "speed": 8
          },
          "seniority": {
            "total": 325,
            "speed": 175
          }
        },
        "万花": {
          "pieces": {
            "total": 16,
            "speed": 13
          },
          "seniority": {
            "total": 330,
            "speed": 270
          }
        },
        "霸刀山庄": {
          "pieces": {
            "total": 21,
            "speed": 11
          },
          "seniority": {
            "total": 440,
            "speed": 220
          }
        },
        "唐门": {
          "pieces": {
            "total": 17,
            "speed": 9
          },
          "seniority": {
            "total": 350,
            "speed": 175
          }
        },
        "衍天宗": {
          "pieces": {
            "total": 16,
            "speed": 7
          },
          "seniority": {
            "total": 325,
            "speed": 150
          }
        },
        "纯阳": {
          "pieces": {
            "total": 17,
            "speed": 9
          },
          "seniority": {
            "total": 350,
            "speed": 180
          }
        },
        "丐帮": {
          "pieces": {
            "total": 22,
            "speed": 10
          },
          "seniority": {
            "total": 445,
            "speed": 190
          }
        },
        "凌雪阁": {
          "pieces": {
            "total": 16,
            "speed": 6
          },
          "seniority": {
            "total": 325,
            "speed": 115
          }
        },
        "北天药宗": {
          "pieces": {
            "total": 16,
            "speed": 6
          },
          "seniority": {
            "total": 325,
            "speed": 115
          }
        },
        "万灵山庄": {
          "pieces": {
            "total": 16,
            "speed": 4
          },
          "seniority": {
            "total": 325,
            "speed": 85
          }
        },
        "明教": {
          "pieces": {
            "total": 20,
            "speed": 10
          },
          "seniority": {
            "total": 420,
            "speed": 205
          }
        },
        "长歌门": {
          "pieces": {
            "total": 19,
            "speed": 12
          },
          "seniority": {
            "total": 375,
            "speed": 225
          }
        },
        "帮会领地": {
          "pieces": {
            "total": 49,
            "speed": 31
          },
          "seniority": {
            "total": 1585,
            "speed": 710
          }
        },
        "阴山大草原": {
          "pieces": {
            "total": 29,
            "speed": 12
          },
          "seniority": {
            "total": 705,
            "speed": 290
          }
        },
        "五台山": {
          "pieces": {
            "total": 19,
            "speed": 11
          },
          "seniority": {
            "total": 455,
            "speed": 255
          }
        },
        "洛道": {
          "pieces": {
            "total": 15,
            "speed": 13
          },
          "seniority": {
            "total": 345,
            "speed": 280
          }
        },
        "经首道源岛": {
          "pieces": {
            "total": 23,
            "speed": 13
          },
          "seniority": {
            "total": 540,
            "speed": 280
          }
        },
        "少林·乱世": {
          "pieces": {
            "total": 15,
            "speed": 11
          },
          "seniority": {
            "total": 335,
            "speed": 240
          }
        },
        "银霜口": {
          "pieces": {
            "total": 20,
            "speed": 16
          },
          "seniority": {
            "total": 405,
            "speed": 325
          }
        },
        "枫华谷·战乱": {
          "pieces": {
            "total": 13,
            "speed": 7
          },
          "seniority": {
            "total": 330,
            "speed": 170
          }
        },
        "长安·战乱": {
          "pieces": {
            "total": 13,
            "speed": 9
          },
          "seniority": {
            "total": 325,
            "speed": 220
          }
        },
        "黑龙沼": {
          "pieces": {
            "total": 10,
            "speed": 9
          },
          "seniority": {
            "total": 220,
            "speed": 200
          }
        },
        "瞿塘峡": {
          "pieces": {
            "total": 49,
            "speed": 31
          },
          "seniority": {
            "total": 1100,
            "speed": 675
          }
        },
        "广陵邑": {
          "pieces": {
            "total": 18,
            "speed": 18
          },
          "seniority": {
            "total": 505,
            "speed": 505
          }
        },
        "万花·乱世": {
          "pieces": {
            "total": 13,
            "speed": 12
          },
          "seniority": {
            "total": 295,
            "speed": 260
          }
        },
        "马嵬驿": {
          "pieces": {
            "total": 16,
            "speed": 15
          },
          "seniority": {
            "total": 400,
            "speed": 365
          }
        },
        "天策·战乱": {
          "pieces": {
            "total": 15,
            "speed": 14
          },
          "seniority": {
            "total": 365,
            "speed": 345
          }
        },
        "金水镇": {
          "pieces": {
            "total": 11,
            "speed": 9
          },
          "seniority": {
            "total": 255,
            "speed": 190
          }
        },
        "千岛湖": {
          "pieces": {
            "total": 21,
            "speed": 15
          },
          "seniority": {
            "total": 505,
            "speed": 335
          }
        },
        "烂柯山": {
          "pieces": {
            "total": 10,
            "speed": 9
          },
          "seniority": {
            "total": 200,
            "speed": 180
          }
        },
        "南屏山": {
          "pieces": {
            "total": 9,
            "speed": 9
          },
          "seniority": {
            "total": 225,
            "speed": 225
          }
        },
        "无量山": {
          "pieces": {
            "total": 15,
            "speed": 13
          },
          "seniority": {
            "total": 345,
            "speed": 290
          }
        },
        "九寨沟": {
          "pieces": {
            "total": 1,
            "speed": 1
          },
          "seniority": {
            "total": 20,
            "speed": 20
          }
        },
        "巴陵县": {
          "pieces": {
            "total": 8,
            "speed": 8
          },
          "seniority": {
            "total": 195,
            "speed": 195
          }
        },
        "七秀·乱世": {
          "pieces": {
            "total": 13,
            "speed": 4
          },
          "seniority": {
            "total": 295,
            "speed": 95
          }
        },
        "龙泉府": {
          "pieces": {
            "total": 18,
            "speed": 12
          },
          "seniority": {
            "total": 420,
            "speed": 250
          }
        },
        "寇岛": {
          "pieces": {
            "total": 16,
            "speed": 14
          },
          "seniority": {
            "total": 425,
            "speed": 360
          }
        },
        "赤岬山城": {
          "pieces": {
            "total": 1,
            "speed": 0
          },
          "seniority": {
            "total": 30,
            "speed": 0
          }
        },
        "蔷薇列岛": {
          "pieces": {
            "total": 18,
            "speed": 14
          },
          "seniority": {
            "total": 425,
            "speed": 305
          }
        },
        "藏剑山庄·乱世": {
          "pieces": {
            "total": 19,
            "speed": 15
          },
          "seniority": {
            "total": 465,
            "speed": 345
          }
        },
        "昆仑": {
          "pieces": {
            "total": 9,
            "speed": 9
          },
          "seniority": {
            "total": 220,
            "speed": 220
          }
        },
        "鲲鹏岛": {
          "pieces": {
            "total": 23,
            "speed": 15
          },
          "seniority": {
            "total": 570,
            "speed": 310
          }
        },
        "河阳": {
          "pieces": {
            "total": 1,
            "speed": 0
          },
          "seniority": {
            "total": 20,
            "speed": 0
          }
        },
        "浣花水榭": {
          "pieces": {
            "total": 1,
            "speed": 0
          },
          "seniority": {
            "total": 15,
            "speed": 0
          }
        },
        "洞天福地岛": {
          "pieces": {
            "total": 19,
            "speed": 6
          },
          "seniority": {
            "total": 440,
            "speed": 130
          }
        },
        "融天岭": {
          "pieces": {
            "total": 10,
            "speed": 9
          },
          "seniority": {
            "total": 225,
            "speed": 205
          }
        },
        "苍山洱海": {
          "pieces": {
            "total": 10,
            "speed": 3
          },
          "seniority": {
            "total": 245,
            "speed": 75
          }
        },
        "跨服·烂柯山": {
          "pieces": {
            "total": 11,
            "speed": 8
          },
          "seniority": {
            "total": 325,
            "speed": 230
          }
        },
        "黑山林海": {
          "pieces": {
            "total": 21,
            "speed": 3
          },
          "seniority": {
            "total": 490,
            "speed": 65
          }
        },
        "楚州": {
          "pieces": {
            "total": 10,
            "speed": 8
          },
          "seniority": {
            "total": 200,
            "speed": 160
          }
        },
        "九寨沟·镜海": {
          "pieces": {
            "total": 1,
            "speed": 1
          },
          "seniority": {
            "total": 15,
            "speed": 15
          }
        },
        "百溪": {
          "pieces": {
            "total": 8,
            "speed": 8
          },
          "seniority": {
            "total": 160,
            "speed": 160
          }
        },
        "晟江": {
          "pieces": {
            "total": 11,
            "speed": 9
          },
          "seniority": {
            "total": 220,
            "speed": 180
          }
        },
        "洛阳·战乱": {
          "pieces": {
            "total": 21,
            "speed": 15
          },
          "seniority": {
            "total": 520,
            "speed": 355
          }
        },
        "私邸宅园": {
          "pieces": {
            "total": 34,
            "speed": 11
          },
          "seniority": {
            "total": 590,
            "speed": 135
          }
        },
        "白龙口": {
          "pieces": {
            "total": 9,
            "speed": 8
          },
          "seniority": {
            "total": 195,
            "speed": 175
          }
        },
        "黑戈壁": {
          "pieces": {
            "total": 25,
            "speed": 16
          },
          "seniority": {
            "total": 595,
            "speed": 350
          }
        },
        "龙门荒漠": {
          "pieces": {
            "total": 10,
            "speed": 10
          },
          "seniority": {
            "total": 245,
            "speed": 245
          }
        }
      },
      "score": 123435,
      "totalScore": 199480
    }
  },
  "time": 1733678896
}
```