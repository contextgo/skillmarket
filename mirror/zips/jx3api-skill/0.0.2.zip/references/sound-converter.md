> **请求说明**

此接口基于阿里云 TTS 服务，通过输入文本生成语音内容。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/sound/converter
```

> **请求参数**

```json
{
  "appkey": "...",
  "access": "...",
  "secret": "...",
  "voice": "Aitong",
  "format": "mp3",
  "sample_rate": 16000,
  "volume": 50,
  "speech_rate": 0,
  "pitch_rate": 0,
  "text": "剑网三真好玩儿！"
}
```

- [√] `[appkey]` 阿里云应用标识 [点击申请](https://nls-portal.console.aliyun.com/overview)。
- [√] `[access]` 阿里云 Access Key [点击申请](https://usercenter.console.aliyun.com)。
- [√] `[secret]` 阿里云 Secret Key [点击申请](https://usercenter.console.aliyun.com)。
- [×] ``[voice]`` 发音人名称，默认值： Aitong，[点击查看](https://help.aliyun.com/knowledge_detail/84435.html?spm=a2c4g.11186631.2.1.67045663WlpL4n)。
- [×] ``[format]`` 音频格式，支持 PCM、WAV 和 MP3。默认值：MP3。
- [×] ``[sample_rate]`` 音频采样率，支持 8000 和 16000。默认值：16000。
- [×] ``[volume]`` 音量大小，范围为 0 到 100。默认值：50。
- [×] ``[speech_rate]`` 语速调节，范围为 -500 到 500。默认值：0。
- [×] `[pitch_rate]` 音调调节，范围为 -500 到 500。默认值：0。
- [√] ``[text]`` 待合成的文本内容。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "text": "剑网三真好玩儿",
    "token": "60573f1203ed4774a44ba47ea8273ef3",
    "url": "https://nls-gateway.cn-shanghai.aliyuncs.com/stream/v1/tts?appkey=usTUQnlSuPRzMaw6&token=60573f1203ed4774a44ba47ea8273ef3&format=mp3&voice=Aitong&sample_rate=16000&speech_rate=0&volume=50&pitch_rate=0&text=%E5%89%91%E7%BD%91%E4%B8%89%E7%9C%9F%E5%A5%BD%E7%8E%A9%E5%84%BF"
  },
  "time": 1713010443
}
```