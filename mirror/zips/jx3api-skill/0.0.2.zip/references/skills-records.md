> **请求说明**

此接口用于查询技能的历史修改记录，包括资料片更新、技能调整等信息。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/skills/records
```

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": "1334209",
      "title": "11月21日“丝路风语”资料片武学调整",
      "url": "https://jx3.xoyo.com/announce/gg.html?id=1334209",
      "time": "2024-11-20 23:06:15"
    }
  ],
  "time": 1733668273
}
```