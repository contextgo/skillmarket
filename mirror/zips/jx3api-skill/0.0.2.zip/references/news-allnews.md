> **请求说明**

此接口用于获取官方最新公告及新闻内容，包括新闻分类、标题及链接等信息。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/news/allnews

```

> **请求参数**

```json
{
  "limit": 1
}

```

- [×] `[limit]` 限制返回的新闻条数，默认值为 10，可选范围为 1-50。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 2612,
      "token": 1334243,
      "class": "官方公告",
      "title": "12月9日例行维护公告",
      "date": "12/08",
      "url": "https://jx3.xoyo.com/announce/gg.html?id=1334243"
    }
  ],
  "time": 1733665940
}
```