> **请求说明**

此接口用于统计角色近期的名剑战绩数据，包含不同门派的表现对比。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/arena/schools
```

> **请求参数**

```json
{
  "mode": 33,
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [×] 可选的 `[mode]` 指定比赛模式，查询该模式的统计数据，默认值为 33（名剑 3v3）。
- [√] 必选的 `[ticket]` 推栏标识，用于验证请求权限。请替换为您的实际推栏 Token (YOUR_TUILAN_TOKEN)。
- [√] 必选的 `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "name": "万花",
      "this": 19,
      "last": 17
    }
  ],
  "time": 1713009275
}
```