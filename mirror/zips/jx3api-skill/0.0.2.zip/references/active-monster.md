> **请求说明**

此接口用于获取本周百战异闻录刷新的首领以及它们的特殊效果。

> **请求权限**

```VIP2```

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/active/monster
```

> **请求参数**

```json
{
  "token": "YOUR_TOKEN"
}

```
- [√] ```[token]``` 用于标识请求站点的有效性，并验证请求权限。请替换为您获取的实际 Token。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "start": 1730070000,
    "end": 1730674800,
    "data": [
      {
        "level": 1,
        "name": "冯度",
        "skill": [
          "花钱消灾",
          "斗转金移",
          "空穴来风",
          "通世金诀"
        ],
        "data": {
          "id": 3151,
          "name": "无",
          "list": [],
          "desc": "无",
          "time": 1730070000
        }
      }
    ]
  },
  "time": 1733656377
}
```