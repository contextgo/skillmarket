> **请求说明**

此接口用于查询家园系统中特定装饰的详细信息，包括来源、属性和外观等内容。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/home/furniture
```

> **请求参数**

```json
{
  "name": "龙门香梦"
}
```

- [√] `[name]` 指定目标装饰的名称，查找该装饰的详细信息。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "id": 1,
    "name": "龙门香梦",
    "type": 1,
    "color": 4,
    "source": "园宅会赛",
    "architecture": 0,
    "limit": 10,
    "quality": 1000,
    "view": 7931,
    "practical": 3525,
    "hard": 3525,
    "geomantic": 3525,
    "interesting": 3525,
    "produce": null,
    "image": "https://dl.pvp.xoyo.com/prod/icons/ui/image/homeland/data/source/home/furniture/cloth/cloth5_4_1001.mesh.png",
    "tip": "跳影如流泉，香梦过龙门。山中逍遥客，化为唤雨人。"
  },
  "time": 1723005805
}
```