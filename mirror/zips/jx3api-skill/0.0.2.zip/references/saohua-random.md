> **请求说明**

此接口用于随机获取一条与万花门派相关的骚话。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/saohua/random
```

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "id": 1178,
    "text": "想干室友就直接上，别找借口"
  },
  "time": 1713009950
}
```
