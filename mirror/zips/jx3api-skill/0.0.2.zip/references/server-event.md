> **请求说明**

此接口用于查询跨服阵营事件，包括阵营名称、服务器信息以及事件时间。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/server/event
```

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 48783,
      "camp_name": "恶人谷",
      "fenxian_zone_name": "电信区",
      "fenxian_server_name": "斗转星移",
      "friend_zone_name": "电信区",
      "friend_server_name": "唯我独尊",
      "role_name": "质歆@梦江南·唯我独尊",
      "set_time": 1733675364
    }
  ],
  "time": 1733675554
}
```