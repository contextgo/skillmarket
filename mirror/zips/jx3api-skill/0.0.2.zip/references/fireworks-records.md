> **请求说明**

此接口用于查询烟花赠送与接收的历史记录，数据可能存在遗漏。

> **请求权限**

```VIP2```

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/fireworks/records
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "name": "风月的男宠",
  "token": "YOUR_TOKEN"
}

```

- [√] `[server]` 指定目标区服，查找目标区服的相关信息。
- [√] `[name]` 指定角色名称，查找目标角色的相关信息。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。请替换为您获取的实际 Token。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 658542,
      "zone": "电信区",
      "server": "唯我独尊",
      "name": "流光绮梦",
      "map_name": "帮会领地",
      "sender": "风月",
      "receive": "风月的男宠",
      "status": 1,
      "time": 1676617216
    }
  ],
  "time": 1713010731
}
```