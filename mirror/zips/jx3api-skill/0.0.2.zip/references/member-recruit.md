> **请求说明**

此接口用于查询指定区服的团队招募信息，包括活动类型、队长信息及当前队伍状态。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/member/recruit
```

> **请求参数**

```json
{
  "server": "梦江南",
  "keyword": "英雄西津渡",
  "table": 1,
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的团队招募信息。
- [×] `[keyword]` 输入关键字模糊匹配，使用 =关键字 可完全匹配。
- [×] `[table]` 指定数据记录范围：
    - **1**：本服 + 跨服（默认值）。
    - **2**：仅本服。
    - **3**：仅跨服。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zone": "电信五区",
    "server": "梦江南",
    "time": 1713009283,
    "data": [
      {
        "crossServer": true,
        "activityId": 5,
        "activity": "九老洞",
        "level": 120,
        "leader": "花开又一季",
        "pushId": 0,
        "roomID": "525994",
        "roleId": 0,
        "createTime": 1713009284,
        "number": 9,
        "maxNumber": 10,
        "label": [],
        "content": "小1，T奶齐随便来++++++++++++++"
      }
    ]
  },
  "time": 1713009300
}
```