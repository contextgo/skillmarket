> **请求说明**

此接口用于查询指定心法的技能详细信息，包括技能的效果描述、类型、冷却时间、消耗等关键属性。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/school/skills
```

> **请求参数**

```json
{
  "name": "花间游",
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[name]` 指定心法名称，查询目标心法的技能效果。
- [√] `[ticket]` 推栏标识，用于验证请求权限。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "class": "养心诀",
      "data": [
        {
          "name": "清心静气",
          "simpleDesc": "辅助技，尽量使友方目标维持这个效果。",
          "desc": "使友方目标气血最大值提高5%，持续30分钟。",
          "specialDesc": "营气之道，内谷为宝。",
          "interval": "无调息时间",
          "consumption": "4635点",
          "distance": "20尺",
          "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/WanHua/skill_wanhua25.png?v=2",
          "kind": "技能",
          "subKind": "万花",
          "releaseType": "瞬间释放",
          "weapon": "笔类"
        }
      ],
      "time": 1723008470
    }
  ]
}
```