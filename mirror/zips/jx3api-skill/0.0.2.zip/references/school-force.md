> **请求说明**

此接口用于查询指定心法的奇穴详细效果，包括每层奇穴的技能描述、类别及图标等信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/school/force
```

> **请求参数**

```json
{
  "name": "花间游",
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[name]` 指定心法名称，查询目标心法的奇穴效果。
- [√] `[ticket]` 推栏标识，用于验证请求权限。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "level": 1,
      "data": [
        {
          "name": "烟霞",
          "class": 0,
          "desc": "“阳明指”的会心几率提高10%，会心效果提高10%。",
          "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/Common/guanchongjian.png?v=2",
          "kind": "技能",
          "subKind": "通用"
        },
        {
          "name": "放歌",
          "class": 0,
          "desc": "每次恢复墨意时，额外恢复2点。",
          "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/TianFu/tf_wanhua_T7.png?v=2",
          "kind": "技能",
          "subKind": "天赋"
        },
        {
          "name": "少阳指",
          "class": 0,
          "desc": "施展“商阳指”使目标移动速度降低60%，持续4秒。",
          "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/WanHua/skill_wanhua32.png?v=2",
          "kind": "技能",
          "subKind": "万花"
        }
      ]
    }
  ],
  "time": 1723008398
}
```