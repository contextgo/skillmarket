> **请求说明**

此接口用于通过网易云音乐平台搜索指定歌曲名称，并返回相关音乐的 ID、名称和歌手信息。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/music/netease
```

> **请求参数**

```json
{
  "name": "么么哒"
}
```

- [√] `[name]` 歌曲名称，用于搜索网易云音乐的相关内容。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 399343626,
      "name": "么么哒",
      "singer": "陈咏"
    },
    {
      "id": 30070118,
      "name": "么么哒",
      "singer": "曹格"
    },
    {
      "id": 408277079,
      "name": "么么哒",
      "singer": "莫露露"
    },
    {
      "id": 32785814,
      "name": "么么哒",
      "singer": "小緣"
    },
    {
      "id": 2870420,
      "name": "Zou Bisou, Bisou",
      "singer": "Jessica Paré"
    },
    {
      "id": 2097101790,
      "name": "Wutan Wutan",
      "singer": "Alimjan-Abdukadir"
    },
    {
      "id": 2872407,
      "name": "I Can't Stop The Rain",
      "singer": "KISS"
    },
    {
      "id": 34125020,
      "name": "么么哒",
      "singer": "杨慧妍"
    },
    {
      "id": 2031988055,
      "name": "么么哒",
      "singer": "美蛋缘"
    },
    {
      "id": 2872255,
      "name": "Rock And Roll All Nite",
      "singer": "KISS"
    }
  ],
  "time": 1733679635
}
```