> **请求说明**

此接口用于获取官方最新维护公告，包括公告标题、发布日期及链接等信息。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/news/announce
```

> **请求参数**

```json
{
  "limit": 1
}

```

- [×] `[limit]` 限制返回的公告条数，默认值为 10，可选范围为 1-50。


> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 2607,
      "token": 1334235,
      "class": "官方公告",
      "title": "12月5日1.0.0.8799版本更新公告",
      "date": "12/05",
      "url": "https://jx3.xoyo.com/announce/gg.html?id=1334235"
    }
  ],
  "time": 1733666196
}
```