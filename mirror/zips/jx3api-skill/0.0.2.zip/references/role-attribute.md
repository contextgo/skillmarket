> **请求说明**

此接口用于查询指定角色的装备属性详情，包括装备名称、属性值、附魔等信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/role/attribute
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "name": "夜温言@长安城",
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的角色记录。
- [√] `[name]` 指定角色名称，查询该角色的装备属性详情。
- [√] `[ticket]` 推栏标识，用于验证请求权限。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信区",
    "serverName": "唯我独尊",
    "roleName": "夜温言@长安城",
    "roleId": "26468709",
    "globalRoleId": "288230376159033247",
    "forceName": "万花",
    "forceId": "2",
    "bodyName": "萝莉",
    "bodyId": "6",
    "tongName": null,
    "tongId": null,
    "campName": "中立",
    "campId": "0",
    "personName": "",
    "personId": "c5153c2ea2864081b70eb915595a45ea",
    "personAvatar": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/cda8b816adf542a290c9c5722c6bfb0a/avatar.jpg/5425ad76b32940718f419d8b82d80894.jpg",
    "kungfuName": "花间游",
    "kungfuId": "10021",
    "equipList": [
      {
        "name": "璃光浮远",
        "class": "笔",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/weapon/Pen/wpn_22_10_13_46.png?v=2",
        "kind": "武器",
        "subKind": "笔",
        "quality": "12500",
        "strengthLevel": "8",
        "maxStrengthLevel": "8",
        "color": "5",
        "desc": "笔长二尺三寸，重三斤四两，其上所镶嵌的多是出自海中的贵重的琉璃宝玉。\\n陆卿墨出身江东书香门第，年少时好交游，以一手好书法闻名当地，结识了不少江南才子。陆卿墨自小崇拜颜真卿，十七岁那年，得好友万松谦邀请前往万花谷，恰遇颜真卿在谷中小住，陆卿墨便向其请教书法，颜真卿只略微评论。陆卿墨以为颜真卿并未真心相授，于是请仆从快马返回江南家中，取了一支镶满海中宝玉的笔来。\\n而后，陆卿墨带着此笔再度拜访颜真卿，颜真卿苦笑道：“我先前所言并非客套，你才气笔力俱佳，若非要点出个短处来，那便是少了些风骨。”陆卿墨心中不服，此后多次向颜真卿讨教，颜真卿却不与他谈书法，反而说起治国济世之道，陆卿墨逐渐被颜真卿折服，拜其为师，随其精研书法与武学，从一个志在隐逸的才子蜕变为励志经民济世的儒生。而那支价值连城的璃光浮远则送给了万松谦。",
        "source": null,
        "fiveStone": [
          {
            "name": "五行石（八级）",
            "level": "8",
            "max": "97",
            "min": "97",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_8a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "混元性内功攻击提高97",
            "percent": false
          },
          {
            "name": "五行石（八级）",
            "level": "8",
            "max": "41",
            "min": "41",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_8a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "元气提高41",
            "percent": false
          },
          {
            "name": "五行石（八级）",
            "level": "8",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_8a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "混元性内功破防等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "武器伤害提高1346",
            "GeneratedMagic": "武器伤害提高1346",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "1346",
          "Base1Min": "1346",
          "Desc": "atMeleeWeaponDamageBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base2Max": "897",
          "Base2Min": "897",
          "Desc": "atMeleeWeaponDamageRand"
        },
        "EquipType": {
          "Desc": "通用",
          "EquipUsage": "3",
          "Icon": "",
          "SubType": "武器"
        },
        "ID": "38049",
        "UID": "200967",
        "colorStone": {
          "id": "1833",
          "name": "彩·雷鸣·混沌·霹雳(陆)",
          "class": "五彩石",
          "level": "6",
          "icon": "https://dl.pvp.xoyo.com/prod/icons/System/Optional/five_element_stone_water_10.png?v=2",
          "kind": "系统",
          "subKind": "可挑选",
          "attribute": [
            {
              "max": "442",
              "min": "442",
              "desc": "混元性内功攻击提高442",
              "percent": false
            },
            {
              "max": "2925",
              "min": "2925",
              "desc": "混元性内功破防等级提高2925",
              "percent": false
            },
            {
              "max": "5850",
              "min": "5850",
              "desc": "混元性内功会心效果等级提高5850",
              "percent": false
            }
          ]
        },
        "modifyType": [
          {
            "name": "元气",
            "max": "933",
            "min": "933",
            "desc": "元气提高933",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "5189",
            "min": "5189",
            "desc": "混元性内功攻击提高5189",
            "percent": false
          },
          {
            "name": "会心",
            "max": "5459",
            "min": "5459",
            "desc": "混元性内功会心等级提高5459",
            "percent": false
          },
          {
            "name": "破防",
            "max": "5979",
            "min": "5979",
            "desc": "混元性内功破防等级提高5979",
            "percent": false
          },
          {
            "name": "加速",
            "max": "2599",
            "min": "2599",
            "desc": "加速等级提高2599",
            "percent": false
          }
        ],
        "permanentEnchant": [
          {
            "id": "11874",
            "name": "断浪·兵·铸（内攻）",
            "level": "",
            "icon": "https://static.nicemoe.cn/icon/permanent-enchant.png",
            "attributes": [
              {
                "max": "343",
                "min": "343",
                "attrib": [
                  {
                    "desc": "内功攻击提高343"
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        "name": "斛尘囊",
        "class": "投掷",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/weapon/TouZhiNang/wpn_longdis04.png?v=2",
        "kind": "武器",
        "subKind": "投掷囊",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": null,
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "无双等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "暗器伤害提高3815",
            "GeneratedMagic": "暗器伤害提高3815",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "3815",
          "Base1Min": "3815",
          "Desc": "atRangeWeaponDamageBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base2Max": "2543",
          "Base2Min": "2543",
          "Desc": "atRangeWeaponDamageRand"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "暗器"
        },
        "ID": "40577",
        "UID": "224114",
        "modifyType": [
          {
            "name": "元气",
            "max": "551",
            "min": "551",
            "desc": "元气提高551",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1391",
            "min": "1391",
            "desc": "内功攻击提高1391",
            "percent": false
          },
          {
            "name": "破招",
            "max": "4604",
            "min": "4604",
            "desc": "破招值提高4604",
            "percent": false
          },
          {
            "name": "无双",
            "max": "3683",
            "min": "3683",
            "desc": "无双等级提高3683",
            "percent": false
          }
        ]
      },
      {
        "name": "玉凉衣",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/armor/Coat/daoj_19_6_20_10.png?v=2",
        "kind": "防具",
        "subKind": "上衣",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "副本：南诏皇宫 — 5号boss宝箱；荻花宫后山 — 牡丹宝箱；大明宫 — 无名；太原之战·逐虎驱狼 — 史思明；狼牙堡·辉天堑 — 剑阵宝箱3,剑阵宝箱2；狼牙堡·狼神殿 — 史思明；尘归海·巨冥湾 — 黄穆；敖龙岛 — 驺吾；白帝江关 — 宇文灭；雷域大泽 — 乌蒙贵；河阳之战 — 常宿",
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "破招值提高321",
            "percent": false
          },
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "全会心等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "外功防御等级提高671",
            "GeneratedMagic": "外功防御等级提高671",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "671",
          "Base1Min": "671",
          "Desc": "atPhysicsShieldBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "内功防御等级提高839",
            "GeneratedMagic": "内功防御等级提高839",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base2Max": "839",
          "Base2Min": "839",
          "Desc": "atMagicShield"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "上衣"
        },
        "ID": "100873",
        "UID": "219115",
        "modifyType": [
          {
            "name": "元气",
            "max": "918",
            "min": "918",
            "desc": "元气提高918",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "2319",
            "min": "2319",
            "desc": "内功攻击提高2319",
            "percent": false
          },
          {
            "name": "破招",
            "max": "7674",
            "min": "7674",
            "desc": "破招值提高7674",
            "percent": false
          },
          {
            "name": "无双",
            "max": "6139",
            "min": "6139",
            "desc": "无双等级提高6139",
            "percent": false
          }
        ]
      },
      {
        "name": "昭文冠",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/armor/Hat/daoj_19_6_20_7.png?v=2",
        "kind": "防具",
        "subKind": "帽子",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "副本：一之窟 — 伍靖远；龙渊泽 — 辽东双煞宝箱；荻花宫后山 — 提坦德亚罗宝箱；血战天策 — 固守天策府,；上阳宫·双曜亭 — 哥舒翰；风雷刀谷·千雷殿 — 伊玛目；九老洞 — 鬼筹",
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "全会心等级提高321",
            "percent": false
          },
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "97",
            "min": "97",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "内功攻击提高97",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "外功防御等级提高537",
            "GeneratedMagic": "外功防御等级提高537",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "537",
          "Base1Min": "537",
          "Desc": "atPhysicsShieldBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "内功防御等级提高671",
            "GeneratedMagic": "内功防御等级提高671",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base2Max": "671",
          "Base2Min": "671",
          "Desc": "atMagicShield"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "帽子"
        },
        "ID": "100903",
        "UID": "219201",
        "modifyType": [
          {
            "name": "元气",
            "max": "826",
            "min": "826",
            "desc": "元气提高826",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "2087",
            "min": "2087",
            "desc": "内功攻击提高2087",
            "percent": false
          },
          {
            "name": "破招",
            "max": "6906",
            "min": "6906",
            "desc": "破招值提高6906",
            "percent": false
          },
          {
            "name": "无双",
            "max": "5525",
            "min": "5525",
            "desc": "无双等级提高5525",
            "percent": false
          }
        ]
      },
      {
        "name": "玉凉腰带",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/armor/Belt/daoj_19_6_20_9.png?v=2",
        "kind": "防具",
        "subKind": "腰带",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "副本：荻花宫后山 — 罗索斯宝箱；战宝迦兰 — 王海银宝箱；战宝军械库 — ；大明宫 — 耶律燕；永王行宫·花月别院 — 韩非池；上阳宫·观风殿 — 沈眠风；冰火岛·荒血路 — 没藏呼月；敖龙岛 — 陈徽；范阳夜变 — 白某；雷域大泽 — 月泉淮；河阳之战 — 阿阁诺；武狱黑牢 — 乐临川；冷龙峰 — 鹰眼客",
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "无双等级提高321",
            "percent": false
          },
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "全会心等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "外功防御等级提高335",
            "GeneratedMagic": "外功防御等级提高335",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "335",
          "Base1Min": "335",
          "Desc": "atPhysicsShieldBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "内功防御等级提高419",
            "GeneratedMagic": "内功防御等级提高419",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base2Max": "419",
          "Base2Min": "419",
          "Desc": "atMagicShield"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "腰带"
        },
        "ID": "100849",
        "UID": "219091",
        "modifyType": [
          {
            "name": "元气",
            "max": "643",
            "min": "643",
            "desc": "元气提高643",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1623",
            "min": "1623",
            "desc": "内功攻击提高1623",
            "percent": false
          },
          {
            "name": "破招",
            "max": "5371",
            "min": "5371",
            "desc": "破招值提高5371",
            "percent": false
          },
          {
            "name": "无双",
            "max": "4297",
            "min": "4297",
            "desc": "无双等级提高4297",
            "percent": false
          }
        ]
      },
      {
        "name": "斛尘裤",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/armor/Pants/daoj_19_6_20_11.png?v=2",
        "kind": "防具",
        "subKind": "裤子",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": null,
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "97",
            "min": "97",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "内功攻击提高97",
            "percent": false
          },
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "全会心等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "外功防御等级提高604",
            "GeneratedMagic": "外功防御等级提高604",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "604",
          "Base1Min": "604",
          "Desc": "atPhysicsShieldBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "内功防御等级提高755",
            "GeneratedMagic": "内功防御等级提高755",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base2Max": "755",
          "Base2Min": "755",
          "Desc": "atMagicShield"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "下装"
        },
        "ID": "104130",
        "UID": "224078",
        "modifyType": [
          {
            "name": "元气",
            "max": "918",
            "min": "918",
            "desc": "元气提高918",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "2319",
            "min": "2319",
            "desc": "内功攻击提高2319",
            "percent": false
          },
          {
            "name": "破防",
            "max": "7674",
            "min": "7674",
            "desc": "内功破防等级提高7674",
            "percent": false
          },
          {
            "name": "无双",
            "max": "6139",
            "min": "6139",
            "desc": "无双等级提高6139",
            "percent": false
          }
        ]
      },
      {
        "name": "昭文袖",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/armor/Armguard/daoj_19_6_20_8.png?v=2",
        "kind": "防具",
        "subKind": "护臂",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "副本：一之窟 — 骆耀阳；大明宫 — 特殊宝箱,华丽的宝箱,剑圣；荻花圣殿 — 贪狼之牙宝箱；荻花宫后山 — 水烟宝箱；血战天策 — 曹炎烈；上阳宫·观风殿 — ；风雷刀谷·锻刀厅 — 柳愚；冰火岛·荒血路 — 康疑；白帝江关 — 姜集苦；武狱黑牢 — 时风；冷龙峰 — 葛木寒",
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "内功破防等级提高321",
            "percent": false
          },
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "破招值提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "外功防御等级提高470",
            "GeneratedMagic": "外功防御等级提高470",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "470",
          "Base1Min": "470",
          "Desc": "atPhysicsShieldBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "内功防御等级提高587",
            "GeneratedMagic": "内功防御等级提高587",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base2Max": "587",
          "Base2Min": "587",
          "Desc": "atMagicShield"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "护腕"
        },
        "ID": "100879",
        "UID": "219177",
        "modifyType": [
          {
            "name": "元气",
            "max": "643",
            "min": "643",
            "desc": "元气提高643",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1623",
            "min": "1623",
            "desc": "内功攻击提高1623",
            "percent": false
          },
          {
            "name": "破招",
            "max": "5371",
            "min": "5371",
            "desc": "破招值提高5371",
            "percent": false
          },
          {
            "name": "无双",
            "max": "4297",
            "min": "4297",
            "desc": "无双等级提高4297",
            "percent": false
          }
        ]
      },
      {
        "name": "映宵靴",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/armor/Shoe/item_24_10_19_12.png?v=2",
        "kind": "防具",
        "subKind": "鞋",
        "quality": "22500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "副本：25人普通一之窟 — 伍靖远,关卡宝箱",
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "41",
            "min": "41",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "元气提高41",
            "percent": false
          },
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "无双等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "外功防御等级提高368",
            "GeneratedMagic": "外功防御等级提高368",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base1Max": "368",
          "Base1Min": "368",
          "Desc": "atPhysicsShieldBase"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "内功防御等级提高460",
            "GeneratedMagic": "内功防御等级提高460",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "0",
            "Type": "Attribute",
            "percent": false
          },
          "Base2Max": "460",
          "Base2Min": "460",
          "Desc": "atMagicShield"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "鞋子"
        },
        "ID": "101208",
        "UID": "219734",
        "modifyType": [
          {
            "name": "元气",
            "max": "705",
            "min": "705",
            "desc": "元气提高705",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1781",
            "min": "1781",
            "desc": "内功攻击提高1781",
            "percent": false
          },
          {
            "name": "全会心",
            "max": "5896",
            "min": "5896",
            "desc": "全会心等级提高5896",
            "percent": false
          },
          {
            "name": "无双",
            "max": "4716",
            "min": "4716",
            "desc": "无双等级提高4716",
            "percent": false
          }
        ]
      },
      {
        "name": "灵空·未判链",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/trinket/Necklace/tkt_necklace17.png?v=2",
        "kind": "饰品",
        "subKind": "项链",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": null,
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "无双等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base1Max": "",
          "Base1Min": "",
          "Desc": "atInvalid"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base2Max": "",
          "Base2Min": "",
          "Desc": "atInvalid"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "项链"
        },
        "ID": "42734",
        "UID": "224431",
        "modifyType": [
          {
            "name": "元气",
            "max": "459",
            "min": "459",
            "desc": "元气提高459",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1159",
            "min": "1159",
            "desc": "内功攻击提高1159",
            "percent": false
          },
          {
            "name": "破防",
            "max": "3837",
            "min": "3837",
            "desc": "内功破防等级提高3837",
            "percent": false
          },
          {
            "name": "无双",
            "max": "3069",
            "min": "3069",
            "desc": "无双等级提高3069",
            "percent": false
          }
        ]
      },
      {
        "name": "江空坠",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/trinket/Waist/tkt_pendant29.png?v=2",
        "kind": "饰品",
        "subKind": "腰坠",
        "quality": "20600",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "声望：郝张 — 空城殿·装备",
        "fiveStone": [
          {
            "name": "五行石（七级）",
            "level": "7",
            "max": "321",
            "min": "321",
            "icon": "https://dl.pvp.xoyo.com/prod/icons/five_element_stone_7a.png?v=2",
            "kind": "系统",
            "subKind": "95级生活技能",
            "desc": "无双等级提高321",
            "percent": false
          }
        ],
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base1Max": "",
          "Base1Min": "",
          "Desc": "atInvalid"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base2Max": "",
          "Base2Min": "",
          "Desc": "atInvalid"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "腰坠"
        },
        "ID": "41382",
        "UID": "220495",
        "modifyType": [
          {
            "name": "元气",
            "max": "461",
            "min": "461",
            "desc": "元气提高461",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1165",
            "min": "1165",
            "desc": "内功攻击提高1165",
            "percent": false
          },
          {
            "name": "全会心",
            "max": "3855",
            "min": "3855",
            "desc": "全会心等级提高3855",
            "percent": false
          },
          {
            "name": "无双",
            "max": "3084",
            "min": "3084",
            "desc": "无双等级提高3084",
            "percent": false
          }
        ]
      },
      {
        "name": "斛尘戒",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/trinket/Ring/tkt_ring07.png?v=2",
        "kind": "饰品",
        "subKind": "戒指",
        "quality": "20500",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "副本：一之窟 — 宋泉,苏什；秦皇陵 — 银月宝箱,,令狐伤；会战唐门 — 汪莽宝箱,狼牙军阵宝箱；战宝迦兰 — 镇恶宝箱；战宝军械库 — ；永王行宫·仙侣庭园 — 森九岚,；狼牙堡·辉天堑 — 机关阵宝箱2,机关阵宝箱3；尘归海·巨冥湾 — 邢不僵,鬼首；达摩洞 — 宓桃；白帝江关 — 赵八嫂；西津渡 — 苏凤楼；九老洞 — 月泉淮；持国天王回忆录 — 提多罗吒宝箱；狼牙堡·战兽山 — 无支祁；敖龙岛 — 源思弦；河阳之战 — 周通忌",
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base1Max": "",
          "Base1Min": "",
          "Desc": "atInvalid"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base2Max": "",
          "Base2Min": "",
          "Desc": "atInvalid"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "戒指"
        },
        "ID": "41194",
        "UID": "219041",
        "modifyType": [
          {
            "name": "元气",
            "max": "459",
            "min": "459",
            "desc": "元气提高459",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1159",
            "min": "1159",
            "desc": "内功攻击提高1159",
            "percent": false
          },
          {
            "name": "破招",
            "max": "3837",
            "min": "3837",
            "desc": "破招值提高3837",
            "percent": false
          },
          {
            "name": "无双",
            "max": "3069",
            "min": "3069",
            "desc": "无双等级提高3069",
            "percent": false
          }
        ],
        "permanentEnchant": [
          {
            "id": "12355",
            "name": "昆仑玄石·戒指（内伤）",
            "level": "",
            "icon": "https://static.nicemoe.cn/icon/permanent-enchant.png",
            "attributes": [
              {
                "max": "633",
                "min": "633",
                "attrib": [
                  {
                    "desc": "内功攻击提高633"
                  }
                ]
              }
            ]
          }
        ]
      },
      {
        "name": "风沙行·长河",
        "class": "",
        "icon": "https://dl.pvp.xoyo.com/prod/icons/trinket/Ring/tkt_ring21.png?v=2",
        "kind": "饰品",
        "subKind": "戒指",
        "quality": "20200",
        "strengthLevel": "6",
        "maxStrengthLevel": "6",
        "color": "4",
        "desc": "",
        "source": "任务：秘窟取宝",
        "Base1Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base1Max": "",
          "Base1Min": "",
          "Desc": "atInvalid"
        },
        "Base2Type": {
          "Attrib": {
            "GeneratedBase": "",
            "GeneratedMagic": "",
            "HorseBase": "",
            "HorseMagic": "",
            "IsMobile": "",
            "percent": false
          },
          "Base2Max": "",
          "Base2Min": "",
          "Desc": "atInvalid"
        },
        "EquipType": {
          "Desc": "秘境挑战",
          "EquipUsage": "1",
          "Icon": "http://seasun-jx3-esport-static.ks3-cn-shanghai.ksyun.com/prod/icons/ui/image/equip/pve.png",
          "SubType": "戒指"
        },
        "ID": "42840",
        "UID": "224483",
        "modifyType": [
          {
            "name": "元气",
            "max": "452",
            "min": "452",
            "desc": "元气提高452",
            "percent": false
          },
          {
            "name": "攻击",
            "max": "1142",
            "min": "1142",
            "desc": "内功攻击提高1142",
            "percent": false
          },
          {
            "name": "破招",
            "max": "3781",
            "min": "3781",
            "desc": "破招值提高3781",
            "percent": false
          },
          {
            "name": "无双",
            "max": "3024",
            "min": "3024",
            "desc": "无双等级提高3024",
            "percent": false
          }
        ],
        "permanentEnchant": [
          {
            "id": "12356",
            "name": "昆仑玄石·戒指（破招）",
            "level": "",
            "icon": "https://static.nicemoe.cn/icon/permanent-enchant.png",
            "attributes": [
              {
                "max": "2089",
                "min": "2089",
                "attrib": [
                  {
                    "desc": "破招值提高2089"
                  }
                ]
              }
            ]
          }
        ]
      }
    ],
    "qixueList": [
      {
        "name": "烟霞",
        "level": 1,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/Common/guanchongjian.png?v=2",
        "kind": "技能",
        "subKind": "通用",
        "desc": "“阳明指”的会心几率提高10%，会心效果提高10%。"
      },
      {
        "name": "倚天",
        "level": 2,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/TianFu/skill_0514_134.png?v=2",
        "kind": "技能",
        "subKind": "天赋",
        "desc": "若目标存在自身的“兰摧玉折”不利状态，则无视目标25%内功防御等级且每跳恢复自身0.75%内力值。"
      },
      {
        "name": "钟灵",
        "level": 3,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/Common/skill_125.png?v=2",
        "kind": "技能",
        "subKind": "通用",
        "desc": "施展“玉石俱焚”触发吞噬时返还1秒调息时间，下一运功招式无需运功且消耗20墨意，自身18秒内基础攻击力提升15%。"
      },
      {
        "name": "焚玉",
        "level": 4,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/WanHua/skill_wanhua22.png?v=2",
        "kind": "技能",
        "subKind": "万花",
        "desc": "“阳明指”命中后，使自身下次施展持续伤害时造成一次内功伤害。"
      },
      {
        "name": "折花",
        "level": 5,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/WanHua/skill_wh_19_6_20_1.png?v=2",
        "kind": "技能",
        "subKind": "万花",
        "desc": "“阳明指”变为3层充能招式，充能时间6秒。命中后吞噬目标身上剩余时间最长的持续伤害效果。自身持续伤害被吞噬后，使下一个对应持续伤害招式附带混元伤害。"
      },
      {
        "name": "雪中行",
        "level": 6,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/Common/skill_89.png?v=2",
        "kind": "技能",
        "subKind": "通用",
        "desc": "“快雪时晴”2.81秒内对目标造成5次伤害。“快雪时晴”每跳使自身获得“溅玉”气劲，每层使自身基础攻击力提升10%，会心提升6%，最多3层。施展“玉石俱焚”后会清除所有“溅玉”气劲。"
      },
      {
        "name": "清流",
        "level": 7,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/TianFu/tf_wanhua_T9.png?v=2",
        "kind": "技能",
        "subKind": "天赋",
        "desc": "“兰摧玉折”调息时间降低4秒。自身对“兰摧玉折”标记目标伤害提升10%。"
      },
      {
        "name": "青冠",
        "level": 8,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/Common/skill_62.png?v=2",
        "kind": "技能",
        "subKind": "通用",
        "desc": "无双等级提高10%，基础攻击力提高10%。"
      },
      {
        "name": "流离",
        "level": 9,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/TianFu/tf_wanhua_24.png?v=2",
        "kind": "技能",
        "subKind": "天赋",
        "desc": "每次消耗墨意，使下一个“玉石俱焚”命中后，恢复20墨意并附带“兰摧玉折”持续伤害效果。每吞噬一个持续伤害效果，调息时间降低1.5秒。"
      },
      {
        "name": "丹青",
        "level": 10,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/WanHua/skill_22_4_25_33.png?v=2",
        "kind": "技能",
        "subKind": "万花",
        "desc": "“玉石俱焚”会在目标8尺区域产生墨池持续6秒，墨池每2秒浸染其中最多5个目标造成伤害并减速50%，若墨池浸染的目标有自身持续伤害，则对其造成该持续伤害的一跳伤害。同时画出雨墨雕，延迟1.5秒后对墨池内最多5个敌方目标造成混元伤害。"
      },
      {
        "name": "墨海临源",
        "level": 11,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/WanHua/skill_24_3_15_26.png?v=2",
        "kind": "技能",
        "subKind": "万花",
        "desc": "“阳明指”“玉石俱焚”每命中5次可施展1次，最多可累计3层。施展后恢复20墨意，对目标造成无质混元伤害（无质伤害无法会心，但伤害受到会心、会心效果加成）并附带一段破招伤害。"
      },
      {
        "name": "涓流",
        "level": 12,
        "icon": "https://dl.pvp.xoyo.com/prod/icons/skill/TianFu/skill_0514_237.png?v=2",
        "kind": "技能",
        "subKind": "天赋",
        "desc": "施展伤害招式命中目标，使自身会心几率提高1.6%，会心效果提高1.6%，每次造成伤害时叠加一层，叠加至10层后重置。"
      }
    ],
    "panelList": {
      "score": 370503,
      "panel": [
        {
          "name": "攻击力",
          "percent": false,
          "value": 53715
        },
        {
          "name": "会心",
          "percent": true,
          "value": 9.56
        },
        {
          "name": "破防",
          "percent": true,
          "value": 12.32
        },
        {
          "name": "化劲",
          "percent": true,
          "value": 9.96
        },
        {
          "name": "气血",
          "percent": false,
          "value": 1508261
        },
        {
          "name": "基础攻击力",
          "percent": false,
          "value": 35784
        },
        {
          "name": "会心效果",
          "percent": true,
          "value": 183.03
        },
        {
          "name": "破招",
          "percent": false,
          "value": 43576
        },
        {
          "name": "加速",
          "percent": false,
          "value": 2921
        },
        {
          "name": "无双",
          "percent": true,
          "value": 40.04
        },
        {
          "name": "内功防御",
          "percent": true,
          "value": 6.07
        },
        {
          "name": "外功防御",
          "percent": true,
          "value": 4.43
        },
        {
          "name": "御劲",
          "percent": true,
          "value": 0
        },
        {
          "name": "元气",
          "percent": false,
          "value": 8832
        }
      ]
    }
  },
  "time": 1733674051
}
```