> **请求说明**

此接口用于查询各服务器的关隘首领刷新记录，包括首领状态、所属阵营及时间信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/server/leader
```

> **请求参数**

```json
{
  "token": "YOUR_TOKEN"
}
```

- [√] `[token]` 用于验证请求权限，请替换为您的实际 Token。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "server": "乾坤一掷",
      "data": [
        {
          "id": 137,
          "zone": "电信区",
          "server": "乾坤一掷",
          "leader": "封偃师·梦江南",
          "camp_name": "恶人谷",
          "castle": "盘碣关",
          "status": 3,
          "str_status": "可拾取",
          "start_time": 1733675812,
          "end_time": 1733675992
        },
        {
          "id": 141,
          "zone": "电信区",
          "server": "乾坤一掷",
          "leader": "还烟·梦江南",
          "camp_name": "浩气盟",
          "castle": "赤焰关",
          "status": 2,
          "str_status": "保护期",
          "start_time": 1733665203,
          "end_time": 1733676003
        },
        {
          "id": 155,
          "zone": "电信区",
          "server": "乾坤一掷",
          "leader": "踢军爷裤裆·破阵子",
          "camp_name": "浩气盟",
          "castle": "回雁关",
          "status": 1,
          "str_status": "可抢占",
          "start_time": 1733675703,
          "end_time": 0
        }
      ]
    }
  ],
  "time": 1733675925
}
```