> **请求说明**

此接口用于查询的卢马的刷新、捕获及拍卖记录，包括捕获者、拍卖价格及相关时间信息。

> **请求权限**

```VIP2```

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/dilu/records
```

> **请求参数**

```json
{
  "server": "长安城",
  "token": "YOUR_TOKEN"
}
```

- [×] `[server]` 指定服务器名称，查询该服务器的的卢马记录。如果未指定，将返回所有服务器的记录。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。请替换为您获取的实际 Token。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 914,
      "zone": "电信区",
      "server": "长安城",
      "name": "的卢",
      "level": 15,
      "map_name": "龙泉府",
      "refresh_time": 1733490900,
      "capture_role_name": "慕深深",
      "capture_camp_name": "恶人谷",
      "capture_time": 1733492702,
      "auction_role_name": "郭千千",
      "auction_camp_name": "恶人谷",
      "auction_time": 1733494600,
      "auction_amount": "805万1514金",
      "start_time": 1733094000,
      "end_time": 1733612400
    }
  ],
  "time": 1733661554
}
```
