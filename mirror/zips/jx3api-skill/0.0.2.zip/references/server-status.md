> **请求说明**

此接口用于查询指定服务器的当前状态，包括 **维护**、**正常**、**繁忙** 和 **爆满** 等状态信息。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/server/status
```

> **请求参数**

```json
{
  "server": "长安城"
}
```

- [√] `[server]` 指定目标区服的名称，查询该区服的状态信息。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zone": "电信区",
    "server": "长安城",
    "status": "爆满"
  },
  "time": 1723007064
}
```