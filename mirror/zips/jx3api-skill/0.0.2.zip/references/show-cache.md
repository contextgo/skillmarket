> **请求说明**

此接口用于查询指定角色的名片墙信息。注意，该接口从缓存中读取数据，非实时更新。建议与装备属性接口搭配使用。

> **请求权限**

``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/show/cache
```

> **请求参数**

```json
{
  "server": "唯我独尊",
  "name": "夜温言@长安城",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 目标区服名称，用于查询该区服的角色信息。
- [√] `[name]` 角色名称，用于查找目标角色的名片墙信息。
- [√] `[token]` 站点标识，用于验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信区",
    "serverName": "唯我独尊",
    "roleName": "夜温言@长安城",
    "showHash": "98adfebcbb37d74e86b28acf28099fec",
    "showAvatar": "https://www.jx3api.com/cache/920dd4767af634aa2d68f3767b867a3d.png"
  },
  "time": 1733676373
}
```