> **请求说明**

此接口用于查询指定心法的资历排行榜，包括角色信息、所属心法及其资历值排名。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/school/seniority
```

> **请求参数**

```json
{
  "school": "蓬莱",
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[school]` 指定心法名称，查询目标心法的排行榜信息。
- [√] `[ticket]` 推栏标识，用于验证请求权限，需替换为实际的推栏 Token (YOUR_TUILAN_TOKEN)。
- [√] `[token]` 站点标识，用于验证请求权限，需替换为实际的 Token (YOUR_TOKEN)。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "Value": 196325,
      "avatarUrl": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/d1e6c4ce3da24adab2be21adccae480e/avatar.jpg/15477022ba704e52a7501304e161a086.jpg",
      "forceIcon": "https://dl.pvp.xoyo.com/static/tuilan-app/images/jx3/forces/icons/24.png",
      "forceId": 24,
      "gameVersion": 0,
      "nickName": "初亓聿",
      "personId": "70f4a1158e71446ba6f951c44e546924",
      "personNum": 2999828,
      "roleId": 31990011,
      "roleName": "词辰",
      "serverName": "梦江南",
      "zoneName": "电信区",
      "zoneServerName": "mjn",
      "forceName": "蓬莱"
    }
  ],
  "time": 1733675115
}
```