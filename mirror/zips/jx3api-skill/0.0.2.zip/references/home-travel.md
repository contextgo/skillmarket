> **请求说明**

此接口用于查询指定地图的装饰物品产出信息，包括装饰的属性、来源和外观等内容。

> **请求权限**

``USER`` ``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/home/travel
```

> **请求参数**

```json
{
  "name": "万花"
}
```

- [√] `[name]` 指定目标地图的名称，查询该地图的装饰物品产出信息。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 422,
      "name": "日晷",
      "type": 1,
      "color": 3,
      "source": "宠物游历",
      "architecture": 0,
      "limit": 3,
      "quality": 615,
      "view": 484,
      "practical": 1743,
      "hard": 500,
      "geomantic": 500,
      "interesting": 0,
      "produce": "万花",
      "image": "https://dl.pvp.xoyo.com/prod/icons/ui/image/homeland/data/source/home/furniture/ornament/ornament1_1_1008_p.prefab.png",
      "tip": "产出地图：万花"
    }
  ],
  "time": 1723006304
}
```