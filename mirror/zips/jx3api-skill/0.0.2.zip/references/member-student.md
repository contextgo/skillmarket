> **请求说明**

此接口用于查询客户端师徒系统中师傅收徒的相关信息，包括徒弟的角色信息及备注。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/member/student
```

> **请求参数**

```json
{
  "server": "长安城",
  "keyword": "师傅",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的师徒信息。
- [×] `[keyword]` 输入关键字模糊匹配，使用 =关键字 可完全匹配。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zone": "电信五区",
    "server": "梦江南",
    "data": [
      {
        "roleId": 23032923,
        "roleName": "我踏马超凶惹",
        "roleLevel": 120,
        "campName": "浩气盟",
        "tongName": "聆雪",
        "tongMasterName": "洛青栀",
        "bodyId": 2,
        "bodyName": "成女",
        "forceId": 5,
        "forceName": "七秀",
        "comment": "PVE人收个开朗徒弟！",
        "time": 1713009588
      }
    ]
  },
  "time": 1713009588
}
```