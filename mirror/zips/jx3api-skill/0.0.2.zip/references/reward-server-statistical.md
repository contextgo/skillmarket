> **请求说明**

此接口用于统计当前赛季副本中掉落的特殊物品信息，包括物品名称、掉落角色、地图等详细信息。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/reward/server/statistical
```

> **请求参数**

```json
{
  "name": "太一玄晶",
  "limit": 15,
  "token": "YOUR_TOKEN"
}
```

- [√] `[name]` 指定物品名称，查询目标物品的赛季掉落记录。
- [×] `[limit]` 限制返回记录的数量，默认值为 30，可选范围为 1-100。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": [
    {
      "id": 523999,
      "zone": "无界区",
      "server": "有人赴约",
      "name": "太一玄晶",
      "role_name": "阿克硫斯",
      "map_name": "25人普通冷龙峰",
      "source": 0,
      "time": 1730305539
    }
  ],
  "time": 1713010707
}
```