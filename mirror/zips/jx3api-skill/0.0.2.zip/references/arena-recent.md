> **请求说明**

此接口用于查询角色近期的名剑战绩记录，包括角色基本信息、战绩详情以及比赛趋势。

> **请求权限**

``VIP1`` ``VIP2``

> **请求方式(GET/POST)**

```url
https://www.jx3api.com/data/arena/recent
```

> **请求参数**

```json
{
  "server": "梦江南",
  "name": "有所依",
  "mode": 33,
  "ticket": "YOUR_TUILAN_TOKEN",
  "token": "YOUR_TOKEN"
}
```

- [√] `[server]` 指定目标区服，查询该区服的战绩信息。
- [√] `[name]` 指定角色名称，查询该角色的战绩信息。
- [×] `[mode]` 指定比赛模式，查询特定模式的战绩；若未指定，则返回推栏全部角色近期的比赛记录。
- [√] `[ticket]` 推栏标识，用于验证请求权限。请替换为您的实际推栏 Token (YOUR_TUILAN_TOKEN)。
- [√] `[token]` 用于标识请求站点的有效性，并验证请求权限。

> **返回结果**

```json
{
  "code": 200,
  "msg": "success",
  "data": {
    "zoneName": "电信五区",
    "serverName": "梦江南",
    "roleName": "有所依",
    "roleId": "27316130",
    "globalRoleId": "198158383609572538",
    "forceName": "万花",
    "forceId": "2",
    "bodyName": "成女",
    "bodyId": "2",
    "tongName": null,
    "tongId": null,
    "campName": "浩气盟",
    "campId": "1",
    "personName": "山旎",
    "personId": "3394b9420e9c464a9be906b2915c8357",
    "personAvatar": "https://qdla.pvp.xoyo.com/prod/avatar/tmp/709a9b5404c049eb8c2e7f163750bd8a/avatar.jpg/5606c26228ac46e88f58a7fc43204ec9.jpg",
    "performance": {
      "3v3": {
        "mmr": 2787,
        "grade": 15,
        "ranking": "-",
        "winCount": 326,
        "totalCount": 615,
        "mvpCount": 61,
        "pvpType": "",
        "winRate": 53
      }
    },
    "history": [
      {
        "zone": "电信五区",
        "server": "梦江南",
        "avgGrade": 15,
        "totalMmr": 2787,
        "mmr": 9,
        "kungfu": "离经易道",
        "pvpType": 3,
        "won": true,
        "mvp": false,
        "startTime": 1705729248,
        "endTime": 1705729390
      }
    ],
    "trend": [
      {
        "matchDate": 1705729248,
        "mmr": 2787,
        "winRate": 0.53
      }
    ]
  },
  "time": 1713009144
}
```