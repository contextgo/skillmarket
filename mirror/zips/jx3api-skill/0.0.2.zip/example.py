#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
剑网3 API 使用示例
"""

import requests

API_BASE_URL = "https://www.jx3api.com/data"

class JX3APIClient:
    """剑网3 API 客户端"""

    def __init__(self, base_url=None):
        self.base_url = base_url or API_BASE_URL
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'JX3APISkill/1.0',
            'Content-Type': 'application/json'
        })

    def _request(self, endpoint, method="GET", params=None, data=None):
        """统一请求方法"""
        url = f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        try:
            if method.upper() == "GET":
                response = self.session.get(url, params=params, timeout=10)
            elif method.upper() == "POST":
                response = self.session.post(url, params=params, json=data, timeout=10)
            else:
                return {"code": 400, "msg": f"不支持的请求方法: {method}", "data": None}

            response.raise_for_status()
            result = response.json()
            return result
        except requests.exceptions.Timeout:
            return {"code": 408, "msg": "请求超时，请稍后重试", "data": None}
        except requests.exceptions.RequestException as e:
            return {"code": 500, "msg": f"请求失败: {str(e)}", "data": None}

    def get_active_calendar(self, server=None, num=0):
        """查询日常活动日历"""
        params = {"num": num}
        if server:
            params["server"] = server
        return self._request("active/calendar", params=params)

    def get_server_status(self, server):
        """查询服务器状态"""
        params = {"server": server}
        return self._request("server/status", params=params)

    def get_news_announce(self, limit=10):
        """查询官方公告"""
        params = {"limit": limit}
        return self._request("news/announce", params=params)


def get_client(base_url=None):
    """获取JX3 API客户端实例"""
    return JX3APIClient(base_url)


def format_calendar_result(result):
    """格式化日常活动结果"""
    if result.get("code") != 200:
        return f"查询失败: {result.get('msg', '未知错误')}"
    
    data = result.get("data", {})
    if not data:
        return "暂无数据"
    
    lines = []
    lines.append(f"日期: {data.get('date', '未知')} 星期{data.get('week', '未知')}")
    lines.append(f"大战: {data.get('war', '未知')}")
    lines.append(f"战场: {data.get('battle', '未知')}")
    lines.append(f"矿车: {data.get('orecar', '未知')}")
    
    if data.get('school'):
        lines.append(f"门派: {data.get('school')}")
    if data.get('rescue'):
        lines.append(f"救援: {data.get('rescue')}")
    
    luck = data.get('luck', [])
    if luck:
        lines.append(f"幸运: {', '.join(luck)}")
    
    card = data.get('card', [])
    if card:
        lines.append(f"美人图: {', '.join(card)}")
    
    team = data.get('team', [])
    if team:
        lines.append(f"团队: {'; '.join(team)}")
    
    return "\n".join(lines)

def main():
    client = get_client()
    
    print("=" * 50)
    print("剑网3 API 示例")
    print("=" * 50)
    
    print("\n【1. 查询今日日常活动】")
    result = client.get_active_calendar()
    print(format_calendar_result(result))
    
    print("\n" + "-" * 50)
    print("\n【2. 查询指定服务器今日日常】")
    result = client.get_active_calendar(server="长安城")
    print(format_calendar_result(result))
    
    print("\n" + "-" * 50)
    print("\n【3. 查询明日日常活动】")
    result = client.get_active_calendar(num=1)
    print(format_calendar_result(result))
    
    print("\n" + "-" * 50)
    print("\n【4. 查询服务器状态】")
    result = client.get_server_status(server="长安城")
    if result.get("code") == 200:
        data = result.get("data", {})
        print(f"区服: {data.get('zone', '未知')}")
        print(f"服务器: {data.get('server', '未知')}")
        print(f"状态: {data.get('status', '未知')}")
    else:
        print(f"查询失败: {result.get('msg', '未知错误')}")
    
    print("\n" + "-" * 50)
    print("\n【5. 查询官方公告】")
    result = client.get_news_announce(limit=3)
    if result.get("code") == 200:
        data = result.get("data", [])
        for i, item in enumerate(data, 1):
            print(f"{i}. [{item.get('class', '公告')}] {item.get('title', '未知')}")
            print(f"   日期: {item.get('date', '未知')}")
            print(f"   链接: {item.get('url', '未知')}")
    else:
        print(f"查询失败: {result.get('msg', '未知错误')}")
    
    print("\n" + "=" * 50)

if __name__ == "__main__":
    main()
