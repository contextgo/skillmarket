---
name: "jx3api-skill"
description: "剑网3游戏助手，提供日常任务、服务器状态、官方公告、角色信息等查询功能。Invoke when user asks about JX3 game daily tasks, server status, announcements, character info, or any JX3 related queries."
---

# 剑网3游戏助手 (JX3API Skill)

基于 jx3api 的剑网3游戏数据查询工具。

## 触发场景

当用户询问以下内容时，调用此技能：
- 剑网3日常任务查询
- 服务器状态查询
- 官方公告查询
- 角色/玩家信息查询
- 奇遇信息查询
- 门派技能查询
- 世界首领/野外首领查询
- 其他剑网3游戏相关数据

## 可用功能

### 1. 日常活动查询 (get_active_calendar)

查询今天、明天、后天的日常任务信息，包括大战、战场、矿车、门派任务、救援、幸运玩家、美人图等。

**参数：**
- `server` (可选): 服务器名称，用于获取美人图数据，默认为空
- `num` (可选): 日期偏移，0=今天，1=明天，2=后天，默认0

**返回数据说明：**
- `date`: 查询日期
- `week`: 星期几
- `war`: 大战
- `battle`: 战场
- `orecar`: 矿车任务
- `school`: 门派任务
- `rescue`: 驰援任务
- `luck`: 福缘宠物
- `card`: 声望加倍卡
- `team`: 公共周常, 五人周常, 十人周常（以分号分隔）

**特别说明：**
- 美人图数据仅在周三、周五、周六、周日提供
- 世界首领仅在周三、周五存在
- 五人周常因游戏调整已被删除，可能返回"已删除;已删除;已删除"，应忽略此类数据

**示例调用：**
```python
client.get_active_calendar()  # 今日日常
client.get_active_calendar(server="长安城")  # 指定服务器
client.get_active_calendar(num=1)  # 明日日常
```

### 2. 服务器状态查询 (get_server_status)

查询服务器当前状态（维护/正常/繁忙/拥挤/爆满）。

**参数：**
- `server` (必填): 服务器名称

**示例调用：**
```python
client.get_server_status(server="长安城")
```

### 3. 开服状态查询 (get_server_check)

查询服务器是否开服或维护中。

**参数：**
- `server` (可选): 服务器名称，不传则返回所有服务器

**示例调用：**
```python
client.get_server_check(server="长安城")
```

### 4. 官方公告查询 (get_news_announce)

获取官方最新维护公告。

**参数：**
- `limit` (可选): 返回条数，1-50，默认10

**示例调用：**
```python
client.get_news_announce(limit=5)
```

### 5. 世界首领查询 (get_active_celebs)

查询世界首领刷新信息。

**参数：**
- `server` (必填): 服务器名称

**示例调用：**
```python
client.get_active_celebs(server="长安城")
```

### 6. 野外首领查询 (get_active_monster)

查询野外首领刷新信息。

**参数：**
- `server` (必填): 服务器名称

**示例调用：**
```python
client.get_active_monster(server="长安城")
```

### 7. 奇遇查询 (get_luck_adventure)

查询指定角色的奇遇触发记录。

**参数：**
- `server` (必填): 服务器名称
- `name` (可选): 角色名称

**示例调用：**
```python
client.get_luck_adventure(server="梦江南", name="玩家名称")
```

### 8. 角色属性查询 (get_role_attribute)

查询指定角色的装备属性详情。

**参数：**
- `server` (必填): 服务器名称
- `name` (必填): 角色名称

**示例调用：**
```python
client.get_role_attribute(server="唯我独尊", name="角色名称")
```

### 9. 角色详情查询 (get_role_detailed)

查询指定角色的详细信息。

**参数：**
- `server` (必填): 服务器名称
- `name` (必填): 角色名称

**示例调用：**
```python
client.get_role_detailed(server="长安城", name="角色名称")
```

### 10. 门派技能查询 (get_school_skills)

查询指定门派的技能信息。

**参数：**
- `school` (必填): 门派名称

**示例调用：**
```python
client.get_school_skills(school="万花")
```

### 11. 服务器活动查询 (get_server_event)

查询服务器活动信息。

**参数：**
- `server` (可选): 服务器名称

**示例调用：**
```python
client.get_server_event(server="长安城")
```

### 12. 开服时间表查询 (get_server_master)

查询服务器开服时间表。

**示例调用：**
```python
client.get_server_master()
```

### 13. 沙盘信息查询 (get_server_sand)

查询阵营沙盘信息。

**参数：**
- `server` (必填): 服务器名称

**示例调用：**
```python
client.get_server_sand(server="长安城")
```

## 使用示例

### 示例1：查询今日日常

**用户输入：** "今天的日常是什么？"

**调用：**
```python
from jx3api import get_client
client = get_client()
result = client.get_active_calendar()
```

**输出格式化：**
```
日期: 2026-04-01 星期三
大战: 大战！英雄冰川宫宝库
战场: 云湖天池
矿车: 跨服·河西瀚漠
门派: 纯阳·山门卫道
救援: 藏剑·乱世
幸运: 嗷呜, 丰丰, 圆圆
声望加倍卡: 英雄天子峰, 英雄日轮山城
公共周常: 洞天福地·守卫泥兰;龙泉府·雪国冬猎
十人周常: 一之窟;九老洞;河阳之战
```

### 示例2：查询服务器状态

**用户输入：** "长安城服务器状态怎么样？"

**调用：**
```python
result = client.get_server_status(server="长安城")
```

**输出格式化：**
```
区服: 电信区
服务器: 长安城
状态: 拥挤
```

### 示例2.1：使用简称查询服务器状态

**用户输入：** "长安服务器状态怎么样？"

**调用：**
```python
result = client.get_server_status(server="长安")
```

**输出格式化：**
```
区服: 电信区
服务器: 长安城
状态: 拥挤
```

**说明：** 系统会自动将"长安"解析为"长安城"

### 示例3：查询官方公告

**用户输入：** "最近有什么公告？"

**调用：**
```python
result = client.get_news_announce(limit=3)
```

**输出格式化：**
```
1. [官方公告] 3月23日1.0.0.9670版本更新公告
   日期: 03/23
   链接: https://jx3.xoyo.com/announce/gg.html?id=1335389
```

## 返回数据结构

所有API返回统一格式：

```json
{
  "code": 200,
  "msg": "success",
  "data": { ... },
  "time": 1733646979
}
```

- `code`: 状态码，200表示成功
- `msg`: 状态信息
- `data`: 具体数据
- `time`: 时间戳

## 注意事项

1. 部分接口需要VIP权限
2. 美人图数据仅在周三、周五、周六、周日提供
3. 世界首领仅在周三、周五存在
4. 角色查询可能需要额外token配置
5. **服务器名称支持模糊匹配**：用户可以使用服务器简称进行查询，系统会自动解析为完整的服务器名称
   - 例如：输入"双梦"或"双梦镇"会自动解析为"梦江南"
   - 例如：输入"长安"会自动解析为"长安城"
   - 支持所有需要服务器参数的接口
