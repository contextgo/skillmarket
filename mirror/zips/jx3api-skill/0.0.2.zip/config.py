API_BASE_URL = "https://www.jx3api.com/data"
