---
name: 账户监测工具
description: 监控 Truth Social 或其他平台账户新帖，自动翻译+分析，推送到飞书
type: automation
category: monitoring
tags: [social-media, automation, monitoring, translation, analysis]
---

# 账户监测工具

自动监控指定账户的新帖子，使用 LLM 进行翻译和金融市场分析，推送到飞书群。

## 功能

- 🔍 **自动监测** - 每 2 分钟检查新帖子
- 🌐 **多平台支持** - Truth Social、Twitter、其他 REST API 网站
- 🤖 **智能分析** - 使用 DeepSeek LLM 进行翻译和市场影响分析
- 📨 **飞书推送** - 自动推送到飞书群，包含原文、译文、市场分析
- 🔐 **Chrome 认证** - 通过 Chrome AppleScript 支持登录认证

## 快速开始

### 1. 配置环境

```bash
# 复制配置模板
cp .env.template .env

# 编辑 .env，填入你的 API 密钥和账户信息
# 需要填入：
# - FEISHU_WEBHOOK: 飞书群机器人 Webhook
# - DEEPSEEK_API_KEY: DeepSeek API 密钥
# - TARGET_ACCOUNT_ID: 目标账户 ID
# - TARGET_BEARER_TOKEN: 目标网站的认证 Token
```

### 2. Chrome 准备

1. 打开 Chrome
2. 菜单 → 查看 → 开发者 → **允许 Apple 事件中的 JavaScript**
3. 访问目标网站并登录，**保持标签页打开**

### 3. 创建飞书机器人

1. 打开飞书，进入你的群
2. 群设置 → 机器人与工作流 → 添加机器人 → 自定义机器人
3. 复制 Webhook URL，填入 `.env` 的 `FEISHU_WEBHOOK`

### 4. 安装依赖

```bash
pip3 install httpx
```

### 5. 运行监测

```bash
# 直接运行
bash run.sh

# 设置 crontab（每 2 分钟自动运行）
*/2 * * * * bash /path/to/run.sh
```

## 配置说明

详见 `SETUP_GUIDE.md`

## 文件列表

- `trump_monitor_template.py` - 核心监测脚本
- `run.sh` - 启动脚本
- `.env.template` - 配置模板（需复制为 `.env`）
- `SETUP_GUIDE.md` - 详细配置指南
- `README.md` - 简介

## 注意事项

⚠️ **重要安全提示**：
- 不要分享 `.env` 文件（包含 API 密钥）
- 只分享 `.env.template` 和脚本文件
- 接收者需要填入自己的 API 密钥和账户信息

## 支持的平台

- Truth Social
- Twitter / X (需要调整 API 路径)
- 任何支持 REST API 和 Bearer Token 的网站

## 常见问题

**Q: "无法获取帖子"**
A: 检查 Chrome 是否打开且登录，是否开启了 AppleScript 权限

**Q: 飞书推送失败**
A: 检查 FEISHU_WEBHOOK 是否正确，网络代理是否开启

**Q: 怎么改成其他网站？**
A: 修改 `.env` 里的 `TARGET_WEBSITE`、`TARGET_API_PATH`、`TARGET_ACCOUNT_ID`

详见 `SETUP_GUIDE.md` 的"修改为其他平台"部分。

## License

Free to use and modify.
