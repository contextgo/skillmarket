#!/usr/bin/env python3
"""
Truth Social Account Monitor（Chrome 版）
通过 Chrome AppleScript 在已登录的浏览器里调 API，
使用 LLM 翻译+分析，推送到飞书/企业微信。

前提：Chrome 已打开并登录目标网站
"""

import os, json, re, subprocess, sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo
import httpx

# ── 配置 ──────────────────────────────────────────────────────────────────────
# 需要用户自己配置的环境变量
FEISHU_WEBHOOK        = os.environ.get("FEISHU_WEBHOOK", "")
DEEPSEEK_API_KEY      = os.environ.get("DEEPSEEK_API_KEY", "")
LLM_API_TOKEN         = os.environ.get("LLM_API_TOKEN", "")
PROXY                 = os.environ.get("PROXY", "http://127.0.0.1:7897")

# 目标账户配置（用户需要自己填）
TARGET_ACCOUNT_ID     = os.environ.get("TARGET_ACCOUNT_ID", "")
TARGET_WEBSITE        = os.environ.get("TARGET_WEBSITE", "truthsocial.com")
TARGET_API_PATH       = os.environ.get("TARGET_API_PATH", "/api/v1/accounts")
TARGET_ACCOUNT_NAME   = os.environ.get("TARGET_ACCOUNT_NAME", "Account")
TARGET_BEARER_TOKEN   = os.environ.get("TARGET_BEARER_TOKEN", "")

# 头像图片 key（用户需要自己上传到飞书获得）
TARGET_HEADER_KEY     = os.environ.get("TARGET_HEADER_KEY", "")

STATE_FILE            = Path(__file__).parent / "last_post_id.txt"
# ──────────────────────────────────────────────────────────────────────────────


# ── 1. 通过 AppleScript 在 Chrome 里执行 JS ───────────────────────────────────

def chrome_fetch_posts() -> list[dict]:
    """在 Chrome 的已登录页面里执行同步 XHR，拿到最新帖子。"""
    js = (
        "(function(){"
        "var xhr=new XMLHttpRequest();"
        f"xhr.open('GET','{TARGET_API_PATH}/{TARGET_ACCOUNT_ID}/statuses?limit=10&exclude_reblogs=true',false);"
        f"xhr.setRequestHeader('Authorization','Bearer {TARGET_BEARER_TOKEN}');"
        "xhr.send();"
        "if(xhr.status!==200)return '[]';"
        "var posts=JSON.parse(xhr.responseText);"
        "return JSON.stringify(posts.map(function(p){"
        "return {id:p.id,created_at:p.created_at||'',text:(p.content||'').replace(/<[^>]+>/g,' ').trim(),url:p.url||''};"
        "}));"
        "})()"
    )

    script = f'''tell application "Google Chrome"
    repeat with theWindow in windows
        repeat with theTab in tabs of theWindow
            if URL of theTab contains "{TARGET_WEBSITE}" then
                return execute theTab javascript "{js}"
            end if
        end repeat
    end repeat
end tell'''

    try:
        result = subprocess.run(
            ["osascript", "-e", script],
            capture_output=True, text=True, timeout=30
        )
        output = result.stdout.strip()
        if not output:
            print(f"[error] AppleScript 无输出: {result.stderr[:200]}")
            return []
        posts = json.loads(output)
        return posts if isinstance(posts, list) else []
    except Exception as e:
        print(f"[error] Chrome 调用失败: {e}")
        return []


def fetch_posts_direct() -> list[dict]:
    """直接通过 httpx 请求（某些网站支持）。"""
    url = f"https://{TARGET_WEBSITE}{TARGET_API_PATH}/{TARGET_ACCOUNT_ID}/statuses?limit=10&exclude_reblogs=true"
    try:
        headers = {"User-Agent": "Mozilla/5.0"}
        if TARGET_BEARER_TOKEN:
            headers["Authorization"] = f"Bearer {TARGET_BEARER_TOKEN}"
        resp = httpx.get(url, proxy=PROXY, timeout=20, headers=headers)
        resp.raise_for_status()
        posts = resp.json()
        return [{"id": p["id"], "created_at": p.get("created_at", ""),
                 "text": re.sub(r"<[^>]+>", "", p.get("content", "").replace("<br/>", "\n").replace("<br />", "\n")).strip(),
                 "url": p.get("url", "")} for p in posts if isinstance(p, dict)]
    except Exception as e:
        print(f"[warn] 直接请求失败: {e}")
        return []


def fetch_posts() -> list[dict]:
    """抓取帖子，先试直接请求，再试 AppleScript。"""
    posts = fetch_posts_direct()
    if posts:
        return posts
    print("[info] 直接请求失败，尝试 AppleScript...")
    posts = chrome_fetch_posts()
    return posts


# ── 2. LLM 分析 ──────────────────────────────────────────────────────────────

def analyze(text: str) -> dict:
    """使用 LLM 进行翻译和分析。需要用户配置 DEEPSEEK_API_KEY。"""
    prompt = f"""你是一位财经分析师，请对以下文本完成分析：

【原文】
{text}

请严格按以下 JSON 格式返回，不要有任何多余文字：
{{
  "translation": "翻译或总结（如果是英文则翻译成中文）",
  "market_analysis": {{
    "us_stocks":   "对美股的潜在影响（1-2句）",
    "us_bonds":    "对美债的潜在影响（1-2句）",
    "commodities": "对大宗商品的潜在影响（1-2句）",
    "hk_stocks":   "对港股的潜在影响（1-2句）",
    "a_shares":    "对A股的潜在影响（1-2句）"
  }},
  "summary": "一句话核心概括（≤50字）"
}}"""
    resp = httpx.post(
        "https://api.deepseek.com/chat/completions",
        headers={"Authorization": f"Bearer {DEEPSEEK_API_KEY}", "Content-Type": "application/json"},
        json={"model": "deepseek-chat", "messages": [{"role": "user", "content": prompt}], "max_tokens": 1024},
        timeout=30,
    )
    resp.raise_for_status()
    raw = resp.json()["choices"][0]["message"]["content"].strip()
    m = re.search(r"\{.*\}", raw, re.DOTALL)
    return json.loads(m.group()) if m else {"translation": raw, "market_analysis": {}, "summary": ""}


# ── 3. 飞书推送 ───────────────────────────────────────────────────────────────

def push_feishu(post: dict, analysis: dict):
    ma      = analysis.get("market_analysis", {})
    summary = analysis.get("summary", "")
    transl  = analysis.get("translation", "")
    text    = post["text"]
    url     = post["url"]

    try:
        dt_utc = datetime.fromisoformat(post["created_at"].replace("Z", "+00:00"))
        dt_et  = dt_utc.astimezone(ZoneInfo("America/New_York"))
        post_time = dt_et.strftime(f"%Y-%m-%d %H:%M {dt_et.strftime('%Z')}")
    except Exception:
        post_time = post.get("created_at", "")

    elements = []

    # 如果有头像，加入头像元素
    if TARGET_HEADER_KEY:
        elements.append(
            {"tag": "img", "img_key": TARGET_HEADER_KEY, "alt": {"tag": "plain_text", "content": TARGET_ACCOUNT_NAME}, "preview": False}
        )

    elements.extend([
        {"tag": "div", "text": {"tag": "lark_md", "content": f"**🕐 发文时间：** {post_time}"}},
        {"tag": "div", "text": {"tag": "lark_md", "content": f"**🗣️ 原文**\n> {text}"}},
        {"tag": "div", "text": {"tag": "lark_md", "content": f"**📝 译文/总结**\n{transl}"}},
        {"tag": "hr"},
        {"tag": "div", "text": {"tag": "lark_md", "content": (
            f"**📊 市场影响分析**\n"
            f"🇺🇸 **美股：** {ma.get('us_stocks','-')}\n"
            f"📜 **美债：** {ma.get('us_bonds','-')}\n"
            f"🛢️ **大宗：** {ma.get('commodities','-')}\n"
            f"🇭🇰 **港股：** {ma.get('hk_stocks','-')}\n"
            f"🇨🇳 **A股：** {ma.get('a_shares','-')}"
        )}},
        {"tag": "hr"},
        {"tag": "action", "actions": [
            {"tag": "button", "text": {"tag": "plain_text", "content": "🔗 查看原帖"}, "url": url, "type": "default"},
        ]},
    ])

    card = {
        "config": {"wide_screen_mode": True},
        "header": {"title": {"tag": "plain_text", "content": f"🔔 {TARGET_ACCOUNT_NAME}: {summary}"}, "template": "red"},
        "elements": elements,
    }

    for attempt in range(3):
        try:
            resp = httpx.post(FEISHU_WEBHOOK, json={"msg_type": "interactive", "card": json.dumps(card)}, timeout=20)
            resp.raise_for_status()
            if resp.json().get("code", 0) == 0:
                print("[info] 飞书推送成功")
                return
        except Exception as e:
            print(f"[warn] 推送第{attempt+1}次失败: {e}")
    print("[error] 飞书推送最终失败")


# ── 4. 主流程 ─────────────────────────────────────────────────────────────────

def load_last_id() -> str | None:
    return STATE_FILE.read_text().strip() if STATE_FILE.exists() else None

def save_last_id(post_id: str):
    STATE_FILE.write_text(post_id)


def main():
    print("[1/3] 抓取帖子...")
    posts = fetch_posts()
    if not posts:
        print(f"[error] 无法获取帖子。请确认 Chrome 已打开且登录 {TARGET_WEBSITE}")
        return

    last_id = load_last_id()
    print(f"[info] 共 {len(posts)} 条，上次ID: {last_id}")

    if last_id is None:
        save_last_id(posts[0]["id"])
        print(f"[info] 首次运行，记录最新ID，不推送历史帖子")
        return

    cut = []
    for p in posts:
        if p["id"] == last_id:
            break
        cut.append(p)
    new_posts = cut

    actionable = [p for p in new_posts if p["text"].strip()]
    print(f"[info] 新帖 {len(new_posts)} 条，有文本 {len(actionable)} 条")

    if not actionable:
        print("[info] 无新帖子")
        return

    # 所有新帖全部推送（按发帖时间从旧到新）
    for post in reversed(actionable):
        print(f"[2/3] 分析: {post['text'][:60]}...")
        analysis = analyze(post["text"])
        print(f"[3/3] 推送飞书...")
        push_feishu(post, analysis)

    save_last_id(posts[0]["id"])
    print("[done] 完成")


if __name__ == "__main__":
    main()
