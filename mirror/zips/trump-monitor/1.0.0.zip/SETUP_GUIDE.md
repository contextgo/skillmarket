# Truth Social（或其他平台）账户监测工具

这是一个通用的账户监测框架，通过 Chrome AppleScript 自动监控指定账户的新帖，并使用 LLM 进行翻译+分析，推送到飞书。

## 快速开始

### 1. 环境准备

```bash
# 安装依赖
pip3 install httpx

# 创建 .env 文件
cp .env.template .env
```

### 2. 配置 .env

编辑 `.env` 文件，填入：

```
# 飞书群机器人 Webhook（必填）
FEISHU_WEBHOOK=https://open.feishu.cn/open-apis/bot/v2/hook/YOUR_WEBHOOK_ID

# DeepSeek API（用于翻译+分析，必填）
DEEPSEEK_API_KEY=sk-xxxxxxxx

# 代理地址（可选，如果网络环境需要）
PROXY=http://127.0.0.1:7897

# 目标账户信息（必填）
TARGET_WEBSITE=truthsocial.com
TARGET_ACCOUNT_ID=YOUR_ACCOUNT_ID
TARGET_API_PATH=/api/v1/accounts
TARGET_ACCOUNT_NAME=Donald Trump
TARGET_BEARER_TOKEN=YOUR_BEARER_TOKEN

# 飞书头像 key（可选，让消息更美观）
TARGET_HEADER_KEY=img_v3_xxxxxx
```

### 3. 获取账户信息

#### 3.1 获取 TARGET_ACCOUNT_ID 和 TARGET_BEARER_TOKEN

在 Chrome 里登录 truthsocial.com，然后在浏览器控制台执行：

```javascript
// 获取当前账户 Token
JSON.parse(localStorage.getItem('truth:auth')).users[Object.keys(JSON.parse(localStorage.getItem('truth:auth')).users)[0]].access_token

// 获取目标账户 ID（访问目标账户页面后）
// 从 API 响应或网页中找到账户 ID
```

#### 3.2 获取飞书头像 key（可选）

如果想要漂亮的头像效果：

1. 下载目标账户头像
2. 在飞书里上传图片（通过飞书 App API）
3. 获得 img_key，填入 .env

不填此项也可以，消息仍然会正常推送。

### 4. Chrome 准备

1. 打开 Chrome
2. **重要**：进入 Chrome 菜单 → 查看 → 开发者 → **允许 Apple 事件中的 JavaScript**
3. 访问 targetsite.com 并登录，**保持标签页打开**

### 5. 创建飞书群机器人

1. 打开飞书，创建或进入一个群
2. 群设置 → 机器人与工作流 → 添加机器人
3. 选择"自定义机器人"，创建后获得 Webhook URL
4. 填入 .env 中的 `FEISHU_WEBHOOK`

### 6. 运行监测

```bash
# 直接运行
bash run.sh

# 或用 crontab 每 2 分钟自动运行
*/2 * * * * bash /path/to/run.sh
```

## 如何修改为其他平台

### 改为监测 Twitter/X

1. 改 `TARGET_WEBSITE=x.com`
2. 改 `TARGET_API_PATH=/2/tweets/search/recent` 或 Twitter API v2 的路径
3. 更新 `TARGET_BEARER_TOKEN` 为 Twitter API Bearer Token
4. 调整 `analyze()` 函数的提示词

### 改为监测其他网站

只需要目标网站有 REST API，并且支持通过 Bearer Token 认证：

1. 找到 API 文档，确定账户 ID 和获取帖子的 endpoint
2. 获得 Bearer Token（通常在网站 localStorage 或 API 密钥管理）
3. 更新 TARGET_* 环境变量
4. 根据 API 响应结构调整帖子解析逻辑

## 常见问题

### "无法获取帖子"

1. Chrome 是否打开且登录了？
2. Chrome 是否已开启"允许 Apple 事件中的 JavaScript"？
3. 目标网站是否还是登录状态？

### 飞书推送失败

1. FEISHU_WEBHOOK 是否正确？
2. 网络代理是否开启？
3. 检查 monitor.log 里的错误信息

### DeepSeek 分析失败

1. DEEPSEEK_API_KEY 是否有效？
2. 账户余额是否充足？
3. API 速率限制？

## 文件说明

- `trump_monitor_template.py` - 核心监测脚本（模板，需要填入 .env）
- `run.sh` - 启动脚本（sourcing .env）
- `.env` - 配置文件（不要提交到 Git）
- `last_post_id.txt` - 记录上次的帖子 ID（自动生成）
- `monitor.log` - 运行日志

## 共享与安全

**重要**：这个脚本模板本身不含任何敏感信息。在共享时：

- ✅ 可以分享 `trump_monitor_template.py`、`run.sh`、`SETUP_GUIDE.md`
- ✅ 可以分享 `.env.template`（只写说明，不写实际值）
- ❌ **不要分享 `.env`**（包含 API 密钥）
- ❌ **不要分享 `last_post_id.txt` 和 `monitor.log`**（可能泄露账户信息）

接收者需要自己填入各自的 API 密钥和账户信息。

## License

Free to use and modify.
