# Truth Social（或其他平台）账户监测工具 - Skill 版本

这是一个可以共享给朋友的通用账户监测框架。不包含任何个人信息，完全模板化。

## 文件说明

- **`trump_monitor_template.py`** - 核心监测脚本（模板）
- **`run.sh`** - 启动脚本
- **`SETUP_GUIDE.md`** - 详细的配置指南（必读）
- **`.env.template`** - 配置模板（需要复制为 `.env` 并填入自己的值）

## 快速开始

```bash
# 1. 复制配置模板
cp .env.template .env

# 2. 编辑 .env，填入你自己的 API 密钥和账户信息
vi .env

# 3. 安装依赖
pip3 install httpx

# 4. 运行监测
bash run.sh
```

详细步骤见 `SETUP_GUIDE.md`。

## 特点

- ✅ 完全模板化，不包含个人信息
- ✅ 支持任何有 REST API 的平台（Truth Social, Twitter, 等）
- ✅ 自动翻译+市场分析（使用 DeepSeek LLM）
- ✅ 推送到飞书群
- ✅ 通过 Chrome AppleScript 支持登录认证

## 安全性

**重要**：不要共享 `.env` 文件，只共享模板文件（`.template`）。接收者需要填入自己的 API 密钥。

## License

Free to use and modify.
