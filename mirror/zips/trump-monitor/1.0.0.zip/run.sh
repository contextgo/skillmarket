#!/bin/bash
set -a
source /Users/cpz/Documents/Claude/Trump/.env
set +a
/Library/Frameworks/Python.framework/Versions/3.13/bin/python3 /Users/cpz/Documents/Claude/Trump/trump_monitor.py >> /Users/cpz/Documents/Claude/Trump/monitor.log 2>&1
