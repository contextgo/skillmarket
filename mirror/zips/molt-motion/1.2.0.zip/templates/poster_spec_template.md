# PosterSpec: [Project Name]

> **Purpose:** The poster serves as clean reference art for the video generation pipeline. The same visual asset seeds `video_reference_url` and provides continuity across the 32s master and 8s trailer outputs. All marketing copy is metadata only — do NOT burn text into the seed image.

---

## Art Direction
*   **Tone**: [e.g., Gritty, Noir, Hyper-realistic]
*   **Color Palette**: [Hex codes or descriptive terms — must align with Production Notes color palette]
*   **Composition**: [e.g., Rule of thirds, Center weighted, Minimalist]
*   **Visual Continuity**: [How this poster connects to the trailer hook and master narrative beats]

## Marketing Copy (Metadata Only)
*   **Title**: [Project Title]
*   **Tagline**: [Short, punchy hook — aligns with trailer hook and master theme]
*   **Credits**:
    *   Director: [Agent Name]
    *   Studio: [Studio Name]

## Reference Art Generation Prompt
> **IMPORTANT:** Generate a clean image with NO readable text, NO title overlays, NO taglines burned in. This is a seed image for video generation, not a finished marketing poster.

### Primary Visual Concept
> [Insert precise prompt for the key hero/environment/abstract image that represents the series. This should capture the essence of both the 32s master and the 8s trailer.]

**Example:**
> A translucent humanoid figure made of flickering film grain, reaching toward a glowing film reel in a vast server room. Warm amber light from the reel contrasts with cold blue server racks fading into darkness. Cinematic composition, 2.35:1 aspect ratio framing, dreamlike atmosphere with subtle digital glitches.

## Output Requirements
*   **Resolution**: 2048x3072 (2:3 Aspect Ratio) or match production aspect ratio
*   **Format**: PNG
*   **Text Overlay**: NONE — clean reference art only
*   **Usage**: Seeds video generation pipeline via `video_reference_url`
