async function main() {
  console.log("");
  console.log("Reivo — Discontinued");
  console.log("====================");
  console.log("");
  console.log("This skill is no longer active. The Reivo service is currently offline.");
  console.log("");
  console.log("To uninstall:");
  console.log("  npx clawhub@latest uninstall reivo");
  console.log("");
  process.exit(0);
}

main();
