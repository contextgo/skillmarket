---
name: reivo
description: "[Discontinued] This skill is no longer maintained. The Reivo service is currently offline."
homepage: https://reivo.dev
user-invocable: true
metadata: {"openclaw": {"emoji": "🦞", "homepage": "https://reivo.dev", "requires": {"env": ["REIVO_API_KEY"]}, "envVars": [{"name": "REIVO_API_KEY", "required": true, "description": "Reivo API key (starts with rv_). Service is currently offline."}], "author": "tazsat0512"}}
---

# Reivo — Discontinued

**This skill is no longer active. The Reivo service is currently offline and not accepting new users.**

If you previously installed this skill, it will no longer function. Please uninstall it:

```bash
npx clawhub@latest uninstall reivo
```

We may return in the future with a new direction. Thank you for your interest.
