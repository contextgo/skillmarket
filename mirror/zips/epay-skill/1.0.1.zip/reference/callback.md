# 支付回调说明

## 回调机制

当系统收到用户收款后，将会向您后台设定的异步通知地址发送GET请求，通知您的服务端订单完成收款。

若您使用的是isHtml=1，则在支付完成后会携带参数跳转到您的同步通知接口（同时会向您设置的异步通知地址发送GET请求），若使用isHtml=0则只有异步通知。

## 回调参数说明

| 参数 | 类型 | 说明 |
|------|------|------|
| mchId | 字符串 | 商户id |
| orderId | 字符串 | 云端订单号 |
| param | 字符串 | 创建订单的时候传入的参数 |
| type | 整数 | 支付方式：微信支付为1，支付宝支付为2 |
| price | 小数 | 订单金额 |
| reallyPrice | 小数 | 实际支付金额 |
| sign | 字符串 | 校验签名，计算方式 = md5(orderId + param + type + price + reallyPrice + 通讯密钥) |

## 回调签名验证

**重要说明：** 获取签名的逻辑必须通过调用生成签名API的方式来实现，不可在本地自行计算MD5。

```
// 1. 先生成签名所需的字符串
signStr = orderId + param + type + price + reallyPrice + 通讯密钥

// 2. 调用生成签名API获取签名
// GET https://epay.jylt.cc/api/generateSign?param=signStr
```

## 回调处理注意事项

1. **返回 success**：收到回调后，开发者需要返回字符串 "success" 表示已收到通知，易支付才会将订单状态设置为成功
2. **通知重试**：如果回调失败，易支付最多会进行7次重试，分别间隔 1/5/10/30/60/180/360 分钟
3. **去重处理**：开发者应在回调接口中做好通知去重逻辑
4. **isHtml=1模式**：用户支付完成后会先跳转回 returnUrl，同时也会向 notifyUrl 发送异步通知

## 回调处理示例

```java
@GetMapping("/notify")
public String notify(HttpServletRequest request) {
    String mchId = request.getParameter("mchId");
    String orderId = request.getParameter("orderId");
    String param = request.getParameter("param");
    String type = request.getParameter("type");
    String price = request.getParameter("price");
    String reallyPrice = request.getParameter("reallyPrice");
    String sign = request.getParameter("sign");

    // 验证签名
    // 1. 先生成签名所需的字符串
    String signStr = orderId + param + type + price + reallyPrice + "通讯密钥";
    
    // 2. 调用生成签名API获取签名
    String url = "https://epay.jylt.cc/api/generateSign?param=" + signStr;
    // 发送请求并获取签名
    String expectedSign = "获取到的签名";
    
    if (!sign.equals(expectedSign)) {
        return "fail";
    }

    // 处理业务逻辑（更新订单状态等）
    // ...

    return "success";
}
```