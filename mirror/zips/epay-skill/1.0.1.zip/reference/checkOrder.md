# 查询订单状态接口

## 请求地址

https://epay.jylt.cc/api/checkOrder

## 请求方式

GET/POST

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| orderId | 字符串 | 否 | 订单号，创建订单返回的（orderId、payId最少填一个） |
| payId | 字符串 | 否 | 支付单号，开发者自己创建的（orderId、payId最少填一个） |
| mchId | 字符串 | 是 | 商户id |

## 请求示例

```
GET https://epay.jylt.cc/api/checkOrder?orderId=1694523456789&mchId=1547130349673
```

## 返回数据说明

| 返回参数 | 类型 | 说明 |
|----------|------|------|
| code | 整数 | 1：订单已被支付，-1：支付失败，-2：订单未支付，-3：订单已过期 |
| msg | 字符串 | 调用结果说明 |
| data | 字符串 | 如果code为-1，则data为null，否则为该订单支付完成后的跳转地址（带回调参数） |

## 返回示例

**支付成功：**
```json
{
  "code": 1,
  "msg": "订单已支付",
  "data": "https://yourdomain.com/callback?orderId=1694523456789&param=xxx"
}
```

**等待支付：**
```json
{
  "code": -2,
  "msg": "订单未支付",
  "data": null
}
```

**订单过期：**
```json
{
  "code": -3,
  "msg": "订单已过期",
  "data": null
}
```