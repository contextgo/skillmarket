# 查询订单信息接口

## 请求地址

https://epay.jylt.cc/api/getOrder

## 请求方式

GET/POST

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| orderId | 字符串 | 否 | 云端订单号，创建订单返回的（orderId、payId最少填一个） |
| payId | 字符串 | 否 | 支付单号，开发者自己创建的（orderId、payId最少填一个） |
| mchId | 字符串 | 是 | 商户号 |

## 请求示例

```
GET https://epay.jylt.cc/api/getOrder?orderId=1694523456789&mchId=1547130349673
```

## 返回数据说明

| 返回参数 | 类型 | 说明 |
|----------|------|------|
| code | 整数 | 返回代码（1：成功，-1：调用失败） |
| msg | 字符串 | api调用结果说明 |
| data | 对象 | 如果code=-1，data为null |
| data.payId | 字符串 | 商户订单号 |
| data.orderId | 字符串 | 云端订单号，可用于查询订单是否支付成功 |
| data.payType | 整数 | 微信支付为1，支付宝支付为2 |
| data.price | 小数 | 订单金额 |
| data.reallyPrice | 小数 | 实际支付金额 |
| data.payUrl | 字符串 | 支付二维码内容 |
| data.isAuto | 整数 | 1需要手动输入金额，0扫码后自动输入金额 |
| data.state | 整数 | -1：订单过期，0：等待支付，1：支付成功 |
| data.timeOut | 整数 | 订单有效时间（分钟） |
| data.date | 整型 | 订单创建时间时间戳（13位） |

## 返回示例

```json
{
  "code": 1,
  "msg": "success",
  "data": {
    "payId": "2023091239201001",
    "orderId": "1694523456789",
    "payType": 2,
    "price": 0.01,
    "reallyPrice": 0.01,
    "payUrl": "https://qr.alipay.com/xxx",
    "isAuto": 0,
    "state": 1,
    "timeOut": 5,
    "date": 1694523456789
  }
}
```