# 创建订单接口

## 请求地址

https://epay.jylt.cc/api/createOrder

## 请求方式

GET/POST

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| mchId | 字符串 | 是 | 商户ID，在易支付后台获取 |
| payId | 字符串 | 是 | 商户支付单号，可以是时间戳，不可重复，长度最大50个字符 |
| type | 整数 | 是 | 微信支付传入1，支付宝支付传入2 |
| price | 小数 | 是 | 订单金额 |
| sign | 字符串 | 是 | 签名，计算方式为 md5(payId+param+type+price+通讯密钥) |
| goodsName | 字符串 | 是 | 商品名，长度最大50个字符 |
| param | 字符串 | 否 | 传输参数，将会原样返回到异步和同步通知接口 |
| isHtml | 整数 | 否 | 0：返回订单json数据；1：跳转到支付页面 |
| notifyUrl | 字符串 | 否 | 当前订单支付成功后的异步回调地址；如果不填，则使用在易支付管理平台填写的异步回调地址（最多200字符） |
| returnUrl | 字符串 | 否 | 如果isHtml=1，当前订单支付成功后跳转的页面地址；如果不填，则使用在易支付管理平台填写的同步回调地址（最多200字符） |
| timeoutUrl | 字符串 | 否 | 如果isHtml=1，当前订单支付超时后跳转的页面地址；如果不填，则使用在易支付管理平台填写的超时回调地址（最多200字符） |

## 请求示例

```
POST https://epay.jylt.cc/api/createOrder
Content-Type: application/x-www-form-urlencoded

mchId=1547130349673&payId=2023091239201001&type=2&price=0.01&sign=28943820b95019b6a63598a13c46f93f&goodsName=测试商品&param=uid:12&isHtml=0&notifyUrl=https://example.com/notify&returnUrl=https://example.com/return&timeoutUrl=https://example.com/timeout
```

## 返回数据说明

| 返回参数 | 类型 | 说明 |
|----------|------|------|
| code | 整数 | 返回代码（1：成功，-1：调用失败） |
| msg | 字符串 | api调用结果说明 |
| data | 对象 | 如果code=-1，data为null |
| data.payId | 字符串 | 商户支付单号 |
| data.orderId | 字符串 | 云端订单号，可用于查询订单是否支付成功 |
| data.payType | 整数 | 微信支付为1，支付宝支付为2 |
| data.price | 小数 | 订单金额 |
| data.reallyPrice | 小数 | 实际支付金额 |
| data.payUrl | 字符串 | 支付二维码图片url（如果url中含有\u003d，请将该字符替换为=） |
| data.isAuto | 整数 | 1需要手动输入金额，0扫码后自动输入金额 |
| data.state | 整数 | -1：订单过期，0：等待支付，1：支付成功，2:通知失败，3：账户余额不足 |
| data.timeOut | 整数 | 订单有效时间（分钟） |
| data.date | 整型 | 订单创建时间时间戳（13位） |

## 返回示例

```json
{
  "code": 1,
  "msg": "success",
  "data": {
    "payId": "2023091239201001",
    "orderId": "1694523456789",
    "payType": 2,
    "price": 0.01,
    "reallyPrice": 0.01,
    "payUrl": "https://qr.alipay.com/xxx",
    "isAuto": 0,
    "state": 0,
    "timeOut": 5,
    "date": 1694523456789
  }
}
```