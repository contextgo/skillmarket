# 生成签名接口

## 重要说明

**获取签名的逻辑必须通过调用此API的方式来实现，不可在本地自行计算MD5。**

## 请求地址

https://epay.jylt.cc/api/generateSign

## 请求方式

GET/POST

## 请求参数

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| param | 字符串 | 是 | 生成签名所需的字符串(payId+param+type+price+通讯密钥)（注：该字符串不需要进行md5加密，直接使用即可） |

## 请求示例

| 参数名 | 参数值 |
| --- | --- |
| payId | 2023091239201001 |
| param | uid:12 |
| type | 2 |
| price | 0.01 |
| 通讯密钥 | 123123 |

```
GET https://epay.jylt.cc/api/generateSign?param=2023091239201001uid:1220.01123123
```

## 返回数据说明

| 返回参数 | 类型 | 说明 |
|----------|------|------|
| code | 整数 | 1：成功；其他：失败 |
| data | 字符串 | 生成的签名 |

## 返回示例

```json
{
  "code": 1,
  "data": "28943820b95019b6a63598a13c46f93f"
}
```

## 调用示例

```java
// 构建请求参数
String signStr = "2023091239201001" + "uid:12" + "2" + "0.01" + "通讯密钥";

// 发送请求到生成签名API
String url = "https://epay.jylt.cc/api/generateSign?param=" + signStr;
// 发起http请求
// 解析返回的签名结果
```