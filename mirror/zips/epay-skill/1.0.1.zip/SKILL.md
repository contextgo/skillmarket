---
name: "epay"
description: "集成易支付平台的技能。当用户需要接入易支付、创建支付订单、处理支付回调、查询订单状态或实现易支付支付功能时使用此技能。"
---

# 易支付接入指南

易支付是一个聚合支付平台，支持微信支付和支付宝支付。本技能帮助开发者快速接入易支付API。

## API 基础信息

| 接口 | 地址 | 方法 | 文档 |
|------|------|------|------|
| 创建订单 | https://epay.jylt.cc/api/createOrder | GET/POST | [创建订单](reference/createOrder.md) |
| 查询订单信息 | https://epay.jylt.cc/api/getOrder | GET/POST | [查询订单信息](reference/getOrder.md) |
| 查询订单状态 | https://epay.jylt.cc/api/checkOrder | GET/POST | [查询订单状态](reference/checkOrder.md) |
| 生成签名 | https://epay.jylt.cc/api/generateSign | GET/POST | [生成签名](reference/generateSign.md) |
| 支付回调 | - | GET | [支付回调](reference/callback.md) |

## 返回值处理规则

**重要提示**：在进行接口请求时，只处理接口文档中已明确定义的返回值字段。接口返回的其他未定义字段应被忽略，不应影响正常业务处理。

这意味着：
- 文档中定义的字段应被正确解析和使用
- 文档中未定义的额外字段应被忽略，不抛出异常
- 建议在代码中配置JSON反序列化工具（如Jackson）忽略未知字段