#!/usr/bin/env python3
"""
财务指标计算器 - Financial Metrics Calculator
计算和分析各类财务指标，输出专业格式报告

使用方法:
    python financial_metrics.py --type profitability --data "revenue:100,cost:60,net_income:20,equity:80,assets:200"
    python financial_metrics.py --type liquidity --data "current_assets:150,current_liabilities:100,inventory:40,cash:30"
    python financial_metrics.py --type leverage --data "total_debt:80,total_assets:200,ebit:25,interest:5,equity:120"
    python financial_metrics.py --type valuation --data "market_cap:500,revenue:100,net_income:20,book_value:150,ebitda:30"
    python financial_metrics.py --type all --data "revenue:100,cost:60,gross_profit:40,opex:15,ebit:25,interest:3,tax:4,net_income:18,equity:100,assets:250,current_assets:80,current_liabilities:50,inventory:20,cash:20,total_debt:60"
"""

import argparse
import json
import sys
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional
from pathlib import Path

@dataclass
class FinancialMetrics:
    """财务指标集合"""
    # 盈利能力
    gross_margin: float = 0.0       # 毛利率 %
    operating_margin: float = 0.0   # 营业利润率 %
    net_margin: float = 0.0        # 净利率 %
    roe: float = 0.0               # 净资产收益率 %
    roa: float = 0.0              # 总资产收益率 %
    roic: float = 0.0             # 投资资本回报率 %

    # 偿债能力
    debt_ratio: float = 0.0        # 资产负债率 %
    current_ratio: float = 0.0     # 流动比率
    quick_ratio: float = 0.0       # 速动比率
    cash_ratio: float = 0.0        # 现金比率
    interest_coverage: float = 0.0 # 利息保障倍数

    # 运营效率
    asset_turnover: float = 0.0    # 资产周转率
    inventory_days: float = 0.0    # 存货周转天数
    receivable_days: float = 0.0   # 应收账款周转天数
    payable_days: float = 0.0      # 应付账款周转天数
    cash_conversion_cycle: float = 0.0 # 现金转换周期

    # 成长性
    revenue_growth: float = 0.0     # 收入增长率 %
    profit_growth: float = 0.0     # 利润增长率 %
    equity_growth: float = 0.0     # 净资产增长率 %

    # 估值指标
    pe: float = 0.0               # 市盈率
    pb: float = 0.0              # 市净率
    ps: float = 0.0              # 市销率
    ev_ebitda: float = 0.0        # EV/EBITDA

    # 每股指标
    eps: float = 0.0              # 每股收益
    bvps: float = 0.0            # 每股净资产
    dps: float = 0.0            # 每股股息

def parse_financial_data(data_str: str) -> Dict[str, float]:
    """解析财务数据字符串"""
    data = {}
    for item in data_str.split(','):
        parts = item.split(':')
        if len(parts) == 2:
            key = parts[0].strip().lower()
            value = float(parts[1].strip())
            data[key] = value
    return data

def calculate_profitability_metrics(data: Dict[str, float]) -> Dict[str, float]:
    """计算盈利能力指标"""
    metrics = {}

    revenue = data.get('revenue', 0)
    cost = data.get('cost', 0)
    gross_profit = data.get('gross_profit', revenue - cost)
    opex = data.get('opex', 0)
    ebit = data.get('ebit', gross_profit - opex)
    interest = data.get('interest', 0)
    ebt = ebit - interest
    tax = data.get('tax', 0)
    net_income = data.get('net_income', ebt - tax)
    equity = data.get('equity', 0)
    assets = data.get('assets', 0)

    # 毛利率
    if revenue > 0:
        metrics['gross_margin'] = gross_profit / revenue * 100

    # 营业利润率
    if revenue > 0:
        metrics['operating_margin'] = ebit / revenue * 100

    # 净利率
    if revenue > 0:
        metrics['net_margin'] = net_income / revenue * 100

    # ROE
    if equity > 0:
        metrics['roe'] = net_income / equity * 100

    # ROA
    if assets > 0:
        metrics['roa'] = net_income / assets * 100

    # ROIC
    if assets > 0 and equity > 0:
        invested_capital = assets - data.get('current_liabilities', 0)
        if invested_capital > 0:
            tax_rate = tax / ebt if ebt > 0 else 0
            roic = ebit * (1 - tax_rate) / invested_capital * 100
            metrics['roic'] = roic

    return metrics

def calculate_liquidity_metrics(data: Dict[str, float]) -> Dict[str, float]:
    """计算偿债能力指标"""
    metrics = {}

    current_assets = data.get('current_assets', 0)
    current_liabilities = data.get('current_liabilities', 0)
    inventory = data.get('inventory', 0)
    cash = data.get('cash', 0)
    total_liabilities = data.get('total_liabilities', current_liabilities)

    # 流动比率
    if current_liabilities > 0:
        metrics['current_ratio'] = current_assets / current_liabilities

    # 速动比率
    if current_liabilities > 0:
        quick_assets = current_assets - inventory
        metrics['quick_ratio'] = quick_assets / current_liabilities

    # 现金比率
    if current_liabilities > 0:
        metrics['cash_ratio'] = cash / current_liabilities

    return metrics

def calculate_leverage_metrics(data: Dict[str, float]) -> Dict[str, float]:
    """计算杠杆指标"""
    metrics = {}

    total_debt = data.get('total_debt', 0)
    total_assets = data.get('total_assets', 0)
    equity = data.get('equity', total_assets - total_debt)
    ebit = data.get('ebit', 0)
    interest = data.get('interest', 0)

    # 资产负债率
    if total_assets > 0:
        metrics['debt_ratio'] = total_debt / total_assets * 100

    # 利息保障倍数
    if interest > 0:
        metrics['interest_coverage'] = ebit / interest

    return metrics

def calculate_valuation_metrics(data: Dict[str, float]) -> Dict[str, float]:
    """计算估值指标"""
    metrics = {}

    market_cap = data.get('market_cap', 0)
    revenue = data.get('revenue', 0)
    net_income = data.get('net_income', 0)
    book_value = data.get('book_value', 0)
    ebitda = data.get('ebitda', data.get('ebit', 0))
    shares = data.get('shares_outstanding', 1)
    dps = data.get('dps', 0)

    # PE
    if net_income > 0:
        metrics['pe'] = market_cap / net_income

    # PB
    if book_value > 0:
        metrics['pb'] = market_cap / book_value

    # PS
    if revenue > 0:
        metrics['ps'] = market_cap / revenue

    # EV/EBITDA
    ev = market_cap + data.get('total_debt', 0) - data.get('cash', 0)
    if ebitda > 0:
        metrics['ev_ebitda'] = ev / ebitda

    # 每股指标
    if shares > 0:
        metrics['eps'] = net_income / shares
        metrics['bvps'] = book_value / shares
        metrics['dps'] = dps

    return metrics

def generate_metrics_report(metrics: FinancialMetrics, company_name: str = "目标公司") -> str:
    """生成财务指标报告"""

    def format_val(key: str, val: float) -> str:
        """格式化指标值"""
        if val == 0:
            return "N/A"
        if key in ['current_ratio', 'quick_ratio', 'cash_ratio', 'interest_coverage', 'pe', 'pb', 'ps', 'ev_ebitda']:
            return f"{val:.2f}"
        elif key in ['debt_ratio', 'gross_margin', 'operating_margin', 'net_margin', 'roe', 'roa', 'roic']:
            return f"{val:.2f}%"
        elif key in ['inventory_days', 'receivable_days', 'payable_days', 'cash_conversion_cycle']:
            return f"{val:.1f}天"
        elif key in ['asset_turnover']:
            return f"{val:.2f}次"
        else:
            return f"{val:.2f}"

    report = f"""
# {company_name} 财务指标分析报告

## 一、盈利能力

| 指标 | 数值 | 参考标准 | 评价 |
|------|------|---------|------|
| 毛利率 | {format_val('gross_margin', metrics.gross_margin)} | >30%优秀 | {'优秀' if metrics.gross_margin > 30 else '良好' if metrics.gross_margin > 15 else '一般'} |
| 营业利润率 | {format_val('operating_margin', metrics.operating_margin)} | >15%优秀 | {'优秀' if metrics.operating_margin > 15 else '良好' if metrics.operating_margin > 5 else '一般'} |
| 净利率 | {format_val('net_margin', metrics.net_margin)} | >10%优秀 | {'优秀' if metrics.net_margin > 10 else '良好' if metrics.net_margin > 5 else '一般'} |
| ROE | {format_val('roe', metrics.roe)} | >15%优秀 | {'优秀' if metrics.roe > 15 else '良好' if metrics.roe > 8 else '一般'} |
| ROA | {format_val('roa', metrics.roa)} | >5%优秀 | {'优秀' if metrics.roa > 5 else '良好' if metrics.roa > 2 else '一般'} |
| ROIC | {format_val('roic', metrics.roic)} | >WACC | {'创造价值' if metrics.roic > 8 else '消耗价值'} |

## 二、偿债能力

| 指标 | 数值 | 健康标准 | 评价 |
|------|------|---------|------|
| 资产负债率 | {format_val('debt_ratio', metrics.debt_ratio)} | <60% | {'健康' if metrics.debt_ratio < 60 else '偏高' if metrics.debt_ratio < 80 else '危险'} |
| 流动比率 | {format_val('current_ratio', metrics.current_ratio)} | >1.5 | {'优秀' if metrics.current_ratio > 2 else '良好' if metrics.current_ratio > 1.5 else '偏弱'} |
| 速动比率 | {format_val('quick_ratio', metrics.quick_ratio)} | >1.0 | {'优秀' if metrics.quick_ratio > 1.5 else '良好' if metrics.quick_ratio > 1 else '偏弱'} |
| 现金比率 | {format_val('cash_ratio', metrics.cash_ratio)} | >0.2 | {'充足' if metrics.cash_ratio > 0.3 else '正常' if metrics.cash_ratio > 0.2 else '偏低'} |
| 利息保障倍数 | {format_val('interest_coverage', metrics.interest_coverage)} | >3 | {'优秀' if metrics.interest_coverage > 5 else '良好' if metrics.interest_coverage > 3 else '偏弱'} |

## 三、估值指标

| 指标 | 数值 | 参考标准 | 说明 |
|------|------|---------|------|
| PE（市盈率） | {format_val('pe', metrics.pe)} | 行业均值 | 越低相对便宜 |
| PB（市净率） | {format_val('pb', metrics.pb)} | <3 | 低于净资产可能低估 |
| PS（市销率） | {format_val('ps', metrics.ps)} | 行业均值 | 成长股参考 |
| EV/EBITDA | {format_val('ev_ebitda', metrics.ev_ebitda)} | <15 | 资本密集型参考 |

## 四、综合评价

"""

    # 计算综合得分
    scores = []

    # 盈利能力得分
    if metrics.roe > 15:
        scores.append(('盈利能力', 25, 25))
    elif metrics.roe > 8:
        scores.append(('盈利能力', 25, 18))
    else:
        scores.append(('盈利能力', 25, 10))

    # 偿债能力得分
    if metrics.debt_ratio < 50 and metrics.current_ratio > 1.5:
        scores.append(('偿债能力', 20, 18))
    elif metrics.debt_ratio < 70:
        scores.append(('偿债能力', 20, 14))
    else:
        scores.append(('偿债能力', 20, 8))

    # 成长性得分
    if metrics.revenue_growth > 20:
        scores.append(('成长性', 25, 23))
    elif metrics.revenue_growth > 10:
        scores.append(('成长性', 25, 18))
    else:
        scores.append(('成长性', 25, 12))

    # 估值吸引力
    if metrics.pe > 0 and metrics.pe < 15:
        scores.append(('估值吸引力', 30, 25))
    elif metrics.pe < 25:
        scores.append(('估值吸引力', 30, 18))
    else:
        scores.append(('估值吸引力', 30, 10))

    total_score = sum(s[2] for s in scores)
    total_weight = sum(s[1] for s in scores)

    report += "| 维度 | 权重 | 得分 |\n|------|------|------|\n"
    for name, weight, score in scores:
        report += f"| {name} | {weight} | {score} |\n"

    report += f"""
| **综合得分** | {total_weight} | **{total_score}** |

> 综合评分标准：80-100分优秀，60-80分良好，40-60分一般，<40分较差

## 五、风险提示

"""

    risk_items = []
    if metrics.debt_ratio > 70:
        risk_items.append("资产负债率偏高，存在偿债压力")
    if metrics.current_ratio < 1:
        risk_items.append("流动比率不足，短期偿债风险")
    if metrics.cash_ratio < 0.1:
        risk_items.append("现金比率偏低，流动性紧张")
    if metrics.interest_coverage < 2:
        risk_items.append("利息保障不足，债务风险较大")
    if metrics.inventory_days > 180:
        risk_items.append("存货周转偏慢，存在积压风险")

    if risk_items:
        for i, risk in enumerate(risk_items, 1):
            report += f"{i}. {risk}\n"
    else:
        report += "财务指标整体健康，未发现明显风险信号。\n"

    report += "\n---\n*本报告由 Financial Analyst Skill 自动生成，仅供参考，不构成投资建议。*"

    return report

def main():
    parser = argparse.ArgumentParser(description='财务指标计算器')
    parser.add_argument('--type', choices=['profitability', 'liquidity', 'leverage', 'valuation', 'all'],
                        default='all', help='计算指标类型')
    parser.add_argument('--data', required=True,
                        help='财务数据，格式: key1:value1,key2:value2')
    parser.add_argument('--company', default='目标公司', help='公司名称')
    parser.add_argument('--output', default='financial_metrics.md', help='输出报告路径')

    args = parser.parse_args()

    print(f"[INFO] 正在解析财务数据...")
    data = parse_financial_data(args.data)
    print(f"[INFO] 已解析 {len(data)} 个数据项")

    # 计算指标
    metrics = FinancialMetrics()

    if args.type in ['profitability', 'all']:
        print(f"[INFO] 计算盈利能力指标...")
        p = calculate_profitability_metrics(data)
        for k, v in p.items():
            if hasattr(metrics, k):
                setattr(metrics, k, v)

    if args.type in ['liquidity', 'all']:
        print(f"[INFO] 计算偿债能力指标...")
        l = calculate_liquidity_metrics(data)
        for k, v in l.items():
            if hasattr(metrics, k):
                setattr(metrics, k, v)

    if args.type in ['leverage', 'all']:
        print(f"[INFO] 计算杠杆指标...")
        lev = calculate_leverage_metrics(data)
        for k, v in lev.items():
            if hasattr(metrics, k):
                setattr(metrics, k, v)

    if args.type in ['valuation', 'all']:
        print(f"[INFO] 计算估值指标...")
        v = calculate_valuation_metrics(data)
        for k, v_val in v.items():
            if hasattr(metrics, k):
                setattr(metrics, k, v_val)

    # 生成报告
    report = generate_metrics_report(metrics, args.company)

    # 保存报告
    Path(args.output).write_text(report, encoding='utf-8')
    print(f"\n[OK] 财务指标报告已保存: {args.output}")

    # 打印关键指标
    print(f"\n[关键指标摘要]")
    print(f"  毛利率: {metrics.gross_margin:.2f}%")
    print(f"  净利率: {metrics.net_margin:.2f}%")
    print(f"  ROE: {metrics.roe:.2f}%")
    print(f"  资产负债率: {metrics.debt_ratio:.2f}%")
    print(f"  流动比率: {metrics.current_ratio:.2f}")
    if metrics.pe > 0:
        print(f"  PE: {metrics.pe:.2f}")
    if metrics.pb > 0:
        print(f"  PB: {metrics.pb:.2f}")

if __name__ == '__main__':
    main()
