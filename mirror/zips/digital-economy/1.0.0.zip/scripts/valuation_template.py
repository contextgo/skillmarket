#!/usr/bin/env python3
"""
财务估值模板 - Financial Valuation Template
支持 DCF 估值、可比公司法、敏感性分析

使用方法:
    python valuation_template.py --method dcf --company "某公司"
    python valuation_template.py --method comps --companies "公司A,公司B,公司C"
"""

import argparse
import json
from dataclasses import dataclass, asdict
from typing import List, Dict, Optional
from pathlib import Path

# ============================================================
# 估值模型类
# ============================================================

@dataclass
class DCFInputs:
    """DCF 估值输入参数"""
    company_name: str
    current_revenue: float          # 当前收入（亿）
    revenue_growth_rate: float      # 收入增速（%）
    operating_margin: float          # 营业利润率（%）
    tax_rate: float                 # 所得税率（%）
    da_rate: float                  # 折旧摊销/收入（%）
    capex_rate: float               # 资本支出/收入（%）
    nwc_rate: float                 # 营运资本增加/收入增量（%）
    wacc: float                     # 加权平均资本成本（%）
    terminal_growth: float          # 永续增长率（%）
    shares_outstanding: float       # 流通股数（亿股）
    net_debt: float                 # 净负债（亿）
    forecast_years: int = 5          # 预测期（年）

@dataclass
class DCFResult:
    """DCF 估值结果"""
    company_name: str
    forecast_cashflows: List[Dict]
    terminal_value: float
    pv_of_cashflows: float
    pv_of_terminal: float
    enterprise_value: float
    equity_value: float
    target_price: float
    upside_downside: float
    wacc: float
    terminal_growth: float

def calculate_dcf(inputs: DCFInputs) -> DCFResult:
    """执行 DCF 估值计算"""

    # Step 1: 预测各年自由现金流
    cashflows = []
    revenue = inputs.current_revenue

    for year in range(1, inputs.forecast_years + 1):
        # 收入增长
        revenue *= (1 + inputs.revenue_growth_rate / 100)

        # EBIT
        ebit = revenue * inputs.operating_margin / 100

        # 税后营业利润 (NOPAT)
        nopat = ebit * (1 - inputs.tax_rate / 100)

        # 折旧摊销
        da = revenue * inputs.da_rate / 100

        # 资本支出
        capex = revenue * inputs.capex_rate / 100

        # 营运资本增加
        nwc_increase = (revenue - inputs.current_revenue * (1 + inputs.revenue_growth_rate/100)**(year-1)) * inputs.nwc_rate / 100

        # 自由现金流
        fcf = nopat + da - capex - nwc_increase

        # 折现
        discount_factor = (1 + inputs.wacc / 100) ** year
        pv_fcf = fcf / discount_factor

        cashflows.append({
            'year': year,
            'revenue': round(revenue, 2),
            'ebit': round(ebit, 2),
            'nopat': round(nopat, 2),
            'da': round(da, 2),
            'capex': round(capex, 2),
            'nwc': round(nwc_increase, 2),
            'fcf': round(fcf, 2),
            'pv_fcf': round(pv_fcf, 2)
        })

    # Step 2: 永续价值
    last_fcf = cashflows[-1]['fcf']
    terminal_value = last_fcf * (1 + inputs.terminal_growth / 100) / (inputs.wacc / 100 - inputs.terminal_growth / 100)

    # Step 3: PV of Cashflows
    pv_cashflows = sum(c['pv_fcf'] for c in cashflows)

    # Step 4: PV of Terminal Value
    pv_terminal = terminal_value / (1 + inputs.wacc / 100) ** inputs.forecast_years

    # Step 5: Enterprise Value
    ev = pv_cashflows + pv_terminal

    # Step 6: Equity Value
    equity_value = ev - inputs.net_debt

    # Step 7: Target Price
    target_price = equity_value / inputs.shares_outstanding

    return DCFResult(
        company_name=inputs.company_name,
        forecast_cashflows=cashflows,
        terminal_value=round(terminal_value, 2),
        pv_of_cashflows=round(pv_cashflows, 2),
        pv_of_terminal=round(pv_terminal, 2),
        enterprise_value=round(ev, 2),
        equity_value=round(equity_value, 2),
        target_price=round(target_price, 2),
        upside_downside=0,  # 需要current price计算
        wacc=inputs.wacc,
        terminal_growth=inputs.terminal_growth
    )

def generate_sensitivity_analysis(base_inputs: DCFInputs,
                                  wacc_range: tuple = (6, 12),
                                  g_range: tuple = (1, 5)) -> List[Dict]:
    """敏感性分析：WACC vs 永续增长率"""

    results = []
    waccs = [wacc_range[0] + i for i in range(wacc_range[1] - wacc_range[0] + 1)]
    gs = [g_range[0] + i * 0.5 for i in range(int((g_range[1] - g_range[0]) / 0.5) + 1)]

    for wacc in waccs:
        row = {'wacc': f'{wacc}%'}
        for g in gs:
            inputs = DCFInputs(
                company_name=base_inputs.company_name,
                current_revenue=base_inputs.current_revenue,
                revenue_growth_rate=base_inputs.revenue_growth_rate,
                operating_margin=base_inputs.operating_margin,
                tax_rate=base_inputs.tax_rate,
                da_rate=base_inputs.da_rate,
                capex_rate=base_inputs.capex_rate,
                nwc_rate=base_inputs.nwc_rate,
                wacc=wacc,
                terminal_growth=g,
                shares_outstanding=base_inputs.shares_outstanding,
                net_debt=base_inputs.net_debt,
                forecast_years=base_inputs.forecast_years
            )
            result = calculate_dcf(inputs)
            row[f'g={g}%'] = f'{result.target_price:.1f}'

        results.append(row)

    return results

# ============================================================
# 可比公司法
# ============================================================

@dataclass
class ComparableCompany:
    """可比公司"""
    name: str
    ticker: str
    market_cap: float          # 市值（亿）
    pe_ttm: float             # 市盈率 TTM
    pe_forward: float         # 市盈率 前向
    pb: float                 # 市净率
    ps: float                 # 市销率
    ev_ebitda: float          # EV/EBITDA
    dividend_yield: float     # 股息率
    revenue_growth: float     # 收入增速
    net_margin: float         # 净利率

@dataclass
class ComparableValuation:
    """可比估值结果"""
    target_name: str
    target_metrics: Dict
    comps_multiples: List[Dict]
    valuation_by_pe: float
    valuation_by_pb: float
    valuation_by_ps: float
    valuation_by_ev_ebitda: float
    average_valuation: float
    recommended_price: float

def calculate_comparable_valuation(target_revenue: float,
                                    target_net_income: float,
                                    target_book_value: float,
                                    target_ebitda: float,
                                    comps: List[ComparableCompany]) -> ComparableValuation:
    """可比公司法估值"""

    # 计算各指标下的估值
    valuations = {}

    # PE 估值
    pe_multiples = [c.pe_ttm for c in comps if c.pe_ttm > 0]
    if pe_multiples:
        avg_pe = sum(pe_multiples) / len(pe_multiples)
        median_pe = sorted(pe_multiples)[len(pe_multiples)//2]
        valuations['PE'] = {
            'avg': target_net_income * avg_pe,
            'median': target_net_income * median_pe
        }

    # PB 估值
    pb_multiples = [c.pb for c in comps if c.pb > 0]
    if pb_multiples:
        avg_pb = sum(pb_multiples) / len(pb_multiples)
        median_pb = sorted(pb_multiples)[len(pb_multiples)//2]
        valuations['PB'] = {
            'avg': target_book_value * avg_pb,
            'median': target_book_value * median_pb
        }

    # PS 估值
    ps_multiples = [c.ps for c in comps if c.ps > 0]
    if ps_multiples:
        avg_ps = sum(ps_multiples) / len(ps_multiples)
        median_ps = sorted(ps_multiples)[len(ps_multiples)//2]
        valuations['PS'] = {
            'avg': target_revenue * avg_ps,
            'median': target_revenue * median_ps
        }

    # EV/EBITDA 估值
    ev_ebitda_multiples = [c.ev_ebitda for c in comps if c.ev_ebitda > 0]
    if ev_ebitda_multiples:
        avg_ev_ebitda = sum(ev_ebitda_multiples) / len(ev_ebitda_multiples)
        median_ev_ebitda = sorted(ev_ebitda_multiples)[len(ev_ebitda_multiples)//2]
        valuations['EV/EBITDA'] = {
            'avg': target_ebitda * avg_ev_ebitda,
            'median': target_ebitda * median_ev_ebitda
        }

    # 综合估值（取中位数平均）
    all_values = []
    if 'PE' in valuations:
        all_values.append(valuations['PE']['median'])
    if 'PB' in valuations:
        all_values.append(valuations['PB']['median'])
    if 'PS' in valuations:
        all_values.append(valuations['PS']['median'])
    if 'EV/EBITDA' in valuations:
        all_values.append(valuations['EV/EBITDA']['median'])

    avg_valuation = sum(all_values) / len(all_values) if all_values else 0

    return ComparableValuation(
        target_name=target_name,
        target_metrics={
            'revenue': target_revenue,
            'net_income': target_net_income,
            'book_value': target_book_value,
            'ebitda': target_ebitda
        },
        comps_multiples=[{
            'name': c.name,
            'PE': c.pe_ttm,
            'PB': c.pb,
            'PS': c.ps,
            'EV/EBITDA': c.ev_ebitda
        } for c in comps],
        valuation_by_pe=valuations.get('PE', {}).get('median', 0),
        valuation_by_pb=valuations.get('PB', {}).get('median', 0),
        valuation_by_ps=valuations.get('PS', {}).get('median', 0),
        valuation_by_ev_ebitda=valuations.get('EV/EBITDA', {}).get('median', 0),
        average_valuation=round(avg_valuation, 2),
        recommended_price=round(avg_valuation, 2)
    )

# ============================================================
# 报告生成
# ============================================================

def generate_valuation_report(dcf_result: DCFResult,
                              sensitivity: List[Dict],
                              current_price: float = None) -> str:
    """生成估值分析报告"""

    report = f"""
# {dcf_result.company_name} DCF 估值分析报告

## 一、估值假设

| 参数 | 数值 | 说明 |
|------|------|------|
| WACC | {dcf_result.wacc}% | 加权平均资本成本 |
| 永续增长率 | {dcf_result.terminal_growth}% | 长期增速假设 |
| 预测期 | 5年 | 标准预测周期 |

## 二、现金流预测（单位：亿元）

| 年份 | 收入 | EBIT | NOPAT | D&A | Capex | NWC | FCF | PV(FCF) |
|------|------|------|-------|-----|-------|-----|-----|---------|
"""

    for cf in dcf_result.forecast_cashflows:
        report += f"| {cf['year']}年 | {cf['revenue']} | {cf['ebit']} | {cf['nopat']} | {cf['da']} | {cf['capex']} | {cf['nwc']} | {cf['fcf']} | {cf['pv_fcf']} |\n"

    report += f"""
## 三、估值结果

| 项目 | 数值（亿元）|
|------|-------------|
| 预测期现金流现值 | {dcf_result.pv_of_cashflows} |
| 永续价值 | {dcf_result.terminal_value} |
| 永续价值现值 | {dcf_result.pv_of_terminal} |
| **企业价值（EV）** | **{dcf_result.enterprise_value}** |
| 减：净负债 | {dcf_result.equity_value + dcf_result.enterprise_value - dcf_result.equity_value if dcf_result.equity_value < dcf_result.enterprise_value else dcf_result.enterprise_value - dcf_result.equity_value} |
| **股权价值** | **{dcf_result.equity_value}** |

## 四、敏感性分析（WACC vs 永续增长率）

| WACC \\ g | {''.join([f'{k.split('=')[1]}' for k in sensitivity[0].keys() if '=' in k])} |
|----------|{'-' * (12 * len([k for k in sensitivity[0].keys() if '=' in k]))}|
"""

    for row in sensitivity:
        g_values = ' | '.join([row[k] for k in sorted(row.keys()) if k != 'wacc'])
        report += f"| {row['wacc']} | {g_values} |\n"

    if current_price:
        upside = (dcf_result.target_price - current_price) / current_price * 100
        report += f"""
## 五、投资建议

| 指标 | 数值 |
|------|------|
| 当前股价 | {current_price:.2f}元 |
| DCF 目标价 | {dcf_result.target_price:.2f}元 |
| 潜在涨跌幅 | {upside:+.1f}% |
| 评级建议 | {'买入' if upside > 20 else '增持' if upside > 0 else '中性' if upside > -20 else '减持'} |

> 注：以上估值仅供参考，不构成投资建议。实际投资需结合公司基本面、市场环境和个人风险偏好综合判断。
"""

    return report

# ============================================================
# 主函数
# ============================================================

def main():
    parser = argparse.ArgumentParser(description='财务估值模板')
    parser.add_argument('--method', choices=['dcf', 'comps'], default='dcf',
                        help='估值方法: dcf(现金流折现), comps(可比公司法)')
    parser.add_argument('--company', default='目标公司', help='公司名称')
    parser.add_argument('--revenue', type=float, default=100, help='当前收入（亿元）')
    parser.add_argument('--growth', type=float, default=15, help='收入增速（%%）')
    parser.add_argument('--margin', type=float, default=20, help='营业利润率（%%）')
    parser.add_argument('--wacc', type=float, default=9, help='WACC（%%）')
    parser.add_argument('--terminal_g', type=float, default=3, help='永续增长率（%%）')
    parser.add_argument('--shares', type=float, default=10, help='流通股数（亿股）')
    parser.add_argument('--net_debt', type=float, default=20, help='净负债（亿元）')
    parser.add_argument('--current_price', type=float, help='当前股价（用于计算涨跌幅）')
    parser.add_argument('--output', default='valuation_report.md', help='输出报告路径')

    args = parser.parse_args()

    print(f"[INFO] 开始执行 {args.method.upper()} 估值分析...")
    print(f"[INFO] 目标公司: {args.company}")

    if args.method == 'dcf':
        # 构建 DCF 输入
        inputs = DCFInputs(
            company_name=args.company,
            current_revenue=args.revenue,
            revenue_growth_rate=args.growth,
            operating_margin=args.margin,
            tax_rate=15,          # 默认15%所得税率
            da_rate=3,             # 默认3%折旧摊销率
            capex_rate=4,         # 默认4%资本支出率
            nwc_rate=10,          # 默认10%营运资本增加率
            wacc=args.wacc,
            terminal_growth=args.terminal_g,
            shares_outstanding=args.shares,
            net_debt=args.net_debt,
            forecast_years=5
        )

        # 执行 DCF
        result = calculate_dcf(inputs)
        sensitivity = generate_sensitivity_analysis(inputs)

        # 生成报告
        report = generate_valuation_report(result, sensitivity, args.current_price)

        # 保存报告
        Path(args.output).write_text(report, encoding='utf-8')
        print(f"[OK] 估值报告已保存: {args.output}")
        print(f"\n[结果摘要]")
        print(f"  企业价值: {result.enterprise_value} 亿元")
        print(f"  股权价值: {result.equity_value} 亿元")
        print(f"  目标股价: {result.target_price} 元")

        if args.current_price:
            upside = (result.target_price - args.current_price) / args.current_price * 100
            print(f"  潜在涨跌幅: {upside:+.1f}%")

    else:
        print("[INFO] 可比公司法需要提供可比公司数据，请通过 Python 代码调用 calculate_comparable_valuation() 函数")
        print("[INFO] 示例代码:")
        print("""
from valuation_template import ComparableCompany, calculate_comparable_valuation

comps = [
    ComparableCompany(name='可比A', ticker='000001', market_cap=1000, pe_ttm=20,
                      pe_forward=18, pb=3, ps=5, ev_ebitda=15, dividend_yield=2,
                      revenue_growth=15, net_margin=10),
    # 添加更多可比公司...
]

result = calculate_comparable_valuation(
    target_revenue=100,     # 目标公司收入
    target_net_income=20,    # 目标公司净利润
    target_book_value=80,   # 目标公司净资产
    target_ebitda=30,       # 目标公司EBITDA
    comps=comps
)
print(f"推荐估值: {result.recommended_price} 亿元")
        """)

if __name__ == '__main__':
    main()
