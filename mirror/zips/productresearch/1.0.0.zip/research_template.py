#!/usr/bin/env python3
"""
竞品调研报告生成器
用法: python3 research_template.py <公司名> <工作目录>
输出: {公司名}_竞品调研报告.docx
"""
import sys, os, ssl
from docx import Document
from docx.shared import Pt, RGBColor, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import fitz

# ====================================================================
# 字体/样式配置
# ====================================================================
def reset_styles(doc):
    styles = doc.styles
    styles['Normal'].font.name = 'SimSun'
    styles['Normal'].font.size = Pt(12)
    styles['Normal'].font.color.rgb = RGBColor(0x33,0x33,0x33)
    def h1_st(name, sz, rgb, sp=12, sa=6):
        st = styles.get(name, None) or styles.add_style(name, 1)
        st.font.name='SimSun'; st.font.size=Pt(sz); st.font.bold=True
        st.font.color.rgb=RGBColor(*rgb)
        st.paragraph_format.space_before=Pt(sp)
        st.paragraph_format.space_after=Pt(sa)
        return st
    reset_heading('Heading 1', 24, (0x1F,0x4E,0x79))
    reset_heading('Heading 2', 18, (0x2E,0x75,0xB6))
    reset_heading('Heading 3', 14, (0x3A,0x8C,0xC7))
    return doc

def reset_heading(name, size_pt, rgb, sp=10, sa=4):
    styles = Document().styles  # stub below
    styles['Normal'].font.name='SimSun'; styles['Normal'].font.size=Pt(12); styles['Normal'].font.color.rgb=RGBColor(0x33,0x33,0x33)
    # Heading styles re-define after doc creation — see init_doc()
    pass

def init_doc(company_name, output_path):
    """初始化文档：页面设置、页眉页脚、字体"""
    doc = Document()
    s = doc.sections[0]
    s.page_width=Cm(21); s.page_height=Cm(29.7)
    s.left_margin=Cm(2.54); s.right_margin=Cm(2.54)
    s.top_margin=Cm(2.54); s.bottom_margin=Cm(2.54)
    # 页眉
    hp=s.header.paragraphs[0]; hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    r=hp.add_run(f'{company_name} 竞品调研报告  |  {company_name} Competitive Research')
    r.font.name='SimSun'; r.font.size=Pt(9)
    r.font.color.rgb=RGBColor(0x2E,0x75,0xB6)
    pPr=hp._p.get_or_add_pPr()
    pBdr=OxmlElement('w:pBdr')
    b=OxmlElement('w:bottom'); b.set(qn('w:val'),'single')
    b.set(qn('w:sz'),'6'); b.set(qn('w:space'),'1')
    b.set(qn('w:color'),'2E75B6')
    pBdr.append(b); pPr.append(pBdr)
    # 页脚
    fp=s.footer.paragraphs[0]; fp.alignment=WD_ALIGN_PARAGRAPH.CENTER
    r2=fp.add_run('第 '); r2.font.name='SimSun'; r2.font.size=Pt(9)
    r2.font.color.rgb=RGBColor(0x88,0x88,0x88)
    r3=fp.add_run()
    f1=OxmlElement('w:fldChar'); f1.set(qn('w:fldCharType'),'begin')
    it=OxmlElement('w:instrText')
    it.set(qn('xml:space'),'preserve'); it.text='PAGE'
    f2=OxmlElement('w:fldChar'); f2.set(qn('w:fldCharType'),'end')
    r3._r.append(f1); r3._r.append(it); r3._r.append(f2)
    r3.font.name='SimSun'; r3.font.size=Pt(9)
    r3.font.color.rgb=RGBColor(0x88,0x88,0x88)
    r4=fp.add_run(' 页'); r4.font.name='SimSun'; r4.font.size=Pt(9)
    r4.font.color.rGB=RGBColor(0x88,0x88,0x88)
    # 全局样式
    styles=doc.styles
    styles['Normal'].font.name='SimSun'
    styles['Normal'].font.size=Pt(12)
    styles['Normal'].font.color.rgb=RGBColor(0x33,0x33,0x33)
    # Heading1/2/3 重定义
    for hname, sz, rgb in [('Heading 1',24,(0x1F,0x4E,0x79)),
                            ('Heading 2',18,(0x2E,0x75,0xB6)),
                            ('Heading 3',14,(0x3A,0x8C,0xC7))]:
        if hname in styles:
            st=styles[hname]
        else:
            st=styles.add_style(hname,1)
        st.font.name='SimSun'; st.font.size=Pt(sz); st.bold=True
        st.font.color.rgb=RGBColor(*rgb)
        st.paragraph_format.space_before=Pt(12)
        st.paragraph_format.space_after=Pt(6)
    return doc

# ====================================================================
# 工具函数
# ====================================================================

def shd(cell, fill):
    tc=cell._tc; p=tc.get_or_add_tcPr()
    x=OxmlElement('w:shd')
    x.set(qn('w:val'),'clear')
    x.set(qn('w:color'),'auto')
    x.set(qn('w:fill'),fill)
    p.append(x)

def p(doc, text, sz=12, bold=False, ital=False, c=None, align=WD_ALIGN_PARAGRAPH.LEFT):
    para=doc.add_paragraph()
    para.alignment=align
    para.paragraph_format.space_after=Pt(3)
    run=para.add_run(text)
    run.font.name='SimSun'; run.font.size=Pt(sz)
    run.bold=bold; run.italic=ital
    if c: run.font.color.rgb=RGBColor(*c)
    return para

def h1(doc, text):
    return doc.add_heading(text, level=1)

def h2(doc, text):
    return doc.add_heading(text, level=2)

def h3(doc, text):
    return doc.add_heading(text, level=3)

def pb(doc):
    doc.add_page_break()

def tbl(doc, hdrs, rows, ws):
    tbl=doc.add_table(rows=0, cols=len(hdrs)); tbl.style='Table Grid'
    hr=tbl.add_row()
    for i,h in enumerate(hdrs):
        c=hr.cells[i]; c.text=h
        c.paragraphs[0].runs[0].font.name='SimSun'
        c.paragraphs[0].runs[0].font.size=Pt(9)
        c.paragraphs[0].runs[0].bold=True
        c.paragraphs[0].runs[0].font.color.rgb=RGBColor(255,255,255)
        c.paragraphs[0].alignment=WD_ALIGN_PARAGRAPH.CENTER
        shd(c,'2E75B6')
    for ri,row in enumerate(rows):
        dr=tbl.add_row()
        for ci,v in enumerate(row):
            cell=dr.cells[ci]; cell.text=str(v)
            cell.paragraphs[0].runs[0].font.name='SimSun'
            cell.paragraphs[0].runs[0].size=Pt(9)
            if ri%2==1: shd(cell,'EFF5FF')
    for i,w in enumerate(ws):
        for row in tbl.rows:
            row.cells[i].width=Cm(w)
    doc.add_paragraph()

def img_inline(doc, img_path, w_cm=14.5, cap='', note='', screenshots_dir=''):
    full_path=os.path.join(screenshots_dir, img_path) if screenshots_dir else img_path
    if not os.path.exists(full_path):
        p(doc,f'[图片缺失: {img_path}]', sz=9, ital=True, c=(0xCC,0x00,0x00))
        return
    para=doc.add_paragraph()
    para.alignment=WD_ALIGN_PARAGRAPH.CENTER
    para.paragraph_format.space_before=Pt(6); para.paragraph_format.space_after=Pt(4)
    para.add_run().add_picture(full_path, width=Cm(w_cm))
    if cap:
        p2=doc.add_paragraph()
        p2.alignment=WD_ALIGN_PARAGRAPH.CENTER
        r2=p2.add_run(cap); r2.font.name='SimSun'
        r2.font.size=Pt(10); r2.bold=True; r2.font.color.rgb=RGBColor(0x44,0x44,0x44)
    if note:
        p3=doc.add_paragraph()
        p3.alignment=WD_ALIGN_PARAGRAPH.CENTER
        r3=p3.add_run(note); r3.font.name='SimSun'
        r3.font.size=Pt(9); r3.italic=True
        r3.font.color.rgb=RGBColor(0x88,0x88,0x88)
    doc.add_paragraph()

def divider(doc):
    para=doc.add_paragraph()
    para.paragraph_format.space_before=Pt(4); para.paragraph_format.space_after=Pt(4)
    pPr=para._p.get_or_add_pPr()
    pBdr=OxmlElement('w:pBdr')
    b=OxmlElement('w:bottom'); b.set(qn('w:val'),'single')
    b.set(qn('w:sz'),'6'); b.set(qn('w:space'),'1')
    b.set(qn('w:color'),'2E75B6')
    pBdr.append(b); pPr.append(pBdr)

# ====================================================================
# PDF 下载工具
# ====================================================================

def download_pdf(url, output_path, headers=None):
    """下载 PDF，支持 SSL 绕过和自定义 headers"""
    import urllib.request
    ctx=ssl._create_unverified_context()
    headers=headers or {
        'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7 AppleWebKit/537.36 Chrome/120.0 Safari/537.36'
    }
    req=urllib.request.Request(url, headers=headers)
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=40) as r:
            with open(output_path,'wb') as f:
                f.write(r.read())
            return True, output_path
    except Exception as e:
        return False, str(e)

def extract_pdf_text(pdf_path):
    """提取 PDF 全文文本"""
    try:
        import fitz
        doc=fitz.open(pdf_path)
        texts=[]
        for i in range(min(doc.page_count, 5):  # 前5页摘要
            t=doc[i].get_text().strip()
            if t: texts.append(f'P{i+1}: {t[:500]}')
        doc.close()
        return True, '\n\n'.join(texts)
    except Exception as e:
        return False, str(e)

def render_pdf_pages(pdf_path, output_dir, pages=None):
    """渲染 PDF 页面为 PNG（每页 2x 缩放"""
    import fitz, os
    os.makedirs(output_dir, exist_ok=True)
    try:
        doc=fitz.open(pdf_path)
        pages=pages or range(doc.page_count)
        results=[]
        for i in pages:
            if i >= doc.page_count: continue
            mat=fitz.Matrix(2, 2)
            pix=doc[i].get_pixmap(matrix=mat)
            fname=os.path.join(output_dir, f'page{i+1}.png')
            pix.save(fname)
            results.append(fname)
        doc.close()
        return True, results
    except Exception as e:
        return False, str(e)

# ====================================================================
# Web 搜索摘要
# ====================================================================

def web_search_summary(queries):
    """
    queries: list of (query_string, max_results) tuples
    返回: list of search results
    Agent 在执行时替换为真实 web_search 调用
    """
    # 占位符——Agent 执行时替换为真实搜索
    return [{'placeholder': True, 'queries': list(queries)}]

# ====================================================================
# 报告生成入口
# ====================================================================

def generate_report(company_name, output_dir, screenshots_dir, pdf_paths=None, research_data=None):
    """
    生成完整调研报告 Word 文档
    
    research_data: dict，可选，包含:
      - background: str
      - services: list of str
      - market_data: list of list
      - app_info: dict
      - user_feedback: dict
      - pdf_text: str
    """
    doc=init_doc(company_name, output_dir)
    report_path=os.path.join(output_dir, f'{company_name}_竞品调研报告.docx')
    doc.save(report_path)
    return report_path

if __name__=='__main__':
    if len(sys.argv)<3:
        print('用法: python3 research_template.py <公司名> <输出目录>')
        sys.exit(1)
    company=sys.argv[1]
    out_dir=sys.argv[2]
    os.makedirs(out_dir, exist_ok=True)
    screenshots=os.path.join(out_dir,'screenshots')
    os.makedirs(screenshots, exist_ok=True)
    path=generate_report(company, out_dir, screenshots)
    print(f'报告已生成: {path}')
