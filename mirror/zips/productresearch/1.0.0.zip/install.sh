#!/bin/bash
# install.sh — 安装竞品调研 Skill 到 WorkBuddy skills 目录
# 用法: bash install.sh

TARGET="$HOME/.workbuday/skills/competitive_research"
DEST="$HOME/.workbuddy/skills/competitive_research"

# 检测 CodeBuddy vs WorkBuddy
if [ -d "$HOME/.codebuddy/skills" ]; then
    DEST="$HOME/.codebuddy/skills/competitive_research"
elif [ -d "$HOME/.clawbuddy/skills" ]; then
    DEST="$HOME/.clawbuddy/skills/competitive_research"
else
    DEST="$HOME/.workbuddy/skills/competitive_research"
fi

mkdir -p "$DEST"
cp -r . "$DEST/"
echo "✅ Skill 已安装到: $DEST"
echo "📱 重启 WorkBuddy 即可使用"
echo "💡 输入「调研 XX 公司」开始竞品调研"
