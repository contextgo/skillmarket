# 竞品调研 Skill

## 功能
输入公司名，自动完成竞品深度调研，输出格式规范的 Word 报告。

## 工具链

| 步骤 | 工具 | 说明 |
|------|------|------|
| 1. 背景调研 | web_search + web_fetch | 官网、年报、新闻 |
| 2. 竞品信息 | web_search | 市场份额、竞争格局 |
| 3. App 数据 | web_fetch（App Store/Google Play） | 评分、功能、版本历史 |
| 4. PDF 手册 | urllib.request + SSL绕过 | 下载官方手册 |
| 5. 截图提取 | PyMuPDF 2x 渲染 | PDF 页面渲染 PNG |
| 6. 报告生成 | python-docx | 格式规范 Word 报告 |

## 输出规范（固化）

| 元素 | 规范 |
|------|------|
| 正文字体 | SimSun 12pt |
| 标题一/二/三 | SimSun 加粗，三级蓝色分层 |
| 表格 | 交替行底色，表头白底蓝字 |
| 截图 | PDF 每页 2x PNG，嵌入 Word |
| 页眉 | 公司名 + 日期，右对齐 |
| 页码 | 居中页脚 |

## 调用方式
用户说「调研XXX公司」→ agent 自动执行全流程 → 输出 {公司名}_竞品调研报告.docx

## 核心文件
- `research_template.py` — 报告生成模板（工具函数 + 入口）
- `SKILL.md` — 本文件
