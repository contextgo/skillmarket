# 医保混合收款成功通知说明（服务商 - Go）

> 内容与 [`Java/6-回调通知/医保混合收款成功通知说明.md`](../../Java/6-回调通知/医保混合收款成功通知说明.md) 完全一致；本副本仅为 Go 项目按目录约定查找方便而存在。

> 来源：[服务商医保混合收款成功通知](https://pay.weixin.qq.com/doc/v3/partner/4012165722.md) / [间连医保混合收款成功通知](https://pay.weixin.qq.com/doc/v3/partner/4018303231.md)（结构一致）
> 通用解密 / 验签 / 回包流程参考 [📄 ../../../接入指南/回调处理.md](../../../接入指南/回调处理.md)

## 一、回调时机

当订单 `mix_pay_status = MIX_PAY_SUCCESS` 时，微信支付通过 POST 向服务商医保下单接口中传入的 `callback_url` 发送通知。

| 事件类型 | 含义 |
| --- | --- |
| `MEDICAL_INSURANCE.SUCCESS` | 医保混合收款成功 |

> ‼️ 多个子商户共用同一 `notify_url`，**必须**按解密后的 `sub_mchid` 路由业务，否则会出现串单。
> ‼️ 微信仅在订单达到 `MIX_PAY_SUCCESS` 时回调一次。若 5 秒内未收到 200/204，将按指数退避重试，30 秒后**不再重试**。
> ‼️ **必须**对 `MIX_PAY_CREATED` 状态订单做主动查询兜底（`GET /v3/med-ins/orders/mix-trade-no/{mix_trade_no}?sub_mchid=...`）。

## 二、HTTP 头

与商户场景一致：`Wechatpay-Serial` / `Wechatpay-Signature` / `Wechatpay-Timestamp` / `Wechatpay-Nonce`，验签使用**服务商**的微信支付公钥（推荐）或微信支付平台证书。

> ‼️ `Wechatpay-Serial` 以 `PUB_KEY_ID_` 开头则用微信支付公钥验签，否则用平台证书验签。

## 三、报文结构

```json
{
  "id": "EV-2018022511223320873",
  "create_time": "2020-03-26T10:43:39+08:00",
  "event_type": "MEDICAL_INSURANCE.SUCCESS",
  "resource_type": "encrypt-resource",
  "resource": {
    "algorithm": "AEAD_AES_256_GCM",
    "ciphertext": "...",
    "nonce": "...",
    "associated_data": "..."
  }
}
```

## 四、resource.ciphertext 解密后的业务字段

> 算法：`AEAD_AES_256_GCM`，密钥：服务商 APIv3 密钥（32 字节）

服务商场景下相比商户场景，多出 `sub_mchid` / `sub_appid` / `sub_openid` 三个字段：

| 字段 | 类型 | 含义 |
| --- | --- | --- |
| `mix_trade_no` | string(32) | 医保自费混合订单号 |
| `mix_pay_status` | string | `MIX_PAY_SUCCESS` |
| `self_pay_status` | string | `SELF_PAY_SUCCESS` / `NO_SELF_PAY` |
| `med_ins_pay_status` | string | `MED_INS_PAY_SUCCESS` / `NO_MED_INS_PAY` |
| `paid_time` | string(64) | 支付完成时间，RFC3339 |
| `passthrough_response_content` | string(2048) | 医保局透传给医疗机构的内容 |
| `mix_pay_type` | string | `CASH_ONLY` / `INSURANCE_ONLY` / `CASH_AND_INSURANCE` |
| `order_type` | string | `REG_PAY` 等，详见 SKILL 总览 |
| `appid` | string(32) | **服务商**公众号 / 小程序 AppID |
| `sub_appid` | string(32) | **医疗机构**公众号 / 小程序 AppID |
| `sub_mchid` | string(32) | **医疗机构**商户号（路由依据） |
| `openid` | string(128) | 用户在服务商 AppID 下的 openid（与 sub_openid 二选一） |
| `sub_openid` | string(128) | 用户在医疗机构 AppID 下的 openid |
| `pay_for_relatives` | bool | 是否代亲属支付 |
| `out_trade_no` | string(64) | 商户订单号 |
| `serial_no` | string(20) | 医疗机构订单号 |
| `pay_order_id` | string(64) | 医保局支付单 ID |
| `pay_auth_no` | string(40) | 医保局支付授权码 |
| `geo_location` | string(40) | 用户经纬度 |
| `city_id` | string(8) | 城市 ID |
| `med_inst_name` | string(128) | 医疗机构名称 |
| `med_inst_no` | string(32) | 医疗机构编码 |
| `med_ins_order_create_time` | string(64) | 医保下单时间 |
| `total_fee` | uint64 | 订单总金额（分） |
| `med_ins_gov_fee` / `med_ins_self_fee` / `med_ins_other_fee` / `med_ins_cash_fee` / `wechat_pay_cash_fee` | uint64 | 各分项金额，单位分 |
| `cash_add_detail[].cash_add_fee` / `cash_add_type` | uint64 / string | 现金补充明细 |
| `cash_reduce_detail[].cash_reduce_fee` / `cash_reduce_type` | uint64 / string | 现金减免明细 |
| `callback_url` | string(256) | 回调通知 URL |
| `prepay_id` | string(64) | 自费预下单 ID |
| `attach` | string(128) | 商户自定义透传 |
| `channel_no` | string(32) | 渠道号 |
| `med_ins_test_env` | bool | 是否医保局测试环境 |

## 五、应答规范

| 场景 | HTTP 状态码 | 应答体 |
| --- | --- | --- |
| 验签通过 + 业务处理成功 | 200 / 204 | 无包体 |
| 验签失败 / 业务处理失败 | 4XX / 5XX | `{"code": "FAIL", "message": "失败"}` |

## 六、服务商必备：按 sub_mchid 路由

```text
1) 接收回调 → 验签 → 解密
2) 从解密后的 resource 中读取 sub_mchid
3) 根据 sub_mchid 查找对应的业务处理逻辑（如调用医院 HIS 回写订单）
4) 幂等处理：以 (sub_mchid, mix_trade_no) 联合主键检查
5) 返回 200/204
```

> ‼️ **禁止**仅按 `out_trade_no` / `mix_trade_no` 路由：不同子商户的 `out_trade_no` 可能重复，必须复合 `sub_mchid` 才能唯一定位订单。

## 七、与查单的关系

| 场景 | 推荐做法 |
| --- | --- |
| 30 秒内收到回调 | 验签 + 解密 + 按 (`sub_mchid`, `mix_trade_no`) 幂等 |
| 30 秒后未收到回调 | 主动调用查单接口（带 `sub_mchid`）确认 |
| 解密 / 验签失败 | 应答 4XX/5XX 触发重试，同时报警查单兜底 |
