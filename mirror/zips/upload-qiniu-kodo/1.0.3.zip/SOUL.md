# SOUL

## 功能说明
- 上传本地文件到七牛云对象存储
- 支持自定义访问有效期（秒）
- 生成私有签名 URL，过期自动失效
- 数据库只需存储文件 key，不存 base64
- 纯本地运行，无外部 API 依赖

## 配置项（安装后填写）
```json
{
  "accessKey": "",
  "secretKey": "",
  "bucket": "",
  "domain": "",
  "region": "z0",
  "defaultExpire": 3600
}
```