
---


```javascript
const qiniu = require('qiniu');
const fs = require('fs');
const path = require('path');

class QiniuUploadAutoDeleteSkill {
  constructor(config) {
    this.accessKey = config.accessKey || '';
    this.secretKey = config.secretKey || '';
    this.bucket = config.bucket || '';
    this.domain = config.domain || '';
    this.region = config.region || 'z0';
    this.defaultDeleteDays = config.defaultDeleteDays || 7; // 默认7天删

    if (!this.accessKey || !this.secretKey || !this.bucket || !this.domain) {
      throw new Error('请先配置七牛云 accessKey、secretKey、bucket、domain');
    }

    this.mac = new qiniu.auth.digest.Mac(this.accessKey, this.secretKey);
    this.cfg = new qiniu.conf.Config();
    this.cfg.zone = this.getZone(this.region);
    this.rs = new qiniu.rs.Client(this.mac, this.cfg);
  }

  getZone(region) {
    const map = {
      z0: qiniu.zone.Zone_z0,
      z1: qiniu.zone.Zone_z1,
      z2: qiniu.zone.Zone_z2,
      na0: qiniu.zone.Zone_na0,
      as0: qiniu.zone.Zone_as0,
    };
    return map[region] || qiniu.zone.Zone_z0;
  }

  generateUploadToken(key) {
    const putPolicy = new qiniu.rs.PutPolicy({
      scope: `${this.bucket}:${key}`
    });
    return putPolicy.uploadToken(this.mac);
  }

  async upload(localPath, key) {
    return new Promise((resolve, reject) => {
      const uploader = new qiniu.form_up.FormUploader(this.cfg);
      const extra = new qiniu.form_up.PutExtra();
      const token = this.generateUploadToken(key);
      uploader.putFile(token, key, localPath, extra, (err, ret) => {
        if (err) return reject(err);
        resolve(ret);
      });
    });
  }

  // 核心：设置服务端生命周期——N天后自动删除
  async setLifecycleDelete(key, deleteDays) {
    const entryURI = `${this.bucket}:${key}`;
    // deleteAfterDays 单位：天，0=取消{insert\_element\_2\_}
    await this.rs.updateLifecycle(entryURI, {
      deleteAfterDays: deleteDays
    });
  }

  // 生成永久访问链接（公开/私有）
  getUrl(key, isPrivate) {
    const base = `${this.domain}/${encodeURIComponent(key)}`;
    if (!isPrivate) return base;
    // 私有空间：生成永久签名（不过期，直到文件被删）
    const expire = Math.floor(Date.now() / 1000) + 365 * 24 * 3600 * 10; // 10年
    return qiniu.rs.getPrivateUrl(base, expire, this.mac);
  }

  async run(args) {
    const { filePath, deleteDays, isPrivate = false } = args;

    if (!filePath) throw new Error('缺少 filePath');
    if (!fs.existsSync(filePath)) throw new Error('文件不存在');

    const key = path.basename(filePath);
    const days = deleteDays || this.defaultDeleteDays;

    // 1. 上传
    const upRet = await this.upload(filePath, key);

    // 2. 设置服务端自动删除（关键）
    await this.setLifecycleDelete(key, days);

    // 3. 生成永久访问链接
    const url = this.getUrl(key, isPrivate);

    const deleteAt = Math.floor(Date.now() / 1000) + days * 24 * 3600;

    return {
      key,
      hash: upRet.hash,
      url,
      deleteAfterDays: days,
      deleteAt,
      deleteHuman: new Date(deleteAt * 1000).toLocaleString('zh-CN')
    };
  }
}

module.exports = QiniuUploadAutoDeleteSkill;