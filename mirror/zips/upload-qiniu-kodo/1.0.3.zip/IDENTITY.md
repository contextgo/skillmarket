# IDENTITY
name: qiniu-upload-with-expire
displayName: 七牛云上传 + 限时私有链接
author: user
version: 1.0.0
description: 上传文件到七牛云，生成带过期时间的私有访问URL，安全不泄露原图，适合OCR、手写图片存储。
category: 文件工具
tags: [qiniu, 七牛, 上传, 私有链接, 有效期, 图片存储]
supportedScenes: [agent, cli]