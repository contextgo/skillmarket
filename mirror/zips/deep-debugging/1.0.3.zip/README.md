# Deep Debugging Skill

**Stop guessing. Start proving.**

A structured 4-phase debugging protocol for AI agents and developers. No more random fixes — this skill forces hypothesis-driven debugging that actually finds root causes.

---

## What it does

When you hit a bug, the instinct is to start changing things and see what sticks. This skill breaks that habit. It forces you to collect evidence first, form a single testable hypothesis, isolate the root cause with binary search — and only then write a fix.

The result: bugs get solved once, not repeatedly.

---

## When it triggers

The skill activates automatically when your message contains any of these phrases:

```
debug / bug / broken / kaputt / fehler / error / crash / absturz
"funktioniert nicht" / "schlägt fehl" / "wirft error" / "wirft exception"
401 / 403 / 500 (as standalone HTTP codes)
```

It does **not** fire on vague phrases like "why does X work" or general questions — only on clear error signals.

---

## 4-Phase Workflow

| Phase | Name | What happens |
|---|---|---|
| Pre | Quick Triage | 30-second checklist: server restarted? ENV set? migration ran? cache cleared? |
| 1 | Data Collection | Gather exact error message, when it happens, who is affected, what last changed |
| 2 | Hypothesis | Formulate ONE concrete, testable hypothesis before touching anything |
| 3 | Binary Search | Isolate root cause by halving the problem space using the right checkliste |
| 4 | Fix | Minimal fix only after root cause is proven — then verify and report |

---

## Hypothese → Checkliste Selector

In Phase 3, the right checklist is chosen based on the hypothesis:

- **Auth / Token / Session** → JWT flow, step by step (login → token → header → guard → secret)
- **API / Request / CORS** → Request chain from middleware to DB response
- **UI / State / Hooks** → React event → state → re-render → API → UI update
- **DB / Schema / Query** → Schema sync, null-safety, transactions, connection pool
- **Performance** → N+1 queries, missing indexes, re-renders, memory leaks

---

## Quick Demo

**User writes:** "API gibt 401 zurück, hab JWT implementiert"

**Skill does:**
1. Pre-Phase: "Server neu gestartet? ENV gesetzt?" — checkt Basics in 30 Sekunden
2. Phase 1: Fragt nach exakter Fehlermeldung, betroffenem Endpoint, letztem Commit
3. Phase 2: Formuliert Hypothese — z.B. "JWT_SECRET in JwtModule und JwtStrategy stimmen nicht überein"
4. Phase 3 (Auth-Checkliste): Schritt für Schritt — Login-Response prüfen → Set-Cookie / Bearer Header → Guard-Log → Secret-Vergleich
5. Phase 4: Minimaler Fix an genau der Stelle die Schritt 5 als Ursache bewiesen hat
6. DEBUG REPORT: Ursache, Beweis, Fix, Verifikation — in strukturiertem Format

---

## Eskalation bei 3 Fehlversuchen

Wenn nach 3 Fixes der Bug noch existiert, geht der Skill **nicht** blind zurück zu Phase 1. Stattdessen:

1. Status-Bericht mit allen getesteten Hypothesen und Ergebnissen
2. User aktiv fragen: "Welche offene Hypothese soll ich tiefer verfolgen?"
3. Optional: frischen Subagent mit minimalem Kontext spawnen (verhindert Confirmation Bias durch kontaminierten Reasoning-Path)

---

## Installation

Kopiere den Skill-Ordner nach:

```
~/.claude/skills/deep-debugging/
```

Enthaltene Dateien:
- `SKILL.md` — Vollständiges Protokoll (wird von Claude automatisch geladen)
- `README.md` — Diese Datei
- `package.json` — Skill-Metadaten
- `_meta.json` — Marketplace-Metadaten

---

## Wann NICHT nutzen

Dieser Skill ist für echte Bugs mit unklarer Ursache. Ihn **nicht** aktivieren bei:

- **Tippfehlern** — Variablenname falsch geschrieben, fehlende Klammer
- **Fehlenden npm-Packages** — `npm install` noch nicht ausgeführt
- **Fehlenden ENV-Variablen** — `.env` nicht angelegt oder nicht geladen
- **Einfachen 404-Fehlern** — Route nicht registriert, Schreibfehler im Pfad
- **Offensichtlichen Syntax-Fehlern** — TypeScript/ESLint zeigt die Zeile direkt an

Für diese Fälle reicht direktes Hinschauen — kein Protokoll nötig.

---

## Includes

- Auth/JWT debugging flow (NestJS, Schritt 1–5)
- React/Next.js debugging (Hydration, useEffect, Hooks, SSR)
- Prisma/DB debugging (schema sync, N+1, connection pool, transactions)
- Performance debugging (re-renders, memory leaks, bundle size, missing index)
- Common error quick-reference table (20+ symptoms → root causes)
- Debug tools, curl snippets, git bisect
- 6 real-world Lessons Learned from production bugs
- Mandatory DEBUG REPORT format
- Eskalations-Pfad nach 3 Fehlversuchen

## Stack

Optimized for NestJS + Next.js + Prisma, but the methodology works with any stack.

---

> "Don't debug with your gut. Debug with evidence."
