#!/usr/bin/env python3
"""
客户攻坚计划书自动生成脚本 v2.1.0
根据客户公司名称，自动生成包含8个章节的完整攻坚计划书（HTML格式）

修复内容：
- 修复 f-string 与 CSS 花括号冲突问题（使用 .replace() 方法）
- 增加 8 章节结构（封面、目录、客户概况、决策链条分析、业务架构分析、产品推荐、竞品对比、商务策略、销售话术、行动计划）
- 应用配色方案（#006EFF、#52C41A、#FF4D4F、#FAAD14、#E8492D）
- 支持嵌入架构图（SVG/Base64 PNG）
- 添加打印样式（@media print），支持打印为 PDF
"""

import sys
import json
from datetime import datetime

def generate_html(customer_name, partner_name="", sales_name="", architect_name="", support_team=""):
    """
    生成客户攻坚计划书 HTML 文件
    
    Args:
        customer_name: 客户公司名称
        partner_name: 伙伴名称（可选）
        sales_name: 销售名称（可选）
        architect_name: 架构师名称（可选）
        support_team: 支持团队（可选）
    
    Returns:
        output_path: 生成的 HTML 文件路径
    """
    
    # 配色方案（来自 v2.0.0 定义）
    colors = {
        "primary": "#006EFF",      # 腾讯蓝
        "champion": "#52C41A",     # Champion（支持者）- 绿色
        "blocker": "#FF4D4F",      # Blocker（阻碍者）- 红色
        "neutral": "#FAAD14",       # 中立 - 黄色
        "decision": "#006EFF",      # 最终决策者 - 蓝色
        "accent": "#E8492D"        # 强调色 - 橙红
    }
    
    # HTML 模板（使用占位符，避免 f-string 与 CSS 花括号冲突）
    html_template = """<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>{{CUSTOMER_NAME}}-客户攻坚计划书</title>
    <style>
        /* 配色方案 */
        :root {
            --primary: {{COLOR_PRIMARY}};
            --champion: {{COLOR_CHAMPION}};
            --blocker: {{COLOR_BLOCKER}};
            --neutral: {{COLOR_NEUTRAL}};
            --decision: {{COLOR_DECISION}};
            --accent: {{COLOR_ACCENT}};
        }
        
        /* 基础样式 */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Microsoft YaHei', '微软雅黑', Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            background: #f5f5f5;
        }
        
        /* 封面 */
        .cover {
            background: linear-gradient(135deg, var(--primary) 0%, #0046A3 100%);
            color: white;
            padding: 60px 40px;
            text-align: center;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        
        .cover h1 {
            font-size: 48px;
            margin-bottom: 30px;
            font-weight: bold;
        }
        
        .cover h2 {
            font-size: 32px;
            margin-bottom: 20px;
            font-weight: normal;
        }
        
        .cover p {
            font-size: 18px;
            margin: 10px 0;
        }
        
        /* 目录 */
        .table-of-contents {
            padding: 40px;
            background: white;
            margin: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .table-of-contents h2 {
            color: var(--primary);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        
        .table-of-contents ol {
            list-style: none;
            padding-left: 0;
        }
        
        .table-of-contents li {
            padding: 12px 20px;
            margin: 8px 0;
            background: #f9f9f9;
            border-left: 4px solid var(--primary);
            font-size: 16px;
        }
        
        /* 章节 */
        .chapter {
            padding: 40px;
            background: white;
            margin: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .chapter h2 {
            color: var(--primary);
            border-bottom: 2px solid var(--primary);
            padding-bottom: 10px;
            margin-bottom: 30px;
            font-size: 28px;
        }
        
        /* 客户概况网格 */
        .profile-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .profile-item {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid var(--primary);
        }
        
        .profile-item h3 {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        /* 决策链条分析 */
        .org-chart {
            margin: 20px 0;
            text-align: center;
        }
        
        .org-chart img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        
        .attack-strategy {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .attack-strategy th {
            background: var(--primary);
            color: white;
            padding: 12px;
            text-align: left;
        }
        
        .attack-strategy td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        
        .role-champion {
            color: var(--champion);
            font-weight: bold;
        }
        
        .role-blocker {
            color: var(--blocker);
            font-weight: bold;
        }
        
        .role-neutral {
            color: var(--neutral);
            font-weight: bold;
        }
        
        .role-decision {
            color: var(--decision);
            font-weight: bold;
        }
        
        /* 业务架构分析 */
        .business-arch {
            margin: 20px 0;
            text-align: center;
        }
        
        .business-arch img {
            max-width: 100%;
            height: auto;
            border: 1px solid #ddd;
            border-radius: 8px;
        }
        
        /* 产品卡片 */
        .product-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        
        .product-card {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            border-left: 4px solid var(--accent);
        }
        
        .product-card h3 {
            color: var(--accent);
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        .product-card .match-reason {
            background: white;
            padding: 10px;
            border-radius: 4px;
            margin-top: 10px;
            font-size: 14px;
            line-height: 1.8;
        }
        
        /* 竞品对比 */
        .competitor-comparison {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .competitor-comparison th {
            background: var(--primary);
            color: white;
            padding: 12px;
            text-align: left;
        }
        
        .competitor-comparison td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        
        /* 商务策略 */
        .strategy-section {
            margin-top: 20px;
        }
        
        .strategy-item {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid var(--primary);
        }
        
        .strategy-item h3 {
            color: var(--primary);
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        /* 销售话术 */
        .sales-scripts {
            margin-top: 20px;
        }
        
        .script-item {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid var(--champion);
        }
        
        .script-item h3 {
            color: var(--champion);
            margin-bottom: 10px;
            font-size: 18px;
        }
        
        .script-content {
            background: white;
            padding: 15px;
            border-radius: 4px;
            margin-top: 10px;
            font-size: 14px;
            line-height: 1.8;
        }
        
        /* 行动计划 */
        .action-plan {
            margin-top: 20px;
        }
        
        .kpi-items {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .kpi-item {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 8px;
            text-align: center;
            border-left: 4px solid var(--accent);
        }
        
        .action-list {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }
        
        .action-list ol {
            padding-left: 20px;
        }
        
        .action-list li {
            padding: 8px 0;
            font-size: 15px;
        }
        
        /* 打印样式 */
        @media print {
            body {
                background: white;
            }
            
            .cover {
                min-height: auto;
                page-break-after: always;
            }
            
            .chapter {
                page-break-inside: avoid;
                box-shadow: none;
                border: 1px solid #ddd;
            }
            
            .table-of-contents {
                page-break-after: always;
            }
        }
    </style>
</head>
<body>
    <!-- 封面 -->
    <div class="cover">
        <h1>客户攻坚计划书</h1>
        <h2>【客户名称：{{CUSTOMER_NAME}}】</h2>
        {{PARTNER_LINE}}
        <p>【销售：{{SALES_NAME}} &nbsp;&nbsp; 架构师：{{ARCHITECT_NAME}}】</p>
        <p>生成时间：{{GENERATE_TIME}}</p>
    </div>
    
    <!-- 目录 -->
    <div class="table-of-contents">
        <h2>目录</h2>
        <ol>
            <li>客户概况</li>
            <li>决策链条分析</li>
            <li>业务架构分析</li>
            <li>腾讯云产品方案推荐</li>
            <li>竞品对比分析</li>
            <li>商务策略建议</li>
            <li>销售话术参考</li>
            <li>总结与行动计划</li>
        </ol>
    </div>
    
    <!-- 第一章：客户概况 -->
    <div class="chapter">
        <h2>一、客户概况</h2>
        <div class="profile-grid">
            <div class="profile-item">
                <h3>基本信息</h3>
                <p><strong>公司名称：</strong>{{CUSTOMER_NAME}}</p>
                <p><strong>所属行业：</strong>[待填充]</p>
                <p><strong>业务规模：</strong>[待填充]</p>
                <p><strong>IT投入：</strong>[待填充]</p>
            </div>
            <div class="profile-item">
                <h3>战略方向</h3>
                <p>[待填充：从财报/官网/新闻中提取]</p>
            </div>
            <div class="profile-item">
                <h3>决策链条</h3>
                <p>[待填充：关键决策人及态度]</p>
            </div>
        </div>
    </div>
    
    <!-- 第二章：决策链条分析 -->
    <div class="chapter">
        <h2>二、决策链条分析</h2>
        <div class="org-chart">
            <p>[待嵌入组织架构图 SVG/PNG]</p>
        </div>
        <table class="attack-strategy">
            <tr>
                <th>姓名</th>
                <th>职位</th>
                <th>角色</th>
                <th>攻坚策略</th>
            </tr>
            <tr>
                <td>[姓名]</td>
                <td>[职位]</td>
                <td class="role-champion">Champion（支持者）</td>
                <td>[策略]</td>
            </tr>
            <tr>
                <td>[姓名]</td>
                <td>[职位]</td>
                <td class="role-blocker">Blocker（阻碍者）</td>
                <td>[策略]</td>
            </tr>
        </table>
    </div>
    
    <!-- 第三章：业务架构分析 -->
    <div class="chapter">
        <h2>三、业务架构分析</h2>
        <div class="business-arch">
            <p>[待嵌入业务架构图 SVG/PNG]</p>
        </div>
        <div class="profile-item">
            <h3>业务架构四层解读</h3>
            <p>[待填充：接入层/应用层/数据层/基础设施层的解读]</p>
        </div>
        <div class="profile-item">
            <h3>机会点识别</h3>
            <p>[待填充：从架构图中识别的腾讯云切入机会]</p>
        </div>
    </div>
    
    <!-- 第四章：腾讯云产品方案推荐 -->
    <div class="chapter">
        <h2>四、腾讯云产品方案推荐</h2>
        <div class="product-cards">
            <div class="product-card">
                <h3>🔥 核心推荐：[产品名称]</h3>
                <p><strong>匹配业务：</strong>[业务场景]</p>
                <p><strong>推荐理由：</strong>[理由]</p>
                <p><strong>预估规模：</strong>[金额]</p>
                <div class="match-reason">
                    <p><strong>竞品对标：</strong>[阿里云/AWS 产品对比]</p>
                    <p><strong>切入话术：</strong>[话术]</p>
                </div>
            </div>
            <div class="product-card">
                <h3>⭐ 扩展推荐：[产品名称]</h3>
                <p><strong>匹配场景：</strong>[场景]</p>
                <p><strong>预估价值：</strong>[价值]</p>
                <p><strong>优先级：</strong>P1/P2/P3</p>
            </div>
        </div>
    </div>
    
    <!-- 第五章：竞品对比分析 -->
    <div class="chapter">
        <h2>五、竞品对比分析</h2>
        <table class="competitor-comparison">
            <tr>
                <th>对比维度</th>
                <th>腾讯云</th>
                <th>阿里云</th>
                <th>华为云</th>
            </tr>
            <tr>
                <td>产品丰富度</td>
                <td>⭐⭐⭐⭐⭐</td>
                <td>⭐⭐⭐⭐</td>
                <td>⭐⭐⭐</td>
            </tr>
            <tr>
                <td>价格优势</td>
                <td>⭐⭐⭐⭐</td>
                <td>⭐⭐⭐</td>
                <td>⭐⭐⭐⭐</td>
            </tr>
            <tr>
                <td>服务支持</td>
                <td>⭐⭐⭐⭐⭐</td>
                <td>⭐⭐⭐</td>
                <td>⭐⭐⭐</td>
            </tr>
        </table>
        <div class="strategy-item">
            <h3>SWOT 分析</h3>
            <p><strong>优势（Strengths）：</strong>[待填充]</p>
            <p><strong>劣势（Weaknesses）：</strong>[待填充]</p>
            <p><strong>机会（Opportunities）：</strong>[待填充]</p>
            <p><strong>威胁（Threats）：</strong>[待填充]</p>
        </div>
    </div>
    
    <!-- 第六章：商务策略建议 -->
    <div class="chapter">
        <h2>六、商务策略建议</h2>
        <div class="strategy-section">
            <div class="strategy-item">
                <h3>年消耗预估</h3>
                <p>[待填充：核心产品 + 扩展产品的总预估消耗]</p>
            </div>
            <div class="strategy-item">
                <h3>切入策略</h3>
                <p>[待填充：如何切入客户，第一次接触的时机和方式]</p>
            </div>
            <div class="strategy-item">
                <h3>扩张策略</h3>
                <p>[待填充：从核心产品扩展到更多产品的路径]</p>
            </div>
            <div class="strategy-item">
                <h3>风险应对策略</h3>
                <p>[待填充：识别风险点和应对措施]</p>
            </div>
            <div class="strategy-item">
                <h3>时间表</h3>
                <p>[待填充：关键里程碑和时间节点]</p>
            </div>
        </div>
    </div>
    
    <!-- 第七章：销售话术参考 -->
    <div class="chapter">
        <h2>七、销售话术参考</h2>
        <div class="sales-scripts">
            <div class="script-item">
                <h3>针对 Champion 的话术</h3>
                <div class="script-content">
                    <p><strong>开场：</strong>[话术]</p>
                    <p><strong>痛点切入：</strong>[话术]</p>
                    <p><strong>产品推荐：</strong>[话术]</p>
                    <p><strong>异议处理：</strong>[话术]</p>
                </div>
            </div>
            <div class="script-item">
                <h3>针对 Blocker 的话术</h3>
                <div class="script-content">
                    <p><strong>开场：</strong>[话术]</p>
                    <p><strong>痛点切入：</strong>[话术]</p>
                    <p><strong>异议处理：</strong>[话术]</p>
                </div>
            </div>
            <div class="script-item">
                <h3>针对最终决策者的话术</h3>
                <div class="script-content">
                    <p><strong>价值主张：</strong>[话术]</p>
                    <p><strong>ROI 分析：</strong>[话术]</p>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 第八章：总结与行动计划 -->
    <div class="chapter">
        <h2>八、总结与行动计划</h2>
        <div class="action-plan">
            <h3>KPI 指标</h3>
            <div class="kpi-items">
                <div class="kpi-item">
                    <h4>年消耗目标</h4>
                    <p>[金额]</p>
                </div>
                <div class="kpi-item">
                    <h4>产品覆盖</h4>
                    <p>[数量] 个产品</p>
                </div>
                <div class="kpi-item">
                    <h4>决策链突破</h4>
                    <p>[数量] 个关键人</p>
                </div>
            </div>
            
            <h3>行动清单</h3>
            <div class="action-list">
                <ol>
                    <li>[行动 1：具体任务 + 负责人 + 截止时间]</li>
                    <li>[行动 2：具体任务 + 负责人 + 截止时间]</li>
                    <li>[行动 3：具体任务 + 负责人 + 截止时间]</li>
                </ol>
            </div>
            
            <h3>风险提示</h3>
            <div class="strategy-item">
                <p>[待填充：主要风险和应对方案]</p>
            </div>
        </div>
    </div>
</body>
</html>"""
    
    # 替换占位符
    html_content = html_template
    html_content = html_content.replace("{{CUSTOMER_NAME}}", customer_name)
    html_content = html_content.replace("{{COLOR_PRIMARY}}", colors["primary"])
    html_content = html_content.replace("{{COLOR_CHAMPION}}", colors["champion"])
    html_content = html_content.replace("{{COLOR_BLOCKER}}", colors["blocker"])
    html_content = html_content.replace("{{COLOR_NEUTRAL}}", colors["neutral"])
    html_content = html_content.replace("{{COLOR_DECISION}}", colors["decision"])
    html_content = html_content.replace("{{COLOR_ACCENT}}", colors["accent"])
    
    # 伙伴名称行（可选）
    partner_line = f"<p>【伙伴名称：{partner_name}】</p>" if partner_name else ""
    html_content = html_content.replace("{{PARTNER_LINE}}", partner_line)
    
    # 销售和架构师名称
    html_content = html_content.replace("{{SALES_NAME}}", sales_name if sales_name else "[待填写]")
    html_content = html_content.replace("{{ARCHITECT_NAME}}", architect_name if architect_name else "[待填写]")
    
    # 生成时间
    generate_time = datetime.now().strftime('%Y年%m月%d日')
    html_content = html_content.replace("{{GENERATE_TIME}}", generate_time)
    
    # 保存 HTML 文件
    output_path = f'/Users/super/WorkBuddy/腾讯云渠道销售专家/{customer_name}-客户攻坚计划书.html'
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html_content)
    
    print(f'✅ 已生成 "{customer_name}" 的客户攻坚计划书')
    print(f'📄 文档路径：{output_path}')
    return output_path

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python3 generate_attack_plan.py <customer_name> [partner_name] [sales_name] [architect_name] [support_team]')
        sys.exit(1)
    
    customer_name = sys.argv[1]
    partner_name = sys.argv[2] if len(sys.argv) > 2 else ""
    sales_name = sys.argv[3] if len(sys.argv) > 3 else ""
    architect_name = sys.argv[4] if len(sys.argv) > 4 else ""
    support_team = sys.argv[5] if len(sys.argv) > 5 else ""
    
    generate_html(customer_name, partner_name, sales_name, architect_name, support_team)
