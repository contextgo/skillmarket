---
name: customer-attack-plan
description: "客户攻坚计划书自动生成工具。根据客户公司名称，自动生成包含8个章节的完整攻坚计划书（HTML格式）。触发词：客户攻坚计划书、攻坚计划、客户分析报告、生成攻坚计划、客户画像分析。当用户提供客户公司名称，要求生成客户分析文档时，使用此技能。集成tencent-cloud-customer-portrait、customer-opportunity-analyzer、fireworks-tech-graph等技能，自动完成客户概况、决策链条分析、业务架构分析、腾讯云产品方案推荐、竞品对比、商务策略、销售话术、行动计划的所有内容生成。重要：本技能生成HTML格式文档（非Word），支持精美排版、打印为PDF、嵌入式图表。"
---

# 客户攻坚计划书生成技能 v2.0.0

## 概述

本技能根据**客户公司名称**，自动生成完整的"客户攻坚计划书"（HTML文档），包含8个核心章节：

1. **客户概况** - 公司基本信息、业务规模、IT投入、战略方向
2. **决策链条分析** - 组织架构图、关键决策人、角色态度、攻坚策略
3. **业务架构分析** - 业务架构图、四层解读、机会点识别
4. **腾讯云产品方案推荐** - 核心产品、扩展产品、安全合规产品
5. **竞品对比分析** - 腾讯云 vs 阿里云/华为云、SWOT分析
6. **商务策略建议** - 年消耗预估、切入/扩张/风险策略、时间表
7. **销售话术参考** - 针对每个决策人角色的话术模板
8. **总结与行动计划** - KPI指标、行动清单、风险提示

---

## 使用场景

**触发条件**（满足任一即可）：
- 用户提供客户公司名称，要求"生成攻坚计划书"
- 用户提到"客户攻坚"、"客户分析报告"、"客户画像"
- 用户需要快速准备客户拜访材料
- 用户需要系统化的客户分析文档

**输入要求**：
- **必需**：客户公司全称（用于联网搜索和信息收集）
- **可选**：伙伴名称、销售名称、架构师名称、支持团队

---

## 工作流程

### 第一步：信息收集与真实数据获取

**1.1 调用 `tencent-cloud-customer-portrait` 技能**

```
请使用 tencent-cloud-customer-portrait 技能，分析 [客户公司名称]：
1. 行业深度分析（市场规模、竞争格局、政策环境）
2. CEO级业务痛点提炼
3. 客户画像两步法（SWOT分析 + 决策链条映射）
```

**输出**：
- 客户概况的完整内容
- 决策链分析结果（Champion/Blocker识别）
- 关键人员列表

**1.2 真实数据获取（重要！）**

⚠️ **必须使用真实数据，禁止虚构！**

**方法1：DNS解析分析（云服务商识别）**
```bash
# 查询官网域名解析
nslookup [客户官网域名]
dig [客户官网域名]

# 查询API/图片等子域名
nslookup api.[客户域名]
nslookup img.[客户域名]
```

**判断规则**：
- `eo.dnse1.com` → 腾讯云EdgeOne CDN
- `qiniudns.com` → 七牛云
- `alidns.com` → 阿里云DNS
- `huaweicloud.com` → 华为云

**方法2：官网IP归属查询**
```bash
# 查询IP地址
ping [客户官网域名]
whois [IP地址]
```

**方法3：搜索真实高管信息**
```
使用 WebSearch 搜索：
- "[客户公司] CTO"
- "[客户公司] CFO"
- "[客户公司] 技术负责人"
- site:liepin.com "[客户公司]"
- site:linkedin.com "[客户公司]"
```

**方法4：竞品介入情况确认**
```
使用 WebSearch 搜索：
- "[客户公司] 阿里云"
- "[客户公司] 华为云"
- "[客户公司] 上云"
- "[客户公司] 数字化转型"
```

**1.3 调用 `customer-opportunity-analyzer` 技能**

```
请使用 customer-opportunity-analyzer 技能，分析 [客户公司名称]：
1. 业务场景分析
2. 腾讯云产品匹配建议
3. 技术架构分析
```

**输出**：
- 业务架构说明
- 技术痛点分析
- 产品推荐清单

---

### 第二步：生成架构图（可选）

**2.1 决策链条图（组织架构图）**

使用 `fireworks-tech-graph` 技能生成：

```
请使用 fireworks-tech-graph 技能，生成决策链条图：
- 类型：组织架构图
- 内容：[从第一步获得的决策链分析结果]
- 格式：SVG或PNG
- 样式：标注Champion（绿色 #52C41A）/Blocker（红色 #FF4D4F）
```

**2.2 业务架构图**

```
请使用 fireworks-tech-graph 技能，生成业务架构图：
- 类型：业务流程图
- 内容：[从第一步获得的业务场景分析]
- 格式：SVG或PNG
- 样式：模块化，标注机会点（橙色高亮）
```

**重要**：
- 图片可保存为Base64嵌入HTML，或保存为外部文件
- 记录图片路径，供第三步插入HTML文档

---

### 第三步：核算腾讯云产品报价

⚠️ **必须使用官方计费规则，禁止虚构价格！**

**常见产品计费规则**：

| 产品 | 计费规则 | 注意事项 |
|------|----------|----------|
| 企业微信 | 按员工席位计费 | 约300元/人/年，非用户数！ |
| CVM云服务器 | 按实例规格+时长 | 包年有折扣 |
| COS对象存储 | 按存储量+流量 | 有免费额度 |
| CDN加速 | 按流量 | 有阶梯计价 |
| 数据库 | 按实例规格+存储 | 高可用版更贵 |

**报价计算方法**：
```
使用 WebFetch 访问腾讯云官网计算器：
- https://buy.cloud.tencent.com/price
- 根据实际需求选择配置
- 获取准确报价
```

**输出格式**：
```
核心产品推荐：
1. 企业微信
   - 配置：500席位
   - 单价：300元/人/年
   - 年费：15万元/年
   - 说明：按员工席位计费，非用户数
```

---

### 第四步：生成HTML文档

**4.1 HTML文档结构**（严格按照8章节）

```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>[客户公司]-客户攻坚计划书</title>
    <style>
        /* 使用内嵌CSS，确保样式一致性 */
    </style>
</head>
<body>
    <!-- 封面 -->
    <div class="cover">
        <h1>客户攻坚计划书</h1>
        <h2>【客户名称：[客户公司]】</h2>
        <p>【伙伴名称：XXX】</p>
        <p>【销售：XXX &nbsp;&nbsp; 架构师：XXX】</p>
    </div>
    
    <!-- 目录 -->
    <div class="table-of-contents">
        <h2>目录</h2>
        <ol>
            <li>客户概况</li>
            <li>决策链条分析</li>
            <li>业务架构分析</li>
            <li>腾讯云产品方案推荐</li>
            <li>竞品对比分析</li>
            <li>商务策略建议</li>
            <li>销售话术参考</li>
            <li>总结与行动计划</li>
        </ol>
    </div>
    
    <!-- 第一章：客户概况 -->
    <div class="chapter">
        <h2>一、客户概况</h2>
        <div class="profile-grid">
            <!-- 使用网格布局展示客户信息 -->
        </div>
    </div>
    
    <!-- 第二章：决策链条分析 -->
    <div class="chapter">
        <h2>二、决策链条分析</h2>
        <div class="org-chart">
            <!-- 嵌入组织架构图 -->
        </div>
        <table class="attack-strategy">
            <!-- 攻坚策略表 -->
        </table>
    </div>
    
    <!-- 第三章：业务架构分析 -->
    <div class="chapter">
        <h2>三、业务架构分析</h2>
        <div class="business-arch">
            <!-- 嵌入业务架构图 -->
        </div>
    </div>
    
    <!-- 第四章：腾讯云产品方案推荐 -->
    <div class="chapter">
        <h2>四、腾讯云产品方案推荐</h2>
        <div class="product-cards">
            <!-- 产品卡片：核心产品、扩展产品、安全合规 -->
        </div>
    </div>
    
    <!-- 第五章：竞品对比分析 -->
    <div class="chapter">
        <h2>五、竞品对比分析</h2>
        <table class="competitor-comparison">
            <!-- 竞品对比表 -->
        </table>
    </div>
    
    <!-- 第六章：商务策略建议 -->
    <div class="chapter">
        <h2>六、商务策略建议</h2>
        <div class="strategy-section">
            <!-- 年消耗预估、切入策略、扩张策略、风险应对策略、时间表 -->
        </div>
    </div>
    
    <!-- 第七章：销售话术参考 -->
    <div class="chapter">
        <h2>七、销售话术参考</h2>
        <div class="sales-scripts">
            <!-- 针对每个决策人角色的话术 -->
        </div>
    </div>
    
    <!-- 第八章：总结与行动计划 -->
    <div class="chapter">
        <h2>八、总结与行动计划</h2>
        <div class="action-plan">
            <!-- KPI指标、行动清单、风险提示 -->
        </div>
    </div>
</body>
</html>
```

**4.2 配色方案**（重要！）

| 用途 | 颜色代码 | 说明 |
|------|----------|------|
| 主色调 | #006EFF | 腾讯蓝 |
| Champion（支持者） | #52C41A | 绿色 |
| Blocker（阻碍者） | #FF4D4F | 红色 |
| 中立 | #FAAD14 | 黄色 |
| 最终决策者 | #006EFF | 蓝色 |
| 强调色 | #E8492D | 橙红 |

**4.3 产品推荐卡片模板**

```html
<div class="product-card">
    <div class="card-header">
        <span class="card-number">①</span>
        <h3>产品名称</h3>
    </div>
    <div class="card-body">
        <div class="detail-item">
            <span class="detail-label">配置：</span>
            <span class="detail-value">配置详情</span>
        </div>
        <div class="detail-item">
            <span class="detail-label">单价：</span>
            <span class="detail-value">单价信息</span>
        </div>
        <div class="detail-item">
            <span class="detail-label">年费：</span>
            <span class="detail-value"><strong>年费金额</strong></span>
        </div>
    </div>
    <div class="card-footer">
        <p><strong>价值主张：</strong>价值描述</p>
    </div>
</div>
```

**4.4 TCO汇总表模板**

```html
<table class="tco-summary">
    <thead>
        <tr>
            <th>产品</th>
            <th>月费（万元）</th>
            <th>年费（万元）</th>
            <th>备注</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>产品1</td>
            <td>1.25</td>
            <td>15</td>
            <td>备注信息</td>
        </tr>
        <tr class="total-row">
            <td><strong>合计</strong></td>
            <td><strong>63.5</strong></td>
            <td><strong>761</strong></td>
            <td>总价</td>
        </tr>
    </tbody>
</table>
```

---

### 第五步：增加WorkBuddy和ClawPro推荐（可选）

**5.1 WorkBuddy企业AI工作助手**

```html
<div class="product-card">
    <div class="card-header">
        <span class="card-number">⑥</span>
        <h3>WorkBuddy企业AI工作助手</h3>
    </div>
    <div class="card-body">
        <div class="detail-item">
            <span class="detail-label">配置：</span>
            <span class="detail-value">500席位</span>
        </div>
        <div class="detail-item">
            <span class="detail-label">单价：</span>
            <span class="detail-value">78元/月/席（企业旗舰版）</span>
        </div>
        <div class="detail-item">
            <span class="detail-label">年费：</span>
            <span class="detail-value"><strong>46.8万元/年</strong></span>
        </div>
    </div>
    <div class="card-footer">
        <p><strong>价值主张：</strong>提升全员生产力，AI编程、AI写方案、AI分析数据</p>
        <p><strong>包含：</strong>CodeBuddy双产品 + 2000 Credits/月/人</p>
    </div>
</div>
```

**5.2 ClawPro专业版AI工具**

```html
<div class="product-card">
    <div class="card-header">
        <span class="card-number">⑦</span>
        <h3>ClawPro专业版AI工具</h3>
    </div>
    <div class="card-body">
        <div class="detail-item">
            <span class="detail-label">配置：</span>
            <span class="detail-value">500席位</span>
        </div>
        <div class="detail-item">
            <span class="detail-label">单价：</span>
            <span class="detail-value">128元/月/席（专业版）</span>
        </div>
        <div class="detail-item">
            <span class="detail-label">年费：</span>
            <span class="detail-value"><strong>76.8万元/年</strong></span>
        </div>
    </div>
    <div class="card-footer">
        <p><strong>价值主张：</strong>最强大AI助手，支持Claude、GPT、Gemini全模型</p>
        <p><strong>包含：</strong>无限Token预算 + 50G知识库 + 自定义Skill</p>
    </div>
</div>
```

---

## 输出文件

完成后的输出文件：

```
/Users/super/WorkBuddy/腾讯云渠道销售专家/
└─ [客户公司]-客户攻坚计划书.html     (主文档，精美排版)
```

**HTML文档优势**：
1. **排版精美** - 支持CSS样式、响应式布局
2. **易于分享** - 可邮件发送、微信分享
3. **可打印为PDF** - 浏览器"打印"功能即可
4. **嵌入多媒体** - 支持嵌入图片、视频、链接
5. **交互性强** - 可添加折叠、选项卡等交互元素

---

## 使用示例

### 示例1：基本使用

**用户输入**：
```
请为"广州伊的家网络科技有限公司"生成客户攻坚计划书
```

**执行流程**：
1. 调用 `tencent-cloud-customer-portrait` 分析"广州伊的家网络科技有限公司"
2. 使用DNS解析获取真实云服务商信息
3. 搜索真实高管信息（CTO、CFO等）
4. 调用 `customer-opportunity-analyzer` 分析业务机会
5. 核算腾讯云产品报价（使用官方计算器）
6. 生成HTML文档（8章节，精美排版）

**输出**：
```
✅ 已生成"广州伊的家网络科技有限公司"的客户攻坚计划书
📄 文档路径：/Users/super/WorkBuddy/腾讯云渠道销售专家/广州伊的家-客户攻坚计划书.html
🎨 文档格式：HTML（可打印为PDF）
📊 包含内容：8个章节，真实数据，精美排版
```

---

### 示例2：带可选参数

**用户输入**：
```
请为"阿里巴巴集团"生成攻坚计划书：
- 伙伴名称：XX合作伙伴
- 销售：张三
- 架构师：李四
- 支持团队：售前支持组
```

**输出**：文档头部信息自动填充

---

## 技能依赖

本技能需要以下技能配合：

| 技能名称 | 用途 | 是否必需 |
|---------|------|----------|
| `tencent-cloud-customer-portrait` | 客户画像分析、决策链分析 | ✅ 必需 |
| `customer-opportunity-analyzer` | 业务机会分析、产品匹配 | ✅ 必需 |
| `fireworks-tech-graph` | 生成架构图（SVG/PNG格式） | ❌ 可选 |
| `websearch` | 搜索真实高管信息、竞品信息 | ✅ 必需 |
| `webfetch` | 获取腾讯云官方报价 | ✅ 必需 |

**依赖检查**：
- 如果缺少某个技能，提示用户先安装
- 技能安装命令：`/skills install [技能名称]`

---

## 注意事项

### 数据准确性（最高优先级！）

⚠️ **所有数据必须来自真实来源，禁止虚构！**

**必须执行的验证步骤**：
1. **员工人数** - 通过企查查/天眼查获取工商注册人数，结合实际运营规模估算
2. **高管信息** - 通过新闻稿、LinkedIn、猎聘搜索真实姓名
3. **云服务商** - 通过DNS解析、IP归属查询真实数据
4. **竞品介入** - 通过新闻搜索、招标公告获取真实信息
5. **产品报价** - 使用腾讯云官网计算器获取准确报价

**禁止使用的方法**：
- ❌ 虚构员工人数
- ❌ 虚构高管姓名
- ❌ 虚构云服务商
- ❌ 虚构竞品介入情况
- ❌ 虚构产品报价

**正确的做法**：
- ✅ 标注"待确认"或"未公开"
- ✅ 提供估算范围（如：1500-3800人）
- ✅ 说明数据来源（如：企查查2024年数据）
- ✅ 建议线下接触获取真实信息

### 时效性

- 市场环境和政策变化快，建议定期更新分析
- 客户公司信息动态变化，建议每次使用前重新生成
- DNS解析结果可能变化，建议生成前重新查询

### 保密性

- 所有分析内容严格保密，仅用于销售准备
- 不要将客户信息上传到公共平台
- HTML文档可能包含敏感信息，注意文件权限控制

---

## 故障排查

### 问题1：技能调用失败

**现象**：无法调用 `tencent-cloud-customer-portrait` 等技能

**解决**：
1. 检查技能是否已安装：`/skills list`
2. 如果未安装，先安装缺失的技能
3. 如果已安装但仍失败，检查技能是否启用

### 问题2：DNS解析失败

**现象**：无法获取客户云服务商信息

**解决**：
1. 检查域名是否正确
2. 尝试使用不同DNS服务器（8.8.8.8、114.114.114.114）
3. 使用在线DNS查询工具（如：https://toolbox.googleapps.com/apps/dig/）
4. 标注"云服务商待确认"

### 问题3：高管信息搜索失败

**现象**：无法找到客户CTO/CFO真实姓名

**解决**：
1. 搜索客户公司新闻稿（通常包含高管信息）
2. 搜索行业媒体报道
3. 搜索LinkedIn/猎聘（site:linkedin.com "公司名"）
4. 标注"姓名未公开，需线下接触获取"

### 问题4：HTML文档样式错误

**现象**：生成的HTML文档样式混乱

**解决**：
1. 检查CSS代码是否正确
2. 使用浏览器开发者工具调试
3. 参考模板HTML文件（`广州伊的家-客户攻坚计划书.html`）
4. 确保使用内嵌CSS（而非外部CSS文件）

---

## 版本历史

**v2.1.0** (2026-04-26)
- 🔧 **修复**：解决 f-string 与 CSS 花括号冲突问题（使用占位符替换法）
- 📊 更新 generate_attack_plan.py 脚本（正确使用 .replace() 方法）
- ✅ 验证 HTML 输出格式（8章节完整结构）

**v2.0.0** (2026-04-25)
- 🎨 **重大更新**：从Word格式改为HTML格式
- 📊 增加8章节结构（原5章节）
- 🔍 增加真实数据获取方法（DNS解析、IP归属查询、高管搜索）
- 💰 增加腾讯云产品报价核算方法
- 🤖 增加WorkBuddy和ClawPro推荐部分
- 📝 更新文档模板和配色方案
- ⚠️ 强化数据准确性要求（禁止虚构数据）

**v1.0.0** (2026-04-24)
- 初始版本发布
- 支持"三图一表"完整生成
- 集成多个技能实现自动化
- 生成Word格式文档

---

## 反馈与改进

如有功能建议或问题反馈，请联系销冠团队。

**已知改进方向**：
1. 支持自定义HTML模板
2. 支持历史攻坚计划书对比
3. 自动更新客户信息（定时任务）
4. 支持团队协作编辑攻坚计划书
5. 集成更多真实数据获取方法（如：招投标数据、专利数据）

---

## 最佳实践

本技能的最佳实践资产已沉淀到工作区，可直接复用：

### 1. HTML 报告模板
- **文件**: `/Users/super/WorkBuddy/腾讯云渠道销售专家/广州伊的家-客户攻坚计划书.html`
- **说明**: 完整的8章节HTML报告模板，包含配色方案、打印样式、响应式布局
- **使用方法**: 复制模板，替换内容，保持CSS样式不变

### 2. PPT 生成脚本
- **文件**: `/Users/super/WorkBuddy/腾讯云渠道销售专家/ppt-workbuddy/`
- **说明**: 包含22张PNG图片、12个HTML文件、2个JS脚本，用于生成专业的PPT报告
- **使用方法**: 使用 `generate-ppt-complete.js` 或 `generate-ppt-final.js` 生成PPT

### 3. 报价单生成脚本
- **文件**: `/Users/super/WorkBuddy/腾讯云渠道销售专家/generate-quote-excel.py`
- **说明**: 生成腾讯云报价单（Excel格式），应用腾讯云配色方案，包含深蓝表头、浅蓝合计行、橙红强调色
- **使用方法**: 运行脚本，输入产品配置，自动生成报价单Excel文件

### 4. 架构图生成脚本
- **文件**: 
  - `/Users/super/WorkBuddy/腾讯云渠道销售专家/generate-org-chart.py`（组织架构图）
  - `/Users/super/WorkBuddy/腾讯云渠道销售专家/generate-business-arch.py`（业务架构图）
  - `/Users/super/WorkBuddy/腾讯云渠道销售专家/generate-tech-arch.py`（技术架构图）
- **说明**: 使用Python生成SVG/PNG架构图，可嵌入HTML报告
- **使用方法**: 运行脚本，输入架构信息，自动生成架构图

### 5. 完整生成脚本
- **文件**: `/Users/super/.workbuddy/skills/customer-attack-plan/scripts/generate_attack_plan.py`
- **说明**: 一键生成完整的8章节HTML攻坚计划书
- **使用方法**: 
  ```bash
  python3 generate_attack_plan.py "客户公司名称" "伙伴名称" "销售名称" "架构师名称"
  ```

### 6. 工作区其他可用脚本
- `generate-attack-plan-final.py` - 最终版攻击计划生成脚本
- `generate-attack-plan-optimized.py` - 优化版攻击计划生成脚本
- `add-chapter4-rest.py` - 添加第4章（业务架构分析）
- `add-content-step1.py`、`add-content-step2.py` - 分步添加内容

**实践建议**：
1. 首次使用：直接运行 `generate_attack_plan.py`，生成基础报告
2. 定制化：修改HTML模板（CSS样式、章节内容）
3. 批量生成：编写批处理脚本，循环生成多个客户的攻坚计划书
4. 版本管理：为每个客户保存单独的HTML文件，定期更新

---

**让每个销售都能生成专业级的客户攻坚计划书！**
