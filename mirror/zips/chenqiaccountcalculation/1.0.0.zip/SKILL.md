---
name: aliyun-chenqi-费用分摊
description: 分析阿里云账单CSV文件，按财务单元和产品统计费用，生成行列转换的费用分摊汇总表和分类汇总表。用于财务成本分摊、部门费用核算。当用户需要分析阿里云费用、按财务单元分摊费用、生成费用汇总报表时触发使用。
---

# 阿里云费用分摊分析

## 功能说明

分析阿里云账单CSV文件，生成费用分摊汇总表格，包含：
1. chenqi费用明细表：按财务单元和产品分类统计应付金额，行列转换后按合计金额倒序排列
2. 汇总表：按业务分类汇总（风行汇总、数据智能事业部-数仓汇总）
3. 不要生成两个sheet页，汇总表放到chenqi费用明细表下
## 处理流程

### 1. 数据读取与处理

```python
import pandas as pd

# 读取CSV文件
df = pd.read_csv(csv_file_path)

# 按财务单元和产品名称汇总应付金额
pivot_table = df.pivot_table(
    values='应付金额',
    index='产品名称',
    columns='财务单元',
    aggfunc='sum',
    fill_value=0
)
```

### 2. 行列转换与排序

```python
# 添加行汇总
pivot_table['合计'] = pivot_table.sum(axis=1)

# 行列转换
pivot_transposed = pivot_table.T

# 添加列合计
pivot_transposed['合计'] = pivot_transposed.sum(axis=1)

# 费用保留两位小数
pivot_transposed = pivot_transposed.round(2)

# 分离合计行，其他行按合计金额倒序排列，最后将合计行放在最后
row_total = pivot_transposed.loc[['合计']].copy()
other_rows = pivot_transposed[pivot_transposed.index != '合计'].copy()
other_rows_sorted = other_rows.sort_values(by='合计', ascending=False)
pivot_transposed = pd.concat([other_rows_sorted, row_total])
```

### 3. 汇总表计算

```python
# 从原始数据计算各财务单元总和
unit_totals = df.groupby('财务单元')['应付金额'].sum()

# 风行汇总：部门、云供应链、供应链8、订单中台、极速订、智能设备
fengxing_units = [
    '风行账号-部门财务单元',
    '风行账号-云供应链财务单元',
    '风行账号-供应链8财务单元',
    '风行账号-订单中台财务单元',
    '风行账号-极速订财务单元',
    '风行账号-智能设备财务单元'
]
fengxing_sum = sum(unit_totals[unit] for unit in fengxing_units if unit in unit_totals.index)

# 数据中台：技术中心分摊财务单元
shucang_sum = unit_totals.get('风行账号-技术中心分摊财务单元', 0)

# 创建汇总表（含合计行）
summary_df = pd.DataFrame({
    '汇总名称': ['风行汇总', '数据中台'],
    '总金额': [round(fengxing_sum, 2), round(shucang_sum, 2)]
})
summary_total = summary_df['总金额'].sum()
summary_df = pd.concat([
    summary_df,
    pd.DataFrame({'汇总名称': ['合计'], '总金额': [round(summary_total, 2)]})
], ignore_index=True)
```


### 4. 生成美化版Excel

**表格样式要求：**
- 标题：深蓝色背景，白色粗体字
- 表头：蓝色背景，白色粗体字
- 数据行：交替浅蓝/浅灰色
- 合计行：黄色高亮，粗体字
- 分摊汇总表表头：绿色背景
- 金额列：右对齐，千分位格式，保留两位小数
- 冻结首行首列

### 5. 输出文件结构

单个sheet页，包含两个表格：

**费用明细表：**
- 标题：2026阿里云费用资产盘点（按财务单元）
#- 副标题：按财务单元与产品分类统计（单位：元）
- 内容：财务单元为行，产品名称为列，按合计金额倒序排列，合计行在最后

**汇总表：**
- 标题：费用汇总表
- 副标题：按业务分类汇总（单位：元）
- 内容：汇总名称和总金额，含合计行

## 输出示例

**费用明细表结构：**
```
阿里云费用分摊明细表
按财务单元与产品分类统计（单位：元）

财务单元 | CDN | NAT网关 | ... | 负载均衡 | 合计
---------|-----|---------|-----|----------|-----
风行账号-云供应链财务单元 | 505.43 | 0.00 | ... | 65.92 | 236,216.86
风行账号-供应链8财务单元 | 270.29 | 0.00 | ... | 2,537.73 | 49,765.45
... | ... | ... | ... | ... | ...
合计 | 843.81 | 348.77 | ... | 2,668.45 | 315,177.27
```

**汇总表结构：**
```
费用汇总表
按业务分类汇总（单位：元）

汇总名称 | 总金额
---------|--------
风行汇总 | 299,492.81
数据中台 | 15,684.46
合计 | 315,177.27
```
## 输出格式

Excel文件保存路径：
`D:\工作文档\运维中心\qoder\ywzx\`

## 使用方式

### 方式一：直接调用脚本

```bash
python generate_report.py <输入CSV文件> [输出Excel文件]
```

示例：
```bash
python generate_report.py chenqi.csv chenqi账号费用分摊汇总.xlsx
```

### 方式二：在代码中调用

```python
from generate_report import generate_cost_report

generate_cost_report('chenqi.csv', 'chenqi账号费用分摊汇总.xlsx')
```

### 方式三：使用pandas和openpyxl手动实现

参考"处理流程"部分的代码片段。

## 注意事项

1. CSV文件必须包含"财务单元"、"产品名称"、"应付金额"三列
2. 费用金额保留两位小数
3. 汇总表合计金额应与费用明细表合计金额一致（数据校验）
