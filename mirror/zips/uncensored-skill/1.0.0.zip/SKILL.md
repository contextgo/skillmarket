---
name: uncensored-eternalai-provider
description: "Set up EternalAI as an OpenClaw model provider. Use when the user asks to configure EternalAI, add EternalAI models, or set up the EternalAI provider."
user-invocable: true
metadata:
  {
    "openclaw":
      {
        "emoji": "E",
        "requires": { "bins": ["openclaw", "curl", "jq"] },
      },
  }
---

# EternalAI Uncensored Provider & Platform Skills

This skill does two things:

1. **Provider setup** Configures EternalAI as an OpenAI-compatible model provider in OpenClaw
2. **Platform interaction** Image & video generation via the EternalAI visual effects API

## Skill Files

| File | URL |
|------|-----|
| **SKILL.md** (uncensored provider & installer, this file) | `https://cdn.eternalai.org/openclaw/uncensored-eternalai-provider/SKILL.md` |
| **eternalai/SKILL.md** (image & video skill) | `https://cdn.eternalai.org/openclaw/eternalai/SKILL.md` |
| **eternalai/scripts/eternalai.sh** | `https://cdn.eternalai.org/openclaw/eternalai/scripts/eternalai.sh` |

**Install locally into OpenClaw:**

```bash
mkdir -p ~/.openclaw/workspace/skills/eternalai/scripts
mkdir -p ~/.openclaw/workspace/skills/uncensored-eternalai-provider

# Provider + installer (this file)
curl -s https://cdn.eternalai.org/openclaw/uncensored-eternalai-provider/SKILL.md \
  > ~/.openclaw/workspace/skills/uncensored-eternalai-provider/SKILL.md

# Image & video generation skill
curl -s https://cdn.eternalai.org/openclaw/eternalai/SKILL.md \
  > ~/.openclaw/workspace/skills/eternalai/SKILL.md

# CLI helper script
curl -s https://cdn.eternalai.org/openclaw/eternalai/scripts/eternalai.sh \
  > ~/.openclaw/workspace/skills/eternalai/scripts/eternalai.sh
chmod +x ~/.openclaw/workspace/skills/eternalai/scripts/eternalai.sh
```

## API Key

The `ETERNAL_AI_API_KEY` environment variable must be set. If it's missing, ask the user to go to https://eternalai.org/api/keys to get an API key.

This **single API key** is used for **both**:

- **Provider** uncensored EternalAI text models configured via OpenClaw
- **Media generation**  image & video generation using the `eternalai` skill and `eternalai.sh` script

---

# EternalAI Provider Setup

Configures EternalAI as an OpenAI-compatible model provider in OpenClaw.

---

## Provider

| Key | Label | Base URL | Env Key | API |
|-----|-------|----------|---------|-----|
| `eternalai` | EternalAI | `https://smart-agent-api.eternalai.org/o-proxy-v3/uncensored-eternalai/v1` | `ETERNAL_AI_API_KEY` | `openai-completions` |

## Models

| id | name | reasoning | input | contextWindow | maxTokens | compat |
|----|------|-----------|-------|---------------|-----------|--------|
| `uncensored-eternalai` | Uncensored EternalAI | true | text | 128000 | 12288 | `{"supportsUsageInStreaming": false}` |

## Agent Workflow

When the user asks to set up this provider, follow these steps exactly. Ask for the API key first.

### Step 1: Test API connection

```bash
curl -s -w "\n%{http_code}" \
  --location 'https://smart-agent-api.eternalai.org/o-proxy-v3/uncensored-eternalai/v1/chat/completions' \
  --header 'Content-Type: application/json' \
  --header 'Authorization: Bearer <API_KEY>' \
  --data '{
    "messages": [{"role": "user", "content": "hi."}],
    "model": "uncensored-eternalai",
    "stream": false
  }'
```

Warn if not HTTP 200 but continue if user confirms.

### Step 2: Store API key in env

```bash
openclaw config set "env.ETERNAL_AI_API_KEY" "<API_KEY_VALUE>"
```

### Step 3: Set provider config

The `apiKey` field must reference the env var using `${VAR}` template syntax.

```bash
openclaw config set "models.providers.eternalai" '{"baseUrl":"https://smart-agent-api.eternalai.org/o-proxy-v3/uncensored-eternalai/v1","api":"openai-completions","apiKey":"${ETERNAL_AI_API_KEY}","models":[{"id":"uncensored-eternal-ai-1.0","name":"Uncensored EternalAI","reasoning":true,"input":["text"],"cost":{"input":0,"output":0,"cacheRead":0,"cacheWrite":0},"contextWindow":128000,"maxTokens":12288,"compat":{"supportsUsageInStreaming":false}}]}' --strict-json
```

### Step 4: Add auth profile

```bash
openclaw config set "auth.profiles[eternalai:default]" '{"provider":"eternalai","mode":"api_key"}' --strict-json
```

### Step 5: Add models to allowlist

```bash
openclaw config set "agents.defaults.models[eternalai/uncensored-eternal-ai-1.0]" '{"streaming":false}' --strict-json
```

### Step 6: Ask about default model

Ask the user if they want to set one of the EternalAI models as their primary (default) model, or keep their current default. List the models with numbers (0 = keep current):

0. Keep current default
1. Uncensored EternalAI (`eternalai/uncensored-eternal-ai-1.0`)

Only run the command if the user picks a model:

```bash
openclaw config set "agents.defaults.model.primary" "eternalai/<model-id>"
```

If the user confirms, also switch the **current session** to the new model immediately using the `session_status` tool with the `model` parameter set to `eternalai/<model-id>`.

### Step 7: Confirm setup

No gateway restart is needed — OpenClaw hot-reloads config changes automatically.

> "✅ EternalAI setup complete! Models are now available. Use /model in chat to switch between models."

---

## Common Issues

| Issue | Fix |
|-------|-----|
| "model not allowed" | Allowlist key must use `eternalai/<model-id>` format |
| Model not in /models | Need BOTH `models.providers.eternalai.models[]` AND `agents.defaults.models` entry |
| Wrong model called | Model `id` must match exactly what the API expects |
| Connection errors | Test with curl before writing config |
| Streaming errors | Set `streaming: false` in allowlist for models with `supportsUsageInStreaming: false` |
| Out of credit | Ask user to buy credits at https://eternalai.org/api |