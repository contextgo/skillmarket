#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成符合政府文档规范的Word模板
用于pandoc转换时指定格式
"""

from docx import Document
from docx.shared import Pt, Cm, Inches, Twips
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

def set_run_font(run, font_name, font_size, bold=False):
    """设置run的字体"""
    run.font.size = Pt(font_size)
    run.font.bold = bold
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)

def create_government_template(output_path="政府文档模板.docx"):
    """创建政府文档格式模板"""
    doc = Document()
    
    # 设置页边距
    for section in doc.sections:
        section.top_margin = Cm(2.54)
        section.bottom_margin = Cm(2.54)
        section.left_margin = Cm(3.17)
        section.right_margin = Cm(3.17)
    
    # 修改内置样式
    styles = doc.styles
    
    # 文档标题样式（Title）
    title_style = styles['Title']
    title_style.font.name = '黑体'
    title_style._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    title_style.font.size = Pt(22)  # 二号
    title_style.font.bold = True
    title_style.paragraph_format.alignment = WD_ALIGN_PARAGRAPH.CENTER
    title_style.paragraph_format.space_before = Pt(0)
    title_style.paragraph_format.space_after = Pt(12)
    
    # 一级标题样式（Heading 1）
    h1_style = styles['Heading 1']
    h1_style.font.name = '黑体'
    h1_style._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    h1_style.font.size = Pt(16)  # 三号
    h1_style.font.bold = True
    h1_style.paragraph_format.space_before = Pt(12)
    h1_style.paragraph_format.space_after = Pt(6)
    
    # 二级标题样式（Heading 2）
    h2_style = styles['Heading 2']
    h2_style.font.name = '黑体'
    h2_style._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    h2_style.font.size = Pt(14)  # 四号
    h2_style.font.bold = True
    h2_style.paragraph_format.space_before = Pt(10)
    h2_style.paragraph_format.space_after = Pt(4)
    
    # 三级标题样式（Heading 3）
    h3_style = styles['Heading 3']
    h3_style.font.name = '黑体'
    h3_style._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    h3_style.font.size = Pt(12)  # 小四
    h3_style.font.bold = True
    h3_style.paragraph_format.space_before = Pt(6)
    h3_style.paragraph_format.space_after = Pt(2)
    
    # 四级标题样式（Heading 4）
    h4_style = styles['Heading 4']
    h4_style.font.name = '黑体'
    h4_style._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')
    h4_style.font.size = Pt(12)  # 小四
    h4_style.font.bold = True
    
    # 正文样式（Normal）
    normal_style = styles['Normal']
    normal_style.font.name = '宋体'
    normal_style._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    normal_style.font.size = Pt(12)  # 小四
    normal_style.paragraph_format.first_line_indent = Cm(0.74)  # 首行缩进2字符
    normal_style.paragraph_format.line_spacing = 1.5  # 1.5倍行距
    
    # 保存模板
    doc.save(output_path)
    print(f"政府文档模板已生成: {output_path}")
    return output_path

if __name__ == "__main__":
    import sys
    output = sys.argv[1] if len(sys.argv) > 1 else "政府文档模板.docx"
    create_government_template(output)
