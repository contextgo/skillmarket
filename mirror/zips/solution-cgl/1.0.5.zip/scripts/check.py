#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
技术方案完整性检查脚本
检查生成的技术方案是否包含所有必要章节
"""

import re
import sys
from pathlib import Path


def check_tech_solution(file_path: str) -> dict:
    """
    检查技术方案文档的完整性
    
    Args:
        file_path: 技术方案文档路径
        
    Returns:
        检查结果字典
    """
    # 必须包含的章节列表
    required_sections = [
        "项目概述",
        "需求分析",
        "总体架构设计",
        "技术选型方案",
        "功能模块设计",
        "数据架构设计",
        "安全架构设计",
        "部署架构设计",
        "接口设计",
        "性能保障方案",
        "实施方案",
        "运维保障方案",
        "项目预算",
        "风险分析与应对",
        "附录"
    ]
    
    # 必须包含的子章节
    required_subsections = {
        "项目概述": ["项目背景", "项目目标", "项目范围", "建设原则"],
        "需求分析": ["业务需求分析", "功能需求分析", "技术需求分析"],
        "总体架构设计": ["设计原则", "架构总览"],
        "技术选型方案": ["开发技术选型"],
        "功能模块设计": [],  # 动态生成，不检查
        "接口设计": ["接口规范", "核心接口清单"],
        "实施方案": ["实施计划"],
        "运维保障方案": ["监控方案", "备份方案"],
    }
    
    # 读取文件内容
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
    except FileNotFoundError:
        return {
            "status": "error",
            "message": f"文件不存在: {file_path}"
        }
    
    results = {
        "status": "success",
        "file_path": file_path,
        "missing_sections": [],
        "missing_subsections": {},
        "found_sections": [],
        "warnings": []
    }
    
    # 检查主章节
    for section in required_sections:
        # 匹配 ## 一、项目概述 或 ## 项目概述 格式
        pattern = rf"##\s*(一、)?{section}"
        if re.search(pattern, content):
            results["found_sections"].append(section)
        else:
            results["missing_sections"].append(section)
    
    # 检查子章节
    for main_section, subsections in required_subsections.items():
        if main_section in results["missing_sections"]:
            continue  # 主章节缺失，跳过子章节检查
            
        missing_subs = []
        for sub in subsections:
            # 匹配 ### 1.1 项目背景 或 ### 项目背景 格式
            pattern = rf"###\s*(\d+\.\d+\s*)?{sub}"
            if not re.search(pattern, content):
                missing_subs.append(sub)
        
        if missing_subs:
            results["missing_subsections"][main_section] = missing_subs
    
    # 检查是否有占位符未替换
    placeholder_patterns = [
        r"\[金额\]",
        r"\[总金额\]",
        r"\[项目名称\]",
        r"\[单位名称\]",
        r"\[具体单位/部门\]",
    ]
    
    for pattern in placeholder_patterns:
        if re.search(pattern, content):
            results["warnings"].append(f"存在未替换的占位符: {pattern}")
    
    # 判断整体状态
    if results["missing_sections"]:
        results["status"] = "incomplete"
    elif results["missing_subsections"]:
        results["status"] = "incomplete"
    elif results["warnings"]:
        results["status"] = "warning"
    
    return results


def print_report(results: dict):
    """打印检查报告"""
    print("\n" + "="*60)
    print("技术方案完整性检查报告")
    print("="*60)
    print(f"\n文件: {results['file_path']}")
    print(f"状态: {results['status'].upper()}")
    
    if results["status"] == "success":
        print("\n✅ 所有章节完整！")
    elif results["status"] == "incomplete":
        print("\n❌ 存在缺失章节")
    elif results["status"] == "warning":
        print("\n⚠️ 完整但存在警告")
    
    # 显示找到的章节
    if results["found_sections"]:
        print(f"\n✅ 已包含章节 ({len(results['found_sections'])}/15):")
        for section in results["found_sections"]:
            print(f"   - {section}")
    
    # 显示缺失的章节
    if results["missing_sections"]:
        print(f"\n❌ 缺失章节 ({len(results['missing_sections'])}):")
        for section in results["missing_sections"]:
            print(f"   - {section}")
    
    # 显示缺失的子章节
    if results["missing_subsections"]:
        print("\n❌ 缺失子章节:")
        for main_section, subs in results["missing_subsections"].items():
            print(f"   {main_section}:")
            for sub in subs:
                print(f"     - {sub}")
    
    # 显示警告
    if results["warnings"]:
        print("\n⚠️ 警告:")
        for warning in results["warnings"]:
            print(f"   - {warning}")
    
    print("\n" + "="*60)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python check.py <技术方案文件路径>")
        print("示例: python check.py 技术方案_南岸AI值班管理系统_20260414.md")
        sys.exit(1)
    
    file_path = sys.argv[1]
    results = check_tech_solution(file_path)
    print_report(results)
    
    # 返回退出码
    sys.exit(0 if results["status"] == "success" else 1)
