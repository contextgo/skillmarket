#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Markdown转Word脚本
将技术方案Markdown文档转换为Word格式
"""

import sys
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn


def create_document():
    """创建Word文档并设置样式"""
    doc = Document()
    
    # 设置默认字体
    doc.styles['Normal'].font.name = '宋体'
    doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), '宋体')
    doc.styles['Normal'].font.size = Pt(12)
    
    return doc


def add_title(doc, text, level=1):
    """添加标题"""
    if level == 0:
        # 文档主标题
        paragraph = doc.add_heading(text, level=0)
        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for run in paragraph.runs:
            run.font.size = Pt(22)
            run.font.bold = True
    else:
        heading = doc.add_heading(text, level=level)
        for run in heading.runs:
            run.font.name = '黑体'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')


def add_paragraph(doc, text):
    """添加普通段落"""
    paragraph = doc.add_paragraph(text)
    paragraph.paragraph_format.first_line_indent = Inches(0.3)
    paragraph.paragraph_format.line_spacing = 1.5


def add_table(doc, headers, rows):
    """添加表格"""
    table = doc.add_table(rows=len(rows) + 1, cols=len(headers))
    table.style = 'Table Grid'
    
    # 添加表头
    header_cells = table.rows[0].cells
    for i, header in enumerate(headers):
        header_cells[i].text = header
        for paragraph in header_cells[i].paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
    
    # 添加数据行
    for i, row in enumerate(rows):
        row_cells = table.rows[i + 1].cells
        for j, cell in enumerate(row):
            row_cells[j].text = str(cell)
    
    # 表格后添加空行
    doc.add_paragraph()


def parse_markdown_table(lines):
    """解析Markdown表格"""
    if len(lines) < 2:
        return None, None
    
    # 解析表头
    header_line = lines[0].strip('|').split('|')
    headers = [h.strip() for h in header_line]
    
    # 跳过分隔行
    data_lines = lines[2:] if len(lines) > 2 else []
    
    rows = []
    for line in data_lines:
        if line.strip().startswith('|'):
            cells = line.strip('|').split('|')
            rows.append([c.strip() for c in cells])
    
    return headers, rows


def parse_markdown_to_docx(md_content: str, output_path: str):
    """将Markdown内容转换为Word文档"""
    doc = create_document()
    
    lines = md_content.split('\n')
    i = 0
    
    while i < len(lines):
        line = lines[i].strip()
        
        # 空行
        if not line:
            i += 1
            continue
        
        # 主标题 (# 开头)
        if line.startswith('# ') and not line.startswith('## '):
            title = line[2:].strip()
            add_title(doc, title, level=0)
            i += 1
            continue
        
        # 二级标题 (## 开头)
        if line.startswith('## '):
            title = line[3:].strip()
            # 移除章节编号，如 "一、项目概述" -> "项目概述"
            if '、' in title:
                title = title.split('、', 1)[1]
            add_title(doc, title, level=1)
            i += 1
            continue
        
        # 三级标题 (### 开头)
        if line.startswith('### '):
            title = line[4:].strip()
            # 移除子章节编号，如 "1.1 项目背景" -> "项目背景"
            if re.match(r'\d+\.\d+\s', title):
                title = re.sub(r'\d+\.\d+\s', '', title)
            add_title(doc, title, level=2)
            i += 1
            continue
        
        # 四级标题 (#### 开头)
        if line.startswith('#### '):
            title = line[5:].strip()
            add_title(doc, title, level=3)
            i += 1
            continue
        
        # 表格
        if line.startswith('|'):
            # 收集整个表格
            table_lines = []
            while i < len(lines) and lines[i].strip().startswith('|'):
                table_lines.append(lines[i])
                i += 1
            
            headers, rows = parse_markdown_table(table_lines)
            if headers and rows:
                add_table(doc, headers, rows)
            continue
        
        # 代码块
        if line.startswith('```'):
            # 收集代码块内容
            code_lines = []
            i += 1
            while i < len(lines) and not lines[i].strip().startswith('```'):
                code_lines.append(lines[i])
                i += 1
            i += 1  # 跳过结束的 ```
            
            # 添加代码块（作为普通文本，保持格式）
            code_text = '\n'.join(code_lines)
            paragraph = doc.add_paragraph()
            run = paragraph.add_run(code_text)
            run.font.name = 'Courier New'
            run.font.size = Pt(10)
            continue
        
        # 列表项
        if line.startswith('- ') or line.startswith('* '):
            text = line[2:].strip()
            paragraph = doc.add_paragraph(text, style='List Bullet')
            i += 1
            continue
        
        # 有序列表
        if re.match(r'^\d+\.\s', line):
            text = re.sub(r'^\d+\.\s', '', line)
            paragraph = doc.add_paragraph(text, style='List Number')
            i += 1
            continue
        
        # 普通段落
        add_paragraph(doc, line)
        i += 1
    
    # 保存文档
    doc.save(output_path)
    print(f"Word文档已生成: {output_path}")


def convert_md_to_docx(md_file: str, docx_file: str = None):
    """将Markdown文件转换为Word文档"""
    md_path = Path(md_file)
    
    if not md_path.exists():
        print(f"错误: 文件不存在 {md_file}")
        return False
    
    # 默认输出文件名
    if docx_file is None:
        docx_file = md_path.with_suffix('.docx')
    
    # 读取Markdown内容
    with open(md_path, 'r', encoding='utf-8') as f:
        md_content = f.read()
    
    # 转换
    parse_markdown_to_docx(md_content, str(docx_file))
    return True


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python md_to_docx.py <Markdown文件路径> [输出Word文件路径]")
        print("示例: python md_to_docx.py 技术方案.md 技术方案.docx")
        sys.exit(1)
    
    md_file = sys.argv[1]
    docx_file = sys.argv[2] if len(sys.argv) > 2 else None
    
    success = convert_md_to_docx(md_file, docx_file)
    sys.exit(0 if success else 1)
