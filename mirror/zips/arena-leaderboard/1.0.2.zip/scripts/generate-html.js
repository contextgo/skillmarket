/**
 * 生成 Arena.ai 榜单 HTML 页面（标签切换版）
 * 用法: node generate-html.js <input.json> <output.html>
 */

const fs = require('fs');

const CATEGORY_META = {
  'text': { name: 'Text', icon: '💬' },
  'code': { name: 'Code', icon: '💻' },
  'vision': { name: 'Vision', icon: '👁️' },
  'search': { name: 'Search', icon: '🔍' },
  'document': { name: 'Document', icon: '📄' },
  'text-to-image': { name: '文生图', icon: '🎨' },
  'image-edit': { name: '图编辑', icon: '✏️' },
  'text-to-video': { name: '文生视频', icon: '🎬' },
  'image-to-video': { name: '图生视频', icon: '🎥' },
  'video-edit': { name: '视频编辑', icon: '🎞️' }
};

const ICON_BASE_URL = 'https://cdn.jsdelivr.net/npm/@lobehub/icons-static-png@1.85.0/light';

const ICON_MAP = {
  'claude': 'claude', 'claudecode': 'claudecode',
  'gpt': 'openai', 'chatgpt': 'openai', 'o1': 'openai', 'o3': 'openai', 'o4': 'openai', 'codex': 'codex', 'dall': 'dalle',
  'gemini': 'gemini', 'geminicli': 'geminicli', 'gemma': 'gemma',
  'grok': 'grok', 'xai': 'xai',
  'llama': 'meta', 'metaai': 'metaai',
  'qwen': 'qwen', 'glm': 'zhipu', 'chatglm': 'chatglm', 'zhipu': 'zhipu',
  'doubao': 'doubao', 'kimi': 'kimi', 'moonshot': 'moonshot',
  'wenxin': 'wenxin', 'ernie': 'wenxin', 'yi': 'yi',
  'deepseek': 'deepseek', 'minimax': 'minimax',
  'hunyuan': 'hunyuan', 'internlm': 'internlm', 'baichuan': 'baichuan',
  'skywork': 'skywork', 'stepfun': 'stepfun', 'sensenova': 'sensenova',
  'kling': 'kling', 'hailuo': 'hailuo', 'vidu': 'vidu',
  'cogvideo': 'cogvideo', 'cogview': 'cogview', 'pixverse': 'pixverse',
  'jimeng': 'jimeng', 'kolors': 'kolors', 'spark': 'spark', 'tiangong': 'tiangong',
  'mistral': 'mistral', 'mixtral': 'mistral', 'codestral': 'mistral',
  'cohere': 'cohere', 'command': 'cohere', 'dbrx': 'dbrx',
  'phi': 'microsoft', 'copilot': 'copilot',
  'midjourney': 'midjourney', 'sora': 'sora', 'flux': 'flux', 'ideogram': 'ideogram',
  'runway': 'runway', 'pika': 'pika', 'luma': 'luma',
  'stability': 'stability', 'sd': 'stability', 'stable': 'stability',
  'nvidia': 'nvidia', 'aws': 'aws', 'bedrock': 'bedrock', 'azure': 'azure',
  'huggingface': 'huggingface', 'perplexity': 'perplexity',
  'fireworks': 'fireworks', 'together': 'together', 'groq': 'groq',
  'deepinfra': 'deepinfra', 'cerebras': 'cerebras', 'sambanova': 'sambanova',
  'snowflake': 'snowflake', 'exa': 'exa', 'tavily': 'tavily'
};

const VENDOR_ICON_MAP = {
  'Anthropic': 'claude', 'OpenAI': 'openai', 'Google': 'google',
  'xAI': 'grok', 'Meta': 'meta', 'Alibaba': 'qwen', 'Z.ai': 'zhipu',
  'Bytedance': 'doubao', 'DeepSeek': 'deepseek', 'Moonshot': 'kimi',
  'Baidu': 'wenxin', 'MiniMax': 'minimax', 'Xiaomi': 'mimo',
  'Microsoft': 'microsoft', 'Amazon': 'aws', 'Stability': 'stability',
  'Mistral': 'mistral', 'Cohere': 'cohere', 'Nvidia': 'nvidia',
  'IBM': 'ibm', 'Apple': 'apple', 'Tencent': 'tencent', 'Huawei': 'huawei',
  'Perplexity': 'perplexity', '01.AI': 'yi'
};

const PRICES = {
  'claude-opus-4-6': { input: 15, output: 75 },
  'claude-opus-4-6-thinking': { input: 15, output: 75 },
  'claude-sonnet-4-6': { input: 3, output: 15 },
  'claude-sonnet-4': { input: 3, output: 15 },
  'claude-opus-4-5': { input: 15, output: 75 },
  'claude-opus-4-5-20251101': { input: 15, output: 75 },
  'claude-3-5-sonnet': { input: 3, output: 15 },
  'claude-3-5-haiku': { input: 0.8, output: 4 },
  'claude-3-opus': { input: 15, output: 75 },
  'claude-3-haiku': { input: 0.25, output: 1.25 },
  'gpt-4o': { input: 2.5, output: 10 },
  'gpt-4o-mini': { input: 0.15, output: 0.6 },
  'gpt-4-turbo': { input: 10, output: 30 },
  'gpt-4': { input: 30, output: 60 },
  'gpt-3.5-turbo': { input: 0.5, output: 1.5 },
  'o1': { input: 15, output: 60 },
  'o1-mini': { input: 1.5, output: 6 },
  'o3-mini': { input: 1.1, output: 4.4 },
  'gpt-5': { input: 10, output: 30 },
  'gpt-5.4': { input: 10, output: 30 },
  'gpt-5.4-high': { input: 15, output: 60 },
  'gemini-2-pro': { input: 1.25, output: 5 },
  'gemini-2-flash': { input: 0.1, output: 0.4 },
  'gemini-1.5-pro': { input: 1.25, output: 5 },
  'gemini-1.5-flash': { input: 0.075, output: 0.3 },
  'gemini-3-pro': { input: 1.25, output: 10 },
  'gemini-3-flash': { input: 0.1, output: 0.4 },
  'gemini-3.1-pro': { input: 1.25, output: 10 },
  'grok-2': { input: 2, output: 10 },
  'grok-3': { input: 3, output: 15 },
  'grok-4': { input: 3, output: 15 },
  'grok-4.20': { input: 5, output: 25 },
  'llama-3-70b': { input: 0.7, output: 0.7 },
  'llama-3.1-70b': { input: 0.7, output: 0.7 },
  'llama-3.1-405b': { input: 3, output: 3 },
  'llama-3.3-70b': { input: 0.6, output: 0.6 },
  'llama-4': { input: 0.8, output: 0.8 },
  'llama-4-maverick': { input: 0.2, output: 0.6 },
  'llama-4-scout': { input: 0.15, output: 0.5 },
  'qwen-turbo': { input: 0.3, output: 0.6 },
  'qwen-plus': { input: 0.8, output: 2 },
  'qwen-max': { input: 20, output: 60 },
  'qwen-2.5-72b': { input: 0.4, output: 0.4 },
  'qwen-3': { input: 0.5, output: 1 },
  'qwen-3-72b': { input: 0.4, output: 0.4 },
  'qwen-3.5': { input: 0.6, output: 1.2 },
  'qwen-3.6': { input: 0.8, output: 2 },
  'glm-4': { input: 14, output: 14 },
  'glm-4-plus': { input: 14, output: 14 },
  'glm-4-air': { input: 1, output: 1 },
  'glm-4-flash': { input: 0.1, output: 0.1 },
  'glm-4.5': { input: 10, output: 10 },
  'glm-4.6': { input: 8, output: 8 },
  'glm-4.7': { input: 6, output: 6 },
  'glm-5': { input: 5, output: 5 },
  'deepseek-chat': { input: 0.14, output: 0.28 },
  'deepseek-coder': { input: 0.14, output: 0.28 },
  'deepseek-v3': { input: 0.27, output: 1.1 },
  'deepseek-r1': { input: 0.55, output: 2.19 },
  'kimi': { input: 12, output: 12 },
  'moonshot-v1-8k': { input: 12, output: 12 },
  'doubao-pro-4k': { input: 0.8, output: 2 },
  'doubao-lite-4k': { input: 0.3, output: 0.6 },
  'wenxin': { input: 12, output: 12 },
  'ernie-4': { input: 120, output: 120 },
  'ernie-3.5': { input: 4, output: 8 },
  'minimax-abab6': { input: 2, output: 2 },
  'minimax-abab6.5': { input: 1.5, output: 1.5 },
  'mistral-small': { input: 0.2, output: 0.6 },
  'mistral-medium': { input: 2.7, output: 8.1 },
  'mistral-large': { input: 4, output: 12 },
  'mistral-large2': { input: 3, output: 9 },
  'mixtral-8x7b': { input: 0.7, output: 0.7 },
  'mixtral-8x22b': { input: 2, output: 2 },
  'codestral': { input: 0.2, output: 0.6 },
  'pixtral': { input: 0.2, output: 0.6 },
  'command': { input: 1, output: 2 },
  'command-r': { input: 0.5, output: 1.5 },
  'command-r-plus': { input: 3, output: 15 },
  'phi-3-mini': { input: 0.1, output: 0.1 },
  'phi-4': { input: 0.1, output: 0.1 },
  'dbrx': { input: 2, output: 2 },
  'yi-large': { input: 20, output: 20 },
  'yi-medium': { input: 2.5, output: 2.5 },
  'yi-lightning': { input: 0.99, output: 0.99 },
  'hunyuan-lite': { input: 0.8, output: 0.8 },
  'hunyuan-standard': { input: 4, output: 12 },
  'internlm2-20b': { input: 1, output: 1 },
  'baichuan2-53b': { input: 2, output: 2 },
  'gpt-5.4-high (codex-harness)': { input: 15, output: 60 }
};

function getIconName(modelName, vendor) {
  const modelLower = modelName.toLowerCase();
  for (const [key, icon] of Object.entries(ICON_MAP)) {
    if (modelLower.includes(key.toLowerCase())) return icon;
  }
  if (VENDOR_ICON_MAP[vendor]) return VENDOR_ICON_MAP[vendor];
  return null;
}

function getPrice(modelName) {
  if (PRICES[modelName]) return PRICES[modelName];
  const modelLower = modelName.toLowerCase();
  for (const [key, price] of Object.entries(PRICES)) {
    if (modelLower.includes(key.toLowerCase())) return price;
  }
  return null;
}

function getScoreColor(score) {
  if (score >= 1500) return '#10b981';
  if (score >= 1400) return '#3b82f6';
  if (score >= 1300) return '#f59e0b';
  return '#6b7280';
}

function formatPrice(price) {
  if (!price) return '-';
  return `$${price.input}/${price.output}`;
}

function generateModelRow(model) {
  const scoreColor = getScoreColor(model.score);
  const chineseTag = model.ch ? ' 🇨🇳' : '';
  const ciRange = model.ci ? `±${model.ci}` : '';
  const iconName = getIconName(model.model, model.vendor);
  const price = getPrice(model.model);

  let iconHtml;
  if (iconName) {
    const colorUrl = `${ICON_BASE_URL}/${iconName}-color.png`;
    const whiteUrl = `${ICON_BASE_URL}/${iconName}.png`;
    iconHtml = `<img class="model-icon" src="${colorUrl}" alt="" loading="lazy" onerror="this.onerror=null;this.src='${whiteUrl}';this.className='model-icon white';">`;
  } else {
    iconHtml = '<span class="model-icon-placeholder"></span>';
  }

  return `<tr class="${model.ch ? 'chinese' : ''}">
        <td class="col-rank">${model.rank}</td>
        <td class="col-model">${iconHtml}<span class="model-text">${model.model}${chineseTag}</span></td>
        <td class="col-vendor">${model.vendor}</td>
        <td class="col-score"><span style="color:${scoreColor}">${model.score}</span><span class="ci">${ciRange}</span></td>
        <td class="col-votes">${model.votes?.toLocaleString() || '-'}</td>
        <td class="col-price">${formatPrice(price)}</td>
      </tr>`;
}

function generateCategoryPanel(cat, data, isActive) {
  const meta = CATEGORY_META[cat] || { name: cat, icon: '📊' };
  const models = data.models || [];
  const lastUpdated = data.meta?.last_updated || '-';

  return `<div class="panel" id="panel-${cat}" style="display:${isActive ? 'block' : 'none'}">
      <div class="panel-head">
        <h2>${meta.icon} ${meta.name} 榜单</h2>
        <span class="meta-info">${models.length} 模型 · ${lastUpdated}</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead><tr>
            <th class="col-rank">排名</th>
            <th class="col-model">模型</th>
            <th class="col-vendor">厂商</th>
            <th class="col-score">Elo</th>
            <th class="col-votes">投票</th>
            <th class="col-price">价格</th>
          </tr></thead>
          <tbody>${models.map(m => generateModelRow(m)).join('\n')}</tbody>
        </table>
      </div>
    </div>`;
}

function generateChinesePanels(data) {
  const categories = Object.keys(data.leaderboards);
  let html = '';

  categories.forEach(cat => {
    const meta = CATEGORY_META[cat] || { name: cat, icon: '📊' };
    const models = (data.leaderboards[cat]?.models || []).filter(m => m.ch);
    if (models.length === 0) return;
    models.forEach((m, i) => { m.chineseRank = i + 1; });

    html += `<div class="panel chinese-panel" id="panel-chinese-${cat}" style="display:none">
        <div class="panel-head">
          <h3>${meta.icon} ${meta.name} · 中国模型</h3>
          <span class="meta-info">${models.length} 模型</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead><tr>
              <th class="col-rank">排名</th>
              <th class="col-model">模型</th>
              <th class="col-vendor">厂商</th>
              <th class="col-score">Elo</th>
              <th class="col-votes">投票</th>
              <th class="col-price">价格</th>
            </tr></thead>
            <tbody>${models.map(m => { m.rank = m.chineseRank; return generateModelRow(m); }).join('\n')}</tbody>
          </table>
        </div>
      </div>`;
  });
  return html;
}

function generateHTML(data) {
  const categories = Object.keys(data.leaderboards);
  const tabs = categories.map((cat, i) => {
    const meta = CATEGORY_META[cat] || { name: cat, icon: '📊' };
    return `<button class="tab${i === 0 ? ' active' : ''}" data-panel="${cat}">${meta.icon} ${meta.name}</button>`;
  }).join('') + '<button class="tab" data-panel="chinese">🇨🇳 中国</button>';

  const panels = categories.map((cat, i) => generateCategoryPanel(cat, data.leaderboards[cat], i === 0)).join('\n');
  const chinesePanels = generateChinesePanels(data);
  const chineseSubTabs = Object.keys(data.leaderboards)
    .filter(cat => (data.leaderboards[cat]?.models || []).some(m => m.ch))
    .map(cat => {
      const meta = CATEGORY_META[cat] || { name: cat, icon: '📊' };
      const count = (data.leaderboards[cat]?.models || []).filter(m => m.ch).length;
      return `<button class="subtab" data-panel="chinese-${cat}">${meta.icon} ${meta.name} (${count})</button>`;
    }).join('');

  return `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Arena.ai 模型榜单 - ${data.date}</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,'PingFang SC',sans-serif;background:#0f172a;color:#e2e8f0;min-height:100vh}
.container{max-width:1200px;margin:0 auto;padding:20px}
header{text-align:center;padding:24px 0;margin-bottom:20px}
header h1{font-size:1.75rem;color:#60a5fa}
header p{color:#64748b;margin-top:6px;font-size:.85rem}
header a{color:#60a5fa}

.tabs{display:flex;flex-wrap:wrap;gap:6px;justify-content:center;padding:12px;background:#1e293b;border-radius:10px;margin-bottom:20px}
.tab{padding:8px 14px;border:none;background:transparent;color:#94a3b8;cursor:pointer;border-radius:6px;font-size:.85rem;transition:.2s;white-space:nowrap}
.tab:hover{background:rgba(96,165,250,.15);color:#60a5fa}
.tab.active{background:#3b82f6;color:#fff}

.subtabs{display:flex;flex-wrap:wrap;gap:4px;justify-content:center;padding:10px;background:rgba(30,41,59,.5);border-radius:8px;margin-bottom:16px}
.subtab{padding:6px 12px;border:none;background:transparent;color:#94a3b8;cursor:pointer;border-radius:4px;font-size:.75rem;transition:.2s;white-space:nowrap}
.subtab:hover{background:rgba(239,68,68,.15);color:#f87171}
.subtab.active{background:#ef4444;color:#fff}

.panel{background:#1e293b;border-radius:12px;padding:20px;border:1px solid #334155}
.panel-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:12px}
.panel-head h2{font-size:1.15rem;color:#f1f5f9;white-space:nowrap}
.panel-head h3{font-size:1rem;color:#f1f5f9;white-space:nowrap}
.meta-info{color:#64748b;font-size:.8rem}
.chinese-panel{border-left:3px solid #ef4444}

.table-wrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;font-size:.85rem}

/* 表头 */
thead tr{background:#0f172a}
th{padding:12px 10px;text-align:left;font-weight:600;color:#94a3b8;border-bottom:2px solid #334155;white-space:nowrap;line-height:1;vertical-align:middle}
th.col-rank{text-align:center;width:50px}
th.col-model{width:40%}
th.col-vendor{width:120px}
th.col-score{width:90px}
th.col-votes{text-align:right;width:80px}
th.col-price{text-align:right;width:90px}

/* 表格行 */
tbody tr{border-bottom:1px solid #334155}
tbody tr:hover{background:rgba(96,165,250,.05)}
tbody tr.chinese{background:rgba(239,68,68,.08)}
tbody tr.chinese:hover{background:rgba(239,68,68,.15)}
td{padding:10px;vertical-align:middle;line-height:1.4}

/* 各列内容 */
td.col-rank{text-align:center;font-weight:bold;color:#94a3b8}
td.col-model{display:table-cell}
td.col-model>*{display:inline-block;vertical-align:middle}
.model-icon{width:22px;height:22px;margin-right:8px;border-radius:4px;object-fit:contain;background:transparent}
.model-icon.white{filter:brightness(0) invert(1)}
.model-icon-placeholder{width:22px;height:22px;margin-right:8px;border-radius:4px;background:#334155;display:inline-block}
.model-text{word-break:break-all}
td.col-vendor{color:#64748b;font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
td.col-score{white-space:nowrap}
td.col-score .ci{color:#64748b;font-size:.75rem;margin-left:3px}
td.col-votes{text-align:right;color:#94a3b8;white-space:nowrap}
td.col-price{text-align:right;color:#10b981;font-size:.8rem;white-space:nowrap}

footer{text-align:center;padding:20px;color:#475569;font-size:.8rem;margin-top:20px}
footer a{color:#60a5fa}

@media(max-width:768px){
.container{padding:10px}
.tabs{padding:8px;gap:4px}
.tab{padding:6px 10px;font-size:.75rem}
.panel{padding:12px}
th,td{padding:8px;font-size:.8rem}
.model-icon,.model-icon-placeholder{width:18px;height:18px;margin-right:6px}
th.col-model{width:45%}
}
</style>
</head>
<body>
<div class="container">
<header>
<h1>🏆 Arena.ai 模型榜单</h1>
<p>数据来源: <a href="https://arena.ai" target="_blank">arena.ai</a> · 快照: ${data.date}</p>
</header>

<div class="tabs">${tabs}</div>

<div id="main-panels">${panels}</div>

<div id="chinese-wrapper" style="display:none">
<div class="subtabs">${chineseSubTabs}</div>
${chinesePanels}
</div>

<footer>
<p>数据来自 <a href="https://arena.ai" target="_blank">Arena.ai</a> · 图标: <a href="https://github.com/lobehub/lobe-icons" target="_blank">LobeHub</a></p>
</footer>
</div>

<script>
document.querySelectorAll('.tab').forEach(tab=>{
tab.addEventListener('click',()=>{
const panelId=tab.dataset.panel;
document.querySelectorAll('.tab').forEach(t=>t.classList.remove('active'));
tab.classList.add('active');
if(panelId==='chinese'){
document.getElementById('main-panels').style.display='none';
document.getElementById('chinese-wrapper').style.display='block';
const first=document.querySelector('.subtab');
if(first){
document.querySelectorAll('.subtab').forEach(s=>s.classList.remove('active'));
first.classList.add('active');
document.querySelectorAll('.chinese-panel').forEach(p=>p.style.display='none');
document.getElementById('panel-'+first.dataset.panel).style.display='block';
}
}else{
document.getElementById('main-panels').style.display='block';
document.getElementById('chinese-wrapper').style.display='none';
document.querySelectorAll('.panel:not(.chinese-panel)').forEach(p=>p.style.display='none');
document.getElementById('panel-'+panelId).style.display='block';
}
});
});
document.querySelectorAll('.subtab').forEach(st=>{
st.addEventListener('click',()=>{
document.querySelectorAll('.subtab').forEach(s=>s.classList.remove('active'));
st.classList.add('active');
document.querySelectorAll('.chinese-panel').forEach(p=>p.style.display='none');
document.getElementById('panel-'+st.dataset.panel).style.display='block';
});
});
</script>
</body>
</html>`;
}

function main() {
  const inputFile = process.argv[2];
  const outputFile = process.argv[3];
  if (!inputFile || !outputFile) {
    console.error('Usage: node generate-html.js <input.json> <output.html>');
    process.exit(1);
  }
  const data = JSON.parse(fs.readFileSync(inputFile, 'utf-8'));
  const html = generateHTML(data);
  fs.writeFileSync(outputFile, html, 'utf-8');
  console.log('Generated:', outputFile);
  console.log('Size:', Math.round(html.length / 1024), 'KB');
}

main();