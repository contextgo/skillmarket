/**
 * 从 GitHub 抓取 Arena.ai 榜单数据
 * 用法: node fetch-arena-data.js <workspace>
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const CATEGORIES = [
  'text', 'code', 'vision', 'search', 'document',
  'text-to-image', 'image-edit', 'text-to-video', 'image-to-video', 'video-edit'
];

const CHINESE_VENDORS = [
  'Alibaba', 'Bytedance', 'Z.ai', 'Moonshot', 'Baidu', 'MiniMax', 'DeepSeek', 'Xiaomi'
];

// 内置价格数据 ($/百万token, 输入/输出)
const PRICES = {
  // Anthropic Claude
  'claude-opus-4-6': { input: 15, output: 75 },
  'claude-opus-4-6-thinking': { input: 15, output: 75 },
  'claude-sonnet-4-6': { input: 3, output: 15 },
  'claude-sonnet-4': { input: 3, output: 15 },
  'claude-opus-4-5': { input: 15, output: 75 },
  'claude-opus-4-5-20251101': { input: 15, output: 75 },
  'claude-3-5-sonnet': { input: 3, output: 15 },
  'claude-3-5-haiku': { input: 0.8, output: 4 },
  'claude-3-opus': { input: 15, output: 75 },
  'claude-3-haiku': { input: 0.25, output: 1.25 },
  // OpenAI GPT
  'gpt-4o': { input: 2.5, output: 10 },
  'gpt-4o-mini': { input: 0.15, output: 0.6 },
  'gpt-4-turbo': { input: 10, output: 30 },
  'gpt-4': { input: 30, output: 60 },
  'gpt-3.5-turbo': { input: 0.5, output: 1.5 },
  'o1': { input: 15, output: 60 },
  'o1-mini': { input: 1.5, output: 6 },
  'o3-mini': { input: 1.1, output: 4.4 },
  'gpt-5': { input: 10, output: 30 },
  'gpt-5.4': { input: 10, output: 30 },
  'gpt-5.4-high': { input: 15, output: 60 },
  // Google Gemini
  'gemini-2-pro': { input: 1.25, output: 5 },
  'gemini-2-flash': { input: 0.1, output: 0.4 },
  'gemini-1.5-pro': { input: 1.25, output: 5 },
  'gemini-1.5-flash': { input: 0.075, output: 0.3 },
  'gemini-3-pro': { input: 1.25, output: 10 },
  'gemini-3-flash': { input: 0.1, output: 0.4 },
  'gemini-3.1-pro': { input: 1.25, output: 10 },
  // xAI Grok
  'grok-2': { input: 2, output: 10 },
  'grok-3': { input: 3, output: 15 },
  'grok-4': { input: 3, output: 15 },
  'grok-4.20': { input: 5, output: 25 },
  // Meta Llama
  'llama-3-70b': { input: 0.7, output: 0.7 },
  'llama-3.1-70b': { input: 0.7, output: 0.7 },
  'llama-3.1-405b': { input: 3, output: 3 },
  'llama-3.3-70b': { input: 0.6, output: 0.6 },
  'llama-4': { input: 0.8, output: 0.8 },
  'llama-4-maverick': { input: 0.2, output: 0.6 },
  'llama-4-scout': { input: 0.15, output: 0.5 },
  // Alibaba Qwen
  'qwen-turbo': { input: 0.3, output: 0.6 },
  'qwen-plus': { input: 0.8, output: 2 },
  'qwen-max': { input: 20, output: 60 },
  'qwen-2.5-72b': { input: 0.4, output: 0.4 },
  'qwen-3': { input: 0.5, output: 1 },
  'qwen-3-72b': { input: 0.4, output: 0.4 },
  'qwen-3.5': { input: 0.6, output: 1.2 },
  'qwen-3.6': { input: 0.8, output: 2 },
  // Z.ai GLM
  'glm-4': { input: 14, output: 14 },
  'glm-4-plus': { input: 14, output: 14 },
  'glm-4-air': { input: 1, output: 1 },
  'glm-4-flash': { input: 0.1, output: 0.1 },
  'glm-4.5': { input: 10, output: 10 },
  'glm-4.6': { input: 8, output: 8 },
  'glm-4.7': { input: 6, output: 6 },
  'glm-5': { input: 5, output: 5 },
  // DeepSeek
  'deepseek-chat': { input: 0.14, output: 0.28 },
  'deepseek-coder': { input: 0.14, output: 0.28 },
  'deepseek-v3': { input: 0.27, output: 1.1 },
  'deepseek-r1': { input: 0.55, output: 2.19 },
  // Moonshot Kimi
  'kimi': { input: 12, output: 12 },
  'moonshot-v1-8k': { input: 12, output: 12 },
  // Bytedance Doubao
  'doubao-pro-4k': { input: 0.8, output: 2 },
  'doubao-lite-4k': { input: 0.3, output: 0.6 },
  // Baidu Wenxin
  'wenxin': { input: 12, output: 12 },
  'ernie-4': { input: 120, output: 120 },
  'ernie-3.5': { input: 4, output: 8 },
  // MiniMax
  'minimax-abab6': { input: 2, output: 2 },
  'minimax-abab6.5': { input: 1.5, output: 1.5 },
  // Mistral
  'mistral-small': { input: 0.2, output: 0.6 },
  'mistral-medium': { input: 2.7, output: 8.1 },
  'mistral-large': { input: 4, output: 12 },
  'mistral-large2': { input: 3, output: 9 },
  'mixtral-8x7b': { input: 0.7, output: 0.7 },
  'mixtral-8x22b': { input: 2, output: 2 },
  'codestral': { input: 0.2, output: 0.6 },
  'pixtral': { input: 0.2, output: 0.6 },
  // Cohere
  'command': { input: 1, output: 2 },
  'command-r': { input: 0.5, output: 1.5 },
  'command-r-plus': { input: 3, output: 15 },
  // 其他
  'phi-3-mini': { input: 0.1, output: 0.1 },
  'phi-4': { input: 0.1, output: 0.1 },
  'dbrx': { input: 2, output: 2 },
  'yi-large': { input: 20, output: 20 },
  'yi-medium': { input: 2.5, output: 2.5 },
  'yi-lightning': { input: 0.99, output: 0.99 },
  'hunyuan-lite': { input: 0.8, output: 0.8 },
  'hunyuan-standard': { input: 4, output: 12 },
  'internlm2-20b': { input: 1, output: 1 },
  'baichuan2-53b': { input: 2, output: 2 },
  'gpt-5.4-high (codex-harness)': { input: 15, output: 60 }
};

function fetch(url) {
  return new Promise((resolve, reject) => {
    https.get(url, {
      headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)' }
    }, (res) => {
      if (res.statusCode === 301 || res.statusCode === 302) {
        fetch(res.headers.location).then(resolve).catch(reject);
        return;
      }
      if (res.statusCode !== 200) {
        reject(new Error(`HTTP ${res.statusCode}`));
        return;
      }
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(data));
    }).on('error', reject);
  });
}

function getPrice(modelName) {
  if (PRICES[modelName]) return PRICES[modelName];
  const modelLower = modelName.toLowerCase();
  for (const [key, price] of Object.entries(PRICES)) {
    if (modelLower.includes(key.toLowerCase())) return price;
  }
  return null;
}

function isChinese(vendor) {
  return CHINESE_VENDORS.some(v => vendor.toLowerCase().includes(v.toLowerCase()));
}

async function main() {
  const workspace = process.argv[2] || '.';
  console.log('Workspace:', workspace);

  // 获取最新日期
  let date;
  try {
    const latestRaw = await fetch('https://raw.githubusercontent.com/oolong-tea-2026/arena-ai-leaderboards/main/data/latest.json');
    const latest = JSON.parse(latestRaw);
    date = latest.date;
    console.log('Latest data date:', date);
  } catch (e) {
    const today = new Date().toISOString().slice(0, 10);
    date = today;
    console.log('Using fallback date:', date);
  }

  const result = {
    date,
    fetchedAt: new Date().toISOString(),
    leaderboards: {}
  };

  // 抓取各榜单
  for (const cat of CATEGORIES) {
    const url = `https://raw.githubusercontent.com/oolong-tea-2026/arena-ai-leaderboards/main/data/${date}/${cat}.json`;
    console.log(`Fetching ${cat}...`);
    try {
      const raw = await fetch(url);
      const data = JSON.parse(raw);
      data.models = data.models.map(m => ({
        ...m,
        ch: isChinese(m.vendor),
        price: getPrice(m.model)
      }));
      result.leaderboards[cat] = data;
      console.log(`  ✓ ${cat}: ${data.models.length} models`);
    } catch (e) {
      console.log(`  ✗ ${cat}: ${e.message}`);
    }
  }

  // 提取中国模型（供中国模型榜单使用）
  const chineseModels = [];
  for (const [cat, data] of Object.entries(result.leaderboards)) {
    for (const m of data.models) {
      if (m.ch) {
        chineseModels.push({ ...m, category: cat });
      }
    }
  }
  const seen = new Set();
  result.chineseModels = chineseModels
    .sort((a, b) => b.score - a.score)
    .filter(m => {
      if (seen.has(m.model)) return false;
      seen.add(m.model);
      return true;
    });

  const outputPath = path.join(workspace, 'arena-data.json');
  fs.writeFileSync(outputPath, JSON.stringify(result, null, 2));
  console.log('\nSaved to:', outputPath);
  console.log('Categories:', Object.keys(result.leaderboards).join(', '));
  console.log('Chinese models:', result.chineseModels.length);
}

main().catch(e => {
  console.error('Error:', e.message);
  process.exit(1);
});