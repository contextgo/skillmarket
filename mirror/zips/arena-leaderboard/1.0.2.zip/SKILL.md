---
name: arena-leaderboard
description: |
  生成 Arena.ai AI模型榜单的交互式HTML页面。触发词：AI模型榜单、LMArena、模型排名、排行榜。
  支持10个细分榜单及中国模型汇总，数据来源 GitHub API 每日快照。
---

# Arena.ai 模型榜单生成器

生成交互式 HTML 榜单页面，展示 AI 模型排名。

## 触发条件

用户提及以下关键词时自动触发：
- "AI模型榜单"、"模型排名"、"排行榜"、"LMArena"、"Arena.ai"
- "Claude排名"、"GPT排名"、"GLM排名"、"看看榜单"

## 工作流程

### Step 1: 抓取数据

```bash
node SKILL_DIR/scripts/fetch-arena-data.js <workspace>
```

从 `oolong-tea-2026/arena-ai-leaderboards` 获取数据，输出 `arena-data.json`。

**备用方案**: 脚本失败时，用 Bash/curl 直接抓取：
- 最新日期: `https://raw.githubusercontent.com/oolong-tea-2026/arena-ai-leaderboards/main/data/latest.json`
- 榜单数据: `https://raw.githubusercontent.com/oolong-tea-2026/arena-ai-leaderboards/main/data/{date}/{category}.json`

### Step 2: 生成 HTML

```bash
node SKILL_DIR/scripts/generate-html.js <workspace>/arena-data.json <workspace>/arena-leaderboard.html
```

**备用方案**: 脚本失败时，参考 generate-html.js 中的 HTML 结构手动构建。

### Step 3: 展示页面

让用户在浏览器打开生成的 HTML 文件。

## 榜单分类

| Tab | 数据文件 | 说明 |
|-----|---------|------|
| Text | text.json | 文本对话 |
| Code | code.json | 代码编程 |
| Vision | vision.json | 视觉理解 |
| Search | search.json | 搜索增强 |
| Document | document.json | 文档处理 |
| Text→Image | text-to-image.json | 文生图 |
| Image Edit | image-edit.json | 图像编辑 |
| Text→Video | text-to-video.json | 文生视频 |
| Image→Video | image-to-video.json | 图生视频 |
| Video Edit | video-edit.json | 视频编辑 |
| 🇨🇳 中国 | 各榜单过滤 | 各榜单中国模型排名 |

## 中国模型识别

以下 vendor 为中国模型（`ch: true`）：
- Alibaba (通义千问), Bytedance (豆包), Z.ai (智谱), Moonshot (Kimi)
- Baidu (文心), MiniMax, DeepSeek, Xiaomi (MiMo)

**注意**: Anthropic、OpenAI、Google、xAI 等非中国厂商，不可标记 `ch: true`。

## 价格数据

主流模型 API 价格内置脚本中（$/百万token，输入/输出）。新模型可从 `https://llm-stats.com` 获取。

## HTML 页面特性

- 横向 Tab 切换展示10个细分榜单
- 中国模型按各细分榜单单独展示排名
- LobeHub 品牌彩色图标（PNG格式）
- Elo 评分颜色可视化
- API 价格显示
- 中国模型红色高亮 + 🇨🇳 标签
- 表格响应式布局

## 文件结构

```
arena-leaderboard/
├── SKILL.md
└── scripts/
    ├── fetch-arena-data.js
    └── generate-html.js
```

## 故障排查

- **404错误**: 日期可能滞后，脚本自动使用 latest.json 获取最新日期
- **Node脚本失败**: 用 Bash/curl 抓取数据，参考 generate-html.js 手动构建 HTML