# 微信公众号周报生成

## 描述

自动从微信公众号文章数据中筛选、抓取原文、精炼简介、生成排版精美的 HTML 周报。最终产出可从浏览器直接复制粘贴到微信公众号编辑器，标题超链接自动保留。

## 前置条件

- Python 3.8+
- `requests` 库
- 目录结构：工作目录下有 `sync_state.json`（wewe-rss 数据源）和 `gen_weekly_report.py`、`_gen_weekly_html.py` 两个脚本

## 执行步骤

### 步骤1：筛选文章 + 抓取原文

执行命令：
```bash
cd 工作目录
python gen_weekly_report.py --days 7
```

脚本自动完成：
1. 从 `sync_state.json` 按 `published_at` 筛选最近7天文章
2. 过滤广告标题（排除：报名/通知/预告/招募/招生/公告/活动概览/开课/全网首开/直播/黄页）
3. 抓取正文前200字，缓存到 `_body_cache.json`
4. 正文<30字的文章标记 `paywalled`
5. 按发布时间正序排列

输出：
- `周报/_raw_articles.json`：本周文章数据
- `周报/精神分析周报 · MM月DD日-MM月DD日.txt`：TXT骨架版（无简介）

### 步骤2：AI精炼简介

读取 `周报/_raw_articles.json`，基于每篇的 `body` 字段（正文前200字）精炼简介：
- 每篇30-40字，两句话，概括核心论点
- 必须基于原文，不凭标题编造
- 付费文章（`paywalled: true`）写"本文为付费内容，无法获取正文。"

生成带简介的 TXT 周报，覆盖步骤1的 TXT 文件。

**TXT格式要求**：
```
【文章标题】
来源：公众号名称
发布时间：MM-DD HH:MM
简介：30-40字的简介内容。
链接：https://mp.weixin.qq.com/s/xxxxx
```

### 步骤3：生成HTML周报

执行命令：
```bash
python _gen_weekly_html.py
```

脚本自动读取 `_raw_articles.json` 和最新 TXT 文件，生成排版精美的 HTML。

输出：`周报/精神分析周报 · MM月DD日-MM月DD日.html`

### 步骤4：发布到公众号

1. 浏览器打开 HTML 文件
2. 全选（Ctrl+A）→ 复制（Ctrl+C）
3. 粘贴到微信公众号编辑器
4. 标题超链接自动保留

## 关键规则

- 筛选用 `published_at`（真实发布时间），不用 `imported_at`
- UTC时间（带`.000Z`后缀）需+8小时转北京时间
- 简介匹配用URL，不要用标题（避免中英文引号差异）
- HTML是唯一可靠方案，Word格式有超链接分割问题

## token消耗

| 规模 | 总计 |
|------|------|
| 20篇 | ~7K |
| 50篇 | ~18K |
| 60篇 | ~22K |

分批建议：>50篇分2-3批处理。
