#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "tencentcloud-sdk-python-vclm>=3.0.0",
# ]
# ///
"""
Generate videos directly from text descriptions using Tencent HunyuanVideo 1.5.

Direct text-to-video pipeline (no intermediate image step):
  Text → Video  (HunyuanVideo: SubmitHunyuanToVideoJob)

SDK import notes (verified 2026-03-31):
  from tencentcloud.vclm.v20240523.vclm_client import VclmClient
  Client init: cred = credential.Credential(secret_id, secret_key)
               VclmClient(cred, region, profile)

API: SubmitHunyuanToVideoJob
  - Image parameter is OPTIONAL — pass Prompt only for T2V mode
  - Status codes: WAIT=waiting, RUN=running, FAIL=failed, DONE=done
  - Result: ResultVideoUrl (valid for 24 hours)

Usage:
    uv run generate.py --prompt "一只猫在草地上奔跑，写实风格"

    TENCENT_SECRET_ID=xxx TENCENT_SECRET_KEY=yyy \\
        uv run generate.py --prompt "..." --video-resolution 720p
"""

import argparse
import os
import sys
import time
from datetime import datetime
from pathlib import Path
from urllib.request import urlretrieve


# ─── Credentials ───────────────────────────────────────────────────────────────

def get_credentials(provided_id: str | None, provided_key: str | None) -> tuple[str, str]:
    """Get credentials from arguments first, then environment variables."""
    secret_id = provided_id or os.environ.get("TENCENT_SECRET_ID")
    secret_key = provided_key or os.environ.get("TENCENT_SECRET_KEY")

    if not secret_id or not secret_key:
        print("Error: Missing Tencent Cloud credentials.", file=sys.stderr)
        print("Please provide credentials via:", file=sys.stderr)
        print("  Option 1: --secret-id <ID> --secret-key <KEY>", file=sys.stderr)
        print("  Option 2: env vars TENCENT_SECRET_ID and TENCENT_SECRET_KEY", file=sys.stderr)
        sys.exit(1)

    return secret_id, secret_key


# ─── Hunyuan Video Generation ─────────────────────────────────────────────────
# API: SubmitHunyuanToVideoJob / DescribeHunyuanToVideoJob
# Status codes: WAIT=waiting, RUN=running, FAIL=failed, DONE=done

def submit_video_job(client, prompt: str, resolution: str, logo_add: int) -> str:
    """Submit text-to-video job and return JobId."""
    from tencentcloud.vclm.v20240523 import models

    req = models.SubmitHunyuanToVideoJobRequest()
    req.Prompt = prompt
    req.Resolution = resolution
    req.LogoAdd = logo_add
    # Image is intentionally omitted — this is pure T2V (text-to-video) mode

    resp = client.SubmitHunyuanToVideoJob(req)
    job_id = resp.JobId

    if not job_id:
        print("Error: No JobId returned from video API.", file=sys.stderr)
        sys.exit(1)

    return job_id


def query_video_job(client, job_id: str, retry: int = 3) -> dict:
    """Query video job status with retry on transient errors."""
    from tencentcloud.vclm.v20240523 import models
    from tencentcloud.common.exception.tencent_cloud_sdk_exception import TencentCloudSDKException

    for attempt in range(retry):
        try:
            req = models.DescribeHunyuanToVideoJobRequest()
            req.JobId = job_id
            resp = client.DescribeHunyuanToVideoJob(req)
            return {
                "status": resp.Status,
                "error_code": resp.ErrorCode or "",
                "error_message": resp.ErrorMessage or "",
                "result_video_url": resp.ResultVideoUrl or "",
            }
        except TencentCloudSDKException:
            if attempt < retry - 1:
                time.sleep(5)
            else:
                raise


def wait_for_video(client, job_id: str, max_wait: int = 360, poll_interval: int = 5) -> str:
    """Wait for video generation to complete and return result video URL."""
    elapsed = 0
    while elapsed < max_wait:
        time.sleep(poll_interval)
        elapsed += poll_interval

        result = query_video_job(client, job_id)
        status = result["status"]

        if status == "WAIT":
            if elapsed % 15 == 0:
                print(f"    [{elapsed}s] Waiting in queue...")
        elif status == "RUN":
            print(f"    [{elapsed}s] Generating video...")
        elif status == "FAIL":
            print(f"\n  Video generation FAILED.", file=sys.stderr)
            print(f"    Error: {result['error_code']} - {result['error_message']}", file=sys.stderr)
            sys.exit(1)
        elif status == "DONE":
            print(f"\n  Video generated in ~{elapsed}s")
            if not result["result_video_url"]:
                print("Error: No video URL in result.", file=sys.stderr)
                sys.exit(1)
            return result["result_video_url"]
        else:
            print(f"    [{elapsed}s] Unknown status: {status}")

    print(f"\n  Error: Video generation timed out after {max_wait}s.", file=sys.stderr)
    sys.exit(1)


def generate_video(client, prompt: str, output_path: Path,
                   video_resolution: str, logo_add: int) -> Path:
    """Generate a video from text prompt and save to file."""
    print(f"Generating video (HunyuanVideo 1.5, T2V mode)...")
    print(f"    Prompt: {prompt[:100]}{'...' if len(prompt) > 100 else ''}")
    print(f"    Resolution: {video_resolution}")
    print()

    job_id = submit_video_job(client, prompt, video_resolution, logo_add)
    print(f"  JobId: {job_id}")
    print()

    video_url = wait_for_video(client, job_id)

    print(f"  Downloading video...")
    urlretrieve(video_url, str(output_path))
    file_size = output_path.stat().st_size
    print(f"  Video saved: {output_path.resolve()} ({file_size / 1024 / 1024:.1f}MB)")
    print()

    return output_path


# ─── Main ─────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Generate videos directly from text using Tencent HunyuanVideo 1.5 (T2V)"
    )
    parser.add_argument("--prompt", "-p", required=True,
                        help="Text description for video content (max 200 UTF-8 chars)")
    parser.add_argument("--filename", "-f",
                        help="Output video filename (default: hunyuan-video-{timestamp}.mp4)")
    parser.add_argument("--video-resolution", default="720p",
                        choices=["720p"],
                        help="Video resolution (default: 720p, currently only 720p is supported)")
    parser.add_argument("--logo-add", type=int, choices=[0, 1], default=1,
                        help="Watermark: 0=off, 1=on (default)")
    parser.add_argument("--secret-id",
                        help="Tencent Cloud SecretId (or use env TENCENT_SECRET_ID)")
    parser.add_argument("--secret-key",
                        help="Tencent Cloud SecretKey (or use env TENCENT_SECRET_KEY)")

    args = parser.parse_args()

    # Prompt length check (API limit: 200 UTF-8 chars)
    prompt = args.prompt.strip()
    if len(prompt) > 200:
        print(f"Warning: Prompt is {len(prompt)} chars; truncating to 200.", file=sys.stderr)
        prompt = prompt[:200]

    # ── Credentials
    secret_id, secret_key = get_credentials(args.secret_id, args.secret_key)

    # ── SDK Imports & Client Setup
    # Verified import path (2026-03-31):
    #   VclmClient: tencentcloud.vclm.v20240523.vclm_client
    from tencentcloud.common import credential as cred_module
    from tencentcloud.common.profile.client_profile import ClientProfile
    from tencentcloud.common.profile.http_profile import HttpProfile
    from tencentcloud.vclm.v20240523.vclm_client import VclmClient

    cred = cred_module.Credential(secret_id, secret_key)

    http_profile = HttpProfile()
    http_profile.endpoint = "vclm.tencentcloudapi.com"
    client_profile = ClientProfile()
    client_profile.httpProfile = http_profile
    video_client = VclmClient(cred, "ap-guangzhou", client_profile)

    # ── Output path
    if args.filename:
        output_path = Path(args.filename)
    else:
        timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
        output_path = Path(f"hunyuan-video-{timestamp}.mp4")

    output_path.parent.mkdir(parents=True, exist_ok=True)

    # ── Generate video directly from text
    output_path = generate_video(
        video_client, prompt, output_path,
        args.video_resolution, args.logo_add
    )

    print("=" * 60)
    print(f"VIDEO_READY:{output_path.resolve()}")
    print("=" * 60)


if __name__ == "__main__":
    main()
