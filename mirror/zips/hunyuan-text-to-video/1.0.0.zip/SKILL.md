---
name: hunyuan-text-to-video
description: "基于腾讯云 HunyuanVideo 1.5 的直接文生视频工具，一句话生成视频，无需中间图片步骤"
description_en: "Direct text-to-video generation using Tencent HunyuanVideo 1.5 (no image intermediate)"
---

# 腾讯云混元文生视频

使用腾讯云**混元生视频**（`SubmitHunyuanToVideoJob`）API，直接将文字描述生成视频。  
基于 **HunyuanVideo 1.5** 模型，无需中间图片生成步骤。

## 前置要求

1. 在 [混元生视频控制台](https://console.cloud.tencent.com/vclm) 开通服务并领取免费额度或开启后付费
2. 获取腾讯云账号的 SecretId 和 SecretKey（[CAM 控制台](https://console.cloud.tencent.com/cam/capi)）

## 使用方法

运行脚本（使用绝对路径，不要 cd 到 skill 目录）：

```bash
# 基本用法：直接文生视频
uv run {baseDir}/scripts/generate.py --prompt "一只小狗在海边玩耍，写实摄影风格"

# 指定输出文件名
uv run {baseDir}/scripts/generate.py --prompt "..." --filename my-video.mp4

# 去掉水印
uv run {baseDir}/scripts/generate.py --prompt "..." --logo-add 0
```

凭据可以通过参数或环境变量传入：

```bash
TENCENT_SECRET_ID=xxx TENCENT_SECRET_KEY=yyy uv run {baseDir}/scripts/generate.py --prompt "..."
# 或
uv run {baseDir}/scripts/generate.py --prompt "..." --secret-id xxx --secret-key yyy
```

## 参数说明

| 参数 | 必填 | 说明 |
|------|------|------|
| `--prompt` / `-p` | 是 | 视频描述文本，最多 **200 个 UTF-8 字符**（超长自动截断） |
| `--filename` / `-f` | 否 | 输出视频文件名（默认：`hunyuan-video-{时间戳}.mp4`） |
| `--video-resolution` | 否 | 视频分辨率，目前仅支持 `720p`（默认） |
| `--logo-add` | 否 | 是否添加水印，`0`=不添加，`1`=添加（默认） |
| `--secret-id` | 否 | 腾讯云 SecretId（也可通过环境变量 `TENCENT_SECRET_ID` 设置） |
| `--secret-key` | 否 | 腾讯云 SecretKey（也可通过环境变量 `TENCENT_SECRET_KEY` 设置） |

## 环境变量

| 变量名 | 说明 |
|--------|------|
| `TENCENT_SECRET_ID` | 腾讯云 SecretId |
| `TENCENT_SECRET_KEY` | 腾讯云 SecretKey |

## 输出

- 生成的视频保存为 MP4 到**当前工作目录**，并打印 `VIDEO_READY:/path/to/file.mp4`
- **不要尝试读取视频文件内容**，直接告知用户保存路径，并调用 `open_result_view` 展示

## API 说明（2026-03-31 验证）

| 服务 | 提交接口 | 查询接口 | SDK 包 |
|------|---------|---------|--------|
| 混元生视频（HunyuanVideo 1.5） | `SubmitHunyuanToVideoJob` | `DescribeHunyuanToVideoJob` | `tencentcloud-sdk-python-vclm` |

- **Image 参数为可选**：不传 `Image` 时为纯 T2V（文生视频）模式
- **Client 导入**：`from tencentcloud.vclm.v20240523.vclm_client import VclmClient`
- **Client 初始化**：先创建 `cred = credential.Credential(secret_id, secret_key)`，再传入 `VclmClient(cred, "ap-guangzhou", profile)`
- **状态码**：`WAIT`=等待中，`RUN`=运行中，`FAIL`=失败，`DONE`=完成
- **结果字段**：`ResultVideoUrl`（URL 有效期 24 小时）
- **并发限制**：默认 1 个并发，需等上一个任务完成后再提交

## 推荐工作流程（Agent 使用）

1. 调用脚本提交生成任务，等待 `VIDEO_READY:` 输出
2. 调用 `open_result_view` 将视频展示给用户
