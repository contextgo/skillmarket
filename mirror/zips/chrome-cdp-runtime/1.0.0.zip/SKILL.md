# Display Name
Chrome CDP Runtime

# Slug
chrome-cdp-runtime

# Description
提供 Chrome CDP 运行时能力：检查 9222、接管已存在的 Chrome CDP 实例，或在已知 Chrome 可执行路径下启动 Chrome 调试实例，并执行基础页面连接与 tab 操作。

# When to use
当任务涉及以下场景时使用：

- Chrome CDP 调试
- 浏览器自动化前置环境准备
- 接管已有 9222 实例
- 启动 Chrome 调试实例
- 列出/选择浏览器 tab
- 通过 CDP 执行页面脚本

# Inputs
- chromeExecutablePath（可选）
- targetUrl（可选）
- userDataDir（可选）
- debugPort（可选，默认 9222）

# Skill Content
使用 Chrome CDP 作为浏览器自动化运行时基础能力。

核心职责：
- 检查 9222 是否可访问
- 接管已存在的 Chrome CDP 实例
- 如果明确提供了 Chrome 可执行路径，可按该路径启动 Chrome 调试实例
- 连接 tab，选择目标页面，执行基础页面脚本
- 为上层业务 skill 提供稳定浏览器运行环境

硬约束：
- 仅使用 Chrome CDP
- 仅使用调试端口 9222
- 不使用 Edge
- 不使用未明确授权的浏览器替代方案
- 不因“其他浏览器也能调试”而自行切换测试介质

路径约束：
- 如果仅接管已存在的 Chrome CDP 实例，不要求提供 Chrome 可执行路径
- 如果需要自动启动 Chrome，必须提供已确认的 Chrome 可执行路径
- 如果 Chrome 路径未知、Chrome 未安装、或 9222 未监听，则只能报告环境不满足

执行流程：
1. 检查 9222 是否已监听
2. 如果已监听，优先接管已有 Chrome CDP 实例
3. 如果未监听且提供了 Chrome 路径，则按该路径启动 Chrome，并开启 9222
4. 如果未监听且未提供 Chrome 路径，则报告环境不满足
5. 连接 CDP，列出 tab，选择目标 tab
6. 提供基础页面读取、导航和脚本执行能力

禁止事项：
- 不要硬编码 Chrome 路径
- 不要自动切换到其他浏览器
- 不要在路径未知时假设系统里一定有 Chrome
- 不要在未授权时自行扩展为“任何可调试浏览器都可以”

完成标准：
- 成功接管或启动 Chrome CDP
- 9222 可访问
- 能够列出并连接目标 tab
- 能执行基础页面操作

# Must Do
- 优先检查 9222
- 优先接管已存在的 Chrome CDP 实例
- 自动启动 Chrome 时必须使用已确认路径
- 无法满足环境约束时明确报告阻塞原因

# Must Not Do
- 不要切换到 Edge
- 不要切换到其他浏览器
- 不要硬编码 Chrome 路径
- 不要在路径未知时自行猜路径

# Acceptance Criteria
- 9222 可访问
- Chrome CDP 可连接
- 目标 tab 可读取或操作
- 运行时环境满足上层业务 skill 调用条件
