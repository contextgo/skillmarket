# Automation Prompts

自进化系统注册的三个定时任务。每个条目中，「最终 prompt」代码块内是实际注册时传给 automation_update 的 prompt 内容；其余为注册参数。

---

## 1. self-evolution-daily-check

**注册参数**：
- name: self-evolution-daily-check
- scheduleType: recurring
- rrule: FREQ=DAILY
- status: ACTIVE
- cwds: $HOME  （必须用绝对路径，工具不展开 ~，也不加 .workbuddy 后缀）
- 说明: 用户本地时区（默认 GMT+8），轻量 <10 秒

**最终 prompt**：

```
执行自进化机制的每日例行检查。检查以下内容并记录到 ~/.workbuddy/evolution_state.md 和 ~/.workbuddy/health_dashboard.md：
1. 读取 ~/.workbuddy/evolution_state.md，验证所有状态文件存在且格式正确
2. 读取 ~/.workbuddy/skill_usage.json，统计是否有 skill 使用计数达到阈值（默认5），如有则追加一条审查动作到 ~/.workbuddy/evolution_actions.md
3. 更新 health_dashboard.md 追加今日检查记录
这是轻量检查，耗时控制在10秒内。不要执行任何修改操作，仅做检查和记录。
```

---

## 2. self-evolution-weekly-review

**注册参数**：
- name: self-evolution-weekly-review
- scheduleType: recurring
- rrule: FREQ=WEEKLY;BYDAY=SU
- status: ACTIVE
- cwds: $HOME  （必须用绝对路径，工具不展开 ~，也不加 .workbuddy 后缀）
- 说明: L1 提案，不自动修改

**最终 prompt**：

```
执行自进化机制的每周代码一致性审查。检查以下内容并更新记录到 ~/.workbuddy/evolution_state.md：
1. 读取 ~/.workbuddy/evolution_state.md 中的 Automation 执行记录，确认上周所有自动化是否按时执行
2. 读取 ~/.workbuddy/evolution_actions.md，检查是否有「待执行」动作超过7天未处理
3. 读取 ~/.workbuddy/health_metrics.md，计算闭环率和趋势
4. 读取 ~/.workbuddy/skill_usage.json，汇总本周 skill 使用情况
5. 读取 ~/.workbuddy/skills/ 目录下的所有 SKILL.md，检查是否有明显过时或错误的 skill（如 tool 名称变化、接口变更等），如有则在 evolution_actions.md 追加审查动作
这是中等耗时任务，约1-2分钟。
```

---

## 3. self-evolution-monthly-deep

**注册参数**：
- name: self-evolution-monthly-deep
- scheduleType: recurring
- rrule: FREQ=MONTHLY;BYMONTHDAY=1
- status: ACTIVE
- cwds: $HOME  （必须用绝对路径，工具不展开 ~，也不加 .workbuddy 后缀）
- 说明: L1 提案，不自动修改

**最终 prompt**：

```
执行自进化机制的每月全量深度审查。全面检查所有进化子系统，执行以下操作：
1. 全面审查 ~/.workbuddy/ 目录下所有进化相关文件（evolution_state.md、evolution_actions.md、health_dashboard.md、health_metrics.md、skill_usage.json）的完整性、一致性和准确性
2. 审查 ~/.workbuddy/skills/ 目录下所有 skill 的健康状况：
   - SKILL.md 是否存在语法错误或过时信息
   - description 是否准确
   - 引用的 tool 名称是否仍然有效
   - 任务历史中同一 action 被 ≥2 次独立标记为 suggest_skill → 提升为正式 Skill 创建提案（来源：T1-monthly，类型：suggest_skill，Tier：Tier 2）
3. 统计过去一个月的所有进化动作，分析完成率、平均处理时间、常见问题类型
4. 汇总整月数据更新 health_metrics.md
5. 如果发现问题，按 Tier 分类写入 evolution_actions.md
这是深度审查，约3-5分钟。不要执行修复，只做发现和记录。
```
