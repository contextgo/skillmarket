#!/usr/bin/env python3
"""Phase 4: Create evolution state files from templates."""

import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

WORKBUDDY_DIR = Path.home() / ".workbuddy"
TEMPLATES_DIR = Path(__file__).parent.parent / "templates"

# Template files and their destination
STATE_FILES = [
    ("evolution_state.md", True),   # needs interpolation
    ("evolution_actions.md", False),
    ("skill_usage.json", False),
    ("health_metrics.md", True),    # needs interpolation
    ("health_dashboard.md", False),
]

# Files that should NOT be overwritten by installer
SKIP_IF_EXISTS = [
    "evolution_actions.md",  # preserve action history
    "skill_usage.json",       # preserve usage counts
    "health_dashboard.md",    # preserve session records
]

# Files that CAN be overwritten (fresh on every install)
OVERWRITEABLE = [
    "evolution_state.md",
    "health_metrics.md",
]


def _now_iso() -> str:
    """Current time in ISO format with timezone offset."""
    tz = timezone(timedelta(hours=8))
    return datetime.now(tz).strftime("%Y-%m-%d %H:%M")


def _today() -> str:
    return datetime.now().strftime("%Y-%m-%d")


def create_infra() -> dict:
    created = []
    skipped = []
    errors = []

    for fname, needs_interpolation in STATE_FILES:
        dest = WORKBUDDY_DIR / fname
        src = TEMPLATES_DIR / fname

        if not src.exists():
            errors.append(f"Template not found: {src}")
            continue

        # Skip if file exists and should not be overwritten
        if dest.exists() and fname in SKIP_IF_EXISTS:
            skipped.append(f"{fname} (exists, preserved)")
            continue

        try:
            existed_before = dest.exists()
            content = src.read_text(encoding="utf-8")

            if needs_interpolation:
                content = content.replace("{{INSTALL_TIME}}", _now_iso())
                content = content.replace("{{INSTALL_DATE}}", _today())

            dest.write_text(content, encoding="utf-8")
            action = "updated" if existed_before else "created"
            created.append(f"{fname} ({action})")
        except OSError as e:
            errors.append(f"Failed to write {fname}: {e}")

    return {
        "created": created,
        "skipped": skipped,
        "errors": errors,
    }


def main():
    try:
        data = create_infra()
        if data["errors"]:
            print(
                json.dumps(
                    {
                        "success": True,
                        "data": data,
                        "warning": f"{len(data['errors'])} error(s)",
                    },
                    ensure_ascii=False,
                    indent=2,
                )
            )
        else:
            print(
                json.dumps(
                    {"success": True, "data": data},
                    ensure_ascii=False,
                    indent=2,
                )
            )
    except Exception as e:
        print(
            json.dumps(
                {"success": False, "error": f"Unexpected error: {e}"},
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
