# Changelog — self-evolution-installer

## [1.1.0] - 2026-05-02

### Added
- **新增 Phase 5.5：用户配置环节**（共同进化关键）。安装后引导用户选择自主权级别（L1/L2）和 T3 使用驱动（开/关），写入 evolution_state.md。
- **创建 SPEC.md**：功能规格说明书（v1.1.0），定义 7 阶段流程、输入输出、成功标准、降级策略。

### Updated
- **更新 references/design.md 至 v1.1.0**：新增 ADR-010（Phase 5.5 用户配置）、更新 ADR-004（L1 改为用户可选默认值）、模块关系图/数据流图加入 Phase 5.5。
- **更新 references/automation-prompts.md**：3 个自动化 prompt 替换为实际注册时使用的更具体版本（带结构化检查步骤和结果记录）。
- **更新 SKILL.md**：执行前确认的计划描述从 6 阶段更新为 7 阶段。

### Fixed
- **DESIGN.md 位置修正**：从 `references/design.md` 移至根目录 `DESIGN.md`，符合三文件追溯规范。
- **Phase 5 cwds 错误**：修正为 `$HOME`（绝对路径），去掉 `.workbuddy/` 后缀和波浪号描述。
- **Phase 4 health_dashboard 初始化**：安装完成后写入首行记录，避免空表。
- **SKILL.md 阶段计数修正**：从 6 阶段改为 7 阶段，与新增的 Phase 5.5 对应。

## [1.0.0] - 2026-05-01

### Added
- 完整的 6 阶段安装流程：审计 → Bootstrap → SOUL注入 → 状态文件 → Automation → 验证
- 4 个 Python 脚本：audit.py, fix_layer0.py, inject_evolution.py, create_infra.py
- 6 个模板文件：evolution_section.md（SOUL.md 注入段）、evolution_state.md、evolution_actions.md、skill_usage.json、health_metrics.md、health_dashboard.md
- 3 个 Automation prompt（references/automation-prompts.md）：daily-check、weekly-review、monthly-deep
- 默认自主权 L1、workspace 级记忆、两档 Automation 兜底策略
