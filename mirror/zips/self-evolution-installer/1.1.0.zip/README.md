# Self-Evolution Installer

> [English](#self-evolution-installer) | [中文](#self-evolution-installer-1)

> ⚠️ **WorkBuddy only.** This skill relies on WorkBuddy-specific mechanisms (SOUL.md injection, automation_update tool). It will NOT work on OpenClaw or other non-WorkBuddy platforms.
>
> ⚠️ **仅限 WorkBuddy。** 本 Skill 深度依赖 WorkBuddy 专有机制（SOUL.md 注入、automation_update 工具），**不能**在 OpenClaw 或其他非 WorkBuddy 平台使用。

> **Give your WorkBuddy the ability to learn.** Install in one command. Your agent starts improving itself — automatically discovering issues, tracking improvements, and compounding knowledge across sessions.

---

## Overview

Self-Evolution Installer is a WorkBuddy skill that installs a complete self-evolution mechanism onto any WorkBuddy agent. Once installed, the agent gains:

- **24/7 Auto Inspection** — Daily syntax checks, weekly documentation-code consistency audits, monthly deep analysis
- **Smart Defect Capture** — Automatically records issues when tasks error, fail repeatedly, or you correct course
- **Cross-Session Memory** — 5 state files survive between sessions; all pending improvements and actions persist
- **Graduated Autonomy** — L0 observe / L1 propose (default) / L2 auto-fix, you stay in control
- **Pattern Awareness** ★ — Tracks your task history across sessions; proactively suggests creating a new Skill when the same operation repeats 3+ times in 30 days
- **One-Click Portable** — Zero external dependencies. Copy the skill directory to any WorkBuddy agent and install.

### How It Works

```
Install (6 phases, < 2 min) → Next session, agent auto-loads evolution code
→ Daily: syntax check  →  Weekly: health audit  →  Monthly: deep analysis + pattern mining
→ Session start: 8-step self-check + task pattern scan
→ Task complete: auto-log + friction detection
```

### Quick Install

Just say to your WorkBuddy:

```
安装自进化
```

The skill auto-loads, runs 6 phases, and takes effect from the next session.

### Requirements

- WorkBuddy agent (any version)
- Python 3 (standard library only, zero pip dependencies)

### File Structure

```
self-evolution-installer/
├── SKILL.md              # Entry point — 6-phase installation guide
├── CHANGELOG.md
├── DESIGN.md             # Architecture Decision Records (ADR)
├── SPEC.md
├── README.md
├── scripts/
│   ├── audit.py          # Phase 1: environment audit
│   ├── fix_layer0.py     # Phase 2: bootstrap handling
│   ├── inject_evolution.py  # Phase 3: inject evolution code into SOUL.md
│   └── create_infra.py   # Phase 4: create 5 state files
├── templates/            # Phase 3-4 template files
│   ├── evolution_section.md  # SOUL.md injection content
│   ├── evolution_state.md
│   ├── evolution_actions.md
│   ├── skill_usage.json
│   ├── health_metrics.md
│   └── health_dashboard.md
└── references/
    └── automation-prompts.md  # 3 automation prompts
```

### State Files

All located under `~/.workbuddy/`:

| File | Purpose |
|------|---------|
| `evolution_state.md` | Configuration + skill review status |
| `evolution_actions.md` | Single action queue + task history (JSONL) |
| `skill_usage.json` | Usage counts per skill |
| `health_metrics.md` | Health score trends |
| `health_dashboard.md` | Session log (last 100 entries) |

### Changelog

See [CHANGELOG.md](CHANGELOG.md)

### License

MIT-0 (No attribution required)

---

# Self-Evolution Installer

> **让 WorkBuddy 拥有自进化能力。** 一行指令安装，你的 Agent 从此学会自主学习、自动发现缺陷、并在会话间累积改进经验。

---

## 概述

Self-Evolution Installer 是一个 WorkBuddy Skill，能在任何 WorkBuddy Agent 上安装完整的自进化机制。安装后 agent 具备以下能力：

- **24/7 自动巡检** — 每日语法检查、每周文档代码一致性审计、每月深度分析
- **智能缺陷捕获** — 任务出错、连续失败、你纠正方向时自动记录问题
- **跨会话记忆** — 5 个状态文件持久保存，未完成的改进和待确认动作跨 session 加载
- **分级自主权** — L0 观察 / L1 提案（默认）/ L2 自动修复，你始终在控制位
- **模式感知 ★** — 追踪跨会话任务历史，同一操作 30 天内出现 3 次以上，主动提议生成新的 Skill
- **一键移植** — 零外部依赖，复制到任何 WorkBuddy Agent 即可安装

### 工作原理

```
安装（6 阶段，< 2 分钟）→ 下次会话自动加载进化代码
→ 每日：语法检查  →  每周：健康审计  →  每月：深度分析 + 模式挖掘
→ 会话启动：8 步自检 + 任务模式扫描
→ 任务完成：自动记录 + 摩擦检测
```

### 快速安装

对你的 WorkBuddy 说：

```
安装自进化
```

Skill 自动加载，6 阶段全自动安装，下次会话即时生效。

### 环境要求

- WorkBuddy Agent（任意版本）
- Python 3（仅使用标准库，零 pip 依赖）

### 文件结构

同上英文部分

### 状态文件

位于 `~/.workbuddy/` 下：

| 文件 | 用途 |
|------|------|
| `evolution_state.md` | 配置 + 审查状态 |
| `evolution_actions.md` | 动作队列 + 任务历史（JSONL） |
| `skill_usage.json` | 各 Skill 使用计数 |
| `health_metrics.md` | 健康分趋势 |
| `health_dashboard.md` | 会话日志（近 100 条） |

### 更新日志

详见 [CHANGELOG.md](CHANGELOG.md)

### 许可协议

MIT-0（无需署名）
