--- 
name: self-evolution-installer
version: "1.1.0"
description: |
  （仅限 WorkBuddy）在 WorkBuddy agent 上安装自进化能力。一键执行，安装后 agent 自动具备：
  定时巡检、状态持久化、自主分级改进。零外部依赖，可移植到任何 WorkBuddy agent。
  请勿在 OpenClaw 或其他非 WorkBuddy 工具中使用。
  触发词：安装自进化、setup evolution、init self-evolution、装进化模块、
  安装进化引擎、enable self evolution
triggers:
  - 安装自进化
  - setup evolution
  - init self-evolution
  - 装进化模块
  - 安装进化引擎
  - enable self evolution
token_budget:
  L0_trigger: 100
  L1_core: 2000
  L2_deep: 5000
  hard_cap: 8000
--- 

# Self-Evolution Installer

在 WorkBuddy agent 上安装自进化能力。7 个阶段顺序执行，断点续装。

## 执行前确认

**先议后行**：在开始任何修改之前，先向用户呈报以下计划，确认后再动手：

> 我将为你的 WorkBuddy 安装自进化能力。过程分 7 个阶段：
> 1. 审计环境
> 2. 处理 Bootstrap 状态
> 3. 注入 SOUL.md 进化代码
> 4. 创建 5 个状态文件
> 5. 注册 3 个定时 Automation
> 6. 配置自主权级别（与你讨论共同进化的方式）
> 7. 验证安装
>
> 预计 < 2 分钟。确定要开始吗？

用户确认后按以下流程执行。每个阶段先读上一个阶段的输出 JSON，再做本阶段操作。

---

## Phase 1: 审计环境

执行：
```bash
python3 ~/.workbuddy/skills/self-evolution-installer/scripts/audit.py
```

解读输出：
- 如果 `phases_completed` 包含已完成阶段编号，跳过对应阶段
- **如果 `phases_completed == [1,2,3,4,5,6]`（全部完成）**：直接输出「自进化系统已安装，无需重复」，结束
- 如果 `soul_md_has_evolution == true`，Phase 3 时走「替换」而非「追加」
- 记录 `bootstrap_exists` 供 Phase 2 使用

---

## Phase 2: Bootstrap 处理

执行：
```bash
python3 ~/.workbuddy/skills/self-evolution-installer/scripts/fix_layer0.py
```

解读输出：
- 如果 `bootstrap_needed == true`：**暂停安装**，引导用户完成 Bootstrap 对话（确定名字/人格/城市/职业）。完成后删除 BOOTSTRAP.md，回到 Phase 2 重新检测。
- 如果 `bootstrap_handled == true` 且 `bootstrap_deleted == true`：继续。
- 如果 `bootstrap_handled == true` 且 `bootstrap_deleted == false` 且 `bootstrap_needed == false`：已经是正常状态，继续。

Bootstrap 对话指南：不要审问式，像聊天一样自然。问：称呼、AI 名字、AI 风格、用户城市、日常做什么。更新 SOUL.md / IDENTITY.md / USER.md 后删 BOOTSTRAP.md。

---

## Phase 3: 注入 SOUL.md 进化代码

执行：
```bash
python3 ~/.workbuddy/skills/self-evolution-installer/scripts/inject_evolution.py
```

解读输出：
- `action == "appended"`：首次注入
- `action == "replaced"`：覆盖已有标记段
- `backup_created == true`：SOUL.md.bak 已生成
- 失败则停止，报错

---

## Phase 4: 创建状态文件

执行：
```bash
python3 ~/.workbuddy/skills/self-evolution-installer/scripts/create_infra.py
```

解读输出：
- `created` 列表显示已创建/更新的文件
- `skipped` 列表显示被保留的已有文件（evolution_actions.md、skill_usage.json 等不会被覆盖）
- 如果 health_dashboard.md 在 created 列表中或为空，写入一条初始记录：
  ```
  | {安装时间} | ✅ | - | - | ❌ 不存在 | ⚠️ 待首次执行 |
  ```

---

## Phase 5: 注册 Automations

**先探测**：确认当前会话中 `automation_update` 工具是否可用。搜索当前可用工具列表。

如果不可用：跳过本阶段，输出警告：

> ⚠️ automation_update 工具不可用，3 个 Automation 未注册。  
> 安装视为部分成功。会话启动时的兜底检查仍能覆盖定时任务功能。  
> 完整的 Automation prompt 见 `~/.workbuddy/skills/self-evolution-installer/references/automation-prompts.md`

如果可用：读取 `references/automation-prompts.md`，对每个 Automation 条目：
1. 先 `automation_update mode=view` 检查是否已存在
2. 不存在则 `automation_update mode=suggested create`：从条目的「注册参数」取 name/scheduleType/rrule/status/cwds，从「prompt」代码块取 prompt 内容
3. 确认每个注册后状态为 ACTIVE

三个 Automation：
1. `self-evolution-daily-check` — DAILY;BYHOUR=3（本地时区 GMT+8）
2. `self-evolution-weekly-review` — WEEKLY;BYDAY=SU;BYHOUR=4
3. `self-evolution-monthly-deep` — MONTHLY;BYMONTHDAY=1;BYHOUR=5

注册参数均为 `scheduleType=recurring`，`status=ACTIVE`。  
**cwds 必填且必须用绝对路径**：先执行 `echo $HOME` 获取用户 home 目录，传入 `$HOME`（不含子路径）。不要用 `~`——该工具不会展开波浪号，也不要加 `.workbuddy/` 后缀。  
**prompt 参数内容**：从 `references/automation-prompts.md` 中该条目的「最终 prompt」代码块取。

---

## Phase 5.5: 用户配置（共同进化关键）

> **新增阶段**：安装完成后引导用户选择配置。此阶段关乎 agent 是否真正能与你共同成长。

**先读取当前 evolution_state.md 的配置**（如果是首次安装，值为 L1/关闭）：

向用户呈报以下选项（使用 AskUserQuestion 让用户选择）：

### 选项 A：自主权级别

| 级别 | 含义 |
|------|------|
| **L1（提案制）** | 我发现问题后只提案，等你确认才执行。最安全，进化慢。 |
| **L2（部分自主）** | P3 级低风险问题（语法错误、skill 优化、小 bug）我自动修复并记录。P1/P2 仍提案。进化更快，风险可控。 |

### 选项 B：T3 使用驱动

| 状态 | 含义 |
|------|------|
| **关闭** | 进化仅靠定时审查驱动，不参考使用数据。 |
| **开启** | 基于实际使用数据（skill 调用频率、错误模式、重复操作）驱动进化。用得越多，进化越精准。 |

用户确认后，写入 `~/.workbuddy/evolution_state.md`：
- `- 自主权级别：{L1|L2}`
- `- T3 使用驱动：{关闭|开启}`

---

## Phase 6: 验证 + 报告

逐项检查，生成最终报告：

```bash
# 1. SOUL.md 含进化标记段
grep -c "<!-- EVOLUTION_SECTION_START -->" ~/.workbuddy/SOUL.md

# 2. 5 个状态文件存在且非空
for f in evolution_state.md evolution_actions.md skill_usage.json health_metrics.md health_dashboard.md; do
  echo "$f: $(wc -c < "${HOME}/.workbuddy/${f}" 2>/dev/null || echo 0)"
done
```

如果 Phase 5 执行了，用 `automation_update mode=view` 检查 3 个 Automation 的状态。

输出最终安装报告：

```
✅ 安装完成

| 阶段 | 状态 |
|------|------|
| 1. 审计 | ✅ |
| 2. Bootstrap | ✅ | 
| 3. SOUL注入 | ✅ |
| 4. 状态文件 | ✅ (x created, y skipped) |
| 5. Automation | ✅ / ⚠️ 部分 |
| 6. 配置 | ✅ |
| 7. 验证 | ✅ |

下次会话启动时，agent 将自动加载自进化能力。
第一个自动化预计在北京时间凌晨 3:00 触发。
```

---

## 参考资料

安装后在需要时加载：
- `references/automation-prompts.md` — 3 个 Automation 的完整 prompt
- `DESIGN.md` — 架构决策文档（ADR）
