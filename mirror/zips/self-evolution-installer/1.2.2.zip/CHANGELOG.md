# Changelog — self-evolution-installer

## [1.2.2] - 2026-05-03

### Added
- **EVOLUTION_SECTION「时间线记录检查」（自进化v1.2.2）**：修改 skill 后自动检查 skill_timeline.md 是否有当天对应条目，缺失则静默追加。与版本变更检测同一触发条件，自动兜底避免遗漏。
- **EVOLUTION_SECTION「进化系统自检」**：每周周检时对进化系统做交叉验证（skill 列表漂移、action 统计一致性、automation 存活、EVOLUTION_SECTION 完整性）。发现问题写入 evolution_actions.md（P2，类型：self_check），只读不修复。
- **「信条自执行」根信条新增修复方向**：默认「把原则变成自动化兜底」，无法自动化的显式标记为「待自动化」。

### Changed
- **templates/evolution_section.md 版本升级至 v1.2.2**：新增时间线检查 + 自检节 + 状态表补 skill_timeline.md
- **templates/evolution_state.md 安装器+进化代码版本更新为 v1.2.2**
- **references/automation-prompts.md**：周检 prompt 新增第 6 步（进化系统自检）
- **automation 实际 prompt 同步更新**：daily/weekly/monthly 三个运行中的 automation prompt 均已更新

### Fixed
- **机制漏洞：改完 skill 后可能遗漏 skill_timeline.md 更新**。根本原因是「行动即记录」是原则而非检查点，版本变更检测条件分支中没有兜底。新增时间线记录检查后，每次改 skill 自动补录。

## [1.2.1] - 2026-05-02

### Added
- **EVOLUTION_SECTION 「版本变更检测」(自进化v1.2.1)**：每次完成任务后自动检测是否修改了 skill 文件，如修改则比对 SKILL.md 版本与 CHANGELOG/SPEC/DESIGN 版本一致。不一致时写入 evolution_actions.md（P2，来源 T2-session）。将 SCK 的 verify.py 版本检查能力接入进化引擎的后任务触发链。

### Changed
- **templates/evolution_section.md 版本升级至 v1.2.1**
- **evolution_state.md 安装器+进化代码版本更新为 v1.2.1**

## [1.2.0] - 2026-05-02

### Added
- **EVOLUTION_SECTION 新增步骤 9：skills/ 目录当日变更扫描**（自进化 v1.2.0）。会话启动时自动扫描 skills/ 目录当日修改文件，确保跨会话感知 skill 新建/更新。修复觉者指出的一处盲区。
- **templates/evolution_section.md 版本升级至 v1.2.0**：新增 step 9 及说明

### Changed
- **evolution_state.md 进化代码版本更新为 v1.2.0**

## [1.1.2] - 2026-05-02

### Changed
- **INTRO.md 合并至 README.md，删除 INTRO.md**：将 INTRO.md 的独有内容（技术架构五层模型、FAQ、问题驱动叙事、安装前后对比）合并到 README.md，删除英文部分，使 README.md 成为单一中文文档。解决两文件 50%+ 内容重叠问题。

## [1.1.1] - 2026-05-02

### Fixed
- **README.md 阶段数修正**：所有「6 阶段」引用更新为「7 阶段」（5 处），与 SKILL.md 的 7 阶段流程保持一致。
- **CHANGELOG.md 路径修正**：`references/design.md` 更新为 `DESIGN.md`，反映文件已移至根目录。
- **templates/evolution_state.md 版本号更新**：安装器版本和进化代码版本从 `v1.0` 更新为 `v1.1.1`，进度说明包含 Phase 5.5。
- **templates/evolution_section.md 版本号更新**：注入代码版本从 `v1.0` 更新为 `v1.1.1`。
- **DESIGN.md 版本历史格式统一**：`1.1` 格式统一为 `1.1.0`。

## [1.1.0] - 2026-05-02

### Added
- **新增 Phase 5.5：用户配置环节**（共同进化关键）。安装后引导用户选择自主权级别（L1/L2）和 T3 使用驱动（开/关），写入 evolution_state.md。
- **创建 SPEC.md**：功能规格说明书（v1.1.0），定义 7 阶段流程、输入输出、成功标准、降级策略。

### Updated
- **更新 DESIGN.md 至 v1.1.0**：新增 ADR-010（Phase 5.5 用户配置）、更新 ADR-004（L1 改为用户可选默认值）、模块关系图/数据流图加入 Phase 5.5。
- **更新 references/automation-prompts.md**：3 个自动化 prompt 替换为实际注册时使用的更具体版本（带结构化检查步骤和结果记录）。
- **更新 SKILL.md**：执行前确认的计划描述从 6 阶段更新为 7 阶段。

### Fixed
- **DESIGN.md 位置修正**：从 `references/design.md` 移至根目录 `DESIGN.md`，符合三文件追溯规范。
- **Phase 5 cwds 错误**：修正为 `$HOME`（绝对路径），去掉 `.workbuddy/` 后缀和波浪号描述。
- **Phase 4 health_dashboard 初始化**：安装完成后写入首行记录，避免空表。
- **SKILL.md 阶段计数修正**：从 6 阶段改为 7 阶段，与新增的 Phase 5.5 对应。

## [1.0.0] - 2026-05-01

### Added
- 完整的 6 阶段安装流程：审计 → Bootstrap → SOUL注入 → 状态文件 → Automation → 验证
- 4 个 Python 脚本：audit.py, fix_layer0.py, inject_evolution.py, create_infra.py
- 6 个模板文件：evolution_section.md（SOUL.md 注入段）、evolution_state.md、evolution_actions.md、skill_usage.json、health_metrics.md、health_dashboard.md
- 3 个 Automation prompt（references/automation-prompts.md）：daily-check、weekly-review、monthly-deep
- 默认自主权 L1、workspace 级记忆、两档 Automation 兜底策略
