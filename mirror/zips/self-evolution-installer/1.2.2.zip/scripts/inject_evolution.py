#!/usr/bin/env python3
"""Phase 3: Inject evolution code section into SOUL.md."""

import json
import sys
from pathlib import Path

WORKBUDDY_DIR = Path.home() / ".workbuddy"
SOUL_MD = WORKBUDDY_DIR / "SOUL.md"
TEMPLATES_DIR = Path(__file__).parent.parent / "templates"
EVOLUTION_TEMPLATE = TEMPLATES_DIR / "evolution_section.md"

START_MARKER = "<!-- EVOLUTION_SECTION_START -->"
END_MARKER = "<!-- EVOLUTION_SECTION_END -->"


def inject() -> dict:
    result = {
        "action": "unknown",
        "marker_found": False,
        "backup_created": False,
    }

    # Validate prerequisites
    if not SOUL_MD.exists():
        return {
            "success": False,
            "error": f"SOUL.md not found at {SOUL_MD}",
        }
    if not EVOLUTION_TEMPLATE.exists():
        return {
            "success": False,
            "error": f"Evolution template not found at {EVOLUTION_TEMPLATE}",
        }

    # Read SOUL.md
    try:
        soul_content = SOUL_MD.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        # Try common encodings
        try:
            raw = SOUL_MD.read_bytes()
            for enc in ["utf-8", "utf-16", "gbk", "gb18030"]:
                try:
                    soul_content = raw.decode(enc)
                    break
                except (UnicodeDecodeError, LookupError):
                    continue
            else:
                return {
                    "success": False,
                    "error": f"Cannot decode {SOUL_MD}: unknown encoding",
                }
        except OSError as e:
            return {
                "success": False,
                "error": f"Cannot read {SOUL_MD}: {e}",
            }

    except OSError as e:
        return {
            "success": False,
            "error": f"Cannot read {SOUL_MD}: {e}",
        }

    # Read evolution template
    try:
        evolution_content = EVOLUTION_TEMPLATE.read_text(encoding="utf-8")
    except OSError as e:
        return {
            "success": False,
            "error": f"Cannot read evolution template: {e}",
        }

    # Check marker integrity
    has_start = START_MARKER in soul_content
    has_end = END_MARKER in soul_content
    markers_in_template_start = START_MARKER in evolution_content
    markers_in_template_end = END_MARKER in evolution_content

    if has_start != has_end:
        return {
            "success": False,
            "error": (
                f"SOUL.md has corrupted evolution markers: "
                f"START={has_start}, END={has_end}. "
                f"Please fix manually before retrying."
            ),
        }

    if not markers_in_template_start or not markers_in_template_end:
        return {
            "success": False,
            "error": "Evolution template missing required markers.",
        }

    # Create backup before modifying
    backup_path = SOUL_MD.with_suffix(".md.bak")
    try:
        backup_path.write_text(soul_content, encoding="utf-8")
        result["backup_created"] = True
    except OSError:
        # Non-critical: proceed without backup
        pass

    # Inject or replace
    if has_start and has_end:
        # Replace existing evolution section
        start_idx = soul_content.index(START_MARKER)
        end_idx = soul_content.index(END_MARKER) + len(END_MARKER)
        new_content = (
            soul_content[:start_idx]
            + evolution_content.strip()
            + "\n"
            + soul_content[end_idx:]
        )
        result["action"] = "replaced"
        result["marker_found"] = True
    else:
        # Append evolution section at end
        new_content = soul_content.rstrip() + "\n\n" + evolution_content.strip() + "\n"
        result["action"] = "appended"
        result["marker_found"] = False

    # Write
    try:
        SOUL_MD.write_text(new_content, encoding="utf-8")
    except OSError as e:
        # Restore backup if write fails
        if result["backup_created"]:
            backup_path.rename(SOUL_MD)
        return {
            "success": False,
            "error": f"Cannot write {SOUL_MD}: {e}. Backup restored.",
        }

    return result


def main():
    try:
        data = inject()
        if "success" in data and not data["success"]:
            print(json.dumps(data, ensure_ascii=False, indent=2))
            sys.exit(1)
        print(
            json.dumps(
                {"success": True, "data": data},
                ensure_ascii=False,
                indent=2,
            )
        )
    except Exception as e:
        print(
            json.dumps(
                {"success": False, "error": f"Unexpected error: {e}"},
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
