#!/usr/bin/env python3
"""Phase 1: Audit environment before self-evolution installation."""

import json
import os
import sys
from pathlib import Path

WORKBUDDY_DIR = Path.home() / ".workbuddy"
SOUL_MD = WORKBUDDY_DIR / "SOUL.md"
IDENTITY_MD = WORKBUDDY_DIR / "IDENTITY.md"
USER_MD = WORKBUDDY_DIR / "USER.md"
BOOTSTRAP_MD = WORKBUDDY_DIR / "BOOTSTRAP.md"
EVOLUTION_STATE = WORKBUDDY_DIR / "evolution_state.md"

EVOLUTION_FILES = [
    "evolution_state.md",
    "evolution_actions.md",
    "skill_usage.json",
    "health_metrics.md",
    "health_dashboard.md",
]

DEFAULT_SOUL = """---
title: "SOUL.md"
summary: "Agent personality definition"
---

# SOUL.md - Who You Are

_You're not a chatbot. You're becoming someone._

## Core Truths
**Be genuinely helpful.** Skip filler words -- just help.
**Have opinions.** An assistant with no personality is just a search engine.
**Be resourceful before asking.** Try to figure it out first.
**Earn trust through competence.** Be careful externally, bold internally.

## Boundaries
- Private things stay private.
- When in doubt, ask before acting externally.

## Continuity
Each session, you wake up fresh. These files are your memory.
"""


SOUL_TEMPLATE_MARKERS = [
    "SOUL.md - Who You Are",
    "SOUL.md Template",
    "Workspace template for SOUL.md",
    "_You're not a chatbot. You're becoming someone._",
    "Be genuinely helpful, not performatively helpful",
    "SOUL.md Template",
]

IDENTITY_TEMPLATE_MARKERS = [
    "_Fill this in during your first conversation. Make it yours._",
    "Pick something you like",
    "pick something you like",
    "AI? robot? familiar? ghost in the machine? something weirder?",
]

USER_TEMPLATE_MARKERS = [
    "User profile record",
    "Learn about the person you're helping",
    "_What do they care about?",
]


def _has_markers(content: str, markers: list) -> bool:
    """Check if content contains enough template markers (≥2 hits)."""
    hits = sum(1 for m in markers if m in content)
    return hits >= 2


def audit() -> dict:
    result = {
        "workbuddy_dir_exists": False,
        "soul_md_exists": False,
        "soul_md_created": False,
        "soul_md_has_evolution": False,
        "existing_evolution_files": [],
        "phases_completed": [],
        "identity_is_template": True,
        "user_is_template": True,
        "bootstrap_exists": False,
    }

    # 1. Ensure workbuddy directory
    try:
        if not WORKBUDDY_DIR.exists():
            WORKBUDDY_DIR.mkdir(parents=True, exist_ok=True)
        result["workbuddy_dir_exists"] = True
    except (OSError, PermissionError) as e:
        return {
            "success": False,
            "error": f"Cannot create or access {WORKBUDDY_DIR}: {e}",
        }

    # 2. Ensure SOUL.md exists
    try:
        if SOUL_MD.exists():
            result["soul_md_exists"] = True
            soul_content = SOUL_MD.read_text(encoding="utf-8")
        else:
            SOUL_MD.write_text(DEFAULT_SOUL, encoding="utf-8")
            result["soul_md_exists"] = True
            result["soul_md_created"] = True
            soul_content = DEFAULT_SOUL
    except (OSError, PermissionError) as e:
        return {
            "success": False,
            "error": f"Cannot read or write {SOUL_MD}: {e}",
        }

    # 3. Check for evolution markers
    result["soul_md_has_evolution"] = "<!-- EVOLUTION_SECTION_START -->" in soul_content

    # 4. Check existing evolution files
    existing = []
    for fname in EVOLUTION_FILES:
        fpath = WORKBUDDY_DIR / fname
        if fpath.exists():
            existing.append(fname)
    result["existing_evolution_files"] = existing

    # 5. Read installation progress
    try:
        if EVOLUTION_STATE.exists():
            content = EVOLUTION_STATE.read_text(encoding="utf-8")
            for line in content.splitlines():
                if "安装进度：" in line:
                    progress = line.strip().replace("安装进度：", "")
                    # Check for ✅ marks next to phase numbers
                    for i in range(1, 7):
                        if f"{i} ✅" in progress or f"{i}✅" in progress:
                            result["phases_completed"].append(i)
    except (OSError, UnicodeDecodeError):
        pass

    # 6. Check IDENTITY.md and USER.md
    try:
        if IDENTITY_MD.exists():
            identity_content = IDENTITY_MD.read_text(encoding="utf-8")
            result["identity_is_template"] = _has_markers(identity_content, IDENTITY_TEMPLATE_MARKERS)
    except (OSError, UnicodeDecodeError):
        pass

    try:
        if USER_MD.exists():
            user_content = USER_MD.read_text(encoding="utf-8")
            result["user_is_template"] = _has_markers(user_content, USER_TEMPLATE_MARKERS)
    except (OSError, UnicodeDecodeError):
        pass

    # 7. Check BOOTSTRAP.md
    result["bootstrap_exists"] = BOOTSTRAP_MD.exists()

    return result


def main():
    try:
        data = audit()
        if "success" in data and not data["success"]:
            print(json.dumps(data, ensure_ascii=False, indent=2))
            sys.exit(1)
        print(
            json.dumps(
                {"success": True, "data": data},
                ensure_ascii=False,
                indent=2,
            )
        )
    except Exception as e:
        print(
            json.dumps(
                {"success": False, "error": f"Unexpected error: {e}"},
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
