# Scripts

安装脚本。使用 Python 3 标准库，零外部依赖。

| 脚本 | 阶段 | 功能 |
|------|------|------|
| audit.py | Phase 1 | 审计环境：检查 SOUL.md、进化文件、安装进度 |
| fix_layer0.py | Phase 2 | Bootstrap 状态检测：判断是否需要 Bootstrap 对话 |
| inject_evolution.py | Phase 3 | 注入/替换 SOUL.md 进化标记段 |
| create_infra.py | Phase 4 | 从 templates/ 创建 5 个进化状态文件 |

## 通用约定

- 输出 JSON 到 stdout，`success` 字段表示执行结果
- 错误信息在 `error` 字段
- 所有路径操作使用 `pathlib.Path`
- 文件操作前备份（.bak）
