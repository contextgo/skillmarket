#!/usr/bin/env python3
"""Phase 2: Bootstrap state detection. Does NOT conduct the conversation."""

import json
import os
import sys
from pathlib import Path

WORKBUDDY_DIR = Path.home() / ".workbuddy"
SOUL_MD = WORKBUDDY_DIR / "SOUL.md"
BOOTSTRAP_MD = WORKBUDDY_DIR / "BOOTSTRAP.md"

# Markers that indicate SOUL.md is still the default template
TEMPLATE_MARKERS = [
    "SOUL.md - Who You Are",
    "SOUL.md Template",
    "Workspace template for SOUL.md",
    "_Fill this in during your first conversation",
    "pick something you like",
]


def _soul_is_personalized() -> bool:
    """Return True if SOUL.md has actual personality content (not template)."""
    try:
        if not SOUL_MD.exists():
            return False
        content = SOUL_MD.read_text(encoding="utf-8")
        hits = sum(1 for m in TEMPLATE_MARKERS if m in content)
        return hits < 2
    except (OSError, UnicodeDecodeError):
        return False


def fix_layer0() -> dict:
    result = {
        "bootstrap_needed": False,
        "bootstrap_handled": False,
        "bootstrap_deleted": False,
    }

    bootstrap_exists = BOOTSTRAP_MD.exists()
    soul_personalized = _soul_is_personalized()

    if bootstrap_exists and not soul_personalized:
        # BOOTSTRAP exists and SOUL is still template -> need bootstrap
        result["bootstrap_needed"] = True
        result["bootstrap_handled"] = False
        result[
            "reason"
        ] = "BOOTSTRAP.md exists, SOUL.md is still template. Bootstrap conversation needed."
    elif bootstrap_exists and soul_personalized:
        # BOOTSTRAP exists but SOUL is already personalized -> bootstrap already done
        try:
            os.remove(str(BOOTSTRAP_MD))
            result["bootstrap_deleted"] = True
        except OSError as e:
            result["reason"] = f"Bootstrap done but cannot delete BOOTSTRAP.md: {e}"
            return result
        result["bootstrap_handled"] = True
        result["bootstrap_needed"] = False
        result["reason"] = "BOOTSTRAP.md deleted (SOUL.md already personalized)."
    elif not bootstrap_exists and not soul_personalized:
        # No BOOTSTRAP but SOUL is template -> unusual but not blocking
        result["bootstrap_handled"] = False
        result["bootstrap_needed"] = False
        result["reason"] = "No BOOTSTRAP.md found, but SOUL.md appears to be template."
    else:
        # No BOOTSTRAP, SOUL is personalized -> normal post-bootstrap state
        result["bootstrap_handled"] = True
        result["bootstrap_needed"] = False
        result["reason"] = "Already bootstrapped (no BOOTSTRAP.md, SOUL.md is personalized)."

    return result


def main():
    try:
        data = fix_layer0()
        print(
            json.dumps(
                {"success": True, "data": data},
                ensure_ascii=False,
                indent=2,
            )
        )
    except Exception as e:
        print(
            json.dumps(
                {"success": False, "error": f"Unexpected error: {e}"},
                ensure_ascii=False,
                indent=2,
            )
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
