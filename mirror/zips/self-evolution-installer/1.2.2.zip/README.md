# Self-Evolution Installer

> **让 WorkBuddy 拥有自进化能力。** 一行指令安装，你的 Agent 从此学会自主学习、自动发现缺陷、并在会话间累积改进经验。

> ⚠️ **仅限 WorkBuddy。** 本 Skill 深度依赖 WorkBuddy 专有机制（SOUL.md 注入、automation_update 工具），**不能**在 OpenClaw 或其他非 WorkBuddy 平台使用。

---

## 一句话总结

一个 Skill，一次安装。你的 WorkBuddy Agent 从此拥有跨会话记忆、自动巡检、缺陷捕获和模式感知能力——在每次对话中持续进化，越用越聪明。

## 它能做什么

如果你用过 WorkBuddy，你一定遇到过这些问题：

每次打开会话，Agent 都像第一次见你。昨天教过的规则今天又忘。同一个操作重复了十次，每次都从头来——没有人提醒你「这个可以做成 Skill」。你花了大量时间调教 Agent，但这些投入全部归零。没有积累，没有复利。

**这个 Skill 就是来解决这些问题的。** 安装后，你的 Agent 自动获得以下能力：

| 能力 | 说明 |
|------|------|
| 自动巡检 | 每天检查语法、每周审计文档一致性、每月深度分析 |
| 缺陷捕获 | 任务出错、连续失败、你纠正方向时自动记录问题 |
| 跨会话记忆 | 5 个状态文件持久化，下次会话自动加载，未完成的改进都在 |
| 分级自主权 | L0 仅观察 / L1 提案确认（默认）/ L2 自动修复，你控制节奏 |
| 模式感知 | 追踪你的任务历史，同一操作 30 天内重复 3 次以上，主动提议做成新 Skill |
| 时间线管理 | 每次 Skill 修改自动记录到活动时间线，跨会话可追溯 |
| 进化自检 | 每周自动检查进化系统自身健康（列表漂移/统计一致/automation 存活） |
| 一键移植 | 零外部依赖，复制到任何 WorkBuddy Agent 即可安装 |

## 安装前后对比

**有自进化之前：** 每次会话从零开始。出错了等你发现才修。相同的错误反复犯。Agent 不会主动发现可以沉淀成 Skill 的重复操作。你等于全职维护人员。

**有自进化之后：** 越用越聪明——对话中的纠正会累积。数据偏了自动发现并提醒。小问题自动修复，大问题提案让你决策。重复 3 次的操作自动识别，主动问你要不要做成 Skill。你的时间开始产生复利。

## 技术架构

五层进化模型：

| 层级 | 说明 |
|------|------|
| 触发总线层 | 4 种触发方式覆盖所有场景——定时任务、会话启动、使用数据驱动、错误捕获 |
| 进化引擎层 | 感知 → 判定 → 修复 → 验证的四步闭环决策模型，每步可审计 |
| 状态与记忆层 | 6 个纯文本文件，可 git 追踪，完全透明 |
| 基础层 | Bootstrap 初始化、跨会话 Working Memory、健康仪表盘 |
| Skill 层 | self-evolution-installer 自身——一键安装，零外部依赖 |

关键设计决策：通过 SOUL.md 标记段注入进化代码，不创建独立文件，确保幂等安装。7 个阶段断点续装，安装 100 次和安装 1 次结果一样。

## 设计理念

- **原则变自动化兜底** — 每条信条要么有自动化检查点兜住，要么显式标记为「待自动化」。不靠自觉，靠机制。
- **先议后行** — 改动前先出方案，确认后再执行。体现在 L1 默认提案制，安装时即可选择。
- **零外部依赖** — 纯 Python 标准库 + 纯文本 Markdown/JSON 文件。无 pip 无数据库，可 Git 追踪。
- **幂等安装** — 装 1 次和装 100 次结果一样。断点续装不重复执行已完成阶段。

## 工作原理

```
安装（7 阶段，< 2 分钟）→ 下次会话自动加载进化代码
→ 每日：语法检查  →  每周：健康审计  →  每月：深度分析 + 模式挖掘
→ 会话启动：9 步自检 + 任务模式扫描
→ 任务完成：自动记录 + 版本检测 + 时间线记录 + 摩擦检测
```

## 快速安装

对你的 WorkBuddy 说：

```
安装自进化
```

Skill 自动加载，7 阶段全自动安装，下次会话即时生效。

## 环境要求

- WorkBuddy Agent（任意版本）
- Python 3（仅使用标准库，零 pip 依赖）

## 文件结构

```
self-evolution-installer/
├── SKILL.md              # 入口 — 7 阶段安装引导
├── CHANGELOG.md          # 更新日志
├── DESIGN.md             # 架构决策记录（ADR）
├── SPEC.md               # 功能规格说明书
├── README.md             # 本文件
├── scripts/              # 安装脚本（Python 标准库）
│   ├── audit.py          # Phase 1: 环境审计
│   ├── fix_layer0.py     # Phase 2: Bootstrap 处理
│   ├── inject_evolution.py  # Phase 3: 注入进化代码到 SOUL.md
│   └── create_infra.py   # Phase 4: 创建 6 个状态文件
├── templates/            # Phase 3-4 模板文件
│   ├── evolution_section.md  # SOUL.md 注入内容
│   ├── evolution_state.md
│   ├── evolution_actions.md
│   ├── skill_usage.json
│   ├── skill_timeline.md
│   ├── health_metrics.md
│   └── health_dashboard.md
└── references/
    └── automation-prompts.md  # 3 个 Automation prompt
```

## 状态文件

位于 `~/.workbuddy/` 下：

| 文件 | 用途 |
|------|------|
| `evolution_state.md` | 配置 + 审查状态 |
| `evolution_actions.md` | 动作队列 + 任务历史（JSONL） |
| `skill_usage.json` | 各 Skill 使用计数 |
| `skill_timeline.md` | Skill 活动时间线（创建/修改/发布事件） |
| `health_metrics.md` | 健康分趋势 |
| `health_dashboard.md` | 会话日志（近 100 条） |

## 常见问题

**问：安装后会修改我现有的配置吗？**

不会。安装过程只追加进化代码段到 SOUL.md，不触碰你已有的人格内容。已有状态文件也不会被覆盖。

**问：我的 Mac 晚上合盖，定时任务能跑吗？**

能。如果定时任务因合盖错过触发，下次会话启动时会自动检测并补跑每日检查。每周和每月任务则会提醒你决定是否现在执行。

**问：Agent 会自动修改我的文件吗？**

默认不会。安装后默认为 L1 提案制——Agent 发现问题后只向你提案，等你确认才会动手。你可以手动升级到 L2 自动修复模式。

**问：我能看到它做了什么吗？**

完全可以。所有状态文件都是纯文本 Markdown 和 JSON，存放在 `~/.workbuddy/` 下，随时可以查看、审计、用 git 做版本管理。

**问：想卸载怎么办？**

SOUL.md 中的进化代码段以 `<!-- EVOLUTION_SECTION_START -->` 和 `<!-- EVOLUTION_SECTION_END -->` 标记，手动删除该段即可移除运行时代码。状态文件可以手动删除或保留。

## 更新日志

详见 [CHANGELOG.md](CHANGELOG.md)

## 许可协议

MIT-0（无需署名）
