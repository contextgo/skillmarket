# Evolution Actions

## 统计
- 总计：0 | 待执行：0 | 待确认：0 | 已完成：0

## 动作队列

（空队列 — 进化引擎将在发现问题后自动追加）

### 动作格式

### A-YYYYMMDD-NNN：[简短标题]
- 状态：待执行 | 待确认 | 已完成 | 跳过（理由）
- 优先级：P0 / P1 / P2 / P3
- 类型：audit_skill | fix_dead_code | sync_doc | cross_pollinate | suggest_skill | archive_skill | health_report
- 来源：T1-daily | T1-weekly | T1-monthly | T2-session | T3-usage | T4-error
- Tier：Tier 1（单 skill） | Tier 2（跨 skill 通用） | Tier 3（基础层）
- 目标文件：...
- 修复工具：skill名称 | 兜底模式
- 创建时间：YYYY-MM-DD HH:MM
- 截止日期：YYYY-MM-DD
- 上次汇报时间：YYYY-MM-DD HH:MM
- 描述：...

---

## 任务历史

任务完成后自动追加，每行一条 JSONL。用于模式检测和 Skill 建议生成。

格式：`{"date":"YYYY-MM-DD","action":"<动作名>","result":"<结果>"}`

```jsonl
```
