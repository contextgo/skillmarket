<!-- EVOLUTION_SECTION_START -->
## 自进化机制（self-evolution v1.2.2）

### 每次会话启动时（最先执行）
以下检查不可跳过。执行结果写入 `~/.workbuddy/health_dashboard.md`。

1. 读取 `~/.workbuddy/evolution_state.md` 获取当前配置和状态
2. 读取 `~/.workbuddy/evolution_actions.md`，如有「待执行」或「待确认」项，提醒用户
3. 读取 `~/.workbuddy/evolution_actions.md` 底部的「任务历史」段。如果同一 action 在最近 30 天内出现 ≥3 次且尚未有对应的 Skill 提案，写入一条 `suggest_skill` 动作到队列（来源：T2-session，类型：suggest_skill，见该文件 Schema）
4. 检查当天是否应有 automation 执行（见 evolution_state.md 的 Automation 执行记录），如有遗漏：
   - **Daily Check 遗漏**：自动补跑（轻量，<10 秒，不打断用户）
   - **Weekly Review / Monthly Deep 遗漏**：提醒用户，由用户决定是否现在执行
5. 检查是否跨月（与 evolution_state.md 上次月度深检时间比较）→ 触发月度回顾
6. 检查当前 workspace 的 .workbuddy/memory/ 是否存在 → 不存在则创建
7. 检查 `~/.workbuddy/BOOTSTRAP.md` 是否存在 → 存在则暂时将自主权降为 L0，并提醒用户完成 bootstrap
8. 更新 health_dashboard.md：追加一行会话记录（超过 100 行时归档旧行到 health_dashboard_archive.md）
9. **扫描 skills/ 目录当日变更。** 执行 `find ~/.workbuddy/skills/ -type f -newermt $(date +%Y-%m-%d) 2>/dev/null | sort`，根据输出：
   - 有变更 → 列出新增/修改的 skill 名称及文件计数，在会话上下文中注明
   - 无变更 → 跳过（< 1 秒，不影响用户体验）
   - 此检查在重启后、任务开始前执行，确保跨会话感知当日 skill 操作

### 每次完成任务后

**任务历史记录**（无条件执行）：
将本次任务以 JSONL 格式追加到 `~/.workbuddy/evolution_actions.md` 底部的「任务历史」段：
```
{"date":"YYYY-MM-DD","action":"<简短动作名>","result":"<success|数量>"}
```
示例：`{"date":"2026-05-02","action":"generate_pptx","result":"success"}`

**版本变更检测**（有条件执行）：
如果本次任务修改了 `~/.workbuddy/skills/` 下任何 skill 的文件：
1. 对每个被修改的 skill，读取 `SKILL.md` frontmatter 的 `version:` 字段作为基准版本
2. 如果该 skill 有 `CHANGELOG.md`，提取最新版本号（`## [X.Y.Z]`），与基准版本比对
3. 如果该 skill 有 `SPEC.md` 或 `DESIGN.md`，提取版本历史表最新行，与基准版本比对
4. 任何不一致 → 写入 `evolution_actions.md`（优先级：P2，来源：T2-session，类型：sync_version，Tier：1），并告知用户

**时间线记录检查**（自动追加，紧接着版本变更检测）：
如果版本变更检测已确认有 skill 被修改：
1. 读取 `~/.workbuddy/skill_timeline.md`，查找当天的日期标题（`## [YYYY-MM-DD]`）下是否有被修改的 skill 的条目
2. 如果缺失 → 自动追加一条时间线记录，格式参照现有条目（`### skill-name` + 类型/说明/版本）
3. 无需重复报告给用户，静默修复

**摩擦检测**（有条件执行）：
检查本次任务中是否有以下情况（任一满足即触发）：

**客观信号**（自动触发）：
- 执行过程中出现错误/异常
- 同一操作连续 2 次以上才成功

**主观信号**（主动判断）：
- 用户中途停掉流程并纠正方向
- 必须绕过某个 skill 设计来做 hack
- 任务中有明显的摩擦点
- 任务中发现了可跨 Skill 复用的模式/原则/认知，值得沉淀到 `~/.workbuddy/principles/`

触发后：
1. 按三层分类问题：
   - **Tier 1**：问题仅由某个特定 skill 的设计/实现导致，修改该 skill 即可解决
   - **Tier 2**：问题模式适用于多个 skill，需要修改通用机制
   - **Tier 3**：问题属于 WorkBuddy 工作方式/原则的根本缺陷，需修改 SOUL.md 等基础文件（必须经用户确认）
2. 写入 `~/.workbuddy/evolution_actions.md`
3. 自主权判定：L0 只记录 | L1 提案等确认 | L2 P3 自动修复（需配置中显式开启）
4. 更新 `~/.workbuddy/skill_usage.json` 中对应 skill 的 count 字段

### 进化系统自检（每周周检时执行）

对进化系统本身做交叉验证，通过 weekly review 自动化触发。所有检查为只读，发现问题写入 `evolution_actions.md`（P2，类型：self_check）。

| 检查项 | 验证内容 | 严重度 |
|--------|---------|--------|
| skill 列表漂移 | evolution_state 中 skill 列表 vs skills/ 实际目录 | 🔴 |
| action 统计一致性 | evolution_actions 统计行 vs 实际条目计数 | 🟡 |
| automation 存活 | 登记表 vs 系统实际注册的 automation 状态 | 🔴 |
| EVOLUTION_SECTION 完整性 | 版本号是否与 installer 期望一致 | 🟡 |

### Skill 修复：运行时能力检测
修复 skill 时不硬编码依赖特定工具：

1. 扫描 `~/.workbuddy/skills/` 下所有 skill 的 description 字段
2. 匹配关键词：refine / audit / review / quality / improve / fix / 完善 / 审查 / 修复 / 优化 / 审计
3. 🟢 找到功能匹配的 skill → 调用执行
4. 🟡 找到部分匹配的 skill → 适配调用
5. 🔴 无可用 skill → 兜底模式：P3 可自动修复（需验证），P1-P2 只提案

evolution_actions 中记录使用的工具名称；兜底模式额外标注。

### 定时 Automation
系统注册了三个定时任务（名称见 evolution_state.md）：
- 每日 3:00（用户本地时区，默认 GMT+8）：语法/import 检查
- 每周日 4:00：代码一致性审查 + 进化系统自检
- 每月 1 号 5:00：全量深度审查

会话中若检测到以上 automation 未按时执行，按三档策略处理：Daily 自动补、Weekly/Monthly 提醒。

### 状态文件
| 文件 | 用途 |
|------|------|
| `~/.workbuddy/evolution_state.md` | 配置、skill 审查状态 |
| `~/.workbuddy/evolution_actions.md` | 唯一动作队列（生命周期：待执行→待确认→已完成），底部含「任务历史」段（JSONL） |
| `~/.workbuddy/skill_usage.json` | Skill 使用计数（JSON 格式，跨会话可靠读写） |
| `~/.workbuddy/skill_timeline.md` | Skill 活动时间线，记录创建/修改/发布事件 |
| `~/.workbuddy/health_metrics.md` | 闭环率、趋势 |
| `~/.workbuddy/health_dashboard.md` | 每次会话执行记录（上限 100 行） |

### Skill 使用计数
使用计数存储在 `~/.workbuddy/skill_usage.json`。
达到阈值（默认 5）时，在 evolution_actions.md 中自动追加一条审查动作。审查后 count 归零、last_reset 更新。

### Meta-Evolution
此标记段只能通过 self-evolution-installer 升级，不得自行修改。Evolution_state.md 中的配置项可在运行时修改。
<!-- EVOLUTION_SECTION_END -->
