# DESIGN · self-evolution-installer

> 版本：v1.2.2  
> 日期：2026-05-03  
> 状态：已发布

## 版本历史

| 版本 | 日期 | 变更 |
|------|------|------|
| 1.2.2 | 2026-05-03 | 新增时间线记录检查 + 进化自检节（v1.2.2）；新增 ADR-012、ADR-013 |
| 1.2.1 | 2026-05-02 | 新增 EVOLUTION_SECTION 后任务版本变更检测（v1.2.1）；更新 ADR-011 |
| 1.2.0 | 2026-05-02 | 新增 EVOLUTION_SECTION step 9（skills/ 目录当日变更扫描）；新增 ADR-011 版本同步清单 |
| 1.1.1 | 2026-05-02 | 新增 INTRO.md；修正 README/CHANGELOG/模板中的版本号和阶段数不一致 |
| 1.1.0 | 2026-05-02 | 新增 Phase 5.5（用户配置）+ ADR-010，更新 ADR-004 为用户可选，修正 cwds 路径描述 |
| 1.1.0 | 2026-05-01 | 修：去除 memery/ 残留引用 + 新增 ADR-008~009 |
| 1.0 | 2026-05-01 | 初版，基于 self-evolution-system-design.md v2.1 |

## 架构决策记录 (ADR)

### ADR-001: SOUL.md 嵌入模式

**决策**：SOUL.md 中用 `<!-- EVOLUTION_SECTION_START -->` / `<!-- EVOLUTION_SECTION_END -->` 标记段隔离进化代码。

**备选方案**：
- A) 独立 evolution_soul.md 文件，SOUL.md 引用
- B) SOUL.md 末尾合并式追加（无标记段）

**选择理由**：SOUL.md 是 WorkBuddy 唯一被系统注入的行为指令文件。独立文件无法被自动加载（WorkBuddy 只注入 SOUL.md）。标记段保证不污染 agent 已有的人格内容，且支持幂等替换。

**后果**：
- SOUL.md 规模增加约 60 行
- 多个「带自进化」的 skill 不能同时装（标记段冲突）
- Meta-evolution（进化系统升级）只能通过重新执行 installer 实现，见 ADR-007

---

### ADR-002: 记忆目录仅涉 Workspace 级

**决策**：进化系统只操作 workspace 级别的 `.workbuddy/memory/YYYY-MM-DD.md`，不触碰 `~/.workbuddy/memory/` 全局目录。

**备选方案**：
- A) 统一全局到 YYYY-MM-DD 格式
- B) 保留 UUID 命名并做环境适配

**选择理由**：
- 全局目录使用 UUID 命名，由 WorkBuddy 系统内部管理，改名可能破坏 session 恢复
- Workspace 级记忆天然使用 YYYY-MM-DD 格式，零冲突
- 进化系统的「检查 memory 是否存在」检查的是 workspace 级路径

**后果**：
- 进化引擎的会话级检查仅在 workspace 范围内有效
- 如果 workspace 的 memory 目录不存在，进化引擎负责创建

---

### ADR-003: Automation 补充模式

**决策**：定时任务设定时触发，额外的兜底在会话启动时补执行。分两档：
- Daily 遗漏：自动补跑（10-20 个文件语法检查，< 10 秒）
- Weekly/Monthly 遗漏：仅提醒用户，由用户决定是否现在执行

**备选方案**：
- A) 严格模式：期望按时执行，不补跑
- B) 随缘模式：跑了算，不跑无所谓
- C) 全部自动补跑

**选择理由**：
- MacBook 凌晨合盖，自动化大概率不按时触发
- Daily 检查足够轻量，自动补不打断用户
- Weekly/Monthly 耗时较长（30-60 秒），交给用户掌控避免干扰

**后果**：
- SOUL.md 注入代码的第 3、4 步需要包含时间比对和分档兜底逻辑
- 会话启动时多几秒开销（Daily 补跑）
- 用户偶尔会收到「上周的中检漏了」提醒

---

### ADR-004: L1 自主权为用户安装时可选的默认值

**决策**：安装过程中（Phase 5.5）引导用户选择自主权级别，L1 作为默认选项呈现，非硬编码。

**备选方案**：
- A) L0（只发现不报告）
- B) L2（P3 小问题自动修）
- C) L3（深度自动）
- D) 硬编码 L1，不允许安装时选择（v1.0 方案）

**选择理由**：
- 和 SOUL.md 核心信条「先议后行」完全一致
- v1.0 默认 L1 但用户无法在安装时知情或选择
- L1 作为推荐选项呈现，用户可自主升级到 L2
- 「共同进化」的核心是用户决定进化的节奏

**后果**：
- 安装过程增加一个交互环节（Phase 5.5）
- 如果用户选择 L2，P3 问题将自动修复，不会提案
- 安装完成后仍可通过 evolution_state.md 调整
- Phase 5.5 同时询问 T3 使用驱动的开关

---

### ADR-005: 安装幂等 — 断点续装

**决策**：evolution_state.md 的安装进度字段（`安装进度：1/2/3/4/5/6/7`）驱动断点续装。Phase 1 先读取此行，跳过已完成阶段。

**备选方案**：
- A) 文件存在性检测
- B) 全量重新执行（覆盖模式）

**选择理由**：
- 进度字段比文件存在性更可靠——文件可能被误删，进度字段反映真实状态
- 覆盖模式浪费且可能覆盖用户手动修改的配置
- 6 个 phase 的依赖链天然支持断点续装（v1.1.0 增加至 7 个）

**后果**：
- evolution_state.md 成为安装状态的主控文件
- 如果 Phase 5 注册了 2 个 automation 后被打断，重新安装时需要检测已注册的 automation

---

### ADR-006: Phase 5 使用 AI 指令而非 Python 脚本

**决策**：Automation 注册不用 Python 脚本，在 SKILL.md 中以自然语言引导 AI 调用 `automation_update` 工具。

**备选方案**：
- A) Python 脚本调用 WorkBuddy API
- B) Shell 脚本写入 SQLite 数据库

**选择理由**：
- `automation_update` 是 WorkBuddy 内置工具，Python/Shell 无权直接操作其数据库
- AI 指令是唯一可移植的注册方式——不同平台可能有不同 API
- 每个注册前先 `view` 检查是否已存在，实现幂等

**后果**：
- 安装过程需要 AI 在会话中执行 Phase 5，不能完全无人值守
- 如果 AI 会话在选择 CWD 时出错，automation 可能注册到错误的 workspace

---

### ADR-007: Meta-Evolution — Installer 为唯一升级入口

**决策**：SOUL.md 进化标记段只能通过 installer 重新执行来升级。进化引擎不能修改自己的指令源。

**备选方案**：
- A) 允许进化引擎修改自身 SOUL.md 标记段
- B) 完全禁止升级

**选择理由**：
- 防自毁（进化引擎错误修改自己的行为代码）
- 可追踪（版本号在 evolution_state.md 中）
- 可回滚（旧版 installer 重新安装）

**后果**：
- 进化系统升级需要用户主动（下载新版 installer → 重新执行）
- evolution_state.md 中的配置项仍可在运行时修改
- installer 需支持「替换旧标记段」模式（Phase 3 已有）

---

### ADR-008: 模板类型 — basic（非 multi-scene）

**决策**：Skill 使用 `basic` 模板，不使用 `multi-scene`。

**备选方案**：multi-scene（将 6 个 phase 映射为 6 个场景）

**选择理由**：
- 7 个安装阶段是顺序执行的非条件流程，用户触发一次全部跑完
- multi-scene 模板需要场景路由逻辑（触发词→工作流映射），但本 skill 所有阶段由同一条命令触发
- basic 模板的 SKILL.md 更简洁，不产生冗余的场景声明

**后果**：
- SKILL.md 不需要 scene 路由表
- BUILD 阶段使用 `python3 scripts/init_skill.py --name self-evolution-installer --template basic`
- SPEC/DESIGN 文件仍需保留（由 king 规范要求 basic 模板也可选配）

---

### ADR-009: Phase 5 降级策略

**决策**：Phase 5 执行前先探测目标系统是否提供 `automation_update` 工具。不可用时跳过注册并输出警告，安装视为部分成功。

**备选方案**：
- A) Automation 不可用时安装失败
- B) 静默跳过

**选择理由**：
- Evolution 系统的核心能力（SOUL.md 注入 + 状态文件）不依赖 Automation 的存在
- Automation 缺失时，会话启动兜底（SOUL.md 第 3 步）仍能覆盖检查逻辑
- 安装不应因一个非核心工具缺失而整体失败

**后果**：
- Automation 警告中需包含 3 个 automation 的完整 prompt，供用户手动注册
- Phase 6 验证清单中将 automation 状态标记为「⚠️ 未注册」而非 ❌

### ADR-010: Phase 5.5 用户配置环节

**决策**：在 Phase 5 注册 automations 之后、Phase 6 验证之前，增加用户配置环节。使用 AskUserQuestion 让用户选择自主权级别（L1/L2）和 T3 使用驱动（开/关），写入 evolution_state.md。

**备选方案**：
- A) 安装后不询问，用户自行修改 evolution_state.md
- B) 安装后通过自动化脚本设置默认值

**选择理由**：
- 「共同进化」要求用户在安装时就知情并参与选择节奏
- 自主权级别和 T3 使用驱动是决定进化行为的最核心参数
- 安装时一问 + 写入，比让用户事后找文件改更顺滑
- 与 ADR-004 的「L1 为用户可选默认值」一致

**后果**：
- 安装过程增加 2 个问题（选 L1/L2、选开/关），约 10 秒交互
- evolution_state.md 的配置在 Phase 5.5 完成后才写入
- 后续升级时，Phase 5.5 跳过（配置不覆盖）

---

### ADR-011: 版本同步清单 — 版本号必须对齐的 7 个表面

**决策**：每次 self-evolution-installer 升级（版本号变更），下列 7 处必须同步修改。将此清单写入 DESIGN.md，任何 AI 执行升级前先读此清单。

**版本号位于的文件和位置**：

| # | 文件 | 具体位置 | 例子 |
|---|------|---------|------|
| 1 | `SKILL.md` | frontmatter `version:` 字段 | `version: "1.2.2"` |
| 2 | `SPEC.md` | 顶部 header | `> 版本：v1.2.2` |
| 3 | `DESIGN.md` | 顶部 header + 版本历史表 | `> 版本：v1.2.2` + 新增版本行 |
| 4 | `CHANGELOG.md` | 版本条目标题 | `## [1.2.2] - 2026-05-03` |
| 5 | `templates/evolution_state.md` | 安装器版本 + 进化代码版本 | `安装器版本：v1.2.2` + `进化代码版本：v1.2.2` |
| 6 | `templates/evolution_section.md` | 自进化机制标题 | `## 自进化机制（self-evolution v1.2.2）` |
| 7 | `evolution_state.md`（用户实例） | 安装器版本 + 进化代码版本 | 同上，用户部署的实例 |

**修复路线**：先改模板（#5、#6），再注入（#7 自动更新），再改自身文档（#1-#4）。

**备选方案**：
- A) 无清单，靠 AI 的「记得」
- B) 脚本自动扫描所有版本号并自动修改

**选择理由**：
- 方案 A 已被本次实践证伪——AI 在"热修复模式"下会忘记同步
- 方案 B 过度设计——版本变更是低频操作（可能数周一次），写脚本不值得
- 清单在升级时作为「人类可读的 checklist」由 AI 逐项过，足够且可靠

**后果**：
- 升级前必须先读本清单
- 清单本身需在版本变更时同步更新（自我引用风险，但版本变更本身就是低频操作，可接受）

---

### ADR-012: 时间线记录检查 — 后任务自动兜底

**决策**：版本变更检测之后顺带执行时间线记录检查。如果检测到 skill 被修改，自动读取 `skill_timeline.md`，检查当天是否有对应条目，缺失则静默追加。

**备选方案**：
- A) 靠 AI 自觉遵守「行动即记录」纪律
- B) 单独独立的检查机制

**选择理由**：
- 方案 A 已被证伪——热修复模式下 AI 会忘记（时间线记录本身发现的）
- 版本变更检测已确认 skill 被修改，条件分支已打开，顺带检查是零额外成本
- 静默修复不干扰用户体验

**后果**：
- EVOLUTION_SECTION「每次完成任务后」增加一段条件逻辑
- 版本变更检测触发时多一次文件读取（skill_timeline.md，< 10ms）

---

### ADR-013: 进化系统自检 — 周检内嵌

**决策**：每周周检时对进化系统本身做交叉验证，作为周检 prompt 的第 6 步。不新增独立 automation。

**备选方案**：
- A) 新加第四个 automation（self-evolution-self-check）
- B) 放在月度深检中
- C) 每次会话启动时都跑

**选择理由**：
- 自检涉及跨文件比对（evolution_state vs skills/ 实际目录等），操作多但全为只读，周检的 1-2 分钟窗口刚好消化
- 新加 automation 增加系统复杂度和启动兜底逻辑
- 并非每次启动都需要做（漂移是慢变量）
- 月度深检距离太远，漂移发现太晚

**后果**：
- 周检 prompt 新增第 6 步
- 周检耗时增加约 1-2 秒（纯文件比较）
- 发现不一致时写入 evolution_actions.md（P2，不会自动修复）

---

## 模块关系图

```
SKILL.md (L1)
  ├── 引导 AI 执行 Phase 1-4（调用 Python 脚本）
  ├── 引导 AI 执行 Phase 5（调用 automation_update 工具）
  ├── 引导 AI 执行 Phase 5.5（AskUserQuestion + 写 evolution_state）
  └── 引导 AI 执行 Phase 6（验证 + 报告）
       │
scripts/
  ├── audit.py           → Phase 1: 审计环境
  ├── fix_layer0.py      → Phase 2: 处理 Bootstrap
  ├── inject_evolution.py → Phase 3: 注入 SOUL.md 标记段
  └── create_infra.py    → Phase 4: 创建 6 个状态文件
       │
templates/               → Phase 3-4 的模板文件
  ├── evolution_section.md   (SOUL.md 注入内容)
  ├── evolution_state.md
  ├── evolution_actions.md
  ├── skill_usage.json
  ├── skill_timeline.md
  ├── health_metrics.md
  └── health_dashboard.md
       │
DESIGN.md                  → 架构决策文档（本文档）
references/
  ├── automation-prompts.md → 3 个 Automation 的完整 prompt
  │
SPEC.md                    → 功能规格说明书
CHANGELOG.md               → 版本变更记录
```

## 数据流图

```
Phase 1: audit.py
  检测: SOUL.md 存在? 有旧标记段? 进化文件已有? 安装进度?
  → 输出 JSON: { phases_completed: [1,2], ... }

Phase 2: fix_layer0.py  
  检测: BOOTSTRAP.md? SOUL.md 是模板还是真人? USER.md 空?
  → 动作: 提示 Bootstrap / 跳过
  → 删除 BOOTSTRAP.md
  → 输出 JSON: { bootstrap_handled: true, ... }

Phase 3: inject_evolution.py
  读取: SOUL.md, templates/evolution_section.md
  → 标记段不存在: 末尾追加
  → 标记段已存在: 替换标记段内容
  → 写入 SOUL.md

Phase 4: create_infra.py
  检测: 6 个文件是否已存在
  → 逐一从 templates/ 复制并插值（时间、版本）
  → 输出 JSON: { created: [...], skipped: [...] }

Phase 5: AI 指令
  读取: SKILL.md 中的 Automation 规格
  → 对 3 个 automation 逐一 view → create/update
  → 输出: 注册报告

Phase 5.5: AI 指令（用户交互）
  读取: current evolution_state.md 配置
  → AskUserQuestion: 选 L1/L2、选 T3 开/关
  → 写入 evolution_state.md
  → 输出: 配置已写入

Phase 6: 验证
  grep: SOUL.md 含 <!-- EVOLUTION_SECTION_START -->
  stat: 6 个状态文件非空
  automation_update view: 3 个已注册 + ACTIVE
  → 输出: 安装报告（checklist）
```
