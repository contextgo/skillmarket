# SPEC · self-evolution-installer

> 版本：v1.2.2  
> 日期：2026-05-03  
> 状态：已发布

## 概述

一键在 WorkBuddy agent 上安装自进化能力。安装后 agent 自动具备：定时巡检、状态持久化、自主分级改进、Skill 活动时间线自动管理、进化系统健康自检。零外部依赖，可移植到任何 WorkBuddy agent。

## 触发词

- 安装自进化, setup evolution, init self-evolution
- 装进化模块, 安装进化引擎, enable self evolution

## 输入

| 输入 | 来源 | 说明 |
|------|------|------|
| SOUL.md | ~/.workbuddy/SOUL.md | agent 行为指令文件，注入进化标记段 |
| IDENTITY.md | ~/.workbuddy/IDENTITY.md | agent 身份，Phase 2 检查是否为模板 |
| USER.md | ~/.workbuddy/USER.md | 用户信息，Phase 2 检查是否为模板 |
| BOOTSTRAP.md | ~/.workbuddy/BOOTSTRAP.md | 可选，存在时触发 Bootstrap 流程 |
| 模板文件 | templates/ | evolution_section.md + 6 个状态文件模板 |
| 用户选择 | 交互 | Phase 5.5 用户选择 L1/L2 + T3 开/关 |

## 处理流程（7 Phase）

### Phase 1: 审计环境
- 确保 ~/.workbuddy/ 目录存在
- 确保 SOUL.md 存在（不存在则创建默认模板）
- 检测已有进化标记段
- 检测已安装的进化文件
- 读取安装进度，实现断点续装

### Phase 2: Bootstrap 处理
- 检测 BOOTSTRAP.md 和身份文件是否为模板
- 如果需要 bootstrap，暂停安装引导用户完成
- 删除 BOOTSTRAP.md

### Phase 3: 注入 SOUL.md 进化代码
- 无标记段：末尾追加
- 已有标记段：替换内容（幂等）
- 创建 SOUL.md.bak 备份

### Phase 4: 创建 6 个状态文件
- evolution_state.md
- evolution_actions.md
- skill_usage.json
- skill_timeline.md
- health_metrics.md
- health_dashboard.md
- 已存在的不覆盖
- 初始化 health_dashboard 首行记录

### Phase 5: 注册 3 个 Automation
- self-evolution-daily-check（每日）
- self-evolution-weekly-review（每周日）
- self-evolution-monthly-deep（每月1日）
- 先探测 automation_update 可用性
- 每个注册前先 view 检查是否存在（幂等）
- cwds 使用 $HOME 绝对路径

### Phase 5.5: 用户配置
- 先读取当前 evolution_state.md 的配置
- 询问自主权级别（L1 推荐 / L2）
- 询问 T3 使用驱动（开启推荐 / 关闭）
- 用户确认后写入 evolution_state.md

### Phase 6: 验证
- SOUL.md 含进化标记段
- 5 个状态文件存在且非空
- 3 个 automation 注册状态 ACTIVE（如可用）
- 输出安装报告

## 输出

### 成功标准
1. SOUL.md 包含 `<!-- EVOLUTION_SECTION_START -->` 标记段
2. 6 个状态文件存在且非空（含 skill_timeline.md）
3. 3 个 automation 注册为 ACTIVE（或输出降级警告）
4. evolution_state.md 中配置完成

### 安装报告格式

```
| 阶段 | 状态 |
|------|------|
| 1. 审计 | ✅ |
| 2. Bootstrap | ✅ |
| 3. SOUL注入 | ✅ |
| 4. 状态文件 | ✅ (x created, y skipped) |
| 5. Automation | ✅ / ⚠️ 部分 |
| 6. 配置 | ✅ |
| 7. 验证 | ✅ |
```

## 降级策略

| 场景 | 行为 |
|------|------|
| Phase 2 bootstrap 需要 | 暂停安装，引导用户完成 bootstrap 对话 |
| Phase 5 automation_update 不可用 | 跳过注册，输出警告，视为部分成功 |
| Phase 3 注入失败 | 停止安装，报错 |
| 断点续装 | 已完成的 phase 跳过，从断点继续 |

## 需求规格

### REQ-001: 状态文件创建
- **描述**：安装完成后 `~/.workbuddy/` 下存在 6 个状态文件
- **验收**：evolution_state.md / evolution_actions.md / skill_usage.json / skill_timeline.md / health_metrics.md / health_dashboard.md 均存在且非空
- **优先级**：P0

### REQ-002: SOUL.md 进化标记段注入
- **描述**：SOUL.md 包含 `<!-- EVOLUTION_SECTION_START -->` 和 `<!-- EVOLUTION_SECTION_END -->` 标记段
- **验收**：grep 确认两标记均存在，间隔内容为有效进化代码
- **优先级**：P0

### REQ-003: Automation 注册
- **描述**：安装成功后注册 3 个定时 automation（daily / weekly / monthly）
- **验收**：通过 `automation_update mode=view` 确认 3 个名称对应且状态为 ACTIVE
- **优先级**：P0
- **降级**：工具不可用时跳过，视为部分成功

### REQ-004: 断点续装
- **描述**：安装中断后重新执行，已完成的 phase 跳过，从断点继续
- **验收**：在 Phase 3 后中断，重跑后跳过 Phase 1-3，从 Phase 4 继续
- **优先级**：P1

### REQ-005: 版本同步一致性
- **描述**：SKILL.md / SPEC.md / DESIGN.md / CHANGELOG.md / evolution_state.md / evolution_section.md 中的版本号一致
- **验收**：DESIGN.md ADR-011 清单中 7 处版本号全部对齐
- **优先级**：P1

### REQ-006: 用户配置交互
- **描述**：Phase 5.5 引导用户选择自主权级别（L1/L2）和 T3 使用驱动（开/关）
- **验收**：执行 Phase 5.5 时弹出 AskUserQuestion，选择后 evolution_state.md 配置更新
- **优先级**：P1

### REQ-007: 自动化兜底
- **描述**：会话启动时检测当日 automation 是否漏跑，对 daily 自动补跑，weekly/monthly 提醒用户
- **验收**：EVOLUTION_SECTION 启动步骤第 4-5 步按三档策略执行
- **优先级**：P2

### REQ-008: 安装幂等
- **描述**：已安装的系统上再次执行 installer，不破坏现有状态文件，不重复注册 automation
- **验收**：重装后所有状态文件保留已有内容，automation 不重复注册
- **优先级**：P2

## 依赖

- Python 3.x（内置库，无外部依赖）
- WorkBuddy 环境（automation_update 工具可选）
