# ROOT_TEMPLATE.md

> 本文件是安装专业 SKILL 时生成根 SKILL.md（入口文件）的模板。
> 安装流程中，skill-manager 读取本模板，
> 将 {{占位符}} 替换为实际值后，写入 `<skill_name>/SKILL.md`。
>
> **本文件受 skill-manager 自我保护机制保护，不可通过对话修改。**

---

以下为模板正文，`{{}}` 中的内容在安装时替换：

---

```markdown
---
name: {{skill_name}}
description: "{{description}}"
managed_by: skill-manager
installed: {{install_date}}
---

# {{skill_name}}

> 本文件由 skill-manager 自动生成，是该技能的唯一入口。
> 不可通过对话直接修改本文件。
> 如需自定义，请通过补充（_user/{{skill_name}}/extensions/）或纠正（_user/{{skill_name}}/patches/）机制操作。

## 基础信息

- **技能名称：** {{skill_name}}
- **描述：** {{description}}
- **安装日期：** {{install_date}}

## base/ 目录概要

{{base_tree}}

---

## 阅读指令

你正在使用一个支持用户自定义的分层 SKILL。加载本技能时，**必须按以下三步顺序组装最终生效内容**，每步都要执行，不可跳过。

### 第一步：加载官方基础内容

读取 `base/SKILL.md`（官方核心指令）及 `base/` 下的其他文件。

### 第二步：应用用户纠正（patches）

直接扫描 `../_user/{{skill_name}}/patches/` 目录，列出所有 `.md` 文件（排除 `.gitkeep`）。

> ⚠️ 必须通过目录扫描获取文件列表，不可依赖本文件中的任何计数统计，计数可能因时序问题不同步。

对每个发现的 patch 文件：
1. 读取 frontmatter 中的 `target` 字段，定位被纠正的 base 文件
2. 读取对应 base 文件内容
3. 逐条将 `original` 字段匹配到的内容替换为 `corrected` 字段的内容
4. 未被任何 patch 提及的 base 内容保持原样生效

### 第三步：追加用户补充（extensions）

直接扫描 `../_user/{{skill_name}}/extensions/` 目录，列出所有 `.md` 文件（排除 `.gitkeep`）。

> ⚠️ 同上，必须通过目录扫描获取文件列表。

对每个发现的 extension 文件：读取其内容，作为额外规则/模板/配置追加到官方内容之后生效。

### 冲突规则

当用户内容（patches/ 或 extensions/）与 base/ 内容冲突时，**以用户内容为准**。

---

## 用户自定义状态（仅供参考）

> ⚠️ 以下计数为 skill-manager 最后一次操作时的快照，可能不是最新状态。
> 实际内容以扫描目录为准（见上方阅读指令）。

- **纠正（patches）：** {{patch_count}} 个文件
- **补充（extensions）：** {{extension_count}} 个文件

详见注册表：`../_user/{{skill_name}}/registry.md`

---

## 操作约束

### 当用户要求自定义此 SKILL
1. 先读取 `base/` 的相关内容，理解官方已有的规则和范围
2. 将用户需求与 base 已有内容比对，判断是「补充」还是「纠正」
3. 补充（base 中不存在的新内容）→ 创建文件到 `../_user/{{skill_name}}/extensions/`，头部 mode=append
4. 纠正（base 中已有但需修正的条目）→ 创建文件到 `../_user/{{skill_name}}/patches/`，头部 mode=patch
5. 意图不明确 → 先列出 base 中已有的相关内容，再询问用户
6. 操作完成后更新 `../_user/{{skill_name}}/registry.md`
7. **操作完成后重新生成本入口文件**（调用 skill-manager 重新生成 `{{skill_name}}/SKILL.md`，更新计数）
8. 禁止直接修改 `base/` 中的任何文件

### 当用户要求安装或更新此 SKILL
1. 将新包内容完整替换 `base/` 目录（清空后复制）
2. 不触碰 `../_user/{{skill_name}}/` 目录
3. 校验 `../_user/{{skill_name}}/patches/` 中的纠正项是否仍匹配新版 base 内容
4. 校验 `../_user/{{skill_name}}/extensions/` 中的补充是否与新版 base 存在主题重叠
5. 重新生成本入口文件（base/ 目录概要更新为新版，计数同步）
6. 向用户展示更新报告和兼容性检查结果
```

---

## 占位符说明

| 占位符 | 来源 | 说明 |
|--------|------|------|
| `{{skill_name}}` | 优先取 base/SKILL.md frontmatter 的 name 字段；无则取 .zip 解压后的根目录名 | 技能名称 |
| `{{description}}` | 优先取 base/SKILL.md frontmatter 的 description 字段；无则定位 base/SKILL.md 正文中「技能描述」标题，提取其下方文本 | 技能描述 |
| `{{install_date}}` | 安装时的当前日期，格式 YYYY-MM-DD | 安装日期 |
| `{{base_tree}}` | 扫描 base/ 目录生成的树状结构文本（类似 tree 命令输出） | 目录概要 |
| `{{patch_count}}` | 扫描 `_user/<skill_name>/patches/` 下的 .md 文件数量（排除 .gitkeep） | 纠正文件数 |
| `{{extension_count}}` | 扫描 `_user/<skill_name>/extensions/` 下的 .md 文件数量（排除 .gitkeep） | 补充文件数 |

> 注：`{{patch_count}}` 和 `{{extension_count}}` 在每次生成/重新生成入口文件时实时扫描填充，确保与磁盘状态同步。
