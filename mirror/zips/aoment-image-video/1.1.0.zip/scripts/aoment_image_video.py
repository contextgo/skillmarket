#!/usr/bin/env python3
# /// script
# requires-python = ">=3.10"
# dependencies = [
#     "requests>=2.28.0",
# ]
# ///
"""
aoment-image-video CLI

Agent API Key authenticated image and video generation powered by Aoment AI.
The client calls the dedicated skill API endpoints only.
"""

import argparse
import base64
import json
import os
import re
import sys

import requests

API_BASE = "https://www.aoment.com"

DEFAULT_IMAGE_MODEL = "image-n2-fast"
DEFAULT_VIDEO_MODEL = "video-v1"

IMAGE_TIMEOUT = 660
VIDEO_TIMEOUT = 1380


def _auth_headers(api_key: str) -> dict:
    return {"Authorization": f"Bearer {api_key}"}


def _json_or_error(response: requests.Response) -> dict:
    try:
        result = response.json()
    except ValueError:
        return {"success": False, "error": response.text or f"HTTP {response.status_code}"}

    if not response.ok and result.get("success") is not False:
        result["success"] = False
        result.setdefault("error", f"HTTP {response.status_code}")
    return result


def generate_text_to_image(api_base: str, args: argparse.Namespace) -> dict:
    url = f"{api_base}/api/skills/aoment-image-video/text-to-image"
    payload = {
        "prompt": args.prompt,
        "aspectRatio": args.aspect_ratio,
        "imageSize": args.image_size,
        "model": args.model or DEFAULT_IMAGE_MODEL,
    }

    response = requests.post(
        url, json=payload, headers=_auth_headers(args.api_key), timeout=IMAGE_TIMEOUT
    )
    result = _json_or_error(response)

    if not result.get("success"):
        return {"success": False, "error": result.get("error", "text-to-image failed")}

    return {
        "success": True,
        "tool_type": "text-to-image",
        "data": {"image_url": result.get("imageUrl")},
    }


def generate_image_to_image(api_base: str, args: argparse.Namespace) -> dict:
    url = f"{api_base}/api/skills/aoment-image-video/image-to-image"

    ref_list = args.reference_image
    if not ref_list:
        return {"success": False, "error": "image-to-image requires --reference-image"}

    data = {
        "prompt": args.prompt,
        "aspectRatio": args.aspect_ratio,
        "imageSize": args.image_size,
        "model": args.model or DEFAULT_IMAGE_MODEL,
    }
    files = {}

    reference_image = ref_list[0]
    if reference_image.startswith("http"):
        data["image"] = reference_image
    else:
        try:
            image_bytes = base64.b64decode(reference_image)
        except Exception as exc:
            return {"success": False, "error": f"invalid reference image base64: {exc}"}
        files["image"] = ("reference.png", image_bytes, "image/png")

    response = requests.post(
        url,
        data=data,
        files=files or None,
        headers=_auth_headers(args.api_key),
        timeout=IMAGE_TIMEOUT,
    )
    result = _json_or_error(response)

    if not result.get("success"):
        return {"success": False, "error": result.get("error", "image-to-image failed")}

    return {
        "success": True,
        "tool_type": "image-to-image",
        "data": {"image_url": result.get("imageUrl")},
    }


def generate_video(api_base: str, args: argparse.Namespace) -> dict:
    url = f"{api_base}/api/skills/aoment-image-video/video-generation"

    data = {
        "prompt": args.prompt,
        "model": args.model or DEFAULT_VIDEO_MODEL,
        "v1Orientation": args.orientation,
        "v1Resolution": args.resolution,
        "v1Mode": args.mode,
    }
    files_list = []

    for index, ref in enumerate(args.reference_image or []):
        if ref.startswith("http"):
            data[f"referenceImageUrl_{index}"] = ref
        else:
            try:
                image_bytes = base64.b64decode(ref)
            except Exception as exc:
                return {"success": False, "error": f"invalid reference image base64: {exc}"}
            files_list.append(
                ("referenceImage", (f"reference-{index}.png", image_bytes, "image/png"))
            )

    response = requests.post(
        url,
        data=data,
        files=files_list or None,
        headers=_auth_headers(args.api_key),
        timeout=VIDEO_TIMEOUT,
    )
    result = _json_or_error(response)

    if not result.get("success"):
        return {"success": False, "error": result.get("error", "video generation failed")}

    return {
        "success": True,
        "tool_type": "video-generation",
        "data": {"video_url": result.get("videoUrl")},
    }


def _read_local_version() -> str | None:
    try:
        skill_md = os.path.join(os.path.dirname(__file__), "..", "SKILL.md")
        with open(skill_md, "r", encoding="utf-8") as file:
            content = file.read()
        match = re.search(r"^version:\s*(.+)$", content, re.MULTILINE)
        return match.group(1).strip() if match else None
    except Exception:
        return None


def _compare_versions(local: str, remote: str) -> int:
    def parse(version: str) -> tuple:
        return tuple(int(part) for part in version.split("."))

    try:
        local_parts, remote_parts = parse(local), parse(remote)
        return (local_parts > remote_parts) - (local_parts < remote_parts)
    except Exception:
        return 0


def _check_version(api_base: str) -> None:
    local_version = _read_local_version()
    if not local_version:
        return

    try:
        response = requests.get(f"{api_base}/api/skills/aoment-image-video/version", timeout=5)
        data = response.json()
        if not data.get("success"):
            return
        remote_version = data.get("data", {}).get("version")
        if remote_version and _compare_versions(local_version, remote_version) < 0:
            json.dump(
                {
                    "success": False,
                    "error": "update_required",
                    "current_version": local_version,
                    "latest_version": remote_version,
                    "message": (
                        f"Skill version is outdated (current {local_version}, "
                        f"latest {remote_version}). Download the latest package and retry."
                    ),
                },
                sys.stdout,
                ensure_ascii=False,
                indent=2,
            )
            print()
            sys.exit(1)
    except Exception:
        return


def main():
    parser = argparse.ArgumentParser(description="aoment-image-video generation CLI")
    parser.add_argument("--api-key", "-k", required=True, help="Agent API Key")
    parser.add_argument(
        "--tool-type",
        "-t",
        required=True,
        choices=["text-to-image", "image-to-image", "video-generation"],
        help="Tool type",
    )
    parser.add_argument("--prompt", "-p", required=True, help="Prompt")
    parser.add_argument(
        "--model",
        default=None,
        help=(
            "Model ID. Image default: image-n2-fast. Video default: video-v1. "
            "Image models: image-n2-fast, image-n2, image-n1-fast, image-n1, image-o2."
        ),
    )
    parser.add_argument("--aspect-ratio", default="auto", help="Image aspect ratio")
    parser.add_argument("--image-size", default="1K", help="Image size: 1K, 2K, or 4K")
    parser.add_argument(
        "--reference-image",
        action="append",
        default=None,
        help="Reference image as Base64 data or URL. Can be specified multiple times for video.",
    )
    parser.add_argument(
        "--orientation",
        default="portrait",
        choices=["portrait", "landscape"],
        help="Video orientation",
    )
    parser.add_argument(
        "--resolution",
        default="standard",
        choices=["standard", "hd", "4k"],
        help="Video resolution",
    )
    parser.add_argument(
        "--mode",
        default="standard",
        help="Compatibility option. The current video backend uses standard mode.",
    )
    args = parser.parse_args()

    _check_version(API_BASE)

    try:
        if args.tool_type == "text-to-image":
            result = generate_text_to_image(API_BASE, args)
        elif args.tool_type == "image-to-image":
            result = generate_image_to_image(API_BASE, args)
        else:
            result = generate_video(API_BASE, args)
    except requests.exceptions.Timeout:
        result = {"success": False, "error": f"request timed out for {args.tool_type}"}
    except requests.exceptions.RequestException as exc:
        result = {"success": False, "error": f"network request failed: {exc}"}
    except Exception as exc:
        result = {"success": False, "error": f"internal error: {exc}"}

    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    print()


if __name__ == "__main__":
    main()
