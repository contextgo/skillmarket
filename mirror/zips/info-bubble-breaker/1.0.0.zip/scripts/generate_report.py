#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
破除信息茧房 - Word报告生成器
根据六步框架生成认知评估报告和行动指南
"""

import sys
import json
from datetime import datetime
from pathlib import Path

try:
    from docx import Document
    from docx.shared import Pt, RGBColor, Inches
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.oxml.ns import qn
except ImportError:
    print("请先安装依赖: pip install python-docx")
    sys.exit(1)


def create_cover(doc, date_str):
    """创建封面"""
    # 空行
    for _ in range(6):
        doc.add_paragraph()
    
    # 主标题
    title_para = doc.add_paragraph()
    title_run = title_para.add_run("破除信息茧房方案")
    title_run.font.size = Pt(28)
    title_run.font.bold = True
    title_run.font.color.rgb = RGBColor(0, 102, 153)  # 蓝色
    title_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 空行
    for _ in range(2):
        doc.add_paragraph()
    
    # 副标题
    subtitle_para = doc.add_paragraph()
    subtitle_run = subtitle_para.add_run("个人认知评估与重建计划")
    subtitle_run.font.size = Pt(16)
    subtitle_run.font.color.rgb = RGBColor(102, 102, 102)
    subtitle_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 空行
    for _ in range(4):
        doc.add_paragraph()
    
    # 日期
    date_para = doc.add_paragraph()
    date_run = date_para.add_run(date_str)
    date_run.font.size = Pt(12)
    date_run.font.color.rgb = RGBColor(128, 128, 128)
    date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 分页
    doc.add_page_break()


def add_heading_custom(doc, text, level=1):
    """添加自定义标题"""
    heading = doc.add_heading(text, level=level)
    for run in heading.runs:
        if level == 1:
            run.font.color.rgb = RGBColor(0, 102, 153)  # 蓝色
            run.font.size = Pt(18)
        elif level == 2:
            run.font.color.rgb = RGBColor(0, 153, 153)  # 青色
            run.font.size = Pt(14)
        else:
            run.font.color.rgb = RGBColor(51, 51, 51)
    return heading


def add_step_section(doc, step_num, step_name, step_key, content, color):
    """添加步骤章节"""
    # 步骤标题
    heading = add_heading_custom(doc, f"第{step_num}步：{step_name}", level=2)
    
    # 内容
    if content:
        for key, value in content.items():
            if value:
                # 子标题
                para = doc.add_paragraph()
                label = para.add_run(f"{key}：")
                label.font.bold = True
                label.font.color.rgb = RGBColor(int(color[1:3], 16), int(color[3:5], 16), int(color[5:7], 16))
                
                # 内容
                if isinstance(value, list):
                    for item in value:
                        p = doc.add_paragraph(style='List Bullet')
                        p.add_run(str(item))
                        p.paragraph_format.line_spacing = 1.5
                else:
                    content_para = doc.add_paragraph(str(value))
                    content_para.paragraph_format.line_spacing = 1.5
    
    doc.add_paragraph()


def create_diagnosis_table(doc, diagnosis):
    """创建茧房诊断表"""
    add_heading_custom(doc, "茧房诊断结果", level=2)
    
    # 创建表格
    table = doc.add_table(rows=1, cols=3)
    table.style = 'Light Grid Accent 1'
    
    # 表头
    hdr_cells = table.rows[0].cells
    hdr_cells[0].text = '测试项目'
    hdr_cells[1].text = '结果'
    hdr_cells[2].text = '评估'
    
    # 设置表头样式
    for cell in hdr_cells:
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.bold = True
                run.font.color.rgb = RGBColor(255, 255, 255)
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 添加数据行
    tests = [
        ("回音壁测试", diagnosis.get('echo_test', '')),
        ("情绪惯性测试", diagnosis.get('emotion_test', '')),
        ("逻辑起点测试", diagnosis.get('logic_test', '')),
    ]
    
    for test_name, result in tests:
        row_cells = table.add_row().cells
        row_cells[0].text = test_name
        row_cells[1].text = result
        row_cells[2].text = "健康" if result == "健康" else ("轻度" if result == "轻度茧房" else "重度")
    
    doc.add_paragraph()
    
    # 综合评估
    overall = diagnosis.get('overall', '')
    if overall:
        para = doc.add_paragraph()
        label = para.add_run("综合评估：")
        label.font.bold = True
        para.add_run(f"\n{overall}")
    
    doc.add_paragraph()


def create_action_plan(doc, action_plan):
    """创建行动计划"""
    add_heading_custom(doc, "30天破除计划", level=2)
    
    # 每日行动
    daily_actions = action_plan.get('daily_actions', [])
    if daily_actions:
        add_heading_custom(doc, "每日行动清单", level=3)
        for i, action in enumerate(daily_actions, 1):
            para = doc.add_paragraph(style='List Number')
            para.add_run(f"第{i}天：{action}")
            para.paragraph_format.line_spacing = 1.5
        doc.add_paragraph()
    
    # 周计划
    weekly_plan = action_plan.get('weekly_plan', [])
    if weekly_plan:
        add_heading_custom(doc, "周计划", level=3)
        for week in weekly_plan:
            para = doc.add_paragraph()
            label = para.add_run(f"第{week.get('week', '')}周：")
            label.font.bold = True
            para.add_run(week.get('focus', ''))
            para.paragraph_format.line_spacing = 1.5
        doc.add_paragraph()


def generate_report(data, output_path):
    """生成完整的破除方案"""
    doc = Document()
    
    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = 'Microsoft YaHei'
    style._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
    style.font.size = Pt(11)
    
    # 提取数据
    date_str = data.get('date', datetime.now().strftime('%Y年%m月%d日'))
    diagnosis = data.get('diagnosis', {})
    
    # 1. 封面
    create_cover(doc, date_str)
    
    # 2. 茧房诊断报告
    add_heading_custom(doc, "茧房诊断报告", level=1)
    doc.add_paragraph()
    
    if diagnosis:
        create_diagnosis_table(doc, diagnosis)
    
    # 分页
    doc.add_page_break()
    
    # 3. 六步破除方案
    add_heading_custom(doc, "六步破除方案", level=1)
    doc.add_paragraph()
    
    steps = [
        ("一", "觉察（Awareness）", 'awareness', "#FF6B6B"),
        ("二", "溯源（Traceability）", 'traceability', "#4ECDC4"),
        ("三", "异质化（Heterogenization）", 'heterogenization', "#45B7D1"),
        ("四", "多维建模（Multi-dimensional）", 'multidimensional', "#96CEB4"),
        ("五", "批判性思维（Critical Thinking）", 'critical', "#DDA0DD"),
        ("六", "知行合一（Action & Reflection）", 'action', "#F7DC6F"),
    ]
    
    for step_num, step_name, step_key, color in steps:
        step_content = data.get(step_key, {})
        if step_content:
            add_step_section(doc, step_num, step_name, step_key, step_content, color)
    
    # 分页
    doc.add_page_break()
    
    # 4. 行动指南
    add_heading_custom(doc, "行动指南", level=1)
    doc.add_paragraph()
    
    action_plan = data.get('action_plan', {})
    if action_plan:
        create_action_plan(doc, action_plan)
    
    # 5. 资源推荐
    add_heading_custom(doc, "资源推荐", level=1)
    doc.add_paragraph()
    
    # 异质化信息源
    sources = data.get('heterogeneous_sources', [])
    if sources:
        add_heading_custom(doc, "异质化信息源", level=2)
        for source in sources:
            para = doc.add_paragraph(style='List Bullet')
            para.add_run(source)
            para.paragraph_format.line_spacing = 1.5
        doc.add_paragraph()
    
    # 经典阅读
    classics = data.get('classics', [])
    if classics:
        add_heading_custom(doc, "经典阅读书单", level=2)
        for book in classics:
            para = doc.add_paragraph(style='List Bullet')
            para.add_run(book)
            para.paragraph_format.line_spacing = 1.5
        doc.add_paragraph()
    
    # 工具推荐
    tools = data.get('tools', [])
    if tools:
        add_heading_custom(doc, "批判性思维工具", level=2)
        for tool in tools:
            para = doc.add_paragraph(style='List Bullet')
            para.add_run(tool)
            para.paragraph_format.line_spacing = 1.5
    
    # 保存文档
    doc.save(output_path)
    print(f"[OK] 破除信息茧房方案已生成: {output_path}")


def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python generate_report.py <json文件> [输出路径]")
        print("示例: python generate_report.py data.json 破除茧房方案.docx")
        sys.exit(1)
    
    json_file = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else "破除信息茧房方案.docx"
    
    # 读取JSON数据
    with open(json_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    # 生成报告
    generate_report(data, output_path)


if __name__ == '__main__':
    main()
