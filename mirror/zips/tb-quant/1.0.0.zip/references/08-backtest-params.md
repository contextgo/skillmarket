# 回测参数设置

## 回测模式配置

在TB终端的"回测设置"中配置以下参数：

| 参数 | 说明 | 默认值 |
|------|------|--------|
| 初始资金 | 策略启动时的资金 | 1,000,000 |
| 手续费率 | 交易手续费比例 | 0.00025 (万五) |
| 滑点 | 价格滑点比例 | 0.001 (0.1%) |
| 复权方式 | 前复权/后复权 | 前复权 (ADJUST_PREV) |
| 回测区间 | 开始~结束日期 | 根据需要设置 |
| 最大回撤限制 | 超过则停止回测 | 无限制 |

## Run() 函数参数

```text
Run(strategy_id, filename, mode, token, ...)
```

| 参数 | 类型 | 说明 |
|------|------|------|
| strategy_id | String | 策略ID，用于标识策略 |
| filename | String | 策略文件名（不带.tc4后缀） |
| mode | Integer | 运行模式：1=实时，2=回测 |
| token | String | API Token（实盘需要） |
| backtest_start_time | String | 回测开始时间 `%Y-%m-%d %H:%M:%S` |
| backtest_end_time | String | 回测结束时间 `%Y-%m-%d %H:%M:%S` |
| backtest_initial_cash | Numeric | 初始资金 |
| backtest_commission_ratio | Numeric | 佣金比例 |
| backtest_slippage_ratio | Numeric | 滑点比例 |
| backtest_adjust | Integer | 复权方式：ADJUST_NONE=0, ADJUST_PREV=1, ADJUST_POST=2 |
| serv_addr | String | 终端地址，默认本地，可指定ip:port |

### 示例
```text
Run("my_strategy", "my_strategy", MODE_BACKTEST, "your_token",
    "2024-01-01 09:00:00", "2024-12-31 15:00:00",
    1000000, 0.00025, 0.001, ADJUST_PREV)
```

## 回测结果查看

回测完成后，可以在TB终端查看：
- 收益曲线
- 最大回撤
- 夏普比率
- 持仓明细
- 交易记录
