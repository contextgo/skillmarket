# 核心函数

## Init() 初始化函数

仅在策略首次加载时执行一次，用于：
- 设置图表样式（Cat数组）
- 注册定时任务（schedule）
- 订阅行情数据（subscribe）
- 初始化策略参数

```text
void Init()
{
    // 设置图表显示
    Cat(1) = "价格";
    Cat(2) = "MA20";
    Cat(3) = "MA50";
}
```

## OnBar() K线事件函数

每根K线触发一次，是最常用的事件函数。

### 签名
```text
void OnBar(Arrayref<Integer> Indexs)
```

### 参数说明
- `Indexs`：品种索引数组，`Indexs[0]` 是当前品种的索引

### 获取当前品种
```text
String Symbol = SymInfo(0);  // 多品种用 SymInfo(Indexs[0])
```

### 示例
```text
void OnBar(Arrayref<Integer> Indexs)
{
    String Symbol = SymInfo(0);

    // 获取历史数据
    Numeric Close[];
    GetKLineData(Symbol, 0, 100, Close, 0);

    // 策略逻辑...
}
```

## OnTick() Tick事件函数

逐笔成交/委托级别触发，适用于高频策略。

### 签名
```text
void OnTick(Arrayref<Integer> Indexs)
```

### 使用场景
- 做市策略
- 套利策略
- 高频交易

## OnTimerEvent() 定时任务函数

按时间规则触发，适用于每日固定时间操作。

### 签名
```text
void OnTimerEvent(Integer Type)
```

### Type类型
- `1`：每根K线触发
- `2`：每分钟触发
- `3`：每小时触发

### 示例
```text
void OnTimerEvent(Integer Type)
{
    if(Type == 1) {
        // 每根K线触发
    }
}
```

## Run() 运行入口

```text
Run(strategy_id, filename, mode, token, ...)
```

| 参数 | 类型 | 说明 |
|------|------|------|
| strategy_id | String | 策略ID，用于标识策略 |
| filename | String | 策略文件名（不带.tc4后缀） |
| mode | Integer | 运行模式：1=实时，2=回测 |
| token | String | API Token |
| backtest_start_time | String | 回测开始时间 `%Y-%m-%d %H:%M:%S` |
| backtest_end_time | String | 回测结束时间 `%Y-%m-%d %H:%M:%S` |
| backtest_initial_cash | Numeric | 初始资金 |
| backtest_commission_ratio | Numeric | 佣金比例 |
| backtest_slippage_ratio | Numeric | 滑点比例 |
| backtest_adjust | Integer | 复权方式：ADJUST_NONE/ADJUST_PREV/ADJUST_POST |
| serv_addr | String | 终端地址，默认本地，可指定ip:port |

### 示例
```text
Run("my_strategy", "my_strategy", MODE_BACKTEST, "your_token",
    "2024-01-01 09:00:00", "2024-12-31 15:00:00",
    1000000, 0.00025, 0.001, ADJUST_PREV)
```
