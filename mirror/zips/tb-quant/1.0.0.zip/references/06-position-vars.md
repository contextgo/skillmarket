# 持仓相关内置变量

## 持仓方向判断

```text
// 多头持仓
if(MarketPosition == 1) { }

// 空头持仓
if(MarketPosition == -1) { }

// 空仓
if(MarketPosition == 0) { }
```

## 开平仓判断

```text
// 判断是否为开仓
if(BarsSinceEntry <= 0) { }  // 刚开仓

// 判断是否为平仓
if(BarsSinceEntry > 0) { }   // 已持仓
```

## 盈亏计算

```text
// 浮动盈亏（元）
Numeric Profit = PositionProfit;

// 盈亏比例
Numeric ProfitRatio = PositionProfitRatio;

// 开仓价格
Numeric EntryPrice;

// 当前价格
Numeric CurrentPrice;

// 计算盈亏
Numeric PnL = (CurrentPrice - EntryPrice) * MarketPosition * Volume;
```

## 止损止盈实现

```text
// 动态止损
Numeric StopLoss = EntryPrice - AtrPeriod * 2;  // ATR止损
if(CurrentPrice < StopLoss && MarketPosition == 1) {
    Sell(Symbol, 1, Market);  // 止损卖出
}

// 动态止盈
Numeric TakeProfit = EntryPrice + AtrPeriod * 2;
if(CurrentPrice > TakeProfit && MarketPosition == 1) {
    Sell(Symbol, 1, Market);  // 止盈卖出
}
```
