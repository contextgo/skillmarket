# 掘金量化 vs 开拓者(TB) API对照手册

## 一、事件函数对比

| 功能 | 掘金量化 (GM) | 开拓者(TB) | 对照说明 |
|------|--------------|-----------|---------|
| **初始化** | `def init(context):` | `void Init()` | GM用Python def，TB用C++ void |
| **K线触发** | `def on_bar(context, bars):` | `void OnBar(Arrayref<Integer> Indexs)` | GM传bars数组，TB传Indexs索引 |
| **Tick触发** | `def on_tick(context, tick):` | `void OnTick(Arrayref<Integer> Indexs)` | 两者签名类似 |
| **定时任务** | `schedule(frequency='1d', time_rule='09:30')` | `OnTimerEvent(Type)` | GM用schedule装饰器，TB用内置函数 |
| **运行入口** | `run(strategy_id, filename, mode, ...)` | `Run(strategy_id, filename, mode, ...)` | 参数几乎一致 |

## 二、数据查询API对比

### 2.1 当前行情

| 功能 | GM | TB | 差异 |
|------|-----|-----|------|
| **查询当前行情** | `current(symbols)` | `current(Symbols)` | 参数类型不同，GM用list，TB用Array |
| **返回字段** | symbol, price, volume, ... | symbol, open, high, low, close, ... | TB字段更详细 |
| **实时模式** | 返回最新tick | 返回最新K线 | GM更细粒度 |

### 2.2 历史数据

| 功能 | GM | TB | 差异 |
|------|-----|-----|------|
| **查询历史** | `history(symbol, frequency, start, end, fields)` | `GetKLineData(Symbol, Start, Count, Array, FieldType)` | GM按时间范围，TB按数量+偏移 |
| **频率支持** | `'1d'`, `'60s'`, `'300s'`, `'tick'` | `'1d'`, `'60s'`, `'300s'` | GM支持tick，TB不支持 |
| **多标的** | 支持逗号分隔 | 需循环调用 | GM更方便 |
| **DataFrame** | `df=True` 返回DataFrame | 无，需手动处理 | GM更友好 |
| **停牌处理** | `skip_suspended=True` | 无此参数 | GM自动跳过 |

### 2.3 订阅数据滑窗

| 功能 | GM | TB | 差异 |
|------|-----|-----|------|
| **订阅行情** | `subscribe(symbols, frequency, count, fields)` | `subscribe(Array, Frequency, Count, Fields)` | 语法相似，GM更简洁 |
| **获取滑窗** | `context.data(symbol, frequency, count)` | 无，需用`GetKLineData` | TB需手动实现 |
| **格式化输出** | `format='df'/'row'/'col'` | 无 | GM支持多种格式 |

## 三、下单API对比

### 3.1 开仓平仓指令

| 功能 | GM | TB | 关键差异 |
|------|-----|-----|---------|
| **多头开仓** | `order_volume(..., position_effect=PositionEffect_Open)` | `Buy(Symbol, Volume, PriceType)` | TB更简洁，直接用Buy/Sell |
| **多头平仓** | `order_target_volume(..., position_side=PositionSide_Long)` | `Sell(Symbol, Volume, PriceType)` | TB无需position_side参数 |
| **空头开仓** | `credit_short_selling(...)` | `SellShort(Symbol, Volume, PriceType)` | TB更直观 |
| **空头平仓** | `credit_buying_on_repayment(...)` | `BuyToCover(Symbol, Volume, PriceType)` | TB更简洁 |
| **平今/平昨** | 无 | `CloseToday/CloseYesterday` | TB期货专用 |
| **价格类型** | `Market/Limit` | `Market/Limit` | 相同 |

### 3.2 批量/算法单

| 功能 | GM | TB | 差异 |
|------|-----|-----|------|
| **批量下单** | `order_batch(orders)` | 需循环调用 | GM更方便 |
| **算法单** | `algo_order(...)` | 无 | GM有专门接口 |
| **撤单** | `order_cancel(cl_ord_id)` | 无 | GM有撤单功能 |
| **持仓查询** | `get_position()` | `MarketPosition`变量 | TB直接用变量，GM需调用函数 |
| **账户查询** | `get_cash()` | 无 | GM有完整账户API |

## 四、持仓管理对比

| 功能 | GM | TB | 差异 |
|------|-----|-----|------|
| **持仓方向** | `position.side` | `MarketPosition`变量 | TB直接用变量，GM需访问对象属性 |
| **持仓量** | `position.volume` | 无，需计算 | GM更方便 |
| **浮动盈亏** | `position.pnl` | `PositionProfit`变量 | TB直接用变量 |
| **开仓价** | `position.entry_price` | `EntryPrice`变量 | TB直接用变量 |
| **持仓天数** | 无 | `BarsSinceEntry`变量 | TB专属 |
| **止损止盈** | 无内置 | 需手动计算后调用Buy/Sell | TB需自己实现 |
| **复权方式** | `adjust=ADJUST_PREV` | `backtest_adjust=ADJUST_PREV` | 参数名不同 |

## 五、技术指标对比

| 指标 | GM | TB | 差异 |
|------|-----|-----|------|
| **移动平均** | `data['close'].rolling(N).mean()` | `CalculateMA(Close, N, Period, Ma)` | GM用pandas，TB用C函数 |
| **MACD** | `data['close'].diff(12).divide(data['close'].diff(26)-data['close'].diff(12)).rolling(9).mean()` | `CalculateMACD(Close, Period, Fast, Slow, Signal, Dif, Dea, Macd)` | GM代码长，TB函数简洁 |
| **RSI** | `100 - 100/(1+rs)` | `CalculateRSI(Close, Period, Rsi)` | TB有专用函数 |
| **布林带** | `(data['close'] - data['close'].rolling(N).mean()) / data['close'].rolling(N).std() * 2` | `CalculateBollinger(Close, N, StdDev, Upper, Lower, Mid)` | TB函数封装更好 |
| **ATR** | 无内置 | `CalculateATR(High, Low, Close, N, Atr)` | TB有专用函数 |
| **自定义指标** | 可定义class继承Indicator | 可用`Indicator(Name, Param)`引用 | GM更灵活 |

## 六、回测参数对比

| 参数 | GM | TB | 是否一致 |
|------|-----|-----|---------|
| **初始资金** | `backtest_initial_cash` | `backtest_initial_cash` | ✅ 一致 |
| **佣金比例** | `backtest_commission_ratio` | `backtest_commission_ratio` | ✅ 一致 |
| **滑点比例** | `backtest_slippage_ratio` | `backtest_slippage_ratio` | ✅ 一致 |
| **复权方式** | `backtest_adjust` (0/1/2) | `backtest_adjust` (0/1/2) | ✅ 一致 |
| **撮合模式** | `backtest_match_mode` (0/1) | 无 | GM有，TB默认 |
| **缓存检查** | `backtest_check_cache` | 无 | GM有，TB默认开启 |
| **终端地址** | `serv_addr` | `serv_addr` | ✅ 一致 |
| **成交比例** | `backtest_transaction_ratio` | 无 | GM有，TB固定1.0 |

## 七、枚举常量对比

### 7.1 订单状态 OrderStatus

| 值 | GM | TB | 说明 |
|-----|-----|-----|------|
| 新建 | 1 | 1 | ✅ 一致 |
| 已报 | 2 | 2 | ✅ 一致 |
| 部分成交 | 3 | 3 | ✅ 一致 |
| 已成交 | 4 | 4 | ✅ 一致 |
| 已撤 | 5 | 5 | ✅ 一致 |
| 拒绝 | 7 | 7 | ✅ 一致 |
| 待撤 | 8 | 8 | ✅ 一致 |
| 未知/内部态 | 9/10 | 10 | ⚠️ TB有内部态10 |

### 7.2 订单类型 OrderType

| 值 | GM | TB | 说明 |
|-----|-----|-----|------|
| 市价单 | 1 | 1 | ✅ 一致 |
| 限价单 | 2 | 2 | ✅ 一致 |

### 7.3 买卖方向 OrderSide

| 值 | GM | TB | 说明 |
|-----|-----|-----|------|
| 买入 | 1 | 1 | ✅ 一致 |
| 卖出 | 2 | 2 | ✅ 一致 |

### 7.4 复权方式 AdjustType

| 值 | GM | TB | 说明 |
|-----|-----|-----|------|
| 不复权 | 0 | 0 | ✅ 一致 |
| 前复权 | 1 | 1 | ✅ 一致 |
| 后复权 | 2 | 2 | ✅ 一致 |

## 八、开发体验对比

| 维度 | 掘金量化 (GM) | 开拓者(TB) | 评价 |
|------|--------------|-----------|------|
| **语言** | Python | C++ | GM更易学，TB性能更好 |
| **语法** | Pythonic，简洁 | C++风格，冗长 | GM更适合快速原型 |
| **调试** | PyCharm/VSCode，断点调试 | TB终端，print调试 | GM调试更方便 |
| **第三方库** | pandas, numpy, scikit-learn | 有限 | GM生态丰富 |
| **策略模板** | 标准类结构 | region划分 | GM更清晰 |
| **中文注释** | 支持 | 支持 | 都好 |
| **版本控制** | Git | TB自带 | GM更方便协作 |
| **文档** | Sphinx生成 | TB帮助文档 | GM更详细 |
| **社区** | 掘金社区 | TB论坛 | GM活跃度高 |
| **学习曲线** | 低，Python基础即可 | 中，需学C++语法 | GM更容易上手 |
| **性能** | Python解释执行，较慢 | C++编译执行，快10-100倍 | TB性能优势明显 |
| **实时交易** | 需要终端保持打开 | 需要连接行情服务 | 都需要额外配置 |
| **实盘部署** | 掘金终端网页 | TB软件 | GM更便捷 |

## 九、适用场景建议

### 选择掘金量化(GM)如果：
- ✅ 初学者，不懂C++
- ✅ 需要快速验证想法（回测快）
- ✅ 使用机器学习/深度学习模型
- ✅ 需要丰富的第三方库（pandas, scikit-learn, tensorflow）
- ✅ 团队协作，多人开发
- ✅ 数据分析、特征工程需求多
- ✅ 不想安装重型软件（TB）
- ✅ 策略复杂度高，需要大量数据处理

### 选择开拓者(TB)如果：
- ✅ 专业量化交易员，熟悉C++
- ✅ 追求极致性能（高频/CTA）
- ✅ 期货交易（TB对期货支持更好）
- ✅ 需要极低延迟（<10ms）
- ✅ 长期稳定运行（TB更稳定）
- ✅ 复杂算法策略（海龟交易、统计套利）
- ✅ 本地部署，不依赖网络
- ✅ 策略逻辑简单，追求代码简洁

## 十、混合使用建议

实际项目中，可以**混合使用**两者优势：

```text
方案：GM做策略研发 + TB做实盘部署

步骤：
1. GM中快速迭代策略，利用其生态系统
2. 将核心算法移植到TB，优化性能
3. TB负责实盘交易，保证稳定性和速度
4. GM继续用于回测、分析、可视化
```

**示例工作流：**
```text
周一：在GM中测试新策略，用pandas分析数据
周二：策略有效，用TB重写核心逻辑，优化性能
周三：TB回测，调整参数
周四：仿真环境测试，观察表现
周五：实盘部署，监控运行
周末：回到GM，分析绩效，准备下一轮迭代
```
