# K线数据 & 历史数据查询

## GetKLineData() 获取K线数据

### 语法
```text
GetKLineData(String Symbol, Integer StartIndex, Integer Count, Arrayref<Numeric> OutArray, Integer FieldType)
```

### 参数说明
| 参数 | 类型 | 说明 |
|------|------|------|
| Symbol | String | 品种代码，如 `"SHFE.ag2506"` |
| StartIndex | Integer | 起始索引（0表示从最新开始） |
| Count | Integer | 获取数量 |
| OutArray | Arrayref<Numeric> | 输出数组，存储各字段值 |
| FieldType | Integer | 字段类型：0=收盘价，1=开盘价，2=最高价，3=最低价，4=成交量，5=持仓量 |

### 示例
```text
// 获取最近100根K线的收盘价
Numeric Close[];
GetKLineData("SHFE.ag2506", 0, 100, Close, 0);

// 获取多字段数据
Numeric Open[], High[], Low[], Volume[];
GetKLineData("SHFE.ag2506", 0, 100, Open, 1);  // 开盘价
GetKLineData("SHFE.ag2506", 0, 100, High, 2);   // 最高价
GetKLineData("SHFE.ag2506", 0, 100, Low, 3);    // 最低价
GetKLineData("SHFE.ag2506", 0, 100, Volume, 4); // 成交量
```

## current() 查询实时行情

### 语法
```text
current(Arrayref<String> Symbols, Arrayref<Integer> Frequencies)
```

### 返回字段
| 字段 | 说明 |
|------|------|
| symbol | 品种代码 |
| open | 开盘价 |
| high | 最高价 |
| low | 最低价 |
| close | 最新价 |
| volume | 成交量 |
| amount | 成交额 |
| frequency | 周期 |
| timestamp | 时间戳 |

### 示例
```text
Array<String> Symbols = Array("SHFE.ag2506");
current(Symbols);
```

## history() 查询历史数据

### 语法
```text
history(String Symbol, String Frequency, String StartTime, String EndTime, Integer Count, Arrayref<String> Fields, Boolean SkipSuspended, String FillMethod)
```

### 参数说明
| 参数 | 类型 | 说明 |
|------|------|------|
| Symbol | String | 品种代码 |
| Frequency | String | 周期：`1d`, `60s`, `300s` |
| StartTime | String | 开始时间，格式：`"2024-01-01 09:00:00"` |
| EndTime | String | 结束时间 |
| Count | Integer | 返回条数限制，-1表示全部 |
| Fields | Arrayref<String> | 需要的字段，逗号分隔 |
| SkipSuspended | Boolean | 是否跳过停牌日，默认True |
| FillMethod | String | 填充方法：`pre`(前填), `post`(后填), `None`(不填) |

### 示例
```text
// 查询2024年1月的日线数据
history("SHFE.ag2506", "1d", "2024-01-01 09:00:00", "2024-01-31 15:00:00", -1, Array("close"))

// 查询分钟线数据
history("SHFE.ag2506", "60s", "2024-01-01 09:00:00", "2024-01-01 15:00:00", -1, Array("low", "high"))
```

## 常用数据操作函数

| 函数 | 说明 | 示例 |
|------|------|------|
| Max(Array) | 最大值 | `Max(Close[0:10])` |
| Min(Array) | 最小值 | `Min(Low[0:10])` |
| Average(Array) | 平均值 | `Average(Close[0:10])` |
| StdDev(Array) | 标准差 | `StdDev(Close[0:10])` |
| Sum(Array) | 总和 | `Sum(Volume[0:10])` |
| GetValue(Offset, Array, Out) | 获取指定偏移量 | `GetValue(-1, Close, Latest)` |
