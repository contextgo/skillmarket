# 快速开始 & 策略架构

## 策略三大结构

开拓者(TradeBlazer)策略主要有 3 种结构：

### 1. 定时任务型
```text
// 每日固定时间执行
void Init() { }

void OnTimerEvent(Integer Type) {
    if(Type == 1) { // 每根K线触发
        // 策略逻辑
    }
}
```

### 2. 数据事件驱动型（最常用）
```text
// K线触发、技术指标
void OnBar(Arrayref<Integer> Indexs) {
    String Symbol = SymInfo(0);
    // 策略逻辑
}
```

### 3. 时间序列滑窗型
```text
// 需要历史数据计算
void OnBar(Arrayref<Integer> Indexs) {
    String Symbol = SymInfo(0);
    Numeric Close[];
    GetKLineData(Symbol, 0, 100, Close, 0);
    // 使用Close数组进行计算
}
```

## 运行模式

| 模式 | 常量 | 说明 |
|------|------|------|
| 实时模式 | `MODE_LIVE = 1` | 仿真/实盘交易，接收实时行情 |
| 回测模式 | `MODE_BACKTEST = 2` | 历史数据回放，快速验证策略 |

## 策略文件结构

```text
// ============================================================
// 策略名称：{name}
// 策略描述：{description}
// 生成时间：{date}
// ============================================================

#region 配置区 —— 用户可通过修改此处调整策略参数
Vars Numeric MaPeriod(20);           // 均线周期
Vars Numeric AtrPeriod(14);          // ATR周期
Vars Numeric StopLossPct(0.05);      // 止损比例
#endregion

#region 初始化 —— 仅在首次运行时执行一次
void Init()
{
    // 设置图表样式
    Cat(1) = "MA策略";
}
#endregion

#region 主循环 —— 每根K线触发
void OnBar(Arrayref<Integer> Indexs)
{
    // 获取当前品种
    String Symbol = SymInfo(0);

    // ========================================
    // 【策略核心】在此处实现买卖信号
    // ========================================
}
#endregion
```

## Run() 运行入口全解

| 参数 | 类型 | 说明 |
|------|------|------|
| strategy_id | String | 策略ID，用于标识策略 |
| filename | String | 策略文件名（不带.tc4后缀） |
| mode | Integer | MODE_LIVE=1 / MODE_BACKTEST=2 |
| token | String | API Token（实盘需要） |
| backtest_start_time | String | 回测开始时间 `%Y-%m-%d %H:%M:%S` |
| backtest_end_time | String | 回测结束时间 `%Y-%m-%d %H:%M:%S` |
| backtest_initial_cash | Numeric | 初始资金，默认1000000 |
| backtest_commission_ratio | Numeric | 佣金比例，默认0.00025 |
| backtest_slippage_ratio | Numeric | 滑点比例，默认0.001 |
| backtest_adjust | Integer | 复权方式：ADJUST_NONE=0, ADJUST_PREV=1, ADJUST_POST=2 |
| serv_addr | String | 终端地址，默认本地，可指定ip:port |

```text
Run("my_strategy", "my_strategy", MODE_BACKTEST, "your_token",
    "2024-01-01 09:00:00", "2024-12-31 15:00:00",
    1000000, 0.00025, 0.001, ADJUST_PREV)
```

## 注意事项

- filename必须与实际文件名一致（不带.tc4后缀）
- 前复权/后复权回测不处理分红送转事件（已通过复权因子调整）
- 不复权模式会自动处理分红送转
- 回测模式下Init()中不能执行交易操作，只能在OnBar()中执行
