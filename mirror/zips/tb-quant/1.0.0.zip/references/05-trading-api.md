# 下单API全集

## 开仓平仓指令

### Buy() 多头开仓（市价）
```text
Buy(String Symbol, Integer Volume, Integer PriceType)
```
| 参数 | 说明 |
|------|------|
| Symbol | 品种代码，如 `"SHFE.ag2506"` |
| Volume | 手数 |
| PriceType | 价格类型：`Market`(市价), `Limit`(限价) |

**示例：**
```text
Buy("SHFE.ag2506", 1, Market);  // 市价开多1手
Buy("SHFE.ag2506", 1, Limit, 4500);  // 限价开多1手，价格4500
```

### Sell() 多头平仓（市价）
```text
Sell(String Symbol, Integer Volume, Integer PriceType)
```

**示例：**
```text
Sell("SHFE.ag2506", 1, Market);  // 市价平多1手
```

### SellShort() 空头开仓（市价）
```text
SellShort(String Symbol, Integer Volume, Integer PriceType)
```

**示例：**
```text
SellShort("SHFE.ag2506", 1, Market);  // 市价开空1手
```

### BuyToCover() 空头平仓（市价）
```text
BuyToCover(String Symbol, Integer Volume, Integer PriceType)
```

**示例：**
```text
BuyToCover("SHFE.ag2506", 1, Market);  // 市价平空1手
```

## 平今/平昨（期货专用）

| 函数 | 说明 |
|------|------|
| CloseToday | 平今仓 |
| CloseYesterday | 平昨仓 |

**示例：**
```text
Sell("SHFE.ag2506", 1, CloseToday);  // 平今仓
```

## 持仓相关内置变量

| 变量 | 含义 | 示例 |
|------|------|------|
| MarketPosition | 当前持仓方向 | `MarketPosition == 1`(多), `-1`(空), `0`(空仓) |
| BarsSinceEntry | 持仓天数 | - |
| EntryPrice | 开仓价格 | - |
| ExitPrice | 平仓价格 | - |
| PositionProfit | 浮动盈亏 | - |
| PositionProfitRatio | 盈亏比例 | - |

## 订单状态查询

| 状态码 | 含义 |
|--------|------|
| 1 | 新建 |
| 3 | 部分成交 |
| 4 | 全部成交 |
| 5 | 已撤 |
| 7 | 拒绝 |
| 8 | 待撤 |
| 10 | 回测内部态 |
