# 技术指标计算

## 移动平均 (MA)

```text
// 计算简单移动平均
Numeric Ma[];
CalculateMA(Close, COUNT, Period, Ma);

// 参数说明
// Close: 收盘价数组
// COUNT: 数据长度
// Period: 周期
// Ma: 输出数组
```

**示例：**
```text
Numeric Close[], Ma20[], Ma50[];
GetKLineData("SHFE.ag2506", 0, 100, Close, 0);
CalculateMA(Close, 100, 20, Ma20);
CalculateMA(Close, 100, 50, Ma50);

// MA交叉判断
if(Ma20[99] > Ma50[99] && Ma20[98] <= Ma50[98]) {
    // 金叉，买入
}
```

## MACD

```text
Numeric Dif[], Dea[], Macd[];
CalculateMACD(Close, Period, FastPeriod, SlowPeriod, SignalPeriod, Dif, Dea, Macd);
```

**参数：**
- `Close`: 收盘价数组
- `Period`: 周期
- `FastPeriod`: 快线周期（默认12）
- `SlowPeriod`: 慢线周期（默认26）
- `SignalPeriod`: 信号线周期（默认9）

## RSI

```text
Numeric Rsi[];
CalculateRSI(Close, Period, Rsi);
```

## 布林带 (Bollinger Bands)

```text
Numeric Upper[], Lower[], Mid[];
CalculateBollinger(Close, Period, StdDev, Upper, Lower, Mid);
```

**参数：**
- `Close`: 收盘价数组
- `Period`: 周期（默认20）
- `StdDev`: 标准差倍数（默认2）

## ATR (Average True Range)

```text
Numeric Atr[];
CalculateATR(High, Low, Close, Period, Atr);
```

**参数：**
- `High`: 最高价数组
- `Low`: 最低价数组
- `Close`: 收盘价数组
- `Period`: 周期（默认14）
- `Atr`: 输出数组
