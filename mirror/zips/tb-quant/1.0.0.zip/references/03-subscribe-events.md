# 行情订阅与事件回调

## subscribe() 订阅行情

### 语法
```text
subscribe(Arrayref<String> Symbols, String Frequency, Integer Count, Arrayref<String> Fields)
```

### 参数说明
| 参数 | 类型 | 说明 |
|------|------|------|
| Symbols | Arrayref<String> | 品种代码数组，如 `["SHFE.ag2506", "SHFE.au2506"]` |
| Frequency | String | K线周期：`1d`(日线), `60s`(分钟), `300s`(5分钟) |
| Count | Integer | 订阅K线数量（滑窗大小） |
| Fields | Arrayref<String> | 需要的字段，如 `["close", "high", "low"]` |

### 示例
```text
// 订阅日线数据
subscribe(Array("SHFE.ag2506"), "1d", 100, Array("close"))

// 订阅多品种
subscribe(Array("SHFE.ag2506", "SHFE.au2506"), "1d", 100, Array("close"))
```

## unsubcribe() 取消订阅

```text
unsubscribe(Arrayref<String> Symbols)
```

## OnBar 事件触发条件

| 条件 | 说明 |
|------|------|
| 新K线产生 | 每根K线收盘后触发一次 |
| 定时任务 | schedule设置的时间点触发 |
| 手动触发 | Run函数执行时触发 |

## 常用事件类型

| 事件 | 触发时机 | 适用场景 |
|------|---------|---------|
| OnBar | 每根K线 | 技术指标、趋势跟踪 |
| OnTick | 逐笔成交 | 高频交易、做市 |
| OnTimer | 定时任务 | 每日固定操作 |
| OnOrder | 订单状态变化 | 订单跟踪 |
| OnTrade | 成交回报 | 成交确认 |

## 交易事件回调

| 函数 | 触发时机 | 用途 |
|------|---------|------|
| on_execution_report(context, execrpt) | 委托执行时 | 成交确认、手续费计算 |
| on_order_status(context, order) | 委托状态变更 | 订单跟踪、拒单处理 |
| on_account_status(context, account) | 账户状态变更 | 资金监控 |
| on_error(context, code, info) | 发生异常时 | 错误处理 |
| on_parameter(context, parameter) | 动态参数修改 | UI调参 |
| on_backtest_finished(context, indicator) | 回测结束时 | 绩效分析 |
