#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
TB策略模板生成器 - 从自然语言描述生成标准.tc4策略文件
"""

import os
import sys
from datetime import datetime

# TB语法转义
ESCAPE_CHARS = {'<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;'}

def escape_tb_code(text):
    """转义TB代码中的特殊字符"""
    for char, replacement in ESCAPE_CHARS.items():
        text = text.replace(char, replacement)
    return text

def generate_ma_strategy(name, description, config_params, signal_logic, risk_control="无"):
    """生成双均线策略模板"""
    
    # 配置区
    config_region = f"#region 配置区 —— 用户可通过修改此处调整策略参数\n"
    vars_line = ""
    for var_name, var_type, default_value, comment in config_params:
        if var_type == "Numeric":
            vars_line += f"Vars Numeric {var_name}({default_value});           // {comment}\n"
    config_region += vars_line + "#endregion\n\n"
    
    # 初始化区
    init_region = """#region 初始化 —— 仅在首次运行时执行一次
void Init()
{
    // 设置图表样式
    Cat(1) = "MA策略";
}
#endregion\n\n"""
    
    # 主循环区
    main_loop = f"""#region 主循环 —— 每根K线触发
void OnBar(Arrayref<Integer> Indexs)
{
    // 获取当前品种
    String Symbol = SymInfo(0);
    
    // ========================================
    // 【策略核心】{description}
    // ========================================
    
    // 示例：双均线策略
    Numeric Close[];
    GetKLineData(Symbol, 0, 100, Close, 0);  // 获取收盘价数组
    
    Numeric MaShort, MaLong;
    CalculateMA(Close, 100, {config_params[0][2]}, MaShort);
    CalculateMA(Close, 100, {config_params[1][2] * 2}, MaLong);
    
    // 判断金叉/死叉
    if(MaShort[99] > MaLong[99] && MaShort[98] <= MaLong[98])
    {{
        // 金叉，买入
        Buy(Symbol, 1, Market);  // 开1手，市价单
    }}
    else if(MaShort[99] < MaLong[99] && MaShort[98] >= MaLong[98])
    {{
        // 死叉，卖出
        Sell(Symbol, 1, Market);  // 平1手，市价单
    }}
}
#endregion\n\n"""
    
    # 辅助函数区
    helper_region = """#region 辅助函数 —— 可选
// 计算移动平均
void CalculateMA(NumericRef Data, Integer Length, Numeric Period, NumericRef OutResult)
{{
    Numeric Sum = 0;
    for(Integer i = 0; i < Period; i++) Sum += Data[Length-Period+i];
    OutResult = Sum / Period;
}}
#endregion\n\n"""
    
    # 运行入口区
    run_entry = """# ============================================================
# 启动入口
# ============================================================
if __name__ == '__main__':
    // 本地运行无需token，直接调用Run
    Run("{name}", "{name}", MODE_BACKTEST, "",
        "2024-01-01 09:00:00", "2024-12-31 15:00:00",
        1000000, 0.00025, 0.001, ADJUST_PREV)
""".format(name=name)
    
    # 组合完整策略
    full_strategy = config_region + init_region + main_loop + helper_region + run_entry
    
    return full_strategy

def generate_atr_strategy(name, description, config_params, signal_logic, risk_control="ATR止损"):
    """生成ATR突破策略模板"""
    
    config_region = f"#region 配置区\n"
    vars_line = ""
    for var_name, var_type, default_value, comment in config_params:
        if var_type == "Numeric":
            vars_line += f"Vars Numeric {var_name}({default_value});           // {comment}\n"
    config_region += vars_line + "#endregion\n\n"
    
    init_region = """#region 初始化
void Init() { }
#endregion\n\n"""
    
    main_loop = f"""#region 主循环
void OnBar(Arrayref<Integer> Indexs)
{
    String Symbol = SymInfo(0);
    
    // ========================================
    // 【策略核心】{description}
    // ========================================
    
    Numeric High[], Low[], Close[], Atr[];
    GetKLineData(Symbol, 0, 200, High, 2);
    GetKLineData(Symbol, 0, 200, Low, 3);
    GetKLineData(Symbol, 0, 200, Close, 0);
    CalculateATR(High, Low, Close, {config_params[0][2]}, Atr);
    
    // ATR止损止盈
    Numeric StopLoss, TakeProfit;
    StopLoss = Close[199] - Atr[199] * 2;  // 下方2倍ATR止损
    TakeProfit = Close[199] + Atr[199] * 2; // 上方2倍ATR止盈
    
    if(MarketPosition != 1)
    {{
        if(Close[199] > Max(StopLoss))
            Buy(Symbol, 1, Market);  // 突破止损线上方，买入
    }}
    else if(Close[199] < Min(TakeProfit))
        Sell(Symbol, 1, Market);     // 跌破止盈线，卖出
}
#endregion\n\n"""
    
    run_entry = f"""# ============================================================
# 启动入口
# ============================================================
if __name__ == '__main__':
    Run("{name}", "{name}", MODE_BACKTEST, "",
        "2024-01-01 09:00:00", "2024-12-31 15:00:00",
        1000000, 0.00025, 0.001, ADJUST_PREV)
"""
    
    return config_region + init_region + main_loop + run_entry

def main():
    """主函数：交互式生成策略"""
    print("=" * 60)
    print("TB策略模板生成器 v1.0")
    print("=" * 60)
    
    # 获取用户输入
    print("\n【第1步】请输入策略名称:")
    name = input("> ").strip()
    
    print("\n【第2步】请输入策略描述:")
    description = input("> ").strip()
    
    print("\n【第3步】选择策略类型:")
    print("1. 双均线交叉策略")
    print("2. ATR突破策略")
    print("3. MACD策略")
    print("4. RSI超买超卖")
    print("5. 自定义策略")
    
    choice = input("\n请输入选项 (1-5): ").strip()
    
    strategies = {
        "1": {
            "name": name,
            "description": description,
            "config_params": [
                ("MaShort", "Numeric", 5, "短期均线周期"),
                ("MaLong", "Numeric", 20, "长期均线周期"),
            ],
            "template": "ma_cross"
        },
        "2": {
            "name": name,
            "description": description,
            "config_params": [
                ("AtrPeriod", "Numeric", 14, "ATR周期"),
                ("LookBack", "Numeric", 200, "回看周期"),
            ],
            "template": "atr_breakout"
        }
    }
    
    if choice not in strategies:
        print("无效选项，使用默认双均线策略")
        strategies["1"]["name"] = name
        strategies["1"]["description"] = description
    
    # 生成策略代码
    strategy_data = strategies[choice]
    
    if strategy_data["template"] == "ma_cross":
        code = generate_ma_strategy(
            strategy_data["name"],
            strategy_data["description"],
            strategy_data["config_params"],
            "均线交叉信号"
        )
    else:
        code = generate_atr_strategy(
            strategy_data["name"],
            strategy_data["description"],
            strategy_data["config_params"],
            "ATR突破信号"
        )
    
    # 保存文件
    filename = f"{name}.tc4"
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(code)
    
    print(f"\n✅ 策略文件已生成: {filename}")
    print(f"\n📄 文件内容预览:")
    print("-" * 60)
    print(code[:1000] + "..." if len(code) > 1000 else code)
    print("-" * 60)
    
    print(f"\n💡 下一步:")
    print(f"1. 打开TB软件，进入'策略实验室'")
    print(f"2. 点击'新建策略'，粘贴代码")
    print(f"3. 点击'编译'确保无语法错误")
    print(f"4. 设置回测参数后点击'运行'")
    print(f"\n🎯 策略ID: {name}")

if __name__ == "__main__":
    main()
