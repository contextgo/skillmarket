---
name: tb-quant
version: 2.0.0
description: >
  开拓者(TradeBlazer/TB)量化交易专家技能。当用户提到TB、TradeBlazer、开拓者、TBQuant、TB策略、
  TB代码、TB回测、实时行情、订阅行情、历史数据、下单、持仓管理、Var变量、OnBar事件、
  Buy/Sell开平仓、MarketPosition、BarsSinceEntry、EntryPrice、区间突破、自适应均线时，自动加载此skill。
---

# 开拓者(TB)量化交易 SDK 技能 — v2.0

## 定位

你是**开拓者(TradeBlazer/TB)平台的自然语言策略助手**。用户用中文描述交易想法，你负责：

1. **理解需求** → 提炼策略逻辑（标的/信号/风控）
2. **生成代码** → 输出符合TB语法规范的完整 `.tc4` 策略文件
3. **执行运行** → 在TB终端中加载并运行策略

## 核心原则

1. **事件函数命名**：旧版TB使用 `onbar()`，新版TBQuant使用 `OnBar(Arrayref<Integer> indexs)`
2. **变量系统**：所有Var声明为静态，跨bar保持值；序列变量用NumericSeries/BoolSeries/StringSeries
3. **开仓平仓指令**：必须使用 `Buy`/`Sell`/`BuyToCover`/`SellShort`，不能用其他函数
4. **内置变量直接使用**：`MarketPosition`、`BarsSinceEntry`、`EntryPrice`等
5. **两种模式**：`MODE_BACKTEST=2`（回测）、`MODE_LIVE=1`（实时/仿真）
6. **纯本地运行无需token**：本地.tc4文件直接在TB终端加载，无需API token

## 🚀 用户工作流（自然语言→运行）

### 第0步：确认策略类型

根据用户需求选择策略结构：

| 类型 | 适用场景 | 示例 |
|------|---------|------|
| **定时任务型** | 每日固定时间操作 | 收盘后扫描、开盘前准备 |
| **数据事件驱动型** | K线触发、技术指标 | MA交叉、MACD金叉死叉 |
| **时间序列滑窗型** | 需要历史数据计算 | 布林带、RSI、KDJ |
| **区间突破型** | 支撑阻力突破 | 突破前高/前低、ATL突破 |
| **高频tick型** | 逐笔成交/委托 | 做市策略、套利 |

> ⚠️ 如果用户描述模糊（如"帮我做个赚钱的策略"），必须追问具体条件后再生成代码。

### 第一步：理解用户意图

提取以下信息：

| 维度 | 需确认的信息 | 默认值（如未明确说明） |
|------|-------------|----------------------|
| **strategy_id** | 策略在TB终端的标识（英文/数字/下划线） | 根据策略特征命名，如 `ma_cross_600519` |
| **标的池** | 哪些期货/股票？ | 沪深300成分股/主力连续合约 |
| **时间频率** | 日线/分钟线/tick？ | 日线 `1d` |
| **买入信号** | 什么条件买入？（均线/指标/事件） | 必须明确，不能猜测 |
| **卖出信号** | 什么条件卖出？ | 必须明确，不能猜测 |
| **仓位管理** | 全仓/固定手数/比例/等权 | 等权分配 |
| **止损止盈** | 有无？阈值多少？ | 无 |
| **回测区间** | 开始~结束日期 | 最近1年 |
| **初始资金** | 多少钱？ | 100万 |
| **运行模式** | 回测还是实盘？ | 先回测 |

### 第二步：生成策略文件

使用下方**标准策略模板**生成完整 `.tc4` 文件，保存到用户输出目录。

#### 标准策略模板

```text
// ============================================================
// 策略名称：{name}
// 策略描述：{description}
// 生成时间：{date}
// ============================================================

#region 配置区 —— 用户可通过修改此处调整策略参数
Vars Numeric MaPeriod(20);           // 均线周期
Vars Numeric AtrPeriod(14);          // ATR周期
Vars Numeric StopLossPct(0.05);      // 止损比例
#endregion

#region 初始化 —— 仅在首次运行时执行一次
void Init()
{
    // 设置图表样式
    Cat(1) = "MA策略";
}
#endregion

#region 主循环 —— 每根K线触发
void OnBar(Arrayref<Integer> Indexs)
{
    // 获取当前品种
    String Symbol = SymInfo(0);

    // ========================================
    // 【策略核心】在此处实现买卖信号
    // ========================================
}
#endregion
```

#### 关键语法要点

| 要素 | 正确写法 | 错误写法 |
|------|---------|---------|
| **事件函数** | `void OnBar(Arrayref<Integer> Indexs)` | `OnBar()` 或 `onbar()` |
| **变量声明** | `Vars Numeric X(0);` | `static Numeric X(0);` |
| **序列变量** | `Vars NumericSeries Close(0);` | `double Close[N];` |
| **开仓** | `Buy(Symbol, Volume, PriceType)` | `order_volume(..., position_effect=PositionEffect_Open)` |
| **平仓** | `Sell(Symbol, Volume, PriceType)` | `order_target_volume(..., position_side=PositionSide_Long)` |
| **内置变量** | `MarketPosition` | `get_position()` |
| **数据访问** | `GetKLineData(Symbol, 0, COUNT, Close, 0)` | `context.data(symbol=Symbol)` |
| **条件语句** | `if(Condition) { ... }` | `if(Condition) Begin ... End;` |

### 第三步：执行策略

在TB终端中：

1. 打开TB软件，进入"策略实验室"
2. 点击"新建策略"，粘贴代码
3. 点击"编译"确保无语法错误
4. 设置回测参数（时间范围、初始资金、手续费等）
5. 点击"运行"开始回测
6. 查看结果图表（收益曲线、回撤、夏普比率等）

> 实盘模式需要在"实时行情"界面，连接行情服务后点击"启动"。

## 📖 参考文档索引

详细API文档位于 `references/` 目录下：

| 文件 | 内容概要 |
|------|---------|
| `01-quick-start.md` | 快速开始、策略架构、Run()运行入口全解 |
| `02-core-functions.md` | Init/OnBar/OnTick/OnTimerEvent/Run函数详解 |
| `03-subscribe-events.md` | subscribe/unsubscribe订阅、OnBar/OnTick/OnTimer事件 |
| `04-market-data.md` | GetKLineData/current/history数据查询API |
| `05-trading-api.md` | Buy/Sell/SellShort/BuyToCover下单API全集 |
| `06-position-vars.md` | MarketPosition/BarsSinceEntry/EntryPrice持仓变量 |
| `07-indicators.md` | MA/MACD/RSI/Bollinger/ATR技术指标计算 |
| `08-backtest-params.md` | Run()回测参数设置与复权方式 |
| `09-pitfalls.md` | 16条常见坑点与解决方案 |

## 🎯 进阶策略示例

### 双均线交叉策略

```text
#region 配置区
Vars Numeric MaShort(5), MaLong(20);
#endregion

void OnBar(Arrayref<Integer> Indexs)
{
    String Symbol = SymInfo(0);
    Numeric Close[];
    GetKLineData(Symbol, 0, 100, Close, 0);

    Numeric MaShort, MaLong;
    CalculateMA(Close, 100, MaShort, MaShort);
    CalculateMA(Close, 100, MaLong, MaLong);

    if(MaShort[99] > MaLong[99] && MaShort[98] <= MaLong[98])
        Buy(Symbol, 1, Market);  // 金叉买入
    else if(MaShort[99] < MaLong[99] && MaShort[98] >= MaLong[98])
        Sell(Symbol, 1, Market); // 死叉卖出
}
```

### 海龟交易法（CTA）

```text
#region 配置区
Vars Numeric AtrPeriod(14), TrendPeriod(55);
#endregion

void OnBar(Arrayref<Integer> Indexs)
{
    String Symbol = SymInfo(0);
    Numeric High[], Low[], Close[], Atr[];
    GetKLineData(Symbol, 0, 200, High, 0);
    GetKLineData(Symbol, 0, 200, Low, 0);
    GetKLineData(Symbol, 0, 200, Close, 0);
    CalculateATR(High, Low, Close, AtrPeriod, Atr);

    Numeric LongStop, ShortStop;
    LongStop = Close[200] + Atr[200] * 2;
    ShortStop = Close[200] - Atr[200] * 2;

    if(MarketPosition != 1) {
        if(Close[200] > Max(LongStop))
            Buy(Symbol, 1, Market);
    } else if(Close[200] < Min(ShortStop))
        Sell(Symbol, 1, Market);
}
```

### 区间突破策略

```text
#region 配置区
Vars Numeric LookBack(200);
#endregion

void OnBar(Arrayref<Integer> Indexs)
{
    String Symbol = SymInfo(0);
    Numeric High[], Low[], Close[];
    GetKLineData(Symbol, 0, LookBack, High, 0);
    GetKLineData(Symbol, 0, LookBack, Low, 0);
    GetKLineData(Symbol, 0, LookBack, Close, 0);

    Numeric Highest, Lowest;
    GetValue(-LookBack, HIGH, Highest);
    GetValue(-LookBack, LOW, Lowest);

    if(!IsInTrend(Symbol, 1)) {
        if(Close[LookBack-1] > Highest)
            Buy(Symbol, 1, Market);  // 突破前高
        else if(Close[LookBack-1] < Lowest)
            Sell(Symbol, 1, Market); // 跌破前低
    }
}
```

## ❓ 常见问题 & 注意事项

- **事件函数签名**：`void OnBar(Arrayref<Integer> Indexs)`，注意是 `Arrayref` 不是 `Array`
- **变量作用域**：Vars全局静态，跨bar保持值；局部变量每次重新计算
- **数组索引**：TB数组从0开始，`Close[0]`是最新价，`Close[N-1]`是最旧价
- **多品种处理**：用 `SymInfo(Index)` 获取第Index个品种，`CountSymbols()` 获取总数
- **回测限制**：每个交易日18:30前只能回测上一个交易日数据
- **实盘限制**：实时模式只能推送具体合约行情，主连合约无行情推送
- **T+1约束**：当天买入不能当天卖出，策略逻辑需要考虑这个约束
- **止损止盈**：TB没有内置止损止盈函数，需要手动计算并调用Buy/Sell
- **公式引用**：`Indicator(Name, Param)` 可以引用已定义的技术指标
