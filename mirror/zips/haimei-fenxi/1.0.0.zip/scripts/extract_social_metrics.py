#!/usr/bin/env python3
import json
import re
import sys
from pathlib import Path
import pandas as pd

THEME_RULES = [
    ("文旅风光", ["travel", "tour", "scenic", "grotto", "mountain", "paradise", "景", "旅游", "风光", "古城", "遗址"]),
    ("节庆民俗", ["festival", "lantern", "spring festival", "folk", "celebration", "节", "灯会", "民俗"]),
    ("非遗文化", ["heritage", "intangible", "calligraphy", "craft", "opera", "非遗", "书法", "文化"]),
    ("城市生活", ["city", "street", "park", "life", "lifestyle", "咖啡", "街区", "生活", "城市"]),
    ("产业科创", ["technology", "innovation", "industry", "agriculture", "smart", "科技", "产业", "农业"]),
    ("国际时事", ["trump", "iran", "consulate", "protest", "u.s.", "pakistan", "美国", "伊朗"]),
]

def detect_theme(text: str) -> str:
    t = (text or "").lower()
    for theme, kws in THEME_RULES:
        if any(k.lower() in t for k in kws):
            return theme
    return "综合资讯"

def shorten(text: str, n: int = 80) -> str:
    text = re.sub(r"\s+", " ", (text or "").strip())
    return text[:n]


def main():
    if len(sys.argv) != 3:
        print("usage: extract_social_metrics.py <excel_path> <output_dir>")
        sys.exit(1)
    excel_path = Path(sys.argv[1])
    out_dir = Path(sys.argv[2])
    out_dir.mkdir(parents=True, exist_ok=True)
    xls = pd.ExcelFile(excel_path)
    records = []
    for sheet in xls.sheet_names:
        if sheet == "总结":
            continue
        try:
            df = pd.read_excel(excel_path, sheet_name=sheet, header=3)
        except Exception:
            continue
        if "序号" not in df.columns:
            continue
        df = df[df["序号"].notna()].copy()
        if "-" in sheet:
            platform, account = sheet.split("-", 1)
        else:
            platform, account = sheet, sheet
        df["平台"] = platform
        df["账号"] = account
        for c in ["互动次数", "心情数/点赞数", "评论数/回复数", "分享次数/转发次数 (混合)"]:
            if c in df.columns:
                df[c] = pd.to_numeric(df[c], errors="coerce").fillna(0)
        if "帖文内容" in df.columns:
            df["主题"] = df["帖文内容"].astype(str).map(detect_theme)
            df["内容概述"] = df["帖文内容"].astype(str).map(shorten)
        else:
            df["主题"] = "综合资讯"
            df["内容概述"] = ""
        records.append(df)
    all_df = pd.concat(records, ignore_index=True) if records else pd.DataFrame()
    if all_df.empty:
        raise SystemExit("no parsable account sheets found")

    platform_summary = all_df.groupby("平台").agg(
        账号数=("账号", "nunique"),
        发文数=("序号", "count"),
        互动总数=("互动次数", "sum"),
        点赞数=("心情数/点赞数", "sum"),
        评论数=("评论数/回复数", "sum"),
        分享数=("分享次数/转发次数 (混合)", "sum"),
    ).reset_index()
    platform_summary["平均每帖互动"] = (platform_summary["互动总数"] / platform_summary["发文数"]).round(1)

    account_summary = all_df.groupby(["平台", "账号"]).agg(
        发文数=("序号", "count"),
        互动总数=("互动次数", "sum"),
        点赞数=("心情数/点赞数", "sum"),
        评论数=("评论数/回复数", "sum"),
        分享数=("分享次数/转发次数 (混合)", "sum"),
    ).reset_index()
    account_summary["平均互动"] = (account_summary["互动总数"] / account_summary["发文数"]).round(1)
    account_summary = account_summary.sort_values(["互动总数", "平均互动"], ascending=[False, False])

    top_posts = all_df.sort_values("互动次数", ascending=False).head(20).copy()
    top_posts = top_posts[[c for c in ["平台", "账号", "日期", "互动次数", "心情数/点赞数", "评论数/回复数", "分享次数/转发次数 (混合)", "主题", "内容概述", "帖文链接"] if c in top_posts.columns]]
    top_posts = top_posts.rename(columns={
        "互动次数": "总互动",
        "心情数/点赞数": "点赞",
        "评论数/回复数": "评论",
        "分享次数/转发次数 (混合)": "分享",
    })

    theme_samples = all_df.groupby("主题").agg(
        帖文数=("序号", "count"),
        互动总数=("互动次数", "sum"),
        平均互动=("互动次数", "mean"),
    ).reset_index().sort_values("互动总数", ascending=False)
    theme_samples["平均互动"] = theme_samples["平均互动"].round(1)

    summary = {
        "platform_count": int(platform_summary.shape[0]),
        "account_count": int(all_df["账号"].nunique()),
        "post_count": int(all_df.shape[0]),
        "interaction_total": int(all_df["互动次数"].sum()),
        "top_platform_by_posts": platform_summary.sort_values("发文数", ascending=False).iloc[0]["平台"],
        "top_platform_by_efficiency": platform_summary.sort_values("平均每帖互动", ascending=False).iloc[0]["平台"],
        "top_account_by_interaction": account_summary.iloc[0]["账号"],
        "top_theme": theme_samples.iloc[0]["主题"] if not theme_samples.empty else "综合资讯",
    }

    platform_summary.to_csv(out_dir / "platform_summary.csv", index=False)
    account_summary.to_csv(out_dir / "account_summary.csv", index=False)
    top_posts.to_csv(out_dir / "top_posts.csv", index=False)
    theme_samples.to_csv(out_dir / "theme_samples.csv", index=False)
    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False))

if __name__ == "__main__":
    main()
