# Table spec

## Platform table
Columns:
- 平台
- 账号数
- 发文数
- 互动总数
- 平均每帖互动
- 点赞数
- 评论数
- 分享数

## Account table
Default columns:
- 平台
- 账号
- 发文数
- 互动总数
- 平均互动
- 备注

Prefer the top 8 to 12 accounts by interaction, but include at least one efficiency case if it would otherwise be omitted.

## High-performing content case table
Columns:
- 平台
- 账号
- 日期
- 总互动
- 点赞
- 评论
- 分享
- 内容概述
- 案例启示

Keep content summary under 50 Chinese characters where possible.
