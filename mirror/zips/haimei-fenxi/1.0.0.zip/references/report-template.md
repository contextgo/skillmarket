# Report template

Use this exact section order.

# [省份]海外社交媒体账号运营监测月度报告

## 一、执行摘要
One to three paragraphs. Cover overall state, biggest bright spot, biggest concern, and next-step priority.

## 二、本月账号矩阵总体运行情况
Summarize platform coverage, total posting, total interaction, and the month’s main content directions.

## 三、平台层核心数据表现
Insert the platform table first, then analyze which platforms carry scale, which platforms carry efficiency, and what the distribution means.

## 四、账号层运营表现观察
Insert the account table first, then describe high-frequency accounts, high-interaction accounts, and accounts with standout single-post performance.

## 五、内容传播表现分析
Summarize the best-performing themes and expressions from the post sample. Focus on visuality, local identity, event atmosphere, culture, tourism, lifestyle, or other themes actually present.

## 六、高互动内容案例与传播特征总结
Insert the high-performing content case table first, then write 3 to 5 short case analyses and a closing paragraph summarizing repeatable content patterns.

## 七、当前运营中值得关注的问题
Write 3 to 5 concrete issues grounded in the workbook.

## 八、下阶段优化建议
Group into:
- 可立即执行事项
- 一月内推进事项
- 中期持续建设事项

## 九、附件说明
List the generated tables and case list.
