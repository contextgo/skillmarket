# Writing rules

## What the report must do
- Explain the month clearly for a client.
- Show data, but not as a data dump.
- Surface content and international communication insight in every analytical section.
- Stay within what the workbook can prove.

## What the report must not do
Do not state or strongly imply any of the following unless the workbook directly contains the evidence:
- audience age bands
- audience geography
- sentiment analysis results
- account security state
- abnormal login, throttling, or suppression
- comment moderation outcomes
- secondary pickup by overseas media or influencers
- industry-average comparison

## Recommended phrasing
Prefer:
- 从本月数据看
- 从高互动帖文样本看
- 综合平台表现和内容特征判断
- 值得关注的是
- 说明当前账号矩阵在……方面已具备一定基础

Avoid:
- 已全面排查
- 显著高于行业平均
- 海外受众主要集中在
- 账号整体安全运营良好

## Analysis logic
Each major section should use this pattern:
1. data phenomenon
2. content observation
3. professional judgment
4. actionable implication

## Chinadaily voice
- professional
- calm
- externally deliverable
- strategically aware
- not academic, not promotional
