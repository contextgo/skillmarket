---
name: chinadaily-overseas-report-writer
description: "generate a client-ready monthly overseas social media monitoring report from one uploaded excel workbook. use when the user uploads a monthly social media operations ledger and wants a complete report, a word report body, or supporting tables for platform performance, account performance, and high-performing posts. follow chinadaily conventions: emphasize international communication insight, include data without dumping raw numbers, avoid claims not supported by the workbook, and default to the structure platform-account-content-cases-issues-recommendations."
metadata: {"openclaw":{"homepage":"https://docs.openclaw.ai/tools/skills"}}
---

# Chinadaily Overseas Report Writer

Turn one uploaded Excel monthly ledger into a client-ready overseas social media monitoring report.

## Workflow

Follow these steps in order.

1. Run `scripts/extract_social_metrics.py <excel_path> <output_dir>`.
2. Read `references/writing-rules.md` for scope, tone, and non-inferable items.
3. Read `references/report-template.md` and draft the report body using its exact section order.
4. Use the generated CSV and JSON files to fill the platform table, account table, and high-performing content case table.
5. If the user wants a Word document, place the final body into a `.docx` file using the available document tool in the environment. If a document tool is unavailable, still produce the complete report text and the three tables in markdown.

## Input expectations

Assume the primary input is one uploaded `.xlsx` monthly ledger.

The workbook usually contains:
- one summary sheet named `总结`
- multiple account sheets named like `Facebook-Account Name`
- per-post rows beginning after three header rows

Do not ask the user to restructure the workbook unless parsing fails.

## Output requirements

Always produce these deliverables:
- complete report正文 in Chinese
- 平台表格
- 账号表格
- 高互动案例表

When creating the narrative, always keep this order:
1. 执行摘要
2. 本月账号矩阵总体运行情况
3. 平台层核心数据表现
4. 账号层运营表现观察
5. 内容传播表现分析
6. 高互动内容案例与传播特征总结
7. 当前运营中值得关注的问题
8. 下阶段优化建议
9. 附件说明

## Chinadaily writing rules

Apply these rules every time:
- emphasize international communication logic and content insight, not only data movement
- include concrete data in every major section, but do not overload paragraphs with raw numbers
- do not claim audience age, geography, sentiment, account security, algorithm suppression, reprint volume, or comment-risk outcomes unless the workbook directly provides that evidence
- write findings as `data phenomenon + content observation + professional judgment`
- default to platform-account-content-cases-issues-recommendations logic
- keep tone professional, steady, and client-facing

## Analytical priorities

Prefer these judgments when the workbook supports them:
- which platforms carry the main publishing burden
- which platforms have stronger single-post efficiency
- which accounts sustain the basic traffic floor
- which accounts create standout posts
- which content themes repeatedly drive interaction
- whether posting quantity and interaction efficiency are mismatched
- whether content is strongly tied to local identity or drifts into low-value generic/news content

## Required references

Use these references while drafting:
- `references/writing-rules.md`
- `references/report-template.md`
- `references/table-spec.md`

## Required script outputs

The extraction script writes:
- `summary.json`
- `platform_summary.csv`
- `account_summary.csv`
- `top_posts.csv`
- `theme_samples.csv`

Base the report on those files.

## Fallback behavior

If some workbook fields are missing:
- still produce the report
- explicitly narrow the affected claims
- keep the structure intact
- avoid fabricating unavailable metrics

## OpenClaw compatibility notes

This skill is packaged as an AgentSkills-compatible folder with `SKILL.md` frontmatter and supporting resources, which aligns with OpenClaw skill loading expectations. OpenClaw loads skills from workspace or managed skill folders and requires `SKILL.md` as the entrypoint. citeturn275372search0turn275372search1turn275372search2
