# 眼底 AI 多病种分析 API Reference

> 本文档基于《眼底AI青光眼与多病种API2026》整理，用于说明 `fundus-images-ai-analysis` Skill 所调用的底层 API 能力。
> 更新日期：2026-04-14 | v2

---

## 目录

1. [服务概览](#1-服务概览)
2. [鉴权说明](#2-鉴权说明)
3. [接口一：检查信息与图片上传](#3-接口一检查信息与图片上传)
4. [接口二：眼底 AI 结果查询](#4-接口二眼底-ai-结果查询)
5. [响应数据结构详解](#5-响应数据结构详解)
6. [错误码对照表](#6-错误码对照表)
7. [Skill 与 API 的映射关系](#7-skill-与-api-的映射关系)
8. [试用与正式使用](#8-试用与正式使用)

---

## 1. 服务概览

本服务提供眼底图像的 AI 辅助诊断能力，支持以下两类 AI 分析：

| AI 类型 | `aiType` 值 | 说明 |
|---------|------------|------|
| 青光眼 + 多病种（联合） | `0` | 同时输出青光眼和多病种结果（**推荐**） |
| 青光眼（单独） | `1` | 仅输出青光眼分析结果 |
| 多病种（单独） | `2` | 仅输出多病种分析结果 |

**多病种覆盖范围：**
糖尿病性视网膜病变（DR）、年龄相关性黄斑变性（AMD）、视网膜静脉阻塞、屈光间质混浊、高血压眼底病变、豹纹状眼底、高度近视眼底改变、其他眼底疾病

**完整调用流程：**

```
上传图片（Step 1） ──→ 等待 AI 处理 ──→ 轮询查询结果（Step 2） ──→ 格式化输出（Step 3）
     │                                          │
     └─ 获得 studyId ──────────────────────────→ 使用 studyId 查询
```

---

## 2. 鉴权说明

所有接口均需在 HTTP 请求头中携带以下字段：

| Header 字段 | 类型 | 说明 |
|------------|------|------|
| `appId` | string | 合作方 ID，由腾讯系统分配 |
| `signature` | string | HMAC-SHA256 签名 |
| `timestamp` | string | 当前时间戳（**毫秒**级） |

**签名算法：**

```
signature = HMAC-SHA256(key=token, message=appId + timestamp)
```

- `token`：密钥，由腾讯系统分配（**不**在请求头中传递）
- 拼接规则：直接将 `appId` 和 `timestamp` 字符串拼接，无分隔符

### 签名生成示例

**Python：**
```python
import hmac, hashlib, time

app_id = "12708"
token = "69842f96c5b14c0ca8042fc309f3f087"
timestamp = str(int(time.time() * 1000))  # 毫秒级
signature = hmac.new(token.encode(), (app_id + timestamp).encode(), hashlib.sha256).hexdigest()
```

**Bash：**
```bash
APP_ID="12708"
TOKEN="69842f96c5b14c0ca8042fc309f3f087"
TIMESTAMP=$(python3 -c "import time; print(int(time.time()*1000))")
SIGNATURE=$(echo -n "${APP_ID}${TIMESTAMP}" | openssl dgst -sha256 -hmac "$TOKEN" | awk '{print $2}')
```

> ⚠️ 注意：timestamp 必须为**毫秒**级（13位数字），不是秒级。

---

## 3. 接口一：检查信息与图片上传

### 基本信息

| 项目 | 内容 |
|------|------|
| 请求方法 | `POST` |
| 正式环境 | `https://pacs.qq.com/thirdparty/studyupload/v2/{appId}` |
| 测试环境 | `https://test.pacs.qq.com/thirdparty/studyupload/v2/{appId}` |
| Content-Type | `application/json; charset=utf-8` |

### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| `studyId` | string | ✅ | 检查序列号，调用方自行生成（建议 `study_` + UUID），后续查询时需用此值 |
| `studyName` | string | ✅ | 检查名称，眼底固定填 `"眼底检查"` |
| `studyDate` | long | ✅ | 检查日期，Unix 时间戳（**秒**级） |
| `studyType` | int | ✅ | 检查类型，眼底固定填 `2` |
| `patientName` | string | ❌ | 患者姓名 |
| `patientId` | string | ❌ | 患者在医院侧的编号 |
| `patientGender` | string | ❌ | 性别：`"0"`=未知，`"1"`=男，`"2"`=女，`"3"`=其他 |
| `patientBirthday` | string | ❌ | 患者生日，格式 `YYYY-MM-DD` |
| `images` | Array\<Image\> | ✅ | 图片数组，至少 1 张，最多 20 张，总大小 ≤ 5MB |

### images 子对象结构

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| `imageId` | string | ✅ | 图片唯一编号（在本次检查范围内唯一） |
| `content` | string | ✅ | 图片 Base64 编码内容（**不含** `data:image/...;base64,` 前缀） |
| `url` | string | ❌ | 图片在医院侧内网地址（可不传） |
| `descPosition` | string | ⚠️ 眼底必填 | 眼位：`"0"`=未知，`"1"`=左眼（OS），`"2"`=右眼（OD） |

> ⚠️ **眼底检查必须传 `descPosition`**，否则无法区分左右眼结果。

### 响应参数

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | int | `0`=成功，非 `0`=失败 |
| `message` | string | 结果描述 |
| `requestId` | string | 请求 ID，用于排查问题 |

> ⚠️ **重要**：上传成功后，使用**请求体中自定义的 `studyId`** 查询结果（不是从响应中获取）。

### 请求示例

**Bash/curl：**

```bash
APP_ID="12708"
TOKEN="69842f96c5b14c0ca8042fc309f3f087"
IMAGE_PATH="/path/to/fundus_image.jpg"

# 生成签名
TIMESTAMP=$(python3 -c "import time; print(int(time.time()*1000))")
SIGNATURE=$(echo -n "${APP_ID}${TIMESTAMP}" | openssl dgst -sha256 -hmac "$TOKEN" | awk '{print $2}')

# Base64 编码图片（macOS 用 -i，Linux 用 -w 0）
IMAGE_B64=$(base64 -i "$IMAGE_PATH" | tr -d '\n')

# 生成 studyId
STUDY_ID="study_$(uuidgen | tr '[:upper:]' '[:lower:]' | tr -d '-' | head -c 12)"

curl -s -X POST "https://pacs.qq.com/thirdparty/studyupload/v2/${APP_ID}" \
  -H "appId: ${APP_ID}" \
  -H "signature: ${SIGNATURE}" \
  -H "timestamp: ${TIMESTAMP}" \
  -H "Content-Type: application/json; charset=utf-8" \
  -d "{
    \"studyId\": \"${STUDY_ID}\",
    \"studyName\": \"眼底检查\",
    \"studyDate\": $(date +%s),
    \"studyType\": 2,
    \"images\": [{
      \"imageId\": \"img_001\",
      \"content\": \"${IMAGE_B64}\",
      \"descPosition\": \"2\"
    }]
  }"

echo "studyId=${STUDY_ID}"
```

**Python：**

```python
import hmac, hashlib, time, json, base64, uuid, urllib.request

app_id = "12708"
token = "69842f96c5b14c0ca8042fc309f3f087"
image_path = "/path/to/fundus_image.jpg"

# 签名
timestamp = str(int(time.time() * 1000))
signature = hmac.new(token.encode(), (app_id + timestamp).encode(), hashlib.sha256).hexdigest()

# Base64 编码
with open(image_path, "rb") as f:
    image_b64 = base64.b64encode(f.read()).decode()

# 请求体
study_id = "study_" + uuid.uuid4().hex[:12]
body = {
    "studyId": study_id,
    "studyName": "眼底检查",
    "studyDate": int(time.time()),
    "studyType": 2,
    "images": [{
        "imageId": "img_" + uuid.uuid4().hex[:8],
        "content": image_b64,
        "descPosition": "2"  # 右眼
    }]
}

# 发送
url = f"https://pacs.qq.com/thirdparty/studyupload/v2/{app_id}"
req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST")
req.add_header("appId", app_id)
req.add_header("signature", signature)
req.add_header("timestamp", timestamp)
req.add_header("Content-Type", "application/json; charset=utf-8")

with urllib.request.urlopen(req, timeout=60) as resp:
    result = json.loads(resp.read().decode())
    print(result)
    # study_id 用于后续查询
```

---

## 4. 接口二：眼底 AI 结果查询

### 基本信息

| 项目 | 内容 |
|------|------|
| 请求方法 | `POST` |
| 正式环境 | `https://pacs.qq.com/thirdparty/queryEyeAIResult/{appId}` |
| 测试环境 | `https://test.pacs.qq.com/thirdparty/queryEyeAIResult/{appId}` |
| Content-Type | `application/json; charset=utf-8` |

### 请求参数

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| `hospitalId` | string | ✅ | 医疗机构标识，与 appId 相同（当前为 `"12708"`） |
| `studyId` | string | ✅ | 上传接口中使用的 studyId |
| `patientId` | string | ❌ | 患者唯一标识（可选） |
| `aiType` | int | ✅ | AI 类型：`0`=青光眼+多病种（推荐），`1`=青光眼，`2`=多病种 |
| `needReport` | int | ✅ | 是否生成 PDF 报告：`0`=否，`1`=是（推荐 `1`） |

### 轮询策略

| 参数 | 值 |
|------|-----|
| 轮询间隔 | **10 秒** |
| 超时上限 | **3 分钟**（最多 18 次） |
| 继续等待条件 | `code = 30008`（AI 任务处理中） |
| 成功条件 | `code = 0` 且 `data` 字段非空 |
| 失败条件 | 其他非零 `code`，或超时未返回 |

### 响应参数（顶层）

| 字段 | 类型 | 说明 |
|------|------|------|
| `code` | int | `0`=成功，`30008`=处理中，其他=失败 |
| `message` | string | 结果描述 |
| `requestId` | string | 请求 ID |
| `data` | object | AI 结果详情，见下方 [§5 响应数据结构详解](#5-响应数据结构详解) |

### 请求示例

**Python（含轮询）：**

```python
import hmac, hashlib, time, json, urllib.request

app_id = "12708"
token = "69842f96c5b14c0ca8042fc309f3f087"
study_id = "<Step 1 中的 studyId>"

for attempt in range(18):
    timestamp = str(int(time.time() * 1000))
    signature = hmac.new(token.encode(), (app_id + timestamp).encode(), hashlib.sha256).hexdigest()

    body = {"hospitalId": "12708", "studyId": study_id, "aiType": 0, "needReport": 1}

    url = f"https://pacs.qq.com/thirdparty/queryEyeAIResult/{app_id}"
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST")
    req.add_header("appId", app_id)
    req.add_header("signature", signature)
    req.add_header("timestamp", timestamp)
    req.add_header("Content-Type", "application/json; charset=utf-8")

    with urllib.request.urlopen(req, timeout=30) as resp:
        result = json.loads(resp.read().decode())

    if result.get("code") == 0 and result.get("data"):
        print(json.dumps(result, ensure_ascii=False, indent=2))
        break
    elif result.get("code") == 30008:
        print(f"[{attempt+1}/18] AI 处理中，等待 10 秒...")
        time.sleep(10)
    else:
        raise Exception(f"查询失败 (code={result.get('code')}): {result.get('message')}")
else:
    raise Exception("超时：3 分钟内未获取到诊断结果")
```

**Bash/curl：**

```bash
APP_ID="12708"
TOKEN="69842f96c5b14c0ca8042fc309f3f087"
STUDY_ID="<Step 1 中的 studyId>"

for i in $(seq 1 18); do
  TIMESTAMP=$(python3 -c "import time; print(int(time.time()*1000))")
  SIGNATURE=$(echo -n "${APP_ID}${TIMESTAMP}" | openssl dgst -sha256 -hmac "$TOKEN" | awk '{print $2}')

  RESULT=$(curl -s -X POST "https://pacs.qq.com/thirdparty/queryEyeAIResult/${APP_ID}" \
    -H "appId: ${APP_ID}" \
    -H "signature: ${SIGNATURE}" \
    -H "timestamp: ${TIMESTAMP}" \
    -H "Content-Type: application/json; charset=utf-8" \
    -d "{\"hospitalId\":\"12708\",\"studyId\":\"${STUDY_ID}\",\"aiType\":0,\"needReport\":1}")

  CODE=$(echo "$RESULT" | python3 -c "import sys,json; print(json.load(sys.stdin).get('code',''))")

  if [ "$CODE" = "0" ]; then
    echo "$RESULT" | python3 -m json.tool
    break
  elif [ "$CODE" = "30008" ]; then
    echo "[$i/18] AI 处理中，等待 10 秒..."
    sleep 10
  else
    echo "查询失败: $RESULT"
    break
  fi
done
```

---

## 5. 响应数据结构详解

### 5.1 AIResult（顶层 data 对象）

| 字段 | 类型 | 说明 |
|------|------|------|
| `glaucomaResultList` | List\<GlaucomaResult\> | 青光眼 AI 结果列表（按眼别分条目） |
| `multipleDiseasesResultList` | List\<MultipleDiseasesResult\> | 多病种 AI 结果列表（按眼别分条目） |
| `imageMaskResultList` | List | 图像分割结果（通常为空，可忽略） |
| `reportUrl` | string | PDF 报告链接（`needReport=1` 时有值） |

### 5.2 图片处理状态码（status 字段）

适用于 `GlaucomaResult` 和 `MultipleDiseasesResult` 的 `status` 字段：

| status | 含义 | Agent 处理方式 |
|--------|------|---------------|
| `200` | ✅ 处理成功 | 正常解析结果 |
| `0` | ⏳ 处理中 | 继续轮询 |
| `-1` | ⏳ 待处理 | 继续轮询 |
| `-2` | ❌ 处理失败 | 告知用户 |
| `-3` | ⚠️ 屈光间质混浊 | 告知用户图片质量问题 |
| `-4` | ❌ 图片不合格 | 告知用户更换图片 |
| `404` | ❌ 未找到图片 | 检查上传是否成功 |

> ⚠️ 仅 `status = 200` 的条目有完整的诊断数据。其他状态时，float 字段返回 `-1`，string 字段返回 `"未知"`。

### 5.3 GlaucomaResult（青光眼结果）

| 字段 | 类型 | 说明 |
|------|------|------|
| `status` | int | 图片处理状态，见 §5.2 |
| `eyeCategory` | int | 眼别：`0`=左眼（OS），`1`=右眼（OD） |
| `aiResult` | string | AI 结论文本 |

`aiResult` 可能取值：

| 值 | 含义 | 图标 |
|----|------|------|
| `"未见明显青光眼样眼底表现"` | 正常 | ✅ |
| `"疑似青光眼样眼底表现"` | 疑似异常 | ⚠️ |
| `"未知结果"` | 无法判断（通常 status≠200） | ❓ |

### 5.4 MultipleDiseasesResult（多病种结果）

| 字段 | 类型 | 说明 |
|------|------|------|
| `status` | int | 图片处理状态，见 §5.2 |
| `eyeCategory` | int | 眼别：`0`=左眼（OS），`1`=右眼（OD） |
| `description` | object | 病灶形态学描述，见 §5.5 |
| `result` | object | 多病种诊断结论，见 §5.6 |

### 5.5 description（形态学指标）

| 字段 | 类型 | 说明 |
|------|------|------|
| `ratiosCD` | float | 杯盘比（C/D ratio），**青光眼核心指标**，正常值 < 0.6 |
| `ratiosIN` | float | 盘沿比 I/N（鼻侧/下方） |
| `ratiosSN` | float | 盘沿比 S/N（上方/鼻侧） |
| `ratiosTN` | float | 盘沿比 T/N（颞侧/鼻侧） |
| `microaneurysms` | string | 微动脉瘤：`"是"` / `"否"` / `"未知"` |
| `bleeding` | string | 出血斑：`"是"` / `"否"` / `"未知"` |
| `hardExudation` | string | 硬性渗出：`"是"` / `"否"` / `"未知"` |
| `softExudation` | string | 软性渗出：`"是"` / `"否"` / `"未知"` |
| `proliferation` | string | 增殖膜：`"是"` / `"否"` / `"未知"` |
| `vitreous` | string | 玻璃体积血：`"是"` / `"否"` / `"未知"` |
| `wart` | string | 玻璃膜疣：`"是"` / `"否"` / `"未知"` |

> ⚠️ 当 `status != 200` 时，float 字段返回 `-1`，string 字段返回 `"未知"`。
>
> ⚠️ 旧版文档中 `hardExudation` 说明写为"软性渗出"是笔误，实际为**硬性渗出**。

### 5.6 result（多病种诊断结论）

| 字段 | 类型 | 可能值 | 说明 |
|------|------|--------|------|
| `noAbnormality` | string | `"是"` / `"否"` / `""` | 未见明显异常（为空时需看各项具体值） |
| `diabetic` | string | `"未见异常"` / `"轻度"` / `"中度"` / `"重度"` / `"增殖"` / `"未知"` | 糖尿病性视网膜病变（DR）分级 |
| `AMD` | string | `"有"` / `"无"` / `"不确定"` | 年龄相关性黄斑变性 |
| `block` | string | `"有"` / `"无"` / `"不确定"` | 视网膜静脉阻塞 |
| `turbid` | string | `"有"` / `"无"` / `"不确定"` | 屈光间质混浊 |
| `hypertensive` | string | `"有"` / `"无"` / `"不确定"` | 高血压眼底病变 |
| `tessellatedFundus` | string | `"有"` / `"无"` / `"不确定"` | 豹纹状眼底 |
| `pathologicalMyopia` | string | `"有"` / `"无"` / `"不确定"` | 高度近视眼底改变 |
| `other` | string | `"有"` / `"无"` / `""` | 其他眼底疾病 |

### 5.7 eyeCategory 与 descPosition 对照

> ⚠️ **这是一个容易混淆的点**：上传和查询使用了不同的编码方式。

| | 左眼（OS） | 右眼（OD） | 未知 |
|--|-----------|-----------|------|
| **上传** `descPosition` | `"1"` | `"2"` | `"0"` |
| **返回** `eyeCategory` | `0` | `1` | — |

### 5.8 完整响应示例

```json
{
  "code": 0,
  "message": "请求成功",
  "requestId": "1e70edad-1dd4-4711-a033-933cb13ca529",
  "data": {
    "glaucomaResultList": [
      {
        "aiResult": "疑似青光眼样眼底表现",
        "eyeCategory": 1,
        "status": 200
      }
    ],
    "multipleDiseasesResultList": [
      {
        "status": 200,
        "eyeCategory": 1,
        "description": {
          "ratiosCD": 0.61115,
          "ratiosIN": 0.719298,
          "ratiosSN": 1.052632,
          "ratiosTN": 0.877193,
          "microaneurysms": "否",
          "bleeding": "否",
          "hardExudation": "否",
          "softExudation": "否",
          "proliferation": "否",
          "vitreous": "否",
          "wart": ""
        },
        "result": {
          "noAbnormality": "",
          "diabetic": "未见异常",
          "AMD": "无",
          "block": "无",
          "turbid": "无",
          "hypertensive": "无",
          "tessellatedFundus": "有",
          "pathologicalMyopia": "无",
          "other": ""
        }
      }
    ],
    "imageMaskResultList": [],
    "reportUrl": "https://pacs.qq.com/partners/apiReport?tpShareId=6fa7e56e..."
  }
}
```

---

## 6. 错误码对照表

| code | 含义 | Agent 处理方式 |
|------|------|---------------|
| `0` | 请求成功 | 正常处理 |
| `1` | 参数错误 | 检查请求参数是否缺失或格式不对，停止并告知用户 |
| `2` | 数据库异常 | 稍后重试（最多 2 次） |
| `10003` | 未找到数据 | 确认 studyId / hospitalId 是否正确 |
| `30008` | 检查处理中 | **继续轮询**（AI 任务尚未完成） |
| `90001` | 无效 token | 检查 token 配置，停止并告知用户 |
| `90002` | 无效签名 | 检查签名算法和时间戳，停止并告知用户 |
| `90003` | 超出最大获取次数 | 降低轮询频率，延长间隔后重试 |

---

## 7. Skill 与 API 的映射关系

说明 `fundus-images-ai-analysis` Skill 各步骤与底层 API 的对应关系：

| Skill 步骤 | 底层 API | 方式 |
|-----------|----------|------|
| Step 1：上传图片 | `POST /thirdparty/studyupload/v2/{appId}` | 纯 HTTP 调用（JSON body + Base64 图片） |
| Step 2：轮询结果 | `POST /thirdparty/queryEyeAIResult/{appId}` | 纯 HTTP 调用（JSON body） |
| Step 3：格式化输出 | — | 解析 `data.glaucomaResultList` + `data.multipleDiseasesResultList` |
| PDF 报告 | `data.reportUrl` | 直接提供链接 |

**关键字段流转：**

```
上传时自定义 studyId ──→ 查询时传入 studyId ──→ 获得 data 对象 ──→ 格式化输出
```

**轮询策略：**
- 间隔：10 秒
- 超时：3 分钟（最多 18 次）
- 继续条件：`code = 30008`
- 成功条件：`code = 0` 且 `data` 非空

---

## 8. 试用与正式使用

### 8.1 试用

Skill 能力面向各类用户进行试用，现提供试用所需的凭证：

| 项目 | 值 |
|------|-----|
| APP-ID | `12708` |
| APP-TOKEN | `69842f96c5b14c0ca8042fc309f3f087` |
| hospitalId | `12708`（与 APP-ID 相同） |
| 有效期 | 至 2026.4.30 |

如需 sample 眼底图片进行测试：
- 下载地址：https://yunpan.oa.tencent.com/s/cswdFyPdUx
- 提取码：KZY7
- 到期时间：2026-04-28 23:59:59

### 8.2 正式使用

如在试用后希望长期使用，可联系 miying@tencent.com 沟通合作事宜，或访问 [腾讯健康官网](https://healthcare.tencent.com/production/1?from=tab) 联系我们。

---

*文档版本：v2 | 更新日期：2026-04-14 | 来源：眼底AI青光眼与多病种API2026.pdf + 实际调用验证*
