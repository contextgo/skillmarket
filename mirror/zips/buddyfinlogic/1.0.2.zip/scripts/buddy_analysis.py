#!/usr/bin/env python3
"""
Buddy方法论 · 个股分析脚本
基于15项财务指标的三维评级体系

使用方式:
    python buddy_analysis.py <股票名称或代码> [股票2] [股票3] ...

示例:
    python buddy_analysis.py 兆易创新 603986
    python buddy_analysis.py 腾讯控股 00700.HK
"""

import sys
import json
from pathlib import Path

# 尝试导入neodata，若不可用则使用模拟数据
try:
    sys.path.insert(0, str(Path(__file__).parent.parent.parent / "neodata-financial-search" / "scripts"))
    from query import query_neodata
    HAS_NEODATA = True
except ImportError:
    HAS_NEODATA = False
    print("[提示] neodata-financial-search 未安装，将使用示例数据演示")

# ============================================================
# 指标阈值定义
# ============================================================

THRESHOLDS = {
    "roe": {"excellent": 15, "good": 10, "unit": "%"},
    "cash_ratio": {"excellent": 100, "good": 80, "unit": "%"},  # 收现比
    "debt_ratio": {"excellent": 60, "warning": 75, "unit": "%"},  # 资产负债率
    "goodwill_ratio": {"excellent": 30, "warning": 50, "unit": "%"},  # 商誉/净资产
    "pledge_ratio": {"excellent": 50, "warning": 80, "unit": "%"},  # 大股东质押
    "receivable_ratio": {"excellent": 30, "warning": 50, "unit": "%"},  # 应收/营收
    "interest_debt_ratio": {"excellent": 40, "warning": 60, "unit": "%"},  # 有息负债率
    "gross_margin": {"excellent": 30, "good": 15, "unit": "%"},  # 毛利率
}

RATING_SYMBOLS = {
    "⭐⭐⭐": "值得关注",
    "⭐⭐": "谨慎对待",
    "⭐": "回避"
}


def score_indicator(value: float, threshold: dict, inverse: bool = False) -> str:
    """
    根据阈值给指标打分
    inverse: True 表示越小越好（如资产负债率）
    """
    excellent = threshold["excellent"]
    if "warning" in threshold:
        warning = threshold["warning"]
    else:
        warning = threshold.get("good", excellent)

    if inverse:
        if value <= excellent:
            return "✅"
        elif value <= warning:
            return "⚠️"
        else:
            return "❌"
    else:
        if value >= excellent:
            return "✅"
        elif value >= warning:
            return "⚠️"
        else:
            return "❌"


def rate_stock(data: dict) -> dict:
    """
    根据15项指标对股票进行评级
    data: dict 包含各项财务数据
    返回: dict 包含评级结果和详细评分
    """

    # 提取数据
    roe = data.get("roe", 0)
    cash_ratio = data.get("cash_ratio", 0)  # 收现比
    debt_ratio = data.get("debt_ratio", 0)
    goodwill_ratio = data.get("goodwill_ratio", 999)  # 商誉/净资产
    pledge_ratio = data.get("pledge_ratio", 999)
    receivable_ratio = data.get("receivable_ratio", 999)
    interest_debt_ratio = data.get("interest_debt_ratio", 999)
    gross_margin = data.get("gross_margin", 0)
    hsgt_ratio = data.get("hsgt_ratio", 0)  # 北向资金

    # 核心否决条件（直接判定⭐）
    veto_conditions = []
    if cash_ratio < 0:
        veto_conditions.append(f"收现比负值({cash_ratio}%)")
    if debt_ratio > 85:
        veto_conditions.append(f"资产负债率过高({debt_ratio}%)")
    if goodwill_ratio > 70:
        veto_conditions.append(f"商誉风险({goodwill_ratio}%)")
    if roe < -20:
        veto_conditions.append(f"ROE极差({roe}%)")

    # 核心肯定条件（争取⭐⭐⭐）
    positive_conditions = []
    score = 0
    max_score = 5  # 5分制

    # 收现比 (最重要)
    if cash_ratio >= 80:
        score += 2
        positive_conditions.append(f"收现比优秀({cash_ratio}%)")
    elif cash_ratio >= 0:
        score += 1
        positive_conditions.append(f"收现比基本合格({cash_ratio}%)")

    # 资产负债率
    if debt_ratio <= 60:
        score += 1
        positive_conditions.append(f"资产负债率安全({debt_ratio}%)")
    elif debt_ratio <= 75:
        score += 0.5

    # ROE
    if roe >= 15:
        score += 1
        positive_conditions.append(f"ROE优秀({roe}%)")
    elif roe >= 8:
        score += 0.5
        positive_conditions.append(f"ROE尚可({roe}%)")

    # 商誉
    if goodwill_ratio <= 30:
        score += 0.5
        positive_conditions.append(f"商誉安全({goodwill_ratio}%)")

    # 北向资金
    if hsgt_ratio >= 3:
        score += 0.5
        positive_conditions.append(f"北向资金重仓({hsgt_ratio}%)")

    # 判定等级
    if veto_conditions:
        rating = "⭐"
        summary = f"否决: {', '.join(veto_conditions)}"
    elif score >= 4:
        rating = "⭐⭐⭐"
        summary = f"综合得分{score}/{max_score}，财务质量优秀"
    elif score >= 2.5:
        rating = "⭐⭐"
        summary = f"综合得分{score}/{max_score}，需关注部分指标"
    else:
        rating = "⭐⭐"
        summary = f"综合得分{score}/{max_score}，谨慎对待"

    return {
        "rating": rating,
        "score": score,
        "summary": summary,
        "positive_conditions": positive_conditions,
        "veto_conditions": veto_conditions,
        "indicators": {
            "ROE": {"value": roe, "score": score_indicator(roe, THRESHOLDS["roe"])},
            "收现比": {"value": cash_ratio, "score": score_indicator(cash_ratio, THRESHOLDS["cash_ratio"])},
            "资产负债率": {"value": debt_ratio, "score": score_indicator(debt_ratio, THRESHOLDS["debt_ratio"], inverse=True)},
            "商誉/净资产": {"value": goodwill_ratio, "score": score_indicator(goodwill_ratio, THRESHOLDS["goodwill_ratio"], inverse=True)},
            "毛利率": {"value": gross_margin, "score": score_indicator(gross_margin, THRESHOLDS["gross_margin"])},
            "北向资金": {"value": hsgt_ratio, "score": "✅" if hsgt_ratio >= 3 else ("⚠️" if hsgt_ratio >= 1 else "❌")},
        }
    }


def format_report(name: str, code: str, data: dict, result: dict) -> str:
    """格式化输出分析报告"""
    lines = [
        f"\n{'='*60}",
        f"  {name}（{code}）· Buddy方法论分析",
        f"{'='*60}",
        f"\n  评级：{result['rating']} {RATING_SYMBOLS.get(result['rating'], '')}",
        f"\n  综合得分：{result['score']}/5",
        f"\n  结论：{result['summary']}",
        f"\n{'─'*60}",
        f"  核心指标",
        f"{'─'*60}",
    ]

    for indicator, info in result["indicators"].items():
        lines.append(f"  {indicator:12s} {info['value']:>8}  {info['score']}")

    if result["positive_conditions"]:
        lines.append(f"\n{'─'*60}")
        lines.append(f"  ✅ 亮点")
        lines.append(f"{'─'*60}")
        for cond in result["positive_conditions"]:
            lines.append(f"  • {cond}")

    if result["veto_conditions"]:
        lines.append(f"\n{'─'*60}")
        lines.append(f"  ❌ 风险")
        lines.append(f"{'─'*60}")
        for cond in result["veto_conditions"]:
            lines.append(f"  • {cond}")

    lines.append(f"\n{'='*60}\n")
    return "\n".join(lines)


# ============================================================
# 示例数据（当neodata不可用时）
# ============================================================

SAMPLE_DATA = {
    "兆易创新": {
        "code": "603986",
        "data": {
            "roe": 9.3, "cash_ratio": 184, "debt_ratio": 14.9,
            "goodwill_ratio": 2, "pledge_ratio": 0, "receivable_ratio": 8,
            "interest_debt_ratio": 2, "gross_margin": 38, "hsgt_ratio": 6.19
        }
    },
    "江波龙": {
        "code": "301308",
        "data": {
            "roe": -12.38, "cash_ratio": -235, "debt_ratio": 64.7,
            "goodwill_ratio": 15, "pledge_ratio": 36, "receivable_ratio": 55,
            "interest_debt_ratio": 45, "gross_margin": 9, "hsgt_ratio": 0.3
        }
    },
    "浪潮信息": {
        "code": "000977",
        "data": {
            "roe": 3.5, "cash_ratio": -50, "debt_ratio": 73.6,
            "goodwill_ratio": 5, "pledge_ratio": 25, "receivable_ratio": 65,
            "interest_debt_ratio": 55, "gross_margin": 4.9, "hsgt_ratio": 1.2
        }
    },
    "光环新网": {
        "code": "300383",
        "data": {
            "roe": -8.0, "cash_ratio": 30, "debt_ratio": 35,
            "goodwill_ratio": 85, "pledge_ratio": 0, "receivable_ratio": 20,
            "interest_debt_ratio": 25, "gross_margin": 18, "hsgt_ratio": 0.5
        }
    }
}


def main():
    print("\n🔍 Buddy方法论 · 个股分析工具")
    print("=" * 40)

    # 如果有命令行参数
    if len(sys.argv) > 1:
        stocks = sys.argv[1:]
    else:
        # 默认分析示例股票
        stocks = list(SAMPLE_DATA.keys())
        print("[提示] 未指定股票，使用示例数据演示")

    results = {}
    for stock_name in stocks:
        # 尝试从neodata获取真实数据
        if HAS_NEODATA:
            try:
                # 查询财务数据
                query_result = query_neodata(f"{stock_name} ROE 收现比 资产负债率 商誉 毛利率 北向资金")
                # 解析结果并计算
                data = parse_neodata_result(query_result)
            except Exception as e:
                print(f"[警告] 获取{stock_name}数据失败: {e}，使用示例数据")
                data = SAMPLE_DATA.get(stock_name, {}).get("data", {})
                code = SAMPLE_DATA.get(stock_name, {}).get("code", "N/A")
        else:
            sample = SAMPLE_DATA.get(stock_name, {})
            data = sample.get("data", {})
            code = sample.get("code", "N/A")

        if not data:
            print(f"[跳过] 未找到 {stock_name} 的数据")
            continue

        result = rate_stock(data)
        results[stock_name] = result

        # 输出报告
        report = format_report(stock_name, code, data, result)
        print(report)

    # 排序输出
    if len(results) > 1:
        print("\n🏆 排名（综合得分）")
        print("-" * 40)
        sorted_results = sorted(results.items(), key=lambda x: x[1]["score"], reverse=True)
        for i, (name, result) in enumerate(sorted_results, 1):
            print(f"  {i}. {name:12s} {result['rating']} ({result['score']}分)")


def parse_neodata_result(query_result: str) -> dict:
    """
    解析neodata返回的结果
    TODO: 根据实际API返回格式实现
    """
    # 这是一个占位符，需要根据实际API返回格式实现
    # 目前返回空字典，调用方会使用示例数据
    return {}


if __name__ == "__main__":
    main()
