---
name: seedance-2-0
display_name: Seedance 2.0
description: 字节跳动 Seedance 2.0 AI 视频生成技能，支持文生图、文生视频，提供快速生成封装
version: 2.0.0
author: zll
---

# Seedance 2.0 - 字节跳动AI视频生成技能

## 功能描述

提供便捷的API调用封装，支持提示词配置化快速生成视频。

Seedance 2.0 是字节跳动最新的AI视频生成模型，支持文生视频、图生视频等功能，现已开放公测！

## 功能

1. **快速生成** - 封装API调用，支持常见场景提示词模板配置化
2. **支持多种参数配置** - 模型选择、时长、分辨率、比例等
3. **下载结果** - 自动下载生成的视频文件到本地，同时生成一个可临时访问链接

## 配置

本技能读取环境变量 `ARK_API_KEY` 和 `ARK_BASE_URL` 配置：

- `ARK_API_KEY` - 火山引擎API密钥（从火山引擎控制台获取）
- `ARK_BASE_URL` - 默认 `https://ark.cn-beijing.volces.com/api/v3`
- 默认模型：`doubao-seedance-2-0-260128`

## 使用方式

### 生成视频
```
用seedance生成视频，提示词：...
```

支持参数：
- 模型选择（pro/fast/lite）
- 时长（5s/10s/15s）
- 比例（9:16/16:9/1:1）
- 分辨率（720p/1080p）

## 合规说明

必须遵守内容审核：
- 通用安全：禁涉黄、涉恐、涉敏
- 版权：禁未授权IP作品、公众人物、版权音乐
