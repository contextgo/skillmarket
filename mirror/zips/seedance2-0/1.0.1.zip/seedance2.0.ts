#!/usr/bin/env bun

/**
 * Seedance 2.0 AI视频生成技能
 *
 * 功能：
 * 1. 调用API生成视频
 * 2. 下载生成结果
 */

import { parseArgs } from 'util';
import fs from 'fs';
import path from 'path';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);

// 加载环境变量
import dotenv from 'dotenv';
dotenv.config({ path: path.join(__dirname, '.env') });

// 默认提示词模板配置
export const PROMPT_TEMPLATES = {
  "promo": "产品宣传促销视频，吸引人的视觉效果，清晰的产品展示，购买呼吁，适合社交媒体分享",
  "event": "活动预告短视频，倒计时展示，活动信息清晰，激发观众兴趣参与，节奏轻快",
  "vlog": "日常生活vlog片段，自然流畅，真实风格，适合竖屏观看",
  "education": "知识科普短视频，清晰讲解，图文并茂，生动有趣，便于理解",
  "marketing": "营销短视频，产品卖点突出，行动召唤明确，高转化率"
};

// 模型配置
export const MODEL_CONFIGS = {
  "pro": "doubao-seedance-2-0-260128",
  "fast": "doubao-seedance-2-0-fast-260128",
  "lite": "doubao-seedance-1-0-lite"
};

export interface SeedanceOptions {
  prompt: string;
  model?: keyof typeof MODEL_CONFIGS;
  duration?: number; // 5, 10, 15 (seconds)
  ratio?: "16:9" | "9:16" | "1:1";
  generateAudio?: boolean;
  watermark?: boolean;
  outputPath?: string;
  referenceImages?: string[];
  referenceVideos?: string[];
  referenceAudios?: string[];
}


export function getApiConfig() {
  const apiKey = process.env.ARK_API_KEY;
  // ARK endpoint for Seedance
  const baseUrl = process.env.ARK_BASE_URL || "https://ark.cn-beijing.volces.com/api/v3";

  if (!apiKey) {
    throw new Error("ARK_API_KEY environment variable is required");
  }

  return { apiKey, baseUrl };
}

export function getModelId(model: keyof typeof MODEL_CONFIGS): string {
  return MODEL_CONFIGS[model] || MODEL_CONFIGS.pro;
}

export function getPromptFromTemplate(templateName: string, customPrompt?: string): string {
  const basePrompt = PROMPT_TEMPLATES[templateName as keyof typeof PROMPT_TEMPLATES] || "";
  if (customPrompt) {
    return `${basePrompt} ${customPrompt}`;
  }
  return basePrompt;
}

export async function generateVideo(options: SeedanceOptions): Promise<string> {
  const { apiKey, baseUrl } = getApiConfig();
  const modelId = getModelId(options.model || "pro");

  const ratio = options.ratio || "16:9";
  const duration = options.duration || 15;
  const generateAudio = options.generateAudio !== undefined ? options.generateAudio : true;
  const watermark = options.watermark !== undefined ? options.watermark : false;

  // Build content array
  const content = [
    {
      type: "text",
      text: options.prompt
    }
  ];

  // Add reference images if provided
  if (options.referenceImages && options.referenceImages.length > 0) {
    for (const url of options.referenceImages) {
      content.push({
        type: "image_url",
        image_url: { url },
        role: "reference_image"
      });
    }
  }

  // Add reference videos if provided
  if (options.referenceVideos && options.referenceVideos.length > 0) {
    for (const url of options.referenceVideos) {
      content.push({
        type: "video_url",
        video_url: { url },
        role: "reference_video"
      });
    }
  }

  // Add reference audios if provided
  if (options.referenceAudios && options.referenceAudios.length > 0) {
    for (const url of options.referenceAudios) {
      content.push({
        type: "audio_url",
        audio_url: { url },
        role: "reference_audio"
      });
    }
  }

  const requestBody = {
    model: modelId,
    content: content,
    generate_audio: generateAudio,
    ratio: ratio,
    duration: duration,
    watermark: watermark
  };

  console.log("Starting video generation with parameters:");
  console.log(JSON.stringify(requestBody, null, 2));

  const endpoint = `${baseUrl}/contents/generations/tasks`;
  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify(requestBody)
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`API request failed: ${response.status} - ${error}`);
  }

  const data = await response.json();
  const taskId = data.id;

  console.log(`Generation started: ${taskId}`);
  console.log("Waiting for completion...");

  // Poll for completion
  let result = null;
  for (let i = 0; i < 60; i++) { // 最长等待10分钟
    await new Promise(resolve => setTimeout(resolve, 10000)); // 每10秒检查一次

    const statusResponse = await fetch(`${baseUrl}/contents/generations/tasks/${taskId}`, {
      headers: {
        "Authorization": `Bearer ${apiKey}`
      }
    });

    if (!statusResponse.ok) {
      console.warn(`Status check failed: ${statusResponse.status}, retrying...`);
      continue;
    }

    const statusData = await statusResponse.json();

    if (statusData.status === "completed") {
      result = statusData;
      break;
    } else if (statusData.status === "failed") {
      throw new Error(`Generation failed: ${statusData.error || "unknown error"}`);
    } else {
      console.log(`Current status: ${statusData.status}, continuing to wait...`);
    }
  }

  if (!result) {
    throw new Error("Generation timed out after 10 minutes");
  }

  const videoUrl = result.content[0].video_url;
  console.log(`Generation completed! Video URL: ${videoUrl}`);

  // Download the video if output path is specified
  if (options.outputPath) {
    console.log(`Downloading video to ${options.outputPath}...`);
    const videoResponse = await fetch(videoUrl);
    if (!videoResponse.ok) {
      throw new Error(`Failed to download video: ${videoResponse.status}`);
    }
    const videoBuffer = Buffer.from(await videoResponse.arrayBuffer());
    fs.writeFileSync(options.outputPath, videoBuffer);
    console.log(`Video saved to: ${options.outputPath}`);
  }

  return videoUrl;
}

// 打印帮助信息
function printHelp() {
  console.log(`
Seedance 2.0 AI 视频生成工具
============================

使用方式:
  bun seedance2.0.ts --prompt "提示词" [选项]

必选参数（任选其一）:
  --prompt, -p "文本"    自定义生成提示词
  --template, -t 名称    使用内置模板 (promo/event/vlog/education/marketing)

可选参数:
  --model, -m 模型       选择模型 (pro/fast/lite) 默认: pro
  --duration, -d 秒数    视频时长 (5/10/15) 默认: 15
  --ratio, -r 比例       视频比例 (16:9/9:16/1:1) 默认: 16:9
  --no-audio             关闭音频生成
  --watermark            开启水印
  --ref-image URL        添加参考图片（可多次使用）
  --ref-video URL        添加参考视频（可多次使用）
  --ref-audio URL        添加参考音频（可多次使用）
  --output, -o 文件      输出文件路径

示例:
  bun seedance2.0.ts --prompt "美丽的海滩日落"
  bun seedance2.0.ts --template promo --prompt "新品上市"
  bun seedance2.0.ts --prompt "产品演示" --model pro --duration 15 --ratio 16:9

配置:
  复制 .env.example 为 .env 并填入 ARK_API_KEY
`);
}

// CLI main
async function main() {
  const { values } = parseArgs({
    args: Bun.argv,
    options: {
      'help': { type: 'boolean' },
      'prompt': { type: 'string', short: 'p' },
      'model': { type: 'string', short: 'm', default: 'pro' },
      'duration': { type: 'string', short: 'd', default: '5' },
      'ratio': { type: 'string', short: 'r', default: '16:9' },
      'no-audio': { type: 'boolean' },
      'watermark': { type: 'boolean' },
      'template': { type: 'string', short: 't' },
      'output': { type: 'string', short: 'o' },
      'ref-image': { type: 'string', multiple: true },
      'ref-video': { type: 'string', multiple: true },
      'ref-audio': { type: 'string', multiple: true },
    },
    allowPositionals: true
  });

  if (values.help) {
    printHelp();
    process.exit(0);
  }

  if (!values.prompt && !values.template) {
    console.error("Error: either --prompt or --template is required");
    console.log("Use --help for more information");
    process.exit(1);
  }

  let prompt = values.prompt || "";
  if (values.template && PROMPT_TEMPLATES[values.template as keyof typeof PROMPT_TEMPLATES]) {
    prompt = getPromptFromTemplate(values.template, prompt);
  }

  const options: SeedanceOptions = {
    prompt,
    model: (values.model as any) || "pro",
    duration: parseInt(values.duration || "15"),
    ratio: (values.ratio as any) || "16:9",
    generateAudio: !values['no-audio'],
    watermark: values.watermark || false,
    outputPath: values.output || `seedance-${Date.now()}.mp4`,
    referenceImages: values['ref-image'] || [],
    referenceVideos: values['ref-video'] || [],
    referenceAudios: values['ref-audio'] || [],
  };

  try {
    const videoUrl = await generateVideo(options);
    console.log("\n✅ Generation completed successfully!");
    console.log(`Video URL: ${videoUrl}`);
    if (options.outputPath) {
      console.log(`File saved to: ${options.outputPath}`);
    }
  } catch (error) {
    console.error("❌ Error:", (error as Error).message);
    process.exit(1);
  }
}

// Run if called directly
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
if (process.argv[1] === __filename) {
  main();
}
