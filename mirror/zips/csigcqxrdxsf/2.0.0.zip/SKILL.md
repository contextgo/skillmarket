---
name: DXSF.Skill
description: 从图片中提取客户信息（客户名称、CID、UIN列表）并整理到Excel表格。自动检测重复客户避免重复录入，支持按月份自动生成文件名"电销通路释放名单YYYYMM.xlsx"。当用户需要从截图或图片中提取企业/个人名称、CID编号、UIN编号等客户信息并生成结构化Excel报表时使用此Skill。
triggers:
  - 提取图片信息
  - 识别图片中的CID
  - 整理客户信息到Excel
  - 从截图提取UIN
  - 客户信息提取
  - OCR识别客户信息
  - 电销通路释放名单
  - 客户释放记录
---

# 信息提取与整理 Skill

## 概述

本Skill用于从图片（截图）中自动提取客户信息，包括：
- 左上角的企业或个人名称（客户名称）
- 客户信息下方的CID编号
- UIN列表后的数字

提取的信息会自动整理到Excel表格中，包含：客户名称、CID、UIN列表、释放原因、释放时间。

**核心特性：**
- ✅ **全自动流程**：接收图片 → 保存到桌面 → 识别信息 → 填入Excel → 删除临时图片
- ✅ 自动按月份命名Excel文件：`电销通路释放名单YYYYMM.xlsx`
- ✅ 自动保存到桌面
- ✅ 重复客户检测：通过CID或UIN判断，避免重复录入
- ✅ 自动合并：新识别的内容追加到已有文件
- ✅ 批量处理：支持一次处理多张图片
- ✅ 自动清理：处理完成后删除桌面临时图片

## 使用场景

- 处理客户信息截图，提取关键字段
- 批量整理客户释放记录
- 将图片中的结构化信息转为Excel报表
- 电销通路客户释放名单管理

## 前置依赖

使用本Skill前，确保系统已安装以下Python包：

```bash
pip install pytesseract Pillow openpyxl
```

同时需要安装Tesseract-OCR引擎：
- Windows: 下载安装包 https://github.com/UB-Mannheim/tesseract/wiki
- macOS: `brew install tesseract tesseract-lang`（需安装中文语言包）
- Linux: `sudo apt-get install tesseract-ocr tesseract-ocr-chi-sim`

## 工作流程

### 单张图片处理

1. 接收用户提供的图片路径和释放原因
2. 使用OCR识别图片中的文本
3. 提取客户名称、CID、UIN
4. **检查是否重复**（通过CID或UIN判断）
5. 如果是新客户，追加到Excel文件
6. 如果是重复客户，提示已录入并跳过

### 批量图片处理

1. 接收多张图片及其对应的释放原因
2. 依次处理每张图片
3. 自动过滤已录入的重复客户
4. 将新数据汇总到同一个Excel文件

## 使用方法

### 方式一：全自动处理（推荐）

直接发送图片给我，我会自动完成：
1. 保存图片到桌面临时文件夹
2. 识别客户信息（客户名称、CID、UIN）
3. 填入Excel（自动去重）
4. 删除临时图片

**你只需发送：** 图片 + 释放原因

**示例：**
```
@image 释放原因：无收入，无法联系
```

### 方式二：自动处理文件夹

将图片放入 `C:\Users\liyang\Desktop\新建文件夹`，然后运行：

```bash
python scripts/auto_process.py "释放原因"
```

系统会自动：
1. 读取文件夹中的所有图片
2. 识别客户信息
3. 录入到Excel（自动去重）

### 方式二：命令行调用

**单张图片（自动命名）：**
```bash
python scripts/extract_info.py "图片路径.png" "释放原因"
# 输出: 桌面/电销通路释放名单202604.xlsx
```

**单张图片（自定义路径）：**
```bash
python scripts/extract_info.py "图片路径.png" "释放原因" "自定义.xlsx"
```

**批量处理（自动命名）：**
```bash
python scripts/batch_extract.py "图片1.png" "原因1" "图片2.png" "原因2"
```

**批量处理（自定义Excel）：**
```bash
python scripts/batch_extract.py "自定义.xlsx" "图片1.png" "原因1" "图片2.png" "原因2"
```

### Python API调用

```python
from scripts.extract_info import process_image, get_excel_filename

# 使用自动生成的文件名
excel_path = get_excel_filename()  # 桌面/电销通路释放名单202604.xlsx

result, error = process_image(
    image_path="path/to/image.png",
    release_reason="客户主动释放",
    excel_path=excel_path
)

if result:
    print(f"成功录入: {result['extracted_data']}")
else:
    print(f"处理失败: {error}")  # 可能提示"该客户信息已经录入"
```

## 文件命名规则

Excel文件自动命名为：
```
电销通路释放名单YYYYMM.xlsx
```
- 存储位置：电脑桌面
- 示例：`电销通路释放名单202604.xlsx`（2026年4月）
- 同月数据自动合并到同一文件

## 重复检测机制

### 检测逻辑
- 通过 **CID** 判断：如果CID已存在，视为重复
- 通过 **UIN** 判断：如果UIN已存在，视为重复
- **CID或UIN任一匹配，即视为同一客户**（即使释放原因不同，也不再重复录入）
- 不依赖释放原因判断重复性

### 处理结果
- **新客户**：正常录入Excel，返回成功
- **重复客户**：提示"该客户信息已经录入"，跳过不重复录入

### 示例提示
```
⚠ 跳过: CID 'CID12345' 已存在（客户：示例公司）
⚠ 跳过: UIN '987654321' 已存在（客户：测试企业）
```

## 提取规则说明

### 客户名称提取
- **优先匹配**：识别"客户名称"字段后的内容
- **备选方案**：取图片左上角前3行中非空的文本
- 自动过滤包含"CID"、"UIN"、"客户"、"信息"、"列表"等关键词的行
- **示例**：`遐想电子商务(深圳)有限公司`

### CID提取
- 支持多种格式：CID:xxx、CID：xxx、CID xxx
- 优先匹配32位十六进制字符串（如：`4fd06258fda3364b0ecaef4182f7d9e4`）
- 支持字母数字组合（含连字符和下划线）
- **示例**：`CID: 4fd06258fda3364b0ecaef4182f7d9e4` → `4fd06258fda3364b0ecaef4182f7d9e4`

### UIN提取
- 支持格式：UIN列表:xxx、UIN列表 : xxx（支持空格）、UIN:xxx
- 优先匹配12位数字（如：`100040402456`）
- 如果未找到明确标记，搜索UIN关键词附近的数字
- **示例**：`UIN列表 : 100040402456` → `100040402456`

### 释放时间
- 自动使用当前系统时间
- 格式：YYYY-MM-DD HH:MM:SS

## Excel输出格式

| 客户名称 | CID | UIN列表 | 释放原因 | 释放时间 |
|---------|-----|---------|---------|---------|
| 示例公司 | CID12345 | 987654321 | 客户主动释放 | 2024-01-15 10:30:00 |

- 表头自动加粗居中
- 列宽根据内容自动调整
- 支持追加写入已有Excel文件

## 脚本说明

### scripts/extract_info.py
主要提取脚本，包含以下函数：
- `get_desktop_path()`: 获取桌面路径
- `get_excel_filename()`: 生成月度Excel文件名
- `extract_text_from_image()`: OCR文本识别
- `extract_customer_name()`: 提取客户名称
- `extract_cid()`: 提取CID
- `extract_uin_list()`: 提取UIN
- `check_duplicate()`: 检查客户是否已存在
- `create_or_update_excel()`: 创建/更新Excel
- `process_image()`: 主处理函数

### scripts/batch_extract.py
批量处理脚本，支持一次处理多张图片，自动汇总处理结果。

## 注意事项

1. 图片清晰度会影响OCR识别准确率
2. 中文识别需要安装tesseract的中文语言包
3. 如果提取结果不准确，可以调整正则表达式模式
4. Excel文件自动保存到桌面，按月份命名
5. 重复客户会自动跳过，不会重复录入

## 故障排除

### OCR识别失败
- 检查Tesseract是否正确安装
- 确认中文语言包已安装（chi_sim）
- 尝试提高图片清晰度

### 提取字段为空
- 检查图片中是否包含目标信息
- 查看原始OCR文本：`result['raw_text']`
- 根据实际格式调整正则表达式

### Excel文件损坏
- 确保文件未被其他程序占用
- 检查文件路径是否有写入权限

### 重复检测不生效
- 确认Excel文件没有被手动修改CID/UIN格式
- 检查CID/UIN前后是否有空格
