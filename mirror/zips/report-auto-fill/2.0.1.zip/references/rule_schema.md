# 规则库数据结构规范（Rule Schema）

## 一、规则库文件路径

```
~/.workbuddy/report_rules/rules_db.json
```

## 二、整体结构

```json
{
  "signatures": {
    "<sig_id>": { ... }
  },
  "rules": {
    "<rule_id>": { ... }
  }
}
```

---

## 三、报签（Signature）字段说明

```json
{
  "sig_id":      "a1b2c3d4",          // 8位随机ID，唯一标识报签
  "name":        "资产负债表",          // 报表名称（人类可读）
  "report_type": "financial",          // 报表类型（见下方枚举）
  "description": "年报资产负债表季报",   // 描述（可选）
  "key_fields":  ["资产", "负债", "所有者权益", "货币资金"],  // 核心字段特征（用于模糊匹配）
  "created_at":  "2024-01-01 09:00:00",
  "updated_at":  "2024-01-15 14:30:00"
}
```

### report_type 枚举值
- `financial`   — 财务报表（资产负债表、利润表、现金流量表等）
- `statistical` — 统计报表
- `business`    — 业务报表
- `regulatory`  — 监管报表
- `management`  — 管理报表
- `other`       — 其他

---

## 四、规则（Rule）字段说明

```json
{
  "rule_id":      "abc123def456",     // 12位随机ID，唯一标识规则
  "sig_id":       "a1b2c3d4",         // 关联的报签ID
  "output_field": "货币资金",          // 输出报表中的字段名/行名
  "source_field": "1001,1002",        // 原始数据中的字段名（逗号分隔=求和，单个=直接映射）
  "logic":        "库存现金+银行存款期末余额合计",  // 取数逻辑（自然语言描述）
  "formula":      "1001科目期末余额 + 1002科目期末余额",  // 计算公式（可选）
  "cell_address": "C5",               // 在模板Excel中的单元格地址（可选，但推荐填写）
  "source":       "ai_generated",     // 规则来源（见下方枚举）
  "notes":        "仅含人民币口径",    // 备注（可选）
  "created_at":   "2024-01-01 09:00:00",
  "updated_at":   "2024-01-15 14:30:00",
  "active":       true                // 是否启用（false=软删除）
}
```

### source 枚举值
- `ai_generated`   — AI自主判断生成
- `user_provided`  — 用户主动提供
- `user_corrected` — 用户修正后的规则

---

## 五、批量导入格式（JSON数组）

用于 `import-rules` 命令的输入文件格式：

```json
[
  {
    "output_field": "货币资金",
    "source_field": "1001,1002",
    "logic": "库存现金+银行存款",
    "formula": "",
    "cell_address": "C5",
    "source": "user_provided",
    "notes": ""
  },
  {
    "output_field": "应收账款",
    "source_field": "1122",
    "logic": "应收账款科目期末余额",
    "formula": "",
    "cell_address": "C8",
    "source": "user_provided",
    "notes": "需减去坏账准备"
  },
  {
    "output_field": "流动资产合计",
    "source_field": "",
    "logic": "货币资金+应收账款+存货+预付账款之和",
    "formula": "货币资金 + 应收账款 + 存货 + 预付账款",
    "cell_address": "C20",
    "source": "ai_generated",
    "notes": "合计行，按公式自动计算"
  }
]
```

---

## 六、公式计算支持范围

`fill_report.py` 支持以下公式格式：

| 格式 | 示例 | 说明 |
|------|------|------|
| 字段加法 | `货币资金 + 应收账款` | 多字段相加 |
| 字段减法 | `营业收入 - 营业成本` | 字段相减 |
| 混合加减 | `收入 - 成本 - 费用` | 混合运算 |
| 纯数字 | `1000000` | 固定值 |

**注意**：
- 公式中的字段名必须与原始数据的字段名（或其行标签）一致（支持模糊匹配）
- 不支持乘除、括号嵌套等复杂公式（如需复杂计算，建议在源数据中预先计算好）

---

## 七、规则复用说明

- 相同类型报表（同一报签 sig_id）的规则会自动复用
- 下次遇到同类型报表时，系统自动调用已有规则，无需重建
- 规则更新（user_corrected）后自动替换，历史规则通过 updated_at 追踪
- 如同类报表因期间/版本不同导致规则差异，建议新建独立报签
