#!/usr/bin/env python3
"""
fill_report.py - 报表自动填报脚本

功能：
1. 根据规则库中的填写规则，从原始数据文件提取数据
2. 将提取结果写入报表模板文件（Excel格式）
3. 支持简单公式计算（如科目相加、科目相减）
4. 输出填报完成的Excel文件
5. ⚠️ 填报前强制校验规则库状态（规则先行原则）

使用方式：
    python fill_report.py fill <sig_id> <data_file> <template_file> [output_file]
    python fill_report.py preview <sig_id> <data_file>   # 仅预览提取结果，不写文件

参数：
    sig_id          报签ID（规则库中对应报签）
    data_file       原始数据文件（Excel/CSV）
    template_file   报表模板文件（Excel，需有字段占位符或已知单元格位置）
    output_file     输出文件路径（默认：template_file名称_filled.xlsx）

注意：
    - 报表模板中的字段单元格需在规则中指定 cell_address（如 "B5"）
    - 若未指定 cell_address，则仅做数据匹配预览

⚠️ 规则先行原则：
    - 执行 fill 命令时，脚本会强制校验规则库中是否有足够规则
    - 规则覆盖不足时将拒绝执行并提示补齐规则
    - 禁止绕过规则库直接写入数值
"""

import sys
import json
import os
from pathlib import Path
from datetime import datetime


def _load_db():
    store_file = Path.home() / ".workbuddy" / "report_rules" / "rules_db.json"
    if store_file.exists():
        with open(store_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"signatures": {}, "rules": {}}


def _check_dep(pkg):
    import importlib
    try:
        importlib.import_module(pkg)
        return True
    except ImportError:
        return False


def _require(pkg, install_name=None):
    if not _check_dep(pkg):
        name = install_name or pkg
        print(f"[提示] 缺少依赖 {pkg}，请先运行：pip install {name}", file=sys.stderr)
        sys.exit(1)


# ─────────────────────────────────────────────
#  原始数据读取（扁平化为 {字段: 值} 字典）
# ─────────────────────────────────────────────

def load_source_data(file_path: str) -> dict:
    """
    读取原始数据文件，返回两种结构：
    1. flat_data: {字段名: 值} 用于简单字段映射
    2. df_data:   {sheet名: DataFrame} 用于公式计算
    """
    _require("pandas")
    _require("openpyxl")
    import pandas as pd

    ext = Path(file_path).suffix.lower()
    flat_data = {}
    df_data = {}

    if ext in (".xlsx", ".xls", ".xlsm"):
        xl = pd.ExcelFile(file_path)
        for sheet in xl.sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet)
            df_data[sheet] = df
            # 将每个字段的第一个非空值写入 flat_data
            for col in df.columns:
                col_str = str(col).strip()
                non_null = df[col].dropna()
                if not non_null.empty and col_str not in flat_data:
                    flat_data[col_str] = non_null.iloc[0]
            # 如果DataFrame是二维表（如余额表），尝试建立 {科目名: 金额} 索引
            # 常见结构：第一列=科目/项目名，第二列=金额/数值
            if len(df.columns) >= 2:
                key_col = df.columns[0]
                val_col = df.columns[1]
                for _, row in df.iterrows():
                    k = str(row[key_col]).strip() if not _is_nan(row[key_col]) else None
                    v = row[val_col] if not _is_nan(row[val_col]) else None
                    if k and v is not None:
                        flat_data[k] = v

    elif ext == ".csv":
        import pandas as pd
        df = pd.read_csv(file_path, encoding="utf-8-sig")
        df_data["Sheet1"] = df
        for col in df.columns:
            non_null = df[col].dropna()
            if not non_null.empty:
                flat_data[str(col).strip()] = non_null.iloc[0]

    return {"flat": flat_data, "frames": df_data}


def _is_nan(v):
    try:
        import math
        return math.isnan(float(v))
    except Exception:
        return v is None or str(v).strip() in ("", "nan", "NaN", "None")


# ─────────────────────────────────────────────
#  规则执行：根据 source_field + formula 取值
# ─────────────────────────────────────────────

def apply_rule(rule: dict, source_data: dict) -> tuple:
    """
    执行单条规则，返回 (value, note)
    支持：
    - 直接字段映射：source_field = "货币资金"
    - 简单加减公式：formula = "科目101 + 科目102 - 科目201"
    - 多字段逗号分隔求和：source_field = "货币资金,银行存款"
    """
    flat = source_data.get("flat", {})
    formula = rule.get("formula", "").strip()
    source_field = rule.get("source_field", "").strip()

    # 1. 优先尝试公式
    if formula:
        try:
            value = _eval_formula(formula, flat)
            return (value, f"公式计算: {formula}")
        except Exception as e:
            pass  # 公式失败则降级到字段匹配

    # 2. 多字段求和（逗号分隔）
    if "," in source_field:
        fields = [f.strip() for f in source_field.split(",")]
        total = 0
        found = False
        for f in fields:
            v = _fuzzy_get(flat, f)
            if v is not None:
                try:
                    total += float(v)
                    found = True
                except Exception:
                    pass
        if found:
            return (total, f"多字段求和: {source_field}")

    # 3. 单字段直接映射（模糊匹配）
    v = _fuzzy_get(flat, source_field)
    if v is not None:
        return (v, f"字段映射: {source_field}")

    return (None, f"未找到字段: {source_field}")


def _fuzzy_get(flat: dict, key: str):
    """从扁平数据中模糊匹配字段（大小写、空格不敏感）"""
    if not key:
        return None
    key_lower = key.lower().replace(" ", "")
    # 完全匹配
    if key in flat:
        return flat[key]
    # 模糊匹配
    for k, v in flat.items():
        if k.lower().replace(" ", "") == key_lower:
            return v
    # 包含匹配
    for k, v in flat.items():
        if key_lower in k.lower() or k.lower() in key_lower:
            return v
    return None


def _eval_formula(formula: str, flat: dict):
    """
    解析简单加减公式，如 "货币资金 + 应收账款 - 预付账款"
    将字段名替换为实际数值后计算
    """
    import re
    # 找出公式中的所有字段名（非运算符、非数字的词）
    tokens = re.split(r"(\s*[+\-]\s*)", formula)
    result_expr = ""
    for token in tokens:
        token = token.strip()
        if token in ("+", "-"):
            result_expr += f" {token} "
        elif re.match(r"^[\d.]+$", token):
            result_expr += token
        else:
            # 字段名：去 flat 取值
            val = _fuzzy_get(flat, token)
            if val is None:
                raise ValueError(f"字段 '{token}' 在原始数据中未找到")
            result_expr += str(float(val))
    return eval(result_expr)  # nosec（仅处理数值表达式）


# ─────────────────────────────────────────────
#  填报执行
# ─────────────────────────────────────────────

def fill_report(sig_id: str, data_file: str, template_file: str, output_file: str = None) -> dict:
    """
    核心填报函数
    返回 {"success": bool, "output_file": str, "filled": [...], "missing": [...]}
    """
    _require("openpyxl")
    import openpyxl

    db = _load_db()

    # 检查报签
    sig = db["signatures"].get(sig_id)
    if not sig:
        return {"success": False, "error": f"未找到报签: {sig_id}"}

    # 获取规则
    rules = [r for r in db["rules"].values() if r["sig_id"] == sig_id and r.get("active", True)]
    if not rules:
        return {"success": False, "error": f"报签 {sig_id} 下无有效规则。⚠️ 规则先行原则：必须先建立并固化规则后再执行填报。"}

    # ⚠️ 规则校验门控：检查规则是否足够覆盖模板字段
    template_fields = _extract_template_fill_fields(template_file)
    if template_fields:
        covered = set()
        for r in rules:
            of = r.get("output_field", "").strip()
            if of:
                covered.add(of)
        uncovered = template_fields - covered
        if len(uncovered) > len(template_fields) * 0.5:
            # 超过50%的字段未覆盖，拒绝执行
            sample = list(uncovered)[:10]
            return {
                "success": False,
                "error": (
                    f"⛔ 规则覆盖率不足，拒绝执行填报。\n"
                    f"模板需填字段：{len(template_fields)} 个\n"
                    f"规则已覆盖：{len(covered)} 个\n"
                    f"未覆盖字段（{len(uncovered)} 个）：{sample}...\n"
                    f"请先为未覆盖字段补充规则（rule_store.py add-rule），再重新填报。"
                ),
                "coverage": {
                    "total_fields": len(template_fields),
                    "covered_fields": len(covered),
                    "uncovered_fields": list(uncovered),
                    "coverage_rate": round(len(covered) / len(template_fields) * 100, 1),
                },
            }

    # 读取原始数据
    source_data = load_source_data(data_file)

    # 打开模板
    wb = openpyxl.load_workbook(template_file)
    ws = wb.active

    filled = []
    missing = []

    for rule in rules:
        value, note = apply_rule(rule, source_data)
        output_field = rule["output_field"]
        cell_addr = rule.get("cell_address", "")

        if value is not None:
            # 若规则指定了单元格地址，直接写入
            if cell_addr:
                try:
                    ws[cell_addr] = value
                    filled.append({
                        "field": output_field,
                        "cell": cell_addr,
                        "value": value,
                        "note": note,
                    })
                except Exception as e:
                    missing.append({"field": output_field, "reason": str(e)})
            else:
                # 尝试在模板中搜索包含该字段名的单元格
                found_cell = _find_field_cell(ws, output_field)
                if found_cell:
                    # 写入相邻单元格（右侧一列）
                    target = ws.cell(row=found_cell.row, column=found_cell.column + 1)
                    target.value = value
                    filled.append({
                        "field": output_field,
                        "cell": target.coordinate,
                        "value": value,
                        "note": note,
                    })
                else:
                    filled.append({
                        "field": output_field,
                        "cell": "（未定位单元格）",
                        "value": value,
                        "note": note,
                    })
        else:
            missing.append({"field": output_field, "reason": note})

    # 保存输出文件
    if not output_file:
        p = Path(template_file)
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = str(p.parent / f"{p.stem}_filled_{ts}{p.suffix}")

    wb.save(output_file)

    return {
        "success": True,
        "sig_id": sig_id,
        "output_file": output_file,
        "filled_count": len(filled),
        "missing_count": len(missing),
        "filled": filled,
        "missing": missing,
    }


def _find_field_cell(ws, field_name: str):
    """在工作表中搜索包含字段名的单元格"""
    field_lower = field_name.lower()
    for row in ws.iter_rows():
        for cell in row:
            if cell.value and isinstance(cell.value, str):
                if field_lower in cell.value.lower() or cell.value.lower() in field_lower:
                    return cell
    return None


def _extract_template_fill_fields(template_file: str) -> set:
    """
    从报表模板中提取所有需填字段名（第一列非空单元格）。
    排除纯标题行（如"一、经营活动产生的现金流量"等大标题）和合计行。
    返回字段名集合。
    """
    _require("openpyxl")
    import openpyxl

    try:
        wb = openpyxl.load_workbook(template_file, data_only=True)
    except Exception:
        return set()

    fields = set()
    for ws in wb.worksheets:
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=True):
            if row[0] and isinstance(row[0], str):
                label = str(row[0]).strip()
                if label and len(label) > 1:
                    # 排除纯数字、纯序号
                    try:
                        float(label)
                        continue
                    except ValueError:
                        pass
                    fields.add(label)
    return fields


def preview_fill(sig_id: str, data_file: str) -> dict:
    """
    预览模式：不写文件，仅展示每条规则的取值结果
    """
    db = _load_db()
    sig = db["signatures"].get(sig_id)
    if not sig:
        return {"success": False, "error": f"未找到报签: {sig_id}"}

    rules = [r for r in db["rules"].values() if r["sig_id"] == sig_id and r.get("active", True)]
    source_data = load_source_data(data_file)

    preview = []
    for rule in rules:
        value, note = apply_rule(rule, source_data)
        preview.append({
            "output_field": rule["output_field"],
            "value": value,
            "note": note,
            "rule_id": rule["rule_id"],
        })
    return {"success": True, "preview": preview}


# ─────────────────────────────────────────────
#  CLI 入口
# ─────────────────────────────────────────────

def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(0)

    cmd = args[0]

    if cmd == "fill" and len(args) >= 4:
        sig_id = args[1]
        data_file = args[2]
        template_file = args[3]
        output_file = args[4] if len(args) > 4 else None
        result = fill_report(sig_id, data_file, template_file, output_file)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))

    elif cmd == "preview" and len(args) >= 3:
        sig_id = args[1]
        data_file = args[2]
        result = preview_fill(sig_id, data_file)
        print(json.dumps(result, ensure_ascii=False, indent=2, default=str))

    else:
        print(f"未知命令或参数不足：{' '.join(args)}")
        print("运行 `python fill_report.py` 查看帮助")
        sys.exit(1)


if __name__ == "__main__":
    main()
