#!/usr/bin/env python3
"""
rule_store.py - 报表填报规则库管理脚本

功能：
1. 报签（Report Signature）的创建、查询、列举
2. 填报规则的增加、修改、查询、删除
3. 规则库的持久化存储（JSON格式）
4. 规则导出为可读表格

使用方式：
    python rule_store.py <command> [options]

命令：
    list-sigs                       列出所有报签
    show-sig <sig_id>               显示某报签详情及规则
    add-sig <name> <type> [desc]    新增报签
    list-rules <sig_id>             列出某报签的所有规则
    add-rule <sig_id>               交互式新增规则（从stdin读取JSON）
    update-rule <rule_id>           更新规则（从stdin读取JSON）
    delete-rule <rule_id>           删除规则
    export-rules <sig_id>           以表格形式导出规则（便于AI输出给用户）
    import-rules <sig_id> <file>    从JSON文件批量导入规则
    check-coverage <sig_id> <模板文件>  校验规则覆盖率（规则 vs 模板需填字段）
"""

import json
import sys
import os
import uuid
from datetime import datetime
from pathlib import Path

# ─────────────────────────────────────────────
#  存储路径（默认放在 ~/.workbuddy/report_rules/）
# ─────────────────────────────────────────────
DEFAULT_STORE_DIR = Path.home() / ".workbuddy" / "report_rules"
STORE_FILE = DEFAULT_STORE_DIR / "rules_db.json"


def _load_db() -> dict:
    """加载规则库，若不存在则初始化空库"""
    if STORE_FILE.exists():
        with open(STORE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"signatures": {}, "rules": {}}


def _save_db(db: dict):
    """持久化规则库"""
    DEFAULT_STORE_DIR.mkdir(parents=True, exist_ok=True)
    with open(STORE_FILE, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


# ─────────────────────────────────────────────
#  报签管理
# ─────────────────────────────────────────────

def list_signatures(db: dict) -> list:
    """返回所有报签列表"""
    return list(db["signatures"].values())


def get_signature(db: dict, sig_id: str) -> dict | None:
    return db["signatures"].get(sig_id)


def find_signature_by_name(db: dict, name: str) -> dict | None:
    """按报表名称（模糊）查找报签"""
    name_lower = name.lower()
    for sig in db["signatures"].values():
        if name_lower in sig["name"].lower() or name_lower in sig.get("description", "").lower():
            return sig
    return None


def add_signature(db: dict, name: str, report_type: str,
                  description: str = "", key_fields: list = None) -> dict:
    """
    新增报签
    :param name:        报表名称（如"资产负债表"）
    :param report_type: 报表类型（financial/statistical/business/other）
    :param description: 描述
    :param key_fields:  核心字段特征列表
    :return: 新报签 dict
    """
    sig_id = str(uuid.uuid4())[:8]
    sig = {
        "sig_id": sig_id,
        "name": name,
        "report_type": report_type,
        "description": description,
        "key_fields": key_fields or [],
        "created_at": _now(),
        "updated_at": _now(),
    }
    db["signatures"][sig_id] = sig
    _save_db(db)
    return sig


def update_signature(db: dict, sig_id: str, **kwargs) -> dict | None:
    """更新报签字段"""
    sig = db["signatures"].get(sig_id)
    if not sig:
        return None
    for k, v in kwargs.items():
        if k in sig:
            sig[k] = v
    sig["updated_at"] = _now()
    _save_db(db)
    return sig


# ─────────────────────────────────────────────
#  规则管理
# ─────────────────────────────────────────────

def list_rules(db: dict, sig_id: str) -> list:
    """返回指定报签下的所有规则"""
    return [r for r in db["rules"].values() if r["sig_id"] == sig_id]


def get_rule(db: dict, rule_id: str) -> dict | None:
    return db["rules"].get(rule_id)


def add_rule(db: dict, sig_id: str, rule_data: dict) -> dict:
    """
    新增规则
    rule_data 必须字段：
        output_field   : 输出报表字段名
        source_field   : 原始数据来源字段名/表达式
        logic          : 取数逻辑描述（自然语言）
        formula        : 计算公式（可选，如 "科目101+科目102"）
        source         : 规则来源（ai_generated / user_provided / user_corrected）
        notes          : 备注（可选）
    """
    rule_id = str(uuid.uuid4())[:12]
    rule = {
        "rule_id": rule_id,
        "sig_id": sig_id,
        "output_field": rule_data.get("output_field", ""),
        "source_field": rule_data.get("source_field", ""),
        "logic": rule_data.get("logic", ""),
        "formula": rule_data.get("formula", ""),
        "source": rule_data.get("source", "ai_generated"),  # ai_generated / user_provided / user_corrected
        "notes": rule_data.get("notes", ""),
        "created_at": _now(),
        "updated_at": _now(),
        "active": True,
    }
    db["rules"][rule_id] = rule
    _save_db(db)
    return rule


def update_rule(db: dict, rule_id: str, rule_data: dict) -> dict | None:
    """更新规则，并将来源标记为 user_corrected"""
    rule = db["rules"].get(rule_id)
    if not rule:
        return None
    updatable = ["output_field", "source_field", "logic", "formula", "notes", "active"]
    for k in updatable:
        if k in rule_data:
            rule[k] = rule_data[k]
    # 若用户修正，来源升级
    if rule_data.get("source"):
        rule["source"] = rule_data["source"]
    else:
        rule["source"] = "user_corrected"
    rule["updated_at"] = _now()
    _save_db(db)
    return rule


def delete_rule(db: dict, rule_id: str) -> bool:
    if rule_id in db["rules"]:
        del db["rules"][rule_id]
        _save_db(db)
        return True
    return False


def bulk_add_rules(db: dict, sig_id: str, rules_list: list) -> list:
    """批量新增规则"""
    added = []
    for r in rules_list:
        added.append(add_rule(db, sig_id, r))
    return added


def _extract_template_fields(template_file: str) -> set:
    """从报表模板中提取所有需填字段名（第一列非空单元格）"""
    try:
        import openpyxl
        wb = openpyxl.load_workbook(template_file, data_only=True)
    except Exception:
        return set()
    fields = set()
    for ws in wb.worksheets:
        for row in ws.iter_rows(min_row=1, max_row=ws.max_row, values_only=True):
            if row[0] and isinstance(row[0], str):
                label = str(row[0]).strip()
                if label and len(label) > 1:
                    try:
                        float(label)
                        continue
                    except ValueError:
                        pass
                    fields.add(label)
    return fields


# ─────────────────────────────────────────────
#  导出为可读表格（Markdown）
# ─────────────────────────────────────────────

SOURCE_LABELS = {
    "ai_generated": "AI自动生成",
    "user_provided": "用户提供",
    "user_corrected": "用户修正",
}


def export_rules_markdown(db: dict, sig_id: str) -> str:
    """将规则库导出为Markdown表格，供AI展示给用户"""
    sig = get_signature(db, sig_id)
    if not sig:
        return f"❌ 未找到报签 {sig_id}"

    rules = list_rules(db, sig_id)
    if not rules:
        return f"📋 报签「{sig['name']}」（{sig_id}）暂无规则。"

    lines = [
        f"## 📋 报签：{sig['name']}",
        f"- **类型**：{sig['report_type']}",
        f"- **描述**：{sig.get('description', '—')}",
        f"- **报签ID**：`{sig_id}`",
        f"- **规则数量**：{len(rules)}",
        "",
        "| # | 输出字段 | 来源字段/表达式 | 取数逻辑 | 计算公式 | 规则来源 | 备注 |",
        "|---|----------|----------------|---------|---------|---------|------|",
    ]
    for i, r in enumerate(rules, 1):
        source_label = SOURCE_LABELS.get(r["source"], r["source"])
        active_mark = "" if r.get("active", True) else "~~"
        row = (
            f"| {i} "
            f"| {active_mark}{r['output_field']}{active_mark} "
            f"| {r['source_field']} "
            f"| {r['logic']} "
            f"| {r.get('formula', '—')} "
            f"| {source_label} "
            f"| {r.get('notes', '—')} |"
        )
        lines.append(row)

    lines += [
        "",
        f"> 最后更新：{sig['updated_at']}",
    ]
    return "\n".join(lines)


# ─────────────────────────────────────────────
#  CLI 入口
# ─────────────────────────────────────────────

def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(0)

    db = _load_db()
    cmd = args[0]

    if cmd == "list-sigs":
        sigs = list_signatures(db)
        if not sigs:
            print("（规则库为空，尚无报签）")
        else:
            print(f"{'报签ID':<10} {'报表名称':<20} {'类型':<16} {'规则数':<6} {'更新时间'}")
            print("-" * 70)
            for s in sigs:
                rule_count = len(list_rules(db, s["sig_id"]))
                print(f"{s['sig_id']:<10} {s['name']:<20} {s['report_type']:<16} {rule_count:<6} {s['updated_at']}")

    elif cmd == "show-sig" and len(args) >= 2:
        sig_id = args[1]
        print(export_rules_markdown(db, sig_id))

    elif cmd == "add-sig" and len(args) >= 3:
        name = args[1]
        rtype = args[2]
        desc = args[3] if len(args) > 3 else ""
        sig = add_signature(db, name, rtype, desc)
        print(f"✅ 报签已创建：{sig['sig_id']} | {sig['name']}")

    elif cmd == "list-rules" and len(args) >= 2:
        sig_id = args[1]
        print(export_rules_markdown(db, sig_id))

    elif cmd == "add-rule" and len(args) >= 2:
        sig_id = args[1]
        data = json.loads(sys.stdin.read())
        rule = add_rule(db, sig_id, data)
        print(f"✅ 规则已添加：{rule['rule_id']} -> {rule['output_field']}")

    elif cmd == "update-rule" and len(args) >= 2:
        rule_id = args[1]
        data = json.loads(sys.stdin.read())
        rule = update_rule(db, rule_id, data)
        if rule:
            print(f"✅ 规则已更新：{rule['rule_id']}")
        else:
            print(f"❌ 未找到规则 {rule_id}")

    elif cmd == "delete-rule" and len(args) >= 2:
        rule_id = args[1]
        ok = delete_rule(db, rule_id)
        print("✅ 规则已删除" if ok else f"❌ 未找到规则 {rule_id}")

    elif cmd == "export-rules" and len(args) >= 2:
        sig_id = args[1]
        print(export_rules_markdown(db, sig_id))

    elif cmd == "import-rules" and len(args) >= 3:
        sig_id = args[1]
        fpath = args[2]
        with open(fpath, "r", encoding="utf-8") as f:
            rules_list = json.load(f)
        added = bulk_add_rules(db, sig_id, rules_list)
        print(f"✅ 批量导入完成，共导入 {len(added)} 条规则")

    elif cmd == "check-coverage" and len(args) >= 3:
        sig_id = args[1]
        template_file = args[2]
        # 读取规则库中的 output_field
        rules = list_rules(db, sig_id)
        covered = set()
        for r in rules:
            of = r.get("output_field", "").strip()
            if of and r.get("active", True):
                covered.add(of)
        # 读取模板需填字段
        template_fields = _extract_template_fields(template_file)
        if not template_fields:
            print("⚠️ 未能从模板中提取到需填字段。")
            sys.exit(0)
        uncovered = template_fields - covered
        coverage_rate = round(len(covered & template_fields) / len(template_fields) * 100, 1) if template_fields else 0
        print(f"\n📊 规则覆盖率校验 — 报签ID：{sig_id}")
        print(f"  模板需填字段：{len(template_fields)} 个")
        print(f"  规则已覆盖：{len(covered & template_fields)} 个")
        print(f"  覆盖率：{coverage_rate}%")
        if uncovered:
            print(f"  ⚠️ 未覆盖字段（{len(uncovered)} 个）：")
            for f in sorted(uncovered)[:20]:
                print(f"    - {f}")
        else:
            print("  ✅ 所有模板字段均已覆盖，可以执行填报。")

    else:
        print(f"未知命令或参数不足：{' '.join(args)}")
        print("运行 `python rule_store.py` 查看帮助")
        sys.exit(1)


if __name__ == "__main__":
    main()
