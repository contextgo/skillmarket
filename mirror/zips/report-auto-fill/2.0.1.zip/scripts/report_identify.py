#!/usr/bin/env python3
"""
report_identify.py - 报表识别与报签生成辅助脚本

功能：
1. 读取 Excel / CSV / PDF（文本层）文件，提取字段名列表
2. 根据字段特征输出报表类型判断依据（供AI进一步推理）
3. 与规则库交互：自动匹配已有报签 / 生成新报签

使用方式：
    python report_identify.py extract-fields <file_path>
    python report_identify.py match-sig <file_path>
    python report_identify.py create-sig <name> <type> <fields_json>

依赖（自动在运行时检查并提示安装）：
    openpyxl, pandas, pdfminer.six（PDF文本提取，可选）
"""

import sys
import json
import os
from pathlib import Path

# ─────────────────────────────────────────────
#  依赖检查
# ─────────────────────────────────────────────

def _check_dep(pkg):
    import importlib
    try:
        importlib.import_module(pkg)
        return True
    except ImportError:
        return False


def _require(pkg, install_name=None):
    if not _check_dep(pkg):
        name = install_name or pkg
        print(f"[提示] 缺少依赖 {pkg}，请先运行：pip install {name}", file=sys.stderr)
        sys.exit(1)


# ─────────────────────────────────────────────
#  字段提取
# ─────────────────────────────────────────────

def extract_fields_excel(file_path: str, sheet_index: int = 0) -> dict:
    """提取Excel文件的字段及样本数据"""
    _require("openpyxl")
    _require("pandas")
    import pandas as pd

    path = Path(file_path)
    if not path.exists():
        return {"error": f"文件不存在：{file_path}"}

    try:
        xl = pd.ExcelFile(file_path)
        sheet_names = xl.sheet_names
        results = {}
        for sheet in sheet_names:
            df = pd.read_excel(file_path, sheet_name=sheet, header=None, nrows=20)
            # 尝试找到标题行（第一行含非空字符串最多的行）
            header_row = 0
            max_str_count = 0
            for i, row in df.iterrows():
                str_count = sum(1 for v in row if isinstance(v, str) and v.strip())
                if str_count > max_str_count:
                    max_str_count = str_count
                    header_row = i

            df2 = pd.read_excel(file_path, sheet_name=sheet, header=header_row)
            fields = [str(c).strip() for c in df2.columns if str(c).strip() and not str(c).startswith("Unnamed")]
            # 取前3行样本
            sample_rows = df2.head(3).to_dict(orient="records")
            results[sheet] = {
                "fields": fields,
                "sample_rows": sample_rows,
                "row_count": len(df2),
            }
        return {
            "file": str(path.name),
            "type": "excel",
            "sheets": results,
        }
    except Exception as e:
        return {"error": str(e)}


def extract_fields_csv(file_path: str) -> dict:
    """提取CSV文件的字段"""
    _require("pandas")
    import pandas as pd

    try:
        df = pd.read_csv(file_path, encoding="utf-8-sig")
        fields = list(df.columns)
        sample_rows = df.head(3).to_dict(orient="records")
        return {
            "file": Path(file_path).name,
            "type": "csv",
            "fields": fields,
            "sample_rows": sample_rows,
            "row_count": len(df),
        }
    except Exception as e:
        return {"error": str(e)}


def extract_text_pdf(file_path: str, max_pages: int = 5) -> dict:
    """提取PDF文本内容（前N页）"""
    try:
        from pdfminer.high_level import extract_text
        text = extract_text(file_path, maxpages=max_pages)
        # 提取每行非空内容
        lines = [l.strip() for l in text.split("\n") if l.strip()]
        return {
            "file": Path(file_path).name,
            "type": "pdf",
            "text_lines": lines[:100],  # 最多100行
            "total_lines": len(lines),
        }
    except ImportError:
        return {"error": "pdfminer.six 未安装，请运行：pip install pdfminer.six"}
    except Exception as e:
        return {"error": str(e)}


def extract_fields(file_path: str) -> dict:
    """根据文件扩展名自动选择提取方式"""
    ext = Path(file_path).suffix.lower()
    if ext in (".xlsx", ".xls", ".xlsm"):
        return extract_fields_excel(file_path)
    elif ext == ".csv":
        return extract_fields_csv(file_path)
    elif ext == ".pdf":
        return extract_text_pdf(file_path)
    else:
        return {"error": f"不支持的文件格式：{ext}（支持 xlsx/xls/csv/pdf）"}


# ─────────────────────────────────────────────
#  报签匹配
# ─────────────────────────────────────────────

def match_signature(db: dict, field_list: list) -> list:
    """
    用字段列表与已有报签的 key_fields 进行模糊匹配
    返回匹配分数最高的报签列表（按分数降序）
    """
    results = []
    field_set = {f.lower() for f in field_list}
    for sig in db.get("signatures", {}).values():
        key_fields = [k.lower() for k in sig.get("key_fields", [])]
        if not key_fields:
            continue
        matched = sum(1 for kf in key_fields if any(kf in ff or ff in kf for ff in field_set))
        score = matched / len(key_fields) if key_fields else 0
        if score > 0:
            results.append({"sig": sig, "score": round(score, 3), "matched": matched})
    results.sort(key=lambda x: x["score"], reverse=True)
    return results


# ─────────────────────────────────────────────
#  CLI 入口
# ─────────────────────────────────────────────

def _load_db():
    store_file = Path.home() / ".workbuddy" / "report_rules" / "rules_db.json"
    if store_file.exists():
        with open(store_file, "r", encoding="utf-8") as f:
            return json.load(f)
    return {"signatures": {}, "rules": {}}


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__)
        sys.exit(0)

    cmd = args[0]

    if cmd == "extract-fields" and len(args) >= 2:
        result = extract_fields(args[1])
        print(json.dumps(result, ensure_ascii=False, indent=2))

    elif cmd == "match-sig" and len(args) >= 2:
        result = extract_fields(args[1])
        # 收集所有字段
        fields = []
        if "sheets" in result:
            for sheet_data in result["sheets"].values():
                fields.extend(sheet_data.get("fields", []))
        elif "fields" in result:
            fields = result["fields"]
        elif "text_lines" in result:
            fields = result["text_lines"][:30]

        db = _load_db()
        matches = match_signature(db, fields)
        if matches:
            print("🔍 匹配到以下报签（按相似度排序）：")
            for m in matches[:5]:
                s = m["sig"]
                print(f"  [{m['score']*100:.0f}%] {s['sig_id']} | {s['name']} | {s['report_type']}")
        else:
            print("⚠️ 未找到匹配的报签，建议新建报签。")
        print("\n📄 文件字段预览：", fields[:20])

    elif cmd == "create-sig" and len(args) >= 3:
        # 从命令行快速创建报签（供AI调用）
        import rule_store as rs
        name = args[1]
        rtype = args[2]
        key_fields = json.loads(args[3]) if len(args) > 3 else []
        desc = args[4] if len(args) > 4 else ""
        db = _load_db()
        sig = rs.add_signature(db, name, rtype, desc, key_fields)
        print(json.dumps(sig, ensure_ascii=False, indent=2))

    else:
        print(f"未知命令：{' '.join(args)}")
        print("运行 `python report_identify.py` 查看帮助")
        sys.exit(1)


if __name__ == "__main__":
    main()
