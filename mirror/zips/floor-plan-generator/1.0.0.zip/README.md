# 户型图自动生成器

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.8+-green)
![License](https://img.shields.io/badge/license-MIT-orange)

一个高效的CAD户型图自动生成工具，可以根据房间尺寸参数自动生成专业的户型图CAD文件。

## 功能特性

- **智能布局**: 根据房间尺寸自动计算最优布局
- **标准化分层**: 符合CAD规范的图层管理
- **自动标注**: 尺寸、名称、面积自动标注
- **多格式支持**: DWG、DXF格式导出
- **易于定制**: 支持JSON配置和Python API

## 快速开始

### AI助手使用

直接告诉AI助手您的需求：

```
生成一个两室一厅户型图
客厅：6000×4500
主卧：4500×3600
次卧：3600×3300
厨房：3000×2400
卫生间：2400×1800
```

AI助手会自动生成CAD文件并保存到桌面。

## 使用方法

### 方法一：命令行使用

```bash
# 使用默认配置
python "C:\Users\胡华婷\.codebuddy\skills\floor-plan-generator\scripts\generate.py"

# 使用配置文件
python "C:\Users\胡华婷\.codebuddy\skills\floor-plan-generator\scripts\generate.py" --config config.json

# 交互式输入
python "C:\Users\胡华婷\.codebuddy\skills\floor-plan-generator\scripts\generate.py" --interactive
```

### 方法二：Python API

```python
from generate import FloorPlanGenerator, FloorPlanConfig

# 创建配置
config = FloorPlanConfig()
config.rooms = [
    {"name": "客厅", "width": 6000, "height": 4500},
    {"name": "主卧", "width": 4500, "height": 3600},
    {"name": "次卧", "width": 3600, "height": 3300},
    {"name": "厨房", "width": 3000, "height": 2400},
    {"name": "卫生间", "width": 2400, "height": 1800},
]
config.output_filename = "我的户型图"

# 生成
generator = FloorPlanGenerator(config)
output_path = generator.generate()
```

## 图层结构

| 图层名称 | 功能 | 颜色 |
|----------|------|------|
| WALLS | 外墙轮廓 | 白色 |
| INNER_WALLS | 内墙隔断 | 白色 |
| DOORS | 门 | 绿色 |
| WINDOWS | 窗户 | 蓝色 |
| DIMENSIONS | 尺寸标注 | 红色 |
| ROOM_NAMES | 房间名称 | 绿色 |
| TEXT | 文字标注 | 白色 |

## 参数说明

### 房间配置

```json
{
  "name": "客厅",
  "width": 6000,
  "height": 4500
}
```

| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| name | String | 是 | 房间名称（支持中文） |
| width | Integer | 是 | 房间宽度(mm) |
| height | Integer | 是 | 房间高度(mm) |

### 全局配置

| 参数 | 默认值 | 说明 |
|------|--------|------|
| wall_thickness | 240 | 墙厚(mm) |
| door_width | 900 | 门宽(mm) |
| bathroom_door_width | 700 | 卫生间门宽(mm) |
| window_width | 1200 | 窗户宽(mm) |
| output_filename | 户型图 | 输出文件名 |
| output_dir | 桌面 | 输出目录 |

## 常见户型示例

### 一室一厅 (~50m²)

```json
{
  "rooms": [
    {"name": "客厅", "width": 4500, "height": 4000},
    {"name": "卧室", "width": 4000, "height": 3500},
    {"name": "厨房", "width": 2500, "height": 2000},
    {"name": "卫生间", "width": 2000, "height": 1800}
  ]
}
```

### 两室一厅 (~75m²)

```json
{
  "rooms": [
    {"name": "客厅", "width": 6000, "height": 4500},
    {"name": "主卧", "width": 4500, "height": 3600},
    {"name": "次卧", "width": 3600, "height": 3300},
    {"name": "厨房", "width": 3000, "height": 2400},
    {"name": "卫生间", "width": 2400, "height": 1800}
  ]
}
```

### 三室两厅 (~100m²)

```json
{
  "rooms": [
    {"name": "客厅", "width": 6000, "height": 4500},
    {"name": "餐厅", "width": 3600, "height": 3000},
    {"name": "主卧", "width": 4500, "height": 3600},
    {"name": "次卧1", "width": 3600, "height": 3300},
    {"name": "次卧2", "width": 3300, "height": 3000},
    {"name": "厨房", "width": 3000, "height": 2400},
    {"name": "卫生间", "width": 2400, "height": 1800}
  ]
}
```

## 输出文件

### 文件格式
- **DWG**: AutoCAD R2018格式 (主要格式)
- **DXF**: 通用CAD交换格式 (可通过CAD软件转换)

### 文件位置
默认保存到桌面：`C:\Users\胡华婷\Desktop\`

### 打开方式
- **AutoCAD** - 完整功能支持
- **QCAD** - 免费开源CAD软件
- **DraftSight** - 免费DWG查看器
- **LibreCAD** - 免费开源CAD软件
- **Autodesk TrueView** - 在线查看器

## 技术规格

- **编程语言**: Python 3.8+
- **依赖库**: ezdxf (自动安装)
- **文件格式**: DWG R2018 / DXF
- **单位系统**: 毫米 (mm)
- **比例**: 1:100

## 安装依赖

首次使用会自动安装依赖，如需手动安装：

```bash
pip install ezdxf
```

## 文件结构

```
floor-plan-generator/
├── SKILL.md                    # 技能描述
├── README.md                   # 本文件
├── scripts/
│   └── generate.py            # 核心生成脚本
├── references/
│   └── usage_guide.md         # 详细使用指南
└── templates/
    └── default_config.json    # 默认配置模板
```

## 更新日志

### v1.0.0 (2026-04-10)
- 初始版本发布
- 支持基础户型生成
- 自动分层和标注
- 多格式导出支持

## 许可协议

MIT License

## 联系方式

如有问题或建议，请联系AI助手。
