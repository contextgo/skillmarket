"""
户型图自动生成器 - 核心脚本
根据房间尺寸参数自动生成CAD户型图文件

使用方法:
1. 命令行: python generate.py --config config.json
2. 交互式: python generate.py --interactive
3. Python API: from generate import FloorPlanGenerator, FloorPlanConfig
"""

import ezdxf
from ezdxf.enums import TextEntityAlignment
import os
import sys
import json
import argparse
from typing import Dict, List, Optional


class FloorPlanConfig:
    """户型图配置类"""
    
    def __init__(self):
        # 默认两室一厅配置
        self.rooms: List[Dict] = [
            {"name": "客厅", "width": 6000, "height": 4500},
            {"name": "主卧", "width": 4500, "height": 3600},
            {"name": "次卧", "width": 3600, "height": 3300},
            {"name": "厨房", "width": 3000, "height": 2400},
            {"name": "卫生间", "width": 2400, "height": 1800},
        ]
        self.wall_thickness = 240
        self.door_width = 900
        self.bathroom_door_width = 700
        self.window_width = 1200
        self.output_filename = "户型图"
        self.output_dir = os.path.expanduser("~\\Desktop")
    
    @classmethod
    def from_json(cls, json_path: str) -> 'FloorPlanConfig':
        """从JSON文件加载配置"""
        with open(json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        config = cls()
        if 'rooms' in data:
            config.rooms = data['rooms']
        if 'wall_thickness' in data:
            config.wall_thickness = data['wall_thickness']
        if 'door_width' in data:
            config.door_width = data['door_width']
        if 'bathroom_door_width' in data:
            config.bathroom_door_width = data['bathroom_door_width']
        if 'window_width' in data:
            config.window_width = data['window_width']
        if 'output_filename' in data:
            config.output_filename = data['output_filename']
        if 'output_dir' in data:
            config.output_dir = data['output_dir']
        
        return config
    
    def to_json(self, json_path: str):
        """保存配置到JSON文件"""
        data = {
            'rooms': self.rooms,
            'wall_thickness': self.wall_thickness,
            'door_width': self.door_width,
            'bathroom_door_width': self.bathroom_door_width,
            'window_width': self.window_width,
            'output_filename': self.output_filename,
            'output_dir': self.output_dir
        }
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)


class FloorPlanGenerator:
    """户型图生成器"""
    
    def __init__(self, config: FloorPlanConfig):
        self.config = config
        self.doc = ezdxf.new("R2018", setup=True)
        self.doc.header["$INSUNITS"] = 4  # Millimeters
        self.msp = self.doc.modelspace()
        self.layout = {}
        
        # 创建图层
        self._setup_layers()
    
    def _setup_layers(self):
        """创建标准图层"""
        # 删除默认图层
        if "0" in self.doc.layers:
            try:
                self.doc.layers.remove("0")
            except:
                pass
        
        # 定义图层
        layer_defs = [
            ("WALLS", 7, "continuous", 50),
            ("INNER_WALLS", 7, "continuous", 35),
            ("DOORS", 3, "continuous", 25),
            ("WINDOWS", 5, "continuous", 25),
            ("DIMENSIONS", 1, "continuous", 20),
            ("ROOM_NAMES", 3, "continuous", 50),
            ("TEXT", 7, "continuous", 30),
        ]
        
        for name, color, linetype, lineweight in layer_defs:
            self.doc.layers.add(name)
            layer = self.doc.layers.get(name)
            layer.color = color
            layer.linetype = linetype
            layer.lineweight = lineweight
    
    def _design_layout(self) -> Dict:
        """设计户型布局"""
        wall = self.config.wall_thickness
        rooms = self.config.rooms
        
        if len(rooms) == 2:
            # 一室一厅
            layout = self._layout_1br(rooms, wall)
        elif len(rooms) == 3:
            # 两室一厅
            layout = self._layout_2br(rooms, wall)
        elif len(rooms) == 4:
            # 三室一厅
            layout = self._layout_3br(rooms, wall)
        elif len(rooms) == 5:
            # 三室两厅
            layout = self._layout_3br2l(rooms, wall)
        else:
            # 默认布局
            layout = self._layout_default(rooms, wall)
        
        return layout
    
    def _layout_1br(self, rooms, wall) -> Dict:
        """一室一厅布局"""
        layout = {}
        living = rooms[0] if "客厅" in rooms[0]["name"] else rooms[1]
        bedroom = rooms[0] if "卧" in rooms[0]["name"] else rooms[1]
        
        x, y = wall, wall
        layout["living_room"] = {"x": x, "y": y, **living}
        layout["bedroom"] = {"x": x, "y": y + living["height"], **bedroom}
        
        return layout
    
    def _layout_2br(self, rooms, wall) -> Dict:
        """两室一厅布局"""
        layout = {}
        # 假设: 客厅、厨房、两个卧室
        living = next((r for r in rooms if "客厅" in r["name"]), rooms[0])
        master = next((r for r in rooms if "主卧" in r["name"]), rooms[1])
        second = next((r for r in rooms if "次卧" in r["name"]), None)
        kitchen = next((r for r in rooms if "厨房" in r["name"]), None)
        bathroom = next((r for r in rooms if "卫生" in r["name"]), None)
        
        x, y = wall, wall
        # 客厅在左下
        layout["living_room"] = {"x": x, "y": y, **living}
        
        # 主卧在客厅上方
        layout["master_bedroom"] = {
            "x": x + living["width"],
            "y": y + living["height"] - master["height"],
            **master
        }
        
        # 次卧在客厅右侧
        if second:
            layout["second_bedroom"] = {
                "x": x,
                "y": y + living["height"],
                **second
            }
        
        # 厨房
        if kitchen:
            layout["kitchen"] = {
                "x": x + second["width"] if second else x,
                "y": y - kitchen["height"],
                **kitchen
            }
        
        # 卫生间
        if bathroom:
            layout["bathroom"] = {
                "x": x + living["width"],
                "y": y - bathroom["height"],
                **bathroom
            }
        
        return layout
    
    def _layout_3br(self, rooms, wall) -> Dict:
        """三室一厅布局"""
        return self._layout_2br(rooms, wall)
    
    def _layout_3br2l(self, rooms, wall) -> Dict:
        """三室两厅布局"""
        layout = {}
        rooms_copy = rooms.copy()
        
        # 找出所有房间类型
        living = next((r for r in rooms_copy if "客厅" in r["name"]), {"name": "客厅", "width": 6000, "height": 4500})
        dining = next((r for r in rooms_copy if "餐厅" in r["name"]), {"name": "餐厅", "width": 3000, "height": 3000})
        master = next((r for r in rooms_copy if "主卧" in r["name"]), {"name": "主卧", "width": 4500, "height": 3600})
        second = next((r for r in rooms_copy if "次卧" in r["name"] and "主" not in r["name"]), {"name": "次卧", "width": 3600, "height": 3300})
        kitchen = next((r for r in rooms_copy if "厨房" in r["name"]), {"name": "厨房", "width": 3000, "height": 2400})
        bathroom = next((r for r in rooms_copy if "卫生" in r["name"]), {"name": "卫生间", "width": 2400, "height": 1800})
        
        x, y = wall, wall
        
        # 客厅
        layout["living_room"] = {"x": x, "y": y, **living}
        
        # 餐厅在客厅上方
        layout["dining_room"] = {
            "x": x,
            "y": y + living["height"],
            **dining
        }
        
        # 主卧
        layout["master_bedroom"] = {
            "x": x + living["width"],
            "y": y + dining["height"] - master["height"],
            **master
        }
        
        # 次卧
        layout["second_bedroom"] = {
            "x": x + living["width"],
            "y": y,
            **second
        }
        
        # 厨房
        layout["kitchen"] = {
            "x": x - kitchen["width"],
            "y": y,
            **kitchen
        }
        
        # 卫生间
        layout["bathroom"] = {
            "x": x - bathroom["width"],
            "y": y + kitchen["height"],
            **bathroom
        }
        
        return layout
    
    def _layout_default(self, rooms, wall) -> Dict:
        """默认布局 - 根据房间数量智能分配"""
        layout = {}
        x, y = wall, wall
        
        # 客厅优先
        living = next((r for r in rooms if "客厅" in r["name"] or "起居" in r["name"]), rooms[0])
        layout["room_0"] = {"x": x, "y": y, **living}
        
        # 依次排列其他房间
        for i, room in enumerate(rooms[1:], 1):
            prev_room = rooms[i-1]
            layout[f"room_{i}"] = {
                "x": x + prev_room["width"],
                "y": y,
                **room
            }
        
        return layout
    
    def draw_outer_walls(self):
        """绘制外墙"""
        wall = self.config.wall_thickness
        
        all_rooms = list(self.layout.values())
        min_x = min(r["x"] for r in all_rooms) - wall
        min_y = min(r["y"] for r in all_rooms) - wall
        max_x = max(r["x"] + r["width"] for r in all_rooms) + wall
        max_y = max(r["y"] + r["height"] for r in all_rooms) + wall
        
        # 绘制外墙轮廓
        self.msp.add_lwpolyline(
            [(min_x, min_y), (max_x, min_y), (max_x, max_y), (min_x, max_y), (min_x, min_y)],
            close=True,
            dxfattribs={"layer": "WALLS"}
        )
        
        # 内边
        self.msp.add_lwpolyline(
            [(min_x + wall, min_y + wall), 
             (max_x - wall, min_y + wall), 
             (max_x - wall, max_y - wall), 
             (min_x + wall, max_y - wall),
             (min_x + wall, min_y + wall)],
            close=True,
            dxfattribs={"layer": "WALLS"}
        )
    
    def draw_inner_walls(self):
        """绘制内墙"""
        wall = self.config.wall_thickness
        
        for name, room in self.layout.items():
            # 为每个房间绘制分隔墙
            x, y = room["x"], room["y"]
            w, h = room["width"], room["height"]
            
            # 上边
            self.msp.add_lwpolyline(
                [(x, y + h - wall), (x + w, y + h - wall)],
                dxfattribs={"layer": "INNER_WALLS"}
            )
            # 右边
            self.msp.add_lwpolyline(
                [(x + w - wall, y), (x + w - wall, y + h)],
                dxfattribs={"layer": "INNER_WALLS"}
            )
    
    def draw_doors(self):
        """绘制门"""
        wall = self.config.wall_thickness
        door_width = self.config.door_width
        half_wall = wall / 2
        
        for name, room in self.layout.items():
            center_x = room["x"] + room["width"] / 2
            center_y = room["y"] + room["height"] / 2
            
            # 绘制门扇 (简单的圆弧表示)
            if door_width <= room["width"]:
                # 水平门
                self.msp.add_arc(
                    center=(center_x, room["y"]),
                    radius=door_width / 2,
                    start_angle=90,
                    end_angle=180,
                    dxfattribs={"layer": "DOORS"}
                )
            if door_width <= room["height"]:
                # 垂直门
                self.msp.add_arc(
                    center=(room["x"] + room["width"], center_y),
                    radius=door_width / 2,
                    start_angle=0,
                    end_angle=90,
                    dxfattribs={"layer": "DOORS"}
                )
    
    def draw_windows(self):
        """绘制窗户"""
        wall = self.config.wall_thickness
        window_width = self.config.window_width
        half_wall = wall / 2
        
        for name, room in self.layout.items():
            center_x = room["x"] + room["width"] / 2
            center_y = room["y"] + room["height"] / 2
            
            # 窗户中线
            if window_width <= room["width"]:
                # 水平窗户
                win_x = center_x - window_width / 2
                self.msp.add_line(
                    (win_x, room["y"] + room["height"] - half_wall),
                    (win_x + window_width, room["y"] + room["height"] - half_wall),
                    dxfattribs={"layer": "WINDOWS"}
                )
            if window_width <= room["height"]:
                # 垂直窗户
                win_y = center_y - window_width / 2
                self.msp.add_line(
                    (room["x"] - half_wall, win_y),
                    (room["x"] - half_wall, win_y + window_width),
                    dxfattribs={"layer": "WINDOWS"}
                )
    
    def add_dimensions(self):
        """添加尺寸标注"""
        wall = self.config.wall_thickness
        offset = 800
        
        all_rooms = list(self.layout.values())
        min_x = min(r["x"] for r in all_rooms) - wall
        min_y = min(r["y"] for r in all_rooms) - wall
        max_x = max(r["x"] + r["width"] for r in all_rooms) + wall
        max_y = max(r["y"] + r["height"] for r in all_rooms) + wall
        
        # 总尺寸
        self.msp.add_text(
            f"{max_x - min_x}",
            dxfattribs={"layer": "DIMENSIONS", "height": 250, "style": "Standard"}
        ).set_placement((max_x / 2, min_y - offset + 100), align=TextEntityAlignment.MIDDLE_CENTER)
        
        self.msp.add_text(
            f"{max_y - min_y}",
            dxfattribs={"layer": "DIMENSIONS", "height": 250, "style": "Standard"}
        ).set_placement((min_x - offset + 100, max_y / 2), align=TextEntityAlignment.MIDDLE_CENTER)
        
        # 尺寸线
        self.msp.add_line((min_x, min_y - offset), (max_x, min_y - offset), dxfattribs={"layer": "DIMENSIONS"})
        self.msp.add_line((min_x - offset, min_y), (min_x - offset, max_y), dxfattribs={"layer": "DIMENSIONS"})
    
    def add_room_labels(self):
        """添加房间标签"""
        for name, room in self.layout.items():
            center_x = room["x"] + room["width"] / 2
            center_y = room["y"] + room["height"] / 2
            
            # 房间名称
            self.msp.add_text(
                room["name"],
                dxfattribs={"layer": "ROOM_NAMES", "height": 400, "style": "Standard"}
            ).set_placement((center_x, center_y), align=TextEntityAlignment.MIDDLE_CENTER)
            
            # 面积
            area = (room["width"] * room["height"]) / 1000000
            self.msp.add_text(
                f"{area:.1f}m2",
                dxfattribs={"layer": "TEXT", "height": 250, "style": "Standard"}
            ).set_placement((center_x, center_y - 500), align=TextEntityAlignment.MIDDLE_CENTER)
    
    def add_title(self):
        """添加标题"""
        all_rooms = list(self.layout.values())
        max_x = max(r["x"] + r["width"] for r in all_rooms)
        max_y = max(r["y"] + r["height"] for r in all_rooms)
        
        total_area = sum(r["width"] * r["height"] for r in all_rooms) / 1000000
        
        self.msp.add_text(
            f"{len(self.config.rooms)}室户型图",
            dxfattribs={"layer": "ROOM_NAMES", "height": 600, "style": "Standard"}
        ).set_placement((max_x / 2, max_y + 1500), align=TextEntityAlignment.MIDDLE_CENTER)
        
        self.msp.add_text(
            f"总面积: {total_area:.1f}m2 | 1:100",
            dxfattribs={"layer": "TEXT", "height": 300, "style": "Standard"}
        ).set_placement((max_x / 2, max_y + 1000), align=TextEntityAlignment.MIDDLE_CENTER)
    
    def generate(self) -> str:
        """生成CAD文件"""
        print("[*] 开始生成户型图...")
        
        # 设计布局
        self.layout = self._design_layout()
        
        # 绘制各部分
        print("    - 绘制外墙...")
        self.draw_outer_walls()
        
        print("    - 绘制内墙...")
        self.draw_inner_walls()
        
        print("    - 绘制门...")
        self.draw_doors()
        
        print("    - 绘制窗户...")
        self.draw_windows()
        
        print("    - 添加标注...")
        self.add_dimensions()
        
        print("    - 添加房间标签...")
        self.add_room_labels()
        
        print("    - 添加标题...")
        self.add_title()
        
        # 保存文件
        output_path = os.path.join(self.config.output_dir, f"{self.config.output_filename}.dwg")
        print(f"    - 保存文件: {output_path}")
        self.doc.saveas(output_path)
        
        print(f"[OK] 户型图已生成: {output_path}")
        
        # 统计
        total_area = sum(r["width"] * r["height"] for r in self.layout.values()) / 1000000
        print(f"\n[*] 户型统计:")
        print(f"    总面积: {total_area:.1f} m2")
        print(f"    房间数量: {len(self.layout)}")
        for name, room in self.layout.items():
            area = room["width"] * room["height"] / 1000000
            print(f"    - {room['name']}: {room['width']}x{room['height']} ({area:.1f}m2)")
        
        return output_path


def interactive_mode():
    """交互式输入模式"""
    print("\n" + "=" * 60)
    print("户型图生成器 - 交互式模式")
    print("=" * 60)
    
    config = FloorPlanConfig()
    
    # 输入房间数量
    while True:
        try:
            num_rooms = int(input("\n请输入房间数量 (2-6): "))
            if 2 <= num_rooms <= 6:
                break
            print("请输入2-6之间的数字")
        except ValueError:
            print("请输入有效的数字")
    
    config.rooms = []
    room_types = ["客厅", "主卧", "次卧", "厨房", "卫生间", "餐厅", "书房", "阳台"]
    
    for i in range(num_rooms):
        print(f"\n--- 房间 {i+1} ---")
        name = input(f"房间名称 ({', '.join(room_types[:num_rooms])}): ").strip()
        if not name:
            name = room_types[i] if i < len(room_types) else f"房间{i+1}"
        
        while True:
            try:
                width = int(input("宽度 (mm): "))
                height = int(input("高度 (mm): "))
                if width > 0 and height > 0:
                    break
                print("请输入正数")
            except ValueError:
                print("请输入有效的数字")
        
        config.rooms.append({"name": name, "width": width, "height": height})
    
    # 其他参数
    print("\n--- 其他参数 (直接回车使用默认值) ---")
    
    wall = input(f"墙厚 (mm) [默认240]: ").strip()
    if wall:
        config.wall_thickness = int(wall)
    
    door = input(f"门宽 (mm) [默认900]: ").strip()
    if door:
        config.door_width = int(door)
    
    window = input(f"窗宽 (mm) [默认1200]: ").strip()
    if window:
        config.window_width = int(window)
    
    filename = input(f"输出文件名 [默认户型图]: ").strip()
    if filename:
        config.output_filename = filename
    
    # 生成
    generator = FloorPlanGenerator(config)
    output_path = generator.generate()
    
    print(f"\n[DONE] 文件已保存: {output_path}")
    return output_path


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description="户型图自动生成器")
    parser.add_argument("--config", "-c", help="配置文件路径 (JSON)")
    parser.add_argument("--interactive", "-i", action="store_true", help="交互式输入模式")
    parser.add_argument("--output", "-o", help="输出文件路径")
    
    args = parser.parse_args()
    
    if args.interactive:
        interactive_mode()
    elif args.config:
        # 从配置文件加载
        config = FloorPlanConfig.from_json(args.config)
        if args.output:
            config.output_filename = args.output.replace(".dwg", "")
        generator = FloorPlanGenerator(config)
        generator.generate()
    else:
        # 使用默认配置
        print("[*] 使用默认配置生成户型图...")
        config = FloorPlanConfig()
        generator = FloorPlanGenerator(config)
        generator.generate()


if __name__ == "__main__":
    main()
