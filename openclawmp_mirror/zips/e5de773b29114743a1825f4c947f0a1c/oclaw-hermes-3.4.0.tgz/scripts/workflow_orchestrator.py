#!/usr/bin/env python3
"""
超能力工作流编排器 v3.4
Super Capability Workflow Orchestrator

解构并整合市面上三种主流智能体架构的核心能力：
1. **Hermes 架构** - 自进化记忆 + 技能蒸馏
2. **DeerFlow 架构** - LangGraph编排 + 深度研究链
3. **OpenAI Swarm 架构** - 轻量级多智能体 + 函数调用

形成统一的超能力工作流系统。

作者: dlh365
版本: 3.4.0
"""

import asyncio
import json
import hashlib
from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys
sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from mflow_v2 import MFlowEngineV2, MemoryEntry
from narrative_enhancer import NormanMailerEnhancer

class WorkflowType(Enum):
    """工作流类型"""
    # Hermes 风格工作流
    MEMORY_EVOLUTION = "memory_evolution"      # 记忆进化
    SKILL_DISTILLATION = "skill_distillation"  # 技能蒸馏
    EXPERT_CLONING = "expert_cloning"          # 专家克隆
    
    # DeerFlow 风格工作流
    DEEP_RESEARCH = "deep_research"            # 深度研究
    CODE_EXECUTION = "code_execution"          # 代码执行
    MULTI_AGENT_CHAIN = "multi_agent_chain"    # 多智能体链
    
    # Swarm 风格工作流
    LIGHTWEIGHT_SWARM = "lightweight_swarm"    # 轻量级群体
    FUNCTION_ROUTING = "function_routing"      # 函数路由
    CONTEXT_HANDOFF = "context_handoff"        # 上下文交接
    
    # 超能力组合工作流
    HYPER_RESEARCH = "hyper_research"          # 超研究（DeerFlow研究+Hermes记忆）
    HYPER_CREATION = "hyper_creation"          # 超创造（Swarm协作+技能蒸馏）
    HYPER_EVOLUTION = "hyper_evolution"        # 超进化（记忆进化+专家克隆）

@dataclass
class WorkflowStep:
    """工作流步骤"""
    step_id: str
    name: str
    capability_module: str      # 能力模块名称
    inputs: Dict[str, Any]
    outputs: List[str]
    dependencies: List[str] = field(default_factory=list)
    timeout: float = 60.0
    retry_count: int = 3
    
@dataclass
class WorkflowInstance:
    """工作流实例"""
    workflow_id: str
    workflow_type: WorkflowType
    steps: List[WorkflowStep]
    context: Dict[str, Any] = field(default_factory=dict)
    results: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"     # pending, running, completed, failed
    start_time: datetime = None
    end_time: datetime = None
    
    def __post_init__(self):
        if self.start_time is None:
            self.start_time = datetime.now()

# ==================== 能力模块库 ====================

class CapabilityModules:
    """
    能力模块库 - 解构三种架构的核心能力
    """
    
    # ===== Hermes 能力模块 =====
    
    @staticmethod
    def memory_layer_management(context: Dict) -> Dict:
        """
        记忆分层管理 (Hermes核心)
        
        七层记忆体系：
        - instant: 即时记忆
        - working: 工作记忆
        - short: 短期记忆
        - long: 长期记忆
        - skill: 技能记忆
        - expert: 专家记忆
        - graph: 图记忆
        """
        memory = MFlowEngineV2()
        
        operation = context.get("operation", "retrieve")
        layer = context.get("layer", "working")
        content = context.get("content", "")
        
        if operation == "store":
            entry = memory.add_fact({
                "layer": layer,
                "content": content,
                "importance": context.get("importance", 5.0),
                "source": context.get("source", "workflow")
            })
            return {"success": True, "memory_id": entry.get("id"), "layer": layer}
        
        elif operation == "retrieve":
            query = context.get("query", content)
            results = memory.retrieve_similar(query, layer=layer, top_k=context.get("top_k", 5))
            return {"success": True, "memories": results, "count": len(results)}
        
        elif operation == "evolve":
            # 记忆进化：整合短期记忆到长期记忆
            short_term = memory.retrieve_by_layer("short")
            consolidated = memory.consolidate_memories(short_term)
            return {"success": True, "consolidated": consolidated}
        
        return {"success": False, "error": "Unknown operation"}
    
    @staticmethod
    def skill_auto_generation(context: Dict) -> Dict:
        """
        技能自动生成 (Hermes核心)
        
        自动从使用模式中提取技能
        """
        from skill_auto_generator import SkillAutoGenerator
        
        generator = SkillAutoGenerator()
        
        trigger_skill = context.get("trigger_skill")
        call_records = context.get("call_records", [])
        
        # 模拟达到阈值
        for record in call_records:
            generator.record_skill_call(
                skill_name=record.get("skill_name", "unknown"),
                query=record.get("query", ""),
                context=record.get("context", {}),
                success=record.get("success", True)
            )
        
        return {
            "success": True,
            "generation_tasks": len(generator.generation_tasks),
            "pending_triggers": list(generator.pending_triggers)
        }
    
    @staticmethod
    def expert_thought_distillation(context: Dict) -> Dict:
        """
        专家思维蒸馏 (Hermes核心)
        
        六路并行采集 + 三重验证提炼
        """
        expert_name = context.get("expert_name", "unknown")
        source_materials = context.get("sources", [])
        
        # 六路并行采集
        collection_results = {
            "biography": CapabilityModules._collect_biography(expert_name),
            "interviews": CapabilityModules._collect_interviews(expert_name),
            "writings": CapabilityModules._collect_writings(expert_name),
            "decisions": CapabilityModules._collect_decisions(expert_name),
            "patterns": CapabilityModules._collect_patterns(expert_name),
            "contradictions": CapabilityModules._collect_contradictions(expert_name)
        }
        
        # 三重验证提炼
        distilled = {
            "mental_models": CapabilityModules._extract_mental_models(collection_results),
            "decision_heuristics": CapabilityModules._extract_heuristics(collection_results),
            "expression_dna": CapabilityModules._extract_expression(collection_results)
        }
        
        return {
            "success": True,
            "expert_name": expert_name,
            "distilled_components": distilled,
            "collection_coverage": len([v for v in collection_results.values() if v])
        }
    
    # ===== DeerFlow 能力模块 =====
    
    @staticmethod
    def deep_research_chain(context: Dict) -> Dict:
        """
        深度研究链 (DeerFlow核心)
        
        问题分解 → 多源搜索 → 信息验证 → 综合分析 → 报告生成
        """
        query = context.get("query", "")
        
        # Step 1: 问题分解
        sub_questions = CapabilityModules._decompose_question(query)
        
        # Step 2: 多源搜索 (并行)
        search_results = {}
        with ThreadPoolExecutor(max_workers=5) as executor:
            futures = {
                executor.submit(CapabilityModules._search_source, sq, source): (sq, source)
                for sq in sub_questions
                for source in ["web", "academic", "news", "social"]
            }
            for future in as_completed(futures):
                sq, source = futures[future]
                try:
                    search_results[f"{sq}_{source}"] = future.result()
                except Exception as e:
                    search_results[f"{sq}_{source}"] = {"error": str(e)}
        
        # Step 3: 信息验证
        verified = CapabilityModules._verify_information(search_results)
        
        # Step 4: 综合分析
        analysis = CapabilityModules._synthesize_analysis(verified, query)
        
        # Step 5: 报告生成
        report = CapabilityModules._generate_research_report(analysis, query)
        
        return {
            "success": True,
            "sub_questions": sub_questions,
            "sources_searched": len(search_results),
            "verified_facts": len(verified),
            "report": report
        }
    
    @staticmethod
    def code_sandbox_execution(context: Dict) -> Dict:
        """
        代码沙箱执行 (DeerFlow核心)
        
        安全隔离的代码执行环境
        """
        code = context.get("code", "")
        language = context.get("language", "python")
        timeout = context.get("timeout", 30)
        
        # 沙箱执行逻辑
        result = {
            "success": True,
            "output": "",
            "errors": [],
            "execution_time": 0.0,
            "sandbox_id": hashlib.md5(code.encode()).hexdigest()[:8]
        }
        
        # 这里集成实际的沙箱执行
        # 简化示例
        try:
            if language == "python":
                # 使用受限exec
                local_ns = {}
                exec(code, {"__builtins__": {}}, local_ns)
                result["output"] = str(local_ns.get("result", "No result"))
        except Exception as e:
            result["success"] = False
            result["errors"].append(str(e))
        
        return result
    
    @staticmethod
    def langgraph_orchestration(context: Dict) -> Dict:
        """
        LangGraph编排 (DeerFlow核心)
        
        状态机驱动的智能体协作
        """
        from parallel_agents import ParallelAgentEngine
        
        engine = ParallelAgentEngine()
        request = context.get("request", "")
        
        result = engine.execute_parallel(request, context)
        
        return {
            "success": True,
            "intent": result.get("intent"),
            "agents_used": result.get("agent_results", {}).keys(),
            "execution_time": result.get("execution_time", 0),
            "output": result.get("final_output", "")
        }
    
    # ===== Swarm 能力模块 =====
    
    @staticmethod
    def lightweight_agent_swarm(context: Dict) -> Dict:
        """
        轻量级智能体群体 (Swarm核心)
        
        简单、快速、可扩展的多智能体协作
        """
        agents = context.get("agents", [])
        task = context.get("task", "")
        
        results = []
        with ThreadPoolExecutor(max_workers=len(agents)) as executor:
            futures = {
                executor.submit(CapabilityModules._run_lightweight_agent, agent, task): agent
                for agent in agents
            }
            for future in as_completed(futures):
                agent = futures[future]
                try:
                    result = future.result()
                    results.append({"agent": agent, "result": result, "success": True})
                except Exception as e:
                    results.append({"agent": agent, "error": str(e), "success": False})
        
        # 聚合结果
        aggregated = CapabilityModules._aggregate_swarm_results(results)
        
        return {
            "success": True,
            "agent_count": len(agents),
            "successful_agents": len([r for r in results if r["success"]]),
            "aggregated_result": aggregated
        }
    
    @staticmethod
    def function_call_routing(context: Dict) -> Dict:
        """
        函数调用路由 (Swarm核心)
        
        基于函数定义的动态路由
        """
        available_functions = context.get("functions", [])
        user_intent = context.get("intent", "")
        parameters = context.get("parameters", {})
        
        # 匹配最佳函数
        best_match = None
        best_score = 0
        
        for func in available_functions:
            score = CapabilityModules._calculate_function_match(func, user_intent, parameters)
            if score > best_score:
                best_score = score
                best_match = func
        
        if best_match and best_score > 0.6:
            return {
                "success": True,
                "routed_function": best_match.get("name"),
                "confidence": best_score,
                "parameters": CapabilityModules._map_parameters(best_match, parameters)
            }
        
        return {
            "success": False,
            "error": "No suitable function found",
            "best_match": best_match.get("name") if best_match else None,
            "confidence": best_score
        }
    
    @staticmethod
    def context_handoff(context: Dict) -> Dict:
        """
        上下文交接 (Swarm核心)
        
        智能体间的状态传递
        """
        from_agent = context.get("from_agent")
        to_agent = context.get("to_agent")
        current_context = context.get("context", {})
        
        # 提取关键上下文
        essential_context = {
            "user_intent": current_context.get("intent"),
            "key_facts": current_context.get("facts", []),
            "pending_tasks": current_context.get("pending", []),
            "conversation_history": current_context.get("history", [])[-5:],  # 最近5轮
            "shared_memory": current_context.get("shared_memory", {})
        }
        
        # 转换为目标智能体格式
        adapted_context = CapabilityModules._adapt_context_for_agent(
            essential_context, from_agent, to_agent
        )
        
        return {
            "success": True,
            "from": from_agent,
            "to": to_agent,
            "handoff_context": adapted_context,
            "context_compression_ratio": len(str(adapted_context)) / len(str(current_context))
        }
    
    # ===== 辅助方法 =====
    
    @staticmethod
    def _collect_biography(expert: str) -> Dict:
        return {"source": "biography", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_interviews(expert: str) -> Dict:
        return {"source": "interviews", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_writings(expert: str) -> Dict:
        return {"source": "writings", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_decisions(expert: str) -> Dict:
        return {"source": "decisions", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_patterns(expert: str) -> Dict:
        return {"source": "patterns", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_contradictions(expert: str) -> Dict:
        return {"source": "contradictions", "expert": expert, "data": {}}
    
    @staticmethod
    def _extract_mental_models(collection: Dict) -> List[Dict]:
        return [{"model": f"model_{i}", "description": ""} for i in range(3)]
    
    @staticmethod
    def _extract_heuristics(collection: Dict) -> List[str]:
        return ["heuristic_1", "heuristic_2", "heuristic_3"]
    
    @staticmethod
    def _extract_expression(collection: Dict) -> Dict:
        return {"style": "analytical", "patterns": []}
    
    @staticmethod
    def _decompose_question(query: str) -> List[str]:
        return [f"sub_question_{i}" for i in range(3)]
    
    @staticmethod
    def _search_source(question: str, source: str) -> Dict:
        return {"question": question, "source": source, "results": []}
    
    @staticmethod
    def _verify_information(search_results: Dict) -> List[Dict]:
        return [{"fact": k, "verified": True} for k in search_results.keys()]
    
    @staticmethod
    def _synthesize_analysis(verified: List[Dict], query: str) -> Dict:
        return {"query": query, "verified_count": len(verified), "themes": []}
    
    @staticmethod
    def _generate_research_report(analysis: Dict, query: str) -> str:
        return f"Research report for: {query}"
    
    @staticmethod
    def _run_lightweight_agent(agent: str, task: str) -> Dict:
        return {"agent": agent, "task": task, "output": f"Result from {agent}"}
    
    @staticmethod
    def _aggregate_swarm_results(results: List[Dict]) -> Dict:
        return {"consensus": "aggregated", "divergence": []}
    
    @staticmethod
    def _calculate_function_match(func: Dict, intent: str, params: Dict) -> float:
        return 0.8
    
    @staticmethod
    def _map_parameters(func: Dict, params: Dict) -> Dict:
        return params
    
    @staticmethod
    def _adapt_context_for_agent(context: Dict, from_agent: str, to_agent: str) -> Dict:
        return context


# ==================== 超能力工作流 ====================

class HyperWorkflows:
    """
    超能力工作流 - 组合三种架构的优势
    """
    
    @staticmethod
    def hyper_research_workflow(context: Dict) -> Dict:
        """
        超研究工作流
        
        DeerFlow深度研究 + Hermes记忆进化 + Swarm轻量验证
        """
        modules = CapabilityModules()
        
        # Phase 1: DeerFlow深度研究
        research_result = modules.deep_research_chain(context)
        
        # Phase 2: Hermes记忆存储
        memory_result = modules.memory_layer_management({
            "operation": "store",
            "layer": "long",
            "content": json.dumps(research_result["report"]),
            "importance": 8.0,
            "source": "hyper_research"
        })
        
        # Phase 3: Swarm轻量验证
        verification_result = modules.lightweight_agent_swarm({
            "agents": ["fact_checker", "bias_detector", "synthesizer"],
            "task": f"Verify research findings: {research_result['verified_facts']} facts"
        })
        
        return {
            "workflow": "hyper_research",
            "phases": {
                "research": research_result,
                "memory": memory_result,
                "verification": verification_result
            },
            "output": {
                "report": research_result["report"],
                "memory_id": memory_result.get("memory_id"),
                "verification_score": verification_result["successful_agents"] / 3
            }
        }
    
    @staticmethod
    def hyper_creation_workflow(context: Dict) -> Dict:
        """
        超创造工作流
        
        Swarm协作生成 + Hermes技能蒸馏 + DeerFlow代码执行
        """
        modules = CapabilityModules()
        
        # Phase 1: Swarm协作生成创意
        swarm_result = modules.lightweight_agent_swarm({
            "agents": ["ideator", "critic", "refiner"],
            "task": context.get("creation_task", "Generate creative solution")
        })
        
        # Phase 2: Hermes技能自动提取
        skill_result = modules.skill_auto_generation({
            "trigger_skill": "creative_generation",
            "call_records": [{"skill_name": "ideator", "query": context.get("creation_task"), "success": True}]
        })
        
        # Phase 3: DeerFlow代码实现
        code_result = modules.code_sandbox_execution({
            "code": swarm_result["aggregated_result"].get("implementation", "# TODO"),
            "language": context.get("language", "python")
        })
        
        return {
            "workflow": "hyper_creation",
            "phases": {
                "generation": swarm_result,
                "skill_extraction": skill_result,
                "implementation": code_result
            },
            "output": {
                "creative_solution": swarm_result["aggregated_result"],
                "skill_generated": skill_result["generation_tasks"] > 0,
                "code_executed": code_result["success"]
            }
        }
    
    @staticmethod
    def hyper_evolution_workflow(context: Dict) -> Dict:
        """
        超进化工作流
        
        Hermes专家克隆 + DeerFlow多智能体链 + Swarm函数路由
        """
        modules = CapabilityModules()
        
        # Phase 1: Hermes专家克隆
        expert_result = modules.expert_thought_distillation({
            "expert_name": context.get("expert_name", "unknown"),
            "sources": context.get("sources", [])
        })
        
        # Phase 2: DeerFlow多智能体链执行
        chain_result = modules.langgraph_orchestration({
            "request": f"Apply expert model: {context.get('expert_name')}",
            "expert_distilled": expert_result["distilled_components"]
        })
        
        # Phase 3: Swarm函数路由优化
        routing_result = modules.function_call_routing({
            "functions": context.get("available_functions", []),
            "intent": context.get("optimization_goal", "improve"),
            "parameters": {"expert_model": expert_result["distilled_components"]}
        })
        
        return {
            "workflow": "hyper_evolution",
            "phases": {
                "expert_cloning": expert_result,
                "execution": chain_result,
                "optimization": routing_result
            },
            "output": {
                "expert_model": expert_result["distilled_components"],
                "execution_result": chain_result["output"],
                "optimization_route": routing_result.get("routed_function")
            }
        }


# ==================== 工作流编排器 ====================

class WorkflowOrchestrator:
    """
    工作流编排器 - 统一入口
    """
    
    WORKFLOW_REGISTRY = {
        # Hermes工作流
        WorkflowType.MEMORY_EVOLUTION: CapabilityModules.memory_layer_management,
        WorkflowType.SKILL_DISTILLATION: CapabilityModules.skill_auto_generation,
        WorkflowType.EXPERT_CLONING: CapabilityModules.expert_thought_distillation,
        
        # DeerFlow工作流
        WorkflowType.DEEP_RESEARCH: CapabilityModules.deep_research_chain,
        WorkflowType.CODE_EXECUTION: CapabilityModules.code_sandbox_execution,
        WorkflowType.MULTI_AGENT_CHAIN: CapabilityModules.langgraph_orchestration,
        
        # Swarm工作流
        WorkflowType.LIGHTWEIGHT_SWARM: CapabilityModules.lightweight_agent_swarm,
        WorkflowType.FUNCTION_ROUTING: CapabilityModules.function_call_routing,
        WorkflowType.CONTEXT_HANDOFF: CapabilityModules.context_handoff,
        
        # 超能力工作流
        WorkflowType.HYPER_RESEARCH: HyperWorkflows.hyper_research_workflow,
        WorkflowType.HYPER_CREATION: HyperWorkflows.hyper_creation_workflow,
        WorkflowType.HYPER_EVOLUTION: HyperWorkflows.hyper_evolution_workflow,
    }
    
    def __init__(self):
        self.memory = MFlowEngineV2()
        self.execution_history: List[Dict] = []
        
    def execute(self, workflow_type: Union[str, WorkflowType], context: Dict) -> Dict:
        """
        执行工作流
        """
        if isinstance(workflow_type, str):
            workflow_type = WorkflowType(workflow_type)
        
        workflow_id = hashlib.md5(
            f"{workflow_type.value}_{datetime.now()}".encode()
        ).hexdigest()[:12]
        
        # 记录开始
        start_time = datetime.now()
        
        # 获取工作流函数
        workflow_func = self.WORKFLOW_REGISTRY.get(workflow_type)
        if not workflow_func:
            return {"success": False, "error": f"Unknown workflow: {workflow_type}"}
        
        # 执行
        try:
            result = workflow_func(context)
            result["workflow_id"] = workflow_id
            result["workflow_type"] = workflow_type.value
            result["execution_time"] = (datetime.now() - start_time).total_seconds()
            result["success"] = result.get("success", True)
        except Exception as e:
            result = {
                "success": False,
                "workflow_id": workflow_id,
                "workflow_type": workflow_type.value,
                "error": str(e),
                "execution_time": (datetime.now() - start_time).total_seconds()
            }
        
        # 记录历史
        self.execution_history.append({
            "workflow_id": workflow_id,
            "type": workflow_type.value,
            "timestamp": start_time.isoformat(),
            "success": result["success"]
        })
        
        # 存储到记忆
        from mflow_v2 import MemoryEntry
        self.memory.store(MemoryEntry(
            id=f"wf_{workflow_id}",
            layer="skill",
            content=json.dumps({
                "workflow": workflow_type.value,
                "context": str(context)[:200],
                "result_summary": "success" if result["success"] else "failed"
            }),
            source="workflow_orchestrator",
            importance=7.0
        ))
        
        return result
    
    def get_capabilities(self) -> Dict:
        """获取所有能力模块"""
        return {
            "hermes_modules": [
                "memory_layer_management",
                "skill_auto_generation", 
                "expert_thought_distillation"
            ],
            "deerflow_modules": [
                "deep_research_chain",
                "code_sandbox_execution",
                "langgraph_orchestration"
            ],
            "swarm_modules": [
                "lightweight_agent_swarm",
                "function_call_routing",
                "context_handoff"
            ],
            "hyper_workflows": [
                "hyper_research",
                "hyper_creation",
                "hyper_evolution"
            ]
        }
    
    def recommend_workflow(self, task_description: str) -> List[Dict]:
        """
        根据任务描述推荐工作流
        """
        recommendations = []
        
        # 关键词匹配
        keywords = {
            WorkflowType.HYPER_RESEARCH: ["研究", "分析", "调查", "报告"],
            WorkflowType.HYPER_CREATION: ["创建", "生成", "设计", "实现"],
            WorkflowType.HYPER_EVOLUTION: ["优化", "进化", "改进", "学习"],
            WorkflowType.DEEP_RESEARCH: ["深度", "详细", "全面"],
            WorkflowType.SKILL_DISTILLATION: ["技能", "自动化", "提取"],
        }
        
        for wf_type, kws in keywords.items():
            score = sum(1 for kw in kws if kw in task_description.lower())
            if score > 0:
                recommendations.append({
                    "workflow": wf_type.value,
                    "confidence": min(score / len(kws) + 0.3, 1.0),
                    "reason": f"匹配关键词: {[kw for kw in kws if kw in task_description.lower()]}"
                })
        
        return sorted(recommendations, key=lambda x: x["confidence"], reverse=True)[:3]


# 便捷函数
def create_orchestrator() -> WorkflowOrchestrator:
    """创建工作流编排器实例"""
    return WorkflowOrchestrator()

def execute_hyper_workflow(workflow_type: str, context: Dict) -> Dict:
    """便捷函数：执行超能力工作流"""
    orchestrator = WorkflowOrchestrator()
    return orchestrator.execute(workflow_type, context)


if __name__ == "__main__":
    print("=== 超能力工作流编排器 v3.4 ===\n")
    
    orchestrator = WorkflowOrchestrator()
    
    # 显示能力模块
    print("【能力模块矩阵】")
    caps = orchestrator.get_capabilities()
    for category, modules in caps.items():
        print(f"\n{category}:")
        for m in modules:
            print(f"  - {m}")
    
    # 测试超研究工作流
    print("\n\n【测试】超研究工作流")
    result = orchestrator.execute(WorkflowType.HYPER_RESEARCH, {
        "query": "AI智能体架构发展趋势"
    })
    print(f"工作流ID: {result.get('workflow_id', 'N/A')}")
    print(f"执行时间: {result.get('execution_time', 0):.3f}s")
    print(f"成功: {result.get('success', False)}")
    if 'output' in result and 'verification_score' in result['output']:
        print(f"验证分数: {result['output']['verification_score']:.2f}")
    else:
        print(f"结果结构: {list(result.keys())}")
    
    # 测试工作流推荐
    print("\n【测试】工作流推荐")
    recommendations = orchestrator.recommend_workflow("我需要深入研究一个复杂的技术问题并生成报告")
    for rec in recommendations:
        print(f"  - {rec['workflow']} (置信度: {rec['confidence']:.2f})")
