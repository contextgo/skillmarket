# Agent Knowledge Graph Construction

Methods for building and maintaining knowledge graphs that help AI agents navigate complex information spaces.

## Why Knowledge Graphs?

- Connect related concepts across different domains
- Enable reasoning about relationships and dependencies
- Support semantic navigation through large knowledge bases
- Facilitate discovery of non-obvious connections

## Graph Construction Methods

### 1. Entity Extraction
Identify key entities from unstructured text:
- People, organizations, products
- Concepts, theories, methodologies
- Events, dates, locations
- Technologies, tools, frameworks

### 2. Relationship Mapping
Define how entities connect:
- Hierarchical: parent/child, category/member
- Temporal: before/after, cause/effect
- Associative: related to, similar to, depends on
- Attribute: has property, uses tool, located at

### 3. Weight Assignment
Score relationships by strength:
- Mention frequency in documents
- Explicit linkage (hyperlinks, references)
- Temporal recency (recent connections score higher)
- Cross-domain bridging (unique connections score higher)

## Storage Formats

### Markdown-Based Graph (Simple)
```markdown
## Entity: Polymarket
- Type: Platform
- Related: prediction-markets, crypto-trading, betting
- Attributes: decentralized, real-money, event-based
- Tags: #trading #prediction #crypto
```

### YAML-Based Graph (Structured)
```yaml
entities:
  polymarket:
    type: platform
    relations:
      - target: crypto-trading
        type: related
      - target: prediction-markets
        type: instance-of
```

### File-Based Index
```
knowledge/
├── entities/         # One file per entity
├── relationships/    # Connection definitions
└── index.md          # Entry point with top-level view
```

## Navigation Patterns

- Start from a node, follow strongest connections
- Use tags for category-based filtering
- Semantic search for concept discovery
- Breadth-first for exploration, depth-first for deep dives
