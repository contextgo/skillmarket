---
name: 实验图生成器
displayName: 实验图生成器
description: 用Python生成高清物理/化学实验装置图，支持标注和尺寸标注。
version: 1.0.0
author: OpenClaw Edu
tags: [education, experiment, diagram, python, visualization]
category: education
---

# 实验图生成器

生成物理化学实验装置图。

## 功能

- Python自动绘图
- 高清PNG/SVG输出
- 关键尺寸标注
- 实验器材库

## 使用

```
@实验图生成器 生成自由落体实验装置图，标注关键尺寸
```
