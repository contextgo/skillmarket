#!/usr/bin/env python3
"""
detect_claude_isms.py - Local Claude-ism scanner for reddit-post-writer
Usage: python detect_claude_isms.py "your draft text here"
       python detect_claude_isms.py < draft.txt
"""

import sys
import re

CLAUDE_ISMS = {
    # Power words
    "genuinely": "actually / really / for real",
    "straightforward": "simple / easy / not that hard",
    "comprehensive": "full / complete / the whole thing",
    "absolutely": "yeah / definitely / for sure",
    "essentially": "basically",
    "ultimately": "in the end / eventually",
    "certainly": "sure / yeah / of course",
    "incredibly": "really / super / so",
    "significant": "big / major / a lot",
    "substantial": "big / major / a lot",
    "crucial": "important / key",
    "fundamental": "basic / core / main",
    "optimal": "best",
    "seamless": "smooth / easy",
    "robust": "solid / strong",
    "valuable": "useful / helpful / good",
    # Formal verbs
    "utilize": "use",
    "implement": "do / try / use / set up",
    "leverage": "use",
    "facilitate": "help / make easier",
    "navigate": "deal with / handle / figure out",
    "demonstrate": "show",
    "indicate": "show / mean / suggest",
    "possess": "have",
    "obtain": "get",
    "commence": "start / begin",
    "terminate": "end / stop",
    "endeavor": "try",
    "ascertain": "find out / figure out",
    "ensure": "make sure",
    "eliminate": "get rid of / cut / remove",
    "enhance": "improve / make better",
    # Formal transitions
    "however": "but / though",
    "therefore": "so",
    "furthermore": "also / and / plus",
    "nevertheless": "still / but / even so",
    "additionally": "also / and / plus / oh and",
    "moreover": "also / and",
    "consequently": "so",
    "subsequently": "then / after / next",
    "nonetheless": "still / but",
    "conversely": "but / on the other hand",
    # Prepositional phrases (partial match)
    "in order to": "to",
    "due to the fact that": "because",
    "prior to": "before",
    "subsequent to": "after",
    "in conjunction with": "with",
    # Journey language
    "on this journey": "[delete]",
    "throughout this process": "[delete]",
    "along the way": "[delete]",
    "as you move forward": "[delete]",
}

BANNED_PHRASES = [
    "here's what i learned",
    "here's the thing",
    "let me share",
    "let me explain",
    "let me tell you",
    "in my experience",
    "i want to share",
    "to be fair",
    "the bottom line is",
    "looking back",
    "interestingly",
    "i've come to realize",
    "the truth is",
    "at the end of the day",
    "it goes without saying",
    "that being said",
    "i can't help but",
    "it's worth noting",
]


def scan(text):
    results = {"claude_isms": [], "banned_phrases": [], "stats": {}}
    text_lower = text.lower()

    for term, replacement in CLAUDE_ISMS.items():
        pattern = r'\b' + re.escape(term) + r'\b'
        matches = re.findall(pattern, text_lower)
        if matches:
            results["claude_isms"].append({
                "term": term,
                "count": len(matches),
                "replacement": replacement
            })

    for phrase in BANNED_PHRASES:
        if phrase in text_lower:
            results["banned_phrases"].append(phrase)

    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if s.strip()]
    if sentences:
        lengths = [len(s.split()) for s in sentences]
        avg = sum(lengths) / len(lengths)
        variance = sum((l - avg) ** 2 for l in lengths) / len(lengths)
        std_dev = variance ** 0.5
        results["stats"] = {
            "sentence_count": len(sentences),
            "avg_length": round(avg, 1),
            "std_dev": round(std_dev, 1),
            "length_ok": std_dev > 8
        }

    casual_markers = ["honestly", "tbh", "like", "idk", "ngl", "i guess",
                      "maybe", "kinda", "sorta", "basically", "i mean"]
    casual_count = sum(text_lower.count(m) for m in casual_markers)
    results["stats"]["casual_markers"] = casual_count
    results["stats"]["casual_ok"] = casual_count >= 3

    return results


def main():
    if len(sys.argv) > 1:
        text = " ".join(sys.argv[1:])
    else:
        text = sys.stdin.read()

    if not text.strip():
        print("Usage: python detect_claude_isms.py \"your draft text\"")
        sys.exit(1)

    results = scan(text)

    print("\n=== CLAUDE-ISM SCAN RESULTS ===\n")

    if results["claude_isms"]:
        print(f"Claude-isms found: {len(results['claude_isms'])}")
        for item in results["claude_isms"]:
            print(f"  [{item['term']}] x{item['count']} -> {item['replacement']}")
    else:
        print("Claude-isms: CLEAN")

    print()

    if results["banned_phrases"]:
        print(f"Banned phrases found: {len(results['banned_phrases'])}")
        for phrase in results["banned_phrases"]:
            print(f"  \"{phrase}\"")
    else:
        print("Banned phrases: CLEAN")

    print()

    stats = results["stats"]
    if stats:
        std_status = "PASS" if stats.get("length_ok") else "FAIL (needs more variation)"
        casual_status = "PASS" if stats.get("casual_ok") else f"FAIL (need 3+, found {stats['casual_markers']})"
        print(f"Sentence length std dev: {stats.get('std_dev', '?')} -> {std_status}")
        print(f"Casual markers: {stats.get('casual_markers', 0)} -> {casual_status}")

    total_issues = len(results["claude_isms"]) + len(results["banned_phrases"])
    print(f"\nTotal issues: {total_issues}")
    if total_issues == 0:
        print("Result: CLEAN - ready for committee review")
    else:
        print("Result: FIX REQUIRED before proceeding to Phase 5")


if __name__ == "__main__":
    main()
