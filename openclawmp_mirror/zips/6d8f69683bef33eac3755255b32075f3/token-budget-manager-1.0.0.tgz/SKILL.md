---
name: token-budget-manager
description: "LLM Token 用量监控和预算管理，防止超支优化成本"
version: 1.0.0
tags: [llm, token, budget, cost, optimization]
---

# Token 预算管理技能

## 计费基础（2026年参考）

| 模型 | 输入价格 | 输出价格 | 适合场景 |
|------|---------|---------|---------|
| GPT-4o | $2.5/M | $10/M | 通用任务 |
| Claude Sonnet | $3/M | $15/M | 代码分析 |
| GPT-4o-mini | $0.15/M | $0.60/M | 轻量任务 |
| DeepSeek V3 | $0.27/M | $1.10/M | 高性价比 |

## 预算分级策略

```
预算使用率 → 行为

< 50%:  所有模型可用
50-80%: 切换低成本模型
80-95%: 仅紧急任务 + 告警
> 95%:  强制暂停 + 通知
```

## Python 监控器

```python
import time
from dataclasses import dataclass, field

@dataclass
class TokenUsage:
    model: str
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    timestamps: list = field(default_factory=list)
    
    def add_usage(self, input_t, output_t, price_in, price_out):
        self.input_tokens += input_t
        self.output_tokens += output_t
        self.cost_usd += input_t * price_in + output_t * price_out
        self.timestamps.append(time.time())
    
    def daily_cost(self):
        cutoff = time.time() - 86400
        recent = sum(1 for t in self.timestamps if t > cutoff)
        ratio = recent / max(len(self.timestamps), 1)
        return self.cost_usd * ratio
```

## 成本优化技巧

1. **模型分级** — 复杂用高端，日常用 mini，批量用本地
2. **Prompt 压缩** — "请帮我把以下内容翻译成英文" → "Translate:" (省 10+ tokens)
3. **上下文裁剪** — 超过上限时移除最早的消息
4. **缓存重复请求** — 用 hash 作为 key 避免重复调用
5. **Cron 任务精打细算** — 每小时任务必须控制单次 Token 上限

## 估算方法

- 1 token ≈ 4 chars（英文）或 2 chars（中文）
- 混合文本取 ≈ 3 chars/token
- 系统提示通常 500-5000 tokens
- 单次对话 2000-10000 tokens
