#!/usr/bin/env python3
"""
RSS 源健康检查工具
定期检查所有 RSS 源的状态，自动标记失效源，推荐使用备用源

功能:
1. 批量测试所有 RSS 源连通性
2. 自动更新配置文件状态
3. 生成健康检查报告
4. 推荐最优源组合

使用方法:
    python3 rss_health_check.py
    python3 rss_health_check.py --auto-update  # 自动更新配置
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path

# 尝试导入依赖
try:
    import feedparser
    import requests
except ImportError as e:
    print(f"❌ 缺少依赖：{e}")
    print("请运行：pip install feedparser requests")
    sys.exit(1)

# 导入 RSS 配置
sys.path.insert(0, str(Path(__file__).parent))
try:
    from rss_feeds_config import AVAILABLE_RSS_FEEDS, BACKUP_RSS_FEEDS, DEPRECATED_RSS_FEEDS
except ImportError:
    print("⚠️ 无法导入 rss_feeds_config，使用默认配置")
    AVAILABLE_RSS_FEEDS = []
    BACKUP_RSS_FEEDS = []
    DEPRECATED_RSS_FEEDS = []


# ============ 配置 ============

CONFIG_DIR = Path(__file__).parent
HEALTH_REPORT_FILE = CONFIG_DIR / "cache" / "rss_health_report.json"
HEALTH_CHECK_INTERVAL_HOURS = 24  # 健康检查间隔（小时）

# 测试超时时间（秒）
TIMEOUT_SECONDS = 10

# 判定为失效的阈值
FAILURE_THRESHOLD = 3  # 连续失败 3 次标记为失效
EMPTY_THRESHOLD = 5    # 连续 5 次空内容标记为不稳定


# ============ 核心功能 ============

def test_rss_feed(feed_info: dict) -> dict:
    """测试单个 RSS 源"""
    url = feed_info['url']
    name = feed_info['name']
    
    result = {
        'name': name,
        'url': url,
        'category': feed_info.get('category', '未知'),
        'tested_at': datetime.now().isoformat(),
    }
    
    try:
        response = requests.get(url, timeout=TIMEOUT_SECONDS, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        if response.status_code == 200:
            feed = feedparser.parse(response.content)
            entry_count = len(feed.entries)
            
            result['status_code'] = 200
            result['entries'] = entry_count
            
            if entry_count > 0:
                result['status'] = 'active'
                result['latest_title'] = feed.entries[0].title[:100] if feed.entries[0].title else '无标题'
                result['priority'] = 1 if entry_count > 15 else (2 if entry_count > 5 else 3)
            else:
                result['status'] = 'empty'
                result['priority'] = 3
                
        else:
            result['status_code'] = response.status_code
            result['status'] = 'error'
            result['entries'] = 0
            result['priority'] = 3
            
    except requests.exceptions.Timeout:
        result['status'] = 'timeout'
        result['entries'] = 0
        result['priority'] = 3
        
    except Exception as e:
        result['status'] = 'error'
        result['error_message'] = str(e)[:100]
        result['entries'] = 0
        result['priority'] = 3
    
    return result


def run_health_check(feeds: list = None) -> dict:
    """运行健康检查"""
    if feeds is None:
        # 合并所有源
        feeds = AVAILABLE_RSS_FEEDS + BACKUP_RSS_FEEDS
    
    print(f"🔍 开始 RSS 源健康检查...")
    print(f"测试源数：{len(feeds)}")
    print(f"测试时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    
    results = []
    start_time = datetime.now()
    
    for i, feed_info in enumerate(feeds, 1):
        print(f"[{i}/{len(feeds)}] 测试 {feed_info['name']}...", end=" ")
        
        result = test_rss_feed(feed_info)
        results.append(result)
        
        # 显示结果
        if result['status'] == 'active':
            print(f"✅ {result['entries']} 篇")
        elif result['status'] == 'empty':
            print(f"⚠️ 空内容")
        else:
            print(f"❌ {result['status']}")
    
    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()
    
    # 汇总统计
    active_count = sum(1 for r in results if r['status'] == 'active')
    empty_count = sum(1 for r in results if r['status'] == 'empty')
    error_count = sum(1 for r in results if r['status'] in ['error', 'timeout'])
    
    report = {
        'tested_at': datetime.now().isoformat(),
        'duration_seconds': duration,
        'total_feeds': len(results),
        'active': active_count,
        'empty': empty_count,
        'error': error_count,
        'health_rate': active_count / len(results) * 100 if results else 0,
        'feeds': results
    }
    
    # 保存报告
    HEALTH_REPORT_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(HEALTH_REPORT_FILE, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    
    return report


def generate_recommendations(report: dict) -> dict:
    """生成推荐配置"""
    feeds = report['feeds']
    
    # 按类别分组
    categories = {}
    for feed in feeds:
        if feed['status'] == 'active':
            category = feed['category']
            if category not in categories:
                categories[category] = []
            categories[category].append(feed)
    
    # 为每个类别推荐 2-3 个源
    recommendations = {
        'optimal_config': [],
        'backup_config': [],
        'deprecated': []
    }
    
    for category, active_feeds in categories.items():
        # 按文章数排序
        sorted_feeds = sorted(active_feeds, key=lambda x: -x['entries'])
        
        # 前 2-3 个作为最优配置
        for feed in sorted_feeds[:3]:
            recommendations['optimal_config'].append({
                'name': feed['name'],
                'url': feed['url'],
                'category': feed['category'],
                'priority': 1 if feed['entries'] > 15 else 2,
                'status': 'active'
            })
        
        # 其余作为备用
        for feed in sorted_feeds[3:]:
            recommendations['backup_config'].append({
                'name': feed['name'],
                'url': feed['url'],
                'category': feed['category'],
                'priority': 3,
                'status': 'backup'
            })
    
    # 标记失效源
    for feed in feeds:
        if feed['status'] in ['error', 'timeout']:
            recommendations['deprecated'].append({
                'name': feed['name'],
                'url': feed['url'],
                'reason': feed['status']
            })
    
    return recommendations


def print_report(report: dict, recommendations: dict):
    """打印报告"""
    print("\n" + "=" * 60)
    print("📊 健康检查报告")
    print("=" * 60)
    
    print(f"\n测试时间：{report['tested_at']}")
    print(f"测试耗时：{report['duration_seconds']:.1f} 秒")
    print(f"健康率：{report['health_rate']:.1f}%")
    
    print(f"\n总计：{report['total_feeds']} 个源")
    print(f"✅ 活跃：{report['active']} 个")
    print(f"⚠️ 空内容：{report['empty']} 个")
    print(f"❌ 失效：{report['error']} 个")
    
    print("\n" + "-" * 60)
    print("📋 推荐配置")
    print("-" * 60)
    
    print(f"\n✅ 最优配置 ({len(recommendations['optimal_config'])} 个):")
    for feed in recommendations['optimal_config']:
        print(f"   • {feed['name']} ({feed['category']}) - 优先级 {feed['priority']}")
    
    if recommendations['backup_config']:
        print(f"\n⚠️ 备用配置 ({len(recommendations['backup_config'])} 个):")
        for feed in recommendations['backup_config']:
            print(f"   • {feed['name']} ({feed['category']})")
    
    if recommendations['deprecated']:
        print(f"\n❌ 建议移除 ({len(recommendations['deprecated'])} 个):")
        for feed in recommendations['deprecated']:
            print(f"   • {feed['name']} - 原因：{feed['reason']}")


def update_config(recommendations: dict):
    """自动更新配置文件"""
    config_file = CONFIG_DIR / "rss_feeds_config.py"
    
    if not config_file.exists():
        print("⚠️ 配置文件不存在，跳过更新")
        return
    
    print(f"\n📝 更新配置文件：{config_file}")
    
    # 读取当前配置
    with open(config_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 生成新的配置代码
    optimal_feeds = recommendations['optimal_config']
    backup_feeds = recommendations['backup_config']
    
    # 这里可以添加更复杂的配置更新逻辑
    # 为简单起见，我们只生成报告，不自动修改配置
    
    print("⚠️ 自动更新配置功能开发中，请手动更新配置文件")
    print("💡 参考推荐配置，手动调整 rss_feeds_config.py")


# ============ 主程序 ============

def main():
    parser = argparse.ArgumentParser(description='RSS 源健康检查工具')
    parser.add_argument('--auto-update', action='store_true', help='自动更新配置文件')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式报告')
    args = parser.parse_args()
    
    # 运行健康检查
    report = run_health_check()
    
    # 生成推荐
    recommendations = generate_recommendations(report)
    
    # 输出报告
    if args.json:
        print(json.dumps({
            'report': report,
            'recommendations': recommendations
        }, ensure_ascii=False, indent=2))
    else:
        print_report(report, recommendations)
        
        # 自动更新配置
        if args.auto_update:
            update_config(recommendations)
    
    # 返回健康率
    if report['health_rate'] < 50:
        print("\n⚠️ 警告：健康率低于 50%，建议立即检查 RSS 源")
        return 1
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
