#!/usr/bin/env python3
"""
Health Check - 依赖健康检查模块

功能：
- 启动时检查所有依赖模块是否可用
- 为每个依赖提供独立的 fallback 机制
- 生成健康报告，帮助定位问题
"""

import sys
import json
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Callable, Any


class DependencyStatus:
    """依赖状态枚举"""
    OK = "ok"              # 正常
    WARNING = "warning"    # 可用但有警告
    DEGRADED = "degraded"  # 降级运行
    FAILED = "failed"      # 完全不可用


class DependencyInfo:
    """依赖信息类"""
    def __init__(self, name: str, required: bool = True):
        self.name = name
        self.required = required
        self.status = DependencyStatus.OK
        self.message = ""
        self.fallback_active = False
        self.import_error: Optional[Exception] = None
        self.module: Any = None
        self.check_time: Optional[datetime] = None
    
    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "required": self.required,
            "status": self.status,
            "message": self.message,
            "fallback_active": self.fallback_active,
            "has_error": self.import_error is not None,
            "check_time": self.check_time.isoformat() if self.check_time else None
        }


class HealthChecker:
    """健康检查器"""
    
    def __init__(self, base_path: Optional[Path] = None):
        self.base_path = base_path or Path(__file__).parent
        self.dependencies: Dict[str, DependencyInfo] = {}
        self.fallbacks: Dict[str, Callable] = {}
        self.check_results: List[dict] = []
        
        # 注册所有依赖模块
        self._register_dependencies()
    
    def _register_dependencies(self):
        """注册所有依赖模块"""
        # 核心依赖（必需）
        self._register("broadcast_cache", required=True)
        self._register("template_validator", required=True)
        
        # 数据获取依赖（重要，但有 fallback）
        self._register("stock_multi_fetcher", required=False, 
                      external_path=self.base_path.parent / "stock-multi-fetcher")
        self._register("news_aggregator", required=False)
        
        # 新闻源依赖（可选，多层 fallback）
        # 注意：newsnow-reader 在 skills/skills/ 目录下（嵌套），是脚本文件
        self._register("newsnow_reader", required=False,
                      script_path=self.base_path.parent / "skills" / "newsnow-reader" / "scripts" / "fetch_news.py",
                      is_script=True)
        self._register("daily_hot_news", required=False,
                      script_path=self.base_path.parent / "daily-hot-news" / "daily_hot_news.py")
        self._register("wechat_scraper", required=False)
        self._register("fast_data_fetch", required=False)
        
        # 工具依赖（可选）
        self._register("news_cache", required=False)
        self._register("timeout_report", required=False)
    
    def _register(self, name: str, required: bool = True, 
                  external_path: Optional[Path] = None,
                  script_path: Optional[Path] = None,
                  is_script: bool = False):
        """注册一个依赖"""
        dep = DependencyInfo(name, required)
        dep.is_script = is_script  # 标记是否为脚本文件（不需要导入）
        
        # 设置模块路径
        if external_path:
            dep.module_path = external_path / f"{name}.py"
        elif script_path:
            dep.module_path = script_path
        else:
            dep.module_path = self.base_path / f"{name}.py"
        
        self.dependencies[name] = dep
    
    def register_fallback(self, name: str, fallback_func: Callable):
        """注册一个依赖的 fallback 函数"""
        self.fallbacks[name] = fallback_func
        if name in self.dependencies:
            self.dependencies[name].fallback_active = True
    
    def check_all(self) -> Dict[str, DependencyInfo]:
        """检查所有依赖"""
        print("\n" + "="*60)
        print("🏥 开始健康检查...")
        print("="*60)
        
        for name, dep in self.dependencies.items():
            self._check_dependency(dep)
        
        # 生成报告
        self._print_report()
        
        return self.dependencies
    
    def _check_dependency(self, dep: DependencyInfo):
        """检查单个依赖"""
        dep.check_time = datetime.now()
        
        # 1. 检查文件是否存在
        if not dep.module_path.exists():
            dep.status = DependencyStatus.FAILED
            dep.message = f"文件不存在：{dep.module_path}"
            print(f"❌ {dep.name}: {dep.message}")
            return
        
        # 对于脚本文件，只检查存在性，不尝试导入
        if getattr(dep, 'is_script', False):
            dep.status = DependencyStatus.OK
            dep.message = "脚本文件存在（无需导入）"
            print(f"✅ {dep.name}: 正常（脚本）")
            return
        
        # 2. 尝试导入模块
        try:
            sys.path.insert(0, str(self.base_path))
            if dep.module_path.parent != self.base_path:
                sys.path.insert(0, str(dep.module_path.parent))
            
            module_name = dep.name.replace("-", "_")
            module = __import__(module_name)
            
            dep.module = module
            dep.status = DependencyStatus.OK
            dep.message = "导入成功"
            print(f"✅ {dep.name}: 正常")
            
        except ImportError as e:
            dep.import_error = e
            dep.status = DependencyStatus.FAILED
            dep.message = f"导入失败：{str(e)[:100]}"
            print(f"❌ {dep.name}: {dep.message}")
            
            # 检查是否有 fallback
            if dep.name in self.fallbacks:
                dep.fallback_active = True
                dep.status = DependencyStatus.DEGRADED
                dep.message += " (fallback 已激活)"
                print(f"   ⚠️ fallback 已激活")
        
        except Exception as e:
            dep.import_error = e
            dep.status = DependencyStatus.WARNING
            dep.message = f"异常：{str(e)[:100]}"
            print(f"⚠️ {dep.name}: {dep.message}")
        
        finally:
            # 清理 sys.path
            if str(self.base_path) in sys.path:
                sys.path.remove(str(self.base_path))
    
    def _print_report(self):
        """打印健康报告"""
        print("\n" + "="*60)
        print("📊 健康检查报告")
        print("="*60)
        
        # 统计
        total = len(self.dependencies)
        ok_count = sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.OK)
        warning_count = sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.WARNING)
        degraded_count = sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.DEGRADED)
        failed_count = sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.FAILED)
        
        print(f"\n总依赖数：{total}")
        print(f"✅ 正常：{ok_count}")
        print(f"⚠️ 警告：{warning_count}")
        print(f"🔶 降级：{degraded_count}")
        print(f"❌ 失败：{failed_count}")
        
        # 检查必需依赖
        required_failed = [d for d in self.dependencies.values() 
                          if d.required and d.status in [DependencyStatus.FAILED, DependencyStatus.DEGRADED]]
        
        if required_failed:
            print(f"\n❌ 警告：{len(required_failed)} 个必需依赖不可用:")
            for dep in required_failed:
                print(f"   - {dep.name}: {dep.message}")
            print("\n建议：请先修复必需依赖后再运行播报")
        else:
            print(f"\n✅ 所有必需依赖正常")
        
        # 详细列表
        print("\n详细列表:")
        print("-"*60)
        for name, dep in sorted(self.dependencies.items()):
            icon = {"ok": "✅", "warning": "⚠️", "degraded": "🔶", "failed": "❌"}[dep.status]
            fallback = " (fallback)" if dep.fallback_active else ""
            print(f"{icon} {name}: {dep.status}{fallback}")
            if dep.message and dep.status != DependencyStatus.OK:
                print(f"   └─ {dep.message}")
        
        print("="*60 + "\n")
    
    def get_summary(self) -> dict:
        """获取健康摘要"""
        return {
            "check_time": datetime.now().isoformat(),
            "total": len(self.dependencies),
            "ok": sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.OK),
            "warning": sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.WARNING),
            "degraded": sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.DEGRADED),
            "failed": sum(1 for d in self.dependencies.values() if d.status == DependencyStatus.FAILED),
            "required_failed": [d.name for d in self.dependencies.values() 
                               if d.required and d.status in [DependencyStatus.FAILED, DependencyStatus.DEGRADED]],
            "dependencies": {name: dep.to_dict() for name, dep in self.dependencies.items()}
        }
    
    def save_report(self, output_path: Optional[Path] = None):
        """保存健康报告到文件"""
        if output_path is None:
            output_path = self.base_path / "health_report.json"
        
        report = self.get_summary()
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False)
        
        print(f"📁 健康报告已保存：{output_path}")
        return output_path
    
    def is_healthy(self) -> bool:
        """检查是否健康（所有必需依赖正常）"""
        for dep in self.dependencies.values():
            if dep.required and dep.status in [DependencyStatus.FAILED, DependencyStatus.DEGRADED]:
                return False
        return True
    
    def get_module(self, name: str) -> Optional[Any]:
        """获取已导入的模块（带 fallback 检查）"""
        if name not in self.dependencies:
            return None
        
        dep = self.dependencies[name]
        
        # 如果模块正常，返回模块
        if dep.module is not None:
            return dep.module
        
        # 如果有 fallback，返回 fallback 函数
        if name in self.fallbacks and dep.fallback_active:
            return self.fallbacks[name]
        
        return None


# ============ 预定义的 fallback 函数 ============

def fallback_stock_fetcher(symbol: str) -> dict:
    """股票数据 fallback - 使用新浪财经 API"""
    import urllib.request
    from datetime import datetime
    
    try:
        if symbol.isdigit():  # A 股
            if symbol.startswith('6'):
                url = f"http://hq.sinajs.cn/list=sh{symbol}"
            else:
                url = f"http://hq.sinajs.cn/list=sz{symbol}"
        else:  # 美股
            url = f"http://hq.sinajs.cn/list=gb_{symbol.lower()}"
        
        req = urllib.request.urlopen(url, timeout=10)
        content = req.read().decode('gbk', errors='ignore')
        
        if '=' in content and '"' in content:
            parts = content.split('=')[1].strip()[1:-1].split(',')
            if len(parts) > 3:
                current_price = parts[3]
                prev_close = parts[2]
                change = ((float(current_price) - float(prev_close)) / float(prev_close) * 100) if current_price and prev_close else 0
                
                return {
                    'price': current_price,
                    'change_percent': f"{change:.2f}",
                    'volume': parts[6] if len(parts) > 6 else '0',
                    'timestamp': datetime.now().strftime('%H:%M:%S'),
                    'source': 'sina_fallback',
                    'confidence': 0.7
                }
    except Exception as e:
        print(f"⚠️ 股票 fallback 失败：{e}")
    
    # 最终兜底
    return {
        'price': '待更新',
        'change_percent': '0.00',
        'source': 'default_fallback',
        'timestamp': datetime.now().strftime('%H:%M:%S'),
        'confidence': 0.1
    }


def fallback_news_fetcher(days: int = 3, limit: int = 5) -> list:
    """新闻获取 fallback - 返回备用新闻"""
    from datetime import datetime, timedelta
    
    backup_news = [
        {
            "title": "AI 行业持续发展，多家科技公司发布新产品",
            "source_name": "备用新闻源",
            "pub_date": (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d'),
            "summary": "科技行业动态，AI 领域持续创新",
            "link": ""
        },
        {
            "title": "全球市场震荡，科技股表现分化",
            "source_name": "备用新闻源",
            "pub_date": (datetime.now() - timedelta(days=1)).strftime('%Y-%m-%d'),
            "summary": "市场动态，投资者需关注风险",
            "link": ""
        }
    ]
    
    print("⚠️ 使用备用新闻数据")
    return backup_news[:limit]


def fallback_weather_fetcher(city: str = "beijing") -> dict:
    """天气获取 fallback - 返回默认天气"""
    from datetime import datetime
    
    # 根据城市返回默认天气
    defaults = {
        "beijing": {
            "weather": "☀️ 晴",
            "temp": "15°C",
            "humidity": "40%",
            "wind": "2 级 北风",
            "suggestion": "适宜户外活动"
        },
        "shenzhen": {
            "weather": "⛅ 多云",
            "temp": "22°C",
            "humidity": "60%",
            "wind": "2 级 东南风",
            "suggestion": "舒适宜人"
        }
    }
    
    result = defaults.get(city, defaults["beijing"])
    result['timestamp'] = datetime.now().strftime('%H:%M:%S')
    result['source'] = 'default_fallback'
    
    print(f"⚠️ {city} 使用备用天气数据")
    return result


# ============ 命令行入口 ============

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='健康检查工具')
    parser.add_argument('--save', action='store_true', help='保存报告到文件')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    parser.add_argument('--quiet', action='store_true', help='静默模式（只输出摘要）')
    
    args = parser.parse_args()
    
    checker = HealthChecker()
    checker.check_all()
    
    if args.json:
        print(json.dumps(checker.get_summary(), indent=2, ensure_ascii=False))
    elif args.quiet:
        summary = checker.get_summary()
        status = "✅ 健康" if checker.is_healthy() else "❌ 不健康"
        print(f"{status} | 正常:{summary['ok']} | 警告:{summary['warning']} | 降级:{summary['degraded']} | 失败:{summary['failed']}")
    
    if args.save:
        checker.save_report()
    
    sys.exit(0 if checker.is_healthy() else 1)
