#!/bin/bash
# 自动反思脚本 - 播报完成后自动调用

echo "=== 播报后自动反思 ==="

# 获取当前时间
BROADCAST_ID=$(date +"%H_00")
RUNTIME=${1:-15}  # 默认 15 秒
TOKENS=${2:-600}  # 默认 600 tokens

# 数据质量 (从环境变量或默认值)
DATA_QUALITY=${DATA_QUALITY:-'{"513100":"L5_default","TQQQ":"L5_default","news":"L1","weather":"L1"}'}

# 反思输出文件
REFLECTION_FILE="/home/admin/openclaw/workspace/memory/reflection-$(date +%Y%m%d-%H%M).md"

echo "播报 ID: $BROADCAST_ID"
echo "执行时间：${RUNTIME}s"
echo "Token: ${TOKENS}"
echo "数据质量：$DATA_QUALITY"
echo ""

# 生成反思报告
python3 /home/admin/openclaw/workspace/skills/hourly-broadcast/broadcast_reflection.py \
  --broadcast-id "$BROADCAST_ID" \
  --data-quality "$DATA_QUALITY" \
  --runtime "$RUNTIME" \
  --tokens "$TOKENS" \
  --output "$REFLECTION_FILE"

# 记录到追踪表
python3 /home/admin/openclaw/workspace/skills/hourly-broadcast/analytics/data_quality_tracker.py \
  --broadcast-id "$BROADCAST_ID" \
  --data-quality "$DATA_QUALITY" \
  --runtime "$RUNTIME" \
  --tokens "$TOKENS"

echo ""
echo "✅ 反思完成！"
echo "报告：$REFLECTION_FILE"
echo "趋势：python3 analytics/data_quality_tracker.py --trend 7"
