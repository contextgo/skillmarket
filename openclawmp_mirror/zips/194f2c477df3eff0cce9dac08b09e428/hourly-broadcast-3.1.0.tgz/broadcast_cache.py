#!/usr/bin/env python3
"""
Broadcast Cache Manager - 播报缓存管理模块（集成动态 TTL）

功能:
- 保存播报内容到本地 JSON 文件
- 加载缓存内容
- 验证缓存有效性
- 清理过期缓存
- 动态 TTL：根据时间段和数据类型自动调整缓存有效期

动态 TTL 策略:
- 股票缓存：交易时段 3 分钟，非交易时段 15 分钟
- 新闻缓存：AI 新闻 4 小时，财经新闻 8 小时，热榜 1 小时
- 天气缓存：30 分钟
- 播报缓存：60 分钟
"""

import json
import os
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any

# 导入动态 TTL 模块
try:
    from dynamic_ttl_cache import DynamicTTLCache, CacheType
    print("✅ 动态 TTL 缓存模块已加载")
    DYNAMIC_TTL_AVAILABLE = True
except ImportError:
    print("⚠️ 动态 TTL 模块未找到，使用固定 TTL")
    DynamicTTLCache = None
    CacheType = None
    DYNAMIC_TTL_AVAILABLE = False


class BroadcastCache:
    """播报缓存管理器（支持动态 TTL）"""
    
    def __init__(self, cache_dir: str = None, use_dynamic_ttl: bool = True):
        """
        初始化缓存管理器
        
        Args:
            cache_dir: 缓存目录路径，默认为脚本同级的 cache 目录
            use_dynamic_ttl: 是否使用动态 TTL（默认 True）
        """
        if cache_dir is None:
            self.cache_dir = Path(__file__).parent / "cache"
        else:
            self.cache_dir = Path(cache_dir)
        
        # 确保目录存在
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        
        # 动态 TTL 缓存管理器
        self.use_dynamic_ttl = use_dynamic_ttl and DYNAMIC_TTL_AVAILABLE
        if self.use_dynamic_ttl:
            self.dynamic_cache = DynamicTTLCache(self.cache_dir)
            print("✅ 动态 TTL 已启用")
        else:
            self.dynamic_cache = None
            self.cache_ttl_minutes = 15  # 固定 TTL 回退值
            print("⚠️ 使用固定 TTL (15 分钟)")
    
    def get_cache_filename(self, broadcast_time: str) -> str:
        """
        获取缓存文件名
        
        Args:
            broadcast_time: 播报时间，格式 "HH:MM" 或 "YYYY-MM-DD HH:MM"
        
        Returns:
            缓存文件路径
        """
        # 解析时间，提取 HH:MM
        if " " in broadcast_time:
            # 完整格式 "YYYY-MM-DD HH:MM"
            time_part = broadcast_time.split(" ")[1]
        else:
            # 简单格式 "HH:MM"
            time_part = broadcast_time
        
        # 转换为文件名 (HH_MM.json)
        filename = time_part.replace(":", "_") + ".json"
        return str(self.cache_dir / filename)
    
    def save(self, broadcast_time: str, content: Dict[str, Any], 
             rendered_markdown: str, metadata: Dict[str, Any] = None) -> str:
        """
        保存播报内容到缓存
        
        Args:
            broadcast_time: 播报时间，格式 "HH:MM"
            content: 播报数据字典
            rendered_markdown: 渲染后的 Markdown 内容
            metadata: 额外元数据
        
        Returns:
            缓存文件路径
        """
        cache_file = self.get_cache_filename(broadcast_time)
        
        # 计算过期时间
        if self.use_dynamic_ttl:
            ttl_minutes = self.dynamic_cache.get_ttl(CacheType.BROADCAST)
            valid_until = datetime.now() + timedelta(minutes=ttl_minutes)
        else:
            ttl_minutes = self.cache_ttl_minutes
            valid_until = datetime.now() + timedelta(minutes=ttl_minutes)
        
        # 构建缓存数据
        cache_data = {
            "broadcast_time": broadcast_time,
            "prepared_at": datetime.now().isoformat(),
            "valid_until": valid_until.isoformat(),
            "ttl_minutes": ttl_minutes,
            "status": "ready",
            "content": content,
            "rendered_markdown": rendered_markdown,
            "metadata": metadata or {},
            "use_dynamic_ttl": self.use_dynamic_ttl
        }
        
        # 保存到文件
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 缓存已保存：{cache_file} (TTL: {ttl_minutes}分钟，过期：{valid_until.strftime('%H:%M:%S')})")
        return cache_file
    
    def load(self, broadcast_time: str) -> Optional[Dict[str, Any]]:
        """
        加载缓存内容
        
        Args:
            broadcast_time: 播报时间，格式 "HH:MM"
        
        Returns:
            缓存数据字典，如果不存在或过期则返回 None
        """
        cache_file = self.get_cache_filename(broadcast_time)
        
        if not os.path.exists(cache_file):
            print(f"⚠️ 缓存文件不存在：{cache_file}")
            return None
        
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            
            # 验证是否过期
            if not self.is_valid(cache_data):
                print(f"⚠️ 缓存已过期：{cache_file}")
                return None
            
            # 计算剩余有效期
            valid_until = datetime.fromisoformat(cache_data["valid_until"])
            remaining = (valid_until - datetime.now()).total_seconds() / 60
            
            ttl_info = f"TTL:{cache_data.get('ttl_minutes', 'N/A')}min"
            print(f"✅ 缓存已加载：{cache_file} (剩余:{remaining:.1f}min, {ttl_info})")
            return cache_data
        
        except Exception as e:
            print(f"❌ 加载缓存失败：{e}")
            return None
    
    def is_valid(self, cache_data: Dict[str, Any]) -> bool:
        """
        验证缓存是否有效
        
        Args:
            cache_data: 缓存数据
        
        Returns:
            True 如果有效，False 如果过期
        """
        try:
            valid_until = datetime.fromisoformat(cache_data.get("valid_until", ""))
            return datetime.now() < valid_until
        except:
            return False
    
    def exists(self, broadcast_time: str) -> bool:
        """
        检查缓存是否存在且有效
        
        Args:
            broadcast_time: 播报时间，格式 "HH:MM"
        
        Returns:
            True 如果存在且有效
        """
        cache_data = self.load(broadcast_time)
        return cache_data is not None
    
    def delete(self, broadcast_time: str) -> bool:
        """
        删除缓存文件
        
        Args:
            broadcast_time: 播报时间，格式 "HH:MM"
        
        Returns:
            True 如果删除成功
        """
        cache_file = self.get_cache_filename(broadcast_time)
        
        if os.path.exists(cache_file):
            os.remove(cache_file)
            print(f"✅ 缓存已删除：{cache_file}")
            return True
        else:
            print(f"⚠️ 缓存文件不存在：{cache_file}")
            return False
    
    def cleanup(self, keep_hours: int = 24) -> int:
        """
        清理过期缓存
        
        Args:
            keep_hours: 保留最近 N 小时的缓存
        
        Returns:
            删除的文件数量
        """
        deleted_count = 0
        cutoff_time = datetime.now() - timedelta(hours=keep_hours)
        
        for cache_file in self.cache_dir.glob("*.json"):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                
                prepared_at = datetime.fromisoformat(cache_data.get("prepared_at", ""))
                
                if prepared_at < cutoff_time:
                    os.remove(cache_file)
                    deleted_count += 1
                    print(f"🗑️ 已清理过期缓存：{cache_file.name}")
            
            except Exception as e:
                print(f"⚠️ 清理缓存失败：{cache_file.name} - {e}")
        
        print(f"✅ 清理完成，共删除 {deleted_count} 个过期缓存")
        return deleted_count
    
    def list_all(self) -> list:
        """
        列出所有缓存文件
        
        Returns:
            缓存文件信息列表
        """
        cache_files = []
        
        for cache_file in self.cache_dir.glob("*.json"):
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                
                cache_files.append({
                    "filename": cache_file.name,
                    "broadcast_time": cache_data.get("broadcast_time", "unknown"),
                    "prepared_at": cache_data.get("prepared_at", "unknown"),
                    "valid_until": cache_data.get("valid_until", "unknown"),
                    "ttl_minutes": cache_data.get("ttl_minutes", "unknown"),
                    "status": cache_data.get("status", "unknown"),
                    "is_valid": self.is_valid(cache_data)
                })
            except:
                cache_files.append({
                    "filename": cache_file.name,
                    "status": "error"
                })
        
        return cache_files
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取缓存统计信息
        
        Returns:
            统计信息字典
        """
        cache_list = self.list_all()
        
        stats = {
            "total_files": len(cache_list),
            "valid_count": sum(1 for c in cache_list if c.get("is_valid", False)),
            "expired_count": sum(1 for c in cache_list if not c.get("is_valid", False)),
            "use_dynamic_ttl": self.use_dynamic_ttl,
            "files": cache_list
        }
        
        return stats
    
    def print_stats(self):
        """打印缓存统计信息"""
        stats = self.get_stats()
        
        print("\n" + "="*60)
        print("📊 播报缓存统计")
        print("="*60)
        print(f"总文件数：{stats['total_files']}")
        print(f"有效缓存：{stats['valid_count']}")
        print(f"过期缓存：{stats['expired_count']}")
        print(f"动态 TTL: {'✅ 已启用' if stats['use_dynamic_ttl'] else '⚠️ 未启用'}")
        
        if stats['files']:
            print("\n缓存列表:")
            for cache in sorted(stats['files'], key=lambda x: x.get('broadcast_time', '')):
                status_icon = "✅" if cache.get('is_valid') else "❌"
                ttl = cache.get('ttl_minutes', 'N/A')
                print(f"  {status_icon} {cache['filename']}: {cache['broadcast_time']} (TTL:{ttl}min)")
        
        print("="*60 + "\n")


# ============ 便捷函数 ============

def save_broadcast(broadcast_time: str, content: dict, markdown: str, **kwargs) -> str:
    """便捷函数：保存播报缓存"""
    cache = BroadcastCache()
    return cache.save(broadcast_time, content, markdown, **kwargs)


def load_broadcast(broadcast_time: str) -> Optional[dict]:
    """便捷函数：加载播报缓存"""
    cache = BroadcastCache()
    return cache.load(broadcast_time)


# ============ 命令行入口 ============

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='播报缓存管理工具')
    parser.add_argument('--stats', action='store_true', help='显示缓存统计')
    parser.add_argument('--list', action='store_true', help='列出所有缓存')
    parser.add_argument('--cleanup', type=int, metavar='HOURS', help='清理 N 小时前的缓存')
    parser.add_argument('--clear', action='store_true', help='清空所有缓存')
    parser.add_argument('--test', action='store_true', help='运行测试')
    
    args = parser.parse_args()
    
    cache = BroadcastCache()
    
    if args.stats:
        cache.print_stats()
    
    elif args.list:
        cache_list = cache.list_all()
        for c in cache_list:
            status = "✅" if c.get('is_valid') else "❌"
            print(f"{status} {c['filename']}: {c.get('broadcast_time', 'N/A')}")
    
    elif args.cleanup:
        cache.cleanup(args.cleanup)
    
    elif args.clear:
        cache.cleanup(0)
    
    elif args.test:
        print("\n=== 测试缓存功能 ===\n")
        
        # 测试保存
        test_data = {
            "test": "data",
            "timestamp": datetime.now().isoformat()
        }
        test_markdown = "# Test Broadcast\n\nThis is a test."
        
        cache_file = cache.save("12_00", test_data, test_markdown, {"test": True})
        
        # 测试加载
        loaded = cache.load("12_00")
        if loaded:
            print(f"\n✅ 加载成功：{loaded['content']}")
        
        # 测试统计
        cache.print_stats()
        
        # 清理测试缓存
        cache.delete("12_00")
        print("\n✅ 测试完成")
    
    else:
        parser.print_help()
