# 1 分钟快速反思指南

**目标**: 每次播报后 1 分钟内完成反思，不增加负担

---

## 🚀 快速流程 (1 分钟)

### 第 1 步：查看数据质量 (10 秒)

播报完成后，查看输出中的置信度：
```
✅ 513100: 8.50 (sina - 置信度 70%)
✅ TQQQ: 65.20 (yfinance - 置信度 90%)
⚠️ 告警：513100 数据降级到 L5_default (置信度 10%)
```

**关键问题**:
- 股票数据是否 >80%? 
- 新闻是否正常？
- 天气是否实时？

---

### 第 2 步：记录到追踪表 (20 秒)

```bash
# 快速命令
python3 /skills/hourly-broadcast/analytics/data_quality_tracker.py \
  --broadcast-id 18_50 \
  --513100 L5 \
  --TQQQ L1 \
  --news L1
```

或直接编辑 JSONL 文件：
```json
{"timestamp":"2026-03-14T18:50:00","broadcast_id":"18_50","avg_confidence":52.5}
```

---

### 第 3 步：生成反思报告 (20 秒)

```bash
python3 /skills/hourly-broadcast/broadcast_reflection.py \
  --broadcast-id 18_50 \
  --data-quality '{"513100":"L5","TQQQ":"L1","news":"L1"}' \
  --runtime 15 --tokens 600
```

---

### 第 4 步：记录关键洞察 (10 秒)

在 `optimization_experiments.md` 追加：
```markdown
### 18:50 播报
- 513100: L5 (10%) - 网络限制
- TQQQ: L1 (95%) - YFinance 正常
- 洞察：A 股数据源需优化，美股正常
- 行动：测试 a-stock-analysis
```

---

## ✅ 完成检查

- [ ] 数据质量已记录
- [ ] 反思报告已生成
- [ ] 关键洞察已记录
- [ ] 行动项已明确

**总耗时**: <1 分钟

---

## 📊 反思模板

```markdown
## [时间] 播报反思

**数据质量**:
- 天气：✅ 95% (wttr.in)
- 新闻：✅ 95% (newsnow-reader)
- 513100: ❌ 10% (L5_default)
- TQQQ: ✅ 95% (yfinance)

**Keep**:
- 天气实时获取正常
- 新闻聚合有效

**Fix**:
- 513100 置信度仅 10%

**Try**:
- 测试 a-stock-analysis
- 配置 HTTP 代理

**行动**:
- [ ] P1: 测试 a-stock-analysis (本周)
```

---

## 🎯 长期追踪

**每周日回顾**:
1. 查看 `quality_log.jsonl` 趋势
2. 统计平均置信度
3. 识别改进最多的数据源
4. 规划下周优化重点

**每月回顾**:
1. 对比月初 vs 月末置信度
2. 评估优化实验效果
3. 调整优化策略
4. 更新 MEMORY.md

---

**核心原则**: 快速、简单、持续、有效
