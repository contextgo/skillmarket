#!/usr/bin/env python3
"""
Template Validator - 播报模板验证模块

功能:
- 验证播报内容是否符合模板要求
- 检查必填字段是否存在
- 检查数据格式是否正确
- 生成验证报告
"""

import re
from typing import Dict, List, Tuple, Any


class TemplateValidator:
    """播报模板验证器"""
    
    # 必填字段列表（根据模板定义）
    REQUIRED_FIELDS = {
        # 基本信息
        "broadcast_time": "播报时间",
        
        # 天气信息（北京）
        "beijing_weather": "北京天气状况",
        "beijing_temp": "北京气温",
        
        # 天气信息（深圳）
        "shenzhen_weather": "深圳天气状况",
        "shenzhen_temp": "深圳气温",
        
        # 市场概览
        "market_time": "数据获取时间",
        "market_source": "数据来源",
        
        # 513100 ETF
        "513100_price": "513100 当前价格",
        "513100_change": "513100 涨跌幅",
        
        # TQQQ
        "tqqq_price": "TQQQ 当前价格",
        "tqqq_change": "TQQQ 涨跌幅",
        
        # 新闻（至少要有 1 条）
        "ai_news1_title": "AI 新闻 1 标题",
    }
    
    # 可选但推荐的字段
    RECOMMENDED_FIELDS = {
        "beijing_humidity": "北京湿度",
        "shenzhen_humidity": "深圳湿度",
        "513100_volume": "513100 成交量",
        "tqqq_volume": "TQQQ 成交量",
        "ai_news1_source": "AI 新闻 1 来源",
        "ai_news1_summary": "AI 新闻 1 摘要",
    }
    
    def __init__(self):
        """初始化验证器"""
        self.errors = []
        self.warnings = []
        self.info = []
    
    def validate_content(self, content: Dict[str, Any]) -> Dict[str, Any]:
        """
        验证播报内容数据
        
        Args:
            content: 播报数据字典
        
        Returns:
            验证报告
        """
        self.errors = []
        self.warnings = []
        self.info = []
        
        # 检查必填字段
        self._check_required_fields(content)
        
        # 检查可选字段
        self._check_recommended_fields(content)
        
        # 检查数据格式
        self._check_data_format(content)
        
        # 检查新闻质量
        self._check_news_quality(content)
        
        # 生成报告
        return self._generate_report()
    
    def validate_markdown(self, markdown: str) -> Dict[str, Any]:
        """
        验证渲染后的 Markdown 内容
        
        Args:
            markdown: Markdown 字符串
        
        Returns:
            验证报告
        """
        self.errors = []
        self.warnings = []
        self.info = []
        
        # 检查必要章节
        self._check_sections(markdown)
        
        # 检查表格格式
        self._check_tables(markdown)
        
        # 检查数据完整性
        self._check_placeholders(markdown)
        
        return self._generate_report()
    
    def _check_required_fields(self, content: Dict[str, Any]):
        """检查必填字段"""
        for field, description in self.REQUIRED_FIELDS.items():
            if field not in content:
                self.errors.append(f"缺少必填字段：{field} ({description})")
            elif content[field] is None or content[field] == "" or content[field] == "待更新":
                # 字段存在但为空
                if field in ["ai_news1_title"]:  # 新闻允许为空
                    self.warnings.append(f"字段为空：{field} ({description})")
                else:
                    self.errors.append(f"字段为空：{field} ({description})")
    
    def _check_recommended_fields(self, content: Dict[str, Any]):
        """检查推荐字段"""
        missing_recommended = []
        for field, description in self.RECOMMENDED_FIELDS.items():
            if field not in content or content[field] is None or content[field] == "":
                missing_recommended.append(f"{field} ({description})")
        
        if len(missing_recommended) > 5:
            self.info.append(f"缺少 {len(missing_recommended)} 个推荐字段（不影响播报）")
    
    def _check_data_format(self, content: Dict[str, Any]):
        """检查数据格式"""
        # 检查价格格式
        price_fields = ["513100_price", "tqqq_price"]
        for field in price_fields:
            if field in content and content[field] not in [None, "", "待更新"]:
                value = str(content[field])
                # 价格应该是数字（可能包含小数点）
                if not re.match(r'^[\d.]+$', value.replace(",", "")):
                    self.warnings.append(f"价格格式可能不正确：{field} = {value}")
        
        # 检查涨跌幅格式
        change_fields = ["513100_change", "tqqq_change"]
        for field in change_fields:
            if field in content and content[field] not in [None, "", "待更新"]:
                value = str(content[field])
                # 涨跌幅应该包含 % 符号
                if "%" not in value and not re.match(r'^[+-]?[\d.]+$', value):
                    self.warnings.append(f"涨跌幅格式可能不正确：{field} = {value}")
        
        # 检查时间格式
        if "market_time" in content and content["market_time"] not in [None, "", "待更新"]:
            time_value = str(content["market_time"])
            # 简单检查是否包含日期时间信息
            if not re.search(r'\d{4}[-/]\d{2}[-/]\d{2}', time_value):
                self.info.append("数据获取时间格式可能不标准")
    
    def _check_news_quality(self, content: Dict[str, Any]):
        """检查新闻质量"""
        news_count = 0
        
        # 统计有效新闻数量
        for i in range(1, 4):
            title_field = f"ai_news{i}_title"
            if title_field in content and content[title_field] not in [None, "", "待更新"]:
                news_count += 1
        
        if news_count == 0:
            self.warnings.append("没有 AI 科技新闻，播报内容可能不够丰富")
        elif news_count < 2:
            self.info.append(f"只有 {news_count} 条 AI 新闻，建议至少 2 条")
        else:
            self.info.append(f"✅ 新闻数量充足：{news_count} 条")
    
    def _check_sections(self, markdown: str):
        """检查必要章节"""
        required_sections = [
            ("## 一、播报基本信息", "基本信息章节"),
            ("## 二、市场行情播报", "市场行情章节"),
            ("## 三、新闻动态", "新闻动态章节"),
            ("## 四、综合分析", "综合分析章节"),
            ("## 五、播报总结", "播报总结章节"),
        ]
        
        for section, description in required_sections:
            if section not in markdown:
                self.errors.append(f"缺少必要章节：{description}")
    
    def _check_tables(self, markdown: str):
        """检查表格格式"""
        # 简单检查：Markdown 表格应该包含 | 符号
        table_count = markdown.count("|")
        if table_count < 20:  # 正常播报应该有多个表格
            self.warnings.append(f"表格数量可能不足（检测到 {table_count//2} 个表格）")
    
    def _check_placeholders(self, markdown: str):
        """检查未替换的占位符"""
        # 检查是否还有"待更新"字样
        pending_count = markdown.count("待更新")
        if pending_count > 10:
            self.warnings.append(f"有 {pending_count} 处数据未更新（待更新）")
        elif pending_count > 0:
            self.info.append(f"有 {pending_count} 处数据标注为待更新")
        
        # 检查是否还有模板占位符
        placeholder_pattern = r'\{data\.get\([^)]+\)\}'
        placeholders = re.findall(placeholder_pattern, markdown)
        if placeholders:
            self.errors.append(f"发现 {len(placeholders)} 个未替换的模板占位符")
    
    def _generate_report(self) -> Dict[str, Any]:
        """生成验证报告"""
        is_valid = len(self.errors) == 0
        
        report = {
            "valid": is_valid,
            "error_count": len(self.errors),
            "warning_count": len(self.warnings),
            "info_count": len(self.info),
            "errors": self.errors,
            "warnings": self.warnings,
            "info": self.info,
            "summary": self._generate_summary(is_valid)
        }
        
        return report
    
    def _generate_summary(self, is_valid: bool) -> str:
        """生成验证摘要"""
        if is_valid:
            if len(self.warnings) == 0:
                return "✅ 模板验证通过，所有必填字段完整"
            else:
                return f"✅ 模板验证通过，但有 {len(self.warnings)} 个警告"
        else:
            return f"❌ 模板验证失败，发现 {len(self.errors)} 个错误"


def validate_broadcast_content(content: Dict[str, Any]) -> Dict[str, Any]:
    """便捷函数：验证播报内容"""
    validator = TemplateValidator()
    return validator.validate_content(content)


def validate_broadcast_markdown(markdown: str) -> Dict[str, Any]:
    """便捷函数：验证 Markdown 内容"""
    validator = TemplateValidator()
    return validator.validate_markdown(markdown)


if __name__ == "__main__":
    # 测试验证器
    validator = TemplateValidator()
    
    # 测试数据（完整）
    test_content = {
        "broadcast_time": "15:00",
        "beijing_weather": "晴",
        "beijing_temp": "15°C ~ 25°C",
        "shenzhen_weather": "多云",
        "shenzhen_temp": "20°C ~ 28°C",
        "market_time": "2026-03-14 14:30:00",
        "market_source": "AkShare",
        "513100_price": "1.234",
        "513100_change": "+1.23%",
        "tqqq_price": "78.90",
        "tqqq_change": "+2.34%",
        "ai_news1_title": "测试新闻标题",
        "ai_news1_source": "量子位",
        "ai_news1_summary": "这是一个测试摘要",
    }
    
    report = validator.validate_content(test_content)
    print("内容验证报告:")
    print(f"有效：{report['valid']}")
    print(f"错误：{report['error_count']}")
    print(f"警告：{report['warning_count']}")
    print(f"信息：{report['info_count']}")
    print(f"摘要：{report['summary']}")
    
    # 测试 Markdown 验证
    test_markdown = """
# 📻 综合整点播报

## 一、播报基本信息
测试内容

## 二、市场行情播报
测试内容

## 三、新闻动态
测试内容

## 四、综合分析
测试内容

## 五、播报总结
测试内容
"""
    
    report = validator.validate_markdown(test_markdown)
    print("\nMarkdown 验证报告:")
    print(f"有效：{report['valid']}")
    print(f"错误：{report['error_count']}")
    print(f"警告：{report['warning_count']}")
