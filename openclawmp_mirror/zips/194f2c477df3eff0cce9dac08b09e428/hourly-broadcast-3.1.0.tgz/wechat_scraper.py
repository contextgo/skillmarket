#!/usr/bin/env python3
"""
微信公众号文章抓取工具 - 增强版
支持 HTTP 代理配置，优化网络请求

目标公众号:
1. APPSO
2. 36 氪
3. 数字生命卡兹克
4. 钛媒体
5. 腾讯科技
6. 量子位
7. 虎嗅

数据源优先级:
- P1: RSS 源（稳定、高效）
- P2: 网站直接抓取
- P3: 搜索引擎聚合

新增功能:
- ✅ HTTP 代理支持（自动检测 + 手动配置）
- ✅ 多代理轮换
- ✅ 请求重试机制
- ✅ 超时优化
- ✅ User-Agent 轮换
"""

import sys
import json
import re
import os
from datetime import datetime, timedelta
from pathlib import Path
import subprocess

# ============ 配置 ============

CACHE_DIR = Path("/tmp/wechat_articles_cache")
CACHE_EXPIRY_SECONDS = 1800  # 30 分钟缓存

# HTTP 代理配置
PROXY_CONFIG = {
    # 自动检测环境变量
    "auto_detect": True,
    
    # 手动配置代理（优先级高于自动检测）
    # 格式：http://username:password@host:port 或 http://host:port
    "manual_proxy": os.getenv("HTTP_PROXY") or os.getenv("http_proxy") or None,
    
    # 代理池（可选，多个代理轮换）
    "proxy_pool": [
        # 示例：
        # "http://proxy1.example.com:8080",
        # "http://proxy2.example.com:8080",
    ],
    
    # 当前使用的代理
    "current_proxy": None,
    
    # 代理超时时间（秒）
    "proxy_timeout": 10,
    
    # 是否使用代理失败后直连
    "fallback_direct": True,
}

# User-Agent 轮换池
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15",
]

# 公众号配置（按优先级排序）
SOURCES = [
    {
        "name": "量子位",
        "priority": 1,
        "rss_url": "https://qbitai.com/feed",
        "web_url": "https://qbitai.com",
        "type": "rss"
    },
    {
        "name": "36 氪",
        "priority": 1,
        "rss_url": "https://36kr.com/feed",
        "web_url": "https://36kr.com",
        "type": "rss"
    },
    {
        "name": "虎嗅",
        "priority": 1,
        "rss_url": "https://www.huxiu.com/rss/",
        "web_url": "https://www.huxiu.com",
        "type": "rss"
    },
    {
        "name": "钛媒体",
        "priority": 2,
        "rss_url": "https://www.tmtpost.com/feed",
        "web_url": "https://www.tmtpost.com",
        "type": "rss"
    },
    {
        "name": "APPSO",
        "priority": 2,
        "rss_url": None,
        "web_url": "https://www.ifanr.com/appso",
        "type": "web"
    },
    {
        "name": "腾讯科技",
        "priority": 2,
        "rss_url": None,
        "web_url": "https://tech.qq.com",
        "type": "web"
    },
    {
        "name": "数字生命卡兹克",
        "priority": 3,
        "rss_url": None,
        "web_url": None,
        "type": "search"
    }
]


# ============ 代理管理 ============

def detect_proxy() -> str:
    """自动检测代理"""
    # 检查环境变量
    for env_var in ["HTTP_PROXY", "http_proxy", "HTTPS_PROXY", "https_proxy"]:
        proxy = os.getenv(env_var)
        if proxy:
            print(f"🌐 检测到代理：{env_var}={proxy}")
            return proxy
    
    # 检查代理池
    if PROXY_CONFIG["proxy_pool"]:
        import random
        proxy = random.choice(PROXY_CONFIG["proxy_pool"])
        print(f"🌐 从代理池选择：{proxy}")
        return proxy
    
    return None


def get_proxy() -> str:
    """获取当前代理"""
    # 手动配置优先
    if PROXY_CONFIG["manual_proxy"]:
        PROXY_CONFIG["current_proxy"] = PROXY_CONFIG["manual_proxy"]
        return PROXY_CONFIG["current_proxy"]
    
    # 自动检测
    if PROXY_CONFIG["auto_detect"]:
        PROXY_CONFIG["current_proxy"] = detect_proxy()
        return PROXY_CONFIG["current_proxy"]
    
    return None


def rotate_proxy():
    """轮换代理"""
    if PROXY_CONFIG["proxy_pool"]:
        import random
        old_proxy = PROXY_CONFIG["current_proxy"]
        PROXY_CONFIG["current_proxy"] = random.choice(PROXY_CONFIG["proxy_pool"])
        print(f"🔄 轮换代理：{old_proxy} → {PROXY_CONFIG['current_proxy']}")


def build_curl_args(proxy: str = None) -> list:
    """构建 curl 参数列表"""
    import random
    
    args = [
        "-s",  # 静默模式
        "-A", random.choice(USER_AGENTS),  # User-Agent 轮换
        "--connect-timeout", str(PROXY_CONFIG["proxy_timeout"]),
        "--max-time", "30",  # 总超时 30 秒
        "--retry", "2",  # 失败重试 2 次
        "--retry-delay", "1",  # 重试间隔 1 秒
        "-L",  # 跟随重定向
    ]
    
    # 添加代理
    if proxy:
        args.extend(["-x", proxy])
    
    # 添加 SSL 选项（跳过证书验证，用于开发环境）
    # 生产环境应该正确配置证书
    args.append("-k")
    
    return args


# ============ 抓取函数 ============

def load_cache():
    """加载缓存"""
    cache_file = CACHE_DIR / "articles.json"
    if not cache_file.exists():
        return None
    
    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        cache_time = datetime.fromisoformat(data['cached_at'])
        if datetime.now() - cache_time > timedelta(seconds=CACHE_EXPIRY_SECONDS):
            print("⚠️ 缓存已过期")
            return None
        
        return data['articles']
    except Exception as e:
        print(f"⚠️ 缓存加载失败：{e}")
        return None


def save_cache(articles):
    """保存缓存"""
    CACHE_DIR.mkdir(parents=True, exist_ok=True)
    cache_file = CACHE_DIR / "articles.json"
    
    try:
        data = {
            'cached_at': datetime.now().isoformat(),
            'articles': articles
        }
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        print(f"💾 已保存缓存 ({len(articles)} 条)")
    except Exception as e:
        print(f"⚠️ 缓存保存失败：{e}")


def fetch_rss(url: str, use_proxy: bool = True) -> list:
    """
    抓取 RSS 源（增强版）
    
    Args:
        url: RSS 地址
        use_proxy: 是否使用代理
    
    Returns:
        文章列表
    """
    proxy = get_proxy() if use_proxy else None
    
    print(f"   📡 RSS: {url}")
    if proxy:
        print(f"      代理：{proxy}")
    
    try:
        curl_args = build_curl_args(proxy)
        curl_args.append(url)
        
        result = subprocess.run(
            ["curl"] + curl_args,
            capture_output=True, text=True, timeout=35
        )
        
        if result.returncode != 0:
            print(f"      ⚠️ 请求失败：{result.stderr[:100]}")
            
            # 尝试直连（fallback）
            if use_proxy and PROXY_CONFIG["fallback_direct"]:
                print(f"      🔄 尝试直连...")
                return fetch_rss(url, use_proxy=False)
            
            return []
        
        if not result.stdout:
            print(f"      ⚠️ 无响应内容")
            return []
        
        articles = []
        # 解析 RSS XML
        items = re.findall(r'<item>(.*?)</item>', result.stdout, re.DOTALL)
        
        for item in items:
            try:
                title_match = re.search(r'<title>(.*?)</title>', item)
                link_match = re.search(r'<link>(.*?)</link>', item)
                pubdate_match = re.search(r'<pubDate>(.*?)</pubDate>', item)
                desc_match = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
                author_match = re.search(r'<author>(.*?)</author>', item)
                
                if title_match and link_match:
                    title = title_match.group(1)
                    link = link_match.group(1)
                    pubdate = pubdate_match.group(1) if pubdate_match else None
                    desc = desc_match.group(1) if desc_match else ""
                    author = author_match.group(1) if author_match else ""
                    
                    # 清理 HTML 标签
                    desc = re.sub(r'<[^>]+>', '', desc)
                    desc = desc[:300] + "..." if len(desc) > 300 else desc
                    
                    articles.append({
                        "title": title.strip(),
                        "link": link,
                        "pub_date": pubdate,
                        "summary": desc.strip(),
                        "author": author.strip(),
                        "source": url
                    })
            except Exception as e:
                continue
        
        print(f"      ✅ 获取 {len(articles)} 篇")
        return articles
    
    except subprocess.TimeoutExpired:
        print(f"      ⚠️ 请求超时 (35s)")
        return []
    except Exception as e:
        print(f"      ⚠️ 异常：{e}")
        
        # 尝试直连
        if use_proxy and PROXY_CONFIG["fallback_direct"]:
            print(f"      🔄 尝试直连...")
            return fetch_rss(url, use_proxy=False)
        
        return []


def fetch_web_articles(url: str, source_name: str, use_proxy: bool = True) -> list:
    """
    抓取网页文章列表（增强版）
    
    Args:
        url: 网站地址
        source_name: 来源名称
        use_proxy: 是否使用代理
    
    Returns:
        文章列表
    """
    proxy = get_proxy() if use_proxy else None
    
    print(f"   🌐 Web: {url} ({source_name})")
    if proxy:
        print(f"      代理：{proxy}")
    
    try:
        curl_args = build_curl_args(proxy)
        curl_args.append(url)
        
        result = subprocess.run(
            ["curl"] + curl_args,
            capture_output=True, text=True, timeout=35
        )
        
        if result.returncode != 0 or not result.stdout:
            print(f"      ⚠️ 请求失败")
            
            # 尝试直连
            if use_proxy and PROXY_CONFIG["fallback_direct"]:
                print(f"      🔄 尝试直连...")
                return fetch_web_articles(url, source_name, use_proxy=False)
            
            return []
        
        # 提取文章链接和标题（根据网站结构调整）
        articles = []
        matches = re.findall(r'<a[^>]+href="([^"]+)"[^>]*>([^<]+)</a>', result.stdout)
        
        for link, title in matches[:15]:
            if link.startswith('http') and len(title.strip()) > 10:
                articles.append({
                    "title": title.strip(),
                    "link": link,
                    "pub_date": None,
                    "summary": "",
                    "source": source_name
                })
        
        print(f"      ✅ 获取 {len(articles)} 篇")
        return articles
    
    except subprocess.TimeoutExpired:
        print(f"      ⚠️ 请求超时 (35s)")
        return []
    except Exception as e:
        print(f"      ⚠️ 异常：{e}")
        
        # 尝试直连
        if use_proxy and PROXY_CONFIG["fallback_direct"]:
            print(f"      🔄 尝试直连...")
            return fetch_web_articles(url, source_name, use_proxy=False)
        
        return []


def filter_recent_articles(articles: list, days: int = 3) -> list:
    """
    过滤近 N 天的文章
    
    Args:
        articles: 文章列表
        days: 天数
    
    Returns:
        过滤后的文章列表
    """
    recent = []
    cutoff_date = datetime.now() - timedelta(days=days)
    
    for article in articles:
        try:
            if article.get('pub_date'):
                # 尝试多种日期格式
                pub_date = None
                for fmt in ['%a, %d %b %Y %H:%M:%S %z', '%Y-%m-%d %H:%M:%S', '%Y-%m-%d']:
                    try:
                        pub_date = datetime.strptime(article['pub_date'], fmt)
                        break
                    except:
                        continue
                
                if pub_date and pub_date.replace(tzinfo=None) >= cutoff_date:
                    recent.append(article)
            else:
                # 没有日期的也加入（可能是最新文章）
                recent.append(article)
        except:
            recent.append(article)
    
    return recent


def get_articles(days: int = 3, limit: int = 10, use_proxy: bool = True) -> list:
    """
    获取公众号文章（增强版）
    
    Args:
        days: 近 N 天
        limit: 返回数量限制
        use_proxy: 是否使用代理
    
    Returns:
        文章列表
    """
    print(f"📰 抓取公众号文章（近{days}天，最多{limit}条）...")
    
    # 显示代理状态
    proxy = get_proxy() if use_proxy else None
    if proxy:
        print(f"🌐 使用代理：{proxy}")
    else:
        print(f"🌐 未使用代理（直连）")
    
    # 检查缓存
    cached = load_cache()
    if cached:
        print(f"✅ 使用缓存数据 ({len(cached)} 条)")
        return cached[:limit]
    
    all_articles = []
    
    for source in SOURCES:
        print(f"   抓取：{source['name']}...")
        
        articles = []
        
        if source['type'] == 'rss' and source.get('rss_url'):
            articles = fetch_rss(source['rss_url'], use_proxy)
        elif source['type'] == 'web' and source.get('web_url'):
            articles = fetch_web_articles(source['web_url'], source['name'], use_proxy)
        
        if articles:
            # 添加来源名称
            for article in articles:
                article['source_name'] = source['name']
                article['priority'] = source['priority']
            all_articles.extend(articles)
        else:
            print(f"      ⚠️ 获取失败")
    
    # 过滤近 N 天文章
    recent_articles = filter_recent_articles(all_articles, days)
    print(f"   近{days}天文章：{len(recent_articles)} 篇")
    
    # 按优先级排序（处理 None 值）
    def sort_key(article):
        priority = article.get('priority', 99)
        pub_date = article.get('pub_date') or ''
        return (priority, pub_date)
    
    recent_articles.sort(key=sort_key, reverse=True)  # 最新文章在前
    
    # 去重（按标题）
    seen_titles = set()
    unique_articles = []
    for article in recent_articles:
        title_hash = hash(article['title'])
        if title_hash not in seen_titles:
            seen_titles.add(title_hash)
            unique_articles.append(article)
    
    print(f"   去重后：{len(unique_articles)} 篇")
    
    # 保存缓存
    if unique_articles:
        save_cache(unique_articles)
    
    return unique_articles[:limit]


# ============ 命令行接口 ============

def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="微信公众号文章抓取工具 - 增强版")
    parser.add_argument("--days", type=int, default=3, help="近 N 天（默认：3）")
    parser.add_argument("--limit", type=int, default=10, help="返回数量限制（默认：10）")
    parser.add_argument("--no-proxy", action="store_true", help="不使用代理")
    parser.add_argument("--set-proxy", type=str, help="手动设置代理（格式：http://host:port）")
    parser.add_argument("--show-config", action="store_true", help="显示配置")
    parser.add_argument("--output", type=str, help="输出文件路径")
    
    args = parser.parse_args()
    
    # 显示配置
    if args.show_config:
        print("=== 微信 Scraper 配置 ===")
        print(f"缓存目录：{CACHE_DIR}")
        print(f"缓存过期：{CACHE_EXPIRY_SECONDS}秒")
        print(f"自动检测代理：{PROXY_CONFIG['auto_detect']}")
        print(f"手动代理：{PROXY_CONFIG['manual_proxy']}")
        print(f"代理池：{len(PROXY_CONFIG['proxy_pool'])} 个")
        print(f"失败后直连：{PROXY_CONFIG['fallback_direct']}")
        return
    
    # 设置代理
    if args.set_proxy:
        PROXY_CONFIG['manual_proxy'] = args.set_proxy
        print(f"✅ 已设置代理：{args.set_proxy}")
    
    # 获取文章
    articles = get_articles(
        days=args.days,
        limit=args.limit,
        use_proxy=not args.no_proxy
    )
    
    # 输出
    if args.output:
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(articles, f, ensure_ascii=False, indent=2)
        print(f"\n✅ 已保存到：{args.output}")
    else:
        print("\n" + "=" * 60)
        for i, article in enumerate(articles, 1):
            print(f"\n[{i}] {article['title']}")
            print(f"    来源：{article.get('source_name', '未知')}")
            print(f"    时间：{article.get('pub_date', '未知')}")
            print(f"    链接：{article.get('link', '')}")
            if article.get('summary'):
                print(f"    摘要：{article['summary'][:100]}...")


if __name__ == "__main__":
    main()
