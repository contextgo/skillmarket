#!/usr/bin/env python3
"""
RSS 源配置 - 更新后的可用 RSS 源列表

测试时间：2026-03-15 10:20
测试结果：
- ✅ 36 氪 (科技): 30 篇文章
- ✅ 量子位 (AI): 10 篇文章
- ⚠️ 华尔街见闻：200 OK 但无内容
- ⚠️ 东方财富：200 OK 但无内容
- ❌ 机器之心：404
- ❌ 新浪财经：404
"""

# 可用的 RSS 源列表（已验证）- 2026-03-15 更新
AVAILABLE_RSS_FEEDS = [
    {
        'name': '36 氪',
        'url': 'https://36kr.com/feed',
        'category': '科技',
        'priority': 1,  # 高优先级
        'status': 'active'
    },
    {
        'name': '量子位',
        'url': 'https://www.qbitai.com/feed',
        'category': 'AI',
        'priority': 1,  # 高优先级
        'status': 'active'
    },
    {
        'name': 'InfoQ',
        'url': 'https://www.infoq.cn/feed',
        'category': '科技',
        'priority': 1,  # 高优先级（20 篇文章）
        'status': 'active'
    },
    {
        'name': 'TechCrunch',
        'url': 'https://techcrunch.com/feed/',
        'category': '科技',
        'priority': 1,  # 高优先级（20 篇文章，国际源）
        'status': 'active'
    },
    {
        'name': '少数派',
        'url': 'https://sspai.com/feed',
        'category': '科技',
        'priority': 2,  # 中优先级（10 篇文章）
        'status': 'active'
    },
]

# 备用 RSS 源（需要进一步验证）
BACKUP_RSS_FEEDS = [
    {
        'name': '华尔街见闻',
        'url': 'https://wallstreetcn.com/feed',
        'category': '财经',
        'priority': 2,
        'status': 'unstable',  # 有时有内容，有时为空
        'note': '200 OK 但经常无内容'
    },
    {
        'name': '虎嗅',
        'url': 'https://www.huxiu.com/rss/1.xml',
        'category': '科技',
        'priority': 2,
        'status': 'untested'
    },
    {
        'name': '少数派',
        'url': 'https://sspai.com/feed',
        'category': '科技',
        'priority': 2,
        'status': 'untested'
    },
]

# 已失效的 RSS 源（暂时移除）
DEPRECATED_RSS_FEEDS = [
    {
        'name': '机器之心',
        'url': 'https://www.jiqizhixin.com/feed',
        'category': 'AI',
        'status': '404',
        'note': '返回 404 错误'
    },
    {
        'name': '新浪财经',
        'url': 'http://finance.sina.com.cn/stock/jsy/roll.xml',
        'category': '财经',
        'status': '404',
        'note': '返回 404 错误'
    },
    {
        'name': '东方财富',
        'url': 'http://news.eastmoney.com/rss/',
        'category': '财经',
        'status': 'empty',
        'note': '200 OK 但 RSS 解析无内容'
    },
]


def get_active_feeds(category=None):
    """获取活跃的 RSS 源"""
    feeds = [f for f in AVAILABLE_RSS_FEEDS if f['status'] == 'active']
    
    if category:
        feeds = [f for f in feeds if f['category'] == category]
    
    # 按优先级排序
    feeds.sort(key=lambda x: x['priority'])
    
    return feeds


def get_all_feeds(include_backup=True):
    """获取所有 RSS 源（包括备用）"""
    feeds = AVAILABLE_RSS_FEEDS.copy()
    
    if include_backup:
        feeds.extend(BACKUP_RSS_FEEDS)
    
    return feeds


# 测试函数
if __name__ == '__main__':
    import feedparser
    import requests
    
    print("🔍 重新验证 RSS 源...\n")
    
    for feed_info in AVAILABLE_RSS_FEEDS:
        url = feed_info['url']
        name = feed_info['name']
        
        try:
            response = requests.get(url, timeout=10, headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            })
            
            if response.status_code == 200:
                feed = feedparser.parse(response.content)
                entry_count = len(feed.entries)
                
                if entry_count > 0:
                    print(f"✅ {name}: {entry_count} 篇文章")
                else:
                    print(f"⚠️ {name}: 0 篇文章 (可能需要移除)")
            else:
                print(f"❌ {name}: HTTP {response.status_code}")
                
        except Exception as e:
            print(f"❌ {name}: {e}")
    
    print(f"\n📄 配置说明:")
    print(f"   活跃源：{len(AVAILABLE_RSS_FEEDS)} 个")
    print(f"   备用源：{len(BACKUP_RSS_FEEDS)} 个")
    print(f"   已移除：{len(DEPRECATED_RSS_FEEDS)} 个")
