#!/usr/bin/env python3
"""
Configure Cron Jobs for Hourly Broadcast
配置整点播报的 cron 任务（准备 + 发送）
"""

import json
import subprocess
import sys

# Cron 配置
PREPARE_CRON = {
    "name": "整点播报 - 准备阶段",
    "schedule": {
        "kind": "cron",
        "expr": "50 6-22 * * *",  # 每小时的第 50 分钟（6:50-22:50）
        "tz": "Asia/Shanghai"
    },
    "payload": {
        "kind": "agentTurn",
        "message": "prepare_next_broadcast",
        "timeoutSeconds": 600  # 10 分钟超时
    },
    "sessionTarget": "isolated",
    "enabled": True
}

SEND_CRON = {
    "name": "整点播报 - 发送阶段",
    "schedule": {
        "kind": "cron",
        "expr": "0 7-23 * * *",  # 整点（7:00-23:00）
        "tz": "Asia/Shanghai"
    },
    "payload": {
        "kind": "agentTurn",
        "message": "send_scheduled_broadcast",
        "timeoutSeconds": 300  # 5 分钟超时
    },
    "sessionTarget": "isolated",
    "enabled": True
}

def run_openclaw_command(command: str):
    """执行 openclaw 命令"""
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=30
        )
        return result.returncode == 0, result.stdout, result.stderr
    except Exception as e:
        return False, "", str(e)

def configure_cron():
    """配置 cron 任务"""
    print("🔧 开始配置整点播报 cron 任务...\n")
    
    # 检查是否已有旧的 cron 任务
    print("📋 检查现有 cron 任务...")
    success, stdout, stderr = run_openclaw_command("openclaw cron list")
    
    if success:
        print("✅ 当前 cron 任务列表:")
        print(stdout[:500] if stdout else "无任务")
        print()
    
    # 配置准备任务
    print("⏰ 配置准备任务（每小时 XX:50）...")
    prepare_json = json.dumps(PREPARE_CRON, ensure_ascii=False)
    cmd = f'openclaw cron add --job=\'{prepare_json}\''
    success, stdout, stderr = run_openclaw_command(cmd)
    
    if success:
        print("✅ 准备任务配置成功")
    else:
        print(f"⚠️ 准备任务配置失败：{stderr}")
    
    print()
    
    # 配置发送任务
    print("📻 配置发送任务（每小时 XX:00）...")
    send_json = json.dumps(SEND_CRON, ensure_ascii=False)
    cmd = f'openclaw cron add --job=\'{send_json}\''
    success, stdout, stderr = run_openclaw_command(cmd)
    
    if success:
        print("✅ 发送任务配置成功")
    else:
        print(f"⚠️ 发送任务配置失败：{stderr}")
    
    print()
    print("="*50)
    print("✅ cron 配置完成！")
    print("="*50)
    print("\n📅 任务 schedule:")
    print(f"  - 准备：{PREPARE_CRON['schedule']['expr']} (Asia/Shanghai)")
    print(f"  - 发送：{SEND_CRON['schedule']['expr']} (Asia/Shanghai)")
    print("\n💡 提示:")
    print("  - 准备任务会在 XX:50 自动执行，提前准备 XX+1:00 的播报内容")
    print("  - 发送任务会在 XX:00 自动执行，从缓存读取并发送播报")
    print("  - 如果缓存不存在或过期，会自动生成并发送")
    print()

if __name__ == "__main__":
    configure_cron()
