# 整点播报配置指南

## 📋 配置步骤

### 步骤 1：确认技能已安装 ✅
```bash
ls -la /home/admin/openclaw/workspace/skills/hourly-broadcast/
```

应包含以下文件：
- `SKILL.md` - 技能说明
- `broadcast.py` - 播报生成工具
- `README.md` - 使用说明
- `sample_data.json` - 示例数据

### 步骤 2：测试播报生成 ✅
```bash
cd /home/admin/openclaw/workspace/skills/hourly-broadcast

# 检查时间
python3 broadcast.py --check-time

# 生成示例播报
python3 broadcast.py --data sample_data.json --output test_broadcast.md

# 查看生成的内容
cat test_broadcast.md
```

### 步骤 3：配置定时任务（整点自动播报）

#### 方案 A：使用 OpenClaw Cron（推荐）

通过 OpenClaw 的 cron 功能配置整点播报任务：

```bash
# 配置每小时整点播报（07:00-01:00）
# 需要在 OpenClaw 中配置 cron job
```

Cron 配置示例（供参考）：
```json
{
  "name": "整点播报 - 07:00-01:00",
  "schedule": {
    "kind": "cron",
    "expr": "0 7-23 * * *"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "请生成当前整点的播报内容"
  },
  "sessionTarget": "main"
}
```

#### 方案 B：手动触发

在飞书中直接发送消息触发播报：
- "整点播报"
- "帮我播报一下"
- "今天市场怎么样"

### 步骤 4：配置数据自动化（可选）

#### 4.1 天气数据自动化
使用 weather skill 获取天气：
```bash
# 示例：查询北京天气
wttr.in/Beijing?format=j1
```

#### 4.2 行情数据自动化
使用 stock-query skill 获取行情：
```bash
# 获取 513100 实时行情
python3 ../stock-query/stock_query.py real-time 513100

# 获取 TQQQ 实时行情
python3 ../stock-query/stock_query.py real-time TQQQ
```

#### 4.3 新闻数据自动化
使用 web_fetch 获取新闻：
```bash
# 示例：从科技媒体获取新闻
# 需要配置 RSS 源或使用 web_fetch
```

### 步骤 5：配置网格策略数据（重要）

网格策略需要持久化保存，建议创建数据文件：

```bash
# 创建网格策略配置文件
cat > grid_strategy.json << 'EOF'
{
  "513100": {
    "grid_levels": 5,
    "price_range": [1.15, 1.35],
    "current_position": 60,
    "buy_prices": [1.20, 1.18, 1.16, 1.14, 1.12],
    "sell_prices": [1.24, 1.26, 1.28, 1.30, 1.32],
    "last_update": "2026-03-14T14:00:00+08:00"
  },
  "TQQQ": {
    "grid_levels": 5,
    "price_range": [60, 80],
    "current_position": 50,
    "buy_prices": [65, 63, 61, 59, 57],
    "sell_prices": [69, 71, 73, 75, 77],
    "last_update": "2026-03-14T14:00:00+08:00"
  }
}
EOF
```

## 🔧 自动化脚本示例

### 完整播报生成脚本

```python
#!/usr/bin/env python3
"""
自动播报生成脚本
获取天气、行情、新闻，生成完整播报
"""

import json
import subprocess
from datetime import datetime

def get_weather(city):
    """获取天气数据（示例）"""
    # 实际使用时调用 weather API
    return {
        "condition": "晴",
        "temp": "8°C ~ 18°C",
        "humidity": "35%",
        "wind": "2 级 西北风",
        "suggestion": "适合户外活动"
    }

def get_stock_price(symbol):
    """获取股票价格"""
    # 调用 stock-query skill
    result = subprocess.run(
        ["python3", "../stock-query/stock_query.py", "real-time", symbol],
        capture_output=True, text=True
    )
    return result.stdout

def generate_broadcast():
    """生成完整播报"""
    data = {
        "beijing_weather": get_weather("Beijing"),
        "shenzhen_weather": get_weather("Shenzhen"),
        "513100_price": get_stock_price("513100"),
        "tqqq_price": get_stock_price("TQQQ"),
        # ... 其他数据
    }
    
    # 生成播报
    result = subprocess.run(
        ["python3", "broadcast.py", "--data", json.dumps(data)],
        capture_output=True, text=True
    )
    
    return result.stdout

if __name__ == "__main__":
    broadcast = generate_broadcast()
    print(broadcast)
```

## ⚙️ OpenClaw 配置

### 在 AGENTS.md 中添加播报提醒

```markdown
## 整点播报

- **时间**: 每小时 00 分（07:00-01:00）
- **技能**: hourly-broadcast
- **模板**: https://www.feishu.cn/docx/QVVHda3nqoVDu0xwDyEcXNMpnph
- **流程**:
  1. XX:50 - 预加载数据
  2. XX:55 - 生成播报内容
  3. XX:00 - 发送播报
```

### 在 HEARTBEAT.md 中添加检查

```markdown
# 整点播报检查
- 检查当前时间是否在播报范围内（07:00-01:00）
- 如是整点，生成并发送播报
- 检查网格策略是否需要更新
```

## 📊 数据更新流程

### 整点播报完整流程

```
XX:50 - 开始准备
  │
  ├─→ 获取天气数据（北京、深圳）
  ├─→ 获取行情数据（513100、TQQQ）
  ├─→ 获取最新新闻（AI、财经）
  ├─→ 读取网格策略配置
  │
  ↓
XX:55 - 生成播报
  │
  ├─→ 填充模板
  ├─→ 计算时间段祝福语
  ├─→ 生成 Markdown 内容
  │
  ↓
XX:00 - 发送播报
  │
  ├─→ 发送到飞书
  ├─→ 记录播报日志
  └─→ 更新网格策略状态
```

## 🔍 故障排查

### 问题 1：播报未按时发送
**检查**:
```bash
# 检查是否在播报时间
python3 broadcast.py --check-time

# 检查 cron 配置
openclaw cron list
```

### 问题 2：数据获取失败
**解决**:
- 检查网络连接
- 切换数据源（AkShare ↔ YFinance）
- 使用联网搜索作为备选

### 问题 3：网格策略数据丢失
**解决**:
- 创建持久化配置文件
- 每次播报后更新状态
- 备份到云文档或 Git

## 📝 日常维护

### 每日检查
- [ ] 检查播报是否按时发送
- [ ] 验证数据准确性
- [ ] 更新网格策略状态

### 每周检查
- [ ] 检查新闻源是否有效
- [ ] 验证天气 API 是否正常
- [ ] 回顾播报质量，优化模板

### 每月检查
- [ ] 更新时间段祝福语
- [ ] 检查技能依赖是否最新
- [ ] 优化播报内容结构

## 📖 相关文档

- [技能说明](SKILL.md)
- [使用指南](README.md)
- [播报模板](https://www.feishu.cn/docx/QVVHda3nqoVDu0xwDyEcXNMpnph)
- [stock-query skill](../stock-query/README.md)
