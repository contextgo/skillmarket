# 📻 配置播报自动发送到飞书群

**最后更新**: 2026-03-14 17:33  
**状态**: ✅ 可配置

---

## 📋 当前配置

### Cron Jobs 状态

| 任务 | Schedule | 目标 | 状态 |
|------|----------|------|------|
| 准备阶段 | `50 6-22 * * *` | 个人 (ou_...) | ✅ 运行中 |
| 发送阶段 | `0 7-23 * * *` | 个人 (ou_...) | ✅ 运行中 |

### 当前发送目标

- **类型**: 个人私聊
- **User ID**: `ou_1774bc9ee21296e5a3466ed106a51f17`
- **频道**: Feishu

---

## 🎯 配置发送到飞书群

### 方案 A: 修改 broadcast.py (推荐)

**步骤 1: 获取群 ID**

```bash
# 方法 1: 从飞书群链接获取
# 群链接格式：https://app.feishu.cn/chat/CHAT_ID
# 例如：https://app.feishu.cn/chat/oc_a6c8d9e0f1b2c3d4

# 方法 2: 使用 feishu_chat 工具搜索
```

**步骤 2: 修改发送配置**

编辑 `~/openclaw/workspace/skills/hourly-broadcast/broadcast.py`

找到 `send_broadcast()` 函数中的发送部分：

```python
# 原配置（发送到个人）
result = subprocess.run(
    ["openclaw", "message", "send", 
     "--channel", "feishu",
     "--target", "ou_1774bc9ee21296e5a3466ed106a51f17",  # ← 个人 ID
     "--message", markdown],
    capture_output=True, text=True, timeout=30
)

# 修改为（发送到群）
result = subprocess.run(
    ["openclaw", "message", "send", 
     "--channel", "feishu",
     "--target", "oc_xxxxxxxxxxxxxxxx",  # ← 改为群 ID
     "--message", markdown],
    capture_output=True, text=True, timeout=30
)
```

**步骤 3: 测试发送**

```bash
cd ~/openclaw/workspace/skills/hourly-broadcast
python3 broadcast.py --send 17 --force
```

---

### 方案 B: 使用配置文件 (灵活)

**步骤 1: 创建配置文件**

创建 `~/openclaw/workspace/skills/hourly-broadcast/broadcast_config.json`:

```json
{
  "delivery": {
    "channel": "feishu",
    "target_type": "chat",
    "target_id": "oc_a6c8d9e0f1b2c3d4",
    "fallback_target": "ou_1774bc9ee21296e5a3466ed106a51f17"
  },
  "schedule": {
    "timezone": "Asia/Shanghai",
    "prepare_minute": 50,
    "send_hours": "7-23"
  },
  "content": {
    "include_weather": true,
    "include_stock": true,
    "include_news": true,
    "stock_symbols": ["513100", "TQQQ"]
  }
}
```

**步骤 2: 修改 broadcast.py 读取配置**

在 `send_broadcast()` 函数开头添加：

```python
# 加载配置
config_path = os.path.join(os.path.dirname(__file__), 'broadcast_config.json')
if os.path.exists(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
        config = json.load(f)
    
    target = config['delivery']['target_id']
    channel = config['delivery']['channel']
else:
    # 默认配置
    target = "ou_1774bc9ee21296e5a3466ed106a51f17"
    channel = "feishu"
```

**步骤 3: 修改发送命令**

```python
result = subprocess.run(
    ["openclaw", "message", "send", 
     "--channel", channel,
     "--target", target,
     "--message", markdown],
    capture_output=True, text=True, timeout=30
)
```

---

### 方案 C: 更新 Cron Job 配置 (最简单)

**步骤 1: 查看当前 Cron Jobs**

```bash
openclaw cron list
```

**步骤 2: 删除旧的 Cron Jobs**

```bash
# 删除准备任务
openclaw cron remove --job-id d06f6b4a-15b6-4870-ad61-edd7ea341f81

# 删除发送任务
openclaw cron remove --job-id 0297ba59-f6b4-467b-97f3-509f972430ad
```

**步骤 3: 创建新的 Cron Jobs（带群配置）**

```bash
# 准备任务
openclaw cron add --job='{
  "name": "整点播报 - 准备阶段",
  "schedule": {
    "kind": "cron",
    "expr": "50 6-22 * * *",
    "tz": "Asia/Shanghai"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "prepare_next_broadcast",
    "timeoutSeconds": 600
  },
  "sessionTarget": "isolated",
  "delivery": {
    "mode": "announce",
    "to": "oc_a6c8d9e0f1b2c3d4",
    "channel": "feishu"
  }
}'

# 发送任务
openclaw cron add --job='{
  "name": "整点播报 - 发送阶段",
  "schedule": {
    "kind": "cron",
    "expr": "0 7-23 * * *",
    "tz": "Asia/Shanghai"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "send_scheduled_broadcast",
    "timeoutSeconds": 300
  },
  "sessionTarget": "isolated",
  "delivery": {
    "mode": "announce",
    "to": "oc_a6c8d9e0f1b2c3d4",
    "channel": "feishu"
  }
}'
```

---

## 🔍 获取飞书群 ID 的方法

### 方法 1: 从群链接获取

1. 打开飞书群
2. 点击右上角「...」
3. 选择「复制链接」
4. 链接格式：`https://app.feishu.cn/chat/oc_a6c8d9e0f1b2c3d4`
5. `oc_a6c8d9e0f1b2c3d4` 就是群 ID

### 方法 2: 使用 feishu_chat 工具搜索

```bash
# 搜索群
openclaw feishu chat search --query="群名称关键词"
```

### 方法 3: 使用 feishu_chat_members 工具

如果你知道群里的某个成员：

```python
# 通过成员查找群（需要知道群 ID）
```

---

## 📝 完整配置示例

### 配置文件 (`broadcast_config.json`)

```json
{
  "delivery": {
    "channel": "feishu",
    "target_type": "chat",
    "target_id": "oc_a6c8d9e0f1b2c3d4",
    "fallback_target": "ou_1774bc9ee21296e5a3466ed106a51f17",
    "mention_users": [],
    "reply_to_thread": false
  },
  "schedule": {
    "timezone": "Asia/Shanghai",
    "prepare_minute": 50,
    "send_hours": "7-23",
    "quiet_hours": "1-6"
  },
  "content": {
    "include_weather": true,
    "include_stock": true,
    "include_news": true,
    "stock_symbols": ["513100", "TQQQ"],
    "weather_cities": ["北京", "深圳"],
    "news_sources": ["wallstreetcn", "36kr", "hackernews"]
  },
  "format": {
    "use_markdown": true,
    "use_tables": true,
    "max_news_items": 5,
    "include_timestamp": true
  }
}
```

### Cron Job 配置

```json
{
  "name": "整点播报 - 发送阶段",
  "schedule": {
    "kind": "cron",
    "expr": "0 7-23 * * *",
    "tz": "Asia/Shanghai"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "send_scheduled_broadcast",
    "timeoutSeconds": 300
  },
  "sessionTarget": "isolated",
  "delivery": {
    "mode": "announce",
    "to": "oc_a6c8d9e0f1b2c3d4",
    "channel": "feishu"
  }
}
```

---

## ✅ 测试步骤

### 1. 测试配置文件

```bash
cd ~/openclaw/workspace/skills/hourly-broadcast
python3 -c "import json; print(json.load(open('broadcast_config.json')))"
```

### 2. 手动发送测试

```bash
python3 broadcast.py --send 17 --force
```

### 3. 检查 Cron Jobs

```bash
openclaw cron list
```

### 4. 查看播报历史

```bash
ls -la cache/
cat cache/17_00.json
```

---

## 🚀 快速配置脚本

创建 `configure_feishu_group.py`:

```python
#!/usr/bin/env python3
"""
配置播报发送到飞书群
"""

import json
import subprocess
import sys

def get_group_id():
    """获取群 ID"""
    group_id = input("请输入飞书群 ID (oc_xxxxxxxxxxxxxxxx): ")
    if not group_id.startswith("oc_"):
        print("❌ 群 ID 格式错误，应该以 oc_ 开头")
        sys.exit(1)
    return group_id

def update_config(group_id):
    """更新配置文件"""
    config = {
        "delivery": {
            "channel": "feishu",
            "target_type": "chat",
            "target_id": group_id,
            "fallback_target": "ou_1774bc9ee21296e5a3466ed106a51f17"
        }
    }
    
    config_path = "broadcast_config.json"
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 配置文件已更新：{config_path}")

def update_cron(group_id):
    """更新 Cron Job"""
    # 删除旧的
    print("🗑️  删除旧的 Cron Jobs...")
    subprocess.run("openclaw cron remove --job-id d06f6b4a-15b6-4870-ad61-edd7ea341f81", shell=True)
    subprocess.run("openclaw cron remove --job-id 0297ba59-f6b4-467b-97f3-509f972430ad", shell=True)
    
    # 创建新的
    print("⏰ 创建新的 Cron Jobs...")
    
    send_job = {
        "name": "整点播报 - 发送阶段",
        "schedule": {
            "kind": "cron",
            "expr": "0 7-23 * * *",
            "tz": "Asia/Shanghai"
        },
        "payload": {
            "kind": "agentTurn",
            "message": "send_scheduled_broadcast",
            "timeoutSeconds": 300
        },
        "sessionTarget": "isolated",
        "delivery": {
            "mode": "announce",
            "to": group_id,
            "channel": "feishu"
        }
    }
    
    cmd = f"openclaw cron add --job='{json.dumps(send_job, ensure_ascii=False)}'"
    subprocess.run(cmd, shell=True)
    
    print("✅ Cron Jobs 已更新")

if __name__ == "__main__":
    print("📻 配置播报发送到飞书群\n")
    
    group_id = get_group_id()
    update_config(group_id)
    update_cron(group_id)
    
    print("\n✅ 配置完成！")
    print(f"📤 播报将发送到群：{group_id}")
    print("⏰ 下次播报时间：下一个整点")
```

运行：

```bash
cd ~/openclaw/workspace/skills/hourly-broadcast
python3 configure_feishu_group.py
```

---

## 📊 配置对比

| 配置项 | 个人私聊 | 飞书群 |
|--------|----------|--------|
| Target ID | `ou_xxxxx` | `oc_xxxxx` |
| 可见范围 | 仅自己 | 群成员 |
| 互动性 | 低 | 高（可讨论） |
| 适用场景 | 个人监控 | 团队共享 |

---

## ⚠️ 注意事项

1. **群权限**: 确保机器人有发送消息的权限
2. **消息频率**: 整点播报较频繁，避免打扰群成员
3. **静默时间**: 配置 `quiet_hours` 避免夜间发送
4. **备用方案**: 保留 `fallback_target` 用于测试

---

## 🔧 故障排查

### Q: 消息发送失败？
A: 检查：
- 群 ID 是否正确
- 机器人是否有群权限
- 飞书 OAuth 是否过期

### Q: Cron Job 不执行？
A: 检查：
```bash
openclaw cron status
openclaw cron list
```

### Q: 消息格式错误？
A: 检查 Markdown 格式，避免特殊字符

---

**需要我帮你执行配置吗？请提供飞书群 ID！** 🚀
