#!/usr/bin/env python3
"""
超时检测与汇报工具
当播报超时时主动通知用户并提供优化方案
"""

import json
from datetime import datetime
from pathlib import Path

# 超时配置
TIMEOUT_SECONDS = 600  # 10 分钟
WARNING_THRESHOLD = 400  # 超过 6 分 40 秒发出警告

# 汇报模板
TIMEOUT_REPORT_TEMPLATE = """
# ⚠️ 整点播报超时提醒

**播报时间**: {broadcast_time}  
**超时时长**: {duration_text}  
**超时原因**: {reason}

---

## 🔍 原因分析

{analysis}

---

## 💡 优化方案

{optimization_plans}

---

## 💬 请确认

**选择哪个方案？**
- A) {option_a}
- B) {option_b}
- C) 保持现状

**回复 A/B/C 或提出其他建议**
"""


def analyze_timeout_reason(duration_seconds: int, error_message: str = "") -> str:
    """分析超时原因"""
    
    reasons = []
    
    if duration_seconds >= TIMEOUT_SECONDS:
        reasons.append("1. **执行时间超过限制** ({:.1f}分钟 > {}分钟)".format(
            duration_seconds / 60, TIMEOUT_SECONDS // 60))
    
    if "AkShare" in error_message or "stock" in error_message.lower():
        reasons.append("2. **股票数据获取慢** - AkShare 全市场扫描耗时较长")
    
    if "news" in error_message.lower() or "fetch" in error_message.lower():
        reasons.append("3. **新闻抓取超时** - 微信公众号抓取可能遇到反爬")
    
    if "weather" in error_message.lower():
        reasons.append("4. **天气 API 延迟** - wttr.in 响应慢")
    
    if "session" in error_message.lower():
        reasons.append("5. **Session 启动慢** - isolated session 初始化耗时")
    
    if not reasons:
        reasons.append("1. **未知原因** - 需要进一步排查日志")
        reasons.append("2. **可能原因**: 网络延迟、API 限流、数据量大")
    
    return "\n".join(reasons)


def generate_optimization_plans(duration_seconds: int) -> tuple:
    """生成优化方案"""
    
    plans = {
        "A": {
            "title": "优化数据获取",
            "details": [
                "- 并行获取天气、行情、新闻（预计减少 40% 时间）",
                "- 增加数据缓存（股票 5 分钟、新闻 30 分钟）",
                "- 减少 AkShare 全量扫描，改用定点查询"
            ],
            "estimated_saving": "50-60%",
            "effort": "中"
        },
        "B": {
            "title": "简化播报内容",
            "details": [
                "- 保留核心：天气 + 行情（必须）",
                "- 简化新闻：1 条摘要（可选）",
                "- 移除网格策略详细数据（可选）"
            ],
            "estimated_saving": "30-40%",
            "effort": "低"
        },
        "C": {
            "title": "调整播报频率",
            "details": [
                "- 改为关键时段播报（09:00/12:00/15:00/20:00）",
                "- 每日 4 次代替每小时 1 次",
                "- 减少 76% 的执行次数"
            ],
            "estimated_saving": "76% (总执行时间)",
            "effort": "低"
        },
        "D": {
            "title": "增加超时时间",
            "details": [
                "- 当前：600 秒 (10 分钟)",
                "- 建议：900 秒 (15 分钟)",
                "- 简单但非根本解决方案"
            ],
            "estimated_saving": "0% (仅延长容忍度)",
            "effort": "极低"
        }
    }
    
    return plans


def format_duration(seconds: int) -> str:
    """格式化时长"""
    minutes = seconds // 60
    secs = seconds % 60
    return f"{minutes}分{secs}秒"


def generate_timeout_report(duration_seconds: int, error_message: str = "", broadcast_time: str = None) -> str:
    """生成超时汇报"""
    
    if broadcast_time is None:
        broadcast_time = datetime.now().strftime('%Y-%m-%d %H:%M')
    
    # 分析原因
    analysis = analyze_timeout_reason(duration_seconds, error_message)
    
    # 生成优化方案
    plans = generate_optimization_plans(duration_seconds)
    
    # 格式化方案
    plans_text = []
    for key, plan in plans.items():
        plan_text = f"**{key}) {plan['title']}** (预计节省 {plan['estimated_saving']}, 工作量：{plan['effort']})\n"
        for detail in plan['details']:
            plan_text += f"  {detail}\n"
        plans_text.append(plan_text)
    
    # 填充模板
    report = TIMEOUT_REPORT_TEMPLATE.format(
        broadcast_time=broadcast_time,
        duration_text=format_duration(duration_seconds),
        reason="执行时间超过限制" if duration_seconds >= TIMEOUT_SECONDS else "接近超时阈值",
        analysis=analysis,
        optimization_plans="\n".join(plans_text),
        option_a=plans['A']['title'],
        option_b=plans['B']['title']
    )
    
    return report


def check_and_report(execution_log_path: str = None):
    """检查执行日志并汇报超时"""
    
    # 这里可以读取 cron 执行日志
    # 简化版本：直接返回报告生成函数
    
    print("超时检测与汇报工具已就绪")
    print("用法：在 cron 错误处理中调用 generate_timeout_report()")
    
    return generate_timeout_report


if __name__ == "__main__":
    # 测试
    report = generate_timeout_report(650, "cron: job execution timed out")
    print(report)
