#!/usr/bin/env python3
"""
News Aggregator - 简化版新闻聚合器
使用现有技能组合（multi-search-engine + web-fetcher）实现类似 news-aggregator 的功能

信源：
- 搜索引擎：Google/Bing/百度/搜狗/360（17 个）
- RSS 源：机器之心/36 氪/虎嗅/华尔街见闻
- 微信公众号：量子位/36 氪/钛媒体（已集成在 broadcast.py）

使用方法:
    python3 news_aggregator.py --source hackernews,github,wallstreetcn --keyword AI,Agent --limit 10
    python3 news_aggregator.py --source rss --keyword 大模型 --limit 5 --deep
"""

import argparse
import json
import subprocess
import urllib.request
import urllib.parse
from datetime import datetime, timedelta
from pathlib import Path
import re

# 尝试导入依赖
try:
    import feedparser
    HAS_FEEDPARSER = True
except ImportError:
    HAS_FEEDPARSER = False
    print("⚠️ 缺少依赖：feedparser")
    print("请运行：pip install feedparser")

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False
    print("⚠️ 缺少依赖：requests")
    print("请运行：pip install requests")


# ============ 配置 ============

# RSS 源列表（2026-03-15 10:48 更新）
RSS_FEEDS = {
    # ✅ 已验证可用（高优先级）
    "36kr": "https://36kr.com/feed",  # 36 氪（科技）- 30 篇文章
    "qbitai": "https://www.qbitai.com/feed",  # 量子位（AI）- 10 篇文章
    "infoq": "https://www.infoq.cn/feed",  # InfoQ（科技）- 20 篇文章
    "techcrunch": "https://techcrunch.com/feed/",  # TechCrunch（科技）- 20 篇文章
    
    # ✅ 可用（中优先级）
    "sspai": "https://sspai.com/feed",  # 少数派（科技）- 10 篇文章
    
    # ⚠️ 不稳定（有时有内容）
    "wallstreetcn": "https://www.wallstreetcn.com/feed",  # 华尔街见闻（财经）
    
    # ⏳ 待测试/备用
    "huggingface": "https://huggingface.co/blog/feed.xml",  # HF Blog
    "benbites": "https://benbites.substack.com/feed",  # Ben's Bites
    
    # ❌ 已失效（保留但可能返回 404）
    "jiqizhixin": "https://www.jiqizhixin.com/rss",  # 机器之心（AI）- 404
    "huxiu": "https://www.huxiu.com/rss.php",  # 虎嗅（科技）- 404
}

# 搜索引擎列表（来自 multi-search-engine）
SEARCH_ENGINES = [
    "google", "bing", "baidu", "sogou", "360",
    "github", "hackernews", "v2ex", "zhihu"
]

# 关键词扩展映射
KEYWORD_EXPANSION = {
    "AI": "AI,LLM,GPT,Agent,RAG，大模型，人工智能，机器学习",
    "Agent": "Agent,智能体，多 Agent,Agent 协作，AutoGen，LangChain",
    "机器人": "机器人，具身智能，人形机器人，机器人技术",
    "科技": "科技，互联网，数码，电子产品",
}


# ============ 核心功能 ============

def expand_keywords(keywords: str) -> str:
    """扩展关键词"""
    if not keywords:
        return ""
    
    expanded = []
    for kw in keywords.split(","):
        kw = kw.strip()
        if kw in KEYWORD_EXPANSION:
            expanded.append(KEYWORD_EXPANSION[kw])
        else:
            expanded.append(kw)
    
    return ",".join(expanded)


def fetch_rss_news(source: str, keyword: str = None, limit: int = 10) -> list:
    """从 RSS 源获取新闻"""
    if not HAS_FEEDPARSER:
        print("⚠️ feedparser 未安装，跳过 RSS 抓取")
        return []
    
    if source not in RSS_FEEDS:
        print(f"⚠️ 未知的 RSS 源：{source}")
        return []
    
    url = RSS_FEEDS[source]
    print(f"📰 抓取 RSS: {source} ({url})")
    
    try:
        feed = feedparser.parse(url)
        articles = []
        
        for entry in feed.entries[:limit * 2]:  # 多抓一些用于过滤
            title = entry.get("title", "")
            summary = entry.get("summary", "")
            link = entry.get("link", "")
            pub_date = entry.get("published", "")
            
            # 关键词过滤
            if keyword:
                keyword_matched = False
                for kw in keyword.split(","):
                    if kw.strip().lower() in title.lower() or kw.strip().lower() in summary.lower():
                        keyword_matched = True
                        break
                if not keyword_matched:
                    continue
            
            articles.append({
                "title": title,
                "summary": summary[:200] if summary else "",
                "link": link,
                "source": source,
                "pub_date": pub_date[:10] if pub_date else "",
                "content": ""
            })
            
            if len(articles) >= limit:
                break
        
        print(f"✅ {source}: 获取 {len(articles)} 篇")
        return articles
    
    except Exception as e:
        print(f"❌ {source} 失败：{e}")
        return []


def fetch_search_news(source: str, keyword: str, limit: int = 10) -> list:
    """从搜索引擎获取新闻"""
    print(f"🔍 搜索：{source} - {keyword}")
    
    # 调用 multi-search-engine
    try:
        cmd = [
            "python3",
            "/home/admin/openclaw/workspace/skills/multi-search-engine/search.py",
            "--engine", source,
            "--query", keyword,
            "--limit", str(limit)
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            # 解析搜索结果（假设输出 JSON）
            try:
                data = json.loads(result.stdout)
                articles = []
                for item in data.get("results", []):
                    articles.append({
                        "title": item.get("title", ""),
                        "summary": item.get("snippet", ""),
                        "link": item.get("url", ""),
                        "source": source,
                        "pub_date": "",
                        "content": ""
                    })
                print(f"✅ {source}: 获取 {len(articles)} 篇")
                return articles
            except json.JSONDecodeError:
                print(f"⚠️ {source} 输出非 JSON 格式")
                return []
        else:
            print(f"❌ {source} 失败：{result.stderr}")
            return []
    
    except Exception as e:
        print(f"❌ {source} 异常：{e}")
        return []


def fetch_deep_content(url: str) -> str:
    """深度抓取正文内容"""
    print(f"📄 深度抓取：{url}")
    
    try:
        cmd = [
            "python3",
            "/home/admin/openclaw/workspace/skills/web-fetcher/web_fetcher.py",
            url,
            "--strategy", "markdown.new"
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        
        if result.returncode == 0:
            # 提取正文（去掉标题等元数据）
            content = result.stdout
            # 简单清理
            content = re.sub(r'^#+ .*$', '', content, flags=re.MULTILINE)
            content = content.strip()[:2000]  # 限制长度
            return content
        else:
            print(f"⚠️ 深度抓取失败")
            return ""
    
    except Exception as e:
        print(f"❌ 深度抓取异常：{e}")
        return ""


def aggregate_news(sources: list, keyword: str = None, limit: int = 10, deep: bool = False) -> list:
    """聚合多源新闻"""
    all_articles = []
    
    # 扩展关键词
    expanded_keyword = expand_keywords(keyword) if keyword else ""
    
    for source in sources:
        articles = []
        
        # RSS 源
        if source in RSS_FEEDS:
            articles = fetch_rss_news(source, expanded_keyword, limit)
        
        # 搜索引擎
        elif source in SEARCH_ENGINES:
            articles = fetch_search_news(source, expanded_keyword, limit)
        
        # 未知源
        else:
            print(f"⚠️ 未知源：{source}")
            continue
        
        all_articles.extend(articles)
    
    # 去重（按标题）
    seen = set()
    unique_articles = []
    for article in all_articles:
        title_hash = hash(article["title"])
        if title_hash not in seen:
            seen.add(title_hash)
            unique_articles.append(article)
    
    # 深度抓取
    if deep and HAS_REQUESTS:
        print("📖 开始深度抓取正文...")
        for article in unique_articles[:5]:  # 只抓取前 5 篇
            if article["link"]:
                content = fetch_deep_content(article["link"])
                if content:
                    article["content"] = content
    
    # 限制数量
    return unique_articles[:limit]


def generate_report(articles: list, format: str = "json") -> str:
    """生成报告"""
    if format == "json":
        return json.dumps(articles, ensure_ascii=False, indent=2)
    
    elif format == "markdown":
        md = f"# 新闻聚合报告\n\n"
        md += f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        md += f"**文章数量**: {len(articles)}\n\n"
        md += "---\n\n"
        
        for i, article in enumerate(articles, 1):
            md += f"## {i}. {article['title']}\n\n"
            md += f"**来源**: {article['source']}\n"
            if article['pub_date']:
                md += f"**时间**: {article['pub_date']}\n"
            md += f"**链接**: {article['link']}\n\n"
            if article['summary']:
                md += f"**摘要**: {article['summary']}\n\n"
            if article['content']:
                md += f"**正文**: {article['content'][:500]}...\n\n"
            md += "---\n\n"
        
        return md
    
    else:
        return str(articles)


# ============ 命令行接口 ============

def main():
    parser = argparse.ArgumentParser(description="News Aggregator - 简化版新闻聚合器")
    parser.add_argument("--source", type=str, default="jiqizhixin,36kr",
                        help="信源列表，逗号分隔 (默认：jiqizhixin,36kr)")
    parser.add_argument("--keyword", type=str, default="AI,Agent",
                        help="关键词，逗号分隔 (默认：AI,Agent)")
    parser.add_argument("--limit", type=int, default=10,
                        help="每源最大文章数 (默认：10)")
    parser.add_argument("--deep", action="store_true",
                        help="启用深度抓取正文")
    parser.add_argument("--format", type=str, default="json",
                        choices=["json", "markdown"],
                        help="输出格式 (默认：json)")
    parser.add_argument("--output", type=str,
                        help="输出文件路径 (默认：stdout)")
    
    args = parser.parse_args()
    
    # 解析信源
    sources = [s.strip() for s in args.source.split(",")]
    
    print(f"🚀 开始聚合新闻...")
    print(f"   信源：{', '.join(sources)}")
    print(f"   关键词：{args.keyword}")
    print(f"   限制：{args.limit} 篇/源")
    print(f"   深度抓取：{'是' if args.deep else '否'}")
    print()
    
    # 聚合新闻
    articles = aggregate_news(
        sources=sources,
        keyword=args.keyword,
        limit=args.limit,
        deep=args.deep
    )
    
    # 生成报告
    report = generate_report(articles, args.format)
    
    # 输出
    if args.output:
        Path(args.output).write_text(report, encoding="utf-8")
        print(f"\n✅ 已保存到：{args.output}")
    else:
        print("\n" + "=" * 60 + "\n")
        print(report)
    
    print(f"\n📊 总计：{len(articles)} 篇")


if __name__ == "__main__":
    main()
