#!/usr/bin/env python3
"""
数据置信度可视化仪表盘
显示趋势、统计和改进建议
"""

import json
from datetime import datetime, timedelta
from pathlib import Path

TRACKING_FILE = Path("/home/admin/openclaw/workspace/skills/hourly-broadcast/analytics/quality_log.jsonl")

def load_data(days: int = 7):
    """加载最近 N 天的数据"""
    if not TRACKING_FILE.exists():
        return []
    
    records = []
    cutoff = datetime.now() - timedelta(days=days)
    
    with open(TRACKING_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            record = json.loads(line)
            record_time = datetime.fromisoformat(record['timestamp'])
            if record_time >= cutoff:
                records.append(record)
    
    return records

def show_dashboard():
    """显示仪表盘"""
    records = load_data(7)
    
    if not records:
        print("📊 数据置信度仪表盘")
        print("=" * 50)
        print("⚠️ 暂无数据，开始播报后自动记录")
        return
    
    print("📊 数据置信度仪表盘")
    print("=" * 50)
    print(f"统计周期：最近 7 天")
    print(f"播报次数：{len(records)} 次")
    print()
    
    # 计算平均置信度
    avg_conf = sum(r['avg_confidence'] for r in records) / len(records)
    print(f"平均置信度：{avg_conf:.1f}% (目标 >80%)")
    print()
    
    # 各数据源平均
    weather_avg = sum(r['data_sources']['weather']['confidence'] for r in records) / len(records)
    news_avg = sum(r['data_sources']['news']['confidence'] for r in records) / len(records)
    stock_513100_avg = sum(r['data_sources']['513100']['confidence'] for r in records) / len(records)
    stock_tqqq_avg = sum(r['data_sources']['TQQQ']['confidence'] for r in records) / len(records)
    
    print("📈 各数据源平均置信度:")
    print(f"  天气：{weather_avg:.1f}% {'✅' if weather_avg >= 90 else '⚠️'}")
    print(f"  新闻：{news_avg:.1f}% {'✅' if news_avg >= 90 else '⚠️'}")
    print(f"  513100: {stock_513100_avg:.1f}% {'✅' if stock_513100_avg >= 80 else '❌'}")
    print(f"  TQQQ: {stock_tqqq_avg:.1f}% {'✅' if stock_tqqq_avg >= 80 else '❌'}")
    print()
    
    # 趋势分析
    if len(records) >= 2:
        first_half = records[:len(records)//2]
        second_half = records[len(records)//2:]
        
        first_avg = sum(r['avg_confidence'] for r in first_half) / len(first_half)
        second_avg = sum(r['avg_confidence'] for r in second_half) / len(second_half)
        
        trend = "📈 上升" if second_avg > first_avg else "📉 下降" if second_avg < first_avg else "➡️ 持平"
        change = second_avg - first_avg
        
        print(f"📊 趋势：{trend} ({change:+.1f}%)")
        print(f"  前半段：{first_avg:.1f}%")
        print(f"  后半段：{second_avg:.1f}%")
        print()
    
    # 最近 5 次播报
    print("📋 最近 5 次播报:")
    for record in records[-5:]:
        time = datetime.fromisoformat(record['timestamp']).strftime('%m-%d %H:%M')
        conf = record['avg_confidence']
        status = "✅" if conf >= 80 else "⚠️" if conf >= 50 else "❌"
        print(f"  {time} {status} {conf:.1f}%")
    
    print()
    print("=" * 50)
    
    # 改进建议
    if avg_conf < 50:
        print("🔴 紧急：平均置信度偏低，需立即优化股票数据源")
        print("建议:")
        print("  1. 配置 HTTP 代理 (解锁 AkShare/YFinance)")
        print("  2. 配置 Tushare API (备选方案)")
        print("  3. 集成 a-stock-analysis (新浪财经)")
    elif avg_conf < 80:
        print("🟡 注意：置信度接近目标，继续努力")
        print("建议:")
        print("  1. 优化股票数据源")
        print("  2. 实施多源验证")
    else:
        print("🟢 优秀：置信度达标！保持当前策略")

if __name__ == "__main__":
    show_dashboard()
