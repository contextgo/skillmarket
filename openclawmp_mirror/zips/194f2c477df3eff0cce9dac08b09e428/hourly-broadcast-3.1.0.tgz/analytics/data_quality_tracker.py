#!/usr/bin/env python3
"""
数据质量追踪器 - 记录每次播报的数据置信度
用于长期趋势分析和优化效果验证
"""

import json
from datetime import datetime
from pathlib import Path

TRACKING_FILE = Path("/home/admin/openclaw/workspace/skills/hourly-broadcast/analytics/quality_log.jsonl")

def log_quality(broadcast_id: str, data_quality: dict, runtime: int = 0, tokens: int = 0):
    """记录单次播报的数据质量"""
    
    confidence_map = {
        "L1": 95, "L2": 90, "L3": 70, "L4": 60, "L5_default": 10,
        "L1_cache": 90, "L2_rss": 70, "L3_web": 60, "L4_manual": 95
    }
    
    record = {
        "timestamp": datetime.now().isoformat(),
        "broadcast_id": broadcast_id,
        "runtime": runtime,
        "tokens": tokens,
        "data_sources": {
            "weather": {
                "confidence": 95,
                "source": "wttr.in",
                "level": data_quality.get("weather", "L1")
            },
            "news": {
                "confidence": confidence_map.get(data_quality.get("news", "L1"), 95),
                "source": data_quality.get("news_source", "newsnow-reader"),
                "level": data_quality.get("news", "L1")
            },
            "513100": {
                "confidence": confidence_map.get(data_quality.get("513100", "L5_default"), 10),
                "source": data_quality.get("513100_source", "L5_default"),
                "level": data_quality.get("513100", "L5_default")
            },
            "TQQQ": {
                "confidence": confidence_map.get(data_quality.get("TQQQ", "L5_default"), 10),
                "source": data_quality.get("TQQQ_source", "L5_default"),
                "level": data_quality.get("TQQQ", "L5_default")
            }
        },
        "avg_confidence": calculate_avg(data_quality)
    }
    
    # 追加到 JSONL 文件
    with open(TRACKING_FILE, 'a', encoding='utf-8') as f:
        f.write(json.dumps(record, ensure_ascii=False) + '\n')
    
    print(f"✅ 数据质量已记录：{broadcast_id}, 平均置信度：{record['avg_confidence']:.1f}%")
    return record


def calculate_avg(data_quality: dict) -> float:
    """计算平均置信度"""
    confidence_map = {
        "L1": 95, "L2": 90, "L3": 70, "L4": 60, "L5_default": 10
    }
    
    confidences = [
        95,  # weather
        confidence_map.get(data_quality.get("news", "L1"), 95),
        confidence_map.get(data_quality.get("513100", "L5_default"), 10),
        confidence_map.get(data_quality.get("TQQQ", "L5_default"), 10)
    ]
    
    return sum(confidences) / len(confidences)


def get_trend(days: int = 7):
    """获取最近 N 天的趋势"""
    if not TRACKING_FILE.exists():
        return "暂无数据"
    
    records = []
    with open(TRACKING_FILE, 'r', encoding='utf-8') as f:
        for line in f:
            records.append(json.loads(line))
    
    if not records:
        return "暂无数据"
    
    # 计算平均趋势
    recent = records[-days*24:]  # 每小时一次，最多 24 次/天
    avg_conf = sum(r['avg_confidence'] for r in recent) / len(recent)
    
    return f"最近{days}天平均置信度：{avg_conf:.1f}% (共{len(recent)}次播报)"


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--trend":
        print(get_trend(7))
    else:
        # 测试
        log_quality("test_00", {"513100": "L5_default", "TQQQ": "L5_default", "news": "L1"})
