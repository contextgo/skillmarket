#!/usr/bin/env python3
"""
新闻缓存管理 - 支持 12 小时缓存
减少重复抓取，降低 token 消耗

缓存策略:
- 07:00 - 实时抓取新闻 (早间版)
- 19:00 - 实时抓取新闻 (晚间版)
- 其他时间 - 使用缓存
"""

import json
from datetime import datetime, timedelta
from pathlib import Path

CACHE_DIR = Path("/home/admin/openclaw/workspace/skills/hourly-broadcast/cache/news")
CACHE_TTL_HOURS = 12  # 12 小时缓存


class NewsCache:
    def __init__(self):
        CACHE_DIR.mkdir(parents=True, exist_ok=True)
        self.cache_file = CACHE_DIR / "latest_news.json"
    
    def get_cache_timestamp(self) -> datetime:
        """获取缓存时间戳"""
        if not self.cache_file.exists():
            return None
        
        with open(self.cache_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return datetime.fromisoformat(data['cached_at'])
    
    def is_cache_valid(self) -> bool:
        """检查缓存是否有效 (12 小时内)"""
        cached_at = self.get_cache_timestamp()
        if not cached_at:
            return False
        
        now = datetime.now()
        age = now - cached_at
        
        # 检查是否在 12 小时内
        if age > timedelta(hours=CACHE_TTL_HOURS):
            print(f"⏰ 缓存已过期 (缓存时间：{cached_at.strftime('%H:%M')}, 当前：{now.strftime('%H:%M')}, 缓存年龄：{age})")
            return False
        
        print(f"✅ 缓存有效 (缓存时间：{cached_at.strftime('%H:%M')}, 缓存年龄：{age})")
        return True
    
    def should_fetch_fresh(self) -> bool:
        """判断是否应该抓取实时新闻"""
        now = datetime.now()
        
        # 缓存无效时，抓取实时
        if not self.is_cache_valid():
            return True
        
        # 早间版：07:00-07:59
        if now.hour == 7 and now.minute < 60:
            print("🌅 早间播报时间，抓取实时新闻")
            return True
        
        # 晚间版：19:00-19:59
        if now.hour == 19 and now.minute < 60:
            print("🌆 晚间播报时间，抓取实时新闻")
            return True
        
        # 缓存有效且非早/晚间，使用缓存
        return False
    
    def load_cached_news(self) -> dict:
        """加载缓存的新闻数据"""
        if not self.cache_file.exists():
            return None
        
        try:
            with open(self.cache_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"📰 加载缓存新闻：{len(data.get('articles', []))} 条")
                return data
        except Exception as e:
            print(f"⚠️ 加载缓存失败：{e}")
            return None
    
    def save_news(self, news_data: dict):
        """保存新闻到缓存"""
        news_data['cached_at'] = datetime.now().isoformat()
        news_data['cache_version'] = '1.0'
        
        with open(self.cache_file, 'w', encoding='utf-8') as f:
            json.dump(news_data, f, ensure_ascii=False, indent=2)
        
        print(f"💾 新闻已缓存：{len(news_data.get('articles', []))} 条，缓存时间：{news_data['cached_at']}")
    
    def get_cache_info(self) -> dict:
        """获取缓存信息"""
        cached_at = self.get_cache_timestamp()
        if not cached_at:
            return {
                'has_cache': False,
                'age_hours': None,
                'is_valid': False
            }
        
        now = datetime.now()
        age = now - cached_at
        
        return {
            'has_cache': True,
            'cached_at': cached_at.strftime('%Y-%m-%d %H:%M'),
            'age_hours': round(age.total_seconds() / 3600, 1),
            'is_valid': age <= timedelta(hours=CACHE_TTL_HOURS)
        }


def main():
    """测试缓存功能"""
    cache = NewsCache()
    
    print("=== 新闻缓存测试 ===")
    print(f"缓存目录：{CACHE_DIR}")
    print(f"缓存 TTL: {CACHE_TTL_HOURS} 小时")
    print()
    
    info = cache.get_cache_info()
    print(f"缓存状态:")
    print(f"  有缓存：{info['has_cache']}")
    if info['has_cache']:
        print(f"  缓存时间：{info['cached_at']}")
        print(f"  缓存年龄：{info['age_hours']} 小时")
        print(f"  是否有效：{info['is_valid']}")
    print()
    
    should_fetch = cache.should_fetch_fresh()
    print(f"是否抓取实时新闻：{should_fetch}")


if __name__ == "__main__":
    main()
