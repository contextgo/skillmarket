#!/usr/bin/env python3
"""
Dynamic TTL Cache Manager - 动态缓存 TTL 管理模块

功能:
- 根据数据类型和时间段动态设置缓存 TTL
- 股票缓存：交易时段 3 分钟，非交易时段 15 分钟
- 新闻缓存：AI 新闻 4 小时，财经新闻 8 小时，热榜 1 小时
- 天气缓存：30 分钟
- 自动判断缓存过期时间
"""

import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, Dict, Any
from enum import Enum


class CacheType(Enum):
    """缓存类型枚举"""
    STOCK = "stock"           # 股票数据
    NEWS_AI = "news_ai"       # AI 新闻
    NEWS_FINANCE = "news_finance"  # 财经新闻
    NEWS_HOT = "news_hot"     # 热榜新闻
    WEATHER = "weather"       # 天气数据
    BROADCAST = "broadcast"   # 完整播报


class MarketStatus(Enum):
    """市场状态枚举"""
    TRADING = "trading"       # 交易时段
    PRE_TRADING = "pre_trading"  # 盘前
    POST_TRADING = "post_trading"  # 盘后
    CLOSED = "closed"         # 休市（周末/节假日）


class DynamicTTLConfig:
    """动态 TTL 配置"""
    
    # 股票缓存 TTL（分钟）
    STOCK_TTL_TRADING = 3      # 交易时段：3 分钟
    STOCK_TTL_PRE_POST = 10    # 盘前盘后：10 分钟
    STOCK_TTL_CLOSED = 15      # 休市：15 分钟
    
    # 新闻缓存 TTL（小时）
    NEWS_AI_TTL = 4            # AI 新闻：4 小时
    NEWS_FINANCE_TTL = 8       # 财经新闻：8 小时
    NEWS_HOT_TTL = 1           # 热榜：1 小时
    
    # 天气缓存 TTL（分钟）
    WEATHER_TTL = 30           # 天气：30 分钟
    
    # 完整播报缓存 TTL（分钟）
    BROADCAST_TTL = 60         # 播报：60 分钟（整点更新）
    
    # 交易时段配置（北京时间）
    TRADING_HOURS = [
        (9, 15, 11, 30),   # 上午：9:15-11:30
        (13, 0, 15, 0),    # 下午：13:00-15:00
    ]
    
    # 盘前盘后配置
    PRE_TRADING_HOURS = (8, 0, 9, 15)    # 8:00-9:15
    POST_TRADING_HOURS = (15, 0, 16, 0)  # 15:00-16:00


class DynamicTTLCache:
    """动态 TTL 缓存管理器"""
    
    def __init__(self, cache_dir: Optional[Path] = None):
        """
        初始化缓存管理器
        
        Args:
            cache_dir: 缓存目录路径
        """
        self.cache_dir = cache_dir or (Path(__file__).parent / "cache")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.config = DynamicTTLConfig()
    
    def get_market_status(self, check_time: Optional[datetime] = None) -> MarketStatus:
        """
        判断当前市场状态
        
        Args:
            check_time: 检查时间，默认当前时间
        
        Returns:
            市场状态
        """
        if check_time is None:
            check_time = datetime.now()
        
        # 检查是否是周末
        if check_time.weekday() >= 5:  # 5=周六，6=周日
            return MarketStatus.CLOSED
        
        hour = check_time.hour
        minute = check_time.minute
        time_in_minutes = hour * 60 + minute
        
        # 检查交易时段
        for start_h, start_m, end_h, end_m in self.config.TRADING_HOURS:
            start_minutes = start_h * 60 + start_m
            end_minutes = end_h * 60 + end_m
            
            if start_minutes <= time_in_minutes < end_minutes:
                return MarketStatus.TRADING
        
        # 检查盘前
        pre_start = self.config.PRE_TRADING_HOURS[0] * 60 + self.config.PRE_TRADING_HOURS[1]
        pre_end = self.config.PRE_TRADING_HOURS[2] * 60 + self.config.PRE_TRADING_HOURS[3]
        if pre_start <= time_in_minutes < pre_end:
            return MarketStatus.PRE_TRADING
        
        # 检查盘后
        post_start = self.config.POST_TRADING_HOURS[0] * 60 + self.config.POST_TRADING_HOURS[1]
        post_end = self.config.POST_TRADING_HOURS[2] * 60 + self.config.POST_TRADING_HOURS[3]
        if post_start <= time_in_minutes < post_end:
            return MarketStatus.POST_TRADING
        
        # 其他时间为休市
        return MarketStatus.CLOSED
    
    def get_stock_ttl(self, check_time: Optional[datetime] = None) -> int:
        """
        获取股票数据缓存 TTL（分钟）
        
        Args:
            check_time: 检查时间
        
        Returns:
            TTL（分钟）
        """
        market_status = self.get_market_status(check_time)
        
        if market_status == MarketStatus.TRADING:
            return self.config.STOCK_TTL_TRADING
        elif market_status in [MarketStatus.PRE_TRADING, MarketStatus.POST_TRADING]:
            return self.config.STOCK_TTL_PRE_POST
        else:
            return self.config.STOCK_TTL_CLOSED
    
    def get_news_ttl(self, news_type: str = "ai") -> int:
        """
        获取新闻数据缓存 TTL（小时）
        
        Args:
            news_type: 新闻类型 (ai/finance/hot)
        
        Returns:
            TTL（小时）
        """
        news_type = news_type.lower()
        
        if news_type == "ai":
            return self.config.NEWS_AI_TTL
        elif news_type == "finance":
            return self.config.NEWS_FINANCE_TTL
        elif news_type == "hot":
            return self.config.NEWS_HOT_TTL
        else:
            return self.config.NEWS_AI_TTL  # 默认 AI 新闻 TTL
    
    def get_weather_ttl(self) -> int:
        """
        获取天气数据缓存 TTL（分钟）
        
        Returns:
            TTL（分钟）
        """
        return self.config.WEATHER_TTL
    
    def get_broadcast_ttl(self) -> int:
        """
        获取完整播报缓存 TTL（分钟）
        
        Returns:
            TTL（分钟）
        """
        return self.config.BROADCAST_TTL
    
    def get_ttl(self, cache_type: CacheType, **kwargs) -> int:
        """
        获取指定缓存类型的 TTL
        
        Args:
            cache_type: 缓存类型
            **kwargs: 额外参数（如 news_type）
        
        Returns:
            TTL（分钟）
        """
        if cache_type == CacheType.STOCK:
            return self.get_stock_ttl(kwargs.get('check_time'))
        elif cache_type == CacheType.NEWS_AI:
            return self.get_news_ttl("ai") * 60  # 转换为分钟
        elif cache_type == CacheType.NEWS_FINANCE:
            return self.get_news_ttl("finance") * 60
        elif cache_type == CacheType.NEWS_HOT:
            return self.get_news_ttl("hot") * 60
        elif cache_type == CacheType.WEATHER:
            return self.get_weather_ttl()
        elif cache_type == CacheType.BROADCAST:
            return self.get_broadcast_ttl()
        else:
            return 60  # 默认 60 分钟
    
    def calculate_expiry(self, cache_type: CacheType, **kwargs) -> datetime:
        """
        计算缓存过期时间
        
        Args:
            cache_type: 缓存类型
            **kwargs: 额外参数
        
        Returns:
            过期时间
        """
        ttl_minutes = self.get_ttl(cache_type, **kwargs)
        return datetime.now() + timedelta(minutes=ttl_minutes)
    
    def is_expired(self, cache_data: Dict[str, Any]) -> bool:
        """
        检查缓存是否过期
        
        Args:
            cache_data: 缓存数据（包含 valid_until 字段）
        
        Returns:
            是否过期
        """
        if "valid_until" not in cache_data:
            return True  # 没有过期时间，视为过期
        
        try:
            valid_until = datetime.fromisoformat(cache_data["valid_until"])
            return datetime.now() > valid_until
        except Exception:
            return True
    
    def get_cache_filename(self, cache_type: CacheType, key: str) -> str:
        """
        获取缓存文件名
        
        Args:
            cache_type: 缓存类型
            key: 缓存键（如股票代码、新闻类型等）
        
        Returns:
            缓存文件路径
        """
        filename = f"{cache_type.value}_{key}.json"
        return str(self.cache_dir / filename)
    
    def save(self, cache_type: CacheType, key: str, data: Dict[str, Any], 
             extra_metadata: Dict[str, Any] = None) -> str:
        """
        保存缓存数据
        
        Args:
            cache_type: 缓存类型
            key: 缓存键
            data: 缓存数据
            extra_metadata: 额外元数据
        
        Returns:
            缓存文件路径
        """
        cache_file = self.get_cache_filename(cache_type, key)
        
        # 计算过期时间
        expiry_time = self.calculate_expiry(cache_type)
        
        # 构建缓存数据
        cache_data = {
            "cache_type": cache_type.value,
            "key": key,
            "created_at": datetime.now().isoformat(),
            "valid_until": expiry_time.isoformat(),
            "ttl_minutes": self.get_ttl(cache_type),
            "status": "valid",
            "data": data,
            "metadata": extra_metadata or {}
        }
        
        # 保存到文件
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(cache_data, f, ensure_ascii=False, indent=2)
        
        print(f"✅ 缓存已保存：{cache_file} (TTL: {self.get_ttl(cache_type)}分钟，过期：{expiry_time.strftime('%H:%M:%S')})")
        return cache_file
    
    def load(self, cache_type: CacheType, key: str) -> Optional[Dict[str, Any]]:
        """
        加载缓存数据
        
        Args:
            cache_type: 缓存类型
            key: 缓存键
        
        Returns:
            缓存数据，如果不存在或已过期则返回 None
        """
        cache_file_path = self.get_cache_filename(cache_type, key)
        cache_file = Path(cache_file_path)
        
        if not cache_file.exists():
            print(f"⚠️ 缓存不存在：{cache_file}")
            return None
        
        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                cache_data = json.load(f)
            
            # 检查是否过期
            if self.is_expired(cache_data):
                print(f"⚠️ 缓存已过期：{cache_file}")
                # 可以选择删除过期缓存
                # cache_file.unlink()
                return None
            
            # 计算剩余有效期
            valid_until = datetime.fromisoformat(cache_data["valid_until"])
            remaining = (valid_until - datetime.now()).total_seconds() / 60
            
            print(f"✅ 缓存有效：{cache_file} (剩余：{remaining:.1f}分钟)")
            return cache_data
        
        except Exception as e:
            print(f"⚠️ 缓存加载失败：{e}")
            return None
    
    def get_or_fetch(self, cache_type: CacheType, key: str, 
                     fetch_func, force_refresh: bool = False) -> Dict[str, Any]:
        """
        获取缓存，如不存在或过期则调用 fetch_func 获取新数据
        
        Args:
            cache_type: 缓存类型
            key: 缓存键
            fetch_func: 获取数据的函数（返回 Dict）
            force_refresh: 是否强制刷新
        
        Returns:
            数据字典
        """
        # 尝试加载缓存（非强制刷新时）
        if not force_refresh:
            cached = self.load(cache_type, key)
            if cached:
                cached['from_cache'] = True
                return cached
        
        # 缓存不存在或已过期，获取新数据
        print(f"🔄 缓存未命中，获取新数据...")
        data = fetch_func()
        
        # 保存到新缓存
        self.save(cache_type, key, data)
        
        data['from_cache'] = False
        return data
    
    def clear(self, cache_type: Optional[CacheType] = None) -> int:
        """
        清理缓存
        
        Args:
            cache_type: 缓存类型，None 表示清理所有
        
        Returns:
            清理的文件数
        """
        count = 0
        
        for cache_file in self.cache_dir.glob("*.json"):
            if cache_type is None:
                # 清理所有
                cache_file.unlink()
                count += 1
            else:
                # 清理指定类型
                if cache_file.stem.startswith(cache_type.value):
                    cache_file.unlink()
                    count += 1
        
        print(f"✅ 已清理 {count} 个缓存文件")
        return count
    
    def get_stats(self) -> Dict[str, Any]:
        """
        获取缓存统计信息
        
        Returns:
            统计信息字典
        """
        stats = {
            "total_files": 0,
            "total_size_bytes": 0,
            "by_type": {},
            "expired_count": 0,
            "valid_count": 0
        }
        
        for cache_file in self.cache_dir.glob("*.json"):
            stats["total_files"] += 1
            stats["total_size_bytes"] += cache_file.stat().st_size
            
            try:
                with open(cache_file, 'r', encoding='utf-8') as f:
                    cache_data = json.load(f)
                
                cache_type = cache_data.get("cache_type", "unknown")
                if cache_type not in stats["by_type"]:
                    stats["by_type"][cache_type] = {"count": 0, "size": 0}
                
                stats["by_type"][cache_type]["count"] += 1
                stats["by_type"][cache_type]["size"] += cache_file.stat().st_size
                
                if self.is_expired(cache_data):
                    stats["expired_count"] += 1
                else:
                    stats["valid_count"] += 1
            
            except Exception:
                pass
        
        return stats
    
    def print_stats(self):
        """打印缓存统计信息"""
        stats = self.get_stats()
        
        print("\n" + "="*60)
        print("📊 缓存统计")
        print("="*60)
        print(f"总文件数：{stats['total_files']}")
        print(f"总大小：{stats['total_size_bytes'] / 1024:.2f} KB")
        print(f"有效缓存：{stats['valid_count']}")
        print(f"过期缓存：{stats['expired_count']}")
        
        if stats["by_type"]:
            print("\n按类型统计:")
            for cache_type, type_stats in sorted(stats["by_type"].items()):
                print(f"  {cache_type}: {type_stats['count']} 个，{type_stats['size'] / 1024:.2f} KB")
        
        print("="*60 + "\n")


# ============ 命令行入口 ============

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='动态 TTL 缓存管理工具')
    parser.add_argument('--stats', action='store_true', help='显示缓存统计')
    parser.add_argument('--clear', action='store_true', help='清理所有缓存')
    parser.add_argument('--clear-type', type=str, help='清理指定类型的缓存')
    parser.add_argument('--test', action='store_true', help='运行测试')
    
    args = parser.parse_args()
    
    cache = DynamicTTLCache()
    
    if args.stats:
        cache.print_stats()
    
    elif args.clear:
        cache.clear()
    
    elif args.clear_type:
        try:
            cache_type = CacheType(args.clear_type)
            cache.clear(cache_type)
        except ValueError:
            print(f"❌ 无效的缓存类型：{args.clear_type}")
            print(f"有效类型：{', '.join([t.value for t in CacheType])}")
    
    elif args.test:
        # 运行测试
        print("\n=== 测试动态 TTL ===\n")
        
        # 测试市场状态判断
        print("当前市场状态:", cache.get_market_status())
        print("股票缓存 TTL:", cache.get_stock_ttl(), "分钟")
        
        # 测试缓存保存和加载
        print("\n=== 测试缓存功能 ===\n")
        
        test_data = {
            "price": 100.5,
            "change": 2.5,
            "timestamp": datetime.now().isoformat()
        }
        
        # 保存股票缓存
        cache.save(CacheType.STOCK, "TEST", test_data)
        
        # 加载缓存
        cached = cache.load(CacheType.STOCK, "TEST")
        if cached:
            print(f"✅ 缓存加载成功：{cached['data']}")
        
        # 显示统计
        cache.print_stats()
        
        # 清理测试缓存
        cache.clear(CacheType.STOCK)
    
    else:
        parser.print_help()
