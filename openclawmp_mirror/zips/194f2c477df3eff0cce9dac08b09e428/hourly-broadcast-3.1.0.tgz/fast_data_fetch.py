#!/usr/bin/env python3
"""
快速数据获取脚本 - 用于整点播报
简化版，确保快速返回数据
"""

import json
import subprocess
import sys
from datetime import datetime

def get_weather_simple(city: str) -> dict:
    """获取天气 - 简化版"""
    # 使用 wttr.in API（快速，无需 key）
    try:
        import urllib.request
        url = f"https://wttr.in/{city}?format=j1"
        req = urllib.request.urlopen(url, timeout=10)
        data = json.loads(req.read().decode())
        
        current = data['current_condition'][0]
        return {
            'condition': current.get('weatherDesc', [{}])[0].get('value', '未知'),
            'temp': f"{current.get('temp_C', '未知')}°C",
            'humidity': current.get('humidity', '未知') + '%',
            'wind': f"{current.get('windspeedKmph', '未知')} km/h",
            'suggestion': '适宜户外活动' if current.get('temp_C', '20') > '15' else '注意保暖'
        }
    except Exception as e:
        print(f"⚠️ 天气获取失败：{e}", file=sys.stderr)
        return {}

def get_stock_simple(symbol: str) -> dict:
    """获取股票 - 简化版（单数据源）"""
    try:
        # 使用 AkShare 快速查询
        import akshare as ak
        
        if symbol.isdigit():  # A 股
            df = ak.stock_zh_a_spot_em()
            row = df[df['代码'] == symbol]
            if len(row) > 0:
                return {
                    'price': str(row['最新价'].values[0]),
                    'change_percent': str(row['涨跌幅'].values[0]),
                    'volume': str(row['成交量'].values[0]),
                    'amount': str(row['成交额'].values[0]),
                    'timestamp': datetime.now().strftime('%H:%M:%S')
                }
        else:  # 美股
            import yfinance as yf
            stock = yf.Ticker(symbol)
            info = stock.fast_info
            return {
                'price': str(info['lastPrice']),
                'change_percent': str(info.get('regularMarketChangePercent', 0)),
                'volume': str(info.get('volume', 0)),
                '52week': f"{info.get('fiftyTwoWeekLow', 0)} - {info.get('fiftyTwoWeekHigh', 0)}",
                'timestamp': datetime.now().strftime('%H:%M:%S')
            }
    except Exception as e:
        print(f"⚠️ 股票获取失败 {symbol}: {e}", file=sys.stderr)
        return {}

def get_news_simple() -> list:
    """获取新闻 - 简化版"""
    try:
        # 使用 RSS 源
        import feedparser
        
        feeds = [
            "https://www.jiqizhixin.com/rss",
            "https://36kr.com/feed"
        ]
        
        articles = []
        for feed_url in feeds[:1]:  # 只取一个源，加快速度
            feed = feedparser.parse(feed_url)
            for entry in feed.entries[:3]:
                articles.append({
                    'title': entry.title,
                    'source': feed.feed.get('title', '未知'),
                    'link': entry.link,
                    'pub_date': entry.get('published', '')[:10],
                    'summary': entry.get('summary', '')[:100]
                })
        
        return articles
    except Exception as e:
        print(f"⚠️ 新闻获取失败：{e}", file=sys.stderr)
        return []

def main():
    """主函数 - 获取所有数据"""
    print("📊 开始获取数据...", flush=True)
    
    data = {
        'market_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'market_source': 'AkShare / YFinance / wttr.in'
    }
    
    # 1. 天气
    print("🌤️ 获取天气...", flush=True)
    bj = get_weather_simple("Beijing")
    sz = get_weather_simple("Shenzhen")
    
    if bj:
        data.update({
            'beijing_weather': bj['condition'],
            'beijing_temp': bj['temp'],
            'beijing_humidity': bj['humidity'],
            'beijing_wind': bj['wind'],
            'beijing_suggestion': bj['suggestion']
        })
    
    if sz:
        data.update({
            'shenzhen_weather': sz['condition'],
            'shenzhen_temp': sz['temp'],
            'shenzhen_humidity': sz['humidity'],
            'shenzhen_wind': sz['wind'],
            'shenzhen_suggestion': sz['suggestion']
        })
    
    # 2. 股票
    print("📈 获取股票...", flush=True)
    stock_513100 = get_stock_simple("513100")
    stock_tqqq = get_stock_simple("TQQQ")
    
    if stock_513100:
        data.update({
            '513100_price': stock_513100['price'],
            '513100_change': stock_513100['change_percent'] + '%',
            '513100_volume': stock_513100['volume'],
            '513100_amount': stock_513100['amount'],
            '513100_time': stock_513100['timestamp']
        })
    
    if stock_tqqq:
        data.update({
            'tqqq_price': stock_tqqq['price'],
            'tqqq_change': stock_tqqq['change_percent'] + '%',
            'tqqq_volume': stock_tqqq['volume'],
            'tqqq_52week': stock_tqqq['52week'],
            'tqqq_time': stock_tqqq['timestamp']
        })
    
    # 3. 新闻
    print("📰 获取新闻...", flush=True)
    articles = get_news_simple()
    
    for i, article in enumerate(articles[:3], 1):
        data.update({
            f'ai_news{i}_title': article['title'],
            f'ai_news{i}_source': article['source'],
            f'ai_news{i}_time': article['pub_date'],
            f'ai_news{i}_summary': article['summary'],
            f'ai_news{i}_link': article['link']
        })
    
    # 输出 JSON
    print(json.dumps(data, ensure_ascii=False, indent=2))
    print("✅ 数据获取完成", flush=True)

if __name__ == "__main__":
    main()
