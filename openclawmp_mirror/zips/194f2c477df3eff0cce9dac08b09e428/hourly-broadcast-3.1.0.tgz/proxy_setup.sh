#!/bin/bash
# HTTP 代理配置脚本

echo "=== HTTP 代理配置 ==="

# 检测系统代理环境
echo "1. 检查系统代理..."
if [ -n "$HTTP_PROXY" ]; then
    echo "   ✅ HTTP_PROXY=$HTTP_PROXY"
else
    echo "   ⚠️ HTTP_PROXY 未设置"
fi

if [ -n "$HTTPS_PROXY" ]; then
    echo "   ✅ HTTPS_PROXY=$HTTPS_PROXY"
else
    echo "   ⚠️ HTTPS_PROXY 未设置"
fi

# 检查 Clash
echo "2. 检查 Clash..."
if command -v clash &> /dev/null; then
    echo "   ✅ Clash 已安装"
    clash --version
else
    echo "   ⚠️ Clash 未安装"
    echo "   安装方法："
    echo "   wget https://github.com/Dreamacro/clash/releases/download/premium/clash-linux-amd64-v1.18.0.gz"
    echo "   gunzip clash-linux-amd64-v1.18.0.gz"
    echo "   chmod +x clash-linux-amd64-v1.18.0"
    echo "   sudo mv clash-linux-amd64-v1.18.0 /usr/local/bin/clash"
fi

# 检查代理端口
echo "3. 检查代理端口..."
if netstat -tlnp 2>/dev/null | grep -q 7890; then
    echo "   ✅ 7890 端口已监听"
else
    echo "   ⚠️ 7890 端口未监听"
fi

# 测试网络
echo "4. 测试网络..."
echo -n "   wttr.in: "
if curl -s https://wttr.in/?format=3 > /dev/null 2>&1; then
    echo "✅ 可访问"
else
    echo "❌ 不可访问"
fi

echo -n "   news.ycombinator.com: "
if curl -s -I https://news.ycombinator.com > /dev/null 2>&1; then
    echo "✅ 可访问"
else
    echo "❌ 不可访问 (网络限制)"
fi

echo ""
echo "=== 建议配置 ==="
echo "# 临时设置代理（当前会话）"
echo "export HTTP_PROXY=http://127.0.0.1:7890"
echo "export HTTPS_PROXY=http://127.0.0.1:7890"
echo ""
echo "# 永久设置（添加到 ~/.bashrc）"
echo "echo 'export HTTP_PROXY=http://127.0.0.1:7890' >> ~/.bashrc"
echo "echo 'export HTTPS_PROXY=http://127.0.0.1:7890' >> ~/.bashrc"
echo "source ~/.bashrc"
