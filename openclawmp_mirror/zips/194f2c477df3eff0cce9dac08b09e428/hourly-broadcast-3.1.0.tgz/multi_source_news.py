#!/usr/bin/env python3
"""
多源新闻聚合器 - 增强版
实现多源备份、优先级排序、自动降级

特性:
1. 多源备份：每个类别 2-3 个源
2. 优先级排序：按文章数、时效性、可信度
3. 自动降级：高优先级失败时自动使用备用源
4. 交叉验证：同一新闻多源报道才采用（可选）

使用方法:
    python3 multi_source_news.py
    python3 multi_source_news.py --cross-verify  # 启用交叉验证
"""

import argparse
import json
import sys
from datetime import datetime, timedelta
from pathlib import Path
from collections import defaultdict

# 尝试导入依赖
try:
    import feedparser
    import requests
except ImportError as e:
    print(f"❌ 缺少依赖：{e}")
    print("请运行：pip install feedparser requests")
    sys.exit(1)

# 导入 RSS 配置
sys.path.insert(0, str(Path(__file__).parent))
try:
    from rss_feeds_config import AVAILABLE_RSS_FEEDS, BACKUP_RSS_FEEDS
except ImportError:
    print("⚠️ 无法导入 rss_feeds_config，使用内置配置")
    AVAILABLE_RSS_FEEDS = [
        {'name': '36kr', 'url': 'https://36kr.com/feed', 'category': '科技', 'priority': 1},
        {'name': 'qbitai', 'url': 'https://www.qbitai.com/feed', 'category': 'AI', 'priority': 1},
        {'name': 'infoq', 'url': 'https://www.infoq.cn/feed', 'category': '科技', 'priority': 1},
    ]
    BACKUP_RSS_FEEDS = []


# ============ 配置 ============

# 每个类别需要的源数量
SOURCES_PER_CATEGORY = 3

# 最少需要的文章数
MIN_ARTICLES = 5

# 超时时间（秒）
TIMEOUT_SECONDS = 10

# 是否启用交叉验证（需要 2+ 源报道同一新闻才采用）
ENABLE_CROSS_VERIFY = False


# ============ 核心功能 ============

def fetch_rss_feed(feed_info: dict) -> list:
    """抓取单个 RSS 源"""
    url = feed_info['url']
    name = feed_info['name']
    
    try:
        response = requests.get(url, timeout=TIMEOUT_SECONDS, headers={
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
        if response.status_code != 200:
            print(f"⚠️ {name}: HTTP {response.status_code}")
            return []
        
        feed = feedparser.parse(response.content)
        articles = []
        
        for entry in feed.entries[:10]:  # 每个源最多取 10 篇
            article = {
                'title': entry.title if hasattr(entry, 'title') else '无标题',
                'source': name,
                'category': feed_info.get('category', '未知'),
                'priority': feed_info.get('priority', 3),
                'pub_date': entry.published if hasattr(entry, 'published') else '',
                'link': entry.link if hasattr(entry, 'link') else '',
                'summary': entry.summary if hasattr(entry, 'summary') else '',
                'fetched_at': datetime.now().isoformat()
            }
            articles.append(article)
        
        return articles
        
    except Exception as e:
        print(f"❌ {name}: {e}")
        return []


def fetch_multi_source_news(sources: list = None, limit: int = 10) -> list:
    """
    多源新闻聚合
    
    策略:
    1. 按优先级排序源
    2. 优先抓取高优先级源
    3. 如果高优先级源失败，自动使用备用源
    4. 去重（按标题哈希）
    5. 按时间和优先级排序
    """
    
    if sources is None:
        # 使用所有可用源
        sources = AVAILABLE_RSS_FEEDS + BACKUP_RSS_FEEDS
    
    # 按类别分组
    category_sources = defaultdict(list)
    for source in sources:
        category_sources[source.get('category', '其他')].append(source)
    
    print(f"📰 开始多源新闻聚合...")
    print(f"源总数：{len(sources)}")
    print(f"类别数：{len(category_sources)}")
    print("=" * 60)
    
    all_articles = []
    start_time = datetime.now()
    
    # 按类别抓取
    for category, cat_sources in category_sources.items():
        print(f"\n📂 类别：{category}")
        
        # 按优先级排序
        sorted_sources = sorted(cat_sources, key=lambda x: x.get('priority', 3))
        
        # 抓取前 N 个源（每个类别）
        for source in sorted_sources[:SOURCES_PER_CATEGORY]:
            print(f"  抓取 {source['name']}...", end=" ")
            
            articles = fetch_rss_feed(source)
            
            if articles:
                print(f"✅ {len(articles)} 篇")
                all_articles.extend(articles)
            else:
                print(f"❌ 失败")
    
    # 去重
    print("\n" + "=" * 60)
    print("🔄 去重处理...")
    
    seen_titles = set()
    unique_articles = []
    
    for article in all_articles:
        # 标题哈希（简单去重）
        title_hash = hash(article['title'])
        
        if title_hash not in seen_titles:
            seen_titles.add(title_hash)
            unique_articles.append(article)
    
    print(f"原始文章：{len(all_articles)} 篇")
    print(f"去重后：{len(unique_articles)} 篇")
    print(f"去重率：{(1 - len(unique_articles)/len(all_articles))*100:.1f}%")
    
    # 交叉验证（可选）
    if ENABLE_CROSS_VERIFY:
        print("\n🔍 交叉验证...")
        # TODO: 实现交叉验证逻辑
        print("⚠️ 交叉验证功能开发中")
    
    # 排序（按优先级和时间）
    print("\n📊 排序处理...")
    
    def sort_key(article):
        # 优先级越高越好（数字越小越好）
        # 时间越新越好
        priority = article.get('priority', 3)
        pub_date = article.get('pub_date', '')
        
        # 简单的时间解析
        try:
            if pub_date:
                pub_time = datetime.fromisoformat(pub_date.replace('Z', '+00:00'))
                time_score = -(pub_time - datetime.now()).total_seconds()
            else:
                time_score = 0
        except:
            time_score = 0
        
        return (priority, time_score)
    
    sorted_articles = sorted(unique_articles, key=sort_key)
    
    # 限制数量
    final_articles = sorted_articles[:limit]
    
    # 统计来源分布
    source_count = defaultdict(int)
    for article in final_articles:
        source_count[article['source']] += 1
    
    duration = (datetime.now() - start_time).total_seconds()
    
    print(f"\n✅ 完成！")
    print(f"耗时：{duration:.1f} 秒")
    print(f"最终文章：{len(final_articles)} 篇")
    print(f"\n来源分布:")
    for source, count in sorted(source_count.items(), key=lambda x: -x[1]):
        print(f"   • {source}: {count} 篇")
    
    return final_articles


def print_news(articles: list):
    """打印新闻列表"""
    print("\n" + "=" * 60)
    print("📰 最新新闻")
    print("=" * 60)
    
    for i, article in enumerate(articles, 1):
        print(f"\n{i}. {article['title']}")
        print(f"   来源：{article['source']}")
        print(f"   类别：{article['category']}")
        print(f"   时间：{article['pub_date'][:10] if article.get('pub_date') else '未知'}")
        print(f"   链接：{article['link'][:80]}...")


def save_news(articles: list, output_file: str = None):
    """保存新闻到文件"""
    if output_file is None:
        output_file = Path(__file__).parent / "cache" / "multi_source_news.json"
    
    output_file = Path(output_file)
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    data = {
        'fetched_at': datetime.now().isoformat(),
        'total_articles': len(articles),
        'sources': list(set(a['source'] for a in articles)),
        'articles': articles
    }
    
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    print(f"\n💾 新闻已保存：{output_file}")


# ============ 主程序 ============

def main():
    parser = argparse.ArgumentParser(description='多源新闻聚合器')
    parser.add_argument('--limit', type=int, default=10, help='最多返回文章数')
    parser.add_argument('--cross-verify', action='store_true', help='启用交叉验证')
    parser.add_argument('--output', type=str, help='输出文件路径')
    parser.add_argument('--json', action='store_true', help='输出 JSON 格式')
    args = parser.parse_args()
    
    global ENABLE_CROSS_VERIFY
    ENABLE_CROSS_VERIFY = args.cross_verify
    
    # 抓取新闻
    articles = fetch_multi_source_news(limit=args.limit)
    
    # 输出
    if args.json:
        print(json.dumps(articles, ensure_ascii=False, indent=2))
    else:
        print_news(articles)
    
    # 保存
    if args.output:
        save_news(articles, args.output)
    else:
        save_news(articles)
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
