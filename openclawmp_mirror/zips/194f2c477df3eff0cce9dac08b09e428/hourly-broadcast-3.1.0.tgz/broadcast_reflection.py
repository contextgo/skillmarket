#!/usr/bin/env python3
"""
播报反思工具 - 每次播报后自动执行
持续优化数据置信度和播报质量

使用方法:
python3 broadcast_reflection.py --broadcast-id 18_00 --data-quality '{"513100":"L5","TQQQ":"L5","news":"L1"}'
"""

import argparse
import json
from datetime import datetime
from pathlib import Path

# 反思模板
REFLECTION_TEMPLATE = """# 整点播报反思 · {broadcast_id}

**播报时间**: {broadcast_time}  
**执行时间**: {runtime}s  
**Token 消耗**: {tokens}  
**数据置信度**: {avg_confidence}%

---

## 📊 数据质量评估

| 数据类型 | 置信度 | 数据源 | 状态 |
|---------|--------|--------|------|
| 天气 (北京/深圳) | {weather_conf}% | wttr.in | {weather_status} |
| 新闻 | {news_conf}% | {news_source} | {news_status} |
| 513100 | {513100_conf}% | {513100_source} | {513100_status} |
| TQQQ | {tqqq_conf}% | {tqqq_source} | {tqqq_status} |

**平均置信度**: {avg_conf}% (目标 >80%)

---

## ✅ Keep (保持)

{keep_items}

---

## 🔧 Fix (改进)

{fix_items}

---

## 🎯 Try (尝试)

{try_items}

---

## 📈 优化实验记录

### 实验 {experiment_id}

**假设**: {hypothesis}  
**方法**: {method}  
**结果**: {result}  
**结论**: {conclusion}  
**下一步**: {next_step}

---

## 📝 关键洞察

{insights}

---

## 📋 行动项

| 优先级 | 行动 | 截止时间 | 状态 |
|--------|------|----------|------|
{action_items}

---

**反思完成时间**: {reflection_time}  
**下次播报**: {next_broadcast}
"""

def generate_reflection(broadcast_id: str, data_quality: dict, runtime: int = 0, tokens: int = 0):
    """生成播报告析报告"""
    
    now = datetime.now()
    next_broadcast = now.replace(minute=50)
    if next_broadcast <= now:
        next_broadcast = next_broadcast.replace(hour=(now.hour + 1) % 24)
    
    # 数据置信度映射
    confidence_map = {
        "L1": 95, "L2": 90, "L3": 70, "L4": 60, "L5_default": 10,
        "L1_cache": 90, "L2_rss": 70, "L3_web": 60, "L4_manual": 95
    }
    
    status_map = {
        "L1": "✅ 优秀", "L2": "✅ 良好", "L3": "⚠️ 一般",
        "L4": "⚠️ 较差", "L5_default": "❌ 需改进"
    }
    
    # 计算各项置信度
    weather_conf = 95  # wttr.in 总是可靠
    news_conf = confidence_map.get(data_quality.get("news", "L1"), 95)
    stock_513100_conf = confidence_map.get(data_quality.get("513100", "L5_default"), 10)
    stock_tqqq_conf = confidence_map.get(data_quality.get("TQQQ", "L5_default"), 10)
    
    avg_conf = (weather_conf + news_conf + stock_513100_conf + stock_tqqq_conf) / 4
    
    # 生成 Keep/Fix/Try
    keep_items = []
    fix_items = []
    try_items = []
    
    # 天气总是可靠的
    keep_items.append(f"✅ 天气数据实时获取 (wttr.in, {weather_conf}% 置信度)")
    
    # 新闻
    if news_conf >= 90:
        keep_items.append(f"✅ 新闻聚合策略有效 (newsnow-reader, {news_conf}% 置信度)")
    else:
        fix_items.append(f"🔧 新闻置信度偏低 ({news_conf}%), 检查新闻源可用性")
    
    # 股票
    if stock_513100_conf < 80:
        fix_items.append(f"🔧 513100 数据置信度仅 {stock_513100_conf}%, 需优化数据源")
        try_items.append("🎯 尝试配置 HTTP 代理解锁 AkShare/YFinance")
        try_items.append("🎯 尝试配置 Tushare API (备选方案)")
        try_items.append("🎯 尝试 a-stock-analysis (新浪财经数据源)")
    
    if stock_tqqq_conf < 80:
        fix_items.append(f"🔧 TQQQ 数据置信度仅 {stock_tqqq_conf}%, 需优化数据源")
        try_items.append("🎯 尝试配置 HTTP 代理解锁 YFinance")
        try_items.append("🎯 尝试美股数据源替代方案")
    
    # 格式化
    keep_str = "\n".join([f"- {item}" for item in keep_items]) if keep_items else "- 无"
    fix_str = "\n".join([f"- {item}" for item in fix_items]) if fix_items else "- 无"
    try_str = "\n".join([f"- {item}" for item in try_items]) if try_items else "- 无"
    
    # 行动项
    action_items = []
    if stock_513100_conf < 80:
        action_items.append(f"P1 | 配置 HTTP 代理或 Tushare API | 本周内 | ⏳ 待执行")
        action_items.append(f"P1 | 测试 a-stock-analysis 数据源 | 3 天内 | ⏳ 待执行")
    
    action_str = "\n".join([f"| {item} |" for item in action_items]) if action_items else "| - | - | - | - |"
    
    # 实验 ID
    experiment_id = f"EXP-{now.strftime('%Y%m%d-%H%M')}"
    
    # 洞察
    insights = []
    if avg_conf < 50:
        insights.append("⚠️ 整体置信度偏低，主要受股票数据拖累")
        insights.append("💡 天气和新闻数据可靠，优化重点在股票数据源")
        insights.append("🎯 建议优先级：HTTP 代理 > Tushare API > a-stock-analysis")
    
    insights_str = "\n".join([f"- {item}" for item in insights]) if insights else "- 无明显问题"
    
    # 生成反思
    reflection = REFLECTION_TEMPLATE.format(
        broadcast_id=broadcast_id,
        broadcast_time=now.strftime('%Y-%m-%d %H:%M'),
        runtime=runtime,
        tokens=tokens,
        avg_confidence=f"{avg_conf:.1f}",
        weather_conf=weather_conf,
        weather_status=status_map.get("L1"),
        news_conf=news_conf,
        news_source=data_quality.get("news_source", "newsnow-reader"),
        news_status=status_map.get(data_quality.get("news", "L1")),
        **{
            "513100_conf": stock_513100_conf,
            "513100_source": data_quality.get("513100_source", "L5_default"),
            "513100_status": status_map.get(data_quality.get("513100", "L5_default")),
            "tqqq_conf": stock_tqqq_conf,
            "tqqq_source": data_quality.get("TQQQ_source", "L5_default"),
            "tqqq_status": status_map.get(data_quality.get("TQQQ", "L5_default")),
        },
        avg_conf=f"{avg_conf:.1f}",
        keep_items=keep_str,
        fix_items=fix_str,
        try_items=try_str,
        experiment_id=experiment_id,
        hypothesis="配置 HTTP 代理或 Tushare API 可提升股票数据置信度至>80%",
        method="1. 安装 Clash 代理 2. 配置 Tushare API token 3. 测试 a-stock-analysis",
        result="待执行",
        conclusion="待验证",
        next_step="本周内完成代理配置和 API 测试",
        insights=insights_str,
        action_items=action_str,
        reflection_time=now.strftime('%Y-%m-%d %H:%M'),
        next_broadcast=next_broadcast.strftime('%Y-%m-%d %H:%M')
    )
    
    return reflection, avg_conf


def main():
    parser = argparse.ArgumentParser(description='播报反思工具')
    parser.add_argument('--broadcast-id', required=True, help='播报 ID (如 18_00)')
    parser.add_argument('--data-quality', type=str, help='数据质量 JSON')
    parser.add_argument('--runtime', type=int, default=0, help='执行时间 (秒)')
    parser.add_argument('--tokens', type=int, default=0, help='Token 消耗')
    parser.add_argument('--output', type=str, help='输出文件路径')
    
    args = parser.parse_args()
    
    data_quality = json.loads(args.data_quality) if args.data_quality else {}
    
    reflection, avg_conf = generate_reflection(
        args.broadcast_id,
        data_quality,
        args.runtime,
        args.tokens
    )
    
    if args.output:
        output_path = Path(args.output)
        output_path.write_text(reflection, encoding='utf-8')
        print(f"✅ 反思报告已保存：{output_path}")
    else:
        print(reflection)
    
    print(f"\n📊 平均置信度：{avg_conf:.1f}% (目标 >80%)")
    
    if avg_conf < 50:
        print("⚠️ 告警：置信度偏低，需优先优化股票数据源")
    elif avg_conf < 80:
        print("⚠️ 注意：置信度接近目标，继续努力")
    else:
        print("✅ 优秀：置信度达标！")


if __name__ == "__main__":
    main()
