# 🦞 外置 AI 代理浏览器 - 一键连接 Kimi/ChatGPT/智谱/通义千问，让 AI 自动搜索分析并生成精美报告

**版本**: 5.0  
**类型**: OpenClaw Skill  
**创建时间**: 2026-03-22  
**实测验证**: 4 轮完整测试（大模型技术/世界杯/量子力学/水培植物）  
**更新内容**: Chrome 模式 - 复用浏览器登录态，无需重新登录

---

## 📌 描述

让 AI 能够通过浏览器自动化访问外部 AI 网站（MiroMind、Kimi、智谱清言、ChatGPT、Gemini 等），利用这些免费或订阅制的 AI 服务作为"外置大脑"，增强自身的信息获取和分析能力。

**核心优势**:
- ✅ 无需开发新 Skill，直接用现有 `agent-browser` CLI
- ✅ 支持所有 AI 网站（只需替换 URL）
- ✅ **Chrome 模式复用登录态** — 无需重新登录，直接使用已登录的 Cookie
- ✅ 回车键发送问题（100% 可靠，避免点错按钮）
- ✅ 监控 Cancel 按钮（实时掌握 AI 分析进度）
- ✅ 自动生成 HTML 报告（美观、可分享）

---

## 🎯 适用场景

- 需要查询外部 AI 的观点/分析/建议
- 多 AI 对比分析（同时查询 Kimi、GPT、Gemini）
- 利用免费 AI 服务扩展自身知识边界
- 自动化重复的 AI 查询任务

---

## 📦 安装说明

### 前置条件

1. **OpenClaw** 已安装并运行
2. **agent-browser** 已安装：
   ```bash
   npm install -g agent-browser
   ```
3. **Google Chrome** 已安装

### 安装步骤

1. **复制 Skill 文件**
   ```bash
   cp SKILL.md ~/.openclaw/skills/外置 AI 代理浏览器/
   ```

2. **配置 Chrome 路径**
   ```bash
   # Linux
   export AGENT_BROWSER_EXECUTABLE_PATH="/usr/bin/google-chrome"
   
   # macOS
   export AGENT_BROWSER_EXECUTABLE_PATH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
   
   # Windows
   $env:AGENT_BROWSER_EXECUTABLE_PATH="C:\Program Files\Google\Chrome\Application\chrome.exe"
   ```

3. **测试安装**
   ```bash
   agent-browser --version
   # 应输出：agent-browser 0.x.x
   ```

---

## 🚀 使用方法

### 快速开始（Chrome 模式 - 复用登录态）⭐推荐

```bash
# 1. 打开浏览器（复用 Chrome 登录态）
export AGENT_BROWSER_EXECUTABLE_PATH="/usr/bin/google-chrome"
agent-browser --headed open https://dr.miromind.ai/ \
  --user-data-dir=/home/admin/.config/google-chrome/

# 2. 获取页面元素
agent-browser snapshot -i

# 3. 点击 New chat（如需要）
agent-browser click @e5

# 4. 输入问题
agent-browser fill @e10 "你的问题"

# 5. 回车发送（⚠️ 不要点击按钮！）
agent-browser press Enter
sleep 3

# 6. 监控 Cancel 按钮
agent-browser snapshot -i | grep -i "cancel"
# 看到 Cancel 后立即停止，截图告知用户

# 7. 等待 AI 完成后获取答案
agent-browser get text body > answer.txt

# 8. 生成 HTML 报告（可选）
# 使用模板生成美观的 HTML 报告
```

**Chrome 模式优势**:
- ✅ **无需重新登录** — 直接使用你在 Chrome 中已登录的 Kimi/ChatGPT/智谱等账号
- ✅ **Cookie 共享** — 无需重新扫码或输入密码
- ✅ **真实用户环境** — 和用户手动操作完全一致

**备选方案**: 如果不想暴露主浏览器登录态，可以使用临时 Profile（手工登录），详见 SKILL.md

### 完整脚本示例

详见 `SKILL.md` 中的"完整脚本示例"章节。

---

## 📋 支持的 AI 网站

| 网站 | 网址 | 登录方式 |
|------|------|---------|
| MiroMind | https://dr.miromind.ai/ | 邮箱/GitHub/Google/Apple |
| Kimi | https://kimi.moonshot.cn/ | 手机/微信 |
| 智谱清言 | https://chatglm.cn/ | 手机/微信 |
| ChatGPT | https://chat.openai.com/ | 邮箱/Google |
| Gemini | https://gemini.google.com/ | Google 账号 |
| 通义千问 | https://tongyi.aliyun.com/ | 支付宝/淘宝 |

---

## ⚠️ 关键注意事项

### ✅ 必做

- [ ] 打开浏览器后不要重复打开（保持会话）
- [ ] 用户手工登录（最可靠）
- [ ] 每个操作后等待 3-5 秒
- [ ] 输入中文直接用 `fill`
- [ ] **用回车键发送问题** — `press Enter`（最可靠！）
- [ ] AI 分析期间定期截图汇报
- [ ] **看到 Cancel 按钮后立即停止** — 截图告知用户等待

### ❌ 禁止

- [ ] 反复重新打开浏览器（导致 Cookie 丢失）
- [ ] 点击发送按钮（容易点错成附件📎）
- [ ] 过早判断 AI 失败（可能需 5 分钟）
- [ ] 不询问用户就一直等待
- [ ] 输入后立即操作（未等待完成）

---

## 📊 实测记录

### 测试 1: 2026 年最火的大模型技术
- **AI 耗时**: 约 5 分钟
- **结果**: ✅ 成功获取 40+ 篇权威来源分析的完整报告

### 测试 2: 2026 年世界杯简报
- **AI 耗时**: 约 5 分钟
- **结果**: ✅ 成功获取完整赛事简报

### 测试 3: 如何入门量子力学？
- **AI 耗时**: 约 3 分钟
- **结果**: ✅ 成功获取详细入门路线图（三阶段学习法）

### 测试 4: 春天易于种植的水培植物
- **AI 耗时**: 约 2 分钟
- **结果**: ✅ 成功获取 10 种水培植物推荐 + 养护指南

**总计**: 4/4 次测试成功，回车键发送 100% 可靠！

---

## 📁 文件结构

```
外置 AI 代理浏览器/
├── README.md           # 本文件
├── SKILL.md            # 完整技能文档（13KB）
└── templates/          # 可选：HTML 报告模板
    └── report.html     # HTML 报告模板
```

---

## 🙏 致谢

本 Skill 基于以下工具构建：
- [agent-browser](https://github.com/agent-browser/agent-browser) - 浏览器自动化 CLI
- [OpenClaw](https://openclaw.ai) - AI 代理框架
- [MiroMind](https://dr.miromind.ai/) - 深度思考 AI 引擎

---

## 📞 支持与反馈

如有问题或建议，请通过水产市场（OpenClawMP）反馈。

**版本历史**:
- v4.0 (2026-03-22): 第四轮测试验证，回车键发送 100% 可靠
- v3.0 (2026-03-22): 第三轮测试教训，监控 Cancel 按钮
- v2.0 (2026-03-22): 第二轮测试，Cookie 保持
- v1.0 (2026-03-22): 初始版本
