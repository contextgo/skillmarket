# -*- coding: utf-8 -*-
"""
Integration Test for Lobster Pet
集成测试 - 验证联动功能
"""

import sys
import time
sys.path.insert(0, 'src')

print("=" * 60)
print("Lobster Pet Integration Test")
print("=" * 60)
print()

# 测试1: 连接器
print("[Test 1] OpenClaw Connector")
print("-" * 40)

from openclaw_connector import OpenClawConnector

oc = OpenClawConnector()

# 连续检测5次
for i in range(5):
    status = oc.get_status()
    tokens = oc.get_token_usage()
    
    print(f"\nCheck {i+1}:")
    print(f"  Status: Working={status['is_working']}, Thinking={status['is_thinking']}, Idle={status['is_idle']}")
    print(f"  Sessions: {status['session_count']}")
    print(f"  Tokens: {tokens}")
    
    if i < 4:
        print("  Waiting 2 seconds...")
        time.sleep(2)

print()
print("=" * 60)
print("Integration test complete!")
print("=" * 60)
print()
print("Note: Start a conversation with OpenClaw to see status changes.")
