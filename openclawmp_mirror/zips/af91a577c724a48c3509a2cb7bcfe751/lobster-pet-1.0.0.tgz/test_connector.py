# -*- coding: utf-8 -*-
"""
Test OpenClaw Connector
测试OpenClaw连接模块
"""

import sys
sys.path.insert(0, 'src')

from openclaw_connector import OpenClawConnector

print("Testing OpenClaw Connector...")
print()

oc = OpenClawConnector()

# 测试获取状态
print("[1] Getting status...")
status = oc.get_status()
print(f"  is_working: {status['is_working']}")
print(f"  is_thinking: {status['is_thinking']}")
print(f"  is_idle: {status['is_idle']}")
print(f"  session_count: {status['session_count']}")

# 测试获取Token
print()
print("[2] Getting token usage...")
tokens = oc.get_token_usage()
print(f"  Token delta: {tokens}")

# 测试获取会话数
print()
print("[3] Getting session count...")
count = oc.get_session_count()
print(f"  Active sessions: {count}")

print()
print("Test complete!")
