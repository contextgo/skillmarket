# -*- coding: utf-8 -*-
"""
Lobster Pet Diagnostic Tool
诊断工具 - 检查联动问题
"""

import sys
import os
from pathlib import Path

print("=" * 60)
print("Lobster Pet Diagnostic Tool")
print("=" * 60)
print()

# 1. 检查文件是否存在
print("[1] Checking files...")
files_to_check = [
    ("Status file", Path.home() / '.stepclaw' / 'lobster-pet-status.json'),
    ("Plugin", Path.home() / '.stepclaw' / 'extensions' / 'lobster-pet-connector' / 'openclaw_plugin.py'),
    ("Main script", Path.home() / '.stepclaw' / 'skills' / 'lobster-pet' / 'lobster_pet.py'),
    ("Icon", Path.home() / '.stepclaw' / 'skills' / 'lobster-pet' / 'assets' / 'icon.ico'),
]

for name, path in files_to_check:
    exists = "OK" if path.exists() else "MISSING"
    print(f"  {name}: {exists}")

print()

# 2. 检查Python模块
print("[2] Checking Python modules...")
sys.path.insert(0, str(Path.home() / '.stepclaw' / 'skills' / 'lobster-pet' / 'src'))

try:
    from lobster_sprite import LobsterSprite
    print("  LobsterSprite: OK")
except Exception as e:
    print(f"  LobsterSprite: ERROR - {e}")

try:
    from openclaw_connector import OpenClawConnector
    print("  OpenClawConnector: OK")
except Exception as e:
    print(f"  OpenClawConnector: ERROR - {e}")

try:
    from xp_system import XPSystem
    print("  XPSystem: OK")
except Exception as e:
    print(f"  XPSystem: ERROR - {e}")

print()

# 3. 测试状态文件读取
print("[3] Testing status file...")
status_file = Path.home() / '.stepclaw' / 'lobster-pet-status.json'
if status_file.exists():
    try:
        import json
        with open(status_file, 'r') as f:
            data = json.load(f)
        print(f"  Status: {data.get('status', {})}")
        print(f"  Tokens: {data.get('tokens', {})}")
    except Exception as e:
        print(f"  ERROR reading status file: {e}")
else:
    print("  Status file not found - plugin may not be running")

print()

# 4. 测试Socket连接
print("[4] Testing socket connection...")
try:
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(2)
    sock.connect(('127.0.0.1', 7654))
    sock.send(json.dumps({'action': 'ping'}).encode())
    response = sock.recv(1024).decode()
    print(f"  Socket response: {response}")
    sock.close()
except Exception as e:
    print(f"  Socket error: {e}")
    print("  Plugin socket server may not be running")

print()

# 5. 检查OpenClaw配置
print("[5] Checking OpenClaw config...")
config_file = Path.home() / '.stepclaw' / 'openclaw.json'
if config_file.exists():
    try:
        import json
        with open(config_file, 'r') as f:
            config = json.load(f)
        plugins = config.get('plugins', {}).get('entries', {})
        if 'lobster-pet-connector' in plugins:
            print(f"  Plugin enabled: {plugins['lobster-pet-connector'].get('enabled', False)}")
        else:
            print("  Plugin not in config - may need to enable")
    except Exception as e:
        print(f"  Error reading config: {e}")
else:
    print("  OpenClaw config not found")

print()
print("=" * 60)
print("Diagnostic complete")
print("=" * 60)
