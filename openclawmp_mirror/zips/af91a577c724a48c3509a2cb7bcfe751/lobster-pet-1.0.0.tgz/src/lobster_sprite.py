# -*- coding: utf-8 -*-
"""
Lobster Sprite Module - Refined Version
像素龙虾精灵模块 - 精致16x16像素版本
"""

from PIL import Image, ImageDraw
from PyQt5.QtGui import QPixmap, QImage
import numpy as np


class LobsterSprite:
    """龙虾精灵类 - 精致像素艺术"""
    
    # 等级颜色配置
    LEVEL_COLORS = {
        1: {'body': (255, 107, 107), 'accent': (255, 158, 158), 'eye': (255, 200, 200)},  # 粉色宝宝
        2: {'body': (255, 159, 67), 'accent': (255, 195, 113), 'eye': (255, 220, 180)},   # 活力橙
        3: {'body': (255, 206, 86), 'accent': (255, 230, 150), 'eye': (255, 240, 200)},   # 键盘侠黄
        4: {'body': (72, 219, 251), 'accent': (149, 230, 255), 'eye': (200, 245, 255)},   # 代码大师蓝
        5: {'body': (29, 209, 161), 'accent': (120, 255, 214), 'eye': (180, 255, 220)},   # 黑客绿
        6: {'body': (162, 155, 254), 'accent': (200, 190, 255), 'eye': (230, 220, 255)},  # AI龙虾王紫
    }
    
    # 等级名称
    LEVEL_NAMES = {
        1: '龙虾宝宝',
        2: '活力龙虾',
        3: '键盘侠',
        4: '代码大师',
        5: '黑客龙虾',
        6: 'AI龙虾王',
    }
    
    def __init__(self, level=1):
        self.level = level
        self.frame_index = 0
        self.colors = self.LEVEL_COLORS.get(min(level, 6), self.LEVEL_COLORS[1])
        
    def set_level(self, level):
        """设置等级"""
        self.level = level
        self.colors = self.LEVEL_COLORS.get(min(level, 6), self.LEVEL_COLORS[1])
    
    def get_level_name(self):
        """获取等级名称"""
        return self.LEVEL_NAMES.get(self.level, '龙虾宝宝')
    
    def get_icon_path(self):
        """获取图标路径"""
        return 'assets/icon.png'
    
    def create_pixel_lobster(self, state='idle', frame=0):
        """创建像素龙虾图像 - 16x16像素，放大到64x64"""
        img = Image.new('RGBA', (16, 16), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        
        body_color = self.colors['body']
        accent_color = self.colors['accent']
        eye_color = self.colors['eye']
        
        if state == 'idle':
            self._draw_idle(draw, body_color, accent_color, eye_color, frame)
        elif state == 'working':
            self._draw_working(draw, body_color, accent_color, eye_color, frame)
        elif state == 'thinking':
            self._draw_thinking(draw, body_color, accent_color, eye_color, frame)
        elif state == 'resting':
            self._draw_resting(draw, body_color, accent_color, eye_color, frame)
        
        # 放大到64x64
        img = img.resize((64, 64), Image.NEAREST)
        
        # 转换为QPixmap
        data = img.tobytes('raw', 'RGBA')
        qimage = QImage(data, 64, 64, QImage.Format_RGBA8888)
        return QPixmap.fromImage(qimage)
    
    def _draw_idle(self, draw, body, accent, eye, frame):
        """待机状态 - 优雅摆动"""
        # 身体轻微摆动
        sway = int(np.sin(frame * 0.08) * 1)
        bx, by = 5 + sway, 7
        
        # 身体 (椭圆)
        draw.ellipse([bx, by, bx+4, by+3], fill=body)
        
        # 头部
        hx, hy = 5 + sway, 4
        draw.ellipse([hx, hy, hx+4, hy+3], fill=body)
        
        # 眼睛 (带眨眼)
        blink = 0 if (frame % 60) < 55 else 1
        if blink == 0:
            draw.ellipse([hx+1, hy+1, hx+2, hy+2], fill=(255,255,255))
            draw.ellipse([hx+3, hy+1, hx+4, hy+2], fill=(255,255,255))
            draw.point([hx+1, hy+1], fill=(0,0,0))
            draw.point([hx+3, hy+1], fill=(0,0,0))
        else:
            draw.line([hx+1, hy+1, hx+2, hy+1], fill=(0,0,0), width=1)
            draw.line([hx+3, hy+1, hx+4, hy+1], fill=(0,0,0), width=1)
        
        # 触须 (优雅摆动)
        ant = int(np.sin(frame * 0.1) * 2)
        draw.line([hx+1, hy, hx+ant, hy-2], fill=body, width=1)
        draw.line([hx+3, hy, hx+4-ant, hy-2], fill=body, width=1)
        
        # 大钳子 (标志性)
        claw = int(np.sin(frame * 0.06) * 1)
        # 左钳
        draw.ellipse([bx-2, by+claw, bx, by+2+claw], fill=accent)
        draw.ellipse([bx-1, by-1+claw, bx+1, by+1+claw], fill=accent)
        # 右钳
        draw.ellipse([bx+4, by-claw, bx+6, by+2-claw], fill=accent)
        draw.ellipse([bx+3, by-1-claw, bx+5, by+1-claw], fill=accent)
        
        # 尾巴 (扇形摆动)
        tail = int(np.sin(frame * 0.08) * 1)
        draw.polygon([
            (bx+1, by+3), (bx+2, by+5+tail), (bx+3, by+6+tail), 
            (bx+4, by+5+tail), (bx+5, by+3)
        ], fill=accent)
        
        # 小腿
        leg = int(np.sin(frame * 0.12) * 1)
        draw.line([bx-1, by+1, bx-2, by+2+leg], fill=body, width=1)
        draw.line([bx+6, by+1, bx+7, by+2-leg], fill=body, width=1)
    
    def _draw_working(self, draw, body, accent, eye, frame):
        """工作状态 - 疯狂敲击"""
        # 震动效果
        shake = int(np.sin(frame * 0.8) * 1)
        bx, by = 5 + shake, 7
        
        # 身体
        draw.ellipse([bx, by, bx+4, by+3], fill=body)
        
        # 头部
        hx, hy = 5 + shake, 4
        draw.ellipse([hx, hy, hx+4, hy+3], fill=body)
        
        # 眼睛 (瞪大专注)
        draw.ellipse([hx+1, hy, hx+2, hy+2], fill=(255,255,255))
        draw.ellipse([hx+3, hy, hx+4, hy+2], fill=(255,255,255))
        draw.point([hx+1, hy], fill=(0,0,0))
        draw.point([hx+3, hy], fill=(0,0,0))
        
        # 键盘 (Lv.3+)
        if self.level >= 3:
            kb_flash = (frame // 2) % 4
            for i in range(4):
                c = (200,200,200) if i==kb_flash else (100,100,100)
                draw.point([4+i, 14], fill=c)
        
        # 钳子疯狂敲击
        tap = frame % 3
        if tap == 0:
            draw.ellipse([bx-2, 5, bx, 7], fill=accent)
            draw.ellipse([bx+4, 8, bx+6, 10], fill=accent)
        elif tap == 1:
            draw.ellipse([bx-2, 8, bx, 10], fill=accent)
            draw.ellipse([bx+4, 5, bx+6, 7], fill=accent)
        else:
            draw.ellipse([bx-2, 6, bx, 8], fill=accent)
            draw.ellipse([bx+4, 6, bx+6, 8], fill=accent)
        
        # 代码飞溅 (Lv.4+)
        if self.level >= 4:
            for i in range(2):
                cx = 2 + (frame*2 + i*4) % 10
                cy = 1 + int(np.sin(frame*0.4 + i)*1)
                draw.point([cx, cy], fill=(0,255,0))
    
    def _draw_thinking(self, draw, body, accent, eye, frame):
        """思考状态 - 沉思"""
        bx, by = 5, 7
        
        # 身体
        draw.ellipse([bx, by, bx+4, by+3], fill=body)
        
        # 头部
        hx, hy = 5, 4
        draw.ellipse([hx, hy, hx+4, hy+3], fill=body)
        
        # 眼睛 (向上看)
        look = int(np.sin(frame * 0.05) * 1)
        draw.ellipse([hx+1, hy-look, hx+2, hy+1-look], fill=(255,255,255))
        draw.ellipse([hx+3, hy-look, hx+4, hy+1-look], fill=(255,255,255))
        draw.point([hx+1, hy-look], fill=(0,0,0))
        draw.point([hx+3, hy-look], fill=(0,0,0))
        
        # 思考气泡
        if (frame % 80) < 40:
            alpha = int((1 - abs((frame%40) - 20)/20) * 255)
            # 气泡点
            draw.ellipse([12, 12, 13, 13], fill=(255,255,255, alpha//3))
            draw.ellipse([13, 10, 14, 11], fill=(255,255,255, alpha//2))
            draw.ellipse([14, 7, 15, 9], fill=(255,255,255, alpha))
            # ...
            if (frame % 20) < 10:
                draw.point([14, 8], fill=(100,100,100))
            if (frame % 20) < 15:
                draw.point([15, 8], fill=(100,100,100))
            draw.point([16, 8], fill=(100,100,100))
        
        # 触须 (缓慢摆动)
        ant = int(np.sin(frame * 0.04) * 1)
        draw.line([hx+1, hy, hx+ant, hy-2], fill=body, width=1)
        draw.line([hx+3, hy, hx+4-ant, hy-2], fill=body, width=1)
        
        # 钳子 (抱胸姿势)
        draw.ellipse([bx, by+1, bx+2, by+3], fill=accent)
        draw.ellipse([bx+3, by+1, bx+5, by+3], fill=accent)
    
    def _draw_resting(self, draw, body, accent, eye, frame):
        """休息状态 - 睡觉"""
        bx, by = 6, 8
        
        # 身体 (蜷缩)
        draw.ellipse([bx, by, bx+3, by+3], fill=body)
        
        # 头部 (低垂)
        hx, hy = 6, 6
        draw.ellipse([hx, hy, hx+3, hy+2], fill=body)
        
        # 眼睛 (闭合)
        draw.line([hx+1, hy+1, hx+2, hy+1], fill=(100,100,100), width=1)
        
        # Zzz气泡
        z_alpha = int((1 - abs((frame%60) - 30)/30) * 255)
        z_y = 3 - (frame % 60) // 20
        # Z
        draw.line([13, z_y, 14, z_y], fill=(200,200,200, z_alpha//3), width=1)
        draw.line([13, z_y, 14, z_y+1], fill=(200,200,200, z_alpha//3), width=1)
        draw.line([13, z_y+1, 14, z_y+1], fill=(200,200,200, z_alpha//3), width=1)
        
        # 钳子 (收起)
        draw.ellipse([bx-1, by+1, bx+1, by+3], fill=accent)
        draw.ellipse([bx+3, by+1, bx+5, by+3], fill=accent)
        
        # 尾巴 (包裹)
        draw.arc([bx-1, by+2, bx+4, by+5], 0, 180, fill=accent, width=1)
    
    def get_next_frame(self, state):
        """获取下一帧动画"""
        self.frame_index += 1
        return self.create_pixel_lobster(state, self.frame_index)
    
    def get_current_frame(self):
        """获取当前帧"""
        return self.create_pixel_lobster('idle', self.frame_index)
