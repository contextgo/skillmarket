# -*- coding: utf-8 -*-
"""
Simple OpenClaw Connector
简化版连接器 - 只监控当前对话状态

在当前对话目录创建状态文件，桌宠读取即可
"""

import json
import time
from pathlib import Path


class OpenClawConnector:
    """简化版连接器"""
    
    def __init__(self):
        # 状态文件路径（当前对话）
        self.status_file = Path.home() / '.stepclaw' / 'lobster-pet-status.json'
        self.last_status = {
            'is_working': False,
            'is_thinking': False,
            'is_idle': True,
            'message': ''
        }
        
    def get_status(self):
        """读取状态文件"""
        try:
            if self.status_file.exists():
                with open(self.status_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.last_status = {
                        'is_working': data.get('is_working', False),
                        'is_thinking': data.get('is_thinking', False),
                        'is_idle': data.get('is_idle', True),
                        'message': data.get('message', '')
                    }
            return self.last_status
        except:
            return self.last_status
    
    def get_token_usage(self):
        """获取Token消耗"""
        try:
            if self.status_file.exists():
                with open(self.status_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    return data.get('tokens', 0)
        except:
            pass
        return 0


def update_status(is_working=False, is_thinking=False, is_idle=True, tokens=0, message=''):
    """更新状态文件（由当前对话调用）"""
    try:
        status_file = Path.home() / '.stepclaw' / 'lobster-pet-status.json'
        
        data = {
            'is_working': is_working,
            'is_thinking': is_thinking,
            'is_idle': is_idle,
            'tokens': tokens,
            'message': message,
            'timestamp': time.time()
        }
        
        with open(status_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False)
            
    except Exception as e:
        print(f"[Status Update] Error: {e}")


# 如果直接运行此文件，创建测试状态
if __name__ == '__main__':
    import sys
    
    if len(sys.argv) > 1:
        state = sys.argv[1]
        if state == 'working':
            update_status(is_working=True, is_thinking=False, is_idle=False, message='Working')
            print("Status set to: WORKING")
        elif state == 'thinking':
            update_status(is_working=False, is_thinking=True, is_idle=False, message='Thinking')
            print("Status set to: THINKING")
        elif state == 'idle':
            update_status(is_working=False, is_thinking=False, is_idle=True, message='Idle')
            print("Status set to: IDLE")
        else:
            print("Usage: python openclaw_connector.py [working|thinking|idle]")
    else:
        # 显示当前状态
        oc = OpenClawConnector()
        status = oc.get_status()
        print(f"Current status: {status}")
