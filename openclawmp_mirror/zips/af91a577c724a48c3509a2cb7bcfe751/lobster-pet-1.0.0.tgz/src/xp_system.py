# -*- coding: utf-8 -*-
"""
XP System Module
经验值系统模块 - 管理Token消耗转换为经验值，处理等级升级
"""

import json
from pathlib import Path


class XPSystem:
    """经验值系统类"""
    
    # 等级配置
    LEVELS = {
        1: {'name': '龙虾宝宝', 'xp_required': 0, 'color': (255, 107, 107)},
        2: {'name': '活力龙虾', 'xp_required': 1000000, 'color': (255, 159, 67)},      # 1M tokens
        3: {'name': '键盘侠', 'xp_required': 5000000, 'color': (255, 206, 86)},        # 5M tokens
        4: {'name': '代码大师', 'xp_required': 10000000, 'color': (72, 219, 251)},      # 10M tokens
        5: {'name': '黑客龙虾', 'xp_required': 25000000, 'color': (29, 209, 161)},      # 25M tokens
        6: {'name': 'AI龙虾王', 'xp_required': 50000000, 'color': (162, 155, 254)},     # 50M tokens
    }
    
    # 经验值转换率: 1 token = 1 XP
    XP_PER_TOKEN = 1
    
    def __init__(self):
        self.data_file = Path.home() / '.stepclaw' / 'lobster-pet-xp.json'
        self.xp = 0
        self.total_tokens = 0
        self.level = 1
        self.load_data()
    
    def load_data(self):
        """加载经验值数据"""
        if self.data_file.exists():
            try:
                with open(self.data_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.xp = data.get('xp', 0)
                    self.total_tokens = data.get('total_tokens', 0)
                    self.level = data.get('level', 1)
            except:
                self.xp = 0
                self.total_tokens = 0
                self.level = 1
    
    def save_data(self):
        """保存经验值数据"""
        data = {
            'xp': self.xp,
            'total_tokens': self.total_tokens,
            'level': self.level,
            'level_name': self.get_level_name()
        }
        with open(self.data_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def add_tokens(self, tokens):
        """添加Token消耗，转换为经验值"""
        xp_gained = tokens * self.XP_PER_TOKEN
        self.xp += xp_gained
        self.total_tokens += tokens
        
        # 检查是否升级
        old_level = self.level
        self._check_level_up()
        
        # 保存数据
        self.save_data()
        
        return xp_gained
    
    def _check_level_up(self):
        """检查是否升级"""
        for level in sorted(self.LEVELS.keys(), reverse=True):
            if self.xp >= self.LEVELS[level]['xp_required']:
                self.level = level
                break
    
    def get_level(self):
        """获取当前等级"""
        return self.level
    
    def get_level_name(self):
        """获取当前等级名称"""
        return self.LEVELS.get(self.level, self.LEVELS[1])['name']
    
    def get_level_color(self):
        """获取当前等级颜色"""
        return self.LEVELS.get(self.level, self.LEVELS[1])['color']
    
    def get_xp(self):
        """获取当前经验值"""
        return self.xp
    
    def get_total_tokens(self):
        """获取累计Token消耗"""
        return self.total_tokens
    
    def xp_to_next_level(self):
        """计算升级所需经验值"""
        next_level = self.level + 1
        if next_level in self.LEVELS:
            return self.LEVELS[next_level]['xp_required'] - self.xp
        return 0  # 已满级
    
    def get_progress_percentage(self):
        """获取当前等级进度百分比"""
        current_level_xp = self.LEVELS[self.level]['xp_required']
        next_level_xp = self.LEVELS.get(self.level + 1, {}).get('xp_required', current_level_xp * 2)
        
        if next_level_xp == current_level_xp:
            return 100
        
        progress = (self.xp - current_level_xp) / (next_level_xp - current_level_xp) * 100
        return min(max(progress, 0), 100)
    
    def get_all_levels_info(self):
        """获取所有等级信息"""
        return self.LEVELS
    
    def get_level_up_rewards(self, level):
        """获取升级奖励"""
        rewards = {
            2: {'new_feature': '眼睛动画', 'description': '龙虾获得了生动的眼睛动画'},
            3: {'new_feature': '机械键盘', 'description': '龙虾开始敲击键盘'},
            4: {'new_feature': '多屏幕', 'description': '龙虾可以同时处理多个任务'},
            5: {'new_feature': '黑客风格', 'description': '龙虾获得了绿色矩阵风格'},
            6: {'new_feature': 'AI王座', 'description': '龙虾成为了AI龙虾王'},
        }
        return rewards.get(level, {'new_feature': '继续成长', 'description': '龙虾在不断进化'})
