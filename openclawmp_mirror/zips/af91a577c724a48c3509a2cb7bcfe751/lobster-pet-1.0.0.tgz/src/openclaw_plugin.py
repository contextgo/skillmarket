# -*- coding: utf-8 -*-
"""
OpenClaw Plugin for Lobster Pet
OpenClaw插件 - 让OpenClaw与桌宠联动

将此文件放入 ~/.stepclaw/extensions/lobster-pet-connector/
"""

import json
import os
import socket
import threading
import time
from pathlib import Path
from datetime import datetime


class LobsterPetConnector:
    """OpenClaw与Lobster Pet连接器"""
    
    def __init__(self):
        self.status_file = Path.home() / '.stepclaw' / 'lobster-pet-status.json'
        self.socket_port = 7654
        self.running = True
        
        # 当前状态
        self.current_status = {
            'is_working': False,
            'is_thinking': False,
            'is_idle': True,
            'session_count': 0,
            'last_activity': '',
            'timestamp': 0
        }
        
        # Token统计
        self.token_stats = {
            'total_tokens': 0,
            'session_tokens': 0,
            'last_update': 0
        }
        
    def start(self):
        """启动连接器"""
        print("[LobsterPet] Starting connector...")
        
        # 启动状态监控线程
        self.monitor_thread = threading.Thread(target=self._monitor_status, daemon=True)
        self.monitor_thread.start()
        
        # 启动Socket服务器
        self.socket_thread = threading.Thread(target=self._start_socket_server, daemon=True)
        self.socket_thread.start()
        
        print("[LobsterPet] Connector started!")
        
    def _monitor_status(self):
        """监控OpenClaw状态"""
        while self.running:
            try:
                # 获取OpenClaw状态
                status = self._get_openclaw_status()
                
                # 更新状态
                self.current_status.update(status)
                self.current_status['timestamp'] = time.time()
                
                # 写入状态文件
                self._write_status_file()
                
                # 检测状态变化
                self._detect_state_change()
                
                time.sleep(2)  # 每2秒检查一次
            except Exception as e:
                print(f"[LobsterPet] Monitor error: {e}")
                time.sleep(5)
    
    def _get_openclaw_status(self):
        """获取OpenClaw当前状态"""
        try:
            # 尝试读取OpenClaw状态
            state_dir = Path.home() / '.stepclaw'
            
            # 检查活跃会话
            sessions_dir = state_dir / 'sessions'
            active_sessions = 0
            thinking_sessions = 0
            
            if sessions_dir.exists():
                for session_file in sessions_dir.glob('*.json'):
                    try:
                        with open(session_file, 'r', encoding='utf-8') as f:
                            data = json.load(f)
                            if data.get('active', False):
                                active_sessions += 1
                            if data.get('thinking', False):
                                thinking_sessions += 1
                    except:
                        continue
            
            # 检查是否有工作在进行
            is_working = active_sessions > 0
            is_thinking = thinking_sessions > 0
            is_idle = not (is_working or is_thinking)
            
            return {
                'is_working': is_working,
                'is_thinking': is_thinking,
                'is_idle': is_idle,
                'session_count': active_sessions,
                'last_activity': datetime.now().isoformat()
            }
        except Exception as e:
            print(f"[LobsterPet] Get status error: {e}")
            return {
                'is_working': False,
                'is_thinking': False,
                'is_idle': True,
                'session_count': 0,
                'last_activity': ''
            }
    
    def _write_status_file(self):
        """写入状态文件"""
        try:
            data = {
                'status': self.current_status,
                'tokens': self.token_stats,
                'updated_at': datetime.now().isoformat()
            }
            
            # 使用临时文件然后重命名，保证原子性
            temp_file = self.status_file.with_suffix('.tmp')
            with open(temp_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            temp_file.replace(self.status_file)
        except Exception as e:
            print(f"[LobsterPet] Write status error: {e}")
    
    def _detect_state_change(self):
        """检测状态变化并通知"""
        # 这里可以添加状态变化时的特殊处理
        # 比如：开始工作时发送通知给桌宠
        pass
    
    def _start_socket_server(self):
        """启动Socket服务器"""
        try:
            server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            server.bind(('127.0.0.1', self.socket_port))
            server.listen(5)
            
            print(f"[LobsterPet] Socket server listening on port {self.socket_port}")
            
            while self.running:
                try:
                    client, addr = server.accept()
                    handler = threading.Thread(
                        target=self._handle_client,
                        args=(client,),
                        daemon=True
                    )
                    handler.start()
                except Exception as e:
                    print(f"[LobsterPet] Socket accept error: {e}")
        except Exception as e:
            print(f"[LobsterPet] Socket server error: {e}")
    
    def _handle_client(self, client):
        """处理客户端连接"""
        try:
            data = client.recv(1024).decode('utf-8')
            request = json.loads(data)
            
            action = request.get('action')
            
            if action == 'get_status':
                # 返回当前状态
                response = {
                    'success': True,
                    'data': {
                        'status': self.current_status,
                        'tokens': self.token_stats
                    }
                }
            elif action == 'set_state':
                # 设置桌宠状态（从OpenClaw接收）
                state = request.get('state')
                # 这里可以触发状态变更事件
                response = {'success': True, 'message': f'State set to {state}'}
            elif action == 'ping':
                response = {'success': True, 'message': 'pong'}
            else:
                response = {'success': False, 'error': 'Unknown action'}
            
            client.send(json.dumps(response).encode('utf-8'))
        except Exception as e:
            print(f"[LobsterPet] Handle client error: {e}")
        finally:
            client.close()
    
    def update_token_usage(self, tokens):
        """更新Token使用量（由OpenClaw调用）"""
        self.token_stats['session_tokens'] += tokens
        self.token_stats['total_tokens'] += tokens
        self.token_stats['last_update'] = time.time()
        
        # 立即写入状态文件
        self._write_status_file()
    
    def notify_state_change(self, old_state, new_state):
        """通知状态变化"""
        print(f"[LobsterPet] State changed: {old_state} -> {new_state}")
        
        # 可以在这里添加更多通知逻辑
        # 比如：发送系统通知、播放音效等
    
    def stop(self):
        """停止连接器"""
        self.running = False
        print("[LobsterPet] Connector stopped")


# 全局实例
_connector = None

def init():
    """初始化连接器（由OpenClaw调用）"""
    global _connector
    if _connector is None:
        _connector = LobsterPetConnector()
        _connector.start()
    return _connector

def get_connector():
    """获取连接器实例"""
    global _connector
    return _connector

# 如果直接运行此文件
if __name__ == '__main__':
    connector = LobsterPetConnector()
    connector.start()
    
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        connector.stop()
