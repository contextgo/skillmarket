# -*- coding: utf-8 -*-
"""
Lobster Pet for OpenClaw - Simple Version
桌面宠物龙虾 - 简化版，只监控当前对话
"""

import sys
import os
import json
import time
import threading
from pathlib import Path

from PyQt5.QtWidgets import (QApplication, QMainWindow, QLabel, QSystemTrayIcon, 
                             QMenu, QAction, QMessageBox)
from PyQt5.QtCore import Qt, QTimer, QPoint
from PyQt5.QtGui import QPixmap, QIcon

from lobster_sprite import LobsterSprite
from openclaw_connector import OpenClawConnector
from xp_system import XPSystem


class LobsterPet(QMainWindow):
    """主窗口类"""
    
    def __init__(self):
        super().__init__()
        
        self.config = self.load_config()
        self.sprite = LobsterSprite(self.config.get('level', 1))
        self.openclaw = OpenClawConnector()
        self.xp_system = XPSystem()
        
        self.current_state = 'idle'
        self.is_dragging = False
        self.drag_position = QPoint()
        self.manual_mode = False
        
        self.init_ui()
        self.init_tray()
        self.start_monitor()
        
    def load_config(self):
        """加载配置"""
        config_path = Path.home() / '.stepclaw' / 'lobster-pet-config.json'
        default = {'level': 1, 'xp': 0, 'total_tokens': 0, 'position': {'x': 100, 'y': 100}}
        
        if config_path.exists():
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    return {**default, **json.load(f)}
            except:
                pass
        return default
    
    def save_config(self):
        """保存配置"""
        config_path = Path.home() / '.stepclaw' / 'lobster-pet-config.json'
        self.config['position'] = {'x': self.x(), 'y': self.y()}
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
    
    def init_ui(self):
        """初始化UI"""
        self.setWindowFlags(Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint | Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)
        
        self.setFixedSize(64, 64)
        
        pos = self.config.get('position', {'x': 100, 'y': 100})
        self.move(pos['x'], pos['y'])
        
        self.lobster_label = QLabel(self)
        self.lobster_label.setFixedSize(64, 64)
        self.lobster_label.setAlignment(Qt.AlignCenter)
        
        self.status_label = QLabel(self)
        self.status_label.setFixedSize(64, 16)
        self.status_label.move(0, 48)
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet('QLabel { color: white; background: rgba(0,0,0,150); border-radius: 8px; font-size: 8px; }')
        self.status_label.hide()
        
        self.level_label = QLabel(self)
        self.level_label.setFixedSize(24, 16)
        self.level_label.move(40, 0)
        self.level_label.setAlignment(Qt.AlignCenter)
        self.level_label.setStyleSheet('QLabel { color: white; background: rgba(255,107,107,200); border-radius: 8px; font-size: 8px; font-weight: bold; }')
        self.level_label.setText(f"Lv.{self.config.get('level', 1)}")
        
        self.update_lobster_display()
        self.show()
    
    def init_tray(self):
        """初始化托盘"""
        self.tray_icon = QSystemTrayIcon(self)
        
        # 创建简单图标
        from PyQt5.QtGui import QPixmap, QColor
        pixmap = QPixmap(32, 32)
        pixmap.fill(QColor(255, 107, 107))
        self.tray_icon.setIcon(QIcon(pixmap))
        
        menu = QMenu()
        
        menu.addAction("显示", self.show)
        menu.addSeparator()
        
        status_menu = menu.addMenu("状态")
        status_menu.addAction("待机", lambda: self.set_state('idle', True))
        status_menu.addAction("工作", lambda: self.set_state('working', True))
        status_menu.addAction("思考", lambda: self.set_state('thinking', True))
        status_menu.addAction("休息", lambda: self.set_state('resting', True))
        
        menu.addSeparator()
        menu.addAction("查看统计", self.show_stats)
        menu.addAction("退出", self.quit_app)
        
        self.tray_icon.setContextMenu(menu)
        self.tray_icon.show()
    
    def start_monitor(self):
        """启动监控"""
        # 动画定时器
        self.anim_timer = QTimer(self)
        self.anim_timer.timeout.connect(self.update_animation)
        self.anim_timer.start(100)
        
        # 状态检查定时器
        self.check_timer = QTimer(self)
        self.check_timer.timeout.connect(self.check_status)
        self.check_timer.start(2000)  # 每2秒检查
        
        # Token监控线程
        def token_monitor():
            while True:
                try:
                    tokens = self.openclaw.get_token_usage()
                    if tokens > 0:
                        self.xp_system.add_tokens(tokens)
                        new_level = self.xp_system.get_level()
                        if new_level > self.config.get('level', 1):
                            self.config['level'] = new_level
                            self.sprite.set_level(new_level)
                            QTimer.singleShot(0, lambda: self.level_label.setText(f"Lv.{new_level}"))
                    time.sleep(5)
                except:
                    time.sleep(10)
        
        threading.Thread(target=token_monitor, daemon=True).start()
    
    def check_status(self):
        """检查状态"""
        if self.manual_mode:
            return
        
        try:
            status = self.openclaw.get_status()
            
            if status.get('is_working') and self.current_state != 'working':
                self.set_state('working')
            elif status.get('is_thinking') and self.current_state != 'thinking':
                self.set_state('thinking')
            elif status.get('is_idle') and self.current_state not in ['idle', 'resting']:
                self.set_state('idle')
        except Exception as e:
            print(f"Check error: {e}")
    
    def set_state(self, state, manual=False):
        """设置状态"""
        self.current_state = state
        
        if manual:
            self.manual_mode = True
            QTimer.singleShot(30000, lambda: setattr(self, 'manual_mode', False))
        
        names = {'idle': '待机', 'working': '工作中', 'thinking': '思考中', 'resting': '休息中'}
        self.status_label.setText(names.get(state, ''))
        self.status_label.show()
        QTimer.singleShot(3000, self.status_label.hide)
    
    def update_animation(self):
        """更新动画"""
        frame = self.sprite.get_next_frame(self.current_state)
        if frame:
            self.lobster_label.setPixmap(frame)
    
    def update_lobster_display(self):
        """更新显示"""
        frame = self.sprite.get_current_frame()
        if frame:
            self.lobster_label.setPixmap(frame)
    
    def show_stats(self):
        """显示统计"""
        try:
            level = self.config.get('level', 1)
            xp = self.xp_system.get_xp()
            total = self.xp_system.get_total_tokens()
            
            text = f"等级: Lv.{level} {self.sprite.get_level_name()}\n"
            text += f"经验值: {xp:,} XP\n"
            text += f"Token消耗: {total:,}\n"
            text += f"当前状态: {self.current_state}"
            
            QMessageBox.information(self, "龙虾状态", text)
        except Exception as e:
            QMessageBox.warning(self, "错误", str(e))
    
    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            self.is_dragging = True
            self.drag_position = event.globalPos() - self.frameGeometry().topLeft()
    
    def mouseMoveEvent(self, event):
        if self.is_dragging:
            self.move(event.globalPos() - self.drag_position)
    
    def mouseReleaseEvent(self, event):
        self.is_dragging = False
    
    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:
            states = ['idle', 'working', 'thinking', 'resting']
            idx = states.index(self.current_state)
            self.set_state(states[(idx + 1) % len(states)], True)
    
    def contextMenuEvent(self, event):
        self.tray_icon.contextMenu().exec_(event.globalPos())
    
    def quit_app(self):
        self.save_config()
        self.tray_icon.hide()
        QApplication.quit()
    
    def closeEvent(self, event):
        self.save_config()
        event.accept()


def main():
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    pet = LobsterPet()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
