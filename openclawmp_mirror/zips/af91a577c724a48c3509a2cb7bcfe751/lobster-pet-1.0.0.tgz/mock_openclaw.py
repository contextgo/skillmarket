# -*- coding: utf-8 -*-
"""
Mock OpenClaw Session Generator
模拟OpenClaw会话生成器 - 用于测试桌宠联动

运行此脚本可以模拟OpenClaw活动，测试桌宠状态切换
"""

import json
import time
import random
from pathlib import Path
from datetime import datetime


def create_mock_session(session_type='working'):
    """创建模拟会话"""
    session_dir = Path.home() / '.stepclaw' / 'sessions'
    session_dir.mkdir(parents=True, exist_ok=True)
    
    session_id = f"mock-{session_type}-{int(time.time())}"
    session_file = session_dir / f"{session_id}.json"
    
    # 创建模拟消息
    messages = []
    
    if session_type == 'working':
        # 工作状态：普通对话
        messages = [
            {'role': 'user', 'content': 'Hello', 'timestamp': time.time(), 'tokens': 10},
            {'role': 'assistant', 'content': 'Hi there!', 'timestamp': time.time(), 'tokens': 50},
        ]
    elif session_type == 'thinking':
        # 思考状态：带reasoning字段
        messages = [
            {'role': 'user', 'content': 'Solve this', 'timestamp': time.time(), 'tokens': 20},
            {'role': 'assistant', 'content': 'Solution...', 'reasoning': 'Let me think...', 'timestamp': time.time(), 'tokens': 200},
        ]
    
    session_data = {
        'id': session_id,
        'start_time': datetime.now().isoformat(),
        'messages': messages,
        'active': True,
        'thinking': session_type == 'thinking'
    }
    
    with open(session_file, 'w', encoding='utf-8') as f:
        json.dump(session_data, f, ensure_ascii=False, indent=2)
    
    print(f"Created mock session: {session_id}")
    return session_id


def cleanup_mock_sessions():
    """清理模拟会话"""
    session_dir = Path.home() / '.stepclaw' / 'sessions'
    if not session_dir.exists():
        return
    
    count = 0
    for session_file in session_dir.glob('mock-*.json'):
        session_file.unlink()
        count += 1
    
    print(f"Cleaned up {count} mock sessions")


def simulate_activity():
    """模拟OpenClaw活动"""
    print("=" * 60)
    print("OpenClaw Activity Simulator")
    print("=" * 60)
    print()
    
    # 清理旧会话
    cleanup_mock_sessions()
    
    # 模拟1: 工作状态
    print("[1] Simulating WORKING state...")
    create_mock_session('working')
    print("   -> Lobster should switch to WORKING (typing animation)")
    time.sleep(3)
    
    # 模拟2: 思考状态
    print()
    print("[2] Simulating THINKING state...")
    cleanup_mock_sessions()
    create_mock_session('thinking')
    print("   -> Lobster should switch to THINKING (thinking bubble)")
    time.sleep(3)
    
    # 模拟3: 空闲状态
    print()
    print("[3] Simulating IDLE state...")
    cleanup_mock_sessions()
    print("   -> Lobster should switch to IDLE (walking animation)")
    time.sleep(3)
    
    # 清理
    print()
    print("[4] Cleaning up...")
    cleanup_mock_sessions()
    
    print()
    print("=" * 60)
    print("Simulation complete!")
    print("=" * 60)
    print()
    print("Check your Lobster Pet to see if it responded correctly.")


if __name__ == '__main__':
    simulate_activity()
