# -*- coding: utf-8 -*-
"""
Lobster Pet for OpenClaw
桌面宠物龙虾 - Windows启动脚本
"""

import sys
import os
from pathlib import Path

# 添加src目录到路径
src_dir = Path(__file__).parent / 'src'
sys.path.insert(0, str(src_dir))

# 导入主模块
from main import main

if __name__ == '__main__':
    main()
