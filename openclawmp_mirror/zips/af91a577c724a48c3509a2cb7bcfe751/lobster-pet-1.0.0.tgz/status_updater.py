# -*- coding: utf-8 -*-
"""
Status Updater for Current Session
在当前对话中更新桌宠状态

将此代码集成到对话处理中
"""

import json
import time
from pathlib import Path

def set_working():
    """设置为工作状态"""
    _update_status(True, False, False, "Working on task...")

def set_thinking():
    """设置为思考状态"""
    _update_status(False, True, False, "Thinking...")

def set_idle():
    """设置为空闲状态"""
    _update_status(False, False, True, "Idle")

def _update_status(working, thinking, idle, message):
    """更新状态文件"""
    try:
        status_file = Path.home() / '.stepclaw' / 'lobster-pet-status.json'
        
        data = {
            'is_working': working,
            'is_thinking': thinking,
            'is_idle': idle,
            'message': message,
            'timestamp': time.time()
        }
        
        with open(status_file, 'w', encoding='utf-8') as f:
            json.dump(data, f)
            
    except Exception as e:
        pass  # 静默失败，不影响对话


# 自动检测状态（简单规则）
class StatusAutoDetector:
    """自动检测对话状态"""
    
    def __init__(self):
        self.last_activity = time.time()
        self.is_processing = False
    
    def on_user_message(self):
        """用户发送消息时"""
        self.is_processing = True
        self.last_activity = time.time()
        set_working()
    
    def on_assistant_start(self):
        """助手开始回复时"""
        set_thinking()
    
    def on_assistant_end(self):
        """助手回复结束时"""
        self.is_processing = False
        self.last_activity = time.time()
        # 3秒后恢复空闲
        import threading
        def reset():
            time.sleep(3)
            if not self.is_processing:
                set_idle()
        threading.Thread(target=reset, daemon=True).start()


# 全局实例
_status_detector = StatusAutoDetector()

def update_status_on_message():
    """消息处理时调用"""
    _status_detector.on_user_message()

def update_status_on_response_start():
    """开始回复时调用"""
    _status_detector.on_assistant_start()

def update_status_on_response_end():
    """回复结束时调用"""
    _status_detector.on_assistant_end()


if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        cmd = sys.argv[1]
        if cmd == 'working':
            set_working()
            print("Status: WORKING")
        elif cmd == 'thinking':
            set_thinking()
            print("Status: THINKING")
        elif cmd == 'idle':
            set_idle()
            print("Status: IDLE")
        else:
            print("Usage: python status_updater.py [working|thinking|idle]")
    else:
        print("Status updater ready")
