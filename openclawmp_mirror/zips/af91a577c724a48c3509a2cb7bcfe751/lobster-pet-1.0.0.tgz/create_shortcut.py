# -*- coding: utf-8 -*-
"""Create desktop shortcut with icon"""
import os
import sys
from pathlib import Path

# 创建快捷方式
def create_shortcut():
    desktop = Path.home() / 'Desktop'
    target = Path.home() / '.stepclaw' / 'skills' / 'lobster-pet' / 'lobster_pet.py'
    icon = Path.home() / '.stepclaw' / 'skills' / 'lobster-pet' / 'assets' / 'icon.ico'
    shortcut = desktop / 'Lobster Pet.lnk'
    python = r'C:\Users\hyss\AppData\Local\Programs\Python\Python313\pythonw.exe'
    
    # 使用PowerShell创建快捷方式
    ps_script = f'''
    $WshShell = New-Object -ComObject WScript.Shell
    $Shortcut = $WshShell.CreateShortcut("{shortcut}")
    $Shortcut.TargetPath = "{python}"
    $Shortcut.Arguments = "{target}"
    $Shortcut.WorkingDirectory = "{target.parent}"
    $Shortcut.IconLocation = "{icon},0"
    $Shortcut.Description = "Lobster Pet for OpenClaw"
    $Shortcut.Save()
    Write-Output "Shortcut created successfully"
    '''
    
    import subprocess
    result = subprocess.run(['powershell', '-Command', ps_script], 
                          capture_output=True, text=True)
    print(result.stdout)
    if result.stderr:
        print("Error:", result.stderr)

if __name__ == '__main__':
    create_shortcut()
