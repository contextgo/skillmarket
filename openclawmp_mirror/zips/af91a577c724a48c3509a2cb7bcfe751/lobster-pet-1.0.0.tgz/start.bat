@echo off
chcp 65001 >nul
cd /d "%~dp0"
C:\Users\hyss\AppData\Local\Programs\Python\Python313\pythonw.exe lobster_pet.py
