@echo off
chcp 65001 >nul
echo 🦞 Lobster Pet for OpenClaw - 安装脚本
echo ==========================================
echo.

REM 检查Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ 错误: 未找到Python，请先安装Python 3.8+
    pause
    exit /b 1
)

echo ✅ Python已安装

REM 安装依赖
echo.
echo 📦 正在安装依赖...
pip install -r requirements.txt

if errorlevel 1 (
    echo ❌ 依赖安装失败
    pause
    exit /b 1
)

echo ✅ 依赖安装完成

REM 创建桌面快捷方式
echo.
echo 🖥️ 正在创建桌面快捷方式...
set "DESKTOP=%USERPROFILE%\Desktop"
set "TARGET=%CD%\lobster_pet.py"
set "SHORTCUT=%DESKTOP%\🦞 Lobster Pet.lnk"

powershell -Command "$WshShell = New-Object -comObject WScript.Shell; $Shortcut = $WshShell.CreateShortcut('%SHORTCUT%'); $Shortcut.TargetPath = 'python'; $Shortcut.Arguments = '%TARGET%'; $Shortcut.WorkingDirectory = '%CD%'; $Shortcut.IconLocation = '%CD%\assets\icon.ico,0'; $Shortcut.Save()"

echo ✅ 桌面快捷方式已创建

REM 创建开机启动项
echo.
echo 🔄 是否添加到开机启动？(Y/N)
set /p choice=
if /i "%choice%"=="Y" (
    set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
    copy "%SHORTCUT%" "%STARTUP%\🦞 Lobster Pet.lnk" >nul
    echo ✅ 已添加到开机启动
)

echo.
echo ==========================================
echo 🎉 安装完成！
echo.
echo 启动方式:
echo   1. 双击桌面快捷方式
echo   2. 运行: python lobster_pet.py
echo.
pause
