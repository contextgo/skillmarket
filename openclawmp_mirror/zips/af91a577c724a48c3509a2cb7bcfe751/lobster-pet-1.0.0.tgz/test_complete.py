# -*- coding: utf-8 -*-
"""
Complete Test for Lobster Pet
"""

import sys
import time
import json
from pathlib import Path

sys.path.insert(0, 'src')

print("=" * 60)
print("Lobster Pet Complete Test")
print("=" * 60)
print()

# Test 1: Status File Write
print("[Test 1] Status File Write")
print("-" * 40)

status_file = Path.home() / '.stepclaw' / 'lobster-pet-status.json'

# Write working status
data = {
    'is_working': True,
    'is_thinking': False,
    'is_idle': False,
    'message': 'Working',
    'timestamp': time.time()
}
with open(status_file, 'w', encoding='utf-8') as f:
    json.dump(data, f)
print("[OK] Working status written")

time.sleep(1)

# Write thinking status
data['is_working'] = False
data['is_thinking'] = True
data['is_idle'] = False
data['message'] = 'Thinking'
data['timestamp'] = time.time()
with open(status_file, 'w', encoding='utf-8') as f:
    json.dump(data, f)
print("[OK] Thinking status written")

time.sleep(1)

# Write idle status
data['is_working'] = False
data['is_thinking'] = False
data['is_idle'] = True
data['message'] = 'Idle'
data['timestamp'] = time.time()
with open(status_file, 'w', encoding='utf-8') as f:
    json.dump(data, f)
print("[OK] Idle status written")

print()

# Test 2: Status File Read
print("[Test 2] Status File Read")
print("-" * 40)

from openclaw_connector import OpenClawConnector

oc = OpenClawConnector()
status = oc.get_status()
print(f"Status read: {status}")
print(f"  is_working: {status['is_working']}")
print(f"  is_thinking: {status['is_thinking']}")
print(f"  is_idle: {status['is_idle']}")

print()

# Test 3: Status Switching
print("[Test 3] Status Switching (6 seconds)")
print("-" * 40)
print("If Lobster Pet is running, watch for animation changes!")
print()

states = [
    (True, False, False, "WORKING"),
    (False, True, False, "THINKING"),
    (False, False, True, "IDLE"),
]

for working, thinking, idle, name in states:
    data = {
        'is_working': working,
        'is_thinking': thinking,
        'is_idle': idle,
        'message': name,
        'timestamp': time.time()
    }
    with open(status_file, 'w', encoding='utf-8') as f:
        json.dump(data, f)
    
    print(f"Set to: {name}")
    
    # Verify
    status = oc.get_status()
    expected = 'working' if working else ('thinking' if thinking else 'idle')
    actual = 'working' if status['is_working'] else ('thinking' if status['is_thinking'] else 'idle')
    
    if actual == expected:
        print(f"  [OK] Verified: {actual}")
    else:
        print(f"  [FAIL] Expected {expected}, got {actual}")
    
    time.sleep(2)

print()
print("=" * 60)
print("Test completed!")
print("=" * 60)
