# -*- coding: utf-8 -*-
"""
Real-time Test for Lobster Pet
实时测试 - 模拟真实对话场景
"""

import sys
import json
import time
from pathlib import Path

# 创建实时更新的session
def create_live_session():
    session_dir = Path.home() / '.stepclaw' / 'sessions'
    session_dir.mkdir(parents=True, exist_ok=True)
    
    session_file = session_dir / 'live-test-session.json'
    
    print("Creating live session...")
    print("This will update every 2 seconds for 30 seconds")
    print("Watch your Lobster Pet for status changes!")
    print()
    
    for i in range(15):  # 30秒
        now = time.time()
        
        # 模拟不同状态
        if i < 5:
            # 工作状态
            messages = [
                {'role': 'user', 'content': f'Question {i}', 'timestamp': now - 2, 'tokens': 50},
                {'role': 'assistant', 'content': f'Answer {i}', 'timestamp': now, 'tokens': 200}
            ]
            state = "WORKING"
        elif i < 10:
            # 思考状态（有reasoning）
            messages = [
                {'role': 'user', 'content': f'Complex question {i}', 'timestamp': now - 3, 'tokens': 100},
                {'role': 'assistant', 'content': f'Solution {i}', 'reasoning': f'Thinking process {i}...', 'timestamp': now, 'tokens': 500}
            ]
            state = "THINKING"
        else:
            # 空闲状态（无新消息）
            messages = [
                {'role': 'user', 'content': 'Old question', 'timestamp': now - 60, 'tokens': 50},
                {'role': 'assistant', 'content': 'Old answer', 'timestamp': now - 58, 'tokens': 200}
            ]
            state = "IDLE"
        
        session_data = {
            'id': 'live-test-session',
            'messages': messages,
            'active': True
        }
        
        with open(session_file, 'w', encoding='utf-8') as f:
            json.dump(session_data, f)
        
        print(f"[{i*2}s] State: {state} - File updated")
        time.sleep(2)
    
    # 清理
    session_file.unlink(missing_ok=True)
    print()
    print("Live test complete!")
    print("Session file cleaned up")

if __name__ == '__main__':
    create_live_session()
