# -*- coding: utf-8 -*-
"""
Lobster Pet Test Script
测试脚本 - 验证核心功能
"""

import sys
sys.path.insert(0, 'src')

print("=" * 50)
print("Lobster Pet for OpenClaw - Test")
print("=" * 50)
print()

# Test 1: XP System
print("[Test 1] XP System")
print("-" * 30)
try:
    from xp_system import XPSystem
    xp = XPSystem()
    
    # Add some tokens
    xp_gained = xp.add_tokens(1500000)  # 1.5M tokens
    print(f"Add Tokens: 1,500,000")
    print(f"Gain XP: {xp_gained:,}")
    print(f"Current Level: Lv.{xp.get_level()}")
    print(f"Level Name: {xp.get_level_name()}")
    print(f"Current XP: {xp.get_xp():,}")
    print(f"Total Tokens: {xp.get_total_tokens():,}")
    print(f"Progress: {xp.get_progress_percentage():.1f}%")
    print(f"Next Level Need: {xp.xp_to_next_level():,} XP")
    print("[PASS] XP System OK")
except Exception as e:
    print(f"[FAIL] XP System Error: {e}")

print()

# Test 2: OpenClaw Connector
print("[Test 2] OpenClaw Connector")
print("-" * 30)
try:
    from openclaw_connector import OpenClawConnector
    oc = OpenClawConnector()
    
    status = oc.get_status()
    print(f"OpenClaw Running: {status['is_running']}")
    print(f"Working: {status['is_working']}")
    print(f"Thinking: {status['is_thinking']}")
    print(f"Active Sessions: {status['session_count']}")
    
    tokens = oc.get_token_usage()
    print(f"Token Usage Delta: {tokens}")
    
    print("[PASS] OpenClaw Connector OK")
except Exception as e:
    print(f"[FAIL] OpenClaw Connector Error: {e}")

print()

# Test 3: Lobster Sprite
print("[Test 3] Lobster Sprite")
print("-" * 30)
try:
    from lobster_sprite import LobsterSprite
    from PyQt5.QtGui import QPixmap
    
    # Test different levels
    for level in [1, 3, 6]:
        sprite = LobsterSprite(level)
        frame = sprite.create_pixel_lobster('idle', 0)
        print(f"Level {level}: {sprite.get_level_name()}")
        print(f"  - Color: {sprite.colors['body']}")
        print(f"  - Frame Size: {frame.size().width()}x{frame.size().height()}")
    
    # Test different states
    sprite = LobsterSprite(3)
    for state in ['idle', 'working', 'thinking', 'resting']:
        frame = sprite.create_pixel_lobster(state, 0)
        print(f"State {state}: Render OK")
    
    print("[PASS] Lobster Sprite OK")
except Exception as e:
    print(f"[FAIL] Lobster Sprite Error: {e}")

print()
print("=" * 50)
print("Test Complete!")
print("=" * 50)
