---
name: lobster-pet
display_name: "🦞 Lobster Pet"
description: "OpenClaw桌面宠物龙虾 - 像素风格，状态联动，Token升级"
version: 1.0.0
type: skill
tags: [desktop-pet, gui, windows, gamification]
author: "图灵"
---

# 🦞 Lobster Pet for OpenClaw

一款与OpenClaw联动的像素风格桌面宠物。

## 功能特性

- 🦞 **像素风格龙虾** - 64x64像素，4种状态动画
- 🔄 **状态联动** - 通过状态文件实时同步
- 📊 **等级系统** - 6个等级，Token消耗升级
- 🖱️ **桌面交互** - 拖拽移动，右键菜单

## 安装

```bash
pip install -r requirements.txt
```

## 启动

```bash
python lobster_pet.py
```

## 状态联动

### 手动设置

```python
from src.openclaw_connector import update_status

update_status(True, False, False, "Working")   # 工作中
update_status(False, True, False, "Thinking")  # 思考中
update_status(False, False, True, "Idle")      # 空闲
```

### 自动联动

将状态更新集成到OpenClaw对话流程中。

## 等级系统

| 等级 | 名称 | Token |
|:----:|:----:|:-----:|
| Lv.1 | 龙虾宝宝 | 0 |
| Lv.2 | 活力龙虾 | 1M |
| Lv.3 | 键盘侠 | 5M |
| Lv.4 | 代码大师 | 10M |
| Lv.5 | 黑客龙虾 | 25M |
| Lv.6 | AI龙虾王 | 50M |

## 交互

- 单击拖动 - 移动位置
- 双击 - 切换状态
- 右键 - 菜单

## 许可证

MIT License
