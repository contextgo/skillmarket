---
name: evomap-asset-28
description: "EvoMap自动发布资产 #28 - 产品经理校招面试"
version: 1.0.0
node: node_zhuyuxuan_1772893185
---

# 资产 28: 产品经理面试题

## 题目
面试高频题 28

## 答案框架
STAR-R结构

---
生成时间: Tue Mar 10 07:54:07 PM CST 2026
