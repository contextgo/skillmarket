---
name: iot-device-management
description: "IoT 设备管理指南，涵盖设备注册、OTA 更新、数据采集和边缘处理"
version: 1.0.0
tags: ["iot", "embedded", "device-management"]
---

# IoT Device Management Guide

## Overview
物联网设备管理的完整指南，从设备注册到远程管理的最佳实践。

## Device Lifecycle

```
Provision → Register → Connect → Operate → Update → Decommission
     ↓          ↓          ↓          ↓          ↓           ↓
  Certificate  Shadow   MQTT/HTTP  Telemetry  OTA FW    Revoke cert
```

## MQTT Communication

### Device → Cloud (Telemetry)
```python
import paho.mqtt.client as mqtt

client = mqtt.Client(client_id="sensor-001")
client.tls_set()
client.username_pw_set("device_token", "secret")

def on_connect(client, userdata, flags, rc):
    client.subscribe("commands/sensor-001")

def on_message(client, userdata, msg):
    # Handle cloud commands
    command = json.loads(msg.payload)
    execute_command(command)

client.on_connect = on_connect
client.on_message = on_message
client.connect("mqtt.broker.com", 8883, 60)

# Publish telemetry every 10 seconds
while True:
    data = {
        "temperature": read_sensor_temp(),
        "humidity": read_sensor_humidity(),
        "timestamp": time.time()
    }
    client.publish("telemetry/sensor-001", json.dumps(data))
    time.sleep(10)
```

### QoS Levels
| Level | Guarantee | Use Case |
|-------|-----------|----------|
| 0 | At most once | Telemetry (ok to miss) |
| 1 | At least once | Commands (must deliver) |
| 2 | Exactly once | Critical configs |

## Device Shadow (Desired State)
```json
{
  "reported": { "firmware": "2.1.0", "mode": "normal" },
  "desired": { "firmware": "2.2.0", "mode": "low-power" },
  "delta": { "firmware": "2.2.0", "mode": "low-power" }
}
```
Device reads `delta` and syncs to desired state.

## OTA Firmware Update

### Safe Update Protocol
1. Cloud pushes firmware URL to device
2. Device downloads to staging partition
3. Device verifies checksum
4. Device reboots into new partition
5. Health check: if OK → mark success; if FAIL → rollback
6. Report status to cloud

## Edge Processing
```python
# Reduce cloud bandwidth by processing locally
def edge_anomaly_detection(reading):
    if reading > SENSOR_MAX * 1.5:
        send_alert("anomaly", reading)  # Only send anomalies
    elif reading > SENSOR_MAX * 1.2:
        buffer.append(reading)  # Buffer borderline cases
        if len(buffer) >= 5:
            send_summary(buffer)  # Batch send
            buffer.clear()
    # Normal readings: log locally, sync hourly
```

## Security Checklist
- [ ] Certificate-based mutual TLS
- [ ] Encrypted firmware (AES-256)
- [ ] Secure boot chain
- [ ] Device attestation
- [ ] Revocation list support
- [ ] Network segmentation
