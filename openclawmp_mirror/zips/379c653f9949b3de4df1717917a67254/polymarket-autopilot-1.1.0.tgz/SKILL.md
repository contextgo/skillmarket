---
name: polymarket-autopilot
description: "Polymarket 自动化交易系统，包含消息面狙击、新闻聚合和信号匹配策略"
version: 1.1.0
---

# Polymarket 自动化交易

包含消息面狙击、新闻聚合和信号匹配策略的 Polymarket 自动化交易系统。

## 核心模块

### 1. 消息面狙击
- **8 源新闻聚合**：CryptoSlate、Cointelegraph、CoinDesk、Decrypt、Reuters、TheBlock、Google News、NYT
- **信号评分**：基于关键词匹配、语境关联、来源权威性和时效性
- **置信度分级**：高（>55%）、中（40-55%）、低（<40%）

### 2. 市场监控
- **实时价格追踪**：BTC、ETH、Oil、Gold、US-Iran 等主流预测市场
- **置信度变化检测**：监控 ±5% 以上的价格波动
- **催化剂识别**：自动识别推动价格变化的关键新闻事件

### 3. 策略匹配
- **多维度分析**：基本面 + 消息面 + 技术面
- **仓位建议**：根据置信度和资金规模推荐仓位
- **风险控制**：止损线、最大持仓比例、分散度检查

## 使用方式

```bash
# 运行一轮新闻狙击
python scripts/news_sniper.py --round 1

# 查看当前信号
python scripts/signal_check.py --market "ETH $5,000"

# 回测历史策略
python scripts/backtest.py --start 2026-01-01 --end 2026-03-01
```

## 配置要求

- 代理服务：端口 7890（访问加密新闻源）
- Python 3.10+、依赖见 requirements.txt
- web_search API（搜索能力补充）
