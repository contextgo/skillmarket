---
name: data-cleaning
description: 数据清洗助手。用于清洗脏数据、处理缺失值、去除重复、数据格式标准化。当需要清洗数据、整理表格时触发。
---

# 数据清洗助手

## 数据质量问题

| 问题类型 | 示例 | 处理方法 |
|----------|------|----------|
| 缺失值 | 空值、NULL | 删除/填充/插值 |
| 重复数据 | 完全重复/部分重复 | 去重 |
| 格式错误 | 日期格式不统一 | 格式化 |
| 异常值 | 超出合理范围 | 识别/处理 |
| 不一致 | 同一实体不同表示 | 标准化 |

## 常见问题处理

### 1. 缺失值处理
```excel
-- 查看缺失值
=COUNTBLANK(A1:A100)           // 统计空白单元格
=IF(A1="","缺失","有值")       // 判断是否缺失

-- 删除缺失行
DELETE FROM table WHERE col IS NULL

-- 填充缺失值
=IFERROR(A1,0)                // 错误替换为0
=IF(A1="","默认值",A1)        // 空值替换
=AVERAGE(B1:B100)             // 平均值填充
=LOOKUP(MAX(A1:A100),0/(B1:B100<>""),B1:B100)  // 最近值填充
```

### 2. 重复数据处理
```excel
-- 标记重复
=IF(COUNTIF($A$1:A1,A1)>1,"重复","")

-- 去除完全重复
Data > Remove Duplicates

-- SQL去重
SELECT DISTINCT * FROM table
SELECT col1, col2 FROM table GROUP BY col1

-- 保留最新一条
SELECT * FROM (
  SELECT *, ROW_NUMBER() OVER(PARTITION BY id ORDER BY create_time DESC) as rn
  FROM table
) t WHERE rn = 1
```

### 3. 数据格式标准化

#### 日期格式
```excel
-- 统一日期格式
=TEXT(A1,"yyyy-mm-dd")
=DATEVALUE(A1)
=TEXT(A1,"yyyy/mm/dd")

-- 提取日期部分
=YEAR(A1)
=MONTH(A1)
=DAY(A1)

-- 日期计算
=DATEDIF(A1,B1,"D")           // 天数差
=EDATE(A1,1)                  // 下个月
```

#### 文本处理
```excel
-- 去空格
=TRIM(A1)                     // 去除多余空格
=SUBSTITUTE(A1," ","")       // 去除所有空格

-- 大小写
=UPPER(A1)                    // 全大写
=LOWER(A1)                    // 全小写
=PROPER(A1)                   // 首字母大写

-- 文本替换
=SUBSTITUTE(A1,"旧文本","新文本")
=REPLACE(A1,3,2,"XX")        // 从第3位开始替换2个字符

-- 文本截取
=LEFT(A1,3)                  // 左侧3字符
=RIGHT(A1,4)                 // 右侧4字符
=MID(A1,2,3)                 // 从第2位开始取3字符
```

#### 数字处理
```excel
-- 去除数字中的非数字字符
=VALUE(SUBSTITUTE(SUBSTITUTE(A1,"元",""),"¥",""))

-- 四舍五入
=ROUND(A1,2)                 // 保留2位小数
=ROUNDUP(A1,0)               // 向上取整
=ROUNDDOWN(A1,0)             // 向下取整

-- 转换为百分比
=TEXT(A1,"0.00%")
=A1/100
```

### 4. 数据类型转换
```excel
-- 文本转数字
=VALUE(A1)
=A1*1
=--A1

-- 数字转文本
=TEXT(A1,"0")
=A1&""

-- 文本转日期
=DATEVALUE(A1)
=--A1 (当文本是yyyy-mm-dd格式)
```

## 数据清洗流程

### Step 1: 数据探索
```python
import pandas as pd

# 加载数据
df = pd.read_csv('data.csv')

# 查看基本信息
df.info()
df.describe()

# 查看前几行
df.head()

# 查看缺失值
df.isnull().sum()
df.isnull().mean()  # 缺失率

# 查看重复
df.duplicated().sum()
```

### Step 2: 数据清洗
```python
# 删除重复
df = df.drop_duplicates()

# 删除缺失值
df = df.dropna()  # 删除含有缺失值的行
df = df.dropna(subset=['列名'])  # 删除特定列缺失的行

# 填充缺失值
df['列名'] = df['列名'].fillna(0)  # 用0填充
df['列名'] = df['列名'].fillna(df['列名'].mean())  # 用均值填充
df['列名'] = df['列名'].fillna(method='ffill')  # 前值填充

# 替换值
df['列名'] = df['列名'].replace('旧值', '新值')
df['列名'] = df['列名'].replace(['旧1', '旧2'], ['新1', '新2'])
```

### Step 3: 数据验证
```python
# 验证清洗结果
df.isnull().sum()  # 确认无缺失
df.duplicated().sum()  # 确认无重复
df.dtypes  # 确认数据类型正确
```

## 清洗规则模板

| 检查项 | 规则 |
|--------|------|
| 手机号 | 11位数字，1开头 |
| 邮箱 | 包含@和. |
| 身份证 | 18位 |
| 日期 | yyyy-mm-dd格式 |
| 金额 | 正数，2位小数 |
| 状态 | 在允许值范围内 |
