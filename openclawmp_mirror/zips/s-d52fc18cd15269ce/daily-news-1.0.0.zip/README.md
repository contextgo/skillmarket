# Daily News 每日新闻订阅

抓取 36氪 RSS 新闻，生成每日简报。

## 使用方法

### 1. 手动运行

```powershell
PowerShell -ExecutionPolicy Bypass -File "daily-news.ps1"
```

### 2. 查看输出

运行后在工作目录生成：
- `INBOX.md` - 简报内容（用于推送）
- `INBOX_NEWS_YYYY-MM-DD.md` - 完整新闻存档
- `logs/daily-news-YYYY-MM-DD.log` - 运行日志

### 3. 配置定时推送（OpenClaw Cron）

```json
{
  "name": "Daily News",
  "schedule": "0 9 * * *",
  "sessionTarget": "main",
  "payload": {
    "kind": "systemEvent",
    "event": {
      "type": "custom",
      "text": "请执行：1) PowerShell -ExecutionPolicy Bypass -File \"<脚本路径>\\daily-news.ps1\"; 2) 读取 INBOX.md; 3) 使用 message 工具发送到 feishu 通道"
    }
  },
  "delivery": {
    "mode": "announce",
    "channel": "feishu"
  }
}
```

### 4. 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| WorkDir | string | `~/.openclaw/workspace` | 工作目录 |
| MaxNews | int | 15 | 抓取新闻条数 |

```powershell
# 示例：抓取20条新闻
.\daily-news.ps1 -MaxNews 20
```

## 自定义 RSS 源

修改脚本中的 RSS URL 即可切换新闻源：

```powershell
$resp = Invoke-WebRequest -Uri "https://36kr.com/feed" -UseBasicParsing -TimeoutSec 30
# 替换为其他 RSS 源，如：
# - BBC: https://feeds.bbci.co.uk/news/rss.xml
# - TechCrunch: https://techcrunch.com/feed/
# - 少数派: https://sspai.com/feed
```

## 数据源

- 36氪 RSS: https://36kr.com/feed
- 科技与创业新闻
- 更新时间：每天 09:00 北京时间