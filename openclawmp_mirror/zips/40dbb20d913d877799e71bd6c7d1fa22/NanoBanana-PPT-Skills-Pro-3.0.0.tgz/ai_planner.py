#!/usr/bin/env python3
"""
AI Content Planner - 智能PPT内容规划器

使用大语言模型分析用户输入，自动生成PPT结构和内容规划。
支持多种场景：商务汇报、产品介绍、教学课件、数据报告等。
"""

import json
import os
import sys
from typing import Dict, List, Optional


def plan_ppt_with_llm(topic: str, pages: int, style: str, audience: str = "") -> Dict:
    """
    使用LLM生成PPT规划
    
    由于当前环境使用StepFun模型，我们通过结构化模板来生成规划
    实际部署时可接入LLM API进行智能生成
    """
    
    # 根据主题类型智能选择模板
    templates = {
        "business": {
            "structure": ["cover", "overview", "problem", "solution", "market", "product", "team", "financial", "milestone", "summary"],
            "default_pages": 10,
        },
        "product": {
            "structure": ["cover", "pain_point", "solution", "features", "demo", "advantages", "cases", "pricing", "faq", "contact"],
            "default_pages": 10,
        },
        "education": {
            "structure": ["cover", "objectives", "theory", "examples", "practice", "summary", "homework"],
            "default_pages": 7,
        },
        "report": {
            "structure": ["cover", "executive_summary", "background", "methodology", "findings", "analysis", "recommendations", "conclusion"],
            "default_pages": 8,
        },
        "pitch": {
            "structure": ["cover", "hook", "problem", "solution", "traction", "market", "business_model", "team", "ask", "closing"],
            "default_pages": 10,
        },
    }
    
    # 检测主题类型
    topic_lower = topic.lower()
    if any(word in topic_lower for word in ["融资", "路演", "pitch", "invest"]):
        template_type = "pitch"
    elif any(word in topic_lower for word in ["产品", "product", "介绍", "intro"]):
        template_type = "product"
    elif any(word in topic_lower for word in ["课程", "教学", "培训", "course", "education"]):
        template_type = "education"
    elif any(word in topic_lower for word in ["报告", "分析", "调研", "report", "analysis"]):
        template_type = "report"
    else:
        template_type = "business"
    
    template = templates[template_type]
    structure = template["structure"]
    
    # 根据页数调整结构
    if pages <= 5:
        # 精简版：封面 + 3内容 + 总结
        selected = [structure[0]] + structure[1:pages-1] + [structure[-1]]
    elif pages >= len(structure):
        selected = structure
    else:
        # 智能选择关键页面
        selected = [structure[0]]  # 封面
        step = (len(structure) - 2) / (pages - 2)
        for i in range(1, pages - 1):
            idx = min(int(i * step), len(structure) - 2)
            selected.append(structure[idx])
        selected.append(structure[-1])  # 总结
    
    # 生成内容
    slides = []
    for i, page_type in enumerate(selected[:pages], 1):
        content = generate_page_content(page_type, topic, i, pages)
        slides.append({
            "slide_number": i,
            "page_type": map_page_type(page_type, i, pages),
            "content": content
        })
    
    return {
        "title": topic,
        "type": template_type,
        "audience": audience,
        "style": style,
        "slides": slides
    }


def map_page_type(page_type: str, current: int, total: int) -> str:
    """映射页面类型到显示类型"""
    if current == 1:
        return "cover"
    elif current == total:
        return "data"
    elif page_type in ["financial", "findings", "analysis", "market"]:
        return "data"
    else:
        return "content"


def generate_page_content(page_type: str, topic: str, current: int, total: int) -> str:
    """根据页面类型生成内容"""
    
    content_map = {
        "cover": f"{topic}\n副标题/演讲者",
        
        "overview": "内容概览\n- 本次汇报的主要内容\n- 关键要点预览\n- 预期收获",
        
        "problem": "问题与挑战\n- 当前面临的核心问题\n- 市场痛点分析\n- 现有解决方案的不足",
        
        "solution": "解决方案\n- 我们的核心方案\n- 创新点与优势\n- 技术/方法路径",
        
        "product": "产品介绍\n- 核心功能展示\n- 产品特色亮点\n- 用户使用场景",
        
        "features": "功能特性\n- 核心功能一\n- 核心功能二\n- 核心功能三",
        
        "market": "市场分析\n- 目标市场规模\n- 增长趋势预测\n- 竞争格局分析",
        
        "traction": "进展与成果\n- 关键里程碑\n- 用户增长数据\n- 收入/合作情况",
        
        "team": "团队介绍\n- 核心成员背景\n- 专业能力与经验\n- 团队优势",
        
        "financial": "财务预测\n- 收入预测\n- 成本结构\n- 盈利预期",
        
        "business_model": "商业模式\n- 收入来源\n- 成本结构\n- 盈利路径",
        
        "advantages": "竞争优势\n- 技术壁垒\n- 资源优势\n- 差异化定位",
        
        "cases": "成功案例\n- 客户案例一\n- 客户案例二\n- 效果数据",
        
        "pricing": "定价策略\n- 基础版方案\n- 专业版方案\n- 企业版方案",
        
        "methodology": "研究方法\n- 数据来源\n- 分析框架\n- 验证方式",
        
        "findings": "核心发现\n- 关键发现一\n- 关键发现二\n- 数据支撑",
        
        "analysis": "深度分析\n- 趋势解读\n- 原因分析\n- 影响评估",
        
        "recommendations": "建议与对策\n- 短期建议\n- 中期策略\n- 长期规划",
        
        "objectives": "学习目标\n- 知识目标\n- 能力目标\n- 应用目标",
        
        "theory": "理论基础\n- 核心概念\n- 理论框架\n- 关键原理",
        
        "examples": "案例分析\n- 经典案例\n- 实际应用\n- 经验总结",
        
        "practice": "实践练习\n- 练习任务\n- 操作步骤\n- 注意事项",
        
        "demo": "产品演示\n- 核心功能展示\n- 操作流程\n- 效果预览",
        
        "faq": "常见问题\n- 问题一及解答\n- 问题二及解答\n- 问题三及解答",
        
        "contact": "联系我们\n- 联系方式\n- 官方网站\n- 社交媒体",
        
        "ask": "融资需求\n- 融资金额\n- 资金用途\n- 发展规划",
        
        "hook": "开场引入\n- 引人深思的问题\n- 震撼的数据\n- 有趣的故事",
        
        "closing": "结束语\n- 核心价值重申\n- 行动号召\n- 感谢聆听",
        
        "executive_summary": "执行摘要\n- 核心结论\n- 关键数据\n- 主要建议",
        
        "background": "背景介绍\n- 研究背景\n- 行业现状\n- 研究意义",
        
        "milestone": "里程碑\n- 已完成目标\n- 当前进展\n- 未来计划",
        
        "summary": "总结与展望\n- 核心要点回顾\n- 关键成果总结\n- 下一步计划",
        
        "homework": "课后作业\n- 作业要求\n- 提交方式\n- 截止时间",
        
        "conclusion": "结论\n- 主要发现\n- 研究贡献\n- 局限与展望",
    }
    
    return content_map.get(page_type, f"{page_type}\n- 要点一\n- 要点二\n- 要点三")


def interactive_plan():
    """交互式规划"""
    print("=" * 60)
    print("🎯 AI PPT 智能规划器")
    print("=" * 60)
    print()
    
    # 收集输入
    topic = input("📌 PPT主题: ").strip()
    if not topic:
        print("❌ 主题不能为空")
        return
    
    print()
    print("选择页数:")
    print("  1. 5页 (精简版)")
    print("  2. 8页 (标准版)")
    print("  3. 10页 (完整版)")
    print("  4. 自定义")
    choice = input("选择 (1-4, 默认2): ").strip() or "2"
    
    page_map = {"1": 5, "2": 8, "3": 10}
    if choice == "4":
        pages = int(input("输入页数 (5-15): ").strip() or "8")
    else:
        pages = page_map.get(choice, 8)
    
    print()
    print("选择风格:")
    print("  1. 渐变毛玻璃 (科技感)")
    print("  2. 商务极简 (专业)")
    print("  3. 科技未来 (炫酷)")
    print("  4. 教育学术 (严谨)")
    print("  5. 创意艺术 (活泼)")
    print("  6. 自然生态 (环保)")
    print("  7. 暗黑高级 (奢华)")
    style_choice = input("选择 (1-7, 默认1): ").strip() or "1"
    
    style_map = {
        "1": "gradient-glass",
        "2": "business-minimal",
        "3": "tech-future",
        "4": "education-academic",
        "5": "creative-art",
        "6": "nature-eco",
        "7": "dark-luxury",
    }
    style = style_map.get(style_choice, "gradient-glass")
    
    audience = input("\n👥 目标受众 (可选): ").strip()
    
    # 生成规划
    print()
    print("🤖 正在生成PPT规划...")
    print("-" * 60)
    
    plan = plan_ppt_with_llm(topic, pages, style, audience)
    
    # 显示预览
    print()
    print(f"📊 规划预览: {plan['title']}")
    print(f"类型: {plan['type']} | 风格: {plan['style']} | 页数: {len(plan['slides'])}")
    print()
    
    for slide in plan['slides']:
        content_preview = slide['content'].split('\n')[0][:30]
        print(f"  第{slide['slide_number']:2d}页 [{slide['page_type']:8s}] {content_preview}...")
    
    # 保存文件
    print()
    filename = f"plan_{topic.replace(' ', '_')[:20]}.json"
    with open(filename, 'w', encoding='utf-8') as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)
    
    print(f"✅ 规划已保存: {filename}")
    print()
    print("生成命令:")
    print(f"  python3 generate_ppt.py --plan {filename} --style styles/{style}.md --output {topic.replace(' ', '_')[:20]}")
    
    return filename


if __name__ == "__main__":
    interactive_plan()
