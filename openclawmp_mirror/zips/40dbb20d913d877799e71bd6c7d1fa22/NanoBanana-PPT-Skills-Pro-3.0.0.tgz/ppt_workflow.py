#!/usr/bin/env python3
"""
PPT Workflow - 一键PPT工作流

整合所有功能的一键脚本：
1. 智能规划/模板选择
2. 生成PPT图片
3. 导出PPTX
4. 打开预览

Usage:
    python3 ppt_workflow.py
"""

import json
import os
import subprocess
import sys
from pathlib import Path


def run_command(cmd, cwd=None):
    """运行命令并返回结果"""
    print(f"\n$ {' '.join(cmd)}")
    result = subprocess.run(cmd, cwd=cwd)
    return result.returncode == 0


def main():
    print("=" * 70)
    print("🚀 PPT Generator Pro - 一键工作流")
    print("=" * 70)
    print()
    
    # 检查依赖
    print("📦 检查依赖...")
    try:
        from PIL import Image
        print("  ✓ Pillow 已安装")
    except:
        print("  ✗ Pillow 未安装，正在安装...")
        subprocess.run([sys.executable, "-m", "pip", "install", "pillow"])
    
    try:
        from pptx import Presentation
        print("  ✓ python-pptx 已安装")
    except:
        print("  ⚠ python-pptx 未安装 (PPTX导出功能将不可用)")
        install = input("  是否安装? (y/n): ").strip().lower()
        if install == 'y':
            subprocess.run([sys.executable, "-m", "pip", "install", "python-pptx"])
    
    print()
    
    # 选择工作流模式
    print("选择工作流模式:")
    print("  1. 智能规划 (输入主题，AI自动生成结构)")
    print("  2. 套用模板 (选择行业模板)")
    print("  3. 使用现有规划文件")
    
    mode = input("\n选择 (1-3): ").strip() or "1"
    
    plan_file = None
    output_name = None
    
    if mode == "1":
        # 智能规划
        print("\n" + "=" * 70)
        print("🤖 智能规划模式")
        print("=" * 70)
        
        # 运行规划器
        result = subprocess.run([sys.executable, "ai_planner.py"])
        if result.returncode != 0:
            print("❌ 规划失败")
            return
        
        # 查找生成的规划文件
        for f in os.listdir("."):
            if f.startswith("plan_") and f.endswith(".json"):
                plan_file = f
                output_name = f[5:-5]  # 去掉 plan_ 和 .json
                break
        
    elif mode == "2":
        # 模板模式
        print("\n" + "=" * 70)
        print("📋 模板模式")
        print("=" * 70)
        
        result = subprocess.run([sys.executable, "template_manager.py"])
        if result.returncode != 0:
            print("❌ 模板应用失败")
            return
        
        # 查找生成的规划文件
        for f in os.listdir("."):
            if f.startswith("plan_") and f.endswith(".json"):
                plan_file = f
                output_name = f[5:-5]
                break
    
    elif mode == "3":
        # 使用现有规划
        plan_file = input("\n输入规划文件路径: ").strip()
        if not os.path.exists(plan_file):
            print(f"❌ 文件不存在: {plan_file}")
            return
        output_name = input("输出目录名称: ").strip() or "my_ppt"
    
    else:
        print("❌ 无效选择")
        return
    
    if not plan_file:
        print("❌ 未找到规划文件")
        return
    
    print(f"\n✅ 规划文件: {plan_file}")
    print(f"✅ 输出目录: {output_name}")
    
    # 选择风格
    print("\n" + "=" * 70)
    print("🎨 选择风格")
    print("=" * 70)
    
    styles = [
        ("gradient-glass", "渐变毛玻璃 (科技感)"),
        ("business-minimal", "商务极简 (专业)"),
        ("tech-future", "科技未来 (炫酷)"),
        ("education-academic", "教育学术 (严谨)"),
        ("creative-art", "创意艺术 (活泼)"),
        ("nature-eco", "自然生态 (环保)"),
        ("dark-luxury", "暗黑高级 (奢华)"),
    ]
    
    for i, (key, name) in enumerate(styles, 1):
        print(f"  {i}. {name}")
    
    style_choice = input("\n选择 (1-7, 默认2): ").strip() or "2"
    style_key = styles[int(style_choice) - 1][0] if style_choice.isdigit() and 1 <= int(style_choice) <= 7 else "business-minimal"
    style_file = f"styles/{style_key}.md"
    
    print(f"✅ 已选择: {style_key}")
    
    # 生成PPT
    print("\n" + "=" * 70)
    print("🖼️  生成PPT图片")
    print("=" * 70)
    
    if not run_command([
        sys.executable, "generate_ppt.py",
        "--plan", plan_file,
        "--style", style_file,
        "--output", output_name
    ]):
        print("❌ PPT生成失败")
        return
    
    # 检查图片是否生成
    images_dir = os.path.join(output_name, "images")
    if not os.path.exists(images_dir):
        print(f"❌ 图片目录不存在: {images_dir}")
        return
    
    image_count = len([f for f in os.listdir(images_dir) if f.endswith('.png')])
    print(f"✅ 已生成 {image_count} 张图片")
    
    # 询问是否导出PPTX
    print("\n" + "=" * 70)
    print("📤 导出选项")
    print("=" * 70)
    
    export_pptx = input("是否导出PPTX文件? (y/n, 默认y): ").strip().lower() != 'n'
    
    if export_pptx:
        pptx_file = f"{output_name}.pptx"
        
        # 检查python-pptx
        try:
            from pptx import Presentation
            
            with_notes = input("是否包含演讲者备注? (y/n, 默认n): ").strip().lower() == 'y'
            
            cmd = [
                sys.executable, "export_pptx.py",
                "--images", images_dir,
                "--output", pptx_file,
            ]
            
            if with_notes:
                prompts_file = os.path.join(output_name, "prompts.json")
                if os.path.exists(prompts_file):
                    cmd.extend(["--with-notes", prompts_file])
            
            if run_command(cmd):
                print(f"✅ PPTX已导出: {pptx_file}")
            else:
                print("⚠ PPTX导出失败")
        except ImportError:
            print("⚠ python-pptx未安装，跳过PPTX导出")
            print("  安装命令: pip install python-pptx")
    
    # 完成
    print("\n" + "=" * 70)
    print("🎉 工作流完成!")
    print("=" * 70)
    print()
    print(f"📁 输出目录: {output_name}/")
    print(f"🖼️  图片位置: {output_name}/images/")
    print(f"🌐 播放器: {output_name}/index.html")
    
    if export_pptx and os.path.exists(f"{output_name}.pptx"):
        print(f"📊 PPTX文件: {output_name}.pptx")
    
    print()
    print("打开方式:")
    print(f"  浏览器: start {output_name}/index.html")
    if os.path.exists(f"{output_name}.pptx"):
        print(f"  PPTX:   start {output_name}.pptx")
    
    # 询问是否打开
    print()
    open_now = input("是否立即打开预览? (y/n): ").strip().lower()
    if open_now == 'y':
        html_path = os.path.join(output_name, "index.html")
        if os.path.exists(html_path):
            subprocess.run(["start", html_path], shell=True)


if __name__ == "__main__":
    main()
