#!/usr/bin/env python3
"""
PPTX Exporter - 导出为 PowerPoint 文件

将生成的PPT图片导出为真实的 .pptx 文件，支持编辑和二次修改。
"""

import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List, Optional

try:
    from pptx import Presentation
    from pptx.util import Inches, Pt
    from pptx.dml.color import RgbColor
    from pptx.enum.text import PP_ALIGN, MSO_ANCHOR
    PPTX_AVAILABLE = True
except ImportError:
    PPTX_AVAILABLE = False
    print("Warning: python-pptx not installed. PPTX export disabled.")
    print("Install with: pip install python-pptx")


def create_pptx_from_images(
    image_dir: str,
    output_path: str,
    title: str = "Generated Presentation",
    width: int = 1344,
    height: int = 768,
) -> bool:
    """
    从图片创建PPTX文件
    
    Args:
        image_dir: 图片目录路径
        output_path: 输出PPTX文件路径
        title: 演示文稿标题
        width: 幻灯片宽度（像素）
        height: 幻灯片高度（像素）
    """
    if not PPTX_AVAILABLE:
        print("Error: python-pptx not installed")
        return False
    
    try:
        # 创建演示文稿
        prs = Presentation()
        
        # 设置幻灯片尺寸为16:9
        # PPTX默认是9144000 EMUs = 10 inches
        # 16:9 比例: 10 x 5.625 inches
        prs.slide_width = Inches(10)
        prs.slide_height = Inches(5.625)
        
        # 获取空白布局
        blank_layout = prs.slide_layouts[6]  # 空白布局
        
        # 查找所有幻灯片图片
        image_files = sorted([
            f for f in os.listdir(image_dir)
            if f.startswith('slide-') and f.endswith('.png')
        ])
        
        if not image_files:
            print(f"Error: No slide images found in {image_dir}")
            return False
        
        print(f"Found {len(image_files)} slides")
        
        for img_file in image_files:
            img_path = os.path.join(image_dir, img_file)
            
            # 添加新幻灯片
            slide = prs.slides.add_slide(blank_layout)
            
            # 添加图片，填满整个幻灯片
            slide.shapes.add_picture(
                img_path,
                Inches(0),  # left
                Inches(0),  # top
                width=prs.slide_width,
                height=prs.slide_height,
            )
            
            print(f"  Added: {img_file}")
        
        # 保存文件
        prs.save(output_path)
        print(f"\n✅ PPTX saved: {output_path}")
        return True
        
    except Exception as e:
        print(f"Error creating PPTX: {e}")
        return False


def create_pptx_with_notes(
    image_dir: str,
    prompts_file: str,
    output_path: str,
) -> bool:
    """
    创建带演讲者备注的PPTX
    
    Args:
        image_dir: 图片目录
        prompts_file: prompts.json 文件路径（包含内容信息）
        output_path: 输出路径
    """
    if not PPTX_AVAILABLE:
        print("Error: python-pptx not installed")
        return False
    
    try:
        # 加载 prompts 数据
        with open(prompts_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        slides_data = data.get('slides', [])
        
        # 创建演示文稿
        prs = Presentation()
        prs.slide_width = Inches(10)
        prs.slide_height = Inches(5.625)
        blank_layout = prs.slide_layouts[6]
        
        for slide_info in slides_data:
            slide_num = slide_info.get('slide_number', 0)
            content = slide_info.get('content', '')
            
            # 查找对应图片
            img_file = f"slide-{slide_num:02d}.png"
            img_path = os.path.join(image_dir, img_file)
            
            if not os.path.exists(img_path):
                print(f"Warning: Image not found: {img_path}")
                continue
            
            # 添加幻灯片
            slide = prs.slides.add_slide(blank_layout)
            
            # 添加图片
            slide.shapes.add_picture(
                img_path,
                Inches(0),
                Inches(0),
                width=prs.slide_width,
                height=prs.slide_height,
            )
            
            # 添加演讲者备注
            notes_slide = slide.notes_slide
            notes_text_frame = notes_slide.notes_text_frame
            notes_text_frame.text = f"第{slide_num}页内容:\n{content}"
            
            print(f"  Added slide {slide_num} with notes")
        
        prs.save(output_path)
        print(f"\n✅ PPTX with notes saved: {output_path}")
        return True
        
    except Exception as e:
        print(f"Error: {e}")
        return False


def main():
    parser = argparse.ArgumentParser(
        description="Export PPT images to PowerPoint (.pptx) file",
    )
    parser.add_argument(
        "--images", "-i",
        required=True,
        help="Directory containing slide images",
    )
    parser.add_argument(
        "--output", "-o",
        required=True,
        help="Output PPTX file path",
    )
    parser.add_argument(
        "--title", "-t",
        default="Generated Presentation",
        help="Presentation title",
    )
    parser.add_argument(
        "--with-notes", "-n",
        help="Add speaker notes from prompts.json file",
    )
    
    args = parser.parse_args()
    
    if not PPTX_AVAILABLE:
        print("Error: Please install python-pptx first:")
        print("  pip install python-pptx")
        sys.exit(1)
    
    if args.with_notes:
        success = create_pptx_with_notes(
            args.images,
            args.with_notes,
            args.output,
        )
    else:
        success = create_pptx_from_images(
            args.images,
            args.output,
            args.title,
        )
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
