---
name: NanoBanana-PPT-Skills-Pro
version: 3.0.0
description: 专业级AI PPT生成器 - 7种风格、智能规划、5个行业模板、PPTX导出
---

# PPT Generator Pro v3.0

世界级专业PPT生成工具，基于智谱AI CogView-4 + PIL文字叠加，支持7种风格、智能内容规划、行业模板、PPTX导出。

## ✨ 核心特性

### 🎨 7种专业风格
- **渐变毛玻璃** - 科技感、产品发布
- **商务极简** - 专业汇报、企业介绍
- **科技未来** - 炫酷、前沿技术
- **教育学术** - 严谨、教学培训
- **创意艺术** - 活泼、设计展示
- **自然生态** - 环保、可持续发展
- **暗黑高级** - 奢华、高端品牌

### 🤖 智能内容规划
- AI自动生成PPT结构
- 根据主题智能选择模板
- 支持5-15页灵活配置

### 📋 行业模板系统
- 创业融资路演 (12页)
- 产品发布会 (10页)
- 季度工作报告 (8页)
- 培训课程 (10页)
- 研究报告 (12页)

### 📤 多格式导出
- PNG图片 (默认)
- PPTX文件 (可编辑)
- HTML播放器
- PDF导出 (计划中)

### 🎤 演讲者支持
- 演讲者备注
- 计时器
- 快捷键导航

## 🚀 快速开始

### 安装依赖
```bash
pip install pillow python-pptx python-dotenv
```

### 设置API Key
```bash
export ZHIPU_API_KEY="your-api-key"
```

### 方式1: 智能规划 (推荐)
```bash
python3 ai_planner.py
# 按提示输入主题、页数、风格
```

### 方式2: 套用模板
```bash
python3 template_manager.py
# 选择行业模板，输入主题
```

### 方式3: 手动规划
```bash
python3 generate_ppt.py --plan my_plan.json --style styles/business-minimal.md --output my_ppt
```

### 导出PPTX
```bash
python3 export_pptx.py --images my_ppt/images --output my_ppt.pptx
```

## 📖 详细用法

### 智能规划器
交互式生成PPT规划：
```bash
python3 ai_planner.py
```

流程：
1. 输入PPT主题
2. 选择页数 (5/8/10/自定义)
3. 选择风格 (7种)
4. 自动生成规划文件
5. 一键生成PPT

### 模板管理器
快速套用行业模板：
```bash
python3 template_manager.py
```

内置模板：
| 模板 | 页数 | 适用场景 |
|------|------|----------|
| startup_pitch | 12 | 创业融资路演 |
| product_launch | 10 | 产品发布会 |
| quarterly_report | 8 | 季度工作报告 |
| training_course | 10 | 培训课程 |
| research_report | 12 | 研究报告 |

### 风格选择
```bash
# 列出所有风格
ls styles/

# 使用指定风格
python3 generate_ppt.py --plan plan.json --style styles/tech-future.md --output myppt
```

### 导出选项
```bash
# 仅图片 (默认)
python3 generate_ppt.py --plan plan.json --style styles/business-minimal.md

# 导出PPTX (可编辑)
python3 export_pptx.py --images outputs/xxx/images --output myppt.pptx

# 带演讲者备注
python3 export_pptx.py --images outputs/xxx/images --with-notes outputs/xxx/prompts.json --output myppt.pptx
```

## 📁 项目结构

```
NanoBanana-PPT-Skills/
├── generate_ppt.py          # 核心生成器
├── ai_planner.py            # 智能规划器
├── template_manager.py      # 模板管理器
├── export_pptx.py           # PPTX导出
├── styles/                  # 7种风格模板
│   ├── gradient-glass.md
│   ├── business-minimal.md
│   ├── tech-future.md
│   ├── education-academic.md
│   ├── creative-art.md
│   ├── nature-eco.md
│   └── dark-luxury.md
├── templates/               # 行业模板
│   ├── startup_pitch.json
│   ├── product_launch.json
│   ├── quarterly_report.json
│   ├── training_course.json
│   └── research_report.json
├── .env                     # API Key配置
└── SKILL.md                 # 本文件
```

## 🎨 风格详情

### gradient-glass (渐变毛玻璃)
- Apple Keynote风格
- 霓虹紫/电光蓝/珊瑚橙渐变
- 3D玻璃物体 + 电影级光照
- 适合：产品发布、科技展示

### business-minimal (商务极简)
- 纯白/浅灰背景
- 深蓝主色调 + 橙色强调
- 大量留白、专业严谨
- 适合：企业汇报、商务演示

### tech-future (科技未来)
- 深色背景 + 霓虹发光
- 网格线、代码感装饰
- 炫酷前沿
- 适合：技术分享、创新展示

### education-academic (教育学术)
- 温和背景色
- 墨绿/藏青主色调
- 学术规范格式
- 适合：教学课件、学术报告

### creative-art (创意艺术)
- 大胆色彩搭配
- 不规则几何形状
- 艺术化排版
- 适合：设计展示、创意提案

### nature-eco (自然生态)
- 自然色调
- 大地色系
- 有机曲线
- 适合：环保主题、可持续发展

### dark-luxury (暗黑高级)
- 纯黑背景
- 金色/玫瑰金强调
- 高端奢华感
- 适合：高端品牌、奢侈品

## ⚙️ 高级配置

### 环境变量
```bash
# 必需
export ZHIPU_API_KEY="your-api-key"

# 可选 (视频功能)
export KLING_ACCESS_KEY="your-kling-key"
export KLING_SECRET_KEY="your-kling-secret"
```

### 自定义字体
程序会自动检测系统字体：
- Windows: 微软雅黑、黑体、宋体
- Linux: 文泉驿、Noto Sans CJK
- macOS: 苹方、STHeiti

如需指定字体，修改 `generate_ppt.py` 中的 `find_chinese_font()` 函数。

### 分辨率设置
```bash
# 默认 1344x768 (16:9)
python3 generate_ppt.py --plan plan.json --resolution 1344x768

# 其他选项
# 1024x1024 (方形)
# 768x1344 (竖版)
```

## 🔧 故障排除

### 文字不显示
```bash
# 检查Pillow
pip install pillow

# 检查系统字体
python3 -c "from PIL import ImageFont; print(ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 20))"
```

### PPTX导出失败
```bash
# 安装python-pptx
pip install python-pptx
```

### API调用失败
- 检查 `ZHIPU_API_KEY` 设置
- 确认API Key未过期
- 检查网络连接

## 📊 性能指标

| 指标 | 数值 |
|------|------|
| 单页生成时间 | 30-60秒 |
| 支持页数 | 5-15页 |
| 输出分辨率 | 1344x768 |
| 支持风格 | 7种 |
| 内置模板 | 5个 |

## 📝 更新日志

### v3.0.0 (2026-03-23)
- ✨ 新增7种专业风格
- ✨ 新增AI智能规划器
- ✨ 新增行业模板系统
- ✨ 新增PPTX导出功能
- ✨ 优化PIL文字叠加
- 🔧 重构代码架构

### v2.1.0 (2026-03-23)
- ✨ 智谱AI CogView适配
- ✨ PIL文字叠加解决中文乱码
- ✨ 自动字体检测

### v2.0.0
- ✨ 视频转场功能
- ✨ 交互式播放器

## 📄 许可证

MIT License

## 🙏 致谢

- 基于歸藏的原版NanoBanana-PPT-Skills
- 智谱AI CogView-4模型
- python-pptx库
