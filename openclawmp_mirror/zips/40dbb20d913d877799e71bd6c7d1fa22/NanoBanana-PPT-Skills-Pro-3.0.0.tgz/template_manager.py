#!/usr/bin/env python3
"""
Template Manager - PPT模板管理器

管理内置模板，支持快速套用行业模板生成PPT。
"""

import json
import os
from pathlib import Path
from typing import Dict, List, Optional


def get_templates_dir() -> str:
    """获取模板目录"""
    return os.path.join(os.path.dirname(__file__), "templates")


def list_templates() -> List[Dict]:
    """列出所有可用模板"""
    templates_dir = get_templates_dir()
    templates = []
    
    if not os.path.exists(templates_dir):
        return templates
    
    for file in os.listdir(templates_dir):
        if file.endswith('.json'):
            try:
                with open(os.path.join(templates_dir, file), 'r', encoding='utf-8') as f:
                    template = json.load(f)
                    templates.append({
                        "name": template.get("name"),
                        "display_name": template.get("display_name"),
                        "description": template.get("description"),
                        "pages": template.get("pages"),
                        "file": file,
                    })
            except:
                pass
    
    return templates


def load_template(template_name: str) -> Optional[Dict]:
    """加载指定模板"""
    templates_dir = get_templates_dir()
    template_file = os.path.join(templates_dir, f"{template_name}.json")
    
    if not os.path.exists(template_file):
        return None
    
    with open(template_file, 'r', encoding='utf-8') as f:
        return json.load(f)


def apply_template(template_name: str, topic: str, custom_content: Dict = None) -> Dict:
    """
    应用模板生成PPT规划
    
    Args:
        template_name: 模板名称
        topic: PPT主题
        custom_content: 自定义内容，用于替换模板中的占位符
    
    Returns:
        PPT规划字典
    """
    template = load_template(template_name)
    if not template:
        raise ValueError(f"Template not found: {template_name}")
    
    slides = []
    for i, item in enumerate(template.get("structure", []), 1):
        content = custom_content.get(item["type"], item["hint"]) if custom_content else item["hint"]
        
        # 替换占位符
        content = content.replace("{topic}", topic)
        content = content.replace("{title}", item["title"])
        
        slides.append({
            "slide_number": i,
            "page_type": map_page_type(item["type"], i, len(template["structure"])),
            "content": f"{item['title']}\n{content}",
        })
    
    return {
        "title": topic,
        "template": template_name,
        "slides": slides,
    }


def map_page_type(page_type: str, current: int, total: int) -> str:
    """映射页面类型"""
    if current == 1:
        return "cover"
    elif current == total:
        return "data"
    elif page_type in ["data", "financials", "findings", "analysis", "market"]:
        return "data"
    else:
        return "content"


def interactive_template():
    """交互式模板选择"""
    print("=" * 60)
    print("📋 PPT 模板库")
    print("=" * 60)
    print()
    
    templates = list_templates()
    
    if not templates:
        print("❌ 没有找到模板")
        return
    
    print("可用模板:")
    for i, t in enumerate(templates, 1):
        print(f"  {i}. {t['display_name']}")
        print(f"     {t['description']} ({t['pages']}页)")
        print()
    
    choice = input(f"选择模板 (1-{len(templates)}): ").strip()
    try:
        idx = int(choice) - 1
        if idx < 0 or idx >= len(templates):
            print("❌ 无效选择")
            return
    except:
        print("❌ 无效输入")
        return
    
    selected = templates[idx]
    template = load_template(selected["name"])
    
    print()
    print(f"📌 已选择: {selected['display_name']}")
    print()
    
    # 输入主题
    topic = input("PPT主题: ").strip()
    if not topic:
        print("❌ 主题不能为空")
        return
    
    # 是否自定义内容
    print()
    customize = input("是否自定义每页内容? (y/n, 默认n): ").strip().lower() == 'y'
    
    custom_content = {}
    if customize:
        print()
        print("输入每页内容 (直接回车使用默认):")
        for item in template["structure"]:
            hint = item["hint"]
            user_input = input(f"  {item['title']}: ").strip()
            if user_input:
                custom_content[item["type"]] = user_input
    
    # 生成规划
    print()
    print("🔄 正在生成规划...")
    
    try:
        plan = apply_template(selected["name"], topic, custom_content if custom_content else None)
        
        # 保存
        filename = f"plan_{topic.replace(' ', '_')[:20]}.json"
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)
        
        print()
        print(f"✅ 规划已保存: {filename}")
        print()
        print("生成命令:")
        print(f"  python3 generate_ppt.py --plan {filename} --style styles/gradient-glass.md --output {topic.replace(' ', '_')[:20]}")
        
        return filename
        
    except Exception as e:
        print(f"❌ 错误: {e}")
        return


if __name__ == "__main__":
    interactive_template()
