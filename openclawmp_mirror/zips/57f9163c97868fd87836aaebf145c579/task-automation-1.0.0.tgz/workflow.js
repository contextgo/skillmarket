/**
 * Task Automation - Workflow Engine
 * Advanced workflow orchestration with error recovery and progress tracking
 */

class WorkflowEngine {
  constructor() {
    this.workflows = new Map();
    this.activeTasks = new Map();
    this.state = new Map();
  }

  /**
   * Create a new workflow
   */
  create(definition) {
    const id = `wf_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const workflow = {
      id,
      ...definition,
      status: 'created',
      createdAt: new Date().toISOString(),
      tasks: new Map(),
      completedTasks: [],
      failedTasks: [],
      progress: 0
    };
    
    // Initialize tasks
    definition.tasks.forEach(taskDef => {
      workflow.tasks.set(taskDef.id, {
        ...taskDef,
        status: 'pending',
        attempts: 0,
        startTime: null,
        endTime: null,
        output: null,
        error: null
      });
    });
    
    this.workflows.set(id, workflow);
    return id;
  }

  /**
   * Start workflow execution
   */
  async start(workflowId, options = {}) {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) throw new Error(`Workflow ${workflowId} not found`);
    
    workflow.status = 'running';
    workflow.startTime = new Date().toISOString();
    
    // Find tasks with no dependencies
    const readyTasks = Array.from(workflow.tasks.values())
      .filter(t => !t.depends_on || t.depends_on.length === 0);
    
    // Execute ready tasks
    await Promise.all(readyTasks.map(task => this.executeTask(workflowId, task.id)));
    
    return workflowId;
  }

  /**
   * Execute a single task
   */
  async executeTask(workflowId, taskId) {
    const workflow = this.workflows.get(workflowId);
    const task = workflow.tasks.get(taskId);
    
    // Check dependencies
    if (task.depends_on) {
      const depsComplete = task.depends_on.every(depId => {
        const dep = workflow.tasks.get(depId);
        return dep && dep.status === 'completed';
      });
      
      if (!depsComplete) {
        console.log(`Task ${taskId} waiting for dependencies`);
        return;
      }
    }
    
    task.status = 'running';
    task.startTime = new Date().toISOString();
    task.attempts++;
    
    try {
      // Execute task steps
      for (const step of task.steps) {
        await this.executeStep(workflowId, taskId, step);
      }
      
      task.status = 'completed';
      task.endTime = new Date().toISOString();
      workflow.completedTasks.push(taskId);
      
      // Find next tasks
      this.triggerNextTasks(workflowId, taskId);
      
    } catch (error) {
      task.status = 'failed';
      task.error = error.message;
      task.endTime = new Date().toISOString();
      workflow.failedTasks.push(taskId);
      
      // Handle error
      await this.handleError(workflowId, taskId, error);
    }
    
    // Update progress
    this.updateProgress(workflowId);
  }

  /**
   * Execute a single step
   */
  async executeStep(workflowId, taskId, step) {
    const workflow = this.workflows.get(workflowId);
    
    // Check condition
    if (step.condition && !this.evaluateCondition(step.condition, workflow)) {
      console.log(`Step skipped due to condition: ${step.condition}`);
      return;
    }
    
    // Execute action
    console.log(`Executing: ${step.action}`);
    
    // Here you would call the actual action handler
    // For now, simulate execution
    await this.simulateExecution(step);
    
    // Store output
    const task = workflow.tasks.get(taskId);
    task.output = { action: step.action, completed: true };
  }

  /**
   * Simulate task execution (replace with actual implementation)
   */
  async simulateExecution(step) {
    const delay = Math.random() * 2000 + 500;
    await new Promise(resolve => setTimeout(resolve, delay));
    
    // Simulate occasional failures for testing
    if (Math.random() < 0.1) {
      throw new Error(`Simulated failure in ${step.action}`);
    }
  }

  /**
   * Handle task errors with retry logic
   */
  async handleError(workflowId, taskId, error) {
    const workflow = this.workflows.get(workflowId);
    const task = workflow.tasks.get(taskId);
    
    const errorHandling = task.error_handling || { strategy: 'retry', max_retries: 3 };
    
    if (errorHandling.strategy === 'retry' && task.attempts < errorHandling.max_retries) {
      const delay = this.calculateBackoff(task.attempts, errorHandling.backoff);
      console.log(`Retrying task ${taskId} in ${delay}ms (attempt ${task.attempts})`);
      
      await new Promise(resolve => setTimeout(resolve, delay));
      await this.executeTask(workflowId, taskId);
      
    } else if (errorHandling.strategy === 'skip') {
      console.log(`Skipping failed task ${taskId}`);
      task.status = 'skipped';
      this.triggerNextTasks(workflowId, taskId);
      
    } else {
      // Abort workflow
      workflow.status = 'failed';
      console.error(`Workflow ${workflowId} failed: ${error.message}`);
    }
  }

  /**
   * Calculate retry delay with backoff
   */
  calculateBackoff(attempt, backoff = 'exponential') {
    const baseDelay = 1000;
    
    if (backoff === 'exponential') {
      return baseDelay * Math.pow(3, attempt - 1);
    } else if (backoff === 'fixed') {
      return baseDelay;
    }
    
    return baseDelay;
  }

  /**
   * Trigger next tasks after completion
   */
  triggerNextTasks(workflowId, completedTaskId) {
    const workflow = this.workflows.get(workflowId);
    
    // Find tasks that depend on completed task
    const nextTasks = Array.from(workflow.tasks.values())
      .filter(t => t.depends_on && t.depends_on.includes(completedTaskId))
      .filter(t => t.status === 'pending');
    
    // Check if all dependencies are met
    nextTasks.forEach(task => {
      const depsComplete = task.depends_on.every(depId => {
        const dep = workflow.tasks.get(depId);
        return dep && (dep.status === 'completed' || dep.status === 'skipped');
      });
      
      if (depsComplete) {
        this.executeTask(workflowId, task.id);
      }
    });
  }

  /**
   * Update workflow progress
   */
  updateProgress(workflowId) {
    const workflow = this.workflows.get(workflowId);
    const total = workflow.tasks.size;
    const completed = workflow.completedTasks.length;
    const failed = workflow.failedTasks.length;
    
    workflow.progress = Math.round(((completed + failed) / total) * 100);
    
    // Check if workflow is complete
    if (completed + failed === total) {
      workflow.status = failed > 0 ? 'completed_with_errors' : 'completed';
      workflow.endTime = new Date().toISOString();
    }
  }

  /**
   * Evaluate conditional expression
   */
  evaluateCondition(condition, workflow) {
    // Simple condition evaluation
    // In production, use a proper expression parser
    try {
      // Replace variables
      const context = {};
      workflow.tasks.forEach((task, id) => {
        context[id] = task.output;
      });
      
      // Very basic evaluation - replace with proper implementation
      return true;
    } catch (e) {
      return false;
    }
  }

  /**
   * Get workflow status
   */
  getStatus(workflowId) {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) return null;
    
    return {
      id: workflow.id,
      name: workflow.name,
      status: workflow.status,
      progress: workflow.progress,
      createdAt: workflow.createdAt,
      startTime: workflow.startTime,
      endTime: workflow.endTime,
      tasks: Array.from(workflow.tasks.values()).map(t => ({
        id: t.id,
        name: t.name,
        status: t.status,
        attempts: t.attempts,
        error: t.error
      }))
    };
  }

  /**
   * Cancel workflow
   */
  cancel(workflowId, force = false) {
    const workflow = this.workflows.get(workflowId);
    if (!workflow) return false;
    
    workflow.status = 'cancelled';
    workflow.endTime = new Date().toISOString();
    
    // Cancel running tasks
    workflow.tasks.forEach(task => {
      if (task.status === 'running') {
        task.status = 'cancelled';
      }
    });
    
    return true;
  }

  /**
   * List all workflows
   */
  list(filters = {}) {
    let workflows = Array.from(this.workflows.values());
    
    if (filters.status) {
      workflows = workflows.filter(w => w.status === filters.status);
    }
    
    return workflows.map(w => this.getStatus(w.id));
  }
}

// Export for use
module.exports = { WorkflowEngine };

// Example usage
if (require.main === module) {
  const engine = new WorkflowEngine();
  
  // Create example workflow
  const workflowId = engine.create({
    name: "Example Workflow",
    tasks: [
      {
        id: "task1",
        name: "Download Data",
        type: "sequential",
        steps: [{ action: "download", params: { url: "https://example.com/data" } }]
      },
      {
        id: "task2",
        name: "Process Data",
        type: "sequential",
        depends_on: ["task1"],
        steps: [{ action: "process", params: {} }]
      }
    ]
  });
  
  console.log("Created workflow:", workflowId);
  
  // Start workflow
  engine.start(workflowId).then(() => {
    console.log("Workflow started");
  });
}
