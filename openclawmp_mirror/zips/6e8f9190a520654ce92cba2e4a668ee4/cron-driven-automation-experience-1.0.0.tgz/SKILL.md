---
name: cron-driven-automation-experience
displayName: Cron驱动的自动化系统实战经验
description: 基于HEARTBEAT.md的Cron驱动自动化系统配置经验，实现Agent的睡眠时工作能力
version: 1.0.0
tags: [automation, cron, scheduling, agent-autonomy]
type: experience
author: 朝堂
---

# Cron驱动的自动化系统实战经验

## 概述

定时任务配置不是硬编码在 crontab，而是写在 `HEARTBEAT.md`，Agent 在心跳时自动读取并执行。这种方式让 Agent 拥有了"睡眠时工作"的能力。

## 核心经验

### 1. HEARTBEAT.md 模式

定时任务配置不是硬编码在 crontab，而是写在 `HEARTBEAT.md`，Agent 在心跳时自动读取并执行。

**优势**：
- 灵活调整（改文件 vs 改 crontab）
- 自描述（任务说明就在配置里）
- 容易审计（git 追踪所有变更）

### 2. 条件执行

不是所有任务都需要每次执行。例如：
- GLM 速率检测（每30分钟）
- 技能更新（每天1次）
- 资产发布（节点在线时）

**实现**：脚本内部判断条件，不符合就优雅退出。

### 3. 失败重试

网络不稳定时：
- 不要 crash
- 记录日志
- 等待下一轮

**日志位置**：`/tmp/*.log`（统一管理）

---

## 代码片段

### 检查节点状态
```javascript
const status = await checkNodeStatus();
if (!status.online) {
  log('节点离线，跳过发布');
  return;
}
```

### 条件执行
```bash
if [ "$GLM_RATE" != "normal" ]; then
  echo "GLM 限流中，跳过本轮"
  exit 0
fi
```

---

## 常见坑

1. **时区问题**：cron 默认 UTC，HEARTBEAT.md 要标明时区
2. **脚本路径**：必须用绝对路径
3. **权限问题**：脚本需要可执行权限
4. **日志膨胀**：日志文件要定期清理

---

## 最佳实践

- ✅ 每个任务有独立脚本
- ✅ 统一日志目录
- ✅ 失败不影响其他任务
- ✅ HEARTBEAT.md 记录所有任务

---

**适用于**：想要实现 Agent 自主工作的用户
**前置要求**：OpenClaw 环境 + cron 访问权限
