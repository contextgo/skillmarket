/**
 * SSH Docker 管理器
 * 通过 SSH 远程管理 Linux 设备的 Docker 容器
 */
const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const CONFIG_PATH = path.join(__dirname, '..', 'devices.json');

// 加载配置
function loadConfig() {
  if (!fs.existsSync(CONFIG_PATH)) {
    throw new Error('请先配置 devices.json');
  }
  return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf8'));
}

// 获取设备配置
function getDevice(deviceName) {
  const config = loadConfig();
  const name = deviceName || config.defaultDevice;
  const device = config.devices[name];
  if (!device) {
    throw new Error(`设备 ${name} 不存在`);
  }
  return device;
}

// 执行 SSH 命令
function sshExec(command, deviceName) {
  const device = getDevice(deviceName);
  const sshCommand = `sshpass -p '${device.password}' ssh -o StrictHostKeyChecking=no -p ${device.port} ${device.user}@${device.host} "${command}"`;
  
  try {
    return execSync(sshCommand, { encoding: 'utf8', timeout: 30000 });
  } catch (error) {
    throw new Error(`SSH 执行失败: ${error.message}`);
  }
}

// 获取 Docker 路径
function getDockerPath(deviceName) {
  const device = getDevice(deviceName);
  return device.dockerPath || 'docker';
}

// 列出所有容器
function listContainers(deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const cmd = `${dockerPath} ps -a --format 'table {{.Names}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}'`;
  const output = sshExec(cmd, deviceName);
  return output;
}

// 查看容器状态
function containerStatus(containerName, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const cmd = `${dockerPath} ps -a --filter 'name=${containerName}' --format 'table {{.Names}}\\t{{.Image}}\\t{{.Status}}\\t{{.Ports}}'`;
  const output = sshExec(cmd, deviceName);
  return output;
}

// 启动容器
function startContainer(containerName, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} start ${containerName}`, deviceName);
  return output;
}

// 停止容器
function stopContainer(containerName, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} stop ${containerName}`, deviceName);
  return output;
}

// 重启容器
function restartContainer(containerName, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} restart ${containerName}`, deviceName);
  return output;
}

// 查看容器日志
function containerLogs(containerName, lines = 50, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} logs --tail ${lines} ${containerName} 2>&1`, deviceName);
  return output;
}

// 执行容器命令
function execContainer(containerName, command, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} exec ${containerName} ${command}`, deviceName);
  return output;
}

// 查看资源使用
function containerStats(deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const cmd = `${dockerPath} stats --no-stream --format 'table {{.Name}}\\t{{.CPUPerc}}\\t{{.MemUsage}}\\t{{.NetIO}}\\t{{.BlockIO}}'`;
  const output = sshExec(cmd, deviceName);
  return output;
}

// 清理停止的容器
function pruneContainers(deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} container prune -f`, deviceName);
  return output;
}

// 查看镜像列表
function listImages(deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const cmd = `${dockerPath} images --format 'table {{.Repository}}\\t{{.Tag}}\\t{{.Size}}\\t{{.CreatedAt}}'`;
  const output = sshExec(cmd, deviceName);
  return output;
}

// 删除容器
function removeContainer(containerName, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} rm -f ${containerName}`, deviceName);
  return output;
}

// 获取容器详情
function inspectContainer(containerName, deviceName) {
  const dockerPath = getDockerPath(deviceName);
  const output = sshExec(`${dockerPath} inspect ${containerName}`, deviceName);
  return JSON.parse(output)[0];
}

// 命令行参数处理
const args = process.argv.slice(2);
let deviceName = null;

// 检查是否有 --device 参数
const deviceIndex = args.indexOf('--device');
if (deviceIndex !== -1 && args[deviceIndex + 1]) {
  deviceName = args[deviceIndex + 1];
  args.splice(deviceIndex, 2);
}

async function main() {
  try {
    if (args.includes('--list')) {
      console.log('📋 容器列表:');
      console.log(listContainers(deviceName));
    } else if (args.includes('--status') && args[1]) {
      const idx = args.indexOf('--status');
      const containerName = args[idx + 1];
      console.log(`📊 ${containerName} 状态:`);
      console.log(containerStatus(containerName, deviceName));
    } else if (args.includes('--start') && args[1]) {
      const idx = args.indexOf('--start');
      const containerName = args[idx + 1];
      console.log(`▶️ 启动 ${containerName}...`);
      console.log(startContainer(containerName, deviceName));
      console.log('✅ 启动成功');
    } else if (args.includes('--stop') && args[1]) {
      const idx = args.indexOf('--stop');
      const containerName = args[idx + 1];
      console.log(`⏹️ 停止 ${containerName}...`);
      console.log(stopContainer(containerName, deviceName));
      console.log('✅ 停止成功');
    } else if (args.includes('--restart') && args[1]) {
      const idx = args.indexOf('--restart');
      const containerName = args[idx + 1];
      console.log(`🔄 重启 ${containerName}...`);
      console.log(restartContainer(containerName, deviceName));
      console.log('✅ 重启成功');
    } else if (args.includes('--logs')) {
      const logsIdx = args.indexOf('--logs');
      const containerName = args[logsIdx + 1];
      const linesIdx = args.indexOf('--lines');
      const lines = linesIdx !== -1 ? args[linesIdx + 1] : 50;
      console.log(`📜 ${containerName} 日志 (最近 ${lines} 行):`);
      console.log(containerLogs(containerName, lines, deviceName));
    } else if (args.includes('--exec')) {
      const execIdx = args.indexOf('--exec');
      const containerName = args[execIdx + 1];
      const cmdIdx = args.indexOf('--command');
      const command = args[cmdIdx + 1];
      console.log(`🔧 执行: ${command}`);
      console.log(execContainer(containerName, command, deviceName));
    } else if (args.includes('--stats')) {
      console.log('📊 资源使用:');
      console.log(containerStats(deviceName));
    } else if (args.includes('--prune')) {
      console.log('🧹 清理停止的容器...');
      console.log(pruneContainers(deviceName));
      console.log('✅ 清理完成');
    } else if (args.includes('--images')) {
      console.log('🖼️ 镜像列表:');
      console.log(listImages(deviceName));
    } else if (args.includes('--rm') && args[1]) {
      const idx = args.indexOf('--rm');
      const containerName = args[idx + 1];
      console.log(`🗑️ 删除容器 ${containerName}...`);
      console.log(removeContainer(containerName, deviceName));
      console.log('✅ 删除成功');
    } else if (args.includes('--inspect') && args[1]) {
      const idx = args.indexOf('--inspect');
      const containerName = args[idx + 1];
      console.log(`🔍 ${containerName} 详情:`);
      console.log(JSON.stringify(inspectContainer(containerName, deviceName), null, 2));
    } else {
      console.log('SSH Docker 管理器');
      console.log('');
      console.log('用法:');
      console.log('  node docker.js --list                    # 列出所有容器');
      console.log('  node docker.js --status <容器名>          # 查看容器状态');
      console.log('  node docker.js --start <容器名>           # 启动容器');
      console.log('  node docker.js --stop <容器名>            # 停止容器');
      console.log('  node docker.js --restart <容器名>         # 重启容器');
      console.log('  node docker.js --logs <容器名> --lines 50 # 查看日志');
      console.log('  node docker.js --exec <容器名> --command "ls" # 执行命令');
      console.log('  node docker.js --stats                   # 查看资源使用');
      console.log('  node docker.js --prune                   # 清理停止的容器');
      console.log('  node docker.js --images                  # 查看镜像');
      console.log('  node docker.js --rm <容器名>             # 删除容器');
      console.log('  --device <设备名>                        # 指定设备');
    }
  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
