#!/bin/bash
# 水牛分析技能调度器
# 由 OpenClaw skill command 通过 exec 工具调用

SKILL_DIR="/root/.openclaw/workspace/skills/水牛分析/scripts"

# 加载环境变量
if [ -f "/root/.openclaw/agents/redquinn/workspace/.env" ]; then
    export IWENCAI_API_KEY=$(grep IWENCAI_API_KEY "/root/.openclaw/agents/redquinn/workspace/.env" | cut -d'=' -f2)
fi
if [ -z "$IWENCAI_API_KEY" ]; then
    export IWENCAI_API_KEY=$(grep -m1 "IWENCAI_API_KEY" ~/.bashrc | cut -d'=' -f2- | tr -d '"' | tr -d "'")
fi

# 执行数据采集脚本，传递所有参数
exec python3 "$SKILL_DIR/gather_data.py" "$@"
