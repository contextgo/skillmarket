#!/usr/bin/env python3
"""
水牛分析 - 数据采集脚本
用法: python3 gather_data.py <股票名称或代码> [股票名称或代码...]

示例:
  python3 gather_data.py 平安银行
  python3 gather_data.py 比亚迪 宁德时代
"""
import sys
import json
import urllib.request
import os
import time

IWENCAI_API_KEY = os.environ.get("IWENCAI_API_KEY", "")
IWENCAI_BASE_URL = "https://openapi.iwencai.com"

def wencai_query(query, limit=5):
    if not IWENCAI_API_KEY:
        return {"error": "IWENCAI_API_KEY not set"}
    url = f"{IWENCAI_BASE_URL}/v1/query2data"
    headers = {"Authorization": f"Bearer {IWENCAI_API_KEY}", "Content-Type": "application/json"}
    payload = {"query": query, "page": "1", "limit": str(limit), "is_cache": "1"}
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result.get("datas", [])
    except Exception as e:
        return [{"error": str(e)}]

def gather_all(code_or_name):
    """采集单只股票全维度数据"""
    results = {}
    queries = [
        ("price", f"{code_or_name}最新价格"),
        ("pe_pb", f"{code_or_name}市盈率 市净率"),
        ("roe_debt", f"{code_or_name}ROE 资产负债率"),
        ("revenue_profit", f"{code_or_name}营业收入 净利润 每股收益"),
        ("cash_flow", f"{code_or_name}经营性现金流"),
        ("fund_flow", f"{code_or_name}主力净流入 大单小单资金流向"),
        ("dividend", f"{code_or_name}股息率 分红送转"),
        ("macd_rsi", f"{code_or_name}MACD KDJ RSI 均线系统"),
        ("basic_info", f"{code_or_name}公司介绍 实际控制人 主营业务"),
        ("holder_info", f"{code_or_name}股东人数 前十大股东"),
        ("business", f"{code_or_name}主营业务构成 主营收入占比"),
        ("event", f"{code_or_name}业绩预告 分红送转 解禁"),
        ("industry", f"{code_or_name}行业涨跌幅 行业资金流向"),
        ("institutional", f"{code_or_name}券商目标价 机构评级 盈利预测"),
    ]
    for qname, q in queries:
        data = wencai_query(q)
        if data and "error" not in data[0]:
            results[qname] = data[0]
        time.sleep(0.15)
    return results

def format_field(d, key):
    val = d.get(key, d.get(key.replace("_", ""), "?"))
    if val is None or val == "":
        return "?"
    if isinstance(val, float):
        return f"{val:.2f}"
    return str(val)

def analyze_single(code_or_name):
    print(f"\n{'='*60}")
    print(f"  水牛分析数据采集 · {code_or_name}")
    print(f"{'='*60}")

    data = gather_all(code_or_name)

    # 解析关键字段
    price_data = data.get("price", {})
    pe_pb = data.get("pe_pb", {})
    roe_debt = data.get("roe_debt", {})
    rev_profit = data.get("revenue_profit", {})
    cash = data.get("cash_flow", {})
    funds = data.get("fund_flow", {})
    div = data.get("dividend", {})
    tech = data.get("macd_rsi", {})
    basic = data.get("basic_info", {})
    holders = data.get("holder_info", {})
    biz = data.get("business", {})
    events = data.get("event", {})
    inst = data.get("institutional", {})

    code = price_data.get("股票代码", "?")
    name = price_data.get("股票简称", code_or_name)
    price = price_data.get("收盘价[20260417]", price_data.get("最新价", "?"))
    pe = pe_pb.get("最新市盈率ttm", "?")
    pb = pe_pb.get("最新市净率", "?")
    roe = roe_debt.get("净资产收益率[20251231]", roe_debt.get("净资产收益率[20250930]", "?"))
    debt = roe_debt.get("资产负债率[20251231]", roe_debt.get("资产负债率[20250930]", "?"))
    revenue = rev_profit.get("营业收入", "?")
    profit = rev_profit.get("归母净利润", "?")
    eps = rev_profit.get("每股收益", "?")
    cf = cash.get("经营性现金流", "?")
    main_flow = funds.get("主力资金流向", "?")
    rsi = tech.get("rsi[20260417]", tech.get("rsi", "?"))
    macd = tech.get("macd[20260417]", tech.get("macd", "?"))
    ma5 = tech.get("ma5[20260417]", tech.get("ma5", "?"))
    ma10 = tech.get("ma10[20260417]", tech.get("ma10", "?"))
    ma20 = tech.get("ma20[20260417]", tech.get("ma20", "?"))
    dividend_yield = div.get("股息率", "?")
    controller = basic.get("实际控制人", "?")
    main_biz = basic.get("主营业务", "?")
    holder_count = holders.get("股东人数", "?")
    top10_pct = holders.get("前十大股东持股比例", "?")
    inst_target = inst.get("券商目标价", "?")
    inst_rating = inst.get("机构评级", "?")

    # 打印结构化数据
    print(f"\n【基本信息】")
    print(f"  代码: {code} | 简称: {name} | 价格: ¥{price}")
    print(f"  实际控制人: {controller}")
    print(f"  主营业务: {main_biz}")

    print(f"\n【估值指标】")
    print(f"  PE(TTM): {pe} | PB: {pb} | 股息率: {dividend_yield}")

    print(f"\n【财务数据】")
    if revenue != "?" and revenue:
        print(f"  营收: {float(revenue)/1e8:.2f}亿")
    if profit != "?" and profit:
        print(f"  净利润: {float(profit)/1e8:.2f}亿")
    print(f"  EPS: {eps}")
    print(f"  ROE: {roe}% | 负债率: {debt}%")
    print(f"  经营性现金流: {cf}")

    print(f"\n【技术指标】")
    print(f"  RSI: {rsi} | MACD: {macd}")
    print(f"  MA5: {ma5} | MA10: {ma10} | MA20: {ma20}")

    print(f"\n【资金流向】")
    print(f"  主力净流入: {main_flow} (万元)")

    print(f"\n【股东结构】")
    print(f"  股东人数: {holder_count} | 前十大股东占比: {top10_pct}%")

    print(f"\n【机构观点】")
    print(f"  目标价: {inst_target} | 评级: {inst_rating}")

    # 汇总数据字典
    return {
        "name": name, "code": code, "price": price,
        "pe": pe, "pb": pb, "roe": roe, "debt": debt,
        "revenue": revenue, "profit": profit, "eps": eps,
        "cash_flow": cf, "fund_flow": main_flow,
        "rsi": rsi, "macd": macd,
        "ma5": ma5, "ma10": ma10, "ma20": ma20,
        "dividend_yield": dividend_yield,
        "controller": controller, "main_business": main_biz,
        "holder_count": holder_count, "top10_pct": top10_pct,
        "inst_target": inst_target, "inst_rating": inst_rating,
        "raw_data": data
    }

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    stocks = sys.argv[1:]
    all_results = {}
    for s in stocks:
        try:
            r = analyze_single(s)
            all_results[s] = r
        except Exception as e:
            print(f"❌ {s} 采集失败: {e}")
        time.sleep(0.5)

    if all_results:
        print(f"\n\n{'='*60}")
        print("  📋 数据采集汇总")
        print(f"{'='*60}")
        for s, r in all_results.items():
            print(f"\n{r['name']}({r['code']}) ¥{r['price']} | PE={r['pe']} ROE={r['roe']}% RSI={r['rsi']} 主力={r['fund_flow']}")
        print(f"\n[JSON_OUTPUT]")
        print(json.dumps(all_results, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
