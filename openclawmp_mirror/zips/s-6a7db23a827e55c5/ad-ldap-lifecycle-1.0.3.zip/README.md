# AD LDAP 用户生命周期管理器

管理企业 Active Directory 用户生命周期：入职创建账号、离职禁用账号、定期审计、多维表格同步。

## 功能

- **用户查询**：按 OU 或全域名查询 AD 用户
- **入职流程**：创建 AD 账号、自动加入分组、设置初始密码
- **离职流程**：禁用账号、移除分组
- **定期审计**：检测僵尸账号、密码过期、特权账号
- **飞书同步**：将 AD 用户数据同步到飞书多维表格

## 核心脚本

| 脚本 | 功能 |
|------|------|
| scripts/new-employee.ps1 | 入职 - 创建账号并加入分组 |
| scripts/offboard-employee.ps1 | 离职 - 禁用/删除账号 |
| scripts/audit.ps1 | 审计 - 僵尸账号、密码过期 |
| scripts/sync-to-feishu.ps1 | 同步到飞书多维表格 |

## 重要：UTF-8 编码

调用飞书 API 时，**必须**使用 UTF-8 字节数组传 body。

## 配置

编辑 `config/settings.json` 配置 AD 域名、服务器地址、飞书多维表格参数。

## 版本历史

### v1.0.3 (2026-03-26)
- 改进：敏感信息配置项改为 `<placeholder>` 格式，用户一目了然

### v1.0.2 (2026-03-26)
- 安全修复：移除 config/settings.json 中硬编码的飞书 app_secret、access_token、默认密码
- 修复：feishu-bitables.ps1 不再硬编码 app_id，改为从配置文件读取

### v1.0.1
- 内部优化