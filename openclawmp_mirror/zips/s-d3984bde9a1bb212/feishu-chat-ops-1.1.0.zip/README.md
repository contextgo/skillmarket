# 飞书群聊管理 Skill

## ⚠️ 重要：每次执行前必须先检测配置

```bash
python3 skills/feishu-chat-ops/scripts/setup.py
```

- 输出 `STATUS:ready` → 直接执行操作
- 输出 `STATUS:not_configured` → 进入引导流程（见下方）
- 输出 `STATUS:invalid` → 凭证有误，重新引导

---

## 🤖 自动引导配置流程（STATUS:not_configured 时执行）

当检测到未配置时，**主动向用户说**：

> 我需要你的飞书应用凭证才能帮你管理群聊。
>
> 请按以下步骤操作：
> 1. 打开飞书开放平台：https://open.feishu.cn/
> 2. 进入「我的应用」→ 选择你的应用（没有就新建一个企业自建应用）
> 3. 点击「凭证与基础信息」，复制 **App ID** 和 **App Secret**
> 4. 在「权限管理」中开启这 3 个权限：
>    - `im:chat`（读取群信息）
>    - `im:chat:create`（创建群聊）
>    - `im:chat.member:write`（管理群成员）
> 5. 把 App ID 和 App Secret 发给我，我来完成配置 ✅

**用户回复后**，运行以下命令保存配置：
```bash
python3 skills/feishu-chat-ops/scripts/setup.py --set <用户给的AppID> <用户给的AppSecret>
```

配置成功后**自动继续**执行用户原本的请求。

---

## 🚀 操作命令

### 创建群
```bash
python3 skills/feishu-chat-ops/scripts/chat.py create "群名称"
python3 skills/feishu-chat-ops/scripts/chat.py create "群名称" --desc "群描述"
# 创建并邀请成员
python3 skills/feishu-chat-ops/scripts/chat.py create "群名称" --members ou_xxx ou_yyy
```

### 列出机器人所在的群
```bash
python3 skills/feishu-chat-ops/scripts/chat.py list
```

### 按名字邀请用户进群（自动搜索）
```bash
python3 skills/feishu-chat-ops/scripts/chat.py invite <chat_id> 张三
```

### 按 open_id 添加成员
```bash
python3 skills/feishu-chat-ops/scripts/chat.py add <chat_id> ou_xxx [ou_yyy ...]
```

### 添加机器人到群（by app_id）
```bash
python3 skills/feishu-chat-ops/scripts/chat.py addbot <chat_id> cli_xxx
```

### 解散群
```bash
python3 skills/feishu-chat-ops/scripts/chat.py delete <chat_id>
```

---

## 📦 安装方法

```bash
# 解压到 OpenClaw workspace 的 skills 目录
tar -xzf feishu-chat-ops.tar.gz -C /opt/openclaw/workspace/skills/

# 重启 openclaw
sudo systemctl restart openclaw.service
```

安装后直接说「建群」或「创建飞书群」，龙虾会自动引导完成配置。