#!/usr/bin/env python3
"""
亚马逊运营季度报告生成器

用法: python generate_report.py --data <json_file> --output <output.xlsx>

JSON 数据结构见本文件开头的 data_schema 注释。
"""

import json
import argparse
import sys
import os
from datetime import datetime

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side, numbers
    from openpyxl.utils import get_column_letter
except ImportError:
    print("错误: 需要 openpyxl。运行 pip install openpyxl 后重试。")
    sys.exit(1)

# ─── 样式定义 ───
TITLE_FONT = Font(name='Microsoft YaHei', size=16, bold=True, color='1F4E79')
HEADER_FONT = Font(name='Microsoft YaHei', size=11, bold=True, color='FFFFFF')
HEADER_FILL = PatternFill('solid', fgColor='2E75B6')
SECTION_FONT = Font(name='Microsoft YaHei', size=13, bold=True, color='2E75B6')
LABEL_FONT = Font(name='Microsoft YaHei', size=10, bold=True, color='1F4E79')
CONTENT_FONT = Font(name='Microsoft YaHei', size=10)
NOTE_FONT = Font(name='Microsoft YaHei', size=9, italic=True, color='666666')
RED_FONT = Font(name='Microsoft YaHei', size=10, color='C00000', bold=True)
GREEN_FONT = Font(name='Microsoft YaHei', size=10, color='006100')
WRAP = Alignment(wrap_text=True, vertical='top')
CENTER = Alignment(horizontal='center', vertical='center')
RIGHT = Alignment(horizontal='right', vertical='center')
THIN_BORDER = Border(
    left=Side(style='thin'), right=Side(style='thin'),
    top=Side(style='thin'), bottom=Side(style='thin')
)
SUB_HEADER_FILL = PatternFill('solid', fgColor='D6E4F0')

def apply_cell_style(ws, row, col, value=None, font=None, fill=None, 
                     alignment=None, border=THIN_BORDER, number_format=None):
    cell = ws.cell(row=row, column=col, value=value)
    if font: cell.font = font
    if fill: cell.fill = fill
    if alignment: cell.alignment = alignment
    if border: cell.border = border
    if number_format: cell.number_format = number_format
    return cell

def write_header_row(ws, row, headers, col_offset=1, fill=HEADER_FILL, font=HEADER_FONT):
    for i, h in enumerate(headers):
        c = apply_cell_style(ws, row, col_offset + i, h, font=font, fill=fill, 
                            alignment=CENTER, border=THIN_BORDER)
    return row

def write_section_title(ws, row, title):
    ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
    apply_cell_style(ws, row, 1, title, font=SECTION_FONT)
    ws.row_dimensions[row].height = 28
    return row + 1

# ─── 模块一：整体业绩 ───
def build_module1(ws, data):
    row = write_section_title(ws, ws.max_row + 2, '一、整体业绩')
    
    # 表1：Q1数据概览
    row = write_section_title(ws, row, '表1：Q1 数据概览')
    headers = ['指标', '数值']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    overview = data.get('module1_overview', {})
    items = [
        ('Q1 在售链接数量（父体）', overview.get('parent_count', '')),
        ('Q1 在售链接数量（子体）', overview.get('child_count', '')),
        ('Q1 销售额（¥）', overview.get('sales', '')),
        ('销售额环比增长率', overview.get('sales_growth', '')),
        ('Q1 销量（件）', overview.get('volume', '')),
        ('销量环比增长率', overview.get('volume_growth', '')),
        ('Q1 利润（¥）', overview.get('profit', '')),
        ('利润环比增长率', overview.get('profit_growth', '')),
        ('Q1 广告花费（¥）', overview.get('ad_spend', '')),
        ('广告花费环比增长率', overview.get('ad_spend_growth', '')),
    ]
    for label, val in items:
        apply_cell_style(ws, row, 1, label, font=LABEL_FONT)
        cell = apply_cell_style(ws, row, 2, val, font=CONTENT_FONT, alignment=RIGHT)
        if '增长' in label:
            cell.number_format = '0.00%'
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
        # Actually keep as 2 columns
        ws.unmerge_cells(start_row=row, start_column=1, end_row=row, end_column=2)
        apply_cell_style(ws, row, 1, label, font=LABEL_FONT)
        apply_cell_style(ws, row, 2, val, font=CONTENT_FONT, alignment=RIGHT)
        for c in range(1, 3):
            ws.cell(row=row, column=c).border = THIN_BORDER
        row += 1
    
    # 分析
    analysis1 = overview.get('analysis', '')
    if analysis1:
        row += 1
        apply_cell_style(ws, row, 1, '总结分析:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis1, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(60, len(analysis1) // 2 * 15)
        row += 1

    # 表2：1-3月数据分析
    row = write_section_title(ws, row, '表2：1-3月 月度数据分析')
    headers = ['月份', '销售额(¥)', '环比增长', '销量(件)', '环比增长', '利润(¥)', '环比增长', '广告花费(¥)', '环比增长']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    monthly = data.get('module1_monthly', [])
    for m in monthly:
        vals = [m.get('month', ''), m.get('sales', ''), m.get('sales_growth', ''), 
                m.get('volume', ''), m.get('volume_growth', ''), m.get('profit', ''),
                m.get('profit_growth', ''), m.get('ad_spend', ''), m.get('ad_spend_growth', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '增长' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    analysis2 = data.get('module1_monthly_analysis', '')
    if analysis2:
        row += 1
        apply_cell_style(ws, row, 1, '总结分析:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis2, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(60, len(analysis2) // 2 * 15)
        row += 1

    # 表3：各站点数据对比
    row = write_section_title(ws, row, '表3：各站点数据对比')
    headers = ['站点', '销量(件)', '销量占比', '销售额(¥)', '销售额占比', '广告费(¥)', '广告费占比', 
               '仓储费(¥)', '毛利润(¥)', '毛利率']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    sites = data.get('module1_sites', [])
    for s in sites:
        vals = [s.get('site', ''), s.get('volume', ''), s.get('volume_ratio', ''),
                s.get('sales', ''), s.get('sales_ratio', ''), s.get('ad_spend', ''),
                s.get('ad_ratio', ''), s.get('storage', ''), s.get('gross_profit', ''),
                s.get('gross_margin', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i] or '毛利率' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    analysis3 = data.get('module1_sites_analysis', '')
    if analysis3:
        row += 1
        apply_cell_style(ws, row, 1, '总结分析:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis3, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(60, len(analysis3) // 2 * 15)
        row += 1

    # 表4：各产品数据占比
    row = write_section_title(ws, row, '表4：各产品数据占比')
    headers = ['产品', '销量(件)', '销量占比', '销售额(¥)', '销售额占比', '毛利润(¥)', '毛利润占比', '均价(¥)']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    products = data.get('module1_products', [])
    for p in products:
        vals = [p.get('product', ''), p.get('volume', ''), p.get('volume_ratio', ''),
                p.get('sales', ''), p.get('sales_ratio', ''), p.get('profit', ''),
                p.get('profit_ratio', ''), p.get('avg_price', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    analysis4 = data.get('module1_products_analysis', '')
    if analysis4:
        row += 1
        apply_cell_style(ws, row, 1, '总结分析:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis4, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(60, len(analysis4) // 2 * 15)
        row += 1

    return row

# ─── 模块二：利润与成本 ───
def build_module2(ws, data):
    row = write_section_title(ws, ws.max_row + 2, '二、利润与成本')
    
    headers = ['月份', '毛利率', 'ACOS', 'ACOAS', 'FBA仓储费(¥)', '长期仓储费(¥)', '移除弃置费(¥)', '广告花费(¥)']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    costs = data.get('module2_costs', [])
    for c in costs:
        vals = [c.get('month', ''), c.get('gross_margin', ''), c.get('acos', ''),
                c.get('acoas', ''), c.get('fba_storage', ''), c.get('long_storage', ''),
                c.get('removal', ''), c.get('ad_spend', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '率' in headers[i] or 'ACOS' in headers[i] or 'ACOAS' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    analysis = data.get('module2_analysis', '')
    if analysis:
        row += 1
        apply_cell_style(ws, row, 1, '成本剖析与优化措施:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(80, len(analysis) // 2 * 15)
        row += 1

    return row

# ─── 模块三：库存管理 ───
def build_module3(ws, data):
    row = write_section_title(ws, ws.max_row + 2, '三、库存管理')
    
    # FBA库存
    row = write_section_title(ws, row, 'FBA 库存统计')
    headers = ['产品/链接', '总库存', '0-90天', '0-90天占比', '91-180天', '91-180天占比',
               '180-270天', '180-270天占比', '270天以上', '270天以上占比']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    fba = data.get('module3_fba', [])
    for f in fba:
        vals = [f.get('product', ''), f.get('total', ''), f.get('d0_90', ''), f.get('d0_90_ratio', ''),
                f.get('d91_180', ''), f.get('d91_180_ratio', ''), f.get('d181_270', ''), 
                f.get('d181_270_ratio', ''), f.get('d270_plus', ''), f.get('d270_plus_ratio', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    # 本地库存
    row = write_section_title(ws, row, '本地库存统计')
    headers = ['产品/链接', '总库存', '30天+未发货', '30天+占比', '60天+未发货', '60天+占比', '90天+未发货', '90天+占比']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    local_inv = data.get('module3_local', [])
    for l in local_inv:
        vals = [l.get('product', ''), l.get('total', ''), l.get('d30_plus', ''), l.get('d30_ratio', ''),
                l.get('d60_plus', ''), l.get('d60_ratio', ''), l.get('d90_plus', ''), l.get('d90_ratio', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    analysis = data.get('module3_analysis', '')
    if analysis:
        row += 1
        apply_cell_style(ws, row, 1, '库存分析与优化措施:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(80, len(analysis) // 2 * 15)
        row += 1

    return row

# ─── 模块四：广告指标 ───
def build_module4(ws, data):
    row = write_section_title(ws, ws.max_row + 2, '四、广告指标')
    
    # 各广告类型表现
    row = write_section_title(ws, row, '各广告类型表现')
    headers = ['广告类型', '花费(¥)', '花费占比', '展示次数', '点击次数', 'CTR', 'ACOS', 'ROAS']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    ad_types = data.get('module4_ad_types', [])
    for a in ad_types:
        vals = [a.get('type', ''), a.get('spend', ''), a.get('spend_ratio', ''),
                a.get('impressions', ''), a.get('clicks', ''), a.get('ctr', ''),
                a.get('acos', ''), a.get('roas', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i] or 'CTR' in headers[i] or 'ACOS' in headers[i]:
                cell.number_format = '0.00%'
            if 'ROAS' in headers[i]:
                cell.number_format = '0.00'
        row += 1
    
    # 新品老品花费
    row = write_section_title(ws, row, '新品/老品广告花费')
    headers = ['品类', '花费(¥)', '花费占比', '订单数', 'ACOS']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    new_old = data.get('module4_new_old', [])
    for n in new_old:
        vals = [n.get('category', ''), n.get('spend', ''), n.get('spend_ratio', ''),
                n.get('orders', ''), n.get('acos', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i] or 'ACOS' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    # SKU 分类花费
    row = write_section_title(ws, row, '爆款/利润款/平销/滞销 SKU 花费对比')
    headers = ['SKU分类', '花费(¥)', '花费占比', '订单数', 'ACOS', '利润率']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    sku_types = data.get('module4_sku_types', [])
    for s in sku_types:
        vals = [s.get('category', ''), s.get('spend', ''), s.get('spend_ratio', ''),
                s.get('orders', ''), s.get('acos', ''), s.get('profit_margin', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i] or 'ACOS' in headers[i] or '利润率' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    analysis = data.get('module4_analysis', '')
    if analysis:
        row += 1
        apply_cell_style(ws, row, 1, '广告分析:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(80, len(analysis) // 2 * 15)
        row += 1

    return row

# ─── 模块五：产品表现 ───
def build_module5(ws, data):
    row = write_section_title(ws, ws.max_row + 2, '五、产品表现')
    
    # 爆款SKU
    row = write_section_title(ws, row, '爆款 SKU 表现')
    headers = ['SKU', '月份', '小类排名', '核心关键词排位', 'ACOS', 'CVR', '退货率', '利润率']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    hot_skus = data.get('module5_hot', [])
    for h in hot_skus:
        vals = [h.get('sku', ''), h.get('month', ''), h.get('rank', ''),
                h.get('keyword_rank', ''), h.get('acos', ''), h.get('cvr', ''),
                h.get('return_rate', ''), h.get('profit_margin', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if 'ACOS' in headers[i] or 'CVR' in headers[i] or '退货率' in headers[i] or '利润率' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    # Q2 预测
    q2_pred = data.get('module5_q2_prediction', '')
    if q2_pred:
        row += 1
        apply_cell_style(ws, row, 1, 'Q2 关键词趋势与预测:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, q2_pred, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(80, len(q2_pred) // 2 * 15)
        row += 1

    # 新品表现
    row = write_section_title(ws, row, '新品表现')
    headers = ['SKU', '上线日期', '推广周期(天)', '销售额(¥)', '销售占比', 'CVR', 'ACoS']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    new_skus = data.get('module5_new', [])
    for n in new_skus:
        vals = [n.get('sku', ''), n.get('launch_date', ''), n.get('promo_days', ''),
                n.get('sales', ''), n.get('sales_ratio', ''), n.get('cvr', ''), n.get('acos', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
            if '占比' in headers[i] or 'CVR' in headers[i] or 'ACoS' in headers[i]:
                cell.number_format = '0.00%'
        row += 1
    
    analysis = data.get('module5_analysis', '')
    if analysis:
        row += 1
        apply_cell_style(ws, row, 1, '新品分析与竞品动态:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, analysis, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(80, len(analysis) // 2 * 15)
        row += 1

    return row

# ─── 模块六：Q2目标规划 ───
def build_module6(ws, data):
    row = write_section_title(ws, ws.max_row + 2, '六、Q2 目标规划')
    
    # 目标表
    row = write_section_title(ws, row, 'Q2 目标与实现路径')
    headers = ['指标', 'Q1 实际', 'Q2 目标', '年度目标', '达成路径/备注']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    targets = data.get('module6_targets', [])
    for t in targets:
        vals = [t.get('metric', ''), t.get('q1_actual', ''), t.get('q2_target', ''),
                t.get('annual_target', ''), t.get('path', '')]
        for i, v in enumerate(vals):
            cell = apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
        ws.cell(row=row, column=5).alignment = WRAP
        row += 1
    
    # 开品进度
    row = write_section_title(ws, row, '开品进度')
    headers = ['产品', '当前阶段', '预计上架时间', '目标月销', '负责人']
    write_header_row(ws, row, headers, col_offset=1)
    row += 1
    
    dev = data.get('module6_dev', [])
    for d in dev:
        vals = [d.get('product', ''), d.get('stage', ''), d.get('eta', ''),
                d.get('target_sales', ''), d.get('owner', '')]
        for i, v in enumerate(vals):
            apply_cell_style(ws, row, i + 1, v, font=CONTENT_FONT, alignment=CENTER)
        row += 1
    
    # Q3 基础铺垫
    q3 = data.get('module6_q3_prep', '')
    if q3:
        row += 1
        apply_cell_style(ws, row, 1, 'Q3 基础铺垫计划:', font=SECTION_FONT)
        row += 1
        ws.merge_cells(start_row=row, start_column=1, end_row=row, end_column=10)
        apply_cell_style(ws, row, 1, q3, font=CONTENT_FONT, alignment=WRAP)
        ws.row_dimensions[row].height = max(80, len(q3) // 2 * 15)
        row += 1

    return row

# ─── 主函数 ───
def main():
    parser = argparse.ArgumentParser(description='生成亚马逊运营季度报告')
    parser.add_argument('--data', required=True, help='JSON 数据文件路径')
    parser.add_argument('--output', required=True, help='输出 Excel 文件路径')
    parser.add_argument('--title', default='Q1 运营季度总结报告', help='报告标题')
    args = parser.parse_args()
    
    with open(args.data, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = '季度报告'
    
    # 页面设置
    ws.page_setup.orientation = 'landscape'
    ws.page_setup.fitToWidth = 1
    ws.page_setup.fitToHeight = 0
    ws.page_margins.left = 0.5
    ws.page_margins.right = 0.5
    ws.page_margins.top = 0.5
    ws.page_margins.bottom = 0.5
    
    # 列宽
    col_widths = {1: 22, 2: 16, 3: 14, 4: 16, 5: 14, 6: 16, 7: 14, 8: 16, 9: 14, 10: 16}
    for col, width in col_widths.items():
        ws.column_dimensions[get_column_letter(col)].width = width
    
    # 报告标题
    ws.merge_cells('A1:J1')
    apply_cell_style(ws, 1, 1, args.title, font=TITLE_FONT)
    ws.row_dimensions[1].height = 35
    ws.merge_cells('A2:J2')
    apply_cell_style(ws, 2, 1, f'生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}  |  币种: 人民币(¥)', font=NOTE_FONT)
    
    row = 4
    
    if 'module1_overview' in data:
        row = build_module1(ws, data)
    if 'module2_costs' in data:
        row = build_module2(ws, data)
    if 'module3_fba' in data:
        row = build_module3(ws, data)
    if 'module4_ad_types' in data:
        row = build_module4(ws, data)
    if 'module5_hot' in data:
        row = build_module5(ws, data)
    if 'module6_targets' in data:
        row = build_module6(ws, data)
    
    wb.save(args.output)
    print(f'Report generated: {args.output}')

if __name__ == '__main__':
    main()
