# 模块一：整体业绩 — 数据收集指南

## 表1：Q1 数据概览

需要字段：
| 字段 | 说明 |
|------|------|
| `parent_count` | Q1 在售父体数量 |
| `child_count` | Q1 在售子体数量 |
| `sales` | Q1 销售额（¥） |
| `sales_growth` | 销售额环比增长率 |
| `volume` | Q1 销量 |
| `volume_growth` | 销量环比增长率 |
| `profit` | Q1 利润 |
| `profit_growth` | 利润环比增长率 |
| `ad_spend` | Q1 广告花费 |
| `ad_spend_growth` | 广告花费环比增长率 |
| `analysis` | 数据下滑分析文字 |

## 表2：1-3月月度数据

每月需要：`month`, `sales`, `sales_growth`, `volume`, `volume_growth`, `profit`, `profit_growth`, `ad_spend`, `ad_spend_growth`

## 表3：各站点数据对比

每站点需要：`site`, `volume`, `volume_ratio`, `sales`, `sales_ratio`, `ad_spend`, `ad_ratio`, `storage`, `gross_profit`, `gross_margin`

## 表4：各产品数据占比

每产品需要：`product`, `volume`, `volume_ratio`, `sales`, `sales_ratio`, `profit`, `profit_ratio`, `avg_price`
