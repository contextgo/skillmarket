# 模块四：广告指标 — 数据收集指南

## 广告类型表现 (SP/SD/SB)

每类型需要：
| 字段 | 说明 |
|------|------|
| `type` | SP / SD / SB |
| `spend` | 花费（¥） |
| `spend_ratio` | 花费占比 |
| `impressions` | 展示次数 |
| `clicks` | 点击次数 |
| `ctr` | 点击率 |
| `acos` | ACOS |
| `roas` | ROAS |

## 新品/老品花费

每品类需要：`category`（新品/老品）, `spend`, `spend_ratio`, `orders`, `acos`

## SKU 分类花费

每分类需要：`category`（爆款SKU/利润款SKU/平销SKU/滞销SKU）, `spend`, `spend_ratio`, `orders`, `acos`, `profit_margin`

## 分析要点

1. SP/SD/SB 投入产出比是否合理？
2. 新品广告占比是否过高或过低？
3. 滞销 SKU 是否还在消耗大量广告费？
4. 爆款是否广告预算不足？
