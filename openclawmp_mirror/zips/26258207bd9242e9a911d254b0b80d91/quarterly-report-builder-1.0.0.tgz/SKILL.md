---
name: quarterly-report-builder
description: >
  生成亚马逊运营经理季度总结报告（Excel）。支持完整 6 大模块：
  整体业绩、利润与成本、库存管理、广告指标、产品表现、Q2 目标规划。
  使用场景：用户提到"季度报告""Q1/Q2/Q3/Q4 总结""运营季报"
  "亚马逊运营报告""季度数据分析"，或明确引用本报告模板的章节。
  NOT for: 月度报告、周报、非亚马逊电商报告。
---

# Quarterly Report Builder

生成亚马逊运营经理季度总结报告，输出为 Excel 文件。

## 快速开始

1. 确认用户负责的站点范围和产品线
2. 按 6 大模块逐一引导用户提供数据
3. 调用 `scripts/generate_report.py` 生成 Excel
4. 引导用户审阅表格与 AI 总结分析

```bash
python scripts/generate_report.py --data <json_data_file> --output <output.xlsx>
```

## 模块与文件对应

| 模块 | 内容 | 参考文件 |
|------|------|---------|
| 一、整体业绩 | 表 1-4 + 分析 | `references/module1.md` |
| 二、利润与成本 | 毛利率/ACOS/仓储费 | `references/module2.md` |
| 三、库存管理 | FBA + 本地库存 | `references/module3.md` |
| 四、广告指标 | SP/SD/SB + SKU 分类 | `references/module4.md` |
| 五、产品表现 | 爆款/新品 | `references/module5.md` |
| 六、Q2 目标规划 | 目标 + 路径 | `references/module6.md` |

用户只关心其中几个模块时，按需加载对应 reference。

## 数据引导策略

**不要一次性要所有数据。** 按模块分批引导，每次只收集一个模块需要的字段。

每次收集完一个模块的数据后：
1. 用表格展示给用户确认
2. 确认无误后进入下一个模块
3. 所有模块完成后调用脚本生成 Excel

## 货币与格式

- 所有金额单位：人民币（¥）
- 环比增长率 = (本期 - 上期) / 上期 × 100%
- 占比 = 分项 / 合计 × 100%
- Excel 中所有比率列自动设置百分比格式

## 脚本参数

`scripts/generate_report.py` 接受 JSON 格式数据文件，结构见脚本头部注释。
运行后输出带格式的完整 Excel 报表。
