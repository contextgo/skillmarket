---
name: ontology
description: Typed knowledge graph for structured agent memory and composable skills. Use when creating/querying entities (Person, Project, Task, Event, Document), linking related objects, enforcing constraints, planning multi-step actions as graph transformations, or when skills need to share state. Trigger on "remember", "what do I know about", "link X to Y", "show dependencies", entity CRUD, or cross-skill data access.
---

# Ontology

A typed vocabulary + constraint system for representing knowledge as a verifiable graph.

## Core Concept

Everything is an **entity** with a **type**, **properties**, and **relations** to other entities. Every mutation is validated against type constraints before committing.

```
Entity: { id, type, properties, relations, created, updated }
Relation: { from_id, relation_type, to_id, properties }
```

## When to Use

| Trigger | Action |
|---------|--------|
| "Remember that..." | Create/update entity |
| "What do I know about X?" | Query graph |
| "Link X to Y" | Create relation |
| "Show all tasks for project Z" | Graph traversal |
| "What depends on X?" | Dependency query |
| Planning multi-step work | Model as graph transformations |
| Skill needs shared state | Read/write ontology objects |

## Core Types

```yaml
# Agents & People
Person: { name, email?, phone?, notes? }
Organization: { name, type?, members[] }

# Work
Project: { name, status, goals[], owner? }
Task: { title, status, due?, priority?, assignee?, blockers[] }
Goal: { description, target_date?, metrics[] }

# Time & Place
Event: { title, start, end?, location?, attendees[], recurrence? }
Location: { name, address?, coordinates? }

# Information
Document: { title, path?, url?, summary? }
Message: { content, sender, recipients[], thread? }
Thread: { subject, participants[], messages[] }
Note: { content, tags[], refs[] }

# Resources
Account: { service, username, credential_ref? }
Device: { name, type, identifiers[] }
Credential: { service, secret_ref }  # Never store secrets directly

# Meta
Action: { type, target, timestamp, outcome? }
Policy: { scope, rule, enforcement }
```

## Storage

Data is stored inside the skill's own directory, regardless of where the skill
is installed or called from:

```
<skill-root>/memory/ontology/graph.jsonl   ← entity + relation log
<skill-root>/memory/ontology/schema.yaml   ← optional type constraints
```

The `memory/ontology/` directory is created automatically on first use.
You do not need to create it manually.

```jsonl
{"op":"create","entity":{"id":"p_001","type":"Person","properties":{"name":"Alice"}}}
{"op":"create","entity":{"id":"proj_001","type":"Project","properties":{"name":"Website Redesign","status":"active"}}}
{"op":"relate","from":"proj_001","rel":"has_owner","to":"p_001"}
```

Query via scripts or direct file ops. For complex graphs, migrate to SQLite.

### Append-Only Rule

When working with existing ontology data or schema, **append/merge** changes instead of overwriting files. This preserves history and avoids clobbering prior definitions.

## Quick Start

### Step 0 — Install dependencies (first time only)

```bash
python scripts/setup.py --install
```

To verify without installing:

```bash
python scripts/setup.py --check
```

### Step 1 — Create entities and relations

```bash
python scripts/ontology.py create --type Person --props-file person.json
python scripts/ontology.py create --type Project --props-file project.json
python scripts/ontology.py relate --from proj_001 --rel has_owner --to p_001
```

### Step 2 — Query

```bash
python scripts/ontology.py list --type Person
python scripts/ontology.py query --type Task --where-file filter.json
```

### Step 3 — Validate (optional)

```bash
python scripts/ontology.py validate
```

## Workflows

### Cross-platform note

Shell quoting of JSON strings differs between operating systems.
**Use file-based parameters to avoid quoting issues on all platforms:**

```bash
# Step 1: write your properties to a JSON file
# props.json: {"name": "Alice", "email": "alice@example.com"}

# Step 2: pass the file to the script
python scripts/ontology.py create --type Person --props-file props.json
python scripts/ontology.py query --type Task --where-file filter.json
python scripts/ontology.py update --id task_001 --props-file updates.json
```

Inline JSON strings work on Linux/macOS only:

```bash
# Linux/macOS only
python scripts/ontology.py create --type Person --props '{"name":"Alice"}'
```

### Create Entity

```bash
# Cross-platform (recommended)
python scripts/ontology.py create --type Person --props-file props.json

# Linux/macOS only
python scripts/ontology.py create --type Person --props '{"name":"Alice","email":"alice@example.com"}'
```

### Query

```bash
python scripts/ontology.py query --type Task --where-file filter.json
python scripts/ontology.py get --id task_001
python scripts/ontology.py related --id proj_001 --rel has_task
```

### Link Entities

```bash
python scripts/ontology.py relate --from proj_001 --rel has_task --to task_001
```

The `relate` command is **idempotent**: running it multiple times with the same
`--from`, `--rel`, and `--to` values will not create duplicate entries.

### Validate

```bash
python scripts/ontology.py validate
```

## Constraints

Define in `memory/ontology/schema.yaml`.

The table below shows which constraints are enforced automatically by the
`validate` command and which are advisory (model judgment only):

| Constraint | Status | Enforced by |
|---|---|---|
| Required properties | **Enforced** | `validate` command |
| Forbidden properties | **Enforced** | `validate` command |
| Enum values | **Enforced** | `validate` command |
| Relation type checks | **Enforced** | `validate` command |
| Relation cardinality | **Enforced** | `validate` command |
| Acyclic relations | **Enforced** | `validate` command |
| Event end >= start | **Enforced** | `validate` command |
| Task status transitions | Advisory | Model judgment only |
| Orphan task check | Advisory | Model judgment only |

Example schema fragment:

```yaml
types:
  Task:
    required: [title, status]
    status_enum: [open, in_progress, blocked, done]

  Event:
    required: [title, start]
    validate: "end >= start if end exists"

  Credential:
    required: [service, secret_ref]
    forbidden_properties: [password, secret, token]

relations:
  has_owner:
    from_types: [Project, Task]
    to_types: [Person]
    cardinality: many_to_one

  blocks:
    from_types: [Task]
    to_types: [Task]
    acyclic: true
```

Apply a schema fragment:

```bash
# Cross-platform (recommended)
python scripts/ontology.py schema-append --data-file schema_fragment.json

# Linux/macOS only
python scripts/ontology.py schema-append --data '{"types":{"Task":{"required":["title","status"]}}}'
```

## Skill Contract

Skills that use ontology should declare:

```yaml
# In SKILL.md frontmatter or header
ontology:
  reads: [Task, Project, Person]
  writes: [Task, Action]
  preconditions:
    - "Task.assignee must exist"
  postconditions:
    - "Created Task has status=open"
```

## Planning as Graph Transformation

Model multi-step plans as a sequence of graph operations:

```
Plan: "Schedule team meeting and create follow-up tasks"

1. CREATE Event { title: "Team Sync", attendees: [p_001, p_002] }
2. RELATE Event -> has_project -> proj_001
3. CREATE Task { title: "Prepare agenda", assignee: p_001 }
4. RELATE Task -> for_event -> event_001
5. CREATE Task { title: "Send summary", assignee: p_001, blockers: [task_001] }
```

Each step is validated before execution. Rollback on constraint violation.

## Integration Patterns

### With Causal Inference

Log ontology mutations as causal actions:

```python
action = {
    "action": "create_entity",
    "domain": "ontology",
    "context": {"type": "Task", "project": "proj_001"},
    "outcome": "created"
}
```

### Cross-Skill Communication

```python
# Email skill creates commitment
commitment = ontology.create("Commitment", {
    "source_message": msg_id,
    "description": "Send report by Friday",
    "due": "2026-01-31"
})

# Task skill picks it up
tasks = ontology.query("Commitment", {"status": "pending"})
for c in tasks:
    ontology.create("Task", {
        "title": c.description,
        "due": c.due,
        "source": c.id
    })
```

## References

- `references/schema.md` — Full type definitions and constraint patterns
- `references/queries.md` — Query language and traversal examples
