#!/usr/bin/env python3
"""
Ontology skill — dependency setup.

Usage:
    python scripts/setup.py --check    # Check whether all dependencies are installed
    python scripts/setup.py --install  # Install missing dependencies

This script is intentionally self-contained (stdlib only) so it can always
run before any third-party packages are available.

To add a new dependency for this skill, append it to REQUIRED_PACKAGES below.
The format follows pip requirement specifiers: "package_name>=version".
"""

import subprocess
import sys
from importlib.util import find_spec

# ---------------------------------------------------------------------------
# Declare all skill dependencies here.
# Key   : importable module name (used to check if already installed)
# Value : pip install specifier (used when installing)
# ---------------------------------------------------------------------------
REQUIRED_PACKAGES = {
    "yaml": "pyyaml>=5.1",
}


def check_packages() -> dict[str, bool]:
    """Return {module_name: is_installed} for each required package."""
    return {name: find_spec(name) is not None for name in REQUIRED_PACKAGES}


def install_missing(status: dict[str, bool]) -> bool:
    """Install all packages that are not yet installed. Returns True on success."""
    missing = [REQUIRED_PACKAGES[name] for name, ok in status.items() if not ok]
    if not missing:
        print("[setup] All dependencies are already installed.")
        return True

    print(f"[setup] Installing: {', '.join(missing)}")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", *missing],
        check=False,
    )
    if result.returncode != 0:
        print(
            "[setup] Installation failed. Try running manually:\n"
            f"  pip install {' '.join(missing)}",
            file=sys.stderr,
        )
        return False

    print("[setup] Done.")
    return True


def print_status(status: dict[str, bool]) -> None:
    for module, ok in status.items():
        spec = REQUIRED_PACKAGES[module]
        mark = "OK" if ok else "MISSING"
        print(f"  [{mark}] {spec}")


def main() -> None:
    import argparse

    parser = argparse.ArgumentParser(description="Ontology skill dependency setup")
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--check", action="store_true", help="Check dependencies without installing")
    group.add_argument("--install", action="store_true", help="Install missing dependencies")
    args = parser.parse_args()

    status = check_packages()

    if args.check:
        print("[setup] Dependency status:")
        print_status(status)
        all_ok = all(status.values())
        if not all_ok:
            print("\n[setup] Run: python scripts/setup.py --install")
            sys.exit(1)
    else:
        print_status(status)
        success = install_missing(status)
        if not success:
            sys.exit(1)


if __name__ == "__main__":
    main()
