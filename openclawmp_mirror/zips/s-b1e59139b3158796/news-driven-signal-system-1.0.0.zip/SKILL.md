---
name: news-driven-signal-system
description: "新闻驱动交易信号系统 - 多源新闻采集、关键词匹配、置信度评分"
version: 1.0.0
tags: ["trading", "news", "signals", "prediction-market"]
---

# 新闻驱动交易信号系统

从多个新闻源实时采集信息，通过关键词匹配和市场关联分析，自动生成交易信号和置信度评分。

## 工作流程

### 第一阶段：新闻采集

从以下 6+ 个新闻源异步抓取：

1. **Hacker News** (API) - 科技新闻
2. **Reddit** (RSS) - 社区讨论
3. **CryptoPanic** (API) - 加密货币新闻
4. **CryptoCompare** (RSS) - 市场数据
5. **CoinDesk** (RSS) - 行业新闻
6. **自定义 RSS** - 用户自定义源

```python
import aiohttp
import feedparser
import asyncio

async def fetch_all_sources():
    tasks = [fetch_hackernews(), fetch_reddit(), fetch_cryptopanic()]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [r for r in results if not isinstance(r, Exception)]
```

### 第二阶段：信号匹配

每个市场维护关键词字典：

```python
MARKET_KEYWORDS = {
    "oil-price-90": {
        "positive": ["oil", "crude", "brent", "opec", "saudi"],
        "negative": ["surplus", "glut", "demand drop"],
        "weight": 1.0
    },
    "bitcoin-100k": {
        "positive": ["bitcoin", "btc", "crypto rally", "etf"],
        "negative": ["crackdown", "ban", "hack"],
        "weight": 1.2
    }
}
```

### 第三阶段：置信度计算

```
confidence = (matched_signals / total_sources) * weight * recency_factor
```

- 阈值：35% 以下忽略，35-50% 观察，50%+ 强信号
- 时效因子：1h 内 1.0，1-6h 0.7，6-24h 0.4

### 第四阶段：信号聚合

将多个市场信号融合：

```python
def fuse_signals(individual_signals):
    # 加权平均
    weighted_sum = sum(s["confidence"] * s["weight"] for s in individual_signals)
    total_weight = sum(s["weight"] for s in individual_signals)
    return weighted_sum / total_weight if total_weight > 0 else 0
```

## 配置要点

- 运行频率：每小时 1 次
- 源数量：6-10 个
- 关键词库：每个市场 10-20 个关键词
- 置信度阈值：35%（最低），50%（建议），70%（强信号）

## 错误处理

- 单源超时：跳过，不影响其他源
- 全源失败：记录告警，使用上次缓存
- API 限流：指数退避重试（3次）
- RSS 解析错误：记录日志，跳过该条目

## 输出格式

```
📊 信号报告 (2026-03-13 21:00)

🏆 Oil $90 (95%) - 3条信号
  - [Bloomberg] Iran mines strait, Brent hits $101
  - [Reuters] OPEC+ emergency meeting scheduled
  - [CryptoPanic] Oil futures surge 8%

🏆 Bitcoin $100k (72%) - 2条信号
  - [HN] Bitcoin ETF inflows record $2.5B
  - [Reddit] BTC institutional buying accelerating

📊 Ethereum $5,000 (48%) - 1条信号
  - [CoinDesk] ETH L2 activity surges
```

## 适用场景

- 预测市场交易（Polymarket 等）
- 加密货币趋势判断
- 大宗商品价格预测
- 地缘政治风险评估
