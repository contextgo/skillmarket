# DataClaw 工具集

OpenClaw 会话数据导出、匿名化、分享工具链。

## 功能

- 查看 DataClaw 配置状态
- 发现本地 OpenClaw 项目
- 匿名化处理会话数据
- 导出为 JSONL 格式
- 推送到 Hugging Face

## 安装

```bash
openclawmp install skill/@dataclaw-tools
```

## 使用

见 SKILL.md 详细文档。

## 许可证

MIT
