---
name: d3js-dataviz
description: D3.js 数据可视化生成器，支持从数据自动生成交互式 D3.js 可视化图表，涵盖柱状图、折线图、饼图、散点图、热力图、树图、力导向图、桑基图、地理地图等多种图表类型，提供完整代码模板和导出方案。
---

# D3.js 数据可视化生成器 (D3.js DataViz Generator)

> 作者：知白守黑1024

## 概述

D3.js 数据可视化生成器是一个专业的数据可视化工具，能够根据用户的数据和需求，自动生成高质量的交互式 D3.js 可视化代码。支持柱状图、折线图、饼图、散点图、热力图、树图、力导向图、桑基图、地理地图等 10+ 种图表类型。所有生成的代码均为独立的 HTML 文件，可直接在浏览器中打开。

---

## 1. D3.js 基础设置

### 1.1 HTML 模板结构

每个生成的可视化都使用以下标准 HTML 模板：

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据可视化</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        /* 样式在此处定义 */
    </style>
</head>
<body>
    <div id="chart"></div>
    <script>
        // D3.js 代码在此处编写
    </script>
</body>
</html>
```

### 1.2 响应式设计基础

```css
/* 基础响应式样式 */
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}

body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: #ffffff;
    color: #333;
    padding: 20px;
}

#chart {
    width: 100%;
    max-width: 960px;
    margin: 0 auto;
}

#chart svg {
    width: 100%;
    height: auto;
}

/* 工具提示样式 */
.tooltip {
    position: absolute;
    background: rgba(0, 0, 0, 0.8);
    color: #fff;
    padding: 8px 12px;
    border-radius: 6px;
    font-size: 13px;
    pointer-events: none;
    z-index: 1000;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
}
```

### 1.3 通用 D3.js 工具函数

```javascript
// 通用颜色方案
const colorSchemes = {
    // 分类色板（最多 12 种颜色）
    categorical: d3.schemeTableau10,
    // 序列色板（单色渐变）
    sequential: d3.interpolateBlues,
    // 发散色板（双色渐变，适合有正负值的数据）
    diverging: d3.interpolateRdBu,
    // 自定义色板
    custom: ['#4e79a7', '#f28e2b', '#e15759', '#76b7b2', '#59a14f',
             '#edc948', '#b07aa1', '#ff9da7', '#9c755f', '#bab0ac'],
};

// 创建响应式 SVG 容器
function createResponsiveSVG(containerId, marginTop = 40, marginRight = 30,
                              marginBottom = 50, marginLeft = 60) {
    const container = document.getElementById(containerId);
    const fullWidth = container.clientWidth;
    const width = fullWidth - marginLeft - marginRight;
    const height = Math.min(width * 0.56, 500) - marginTop - marginBottom;

    const svg = d3.select(container)
        .append("svg")
        .attr("viewBox", `0 0 ${fullWidth} ${height + marginTop + marginBottom}`)
        .attr("preserveAspectRatio", "xMidYMid meet")
        .append("g")
        .attr("transform", `translate(${marginLeft},${marginTop})`);

    return { svg, width, height, fullWidth };
}

// 通用工具提示创建
function createTooltip() {
    return d3.select("body")
        .append("div")
        .attr("class", "tooltip")
        .style("opacity", 0);
}

// 数字格式化
const formatNumber = d3.format(",");
const formatPercent = d3.format(".1%");
const formatCurrency = d3.format("$,.2f");
```

---

## 2. 柱状图（Bar Chart）

### 2.1 垂直柱状图

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>柱状图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 800px; margin: 0 auto; }
        .bar { cursor: pointer; transition: opacity 0.2s; }
        .bar:hover { opacity: 0.8; }
        .axis text { font-size: 12px; }
        .axis line, .axis path { stroke: #ccc; }
        .title { text-anchor: middle; font-size: 18px; font-weight: 600; margin-bottom: 20px; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 10px 14px; border-radius: 8px; font-size: 13px; pointer-events: none; z-index: 1000; }
    </style>
</head>
<body>
    <div class="chart-container" id="bar-chart"></div>
    <script>
        // 示例数据：2024 年各季度销售额
        const data = [
            { category: "Q1", value: 45000 },
            { category: "Q2", value: 62000 },
            { category: "Q3", value: 78000 },
            { category: "Q4", value: 91000 },
        ];

        const container = document.getElementById("bar-chart");
        const fullWidth = container.clientWidth;
        const margin = { top: 40, right: 30, bottom: 60, left: 70 };
        const width = fullWidth - margin.left - margin.right;
        const height = 400 - margin.top - margin.bottom;

        // 创建比例尺
        const x = d3.scaleBand()
            .domain(data.map(d => d.category))
            .range([0, width])
            .padding(0.3);

        const y = d3.scaleLinear()
            .domain([0, d3.max(data, d => d.value) * 1.1])
            .nice()
            .range([height, 0]);

        // 创建 SVG
        const svg = d3.select("#bar-chart")
            .append("svg")
            .attr("viewBox", `0 0 ${fullWidth} ${400}`)
            .attr("preserveAspectRatio", "xMidYMid meet")
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // 标题
        svg.append("text").attr("class", "title").attr("x", width / 2).attr("y", -10).text("2024 年季度销售额");

        // 创建工具提示
        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        // X 轴
        svg.append("g").attr("class", "axis")
            .attr("transform", `translate(0,${height})`)
            .call(d3.axisBottom(x))
            .selectAll("text").attr("text-anchor", "middle");

        // Y 轴
        svg.append("g").attr("class", "axis")
            .call(d3.axisLeft(y).ticks(5).tickFormat(d3.format("$,d")));

        // Y 轴标签
        svg.append("text").attr("transform", "rotate(-90)").attr("y", -50)
            .attr("x", -height / 2).attr("text-anchor", "middle").attr("font-size", "12px").text("销售额");

        // 绘制柱子
        const color = d3.scaleOrdinal().domain(data.map(d => d.category)).range(["#4e79a7", "#f28e2b", "#e15759", "#76b7b2"]);

        svg.selectAll(".bar").data(data).join("rect")
            .attr("class", "bar")
            .attr("x", d => x(d.category))
            .attr("width", x.bandwidth())
            .attr("y", height)
            .attr("height", 0)
            .attr("fill", d => color(d.category))
            .attr("rx", 4)
            .on("mouseover", function(event, d) {
                tooltip.transition().duration(200).style("opacity", 1);
                tooltip.html(`<strong>${d.category}</strong><br>销售额: $${d3.format(",")(d.value)}`)
                    .style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 30) + "px");
                d3.select(this).attr("opacity", 0.8);
            })
            .on("mouseout", function() {
                tooltip.transition().duration(200).style("opacity", 0);
                d3.select(this).attr("opacity", 1);
            })
            .transition()
            .duration(800)
            .delay((d, i) => i * 100)
            .attr("y", d => y(d.value))
            .attr("height", d => height - y(d.value));

        // 柱子上方数值标签
        svg.selectAll(".value-label").data(data).join("text")
            .attr("class", "value-label")
            .attr("x", d => x(d.category) + x.bandwidth() / 2)
            .attr("y", d => y(d.value) - 8)
            .attr("text-anchor", "middle")
            .attr("font-size", "12px")
            .attr("fill", "#333")
            .text(d => `$${d3.format(",")(d.value)}`)
            .attr("opacity", 0)
            .transition()
            .duration(800)
            .delay((d, i) => i * 100 + 400)
            .attr("opacity", 1);
    </script>
</body>
</html>
```

### 2.2 水平柱状图

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>水平柱状图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 800px; margin: 0 auto; }
        .bar { cursor: pointer; }
        .bar:hover { filter: brightness(1.1); }
        .axis text { font-size: 12px; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 8px 12px; border-radius: 6px; font-size: 13px; pointer-events: none; }
    </style>
</head>
<body>
    <div class="chart-container" id="hbar-chart"></div>
    <script>
        // 示例数据：编程语言流行度排行
        const data = [
            { name: "Python", value: 28.1 },
            { name: "JavaScript", value: 20.8 },
            { name: "Java", value: 15.6 },
            { name: "TypeScript", value: 12.4 },
            { name: "C++", value: 10.3 },
            { name: "Go", value: 8.2 },
            { name: "Rust", value: 6.5 },
            { name: "Swift", value: 4.8 },
        ].sort((a, b) => b.value - a.value);

        const container = document.getElementById("hbar-chart");
        const fullWidth = container.clientWidth;
        const margin = { top: 20, right: 60, bottom: 30, left: 90 };
        const width = fullWidth - margin.left - margin.right;
        const barHeight = 32;
        const height = data.length * (barHeight + 8) - 8;

        const svg = d3.select("#hbar-chart")
            .append("svg")
            .attr("viewBox", `0 0 ${fullWidth} ${height + margin.top + margin.bottom}`)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        const x = d3.scaleLinear().domain([0, d3.max(data, d => d.value) * 1.15]).range([0, width]);
        const y = d3.scaleBand().domain(data.map(d => d.name)).range([0, height]).padding(0.15);

        const color = d3.scaleLinear().domain([0, d3.max(data, d => d.value)]).range(["#76b7b2", "#4e79a7"]);

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        // X 轴
        svg.append("g").attr("transform", `translate(0,${height})`).call(d3.axisBottom(x).ticks(5).tickFormat(d => d + "%"));

        // 柱子
        svg.selectAll(".bar").data(data).join("rect")
            .attr("class", "bar")
            .attr("y", d => y(d.name))
            .attr("height", y.bandwidth())
            .attr("x", 0)
            .attr("width", 0)
            .attr("fill", d => color(d.value))
            .attr("rx", 4)
            .on("mouseover", function(event, d) {
                tooltip.style("opacity", 1).html(`<strong>${d.name}</strong>: ${d.value}%`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 25) + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0))
            .transition().duration(600).delay((d, i) => i * 80)
            .attr("width", d => x(d.value));

        // 数值标签
        svg.selectAll(".label").data(data).join("text")
            .attr("x", d => x(d.value) + 6)
            .attr("y", d => y(d.name) + y.bandwidth() / 2 + 4)
            .attr("font-size", "12px")
            .attr("fill", "#555")
            .text(d => d.value + "%")
            .attr("opacity", 0)
            .transition().duration(400).delay((d, i) => i * 80 + 300)
            .attr("opacity", 1);
    </script>
</body>
</html>
```

---

## 3. 折线图（Line Chart）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>折线图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 800px; margin: 0 auto; }
        .line-path { fill: none; stroke-width: 2.5; stroke-linecap: round; stroke-linejoin: round; }
        .area { opacity: 0.15; }
        .dot { cursor: pointer; }
        .dot:hover { r: 6; }
        .legend { font-size: 13px; }
        .legend-item { cursor: pointer; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 10px 14px; border-radius: 8px; font-size: 13px; pointer-events: none; }
        .grid line { stroke: #eee; stroke-dasharray: 3,3; }
        .grid .domain { display: none; }
    </style>
</head>
<body>
    <div class="chart-container" id="line-chart"></div>
    <script>
        // 示例数据：月度用户增长
        const months = ["1月","2月","3月","4月","5月","6月","7月","8月","9月","10月","11月","12月"];
        const series = [
            { name: "产品A", color: "#4e79a7", values: [120, 180, 250, 320, 410, 520, 610, 720, 830, 950, 1050, 1200] },
            { name: "产品B", color: "#e15759", values: [80, 120, 160, 200, 280, 350, 420, 500, 580, 680, 780, 900] },
            { name: "产品C", color: "#59a14f", values: [50, 70, 90, 130, 170, 220, 260, 310, 380, 440, 520, 600] },
        ];

        const data = months.map((month, i) => ({
            month,
            ...Object.fromEntries(series.map(s => [s.name, s.values[i]]))
        }));

        const container = document.getElementById("line-chart");
        const fullWidth = container.clientWidth;
        const margin = { top: 40, right: 30, bottom: 60, left: 60 };
        const width = fullWidth - margin.left - margin.right;
        const height = 400 - margin.top - margin.bottom;

        const svg = d3.select("#line-chart")
            .append("svg")
            .attr("viewBox", `0 0 ${fullWidth} ${400}`)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        // 标题
        svg.append("text").attr("x", width / 2).attr("y", -10)
            .attr("text-anchor", "middle").attr("font-size", "18px").attr("font-weight", "600")
            .text("2024 年月度用户增长趋势");

        const x = d3.scalePoint().domain(months).range([0, width]).padding(0.1);
        const allValues = series.flatMap(s => s.values);
        const y = d3.scaleLinear().domain([0, d3.max(allValues) * 1.1]).nice().range([height, 0]);

        // 网格
        svg.append("g").attr("class", "grid").call(d3.axisLeft(y).ticks(5).tickSize(-width).tickFormat(""));

        // 坐标轴
        svg.append("g").attr("transform", `translate(0,${height})`).call(d3.axisBottom(x));
        svg.append("g").call(d3.axisLeft(y).ticks(5));

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        // 面积和线条
        series.forEach((s, si) => {
            const area = d3.area()
                .x((d, i) => x(months[i]))
                .y0(height)
                .y1(d => y(d))
                .curve(d3.curveMonotoneX);

            svg.append("path").datum(s.values)
                .attr("class", "area").attr("fill", s.color)
                .attr("d", area).attr("opacity", 0)
                .transition().duration(800).attr("opacity", 0.15);

            const line = d3.line().x((d, i) => x(months[i])).y(d => y(d)).curve(d3.curveMonotoneX);

            const path = svg.append("path").datum(s.values)
                .attr("class", "line-path").attr("stroke", s.color)
                .attr("d", line);

            const pathLength = path.node().getTotalLength();
            path.attr("stroke-dasharray", pathLength)
                .attr("stroke-dashoffset", pathLength)
                .transition().duration(1500).ease(d3.easeQuadOut)
                .attr("stroke-dashoffset", 0);

            // 数据点
            svg.selectAll(`.dot-${si}`).data(s.values).join("circle")
                .attr("class", "dot").attr("cx", (d, i) => x(months[i])).attr("cy", d => y(d))
                .attr("r", 0).attr("fill", s.color).attr("stroke", "#fff").attr("stroke-width", 2)
                .on("mouseover", function(event, d) {
                    const idx = s.values.indexOf(d);
                    tooltip.style("opacity", 1).html(`<strong>${months[idx]}</strong><br>${s.name}: ${d3.format(",")(d)} 用户`);
                    tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 30) + "px");
                })
                .on("mouseout", () => tooltip.style("opacity", 0))
                .transition().duration(300).delay((d, i) => 1000 + i * 50)
                .attr("r", 4);
        });

        // 图例
        const legend = svg.append("g").attr("class", "legend").attr("transform", `translate(${width - 200}, -25)`);
        series.forEach((s, i) => {
            const item = legend.append("g").attr("class", "legend-item").attr("transform", `translate(${i * 75}, 0)`);
            item.append("rect").attr("width", 12).attr("height", 12).attr("rx", 2).attr("fill", s.color);
            item.append("text").attr("x", 16).attr("y", 10).text(s.name);
        });
    </script>
</body>
</html>
```

---

## 4. 饼图（Pie Chart）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>饼图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 600px; margin: 0 auto; text-align: center; }
        .slice { cursor: pointer; transition: opacity 0.2s; }
        .slice:hover { opacity: 0.85; filter: brightness(1.05); }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 10px 14px; border-radius: 8px; font-size: 13px; pointer-events: none; }
    </style>
</head>
<body>
    <div class="chart-container" id="pie-chart"></div>
    <script>
        const data = [
            { label: "直接访问", value: 335 },
            { label: "搜索引擎", value: 580 },
            { label: "社交媒体", value: 284 },
            { label: "邮件营销", value: 154 },
            { label: "联盟广告", value: 220 },
            { label: "其他", value: 130 },
        ];

        const container = document.getElementById("pie-chart");
        const fullWidth = container.clientWidth;
        const size = Math.min(fullWidth, 500);
        const radius = size / 2;

        const svg = d3.select("#pie-chart")
            .append("svg")
            .attr("viewBox", `0 0 ${size} ${size + 40}`)
            .append("g")
            .attr("transform", `translate(${radius},${radius})`);

        // 标题
        svg.append("text").attr("x", 0).attr("y", -radius + 10)
            .attr("text-anchor", "middle").attr("font-size", "16px").attr("font-weight", "600")
            .text("流量来源分布");

        const color = d3.scaleOrdinal().domain(data.map(d => d.label))
            .range(["#4e79a7", "#f28e2b", "#e15759", "#76b7b2", "#59a14f", "#edc948"]);

        const pie = d3.pie().value(d => d.value).sort(null).padAngle(0.02);
        const arc = d3.arc().innerRadius(radius * 0.45).outerRadius(radius * 0.85);
        const arcHover = d3.arc().innerRadius(radius * 0.42).outerRadius(radius * 0.9);
        const arcLabel = d3.arc().innerRadius(radius * 0.88).outerRadius(radius * 0.88);

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);
        const total = d3.sum(data, d => d.value);

        // 绘制扇区
        svg.selectAll(".slice").data(pie(data)).join("path")
            .attr("class", "slice")
            .attr("fill", d => color(d.data.label))
            .attr("stroke", "#fff")
            .attr("stroke-width", 2)
            .on("mouseover", function(event, d) {
                const pct = ((d.data.value / total) * 100).toFixed(1);
                tooltip.style("opacity", 1).html(`<strong>${d.data.label}</strong><br>${d3.format(",")(d.data.value)} (${pct}%)`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 30) + "px");
                d3.select(this).transition().duration(200).attr("d", arcHover);
            })
            .on("mouseout", function(event, d) {
                tooltip.style("opacity", 0);
                d3.select(this).transition().duration(200).attr("d", arc);
            })
            .transition().duration(800)
            .attrTween("d", function(d) {
                const i = d3.interpolate({ startAngle: 0, endAngle: 0 }, d);
                return t => arc(i(t));
            });

        // 标签
        svg.selectAll(".label").data(pie(data)).join("text")
            .attr("transform", d => `translate(${arcLabel.centroid(d)})`)
            .attr("text-anchor", "middle")
            .attr("font-size", "11px")
            .attr("fill", "#fff")
            .attr("font-weight", "500")
            .text(d => {
                const pct = ((d.data.value / total) * 100).toFixed(0);
                return pct > 5 ? pct + "%" : "";
            });

        // 图例
        const legend = d3.select("#pie-chart").select("svg")
            .append("g").attr("transform", `translate(0, ${size + 10})`);

        const itemsPerRow = 3;
        data.forEach((d, i) => {
            const row = Math.floor(i / itemsPerRow);
            const col = i % itemsPerRow;
            const itemWidth = size / itemsPerRow;
            const item = legend.append("g").attr("transform", `translate(${col * itemWidth + 10}, ${row * 22})`);
            item.append("rect").attr("width", 10).attr("height", 10).attr("rx", 2).attr("fill", color(d.label));
            item.append("text").attr("x", 14).attr("y", 9).attr("font-size", "12px").text(d.label);
        });
    </script>
</body>
</html>
```

---

## 5. 散点图（Scatter Plot）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>散点图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 800px; margin: 0 auto; }
        .dot { cursor: pointer; opacity: 0.8; transition: opacity 0.2s; }
        .dot:hover { opacity: 1; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 10px 14px; border-radius: 8px; font-size: 13px; pointer-events: none; }
        .grid line { stroke: #eee; stroke-dasharray: 3,3; }
        .grid .domain { display: none; }
    </style>
</head>
<body>
    <div class="chart-container" id="scatter-chart"></div>
    <script>
        // 生成模拟数据
        const categories = ["A", "B", "C"];
        const data = [];
        for (let i = 0; i < 80; i++) {
            const cat = categories[Math.floor(Math.random() * 3)];
            data.push({
                x: Math.random() * 100,
                y: Math.random() * 80 + Math.random() * 20,
                r: Math.random() * 8 + 4,
                category: cat,
                label: `数据点 ${i + 1}`,
            });
        }

        const container = document.getElementById("scatter-chart");
        const fullWidth = container.clientWidth;
        const margin = { top: 30, right: 30, bottom: 50, left: 60 };
        const width = fullWidth - margin.left - margin.right;
        const height = 400 - margin.top - margin.bottom;

        const svg = d3.select("#scatter-chart")
            .append("svg")
            .attr("viewBox", `0 0 ${fullWidth} ${400}`)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        const x = d3.scaleLinear().domain([0, 100]).range([0, width]);
        const y = d3.scaleLinear().domain([0, 100]).range([height, 0]);
        const r = d3.scaleSqrt().domain([0, d3.max(data, d => d.r)]).range([3, 15]);
        const color = d3.scaleOrdinal().domain(categories).range(["#4e79a7", "#e15759", "#59a14f"]);

        // 网格
        svg.append("g").attr("class", "grid").call(d3.axisLeft(y).ticks(5).tickSize(-width).tickFormat(""));
        svg.append("g").attr("class", "grid").attr("transform", `translate(0,${height})`)
            .call(d3.axisBottom(x).ticks(5).tickSize(-height).tickFormat(""));

        // 坐标轴
        svg.append("g").attr("transform", `translate(0,${height})`).call(d3.axisBottom(x));
        svg.append("g").call(d3.axisLeft(y));

        // 轴标签
        svg.append("text").attr("x", width / 2).attr("y", height + 40)
            .attr("text-anchor", "middle").attr("font-size", "13px").text("X 轴");
        svg.append("text").attr("transform", "rotate(-90)").attr("x", -height / 2).attr("y", -45)
            .attr("text-anchor", "middle").attr("font-size", "13px").text("Y 轴");

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        // 散点
        svg.selectAll(".dot").data(data).join("circle")
            .attr("class", "dot")
            .attr("cx", d => x(d.x))
            .attr("cy", d => y(d.y))
            .attr("r", 0)
            .attr("fill", d => color(d.category))
            .attr("stroke", "#fff")
            .attr("stroke-width", 1)
            .on("mouseover", function(event, d) {
                tooltip.style("opacity", 1).html(`<strong>${d.label}</strong><br>类别: ${d.category}<br>X: ${d.x.toFixed(1)}, Y: ${d.y.toFixed(1)}`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 30) + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0))
            .transition().duration(600).delay((d, i) => i * 10)
            .attr("r", d => r(d.r));

        // 图例
        const legend = svg.append("g").attr("transform", `translate(${width - 120}, 0)`);
        categories.forEach((cat, i) => {
            const item = legend.append("g").attr("transform", `translate(0, ${i * 22})`);
            item.append("circle").attr("r", 6).attr("fill", color(cat));
            item.append("text").attr("x", 12).attr("y", 4).attr("font-size", "12px").text(`类别 ${cat}`);
        });
    </script>
</body>
</html>
```

---

## 6. 热力图（Heatmap）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>热力图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 700px; margin: 0 auto; text-align: center; }
        .cell { cursor: pointer; transition: opacity 0.15s; stroke: #fff; stroke-width: 2; }
        .cell:hover { opacity: 0.8; stroke: #333; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 10px 14px; border-radius: 8px; font-size: 13px; pointer-events: none; }
        .axis text { font-size: 11px; }
    </style>
</head>
<body>
    <div class="chart-container" id="heatmap"></div>
    <script>
        // 示例数据：一周每小时的访问量
        const days = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"];
        const hours = Array.from({ length: 24 }, (_, i) => `${i}:00`);
        const data = [];
        days.forEach((day, di) => {
            hours.forEach((hour, hi) => {
                const isWeekend = di >= 5;
                const isWorkHour = hi >= 9 && hi <= 18;
                let base = isWeekend ? 20 : (isWorkHour ? 60 : 15);
                data.push({
                    day, hour,
                    value: Math.floor(base + Math.random() * 40)
                });
            });
        });

        const container = document.getElementById("heatmap");
        const fullWidth = container.clientWidth;
        const margin = { top: 40, right: 100, bottom: 40, left: 50 };
        const cellSize = Math.min((fullWidth - margin.left - margin.right) / 24, 22);
        const width = cellSize * 24;
        const height = cellSize * 7;

        const svg = d3.select("#heatmap")
            .append("svg")
            .attr("viewBox", `0 0 ${width + margin.left + margin.right + 20} ${height + margin.top + margin.bottom}`)
            .append("g")
            .attr("transform", `translate(${margin.left},${margin.top})`);

        svg.append("text").attr("x", width / 2).attr("y", -15)
            .attr("text-anchor", "middle").attr("font-size", "16px").attr("font-weight", "600")
            .text("一周网站访问量热力图");

        const x = d3.scaleBand().domain(hours).range([0, width]);
        const y = d3.scaleBand().domain(days).range([0, height]);
        const color = d3.scaleSequential(d3.interpolateYlOrRd).domain([0, d3.max(data, d => d.value)]);

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        // X 轴标签
        svg.append("g").selectAll("text").data(hours.filter((_, i) => i % 3 === 0))
            .join("text").attr("x", d => x(d) + x.bandwidth() / 2).attr("y", height + 20)
            .attr("text-anchor", "middle").attr("font-size", "10px").text(d => d);

        // Y 轴标签
        svg.append("g").selectAll("text").data(days)
            .join("text").attr("x", -5).attr("y", d => y(d) + y.bandwidth() / 2 + 4)
            .attr("text-anchor", "end").attr("font-size", "12px").text(d => d);

        // 热力单元
        svg.selectAll(".cell").data(data).join("rect")
            .attr("class", "cell")
            .attr("x", d => x(d.hour))
            .attr("y", d => y(d.day))
            .attr("width", x.bandwidth() - 1)
            .attr("height", y.bandwidth() - 1)
            .attr("fill", d => color(d.value))
            .on("mouseover", function(event, d) {
                tooltip.style("opacity", 1).html(`<strong>${d.day} ${d.hour}</strong><br>访问量: ${d.value}`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 30) + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0));

        // 颜色图例
        const legendWidth = 15;
        const legendHeight = height;
        const legendX = width + 20;
        const legendGradient = svg.append("defs").append("linearGradient")
            .attr("id", "legend-gradient").attr("x1", "0").attr("y1", "0").attr("x2", "0").attr("y2", "1");

        const stops = d3.range(0, 1.01, 0.1);
        stops.forEach(s => {
            legendGradient.append("stop").attr("offset", s * 100 + "%")
                .attr("stop-color", color(s * d3.max(data, d => d.value)));
        });

        svg.append("rect").attr("x", legendX).attr("y", 0).attr("width", legendWidth)
            .attr("height", legendHeight).attr("fill", "url(#legend-gradient)");

        const legendScale = d3.scaleLinear().domain([0, d3.max(data, d => d.value)]).range([legendHeight, 0]);
        const legendAxis = d3.axisRight(legendScale).ticks(5);
        svg.append("g").attr("transform", `translate(${legendX + legendWidth},0)`).call(legendAxis);
    </script>
</body>
</html>
```

---

## 7. 力导向图（Force Graph）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>力导向图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 800px; margin: 0 auto; text-align: center; }
        .link { stroke-opacity: 0.6; stroke-width: 1.5px; }
        .node { cursor: grab; }
        .node:active { cursor: grabbing; }
        .node circle { stroke: #fff; stroke-width: 2px; }
        .node text { font-size: 11px; pointer-events: none; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 8px 12px; border-radius: 6px; font-size: 12px; pointer-events: none; }
    </style>
</head>
<body>
    <div class="chart-container" id="force-graph"></div>
    <script>
        // 示例数据：技术栈关系图
        const nodes = [
            { id: "JavaScript", group: 1, size: 30 },
            { id: "TypeScript", group: 1, size: 22 },
            { id: "React", group: 2, size: 28 },
            { id: "Vue", group: 2, size: 25 },
            { id: "Node.js", group: 3, size: 26 },
            { id: "Next.js", group: 2, size: 20 },
            { id: "Express", group: 3, size: 18 },
            { id: "D3.js", group: 4, size: 16 },
            { id: "MongoDB", group: 5, size: 20 },
            { id: "PostgreSQL", group: 5, size: 22 },
            { id: "GraphQL", group: 3, size: 16 },
            { id: "REST API", group: 3, size: 18 },
        ];

        const links = [
            { source: "JavaScript", target: "TypeScript", value: 5 },
            { source: "JavaScript", target: "React", value: 5 },
            { source: "JavaScript", target: "Vue", value: 5 },
            { source: "JavaScript", target: "Node.js", value: 5 },
            { source: "JavaScript", target: "D3.js", value: 4 },
            { source: "TypeScript", target: "React", value: 4 },
            { source: "React", target: "Next.js", value: 5 },
            { source: "Vue", target: "Node.js", value: 3 },
            { source: "Node.js", target: "Express", value: 5 },
            { source: "Node.js", target: "GraphQL", value: 3 },
            { source: "Node.js", target: "REST API", value: 4 },
            { source: "Express", target: "MongoDB", value: 4 },
            { source: "Express", target: "PostgreSQL", value: 4 },
            { source: "GraphQL", target: "React", value: 3 },
            { source: "PostgreSQL", target: "Next.js", value: 3 },
        ];

        const container = document.getElementById("force-graph");
        const fullWidth = container.clientWidth;
        const width = Math.min(fullWidth, 800);
        const height = 500;

        const svg = d3.select("#force-graph")
            .append("svg")
            .attr("viewBox", `0 0 ${width} ${height}`)
            .attr("width", "100%");

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        const color = d3.scaleOrdinal(d3.schemeTableau10);
        const size = d3.scaleLinear().domain(d3.extent(nodes, d => d.size)).range([6, 25]);

        // 力模拟
        const simulation = d3.forceSimulation(nodes)
            .force("link", d3.forceLink(links).id(d => d.id).distance(80))
            .force("charge", d3.forceManyBody().strength(-300))
            .force("center", d3.forceCenter(width / 2, height / 2))
            .force("collision", d3.forceCollide().radius(d => size(d.size) + 5));

        // 绘制连线
        const link = svg.append("g").selectAll("line").data(links).join("line")
            .attr("class", "link")
            .attr("stroke", "#999");

        // 绘制节点
        const node = svg.append("g").selectAll("g").data(nodes).join("g")
            .attr("class", "node")
            .call(d3.drag()
                .on("start", (event, d) => { if (!event.active) simulation.alphaTarget(0.3).restart(); d.fx = d.x; d.fy = d.y; })
                .on("drag", (event, d) => { d.fx = event.x; d.fy = event.y; })
                .on("end", (event, d) => { if (!event.active) simulation.alphaTarget(0); d.fx = null; d.fy = null; })
            );

        node.append("circle")
            .attr("r", d => size(d.size))
            .attr("fill", d => color(d.group))
            .on("mouseover", function(event, d) {
                tooltip.style("opacity", 1).html(`<strong>${d.id}</strong>`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 25) + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0));

        node.append("text").text(d => d.id).attr("dy", d => -size(d.size) - 6).attr("text-anchor", "middle");

        simulation.on("tick", () => {
            link.attr("x1", d => d.source.x).attr("y1", d => d.source.y)
                .attr("x2", d => d.target.x).attr("y2", d => d.target.y);
            node.attr("transform", d => `translate(${d.x},${d.y})`);
        });
    </script>
</body>
</html>
```

---

## 8. 树图（Treemap）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>树图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 800px; margin: 0 auto; text-align: center; }
        .cell { cursor: pointer; }
        .cell rect { stroke: #fff; stroke-width: 2; transition: opacity 0.15s; }
        .cell:hover rect { opacity: 0.8; }
        .cell text { pointer-events: none; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 8px 12px; border-radius: 6px; font-size: 12px; pointer-events: none; }
    </style>
</head>
<body>
    <div class="chart-container" id="treemap"></div>
    <script>
        const data = {
            name: "项目",
            children: [
                { name: "前端", children: [
                    { name: "React", value: 350 }, { name: "Vue", value: 280 },
                    { name: "Angular", value: 200 }, { name: "Svelte", value: 120 },
                ]},
                { name: "后端", children: [
                    { name: "Node.js", value: 400 }, { name: "Python", value: 350 },
                    { name: "Go", value: 200 }, { name: "Rust", value: 150 },
                ]},
                { name: "数据库", children: [
                    { name: "PostgreSQL", value: 250 }, { name: "MongoDB", value: 200 },
                    { name: "Redis", value: 150 }, { name: "MySQL", value: 180 },
                ]},
                { name: "DevOps", children: [
                    { name: "Docker", value: 300 }, { name: "K8s", value: 250 },
                    { name: "CI/CD", value: 180 },
                ]},
            ]
        };

        const container = document.getElementById("treemap");
        const fullWidth = container.clientWidth;
        const width = Math.min(fullWidth, 800);
        const height = 500;

        const svg = d3.select("#treemap")
            .append("svg")
            .attr("viewBox", `0 0 ${width} ${height + 30}`)
            .attr("width", "100%");

        svg.append("text").attr("x", width / 2).attr("y", 20)
            .attr("text-anchor", "middle").attr("font-size", "16px").attr("font-weight", "600")
            .text("技术栈项目分布");

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        const root = d3.hierarchy(data).sum(d => d.value).sort((a, b) => b.value - a.value);

        d3.treemap()
            .size([width, height])
            .paddingOuter(4)
            .paddingInner(2)
            .round(true)(root);

        const color = d3.scaleOrdinal().domain(data.children.map(d => d.name))
            .range(["#4e79a7", "#e15759", "#59a14f", "#f28e2b"]);

        const leaf = svg.selectAll("g").data(root.leaves()).join("g")
            .attr("class", "cell")
            .attr("transform", d => `translate(${d.x0},${d.y0 + 30})`);

        leaf.append("rect")
            .attr("width", d => Math.max(0, d.x1 - d.x0))
            .attr("height", d => Math.max(0, d.y1 - d.y0))
            .attr("fill", d => color(d.parent.data.name))
            .on("mouseover", function(event, d) {
                tooltip.style("opacity", 1).html(`<strong>${d.data.name}</strong><br>大小: ${d.value}`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 25) + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0));

        leaf.append("text")
            .attr("x", 4).attr("y", 16).attr("font-size", "11px").attr("fill", "#fff")
            .text(d => {
                const w = d.x1 - d.x0;
                return w > 40 ? d.data.name : "";
            });

        leaf.append("text")
            .attr("x", 4).attr("y", 30).attr("font-size", "10px").attr("fill", "rgba(255,255,255,0.8)")
            .text(d => {
                const w = d.x1 - d.x0;
                return w > 50 ? d.value : "";
            });
    </script>
</body>
</html>
```

---

## 9. 桑基图（Sankey Diagram）

```html
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>桑基图</title>
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: -apple-system, sans-serif; background: #fff; padding: 20px; color: #333; }
        .chart-container { max-width: 900px; margin: 0 auto; text-align: center; }
        .node rect { cursor: move; fill-opacity: 0.9; stroke: #fff; stroke-width: 1; }
        .node text { font-size: 12px; pointer-events: none; }
        .link { fill: none; stroke-opacity: 0.4; }
        .link:hover { stroke-opacity: 0.6; }
        .tooltip { position: absolute; background: rgba(0,0,0,0.85); color: #fff; padding: 8px 12px; border-radius: 6px; font-size: 12px; pointer-events: none; }
    </style>
</head>
<body>
    <div class="chart-container" id="sankey"></div>
    <script>
        const data = {
            nodes: [
                { name: "首页" }, { name: "产品页" }, { name: "博客" },
                { name: "关于" }, { name: "搜索" },
                { name: "注册" }, { name: "购买" }, { name: "离开" },
            ],
            links: [
                { source: 0, target: 1, value: 40 },
                { source: 0, target: 2, value: 30 },
                { source: 0, target: 3, value: 15 },
                { source: 0, target: 4, value: 15 },
                { source: 1, target: 5, value: 20 },
                { source: 1, target: 6, value: 15 },
                { source: 1, target: 7, value: 5 },
                { source: 2, target: 5, value: 10 },
                { source: 2, target: 6, value: 8 },
                { source: 2, target: 7, value: 12 },
                { source: 3, target: 5, value: 8 },
                { source: 3, target: 7, value: 7 },
                { source: 4, target: 1, value: 8 },
                { source: 4, target: 6, value: 7 },
            ]
        };

        const container = document.getElementById("sankey");
        const fullWidth = container.clientWidth;
        const width = Math.min(fullWidth, 900);
        const height = 450;

        const svg = d3.select("#sankey")
            .append("svg")
            .attr("viewBox", `0 0 ${width} ${height}`)
            .attr("width", "100%");

        const tooltip = d3.select("body").append("div").attr("class", "tooltip").style("opacity", 0);

        const color = d3.scaleOrdinal(d3.schemeCategory10);

        const sankey = d3.sankey()
            .nodeWidth(20)
            .nodePadding(16)
            .extent([[1, 5], [width - 1, height - 5]]);

        const { nodes, links } = sankey({
            nodes: data.nodes.map(d => ({ ...d })),
            links: data.links.map(d => ({ ...d }))
        });

        // 绘制连线
        const link = svg.append("g").selectAll("path").data(links).join("path")
            .attr("class", "link")
            .attr("d", d3.sankeyLinkHorizontal())
            .attr("stroke", d => color(d.source.index))
            .attr("stroke-width", d => Math.max(1, d.width))
            .on("mouseover", function(event, d) {
                tooltip.style("opacity", 1).html(`${d.source.name} → ${d.target.name}<br>流量: ${d.value}`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 25) + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0));

        // 绘制节点
        const node = svg.append("g").selectAll("g").data(nodes).join("g").attr("class", "node");

        node.append("rect")
            .attr("x", d => d.x0).attr("y", d => d.y0)
            .attr("height", d => Math.max(1, d.y1 - d.y0))
            .attr("width", d => d.x1 - d.x0)
            .attr("fill", d => color(d.index))
            .on("mouseover", function(event, d) {
                tooltip.style("opacity", 1).html(`<strong>${d.name}</strong><br>总流量: ${d.value}`);
                tooltip.style("left", (event.pageX + 10) + "px").style("top", (event.pageY - 25) + "px");
            })
            .on("mouseout", () => tooltip.style("opacity", 0));

        node.append("text")
            .attr("x", d => d.x0 < width / 2 ? d.x1 + 6 : d.x0 - 6)
            .attr("y", d => (d.y1 + d.y0) / 2)
            .attr("dy", "0.35em")
            .attr("text-anchor", d => d.x0 < width / 2 ? "start" : "end")
            .text(d => d.name);
    </script>
</body>
</html>
```

---

## 10. 数据预处理

### 10.1 数据清洗函数

```javascript
// 通用数据预处理函数
function preprocessData(rawData, options = {}) {
    const {
        valueKey = "value",
        sortKey = null,
        sortDir = "desc",
        filterFn = null,
        groupBy = null,
        aggregate = "sum",
        topN = null,
    } = options;

    let data = [...rawData];

    // 过滤
    if (filterFn) data = data.filter(filterFn);

    // 分组聚合
    if (groupBy) {
        const grouped = d3.group(data, d => d[groupBy]);
        data = Array.from(grouped, ([key, values]) => ({
            [groupBy]: key,
            [valueKey]: aggregate === "sum" ? d3.sum(values, d => d[valueKey])
                    : aggregate === "mean" ? d3.mean(values, d => d[valueKey])
                    : aggregate === "count" ? values.length
                    : d3.max(values, d => d[valueKey]),
        }));
    }

    // 排序
    if (sortKey) {
        data.sort((a, b) => sortDir === "desc" ? b[sortKey] - a[sortKey] : a[sortKey] - b[sortKey]);
    }

    // 取前 N
    if (topN) data = data.slice(0, topN);

    return data;
}

// CSV 解析
function parseCSV(csvString) {
    const parsed = d3.csvParse(csvString);
    return parsed.map(row => {
        const obj = {};
        for (const [key, value] of Object.entries(row)) {
            const num = parseFloat(value);
            obj[key] = isNaN(num) || value.trim() === "" ? value : num;
        }
        return obj;
    });
}

// JSON 数据适配
function adaptData(data, mappings) {
    return data.map(item => {
        const adapted = {};
        for (const [newKey, oldKey] of Object.entries(mappings)) {
            adapted[newKey] = typeof oldKey === "function" ? oldKey(item) : item[oldKey];
        }
        return adapted;
    });
}
```

---

## 11. 导出功能

### 11.1 导出为 PNG

```javascript
function exportToPNG(svgElement, filename = "chart.png") {
    const svgData = new XMLSerializer().serializeToString(svgElement);
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const img = new Image();

    // 获取 SVG 尺寸
    const svgRect = svgElement.getBoundingClientRect();
    const scale = 2; // 高分辨率
    canvas.width = svgRect.width * scale;
    canvas.height = svgRect.height * scale;

    img.onload = function () {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

        const link = document.createElement("a");
        link.download = filename;
        link.href = canvas.toDataURL("image/png");
        link.click();
    };

    img.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svgData);
}
```

### 11.2 导出为独立 HTML

```javascript
function exportToHTML(containerId, filename = "chart.html") {
    const container = document.getElementById(containerId);
    const svgElement = container.querySelector("svg");
    const styleElements = document.querySelectorAll("style");
    let styles = "";
    styleElements.forEach(s => styles += s.outerHTML);

    const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>数据可视化</title>
    <script src="https://d3js.org/d3.v7.min.js"><\/script>
    ${styles}
</head>
<body>
    ${svgElement.outerHTML}
</body>
</html>`;

    const blob = new Blob([html], { type: "text/html" });
    const link = document.createElement("a");
    link.download = filename;
    link.href = URL.createObjectURL(blob);
    link.click();
}
```

---

## 12. 无障碍设计（Accessibility）

### 12.1 颜色对比度

```javascript
// 使用 WCAG 合规的颜色方案
const a11yColorSchemes = {
    // 色盲友好色板
    colorBlind: ['#000000', '#E69F00', '#56B4E9', '#009E73', '#F0E442',
                 '#0072B2', '#D55E00', '#CC79A7'],
    // 高对比度色板
    highContrast: ['#1b9e77', '#d95f02', '#7570b3', '#e7298a',
                   '#66a61e', '#e6ab02', '#a6761d', '#666666'],
};

// 确保文本在背景上可读
function getAccessibleTextColor(bgColor) {
    const hex = bgColor.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    const brightness = (r * 299 + g * 587 + b * 114) / 1000;
    return brightness > 128 ? '#000000' : '#ffffff';
}

// 为 SVG 添加 ARIA 标签
svg.attr("role", "img")
   .attr("aria-labelledby", "chart-title chart-desc");

// 添加描述元素
svg.append("desc").attr("id", "chart-desc").text("这是一张柱状图，展示了...");
```

---

## 13. 使用指南

### 快速生成图表

直接描述数据和你想要的图表类型：

```
请根据以下数据生成一个柱状图：
- Python: 28.1%
- JavaScript: 20.8%
- Java: 15.6%
- TypeScript: 12.4%
- Go: 8.2%
```

```
请生成一个交互式折线图，展示以下月度销售数据趋势（带动画和工具提示）
```

```
请将以下 CSV 数据转换为热力图，行是日期，列是小时
```

### 支持的图表类型

| 图表类型 | 适用数据 | 关键词 |
|---------|---------|--------|
| 柱状图 | 分类比较 | bar, 柱状, 比较 |
| 折线图 | 时间序列趋势 | line, 折线, 趋势 |
| 饼图 | 占比分布 | pie, 饼, 占比, 分布 |
| 散点图 | 相关性分析 | scatter, 散点, 相关 |
| 热力图 | 密度矩阵 | heatmap, 热力, 密度 |
| 树图 | 层级占比 | treemap, 树图, 层级 |
| 力导向图 | 关系网络 | force, 关系, 网络 |
| 桑基图 | 流量流转 | sankey, 桑基, 流转 |

---

## 14. 注意事项

1. **D3.js 版本**：本工具使用 D3.js v7，确保引入正确版本
2. **数据格式**：确保数据格式正确，数值字段为数字类型
3. **响应式设计**：所有图表使用 viewBox 实现响应式，适配不同屏幕
4. **颜色选择**：避免使用红绿色盲难以区分的颜色组合
5. **动画性能**：大数据集（>1000点）时减少动画效果
6. **浏览器兼容**：SVG 动画在所有现代浏览器中均支持
