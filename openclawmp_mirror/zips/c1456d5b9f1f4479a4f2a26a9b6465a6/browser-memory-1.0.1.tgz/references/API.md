# Browser Memory System - API Reference

## Memory Management API

### `memory.sh init`

Initialize the memory system.

**Usage:**
```bash
bash scripts/memory.sh init
```

**Output:**
```
✅ Memory system initialized
```

---

### `memory.sh record`

Record a browser action to memory.

**Usage:**
```bash
bash scripts/memory.sh record <action> <url> [selector] [result]
```

**Parameters:**
- `action`: The action type (open, click, type, fill, etc.)
- `url`: The URL where action occurred
- `selector`: (Optional) The CSS selector used
- `result`: (Optional) Result of action (success/failed)

**Example:**
```bash
bash scripts/memory.sh record click https://github.com "#submit" success
```

---

### `memory.sh recommend`

Get recommended selectors for a URL.

**Usage:**
```bash
bash scripts/memory.sh recommend <url>
```

**Output:**
```
🎯 Recommended selectors for github.com:
  #username - used 12 times (100.0% success)
  #password - used 12 times (100.0% success)
  #submit - used 15 times (93.3% success)
```

---

### `memory.sh patterns`

Show learned patterns and statistics.

**Usage:**
```bash
bash scripts/memory.sh patterns
```

**Output:**
- Learned patterns with usage count
- Most successful selectors
- Domain statistics

---

### `memory.sh stats`

Display memory statistics.

**Usage:**
```bash
bash scripts/memory.sh stats
```

**Output:**
```
============================================================
🧠 Browser Memory Statistics
============================================================
📊 Total Sessions: 42
✅ Successful Actions: 156
❌ Failed Actions: 8
📈 Success Rate: 95.1%
🌐 Domains Visited: 12
🎯 Patterns Learned: 5
🔍 Selectors Known: 23
============================================================
```

---

### `memory.sh learn`

Learn a new workflow pattern.

**Usage:**
```bash
bash scripts/memory.sh learn <pattern_name> "<steps>"
```

**Parameters:**
- `pattern_name`: Name for the pattern
- `steps`: Multi-line string of steps

**Example:**
```bash
bash scripts/memory.sh learn "Login Flow" "
open https://example.com/login
snapshot -i
type #username
type #password
click #submit
"
```

---

### `memory.sh export`

Export memory to cloud storage.

**Usage:**
```bash
bash scripts/memory.sh export
```

**Output:**
```
✅ Memory exported to /workspace/.browser_memory
   - browser_memory.json (machine-readable)
   - memory_summary.md (human-readable)
```

---

### `memory.sh sync`

Sync memory from cloud storage.

**Usage:**
```bash
bash scripts/memory.sh sync
```

**Behavior:**
- Merges cloud and local memory
- Accumulates statistics
- Preserves all data

---

### `memory.sh reset`

Reset all memory data.

**Usage:**
```bash
bash scripts/memory.sh reset
```

**Warning:** This will delete all learned patterns and history.

---

## Memory Data Structure

### browser_memory.json

```json
{
  "version": "2.0.0",
  "created": "ISO8601 timestamp",
  "last_updated": "ISO8601 timestamp",
  "total_sessions": 0,
  "successful_actions": 0,
  "failed_actions": 0,
  "domains": {
    "example.com": {
      "first_visit": "timestamp",
      "visit_count": 0,
      "successful_actions": 0,
      "failed_actions": 0,
      "common_selectors": {}
    }
  },
  "patterns": [],
  "learned_selectors": {},
  "session_history": []
}
```

---

## Integration Points

### Session Start Hook

Automatically syncs memory from cloud:
```json
{
  "type": "command",
  "command": "bash scripts/memory.sh sync"
}
```

### Session End Hook

Automatically exports memory to cloud:
```json
{
  "type": "command",
  "command": "bash scripts/memory.sh export"
}
```

---

## Performance Metrics

- **Record latency**: < 50ms (async)
- **Recommendation speed**: < 10ms
- **Export speed**: < 100ms
- **Sync speed**: < 100ms
- **Storage overhead**: ~1KB per 100 actions

---

## Error Handling

All commands return:
- Exit code 0 on success
- Exit code 1 on error
- Error messages to stderr

---

## Best Practices

1. **Always check recommendations** before interacting
2. **Learn patterns** for repeated workflows
3. **Monitor stats** regularly
4. **Export memory** before important sessions end
5. **Sync memory** at session start

---

**API Version**: 2.0.0  
**Last Updated**: 2025-07-15
