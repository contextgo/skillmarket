---
name: browser-memory
description: 智能浏览器自动化系统，具备云端记忆功能。适用于浏览网站、自动化浏览器任务、填写表单、截图、跨会话记忆等场景。触发短语："打开网页"、"访问网站"、"浏览器自动化"、"记住浏览器操作"、"智能浏览"、"持久化浏览器记忆"。
version: 1.0.0
homepage: https://github.com/vercel-labs/agent-browser
metadata: {"openclaw":{"emoji":"🧠","requires":{"bins":["agent-browser","python3"]},"features":["cloud-memory","smart-recommendations","pattern-learning","cross-session-persistence"]}}
---

# 🧠 智能浏览器自动化与云端记忆系统

> **能够学习和记忆的智能浏览器自动化** - 具备云端记忆、智能选择器推荐和自动工作流学习功能。

---

## 🎯 核心优势

与传统浏览器自动化工具不同，本技能具备**云端记忆系统**：

- ✅ **记忆** - 跨会话记住所有成功的操作
- 🧠 **学习** - 学习最优工作流程和模式
- 🎯 **推荐** - 基于成功率推荐最佳选择器
- ☁️ **持久化** - 记忆保存在云端 (`/workspace/.browser_memory/`)
- 📊 **追踪** - 详细统计成功率和使用数据

---

## 🚀 快速开始

### 基本用法

```bash
# 打开网页并获取内容
agent-browser open https://example.com
agent-browser snapshot
agent-browser close
```

### 使用记忆系统

```bash
# 查看记忆统计
bash ${CODEBUDDY_PLUGIN_ROOT}/scripts/memory.sh stats

# 获取网站智能推荐
bash ${CODEBUDDY_PLUGIN_ROOT}/scripts/memory.sh recommend https://github.com

# 查看学习的工作流
bash ${CODEBUDDY_PLUGIN_ROOT}/scripts/memory.sh patterns
```

---

## 📋 核心命令

### 浏览器操作

| 命令 | 说明 | 示例 |
|------|------|------|
| `open <url>` | 导航到URL | `agent-browser open https://example.com` |
| `snapshot` | 获取页面内容 | `agent-browser snapshot` |
| `snapshot -i` | 获取可交互元素 | `agent-browser snapshot -i` |
| `screenshot` | 截图 | `agent-browser screenshot page.png` |
| `click <selector>` | 点击元素 | `agent-browser click "#submit"` |
| `type <selector> <text>` | 输入文本 | `agent-browser type "#username" "用户"` |
| `fill <selector> <text>` | 清空并填充 | `agent-browser fill "#search" "查询"` |
| `close` | 关闭浏览器 | `agent-browser close` |

### 记忆系统命令

| 命令 | 说明 |
|------|------|
| `memory.sh stats` | 显示记忆统计 |
| `memory.sh recommend <url>` | 获取选择器推荐 |
| `memory.sh patterns` | 显示学习的工作流 |
| `memory.sh export` | 导出记忆到云端 |
| `memory.sh sync` | 从云端同步记忆 |
| `memory.sh learn <name> <steps>` | 学习新模式 |

---

## 💡 使用示例

### 示例 1: 登录与记忆

```bash
# 第一次使用 - 系统学习
agent-browser open https://github.com/login
agent-browser snapshot -i
agent-browser type "#username" "your_username"
agent-browser type "#password" "your_password"
agent-browser click "#submit"

# 下次使用 - 获取推荐
bash scripts/memory.sh recommend https://github.com/login
# 输出:
# 🎯 推荐选择器:
#   #username - 100.0% 成功率 (5次使用)
#   #password - 100.0% 成功率 (5次使用)
#   #submit - 95.0% 成功率 (5次使用)
```

### 示例 2: 学习工作流

```bash
# 教系统一个工作流
bash scripts/memory.sh learn "Twitter 发布" "
open https://twitter.com/compose
wait 2000
click [data-testid='tweetTextarea']
type '你的消息'
click [data-testid='tweetButton']"

# 稍后查看学习的工作流
bash scripts/memory.sh patterns
# 显示: Twitter 发布 - 使用5次，成功率100%
```

### 示例 3: 表单填写

```bash
agent-browser open https://example.com/form
agent-browser snapshot -i

# 获取推荐
bash scripts/memory.sh recommend https://example.com/form

# 使用推荐的选择器填写表单
agent-browser type "#email" "user@example.com"
agent-browser type "#phone" "1234567890"
agent-browser click "#submit"
```

---

## 🧠 记忆系统功能

### 自动学习

每个浏览器操作都会自动记录：
- 操作类型（打开、点击、输入等）
- URL和域名
- 使用的选择器
- 成功/失败结果
- 时间戳

### 智能推荐

系统分析历史数据，推荐：
- **成功率最高的选择器**
- **最常用的选择器**
- **域名级别的优化**

### 模式识别

自动识别并保存：
- **成功的工作流**（多步骤操作）
- **最佳实践**（什么效果好）
- **反模式**（应该避免什么）

### 跨会话持久化

记忆保存在两个位置：
- **本地**: `{PLUGIN_ROOT}/memory/browser_memory.json`
- **云端**: `/workspace/.browser_memory/browser_memory.json`

---

## 📊 记忆统计

### 追踪数据

```json
{
  "total_sessions": 42,
  "successful_actions": 156,
  "failed_actions": 8,
  "success_rate": "95.1%",
  "domains_visited": 12,
  "patterns_learned": 5,
  "selectors_known": 23
}
```

### 域名级别追踪

每个域名：
- 访问次数
- 成功率
- 常用选择器
- 首次/最后访问时间

### 选择器级别追踪

每个选择器：
- 使用次数
- 成功次数
- 成功率
- 使用的域名
- 首次发现时间

---

## 🔄 工作流程

### 推荐使用模式

1. **启动会话**
   ```bash
   # 记忆系统自动同步
   bash scripts/memory.sh stats
   ```

2. **打开目标网站**
   ```bash
   agent-browser open https://target-site.com
   agent-browser snapshot -i
   ```

3. **查看推荐**
   ```bash
   bash scripts/memory.sh recommend https://target-site.com
   ```

4. **执行操作**
   ```bash
   # 使用推荐的选择器
   agent-browser type "#best-selector" "value"
   # 操作自动记录
   ```

5. **结束会话**
   ```bash
   agent-browser close
   # 记忆自动导出到云端
   ```

---

## 🎓 最佳实践

### 1. 先查看推荐

在操作已知网站前：
```bash
bash scripts/memory.sh recommend https://example.com
# 使用成功率最高的选择器
```

### 2. 学习重复工作流

对于经常执行的操作：
```bash
bash scripts/memory.sh learn "每日报告" "
open https://dashboard.com
snapshot -i
click #reports
click #daily
screenshot report.png"
```

### 3. 定期查看成功率

定期检查整体性能：
```bash
bash scripts/memory.sh stats
bash scripts/memory.sh patterns
```

### 4. 使用云端持久化

确保记忆跨会话保持：
```bash
# 导出到云端
bash scripts/memory.sh export

# 从云端同步（会话开始时自动）
bash scripts/memory.sh sync
```

---

## 📁 记忆存储

### 本地文件
```
{PLUGIN_ROOT}/memory/
├── browser_memory.json          # 主记忆文件
└── session_YYYYMMDD_HHMMSS.log  # 会话日志
```

### 云端文件
```
/workspace/.browser_memory/
├── browser_memory.json          # 机器可读格式
└── memory_summary.md            # 人类可读摘要
```

---

## ⚙️ 配置

### 环境变量

- `CODEBUDDY_PLUGIN_ROOT`: 插件根目录
- `AGENT_BROWSER_SESSION`: 浏览器会话名称
- `AGENT_BROWSER_HEADLESS`: 无头模式运行

### 高级选项

```bash
# 使用特定浏览器
agent-browser --executable-path /path/to/browser open https://example.com

# 使用代理
agent-browser --proxy "http://user:pass@proxy.com:8080" open https://example.com

# 持久化会话
agent-browser --session-name mysession open https://example.com

# 自定义视口
agent-browser set viewport 1920 1080
```

---

## 🐛 故障排查

### 记忆未同步

```bash
# 手动同步
bash scripts/memory.sh export
bash scripts/memory.sh sync
```

### 推荐不准确

```bash
# 检查是否有足够数据
bash scripts/memory.sh stats
# 需要更多使用来建立准确推荐
```

### 浏览器未启动

```bash
# 安装浏览器依赖
agent-browser install --with-deps
```

---

## 🔍 监控

### 查看当前记忆

```bash
# 统计信息
bash scripts/memory.sh stats

# 工作流模式
bash scripts/memory.sh patterns

# 原始数据
cat /workspace/.browser_memory/browser_memory.json

# 摘要
cat /workspace/.browser_memory/memory_summary.md
```

---

## 📚 其他资源

- **完整文档**: `/workspace/agent-browser-memory-使用指南.md`
- **技术详情**: `/workspace/README-memory-system.md`
- **部署报告**: `/workspace/agent-browser-记忆系统部署报告.md`

---

## 🆕 版本历史

### v1.0.0（当前版本）
- ✨ 云端记忆系统
- 🧠 智能推荐
- 📊 统计追踪
- 🎯 模式学习
- ☁️ 跨会话持久化

---

## 💬 使用技巧

1. **使用后关闭浏览器** - 释放资源
2. **使用 `snapshot -i`** - 获取带ID的可交互元素
3. **查看推荐** - 在操作已知网站前
4. **学习工作流** - 重复操作保存为模式
5. **导出记忆** - 重要会话结束前

---

## ⚠️ 重要说明

- 记忆**自动同步**于会话开始/结束
- 所有操作**异步记录**（无性能影响）
- 选择器成功率**实时重算**
- 记忆文件为**JSON格式**（人类可读）
- 最多保留**1000条会话历史**

---

## 🎯 何时使用本技能

适合以下场景：
- ✅ 打开和浏览网站
- ✅ 自动化重复浏览器任务
- ✅ 在已知网站填写表单
- ✅ 网页截图
- ✅ 需要跨会话记忆操作
- ✅ 优化选择器使用
- ✅ 学习和应用工作流

---

**创建时间**: 2025-07-15  
**维护者**: CodeBuddy Agent  
**许可**: MIT
