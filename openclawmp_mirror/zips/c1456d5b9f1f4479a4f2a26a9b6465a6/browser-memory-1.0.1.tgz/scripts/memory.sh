#!/bin/bash
# agent-browser 云端记忆系统 v2.0
# 用于保存和恢复浏览器操作记忆，支持跨会话持久化

# 设置默认路径
PLUGIN_ROOT="${CODEBUDDY_PLUGIN_ROOT:-/root/.codebuddy/plugins/marketplaces/codebuddy-plugins-official/plugins/agent-browser}"
MEMORY_DIR="${PLUGIN_ROOT}/memory"
MEMORY_FILE="${MEMORY_DIR}/browser_memory.json"
CLOUD_MEMORY_DIR="/workspace/.browser_memory"
CLOUD_MEMORY_FILE="${CLOUD_MEMORY_DIR}/browser_memory.json"
SESSION_LOG="${MEMORY_DIR}/session_$(date +%Y%m%d_%H%M%S).log"

# 创建记忆目录
mkdir -p "$MEMORY_DIR"
mkdir -p "$CLOUD_MEMORY_DIR"

# 初始化记忆文件
init_memory() {
    if [ ! -f "$MEMORY_FILE" ]; then
        cat > "$MEMORY_FILE" << EOF
{
  "version": "2.0.0",
  "created": "$(date -Iseconds)",
  "last_updated": "$(date -Iseconds)",
  "total_sessions": 0,
  "successful_actions": 0,
  "failed_actions": 0,
  "domains": {},
  "patterns": [],
  "common_workflows": [],
  "learned_selectors": {},
  "error_solutions": {},
  "session_history": []
}
EOF
        echo "✅ Memory system initialized"
    else
        echo "ℹ️  Memory already initialized"
    fi
}

# 记录操作到云端记忆
record_action() {
    local action="$1"
    local url="$2"
    local selector="${3:-None}"
    local result="${4:-unknown}"
    local timestamp=$(date -Iseconds)
    
    # 提取域名
    local domain=$(echo "$url" | grep -oP '(?:https?://)?([^/:]+)' | head -1 || echo "unknown")
    
    # 记录到会话日志
    echo "[$timestamp] $action | $url | $selector | $result" >> "$SESSION_LOG"
    
    # 更新云端记忆文件
    python3 << PYEOF
import json
from datetime import datetime
import sys

memory_file = "$MEMORY_FILE"
action = "$action"
url = "$url"
selector = "$selector" if "$selector" else "None"
result = "$result"
domain = "$domain"
timestamp = "$timestamp"

try:
    with open(memory_file, 'r') as f:
        memory = json.load(f)
    
    # 更新统计
    memory['last_updated'] = timestamp
    memory['total_sessions'] += 1
    if result == 'success':
        memory['successful_actions'] += 1
    elif result == 'failed':
        memory['failed_actions'] += 1
    
    # 更新域名记录
    if domain not in memory['domains']:
        memory['domains'][domain] = {
            'first_visit': timestamp,
            'visit_count': 0,
            'successful_actions': 0,
            'failed_actions': 0,
            'common_selectors': {}
        }
    
    memory['domains'][domain]['visit_count'] += 1
    if result == 'success':
        memory['domains'][domain]['successful_actions'] += 1
    elif result == 'failed':
        memory['domains'][domain]['failed_actions'] += 1
    
    # 记录选择器使用
    if selector and selector != 'None':
        if selector not in memory['domains'][domain]['common_selectors']:
            memory['domains'][domain]['common_selectors'][selector] = 0
        memory['domains'][domain]['common_selectors'][selector] += 1
        
        # 学习选择器
        if selector not in memory['learned_selectors']:
            memory['learned_selectors'][selector] = {
                'first_seen': timestamp,
                'use_count': 0,
                'success_count': 0,
                'success_rate': 0,
                'domains': []
            }
        
        memory['learned_selectors'][selector]['use_count'] += 1
        if result == 'success':
            memory['learned_selectors'][selector]['success_count'] += 1
        if domain not in memory['learned_selectors'][selector]['domains']:
            memory['learned_selectors'][selector]['domains'].append(domain)
        
        # 计算成功率
        total = memory['learned_selectors'][selector]['use_count']
        success = memory['learned_selectors'][selector]['success_count']
        memory['learned_selectors'][selector]['success_rate'] = success / total if total > 0 else 0
    
    # 记录会话历史
    memory['session_history'].append({
        'timestamp': timestamp,
        'action': action,
        'url': url,
        'selector': selector,
        'result': result
    })
    
    # 限制历史记录长度
    if len(memory['session_history']) > 1000:
        memory['session_history'] = memory['session_history'][-1000:]
    
    # 保存更新
    with open(memory_file, 'w') as f:
        json.dump(memory, f, indent=2, ensure_ascii=False)
        
    print(f"✅ Recorded: {action} on {domain}")
    
except Exception as e:
    print(f"❌ Error updating memory: {e}", file=sys.stderr)
    sys.exit(1)
PYEOF
}

# 学习操作模式
learn_pattern() {
    local pattern_name="$1"
    local pattern_steps="$2"
    
    python3 << PYEOF
import json
import sys

memory_file = "$MEMORY_FILE"
pattern_name = "$pattern_name"
pattern_steps = '''$pattern_steps'''

try:
    with open(memory_file, 'r') as f:
        memory = json.load(f)
    
    # 添加或更新模式
    pattern_exists = False
    for pattern in memory['patterns']:
        if pattern['name'] == pattern_name:
            pattern['use_count'] += 1
            pattern['last_used'] = "$(date -Iseconds)"
            pattern_exists = True
            break
    
    if not pattern_exists:
        memory['patterns'].append({
            'name': pattern_name,
            'steps': [s.strip() for s in pattern_steps.split('\n') if s.strip()],
            'use_count': 1,
            'created': "$(date -Iseconds)",
            'last_used': "$(date -Iseconds)"
        })
    
    with open(memory_file, 'w') as f:
        json.dump(memory, f, indent=2, ensure_ascii=False)
    
    print(f"✅ Learned pattern: {pattern_name}")
        
except Exception as e:
    print(f"❌ Error learning pattern: {e}", file=sys.stderr)
    sys.exit(1)
PYEOF
}

# 获取推荐选择器
get_recommended_selectors() {
    local url="$1"
    local domain=$(echo "$url" | grep -oP '(?:https?://)?([^/:]+)' | head -1 || echo "unknown")
    
    python3 << PYEOF
import json
import sys

memory_file = "$MEMORY_FILE"
domain = "$domain"

try:
    with open(memory_file, 'r') as f:
        memory = json.load(f)
    
    if domain in memory['domains']:
        selectors = memory['domains'][domain]['common_selectors']
        # 按使用次数排序
        sorted_selectors = sorted(selectors.items(), key=lambda x: x[1], reverse=True)
        if sorted_selectors:
            print(f"🎯 Recommended selectors for {domain}:")
            for selector, count in sorted_selectors[:5]:
                # 获取成功率
                success_rate = 0
                if selector in memory['learned_selectors']:
                    success_rate = memory['learned_selectors'][selector]['success_rate'] * 100
                print(f"  {selector} - used {count} times ({success_rate:.1f}% success)")
        else:
            print(f"ℹ️  No selectors learned for {domain} yet")
    else:
        print(f"ℹ️  No history found for {domain}")
        
except Exception as e:
    print(f"❌ Error getting recommendations: {e}", file=sys.stderr)
PYEOF
}

# 获取学习到的模式
get_learned_patterns() {
    python3 << PYEOF
import json
import sys

memory_file = "$MEMORY_FILE"

try:
    with open(memory_file, 'r') as f:
        memory = json.load(f)
    
    print("\n" + "="*60)
    print("📚 Learned Patterns")
    print("="*60)
    if memory['patterns']:
        for pattern in memory['patterns']:
            print(f"\n🎯 Pattern: {pattern['name']}")
            print(f"   Used: {pattern['use_count']} times")
            print(f"   Last used: {pattern['last_used']}")
            print("   Steps:")
            for i, step in enumerate(pattern['steps'], 1):
                print(f"     {i}. {step}")
    else:
        print("\nℹ️  No patterns learned yet")
    
    print("\n" + "="*60)
    print("🎯 Most Successful Selectors")
    print("="*60)
    sorted_selectors = sorted(
        memory['learned_selectors'].items(),
        key=lambda x: x[1]['success_rate'],
        reverse=True
    )
    found = False
    for selector, info in sorted_selectors[:10]:
        if info['success_rate'] > 0.7 and info['use_count'] >= 2:
            print(f"\n{selector}")
            print(f"  Success: {info['success_rate']*100:.1f}%")
            print(f"  Used: {info['use_count']} times")
            print(f"  Domains: {', '.join(info['domains'][:3])}")
            found = True
    
    if not found:
        print("\nℹ️  Need more data to show successful selectors")
    
    print("\n" + "="*60)
    print("🌐 Domain Statistics")
    print("="*60)
    for domain, info in sorted(memory['domains'].items(), key=lambda x: x[1]['visit_count'], reverse=True)[:10]:
        total = info['successful_actions'] + info['failed_actions']
        success_rate = info['successful_actions'] / total * 100 if total > 0 else 0
        print(f"\n{domain}")
        print(f"  Visits: {info['visit_count']}")
        print(f"  Success: {success_rate:.1f}%")
        print(f"  Known selectors: {len(info['common_selectors'])}")
    print()
        
except Exception as e:
    print(f"❌ Error getting patterns: {e}", file=sys.stderr)
PYEOF
}

# 导出记忆到云端（工作目录）
export_to_cloud() {
    if [ ! -f "$MEMORY_FILE" ]; then
        echo "❌ No memory file found"
        return 1
    fi
    
    mkdir -p "$CLOUD_MEMORY_DIR"
    
    # 复制记忆文件
    cp "$MEMORY_FILE" "$CLOUD_MEMORY_FILE"
    
    # 创建可读摘要
    python3 << 'PYEOF' > "$CLOUD_MEMORY_DIR/memory_summary.md"
import json
from datetime import datetime

memory_file = "/root/.codebuddy/plugins/marketplaces/codebuddy-plugins-official/plugins/agent-browser/memory/browser_memory.json"

try:
    with open(memory_file, 'r') as f:
        memory = json.load(f)

    print("# 🧠 Browser Automation Memory System\n")
    print(f"**Version**: {memory['version']}")
    print(f"**Last Updated**: {memory['last_updated']}\n")
    
    print(f"## 📊 Statistics\n")
    print(f"- **Total Sessions**: {memory['total_sessions']}")
    print(f"- **Successful Actions**: {memory['successful_actions']}")
    print(f"- **Failed Actions**: {memory['failed_actions']}")
    
    if memory['total_sessions'] > 0:
        success_rate = memory['successful_actions'] / memory['total_sessions'] * 100
        print(f"- **Success Rate**: {success_rate:.1f}%")
    
    print(f"- **Domains Visited**: {len(memory['domains'])}")
    print(f"- **Patterns Learned**: {len(memory['patterns'])}")
    print(f"- **Selectors Known**: {len(memory['learned_selectors'])}\n")

    print(f"## 🌐 Top Domains\n")
    for domain, info in sorted(memory['domains'].items(), key=lambda x: x[1]['visit_count'], reverse=True)[:10]:
        total = info['successful_actions'] + info['failed_actions']
        success_rate = info['successful_actions'] / total * 100 if total > 0 else 0
        print(f"- **{domain}**: {info['visit_count']} visits, {success_rate:.1f}% success")

    print(f"\n## 📚 Learned Patterns\n")
    for pattern in memory['patterns']:
        print(f"### {pattern['name']}")
        print(f"- Used {pattern['use_count']} times")
        print(f"- Steps:")
        for i, step in enumerate(pattern['steps'], 1):
            print(f"  {i}. {step}")
        print()
    
    print(f"## 🎯 Top Selectors\n")
    sorted_selectors = sorted(
        memory['learned_selectors'].items(),
        key=lambda x: x[1]['success_rate'],
        reverse=True
    )[:10]
    
    for selector, info in sorted_selectors:
        print(f"- `{selector}`: {info['success_rate']*100:.1f}% success ({info['use_count']} uses)")
    
except Exception as e:
    print(f"Error generating summary: {e}")
PYEOF
    
    echo "✅ Memory exported to $CLOUD_MEMORY_DIR"
    echo "   - browser_memory.json (machine-readable)"
    echo "   - memory_summary.md (human-readable)"
}

# 同步云端记忆
sync_from_cloud() {
    if [ ! -f "$CLOUD_MEMORY_FILE" ]; then
        echo "ℹ️  No cloud memory found, starting fresh"
        return 0
    fi
    
    # 合并云端和本地记忆
    python3 << PYEOF
import json
import sys

local_file = "$MEMORY_FILE"
cloud_file = "$CLOUD_MEMORY_FILE"

try:
    # 如果本地文件不存在，直接复制云端文件
    try:
        with open(local_file, 'r') as f:
            local = json.load(f)
    except FileNotFoundError:
        with open(cloud_file, 'r') as f:
            local = json.load(f)
        with open(local_file, 'w') as f:
            json.dump(local, f, indent=2, ensure_ascii=False)
        print("✅ Cloud memory synced successfully")
        sys.exit(0)
    
    with open(cloud_file, 'r') as f:
        cloud = json.load(f)
    
    # 合并策略：选择更新的数据
    # 统计数据累加
    local['total_sessions'] += cloud['total_sessions']
    local['successful_actions'] += cloud['successful_actions']
    local['failed_actions'] += cloud['failed_actions']
    
    # 合并域名记录
    for domain, info in cloud['domains'].items():
        if domain not in local['domains']:
            local['domains'][domain] = info
        else:
            local['domains'][domain]['visit_count'] += info['visit_count']
            local['domains'][domain]['successful_actions'] += info['successful_actions']
            local['domains'][domain]['failed_actions'] += info['failed_actions']
            
            # 合并选择器
            for selector, count in info['common_selectors'].items():
                if selector not in local['domains'][domain]['common_selectors']:
                    local['domains'][domain]['common_selectors'][selector] = count
                else:
                    local['domains'][domain]['common_selectors'][selector] += count
    
    # 合并学习的选择器
    for selector, info in cloud['learned_selectors'].items():
        if selector not in local['learned_selectors']:
            local['learned_selectors'][selector] = info
        else:
            local['learned_selectors'][selector]['use_count'] += info['use_count']
            local['learned_selectors'][selector]['success_count'] += info['success_count']
            
            # 重新计算成功率
            total = local['learned_selectors'][selector]['use_count']
            success = local['learned_selectors'][selector]['success_count']
            local['learned_selectors'][selector]['success_rate'] = success / total if total > 0 else 0
            
            # 合并域名
            for domain in info['domains']:
                if domain not in local['learned_selectors'][selector]['domains']:
                    local['learned_selectors'][selector]['domains'].append(domain)
    
    # 合并模式
    existing_patterns = [p['name'] for p in local['patterns']]
    for pattern in cloud['patterns']:
        if pattern['name'] not in existing_patterns:
            local['patterns'].append(pattern)
        else:
            # 更新使用次数
            for p in local['patterns']:
                if p['name'] == pattern['name']:
                    p['use_count'] += pattern['use_count']
                    break
    
    # 更新时间戳
    local['last_updated'] = "$(date -Iseconds)"
    
    with open(local_file, 'w') as f:
        json.dump(local, f, indent=2, ensure_ascii=False)
    
    print("✅ Cloud memory synced successfully")
    print(f"   Total sessions: {local['total_sessions']}")
    print(f"   Domains known: {len(local['domains'])}")
    print(f"   Patterns learned: {len(local['patterns'])}")
    
except Exception as e:
    print(f"❌ Error syncing memory: {e}", file=sys.stderr)
    sys.exit(1)
PYEOF
}

# 显示统计信息
show_stats() {
    if [ ! -f "$MEMORY_FILE" ]; then
        echo "ℹ️  No memory data yet. Start using the browser to build memory."
        return 0
    fi
    
    python3 << PYEOF
import json
import sys

memory_file = "$MEMORY_FILE"

try:
    with open(memory_file, 'r') as f:
        memory = json.load(f)
    
    print("\n" + "="*60)
    print("🧠 Browser Memory Statistics")
    print("="*60)
    print(f"📊 Total Sessions: {memory['total_sessions']}")
    print(f"✅ Successful Actions: {memory['successful_actions']}")
    print(f"❌ Failed Actions: {memory['failed_actions']}")
    
    if memory['total_sessions'] > 0:
        success_rate = memory['successful_actions'] / memory['total_sessions'] * 100
        print(f"📈 Success Rate: {success_rate:.1f}%")
    
    print(f"🌐 Domains Visited: {len(memory['domains'])}")
    print(f"🎯 Patterns Learned: {len(memory['patterns'])}")
    print(f"🔍 Selectors Known: {len(memory['learned_selectors'])}")
    
    if memory['domains']:
        print("\n🏆 Top Domains:")
        for domain, info in sorted(memory['domains'].items(), key=lambda x: x[1]['visit_count'], reverse=True)[:3]:
            print(f"   - {domain}: {info['visit_count']} visits")
    
    print("="*60 + "\n")
    
except Exception as e:
    print(f"❌ Error: {e}", file=sys.stderr)
PYEOF
}

# 重置记忆
reset_memory() {
    echo "⚠️  This will delete all learned patterns and history."
    read -p "Are you sure? (yes/no): " confirm
    
    if [ "$confirm" = "yes" ]; then
        rm -f "$MEMORY_FILE"
        rm -f "$CLOUD_MEMORY_FILE"
        rm -f "${MEMORY_DIR}"/session_*.log
        init_memory
        echo "✅ Memory reset successfully"
    else
        echo "ℹ️  Operation cancelled"
    fi
}

# 主命令分发
case "$1" in
    init)
        init_memory
        ;;
    record)
        init_memory >/dev/null 2>&1
        record_action "$2" "$3" "$4" "$5"
        ;;
    learn)
        learn_pattern "$2" "$3"
        ;;
    recommend)
        get_recommended_selectors "$2"
        ;;
    patterns)
        get_learned_patterns
        ;;
    export)
        export_to_cloud
        ;;
    sync)
        sync_from_cloud
        ;;
    stats)
        show_stats
        ;;
    reset)
        reset_memory
        ;;
    *)
        echo "🧠 agent-browser Cloud Memory System v2.0"
        echo ""
        echo "Usage: $0 {init|record|learn|recommend|patterns|export|sync|stats|reset}"
        echo ""
        echo "Commands:"
        echo "  init                     Initialize memory system"
        echo "  record <action> <url> [selector] [result]"
        echo "                           Record an action (result: success/failed)"
        echo "  learn <name> <steps>     Learn a new pattern (steps separated by newlines)"
        echo "  recommend <url>          Get recommended selectors for URL"
        echo "  patterns                 Show learned patterns and statistics"
        echo "  export                   Export memory to cloud (/workspace)"
        echo "  sync                     Sync memory from cloud"
        echo "  stats                    Show memory statistics"
        echo "  reset                    Reset all memory data"
        echo ""
        echo "Examples:"
        echo "  $0 record open https://example.com None success"
        echo "  $0 record click https://example.com '#submit' success"
        echo "  $0 learn 'Login Flow' 'open url\nfill username\nfill password\nclick submit'"
        echo "  $0 recommend https://example.com"
        echo "  $0 stats"
        ;;
esac
