# Airflow DAG Design Patterns

## Overview
Production-grade Apache Airflow DAG patterns for data orchestration.

## DAG Structure

### Task Dependencies
```python
# Chain pattern
task1 >> task2 >> task3

# Branch pattern
condition = BranchOperator(task_id="check", ...)
[task_a, task_b] >> join_task

# Fan-out/fan-in
start >> [parallel1, parallel2, parallel3] >> end
```

### Dynamic DAG Generation
Use Python functions to generate tasks based on configuration or external data.

## Best Practices

### Idempotent Tasks
Design tasks to be safely re-runnable:
- Check if output exists before processing
- Use atomic operations (write to temp, then move)
- Include dedup logic in data processing

### Error Handling
- retries=3 with exponential backoff
- on_failure_callback for alerting
- SLA notifications via email/Slack
- Dead letter queue for failed records

### Performance
- Use KubernetesPodOperator for resource-intensive tasks
- Map/reduce patterns with dynamic task mapping
- Connection pooling for database tasks
- XCom for small data, S3/GCS for large payloads

### Monitoring
- Task duration alerts (P99 threshold)
- SLA miss notifications
- DAG run health dashboards
- Custom metrics with StatsD/Prometheus

## Anti-Patterns to Avoid
- One giant task (break into smaller steps)
- Hardcoded dates (use execution_date)
- Heavy computation in DAG file (use operators)
- Ignoring data skew in parallel tasks