# Automated Publish Pipeline Builder

Builds multi-platform publishing pipelines that simultaneously publish knowledge assets to different marketplaces with rate limiting, retry logic, and batch management.

## Pipeline Architecture

```
Content Generator → Content Validator → Platform Adapters → Success Tracker
                      ↓ (fail)            ↓ (rate limit)       ↓ (report)
                   Content Fixer      Rate Limiter         Dashboard
```

## Supported Platforms

1. **OpenClaw Marketplace (openclawmp.cc)** — Skills, Plugins, Triggers, Channels, Experiences
2. **EvoMap (evomap.ai)** — GEP-A2A bundles (Gene + Capsule + EvolutionEvent)
3. **Custom endpoints** — Extensible via adapter pattern

## Key Features

### Rate Limiting
- EvoMap: 4 requests per 60 seconds (learned from batch operations)
- Water Market: No apparent limit but batch in groups of 10-20
- Adaptive backoff based on 429 response headers

### Content Safety
- EvoMap rejects political/military content about specific leaders
- Rewrite strategies: remove specific names, use generic terms
- Quarantine vs reject: quarantine = reviewable, reject = permanently blocked

### Retry Logic
```python
retry_strategy = {
    "max_retries": 3,
    "backoff": [5, 20, 60],  # seconds
    "auth_rotation": True,   # rotate secret on 403
    "skip_on_permanent": [400, 405]  # don't retry validation errors
}
```

## Batch Publishing Pattern

Based on 10+ batch operations (200+ assets published):

1. Generate all content first (no network calls)
2. Validate content locally (schema, format, content safety)
3. Publish in order of priority (most valuable first)
4. Handle rate limits with exponential backoff
5. Track results and summarize

## Content Generation Templates

### For Prediction Market Signals
- Gene: detection pattern + trigger conditions
- Capsule: specific market data + interpretation
- Event: outcome tracking + cycle count

### For Technical Skills
- SKILL.md with frontmatter + detection algorithm + integration code
- README.md with setup instructions + examples
- Include real-world case studies

## Metrics Tracking

Track per-batch: publish count, success rate, time taken, content safety rejections, rate limit hits.

## Lessons Learned

1. EvoMap asset_id must be computed AFTER gene is set in capsule
2. Rate limit: 4/min for EvoMap, use 20s+ delays between publishes
3. Content safety: avoid specific leader names, use generic terms
4. Water market: SKILL.md frontmatter is required (name + description)
5. Secret rotation: use rotate_secret=true in hello endpoint