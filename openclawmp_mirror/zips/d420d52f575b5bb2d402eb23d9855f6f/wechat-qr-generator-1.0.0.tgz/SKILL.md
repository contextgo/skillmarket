---
name: wechat-qr-generator
description: 在本地生成微信渠道二维码，无需依赖外部服务，支持自定义尺寸和样式
version: 1.0.0
type: skill
tags: [wechat, qr-code, generator, local, image]
author: 焱垚
---

# 微信二维码本地生成脚本

> 纯本地生成微信二维码，无需调用外部 API，保护隐私且速度快

## 功能特性

- ✅ 纯本地生成，不依赖网络服务
- ✅ 支持自定义二维码尺寸
- ✅ 支持添加微信 logo 水印
- ✅ 输出为 PNG 格式
- ✅ 可自定义容错级别

## 安装依赖

```bash
npm install qrcode sharp
```

## 使用方法

### 基础用法

```javascript
const { generateWeChatQR } = require('./wechat-qr-generator');

// 生成标准微信二维码
await generateWeChatQR({
  text: 'https://weixin.qq.com/r/your-code',
  outputPath: './output.png'
});
```

### 高级用法

```javascript
await generateWeChatQR({
  text: 'https://weixin.qq.com/r/your-code',
  outputPath: './output.png',
  width: 500,           // 二维码尺寸（像素）
  margin: 4,            // 边距
  color: {
    dark: '#000000',    // 二维码颜色
    light: '#FFFFFF'    // 背景颜色
  },
  addLogo: true,        // 是否添加微信 logo
  logoPath: './wechat-logo.png'
});
```

## 完整代码

```javascript
const QRCode = require('qrcode');
const sharp = require('sharp');
const fs = require('fs').promises;
const path = require('path');

/**
 * 生成微信二维码
 * @param {Object} options - 配置选项
 * @param {string} options.text - 二维码内容
 * @param {string} options.outputPath - 输出路径
 * @param {number} options.width - 二维码宽度（默认 300）
 * @param {number} options.margin - 边距（默认 4）
 * @param {Object} options.color - 颜色配置
 * @param {boolean} options.addLogo - 是否添加 logo
 * @param {string} options.logoPath - logo 路径
 */
async function generateWeChatQR(options) {
  const {
    text,
    outputPath,
    width = 300,
    margin = 4,
    color = { dark: '#000000', light: '#FFFFFF' },
    addLogo = true,
    logoPath = null
  } = options;

  // 生成基础二维码
  const qrBuffer = await QRCode.toBuffer(text, {
    width: width,
    margin: margin,
    color: color,
    errorCorrectionLevel: 'H' // 高容错，支持添加 logo
  });

  let finalImage = sharp(qrBuffer);

  // 添加微信 logo
  if (addLogo) {
    const logo = logoPath 
      ? await sharp(logoPath).resize(Math.floor(width * 0.2)).toBuffer()
      : await createDefaultLogo(Math.floor(width * 0.2));
    
    finalImage = finalImage.composite([{
      input: logo,
      gravity: 'center'
    }]);
  }

  // 保存
  await finalImage.png().toFile(outputPath);
  console.log(`✅ 二维码已生成: ${outputPath}`);
  return outputPath;
}

/**
 * 创建默认微信 logo
 */
async function createDefaultLogo(size) {
  // 创建绿色圆形背景
  const svg = `
    <svg width="${size}" height="${size}" xmlns="http://www.w3.org/2000/svg">
      <circle cx="${size/2}" cy="${size/2}" r="${size/2}" fill="#07C160"/>
      <text x="50%" y="50%" font-size="${size*0.5}" fill="white" 
            text-anchor="middle" dominant-baseline="middle">We</text>
    </svg>
  `;
  
  return await sharp(Buffer.from(svg)).png().toBuffer();
}

module.exports = { generateWeChatQR };

// CLI 用法
if (require.main === module) {
  const args = process.argv.slice(2);
  const text = args[0] || 'https://weixin.qq.com';
  const output = args[1] || './wechat-qr.png';
  
  generateWeChatQR({ text, outputPath: output })
    .then(() => process.exit(0))
    .catch(err => {
      console.error('❌ 生成失败:', err);
      process.exit(1);
    });
}
```

## CLI 使用

```bash
# 基础用法
node wechat-qr-generator.js "https://weixin.qq.com/r/xxx" ./output.png

# 使用模块
node -e "require('./wechat-qr-generator').generateWeChatQR({text: 'test', outputPath: './test.png'})"
```

## 参数说明

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| text | string | 必填 | 二维码内容 |
| outputPath | string | 必填 | 输出文件路径 |
| width | number | 300 | 二维码宽度（像素） |
| margin | number | 4 | 边距（模块数） |
| color.dark | string | #000000 | 二维码颜色 |
| color.light | string | #FFFFFF | 背景颜色 |
| addLogo | boolean | true | 是否添加 logo |
| logoPath | string | null | 自定义 logo 路径 |

## 注意事项

1. 需要安装 Node.js ≥ 14
2. 依赖 sharp 库，Windows 可能需要安装构建工具
3. 高容错级别（H）可确保添加 logo 后仍能正常扫描

## 许可证

MIT
