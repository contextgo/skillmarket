#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全能健身教练 - 训练计划生成器
支持多种训练目标：减脂、增肌、体能、康复
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict


@dataclass
class UserProfile:
    """用户档案"""
    gender: str
    age: int
    height_cm: float
    weight_kg: float
    fitness_level: str  # 零基础/初级/中级/高级
    goal: str  # fat_loss/muscle_building/performance/rehab/health
    equipment: str  # 无/哑铃/弹力带/健身房/综合
    days_per_week: int
    minutes_per_session: int
    health_issues: Optional[str] = None
    focus_areas: Optional[List[str]] = None
    avoid_exercises: Optional[List[str]] = None


class ExerciseLibrary:
    """动作库"""

    EXERCISES = {
        "胸部": {
            "无器械": [
                {"name": "标准俯卧撑", "difficulty": 2, "target": "胸大肌/三头", "替代": "跪姿俯卧撑"},
                {"name": "宽距俯卧撑", "difficulty": 2, "target": "胸大肌外侧", "替代": "上斜俯卧撑"},
                {"name": "钻石俯卧撑", "difficulty": 3, "target": "胸肌中缝/三头", "替代": "窄距俯卧撑"},
                {"name": "下斜俯卧撑", "difficulty": 3, "target": "上胸", "替代": "标准俯卧撑"},
            ],
            "哑铃": [
                {"name": "哑铃卧推", "difficulty": 2, "target": "胸大肌", "替代": "地板哑铃卧推"},
                {"name": "哑铃飞鸟", "difficulty": 2, "target": "胸肌外侧", "替代": "地板飞鸟"},
                {"name": "哑铃上斜卧推", "difficulty": 2, "target": "上胸", "替代": "哑铃卧推"},
                {"name": "哑铃上斜飞鸟", "difficulty": 2, "target": "上胸外侧", "替代": "哑铃飞鸟"},
                {"name": "单臂哑铃卧推", "difficulty": 3, "target": "胸大肌/核心", "替代": "哑铃卧推"},
            ],
            "健身房": [
                {"name": "杠铃卧推", "difficulty": 3, "target": "胸大肌", "替代": "史密斯卧推"},
                {"name": "上斜杠铃卧推", "difficulty": 3, "target": "上胸", "替代": "上斜哑铃卧推"},
                {"name": "双杠臂屈伸", "difficulty": 3, "target": "下胸/三头", "替代": "下斜俯卧撑"},
                {"name": "器械夹胸", "difficulty": 1, "target": "胸肌中缝", "替代": "哑铃飞鸟"},
                {"name": "绳索夹胸", "difficulty": 2, "target": "胸肌整体", "替代": "哑铃飞鸟"},
            ]
        },
        "背部": {
            "无器械": [
                {"name": "反向划船", "difficulty": 2, "target": "背阔肌/菱形肌", "替代": "超人式"},
                {"name": "超人式", "difficulty": 1, "target": "竖脊肌/下背", "替代": "鸟狗式"},
                {"name": "Y字上举", "difficulty": 1, "target": "下斜方肌", "替代": "俯卧划船"},
                {"name": "俯卧划船", "difficulty": 2, "target": "背阔肌", "替代": "反向划船"},
            ],
            "哑铃": [
                {"name": "哑铃划船", "difficulty": 2, "target": "背阔肌", "替代": "单臂哑铃划船"},
                {"name": "单臂哑铃划船", "difficulty": 2, "target": "背阔肌", "替代": "哑铃划船"},
                {"name": "哑铃直腿硬拉", "difficulty": 2, "target": "竖脊肌/腘绳肌", "替代": "哑铃罗马尼亚硬拉"},
                {"name": "哑铃耸肩", "difficulty": 1, "target": "斜方肌", "替代": "农夫行走"},
            ],
            "健身房": [
                {"name": "引体向上", "difficulty": 4, "target": "背阔肌/二头", "替代": "辅助引体向上"},
                {"name": "杠铃划船", "difficulty": 3, "target": "背阔肌", "替代": "T杠划船"},
                {"name": "高位下拉", "difficulty": 2, "target": "背阔肌", "替代": "器械下拉"},
                {"name": "坐姿划船", "difficulty": 2, "target": "背阔肌/菱形肌", "替代": "器械划船"},
                {"name": "硬拉", "difficulty": 4, "target": "全身后侧链", "替代": "罗马尼亚硬拉"},
            ]
        },
        "腿部": {
            "无器械": [
                {"name": "深蹲", "difficulty": 2, "target": "股四头肌/臀大肌", "替代": "箱式深蹲"},
                {"name": "弓步蹲", "difficulty": 2, "target": "股四头肌/臀大肌", "替代": "后撤弓步"},
                {"name": "臀桥", "difficulty": 1, "target": "臀大肌", "替代": "单腿臀桥"},
                {"name": "单腿臀桥", "difficulty": 2, "target": "臀大肌", "替代": "臀桥"},
                {"name": "侧抬腿", "difficulty": 1, "target": "臀中肌", "替代": "蚌式开合"},
                {"name": "小腿提踵", "difficulty": 1, "target": "小腿", "替代": "单腿提踵"},
            ],
            "哑铃": [
                {"name": "哑铃深蹲", "difficulty": 2, "target": "股四头肌", "替代": "高脚杯深蹲"},
                {"name": "哑铃罗马尼亚硬拉", "difficulty": 2, "target": "腘绳肌/臀大肌", "替代": "哑铃直腿硬拉"},
                {"name": "哑铃弓步蹲", "difficulty": 2, "target": "股四头肌", "替代": "哑铃后撤弓步"},
                {"name": "哑铃保加利亚分腿蹲", "difficulty": 3, "target": "股四头肌", "替代": "哑铃弓步蹲"},
                {"name": "哑铃单腿硬拉", "difficulty": 3, "target": "腘绳肌/臀大肌", "替代": "哑铃罗马尼亚硬拉"},
            ],
            "健身房": [
                {"name": "杠铃深蹲", "difficulty": 3, "target": "股四头肌", "替代": "史密斯深蹲"},
                {"name": "杠铃硬拉", "difficulty": 4, "target": "全身后侧链", "替代": "罗马尼亚硬拉"},
                {"name": "腿举", "difficulty": 2, "target": "股四头肌", "替代": "器械腿举"},
                {"name": "腿屈伸", "difficulty": 1, "target": "股四头肌", "替代": "哑铃深蹲"},
                {"name": "腿弯举", "difficulty": 1, "target": "腘绳肌", "替代": "哑铃罗马尼亚硬拉"},
                {"name": "髋外展", "difficulty": 1, "target": "臀中肌", "替代": "侧抬腿"},
            ]
        },
        "肩部": {
            "无器械": [
                {"name": "派克俯卧撑", "difficulty": 3, "target": "肩部", "替代": "折刀俯卧撑"},
                {"name": "折刀俯卧撑", "difficulty": 3, "target": "肩部", "替代": "派克俯卧撑"},
                {"name": "倒立撑", "difficulty": 5, "target": "肩部", "替代": "派克俯卧撑"},
            ],
            "哑铃": [
                {"name": "哑铃推举", "difficulty": 2, "target": "三角肌前束/中束", "替代": "阿诺德推举"},
                {"name": "阿诺德推举", "difficulty": 3, "target": "三角肌", "替代": "哑铃推举"},
                {"name": "哑铃侧平举", "difficulty": 2, "target": "三角肌中束", "替代": "绳索侧平举"},
                {"name": "哑铃前平举", "difficulty": 2, "target": "三角肌前束", "替代": "杠铃片前平举"},
                {"name": "俯身哑铃飞鸟", "difficulty": 2, "target": "三角肌后束", "替代": "绳索面拉"},
            ],
            "健身房": [
                {"name": "杠铃推举", "difficulty": 3, "target": "三角肌", "替代": "史密斯推举"},
                {"name": "哑铃推举", "difficulty": 2, "target": "三角肌", "替代": "器械推举"},
                {"name": "绳索面拉", "difficulty": 2, "target": "三角肌后束", "替代": "反向飞鸟"},
                {"name": "器械推举", "difficulty": 1, "target": "三角肌", "替代": "哑铃推举"},
            ]
        },
        "手臂": {
            "无器械": [
                {"name": "窄距俯卧撑", "difficulty": 2, "target": "三头肌", "替代": "钻石俯卧撑"},
                {"name": "钻石俯卧撑", "difficulty": 3, "target": "三头肌", "替代": "窄距俯卧撑"},
                {"name": "反手俯卧撑", "difficulty": 2, "target": "二头肌", "替代": "反手引体"},
                {"name": "凳上臂屈伸", "difficulty": 2, "target": "三头肌", "替代": "窄距俯卧撑"},
            ],
            "哑铃": [
                {"name": "哑铃弯举", "difficulty": 1, "target": "二头肌", "替代": "锤式弯举"},
                {"name": "锤式弯举", "difficulty": 1, "target": "肱肌/二头肌", "替代": "哑铃弯举"},
                {"name": "集中弯举", "difficulty": 2, "target": "二头肌", "替代": "哑铃弯举"},
                {"name": "哑铃颈后臂屈伸", "difficulty": 2, "target": "三头肌", "替代": "俯身臂屈伸"},
                {"name": "哑铃俯身臂屈伸", "difficulty": 2, "target": "三头肌", "替代": "颈后臂屈伸"},
            ],
            "健身房": [
                {"name": "杠铃弯举", "difficulty": 2, "target": "二头肌", "替代": "EZ杠弯举"},
                {"name": "绳索下压", "difficulty": 1, "target": "三头肌", "替代": "直杠下压"},
                {"name": "牧师凳弯举", "difficulty": 2, "target": "二头肌", "替代": "哑铃弯举"},
                {"name": "仰卧臂屈伸", "difficulty": 2, "target": "三头肌", "替代": "绳索下压"},
            ]
        },
        "核心": {
            "无器械": [
                {"name": "平板支撑", "difficulty": 1, "target": "腹横肌", "替代": "跪姿平板支撑"},
                {"name": "死虫式", "difficulty": 1, "target": "腹直肌", "替代": "仰卧抬腿"},
                {"name": "鸟狗式", "difficulty": 1, "target": "核心稳定", "替代": "超人式"},
                {"name": "卷腹", "difficulty": 1, "target": "腹直肌上段", "替代": "仰卧起坐"},
                {"name": "反向卷腹", "difficulty": 2, "target": "腹直肌下段", "替代": "仰卧抬腿"},
                {"name": "俄罗斯转体", "difficulty": 2, "target": "腹斜肌", "替代": "侧平板"},
                {"name": "侧平板", "difficulty": 2, "target": "腹斜肌", "替代": "俄罗斯转体"},
                {"name": "登山跑", "difficulty": 2, "target": "核心/有氧", "替代": "慢速登山"},
                {"name": "V字两头起", "difficulty": 3, "target": "腹直肌", "替代": "卷腹+反向卷腹"},
            ],
            "哑铃": [
                {"name": "哑铃侧屈", "difficulty": 1, "target": "腹斜肌", "替代": "侧平板"},
                {"name": "哑铃俄罗斯转体", "difficulty": 2, "target": "腹斜肌", "替代": "俄罗斯转体"},
            ],
            "健身房": [
                {"name": "绳索卷腹", "difficulty": 2, "target": "腹直肌", "替代": "器械卷腹"},
                {"name": "悬垂举腿", "difficulty": 3, "target": "腹直肌下段", "替代": "仰卧举腿"},
                {"name": "健腹轮", "difficulty": 3, "target": "腹直肌", "替代": "平板支撑"},
            ]
        },
        "有氧": {
            "无器械": [
                {"name": "开合跳", "difficulty": 1, "target": "心肺/全身", "替代": "原地踏步"},
                {"name": "高抬腿", "difficulty": 2, "target": "心肺/下肢", "替代": "原地跑"},
                {"name": "波比跳", "difficulty": 3, "target": "心肺/全身", "替代": "简化波比"},
                {"name": "登山跑", "difficulty": 2, "target": "心肺/核心", "替代": "慢速登山"},
                {"name": "原地跑", "difficulty": 1, "target": "心肺/下肢", "替代": "原地踏步"},
                {"name": "跳绳", "difficulty": 2, "target": "心肺/协调", "替代": "原地跑"},
            ],
            "健身房": [
                {"name": "跑步机", "difficulty": 1, "target": "心肺/下肢", "替代": "椭圆机"},
                {"name": "椭圆机", "difficulty": 1, "target": "心肺/全身", "替代": "跑步机"},
                {"name": "动感单车", "difficulty": 2, "target": "心肺/下肢", "替代": "跑步机"},
                {"name": "划船机", "difficulty": 2, "target": "心肺/全身", "替代": "椭圆机"},
                {"name": "楼梯机", "difficulty": 2, "target": "心肺/下肢", "替代": "跑步机爬坡"},
            ]
        }
    }

    @classmethod
    def get_exercises(cls, muscle_group: str, equipment: str) -> List[Dict]:
        """获取指定肌群和器械的动作列表"""
        group = cls.EXERCISES.get(muscle_group, {})

        # 优先返回指定器械的动作
        exercises = group.get(equipment, [])

        # 如果没有，降级到更简单的器械
        if not exercises and equipment == "健身房":
            exercises = group.get("哑铃", [])
        if not exercises and equipment in ["健身房", "哑铃"]:
            exercises = group.get("无器械", [])

        return exercises

    @classmethod
    def get_all_muscle_groups(cls) -> List[str]:
        """获取所有肌群"""
        return list(cls.EXERCISES.keys())


class WorkoutTemplate:
    """训练模板"""

    TEMPLATES = {
        "全身训练": {
            "description": "适合零基础或时间有限",
            "frequency": "3天/周",
            "duration": "30-45分钟",
            "structure": {
                "热身": 5,
                "主训练": {
                    "下肢": 2,
                    "上肢推": 1,
                    "上肢拉": 1,
                    "核心": 2
                },
                "拉伸": 5
            }
        },
        "上下肢分化": {
            "description": "适合初级增肌",
            "frequency": "4天/周",
            "duration": "60分钟",
            "A日_上肢": {
                "胸部": 2,
                "背部": 2,
                "肩部": 1,
                "手臂": 2
            },
            "B日_下肢": {
                "股四头肌": 2,
                "腘绳肌": 2,
                "臀部": 1,
                "小腿": 1,
                "核心": 2
            }
        },
        "推拉腿PPL": {
            "description": "适合中级增肌",
            "frequency": "6天/周",
            "duration": "60-75分钟",
            "推日": ["胸部", "肩部", "三头肌"],
            "拉日": ["背部", "二头肌", "后肩"],
            "腿日": ["股四头肌", "腘绳肌", "臀部", "小腿"]
        },
        "五分化": {
            "description": "适合高级健美",
            "frequency": "5天/周",
            "duration": "75-90分钟",
            "周一": "胸部",
            "周二": "背部",
            "周三": "肩部",
            "周四": "手臂",
            "周五": "腿部"
        },
        "减脂HIIT": {
            "description": "高效燃脂",
            "frequency": "4-5天/周",
            "duration": "30分钟",
            "structure": {
                "热身": 5,
                "HIIT": 20,
                "拉伸": 5
            }
        },
        "康复训练": {
            "description": "改善体态，缓解疼痛",
            "frequency": "每天",
            "duration": "20-30分钟",
            "focus": ["核心稳定", "臀肌激活", "上背强化", "拉伸放松"]
        }
    }


class WorkoutPlanGenerator:
    """训练计划生成器"""

    def __init__(self, user: UserProfile):
        self.user = user
        self.exercise_lib = ExerciseLibrary()
        self.template_lib = WorkoutTemplate()

    def generate_plan(self) -> Dict:
        """生成完整训练计划"""
        # 根据目标选择模板
        template = self._select_template()

        # 生成4周计划
        plan = {
            "user_profile": asdict(self.user),
            "template": template,
            "weeks": []
        }

        for week in range(1, 5):
            week_plan = self._generate_week(week, template)
            plan["weeks"].append(week_plan)

        return plan

    def _select_template(self) -> str:
        """根据目标选择模板"""
        goal_map = {
            "fat_loss": "减脂HIIT" if self.user.fitness_level in ["零基础", "初级"] else "全身训练",
            "muscle_building": {
                "零基础": "全身训练",
                "初级": "上下肢分化",
                "中级": "推拉腿PPL",
                "高级": "五分化"
            }.get(self.user.fitness_level, "上下肢分化"),
            "performance": "全身训练",
            "rehab": "康复训练",
            "health": "全身训练"
        }
        return goal_map.get(self.user.goal, "全身训练")

    def _generate_week(self, week: int, template: str) -> Dict:
        """生成单周计划"""
        intensity = 0.7 + (week * 0.1)  # 70%, 80%, 90%, 100%

        if template == "全身训练":
            return self._generate_full_body_week(week, intensity)
        elif template == "上下肢分化":
            return self._generate_upper_lower_week(week, intensity)
        elif template == "推拉腿PPL":
            return self._generate_ppl_week(week, intensity)
        elif template == "减脂HIIT":
            return self._generate_hiit_week(week, intensity)
        else:
            return self._generate_full_body_week(week, intensity)

    def _generate_full_body_week(self, week: int, intensity: float) -> Dict:
        """生成全身训练周计划"""
        sessions = []

        for day in range(1, self.user.days_per_week + 1):
            session = {
                "day": day,
                "name": f"第{day}次训练 - 全身",
                "duration": self.user.minutes_per_session,
                "warmup": self._generate_warmup(),
                "exercises": self._generate_full_body_exercises(week),
                "cooldown": self._generate_cooldown()
            }
            sessions.append(session)

        return {"week": week, "sessions": sessions}

    def _generate_full_body_exercises(self, week: int) -> List[Dict]:
        """生成全身训练动作"""
        exercises = []
        equipment = self.user.equipment

        # 下肢
        leg_exercises = self.exercise_lib.get_exercises("腿部", equipment)
        if leg_exercises:
            ex = leg_exercises[0]
            exercises.append({
                "name": ex["name"],
                "sets": 3,
                "reps": f"{8 + week}-{12 + week}次",
                "rest": "60秒",
                "target": ex["target"],
                "alternative": ex.get("替代", "")
            })

        # 上肢推
        chest_exercises = self.exercise_lib.get_exercises("胸部", equipment)
        if chest_exercises:
            ex = chest_exercises[0]
            exercises.append({
                "name": ex["name"],
                "sets": 3,
                "reps": f"{8 + week}-{12 + week}次",
                "rest": "60秒",
                "target": ex["target"],
                "alternative": ex.get("替代", "")
            })

        # 上肢拉
        back_exercises = self.exercise_lib.get_exercises("背部", equipment)
        if back_exercises:
            ex = back_exercises[0]
            exercises.append({
                "name": ex["name"],
                "sets": 3,
                "reps": f"{8 + week}-{12 + week}次",
                "rest": "60秒",
                "target": ex["target"],
                "alternative": ex.get("替代", "")
            })

        # 核心
        core_exercises = self.exercise_lib.get_exercises("核心", "无器械")
        if core_exercises:
            for i in range(min(2, len(core_exercises))):
                ex = core_exercises[i]
                exercises.append({
                    "name": ex["name"],
                    "sets": 3,
                    "reps": "30-45秒" if "支撑" in ex["name"] else f"{10 + week}-{15 + week}次",
                    "rest": "45秒",
                    "target": ex["target"],
                    "alternative": ex.get("替代", "")
                })

        return exercises

    def _generate_warmup(self) -> List[Dict]:
        """生成热身"""
        return [
            {"name": "关节活动", "duration": "2分钟", "description": "颈部、肩部、髋部、膝关节活动"},
            {"name": "动态拉伸", "duration": "3分钟", "description": "手臂画圈、腿部摆动、躯干旋转"},
            {"name": "动作预热", "duration": "2分钟", "description": "用轻重量或无重量做即将训练的动作"}
        ]

    def _generate_cooldown(self) -> List[Dict]:
        """生成放松"""
        return [
            {"name": "慢走", "duration": "2分钟", "description": "逐渐降低心率"},
            {"name": "静态拉伸", "duration": "5分钟", "description": "重点拉伸训练部位"},
            {"name": "深呼吸", "duration": "1分钟", "description": "放松身心"}
        ]

    def _generate_upper_lower_week(self, week: int, intensity: float) -> Dict:
        """生成上下肢分化周计划"""
        # 简化为全身训练（可根据需要扩展）
        return self._generate_full_body_week(week, intensity)

    def _generate_ppl_week(self, week: int, intensity: float) -> Dict:
        """生成PPL周计划"""
        # 简化为全身训练（可根据需要扩展）
        return self._generate_full_body_week(week, intensity)

    def _generate_hiit_week(self, week: int, intensity: float) -> Dict:
        """生成HIIT周计划"""
        sessions = []

        for day in range(1, self.user.days_per_week + 1):
            session = {
                "day": day,
                "name": f"第{day}次训练 - HIIT",
                "duration": self.user.minutes_per_session,
                "warmup": self._generate_warmup(),
                "exercises": self._generate_hiit_exercises(week),
                "cooldown": self._generate_cooldown()
            }
            sessions.append(session)

        return {"week": week, "sessions": sessions}

    def _generate_hiit_exercises(self, week: int) -> List[Dict]:
        """生成HIIT动作"""
        exercises = []
        cardio_exercises = self.exercise_lib.get_exercises("有氧", self.user.equipment)

        # 选择4-6个动作做循环
        selected = cardio_exercises[:min(6, len(cardio_exercises))]

        for ex in selected:
            exercises.append({
                "name": ex["name"],
                "work": "30秒",
                "rest": "15秒",
                "rounds": 4 + week,
                "target": ex["target"]
            })

        return exercises

    def export_to_markdown(self, plan: Dict) -> str:
        """导出为Markdown格式"""
        user = self.user

        md = f"""# 🏋️ 个人专属训练计划

**生成日期**: {datetime.now().strftime('%Y年%m月%d日')}
**训练周期**: 4周

---

## 📋 个人档案

| 项目 | 内容 |
|------|------|
| 性别 | {user.gender} |
| 年龄 | {user.age}岁 |
| 身高 | {user.height_cm}cm |
| 体重 | {user.weight_kg}kg |
| 训练目标 | {user.goal} |
| 运动水平 | {user.fitness_level} |
| 可用器械 | {user.equipment} |
| 训练频率 | 每周{user.days_per_week}天 |
| 每次时长 | {user.minutes_per_session}分钟 |

---

## 🎯 训练方案概览

**方案类型**: {plan['template']}
**方案说明**: {self.template_lib.TEMPLATES.get(plan['template'], {}).get('description', '个性化训练')}

### 训练原则
- 每周{user.days_per_week}次训练，每次{user.minutes_per_session}分钟
- 4周渐进式设计，强度逐周递增
- 循序渐进，第4周为巩固期
- 注重动作质量，不盲目追求重量

---

## 📅 4周详细计划

"""

        for week in plan["weeks"]:
            md += f"\n### 第{week['week']}周\n\n"

            for session in week["sessions"]:
                md += f"**第{session['day']}次训练** - {session['name']}\n\n"

                # 热身
                md += "**热身** (5分钟)\n"
                for item in session["warmup"]:
                    md += f"- {item['name']}: {item['duration']} - {item['description']}\n"

                # 主训练
                md += "\n**主训练**\n"
                for i, ex in enumerate(session["exercises"], 1):
                    if "work" in ex:  # HIIT格式
                        md += f"{i}. {ex['name']}: {ex['work']}运动 / {ex['rest']}休息 × {ex['rounds']}轮\n"
                    else:  # 力量训练格式
                        md += f"{i}. {ex['name']}: {ex['sets']}组 × {ex['reps']}, 休息{ex['rest']}\n"
                        md += f"   - 目标肌群: {ex['target']}\n"
                        if ex.get('alternative'):
                            md += f"   - 替代动作: {ex['alternative']}\n"

                # 放松
                md += "\n**放松** (5分钟)\n"
                for item in session["cooldown"]:
                    md += f"- {item['name']}: {item['duration']} - {item['description']}\n"

                md += "\n---\n\n"

        # 添加进阶指导
        md += """
## 📈 进阶指导

### 渐进超负荷原则
每周选择以下一种方式增加难度：
1. **增加重量**: 能标准完成目标次数后，增加2.5-5kg
2. **增加次数**: 从8次增加到10次，再到12次
3. **增加组数**: 从3组增加到4组
4. **缩短休息**: 从90秒缩短到60秒

### 第4周后
- 如果感觉轻松：进入下一阶段的计划（增加天数或时长）
- 如果感觉适中：重复第3-4周的内容
- 如果感觉困难：重复第2周的内容，巩固基础

---

## ⚠️ 安全提醒

### 训练前检查
- [ ] 睡眠充足（7-8小时）
- [ ] 2小时内进食过
- [ ] 补充水分
- [ ] 无急性疼痛

### 动作原则
- 从轻开始，先掌握动作模式
- 全程控制，不要借助惯性
- 发力呼气，放松吸气
- 感到刺痛立即停止

### 过度训练信号
- 持续疲劳，休息后无法恢复
- 运动表现下降
- 睡眠质量差
- 静息心率升高

---

## 📝 训练记录表

| 日期 | 周次 | 训练内容 | 完成情况 | 感受 | 备注 |
|------|------|---------|---------|------|------|
| | 第1周 | | | | |
| | 第1周 | | | | |
| | 第2周 | | | | |
| | 第2周 | | | | |
| | 第3周 | | | | |
| | 第3周 | | | | |
| | 第4周 | | | | |
| | 第4周 | | | | |

---

*祝你训练顺利，达成目标！* 💪
"""

        return md


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='生成个性化训练计划')
    parser.add_argument('--goal', required=True,
                       choices=['fat_loss', 'muscle_building', 'performance', 'rehab', 'health'],
                       help='训练目标')
    parser.add_argument('--gender', required=True, choices=['男', '女'], help='性别')
    parser.add_argument('--age', type=int, required=True, help='年龄')
    parser.add_argument('--height', type=float, required=True, help='身高(cm)')
    parser.add_argument('--weight', type=float, required=True, help='体重(kg)')
    parser.add_argument('--level', default='零基础',
                       choices=['零基础', '初级', '中级', '高级'],
                       help='运动水平')
    parser.add_argument('--equipment', default='无',
                       help='可用器械')
    parser.add_argument('--days', type=int, default=3, help='每周训练天数')
    parser.add_argument('--minutes', type=int, default=45, help='每次训练分钟数')
    parser.add_argument('--output', required=True, help='输出文件路径')

    args = parser.parse_args()

    # 创建用户档案
    user = UserProfile(
        gender=args.gender,
        age=args.age,
        height_cm=args.height,
        weight_kg=args.weight,
        fitness_level=args.level,
        goal=args.goal,
        equipment=args.equipment,
        days_per_week=args.days,
        minutes_per_session=args.minutes
    )

    # 生成计划
    generator = WorkoutPlanGenerator(user)
    plan = generator.generate_plan()

    # 导出为Markdown
    markdown = generator.export_to_markdown(plan)

    # 保存文件
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(markdown)

    print(f"[OK] 训练计划已生成: {output_path}")
    print(f"[INFO] 方案类型: {plan['template']}")
    print(f"[INFO] 训练频率: 每周{args.days}天，每次{args.minutes}分钟")


if __name__ == "__main__":
    main()
