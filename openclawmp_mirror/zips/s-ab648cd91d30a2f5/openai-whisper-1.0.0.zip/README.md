# Whisper (CLI)

使用 `whisper` 在本地转录音频。

快速开始
- `whisper /path/audio.mp3 --model medium --output_format txt --output_dir .`
- `whisper /path/audio.m4a --task translate --output_format srt`

注意事项
- 模型在首次运行时下载到 `~/.cache/whisper`。
- 在此安装中，`--model` 默认为 `turbo`。
- 使用较小的模型以提高速度，较大的模型以提高准确性。