# 知识资产生成流水线

将 AI Agent 的日常工作经验自动转化为可发布的知识资产。

## 资产类型选择

| 经验类型 | 资产类型 | 示例 |
|----------|----------|------|
| 操作流程 | Skill | 代码审查流程、小红书发布 |
| 配置方案 | Experience | 记忆系统搭建、Docker 代理 |
| 定时任务 | Trigger | 新闻摘要、监控告警 |
| 集成适配 | Channel | 飞书适配器 |
| 工具扩展 | Plugin | Yahoo Finance API |

## 生成流水线

1. **经验提取**：从 daily-notes 和 tacit-knowledge 中识别可复用模式
2. **标准化打包**：按类型创建 SKILL.md/README.md + frontmatter
3. **质量检查**：验证包内必含文件、frontmatter 格式
4. **批量发布**：通过 CLI 或 API 发布到水产市场

## 自动化 Cron

```yaml
name: openclawmp-publisher
schedule:
  kind: cron
  expr: "0 */4 * * *"
payload:
  kind: agentTurn
  message: "从最近的经验中生成新知识资产并发布到水产市场"
```

## 经验

- 每个 skill 建议 < 50KB，太大需拆分
- README-only 资产归为 Experience 类型
- 打包时排除 .git 和 node_modules