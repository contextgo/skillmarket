# Feishu Bitable Library v2 - 使用用户Token (从加密存储读取)
# 支持从 OpenClaw 的加密 UAT 文件读取用户 access_token

$script:FeishuConfig = $null
$script:UserTokenCache = @{token=$null; expire_at=0}

# 获取 OpenClaw 加密存储的用户 token
function Get-OpenClawUserToken {
    # 优先使用配置中的 user_access_token（如果有）
    if ($script:FeishuConfig.user_access_token) {
        return $script:FeishuConfig.user_access_token
    }
    
    # 从缓存读取（避免频繁解密）
    $nowMs = [DateTime]::UtcNow.Ticks
    if ($script:UserTokenCache.token -and $script:UserTokenCache.expire_at -gt $nowMs) {
        return $script:UserTokenCache.token
    }
    
    # 通过 Node.js 解密 OpenClaw 的 UAT 文件
    $decryptScript = @"
const {readFileSync, existsSync} = require('fs');
const {createDecipheriv} = require('crypto');
const path = require('path');
const os = require('os');

const localAppData = process.env.LOCALAPPDATA || path.join(os.homedir(),'AppData','Local');
const uatDir = path.join(localAppData, 'openclaw-feishu-uat');
const encFile = path.join(uatDir, 'cli_a92cf9e289f65cd5_ou_554abae9e0c9aa8c225793e33fe181c3.enc');
const mkFile = path.join(uatDir, 'master.key');

if (!existsSync(encFile) || !existsSync(mkFile)) {
    process.exit(1);
}

try {
    const masterKey = readFileSync(mkFile);
    const enc = readFileSync(encFile);
    const iv = enc.subarray(0, 12);
    const tag = enc.subarray(12, 28);
    const ciphertext = enc.subarray(28);
    const decipher = createDecipheriv('aes-256-gcm', masterKey, iv);
    decipher.setAuthTag(tag);
    const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()]);
    const td = JSON.parse(decrypted.toString('utf8'));
    
    // 输出 token 和过期时间（毫秒时间戳）
    console.log(JSON.stringify({
        token: td.accessToken || td.access_token,
        expireAt: td.expiresAt || td.expire_at || 0
    }));
} catch(e) {
    process.exit(1);
}
"@
    
    $tempScript = "$env:TEMP\decrypt_uat_$PID.ps1"
    $decryptScript | Out-File -FilePath $tempScript -Encoding UTF8
    
    # 通过 pwsh 调用 node 来解密
    $nodeScript = "$env:TEMP\decrypt_uat_node_$PID.js"
    $decryptScript | Out-File -FilePath $nodeScript -Encoding UTF8 -Width 200
    
    try {
        $output = & node $nodeScript 2>$null
        Remove-Item $nodeScript -ErrorAction SilentlyContinue
        
        if ($output) {
            $data = $output | ConvertFrom-Json
            $token = $data.token
            $expireAt = $data.expireAt
            
            if ($token -and $token.Length -gt 10) {
                # 缓存 token，过期前 5 分钟刷新
                $bufferMs = 5 * 60 * 1000
                $script:UserTokenCache.token = $token
                $script:UserTokenCache.expire_at = ($expireAt - $bufferMs) * 10000  # ms -> ticks
                return $token
            }
        }
    } catch {
        # 解密失败，忽略
    }
    
    Remove-Item $nodeScript -ErrorAction SilentlyContinue
    return $null
}

function Initialize-FeishuBitable {
    param([string]$ConfigPath)
    $configJson = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
    $config = $configJson | ConvertFrom-Json
    $script:FeishuConfig = $config.feishu
    if (-not $script:FeishuConfig.enabled) { return $false }
    if (-not $script:FeishuConfig.bitable_app_token) {
        Write-Warning "Missing bitable_app_token in config"
        return $false
    }
    
    # 测试 token 是否可用
    $token = Get-OpenClawUserToken
    if (-not $token) {
        Write-Warning "Could not get user token from OpenClaw encrypted storage"
        return $false
    }
    
    return $true
}

function Invoke-FeishuApi {
    param(
        [string]$Method = "GET",
        [string]$ApiPath,
        [object]$Body = $null,
        [string]$Token = $null
    )
    
    if (-not $Token) { $Token = Get-OpenClawUserToken }
    if (-not $Token) { return @{success=$false; code=-1; msg="No token"} }
    
    $baseUrl = "https://open.feishu.cn/open-apis"
    $url = $baseUrl + $ApiPath
    $headers = @{
        "Authorization" = "Bearer $Token"
        "Content-Type" = "application/json; charset=utf-8"
    }
    
    try {
        if ($Body) {
            $bodyJson = $Body | ConvertTo-Json -Compress -Depth 10
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($bodyJson)
            $resp = Invoke-WebRequest -Uri $url -Method $Method -Headers $headers -Body $bytes -TimeoutSec 20 -ContentType "application/json; charset=utf-8"
        } else {
            $resp = Invoke-WebRequest -Uri $url -Method $Method -Headers $headers -TimeoutSec 20
        }
        
        $content = $resp.Content | ConvertFrom-Json
        return @{
            success = ($content.code -eq 0)
            code = $content.code
            msg = $content.msg
            data = $content.data
        }
    } catch {
        $ex = $_.Exception
        if ($ex.Response) {
            $status = [int]$ex.Response.StatusCode
            $reader = [System.IO.StreamReader]::new($ex.Response.GetResponseStream())
            $bodyText = $reader.ReadToEnd()
            $reader.Close()
            try { $j = $bodyText | ConvertFrom-Json; $code = $j.code; $msg = $j.msg } catch { $code = $status; $msg = $bodyText }
            return @{success=$false; code=$code; msg=$msg}
        }
        return @{success=$false; code=-1; msg=$ex.Message}
    }
}

function New-FeishuRecord {
    param([string]$TableId, [hashtable]$Fields)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "POST" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records" -Body @{fields=$Fields}
    
    if (-not $result.success) {
        Write-Warning "Create record failed: $($result.msg) (code $($result.code))"
        return $null
    }
    return $result.data.record
}

function Get-FeishuRecords {
    param([string]$TableId, [string]$ViewId = "", [int]$PageSize = 50, [string]$PageToken = "")
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $path = "/bitable/v1/apps/$appToken/tables/$TableId/records/search"
    
    $q = @{page_size=$PageSize; fields=@()}
    if ($ViewId) { $q.view_id = $ViewId }
    if ($PageToken) { $q.page_token = $PageToken }
    
    $result = Invoke-FeishuApi -Method "POST" -ApiPath $path -Body $q
    
    if (-not $result.success) {
        Write-Warning "Get records failed: $($result.msg)"
        return $null
    }
    return $result.data
}

function Update-FeishuRecord {
    param([string]$TableId, [string]$RecordId, [hashtable]$Fields)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "PUT" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records/$RecordId" -Body @{fields=$Fields}
    
    if (-not $result.success) {
        Write-Warning "Update record failed: $($result.msg)"
        return $null
    }
    return $result.data.record
}

function Delete-FeishuRecord {
    param([string]$TableId, [string]$RecordId)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "DELETE" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records/$RecordId"
    
    if (-not $result.success) {
        Write-Warning "Delete record failed: $($result.msg)"
        return $false
    }
    return $true
}
