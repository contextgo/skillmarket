---
name: trackup-food-analyze
version: 1.0.6
description: 根据食物图片分析食物营养成分，默认通过 AnalyzeWholeFood 执行完整分析，也支持宏量营养、配料、健康洞察和基于关键词的食物搜索。
---

# 食物营养智能分析

使用这个 skill 可以根据食物图片分析营养成分，也支持食物搜索和专项营养数据分析：

- `https://deepeat.ai/step.aispark.api.API/AnalyzeWholeFood`
- `https://deepeat.ai/step.aispark.api.API/ExtractFoodMacros`
- `https://deepeat.ai/step.aispark.api.API/AnalyzeIngredients`
- `https://deepeat.ai/step.aispark.api.API/GetHealthInsight`
- `https://deepeat.ai/step.aispark.api.API/SearchFood`

## 规则

- 始终使用 `POST`
- 始终发送 `Content-Type: application/json`
- 图片分析请求必须包含 `image_url` 或 `image_base64`
- 如果两者同时存在，优先使用 `image_base64`
- `image_base64` 必须是原始 base64 字符串，不能包含 `data:image/...;base64,`
- 需要完整分析食物图片时，直接调用 `AnalyzeWholeFood`
- 只有当用户明确要求某一个分析维度时，才调用对应的专项图片分析接口
- `ExtractFoodMacros` 用于基础宏量营养提取
- `AnalyzeIngredients` 用于深入的配料与代谢分析
- `GetHealthInsight` 用于专业健康洞察
- `SearchFood` 的请求体必须包含 `keyword`
- `SearchFood` 最多返回前 `20` 条结果

## API 选择

根据用户意图选择对应接口：

1. 完整食物分析：`AnalyzeWholeFood`
2. 仅提取基础宏量营养：`ExtractFoodMacros`
3. 仅做深入配料与代谢分析：`AnalyzeIngredients`
4. 仅获取专业健康洞察：`GetHealthInsight`
5. 不做图片分析、只按关键词查询：`SearchFood`

## 食物搜索

当用户想按关键词查询食物，而不是分析图片时，使用 `SearchFood`。

请求示例：

```bash
curl --silent --show-error --location \
  'https://deepeat.ai/step.aispark.api.API/SearchFood' \
  --header 'Content-Type: application/json' \
  --data '{
    "keyword": "banana"
  }'
```

返回结构示例：

```json
{
  "foods": [
    {
      "food_name": "Banana",
      "calories_cal": "89000",
      "weight_g": "100",
      "carbs_g": "22.8",
      "proteins_g": "1.1",
      "fats_g": "0.3",
      "display_gi": 51,
      "brand": ""
    }
  ],
  "pagination": {
    "size": 20,
    "page": 1,
    "total": 123
  }
}
```

## 图片来源解析顺序

当用户发送或提到食物图片时，按以下顺序解析图片来源：

1. **本地文件路径**：用户明确提供了路径，或某个已知文件存在于本地（例如 `Downloads`）
2. **自动读取剪贴板**：当用户在网页聊天等不会把图片保存到本地的通道里直接粘贴或拖入图片时，**立即**尝试从系统剪贴板读取。用户刚完成粘贴，图片大概率仍在剪贴板里。不要先询问用户，先静默尝试读取。
3. **图片 URL**：如果用户提供了 URL，则直接使用 `image_url` 参数

**关键行为：** 当消息中出现内联图片但没有本地文件路径时，**始终优先自动尝试读取剪贴板**。只有在读取失败后，才回退为询问用户。

### macOS 剪贴板图片读取

当收到内联图片但没有本地文件路径时，使用以下方式读取：

```bash
cat > /tmp/clipboard_image.swift << 'SWIFT'
import Cocoa
let pb = NSPasteboard.general
let outputPath = "/tmp/clipboard_image.png"

if let imgData = pb.data(forType: .png) {
    try! imgData.write(to: URL(fileURLWithPath: outputPath))
    print("OK: saved \(imgData.count) bytes")
} else if let tiffData = pb.data(forType: .tiff) {
    if let img = NSBitmapImageRep(data: tiffData),
       let pngData = img.representation(using: .png, properties: [:]) {
        try! pngData.write(to: URL(fileURLWithPath: outputPath))
        print("OK: saved \(pngData.count) bytes (from TIFF)")
    } else {
        print("ERR: could not convert TIFF to PNG")
    }
} else {
    let types = pb.types?.map { $0.rawValue } ?? []
    print("ERR: no image in clipboard. Types: \(types)")
}
SWIFT
swift /tmp/clipboard_image.swift
```

如果成功，图片会保存到 `/tmp/clipboard_image.png`。之后使用这个路径继续执行下方的本地图片工作流。

如果剪贴板中没有图片（输出为 `ERR`），就提示用户先重新复制或截图图片，或者直接提供文件路径。

## 本地图片工作流

先把本地图片转成 base64：

```bash
base64 < /absolute/path/to/image.jpg | tr -d '\n' > /tmp/food_image.b64
```

再构造请求体：

```bash
printf '{"image_base64":"' > /tmp/food_image.json
cat /tmp/food_image.b64 >> /tmp/food_image.json
printf '"}' >> /tmp/food_image.json
```

然后直接调用完整食物分析接口：

```bash
curl --silent --show-error --location \
  'https://deepeat.ai/step.aispark.api.API/AnalyzeWholeFood' \
  --header 'Content-Type: application/json' \
  --data-binary @/tmp/food_image.json
```

## 代理问题处理

如果 `curl` 错误地走了本地代理，例如 `127.0.0.1:7890`，可改用以下方式重试：

```bash
env -u http_proxy -u https_proxy -u HTTP_PROXY -u HTTPS_PROXY -u ALL_PROXY curl ...
```

## 响应字段

`AnalyzeWholeFood`:

- `food_name`
- `total_weight_g`
- `total_calories_kcal`
- `carbs_g`
- `proteins_g`
- `fats_g`
- `display_gi`
- `dietary_fiber_g`
- `sugar_g`
- `ingredients[]`
- `health_score`
- `health_profile`

`ExtractFoodMacros`:

- `food_name`
- `total_weight_g`
- `total_calories_kcal`
- `carbs_g`
- `proteins_g`
- `fats_g`

`AnalyzeIngredients`:

- `display_gi`
- `dietary_fiber_g`
- `sugar_g`
- `ingredients[]`

`GetHealthInsight`:

- `health_score`
- `health_profile`

`SearchFood`:

- `foods[]`
- `pagination.page`
- `pagination.size`
- `pagination.total`

`health_score` 含义：

- `1-5`，由 AI 食物评估生成的分数
- `5` 为最高分
- 可用于帮助用户做出更有营养依据的选择

## 输出规则

- 数值字段必须与 API 返回保持一致
- 不要补造缺失字段
- 完整图片分析默认使用 `AnalyzeWholeFood`
- 专项分析只调用与用户请求相匹配的专用接口
- 对于 `SearchFood`，按 API 返回顺序输出食物结果；除非响应里确实更多，否则不要声称超过 `20` 条

## 常见错误

- `400 invalid_request`
- `422 food_not_recognized`
- `422 barcode_only_result`
- `429 rate_limit_exceeded`
- `500 internal_error`
- `502 upstream_flow_error`
