# 食物营养智能分析

通过食物图片分析食物营养成分，支持食物搜索和专项营养数据分析。

## 功能

- 使用 `AnalyzeWholeFood` 进行完整食物分析
- 使用 `ExtractFoodMacros` 进行专项宏量营养提取
- 使用 `AnalyzeIngredients` 进行专项配料与代谢分析
- 使用 `GetHealthInsight` 获取专业健康洞察
- 支持基于关键词的食物搜索

## 前提条件

- 确保可以访问 `https://deepeat.ai`

## 用法

### 完整食物分析

提供图片 URL 或 base64 数据。需要完整分析时，调用：

1. `AnalyzeWholeFood`

这是默认的图片分析接口。它会返回合并结果，包括宏量营养、配料、GI、膳食纤维、糖分、健康评分和健康画像。

### 专项图片分析

如果用户只想看某一个维度，直接调用对应接口：

1. 基础宏量营养提取：`ExtractFoodMacros`
2. 深度配料与代谢分析：`AnalyzeIngredients`
3. 专业健康洞察：`GetHealthInsight`

### 食物搜索

如果没有图片，可以使用关键词搜索食物：

```
SearchFood: "banana"
```

最多返回 20 条结果，包含宏量营养和 GI。

## 输出规则

- 数值必须与 API 原始返回保持一致
- 不要补造缺失字段
- 完整图片分析直接使用 `AnalyzeWholeFood`
- 只有当用户明确要求某个分析维度时，才使用专项接口
- 健康评分范围为 `1-5`，可帮助用户做出更有营养依据的选择
