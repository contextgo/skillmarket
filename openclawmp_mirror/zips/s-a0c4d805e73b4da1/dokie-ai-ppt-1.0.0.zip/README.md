<p align="right">
  <a href="README_CN.md">中文</a> | English
</p>

<p align="center">
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/Logo%20Mark%20Cricle.png" alt="Dokie" width="100" />
</p>

<h1 align="center">Dokie AI PPT 技能</h1>

<p align="center">
  与您的 AI 助手对话，获取专业的 HTML 幻灯片。<br/>
  由 <a href="https://dokie.ai">dokie.ai</a> 构建
</p>

<p align="center">
  目前最强大的 AI 演示技能。不仅仅是静态幻灯片 — 完全交互式 HTML 演示文稿，包含入场动画、页面过渡、可点击元素、实时图表，甚至 3D 模型。基于 Web 技术（Tailwind CSS, Chart.js, GSAP, Font Awesome）构建，远超传统 PPT 工具的能力。
</p>

<p align="center">
  <a href="#quick-start">快速开始</a> · <a href="#features">功能特性</a> · <a href="#see-it-in-action">实际效果</a> · <a href="#go-further-with-dokie">进一步使用 Dokie</a>
</p>

<p align="center">
  支持 Claude Code、Cursor、Codex 和 35+ AI 助手 — 任何支持开放技能生态系统的助手。
</p>

---

## 快速开始

**安装技能：**

```bash
npx skills add MYZY-AI/dokie-ai-ppt
```

**要求您的助手创建演示文稿：**

```
"制作一份季度报告演示"
"为我的初创公司制作融资演示"
"构建一个带有创意动画的产品发布演示"
```

该技能会引导您完成每个步骤 — 收集需求、选择主题、审阅大纲、生成幻灯片和预览。在每一步中，您都保持控制权。

<details>
<summary>指定助手</summary>

```bash
npx skills add MYZY-AI/dokie-ai-ppt -a claude-code
npx skills add MYZY-AI/dokie-ai-ppt -a cursor
```

</details>

<details>
<summary>先决条件</summary>

```bash
npx dokie-cli themes    # 验证 Dokie CLI 是否可用
```

</details>

---

## 功能特性

### 25+ 主题

从商业到医疗，从科技到创意 — 选择内置主题或自定义颜色、字体和装饰以匹配您的品牌。每个主题都包含完整的样式系统，包括排版、调色板、背景和装饰元素。

<p align="center">
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/dokietheme.png" width="260" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/market.png" width="260" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/medi.png" width="260" />
</p>
<p align="center">
  <em>左：Dokie 品牌主题 &nbsp;·&nbsp; 中：市场分析主题 &nbsp;·&nbsp; 右：医疗专业主题</em>
</p>

<p align="center">
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/qinghua.png" width="260" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/trends.png" width="260" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/yellow.png" width="260" />
</p>
<p align="center">
  <em>左：中国瓷器风格 &nbsp;·&nbsp; 中：趋势与数据主题 &nbsp;·&nbsp; 右：温暖创意主题</em>
</p>

### 10+ 种图表类型

柱状图、折线图、饼图、雷达图、气泡图、金字塔图、漏斗图、时间线图、流程图、四象限图 — 全部使用 Chart.js 在 HTML 中实时渲染。没有静态图像，没有截图 — 真实的交互式图表直接嵌入到您的幻灯片中。数据更新？只需更改数字并刷新。

<p align="center">
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/005.png" width="260" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/006.png" width="260" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/007.png" width="260" />
</p>
<p align="center">
  <em>柱状图 · 折线图 · 环形图 &nbsp;|&nbsp; 雷达图 · 气泡图 &nbsp;|&nbsp; 漏斗图 · 金字塔图</em>
</p>
<p align="center">
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/008.png" width="260" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/009.png" width="260" />
</p>
<p align="center">
  <em>时间线图 · 四象限图 &nbsp;|&nbsp; 流程图 · 循环图</em>
</p>

### 动画与交互

这不是您典型的"淡入"演示工具。每张幻灯片都是一个真实的网页，这意味着您可以获得完整的网页动画和交互功能：

- **入场动画** — 元素飞入、淡入、缩放、旋转、模糊 — 每个都有精确的时间曲线和缓动曲线
- **页面转场** — 平滑的幻灯片间过渡，具有电影般的流动感
- **交互元素** — 可点击的标签、悬停效果、可展开的区块 — 您的观众可以探索，而不仅仅是观看
- **滚动触发效果** — 内容随着滚动显示，创造故事叙述的节奏感
- **视差与分层运动** — 平面幻灯片无法实现的深度和维度
- **3D模型与高级视觉效果** — 嵌入3D对象、粒子效果等 — 浏览器就是您的画布

从3种强度级别中选择：

- **简约** — 微妙的淡入和滑动。干净专业，完美适合内容本身就能说明问题的企业环境。
- **平衡** — 适度的运动与错开的时间。增加视觉节奏而不分散注意力。非常适合产品演示和团队会议。
- **创意** — 完整的电影级体验。滚动触发的显示、视差层、动态过渡。专为需要给人留下深刻印象的主题演讲和推介而设计。达到Awwwards级别的动画设计。

<p align="center">
  <a href="https://www.dokie.ai/presentation/share/azVPjJDBaPgM">
    <img src="https://github.com/user-attachments/assets/85a9a3a3-5054-48b4-826f-209e3456e0f9" width="680" />
  </a>
</p>
<p align="center">
  <em>创意动画风格 — 带有分层过渡的电影级入场效果。<a href="https://www.dokie.ai/presentation/share/azVPjJDBaPgM">点击查看实时演示 →</a></em>
</p>

### 自动质量检查

生成后，技能会自动检查每张幻灯片：
- **内容溢出** — 文本或元素超出幻灯片边界
- **图表渲染** — 确保所有数据可视化正确显示
- **主题一致性** — 验证字体、颜色和间距是否与所选主题匹配

问题会在您注意到之前就被修复。您可以在第一次预览时就获得精美的结果。

---

## 实际体验

生成的幻灯片会立即预览。预览服务器为您提供两个链接 — 一个供您本地使用，另一个可以与任何人共享的公共链接：

```
✓ 服务器运行中:

    ➜  本地:   http://localhost:3456
    ➜  公共:  https://your-presentation.trycloudflare.com
```

将公共链接发送给任何人进行快速预览 — 无需安装。要获取永久可共享的链接，请在 [dokie.ai](https://dokie.ai) 中打开您的演示文稿，以获取不会过期的稳定 URL。

<p align="center">
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/preview.jpg" width="680" />
</p>
<p align="center">
  <em>内置预览 — 浏览所有幻灯片，检查布局，通过公共链接与您的团队共享</em>
</p>

---

## 通过 Dokie 进一步探索

想要更多控制权？您生成的每个演示文稿都可以免费在 [dokie.ai](https://dokie.ai) 中打开。在 Dokie 编辑器中，您可以：

- 通过拖放编辑器微调布局、文本和视觉细节
- 在细粒度级别调整样式、颜色和字体
- 导出为 **PDF**、**PPTX**、**图像** 等格式

从 AI 生成到像素级完美润色 — 全部在一个工作流程中完成。

<p align="center">
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/edit.png" width="330" />
  <img src="https://skill-1317512395.cos.ap-singapore.myqcloud.com/editdaochu.png" width="330" />
</p>
<p align="center">
  <em>左侧：在 Dokie 编辑器中微调每个细节 &nbsp;·&nbsp; 右侧：导出为 PDF、PPTX 等格式</em>
</p>

---

<p align="center">
  <a href="https://dokie.ai">dokie.ai</a> · MIT 许可证
</p>