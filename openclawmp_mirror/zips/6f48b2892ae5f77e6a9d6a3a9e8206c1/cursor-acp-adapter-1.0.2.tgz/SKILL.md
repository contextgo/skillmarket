---
name: cursor-acp-adapter
displayName: Cursor ACP适配器
description: 让OpenClaw/acpx能调用Cursor CLI的AI编程能力。实现下游ACP客户端与上游Cursor CLI的双向桥接，支持代码生成、重构、Review等功能。
version: 1.0.2
author: ai-fzx
homepage: https://github.com/ai-fzx/fzx_cursor_acp
tags: [cursor, acp, coding, ai-programming, bridge]
category: tool
---

# Cursor ACP适配器

让 OpenClaw / acpx 能调用 Cursor 的 AI 编程能力。

## 功能特点

- **AI 编程**：让 Cursor 帮你写代码、改代码、Review 代码
- **代码生成**：根据需求自动生成代码实现
- **代码重构**：优化现有代码结构
- **Bug 修复**：分析并修复代码问题
- **代码解释**：解释复杂代码的逻辑
- **测试生成**：自动生成单元测试

## 前置条件

| 条件 | 说明 |
|------|------|
| **安装 Cursor CLI** | 终端能执行 `agent --version` |
| **登录 Cursor** | 执行 `agent login` 或配置 `CURSOR_API_KEY` |
| **安装适配器** | `npm install -g fzx-cursor-acp` |

## 安装步骤

### 1. 安装 Cursor CLI
```bash
# 通过 npm 安装
npm install -g cursor-agent

# 验证安装
agent --version
```

### 2. 登录 Cursor
```bash
agent login
# 或配置 API Key
set CURSOR_API_KEY=your_api_key
```

### 3. 安装适配器
```bash
npm install -g fzx-cursor-acp
```

### 4. 配置 acpx
编辑 `~/.acpx/config.json`：
```json
{
  "agents": {
    "cursor": {
      "command": "fzx-cursor-acp"
    }
  }
}
```

## 使用示例

### 新建会话
```bash
acpx cursor sessions new
```

### 代码生成
```bash
acpx cursor "帮我写一个 Python 爬虫，抓取豆瓣电影 Top 250"
```

### 代码重构
```bash
acpx --cwd D:\myproject cursor "优化这个项目的代码结构"
```

### 代码审查
```bash
acpx cursor "Review 这个文件的代码质量"
```

### Bug 修复
```bash
acpx cursor "这个代码有bug，帮我修复"
```

## 常用命令

| 命令 | 说明 |
|------|------|
| `acpx cursor sessions new` | 新建会话 |
| `acpx cursor "任务"` | 发送任务 |
| `acpx --cwd 路径 cursor "任务"` | 指定工作目录 |
| `acpx cursor sessions list` | 列出会话 |
| `acpx cursor status` | 查看状态 |
| `acpx cursor cancel` | 取消任务 |

## 权限策略

```bash
# 自动批准所有操作
acpx --approve-all cursor "任务"

# 只批准读操作
acpx --approve-reads cursor "任务"

# 拒绝所有操作（仅查看）
acpx --deny-all cursor "任务"
```

## 注意事项

- 本适配器启动的是 **Cursor CLI**，不是 Cursor IDE 的 Agent 面板
- 任务在子进程中运行，不会在 Cursor 编辑器窗口显示
- 需要有效的 Cursor 登录态才能稳定执行
- 支持 Windows、Mac、Linux 三平台

## 故障排查

### 提示 "Cursor CLI not found"
```bash
# 检查安装
where.exe agent
# 或
which agent

# 重新安装
npm install -g cursor-agent
```

### 提示 "Not logged in"
```bash
agent login
```

### 查看调试日志
```powershell
$env:LOG_LEVEL="debug"
fzx-cursor-acp
```

## 相关链接

- GitHub：https://github.com/ai-fzx/fzx_cursor_acp
- npm：https://www.npmjs.com/package/fzx-cursor-acp
- acpx：https://github.com/openclaw/acpx

## 许可证

MIT