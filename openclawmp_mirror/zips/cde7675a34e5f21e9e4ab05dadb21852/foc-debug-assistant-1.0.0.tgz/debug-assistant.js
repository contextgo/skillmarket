/**
 * FOC参数调试助手
 * 提供FOC控制参数诊断和分析
 */

/**
 * 分析电流环PI参数是否合理
 */
function analyzeCurrentLoopPI(Kp, Ki, Kd = 0, R, L, Ts) {
  const results = {
    bandwidth_approx: Kp / L, // 近似带宽 rad/s
    stability: [],
    recommendations: []
  };

  // 稳定性检查
  if (Kp <= 0) {
    results.stability.push('❌ Kp必须大于0');
  }
  if (Ki < 0 || Ki > Kp) {
    results.stability.push('⚠️ Ki建议在 0 ~ Kp 范围内');
  }
  if (Kd > Kp * 2) {
    results.stability.push('⚠️ Kd过大可能导致噪声放大');
  }

  // 带宽检查（经验公式：带宽 ≈ Kp/L）
  const bw = results.bandwidth_approx;
  if (bw < 100) {
    results.recommendations.push(`电流环带宽过低(${bw.toFixed(0)} rad/s)，建议提高Kp`);
  } else if (bw > 5000) {
    results.recommendations.push(`电流环带宽过高(${bw.toFixed(0)} rad/s)，可能导致噪声敏感`);
  } else {
    results.recommendations.push(`电流环带宽合理：${bw.toFixed(0)} rad/s`);
  }

  // 时间尺度检查
  const Tc = 1 / bw; // 电流环响应时间
  if (Ts / Tc < 5) {
    results.stability.push(`⚠️ 采样周期${(Ts*1e6).toFixed(0)}μs相对于电流环响应过短，建议采样周期 ≤ 电流环时间常数的1/5`);
  }

  return results;
}

/**
 * 分析速度环PI参数
 */
function analyzeSpeedLoopPI(Kp, Ki, J, B, Kt) {
  const results = {
    response_time: [],
    stability: [],
    recommendations: []
  };

  // 速度环自然频率估算（简化模型）
  const wn = Math.sqrt(Ki * Kt / J); // 简化估算
  const damping = Kp / (2 * Math.sqrt(Kt * Ki * J));

  if (damping < 0.5) {
    results.stability.push(`阻尼比过低(${damping.toFixed(2)})，系统可能振荡`);
    results.recommendations.push('建议增加Kp或减小Ki以提高阻尼');
  } else if (damping > 2) {
    results.stability.push(`阻尼比偏高(${damping.toFixed(2)})，响应可能偏慢`);
    results.recommendations.push('可适当增加Ki提高响应速度');
  } else {
    results.stability.push(`阻尼比合理：${damping.toFixed(2)}`);
  }

  if (wn < 1) {
    results.recommendations.push(`速度环响应过慢，自然频率${wn.toFixed(2)} rad/s偏低`);
  } else if (wn > 50) {
    results.recommendations.push(`速度环响应过快，自然频率${wn.toFixed(2)} rad/s可能引起噪声`);
  }

  return results;
}

/**
 * 极对数/槽数配合检查
 */
function checkPoleSlotConfig(poles, slots) {
  const results = {
    valid: true,
    issues: [],
    suggestions: []
  };

  const p = poles / 2;
  const q = slots / (poles * 3); // 每极每相槽数

  if (!Number.isInteger(q)) {
    results.issues.push(`分数槽配合 (q=${q.toFixed(2)})，可能引起齿槽转矩脉动`);
    results.suggestions.push('分数槽绕组需要特别注意绕组分布系数的计算');
  }

  // 常见合理配合
  const commonConfigs = [
    [2, 12], [4, 24], [4, 36], [6, 36], [6, 54], [8, 24], [8, 36], [8, 48], [10, 30], [10, 60]
  ];

  const isCommon = commonConfigs.some(([pp, ss]) => pp === p && ss === slots);
  if (!isCommon && Number.isInteger(q)) {
    results.suggestions.push(`整数槽配合(${p}对极/${slots}槽)可进一步验证合理性`);
  }

  // 槽极比检查
  const slotPoleRatio = slots / poles;
  if (slotPoleRatio < 2) {
    results.issues.push(`槽极比(${slotPoleRatio})偏低，齿槽转矩可能较大`);
  }

  return results;
}

/**
 * 诊断FOC故障
 */
function diagnoseFOCSymptom(symptom, details = {}) {
  const symptomLower = symptom.toLowerCase();
  
  const diagnosisMap = {
    '抖动': {
      causes: ['电流环带宽不足', 'Hall信号错误/延迟', '极对数配置错误', '机械松动', 'PWM分辨率不足'],
      steps: [
        '1. 检查极对数配置是否与电机铭牌一致',
        '2. 测量Hall信号，确认安装角度正确',
        '3. 检查电流环带宽，建议至少500 rad/s',
        '4. 降低转速观察是否改善，判断是否为机械共振'
      ]
    },
    '噪声': {
      causes: ['电流谐波', '开关频率过低(<10kHz)', 'PWM分辨率不足', '采样点位置不当', '磁密饱和'],
      steps: [
        '1. 将PWM频率提高到16kHz或20kHz',
        '2. 检查电流波形是否有明显谐波',
        '3. 调整采样点位置（建议在PWM中心采样）',
        '4. 检查气隙磁密是否饱和'
      ]
    },
    '效率': {
      causes: ['磁链观测偏差', '弱磁区参数不当', '铜损过高', '磁密设计偏高', '控制器开关损耗'],
      steps: [
        '1. 校准磁链观测器，对比反电动势实测值',
        '2. 检查高速区弱磁升压是否足够',
        '3. 检查线径/槽满率是否合理',
        '4. 测量三相电流平衡度'
      ]
    },
    '启动': {
      causes: ['初始角度错误', '启动电流不足', 'Hall信号接错', '磁链观测器收敛慢'],
      steps: [
        '1. 使用预定位方式启动，确认初始角度',
        '2. 检查Hall信号与UVW相序是否正确',
        '3. 适当提高启动电流',
        '4. 观测器收敛时间建议<100ms'
      ]
    },
    '高速': {
      causes: ['弱磁PI不当', '磁链观测动态响应差', '反电动势过高', 'PWM占空比饱和'],
      steps: [
        '1. 检查弱磁升压PI参数，Kp建议0.5~2.0',
        '2. 优化磁链观测器（PLL带宽适当提高）',
        '3. 确认反电动势常数设计，高速时注意限制电压',
        '4. 检查FOC输出是否进入电压饱和区'
      ]
    }
  };

  for (const [key, diagnosis] of Object.entries(diagnosisMap)) {
    if (symptomLower.includes(key)) {
      return { symptom: key, ...diagnosis };
    }
  }

  return {
    symptom: symptom,
    causes: ['参数配置问题', '传感器问题', '机械问题'],
    steps: ['建议提供更多细节：电机参数、控制器型号、观测器类型、具体转速范围']
  };
}

// CLI
const args = process.argv.slice(2);
if (args.length > 0) {
  const cmd = args[0];
  const params = args.slice(1);
  
  if (cmd === 'diagnose') {
    console.log(JSON.stringify(diagnoseFOCSymptom(params.join(' ')), null, 2));
  } else if (cmd === 'check-pole-slot') {
    console.log(JSON.stringify(checkPoleSlotConfig(parseInt(params[0]), parseInt(params[1])), null, 2));
  } else if (cmd === 'analyze-current') {
    console.log(JSON.stringify(analyzeCurrentLoopPI(parseFloat(params[0]), parseFloat(params[1]), parseFloat(params[2]||0), parseFloat(params[3]), parseFloat(params[4])), null, 2));
  } else {
    console.log('用法: node debug-assistant.js diagnose "抖动"');
  }
}

module.exports = { analyzeCurrentLoopPI, analyzeSpeedLoopPI, checkPoleSlotConfig, diagnoseFOCSymptom };
