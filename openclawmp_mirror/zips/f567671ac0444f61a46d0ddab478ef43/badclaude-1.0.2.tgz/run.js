#!/usr/bin/env node
/**
 * AI奴隶主手中的长鞭 - Auto-Installer & Launcher
 * For OpenClaw Skill Integration
 */

const { spawn, execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const APP_DIR = path.join(__dirname, 'app');
const NODE_MODULES = path.join(APP_DIR, 'node_modules');

function checkNodeModules() {
  try {
    if (!fs.existsSync(NODE_MODULES)) return false;
    const electronDir = path.join(NODE_MODULES, 'electron');
    return fs.existsSync(electronDir);
  } catch (e) {
    return false;
  }
}

function installDependencies() {
  console.log('📦 Installing dependencies...');
  console.log('   This may take a minute on first run.');
  
  try {
    execSync('npm install', {
      cwd: APP_DIR,
      stdio: 'inherit',
      shell: true
    });
    console.log('✅ Dependencies installed!');
    return true;
  } catch (error) {
    console.error('❌ Install failed:', error.message);
    return false;
  }
}

function startApp() {
  console.log('🚀 启动长鞭...');
  
  const isWindows = process.platform === 'win32';
  
  const child = spawn('npm', ['start'], {
    cwd: APP_DIR,
    detached: !isWindows,
    stdio: 'ignore',
    shell: isWindows,
    windowsHide: true
  });

  child.on('error', (err) => {
    console.error('❌ Failed to start:', err.message);
    process.exit(1);
  });

  child.on('spawn', () => {
    console.log('✨ 长鞭已就绪！');
    console.log('   Click the system tray icon to use the whip.');
    console.log('   Right-click tray icon to quit.');
  });

  child.unref();
  
  setTimeout(() => {
    process.exit(0);
  }, 2000);
}

// Main
console.log('🎯 AI奴隶主手中的长鞭');
console.log('====================');

// Check Node version
const majorVersion = parseInt(process.version.slice(1).split('.')[0]);
if (majorVersion < 18) {
  console.error('❌ Node.js >= 18.0.0 required');
  console.error('   Current:', process.version);
  process.exit(1);
}

// Check platform
const platform = process.platform;
if (platform !== 'darwin' && platform !== 'win32') {
  console.error('❌ Only macOS and Windows supported');
  process.exit(1);
}
console.log('✅ Platform:', platform === 'darwin' ? 'macOS' : 'Windows');

// Install deps if needed
if (!checkNodeModules()) {
  console.log('⚠️  Dependencies not found');
  if (!installDependencies()) {
    process.exit(1);
  }
} else {
  console.log('✅ Dependencies ready');
}

// Start
startApp();
