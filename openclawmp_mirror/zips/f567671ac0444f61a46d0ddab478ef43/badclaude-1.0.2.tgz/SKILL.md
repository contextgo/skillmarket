---
name: badclaude
description: |
  Run the badclaude Electron app - a playful desktop overlay with a virtual whip.
  
  **Auto-installation**: This skill automatically checks and installs dependencies on first run.
  Click the tray icon to spawn a virtual whip; when the whip cracks, it plays a sound effect and displays anime-style text.
  Purely for fun - no keyboard interference, no focus stealing, no Ctrl+C sending.
  
  Use when user wants to run badclaude, launch the whip overlay tool, or just have some fun.
---

# 虚拟鞭子 - 纯娱乐桌面工具

一个有趣的桌面工具，通过虚拟鞭子带来轻松娱乐的体验。

## Quick Start

Simply ask me to run badclaude:

```
Run badclaude
```

Or:

```
启动鞭子
```

I will execute: `node run.js` which automatically:
1. Check Node.js version (>= 18)
2. Check platform compatibility (macOS/Windows)
3. Install dependencies if needed (`npm install` in app/ directory)
4. Start the application (`npm start` in app/ directory)

## How to Run

From the skill directory:

```bash
node run.js
```

The launcher will:
- Check prerequisites
- Install dependencies on first run (may take 1-2 minutes)
- Start the Electron app
- Show system tray icon

## What It Does

BadClaude creates a system tray icon that, when clicked, spawns a virtual whip overlay:
- **Click tray icon**: Spawn the whip at screen center
- **Whip physics**: Automatic whip movement with physics simulation
- **Auto drop**: Whip automatically drops after 3 seconds
- **Whip crack**: When tip breaks sound barrier:
  - 🔊 Plays whip crack sound effect
  - ✨ Displays anime-style text with glow effects

**注意**: 此版本已完全移除所有键盘输入、Ctrl+C 发送和焦点抢夺功能。窗口使用点击穿透模式，不会干扰其他应用。

## Controls

| Action | Result |
|--------|--------|
| Click tray icon | Spawn whip overlay (auto plays) |
| Click tray icon again | Drop whip immediately |
| Right-click tray icon | Show menu with Quit option |

## Platform Support

- **macOS**: ✅ Full support
- **Windows**: ✅ Full support
- **Linux**: ❌ Not supported

## Requirements

- Node.js >= 18.0.0
- npm (comes with Node.js)
- macOS or Windows

## Files

This skill includes the complete badclaude app in the `app/` directory:
- `app/main.js` - Electron main process
- `app/overlay.html` - Whip physics simulation and text effects
- `app/sounds/` - Sound effects
- `app/icon/` - Tray icons

## Troubleshooting

**No sound?** Check that sound files exist in `app/sounds/`

**Install fails?** Check Node.js version: `node --version`

## License

MIT
