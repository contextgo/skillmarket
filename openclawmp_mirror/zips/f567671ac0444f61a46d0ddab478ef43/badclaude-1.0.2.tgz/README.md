# AI奴隶主手中的长鞭

一个有趣的桌面鞭子工具，通过虚拟鞭子让AI助手更努力地工作！

## Installation

1. Copy this folder to your OpenClaw skills directory:
   ```
   ~/.stepclaw/skills/badclaude/
   ```

2. Ask your OpenClaw agent:
   ```
   Run badclaude
   ```

That's it! The skill will automatically install dependencies on first run.

## Usage

- **Click tray icon**: Spawn the whip
- **Move mouse**: Control the whip
- **Whip crack**: Sends Ctrl+C + encouragement message
- **Right-click tray**: Quit

## Requirements

- Node.js >= 18
- Windows or macOS

## Files

- `SKILL.md` - Skill documentation
- `run.js` - Auto-installer and launcher
- `app/` - Electron application
