#!/usr/bin/env node
/**
 * Pack BadClaude Skill for Sharing
 * Creates a clean zip without node_modules
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SKILL_DIR = __dirname;
const SKILL_NAME = path.basename(SKILL_DIR);
const OUTPUT_NAME = 'badclaude-skill-ready';

function pack() {
  console.log('📦 BadClaude Skill Packager');
  console.log('============================');
  console.log();
  
  const parentDir = path.dirname(SKILL_DIR);
  const zipPath = path.join(parentDir, `${OUTPUT_NAME}.zip`);
  
  // Remove existing zip
  if (fs.existsSync(zipPath)) {
    fs.unlinkSync(zipPath);
    console.log('🗑️  Removed old zip');
  }
  
  console.log('📁 Skill directory:', SKILL_DIR);
  console.log('📤 Output:', zipPath);
  console.log();
  
  // Check if node_modules exists in app/
  const appNodeModules = path.join(SKILL_DIR, 'app', 'node_modules');
  const hasNodeModules = fs.existsSync(appNodeModules);
  
  if (hasNodeModules) {
    const stats = fs.statSync(appNodeModules);
    const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
    console.log(`⚠️  Found node_modules (${sizeMB} MB) - will be excluded from zip`);
    console.log('   Recipient will auto-install on first run');
    console.log();
  }
  
  // Create zip (excluding node_modules)
  console.log('🗜️  Creating zip...');
  
  try {
    const isWindows = process.platform === 'win32';
    
    if (isWindows) {
      // Use PowerShell
      const cmd = `powershell -Command "& {Compress-Archive -Path '${SKILL_DIR}\*' -DestinationPath '${zipPath}' -Force}"`;
      execSync(cmd, { stdio: 'pipe' });
      
      // Remove node_modules from zip if it was included
      if (hasNodeModules) {
        console.log('   Removing node_modules from zip...');
        const removeCmd = `powershell -Command "& {$zip = [System.IO.Compression.ZipFile]::Open('${zipPath}', 'Update'); $entries = $zip.Entries | Where-Object { $_.FullName -like '*/node_modules/*' }; foreach($e in $entries) { $zip.DeleteEntry($e) }; $zip.Dispose()}"`;
        try {
          execSync(removeCmd, { stdio: 'pipe' });
        } catch (e) {
          // Ignore, PowerShell method might not work
        }
      }
    } else {
      // Use zip command
      execSync(`cd "${parentDir}" && zip -r "${OUTPUT_NAME}.zip" "${SKILL_NAME}" -x "*/node_modules/*" -x "*/.git/*" -x "*/.DS_Store"`, 
        { stdio: 'pipe' });
    }
    
    // Show result
    const stats = fs.statSync(zipPath);
    const sizeMB = (stats.size / 1024 / 1024).toFixed(2);
    
    console.log();
    console.log('✅ Packaged successfully!');
    console.log('   File:', zipPath);
    console.log('   Size:', sizeMB, 'MB');
    console.log();
    console.log('📤 Share this zip file with others');
    console.log();
    console.log('📋 Installation instructions for recipient:');
    console.log('   1. Extract zip to ~/.stepclaw/skills/');
    console.log('   2. Rename folder to "badclaude"');
    console.log('   3. Ask OpenClaw: "Run badclaude"');
    console.log('   4. Wait for auto-installation (1-2 min on first run)');
    
  } catch (error) {
    console.error('❌ Packaging failed:', error.message);
    console.log();
    console.log('💡 Manual method:');
    console.log('   1. Copy this skill folder');
    console.log('   2. Delete app/node_modules/');
    console.log('   3. Zip the folder');
    process.exit(1);
  }
}

pack();
