---
name: news-signal-tfidf-matching
description: "TF-IDF 文本匹配引擎，用于新闻标题与预测市场信号的自动关联"
version: 1.0.0
tags: [nlp, tfidf, news, signal, prediction-market, text-matching]
---

# 新闻信号 TF-IDF 匹配引擎

## 概述

将新闻标题与预测市场信号进行自动匹配，计算相关性分数，筛选高置信度信号。

## TF-IDF 原理

- **TF（词频）**：某词在文档中出现的频率越高越重要
- **IDF（逆文档频率）**：某词在所有文档中越少出现越独特

```
TF-IDF = (词在文档中出现次数 / 文档总词数) × log(总文档数 / 包含该词的文档数)
```

## Python 实现（零依赖版）

```python
import math, re
from collections import Counter
from typing import List, Dict, Tuple

def tokenize(text: str) -> List[str]:
    """简单分词：转小写 + 提取单词"""
    return re.findall(r'\b[a-z]{2,}\b', text.lower())

def tf(words: List[str]) -> Dict[str, float]:
    """计算词频"""
    counts = Counter(words)
    total = len(words)
    return {w: c/total for w, c in counts.items()}

def idf(documents: List[List[str]]) -> Dict[str, float]:
    """计算逆文档频率"""
    n = len(documents)
    df = Counter()
    for doc in documents:
        df.update(set(doc))
    return {w: math.log(n / (f + 1)) + 1 for w, f in df.items()}

def cosine_similarity(v1: Dict[str, float], v2: Dict[str, float]) -> float:
    """余弦相似度"""
    common = set(v1) & set(v2)
    if not common:
        return 0.0
    dot = sum(v1[w] * v2[w] for w in common)
    norm1 = math.sqrt(sum(v ** 2 for v in v1.values()))
    norm2 = math.sqrt(sum(v ** 2 for v in v2.values()))
    return dot / (norm1 * norm2) if norm1 and norm2 else 0.0

class TFIDFMatcher:
    def __init__(self, signals: Dict[str, str]):
        """
        Args:
            signals: {signal_id: "关键词描述"} 的映射
        """
        self.signal_ids = list(signals.keys())
        self.signal_tokens = {sid: tokenize(desc) for sid, desc in signals.items()}
        self.signal_tfidf = {}
        
        idf_vals = idf(list(self.signal_tokens.values()))
        for sid, tokens in self.signal_tokens.items():
            tf_vals = tf(tokens)
            self.signal_tfidf[sid] = {w: tf_vals.get(w, 0) * idf_vals.get(w, 1)
                                       for w in set(tokens)}
    
    def match(self, news_title: str, threshold: float = 0.3) -> List[Tuple[str, float]]:
        """匹配新闻标题与信号，返回 [(signal_id, score)] 降序排列"""
        news_tokens = tokenize(news_title)
        news_tfidf = {}
        for w in news_tokens:
            # 用 TF × 默认 IDF（简化版）
            news_tfidf[w] = news_tokens.count(w) / len(news_tokens) * 1.5
        
        results = []
        for sid, svec in self.signal_tfidf.items():
            score = cosine_similarity(news_tfidf, svec)
            if score >= threshold:
                results.append((sid, score))
        
        return sorted(results, key=lambda x: x[1], reverse=True)

# 使用示例
signals = {
    "oil_price": "crude oil brent WTI price surge barrel energy OPEC",
    "iran_war": "Iran military strike US conflict hormuz war escalation",
    "bitcoin": "bitcoin BTC cryptocurrency price crash rally market",
    "gold": "gold precious metal price safe haven inflation",
    "stock_market": "stock market S&P dow jones nasdaq equities recession",
}

matcher = TFIDFMatcher(signals)
results = matcher.match("Brent crude oil hits $120 as Iran tensions escalate")
# [('oil_price', 0.62), ('iran_war', 0.45)]
```

## 阈值建议

| 阈值 | 含义 | 适用场景 |
|------|------|---------|
| ≥ 0.5 | 强匹配 | 直接用于交易信号 |
| 0.3-0.5 | 中等匹配 | 需要人工确认 |
| < 0.3 | 弱匹配 | 忽略 |

## 优化方向

1. 增加同义词映射（crude ↔ petroleum ↔ oil）
2. 加入关键词权重（OPEC 比 "the" 重要）
3. 用新闻全文而非标题（但计算成本更高）
4. 按时间衰减旧信号
