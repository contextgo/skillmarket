---
name: email-outreach-auto
description: |
  候选人邮件触达自动化：个性化冷邮件撰写 + 定时跟进序列 + 审批发送。
  基于 cold-email 框架优化，支持三种首发模板（论文型/行业型/GitHub型）和三轮自动跟进。
  Use when: 需要给候选人发触达邮件、设置跟进提醒、批量邮件触达、管理邮件序列。
  Requires: SMTP 配置（host/port/username/password）。
  Author: HXM
---

# Email Outreach Auto — 候选人邮件触达自动化

## 核心能力

1. **个性化首发邮件** — 根据候选人来源自动选模板，填充个性化内容
2. **自动跟进序列** — 3天/8天/15天三轮跟进，每封带新信息
3. **审批流程** — 跟进邮件先生成草稿，用户确认后才发出
4. **触达记录** — 自动记录状态、跟进次数、下次跟进时间

## 工作流程

```
用户提供候选人信息
    ↓
选择模板（paper/industry/github）→ 生成个性化邮件
    ↓
发送 + 记录到 outreach_db.json
    ↓
cron 每天检查到期跟进 → 生成草稿 → 通知用户审批
    ↓
用户确认 → 发送跟进 → 更新记录
    ↓
3轮跟进后未回复 → 自动关闭
```

## 配置

首次使用前，编辑 `scripts/outreach_db.json` 中的 config 部分：

```json
{
  "config": {
    "smtp_host": "smtp.example.com",
    "smtp_port": 465,
    "smtp_secure": true,
    "smtp_username": "you@example.com",
    "default_from": "you@example.com",
    "followup_schedule": [3, 8, 15],
    "signature": "你的签名"
  }
}
```

SMTP 密码通过环境变量 `SMTP_PASSWORD` 传入，不存储在文件中。

## 使用方法

### 发送首封邮件

```bash
python scripts/send_outreach.py \
  --name "张三" --email "zhangsan@xxx.com" \
  --direction "多模态" --source "arXiv" \
  --template paper \
  --paper_title "Attention Residuals" \
  --paper_insight "用softmax attention替代固定权重残差" \
  --team_direction "模型架构创新"
```

模板选择：
- `paper` — 论文/项目认可型（需 paper_title, paper_insight, team_direction）
- `industry` — 行业动态型（需 observation, role_highlight）
- `github` — 技术社区型（需 repo, contribution, role）

### 检查跟进

```bash
python scripts/check_followups.py
```

### 审批发送跟进

```bash
python scripts/approve_followup.py --id <candidate_id>  # 单个
python scripts/approve_followup.py --all                  # 全部
```

## 邮件写作原则

详见 `references/writing-guide.md`：
- 像同行聊天，不像HR群发
- 每句话都必须有存在的理由
- 全文不超过150字
- 只有一个低门槛请求
- 跟进必须带新信息

## 跟进序列策略

详见 `references/followup-strategy.md`：
- 第3天：补充新角度（团队/技术进展）
- 第8天：分享资源（行业洞察/开源项目）
- 第15天：最终触达，尊重选择，留长线联系方式

## 文件结构

```
email-outreach-auto/
├── SKILL.md                          # 本文件
├── scripts/
│   ├── email_templates.py            # 邮件模板库
│   ├── send_outreach.py              # 发送首封邮件
│   ├── check_followups.py            # 检查到期跟进
│   ├── approve_followup.py           # 审批后发送
│   ├── cron_check.py                 # cron 入口
│   └── outreach_db.json              # 触达记录数据库
└── references/
    ├── writing-guide.md              # 邮件写作原则
    └── followup-strategy.md          # 跟进策略详解
```
