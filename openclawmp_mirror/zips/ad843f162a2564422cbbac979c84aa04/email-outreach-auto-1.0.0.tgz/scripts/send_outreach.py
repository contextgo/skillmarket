# -*- coding: utf-8 -*-
"""
发送首封触达邮件 + 记录到数据库
用法: python send_outreach.py --name "张三" --email "zhangsan@xxx.com" --direction "多模态" --source "arXiv" --template paper --paper_title "Attention Residuals" --paper_insight "用softmax attention替代固定权重残差" --team_direction "模型架构创新"
"""
import json, smtplib, ssl, argparse, os, uuid
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "outreach_db.json")

def load_db():
    with open(DB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_db(db):
    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def send_email(to_addr, subject, body, db):
    cfg = db["config"]
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = cfg["default_from"]
    msg["To"] = to_addr
    msg.attach(MIMEText(body, "plain", "utf-8"))

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(cfg["smtp_host"], cfg["smtp_port"], context=context) as server:
        server.login(cfg["smtp_username"], os.environ.get("SMTP_PASSWORD", ""))
        server.sendmail(cfg["default_from"], to_addr, msg.as_string())
    print(f"✅ Email sent to {to_addr}")

def main():
    parser = argparse.ArgumentParser(description="发送首封触达邮件")
    parser.add_argument("--name", required=True, help="候选人姓名")
    parser.add_argument("--email", required=True, help="候选人邮箱")
    parser.add_argument("--direction", required=True, help="技术方向")
    parser.add_argument("--source", required=True, help="发现来源 (arXiv/GitHub/脉脉)")
    parser.add_argument("--template", default="paper", choices=["paper", "industry", "github"])
    parser.add_argument("--subject", default=None, help="自定义主题")
    # paper template args
    parser.add_argument("--paper_title", default="")
    parser.add_argument("--paper_insight", default="")
    parser.add_argument("--team_direction", default="大模型")
    # industry template args
    parser.add_argument("--observation", default="")
    parser.add_argument("--role_highlight", default="")
    # github template args
    parser.add_argument("--repo", default="")
    parser.add_argument("--contribution", default="")
    parser.add_argument("--role", default="")
    args = parser.parse_args()

    from email_templates import template_paper, template_industry, template_github

    if args.template == "paper":
        subject, body = template_paper(args.name, args.paper_title, args.paper_insight, args.team_direction)
    elif args.template == "industry":
        subject, body = template_industry(args.name, args.observation, args.role_highlight)
    elif args.template == "github":
        subject, body = template_github(args.name, args.repo, args.contribution, args.role)

    if args.subject:
        subject = args.subject

    db = load_db()
    send_email(args.email, subject, body, db)

    # 记录到数据库
    schedule = db["config"]["followup_schedule"]
    now = datetime.now()
    candidate = {
        "id": str(uuid.uuid4())[:8],
        "name": args.name,
        "email": args.email,
        "direction": args.direction,
        "source": args.source,
        "template": args.template,
        "subject": subject,
        "status": "contacted",
        "first_sent": now.strftime("%Y-%m-%d %H:%M"),
        "followup_count": 0,
        "next_followup": (now + timedelta(days=schedule[0])).strftime("%Y-%m-%d"),
        "responded": False,
        "notes": ""
    }
    db["candidates"].append(candidate)
    save_db(db)
    print(f"📝 Recorded: {args.name} ({args.email}) - next followup: {candidate['next_followup']}")

if __name__ == "__main__":
    main()
