# -*- coding: utf-8 -*-
"""
审批通过后发送跟进邮件
用法: python approve_followup.py --id <candidate_id> [--all]
"""
import json, smtplib, ssl, argparse, os
from datetime import datetime, timedelta
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "outreach_db.json")
PENDING_PATH = os.path.join(SCRIPT_DIR, "pending_followups.json")

def load_db():
    with open(DB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_db(db):
    with open(DB_PATH, "w", encoding="utf-8") as f:
        json.dump(db, f, ensure_ascii=False, indent=2)

def load_pending():
    if not os.path.exists(PENDING_PATH):
        return []
    with open(PENDING_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_pending(pending):
    with open(PENDING_PATH, "w", encoding="utf-8") as f:
        json.dump(pending, f, ensure_ascii=False, indent=2)

def send_email(to_addr, subject, body, cfg):
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"] = cfg["default_from"]
    msg["To"] = to_addr
    msg.attach(MIMEText(body, "plain", "utf-8"))

    context = ssl.create_default_context()
    with smtplib.SMTP_SSL(cfg["smtp_host"], cfg["smtp_port"], context=context) as server:
        server.login(cfg["smtp_username"], os.environ.get("SMTP_PASSWORD", ""))
        server.sendmail(cfg["default_from"], to_addr, msg.as_string())
    print(f"✅ Followup sent to {to_addr}")

def approve(candidate_id=None, approve_all=False):
    db = load_db()
    pending = load_pending()
    if not pending:
        print("📭 没有待审批的跟进邮件")
        return

    schedule = db["config"]["followup_schedule"]
    sent = []

    for p in pending:
        if not approve_all and p["candidate_id"] != candidate_id:
            continue

        # 发送邮件
        send_email(p["email"], p["subject"], p["body"], db["config"])

        # 更新数据库
        for c in db["candidates"]:
            if c["id"] == p["candidate_id"]:
                c["followup_count"] = p["followup_num"]
                c["last_followup"] = datetime.now().strftime("%Y-%m-%d %H:%M")
                # 计算下次跟进时间
                if p["followup_num"] < 3:
                    first_sent = datetime.strptime(c["first_sent"], "%Y-%m-%d %H:%M")
                    next_days = schedule[p["followup_num"]]  # schedule[1]=8, schedule[2]=15
                    c["next_followup"] = (first_sent + timedelta(days=next_days)).strftime("%Y-%m-%d")
                else:
                    c["status"] = "closed"
                    c["next_followup"] = None
                break

        sent.append(p["candidate_id"])

    # 清除已发送的 pending
    remaining = [p for p in pending if p["candidate_id"] not in sent]
    save_pending(remaining)
    save_db(db)
    print(f"📬 已发送 {len(sent)} 封跟进邮件")

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--id", default=None, help="候选人ID")
    parser.add_argument("--all", action="store_true", help="审批全部")
    args = parser.parse_args()
    approve(candidate_id=args.id, approve_all=args.all)

if __name__ == "__main__":
    main()
