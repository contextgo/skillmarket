# -*- coding: utf-8 -*-
"""邮件模板库 - 基于 cold-email skill
签名从 outreach_db.json 的 config.signature 读取
"""
import json, os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "outreach_db.json")

def _load_signature():
    """从配置文件读取签名"""
    try:
        with open(DB_PATH, "r", encoding="utf-8") as f:
            db = json.load(f)
        return "\n" + db["config"]["signature"]
    except Exception:
        return "\n[请在 outreach_db.json 中配置 signature]"

# ====== 首发模板 ======

def template_paper(name, paper_title, paper_insight, team_direction):
    """模板A：论文/项目认可型"""
    sig = _load_signature()
    subject = "模型架构创新 · 交流"
    body = f"""{name}你好，

看到你参与的 {paper_title} 这篇工作——{paper_insight}。

我们团队正好在做{team_direction}方向的研究，和你的工作很契合。
{sig}"""
    return subject, body


def template_industry(name, observation, role_highlight):
    """模板B：行业动态型"""
    sig = _load_signature()
    subject = "大模型方向 · 交流"
    body = f"""{name}你好，

注意到你最近{observation}。

我们在大模型方向上刚好有一个很匹配的角色，{role_highlight}。
{sig}"""
    return subject, body


def template_github(name, repo, contribution, role):
    """模板C：技术社区型"""
    sig = _load_signature()
    subject = "技术交流"
    body = f"""{name}你好，

在 GitHub 上看到你对 {repo} 的贡献，特别是{contribution}，设计思路很不错。

我们团队在做类似方向，正在找{role}。技术栈和氛围应该会比较对你的口味。
{sig}"""
    return subject, body


# ====== 跟进模板 ======

def followup_1(name, new_angle):
    """跟进第1封（+3天）：补充新角度"""
    sig = _load_signature()
    subject = "Re: 模型架构创新 · 交流"
    body = f"""{name}你好，

上次发了一封邮件，不确定你有没有看到。

补充一点：{new_angle}

如果时机不对完全理解，也欢迎以后保持联系。
{sig}"""
    return subject, body


def followup_2(name, resource):
    """跟进第2封（+8天）：分享资源"""
    sig = _load_signature()
    subject = "Re: 模型架构创新 · 交流"
    body = f"""{name}你好，

分享一个可能感兴趣的内容：{resource}

和你之前的研究方向比较相关，希望有帮助。

无论是否考虑新机会，都欢迎交流技术。
{sig}"""
    return subject, body


def followup_3(name):
    """跟进第3封（+15天）：最终触达"""
    sig = _load_signature()
    subject = "Re: 模型架构创新 · 交流"
    body = f"""{name}你好，

这是最后一次打扰。如果目前没有看新机会，完全理解。

如果未来有任何想聊的，随时联系我。祝一切顺利！
{sig}"""
    return subject, body
