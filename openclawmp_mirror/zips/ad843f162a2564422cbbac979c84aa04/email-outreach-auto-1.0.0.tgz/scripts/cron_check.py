# -*- coding: utf-8 -*-
"""
cron 入口 - 检查跟进并通知飞书群
由 OpenClaw cron 每天 10:00 调用
"""
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from check_followups import main as check_main

def run():
    pending = check_main()
    if pending:
        # 生成飞书通知文本
        lines = [f"📬 **今日邮件跟进提醒**（{len(pending)}封待审批）\n"]
        for p in pending:
            lines.append(f"- **{p['name']}** ({p['email']}) - 第{p['followup_num']}次跟进")
            lines.append(f"  主题：{p['subject']}")
            lines.append(f"  预览：{p['body'][:80]}...\n")
        lines.append("回复「全部发送」或「发送 [姓名]」来审批。")
        print("\n".join(lines))
    else:
        print("HEARTBEAT_OK")

if __name__ == "__main__":
    run()
