# -*- coding: utf-8 -*-
"""
定时检查跟进 - 由 cron 每天10:00运行
检查 outreach_db.json 中到期的跟进，生成跟进邮件草稿
输出到 pending_followups.json 等待审批
"""
import json, os
from datetime import datetime

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(SCRIPT_DIR, "outreach_db.json")
PENDING_PATH = os.path.join(SCRIPT_DIR, "pending_followups.json")

def load_db():
    with open(DB_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

def save_pending(pending):
    with open(PENDING_PATH, "w", encoding="utf-8") as f:
        json.dump(pending, f, ensure_ascii=False, indent=2)

def main():
    db = load_db()
    today = datetime.now().strftime("%Y-%m-%d")
    schedule = db["config"]["followup_schedule"]
    pending = []

    for c in db["candidates"]:
        # 跳过已回复或已完成全部跟进的
        if c.get("responded", False):
            continue
        if c.get("followup_count", 0) >= 3:
            continue
        if c.get("status") == "closed":
            continue

        next_followup = c.get("next_followup", "")
        if not next_followup or next_followup > today:
            continue

        # 到期了，生成跟进草稿
        followup_num = c["followup_count"] + 1
        from email_templates import followup_1, followup_2, followup_3

        if followup_num == 1:
            subject, body = followup_1(c["name"], f"我们团队最近在{c['direction']}方向有一些新进展，技术挑战很有意思")
        elif followup_num == 2:
            subject, body = followup_2(c["name"], f"最近{c['direction']}方向有几个不错的开源项目和会议，整理了一些信息")
        elif followup_num == 3:
            subject, body = followup_3(c["name"])
        else:
            continue

        pending.append({
            "candidate_id": c["id"],
            "name": c["name"],
            "email": c["email"],
            "followup_num": followup_num,
            "subject": subject,
            "body": body,
            "due_date": next_followup,
            "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M")
        })

    if pending:
        save_pending(pending)
        # 输出摘要供飞书通知
        print(f"📬 今日有 {len(pending)} 封跟进邮件待审批：")
        for p in pending:
            print(f"  - {p['name']} ({p['email']}) 第{p['followup_num']}次跟进")
        return pending
    else:
        print("✅ 今日无需跟进")
        return []

if __name__ == "__main__":
    main()
