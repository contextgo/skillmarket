# 高级 UI/UX 设计智能系统 v2

全面的 UI/UX 设计指南，覆盖 Web 和移动端应用的完整设计流程。

## 核心能力

- **50+ 设计风格**：glassmorphism、claymorphism、minimalism、brutalism、neumorphism、bento grid 等
- **97 色彩方案**：21 大类调色板，覆盖各行业场景
- **57 字体搭配**：经过验证的字体组合推荐
- **99 条 UX 准则**：按优先级分类的最佳实践
- **25 种图表类型**：数据可视化选型指南
- **9 个技术栈**：React、Next.js、Vue、Svelte、SwiftUI、React Native、Flutter、Tailwind、shadcn/ui

## 适用场景

- 设计新 UI 组件或页面
- 选择配色方案和排版
- 审查代码的 UX 问题
- 构建落地页、仪表盘、后台
- 实现无障碍访问要求

## 支持动作

plan / build / create / design / implement / review / fix / improve / optimize / enhance / refactor / check

## 许可

MIT
