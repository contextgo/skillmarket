---
name: svelte-sveltekit-guide
description: "Svelte and SvelteKit development guide - compile-time framework with minimal bundle size"
version: 1.0.0
tags: ["svelte", "sveltekit", "framework", "frontend", "ssr"]
---

# Svelte and SvelteKit Guide

Svelte shifts work from the browser to the build step, producing minimal JavaScript.

## Why Svelte

- **Compile-time**: No virtual DOM — generates imperative updates
- **Tiny bundles**: Minimal JS output
- **Reactive by default**: Variables auto-update DOM
- **SvelteKit**: Full-stack with SSR and file-based routing

## Svelte 5 Runes

- `$state()`: Reactive state
- `$derived()`: Computed values
- `$effect()`: Side effects
- `$props()`: Component props

## SvelteKit Routing

```
src/routes/
├── +page.svelte          # Home
├── about/+page.svelte    # /about
└── blog/[slug]/+page.svelte  # Dynamic route
```

## Performance Tips

- Use `{#await}` for async data
- Group related state with objects
- Use `transition:` for animations
