---
name: vue-nuxt-guide
description: "Vue 3 and Nuxt 3 development guide - Composition API, full-stack framework with SSR and auto-imports"
version: 1.0.0
tags: ["vue", "nuxt", "vue3", "ssr", "frontend", "framework"]
---

# Vue 3 and Nuxt 3 Guide

Vue 3 features the Composition API for better TypeScript support and logic reuse. Nuxt 3 is the full-stack meta-framework.

## Vue 3 Composition API

```vue
<script setup>
import { ref, computed, onMounted, watch } from 'vue';

const count = ref(0);
const doubled = computed(() => count.value * 2);

watch(count, (newVal) => {
  console.log('Count changed:', newVal);
});

onMounted(() => {
  console.log('Mounted!');
});
</script>

<template>
  <button @click="count++">{{ count }} (x2 = {{ doubled }})</button>
</template>
```

## Nuxt 3 Project

```bash
npx nuxi@latest init my-app
cd my-app
npm run dev
```

## Nuxt 3 Auto-Routes

```
pages/
├── index.vue          # /
├── about.vue          # /about
├── blog/
│   ├── index.vue      # /blog
│   └── [slug].vue     # /blog/:slug
└── [...slug].vue      # Catch-all route
```

## Nuxt 3 Server API

```typescript
// server/api/hello.ts
export default defineEventHandler((event) => {
  return { message: 'Hello from Nuxt!' };
});
```

## Nuxt 3 Data Fetching

```vue
<script setup>
const { data: posts, pending } = await useFetch('/api/posts');
</script>
```

## Key Features

- **Auto-imports**: Components, composables, utils auto-imported
- **Server Routes**: Built-in API routes
- **Hybrid Rendering**: SSR, SSG, SWR, ISR per route
- **Nitro Engine**: Universal server engine
- **Module Ecosystem**: Rich module system

## Best Practices

- Use `<script setup>` for all components
- Composables for reusable logic (`use*` naming)
- Use `useFetch` and `useAsyncData` for data fetching
- Leverage auto-imports (no manual imports needed)
- Use `definePageMeta` for route metadata
