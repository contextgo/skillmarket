---
name: infra-hunter
description: >
  AI 基础设施与 RL 后训练情报猎手。监控 55+ 家 AI/云/投资公司的高价值动态，
  自动评分筛选并写入飞书多维表格。支持两种模式：
  (1) ai-infra — 全品类高价值情报（产品发布、功能更新、融资并购、技术博客等）；
  (2) rl — 仅 RL/后训练相关情报。
  触发词：infra hunter、情报猎手、跑一次情报、ai-infra-watch、rl-watch、
  情报扫描、infra scan、RL 情报、AI infra 情报。
---

# Infra Hunter

AI 基础设施与 RL 后训练情报监控技能。

## 模式

| 模式 | 标识 | 关注范围 |
|---|---|---|
| **ai-infra** | `ai-infra-watch` | 全品类：产品发布、功能更新、客户案例、重大合作、技术博客、架构变化、融资并购、重要开发者更新 |
| **rl** | `rl-watch` | 仅 RL 相关：RL 产品发布、RL 功能更新、RL 客户案例、RL 重大合作、RL 技术博客、RL 架构变化、RL 融资并购、RL 重要开发者更新 |

默认模式：`ai-infra`。用户说「RL 模式」「跑 RL」时切换为 `rl`。

## 执行流程

### 1. 加载配置

1. 读取 `references/watchlist.md` 获取监控公司列表（按 `-` 行解析，忽略 `#` 注释和空行）。
2. 读取 `references/bitable-config.md` 获取飞书多维表格的 `app_token`、`table_id` 和字段映射。

### 2. 情报采集

按优先级依次检索每家公司：

1. **X (Twitter)** — `web_search` 搜索 `site:x.com "<公司名>"` 限定近 24h
2. **官网 blog / changelog** — `web_search` 搜索 `"<公司名>" blog OR changelog`，`web_fetch` 抓取正文
3. **GitHub release** — `web_search` 搜索 `site:github.com "<公司名>" release`

> 不需要把 55 家全部逐一搜索。先批量搜索高频关键词组合（如 `"AI infra" OR "model release" OR "funding" site:x.com`），锁定有新动态的公司，再针对性深挖。效率优先。

### 3. 评分与筛选

对每条情报按 **10 分制**评分：

- **9-10 分**：重大产品发布、大额融资、行业格局变化
- **8 分**：显著功能更新、重要合作、有价值的技术深度文章
- **< 8 分**：丢弃，不输出

仅保留 **≥ 8 分**结果，最多 **5 条**。

在 `rl` 模式下，所有情报必须与 RL / 后训练直接相关，否则即使高分也丢弃。

### 4. 写入飞书多维表格

对每条 ≥ 8 分的结果，调用 `feishu_bitable_create_record`：

- `app_token` 和 `table_id` 从 `references/bitable-config.md` 读取
- `fields` 按字段映射填写，`来源任务` 填当前模式标识（`rl-watch` 或 `ai-infra-watch`）

**先写表格，再输出卡片。**

### 5. 输出格式

每条结果输出固定卡片：

```
🏢 公司：<公司名>
📂 类型：<类型>
⭐ 评分：<N>/10
🕐 发布时间：<时间>
📡 来源：<平台>
📌 标题：<标题>
📝 摘要：<摘要>
🔗 源链接：<URL>
💬 小新点评：<一句话点评>
```

如果本次窗口无 ≥ 8 分结果，输出：

```
本次窗口无高价值动态。
```

## 禁止事项

- 禁止输出检索过程或中间步骤
- 禁止说「继续查」「继续深挖」「稍后返回」
- 禁止编造不存在的信息
- 禁止重复汇报已写入表格的旧条目（可先查表格最近记录去重）

## 输出通道

结果通过飞书 DM 推送。cron 任务配置 `delivery.channel = "feishu"`。
