# Watchlist — 监控公司/机构列表

> 增删公司直接编辑此文件，每行一个，`#` 开头为注释。

## 海外 AI Infra / 云服务
- Fireworks.ai
- Together.ai
- Anyscale
- ServiceNow
- Scale AI
- Nebius
- Lambda
- Baseten
- DeepInfra
- Friendli
- Novita
- Cerebras
- Groq
- SambaNova
- VAST
- BentoML

## 国内云厂商
- 阿里云
- 腾讯云
- 百度云

## 海外云厂商
- AWS
- Azure
- 谷歌云

## 大模型 / AI 公司
- OpenAI
- Anthropic
- 字节跳动/抖音
- 阶跃星辰
- Grasp
- 月之暗面/Kimi
- 智谱
- Minimax
- Character.ai

## AI 应用 / 工具
- Kuse.ai
- Junior.so
- Sheet0
- Wanaka
- Dify/Dify.AI
- Lessie AI
- OpusClip
- Palona AI
- Clockless.ai
- Mercor
- ACE Studio
- 心影随形
- Pokee AI
- Gru.ai

## 投资机构
- 绿洲资本
- Leonis Capital
- 云磬投资
- 创新工场

## 其他
- PingCAP
- 地平线
- 理想汽车
- 高途
- 心识宇宙
- 清华大学交叉信息研究院
