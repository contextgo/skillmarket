# 飞书多维表格配置

> 修改此文件即可切换写入目标，无需改动 SKILL.md。

| 参数 | 值 |
|---|---|
| app_token | DeMHbeVI7a4xiWsJEEXcgsG3n7d |
| table_id | tblWWncCRsumnP5q |

## 字段映射

写入 `feishu_bitable_create_record` 时使用以下 fields：

| 字段名 | 说明 | 示例 |
|---|---|---|
| 来源任务 | 填当前模式标识：`rl-watch` 或 `ai-infra-watch` | `rl-watch` |
| 公司 | 公司/机构名称 | `OpenAI` |
| 类型 | 信息类型 | `产品发布` |
| 评分 | 10 分制整数 | `9` |
| 标题 | 信息标题 | `GPT-5 发布` |
| 摘要 | 一段话摘要 | `OpenAI 正式发布 GPT-5…` |
| 来源 | 来源平台 + 链接 | `X https://x.com/…` |
| 发布时间 | 原始发布时间 | `2026-04-02` |
