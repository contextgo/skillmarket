---
name: monthly-target-drift-analyzer
description: "Analyze when monthly prediction market price targets drift while spot prices remain stable, indicating time-constraint reassessment"
version: 1.0.0
type: skill
tags: prediction-market, monthly-target, drift, btc, commodity
---

# Monthly Target Drift Analyzer

Distinguishes between time-constraint drift (calendar math) and directional shift (market view change) when prediction market monthly targets decline while spot prices are stable.

## Core Concept

When a monthly prediction market target declines but the spot price is stable, the market is NOT becoming bearish — it's recalculating whether the target is achievable in the remaining time.

## Drift Classification

```python
def classify_drift(target_change, spot_change, days_remaining, target_distance_pct):
    if spot_change > -1.0:  # spot stable or rising
        if target_change < -2.0:  # target declining significantly
            required_daily = target_distance_pct / days_remaining
            # If required daily return exceeds historical average → time_constraint_drift
            return "time_constraint_drift"
        return "minor_adjustment"
    else:  # spot declining
        return "directional_shift"  # actual bearish signal
```

## Three Resolution Paths

| Path | Probability | Description |
|------|-------------|-------------|
| Spot breaks higher | ~25% | Catalyst triggers rally to target |
| Target converges to spot | ~50% | Market accepts lower outcome |
| Spot drops to target | ~25% | Bearish confirmation |

## Case Study: BTC $75K March 2026

- **Spot**: Stable at $70,700-70,800 (no decline)
- **Target PM**: Declined 63% → 59.5% over 4 rounds (-3.5%)
- **Days remaining**: 17
- **Required rally**: 6% (0.35%/day)
- **Historical daily return**: 0.1-0.2% during fear period
- **Classification**: `time_constraint_drift` (not bearish)

## Application

The analyzer helps avoid two common errors:
1. **False bearish**: Selling because monthly target declined (when it's just calendar math)
2. **False bullish**: Buying because spot is stable (when monthly window is closing)

**Correct action**: Hold existing positions, reduce size on time_constraint_drift, do not add.

## Integration

Monitor Gamma API for multi-timeframe markets. When daily PM stable but monthly PM declining, flag as time_constraint_drift and adjust position sizing accordingly.
