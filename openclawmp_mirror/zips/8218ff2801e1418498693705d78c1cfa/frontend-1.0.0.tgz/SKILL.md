---
name: frontend
description: 前端开发工具，提供HTML/CSS/JavaScript开发辅助功能
author: OpenClaw Community
version: 1.0.0
tags: [frontend, web, development, html, css, javascript]
---

# Frontend Development Skill

前端开发技能，提供网页开发相关的辅助工具和功能。

## 功能特性

- HTML代码生成和优化
- CSS样式设计和调试
- JavaScript代码辅助
- 响应式设计检查
- 浏览器兼容性检查

## 使用方法

待补充详细使用说明。

## 技术栈支持

- HTML5
- CSS3 (包括Flexbox, Grid)
- JavaScript (ES6+)
- 主流前端框架参考

## 注意事项

- 代码需要根据具体项目需求调整
- 建议在实际浏览器中测试效果