---
name: feature-flag
description: 特性开关助手。用于管理功能开关、配置灰度发布、控制功能曝光。当需要管理功能开关、灰度发布时触发。
---

# 特性开关助手

## 开关类型

| 类型 | 说明 | 示例 |
|------|------|------|
| 永久开关 | 永久启用/禁用 | 旧功能清理 |
| 发布开关 | 控制新功能发布 | 新功能灰度 |
| 实验开关 | A/B测试 | 特性实验 |
| 运维开关 | 紧急开关 | 降级熔断 |

## 开关设计

```markdown
## 开关模型

### 开关配置
| 字段 | 类型 | 说明 |
|------|------|------|
| key | string | 开关唯一标识 |
| name | string | 开关名称 |
| type | enum | 发布/实验/运维 |
| enabled | boolean | 是否启用 |
| default_value | boolean | 默认值 |
| rollout_percentage | int | 灰度比例 |
| target_users | list | 目标用户 |
| target_regions | list | 目标地区 |

### 开关规则
```
优先级：target_users > target_regions > rollout_percentage > default_value
```

## 开关管理

### 创建开关
```json
{
  "key": "new_checkout_flow",
  "name": "新版结账流程",
  "type": "release",
  "description": "新版结账流程灰度发布",
  "enabled": true,
  "rollout_percentage": 10,
  "created_at": "2024-01-01",
  "updated_at": "2024-01-01"
}
```

### 开关更新
```json
{
  "rollout_percentage": 50,
  "updated_at": "2024-01-15"
}
```

## 代码集成

### Java示例
```java
@Configuration
public class FeatureConfig {
    
    @Value("${feature.new-checkout-flow:false}")
    private boolean newCheckoutFlow;
    
    @Bean
    public FeatureFlagService featureFlagService() {
        return new FeatureFlagService();
    }
}

// 使用开关
@Service
public class CheckoutService {
    
    @Autowired
    private FeatureFlagService featureFlag;
    
    public void checkout() {
        if (featureFlag.isEnabled("new_checkout_flow")) {
            // 新版结账流程
            newCheckout();
        } else {
            // 旧版结账流程
            oldCheckout();
        }
    }
}
```

### Node.js示例
```javascript
// 使用LaunchDarkly SDK
const LaunchDarkly = require('launchdarkly-node-server-sdk');

const client = LaunchDarkly.init('sdk-key');

client.on('ready', () => {
  const flagValue = client.variation('new-checkout-flow', {
    key: 'user123'
  }, false);
  
  if (flagValue) {
    // 新版逻辑
  } else {
    // 旧版逻辑
  }
});
```

### 中间件示例
```javascript
// Express中间件
app.use('/checkout', (req, res, next) => {
  const userId = req.user.id;
  const enableNewFlow = featureFlags.isEnabled('new_checkout_flow', userId);
  
  if (enableNewFlow) {
    req.checkoutVersion = 'new';
  } else {
    req.checkoutVersion = 'old';
  }
  
  next();
});
```

## 灰度策略

### 用户分群
```markdown
| 分群 | 策略 | 比例 |
|------|------|------|
| 内测用户 | 指定用户ID | 100% |
| VIP用户 | 用户等级=VIP | 100% |
| 白名单 | 指定用户 | 100% |
| 随机用户 | 按百分比 | 10%→30%→50%→100% |
```

### 灰度节奏
```markdown
| 阶段 | 时间 | 范围 | 观察重点 |
|------|------|------|----------|
| Day 1 | 第1天 | 5% | 核心指标 |
| Day 3 | 第3天 | 20% | +性能指标 |
| Day 7 | 第7天 | 50% | +业务指标 |
| Day 14 | 第14天 | 100% | 全量验证 |
```

## 开关管理界面设计

```markdown
## 开关管理控制台

┌────────────────────────────────────────────────────┐
│  特性开关管理                              [+ 新建] │
├────────────────────────────────────────────────────┤
│  搜索：__________  类型：全部 ▼  状态：全部 ▼    │
├────────────────────────────────────────────────────┤
│  开关名称          │ 类型 │ 状态 │ 灰度比例 │ 操作│
├────────────────────────────────────────────────────┤
│  new_checkout_flow │ 发布 │ 启用 │   50%    │ 编辑│
│  ai_recommendation │ 发布 │ 启用 │   20%    │ 编辑│
│  dark_mode         │ 发布 │ 禁用 │    0%    │ 编辑│
│  emergency_mode     │ 运维 │ 禁用 │    0%    │ 编辑│
└────────────────────────────────────────────────────┘

## 开关详情
┌────────────────────────────────────────────────────┐
│  new_checkout_flow                          [编辑] │
├────────────────────────────────────────────────────┤
│  名称：新版结账流程                                  │
│  类型：发布开关                                      │
│  状态：启用                                        │
│  灰度比例：50%                                     │
│  创建时间：2024-01-01                              │
│  更新时间：2024-01-15                              │
├────────────────────────────────────────────────────┤
│  规则配置                                          │
│  ├─ 白名单用户：user123, user456                   │
│  ├─ 排除用户：test_user                           │
│  └─ 地区限制：无                                   │
├────────────────────────────────────────────────────┤
│  使用统计                                          │
│  ├─ 总请求：10,000                                 │
│  ├─ 开关触发：5,000 (50%)                         │
│  └─ 错误率：0.1%                                  │
├────────────────────────────────────────────────────┤
│  操作日志                                          │
│  ├─ 2024-01-15 14:00  灰度比例 30%→50%  @admin │
│  └─ 2024-01-10 10:00  灰度比例 10%→30%  @admin  │
└────────────────────────────────────────────────────┘
```

## 监控指标

```markdown
## 开关监控

| 指标 | 告警阈值 |
|------|----------|
| 开关触发错误率 | > 1% |
| 开关响应时间 | > 10ms |
| 配置同步延迟 | > 1分钟 |
| 开关覆盖用户 | < 预期80% |
```
