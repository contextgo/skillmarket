# PDF to Markdown 转换工具

把 PDF 变成可读、可检索、可继续加工的 Markdown 语料。

这个技能面向两类常见场景：
- 资料沉淀：把报告/书籍/课程讲义从 PDF 转成可长期维护的 Markdown 知识库
- AI 工作流：把原始 PDF 清洗成更适合 LLM 检索与引用的文本格式

## 解决的问题

- 扫描版 PDF 直接不可检索，需要 OCR 才能用
- 文字版 PDF 提取后常混有页眉页脚、链接、水印等噪音
- 大文档难拆分，后续很难做主题化引用和索引

## 核心能力

- 扫描版 PDF：基于 macOS Vision 框架做 OCR 转录
- 文字版 PDF：直接抽取文本，速度快
- 按章节拆分：把长文档拆成多份 Markdown 文件
- 目录索引：自动生成结构化索引，便于后续检索
- 后处理清理：按规则批量去除噪音内容

## 快速开始

1. 准备转换脚本：复制 `template.py` 并填写路径和参数
2. 根据文档类型设置：`USE_OCR=True/False`
3. 运行转换并检查输出质量
4. 用 `post_processing.py` 执行清理规则

## 适用人群

- 经常处理 PDF 资料的研究/内容/知识管理工作流
- 需要把 PDF 语料喂给 Agent 或 RAG 系统的人
- 需要章节级切分、索引与批量清洗的场景

## 文件入口

- `instructions.md`: 完整流程说明
- `QUICKSTART.md`: 最短上手路径
- `template.py`: 转换模板
- `post_processing.py`: 后处理清理工具
- `OPTIMIZE_FOR_AI.md`: 面向 AI 检索的结构化优化建议