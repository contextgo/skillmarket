# Natural Language Processing Guide

## Overview
NLP 核心技术栈，从基础文本处理到高级语义分析。

## Text Preprocessing Pipeline

```python
import re
from collections import Counter

def preprocess(text):
    # 1. Normalize
    text = text.lower().strip()
    # 2. Remove URLs/emails
    text = re.sub(r'https?://\S+|@\S+', '', text)
    # 3. Tokenize (simple word split)
    tokens = re.findall(r'\b\w+\b', text)
    # 4. Remove stopwords
    stopwords = {'the', 'a', 'an', 'is', 'are', 'was', 'were', 'in', 'on', 'at', 'to'}
    tokens = [t for t in tokens if t not in stopwords]
    # 5. Lemmatize (simplified)
    tokens = [t.rstrip('s') if t.endswith('s') else t for t in tokens]
    return tokens
```

## TF-IDF Scoring (Practical)

```python
import math

def tfidf(documents, query_tokens):
    """Simple TF-IDF implementation for signal matching"""
    N = len(documents)
    
    # Document frequency
    df = Counter()
    for doc in documents:
        unique_terms = set(doc.lower().split())
        for term in query_tokens:
            if term in unique_terms:
                df[term] += 1
    
    # Score each document
    scores = []
    for i, doc in enumerate(documents):
        score = 0
        doc_tokens = doc.lower().split()
        doc_len = len(doc_tokens)
        
        for term in query_tokens:
            tf = doc_tokens.count(term) / doc_len  # Term Frequency
            idf = math.log(N / (1 + df.get(term, 0)))  # Inverse Document Frequency
            score += tf * idf
        
        scores.append((i, score))
    
    return sorted(scores, key=lambda x: x[1], reverse=True)
```

## Named Entity Recognition (Simple Rule-Based)
```python
import re

def extract_entities(text):
    patterns = {
        'money': r'\$[\d,.]+[KkMmBb]?|\d+(?:\.\d+)?(?:\s*(?:dollars?|USD|btc))',
        'percentage': r'\d+(?:\.\d+)?%',
        'date': r'\d{1,2}[/-]\d{1,2}[/-]\d{2,4}|\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)\w*\s+\d{1,2}',
        'organization': r'\b(?:Fed|SEC|CFTC|JPMorgan|Goldman|BlackRock|Binance|Coinbase)\w*\b',
        'crypto': r'\b(?:BTC|ETH|SOL|XRP|BNB|DOGE)\b',
    }
    
    entities = {}
    for entity_type, pattern in patterns.items():
        entities[entity_type] = re.findall(pattern, text, re.IGNORECASE)
    return entities
```

## Sentiment Analysis (Lexicon-Based)
```python
POSITIVE = {'surge', 'rally', 'breakthrough', 'bullish', 'gain', 'jump', 'soar'}
NEGATIVE = {'crash', 'plunge', 'drop', 'bearish', 'fall', 'slump', 'fear'}

def sentiment_score(text):
    tokens = set(text.lower().split())
    pos = len(tokens & POSITIVE)
    neg = len(tokens & NEGATIVE)
    total = max(pos + neg, 1)
    return (pos - neg) / total  # Range: -1 to 1
```

## Text Summarization (Extractive)
```python
def summarize(text, num_sentences=3):
    sentences = re.split(r'[.!?]+', text)
    sentences = [s.strip() for s in sentences if len(s.strip()) > 20]
    
    # Score by sentence position + keyword frequency
    scores = []
    for i, sent in enumerate(sentences):
        position_score = 1.0 if i < 3 else 0.5  # First 3 sentences get boost
        length_score = min(len(sent.split()) / 20, 1.0)
        scores.append((i, position_score * 0.6 + length_score * 0.4))
    
    top_indices = sorted(scores, key=lambda x: x[1], reverse=True)[:num_sentences]
    return '. '.join(sentences[i] for i, _ in sorted(top_indices))
```

## Practical Application: News Signal Extraction
Combine TF-IDF + NER + Sentiment for a lightweight news signal pipeline:
1. TF-IDF ranks relevance to target topics
2. NER extracts key entities (prices, percentages, orgs)
3. Sentiment classifies directional bias
4. Combined score determines signal strength