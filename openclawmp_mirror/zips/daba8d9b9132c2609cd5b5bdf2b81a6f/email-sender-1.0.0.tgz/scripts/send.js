#!/usr/bin/env node

/**
 * Email Sender Script
 * Send emails via SMTP with support for text, HTML, attachments, and multiple recipients.
 */

const nodemailer = require('nodemailer');
const fs = require('fs');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '../.env') });

// Parse command line arguments
function parseArgs(args) {
  const result = {};
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--to' && args[i + 1]) {
      result.to = args[++i].split(',').map(s => s.trim());
    } else if (arg === '--cc' && args[i + 1]) {
      result.cc = args[++i].split(',').map(s => s.trim());
    } else if (arg === '--bcc' && args[i + 1]) {
      result.bcc = args[++i].split(',').map(s => s.trim());
    } else if (arg === '--subject' && args[i + 1]) {
      result.subject = args[++i];
    } else if (arg === '--body' && args[i + 1]) {
      result.body = args[++i];
    } else if (arg === '--body-file' && args[i + 1]) {
      result.bodyFile = args[++i];
    } else if (arg === '--html') {
      result.html = true;
    } else if (arg === '--attach' && args[i + 1]) {
      result.attachments = args[++i].split(',').map(s => s.trim());
    } else if (arg === '--from' && args[i + 1]) {
      result.from = args[++i];
    } else if (arg === '--help' || arg === '-h') {
      result.help = true;
    }
  }
  return result;
}

function showHelp() {
  console.log(`
📧 Email Sender - Send emails via SMTP

Usage:
  node scripts/send.js --to <email> --subject <text> [options]

Required:
  --to <email>        Recipient(s), comma-separated for multiple
  --subject <text>    Email subject

Options:
  --body <text>       Plain text body content
  --html              Treat body as HTML
  --body-file <file>  Read body content from file
  --cc <email>        CC recipient(s)
  --bcc <email>       BCC recipient(s)
  --attach <files>    Attachment(s), comma-separated
  --from <email>      Override default sender address
  --help, -h          Show this help message

Examples:
  # Simple text email
  node scripts/send.js --to user@example.com --subject "Hello" --body "World"

  # HTML email
  node scripts/send.js --to user@example.com --subject "Newsletter" --html --body "<h1>Welcome</h1>"

  # With attachment
  node scripts/send.js --to user@example.com --subject "Report" --body "Please find attached" --attach report.pdf

  # Multiple recipients with CC
  node scripts/send.js --to "a@example.com,b@example.com" --cc "c@example.com" --subject "Meeting" --body "Tomorrow 3pm"
`);
}

// Create SMTP transporter
function createTransporter() {
  const config = {
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: parseInt(process.env.SMTP_PORT) || 587,
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  };

  // For port 465, secure should be true
  if (config.port === 465) {
    config.secure = true;
  }

  return nodemailer.createTransport(config);
}

// Send email
async function sendEmail(options) {
  const transporter = createTransporter();

  // Read body from file if specified
  let text = options.body;
  let html = options.html ? options.body : undefined;

  if (options.bodyFile) {
    const bodyPath = path.isAbsolute(options.bodyFile)
      ? options.bodyFile
      : path.join(process.cwd(), options.bodyFile);
    const content = fs.readFileSync(bodyPath, 'utf-8');
    if (options.html) {
      html = content;
    } else {
      text = content;
    }
  }

  // Prepare attachments
  const attachments = options.attachments?.map(file => ({
    filename: path.basename(file),
    path: path.isAbsolute(file) ? file : path.join(process.cwd(), file)
  }));

  const mailOptions = {
    from: options.from || process.env.SMTP_FROM || process.env.SMTP_USER,
    to: options.to.join(', '),
    cc: options.cc?.join(', '),
    bcc: options.bcc?.join(', '),
    subject: options.subject,
    text: text,
    html: html,
    attachments: attachments || []
  };

  try {
    const info = await transporter.sendMail(mailOptions);
    console.log(`✅ Email sent successfully!`);
    console.log(`   Message ID: ${info.messageId}`);
    if (info.accepted.length > 0) {
      console.log(`   Accepted: ${info.accepted.join(', ')}`);
    }
    if (info.rejected.length > 0) {
      console.log(`   Rejected: ${info.rejected.join(', ')}`);
    }
    return info;
  } catch (error) {
    console.error(`❌ Failed to send email: ${error.message}`);
    if (error.responseCode) {
      console.error(`   SMTP Error ${error.responseCode}: ${error.response}`);
    }
    throw error;
  }
}

// Main
async function main() {
  const args = parseArgs(process.argv.slice(2));

  if (args.help) {
    showHelp();
    process.exit(0);
  }

  // Validate required arguments
  if (!args.to || args.to.length === 0) {
    console.error('❌ Error: --to is required');
    showHelp();
    process.exit(1);
  }

  if (!args.subject) {
    console.error('❌ Error: --subject is required');
    showHelp();
    process.exit(1);
  }

  if (!args.body && !args.bodyFile) {
    console.error('❌ Error: --body or --body-file is required');
    showHelp();
    process.exit(1);
  }

  // Validate SMTP configuration
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.error('❌ Error: SMTP configuration missing in .env file');
    console.error('   Required: SMTP_HOST, SMTP_USER, SMTP_PASS');
    console.error('   See .env.example for template');
    process.exit(1);
  }

  try {
    await sendEmail(args);
  } catch (error) {
    process.exit(1);
  }
}

main();
