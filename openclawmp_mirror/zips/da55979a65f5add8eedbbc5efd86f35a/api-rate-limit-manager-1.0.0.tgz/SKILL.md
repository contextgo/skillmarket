---
name: api-rate-limit-manager
description: "Track, budget, and optimize API rate limits across multiple services for 24/7 agent operations"
version: 1.0.0
---

# API Rate Limit Manager

Track and optimize API quota usage across all services consumed by an AI agent system running 24/7.

## When to Use

- When running multiple concurrent jobs that share API quotas
- When you need to prevent one job from exhausting a shared budget
- When daily API limits are a bottleneck for continuous operations

## Process

### Step 1: Inventory APIs
List all external APIs consumed:
```
| API | Daily Limit | Current Usage | Reset Time | Priority |
|-----|-----------|---------------|------------|----------|
| web_search | 400 | ~200 | 00:00 UTC | High |
| OpenClaw API | Unlimited | ~500 | N/A | Medium |
| EvoMap API | ~100 | ~30 | N/A | Low |
| News sources | Unlimited | ~300 | N/A | High |
```

### Step 2: Budget Allocation
Divide daily quotas across jobs:
```
Total web_search budget: 400/day
- Polymarket sniper (15 runs × 5 min): 300 (75%)
- Stock analysis (1 run): 50 (12.5%)
- Skill discovery (1 run): 50 (12.5%)
```

### Step 3: Detection
When quota is exhausted (HTTP 402/429):
1. **Log the exhaustion** with timestamp
2. **Switch to fallback** (e.g., web_fetch instead of web_search)
3. **Notify dependent jobs** to use alternatives
4. **Schedule recovery** for next reset period

### Step 4: Optimization
- Cache repeated identical queries
- Batch related requests
- Use cheaper alternatives when precision isn't critical
- Prioritize high-value queries

## Error Code Reference

| Code | Meaning | Action |
|------|---------|--------|
| 402 | Payment Required | Quota exhausted, switch to fallback |
| 429 | Too Many Requests | Rate limited, add delay |
| 403 | Forbidden | Anti-scraping, change approach |
| 413 | Payload Too Large | Reduce request size |
| 503 | Service Unavailable | Retry with backoff |

## Budget Tracking Template

Maintain a simple counter file:
```json
{
  "web_search": {"used": 200, "limit": 400, "reset": "2026-03-14T00:00:00Z"},
  "evomap": {"used": 30, "limit": 100, "reset": null}
}
```

Update after each API call. Check before making new calls.
