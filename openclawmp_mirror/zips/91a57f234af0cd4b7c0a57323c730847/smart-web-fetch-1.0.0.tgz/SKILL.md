---
name: smart-web-fetch
description: 智能网页抓取系统，自动识别网页类型并选择最佳抓取策略，支持文章、API文档、新闻、博客等多种类型
version: 1.0.0
---

# Smart Web Fetch 智能网页抓取

组合 defuddle + summarize + 自定义规则，实现智能网页内容提取。

## 🎯 核心功能

1. **自动识别网页类型**：
   - 📰 新闻/文章（提取标题、正文、作者、日期）
   - 📚 API 文档（提取 API 端点、参数、示例）
   - 📝 博客/技术文章（提取代码块、要点）
   - 🛒 产品页面（提取价格、规格、评价）
   - 🔬 学术论文（提取摘要、引用、关键数据）

2. **智能抓取策略**：
   - 优先使用 defuddle（去除广告/导航）
   - 自动检测内容语言
   - 提取结构化数据（表格、列表、代码）
   - 保留重要元数据（作者、日期、标签）

3. **多格式输出**：
   - Markdown（默认）
   - JSON（结构化数据）
   - 纯文本（简单场景）
   - 摘要（长内容）

## 📦 依赖技能

- ✅ `defuddle` - 提取干净内容
- ✅ `summarize` - 总结长内容

## 🚀 使用方法

### 1. 基础用法

```bash
# 抓取文章（自动识别类型）
smart-web-fetch <url>

# 示例
smart-web-fetch https://example.com/blog/post

# 输出：Markdown 格式，包含标题、正文、元数据
```

### 2. 指定输出格式

```bash
# JSON 格式（结构化）
smart-web-fetch <url> --json

# 纯摘要
smart-web-fetch <url> --summary

# 完整内容（包括所有元数据）
smart-web-fetch <url> --full
```

### 3. 指定内容类型

```bash
# 强制按新闻格式抓取
smart-web-fetch <url> --type news

# 强制按 API 文档格式抓取
smart-web-fetch <url> --type api

# 强制按博客格式抓取
smart-web-fetch <url> --type blog
```

### 4. 保存到文件

```bash
# 保存为 Markdown
smart-web-fetch <url> -o article.md

# 保存为 JSON
smart-web-fetch <url> --json -o data.json
```

## 🎨 抓取策略

### 策略 1：新闻/文章
```bash
defuddle parse <url> --md | \
  extract-metadata --fields title,author,date,keywords | \
  summarize --max-length 500
```

**输出示例**：
```markdown
# 标题：OpenAI 发布 GPT-5

**作者**: John Doe  
**日期**: 2026-03-05  
**关键词**: AI, GPT, OpenAI

## 摘要
OpenAI 今日发布 GPT-5，性能相比 GPT-4 提升 200%...

## 正文
[完整内容]
```

### 策略 2：API 文档
```bash
defuddle parse <url> --md | \
  extract-code-blocks | \
  extract-api-endpoints | \
  format-json
```

**输出示例**：
```json
{
  "endpoints": [
    {
      "method": "GET",
      "path": "/api/users",
      "parameters": [
        {"name": "limit", "type": "integer", "required": false}
      ],
      "example": "curl -X GET https://api.example.com/users"
    }
  ]
}
```

### 策略 3：技术博客
```bash
defuddle parse <url> --md | \
  extract-code-blocks --language python | \
  extract-headings | \
  summarize --max-length 300
```

## 🔧 配置

### 自定义抓取规则

编辑 `config/smart-web-fetch.yaml`：

```yaml
# 网页类型识别规则
type_detection:
  news:
    keywords:
      - "新闻"
      - "news"
      - "报道"
    domains:
      - "news.ycombinator.com"
      - "bbc.com"
  
  api:
    keywords:
      - "API"
      - "endpoint"
      - "参数"
    domains:
      - "docs.openai.com"
      - "developer.mozilla.org"

# 输出格式配置
output:
  max_summary_length: 500
  include_metadata: true
  include_code_blocks: true
  preserve_links: true
```

## 📊 性能对比

| 工具 | 速度 | 准确性 | 结构化 | 摘要 |
|------|------|--------|--------|------|
| **WebFetch** | ⚡⚡⚡ | ⭐⭐⭐ | ❌ | ❌ |
| **Defuddle** | ⚡⚡⚡ | ⭐⭐⭐⭐ | ❌ | ❌ |
| **Smart Web Fetch** | ⚡⚡ | ⭐⭐⭐⭐⭐ | ✅ | ✅ |

## 🎯 使用场景

### 场景 1：每日新闻摘要
```bash
# 抓取多个新闻源
smart-web-fetch https://news.ycombinator.com --type news -o hn.md
smart-web-fetch https://www.bbc.com/news/technology --type news -o bbc.md

# 合并成日报
cat hn.md bbc.md | summarize --max-length 1000 > daily_news.md
```

### 场景 2：API 文档整理
```bash
# 抓取 API 文档
smart-web-fetch https://docs.openai.com/api --type api --json -o openai_api.json

# 生成客户端代码
openclaw generate-client openai_api.json --language python
```

### 场景 3：技术博客归档
```bash
# 抓取博客文章
smart-web-fetch https://blog.example.com/post --type blog -o blog.md

# 提取代码示例
extract-code blog.md --language python > examples.py
```

## ⚙️ 高级功能

### 1. 批量抓取
```bash
# 从文件读取 URL 列表
cat urls.txt | xargs -I {} smart-web-fetch {} --summary
```

### 2. 增量更新
```bash
# 只抓取更新的内容
smart-web-fetch <url> --since yesterday
```

### 3. 智能缓存
```bash
# 使用缓存（24 小时）
smart-web-fetch <url> --cache 24h
```

## 🔗 集成示例

### 与飞书集成
```bash
# 抓取并推送到飞书
smart-web-fetch <url> | \
  openclaw message send --channel feishu --target "user:ou_xxx"
```

### 与 Obsidian 集成
```bash
# 抓取并保存到 Obsidian
smart-web-fetch <url> -o ~/obsidian-vault/notes/article.md
```

## 📝 脚本位置

- **主脚本**: `~/.openclaw/workspace/scripts/smart_web_fetch.sh`
- **配置文件**: `~/.openclaw/workspace/config/smart-web-fetch.yaml`
- **缓存目录**: `~/.openclaw/workspace/temp/smart-web-fetch-cache/`

## 🐛 故障排查

### 问题 1：抓取失败
```bash
# 检查 URL 是否可访问
curl -I <url>

# 使用代理
smart-web-fetch <url> --proxy http://host.docker.internal:7890
```

### 问题 2：内容不完整
```bash
# 使用 --full 强制抓取完整内容
smart-web-fetch <url> --full
```

### 问题 3：编码问题
```bash
# 指定编码
smart-web-fetch <url> --encoding utf-8
```

## 💡 最佳实践

1. **优先使用 defuddle**：对于标准网页，defuddle 已经足够好
2. **按需使用摘要**：长内容使用 `--summary` 节省 token
3. **保存原始内容**：重要内容使用 `--full` 保存完整版
4. **定期清理缓存**：`rm -rf ~/.openclaw/workspace/temp/smart-web-fetch-cache/*`

## 🔄 更新日志

### v1.0.0 (2026-03-05)
- ✅ 初始版本
- ✅ 支持 5 种网页类型
- ✅ 自动识别和策略选择
- ✅ 集成 defuddle + summarize

## 📚 相关技能

- `defuddle` - 网页内容提取
- `summarize` - 内容总结
- `http-retry-skill` - 网络重试
- `browser-automation` - 复杂网页抓取

---

**需要帮助？** 回复 "帮助 smart-web-fetch" 或查看 `~/.openclaw/workspace/scripts/smart_web_fetch.sh`
