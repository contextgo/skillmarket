#!/usr/bin/env python3
"""
StepFun Desktop Activity Context Search
Searches local summary JSON files by keywords and returns structured context.

Usage:
    python3 search_context.py --keywords kw1 kw2 [--days N]

Output:
    JSON array of matched context items.
"""

import argparse
import json
import os
import sys
from pathlib import Path

SUMMARY_BASE_DIR_DEFAULT = os.path.expanduser(
    "~/Library/Application Support/stepfun-desktop/desktop-share/summary"
)

IMAGEINFO_WEIGHT = 2
OTHER_WEIGHT = 1

TOP_SINGLE = 5
TOP_MULTI_PER_KW = 3


def get_base_dir() -> Path:
    env_val = os.environ.get("SUMMARY_BASE_DIR", "")
    if env_val:
        return Path(env_val)
    # Try loading from .env in cwd
    env_file = Path(os.getcwd()) / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line.startswith("SUMMARY_BASE_DIR="):
                val = line.split("=", 1)[1].strip().strip('"').strip("'")
                if val:
                    return Path(val)
    return Path(SUMMARY_BASE_DIR_DEFAULT)


def collect_json_files(base_dir: Path, days: int | None) -> list[Path]:
    if not base_dir.exists():
        return []
    day_dirs = sorted(
        [d for d in base_dir.iterdir() if d.is_dir() and d.name.isdigit()],
        reverse=True,
    )
    if days is not None:
        day_dirs = day_dirs[:days]
    files = []
    for day_dir in day_dirs:
        files.extend(sorted(day_dir.glob("*.json")))
    return files


def score_record(record: dict, keywords: list[str]) -> tuple[int, set[str]]:
    """Return (total_score, matched_keywords_set) for a screenImage record."""
    matched = set()
    score = 0
    image_info = (record.get("imageInfo") or "").lower()
    front_app = (record.get("frontApp") or "").lower()
    window_title = (record.get("windowTitle") or "").lower()

    for kw in keywords:
        kw_lower = kw.lower()
        if kw_lower in image_info:
            matched.add(kw)
            score += IMAGEINFO_WEIGHT
        elif kw_lower in front_app or kw_lower in window_title:
            matched.add(kw)
            score += OTHER_WEIGHT

    return score, matched


def search(keywords: list[str], days: int | None) -> list[dict]:
    base_dir = get_base_dir()
    files = collect_json_files(base_dir, days)

    if not files:
        return []

    # key: (file_path, timestamp) -> result dict
    candidates: dict[tuple, dict] = {}

    for file_path in files:
        try:
            with open(file_path, encoding="utf-8") as f:
                data = json.load(f)
        except (json.JSONDecodeError, OSError):
            continue

        file_title = data.get("title", "")
        file_summary = data.get("summary", "")
        file_start = data.get("startTime", "")
        file_end = data.get("endTime", "")
        aux_text = f"{file_title} {file_summary}".lower()

        screen_images = data.get("screenImages") or []
        for img in screen_images:
            img_score, img_matched = score_record(img, keywords)

            # Also check aux fields for this file
            aux_matched = set()
            if img_score == 0:
                for kw in keywords:
                    if kw.lower() in aux_text:
                        aux_matched.add(kw)
                if not aux_matched:
                    continue
                aux_score = len(aux_matched) * OTHER_WEIGHT
            else:
                aux_score = 0

            total_matched = img_matched | aux_matched
            total_score = img_score + aux_score

            key = (str(file_path), img.get("timestamp", ""))
            existing = candidates.get(key)
            if existing is None or total_score > existing["score"]:
                candidates[key] = {
                    "file": str(file_path),
                    "startTime": file_start,
                    "endTime": file_end,
                    "timestamp": img.get("timestamp", ""),
                    "matchedKeywords": list(total_matched),
                    "score": total_score,
                    "imageInfo": img.get("imageInfo", ""),
                    "frontApp": img.get("frontApp", ""),
                    "windowTitle": img.get("windowTitle", ""),
                }

    if not candidates:
        return []

    all_items = list(candidates.values())

    if len(keywords) == 1:
        all_items.sort(key=lambda x: x["score"], reverse=True)
        result = all_items[:TOP_SINGLE]
    else:
        # Per-keyword top 3, then merge & dedup
        seen_keys = set()
        result = []
        for kw in keywords:
            kw_items = [
                item for item in all_items if kw in item["matchedKeywords"]
            ]
            kw_items.sort(key=lambda x: x["score"], reverse=True)
            for item in kw_items[:TOP_MULTI_PER_KW]:
                dedup_key = (item["file"], item["timestamp"])
                if dedup_key not in seen_keys:
                    seen_keys.add(dedup_key)
                    result.append(item)

    return result


def main():
    parser = argparse.ArgumentParser(
        description="Search StepFun desktop activity context by keywords"
    )
    parser.add_argument(
        "--keywords", nargs="+", required=True, help="Keywords to search for"
    )
    parser.add_argument(
        "--days",
        type=int,
        default=None,
        help="Limit search to most recent N days (default: all)",
    )
    args = parser.parse_args()

    results = search(args.keywords, args.days)
    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
