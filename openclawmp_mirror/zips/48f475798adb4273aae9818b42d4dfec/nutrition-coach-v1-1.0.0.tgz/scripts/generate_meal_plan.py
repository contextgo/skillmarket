#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全能营养教练 - 饮食计划生成器
根据用户目标和条件生成个性化饮食方案
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict


@dataclass
class UserProfile:
    """用户档案"""
    gender: str
    age: int
    height_cm: float
    weight_kg: float
    goal: str  # fat_loss/muscle_gain/maintenance/health
    activity_level: str  # sedentary/light/moderate/active/very_active
    target_weight_kg: Optional[float] = None
    diet_type: str = "普通"  # 普通/素食/纯素/生酮/低碳
    cuisine_preference: str = "中餐"  # 中餐/西餐/日料/混合
    cooking_capability: str = "自己做饭"  # 自己做饭/外卖/食堂/混合
    cooking_time: int = 30  # 每餐可用时间（分钟）
    food_preferences: Optional[List[str]] = None
    food_dislikes: Optional[List[str]] = None
    allergies: Optional[List[str]] = None
    health_conditions: Optional[List[str]] = None


class NutritionCalculator:
    """营养计算器"""

    @staticmethod
    def calculate_bmr(gender: str, weight_kg: float, height_cm: float, age: int) -> int:
        """计算基础代谢率 (Mifflin-St Jeor公式)"""
        if gender == "男":
            bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age + 5
        else:
            bmr = 10 * weight_kg + 6.25 * height_cm - 5 * age - 161
        return int(bmr)

    @staticmethod
    def calculate_tdee(bmr: int, activity_level: str) -> int:
        """计算每日总能量消耗"""
        multipliers = {
            "sedentary": 1.2,      # 久坐
            "light": 1.375,        # 轻度活动
            "moderate": 1.55,      # 中度活动
            "active": 1.725,       # 高强度活动
            "very_active": 1.9     # 极高强度
        }
        return int(bmr * multipliers.get(activity_level, 1.55))

    @staticmethod
    def calculate_target_calories(tdee: int, goal: str, current_weight: float, target_weight: Optional[float] = None) -> int:
        """计算目标热量"""
        if goal == "fat_loss":
            # 减脂：制造300-500kcal缺口
            return max(1200, tdee - 500)
        elif goal == "muscle_gain":
            # 增肌：盈余200-500kcal
            return tdee + 300
        elif goal == "maintenance":
            # 维持：等于TDEE
            return tdee
        else:  # health
            # 健康：轻微缺口或平衡
            return tdee - 200

    @staticmethod
    def calculate_macros(calories: int, goal: str, weight_kg: float) -> Dict:
        """计算宏量营养素"""
        if goal == "fat_loss":
            # 减脂：高蛋白，中等碳水
            protein_g = int(weight_kg * 2.0)  # 2g/kg
            protein_cal = protein_g * 4
            fat_g = int(weight_kg * 0.8)  # 0.8g/kg
            fat_cal = fat_g * 9
            carb_cal = calories - protein_cal - fat_cal
            carb_g = int(carb_cal / 4)
        elif goal == "muscle_gain":
            # 增肌：高蛋白，高碳水
            protein_g = int(weight_kg * 1.8)  # 1.8g/kg
            protein_cal = protein_g * 4
            fat_g = int(weight_kg * 1.0)  # 1g/kg
            fat_cal = fat_g * 9
            carb_cal = calories - protein_cal - fat_cal
            carb_g = int(carb_cal / 4)
        else:
            # 维持/健康：均衡
            protein_g = int(weight_kg * 1.2)  # 1.2g/kg
            protein_cal = protein_g * 4
            fat_g = int(weight_kg * 0.9)  # 0.9g/kg
            fat_cal = fat_g * 9
            carb_cal = calories - protein_cal - fat_cal
            carb_g = int(carb_cal / 4)

        return {
            "protein_g": protein_g,
            "protein_pct": round(protein_cal / calories * 100, 1),
            "carb_g": carb_g,
            "carb_pct": round(carb_cal / calories * 100, 1),
            "fat_g": fat_g,
            "fat_pct": round(fat_cal / calories * 100, 1),
            "fiber_g": 25  # 推荐25-35g
        }


class FoodDatabase:
    """食物数据库"""

    FOODS = {
        "蛋白质": {
            "鸡胸肉": {"calories": 165, "protein": 31, "carbs": 0, "fat": 3.6, "unit": "100g"},
            "鸡腿肉": {"calories": 226, "protein": 25, "carbs": 0, "fat": 13, "unit": "100g"},
            "鸡蛋": {"calories": 155, "protein": 13, "carbs": 1.1, "fat": 11, "unit": "100g"},
            "三文鱼": {"calories": 208, "protein": 20, "carbs": 0, "fat": 13, "unit": "100g"},
            "鲈鱼": {"calories": 124, "protein": 23, "carbs": 0, "fat": 3, "unit": "100g"},
            "虾": {"calories": 99, "protein": 24, "carbs": 0, "fat": 0.3, "unit": "100g"},
            "瘦牛肉": {"calories": 250, "protein": 26, "carbs": 0, "fat": 15, "unit": "100g"},
            "豆腐": {"calories": 76, "protein": 8, "carbs": 1.9, "fat": 4.8, "unit": "100g"},
            "牛奶": {"calories": 54, "protein": 3, "carbs": 4.8, "fat": 3, "unit": "100ml"},
        },
        "碳水": {
            "糙米": {"calories": 111, "protein": 2.6, "carbs": 23, "fat": 0.9, "unit": "100g"},
            "燕麦": {"calories": 389, "protein": 16.9, "carbs": 66, "fat": 6.9, "unit": "100g"},
            "红薯": {"calories": 86, "protein": 1.6, "carbs": 20, "fat": 0.1, "unit": "100g"},
            "全麦面包": {"calories": 247, "protein": 13, "carbs": 41, "fat": 3.4, "unit": "100g"},
            "藜麦": {"calories": 120, "protein": 4.4, "carbs": 21, "fat": 1.9, "unit": "100g"},
            "玉米": {"calories": 86, "protein": 3.2, "carbs": 19, "fat": 1.2, "unit": "100g"},
        },
        "蔬菜": {
            "西兰花": {"calories": 34, "protein": 2.8, "carbs": 7, "fat": 0.4, "unit": "100g"},
            "菠菜": {"calories": 23, "protein": 2.9, "carbs": 3.6, "fat": 0.4, "unit": "100g"},
            "黄瓜": {"calories": 15, "protein": 0.7, "carbs": 3.6, "fat": 0.1, "unit": "100g"},
            "番茄": {"calories": 18, "protein": 0.9, "carbs": 3.9, "fat": 0.2, "unit": "100g"},
            "胡萝卜": {"calories": 41, "protein": 0.9, "carbs": 10, "fat": 0.2, "unit": "100g"},
            "生菜": {"calories": 15, "protein": 1.4, "carbs": 2.9, "fat": 0.2, "unit": "100g"},
            "青椒": {"calories": 20, "protein": 0.9, "carbs": 4.6, "fat": 0.2, "unit": "100g"},
        },
        "水果": {
            "苹果": {"calories": 52, "protein": 0.3, "carbs": 14, "fat": 0.2, "unit": "100g"},
            "香蕉": {"calories": 89, "protein": 1.1, "carbs": 23, "fat": 0.3, "unit": "100g"},
            "蓝莓": {"calories": 57, "protein": 0.7, "carbs": 14, "fat": 0.3, "unit": "100g"},
            "橙子": {"calories": 47, "protein": 0.9, "carbs": 12, "fat": 0.1, "unit": "100g"},
            "猕猴桃": {"calories": 61, "protein": 1.1, "carbs": 15, "fat": 0.5, "unit": "100g"},
        },
        "脂肪": {
            "牛油果": {"calories": 160, "protein": 2, "carbs": 9, "fat": 15, "unit": "100g"},
            "杏仁": {"calories": 579, "protein": 21, "carbs": 22, "fat": 50, "unit": "100g"},
            "核桃": {"calories": 654, "protein": 15, "carbs": 14, "fat": 65, "unit": "100g"},
            "橄榄油": {"calories": 884, "protein": 0, "carbs": 0, "fat": 100, "unit": "100ml"},
        }
    }

    @classmethod
    def get_food(cls, category: str, name: str) -> Optional[Dict]:
        """获取食物信息"""
        return cls.FOODS.get(category, {}).get(name)

    @classmethod
    def get_foods_by_category(cls, category: str) -> Dict:
        """获取某类食物"""
        return cls.FOODS.get(category, {})


class RecipeGenerator:
    """食谱生成器"""

    # 中餐食谱模板
    CHINESE_RECIPES = {
        "早餐": [
            {
                "name": "燕麦牛奶粥",
                "ingredients": {"燕麦": "50g", "牛奶": "250ml", "香蕉": "半根"},
                "calories": 400,
                "protein": 18,
                "time": 5,
                "method": "燕麦加牛奶煮3分钟，加入切片香蕉"
            },
            {
                "name": "全麦三明治",
                "ingredients": {"全麦面包": "2片", "鸡蛋": "1个", "生菜": "2片", "番茄": "2片"},
                "calories": 350,
                "protein": 16,
                "time": 10,
                "method": "鸡蛋煎熟，夹入面包中，加生菜番茄"
            },
            {
                "name": "紫薯豆浆",
                "ingredients": {"紫薯": "150g", "鸡蛋": "1个", "无糖豆浆": "300ml"},
                "calories": 380,
                "protein": 15,
                "time": 15,
                "method": "紫薯蒸熟，鸡蛋水煮，搭配豆浆"
            },
        ],
        "午餐": [
            {
                "name": "香煎鸡胸肉套餐",
                "ingredients": {"鸡胸肉": "150g", "糙米": "100g", "西兰花": "200g", "胡萝卜": "50g"},
                "calories": 550,
                "protein": 45,
                "time": 25,
                "method": "鸡胸肉用盐和黑胡椒腌制后煎熟，蔬菜焯水，配糙米饭"
            },
            {
                "name": "清蒸鲈鱼套餐",
                "ingredients": {"鲈鱼": "150g", "红薯": "150g", "菠菜": "200g"},
                "calories": 480,
                "protein": 38,
                "time": 20,
                "method": "鲈鱼清蒸8分钟，红薯蒸熟，菠菜清炒"
            },
            {
                "name": "番茄牛肉套餐",
                "ingredients": {"瘦牛肉": "120g", "番茄": "200g", "糙米": "100g", "生菜": "100g"},
                "calories": 580,
                "protein": 35,
                "time": 30,
                "method": "牛肉切片炒番茄，配糙米饭和生菜沙拉"
            },
        ],
        "晚餐": [
            {
                "name": "虾仁豆腐汤",
                "ingredients": {"虾仁": "100g", "豆腐": "150g", "番茄": "100g", "杂粮": "80g"},
                "calories": 380,
                "protein": 28,
                "time": 15,
                "method": "番茄炒出汁，加水煮开，放入豆腐和虾仁"
            },
            {
                "name": "鸡丝沙拉",
                "ingredients": {"鸡胸肉": "100g", "黄瓜": "100g", "生菜": "100g", "玉米": "50g"},
                "calories": 320,
                "protein": 25,
                "time": 15,
                "method": "鸡胸肉煮熟撕丝，蔬菜切块，加橄榄油和醋拌匀"
            },
            {
                "name": "蒸蛋羹",
                "ingredients": {"鸡蛋": "2个", "豆腐": "100g", "菠菜": "100g", "杂粮": "60g"},
                "calories": 350,
                "protein": 22,
                "time": 15,
                "method": "鸡蛋打散加温水蒸8分钟，菠菜焯水，配杂粮"
            },
        ],
        "加餐": [
            {
                "name": "坚果酸奶",
                "ingredients": {"无糖酸奶": "150g", "杏仁": "10g", "蓝莓": "50g"},
                "calories": 180,
                "protein": 8,
                "time": 2,
                "method": "混合即可"
            },
            {
                "name": "水果拼盘",
                "ingredients": {"苹果": "半个", "猕猴桃": "1个"},
                "calories": 100,
                "protein": 1,
                "time": 3,
                "method": "切块食用"
            },
        ]
    }

    def __init__(self, user: UserProfile, macros: Dict):
        self.user = user
        self.macros = macros

    def generate_daily_meals(self) -> Dict:
        """生成一天的饮食"""
        meals = {}

        # 根据目标分配三餐热量
        if self.user.goal == "fat_loss":
            meal_distribution = {"早餐": 0.30, "午餐": 0.40, "晚餐": 0.25, "加餐": 0.05}
        elif self.user.goal == "muscle_gain":
            meal_distribution = {"早餐": 0.25, "午餐": 0.35, "晚餐": 0.30, "加餐": 0.10}
        else:
            meal_distribution = {"早餐": 0.30, "午餐": 0.35, "晚餐": 0.30, "加餐": 0.05}

        total_calories = self.macros.get("total_calories", 2000)

        for meal_type, ratio in meal_distribution.items():
            target_calories = int(total_calories * ratio)
            recipe = self._select_recipe(meal_type, target_calories)
            meals[meal_type] = recipe

        return meals

    def _select_recipe(self, meal_type: str, target_calories: int) -> Dict:
        """选择适合的食谱"""
        recipes = self.CHINESE_RECIPES.get(meal_type, [])

        # 选择热量最接近的
        if recipes:
            closest = min(recipes, key=lambda x: abs(x["calories"] - target_calories))
            return closest

        return {"name": "自定义", "ingredients": {}, "calories": target_calories, "protein": 0}

    def generate_weekly_plan(self) -> List[Dict]:
        """生成一周饮食计划"""
        weekly_plan = []

        for day in range(1, 8):
            daily_meals = self.generate_daily_meals()
            daily_plan = {
                "day": day,
                "meals": daily_meals,
                "daily_totals": self._calculate_daily_totals(daily_meals)
            }
            weekly_plan.append(daily_plan)

        return weekly_plan

    def _calculate_daily_totals(self, meals: Dict) -> Dict:
        """计算每日总计"""
        total_calories = sum(meal.get("calories", 0) for meal in meals.values())
        total_protein = sum(meal.get("protein", 0) for meal in meals.values())

        return {
            "calories": total_calories,
            "protein": total_protein,
            "carbs": "-",
            "fat": "-"
        }


class ShoppingListGenerator:
    """购物清单生成器"""

    def generate(self, weekly_plan: List[Dict]) -> Dict:
        """根据一周饮食生成购物清单"""
        shopping_list = {
            "蛋白质": {},
            "碳水": {},
            "蔬菜": {},
            "水果": {},
            "其他": {}
        }

        # 汇总所有食材
        for day_plan in weekly_plan:
            for meal_type, meal in day_plan["meals"].items():
                ingredients = meal.get("ingredients", {})
                for item, amount in ingredients.items():
                    category = self._categorize_item(item)
                    if item in shopping_list[category]:
                        shopping_list[category][item] += f", {amount}"
                    else:
                        shopping_list[category][item] = amount

        return shopping_list

    def _categorize_item(self, item: str) -> str:
        """分类食材"""
        protein_items = ["鸡胸肉", "鸡腿肉", "鸡蛋", "三文鱼", "鲈鱼", "虾", "瘦牛肉", "豆腐", "牛奶"]
        carb_items = ["糙米", "燕麦", "红薯", "全麦面包", "藜麦", "玉米", "杂粮"]
        veg_items = ["西兰花", "菠菜", "黄瓜", "番茄", "胡萝卜", "生菜", "青椒"]
        fruit_items = ["苹果", "香蕉", "蓝莓", "橙子", "猕猴桃"]

        if item in protein_items:
            return "蛋白质"
        elif item in carb_items:
            return "碳水"
        elif item in veg_items:
            return "蔬菜"
        elif item in fruit_items:
            return "水果"
        else:
            return "其他"


class MealPlanGenerator:
    """饮食计划主生成器"""

    def __init__(self, user: UserProfile):
        self.user = user
        self.calculator = NutritionCalculator()
        self.nutrition = self._calculate_nutrition()

    def _calculate_nutrition(self) -> Dict:
        """计算营养需求"""
        bmr = self.calculator.calculate_bmr(
            self.user.gender, self.user.weight_kg, self.user.height_cm, self.user.age
        )
        tdee = self.calculator.calculate_tdee(bmr, self.user.activity_level)
        target_calories = self.calculator.calculate_target_calories(
            tdee, self.user.goal, self.user.weight_kg, self.user.target_weight_kg
        )
        macros = self.calculator.calculate_macros(target_calories, self.user.goal, self.user.weight_kg)

        return {
            "bmr": bmr,
            "tdee": tdee,
            "target_calories": target_calories,
            **macros
        }

    def generate_plan(self) -> str:
        """生成完整饮食计划文档"""
        # 生成食谱
        recipe_gen = RecipeGenerator(self.user, self.nutrition)
        weekly_plan = recipe_gen.generate_weekly_plan()

        # 生成购物清单
        shopping_gen = ShoppingListGenerator()
        shopping_list = shopping_gen.generate(weekly_plan)

        # 导出为Markdown
        return self._export_to_markdown(weekly_plan, shopping_list)

    def _export_to_markdown(self, weekly_plan: List[Dict], shopping_list: Dict) -> str:
        """导出为Markdown"""
        user = self.user
        nutrition = self.nutrition

        md = f"""# 🍽️ 个性化饮食方案

**生成日期**: {datetime.now().strftime('%Y年%m月%d日')}
**方案周期**: 7天轮换

---

## 📋 个人档案

| 项目 | 内容 |
|------|------|
| 性别 | {user.gender} |
| 年龄 | {user.age}岁 |
| 身高 | {user.height_cm}cm |
| 体重 | {user.weight_kg}kg |
| 饮食目标 | {user.goal} |
| 活动水平 | {user.activity_level} |
| 饮食类型 | {user.diet_type} |
| 菜系偏好 | {user.cuisine_preference} |
| 做饭条件 | {user.cooking_capability} |
| 每餐时间 | {user.cooking_time}分钟 |

---

## 📊 营养需求分析

| 指标 | 数值 | 说明 |
|------|------|------|
| **基础代谢(BMR)** | {nutrition['bmr']} kcal | 静息消耗 |
| **每日总消耗(TDEE)** | {nutrition['tdee']} kcal | 含活动消耗 |
| **建议每日摄入** | {nutrition['target_calories']} kcal | 根据目标调整 |
| **蛋白质** | {nutrition['protein_g']}g ({nutrition['protein_pct']}%) | 约{nutrition['protein_g']//user.weight_kg}g/kg体重 |
| **碳水** | {nutrition['carb_g']}g ({nutrition['carb_pct']}%) | 支持能量需求 |
| **脂肪** | {nutrition['fat_g']}g ({nutrition['fat_pct']}%) | 维持激素健康 |
| **膳食纤维** | {nutrition['fiber_g']}g | 促进肠道健康 |

---

## 🍳 7天饮食计划

"""

        for day_plan in weekly_plan:
            md += f"\n### 第{day_plan['day']}天\n\n"

            for meal_type, meal in day_plan["meals"].items():
                md += f"**{meal_type}** - {meal['name']} ({meal['calories']}kcal, 蛋白质{meal['protein']}g)\n\n"
                md += f"- 食材: {', '.join([f'{k} {v}' for k, v in meal['ingredients'].items()])}\n"
                md += f"- 做法: {meal['method']}\n"
                md += f"- 用时: {meal['time']}分钟\n\n"

            totals = day_plan["daily_totals"]
            md += f"**今日总计**: {totals['calories']}kcal, 蛋白质{totals['protein']}g\n\n"
            md += "---\n\n"

        # 添加购物清单
        md += "\n## 🛒 购物清单\n\n"
        for category, items in shopping_list.items():
            if items:
                md += f"### {category}\n"
                for item, amount in items.items():
                    md += f"- {item}: {amount}\n"
                md += "\n"

        # 添加实用建议
        md += """
---

## 💡 实用建议

###  meal prep 建议
- **周末批量准备**: 蛋白质（烤鸡胸、煮蛋）、碳水（煮杂粮饭、蒸红薯）
- **蔬菜**: 建议现做或准备3天内的量
- **分装**: 按餐分装到保鲜盒，工作日直接加热

### 外食替代方案
- **中餐**: 选择清蒸、白灼、清炒类菜品
- **快餐**: 赛百味全麦三明治、麦当劳板烧鸡腿堡（去酱）
- **火锅**: 清汤锅底，多选瘦肉、海鲜、蔬菜

### 饮水建议
- 每日饮水 2000-2500ml
- 运动前后额外补充
- 餐前30分钟喝水有助于控制食欲

### 注意事项
- 称重每周1次即可，不要每天称重
- 允许偶尔的"欺骗餐"，保持心理平衡
- 如有不适，请咨询营养师或医生

---

## 📝 饮食记录表

| 日期 | 体重 | 早餐 | 午餐 | 晚餐 | 加餐 | 总热量 | 感受 |
|------|------|------|------|------|------|--------|------|
| 周一 | | | | | | | |
| 周二 | | | | | | | |
| 周三 | | | | | | | |
| 周四 | | | | | | | |
| 周五 | | | | | | | |
| 周六 | | | | | | | |
| 周日 | | | | | | | |

---

*祝你饮食愉快，达成目标！* 🎯
"""

        return md


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='生成个性化饮食方案')
    parser.add_argument('--goal', required=True,
                       choices=['fat_loss', 'muscle_gain', 'maintenance', 'health'],
                       help='饮食目标')
    parser.add_argument('--gender', required=True, choices=['男', '女'], help='性别')
    parser.add_argument('--age', type=int, required=True, help='年龄')
    parser.add_argument('--height', type=float, required=True, help='身高(cm)')
    parser.add_argument('--weight', type=float, required=True, help='体重(kg)')
    parser.add_argument('--activity', default='moderate',
                       choices=['sedentary', 'light', 'moderate', 'active', 'very_active'],
                       help='活动水平')
    parser.add_argument('--diet-type', default='普通', help='饮食类型')
    parser.add_argument('--cuisine', default='中餐', help='菜系偏好')
    parser.add_argument('--cooking-time', type=int, default=30, help='每餐可用时间(分钟)')
    parser.add_argument('--output', required=True, help='输出文件路径')

    args = parser.parse_args()

    # 创建用户档案
    user = UserProfile(
        gender=args.gender,
        age=args.age,
        height_cm=args.height,
        weight_kg=args.weight,
        goal=args.goal,
        activity_level=args.activity,
        diet_type=args.diet_type,
        cuisine_preference=args.cuisine,
        cooking_time=args.cooking_time
    )

    # 生成计划
    generator = MealPlanGenerator(user)
    plan_content = generator.generate_plan()

    # 保存文件
    output_path = Path(args.output)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(plan_content)

    print(f"[OK] 饮食方案已生成: {output_path}")
    print(f"[INFO] 目标热量: {generator.nutrition['target_calories']} kcal")
    print(f"[INFO] 蛋白质: {generator.nutrition['protein_g']}g")


if __name__ == "__main__":
    main()
