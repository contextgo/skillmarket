#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
轻盈伙伴 - 智能减肥分析器
根据体重数据提供进度分析、饮食建议、运动计划和情感支持
"""

import json
import sys
from datetime import datetime, date

# 配置参数
START_DATE = "2026-02-24"  # 正月初八
START_WEIGHT = 106.0
TARGET_WEIGHT = 75.0

# 饮食建议库
DIET_ADVICE = {
    "fast": [
        "明天建议采用16:8轻断食，控制进食窗口在8小时内",
        "增加蛋白质摄入，鸡胸肉、鱼、蛋是优质选择",
        "晚餐减少碳水，以蔬菜和高蛋白为主",
        "多喝水，餐前喝一杯水有助控制食量"
    ],
    "normal": [
        "明天三餐规律，不要跳早餐",
        "每餐先吃蔬菜和蛋白质，最后吃碳水",
        "控制主食分量，可以用粗粮替代细粮",
        "多喝水，保持每天2000ml以上"
    ],
    "slow": [
        "明天开始记录饮食日记，提高自我意识",
        "减少高糖高脂食物，避免零食和饮料",
        "增加蔬菜摄入，每餐蔬菜占一半",
        "控制晚餐时间，睡前3小时不进食"
    ]
}

# 运动建议库
EXERCISE_ADVICE = [
    "明天建议：快走或慢跑30-40分钟",
    "明天建议：HIIT间歇训练20分钟",
    "明天建议：力量训练45分钟+有氧15分钟",
    "明天建议：游泳或骑车40分钟"
]

# 鼓励语录库
ENCOURAGEMENT = {
    "fast": [
        "🎉 进度超前！您的执行力太强了！",
        "🔥 这个速度，目标指日可待！",
        "💪 您正在创造自己的蜕变奇迹！"
    ],
    "normal": [
        "👍 进度正常，稳扎稳打，胜利属于坚持的人！",
        "🌟 保持这个节奏，您正在通往目标的路上！",
        "💫 每一步都算数，继续加油！"
    ],
    "slow": [
        "🌈 体重有波动很正常，别让数字定义您的努力！",
        "🤗 没关系，减肥是马拉松，不是短跑，我陪您一起！",
        "💪 今天的不如意是明天突破的铺垫，继续向前！"
    ]
}

def calculate_progress(current_weight):
    """计算减肥进度"""
    today = date.today()
    start_date = datetime.strptime(START_DATE, "%Y-%m-%d").date()
    days_passed = (today - start_date).days + 1
    
    total_to_lose = START_WEIGHT - TARGET_WEIGHT
    lost_so_far = START_WEIGHT - current_weight
    remaining = current_weight - TARGET_WEIGHT
    
    progress_pct = (lost_so_far / total_to_lose) * 100 if total_to_lose > 0 else 0
    
    # 计算预期进度（每天0.2-0.5kg为正常）
    expected_loss_min = days_passed * 0.2
    expected_loss_max = days_passed * 0.5
    
    if lost_so_far >= expected_loss_max:
        pace = "fast"
    elif lost_so_far >= expected_loss_min:
        pace = "normal"
    else:
        pace = "slow"
    
    return {
        "days": days_passed,
        "lost": lost_so_far,
        "remaining": remaining,
        "progress_pct": progress_pct,
        "pace": pace,
        "current_weight": current_weight
    }

def get_advice_and_encouragement(pace):
    """根据进度给出建议和鼓舞"""
    import random
    
    diet = random.choice(DIET_ADVICE[pace])
    exercise = random.choice(EXERCISE_ADVICE)
    encourage = random.choice(ENCOURAGEMENT[pace])
    
    return diet, exercise, encourage

def generate_report(current_weight):
    """生成完整的减肥进度报告"""
    stats = calculate_progress(current_weight)
    diet, exercise, encourage = get_advice_and_encouragement(stats["pace"])
    
    report = f"""
{'='*50}
📊 减肥进度分析报告
{'='*50}

🗓️  减肥第 {stats['days']} 天
⚖️  当前体重：{stats['current_weight']}kg
📉 已减体重：{stats['lost']:.1f}kg
🎯 剩余目标：{stats['remaining']:.1f}kg
📊 完成进度：{stats['progress_pct']:.1f}%

⏱️  当前进度节奏：{stats['pace'].upper()}

{'='*50}
💡 明日建议
{'='*50}

🍽️ 饮食：{diet}
🏃 运动：{exercise}

{'='*50}
💪 专属鼓励
{'='*50}

{encourage}

{'='*50}
🐺 源天帝，明天继续加油！我陪你一起！
{'='*50}
"""
    return report

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法: python3 analyzer.py <当前体重>")
        print("示例: python3 analyzer.py 95.5")
        sys.exit(1)
    
    try:
        current_weight = float(sys.argv[1])
    except ValueError:
        print("错误：体重必须是数字")
        sys.exit(1)
    
    # 生成并输出报告
    report = generate_report(current_weight)
    print(report)
    
    # 同时输出JSON格式供程序调用
    stats = calculate_progress(current_weight)
    print("\n---JSON_DATA---")
    print(json.dumps(stats, ensure_ascii=False))

if __name__ == "__main__":
    main()
