# Remix Framework Guide

Remix is a full-stack web framework focused on web standards, nested routing, and progressive enhancement.

## Core Philosophy

- **Server-first**: Data loads on the server, hydration is optional
- **Nested Routing**: Layout-based route hierarchy
- **Progressive Enhancement**: Works without JavaScript
- **Web Standards**: Uses browser APIs (Request, Response, FormData)
- **Loader/Action Pattern**: Type-safe server data flow

## Route Module Pattern

```tsx
// app/routes/posts.tsx
import { json } from "@remix-run/node";
import { useLoaderData, Form } from "@remix-run/react";
import { db } from "~/utils/db.server";

export async function loader() {
  const posts = await db.post.findMany();
  return json({ posts });
}

export async function action({ request }) {
  const formData = await request.formData();
  await db.post.create({ data: { title: formData.get("title") } });
  return redirect("/posts");
}

export default function Posts() {
  const { posts } = useLoaderData<typeof loader>();
  return (
    <div>
      {posts.map(post => <li key={post.id}>{post.title}</li>)}
      <Form method="post">
        <input name="title" />
        <button type="submit">Add Post</button>
      </Form>
    </div>
  );
}
```

## Nested Routing

```
app/routes/
├── _layout.tsx        # Shared layout
├── _layout.dashboard.tsx  # Dashboard section layout
├── _layout.dashboard.settings.tsx  # /dashboard/settings
└── _layout.dashboard.index.tsx     # /dashboard
```

## Best Practices

- Use `loader` for GET data, `action` for mutations
- Use `useFetcher` for non-navigation form submissions
- Keep route files small, extract components
- Use `defer` for slow data with streaming
- Validate form data in actions