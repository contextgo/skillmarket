# 市场监控 (stock-market-monitor)

市场监控 Skill，实时监测市场异动、大单交易、涨停热度、龙虎榜数据。

## 功能

- 实时监控大单交易
- 涨停股票分析
- 昨日涨停表现
- 龙虎榜数据获取
- 市场热度监控

## 使用

```bash
# 监控大单
python main.py big-deal --min-amount 1000000

# 涨停股票
python main.py zt-board

# 昨日涨停表现
python main.py yesterday-zt

# 龙虎榜
python main.py longhuban --date 20250115

# 市场热度
python main.py heat
```

## 依赖

- akshare
- pandas

## License

MIT
