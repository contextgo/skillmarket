#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
市场监控工具
实时监测市场异动、大单交易、涨停热度、龙虎榜
"""

import akshare as ak
import pandas as pd


class MarketMonitor:
    """市场监控器"""
    
    def __init__(self):
        pass
    
    def get_big_deal(self, min_amount=1000000):
        """
        获取大单交易
        
        Args:
            min_amount: 最小成交金额（元）
            
        Returns:
            DataFrame: 大单交易数据
        """
        try:
            df = ak.stock_zh_a_spot_em()
            # 筛选成交额大于阈值的
            df['成交额_元'] = df['成交额'] * 10000  # 转换为元
            big_deals = df[df['成交额_元'] >= min_amount]
            
            columns = ['代码', '名称', '最新价', '涨跌幅', '成交额', '换手率', '所属行业']
            available_cols = [c for c in columns if c in big_deals.columns]
            return big_deals[available_cols].sort_values('成交额', ascending=False).head(20)
        except Exception as e:
            print(f"获取大单数据失败: {e}")
            return None
    
    def get_zt_board(self):
        """
        获取涨停股票
        
        Returns:
            DataFrame: 涨停股票列表
        """
        try:
            df = ak.stock_zh_a_spot_em()
            # 涨停股票（涨幅 >= 9.5%）
            zt = df[df['涨跌幅'] >= 9.5].copy()
            
            columns = ['代码', '名称', '最新价', '涨跌幅', '换手率', '成交额', '所属行业']
            available_cols = [c for c in columns if c in zt.columns]
            return zt[available_cols].sort_values('涨跌幅', ascending=False)
        except Exception as e:
            print(f"获取涨停数据失败: {e}")
            return None
    
    def get_yesterday_zt(self):
        """
        获取昨日涨停股票今日表现
        
        Returns:
            DataFrame: 昨日涨停股表现
        """
        try:
            # 获取昨日涨停数据
            df = ak.stock_zt_pool_em(date="")
            if df is not None and not df.empty:
                columns = ['代码', '名称', '涨跌幅', '最新价', '成交额', '所属行业']
                available_cols = [c for c in columns if c in df.columns]
                return df[available_cols]
        except Exception as e:
            print(f"获取昨日涨停表现失败: {e}")
        return None
    
    def get_longhuban(self, date=None):
        """
        获取龙虎榜数据
        
        Args:
            date: 日期，格式 YYYYMMDD，默认今天
            
        Returns:
            DataFrame: 龙虎榜数据
        """
        try:
            if date is None:
                from datetime import datetime
                date = datetime.now().strftime("%Y%m%d")
            
            df = ak.stock_lhb_detail_daily_sina(start_date=date, end_date=date)
            
            if df is not None and not df.empty:
                return df.head(30)
        except Exception as e:
            print(f"获取龙虎榜失败: {e}")
        return None
    
    def get_market_heat(self):
        """
        获取市场热度
        
        Returns:
            dict: 市场热度指标
        """
        try:
            df = ak.stock_zh_a_spot_em()
            
            total = len(df)
            up = len(df[df['涨跌幅'] > 0])
            down = len(df[df['涨跌幅'] < 0])
            zt = len(df[df['涨跌幅'] >= 9.5])
            dt = len(df[df['涨跌幅'] <= -9.5])
            
            heat = {
                "总股票数": total,
                "上涨": up,
                "下跌": down,
                "涨停": zt,
                "跌停": dt,
                "上涨率": f"{up/total*100:.2f}%",
                "涨停率": f"{zt/total*100:.2f}%",
            }
            return heat
        except Exception as e:
            print(f"获取市场热度失败: {e}")
            return None


def main():
    """CLI 入口"""
    import fire
    
    monitor = MarketMonitor()
    
    def big_deal(min_amount=1000000):
        """监控大单"""
        result = monitor.get_big_deal(min_amount)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取大单数据失败")
    
    def zt_board():
        """涨停股票"""
        result = monitor.get_zt_board()
        if result is not None:
            print(result.to_string(index=False))
            print(f"\n共 {len(result)} 只涨停")
        else:
            print("获取涨停数据失败")
    
    def yesterday_zt():
        """昨日涨停表现"""
        result = monitor.get_yesterday_zt()
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取昨日涨停表现失败")
    
    def longhuban(date=None):
        """龙虎榜"""
        result = monitor.get_longhuban(date)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取龙虎榜失败")
    
    def heat():
        """市场热度"""
        result = monitor.get_market_heat()
        if result is not None:
            for k, v in result.items():
                print(f"{k}: {v}")
        else:
            print("获取市场热度失败")
    
    fire.Fire({
        "big-deal": big_deal,
        "zt-board": zt_board,
        "yesterday-zt": yesterday_zt,
        "longhuban": longhuban,
        "heat": heat,
    })


if __name__ == "__main__":
    main()
