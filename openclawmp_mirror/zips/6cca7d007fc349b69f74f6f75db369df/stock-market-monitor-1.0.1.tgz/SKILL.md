# stock-market-monitor Skill

## Description

市场监控 Skill，实时监测市场异动、大单交易、涨停热度、龙虎榜数据。

## Capabilities

- 实时监控大单交易
- 涨停股票分析
- 昨日涨停表现
- 龙虎榜数据获取
- 市场热度监控

## Usage

```bash
# 监控大单
python main.py big-deal --min-amount 1000000

# 涨停股票
python main.py zt-board

# 昨日涨停表现
python main.py yesterday-zt

# 龙虎榜
python main.py longhuban --date 2025-01-15

# 市场热度
python main.py heat
```

## Dependencies

- akshare
- pandas

## License

MIT
