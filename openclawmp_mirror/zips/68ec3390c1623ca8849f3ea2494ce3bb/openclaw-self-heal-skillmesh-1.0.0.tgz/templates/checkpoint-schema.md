# Checkpoint Schema

- task_id
- step_name
- input_digest
- output_digest
- status
- updated_at
