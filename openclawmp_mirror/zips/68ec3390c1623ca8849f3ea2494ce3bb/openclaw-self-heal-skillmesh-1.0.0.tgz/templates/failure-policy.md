# Failure Policy

## 1) 可自动重试（瞬时故障）
- timeout
- rate_limit
- temporary_network_error

策略：最多 3 次，指数退避 + jitter。

## 2) 可降级重试
- primary_model_unavailable
- tool_partial_failure

策略：切到 fallback 后重试 1 次。

## 3) 必须人工确认
- external_side_effect
- permission_denied
- data_integrity_risk
