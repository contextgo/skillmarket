---
name: whisper-stt
description: "语音识别 (STT) - 使用 OpenAI Whisper 将语音转成文字。当用户发送语音消息时自动调用此技能。"
homepage: 
metadata: { "openclaw": { "emoji": "🎙️", "requires": { "api": "openai-whisper" } } }
---

# Whisper STT Skill

使用 OpenAI Whisper API 进行语音识别。

## When to Use

✅ **USE this skill when:**

- 用户发送语音消息
- 需要将音频转成文字

## Implementation

使用 OpenAI Whisper API：

```python
import requests

def transcribe_audio(audio_path, api_key):
    url = "https://api.openai.com/v1/audio/transcriptions"
    
    with open(audio_path, "rb") as f:
        files = {"file": f}
        data = {"model": "whisper-1"}
        headers = {"Authorization": f"Bearer {api_key}"}
        
        response = requests.post(url, files=files, data=data, headers=headers)
        return response.json()["text"]
```

## Notes

- 需要 OpenAI API Key
- 支持多种音频格式 (mp3, wav, m4a, etc.)
- 最大 25MB
