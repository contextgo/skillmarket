#!/usr/bin/env python3
"""
GJB军工体系文件生成器（Python跨平台版）
符合GJB9001C-2017标准，支持生成质量手册、程序文件、作业指导书、记录表单、设计开发文档

用法：
  python generator.py --type 程序文件 --name "设计和开发控制程序" --code "OP-002"
  python generator.py --type 作业指导书 --name "定子绕组嵌线作业指导书" --code "WI-EM-001"
  python generator.py --type 记录表单 --name "电机绕组检验记录" --code "FRM-EM-001"
  python generator.py --type 质量手册 --code "QM-001"
  python generator.py --list
"""

import argparse
import sys
from datetime import datetime

# ============================================================
# 模板库
# ============================================================

TEMPLATES = {
    "程序文件": """
【标题】
{code} {name}
版本：{version} | 发布日期：{date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. 目的

规范{scope}过程，确保产品满足顾客要求和适用法律法规要求，建立并保持{code}程序文件。

2. 适用范围

适用于公司{product_types}的{scope_description}全过程，包括{process_steps}。

3. 引用标准

- GJB9001C-2017《质量管理体系要求》
- GJB3206-2010《技术状态管理》
- GJB450A-2004《装备可靠性工作通用要求》
- GB/T 19001-2016《质量管理体系基础和术语》
{additional_standards}

4. 职责

{responsibilities}

5. 工作程序

{process}

6. 质量记录

{records}

7. 附录

{appendix}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
编制：___________ 审核：___________ 批准：___________ 日期：___________
""",

    "作业指导书": """
【标题】
{code} {name}
版本：{version} | 发布日期：{date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. 目的

规范{scope}操作，确保产品质量满足设计要求，建立{code}作业指导书。

2. 适用范围

适用于公司{product_types}的{scope_description}工序。

3. 材料和设备

{材料和设备}

4. 操作步骤

{操作步骤}

5. 质量检查

{质量检查}

6. 注意事项

{注意事项}

7. 记录要求

{记录要求}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
编制：___________ 审核：___________ 批准：___________ 日期：___________
""",

    "记录表单": """
【标题】
{code} {name}
版本：{version} | 发布日期：{date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
基本信息

| 项目 | 内容 |
|------|------|
| 产品型号 | |
| 产品编号 | |
| 检验日期 | |
| 检验员 | |
| 生产批号 | |
| 操作者 | |

{表单内容}

检验结论
□ 合格  □ 不合格（原因：_______________________）

检验员：___________ 审核：___________ 批准：___________ 日期：___________
""",

    "质量手册": """
【标题】
{code} {name}
版本：{version} | 发布日期：{date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
0. 发布令

本质量手册依据GJB9001C-2017《质量管理体系要求》编制，现批准发布实施。
本手册是公司质量管理体系的核心文件，是开展质量活动的准则，对内具有强制性。

总经理：___________ 日期：___________

1. 适用范围

1.1 本手册适用于公司{product_types}的设计开发、生产和服务全过程。

1.2 本手册适用于公司质量管理体系覆盖的所有部门和人员。

1.3 本手册适用于军方顾客及合同要求的质量管理体系认证。

2. 引用标准

- GJB9001C-2017《质量管理体系要求》
- GJB3206-2010《技术状态管理》
- GJB450A-2004《装备可靠性工作通用要求》
- GJB368B-2009《装备维修工作通用要求》
- GB/T 19001-2016《质量管理体系基础和术语》
{additional_standards}

3. 术语和定义

本手册采用GJB9001C及GB/T 19001中的术语和定义。

4. 质量管理体系

4.1 总要求
公司按照GJB9001C-2017建立、实施、保持和持续改进质量管理体系...

4.2 文件要求
（见程序文件OP-001《文件控制程序》）

5. 管理职责

5.1 管理承诺
（最高管理者承诺见《管理承诺记录》）

6. 资源管理

（详见相关程序文件）

7. 产品实现

（详见设计和开发、生产和服务相关程序文件）

8. 测量、分析和改进

（详见监视测量和不合格品控制程序文件）

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
编制：___________ 审核：___________ 批准：___________ 日期：___________
""",

    "设计开发文档": """
【标题】
{code} {name}
版本：{version} | 发布日期：{date}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. 设计输入

| 要求项 | 内容 | 来源 |
|--------|------|------|
| 顾客要求 | | 技术协议/合同 |
| 法规要求 | | GJB/国标 |
| 功能要求 | | 任务书 |
| 可靠性指标 | | 可靠性大纲 |
| 环境要求 | | GJB423 |

2. 设计输出

{设计输出}

3. 设计评审

| 评审阶段 | 时间 | 参加人员 | 评审结论 |
|----------|------|----------|----------|
| 方案评审 | | | □通过 □不通过 |
| 详细评审 | | | □通过 □不通过 |
| 设计定型 | | | □通过 □不通过 |

4. 设计验证

{设计验证}

5. 设计确认

{设计确认}

6. 更改记录

{更改记录}

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
项目负责人：___________ 审核：___________ 批准：___________ 日期：___________
""",
}


# ============================================================
# 内容片段库
# ============================================================

CONTENT = {
    "product_types_motor": "军用电机、永磁电机、无刷力矩电机、伺服电机",

    "scope_设计和开发": "设计和开发",
    "scope_description_设计和开发": "设计和开发",
    "process_steps_设计和开发": "设计输入、设计输出、设计评审、设计验证、设计确认和设计更改控制",

    "scope_定子绕组嵌线": "定子绕组嵌线",
    "scope_description_定子绕组嵌线": "定子绕组嵌线",

    "responsibilities_通用": """4.1 管理者代表
  - 负责批准设计和开发计划
  - 主持设计评审和设计确认

4.2 研发部
  - 负责编制设计输入文件
  - 负责设计和开发全过程的技术工作
  - 负责设计输出文件的编制

4.3 质量部
  - 负责设计评审的组织
  - 负责设计验证和设计确认的监督

4.4 生产部
  - 参与设计评审和设计验证
  - 负责工艺文件的编制""",

    "process_设计和开发": """5.1 设计和开发策划
5.1.1 项目立项后，由项目负责人编制《设计和开发和计划书》
5.1.2 计划书内容包括：阶段划分、工作内容、职责分工、进度安排、资源需求

5.2 设计输入
5.2.1 设计输入应完整、明确、可验证
5.2.2 设计输入文件经评审后，由项目负责人批准

5.3 设计输出
5.3.1 设计输出应满足设计输入要求
5.3.2 设计输出文件包括：电磁方案、结构图纸、BOM、技术条件

5.4 设计评审
5.4.1 方案设计评审、详细设计评审、设计定型评审
5.4.2 评审结论应予以记录

5.5 设计验证
5.5.1 重要设计应进行Maxwell电磁仿真验证
5.5.2 设计验证记录应予以保存

5.6 设计确认
5.6.1 样机试验完成，编制《设计确认报告》

5.7 设计更改
5.7.1 重大更改应重新评审和验证""",

    "records_通用": """| 记录名称 | 记录编号 | 保存期限 |
|---------|---------|---------|
| 设计和开发计划书 | DD-001 | 10年 |
| 设计输入评审记录 | DD-002 | 10年 |
| 设计评审记录 | DD-003 | 10年 |
| 设计验证报告 | DD-004 | 10年 |
| 设计确认报告 | DD-005 | 永久 |""",

    "materials_嵌线": """### 3.1 主要材料
- 电磁线：QZ-2 0.71mm（根据技术文件）
- 槽绝缘：NMN 0.25mm
- 槽楔：3240环氧酚醛玻璃布板
- 端部绝缘：醇酸玻纤套管

### 3.2 设备工具
- 嵌线工具（压线脚、划线板、锤子）
- 绕线机（根据规格选用）
- 绕组拉力计、万用表
- 匝间冲击仪""",

    "steps_嵌线": """### 4.1 准备工作
a) 检查铁心质量：槽内应无毛刺、无锈蚀
b) 检查电磁线：线径符合要求，绝缘完好
c) 裁剪绝缘材料：尺寸符合工艺文件

### 4.2 槽绝缘安装
a) 将槽绝缘折成U形放入槽内
b) 绝缘伸出铁心长度：15~20mm
c) 检查绝缘无破损、无皱褶

### 4.3 嵌线
a) 确定嵌线起点和方向（面对出线盒，左出右进）
b) 将线圈直线边嵌入槽内，用压线脚压实
c) 槽满率应控制在45%~55%范围
d) 槽内导线不应交叉、不应松动

### 4.4 端部整形
a) 端部应整齐、美观
b) 端部高度应符合图样要求

### 4.5 槽楔安装
a) 槽楔长度：比槽绝缘短2~3mm
b) 槽楔应紧密插入，不应松动""",

    "check_嵌线": """| 检查项目 | 要求 | 检查方法 |
|---------|------|---------|
| 槽满率 | 45%~55% | 目测+塞规 |
| 绝缘电阻 | ≥100MΩ | 500V兆欧表 |
| 匝间绝缘 | 无短路 | 匝间冲击仪 |
| 导线排列 | 整齐无交叉 | 目测 |
| 槽楔安装 | 紧密无松动 | 目测+手按 |""",

    "notes_嵌线": """a) 操作者应佩戴干净手套，保持清洁
b) 不得踩踏铁心
c) 嵌线过程中轻拿轻放，防止电磁线绝缘损伤
d) 发现问题及时报告，不得擅自处理
e) 每嵌完一个线圈后，用万用表检查相间绝缘""",

    "form_绕组检验": """### 绕组外观检查
| 检查项目 | 要求 | 结果 |
|---------|------|------|
| 槽满率 | 45%~55% | |
| 导线排列 | 整齐无交叉 | |
| 绝缘无破损 | 无可见破损 | |
| 端部整形 | 整齐美观 | |
| 槽楔安装 | 紧密无松动 | |

### 电气性能检查
| 检查项目 | 要求 | 实测值 |
|---------|------|--------|
| 相电阻（AB） | ___Ω | |
| 相电阻（BC） | ___Ω | |
| 相电阻（CA） | ___Ω | |
| 三相不平衡度 | ≤2% | |
| 绝缘电阻 | ≥100MΩ | |
| 匝间绝缘 | 无击穿 | |""",
}


# ============================================================
# 预置文档生成
# ============================================================

PRESETS = {
    "OP-001": {
        "type": "程序文件",
        "name": "文件控制程序",
        "code": "OP-001",
        "scope": "质量管理体系文件的控制",
        "scope_description": "质量管理体系文件的控制",
        "process_steps": "文件编写、审批、发放、更改和保管",
        "responsibilities": """4.1 质量管理部
  - 负责质量管理体系文件的归口管理
  - 负责文件的发放和登记

4.2 各部门
  - 负责本部门文件的编制、使用和保管""",
        "process": """5.1 文件编写
a) 文件应遵循"事事有程序，事事有记录"原则
b) 文件格式应统一，使用公司规定的文件模板

5.2 文件编号
a) 质量手册：QM-XXX
b) 程序文件：OP-XXX
c) 作业指导书：WI-XXX
d) 记录表单：FRM-XXX
e) 设计开发文档：DD-XXX

5.3 文件审批
a) 质量手册：由总经理批准
b) 程序文件：由管理者代表批准
c) 作业指导书：由部门负责人批准

5.4 文件发放
a) 文件管理员负责文件的发放和登记
b) 收回失效文件，防止误用

5.5 文件更改
a) 填写《文件更改申请单》
b) 更改评审：由原审批部门评审
c) 更改实施：更新文件版本号""",
        "records": """| 记录名称 | 记录编号 | 保存期限 |
|---------|---------|---------|
| 文件发放记录 | FRM-OP001-01 | 5年 |
| 文件更改申请单 | FRM-OP001-02 | 5年 |
| 文件销毁记录 | FRM-OP001-03 | 5年 |""",
    },
    "OP-002": {
        "type": "程序文件",
        "name": "设计和开发控制程序",
        "code": "OP-002",
        "scope": "设计和开发",
        "scope_description": "设计和开发",
        "process_steps": "设计输入、设计输出、设计评审、设计验证、设计确认和设计更改控制",
        "responsibilities": CONTENT["responsibilities_通用"],
        "process": CONTENT["process_设计和开发"],
        "records": CONTENT["records_通用"],
    },
    "WI-EM-001": {
        "type": "作业指导书",
        "name": "定子绕组嵌线作业指导书",
        "code": "WI-EM-001",
        "scope": "定子绕组嵌线",
        "scope_description": "定子绕组嵌线",
        "材料设备": CONTENT["materials_嵌线"],
        "操作步骤": CONTENT["steps_嵌线"],
        "质量检查": CONTENT["check_嵌线"],
        "注意事项": CONTENT["notes_嵌线"],
        "记录要求": "嵌线检验记录 FRM-EM-001",
    },
    "FRM-EM-001": {
        "type": "记录表单",
        "name": "电机绕组检验记录",
        "code": "FRM-EM-001",
        "表单内容": CONTENT["form_绕组检验"],
    },
    "QM-001": {
        "type": "质量手册",
        "name": "质量手册",
        "code": "QM-001",
    },
}


# ============================================================
# 生成器
# ============================================================

def generate(doc_type, doc_name, doc_code, version="A",
             product_types=None, preset=None, output_file=None):
    """生成GJB文档"""

    date = datetime.now().strftime("%Y-%m-%d")

    if preset and preset in PRESETS:
        p = PRESETS[preset]
        doc_type = doc_type or p.get("type", "程序文件")
        doc_name = doc_name or p.get("name", doc_name)
        doc_code = doc_code or p.get("code", "OP-XXX")
        template_data = p.copy()
        template_data["version"] = version
        template_data["date"] = date
        template_data["name"] = doc_name
        template_data["code"] = doc_code
        template_data["product_types"] = product_types or CONTENT.get("product_types_motor", "")
    else:
        product_types = product_types or CONTENT.get("product_types_motor", "")
        template_data = {
            "type": doc_type,
            "name": doc_name,
            "code": doc_code,
            "version": version,
            "date": date,
            "product_types": product_types,
            "scope": doc_name,
            "scope_description": doc_name,
            "process_steps": "相关过程步骤",
            "responsibilities": CONTENT.get("responsibilities_通用", ""),
            "process": CONTENT.get("process_设计和开发", ""),
            "records": CONTENT.get("records_通用", ""),
            "additional_standards": "",
            "appendix": "",
        }

    # 填充模板
    template = TEMPLATES.get(doc_type, TEMPLATES["程序文件"])
    content = template.format(**{k: v for k, v in template_data.items() if v})

    # 输出
    if output_file:
        with open(output_file, "w", encoding="utf-8") as f:
            f.write(content)
        print(f"[OK] 已生成：{output_file}")
    else:
        print(content)
        return content


def list_presets():
    """列出所有预置文档"""
    print("\n===== 预置文档列表 =====")
    for code, info in PRESETS.items():
        print(f"  {code}: {info['name']} ({info['type']})")
    print()


def main():
    parser = argparse.ArgumentParser(description="GJB军工体系文件生成器")
    parser.add_argument("--type", "-t", choices=list(TEMPLATES.keys()),
                       help="文档类型")
    parser.add_argument("--name", "-n", help="文档名称")
    parser.add_argument("--code", "-c", help="文档编号（如OP-002）")
    parser.add_argument("--version", "-v", default="A", help="版本号")
    parser.add_argument("--preset", "-p", help="预置文档编号（如OP-002）")
    parser.add_argument("--output", "-o", help="输出文件路径")
    parser.add_argument("--list", "-l", action="store_true", help="列出预置文档")
    parser.add_argument("--product_types", help="适用产品类型（逗号分隔）")

    args = parser.parse_args()

    if args.list:
        list_presets()
        return

    if not args.type and not args.preset:
        print("错误：必须指定 --type 或 --preset")
        print("可用类型：", list(TEMPLATES.keys()))
        print("\n预置文档：")
        list_presets()
        sys.exit(1)

    generate(
        doc_type=args.type,
        doc_name=args.name,
        doc_code=args.code,
        version=args.version,
        preset=args.preset,
        output_file=args.output,
        product_types=args.product_types,
    )


if __name__ == "__main__":
    main()
