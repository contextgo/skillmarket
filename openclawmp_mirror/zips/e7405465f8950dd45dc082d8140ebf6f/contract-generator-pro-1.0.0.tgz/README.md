# Universal Contract Generator

专业的合同生成工具（雇佣/租房/服务等），结合自动化模板填充与法律最佳实践。

**Version:** 1.1.0

## 安装依赖

```bash
pip install -r requirements.txt
```

## 使用方法

### 1. Python API

```python
from contract_generator import ContractGenerator

# 生成单个合同
generator = ContractGenerator()
generator.load_template('templates/employment_contract.docx')
generator.set_variables({
    'company_name': '某某科技有限公司',
    'employee_name': '张三',
    'position': '高级软件工程师',
    'base_salary': 300000,
    'start_date': '2024-04-01'
})
generator.save('contract_张三.docx')
```

### 2. 批量生成

```python
from contract_generator import BatchGenerator

batch = BatchGenerator(template='offer_letter.docx')
batch.load_csv('new_hires.csv')
batch.generate_all(output_dir='offers/')
```

### 3. 命令行

```bash
# 生成单个合同
python contract_generator.py generate \
  --template employment_contract.docx \
  --vars candidate.json \
  --output contract.docx

# 批量生成
python contract_generator.py batch \
  --template offer_letter.docx \
  --csv new_hires.csv \
  --output-dir offers/

# 验证合同
python contract_generator.py validate contract.docx
```

## 模板变量

### 雇佣合同常用变量

| 变量名 | 说明 | 示例 |
|-------|------|------|
| company_name | 公司名称 | 某某科技有限公司 |
| employee_name | 员工姓名 | 张三 |
| position | 职位 | 高级软件工程师 |
| department | 部门 | 技术部 |
| base_salary | 基本工资 | 300000 |
| start_date | 入职日期 | 2024-04-01 |
| work_location | 工作地点 | 北京市朝阳区 |
| reporting_to | 汇报对象 | 技术总监 |
| probation_months | 试用期月数 | 6 |
| notice_period_days | 通知期天数 | 30 |

### 租房合同常用变量

| 变量名 | 说明 | 示例 |
|-------|------|------|
| landlord_name | 房东姓名 | 张伟 |
| tenant_name | 租客姓名 | 李娜 |
| property_address | 房屋地址 | 北京市朝阳区 XX 路 XX 号 |
| room_count | 房间数 | 2 |
| area | 面积 (平方米) | 85 |
| monthly_rent | 月租金 | 8000 |
| lease_months | 租期 (月) | 12 |
| deposit_amount | 押金金额 | 16000 |
| lease_start_date | 起租日期 | 2024 年 4 月 1 日 |
| lease_end_date | 结束日期 | 2025 年 3 月 31 日 |
| payment_method | 支付方式 | 季付/月付 |

## 功能特性

- ✅ 模板系统：支持 DOCX 格式模板
- ✅ 变量替换：自动填充占位符 (支持 [VAR] 和 {{var}} 格式)
- ✅ 批量生成：从 CSV/JSON 批量生成
- ✅ 字段验证：自动检查必填项
- ✅ 合同验证：检查合同完整性
- ✅ 错误处理：友好的错误提示

## 常见问题 (FAQ)

### Q: 提示"模板文件不存在"
**A:** 检查模板文件名是否正确，可用模板：
```bash
ls templates/*.docx
```

### Q: 变量没有替换成功
**A:** 确保 JSON 中的键名与模板中的占位符一致 (不区分大小写)

### Q: 生成的合同是乱码
**A:** 确保 JSON 文件使用 UTF-8 编码保存

### Q: 如何添加新模板
**A:** 将新的 DOCX 模板放入 `templates/` 目录，使用 `[变量名]` 格式标记占位符

## 法律免责声明

本工具提供的模板仅供参考，不构成法律意见。使用前请咨询当地合格法律顾问。

## 提示与技巧

### 快速测试
```bash
# 使用示例数据快速测试
cd ~/.easyclaw/workspace/samples
python ~/.easyclaw/skills/employment-contract-generator/contract_generator.py \
  generate -t rental_contract.docx -v rental_sample.json -o test_contract.docx
```

### 批量生成技巧
- CSV 第一行必须是变量名
- 使用 `employee_name` 或 `tenant_name` 作为文件名字段
- 大量生成时建议先测试 1-2 个

### 模板制作技巧
- 使用 `[VARIABLE_NAME]` 格式标记占位符
- 在 Word 中使用样式保持格式一致
- 复杂表格建议手动制作后添加占位符
