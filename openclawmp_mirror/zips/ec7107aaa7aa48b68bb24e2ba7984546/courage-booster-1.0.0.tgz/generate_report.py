#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
勇气加油行动方案生成器
生成Word格式的勇气行动方案文档
"""

import json
import sys
from datetime import datetime
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn

def set_chinese_font(run, font_name='微软雅黑', font_size=11, bold=False, color=None):
    """设置中文字体"""
    font = run.font
    font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
    font.size = Pt(font_size)
    font.bold = bold
    if color:
        font.color.rgb = RGBColor(*color)

def add_heading_zh(doc, text, level=1):
    """添加中文标题"""
    heading = doc.add_heading(level=level)
    run = heading.add_run(text)
    if level == 1:
        set_chinese_font(run, '微软雅黑', 18, True, (0, 112, 192))
        heading.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif level == 2:
        set_chinese_font(run, '微软雅黑', 14, True, (0, 112, 192))
    else:
        set_chinese_font(run, '微软雅黑', 12, True)
    return heading

def add_paragraph_zh(doc, text, bold=False, color=None, alignment=WD_ALIGN_PARAGRAPH.LEFT):
    """添加中文段落"""
    p = doc.add_paragraph()
    run = p.add_run(text)
    set_chinese_font(run, '微软雅黑', 11, bold, color)
    p.alignment = alignment
    return p

def generate_courage_report(user_data, output_path=None):
    """生成勇气加油行动方案Word文档"""
    
    doc = Document()
    
    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = '微软雅黑'
    style._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    
    # 封面
    doc.add_paragraph()
    doc.add_paragraph()
    doc.add_paragraph()
    
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('勇气加油行动方案')
    set_chinese_font(run, '微软雅黑', 28, True, (0, 112, 192))
    
    doc.add_paragraph()
    
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run('——为你的勇敢之旅加油')
    set_chinese_font(run, '微软雅黑', 14, False, (128, 128, 128))
    
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 日期
    date_p = doc.add_paragraph()
    date_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = date_p.add_run(f'生成日期：{datetime.now().strftime("%Y年%m月%d日")}')
    set_chinese_font(run, '微软雅黑', 11)
    
    doc.add_page_break()
    
    # 一、勇气目标
    add_heading_zh(doc, '一、你的勇气目标', 2)
    
    add_paragraph_zh(doc, '你想做什么？', bold=True)
    goal = user_data.get('goal', '_________________________________')
    add_paragraph_zh(doc, goal)
    
    add_paragraph_zh(doc, '为什么这件事对你重要？', bold=True)
    importance = user_data.get('importance', '_________________________________')
    add_paragraph_zh(doc, importance)
    
    doc.add_paragraph()
    
    # 二、恐惧拆解
    add_heading_zh(doc, '二、恐惧拆解', 2)
    
    add_paragraph_zh(doc, '最坏结果：', bold=True)
    worst_case = user_data.get('worst_case', '_________________________________')
    add_paragraph_zh(doc, worst_case)
    
    add_paragraph_zh(doc, '这个结果我能承受吗？', bold=True)
    can_handle = user_data.get('can_handle', '□ 能    □ 否')
    add_paragraph_zh(doc, can_handle)
    
    add_paragraph_zh(doc, '把大目标拆成小步骤：', bold=True)
    steps = user_data.get('steps', ['_________________________________', 
                                     '_________________________________',
                                     '_________________________________'])
    for i, step in enumerate(steps, 1):
        add_paragraph_zh(doc, f'{i}. {step}')
    
    doc.add_paragraph()
    
    # 三、底气盘点
    add_heading_zh(doc, '三、底气盘点', 2)
    
    add_paragraph_zh(doc, '我的优势（至少3个）：', bold=True)
    advantages = user_data.get('advantages', ['_________________________________',
                                               '_________________________________',
                                               '_________________________________'])
    for i, adv in enumerate(advantages, 1):
        add_paragraph_zh(doc, f'{i}. {adv}')
    
    add_paragraph_zh(doc, '我可以依靠的人：', bold=True)
    supporters = user_data.get('supporters', '_________________________________')
    add_paragraph_zh(doc, supporters)
    
    add_paragraph_zh(doc, '我以前成功克服过的困难：', bold=True)
    past_wins = user_data.get('past_wins', '_________________________________')
    add_paragraph_zh(doc, past_wins)
    
    doc.add_paragraph()
    
    # 四、行动计划
    add_heading_zh(doc, '四、行动计划', 2)
    
    add_paragraph_zh(doc, '今天就能做的5分钟行动：', bold=True)
    action_5min = user_data.get('action_5min', '_________________________________')
    add_paragraph_zh(doc, action_5min)
    
    add_paragraph_zh(doc, '本周的小挑战：', bold=True)
    weekly_challenge = user_data.get('weekly_challenge', '_________________________________')
    add_paragraph_zh(doc, weekly_challenge)
    
    add_paragraph_zh(doc, '身体准备：', bold=True)
    add_paragraph_zh(doc, '□ 深呼吸3次    □ 站直身体    □ 快走5分钟    □ 其他：____________')
    
    add_paragraph_zh(doc, '公开承诺：我要告诉_______我的计划', bold=True)
    
    doc.add_paragraph()
    
    # 五、情绪支持
    add_heading_zh(doc, '五、情绪支持', 2)
    
    add_paragraph_zh(doc, '□ 我承认我现在有点害怕，这很正常')
    add_paragraph_zh(doc, '□ 害怕不代表我不行，害怕也敢做才是勇气')
    
    add_paragraph_zh(doc, '我的打气话（重复3遍）：', bold=True)
    mantra = user_data.get('mantra', '_________________________________')
    add_paragraph_zh(doc, mantra)
    
    add_paragraph_zh(doc, '需要远离的消耗型人/环境：', bold=True)
    avoid = user_data.get('avoid', '_________________________________')
    add_paragraph_zh(doc, avoid)
    
    doc.add_paragraph()
    
    # 六、环境支持
    add_heading_zh(doc, '六、环境支持', 2)
    
    add_paragraph_zh(doc, '我可以靠近的勇敢的人：', bold=True)
    brave_people = user_data.get('brave_people', '_________________________________')
    add_paragraph_zh(doc, brave_people)
    
    add_paragraph_zh(doc, '我的榜样（谁做到过类似的事）：', bold=True)
    role_model = user_data.get('role_model', '_________________________________')
    add_paragraph_zh(doc, role_model)
    
    add_paragraph_zh(doc, '我的支持系统：', bold=True)
    support_system = user_data.get('support_system', '_________________________________')
    add_paragraph_zh(doc, support_system)
    
    doc.add_paragraph()
    
    # 七、价值确认
    add_heading_zh(doc, '七、价值确认', 2)
    
    add_paragraph_zh(doc, '我为什么要做这件事？', bold=True)
    why = user_data.get('why', '_________________________________')
    add_paragraph_zh(doc, why)
    
    add_paragraph_zh(doc, '我必须保护的3样东西：', bold=True)
    protect = user_data.get('protect', ['_________________________________',
                                         '_________________________________',
                                         '_________________________________'])
    for i, item in enumerate(protect, 1):
        add_paragraph_zh(doc, f'{i}. {item}')
    
    add_paragraph_zh(doc, '我值得________，因为我________', bold=True)
    worth = user_data.get('worth', '_________________________________')
    add_paragraph_zh(doc, worth)
    
    doc.add_paragraph()
    
    # 八、极简总结
    add_heading_zh(doc, '八、极简总结', 2)
    
    summary_box = doc.add_paragraph()
    summary_box.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = summary_box.add_run('勇气 = 看清最坏结果 + 拆小目标 + 从小行动 + 有人支持 + 知道自己为何而战')
    set_chinese_font(run, '微软雅黑', 12, True, (0, 112, 192))
    
    doc.add_paragraph()
    
    # 九、每日打卡
    add_heading_zh(doc, '九、每日打卡', 2)
    
    # 创建打卡表格
    table = doc.add_table(rows=8, cols=4)
    table.style = 'Light Grid Accent 1'
    
    # 表头
    headers = ['日期', '做了什么', '感受', '下一步']
    for i, header in enumerate(headers):
        cell = table.rows[0].cells[i]
        run = cell.paragraphs[0].add_run(header)
        set_chinese_font(run, '微软雅黑', 10, True)
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # 空行
    for row in range(1, 8):
        for col in range(4):
            cell = table.rows[row].cells[col]
            run = cell.paragraphs[0].add_run('')
            set_chinese_font(run, '微软雅黑', 10)
    
    doc.add_paragraph()
    
    # 十、给自己的话
    add_heading_zh(doc, '十、给自己的话', 2)
    
    add_paragraph_zh(doc, '写一句鼓励自己的话：')
    doc.add_paragraph()
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 结尾
    doc.add_paragraph()
    ending = doc.add_paragraph()
    ending.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = ending.add_run('💪 勇气不是不害怕，是害怕也敢做。加油！')
    set_chinese_font(run, '微软雅黑', 12, True, (0, 112, 192))
    
    # 保存文档
    if not output_path:
        output_path = f'勇气加油行动方案_{datetime.now().strftime("%Y%m%d")}.docx'
    
    doc.save(output_path)
    print(f'✅ 勇气加油行动方案已生成：{output_path}')
    return output_path

if __name__ == '__main__':
    # 示例数据
    example_data = {
        'goal': '向领导提出加薪请求',
        'importance': '我的付出应该得到相应的回报，这也是对自己价值的认可',
        'worst_case': '领导拒绝，关系暂时尴尬',
        'can_handle': '□ 能',
        'steps': [
            '准备自己的工作成果清单',
            '选择合适的时机预约谈话',
            '清晰表达诉求和理由'
        ],
        'advantages': [
            '过去一年的业绩突出',
            '承担了额外的工作责任',
            '市场行情支持加薪'
        ],
        'supporters': '我的伴侣、好友小李',
        'past_wins': '曾经成功争取过项目机会',
        'action_5min': '列出过去一年的3个主要成就',
        'weekly_challenge': '找领导预约一次谈话',
        'mantra': '我值得被公平对待',
        'avoid': '总是否定我的那个同事',
        'brave_people': '我的直属领导，他总是敢于表达',
        'role_model': '同事小张，他去年成功加薪了',
        'support_system': '伴侣、好友、导师',
        'why': '为了获得公平的回报，也为了证明自己的价值',
        'protect': ['自己的劳动价值', '职业发展的公平性', '自我尊严'],
        'worth': '我值得获得公平的薪酬，因为我付出了相应的努力并取得了成果'
    }
    
    generate_courage_report(example_data)
