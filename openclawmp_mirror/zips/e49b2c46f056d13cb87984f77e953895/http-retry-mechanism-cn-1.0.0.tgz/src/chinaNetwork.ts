/**
 * 中国大陆网络优化
 * 针对国内网络环境的特殊优化
 */

// 国内常用 DNS 服务器
const DEFAULT_CHINA_DNS_SERVERS = [
  '223.5.5.5',    // 阿里 DNS
  '223.6.6.6',    // 阿里 DNS
  '119.29.29.29', // 腾讯 DNS
  '114.114.114.114', // 114 DNS
  '180.76.76.76', // 百度 DNS
];

// 国内直连域名列表
const DEFAULT_CHINA_DIRECT_DOMAINS = [
  '.cn',
  'aliyun.com',
  'alicdn.com',
  'taobao.com',
  'tmall.com',
  'jd.com',
  'qq.com',
  'bilibili.com',
  'baidu.com',
  'weibo.com',
  'douyin.com',
  'huaweicloud.com',
  'tencentcloud.com',
];

// 海外代理域名列表
const DEFAULT_OVERSEAS_PROXY_DOMAINS = [
  'github.com',
  'raw.githubusercontent.com',
  'npmjs.com',
  'registry.npmjs.org',
  'docker.io',
  'google.com',
  'youtube.com',
  'twitter.com',
  'x.com',
  'openai.com',
  'huggingface.co',
];

export interface ChinaNetworkConfig {
  enableChinaDNS: boolean;
  chinaDNSServers: string[];
  enableSmartRouting: boolean;
  chinaDirectDomains: string[];
  overseasProxyDomains: string[];
}

export class ChinaNetworkOptimizer {
  private config: ChinaNetworkConfig;

  constructor(config?: Partial<ChinaNetworkConfig>) {
    this.config = {
      enableChinaDNS: true,
      chinaDNSServers: DEFAULT_CHINA_DNS_SERVERS,
      enableSmartRouting: true,
      chinaDirectDomains: DEFAULT_CHINA_DIRECT_DOMAINS,
      overseasProxyDomains: DEFAULT_OVERSEAS_PROXY_DOMAINS,
      ...config
    };
  }

  /**
   * 判断是否需要代理
   */
  shouldUseProxy(url: string): boolean {
    if (!this.config.enableSmartRouting) {
      return false;
    }

    const hostname = new URL(url).hostname.toLowerCase();

    // 检查是否在国内直连列表
    for (const domain of this.config.chinaDirectDomains) {
      if (hostname === domain || hostname.endsWith(domain)) {
        return false;
      }
    }

    // 检查是否在海外代理列表
    for (const domain of this.config.overseasProxyDomains) {
      if (hostname === domain || hostname.endsWith(domain)) {
        return true;
      }
    }

    // 默认国内直连
    return false;
  }

  /**
   * 获取统计信息
   */
  getStats(): {
    config: ChinaNetworkConfig;
  } {
    return {
      config: this.config
    };
  }
}

export const chinaNetworkOptimizer = new ChinaNetworkOptimizer();
