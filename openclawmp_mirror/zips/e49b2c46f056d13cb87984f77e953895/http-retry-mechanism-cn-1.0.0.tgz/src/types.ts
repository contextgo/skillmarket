/**
 * HTTP 重试机制类型定义 (中国大陆优化版)
 */

export interface RetryConfig {
  maxRetries: number;
  initialDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
  enableJitter: boolean;
  jitterFactor: number;
  retryableErrors: string[];
  retryableStatusCodes: number[];
}

export type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

export interface CircuitBreakerConfig {
  failureThreshold: number;
  successThreshold: number;
  timeoutMs: number;
}

export interface TimeoutConfig {
  requestTimeoutMs: number;
  connectTimeoutMs: number;
}

export interface ChinaNetworkConfig {
  enableChinaDNS: boolean;
  chinaDNSServers: string[];
  enableSmartRouting: boolean;
  chinaDirectDomains: string[];
  overseasProxyDomains: string[];
}

export interface HttpResponse<T = unknown> {
  data: T;
  status: number;
  retries: number;
  durationMs: number;
}

export class HttpError extends Error {
  constructor(
    message: string,
    public readonly code: string,
    public readonly status?: number,
    public readonly retries: number = 0
  ) {
    super(message);
    this.name = 'HttpError';
  }
}
