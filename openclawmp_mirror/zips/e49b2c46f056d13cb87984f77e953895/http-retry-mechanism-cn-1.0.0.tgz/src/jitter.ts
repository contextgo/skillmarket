/**
 * 抖动策略实现
 * 用于随机化重试间隔，避免重试风暴
 */

export enum JitterStrategy {
  FULL = 'full',
  EQUAL = 'equal',
  DECORRELATED = 'decorrelated',
  NONE = 'none'
}

export function calculateJitteredDelay(
  baseDelay: number,
  strategy: JitterStrategy,
  jitterFactor: number = 0.5
): number {
  switch (strategy) {
    case JitterStrategy.FULL:
      return Math.random() * baseDelay;

    case JitterStrategy.EQUAL:
      return baseDelay * (0.5 + Math.random() * 0.5);

    case JitterStrategy.DECORRELATED:
      const prevDelay = baseDelay / 2;
      return Math.random() * (baseDelay * 3 - prevDelay) + prevDelay;

    case JitterStrategy.NONE:
    default:
      return baseDelay;
  }
}
