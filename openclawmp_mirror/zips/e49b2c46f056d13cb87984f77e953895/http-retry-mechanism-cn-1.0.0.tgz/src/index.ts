/**
 * HTTP 重试机制 Skill (中国大陆优化版) - 主入口
 * 版本: 2.0.0
 * 来源: EvoMap 胶囊 (GDI 64.6)
 */

export * from './types';
export { ChinaNetworkOptimizer, chinaNetworkOptimizer } from './chinaNetwork';
export { JitterStrategy, calculateJitteredDelay } from './jitter';

import { RetryConfig, HttpResponse, HttpError, ChinaNetworkConfig } from './types';
import { ChinaNetworkOptimizer } from './chinaNetwork';
import { JitterStrategy, calculateJitteredDelay } from './jitter';

// 默认配置
const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxRetries: 3,
  initialDelayMs: 1000,
  maxDelayMs: 30000,
  backoffMultiplier: 2,
  enableJitter: true,
  jitterFactor: 0.5,
  retryableErrors: ['ECONNRESET', 'ECONNREFUSED', 'ETIMEDOUT', 'timeout_error'],
  retryableStatusCodes: [408, 429, 500, 502, 503, 504]
};

// 国内网络优化器
const chinaOptimizer = new ChinaNetworkOptimizer();

/**
 * 计算延迟（指数退避 + 抖动）
 */
function calculateDelay(attempt: number, config: RetryConfig): number {
  let delay = config.initialDelayMs * Math.pow(config.backoffMultiplier, attempt);
  delay = Math.min(delay, config.maxDelayMs);
  
  if (config.enableJitter) {
    delay = calculateJitteredDelay(delay, JitterStrategy.EQUAL, config.jitterFactor);
  }
  
  return Math.max(0, Math.floor(delay));
}

/**
 * 检查是否应该重试
 */
function shouldRetry(error: Error, statusCode?: number, config: RetryConfig): boolean {
  if (statusCode && config.retryableStatusCodes.includes(statusCode)) {
    return true;
  }
  
  const errorCode = (error as any).code || error.message;
  return config.retryableErrors.some(e => errorCode.includes(e));
}

/**
 * 睡眠函数
 */
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 带重试的 HTTP GET 请求（中国大陆优化版）
 */
export async function get<T = unknown>(
  url: string,
  options: { 
    retry?: Partial<RetryConfig>; 
    timeout?: number;
    chinaNetwork?: Partial<ChinaNetworkConfig>;
  } = {}
): Promise<T> {
  const config = { ...DEFAULT_RETRY_CONFIG, ...options.retry };
  const timeout = options.timeout || 30000;
  
  // 国内网络优化提示
  const useProxy = chinaOptimizer.shouldUseProxy(url);
  if (useProxy) {
    console.log(`[HTTP Retry CN] 检测到海外域名，建议使用代理: ${url}`);
  }
  
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
    const startTime = Date.now();
    
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);
      
      const response = await fetch(url, {
        method: 'GET',
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new HttpError(
          `HTTP ${response.status}: ${response.statusText}`,
          'http_error',
          response.status,
          attempt
        );
      }
      
      const data = await response.json();
      return data as T;
      
    } catch (error) {
      lastError = error as Error;
      const statusCode = (error as HttpError).status;
      
      if (attempt < config.maxRetries && shouldRetry(lastError, statusCode, config)) {
        const delay = calculateDelay(attempt, config);
        console.log(`[HTTP Retry CN] 第 ${attempt + 1} 次失败，${delay}ms 后重试...`);
        await sleep(delay);
      } else {
        break;
      }
    }
  }
  
  throw lastError || new HttpError('请求失败', 'unknown_error');
}

/**
 * 带重试的 HTTP POST 请求（中国大陆优化版）
 */
export async function post<T = unknown>(
  url: string,
  body: unknown,
  options: { 
    retry?: Partial<RetryConfig>; 
    timeout?: number;
    chinaNetwork?: Partial<ChinaNetworkConfig>;
  } = {}
): Promise<T> {
  const config = { ...DEFAULT_RETRY_CONFIG, ...options.retry };
  const timeout = options.timeout || 30000;
  
  let lastError: Error | null = null;
  
  for (let attempt = 0; attempt <= config.maxRetries; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), timeout);
      
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (!response.ok) {
        throw new HttpError(
          `HTTP ${response.status}: ${response.statusText}`,
          'http_error',
          response.status,
          attempt
        );
      }
      
      const data = await response.json();
      return data as T;
      
    } catch (error) {
      lastError = error as Error;
      const statusCode = (error as HttpError).status;
      
      if (attempt < config.maxRetries && shouldRetry(lastError, statusCode, config)) {
        const delay = calculateDelay(attempt, config);
        console.log(`[HTTP Retry CN] 第 ${attempt + 1} 次失败，${delay}ms 后重试...`);
        await sleep(delay);
      } else {
        break;
      }
    }
  }
  
  throw lastError || new HttpError('请求失败', 'unknown_error');
}

/**
 * 获取国内网络优化状态
 */
export function getChinaNetworkStats() {
  return chinaOptimizer.getStats();
}

// 版本信息
export const VERSION = '2.0.0';
export const SOURCE_CAPSULE = 'sha256:6c8b2bef4652d5113cc802b6995a8e9f5da8b5b1ffe3d6bc639e2ca8ce27edec';
export const GDI_SCORE = 64.6;
