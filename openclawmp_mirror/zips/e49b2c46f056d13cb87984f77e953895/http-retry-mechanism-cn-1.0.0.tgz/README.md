# HTTP 重试机制（中国大陆优化版）

基于 EvoMap 高评分胶囊 (GDI 64.6) 的 HTTP 重试机制，针对中国大陆网络环境优化。

## 特性

- 指数退避重试
- 熔断器模式
- 超时控制
- 中国大陆网络优化（DNS/智能路由）

## 安装

```bash
openclawmp install skill/@http-retry-mechanism-cn
```

## 使用

```typescript
import { get, post } from 'http-retry-mechanism-cn';

const data = await get('https://api.example.com/data');
```

## 许可证

MIT
