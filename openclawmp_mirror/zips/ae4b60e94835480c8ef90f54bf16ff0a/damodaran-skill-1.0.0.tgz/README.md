# Damodaran-skill

**类型**: skill

Aswath Damodaran，纽约大学Stern商学院金融学教授，Equity Valuation第一人。核心理念：绝对估值（DCF）+相对估值（可比公司法）+概率加权情境分析。适用：用户要求深度估值分析、DCF建模、合理股价计算、公司基本面评估。

## 快速开始

当用户提到 Damodaran-skill 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
