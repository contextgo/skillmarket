---
name: load-testing
description: 压力测试助手。用于设计压测方案、执行负载测试、分析测试结果。当需要进行压力测试、性能测试时触发。
---

# 压力测试助手

## 压测类型

| 类型 | 说明 | 持续时间 |
|------|------|----------|
| 基准测试 | 确定单用户性能 | 短 |
| 负载测试 | 验证正常负载 | 中 |
| 压力测试 | 找出系统极限 | 中 |
| 浸泡测试 | 长时间稳定运行 | 长 |

## 压测指标

| 指标 | 说明 | 目标值 |
|------|------|--------|
| QPS | 每秒请求数 | > 1000 |
| 响应时间P50 | 中位数响应时间 | < 100ms |
| 响应时间P95 | 95分位响应时间 | < 500ms |
| 响应时间P99 | 99分位响应时间 | < 1000ms |
| 错误率 | 失败请求比例 | < 1% |
| CPU使用率 | 服务端CPU | < 80% |
| 内存使用率 | 服务端内存 | < 80% |

## 压测方案模板

```markdown
# 压力测试方案

## 1. 测试目标

| 指标 | 当前值 | 目标值 |
|------|--------|--------|
| QPS | 500 | 2000 |
| P99响应时间 | 500ms | 300ms |
| 错误率 | 0.1% | < 0.1% |

## 2. 测试范围

- 测试接口：/api/v1/products
- 测试并发：100-1000
- 测试时长：10分钟/阶段

## 3. 测试场景

### 场景1：阶梯加压
| 阶段 | 并发数 | 持续时间 |
|------|--------|----------|
| 预热 | 10 | 1分钟 |
| 阶段1 | 50 | 5分钟 |
| 阶段2 | 100 | 5分钟 |
| 阶段3 | 200 | 5分钟 |
| 阶段4 | 500 | 5分钟 |
| 峰值 | 1000 | 5分钟 |

### 场景2：脉冲测试
模拟突发流量高峰

## 4. 测试环境

| 项目 | 配置 |
|------|------|
| 应用服务器 | 4核8G × 2 |
| 数据库 | 8核16G |
| 网络 | 内网 |
```

## 压测脚本

### JMeter脚本
```xml
<?xml version="1.0" encoding="UTF-8"?>
<jmeterTestPlan>
  <hashTree>
    <TestPlan>
      <stringProp name="TestPlan.name">Product API Load Test</stringProp>
    </TestPlan>
    <hashTree>
      <ThreadGroup>
        <stringProp name="ThreadGroup.num_threads">100</stringProp>
        <stringProp name="ThreadGroup.duration">600</stringProp>
        <stringProp name="ThreadGroup.ramp_time">60</stringProp>
      </ThreadGroup>
      <hashTree>
        <HTTPSamplerProxy>
          <stringProp name="HTTPSampler.domain">api.example.com</stringProp>
          <stringProp name="HTTPSampler.path">/api/v1/products</stringProp>
          <stringProp name="HTTPSampler.method">GET</stringProp>
        </HTTPSamplerProxy>
      </hashTree>
    </hashTree>
  </hashTree>
</jmeterTestPlan>
```

### Locust脚本
```python
from locust import HttpUser, task, between

class ProductUser(HttpUser):
    wait_time = between(1, 3)
    
    @task
    def get_products(self):
        self.client.get("/api/v1/products")
    
    @task(3)
    def get_product_detail(self):
        product_id = random.randint(1, 1000)
        self.client.get(f"/api/v1/products/{product_id}")
    
    @task(2)
    def search_products(self):
        self.client.get("/api/v1/products?keyword=手机")

# 运行
# locust -f locustfile.py --host=https://api.example.com
```

### wrk压测
```bash
# 基础压测
wrk -t12 -c400 -d30s https://api.example.com/api/v1/products

# 带Lua脚本
wrk -t12 -c400 -d30s -s post.lua https://api.example.com/api/v1/orders

# post.lua
wrk.method = "POST"
wrk.body   = '{"user_id":1,"product_id":1}'
wrk.headers["Content-Type"] = "application/json"
```

## 测试执行流程

```markdown
## 压测执行

### 1. 环境准备
- [ ] 测试环境部署完成
- [ ] 数据库数据准备
- [ ] 监控告警就绪
- [ ] 测试账号准备

### 2. 预热
```bash
# 预热请求
for i in {1..10}; do
  curl https://api.example.com/api/v1/products
done
```

### 3. 执行测试
```bash
# 启动监控
./monitor.sh &

# 执行压测
locust -f locustfile.py --headless -u 1000 -r 100 -t 10m

# 停止监控
./stop_monitor.sh
```

### 4. 数据收集
- [ ] TPS数据
- [ ] 响应时间分布
- [ ] 错误日志
- [ ] 资源使用情况
```

## 测试报告模板

```markdown
# 压力测试报告

测试时间：YYYY-MM-DD HH:MM
测试环境：测试环境
测试工具：Locust

---

## 测试结果

### 核心指标
| 指标 | 目标值 | 实测值 | 达成 |
|------|--------|--------|------|
| QPS | 2000 | 2156 | ✓ |
| P99 | 300ms | 280ms | ✓ |
| 错误率 | <1% | 0.05% | ✓ |

### 详细数据
| 并发 | QPS | P50 | P95 | P99 | 错误率 |
|------|-----|------|------|------|--------|
| 100 | 520 | 45ms | 80ms | 120ms | 0% |
| 500 | 1850 | 120ms | 250ms | 400ms | 0.02% |
| 1000 | 2156 | 280ms | 500ms | 800ms | 0.05% |

---

## 瓶颈分析

### 发现的问题
1. 数据库连接池耗尽
2. 缓存命中率低

### 优化建议
1. 增加数据库连接池
2. 优化缓存策略
```

## 常见问题处理

| 问题 | 原因 | 解决方案 |
|------|------|----------|
| 连接拒绝 | 并发过高 | 增加连接数限制 |
| 响应超时 | 服务端慢 | 优化SQL/增加资源 |
| 内存泄漏 | 长连接 | 检查内存泄漏 |
| CPU爆满 | 业务逻辑重 | 代码优化/扩容 |
