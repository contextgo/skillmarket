#!/usr/bin/env python3
"""
Context Compression Tool - 上下文压缩工具
用于压缩上下文而不损伤记忆的核心脚本
"""

import json
import os
import re
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
import argparse
import hashlib


class ContextCompressor:
    """上下文压缩器"""
    
    def __init__(self, workspace_path: str = "/Users/qio/.openclaw/workspace"):
        self.workspace_path = Path(workspace_path)
        self.memory_path = self.workspace_path / "memory"
        self.compression_log = self.workspace_path / ".context-compression.log"
        self.backup_path = self.workspace_path / ".context-backup"
        
        # 确保备份目录存在
        self.backup_path.mkdir(exist_ok=True)
        
        # 压缩配置
        self.config = {
            'compression_ratio': 0.75,  # 75%压缩比例
            'preserve_rules': {
                'high_priority': [
                    '决策', '决定', '选择', '重要经验', '核心原则', 
                    '用户偏好', '关键配置', '重大事件', '创新想法'
                ],
                'medium_priority': [
                    '常用模式', '标准流程', '工具配置', '最佳实践',
                    '工作方法', '协作方式', '技术方案'
                ],
                'low_priority': [
                    '历史操作', '重复任务', '详细日志', '参考信息',
                    '临时记录', '测试数据', '调试信息'
                ]
            },
            'time_windows': {
                'current': 1,      # 当前层：1天
                'working': 7,      # 工作层：7天
                'persistent': 30,  # 持久层：30天
                'archive': 365     # 归档层：365天
            }
        }
    
    def compress_context(self, 
                        source_path: str, 
                        strategy: str = 'smart',
                        mode: str = 'auto') -> Dict[str, Any]:
        """
        压缩上下文数据
        
        Args:
            source_path: 源文件路径
            strategy: 压缩策略 ('smart', 'aggressive', 'conservative')
            mode: 压缩模式 ('auto', 'manual', 'emergency')
        
        Returns:
            压缩结果字典
        """
        print(f"🗜️ 开始压缩上下文: {source_path}")
        print(f"📊 策略: {strategy}, 模式: {mode}")
        
        # 读取源文件
        source_file = Path(source_path)
        if not source_file.exists():
            raise FileNotFoundError(f"源文件不存在: {source_file}")
        
        with open(source_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 备份原始文件
        backup_file = self.backup_path / f"{source_file.name}.backup.{int(time.time())}"
        with open(backup_file, 'w', encoding='utf-8') as f:
            f.write(content)
        
        # 执行压缩
        original_size = len(content)
        compressed_content = self._apply_compression(content, strategy)
        compressed_size = len(compressed_content)
        
        # 计算压缩比例
        compression_ratio = (original_size - compressed_size) / original_size if original_size > 0 else 0
        
        # 保存压缩后的文件
        if mode != 'dry_run':
            compressed_file = source_file.with_suffix('.compressed.md')
            with open(compressed_file, 'w', encoding='utf-8') as f:
                f.write(compressed_content)
            
            # 记录压缩日志
            self._log_compression(source_file, compressed_file, {
                'original_size': original_size,
                'compressed_size': compressed_size,
                'compression_ratio': compression_ratio,
                'strategy': strategy,
                'mode': mode,
                'timestamp': datetime.now().isoformat()
            })
            
            print(f"✅ 压缩完成!")
            print(f"📏 原始大小: {original_size} 字符")
            print(f"📏 压缩大小: {compressed_size} 字符")
            print(f"📊 压缩比例: {compression_ratio:.2%}")
            print(f"💾 备份位置: {backup_file}")
        
        return {
            'success': True,
            'original_size': original_size,
            'compressed_size': compressed_size,
            'compression_ratio': compression_ratio,
            'strategy': strategy,
            'mode': mode,
            'backup_file': str(backup_file)
        }
    
    def _apply_compression(self, content: str, strategy: str) -> str:
        """
        应用压缩算法
        
        Args:
            content: 原始内容
            strategy: 压缩策略
        
        Returns:
            压缩后的内容
        """
        lines = content.split('\n')
        compressed_lines = []
        
        for line in lines:
            if not line.strip():
                compressed_lines.append(line)
                continue
            
            # 检查是否应该保留
            if self._should_preserve(line, strategy):
                compressed_lines.append(line)
            else:
                # 应用压缩
                compressed_line = self._compress_line(line, strategy)
                compressed_lines.append(compressed_line)
        
        return '\n'.join(compressed_lines)
    
    def _should_preserve(self, line: str, strategy: str) -> bool:
        """
        判断是否应该保留该行
        
        Args:
            line: 行内容
            strategy: 压缩策略
        
        Returns:
            是否应该保留
        """
        # 高优先级规则 - 总是保留
        for rule in self.config['preserve_rules']['high_priority']:
            if rule in line:
                return True
        
        # 根据策略调整保留规则
        if strategy == 'conservative':
            # 保守策略：保留更多信息
            for rule in self.config['preserve_rules']['medium_priority']:
                if rule in line:
                    return True
        elif strategy == 'aggressive':
            # 激进策略：压缩更多信息
            pass
        
        # 检查是否为重要结构
        if any(marker in line for marker in ['##', '###', '###', '**']):
            return True
        
        # 检查是否为决策或结论
        if any(marker in line for marker in ['决策', '决定', '结论', '总结', '建议']):
            return True
        
        return False
    
    def _compress_line(self, line: str, strategy: str) -> str:
        """
        压缩单行内容
        
        Args:
            line: 行内容
            strategy: 压缩策略
        
        Returns:
            压缩后的行内容
        """
        # 移除多余的空格
        compressed = re.sub(r'\s+', ' ', line.strip())
        
        # 移除常见的冗余词汇
        redundant_words = ['的', '了', '在', '中', '和', '与', '以及', '并且']
        for word in redundant_words:
            compressed = compressed.replace(word, '')
        
        # 如果压缩后为空，返回占位符
        if not compressed.strip():
            return '# [已压缩的空行]'
        
        return compressed
    
    def compress_memory_file(self, date: str = None, strategy: str = 'smart') -> Dict[str, Any]:
        """
        压缩memory文件
        
        Args:
            date: 日期 (YYYY-MM-DD)，默认为今天
            strategy: 压缩策略
        
        Returns:
            压缩结果
        """
        if not date:
            date = datetime.now().strftime('%Y-%m-%d')
        
        memory_file = self.memory_path / f"{date}.md"
        if not memory_file.exists():
            print(f"⚠️ Memory文件不存在: {memory_file}")
            return {'success': False, 'error': 'Memory文件不存在'}
        
        return self.compress_context(str(memory_file), strategy, 'auto')
    
    def compress_memory_md(self, strategy: str = 'conservative') -> Dict[str, Any]:
        """
        压缩MEMORY.md文件
        
        Args:
            strategy: 压缩策略
        
        Returns:
            压缩结果
        """
        memory_md = self.workspace_path / "MEMORY.md"
        if not memory_md.exists():
            print(f"⚠️ MEMORY.md文件不存在: {memory_md}")
            return {'success': False, 'error': 'MEMORY.md文件不存在'}
        
        return self.compress_context(str(memory_md), strategy, 'auto')
    
    def monitor_context_usage(self) -> Dict[str, Any]:
        """
        监控上下文使用情况
        
        Returns:
            监控结果
        """
        print("📊 监控上下文使用情况...")
        
        # 检查各文件大小
        files_to_check = [
            self.workspace_path / "MEMORY.md",
            self.workspace_path / "SOUL.md",
            self.workspace_path / "USER.md",
            self.memory_path / f"{datetime.now().strftime('%Y-%m-%d')}.md"
        ]
        
        usage_stats = {}
        total_size = 0
        
        for file_path in files_to_check:
            if file_path.exists():
                size = file_path.stat().st_size
                usage_stats[str(file_path)] = size
                total_size += size
                print(f"📁 {file_path.name}: {size} 字符")
            else:
                print(f"⚠️ 文件不存在: {file_path}")
        
        print(f"📊 总计: {total_size} 字符")
        
        # 估算上下文使用比例
        estimated_context_ratio = min(total_size / 1000000, 1.0)  # 假设1M字符为100%
        
        if estimated_context_ratio > 0.6:
            print("⚠️ 上下文使用率过高，建议压缩")
            suggestion = "建议执行压缩操作"
        elif estimated_context_ratio > 0.4:
            print("⚠️ 上下文使用率中等，可以考虑优化")
            suggestion = "可以考虑轻度压缩"
        else:
            print("✅ 上下文使用率正常")
            suggestion = "当前状态良好"
        
        return {
            'total_size': total_size,
            'usage_stats': usage_stats,
            'estimated_context_ratio': estimated_context_ratio,
            'suggestion': suggestion,
            'timestamp': datetime.now().isoformat()
        }
    
    def _log_compression(self, source_file: Path, compressed_file: Path, result: Dict[str, Any]):
        """
        记录压缩日志
        
        Args:
            source_file: 源文件路径
            compressed_file: 压缩后文件路径
            result: 压缩结果
        """
        log_entry = {
            'timestamp': datetime.now().isoformat(),
            'source_file': str(source_file),
            'compressed_file': str(compressed_file),
            'result': result
        }
        
        # 读取现有日志
        log_data = []
        if self.compression_log.exists():
            with open(self.compression_log, 'r', encoding='utf-8') as f:
                try:
                    log_data = json.load(f)
                except:
                    log_data = []
        
        # 添加新日志
        log_data.append(log_entry)
        
        # 保存日志
        with open(self.compression_log, 'w', encoding='utf-8') as f:
            json.dump(log_data, f, indent=2, ensure_ascii=False)
    
    def get_compression_stats(self) -> Dict[str, Any]:
        """
        获取压缩统计信息
        
        Returns:
            统计信息
        """
        if not self.compression_log.exists():
            return {'success': False, 'error': '压缩日志不存在'}
        
        with open(self.compression_log, 'r', encoding='utf-8') as f:
            log_data = json.load(f)
        
        stats = {
            'total_compressions': len(log_data),
            'total_original_size': 0,
            'total_compressed_size': 0,
            'average_compression_ratio': 0,
            'strategies_used': {},
            'recent_compressions': log_data[-5:] if len(log_data) > 5 else log_data
        }
        
        for entry in log_data:
            result = entry['result']
            stats['total_original_size'] += result['original_size']
            stats['total_compressed_size'] += result['compressed_size']
            
            strategy = result['strategy']
            if strategy not in stats['strategies_used']:
                stats['strategies_used'][strategy] = 0
            stats['strategies_used'][strategy] += 1
        
        if stats['total_original_size'] > 0:
            stats['average_compression_ratio'] = (
                stats['total_original_size'] - stats['total_compressed_size']
            ) / stats['total_original_size']
        
        return stats


def main():
    """主函数"""
    parser = argparse.ArgumentParser(description='Context Compression Tool - 上下文压缩工具')
    parser.add_argument('--action', choices=[
        'compress', 'monitor', 'stats', 'auto'
    ], default='compress', help='执行的操作')
    
    parser.add_argument('--source', type=str, help='要压缩的文件路径')
    parser.add_argument('--strategy', choices=['smart', 'aggressive', 'conservative'], 
                       default='smart', help='压缩策略')
    parser.add_argument('--mode', choices=['auto', 'manual', 'emergency'], 
                       default='auto', help='压缩模式')
    parser.add_argument('--date', type=str, help='日期 (YYYY-MM-DD)')
    parser.add_argument('--dry-run', action='store_true', help='试运行模式')
    
    args = parser.parse_args()
    
    # 创建压缩器实例
    compressor = ContextCompressor()
    
    try:
        if args.action == 'compress':
            if args.source:
                # 压缩指定文件
                result = compressor.compress_context(
                    args.source, 
                    args.strategy, 
                    args.mode
                )
            else:
                # 压缩memory文件
                if args.date:
                    result = compressor.compress_memory_file(args.date, args.strategy)
                else:
                    result = compressor.compress_memory_md(args.strategy)
        
        elif args.action == 'monitor':
            # 监控上下文使用情况
            result = compressor.monitor_context_usage()
        
        elif args.action == 'stats':
            # 获取压缩统计信息
            result = compressor.get_compression_stats()
        
        elif args.action == 'auto':
            # 自动压缩
            print("🤖 自动压缩模式启动...")
            
            # 监控使用情况
            monitor_result = compressor.monitor_context_usage()
            
            if monitor_result['estimated_context_ratio'] > 0.6:
                print("🗜️ 执行自动压缩...")
                result = compressor.compress_memory_file(strategy='aggressive')
            else:
                print("✅ 上下文使用率正常，无需压缩")
                result = {'success': True, 'message': '无需压缩'}
        
        # 输出结果
        print("\n" + "="*50)
        print("📊 执行结果:")
        print(json.dumps(result, indent=2, ensure_ascii=False))
        
    except Exception as e:
        print(f"❌ 执行失败: {e}")
        return 1
    
    return 0


if __name__ == '__main__':
    exit(main())