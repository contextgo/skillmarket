---
name: multi-agent-patterns
version: 1.0.0
description: 多 Agent 协作模式实战指南。Use when 需要设计多 Agent 系统、拆分复杂任务给子 Agent、建立 Agent 间通信协议。Don't use when 单个 Agent 就能完成的简单任务、不需要并行或分工的场景。
tags:
  - multi-agent
  - orchestration
  - openclaw
  - subagent
---

# 多 Agent 协作模式实战手册

单个 Agent 上下文有限、能力有边界。当任务足够复杂，需要多个 Agent 分工协作。本 Skill 覆盖从"要不要用多 Agent"的判断，到协议设计、隔离机制和避坑指南的完整实践。

## 适用场景

✅ **Use when:**
- 单个 Agent 上下文不够用，任务需要拆分
- 子任务之间相对独立，可以并行
- 需要不同 Agent 承担不同角色（编码、审查、测试）
- 长任务需要跨 session 持续推进

❌ **Don't use when:**
- 单 Agent 能搞定，别为了"多 Agent"而多 Agent
- 子任务之间高度耦合，拆了反而更慢
- 还没建好单 Agent 的评测和验证体系

---

## 核心原则：先隔离，再协作

顺序不能反：

```
1. 协议先定 → 结构化消息格式，不靠自然语言对齐
2. 隔离先做 → 每个 Agent 独立上下文、独立工作目录
3. 再谈协作 → 任务分派、结果汇总
4. 最后并行 → 确认无竞态后才开并发
```

**过早引入多 Agent 是最常见的反模式。** 协调开销很容易超过并行收益。

---

## 第一章：两种工作模式

### 1.1 指挥者模式（同步协作）

人与单个 Agent 紧密互动，每轮都可调整方向。

```
人 ←→ 主 Agent ←→ 工具
     （每轮交互）
```

- 适合：探索性任务、需要频繁调整方向
- 缺点：session 结束，context 就没了

### 1.2 统筹者模式（异步委派）

人在开始时设定目标，中间让多个 Agent 并行工作，最后审查产出。

```
人 → 主 Agent → 子 Agent A → PR/分支
              → 子 Agent B → PR/分支
              → 子 Agent C → PR/分支
人 ← 主 Agent ← 汇总结果
```

- 适合：可拆分的明确任务、代码生成、批量处理
- 产出物是可持久化工件（PR、文件、报告），不是对话
- **核心价值：把人的持续参与变成对工件的最终审核**

---

## 第二章：子 Agent 设计

### 2.1 什么时候用子 Agent

| 场景 | 用子 Agent | 不用子 Agent |
|---|---|---|
| 搜索+试错过程 | ✅ 探索细节不污染主上下文 | |
| 独立的编码任务 | ✅ 隔离工作目录 | |
| 简单的单步操作 | | ✅ 直接调用工具 |
| 需要主上下文的决策 | | ✅ 在主 Agent 内完成 |

### 2.2 子 Agent 只回传摘要

子 Agent 的搜索、试错和调试过程不应进入主 Agent 上下文：

```python
# 子 Agent 有独立的 messages[]
result = run_agent_loop(task, messages=[])

# 主 Agent 只收到一行摘要
return summarize(result)
```

### 2.3 最小系统提示

子 Agent 只给三节内容，不带 Skills 和 Memory：

```markdown
## Tooling
可用工具列表...

## Workspace
工作目录: /path/to/workspace

## Runtime
当前时间、环境信息...
```

**不给的：**
- Skills 索引（避免权限外泄）
- MEMORY.md（避免破坏隔离）
- 主 Agent 的身份和约束（不需要）

### 2.4 深度限制

防止子 Agent 无限递归生成孙 Agent：

```json
{
  "subagents": {
    "maxDepth": 2,
    "maxConcurrent": 8
  }
}
```

---

## 第三章：OpenClaw 中的多 Agent 实践

### 3.1 使用 sessions_spawn 创建子 Agent

```javascript
// 一次性任务（mode: "run"）
sessions_spawn({
  task: "分析 src/ 目录下所有 TODO 注释，按优先级分类",
  mode: "run",
  runtime: "subagent"
})

// 持久会话（mode: "session"）
sessions_spawn({
  task: "你是代码审查 Agent，负责审查提交到 main 分支的 PR",
  mode: "session",
  label: "code-reviewer",
  runtime: "subagent"
})
```

### 3.2 向子 Agent 发送消息

```javascript
// 通过 label 定位
sessions_send({
  label: "code-reviewer",
  message: "请审查 PR #42"
})

// 通过 sessionKey 定位
sessions_send({
  sessionKey: "agent:main:sub-abc123",
  message: "更新进度"
})
```

### 3.3 管理子 Agent

```javascript
// 查看所有子 Agent
subagents({ action: "list" })

// 干预正在运行的子 Agent
subagents({ action: "steer", target: "code-reviewer", message: "暂停当前任务" })

// 终止子 Agent
subagents({ action: "kill", target: "code-reviewer" })
```

### 3.4 等待子 Agent 完成

```javascript
// 派发后让出当前轮次，等子 Agent 完成后再继续
sessions_spawn({ task: "...", mode: "run" })
sessions_yield({ message: "等待子 Agent 完成分析..." })
// 下一条消息会是子 Agent 的结果
```

---

## 第四章：通信协议设计

### 4.1 为什么不能用自然语言协作

模型记不稳谁承诺了什么，也记不稳谁在等谁的结果。任务一旦有依赖关系，必须用结构化协议。

### 4.2 JSONL Inbox 协议

每个 Agent 有独立的 inbox 文件，append-only：

```
.team/inbox/agent-a.jsonl
.team/inbox/agent-b.jsonl
```

消息结构：

```json
{
  "request_id": "req-001",
  "from_agent": "orchestrator",
  "to_agent": "agent-a",
  "content": "实现用户登录模块，包含 JWT 验证",
  "status": "pending",
  "timestamp": "2026-03-25T10:00:00Z"
}
```

状态流转：`pending` → `approved` / `rejected`

### 4.3 任务图管理依赖

```json
{
  "tasks": [
    {"id": "t1", "desc": "设计数据库 schema", "deps": [], "assignee": "agent-a", "status": "completed"},
    {"id": "t2", "desc": "实现 API 接口", "deps": ["t1"], "assignee": "agent-b", "status": "in_progress"},
    {"id": "t3", "desc": "编写前端页面", "deps": ["t2"], "assignee": "agent-c", "status": "blocked"}
  ]
}
```

规则：
- 有未完成依赖的任务标记为 `blocked`
- 同一时间每个 Agent 只处理一个 `in_progress` 任务
- 完成后更新状态并通知下游

---

## 第五章：文件隔离

### 5.1 Worktree 隔离

每个子 Agent 在独立的 git worktree 中工作，避免文件冲突：

```bash
# 为子 Agent 创建独立工作树
git worktree add .worktrees/agent-a -b feature/login
git worktree add .worktrees/agent-b -b feature/api
```

### 5.2 合并策略

子 Agent 完成后，主 Agent 负责合并：

```bash
# 审查子 Agent 的改动
git diff main...feature/login

# 合并到主分支
git merge feature/login

# 清理工作树
git worktree remove .worktrees/agent-a
```

---

## 第六章：避坑指南

### 6.1 幻觉放大效应

多 Agent 互动时错误会逐层放大：

```
Agent A 产生轻微偏差
  → Agent B 基于 A 的结果强化偏差
    → Agent C 继续叠加
      → 所有 Agent 收敛到高置信度的错误结论
```

**打断方法：**
- 引入独立验证 Agent，不看其他 Agent 的结论
- 关键结论用代码/测试验证，不靠 Agent 互相确认
- 设置交叉验证检查点

### 6.2 同 Session 竞态

同一 session 内的消息必须串行处理：

```
❌ 错误：两个子 Agent 并发写同一个 session 的历史
✅ 正确：每个 sessionKey 维护一个队列，串行处理
```

不同 session 之间可以并发，互不影响。

### 6.3 过度拆分

| 信号 | 说明 |
|---|---|
| 子 Agent 频繁互相询问 | 任务拆得太细，耦合度高 |
| 协调消息比实际工作多 | 协调开销超过并行收益 |
| 合并时大量冲突 | 隔离边界划错了 |

**经验法则：** 先在单 Agent 上验证能力上限，确认瓶颈在上下文或能力边界后，再引入多 Agent。

### 6.4 常见反模式

| 反模式 | 怎么修 |
|---|---|
| 子 Agent 把完整调试过程回传主 Agent | 只回传摘要 |
| 用自然语言协调任务依赖 | 换结构化协议 + 任务图 |
| 所有 Agent 共享同一个工作目录 | Worktree 隔离 |
| 没有深度限制，递归生成子 Agent | 设 maxDepth |
| 先搞并行再建协议 | 先协议 → 隔离 → 协作 → 并行 |

---

## 决策流程图

```
任务来了
  ↓
单 Agent 能搞定？ → 是 → 用单 Agent，别折腾
  ↓ 否
子任务之间独立？ → 否 → 用提示链（顺序执行），别拆 Agent
  ↓ 是
需要不同角色？ → 否 → 用并行工具调用，不需要多 Agent
  ↓ 是
定义协议 → 划分隔离边界 → 建任务图 → 启动子 Agent
```

---

## 参考

- OpenClaw 子 Agent 文档：https://docs.openclaw.ai
- Anthropic 多 Agent 模式：https://claude.com/blog/multi-agent
- Tw93《你不知道的 Agent》多 Agent 章节：https://tw93.fun/2026-03-21/agent.html
