"""
多模态处理器 - 本地多模态内容处理
支持图像OCR、视频关键帧提取、音频转录、PDF内容提取
完全本地运行，无需API
"""

import os
import sys
from typing import Dict, List, Optional, Union
import json

class MultimodalProcessor:
    """多模态内容处理器"""
    
    def __init__(self):
        self.supported_image_formats = ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.tiff', '.webp']
        self.supported_video_formats = ['.mp4', '.avi', '.mov', '.mkv', '.flv', '.wmv']
        self.supported_audio_formats = ['.wav', '.mp3', '.flac', '.aac', '.ogg', '.m4a']
        self.supported_document_formats = ['.pdf']
    
    # ==================== 图像处理 ====================
    
    def process_image(self, image_path: str, extract_text: bool = True) -> Dict:
        """处理图像文件"""
        try:
            from PIL import Image
            import pytesseract
            
            result = {
                'success': True,
                'type': 'image',
                'path': image_path
            }
            
            # 获取图像信息
            with Image.open(image_path) as img:
                result['info'] = {
                    'format': img.format,
                    'mode': img.mode,
                    'size': f"{img.width}x{img.height}",
                    'file_size': f"{os.path.getsize(image_path) / 1024:.2f} KB"
                }
            
            # OCR文字识别
            if extract_text:
                try:
                    text = pytesseract.image_to_string(image_path, lang='chi_sim+eng')
                    result['text'] = text.strip()
                except Exception as e:
                    result['text_error'] = str(e)
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'type': 'image',
                'path': image_path,
                'error': str(e)
            }
    
    def convert_image(self, input_path: str, output_path: str, 
                     format: str = 'PNG') -> Dict:
        """转换图像格式"""
        try:
            from PIL import Image
            
            with Image.open(input_path) as img:
                img.save(output_path, format=format)
            
            return {
                'success': True,
                'input': input_path,
                'output': output_path,
                'format': format
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==================== 视频处理 ====================
    
    def process_video(self, video_path: str, extract_frames: bool = True,
                     num_frames: int = 5, output_dir: str = None) -> Dict:
        """处理视频文件"""
        try:
            import cv2
            
            result = {
                'success': True,
                'type': 'video',
                'path': video_path
            }
            
            cap = cv2.VideoCapture(video_path)
            
            # 获取视频信息
            total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            duration = total_frames / fps if fps > 0 else 0
            
            result['info'] = {
                'duration': f"{duration:.2f} 秒",
                'resolution': f"{int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))}x{int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))}",
                'fps': f"{fps:.2f}",
                'total_frames': total_frames,
                'file_size': f"{os.path.getsize(video_path) / 1024 / 1024:.2f} MB"
            }
            
            # 提取关键帧
            if extract_frames:
                if output_dir is None:
                    output_dir = os.path.splitext(video_path)[0] + '_frames'
                os.makedirs(output_dir, exist_ok=True)
                
                keyframes = []
                interval = total_frames // num_frames if total_frames > 0 else 1
                
                for i in range(min(num_frames, total_frames)):
                    frame_pos = i * interval
                    cap.set(cv2.CAP_PROP_POS_FRAMES, frame_pos)
                    ret, frame = cap.read()
                    
                    if ret:
                        output_path = os.path.join(output_dir, f"frame_{i:04d}.jpg")
                        cv2.imwrite(output_path, frame)
                        keyframes.append(output_path)
                
                result['keyframes'] = keyframes
                result['keyframes_count'] = len(keyframes)
            
            cap.release()
            return result
            
        except Exception as e:
            return {
                'success': False,
                'type': 'video',
                'path': video_path,
                'error': str(e)
            }
    
    def extract_video_audio(self, video_path: str, 
                           output_path: str = None) -> Dict:
        """从视频中提取音频"""
        try:
            from moviepy.editor import VideoFileClip
            
            if output_path is None:
                output_path = os.path.splitext(video_path)[0] + '.mp3'
            
            video = VideoFileClip(video_path)
            audio = video.audio
            audio.write_audiofile(output_path)
            video.close()
            
            return {
                'success': True,
                'video': video_path,
                'audio': output_path
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==================== 音频处理 ====================
    
    def process_audio(self, audio_path: str, 
                     transcribe: bool = False) -> Dict:
        """处理音频文件"""
        try:
            from pydub import AudioSegment
            
            result = {
                'success': True,
                'type': 'audio',
                'path': audio_path
            }
            
            audio = AudioSegment.from_file(audio_path)
            
            result['info'] = {
                'duration': f"{len(audio) / 1000:.2f} 秒",
                'sample_rate': audio.frame_rate,
                'channels': audio.channels,
                'sample_width': audio.sample_width,
                'file_size': f"{os.path.getsize(audio_path) / 1024:.2f} KB"
            }
            
            # 语音转录（需要额外安装whisper）
            if transcribe:
                try:
                    import whisper
                    model = whisper.load_model("base")
                    transcription = model.transcribe(audio_path)
                    result['transcription'] = transcription["text"]
                except Exception as e:
                    result['transcription_error'] = str(e)
                    result['transcription'] = "需要安装whisper模型: pip install openai-whisper"
            
            return result
            
        except Exception as e:
            return {
                'success': False,
                'type': 'audio',
                'path': audio_path,
                'error': str(e)
            }
    
    def convert_audio(self, input_path: str, output_path: str,
                     format: str = 'mp3') -> Dict:
        """转换音频格式"""
        try:
            from pydub import AudioSegment
            
            audio = AudioSegment.from_file(input_path)
            audio.export(output_path, format=format)
            
            return {
                'success': True,
                'input': input_path,
                'output': output_path,
                'format': format
            }
        except Exception as e:
            return {
                'success': False,
                'error': str(e)
            }
    
    # ==================== PDF处理 ====================
    
    def process_pdf(self, pdf_path: str, extract_text: bool = True,
                   extract_images: bool = False) -> Dict:
        """处理PDF文件"""
        try:
            import fitz  # PyMuPDF
            
            result = {
                'success': True,
                'type': 'pdf',
                'path': pdf_path
            }
            
            doc = fitz.open(pdf_path)
            
            # 获取PDF信息
            result['info'] = {
                'pages': len(doc),
                'title': doc.metadata.get('title', '未知'),
                'author': doc.metadata.get('author', '未知'),
                'file_size': f"{os.path.getsize(pdf_path) / 1024:.2f} KB"
            }
            
            # 提取文字
            if extract_text:
                text = ""
                for page_num in range(len(doc)):
                    page = doc[page_num]
                    text += f"\n--- 第 {page_num + 1} 页 ---\n"
                    text += page.get_text()
                result['text'] = text
            
            # 提取图像
            if extract_images:
                output_dir = os.path.splitext(pdf_path)[0] + '_images'
                os.makedirs(output_dir, exist_ok=True)
                
                image_list = []
                for page_num in range(len(doc)):
                    page = doc[page_num]
                    images = page.get_images()
                    
                    for img_index, img in enumerate(images, start=1):
                        xref = img[0]
                        base_image = doc.extract_image(xref)
                        image_bytes = base_image["image"]
                        image_ext = base_image["ext"]
                        
                        output_path = os.path.join(
                            output_dir, 
                            f"page_{page_num+1}_img_{img_index}.{image_ext}"
                        )
                        with open(output_path, "wb") as f:
                            f.write(image_bytes)
                        image_list.append(output_path)
                
                result['images'] = image_list
                result['images_count'] = len(image_list)
            
            doc.close()
            return result
            
        except Exception as e:
            return {
                'success': False,
                'type': 'pdf',
                'path': pdf_path,
                'error': str(e)
            }
    
    # ==================== 通用处理 ====================
    
    def process_file(self, file_path: str, **options) -> Dict:
        """自动识别并处理文件"""
        ext = os.path.splitext(file_path)[1].lower()
        
        if ext in self.supported_image_formats:
            return self.process_image(file_path, **options)
        elif ext in self.supported_video_formats:
            return self.process_video(file_path, **options)
        elif ext in self.supported_audio_formats:
            return self.process_audio(file_path, **options)
        elif ext in self.supported_document_formats:
            return self.process_pdf(file_path, **options)
        else:
            return {
                'success': False,
                'error': f'不支持的文件格式: {ext}'
            }
    
    def batch_process(self, file_paths: List[str], 
                     max_workers: int = 4, **options) -> List[Dict]:
        """批量处理文件"""
        from concurrent.futures import ThreadPoolExecutor
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            results = list(executor.map(
                lambda p: self.process_file(p, **options), 
                file_paths
            ))
        
        return results


# 命令行接口
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='多模态处理器')
    parser.add_argument('file', help='要处理的文件路径')
    parser.add_argument('--type', choices=['image', 'video', 'audio', 'pdf', 'auto'],
                       default='auto', help='文件类型')
    parser.add_argument('--extract-text', action='store_true', help='提取文字')
    parser.add_argument('--extract-frames', action='store_true', help='提取视频帧')
    parser.add_argument('--transcribe', action='store_true', help='语音转录')
    parser.add_argument('--extract-images', action='store_true', help='提取PDF图像')
    
    args = parser.parse_args()
    
    processor = MultimodalProcessor()
    
    if args.type == 'auto':
        result = processor.process_file(
            args.file,
            extract_text=args.extract_text,
            extract_frames=args.extract_frames,
            transcribe=args.transcribe,
            extract_images=args.extract_images
        )
    else:
        method = getattr(processor, f'process_{args.type}')
        result = method(args.file)
    
    print(json.dumps(result, ensure_ascii=False, indent=2))
