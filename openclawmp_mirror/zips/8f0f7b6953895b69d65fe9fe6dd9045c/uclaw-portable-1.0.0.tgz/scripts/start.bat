@echo off
echo ============================================
echo U-Claw 启动程序
echo ============================================
echo.

set NODE_DIR=%~dp0app\runtime\node-win-x64

if not exist "%NODE_DIR%\node.exe" (
    echo [ERROR] 未找到 Node.js
echo.
    echo 请先运行【第二步】安装依赖.bat
echo.
    pause
    exit /b 1
)

echo [OK] 检查通过，正在启动 U-Claw...
echo.
echo 启动后会自动打开浏览器配置页面
echo.
echo ============================================

set PATH=%NODE_DIR%;%PATH%
cd /d "%~dp0"

start http://127.0.0.1:18788/

openclaw gateway start --bind 127.0.0.1 --port 18789

echo.
echo U-Claw 已关闭
echo.
pause