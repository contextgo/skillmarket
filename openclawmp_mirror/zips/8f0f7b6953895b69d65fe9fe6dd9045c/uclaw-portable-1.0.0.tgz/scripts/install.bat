@echo off
echo ============================================
echo U-Claw 依赖安装程序
echo ============================================
echo.
echo 正在检查系统环境...
echo.

set NODE_VER=v22.14.0
set NODE_URL=https://npmmirror.com/mirrors/node/%NODE_VER%/node-%NODE_VER%-win-x64.zip
set APP_DIR=%~dp0app
set RUNTIME_DIR=%APP_DIR%\runtime
set NODE_DIR=%RUNTIME_DIR%\node-win-x64

if exist "%NODE_DIR%\node.exe" (
    echo [OK] Node.js 已安装，跳过下载
    goto install_openclaw
)

echo [1/3] 创建目录...
if not exist "%APP_DIR%" mkdir "%APP_DIR%"
if not exist "%RUNTIME_DIR%" mkdir "%RUNTIME_DIR%"
if not exist "%NODE_DIR%" mkdir "%NODE_DIR%"

echo [2/3] 下载 Node.js %NODE_VER%...
echo      这可能需要2-5分钟，请耐心等待...
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -Uri '%NODE_URL%' -OutFile '%TEMP%\node.zip' -UseBasicParsing" >nul 2>&1

if not exist "%TEMP%\node.zip" (
    echo [ERROR] 下载失败，请检查网络连接
    pause
    exit /b 1
)

echo [3/3] 解压 Node.js...
powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Path '%TEMP%\node.zip' -DestinationPath '%NODE_DIR%' -Force" >nul 2>&1

if exist "%NODE_DIR%\node-%NODE_VER%-win-x64\node.exe" (
    xcopy /E /I /Y "%NODE_DIR%\node-%NODE_VER%-win-x64\*" "%NODE_DIR%\" >nul 2>&1
    rmdir /S /Q "%NODE_DIR%\node-%NODE_VER%-win-x64" >nul 2>&1
)

if not exist "%NODE_DIR%\node.exe" (
    echo [ERROR] 解压失败
    pause
    exit /b 1
)

echo [OK] Node.js 安装完成

:install_openclaw
echo.
echo [4/4] 安装 OpenClaw...
echo      这可能需要1-3分钟...
"%NODE_DIR%\npm.cmd" install -g openclaw >nul 2>&1

if exist "%NODE_DIR%\openclaw.cmd" (
    echo [OK] OpenClaw 安装完成
) else (
    echo [WARNING] OpenClaw 安装可能未完成，但不影响使用
)

echo.
echo ============================================
echo 安装完成！
echo ============================================
echo.
echo 下一步：双击运行【第三步】启动U-Claw.bat
echo.
pause