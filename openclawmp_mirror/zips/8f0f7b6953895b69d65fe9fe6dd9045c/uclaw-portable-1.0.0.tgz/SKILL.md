---
name: uclaw-portable
displayName: UClaw便携版
description: 制作「插上就能用」的AI助手U盘。包含完整的OpenClaw便携化方案，支持Windows/Mac/Linux三平台，一键启动AI助手。
version: 1.0.0
author: UClaw Team
homepage: https://u-claw.org
tags: [portable, usb, openclaw, cross-platform, beginner-friendly]
category: tool
---

# UClaw便携版

> 制作「插上就能用」的AI助手U盘

UClaw是一个完整的OpenClaw便携化解决方案，让你可以把AI助手装进U盘，插上任意电脑就能使用。

## 功能特点

- **便携免安装**：U盘插上即用，无需安装
- **三平台支持**：Windows、Mac、Linux全覆盖
- **中文技能集**：内置10+中文本地化技能
- **一键配置**：可视化配置界面，小白友好
- ** Electron桌面版**：可选安装到电脑

## 包含内容

### 启动脚本
- Windows: `Windows-Start.bat`
- Mac: `Mac-Start.command`
- Linux: `Linux-Start.sh`

### 中文技能集
- bilibili-helper: B站内容优化
- china-search: 国内搜索引擎
- china-translate: 中英互译
- china-weather: 中国天气查询
- deepseek-helper: DeepSeek API助手
- douyin-script: 抖音/快手脚本
- wechat-article: 微信公众号写作
- weibo-poster: 微博内容创作
- xiaohongshu-writer: 小红书写作
- zhihu-writer: 知乎写作

## 快速开始

### 1. 准备U盘
- 容量：4GB+（便携版）或 64GB+（Linux启动盘）
- 格式：FAT32/exFAT

### 2. 复制文件
将 `portable/` 文件夹完整复制到U盘根目录

### 3. 安装依赖（首次）
- Windows: 双击 `【第二步】安装依赖.bat`
- Mac: 双击 `Mac-Install.command`
- Linux: 运行 `bash Linux-Install.sh`

### 4. 启动使用
- Windows: 双击 `【第三步】启动U-Claw.bat`
- Mac: 双击 `Mac-Start.command`
- Linux: 运行 `bash Linux-Start.sh`

### 5. 配置AI模型
浏览器自动打开配置页面，填写API Key即可使用

## API Key申请

支持多种AI服务：
- **阶跃星辰**：https://platform.stepfun.com（推荐）
- **DeepSeek**：https://platform.deepseek.com（性价比高）
- **OpenAI**：https://platform.openai.com
- **其他**：SiliconFlow、智谱AI、月之暗面等

## 系统要求

| 平台 | 要求 |
|------|------|
| Windows | Windows 10/11 64位 |
| Mac | macOS 12+ (Apple Silicon/Intel) |
| Linux | Ubuntu 20.04+ / Debian 10+ |

## 两种模式

### 模式一：便携版U盘（推荐）
- 在已有系统上运行
- 4GB+ U盘即可
- 依赖电脑已有操作系统

### 模式二：Linux启动盘
- 从U盘启动完整Linux系统
- 需要64GB+ USB 3.0
- 不依赖电脑系统

## 技术支持

- 官网：https://u-claw.org
- GitHub：https://github.com/dongsheng123132/u-claw
- OpenClaw：https://github.com/openclaw/openclaw

## 许可证

MIT License