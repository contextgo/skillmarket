# 轻量级向量记忆系统

基于 TF-IDF + SQLite 的向量记忆系统，支持语义搜索和自动压缩。

## ✨ 特性

- ✅ **零依赖** - 仅使用 Python 标准库
- ✅ **语义搜索** - 基于 TF-IDF 的相似度计算
- ✅ **自动压缩** - 定期归档低重要性记忆
- ✅ **标签系统** - 多维度分类
- ✅ **重要性分级** - 1-5 级重要性评分

## 🚀 快速开始

### 1. 添加记忆

```bash
python3 scripts/vector_add.py \
  --content "Ethereum $5,000 信号连续 10 轮保持高置信度" \
  --type "signal" \
  --importance 5 \
  --tags "polymarket,ethereum,signal"
```

**输出**:
```
✅ 记忆已添加 (ID: 1)
   类型: signal
   重要性: 5
   标签: polymarket, ethereum, signal
```

### 2. 搜索记忆

```bash
python3 scripts/vector_search.py \
  --query "Ethereum 价格信号" \
  --top-k 5
```

**输出**:
```
🔍 找到 3 条相关记忆:
================================================================================

[1] 相似度: 0.556 | 重要性: 4/5
    类型: analysis
    内容: Ethereum 价格预测市场信号分析...
    标签: ethereum, analysis
    时间: 2026-03-13 02:23:30
```

### 3. 压缩记忆

```bash
python3 scripts/vector_compress.py --days 30
```

**输出**:
```
✅ 已压缩 12 条记忆
   压缩条件: 30 天前, 重要性 <= 3
   压缩后存储: ~/.openclaw/workspace/.vector-memory/compressed.db
```

## 📊 架构

```
L1 工作记忆 (上下文)
  ↓ 添加记忆
L2 向量记忆 (SQLite + TF-IDF)
  ├── events.db (主数据库)
  ├── tfidf_index.json (词频索引)
  └── compressed.db (压缩归档)
  ↓ 定期压缩
L3 长期记忆 (MEMORY.md + EvoMap)
```

### 数据结构

**events.db**:
```sql
CREATE TABLE vector_events (
    id INTEGER PRIMARY KEY,
    type TEXT,              -- decision/error/insight/signal
    content TEXT,          -- 记忆内容
    importance INTEGER,    -- 1-5
    tags TEXT,             -- JSON array
    tfidf_vector TEXT,     -- JSON object
    created_at TIMESTAMP,
    compressed_at TIMESTAMP
);
```

## 🎯 使用场景

### 场景 1: 记录决策

```python
# 记录重要决策
add_memory(
    content="选择 SQLite + TF-IDF 方案（而非 ChromaDB）",
    event_type="decision",
    importance=5,
    tags=["architecture", "memory", "decision"]
)
```

### 场景 2: 记录错误

```python
# 记录错误和解决方案
add_memory(
    content="代理服务未启动导致 Polymarket 连续 6 次失败",
    event_type="error",
    importance=4,
    tags=["proxy", "error", "polymarket"]
)
```

### 场景 3: 查询历史

```python
# 查询相关决策
results = search_memory(
    query="Ethereum 信号策略",
    top_k=5
)
```

## 🔧 配置

### 定时压缩

添加到 crontab:
```bash
# 每周日凌晨 2 点压缩记忆
0 2 * * 0 python3 ~/.openclaw/skills/vector-memory-lite/scripts/vector_compress.py --days 30
```

### 集成到 OpenClaw

在 MEMORY.md 中添加引用:
```markdown
## 📚 记忆系统

- **L1 工作记忆**: 当前对话上下文
- **L2 向量记忆**: [vector-memory-lite](skills/vector-memory-lite/) - TF-IDF + SQLite
- **L3 长期记忆**: MEMORY.md + EvoMap
```

## 📈 性能

| 指标 | 值 |
|------|-----|
| **搜索延迟** | < 100ms (1000 条记忆) |
| **存储效率** | ~1KB / 100 条记忆 |
| **压缩率** | 70% (30 天后) |
| **内存占用** | < 10MB |

## 🆚 对比 ChromaDB

| 特性 | 本系统 | ChromaDB |
|------|--------|----------|
| **语义理解** | ⭐⭐⭐ (TF-IDF) | ⭐⭐⭐⭐⭐ (BERT) |
| **安装复杂度** | ⭐ (零依赖) | ⭐⭐⭐ (需 pip) |
| **性能** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **成本** | 免费 | 免费 |
| **适用场景** | 轻量级 | 生产级 |

## 📦 文件结构

```
vector-memory-lite/
├── SKILL.md                    # 本文档
├── manifest.json              # 技能元数据
├── install_chromadb.sh        # ChromaDB 安装脚本
└── scripts/
    ├── vector_add.py          # 添加记忆
    ├── vector_search.py       # 搜索记忆
    └── vector_compress.py     # 压缩记忆
```

## 🔍 最佳实践

1. **添加记忆时**:
   - 添加描述性标签
   - 设置准确的重要性（1-5）
   - 包含可检索关键词

2. **搜索记忆时**:
   - 使用自然语言查询
   - 结合类型过滤
   - 限制 top-k 避免信息过载

3. **定期压缩**:
   - 每周压缩一次
   - 保留高重要性记忆（4-5）
   - 归档低重要性记忆（1-3）

## 🆕 升级到 ChromaDB（Docker 方案）

### 方案对比

| 方案 | 语义理解 | 安装复杂度 | 性能 | 适用场景 |
|------|----------|------------|------|----------|
| **TF-IDF + SQLite** | ⭐⭐⭐ | ⭐ (零依赖) | ⭐⭐⭐⭐ | 轻量级 |
| **ChromaDB (Docker)** | ⭐⭐⭐⭐⭐ | ⭐⭐⭐ (需 Docker) | ⭐⭐⭐⭐⭐ | 生产级 |

### 快速安装

```bash
# 1. 安装 Docker（首次）
chmod +x install_docker_chroma.sh
./install_docker_chroma.sh

# 2. 启动 ChromaDB 容器
docker compose up -d

# 3. 测试连接
curl http://localhost:8000/api/v1/heartbeat

# 4. 运行集成测试
python3 scripts/test_chroma_docker.py
```

### 使用 ChromaDB

```bash
# 添加记忆（使用 BERT 嵌入）
python3 scripts/chroma_add.py \
  --content "Ethereum $5,000 信号连续 10 轮保持高置信度" \
  --type "signal" \
  --importance 5 \
  --tags "polymarket,ethereum,signal"

# 搜索记忆（语义搜索）
python3 scripts/chroma_search.py \
  --query "Ethereum 价格信号" \
  --top-k 5

# 按类型过滤
python3 scripts/chroma_search.py \
  --query "错误" \
  --type "error" \
  --top-k 10
```

### ChromaDB 特性

- ✅ **BERT 嵌入** - 更强的语义理解
- ✅ **向量索引** - 更快的搜索（HNSW）
- ✅ **元数据过滤** - 灵活的查询
- ✅ **持久化存储** - Docker volume
- ✅ **REST API** - 标准 HTTP 接口

### Docker 管理

```bash
# 查看状态
docker compose ps

# 查看日志
docker compose logs -f chromadb

# 停止服务
docker compose down

# 重启服务
docker compose restart

# 清理数据（谨慎）
docker compose down -v
```

## 📚 相关资源

- **三层记忆系统**: `~/.openclaw/skills/three-tier-memory/`
- **EvoMap 集成**: `memory/active-projects/passive-income.md`
- **ChromaDB 文档**: https://docs.trychroma.com/

---

**安装时间**: 2026-03-13
**维护者**: Chaotang (node_chaotang_1773048216)
