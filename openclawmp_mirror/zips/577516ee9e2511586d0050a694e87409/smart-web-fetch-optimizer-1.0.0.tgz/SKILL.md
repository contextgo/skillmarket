---
name: smart-web-fetch-optimizer
description: "智能网页抓取优化 - HTML转Markdown、内容提取、反爬策略、并发控制"
version: 1.0.0
tags: ["web-scraping", "fetch", "content-extraction", "agent", "best-practice"]
---

# 智能网页抓取优化

AI Agent 高效抓取网页内容的策略集合，包括 HTML 转 Markdown、内容提取、反爬应对和并发控制。

## 核心原则

1. **能 API 就不爬**：优先使用官方 API
2. **能摘要就不全文**：只取需要的部分
3. **能并发就不串行**：但要尊重速率限制
4. **能缓存就不重复**：避免重复请求

## 抓取策略矩阵

| 内容类型 | 推荐方式 | 工具 |
|---------|---------|------|
| API 数据 | REST/GraphQL | curl/httpx |
| RSS Feed | RSS 解析 | feedparser |
| 静态页面 | HTML→Markdown | web_fetch |
| 动态页面 | 无头浏览器 | Playwright/Puppeteer |
| 简单文本 | 直接请求 | curl |

## HTML 转 Markdown

```python
def html_to_markdown(html_content, max_chars=10000):
    """从 HTML 提取核心内容并转为 Markdown"""
    from markdownify import markdownify
    
    # 移除脚本、样式等无用标签
    clean_html = remove_tags(html_content, ['script', 'style', 'nav', 'footer'])
    
    # 转为 Markdown
    md = markdownify(clean_html, heading_style='ATX')
    
    # 截断
    if len(md) > max_chars:
        md = md[:max_chars] + "\n\n... [truncated]"
    
    return md
```

## 反爬应对

### 策略 1：User-Agent 轮换

```python
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36",
]
```

### 策略 2：请求间隔

```python
import asyncio

async def fetch_with_delay(url, delay=1.0):
    await asyncio.sleep(delay)
    return await fetch(url)
```

### 策略 3：降级方案

```
API → RSS → web_fetch → 浏览器自动化 → 放弃
```

## 并发控制

```python
import asyncio
from asyncio import Semaphore

MAX_CONCURRENT = 5
semaphore = Semaphore(MAX_CONCURRENT)

async def fetch_batch(urls):
    async def limited_fetch(url):
        async with semaphore:
            return await fetch(url)
    
    tasks = [limited_fetch(url) for url in urls]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [(url, r) for url, r in zip(urls, results) if not isinstance(r, Exception)]
```

## 内容质量过滤

```python
def is_quality_content(text, min_length=100):
    if len(text) < min_length:
        return False
    # 检查是否是错误页面
    if '404' in text[:200] or 'not found' in text[:200]:
        return False
    # 检查是否有实质内容
    word_count = len(text.split())
    return word_count > 20
```

## 缓存策略

```python
from datetime import datetime, timedelta

CACHE_TTL = timedelta(hours=1)

def should_fetch(url, last_fetched):
    if not last_fetched:
        return True
    return datetime.now() - last_fetched > CACHE_TTL
```
