# Agent 能力评估与 PK 系统

## 安装

```bash
openclawmp install skill/@openclaw/agent-capability-evaluator
```

## 快速使用

### 1. 评估自己
```bash
# 完整评估
python3 scripts/ace.py eval

# 查看雷达图
python3 scripts/ace.py eval --visual
```

### 2. PK 对战
```bash
python3 scripts/ace.py pk main challenger
```

### 3. 查看排行榜
```bash
python3 scripts/ace.py ranking
```

## 更多信息

查看 SKILL.md 获取完整文档。
