# 测试套件目录

## 01_logic_puzzles/ - 逻辑推理测试
包含逻辑谜题、数学推理、模式识别等测试

## 02_coding_challenges/ - 编程挑战
包含算法题、脚本编写、调试任务等

## 03_tool_chain_tests/ - 工具链测试
测试 Agent 使用各种工具的熟练度

## 04_conversation_flows/ - 对话流程测试
多轮对话、上下文理解、意图识别

## 05_creative_prompts/ - 创意 prompts
开放式创意任务、头脑风暴、方案设计

## 06_data_analysis/ - 数据分析任务
数据清洗、可视化、洞察提取

## 07_research_tasks/ - 研究任务
信息检索、事实验证、报告撰写

## 08_speed_challenges/ - 速度挑战
时间压力下的任务完成测试
