# 小红书自动化发布工具（防检测版）

一键生成小红书风格卡片并自动发布到小红书平台，模拟人类操作行为，避免被检测为机器人。

## 核心功能

- 🎨 **自动渲染** - 将Markdown渲染为小红书风格图片卡片
- 📤 **模拟人工** - 随机延迟、人类打字速度、行为模式
- 🏷️ **话题支持** - 自动添加话题标签
- 📸 **多图支持** - 支持1-9张图片
- 🔄 **防检测** - 避免被识别为机器人

## 防检测机制

### 1. 随机延迟
每次操作间隔1-3秒，模拟人类思考时间。

### 2. 打字速度模拟
每秒3-5个字符，不是瞬间输入。

### 3. 行为抖动
操作时间有微小随机变化，模拟人类的不一致性。

### 4. 页面等待
加载等待1-3秒，模拟人类看页面。

### 5. 检查确认
发布前有确认环节，模拟人类细心检查。

## 使用方法

### 快速开始（推荐）

```bash
# 1. 安装依赖
pip install -r requirements.txt

# 2. 配置Cookie
cp env.example.txt .env
# 编辑 .env 文件，填入你的小红书Cookie

# 3. 渲染卡片
node scripts/render.js content.md -o ./output -s xiaohongshu

# 4. 模拟人工发布（推荐 ⭐）
python scripts/publish_human.py \
  --title "笔记标题" \
  --desc "笔记正文" \
  --images "output/cover.png,output/card_1.png" \
  --topics "话题1,话题2"
```

### 普通发布

```bash
python scripts/publish.py \
  --title "标题" \
  --desc "正文" \
  --images "图片"
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|----------|
| `--title` | 笔记标题 | 必填 |
| `--desc` | 笔记正文 | 必填 |
| `--images` | 图片路径（逗号分隔） | 必填 |
| `--topics` | 话题标签（逗号分隔） | 可选 |
| `--markdown` | Markdown配置文件 | 可选 |
| `--private` | 是否私密 | false |

## 文件结构

```
xiaohongshu-auto-publish/
├── SKILL.md              # 本文件（技能定义）
├── README.md             # 使用说明
├── requirements.txt      # Python依赖
├── package.json          # Node.js依赖
├── env.example.txt       # Cookie配置示例
├── .env                 # Cookie配置（需手动创建）
├── scripts/
│   ├── render.js        # 卡片渲染脚本
│   ├── publish.py       # 普通发布脚本
│   ├── publish_human.py # 模拟人工版 ⭐推荐
│   └── publish_simple.py # 简化发布脚本
└── references/
    └── examples/
        └── content-example.md # 内容示例
```

## 版本对比

| 功能 | publish.py | publish_human.py |
|------|-----------|------------------|
| 基础发布 | ✅ | ✅ |
| 随机延迟 | ❌ | ✅ |
| 打字模拟 | ❌ | ✅ |
| 行为抖动 | ❌ | ✅ |
| 防检测机制 | ⚠️ | ✅✅ |

**推荐使用 publish_human.py**，模拟真人操作行为，降低被检测风险。

## 注意事项

1. **Cookie有效期** - 过期后需重新获取
2. **发布频率** - 建议每天发布不超过10篇
3. **内容合规** - 内容需符合小红书社区规范
4. **图片建议** - 1080x1440像素最佳

## 安装步骤

### Python依赖

```bash
pip install -r requirements.txt
```

依赖包括：
- xhs>=0.2.13 - 小红书API库
- requests - HTTP请求库

### Node.js依赖（可选，用于卡片渲染）

```bash
npm install
npx playwright install chromium
```

## 配置Cookie

### 获取Cookie

1. 浏览器访问 https://www.xiaohongshu.com 并登录
2. 按F12打开开发者工具
3. 切换到 Network 标签
4. 刷新页面，点击任意请求
5. 查看 Request Headers → Cookie
6. 复制完整的Cookie值

### 配置环境变量

```bash
export XHS_COOKIE="你的Cookie值"
```

或创建 `.env` 文件：

```bash
XHS_COOKIE="你的Cookie值"
```

## 完整示例

### 1. 创建Markdown内容

```markdown
---
emoji: "🏔️"
title: "西藏·一生必去一次的地方"
subtitle: "看到照片的那一刻，我哭了"
---

# 布达拉宫

站在布达拉宫广场前，抬头仰望这座世界屋脊上的宫殿...
```

### 2. 渲染卡片

```bash
node scripts/render.js content.md -o ./output -s xiaohongshu
```

### 3. 模拟人工发布

```bash
python scripts/publish_human.py \
  --title "西藏·一生必去一次的地方" \
  --desc "看到照片的那一刻，我哭了..." \
  --images "output/cover.png,output/card_1.png,output/card_2.png" \
  --topics "西藏旅行,布达拉宫"
```

## 输出示例

成功发布后返回：

```
🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉

✅✅✅ 发布成功！✅✅✅

📝 笔记ID: 69bbc6430000000021011992
🔗 分享链接: https://www.xiaohongshu.com/discovery/item/69bbc6430000000021011992

👀 查看发布结果...
  ✓ 发布完成！

🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉
```

## 技术原理

### 签名算法

小红书API需要签名，本工具使用 `xhs.help.sign` 函数实现：

```python
from xhs.help import sign

def sign_wrapper(url, data=None, **kwargs):
    a1 = kwargs.get('a1', a1_value)
    web_session = kwargs.get('web_session', '')
    ctime = kwargs.get('ctime', None)
    b1 = kwargs.get('b1', '')
    return sign(url, data, ctime, a1, b1)

client = XhsClient(cookie, sign=sign_wrapper)
```

### 文件上传

使用小红书API的分片上传机制：

1. 获取上传许可 (`get_upload_files_permit`)
2. 分片上传图片 (`upload_file_with_slice`)
3. 获取上传后的文件ID
4. 创建笔记并关联图片

## 常见问题

### Q1: 如何获取Cookie？

浏览器访问 https://www.xiaohongshu.com 并登录 → F12打开开发者工具 → Network标签 → 刷新页面 → 查看Request Headers → Cookie

### Q2: Cookie过期怎么办？

重新获取Cookie并更新 `.env` 文件或环境变量。

### Q3: 发布失败怎么办？

1. 检查Cookie是否有效
2. 检查图片路径是否正确
3. 检查网络连接
4. 查看错误日志

### Q4: 图片数量有限制吗？

小红书笔记支持1-9张图片，建议使用5-9张效果最佳。

### Q5: 如何定时发布？

使用系统的cron功能配合脚本实现定时发布：

```bash
# 每天早上9点自动发布
cron add --name "daily-xhs-publish" \
  --schedule "0 9 * * *" \
  --command "python scripts/publish_human.py --title '...'"
```

## 技能特点

- ✅ **完全自动化** - 从渲染到发布全流程
- ✅ **防检测机制** - 模拟人类行为
- ✅ **易于使用** - 简单的命令行工具
- ✅ **灵活配置** - 支持自定义参数
- ✅ **稳定可靠** - 经过实战验证

## 适用场景

- 批量发布小红书笔记
- 自动生成精美图片卡片
- 定时发布小红书内容
- 模拟人工行为避免检测
- 内容创作者自动化
- 社交媒体运营

## 版本历史

### v1.0.0 (2026-03-19)
- 初始版本
- 支持卡片渲染
- 支持自动发布
- 支持话题标签
- 添加防检测机制
- 模拟人工行为

## 许可证

MIT License

## 作者

扣子龙虾 (kouzi_longxia)

---

**学习小红书自动化发布技能，提升内容创作效率！** 🦞