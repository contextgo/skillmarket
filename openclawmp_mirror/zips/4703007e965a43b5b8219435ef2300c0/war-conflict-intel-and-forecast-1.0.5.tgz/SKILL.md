---
name: war-conflict-intel-and-forecast
description: Collect, verify, and forecast war or geopolitical conflict developments using authoritative sources, cross-validation, scenario-based prediction, and structured multi-stage workflow.
version: 1.0.5
metadata:
  openclaw:
    emoji: "🛰️"
---

# War / Geopolitical Conflict Intelligence & Forecast Skill

## Purpose
Turn requests like:
- “Collect the latest battlefield situation”
- “Use authoritative sources”
- “Give a more precise assessment”
- “Predict what the U.S., Iran, Israel, or other actors may do next”
- “Estimate likely end-state trajectories”

into a repeatable workflow that is:
- fact-first
- source-ranked
- cross-verified
- explicit about uncertainty
- structured enough to reuse across conflicts
- disciplined in prediction

This skill is for open-source intelligence style synthesis, not classified intelligence, not propaganda, and not fantasy war writing.

---

## What Changed in v1.0.5
This is a release-polish update for marketplace publication. It keeps the collector / analyzer / writer workflow intact while slimming public packaging and improving marketplace readiness.

Detailed release and marketplace copy lives in `references/` and should be loaded only when preparing a public listing.

---

## Operating Principle
Be slower than propaganda, but more accurate than hype.

---

## Core Rules

### 1) Separate facts from judgments
Every serious output must distinguish:
- confirmed facts
- assessment / inference
- forecast

Never present a forecast as if it were already confirmed reality.

### 2) War information is adversarial by default
Every side has incentives to:
- exaggerate success
- hide losses
- shape public opinion
- pressure allies and markets
- trigger psychological effects

Therefore:
- a single belligerent's statement is not enough
- strong claims require stronger verification
- terms like “destroyed”, “eliminated”, “full control”, “crippled”, “collapsed” are claims to verify, not default facts

### 3) Use concrete dates and time windows
Do not write:
- today
- recently
- just now

Prefer:
- exact date
- exact time and timezone when relevant
- explicit forecast windows such as next 24 hours / next 3–7 days / next 2–6 weeks

### 4) Precision beats confidence theater
Do not sound certain when evidence is thin.
Prefer:
- high probability
- medium probability
- low probability / high impact
- too early to confirm
- single-source claim
- preliminary signal

### 5) Every forecast needs both support and disconfirmation
For each meaningful forecast, state:
- what evidence supports it
- what evidence would strengthen it
- what evidence would weaken or overturn it

### 6) Conflict type changes what matters
Do not apply one fixed battlefield template to every crisis.
First classify the conflict profile, then adapt indicators, source focus, and output emphasis.

---

## Conflict Profile Layer
Before deep collection or analysis, classify the primary profile:
- maritime chokepoint / energy crisis
- interstate conventional war
- proxy / shadow war
- internal conflict / coup / fragmentation
- border crisis / coercive signaling
- hybrid conflict

Then choose 3–6 priority indicators that best fit that profile.

Examples:
- maritime crisis → shipping, escorts, rerouting, oil reaction, port warnings
- interstate war → strike tempo, territorial movement, logistics, air defense, mobilization
- internal conflict → command cohesion, defections, capital control, communications systems, recognition

---

## Standard Workflow

### Stage 1: Collector
Use `tasks/collector_task.md`.

Collector responsibilities:
- identify conflict profile
- gather evidence by source hierarchy
- classify into fixed buckets
- label claim status
- apply freshness weighting
- merge duplicates
- surface evidence gaps

Collector output is a structured evidence pack, not a polished narrative.

### Stage 2: Analyzer
Use `tasks/analyzer_task.md`.

Analyzer responsibilities:
- validate collector inputs
- separate facts / inference / unresolved claims
- test alternative explanations
- identify actor goals and constraints
- forecast by time horizon
- generate scenario tree
- include a short self-audit of what may be wrong

### Stage 3: Writer
Use `tasks/writer_task.md`.

Writer responsibilities:
- choose output mode
- preserve confidence discipline
- convert analysis into a readable deliverable
- keep evidence traceability visible
- match tone to a serious intelligence brief, not theatrical commentary

---

## Source Hierarchy
Build the factual backbone from the top down.

### Tier 1: core backbone
Use first whenever available:
- Reuters
- AP
- official primary sources
- hard-data / system indicators

Primary sources confirm what an actor said, not automatically whether the claim is true.

### Tier 2: strong support
Use for depth, context, and strategic framing:
- FT
- WSJ
- NYT
- BBC
- major regional outlets
- major think tanks for context and scenario interpretation

### Tier 3: cautious-use
Use as leads, not settled fact:
- X / Telegram / viral video
- analyst threads
- open-source visual fragments

If a major claim only appears in Tier 3, it remains preliminary until checked.

---

## Mandatory Verification Labels
Every major claim should be treated as one of these:
- Confirmed event
- Confirmed statement
- Disputed consequence
- Single-source detail
- High-confidence inference
- Unverified / preliminary

Use these consistently through collector and analyzer stages.
Do not treat a confirmed statement as proof that the downstream consequence is confirmed.

---

## Collection Buckets
Every serious monitoring cycle should cover, as relevant:
1. battlefield / operational developments
2. military capability changes
3. political / diplomatic signaling
4. shipping / energy spillover
5. macro / market / trade signal
6. humanitarian / institutional warning
7. forward indicators

Do not focus only on kinetic events if the conflict’s real leverage point is shipping, energy, sanctions, coalition politics, or regime stability.

---

## Freshness Weighting
Use this time logic unless the user specifies otherwise:
- `0-12h` → highest operational relevance
- `12-48h` → main near-term reporting layer
- `2-7d` → supporting trend layer
- `>7d` → background only unless structurally essential

Older material may explain the situation, but should not dominate a live update.

---

## Contradiction Handling
When sources conflict:
1. preserve the disagreement
2. isolate the confirmed core
3. separate disputed details
4. avoid false synthesis

Example:
- confirmed core: strikes occurred near a target area
- disputed details: casualty count, destruction level, interception rate, command impact

---

## Forecast Discipline
All serious forecast outputs should be separated into:
- next 24 hours
- next 3–7 days
- next 2–6 weeks

For each horizon, distinguish:
- high probability
- medium probability
- low probability / high impact

Do not collapse all forward judgment into one dramatic paragraph.

---

## End-State Analysis
Use scenario trees, not a single cinematic ending.
At minimum include:
- most likely path
- plausible alternative path
- lower-probability but high-risk path

For each scenario, state:
- rough probability band
- why it is plausible
- what would raise the probability
- what would lower it

---

## Fallback / Downgrade Rules
If source quality is weak or incomplete:
- narrow the claim
- lower the confidence
- shorten the forecast horizon
- shift from prediction toward watchlist / scenarios

If core facts are single-source only:
- do not build aggressive end-state forecasts
- label the analysis provisional

If Tier 1 sources are unavailable:
- use Tier 2 to sketch the picture
- explicitly state that the backbone is weaker than normal

---

## Output Modes
The writer stage should adapt to user need.

Supported modes:
- breaking alert
- daily brief
- weekly assessment
- deep-dive intelligence note
- editorial intelligence digest

Editorial mode should feel readable first, but remain auditable underneath.

Each mode should preserve the same analytic discipline while changing length, emphasis, and density.

---

## Common Failure Modes

### Failure 1: repeating propaganda as fact
Fix:
- attribute clearly
- verify independently
- downgrade confidence when needed

### Failure 2: focusing only on kinetic events
Fix:
- include energy, shipping, politics, diplomacy, humanitarian, and economic spillover

### Failure 3: prediction without horizon
Fix:
- always separate near-term, short-term, and multi-week outlook

### Failure 4: overconfidence
Fix:
- use probability bands
- include disconfirming evidence
- show what would change your mind

### Failure 5: actor blending
Fix:
- separate U.S., Israel, Iran, proxies, Gulf states, Russia, Europe, or other actors as appropriate

### Failure 6: turning analysis into theater
Fix:
- avoid cinematic language
- avoid fake precision
- avoid rhetorical escalation that outruns evidence

---

## Final Discipline Checklist
Before delivering, verify:
- [ ] facts and forecasts are clearly separated
- [ ] dates are concrete
- [ ] Tier 1 sources anchor the core picture when available
- [ ] claim-status labels are applied consistently
- [ ] duplicates are merged
- [ ] uncertainty is visible
- [ ] forecasts are time-boxed
- [ ] end-state analysis uses distinct scenarios
- [ ] watchlist indicators could actually change the assessment
- [ ] tone is disciplined, not theatrical

---

## Recommended Use
Use this skill when the user wants:
- conflict monitoring
- war situation synthesis
- geopolitical risk assessment
- escalation / de-escalation forecasting
- source-ranked strategic briefs

Do not use this skill as a substitute for raw battlefield rumor forwarding or ideological persuasion.
