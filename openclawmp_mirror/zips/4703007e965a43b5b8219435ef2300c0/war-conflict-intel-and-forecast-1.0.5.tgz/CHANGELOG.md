# CHANGELOG

## v1.0.5
- polished release package for marketplace publication
- kept core workflow files focused and lightweight
- moved public listing copy and older release notes into `references/`
- retained collector / analyzer / writer split and editorial digest mode
- no new permissions, credentials, external scripts, or network side effects

## v1.0.4
- refined `editorial intelligence digest` after real-world test run
- reduced in-body citation clutter for user-facing briefs
- added compact source-block guidance
- required one analytical turn at the end of each editorial section
- added public-sentiment / hot-list guardrails

## v1.0.3
- added stable `source_ref_id` system such as `R1`, `AP1`, `WH1`
- refined claim-status taxonomy:
  - Confirmed event
  - Confirmed statement
  - Disputed consequence
  - Single-source detail
  - High-confidence inference
  - Unverified / preliminary
- split `economic / shipping / energy spillover` into:
  - `shipping / energy spillover`
  - `macro / market / trade signal`
- added `Mode E: Editorial intelligence digest`

## v1.0.2
- upgraded from handbook-style skill to structured workflow
- added collector / analyzer / writer split
- added task files:
  - `tasks/collector_task.md`
  - `tasks/analyzer_task.md`
  - `tasks/writer_task.md`
- added structured evidence-pack schema
- added conflict-profile adaptation layer
- added freshness weighting and downgrade rules
- added evidence traceability and red-team self-audit

## v1.0.0
- first published baseline version
- focused on war / geopolitical conflict collection, verification, and scenario-based forecasting
- strong source hierarchy and fact / inference / forecast separation
