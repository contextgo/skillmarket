# War Conflict Intel and Forecast

A source-disciplined OpenClaw skill for war monitoring, geopolitical conflict intelligence, scenario forecasting, and editor-style premium brief generation. It helps an agent turn noisy, fast-moving conflict information into structured evidence packs, clearer assessments, and readable briefs while preserving the boundary between confirmed facts, actor statements, inference, and forecasts.

## What it is good for

- War and geopolitical conflict monitoring
- Escalation risk tracking
- Multi-source synthesis and source ranking
- Scenario-based forecasting
- Analyst-style intelligence notes
- Editorial intelligence digest / premium brief output

## Core workflow

1. **Collector** — classify the conflict profile, gather source-ranked evidence, label claims, and produce a structured evidence pack.
2. **Analyzer** — separate facts from inference, test alternative explanations, identify actor goals and constraints, and build time-horizon scenarios.
3. **Writer** — convert the analysis into a clear user-facing deliverable while preserving confidence discipline and traceability.

## Safety and scope

This skill is for open-source analysis only. It does not provide classified intelligence, operational instructions, propaganda, or fantasy war writing. It adds no credentials, no executable scripts, and no external network side effects by itself.

## Main files

- `SKILL.md`
- `tasks/collector_task.md`
- `tasks/analyzer_task.md`
- `tasks/writer_task.md`
- `tasks/editorial_digest_template.md`
- `CHANGELOG.md`

## Version

Current release: `1.0.5`
