# editorial_digest_template.md

## Purpose
This is the standard sample template for `Mode E: Editorial intelligence digest`.
Use it when the user wants a polished, readable, editor-style intelligence brief.

This template is not a rigid fill-in-the-blanks script.
It is a shape-control tool.
The goal is to preserve:
- readability
- structure
- evidence discipline
- light but recoverable attribution
- one analytical turn per section

---

## Standard Shape

# 编辑精选｜<YYYY-MM-DD>

<用一段简短导读交代过去24小时或本期最重要的风险主线。不要堆事实，要先告诉读者：今天真正重要的是什么，哪些变量正在重新绑定或松动。>

### <板块一标题>
<先写事实层。用自然语言，不要显式露出“谁/何时/做了什么/影响”的机械标签。尽量把相关事实组织成一条完整叙述链。>

<板块一的短分析段。长度通常 2–4 句。回答：这件事为什么值得看，它会影响什么，它更像短期噪音还是结构性变化。>

### <板块二标题>
<事实层。可以用 2–3 个自然段，不必强行压成一句。>

<短分析段。必须有一个“编辑判断”转身，不能只是复述。>

### <板块三标题>
<事实层。若涉及数据、政策或市场，优先写最能改变预期的那部分。>

<短分析段。尽量指出“表面现象”和“真正重要变量”之间的差别。>

### <可选：舆情温度 / 公共注意力>
<只有在确有必要时才加。热榜、社交平台或大众注意力只能作为 secondary signal，不能抢主线。>

<短分析段。说明它和政策/市场/战争主线之间是同步、错位还是无关。>

### 接下来最该盯的几件事
- <变量 1>
- <变量 2>
- <变量 3>

---

## Compact Source Block
在正文后用紧凑格式列来源，不要在正文里堆满引用噪音。
仅在以下情况保留正文内轻量引用：
- 争议事实
- 单源细节
- 高敏感判断

示例：
- `[R1]` Reuters, 2026-04-29, <title>
- `[AP1]` AP, 2026-04-29, <title>
- `[WH1]` White House, 2026-04-28, <title>

---

## Tone Standard
Desired tone:
- calm
- precise
- editorial rather than bureaucratic
- confident only where evidence supports confidence

Avoid:
- theatrical escalation
- fake omniscience
- “近日/近期/最新形势表明” 这类空泛过渡
- 把读者当成需要被喊醒的人

---

## Editorial Checklist
Before delivering, verify:
- opening paragraph gives a real top-line judgment
- every section contains both facts and one short analysis turn
- no section is just stacked snippets
- dates are concrete where needed
- source discipline survives even if citations are mostly end-loaded
- the piece reads like a premium brief, not a form output
