# PUBLISHING_COPY.md

## 1) One-line description
A source-disciplined OpenClaw skill for war monitoring, geopolitical conflict intelligence, scenario forecasting, and editor-style premium brief generation.

## 2) Short public description
`war-conflict-intel-and-forecast` helps turn messy, fast-moving conflict information into structured evidence, clearer analysis, and readable high-quality output.

It is designed for war monitoring, geopolitical escalation tracking, scenario-based forecasting, and premium daily brief generation. The workflow separates collection, analysis, and writing, keeps fact/claim/inference boundaries visible, and supports both analyst-style outputs and cleaner editor-style briefs.

## 3) Long public description
`war-conflict-intel-and-forecast` is an OpenClaw skill built for high-noise, high-stakes information environments.

It is designed to help an agent collect conflict-related developments from ranked sources, separate confirmed facts from statements and inference, evaluate contradiction and uncertainty, and produce outputs that are both analytically disciplined and readable.

The skill is especially useful for:
- war monitoring
- geopolitical escalation tracking
- conflict scenario analysis
- source-ranked synthesis
- premium brief / 编辑精选 style delivery

Recent upgrades turned it from a strong analyst handbook into a more executable workflow.
It now includes:
- a collector / analyzer / writer task split
- structured evidence-pack logic
- stable source reference ids such as `R1`, `AP1`, `WH1`
- refined claim-status handling
- an `editorial intelligence digest` mode for cleaner user-facing output
- a standard editorial digest template for more stable delivery

This makes the skill useful not only for research-heavy conflict tracking, but also for producing polished, source-disciplined briefs that do not read like bureaucratic templates.

## 4) Update announcement
### v1.0.5 update
This release-polish update makes the skill cleaner and more marketplace-ready while preserving the v1.0.4 intelligence workflow improvements.

What changed:
- refined editorial-mode output after real test runs
- reduced citation clutter in user-facing briefs
- added compact end-loaded source block guidance
- required a short analytical turn at the end of each editorial section
- added public-sentiment guardrails so hot-list signals remain secondary
- added a standard `editorial_digest_template.md`
- moved release/support copy behind progressive disclosure in `references/`
- kept the public package lighter and easier to inspect
- retained v1.0.4 workflow improvements and editorial digest mode

Net effect:
The skill remains strong at switching between analyst-grade intelligence work and premium editor-style delivery, while the public package is now cleaner for installation and review.

## 5) Marketplace listing description
Track war and geopolitical conflict developments with stronger source discipline, clearer fact/claim separation, scenario-based analysis, and editor-style premium brief output.

Best for:
- conflict monitoring
- strategic risk tracking
- multi-source synthesis
- premium brief generation

Includes:
- collector / analyzer / writer workflow
- structured evidence handling
- source reference ids
- scenario framing
- editorial intelligence digest mode

## 6) Chinese public-facing description
这是一个面向战争监控、地缘冲突跟踪、情景推演与高质量简报交付的 OpenClaw skill。

它的核心能力不是简单“搜新闻”，而是把高噪声、高不确定性的冲突信息，整理成更有结构的证据包，并进一步区分：什么是已确认事实，什么是单方表述，什么是高可信推断，什么仍然存在争议。

在最近几个版本中，这个 skill 已经从一份“分析员工作手册”，升级成一套更接近可执行 workflow 的系统。它现在不仅能支持 analyst 风格的分析输出，也能支持更自然、更易读、但仍保留来源纪律的“编辑精选”式成品交付。

适合的使用场景包括：
- 战争与冲突动态监控
- 地缘政治升级风险跟踪
- 多源信息交叉整理
- 情景预测与风险研判
- 高质量每日简报 / 编辑精选
