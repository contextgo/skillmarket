# RELEASE_NOTES_v1.0.4

## war-conflict-intel-and-forecast — v1.0.4

This release turns the skill into a more publish-ready intelligence workflow for war monitoring, geopolitical conflict tracking, scenario analysis, and editor-style premium brief generation.

## What's new in v1.0.4
- refined the `editorial intelligence digest` mode after a real test run
- reduced noisy in-body citations for user-facing outputs
- added compact source-block guidance for cleaner premium briefs
- required one short analytical turn at the end of each editorial section
- added guardrails for public-sentiment / hot-list usage so heat signals remain secondary

## What was already upgraded in the recent iterations
- split the workflow into:
  - `collector_task.md`
  - `analyzer_task.md`
  - `writer_task.md`
- added structured evidence-pack logic
- added stable source ids like `R1`, `AP1`, `WH1`
- refined claim-status taxonomy to distinguish:
  - confirmed event
  - confirmed statement
  - disputed consequence
  - single-source detail
  - high-confidence inference
  - unverified / preliminary
- added `Mode E: Editorial intelligence digest`
- added `tasks/editorial_digest_template.md` for stable editor-style outputs
- added `CHANGELOG.md` for version tracking

## Why this matters
The skill is no longer just an analyst handbook.
It now behaves much more like an executable workflow that can:
- collect evidence in a structured way
- separate facts, claims, and inferences more clearly
- produce scenario-based analysis with visible uncertainty
- switch between analyst-style output and cleaner editor-style delivery

## Recommended use cases
- fast conflict monitoring
- geopolitical escalation tracking
- scenario-based forecasting
- premium daily brief / 编辑精选 generation
- source-ranked synthesis for sensitive international topics

## Main files
- `SKILL.md`
- `CHANGELOG.md`
- `tasks/collector_task.md`
- `tasks/analyzer_task.md`
- `tasks/writer_task.md`
- `tasks/editorial_digest_template.md`

## Current version
- `1.0.4`
