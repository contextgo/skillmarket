# RELEASE_NOTES_v1.0.5

## war-conflict-intel-and-forecast — v1.0.5

This is a marketplace release-polish update.

## What's new
- kept the core collector / analyzer / writer workflow intact
- slimmed the public package by moving marketplace copy and older release notes into `references/`
- synchronized metadata and changelog to v1.0.5
- retained the editorial intelligence digest mode introduced in recent versions
- added no new permissions, credentials, executable scripts, or network side effects

## Why this matters
The skill is easier to inspect, safer to review, and cleaner to publish while preserving the analytical workflow built through v1.0.4.
