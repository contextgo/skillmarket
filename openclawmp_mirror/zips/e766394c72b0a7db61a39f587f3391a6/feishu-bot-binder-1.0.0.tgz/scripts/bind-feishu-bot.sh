#!/usr/bin/env bash
# ============================================================================
# bind-feishu-bot.sh — 给 OpenClaw 绑定一个新的飞书机器人
#
# 用法:
#   bash bind-feishu-bot.sh \
#     --agent-id "customer-service" \
#     --agent-name "客服助手" \
#     --agent-emoji "🎧" \
#     --app-id "cli_xxx" \
#     --app-secret "xxx" \
#     --model "modelsproxy-openai/gpt-5-nano" \
#     --dm-policy "open" \
#     --group-policy "open" \
#     --require-mention "true"
#
# 做了什么:
#   1. 创建 agent 目录
#   2. 写入飞书 account 配置到 openclaw.json
#   3. 写入 agent 配置到 openclaw.json
#   4. 写入 binding 路由规则到 openclaw.json
#   5. 重启 gateway
#
# 安全:
#   - 不覆盖已有同名 account/agent
#   - 每一步都检查错误
#   - 出错立即停止
# ============================================================================

set -euo pipefail

# ============ 颜色 ============
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
fail() { echo -e "${RED}❌ $1${NC}"; exit 1; }

# ============ 解析参数 ============
AGENT_ID=""
AGENT_NAME=""
AGENT_EMOJI=""
APP_ID=""
APP_SECRET=""
MODEL="modelsproxy-openai/gpt-5-nano"
DM_POLICY="open"
GROUP_POLICY="open"
REQUIRE_MENTION="false"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --agent-id)      AGENT_ID="$2";      shift 2 ;;
    --agent-name)    AGENT_NAME="$2";    shift 2 ;;
    --agent-emoji)   AGENT_EMOJI="$2";   shift 2 ;;
    --app-id)        APP_ID="$2";        shift 2 ;;
    --app-secret)    APP_SECRET="$2";    shift 2 ;;
    --model)         MODEL="$2";         shift 2 ;;
    --dm-policy)     DM_POLICY="$2";     shift 2 ;;
    --group-policy)  GROUP_POLICY="$2";  shift 2 ;;
    --require-mention) REQUIRE_MENTION="$2"; shift 2 ;;
    *) fail "未知参数: $1" ;;
  esac
done

# ============ 参数校验 ============
[[ -z "$AGENT_ID" ]]   && fail "缺少 --agent-id"
[[ -z "$APP_ID" ]]     && fail "缺少 --app-id"
[[ -z "$APP_SECRET" ]] && fail "缺少 --app-secret"

# agent-name 默认用 agent-id
[[ -z "$AGENT_NAME" ]] && AGENT_NAME="$AGENT_ID"
[[ -z "$AGENT_EMOJI" ]] && AGENT_EMOJI="🤖"

# 校验 App ID 格式
[[ "$APP_ID" =~ ^cli_ ]] || fail "App ID 格式错误，应以 cli_ 开头，当前值: $APP_ID"

echo "============================================"
echo "飞书机器人绑定配置"
echo "============================================"
echo "Agent ID:       $AGENT_ID"
echo "Agent Name:     $AGENT_NAME"
echo "Agent Emoji:    $AGENT_EMOJI"
echo "App ID:         $APP_ID"
echo "App Secret:     ${APP_SECRET:0:6}***"
echo "Model:          $MODEL"
echo "DM Policy:      $DM_POLICY"
echo "Group Policy:   $GROUP_POLICY"
echo "Require @:      $REQUIRE_MENTION"
echo "============================================"
echo ""

OPENCLAW_DIR="$HOME/.openclaw"
CONFIG_FILE="$OPENCLAW_DIR/openclaw.json"
AGENT_DIR="$OPENCLAW_DIR/agents/$AGENT_ID/agent"
WORKSPACE_DIR="$OPENCLAW_DIR/workspace"

# ============ 前置检查 ============
echo "🔍 前置检查..."

# 检查 openclaw.json 存在
[[ -f "$CONFIG_FILE" ]] || fail "找不到 $CONFIG_FILE，请先完成 OpenClaw 初始化"

# 检查 openclaw 命令存在
command -v openclaw &>/dev/null || fail "找不到 openclaw 命令，请确认已安装"

# 检查是否已有同名 feishu account
EXISTING_ACCOUNT=$(python3 -c "
import json, sys
with open('$CONFIG_FILE') as f:
    cfg = json.load(f)
accounts = cfg.get('channels', {}).get('feishu', {}).get('accounts', {})
if '$AGENT_ID' in accounts:
    print('EXISTS')
else:
    print('OK')
" 2>/dev/null || echo "ERROR")

if [[ "$EXISTING_ACCOUNT" == "EXISTS" ]]; then
    fail "飞书 account '$AGENT_ID' 已存在！如需覆盖请先手动删除。"
elif [[ "$EXISTING_ACCOUNT" == "ERROR" ]]; then
    fail "无法读取 openclaw.json，请检查 JSON 格式。"
fi

# 检查是否已有同名 agent
EXISTING_AGENT=$(python3 -c "
import json, sys
with open('$CONFIG_FILE') as f:
    cfg = json.load(f)
agents = cfg.get('agents', {}).get('list', [])
for a in agents:
    if a.get('id') == '$AGENT_ID':
        print('EXISTS')
        sys.exit(0)
print('OK')
" 2>/dev/null || echo "ERROR")

if [[ "$EXISTING_AGENT" == "EXISTS" ]]; then
    warn "Agent '$AGENT_ID' 已存在，将跳过 agent 创建，只添加飞书 account 和 binding。"
fi

ok "前置检查通过"
echo ""

# ============ Step 1: 创建 agent 目录 ============
echo "📁 Step 1: 创建 agent 目录..."

mkdir -p "$AGENT_DIR"
ok "目录已创建: $AGENT_DIR"
echo ""

# ============ Step 2: 写入飞书 account 配置 ============
echo "📝 Step 2: 写入飞书 account 配置..."

# 用 python3 直接安全地修改 JSON（避免 openclaw config set 对复杂嵌套的兼容问题）
python3 << PYEOF
import json, sys, shutil, os

config_file = "$CONFIG_FILE"

# 备份
shutil.copy2(config_file, config_file + ".bak.feishu-binder")

with open(config_file) as f:
    cfg = json.load(f)

# 确保 channels.feishu.accounts 存在
cfg.setdefault("channels", {})
cfg["channels"].setdefault("feishu", {})
cfg["channels"]["feishu"].setdefault("accounts", {})

# 写入新 account
account_id = "$AGENT_ID"
cfg["channels"]["feishu"]["accounts"][account_id] = {
    "enabled": True,
    "appId": "$APP_ID",
    "appSecret": "$APP_SECRET",
    "dmPolicy": "$DM_POLICY",
    "groupPolicy": "$GROUP_POLICY",
    "requireMention": $( [[ "$REQUIRE_MENTION" == "true" ]] && echo "True" || echo "False" ),
    "allowFrom": ["*"]
}

with open(config_file, "w") as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)

print("OK")
PYEOF

ok "飞书 account '$AGENT_ID' 已写入"
echo ""

# ============ Step 3: 写入 agent 配置 ============
echo "📝 Step 3: 写入 agent 配置..."

if [[ "$EXISTING_AGENT" == "EXISTS" ]]; then
    warn "Agent '$AGENT_ID' 已存在，跳过创建"
else
    python3 << PYEOF
import json

config_file = "$CONFIG_FILE"
with open(config_file) as f:
    cfg = json.load(f)

cfg.setdefault("agents", {})
cfg["agents"].setdefault("list", [])

new_agent = {
    "id": "$AGENT_ID",
    "name": "$AGENT_ID",
    "workspace": "$WORKSPACE_DIR",
    "agentDir": "$AGENT_DIR",
    "model": "$MODEL",
    "identity": {
        "name": "$AGENT_NAME",
        "emoji": "$AGENT_EMOJI"
    },
    "subagents": {
        "allowAgents": []
    }
}

cfg["agents"]["list"].append(new_agent)

with open(config_file, "w") as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)

print("OK")
PYEOF

    ok "Agent '$AGENT_ID' 已添加到 agents.list"
fi
echo ""

# ============ Step 4: 写入 binding ============
echo "📝 Step 4: 写入 binding 路由规则..."

python3 << PYEOF
import json

config_file = "$CONFIG_FILE"
with open(config_file) as f:
    cfg = json.load(f)

cfg.setdefault("bindings", [])

# 检查是否已存在同样的 binding
for b in cfg["bindings"]:
    match = b.get("match", {})
    if match.get("channel") == "feishu" and match.get("accountId") == "$AGENT_ID":
        print("SKIP - binding already exists")
        import sys; sys.exit(0)

new_binding = {
    "type": "route",
    "agentId": "$AGENT_ID",
    "match": {
        "channel": "feishu",
        "accountId": "$AGENT_ID"
    }
}

cfg["bindings"].append(new_binding)

with open(config_file, "w") as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)

print("OK")
PYEOF

ok "Binding 已写入: feishu/$AGENT_ID → agent/$AGENT_ID"
echo ""

# ============ Step 5: 验证 JSON ============
echo "🔍 Step 5: 验证配置文件..."

python3 -c "
import json
with open('$CONFIG_FILE') as f:
    json.load(f)
print('OK')
" || {
    warn "JSON 格式异常！正在回滚..."
    cp "$CONFIG_FILE.bak.feishu-binder" "$CONFIG_FILE"
    fail "配置写入失败，已回滚到备份版本"
}

ok "JSON 格式验证通过"
echo ""

# ============ Step 6: 重启 gateway ============
echo "🔄 Step 6: 重启 gateway..."

openclaw gateway restart 2>&1 || warn "Gateway 重启可能需要手动操作"

# 等一会让 gateway 启动
sleep 3

echo ""
ok "=========================================="
ok "🎉 飞书机器人绑定完成！"
ok "=========================================="
echo ""
echo "📋 绑定摘要:"
echo "   Agent:    $AGENT_ID ($AGENT_NAME $AGENT_EMOJI)"
echo "   飞书应用:  $APP_ID"
echo "   Account:  $AGENT_ID"
echo "   DM策略:   $DM_POLICY"
echo "   群聊策略:  $GROUP_POLICY"
echo ""
echo "📋 下一步:"
echo "   1. 在飞书中找到新机器人，发一条消息测试"
if [[ "$DM_POLICY" == "pairing" ]]; then
echo "   2. 运行 'openclaw pairing approve feishu <CODE>' 批准配对"
fi
echo "   3. 查看日志: openclaw logs --follow"
echo "   4. 查看状态: openclaw channels status"
echo ""
echo "📋 备份文件: $CONFIG_FILE.bak.feishu-binder"
