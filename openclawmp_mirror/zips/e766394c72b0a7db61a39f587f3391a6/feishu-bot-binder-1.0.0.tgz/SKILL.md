---
name: feishu-bot-binder
version: 1.0.1
description: |
  给 OpenClaw subagent 绑定一个新的飞书机器人。适用于：已有一个龙虾绑定了飞书机器人，需要再绑一个新飞书机器人给另一个 agent。

  **使用场景**：
  (1) 用户说"绑定新飞书机器人"、"加一个飞书 bot"、"新建飞书 agent"
  (2) 用户提供了飞书 App ID 和 App Secret，要求绑到某个 agent
  (3) 用户想让不同飞书机器人连到不同 agent（如客服、财务、健康等）

  **不适用**：
  - 首次安装 OpenClaw + 飞书（用 `openclaw onboard`）
  - 修改已有飞书机器人配置（直接编辑 openclaw.json）
---

# 飞书机器人绑定 Skill

## 概述

本 skill 将一个**新的飞书机器人**绑定到 OpenClaw 的一个 **agent**（可以是新建的 agent，也可以是已有的 agent）。

整个过程分 **两个阶段**：
1. **飞书开放平台配置**（需要用户在浏览器操作）
2. **OpenClaw 配置**（agent 执行 shell 命令 + 编辑 JSON）

## ⚠️ 前置条件

- OpenClaw 已安装且 gateway 正在运行
- 已有至少一个飞书机器人正常工作
- 用户有飞书开放平台管理员权限

## 执行流程

### 第 1 步：收集信息

向用户确认以下信息：

| 信息 | 说明 | 示例 |
|------|------|------|
| **Agent ID** | 新 agent 的唯一标识（英文+数字+连字符，不含空格） | `customer-service` |
| **Agent 名称** | 显示名称（中文ok） | `客服助手` |
| **Agent Emoji** | 一个 emoji | `🎧` |
| **飞书 App ID** | 从飞书开放平台获取（格式 `cli_xxx`） | `cli_a9xxxxxxxxxxxx` |
| **飞书 App Secret** | 从飞书开放平台获取 | `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx` |
| **模型** | agent 使用的模型（可选，默认用系统默认模型） | `modelsproxy-openai/gpt-5-nano` |
| **DM 策略** | `open`（所有人可用）或 `pairing`（需配对）| `open` |
| **群聊策略** | `open` / `allowlist` / `disabled` | `open` |
| **是否需要 @** | 群聊是否需要 @机器人 才回复 | `true` |

**如果用户还没有创建飞书应用**，先引导用户完成第 2 步。
**如果用户已经有 App ID 和 App Secret**，跳到第 3 步。

### 第 2 步：引导用户在飞书开放平台创建应用

> 这一步是用户在浏览器中操作，agent 只负责给出指引。

发送以下消息给用户（可以直接复制）：

---

**请在飞书开放平台完成以下操作：**

1️⃣ 打开 https://open.feishu.cn/app → 登录 → 点击「创建企业自建应用」

2️⃣ 填写应用名称和描述 → 创建

3️⃣ 进入应用 → 「凭证与基础信息」→ 复制 **App ID** 和 **App Secret** 发给我

4️⃣ 进入「权限管理」→ 点击「批量开通」→ 粘贴以下 JSON：

```json
{"scopes":{"tenant":["aily:file:read","aily:file:write","application:application.app_message_stats.overview:readonly","application:application:self_manage","application:bot.menu:write","cardkit:card:read","cardkit:card:write","contact:user.employee_id:readonly","corehr:file:download","event:ip_list","im:chat.access_event.bot_p2p_chat:read","im:chat.members:bot_access","im:message","im:message.group_at_msg:readonly","im:message.p2p_msg:readonly","im:message:readonly","im:message:send_as_bot","im:resource"],"user":["aily:file:read","aily:file:write","im:chat.access_event.bot_p2p_chat:read"]}}
```

5️⃣ 进入「应用能力」→ 开启「机器人」能力 → 设置机器人名称

6️⃣ 进入「事件与回调」→ 订阅方式选「使用长连接接收事件」→ 添加事件 `im.message.receive_v1`

7️⃣ 如果需要卡片交互：在「事件与回调」添加 `card.action.trigger`

8️⃣ 创建版本 → 提交审核 → 发布

完成后把 **App ID** 和 **App Secret** 发给我。

---

### 第 3 步：执行 OpenClaw 配置

当用户提供了 App ID 和 App Secret 后，执行配置脚本。

**读取并执行** `scripts/bind-feishu-bot.sh`：

```bash
bash <skill_dir>/scripts/bind-feishu-bot.sh \
  --agent-id "<AGENT_ID>" \
  --agent-name "<AGENT_NAME>" \
  --agent-emoji "<EMOJI>" \
  --app-id "<APP_ID>" \
  --app-secret "<APP_SECRET>" \
  --model "<MODEL>" \
  --dm-policy "<DM_POLICY>" \
  --group-policy "<GROUP_POLICY>" \
  --require-mention "<true|false>"
```

> `<skill_dir>` 是本 SKILL.md 所在目录的绝对路径。

**脚本做了什么**（按顺序）：
1. 创建 agent 目录：`~/.openclaw/agents/<agent-id>/agent/`
2. 用 `openclaw config set` 写入 feishu account 配置
3. 用 `openclaw config set` 写入 agent 配置
4. 用 `openclaw config set` 写入 binding 路由规则
5. 重启 gateway

### 第 4 步：验证

脚本执行完成后，做以下验证：

```bash
# 1. 检查 gateway 状态
openclaw gateway status

# 2. 检查通道状态
openclaw channels status

# 3. 查看日志确认连接
openclaw logs --follow
```

告诉用户：
- 在飞书中找到新机器人，发一条消息测试
- 如果 dmPolicy 是 `pairing`，需要用 `openclaw pairing approve feishu <CODE>` 批准配对

### 第 5 步（可选）：自定义 Agent 行为

如果用户需要给 agent 配置 SOUL.md、workspace 等：

```bash
# 创建 agent 专属 workspace（可选）
mkdir -p ~/.openclaw/workspace-<agent-id>

# 创建 SOUL.md（可选）
cat > ~/.openclaw/agents/<agent-id>/agent/SOUL.md << 'EOF'
# 你是 <agent-name>
（在这里写 agent 的人格和行为规则）
EOF
```

## 故障排查

| 问题 | 解决方案 |
|------|----------|
| Gateway 重启失败 | 运行 `openclaw doctor` 检查配置 |
| 机器人不响应 | 检查飞书应用是否已发布、事件订阅是否配置 |
| 提示 schema 校验失败 | 检查 JSON 格式，运行 `openclaw config validate` |
| 日志报 WebSocket 连接失败 | 确认应用已开启「长连接接收事件」 |

## 注意事项

- 每个飞书应用只能绑定一个 account，一个 account 只能路由到一个 agent
- account ID 建议和 agent ID 保持一致，方便管理
- 如果同名 account 已存在，脚本会报错并退出（不覆盖）
- 脚本不会删除任何已有配置，只做新增
