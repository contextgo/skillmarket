# 高级配置参考

## 自定义 Workspace

默认情况下，新 agent 共享主 workspace（`~/.openclaw/workspace`）。如果需要独立 workspace：

```bash
# 创建独立 workspace
mkdir -p ~/.openclaw/workspace-<agent-id>

# 然后修改 openclaw.json 中 agent 的 workspace 字段
openclaw config set 'agents.list[?(@.id=="<agent-id>")].workspace' '~/.openclaw/workspace-<agent-id>'
```

或直接编辑 openclaw.json，修改对应 agent 的 `workspace` 字段。

## 群聊白名单

如果 groupPolicy 设为 `allowlist`，需要配置允许的群：

```json
{
  "accounts": {
    "<agent-id>": {
      "groupPolicy": "allowlist",
      "groupAllowFrom": ["oc_xxx", "oc_yyy"]
    }
  }
}
```

获取群 ID 的方法：
1. 启动 gateway，在群里 @机器人
2. 看日志：`openclaw logs --follow`，找到 `chat_id`

## DM 白名单

限制只有特定用户能私聊：

```json
{
  "accounts": {
    "<agent-id>": {
      "dmPolicy": "open",
      "allowFrom": ["ou_xxx", "ou_yyy"]
    }
  }
}
```

## 给 Agent 写 SOUL.md

```bash
cat > ~/.openclaw/agents/<agent-id>/agent/SOUL.md << 'SOUL'
# 角色定义

你是 [角色名称]。

## 行为规则
- 规则1
- 规则2

## 语气
- 友好/专业/幽默等
SOUL
```

## 给 Agent 配置专属模型

编辑 `~/.openclaw/agents/<agent-id>/agent/models.json`：

```json
{
  "providers": {
    "modelsproxy-openai": {
      "baseUrl": "https://your-model-provider.example.com/v1",
      "apiKey": "<your-api-key>",
      "api": "openai-completions",
      "models": [
        {
          "id": "gpt-5-nano",
          "name": "GPT-5 Nano",
          "reasoning": false,
          "input": ["text", "image"],
          "contextWindow": 200000,
          "maxTokens": 8192
        }
      ]
    }
  }
}
```

## 给 Agent 配置 MCP Server

编辑 `~/.openclaw/agents/<agent-id>/agent/config.json`：

```json
{
  "mcpServers": {
    "server-name": {
      "command": "/path/to/server",
      "args": ["--arg1"],
      "env": {
        "API_KEY": "xxx"
      }
    }
  }
}
```

## Lark (国际版) 配置

如果是 Lark 而非飞书：

```json
{
  "accounts": {
    "<agent-id>": {
      "domain": "lark",
      "appId": "cli_xxx",
      "appSecret": "xxx"
    }
  }
}
```

## 删除绑定

如果要移除一个飞书机器人绑定：

1. 删除 `channels.feishu.accounts.<agent-id>`
2. 删除 `agents.list` 中对应 agent（如果不再需要）
3. 删除 `bindings` 中对应条目
4. 可选：删除 `~/.openclaw/agents/<agent-id>` 目录
5. `openclaw gateway restart`

## 常见 Account 配置字段

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `enabled` | bool | `true` | 是否启用 |
| `appId` | string | - | 飞书 App ID |
| `appSecret` | string | - | 飞书 App Secret |
| `domain` | string | `"feishu"` | `"feishu"` 或 `"lark"` |
| `dmPolicy` | string | `"pairing"` | DM 策略 |
| `groupPolicy` | string | `"open"` | 群聊策略 |
| `requireMention` | bool | `true` | 群聊是否需要 @ |
| `allowFrom` | array | - | 允许的用户 open_id |
| `groupAllowFrom` | array | - | 允许的群 chat_id |
| `typingIndicator` | bool | `true` | 是否显示"正在输入" |
| `streaming` | string | - | 流式回复（`true`/`false`/`"partial"`） |
