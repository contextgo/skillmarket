# Feishu Bot Binder — 一键绑定飞书机器人

> 已有一只龙虾绑了飞书？再绑一个，一条命令搞定。

## 解决什么问题

OpenClaw 支持多 agent 架构——客服、财务、健康教练……每个 agent 可以绑定自己专属的飞书机器人。但手动配置涉及：

- 创建 agent 目录
- 编辑 `openclaw.json` 的 3 个不同位置（accounts / agents.list / bindings）
- JSON 格式不能出错
- 重启 gateway

**这个 Skill 把以上全部自动化为一条 bash 命令。**

## 特性

- **防呆设计**：脚本校验所有参数、检测冲突、JSON 写入前备份、失败自动回滚
- **零 JSON 编辑**：Agent 不需要手动编辑 `openclaw.json`，Python 安全读写
- **完整引导**：SKILL.md 包含飞书开放平台的逐步操作指引，可直接发给用户
- **幂等安全**：同名 account/agent 已存在时报错退出，绝不覆盖
- **开箱即用**：收齐 App ID + App Secret，一条命令完成全部配置

## 适用场景

| 场景 | 示例 |
|------|------|
| 给新 agent 绑飞书机器人 | "帮我的客服 agent 绑一个飞书 bot" |
| 多机器人多 agent 架构 | 主号、客服号、财务号各用不同飞书应用 |
| 批量部署 | 运维脚本循环调用，批量绑定多个机器人 |

## 前置条件

- OpenClaw 已安装，gateway 正在运行
- 已有至少一个飞书机器人正常工作
- 飞书开放平台管理员权限
- Python 3 可用（脚本用 Python 做 JSON 读写）

## 使用方法

### 1. 在飞书开放平台创建应用

Skill 内含完整的分步指引（含权限 JSON、事件订阅配置），Agent 会直接发给用户。

### 2. 执行绑定

```bash
bash <skill_dir>/scripts/bind-feishu-bot.sh \
  --agent-id "customer-service" \
  --agent-name "客服助手" \
  --agent-emoji "🎧" \
  --app-id "cli_a9xxxxxxxxxxxx" \
  --app-secret "your-app-secret-here" \
  --model "modelsproxy-openai/gpt-5-nano" \
  --dm-policy "open" \
  --group-policy "open" \
  --require-mention "true"
```

### 3. 验证

```bash
openclaw gateway status
openclaw channels status
```

在飞书找到新机器人，发一条消息测试。

## 参数说明

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `--agent-id` | ✅ | - | Agent 唯一标识 |
| `--agent-name` | ❌ | 同 agent-id | 显示名称 |
| `--agent-emoji` | ❌ | 🤖 | Emoji 标识 |
| `--app-id` | ✅ | - | 飞书 App ID（`cli_xxx`） |
| `--app-secret` | ✅ | - | 飞书 App Secret |
| `--model` | ❌ | `modelsproxy-openai/gpt-5-nano` | 使用的模型 |
| `--dm-policy` | ❌ | `open` | DM 策略 |
| `--group-policy` | ❌ | `open` | 群聊策略 |
| `--require-mention` | ❌ | `false` | 群聊是否需要 @ |

## 文件结构

```
feishu-bot-binder/
├── SKILL.md                    # 主指令（Agent 读这个）
├── README.md                   # 说明文档（你在看的这个）
├── scripts/
│   └── bind-feishu-bot.sh      # 核心绑定脚本
└── references/
    └── advanced-config.md      # 高级配置（workspace/白名单/SOUL.md 等）
```

## 脚本执行流程

1. ✅ 参数校验（缺参数/格式错误直接报错）
2. ✅ 冲突检测（同名 account/agent 报错退出）
3. ✅ 创建 agent 目录
4. ✅ 备份 `openclaw.json`
5. ✅ 写入飞书 account 配置
6. ✅ 写入 agent 到 agents.list
7. ✅ 写入 binding 路由规则
8. ✅ JSON 格式验证（失败自动回滚）
9. ✅ 重启 gateway

## 兼容性

- OpenClaw 2026.3.x+
- macOS / Linux
- Python 3.6+
- Bash 4.0+

## 作者

海洋大总管 🦞
