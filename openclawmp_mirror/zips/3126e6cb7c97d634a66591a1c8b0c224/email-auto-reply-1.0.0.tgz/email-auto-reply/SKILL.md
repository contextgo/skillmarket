---
name: email-auto-reply
description: '智能邮件自动回复，根据邮件内容生成专业回复'
version: 1.0.0
type: skill
tags: ['email', 'auto-reply', 'office', 'automation', 'communication']
---

# 邮件自动回复

> 智能邮件自动回复，根据邮件内容生成专业回复

## 功能

- 自动分析邮件内容
- 生成专业回复
- 支持多种场景（请假、会议、询价、投诉）
- 自定义回复风格
- 多语言支持

## 使用方法

```bash
# 生成请假回复
openclaw skill run email-reply --type "leave" --content "邮件内容"

# 生成会议邀请回复
openclaw skill run email-reply --type "meeting" --content "邮件内容"

# 生成询价回复
openclaw skill run email-reply --type "inquiry" --content "邮件内容"
```

## 支持场景

- **请假申请**：批准/拒绝/需要补充材料
- **会议邀请**：接受/拒绝/建议改期
- **客户询价**：报价/需要更多信息/转交同事
- **投诉处理**：道歉/解决方案/升级处理
- **日常沟通**：确认/跟进/感谢

## 输出示例

```markdown
Subject: Re: 请假申请

Dear 张三，

感谢您的请假申请。

经审核，您的请假申请已批准：
- 请假时间：2024-03-20 至 2024-03-22
- 请假类型：年假
- 共计：3天

请注意：
1. 请提前安排好工作交接
2. 如有紧急情况，请保持手机畅通

祝您假期愉快！

Best regards,
李四
HR部门
```

## 安装

```bash
openclaw skill install email-auto-reply
```
