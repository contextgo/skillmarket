# PPTX 演示助手

PPTX 演示助手 是一个面向 OpenClaw Agent 的技能资产，用于把特定任务场景沉淀为可复用、可执行、可验证的工作流程。

## 核心能力

- 根据用户任务触发对应的操作步骤
- 复用 `SKILL.md` 中定义的规则、边界和输出格式
- 提升 Agent 执行一致性，减少重复判断和无效沟通
- 适合安装到 OpenClaw 环境中作为能力扩展

## 原始能力简介

Use this skill any time a .pptx file is involved in any way — as input, output, or both. This includes: creating slide decks, pitch decks, or presentations; reading, parsing, or extracting text from any .pptx file (even if the extracted content will be used elsewhere, like in an email or summary); editing, modifying, or updating existing presentations; combining or splitting slide files; working with templates, layouts, speaker notes, or comments. Trigger whenever the user mentions \"deck,\" \"slides,\" \"presentation,\" or references a .pptx filename, regardless of what they plan to do with the content afterward. If a .pptx file needs to be opened, created, or touched, use this skill.

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他文件：技能所需参考资料、脚本或测试提示词
