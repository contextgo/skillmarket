# 飞书工具库 (Feishu Toolkit)

> **v1.0 发布** | 让 OpenClaw Agent 轻松集成飞书消息、群聊和文档管理

---

## 🌟 核心亮点：长连接监听（无需公网 IP！）

**这是本工具库的创新功能！** 传统飞书机器人需要公网域名 + HTTPS 回调 URL，而我们的长连接方案：

```
┌─────────────┐                   ┌──────────────┐
│  你的服务器  │  ─── WebSocket ───→ │  飞书服务器  │
│  (内网)     │   (出站连接)        │             │
└─────────────┘                   └──────────────┘
```

### ✅ 为什么选择长连接？

| 特性 | 传统 Webhook | 长连接监听 |
|------|-------------|-----------|
| **公网 IP** | ❌ 必需 | ✅ 不需要 |
| **HTTPS 证书** | ❌ 必需 | ✅ 不需要 |
| **入站端口** | ❌ 需开放 | ✅ 无需开放 |
| **内网部署** | ❌ 困难 | ✅ 原生支持 |
| **安全性** | ⚠️ 暴露公网 | ✅ 仅出站连接 |
| **配置复杂度** | ⚠️ 高（域名 + 证书 + 回调） | ✅ 低（只需 App ID/Secret） |

### 🚀 快速体验长连接监听

```bash
# 1. 配置应用
cp .lark-config.example.json .lark-config.json
# 编辑 .lark-config.json 填入你的 App ID 和 Secret

# 2. 安装依赖
npm install

# 3. 启动监听服务
node scripts/feishu-ws-listener.js

# 4. 在飞书群聊@机器人，立即响应！
```

**监听服务功能**：
- ✅ 自动连接飞书 WebSocket 服务器
- ✅ 接收@机器人消息、私聊消息
- ✅ 调用 OpenClaw Gateway 处理（支持任意大模型）
- ✅ 自动发送回复到飞书
- ✅ 断线自动重连
- ✅ Token 自动刷新

---

## 📦 功能概览

### 💬 消息工具
- ✅ 发送文本/富文本/文件/图片消息
- ✅ 消息回复功能（支持话题回复）
- ✅ 群聊管理（列表、查找、信息获取）
- ✅ 文件上传（支持图片、文档、压缩包）
- ✅ **长连接消息监听**（创新功能！）

### 📄 文档工具
- ✅ 读取飞书文档内容
- ✅ 创建新的飞书文档
- ✅ 支持 Markdown 转飞书文档
- ✅ 上传文件到飞书云空间

### 🌍 多区域支持
- **Lark（国际版）**：`open.larksuite.com`
- **飞书（中国版）**：`open.feishu.cn`

---

## 🚀 快速开始

### 1. 在飞书开放平台创建应用

1. 访问 https://open.feishu.cn/app
2. 创建企业自建应用
3. 获取凭证：
   - `App ID`（cli_xxxxx）
   - `App Secret`

4. 开通权限：
   - `im:message` - 消息发送
   - `im:chat` - 群聊管理
   - `docx:document` - 文档读写
   - `im:message.receive_v1` - 接收消息（长连接必需）

5. **启用长连接**（重要！）：
   - 进入"事件与回调"
   - "Subscription mode" 选择：**Receive events through persistent connection**
   - 保存并发布应用

### 2. 配置本地项目

```bash
# 复制配置模板
cp .lark-config.example.json .lark-config.json

# 编辑配置文件
{
  "app_id": "your_app_id_here",
  "app_secret": "your_app_secret_here",
  "region": "feishu"  # 或 "lark"
}
```

### 3. 安装依赖

```bash
npm install
```

### 4. 测试功能

```bash
# 列出所有群聊
node cli/list-chats.js

# 发送消息到指定群聊
node cli/send-message.js "群聊 A" "Hello World"

# 启动长连接监听服务
node scripts/feishu-ws-listener.js
```

---

## 📁 项目结构

```
feishu-toolkit/
├── .lark-config.example.json    # 配置模板
├── .lark-config.json            # 实际配置（需自行创建）
├── package.json
├── README.md
│
├── lib/                         # 核心库
│   ├── common/
│   │   └── auth.js              # 认证模块（Token 管理）
│   ├── message/
│   │   ├── message.js           # 消息发送
│   │   └── chat.js              # 群聊管理
│   └── index.js                 # 统一入口
│
├── cli/                         # 命令行工具
│   ├── list-chats.js            # 列出群聊
│   └── send-message.js          # 发送消息
│
├── scripts/                     # 高级脚本
│   ├── feishu-ws-listener.js    # 🌟 长连接监听服务
│   ├── lark-doc-reader.js       # 读取文档
│   ├── lark-doc-writer-v3.js    # 创建文档
│   ├── lark-file-uploader.js    # 上传文件
│   └── send-file-to-chat.js     # 发送文件到群聊
│
└── skills/
    └── feishu-sender/           # OpenClaw 技能
        ├── index.js
        └── SKILL.md
```

---

## 💻 使用方式

### 方式 1：作为 Node.js 库使用

```javascript
const { LarkAuth, LarkMessage, LarkChat } = require('./lib');

// 初始化
const auth = LarkAuth.fromConfig('.lark-config.json');
const message = new LarkMessage(auth);
const chat = new LarkChat(auth);

// 列出群聊
const chats = await chat.list();

// 查找群聊
const targetChat = await chat.findByName('群聊 A');

// 发送文本消息
await message.sendText(targetChat.chat_id, 'Hello World');

// 发送富文本消息
await message.sendRichText(chatId, {
  zh_cn: {
    title: '📢 通知',
    content: [
      [{ tag: 'text', text: '新功能已上线' }]
    ]
  }
});

// 上传并发送文件
const fileData = await message.uploadFile('./package.zip');
await message.sendFile(chatId, fileData.file_key);

// 发送图片
await message.sendImage(chatId, './screenshot.png', '图片说明');
```

### 方式 2：使用 CLI 工具

```bash
# 列出所有群聊
node cli/list-chats.js

# 发送消息
node cli/send-message.js "群聊 A" "Hello World"

# 读取飞书文档
node scripts/lark-doc-reader.js <doc_token>

# 创建飞书文档
node scripts/lark-doc-writer-v3.js <folder_token> "文档标题" "Markdown 内容"

# 上传文件到云空间
node scripts/lark-file-uploader.js ./file.pdf <folder_token>
```

### 方式 3：启动长连接监听服务

```bash
# 启动服务
node scripts/feishu-ws-listener.js

# 输出：
# ============================================================
# 🦞 飞书长连接监听服务
# ============================================================
# 📱 应用 ID: cli_xxxxx
# 🌐 区域：飞书中国版
# 🤖 Gateway: http://127.0.0.1:18789
# 🔌 模式：持久连接（WebSocket）
# ============================================================
#
# [09:00:00] ✅ Token 已刷新
# [09:00:01] 🔌 已连接到飞书 WebSocket 服务器
# [09:00:02] 🔄 服务就绪，等待消息...
#
# [09:05:00] 📨 收到消息：
#    类型：group
#    发送者：用户 XXX
#    内容：你好
# [09:05:01] 🤖 调用 Gateway 生成回复...
# [09:05:02] 📤 发送回复成功
```

### 方式 4：在 OpenClaw 中调用技能

```javascript
const feishuSender = require('feishu-sender');

// 发送文本
await feishuSender.sendText('oc_chat_id', '你好');

// 发送图片
await feishuSender.sendImage('oc_chat_id', '/path/to/image.png', '图片说明');

// 统一接口
await feishuSender.send('oc_chat_id', '文本内容', '/path/to/image.png', '说明');
```

---

## 🔐 安全说明

### 长连接安全优势

1. **仅出站连接**：你的服务器主动连接飞书，无需开放任何入站端口
2. **无公网暴露**：内网服务器即可运行，不暴露在公网
3. **自动认证**：Token 自动获取和刷新，无需手动管理
4. **本地 Gateway**：消息处理在本地完成，数据不出内网

### 配置安全建议

- ✅ 不要将 `.lark-config.json` 提交到 Git
- ✅ 使用 `.gitignore` 忽略配置文件
- ✅ 生产环境使用环境变量：
  ```bash
  export FEISHU_APP_ID="your_app_id"
  export FEISHU_APP_SECRET="your_app_secret"
  ```

---

## 🗺️ 版本规划

### ✅ v1.0（当前版本）

- ✅ 消息发送（文本/富文本/文件/图片）
- ✅ 群聊管理（列表/查找/信息）
- ✅ 🌟 长连接监听服务
- ✅ 文档读写基础功能
- ✅ 文件上传
- ✅ OpenClaw 技能集成

### 🚧 计划中功能

| 功能 | 说明 | 优先级 |
|------|------|--------|
| **群聊消息归纳总结** | 自动总结群聊讨论要点，生成会议纪要 | 🔥 高 |
| **文档智能模板** | 根据历史文档自动生成新文档模板 | 高 |
| **消息队列支持** | 批量发送、定时发送、失败重试 | 中 |
| **多机器人协作** | 多个机器人分工处理不同类型消息 | 中 |
| **消息过滤器** | 自定义规则过滤特定消息 | 中 |
| **Web 管理界面** | 可视化配置和监控面板 | 低 |
| **消息分析报表** | 统计消息量、响应时间、活跃度 | 低 |

### 💡 欢迎贡献

如果你有好的想法或想参与开发，欢迎在水产市场反馈！

---

## 🧪 测试

```bash
# 运行完整测试
node test.js

# 测试群聊列表
node cli/list-chats.js

# 测试消息发送
node cli/send-message.js "测试群" "测试消息"

# 测试长连接监听
node scripts/feishu-ws-listener.js
```

---

## ❓ 常见问题

### Q1: 长连接和 Webhook 有什么区别？

**A:** 长连接是你的服务器主动连接飞书（出站），Webhook 是飞书回调你的服务器（入站）。长连接无需公网 IP 和 HTTPS 证书，更适合内网部署。

### Q2: 长连接稳定吗？断开怎么办？

**A:** 长连接是飞书官方推荐的事件订阅方式。监听服务内置自动重连机制，断开后会自动重新连接。

### Q3: 支持国际版 Lark 吗？

**A:** 支持！在配置文件中设置 `"region": "lark"` 即可。

### Q4: 如何获取 folder_token 创建文档？

**A:** 
1. 在飞书云空间创建一个文件夹
2. 打开文件夹，复制 URL 中 `folder/` 后面的部分
3. 即为 folder_token

---

## 📚 参考文档

- [飞书开放平台](https://open.feishu.cn/)
- [事件订阅指南](https://open.feishu.cn/document/ukTMukTMukTM/uUTNz4SN1MjL1UzM)
- [持久连接文档](https://open.feishu.cn/document/ukTMukTMukTM/uETO1YjLxkTN24SM5UjN)
- [消息 API](https://open.feishu.cn/document/uAjLw4CM/ukTMukTMukTM/reference/im-v1/message/create)
- [Node.js SDK](https://github.com/larksuite/node-sdk)

---

## 📄 许可证

MIT License

---

## 🙏 致谢

感谢飞书开放平台提供的强大 API，让集成变得如此简单！

---

**最后更新**: 2026-03-22  
**版本**: v1.0.2  
**作者**: OpenClaw 社区贡献者
