#!/usr/bin/env node
/**
 * 飞书工具库测试脚本
 */

const {LarkAuth, LarkChat, LarkMessage} = require('./lib');
const config = require('./.lark-config.json');

async function test() {
  console.log('🧪 飞书工具库功能测试\n');
  console.log('=' .repeat(50));
  
  // 1. 测试配置
  console.log('\n📋 1. 配置信息');
  console.log('   App ID:', config.app_id);
  console.log('   Region:', config.region);
  console.log('   ✅ 配置文件正常');
  
  // 2. 测试认证
  console.log('\n🔐 2. 认证测试');
  const auth = new LarkAuth(config.app_id, config.app_secret, {region: config.region});
  try {
    const token = await auth.getTenantAccessToken();
    console.log('   ✅ Token 获取成功');
    console.log('   Token:', token.substring(0, 30) + '...');
    console.log('   API Base:', auth.getApiBase());
  } catch (e) {
    console.log('   ❌ Token 获取失败:', e.message);
    return;
  }
  
  // 3. 测试获取群聊列表
  console.log('\n💬 3. 群聊列表测试');
  const chat = new LarkChat(auth);
  let chats = [];
  try {
    chats = await chat.list();
    console.log('   ✅ 获取成功');
    console.log('   群聊数量:', chats.length);
    if (chats.length > 0) {
      chats.forEach((c, i) => {
        console.log(`   ${i + 1}. ${c.name || '(无名称)'} | ID: ${c.chat_id}`);
      });
    }
  } catch (e) {
    console.log('   ❌ 获取失败:', e.message);
  }
  
  // 4. 测试查找群聊
  console.log('\n🔍 4. 查找群聊测试');
  if (chats.length > 0) {
    try {
      const target = await chat.findByName(chats[0].name || '');
      if (target) {
        console.log('   ✅ 查找成功');
        console.log('   群聊:', target.name);
        console.log('   ID:', target.chat_id);
      } else {
        console.log('   ❌ 未找到群聊');
      }
    } catch (e) {
      console.log('   ❌ 查找失败:', e.message);
    }
  } else {
    console.log('   ⏭️  跳过（无群聊）');
  }
  
  console.log('\n' + '='.repeat(50));
  console.log('✅ 测试完成\n');
}

test().catch(console.error);
