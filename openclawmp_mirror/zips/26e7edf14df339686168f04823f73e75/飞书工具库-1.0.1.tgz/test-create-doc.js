#!/usr/bin/env node
/**
 * 测试创建飞书文档
 */

const https = require('https');
const config = require('./.lark-config.json');

async function createDoc() {
  const apiBase = config.region === 'feishu' ? 'open.feishu.cn' : 'open.larksuite.com';
  
  console.log('📝 测试创建飞书文档\n');
  console.log('=' .repeat(50));
  
  // 1. 获取 Token
  console.log('\n1️⃣ 获取 Token...');
  const tokenRes = await new Promise((resolve, reject) => {
    const req = https.request({
      hostname: apiBase,
      path: '/open-apis/auth/v3/tenant_access_token/internal',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    req.on('error', reject);
    req.write(JSON.stringify({ app_id: config.app_id, app_secret: config.app_secret }));
    req.end();
  });
  
  if (tokenRes.code !== 0) {
    console.log('❌ Token 获取失败:', tokenRes.msg);
    return;
  }
  
  const token = tokenRes.tenant_access_token;
  console.log('✅ Token 获取成功');
  console.log('   Token:', token.substring(0, 30) + '...');
  
  // 2. 获取根目录元数据
  console.log('\n2️⃣ 获取根目录元数据...');
  const rootMeta = await new Promise((resolve, reject) => {
    const req = https.request({
      hostname: apiBase,
      path: '/open-apis/drive/explorer/v2/root_folder/meta',
      method: 'GET',
      headers: {
        'Authorization': 'Bearer ' + token
      }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    req.on('error', reject);
    req.end();
  });
  
  if (rootMeta.code !== 0) {
    console.log('❌ 获取根目录失败:', rootMeta.msg);
    return;
  }
  
  console.log('✅ 根目录信息:');
  console.log('   Token:', rootMeta.data.token);
  console.log('   ID:', rootMeta.data.id);
  console.log('   所有者:', rootMeta.data.owner_id);
  
  const folderToken = rootMeta.data.token;
  
  // 3. 创建文档
  console.log('\n3️⃣ 创建文档...');
  const createRes = await new Promise((resolve, reject) => {
    const content = JSON.stringify({
      title: '你的机器人的测试文档',
      folder_token: folderToken
    });
    
    const req = https.request({
      hostname: apiBase,
      path: '/open-apis/docx/v1/documents',
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(content)
      }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    req.on('error', reject);
    req.write(content);
    req.end();
  });
  
  console.log('   创建响应:', JSON.stringify(createRes, null, 2).substring(0, 300));
  
  if (createRes.code !== 0 && createRes.code !== undefined) {
    console.log('❌ 创建失败:', createRes.msg);
    return;
  }
  
  // 飞书 API 返回格式可能是 data.document 或 data
  const doc = createRes.data?.document || createRes.data || createRes;
  const docId = doc.document_id || doc.id || doc.token;
  
  if (!docId) {
    console.log('⚠️  文档创建响应格式未知，可能已创建');
    return;
  }
  
  console.log('✅ 文档创建成功');
  console.log('   文档 ID:', docId);
  console.log('   标题:', doc.title || '未知');
  console.log('   URL: https://open.feishu.cn/docx/' + docId);
  
  // 4. 写入内容
  console.log('\n4️⃣ 写入内容...');
  const blockContent = JSON.stringify({
    parent_id: docId,
    block_type: 1,
    fields: {
      text_field: {
        elements: [{
          text_run: { content: '这是测试内容，你好世界！\n' }
        }]
      }
    }
  });
  
  const blockRes = await new Promise((resolve, reject) => {
    const req = https.request({
      hostname: apiBase,
      path: '/open-apis/docx/v1/blocks',
      method: 'POST',
      headers: {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(blockContent)
      }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    req.on('error', reject);
    req.write(blockContent);
    req.end();
  });
  
  console.log('   写入响应:', JSON.stringify(blockRes, null, 2).substring(0, 300));
  
  if (blockRes.code !== 0 && blockRes.code !== undefined) {
    console.log('⚠️  写入内容失败:', blockRes.msg);
  } else {
    console.log('✅ 内容写入成功');
  }
  
  console.log('\n' + '='.repeat(50));
  console.log('✅ 测试完成\n');
}

createDoc().catch(e => console.error('❌ 错误:', e.message));
