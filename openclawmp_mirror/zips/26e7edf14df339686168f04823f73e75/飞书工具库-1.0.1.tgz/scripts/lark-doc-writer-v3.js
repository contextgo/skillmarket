#!/usr/bin/env node

/**
 * Lark Document Writer V3
 * 使用正确的 block_type: 31 创建表格
 * 
 * 使用方法：
 * node scripts/lark-doc-writer-v3.js <markdown_file> <doc_title>
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const APP_ID = process.env.FEISHU_APP_ID || '';
const APP_SECRET = process.env.FEISHU_APP_SECRET || '';
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  const postData = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  console.log('🔑 获取访问令牌...');
  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`获取 token 失败: ${response.msg}`);
  console.log('✅ 访问令牌获取成功');
  return response.tenant_access_token;
}

async function createDocument(token, title) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents`);
  const postData = JSON.stringify({ title: title });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  console.log('📄 创建文档...');
  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`创建文档失败: ${response.msg}`);
  console.log(`✅ 文档创建成功: ${response.data.document.document_id}`);
  return response.data.document;
}

async function createBlock(token, documentId, parentId, block) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${documentId}/blocks/${parentId}/children`);
  const postData = JSON.stringify({ children: [block], index: -1 });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  const response = await httpsRequest(options, postData);
  if (response.code !== 0) {
    throw new Error(`创建块失败: ${response.msg || JSON.stringify(response)}`);
  }
  return response.data.children[0];
}

async function getBlockChildren(token, documentId, blockId) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${documentId}/blocks/${blockId}/children`);
  const options = {
    hostname: url.hostname,
    path: url.pathname + '?page_size=500',
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  };
  
  const response = await httpsRequest(options);
  if (response.code !== 0) throw new Error(`获取子块失败: ${response.msg}`);
  return response.data.items || [];
}

async function patchBlock(token, documentId, blockId, updates) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${documentId}/blocks/${blockId}`);
  const postData = JSON.stringify(updates);
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'PATCH',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  const response = await httpsRequest(options, postData);
  if (response.code !== 0) {
    throw new Error(`更新块失败: ${response.msg || JSON.stringify(response)}`);
  }
  return response.data;
}

async function insertTableRows(token, documentId, tableBlockId, rowIndex, count) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${documentId}/blocks/${tableBlockId}`);
  const postData = JSON.stringify({
    insert_table_row: {
      row_index: rowIndex,
      size: count
    }
  });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'PATCH',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  const response = await httpsRequest(options, postData);
  if (response.code !== 0) {
    throw new Error(`插入行失败: ${response.msg || JSON.stringify(response)}`);
  }
  return response.data;
}

/**
 * 创建表格（支持大表格通过插入行）
 */
async function createTable(token, documentId, parentId, tableData) {
  const MAX_ROWS = 9; // Lark API 单次创建最大行数限制
  const rowCount = tableData.length;
  const colCount = tableData[0].length;
  
  // 如果表格超过最大行数，使用插入行方式
  if (rowCount > MAX_ROWS) {
    console.log(`   ⚠️  表格过大 (${rowCount}行)，使用插入行方式...`);
    await createLargeTableWithPatch(token, documentId, parentId, tableData);
    return;
  }
  
  // 正常大小的表格，直接创建
  await createSingleTable(token, documentId, parentId, tableData);
}

/**
 * 创建大表格（通过插入行）
 */
async function createLargeTableWithPatch(token, documentId, parentId, tableData) {
  const MAX_ROWS = 9;
  const rowCount = tableData.length;
  const colCount = tableData[0].length;
  
  // 步骤1: 先创建一个基础表格（最大行数）
  const initialRows = MAX_ROWS;
  
  console.log(`   步骤1: 创建基础表格 ${initialRows}x${colCount}...`);
  const tableBlock = {
    block_type: 31,
    table: {
      property: {
        row_size: initialRows,
        column_size: colCount
      }
    }
  };
  
  await new Promise(resolve => setTimeout(resolve, 500));
  const createdTable = await createBlock(token, documentId, parentId, tableBlock);
  console.log(`   ✅ 基础表格创建成功: ${createdTable.block_id}`);
  
  // 步骤2: 逐行插入剩余行
  const remainingRows = rowCount - initialRows;
  if (remainingRows > 0) {
    console.log(`   步骤2: 逐行插入剩余 ${remainingRows} 行...`);
    for (let i = 0; i < remainingRows; i++) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      await insertTableRows(token, documentId, createdTable.block_id, initialRows + i, 1);
      console.log(`   插入第 ${i + 1}/${remainingRows} 行`);
    }
    console.log(`   ✅ 所有行插入成功`);
  }
  
  // 步骤3: 等待并验证单元格生成
  console.log(`   步骤3: 等待单元格生成...`);
  const expectedCells = rowCount * colCount;
  let actualCells = 0;
  let retries = 0;
  const maxRetries = 5;
  
  while (actualCells < expectedCells && retries < maxRetries) {
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const rows = await getBlockChildren(token, documentId, createdTable.block_id);
    const cells = [];
    for (const row of rows) {
      await new Promise(resolve => setTimeout(resolve, 200));
      const rowCells = await getBlockChildren(token, documentId, row.block_id);
      cells.push(...rowCells);
    }
    
    actualCells = cells.length;
    retries++;
    console.log(`   尝试 ${retries}/${maxRetries}: 获取到 ${actualCells}/${expectedCells} 个单元格`);
  }
  
  if (actualCells < expectedCells) {
    console.log(`   ⚠️  单元格数量不足，继续填充已有单元格`);
  } else {
    console.log(`   ✅ 单元格生成完成`);
  }
  
  // 步骤4: 填充所有内容
  console.log(`   步骤4: 填充表格内容...`);
  await fillTableContent(token, documentId, createdTable.block_id, tableData);
  
  console.log(`   ✅ 大表格创建完成`);
}

/**
 * 创建单个表格
 */
async function createSingleTable(token, documentId, parentId, tableData) {
  const rowCount = tableData.length;
  const colCount = tableData[0].length;
  
  console.log(`   步骤1: 创建 ${rowCount}x${colCount} 空表格...`);
  
  // 创建空表格
  const tableBlock = {
    block_type: 31,
    table: {
      property: {
        row_size: rowCount,
        column_size: colCount
      }
    }
  };
  
  await new Promise(resolve => setTimeout(resolve, 500));
  const createdTable = await createBlock(token, documentId, parentId, tableBlock);
  console.log(`   ✅ 表格块创建成功: ${createdTable.block_id}`);
  
  // 填充表格内容
  console.log(`   步骤2: 填充表格内容...`);
  await fillTableContent(token, documentId, createdTable.block_id, tableData);
  
  return createdTable;
}

/**
 * 填充表格内容
 */
async function fillTableContent(token, documentId, tableBlockId, tableData) {
  const rowCount = tableData.length;
  const colCount = tableData[0].length;
  
  // 获取所有单元格
  await new Promise(resolve => setTimeout(resolve, 500));
  const rows = await getBlockChildren(token, documentId, tableBlockId);
  
  console.log(`   获取到 ${rows.length} 行（期望 ${rowCount} 行）`);
  
  const cells = [];
  for (const row of rows) {
    await new Promise(resolve => setTimeout(resolve, 300));
    const rowCells = await getBlockChildren(token, documentId, row.block_id);
    cells.push(...rowCells);
  }
  
  console.log(`   获取到 ${cells.length} 个单元格（期望 ${rowCount * colCount} 个）`);
  
  // 填充单元格内容
  for (let i = 0; i < cells.length && i < rowCount * colCount; i++) {
    const row = Math.floor(i / colCount);
    const col = i % colCount;
    const content = tableData[row][col];
    
    if (content && content.trim()) {
      const textBlock = {
        block_type: 2,
        text: {
          elements: [{
            text_run: {
              content: content
            }
          }]
        }
      };
      
      await new Promise(resolve => setTimeout(resolve, 300));
      await createBlock(token, documentId, cells[i].block_id, textBlock);
    }
  }
  
  console.log(`   ✅ 内容填充完成`);
}

/**
 * 解析 Markdown
 */
function parseMarkdown(markdown) {
  const lines = markdown.split('\n');
  const items = [];
  let currentTable = null;
  
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    
    // 跳过空行和图片
    if (!line.trim() || (line.includes('![') && line.includes('](image_placeholder)'))) {
      continue;
    }
    
    // 表格处理
    if (line.startsWith('|') && line.endsWith('|')) {
      const cells = line.split('|').slice(1, -1).map(c => c.trim());
      
      // 跳过分隔行
      if (cells.every(c => /^-+$/.test(c))) {
        continue;
      }
      
      if (!currentTable) {
        currentTable = {
          type: 'table',
          data: []
        };
      }
      
      currentTable.data.push(cells);
      continue;
    } else if (currentTable) {
      items.push(currentTable);
      currentTable = null;
    }
    
    // 标题
    if (line.startsWith('# ')) {
      items.push({ type: 'heading1', content: line.substring(2).trim() });
    } else if (line.startsWith('## ')) {
      items.push({ type: 'heading2', content: line.substring(3).trim() });
    } else if (line.startsWith('### ')) {
      items.push({ type: 'heading3', content: line.substring(4).trim() });
    } else if (line.startsWith('#### ')) {
      items.push({ type: 'heading4', content: line.substring(5).trim() });
    }
    // 分隔线
    else if (line.trim() === '---') {
      items.push({ type: 'divider' });
    }
    // 列表
    else if (line.startsWith('- ')) {
      items.push({ type: 'bullet', content: line.substring(2).trim() });
    } else if (/^\d+\. /.test(line)) {
      items.push({ type: 'ordered', content: line.replace(/^\d+\. /, '').trim() });
    }
    // 普通文本
    else if (line.trim()) {
      items.push({ type: 'text', content: line.trim() });
    }
  }
  
  // 处理未闭合的表格
  if (currentTable) {
    items.push(currentTable);
  }
  
  return items;
}

/**
 * 创建文档内容
 */
async function createDocumentContent(token, documentId, items) {
  let createdCount = 0;
  let tableCount = 0;
  
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    
    console.log(`📝 写入内容 (${i + 1}/${items.length}): ${item.type}...`);
    
    try {
      if (item.type === 'table') {
        console.log(`   表格大小: ${item.data.length}x${item.data[0].length}`);
        await createTable(token, documentId, documentId, item.data);
        tableCount++;
        createdCount++;
      } else {
        const block = convertItemToBlock(item);
        if (block) {
          await new Promise(resolve => setTimeout(resolve, 400)); // 增加延迟避免频率限制
          await createBlock(token, documentId, documentId, block);
          createdCount++;
        }
      }
    } catch (error) {
      console.warn(`   ⚠️  失败: ${error.message}`);
    }
  }
  
  console.log(`✅ 内容写入完成: ${createdCount}/${items.length} 个块（包含 ${tableCount} 个表格）`);
}

function convertItemToBlock(item) {
  switch (item.type) {
    case 'heading1':
      return { block_type: 3, heading1: { elements: [{ text_run: { content: item.content } }] } };
    case 'heading2':
      return { block_type: 4, heading2: { elements: [{ text_run: { content: item.content } }] } };
    case 'heading3':
      return { block_type: 5, heading3: { elements: [{ text_run: { content: item.content } }] } };
    case 'heading4':
      return { block_type: 6, heading4: { elements: [{ text_run: { content: item.content } }] } };
    case 'text':
      return { block_type: 2, text: { elements: [{ text_run: { content: item.content } }] } };
    case 'bullet':
      // bullet 格式有问题，暂时转换为普通文本
      return { 
        block_type: 2, 
        text: { 
          elements: [{ text_run: { content: '• ' + item.content } }] 
        } 
      };
    case 'ordered':
      return { 
        block_type: 10, 
        ordered: { 
          elements: [{ text_run: { content: item.content } }] 
        } 
      };
    case 'divider':
      // 分割线不支持通过 API 创建，跳过
      return null;
    default:
      return null;
  }
}

async function main() {
  try {
    const args = process.argv.slice(2);
    
    if (args.length < 2) {
      console.log('使用方法: node lark-doc-writer-v3.js <markdown_file> <doc_title>');
      console.log('示例: node lark-doc-writer-v3.js report.md "2月214情人节CP活动业务分析"');
      process.exit(1);
    }
    
    const markdownFile = args[0];
    const docTitle = args[1];
    
    const markdownPath = path.resolve(markdownFile);
    if (!fs.existsSync(markdownPath)) {
      throw new Error(`文件不存在: ${markdownPath}`);
    }
    
    const markdown = fs.readFileSync(markdownPath, 'utf-8');
    
    console.log('🚀 开始创建 Lark 文档...');
    console.log(`📎 文件: ${markdownFile}`);
    console.log(`📋 标题: ${docTitle}\n`);
    
    // 1. 获取访问令牌
    const token = await getTenantAccessToken();
    
    // 2. 创建文档
    const document = await createDocument(token, docTitle);
    
    // 3. 解析 Markdown
    console.log('\n🔄 解析 Markdown 内容...');
    const items = parseMarkdown(markdown);
    const tableCount = items.filter(i => i.type === 'table').length;
    console.log(`✅ 解析完成: ${items.length} 个块（包含 ${tableCount} 个表格）\n`);
    
    // 4. 创建内容
    await createDocumentContent(token, document.document_id, items);
    
    // 5. 生成文档链接
    const docUrl = `https://your-domain.larksuite.com/docx/${document.document_id}`;
    
    console.log('\n✨ 完成！');
    console.log(`📄 文档链接: ${docUrl}`);
    
  } catch (error) {
    console.error('\n❌ 错误:', error.message);
    process.exit(1);
  }
}

if (require.main === module) {
  main();
}
