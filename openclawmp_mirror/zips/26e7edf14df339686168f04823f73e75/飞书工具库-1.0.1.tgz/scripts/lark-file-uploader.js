#!/usr/bin/env node

/**
 * Lark File Uploader
 * 上传文件到飞书云空间并添加到文档
 *
 * 使用方法：
 * node scripts/lark-file-uploader.js <file_path> <document_id>
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

// 从配置文件读取
const configPath = path.join(__dirname, '../.lark-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const APP_ID = config.app_id;
const APP_SECRET = config.app_secret;
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  const postData = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log('🔑 获取访问令牌...');
  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`获取 token 失败: ${response.msg}`);
  console.log('✅ 访问令牌获取成功');
  return response.tenant_access_token;
}

// 上传文件到飞书云空间
async function uploadFile(token, filePath) {
  const FormData = require('form-data');
  const form = new FormData();

  const fileName = path.basename(filePath);
  const fileStats = fs.statSync(filePath);
  const fileStream = fs.createReadStream(filePath);

  form.append('file_name', fileName);
  form.append('parent_type', 'explorer');
  // 不指定 parent_node，使用默认位置
  form.append('size', fileStats.size.toString());
  form.append('file', fileStream);

  console.log(`📤 上传文件: ${fileName} (${fileStats.size} 字节)...`);

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'open.larksuite.com',
      path: '/open-apis/drive/v1/files/upload_all',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        ...form.getHeaders()
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const response = JSON.parse(data);
          if (response.code !== 0) {
            reject(new Error(`上传失败: ${response.msg}`));
          } else {
            console.log('✅ 文件上传成功');
            resolve(response.data);
          }
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('error', reject);
    form.pipe(req);
  });
}

// 在文档中添加文件块
async function addFileToDocument(token, documentId, fileToken, fileName) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${documentId}/blocks/${documentId}/children`);

  const block = {
    block_type: 28, // 尝试文件块类型 28
    file: {
      token: fileToken
    }
  };

  const postData = JSON.stringify({
    children: [block],
    index: -1
  });

  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log('📎 添加文件到文档...');
  console.log('请求数据:', postData);
  const response = await httpsRequest(options, postData);
  console.log('响应:', JSON.stringify(response, null, 2));
  if (response.code !== 0) {
    throw new Error(`添加文件失败: ${response.msg || JSON.stringify(response)}`);
  }
  console.log('✅ 文件已添加到文档');
  return response.data;
}

async function main() {
  try {
    const args = process.argv.slice(2);
    if (args.length < 2) {
      console.error('用法: node lark-file-uploader.js <file_path> <document_id>');
      process.exit(1);
    }

    const filePath = args[0];
    const documentId = args[1];

    if (!fs.existsSync(filePath)) {
      throw new Error(`文件不存在: ${filePath}`);
    }

    console.log('🚀 开始上传文件到飞书文档...');
    console.log(`📄 文档 ID: ${documentId}`);

    // 1. 获取 token
    const token = await getTenantAccessToken();

    // 2. 上传文件
    const uploadResult = await uploadFile(token, filePath);
    const fileToken = uploadResult.file_token;
    const fileName = path.basename(filePath);

    console.log(`📦 文件 Token: ${fileToken}`);

    // 3. 添加到文档
    await addFileToDocument(token, documentId, fileToken, fileName);

    console.log('\n✨ 完成！');
    console.log(`📄 文档链接: https://your-domain.larksuite.com/docx/${documentId}`);

  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
