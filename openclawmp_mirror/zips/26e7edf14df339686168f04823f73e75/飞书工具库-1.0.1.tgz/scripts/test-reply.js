#!/usr/bin/env node

/**
 * 测试飞书消息回复 API
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../.lark-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const APP_ID = config.app_id;
const APP_SECRET = config.app_secret;
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  const postData = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`获取 token 失败: ${response.msg}`);
  return response.tenant_access_token;
}

// 方法1: 使用 reply 接口
async function replyMessage(token, messageId, content, msgType = 'text') {
  const url = new URL(`${LARK_API_BASE}/im/v1/messages/${messageId}/reply`);

  const postData = JSON.stringify({
    msg_type: msgType,
    content: content,
    reply_in_thread: false  // false 表示直接回复，true 表示在话题中回复
  });

  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log('📨 使用 reply 接口回复消息...');
  console.log('请求:', postData);
  const response = await httpsRequest(options, postData);
  console.log('响应:', JSON.stringify(response, null, 2));

  return response;
}

async function main() {
  try {
    const token = await getTenantAccessToken();

    // 测试回复一条文本消息
    const testMessageId = process.argv[2];
    if (!testMessageId) {
      console.error('用法: node test-reply.js <message_id>');
      process.exit(1);
    }

    await replyMessage(token, testMessageId, JSON.stringify({ text: '测试回复' }), 'text');

  } catch (error) {
    console.error('❌ 错误:', error.message);
  }
}

main();
