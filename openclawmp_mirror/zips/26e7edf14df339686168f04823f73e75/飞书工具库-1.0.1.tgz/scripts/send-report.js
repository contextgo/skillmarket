#!/usr/bin/env node

/**
 * 发送项目简报到群聊
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../.lark-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const APP_ID = config.app_id;
const APP_SECRET = config.app_secret;
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  const postData = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`获取 token 失败: ${response.msg}`);
  return response.tenant_access_token;
}

async function uploadFileForMessage(token, filePath) {
  const FormData = require('form-data');
  const form = new FormData();

  const fileName = path.basename(filePath);
  const fileStream = fs.createReadStream(filePath);

  form.append('file_type', 'stream');
  form.append('file_name', fileName);
  form.append('file', fileStream);

  console.log(`📤 上传文件: ${fileName}...`);

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'open.larksuite.com',
      path: '/open-apis/im/v1/files',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        ...form.getHeaders()
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const response = JSON.parse(data);
          if (response.code !== 0) {
            reject(new Error(`上传失败: ${response.msg}`));
          } else {
            console.log('✅ 文件上传成功');
            resolve(response.data);
          }
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('error', reject);
    form.pipe(req);
  });
}

async function sendRichText(token, chatId, content) {
  const url = new URL(`${LARK_API_BASE}/im/v1/messages`);
  url.searchParams.append('receive_id_type', 'chat_id');

  const postData = JSON.stringify({
    receive_id: chatId,
    msg_type: 'post',
    content: JSON.stringify(content)
  });

  const options = {
    hostname: url.hostname,
    path: url.pathname + url.search,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log('📨 发送简报消息...');
  const response = await httpsRequest(options, postData);

  if (response.code !== 0) {
    throw new Error(`发送消息失败: ${response.msg}`);
  }

  console.log('✅ 简报已发送');
  return response.data;
}

async function replyFileMessage(token, messageId, fileKey) {
  const url = new URL(`${LARK_API_BASE}/im/v1/messages/${messageId}/reply`);

  const postData = JSON.stringify({
    msg_type: 'file',
    content: JSON.stringify({
      file_key: fileKey
    }),
    reply_in_thread: false  // false 表示直接回复
  });

  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log('📦 使用 reply 接口回复文件...');
  const response = await httpsRequest(options, postData);

  if (response.code !== 0) {
    console.log('响应:', JSON.stringify(response, null, 2));
    throw new Error(`回复文件失败: ${response.msg}`);
  }

  console.log('✅ 文件已回复');
  return response.data;
}

async function sendFileMessage(token, chatId, fileKey, replyMessageId = null) {
  const url = new URL(`${LARK_API_BASE}/im/v1/messages`);
  url.searchParams.append('receive_id_type', 'chat_id');

  const payload = {
    receive_id: chatId,
    msg_type: 'file',
    content: JSON.stringify({
      file_key: fileKey
    })
  };

  // 如果提供了 replyMessageId，则作为回复发送
  if (replyMessageId) {
    payload.reply_in_thread = true;
    payload.root_id = replyMessageId;
  }

  const postData = JSON.stringify(payload);

  const options = {
    hostname: url.hostname,
    path: url.pathname + url.search,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log(replyMessageId ? '📦 回复文件...' : '📦 发送文件...');
  const response = await httpsRequest(options, postData);

  if (response.code !== 0) {
    throw new Error(`发送文件失败: ${response.msg}`);
  }

  console.log('✅ 文件已发送');
  return response.data;
}

async function main() {
  try {
    const chatId = 'oc_your_chat_id_here'; // AI分享群
    const docUrl = 'https://your-domain.larksuite.com/docx/H8x2dj2zao6rtfxyOt3lYuifgph';
    const filePath = '/path/to/your/feishu-doc-helper.zip';

    console.log('🚀 开始发送项目简报...\n');

    const token = await getTenantAccessToken();

    // 先上传文件
    const uploadResult = await uploadFileForMessage(token, filePath);
    const fileKey = uploadResult.file_key;

    // 构建优化后的富文本消息
    const content = {
      zh_cn: {
        title: '🚀 AI 自动参考历史文档，生成新文档',
        content: [
          [
            {
              tag: 'text',
              text: '💡 解决什么问题？\n',
              style: ['bold']
            }
          ],
          [
            {
              tag: 'text',
              text: '每次写需求文档/分析文档要手动查找格式和业务逻辑'
            }
          ],
          [
            {
              tag: 'text',
              text: '\n\n📦 快速开始\n',
              style: ['bold']
            }
          ],
          [
            {
              tag: 'text',
              text: '1. 下载压缩包（见下方回复）\n2. 解压并配置 token\n3. 启动 Claude Code\n4. 开始使用'
            }
          ],
          [
            {
              tag: 'text',
              text: '\n\n更多见'
            },
            {
              tag: 'a',
              text: '【完整文档】',
              href: docUrl
            }
          ]
        ]
      }
    };

    const messageResult = await sendRichText(token, chatId, content);
    const messageId = messageResult.message_id;

    console.log(`\n📝 消息 ID: ${messageId}`);
    console.log('现在使用 reply 接口回复文件...\n');

    // 使用 reply 接口回复文件
    await replyFileMessage(token, messageId, fileKey);

    console.log('\n✨ 完成！简报和文件已发送（文件在话题回复中）');

  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
