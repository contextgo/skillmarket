#!/usr/bin/env node

/**
 * Lark Document Reader
 * 用于读取 Lark (飞书国际版) 文档内容并保存为 Markdown
 * 
 * 使用方法：
 * node scripts/lark-doc-reader.js <doc_url> [output_file]
 * 
 * 示例：
 * node scripts/lark-doc-reader.js https://your-domain.larksuite.com/wiki/Ezs2w1a6qiSo2HkFXnHlwxnsg5g
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

// Lark 应用凭证
const APP_ID = process.env.FEISHU_APP_ID || '';
const APP_SECRET = process.env.FEISHU_APP_SECRET || '';

// Lark API 基础 URL (国际版)
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

/**
 * 发起 HTTPS 请求
 */
function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      
      res.on('data', (chunk) => {
        data += chunk;
      });
      
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    
    req.on('error', reject);
    
    if (postData) {
      req.write(postData);
    }
    
    req.end();
  });
}

/**
 * 获取 tenant_access_token
 */
async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  
  const postData = JSON.stringify({
    app_id: APP_ID,
    app_secret: APP_SECRET
  });
  
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  console.log('🔑 获取访问令牌...');
  const response = await httpsRequest(options, postData);
  
  if (response.code !== 0) {
    throw new Error(`获取 token 失败: ${response.msg}`);
  }
  
  console.log('✅ 访问令牌获取成功');
  return response.tenant_access_token;
}

/**
 * 从 URL 中提取文档 ID
 */
function extractDocId(url) {
  // 支持多种 URL 格式
  // https://your-domain.larksuite.com/wiki/Ezs2w1a6qiSo2HkFXnHlwxnsg5g
  // https://your-domain.larksuite.com/docx/doxcnXXXXXXXXXXXXXXXXXXXXXX
  
  const patterns = [
    /\/wiki\/([a-zA-Z0-9]+)/,
    /\/docx\/([a-zA-Z0-9]+)/,
    /\/doc\/([a-zA-Z0-9]+)/,
    /\/sheet\/([a-zA-Z0-9]+)/
  ];
  
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) {
      return match[1];
    }
  }
  
  throw new Error('无法从 URL 中提取文档 ID');
}

/**
 * 获取文档类型
 */
function getDocType(url) {
  if (url.includes('/wiki/')) return 'wiki';
  if (url.includes('/docx/')) return 'docx';
  if (url.includes('/doc/')) return 'doc';
  if (url.includes('/sheet/')) return 'sheet';
  return 'wiki'; // 默认
}

/**
 * 获取 Wiki 文档内容
 */
async function getWikiContent(token, docId) {
  // 尝试直接作为 docx 文档读取
  console.log('📄 尝试读取文档内容...');
  
  try {
    // 方法1: 尝试作为 docx 读取
    return await getDocxContent(token, docId);
  } catch (e1) {
    console.log('⚠️  Docx 方式失败，尝试其他方法...');
    
    try {
      // 方法2: 尝试使用 wiki API
      const url = new URL(`${LARK_API_BASE}/wiki/v2/spaces/get_node`);
      url.searchParams.append('token', docId);
      
      const options = {
        hostname: url.hostname,
        path: url.pathname + url.search,
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      };
      
      const response = await httpsRequest(options);
      
      if (response.code !== 0) {
        throw new Error(`获取文档失败: ${response.msg}`);
      }
      
      const nodeToken = response.data.node.obj_token;
      return await getDocxContent(token, nodeToken);
    } catch (e2) {
      console.log('⚠️  Wiki API 失败，尝试导出方式...');
      
      // 方法3: 尝试导出文档
      return await exportDocument(token, docId);
    }
  }
}

/**
 * 获取 Docx 文档内容（结构化格式）
 */
async function getDocxContent(token, docId) {
  // 先尝试获取结构化内容
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${docId}/blocks`);
  
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  };
  
  console.log('📥 下载文档结构化内容...');
  const response = await httpsRequest(options);
  
  if (response.code !== 0) {
    console.log('⚠️  结构化内容获取失败，尝试原始内容...');
    return await getDocxRawContent(token, docId);
  }
  
  return response.data;
}

/**
 * 获取 Docx 原始内容
 */
async function getDocxRawContent(token, docId) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${docId}/raw_content`);
  
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  };
  
  console.log('📥 下载文档原始内容...');
  const response = await httpsRequest(options);
  
  if (response.code !== 0) {
    throw new Error(`获取文档内容失败: ${response.msg}`);
  }
  
  return response.data.content;
}

/**
 * 导出文档
 */
async function exportDocument(token, docId) {
  const url = new URL(`${LARK_API_BASE}/drive/v1/export_tasks`);
  
  const postData = JSON.stringify({
    file_extension: 'md',
    token: docId,
    type: 'docx'
  });
  
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  console.log('📤 请求导出文档...');
  const response = await httpsRequest(options, postData);
  
  if (response.code !== 0) {
    throw new Error(`导出文档失败: ${response.msg}`);
  }
  
  // 获取导出的文件
  const ticket = response.data.ticket;
  return await getExportedFile(token, ticket);
}

/**
 * 获取导出的文件
 */
async function getExportedFile(token, ticket) {
  // 等待导出完成
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  const url = new URL(`${LARK_API_BASE}/drive/v1/export_tasks/${ticket}`);
  
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  };
  
  console.log('📥 获取导出文件...');
  const response = await httpsRequest(options);
  
  if (response.code !== 0) {
    throw new Error(`获取导出文件失败: ${response.msg}`);
  }
  
  // 下载文件内容
  const fileUrl = response.data.result.file_token;
  return await downloadFile(token, fileUrl);
}

/**
 * 下载文件
 */
async function downloadFile(token, fileToken) {
  const url = new URL(`${LARK_API_BASE}/drive/v1/medias/${fileToken}/download`);
  
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`
    }
  };
  
  console.log('⬇️  下载文件内容...');
  return await httpsRequest(options);
}

/**
 * 将文档内容转换为 Markdown
 */
function convertToMarkdown(content) {
  // 如果是字符串，直接返回
  if (typeof content === 'string') {
    return content;
  }
  
  // 如果是结构化数据，需要解析
  if (content && content.items) {
    return parseBlocks(content.items);
  }
  
  // 其他情况，返回 JSON
  return JSON.stringify(content, null, 2);
}

/**
 * 解析 Lark 文档块
 */
function parseBlocks(blocks) {
  let markdown = '';
  
  for (const block of blocks) {
    const blockType = block.block_type;
    
    switch (blockType) {
      case 1: // 页面
        if (block.page && block.page.elements) {
          markdown += parseElements(block.page.elements);
        }
        break;
      case 2: // 文本
        if (block.text && block.text.elements) {
          markdown += parseTextElements(block.text.elements) + '\n\n';
        }
        break;
      case 3: // 标题1
        if (block.heading1 && block.heading1.elements) {
          markdown += '# ' + parseTextElements(block.heading1.elements) + '\n\n';
        }
        break;
      case 4: // 标题2
        if (block.heading2 && block.heading2.elements) {
          markdown += '## ' + parseTextElements(block.heading2.elements) + '\n\n';
        }
        break;
      case 5: // 标题3
        if (block.heading3 && block.heading3.elements) {
          markdown += '### ' + parseTextElements(block.heading3.elements) + '\n\n';
        }
        break;
      case 6: // 标题4
        if (block.heading4 && block.heading4.elements) {
          markdown += '#### ' + parseTextElements(block.heading4.elements) + '\n\n';
        }
        break;
      case 7: // 标题5
        if (block.heading5 && block.heading5.elements) {
          markdown += '##### ' + parseTextElements(block.heading5.elements) + '\n\n';
        }
        break;
      case 8: // 标题6
        if (block.heading6 && block.heading6.elements) {
          markdown += '###### ' + parseTextElements(block.heading6.elements) + '\n\n';
        }
        break;
      case 9: // 无序列表
        if (block.bullet && block.bullet.elements) {
          markdown += '- ' + parseTextElements(block.bullet.elements) + '\n';
        }
        break;
      case 10: // 有序列表
        if (block.ordered && block.ordered.elements) {
          markdown += '1. ' + parseTextElements(block.ordered.elements) + '\n';
        }
        break;
      case 11: // 代码块
        if (block.code && block.code.elements) {
          const lang = block.code.style?.language || '';
          markdown += '```' + lang + '\n' + parseTextElements(block.code.elements) + '\n```\n\n';
        }
        break;
      case 12: // 引用
        if (block.quote && block.quote.elements) {
          markdown += '> ' + parseTextElements(block.quote.elements) + '\n\n';
        }
        break;
      case 15: // 表格
        if (block.table) {
          markdown += parseTable(block.table) + '\n\n';
        }
        break;
      case 27: // 图片
        if (block.image) {
          const alt = block.image.alt || 'image';
          markdown += `![${alt}](${block.image.token})\n\n`;
        }
        break;
      case 31: // 分割线
        markdown += '---\n\n';
        break;
      default:
        // 未知类型，尝试提取文本
        if (block.text && block.text.elements) {
          markdown += parseTextElements(block.text.elements) + '\n\n';
        }
    }
    
    // 递归处理子块
    if (block.children && block.children.length > 0) {
      markdown += parseBlocks(block.children);
    }
  }
  
  return markdown;
}

/**
 * 解析文本元素
 */
function parseTextElements(elements) {
  let text = '';
  
  for (const element of elements) {
    const textRun = element.text_run;
    if (!textRun) continue;
    
    let content = textRun.content || '';
    const style = textRun.text_element_style || {};
    
    // 应用样式
    if (style.bold) content = `**${content}**`;
    if (style.italic) content = `*${content}*`;
    if (style.strikethrough) content = `~~${content}~~`;
    if (style.inline_code) content = `\`${content}\``;
    if (style.link) content = `[${content}](${style.link.url})`;
    
    text += content;
  }
  
  return text;
}

/**
 * 解析表格
 */
function parseTable(table) {
  if (!table.cells || table.cells.length === 0) {
    return '';
  }
  
  let markdown = '';
  const rows = [];
  
  // 按行组织单元格
  for (const cell of table.cells) {
    const rowIndex = cell.row_index || 0;
    if (!rows[rowIndex]) {
      rows[rowIndex] = [];
    }
    rows[rowIndex][cell.column_index || 0] = cell;
  }
  
  // 生成表格
  for (let i = 0; i < rows.length; i++) {
    const row = rows[i];
    const cells = [];
    
    for (const cell of row) {
      if (cell && cell.elements) {
        cells.push(parseTextElements(cell.elements));
      } else {
        cells.push('');
      }
    }
    
    markdown += '| ' + cells.join(' | ') + ' |\n';
    
    // 添加表头分隔符
    if (i === 0) {
      markdown += '| ' + cells.map(() => '---').join(' | ') + ' |\n';
    }
  }
  
  return markdown;
}

/**
 * 解析元素列表
 */
function parseElements(elements) {
  let markdown = '';
  
  for (const element of elements) {
    if (element.text_run) {
      markdown += element.text_run.content || '';
    }
  }
  
  return markdown;
}

/**
 * 主函数
 */
async function main() {
  try {
    // 解析命令行参数
    const args = process.argv.slice(2);
    
    if (args.length === 0) {
      console.log('使用方法: node lark-doc-reader.js <doc_url> [output_file]');
      console.log('示例: node lark-doc-reader.js https://your-domain.larksuite.com/wiki/Ezs2w1a6qiSo2HkFXnHlwxnsg5g');
      process.exit(1);
    }
    
    const docUrl = args[0];
    const outputFile = args[1] || null;
    
    console.log('🚀 开始读取 Lark 文档...');
    console.log(`📎 文档 URL: ${docUrl}`);
    
    // 1. 获取访问令牌
    const token = await getTenantAccessToken();
    
    // 2. 提取文档 ID
    const docId = extractDocId(docUrl);
    console.log(`📋 文档 ID: ${docId}`);
    
    // 3. 获取文档内容
    const docType = getDocType(docUrl);
    let content;
    
    if (docType === 'wiki') {
      content = await getWikiContent(token, docId);
    } else {
      content = await getDocxContent(token, docId);
    }
    
    // 4. 转换为 Markdown
    const markdown = convertToMarkdown(content);
    
    // 5. 保存或输出
    if (outputFile) {
      const outputPath = path.resolve(outputFile);
      fs.writeFileSync(outputPath, markdown, 'utf-8');
      console.log(`✅ 文档已保存到: ${outputPath}`);
    } else {
      console.log('\n📄 文档内容:\n');
      console.log('='.repeat(80));
      console.log(markdown);
      console.log('='.repeat(80));
    }
    
    console.log('\n✨ 完成！');
    
  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

// 运行主函数
if (require.main === module) {
  main();
}

module.exports = { 
  getTenantAccessToken, 
  extractDocId, 
  getWikiContent, 
  getDocxContent,
  getDocxRawContent,
  exportDocument,
  downloadFile,
  convertToMarkdown,
  parseBlocks,
  parseTable
};
