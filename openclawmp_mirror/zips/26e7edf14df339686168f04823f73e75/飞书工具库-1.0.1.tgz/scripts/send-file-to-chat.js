#!/usr/bin/env node

/**
 * 发送文件到群聊
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../.lark-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const APP_ID = config.app_id;
const APP_SECRET = config.app_secret;
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  const postData = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`获取 token 失败: ${response.msg}`);
  return response.tenant_access_token;
}

async function uploadFileForMessage(token, filePath) {
  const FormData = require('form-data');
  const form = new FormData();

  const fileName = path.basename(filePath);
  const fileStream = fs.createReadStream(filePath);

  form.append('file_type', 'stream');
  form.append('file_name', fileName);
  form.append('file', fileStream);

  console.log(`📤 上传文件用于消息发送: ${fileName}...`);

  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'open.larksuite.com',
      path: '/open-apis/im/v1/files',
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${token}`,
        ...form.getHeaders()
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          const response = JSON.parse(data);
          if (response.code !== 0) {
            reject(new Error(`上传失败: ${response.msg}`));
          } else {
            console.log('✅ 文件上传成功');
            resolve(response.data);
          }
        } catch (e) {
          reject(e);
        }
      });
    });

    req.on('error', reject);
    form.pipe(req);
  });
}

async function sendFileMessage(token, chatId, fileKey) {
  const url = new URL(`${LARK_API_BASE}/im/v1/messages`);
  url.searchParams.append('receive_id_type', 'chat_id');

  const postData = JSON.stringify({
    receive_id: chatId,
    msg_type: 'file',
    content: JSON.stringify({
      file_key: fileKey
    })
  });

  const options = {
    hostname: url.hostname,
    path: url.pathname + url.search,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  console.log('📨 发送文件消息到群聊...');
  const response = await httpsRequest(options, postData);

  if (response.code !== 0) {
    throw new Error(`发送消息失败: ${response.msg}`);
  }

  console.log('✅ 文件已发送到群聊');
  return response.data;
}

async function main() {
  try {
    const filePath = process.argv[2];
    const chatId = process.argv[3];

    if (!filePath || !chatId) {
      console.error('用法: node send-file-to-chat.js <file_path> <chat_id>');
      process.exit(1);
    }

    if (!fs.existsSync(filePath)) {
      throw new Error(`文件不存在: ${filePath}`);
    }

    console.log('🚀 开始发送文件到群聊...');
    console.log(`📁 文件: ${filePath}`);
    console.log(`💬 群聊 ID: ${chatId}\n`);

    // 1. 获取 token
    const token = await getTenantAccessToken();

    // 2. 上传文件
    const uploadResult = await uploadFileForMessage(token, filePath);
    const fileKey = uploadResult.file_key;

    console.log(`🔑 文件 Key: ${fileKey}\n`);

    // 3. 发送消息
    await sendFileMessage(token, chatId, fileKey);

    console.log('\n✨ 完成！');

  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
