#!/usr/bin/env node

/**
 * 列出机器人加入的所有群聊
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../.lark-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const APP_ID = config.app_id;
const APP_SECRET = config.app_secret;
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  const postData = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`获取 token 失败: ${response.msg}`);
  return response.tenant_access_token;
}

async function listChats(token) {
  const url = new URL(`${LARK_API_BASE}/im/v1/chats`);
  url.searchParams.append('page_size', '50');

  const options = {
    hostname: url.hostname,
    path: url.pathname + url.search,
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    }
  };

  console.log('📋 获取群聊列表...');
  const response = await httpsRequest(options);

  if (response.code !== 0) {
    throw new Error(`获取群聊列表失败: ${response.msg}`);
  }

  return response.data;
}

async function main() {
  try {
    const token = await getTenantAccessToken();
    const data = await listChats(token);

    console.log('\n✅ 机器人加入的群聊：\n');

    if (data.items && data.items.length > 0) {
      data.items.forEach((chat, index) => {
        console.log(`${index + 1}. ${chat.name || '(无名称)'}`);
        console.log(`   Chat ID: ${chat.chat_id}`);
        console.log(`   描述: ${chat.description || '(无描述)'}`);
        console.log('');
      });
    } else {
      console.log('未找到任何群聊');
    }

  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
