#!/usr/bin/env node

/**
 * 在文档中添加文本说明
 */

const https = require('https');
const fs = require('fs');
const path = require('path');

const configPath = path.join(__dirname, '../.lark-config.json');
const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
const APP_ID = config.app_id;
const APP_SECRET = config.app_secret;
const LARK_API_BASE = 'https://open.larksuite.com/open-apis';

function httpsRequest(options, postData = null) {
  return new Promise((resolve, reject) => {
    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          resolve(data);
        }
      });
    });
    req.on('error', reject);
    if (postData) req.write(postData);
    req.end();
  });
}

async function getTenantAccessToken() {
  const url = new URL(`${LARK_API_BASE}/auth/v3/tenant_access_token/internal`);
  const postData = JSON.stringify({ app_id: APP_ID, app_secret: APP_SECRET });
  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  const response = await httpsRequest(options, postData);
  if (response.code !== 0) throw new Error(`获取 token 失败: ${response.msg}`);
  return response.tenant_access_token;
}

async function addTextBlock(token, documentId, text) {
  const url = new URL(`${LARK_API_BASE}/docx/v1/documents/${documentId}/blocks/${documentId}/children`);

  const block = {
    block_type: 2, // 文本块
    text: {
      elements: [
        {
          text_run: {
            content: text
          }
        }
      ]
    }
  };

  const postData = JSON.stringify({
    children: [block],
    index: -1
  });

  const options = {
    hostname: url.hostname,
    path: url.pathname,
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      'Content-Length': Buffer.byteLength(postData)
    }
  };

  const response = await httpsRequest(options, postData);
  if (response.code !== 0) {
    throw new Error(`添加文本失败: ${response.msg}`);
  }
  return response.data;
}

async function main() {
  const documentId = process.argv[2];
  const fileToken = process.argv[3];
  const fileName = process.argv[4];

  const token = await getTenantAccessToken();

  // 添加分隔线
  await addTextBlock(token, documentId, '\n---\n');

  // 添加说明文本
  await addTextBlock(token, documentId, '📦 项目压缩包');
  await addTextBlock(token, documentId, `\n文件名：${fileName}`);
  await addTextBlock(token, documentId, `文件 Token：${fileToken}`);
  await addTextBlock(token, documentId, '\n压缩包已上传到飞书云空间，包含完整的项目文件。');

  console.log('✅ 文件信息已添加到文档');
}

main().catch(console.error);
