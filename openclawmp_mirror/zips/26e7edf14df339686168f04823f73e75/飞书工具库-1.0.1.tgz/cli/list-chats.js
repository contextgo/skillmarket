#!/usr/bin/env node

/**
 * CLI: 列出所有群聊
 */

const { LarkAuth, LarkChat } = require('../lib');

async function main() {
  try {
    const auth = LarkAuth.fromConfig('.lark-config.json');
    const chat = new LarkChat(auth);

    console.log('📋 获取群聊列表...\n');

    const chats = await chat.list();

    if (chats.length === 0) {
      console.log('未找到任何群聊');
      return;
    }

    console.log(`✅ 找到 ${chats.length} 个群聊：\n`);

    chats.forEach((item, index) => {
      console.log(`${index + 1}. ${item.name || '(无名称)'}`);
      console.log(`   Chat ID: ${item.chat_id}`);
      if (item.description) {
        console.log(`   描述: ${item.description}`);
      }
      console.log('');
    });

  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
