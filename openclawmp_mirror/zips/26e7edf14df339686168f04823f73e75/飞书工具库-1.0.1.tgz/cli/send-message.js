#!/usr/bin/env node

/**
 * CLI: 发送消息到群聊
 * 用法: node cli/send-message.js <chat_name> <message>
 */

const { LarkAuth, LarkMessage, LarkChat } = require('../lib');

async function main() {
  try {
    const args = process.argv.slice(2);

    if (args.length < 2) {
      console.error('用法: node cli/send-message.js <chat_name> <message>');
      console.error('示例: node cli/send-message.js "测试" "Hello World"');
      process.exit(1);
    }

    const chatName = args[0];
    const messageText = args[1];

    const auth = LarkAuth.fromConfig('.lark-config.json');
    const chat = new LarkChat(auth);
    const message = new LarkMessage(auth);

    console.log(`🔍 查找群聊: ${chatName}...`);

    const targetChat = await chat.findByName(chatName);

    if (!targetChat) {
      console.error(`❌ 未找到群聊: ${chatName}`);
      process.exit(1);
    }

    console.log(`✅ 找到群聊: ${targetChat.name} (${targetChat.chat_id})`);
    console.log(`📨 发送消息...`);

    await message.sendText(targetChat.chat_id, messageText);

    console.log('✅ 消息已发送');

  } catch (error) {
    console.error('❌ 错误:', error.message);
    process.exit(1);
  }
}

main();
