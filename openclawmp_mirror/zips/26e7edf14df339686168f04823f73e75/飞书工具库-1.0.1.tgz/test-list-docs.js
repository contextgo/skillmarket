#!/usr/bin/env node
/**
 * 测试读取飞书文档列表
 */

const https = require('https');
const config = require('./.lark-config.json');

async function listDocs() {
  const apiBase = config.region === 'feishu' ? 'open.feishu.cn' : 'open.larksuite.com';
  
  console.log('📄 测试读取飞书文档列表\n');
  console.log('=' .repeat(50));
  
  // 1. 获取 Token
  console.log('\n1️⃣ 获取 Token...');
  const tokenRes = await new Promise((resolve, reject) => {
    const req = https.request({
      hostname: apiBase,
      path: '/open-apis/auth/v3/tenant_access_token/internal',
      method: 'POST',
      headers: { 'Content-Type': 'application/json' }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    req.on('error', reject);
    req.write(JSON.stringify({ app_id: config.app_id, app_secret: config.app_secret }));
    req.end();
  });
  
  if (tokenRes.code !== 0) {
    console.log('❌ Token 获取失败:', tokenRes.msg);
    return;
  }
  
  const token = tokenRes.tenant_access_token;
  console.log('✅ Token 获取成功');
  
  // 2. 获取文档列表（云空间）
  console.log('\n2️⃣ 获取云空间文件列表...');
  const driveRes = await new Promise((resolve, reject) => {
    const req = https.request({
      hostname: apiBase,
      path: '/open-apis/drive/v1/files?parent_type=root&limit=10',
      method: 'GET',
      headers: {
        'Authorization': 'Bearer ' + token
      }
    }, res => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => resolve(JSON.parse(data)));
    });
    req.on('error', reject);
    req.end();
  });
  
  console.log('   原始数据:', JSON.stringify(driveRes, null, 2).substring(0, 500));
  
  if (driveRes.code !== 0) {
    console.log('❌ 获取失败:', driveRes.msg);
  } else {
    console.log('✅ 获取成功');
    const items = driveRes.data?.items || driveRes.items || [];
    console.log('   文件数:', items.length);
    if (items.length > 0) {
      console.log('\n   文件列表:');
      items.forEach((f, i) => {
        console.log(`   ${i+1}. ${f.name || f.title} (${f.type || f.obj_type})`);
        console.log(`      Token: ${f.token || f.id}`);
      });
    }
  }
  
  console.log('\n' + '='.repeat(50));
  console.log('✅ 测试完成\n');
}

listDocs().catch(e => console.error('❌ 错误:', e.message));
