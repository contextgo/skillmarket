# 飞书工具库重构建议

## 目标
将当前的脚本整合成一个通用的飞书消息工具库，方便在其他项目中复用。

## 新的项目结构

```
feishu-toolkit/
├── lib/
│   ├── auth.js              # 认证相关
│   ├── message.js           # 消息发送
│   ├── file.js              # 文件上传
│   ├── chat.js              # 群聊管理
│   └── template.js          # 消息模板
├── cli/
│   ├── send-message.js      # CLI: 发送消息
│   ├── send-file.js         # CLI: 发送文件
│   ├── list-chats.js        # CLI: 列出群聊
│   └── send-template.js     # CLI: 发送模板消息
├── templates/
│   ├── project-report.json  # 项目简报模板
│   ├── weekly-report.json   # 周报模板
│   └── notification.json    # 通知模板
├── examples/
│   └── send-project-report.js
├── package.json
└── README.md
```

## 核心模块设计

### 1. auth.js - 认证模块
```javascript
class LarkAuth {
  constructor(appId, appSecret) {}
  async getTenantAccessToken() {}
  async refreshToken() {}
}
```

### 2. message.js - 消息模块
```javascript
class LarkMessage {
  constructor(auth) {}

  // 发送消息
  async sendText(chatId, text) {}
  async sendRichText(chatId, content) {}
  async sendFile(chatId, fileKey) {}

  // 回复消息
  async reply(messageId, content, msgType) {}
  async replyInThread(messageId, content, msgType) {}

  // 批量操作
  async sendToMultiple(chatIds, content, msgType) {}
}
```

### 3. file.js - 文件模块
```javascript
class LarkFile {
  constructor(auth) {}

  async uploadForMessage(filePath) {}
  async uploadToDrive(filePath, parentNode) {}
  async getFileInfo(fileKey) {}
}
```

### 4. chat.js - 群聊模块
```javascript
class LarkChat {
  constructor(auth) {}

  async list() {}
  async findByName(name) {}
  async getInfo(chatId) {}
  async getMembers(chatId) {}
}
```

### 5. template.js - 模板模块
```javascript
class LarkTemplate {
  constructor(message) {}

  loadTemplate(name) {}
  render(templateName, data) {}
  async send(chatId, templateName, data) {}
}
```

## 使用示例

### 基础使用
```javascript
const { LarkAuth, LarkMessage, LarkChat } = require('feishu-toolkit');

const auth = new LarkAuth(APP_ID, APP_SECRET);
const message = new LarkMessage(auth);
const chat = new LarkChat(auth);

// 列出群聊
const chats = await chat.list();

// 发送消息
await message.sendText('oc_xxx', 'Hello World');

// 回复消息
await message.reply('om_xxx', { text: 'Reply' }, 'text');
```

### 模板使用
```javascript
const { LarkTemplate } = require('feishu-toolkit');

const template = new LarkTemplate(message);

// 发送项目简报
await template.send('oc_xxx', 'project-report', {
  title: 'AI 文档助手',
  problem: '每次写需求文档要手动查找格式',
  docUrl: 'https://...',
  steps: ['下载', '配置', '启动', '使用']
});
```

### CLI 使用
```bash
# 列出群聊
feishu-toolkit list-chats

# 发送消息
feishu-toolkit send-message --chat "AI分享群" --text "Hello"

# 发送文件
feishu-toolkit send-file --chat "测试群" --file "./package.zip"

# 发送模板消息
feishu-toolkit send-template --chat "AI分享群" --template "project-report" --data ./data.json
```

## 优势

1. **模块化**：每个功能独立，易于维护
2. **可复用**：其他项目可以直接引入
3. **类型安全**：可以添加 TypeScript 支持
4. **易于测试**：每个模块可以单独测试
5. **CLI 支持**：可以作为命令行工具使用
6. **模板系统**：快速创建各种消息格式

## 实施步骤

1. 创建新的 `feishu-toolkit` 目录
2. 重构现有脚本，提取通用逻辑
3. 创建核心模块（auth, message, file, chat）
4. 实现模板系统
5. 创建 CLI 工具
6. 编写文档和示例
7. 发布为 npm 包（可选）

## 下一步

建议先实现核心模块，然后逐步添加高级功能。这样可以快速验证设计，并根据实际使用情况调整。
