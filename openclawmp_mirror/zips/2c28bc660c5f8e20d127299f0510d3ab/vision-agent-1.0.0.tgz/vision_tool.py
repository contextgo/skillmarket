#!/usr/bin/env python3
"""
视觉分析代理工具
用法: python3 vision_tool.py <图片路径> [问题]
"""

import sys
import base64
import requests
import json

MODEL = "qwen3-vl:235b-cloud"
OLLAMA_URL = "http://localhost:11434/api/generate"

def analyze_image(image_path, prompt="详细描述图片内容"):
    """调用qwen3-vl分析图片"""
    
    # 读取图片
    try:
        with open(image_path, "rb") as f:
            img_b64 = base64.b64encode(f.read()).decode("utf-8")
    except FileNotFoundError:
        return f"错误：找不到图片文件 {image_path}"
    except Exception as e:
        return f"错误：读取图片失败 {e}"
    
    # 调用Ollama API
    payload = {
        "model": MODEL,
        "prompt": prompt,
        "images": [img_b64]
    }
    
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=120, stream=True)
        result = []
        
        for line in resp.iter_lines():
            if line:
                data = json.loads(line)
                if "response" in data:
                    result.append(data["response"])
                if data.get("done", False):
                    break
        
        return "".join(result)
        
    except requests.exceptions.Timeout:
        return "错误：模型响应超时"
    except Exception as e:
        return f"错误：{e}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 vision_tool.py <图片路径> [问题]")
        print("示例: python3 vision_tool.py /path/to/image.jpg '描述图片内容'")
        sys.exit(1)
    
    image_path = sys.argv[1]
    prompt = sys.argv[2] if len(sys.argv) > 2 else "详细描述图片内容"
    
    print(f"🔍 正在分析图片: {image_path}")
    print(f"📝 问题: {prompt}")
    print("-" * 50)
    
    result = analyze_image(image_path, prompt)
    print(result)
