---
name: vision-agent
description: "视觉分析代理 - 使用qwen3-vl:235b-cloud分析图片内容。当用户发送图片并要求分析时使用此技能。支持交易图表、截图、照片等视觉内容分析。"
homepage: 
metadata: { "openclaw": { "emoji": "👁️", "requires": { "models": ["qwen3-vl:235b-cloud"] } } }
---

# Vision Agent Skill

视觉分析代理，使用阿里云qwen3-vl:235b-cloud模型分析图片内容。

## When to Use

✅ **USE this skill when:**

- 用户发送图片并要求"分析"
- 用户发送图片并要求"描述"
- 用户发送图片并要求"看看"
- 发送截图要求分析内容
- 发送交易图表要求技术分析

## Input

- 图片文件路径或URL
- 分析要求（可选，默认"详细描述图片内容"）

## Output

详细的图片内容分析描述

## Implementation

使用Ollama API调用qwen3-vl:235b-cloud模型：

```python
import base64
import requests
import json

def analyze_image(image_path, prompt="详细描述图片内容"):
    with open(image_path, "rb") as f:
        img_b64 = base64.b64encode(f.read()).decode("utf-8")
    
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": "qwen3-vl:235b-cloud",
        "prompt": prompt,
        "images": [img_b64]
    }
    
    resp = requests.post(url, json=payload, timeout=120, stream=True)
    for line in resp.iter_lines():
        if line:
            data = json.loads(line)
            if "response" in data:
                print(data["response"], end="")
            if data.get("done", False):
                break
```

## Notes

- 模型：qwen3-vl:235b-cloud（云端模型）
- 需要Ollama服务运行
- 支持JPEG、PNG、GIF、WebP格式
- 单次分析约需30-60秒
