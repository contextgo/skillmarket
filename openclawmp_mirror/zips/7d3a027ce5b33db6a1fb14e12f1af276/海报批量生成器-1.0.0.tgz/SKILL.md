---
name: 海报批量生成器
displayName: 海报批量生成器
description: 根据模板和数据批量生成课程海报，风格统一，信息准确。
version: 1.0.0
author: OpenClaw Edu
tags: [education, poster, batch, design, marketing]
category: education
---

# 海报批量生成器

批量生成课程海报。

## 功能

- 模板设计
- 数据批量填充
- 风格统一
- 高清PNG输出
- 自动排版

## 使用

```
@海报批量生成器 根据课程表批量生成13张课程海报
```
