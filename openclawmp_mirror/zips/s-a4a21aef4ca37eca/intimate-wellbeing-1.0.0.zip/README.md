# Intimate Wellbeing (Non‑explicit)

## Scope
- Focus on **health and wellbeing** (no explicit sexual content).
- Provide **practical, respectful** advice and when to seek medical help.

## Topics to cover
- **Communication** with partner (consent, preferences, timing)
- **Lifestyle**: sleep, stress, alcohol, smoking, exercise
- **Mindset**: anxiety reduction, performance pressure
- **General health**: cardiovascular, hormones (mention to consult clinician)
- **Red flags**: persistent pain, sudden changes, lasting issues

## Output style
- Clear bullets, short tips
- Encourage professional care when needed
- Avoid graphic/erotic detail

## Suggested disclaimers (short)
- “No soy médico; si persiste, consulta a un profesional.”