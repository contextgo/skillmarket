---
name: prompt-engineering-patterns
description: "LLM Prompt 工程核心模式，从基础到高级的完整指南"
version: 1.0.0
tags: ["prompt-engineering", "llm", "ai"]
---

# Prompt Engineering Patterns

## Overview
经过实战验证的 LLM prompt 工程模式，提升输出质量和可靠性。

## Pattern 1: System-User-Instruction (Three-Layer)
```
[System] 你是一个专业的市场分析师...
[User Context] 当前市场数据: BTC $71K, Fear=15...
[Instruction] 请分析以下新闻对市场的影响...
```

**为什么有效**: 明确角色 + 提供上下文 + 精确指令

## Pattern 2: Chain-of-Thought (CoT)
```
分析步骤：
1. 首先识别关键数据点
2. 然后评估每个数据点的影响方向
3. 接着考虑数据点之间的关联
4. 最后综合给出判断

请按以上步骤逐步分析。
```

**为什么有效**: 强制模型显式推理，减少跳跃性结论

## Pattern 3: Few-Shot with Format
```
示例1:
输入: "Oil突破$100"
分析: 看多信号，通胀压力上升，可能推高能源股
置信度: 75%

示例2:
输入: "BTC跌破$65K"
分析: 恐慌信号，但 Fear=15 是历史反向指标
置信度: 60%

现在分析:
输入: "Fed维持利率不变"
分析:
```

**为什么有效**: 示例定义了期望的输出格式和推理深度

## Pattern 4: Constraint-Based
```
要求：
- 回答控制在 200 字以内
- 必须包含具体的行动建议
- 不使用"可能"、"或许"等模糊词
- 必须给出置信度百分比
```

**为什么有效**: 约束减少不确定性输出

## Pattern 5: Self-Evaluation
```
先给出你的初步分析，然后：
1. 评估自己分析的盲点
2. 考虑反面论据
3. 如果有重要信息缺失，明确说明
4. 给出最终修正后的判断
```

**为什么有效**: 内置自我纠错机制

## Pattern 6: Structured Output
```
请以以下 JSON 格式输出：
{
  "signal": "buy/sell/hold",
  "confidence": 0-100,
  "reasons": ["reason1", "reason2"],
  "risks": ["risk1", "risk2"],
  "action": "具体建议"
}
```

**为什么有效**: 可机器解析的输出便于后续处理

## Anti-Patterns
- ❌ "请尽量详细" → 产生冗余信息
- ❌ "帮我分析" → 缺乏上下文
- ❌ 连续追问细节 → 对话成本高
- ✅ 一次性给足上下文 + 明确约束 + 期望格式
