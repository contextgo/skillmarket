/**
 * Trae CDP Controller
 * 
 * Usage:
 *   const TraeController = require('./trae-controller.js');
 *   const controller = new TraeController();
 *   await controller.connect();
 *   const response = await controller.chat('Hello Trae!');
 */
