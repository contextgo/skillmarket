#!/bin/bash
# 股票实时行情测试脚本
# 测试增强版API的各种功能

echo "=========================================="
echo "股票实时行情增强版 - 功能测试"
echo "=========================================="
echo ""

# 设置脚本路径
SCRIPT_PATH="$HOME/.openclaw/workspace/skills/stock-realtime/scripts/enhanced_stock_api.py"

# 测试1: 查询单只股票
echo "📝 测试1: 查询单只股票（浦发银行）"
echo "----------------------------------------"
python "$SCRIPT_PATH" sh600000
echo ""

# 测试2: 查询多只股票表格
echo "📝 测试2: 查询多只股票（表格显示）"
echo "----------------------------------------"
python "$SCRIPT_PATH" sh600000 sz000001 hk00700 --table
echo ""

# 测试3: 技术分析
echo "📝 测试3: 技术分析"
echo "----------------------------------------"
python "$SCRIPT_PATH" sh600000 --analysis
echo ""

# 测试4: 资金流向
echo "📝 测试4: 资金流向分析"
echo "----------------------------------------"
python "$SCRIPT_PATH" sh600000 --fund-flow
echo ""

# 测试5: 龙虎榜数据
echo "📝 测试5: 龙虎榜数据"
echo "----------------------------------------"
python "$SCRIPT_PATH" sh600000 --dragon-tiger
echo ""

# 测试6: AH股溢价
echo "📝 测试6: AH股溢价对比"
echo "----------------------------------------"
python "$SCRIPT_PATH" sh600000 --ah-premium
echo ""

# 测试7: 综合分析
echo "📝 测试7: 综合分析（技术分析+资金流向）"
echo "----------------------------------------"
python "$SCRIPT_PATH" sh600000 --analysis --fund-flow
echo ""

# 测试8: 自选股管理
echo "📝 测试8: 自选股管理"
echo "----------------------------------------"
echo "添加自选股..."
python "$SCRIPT_PATH" --watchlist add sh600000 "银行龙头"
python "$SCRIPT_PATH" --watchlist add sz000001 "银行"
echo ""
echo "查看自选股列表..."
python "$SCRIPT_PATH" --watchlist list
echo ""
echo "删除自选股..."
python "$SCRIPT_PATH" --watchlist remove sh600000
python "$SCRIPT_PATH" --watchlist remove sz000001
echo ""

# 测试9: 查询美股
echo "📝 测试9: 查询美股（苹果）"
echo "----------------------------------------"
python "$SCRIPT_PATH" usAAPL
echo ""

# 测试10: 查询港股
echo "📝 测试10: 查询港股（腾讯）"
echo "----------------------------------------"
python "$SCRIPT_PATH" hk00700
echo ""

echo "=========================================="
echo "✅ 所有测试完成"
echo "=========================================="
echo ""
echo "⚠️ 注意: 部分测试可能因网络问题返回空数据"
echo "⚠️ 所有价格数据仅供参考，不构成投资建议"