# 股票API技术参考文档

本文档提供股票行情API的详细技术信息。

## API端点

### 新浪财经API（主要数据源）

**端点URL：**
```
https://hq.sinajs.cn/list={股票代码}
```

**请求示例：**
```
https://hq.sinajs.cn/list=sh600000,sz000001,hk00700,usAAPL
```

**响应格式：**
```
var hq_str_sh600000="浦发银行,10.50,10.45,10.68,10.72,10.40,10.67,10.68,12345678,130000000,...";
```

### 数据字段说明

响应数据为逗号分隔的字符串，字段顺序如下：

| 字段索引 | 字段名称 | 说明 | 示例 |
|---------|---------|------|------|
| 0 | 股票名称 | 公司名称 | 浦发银行 |
| 1 | 今日开盘价 | 当日开盘价 | 10.50 |
| 2 | 昨日收盘价 | 前一日收盘价 | 10.45 |
| 3 | 当前价格 | 最新成交价 | 10.68 |
| 4 | 今日最高价 | 当日最高成交价 | 10.72 |
| 5 | 今日最低价 | 当日最低成交价 | 10.40 |
| 6 | 竞买价 | 买一价 | 10.67 |
| 7 | 竞卖价 | 卖一价 | 10.68 |
| 8 | 成交量 | 累计成交量（股） | 12345678 |
| 9 | 成交额 | 累计成交金额（元） | 130000000 |
| 10-19 | 买一到买五 | 买一到买五的价格和数量 | - |
| 20-29 | 卖一到卖五 | 卖一到卖五的价格和数量 | - |
| 30 | 日期 | 交易日期 | 2024-03-18 |
| 31 | 时间 | 交易时间 | 15:00:00 |

### 市场代码前缀

| 市场 | 前缀 | 说明 | 示例 |
|------|------|------|------|
| 上海证券交易所 | sh | A股、B股 | sh600000 |
| 深圳证券交易所 | sz | A股、B股、创业板 | sz000001 |
| 香港交易所 | hk | 港股 | hk00700 |
| 美国股市 | us | 纳斯达克、纽交所 | usAAPL |

## 计算字段

### 涨跌幅计算

```python
涨跌幅 = ((当前价格 - 昨收价) / 昨收价) * 100
```

### 涨跌额计算

```python
涨跌额 = 当前价格 - 昨收价
```

## 错误处理

### 常见错误码

| 错误类型 | 描述 | 处理方式 |
|---------|------|---------|
| 网络超时 | API请求超时 | 重试3次，间隔1秒 |
| 无效股票代码 | 股票代码不存在或格式错误 | 提示用户检查代码格式 |
| API限流 | 请求频率过高 | 等待60秒后重试 |
| 空数据 | 非交易时段或停牌 | 提示当前无交易数据 |

### 错误响应示例

```python
# 无效股票代码
var hq_str_sh999999="";

# API返回空值
# 无响应或响应为空
```

## 请求限制

### 频率限制

- **建议频率**：每分钟不超过30次请求
- **最大频率**：每分钟不超过100次请求
- **批量查询**：单次请求最多查询50只股票

### 最佳实践

1. **批量查询**：将多只股票合并在一次请求中
2. **缓存机制**：对于频繁查询的股票，本地缓存30秒
3. **错误重试**：实现指数退避重试机制
4. **请求间隔**：批量查询时，请求间隔至少2秒

## 数据更新时间

### A股市场
- **开盘时间**：9:30-11:30, 13:00-15:00（北京时间）
- **更新频率**：实时（3秒延迟）
- **盘前数据**：9:15-9:25集合竞价

### 港股市场
- **开盘时间**：9:30-12:00, 13:00-16:00（香港时间）
- **更新频率**：实时（3秒延迟）

### 美股市场
- **开盘时间**：9:30-16:00（美国东部时间）
- **北京时间**：21:30-4:00（夏令时）/ 22:30-5:00（冬令时）
- **更新频率**：实时（15分钟延迟免费数据）

## Python实现示例

### 基本查询

```python
import requests

def get_stock_quote(stock_code):
    """获取单只股票行情"""
    url = f"https://hq.sinajs.cn/list={stock_code}"
    headers = {'Referer': 'https://finance.sina.com.cn'}

    response = requests.get(url, headers=headers, timeout=5)
    response.encoding = 'gbk'

    data_str = response.text.split('"')[1]
    if not data_str:
        return None

    fields = data_str.split(',')

    return {
        'name': fields[0],
        'open': float(fields[1]),
        'last_close': float(fields[2]),
        'current': float(fields[3]),
        'high': float(fields[4]),
        'low': float(fields[5]),
        'volume': int(fields[8]),
        'amount': float(fields[9]),
        'date': fields[30],
        'time': fields[31]
    }
```

### 批量查询

```python
def get_multiple_quotes(stock_codes):
    """批量获取多只股票行情"""
    codes_str = ','.join(stock_codes)
    url = f"https://hq.sinajs.cn/list={codes_str}"

    response = requests.get(url, headers=headers, timeout=10)
    response.encoding = 'gbk'

    results = {}
    for line in response.text.split('\n'):
        if not line.strip():
            continue
        code = line.split('=')[0].split('_')[-1]
        data = parse_quote_data(line)
        if data:
            results[code] = data

    return results
```

## 数据解析注意事项

### 编码处理

新浪财经API返回GBK编码数据：
```python
response.encoding = 'gbk'
```

### 空数据处理

```python
if not data_str or data_str == '':
    # 股票代码无效或停牌
    return None
```

### 数值精度

```python
# 价格保留2位小数
price = round(float(price_str), 2)

# 成交量转换为万手
volume_wan = int(volume) / 10000
```

## 备用数据源

如果新浪API不可用，可使用以下备用源：

### 腾讯财经API

```
https://web.qtoss.com/qt/data/list={股票代码}
```

### 网易财经API

```
https://api.money.126.net/data/feed/{股票代码}
```

## 法律声明

- 本技能仅供学习和参考使用
- 数据来源于公开API，准确性不保证
- 不构成任何投资建议
- 请遵守相关API的使用条款和频率限制
- 商业使用请获取相应的API授权