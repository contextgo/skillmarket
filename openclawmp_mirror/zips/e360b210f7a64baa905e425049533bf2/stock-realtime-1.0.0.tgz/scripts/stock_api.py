#!/usr/bin/env python3
"""
股票实时行情查询工具 v2.0
支持A股、港股、美股市场实时行情数据查询

更新内容：
- 修复美股代码格式问题（usAAPL -> gb_aapl）
- 修复港股数据解析问题
- 增加代码格式自动识别
"""

import sys
import requests
import time
import re
from typing import Dict, List, Optional, Tuple


def normalize_code(code: str) -> Tuple[str, str]:
    """
    标准化股票代码，返回 (标准化代码, 市场类型)
    
    支持格式：
    - A股：sh600000, sz000001, 600000, 000001
    - 港股：hk00700, 00700, 01810
    - 美股：usAAPL, AAPL, gb_aapl
    """
    code = code.strip().lower()
    
    # 已有前缀的情况
    if code.startswith('sh'):
        return f"sh{code[2:]}", 'A股'
    elif code.startswith('sz'):
        return f"sz{code[2:]}", 'A股'
    elif code.startswith('hk'):
        return f"hk{code[2:].zfill(5)}", '港股'
    elif code.startswith('us'):
        # usAAPL -> gb_aapl (新浪美股格式)
        symbol = code[2:].upper()
        return f"gb_{symbol.lower()}", '美股'
    elif code.startswith('gb_'):
        return code, '美股'
    
    # 无前缀的情况
    if code.isdigit():
        if len(code) == 6:
            if code.startswith(('60', '68')):
                return f"sh{code}", 'A股'
            elif code.startswith(('00', '30')):
                return f"sz{code}", 'A股'
        elif len(code) == 5:
            return f"hk{code.zfill(5)}", '港股'
        elif len(code) <= 4:
            return f"hk{code.zfill(5)}", '港股'
    else:
        return f"gb_{code.lower()}", '美股'
    
    return code, '未知'


class StockQuote:
    """股票行情数据类"""

    def __init__(self, code: str, data: dict):
        self.code = code
        self.name = data.get('name', 'N/A')
        self.current = data.get('current', 0.0)
        self.last_close = data.get('last_close', 0.0)
        self.high = data.get('high', 0.0)
        self.low = data.get('low', 0.0)
        self.open = data.get('open', 0.0)
        self.volume = data.get('volume', 0)
        self.amount = data.get('amount', 0.0)
        self.date = data.get('date', '')
        self.time = data.get('time', '')

        # 计算涨跌幅和涨跌额
        if self.last_close > 0:
            self.change_percent = ((self.current - self.last_close) / self.last_close) * 100
            self.change_amount = self.current - self.last_close
        else:
            self.change_percent = 0.0
            self.change_amount = 0.0

    def is_valid(self) -> bool:
        """检查数据是否有效"""
        return self.name != 'N/A' and self.current > 0


class StockAPI:
    """股票API查询类"""

    BASE_URL = "https://hq.sinajs.cn/list="
    HEADERS = {
        'Referer': 'https://finance.sina.com.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }

    # 市场代码映射
    MARKET_PREFIX = {
        'sh': '上交所',
        'sz': '深交所',
        'hk': '港股',
        'us': '美股'
    }

    @classmethod
    def get_market(cls, code: str) -> str:
        """识别股票市场"""
        prefix = code[:2].lower() if len(code) >= 2 else ''
        return cls.MARKET_PREFIX.get(prefix, '未知')

    @classmethod
    def fetch_quotes(cls, codes: List[str], retry: int = 3) -> Dict[str, StockQuote]:
        """批量获取股票行情"""
        if not codes:
            return {}

        # 转换代码格式并建立映射
        normalized_codes = []
        code_mapping = {}  # 原始代码 -> 标准化代码
        
        for code in codes:
            normalized, market = normalize_code(code)
            normalized_codes.append(normalized)
            code_mapping[normalized] = code

        # 批量查询，每次最多50只
        batch_size = 50
        results = {}

        for i in range(0, len(normalized_codes), batch_size):
            batch = normalized_codes[i:i+batch_size]
            codes_str = ','.join(batch)
            url = cls.BASE_URL + codes_str

            for attempt in range(retry):
                try:
                    response = requests.get(url, headers=cls.HEADERS, timeout=5)
                    response.encoding = 'gbk'

                    if response.status_code == 200:
                        batch_results = cls._parse_response(response.text, code_mapping)
                        results.update(batch_results)
                        break
                    else:
                        if attempt < retry - 1:
                            time.sleep(1)
                        continue

                except requests.exceptions.RequestException as e:
                    if attempt < retry - 1:
                        time.sleep(1)
                    else:
                        print(f"网络请求失败: {e}", file=sys.stderr)

            # 批次间间隔，避免频率限制
            if i + batch_size < len(codes):
                time.sleep(0.5)

        return results

    @classmethod
    def _parse_response(cls, response_text: str, code_mapping: Dict[str, str] = None) -> Dict[str, StockQuote]:
        """解析API响应"""
        results = {}
        if code_mapping is None:
            code_mapping = {}

        for line in response_text.strip().split('\n'):
            if not line or '=' not in line:
                continue

            # 提取股票代码
            code_part = line.split('=')[0]
            # 对于美股 gb_xxx 格式，需要特殊处理
            if 'hq_str_' in code_part:
                sina_code = code_part.split('hq_str_')[-1]
            else:
                sina_code = code_part.split('_')[-1]
            
            # 获取原始代码
            original_code = code_mapping.get(sina_code, sina_code)

            # 提取数据
            data_part = line.split('"')[1] if '"' in line else ''
            if not data_part:
                continue

            # 解析字段
            fields = data_part.split(',')

            try:
                # 根据市场类型解析
                if sina_code.startswith('gb_'):
                    # 美股格式
                    if len(fields) >= 7:
                        current = float(fields[1]) if fields[1] else 0.0
                        change_percent = float(fields[2]) if fields[2] else 0.0
                        change_amount = float(fields[4]) if fields[4] else 0.0
                        
                        data = {
                            'name': fields[0],
                            'current': current,
                            'change_percent': change_percent,
                            'change_amount': change_amount,
                            'open': float(fields[5]) if fields[5] else 0.0,
                            'high': float(fields[6]) if fields[6] else 0.0,
                            'low': float(fields[7]) if len(fields) > 7 and fields[7] else 0.0,
                            'last_close': current - change_amount if current and change_amount else 0.0,
                            'volume': int(float(fields[10])) if len(fields) > 10 and fields[10] else 0,
                            'amount': float(fields[11]) if len(fields) > 11 and fields[11] else 0.0,
                            'date': '',
                            'time': fields[3] if len(fields) > 3 else ''
                        }
                    else:
                        continue
                        
                elif sina_code.startswith('hk') and len(fields) >= 19:
                    # 港股格式
                    data = {
                        'name': fields[1],  # 中文名
                        'open': float(fields[2]) if fields[2] else 0.0,
                        'last_close': float(fields[3]) if fields[3] else 0.0,
                        'high': float(fields[4]) if fields[4] else 0.0,
                        'low': float(fields[5]) if fields[5] else 0.0,
                        'current': float(fields[6]) if fields[6] else 0.0,
                        'volume': int(float(fields[12])) if fields[12] else 0,
                        'amount': 0.0,
                        'date': fields[17] if len(fields) > 17 else '',
                        'time': fields[18] if len(fields) > 18 else ''
                    }
                    # 涨跌额和涨跌幅
                    data['change_amount'] = float(fields[7]) if fields[7] else 0.0
                    data['change_percent'] = float(fields[8]) if fields[8] else 0.0
                    
                elif len(fields) >= 32:
                    # A股格式
                    data = {
                        'name': fields[0],
                        'open': float(fields[1]) if fields[1] else 0.0,
                        'last_close': float(fields[2]) if fields[2] else 0.0,
                        'current': float(fields[3]) if fields[3] else 0.0,
                        'high': float(fields[4]) if fields[4] else 0.0,
                        'low': float(fields[5]) if fields[5] else 0.0,
                        'volume': int(float(fields[8])) if fields[8] else 0,
                        'amount': float(fields[9]) if fields[9] else 0.0,
                        'date': fields[30] if len(fields) > 30 else '',
                        'time': fields[31] if len(fields) > 31 else ''
                    }
                    # 计算涨跌
                    if data['last_close'] > 0:
                        data['change_amount'] = data['current'] - data['last_close']
                        data['change_percent'] = (data['current'] - data['last_close']) / data['last_close'] * 100
                    else:
                        data['change_amount'] = 0.0
                        data['change_percent'] = 0.0
                else:
                    continue

                quote = StockQuote(original_code, data)
                if quote.is_valid():
                    results[original_code] = quote

            except (ValueError, IndexError):
                continue

        return results


def format_number(num: float, decimal: int = 2) -> str:
    """格式化数字显示"""
    if abs(num) >= 100000000:  # 亿
        return f"{num/100000000:.{decimal}f}亿"
    elif abs(num) >= 10000:  # 万
        return f"{num/10000:.{decimal}f}万"
    else:
        return f"{num:.{decimal}f}"


def colorize(text: str, color: str) -> str:
    """添加颜色（仅在终端支持时）"""
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'reset': '\033[0m'
    }

    # 检查是否在终端环境
    if sys.stdout.isatty():
        return f"{colors.get(color, '')}{text}{colors['reset']}"
    return text


def display_quote(quote: StockQuote):
    """显示单只股票行情"""
    market = StockAPI.get_market(quote.code)

    # 涨跌颜色
    if quote.change_percent > 0:
        change_str = f"+{quote.change_percent:.2f}%"
        amount_str = f"+{quote.change_amount:.2f}"
        change_color = 'red'  # 中国股市红色代表上涨
    elif quote.change_percent < 0:
        change_str = f"{quote.change_percent:.2f}%"
        amount_str = f"{quote.change_amount:.2f}"
        change_color = 'green'  # 中国股市绿色代表下跌
    else:
        change_str = "0.00%"
        amount_str = "0.00"
        change_color = 'yellow'

    # 打印股票信息
    print("\n" + "="*60)
    print(f"股票代码: {quote.code} ({market})")
    print(f"股票名称: {colorize(quote.name, 'blue')}")
    print("="*60)
    print(f"当前价格: {colorize(f'{quote.current:.2f}', 'blue')}")
    print(f"涨跌幅:   {colorize(change_str, change_color)}")
    print(f"涨跌额:   {colorize(amount_str, change_color)}")
    print("-"*60)
    print(f"今开:     {quote.open:.2f}")
    print(f"昨收:     {quote.last_close:.2f}")
    print(f"最高:     {quote.high:.2f}")
    print(f"最低:     {quote.low:.2f}")
    print("-"*60)
    print(f"成交量:   {format_number(quote.volume)}股")
    print(f"成交额:   {format_number(quote.amount)}元")
    print("-"*60)
    print(f"日期:     {quote.date}")
    print(f"时间:     {quote.time}")
    print("="*60)


def display_table(quotes: List[StockQuote]):
    """以表格形式显示多只股票行情"""
    if not quotes:
        print("没有查询到有效数据")
        return

    # 表头
    headers = ["代码", "名称", "当前价", "涨跌幅", "涨跌额", "成交量", "成交额"]
    col_widths = [12, 10, 10, 10, 10, 12, 12]

    # 打印表头
    print("\n" + "="*80)
    header_line = "".join(f"{header:<{width}}" for header, width in zip(headers, col_widths))
    print(header_line)
    print("="*80)

    # 打印数据行
    for quote in quotes:
        market = StockAPI.get_market(quote.code)

        # 涨跌信息
        if quote.change_percent > 0:
            change_str = f"+{quote.change_percent:.2f}%"
            amount_str = f"+{quote.change_amount:.2f}"
            color = 'red'
        elif quote.change_percent < 0:
            change_str = f"{quote.change_percent:.2f}%"
            amount_str = f"{quote.change_amount:.2f}"
            color = 'green'
        else:
            change_str = "0.00%"
            amount_str = "0.00"
            color = 'yellow'

        # 格式化数据
        row = [
            quote.code[:12],
            quote.name[:8] if len(quote.name) > 8 else quote.name,
            f"{quote.current:.2f}",
            colorize(change_str, color),
            colorize(amount_str, color),
            format_number(quote.volume),
            format_number(quote.amount)
        ]

        row_line = "".join(f"{cell:<{width}}" for cell, width in zip(row, col_widths))
        print(row_line)

    print("="*80 + "\n")


def read_codes_from_file(filepath: str) -> List[str]:
    """从文件读取股票代码"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            codes = [line.strip() for line in f if line.strip()]
            return codes
    except FileNotFoundError:
        print(f"错误: 文件 {filepath} 不存在", file=sys.stderr)
        return []
    except Exception as e:
        print(f"读取文件错误: {e}", file=sys.stderr)
        return []


def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description='股票实时行情查询工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog='''
示例:
  # 查询单只股票
  python stock_api.py sh600000

  # 查询多只股票
  python stock_api.py sh600000 sz000001 usAAPL

  # 从文件批量查询
  python stock_api.py --file stocks.txt

股票代码格式:
  A股: sh600000 (上交所) 或 sz000001 (深交所)
  港股: hk00700 (腾讯控股)
  美股: usAAPL (苹果)
        '''
    )

    parser.add_argument('codes', nargs='*', help='股票代码列表')
    parser.add_argument('-f', '--file', help='从文件读取股票代码（每行一个）')
    parser.add_argument('-t', '--table', action='store_true', help='以表格形式显示结果')

    args = parser.parse_args()

    # 收集股票代码
    codes = []

    if args.file:
        file_codes = read_codes_from_file(args.file)
        codes.extend(file_codes)

    if args.codes:
        # 验证代码格式
        for code in args.codes:
            if len(code) < 3:
                print(f"警告: 股票代码格式错误 '{code}'，已跳过", file=sys.stderr)
                continue
            codes.append(code)

    if not codes:
        parser.print_help()
        sys.exit(1)

    # 去重
    codes = list(dict.fromkeys(codes))

    print(f"正在查询 {len(codes)} 只股票...")
    time.sleep(0.3)  # 避免过快请求

    # 查询行情
    quotes_dict = StockAPI.fetch_quotes(codes)

    if not quotes_dict:
        print("未查询到任何有效数据")
        sys.exit(1)

    # 按原始顺序排序
    quotes = [quotes_dict[code] for code in codes if code in quotes_dict]

    # 显示结果
    if args.table or len(quotes) > 1:
        display_table(quotes)
    else:
        display_quote(quotes[0])

    # 显示缺失的代码
    missing_codes = [code for code in codes if code not in quotes_dict]
    if missing_codes:
        print("\n警告: 以下股票代码无效或无数据:")
        for code in missing_codes:
            print(f"  - {code}")


if __name__ == '__main__':
    main()