#!/usr/bin/env python3
"""
百度股市通指数数据抓取
用于补全恒生科技等指数数据
"""

import requests
import json
from datetime import datetime

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Accept': 'application/json',
    'Referer': 'https://gushitong.baidu.com/'
}

# 指数代码映射
INDEX_CODES = {
    '恒生科技': 'HKHSCEI',  # 恒生中国企业指数
    '恒生指数': 'HKHSI',
    '纳斯达克': 'USIXIC',
    '标普 500': 'USSPX',
    '道琼斯': 'USDJI'
}

def fetch_baidu_index(index_name: str) -> dict:
    """从百度股市通获取指数数据"""
    code = INDEX_CODES.get(index_name)
    if not code:
        return {}
    
    try:
        # 百度股市通 API
        url = f"https://finance.pae.baidu.com/api/v1/quote?code={code}"
        resp = requests.get(url, headers=HEADERS, timeout=10)
        
        if resp.status_code == 200:
            data = resp.json()
            if data.get('Result'):
                result = data['Result']
                return {
                    'name': result.get('name', index_name),
                    'price': float(result.get('price', 0)),
                    'change': float(result.get('change', 0)),
                    'change_percent': float(result.get('changePercent', 0)),
                    'time': result.get('time', datetime.now().strftime('%Y-%m-%d %H:%M:%S')),
                    'source': '百度股市通'
                }
    except Exception as e:
        print(f"获取 {index_name} 失败：{e}")
    
    return {}

def main():
    print("=" * 60)
    print("百度股市通指数数据")
    print("=" * 60)
    print(f"查询时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
    
    for name, code in INDEX_CODES.items():
        data = fetch_baidu_index(name)
        if data:
            change_icon = '📈' if data['change_percent'] > 0 else ('📉' if data['change_percent'] < 0 else '➖')
            print(f"{name}: {data['price']:.2f}  {change_icon}{data['change_percent']:+.2f}%")
        else:
            print(f"{name}: 数据暂缺")
    
    print("\n" + "=" * 60)

if __name__ == '__main__':
    main()
