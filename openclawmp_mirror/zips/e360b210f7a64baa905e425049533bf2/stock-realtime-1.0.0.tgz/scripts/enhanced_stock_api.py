#!/usr/bin/env python3
"""
增强版股票实时行情查询工具 v2.0
修复内容：
- 修复美股代码格式问题（usAAPL → gb_aapl）
- 增加多数据源备份（新浪、东方财富、腾讯）
- 增加智能缓存（交易时段30秒，非交易时段延长到下次开盘）
- 增加友好的错误提示
- 增加非交易时段提示
"""

import sys
import requests
import json
import time
import os
import hashlib
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
import math

# ============================================================================
# 常量定义
# ============================================================================

# 免责声明
DISCLAIMER = "⚠️ 所有价格数据仅供参考，不构成投资建议"

# 缓存配置
CACHE_DIR = '/tmp/stock_cache'
CACHE_EXPIRE_SECONDS = 30  # 交易时段缓存30秒
CACHE_NON_TRADING_HOURS = 3600  # 非交易时段缓存1小时

# 重试配置
MAX_RETRIES = 3
RETRY_DELAY = 1  # 重试间隔（秒）

# 请求超时
REQUEST_TIMEOUT = 10

# 市场代码映射
MARKET_PREFIX = {
    'sh': {'name': '上交所', 'country': 'CN', 'type': 'A股'},
    'sz': {'name': '深交所', 'country': 'CN', 'type': 'A股'},
    'hk': {'name': '港股', 'country': 'HK', 'type': '港股'},
    'us': {'name': '美股', 'country': 'US', 'type': '美股'},
    'gb': {'name': '美股', 'country': 'US', 'type': '美股'}  # 新浪美股格式
}

# 交易时段（北京时间）
TRADING_HOURS = {
    'A': [(9, 30), (11, 30), (13, 0), (15, 0)],  # A股：9:30-11:30, 13:00-15:00
    'HK': [(9, 30), (12, 0), (13, 0), (16, 0)],   # 港股：9:30-12:00, 13:00-16:00
    'US': [(21, 30), (4, 0)]  # 美股：21:30-次日4:00（夏令时）/22:30-次日5:00（冬令时）
}

# 自选股配置文件
WATCHLIST_FILE = '/tmp/stock_watchlist.json'


# ============================================================================
# 缓存管理类
# ============================================================================

class StockCache:
    """股票缓存管理"""

    def __init__(self, cache_dir: str = CACHE_DIR):
        self.cache_dir = cache_dir
        os.makedirs(cache_dir, exist_ok=True)

    def _get_cache_key(self, key: str) -> str:
        """生成缓存文件名"""
        hash_key = hashlib.md5(key.encode()).hexdigest()
        return os.path.join(self.cache_dir, f"{hash_key}.json")

    def _is_trading_hours(self, market_type: str) -> bool:
        """判断是否在交易时段"""
        now = datetime.now()
        current_time = (now.hour, now.minute)
        
        if market_type == 'A股':
            # 上午：9:30-11:30
            if (9, 30) <= current_time <= (11, 30):
                return True
            # 下午：13:00-15:00
            if (13, 0) <= current_time <= (15, 0):
                return True
            return False
        elif market_type == '港股':
            # 上午：9:30-12:00
            if (9, 30) <= current_time <= (12, 0):
                return True
            # 下午：13:00-16:00
            if (13, 0) <= current_time <= (16, 0):
                return True
            return False
        elif market_type == '美股':
            # 美股交易时间（北京时间）
            # 夏令时：21:30 - 次日04:00
            # 冬令时：22:30 - 次日05:00
            # 简化判断：21:30-04:00 视为交易时段
            hour = now.hour
            if hour >= 21 or hour < 4:
                return True
            return False
        
        return False

    def get(self, key: str, market_type: str = 'A股') -> Optional[Dict]:
        """获取缓存数据"""
        cache_file = self._get_cache_key(key)

        if not os.path.exists(cache_file):
            return None

        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 检查缓存时间
            cache_time = datetime.fromisoformat(data.get('cache_time', '2000-01-01'))
            now = datetime.now()
            
            # 根据交易时段决定缓存过期时间
            if self._is_trading_hours(market_type):
                expire_seconds = CACHE_EXPIRE_SECONDS
            else:
                expire_seconds = CACHE_NON_TRADING_HOURS
            
            if (now - cache_time).total_seconds() > expire_seconds:
                return None
            
            return data.get('data')
        except Exception:
            return None

    def set(self, key: str, data: Dict):
        """设置缓存"""
        cache_file = self._get_cache_key(key)
        try:
            cache_data = {
                'data': data,
                'cache_time': datetime.now().isoformat()
            }
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(cache_data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass


# ============================================================================
# 代码格式转换
# ============================================================================

class CodeConverter:
    """股票代码格式转换器"""

    @staticmethod
    def normalize(code: str) -> Tuple[str, str]:
        """
        标准化股票代码，返回 (标准化代码, 市场类型)
        
        支持格式：
        - A股：sh600000, sz000001, 600000, 000001
        - 港股：hk00700, 00700, 01810
        - 美股：usAAPL, AAPL, gb_aapl
        
        返回：
        - (标准化代码, 市场类型: 'A股'/'港股'/'美股')
        """
        code = code.strip().lower()
        
        # 已有前缀的情况
        if code.startswith('sh'):
            return f"sh{code[2:]}", 'A股'
        elif code.startswith('sz'):
            return f"sz{code[2:]}", 'A股'
        elif code.startswith('hk'):
            return f"hk{code[2:].zfill(5)}", '港股'  # 港股补齐5位
        elif code.startswith('us'):
            # usAAPL -> gb_aapl (新浪美股格式)
            symbol = code[2:].upper()
            return f"gb_{symbol.lower()}", '美股'
        elif code.startswith('gb_'):
            return code, '美股'
        
        # 无前缀的情况，需要判断市场
        if code.isdigit():
            # 纯数字代码
            if len(code) == 6:
                # 6位数字，A股
                if code.startswith(('60', '68')):
                    return f"sh{code}", 'A股'
                elif code.startswith(('00', '30')):
                    return f"sz{code}", 'A股'
            elif len(code) == 5:
                # 5位数字，港股
                return f"hk{code.zfill(5)}", '港股'
            elif len(code) <= 4:
                # 4位以内数字，可能是港股
                return f"hk{code.zfill(5)}", '港股'
        else:
            # 非数字，美股
            return f"gb_{code.lower()}", '美股'
        
        # 默认返回原代码
        return code, '未知'

    @staticmethod
    def to_sina_format(code: str) -> str:
        """转换为新浪 API 格式"""
        normalized, _ = CodeConverter.normalize(code)
        return normalized


# ============================================================================
# 数据源类
# ============================================================================

class DataSource:
    """数据源基类"""
    
    NAME = "base"
    
    @classmethod
    def fetch(cls, codes: List[str]) -> Dict[str, Dict]:
        """获取行情数据"""
        raise NotImplementedError


class SinaDataSource(DataSource):
    """新浪财经数据源"""
    
    NAME = "sina"
    BASE_URL = "https://hq.sinajs.cn/list="
    HEADERS = {
        'Referer': 'https://finance.sina.com.cn',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
    }
    
    @classmethod
    def fetch(cls, codes: List[str]) -> Dict[str, Dict]:
        """获取行情数据"""
        if not codes:
            return {}
        
        # 转换代码格式
        sina_codes = []
        code_mapping = {}  # 原始代码 -> 新浪代码
        
        for code in codes:
            normalized, market_type = CodeConverter.normalize(code)
            sina_codes.append(normalized)
            code_mapping[normalized] = code
        
        # 批量查询
        batch_size = 50
        results = {}
        
        for i in range(0, len(sina_codes), batch_size):
            batch = sina_codes[i:i + batch_size]
            codes_str = ','.join(batch)
            url = cls.BASE_URL + codes_str
            
            try:
                response = requests.get(url, headers=cls.HEADERS, timeout=REQUEST_TIMEOUT)
                response.encoding = 'gbk'
                
                if response.status_code == 200:
                    batch_results = cls._parse_response(response.text, code_mapping)
                    results.update(batch_results)
            except Exception as e:
                print(f"新浪数据源请求失败: {e}", file=sys.stderr)
            
            # 避免频率限制
            if i + batch_size < len(sina_codes):
                time.sleep(0.3)
        
        return results
    
    @classmethod
    def _parse_response(cls, response_text: str, code_mapping: Dict[str, str]) -> Dict[str, Dict]:
        """解析 API 响应"""
        results = {}
        
        for line in response_text.strip().split('\n'):
            if not line or '=' not in line:
                continue
            
            # 提取股票代码
            code_part = line.split('=')[0]
            # 对于美股 gb_xxx 格式，需要特殊处理
            # code_part = "var hq_str_gb_aapl" 或 "var hq_str_sh600000"
            if 'hq_str_' in code_part:
                sina_code = code_part.split('hq_str_')[-1]
            else:
                sina_code = code_part.split('_')[-1]
            
            original_code = code_mapping.get(sina_code, sina_code)
            
            # 提取数据
            data_part = line.split('"')[1] if '"' in line else ''
            if not data_part:
                continue
            
            fields = data_part.split(',')
            
            try:
                # 根据市场类型解析
                if sina_code.startswith('gb_'):
                    # 美股格式
                    # 字段：名称, 当前价, 涨跌幅, 时间, 涨跌额, 今开, 最高, 最低, 52周高, 52周低, 成交量, 成交额
                    if len(fields) >= 7:
                        data = {
                            'code': original_code,
                            'sina_code': sina_code,
                            'name': fields[0],
                            'current': float(fields[1]) if fields[1] else 0.0,
                            'change_percent': float(fields[2]) if fields[2] else 0.0,
                            'time': fields[3] if len(fields) > 3 else '',
                            'change_amount': float(fields[4]) if fields[4] else 0.0,
                            'open': float(fields[5]) if fields[5] else 0.0,
                            'high': float(fields[6]) if fields[6] else 0.0,
                            'low': float(fields[7]) if len(fields) > 7 and fields[7] else 0.0,
                            'volume': int(float(fields[10])) if len(fields) > 10 and fields[10] else 0,
                            'amount': float(fields[11]) if len(fields) > 11 and fields[11] else 0.0,
                            'last_close': float(fields[1]) - float(fields[4]) if fields[1] and fields[4] else 0.0,
                            'market': '美股',
                            'source': 'sina'
                        }
                        
                        if data['current'] > 0:
                            results[original_code] = data
                            
                elif sina_code.startswith('hk') and len(fields) >= 19:
                    # 港股格式（新浪港股数据格式不同于A股）
                    # 字段：英文名, 中文名, 今开, 昨收, 最高, 最低, 当前价, 涨跌额, 涨跌幅, 买价, 卖价, ...
                    # 实际格式: TENCENT,腾讯控股,546.500,550.000,552.000,542.500,550.500,0.500,0.091,550.00000,550.50000,...
                    data = {
                        'code': original_code,
                        'sina_code': sina_code,
                        'name': fields[1],  # 中文名
                        'open': float(fields[2]) if fields[2] else 0.0,  # 今开
                        'last_close': float(fields[3]) if fields[3] else 0.0,  # 昨收
                        'high': float(fields[4]) if fields[4] else 0.0,  # 最高
                        'low': float(fields[5]) if fields[5] else 0.0,  # 最低
                        'current': float(fields[6]) if fields[6] else 0.0,  # 当前价
                        'volume': int(float(fields[12])) if len(fields) > 12 and fields[12] else 0,  # 成交量
                        'amount': 0.0,  # 成交额港股暂无
                        'date': fields[17] if len(fields) > 17 else '',  # 日期
                        'time': fields[18] if len(fields) > 18 else '',  # 时间
                        'market': '港股',
                        'source': 'sina'
                    }
                    
                    # 涨跌额和涨跌幅（港股API直接返回这些值）
                    data['change_amount'] = float(fields[7]) if fields[7] else 0.0  # 涨跌额
                    data['change_percent'] = float(fields[8]) if fields[8] else 0.0  # 涨跌幅（已经是百分比）
                    
                    if data['current'] > 0:
                        results[original_code] = data
                    
                    if data['current'] > 0:
                        results[original_code] = data
                        
                elif len(fields) >= 32:
                    # A股格式
                    # 字段：名称, 今开, 昨收, 当前价, 最高, 最低, 竞买价, 竞卖价, 成交量, 成交额, ...
                    data = {
                        'code': original_code,
                        'sina_code': sina_code,
                        'name': fields[0],
                        'open': float(fields[1]) if fields[1] else 0.0,
                        'last_close': float(fields[2]) if fields[2] else 0.0,
                        'current': float(fields[3]) if fields[3] else 0.0,
                        'high': float(fields[4]) if fields[4] else 0.0,
                        'low': float(fields[5]) if fields[5] else 0.0,
                        'volume': int(float(fields[8])) if fields[8] else 0,
                        'amount': float(fields[9]) if fields[9] else 0.0,
                        'date': fields[30] if len(fields) > 30 else '',
                        'time': fields[31] if len(fields) > 31 else '',
                        'market': 'A股',
                        'source': 'sina'
                    }
                    
                    # 计算涨跌
                    if data['last_close'] > 0:
                        data['change_amount'] = round(data['current'] - data['last_close'], 3)
                        data['change_percent'] = round(
                            (data['current'] - data['last_close']) / data['last_close'] * 100, 2
                        )
                    else:
                        data['change_amount'] = 0.0
                        data['change_percent'] = 0.0
                    
                    if data['current'] > 0:
                        results[original_code] = data
                        
            except (ValueError, IndexError) as e:
                continue
        
        return results


class EastMoneyDataSource(DataSource):
    """东方财富数据源"""
    
    NAME = "eastmoney"
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://quote.eastmoney.com/'
    }
    
    @classmethod
    def fetch(cls, codes: List[str]) -> Dict[str, Dict]:
        """获取行情数据（东方财富）"""
        if not codes:
            return {}
        
        results = {}
        
        for code in codes:
            normalized, market_type = CodeConverter.normalize(code)
            
            # 东方财富只支持A股和部分港股
            if market_type == 'A股':
                secid = cls._get_secid(normalized)
                if secid:
                    data = cls._fetch_single(secid, code)
                    if data:
                        results[code] = data
        
        return results
    
    @classmethod
    def _get_secid(cls, code: str) -> Optional[str]:
        """获取东方财富 secid"""
        if code.startswith('sh'):
            return f"1.{code[2:]}"
        elif code.startswith('sz'):
            return f"0.{code[2:]}"
        return None
    
    @classmethod
    def _fetch_single(cls, secid: str, original_code: str) -> Optional[Dict]:
        """获取单只股票数据"""
        url = "https://push2.eastmoney.com/api/qt/stock/get"
        params = {
            'secid': secid,
            'fields': 'f43,f44,f45,f46,f47,f48,f50,f51,f52,f55,f57,f58,f60,f169,f170',
            'ut': 'fa5fd1943c7b386f172d01f5a8c5fe8a'
        }
        
        try:
            response = requests.get(url, params=params, headers=cls.HEADERS, timeout=REQUEST_TIMEOUT)
            if response.status_code == 200:
                data = response.json()
                if data and 'data' in data:
                    d = data['data']
                    # 解析数据
                    return {
                        'code': original_code,
                        'name': d.get('f58', ''),
                        'current': d.get('f43', 0) / 100 if d.get('f43') else 0,
                        'high': d.get('f44', 0) / 100 if d.get('f44') else 0,
                        'low': d.get('f45', 0) / 100 if d.get('f45') else 0,
                        'open': d.get('f46', 0) / 100 if d.get('f46') else 0,
                        'last_close': d.get('f60', 0) / 100 if d.get('f60') else 0,
                        'volume': d.get('f47', 0),
                        'amount': d.get('f48', 0),
                        'change_percent': d.get('f170', 0) / 100 if d.get('f170') else 0,
                        'change_amount': d.get('f169', 0) / 100 if d.get('f169') else 0,
                        'market': 'A股',
                        'source': 'eastmoney'
                    }
        except Exception as e:
            print(f"东方财富数据源请求失败: {e}", file=sys.stderr)
        
        return None


class TencentDataSource(DataSource):
    """腾讯财经数据源"""
    
    NAME = "tencent"
    BASE_URL = "https://qt.gtimg.cn/q="
    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://gu.qq.com/'
    }
    
    @classmethod
    def fetch(cls, codes: List[str]) -> Dict[str, Dict]:
        """获取行情数据（腾讯）"""
        if not codes:
            return {}
        
        results = {}
        
        # 转换代码格式
        tencent_codes = []
        code_mapping = {}
        
        for code in codes:
            tencent_code = cls._to_tencent_format(code)
            if tencent_code:
                tencent_codes.append(tencent_code)
                code_mapping[tencent_code] = code
        
        if not tencent_codes:
            return {}
        
        # 批量查询
        url = cls.BASE_URL + ','.join(tencent_codes[:50])
        
        try:
            response = requests.get(url, headers=cls.HEADERS, timeout=REQUEST_TIMEOUT)
            response.encoding = 'gbk'
            
            if response.status_code == 200:
                results = cls._parse_response(response.text, code_mapping)
        except Exception as e:
            print(f"腾讯数据源请求失败: {e}", file=sys.stderr)
        
        return results
    
    @classmethod
    def _to_tencent_format(cls, code: str) -> Optional[str]:
        """转换为腾讯代码格式"""
        normalized, market_type = CodeConverter.normalize(code)
        
        if market_type == 'A股':
            if normalized.startswith('sh'):
                return f"sh{normalized[2:]}"
            elif normalized.startswith('sz'):
                return f"sz{normalized[2:]}"
        elif market_type == '港股':
            return f"hk{normalized[2:]}"
        elif market_type == '美股':
            return f"us{normalized[3:].upper()}"
        
        return None
    
    @classmethod
    def _parse_response(cls, response_text: str, code_mapping: Dict[str, str]) -> Dict[str, Dict]:
        """解析 API 响应"""
        results = {}
        
        for line in response_text.strip().split('\n'):
            if not line or '=' not in line or '~' not in line:
                continue
            
            try:
                # 腾讯数据格式: v_hk00700="100~腾讯控股~00700~...
                # 提取代码部分
                eq_pos = line.find('=')
                code_part = line[:eq_pos]  # v_hk00700
                
                # 提取股票代码
                if '_' in code_part:
                    tencent_code = code_part.split('_')[-1]  # hk00700
                else:
                    tencent_code = code_part
                
                original_code = code_mapping.get(tencent_code, tencent_code)
                
                fields = line.split('~')
                if len(fields) < 35:
                    continue
                
                data = {
                    'code': original_code,
                    'name': fields[1],
                    'current': float(fields[3]) if fields[3] else 0.0,
                    'last_close': float(fields[4]) if fields[4] else 0.0,
                    'open': float(fields[5]) if fields[5] else 0.0,
                    'high': float(fields[33]) if len(fields) > 33 and fields[33] else 0.0,
                    'low': float(fields[34]) if len(fields) > 34 and fields[34] else 0.0,
                    'volume': int(float(fields[6])) if fields[6] else 0,
                    'amount': float(fields[37]) if len(fields) > 37 and fields[37] else 0.0,
                    'source': 'tencent'
                }
                
                # 判断市场
                if tencent_code.startswith('sh') or tencent_code.startswith('sz'):
                    data['market'] = 'A股'
                elif tencent_code.startswith('hk'):
                    data['market'] = '港股'
                elif tencent_code.startswith('us'):
                    data['market'] = '美股'
                
                # 计算涨跌
                if data['last_close'] > 0:
                    data['change_amount'] = round(data['current'] - data['last_close'], 3)
                    data['change_percent'] = round(
                        (data['current'] - data['last_close']) / data['last_close'] * 100, 2
                    )
                else:
                    data['change_amount'] = 0.0
                    data['change_percent'] = 0.0
                
                if data['current'] > 0:
                    results[original_code] = data
                    
            except (ValueError, IndexError):
                continue
        
        return results


# ============================================================================
# 主 API 类
# ============================================================================

class EnhancedStockAPI:
    """增强版股票 API"""
    
    # 数据源优先级：新浪 > 腾讯 > 东方财富
    DATA_SOURCES = [
        ('sina', SinaDataSource),
        ('tencent', TencentDataSource),
        ('eastmoney', EastMoneyDataSource),
    ]
    
    def __init__(self):
        self.cache = StockCache()
    
    def fetch_quotes(self, codes: List[str], use_cache: bool = True) -> Dict[str, Dict]:
        """
        获取股票行情
        
        Args:
            codes: 股票代码列表
            use_cache: 是否使用缓存
            
        Returns:
            股票行情字典
        """
        if not codes:
            return {}
        
        results = {}
        remaining_codes = []
        
        # 先检查缓存
        if use_cache:
            for code in codes:
                normalized, market_type = CodeConverter.normalize(code)
                cached = self.cache.get(f"quote_{normalized}", market_type)
                if cached:
                    results[code] = cached
                else:
                    remaining_codes.append(code)
        else:
            remaining_codes = codes.copy()
        
        # 如果全部命中缓存
        if not remaining_codes:
            return results
        
        # 按市场分组
        a_codes = []
        hk_codes = []
        us_codes = []
        
        for code in remaining_codes:
            _, market_type = CodeConverter.normalize(code)
            if market_type == 'A股':
                a_codes.append(code)
            elif market_type == '港股':
                hk_codes.append(code)
            elif market_type == '美股':
                us_codes.append(code)
            else:
                a_codes.append(code)  # 默认尝试 A 股
        
        # 依次尝试数据源
        for source_name, source_class in self.DATA_SOURCES:
            try:
                if source_name == 'eastmoney':
                    # 东方财富只支持 A 股
                    if a_codes:
                        fetched = source_class.fetch(a_codes)
                        results.update(fetched)
                        a_codes = [c for c in a_codes if c not in fetched]
                else:
                    # 其他数据源支持全部市场
                    codes_to_fetch = a_codes + hk_codes + us_codes
                    if codes_to_fetch:
                        fetched = source_class.fetch(codes_to_fetch)
                        results.update(fetched)
                        
                        # 更新剩余代码
                        a_codes = [c for c in a_codes if c not in fetched]
                        hk_codes = [c for c in hk_codes if c not in fetched]
                        us_codes = [c for c in us_codes if c not in fetched]
                
                # 如果全部获取成功，跳出循环
                if not a_codes and not hk_codes and not us_codes:
                    break
                    
            except Exception as e:
                print(f"数据源 {source_name} 失败: {e}", file=sys.stderr)
                continue
        
        # 缓存结果
        for code, data in results.items():
            normalized, market_type = CodeConverter.normalize(code)
            self.cache.set(f"quote_{normalized}", data)
        
        return results
    
    def get_trading_status(self, code: str) -> Dict:
        """获取交易状态"""
        _, market_type = CodeConverter.normalize(code)
        
        now = datetime.now()
        current_time = (now.hour, now.minute)
        
        status = {
            'market': market_type,
            'is_trading': False,
            'status': '已收盘',
            'next_open': None
        }
        
        if market_type == 'A股':
            if (9, 30) <= current_time <= (11, 30):
                status['is_trading'] = True
                status['status'] = '交易中'
            elif (13, 0) <= current_time <= (15, 0):
                status['is_trading'] = True
                status['status'] = '交易中'
            elif (9, 0) <= current_time < (9, 30):
                status['status'] = '盘前'
            elif (11, 30) < current_time < (13, 0):
                status['status'] = '午间休市'
            else:
                status['status'] = '已收盘'
                
        elif market_type == '港股':
            if (9, 30) <= current_time <= (12, 0):
                status['is_trading'] = True
                status['status'] = '交易中'
            elif (13, 0) <= current_time <= (16, 0):
                status['is_trading'] = True
                status['status'] = '交易中'
            elif (9, 0) <= current_time < (9, 30):
                status['status'] = '盘前'
            elif (12, 0) < current_time < (13, 0):
                status['status'] = '午间休市'
            else:
                status['status'] = '已收盘'
                
        elif market_type == '美股':
            # 美股交易时间（北京时间）
            # 夏令时：21:30 - 次日04:00
            # 冬令时：22:30 - 次日05:00
            hour = now.hour
            if hour >= 21 or hour < 4:
                status['is_trading'] = True
                status['status'] = '交易中'
            elif 16 <= hour < 21:
                status['status'] = '盘前'
            else:
                status['status'] = '已收盘'
        
        return status


# ============================================================================
# 显示函数
# ============================================================================

def format_number(num: float, decimal: int = 2) -> str:
    """格式化数字显示"""
    if abs(num) >= 100000000:
        return f"{num / 100000000:.{decimal}f}亿"
    elif abs(num) >= 10000:
        return f"{num / 10000:.{decimal}f}万"
    else:
        return f"{num:.{decimal}f}"


def colorize(text: str, color: str) -> str:
    """添加颜色"""
    colors = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'magenta': '\033[95m',
        'cyan': '\033[96m',
        'reset': '\033[0m'
    }

    if sys.stdout.isatty():
        return f"{colors.get(color, '')}{text}{colors['reset']}"
    return text


def display_quote_detail(quote: Dict, trading_status: Dict = None):
    """显示单只股票详情"""
    # 涨跌颜色
    if quote['change_percent'] > 0:
        change_color = 'red'
        change_icon = '📈'
    elif quote['change_percent'] < 0:
        change_color = 'green'
        change_icon = '📉'
    else:
        change_color = 'yellow'
        change_icon = '➖'

    print("\n" + "=" * 70)
    print(f"📊 {colorize(quote['name'], 'cyan')} ({quote['code']}) - {quote.get('market', '未知')}")
    
    # 交易状态
    if trading_status:
        status_color = 'green' if trading_status['is_trading'] else 'yellow'
        print(f"   市场状态: {colorize(trading_status['status'], status_color)}")
    
    print("=" * 70)

    # 价格信息
    print(f"\n💰 价格信息")
    print("-" * 70)
    
    current_price = f'{quote["current"]:.3f}' if quote['current'] < 100 else f'{quote["current"]:.2f}'
    print(f"  当前价: {colorize(current_price, 'blue')}")
    
    change_pct = f'{quote["change_percent"]:+.2f}%'
    change_amt = f'{quote["change_amount"]:+.3f}'
    print(f"  涨跌:   {change_icon} {colorize(change_pct, change_color)} "
          f"({colorize(change_amt, change_color)})")
    print(f"  今开:   {quote['open']:.3f}" if quote.get('open') else "  今开:   -")
    print(f"  昨收:   {quote['last_close']:.3f}" if quote.get('last_close') else "  昨收:   -")
    print(f"  最高:   {quote['high']:.3f}" if quote.get('high') else "  最高:   -")
    print(f"  最低:   {quote['low']:.3f}" if quote.get('low') else "  最低:   -")

    # 成交信息
    print(f"\n📈 成交信息")
    print("-" * 70)
    print(f"  成交量: {format_number(quote['volume'])}股" if quote.get('volume') else "  成交量: -")
    print(f"  成交额: {format_number(quote['amount'])}元" if quote.get('amount') else "  成交额: -")
    
    # 数据来源
    print(f"\n📡 数据来源: {quote.get('source', '未知')}")
    
    print("=" * 70)
    print(f"\n{DISCLAIMER}")


def display_quotes_table(quotes: List[Dict]):
    """以表格形式显示多只股票行情"""
    if not quotes:
        print("没有查询到有效数据")
        return

    print("\n" + "=" * 100)
    print(f"{'代码':<12}{'名称':<10}{'当前价':<12}{'涨跌幅':<12}{'涨跌额':<12}{'成交量':<14}{'成交额':<14}")
    print("=" * 100)

    for quote in quotes:
        if quote['change_percent'] > 0:
            color = 'red'
        elif quote['change_percent'] < 0:
            color = 'green'
        else:
            color = 'yellow'

        change_pct = colorize(f"{quote['change_percent']:+.2f}%", color)
        change_amt = colorize(f"{quote['change_amount']:+.3f}", color)

        name = quote['name'][:8] if len(quote.get('name', '')) > 8 else quote.get('name', '')
        
        print(f"{quote['code']:<12}"
              f"{name:<10}"
              f"{quote['current']:<12.3f}"
              f"{change_pct:<20}"
              f"{change_amt:<20}"
              f"{format_number(quote.get('volume', 0)):<14}"
              f"{format_number(quote.get('amount', 0)):<14}")

    print("=" * 100)


# ============================================================================
# 主函数
# ============================================================================

def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description='股票实时行情查询工具 v2.0',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f'''
示例:
  # 查询单只股票
  python {__file__} sh600000

  # 查询多只股票
  python {__file__} sh600000 sz000001 hk00700 gb_aapl

  # 从文件批量查询
  python {__file__} --file stocks.txt

  # 不使用缓存
  python {__file__} sh600000 --no-cache

股票代码格式:
  A股: sh600000 或 600000 (上交所)
       sz000001 或 000001 (深交所)
  港股: hk00700 或 00700 (腾讯控股)
  美股: usAAPL 或 AAPL 或 gb_aapl (苹果)

数据源:
  1. 新浪财经 (主力)
  2. 腾讯财经 (备用)
  3. 东方财富 (A股备用)

{DISCLAIMER}
        '''
    )

    parser.add_argument('codes', nargs='*', help='股票代码列表')
    parser.add_argument('-f', '--file', help='从文件读取股票代码')
    parser.add_argument('-t', '--table', action='store_true', help='以表格形式显示')
    parser.add_argument('--no-cache', action='store_true', help='不使用缓存')

    args = parser.parse_args()

    # 收集股票代码
    codes = []

    if args.file:
        try:
            with open(args.file, 'r', encoding='utf-8') as f:
                codes.extend([line.strip() for line in f if line.strip()])
        except FileNotFoundError:
            print(f"错误: 文件 {args.file} 不存在", file=sys.stderr)
            sys.exit(1)

    if args.codes:
        codes.extend(args.codes)

    if not codes:
        parser.print_help()
        sys.exit(1)

    # 去重
    codes = list(dict.fromkeys(codes))

    print(f"正在查询 {len(codes)} 只股票...")
    use_cache = not args.no_cache

    # 查询行情
    api = EnhancedStockAPI()
    quotes = api.fetch_quotes(codes, use_cache)

    if not quotes:
        print("\n❌ 未查询到任何有效数据")
        print("\n可能的原因：")
        print("  1. 股票代码格式错误")
        print("  2. 当前非交易时段，部分数据源可能不返回数据")
        print("  3. 网络连接问题")
        print("\n建议：")
        print("  - 检查股票代码格式是否正确")
        print("  - 尝试使用 --no-cache 参数重新查询")
        print("  - 稍后重试")
        sys.exit(1)

    # 按原始顺序排序
    quote_list = [quotes[code] for code in codes if code in quotes]

    # 显示结果
    if args.table or len(quote_list) > 1:
        display_quotes_table(quote_list)
    else:
        quote = quote_list[0]
        trading_status = api.get_trading_status(quote['code'])
        display_quote_detail(quote, trading_status)

    # 显示无效代码
    missing_codes = [code for code in codes if code not in quotes]
    if missing_codes:
        print(f"\n⚠️ 以下股票代码无效或无数据: {', '.join(missing_codes)}")
        print("\n代码格式提示：")
        print("  - A股: sh600000, sz000001, 或纯数字 600000")
        print("  - 港股: hk00700 或纯数字 00700")
        print("  - 美股: usAAPL, AAPL, 或 gb_aapl")


if __name__ == '__main__':
    main()