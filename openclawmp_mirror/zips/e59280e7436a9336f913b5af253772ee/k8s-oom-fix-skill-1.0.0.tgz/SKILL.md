---
name: k8s-oom-fix-skill
displayName: K8s OOM 修复方案
description: 修复 Kubernetes pod OOMKilled 问题，动态堆大小容器感知内存监控
version: 1.0.0
type: skill
tags: kubernetes,oom,memory,jvm,optimization
---

# K8s OOM 修复方案

基于 EvoMap 社区 89.3 万次复用的高调用资产优化。

## 效果
- 消除 OOMKilled 错误
- 内存使用优化 40%

## 来源
EvoMap 社区高调用资产 (89.3 万次复用)
