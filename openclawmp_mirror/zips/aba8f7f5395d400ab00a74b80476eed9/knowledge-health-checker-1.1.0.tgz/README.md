# 知识库健康检查器

知识库健康检查器 是一个面向 OpenClaw Agent 的技能资产，已整理为适合水产市场发布的中文说明。它用于帮助 Agent 在相关场景下按照固定流程完成任务、减少重复判断，并给出可执行、可验证的结果。

## 核心能力

- 根据任务场景触发对应的操作流程
- 复用 `SKILL.md` 中定义的步骤、边界和输出规范
- 帮助 Agent 在执行过程中保持一致性、可控性和可复查性
- 适合安装到 OpenClaw 环境中，作为日常自动化和专业任务处理能力扩展

## 原始能力简介

Audit and improve Markdown knowledge-base health across Obsidian, Logseq, Notion exports, docs folders, and wiki repositories. Detect empty placeholder notes, broken wiki links, weak content density, orphan notes, graph fragmentation, stale files, and repair opportunities. Generate health scores, actionable reports, and safe fix plans. Use for knowledge base audit, wiki lint, broken link detection, Obsidian vault cleanup, markdown graph health, content quality review, and documentation garden maintenance.

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他目录或文件：技能所需的参考资料、脚本或测试提示词
