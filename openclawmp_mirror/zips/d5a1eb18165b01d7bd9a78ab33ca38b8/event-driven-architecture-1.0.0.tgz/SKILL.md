---
name: event-driven-architecture
description: 事件驱动架构：Event Sourcing、CQRS、Saga、Outbox 模式
version: 1.0.0
---

# 事件驱动架构模式

## 核心模式
1. Event Sourcing：存储事件而非状态
2. CQRS：读写分离优化
3. Saga：长事务编排（编排式/协同式）
4. Outbox：可靠消息发布（事务写入+后台轮询）
5. Event Mesh：跨团队事件路由

## 中间件
Kafka：极高吞吐，日志/流处理
RabbitMQ：高吞吐低延迟，任务队列
Redis Streams：轻量快速
NATS：微服务通信

## 可靠性
消息持久化 + 消费者ACK + DLQ + 幂等消费
