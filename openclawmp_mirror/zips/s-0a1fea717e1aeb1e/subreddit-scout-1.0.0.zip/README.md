# Subreddit Scout

Use this skill when launching a product via Reddit.

## Steps
1. Identify niche keywords and adjacent problem keywords.
2. Collect 15-30 candidate subreddits.
3. Summarize each subreddit rule/profile:
   - self-promo policy
   - preferred content style
   - allowed post frequency
4. Rank by fit score (audience match + promo tolerance + activity).
5. Output top 5 with tailored post angles.