---
name: maxwell-act-automation
description: Maxwell ACT自动化脚本助手 | 编写ANSYS Maxwell Python ACT脚本，实现参数化建模、自动仿真、数据提取。需安装pyedb或ANSYS Python API。
---

# Maxwell ACT 自动化脚本助手

通过 ANSYS ACT（Automation & Customization Toolkit）和 Python API（pyedb）实现 Maxwell 有限元仿真的参数化、自动化。

## 适用场景

- 参数化仿真（扫参分析）
- 批量建模（不同规格电机）
- 自动提取仿真结果
- 与优化算法集成（遗传算法、梯度下降）
- 自动化仿真报告生成

## 前置要求

```bash
# 安装 ANSYS Python API
pip install pyedb

# 或使用 IronPython（Maxwell 内置）
# 位置：C:\Program Files\ANSYS\2024\v241\IronPython\ipy.exe

# 环境变量（PowerShell）
$env:ANSYSEM_ROOT241 = "C:\Program Files\ANSYS\2024\v241\commonfiles\CPython\3.11\win64"
```

## pyedb 基本用法

### 1. 启动 Maxwell 项目

```python
from pyedb import Maxwell2D

# 启动 Maxwell（后台运行）
maxwell = Maxwell2D(
    projectname="PMSM_Simulation",
    designname="8Pole36Slot",
    version="2024.1",
    specified_version=True,
    non_graphical=False,  # True 则无界面
    close_project_after=True
)

# 或连接已有项目
# maxwell = Maxwell2D("C:/path/to/project.aedt")
```

### 2. 创建几何

```python
# 创建矩形（定子外圆用多边形近似）
rect = maxwell.modeler.create_rectangle(
    position=["0mm", "0mm"],
    dimensions_list=["90mm", "90mm"],
    num_segments=64,  # 近似圆
    name="Stator_Outer"
)

# 创建圆（气隙）
circle = maxwell.modeler.create_circle(
    center_position=["0mm", "0mm"],
    radius="26.5mm",
    num_segments=64,
    name="AirGap"
)

# 布尔运算
maxwell.modeler.subtract("Stator_Outer", "AirGap", keep_originals=False)
```

### 3. 设置材料

```python
# 添加新材料
mat = maxwell.materials.add_material("MySteel")
mat.conductivity = 2.0e6  # S/m
mat.permeability = 500    # 相对磁导率

# 设置 BH 曲线（非线性材料）
mat.add_bh_curve(
    [0, 0.5, 1.0, 1.5, 1.8, 2.0],
    [0, 100, 250, 500, 1200, 3500],
    is_h_curve=False
)

# 赋材料给物体
maxwell.assign_material("Stator", "35YT310")
maxwell.assign_material("Rotor", "35YT310")
maxwell.assign_material("Magnet", "N42SH")
```

### 4. 设置边界条件和激励

```python
# 气球边界（默认自动设置）
# 不需要手动设置，Maxwell 会自动添加

# 永磁体充磁方向
maxwell.assign_magnetization_direction(
    "Magnet_1",
    magnetization_direction=[0, 1],  # Y方向（径向）
    is_positive=True
)

# 绕组激励（瞬态场）
maxwell.assign_current(
    "Coil",
    current_repeat="2A",
    is_solid=True
)

# 转速设置
maxwell.assign_rotor_motion(
    orientation_axis=[0, 0, 1],
    angular_velocity=3000,  # rpm
    is_positive=True
)
```

### 5. 网格控制

```python
# 手动加密气隙网格
maxwell.mesh.assign_mesh_length(
    "AirGap",
    maximum_length="0.08mm",
    mesh_method="LengthBased"
)

# 在区域内加密
maxwell.mesh.assign_mesh_length(
    "Magnet",
    maximum_length="0.15mm",
    mesh_method="LengthBased"
)
```

### 6. 求解设置

```python
# 静磁场求解
maxwell.solve(
    setup_name="MySetup",
   孔径=False,
    print_progress=True
)

# 或创建求解设置
setup = maxwell.create_setup("StaticSetup")
setup.pct_refinement = 5
setup.max_passes = 10
setup.convergence = 0.001
```

### 7. 参数化扫描

```python
# 定义参数
maxwell.parameters.add_parameter("hm", expression="3mm")
maxwell.parameters.add_parameter("current", expression="5A")

# 创建优化分析
optimization = maxwell.create_optimization_analysis("Sweep_hm")
optimization.add_variabled_parameter("hm")
optimization.range_min = "2mm"
optimization.range_max = "5mm"
optimization.range_step = "0.5mm"

# 求解
maxwell.analyze_all()
```

### 8. 提取结果

```python
# 提取气隙磁密（路径）
maxwell.results.get_field_data(
    "Setup1:Solution1",
    "MagneticField",
    plot_name="B_Vector"
)

# 提取力矩
torque_data = maxwell.results.get_solution_data(
    "Setup1:Solution1",
    "Torque",
    expressions=["Torque(Total)"],
    is时间的=True
)
print(torque_data)

# 导出数据到 CSV
maxwell.results.export_results_to_csv(
    output_file="torque_data.csv",
    solution_name="Setup1:Solution1",
    expressions=["Torque(Total)", "Speed"]
)
```

## ACT 脚本模板

### 完整示例：8极36槽 PMSM 参数化建模

```python
#!/usr/bin/env python3
"""
Maxwell 2D PMSM 参数化建模脚本
创建 8极36槽 表贴式 PMSM 模型

依赖：pip install pyedb
"""

from pyedb import Maxwell2D
import math
import os

def create_pmsm_model(
    Dso=90, Dsi=54, Dri=52.5, L=50, air_gap=0.5,
    poles=8, slots=36, Ns=28, a=2,
    magnet_grade="N42SH", steel="35YT310",
    output_path=None
):
    """创建 PMSM 模型"""

    # 启动 Maxwell
    m2d = Maxwell2D(
        projectname="PMSM_Auto",
        designname=f"{poles}P_{slots}S",
        version="2024.1",
        non_graphical=True
    )

    # 设置单位
    m2d.modeler.model_units = "mm"

    # ========== 几何建模 ==========
    # 定子外圆
    m2d.modeler.create_circle("Stator_Outer", radius=Dso/2)
    # 定子内圆（挖去）
    m2d.modeler.create_circle("Stator_Inner", radius=Dsi/2)
    m2d.modeler.subtract("Stator_Outer", "Stator_Inner")

    # 创建槽（36个）
    tooth_width = math.pi * Dsi / slots * 0.45
    slot_radius = math.pi * Dsi / slots * 0.55
    for i in range(slots):
        angle = i * 360 / slots
        m2d.modeler.create_circle(
            f"Slot_{i}",
            radius=slot_radius,
            position=[f"{Dsi/2}mm", "0mm"],
            axis="Z"
        )
        # 这里简化了，实际需用参数化复制

    # 转子
    m2d.modeler.create_circle("Rotor_Outer", radius=Dri/2)
    m2d.modeler.create_circle("Rotor_Inner", radius=16/2)

    # 气隙
    m2d.modeler.create_circle("AirGap", radius=(Dsi-air_gap)/2)

    # 永磁体（8个）
    pole_arc = math.pi * Dri / poles * 0.8  # 极弧
    for i in range(poles):
        angle = i * 360 / poles
        m2d.modeler.create_rectangle(
            f"Magnet_{i}",
            position=[f"{Dri/2-3}mm", "0mm"],
            dimensions_list=[f"{3}mm", f"{pole_arc}mm"],
            rotation=f"{angle}deg"
        )

    # ========== 材料 ==========
    m2d.materials.add_material("35YT310")
    m2d.materials.add_material("N42SH")

    # ========== 赋值 ==========
    m2d.assign_material("Stator", steel)
    m2d.assign_material("Rotor", steel)
    m2d.assign_material("AirGap", "vacuum")

    # 永磁体充磁方向
    for i in range(poles):
        direction = 1 if i % 2 == 0 else -1
        m2d.assign_magnetization(f"Magnet_{i}", direction=direction)

    # ========== 边界 ==========
    # 气球边界（自动）

    # ========== 求解设置 ==========
    setup = m2d.create_setup("StaticSetup")
    setup.pct_refinement = 5
    setup.max_passes = 10

    # 求解
    m2d.analyze()

    # ========== 提取结果 ==========
    # 气隙磁密
    Bg = m2d.results.get_field_data("StaticSetup", "MagneticFluxDensity")

    # 保存
    if output_path:
        m2d.save_project(output_path)

    m2d.close_project()
    return {"Bg": Bg}


if __name__ == "__main__":
    result = create_pmsm_model(output_path="C:/temp/PMSM_auto.aedt")
    print(f"气隙磁密: {result['Bg']}")
```

## 常见问题排查

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| pyedb 连接失败 | ANSYS 版本不匹配 | 指定正确的 version 参数 |
| 建模报错 | 几何重叠 | 用 `modeler.cleanup_objects()` 清理 |
| 求解发散 | 网格太粗/边界错误 | 加密气隙网格，检查 Balloon |
| 提取数据为空 | 表达式名称错误 | 在 Maxwell GUI 确认字段名称 |
| ACT 脚本卡住 | 非图形模式死锁 | 设置 `non_graphical=False` 调试 |

## 资源

- ANSYS ACT API 文档：`C:\Program Files\ANSYS\v241\act_api\docs`
- pyedb 文档：https://edb(pyedb).readthedocs.io
