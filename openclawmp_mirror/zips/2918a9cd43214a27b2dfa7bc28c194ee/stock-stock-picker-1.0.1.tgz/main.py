#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
智能选股工具
多因子股票筛选策略
"""

import pandas as pd
import akshare as ak


class StockPicker:
    """智能选股器"""
    
    def __init__(self):
        """初始化选股器"""
        pass
    
    def get_stock_basics(self):
        """获取股票基本信息"""
        try:
            df = ak.stock_zh_a_spot_em()
            return df
        except Exception as e:
            print(f"获取股票基本信息失败: {e}")
            return None
    
    def multi_factor_pick(self, pe_max=None, mv_max=None, roe_min=None, pb_max=None):
        """
        多因子选股
        
        Args:
            pe_max: 最高市盈率
            mv_max: 最大流通市值（亿）
            roe_min: 最低ROE
            pb_max: 最高市净率
            
        Returns:
            DataFrame: 筛选结果
        """
        df = self.get_stock_basics()
        if df is None:
            return None
        
        try:
            filtered = df.copy()
            
            # 过滤ST股票
            if '名称' in filtered.columns:
                filtered = filtered[~filtered['名称'].str.contains('ST', na=False)]
            
            # 市盈率筛选
            if pe_max is not None and '市盈率-动态' in filtered.columns:
                filtered = filtered[filtered['市盈率-动态'] > 0]  # 排除亏损
                filtered = filtered[filtered['市盈率-动态'] <= pe_max]
            
            # 市值筛选（转换为亿）
            if mv_max is not None and '流通市值' in filtered.columns:
                filtered['流通市值_亿'] = filtered['流通市值'] / 100000000
                filtered = filtered[filtered['流通市值_亿'] <= mv_max]
            
            # 选择输出列
            columns = ['代码', '名称', '最新价', '涨跌幅', '市盈率-动态', '市净率', '流通市值', '所属行业']
            available_cols = [c for c in columns if c in filtered.columns]
            
            return filtered[available_cols].sort_values('涨跌幅', ascending=False)
            
        except Exception as e:
            print(f"多因子选股失败: {e}")
            return None
    
    def breakout_stocks(self, days=50):
        """
        破新高股票
        
        Args:
            days: 多少天内的新高
            
        Returns:
            DataFrame: 破新高股票
        """
        df = self.get_stock_basics()
        if df is None:
            return None
        
        try:
            # 获取当前价格接近N日新高的股票
            # 这里简化处理，实际应该获取历史数据计算
            result = df[df['涨跌幅'] > 5].copy()  # 大涨的股票
            
            columns = ['代码', '名称', '最新价', '涨跌幅', '换手率', '所属行业']
            available_cols = [c for c in columns if c in result.columns]
            
            return result[available_cols].head(20)
        except Exception as e:
            print(f"破新高筛选失败: {e}")
            return None
    
    def zt_stocks(self, days=1):
        """
        涨停股票
        
        Args:
            days: 几天内的涨停
            
        Returns:
            DataFrame: 涨停股票
        """
        df = self.get_stock_basics()
        if df is None:
            return None
        
        try:
            # 筛选涨停股票（涨幅 >= 9.5%）
            zt = df[df['涨跌幅'] >= 9.5].copy()
            
            columns = ['代码', '名称', '最新价', '涨跌幅', '换手率', '成交额', '所属行业']
            available_cols = [c for c in columns if c in zt.columns]
            
            return zt[available_cols].sort_values('涨跌幅', ascending=False)
        except Exception as e:
            print(f"涨停筛选失败: {e}")
            return None
    
    def holder_decrease(self, quarters=2):
        """
        股东数减少股票
        
        Args:
            quarters: 连续减少的季度数
            
        Returns:
            DataFrame: 股东数减少的股票
        """
        try:
            # 获取股东户数数据
            df = ak.stock_gdfx_free_holding_statistics_em()
            
            if df is not None and not df.empty:
                columns = ['股票代码', '股票简称', '股东户数', '户数变动比例', '较上期变动']
                available_cols = [c for c in columns if c in df.columns]
                return df[available_cols].head(30)
        except Exception as e:
            print(f"股东数筛选失败: {e}")
        return None
    
    def fund_holding(self, ratio_min=5):
        """
        基金重仓股
        
        Args:
            ratio_min: 最低基金持股比例
            
        Returns:
            DataFrame: 基金重仓股
        """
        try:
            # 获取基金重仓股数据
            df = ak.stock_report_fund_hold(symbol="基金持仓", date="20241231")
            
            if df is not None and not df.empty:
                # 按持仓比例排序
                if '占流通股比例' in df.columns:
                    df = df.sort_values('占流通股比例', ascending=False)
                
                columns = ['股票代码', '股票简称', '持仓市值', '占流通股比例', '基金家数']
                available_cols = [c for c in columns if c in df.columns]
                return df[available_cols].head(30)
        except Exception as e:
            print(f"基金重仓筛选失败: {e}")
        return None


def main():
    """CLI 入口"""
    import fire
    
    picker = StockPicker()
    
    def pick(pe_max=None, mv_max=None, roe_min=None, pb_max=None):
        """多因子选股"""
        result = picker.multi_factor_pick(pe_max, mv_max, roe_min, pb_max)
        if result is not None:
            print(result.to_string(index=False))
            print(f"\n共 {len(result)} 只符合条件的股票")
        else:
            print("选股失败")
    
    def breakout(days=50):
        """破新高股票"""
        result = picker.breakout_stocks(days)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("筛选失败")
    
    def zt(days=1):
        """涨停股票"""
        result = picker.zt_stocks(days)
        if result is not None:
            print(result.to_string(index=False))
            print(f"\n共 {len(result)} 只涨停股票")
        else:
            print("筛选失败")
    
    def holder_decrease(quarters=2):
        """股东数减少"""
        result = picker.holder_decrease(quarters)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("筛选失败")
    
    def fund_holding(ratio_min=5):
        """基金重仓"""
        result = picker.fund_holding(ratio_min)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("筛选失败")
    
    fire.Fire({
        "pick": pick,
        "breakout": breakout,
        "zt": zt,
        "holder-decrease": holder_decrease,
        "fund-holding": fund_holding,
    })


if __name__ == "__main__":
    main()
