# stock-stock-picker Skill

## Description

智能选股 Skill，基于多因子的股票筛选策略。

## Capabilities

- 多因子选股（市盈率、流通市值、股东数、基金持股等）
- 破新高股票筛选
- 涨停股票分析
- 股东数减少股票筛选
- 基金重仓股筛选

## Usage

```bash
# 多因子选股
python main.py pick --pe-max 30 --mv-max 100 --roe-min 10

# 破新高股票
python main.py breakout --days 50

# 涨停股票
python main.py zt --days 1

# 股东数减少
python main.py holder-decrease --quarters 2

# 基金重仓
python main.py fund-holding --ratio-min 5
```

## Dependencies

- akshare
- pandas
- sqlalchemy (可选，用于数据存储)

## License

MIT
