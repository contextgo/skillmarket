# 飞书语音发送技能包

> 🎤 一键发送飞书语音消息，支持 TTS 自动生成和完整语音链路

## 技能清单

| 技能 | 描述 | 状态 |
|------|------|------|
| **feishu-voice-send** | 飞书语音消息发送 | ✅ 核心技能 |
| **tts-asr** | MiniMax TTS 文字转语音 | ✅ 依赖技能 |
| **feishu-audio-file** | 飞书音频文件发送（备选方案） | ✅ 新增 |

## 安装方式

```bash
# 通过 EasyClaw 技能市场安装
easyclaw skill install feishu-voice-send
```

或手动复制到 `~/.easyclaw/skills/feishu-voice-send`

## 前置要求

1. ✅ EasyClaw 飞书插件已配置
2. ✅ 飞书开放平台应用权限：
   - `im:message`（消息发送）
   - `im:resource`（资源上传）⭐ **语音气泡必需**
3. ✅ Python 3.8+ 和 requests 库

## 快速开始

### 方式 1：发送现有音频文件

```bash
python scripts/send_voice.py --audio-file reply.mp3 --chat-id ou_xxx
```

### 方式 2：完整语音链路（TTS → 飞书语音）

```bash
# 1. 生成语音
python ~/.easyclaw/skills/tts-asr/scripts/generate_minimax_audio.py \
  --text "你好，这是语音测试" \
  --output reply.mp3

# 2. 发送语音
python scripts/send_voice.py --audio-file reply.mp3 --chat-id ou_xxx
```

### 方式 3：音频文件发送（备选方案）

如果缺少 `im:resource` 权限，使用音频文件方式：

```bash
python scripts/send_audio_file.py --audio-file reply.mp3 --chat-id ou_xxx
```

## 权限配置

### 飞书开放平台设置

1. 登录 [飞书开放平台](https://open.feishu.cn/)
2. 找到你的应用
3. 添加权限：
   - ✅ `im:message` - 发送消息
   - ✅ `im:resource` - 上传资源（语音气泡必需）
4. 重新发布应用
5. 重新授权机器人

### 权限验证

运行权限测试脚本：

```bash
python scripts/test_permissions.py
```

## 文件结构

```
feishu-voice-send/
├── SKILL.md                 # 技能说明
├── README.md                # 使用文档
├── scripts/
│   ├── send_voice.py        # 语音发送主脚本
│   ├── send_audio_file.py   # 音频文件发送（备选）
│   ├── test_permissions.py  # 权限测试
│   └── test_upload.py       # 上传测试
├── demo/
│   └── voice_bot_demo.py    # 语音机器人示例
└── examples/
    └── voice_chain.py       # 完整语音链路示例
```

## 常见问题

### Q: 发送失败，错误 234001
**A:** 缺少 `im:resource` 权限，需要在飞书开放平台配置。

### Q: 语音气泡 vs 音频文件
**A:** 
- 语音气泡 🎤：需要 `im:resource` 权限，UI 更好
- 音频文件 📎：无需特殊权限，功能相同，UI 是文件卡片

### Q: 支持哪些音频格式
**A:** MP3、WAV、M4A、AAC、AMR（推荐 AMR，文件更小）

## 技术支持

- 技能市场：[水产市场](https://easyclaw.cn/skills)
- 文档：[EasyClaw 文档](https://docs.openclaw.ai)
- 反馈：GitHub Issues

## 更新日志

### v1.1.0 (2026-03-27)
- ✅ 添加权限测试脚本
- ✅ 添加音频文件备选方案
- ✅ 完善文档和示例
- ✅ 优化错误处理

### v1.0.0 (2026-03-26)
- ✅ 初始版本发布
