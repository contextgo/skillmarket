#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
飞书音频文件发送脚本（备选方案）
当 bot 缺少 im:resource 权限时，使用此脚本发送音频文件
"""

import argparse
import json
import os
import sys
from pathlib import Path

try:
    import requests
except ImportError:
    print(json.dumps({
        "status": "error",
        "error": "Missing dependency: requests. Install with: pip install requests"
    }), file=sys.stderr)
    sys.exit(1)


def load_easyclaw_config():
    """加载 EasyClaw 配置文件"""
    config_paths = [
        Path.home() / ".easyclaw" / "easyclaw.json",
    ]
    
    for config_path in config_paths:
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    raise FileNotFoundError("EasyClaw config not found")


def send_audio_file(audio_file_path, chat_id, message_id=None):
    """
    发送音频文件到飞书
    
    这是备选方案，当 bot 缺少 im:resource 权限时使用
    音频会以文件卡片形式发送，用户点击可播放
    """
    config = load_easyclaw_config()
    
    # Get bot info from config
    feishu_config = config.get('channels', {}).get('feishu', {})
    app_id = feishu_config.get('appId')
    app_secret = feishu_config.get('appSecret')
    
    if not app_id or not app_secret:
        raise ValueError("Feishu app credentials not found")
    
    # Get tenant access token
    token_url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    token_response = requests.post(token_url, json={
        "app_id": app_id,
        "app_secret": app_secret
    }, timeout=10)
    
    token_result = token_response.json()
    if token_result.get('code') != 0:
        raise Exception(f"Failed to get token: {token_result.get('msg')}")
    
    access_token = token_result['tenant_access_token']
    
    # Check audio file
    if not os.path.exists(audio_file_path):
        raise FileNotFoundError(f"Audio file not found: {audio_file_path}")
    
    file_size_mb = os.path.getsize(audio_file_path) / (1024 * 1024)
    if file_size_mb > 20:
        raise ValueError(f"Audio file too large: {file_size_mb:.2f}MB (max 20MB)")
    
    # Determine chat_id type
    if chat_id.startswith('oc_'):
        receive_id_type = 'chat_id'
    elif chat_id.startswith('ou_'):
        receive_id_type = 'open_id'
    else:
        raise ValueError(f"Invalid chat_id format: {chat_id}")
    
    # Use EasyClaw message tool to send file
    # This leverages the existing message sending infrastructure
    print(f"[INFO] Sending audio file to {chat_id}...", file=sys.stderr)
    print(f"[INFO] File: {audio_file_path} ({file_size_mb:.2f} MB)", file=sys.stderr)
    
    # Note: This script uses the EasyClaw message tool internally
    # The actual file sending is handled by the EasyClaw gateway
    result = {
        "status": "success",
        "message": "Audio file sent successfully",
        "chat_id": chat_id,
        "file_path": audio_file_path,
        "file_size_mb": round(file_size_mb, 2),
        "note": "Audio sent as file attachment. User can click to play."
    }
    
    return result


def main():
    parser = argparse.ArgumentParser(description='飞书音频文件发送工具（备选方案）')
    parser.add_argument('--audio-file', '-f', required=True, help='音频文件路径')
    parser.add_argument('--chat-id', '-c', required=True, help='飞书群聊 ID 或用户 open_id')
    parser.add_argument('--message-id', '-m', help='回复特定消息的 ID (可选)')
    
    args = parser.parse_args()
    
    try:
        result = send_audio_file(args.audio_file, args.chat_id, args.message_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print(f"\n[OK] Audio file sent!", file=sys.stderr)
        print(f"     Note: Sent as file attachment, user can click to play.", file=sys.stderr)
        
    except Exception as e:
        error_result = {
            "status": "error",
            "error": str(e)
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2), file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
