#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
飞书语音消息发送脚本
将音频文件以语音消息形式发送到飞书群聊或私聊
"""

import argparse
import json
import os
import sys
import base64
from pathlib import Path
from datetime import datetime

# 尝试导入 requests
try:
    import requests
except ImportError:
    print(json.dumps({
        "status": "error",
        "error": "Missing dependency: requests. Install with: pip install requests"
    }), file=sys.stderr)
    sys.exit(1)


def load_easyclaw_config():
    """加载 EasyClaw 配置文件"""
    config_paths = [
        Path.home() / ".easyclaw" / "easyclaw.json",
        Path(os.environ.get("EASYCLAW_HOME", "~/.easyclaw")).expanduser() / "easyclaw.json",
    ]
    
    for config_path in config_paths:
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    raise FileNotFoundError("EasyClaw config not found. Please ensure you're logged in to EasyClaw.")


def get_feishu_app_ticket(config):
    """获取飞书应用凭证"""
    feishu_config = config.get('channels', {}).get('feishu', {})
    app_id = feishu_config.get('appId')
    app_secret = feishu_config.get('appSecret')
    
    if not app_id or not app_secret:
        raise ValueError("Feishu app credentials not found in EasyClaw config")
    
    return app_id, app_secret


def get_feishu_tenant_access_token(app_id, app_secret):
    """获取飞书租户 access_token"""
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    
    payload = {
        "app_id": app_id,
        "app_secret": app_secret
    }
    
    response = requests.post(url, json=payload, timeout=10)
    result = response.json()
    
    if result.get('code') != 0:
        raise Exception(f"Failed to get tenant access token: {result.get('msg')}")
    
    return result['tenant_access_token']


def upload_voice_file(access_token, audio_file_path):
    """上传语音文件到飞书"""
    url = "https://open.feishu.cn/open-apis/im/v1/files"
    
    headers = {
        "Authorization": f"Bearer {access_token}"
    }
    
    # 确定文件类型
    file_ext = Path(audio_file_path).suffix.lower()
    mime_type_map = {
        '.mp3': 'audio/mpeg',
        '.wav': 'audio/wav',
        '.m4a': 'audio/mp4',
        '.aac': 'audio/aac',
        '.wma': 'audio/x-ms-wma',
        '.ogg': 'audio/ogg',
    }
    
    file_type = "audio"
    mime_type = mime_type_map.get(file_ext, 'audio/mpeg')
    
    with open(audio_file_path, 'rb') as f:
        file_data = f.read()
    
    # 飞书上传接口要求 multipart/form-data
    files = {
        'file': (os.path.basename(audio_file_path), file_data, mime_type)
    }
    
    data = {
        'file_type': file_type
    }
    
    response = requests.post(url, headers=headers, files=data, timeout=30)
    result = response.json()
    
    if result.get('code') != 0:
        raise Exception(f"Failed to upload voice file: {result.get('msg')}")
    
    return result['data']


def send_voice_message(access_token, chat_id, file_key, text="", reply_to_message_id=None):
    """发送语音消息到飞书"""
    url = "https://open.feishu.cn/open-apis/im/v1/messages"
    
    headers = {
        "Authorization": f"Bearer {access_token}",
        "Content-Type": "application/json"
    }
    
    # 判断 chat_id 类型
    if chat_id.startswith('oc_'):
        receive_id_type = 'chat_id'
    elif chat_id.startswith('ou_'):
        receive_id_type = 'open_id'
    else:
        raise ValueError(f"Invalid chat_id format: {chat_id}. Should start with 'oc_' or 'ou_'")
    
    # 构建语音消息内容
    # 飞书语音消息格式：{"file_key":"xxx","duration":123}
    voice_content = {
        "file_key": file_key
    }
    
    payload = {
        "receive_id": chat_id,
        "msg_type": "audio",
        "content": json.dumps(voice_content)
    }
    
    # 添加回复消息 ID（如果有）
    if reply_to_message_id:
        payload["reply_id"] = reply_to_message_id
    
    # 确定正确的 API 端点
    params = {"receive_id_type": receive_id_type}
    
    response = requests.post(url, headers=headers, params=params, json=payload, timeout=10)
    result = response.json()
    
    if result.get('code') != 0:
        raise Exception(f"Failed to send voice message: {result.get('msg')}")
    
    return result['data']


def main():
    parser = argparse.ArgumentParser(description='飞书语音消息发送工具')
    parser.add_argument('--audio-file', '-f', required=True, help='音频文件路径 (mp3/wav/m4a/aac)')
    parser.add_argument('--chat-id', '-c', required=True, help='飞书群聊 ID (oc_xxx) 或用户 open_id (ou_xxx)')
    parser.add_argument('--message-id', '-m', help='回复特定消息的 ID (可选)')
    parser.add_argument('--text', '-t', help='语音消息附带的文字 (可选)')
    
    args = parser.parse_args()
    
    try:
        # 检查音频文件是否存在
        if not os.path.exists(args.audio_file):
            raise FileNotFoundError(f"Audio file not found: {args.audio_file}")
        
        # 检查文件大小（飞书限制 20MB）
        file_size_mb = os.path.getsize(args.audio_file) / (1024 * 1024)
        if file_size_mb > 20:
            raise ValueError(f"Audio file too large: {file_size_mb:.2f}MB (max 20MB)")
        
        print(f"[INFO] Loading EasyClaw config...", file=sys.stderr)
        config = load_easyclaw_config()
        
        print(f"[INFO] Getting Feishu app credentials...", file=sys.stderr)
        app_id, app_secret = get_feishu_app_ticket(config)
        
        print(f"[INFO] Getting tenant access token...", file=sys.stderr)
        access_token = get_feishu_tenant_access_token(app_id, app_secret)
        
        print(f"[INFO] Uploading voice file: {args.audio_file}", file=sys.stderr)
        upload_result = upload_voice_file(access_token, args.audio_file)
        file_key = upload_result.get('file_key')
        file_name = upload_result.get('file_name', os.path.basename(args.audio_file))
        
        if not file_key:
            raise Exception("Upload succeeded but no file_key returned")
        
        print(f"[INFO] File uploaded successfully. file_key: {file_key}", file=sys.stderr)
        
        print(f"[INFO] Sending voice message to {args.chat_id}...", file=sys.stderr)
        send_result = send_voice_message(
            access_token, 
            args.chat_id, 
            file_key,
            text=args.text,
            reply_to_message_id=args.message_id
        )
        
        message_id = send_result.get('message_id')
        
        # 输出成功结果
        result = {
            "status": "success",
            "message_id": message_id,
            "chat_id": args.chat_id,
            "file_key": file_key,
            "file_name": file_name,
            "file_size_mb": round(file_size_mb, 2)
        }
        
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print(f"\n[OK] Voice message sent successfully!", file=sys.stderr)
        print(f"     Message ID: {message_id}", file=sys.stderr)
        print(f"     Chat ID: {args.chat_id}", file=sys.stderr)
        
    except Exception as e:
        error_result = {
            "status": "error",
            "error": str(e)
        }
        print(json.dumps(error_result, ensure_ascii=False, indent=2), file=sys.stderr)
        sys.exit(1)


if __name__ == '__main__':
    main()
