#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
飞书权限测试脚本
检查 bot 是否有发送语音消息所需的权限
"""

import requests
import json
import sys
from pathlib import Path

def load_config():
    """加载 EasyClaw 配置"""
    config_paths = [
        Path.home() / ".easyclaw" / "easyclaw.json",
    ]
    
    for config_path in config_paths:
        if config_path.exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
    
    raise FileNotFoundError("EasyClaw config not found")

def get_token(config):
    """获取飞书 tenant_access_token"""
    feishu_config = config.get('channels', {}).get('feishu', {})
    app_id = feishu_config.get('appId')
    app_secret = feishu_config.get('appSecret')
    
    if not app_id or not app_secret:
        raise ValueError("Feishu app credentials not found")
    
    url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
    response = requests.post(url, json={
        "app_id": app_id,
        "app_secret": app_secret
    }, timeout=10)
    
    result = response.json()
    if result.get('code') != 0:
        raise Exception(f"Failed to get token: {result.get('msg')}")
    
    return result['tenant_access_token']

def test_image_upload(token):
    """测试图片上传权限（基础权限）"""
    url = "https://open.feishu.cn/open-apis/im/v1/images"
    headers = {"Authorization": f"Bearer {token}"}
    
    # 1x1 pixel PNG
    test_image = bytes([
        0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A,
        0x00, 0x00, 0x00, 0x0D, 0x49, 0x48, 0x44, 0x52,
        0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01,
        0x08, 0x06, 0x00, 0x00, 0x00, 0x1F, 0x15, 0xC4,
        0x89, 0x00, 0x00, 0x00, 0x0A, 0x49, 0x44, 0x41,
        0x54, 0x78, 0x9C, 0x63, 0x00, 0x01, 0x00, 0x00,
        0x05, 0x00, 0x01, 0x0D, 0x0A, 0x2D, 0xB4, 0x00,
        0x00, 0x00, 0x00, 0x49, 0x45, 0x4E, 0x44, 0xAE,
        0x42, 0x60, 0x82
    ])
    
    files = {'image': ('test.png', test_image, 'image/png')}
    data = {'image_type': 'message'}
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.status_code == 200

def test_file_upload(token):
    """测试文件上传权限（需要 im:resource）"""
    url = "https://open.feishu.cn/open-apis/im/v1/files"
    headers = {"Authorization": f"Bearer {token}"}
    
    # Small test file
    test_data = b"test file content"
    files = {'file': ('test.txt', test_data, 'text/plain')}
    data = {'file_type': 'file'}
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.status_code == 200

def test_audio_upload(token):
    """测试音频上传权限（需要 im:resource）"""
    url = "https://open.feishu.cn/open-apis/im/v1/files"
    headers = {"Authorization": f"Bearer {token}"}
    
    # Small AMR file header
    test_amr = b"#!AMR\n" + b"\x00" * 20
    files = {'file': ('test.amr', test_amr, 'audio/amr')}
    data = {'file_type': 'audio'}
    
    response = requests.post(url, headers=headers, files=files, data=data)
    return response.status_code == 200

def main():
    print("=" * 60)
    print("飞书语音发送 - 权限测试")
    print("=" * 60)
    
    try:
        config = load_config()
        token = get_token(config)
        print(f"✅ 获取 Token 成功")
    except Exception as e:
        print(f"❌ 获取 Token 失败：{e}")
        sys.exit(1)
    
    # Test permissions
    print(f"\n{'=' * 60}")
    print("权限测试")
    print(f"{'=' * 60}")
    
    # Test 1: Image upload
    print(f"\n[1/3] 图片上传权限...", end=" ")
    if test_image_upload(token):
        print("✅ 通过")
        print("      说明：bot 有基础消息发送权限")
    else:
        print("❌ 失败")
        print("      说明：bot 缺少基础权限，请检查飞书开放平台配置")
    
    # Test 2: File upload
    print(f"\n[2/3] 文件上传权限...", end=" ")
    if test_file_upload(token):
        print("✅ 通过")
        print("      说明：bot 有 im:resource 权限，可以发送语音气泡")
    else:
        print("❌ 失败")
        print("      说明：缺少 im:resource 权限")
        print("      解决：飞书开放平台 → 应用管理 → 权限管理 → 添加 im:resource")
    
    # Test 3: Audio upload
    print(f"\n[3/3] 音频上传权限...", end=" ")
    if test_audio_upload(token):
        print("✅ 通过")
        print("      说明：可以发送语音气泡消息")
    else:
        print("❌ 失败")
        print("      说明：缺少音频上传权限")
        print("      解决：同上，需要 im:resource 权限")
    
    # Summary
    print(f"\n{'=' * 60}")
    print("测试总结")
    print(f"{'=' * 60}")
    
    file_ok = test_file_upload(token)
    audio_ok = test_audio_upload(token)
    
    if file_ok and audio_ok:
        print("\n✅ 所有权限已配置，可以使用语音气泡功能！")
        print("\n使用方式:")
        print("  python scripts/send_voice.py --audio-file reply.mp3 --chat-id ou_xxx")
    else:
        print("\n⚠️  权限不完整，建议使用备选方案：")
        print("\n方案 1: 配置飞书权限（推荐）")
        print("  1. 登录飞书开放平台")
        print("  2. 找到应用 cli_a949faa63f799cef")
        print("  3. 添加权限：im:resource")
        print("  4. 重新发布并授权")
        print("\n方案 2: 使用音频文件发送")
        print("  python scripts/send_audio_file.py --audio-file reply.mp3 --chat-id ou_xxx")
    
    print(f"\n{'=' * 60}\n")

if __name__ == '__main__':
    main()
