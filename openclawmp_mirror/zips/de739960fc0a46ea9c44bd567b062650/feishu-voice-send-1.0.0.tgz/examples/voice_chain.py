#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
完整语音链路示例：语音进语音出
STT → LLM → TTS → 飞书语音
"""

import subprocess
import json
import sys
import os

# 配置
SKILL_BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TTS_SCRIPT = os.path.expanduser("~/.easyclaw/skills/tts-asr/scripts/generate_minimax_audio.py")
VOICE_SEND_SCRIPT = os.path.join(SKILL_BASE, "scripts", "send_voice.py")
AUDIO_FILE_SCRIPT = os.path.join(SKILL_BASE, "scripts", "send_audio_file.py")

def run_command(cmd, description):
    """运行命令并输出结果"""
    print(f"\n{'='*60}")
    print(f"步骤：{description}")
    print(f"{'='*60}")
    print(f"命令：{' '.join(cmd)}\n")
    
    result = subprocess.run(cmd, capture_output=True, text=True)
    
    if result.returncode == 0:
        print(f"✅ {description} 完成")
        if result.stdout:
            print(result.stdout)
        return True
    else:
        print(f"❌ {description} 失败")
        if result.stderr:
            print(result.stderr)
        return False

def main():
    if len(sys.argv) < 3:
        print("用法：python voice_chain.py <输入文字> <chat_id>")
        print("示例：python voice_chain.py '你好，这是语音测试' ou_xxx")
        sys.exit(1)
    
    text = sys.argv[1]
    chat_id = sys.argv[2]
    output_file = os.path.join(SKILL_BASE, "demo", "reply.mp3")
    
    print("="*60)
    print("飞书语音链路演示")
    print("="*60)
    print(f"输入文字：{text}")
    print(f"目标聊天：{chat_id}")
    print(f"输出文件：{output_file}")
    
    # Step 1: TTS 生成语音
    tts_cmd = [
        "python", TTS_SCRIPT,
        "--text", text,
        "--output", output_file
    ]
    
    if not run_command(tts_cmd, "生成 TTS 语音"):
        sys.exit(1)
    
    # Step 2: 发送语音到飞书
    print(f"\n{'='*60}")
    print("步骤：发送语音到飞书")
    print(f"{'='*60}")
    
    # Try voice send first, fallback to audio file
    voice_cmd = [
        "python", VOICE_SEND_SCRIPT,
        "--audio-file", output_file,
        "--chat-id", chat_id
    ]
    
    if run_command(voice_cmd, "发送语音消息"):
        print("\n🎉 语音消息发送成功！")
    else:
        # Fallback to audio file
        print("\n⚠️  语音消息发送失败，尝试使用音频文件方式...")
        
        audio_cmd = [
            "python", AUDIO_FILE_SCRIPT,
            "--audio-file", output_file,
            "--chat-id", chat_id
        ]
        
        if run_command(audio_cmd, "发送音频文件"):
            print("\n✅ 音频文件发送成功（备选方案）")
        else:
            print("\n❌ 发送失败")
            sys.exit(1)
    
    print(f"\n{'='*60}")
    print("完成！")
    print(f"{'='*60}")

if __name__ == '__main__':
    main()
