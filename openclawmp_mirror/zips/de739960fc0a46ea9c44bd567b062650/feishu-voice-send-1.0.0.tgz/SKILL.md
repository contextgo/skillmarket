---
name: feishu-voice-send
description: >
  飞书语音消息发送技能。将音频文件以语音消息形式发送到飞书群聊或私聊。
  支持 mp3/wav/m4a/aac 等常见音频格式，自动上传并发送为语音消息（非文件消息）。
  适用于语音回复、语音播报、语音对话等场景。
---

# 飞书语音消息发送

## 概述

本技能提供将音频文件以**语音消息**形式发送到飞书的能力，与普通文件消息不同：

| 类型 | 展示形式 | 用户体验 |
|------|---------|---------|
| 语音消息 | 🎤 语音气泡，可直接播放 | 点击即播，有进度条，体验好 |
| 文件消息 | 📎 附件图标，需下载 | 需点击下载，体验较差 |

**适用场景**：
- 语音对话机器人（STT → LLM → TTS → 飞书语音）
- 语音播报/通知
- 语音回复用户消息

---

## ⚙️ 认证方式

技能内部自动读取 EasyClaw 飞书插件配置，无需额外配置 API Key。

**配置位置**：`~/.easyclaw/easyclaw.json` → `channels.feishu`

---

## 🖥️ 跨平台说明

| 平台 | Python 命令 |
|------|-----------|
| Windows | `python` |
| macOS / Linux | `python3` |

以下示例统一使用 `python`。**Agent 必须检测当前运行平台，使用对应的命令。** macOS/Linux 上需替换为 `python3`。

---

## 📥 使用方法

### 脚本调用方式

**basedir 说明**：当前 `SKILL.md` 所在目录就是 `{baseDir}`

```bash
python {baseDir}/scripts/send_voice.py --audio-file /path/to/audio.mp3 --chat-id oc_xxx
```

### 完整参数说明

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `--audio-file`, `-f` | ✅ | — | 音频文件路径（mp3/wav/m4a/aac） |
| `--chat-id`, `-c` | ✅ | — | 飞书群聊 ID（oc_xxx）或用户 open_id（ou_xxx） |
| `--message-id`, `-m` | — | — | 回复特定消息的 ID（可选） |
| `--text`, `-t` | — | — | 语音消息附带的文字（可选，飞书部分版本支持） |

### 调用示例

```bash
# 基础用法：发送语音到群聊
python {baseDir}/scripts/send_voice.py --audio-file output.mp3 --chat-id oc_xxx

# 发送语音到私聊
python {baseDir}/scripts/send_voice.py --audio-file output.mp3 --chat-id ou_xxx

# 回复特定消息
python {baseDir}/scripts/send_voice.py --audio-file output.mp3 --chat-id oc_xxx --message-id om_xxx
```

---

## 🔧 完整语音链路示例

### 语音进语音出（STT → LLM → TTS → 飞书语音）

```bash
# 步骤 1：语音转文字（使用 tts-asr 技能）
python ~/.easyclaw/skills/tts-asr/scripts/asr.py --audio-file input.m4a

# 步骤 2：LLM 处理文字（略）

# 步骤 3：文字转语音（使用 tts-asr 技能）
python ~/.easyclaw/skills/tts-asr/scripts/generate_minimax_audio.py --text "回复内容" --output reply.mp3

# 步骤 4：发送语音到飞书（使用本技能）
python {baseDir}/scripts/send_voice.py --audio-file reply.mp3 --chat-id oc_xxx
```

---

## 📤 输出格式

脚本输出 JSON 到标准输出：

```json
{
  "status": "success",
  "message_id": "om_xxx",
  "chat_id": "oc_xxx",
  "file_key": "voice_xxx",
  "duration_seconds": 15
}
```

**Agent 处理方式**：
1. 解析 JSON 输出，提取 `status` 字段
2. 成功时告知用户发送结果
3. 失败时报告错误原因

---

## ❌ 错误处理

### 常见错误

| 错误信息 | 原因 | 解决方案 |
|---------|------|---------|
| `audio_file not found` | 文件路径错误 | 确认文件存在 |
| `file too large` | 音频文件超过飞书限制（20MB） | 压缩音频或分段 |
| `invalid chat_id` | 群聊 ID 格式错误 | 检查 ID 是否为 oc_xxx 或 ou_xxx 格式 |
| `upload failed` | 网络或权限问题 | 检查飞书插件配置和网络 |
| `config not found` | EasyClaw 飞书配置缺失 | 检查 `~/.easyclaw/easyclaw.json` |

### Agent 错误处理规则

1. **不要无限重试** — 最多重试 1 次
2. **明确报告** — 告诉用户失败原因
3. **给出建议** — 提供具体的下一步操作

---

## 📋 前置依赖

使用本技能前，确保：

1. ✅ 已安装并配置 EasyClaw 飞书插件
2. ✅ 飞书 App 已授权机器人发送消息权限
3. ✅ 音频文件已生成（可通过 `tts-asr` 技能生成）

---

## 🔗 相关技能

| 技能 | 用途 |
|------|------|
| `tts-asr` | 文字转语音 / 语音转文字 |
| `feishu` | 飞书综合管理（文档/表格/日程等） |

---

## 速查表

| 项目 | 说明 |
|------|------|
| 脚本 | `scripts/send_voice.py` |
| 输入 | 音频文件（mp3/wav/m4a/aac） |
| 输出 | 飞书语音消息 |
| 认证 | EasyClaw 飞书插件自动 |
| 限制 | 文件大小 ≤ 20MB，时长 ≤ 60 秒（推荐） |
