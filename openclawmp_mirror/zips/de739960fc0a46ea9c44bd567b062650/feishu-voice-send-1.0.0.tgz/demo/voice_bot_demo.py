#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
完整语音对话 Demo
演示：语音输入 → STT → LLM → TTS → 飞书语音输出

使用方法:
    python voice_bot_demo.py --audio-input input.m4a --chat-id oc_xxx

或者分步测试:
    python voice_bot_demo.py --text-input "你好" --chat-id oc_xxx
"""

import argparse
import json
import os
import sys
import subprocess
from pathlib import Path
from datetime import datetime

# 技能基础路径
SKILL_BASE = Path(__file__).parent.parent
TTS_ASR_BASE = Path.home() / ".easyclaw" / "skills" / "tts-asr" / "scripts"


def run_command(cmd, description=""):
    """运行命令并返回结果"""
    print(f"\n{'='*60}")
    print(f"📌 步骤：{description}")
    print(f"🔧 命令：{' '.join(cmd)}")
    print(f"{'='*60}\n")
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, encoding='utf-8', timeout=60)
        
        if result.returncode == 0:
            print(f"✅ 成功")
            if result.stdout:
                print(f"📤 输出:\n{result.stdout}")
            return True, result.stdout
        else:
            print(f"❌ 失败：{result.stderr}")
            return False, result.stderr
            
    except subprocess.TimeoutExpired:
        print(f"❌ 超时（60 秒）")
        return False, "Timeout"
    except Exception as e:
        print(f"❌ 错误：{str(e)}")
        return False, str(e)


def text_to_speech(text, output_path):
    """使用 TTS 技能将文字转为语音"""
    if not TTS_ASR_BASE.exists():
        print(f"⚠️  TTS-ASR 技能未找到：{TTS_ASR_BASE}")
        return False, "TTS-ASR skill not found"
    
    script_path = TTS_ASR_BASE / "generate_minimax_audio.py"
    if not script_path.exists():
        print(f"⚠️  TTS 脚本未找到：{script_path}")
        return False, "TTS script not found"
    
    cmd = [
        "python", str(script_path),
        "--text", text,
        "--output", str(output_path)
    ]
    
    return run_command(cmd, f"文字转语音 - '{text}'")


def send_voice(chat_id, audio_path, message_id=None):
    """发送语音消息到飞书"""
    script_path = SKILL_BASE / "scripts" / "send_voice.py"
    
    if not script_path.exists():
        print(f"⚠️  发送脚本未找到：{script_path}")
        return False, "Send script not found"
    
    cmd = [
        "python", str(script_path),
        "--audio-file", str(audio_path),
        "--chat-id", chat_id
    ]
    
    if message_id:
        cmd.extend(["--message-id", message_id])
    
    return run_command(cmd, f"发送语音到飞书 - {chat_id}")


def speech_to_text(audio_path):
    """使用 ASR 技能将语音转为文字"""
    if not TTS_ASR_BASE.exists():
        print(f"⚠️  TTS-ASR 技能未找到：{TTS_ASR_BASE}")
        return False, "TTS-ASR skill not found"
    
    script_path = TTS_ASR_BASE / "asr.py"
    if not script_path.exists():
        print(f"⚠️  ASR 脚本未找到：{script_path}")
        return False, "ASR script not found"
    
    cmd = [
        "python", str(script_path),
        "--audio-file", audio_path
    ]
    
    success, output = run_command(cmd, f"语音转文字 - {audio_path}")
    
    if success:
        try:
            result = json.loads(output)
            text = result.get('text', '')
            print(f"\n📝 识别结果：{text}")
            return True, text
        except:
            return True, output
    
    return success, output


def demo_text_workflow(chat_id):
    """演示纯文字转语音发送流程"""
    print("\n" + "🎯"*30)
    print("🎯  演示模式：文字 → TTS → 飞书语音")
    print("🎯"*30 + "\n")
    
    # 测试文本
    test_texts = [
        "你好！我是你的语音助手，有什么可以帮你的吗？",
        "这是一条测试语音消息，用于验证语音发送功能。",
        "测试完成，系统运行正常！"
    ]
    
    results = []
    
    for i, text in enumerate(test_texts, 1):
        print(f"\n{'🔊'*20}")
        print(f"第 {i} 条语音")
        print(f"{'🔊'*20}\n")
        
        # 生成语音文件
        output_file = Path.home() / ".easyclaw" / "workspace" / f"test_voice_{i}.mp3"
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        success, _ = text_to_speech(text, output_file)
        
        if not success:
            print(f"⚠️  跳过发送（TTS 失败）")
            results.append({"text": text, "status": "tts_failed"})
            continue
        
        # 发送语音
        success, output = send_voice(chat_id, output_file)
        
        if success:
            try:
                result = json.loads(output)
                message_id = result.get('message_id', 'unknown')
                results.append({"text": text, "status": "sent", "message_id": message_id})
            except:
                results.append({"text": text, "status": "sent", "message_id": "unknown"})
        else:
            results.append({"text": text, "status": "send_failed"})
    
    # 输出汇总
    print("\n" + "📊"*30)
    print("📊  执行结果汇总")
    print("📊"*30 + "\n")
    
    for i, r in enumerate(results, 1):
        status_icon = "✅" if r['status'] == 'sent' else "❌"
        print(f"{i}. {status_icon} {r['text'][:30]}...")
        if r['status'] == 'sent':
            print(f"   消息 ID: {r.get('message_id', 'N/A')}")
    
    print("\n" + "✨"*30)
    print(f"✨  完成！共发送 {len([r for r in results if r['status'] == 'sent'])}/{len(results)} 条语音")
    print("✨"*30 + "\n")
    
    return results


def demo_full_workflow(audio_input, chat_id):
    """演示完整语音对话流程"""
    print("\n" + "🎯"*30)
    print("🎯  演示模式：语音 → STT → LLM → TTS → 飞书语音")
    print("🎯"*30 + "\n")
    
    # 步骤 1: 语音转文字
    print("\n📍 步骤 1/3: 语音转文字 (STT)")
    success, recognized_text = speech_to_text(audio_input)
    
    if not success:
        print("❌ STT 失败，终止流程")
        return None
    
    # 步骤 2: LLM 处理（模拟）
    print("\n📍 步骤 2/3: LLM 处理")
    llm_response = f"我收到了你的消息：'{recognized_text}'。这是一条自动回复的测试语音。"
    print(f"🤖 LLM 回复：{llm_response}")
    
    # 步骤 3: 文字转语音并发送
    print("\n📍 步骤 3/3: TTS + 发送")
    output_file = Path.home() / ".easyclaw" / "workspace" / "voice_reply.mp3"
    output_file.parent.mkdir(parents=True, exist_ok=True)
    
    success, _ = text_to_speech(llm_response, output_file)
    
    if not success:
        print("❌ TTS 失败，终止流程")
        return None
    
    success, output = send_voice(chat_id, output_file)
    
    # 输出结果
    print("\n" + "📊"*30)
    print("📊  执行结果")
    print("📊"*30 + "\n")
    
    print(f"📥 输入语音：{audio_input}")
    print(f"📝 识别文字：{recognized_text}")
    print(f"🤖 LLM 回复：{llm_response}")
    
    if success:
        try:
            result = json.loads(output)
            print(f"✅ 发送成功！")
            print(f"   消息 ID: {result.get('message_id', 'N/A')}")
            print(f"   文件 Key: {result.get('file_key', 'N/A')}")
        except:
            print(f"✅ 发送成功！")
    else:
        print(f"❌ 发送失败")
    
    print("\n" + "✨"*30)
    print("✨  完整流程演示完成！")
    print("✨"*30 + "\n")
    
    return {
        "input": audio_input,
        "recognized": recognized_text,
        "response": llm_response,
        "status": "success" if success else "send_failed"
    }


def main():
    parser = argparse.ArgumentParser(description='飞书语音对话完整 Demo')
    parser.add_argument('--chat-id', '-c', required=True, help='飞书群聊 ID (oc_xxx) 或用户 open_id (ou_xxx)')
    parser.add_argument('--audio-input', '-i', help='输入音频文件路径（完整语音链路）')
    parser.add_argument('--text-input', '-t', help='输入文字（文字转语音链路）')
    
    args = parser.parse_args()
    
    print("\n" + "🎙️"*30)
    print("🎙️  飞书语音对话 Demo")
    print("🎙️  开始时间:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print("🎙️"*30 + "\n")
    
    # 检查飞书配置
    print("🔍 检查前置条件...")
    
    try:
        config_path = Path.home() / ".easyclaw" / "easyclaw.json"
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        feishu_config = config.get('channels', {}).get('feishu', {})
        app_id = feishu_config.get('appId')
        enabled = feishu_config.get('enabled', False)
        
        print(f"✅ 飞书插件：{'已启用' if enabled else '未启用'}")
        print(f"✅ App ID: {app_id}")
        
        if not enabled:
            print("❌ 飞书插件未启用，请先在 EasyClaw 配置中启用")
            sys.exit(1)
            
    except Exception as e:
        print(f"❌ 无法读取配置：{e}")
        sys.exit(1)
    
    # 选择演示模式
    if args.audio_input:
        # 完整语音链路
        if not os.path.exists(args.audio_input):
            print(f"❌ 音频文件不存在：{args.audio_input}")
            sys.exit(1)
        
        demo_full_workflow(args.audio_input, args.chat_id)
        
    elif args.text_input:
        # 文字转语音链路
        print("\n📍 步骤 1/2: 文字转语音")
        output_file = Path.home() / ".easyclaw" / "workspace" / "demo_reply.mp3"
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        success, _ = text_to_speech(args.text_input, output_file)
        
        if not success:
            print("❌ TTS 失败")
            sys.exit(1)
        
        print("\n📍 步骤 2/2: 发送语音")
        success, output = send_voice(args.chat_id, output_file)
        
        if success:
            print("\n✅ 完成！")
            try:
                result = json.loads(output)
                print(f"   消息 ID: {result.get('message_id', 'N/A')}")
            except:
                pass
        else:
            print("\n❌ 发送失败")
            sys.exit(1)
            
    else:
        # 默认：发送 3 条测试语音
        print("ℹ️  未指定输入，使用默认测试文本")
        demo_text_workflow(args.chat_id)
    
    print("\n🎙️"*30)
    print("🎙️  Demo 结束时间:", datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
    print("🎙️"*30 + "\n")


if __name__ == '__main__':
    main()
