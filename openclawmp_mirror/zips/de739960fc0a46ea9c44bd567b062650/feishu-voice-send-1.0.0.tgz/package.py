#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
技能包打包脚本
将 feishu-voice-send 技能打包成 zip 文件，用于分享到水产市场
"""

import zipfile
import os
import json
from pathlib import Path
from datetime import datetime

# 技能包根目录
SKILL_ROOT = Path(__file__).parent

# 需要打包的文件
INCLUDE_FILES = [
    "SKILL.md",
    "README.md",
    "RELEASE.md",
    ".easyclaw-metadata.json",
    "scripts/send_voice.py",
    "scripts/send_audio_file.py",
    "scripts/test_permissions.py",
    "examples/voice_chain.py",
    "demo/voice_bot_demo.py",
]

# 排除的文件
EXCLUDE_PATTERNS = [
    "*.pyc",
    "__pycache__",
    ".git",
    "*.log",
    ".DS_Store",
]

def should_exclude(filepath):
    """检查文件是否应该被排除"""
    name = filepath.name
    for pattern in EXCLUDE_PATTERNS:
        if pattern.startswith('*'):
            if name.endswith(pattern[1:]):
                return True
        elif name == pattern:
            return True
    return False

def create_zip_package():
    """创建技能包 zip 文件"""
    # 读取元数据
    metadata_path = SKILL_ROOT / ".easyclaw-metadata.json"
    if not metadata_path.exists():
        print("[ERROR] 元数据文件不存在")
        return None
    
    with open(metadata_path, 'r', encoding='utf-8') as f:
        metadata = json.load(f)
    
    skill_id = metadata.get('skill_id', 'feishu-voice-send')
    version = metadata.get('version', '1.0.0')
    
    # 生成 zip 文件名
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    zip_filename = f"{skill_id}-v{version}-{timestamp}.zip"
    zip_path = SKILL_ROOT / zip_filename
    
    # 创建 zip 文件
    print("="*60)
    print("[PACKAGE] Creating skill package...")
    print(f"   Skill ID: {skill_id}")
    print(f"   Version: v{version}")
    print(f"   Output: {zip_path}")
    
    with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for include_file in INCLUDE_FILES:
            file_path = SKILL_ROOT / include_file
            
            if not file_path.exists():
                print(f"⚠️  文件不存在：{include_file}")
                continue
            
            if should_exclude(file_path):
                print(f"⏭️  跳过：{include_file}")
                continue
            
            # 添加到 zip（保留目录结构）
            arcname = f"{skill_id}/{include_file}"
            zipf.write(file_path, arcname)
            print(f"   [OK] {include_file}")
        
        # 添加许可证文件（如果有）
        license_file = SKILL_ROOT / "LICENSE"
        if license_file.exists():
            zipf.write(license_file, f"{skill_id}/LICENSE")
            print(f"   [OK] LICENSE")
    
    # 计算文件大小
    file_size = os.path.getsize(zip_path)
    file_size_kb = file_size / 1024
    file_size_mb = file_size_kb / 1024
    
    print(f"\n{'='*60}")
    print(f"[DONE] Package created successfully!")
    print(f"{'='*60}")
    print(f"File: {zip_filename}")
    print(f"Size: {file_size_mb:.2f} MB ({file_size_kb:.1f} KB)")
    print(f"Path: {zip_path}")
    
    # 生成发布信息
    release_info = {
        "skill_id": skill_id,
        "version": version,
        "filename": zip_filename,
        "size_mb": round(file_size_mb, 2),
        "created_at": datetime.now().isoformat(),
        "files_included": len(INCLUDE_FILES),
        "metadata": metadata
    }
    
    # 保存发布信息
    info_path = SKILL_ROOT / f"{skill_id}-v{version}-info.json"
    with open(info_path, 'w', encoding='utf-8') as f:
        json.dump(release_info, f, ensure_ascii=False, indent=2)
    
    print(f"\n[INFO] Release info saved to: {info_path}")
    
    return zip_path

def main():
    print("="*60)
    print("飞书语音发送 - 技能包打包工具")
    print("="*60)
    print()
    
    zip_path = create_zip_package()
    
    if zip_path:
        print(f"\n{'='*60}")
        print("[NEXT] Next Steps")
        print(f"{'='*60}")
        print("1. Upload the zip file to the skill marketplace")
        print("2. Or share on GitHub/Community")
        print("3. Users can install the skill from the zip file")
        print()
        print("Publish command example:")
        print(f"  easyclaw skill publish {zip_path}")
        print()
    else:
        print("\n[ERROR] Package creation failed")
        return 1
    
    return 0

if __name__ == '__main__':
    exit(main())
