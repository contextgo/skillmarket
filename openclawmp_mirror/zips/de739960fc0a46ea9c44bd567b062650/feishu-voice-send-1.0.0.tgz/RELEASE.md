# 飞书语音发送技能包 - 发布说明

## 📦 技能包信息

- **技能 ID**: `feishu-voice-send`
- **版本**: v1.1.0
- **分类**: 飞书工具
- **作者**: EasyClaw Community
- **许可证**: MIT

## 🎯 功能特性

### 核心功能
1. ✅ **语音气泡发送** - 发送飞书原生语音消息（🎤 形式）
2. ✅ **音频文件发送** - 备选方案，无需特殊权限
3. ✅ **权限测试** - 自动检测 bot 权限配置
4. ✅ **完整语音链路** - STT → LLM → TTS → 飞书语音

### 支持的音频格式
- MP3、WAV、M4A、AAC、AMR
- 推荐：AMR（文件更小，飞书原生支持）

### 适用场景
- 语音对话机器人
- 语音播报/通知
- 语音回复用户消息
- 语音进语音出完整链路

## 📋 前置要求

### EasyClaw 配置
- ✅ EasyClaw 飞书插件已启用
- ✅ 配置 `appId` 和 `appSecret`

### 飞书开放平台权限
| 权限 | 用途 | 必需性 |
|------|------|--------|
| `im:message` | 发送消息 | ⭐⭐⭐ 必需 |
| `im:resource` | 上传资源（语音气泡） | ⭐⭐ 语音气泡必需 |

**注意**：缺少 `im:resource` 权限时，可使用音频文件备选方案。

## 🚀 安装方式

### 方式 1：技能市场安装（推荐）
```bash
easyclaw skill install feishu-voice-send
```

### 方式 2：手动安装
```bash
# 下载技能包
git clone <repo_url> ~/.easyclaw/skills/feishu-voice-send

# 或复制文件夹到 ~/.easyclaw/skills/feishu-voice-send
```

### 方式 3：从水产市场
访问 [EasyClaw 技能市场](https://easyclaw.cn/skills) 搜索 "飞书语音"

## 📖 使用文档

### 快速开始

#### 1. 权限测试
```bash
python scripts/test_permissions.py
```

#### 2. 发送语音
```bash
# 方式 A：语音气泡（需要 im:resource 权限）
python scripts/send_voice.py --audio-file reply.mp3 --chat-id ou_xxx

# 方式 B：音频文件（无需特殊权限）
python scripts/send_audio_file.py --audio-file reply.mp3 --chat-id ou_xxx
```

#### 3. 完整语音链路
```bash
python examples/voice_chain.py "你好，这是语音测试" ou_xxx
```

### API 调用示例

```python
# Python 调用
import subprocess

# 发送语音
result = subprocess.run([
    "python", "scripts/send_voice.py",
    "--audio-file", "reply.mp3",
    "--chat-id", "ou_xxx"
], capture_output=True, text=True)

print(result.stdout)
```

## 🔧 脚本说明

| 脚本 | 用途 | 输入 | 输出 |
|------|------|------|------|
| `send_voice.py` | 发送语音气泡 | 音频文件 + chat_id | JSON 结果 |
| `send_audio_file.py` | 发送音频文件 | 音频文件 + chat_id | JSON 结果 |
| `test_permissions.py` | 权限测试 | 无 | 测试报告 |
| `voice_chain.py` | 完整链路演示 | 文字 + chat_id | 语音发送 |

## ❌ 常见问题

### Q1: 错误 234001 - Invalid request param
**原因**: 缺少 `im:resource` 权限  
**解决**: 飞书开放平台 → 应用管理 → 权限管理 → 添加 `im:resource`

### Q2: 错误 230017 - Bot is NOT the owner of the resource
**原因**: 使用了其他 bot 上传的 file_key  
**解决**: 使用当前 bot 上传文件获取 file_key

### Q3: 语音气泡 vs 音频文件
| 特性 | 语音气泡 | 音频文件 |
|------|---------|---------|
| UI 形式 | 🎤 语音卡片 | 📎 文件卡片 |
| 播放体验 | 点击即播 | 点击播放 |
| 权限要求 | 需要 im:resource | 无需特殊权限 |
| 推荐场景 | 语音对话 | 备选方案 |

### Q4: 支持的最大文件大小
- 飞书限制：20MB
- 推荐：≤5MB，时长 ≤60 秒

## 📝 更新日志

### v1.1.0 (2026-03-27)
- ✨ 添加权限测试脚本
- ✨ 添加音频文件备选方案
- ✨ 添加完整语音链路示例
- 📝 完善文档和错误处理
- 🐛 修复跨平台路径问题

### v1.0.0 (2026-03-26)
- ✨ 初始版本发布

## 🔗 相关资源

- [EasyClaw 文档](https://docs.openclaw.ai)
- [飞书开放平台](https://open.feishu.cn/)
- [MiniMax TTS 文档](https://platform.minimaxi.com/)
- [技能市场](https://easyclaw.cn/skills)

## 📮 反馈与支持

- 问题反馈：GitHub Issues
- 技能交流：EasyClaw 社区
- 商务合作：contact@easyclaw.cn

---

**发布于**: 2026-03-27  
**最后更新**: 2026-03-27  
**技能市场**: [水产市场](https://easyclaw.cn/skills)
