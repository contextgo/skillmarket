# React Server Components Patterns

## Overview
RSC is the core feature of React 18+. Correct usage reduces initial load time by 60%.

## When to Use Server Components
- Direct DB/API access
- No user interaction needed
- Server-only dependencies (fs, crypto)
- Keep sensitive data server-side

## When Client Components are Required
- useState/useEffect/useReducer
- Event handlers (onClick, onChange)
- Browser APIs (localStorage, geolocation)
- Custom hooks

## Data Fetching Patterns

### Parallel Data Fetching
Use Promise.all for independent data. Avoid sequential waterfall.

### Suspense Boundaries
Place Suspense in layout for streaming rendering. Show skeleton screens.

### Client Caching
Use SWR or React Query for client-side mutations.

## Optimization
- Bundle: next/dynamic lazy-load non-critical components
- Images: next/image auto WebP + responsive
- Fonts: next/font zero layout shift
- Caching: fetch revalidate strategy

## Common Pitfalls
- Passing function props to Server Components
- useEffect executing server-side
- Excessive client state (lift to URL params)
