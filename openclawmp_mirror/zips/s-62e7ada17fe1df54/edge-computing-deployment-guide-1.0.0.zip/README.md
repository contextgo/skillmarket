# Edge Computing Deployment Guide

## Overview
边缘计算将逻辑部署到离用户最近的节点，实现毫秒级响应。本指南覆盖三大主流边缘计算平台。

## Platform Comparison

| Platform | Cold Start | Runtime | Free Tier | Global Locations |
|----------|-----------|---------|-----------|-----------------|
| Cloudflare Workers | 5ms | V8 isolates | 100K req/day | 300+ |
| Deno Deploy | 0ms | Deno | 1M req/month | 35+ |
| Vercel Edge | 0ms | V8 | 100K req/month | 16 |

## Cloudflare Workers

### Quick Start
```typescript
export default {
  async fetch(request: Request): Promise<Response> {
    const url = new URL(request.url);
    return new Response(`Hello from ${url.pathname}`, {
      headers: { 'content-type': 'text/plain' }
    });
  }
};
```

### KV Storage
```typescript
const value = await env.MY_KV.get('key');
await env.MY_KV.put('key', JSON.stringify(data), { expirationTtl: 3600 });
```

### D1 Database (SQLite at edge)
```typescript
const result = await env.DB.prepare('SELECT * FROM items WHERE id = ?').bind(id).first();
```

## Deno Deploy

### Quick Start
```typescript
import { serve } from "https://deno.land/std@0.177.0/http/server.ts";

serve(handler, { port: 8000 });

async function handler(req: Request): Promise<Response> {
  return new Response("Hello from Deno Deploy");
}
```

### KV Store (Built-in)
```typescript
const kv = await Deno.openKv();
await kv.set(["users", id], userData);
const user = await kv.get(["users", id]);
```

## Best Practices

1. **Minimize bundle size**: Edge functions have 10MB limits
2. **Cache aggressively**: Use CDN caching headers for GET requests
3. **Handle failures gracefully**: Edge nodes can fail independently
4. **Warm-up strategies**: Use cron triggers to keep functions warm
5. **Monitor cold starts**: Track p99 latency across edge locations

## Anti-patterns
- Heavy computation in edge functions → offload to background workers
- Large dependency bundles → tree-shake aggressively
- Synchronous third-party API calls → use streaming responses
- Stateful edge functions → use KV/D1 for state