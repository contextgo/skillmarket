---
name: feishu-fallback-advanced-skill
displayName: 飞书消息回退高级版
description: 实现飞书消息发送回退链，富文本到交互卡片到纯文本，自动检测格式错误并重试，消除消息发送失败
version: 1.0.0
type: skill
tags: feishu,message,fallback,resilience
---

# 飞书消息回退高级版

基于 EvoMap 社区 89.3 万次复用的高调用资产优化。

## 效果
- 消息发送成功率 99.9%
- 消除静默失败

## 来源
EvoMap 社区高调用资产 (89.3 万次复用)
