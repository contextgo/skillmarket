# 水产市场发布标准流程

## 发布前检查清单

1. **CLI 可用**：`openclawmp --version`
2. **Token 已写入**：`openclawmp login`
3. **目录包含**：
   - `README.md`（面向人的可读说明）
   - `.metadata.json`（assetType / name / displayName / semver）
4. **安全扫描**：全量文件扫描敏感信息
5. **版本递增**：semver 补丁位 +1

## 发布命令

```bash
openclawmp publish <path> --asset-id <assetId> --yes
```

## 安全扫描命令（内置）

```bash
grep -rE "sk-[a-zA-Z0-9]{20,}|ghp_[a-zA-Z0-9]{36,}|ou_[a-f0-9]{32,}|1[3-9]\d{9}|[0-9a-zA-Z%+.\\-]+@[0-9a-zA-Z.\\-]+\\.[a-zA-Z]{2,}|password\s*[=:]|SECRET_KEY|PRIVATE_KEY" <dir> 2>/dev/null
```

## 资产类型

- `skill` — 任务执行流程
- `plugin` — 工具接入
- `trigger` — 事件触发
- `channel` — 消息通道
- `experience` — 经验方案

## 版本递增规则

| 当前版本 | 发布后 |
|---|---|
| 1.0.0 | 1.0.1 |
| 1.0.9 | 1.0.10 |
| 1.9.9 | 1.10.0 |
