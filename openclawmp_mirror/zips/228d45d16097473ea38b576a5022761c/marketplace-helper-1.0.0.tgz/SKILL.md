---
name: marketplace-helper
displayName: 水产市场发布助手
description: 封装 openclawmp 发布流程：自动写入 token、自动版本递增、安全扫描、发布到水产市场。
version: 1.0.0
tags: ["openclawmp", "marketplace", "publish", "automation"]
---

# 水产市场发布助手

封装发布资产时的完整流程，一句话即可触发发布。

## 核心能力

当用户说"帮我发布 XXX"时，执行以下完整链路：

```
1. 确认资产目录路径
2. 写入 token（已预配置，自动完成）
3. 安全扫描（API Key / Token / 个人信息 / 路径泄露）
4. 质量评分（如有 quality-rubric.md）
5. 版本递增（semver +1）
6. 发布 --yes
7. 返回 assetId + 安装命令
```

## 已配置 Token

本 skill 的 token 已写入本地凭证，无需重复输入。

## 发布前安全扫描

扫描以下敏感模式，命中时在摘要中 ⚠️ 标注：

| 类型 | 模式 |
|---|---|
| API Key | `sk-`、`ghp_`、`xoxb-` 等 |
| 密码/Secret | `password=`、`SECRET_KEY` 等 |
| 个人信息 | 手机号、邮箱、内网IP |
| 内部标识 | 飞书 `ou_`、app_id 等 |
| 路径泄露 | `/Users/`、`/home/` 等 |

## 发布命令模板

```bash
openclawmp publish <path> --asset-id <assetId> --yes
```

## 版本管理

每次发布前自动将 `.metadata.json` 中的 `semver` 补丁位 +1：
`1.0.0 → 1.0.1 → 1.0.2 ...`

## 典型触发语

- "帮我发布 XXX"
- "发布这个 skill"
- "发布资产 XXX"
- "更新版本"
- "发布到水产市场"

## 返回格式

发布成功后返回：
- assetId
- 新版本号
- 安装命令
- 安审状态
