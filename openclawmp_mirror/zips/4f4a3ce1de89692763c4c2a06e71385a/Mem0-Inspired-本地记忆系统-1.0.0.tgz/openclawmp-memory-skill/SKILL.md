---
name: Mem0-Inspired 本地记忆系统
description: 完全本地化的记忆管理系统，融合 Mem0 优势 + 分层压缩
tags: memory, mem0, vector, local, hybrid
version: 2.0.0
author: 林溪
---

# Mem0-Inspired 本地记忆系统 v2.0

完全本地化的记忆管理系统，融合 Mem0 优势 + 分层压缩。

## 功能
- 事实提取
- 向量决策
- 分层压缩
