# MCP Skill

集成MCP（Model Context Protocol）工具，提供强大的搜索和研究能力。

## 功能特性

- 🔍 **高级网页搜索**：通过Exa.ai进行智能搜索
- 📊 **深度研究**：深度内容分析和研究
- 💻 **代码上下文**：获取技术文档和代码信息
- 🏢 **公司研究**：企业信息和研究报告
- 🔗 **LinkedIn搜索**：专业网络分析
- 🕷️ **网页爬虫**：内容抓取和分析

## 安装状态

✅ **已成功安装**
- 安装时间：2026-03-28 14:27
- 安装方式：手动安装
- 安装路径：`~/.local/lib/node_modules/openclaw/skills/mcp-skill/`

## 使用前提

1. **MCP API密钥**：需要配置有效的MCP API密钥
2. **网络连接**：需要稳定的互联网连接
3. **OpenClaw版本**：支持最新版OpenClaw

## 工具列表

| 工具名称 | 功能描述 | 使用频率 |
|---------|---------|---------|
| web_search_exa | 基础网页搜索 | 高频 |
| web_search_advanced_exa | 高级网页搜索 | 中频 |
| get_code_context_exa | 代码上下文获取 | 中频 |
| deep_search_exa | 深度内容搜索 | 低频 |
| crawling_exa | 网页爬虫 | 低频 |
| company_research_exa | 公司研究 | 中频 |
| linkedin_search_exa | LinkedIn搜索 | 低频 |
| deep_researcher_start | 深度研究启动 | 低频 |
| deep_researcher_check | 深度研究检查 | 低频 |

## 配置指南

### 环境变量配置
```bash
export MCP_API_KEY="your_api_key_here"
```

### OpenClaw配置
确保OpenClaw Gateway已重启以加载新skill。

## 使用示例

### 示例1：网页搜索
```javascript
// 搜索OpenClaw相关信息
const results = await web_search_exa({
  query: "OpenClaw多Agent协作架构",
  max_results: 5,
  time_range: "past_year"
});
```

### 示例2：公司研究
```javascript
// 研究特定公司
const companyInfo = await company_research_exa({
  company: "OpenClaw",
  include_financials: true,
  include_news: true
});
```

## 注意事项

⚠️ **重要提醒**：
1. 遵守MCP API的使用条款
2. 注意API调用频率限制
3. 保护敏感搜索数据
4. 监控API使用成本

## 支持与反馈

- **问题报告**：通过OpenClaw控制UI反馈
- **功能建议**：记录在TOOLS.md中
- **更新计划**：定期检查MCP API更新

## 版本历史

- **v1.0.0** (2026-03-28)：初始安装版本
  - 集成MCP基础工具
  - 支持9个核心功能
  - 完善文档和配置

---
**安装验证**：✅ 通过
**系统集成**：✅ 完成
**就绪状态**：🟢 可用