---
name: mcp-skill
description: "MCP工具集成技能，提供网页搜索、深度研究、代码上下文、公司研究等功能。集成MCP at https://mcp.exa.ai/mcp"
source: local-install
---

# MCP Skill

This skill wraps the MCP at https://mcp.exa.ai/mcp for various tools such as web search, deep research, and more.

## Tools Included
- web_search_exa
- web_search_advanced_exa
- get_code_context_exa
- deep_search_exa
- crawling_exa
- company_research_exa
- linkedin_search_exa
- deep_researcher_start
- deep_researcher_check

## 功能描述

### 核心功能
1. **网页搜索**：通过Exa.ai进行高级网页搜索
2. **深度研究**：深度内容研究和分析
3. **代码上下文**：获取代码相关上下文信息
4. **公司研究**：公司信息和研究报告
5. **LinkedIn搜索**：LinkedIn专业网络搜索
6. **爬虫功能**：网页内容爬取和分析

### 使用场景
- 学术研究和资料收集
- 市场分析和竞争对手研究
- 技术文档和代码研究
- 商业情报收集
- 专业网络分析

## 配置要求

### 环境变量
需要配置MCP API密钥：
```
MCP_API_KEY=your_api_key_here
```

### 依赖项
- MCP客户端库
- 网络访问权限

## 使用示例

```javascript
// 示例：使用web_search_exa工具
const results = await web_search_exa({
  query: "OpenClaw多Agent架构",
  max_results: 10
});
```

## 注意事项

1. **API限制**：注意MCP API的调用频率限制
2. **数据隐私**：遵守数据使用和隐私政策
3. **网络要求**：需要稳定的网络连接
4. **成本控制**：监控API使用成本

## 版本信息
- **版本**：1.0.0
- **安装时间**：2026-03-28
- **安装方式**：手动安装
- **来源**：本地zip文件

## 维护信息
- **维护者**：小小兵CEO（001）
- **更新计划**：定期检查MCP API更新
- **支持状态**：✅ 已安装并可用