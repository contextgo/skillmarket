# PinchTab 安装指南

## ⚠️ 当前状态

**安装遇到问题**: npm 安装的包缺少二进制文件

**解决方案**: 从源码构建（需要 Go 环境）

---

## 🔧 安装步骤

### 1. 安装 Go 环境

```bash
sudo apt update
sudo apt install -y golang-go
```

### 2. 克隆仓库

```bash
cd ~/.openclaw/workspace
git clone https://github.com/pinchtab/pinchtab.git
cd pinchtab
```

### 3. 运行安装脚本

```bash
./doctor.sh
```

### 4. 构建二进制

```bash
go build ./cmd/pinchtab
```

### 5. 安装到系统

```bash
sudo cp pinchtab /usr/local/bin/
```

### 6. 启动服务器

```bash
pinchtab
```

服务器将在 `http://localhost:9867` 启动

---

## 🧪 验证安装

```bash
# 检查版本
pinchtab --version

# 测试 API
curl http://localhost:9867/health

# 打开仪表盘
firefox http://localhost:9867/dashboard
```

---

## 📊 性能测试

```bash
# 创建实例
time curl -s -X POST http://localhost:9867/instances/launch \
  -H "Content-Type: application/json" \
  -d '{"name":"test","mode":"headless"}'

# 导航测试
time pinchtab nav https://pinchtab.com

# Token 消耗测试
pinchtab text | wc -w
```

---

## 🎯 集成到 OpenClaw

### 1. 创建技能包装

```bash
cd ~/.openclaw/workspace/skills/pinchtab-browser
mkdir -p scripts
```

### 2. 创建启动脚本

```bash
cat > scripts/start-pinchtab.sh << 'EOF'
#!/bin/bash
# 启动 PinchTab 服务器

if ! pgrep -f "pinchtab" > /dev/null; then
    echo "Starting PinchTab server..."
    nohup pinchtab > ~/.pinchtab/server.log 2>&1 &
    sleep 2
    echo "✅ PinchTab started on http://localhost:9867"
else
    echo "✅ PinchTab already running"
fi
EOF

chmod +x scripts/start-pinchtab.sh
```

### 3. 添加到 crontab（开机自启动）

```bash
(crontab -l 2>/dev/null; echo "@reboot ~/.openclaw/workspace/skills/pinchtab-browser/scripts/start-pinchtab.sh") | crontab -
```

---

## 🔍 故障排查

### 问题 1: Go 环境未安装

```bash
# 检查 Go
go version

# 安装 Go
sudo apt install -y golang-go
```

### 问题 2: 构建失败

```bash
# 更新依赖
go mod download
go mod tidy

# 重新构建
go build ./cmd/pinchtab
```

### 问题 3: 端口被占用

```bash
# 检查端口
lsof -i :9867

# 杀死进程
kill -9 $(lsof -t -i:9867)

# 重启
pinchtab
```

---

## 📚 相关资源

- **GitHub**: https://github.com/pinchtab/pinchtab
- **文档**: https://pinchtab.com/docs
- **Skill 文档**: `~/.openclaw/workspace/skills/pinchtab-browser/SKILL.md`

---

**下一步**: 安装 Go 环境，然后从源码构建 PinchTab
