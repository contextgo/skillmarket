# 多 Agent 混合层级隔离架构 1.0

> 飞书多 Agent 快速配置与协作架构

## 📖 简介

本架构提供了一套完整的多 Agent 协作系统，通过**混合层级隔离**设计，实现：

- ✅ **协调员 Agent** - 负责任务分配、质量审查和决策
- ✅ **专家 Agent** - 负责专业执行（绘图、媒体生成、内容创作等）
- ✅ **权限隔离** - 协调员不能直接执行专家技能，确保职责清晰
- ✅ **灵活扩展** - 支持 1-N 个 Agent 配置

## 🚀 快速开始

### 方式一：使用配置向导（推荐）

```bash
openclaw skill run feishu-multiagent-onboard
```

### 方式二：手动配置

编辑 `~/.openclaw/openclaw.json`，参考 `templates/openclaw.json.example`

### 方式三：验证配置

```bash
openclaw skill run feishu-multiagent-onboard --check
```

### 方式四：故障诊断

```bash
openclaw skill run feishu-multiagent-onboard --debug
```

## 🎨 个性化命名

本架构使用通用角色名：

- **协调员** - 负责任务分配的主理 Agent
- **专家** - 负责专业执行的 Agent

你可以替换成任何喜欢的命名，例如：

- 墨墨 / 小媒
- 管家 / 工匠
- 指挥 / 执行者
- 你的创意组合！

只需在模板中替换 `{{AGENT_NAME}}` 即可。

### 示例配置

**协调员 Agent（墨墨）:**
```markdown
# 墨墨 - 首席协调员
**角色定位**: 协调员 (Coordinator)
**专属技能前缀**: (无)
```

**专家 Agent（小媒）:**
```markdown
# 小媒 - 领域专家
**角色定位**: 专家 (Specialist)
**专属技能前缀**: baoyu-
```

## 📁 目录结构

```
feishu-multiagent-onboard/
├── SKILL.md                      # Skill 说明
├── README.md                     # 本文档
├── index.js                      # 配置向导脚本
├── docs/
│   ├── guide.md                  # 完整配置指南
│   └── faq.md                    # 常见问题
└── templates/
    ├── openclaw.json.example     # 配置示例
    ├── writer-soul-template.md   # 协调员 SOUL 模板
    └── media-soul-template.md    # 专家 SOUL 模板
```

## 🔧 功能特性

- ✅ 交互式配置向导
- ✅ 自动验证配置格式
- ✅ 故障诊断工具
- ✅ 完整文档和最佳实践
- ✅ 支持 1-N 个 Agent 配置
- ✅ 权限隔离机制
- ✅ 个性化命名支持

## 📚 详细文档

- [完整配置指南](docs/guide.md) - 从创建飞书应用到完成配置的详细步骤
- [常见问题 FAQ](docs/faq.md) - 配置和使用过程中的常见问题解答

## 🛠️ 命令参考

| 命令 | 说明 |
|------|------|
| `openclaw skill run feishu-multiagent-onboard` | 启动配置向导 |
| `openclaw skill run feishu-multiagent-onboard --check` | 验证配置 |
| `openclaw skill run feishu-multiagent-onboard --debug` | 故障诊断 |
| `openclaw skill run feishu-multiagent-onboard --help` | 显示帮助 |

## ⚠️ 重要提示

1. **每个 Agent 独立飞书应用** - 不要共用 App ID 和 Secret
2. **事件订阅必须添加事件** - 长连接 + `接收消息` (im.message)
3. **权限完整导入** - 使用批量导入功能
4. **配置后备份** - `cp ~/.openclaw/openclaw.json ~/.openclaw/openclaw.json.bak`
5. **测试后再发布** - 确保每个 Agent 都能正常回复

## 📝 版本历史

- **1.0.0** (2026-03-08) - 初始版本，支持多 Agent 混合层级隔离架构

## 👥 作者

多 Agent 架构实践者

## 📄 许可证

MIT
