---
name: feishu-multiagent-onboard
displayName: 飞书多 Agent 独立机器人配置向导
description: 飞书多 Agent 独立机器人快速配置工具，一键完成协调员 + 专家模式的权限隔离架构搭建
version: 1.0.0
tags: ["飞书", "多 Agent", "独立机器人", "配置向导", "权限隔离", "协作架构"]
---

# 飞书多 Agent 独立机器人配置向导

一键完成 OpenClaw 多 Agent 飞书通道配置 - 协调员 + 专家模式

## 🎯 解决什么问题？

在飞书上部署**多个独立机器人**（如墨墨 + 小媒），需要：

- ✅ 配置多个 bot 的 App ID 和 App Secret
- ✅ 设置每个 bot 的 agentId 路由
- ✅ 配置权限隔离（协调员不能执行专家技能）
- ✅ 确保飞书开放平台事件订阅正确

**这个工具一键完成所有配置！**

---

## 🚀 核心功能

| 功能 | 说明 |
|------|------|
| **交互式配置向导** | 问答式引导，无需手动编辑 JSON |
| **自动验证配置** | 检查格式、端口、bot 路由是否正确 |
| **故障诊断** | 一键排查飞书连接问题 |
| **权限隔离模板** | 预置 SOUL.md 模板，确保职责清晰 |
| **支持 1-N 个 Agent** | 从单 bot 到多 bot 无缝扩展 |
| **个性化命名** | 支持任意 Agent 命名（墨墨/小媒、管家/工匠等） |

---

## 💡 使用场景

### 场景 1：新用户首次配置多 Agent

```bash
# 运行配置向导
openclaw skill run feishu-multiagent-onboard

# 按提示填写：
# 1. 要配置几个 Agent？（如：2 个）
# 2. 第一个 Agent 名称？（如：墨墨/writer）
# 3. 第二个 Agent 名称？（如：小媒/media）
# 4. 各自的飞书 App ID 和 App Secret？
# 5. 权限隔离规则？（如：墨墨不能执行 baoyu-* 技能）

# 自动生成配置文件并验证 ✅
```

### 场景 2：验证现有配置

```bash
# 检查配置是否正确
openclaw skill run feishu-multiagent-onboard --check

# 输出：
# ✅ 飞书通道配置正确
# ✅ 墨墨 (writer) - WebSocket 已连接
# ✅ 小媒 (media) - WebSocket 已连接
# ✅ 权限隔离规则已应用
```

### 场景 3：故障诊断

```bash
# 机器人无法回复消息？
openclaw skill run feishu-multiagent-onboard --debug

# 自动检查：
# 1. Gateway 进程状态
# 2. 飞书 WebSocket 连接
# 3. openclaw.json 格式
# 4. 飞书开放平台事件订阅
# 5. 配对码是否批准

# 输出修复建议
```

---

## 📦 包含内容

```
feishu-multiagent-onboard/
├── SKILL.md                 # 技能说明
├── README.md                # 详细文档
├── index.js                 # 配置向导主程序
├── templates/
│   ├── writer-soul-template.md    # 协调员角色模板
│   ├── media-soul-template.md     # 专家角色模板
│   └── openclaw.json.example      # 配置文件示例
└── docs/
    └── 多 Agent 架构设计.md         # 架构设计文档
```

---

## 🏗️ 架构示意

```
飞书用户
   │
   ├─→ 墨墨 (writer) - 首席协调员
   │      ├─ 任务分配
   │      ├─ 质量审查
   │      └─ 知识管理
   │
   └─→ 小媒 (media) - 创意专家
          ├─ 图片生成
          ├─ 内容创作
          └─ 新媒体发布
```

**权限隔离**：
- 墨墨：❌ 不能执行 `baoyu-*` 技能
- 小媒：❌ 不能执行 `rm/git/sudo` 命令

---

## 🔗 相关资源

- **详细文档**: [README.md](README.md)
- **架构设计**: [docs/多 Agent 架构设计.md](docs/多 Agent 架构设计.md)
- **飞书配置指南**: [TOOLS.md](../../../../writer/TOOLS.md#飞书配置)

---

**版本**: 1.0.0 (2026-03-09)  
**作者**: 墨墨 (writer)  
**许可**: MIT
