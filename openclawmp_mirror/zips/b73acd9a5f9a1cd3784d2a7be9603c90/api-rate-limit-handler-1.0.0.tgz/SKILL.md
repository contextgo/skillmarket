---
name: api-rate-limit-handler
description: "API速率限制通用处理方案 - 指数退避、令牌桶、降级策略"
version: 1.0.0
tags: ["api", "rate-limit", "resilience", "retry", "resilience"]
---

# API 速率限制处理方案

处理各种 API 的速率限制、超时和错误的通用方案，适用于 AI Agent 频繁调用外部 API 的场景。

## 核心策略

### 1. 指数退避重试

```python
import asyncio
import random

async def retry_with_backoff(coro, max_retries=3, base_delay=1):
    for attempt in range(max_retries):
        try:
            return await coro()
        except (TimeoutError, RateLimitError) as e:
            if attempt == max_retries - 1:
                raise
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            print(f"Retry {attempt + 1}/{max_retries} after {delay:.1f}s: {e}")
            await asyncio.sleep(delay)
```

### 2. 令牌桶限流

```python
import time

class TokenBucket:
    def __init__(self, rate=10, capacity=20):
        self.rate = rate       # 每秒补充令牌数
        self.capacity = capacity
        self.tokens = capacity
        self.last_refill = time.time()
    
    async def acquire(self):
        now = time.time()
        self.tokens = min(self.capacity, 
                         self.tokens + (now - self.last_refill) * self.rate)
        self.last_refill = now
        
        if self.tokens >= 1:
            self.tokens -= 1
            return True
        
        wait_time = (1 - self.tokens) / self.rate
        await asyncio.sleep(wait_time)
        return await self.acquire()
```

### 3. 优雅降级

```python
async def fetch_with_fallback(sources):
    """依次尝试多个源，第一个成功就返回"""
    for source in sources:
        try:
            return await fetch(source)
        except (TimeoutError, RateLimitError):
            continue
    raise AllSourcesFailedError()
```

## 常见 API 限制参考

| API | 限制 | 策略 |
|-----|------|------|
| OpenRouter | 20 req/min | 令牌桶 |
| Hacker News | 无限制 | 直接请求 |
| CryptoPanic | 免费 5/min | 指数退避 |
| Reddit RSS | 无限制 | 直接请求 |
| EvoMap | 4 req/min | 令牌桶 |
| OpenClaw MP | 无明确限制 | 安全间隔 2s |

## 超时配置

```python
TIMEOUT_CONFIG = {
    "fast": 5,      # 轻量 API
    "normal": 15,   # 标准 API
    "slow": 30,     # 大数据 API
    "batch": 120,   # 批量操作
}
```

## 错误分类处理

| 错误码 | 含义 | 处理 |
|-------|------|------|
| 429 | 限流 | 读取 Retry-After 头，等待后重试 |
| 401 | 未授权 | 刷新认证，不重试 |
| 403 | 禁止 | 检查权限，不重试 |
| 500 | 服务器错误 | 重试 1 次 |
| 502/503 | 服务不可用 | 指数退避重试 |
| timeout | 超时 | 重试 + 降低请求量 |

## 监控指标

- 每分钟请求量
- 重试次数
- 成功率
- 平均延迟
- 降级触发次数
