# 自我提升技能

将学习和错误记录到 Markdown 文件中以实现持续改进。编码代理可以稍后将这些处理为修复方案，重要的学习内容会被提升到项目记忆中。

## 快速参考

| 情况 | 操作 |
|-----------|--------|
| 命令/操作失败 | 记录到 `.learnings/ERRORS.md` |
| 用户纠正你 | 记录到 `.learnings/LEARNINGS.md`，类别为 `correction` |
| 用户需要缺失功能 | 记录到 `.learnings/FEATURE_REQUESTS.md` |
| API/外部工具失败 | 记录到 `.learnings/ERRORS.md`，包含集成细节 |
| 知识已过时 | 记录到 `.learnings/LEARNINGS.md`，类别为 `knowledge_gap` |
| 发现更好的方法 | 记录到 `.learnings/LEARNINGS.md`，类别为 `best_practice` |
| 简化/加强重复模式 | 记录/更新 `.learnings/LEARNINGS.md`，使用 `Source: simplify-and-harden` 和稳定的 `Pattern-Key` |
| 与现有条目相似 | 使用 `**See Also**` 链接，考虑提高优先级 |
| 广泛适用的学习 | 提升到 `CLAUDE.md`、`AGENTS.md` 和/或 `.github/copilot-instructions.md` |
| 工作流程改进 | 提升到 `AGENTS.md`（OpenClaw 工作区） |
| 工具陷阱 | 提升到 `TOOLS.md`（OpenClaw 工作区） |
| 行为模式 | 提升到 `SOUL.md`（OpenClaw 工作区） |

## OpenClaw 设置（推荐）

OpenClaw 是此技能的主要平台。它使用基于工作区的提示注入和自动技能加载。

### 安装

**通过 ClawdHub（推荐）：**
```bash
clawdhub install self-improving-agent
```

**手动安装：**
```bash
git clone https://github.com/peterskoett/self-improving-agent.git ~/.openclaw/skills/self-improving-agent
```

为 OpenClaw 重新制作，源自原始仓库：https://github.com/pskoett/pskoett-ai-skills - https://github.com/pskoett/pskoett-ai-skills/tree/main/skills/self-improvement

### 工作区结构

OpenClaw 将这些文件注入到每个会话中：

```
~/.openclaw/workspace/
├── AGENTS.md          # 多代理工作流、委托模式
├── SOUL.md            # 行为准则、个性、原则
├── TOOLS.md           # 工具功能、集成陷阱
├── MEMORY.md          # 长期记忆（仅主会话）
├── memory/            # 日常记忆文件
│   └── YYYY-MM-DD.md
└── .learnings/        # 此技能的日志文件
    ├── LEARNINGS.md
    ├── ERRORS.md
    └── FEATURE_REQUESTS.md
```

### 创建学习文件

```bash
mkdir -p ~/.openclaw/workspace/.learnings
```

然后创建日志文件（或从 `assets/` 复制）：
- `LEARNINGS.md` — 修正、知识缺口、最佳实践
- `ERRORS.md` — 命令失败、异常
- `FEATURE_REQUESTS.md` — 用户请求的功能

### 提升目标

当学习内容被证明具有广泛适用性时，将它们提升到工作区文件中：

| Learning Type | Promote To | Example |
|---------------|------------|---------|
| Behavioral patterns | `SOUL.md` | "简洁明了，避免免责声明" |
| Workflow improvements | `AGENTS.md` | "为长期任务生成子代理" |
| Tool gotchas | `TOOLS.md` | "Git push 需要先配置身份验证" |

### 会话间通信

OpenClaw 提供了跨会话共享学习内容的工具：

- **sessions_list** — 查看活动/最近的会话
- **sessions_history** — 读取另一个会话的记录
- **sessions_send** — 向另一个会话发送学习内容
- **sessions_spawn** — 为后台工作生成子代理

### 可选：启用钩子

为了在会话开始时自动提醒：

```bash
# 将钩子复制到 OpenClaw 钩子目录
cp -r hooks/openclaw ~/.openclaw/hooks/self-improvement

# 启用它
openclaw hooks enable self-improvement
```

有关完整详情，请参阅 `references/openclaw-integration.md`。

---

## 通用设置（其他代理）

对于 Claude Code、Codex、Copilot 或其他代理，在您的项目中创建 `.learnings/`：

```bash
mkdir -p .learnings
```

从 `assets/` 复制模板或创建带标题的文件。

### 在代理文件 AGENTS.md、CLAUDE.md 或 .github/copilot-instructions.md 中添加引用，提醒自己记录学习内容。（这是基于钩子的提醒的替代方案）

#### 自我改进工作流程

当错误或修正发生时：
1. 记录到 `.learnings/ERRORS.md`、`LEARNINGS.md` 或 `FEATURE_REQUESTS.md`
2. 审查并推广广泛适用的学习内容到：
   - `CLAUDE.md` - 项目事实和约定
   - `AGENTS.md` - 工作流程和自动化
   - `.github/copilot-instructions.md` - Copilot 上下文

## 记录格式

### 学习条目

追加到 `.learnings/LEARNINGS.md`：

```markdown
## [LRN-YYYYMMDD-XXX] 类别

**记录时间**: ISO-8601 时间戳
**优先级**: 低 | 中 | 高 | 关键
**状态**: 待处理
**领域**: 前端 | 后端 | 基础设施 | 测试 | 文档 | 配置

### 摘要
所学内容的一行描述

### 详情
完整上下文：发生了什么，什么错了，什么是对的

### 建议行动
要做的具体修复或改进

### 元数据
- 来源: 对话 | 错误 | 用户反馈
- 相关文件: path/to/file.ext
- 标签: tag1, tag2
- 另请参阅: LRN-20250110-001（如果与现有条目相关）
- 模式键: simplify.dead_code | harden.input_validation（可选，用于重复模式跟踪）
- 重复次数: 1（可选）
- 首次出现: 2025-01-15（可选）
- 最后出现: 2025-01-15（可选）

---
```

### 错误条目

追加到 `.learnings/ERRORS.md`：

```markdown
## [ERR-YYYYMMDD-XXX] 技能或命令名称

**记录时间**: ISO-8601 时间戳
**优先级**: 高
**状态**: 待处理
**领域**: 前端 | 后端 | 基础设施 | 测试 | 文档 | 配置

### 摘要
失败内容的简要描述

### 错误
```
实际错误消息或输出
```

### 上下文
- 尝试的命令/操作
- 使用的输入或参数
- 相关的环境详情（如果适用）
```

### 建议的修复
如果可识别，可能解决此问题的方法

### 元数据
- 可重现：是 | 否 | 未知
- 相关文件：path/to/file.ext
- 另请参阅：ERR-20250110-001（如果重复出现）

---

### 功能请求条目

附加到 `.learnings/FEATURE_REQUESTS.md`：

```markdown
## [FEAT-YYYYMMDD-XXX] capability_name

**记录时间**：ISO-8601 时间戳
**优先级**：中等
**状态**：待处理
**领域**：前端 | 后端 | 基础设施 | 测试 | 文档 | 配置

### 请求的功能
用户想要做什么

### 用户上下文
为什么他们需要它，他们正在解决什么问题

### 复杂度估计
简单 | 中等 | 复杂

### 建议的实现
如何构建它，它可能扩展什么

### 元数据
- 频率：首次 | 重复
- 相关功能：现有功能名称

---
```

## ID 生成

格式：`TYPE-YYYYMMDD-XXX`
- 类型：`LRN`（学习），`ERR`（错误），`FEAT`（功能）
- YYYYMMDD：当前日期
- XXX：序列号或随机3个字符（例如：`001`，`A7B`）

示例：`LRN-20250115-001`，`ERR-20250115-A3F`，`FEAT-20250115-002`

## 解决条目

当问题已修复时，更新条目：

1. 将 `**状态**：待处理` 更改为 `**状态**：已解决`
2. 在元数据后添加解决块：

```markdown
### 解决方案
- **解决时间**：2025-01-16T09:00:00Z
- **提交/PR**：abc123 或 #42
- **备注**：对所做工作的简要描述
```

其他状态值：
- `进行中` - 正在积极处理中
- `不修复` - 决定不处理（在解决方案备注中添加原因）
- `已提升` - 提升到 CLAUDE.md、AGENTS.md 或 .github/copilot-instructions.md

## 提升到项目记忆

当学习内容具有广泛适用性（不是一次性修复）时，将其提升到永久项目记忆中。

### 何时提升

- 学习内容适用于多个文件/功能
- 任何贡献者（人类或 AI）应该知道的知识
- 防止重复出现的错误
- 记录项目特定的约定

### 提升目标

| 目标 | 适合放置的内容 |
|--------|-------------------|
| `CLAUDE.md` | 所有 Claude 交互的项目事实、约定、陷阱 |
| `AGENTS.md` | 特定于代理的工作流程、工具使用模式、自动化规则 |
| `.github/copilot-instructions.md` | GitHub Copilot 的项目上下文和约定 |
| `SOUL.md` | 行为准则、沟通风格、原则（OpenClaw 工作区） |
| `TOOLS.md` | 工具功能、使用模式、集成陷阱（OpenClaw 工作区） |

### 如何提升

1. **提炼**学习内容为简洁的规则或事实
2. **添加**到目标文件的适当部分（如需要则创建文件）
3. **更新**原始条目：
   - 将 `**状态**：待处理` 更改为 `**状态**：已提升`
   - 添加 `**提升至**：CLAUDE.md`、`AGENTS.md` 或 `.github/copilot-instructions.md`

### 提升示例

**学习**（详细）：
> 项目使用 pnpm 工作区。尝试了 `npm install` 但失败了。
> 锁定文件是 `pnpm-lock.yaml`。必须使用 `pnpm install`。

**在 CLAUDE.md** (简洁):
```markdown
## 构建与依赖
- 包管理器: pnpm (非 npm) - 使用 `pnpm install`
```

**学习** (详细):
> 修改 API 端点时，必须重新生成 TypeScript 客户端。
> 忘记这样做会导致运行时类型不匹配。

**在 AGENTS.md** (可操作):
```markdown
## API 变更后
1. 重新生成客户端: `pnpm run generate:api`
2. 检查类型错误: `pnpm tsc --noEmit`
```

## 重复模式检测

如果记录的内容与现有条目相似：

1. **先搜索**: `grep -r "keyword" .learnings/`
2. **链接条目**: 在元数据中添加 `**另请参见**: ERR-20250110-001`
3. **提高优先级** 如果问题反复出现
4. **考虑系统性修复**: 重复出现的问题通常表明：
   - 缺少文档 (→ 提升到 CLAUDE.md 或 .github/copilot-instructions.md)
   - 缺少自动化 (→ 添加到 AGENTS.md)
   - 架构问题 (→ 创建技术债务票)

## 简化与强化信息流

使用此工作流程从 `simplify-and-harden` 技能中摄取重复模式，并将它们转化为持久的提示指导。

### 摄取工作流程

1. 从任务摘要中读取 `simplify_and_harden.learning_loop.candidates`。
2. 对于每个候选，使用 `pattern_key` 作为稳定的去重键。
3. 在 `.learnings/LEARNINGS.md` 中搜索具有该键的现有条目：
   - `grep -n "Pattern-Key: <pattern_key>" .learnings/LEARNINGS.md`
4. 如果找到：
   - 增加 `Recurrence-Count`
   - 更新 `Last-Seen`
   - 添加 `See Also` 链接到相关条目/任务
5. 如果未找到：
   - 创建新的 `LRN-...` 条目
   - 设置 `Source: simplify-and-harden`
   - 设置 `Pattern-Key`、`Recurrence-Count: 1` 和 `First-Seen`/`Last-Seen`

### 推广规则 (系统提示反馈)

当以下所有条件都满足时，将重复模式推广到代理上下文/系统提示文件中：

- `Recurrence-Count >= 3`
- 至少在 2 个不同任务中出现过
- 在 30 天的时间窗口内发生

推广目标：
- `CLAUDE.md`
- `AGENTS.md`
- `.github/copilot-instructions.md`
- `SOUL.md` / `TOOLS.md` 适用于 OpenClaw 工作区级别的指导（当适用时）

将推广的规则编写为简短的预防规则（编码前/编码时该做什么），而不是冗长的事件报告。

## 定期审查

在自然断点处审查 `.learnings/`：

### 何时审查
- 开始新的主要任务前
- 完成功能后
- 在有过去经验教训的区域工作时
- 在活跃开发期间每周一次

### 快速状态检查
```bash
# 计待处理项目
grep -h "Status\*\*: pending" .learnings/*.md | wc -l

# 列出待处理的高优先级项目
grep -B5 "Priority\*\*: high" .learnings/*.md | grep "^## \["

# 查找特定领域的经验教训
grep -l "Area\*\*: backend" .learnings/*.md
```

### 审查行动
- 解决已修复的项目
- 推广适用的经验教训
- 链接相关条目
- 升级重复出现的问题

## 检测触发器

当你注意到时自动记录：

**更正** (→ 使用 `correction` 类别的学习):
- "不，那不对..."
- "实际上，应该是..."
- "你关于...是错的"
- "那已经过时了..."

**功能请求** (→ feature request):
- "你还能..."
- "我希望你能..."
- "有没有办法..."
- "你为什么不能..."

**知识缺口** (→ 使用 `knowledge_gap` 类别的学习):
- 用户提供了你不知道的信息
- 你引用的文档已过时
- API行为与你的理解不同

**错误** (→ error entry):
- 命令返回非零退出代码
- 异常或堆栈跟踪
- 意外的输出或行为
- 超时或连接失败

## 优先级指南

| 优先级 | 使用场景 |
|----------|-------------|
| `critical` | 阻止核心功能，有数据丢失风险，安全问题 |
| `high` | 重大影响，影响常见工作流程，重复性问题 |
| `medium` | 中等影响，存在解决方法 |
| `low` | 轻微不便，边缘情况，锦上添花的功能 |

## 区域标签

用于按代码库区域筛选学习内容：

| 区域 | 范围 |
|------|-------|
| `frontend` | UI，组件，客户端代码 |
| `backend` | API，服务，服务器端代码 |
| `infra` | CI/CD，部署，Docker，云服务 |
| `tests` | 测试文件，测试工具，覆盖率 |
| `docs` | 文档，注释，README |
| `config` | 配置文件，环境，设置 |

## 最佳实践

1. **立即记录** - 问题刚发生时上下文最新鲜
2. **具体明确** - 未来的代理需要快速理解
3. **包含复现步骤** - 特别是对于错误
4. **链接相关文件** - 使修复更容易
5. **建议具体修复** - 而不仅仅是"调查"
6. **使用一致的类别** - 便于筛选
7. **积极推广** - 如果有疑问，添加到 CLAUDE.md 或 .github/copilot-instructions.md
8. **定期审查** - 过时的学习内容会失去价值

## Gitignore 选项

**将学习内容保留在本地** (每个开发者):
```gitignore
.learnings/
```

**在仓库中跟踪学习内容** (团队范围):
不要添加到 .gitignore - 学习内容成为共享知识。

**混合模式** (跟踪模板，忽略条目):
```gitignore
.learnings/*.md
!.learnings/.gitkeep
```

## 钩子集成

通过代理钩子启用自动提醒。这是**可选的** - 您必须明确配置钩子。

### 快速设置 (Claude Code / Codex)

在项目中创建 `.claude/settings.json`:

```json
{
  "hooks": {
    "UserPromptSubmit": [{
      "matcher": "",
      "hooks": [{
        "type": "command",
        "command": "./skills/self-improvement/scripts/activator.sh"
      }]
    }]
  }
}
```

这会在每次提示后注入一个学习评估提醒（约50-100个标记的开销）。

### 完整设置 (包含错误检测)

```json
{
  "hooks": {
    "UserPromptSubmit": [{
      "matcher": "",
      "hooks": [{
        "type": "command",
        "command": "./skills/self-improvement/scripts/activator.sh"
      }]
    }],
    "PostToolUse": [{
      "matcher": "Bash",
      "hooks": [{
        "type": "command",
        "command": "./skills/self-improvement/scripts/error-detector.sh"
      }]
    }]
  }
}
```

### 可用的钩子脚本

| 脚本 | 钩子类型 | 用途 |
|--------|-----------|---------|
| `scripts/activator.sh` | UserPromptSubmit | 提醒在任务后评估学习内容 |
| `scripts/error-detector.sh` | PostToolUse (Bash) | 在命令错误时触发 |

有关详细配置和故障排除，请参阅 `references/hooks-setup.md`。

## 自动技能提取

当学习内容足够有价值，可以成为可重用技能时，使用提供的辅助工具进行提取。

### 技能提取标准

当满足以下任一条件时，学习内容符合技能提取标准：

| 标准 | 描述 |
|-----------|-------------|
| **重复性** | 有指向2个以上类似问题的"另请参阅"链接 |
| **已验证** | 状态为"已解决"且修复有效 |
| **非显而易见** | 需要实际调试/调查才能发现 |
| **广泛适用性** | 非项目特定；可在多个代码库中应用 |
| **用户标记** | 用户说"将此保存为技能"或类似表述 |

### 提取工作流程

1. **识别候选技能**：学习内容符合提取标准
2. **运行辅助工具**（或手动创建）：
   ```bash
   ./skills/self-improvement/scripts/extract-skill.sh skill-name --dry-run
   ./skills/self-improvement/scripts/extract-skill.sh skill-name
   ```
3. **自定义SKILL.md**：使用学习内容填写模板
4. **更新学习内容**：将状态设置为"promoted_to_skill"，添加"Skill-Path"
5. **验证**：在新会话中阅读技能，确保其自包含

### 手动提取

如果您更喜欢手动创建：

1. 创建 `skills/<skill-name>/SKILL.md`
2. 使用 `assets/SKILL-TEMPLATE.md` 中的模板
3. 遵循 [Agent Skills 规范](https://agentskills.io/specification)：
   - 包含 `name` 和 `description` 的 YAML 前置元数据
   - 名称必须与文件夹名称匹配
   - 技能文件夹内不得有 README.md

### 提取检测触发器

注意这些表明学习内容应成为技能的信号：

**在对话中：**
- "将此保存为技能"
- "我经常遇到这个问题"
- "这对其他项目会有用"
- "记住这个模式"

**在学习条目中：**
- 多个"另请参阅"链接（重复问题）
- 高优先级 + 已解决状态
- 类别：具有广泛适用性的 `best_practice`
- 用户反馈称赞解决方案

### 技能质量检查

提取前，请验证：

- [ ] 解决方案已测试且正常工作
- [ ] 描述清晰，无需原始上下文
- [ ] 代码示例是自包含的
- [ ] 没有项目特定的硬编码值
- [ ] 遵循技能命名约定（小写，连字符）

## 多代理支持

此技能适用于不同的AI编码助手，并具有针对特定助手的激活方式。

### Claude Code

**激活方式**：钩子（UserPromptSubmit, PostToolUse）
**设置**：使用钩子配置创建 `.claude/settings.json`
**检测**：通过钩子脚本自动检测

### Codex CLI

**激活方式**：钩子（与Claude Code相同的模式）
**设置**：使用钩子配置创建 `.codex/settings.json`
**检测**：通过钩子脚本自动检测

### GitHub Copilot

**激活方式**：手动（不支持钩子）
**设置**：添加到 `.github/copilot-instructions.md`:

```markdown
## 自我提升

解决非显而易见的问题后，考虑记录到 `.learnings/`：
1. 使用自我提升技能的格式
2. 使用"另请参阅"链接相关条目
3. 将高价值的学习内容提升为技能

在聊天中询问："我应该将此记录为学习内容吗？"
```

**检测**：会话结束时手动检查

### OpenClaw

**激活方式**：工作区注入 + 代理间消息传递
**设置**：参见上方的"OpenClaw设置"部分
**检测**：通过会话工具和工作区文件

### 通用代理指导

无论使用哪个助手，在以下情况应用自我提升：

1. **发现非显而易见的内容** - 解决方案不是立即得出的
2. **纠正自己** - 最初的方法是错误的
3. **学习项目约定** - 发现了未记录的模式
4. **遇到意外错误** - 特别是诊断困难的情况
5. **找到更好的方法** - 改进了原始解决方案

### Copilot聊天集成

对于Copilot用户，在相关提示中添加以下内容：

> 完成此任务后，评估是否应使用自我提升技能格式将任何学习内容记录到 `.learnings/`。

或使用快速提示：
- "将此记录到学习内容中"
- "从此解决方案创建技能"
- "检查 .learnings/ 中的相关问题"