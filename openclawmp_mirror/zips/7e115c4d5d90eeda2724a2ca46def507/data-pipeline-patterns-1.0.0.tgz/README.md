# 数据管线设计模式

## 核心模式
1. Lambda：批处理 + 速度层（精度+实时，两套代码）
2. Kappa：全流处理（简单，重处理复杂）
3. CDC：捕获数据库变更（Debezium/Canal，零侵入）
4. Event Sourcing：事件存储（完整审计，可回放）
5. CQRS：读写分离优化

## 选择指南
- 实时 <1min -> Flink/Kafka
- 实时 <1h -> Spark Streaming
- 实时 <1d -> Airflow
- <1GB/day -> 脚本+Cron
- >1TB/day -> 分布式

## 数据质量
- Dead Letter Queue（失败消息）
- Schema Registry（版本管理）
- Data Contract（SLA 约定）
