# Expert Panel 数据结构设计

## 文件夹结构详解

### sessions/ 目录

所有话题的存储根目录。

### 单个话题文件夹命名规范

```
{YYYYMMDD}_{NNN}_{topic_short_name}

示例：
- 20240226_001_AI产品决策
- 20240225_003_技术架构选型
```

### 文件说明

| 文件/文件夹 | 用途 | 格式 |
|-----------|------|------|
| `config.yaml` | 话题配置信息 | YAML |
| `history.md` | 完整讨论历史 | Markdown |
| `summary.md` | 当前阶段总结 | Markdown |
| `experts/` | 专家角色定义 | Markdown |
| `rounds/` | 每轮讨论记录 | Markdown |

## 数据生命周期

```
创建话题
    ↓
初始化配置 → 创建专家定义 → 执行讨论
    ↓
保存轮次记录 → 更新历史 → 生成总结
    ↓
继续讨论（循环）
    ↓
话题完成 → 可选归档
```

## 追加讨论的数据处理

1. 读取 `config.yaml` 获取当前状态
2. 读取 `history.md` 了解讨论上下文
3. 读取 `summary.md` 了解当前结论
4. 执行新轮次讨论
5. 追加新记录到 `rounds/`
6. 更新 `history.md` 和 `summary.md`
7. 更新 `config.yaml` 中的时间戳和状态
