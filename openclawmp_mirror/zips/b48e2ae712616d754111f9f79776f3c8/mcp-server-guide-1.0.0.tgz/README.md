# MCP Server 开发指南

MCP = AI Agent 与外部工具交互的标准协议。

## 三种能力
1. Tools：Agent 可调用的函数
2. Resources：Agent 可读取的数据
3. Prompts：预定义提示词模板

## 快速开始
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js"
const server = new McpServer({name:"my-tools",version:"1.0.0"})
server.tool("search",{query:z.string()},async({query})=>({...}))
server.resource("config","config://app",async()=>({...}))
await server.connect(new StdioServerTransport())

## 最佳实践
- 工具名：动词+名词 (search_, create_)
- Zod schema 验证输入
- 错误信息清晰友好
- 长操作支持 progress
