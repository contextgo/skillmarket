---
name: altium-designer-workflow
description: "Altium Designer PCB 工程自动化工作流，兼容 AD09 ~ AD24。覆盖工程打开、DRC 检查、BOM 导出、Gerber 生成、丝印优化全流程。Use when: user asks to open AD projects, run design rule checks, export BOMs, generate Gerber/NC Drill files, optimize silkscreen, automate Altium Designer tasks, or any PCB design workflow involving Altium Designer (.PrjPcb, .SchDoc, .PcbDoc). Triggers: 打开 AD 工程, DRC 检查, 导出 BOM, 生成 Gerber, 丝印优化, Altium, AD 设计, PCB 出图"
---

# Altium Designer PCB 工程自动化工作流

## 前置条件

- Windows 系统，已安装 Altium Designer（AD09 ~ AD24）
- Altium Designer 可被 COM 自动化控制（默认启用）
- Python 3.8+，已安装 `pywin32`：`pip install pywin32`

### AD09 兼容性

COM ProgID 自动适配：AD18+ 用 `Altium.Application`，AD09~AD17 用 `AltiumDesigner.Application`。
AD09 对 COM API 支持有限，部分操作（DRC、Gerber）会回退到 SendKeys 方式。

## 核心架构

所有操作通过 **Altium COM API** 执行。统一入口：

```python
import win32com.client
ad = win32com.client.Dispatch("Altium.Application")
```

关键对象层级：`Application → WorkspaceManager → Document`
- `AD.WorkspaceManager.GetWorkspaceFromPath(path)` — 打开工程
- `AD.WorkspaceManager.DM_GetWorkspace` — 当前工程
- `AD.GetCurrentDocument()` — 当前活动文档

## 操作流程

### 1. 打开工程

调用 `scripts/open_project.py`：

```bash
python scripts/open_project.py "C:\path\to\Project.PrjPcb"
```

逻辑：
1. 通过 COM 获取 `Application` 对象
2. 调用 `WorkspaceManager.GetWorkspaceFromPath` 加载 `.PrjPcb`
3. 等待 AD 加载完成（轮询 `DM_GetWorkspace` 直到非空）
4. 列出工程中所有文档（`.SchDoc`, `.PcbDoc`, `.OutJob` 等）

### 2. DRC 检查

调用 `scripts/run_drc.py`：

```bash
python scripts/run_drc.py "C:\path\to\Project.PrjPcb" --output "C:\output\drc_report.html"
```

逻辑：
1. 确保 PCB 文档已打开
2. 通过 COM 执行菜单命令 `Tools → Design Rule Check`
3. 使用 `RunProcess` 触发 DRC：
   ```python
   ad.Server.ProcessMessage("PCB:RunDesignRuleCheck")
   ```
4. 等待 DRC 完成，读取生成的报告文件
5. 解析报告，输出统计信息（错误数、警告数、按类别分组）

**DRC 关键规则检查项：**
- 间距规则（Clearance）
- 短路（Short Circuit）
- 未布线网络（Un-Routed Nets）
- 线宽约束（Width Constraint）
- 过孔约束（Via Style）
- 丝印间距（Silkscreen Clearance）

**快速 DRC 快捷键方式**（备用）：
```python
import win32com.client
shell = win32com.client.Dispatch("WScript.Shell")
shell.AppActivate("Altium Designer")
shell.SendKeys("^T^D")  # Ctrl+T, Ctrl+D 打开 DRC 对话框
```

### 3. BOM 导出

调用 `scripts/export_bom.py`：

```bash
python scripts/export_bom.py "C:\path\to\Project.PrjPcb" --output "C:\output\BOM.xlsx" --format xlsx
```

支持的格式：`csv`, `xlsx`, `html`

逻辑：
1. 遍历工程所有 `.SchDoc` 原理图文档
2. 通过 `Report` 菜单或 COM API 获取元件列表
3. 提取字段：`Designator`, `Comment`, `Description`, `Footprint`, `Quantity`, `Manufacturer`, `MPN`
4. 按 `Comment` 聚合相同元件，计算 `Quantity`
5. 按指定格式输出

**CSV 格式**（最简方案）：
```python
# 读取原理图
sch = ad.GetCurrentDocument()
components = []
for sheet in sch.SchIterator_Create():
    for comp in sheet.GetChildObjects():
        if comp.Kind() == 2:  # SchComponent
            components.append({
                "Designator": comp.Designator.Text,
                "Comment": comp.Comment.Text,
                "Description": comp.Description.Text,
                "Footprint": comp.GetState_Current().GetFootprintName(),
            })
    sch.SchIterator_Destroy(sheet)
```

### 4. Gerber 生成

调用 `scripts/generate_gerber.py`：

```bash
python scripts/generate_gerber.py "C:\path\to\Project.PrjPcb" --output-dir "C:\output\Gerber" --layers top,bottom,power,silkscreen,paste,paste_bottom --format RS-274X
```

**标准 Gerber 层叠：**

| 层 | Gerber 扩展名 | 说明 |
|---|---|---|
| Top Layer | `.GTL` | 顶层走线 |
| Bottom Layer | `.GBL` | 底层走线 |
| Power Plane | `.GP1`, `.GP2` | 电源/地层 |
| Top Paste | `.GTP` | 顶层锡膏 |
| Bottom Paste | `.GBP` | 底层锡膏 |
| Top Silkscreen | `.GTO` | 顶层丝印 |
| Bottom Silkscreen | `.GBO` | 底层丝印 |
| Top Solder | `.GTS` | 顶层阻焊 |
| Bottom Solder | `.GBS` | 底层阻焊 |
| Drill (NC) | `.TXT` | 钻孔文件 |

**生成方式**（推荐 OutJob）：
如果工程包含 `.OutJob` 文件，直接运行：
```python
ad.Server.ProcessMessage("Workspace:RunOutputJob")
```

**纯 COM 方案**（无 OutJob 时）：
1. 打开 PCB 文档
2. 通过 `File → Fabrication Outputs → Gerber Files`
3. 使用 `SendKeys` 配置层叠并导出
4. 对 NC Drill 重复：`File → Fabrication Outputs → NC Drill Files`

### 5. 丝印优化

调用 `scripts/optimize_silkscreen.py`：

```bash
python scripts/optimize_silkscreen.py "C:\path\to\Project.PrjPcb" --min-height 0.8 --clearance 0.2
```

**优化规则：**

| 参数 | 建议值 | 说明 |
|---|---|---|
| 最小字符高度 | ≥ 0.8mm | PCB 制造可读性下限 |
| 字符线宽 | ≥ 0.127mm (5mil) | 标准制板工艺 |
| 丝印到焊盘间距 | ≥ 0.2mm | 避免丝印上锡膏 |
| 丝印到元件间距 | ≥ 0.25mm | 避免干涉 |
| 极性标识 | 必须 | PIN1 标记用圆点 + 文字双重标记 |

**优化流程：**
1. 遍历 PCB 所有丝印层（Top/Bottom Overlay）对象
2. 检测违规：文字过小、与焊盘重叠、被元件遮挡
3. 自动调整：缩小字号、移动位置、旋转角度
4. 生成修改报告，列出所有调整项
5. **不直接保存**，先让用户审查（安全规则）

## 一键全流程

调用 `scripts/full_workflow.py` 一次性执行所有步骤：

```bash
python scripts/full_workflow.py "C:\path\to\Project.PrjPcb" --output-dir "C:\output"
```

执行顺序：
1. 打开工程 → 列出文档清单
2. DRC 检查 → 输出报告，显示错误/警告统计
3. 导出 BOM → 生成 xlsx 文件
4. 生成 Gerber + NC Drill → 输出到 `output/Gerber/`
5. 丝印分析 → 输出优化建议报告

## 错误处理

- **COM 连接失败**：检查 Altium Designer 是否正在运行；未运行则尝试启动
- **文件路径错误**：验证 `.PrjPcb` 路径是否存在
- **DRC 报告未生成**：检查 AD 版本兼容性，回退到快捷键方案
- **Gerber 生成失败**：检查是否缺少 OutJob，回退到 SendKeys 方案

## 参考文档

- 详细信息（API 参考、各版本差异、高级配置）：见 `references/api-guide.md`
- OutJob 配置模板：见 `references/outjob-template.md`
