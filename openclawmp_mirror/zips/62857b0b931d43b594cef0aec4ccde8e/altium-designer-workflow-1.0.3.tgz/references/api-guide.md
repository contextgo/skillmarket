# Altium Designer COM API 参考指南

## COM 对象模型

```
Altium.Application (ProgID: "Altium.Application")
├── GetVersion()              → 版本号
├── GetCurrentDocument()      → 当前活动文档
├── Server                    → IServer interface
│   └── ProcessMessage(cmd)   → 执行菜单命令
├── WorkspaceManager
│   ├── GetWorkspaceFromPath(path) → 打开工程
│   └── DM_GetWorkspace()          → 当前工程
└── SchServer / PCBServer          → 专用服务器
```

## 常用 ProcessMessage 命令

| 功能 | 命令 |
|---|---|
| DRC 检查 | `PCB:RunDesignRuleCheck` |
| 运行 OutJob | `Workspace:RunOutputJob` |
| 生成 Gerber | `PCB:GenerateGerber` |
| 生成 NC Drill | `PCB:GenerateNCDrill` |
| 原理图编译 | `Sch:Compile` |
| PCB 网络更新 | `PCB:UpdateFromSchematic` |

## 版本差异

- AD 18-20: COM API 基本稳定
- AD 21+: 部分接口路径变化，`PCBServer` 获取方式有差异
- AD 23+: 引入了新的 `IServer` 接口，旧方式仍可兼容

## 故障排查

- COM 初始化失败 → 确保调用 `pythoncom.CoInitialize()`
- 无法连接 → 先启动 AD 再运行脚本
- SendKeys 失效 → 检查 AD 窗口是否在顶层
