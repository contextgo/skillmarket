#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
丝印优化 - 分析并建议 PCB 丝印层优化方案
用法: python optimize_silkscreen.py "C:\path\to\Project.PrjPcb" [--min-height 0.8] [--clearance 0.2]
"""

import sys
import os
import time
import argparse
import win32com.client
import pythoncom


# 默认工艺约束
DEFAULT_MIN_HEIGHT = 0.8       # mm, 最小字符高度
DEFAULT_MIN_LINE_WIDTH = 0.127 # mm (5mil), 最小线宽
DEFAULT_CLEARANCE_PAD = 0.2    # mm, 丝印到焊盘间距
DEFAULT_CLEARANCE_COMP = 0.25  # mm, 丝印到元件间距


def get_or_start_ad():
    prog_ids = ["Altium.Application", "AltiumDesigner.Application"]
    for prog_id in prog_ids:
        try:
            return win32com.client.Dispatch(prog_id)
        except Exception:
            pass
        try:
            return win32com.client.GetActiveObject(prog_id)
        except Exception:
            pass
    print("[ERROR] 无法连接到 Altium Designer。")
    sys.exit(1)


def analyze_silkscreen(pcb_doc, min_height, clearance_pad):
    """分析 PCB 丝印层，返回违规列表"""
    issues = []
    try:
        # 遍历丝印层对象 (TopOverlay / BottomOverlay)
        # Layer 29 = Top Overlay, Layer 30 = Bottom Overlay
        silkscreen_layers = [29, 30]
        layer_names = {29: "Top Silkscreen", 30: "Bottom Silkscreen"}

        # 通过 PCBServer 获取文档接口
        pcb_server = pcb_doc.PCBServer
        if not pcb_server:
            print("     无法获取 PCBServer，使用替代方案...")
            # 备用方案：通过遍历
            for layer in silkscreen_layers:
                try:
                    iterator = pcb_doc.Iterator_Create()
                    for obj in iterator:
                        if hasattr(obj, 'Layer') and obj.Layer == layer:
                            issue = check_silkscreen_object(obj, layer_names[layer], min_height, clearance_pad)
                            if issue:
                                issues.append(issue)
                    pcb_doc.Iterator_Destroy(iterator)
                except Exception as e:
                    print(f"     层 {layer_names[layer]} 遍历警告: {e}")
            return issues

        for layer in silkscreen_layers:
            try:
                iterator = pcb_doc.Iterator_Create()
                for obj in iterator:
                    if hasattr(obj, 'Layer') and obj.Layer == layer:
                        issue = check_silkscreen_object(obj, layer_names[layer], min_height, clearance_pad)
                        if issue:
                            issues.append(issue)
                pcb_doc.Iterator_Destroy(iterator)
            except Exception as e:
                print(f"     层 {layer_names[layer]} 遍历警告: {e}")

    except Exception as e:
        print(f"     分析过程出错: {e}")

    return issues


def check_silkscreen_object(obj, layer_name, min_height, clearance_pad):
    """检查单个丝印对象是否有违规"""
    issue = None

    # 检查 Text 对象
    if hasattr(obj, 'Text') and hasattr(obj, 'Height'):
        try:
            height = obj.Height  # 通常以 mil 为单位
            height_mm = height * 0.0254  # mil -> mm

            if height_mm < min_height:
                issue = {
                    "type": "字符过小",
                    "layer": layer_name,
                    "detail": f"字符高度 {height_mm:.2f}mm < 最小 {min_height}mm",
                    "object": getattr(obj, 'Text', 'N/A'),
                    "suggestion": f"增大字符高度至 ≥ {min_height}mm ({min_height/0.0254:.1f}mil)",
                    "severity": "⚠️",
                }
        except Exception:
            pass

    # 检查 Track/Line 丝印线宽
    if hasattr(obj, 'Width'):
        try:
            width = obj.Width
            width_mm = width * 0.0254
            if width_mm < DEFAULT_MIN_LINE_WIDTH:
                issue = {
                    "type": "线宽过细",
                    "layer": layer_name,
                    "detail": f"丝印线宽 {width_mm:.3f}mm < 最小 {DEFAULT_MIN_LINE_WIDTH}mm (5mil)",
                    "object": "Track",
                    "suggestion": f"增大线宽至 ≥ {DEFAULT_MIN_LINE_WIDTH}mm (5mil)",
                    "severity": "⚠️",
                }
        except Exception:
            pass

    # 检查重叠焊盘
    if hasattr(obj, 'X') and hasattr(obj, 'Y'):
        try:
            x, y = obj.X, obj.Y
            # 简化检查：实际应检测与 pad 的间距
            # 这里只做存在性标记
        except Exception:
            pass

    return issue


def generate_report(issues, output_path):
    """生成优化建议报告"""
    lines = [
        "=" * 60,
        "Altium Designer 丝印优化报告",
        "=" * 60,
        f"共发现 {len(issues)} 项问题",
        "",
    ]

    # 按类型分类统计
    by_type = {}
    for issue in issues:
        t = issue["type"]
        by_type.setdefault(t, []).append(issue)

    for issue_type, items in by_type.items():
        lines.append(f"\n📋 {issue_type} ({len(items)} 项)")
        lines.append("-" * 40)
        for item in items[:10]:  # 最多显示 10 条
            lines.append(f"  {item['severity']} {item['detail']}")
            lines.append(f"     → {item['suggestion']}")
        if len(items) > 10:
            lines.append(f"  ... 还有 {len(items) - 10} 项")

    lines.append("\n" + "=" * 60)
    lines.append("建议操作步骤:")
    lines.append("1. 在 AD 中按上述建议逐项修改")
    lines.append("2. 修改后重新运行检查")
    lines.append("3. 确认无严重问题后再出 Gerber")
    lines.append("=" * 60)

    report = "\n".join(lines)

    if output_path:
        out_dir = os.path.dirname(output_path)
        if out_dir and not os.path.exists(out_dir):
            os.makedirs(out_dir, exist_ok=True)
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report)
        print(f"     报告已保存: {output_path}")

    return report


def optimize_silkscreen(prj_path, min_height=DEFAULT_MIN_HEIGHT,
                        clearance_pad=DEFAULT_CLEARANCE_PAD, output_path=None):
    if not os.path.exists(prj_path):
        print(f"[ERROR] 工程文件不存在: {prj_path}")
        sys.exit(1)

    ad = get_or_start_ad()

    print("[1/4] 打开工程...")
    workspace = ad.WorkspaceManager.GetWorkspaceFromPath(prj_path)
    time.sleep(2)

    # 找到 PCB 文档
    print("[2/4] 查找 PCB 文档...")
    pcb_doc = None
    for doc in workspace.Documents:
        name = doc.GetName() if hasattr(doc, 'GetName') else ''
        if name.lower().endswith('.pcbdoc'):
            pcb_doc = doc
            print(f"     找到: {name}")
            break

    if not pcb_doc:
        print("[ERROR] 工程中未找到 .PcbDoc 文件。")
        sys.exit(1)

    # 分析
    print("[3/4] 分析丝印层...")
    print(f"     参数: 最小高度={min_height}mm, 焊盘间距={clearance_pad}mm")
    issues = analyze_silkscreen(pcb_doc, min_height, clearance_pad)

    # 报告
    print("[4/4] 生成优化报告...")
    report = generate_report(issues, output_path)

    # 输出到终端
    if not output_path:
        print(f"\n{report}")

    print(f"\n✅ 分析完成。共 {len(issues)} 项需要关注。")
    print("   ⚠️ 以上为建议项，不会自动修改。请审查后再操作。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Altium Designer 丝印优化分析")
    parser.add_argument("project", help="工程路径 (.PrjPcb)")
    parser.add_argument("--min-height", type=float, default=DEFAULT_MIN_HEIGHT,
                        help=f"最小字符高度 mm (默认 {DEFAULT_MIN_HEIGHT})")
    parser.add_argument("--clearance", type=float, default=DEFAULT_CLEARANCE_PAD,
                        help=f"丝印到焊盘最小间距 mm (默认 {DEFAULT_CLEARANCE_PAD})")
    parser.add_argument("--output", "-o", help="输出报告路径", default="silkscreen_report.txt")
    args = parser.parse_args()
    pythoncom.CoInitialize()
    try:
        optimize_silkscreen(args.project, args.min_height, args.clearance, args.output)
    finally:
        pythoncom.CoUninitialize()
