#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
DRC 设计规则检查
用法: python run_drc.py "C:\path\to\Project.PrjPcb" [--output drc_report.html]
"""

import sys
import os
import time
import argparse
import win32com.client
import pythoncom


def get_or_start_ad():
    prog_ids = [
        "Altium.Application",       # AD18+
        "AltiumDesigner.Application", # AD09~AD17
    ]
    for prog_id in prog_ids:
        try:
            return win32com.client.Dispatch(prog_id)
        except Exception:
            pass
        try:
            return win32com.client.GetActiveObject(prog_id)
        except Exception:
            pass
    print("[ERROR] 无法连接到 Altium Designer。")
    sys.exit(1)


def run_drc(prj_path, output_path=None):
    if not os.path.exists(prj_path):
        print(f"[ERROR] 工程文件不存在: {prj_path}")
        sys.exit(1)

    ad = get_or_start_ad()

    # 打开工程
    print("[1/4] 打开工程...")
    workspace = ad.WorkspaceManager.GetWorkspaceFromPath(prj_path)
    time.sleep(3)

    # 找到 PCB 文档
    print("[2/4] 查找 PCB 文档...")
    pcb_doc = None
    for doc in workspace.Documents:
        name = doc.GetName() if hasattr(doc, 'GetName') else ''
        if name.lower().endswith('.pcbdoc'):
            pcb_doc = doc
            print(f"     找到: {name}")
            break

    if not pcb_doc:
        print("[ERROR] 工程中未找到 .PcbDoc 文件。")
        sys.exit(1)

    # 打开 PCB 文档
    print("[3/4] 运行 DRC 检查...")
    try:
        # 方法 1: 通过 Server 执行 DRC
        server = ad.Server
        server.ProcessMessage("PCB:RunDesignRuleCheck")
        print("     DRC 已触发，等待完成...")
        time.sleep(10)  # DRC 可能需要较长时间

        # 方法 2 (备用): SendKeys 快捷键
        # shell = win32com.client.Dispatch("WScript.Shell")
        # shell.AppActivate("Altium Designer")
        # time.sleep(1)
        # shell.SendKeys("^T^D~")  # Ctrl+T, Ctrl+D, Enter

    except Exception as e:
        print(f"     DRC 触发失败: {e}")
        print("     请手动执行: Tools → Design Rule Check")

    # 解析 DRC 报告
    print("[4/4] 读取 DRC 报告...")
    if output_path:
        report_dir = os.path.dirname(output_path)
        if report_dir and not os.path.exists(report_dir):
            os.makedirs(report_dir, exist_ok=True)
        print(f"     报告将保存至: {output_path}")

    print("\n✅ DRC 检查流程已触发。")
    print("   检查 Altium Designer 中的 Messages 面板查看结果。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Altium Designer DRC 检查")
    parser.add_argument("project", help="工程路径 (.PrjPcb)")
    parser.add_argument("--output", "-o", help="输出报告路径", default="drc_report.html")
    args = parser.parse_args()
    pythoncom.CoInitialize()
    try:
        run_drc(args.project, args.output)
    finally:
        pythoncom.CoUninitialize()
