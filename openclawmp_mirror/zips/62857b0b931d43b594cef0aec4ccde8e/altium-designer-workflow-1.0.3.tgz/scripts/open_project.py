#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
打开 Altium Designer 工程文件 (.PrjPcb)
用法: python open_project.py "C:\path\to\Project.PrjPcb"
"""

import sys
import os
import time
import win32com.client
import pythoncom


def get_or_start_ad():
    """获取或启动 Altium Designer 实例，兼容 AD09 ~ AD26"""
    prog_ids = [
        "Altium.Application",       # AD18 ~ AD26
        "AltiumDesigner.Application", # AD09 ~ AD17
    ]
    for prog_id in prog_ids:
        try:
            ad = win32com.client.Dispatch(prog_id)
            print(f"     已连接: {prog_id}")
            return ad
        except Exception:
            pass
        try:
            ad = win32com.client.GetActiveObject(prog_id)
            print(f"     已连接: {prog_id} (GetActiveObject)")
            return ad
        except Exception:
            pass
    print("[ERROR] 无法连接到 Altium Designer。请确保 AD 已运行。")
    print("       支持的版本: AD09 ~ AD26")
    sys.exit(1)


def open_project(prj_path):
    """打开 PCB 工程并列出所有文档"""
    if not os.path.exists(prj_path):
        print(f"[ERROR] 工程文件不存在: {prj_path}")
        sys.exit(1)

    print(f"[1/2] 连接到 Altium Designer...")
    ad = get_or_start_ad()
    print(f"     AD 版本: {ad.GetVersion() if hasattr(ad, 'GetVersion') else 'Unknown'}")

    print(f"[2/2] 打开工程: {os.path.basename(prj_path)}")
    try:
        workspace = ad.WorkspaceManager.GetWorkspaceFromPath(prj_path)
        # 等待加载
        for _ in range(30):
            current = ad.WorkspaceManager.DM_GetWorkspace()
            if current is not None:
                break
            time.sleep(1)
        else:
            print("[WARNING] 工程加载超时，可能仍在加载中...")

        # 列出工程文档
        print("\n✅ 工程打开成功，包含以下文档：")
        print("-" * 60)
        for doc in workspace.Documents:
            ext = os.path.splitext(doc.GetName())[-1] if hasattr(doc, 'GetName') else '?'
            name = doc.GetName() if hasattr(doc, 'GetName') else str(doc)
            print(f"  [{ext}] {name}")
        print("-" * 60)
        print(f"总计: {workspace.Documents.Count if hasattr(workspace.Documents, 'Count') else '?'} 个文件")

        return workspace

    except Exception as e:
        print(f"[ERROR] 打开工程失败: {e}")
        sys.exit(1)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python open_project.py <path_to_PrjPcb>")
        sys.exit(1)
    pythoncom.CoInitialize()
    try:
        open_project(sys.argv[1])
    finally:
        pythoncom.CoUninitialize()
