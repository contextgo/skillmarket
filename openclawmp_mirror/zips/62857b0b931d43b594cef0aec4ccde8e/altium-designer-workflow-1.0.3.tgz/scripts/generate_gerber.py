#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Gerber / NC Drill 输出文件生成
用法: python generate_gerber.py "C:\path\to\Project.PrjPcb" --output-dir C:\output\Gerber
"""

import sys
import os
import time
import argparse
import win32com.client
import pythoncom


# Gerber 层叠配置
LAYER_CONFIG = {
    "top":          {"ext": ".GTL", "desc": "Top Layer"},
    "bottom":       {"ext": ".GBL", "desc": "Bottom Layer"},
    "top_silk":     {"ext": ".GTO", "desc": "Top Silkscreen"},
    "bottom_silk":  {"ext": ".GBO", "desc": "Bottom Silkscreen"},
    "top_solder":   {"ext": ".GTS", "desc": "Top Solder Mask"},
    "bottom_solder":{"ext": ".GBS", "desc": "Bottom Solder Mask"},
    "top_paste":    {"ext": ".GTP", "desc": "Top Paste Mask"},
    "bottom_paste": {"ext": ".GBP", "desc": "Bottom Paste Mask"},
    "power":        {"ext": ".GP1", "desc": "Power Plane 1"},
    "power2":       {"ext": ".GP2", "desc": "Power Plane 2"},
    "drill":        {"ext": ".TXT", "desc": "NC Drill"},
}

DEFAULT_LAYERS = ["top", "bottom", "top_silk", "bottom_silk", "top_solder", "bottom_solder", "top_paste", "bottom_paste", "drill"]


def get_or_start_ad():
    prog_ids = ["Altium.Application", "AltiumDesigner.Application"]
    for prog_id in prog_ids:
        try:
            return win32com.client.Dispatch(prog_id)
        except Exception:
            pass
        try:
            return win32com.client.GetActiveObject(prog_id)
        except Exception:
            pass
    print("[ERROR] 无法连接到 Altium Designer。")
    sys.exit(1)


def generate_gerber_via_outjob(ad, output_dir):
    """通过 OutJob 生成 Gerber（推荐）"""
    try:
        ad.Server.ProcessMessage("Workspace:RunOutputJob")
        print("     OutJob 已触发，请在 AD 中确认输出路径。")
        return True
    except Exception as e:
        print(f"     OutJob 触发失败: {e}")
        return False


def generate_gerber_via_process(ad, pcb_doc, layers, output_dir, gerber_format="RS-274X"):
    """通过 COM ProcessMessage 生成 Gerber"""
    try:
        # 设置 Gerber 输出参数
        params = {
            "OutputDirectory": output_dir,
            "Format": gerber_format,
            "Layers": ",".join(layers),
            "LeadZeros": False,
            "TrailingZeros": True,
            "IncrementalCoord": False,
            "SuppressApertures": True,
        }

        # 构建 Gerber 输出命令
        # 各 AD 版本的命令格式可能不同，此为通用模式
        for layer in layers:
            if layer == "drill":
                # NC Drill
                ad.Server.ProcessMessage(f"PCB:GenerateNCDrill")
                print(f"     生成: NC Drill (.TXT)")
            else:
                layer_info = LAYER_CONFIG.get(layer, {})
                ad.Server.ProcessMessage(f"PCB:GenerateGerber,{layer}")
                print(f"     生成: {layer_info.get('desc', layer)} ({layer_info.get('ext', '?')})")

        time.sleep(5)
        return True
    except Exception as e:
        print(f"     COM 方式生成失败: {e}")
        return False


def generate_gerber_via_keys(layers, output_dir):
    """备用方案：通过 SendKeys 模拟操作"""
    shell = win32com.client.Dispatch("WScript.Shell")
    activated = shell.AppActivate("Altium Designer")
    if not activated:
        print("     警告: 无法激活 AD 窗口，SendKeys 方式不可用。")
        return False

    time.sleep(1)
    print("     SendKeys: File → Fabrication Outputs → Gerber Files")
    # Alt+F → F → G  (菜单路径)
    shell.SendKeys("%FFG")
    time.sleep(3)
    # 这里需要在 AD 对话框中手动确认
    print("     请在 AD Gerber 设置对话框中确认输出。")
    return True


def generate_gerber(prj_path, output_dir, layers=None, gerber_format="RS-274X"):
    if not os.path.exists(prj_path):
        print(f"[ERROR] 工程文件不存在: {prj_path}")
        sys.exit(1)

    if layers is None:
        layers = DEFAULT_LAYERS

    os.makedirs(output_dir, exist_ok=True)

    ad = get_or_start_ad()

    print("[1/4] 打开工程...")
    workspace = ad.WorkspaceManager.GetWorkspaceFromPath(prj_path)
    time.sleep(3)

    # 找 PCB 文档
    print("[2/4] 查找 PCB 文档...")
    pcb_doc = None
    for doc in workspace.Documents:
        name = doc.GetName() if hasattr(doc, 'GetName') else ''
        if name.lower().endswith('.pcbdoc'):
            pcb_doc = doc
            print(f"     找到: {name}")
            break

    if not pcb_doc:
        print("[ERROR] 工程中未找到 .PcbDoc 文件。")
        sys.exit(1)

    # 生成
    print("[3/4] 生成 Gerber 文件...")
    os.makedirs(output_dir, exist_ok=True)

    # 方案 1: 检查 OutJob
    has_outjob = False
    for doc in workspace.Documents:
        name = doc.GetName() if hasattr(doc, 'GetName') else ''
        if name.lower().endswith('.outjob'):
            has_outjob = True
            break

    if has_outjob:
        print("     检测到 OutJob，优先使用...")
        if generate_gerber_via_outjob(ad, output_dir):
            print("\n✅ Gerber 生成完成。")
            return

    # 方案 2: COM 方式
    print("     尝试 COM 方式...")
    if generate_gerber_via_process(ad, pcb_doc, layers, output_dir, gerber_format):
        print("\n✅ Gerber 生成完成。")
        return

    # 方案 3: SendKeys 备用
    print("     回退到 SendKeys 方式...")
    generate_gerber_via_keys(layers, output_dir)

    print(f"\n⚠️  输出目录: {output_dir}")
    print("   请检查 AD Messages 面板确认生成状态。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Altium Designer Gerber/NC Drill 生成")
    parser.add_argument("project", help="工程路径 (.PrjPcb)")
    parser.add_argument("--output-dir", "-d", help="输出目录", default="./Gerber_Output")
    parser.add_argument("--layers", nargs="+", help="要生成的层", default=None,
                        choices=list(LAYER_CONFIG.keys()))
    parser.add_argument("--format", "-f", default="RS-274X", help="Gerber 格式")
    args = parser.parse_args()
    pythoncom.CoInitialize()
    try:
        generate_gerber(args.project, args.output_dir, args.layers, args.format)
    finally:
        pythoncom.CoUninitialize()
