#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Altium Designer PCB 工程一键全流程
执行：打开工程 → DRC 检查 → BOM 导出 → Gerber 生成 → 丝印分析
用法: python full_workflow.py "C:\path\to\Project.PrjPcb" --output-dir "C:\output"
"""

import sys
import os
import time
import argparse
import win32com.client
import pythoncom


def step(title, func, *args, **kwargs):
    """执行步骤并计时"""
    print(f"\n{'='*60}")
    print(f"  ▶ {title}")
    print(f"{'='*60}")
    start = time.time()
    try:
        result = func(*args, **kwargs)
        elapsed = time.time() - start
        print(f"  ✓ 完成 (耗时: {elapsed:.1f}s)")
        return result
    except Exception as e:
        elapsed = time.time() - start
        print(f"  ✗ 失败 (耗时: {elapsed:.1f}s): {e}")
        return None


def main(prj_path, output_dir):
    if not os.path.exists(prj_path):
        print(f"[ERROR] 工程文件不存在: {prj_path}")
        sys.exit(1)

    # 确保输出目录
    gerber_dir = os.path.join(output_dir, "Gerber")
    os.makedirs(output_dir, exist_ok=True)
    os.makedirs(gerber_dir, exist_ok=True)

    # 导入各模块
    script_dir = os.path.dirname(os.path.abspath(__file__))
    sys.path.insert(0, script_dir)

    from open_project import get_or_start_ad
    from run_drc import run_drc
    from export_bom import export_bom
    from generate_gerber import generate_gerber
    from optimize_silkscreen import optimize_silkscreen

    ad = get_or_start_ad()

    # Step 1: 打开工程
    step("打开工程", lambda: (
        print(f"  工程: {os.path.basename(prj_path)}"),
        ws := ad.WorkspaceManager.GetWorkspaceFromPath(prj_path),
        time.sleep(2),
        print(f"  文档数: {ws.Documents.Count if hasattr(ws.Documents, 'Count') else '?'}"),
    )[-1])

    # Step 2: DRC 检查
    drc_output = os.path.join(output_dir, "drc_report.html")
    step("DRC 设计规则检查", run_drc, prj_path, drc_output)

    # Step 3: BOM 导出
    bom_output = os.path.join(output_dir, "BOM.xlsx")
    step("BOM 物料清单导出", export_bom, prj_path, bom_output, "xlsx")

    # Step 4: Gerber 生成
    step("Gerber/NC Drill 生成", generate_gerber, prj_path, gerber_dir)

    # Step 5: 丝印分析
    silk_output = os.path.join(output_dir, "silkscreen_report.txt")
    step("丝印优化分析", optimize_silkscreen, prj_path, 0.8, 0.2, silk_output)

    # 总结
    print(f"\n{'='*60}")
    print("  🎉 全流程完成！")
    print(f"{'='*60}")
    print(f"  输出目录: {output_dir}")
    print(f"  ├── drc_report.html        - DRC 检查报告")
    print(f"  ├── BOM.xlsx               - 物料清单")
    print(f"  ├── Gerber/                - Gerber 输出文件")
    print(f"  └── silkscreen_report.txt  - 丝印优化建议")
    print(f"{'='*60}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Altium Designer PCB 工程一键全流程")
    parser.add_argument("project", help="工程路径 (.PrjPcb)")
    parser.add_argument("--output-dir", "-d", help="输出目录", default="./AD_Output")
    args = parser.parse_args()
    pythoncom.CoInitialize()
    try:
        main(args.project, args.output_dir)
    finally:
        pythoncom.CoUninitialize()
