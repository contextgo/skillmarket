#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
BOM 物料清单导出
用法: python export_bom.py "C:\path\to\Project.PrjPcb" [--output BOM.xlsx] [--format xlsx|csv|html]
"""

import sys
import os
import time
import argparse
import csv
import win32com.client
import pythoncom


def get_or_start_ad():
    prog_ids = ["Altium.Application", "AltiumDesigner.Application"]
    for prog_id in prog_ids:
        try:
            return win32com.client.Dispatch(prog_id)
        except Exception:
            pass
        try:
            return win32com.client.GetActiveObject(prog_id)
        except Exception:
            pass
    print("[ERROR] 无法连接到 Altium Designer。")
    sys.exit(1)


def extract_components_from_schematic(ad, sch_doc):
    """从原理图文档提取元件信息"""
    components = []
    try:
        # 通过 Iterator 遍历所有 SchComponent
        iterator = sch_doc.SchIterator_Create()
        for obj in iterator:
            # Kind == 2 是 SchComponent
            if hasattr(obj, 'Kind') and obj.Kind() == 2:
                try:
                    comp = {
                        "Designator": obj.Designator.Text if hasattr(obj, 'Designator') and hasattr(obj.Designator, 'Text') else '',
                        "Comment": obj.Comment.Text if hasattr(obj, 'Comment') and hasattr(obj.Comment, 'Text') else '',
                        "Description": obj.Description.Text if hasattr(obj, 'Description') and hasattr(obj.Description, 'Text') else '',
                        "Footprint": "",
                        "Quantity": 1,
                    }
                    # 尝试获取 Footprint
                    if hasattr(obj, 'GetState_Current'):
                        state = obj.GetState_Current()
                        if hasattr(state, 'GetFootprintName'):
                            comp["Footprint"] = state.GetFootprintName()
                    components.append(comp)
                except Exception:
                    continue
        sch_doc.SchIterator_Destroy(iterator)
    except Exception as e:
        print(f"     警告: 遍历原理图文档时出错: {e}")

    return components


def aggregate_bom(components):
    """按 Comment 合并相同元件"""
    bom = {}
    for comp in components:
        key = (comp["Comment"], comp["Footprint"], comp["Description"])
        if key in bom:
            bom[key]["Quantity"] += 1
            bom[key]["Designator"] += ", " + comp["Designator"]
        else:
            bom[key] = comp.copy()
    return list(bom.values())


def write_csv(bom_data, output_path):
    with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=["Designator", "Comment", "Description", "Footprint", "Quantity"])
        writer.writeheader()
        writer.writerows(bom_data)


def write_html(bom_data, output_path):
    html = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><title>BOM</title>
<style>table{border-collapse:collapse;width:100%}th,td{border:1px solid #ddd;padding:6px;text-align:left}th{background:#f4f4f4}</style>
</head><body>
<h1>Bill of Materials</h1>
<table>
<tr><th>Designator</th><th>Comment</th><th>Description</th><th>Footprint</th><th>Qty</th></tr>
"""
    for row in bom_data:
        html += f"<tr><td>{row['Designator']}</td><td>{row['Comment']}</td><td>{row['Description']}</td><td>{row['Footprint']}</td><td>{row['Quantity']}</td></tr>\n"
    html += "</table></body></html>"
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)


def export_bom(prj_path, output_path, fmt="xlsx"):
    if not os.path.exists(prj_path):
        print(f"[ERROR] 工程文件不存在: {prj_path}")
        sys.exit(1)

    ad = get_or_start_ad()

    print("[1/4] 打开工程...")
    workspace = ad.WorkspaceManager.GetWorkspaceFromPath(prj_path)
    time.sleep(2)

    # 找到所有原理图文档
    print("[2/4] 查找原理图文档...")
    all_components = []
    sch_count = 0
    for doc in workspace.Documents:
        name = doc.GetName() if hasattr(doc, 'GetName') else ''
        if name.lower().endswith('.schdoc'):
            print(f"     处理: {name}")
            components = extract_components_from_schematic(ad, doc)
            all_components.extend(components)
            sch_count += 1

    if sch_count == 0:
        print("[ERROR] 工程中未找到 .SchDoc 原理图文件。")
        sys.exit(1)

    print(f"     共找到 {len(all_components)} 个元件")

    # 聚合 BOM
    print("[3/4] 聚合 BOM...")
    bom_data = aggregate_bom(all_components)
    print(f"     合并后: {len(bom_data)} 种元件")

    # 输出
    print(f"[4/4] 导出 BOM ({fmt} 格式)...")
    if not output_path.endswith(f'.{fmt}'):
        output_path = output_path.rsplit('.', 1)[0] + f'.{fmt}'

    out_dir = os.path.dirname(output_path)
    if out_dir and not os.path.exists(out_dir):
        os.makedirs(out_dir, exist_ok=True)

    if fmt == "csv":
        write_csv(bom_data, output_path)
    elif fmt == "html":
        write_html(bom_data, output_path)
    elif fmt == "xlsx":
        # 尝试使用 openpyxl
        try:
            from openpyxl import Workbook
            wb = Workbook()
            ws = wb.active
            ws.title = "BOM"
            headers = ["Designator", "Comment", "Description", "Footprint", "Quantity"]
            ws.append(headers)
            for row in bom_data:
                ws.append([row[h] for h in headers])
            wb.save(output_path)
        except ImportError:
            print("     缺少 openpyxl，降级为 CSV 格式。")
            print("     安装: pip install openpyxl")
            output_path = output_path.replace('.xlsx', '.csv')
            write_csv(bom_data, output_path)
    else:
        print(f"[ERROR] 不支持的格式: {fmt}")
        sys.exit(1)

    print(f"\n✅ BOM 已导出: {output_path}")
    print(f"   共 {len(bom_data)} 种元件，来自 {sch_count} 张原理图。")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Altium Designer BOM 导出")
    parser.add_argument("project", help="工程路径 (.PrjPcb)")
    parser.add_argument("--output", "-o", help="输出文件路径", default="BOM.xlsx")
    parser.add_argument("--format", "-f", choices=["xlsx", "csv", "html"], default="xlsx", help="输出格式")
    args = parser.parse_args()
    pythoncom.CoInitialize()
    try:
        export_bom(args.project, args.output, args.format)
    finally:
        pythoncom.CoUninitialize()
