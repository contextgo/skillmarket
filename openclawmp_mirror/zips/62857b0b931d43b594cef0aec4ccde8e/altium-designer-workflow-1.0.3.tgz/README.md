# Altium Designer PCB 设计全流程自动化

Altium Designer PCB 工程自动化工作流，通过 Python + COM API 实现从工程打开到出图的全流程自动化。

## 能力概览

| 模块 | 功能 | 脚本 |
|---|---|---|
| 工程打开 | 加载 .PrjPcb 工程，列出所有文档 | `scripts/open_project.py` |
| DRC 检查 | 触发设计规则检查，解析报告 | `scripts/run_drc.py` |
| BOM 导出 | 从原理图提取元件清单，支持 xlsx/csv/html | `scripts/export_bom.py` |
| Gerber 生成 | 生成 Gerber (RS-274X) + NC Drill 钻孔文件 | `scripts/generate_gerber.py` |
| 丝印优化 | 分析丝印层违规项，输出优化建议报告 | `scripts/optimize_silkscreen.py` |
| 一键全流程 | 按顺序执行上述全部步骤 | `scripts/full_workflow.py` |

## 前置条件

- Windows 系统，已安装 Altium Designer（AD 18+）
- Python 3.8+，已安装 `pywin32`：`pip install pywin32`

## 快速开始

```bash
# 一键全流程
python scripts/full_workflow.py "C:\path\to\Project.PrjPcb" --output-dir "C:\output"

# 单独执行某一步
python scripts/export_bom.py "C:\path\to\Project.PrjPcb" -o BOM.xlsx
python scripts/generate_gerber.py "C:\path\to\Project.PrjPcb" -d ./Gerber_Output
```

## 适用场景

- PCB 工程师日常出图流程自动化
- 批量工程检查（DRC + 丝印）
- BOM 快速导出与元件统计
- 设计审查与质量把控

## 安全说明

- 丝印优化仅生成建议报告，**不会自动修改工程文件**
- DRC、Gerber 等输出操作前建议备份原始工程
