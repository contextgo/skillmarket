---
name: pdf-batch-extractor
description: PDF批量内容提取工具 | 批量提取多个PDF的文字内容，支持按页码范围、按关键词筛选，输出为TXT/Markdown/Excel
---

# PDF批量内容提取工具

批量从PDF文件中提取文字内容，支持指定页码范围、按关键词筛选、多种输出格式。

## 适用场景

- 批量提取技术文档内容
- 收集整理多份规格书/说明书
- 提取合同/报告中的关键信息
- 将PDF内容转换为可编辑文本

## 核心功能

| 功能 | 说明 |
|------|------|
| 批量提取 | 一次性处理多个PDF文件 |
| 页码范围 | 支持指定起始页-结束页 |
| 关键词筛选 | 只提取包含关键词的页面 |
| 多格式输出 | TXT / Markdown / Excel |
| 目录重建 | 提取标题结构重建目录 |

## 支持格式

- 输入：PDF文件（.pdf）
- 输出：TXT / Markdown / Excel

## 使用方法

```powershell
# 提取单个PDF全部内容
pdf-extractor extract -i "doc.pdf" -o "output.txt"

# 批量提取目录所有PDF
pdf-extractor extract -i "C:\docs\*.pdf" -o "C:\output\"

# 只提取前10页
pdf-extractor extract -i "doc.pdf" -o "output.txt" -pages "1-10"

# 按关键词筛选（只提取含该关键词的页面）
pdf-extractor extract -i "doc.pdf" -o "output.txt" -keyword "技术参数"

# 输出为Markdown（保留格式）
pdf-extractor extract -i "doc.pdf" -o "output.md" -format "md"
```

## 对话式使用

```
用户：帮我提取这份PDF第5-20页的内容，输出为txt

用户：把这个文件夹下所有PDF的文字提取出来，合并成一个markdown文件

用户：从这批合同PDF中筛选出所有包含"违约责任"的条款
```
