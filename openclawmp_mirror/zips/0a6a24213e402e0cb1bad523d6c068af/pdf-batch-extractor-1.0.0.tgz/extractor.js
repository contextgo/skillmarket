/**
 * PDF批量内容提取工具
 */

const fs = require('fs');
const path = require('path');

/**
 * 提取PDF文本内容（使用pdf-parse）
 */
async function extractPDFText(filePath, options = {}) {
  const { startPage = 1, endPage, keyword, maxPages } = options;
  
  try {
    const pdfParse = require('pdf-parse');
    const buffer = fs.readFileSync(filePath);
    const data = await pdfParse(buffer);
    
    let text = data.text;
    const totalPages = data.numpages;
    
    // 如果指定了最大页数限制
    if (maxPages && maxPages < totalPages) {
      text = text.split('\n')
        .slice(0, maxPages * 50) // 粗略估算每页50行
        .join('\n');
    }
    
    // 按关键词筛选（保留包含关键词的上下文）
    if (keyword) {
      const lines = text.split('\n');
      const filtered = [];
      let context = [];
      lines.forEach(line => {
        if (line.includes(keyword)) {
          filtered.push(...context.slice(-3)); // 保留前3行上下文
          filtered.push(line);
          context = [];
        } else {
          context.push(line);
          if (context.length > 5) context.shift();
        }
      });
      text = filtered.join('\n') || `（未找到包含"${keyword}"的内容）`;
    }
    
    return {
      text,
      totalPages,
      metadata: data.info,
      fileName: path.basename(filePath)
    };
  } catch (e) {
    throw new Error(`提取失败 ${filePath}: ${e.message}`);
  }
}

/**
 * 批量提取目录下的PDF
 */
async function batchExtract(inputPattern, outputPath, options = {}) {
  const { format = 'txt', keyword } = options;
  
  // 查找匹配的PDF文件
  const glob = require('glob');
  const files = glob.sync(inputPattern);
  
  if (files.length === 0) {
    throw new Error(`未找到匹配的PDF文件: ${inputPattern}`);
  }
  
  const results = [];
  
  for (const file of files) {
    try {
      console.log(`📄 正在提取: ${path.basename(file)}`);
      const result = await extractPDFText(file, options);
      results.push(result);
      
      const outFile = path.join(outputPath, path.basename(file, '.pdf') + '.' + format);
      fs.writeFileSync(outFile, result.text, 'utf8');
      console.log(`  ✅ 完成: ${result.totalPages}页 → ${outFile}`);
    } catch (e) {
      console.error(`  ❌ 失败: ${e.message}`);
    }
  }
  
  return results;
}

/**
 * 合并多个PDF的文本
 */
async function mergePDFTexts(inputPattern, outputFile, options = {}) {
  const results = await batchExtract(inputPattern, path.dirname(outputFile), options);
  
  let merged = '';
  results.forEach(r => {
    merged += `\n=== ${r.fileName} ===\n`;
    merged += r.text + '\n';
  });
  
  fs.writeFileSync(outputFile, merged, 'utf8');
  console.log(`✅ 合并完成: ${outputFile}`);
  return merged.length;
}

// CLI
const [,, cmd, ...argsList] = process.argv;

const ARGS = {};
for (let i = 0; i < argsList.length; i += 2) {
  if (argsList[i]?.startsWith('-')) {
    ARGS[argsList[i].replace(/^-+/, '')] = argsList[i + 1] || true;
  }
}

async function main() {
  if (cmd === 'extract') {
    const { i: input, o: output, pages, keyword, format = 'txt', max } = ARGS;
    if (!input || !output) {
      console.log(`用法:
  pdf-extractor extract -i input.pdf -o output.txt [-pages 1-10] [-keyword xxx] [-format txt|md] [-max 50]
  pdf-extractor batch -i "*.pdf" -o ./output/ [-format txt]`);
      return;
    }
    
    const options = { format, keyword };
    if (pages) {
      const [start, end] = pages.split('-').map(Number);
      options.startPage = start;
      options.endPage = end;
    }
    if (max) options.maxPages = parseInt(max);
    
    const result = await extractPDFText(input, options);
    fs.writeFileSync(output, result.text, 'utf8');
    console.log(`✅ 提取完成: ${result.totalPages}页 → ${output}`);
  }
  else if (cmd === 'batch') {
    const { i: input, o: output, format = 'txt', keyword } = ARGS;
    if (!input || !output) {
      console.log('用法: pdf-extractor batch -i "*.pdf" -o ./output/ [-format txt|md] [-keyword xxx]');
      return;
    }
    await batchExtract(input, output, { format, keyword });
  }
  else if (cmd === 'merge') {
    const { i: input, o: output, format = 'txt', keyword } = ARGS;
    if (!input || !output) {
      console.log('用法: pdf-extractor merge -i "*.pdf" -o merged.txt');
      return;
    }
    await mergePDFTexts(input, output, { format, keyword });
  }
  else {
    console.log(`
PDF批量内容提取工具
==================
用法:
  pdf-extractor extract -i input.pdf -o output.txt [-pages 1-10] [-keyword xxx] [-format txt|md]
  pdf-extractor batch -i "*.pdf" -o ./output/ [-keyword xxx] [-format txt|md]
  pdf-extractor merge -i "*.pdf" -o merged.txt [-keyword xxx]

参数:
  -i        输入文件或glob模式
  -o        输出文件或目录
  -pages    页码范围，如 1-10
  -keyword  按关键词筛选
  -format   输出格式: txt(默认) 或 md
  -max      最大提取页数
`);
  }
}

if (require.main === module) {
  main().catch(e => { console.error('❌ 错误:', e.message); process.exit(1); });
}

module.exports = { extractPDFText, batchExtract, mergePDFTexts };
