---
name: api-rate-limiting-strategies
description: API rate limiting: token bucket, sliding window, distributed throttling, graceful degradation
---

# API Rate Limiting Strategies

## Overview
Protect APIs from abuse while maintaining user experience.

## Algorithm Comparison

### Token Bucket
- Allows burst traffic
- Config: capacity=100, refill=10/sec
- Best for: most API scenarios

### Sliding Window
- More precise limits
- Redis Sorted Set + timestamp
- Best for: strict limits (e.g., payment)

### Fixed Window
- Simple implementation
- Window boundary burst 2x
- Best for: statistics

### Leaky Bucket
- Smooth output rate
- Best for: message sending, log writing

## Layered Limiting
```
Global: 10000 req/min (server protection)
  IP: 100 req/min (anti-bot)
    User: 60 req/min (anti-abuse)
      Endpoint: custom (e.g., login 5/min)
```

## Implementation
- Redis + Lua script for atomic distributed limiting
- Middleware: express-rate-limit / slowapi / Nginx limit_req_zone

## Graceful Degradation
- Return 429 + Retry-After header
- RateLimit-* headers (remaining quota)
- Higher limits for VIP users
- Cache hot endpoint responses

