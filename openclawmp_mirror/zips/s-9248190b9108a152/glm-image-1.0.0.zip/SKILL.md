---
name: glm-image
displayName: GLM AI画图
description: 使用智谱AI CogView模型从文本提示生成高质量图像。
homepage: https://open.bigmodel.cn
---

# GLM AI画图

> 使用智谱AI CogView模型生成图像

## 特点

- 文本→图像生成
- 支持中文提示词
- 多种风格可选
- 速度快，效果好

## 环境要求

- Node.js 18+
- 智谱AI API Key

## 认证方式

```bash
export ZHIPU_API_KEY="your-api-key"
```

获取API Key: https://open.bigmodel.cn/usercenter/apikeys

## 使用方法

```bash
node {baseDir}/scripts/image.mjs "提示词"
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `-s` | 图像尺寸 | 1024x1024 |
| `-o` | 输出文件 | output.png |
| `--style` | 风格 | auto |

## 可用尺寸

- 1024x1024 (方形)
- 768x1360 (竖版)
- 1360x768 (横版)

## 风格选项

| 风格 | 说明 |
|------|------|
| auto | 自动 |
| 3d | 3D风格 |
| anime | 动漫风格 |
| illustration | 插画风格 |
| photo | 照片风格 |
| watercolor | 水彩风格 |

## 示例

```bash
# 基本用法
node {baseDir}/scripts/image.mjs "一只可爱的猫咪"

# 指定尺寸
node {baseDir}/scripts/image.mjs "风景画" -s 1360x768

# 指定风格
node {baseDir}/scripts/image.mjs "二次元少女" --style anime

# 保存到文件
node {baseDir}/scripts/image.mjs "AI未来城市" -o future.png
```

---

*基于智谱AI官方CogView API*
