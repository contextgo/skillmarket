#!/usr/bin/env node

/**
 * GLM AI画图
 * 使用智谱AI CogView API
 */

function usage() {
  console.error(`Usage: image.mjs "提示词" [options]
Options:
  -s <size>      尺寸: 1024x1024, 768x1360, 1360x768 (default: 1024x1024)
  -o <file>      输出文件 (default: output.png)
  --style <s>    风格: auto, 3d, anime, illustration, photo, watercolor`);
  process.exit(2);
}

const args = process.argv.slice(2);
if (args.length === 0) usage();

let prompt = args[0];
let size = '1024x1024';
let outputFile = 'output.png';
let style = 'auto';

for (let i = 1; i < args.length; i++) {
  const a = args[i];
  if (a === '-s' && args[i + 1]) {
    size = args[i + 1];
    i++;
  } else if (a === '-o' && args[i + 1]) {
    outputFile = args[i + 1];
    i++;
  } else if (a === '--style' && args[i + 1]) {
    style = args[i + 1];
    i++;
  }
}

const API_KEY = process.env.ZHIPU_API_KEY;
if (!API_KEY) {
  console.error('错误: 请设置 ZHIPU_API_KEY 环境变量');
  process.exit(1);
}

const https = require('https');
const fs = require('fs');

// 先调用生成API
const postData = JSON.stringify({
  model: 'CogView-4',
  prompt: prompt,
  size: size,
  style: style
});

const options = {
  hostname: 'open.bigmodel.cn',
  path: '/api/paas/v4/images/generations',
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  }
};

console.log('🎨 正在生成图像...');

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    try {
      const result = JSON.parse(data);
      
      if (result.error) {
        console.error('错误:', result.error.message);
        process.exit(1);
      }
      
      // 获取图片URL并下载
      const imageUrl = result.data?.[0]?.url;
      if (!imageUrl) {
        console.error('未获取到图像URL');
        process.exit(1);
      }
      
      console.log('📥 正在下载图像...');
      https.get(imageUrl, (imgRes) => {
        const file = fs.createWriteStream(outputFile);
        imgRes.pipe(file);
        file.on('finish', () => {
          console.log(`✅ 已保存到: ${outputFile}`);
        });
      }).on('error', (e) => {
        console.error('下载错误:', e.message);
        process.exit(1);
      });
      
    } catch (e) {
      console.error('解析失败:', e.message);
      console.error('原始数据:', data);
    }
  });
});

req.on('error', (e) => {
  console.error('请求错误:', e.message);
  process.exit(1);
});

req.write(postData);
req.end();
