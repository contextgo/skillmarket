# Context & Memory Manager

综合性的上下文与记忆管理工具，结合CLI会话监控和智能记忆优化。

## 功能

- **会话监控** - 自动检测无回复问题
- **智能压缩** - 保留关键信息，删除冗余
- **分层记忆** - 会话层/工作层/知识层
- **按需加载** - 只读取需要的记忆
- **主动记录** - 自动提取重要信息

## 快速开始

```bash
# 检查健康状态
cmm check

# 压缩上下文
cmm compress

# 查看记忆统计
cmm memory stats
```

## 配置

编辑 `~/.openclaw/skills/context-memory-manager/CONFIG.json`

## 触发词

- "检查会话健康"
- "压缩上下文"
- "清理记忆"
- "管理上下文"
- "优化记忆"
- "cmm"

## 更多信息

查看 `SKILL.md` 获取完整文档。
