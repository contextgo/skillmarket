---
name: multi-agent-collab
description: "多Agent协作框架[现实对齐版v6]。聚焦StepFun单会话环境100%可用模式，9种核心模板+3大支撑方法，移除所有 physically impossible 的方式。触发：'用协作模式'、'多Agent'、'协作完成'、'研究→写作→审核'、'红队审核'。"
version: "6.0.0"
updated: "2026-03-16"
changelog: "v6.0: 现实对齐——移除5种物理不可能方法，保留9种单会话可用模板+3种核心机制"
---

# Multi-Agent Collaboration Framework v6 [现实对齐版]

> **适用环境**: StepFun单会话平台
> **核心原则**: 移除物理上不可用的方法，聚焦真正可执行的协作模式
> **v6简化为**: 9种协作模板 + 3种核心机制

---

## When to Activate

ONLY when task meets ALL of:
- Deliverable is non-trivial (report, strategy, proposal, code project)
- Task has 2+ distinct cognitive phases
- User explicitly requests collaboration OR task complexity warrants it

For simple tasks: just do it directly.

---

## 9种核心协作模板 (v6 Reality-Aligned)

### 【模板】研究→写作→质量守门

```
任务: 研究报告/行业分析/长文章
适用: 任何需要信息整合后输出的内容生产

第1轮（研究）:
- 目标: 采集原始事实，只编号不下结论
- 技法: Method 7 Blackboard → 输出到 findings.md
- 约束: 每个数据点标注[来源X]

第2轮（写作）:
- 输入: findings.md作为唯一信源
- 技法: Method 6 Skill chain + Method 3 DAG描述
- 约束: 引用格式[ref: findings #X]，不引入外部信息

第3轮（质量守门）:
- 目标: 执行Method 12红队攻击+三层幻觉防线
- 技法: Method 11对抗辩论 + 12红队审核（单会话执行）
- 输出: 审核报告+修正后的终稿
```

---

### 【模板】正方→反方→裁决

```
任务: 投资决策/战略选择/技术选型/争议问题分析
适用: 需要在利弊间做权衡的重大选择

第1轮（正方）:
- 角色: Optimistic Advocate
- 任务: 列出所有支持理由、好处、机会

第2轮（反方）:
- 角色: Pessimistic Critic
- 任务: 列出所有风险、问题、反面证据
- 技法: Same session, role switch

第3轮（裁决）:
- 角色: Neutral Arbiter
- 技法: Method 19投票共识
- 输出: 推荐结论+保留意见清单
```

---

### 【模板】三轮迭代深化

```
任务: 需要渐进完善的复杂文档/策略/方案
适用: Method 9的核心实现

规则:
- 第1轮: 初稿（覆盖率优先）
- 第2轮: 深化（质量优先，识别gap）
- 第3轮: 精炼（最终交付）

守门规则:
- High risk items → 必须修正
- Medium risk items ≤ 3 → 可接受
- Low risk items ≤ 5 → 可接受
- 超过则触发额外轮次

技法: Method 9 Three-pass constrained + Method 14人机检查点
```

---

### 【模板】竞争式生成→择优

```
任务: 需要多版本比选的场景（标题/方案/文案）
适用: Method 18的核心实现

第1轮（竞争生成）:
- 目标: 生成N个独立版本（N=3-5）
- 技法: Method 18 Competitive generation
- 关键: 每个版本用不同角度/风格/框架

第2轮（评估筛选）:
- 技法: Method 19 Voting consensus
- 角色模拟: 3-5个评审专家投票

第3轮（精选完善）:
- 选取Top 1-2，执行Method 9三轮深化
```

---

### 【模板】研究→写作→红队→终稿

```
任务: 高置信度研究报告（v5增强版）
适用: 需要质量门控的正式报告

第1轮（数据采集）:
- 技法: Method 7 Blackboard
- 输出: {workspace}\research\findings.md

第2轮（报告撰写）:
- 技法: Method 6 Skill chain
- 输出: {workspace}\drafts\draft_v1.md

第3轮（红队攻击）:
- 技法: Method 12 Red team +三层幻觉防线
- 5向量: 反转/利益方/假设/执行/数据
- 3防线: 数据溯源/逻辑一致/时效性
- 输出: {workspace}\reviews\red_team_review.md

第4轮（质量评分+终稿）:
- 技法: Method 11对抗辩论 + 8维度评分（Method 13降级版）
- A级(64-80): 直接输出
- B级(48-64): 带改进建议输出
- C级(32-48): 自动触发修正
- D级(<32): 重新采集

输出: {workspace}\final\report_final.md
```

---

### 【模板】数据→分析→叙事

```
任务: 数据分析报告/可视化输出
适用: 需要把数据转化为故事的表达任务

第1轮（数据处理）:
- 技法: Method 16 Script orchestration
- 执行: Excel/CSV处理，生成统计摘要

第2轮（分析洞察）:
- 技法: Method 6 Skill chain + Method 3 DAG
- 找出模式、异常、趋势

第3轮（叙事包装）:
- 技法: Method 18 Competitive generation → 选最佳叙事结构
- 输出: 报告 + 可视化
```

---

### 【模板】翻译→校对→润色

```
任务: 专业文档翻译/本地化

第1轮（翻译）:
- 技法: Method 6 Skill chain（unified-humanizer/翻译功能）

第2轮（校对）:
- 技法: Method 12三层幻觉防线（术语一致性检查）

第3轮（润色）:
- 技法: Method 9最后一轮精炼
```

---

### 【模板】需求→PRD设计→评审

```
任务: 产品PRD/需求文档/方案设计

第1轮（需求采集）:
- 技法: Method 1 Plan分离 + Method 4预检

第2轮（PRD撰写）:
- 技法: Method 6 Skill chain (product-manager-toolkit)

第3轮（评审迭代）:
- 技法: Method 11正反方辩论
- 维度: 用户价值/技术可行/商业收益/执行风险
```

---

### 【模板】开发→测试→审查

```
任务: 代码项目/技术方案实现

第1轮（开发）:
- 技法: Method 6 Skill chain + Method 16 Script执行

第2轮（测试）:
- 技法: Method 12红队（边界测试/异常测试）

第3轮（代码审查）:
- 技法: Method 11对抗（代码审查视角）
- 输出: 审查报告+重构建议
```

---

## 3种核心支撑机制

| 机制 | 对应原Method | 说明 |
|------|-------------|------|
| **文件黑板 (Blackboard)** | Method 7 | 所有模板的数据传递机制，轮次间通过.md/.json文件传递 |
| **技能链 (Skill Chain)** | Method 6 | 调用其他skill完成专业任务 |
| **人机检查点 (Human Check)** | Method 14 | todo_list_manager确认，在关键节点等待用户 |

---

## 质量门控标准

### 三层幻觉防线（所有模板第3轮执行）

**防线1 - 数据溯源:**
- ✅ 有来源支撑: 在原始数据中找到
- ⚠️ AI推断: 基于数据的合理推断（需注明）
- ❌ 疑似幻觉: 无法验证 → 必须标记

**防线2 - 逻辑一致:**
- 百分比之和是否超过100%？
- 增长率和绝对值是否匹配？
- 章节间数据是否矛盾？

**防线3 - 时效性:**
- 每个数据必须标注时间
- 过时数据不能当作最新使用

### 风险等级处理

| 等级 | 标准 | 处理方式 |
|------|------|---------|
| 高 | 数据幻觉/逻辑断裂 | 必须修正 |
| 中 | 来源不明/推断未标 | 可接受≤3个 |
| 低 | 格式/表达问题 | 可接受≤5个 |

---

## 已移除的方法 (v5→v6)

| 原Method | 状态 | 原因 |
|----------|------|------|
| 5 Multi-window物理隔离 | ❌ 移除 | StepFun单会话无法实现 |
| 10 Conversation history注入 | ❌ 移除 | 无持久化会话管理 |
| 13 Blind review盲审 | ❌ 移除 | 物理上无法隐藏历史，已降级为Method 11 |
| 17 Scheduled triggers | ❌ 移除 | StepFun不支持定时任务 |
| 2 Contract Net | ⚠️ 隐式 | 单会话内模拟角色分配，不单独显式 |
| 8 Context relay | ⚠️ 隐式 | 通过Blackboard实现，不单独显式 |

---

## 触发词

```
用户说: "用协作模式" → 进入协作模式，自动选择模板
        "多Agent" → 识别为9种模板之一
        "协作完成" → 激活完整协作流程
        "研究→写作→审核" → 使用模板1或5
        "红队审核" → 使用含Method 12的模板
        "三轮迭代" / "深化" → 使用模板3
        "多个方案比选" → 使用模板4
```

---

## 快速选择决策树

```
需要生成报告/文章? 
  └── 需要高置信度质量门控? → 模板5: 研究→写作→红队→终稿
  └── 一般质量要求? → 模板1: 研究→写作→质量守门

需要做决策/分析利弊?
  └── 使用模板2: 正方→反方→裁决

需要逐步完善/迭代?
  └── 使用模板3: 三轮迭代深化

需要多版本比选?
  └── 使用模板4: 竞争式生成→择优

处理数据?
  └── 使用模板6: 数据→分析→叙事

翻译任务?
  └── 使用模板7: 翻译→校对→润色

产品文档?
  └── 使用模板8: 需求→PRD设计→评审

代码项目?
  └── 使用模板9: 开发→测试→审查
```

---

## 与其他Skill的协同

| Skill | 协同方式 |
|-------|---------|
| unified-market-research | → 模板5深度模式 |
| planning-with-files | → 复杂任务规划 |
| self-improvement | → 协作完成后学习记录 |
| unified-humanizer | → 模板7翻译润色 |
| xlsx/pptx/docx/pdf | → 各模板的输出载体 |

---

## 版本演进

- **v5.0**: 20种方法，5层架构，近半不可用
- **v6.0**: 9种模板+3种机制，全部StepFun可用

架构降级 = 执行可靠性提升
