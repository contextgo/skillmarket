---
name: multi-agent-collab
description: "多Agent协作框架[v7演化版]。从三级模式升级为六维协作模型，引入拓扑结构、动态反馈循环、认知审议机制、涌现式角色分配，实现真正的分布式认知协作。"
version: "7.0.0-alpha"
updated: "2026-03-16"
changelog: "v7.0-alpha: 六维协作模型——从流程定义到协作智能的演化; v6.1: 三级模式; v6.0: 现实对齐"
---

# Multi-Agent Collaboration Framework v7 [演化版]

> **核心飞跃**: 从"流程定义"到"认知协作"
> **六维模型**: Tempo × Topology × Authority × Interaction × Cognition × Persistence
> **关键升级**: 
> - 引入拓扑结构 → Pipeline/Hub-Spoke/Mesh/Hybrid
> - 动态反馈循环 → 收敛导向替代轮次计数
> - 认知审议机制 → Perception→Deliberation→Communication→Consensus→Action→Monitor
> - 涌现式角色 → 动态分配而非预定义

---

## v7 vs v6.1 核心差异

| 维度 | v6.1 (三级模式) | v7 (六维协作) |
|------|----------------|---------------|
| **组织逻辑** | 固定轮次 (2/3/4轮) | 收敛导向 (质量达标为止) |
| **拓扑结构** | 隐式链式 | Pipeline/Hub-Spoke/Mesh/Hybrid |
| **通信模式** | 线性传递 (文件) | 网状交互 (共享状态) |
| **认知协作** | 单人分角 | 分布式认知 (ToM) |
| **失败处理** | 无 | Retry/Rollback/Replan |
| **角色分配** | 预定义 | 涌现式动态分配 |
| **人机协作** | 检查点确认 | 智能决策节点 |

---

## 六维协作模型 (Six-Dimensional Cooperation)

### D1: Tempo (节奏)

| 模式 | 特点 | 适用场景 |
|------|------|---------|
| **Synchronous** | 实时同步，等待对方完成 | 快速决策、讨论会 |
| **Asynchronous** | 提交任务后继续，结果返回通知 | 研究报告、复杂分析 |

**v7升级**: 支持混合模式（关键节点同步，其余异步）

---

### D2: Topology (拓扑结构)

```
【Pipeline 链式】(v6.1默认)
用户 → 研究 → 写作 → 审核 → 输出
├─ 特征: 单向流动，各阶段隔离
├─ 适用: 明确的流水线任务
└─ 优势: 简单、清晰

【Hub-Spoke 星形】
      ┌→ 研究Agent
      │
用户 → Hub → 写作Agent → 输出
      │      ↑
      └→ 审核Agent
├─ 特征: 中心协调，并行输入
├─ 适用: 需要多视角综合的决策
└─ 优势: 信息聚合效率高

【Mesh 网状】
研究 ↔ 写作 ↔ 审核
    ↕    ↕     ↕
    └→ 共识 ←┘
├─ 特征: 全连接，多轮协商
├─ 适用: 复杂共识达成、创意生成
└─ 优势: 涌现创新、集体智慧

【Hybrid 混编】
链式阶段 + Hub-Spoke + Mesh按需求组合
└─ 特征: 复杂任务的最优拓扑
```

**拓扑选择决策树**:
```
任务类型?
├── 信息流水线 → Pipeline (默认)
├── 多方案比选 → Hub-Spoke
├── 创意/共识 → Mesh
└── 复杂项目 → Hybrid (链+Hub+Mesh组合)
```

---

### D3: Authority (决策权限)

| 模式 | 机制 | 适用 |
|------|------|------|
| **Hierarchical** | 主从结构，指令式决策 | 快速执行、责任清晰 |
| **Egalitarian** | 平等投票，多数决 | 观点碰撞、创新探索 |
| **Meritocratic** | 按质量/专业能力加权 | 专业决策 |
| **Hybrid** | 按阶段动态切换 | 复杂决策流程 |

---

### D4: Interaction (交互模式)

| 模式 | 动态 | v7实现 |
|------|------|--------|
| **Dialogue** | 一对一讨论 | 模拟对话轮次 |
| **Debate** | 正反方对抗 | L3红队模式升级 |
| **Voting** | 多选投票 | 8维度质量评分 |
| **Market** | 竞标/拍卖机制 | 动态角色分配 |

---

### D5: Cognition (认知层级)

**Transactive Memory (分布式记忆)**:
```
不是每个Agent有完整记忆，而是:
- Agent A 知道某些信息存在
- Agent B 知道谁能提供某些信息
- Agent C 持有具体信息

通过"元认知"(知道谁知道什么)实现协作
```

v7引入的Cognitive Loop:
```
感知(Perception)
    ↓
审议(Deliberation) ←→ 学习更新
    ↓
通信(Communication)
    ↓
共识(Consensus)
    ↓
行动(Action)
    ↓
监控(Monitor) → 质量评估
    ↓
   [收敛?]
    ├─ 是 → 输出
    └─ 否 → 反馈到审议
```

---

### D6: Persistence (状态持久)

| 层级 | 范围 | 用途 |
|------|------|------|
| **Session** | 当前会话 | 会话级恢复 |
| **Task** | 本次任务 | 任务断点续跑 |
| **Working** | 任务历史 | 经验积累 |
| **Long-term** | 跨任务 | Agent学习进化 |

---

## v7 四大拓扑原型详解

### 【Pipeline】研究→写作→审核

```typescript
// v7 Pipeline with Feedback Loops
interface PipelineState {
  stage: 'research' | 'writing' | 'review' | 'output';
  iteration: number;
  qualityGate: QualityGate;
  backtrack?: 'research' | 'writing'; // 失败时的回退点
}

// 对比v6.1: 增加循环回退，不是单向
StateMachine:
  research ──质量达标──→ writing
     │                    │
     └─质量不达标─── 返回重写
          ↓
      writing ──质量达标──→ review
         │                    │
         └─质量不达标── 返回重构
              ↓
          review ──质量达标──→ output
             │                    │
             └─质量不达标── 返回修正
```

**v7改进**:
- 每个阶段有质量守门
- 不达标触发回退，不是简单"继续下一轮"
- 可配置回退策略 (Retry/Skip/Rollback)

---

### 【Hub-Spoke】决策中心

```
                    ┌─────────────┐
                    │   用户输入   │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │  Hub (协调者) │
                    └──────┬──────┘
            ┌──────────────┼──────────────┐
            │              │              │
            ▼              ▼              ▼
     ┌────────────┐ ┌────────────┐ ┌────────────┐
     │ Spoke 1   │ │ Spoke 2   │ │ Spoke 3   │
     │ (分析师)  │ │ (策略师)  │ │ (风险官)  │
     └────┬───────┘ └────┬───────┘ └────┬───────┘
            │              │              │
            └──────────────┼──────────────┘
                           │
                           ▼
                    ┌─────────────┐
                    │  Consensus  │
                    │  (裁决节点) │
                    └──────┬──────┘
                           │
                           ▼
                    ┌─────────────┐
                    │    输出     │
                    └─────────────┘
```

**v7场景**: 投资选择、战略决策
**Hub的能力**: 
- 任务分解 → 分配给不同Spoke
- 结果聚合 → 冲突检测
- 进度协调 → 超时管理

---

### 【Mesh】网状协作

```
         ┌─────────────────────────────────┐
         │     Mesh: 全连接协商网络       │
         │                                │
    ┌────┴────┐    ┌────┴────┐    ┌────┴────┐
    │ Agent A │◄──►│ Agent B │◄──►│ Agent C │
    │ (创想)  │    │ (实现)  │    │ (批判)  │
    └────┬────┘    └────┬────┘    └────┬────┘
         │              │              │
         └──────┬───────┴───────┬──────┘
                │               │
                └───────┬───────┘
                        │
                        ▼
                    ┌─────────┐
                    │ 共识达成 │
                    └─────────┘
```

**v7场景**: 创新头脑风暴、创意写作、复杂共识
**机制**:
1. 所有Agent同时提案
2. 交叉评审（不是单向）
3. 多轮协商
4. 共识聚合

---

### 【Hybrid】混编拓扑

**复杂报告示例**:
```
Stage 1: Pipeline (信息流水线)
  研究 → 数据清洗 → 初步分析

Stage 2: Hub-Spoke (多视角分析)
  输入 ──Hub──→ 市场分析Spoke
           ├──→ 技术分析Spoke  
           └──→ 风险分析Spoke
           
Stage 3: Mesh (综合共识)
  各Spoke输出 → Mesh协商 → 最终整合

Stage 4: Pipeline (输出质量)
  写作 → 校对 → 发布
```

**v7的自动化**: 自动检测任务复杂度，推荐最优拓扑组合

---

## Emergent Collaboration (涌现式协作)

### 动态角色分配机制

```
不是: "你是研究Agent"
而是: "基于以下任务，谁最适合承担研究?"

流程:
1. Task Analysis → 提取任务特征
2. Role Proposal → 自动提议角色集合
3. Capability Assessment → 评估各Agent能力匹配
4. Role Assignment → 动态分配
5. Execution & Feedback → 执行中动态调整
6. Role Consolidation → 记录最优配置
```

### 示例: 研究报告任务

```
任务: "生成AI芯片行业研究报告"

自动角色提议:
- 数据挖掘Agent (行业数据)
- 分析师Agent (格局分析)
- 财务Agent (财务建模)
- 竞品Agent (对比分析)

分配逻辑:
- 数据挖掘 → 需要强搜索能力 → 分配给研究型Agent
- 分析师 → 需要框架思维 → 分配给分析型Agent
- 财务 → 需要定量能力 → 分配给计算型Agent
- 竞品 → 需要情报收集 → 分配给专项Agent

执行中观察:
- 如果竞品Agent发现的竞品数据很少
- 自动调整: 让数据挖掘Agent补充竞品数据
- 或: 增加一个"竞对情报Agent"
```

---

## Iterative Convergence (迭代收敛)

### 收敛条件

```typescript
interface ConvergenceCriteria {
  // 质量维度阈值
  quality: {                              // 各维度得分
    [dimension: string]: {
      score: number;                      // 当前得分
      threshold: number;                // 阈值
      converged: boolean;               // 是否收敛
    }
  };
  
  // 稳定性检测
  stability: {
    consecutiveIterations: number;       // 连续稳定轮次
    deltaThreshold: number;              // 变化率阈值
    isStable: boolean;                   // 是否稳定
  };
  
  // 硬约束
  hardConstraints: {
    maxIterations: number;               // 最大迭代次数
    timeBudget: number;                  // 时间预算
  };
  
  // 人类介入
  human: {
    approvalsRequired: string[];         // 需要人工审批的节点
    pendingApprovals: ActionId[];      // 待审批
  };
}
```

### 收敛检测算法

```
每轮迭代后:
1. 计算当前质量评分 Q(t)
2. 计算变化率 ΔQ = |Q(t) - Q(t-1)|
3. 检测收敛:
   - 如果 Q(t) >= threshold AND ΔQ < epsilon: 收敛
   - 如果迭代次数 >= max: 强制收敛
   - 如果人类批准: 人为收敛
4. 若未收敛:
   - 分析差距最大的维度
   - 制定改进策略
   - 触发新一轮迭代
```

---

## Quality Prediction (质量预测)

### 预执行预测

```
任务分析 → 难度评估 → 风险预测 → 资源配置

难度评估维度:
- 领域专业性 (1-10)
- 数据可得性 (1-10)
- 分析复杂度 (1-10)
- 时效性要求 (1-10)

风险预测:
- 数据幻觉风险 → 配置数据溯源防线
- 逻辑不连贯风险 → 配置交叉验证
- 遗漏信息风险 → 配置广度检查
- 偏见风险 → 配置多元视角

资源配置:
- 难度8+ → L3深度协作 + Mesh拓扑
- 难度5-7 → L2标准协作 + Hub-Spoke
- 难度<5 → L1轻量协作 + Pipeline
```

---

## v7 使用方式

### 自然语言驱动

```
用户: "用快速模式做个竞品分析"  
→ 解析: "快速"=L1, "竞品分析"=Hub-Spoke拓扑
→ 配置: Synchronous + Hub-Spoke + Egalitarian + Voting + Independent + Session

用户: "正式生成AI芯片行业研究报告，要求高置信度"
→ 解析: "正式"=L3, "行业研究"=Hybrid拓扑(链+星+网)
→ 配置: Async + Hybrid + Meritocratic + Multi-modal + Transactive + Task

用户: "头脑风暴一下营销策略"
→ 解析: "头脑风暴"=Mesh拓扑, "创意"=涌现协作
→ 配置: Synch + Mesh + Egalitarian + Market + Distributed + Session
```

### 显式配置

```yaml
collaboration:
  level: L2
  topology: Hub-Spoke
  tempo: Async
  authority: Meritocratic
  interaction: Debate
  cognition: Shared
  persistence: Task
  
convergence:
  criterion: quality-stable
  maxIterations: 5
  deltaThreshold: 0.1
  
agents:
  - role: Researcher
    count: 2
    topology: Hub-Spoke
  - role: Synthesizer
    count: 1
  - role: Critic
    count: 1
```

---

## v7 技术架构

```
┌─────────────────────────────────────────────┐
│              User Interface                 │
│  (自然语言输入 / YAML配置 / 可视化拓扑)       │
└───────────────────┬─────────────────────────┘
                    │
                    ▼
┌─────────────────────────────────────────────┐
│           Topology Orchestrator             │
│  分析任务 → 推荐/选择拓扑 → 配置协作参数      │
└───────────────────┬─────────────────────────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
        ▼           ▼           ▼
   ┌─────────┐  ┌─────────┐  ┌─────────┐
   │Pipeline │  │Hub-Spoke│  │  Mesh   │
   │Executor │  │Executor │  │Executor │
   └────┬────┘  └────┬────┘  └────┬────┘
        │            │            │
        └────────────┼────────────┘
                     │
                     ▼
         ┌─────────────────────┐
         │ State Machine       │
         │ - CollaborationState│
         │ - AgentStates       │
         │ - ConvergenceMonitor│
         └──────────┬──────────┘
                    │
        ┌───────────┼───────────┐
        │           │           │
        ▼           ▼           ▼
   ┌────────┐  ┌────────┐  ┌────────┐
   │ Retry  │  │ Human  │  │ Output │
   │ Logic  │  │In Loop │  │ Final  │
   └────────┘  └────────┘  └────────┘
```

---

## v7 演进路线

| Phase | 功能 | 周期 | 目标 |
|-------|------|------|------|
| **7.0-alpha** | 拓扑系统 + 收敛机制 | 4周 | 核心框架 |
| **7.0-beta** | 涌现协作 + 预测模型 | 4周 | 智能特性 |
| **7.0-stable** | 优化 + 测试 + 文档 | 2周 | 生产可用 |
| **7.1** | 学习机制 + 跨任务记忆 | 4周 | 进化能力 |
| **7.2** | MCP集成 + 外部Agent | 4周 | 生态扩展 |

---

## 总结: v7的核心升级

| 问题 | v6.1 | v7 |
|------|------|-----|
| 协作模式单一 | 固定链式 | 4种拓扑可选 |
| 轮次计数僵化 | 2/3/4轮 | 收敛导向 |
| 角色预定义 | 固定角色 | 涌现式分配 |
| 无法动态调整 | 线性执行 | 反馈循环 |
| 失败无恢复 | 无 | Retry/Rollback |
| 缺乏集体认知 | 单人分角 | 分布式认知 |

**一句话**: v7从"任务流水线"进化为"认知生态系统"。
