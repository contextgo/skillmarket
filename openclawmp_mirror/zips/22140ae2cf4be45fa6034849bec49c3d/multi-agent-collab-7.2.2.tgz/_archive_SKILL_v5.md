---
name: multi-agent-collab
description: "多Agent协作框架[v6现实对齐版]。聚焦StepFun单会话环境100%可用模式，9种核心模板+3大支撑机制，移除物理不可用方法。触发：'用协作模式'、'多Agent'、'红队审核'、'三轮迭代'。"
version: "6.0.0"
updated: "2026-03-16"
changelog: "v6.0: 现实对齐——移除5种物理不可能方法，保留9种单会话可用模板+3种核心机制; v5.0: Method 12增强（三层幻觉防线）；Method 13增强（8维度质量评分）；新增研究报告专用协作模板"
---

# Multi-Agent Collaboration Framework v6 [现实对齐版]

> **⚠️ 重要**: v6已完成现实对齐
> - **移除**: 5种物理上不可用的方法（多窗口/历史注入/盲审/定时触发等）
> - **保留**: 9种模板 + 3种核心机制（全部StepFun单会话可实现）
> - **详细文档**: 见 `SKILL_v6_full.md` （原v5完整文档作为参考保留）

---

# Multi-Agent Collaboration Framework v5

## When to Activate

ONLY when task meets ALL of:
- Deliverable is non-trivial (report, strategy, proposal, code project)
- Task has 2+ distinct cognitive phases
- User explicitly requests collaboration OR task complexity warrants it

For simple tasks: just do it directly. One focused pass beats three shallow passes.

## Architecture: 5 Layers, 20 Methods

Read full architecture: `D:\XiaoYue_Workspace\projects\终极Agent协作架构\architecture.md`
Read all templates: `D:\XiaoYue_Workspace\projects\终极Agent协作架构\templates.md`
Quick reference: `D:\XiaoYue_Workspace\projects\终极Agent协作架构\quick_reference.md`

### 平台兼容性矩阵（E-MAC-001）

> StepFun 单会话环境下各方法的可用性标注

| # | 方法 | 兼容性 | 说明/降级方案 |
|---|------|--------|-------------|
| **Layer 1 — Planning** |
| 1 | Plan-Execute separation | ✅ 可用 | 先规划再执行 |
| 2 | Contract Net task assignment | ⚠️ 受限 | 单会话模拟多角色分配 |
| 3 | DAG dependency graph | ✅ 可用 | 用 Mermaid 或文本描述 |
| 4 | Pre-check failure modes | ✅ 可用 | 执行前预检 |
| **Layer 2 — Execution** |
| 5 | Multi-window physical isolation | ❌ 不可用 | **降级→Method 7 Blackboard** |
| 6 | Skill chain invocation | ✅ 可用 | 按序调用多个技能 |
| 7 | Blackboard architecture | ✅ 可用 | 通过共享文件传递数据 |
| 8 | Context relay | ⚠️ 受限 | 单会话内模拟压缩交接 |
| 9 | Three-pass constrained thinking | ✅ 可用 | 单会话三轮迭代 |
| 10 | Conversation history export/inject | ❌ 不可用 | **降级→Method 7 Blackboard** |
| **Layer 3 — Quality Assurance** |
| 11 | Adversarial debate | ✅ 可用 | 单会话模拟正反方+裁判 |
| 12 | Red team attack **+三层幻觉防线** | ✅ 可用 | **v5增强：含数据溯源/逻辑一致性/时效性检查** |
| 13 | Blind review **+8维度评分** | ❌ 不可用 | **v5增强：降级→Method 11辩论+8维度评分** |
| 14 | Human-in-the-loop checkpoints | ✅ 可用 | 通过 todo_list_manager 确认 |
| **Layer 4 — Capability Extension** |
| 15 | MCP tool extension | ⚠️ 受限 | 取决于 MCP 服务器可用性 |
| 16 | Script orchestration | ✅ 可用 | 通过 terminal 执行脚本 |
| 17 | Scheduled triggers | ❌ 不可用 | StepFun 不支持定时任务 |
| **Layer 5 — Emergence & Evolution** |
| 18 | Competitive generation | ✅ 可用 | 生成多版本，择优 |
| 19 | Voting consensus | ✅ 可用 | 多角色投票 |
| 20 | Self-play evolution | ⚠️ 受限 | 单会话模拟 |

## Method 12: Red Team Attack v5（三层幻觉防线增强）

### 原有能力
- 5个攻击向量（反转/利益方/假设/执行/数据）

### v5新增能力：三层幻觉防线

来源：stepfun-research-core/prompts/hallucination_defense.py

**使用方式（单会话版）：**

```
请对以下报告执行红队攻击+三层幻觉防线审核，分两轮执行：

第一轮（红队攻击 — 5个攻击向量）：
1. 反转测试：如果结论完全相反，论证是否同样成立？
2. 利益方测试：不同利益方如何看待这些结论？
3. 假设测试：哪些隐含假设如果不成立，结论会崩塌？
4. 执行测试：建议在实际执行中会遇到哪些障碍？
5. 数据测试：数据来源是否可靠？是否有选择性引用？

第二轮（三层幻觉防线审核）：

防线1 — 数据溯源检查：
对每个包含具体数字的声明，检查：
- ✅ [有来源支撑]: 能在原始数据来源中找到
- ⚠️ [AI推断]: 基于数据的合理推断
- ❌ [疑似幻觉]: 明显编造或无法验证

防线2 — 逻辑一致性检查：
- 章节内的数据是否自相矛盾？
- 百分比之和是否合理（市场份额不超过100%）？
- 增长率和绝对值是否匹配？

防线3 — 时效性检查：
- 引用的数据是否标注了时间？
- 是否存在过时数据被当作最新数据使用？

输出格式:
{
    "red_team_issues": [
        {"vector": "反转/利益方/假设/执行/数据", "issue": "具体问题", "severity": "高/中/低"}
    ],
    "hallucination_review": {
        "total_claims": 总声明数,
        "verified_claims": 有来源支撑的数量,
        "inferred_claims": AI推断的数量,
        "suspicious_claims": 疑似幻觉的数量,
        "confidence_score": 整体置信度(0-1),
        "issues": [
            {"claim": "声明", "status": "verified/inferred/suspicious", "reason": "理由", "suggestion": "建议"}
        ]
    },
    "overall_assessment": "整体评估"
}

读取: {报告文件路径}
输出到: {workspace}\reviews\red_team_review.md
```

## Method 13: Blind Review v5（8维度质量评分增强）

### 原有能力
- 基于文档本身判断，不猜测作者意图

### v5新增能力：8维度质量评分

来源：stepfun-research-core/prompts/quality_scoring.py

**使用方式（单会话版）：**

```
请对以下报告进行盲审+8维度质量评分：

你是中立的质量评审专家。你没有看过任何研究过程，你只看到了最终文档。
请基于文档本身判断，不要猜测作者的意图。

8维度评分（每维度1-10分）：

1. 数据充实度 (data_richness)
   - 10分: 数据丰富，覆盖所有关键指标
   - 5分: 数据基本充足，部分指标缺失
   - 1分: 数据严重不足

2. 分析深度 (analysis_depth)
   - 10分: 分析深入，有独特洞察
   - 5分: 分析一般，常规解读
   - 1分: 分析浅显，仅罗列数据

3. 逻辑连贯性 (logical_coherence)
   - 10分: 逻辑严密，前后呼应
   - 5分: 逻辑基本通顺
   - 1分: 逻辑混乱，自相矛盾

4. 框架完整性 (framework_completeness)
   - 10分: 5大框架完整覆盖
   - 5分: 部分框架覆盖
   - 1分: 缺乏系统框架

5. 可操作性 (actionability)
   - 10分: 建议具体可执行
   - 5分: 建议较笼统
   - 1分: 建议空洞无物

6. 数据溯源 (data_traceability)
   - 10分: 所有数据标注来源
   - 5分: 部分数据标注来源
   - 1分: 数据来源不明

7. 可视化质量 (visualization_quality)
   - 10分: 图表恰当，直观有效
   - 5分: 图表基本可用
   - 1分: 图表缺失或不恰当

8. 专业性 (professionalism)
   - 10分: 术语准确，表达专业
   - 5分: 基本专业
   - 1分: 术语错误，表达随意

输出格式:
{
    "scores": {
        "data_richness": 分数,
        "analysis_depth": 分数,
        "logical_coherence": 分数,
        "framework_completeness": 分数,
        "actionability": 分数,
        "data_traceability": 分数,
        "visualization_quality": 分数,
        "professionalism": 分数
    },
    "overall_score": 总分(满分80),
    "grade": "A/B/C/D",
    "strengths": ["优势1", "优势2"],
    "weaknesses": ["不足1", "不足2"],
    "improvement_suggestions": ["建议1", "建议2", "建议3"]
}

评级标准: A(64-80) B(48-64) C(32-48) D(<32)

读取: {报告文件路径}
输出到: {workspace}\reviews\quality_score.md
```

## 新增模板：研究报告专用协作模板（v5新增）

### 适用场景
市场研究报告、行业分析报告、投资研究报告

### 单会话版

```
请为我完成以下市场研究任务，分四轮执行：

第一轮（数据采集）：
搜索并整理关于{行业}的关键数据。只输出编号事实+来源，不下结论。
使用 stepfun-research-core 的数据标记规范：每个数据点标注 [来源X]。
输出到：{workspace}\research\findings.md

第二轮（报告撰写）：
读取findings.md作为唯一输入，使用5大框架撰写研究报告。
框架路由：根据行业特征自动选择最适合的框架组合。
每个核心论点标注[ref: findings #X]。不许引入findings中没有的信息。
输出到：{workspace}\drafts\draft_v1.md

第三轮（红队审核+三层幻觉防线）：
读取draft_v1.md，执行：
- 5个攻击向量（反转/利益方/假设/执行/数据）
- 三层幻觉防线（数据溯源/逻辑一致性/时效性）
必须找出≥5个实质性问题。
输出到：{workspace}\reviews\red_team_review.md

第四轮（8维度质量评分+终稿）：
读取draft_v1.md和red_team_review.md。
执行8维度质量评分，整合有效批评，输出终稿。
输出到：{workspace}\final\report_final.md
同时输出质量评分到：{workspace}\final\quality_score.json
```

### 质量门控

- **A级(64-80)**: 直接输出，无需修改
- **B级(48-64)**: 输出并标注改进建议
- **C级(32-48)**: 自动触发修正流程，重新生成低分章节
- **D级(<32)**: 报告不合格，需要重新采集数据和撰写

## 与其他Skill的协同

| Skill | 协同方式 |
|-------|---------|
| unified-market-research | 深度模式调用Method 12+13增强 |
| stepfun-research-core | 提供三层防线和8维度评分Prompt |
| stepfun-research-engine | 提供LLMClient和质量审核器 |
| byterover | 研究完成后存入项目知识库 |
| self-improvement | 研究事件写入记忆 + 审核发现问题时记录学习点 |

## 原有协作模板（v4继承，完整保留）

以下模板完整保留，详见 `D:\XiaoYue_Workspace\projects\终极Agent协作架构\templates.md`：

| 模板 | 适用场景 | 模式 |
|------|---------|------|
| 模板一：研究→写作→审核 | 报告、文章、方案、文档 | 单会话/多窗口 |
| 模板二：正方→反方→裁判 | 投资决策、战略选择、技术选型 | 单会话/多窗口 |
| 模板三：数据→可视化→叙事 | 数据分析报告、仪表盘 | 单会话 |
| 模板四：开发→测试→审查 | 代码项目、技术方案 | 单会话 |
| 模板五：三轮迭代深化 | 需要逐步深化的复杂任务 | 单会话 |
| 模板六：竞争式生成 | 需要多个备选方案 | 单会话 |
| 模板七：专家委员会 | 多领域交叉问题 | 单会话 |
| 模板八：翻译→校对→润色 | 翻译任务 | 单会话 |
| 模板九：需求→设计→评审 | 产品设计、PRD | 单会话 |
| 模板十：教学→练习→反馈 | 学习辅导 | 单会话 |

**使用方式**: 读取 `D:\XiaoYue_Workspace\projects\终极Agent协作架构\templates.md` 获取完整模板内容。
