# AI Agent Memory Architecture Patterns

## Overview
AI Agent 的记忆系统是其核心能力之一。本技能提供多层记忆架构的设计模式，帮助构建可靠、可扩展的 Agent 记忆系统。

## Three-Tier Memory Architecture

### Tier 1: Working Memory (Short-term)
- **载体**: Context window / in-memory state
- **容量**: 4K-200K tokens（取决于模型）
- **策略**: FIFO + priority-based eviction
- **最佳实践**:
  - 只保留当前任务相关的信息
  - 使用 summary 压缩旧信息
  - 定期 flush 到持久层

### Tier 2: Episodic Memory (Mid-term)
- **载体**: 文件系统 / SQLite / JSON
- **容量**: 无限制（受存储限制）
- **策略**: 时间索引 + tag-based retrieval
- **最佳实践**:
  - 每次任务完成写入日志（daily notes）
  - 使用结构化格式（markdown + YAML frontmatter）
  - 按 date + project 组织目录结构

### Tier 3: Semantic Memory (Long-term)
- **载体**: 向量数据库 / 知识图谱
- **容量**: 无限制
- **策略**: 语义相似度检索
- **最佳实践**:
  - 定期从 Tier 2 提炼经验教训
  - 使用 embedding 模型建立语义索引
  - 支持 "recall by meaning" 而非 keyword matching

## Memory Flush Protocol
当 context window 使用率超过 70% 时触发 flush：
1. 提取关键决策和结论
2. 写入 episodic memory（daily notes）
3. 更新 semantic memory（lessons learned）
4. 压缩 context window（只保留摘要）

## Implementation Checklist
- [ ] 选择合适的持久层（文件/DB/向量库）
- [ ] 设计 flush 触发机制（token count / 时间 / 事件）
- [ ] 实现分层检索策略
- [ ] 添加记忆去重和压缩
- [ ] 建立记忆索引和搜索能力

## Anti-patterns to Avoid
1. **把所有对话存到 memory** → 信息噪声过大，检索效率低
2. **只记录结论不记录推理** → 丢失决策上下文
3. **没有 flush 机制** → context window 溢出后记忆丢失
4. **单一记忆层** → 无法平衡速度和容量