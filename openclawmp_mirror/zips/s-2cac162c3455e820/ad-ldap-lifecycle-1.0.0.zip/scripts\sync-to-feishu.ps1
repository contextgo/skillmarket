﻿[CmdletBinding()]
param(
    [string]$OU,
    [switch]$AllUsers,
    [switch]$TestMode
)

. (Join-Path $PSScriptRoot "..\lib\ad-helper.ps1")
. (Join-Path $PSScriptRoot "..\lib\feishu-bitables.ps1")

$configPath = Join-Path $PSScriptRoot "..\config\settings.json"
$configJson = Get-Content -Path $configPath -Raw -Encoding UTF8
$config = $configJson | ConvertFrom-Json

if (-not $config.feishu.enabled) {
    Write-Host "Feishu integration disabled."
    exit 0
}

if (-not (Initialize-FeishuBitable -ConfigPath $configPath)) {
    Write-Error "Failed to initialize Feishu"
    exit 1
}

$tableId = $config.feishu.user_table_id
if (-not $tableId) {
    Write-Error "user_table_id not configured in settings.json"
    exit 1
}

# ============================================================
# Step 1: Get all existing records from Feishu for dedup
# ============================================================
Write-Host "Loading existing records from Feishu..."
$existingRecords = @{}
$pageToken = ""

do {
    $data = Get-FeishuRecords -TableId $tableId -PageSize 500 -PageToken $pageToken
    if ($data -and $data.items) {
        foreach ($item in $data.items) {
            $recordId = $item.record_id
            $recordInfo = $item.fields.RecordInfo
            if ($recordInfo -and $recordInfo -match '^([^|]+)\|') {
                $sam = $Matches[1].Trim()
                if ($sam) { $existingRecords[$sam] = $recordId }
            }
        }
        $pageToken = if ($data.has_more) { $data.page_token } else { "" }
    } else {
        $pageToken = ""
    }
} while ($pageToken)

Write-Host "Found $($existingRecords.Count) existing records in Feishu"

# ============================================================
# Step 2: Get users from AD via UTF-8 LDAP
# ============================================================
Write-Host "Querying AD via UTF-8 LDAP..."
$users = @()

try {
    $conn = Connect-LDAPServer
    $entries = Search-LDAP -Connection $conn -Filter "(objectClass=user)" -Properties @('samAccountName','displayName','mail','distinguishedName','userAccountControl','pwdLastSet','lastLogonTimestamp') -Scope Subtree
    
    foreach ($entry in $entries) {
        $sam = $entry.Attributes['samAccountName'][0]
        $display = if ($entry.Attributes['displayName']) { $entry.Attributes['displayName'][0] } else { "" }
        $mail = if ($entry.Attributes['mail']) { $entry.Attributes['mail'][0] } else { "" }
        $dn = $entry.Attributes['distinguishedName'][0]
        $uac = $entry.Attributes['userAccountControl'][0]
        
        # Skip disabled accounts
        if ($uac -band 0x2) { continue }
        
        $users += [PSCustomObject]@{
            SamAccountName = $sam
            DisplayName = $display
            Mail = $mail
            DistinguishedName = $dn
        }
    }
    $conn.Dispose()
} catch {
    Write-Warning "LDAP query failed: $_ - falling back to Get-ADUser"
    if ($OU) {
        $adUsers = Get-ADUsers -OU $OU
    } else {
        $adUsers = Get-ADUsers -All
    }
    $users = $adUsers | ForEach-Object {
        [PSCustomObject]@{
            SamAccountName = $_.SamAccountName
            DisplayName = $_.DisplayName
            Mail = $_.Mail
            DistinguishedName = $_.DistinguishedName
        }
    }
}

Write-Host "Found $($users.Count) enabled users in AD"

if ($TestMode) {
    Write-Host "TEST MODE - Showing first 5 users:"
    foreach ($user in $users[0..([Math]::Min(4, $users.Count-1))]) {
        Write-Host "  $($user.SamAccountName) | $($user.DisplayName) | $($user.Mail) | $($user.DistinguishedName)"
    }
    exit 0
}

# ============================================================
# Step 3: Sync each user (insert or skip if exists)
# ============================================================
$insertCount = 0
$skipCount = 0
$failCount = 0

foreach ($user in $users) {
    $sam = $user.SamAccountName
    
    # Skip if already exists
    if ($existingRecords.ContainsKey($sam)) {
        Write-Host "[SKIP] $sam (already exists)"
        $skipCount++
        continue
    }
    
    $fields = @{
        "RecordInfo" = "$($user.SamAccountName)|$($user.DisplayName)|$($user.Mail)|$($user.DistinguishedName)"
    }
    
    $record = New-FeishuRecord -TableId $tableId -Fields $fields
    if ($record) {
        $insertCount++
        $existingRecords[$sam] = $record.record_id
        Write-Host "[INSERT] $sam"
    } else {
        $failCount++
        Write-Warning "[FAIL] $sam"
    }
}

Write-Host "`nSync completed."
Write-Host "Inserted: $insertCount"
Write-Host "Skipped (duplicate): $skipCount"
Write-Host "Failed: $failCount"

exit 0
