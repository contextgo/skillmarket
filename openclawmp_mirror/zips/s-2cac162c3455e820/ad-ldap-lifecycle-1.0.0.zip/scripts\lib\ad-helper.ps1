# AD LDAP Helper Functions
# Pure ASCII / PowerShell 5.1 Compatible

$script:ADConfig = $null

function Initialize-ADEnvironment {
    param([string]$ConfigPath)

    $configJson = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
    $config = $configJson | ConvertFrom-Json
    $script:ADConfig = $config

    Import-Module ActiveDirectory -ErrorAction SilentlyContinue
    if (-not (Get-Module ActiveDirectory)) {
        Write-Warning "ActiveDirectory module not available. Some functions may fail."
    }

    return $true
}

function Get-ADUsers {
    param(
        [string]$OU = "",
        [switch]$All
    )

    try {
        if ($OU) {
            $users = Get-ADUser -Filter * -SearchBase $OU -Properties SamAccountName,DisplayName,Mail,DistinguishedName,LastLogonDate,PasswordExpired,UserPrincipalName
        } else {
            $users = Get-ADUser -Filter * -Properties SamAccountName,DisplayName,Mail,DistinguishedName,LastLogonDate,PasswordExpired,UserPrincipalName
        }
        return $users
    } catch {
        Write-Warning "Failed to get AD users: $_"
        return @()
    }
}

function Get-InactiveUsers {
    param([int]$Days = 90)

    $cutoff = (Get-Date).AddDays(-$Days)
    $allUsers = Get-ADUsers -All
    $inactive = @()

    foreach ($user in $allUsers) {
        $lastLogon = $user.LastLogonDate
        if ($lastLogon -and $lastLogon -lt $cutoff) {
            $inactive += $user
        } elseif (-not $lastLogon) {
            $inactive += $user
        }
    }

    return $inactive
}

function Get-ExpiredPasswords {
    $allUsers = Get-ADUsers -All
    $expired = @()

    foreach ($user in $allUsers) {
        if ($user.PasswordExpired -eq $true) {
            $expired += $user
        }
    }

    return $expired
}

function New-ADUser {
    param(
        [string]$UserName,
        [string]$FullName,
        [string]$Department,
        [string]$Password,
        [string]$OU = "",
        [switch]$ForceChangePassword
    )

    $params = @{
        Name = $UserName
        GivenName = $FullName.Split(' ')[0]
        Surname = if ($FullName.Contains(' ')) { $FullName.Split(' ')[-1] } else { '' }
        SamAccountName = $UserName
        UserPrincipalName = "$UserName@$($script:ADConfig.domain)"
        Enabled = $true
        ChangePasswordAtLogon = $ForceChangePassword.IsPresent
        PasswordNeverExpires = $false
        AccountPassword = (ConvertTo-SecureString $Password -AsPlainText -Force)
    }

    if ($OU) { $params['Path'] = $OU }
    if ($Department) { $params['Department'] = $Department }

    New-ADUser @params -ErrorAction Stop | Out-Null

    return Get-ADUser -Identity $UserName -Properties *
}

function Add-UserToGroup {
    param(
        [string]$User,
        [string]$Group
    )
    Add-ADGroupMember -Identity $Group -Members $User -ErrorAction Stop
}

function Remove-UserFromAllGroups {
    param([string]$User)
    $adUser = Get-ADUser -Identity $User -Properties MemberOf
    foreach ($group in $adUser.MemberOf) {
        Remove-ADGroupMember -Identity $group -Members $user -Confirm:$false -ErrorAction SilentlyContinue
    }
}

function Disable-ADUserAccount {
    param([string]$User)
    Disable-ADAccount -Identity $User -ErrorAction Stop
}

function Remove-ADUserAccount {
    param([string]$User)
    Remove-ADUser -Identity $User -Confirm:$false -ErrorAction Stop
}
