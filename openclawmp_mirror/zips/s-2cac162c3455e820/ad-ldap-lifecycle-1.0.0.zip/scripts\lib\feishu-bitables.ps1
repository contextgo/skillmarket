# Feishu Bitable Library v2 - AD/LDAP Lifecycle (使用用户Token + 字段映射)
# 支持从 OpenClaw 加密存储读取用户 access_token，自动映射字段名

$script:FeishuConfig = $null
$script:UserTokenCache = @{token=$null; expire_at=0}

$script:TableFieldMappings = @{
    'tblZni6lh8ue3OtZ' = @{
        content = 'RecordInfo'
    }
}

function Get-OpenClawUserToken {
    # 优先使用配置中的 user_access_token
    if ($script:FeishuConfig.user_access_token) {
        return $script:FeishuConfig.user_access_token
    }
    
    # 从缓存读取
    $nowMs = [DateTime]::UtcNow.Ticks
    if ($script:UserTokenCache.token -and $script:UserTokenCache.expire_at -gt $nowMs) {
        return $script:UserTokenCache.token
    }
    
    # 通过 Node.js 解密 OpenClaw 的 UAT 文件
    $decryptScript = @"
const{readFileSync,existsSync}=require('fs');
const{createDecipheriv}=require('crypto');
const path=require('path'),os=require('os');
const d=path.join(process.env.LOCALAPPDATA||path.join(os.homedir(),'AppData','Local'),'openclaw-feishu-uat');
const mk=path.join(d,'master.key'),ef=path.join(d,'cli_a92cf9e289f65cd5_ou_554abae9e0c9aa8c225793e33fe181c3.enc');
if(!existsSync(ef)||!existsSync(mk)){process.exit(1);}
try{
const k=readFileSync(mk),e=readFileSync(ef);
const iv=e.subarray(0,12),tag=e.subarray(12,28),c=e.subarray(28);
const x=createDecipheriv('aes-256-gcm',k,iv);x.setAuthTag(tag);
const td=JSON.parse(Buffer.concat([x.update(c),x.final()]).toString('utf8'));
console.log(JSON.stringify({token:td.accessToken||td.access_token,expireAt:td.expiresAt||td.expire_at||0}));
}catch(e){process.exit(1);}
"@
    
    $nodeScript = "$env:TEMP\decrypt_uat_$PID.js"
    $decryptScript | Out-File -FilePath $nodeScript -Encoding UTF8 -Width 200
    
    try {
        $output = & node $nodeScript 2>$null
        Remove-Item $nodeScript -ErrorAction SilentlyContinue
        if ($output) {
            $data = $output | ConvertFrom-Json
            $token = $data.token
            $expireAt = $data.expireAt
            if ($token -and $token.Length -gt 10) {
                $bufferMs = 5 * 60 * 1000
                $script:UserTokenCache.token = $token
                $script:UserTokenCache.expire_at = ($expireAt - $bufferMs) * 10000
                return $token
            }
        }
    } catch {}
    Remove-Item $nodeScript -ErrorAction SilentlyContinue
    return $null
}

function Initialize-FeishuBitable {
    param([string]$ConfigPath)
    $configJson = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
    $config = $configJson | ConvertFrom-Json
    $script:FeishuConfig = $config.feishu
    if (-not $script:FeishuConfig.enabled) { return $false }
    
    $token = Get-OpenClawUserToken
    if (-not $token) { Write-Warning "Could not get user token"; return $false }
    return $true
}

function Invoke-FeishuApi {
    param([string]$Method="GET", [string]$ApiPath, [object]$Body=$null)
    
    $token = Get-OpenClawUserToken
    if (-not $token) { return @{success=$false; code=-1; msg="No token"} }
    
    $url = "https://open.feishu.cn/open-apis$ApiPath"
    $headers = @{"Authorization"="Bearer $token"}
    
    try {
        if ($Body) {
            $bodyJson = $Body | ConvertTo-Json -Compress -Depth 10
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($bodyJson)
            $resp = Invoke-WebRequest -Uri $url -Method $Method -Headers $headers -Body $bytes -TimeoutSec 20 -ContentType "application/json; charset=utf-8"
        } else {
            $resp = Invoke-WebRequest -Uri $url -Method $Method -Headers $headers -TimeoutSec 20
        }
        $content = $resp.Content | ConvertFrom-Json
        return @{success=($content.code -eq 0); code=$content.code; msg=$content.msg; data=$content.data}
    } catch {
        $ex = $_.Exception
        if ($ex.Response) {
            $status = [int]$ex.Response.StatusCode
            $reader = [System.IO.StreamReader]::new($ex.Response.GetResponseStream())
            $bodyText = $reader.ReadToEnd(); $reader.Close()
            try { $j = $bodyText | ConvertFrom-Json; $code = $j.code; $msg = $j.msg } catch { $code = $status; $msg = $bodyText }
            return @{success=$false; code=$code; msg=$msg}
        }
        return @{success=$false; code=-1; msg=$ex.Message}
    }
}

function New-FeishuRecord {
    param([string]$TableId, [hashtable]$Fields)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    # 字段名映射
    $fieldMaps = $script:TableFieldMappings[$TableId]
    if ($fieldMaps) {
        $mapped = @{}
        foreach ($key in $Fields.Keys) {
            $chinese = $fieldMaps[$key]
            if ($chinese) { $mapped[$chinese] = $Fields[$key] } else { $mapped[$key] = $Fields[$key] }
        }
        $Fields = $mapped
    }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "POST" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records" -Body @{fields=$Fields}
    
    if (-not $result.success) { Write-Warning "Create record failed: $($result.msg) (code $($result.code))"; return $null }
    return $result.data.record
}

function Get-FeishuRecords {
    param([string]$TableId, [string]$ViewId="", [int]$PageSize=50, [string]$PageToken="")
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $path = "/bitable/v1/apps/$appToken/tables/$TableId/records/search"
    $q = @{page_size=$PageSize; fields=@()}
    if ($ViewId) { $q.view_id = $ViewId }
    if ($PageToken) { $q.page_token = $PageToken }
    
    $result = Invoke-FeishuApi -Method "POST" -ApiPath $path -Body $q
    if (-not $result.success) { Write-Warning "Get records failed: $($result.msg)"; return $null }
    return $result.data
}

function Update-FeishuRecord {
    param([string]$TableId, [string]$RecordId, [hashtable]$Fields)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $fieldMaps = $script:TableFieldMappings[$TableId]
    if ($fieldMaps) {
        $mapped = @{}
        foreach ($key in $Fields.Keys) {
            $chinese = $fieldMaps[$key]
            if ($chinese) { $mapped[$chinese] = $Fields[$key] } else { $mapped[$key] = $Fields[$key] }
        }
        $Fields = $mapped
    }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "PUT" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records/$RecordId" -Body @{fields=$Fields}
    if (-not $result.success) { Write-Warning "Update failed: $($result.msg)"; return $null }
    return $result.data.record
}

function Delete-FeishuRecord {
    param([string]$TableId, [string]$RecordId)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "DELETE" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records/$RecordId"
    if (-not $result.success) { Write-Warning "Delete failed: $($result.msg)"; return $false }
    return $true
}
