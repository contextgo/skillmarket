---
name: ad-ldap-lifecycle
displayName: AD LDAP Lifecycle Manager
description: "Active Directory 用户生命周期管理器 - 入职/离职/审计/飞书同步，支持中文 DN 的 UTF-8 编码处理"
version: 1.0.0
type: skill
tags: ["active-directory", "ldap", "lifecycle", "automation", "bitable", "飞书"]
---

# AD LDAP 用户生命周期管理器

管理企业 Active Directory 用户生命周期：入职创建账号、离职禁用账号、定期审计、多维表格同步。

## 功能

- **用户查询**：按 OU 或全域名查询 AD 用户
- **入职流程**：创建 AD 账号、自动加入分组、设置初始密码
- **离职流程**：禁用账号、移除分组
- **定期审计**：检测僵尸账号、密码过期、特权账号
- **飞书同步**：将 AD 用户数据同步到飞书多维表格

## 核心脚本

| 脚本 | 功能 |
|------|------|
| scripts/new-employee.ps1 | 入职 - 创建账号并加入分组 |
| scripts/offboard-employee.ps1 | 离职 - 禁用/删除账号 |
| scripts/audit.ps1 | 审计 - 僵尸账号、密码过期 |
| scripts/sync-to-feishu.ps1 | 同步到飞书多维表格 |

## 重要：UTF-8 编码

调用飞书 API 时，**必须**使用 UTF-8 字节数组传 body。

## 配置

编辑 config/settings.json 配置 AD 域名、服务器地址、飞书多维表格参数。