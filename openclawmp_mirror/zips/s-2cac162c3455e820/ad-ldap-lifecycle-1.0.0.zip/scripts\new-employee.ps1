﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$UserName,
    [Parameter(Mandatory=$true)]
    [string]$FullName,
    [Parameter(Mandatory=$true)]
    [string]$Department,
    [string]$OU = "",
    [switch]$SendToFeishu,
    [switch]$TestMode
)

. (Join-Path $PSScriptRoot "..\lib\ad-helper.ps1")
. (Join-Path $PSScriptRoot "..\lib\feishu-bitables.ps1")

$configPath = Join-Path $PSScriptRoot "..\config\settings.json"
$configJson = Get-Content -Path $configPath -Raw -Encoding UTF8
$config = $configJson | ConvertFrom-Json

Write-Host "Creating new employee: $UserName ($FullName)"
Write-Host "Department: $Department"

if ($TestMode) {
    Write-Host "TEST MODE - No changes will be made"
    exit 0
}

# Create AD user
try {
    $password = $config.default_password
    $newUser = New-ADUser -UserName $UserName -FullName $FullName -Department $Department -Password $password -OU $OU -ForceChangePassword $true
    Write-Host "User created successfully: $($newUser.DistinguishedName)"
} catch {
    Write-Error "Failed to create user: $_"
    exit 1
}

# Add to default group
try {
    $groupDN = $config.groups.new_employees
    Add-ADGroupMember -Identity $groupDN -Members $newUser
    Write-Host "Added to group: $groupDN"
} catch {
    Write-Warning "Failed to add to group: $_"
}

# Send to Feishu if requested
if ($SendToFeishu -and $config.feishu.enabled) {
    if (-not (Initialize-FeishuBitable -ConfigPath $configPath)) {
        Write-Warning "Failed to initialize Feishu"
        exit 0
    }

    $tableId = $config.feishu.user_table_id
    if ($tableId) {
        $fields = @{
            "文本" = "$UserName|$FullName|$Department|$($newUser.DistinguishedName)|CREATED|$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))"
        }
        $record = New-FeishuRecord -TableId $tableId -Fields $fields
        if ($record) {
            Write-Host "User info synced to Feishu"
        }
    }
}

Write-Host "Employee onboarding completed."
exit 0
