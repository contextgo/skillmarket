﻿# AD LDAP Helper Functions
# Pure ASCII / PowerShell 5.1 Compatible
# UTF-8 编码支持：DirectorySearcher + LDAP Protocol

$script:ADConfig = $null

function New-UTF8DirectorySearcher {
    param(
        [string]$LDAPPath = "",
        [string]$Filter = "(objectClass=user)",
        [string[]]$Properties = @(),
        [switch]$Deep
    )
    
    # 创建 DirectoryEntry
    if ($LDAPPath) {
        $root = New-Object System.DirectoryServices.DirectoryEntry($LDAPPath)
    } else {
        $root = New-Object System.DirectoryServices.DirectoryEntry
    }
    
    $searcher = New-Object System.DirectoryServices.DirectorySearcher($root)
    $searcher.Filter = $Filter
    $searcher.PageSize = 256
    
    # 关键：设置 UTF-8 编码，避免中文乱码
    $searcher.Encoding = [System.Text.Encoding]::UTF8
    
    # 属性预加载
    if ($Properties.Count -gt 0) {
        foreach ($prop in $Properties) {
            [void]$searcher.PropertiesToLoad.Add($prop)
        }
    }
    
    if ($Deep) {
        $searcher.SearchScope = [System.DirectoryServices.SearchScope]::Subtree
    } else {
        $searcher.SearchScope = [System.DirectoryServices.SearchScope]::OneLevel
    }
    
    return $searcher
}

function Find-ADUserByAccount {
    param([string]$AccountName)
    $searcher = New-UTF8DirectorySearcher -Filter "(&(objectClass=user)(samAccountName=$AccountName))" -Properties @('samAccountName','displayName','mail','distinguishedName','userAccountControl','pwdLastSet','lastLogonTimestamp') -Deep
    $result = $searcher.FindOne()
    if ($result) {
        $props = $result.Properties
        return @{
            SamAccountName = if ($props['samaccountname']) { $props['samaccountname'][0] } else { $null }
            DisplayName    = if ($props['displayname']) { $props['displayname'][0] } else { $null }
            Mail           = if ($props['mail']) { $props['mail'][0] } else { $null }
            DistinguishedName = if ($props['distinguishedname']) { $props['distinguishedname'][0] } else { $null }
            UserAccountControl = if ($props['useraccountcontrol']) { $props['useraccountcontrol'][0] } else { $null }
            PwdLastSet     = if ($props['pwdlastset']) { $props['pwdlastset'][0] } else { $null }
            LastLogonTimestamp = if ($props['lastlogontimestamp']) { $props['lastlogontimestamp'][0] } else { $null }
        }
    }
    return $null
}

function Initialize-ADEnvironment {
    param([string]$ConfigPath)

    $configJson = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
    $config = $configJson | ConvertFrom-Json
    $script:ADConfig = $config

    Import-Module ActiveDirectory -ErrorAction SilentlyContinue
    if (-not (Get-Module ActiveDirectory)) {
        Write-Warning "ActiveDirectory module not available. Some functions may fail."
    }

    return $true
}

function Get-ADUsers {
    param(
        [string]$OU = "",
        [switch]$All
    )

    # 优先使用 AD 模块（自动处理 UTF-8）
    if (Get-Command Get-ADUser -ErrorAction SilentlyContinue) {
        try {
            $props = 'SamAccountName','DisplayName','Mail','DistinguishedName','LastLogonDate','PasswordExpired','UserPrincipalName'
            if ($OU) {
                $users = Get-ADUser -Filter * -SearchBase $OU -Properties $props
            } else {
                $users = Get-ADUser -Filter * -Properties $props
            }
            return $users
        } catch {
            Write-Warning "Get-ADUser failed: $_"
            # Fallback to DirectorySearcher
        }
    }
    
    # Fallback: 使用 UTF-8 DirectorySearcher
    Write-Host "Using UTF-8 DirectorySearcher fallback..."
    $results = @()
    try {
        if ($OU) {
            $searcher = New-UTF8DirectorySearcher -LDAPPath $OU -Filter "(objectClass=user)" -Properties @('samAccountName','displayName','mail','distinguishedName','lastLogonTimestamp','pwdLastSet','userAccountControl') -Deep
        } else {
            $searcher = New-UTF8DirectorySearcher -Filter "(objectClass=user)" -Properties @('samAccountName','displayName','mail','distinguishedName','lastLogonTimestamp','pwdLastSet','userAccountControl') -Deep
        }
        foreach ($r in $searcher.FindAll()) {
            $p = $r.Properties
            $lastLogon = if ($p['lastlogontimestamp']) { [DateTime]::FromFileTime($p['lastlogontimestamp'][0]) } else { $null }
            $pwdExpired = if ($p['pwdlastset'] -and $p['pwdlastset'][0] -eq 0) { $true } else { $false }
            $results += [PSCustomObject]@{
                SamAccountName     = if ($p['samaccountname']) { $p['samaccountname'][0] } else { '' }
                DisplayName        = if ($p['displayname']) { $p['displayname'][0] } else { '' }
                Mail               = if ($p['mail']) { $p['mail'][0] } else { '' }
                DistinguishedName  = if ($p['distinguishedname']) { $p['distinguishedname'][0] } else { '' }
                LastLogonDate      = $lastLogon
                PasswordExpired    = $pwdExpired
                UserPrincipalName  = if ($p['samaccountname']) { "$($p['samaccountname'][0])@$($script:ADConfig.domain)" } else { '' }
            }
        }
    } catch {
        Write-Warning "DirectorySearcher fallback also failed: $_"
    }
    return $results
}

function Get-InactiveUsers {
    param([int]$Days = 90)

    $cutoff = (Get-Date).AddDays(-$Days)
    $allUsers = Get-ADUsers -All
    $inactive = @()

    foreach ($user in $allUsers) {
        $lastLogon = $user.LastLogonDate
        if ($lastLogon -and $lastLogon -lt $cutoff) {
            $inactive += $user
        } elseif (-not $lastLogon) {
            $inactive += $user
        }
    }

    return $inactive
}

function Get-ExpiredPasswords {
    $allUsers = Get-ADUsers -All
    $expired = @()

    foreach ($user in $allUsers) {
        if ($user.PasswordExpired -eq $true) {
            $expired += $user
        }
    }

    return $expired
}

function New-ADUser {
    param(
        [string]$UserName,
        [string]$FullName,
        [string]$Department,
        [string]$Password,
        [string]$OU = "",
        [switch]$ForceChangePassword
    )

    $params = @{
        Name = $UserName
        GivenName = $FullName.Split(' ')[0]
        Surname = if ($FullName.Contains(' ')) { $FullName.Split(' ')[-1] } else { '' }
        SamAccountName = $UserName
        UserPrincipalName = "$UserName@$($script:ADConfig.domain)"
        Enabled = $true
        ChangePasswordAtLogon = $ForceChangePassword.IsPresent
        PasswordNeverExpires = $false
        AccountPassword = (ConvertTo-SecureString $Password -AsPlainText -Force)
    }

    if ($OU) { $params['Path'] = $OU }
    if ($Department) { $params['Department'] = $Department }

    New-ADUser @params -ErrorAction Stop | Out-Null

    return Get-ADUser -Identity $UserName -Properties *
}

function Add-UserToGroup {
    param(
        [string]$User,
        [string]$Group
    )
    Add-ADGroupMember -Identity $Group -Members $User -ErrorAction Stop
}

function Remove-UserFromAllGroups {
    param([string]$User)
    $adUser = Get-ADUser -Identity $User -Properties MemberOf
    foreach ($group in $adUser.MemberOf) {
        Remove-ADGroupMember -Identity $group -Members $user -Confirm:$false -ErrorAction SilentlyContinue
    }
}

function Disable-ADUserAccount {
    param([string]$User)
    Disable-ADAccount -Identity $User -ErrorAction Stop
}

function Remove-ADUserAccount {
    param([string]$User)
    Remove-ADUser -Identity $User -Confirm:$false -ErrorAction Stop
}

# ============================================================
# LDAP Protocol 直接调用（UTF-8 编码支持）
# 用于 AD 模块不可用时的完整替代方案
# ============================================================
function Connect-LDAPServer {
    param(
        [string]$Server = "",
        [int]$Port = 389
    )
    
    try {
        Add-Type -AssemblyName System.DirectoryServices.Protocols
    } catch {}
    
    if (-not $Server) {
        # 自动从 RootDse 获取
        try {
            $root = [ADSI]"LDAP://RootDse"
            $Server = $root.dnsHostName
            if (-not $Server) { $Server = $env:USERDNSDOMAIN }
        } catch {
            $Server = $env:LOGONSERVER -replace '\\',''
            if (-not $Server) { $Server = "localhost" }
        }
    }
    
    $identifier = New-Object System.DirectoryServices.Protocols.LdapDirectoryIdentifier($Server, $Port)
    $conn = New-Object System.DirectoryServices.Protocols.LdapConnection($identifier)
    $conn.AuthType = [System.DirectoryServices.Protocols.AuthType]::Negotiate
    $conn.SessionOptions.ProtocolVersion = 3
    # 关键：设置 UTF-8 编码
    $conn.SessionOptions.Encoding = [System.Text.Encoding]::UTF8
    $conn.Bind()
    
    return $conn
}

function Search-LDAP {
    param(
        [object]$Connection,
        [string]$Base = "",
        [string]$Filter = "(objectClass=user)",
        [string[]]$Properties = @(),
        [string]$Scope = "Subtree"
    )
    
    if (-not $Connection) { throw "No LDAP connection" }
    if (-not $Base) {
        $root = [ADSI]"LDAP://RootDse"
        $Base = $root.defaultNamingContext
    }
    
    $scopeMap = @{
        "Subtree"   = [System.DirectoryServices.Protocols.SearchScope]::Subtree
        "OneLevel"  = [System.DirectoryServices.Protocols.SearchScope]::OneLevel
        "Base"      = [System.DirectoryServices.Protocols.SearchScope]::Base
    }
    
    $req = New-Object System.DirectoryServices.Protocols.SearchRequest(
        $Base,
        $Filter,
        $scopeMap[$Scope],
        $Properties
    )
    
    $resp = $Connection.SendRequest($req)
    return $resp.Entries
}

function Get-ADUserViaLDAP {
    param([string]$AccountName)
    
    try {
        $conn = Connect-LDAPServer
        $entries = Search-LDAP -Connection $conn -Filter "(&(objectClass=user)(samAccountName=$AccountName))" -Properties @('samAccountName','displayName','mail','distinguishedName')
        
        foreach ($entry in $entries) {
            return @{
                SamAccountName     = $entry.Attributes['samAccountName'][0]
                DisplayName        = if ($entry.Attributes['displayName']) { $entry.Attributes['displayName'][0] } else { '' }
                Mail               = if ($entry.Attributes['mail']) { $entry.Attributes['mail'][0] } else { '' }
                DistinguishedName  = $entry.Attributes['distinguishedName'][0]
            }
        }
    } catch {
        Write-Warning "LDAP search failed: $_"
    } finally {
        if ($conn) { $conn.Dispose() }
    }
    return $null
}
