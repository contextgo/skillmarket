﻿[CmdletBinding()]
param(
    [switch]$All,
    [switch]$Inactive,
    [int]$DaysInactive = 90,
    [switch]$ExpiredPasswords,
    [switch]$TestMode
)

. (Join-Path $PSScriptRoot "..\lib\ad-helper.ps1")
. (Join-Path $PSScriptRoot "..\lib\feishu-bitables.ps1")

$configPath = Join-Path $PSScriptRoot "..\config\settings.json"
$configJson = Get-Content -Path $configPath -Raw -Encoding UTF8
$config = $configJson | ConvertFrom-Json

if (-not $config.feishu.enabled) {
    Write-Host "Feishu integration disabled."
    exit 0
}

if (-not (Initialize-FeishuBitable -ConfigPath $configPath)) {
    Write-Error "Failed to initialize Feishu"
    exit 1
}

$tableId = $config.feishu.audit_table_id
if (-not $tableId) {
    Write-Warning "audit_table_id not configured, skipping audit writing"
    # Still run audit checks for reporting
    $tableId = $null
}

$auditResults = @()

if ($All -or $Inactive) {
    Write-Host "Checking for inactive users (not logged in for $DaysInactive days)..."
    $inactive = Get-InactiveUsers -Days $DaysInactive
    foreach ($user in $inactive) {
        $auditResults += [PSCustomObject]@{
            Type = "Inactive"
            User = $user.SamAccountName
            Detail = "Last logon: $($user.LastLogon)"
            Timestamp = Get-Date
        }
    }
    Write-Host "Found $($inactive.Count) inactive users"
}

if ($All -or $ExpiredPasswords) {
    Write-Host "Checking for expired passwords..."
    $expired = Get-ExpiredPasswords
    foreach ($user in $expired) {
        $auditResults += [PSCustomObject]@{
            Type = "PasswordExpired"
            User = $user.SamAccountName
            Detail = "Expired: $($user.PasswordExpired)"
            Timestamp = Get-Date
        }
    }
    Write-Host "Found $($expired.Count) expired passwords"
}

# Write audit results to Feishu if configured
if ($tableId -and $auditResults.Count -gt 0 -and -not $TestMode) {
    Write-Host "`nWriting audit results to Feishu..."
    $written = 0
    foreach ($ audit in $auditResults) {
        $fields = @{
            "文本" = "$($audit.Type)|$($audit.User)|$($audit.Detail)|$($audit.Timestamp)"
        }
        $record = New-FeishuRecord -TableId $tableId -Fields $fields
        if ($record) { $written++ }
    }
    Write-Host "Wrote $written audit records"
} elseif ($TestMode) {
    Write-Host "`nTEST MODE - No records written"
    $auditResults | Format-Table -AutoSize
} else {
    Write-Host "`nNo audit issues found or table not configured."
}

exit 0
