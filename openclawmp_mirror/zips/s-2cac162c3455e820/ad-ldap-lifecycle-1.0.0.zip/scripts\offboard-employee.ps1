﻿[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$UserName,
    [switch]$DisableOnly,
    [switch]$Delete,
    [switch]$SendToFeishu,
    [switch]$TestMode
)

. (Join-Path $PSScriptRoot "..\lib\ad-helper.ps1")
. (Join-Path $PSScriptRoot "..\lib\feishu-bitables.ps1")

$configPath = Join-Path $PSScriptRoot "..\config\settings.json"
$configJson = Get-Content -Path $configPath -Raw -Encoding UTF8
$config = $configJson | ConvertFrom-Json

Write-Host "Offboarding employee: $UserName"

if ($TestMode) {
    Write-Host "TEST MODE - No changes will be made"
    exit 0
}

# Find user
try {
    $user = Get-ADUser -Identity $UserName -Properties MemberOf
    if (-not $user) {
        Write-Error "User not found: $UserName"
        exit 1
    }
} catch {
    Write-Error "Failed to find user: $_"
    exit 1
}

if ($DisableOnly -or $Delete) {
    # Remove from groups
    foreach ($group in $user.MemberOf) {
        try {
            Remove-ADGroupMember -Identity $group -Members $user -Confirm:$false -ErrorAction SilentlyContinue
        } catch {
            Write-Warning "Could not remove from group $group : $_"
        }
    }
    Write-Host "Removed from all groups"

    if ($Delete) {
        # Delete mailbox if exists
        try {
            Disable-Mailbox -Identity $user.UserPrincipalName -Confirm:$false -ErrorAction SilentlyContinue
        } catch {
            Write-Warning "Mailbox not found or could not be disabled"
        }
        # Delete AD account
        Remove-ADUser -Identity $user -Confirm:$false
        Write-Host "AD account deleted"
    } else {
        Disable-ADAccount -Identity $user
        Write-Host "AD account disabled"
    }
}

# Send to Feishu if requested
if ($SendToFeishu -and $config.feishu.enabled) {
    if (-not (Initialize-FeishuBitable -ConfigPath $configPath)) {
        Write-Warning "Failed to initialize Feishu"
        exit 0
    }

    $tableId = $config.feishu.user_table_id
    if ($tableId) {
        $action = if ($Delete) { "DELETED" } else { "DISABLED" }
        $fields = @{
            "文本" = "$UserName|$($user.SamAccountName)|$action|$((Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))"
        }
        $record = New-FeishuRecord -TableId $tableId -Fields $fields
        if ($record) {
            Write-Host "Offboard info synced to Feishu"
        }
    }
}

Write-Host "Employee offboarding completed."
exit 0
