# 文件触发自动化助手

让文件成为Agent的触发器。

## 为什么需要文件触发？

**Cron的局限**：
- 只能按时间触发
- 无法响应文件变化
- 空转浪费资源

**File Watcher的优势**：
- 文件即事件，即时响应
- 按需触发，无空转
- 与外部系统自然集成

## 核心概念

```
文件变化 → File Watcher检测 → 触发Agent → 执行任务
```

| 事件类型 | 触发条件 | 典型场景 |
|----------|----------|----------|
| `created` | 新文件创建 | PDF下载自动摘要 |
| `modified` | 文件内容变化 | 代码修改自动分析 |
| `deleted` | 文件被删除 | 日志轮转监控 |

## 快速开始

### 1. 安装File Watcher Trigger

```bash
openclawmp install trigger/@u-a553402ca21449db9813/file-watcher
```

### 2. 配置config.yaml

```yaml
watch:
  path: ~/Downloads
  patterns:
    - "*.pdf"
    - "*.md"
  recursive: false
  debounceMs: 1000

agent:
  agentId: main
  prompt: |
    新文件 detected!
    文件名: {{filename}}
    路径: {{filepath}}
    大小: {{size}} bytes
    
    请处理这个文件。
  timeoutSeconds: 300
```

### 3. 启用Trigger

```json
{
  "triggers": [{
    "type": "file-watcher",
    "configPath": "~/.openclaw/triggers/file-watcher/config.yaml",
    "enabled": true
  }]
}
```

### 4. 重启Gateway

```bash
openclaw gateway restart
```

## 变量占位符

| 占位符 | 说明 | 示例 |
|--------|------|------|
| `{{filename}}` | 文件名（含扩展名） | `report.pdf` |
| `{{basename}}` | 文件名（不含扩展名） | `report` |
| `{{filepath}}` | 完整路径 | `/Users/xxx/Downloads/report.pdf` |
| `{{size}}` | 文件大小（bytes） | `102400` |
| `{{eventType}}` | 事件类型 | `created/modified/deleted` |
| `{{mimeType}}` | MIME类型 | `application/pdf` |

## 常见场景

### 场景1：PDF自动摘要

```yaml
rules:
  - pattern: "*.pdf"
    event: created
    prompt: |
      请总结这个PDF文档：{{filepath}}
      提取核心观点、关键数据、行动项。
    timeoutSeconds: 600
```

### 场景2：Markdown变更预览

```yaml
rules:
  - pattern: "*.md"
    event: modified
    prompt: |
      Markdown文件 `{{basename}}` 被修改。
      请预览前10行：
      $(head -10 {{filepath}})
    shell: true
```

### 场景3：记忆文件自动索引

```yaml
watch:
  path: ~/memory/daily
  patterns:
    - "*.md"
  
agent:
  prompt: |
    新记忆文件 {{filename}} 已创建。
    请运行 memsearch index ~/memory/ 更新索引。
```

### 场景4：代码变更分析

```yaml
watch:
  path: ~/workspace/my-project
  patterns:
    - "*.js"
    - "*.py"
    - "*.ts"
  recursive: true
  
agent:
  prompt: |
    代码文件 {{filepath}} 被 {{eventType}}。
    请分析变更影响：
    1. 哪些函数/模块受影响？
    2. 需要运行测试吗？
    3. 有潜在风险吗？
```

## 高级配置

### 多规则配置

```yaml
rules:
  - pattern: "*.pdf"
    event: created
    prompt: "PDF摘要任务"
    
  - pattern: "*.jpg"
    event: created
    prompt: "图片分析任务"
    
  - pattern: "backup-*.zip"
    event: created
    prompt: "备份文件处理任务"
```

### 条件过滤

```yaml
conditions:
  minSize: 1024        # 至少1KB
  maxSize: 104857600   # 最大100MB
  custom: |
    eventType === 'created' && filename.endsWith('.pdf')
```

### 防抖配置

```yaml
watch:
  debounceMs: 5000  # 文件变化后等待5秒再触发
```

## 最佳实践

### 1. 选择合适的监控目录

✅ **推荐**：
- `~/Downloads` - 下载文件处理
- `~/memory/daily` - 记忆文件索引
- `~/workspace/project` - 代码变更监控

❌ **避免**：
- `~/.ssh` - 敏感目录
- `/tmp` - 临时文件过多
- 根目录 - 权限和性能问题

### 2. 使用精确的pattern

```yaml
# ✅ 精确匹配
patterns:
  - "report-*.pdf"
  - "daily-*.md"

# ❌ 过于宽泛
patterns:
  - "*"  # 会触发所有文件
```

### 3. 配置合理超时

```yaml
# PDF处理需要更多时间
rules:
  - pattern: "*.pdf"
    timeoutSeconds: 600  # 10分钟

# Markdown预览很快
rules:
  - pattern: "*.md"
    timeoutSeconds: 60   # 1分钟
```

### 4. 启动时忽略已有文件

```yaml
startup:
  ignoreExisting: true  # 避免启动时批量触发
```

## 与Cron/Heartbeat协作

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Cron      │     │ File Watcher│     │  Heartbeat  │
│  (定时任务)  │     │ (文件事件)   │     │  (健康检查)  │
└──────┬──────┘     └──────┬──────┘     └──────┬──────┘
       │                   │                   │
       └───────────────────┴───────────────────┘
                           │
                    ┌──────┴──────┐
                    │    Agent    │
                    └─────────────┘
```

| 触发器 | 适用场景 | 精度 |
|--------|----------|------|
| Cron | 定时备份、日报生成 | 分钟级 |
| File Watcher | 文件处理、即时响应 | 毫秒级 |
| Heartbeat | 健康检查、状态监控 | 分钟级 |

## 故障排查

| 问题 | 检查点 |
|------|--------|
| 文件变化没反应 | 1. trigger.js是否运行<br>2. patterns是否匹配<br>3. enabled: true |
| 频繁触发 | 增加debounceMs到5000+ |
| Agent没执行 | 查看Gateway日志：`tail -f ~/.openclaw/logs/` |
| 权限错误 | 确保进程有监控目录的读权限 |

## 示例：完整的PDF处理工作流

```yaml
# config.yaml
watch:
  path: ~/Downloads
  patterns:
    - "*.pdf"
  debounceMs: 2000
  startup:
    ignoreExisting: true

rules:
  - pattern: "*.pdf"
    event: created
    conditions:
      minSize: 1024
    prompt: |
      📄 新PDF文件: {{filename}}
      
      请执行以下任务：
      1. 提取PDF的核心内容摘要
      2. 识别关键数据和结论
      3. 如果有行动项，列出todo
      4. 将摘要保存到 ~/summaries/{{basename}}.md
      
      文件路径: {{filepath}}
      文件大小: {{size}} bytes
    timeoutSeconds: 300

agent:
  agentId: main
```

## 参考

- File Watcher Trigger: `openclawmp info trigger/@u-a553402ca21449db9813/file-watcher`
- 自动看门狗: `openclawmp info trigger/@u-21b3bb2371b30d8d/auto-watchdog`
- 三层记忆系统: `openclawmp info skill/@u-4968f82bb623454f9101/three-tier-memory`

---

_让文件成为你的自动化触发器 🐱_