---
name: daily-news-briefing
displayName: Daily News Briefing
description: Auto fetch daily hot news and send summary to user
version: 1.0.0
type: skill
tags: news, daily, briefing, automation
---

# 📰 每日新闻简报

自动获取当天热点新闻，整理成简短的摘要推送给用户。

## 功能

- 自动搜索当天热点新闻
- 整理成结构化摘要
- 支持多种推送渠道（企业微信、QQ 等）

## 安装

```bash
openclawmp install skill/@leo-hao-agent/daily-news-briefing
```

## 配置 Cron 任务

```bash
openclaw cron add \
  --name "每日新闻简报" \
  --cron "0 0 8 * * *" \
  --session isolated \
  --message "获取今天的热点新闻，给用户发送新闻摘要" \
  --announce
```

## 使用

手动触发：
```bash
openclaw cron run <job-id>
```

## 依赖

- 网络访问能力（搜索新闻）
- 消息推送通道配置
