# 🦞 外置 AI 代理浏览器 Skill - 一键连接 Kimi/ChatGPT/智谱/通义千问/天工/MiroMind，让 AI 自动搜索分析并生成精美 HTML 报告

**版本**: 5.0  
**创建**: 2026-03-22  
**更新**: 2026-03-22 23:30（Chrome 模式 - 复用浏览器登录态）  
**实测**: MiroMind (https://dr.miromind.ai/)  
**核心**: 用 `agent-browser` CLI 直接控制浏览器访问外部 AI 服务

---

## 🎯 核心思路

**不开发复杂 Skill**，直接用现有 `agent-browser` 工具链：

```
OpenClaw → agent-browser CLI → 浏览器 → 外部 AI 网站 → 返回结果
```

**优势**:
- ✅ 无需开发新 Skill，用现有 `agent-browser`
- ✅ 支持所有 AI 网站（Kimi、智谱、ChatGPT、Gemini 等）
- ✅ **Chrome 模式复用登录态** — 无需重新登录，直接使用已登录的 Cookie
- ✅ 用户可实时看到浏览器操作（远程桌面/VNC）

---

## 🛠️ 完整流程（8 步）

### 步骤 1: 打开浏览器（Chrome 模式 - 复用登录态）⭐推荐

**🎯 Chrome 模式 = 暴露登录态**

Agent 能访问你当前 Chrome 浏览器的所有 Cookie 和登录态，**无需重新登录**！

```bash
# 方式 A: 使用默认 Chrome Profile（推荐）
export AGENT_BROWSER_EXECUTABLE_PATH="/usr/bin/google-chrome"
agent-browser --headed open https://dr.miromind.ai/ \
  --user-data-dir=/home/admin/.config/google-chrome/

# 方式 B: 使用指定 Profile（如"Profile 1"）
agent-browser --headed open https://dr.miromind.ai/ \
  --user-data-dir=/home/admin/.config/google-chrome/Profile\ 1/

# 方式 C: 使用当前激活的 Chrome 窗口（需要关闭所有 Chrome 窗口）
# 1. 关闭所有 Chrome 窗口
# 2. 启动带调试端口的 Chrome
google-chrome --remote-debugging-port=9222 &
# 3. agent-browser 连接
agent-browser --headed open https://dr.miromind.ai/ \
  --remote-debugging-url=http://localhost:9222
```

**关键点**:
- ✅ **复用登录态** — 直接使用你在 Chrome 中已登录的 Kimi/ChatGPT/智谱等账号
- ✅ **Cookie 共享** — 无需重新扫码或输入密码
- ✅ **真实用户环境** — 和用户手动操作完全一致
- ⚠️ **隐私注意** — Agent 能访问该 Profile 的所有标签页内容
- ⚠️ **不要反复重新打开浏览器** — 会导致 Cookie 丢失，会话重置

---

### 备选方案：临时 Profile（手工登录）

如果不想暴露主浏览器的登录态，可以使用临时 Profile：

```bash
# 临时 Profile - 每次都是全新的浏览器会话
export AGENT_BROWSER_EXECUTABLE_PATH="/usr/bin/google-chrome"
agent-browser --headed open https://dr.miromind.ai/

# 用户需要手工扫码/密码登录
# Cookie 保存到临时目录，关闭后清除
```

**适用场景**:
- 隐私优先，不想暴露主浏览器登录态
- 测试用途，不需要长期保存登录状态

---

### 步骤 2: 获取页面元素

```bash
agent-browser snapshot -i
```

**输出示例**:
```
- button "Sign In" [ref=e9]
- textbox [ref=e10]
- button [ref=e11]  # 发送按钮（纸飞机图标✈️）
```

---

### 步骤 3: 处理登录

**情况 A: 已登录** → 跳过此步骤

**情况 B: 未登录** → 推荐用户手工登录

```bash
# 方式 1: 自动点击登录按钮
agent-browser click @e9  # "Sign In"按钮

# 方式 2: 等待用户手动登录（推荐）
# 用户扫码/输入密码完成后，继续下一步
```

**登录选项**（以 MiroMind 为例）:
- Continue with Email
- Continue with Github
- Continue with Google
- Continue with Apple

---

### 步骤 4: 输入问题

```bash
agent-browser fill @e10 "2026 年世界杯简报"
```

**关键点**:
- ✅ **中文可以直接输入** — 不需要特殊处理
- ✅ **灰色文字是占位符** — 直接 `fill` 会覆盖
- ⚠️ **输入后等待 3-5 秒** — 让页面完全接收输入
- ⚠️ **如果 fill 失败**，先检查是否有弹窗阻挡

---

### 步骤 5: 发送问题

**✅ 强烈推荐：按回车键**（避免点错按钮）

```bash
# 按回车键发送（最可靠！）
agent-browser press Enter
sleep 3  # 等待发送完成
```

**❌ 不推荐：点击发送按钮**
```bash
# 容易点错成附件按钮（📎），已多次犯错
agent-browser click @e12  # 风险高！
```

**教训**: 第三轮测试时连续两次点错按钮（点成回形针附件📎而不是发送✈️）

---

### 步骤 6: 等待 AI 回答

**短期等待**（<30 秒）:
```bash
agent-browser wait 10000  # 等待 10 秒
```

**长期等待**（AI 深度分析，可能 3-5 分钟+）:
```bash
# 方式 A: 等待网络空闲
agent-browser wait --load networkidle

# 方式 B: 等待特定元素出现
agent-browser wait @e28  # 等待"Copy message"按钮出现

# 方式 C: 定期检查进度（推荐）
agent-browser snapshot -i | grep -E "(Cancel|Don't show)"
# 如果看到 "Cancel" 按钮，说明 AI 还在运行
```

**⚠️ 关键点**:
- ⏰ **AI 分析可能需要 5 分钟以上** — 不要过早判断失败
- 🙋 **等待期间询问用户** — "正在等待 AI 分析，预计 X 分钟，是否继续等待？"
- 📸 **定期截图汇报** — 每 30-60 秒截图展示进度
- 🛑 **看到 Cancel 按钮后立即停止** — 截图告知用户"AI 正在运行，等待完成"

---

### 步骤 7: 获取答案

```bash
# 方式 A: 截图留存
agent-browser screenshot /tmp/answer.png

# 方式 B: 提取文字
agent-browser get text body > answer.txt

# 方式 C: 完整页面截图
agent-browser screenshot --full answer-full.png
```

---

### 步骤 8: 发送结果给用户

```bash
message action=send channel=openim media=/tmp/answer.png message="AI 回答已完成！"
```

---

## 📋 完整脚本示例

```bash
#!/bin/bash
# 外置 AI 代理浏览器 - 完整流程脚本

set -e

# 配置
export AGENT_BROWSER_EXECUTABLE_PATH="/usr/bin/google-chrome"
URL="https://dr.miromind.ai/"
QUESTION="2026 年世界杯简报"

echo "🦞 正在打开浏览器..."
agent-browser --headed open $URL

echo "📸 获取页面元素..."
agent-browser snapshot -i

echo "⏳ 等待用户确认登录状态..."
# 可通过 VNC 查看，或手动检查

echo "✍️  输入问题..."
agent-browser fill @e10 "$QUESTION"
sleep 3  # 等待输入完成

echo "📤 发送问题..."
agent-browser click @e12

echo "⏰ 等待 AI 分析（最多 5 分钟）..."
for i in {1..10}; do
    sleep 30
    echo "检查进度 ($i/10)..."
    # 截图汇报进度
    agent-browser screenshot /tmp/progress-$i.png
    # 检查是否完成
    agent-browser snapshot -i | grep -q "Cancel" && continue
    echo "✅ AI 已完成！"
    break
done

echo "📸 截图留存..."
agent-browser screenshot /tmp/miromind-answer.png

echo "📤 发送结果..."
message action=send channel=openim media=/tmp/miromind-answer.png message="AI 回答已完成！"

echo "✅ 完成！"
```

---

## 🎯 支持的 AI 网站

| 网站 | 网址 | 登录方式 |
|------|------|---------|
| MiroMind | https://dr.miromind.ai/ | 邮箱/GitHub/Google/Apple |
| Kimi | https://kimi.moonshot.cn/ | 手机/微信 |
| 智谱清言 | https://chatglm.cn/ | 手机/微信 |
| ChatGPT | https://chat.openai.com/ | 邮箱/Google |
| Gemini | https://gemini.google.com/ | Google 账号 |
| 通义千问 | https://tongyi.aliyun.com/ | 支付宝/淘宝 |

---

## 🔐 登录管理

### Chrome 模式（默认）- 复用登录态 ✅

**原则**: 直接使用 Chrome 中已登录的 Cookie，无需重新登录

```bash
# 使用主浏览器 Profile
agent-browser --headed open https://kimi.moonshot.cn/ \
  --user-data-dir=/home/admin/.config/google-chrome/

# 自动继承所有登录态 - Kimi/ChatGPT/智谱等都已登录
agent-browser snapshot -i  # 已登录，直接可用
```

**优势**:
- ✅ **无需重新登录** — 直接使用已登录的 Cookie
- ✅ **所有网站通用** — Kimi/ChatGPT/智谱/通义千问都可以
- ✅ **真实用户环境** — 和用户手动操作完全一致

**注意**:
- ⚠️ **隐私边界** — Agent 能访问该 Profile 的所有标签页内容
- ⚠️ **明确授权** — 用户需要知道 Agent 能访问什么

---

### 临时 Profile（备选）- 手工登录

**原则**: 使用临时浏览器会话，用户手工登录

```bash
# 临时 Profile - 每次都是全新的浏览器会话
agent-browser --headed open https://kimi.moonshot.cn/

# 用户需要手工扫码/密码登录
# Cookie 保存到临时目录，关闭后清除
```

**适用场景**:
- 隐私优先，不想暴露主浏览器登录态
- 测试用途，不需要长期保存登录状态

---

## ⚠️ 常见问题与解决（含实测教训）

### 问题 1: 点错按钮（点到上传附件📎而不是发送✈️）

**教训**: 第一次测试时点错了按钮

**解决**: 
```bash
# 重新获取元素，确认正确的发送按钮 ref
agent-browser snapshot -i
# 找到正确的发送按钮 ref（通常是纸飞机图标）
agent-browser click @e12
```

---

### 问题 2: 以为中文无法输入

**教训**: 第一次测试时尝试用 `press` 逐个输入中文，失败

**解决**: 
```bash
# 直接 fill 输入中文 — 完全支持！
agent-browser fill @e11 "2026 年世界杯简报"
sleep 3  # 等待输入完成
```

---

### 问题 3: 没有等待足够时间

**教训**: `fill` 后立即 `snapshot`，元素还未更新

**解决**: 
```bash
# 每个操作后等待 3-5 秒
agent-browser fill @e11 "问题"
sleep 3
agent-browser snapshot -i  # 现在元素已更新
```

---

### 问题 4: 反复重新打开浏览器

**教训**: 每次 `agent-browser open` 都会创建新会话，Cookie 丢失

**解决**: 
```bash
# ❌ 错误：每次都重新打开
agent-browser open https://dr.miromind.ai/  # Cookie 丢失！

# ✅ 正确：继续使用当前会话
# 页面刷新或弹窗关闭后，直接继续操作
agent-browser click @e1  # 关闭弹窗
agent-browser fill @e11 "问题"  # 继续操作
```

---

### 问题 5: 元素 ref 变化/超时

**教训**: 页面变化后 ref 失效，或元素被弹窗阻挡

**解决**: 
```bash
# 每次页面变化后，重新获取元素
agent-browser snapshot -i

# 检查是否有弹窗阻挡
agent-browser snapshot -i | grep -E "(Close|弹窗)"
# 如果有，先关闭
agent-browser click @e19  # 关闭弹窗

# 然后再操作目标元素
agent-browser fill @e11 "问题"
```

---

### 问题 6: AI 运行时间过长（5 分钟+）

**教训**: 第一次测试时 AI 耗时 5 分钟，期间没有询问用户

**解决**: 
```bash
# 长时间等待前询问用户
message action=send channel=openim message="AI 正在分析，预计需要 3-5 分钟。请问您希望：A) 继续等待 B) 稍后通知 C) 跳过"

# 定期检查进度并汇报
for i in {1..5}; do
    sleep 60
    agent-browser screenshot /tmp/progress-$i.png
    message action=send channel=openim media=/tmp/progress-$i.png message="进度：$i/5 分钟"
done
```

---

### 问题 7: 用户看不到浏览器窗口

**解决**:
- 方案 A: 每次操作后截图发给用户（推荐）
- 方案 B: 启动 VNC 服务器，用户实时查看

```bash
# 启动 VNC
x11vnc -display :1 -forever -shared -nopw
# 用户用 VNC 客户端连接：服务器 IP:5900
```

---

### 问题 8: 总是点错发送按钮（点成附件📎）

**教训**: 第三轮测试时连续 3 次点错按钮

**解决**: 
```bash
# ❌ 错误：点击发送按钮（容易点错）
agent-browser click @e12  # 可能点成附件按钮！

# ✅ 正确：直接按回车键（100% 可靠！）
agent-browser press Enter
sleep 3  # 等待发送完成
```

**监控 Cancel 按钮**:
```bash
# 定期检查是否看到 Cancel 按钮
agent-browser snapshot -i | grep -i "cancel"

# 如果看到，立即停止并告知用户
if agent-browser snapshot -i | grep -qi "cancel"; then
    agent-browser screenshot /tmp/ai-running.png
    message action=send channel=openim media=/tmp/ai-running.png message="🎉 AI 正在分析中（看到 Cancel 按钮），请稍候..."
fi
```

---

## 📊 实测记录

### 测试 1: 2026 年最火的大模型技术（2026-03-22 22:20）

**问题**: "2026 年最火的大模型技术"  
**AI 耗时**: 约 5 分钟  
**结果**: ✅ 成功获取 40+ 篇权威来源分析的完整报告  
**报告**: `/home/admin/openclaw/download/report/AIclaw/2026 大模型技术趋势报告.html`

**教训**:
- ✅ 用户手工登录最可靠
- ✅ AI 分析需要耐心等待
- ✅ 等待期间应询问用户意见

---

### 测试 2: 2026 年世界杯简报（2026-03-22 22:48）

**问题**: "2026 年世界杯简报"  
**AI 耗时**: 约 5 分钟  
**结果**: ✅ 成功获取完整赛事简报  
**报告**: `/home/admin/openclaw/download/report/AIclaw/2026 世界杯简报.html`

**教训**:
- ❌ 不要重新打开浏览器（导致 Cookie 丢失）
- ✅ 中文可以直接输入（不需要特殊处理）
- ✅ 输入后等待 3-5 秒再判断
- ✅ 长时间等待应询问用户是否继续

---

### 测试 3: 如何入门量子力学？（2026-03-22 23:00）

**问题**: "如何入门量子力学？"  
**AI 耗时**: 约 3 分钟  
**结果**: ✅ 成功获取详细入门路线图（三阶段学习法）  
**报告**: `/home/admin/openclaw/download/report/AIclaw/量子力学入门指南.html`

**教训**:
- ❌ **不要点击发送按钮** — 连续两次点错成附件按钮（📎）
- ✅ **直接用回车键发送** — `agent-browser press Enter`（最可靠！）
- ✅ **监控 Cancel 按钮** — 看到后立即截图告知用户"AI 正在运行，等待完成"
- ✅ **不要继续操作** — 等待用户确认 AI 完成后再获取答案

---

### 测试 4: 春天易于种植的水培植物（2026-03-22 23:05）

**问题**: "春天易于种植的水培植物"  
**AI 耗时**: 约 2 分钟  
**结果**: ✅ 成功获取 10 种水培植物推荐 + 养护指南  
**报告**: `/home/admin/openclaw/download/report/AIclaw/春天水培植物指南.html`

**验证**:
- ✅ **回车键发送 100% 可靠** — 一次成功，无点错按钮
- ✅ **继续使用原浏览器** — Cookie 保持，无需重新登录
- ✅ **快速完成** — 2 分钟获取完整答案
- ✅ **HTML 报告生成** — 包含植物卡片、养护原则、选择指南

---

## 💡 最佳实践清单

### ✅ 必做

- [ ] **使用 Chrome 模式** — 复用登录态，无需重新登录（默认方案）
- [ ] 打开浏览器后不要重复打开（保持会话）
- [ ] 每个操作后等待 3-5 秒
- [ ] 输入中文直接用 `fill`
- [ ] **用回车键发送问题** — `press Enter`（最可靠！）
- [ ] AI 分析期间定期截图汇报
- [ ] **看到 Cancel 按钮后立即停止** — 截图告知用户等待

### ❌ 禁止

- [ ] 反复重新打开浏览器（导致 Cookie 丢失）
- [ ] 过早判断 AI 失败（可能需 5 分钟）
- [ ] 不询问用户就一直等待
- [ ] 输入后立即操作（未等待完成）
- [ ] 不检查弹窗就直接操作
- [ ] **点击发送按钮** — 容易点错成附件按钮（已犯错 3 次！）
- [ ] **暴露敏感信息** — Chrome 模式下注意隐私边界

---

## 📁 文件位置规范

| 类型 | 位置 | 示例 |
|------|------|------|
| **Skill 文档** | `workspace/skills/` | `外置 AI 代理浏览器.md` |
| **HTML 报告** | `download/report/AIclaw/` | `2026 世界杯简报.html` |
| **截图** | `download/screenshot/` | `miromind-20260322.png` |

**绝对禁止**:
- ❌ 在 `workspace` 下创建 `download` 文件夹
- ❌ 报告保存到错误位置

---

## 📚 参考

- [agent-browser 完整文档](~/.openclaw/skills/agent-browser/SKILL.md)
- [OpenClaw 文档](https://docs.openclaw.ai)

---

*版本 2.0 - 基于两轮实测经验（大模型技术 + 世界杯），包含完整教训和最佳实践*