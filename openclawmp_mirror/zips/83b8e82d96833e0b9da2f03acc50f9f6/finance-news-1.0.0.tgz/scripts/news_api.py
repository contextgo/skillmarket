#!/usr/bin/env python3
"""
财经新闻查询工具 - 真实数据版本
支持多数据源聚合、分类查询、关键词搜索
数据源：东方财富7x24快讯、东方财富公告、新浪财经
"""

import sys
import requests
import json
import time
import hashlib
import os
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from urllib.parse import urlparse


# ============================================================================
# 常量定义
# ============================================================================

# 免责声明
DISCLAIMER = "⚠️ 新闻内容仅供参考，不构成投资建议"

# 缓存配置
CACHE_DIR = '/tmp/finance_news_cache'
CACHE_EXPIRE_MINUTES = 20  # 缓存过期时间（分钟）

# 重试配置
MAX_RETRIES = 3
RETRY_DELAY = 1  # 重试间隔（秒）

# 请求超时
REQUEST_TIMEOUT = 15

# 新闻分类关键词
CATEGORY_KEYWORDS = {
    'market': ['股市', 'A股', '港股', '美股', '涨停', '跌停', '指数', '大盘', '股票', '证券', '基金', '期货', '沪指', '创业板', '科创'],
    'company': ['公司', '财报', '业绩', '并购', '上市', '退市', '公告', '企业', '集团', '董事会', '股东', '减持', '增持'],
    'macro': ['央行', 'GDP', 'CPI', '政策', '利率', '降准', '财政', '经济', '货币', '通胀', '通缩', '就业', '国务院'],
    'international': ['美联储', '美元', '欧元', '国际贸易', '全球', '海外', '国际', '外盘', '汇率', '关税', '美国', '欧洲', '日本']
}

# 情感分析关键词
POSITIVE_KEYWORDS = [
    '上涨', '涨停', '盈利', '增长', '突破', '利好', '创新高', '大涨', '翻倍',
    '业绩大增', '超预期', '回购', '增持', '并购', '中标', '签约', '合作',
    '获批', '投产', '扩张', '分红', '派息', '反弹', '复苏', '改善'
]

NEGATIVE_KEYWORDS = [
    '下跌', '跌停', '亏损', '下降', '暴跌', '利空', '创新低', '大跌', '腰斩',
    '业绩下滑', '不及预期', '减持', '清仓', '套现', '违约', '债务', '破产',
    '退市', '处罚', '调查', '诉讼', '裁员', '关闭', '停产', '暴雷'
]


# ============================================================================
# 缓存管理类
# ============================================================================

class NewsCache:
    """新闻缓存管理"""

    def __init__(self, cache_dir: str = CACHE_DIR, expire_minutes: int = CACHE_EXPIRE_MINUTES):
        self.cache_dir = cache_dir
        self.expire_minutes = expire_minutes
        os.makedirs(cache_dir, exist_ok=True)

    def _get_cache_key(self, key: str) -> str:
        """生成缓存文件名"""
        hash_key = hashlib.md5(key.encode()).hexdigest()
        return os.path.join(self.cache_dir, f"{hash_key}.json")

    def get(self, key: str) -> Optional[List[Dict]]:
        """获取缓存数据"""
        cache_file = self._get_cache_key(key)

        if not os.path.exists(cache_file):
            return None

        try:
            modify_time = datetime.fromtimestamp(os.path.getmtime(cache_file))
            if datetime.now() - modify_time > timedelta(minutes=self.expire_minutes):
                return None

            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return None

    def set(self, key: str, data: List[Dict]):
        """设置缓存"""
        cache_file = self._get_cache_key(key)
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass


# ============================================================================
# 情感分析
# ============================================================================

def analyze_sentiment(title: str, summary: str = '') -> Tuple[str, float, List[str]]:
    """分析新闻情感"""
    text = f"{title} {summary}".lower()

    positive_matches = [kw for kw in POSITIVE_KEYWORDS if kw in text]
    negative_matches = [kw for kw in NEGATIVE_KEYWORDS if kw in text]

    positive_score = len(positive_matches)
    negative_score = len(negative_matches)

    if positive_score > negative_score:
        sentiment = '利好'
        confidence = min(positive_score / max(positive_score + negative_score, 1), 1.0)
        matched_keywords = positive_matches[:3]
    elif negative_score > positive_score:
        sentiment = '利空'
        confidence = min(negative_score / max(positive_score + negative_score, 1), 1.0)
        matched_keywords = negative_matches[:3]
    else:
        sentiment = '中性'
        confidence = 0.5
        matched_keywords = positive_matches[:2] + negative_matches[:2]

    return sentiment, round(confidence, 2), matched_keywords


# ============================================================================
# 新闻分类
# ============================================================================

def classify_news(title: str, summary: str = '') -> str:
    """对新闻进行分类"""
    text = f"{title} {summary}".lower()

    scores = {}
    for category, keywords in CATEGORY_KEYWORDS.items():
        score = sum(1 for keyword in keywords if keyword in text)
        scores[category] = score

    max_score = max(scores.values())
    if max_score == 0:
        return 'market'

    return max(scores, key=scores.get)


# ============================================================================
# 摘要生成
# ============================================================================

def generate_summary(content: str, max_length: int = 80) -> str:
    """生成智能摘要"""
    if not content:
        return ''

    # 清理文本
    content = re.sub(r'<[^>]+>', '', content)
    content = re.sub(r'\s+', ' ', content).strip()

    if len(content) <= max_length:
        return content

    return content[:max_length] + '...'


# ============================================================================
# 数据源获取器
# ============================================================================

class NewsSourceFetcher:
    """多数据源新闻获取器"""

    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Referer': 'https://www.eastmoney.com/',
    }

    def __init__(self, cache: NewsCache):
        self.cache = cache

    def _fetch_with_retry(self, url: str, headers: dict = None, timeout: int = REQUEST_TIMEOUT) -> Optional[requests.Response]:
        """带重试机制的请求"""
        request_headers = {**self.HEADERS, **(headers or {})}
        
        for attempt in range(MAX_RETRIES):
            try:
                response = requests.get(url, headers=request_headers, timeout=timeout)
                if response.status_code == 200:
                    return response
                elif response.status_code == 429:
                    wait_time = int(response.headers.get('Retry-After', RETRY_DELAY * 2))
                    time.sleep(wait_time)
                else:
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(RETRY_DELAY)
            except requests.exceptions.RequestException as e:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                else:
                    print(f"请求失败（已重试{MAX_RETRIES}次）: {e}", file=sys.stderr)
        
        return None

    def fetch_eastmoney_fastnews(self) -> List[Dict]:
        """获取东方财富7x24快讯"""
        # 这个 API 已验证可用
        url = "https://np-listapi.eastmoney.com/comm/web/getFastNewsList"
        params = {
            'client': 'web',
            'biz': 'web_724',
            'fastColumn': '102',
            'sortEnd': '0',
            'pageSize': '30',
            'req_trace': str(int(time.time() * 1000))
        }
        
        try:
            full_url = f"{url}?{'&'.join(f'{k}={v}' for k, v in params.items())}"
            response = self._fetch_with_retry(full_url)
            
            if not response:
                return []
            
            response.encoding = 'utf-8'
            data = json.loads(response.text)
            news_list = []

            fast_news = data.get('data', {}).get('fastNewsList', [])
            for item in fast_news:
                title = item.get('title', '')
                if not title:
                    continue

                summary = item.get('summary', '')
                show_time = item.get('showTime', '')
                
                # 解析时间
                try:
                    dt = datetime.strptime(show_time, '%Y-%m-%d %H:%M:%S')
                    time_str = show_time
                    timestamp = int(dt.timestamp())
                except:
                    time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    timestamp = int(datetime.now().timestamp())

                # 情感分析
                sentiment, confidence, matched_keywords = analyze_sentiment(title, summary)

                news = {
                    'title': title,
                    'source': '东方财富',
                    'source_icon': '💰',
                    'time': time_str,
                    'timestamp': timestamp,
                    'category': classify_news(title, summary),
                    'summary': generate_summary(summary, 80),
                    'original_summary': summary,
                    'url': f"https://finance.eastmoney.com/a/{item.get('code', '')}.html",
                    'keywords': matched_keywords,
                    'sentiment': sentiment,
                    'sentiment_confidence': confidence
                }
                news_list.append(news)

            return news_list
        except Exception as e:
            print(f"获取东方财富快讯失败: {e}", file=sys.stderr)
            return []

    def fetch_eastmoney_announcements(self) -> List[Dict]:
        """获取东方财富公告"""
        url = "https://np-anotice-stock.eastmoney.com/api/security/ann"
        params = {
            'cb': 'jQuery',
            'sr': '-1',
            'page_size': '20',
            'page_index': '1',
            'ann_type': 'SHA,SZA,BJA',
            'client_source': 'web',
            'f_node': '0',
            's_node': '0'
        }
        
        try:
            full_url = f"{url}?{'&'.join(f'{k}={v}' for k, v in params.items())}"
            response = self._fetch_with_retry(full_url)
            
            if not response:
                return []
            
            response.encoding = 'utf-8'
            text = response.text
            
            # 解析 JSONP 响应
            if text.startswith('jQuery('):
                text = text[7:-1]  # 移除 jQuery() 包装
            
            data = json.loads(text)
            news_list = []

            for item in data.get('data', {}).get('list', []):
                title = item.get('title_ch', '') or item.get('title', '')
                if not title:
                    continue

                # 获取相关股票
                codes = item.get('codes', [])
                stock_name = codes[0].get('short_name', '') if codes else ''
                stock_code = codes[0].get('stock_code', '') if codes else ''

                display_time = item.get('display_time', '')
                try:
                    # 格式: 2026-03-18 22:55:49:513 (带毫秒)
                    # 或: 2026-03-18 22:55:49
                    dt_str = display_time.split(':')[0] + ':' + display_time.split(':')[1] + ':' + display_time.split(':')[2][:2] if ':' in display_time else display_time
                    # 更简单的方式：取前19个字符
                    dt_str = display_time[:19] if len(display_time) >= 19 else display_time
                    dt = datetime.strptime(dt_str, '%Y-%m-%d %H:%M:%S')
                    time_str = dt.strftime('%Y-%m-%d %H:%M:%S')
                    timestamp = int(dt.timestamp())
                except Exception as e:
                    time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    timestamp = int(datetime.now().timestamp())

                # 构建摘要
                summary = f"{stock_name}({stock_code})发布公告" if stock_name else "上市公司公告"

                # 情感分析
                sentiment, confidence, matched_keywords = analyze_sentiment(title, '')

                news = {
                    'title': title,
                    'source': '交易所公告',
                    'source_icon': '📋',
                    'time': time_str,
                    'timestamp': timestamp,
                    'category': 'company',  # 公告默认为公司新闻
                    'summary': generate_summary(summary, 80),
                    'original_summary': summary,
                    'url': f"https://data.eastmoney.com/notices/detail/{item.get('art_code', '')}.html",
                    'keywords': [stock_name] if stock_name else matched_keywords,
                    'sentiment': sentiment,
                    'sentiment_confidence': confidence
                }
                news_list.append(news)

            return news_list
        except Exception as e:
            print(f"获取东方财富公告失败: {e}", file=sys.stderr)
            return []

    def fetch_sina_finance_news(self) -> List[Dict]:
        """获取新浪财经新闻"""
        # 尝试多个新浪 API 端点
        urls = [
            # 新浪财经滚动新闻
            "https://feed.sina.com.cn/api/roll/get?pageid=153&lid=2516&k=&num=20&page=1",
            # 新浪财经要闻
            "https://news.sina.com.cn/roll/index.d.html?cid=56761"
        ]
        
        for url in urls:
            try:
                headers = {**self.HEADERS, 'Referer': 'https://finance.sina.com.cn/'}
                response = self._fetch_with_retry(url, headers)
                
                if not response:
                    continue
                
                response.encoding = 'utf-8'
                
                # 尝试解析 JSON
                try:
                    data = json.loads(response.text)
                    news_list = []
                    
                    # 新浪 API 格式
                    for item in data.get('result', {}).get('data', []):
                        title = item.get('title', '')
                        if not title:
                            continue

                        timestamp = item.get('ctime', 0)
                        try:
                            dt = datetime.fromtimestamp(int(timestamp))
                            time_str = dt.strftime('%Y-%m-%d %H:%M:%S')
                        except:
                            time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                            timestamp = int(datetime.now().timestamp())

                        summary = item.get('intro', '') or item.get('summary', '')
                        sentiment, confidence, matched_keywords = analyze_sentiment(title, summary)

                        news = {
                            'title': title,
                            'source': '新浪财经',
                            'source_icon': '📰',
                            'time': time_str,
                            'timestamp': timestamp,
                            'category': classify_news(title, summary),
                            'summary': generate_summary(summary, 80),
                            'original_summary': summary,
                            'url': item.get('url', ''),
                            'keywords': matched_keywords,
                            'sentiment': sentiment,
                            'sentiment_confidence': confidence
                        }
                        news_list.append(news)
                    
                    if news_list:
                        return news_list
                except json.JSONDecodeError:
                    continue
                    
            except Exception as e:
                print(f"获取新浪财经新闻失败: {e}", file=sys.stderr)
                continue
        
        return []


# ============================================================================
# 主API类
# ============================================================================

class FinanceNewsAPI:
    """财经新闻API"""

    def __init__(self):
        self.cache = NewsCache()
        self.fetcher = NewsSourceFetcher(self.cache)

    def fetch_all_news(self, use_cache: bool = True) -> List[Dict]:
        """获取所有新闻源"""
        cache_key = "all_news_v2"

        # 尝试从缓存获取
        if use_cache:
            cached = self.cache.get(cache_key)
            if cached:
                return cached

        all_news = []

        # 获取各数据源（按优先级）
        # 1. 东方财富7x24快讯（最可靠的实时数据源）
        print("正在获取东方财富快讯...", file=sys.stderr)
        eastmoney_news = self.fetcher.fetch_eastmoney_fastnews()
        if eastmoney_news:
            all_news.extend(eastmoney_news)
            print(f"  获取到 {len(eastmoney_news)} 条快讯", file=sys.stderr)
        time.sleep(0.2)

        # 2. 东方财富公告
        print("正在获取交易所公告...", file=sys.stderr)
        announcements = self.fetcher.fetch_eastmoney_announcements()
        if announcements:
            all_news.extend(announcements)
            print(f"  获取到 {len(announcements)} 条公告", file=sys.stderr)
        time.sleep(0.2)

        # 3. 新浪财经（备用）
        print("正在获取新浪财经新闻...", file=sys.stderr)
        sina_news = self.fetcher.fetch_sina_finance_news()
        if sina_news:
            all_news.extend(sina_news)
            print(f"  获取到 {len(sina_news)} 条新闻", file=sys.stderr)

        # 如果没有获取到任何新闻
        if not all_news:
            print("警告：未能获取到任何新闻数据", file=sys.stderr)
            return []

        # 去重（按标题）
        seen_titles = set()
        unique_news = []
        for news in all_news:
            title_normalized = news['title'].strip().lower()[:50]  # 取前50字符比较
            if title_normalized not in seen_titles:
                seen_titles.add(title_normalized)
                # 确保 timestamp 是整数
                if isinstance(news.get('timestamp'), str):
                    try:
                        news['timestamp'] = int(news['timestamp'])
                    except:
                        news['timestamp'] = 0
                unique_news.append(news)

        # 按时间排序
        unique_news.sort(key=lambda x: int(x.get('timestamp', 0)), reverse=True)

        # 缓存结果
        if use_cache and unique_news:
            self.cache.set(cache_key, unique_news)

        print(f"共获取 {len(unique_news)} 条新闻（去重后）", file=sys.stderr)
        return unique_news

    def filter_by_category(self, news_list: List[Dict], category: str) -> List[Dict]:
        """按分类过滤新闻"""
        if category == 'all':
            return news_list
        return [news for news in news_list if news.get('category') == category]

    def search_by_keyword(self, news_list: List[Dict], keyword: str) -> List[Dict]:
        """按关键词搜索"""
        keyword_lower = keyword.lower()

        results = []
        for news in news_list:
            title = news.get('title', '').lower()
            summary = news.get('original_summary', '') or news.get('summary', '')
            summary = summary.lower()

            if keyword_lower in title or keyword_lower in summary:
                # 计算相关性得分
                score = 0
                if keyword_lower in title:
                    score += 10
                    pos = title.find(keyword_lower)
                    score += max(0, 10 - pos // 5)
                if keyword_lower in summary:
                    score += 5

                news_copy = news.copy()
                news_copy['_relevance'] = score
                news_copy['highlight_keywords'] = [keyword]
                results.append(news_copy)

        # 按相关性排序
        results.sort(key=lambda x: x.get('_relevance', 0), reverse=True)
        return results


# ============================================================================
# 输出格式化
# ============================================================================

def display_news_list(news_list: List[Dict], limit: int = 10):
    """显示新闻列表"""
    if not news_list:
        print("暂无新闻数据")
        return

    print(f"\n📰 共找到 {len(news_list)} 条新闻，显示前 {min(limit, len(news_list))} 条")
    print("=" * 90)
    print(f"{'序号':<4} {'标题':<50} {'来源':<12} {'时间':<20}")
    print("-" * 90)

    for i, news in enumerate(news_list[:limit], 1):
        title = news['title'][:45] + '...' if len(news['title']) > 45 else news['title']
        source = news.get('source', '未知')[:10]
        time_str = news.get('time', '')[:19]
        
        # 情感标签
        sentiment = news.get('sentiment', '中性')
        sentiment_icon = '📈' if sentiment == '利好' else ('📉' if sentiment == '利空' else '➖')
        
        print(f"{i:<4} {title:<50} {source:<12} {time_str:<20}")
        
        # 摘要
        summary = news.get('summary', '')
        if summary:
            print(f"     📝 {summary[:70]}...")
        
        # 关键词
        keywords = news.get('keywords', [])
        if keywords:
            print(f"     🏷️ {sentiment_icon} {sentiment} | 关键词: {', '.join(keywords[:3])}")
        
        # 链接
        url = news.get('url', '')
        if url:
            print(f"     🔗 {url}")
        
        print("     " + "─" * 84)

    print("=" * 90)


def display_news_detail(news: Dict):
    """显示新闻详情"""
    print("\n" + "=" * 90)
    print(f"【标题】{news['title']}")
    print(f"【来源】{news.get('source', '未知')} | 【时间】{news.get('time', '')}")
    print(f"【分类】{news.get('category', 'other')} | 【情感】{news.get('sentiment', '中性')}")
    print("-" * 90)
    if news.get('summary'):
        print(f"【摘要】{news['summary']}")
    if news.get('original_summary'):
        print(f"【详情】{news['original_summary'][:200]}")
    print("-" * 90)
    print(f"【链接】{news.get('url', '')}")
    print("=" * 90 + "\n")


# ============================================================================
# 主函数
# ============================================================================

def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description='财经新闻查询工具（真实数据版）',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f'''
示例:
  # 获取最新财经新闻
  python news_api.py

  # 获取市场行情新闻
  python news_api.py --category market

  # 搜索关键词
  python news_api.py --keyword "人工智能"

  # 指定返回条数
  python news_api.py --limit 20

  # 组合查询
  python news_api.py --category company --keyword "腾讯" --limit 10

支持的分类:
  all          - 全部新闻（默认）
  market       - 市场行情
  company      - 公司新闻
  macro        - 宏观经济
  international - 国际财经

数据源:
  - 东方财富7x24快讯（主要）
  - 东方财富公告（公司动态）
  - 新浪财经（备用）

{DISCLAIMER}
        '''
    )

    parser.add_argument('-c', '--category',
                        choices=['all', 'market', 'company', 'macro', 'international'],
                        default='all',
                        help='新闻分类（默认：all）')

    parser.add_argument('-k', '--keyword',
                        help='搜索关键词')

    parser.add_argument('-l', '--limit',
                        type=int,
                        default=10,
                        help='返回新闻条数（默认：10）')

    parser.add_argument('--no-cache',
                        action='store_true',
                        help='不使用缓存')

    parser.add_argument('--detail',
                        type=int,
                        help='显示指定编号新闻的详情')

    args = parser.parse_args()

    # 创建API实例
    api = FinanceNewsAPI()

    # 获取新闻
    print("正在获取财经新闻...", file=sys.stderr)
    use_cache = not args.no_cache
    all_news = api.fetch_all_news(use_cache=use_cache)

    if not all_news:
        print("未能获取到新闻数据，请检查网络连接", file=sys.stderr)
        sys.exit(1)

    # 按分类过滤
    filtered_news = api.filter_by_category(all_news, args.category)

    # 按关键词搜索
    if args.keyword:
        print(f"🔍 搜索关键词: {args.keyword}", file=sys.stderr)
        filtered_news = api.search_by_keyword(filtered_news, args.keyword)

    if not filtered_news:
        print("未找到符合条件的新闻")
        sys.exit(0)

    # 显示结果
    display_news_list(filtered_news, args.limit)

    # 显示分类统计
    if args.category == 'all':
        print("\n📊 新闻分类统计：")
        category_counts = {}
        for news in filtered_news:
            cat = news.get('category', 'other')
            category_counts[cat] = category_counts.get(cat, 0) + 1

        for cat, count in sorted(category_counts.items(), key=lambda x: x[1], reverse=True):
            print(f"  - {cat}: {count} 条")

        # 情感统计
        print("\n🎭 情感分析统计：")
        sentiment_counts = {'利好': 0, '利空': 0, '中性': 0}
        for news in filtered_news:
            sentiment = news.get('sentiment', '中性')
            sentiment_counts[sentiment] = sentiment_counts.get(sentiment, 0) + 1

        for sentiment, count in sentiment_counts.items():
            icon = '📈' if sentiment == '利好' else ('📉' if sentiment == '利空' else '➖')
            print(f"  {icon} {sentiment}: {count} 条")

    print(f"\n{DISCLAIMER}")


if __name__ == '__main__':
    main()