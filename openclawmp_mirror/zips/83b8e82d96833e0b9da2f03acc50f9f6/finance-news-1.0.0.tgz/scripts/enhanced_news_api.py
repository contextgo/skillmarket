#!/usr/bin/env python3
"""
增强版财经新闻查询工具
新增功能：
- 多数据源：东方财富、腾讯财经、华尔街见闻、财联社、RSS订阅
- 智能摘要生成（每条新闻自动生成 50 字摘要）
- 情感分析（利好/利空/中性）
- 热点新闻排行榜（24小时最热）
- 关键词高亮功能
- 表格和列表切换输出格式
- 错误处理和重试机制（3次重试）
- 数据缓存减少API调用
"""

import sys
import requests
import json
import time
import hashlib
import os
import re
from datetime import datetime, timedelta
from typing import List, Dict, Optional, Tuple
from urllib.parse import urlparse, quote
import feedparser  # RSS 解析库，需要安装: pip install feedparser

# ============================================================================
# 常量定义
# ============================================================================

# 免责声明
DISCLAIMER = "⚠️ 所有新闻内容仅供参考，不构成投资建议"

# 缓存配置
CACHE_DIR = '/tmp/finance_news_enhanced_cache'
CACHE_EXPIRE_MINUTES = 15  # 缓存过期时间（分钟）

# 重试配置
MAX_RETRIES = 3
RETRY_DELAY = 1  # 重试间隔（秒）

# 请求超时
REQUEST_TIMEOUT = 15

# 情感分析关键词
POSITIVE_KEYWORDS = [
    '上涨', '涨停', '盈利', '增长', '突破', '利好', '创新高', '大涨', '翻倍',
    '业绩大增', '超预期', '回购', '增持', '并购', '中标', '签约', '合作',
    '获批', '投产', '扩张', '分红', '派息', '牛市', '反弹', '复苏', '改善',
    '向好', '乐观', '积极', '看好', '布局', '机遇', '蓝筹', '龙头'
]

NEGATIVE_KEYWORDS = [
    '下跌', '跌停', '亏损', '下降', '暴跌', '利空', '创新低', '大跌', '腰斩',
    '业绩下滑', '不及预期', '减持', '清仓', '套现', '违约', '债务', '破产',
    '退市', '处罚', '调查', '诉讼', '裁员', '关闭', '停产', '暴雷', '熊市',
    '崩盘', '危机', '风险', '担忧', '悲观', '谨慎', '回避', '减持', '质押'
]

# 新闻分类关键词
CATEGORY_KEYWORDS = {
    'market': ['股市', 'A股', '港股', '美股', '涨停', '跌停', '指数', '大盘', '股票', '证券', '基金', '期货'],
    'company': ['公司', '财报', '业绩', '并购', '上市', '退市', '公告', '企业', '集团', '董事会', '股东'],
    'macro': ['央行', 'GDP', 'CPI', '政策', '利率', '降准', '财政', '经济', '货币', '通胀', '通缩', '就业'],
    'international': ['美联储', '美元', '欧元', '国际贸易', '全球', '海外', '国际', '外盘', '汇率', '关税']
}

# 热点新闻关键词（用于计算热度）
HOT_KEYWORDS = [
    '涨停', '跌停', '暴涨', '暴跌', '破发', '创新高', '创新低', '利好', '利空',
    '重大', '突发', '紧急', '重磅', '震惊', '历史性', '里程碑', '首次'
]

# RSS 订阅源
RSS_SOURCES = {
    'eastmoney': 'https://news.10jqka.com.cn/tapp/news/push/stock/?tag=zq',
    'wallstreetcn_hot': 'https://wallstreetcn.com/news/global',
    'cls_hot': 'https://www.cls.cn/subject'
}


# ============================================================================
# 缓存管理类
# ============================================================================

class EnhancedNewsCache:
    """增强版新闻缓存管理"""

    def __init__(self, cache_dir: str = CACHE_DIR, expire_minutes: int = CACHE_EXPIRE_MINUTES):
        self.cache_dir = cache_dir
        self.expire_minutes = expire_minutes
        os.makedirs(cache_dir, exist_ok=True)

    def _get_cache_key(self, key: str) -> str:
        """生成缓存文件名"""
        hash_key = hashlib.md5(key.encode()).hexdigest()
        return os.path.join(self.cache_dir, f"{hash_key}.json")

    def get(self, key: str) -> Optional[List[Dict]]:
        """获取缓存数据"""
        cache_file = self._get_cache_key(key)

        if not os.path.exists(cache_file):
            return None

        try:
            modify_time = datetime.fromtimestamp(os.path.getmtime(cache_file))
            if datetime.now() - modify_time > timedelta(minutes=self.expire_minutes):
                return None

            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return None

    def set(self, key: str, data: List[Dict]):
        """设置缓存"""
        cache_file = self._get_cache_key(key)
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def get_metadata(self, key: str) -> Optional[Dict]:
        """获取缓存元数据"""
        cache_file = self._get_cache_key(key)
        if os.path.exists(cache_file):
            return {
                'cached_at': datetime.fromtimestamp(os.path.getmtime(cache_file)).isoformat(),
                'size': os.path.getsize(cache_file)
            }
        return None


# ============================================================================
# 情感分析器
# ============================================================================

class SentimentAnalyzer:
    """新闻情感分析器"""

    @staticmethod
    def analyze(title: str, summary: str = '') -> Tuple[str, float, List[str]]:
        """
        分析新闻情感
        返回: (情感类型, 置信度, 匹配的关键词列表)
        """
        text = f"{title} {summary}".lower()

        positive_matches = []
        negative_matches = []

        # 匹配正面关键词
        for keyword in POSITIVE_KEYWORDS:
            if keyword in text:
                positive_matches.append(keyword)

        # 匹配负面关键词
        for keyword in NEGATIVE_KEYWORDS:
            if keyword in text:
                negative_matches.append(keyword)

        # 计算情感得分
        positive_score = len(positive_matches)
        negative_score = len(negative_matches)

        # 确定情感类型
        if positive_score > negative_score:
            sentiment = '利好'
            confidence = min(positive_score / max(positive_score + negative_score, 1), 1.0)
            matched_keywords = positive_matches[:5]  # 最多返回5个关键词
        elif negative_score > positive_score:
            sentiment = '利空'
            confidence = min(negative_score / max(positive_score + negative_score, 1), 1.0)
            matched_keywords = negative_matches[:5]
        else:
            sentiment = '中性'
            confidence = 0.5
            matched_keywords = positive_matches[:2] + negative_matches[:2]

        return sentiment, round(confidence, 2), matched_keywords


# ============================================================================
# 智能摘要生成器
# ============================================================================

class SummaryGenerator:
    """智能摘要生成器"""

    @staticmethod
    def generate(content: str, max_length: int = 50) -> str:
        """
        生成智能摘要
        提取关键句子，生成指定长度的摘要
        """
        if not content:
            return ''

        # 清理文本
        content = re.sub(r'<[^>]+>', '', content)  # 移除HTML标签
        content = re.sub(r'\s+', ' ', content).strip()  # 合并空白字符

        # 如果内容已经够短，直接返回
        if len(content) <= max_length:
            return content

        # 按句子分割
        sentences = re.split(r'[。！？；\.\!\?\;]', content)
        sentences = [s.strip() for s in sentences if s.strip()]

        if not sentences:
            return content[:max_length] + '...'

        # 计算每个句子的重要性（基于关键词密度）
        important_keywords = ['发布', '宣布', '决定', '显示', '报告', '预计', '增长', '下降', 
                           '上涨', '下跌', '突破', '创新', '首次', '重大', '重要']
        
        sentence_scores = []
        for sentence in sentences:
            score = sum(1 for kw in important_keywords if kw in sentence)
            # 优先选择靠前的句子
            position_bonus = max(0, 3 - sentences.index(sentence)) * 0.5
            sentence_scores.append((sentence, score + position_bonus))

        # 按得分排序
        sentence_scores.sort(key=lambda x: x[1], reverse=True)

        # 构建摘要
        summary = ''
        for sentence, _ in sentence_scores:
            if len(summary) + len(sentence) <= max_length:
                summary += sentence + '。'
            else:
                break

        # 如果摘要为空，取前N个字符
        if not summary:
            summary = content[:max_length]

        # 确保以省略号结尾
        if len(summary) < len(content) and not summary.endswith('...'):
            summary = summary.rstrip('。') + '...'

        return summary[:max_length + 3]  # 允许稍微超出，加上省略号


# ============================================================================
# 数据源获取器
# ============================================================================

class NewsSourceFetcher:
    """多数据源新闻获取器"""

    HEADERS = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    }

    def __init__(self, cache: EnhancedNewsCache):
        self.cache = cache

    def _fetch_with_retry(self, url: str, headers: dict = None, timeout: int = REQUEST_TIMEOUT) -> Optional[requests.Response]:
        """带重试机制的请求"""
        request_headers = {**self.HEADERS, **(headers or {})}
        
        for attempt in range(MAX_RETRIES):
            try:
                response = requests.get(url, headers=request_headers, timeout=timeout)
                if response.status_code == 200:
                    return response
                elif response.status_code == 429:  # 频率限制
                    wait_time = int(response.headers.get('Retry-After', RETRY_DELAY * 2))
                    time.sleep(wait_time)
                else:
                    if attempt < MAX_RETRIES - 1:
                        time.sleep(RETRY_DELAY)
            except requests.exceptions.RequestException as e:
                if attempt < MAX_RETRIES - 1:
                    time.sleep(RETRY_DELAY)
                else:
                    print(f"请求失败（已重试{MAX_RETRIES}次）: {e}", file=sys.stderr)
        
        return None

    def fetch_sina_news(self) -> List[Dict]:
        """获取新浪财经新闻"""
        url = "https://newsapi.sina.cn/api/hotnews.json"
        headers = {**self.HEADERS, 'Referer': 'https://news.sina.com.cn/'}

        response = self._fetch_with_retry(url, headers)
        if not response:
            return []

        try:
            response.encoding = 'utf-8'
            data = json.loads(response.text)
            news_list = []

            for item in data.get('data', []):
                title = item.get('title', '')
                if not title:
                    continue

                timestamp = item.get('ctime', '')
                try:
                    dt = datetime.fromtimestamp(int(timestamp))
                    time_str = dt.strftime('%Y-%m-%d %H:%M:%S')
                except:
                    time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                content = item.get('intro', '')
                
                news = {
                    'title': title,
                    'source': '新浪财经',
                    'source_icon': '📰',
                    'time': time_str,
                    'timestamp': int(timestamp) if timestamp else int(datetime.now().timestamp()),
                    'category': self._classify_news(title, content),
                    'summary': SummaryGenerator.generate(content, 50),
                    'original_summary': content[:150] + '...' if len(content) > 150 else content,
                    'url': item.get('url', ''),
                    'keywords': []
                }
                news_list.append(news)

            return news_list
        except Exception as e:
            print(f"解析新浪财经数据失败: {e}", file=sys.stderr)
            return []

    def fetch_eastmoney_news(self) -> List[Dict]:
        """获取东方财富新闻"""
        url = "https://np-listapi.eastmoney.com/comm/wap/getListInfo"
        params = {
            'type': 106,  # 财经新闻类型
            'pageSize': 20,
            'pageNo': 1,
            'fields': 'title,url,source_url,source,showTime'
        }
        headers = {**self.HEADERS, 'Referer': 'https://www.eastmoney.com/'}

        try:
            # 构建完整URL
            full_url = f"{url}?{'&'.join(f'{k}={v}' for k, v in params.items())}"
            response = self._fetch_with_retry(full_url, headers)
            
            if not response:
                return []
            
            response.encoding = 'utf-8'
            data = json.loads(response.text)
            news_list = []

            for item in data.get('data', {}).get('list', []):
                title = item.get('title', '')
                if not title:
                    continue

                time_str = item.get('showTime', '')
                if not time_str:
                    time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                news = {
                    'title': title,
                    'source': item.get('source', '东方财富'),
                    'source_icon': '💰',
                    'time': time_str,
                    'timestamp': int(datetime.now().timestamp()),
                    'category': self._classify_news(title, ''),
                    'summary': SummaryGenerator.generate(title, 50),
                    'original_summary': '',
                    'url': item.get('url', ''),
                    'keywords': []
                }
                news_list.append(news)

            return news_list
        except Exception as e:
            print(f"获取东方财富新闻失败: {e}", file=sys.stderr)
            return []

    def fetch_tencent_news(self) -> List[Dict]:
        """获取腾讯财经新闻"""
        url = "https://i.news.qq.com/gw/trace_iphp/pc/pc_finance_list"
        params = {
            'page': 1,
            'num': 20,
            'callback': 'jsonp'
        }
        headers = {**self.HEADERS, 'Referer': 'https://finance.qq.com/'}

        try:
            full_url = f"{url}?{'&'.join(f'{k}={v}' for k, v in params.items())}"
            response = self._fetch_with_retry(full_url, headers)
            
            if not response:
                return []
            
            response.encoding = 'utf-8'
            # 尝试解析JSONP响应
            text = response.text
            if text.startswith('jsonp('):
                text = text[6:-1]  # 移除 jsonp() 包装
            
            data = json.loads(text)
            news_list = []

            items = data.get('data', {}).get('list', [])
            for item in items:
                title = item.get('title', '')
                if not title:
                    continue

                timestamp = item.get('timestamp', 0)
                time_str = datetime.fromtimestamp(timestamp).strftime('%Y-%m-%d %H:%M:%S') if timestamp else datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                news = {
                    'title': title,
                    'source': '腾讯财经',
                    'source_icon': '🐧',
                    'time': time_str,
                    'timestamp': timestamp or int(datetime.now().timestamp()),
                    'category': self._classify_news(title, item.get('abstract', '')),
                    'summary': SummaryGenerator.generate(item.get('abstract', ''), 50),
                    'original_summary': item.get('abstract', '')[:150],
                    'url': item.get('url', ''),
                    'keywords': []
                }
                news_list.append(news)

            return news_list
        except Exception as e:
            print(f"获取腾讯财经新闻失败: {e}", file=sys.stderr)
            return []

    def fetch_rss_news(self, rss_url: str, source_name: str) -> List[Dict]:
        """获取RSS新闻源"""
        news_list = []
        
        try:
            response = self._fetch_with_retry(rss_url)
            if not response:
                return []
            
            feed = feedparser.parse(response.content)
            
            for entry in feed.entries[:20]:
                title = entry.get('title', '')
                if not title:
                    continue

                # 解析时间
                published = entry.get('published_parsed') or entry.get('updated_parsed')
                if published:
                    time_str = time.strftime('%Y-%m-%d %H:%M:%S', published)
                    timestamp = int(time.mktime(published))
                else:
                    time_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                    timestamp = int(datetime.now().timestamp())

                # 获取摘要
                summary = entry.get('summary', '') or entry.get('description', '')

                news = {
                    'title': title,
                    'source': source_name,
                    'source_icon': '📡',
                    'time': time_str,
                    'timestamp': timestamp,
                    'category': self._classify_news(title, summary),
                    'summary': SummaryGenerator.generate(summary, 50),
                    'original_summary': summary[:150],
                    'url': entry.get('link', ''),
                    'keywords': []
                }
                news_list.append(news)

            return news_list
        except Exception as e:
            print(f"获取RSS新闻失败 ({source_name}): {e}", file=sys.stderr)
            return []

    def _classify_news(self, title: str, summary: str = '') -> str:
        """对新闻进行分类"""
        text = f"{title} {summary}".lower()

        scores = {}
        for category, keywords in CATEGORY_KEYWORDS.items():
            score = sum(1 for keyword in keywords if keyword in text)
            scores[category] = score

        max_score = max(scores.values())
        if max_score == 0:
            return 'market'

        return max(scores, key=scores.get)


# ============================================================================
# 热点新闻排行榜
# ============================================================================

class HotNewsRanker:
    """热点新闻排行榜计算器"""

    @staticmethod
    def calculate_hot_score(news: Dict) -> int:
        """
        计算新闻热度得分
        基于时间衰减、关键词匹配、情感强度等因素
        """
        score = 0

        # 1. 时间因素（越新越热）
        timestamp = news.get('timestamp', 0)
        if timestamp:
            hours_ago = (datetime.now().timestamp() - timestamp) / 3600
            if hours_ago < 1:
                score += 50  # 1小时内
            elif hours_ago < 6:
                score += 30  # 6小时内
            elif hours_ago < 12:
                score += 20  # 12小时内
            elif hours_ago < 24:
                score += 10  # 24小时内

        # 2. 热点关键词匹配
        title = news.get('title', '')
        summary = news.get('original_summary', '') or news.get('summary', '')
        text = f"{title} {summary}"

        for keyword in HOT_KEYWORDS:
            if keyword in text:
                score += 15

        # 3. 情感强度
        sentiment, confidence, _ = SentimentAnalyzer.analyze(title, summary)
        if sentiment != '中性':
            score += int(confidence * 20)

        return score

    @staticmethod
    def get_hot_news(news_list: List[Dict], top_n: int = 10) -> List[Dict]:
        """获取热点新闻排行榜"""
        # 计算热度得分
        for news in news_list:
            news['hot_score'] = HotNewsRanker.calculate_hot_score(news)

        # 按热度排序
        sorted_news = sorted(news_list, key=lambda x: x.get('hot_score', 0), reverse=True)

        return sorted_news[:top_n]


# ============================================================================
# 关键词高亮
# ============================================================================

class KeywordHighlighter:
    """关键词高亮处理器"""

    # ANSI 颜色代码
    COLORS = {
        'red': '\033[91m',
        'green': '\033[92m',
        'yellow': '\033[93m',
        'blue': '\033[94m',
        'magenta': '\033[95m',
        'cyan': '\033[96m',
        'white': '\033[97m',
        'reset': '\033[0m',
        'bold': '\033[1m',
        'underline': '\033[4m'
    }

    @staticmethod
    def highlight(text: str, keywords: List[str], color: str = 'yellow') -> str:
        """高亮显示关键词"""
        if not sys.stdout.isatty():
            return text

        color_code = KeywordHighlighter.COLORS.get(color, '')
        reset_code = KeywordHighlighter.COLORS['reset']

        # 按长度降序排序，避免短关键词先被替换
        sorted_keywords = sorted(set(keywords), key=len, reverse=True)

        for keyword in sorted_keywords:
            if keyword in text:
                text = text.replace(keyword, f"{color_code}{keyword}{reset_code}")

        return text

    @staticmethod
    def highlight_sentiment(text: str, sentiment: str) -> str:
        """根据情感高亮文本"""
        if not sys.stdout.isatty():
            return text

        if sentiment == '利好':
            return f"{KeywordHighlighter.COLORS['red']}{text}{KeywordHighlighter.COLORS['reset']}"
        elif sentiment == '利空':
            return f"{KeywordHighlighter.COLORS['green']}{text}{KeywordHighlighter.COLORS['reset']}"
        else:
            return text


# ============================================================================
# 主API类
# ============================================================================

class EnhancedFinanceNewsAPI:
    """增强版财经新闻API"""

    def __init__(self):
        self.cache = EnhancedNewsCache()
        self.fetcher = NewsSourceFetcher(self.cache)

    def fetch_all_news(self, use_cache: bool = True, sources: List[str] = None) -> List[Dict]:
        """
        获取所有新闻源
        sources: 指定数据源，None表示全部
        """
        cache_key = f"all_news_{'_'.join(sources or ['all'])}"

        # 尝试从缓存获取
        if use_cache:
            cached = self.cache.get(cache_key)
            if cached:
                return cached

        all_news = []

        # 获取各数据源
        if sources is None or 'sina' in sources:
            all_news.extend(self.fetcher.fetch_sina_news())
            time.sleep(0.3)  # 避免请求过快
        
        if sources is None or 'eastmoney' in sources:
            all_news.extend(self.fetcher.fetch_eastmoney_news())
            time.sleep(0.3)
        
        if sources is None or 'tencent' in sources:
            all_news.extend(self.fetcher.fetch_tencent_news())

        # 为每条新闻添加情感分析
        for news in all_news:
            sentiment, confidence, matched_keywords = SentimentAnalyzer.analyze(
                news['title'], 
                news.get('original_summary', '') or news.get('summary', '')
            )
            news['sentiment'] = sentiment
            news['sentiment_confidence'] = confidence
            news['matched_keywords'] = matched_keywords

        # 去重（按标题）
        seen_titles = set()
        unique_news = []
        for news in all_news:
            title_normalized = news['title'].strip().lower()
            if title_normalized not in seen_titles:
                seen_titles.add(title_normalized)
                unique_news.append(news)

        # 按时间排序
        unique_news.sort(key=lambda x: x.get('timestamp', 0), reverse=True)

        # 缓存结果
        if use_cache and unique_news:
            self.cache.set(cache_key, unique_news)

        return unique_news

    def filter_by_category(self, news_list: List[Dict], category: str) -> List[Dict]:
        """按分类过滤新闻"""
        if category == 'all':
            return news_list
        return [news for news in news_list if news.get('category') == category]

    def search_by_keyword(self, news_list: List[Dict], keyword: str) -> List[Dict]:
        """按关键词搜索"""
        keyword_lower = keyword.lower()

        results = []
        for news in news_list:
            title = news.get('title', '').lower()
            summary = news.get('summary', '').lower()

            if keyword_lower in title or keyword_lower in summary:
                # 计算相关性得分
                score = 0
                if keyword_lower in title:
                    score += 10
                    # 标题中出现的位置越靠前，得分越高
                    pos = title.find(keyword_lower)
                    score += max(0, 10 - pos // 5)
                if keyword_lower in summary:
                    score += 5

                news_copy = news.copy()
                news_copy['_relevance'] = score
                # 标记匹配的关键词
                news_copy['highlight_keywords'] = [keyword]
                results.append(news_copy)

        # 按相关性排序
        results.sort(key=lambda x: x.get('_relevance', 0), reverse=True)

        return results

    def get_hot_news(self, hours: int = 24, limit: int = 10) -> List[Dict]:
        """获取热点新闻排行榜"""
        all_news = self.fetch_all_news()
        
        # 过滤指定时间内的新闻
        cutoff_time = datetime.now() - timedelta(hours=hours)
        recent_news = [
            news for news in all_news 
            if datetime.fromtimestamp(news.get('timestamp', 0)) > cutoff_time
        ]

        return HotNewsRanker.get_hot_news(recent_news, limit)


# ============================================================================
# 输出格式化
# ============================================================================

def display_news_list(news_list: List[Dict], limit: int = 10, 
                      highlight_keywords: List[str] = None,
                      show_sentiment: bool = True):
    """以列表形式显示新闻"""
    if not news_list:
        print("暂无新闻数据")
        return

    print(f"\n📰 共找到 {len(news_list)} 条新闻，显示前 {min(limit, len(news_list))} 条")
    print("=" * 90)

    for i, news in enumerate(news_list[:limit], 1):
        # 标题处理
        title = news['title']
        if highlight_keywords:
            title = KeywordHighlighter.highlight(title, highlight_keywords, 'yellow')

        # 情感标签
        sentiment = news.get('sentiment', '中性')
        if show_sentiment:
            sentiment_display = KeywordHighlighter.highlight_sentiment(
                f"[{sentiment}]", sentiment
            )
        else:
            sentiment_display = ''

        # 来源图标
        source_icon = news.get('source_icon', '📰')
        source = news.get('source', '未知来源')

        print(f"\n{i}. {title}")
        print(f"   {source_icon} {source} | 🕐 {news['time']} | {sentiment_display}")
        
        # 摘要
        summary = news.get('summary', '')
        if summary:
            if highlight_keywords:
                summary = KeywordHighlighter.highlight(summary, highlight_keywords, 'cyan')
            print(f"   📝 {summary}")

        # 匹配的关键词
        matched_keywords = news.get('matched_keywords', [])
        if matched_keywords:
            keywords_str = ', '.join(matched_keywords[:3])
            print(f"   🏷️ 关键词: {keywords_str}")

        # 链接
        url = news.get('url', '')
        if url:
            print(f"   🔗 {url}")
        
        print("   " + "─" * 86)

    print("=" * 90)


def display_news_table(news_list: List[Dict], limit: int = 10,
                       highlight_keywords: List[str] = None):
    """以表格形式显示新闻"""
    if not news_list:
        print("暂无新闻数据")
        return

    print(f"\n📊 新闻列表（表格模式）")
    print("=" * 120)

    # 表头
    headers = ["序号", "标题", "来源", "时间", "情感", "分类"]
    col_widths = [4, 50, 12, 20, 6, 10]
    
    header_line = "".join(f"{h:<{w}}" for h, w in zip(headers, col_widths))
    print(header_line)
    print("-" * 120)

    # 数据行
    for i, news in enumerate(news_list[:limit], 1):
        title = news['title'][:45] + '...' if len(news['title']) > 45 else news['title']
        if highlight_keywords:
            title = KeywordHighlighter.highlight(title, highlight_keywords, 'yellow')

        source = news.get('source', '未知')[:10]
        time_str = news.get('time', '')[:19]
        sentiment = news.get('sentiment', '中性')
        category = news.get('category', 'market')

        # 情感颜色
        sentiment_display = KeywordHighlighter.highlight_sentiment(sentiment, sentiment)

        row = [
            str(i),
            title,
            source,
            time_str,
            sentiment_display,
            category
        ]

        row_line = "".join(f"{cell:<{w}}" for cell, w in zip(row, col_widths))
        print(row_line)

    print("=" * 120)


def display_hot_ranking(news_list: List[Dict]):
    """显示热点新闻排行榜"""
    print("\n🔥 24小时热点新闻排行榜 🔥")
    print("=" * 80)

    for i, news in enumerate(news_list, 1):
        # 热度得分
        hot_score = news.get('hot_score', 0)
        fire_emoji = '🔥' * min(hot_score // 20 + 1, 5)

        title = news['title']
        if len(title) > 50:
            title = title[:47] + '...'

        sentiment = news.get('sentiment', '中性')
        sentiment_icon = '📈' if sentiment == '利好' else ('📉' if sentiment == '利空' else '➖')

        print(f"\n{i}. {fire_emoji} {sentiment_icon} {title}")
        print(f"   来源: {news.get('source', '')} | 热度: {hot_score}")
        print(f"   时间: {news.get('time', '')}")

    print("\n" + "=" * 80)


# ============================================================================
# 主函数
# ============================================================================

def main():
    """主函数"""
    import argparse

    parser = argparse.ArgumentParser(
        description='增强版财经新闻查询工具',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=f'''
示例:
  # 获取最新财经新闻
  python {__file__}

  # 获取市场行情新闻
  python {__file__} --category market

  # 搜索关键词
  python {__file__} --keyword "人工智能"

  # 指定返回条数
  python {__file__} --limit 20

  # 热点新闻排行榜
  python {__file__} --hot

  # 以表格形式显示
  python {__file__} --table

  # 指定数据源
  python {__file__} --sources sina eastmoney

支持的分类:
  all           - 全部新闻（默认）
  market        - 市场行情
  company       - 公司新闻
  macro         - 宏观经济
  international - 国际财经

支持的数据源:
  sina          - 新浪财经
  eastmoney     - 东方财富
  tencent       - 腾讯财经

{DISCLAIMER}
        '''
    )

    parser.add_argument('-c', '--category',
                        choices=['all', 'market', 'company', 'macro', 'international'],
                        default='all',
                        help='新闻分类（默认：all）')

    parser.add_argument('-k', '--keyword',
                        help='搜索关键词')

    parser.add_argument('-l', '--limit',
                        type=int,
                        default=10,
                        help='返回新闻条数（默认：10）')

    parser.add_argument('--no-cache',
                        action='store_true',
                        help='不使用缓存')

    parser.add_argument('--table',
                        action='store_true',
                        help='以表格形式显示结果')

    parser.add_argument('--hot',
                        action='store_true',
                        help='显示热点新闻排行榜')

    parser.add_argument('--sources',
                        nargs='+',
                        choices=['sina', 'eastmoney', 'tencent'],
                        help='指定数据源')

    parser.add_argument('--no-sentiment',
                        action='store_true',
                        help='不显示情感分析')

    args = parser.parse_args()

    # 创建API实例
    api = EnhancedFinanceNewsAPI()

    # 获取新闻
    print("正在获取财经新闻...")
    use_cache = not args.no_cache
    all_news = api.fetch_all_news(use_cache=use_cache, sources=args.sources)

    if not all_news:
        print("未能获取到新闻数据，请检查网络连接")
        sys.exit(1)

    # 按分类过滤
    filtered_news = api.filter_by_category(all_news, args.category)

    # 按关键词搜索
    highlight_keywords = []
    if args.keyword:
        print(f"🔍 搜索关键词: {args.keyword}")
        filtered_news = api.search_by_keyword(filtered_news, args.keyword)
        highlight_keywords = [args.keyword]

    if not filtered_news:
        print("未找到符合条件的新闻")
        sys.exit(0)

    # 显示结果
    show_sentiment = not args.no_sentiment

    if args.hot:
        # 显示热点排行榜
        hot_news = api.get_hot_news(hours=24, limit=args.limit)
        display_hot_ranking(hot_news)
    elif args.table:
        # 表格模式
        display_news_table(filtered_news, args.limit, highlight_keywords)
    else:
        # 列表模式
        display_news_list(filtered_news, args.limit, highlight_keywords, show_sentiment)

    # 显示分类统计
    if args.category == 'all' and not args.hot:
        print("\n📊 新闻分类统计：")
        category_counts = {}
        for news in filtered_news:
            cat = news.get('category', 'other')
            category_counts[cat] = category_counts.get(cat, 0) + 1

        for cat, count in sorted(category_counts.items(), key=lambda x: x[1], reverse=True):
            print(f"  - {cat}: {count} 条")

        # 情感统计
        print("\n🎭 情感分析统计：")
        sentiment_counts = {'利好': 0, '利空': 0, '中性': 0}
        for news in filtered_news:
            sentiment = news.get('sentiment', '中性')
            sentiment_counts[sentiment] = sentiment_counts.get(sentiment, 0) + 1

        for sentiment, count in sentiment_counts.items():
            icon = '📈' if sentiment == '利好' else ('📉' if sentiment == '利空' else '➖')
            print(f"  {icon} {sentiment}: {count} 条")

    print(f"\n{DISCLAIMER}")


if __name__ == '__main__':
    main()