# 财经新闻API技术参考文档

本文档提供财经新闻API的详细技术信息。

## 数据源概述

### 主要数据源

本项目使用多个免费公开数据源获取财经新闻：

1. **新浪财经** - 综合财经新闻
2. **腾讯财经** - 市场动态和公司新闻
3. **网易财经** - 宏观经济分析
4. **东方财富网** - 行业研究报道

### 数据源特点

| 数据源 | 更新频率 | 内容侧重 | API类型 |
|--------|---------|---------|---------|
| 新浪财经 | 实时更新 | 综合财经 | JSON API |
| 腾讯财经 | 5分钟 | 市场行情 | JSON API |
| 网易财经 | 10分钟 | 宏观经济 | JSON API |
| 东方财富网 | 15分钟 | 行业分析 | JSON API |

## API端点

### 新浪财经新闻API

**热门新闻：**
```
https://newsapi.sina.cn/api/hotnews.json
```

**分类新闻：**
```
https://interface.sina.cn/news/get_news_by_category.json?category={分类ID}
```

**分类ID映射：**
- `finance` - 财经要闻
- `stock` - 股市动态
- `forex` - 外汇市场
- `futures` - 期货市场
- `bond` - 债券市场

### 腾讯财经新闻API

**财经头条：**
```
https://finance.qq.com/c/hot_list.htm
```

**股票相关新闻：**
```
https://stock.qq.com/cstock/list.htm
```

### 网易财经新闻API

**财经快讯：**
```
https://money.163.com/special/002557S6/newsdata_idx_index.html
```

**宏观经济：**
```
https://money.163.com/special/00255B0F/macro_news.html
```

## 响应数据格式

### 统一新闻数据结构

```json
{
  "title": "新闻标题",
  "source": "新闻来源",
  "time": "2024-03-18 15:30:00",
  "category": "market",
  "summary": "新闻摘要内容...",
  "url": "https://example.com/news/123",
  "keywords": ["关键词1", "关键词2"],
  "images": ["https://example.com/img.jpg"]
}
```

### 字段说明

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| title | string | 是 | 新闻标题 |
| source | string | 是 | 新闻来源媒体 |
| time | string | 是 | 发布时间（格式：YYYY-MM-DD HH:MM:SS） |
| category | string | 是 | 新闻分类 |
| summary | string | 否 | 新闻摘要 |
| url | string | 是 | 原文链接 |
| keywords | array | 否 | 相关关键词列表 |
| images | array | 否 | 新闻图片URL列表 |

## 数据抓取实现

### 新浪财经抓取示例

```python
import requests
import json
from datetime import datetime

def fetch_sina_finance_news():
    """获取新浪财经热门新闻"""
    url = "https://newsapi.sina.cn/api/hotnews.json"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://news.sina.com.cn/'
    }

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'utf-8'

        if response.status_code == 200:
            data = json.loads(response.text)
            news_list = []

            for item in data.get('data', []):
                news = {
                    'title': item.get('title', ''),
                    'source': item.get('media_name', '新浪财经'),
                    'time': format_time(item.get('ctime', '')),
                    'category': 'market',
                    'summary': item.get('intro', ''),
                    'url': item.get('url', ''),
                    'keywords': extract_keywords(item.get('keywords', ''))
                }
                news_list.append(news)

            return news_list
        else:
            return []

    except Exception as e:
        print(f"抓取新浪财经新闻失败: {e}")
        return []

def format_time(timestamp):
    """格式化时间戳"""
    if not timestamp:
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    try:
        dt = datetime.fromtimestamp(int(timestamp))
        return dt.strftime('%Y-%m-%d %H:%M:%S')
    except:
        return datetime.now().strftime('%Y-%m-%d %H:%M:%S')

def extract_keywords(keywords_str):
    """提取关键词"""
    if not keywords_str:
        return []
    return [k.strip() for k in keywords_str.split(',') if k.strip()]
```

### 腾讯财经抓取示例

```python
def fetch_tencent_finance_news():
    """获取腾讯财经新闻"""
    url = "https://finance.qq.com/c/hot_list.htm"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer': 'https://finance.qq.com/'
    }

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'utf-8'

        if response.status_code == 200:
            # 解析HTML或JSON数据
            return parse_tencent_news(response.text)
        else:
            return []

    except Exception as e:
        print(f"抓取腾讯财经新闻失败: {e}")
        return []
```

## 新闻分类算法

### 关键词分类法

```python
CATEGORY_KEYWORDS = {
    'market': ['股市', 'A股', '港股', '美股', '涨停', '跌停', '指数', '大盘'],
    'company': ['公司', '财报', '业绩', '并购', '上市', '退市', '公告'],
    'macro': ['央行', 'GDP', 'CPI', '政策', '利率', '降准', '财政'],
    'international': ['美联储', '美元', '欧元', '国际贸易', '全球', '海外']
}

def classify_news(title, summary):
    """新闻分类"""
    text = f"{title} {summary}".lower()

    scores = {}
    for category, keywords in CATEGORY_KEYWORDS.items():
        score = sum(1 for keyword in keywords if keyword in text)
        scores[category] = score

    # 返回得分最高的分类
    max_score = max(scores.values())
    if max_score == 0:
        return 'market'  # 默认分类

    return max(scores, key=scores.get)
```

## 关键词搜索实现

### 本地搜索

```python
def search_news_by_keyword(news_list, keyword):
    """按关键词搜索新闻"""
    keyword_lower = keyword.lower()

    results = []
    for news in news_list:
        title = news.get('title', '').lower()
        summary = news.get('summary', '').lower()
        keywords = ' '.join(news.get('keywords', [])).lower()

        # 在标题、摘要和关键词中搜索
        if keyword_lower in title or keyword_lower in summary or keyword_lower in keywords:
            results.append(news)

    return results
```

### 相关性排序

```python
def calculate_relevance(news, keyword):
    """计算新闻与关键词的相关性"""
    score = 0
    keyword_lower = keyword.lower()

    # 标题匹配权重最高
    if keyword_lower in news['title'].lower():
        score += 10

    # 摘要匹配次之
    if keyword_lower in news['summary'].lower():
        score += 5

    # 关键词标签匹配
    if keyword_lower in [k.lower() for k in news.get('keywords', [])]:
        score += 7

    return score

def sort_by_relevance(news_list, keyword):
    """按相关性排序"""
    return sorted(news_list,
                  key=lambda x: calculate_relevance(x, keyword),
                  reverse=True)
```

## 错误处理

### 网络错误处理

```python
def fetch_with_retry(url, max_retries=3, timeout=10):
    """带重试的网络请求"""
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            if response.status_code == 200:
                return response
            elif response.status_code == 404:
                print(f"资源不存在: {url}")
                return None
            else:
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    print(f"请求失败，状态码: {response.status_code}")
                    return None
        except requests.exceptions.Timeout:
            print(f"请求超时，尝试 {attempt + 1}/{max_retries}")
            if attempt < max_retries - 1:
                time.sleep(1)
                continue
        except requests.exceptions.RequestException as e:
            print(f"网络请求异常: {e}")
            if attempt < max_retries - 1:
                time.sleep(1)
                continue

    return None
```

### 数据验证

```python
def validate_news_data(news):
    """验证新闻数据完整性"""
    required_fields = ['title', 'source', 'time', 'url']

    for field in required_fields:
        if not news.get(field):
            return False

    # 验证URL格式
    url = news.get('url', '')
    if not url.startswith('http'):
        return False

    # 验证时间格式
    time_str = news.get('time', '')
    try:
        datetime.strptime(time_str, '%Y-%m-%d %H:%M:%S')
    except ValueError:
        return False

    return True
```

## 性能优化

### 缓存策略

```python
import pickle
import os
from datetime import datetime, timedelta

class NewsCache:
    """新闻缓存管理"""

    def __init__(self, cache_dir='cache', expire_minutes=30):
        self.cache_dir = cache_dir
        self.expire_minutes = expire_minutes
        os.makedirs(cache_dir, exist_ok=True)

    def get_cache_key(self, category, keyword=None):
        """生成缓存键"""
        if keyword:
            return f"{category}_{keyword}.cache"
        return f"{category}.cache"

    def get(self, category, keyword=None):
        """获取缓存"""
        cache_file = os.path.join(self.cache_dir, self.get_cache_key(category, keyword))

        if not os.path.exists(cache_file):
            return None

        # 检查缓存是否过期
        modify_time = datetime.fromtimestamp(os.path.getmtime(cache_file))
        if datetime.now() - modify_time > timedelta(minutes=self.expire_minutes):
            return None

        try:
            with open(cache_file, 'rb') as f:
                return pickle.load(f)
        except:
            return None

    def set(self, category, data, keyword=None):
        """设置缓存"""
        cache_file = os.path.join(self.cache_dir, self.get_cache_key(category, keyword))

        try:
            with open(cache_file, 'wb') as f:
                pickle.dump(data, f)
        except:
            pass
```

### 并发请求

```python
import concurrent.futures

def fetch_all_sources_parallel():
    """并发抓取多个数据源"""
    sources = [
        fetch_sina_finance_news,
        fetch_tencent_finance_news,
        fetch_netease_finance_news
    ]

    all_news = []

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        future_to_source = {executor.submit(source): source.__name__ for source in sources}

        for future in concurrent.futures.as_completed(future_to_source):
            try:
                news_list = future.result()
                all_news.extend(news_list)
            except Exception as e:
                print(f"{future_to_source[future]} 抓取失败: {e}")

    # 去重和排序
    return deduplicate_and_sort(all_news)
```

## 法律和道德注意事项

### 版权声明

- 所有新闻内容版权归原媒体所有
- 本工具仅供个人学习和研究使用
- 不得用于商业用途或大规模分发
- 建议访问原链接阅读完整内容

### 使用限制

- 遵守各数据源的 robots.txt 规则
- 控制请求频率，避免对服务器造成压力
- 不修改或篡改原始内容
- 尊重新闻来源的版权和知识产权

### API使用条款

在使用各财经网站API时，请注意：
- 新浪财经：仅限个人非商业使用
- 腾讯财经：需遵守用户协议
- 网易财经：禁止爬虫滥用

## 故障排除

### 常见问题

1. **无法获取新闻**
   - 检查网络连接
   - 验证API端点是否可访问
   - 检查是否被限流

2. **新闻数据格式错误**
   - API可能已更新，需调整解析逻辑
   - 检查编码格式（UTF-8/GBK）

3. **请求频率限制**
   - 增加请求间隔时间
   - 使用缓存减少重复请求
   - 实现请求队列管理