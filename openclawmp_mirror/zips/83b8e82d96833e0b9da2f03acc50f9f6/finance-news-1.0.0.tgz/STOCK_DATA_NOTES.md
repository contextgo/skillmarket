# 股市早报数据源备注

## 已知数据限制

### 恒生科技指数 (HSTECH)
- **问题**：多个数据源（新浪、东方财富、Investing）接口受限或返回空数据
- **原因**：可能需要特殊权限或 API 密钥
- **解决方案**：
  1. 使用替代数据源（如 Yahoo Finance）
  2. 手动补充数据
  3. 标注"数据暂缺"并说明原因

### 可用数据源优先级

#### A 股指数
1. 新浪财经 `hq.sinajs.cn`
2. 东方财富 `push2.eastmoney.com`

#### 港股指数
1. 新浪财经 `hkHSI`（恒生指数）
2. ~~新浪财经 `hkHSTECH`~~（恒生科技，已失效）
3. 东方财富（需正确 secid 格式）

#### 美股指数
1. Yahoo Finance
2. Alpha Vantage（需 API key）

## 获取恒生科技指数的替代方法

### 已测试的数据源（2026-03-19）

| 数据源 | 状态 | 说明 |
|--------|------|------|
| 新浪财经 | ❌ Forbidden | 接口被限制 |
| 东方财富 API | ❌ 返回空 | secid 格式问题 |
| Yahoo Finance | ❌ 无数据 | 可能需 API key |
| 百度股市通 | ❌ 代码格式不明 | 需进一步研究 |
| Investing.com | ❌ Cloudflare 防护 | 需要浏览器 |

### 可行方案

```bash
# 方案 1: 使用 Playwright 网页抓取（需要浏览器自动化）
python ~/.openclaw/workspace/skills/stock-realtime/scripts/index_fetch.py --playwright

# 方案 2: 手动补充（推荐）
# 访问以下页面查看实时数据：
# - 恒生科技：https://quote.eastmoney.com/hk/333300.html
# - 恒生指数：https://quote.eastmoney.com/hk/100000.html

# 方案 3: 使用替代指数
# 恒生中国企业指数 (HKHSCEI) 可作为参考
```

## 早报模板更新建议

在股市早报中添加数据源说明：
```markdown
**数据来源**: 
- A 股/港股：新浪财经、东方财富
- 美股：Yahoo Finance
- ⚠️ 部分港股指数可能因接口限制暂缺
```

---

**最后更新**: 2026-03-19
