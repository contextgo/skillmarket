#!/bin/bash
# 财经新闻查询测试脚本
# 测试增强版API的各种功能

echo "=========================================="
echo "财经新闻查询增强版 - 功能测试"
echo "=========================================="
echo ""

# 设置脚本路径
SCRIPT_PATH="$HOME/.openclaw/workspace/skills/finance-news/scripts/enhanced_news_api.py"

# 测试1: 基础查询
echo "📝 测试1: 基础查询（获取最新10条新闻）"
echo "----------------------------------------"
python "$SCRIPT_PATH" --limit 5
echo ""

# 测试2: 分类查询
echo "📝 测试2: 分类查询（市场行情）"
echo "----------------------------------------"
python "$SCRIPT_PATH" --category market --limit 3
echo ""

# 测试3: 关键词搜索
echo "📝 测试3: 关键词搜索（人工智能）"
echo "----------------------------------------"
python "$SCRIPT_PATH" --keyword "人工智能" --limit 3
echo ""

# 测试4: 热点新闻
echo "📝 测试4: 热点新闻排行榜"
echo "----------------------------------------"
python "$SCRIPT_PATH" --hot --limit 5
echo ""

# 测试5: 表格显示
echo "📝 测试5: 表格显示模式"
echo "----------------------------------------"
python "$SCRIPT_PATH" --table --limit 5
echo ""

# 测试6: 指定数据源
echo "📝 测试6: 指定数据源（新浪）"
echo "----------------------------------------"
python "$SCRIPT_PATH" --sources sina --limit 3
echo ""

echo "=========================================="
echo "✅ 所有测试完成"
echo "=========================================="
echo ""
echo "⚠️ 注意: 部分测试可能因网络问题返回空数据"
echo "⚠️ 所有新闻内容仅供参考，不构成投资建议"