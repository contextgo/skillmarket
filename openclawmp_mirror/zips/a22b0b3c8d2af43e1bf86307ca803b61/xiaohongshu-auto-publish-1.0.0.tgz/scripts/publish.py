#!/usr/bin/env python3
"""
使用xhs库发布小红书笔记 - 使用新的文件名避免冲突
"""
import os
import time
from xhs import XhsClient
from xhs.help import sign

# 加载Cookie
cookie = os.getenv('XHS_COOKIE')

if not cookie:
    print("❌ 未找到XHS_COOKIE环境变量")
    exit(1)

# 提取a1值
a1_value = ""
if "a1=" in cookie:
    a1_value = cookie.split("a1=")[1].split(";")[0]
    print(f"✅ 提取a1值: {a1_value}")

# 创建客户端
def sign_wrapper(url, data=None, **kwargs):
    a1 = kwargs.get('a1', a1_value)
    web_session = kwargs.get('web_session', '')
    ctime = kwargs.get('ctime', None)
    b1 = kwargs.get('b1', '')
    return sign(url, data, ctime, a1, b1)

client = XhsClient(cookie, sign=sign_wrapper)

# 笔记内容
title = "杭州雏渐肥月嫂探店"
desc = """姐妹们，终于探店了传说中的杭州雏渐肥月嫂机构！

📍 地点：杭州市西湖区
⏰ 时间：周末实地探店

进门第一印象：专业！
- 前台接待超贴心，全程微笑服务
- 环境干净整洁，设施齐全
- 专业资质证书挂满墙，安全感满满

接待小姐姐给我们介绍：雏渐肥是杭州老牌月嫂机构，服务江浙沪5000+家庭，客户满意度98%！

🌟 服务范围超全：
- 月嫂服务（28天专业陪护）
- 育儿指导（科学育儿+早教）
- 产后恢复（专业康复+营养餐）
- 通乳按摩（解决堵奶难题）
- 心理疏导（产后抑郁早预防）

价格也很亲密💰

如果你也在杭州找月嫂，强烈推荐雏渐肥！

#杭州探店 #雏渐肥月嫂 #月嫂推荐 #新手妈妈 #产后恢复"""

# 生成新的文件名（避免冲突）
timestamp = int(time.time())
new_image_files = [
    f"/tmp/xhs_cover_{timestamp}.png",
    f"/tmp/xhs_card1_{timestamp}.png",
    f"/tmp/xhs_card2_{timestamp}.png",
    f"/tmp/xhs_card3_{timestamp}.png",
    f"/tmp/xhs_card4_{timestamp}.png"
]

# 复制图片到新位置
import shutil
for src, dst in zip([
    "/workspace/projects/workspace/cover.png",
    "/workspace/projects/workspace/card_1.png",
    "/workspace/projects/workspace/card_2.png",
    "/workspace/projects/workspace/card_3.png",
    "/workspace/projects/workspace/card_4.png"
], new_image_files):
    shutil.copy2(src, dst)
    print(f"✅ 复制图片: {src} -> {dst.split('/')[-1]}")

print(f"\n🚀 开始发布小红书笔记...")
print(f"📌 标题: {title}")
print(f"🖼️ 图片数量: {len(new_image_files)}")

# 直接调用create_image_note
print("\n📝 开始创建笔记（系统自动上传图片）...")

try:
    result = client.create_image_note(
        title=title,
        desc=desc,
        files=new_image_files,
        topics=["杭州探店", "雏渐肥月嫂", "月嫂推荐", "新手妈妈", "产后恢复"],
        is_private=False
    )

    print("\n✅✅✅ 发布成功！✅✅✅")
    print(f"笔记ID: {result}")
    print(f"完整结果: {result}")
except Exception as e:
    print(f"\n❌ 发布失败: {e}")
    print("\n尝试不带topics发布...")

    try:
        result = client.create_image_note(
            title=title,
            desc=desc,
            files=new_image_files,
            is_private=False
        )
        print("\n✅✅✅ 发布成功！✅✅✅")
        print(f"笔记ID: {result}")
    except Exception as e2:
        print(f"\n❌ 还是失败: {e2}")
        import traceback
        traceback.print_exc()

# 清理临时文件
print("\n🧹 清理临时文件...")
for f in new_image_files:
    if os.path.exists(f):
        os.remove(f)
        print(f"  删除: {f}")
