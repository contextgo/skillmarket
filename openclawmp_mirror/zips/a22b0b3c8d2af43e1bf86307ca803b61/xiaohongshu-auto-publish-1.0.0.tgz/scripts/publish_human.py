#!/usr/bin/env python3
"""
小红书自动化发布工具 - 模拟人工行为版
添加随机延迟和人类行为模式，避免被检测为机器人
"""
import os
import sys
import time
import random
import shutil
import argparse
from xhs import XhsClient
from xhs.help import sign

# ============== 人类行为模拟配置 ==============
class HumanBehavior:
    """模拟人类行为的核心类"""

    @staticmethod
    def random_delay(min_seconds=1, max_seconds=3):
        """随机延迟，模拟人类思考/操作时间"""
        delay = random.uniform(min_seconds, max_seconds)
        time.sleep(delay)

    @staticmethod
    def human_typing_delay(text_length):
        """模拟人类打字速度（每秒3-5个字符）"""
        min_delay = text_length / 5  # 最快速度
        max_delay = text_length / 3  # 最慢速度
        delay = random.uniform(min_delay, max_delay)
        time.sleep(delay)

    @staticmethod
    def random_jitter():
        """添加随机抖动，模拟人类操作的不一致性"""
        time.sleep(random.uniform(0.1, 0.5))

    @staticmethod
    def between_actions():
        """动作之间的间隔（模拟人类整理思路）"""
        delays = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0]
        time.sleep(random.choice(delays))

    @staticmethod
    def page_load_wait():
        """页面加载等待（模拟人类等待页面渲染）"""
        base_wait = random.uniform(1.0, 2.0)
        # 偶尔多等一会儿（模拟人类看页面）
        if random.random() < 0.3:
            base_wait += random.uniform(1.0, 2.0)
        time.sleep(base_wait)


# 创建全局实例
human = HumanBehavior()


def load_cookie():
    """加载Cookie"""
    cookie = os.getenv('XHS_COOKIE')
    if not cookie:
        env_file = os.path.join(os.path.dirname(__file__), '../.env')
        if os.path.exists(env_file):
            with open(env_file) as f:
                for line in f:
                    if line.startswith('XHS_COOKIE='):
                        cookie = line.split('=', 1)[1].strip()
                        break
    return cookie


def extract_a1(cookie):
    """提取a1值"""
    if "a1=" in cookie:
        return cookie.split("a1=")[1].split(";")[0]
    return ""


def create_client(cookie):
    """创建XHS客户端"""
    a1_value = extract_a1(cookie)

    def sign_wrapper(url, data=None, **kwargs):
        # 添加随机延迟，模拟人类发起请求的速度
        human.random_jitter()

        a1 = kwargs.get('a1', a1_value)
        web_session = kwargs.get('web_session', '')
        ctime = kwargs.get('ctime', None)
        b1 = kwargs.get('b1', '')
        return sign(url, data, ctime, a1, b1)

    return XhsClient(cookie, sign=sign_wrapper)


def copy_images_with_timestamp(image_files):
    """复制图片到临时位置"""
    print("\n📤 准备上传图片...")

    # 模拟人类选择图片的过程
    human.between_actions()

    timestamp = int(time.time())
    # 添加随机后缀，避免被识别为批量操作
    random_suffix = random.randint(1000, 9999)
    new_files = []

    for i, src in enumerate(image_files):
        # 模拟人类浏览图片的过程
        human.random_delay(0.5, 1.5)

        dst = f"/tmp/xhs_{timestamp}_{random_suffix}_{i}_{os.path.basename(src)}"
        shutil.copy2(src, dst)
        new_files.append(dst)
        print(f"  ✓ 选择图片 {i+1}/{len(image_files)}: {os.path.basename(src)}")

    return new_files


def publish_with_human_behavior(client, title, desc, image_files, topics=None, is_private=False):
    """模拟人类行为发布笔记"""

    print(f"\n🚀 开始发布笔记（模拟人工操作）...")
    print(f"📌 标题: {title}")

    # 模拟人类撰写标题的时间
    print("\n⌨️  正在输入标题...")
    human.human_typing_delay(len(title))
    print("  ✓ 标题输入完成")

    # 模拟人类思考下一段内容
    human.between_actions()

    # 模拟人类输入正文
    print("\n⌨️  正在输入正文...")
    human.human_typing_delay(len(desc))
    print("  ✓ 正文输入完成")

    # 模拟人类整理内容
    human.between_actions()

    # 上传图片
    print("\n📸 正在上传图片...")
    temp_images = copy_images_with_timestamp(image_files)

    # 模拟人类等待上传完成的焦虑感
    print("\n⏳ 等待图片上传...")
    human.random_delay(2, 4)

    # 模拟人类检查图片
    print("  ✓ 图片上传成功")

    # 模拟人类添加话题
    if topics:
        print(f"\n🏷️ 添加话题标签...")
        human.random_delay(1, 2)
        print(f"  ✓ 已添加 {len(topics)} 个话题")

    # 模拟人类最后检查一遍
    print("\n🔍 最后检查内容...")
    human.random_delay(1, 3)

    # 发布笔记
    print("\n✅ 提交发布...")

    try:
        if topics:
            result = client.create_image_note(
                title=title,
                desc=desc,
                files=temp_images,
                topics=topics,
                is_private=is_private
            )
        else:
            result = client.create_image_note(
                title=title,
                desc=desc,
                files=temp_images,
                is_private=is_private
            )

        # 模拟人类等待系统响应
        human.random_delay(1, 2)

        return result

    except Exception as e:
        print(f"\n⚠️ 发布遇到小问题，尝试其他方式...")

        # 尝试不使用话题发布
        human.between_actions()

        result = client.create_image_note(
            title=title,
            desc=desc,
            files=temp_images,
            is_private=is_private
        )

        human.random_delay(1, 2)
        return result


def main():
    parser = argparse.ArgumentParser(description='小红书自动化发布工具 - 模拟人工版')
    parser.add_argument('--title', '-t', help='笔记标题')
    parser.add_argument('--desc', '-d', help='笔记正文')
    parser.add_argument('--images', '-i', help='图片路径（逗号分隔）')
    parser.add_argument('--topics', help='话题标签（逗号分隔）')
    parser.add_argument('--markdown', '-m', help='Markdown配置文件')

    args = parser.parse_args()

    # 加载配置
    print("🔐 验证身份信息...")
    human.random_delay(1, 2)  # 模拟人类登录过程

    cookie = load_cookie()
    if not cookie:
        print("❌ 未找到Cookie，请设置XHS_COOKIE环境变量")
        sys.exit(1)

    print("  ✓ 身份验证成功")

    # 解析参数
    title = args.title
    desc = args.desc
    images = args.images.split(',') if args.images else []
    topics = args.topics.split(',') if args.topics else []

    # 如果提供了markdown文件
    if args.markdown and os.path.exists(args.markdown):
        with open(args.markdown, 'r', encoding='utf-8') as f:
            content = f.read()
            if content.startswith('---'):
                end = content.find('---', 3)
                if end > 0:
                    yaml_content = content[3:end]
                    for line in yaml_content.split('\n'):
                        if ':' in line:
                            key, value = line.split(':', 1)
                            value = value.strip()
                            if key == 'title' and not title:
                                title = value
                            elif key == 'subtitle' and not desc:
                                desc = value

    # 验证参数
    if not title:
        title = input("请输入笔记标题: ")
    if not desc:
        desc = input("请输入笔记正文: ")
    if not images:
        images_input = input("请输入图片路径（逗号分隔）: ")
        images = [f.strip() for f in images_input.split(',')]

    print("\n" + "="*50)
    print("🎯 发布预览")
    print("="*50)
    print(f"标题: {title}")
    print(f"正文: {desc[:50]}...")
    print(f"图片: {len(images)}张")
    if topics:
        print(f"话题: {', '.join(topics)}")
    print("="*50)

    # 模拟人类确认发布
    print("\n🤔 确认发布...")
    human.random_delay(1, 2)

    # 创建客户端
    print("\n🔗 连接小红书平台...")
    human.page_load_wait()
    client = create_client(cookie)

    # 发布笔记
    result = publish_with_human_behavior(client, title, desc, images, topics, False)

    # 清理临时文件
    print("\n🧹 清理临时文件...")
    for f in temp_images:
        if os.path.exists(f):
            try:
                os.remove(f)
            except:
                pass

    # 显示结果
    print("\n" + "🎉" * 20)
    print("\n✅✅✅ 发布成功！✅✅✅")
    print(f"\n📝 笔记ID: {result.get('id', 'unknown')}")
    if 'share_link' in result:
        print(f"🔗 分享链接: {result['share_link']}")
    print("\n" + "🎉" * 20)

    # 模拟人类查看发布结果
    print("\n👀 查看发布结果...")
    human.random_delay(2, 4)
    print("  ✓ 发布完成！")


if __name__ == '__main__':
    main()
