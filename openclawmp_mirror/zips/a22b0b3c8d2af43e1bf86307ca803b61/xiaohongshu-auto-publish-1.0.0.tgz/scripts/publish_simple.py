#!/usr/bin/env python3
"""
小红书自动化发布工具 - 简化版
使用Markdown文件配置，自动发布小红书笔记

用法：
    python publish_simple.py --markdown content.md --images "cover.png,card_1.png,card_2.png,card_3.png,card_4.png"
"""
import os
import sys
import argparse
import time
import shutil
from xhs import XhsClient
from xhs.help import sign

def load_cookie():
    """加载Cookie"""
    cookie = os.getenv('XHS_COOKIE')
    if not cookie:
        # 尝试从.env文件加载
        env_file = os.path.join(os.path.dirname(__file__), '../.env')
        if os.path.exists(env_file):
            with open(env_file) as f:
                for line in f:
                    if line.startswith('XHS_COOKIE='):
                        cookie = line.split('=', 1)[1].strip()
                        break
    return cookie

def extract_a1(cookie):
    """提取a1值"""
    if "a1=" in cookie:
        return cookie.split("a1=")[1].split(";")[0]
    return ""

def create_client(cookie):
    """创建XHS客户端"""
    a1_value = extract_a1(cookie)

    def sign_wrapper(url, data=None, **kwargs):
        a1 = kwargs.get('a1', a1_value)
        web_session = kwargs.get('web_session', '')
        ctime = kwargs.get('ctime', None)
        b1 = kwargs.get('b1', '')
        return sign(url, data, ctime, a1, b1)

    return XhsClient(cookie, sign=sign_wrapper)

def copy_images_with_timestamp(image_files):
    """复制图片到临时位置，避免文件名冲突"""
    timestamp = int(time.time())
    new_files = []

    for src in image_files:
        dst = f"/tmp/xhs_{timestamp}_{os.path.basename(src)}"
        shutil.copy2(src, dst)
        new_files.append(dst)
        print(f"  复制: {os.path.basename(src)}")

    return new_files

def main():
    parser = argparse.ArgumentParser(description='小红书自动化发布工具 - 简化版')
    parser.add_argument('--markdown', '-m', help='Markdown配置文件路径')
    parser.add_argument('--title', '-t', help='笔记标题')
    parser.add_argument('--desc', '-d', help='笔记正文')
    parser.add_argument('--images', '-i', help='图片路径（逗号分隔）')
    parser.add_argument('--topics', help='话题标签（逗号分隔）')

    args = parser.parse_args()

    # 加载配置
    cookie = load_cookie()
    if not cookie:
        print("❌ 未找到Cookie，请设置XHS_COOKIE环境变量或配置.env文件")
        sys.exit(1)

    # 解析参数
    title = args.title
    desc = args.desc
    images = args.images.split(',') if args.images else []
    topics = args.topics.split(',') if args.topics else []

    # 如果提供了markdown文件，尝试从中读取配置
    if args.markdown and os.path.exists(args.markdown):
        with open(args.markdown, 'r', encoding='utf-8') as f:
            content = f.read()

            # 解析YAML头部
            if content.startswith('---'):
                end = content.find('---', 3)
                if end > 0:
                    yaml_content = content[3:end]
                    for line in yaml_content.split('\n'):
                        if ':' in line:
                            key, value = line.split(':', 1)
                            value = value.strip()
                            if key == 'title' and not title:
                                title = value
                            elif key == 'subtitle' and not desc:
                                desc = value

    # 验证参数
    if not title:
        title = input("请输入笔记标题: ")
    if not desc:
        desc = input("请输入笔记正文: ")
    if not images:
        images_input = input("请输入图片路径（逗号分隔）: ")
        images = [f.strip() for f in images_input.split(',')]

    print(f"\n🚀 开始发布小红书笔记...")
    print(f"📌 标题: {title}")
    print(f"📝 正文: {desc[:50]}...")
    print(f"🖼️ 图片: {len(images)}张")

    # 复制图片
    print("\n📤 复制图片...")
    temp_images = copy_images_with_timestamp(images)

    # 创建客户端
    print("\n🔗 连接小红书...")
    client = create_client(cookie)

    # 发布笔记
    print("\n📝 发布笔记...")
    try:
        if topics:
            result = client.create_image_note(
                title=title,
                desc=desc,
                files=temp_images,
                topics=topics,
                is_private=False
            )
        else:
            result = client.create_image_note(
                title=title,
                desc=desc,
                files=temp_images,
                is_private=False
            )

        print("\n✅✅✅ 发布成功！✅✅✅")
        print(f"笔记ID: {result.get('id', 'unknown')}")

        if 'share_link' in result:
            print(f"分享链接: {result['share_link']}")

    except Exception as e:
        print(f"\n❌ 发布失败: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

    # 清理临时文件
    print("\n🧹 清理临时文件...")
    for f in temp_images:
        if os.path.exists(f):
            os.remove(f)
    print("完成！")

if __name__ == '__main__':
    main()
