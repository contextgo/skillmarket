# 小红书自动化发布工具

> 一键生成小红书风格卡片并自动发布到小红书平台（模拟人工版）

## 快速开始

### 1. 安装依赖

```bash
cd /path/to/xiaohongshu-auto-publish

# Python依赖
pip install -r requirements.txt

# Node.js依赖
npm install

# 安装playwright浏览器
npx playwright install chromium
```

### 2. 配置Cookie

```bash
cp env.example.txt .env
# 编辑 .env 文件，填入你的小红书Cookie
```

### 3. 渲染卡片

```bash
# 生成小红书卡片
node scripts/render.js references/examples/content-example.md \
  -o ./output \
  -s xiaohongshu \
  -m auto-split
```

### 4. 发布笔记（模拟人工版 ⭐推荐）

```bash
# 使用模拟人工版 - 更安全，不易被检测
python scripts/publish_human.py \
  --title "杭州雏渐肥月嫂探店" \
  --desc "姐妹们，终于探店了传说中的杭州雏渐肥月嫂机构！..." \
  --images "output/cover.png,output/card_1.png,output/card_2.png,output/card_3.png,output/card_4.png" \
  --topics "杭州探店,雏渐肥月嫂,月嫂推荐,新手妈妈,产后恢复"

# 或使用普通版
python scripts/publish.py \
  --title "标题" \
  --desc "正文" \
  --images "图片"
```

## 版本对比

| 功能 | publish.py | publish_human.py |
|------|-----------|------------------|
| 基础发布 | ✅ | ✅ |
| 随机延迟 | ❌ | ✅ |
| 打字模拟 | ❌ | ✅ |
| 行为抖动 | ❌ | ✅ |
| 防检测机制 | ⚠️ | ✅✅ |

**推荐使用 publish_human.py**，模拟真人操作行为，降低被检测风险。

## 文件说明

```
├── SKILL.md              # 技能定义文件
├── README.md             # 使用说明
├── requirements.txt      # Python依赖
├── package.json         # Node.js依赖
├── env.example.txt      # Cookie配置示例
├── .env                 # Cookie配置（需手动创建）
├── scripts/
│   ├── render.js        # 卡片渲染脚本
│   ├── publish.py       # 普通发布脚本
│   ├── publish_human.py # 模拟人工版 ⭐推荐
│   └── publish_simple.py # 简化发布脚本
└── references/
    └── examples/
        └── content-example.md # 内容示例
```

## 功能特性

- 🎨 自动渲染Markdown为小红书风格卡片
- 📤 自动发布笔记到小红书
- 🏷️ 支持自定义话题标签
- 📸 支持1-9张图片
- 🤖 模拟人工行为，防检测

## 模拟人工行为说明

publish_human.py 版本模拟以下人类行为：

1. **随机延迟** - 每次操作间隔1-3秒
2. **打字速度** - 每秒3-5个字符
3. **行为抖动** - 操作时间有随机变化
4. **页面等待** - 加载等待1-3秒
5. **检查确认** - 发布前有确认环节

## 注意事项

1. Cookie有效期有限，过期后需重新获取
2. 建议每天发布不超过10篇
3. 内容需符合小红书社区规范
4. 图片建议使用1080x1440像素

## 示例输出

成功发布后返回：

```
🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉

✅✅✅ 发布成功！✅✅✅

📝 笔记ID: 69bb695e00000000220030f7
🔗 分享链接: https://www.xiaohongshu.com/discovery/item/69bb695e00000000220030f7

👀 查看发布结果...
  ✓ 发布完成！

🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉🎉
```
