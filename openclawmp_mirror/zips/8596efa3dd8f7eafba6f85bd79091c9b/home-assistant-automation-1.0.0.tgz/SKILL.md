---
name: home-assistant-automation
description: "Home Assistant automation and integration guide - smart home automation with YAML and UI"
version: 1.0.0
tags: ["home-assistant", "smart-home", "iot", "automation", "integration"]
---

# Home Assistant Automation Guide

Home Assistant is an open-source smart home platform that integrates with thousands of devices and services.

## Core Concepts

- **Entities**: Individual data points (sensor.temperature, light.living_room)
- **Devices**: Physical devices with one or more entities
- **Automations**: If-then rules triggered by events or states
- **Scripts**: Reusable sequences of actions
- **Scenes**: Predefined states for multiple entities

## Automation Example (YAML)

```yaml
automation:
  - alias: "Good Morning"
    trigger:
      - platform: time
        at: "07:00:00"
    condition:
      - condition: time
        weekday: ["mon", "tue", "wed", "thu", "fri"]
    action:
      - service: light.turn_on
        target:
          entity_id: light.bedroom
        data:
          brightness_pct: 50
          color_temp: 350
      - service: climate.set_temperature
        target:
          entity_id: climate.living_room
        data:
          temperature: 22
      - service: media_player.play_media
        target:
          entity_id: media_player.living_room
        data:
          media_content_id: "spotify:track:xxx"
          media_content_type: "music"
```

## Template Sensors

```yaml
template:
  - sensor:
      - name: "Energy Cost Today"
        unit_of_measurement: "USD"
        state: >
          {{ states('sensor.total_energy_kwh') | float * 0.12 }}
```

## Key Integrations

- **MQTT**: Custom sensor/switch via MQTT
- **Zigbee2MQTT**: Zigbee device support
- **ESPHome**: DIY sensor/switch with ESP32
- **Node-RED**: Visual automation builder
- **Google Home / Alexa**: Voice control

## Best Practices

- Use meaningful entity IDs (`sensor.living_room_temperature`)
- Organize automations with aliases
- Use input helpers for configurable values
- Set up automations in YAML (easier to version control)
- Use groups/views for dashboard organization
