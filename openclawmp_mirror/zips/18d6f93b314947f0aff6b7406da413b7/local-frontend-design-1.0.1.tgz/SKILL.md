# 本地前端设计Skill

**创建时间：** 2026-03-13
**创建原因：** ClawHub速率限制，临时创建本地Skill
**基于：** 老板推荐的frontend-design、interaction-design、impeccable、the stack等Skill理念

## 🎯 核心功能

### 1. 前端设计规范
- **设计系统**：色彩、字体、间距、圆角规范
- **组件库**：按钮、卡片、表单、表格等基础组件
- **响应式设计**：移动端、平板、桌面端适配
- **可访问性**：WCAG标准，支持屏幕阅读器等

### 2. 交互设计指南
- **用户体验**：用户流程、信息架构、交互逻辑
- **动效设计**：页面过渡、加载动画、微交互
- **反馈机制**：操作反馈、错误提示、成功确认
- **手势支持**：移动端手势、拖拽操作、滑动交互

### 3. 完美设计标准
- **视觉层次**：信息优先级、视觉焦点、阅读路径
- **品牌一致性**：品牌色、字体、图标、语气统一
- **细节优化**：像素完美、对齐、间距、对比度
- **情感设计**：情感化设计、愉悦体验、品牌情感

### 4. 技术栈指导
- **框架选择**：React/Vue/Svelte/Streamlit对比
- **工具链**：构建工具、包管理器、代码规范
- **性能优化**：加载优化、渲染优化、缓存策略
- **测试策略**：单元测试、集成测试、E2E测试

## 📋 投投是道V2.0应用指南

### 1. 数据可视化设计
```css
/* 图表配色 - 投投是道品牌色 */
--chart-primary: #1E40AF;
--chart-secondary: #3B82F6;
--chart-success: #10B981;
--chart-warning: #F59E0B;
--chart-danger: #EF4444;

/* 图表交互 */
.chart-hover { opacity: 0.8; transition: opacity 0.2s; }
.chart-selected { stroke-width: 3px; }
```

### 2. 交互功能设计
- **拖拽上传**：视觉反馈、进度显示、错误处理
- **实时预览**：即时更新、差异高亮、版本对比
- **风险检测**：风险等级可视化、详细报告、建议措施

### 3. 组件库设计
```python
# 投投是道品牌按钮组件
class BrandButton:
    """品牌按钮组件 - 支持主题色、大小、状态"""
    
    def __init__(self, text, variant="primary", size="medium"):
        self.text = text
        self.variant = variant  # primary/secondary/success/warning/danger
        self.size = size  # small/medium/large
        
    def render(self):
        # 根据品牌规范渲染按钮
        pass
```

### 4. 性能优化设计
- **懒加载**：图表、图片按需加载
- **代码分割**：按路由分割代码包
- **缓存策略**：数据缓存、组件缓存、API缓存
- **预加载**：用户可能访问的页面预加载

## 🛠️ 使用方式

### 1. 设计规范查询
```
# 查询品牌色
问：投投是道V2.0的主品牌色是什么？
答：#1E40AF（深蓝），用于导航栏、主要按钮、重要数据
```

### 2. 组件使用指导
```
# 创建品牌按钮
问：如何创建一个主要品牌按钮？
答：使用BrandButton组件，设置variant="primary"，size="medium"
```

### 3. 交互设计咨询
```
# 设计拖拽上传
问：拖拽上传应该有哪些视觉反馈？
答：1. 拖拽区域高亮 2. 文件数量显示 3. 上传进度条 4. 成功/失败提示
```

### 4. 技术决策支持
```
# 选择图表库
问：Plotly、Chart.js、ECharts哪个更适合？
答：Plotly最适合，因为：1. 功能丰富 2. 交互性强 3. Python集成好
```

## 📚 参考资源

### 1. 设计系统
- **色彩系统**：投投是道V2.0-UI设计语言文档.md
- **字体系统**：思源黑体为主，字号层级明确
- **间距规范**：8px基准，响应式布局

### 2. 组件示例
- **按钮组件**：/examples/components/button.py
- **卡片组件**：/examples/components/card.py
- **表单组件**：/examples/components/form.py

### 3. 交互示例
- **拖拽上传**：/examples/interactions/drag_drop.py
- **实时预览**：/examples/interactions/realtime_preview.py
- **动画效果**：/examples/interactions/animations.py

### 4. 性能示例
- **懒加载**：/examples/performance/lazy_load.py
- **代码分割**：/examples/performance/code_splitting.py
- **缓存策略**：/examples/performance/caching.py

## 🚀 立即应用

### 当前项目任务：
1. **数据可视化组件**：应用图表配色和交互设计
2. **复杂交互功能**：应用拖拽上传和实时预览设计
3. **组件库构建**：基于品牌规范创建可复用组件
4. **性能优化**：应用懒加载和缓存策略

### 执行流程：
```
需求分析 → 设计规范查询 → 组件选择 → 交互设计 → 性能优化 → 测试验证
```

## 📊 质量保证

### 设计审查清单：
- [ ] 符合品牌规范
- [ ] 用户体验优秀
- [ ] 交互逻辑合理
- [ ] 性能指标达标
- [ ] 可访问性良好
- [ ] 响应式适配

### 技术审查清单：
- [ ] 代码规范符合
- [ ] 无性能问题
- [ ] 无安全漏洞
- [ ] 测试覆盖充分
- [ ] 文档完整清晰

**此本地Skill将作为前端优化项目的设计指导，待ClawHub速率限制解除后安装官方Skill替换。**