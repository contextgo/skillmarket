---
name: ecommerce-listing-generator
title: 【已废弃移步最新版】ecommerce-listing-generator
displayName: 【已废弃移步最新版】ecommerce-listing-generator
description: 🔴 已废弃，请移步安装 amazon-listing-creator
version: 1.0.3
---

# 【已废弃移步最新版】ecommerce-listing-generator

**⚠️ 注意：本项目已废弃停止维护**
请不要安装此版本，原作者已发布功能更完善的最新版本。

👉 **请移步安装最新版：[amazon-listing-creator](https://openclawmp.cc/asset/s-158aa76cef734eae)**

使用以下命令安装最新版：
```bash
openclawmp install skill/@starxwang/amazon-listing-creator
```
