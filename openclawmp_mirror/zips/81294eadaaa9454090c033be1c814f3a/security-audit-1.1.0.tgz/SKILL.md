---
name: security-audit
description: Audit codebases and infrastructure for security issues. Use when scanning dependencies, secrets, OWASP risks, SSL/TLS, permissions, auth, authz, injection, XSS, CSRF, CORS, CSP, or deployment hardening. 触发词：security、vulnerability、audit、OWASP、XSS、SQL injection、CSRF、CORS、CSP、authentication、authorization、secrets。 
version: "1.1.0"
last_updated: "2026-04-15"
changelog: "- 强化审计流程、修复建议和输出标准"
metadata: {"clawdbot":{"emoji":"🔒","requires":{"anyBins":["npm","pip","git","openssl","curl"]},"os":["linux","darwin","win32"]}}
---

# Security Audit

## Goal
Find the highest-risk security problems first and give fixes that can actually be applied.

## Workflow

### Phase 1: Scope
- Identify what is being audited: code, infra, dependencies, auth, or config
- Start with the highest-risk surfaces

### Phase 2: Scan
- Check for secrets, injections, broken auth, XSS, CSRF, and dependency issues
- Separate confirmed issues from likely issues

### Phase 3: Verify
- Confirm each finding with code, config, or evidence
- Avoid guessing from one pattern alone

### Phase 4: Fix
- Provide the smallest safe fix
- Include verification steps or tests when possible

## Guardrails
- Do not mix confirmed and speculative findings
- Do not hide severity
- Do not recommend fixes that cannot be verified

## Success Criteria
- Findings are specific
- Severity is clear
- Fixes are practical
