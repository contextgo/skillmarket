---
name: time-series-forecasting
description: 时间序列预测：ARIMA、Prophet、LSTM、XGBoost、预训练模型
version: 1.0.0
---

# 时间序列预测方法库

## 经典
- ARIMA：平稳数据中短期（statsmodels）
- Holt-Winters：趋势+季节性
- Prophet：自动检测季节性，鲁棒

## ML
- XGBoost：lag/rolling/时间特征
- LSTM：长期依赖，需 >1000 数据

## 预训练
- TimesFM (Google)：零样本
- Chronos (Amazon)：零样本

## 选择
<100点 -> 指数平滑
100-1000 -> ARIMA/Prophet
1000+ -> XGBoost
多变量 -> LSTM/Transformer
冷启动 -> TimesFM/Chronos

## 评估
MAE + RMSE + MAPE + Direction Accuracy
