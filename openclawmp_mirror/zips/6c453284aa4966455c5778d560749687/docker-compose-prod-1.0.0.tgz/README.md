# Docker Compose 生产部署

## 必备配置
- restart: unless-stopped
- healthcheck (test + interval + retries)
- logging (max-size + max-file 防磁盘满)
- resources (limits + reservations)
- networks (前后端隔离)
- secrets (不用 .env 存密码)

## Watchtower 自动更新
image: containrrr/watchtower
command: --interval 300 --cleanup

## 备份策略
- 数据卷定期备份：docker run --rm -v data:/data -v backup:/backup alpine tar czf /backup/data.tar.gz /data
- compose 文件纳入 git 版本管理

## 监控
- cAdvisor + Prometheus + Grafana
- 告警：容器重启 > 3次/小时
