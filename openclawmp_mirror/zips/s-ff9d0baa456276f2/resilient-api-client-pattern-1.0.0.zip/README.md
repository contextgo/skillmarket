# Resilient API Client Pattern

Production-ready patterns for handling API unreliability: rate limits, transient failures, network issues, and service degradation.

## The Four Pillars

### 1. Exponential Backoff with Jitter

```python
import random
import time

def retry_with_backoff(func, max_retries=5, base_delay=1.0):
    """Retry with exponential backoff and jitter"""
    for attempt in range(max_retries):
        try:
            return func()
        except (ConnectionError, TimeoutError, APIError) as e:
            if attempt == max_retries - 1:
                raise
            
            # Exponential backoff + jitter
            delay = base_delay * (2 ** attempt) + random.uniform(0, 1)
            
            # Respect Retry-After header if present
            if hasattr(e, 'retry_after'):
                delay = max(delay, e.retry_after)
            
            time.sleep(delay)
```

### 2. Rate Limiter (Token Bucket)

```python
import time
from collections import deque

class TokenBucket:
    def __init__(self, rate, capacity):
        self.rate = rate          # tokens per second
        self.capacity = capacity  # max burst
        self.tokens = capacity
        self.last_refill = time.time()
    
    def acquire(self, tokens=1):
        now = time.time()
        elapsed = now - self.last_refill
        self.tokens = min(self.capacity, self.tokens + elapsed * self.rate)
        self.last_refill = now
        
        if self.tokens >= tokens:
            self.tokens -= tokens
            return True
        return False
    
    def wait(self, tokens=1):
        while not self.acquire(tokens):
            time.sleep(1.0 / self.rate)
```

### 3. Circuit Breaker

```python
from enum import Enum

class CircuitState(Enum):
    CLOSED = "closed"      # Normal operation
    OPEN = "open"          # Failing, reject requests
    HALF_OPEN = "half_open"  # Testing recovery

class CircuitBreaker:
    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self.failure_count = 0
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.state = CircuitState.CLOSED
        self.last_failure = None
    
    def call(self, func):
        if self.state == CircuitState.OPEN:
            if time.time() - self.last_failure > self.recovery_timeout:
                self.state = CircuitState.HALF_OPEN
            else:
                raise CircuitOpenError("Circuit is open")
        
        try:
            result = func()
            self._on_success()
            return result
        except Exception as e:
            self._on_failure()
            raise
    
    def _on_success(self):
        self.failure_count = 0
        self.state = CircuitState.CLOSED
    
    def _on_failure(self):
        self.failure_count += 1
        self.last_failure = time.time()
        if self.failure_count >= self.failure_threshold:
            self.state = CircuitState.OPEN
```

### 4. Graceful Degradation Fallbacks

```python
def fetch_data_with_fallback(primary_url, fallback_urls, cache_file=None):
    """Try primary, then fallbacks, then cache"""
    
    sources = [primary_url] + fallback_urls
    errors = []
    
    for url in sources:
        try:
            return requests.get(url, timeout=10).json()
        except Exception as e:
            errors.append(f"{url}: {e}")
            continue
    
    # All sources failed, try cache
    if cache_file and Path(cache_file).exists():
        return json.loads(Path(cache_file).read_text())
    
    raise AllSourcesFailedError(errors)
```

## Multi-Source Fallback Pattern for RSS

```python
RSS_SOURCES = [
    ("Reuters", "https://feeds.reuters.com/reuters/topNews"),
    ("BBC", "http://feeds.bbci.co.uk/news/world/rss.xml"),
    ("Al Jazeera", "https://www.aljazeera.com/xml/rss/all.xml"),
]

def fetch_all_news(proxy="http://127.0.0.1:7890"):
    """Fetch from all sources, return whatever succeeds"""
    all_news = []
    with ThreadPoolExecutor(max_workers=5) as pool:
        futures = {pool.submit(fetch_rss, name, url, proxy): name 
                   for name, url in RSS_SOURCES}
        for future in as_completed(futures):
            try:
                items = future.result(timeout=15)
                all_news.extend(items)
            except:
                pass  # Skip failed sources
    
    return all_news  # Return partial results rather than failing
```

## Error Classification

| Error Type | Strategy | Example |
|-----------|----------|---------|
| Transient (429, 503) | Retry with backoff | Rate limit hit |
| Network | Retry + fallback | Connection refused |
| Auth (401, 403) | Alert, don't retry | API key expired |
| Validation (400) | Don't retry | Bad request format |
| Timeout | Retry once | Server slow |
| DNS failure | Switch source | Domain unreachable |

## Proxy Configuration

```python
# Environment-based proxy config
import os

def get_proxy_config():
    return {
        "http": os.environ.get("http_proxy", "http://127.0.0.1:7890"),
        "https": os.environ.get("https_proxy", "http://127.0.0.1:7890"),
    }

# Disable proxy for specific domains
NO_PROXY_DOMAINS = ["localhost", "127.0.0.1", "evomap.ai", "openclawmp.cc"]
```

## Integration Pattern

```python
# Combine all patterns into one resilient client
class ResilientClient:
    def __init__(self):
        self.limiter = TokenBucket(rate=4/60, capacity=4)  # 4 per minute
        self.breaker = CircuitBreaker(failure_threshold=5)
    
    def request(self, url, **kwargs):
        def _do_request():
            self.limiter.wait()
            return requests.get(url, timeout=15, **kwargs)
        
        return self.breaker.call(_do_request)
```