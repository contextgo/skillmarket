# CRO, Paid Advertising & Email Marketing

## Table of Contents
1. [Landing Page CRO Elements](#landing-page-cro-elements)
2. [Funnel Optimization](#funnel-optimization)
3. [A/B Test Setup](#ab-test-setup)
4. [Paid Advertising Channel Strategy](#paid-advertising-channel-strategy)
5. [Email Sequence Types](#email-sequence-types)
6. [Referral Program Design](#referral-program-design)
7. [Free Tool Strategy](#free-tool-strategy)

---

## Landing Page CRO Elements

### 1. Value Proposition
- Clear headline (8–12 words)
- Subhead explaining the transformation
- Visual proof (screenshot or video)

### 2. Trust Signals
- Customer / press logos
- Real user testimonials
- Security badges
- Social proof numbers

### 3. CTA Optimization
- Action-oriented verb (never "Submit")
- High contrast color
- Above-the-fold placement

### 4. Friction Analysis
- Remove unnecessary form fields
- Enable auto-fill
- Clear, specific error messages

---

## Funnel Optimization

### Signup Flow
- Minimize fields (email only first)
- Social auth options
- Progress indicators
- Clear value proposition at each step

### Form CRO
- Progressive profiling
- Inline validation
- Smart defaults
- Auto-save drafts

### Onboarding
- Identify the Aha moment and accelerate time-to-value
- Progress tracking
- Feature discovery prompts
- Milestone celebrations

---

## A/B Test Setup

- Test one variable at a time — never combine changes
- Calculate required sample size before starting (use a significance calculator)
- Confidence threshold: ≥95%
- Hypothesis format: "If we [change], [metric] will improve because [reason]"
- Document all results including failures — negative data is still data

---

## Paid Advertising Channel Strategy

### Google Ads
- Brand terms protection (prevent competitor bidding)
- Competitor targeting
- Solution-intent keywords
- RLSA remarketing lists

### Meta / Facebook Ads
- Detailed targeting
- Creative testing (3–5 variants minimum)
- Lookalike audiences from best customers
- Retargeting funnel layers

### LinkedIn Ads
- Job title / function targeting
- Company size filtering
- Industry filters
- B2B intent signals

### Analytics & Tracking Infrastructure
- UTM parameters (consistent naming convention)
- GA4 events configured for goals
- GTM container deployed
- Conversion pixels verified

---

## Email Sequence Types

| Sequence | Trigger | Core Goal | Duration |
|----------|---------|-----------|----------|
| Welcome Series | Sign up | Build relationship + guide to Aha moment | 7 days |
| Nurture Sequence | Post-welcome | Educate and build trust | 2–3 weeks |
| Onboarding Sequence | First login | Feature education, drive activation | Behavior-triggered |
| Win-Back Sequence | Churned user | Re-activate | 3–5 emails |
| Re-engagement Sequence | Dormant subscriber | Clean list or re-activate | 2–3 emails |

---

## Referral Program Design

### Viral Mechanics
- Two-sided rewards (referrer + referred)
- Milestone celebration triggers
- Fraud detection rules
- Dedicated nurture sequence for referred users

### Key Design Decisions
- Reward type: cash / credits / feature unlock
- Reward timing: on signup or on first payment
- Share channels: link / email / social

---

## Free Tool Strategy

### Tool Categories
- Calculators (ROI, pricing, budget)
- Analyzers (SEO checker, copy scorer)
- Generators (headline, template)
- Checklists (audit, pre-launch)
- Templates (documents, workflows)

### SEO Value
- Target high-volume keywords with tool pages
- Shareable results pages attract backlinks naturally
- Tools themselves earn inbound links

### Conversion Path
- Tool results page → signup prompt
- Email results delivery → grows email list
- Unlock advanced features → paid upgrade
