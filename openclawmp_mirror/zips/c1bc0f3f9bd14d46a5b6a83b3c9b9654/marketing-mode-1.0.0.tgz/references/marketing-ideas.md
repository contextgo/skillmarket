# Marketing Ideas — 140+ Proven Approaches

## Table of Contents
1. [Content & SEO](#content--seo)
2. [Competitor & Comparison](#competitor--comparison)
3. [Free Tools & Engineering](#free-tools--engineering)
4. [Paid Advertising](#paid-advertising)
5. [Social Media & Community](#social-media--community)
6. [Email Marketing](#email-marketing)
7. [Partnerships & Programs](#partnerships--programs)
8. [Events & Speaking](#events--speaking)
9. [PR & Media](#pr--media)
10. [Launches & Promotions](#launches--promotions)
11. [Product-Led Growth](#product-led-growth)
12. [Unconventional & Creative](#unconventional--creative)
13. [Platforms & Marketplaces](#platforms--marketplaces)
14. [Developer & Technical](#developer--technical)
15. [Launch Strategy (5-Phase)](#launch-strategy-5-phase)
16. [Pricing Strategy](#pricing-strategy)

---

## Content & SEO
- Easy Keyword Ranking
- SEO Audit
- Glossary Marketing
- Programmatic SEO
- Content Repurposing
- Proprietary Data Content
- Internal Linking
- Content Refreshing
- Knowledge Base SEO
- Parasite SEO

## Competitor & Comparison
- Competitor Comparison Pages
- Marketing Jiu-Jitsu
- Competitive Ad Research

## Free Tools & Engineering
- Side Projects as Marketing
- Engineering as Marketing
- Importers as Marketing
- Quiz Marketing
- Calculator Marketing
- Chrome Extensions
- Microsites
- Scanners
- Public APIs

## Paid Advertising
- Podcast Advertising
- Pre-targeting Ads
- Facebook / Instagram / Twitter(X) / LinkedIn / Reddit / Quora / Google / YouTube Ads
- Cross-Platform Retargeting
- Click-to-Messenger Ads

## Social Media & Community
- Community Marketing
- Quora / Reddit / LinkedIn / Instagram / X Audience Building
- Short Form Video
- Engagement Pods
- Comment Marketing

## Email Marketing
- Mistake Email Marketing
- Reactivation Emails
- Founder Welcome Email
- Dynamic Email Capture
- Monthly Newsletters
- Inbox Placement
- Onboarding Emails
- Win-back Emails
- Trial Reactivation

## Partnerships & Programs
- Affiliate Discovery Through Backlinks
- Influencer Whitelisting
- Reseller Programs
- Expert Networks
- Newsletter Swaps
- Article Quotes
- Pixel Sharing
- Shared Slack Channels
- Affiliate Program
- Integration Marketing
- Community Sponsorship

## Events & Speaking
- Live Webinars
- Virtual Summits
- Roadshows
- Local Meetups / Meetup Sponsorship
- Conference Speaking / Conferences / Conference Sponsorship

## PR & Media
- Media Acquisitions as Marketing
- Press Coverage
- Fundraising PR
- Documentaries

## Launches & Promotions
- Black Friday / New Year Promotions
- Product Hunt Launch + Alternatives
- Early-Access Referrals / Early Access Pricing
- Twitter Giveaways / Giveaways / Vacation Giveaways
- Lifetime Deals

## Product-Led Growth
- Powered By Marketing
- Free Migrations / Contract Buyouts
- One-Click Registration
- In-App Upsells
- Newsletter Referrals
- Viral Loops
- Offboarding Flows
- Concierge Setup
- Onboarding Optimization

## Unconventional & Creative
- Awards / Challenges / Reality TV / Controversy as Marketing
- Moneyball / Curation / Grants as Marketing
- Product Competitions
- Cameo Marketing
- OOH Advertising / Marketing Stunts / Guerrilla Marketing / Humor Marketing

## Platforms & Marketplaces
- Open Source as Marketing
- App Store Optimization / App Marketplaces
- YouTube Reviews / YouTube Channel
- Review Sites
- Live Audio
- International Expansion / Price Localization

## Developer & Technical
- Investor Marketing
- Certifications
- Support as Marketing
- Developer Relations
- Two-Sided Referrals
- Podcast Tours
- Customer Language

---

## Launch Strategy (5-Phase)

| Phase | Name | Core Actions |
|-------|------|-------------|
| Phase 1 | Internal | Use product internally, find bugs, build initial case studies |
| Phase 2 | Alpha (Private Beta) | Invite existing customers, gather feedback, build waitlist |
| Phase 3 | Beta (Public Preview) | Invite codes, refine pricing, build SEO content |
| Phase 4 | Early Access | Open public waitlist, reach out to partners and press |
| Phase 5 | Full Launch | General availability, full promotional push, ongoing optimization |

---

## Pricing Strategy

### Research Methods
- Competitor pricing analysis
- Value-based pricing models
- Willingness-to-pay surveys
- A/B testing for optimization

### Tier Structure
- Free tier (awareness)
- Pro tier (core value)
- Enterprise tier (scale + support)

### Value Metrics
- Per-seat pricing
- Usage-based pricing
- Feature-based tiers
- Outcome-based pricing

### Monetization Optimization
- Annual vs. monthly discounts
- Upgrade paths
- Churn prevention pricing
- Revenue recovery strategies
