# Marketing Psychology — 25 Mental Models

## Table of Contents
1. [Decision & Cognitive Bias](#decision--cognitive-bias)
2. [Social Influence](#social-influence)
3. [Behavioral Design](#behavioral-design)
4. [Mental Frameworks](#mental-frameworks)

---

## Decision & Cognitive Bias

### Anchoring Effect
The first number presented heavily influences all subsequent judgments.
**Application**: Show a higher price first (original, competitor, enterprise tier) to anchor expectations before revealing the target price.

### Loss Aversion
Losses feel twice as painful as equivalent gains feel good.
**Application**: "Don't miss out" beats "You could gain." Frame messaging around what users will lose, not just what they'll gain.

### Paradox of Choice
Too many options overwhelm and cause decision paralysis.
**Application**: Offer three pricing tiers max. Always recommend a single "best for most" option.

### Status-Quo Bias
People prefer their current state. Change feels risky.
**Application**: Reduce migration friction — "Import in one click," "Keep all your data."

### Default Effect
People accept pre-selected options. Defaults are powerful.
**Application**: Pre-select the plan you want customers to choose. Opt-out beats opt-in.

### Endowment Effect
People value things more once they feel ownership.
**Application**: Free trials and freemium models let customers "own" the product before paying.

### IKEA Effect
People value things they helped create more highly.
**Application**: Let users customize, configure, and build. Their investment increases commitment.

### Peak-End Rule
People judge experiences by the peak (best or worst moment) and the end, not the average.
**Application**: Design memorable peak moments and strong endings (thank-you pages, completion states).

### Zeigarnik Effect
Unfinished tasks occupy the mind and create tension.
**Application**: "You're 80% done" progress bars; incomplete profile prompts; abandoned cart emails.

### Prospect Theory
People avoid actions that might cause regret.
**Application**: Money-back guarantees and free trials reduce regret fear. Address objections directly.

---

## Social Influence

### Social Proof
People follow what others are doing. Popularity signals quality.
**Application**: Show customer counts, testimonials, "X people signed up this week" indicators.

### Reciprocity
Give first. People feel obligated to return favors.
**Application**: Free content, tools, and freemium models create a sense of reciprocal obligation.

### Commitment & Consistency
Once people commit to something small, they want to stay consistent.
**Application**: Start with a small commitment (email signup) → leads to larger ones (paid subscription).

### Mere Exposure Effect
Familiarity breeds liking. Consistent presence builds preference.
**Application**: Repeated cross-channel exposure creates comfort and trust over time.

### Scarcity & Urgency
Limited availability increases perceived value.
**Application**: Limited-time offers, low-stock warnings. Only use when genuine — fake scarcity destroys trust.

---

## Behavioral Design

### BJ Fogg Behavior Model
Behavior = Motivation × Ability × Trigger
**Application**: Simultaneously raise motivation (value prop), lower difficulty (reduce friction), and add a trigger (CTA).

### Hick's Law
Decision time increases with the number of options.
**Application**: One clear CTA per page beats three. Fewer form fields = higher conversion.

### AIDA Funnel
Attention → Interest → Desire → Action
**Application**: Structure pages to move through each stage. Capture attention before building desire.

### Pareto Principle (80/20)
80% of results come from 20% of efforts.
**Application**: Find the channels driving most results. Cut or reduce the rest.

### Law of Diminishing Returns
Additional investment yields progressively smaller gains past a certain point.
**Application**: The 10th blog post won't have the same impact as the first. Diversify channels accordingly.

---

## Mental Frameworks

### First Principles
Break problems down to basic truths. Don't copy competitors — ask "why" repeatedly to find root causes.
**Application**: Don't do content marketing just because competitors do. Ask why, what problem it solves, and whether a better solution exists.

### Jobs to Be Done (JTBD)
People "hire" products to get a job done. Focus on outcomes, not features.
**Application**: A drill buyer wants a hole, not a drill. Frame messaging around the job accomplished.

### Circle of Competence
Know what you're good at and stay within it. Double down on genuine expertise.
**Application**: Don't chase every channel. Focus on where you have real competitive advantage.

### Inversion
Ask what would guarantee failure, then avoid those things.
**Application**: List everything that would make a campaign fail, then systematically prevent each one.

### Occam's Razor
Simpler explanations are usually correct.
**Application**: If conversions dropped, check the obvious first (broken form, slow page) before complex attribution analysis.
