# SEO & Content Frameworks

## Table of Contents
1. [SEO Audit Priority Order](#seo-audit-priority-order)
2. [Technical SEO Checklist](#technical-seo-checklist)
3. [Programmatic SEO — 12 Playbooks](#programmatic-seo--12-playbooks)
4. [Schema Markup Types](#schema-markup-types)
5. [Copywriting Frameworks](#copywriting-frameworks)
6. [Copy Editing — 7 Sweeps](#copy-editing--7-sweeps)
7. [Social Content Strategy](#social-content-strategy)

---

## SEO Audit Priority Order

Execute in this order — do not reorder:

1. **Crawlability & Indexation** — Can Google find and index your pages?
2. **Technical Foundations** — Is the site fast and functional?
3. **On-Page Optimization** — Is content optimized?
4. **Content Quality** — Does it deserve to rank?
5. **Authority & Links** — Does it have credibility?

---

## Technical SEO Checklist

### Crawlability
- Robots.txt not blocking important pages
- XML sitemap accessible and updated
- Site architecture within 3 clicks of homepage
- No orphan pages

### Indexation
- No accidental noindex on important pages
- Proper canonical tags (self-referencing)
- No redirect chains
- No soft 404s

### Core Web Vitals
- LCP < 2.5s
- INP < 200ms
- CLS < 0.1
- Server response time optimized
- Images optimized and compressed

### On-Page
- Title tags optimized (≤60 chars, keyword near front)
- Meta descriptions compelling (≤155 chars)
- Header hierarchy correct (H1 → H2 → H3)
- Internal linking to priority pages

### E-E-A-T
- Author expertise clearly demonstrated
- Clear sourcing and citations
- Content regularly updated
- Accurate and comprehensive information

---

## Programmatic SEO — 12 Playbooks

| # | Type | Description |
|---|------|-------------|
| 1 | Location Pages | City + keyword targeting |
| 2 | Comparison Pages | Product + alternative/competitor |
| 3 | Integration Pages | Tool + integration targets |
| 4 | Use Case Pages | Solution + use case |
| 5 | Problem Pages | Pain point + solution |
| 6 | Industry Pages | Industry + keyword targets |
| 7 | Review/Alternatives Pages | Competitor alternatives |
| 8 | Calculator/Generator Pages | Tools with keyword targets |
| 9 | Template Pages | Document templates for keywords |
| 10 | Glossary Pages | Industry terms explained |
| 11 | Checklist Pages | How-to guides as checklists |
| 12 | Quiz/Assessment Pages | Interactive tools |

---

## Schema Markup Types

- Organization schema
- Product / Service schema
- FAQPage schema
- HowTo schema
- Review / BreadcrumbList schema
- LocalBusiness schema

---

## Copywriting Frameworks

### AIDA
**Attention → Interest → Desire → Action**
Best for: Landing pages, email subject lines, ad copy

### PAS
**Problem → Agitation → Solution**
Best for: Social posts, short-form video scripts, email body copy

### Before / After / Bridge
**Current state → Problem → Your solution → Transformation**
Best for: Case studies, product explainer videos

### ACCA
**Awareness → Comprehension → Conviction → Action**
Best for: Educational content, long-form sales pages

### Hero's Journey
**Customer as hero on a journey — your product is the guide**
Best for: Brand stories, founder stories, case studies

---

## Copy Editing — 7 Sweeps

| Sweep | Focus | Key Question |
|-------|-------|-------------|
| 1 | Clarity | Can a reader grasp the main point in 5 seconds? |
| 2 | Voice | Does it match the brand tone? |
| 3 | Proof | Is every claim backed by evidence? |
| 4 | Impact | What's the strongest line? Is it at the top? |
| 5 | Emotion | Does it trigger the intended feeling? |
| 6 | Format | Is it scannable? Headers, bullets, bold? |
| 7 | Authenticity | Does it sound like a real human wrote it? |

---

## Social Content Strategy

### Hook Templates
- **Question hook**: "Have you noticed..."
- **Number hook**: "5 ways to double your conversion rate"
- **Story hook**: "6 months ago we almost shut down..."
- **Contrast hook**: "Most people do X. Winners do Y."
- **Controversy hook**: "[Popular belief] is wrong. Here's why."

### Platform Strategy

| Platform | Content Style | Best Format |
|----------|--------------|-------------|
| LinkedIn | Professional, thought leadership | Long-form posts, opinion pieces |
| X/Twitter | Concise, threads | Tweet threads, hot takes |
| Instagram | Visual + caption | Carousels, Reels |
| TikTok/Reels | Entertainment + education | Short-form video |
| YouTube | In-depth + shorts | Long videos + Shorts |
