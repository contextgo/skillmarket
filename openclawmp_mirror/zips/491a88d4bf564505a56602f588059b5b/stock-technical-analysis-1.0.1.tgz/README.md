# 技术分析 (stock-technical-analysis)

技术分析 Skill，K线形态识别、技术指标计算、趋势分析。

## 功能

- K线形态识别（三只乌鸦、锤子线等）
- 技术指标计算（MACD、KDJ、RSI、BOLL等）
- 趋势分析
- 支撑压力位计算

## 使用

```bash
# K线形态识别
python main.py pattern 000001 --pattern three_black_crows

# 技术指标
python main.py indicator 000001 --type MACD

# 趋势分析
python main.py trend 000001

# 支撑压力
python main.py support 000001
```

## 依赖

- akshare
- pandas
- numpy

## License

MIT
