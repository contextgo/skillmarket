#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
技术分析工具
K线形态识别、技术指标计算、趋势分析
"""

import akshare as ak
import numpy as np
import pandas as pd


class TechnicalAnalyzer:
    """技术分析器"""
    
    def __init__(self):
        pass
    
    def get_kline(self, code, days=60):
        """获取K线数据"""
        try:
            df = ak.stock_zh_a_hist(symbol=code, period="daily", start_date="", end_date="", adjust="qfq")
            if df is not None and not df.empty:
                return df.tail(days)
        except Exception as e:
            print(f"获取K线失败: {e}")
        return None
    
    def identify_pattern(self, code, pattern_type="all"):
        """
        识别K线形态
        
        Args:
            code: 股票代码
            pattern_type: 形态类型 (three_black_crows/hammer/doji/all)
            
        Returns:
            dict: 形态识别结果
        """
        df = self.get_kline(code, days=30)
        if df is None:
            return None
        
        try:
            patterns = []
            
            # 获取最近3天数据
            recent = df.tail(3)
            
            # 三只乌鸦 (连续3天阴线，且每天收盘价低于前一天)
            if pattern_type in ["three_black_crows", "all"]:
                if len(recent) >= 3:
                    c1 = recent.iloc[-3]
                    c2 = recent.iloc[-2]
                    c3 = recent.iloc[-1]
                    
                    if (c1['收盘'] < c1['开盘'] and 
                        c2['收盘'] < c2['开盘'] and 
                        c3['收盘'] < c3['开盘'] and
                        c2['收盘'] < c1['收盘'] and
                        c3['收盘'] < c2['收盘']):
                        patterns.append("三只乌鸦 (看跌)")
            
            # 锤子线 (下影线长，实体小)
            if pattern_type in ["hammer", "all"]:
                last = recent.iloc[-1]
                body = abs(last['收盘'] - last['开盘'])
                lower_shadow = min(last['开盘'], last['收盘']) - last['最低']
                
                if lower_shadow > 2 * body and body > 0:
                    patterns.append("锤子线 (看涨)")
            
            # 十字星 (开盘价≈收盘价)
            if pattern_type in ["doji", "all"]:
                last = recent.iloc[-1]
                body = abs(last['收盘'] - last['开盘'])
                avg_price = (last['最高'] + last['最低']) / 2
                
                if body < avg_price * 0.001:  # 实体小于平均价格的0.1%
                    patterns.append("十字星 (变盘信号)")
            
            return {
                "code": code,
                "patterns": patterns if patterns else ["无明显形态"],
                "recent_trend": self._get_trend(df.tail(5))
            }
        except Exception as e:
            print(f"形态识别失败: {e}")
            return None
    
    def _get_trend(self, df):
        """获取趋势方向"""
        if len(df) < 2:
            return "unknown"
        
        first_close = df.iloc[0]['收盘']
        last_close = df.iloc[-1]['收盘']
        change = (last_close - first_close) / first_close * 100
        
        if change > 5:
            return f"上涨 {change:.2f}%"
        elif change < -5:
            return f"下跌 {abs(change):.2f}%"
        else:
            return f"震荡 {change:.2f}%"
    
    def calculate_indicator(self, code, indicator_type="MACD"):
        """
        计算技术指标
        
        Args:
            code: 股票代码
            indicator_type: 指标类型 (MACD/KDJ/RSI/BOLL)
            
        Returns:
            dict: 指标计算结果
        """
        df = self.get_kline(code, days=60)
        if df is None:
            return None
        
        try:
            closes = df['收盘'].values
            
            if indicator_type == "MACD":
                return self._calc_macd(closes)
            elif indicator_type == "KDJ":
                return self._calc_kdj(df)
            elif indicator_type == "RSI":
                return self._calc_rsi(closes)
            elif indicator_type == "BOLL":
                return self._calc_boll(closes)
            else:
                return {"error": f"不支持的指标类型: {indicator_type}"}
        except Exception as e:
            print(f"指标计算失败: {e}")
            return None
    
    def _calc_macd(self, closes):
        """计算MACD"""
        exp1 = pd.Series(closes).ewm(span=12, adjust=False).mean()
        exp2 = pd.Series(closes).ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        hist = macd - signal
        
        return {
            "type": "MACD",
            "macd": round(macd.iloc[-1], 3),
            "signal": round(signal.iloc[-1], 3),
            "hist": round(hist.iloc[-1], 3),
            "signal_text": "金叉" if hist.iloc[-1] > 0 and hist.iloc[-2] <= 0 else "死叉" if hist.iloc[-1] < 0 and hist.iloc[-2] >= 0 else "中性"
        }
    
    def _calc_kdj(self, df):
        """计算KDJ"""
        low_list = df['最低'].rolling(window=9, min_periods=9).min()
        high_list = df['最高'].rolling(window=9, min_periods=9).max()
        rsv = (df['收盘'] - low_list) / (high_list - low_list) * 100
        
        K = rsv.ewm(com=2, adjust=False).mean()
        D = K.ewm(com=2, adjust=False).mean()
        J = 3 * K - 2 * D
        
        return {
            "type": "KDJ",
            "K": round(K.iloc[-1], 2),
            "D": round(D.iloc[-1], 2),
            "J": round(J.iloc[-1], 2),
            "signal_text": "超买" if J.iloc[-1] > 80 else "超卖" if J.iloc[-1] < 20 else "中性"
        }
    
    def _calc_rsi(self, closes, period=14):
        """计算RSI"""
        deltas = np.diff(closes)
        gains = deltas[deltas > 0].sum() / len(deltas)
        losses = -deltas[deltas < 0].sum() / len(deltas)
        
        if losses == 0:
            rsi = 100
        else:
            rs = gains / losses
            rsi = 100 - (100 / (1 + rs))
        
        return {
            "type": "RSI",
            "rsi": round(rsi, 2),
            "signal_text": "超买" if rsi > 70 else "超卖" if rsi < 30 else "中性"
        }
    
    def _calc_boll(self, closes, period=20):
        """计算布林带"""
        ma = np.mean(closes[-period:])
        std = np.std(closes[-period:])
        
        upper = ma + 2 * std
        lower = ma - 2 * std
        
        return {
            "type": "BOLL",
            "upper": round(upper, 2),
            "middle": round(ma, 2),
            "lower": round(lower, 2),
            "position": "上轨附近" if closes[-1] > upper * 0.98 else "下轨附近" if closes[-1] < lower * 1.02 else "中轨附近"
        }
    
    def analyze_trend(self, code):
        """
        趋势分析
        
        Args:
            code: 股票代码
            
        Returns:
            dict: 趋势分析结果
        """
        df = self.get_kline(code, days=60)
        if df is None:
            return None
        
        try:
            closes = df['收盘'].values
            
            # 计算均线
            ma5 = np.mean(closes[-5:])
            ma10 = np.mean(closes[-10:])
            ma20 = np.mean(closes[-20:])
            
            current = closes[-1]
            
            # 判断趋势
            trend = "上涨" if ma5 > ma10 > ma20 else "下跌" if ma5 < ma10 < ma20 else "震荡"
            
            # 计算涨跌幅
            change_5d = (closes[-1] - closes[-6]) / closes[-6] * 100 if len(closes) >= 6 else 0
            change_20d = (closes[-1] - closes[-21]) / closes[-21] * 100 if len(closes) >= 21 else 0
            
            return {
                "code": code,
                "current_price": round(current, 2),
                "ma5": round(ma5, 2),
                "ma10": round(ma10, 2),
                "ma20": round(ma20, 2),
                "trend": trend,
                "change_5d": f"{change_5d:.2f}%",
                "change_20d": f"{change_20d:.2f}%",
                "signal": "多头排列" if ma5 > ma10 > ma20 else "空头排列" if ma5 < ma10 < ma20 else "均线纠缠"
            }
        except Exception as e:
            print(f"趋势分析失败: {e}")
            return None
    
    def calculate_support_resistance(self, code):
        """
        计算支撑压力位
        
        Args:
            code: 股票代码
            
        Returns:
            dict: 支撑压力位
        """
        df = self.get_kline(code, days=60)
        if df is None:
            return None
        
        try:
            highs = df['最高'].values
            lows = df['最低'].values
            
            # 简单计算近期高低点
            recent_highs = sorted(highs[-20:], reverse=True)[:3]
            recent_lows = sorted(lows[-20:])[:3]
            
            current = df['收盘'].iloc[-1]
            
            return {
                "code": code,
                "current_price": round(current, 2),
                "resistance_1": round(recent_highs[0], 2),
                "resistance_2": round(recent_highs[1], 2) if len(recent_highs) > 1 else None,
                "support_1": round(recent_lows[0], 2),
                "support_2": round(recent_lows[1], 2) if len(recent_lows) > 1 else None,
            }
        except Exception as e:
            print(f"支撑压力计算失败: {e}")
            return None


def main():
    """CLI 入口"""
    import fire
    
    analyzer = TechnicalAnalyzer()
    
    def pattern(code, pattern_type="all"):
        """K线形态识别"""
        result = analyzer.identify_pattern(code, pattern_type)
        if result:
            print(f"股票: {result['code']}")
            print(f"识别形态: {', '.join(result['patterns'])}")
            print(f"近期趋势: {result['recent_trend']}")
        else:
            print("形态识别失败")
    
    def indicator(code, type="MACD"):
        """技术指标"""
        result = analyzer.calculate_indicator(code, type)
        if result:
            for k, v in result.items():
                print(f"{k}: {v}")
        else:
            print("指标计算失败")
    
    def trend(code):
        """趋势分析"""
        result = analyzer.analyze_trend(code)
        if result:
            for k, v in result.items():
                print(f"{k}: {v}")
        else:
            print("趋势分析失败")
    
    def support(code):
        """支撑压力位"""
        result = analyzer.calculate_support_resistance(code)
        if result:
            for k, v in result.items():
                print(f"{k}: {v}")
        else:
            print("计算失败")
    
    fire.Fire({
        "pattern": pattern,
        "indicator": indicator,
        "trend": trend,
        "support": support,
    })


if __name__ == "__main__":
    main()
