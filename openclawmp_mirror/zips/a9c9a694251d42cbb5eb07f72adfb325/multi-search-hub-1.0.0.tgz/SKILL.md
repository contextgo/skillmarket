---
name: multi-search-hub
description: 多搜索引擎聚合搜索中心，支持同时查询 Google、Bing、Baidu、DuckDuckGo、WolframAlpha、Brave Search 等多个搜索引擎，自动去重排序，支持中英文查询、高级搜索语法、时间范围过滤、结果缓存、历史管理和多格式导出。
---

# 多搜索引擎聚合搜索中心 (Multi-Search Hub)

> 作者：知白守黑1024

## 概述

多搜索引擎聚合搜索中心是一个强大的搜索增强工具，能够同时从多个搜索引擎获取结果，通过智能去重和相关性排序，为用户提供更全面、更准确的搜索体验。支持中英文双语查询、高级搜索操作符、时间范围过滤、结果缓存、搜索历史管理和多格式导出。

---

## 核心能力

### 1. 多搜索引擎聚合查询

本工具支持以下搜索引擎的聚合查询：

| 搜索引擎 | 特点 | 适用场景 |
|---------|------|---------|
| Google | 全球最大搜索引擎，索引最全 | 通用搜索、英文内容 |
| Bing | 微软搜索引擎，API 稳定 | 英文搜索、新闻搜索 |
| Baidu | 中文搜索引擎，中文内容丰富 | 中文搜索、国内内容 |
| DuckDuckGo | 隐私保护搜索引擎 | 隐私搜索、无追踪 |
| WolframAlpha | 计算知识引擎 | 数学计算、科学知识 |
| Brave Search | 独立索引的隐私搜索引擎 | 隐私搜索、无广告 |

### 2. 搜索引擎 API 调用方式

#### 2.1 使用 web_search API 进行搜索

当用户发起搜索请求时，优先使用内置的 `web_search` API：

```typescript
// 使用 web_search API 进行搜索
// 调用方式：通过 web_search 工具发起搜索查询
// 参数说明：
//   - query: 搜索关键词（支持中文和英文）
//   - num_results: 返回结果数量（默认 10）
//   - recency_days: 时间范围过滤（天）
```

#### 2.2 使用 curl 调用搜索引擎 API

对于需要更精细控制的场景，可以使用 curl 直接调用各搜索引擎的 API：

**Google Custom Search API:**
```bash
curl -s "https://www.googleapis.com/customsearch/v1?key=${GOOGLE_API_KEY}&cx=${GOOGLE_CSE_ID}&q=${QUERY}&num=10" \
  | python3 -c "import sys,json; data=json.load(sys.stdin); [print(f'{i+1}. {item[\"title\"]}\n   {item[\"link\"]}\n   {item.get(\"snippet\",\"\")}\n') for i,item in enumerate(data.get('items',[]))]"
```

**Bing Web Search API:**
```bash
curl -s "https://api.bing.microsoft.com/v7.0/search?q=${QUERY}&count=10&offset=0" \
  -H "Ocp-Apim-Subscription-Key: ${BING_API_KEY}" \
  | python3 -c "import sys,json; data=json.load(sys.stdin); [print(f'{i+1}. {item[\"name\"]}\n   {item[\"url\"]}\n   {item[\"snippet\"]}\n') for i,item in enumerate(data.get('webPages',{}).get('value',[]))]"
```

**DuckDuckGo (通过 HTML 解析):**
```bash
curl -s "https://html.duckduckgo.com/html/?q=${QUERY}" \
  | python3 -c "
import sys, re
html = sys.stdin.read()
results = re.findall(r'class=\"result__a\"[^>]*>(.*?)</a>.*?class=\"result__snippet\"[^>]*>(.*?)</a>', html, re.DOTALL)
for i, (title, snippet) in enumerate(results[:10]):
    title = re.sub(r'<[^>]+>', '', title)
    snippet = re.sub(r'<[^>]+>', '', snippet)
    print(f'{i+1}. {title}\n   {snippet}\n')
"
```

**Brave Search API:**
```bash
curl -s "https://api.search.brave.com/res/v1/web/search?q=${QUERY}&count=10" \
  -H "X-Subscription-Token: ${BRAVE_API_KEY}" \
  -H "Accept: application/json" \
  | python3 -c "import sys,json; data=json.load(sys.stdin); [print(f'{i+1}. {item[\"title\"]}\n   {item[\"url\"]}\n   {item.get(\"description\",\"\")}\n') for i,item in enumerate(data.get('web',{}).get('results',[]))]"
```

**WolframAlpha API:**
```bash
curl -s "https://api.wolframalpha.com/v2/query?input=${QUERY}&format=plaintext&output=JSON&appid=${WOLFRAM_APP_ID}" \
  | python3 -c "
import sys,json
data=json.load(sys.stdin)
pods = data.get('queryresult',{}).get('pods',[])
for pod in pods:
    for sub in pod.get('subpods',[]):
        text = sub.get('plaintext','')
        if text:
            print(f'[{pod.get(\"title\",\"\")}] {text}')
"
```

---

### 3. 聚合搜索流程

当用户发起聚合搜索时，按照以下流程执行：

#### Step 1: 查询预处理

```python
# 查询预处理流程
def preprocess_query(query: str) -> dict:
    """
    预处理用户查询，提取高级搜索参数
    """
    result = {
        "clean_query": query,
        "search_operators": {},
        "time_range": None,
        "language_hint": None
    }
    
    # 检测语言
    chinese_chars = sum(1 for c in query if '\u4e00' <= c <= '\u9fff')
    if chinese_chars > len(query) * 0.3:
        result["language_hint"] = "zh"
        # 中文查询优先使用 Baidu
    else:
        result["language_hint"] = "en"
    
    # 提取高级搜索操作符
    # site: 限定域名
    if "site:" in query:
        domain = query.split("site:")[1].split()[0]
        result["search_operators"]["site"] = domain
        result["clean_query"] = query.replace(f"site:{domain}", "").strip()
    
    # filetype: 限定文件类型
    if "filetype:" in query:
        ftype = query.split("filetype:")[1].split()[0]
        result["search_operators"]["filetype"] = ftype
        result["clean_query"] = query.replace(f"filetype:{ftype}", "").strip()
    
    # intitle: 标题包含
    if "intitle:" in query:
        title_kw = query.split("intitle:")[1].split()[0]
        result["search_operators"]["intitle"] = title_kw
        result["clean_query"] = query.replace(f"intitle:{title_kw}", "").strip()
    
    # inurl: URL 包含
    if "inurl:" in query:
        url_kw = query.split("inurl:")[1].split()[0]
        result["search_operators"]["inurl"] = url_kw
    
    # intext: 正文包含
    if "intext:" in query:
        text_kw = query.split("intext:")[1].split()[0]
        result["search_operators"]["intext"] = text_kw
    
    # 时间范围过滤
    time_keywords = {
        "过去一小时": "h1",
        "过去一天": "d1",
        "过去一周": "w1",
        "过去一月": "m1",
        "过去一年": "y1",
        "past hour": "h1",
        "past day": "d1",
        "past week": "w1",
        "past month": "m1",
        "past year": "y1"
    }
    query_lower = query.lower()
    for keyword, range_val in time_keywords.items():
        if keyword in query_lower:
            result["time_range"] = range_val
            result["clean_query"] = result["clean_query"].replace(keyword, "").strip()
            break
    
    return result
```

#### Step 2: 多引擎并行搜索

```python
# 多引擎并行搜索策略
SEARCH_ENGINE_PRIORITY = {
    "zh": ["baidu", "google", "bing", "duckduckgo", "brave"],
    "en": ["google", "bing", "brave", "duckduckgo", "baidu"],
    "math": ["wolframalpha", "google", "bing"],
    "news": ["google", "bing", "baidu"],
    "academic": ["google", "bing", "duckduckgo"],
}

def get_search_engines(query_info: dict) -> list:
    """
    根据查询特征选择最佳搜索引擎组合
    """
    language = query_info["language_hint"]
    clean_query = query_info["clean_query"].lower()
    
    # 数学/科学类查询优先使用 WolframAlpha
    math_keywords = ["calculate", "compute", "solve", "equation", "integral", "derivative",
                     "计算", "求解", "方程", "积分", "导数", "公式", "convert"]
    if any(kw in clean_query for kw in math_keywords):
        return SEARCH_ENGINE_PRIORITY["math"]
    
    # 新闻类查询
    news_keywords = ["news", "latest", "breaking", "新闻", "最新", "突发"]
    if any(kw in clean_query for kw in news_keywords):
        return SEARCH_ENGINE_PRIORITY["news"]
    
    return SEARCH_ENGINE_PRIORITY.get(language, SEARCH_ENGINE_PRIORITY["en"])


async def parallel_search(query: str, engines: list, num_results: int = 10) -> list:
    """
    并行搜索多个引擎
    """
    import asyncio
    
    async def search_single_engine(engine: str, q: str, n: int) -> list:
        try:
            # 使用 web_search API 搜索
            # 返回标准化的结果列表
            # 每个结果包含: title, url, snippet, source_engine, rank
            return [{"engine": engine, "results": []}]
        except Exception as e:
            print(f"[{engine}] 搜索失败: {e}")
            return []
    
    tasks = [search_single_engine(engine, query, num_results) for engine in engines]
    results = await asyncio.gather(*tasks, return_exceptions=True)
    return [r for r in results if isinstance(r, list)]
```

#### Step 3: 结果去重与排序

```python
def deduplicate_and_rank(all_results: list, original_query: str) -> list:
    """
    对多引擎搜索结果进行去重和相关性排序
    """
    # URL 去重（标准化 URL）
    seen_urls = set()
    deduped_results = []
    
    for engine_result in all_results:
        for result in engine_result:
            url = result["url"].rstrip("/").lower()
            # 去除追踪参数
            if "?" in url:
                base_url = url.split("?")[0]
            else:
                base_url = url
            
            if base_url not in seen_urls:
                seen_urls.add(base_url)
                deduped_results.append({
                    "title": result["title"],
                    "url": result["url"],
                    "snippet": result["snippet"],
                    "source_engines": [result.get("engine", "unknown")],
                    "relevance_score": 0
                })
            else:
                # 已存在的结果，增加引擎计数
                for existing in deduped_results:
                    if existing["url"].rstrip("/").lower() == url:
                        existing["source_engines"].append(result.get("engine", "unknown"))
                        break
    
    # 计算相关性分数
    query_terms = set(original_query.lower().split())
    
    for result in deduped_results:
        score = 0
        title_lower = result["title"].lower()
        snippet_lower = result["snippet"].lower()
        
        # 标题匹配得分（权重高）
        for term in query_terms:
            if term in title_lower:
                score += 10
            if term in snippet_lower:
                score += 3
        
        # 多引擎命中加分
        score += len(result["source_engines"]) * 5
        
        # 标题完全匹配加分
        if original_query.lower() in title_lower:
            score += 20
        
        result["relevance_score"] = score
    
    # 按分数排序
    deduped_results.sort(key=lambda x: x["relevance_score"], reverse=True)
    
    return deduped_results
```

---

### 4. 高级搜索操作符

#### 4.1 支持的搜索操作符

| 操作符 | 说明 | 示例 |
|--------|------|------|
| `site:` | 限定搜索域名 | `AI 最新进展 site:arxiv.org` |
| `filetype:` | 限定文件类型 | `深度学习 filetype:pdf` |
| `intitle:` | 标题包含关键词 | `intitle:机器学习教程` |
| `inurl:` | URL 包含关键词 | `教程 inurl:github.com` |
| `intext:` | 正文包含关键词 | `intext:Transformer架构` |
| `""` | 精确匹配 | `"large language model"` |
| `-` | 排除关键词 | `python -snake` |
| `OR` | 或运算 | `GPT OR Claude` |
| `*` | 通配符 | `how to * in python` |
| `..` | 数字范围 | `AI papers 2020..2024` |

#### 4.2 操作符使用指南

```python
def apply_search_operators(query: str, operators: dict) -> str:
    """
    将高级搜索操作符应用到不同搜索引擎的查询中
    """
    # Google/Bing/Brave 支持标准操作符
    google_query = query
    for op, val in operators.items():
        google_query = f"{op}:{val} {google_query}"
    
    # Baidu 操作符映射
    baidu_map = {
        "site:": "site:",
        "filetype:": "filetype:",
        "intitle:": "intitle:",
    }
    baidu_query = query
    for op, val in operators.items():
        if op in baidu_map:
            baidu_query = f"{op}{val} {baidu_query}"
    
    return {
        "google": google_query,
        "bing": google_query,
        "baidu": baidu_query,
        "brave": google_query,
        "duckduckgo": google_query,
    }
```

---

### 5. 时间范围过滤

```python
def apply_time_filter(query: str, time_range: str, engine: str) -> str:
    """
    为不同搜索引擎应用时间范围过滤
    """
    # Google: 使用 tbs 参数
    # Bing: 使用 freshness 参数
    # Baidu: 使用 gws 参数
    # Brave: 使用 extra_snippets 参数
    
    time_filters = {
        "h1": {"google": "qdr:h", "bing": "Day", "baidu": "d"},
        "d1": {"google": "qdr:d", "bing": "Day", "baidu": "d"},
        "w1": {"google": "qdr:w", "bing": "Week", "baidu": "w"},
        "m1": {"google": "qdr:m", "bing": "Month", "baidu": "m"},
        "y1": {"google": "qdr:y", "bing": "Year", "baidu": "y"},
    }
    
    if time_range and time_range in time_filters:
        filter_map = time_filters[time_range]
        return f"{query} ({time_range})"
    
    return query
```

**使用时间过滤的关键词：**
- 中文：`过去一小时`、`过去一天`、`过去一周`、`过去一月`、`过去一年`
- 英文：`past hour`、`past day`、`past week`、`past month`、`past year`

示例：
```
搜索：人工智能最新进展 过去一周
效果：只返回最近一周内发布的结果
```

---

### 6. 结果缓存机制

```python
import hashlib
import json
import time
from pathlib import Path

class SearchCache:
    """
    搜索结果缓存管理
    避免重复查询相同内容，提高响应速度
    """
    
    def __init__(self, cache_dir: str = "/tmp/search_cache", ttl: int = 3600):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(exist_ok=True)
        self.ttl = ttl  # 缓存有效期（秒）
    
    def _cache_key(self, query: str, engine: str, time_range: str = None) -> str:
        """生成缓存键"""
        raw = f"{query}|{engine}|{time_range}"
        return hashlib.md5(raw.encode()).hexdigest()
    
    def get(self, query: str, engine: str, time_range: str = None) -> dict | None:
        """获取缓存"""
        key = self._cache_key(query, engine, time_range)
        cache_file = self.cache_dir / f"{key}.json"
        
        if cache_file.exists():
            data = json.loads(cache_file.read_text())
            if time.time() - data["timestamp"] < self.ttl:
                return data["results"]
            else:
                cache_file.unlink()  # 过期删除
        
        return None
    
    def set(self, query: str, engine: str, results: list, time_range: str = None):
        """写入缓存"""
        key = self._cache_key(query, engine, time_range)
        cache_file = self.cache_dir / f"{key}.json"
        
        data = {
            "timestamp": time.time(),
            "query": query,
            "engine": engine,
            "time_range": time_range,
            "results": results
        }
        cache_file.write_text(json.dumps(data, ensure_ascii=False, indent=2))
    
    def clear(self):
        """清空所有缓存"""
        for f in self.cache_dir.glob("*.json"):
            f.unlink()
    
    def stats(self) -> dict:
        """缓存统计"""
        files = list(self.cache_dir.glob("*.json"))
        total_size = sum(f.stat().st_size for f in files)
        return {
            "cached_queries": len(files),
            "total_size_bytes": total_size,
            "ttl_seconds": self.ttl
        }


# 使用示例
cache = SearchCache(ttl=1800)  # 30分钟缓存

# 查询前先检查缓存
cached = cache.get("机器学习教程", "google")
if cached:
    print("使用缓存结果:", cached)
else:
    # 执行搜索
    results = perform_search("机器学习教程", "google")
    cache.set("机器学习教程", "google", results)
```

---

### 7. 搜索历史管理

```python
import sqlite3
from datetime import datetime

class SearchHistory:
    """
    搜索历史记录管理
    """
    
    def __init__(self, db_path: str = "/tmp/search_history.db"):
        self.conn = sqlite3.connect(db_path)
        self._init_db()
    
    def _init_db(self):
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS searches (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT NOT NULL,
                engines TEXT,
                result_count INTEGER,
                timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                category TEXT
            )
        """)
        self.conn.commit()
    
    def add_record(self, query: str, engines: list, result_count: int, category: str = "general"):
        """添加搜索记录"""
        self.conn.execute(
            "INSERT INTO searches (query, engines, result_count, category) VALUES (?, ?, ?, ?)",
            (query, ",".join(engines), result_count, category)
        )
        self.conn.commit()
    
    def get_recent(self, limit: int = 20) -> list:
        """获取最近搜索记录"""
        rows = self.conn.execute(
            "SELECT query, engines, result_count, timestamp FROM searches ORDER BY timestamp DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    
    def get_popular(self, limit: int = 10) -> list:
        """获取热门搜索"""
        rows = self.conn.execute(
            "SELECT query, COUNT(*) as count FROM searches GROUP BY query ORDER BY count DESC LIMIT ?",
            (limit,)
        ).fetchall()
        return [dict(r) for r in rows]
    
    def search_history(self, keyword: str, limit: int = 10) -> list:
        """在历史记录中搜索"""
        rows = self.conn.execute(
            "SELECT * FROM searches WHERE query LIKE ? ORDER BY timestamp DESC LIMIT ?",
            (f"%{keyword}%", limit)
        ).fetchall()
        return [dict(r) for r in rows]
    
    def clear_history(self):
        """清空历史"""
        self.conn.execute("DELETE FROM searches")
        self.conn.commit()
```

---

### 8. 结果导出功能

#### 8.1 导出为 Markdown

```python
def export_to_markdown(results: list, query: str, output_path: str):
    """
    将搜索结果导出为 Markdown 格式
    """
    md = f"""# 搜索结果：{query}

> 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
> 结果数量：{len(results)}

---

"""
    
    for i, result in enumerate(results, 1):
        engines = ", ".join(result.get("source_engines", []))
        md += f"""## {i}. {result['title']}

**链接**：[{result['url']}]({result['url']})
**来源引擎**：{engines}
**相关度**：{result.get('relevance_score', 'N/A')}/100

> {result['snippet']}

---

"""
    
    Path(output_path).write_text(md, encoding="utf-8")
    return output_path
```

#### 8.2 导出为 JSON

```python
def export_to_json(results: list, query: str, output_path: str):
    """
    将搜索结果导出为 JSON 格式
    """
    export_data = {
        "meta": {
            "query": query,
            "exported_at": datetime.now().isoformat(),
            "total_results": len(results),
            "engines_used": list(set(
                eng for r in results for eng in r.get("source_engines", [])
            ))
        },
        "results": [
            {
                "rank": i + 1,
                "title": r["title"],
                "url": r["url"],
                "snippet": r["snippet"],
                "engines": r.get("source_engines", []),
                "relevance_score": r.get("relevance_score", 0)
            }
            for i, r in enumerate(results)
        ]
    }
    
    Path(output_path).write_text(
        json.dumps(export_data, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )
    return output_path
```

---

### 9. 完整搜索工作流示例

#### 示例 1：基础聚合搜索

**用户输入：** `搜索：Next.js 16 新特性`

**执行流程：**
1. 预处理：识别为英文查询，提取关键词 `Next.js 16 新特性`
2. 选择引擎：Google、Bing、DuckDuckGo（英文优先）
3. 并行查询三个引擎，各获取前 10 条结果
4. 去重：基于 URL 标准化去重
5. 排序：按相关性分数排序
6. 输出：返回去重排序后的结果列表

#### 示例 2：带高级操作符的搜索

**用户输入：** `搜索：深度学习教程 filetype:pdf site:github.com 过去一月`

**执行流程：**
1. 预处理：提取 `filetype:pdf`、`site:github.com`、时间范围 `过去一月`
2. 构建各引擎查询字符串
3. 选择引擎：Google、Bing、Baidu
4. 应用时间过滤
5. 并行搜索、去重排序
6. 输出带元信息的结果

#### 示例 3：中文聚合搜索

**用户输入：** `搜索：中国 2024 年 GDP 数据`

**执行流程：**
1. 预处理：识别为中文查询
2. 选择引擎：Baidu（优先）、Google、Bing
3. 并行搜索
4. 去重排序，中文结果优先
5. 输出结果

---

### 10. 错误处理与降级策略

```python
class SearchOrchestrator:
    """
    搜索编排器，管理多引擎搜索、错误处理和降级策略
    """
    
    def __init__(self):
        self.cache = SearchCache(ttl=1800)
        self.history = SearchHistory()
        self.engine_configs = {
            "google": {"timeout": 10, "retry": 2},
            "bing": {"timeout": 10, "retry": 2},
            "baidu": {"timeout": 15, "retry": 3},
            "duckduckgo": {"timeout": 8, "retry": 1},
            "brave": {"timeout": 10, "retry": 2},
            "wolframalpha": {"timeout": 15, "retry": 1},
        }
    
    async def search(self, query: str, engines: list = None, num_results: int = 10):
        """
        执行聚合搜索，带错误处理和降级策略
        """
        # 预处理
        query_info = preprocess_query(query)
        
        # 选择引擎
        if not engines:
            engines = get_search_engines(query_info)
        
        # 检查缓存
        all_results = []
        remaining_engines = []
        
        for engine in engines:
            cached = self.cache.get(
                query_info["clean_query"],
                engine,
                query_info["time_range"]
            )
            if cached:
                all_results.extend(cached)
            else:
                remaining_engines.append(engine)
        
        # 执行未缓存的搜索
        if remaining_engines:
            try:
                fresh_results = await parallel_search(
                    query_info["clean_query"],
                    remaining_engines,
                    num_results
                )
                all_results.extend(fresh_results)
                
                # 写入缓存
                for engine_result in fresh_results:
                    if engine_result:
                        engine = engine_result[0].get("engine", "unknown")
                        self.cache.set(
                            query_info["clean_query"],
                            engine,
                            engine_result,
                            query_info["time_range"]
                        )
            except Exception as e:
                print(f"搜索执行失败: {e}")
        
        # 降级策略：如果没有结果，使用备用引擎
        if not all_results:
            fallback_engines = ["duckduckgo", "bing"]
            fallback_results = await parallel_search(
                query_info["clean_query"],
                fallback_engines,
                num_results
            )
            all_results.extend(fallback_results)
        
        # 去重排序
        ranked_results = deduplicate_and_rank(all_results, query)
        
        # 记录历史
        self.history.add_record(
            query_info["clean_query"],
            engines,
            len(ranked_results)
        )
        
        return ranked_results
```

---

### 11. 使用指南

#### 基本用法

直接描述搜索需求，工具会自动选择最佳搜索引擎组合：

```
请帮我搜索 "React Server Components 最新教程"
```

#### 高级搜索

使用搜索操作符进行精确搜索：

```
请搜索 "机器学习 filetype:pdf site:arxiv.org 过去一周"
```

#### 对比搜索

同时搜索多个相关主题进行对比：

```
请分别搜索 "GPT-5 发布时间" 和 "Claude 4 发布时间"，并对比结果
```

#### 学术搜索

搜索学术论文和技术文档：

```
请搜索 "transformer attention mechanism 论文 过去一年"，优先使用 Google Scholar
```

#### 新闻搜索

搜索最新新闻：

```
请搜索 "AI 行业最新新闻 过去一天"
```

---

### 12. 注意事项

1. **API 密钥配置**：部分搜索引擎（Google、Bing、Brave、WolframAlpha）需要 API 密钥才能使用其 API。请确保相关密钥已正确配置。
2. **速率限制**：各搜索引擎都有速率限制，聚合搜索时需注意不要超过限制。
3. **缓存管理**：定期清理缓存以避免存储过多过期数据。
4. **隐私保护**：使用 DuckDuckGo 和 Brave Search 可获得更好的隐私保护。
5. **结果质量**：不同搜索引擎在不同语言和领域的搜索质量不同，工具会根据查询特征自动选择最优组合。
6. **网络依赖**：搜索功能依赖网络连接，离线状态下无法使用。
