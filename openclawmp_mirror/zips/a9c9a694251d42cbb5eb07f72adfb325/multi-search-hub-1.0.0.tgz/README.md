# 多搜索引擎聚合中心 (Multi-Search Hub)

> 作者：知白守黑1024

## 简介

多搜索引擎聚合中心是一个强大的搜索增强工具，能够同时从 Google、Bing、Baidu、DuckDuckGo、WolframAlpha、Brave Search 等多个搜索引擎获取结果。通过智能去重和相关性排序，为用户提供更全面、更准确的搜索体验。支持中英文双语查询、高级搜索操作符、时间范围过滤、结果缓存、搜索历史管理和多格式导出。

## 核心功能

- **多引擎聚合搜索**：同时查询 Google、Bing、Baidu、DuckDuckGo、WolframAlpha、Brave Search
- **智能去重排序**：基于 URL 标准化和相关性评分自动去重排序
- **中英文原生支持**：根据查询语言自动选择最优搜索引擎组合
- **高级搜索操作符**：支持 site:、filetype:、intitle:、inurl:、intext: 等操作符
- **时间范围过滤**：支持过去一小时/一天/一周/一月/一年的结果过滤
- **结果缓存机制**：避免重复查询，提高响应速度
- **搜索历史管理**：记录和搜索历史查询
- **多格式导出**：支持 Markdown 和 JSON 格式导出

## 使用场景

| 场景 | 说明 |
|------|------|
| 全网内容搜索 | 聚合多个搜索引擎获取最全面的结果 |
| 学术论文搜索 | 结合 Google 和 Baidu 搜索中英文学术资源 |
| 新闻资讯搜索 | 实时搜索最新新闻和热点事件 |
| 技术文档搜索 | 搜索特定网站的技术文档和教程 |
| PDF/文件搜索 | 使用 filetype 操作符搜索特定格式文件 |
| 竞品分析 | 多引擎搜索竞品信息进行对比分析 |
| 隐私搜索 | 使用 DuckDuckGo 和 Brave 进行隐私保护搜索 |
| 数学计算 | 使用 WolframAlpha 进行数学和科学计算 |

## 配置说明

### 支持的搜索引擎

| 搜索引擎 | API 需求 | 特点 |
|---------|---------|------|
| Google | 需要 API Key + CSE ID | 全球最大索引 |
| Bing | 需要 API Key | API 稳定可靠 |
| Baidu | 无需 API（网页解析） | 中文内容丰富 |
| DuckDuckGo | 无需 API（网页解析） | 隐私保护 |
| Brave Search | 需要 API Key | 独立索引 |
| WolframAlpha | 需要 App ID | 计算知识引擎 |

### 环境变量（可选）

```bash
# Google Custom Search
GOOGLE_API_KEY=your_google_api_key
GOOGLE_CSE_ID=your_cse_id

# Bing Web Search
BING_API_KEY=your_bing_api_key

# Brave Search
BRAVE_API_KEY=your_brave_api_key

# WolframAlpha
WOLFRAM_APP_ID=your_wolfram_app_id
```

## 版本

v1.0.0
