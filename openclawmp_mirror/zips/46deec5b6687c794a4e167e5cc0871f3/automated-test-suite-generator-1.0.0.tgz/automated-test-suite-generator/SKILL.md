---
name: automated-test-suite-generator
description: '自动化测试套件生成器 - 智能生成单元测试、集成测试、E2E测试代码'
version: 1.0.0
type: skill
tags: ['testing', 'automation', 'quality', 'development', 'ci-cd']
---

# 自动化测试套件生成器

> 智能生成单元测试、集成测试、E2E测试代码

## 核心功能

- 🧪 自动生成单元测试
- 🔗 智能生成集成测试
- 🌐 自动生成E2E测试
- 📊 测试覆盖率分析
- 🔄 CI/CD集成

## 使用方法

```bash
# 为函数生成单元测试
openclaw skill run test-suite --file "utils.js" --function "calculateTotal"

# 为API生成集成测试
openclaw skill run test-suite --api "./api-spec.yaml" --type "integration"

# 为页面生成E2E测试
openclaw skill run test-suite --url "https://example.com" --type "e2e"

# 为整个项目生成完整测试套件
openclaw skill run test-suite --project "./src" --coverage 80
```

## 支持的测试框架

| 语言 | 单元测试 | 集成测试 | E2E测试 |
|------|---------|---------|---------|
| JavaScript | Jest/Mocha | Supertest | Playwright/Cypress |
| Python | pytest/unittest | requests | Selenium/Playwright |
| Java | JUnit/TestNG | RestAssured | Selenium |
| Go | testing/testify | httptest | Playwright |
| TypeScript | Jest/Vitest | Supertest | Playwright |

## 生成的测试内容

### 1. 单元测试
- ✅ 正常输入测试
- ✅ 边界条件测试
- ✅ 异常处理测试
- ✅ 异步函数测试
- ✅ Mock/Stub支持

### 2. 集成测试
- ✅ API端点测试
- ✅ 数据库交互测试
- ✅ 第三方服务Mock
- ✅ 事务回滚测试

### 3. E2E测试
- ✅ 用户流程测试
- ✅ 页面交互测试
- ✅ 跨浏览器测试
- ✅ 视觉回归测试

## 输出示例

```javascript
// utils.js - 被测试的函数
function calculateTotal(items, tax = 0.08) {
  if (!Array.isArray(items)) throw new Error('Items must be an array');
  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  return subtotal * (1 + tax);
}

// utils.test.js - 生成的测试
const { calculateTotal } = require('./utils');

describe('calculateTotal', () => {
  // 正常输入测试
  test('should calculate total with default tax', () => {
    const items = [{ price: 100, quantity: 2 }, { price: 50, quantity: 1 }];
    expect(calculateTotal(items)).toBe(270); // 250 * 1.08
  });

  // 自定义税率测试
  test('should calculate total with custom tax', () => {
    const items = [{ price: 100, quantity: 1 }];
    expect(calculateTotal(items, 0.1)).toBe(110);
  });

  // 边界条件：空数组
  test('should return 0 for empty items', () => {
    expect(calculateTotal([])).toBe(0);
  });

  // 边界条件：零数量
  test('should handle zero quantity', () => {
    const items = [{ price: 100, quantity: 0 }];
    expect(calculateTotal(items)).toBe(0);
  });

  // 异常处理：非数组输入
  test('should throw error for non-array input', () => {
    expect(() => calculateTotal('invalid')).toThrow('Items must be an array');
  });

  // 异常处理：null输入
  test('should throw error for null input', () => {
    expect(() => calculateTotal(null)).toThrow('Items must be an array');
  });
});
```

## 测试报告输出

```markdown
# 测试报告

## 概览
- 总测试数：45
- 通过：43 ✅
- 失败：2 ❌
- 跳过：0
- 覆盖率：87%

## 详细结果

### utils.test.js
| 测试 | 状态 | 耗时 |
|------|------|------|
| calculateTotal - 正常输入 | ✅ | 12ms |
| calculateTotal - 自定义税率 | ✅ | 8ms |
| calculateTotal - 空数组 | ✅ | 5ms |
| calculateTotal - 异常处理 | ✅ | 10ms |

### api.test.js
| 测试 | 状态 | 耗时 |
|------|------|------|
| GET /users | ✅ | 45ms |
| POST /users | ❌ | 120ms |
| DELETE /users/:id | ✅ | 38ms |

## 失败详情

### POST /users
**错误**：Expected 201, got 400
**原因**：缺少必填字段 email
**建议**：添加输入验证测试

## 覆盖率报告

| 文件 | 语句 | 分支 | 函数 | 行 |
|------|------|------|------|-----|
| utils.js | 95% | 90% | 100% | 95% |
| api.js | 82% | 75% | 85% | 82% |
```

## 安装

```bash
openclaw skill install automated-test-suite-generator
```

## CI/CD集成

```yaml
# .github/workflows/test.yml
name: Automated Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Generate Tests
        run: openclaw skill run test-suite --project "./src" --coverage 80
      - name: Run Tests
        run: npm test
      - name: Upload Coverage
        uses: codecov/codecov-action@v3
```

## 高级功能

- 🤖 AI智能测试用例生成
- 📊 测试覆盖率自动分析
- 🔄 回归测试自动识别
- 🐛 Bug模式学习
- 📈 测试质量评分

---

**提升代码质量，从自动化测试开始！**
