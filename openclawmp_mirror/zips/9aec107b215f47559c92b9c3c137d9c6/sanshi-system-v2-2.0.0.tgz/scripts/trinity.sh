#!/bin/bash
# 三识系统 · 一键入口（v2.0 融合版）
# =====================================
# 统一调用引擎，各模块可独立执行。
#
# 用法:
#   bash trinity.sh              # 状态面板
#   bash trinity.sh memorize     # 记忆评分/迁移（独立）
#   bash trinity.sh evolve       # Gene 列表（独立）
#   bash trinity.sh transcend    # 能力树扫描（独立）
#   bash trinity.sh heartbeat    # 心跳守护
#   bash trinity.sh full         # 完整进化循环（引擎驱动）
#   bash trinity.sh auto         # 自动模式（根据 trigger 决定）

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ENGINE="$SCRIPT_DIR/sanshi_engine.py"

# 检测 Python 路径（优先 py -3，次选 python3）
if command -v py &> /dev/null; then
    PYTHON="py -3"
elif command -v python3 &> /dev/null; then
    PYTHON="python3"
else
    PYTHON="python"
fi

case "$1" in
    memorize)
        echo "📖 识·记：记忆评分/迁移（独立模式）"
        $PYTHON "$SCRIPT_DIR/memorize.py" --days 7
        ;;
    evolve)
        echo "⚙️ 识·变：Gene 列表（独立模式）"
        $PYTHON "$SCRIPT_DIR/evolve.py" list
        ;;
    transcend)
        echo "🔥 识·进：能力树扫描（独立模式）"
        $PYTHON "$SCRIPT_DIR/transcend.py" --check
        ;;
    full|auto|"")
        echo "🧬 三识引擎 v2.0：完整进化循环"
        $PYTHON "$ENGINE" --mode full
        ;;
    status)
        echo "🧬 三识引擎 v2.0：状态面板"
        $PYTHON "$ENGINE" --status
        ;;
    *)
        echo "用法:"
        echo "  bash trinity.sh memorize    # 记忆评分/迁移（独立）"
        echo "  bash trinity.sh evolve       # 列出全部Gene（独立）"
        echo "  bash trinity.sh transcend    # 能力树扫描 + 反劣化（独立）"
        echo "  bash trinity.sh full         # 完整进化循环（引擎驱动）"
        echo "  bash trinity.sh auto         # 自动模式（引擎驱动）"
        echo "  bash trinity.sh status       # 引擎状态面板"
        ;;
esac
