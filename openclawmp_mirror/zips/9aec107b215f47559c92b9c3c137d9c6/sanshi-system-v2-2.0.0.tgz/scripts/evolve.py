#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 能力进化模块（识·变）
=================================
Gene 查询/创建/复用，Event 记录，Capsule 管理。

用法:
    python evolve.py query "邮箱管理"        # 查询Gene
    python evolve.py create "记忆评分流程"    # 创建Gene
    python evolve.py event "类型" "描述"      # 记录事件
    python evolve.py list                     # 列出全部Gene
"""

import os
import sys
import json
from datetime import datetime
from pathlib import Path

SANSHI_ROOT = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "skills", "三识系统")
EVOLUTION_DIR = SANSHI_ROOT / "evolution"
GENES_DIR = EVOLUTION_DIR / "genes"
EVENTS_DIR = EVOLUTION_DIR / "events"
CAPSULES_DIR = EVOLUTION_DIR / "capsules"

# 确保目录存在
for d in [GENES_DIR, EVENTS_DIR, CAPSULES_DIR]:
    d.mkdir(parents=True, exist_ok=True)


def gene_id(title: str) -> str:
    """生成Gene ID"""
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    return f"gene-{ts}-{title[:20].replace(' ', '-')}"


def query_gene(keyword: str) -> list:
    """模糊查询Gene库"""
    results = []
    for f in GENES_DIR.glob("*.yaml"):
        content = f.read_text(encoding="utf-8")
        if keyword.lower() in content.lower():
            results.append({"file": f.name, "preview": content[:200]})
    return results


def create_gene(name: str, description: str, problem: str = "", strategy: str = "") -> str:
    """创建新Gene"""
    gid = gene_id(name)
    gene = {
        "gene_id": gid,
        "name": name,
        "version": "1.0.0",
        "created_at": datetime.now().isoformat(),
        "last_used": datetime.now().isoformat(),
        "source_module": "三识系统",
        "description": description,
        "problem": problem,
        "strategy": strategy,
        "memory_associations": [],
        "reuse_paths": [],
        "abstraction_hints": [],
        "applies_when": [],
        "does_not_apply_when": [],
        "failure_points": [],
        "success_rate": 0.0,
        "used_count": 0,
        "last_success": None,
        "last_failure": None,
    }
    
    yaml_content = f"""# Gene: {name}
gene_id: {gid}
name: "{name}"
version: "1.0.0"
created_at: "{gene['created_at']}"
last_used: "{gene['last_used']}"
source_module: "{gene['source_module']}"

description: |
  {description}

problem: |
  {problem}

strategy: |
  {strategy}

memory_associations: []
reuse_paths: []
abstraction_hints: []

applies_when: []
does_not_apply_when: []
failure_points: []

success_rate: 0.0
used_count: 0
last_success: null
last_failure: null
"""
    
    filepath = GENES_DIR / f"{gid}.yaml"
    filepath.write_text(yaml_content, encoding="utf-8")
    print(f"✅ 创建Gene: {name}")
    print(f"   文件: {filepath}")
    return gid


def record_event(event_type: str, description: str) -> str:
    """记录进化Event"""
    ts = datetime.now().strftime("%Y%m%d-%H%M")
    eid = f"ev-{ts}"
    
    event = {
        "event_id": eid,
        "type": event_type,
        "status": "resolved",
        "created_at": datetime.now().isoformat(),
        "title": description,
        "description": description,
        "problem": {"title": "", "description": "", "root_cause": ""},
        "attempts": [],
        "result": "完成",
        "impact": "",
        "linked_genes": [],
        "memory_references": [],
    }
    
    yaml_content = f"""# Event
event_id: {eid}
type: {event_type}
status: resolved
created_at: "{event['created_at']}"

title: "{description}"
description: |
  {description}

problem:
  title: ""
  description: ""
  root_cause: ""

attempts: []
result: "完成"
impact: ""
linked_genes: []
memory_references: []
"""
    
    filepath = EVENTS_DIR / f"{eid}.yaml"
    filepath.write_text(yaml_content, encoding="utf-8")
    print(f"✅ 记录Event: {eid}")
    return eid


def list_genes() -> list:
    """列出全部Gene"""
    genes = []
    for f in sorted(GENES_DIR.glob("*.yaml")):
        content = f.read_text(encoding="utf-8")
        # 简单解析name和used_count
        name = ""
        used = 0
        for line in content.split("\n"):
            if line.startswith("name:"):
                name = line.split('"')[1] if '"' in line else line.split(":", 1)[1].strip()
            if line.startswith("used_count:"):
                used = int(line.split(":")[1].strip())
        genes.append({"file": f.name, "name": name, "used_count": used})
    return genes


def usage():
    print("三识系统 · 能力进化模块")
    print("=" * 40)
    print("用法:")
    print(f"  {sys.argv[0]} query \"关键词\"    # 查询Gene")
    print(f"  {sys.argv[0]} create \"名称\" \"描述\" # 创建Gene")
    print(f"  {sys.argv[0]} event \"类型\" \"描述\"  # 记录Event")
    print(f"  {sys.argv[0]} list                # 列出Gene")
    print()
    print("Event类型: capability-upgrade | error-fix | pattern-learned | strategy-optimized | memory-breakthrough")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        usage()
        sys.exit(0)
    
    action = sys.argv[1]
    
    if action == "query" and len(sys.argv) >= 3:
        keyword = sys.argv[2]
        results = query_gene(keyword)
        if results:
            print(f"找到 {len(results)} 个Gene:")
            for r in results:
                print(f"  📄 {r['file']}")
                print(f"     {r['preview'][:100]}...")
        else:
            print("未找到相关Gene，建议创建新的")
    
    elif action == "create" and len(sys.argv) >= 4:
        name = sys.argv[2]
        description = sys.argv[3]
        problem = sys.argv[4] if len(sys.argv) > 4 else ""
        strategy = sys.argv[5] if len(sys.argv) > 5 else ""
        create_gene(name, description, problem, strategy)
    
    elif action == "event" and len(sys.argv) >= 4:
        event_type = sys.argv[2]
        description = sys.argv[3]
        record_event(event_type, description)
    
    elif action == "list":
        genes = list_genes()
        if genes:
            print(f"共 {len(genes)} 个Gene:")
            for g in genes:
                print(f"  🧬 {g['name']} (使用 {g['used_count']} 次)")
        else:
            print("Gene库为空，暂无进化记录")
    
    else:
        usage()


# ============================================================================
# Plugin 模式（v2.0 融合版 — 被 sanshi_engine.py 调用）
# ============================================================================
class EvolvePlugin:
    """识·变 插件 — 接收 SanshiContext，返回更新后的 Context"""
    
    def __init__(self, ctx):
        self.ctx = ctx
    
    def run(self, trigger="manual", dry_run=False):
        """执行能力进化，结果写入 ctx"""
        print(f"  [识·变] 扫描 Gene 库 + 匹配记忆...")
        
        # 1. 查询是否有新 Gene 种子（来自 memorize 的进化候选）
        memory_candidates = [m for m in self.ctx.memories_captured if m.get("category") == "core"]
        
        # 2. 列出所有现有 Gene
        existing_genes = list_genes()
        self.ctx.genes_matched = existing_genes
        
        if existing_genes:
            print(f"    找到 {len(existing_genes)} 个现有Gene")
            for g in existing_genes[:5]:  # 只打印前5个
                print(f"    🧬 {g['name']} (使用 {g['used_count']} 次)")
            if len(existing_genes) > 5:
                print(f"    ... +{len(existing_genes) - 5} more")
        
        # 3. 如果有核心记忆，提示 Gene 创建候选
        for mem in memory_candidates:
            if mem.get("score", 0) >= 9:
                self.ctx.events_logged.append({
                    "event_id": f"gene-candidate-{mem['title']}-{datetime.now().strftime('%Y%m%d')}",
                    "type": "gene-seed",
                    "timestamp": datetime.now().isoformat(),
                    "trigger": trigger,
                    "source_memory": mem["title"],
                    "score": mem["score"],
                    "action": "gene-candidate-created",
                })
                print(f"    💡 新Gene候选: {mem['title']} (score={mem['score']})")
        
        # 4. 记录进化事件
        if self.ctx.genes_matched:
            self.ctx.events_logged.append({
                "event_id": f"evolve-{datetime.now().strftime('%Y%m%d-%H%M')}",
                "type": "gene-scan",
                "timestamp": datetime.now().isoformat(),
                "trigger": trigger,
                "genes_scanned": len(self.ctx.genes_matched),
                "gene_candidates": len(memory_candidates),
            })
        
        print(f"  [识·变] 完成: {len(self.ctx.genes_matched)} Gene, {len(memory_candidates)} 候选")
        return self.ctx
