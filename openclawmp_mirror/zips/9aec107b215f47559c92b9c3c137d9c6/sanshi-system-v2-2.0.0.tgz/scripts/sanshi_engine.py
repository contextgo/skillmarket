#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 统一引擎（v2.0 融合版）
===================================
一个引擎驱动三层，各层可独立运行。

用法:
    python sanshi_engine.py                  # 自动模式（根据 trigger 决定）
    python sanshi_engine.py --mode full      # 完整周期
    python sanshi_engine.py --mode memorize  # 只跑识·记
    python sanshi_engine.py --mode evolve    # 只跑识·变
    python sanshi_engine.py --mode transcend # 只跑识·进
    python sanshi_engine.py --trigger error  # 错误触发
    python sanshi_engine.py --trigger complete  # 任务完成触发
    python sanshi_engine.py --status         # 查看引擎状态
"""

import os
import sys
import json
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Optional

# === 配置 ===
PROFILE = os.environ.get("USERPROFILE", "")
WORKSPACE = Path(PROFILE) / ".stepclaw" / "workspace"
MEMORY_DIR = WORKSPACE / "memory"
SANSHI_ROOT = Path(PROFILE) / ".stepclaw" / "skills" / "三识系统"
SCRIPTS_DIR = SANSHI_ROOT / "scripts"
EVOLUTION_DIR = SANSHI_ROOT / "evolution"
METRICS_PATH = EVOLUTION_DIR / "metrics.json"

sys.stdout.reconfigure(encoding="utf-8")


# ============================================================================
# SanshiContext — 中间产物对象（三层之间通过此对象传递数据）
# ============================================================================
@dataclass
class SanshiContext:
    """三识系统中间产物 — 内存对象，执行完毕后才落盘"""
    
    # 识·记 输出
    memories_captured: list[dict] = field(default_factory=list)
    corrections: list[dict] = field(default_factory=list)
    memory_scores: dict = field(default_factory=dict)
    
    # 识·变 输出
    genes_matched: list[dict] = field(default_factory=list)
    genes_created: list[dict] = field(default_factory=list)
    events_logged: list[dict] = field(default_factory=list)
    
    # 识·进 输出
    capability_updates: list[dict] = field(default_factory=list)
    cross_domain_hints: list[str] = field(default_factory=list)
    anti_degradation_findings: list[dict] = field(default_factory=list)
    
    # 度量
    execution_time: dict = field(default_factory=dict)
    success_flags: dict = field(default_factory=dict)
    error_messages: list[str] = field(default_factory=list)
    
    # 元信息
    trigger: str = "manual"
    timestamp: str = field(default_factory=lambda: datetime.now().isoformat())
    
    def merge(self, other: 'SanshiContext'):
        """合并子层输出到主 Context"""
        self.memories_captured.extend(other.memories_captured)
        self.corrections.extend(other.corrections)
        self.memory_scores.update(other.memory_scores)
        self.genes_matched.extend(other.genes_matched)
        self.genes_created.extend(other.genes_created)
        self.events_logged.extend(other.events_logged)
        self.capability_updates.extend(other.capability_updates)
        self.cross_domain_hints.extend(other.cross_domain_hints)
        self.anti_degradation_findings.extend(other.anti_degradation_findings)
        self.execution_time.update(other.execution_time)
        self.success_flags.update(other.success_flags)
        self.error_messages.extend(other.error_messages)
    
    def persist(self):
        """最终落盘：将所有中间产物写入文件系统"""
        self._write_events()
        self._write_metrics()
        self._write_memory_updates()
    
    def _write_events(self):
        """写入进化事件"""
        events_dir = EVOLUTION_DIR / "events"
        events_dir.mkdir(parents=True, exist_ok=True)
        
        for event in self.events_logged:
            event_id = event.get("event_id", f"ev-{int(time.time())}")
            event_path = events_dir / f"{event_id}.json"
            if not event_path.exists():
                event_path.write_text(
                    json.dumps(event, ensure_ascii=False, indent=2),
                    encoding="utf-8"
                )
    
    def _write_metrics(self):
        """写入执行度量"""
        metrics = {}
        if METRICS_PATH.exists():
            try:
                metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
            except:
                pass
        
        metrics["last_run"] = self.timestamp
        metrics["last_trigger"] = self.trigger
        metrics["last_execution_time"] = self.execution_time
        metrics["last_success"] = self.success_flags
        metrics["total_runs"] = metrics.get("total_runs", 0) + 1
        
        METRICS_PATH.parent.mkdir(parents=True, exist_ok=True)
        METRICS_PATH.write_text(
            json.dumps(metrics, ensure_ascii=False, indent=2),
            encoding="utf-8"
        )
    
    def _write_memory_updates(self):
        """将核心记忆追加到 MEMORY.md（只写摘要，不写全文）"""
        memory_md = WORKSPACE / "MEMORY.md"
        if not memory_md.exists():
            return
        
        # 只写 8+ 分记忆的摘要
        core_items = [m for m in self.memories_captured if m.get("score", 0) >= 8]
        if not core_items:
            return
        
        section = f"\n\n## 🧬 三识自动捕获 ({datetime.now().strftime('%Y-%m-%d %H:%M')})\n"
        for item in core_items:
            # 只取摘要前 100 字符，不写全文
            summary = item.get("summary", "")[:100].replace("\n", " ").strip()
            section += f"\n- **{item.get('title', '未命名')}** ({item.get('score', '?')}/10): {summary}"
        
        with open(memory_md, "a", encoding="utf-8", errors="replace") as f:
            f.write(section)
    
    def report(self) -> dict:
        """执行报告（给 Cron/用户看）"""
        return {
            "timestamp": self.timestamp,
            "trigger": self.trigger,
            "memories_captured": len(self.memories_captured),
            "corrections": len(self.corrections),
            "genes_matched": len(self.genes_matched),
            "genes_created": len(self.genes_created),
            "events_logged": len(self.events_logged),
            "capability_updates": len(self.capability_updates),
            "cross_domain_hints": len(self.cross_domain_hints),
            "execution_time": self.execution_time,
            "success_flags": self.success_flags,
            "errors": self.error_messages,
        }


# ============================================================================
# SanshiEngine — 统一引擎
# ============================================================================
class SanshiEngine:
    """三识系统统一引擎：调度 + 度量 + 持久化"""
    
    LAYERS = ["memorize", "evolve", "transcend"]
    
    def __init__(self):
        self.ctx = SanshiContext()
        self.layer_modules = {}
    
    def run(self, mode="auto", trigger=None, days=7, dry_run=False) -> dict:
        """统一入口
        
        mode: "auto" | "memorize" | "evolve" | "transcend" | "full"
        trigger: "error" | "complete" | "heartbeat" | "pcec" | "manual"
        """
        self.ctx.trigger = trigger or "manual"
        
        print(f"🧬 三识引擎 v2.0")
        print(f"{'='*50}")
        print(f"模式: {mode} | 触发: {self.ctx.trigger}")
        print()
        
        # 1. 上下文感知：决定跑哪层
        if mode == "auto":
            layers = self._decide_layers(trigger)
        elif mode == "full":
            layers = self.LAYERS[:]
        else:
            layers = [mode] if mode in self.LAYERS else self.LAYERS
        
        print(f"执行层: {', '.join(layers)}")
        print()
        
        # 2. 按调度顺序执行
        for layer_name in layers:
            t0 = time.time()
            print(f"──▶ {layer_name}")
            try:
                result = self._run_layer(layer_name, trigger, days, dry_run)
                self.ctx.merge(result)
                self.ctx.success_flags[layer_name] = True
                elapsed = round(time.time() - t0, 1)
                self.ctx.execution_time[layer_name] = elapsed
                print(f"  ✓ 完成 ({elapsed}s)")
            except Exception as e:
                self.ctx.success_flags[layer_name] = False
                self.ctx.error_messages.append(f"{layer_name}: {str(e)}")
                elapsed = round(time.time() - t0, 1)
                self.ctx.execution_time[layer_name] = elapsed
                print(f"  ✗ 错误: {e}")
            print()
        
        # 3. 持久化
        if not dry_run:
            print("──▶ 持久化")
            self.ctx.persist()
            print("  ✓ 已写入文件系统")
            print()
        
        # 4. 报告
        report = self.ctx.report()
        print(f"{'='*50}")
        print(f"📊 执行报告:")
        for k, v in report.items():
            if v or (isinstance(v, (int, bool)) and v == 0):
                print(f"  {k}: {v}")
        
        return report
    
    def _decide_layers(self, trigger):
        """上下文感知调度"""
        if trigger == "error":
            return ["memorize"]
        elif trigger == "complete":
            return ["memorize", "evolve"]
        elif trigger == "pcec":
            return ["memorize", "evolve", "transcend"]
        elif trigger == "heartbeat":
            return ["memorize"]
        return ["memorize"]
    
    def _run_layer(self, layer_name, trigger, days, dry_run):
        """执行单一层（插件化）"""
        sub_ctx = SanshiContext(trigger=trigger)
        
        if layer_name == "memorize":
            sub_ctx = self._run_memorize(sub_ctx, days, dry_run)
        elif layer_name == "evolve":
            sub_ctx = self._run_evolve(sub_ctx, trigger, dry_run)
        elif layer_name == "transcend":
            sub_ctx = self._run_transcend(sub_ctx, dry_run)
        
        return sub_ctx
    
    def _run_memorize(self, ctx, days, dry_run):
        """识·记 — 调用 memorize.py 插件"""
        # 尝试加载插件模式
        try:
            sys.path.insert(0, str(SCRIPTS_DIR))
            from memorize import MemorizePlugin
            plugin = MemorizePlugin(ctx)
            return plugin.run(days=days, dry_run=dry_run)
        except ImportError:
            # 回退：直接调用 memorize.run()
            from memorize import run as memorize_run
            results = memorize_run(dry_run=dry_run, days=days)
            ctx.memories_captured = results
            return ctx
    
    def _run_evolve(self, ctx, trigger, dry_run):
        """识·变 — 调用 evolve.py 插件"""
        try:
            sys.path.insert(0, str(SCRIPTS_DIR))
            from evolve import EvolvePlugin
            plugin = EvolvePlugin(ctx)
            return plugin.run(trigger=trigger, dry_run=dry_run)
        except ImportError:
            # 回退：列出 Gene
            from evolve import list_genes
            genes = list_genes()
            ctx.genes_matched = genes
            return ctx
    
    def _run_transcend(self, ctx, dry_run):
        """识·进 — 调用 transcend.py 插件"""
        try:
            sys.path.insert(0, str(SCRIPTS_DIR))
            from transcend import TranscendPlugin
            plugin = TranscendPlugin(ctx)
            return plugin.run(dry_run=dry_run)
        except ImportError:
            # 回退：运行基础扫描
            from transcend import scan_capability_tree, anti_degradation_check
            tree = scan_capability_tree()
            checks = anti_degradation_check()
            ctx.capability_updates = [{"type": "scan", "data": tree}]
            ctx.anti_degradation_findings = checks
            return ctx


def print_status():
    """打印引擎状态"""
    print("🧬 三识引擎 v2.0 — 状态面板")
    print(f"{'='*50}")
    
    if METRICS_PATH.exists():
        try:
            metrics = json.loads(METRICS_PATH.read_text(encoding="utf-8"))
            print(f"总执行次数: {metrics.get('total_runs', 0)}")
            print(f"最后一次: {metrics.get('last_run', '从未')}")
            print(f"最后触发: {metrics.get('last_trigger', 'unknown')}")
            print(f"最后成功: {metrics.get('last_success', {})}")
            print(f"最后耗时: {metrics.get('last_execution_time', {})}")
        except:
            print("度量文件损坏")
    else:
        print("尚无执行记录")
    
    # Gene 库状态
    genes_dir = EVOLUTION_DIR / "genes"
    if genes_dir.exists():
        genes = list(genes_dir.glob("*.yaml")) + list(genes_dir.glob("*.json"))
        print(f"\nGene 库: {len(genes)} 个")
    
    # 事件状态
    events_dir = EVOLUTION_DIR / "events"
    if events_dir.exists():
        events = list(events_dir.glob("*.json")) + list(events_dir.glob("*.md"))
        print(f"进化事件: {len(events)} 个")


# ============================================================================
# CLI 入口
# ============================================================================
if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="三识系统 · 统一引擎")
    parser.add_argument("--mode", choices=["auto", "memorize", "evolve", "transcend", "full"],
                       default="auto", help="执行模式")
    parser.add_argument("--trigger", choices=["error", "complete", "heartbeat", "pcec", "manual"],
                       default=None, help="触发类型")
    parser.add_argument("--days", type=int, default=7, help="扫描最近N天记忆")
    parser.add_argument("--dry-run", action="store_true", help="试运行")
    parser.add_argument("--status", action="store_true", help="查看状态")
    
    args = parser.parse_args()
    
    if args.status:
        print_status()
    else:
        engine = SanshiEngine()
        engine.run(
            mode=args.mode,
            trigger=args.trigger,
            days=args.days,
            dry_run=args.dry_run
        )
