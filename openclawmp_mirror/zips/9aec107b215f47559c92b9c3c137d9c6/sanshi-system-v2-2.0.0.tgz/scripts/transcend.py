#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 知识超越模块（识·进）
=================================
能力树扫描 + 反劣化检查 + 跨域抽象检测。

用法:
    python transcend.py              # 扫描能力树
    python transcend.py --check      # 反劣化检查
    python transcend.py --cross      # 跨域扫描
"""

import os
import sys
import json
from datetime import datetime
from pathlib import Path

SANSHI_ROOT = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "skills", "三识系统")
EVOLUTION_DIR = SANSHI_ROOT / "evolution"
GENES_DIR = EVOLUTION_DIR / "genes"
EVENTS_DIR = EVOLUTION_DIR / "events"
REPORTS_DIR = SANSHI_ROOT.parent / "workspace" / "memory" / "reports"

REPORTS_DIR.mkdir(parents=True, exist_ok=True)

# 反劣化规则
ANTI_DEGEN_RULES = [
    "稳定性：引入新依赖/新状态/新控制流了吗？",
    "可解释性：能向后解释做了什么、为什么、如何判断成功吗？",
    "可复用性：这次的特有东西是什么？可剥离吗？",
    "可扩展性：未来添加功能有扩展点吗？",
    "新颖性：是否放在错误位置？",
    "副作用：当前功能或其他用户会受影响吗？",
]


def scan_capability_tree() -> dict:
    """扫描能力树（Gene库 + Event库）"""
    genes = list(GENES_DIR.glob("*.yaml"))
    events = list(EVENTS_DIR.glob("*.yaml"))
    
    # 简单分类
    categories = {
        "基础能力": [],
        "流程能力": [],
        "决策范式": [],
        "进化候选": [],
    }
    
    for g in genes:
        content = g.read_text(encoding="utf-8")
        # 根据关键词分类
        if "基础操作" in content or "工具" in content:
            categories["基础能力"].append(g.stem)
        elif "流程" in content or "策略" in content:
            categories["流程能力"].append(g.stem)
        elif "决策" in content or "范式" in content:
            categories["决策范式"].append(g.stem)
        else:
            categories["进化候选"].append(g.stem)
    
    return {
        "total_genes": len(genes),
        "total_events": len(events),
        "categories": categories,
    }


def anti_degeneration_check() -> list:
    """反劣化检查：遍历近期Event，检测是否有劣化风险"""
    results = []
    recent_events = sorted(EVENTS_DIR.glob("*.yaml"), key=lambda f: f.stat().st_mtime, reverse=True)[:10]
    
    for event in recent_events:
        content = event.read_text(encoding="utf-8")
        issues = []
        
        # 检测"为了显得更聪明而增加复杂度"
        if "显得更聪明" in content or "complexity" in content.lower():
            issues.append("⚠️ 可能为了显得更聪明而增加复杂度")
        
        # 检测"无法验证"
        if "无法验证" in content or "无法复现" in content:
            issues.append("❌ 引入无法验证/复现的机制")
        
        # 检测模糊概念
        if "感觉正确" in content or "直觉" in content:
            issues.append("⚠️ 用模糊概念替代可执行策略")
        
        if issues:
            results.append({
                "event": event.name,
                "issues": issues,
            })
    
    return results


def cross_domain_scan() -> list:
    """跨域扫描：检测Gene中可迁移到不同领域的解法"""
    # 这是一个启发式检测：如果两个Gene描述相似但领域不同，提示迁移可能
    genes = list(GENES_DIR.glob("*.yaml"))
    cross_domain_candidates = []
    
    if len(genes) < 2:
        return cross_domain_candidates
    
    # 简单匹配：找描述中有相似关键词的Gene
    for i, g1 in enumerate(genes):
        for g2 in genes[i+1:]:
            content1 = g1.read_text(encoding="utf-8").lower()
            content2 = g2.read_text(encoding="utf-8").lower()
            
            # 如果描述有重叠关键词（简化版）
            words1 = set(content1.split())
            words2 = set(content2.split())
            overlap = words1 & words2
            common_keywords = {w for w in overlap if len(w) > 4}
            
            if len(common_keywords) >= 3:
                cross_domain_candidates.append({
                    "gene1": g1.stem,
                    "gene2": g2.stem,
                    "shared_keywords": list(common_keywords)[:5],
                    "hint": "可能可以跨域迁移，请人工确认",
                })
    
    return cross_domain_candidates


def run(check_mode: str = "full"):
    """主执行流程"""
    print("三识系统 · 知识超越模块（识·进）")
    print("=" * 50)
    
    if check_mode in ("full", "tree"):
        tree = scan_capability_tree()
        print(f"\n📊 能力树状态:")
        print(f"  Gene总数: {tree['total_genes']}")
        print(f"  Event总数: {tree['total_events']}")
        for cat, items in tree['categories'].items():
            if items:
                print(f"  {cat}: {len(items)} 个")
            else:
                print(f"  {cat}: (空)")
    
    if check_mode in ("full", "check"):
        print(f"\n🔒 反劣化检查:")
        issues = anti_degeneration_check()
        if issues:
            for issue in issues:
                print(f"  ⚠️ {issue['event']}:")
                for i in issue['issues']:
                    print(f"    {i}")
        else:
            print("  ✅ 未发现劣化风险")
    
    if check_mode in ("full", "cross"):
        print(f"\n🔗 跨域扫描:")
        candidates = cross_domain_scan()
        if candidates:
            for c in candidates:
                print(f"  {c['gene1']} ↔ {c['gene2']}")
                print(f"    共同关键词: {', '.join(c['shared_keywords'])}")
                print(f"    {c['hint']}")
        else:
            print("  (Gene库不足2个，暂无法跨域比较)")
    
    # 生成报告
    report_path = REPORTS_DIR / f"transcend-scan-{datetime.now().strftime('%Y%m%d-%H%M')}.md"
    report_lines = [
        f"# 识·进 扫描报告",
        f"时间: {datetime.now().isoformat()}",
        f"模式: {check_mode}",
        f"",
    ]
    report_lines.append(f"## 能力树")
    report_lines.append(f"- Gene: {tree.get('total_genes', 0)}")
    report_lines.append(f"- Event: {tree.get('total_events', 0)}")
    report_path.write_text("\n".join(report_lines), encoding="utf-8")
    print(f"\n📄 报告: {report_path}")


if __name__ == "__main__":
    mode = "full"
    for arg in sys.argv[1:]:
        if arg == "--check":
            mode = "check"
        elif arg == "--cross":
            mode = "cross"
        elif arg == "--tree":
            mode = "tree"
    
    run(mode)


# ============================================================================
# Plugin 模式（v2.0 融合版 — 被 sanshi_engine.py 调用）
# ============================================================================
class TranscendPlugin:
    """识·进 插件 — 接收 SanshiContext，返回更新后的 Context"""
    
    def __init__(self, ctx):
        self.ctx = ctx
    
    def run(self, dry_run=False):
        """执行知识超越扫描，结果写入 ctx"""
        print(f"  [识·进] 能力树扫描 + 反劣化 + 跨域...")
        
        # 1. 能力树扫描
        tree = scan_capability_tree()
        self.ctx.capability_updates.append({
            "type": "capability-tree-scan",
            "timestamp": datetime.now().isoformat(),
            "total_genes": tree["total_genes"],
            "total_events": tree["total_events"],
            "categories": tree["categories"],
        })
        print(f"    能力树: {tree['total_genes']} Gene, {tree['total_events']} Event")
        
        # 2. 反劣化检查
        issues = anti_degeneration_check()
        for issue in issues:
            self.ctx.anti_degradation_findings.append(issue)
            print(f"    ⚠️ {issue['event']}: {', '.join(issue['issues'])}")
        
        if not issues:
            print(f"    ✅ 反劣化: 无风险")
        
        # 3. 跨域扫描
        candidates = cross_domain_scan()
        for c in candidates:
            self.ctx.cross_domain_hints.append(f"{c['gene1']} ↔ {c['gene2']} ({', '.join(c['shared_keywords'][:3])})")
        
        if candidates:
            print(f"    🔗 跨域候选: {len(candidates)} 对")
        else:
            print(f"    🔗 跨域: 无候选")
        
        # 4. 记录事件
        self.ctx.events_logged.append({
            "event_id": f"transcend-{datetime.now().strftime('%Y%m%d-%H%M')}",
            "type": "transcend-scan",
            "timestamp": datetime.now().isoformat(),
            "trigger": self.ctx.trigger,
            "genes_scanned": tree["total_genes"],
            "degradation_issues": len(issues),
            "cross_domain_candidates": len(candidates),
        })
        
        print(f"  [识·进] 完成")
        return self.ctx
