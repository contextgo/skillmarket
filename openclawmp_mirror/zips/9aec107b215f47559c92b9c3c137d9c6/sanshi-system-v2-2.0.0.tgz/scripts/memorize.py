#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 记忆采集/评分/迁移模块（识·记）
===========================================
从 workspace/memory/ 中读取每日记忆文件，按统一评分标准分级存储。

用法:
    python memorize.py              # 正常运行
    python memorize.py --dry-run    # 试运行（不修改文件）
    python memorize.py --days 3     # 只处理最近N天的记忆
"""

import os
import sys
import json
import re
from datetime import datetime, timedelta
from pathlib import Path

# === 配置 ===
WORKSPACE = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "workspace")
MEMORY_DIR = WORKSPACE / "memory"
REFERENCE_DIR = MEMORY_DIR / "reference"
ARCHIVE_DIR = MEMORY_DIR / "archive"
REPORTS_DIR = MEMORY_DIR / "reports"
MEMORY_MD = WORKSPACE / "MEMORY.md"
SCORING_FEEDBACK = MEMORY_DIR / "scoring-feedback.json"

# 三识系统根目录
SANSHI_ROOT = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "skills", "三识系统")
EVOLUTION_DIR = SANSHI_ROOT / "evolution"
GENES_DIR = EVOLUTION_DIR / "genes"
EVENTS_DIR = EVOLUTION_DIR / "events"

# === 评分关键词 ===
KEYWORDS = {
    10: ["重要决策", "关键经验", "用户要求", "必须记住", "核心原则", "红线", "⭐重要"],
    8:  ["修复", "解决方案", "成功", "验证", "最佳实践", "优化", "完成", "🧬进化"],
    6:  ["配置", "设置", "方法", "流程", "技巧", "工具", "📌保留"],
    4:  ["尝试", "测试", "探索", "学习"],
    2:  ["临时", "草稿", "待确认", "想法", "🗑️可删"],
}


def score_content(content: str, title: str = "") -> int:
    """统一9分制评分"""
    text = content + " " + title
    
    # 1. 检查明确标记
    for score, words in KEYWORDS.items():
        for word in words:
            if word in text:
                return min(score, 10)
    
    # 2. 关键词匹配
    score = 4  # 默认中档
    if any(kw in text for kw in KEYWORDS[10]):
        score = 9
    elif any(kw in text for kw in KEYWORDS[8]):
        score = 7
    elif any(kw in text for kw in KEYWORDS[6]):
        score = 6
    elif any(kw in text for kw in KEYWORDS[4]):
        score = 4
    else:
        score = 3
    
    # 3. 内容质量加成
    if "```" in text or "|---" in text:
        score = min(score + 1, 10)  # 结构化内容+1
    if "决策" in text or "结论" in text:
        score = min(score + 1, 10)  # 决策/结论+1
    
    # 4. 长度调整
    if len(text) < 100:
        score = max(score - 1, 1)
    elif len(text) > 1000:
        score = min(score + 1, 10)
    
    # 5. 反馈修正（自动学习用户纠正）
    if SCORING_FEEDBACK.exists():
        try:
            feedback = json.loads(SCORING_FEEDBACK.read_text(encoding="utf-8"))
            for corr in feedback.get("corrections", []):
                if corr.get("title") in title or corr.get("title") in content[:50]:
                    score = corr.get("correct_score", score)
                    # 记录反馈命中次数
                    corr["hit_count"] = corr.get("hit_count", 0) + 1
            SCORING_FEEDBACK.write_text(json.dumps(feedback, ensure_ascii=False, indent=2), encoding="utf-8")
        except:
            pass
    
    return max(1, min(score, 10))


def classify(score: int) -> str:
    """按分数返回分类标签"""
    if score >= 8:
        return "core"
    elif score >= 5:
        return "reference"
    elif score >= 3:
        return "temporary"
    else:
        return "noise"


def process_memory_file(filepath: Path, dry_run: bool = False) -> dict:
    """处理单个记忆文件，评分+分类"""
    content = filepath.read_text(encoding="utf-8")
    title = filepath.stem
    score = score_content(content, title)
    category = classify(score)
    
    # 提取前200字符作为摘要
    summary = content[:200].replace("\n", " ").strip()
    if len(content) > 200:
        summary += "..."
    
    result = {
        "file": filepath.name,
        "title": title,
        "score": score,
        "category": category,
        "summary": summary,
    }
    
    if not dry_run:
        # 按分类移动/复制
        if category == "core":
            # 核心记忆 → MEMORY.md（追加）
            ensure_memory_section(filepath, content)
        elif category == "reference":
            # 参考记忆 → reference/
            ref_path = REFERENCE_DIR / f"ref-{filepath.stem}.md"
            if not ref_path.exists():
                REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
                ref_path.write_text(content, encoding="utf-8")
        elif category == "temporary":
            # 临时记忆 → 保留原位，由heartbeat衰减
            pass
        elif category == "noise":
            # 噪声 → archive/
            archive_path = ARCHIVE_DIR / f"archived-{filepath.stem}.md"
            ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
            if not archive_path.exists():
                archive_path.write_text(content, encoding="utf-8")
    
    return result


def ensure_memory_section(filepath: Path, content: str):
    """确保核心记忆写入 MEMORY.md"""
    if not MEMORY_MD.exists():
        return
    
    existing = MEMORY_MD.read_text(encoding="utf-8")
    # 避免重复写入（检查标题是否已存在）
    if filepath.stem in existing:
        return
    
    # 追加到 MEMORY.md 末尾
    section = f"\n\n## 📌 {filepath.stem} (2026-04-30)\n\n{content[:500]}\n"
    with open(MEMORY_MD, "a", encoding="utf-8") as f:
        f.write(section)


def run(dry_run: bool = False, days: int = 7) -> list:
    """主执行流程"""
    print(f"{'[试运行] ' if dry_run else ''}三识系统 · 记忆采集/评分/迁移")
    print(f"{'='*50}")
    
    today = datetime.now().date()
    results = []
    
    # 扫描最近N天的记忆文件
    for i in range(days):
        date = today - timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        filepath = MEMORY_DIR / f"{date_str}.md"
        
        if filepath.exists():
            r = process_memory_file(filepath, dry_run)
            results.append(r)
            emoji = {"core": "⭐", "reference": "📌", "temporary": "📝", "noise": "🗑️"}[r["category"]]
            print(f"  {emoji} [{r['score']}/9] {r['file']} → {r['category']}")
        else:
            print(f"  - {date_str}.md (不存在)")
    
    # 统计
    print(f"\n{'='*50}")
    stats = {}
    for r in results:
        cat = r["category"]
        stats[cat] = stats.get(cat, 0) + 1
    
    print(f"处理文件: {len(results)} 个")
    for cat, count in sorted(stats.items(), reverse=True):
        print(f"  {cat}: {count}")
    
    # 生成报告
    if not dry_run:
        REPORTS_DIR.mkdir(parents=True, exist_ok=True)
        report = {
            "timestamp": datetime.now().isoformat(),
            "mode": "dry-run" if dry_run else "normal",
            "days_scanned": days,
            "files_processed": len(results),
            "results": results,
            "statistics": stats,
        }
        report_path = REPORTS_DIR / f"memory-migration-{today}.json"
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"\n报告: {report_path}")
    
    return results


if __name__ == "__main__":
    dry_run = "--dry-run" in sys.argv
    days = 7
    for arg in sys.argv:
        if arg.startswith("--days="):
            days = int(arg.split("=")[1])
        elif arg == "--days" and sys.argv.index(arg) + 1 < len(sys.argv):
            days = int(sys.argv[sys.argv.index(arg) + 1])
    
    run(dry_run=dry_run, days=days)


# ============================================================================
# Plugin 模式（v2.0 融合版 — 被 sanshi_engine.py 调用）
# ============================================================================
class MemorizePlugin:
    """识·记 插件 — 接收 SanshiContext，返回更新后的 Context"""
    
    def __init__(self, ctx):
        self.ctx = ctx
    
    def run(self, days=7, dry_run=False):
        """执行记忆采集，结果写入 ctx"""
        print(f"  [识·记] 扫描最近 {days} 天记忆...")
        
        today = datetime.now().date()
        for i in range(days):
            date = today - timedelta(days=i)
            date_str = date.strftime("%Y-%m-%d")
            filepath = MEMORY_DIR / f"{date_str}.md"
            
            if filepath.exists():
                content = filepath.read_text(encoding="utf-8", errors="replace")
                score = score_content(content, filepath.stem)
                category = classify(score)
                
                # 写入 Context（不落盘，由引擎统一 persist）
                self.ctx.memories_captured.append({
                    "file": filepath.name,
                    "title": filepath.stem,
                    "score": score,
                    "category": category,
                    "summary": content[:200].replace("\n", " ").strip(),
                })
                self.ctx.memory_scores[filepath.stem] = score
                
                emoji = {"core": "⭐", "reference": "📌", "temporary": "📝", "noise": "🗑️"}[category]
                print(f"    {emoji} [{score}/10] {filepath.stem} → {category}")
        
        # 生成 Event
        if self.ctx.memories_captured:
            core_count = sum(1 for m in self.ctx.memories_captured if m["category"] == "core")
            self.ctx.events_logged.append({
                "event_id": f"memorize-{datetime.now().strftime('%Y%m%d-%H%M')}",
                "type": "memory-capture",
                "timestamp": datetime.now().isoformat(),
                "trigger": self.ctx.trigger,
                "memories_captured": len(self.ctx.memories_captured),
                "core_memories": core_count,
            })
        
        print(f"  [识·记] 完成: {len(self.ctx.memories_captured)} 条记忆")
        return self.ctx
