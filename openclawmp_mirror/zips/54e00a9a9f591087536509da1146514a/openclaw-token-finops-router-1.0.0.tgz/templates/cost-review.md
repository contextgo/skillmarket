# Weekly Cost Review

- Top 5 costly tasks
- Model usage distribution
- Cache hit rate
- Optimization actions (owner + deadline)
