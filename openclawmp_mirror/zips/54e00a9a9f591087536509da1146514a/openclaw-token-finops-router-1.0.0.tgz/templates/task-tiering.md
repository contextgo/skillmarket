# Task Tiering

## Tier A（高风险/高价值）
- 质量优先，禁止自动降级

## Tier B（日常任务）
- 质量与成本平衡，可按策略降级

## Tier C（批处理/低风险）
- 成本优先，fallback 优先
