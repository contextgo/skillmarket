# Budget Policy

- Daily Soft Cap:
- Daily Hard Cap:
- Weekly Soft Cap:
- Weekly Hard Cap:

Trigger Actions:
- Soft Cap: alert + review
- Hard Cap: auto downgrade + freeze non-critical jobs
