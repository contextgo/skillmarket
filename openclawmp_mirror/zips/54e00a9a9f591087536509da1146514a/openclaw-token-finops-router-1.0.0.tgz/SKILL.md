---
name: openclaw-token-finops-router
description: "为 OpenClaw 建立 Token FinOps 路由：预算、分层模型、缓存与异常控费。"
version: 1.0.0
type: skill
displayName: "OpenClaw Token FinOps 路由器"
tags: "openclaw, finops, token, model-routing, cost"
---

# OpenClaw Token FinOps 路由器

目标：在保证可用性的同时，把模型成本变成可观测、可控制、可优化。

## 颠覆点

不再“默认上最强模型”，而是按任务价值密度分层路由：

- 高风险任务：质量优先
- 日常任务：均衡质量与成本
- 批处理任务：成本优先

## 适用场景

- Token 成本增长过快
- 模型选型缺乏策略
- 没有预算告警与降级机制

## 核心机制

1. **预算护栏**：日/周预算阈值
2. **路由分层**：任务等级对应模型档位
3. **缓存优先**：高重复场景先命中缓存
4. **异常控费**：预算超阈值自动降级
5. **成本复盘**：周度回看高成本任务类型

## 最小落地步骤

### 1) 建立任务分级

参考 `templates/task-tiering.md`，把任务分为 A/B/C 三档。

### 2) 建立模型矩阵

- A 档：primary 强模型
- B 档：primary/fallback 混合
- C 档：fallback 优先

### 3) 设置预算阈值

参考 `templates/budget-policy.md`：

- soft cap：触发告警
- hard cap：触发自动降级

### 4) 启用成本记录

每个任务记录：

- 使用模型
- 输入/输出 token
- 耗时
- 任务档位

### 5) 周度优化

找出 Top 成本任务，优先优化：

- 提示词冗余
- 模型档位过高
- 缓存命中不足

## 风险边界

- 过度降级可能影响关键任务质量
- 成本优化不能牺牲安全与合规要求
- 预算策略需与业务优先级同步调整

## 关键收益

- 成本曲线更平滑
- 模型资源分配更合理
- 高价值任务获得稳定保障
