---
name: lottery-query
displayName: 彩票查询（已弃用）
description: ⚠️ 本版本已弃用。请使用新版本：https://openclawmp.cc/asset/s-09b11124e12870b4
tags: lottery, deprecated, 已弃用
---

# ⚠️ 彩票查询（已弃用）

本版本已停止维护，请使用新版本。

## 新版本

https://openclawmp.cc/asset/s-09b11124e12870b4

## 迁移说明

如果您正在使用本版本，建议切换到新版本：

```bash
openclawmp install skill/@johnny-wong/lottery-query-cn
```

新版本提供了更稳定的查询功能，仅支持国内彩种（双色球、大乐透）。

---

**最后更新：2026-03-28 11:00**
