#!/usr/bin/env python3
"""
Clawvard Exam Skill - Python implementation
This script provides functionality to take the Clawvard entrance exam.
"""

import json
import requests
from typing import Dict, List, Optional, Tuple

class ClawvardExam:
    """Clawvard入学考试处理器"""
    
    BASE_URL = "https://clawvard.school/api/exam"
    
    def __init__(self, agent_name: str = "OpenClaw Agent"):
        self.agent_name = agent_name
        self.exam_id = None
        self.current_hash = None
        self.progress = {"current": 0, "total": 16}
        
    def start_exam(self) -> Tuple[bool, str, List[Dict]]:
        """开始考试"""
        try:
            response = requests.post(
                f"{self.BASE_URL}/start",
                headers={"Content-Type": "application/json"},
                json={"agentName": self.agent_name},
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                self.exam_id = data.get("examId")
                self.current_hash = data.get("hash")
                batch = data.get("batch", [])
                self.progress["current"] = 0
                return True, "考试开始成功", batch
            else:
                return False, f"考试开始失败: {response.status_code}", []
                
        except Exception as e:
            return False, f"考试开始异常: {str(e)}", []
    
    def submit_batch_answer(self, answers: List[Dict]) -> Tuple[bool, str, Optional[List[Dict]]]:
        """提交批次答案"""
        if not self.exam_id or not self.current_hash:
            return False, "考试未开始或会话无效", None
            
        try:
            response = requests.post(
                f"{self.BASE_URL}/batch-answer",
                headers={"Content-Type": "application/json"},
                json={
                    "examId": self.exam_id,
                    "hash": self.current_hash,
                    "answers": answers
                },
                timeout=30
            )
            
            if response.status_code == 200:
                data = response.json()
                self.current_hash = data.get("hash")
                self.progress = data.get("progress", self.progress)
                next_batch = data.get("nextBatch")
                
                if data.get("examComplete", False):
                    claim_url = data.get("claimUrl", "")
                    return True, f"考试完成！查看成绩单: https://clawvard.school{claim_url}", None
                else:
                    return True, f"批次提交成功 (进度: {self.progress['current']}/{self.progress['total']})", next_batch
            else:
                return False, f"批次提交失败: {response.status_code}", None
                
        except Exception as e:
            return False, f"批次提交异常: {str(e)}", None
    
    def get_exam_status(self) -> Dict:
        """获取考试状态"""
        return {
            "exam_id": self.exam_id,
            "agent_name": self.agent_name,
            "progress": self.progress,
            "current_hash": self.current_hash[:10] + "..." if self.current_hash else None
        }

def main():
    """主函数 - 测试用"""
    exam = ClawvardExam("Test Agent")
    
    print("🦞 Clawvard入学考试测试")
    print("=" * 50)
    
    # 开始考试
    success, message, batch = exam.start_exam()
    print(f"开始考试: {'✅' if success else '❌'} {message}")
    
    if success and batch:
        print(f"收到批次: {len(batch)} 个问题")
        for i, question in enumerate(batch):
            print(f"  {i+1}. [{question.get('dimension', '未知')}] {question.get('prompt', '')[:50]}...")
    
    # 显示状态
    status = exam.get_exam_status()
    print(f"\n考试状态: {json.dumps(status, indent=2, ensure_ascii=False)}")

if __name__ == "__main__":
    main()