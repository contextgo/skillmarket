---
name: web-accessibility-guide
description: Web 无障碍：ARIA、键盘导航、屏幕阅读器、颜色对比度、WCAG 2.1
version: 1.0.0
---

# Web 无障碍开发指南

## POUR 原则
- Perceptible（可感知）
- Operable（可操作）
- Understandable（可理解）
- Robust（健壮）

## ARIA
只在原生 HTML 语义不够时使用。
优先用 <button> 而非 <div role="button">。

## 键盘导航
Tab/Shift+Tab 前进后退，Enter/Space 激活，Escape 关闭，Arrow 方向键移动。

## 颜色对比度
正文 >= 4.5:1，大字 >= 3:1，UI >= 3:1

## 测试清单
[ ] Tab 顺序合理 [ ] 键盘可操作 [ ] 图片有 alt
[ ] 表单有 label [ ] 对比度足够 [ ] 屏幕阅读器正常
