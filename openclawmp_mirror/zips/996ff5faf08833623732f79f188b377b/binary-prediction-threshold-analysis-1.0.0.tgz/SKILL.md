---
name: binary-prediction-threshold-analysis
description: "Binary prediction market threshold crossing analysis methodology"
version: 1.0.0
---

# binary prediction threshold analysis

Systematic methodology for analyzing when binary prediction market probabilities cross key thresholds and what each crossing means for decision making.

## Threshold Levels and Their Significance

| Level | Meaning | Typical Market Phase |
|-------|---------|---------------------|
| 90-100% | Near certainty | Event effectively priced in |
| 75-90% | High probability | Watch for reversal signals |
| 50-75% | Likely | Active market with real uncertainty |
| 25-50% | Possible | Below consensus, contrarian opportunity |
| 10-25% | Unlikely | Tail risk pricing |
| 0-10% | Near impossible | Extreme tail, often mispriced |

## Crossing Patterns

- **Upward 50% Cross**: First time above 50% is a major signal (market shifts from 'unlikely' to 'likely')
- **Oscillation at 50%**: Multiple rounds crossing 50% in both directions = maximum uncertainty
- **100% Confirmation**: Event fully priced in, new information only affects related markets
- **Rapid Reversal from 50%**: Crossing 50% then immediately returning = false signal

## Rate of Change Metrics

- Track pp (percentage point) changes per round
- >5pp single-round move = high-impact event
- >10pp = extremely significant (3.8-sigma equivalent)
- Consecutive same-direction moves >3 rounds = trend confirmation
