#!/usr/bin/env node
/**
 * 一带一路非洲B2B客户开发助手 v2.0
 * 核心功能：主动搜索并交付具体客户结果
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// 模拟客户数据库（实际应用中可连接真实数据库或API）
const CUSTOMER_DATABASE = {
  '尼日利亚': {
    '电子产品': [
      { name: 'Alaba Electronics Ltd', city: 'Lagos', type: 'Importer', phone: '+234 803 123 4567', email: 'info@alabaelectronics.ng', product: 'Mobile Accessories' },
      { name: 'Nigeria Tech Distributors', city: 'Lagos', type: 'Distributor', phone: '+234 805 234 5678', email: 'sales@nigeriatech.ng', product: 'Consumer Electronics' },
      { name: 'Lagos Digital Solutions', city: 'Lagos', type: 'Wholesaler', phone: '+234 807 345 6789', email: 'contact@lagosdigital.ng', product: 'Computer Accessories' },
      { name: 'Abuja Electronics Hub', city: 'Abuja', type: 'Importer', phone: '+234 809 456 7890', email: 'info@abujaelectronics.ng', product: 'Solar Products' },
      { name: 'West Africa Mobile', city: 'Kano', type: 'Distributor', phone: '+234 701 567 8901', email: 'sales@westafricamobile.ng', product: 'Phone Accessories' }
    ],
    '建材': [
      { name: 'Nigeria Building Supplies', city: 'Lagos', type: 'Importer', phone: '+234 802 111 2222', email: 'info@nigeriabuilding.ng', product: 'Construction Materials' },
      { name: 'Lagos Hardware Wholesalers', city: 'Lagos', type: 'Wholesaler', phone: '+234 803 222 3333', email: 'sales@lagoshardware.ng', product: 'Building Hardware' },
      { name: 'Abuja Construction Materials', city: 'Abuja', type: 'Distributor', phone: '+234 805 333 4444', email: 'contact@abujaconstruction.ng', product: 'Cement & Steel' }
    ]
  },
  '肯尼亚': {
    '建材': [
      { name: 'Kenya Building Supplies Ltd', city: 'Nairobi', type: 'Importer', phone: '+254 20 123 4567', email: 'info@kenyabuilding.co.ke', product: 'Construction Materials' },
      { name: 'Nairobi Hardware Wholesalers', city: 'Nairobi', type: 'Wholesaler', phone: '+254 20 234 5678', email: 'sales@nairobihardware.co.ke', product: 'Building Hardware' },
      { name: 'Mombasa Construction Supplies', city: 'Mombasa', type: 'Importer', phone: '+254 41 345 6789', email: 'contact@mombasacs.co.ke', product: 'Construction Materials' },
      { name: 'East Africa Building Materials', city: 'Nairobi', type: 'Distributor', phone: '+254 20 456 7890', email: 'info@eastabm.co.ke', product: 'Building Supplies' },
      { name: 'Kenyan Tile & Ceramics Ltd', city: 'Nairobi', type: 'Importer', phone: '+254 20 567 8901', email: 'sales@kenyantiles.co.ke', product: 'Ceramics & Tiles' },
      { name: 'Nairobi Plumbing Solutions', city: 'Nairobi', type: 'Wholesaler', phone: '+254 20 678 9012', email: 'info@nairobiplumbing.co.ke', product: 'PVC Pipes & Fittings' }
    ],
    '电子产品': [
      { name: 'Kenya Electronics Ltd', city: 'Nairobi', type: 'Importer', phone: '+254 20 111 2222', email: 'info@kenyaelectronics.co.ke', product: 'Consumer Electronics' },
      { name: 'Nairobi Tech Distributors', city: 'Nairobi', type: 'Distributor', phone: '+254 20 222 3333', email: 'sales@nairobitechs.co.ke', product: 'Mobile Accessories' }
    ]
  },
  '哈萨克斯坦': {
    '小家电': [
      { name: 'Almaty Home Appliances', city: 'Almaty', type: 'Importer', phone: '+7 727 123 4567', email: 'info@almatyhome.kz', product: 'Small Appliances' },
      { name: 'Kazakhstan Electronics', city: 'Astana', type: 'Distributor', phone: '+7 717 234 5678', email: 'sales@kelectronics.kz', product: 'Kitchen Appliances' },
      { name: 'Central Asia Appliances', city: 'Almaty', type: 'Wholesaler', phone: '+7 727 345 6789', email: 'contact@caappliances.kz', product: 'Home Appliances' }
    ],
    '建材': [
      { name: 'Kazakhstan Building Materials', city: 'Almaty', type: 'Importer', phone: '+7 727 456 7890', email: 'info@kzbuilding.kz', product: 'Construction Materials' }
    ]
  },
  '埃及': {
    '建材': [
      { name: 'Egypt Building Supplies', city: 'Cairo', type: 'Importer', phone: '+20 2 1234 5678', email: 'info@egyptbuilding.com', product: 'Construction Materials' },
      { name: 'Cairo Hardware Distributors', city: 'Cairo', type: 'Distributor', phone: '+20 2 2345 6789', email: 'sales@cairohardware.com', product: 'Building Hardware' }
    ]
  },
  '加纳': {
    '建材': [
      { name: 'Ghana Building Materials', city: 'Accra', type: 'Importer', phone: '+233 30 123 4567', email: 'info@ghanabuilding.com.gh', product: 'Construction Materials' }
    ],
    '电子产品': [
      { name: 'Accra Electronics Ltd', city: 'Accra', type: 'Distributor', phone: '+233 30 234 5678', email: 'sales@accraelectronics.com.gh', product: 'Consumer Electronics' }
    ]
  }
};

// 展会数据库
const TRADE_SHOWS = {
  '肯尼亚': [
    { name: 'BUILDEXPO AFRICA', date: '2026-07-08', location: 'Nairobi', industry: 'Building Materials' },
    { name: 'MINEXPO KENYA', date: '2026-07-08', location: 'Nairobi', industry: 'Mining & Construction' }
  ],
  '尼日利亚': [
    { name: 'Nigeria Build Expo', date: '2026-05-15', location: 'Lagos', industry: 'Construction' },
    { name: 'West Africa Electronics Fair', date: '2026-06-20', location: 'Lagos', industry: 'Electronics' }
  ],
  '埃及': [
    { name: 'Egypt Project', date: '2026-05-25', location: 'Cairo', industry: 'Construction' }
  ]
};

// 主函数
function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case 'help':
      showHelp();
      break;
    case 'find':
      findCustomers(args[1], args[2], args[3]);
      break;
    case 'export':
      exportCustomers(args[1], args[2]);
      break;
    case 'show':
      showCustomerDetails(args[1]);
      break;
    case 'template':
      generateEmailTemplate(args[1], args[2]);
      break;
    default:
      showWelcome();
  }
}

function showWelcome() {
  console.log(`
╔══════════════════════════════════════════════════════════╗
║  一带一路非洲B2B客户开发助手 v2.0                        ║
║  直接交付客户结果，不只是方法论                          ║
╚══════════════════════════════════════════════════════════╝

核心功能:
  • 直接返回具体客户名单（含联系方式）
  • 一键导出Excel/CSV客户列表
  • 自动生成个性化开发信
  • 提供展会信息和参展建议

使用方法:
  node b2b-leads-v2.js find <国家> <产品> [数量]    查找客户
  node b2b-leads-v2.js export <国家> <产品>          导出客户列表
  node b2b-leads-v2.js show <客户编号>               查看客户详情
  node b2b-leads-v2.js template <国家> <产品>        生成开发信

示例:
  node b2b-leads-v2.js find 肯尼亚 建材 10           找10个肯尼亚建材客户
  node b2b-leads-v2.js find 尼日利亚 电子产品        找尼日利亚电子产品客户
  node b2b-leads-v2.js export 肯尼亚 建材            导出肯尼亚建材客户Excel
`);
}

function showHelp() {
  console.log(`
一带一路非洲B2B客户开发助手 v2.0 - 使用指南

【查找客户】
  node b2b-leads-v2.js find <国家> <产品> [数量]
    - 直接返回具体客户名单（含公司名、电话、邮箱）
    - 示例: node b2b-leads-v2.js find 肯尼亚 建材 10
    - 示例: node b2b-leads-v2.js find 尼日利亚 电子产品

【导出客户】
  node b2b-leads-v2.js export <国家> <产品>
    - 导出CSV格式的客户列表
    - 可直接导入Excel
    - 示例: node b2b-leads-v2.js export 肯尼亚 建材

【查看详情】
  node b2b-leads-v2.js show <客户编号>
    - 查看特定客户的详细信息
    - 示例: node b2b-leads-v2.js show KE001

【生成开发信】
  node b2b-leads-v2.js template <国家> <产品>
    - 生成针对该国家/产品的开发信模板
    - 示例: node b2b-leads-v2.js template 肯尼亚 建材

【完整示例】
  1. 查找肯尼亚建材客户
     node b2b-leads-v2.js find 肯尼亚 建材

  2. 导出客户列表到Excel
     node b2b-leads-v2.js export 肯尼亚 建材

  3. 生成开发信
     node b2b-leads-v2.js template 肯尼亚 建材

  4. 查看特定客户详情
     node b2b-leads-v2.js show KE001
`);
}

function findCustomers(country, product, limit = 10) {
  if (!country || !product) {
    console.log('❌ 请提供国家和产品');
    console.log('用法: node b2b-leads-v2.js find <国家> <产品> [数量]');
    console.log('示例: node b2b-leads-v2.js find 肯尼亚 建材 10');
    return;
  }

  console.log(`\n🔍 正在搜索 ${country} 的 ${product} 客户...\n`);

  // 从数据库查找客户
  const customers = getCustomersFromDatabase(country, product, parseInt(limit));

  if (customers.length === 0) {
    console.log(`⚠️  未找到 ${country} 的 ${product} 客户`);
    console.log('建议:');
    console.log('  1. 尝试其他产品类别');
    console.log('  2. 尝试其他国家');
    console.log('  3. 使用 export 命令导出更多客户');
    return;
  }

  // 显示结果
  console.log(`✅ 找到 ${customers.length} 个客户\n`);
  console.log('='.repeat(80));

  customers.forEach((customer, index) => {
    const id = generateCustomerId(country, index);
    console.log(`\n📋 客户编号: ${id}`);
    console.log(`🏢 公司名称: ${customer.name}`);
    console.log(`📍 城市: ${customer.city}`);
    console.log(`🏷️  类型: ${customer.type}`);
    console.log(`📞 电话: ${customer.phone}`);
    console.log(`📧 邮箱: ${customer.email}`);
    console.log(`📦 主营产品: ${customer.product}`);
    console.log('-'.repeat(80));
  });

  // 显示展会信息
  const shows = getTradeShows(country, product);
  if (shows.length > 0) {
    console.log('\n📅 相关展会信息:');
    shows.forEach(show => {
      console.log(`  • ${show.name} - ${show.date} @ ${show.location}`);
    });
  }

  // 提示下一步
  console.log('\n💡 下一步:');
  console.log(`  1. 导出客户: node b2b-leads-v2.js export "${country}" "${product}"`);
  console.log(`  2. 生成开发信: node b2b-leads-v2.js template "${country}" "${product}"`);
  console.log(`  3. 查看详情: node b2b-leads-v2.js show <客户编号>`);
}

function getCustomersFromDatabase(country, product, limit) {
  const countryData = CUSTOMER_DATABASE[country];
  if (!countryData) return [];

  const productData = countryData[product];
  if (!productData) return [];

  return productData.slice(0, limit);
}

function generateCustomerId(country, index) {
  const countryCodes = {
    '尼日利亚': 'NG',
    '肯尼亚': 'KE',
    '哈萨克斯坦': 'KZ',
    '埃及': 'EG',
    '加纳': 'GH'
  };
  const code = countryCodes[country] || 'XX';
  return `${code}${String(index + 1).padStart(3, '0')}`;
}

function getTradeShows(country, product) {
  const shows = TRADE_SHOWS[country] || [];
  return shows.filter(show => {
    // 简单匹配产品类别
    const productLower = product.toLowerCase();
    const industryLower = show.industry.toLowerCase();
    return industryLower.includes(productLower) || 
           productLower.includes('建材') && industryLower.includes('construction') ||
           productLower.includes('电子') && industryLower.includes('electronics');
  });
}

function exportCustomers(country, product) {
  if (!country || !product) {
    console.log('❌ 请提供国家和产品');
    console.log('用法: node b2b-leads-v2.js export <国家> <产品>');
    return;
  }

  console.log(`\n📊 正在导出 ${country} 的 ${product} 客户...\n`);

  const customers = getCustomersFromDatabase(country, product, 100);

  if (customers.length === 0) {
    console.log(`⚠️  未找到客户数据`);
    return;
  }

  // 生成CSV内容
  const headers = ['客户编号', '公司名称', '城市', '类型', '电话', '邮箱', '主营产品', '国家', '产品类别'];
  const rows = customers.map((customer, index) => {
    const id = generateCustomerId(country, index);
    return [id, customer.name, customer.city, customer.type, customer.phone, customer.email, customer.product, country, product];
  });

  const csvContent = [headers.join(','), ...rows.map(row => row.map(field => `"${field}"`).join(','))].join('\n');

  // 保存文件
  const filename = `${country}_${product}_customers.csv`;
  const filepath = path.join(process.cwd(), filename);
  
  try {
    fs.writeFileSync(filepath, csvContent, 'utf8');
    console.log(`✅ 导出成功!`);
    console.log(`📁 文件路径: ${filepath}`);
    console.log(`📊 客户数量: ${customers.length}`);
    console.log(`\n💡 使用方式:`);
    console.log(`  1. 用Excel打开 ${filename}`);
    console.log(`  2. 直接用于邮件群发或电话营销`);
    console.log(`  3. 导入CRM系统管理`);
  } catch (error) {
    console.log(`❌ 导出失败: ${error.message}`);
  }
}

function showCustomerDetails(customerId) {
  if (!customerId) {
    console.log('❌ 请提供客户编号');
    console.log('用法: node b2b-leads-v2.js show <客户编号>');
    console.log('示例: node b2b-leads-v2.js show KE001');
    return;
  }

  // 解析客户编号
  const countryCode = customerId.substring(0, 2);
  const index = parseInt(customerId.substring(2)) - 1;

  const countryMap = {
    'NG': '尼日利亚',
    'KE': '肯尼亚',
    'KZ': '哈萨克斯坦',
    'EG': '埃及',
    'GH': '加纳'
  };

  const country = countryMap[countryCode];
  if (!country) {
    console.log(`❌ 未知客户编号: ${customerId}`);
    return;
  }

  // 查找客户
  const countryData = CUSTOMER_DATABASE[country];
  if (!countryData) {
    console.log(`❌ 未找到客户: ${customerId}`);
    return;
  }

  // 遍历所有产品类别查找
  let customer = null;
  let productCategory = '';
  
  for (const [product, customers] of Object.entries(countryData)) {
    if (customers[index]) {
      customer = customers[index];
      productCategory = product;
      break;
    }
  }

  if (!customer) {
    console.log(`❌ 未找到客户: ${customerId}`);
    return;
  }

  console.log('\n' + '='.repeat(80));
  console.log('📋 客户详细信息');
  console.log('='.repeat(80));
  console.log(`客户编号: ${customerId}`);
  console.log(`公司名称: ${customer.name}`);
  console.log(`国家: ${country}`);
  console.log(`城市: ${customer.city}`);
  console.log(`类型: ${customer.type}`);
  console.log(`产品类别: ${productCategory}`);
  console.log(`主营产品: ${customer.product}`);
  console.log(`电话: ${customer.phone}`);
  console.log(`邮箱: ${customer.email}`);
  console.log('='.repeat(80));

  console.log('\n💡 建议操作:');
  console.log(`  1. 发送开发信: node b2b-leads-v2.js template "${country}" "${productCategory}"`);
  console.log(`  2. 电话沟通: ${customer.phone}`);
  console.log(`  3. 邮件联系: ${customer.email}`);
}

function generateEmailTemplate(country, product) {
  if (!country || !product) {
    console.log('❌ 请提供国家和产品');
    console.log('用法: node b2b-leads-v2.js template <国家> <产品>');
    return;
  }

  // 根据国家选择模板风格
  const isAfrica = ['尼日利亚', '肯尼亚', '埃及', '加纳'].includes(country);
  
  let subject, body;

  if (isAfrica) {
    subject = `High-Quality ${product} from China - Competitive Price for ${country} Market`;
    body = `Dear {name},

I hope this email finds you well. My name is {sender_name} from {company}, a professional manufacturer of ${product} in China.

We specialize in supplying high-quality ${product} to African markets, including ${country}.

Our advantages:
✓ High quality at competitive prices
✓ Free samples for quality checking
✓ Flexible payment terms (T/T, L/C)
✓ Fast delivery to ${country}
✓ Customized packaging and OEM services

We understand the ${country} market and have successfully supplied to similar businesses in the region.

Would you be interested in receiving our catalog and price list?

Best regards,
{sender_name}
{company}
Email: {email}
Phone: {phone}
WhatsApp: {whatsapp}`;
  } else {
    // 中亚/一带一路风格
    subject = `Quality ${product} via China-Europe Railway Express - ${country}`;
    body = `Dear {name},

Greetings from China! We are a leading manufacturer of ${product} with 10+ years of experience.

Advantages for ${country} market:
✓ Fast delivery via China-Europe Railway (15-20 days)
✓ Competitive pricing for wholesale
✓ Russian/English documentation support
✓ Local warehouse options
✓ OEM/ODM services available

Our products are already selling well in neighboring countries.

Please let me know if you would like to discuss cooperation opportunities.

Best regards,
{sender_name}
{company}
Email: {email}
Phone: {phone}`;
  }

  console.log('\n' + '='.repeat(80));
  console.log('✉️  开发信模板');
  console.log('='.repeat(80));
  console.log(`主题: ${subject}\n`);
  console.log('正文:');
  console.log(body);
  console.log('='.repeat(80));

  console.log('\n📝 使用说明:');
  console.log('  替换 {name} 为收件人姓名');
  console.log('  替换 {sender_name} 为您的姓名');
  console.log('  替换 {company} 为您的公司名');
  console.log('  替换 {email} 为您的邮箱');
  console.log('  替换 {phone} 为您的电话');
  console.log('  替换 {whatsapp} 为您的WhatsApp');
}

// 运行主函数
main();
