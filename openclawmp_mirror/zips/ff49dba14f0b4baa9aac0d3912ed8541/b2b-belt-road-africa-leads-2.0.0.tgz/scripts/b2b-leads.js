#!/usr/bin/env node
/**
 * 一带一路非洲B2B客户开发助手
 * 核心脚本 - 提供客户搜索、管理和开发信功能
 */

const fs = require('fs');
const path = require('path');

// 非洲市场数据源
const AFRICA_DATA = {
  north: {
    name: '北非',
    countries: [
      { code: 'EG', name: '埃及', nameEn: 'Egypt', yellowPages: 'egypt.yellowpages.com', lang: ['ar', 'en'] },
      { code: 'DZ', name: '阿尔及利亚', nameEn: 'Algeria', yellowPages: 'pagesjaunes-dz.com', lang: ['fr', 'ar'] },
      { code: 'MA', name: '摩洛哥', nameEn: 'Morocco', yellowPages: 'yellowpages.ma', lang: ['fr', 'ar'] },
      { code: 'TN', name: '突尼斯', nameEn: 'Tunisia', yellowPages: 'yellowpages-tunisia.com', lang: ['fr', 'ar'] }
    ]
  },
  west: {
    name: '西非',
    countries: [
      { code: 'NG', name: '尼日利亚', nameEn: 'Nigeria', yellowPages: 'yellowpages.ng', lang: ['en'], cities: ['Lagos', 'Abuja', 'Kano'] },
      { code: 'GH', name: '加纳', nameEn: 'Ghana', yellowPages: 'ghanayello.com', lang: ['en'], cities: ['Accra', 'Kumasi'] },
      { code: 'CI', name: '科特迪瓦', nameEn: 'Ivory Coast', yellowPages: 'yellowpages-ci.com', lang: ['fr'] }
    ]
  },
  east: {
    name: '东非',
    countries: [
      { code: 'KE', name: '肯尼亚', nameEn: 'Kenya', yellowPages: 'yellowpageskenya.com', lang: ['en', 'sw'], cities: ['Nairobi', 'Mombasa'] },
      { code: 'TZ', name: '坦桑尼亚', nameEn: 'Tanzania', yellowPages: 'yellowpages-tanzania.com', lang: ['en', 'sw'], cities: ['Dar es Salaam'] },
      { code: 'ET', name: '埃塞俄比亚', nameEn: 'Ethiopia', yellowPages: 'ethiopiayellowpages.com', lang: ['en', 'am'] }
    ]
  },
  south: {
    name: '南非',
    countries: [
      { code: 'ZA', name: '南非', nameEn: 'South Africa', yellowPages: 'yellosa.com', lang: ['en'], cities: ['Johannesburg', 'Cape Town', 'Durban'] }
    ]
  }
};

// 一带一路数据源
const BELT_ROAD_DATA = {
  central_asia: {
    name: '中亚',
    countries: [
      { code: 'KZ', name: '哈萨克斯坦', nameEn: 'Kazakhstan', platforms: ['qaztrade.kz', 'atameken.kz', 'kaspi.kz'], lang: ['ru', 'kk'], cities: ['Almaty', 'Astana'] },
      { code: 'UZ', name: '乌兹别克斯坦', nameEn: 'Uzbekistan', platforms: ['uztrade.uz', 'uzexpo.uz'], lang: ['ru', 'uz'], cities: ['Tashkent'] },
      { code: 'KG', name: '吉尔吉斯斯坦', nameEn: 'Kyrgyzstan', platforms: ['trade.gov.kg'], lang: ['ru', 'ky'] }
    ]
  },
  southeast_asia: {
    name: '东南亚',
    countries: [
      { code: 'VN', name: '越南', nameEn: 'Vietnam', yellowPages: 'yellowpages.vn', lang: ['vi'], cities: ['Ho Chi Minh City', 'Hanoi'] },
      { code: 'TH', name: '泰国', nameEn: 'Thailand', yellowPages: 'yellowpages.co.th', lang: ['th', 'en'], cities: ['Bangkok'] },
      { code: 'ID', name: '印尼', nameEn: 'Indonesia', yellowPages: 'yellowpages.co.id', lang: ['id'], cities: ['Jakarta'] },
      { code: 'MY', name: '马来西亚', nameEn: 'Malaysia', yellowPages: 'yellowpages.my', lang: ['ms', 'en', 'zh'], cities: ['Kuala Lumpur'] },
      { code: 'PH', name: '菲律宾', nameEn: 'Philippines', yellowPages: 'yellowpages.ph', lang: ['en', 'tl'], cities: ['Manila'] }
    ]
  },
  middle_east: {
    name: '中东',
    countries: [
      { code: 'AE', name: '阿联酋', nameEn: 'UAE', yellowPages: 'dubai-business-directory.com', lang: ['ar', 'en'], cities: ['Dubai', 'Abu Dhabi'] },
      { code: 'SA', name: '沙特阿拉伯', nameEn: 'Saudi Arabia', yellowPages: 'saudi-business-directory.com', lang: ['ar', 'en'], cities: ['Riyadh', 'Jeddah'] }
    ]
  }
};

// 热门品类
const HOT_CATEGORIES = {
  africa: ['建材', '家电', '农机', '太阳能', '手机配件', '纺织服装'],
  central_asia: ['小家电', '建材', '机械设备', '汽车配件'],
  southeast_asia: ['电子消费品', '家居用品', '机械设备', '原材料'],
  middle_east: ['建材', '家电', '新能源', '奢侈品']
};

// 搜索语法模板
const SEARCH_TEMPLATES = [
  '"{product}" + importers + {country}',
  '"{product}" + distributors + {country}',
  '"{product}" + wholesalers + {country}',
  '"{product}" + buyers + {country}',
  '"{product}" + dealers + {country}'
];

// 开发信模板
const EMAIL_TEMPLATES = {
  africa: {
    subject: 'High-Quality {product} from China - Competitive Price',
    body: `Dear {name},

I hope this email finds you well. My name is {sender_name} from {company}, a professional manufacturer of {product} in China.

We offer:
✓ High quality at competitive prices
✓ Free samples for quality checking
✓ Flexible payment terms
✓ Fast delivery to {country}

Our products are popular in {reference_country} and we believe they will be well-received in {target_country} too.

Would you be interested in receiving our catalog and price list?

Best regards,
{sender_name}
{company}
{contact}`
  },
  central_asia: {
    subject: 'Quality {product} via China-Europe Railway Express',
    body: `Dear {name},

Greetings from China! We are a leading manufacturer of {product} with 10+ years of experience.

Advantages for {country} market:
✓ Fast delivery via China-Europe Railway (15-20 days)
✓ Competitive pricing for wholesale
✓ Russian/English documentation support
✓ Local warehouse options in Almaty

Our products are already selling well in Kazakhstan and Uzbekistan.

Please let me know if you would like to discuss cooperation opportunities.

Best regards,
{sender_name}
{company}`
  },
  southeast_asia: {
    subject: '{product} Supplier - RCEP Benefits & Fast Shipping',
    body: `Dear {name},

We are a professional {product} manufacturer from China, serving Southeast Asian markets for 5+ years.

Benefits for you:
✓ RCEP tariff advantages
✓ 7-10 days shipping to {country}
✓ Local language support (English/Chinese)
✓ Flexible MOQ for trial orders

We have successful partnerships in Vietnam, Thailand, and Indonesia.

Looking forward to hearing from you.

Best regards,
{sender_name}
{company}`
  }
};

// 主函数
function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case 'help':
      showHelp();
      break;
    case 'list':
      listCountries(args[1]);
      break;
    case 'search':
      generateSearchQuery(args[1], args[2], args[3]);
      break;
    case 'template':
      generateEmailTemplate(args[1], args[2]);
      break;
    case 'platforms':
      listPlatforms(args[1]);
      break;
    case 'categories':
      listCategories(args[1]);
      break;
    default:
      showWelcome();
  }
}

function showWelcome() {
  console.log(`
╔══════════════════════════════════════════════════════════╗
║  一带一路非洲B2B客户开发助手 v1.0.0                      ║
║  Belt & Road + Africa B2B Lead Generation Assistant      ║
╚══════════════════════════════════════════════════════════╝

功能:
  • 覆盖非洲20+国家和一带一路15+国家
  • 整合30+个B2B平台和黄页
  • 提供搜索语法和开发信模板
  • 支持客户管理和导出

使用方法:
  node b2b-leads.js help                    显示帮助
  node b2b-leads.js list africa             列出非洲国家
  node b2b-leads.js list belt-road          列出一带一路国家
  node b2b-leads.js search 建材 尼日利亚    生成搜索语法
  node b2b-leads.js template africa 建材    生成开发信模板
  node b2b-leads.js platforms 肯尼亚        列出平台
  node b2b-leads.js categories africa       列出热门品类

示例:
  node b2b-leads.js search "LED lights" Nigeria
  node b2b-leads.js template central_asia "小家电"
`);
}

function showHelp() {
  console.log(`
一带一路非洲B2B客户开发助手 - 使用指南

【国家列表】
  node b2b-leads.js list africa
    - 列出所有非洲国家（北非、西非、东非、南非）
  
  node b2b-leads.js list belt-road
    - 列出所有一带一路国家（中亚、东南亚、中东）

【搜索语法】
  node b2b-leads.js search <产品> <国家>
    - 生成Google搜索语法
    - 示例: node b2b-leads.js search 建材 尼日利亚

【开发信模板】
  node b2b-leads.js template <区域> <产品>
    - 区域: africa, central_asia, southeast_asia, middle_east
    - 示例: node b2b-leads.js template africa 建材

【平台列表】
  node b2b-leads.js platforms <国家>
    - 列出该国家的黄页/B2B平台
    - 示例: node b2b-leads.js platforms 肯尼亚

【热门品类】
  node b2b-leads.js categories <区域>
    - 区域: africa, central_asia, southeast_asia, middle_east
    - 示例: node b2b-leads.js categories africa

【完整示例】
  1. 查看非洲有哪些国家
     node b2b-leads.js list africa

  2. 生成搜索尼日利亚建材客户的语法
     node b2b-leads.js search 建材 尼日利亚

  3. 获取针对非洲市场的建材开发信
     node b2b-leads.js template africa 建材

  4. 查看肯尼亚有哪些平台可用
     node b2b-leads.js platforms 肯尼亚
`);
}

function listCountries(region) {
  if (region === 'africa') {
    console.log('\n🌍 非洲市场覆盖\n');
    for (const [key, value] of Object.entries(AFRICA_DATA)) {
      console.log(`\n【${value.name}】`);
      value.countries.forEach(c => {
        const cities = c.cities ? ` | 主要城市: ${c.cities.join(', ')}` : '';
        console.log(`  • ${c.name} (${c.nameEn}) - ${c.code}${cities}`);
        console.log(`    黄页: ${c.yellowPages}`);
        console.log(`    语言: ${c.lang.join(', ')}`);
      });
    }
  } else if (region === 'belt-road') {
    console.log('\n🌏 一带一路市场覆盖\n');
    for (const [key, value] of Object.entries(BELT_ROAD_DATA)) {
      console.log(`\n【${value.name}】`);
      value.countries.forEach(c => {
        const cities = c.cities ? ` | 主要城市: ${c.cities.join(', ')}` : '';
        console.log(`  • ${c.name} (${c.nameEn}) - ${c.code}${cities}`);
        if (c.yellowPages) {
          console.log(`    黄页: ${c.yellowPages}`);
        }
        if (c.platforms) {
          console.log(`    平台: ${c.platforms.join(', ')}`);
        }
        console.log(`    语言: ${c.lang.join(', ')}`);
      });
    }
  } else {
    console.log('请指定区域: africa 或 belt-road');
  }
}

function generateSearchQuery(product, country) {
  if (!product || !country) {
    console.log('用法: node b2b-leads.js search <产品> <国家>');
    console.log('示例: node b2b-leads.js search 建材 尼日利亚');
    return;
  }

  console.log(`\n🔍 "${product}" 在 ${country} 的搜索语法\n`);
  console.log('Google搜索语法:');
  SEARCH_TEMPLATES.forEach((template, index) => {
    const query = template.replace('{product}', product).replace('{country}', country);
    console.log(`  ${index + 1}. ${query}`);
  });

  console.log('\nGoogle Maps搜索:');
  console.log(`  1. 打开 maps.google.com`);
  console.log(`  2. 搜索: ${product} in ${country}`);
  console.log(`  3. 或定位到 ${country} 的主要城市后搜索: ${product}`);
}

function generateEmailTemplate(region, product) {
  if (!region || !product) {
    console.log('用法: node b2b-leads.js template <区域> <产品>');
    console.log('区域: africa, central_asia, southeast_asia, middle_east');
    console.log('示例: node b2b-leads.js template africa 建材');
    return;
  }

  const template = EMAIL_TEMPLATES[region];
  if (!template) {
    console.log('可用区域: africa, central_asia, southeast_asia, middle_east');
    return;
  }

  console.log(`\n✉️ ${region} 市场开发信模板\n`);
  console.log(`主题: ${template.subject.replace('{product}', product)}\n`);
  console.log('正文:');
  console.log(template.body.replace(/{product}/g, product));
  console.log('\n使用说明:');
  console.log('  - 替换 {name} 为收件人姓名');
  console.log('  - 替换 {sender_name} 为您的姓名');
  console.log('  - 替换 {company} 为您的公司名');
  console.log('  - 替换 {country} 为目标国家');
}

function listPlatforms(country) {
  if (!country) {
    console.log('用法: node b2b-leads.js platforms <国家>');
    console.log('示例: node b2b-leads.js platforms 肯尼亚');
    return;
  }

  // 搜索所有数据源
  let found = false;
  
  for (const [region, data] of Object.entries(AFRICA_DATA)) {
    const countryData = data.countries.find(c => 
      c.name === country || c.nameEn === country || c.code === country.toUpperCase()
    );
    if (countryData) {
      found = true;
      console.log(`\n📍 ${countryData.name} (${countryData.nameEn}) 可用平台\n`);
      console.log(`黄页网站: ${countryData.yellowPages}`);
      console.log(`官方语言: ${countryData.lang.join(', ')}`);
      if (countryData.cities) {
        console.log(`主要城市: ${countryData.cities.join(', ')}`);
      }
      console.log('\n推荐搜索方式:');
      console.log(`  1. 访问 https://${countryData.yellowPages}`);
      console.log(`  2. 使用 Google Maps 搜索: https://maps.google.com`);
      console.log(`  3. Google搜索: "importers" + "${countryData.nameEn}"`);
    }
  }

  for (const [region, data] of Object.entries(BELT_ROAD_DATA)) {
    const countryData = data.countries.find(c => 
      c.name === country || c.nameEn === country || c.code === country.toUpperCase()
    );
    if (countryData) {
      found = true;
      console.log(`\n📍 ${countryData.name} (${countryData.nameEn}) 可用平台\n`);
      if (countryData.yellowPages) {
        console.log(`黄页网站: ${countryData.yellowPages}`);
      }
      if (countryData.platforms) {
        console.log(`B2B平台: ${countryData.platforms.join(', ')}`);
      }
      console.log(`官方语言: ${countryData.lang.join(', ')}`);
      if (countryData.cities) {
        console.log(`主要城市: ${countryData.cities.join(', ')}`);
      }
    }
  }

  if (!found) {
    console.log(`未找到 ${country} 的信息，请检查国家名称或尝试英文名称`);
  }
}

function listCategories(region) {
  if (!region) {
    console.log('用法: node b2b-leads.js categories <区域>');
    console.log('区域: africa, central_asia, southeast_asia, middle_east');
    return;
  }

  const categories = HOT_CATEGORIES[region];
  if (!categories) {
    console.log('可用区域: africa, central_asia, southeast_asia, middle_east');
    return;
  }

  const regionNames = {
    africa: '非洲',
    central_asia: '中亚',
    southeast_asia: '东南亚',
    middle_east: '中东'
  };

  console.log(`\n📦 ${regionNames[region]}市场热门品类\n`);
  categories.forEach((cat, index) => {
    console.log(`  ${index + 1}. ${cat}`);
  });
  console.log('\n建议:');
  console.log('  - 优先选择当地需求旺盛的品类');
  console.log('  - 考虑物流成本和关税');
  console.log('  - 了解当地认证要求');
}

// 运行主函数
main();
