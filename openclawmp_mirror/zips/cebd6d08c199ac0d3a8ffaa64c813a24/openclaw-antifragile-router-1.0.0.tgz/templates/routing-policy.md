# Routing Policy

## Tier A（关键任务）
- 模型：primary
- 降级条件：仅在主模型不可用时

## Tier B（日常任务）
- 模型：primary -> fallback[0]
- 降级条件：连续失败 >= 3

## Tier C（批处理）
- 模型：fallback 优先
- 目标：成本稳定 + 可完成
