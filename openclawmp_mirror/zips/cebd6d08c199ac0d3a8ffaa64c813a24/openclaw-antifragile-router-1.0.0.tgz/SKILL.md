---
name: openclaw-antifragile-router
description: "为 OpenClaw 构建反脆弱模型路由：熔断、降级、回切、成本兜底。"
version: 1.0.0
type: skill
displayName: "OpenClaw 反脆弱模型路由"
tags: "openclaw, model-routing, fallback, reliability"
---

# OpenClaw 反脆弱模型路由

目标：把“模型挂了就全线停摆”改成“自动降级继续可用”。

## 解决痛点

- 单模型依赖导致整体不可用
- 网络波动时失败率突增
- 成本高峰无法自动降级

## 核心机制

1. **主模型 + 回退链**：优先质量，异常时自动切换
2. **软熔断策略**：连续失败触发降级窗口
3. **分级降级**：高价值任务走强模型，普通任务走低成本模型
4. **回切条件**：主模型恢复后有序回切，避免抖动

## 最小落地步骤

### 1) 配置主模型与 fallback

```bash
openclaw config get agents.defaults.model --json
openclaw config get agents.defaults.models --json
```

确保存在：

- `agents.defaults.model.primary`
- `agents.defaults.model.fallbacks`（数组）

### 2) 定义路由策略（模板）

参考 `templates/routing-policy.md`，至少区分：

- 关键任务（质量优先）
- 日常任务（可降级）
- 批处理任务（成本优先）

### 3) 建立故障探针

每 15 分钟执行一次“最小探针”，记录：

- 成功率
- 平均延迟
- 当前命中模型

### 4) 异常时执行降级

当满足以下任一条件，触发 fallback：

- 连续失败 >= 3
- 5 分钟错误率 > 30%
- 响应超时持续 2 个窗口

### 5) 恢复后回切

主模型恢复稳定 3 个窗口后，再回切，避免频繁抖动。

## 推荐输出格式

- 结论（当前路由状态）
- 依据（探针指标）
- 风险（降级影响）
- 执行步骤（下一步）

## 关键收益

- 高可用：模型抖动不再等于系统停摆
- 可控成本：不同任务走不同模型层级
- 可审计：每次降级/回切都有记录
