/**
 * Agent Harness 工程实践技能
 * 基于Nexad团队三个月的实践与反思
 */

const fs = require('fs');
const path = require('path');

class AgentHarnessSkill {
  constructor() {
    this.name = 'Agent Harness 工程实践';
    this.version = '1.0.0';
  }

  /**
   * 获取技能信息
   */
  getInfo() {
    return {
      name: this.name,
      version: this.version,
      description: '掌握Agent Harness工程实践，构建可靠、安全、可扩展的AI Agent系统',
      author: 'SkillCraft Team',
      tags: ['agent', 'harness', 'engineering', 'marketing', 'safety'],
      skills: [
        '构建业务驱动的Harness策略',
        '构建自动化约束检查工具',
        '设计适合Marketing Agent的Harness',
        '构建多层级约束执行系统',
        '解决Agent系统中的常见问题'
      ]
    };
  }

  /**
   * 获取最佳实践
   */
  getBestPractices() {
    return [
      {
        name: '业务驱动原则',
        description: '每个Harness决策都应追溯到具体的业务需求',
        details: [
          '理解产品上下文是Harness设计的基础',
          '平衡技术约束与业务灵活性'
        ]
      },
      {
        name: '自动化优先原则',
        description: '优先将规则编码为自动化检查',
        details: [
          '当文档不足以约束Agent行为时，将规则升级为代码',
          '建立持续集成的约束检查流程'
        ]
      },
      {
        name: '分层防御原则',
        description: '设计多层级的约束执行系统',
        details: [
          '从技术层面到流程层面的全面覆盖',
          '建立冗余的安全机制'
        ]
      },
      {
        name: '持续优化原则',
        description: '基于实际运行数据不断调整Harness策略',
        details: [
          '定期评估约束的有效性和影响',
          '保持Harness系统的可扩展性和适应性'
        ]
      }
    ];
  }

  /**
   * 获取实施示例
   */
  getExamples() {
    return [
      {
        name: '结构化日志检查工具',
        description: '检查是否使用了结构化日志而非f-string日志',
        code: `#!/usr/bin/env python3
"""
检查是否使用了结构化日志而非f-string日志
"""

import re
import sys
import os

def check_structured_logging(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 查找f-string日志模式
    fstring_log_pattern = r'logger\.(info|debug|warning|error|critical)\(f"[^"]*"\)'
    matches = re.findall(fstring_log_pattern, content)
    
    if matches:
        return False, f"Found f-string logging in {file_path}"
    return True, "No f-string logging found"

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python check_structured_logging.py <file_path>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        sys.exit(1)
    
    valid, message = check_structured_logging(file_path)
    print(message)
    sys.exit(0 if valid else 1)`
      },
      {
        name: '软删除检查工具',
        description: '检查是否使用了软删除而非硬删除',
        code: `#!/usr/bin/env python3
"""
检查是否使用了软删除而非硬删除
"""

import re
import sys
import os

def check_soft_delete(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # 查找直接调用session.delete()的模式
    hard_delete_pattern = r'session\.delete\('
    matches = re.findall(hard_delete_pattern, content)
    
    if matches:
        return False, f"Found hard delete in {file_path}"
    return True, "No hard delete found"

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python check_soft_delete.py <file_path>")
        sys.exit(1)
    
    file_path = sys.argv[1]
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        sys.exit(1)
    
    valid, message = check_soft_delete(file_path)
    print(message)
    sys.exit(0 if valid else 1)`
      }
    ];
  }

  /**
   * 执行技能
   */
  execute(action, params) {
    switch (action) {
      case 'getInfo':
        return this.getInfo();
      case 'getBestPractices':
        return this.getBestPractices();
      case 'getExamples':
        return this.getExamples();
      default:
        throw new Error(`Unknown action: ${action}`);
    }
  }
}

// 导出技能模块
if (typeof module !== 'undefined' && module.exports) {
  module.exports = AgentHarnessSkill;
}

// 浏览器环境
if (typeof window !== 'undefined') {
  window.AgentHarnessSkill = AgentHarnessSkill;
}
