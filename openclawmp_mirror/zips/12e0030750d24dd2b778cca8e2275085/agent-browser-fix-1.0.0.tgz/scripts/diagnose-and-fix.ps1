# Agent Browser Diagnostic and Fix Script
# Resolves agent-browser startup failures on Windows

param(
    [switch]$Fix,
    [switch]$AutoRestart,
    [string]$Session = "default"
)

$ErrorActionPreference = "Continue"

function Write-Status {
    param([string]$Message, [string]$Level = "Info")
    $prefix = switch ($Level) {
        "Success" { "[OK]    " }
        "Warning" { "[WARN]  " }
        "Error"   { "[ERROR] " }
        "Info"    { "[INFO]  " }
        default   { "        " }
    }
    Write-Host "$prefix$Message"
}

function Get-SessionPort {
    param([string]$Name)
    $hash = 0
    for ($i = 0; $i -lt $Name.Length; $i++) {
        $hash = ($hash -shl 5) - $hash + [int][char]$Name[$i]
        $hash = $hash -band 0xFFFFFFFF
    }
    return 49152 + ([Math]::Abs($hash) % 16383)
}

# Main
Write-Status "Agent Browser Diagnostic Tool" "Info"
Write-Status "=============================" "Info"

$port = Get-SessionPort -Name $Session
Write-Status "Session: $Session" "Info"
Write-Status "Port: $port" "Info"

# Check port usage
Write-Status "Checking port $port..." "Info"
$conn = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue | Select-Object -First 1
if ($conn) {
    Write-Status "Port $port is in use by PID $($conn.OwningProcess)" "Warning"
} else {
    Write-Status "Port $port is free" "Success"
}

# Check processes
Write-Status "Checking agent-browser processes..." "Info"
$procs = Get-Process | Where-Object { $_.ProcessName -like "*agent-browser*" }
if ($procs) {
    Write-Status "Found $($procs.Count) agent-browser process(es)" "Warning"
    $procs | ForEach-Object { Write-Status "  PID: $($_.Id)" "Info" }
} else {
    Write-Status "No agent-browser processes running" "Success"
}

# Check state files
$appDir = Join-Path $env:USERPROFILE ".agent-browser"
$portFile = Join-Path $appDir "$Session.port"
$pidFile = Join-Path $appDir "$Session.pid"

Write-Status "Checking state files..." "Info"
if (Test-Path $portFile) {
    Write-Status "Port file exists: $portFile" "Warning"
} else {
    Write-Status "Port file not found" "Success"
}

if (Test-Path $pidFile) {
    Write-Status "PID file exists: $pidFile" "Warning"
} else {
    Write-Status "PID file not found" "Success"
}

# Fix issues
if ($Fix) {
    Write-Status "Applying fixes..." "Info"
    
    if ($procs) {
        Write-Status "Stopping agent-browser processes..." "Info"
        $procs | Stop-Process -Force
        Start-Sleep -Seconds 2
        Write-Status "Processes stopped" "Success"
    }
    
    if (Test-Path $portFile) {
        Remove-Item $portFile -Force
        Write-Status "Removed port file" "Success"
    }
    
    if (Test-Path $pidFile) {
        Remove-Item $pidFile -Force
        Write-Status "Removed PID file" "Success"
    }
    
    # Wait for port release
    $wait = 0
    while ($wait -lt 10) {
        $inUse = Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
        if (-not $inUse) { break }
        Start-Sleep -Seconds 1
        $wait++
    }
    
    if ($wait -lt 10) {
        Write-Status "Port released after $wait seconds" "Success"
    } else {
        Write-Status "Port still in use after 10 seconds" "Warning"
    }
    
    Write-Status "Fixes applied" "Success"
    
    # Auto restart
    if ($AutoRestart) {
        Write-Status "Restarting agent-browser..." "Info"
        $agentPath = "$env:USERPROFILE/.stepfun/runtimes/node/install_1772416488032_xb8rl8qdjw/node-v22.18.0-win-x64/agent-browser.ps1"
        if (Test-Path $agentPath) {
            Start-Process -FilePath "pwsh" -ArgumentList "-File", $agentPath -WindowStyle Hidden
            Start-Sleep -Seconds 3
            $newProcs = Get-Process | Where-Object { $_.ProcessName -like "*agent-browser*" }
            if ($newProcs) {
                Write-Status "agent-browser restarted (PID: $($newProcs[0].Id))" "Success"
            } else {
                Write-Status "Failed to restart agent-browser" "Error"
            }
        } else {
            Write-Status "agent-browser script not found at: $agentPath" "Error"
        }
    }
}

Write-Status "=============================" "Info"
Write-Status "Diagnostic complete" "Info"

if (-not $Fix -and ($procs -or (Test-Path $portFile) -or (Test-Path $pidFile) -or $conn)) {
    Write-Status "Run with -Fix to resolve issues" "Info"
}
