---
name: agent-browser-fix
description: 诊断和修复 agent-browser 在 Windows 上偶发的 default.sock 启动失败问题。包含端口冲突检测、进程清理、自动重启等功能。
---

# Agent Browser 启动修复 Skill

## 问题描述

在 Windows 上使用全局 agent-browser 时，偶发出现 `default.sock` 启动失败（实际是 TCP 端口冲突）。

### 根本原因

1. **端口计算冲突** - agent-browser 使用会话名称的哈希值计算端口 (49152-65535)，可能与其他程序冲突
2. **僵尸进程** - 之前的 agent-browser 进程未正常退出，占用端口
3. **端口文件残留** - `~/.agent-browser/default.port` 文件残留导致误判

## 诊断流程

### 1. 检查端口占用

```powershell
# 计算 default 会话的端口
$session = "default"
$hash = 0
for ($i = 0; $i -lt $session.Length; $i++) {
    $hash = ($hash -shl 5) - $hash + [int]$session[$i]
    $hash = $hash -band 0xFFFFFFFF
}
$port = 49152 + ([Math]::Abs($hash) % 16383)
Write-Host "Default session port: $port"

# 检查端口是否被占用
Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue
```

### 2. 检查 agent-browser 进程

```powershell
Get-Process | Where-Object { $_.ProcessName -like "*agent-browser*" }
```

### 3. 检查端口文件

```powershell
Test-Path "$env:USERPROFILE/.agent-browser/default.port"
Test-Path "$env:USERPROFILE/.agent-browser/default.pid"
```

## 修复方案

### 方案 1: 清理并重启（推荐）

```powershell
# 1. 终止所有 agent-browser 进程
Get-Process | Where-Object { $_.ProcessName -like "*agent-browser*" } | Stop-Process -Force

# 2. 清理端口文件
Remove-Item "$env:USERPROFILE/.agent-browser/default.port" -ErrorAction SilentlyContinue
Remove-Item "$env:USERPROFILE/.agent-browser/default.pid" -ErrorAction SilentlyContinue

# 3. 等待端口释放
Start-Sleep -Seconds 2

# 4. 重新启动
agent-browser
```

### 方案 2: 使用随机端口

设置环境变量使用随机端口而非哈希计算：

```powershell
$env:AGENT_BROWSER_SOCKET_DIR = "$env:TEMP/agent-browser-$(Get-Random)"
agent-browser
```

### 方案 3: 指定固定端口

```powershell
# 在 Windows 上，AGENT_BROWSER_SOCKET_DIR 实际上控制端口文件位置
# 但端口仍由哈希计算，需要通过修改代码或包装脚本来实现
```

## 自动化修复脚本

使用本 skill 的修复脚本：

```powershell
& ~/.stepclaw/skills/agent-browser-fix/scripts/diagnose-and-fix.ps1
```

## 预防措施

1. **启动前检查** - 在启动 agent-browser 前运行诊断
2. **健康检查** - 定期检测 agent-browser 是否正常运行
3. **自动清理** - 系统启动时清理僵尸进程和残留文件

## 定时任务集成

在 OpenClaw 定时任务中添加健康检查：

```json
{
  "name": "Agent Browser 健康检查",
  "schedule": "0 */6 * * *",
  "payload": {
    "message": "执行 agent-browser 健康检查：\n1. 检查 default 会话端口是否被占用\n2. 检查 agent-browser 进程是否正常运行\n3. 如果异常，执行修复脚本\n4. 汇报检查结果"
  }
}
```
