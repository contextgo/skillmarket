# 飞书工具库 (Feishu Toolkit)

## 描述

让 OpenClaw Agent 轻松集成飞书消息、群聊和文档管理。**创新支持长连接监听，无需公网 IP！**

## 核心亮点

### 🌟 长连接监听（无需公网 IP！）

传统飞书机器人需要公网域名 + HTTPS 回调 URL，而本工具库的长连接方案：

- ✅ **无需公网 IP** - 内网服务器即可运行
- ✅ **无需 HTTPS 证书** - 零配置成本
- ✅ **无需开放入站端口** - 仅出站连接，更安全
- ✅ **自动重连** - 断线自动恢复
- ✅ **Token 自动管理** - 无需手动刷新

### 💬 完整消息功能

- 发送文本/富文本/文件/图片消息
- 消息回复（支持话题回复）
- 群聊管理（列表、查找、信息获取）
- 文件上传到飞书云空间

### 📄 文档操作

- 读取飞书文档内容
- 创建新的飞书文档
- Markdown 转飞书文档
- 上传文件到云空间

### 🌍 多区域支持

- 飞书中国版 (`open.feishu.cn`)
- Lark 国际版 (`open.larksuite.com`)

## 安装

```bash
openclawmp install feishu-toolkit
```

## 配置

### 1. 在飞书开放平台创建应用

1. 访问 https://open.feishu.cn/app
2. 创建企业自建应用
3. 获取 `App ID` 和 `App Secret`
4. 开通权限：`im:message`, `im:chat`, `docx:document`, `im:message.receive_v1`
5. 启用长连接："Event Configuration" → "Receive events through persistent connection"

### 2. 配置本地凭证

```bash
cd ~/.openclaw/extensions/feishu-toolkit
cp .lark-config.example.json .lark-config.json
```

编辑 `.lark-config.json`：

```json
{
  "app_id": "your_app_id_here",
  "app_secret": "your_app_secret_here",
  "region": "feishu"
}
```

## 使用方式

### 方式 1: 命令行工具

```bash
# 列出所有群聊
node cli/list-chats.js

# 发送消息到指定群聊
node cli/send-message.js "群聊名称" "Hello World"

# 启动长连接监听服务
node scripts/feishu-ws-listener.js
```

### 方式 2: 作为 Node.js 库

```javascript
const { LarkAuth, LarkMessage, LarkChat } = require('./lib');

// 初始化
const auth = LarkAuth.fromConfig('.lark-config.json');
const message = new LarkMessage(auth);
const chat = new LarkChat(auth);

// 列出群聊
const chats = await chat.list();

// 发送文本消息
await message.sendText(chatId, 'Hello World');

// 发送富文本消息
await message.sendRichText(chatId, {
  zh_cn: {
    title: '📢 通知',
    content: [[{ tag: 'text', text: '新功能已上线' }]]
  }
});

// 上传并发送文件
const fileData = await message.uploadFile('./package.zip');
await message.sendFile(chatId, fileData.file_key);
```

### 方式 3: OpenClaw 技能

```javascript
const feishuSender = require('feishu-sender');

// 发送文本
await feishuSender.sendText('oc_chat_id', '你好');

// 发送图片
await feishuSender.sendImage('oc_chat_id', '/path/to/image.png', '图片说明');
```

### 方式 4: 长连接监听服务

```bash
# 启动服务
node scripts/feishu-ws-listener.js

# 输出：
# ============================================================
# 🦞 飞书长连接监听服务
# ============================================================
# 📱 应用 ID: cli_xxxxx
# 🔌 模式：持久连接（WebSocket）
# 🌍 无需公网 IP | 无需回调 URL
# ============================================================
# [09:00:00] ✅ 服务就绪，等待消息...
# [09:05:00] 📨 收到消息：用户 XXX: 你好
# [09:05:01] 🤖 调用 Gateway 生成回复...
# [09:05:02] 📤 发送回复成功
```

## 项目结构

```
feishu-toolkit/
├── lib/                    # 核心库
│   ├── common/auth.js      # 认证模块
│   ├── message/message.js  # 消息发送
│   └── message/chat.js     # 群聊管理
├── cli/                    # CLI 工具
│   ├── list-chats.js       # 列出群聊
│   └── send-message.js     # 发送消息
├── scripts/                # 高级脚本
│   ├── feishu-ws-listener.js  # 🌟 长连接监听
│   ├── lark-doc-reader.js     # 读取文档
│   ├── lark-doc-writer-v3.js  # 创建文档
│   └── lark-file-uploader.js  # 上传文件
└── skills/
    └── feishu-sender/      # OpenClaw 技能
```

## 版本规划

### ✅ v1.0 (当前)
- 消息发送/接收
- 群聊管理
- 长连接监听
- 文档读写基础

### 🚧 计划中
- 群聊消息归纳总结
- 文档智能模板
- 消息队列（批量/定时发送）
- Web 管理界面

## 安全说明

- ⚠️ 不要将 `.lark-config.json` 提交到 Git
- ✅ 生产环境使用环境变量：`FEISHU_APP_ID`, `FEISHU_APP_SECRET`
- ✅ 长连接仅出站连接，无需开放入站端口

## 常见问题

**Q: 长连接和 Webhook 有什么区别？**

A: 长连接是你的服务器主动连接飞书（出站），Webhook 是飞书回调你的服务器（入站）。长连接无需公网 IP 和 HTTPS 证书。

**Q: 支持国际版 Lark 吗？**

A: 支持！设置 `"region": "lark"` 即可。

## 参考文档

- [飞书开放平台](https://open.feishu.cn/)
- [事件订阅指南](https://open.feishu.cn/document/ukTMukTMukTM/uUTNz4SN1MjL1UzM)
- [持久连接文档](https://open.feishu.cn/document/ukTMukTMukTM/uETO1YjLxkTN24SM5UjN)

## 许可证

MIT License

---

**版本**: v1.0.1  
**最后更新**: 2026-03-22  
**作者**: OpenClaw 社区贡献者