---
name: log-analyzer
description: 日志分析助手。用于分析系统日志、定位问题根因、生成日志报告。当需要分析日志、排查问题时触发。
---

# 日志分析助手

## 日志级别

| 级别 | 英文 | 含义 | 严重程度 |
|------|------|------|----------|
| DEBUG | 调试 | 开发调试信息 | 低 |
| INFO | 信息 | 正常运行信息 | 低 |
| WARN | 警告 | 潜在问题 | 中 |
| ERROR | 错误 | 错误信息 | 高 |
| FATAL | 致命 | 系统崩溃 | 极高 |

## 日志格式

### 标准格式
```log
时间 | 级别 | 线程 | 类名 | 消息
2024-01-01 10:00:00 | ERROR | http-nio-8080-exec-1 | UserService | User login failed: user not found
```

### JSON格式
```json
{
  "timestamp": "2024-01-01T10:00:00.000Z",
  "level": "ERROR",
  "thread": "http-nio-8080-exec-1",
  "logger": "com.example.UserService",
  "message": "User login failed",
  "context": {
    "userId": 123,
    "ip": "192.168.1.1"
  }
}
```

## 日志分析命令

### Linux日志命令
```bash
# 查看日志
tail -f app.log                    # 实时查看
tail -n 100 app.log                # 查看最后100行

# 搜索关键词
grep "ERROR" app.log               # 搜索错误
grep -E "ERROR|WARN" app.log       # 搜索错误和警告
grep -C 5 "ERROR" app.log          # 显示前后5行

# 统计
grep -c "ERROR" app.log            # 统计错误数量
awk '{print $5}' app.log | sort | uniq -c  # 统计各级别数量

# 时间范围
sed -n '/2024-01-01 10:00/,/2024-01-01 11:00/p' app.log

# 性能分析
awk '{print $6}' access.log | sort | uniq -c | sort -rn | head -10
```

### 日志分析脚本
```bash
#!/bin/bash
# 日志分析脚本

LOG_FILE=$1
ERROR_COUNT=$(grep -c "ERROR" $LOG_FILE)
WARN_COUNT=$(grep -c "WARN" $LOG_FILE)
FATAL_COUNT=$(grep -c "FATAL" $LOG_FILE)

echo "=== 日志分析报告 ==="
echo "日志文件: $LOG_FILE"
echo "分析时间: $(date)"
echo ""
echo "错误统计:"
echo "  ERROR: $ERROR_COUNT"
echo "  WARN: $WARN_COUNT"
echo "  FATAL: $FATAL_COUNT"
echo ""

echo "最近10条ERROR:"
grep "ERROR" $LOG_FILE | tail -10

echo ""
echo "错误趋势（每小时）:"
grep "ERROR" $LOG_FILE | awk '{print $2}' | cut -d: -f1 | sort | uniq -c
```

## 常见问题分析

### 1. 性能问题
```log
# 响应时间慢
[分析要点]
1. 搜索slow query
2. 查看GC日志
3. 分析线程状态

# 关键词
slow query、timeout、gc、thread dump
```

### 2. 内存问题
```log
# 内存泄漏
[分析要点]
1. 查看OOM错误
2. 分析GC频率
3. 查看堆内存使用

# 关键词
OutOfMemoryError、heap、gc、memory
```

### 3. 磁盘问题
```log
# 磁盘满
[分析要点]
1. 查看磁盘使用
2. 查找大文件
3. 分析日志增长

# 关键词
No space left、disk、storage
```

### 4. 数据库问题
```log
# 连接池耗尽
[分析要点]
1. 查看连接池状态
2. 分析慢SQL
3. 查看连接泄漏

# 关键词
Connection pool、SQLException、timeout、deadlock
```

## 日志分析报告模板

```markdown
# 日志分析报告

分析时间：YYYY-MM-DD HH:MM
分析范围：YYYY-MM-DD HH:MM - YYYY-MM-DD HH:MM
分析文件：XXX.log

---

## 统计概览

| 级别 | 数量 | 占比 |
|------|------|------|
| DEBUG | XXX | XX% |
| INFO | XXX | XX% |
| WARN | XXX | XX% |
| ERROR | XXX | XX% |
| FATAL | XXX | XX% |

---

## 错误分析

### 高频错误TOP5

| 排名 | 错误类型 | 数量 | 占比 |
|------|----------|------|------|
| 1 | xxx | XXX | XX% |
| 2 | xxx | XXX | XX% |

### 错误趋势
[图表]

---

## 问题定位

### 问题1：xxx
- 现象：xxx
- 原因：xxx
- 影响：xxx
- 建议：xxx

---

## 建议措施

1. xxx
2. xxx

---

## 附件
- 完整日志文件
- 错误详情列表
```
