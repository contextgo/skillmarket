---
name: polymarket-rss-news-aggregator
description: "基于 RSS 源的 Polymarket 新闻聚合器，实时抓取多源新闻并匹配预测市场信号"
version: 1.0.0
---

# Polymarket RSS 新闻聚合器

通过 RSS 订阅源实时抓取金融和政治新闻，自动匹配 Polymarket 上的活跃预测市场，计算信号置信度，辅助交易决策。

## 背景

Polymarket 是基于区块链的预测市场平台。交易者需要实时了解新闻事件对市场的影响。传统的 API 方式（如 web_search）存在速率限制和成本问题，RSS 是更稳定、免费的替代方案。

## RSS 源配置

### 推荐源（按覆盖领域分类）

**综合财经：**
- Reuters Business: `https://feeds.reuters.com/reuters/businessNews`
- CNBC Top News: `https://search.cnbc.com/rs/search/combinedcms/view.xml?partnerId=wrss01&id=100003114`
- BBC Business: `https://feeds.bbci.co.uk/news/business/rss.xml`

**加密货币：**
- CoinDesk: `https://coindesk.com/arc/outboundfeeds/rss/`
- Cointelegraph: `https://cointelegraph.com/rss`
- The Block: `https://www.theblock.co/rss.xml`

**政治/地缘：**
- AP Politics: `https://feeds.apnews.com/rss/apnews-politics`
- BBC World: `https://feeds.bbci.co.uk/news/world/rss.xml`

**特定市场主题：**
- Oil/Energy: `https://feeds.reuters.com/reuters/energyNews`
- Tech/AI: `https://feeds.reuters.com/reuters/technologyNews`
- Gold/Metals: `https://feeds.reuters.com/reuters/businessNews`

### Google 专题搜索 RSS
针对特定市场创建自定义 RSS：
```
https://news.google.com/rss/search?q={keyword}&hl=en-US&gl=US&ceid=US:en
```

关键词列表（针对热门市场）：
- `oil price brent crude OPEC`
- `iran military conflict`
- `bitcoin price BTC`
- `ethereum price ETH`
- `gold price XAU`
- `quantum computing stock`
- `Nasdaq Dow Jones`
- `CFTC SEC regulation prediction market`
- `Apple AI M-series`

## 信号匹配算法

### 步骤 1：关键词匹配

为每个活跃市场定义关键词集：

```python
MARKET_KEYWORDS = {
    "oil-90": {
        "keywords": ["oil", "brent", "crude", "OPEC", "energy", "gasoline"],
        "boost_words": ["surge", "jump", "soar", "$90", "$100", "supply cut"],
        "context": "油价相关新闻"
    },
    "bitcoin-100k": {
        "keywords": ["bitcoin", "BTC", "crypto", "cryptocurrency"],
        "boost_words": ["surge", "ATH", "$100k", "ETF", "institutional"],
        "context": "比特币相关新闻"
    }
}
```

### 步骤 2：置信度计算

```
base_confidence = 0.30
+ keyword_match: +0.10 per unique keyword
+ boost_word_match: +0.15 per boost word
+ source_quality: +0.05 (Reuters/CNBC), +0.03 (other major)
+ recency: +0.05 (within 2 hours)
max_confidence = 0.95
```

### 步骤 3：信号聚合

同一市场的多条新闻信号取加权平均，最近新闻权重更高。

## 使用流程

1. **初始化**：加载市场列表和关键词配置
2. **抓取**：遍历所有 RSS 源（每源超时 10 秒）
3. **去重**：基于标题相似度去除重复新闻
4. **匹配**：将新闻与市场关键词匹配
5. **评分**：计算每个市场的信号置信度
6. **输出**：生成信号报告（JSON 格式）

## 输出格式

```json
{
  "timestamp": "2026-03-13T20:51:00Z",
  "total_news": 210,
  "signals": [
    {
      "market": "oil-90",
      "confidence": 0.95,
      "news_count": 5,
      "top_headlines": [
        "Brent crude surges past $100 on Iran tensions",
        "OPEC+ considers emergency supply cut"
      ]
    }
  ]
}
```

## 容错机制

1. **代理问题**：设置超时，失败源跳过不影响其他源
2. **SSL 问题**：降级使用不验证 SSL 的请求
3. **源不可用**：维护备用源列表
4. **去重机制**：标题相似度 > 0.8 视为重复

## 最佳实践

1. 每 30 分钟执行一次（避免过于频繁被限流）
2. 关注置信度 > 0.35 的信号
3. 连续 3 轮以上高置信度 = 强信号
4. 结合 Polymarket API 获取实际市场价格对比
5. 记录历史信号用于回测
