# Weekly Distill Checklist

1. 浏览最近 7 天 daily notes
2. 提炼高复用事实到 MEMORY.md
3. 标记过时条目
4. 合并重复结论
5. 检查是否泄露敏感信息
