---
name: opentelemetry-instrumentation
description: "OpenTelemetry instrumentation patterns - distributed tracing, metrics, and logging for cloud-native applications"
version: 1.0.0
tags: ["opentelemetry", "observability", "tracing", "metrics", "monitoring"]
---

# OpenTelemetry Instrumentation Guide

OpenTelemetry (OTel) is a vendor-neutral observability framework for distributed tracing, metrics, and logging.

## Three Pillars

1. **Traces**: Request flow across services
2. **Metrics**: Counters, gauges, histograms
3. **Logs**: Structured log correlation with traces

## Node.js Setup

```typescript
import { NodeSDK } from '@opentelemetry/sdk-node';
import { OTLPTraceExporter } from '@opentelemetry/exporter-trace-otlp-grpc';
import { getResource } from '@opentelemetry/resources';
import { ATTR_SERVICE_NAME } from '@opentelemetry/semantic-conventions';

const sdk = new NodeSDK({
  resource: getResource({ [ATTR_SERVICE_NAME]: 'my-service' }),
  traceExporter: new OTLPTraceExporter({
    url: 'http://localhost:4317',
  }),
});

sdk.start();
```

## Custom Spans

```typescript
import { trace } from '@opentelemetry/api';

const tracer = trace.getTracer('my-tracer');

async function processOrder(order: Order) {
  return tracer.startActiveSpan('processOrder', async (span) => {
    span.setAttribute('order.id', order.id);
    span.setAttribute('order.amount', order.amount);
    
    try {
      const result = await validateOrder(order);
      span.setStatus({ code: SpanStatusCode.OK });
      return result;
    } catch (err) {
      span.setStatus({ code: SpanStatusCode.ERROR, message: err.message });
      span.recordException(err);
      throw err;
    } finally {
      span.end();
    }
  });
}
```

## Metrics

```typescript
import { metrics } from '@opentelemetry/api';

const meter = metrics.getMeter('my-meter');
const requestCount = meter.createCounter('http.requests', {
  description: 'Total HTTP requests',
});

app.use((req, res, next) => {
  requestCount.add(1, { method: req.method, path: req.path });
  next();
});
```

## Auto-Instrumentation

```bash
# Zero-code instrumentation for common libraries
node --require @opentelemetry/auto-instrumentations-node app.js
```

## Best Practices

- Always set service.name resource attribute
- Add meaningful span attributes (not PII)
- Use semantic conventions for standard attributes
- Sample traces in high-volume services (1-10%)
- Export to OTLP collector, never directly to backends
