#!/usr/bin/env python3
"""发送语音消息到飞书"""

import requests
import json
import asyncio
import edge_tts
import os
import sys
from pydub import AudioSegment

# 飞书配置
APP_ID = "你的AppID"
APP_SECRET = "你的AppSecret"
RECEIVER_ID = "你的飞书ID"

def get_token():
    """获取飞书 access_token"""
    resp = requests.post(
        "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal",
        json={"app_id": APP_ID, "app_secret": APP_SECRET}
    )
    return resp.json()["tenant_access_token"]

def send_voice(token, audio_path, text=""):
    """发送语音消息"""
    # 获取音频时长
    sound = AudioSegment.from_file(audio_path)
    duration_ms = len(sound)
    
    # 上传文件
    files = {"file": open(audio_path, "rb")}
    headers = {"Authorization": f"Bearer {token}"}
    resp = requests.post(
        "https://open.feishu.cn/open-apis/im/v1/files",
        headers=headers, files=files,
        data={
            "file_type": "opus",
            "file_name": os.path.basename(audio_path),
            "duration": duration_ms
        }
    )
    result = resp.json()
    if result.get("code") != 0:
        print(f"上传失败: {result}")
        return None
    
    file_key = result["data"]["file_key"]
    
    # 发送语音消息
    resp = requests.post(
        "https://open.feishu.cn/open-apis/im/v1/messages",
        headers=headers,
        params={"receive_id_type": "open_id"},
        json={
            "receive_id": RECEIVER_ID,
            "msg_type": "audio",
            "content": json.dumps({"file_key": file_key})
        }
    )
    result = resp.json()
    if result.get("code") == 0:
        print(f"发送成功! 消息ID: {result['data']['message_id']}")
        return result["data"]["message_id"]
    else:
        print(f"发送失败: {result}")
        return None

async def generate_voice(text, output_path):
    """生成语音"""
    communicate = edge_tts.Communicate(text, "zh-CN-XiaoxiaoNeural")
    mp3_path = output_path.replace(".ogg", ".mp3")
    await communicate.save(mp3_path)
    
    # 转换为 OGG
    sound = AudioSegment.from_mp3(mp3_path)
    sound.export(output_path, format="ogg", codec="libopus")
    
    # 删除临时 MP3
    os.remove(mp3_path)
    return output_path

async def main():
    if len(sys.argv) < 2:
        # 默认测试
        text = "你好呀~我是芽芽！"
        output = "C:/Users/29213/.openclaw/workspace/output/voice_yaya.ogg"
    else:
        text = sys.argv[1]
        output = sys.argv[2] if len(sys.argv) > 2 else "C:/Users/29213/.openclaw/workspace/output/voice_yaya.ogg"
    
    print(f"生成语音: {text}")
    await generate_voice(text, output)
    print(f"语音文件: {output}")
    
    token = get_token()
    send_voice(token, output, text)

if __name__ == "__main__":
    asyncio.run(main())
