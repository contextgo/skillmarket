---
name: voice
description: 语音技能。使用 send_voice.py 发送语音到飞书（Edge TTS，免费）。
---

# Voice 语音技能

## 功能
- 语音识别 (Speech-to-Text) - 使用 faster-whisper
- 语音合成 (Text-to-Speech) - 使用 send_voice.py 脚本调用 Edge TTS

## 依赖
```bash
pip install edge-tts pydub requests
```

## 语音识别 (STT)

### faster-whisper (本地)
```python
from faster_whisper import WhisperModel

model = WhisperModel('base', device='cpu', compute_type='int8')
segments, info = model.transcribe('audio.wav', language='zh')
for segment in segments:
    print(segment.text)
```

## 语音合成 (TTS) - 发送语音到飞书

使用 send_voice.py 脚本，通过 Edge TTS 生成语音并发送到飞书：

```bash
python skills/voice/scripts/send_voice.py "你想说的话"
```

**默认输出文件：** `C:/Users/29213/.openclaw/workspace/output/voice_yaya.ogg`

**推荐中文音色：**
- `zh-CN-XiaoxiaoNeural` - 晓晓 (女声)
- `zh-CN-YunxiNeural` - 云希 (男声)
- `zh-CN-YunyangNeural` - 云扬 (男声)

## 飞书配置
> 需要配置你的 App ID 和 App Secret
