#!/usr/bin/env python3
"""
社交广告平台助手
半自动化多平台广告数据管理
"""

import typer
from rich.console import Console
from rich.table import Table
from pathlib import Path
import json
import pandas as pd
from datetime import datetime, timedelta
import re

app = typer.Typer(help="社交广告平台数据管理与优化助手")
console = Console()

# 平台标识映射
PLATFORM_NAMES = {
    "douyin": ["抖音", "巨量引擎", "douyin", "toutiao", "头条"],
    "xiaohongshu": ["小红书", "xhs", "xiaohongshu", "rednote"],
    "bilibili": ["B站", "bilibili", "BiliBili", "b站"],
    "weibo": ["微博", "weibo", "weibo.com"],
    "wechat": ["微信", "wechat", "gzh", "朋友圈"]
}

def detect_platform(file_name: str, explicit_platform: str = None) -> str:
    """自动检测或使用指定的平台"""
    if explicit_platform:
        return explicit_platform.lower()
    
    name_lower = file_name.lower()
    for platform, keywords in PLATFORM_NAMES.items():
        for kw in keywords:
            if kw.lower() in name_lower:
                return platform
    return "unknown"

def normalize_columns(df: pd.DataFrame, platform: str) -> pd.DataFrame:
    """根据平台标准化列名"""
    rename_dict = {}
    
    # 通用映射
    common_mapping = {
        "campaign": ["campaign", "campaign_name", "campaign name", "计划名称", "推广计划", "adgroup_name"],
        "campaign_id": ["campaign_id", "campaign id", "计划ID", "推广计划id", "campaignid"],
        "date": ["date", "日期", "day", "stat_date"],
        "impressions": ["impressions", "展示", "曝光", "imp", "impression"],
        "clicks": ["clicks", "点击", "click", "clk"],
        "conversions": ["conversions", "转化", "convert", "converted", "转化数", "转化量"],
        "cost": ["cost", "花费", "消费", "费用", "cost_rmb"],
        "revenue": ["revenue", "收入", "收益", "营收"]
    }
    
    for std_name, possibilities in common_mapping.items():
        for col in df.columns:
            col_clean = str(col).strip().lower().replace(" ", "").replace("_", "")
            for p in possibilities:
                p_clean = p.lower().replace(" ", "").replace("_", "")
                if col_clean == p_clean:
                    rename_dict[col] = std_name
                    break
    
    df = df.rename(columns=rename_dict)
    
    # 添加平台标记
    df["platform"] = platform.upper()
    
    # 确保date为datetime
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"], errors="coerce")
    
    return df

@app.command()
def import_data(
    platform: str = typer.Option(None, "--platform", "-p", help="平台名称 (douyin/xiaohongshu/bilibili/weibo/wechat，不指定则自动检测)"),
    file: Path = typer.Argument(..., help="CSV文件路径"),
    output: Path = typer.Option(None, "--output", "-o", help="输出JSON文件（默认：同名.json）")
):
    """
    导入平台CSV数据并标准化
    
    示例:
        social-ad-platform import --platform douyin douyin_export.csv
        social-ad-platform import -p xiaohongshu xhs_data.csv -o xhs.json
    """
    if not file.exists():
        console.print(f"[red]❌ 文件不存在: {file}[/red]")
        raise typer.Exit(1)
    
    try:
        df = pd.read_csv(file)
        detected = detect_platform(file.name, platform)
        if detected == "unknown":
            console.print("[yellow]⚠️ 无法自动识别平台，请使用 --platform 参数指定[/yellow]")
            raise typer.Exit(1)
        
        df = normalize_columns(df, detected)
        
        # 检查必要列
        if "campaign_id" not in df.columns and "campaign" not in df.columns:
            console.print("[red]❌ 数据缺少活动标识字段 (campaign_id 或 campaign)[/red]")
            raise typer.Exit(1)
        
        # 保存
        if output is None:
            output = file.with_suffix(".json")
        
        # 转换为可序列化的字典
        data = {
            "file": file.name,
            "platform": detected,
            "import_time": datetime.now().isoformat(),
            "rows": len(df),
            "campaigns": len(df["campaign_id"].unique()) if "campaign_id" in df.columns else len(df["campaign"].unique()),
            "data": df.where(pd.notnull(df), None).to_dict(orient="records")
        }
        
        with open(output, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, default=str)
        
        console.print(f"[green]✅ 导入成功: {file.name}[/green]")
        console.print(f"平台: {detected}")
        console.print(f"数据行数: {len(df)}")
        console.print(f"活动数: {data['campaigns']}")
        console.print(f"输出: {output}")
        
    except Exception as e:
        console.print(f"[red]❌ 导入失败: {e}[/red]")
        raise typer.Exit(1)

@app.command()
def analyze_campaign(
    data_file: Path = typer.Argument(..., help="导入后的JSON数据文件"),
    campaign_id: str = typer.Option(None, "--campaign-id", "-c", help="活动ID（不指定则分析所有）"),
    days: int = typer.Option(30, "--days", "-d", help="分析最近N天数据")
):
    """
    分析活动投放效果
    
    输出：核心指标表 + 趋势图
    """
    if not data_file.exists():
        console.print(f"[red]❌ 文件不存在: {data_file}[/red]")
        raise typer.Exit(1)
    
    with open(data_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    df = pd.DataFrame(data["data"])
    
    # 日期过滤
    if "date" in df.columns:
        df["date"] = pd.to_datetime(df["date"])
        cutoff = datetime.now() - timedelta(days=days)
        df = df[df["date"] >= cutoff]
    
    # 筛选特定活动
    if campaign_id:
        if "campaign_id" in df.columns:
            df = df[df["campaign_id"] == campaign_id]
        else:
            df = df[df["campaign"] == campaign_id]
    
    if len(df) == 0:
        console.print("[yellow]⚠️ 没有符合条件的数据[/yellow]")
        return
    
    # 计算汇总指标
    def calc_metrics(subdf):
        impressions = subdf["impressions"].sum()
        clicks = subdf["clicks"].sum()
        conversions = subdf["conversions"].sum() if "conversions" in subdf.columns else 0
        cost = subdf["cost"].sum()
        revenue = subdf["revenue"].sum() if "revenue" in subdf.columns else 0
        
        return {
            "impressions": int(impressions),
            "clicks": int(clicks),
            "conversions": int(conversions),
            "cost": round(cost, 2),
            "revenue": round(revenue, 2),
            "ctr": clicks / impressions if impressions > 0 else 0,
            "cvr": conversions / clicks if clicks > 0 else 0,
            "cpc": cost / clicks if clicks > 0 else 0,
            "cpm": cost / impressions * 1000 if impressions > 0 else 0,
            "cpa": cost / conversions if conversions > 0 else 0,
            "roi": revenue / cost if cost > 0 else 0
        }
    
    result = calc_metrics(df)
    
    # 输出表格
    table = Table(title="活动效果分析")
    table.add_column("指标", style="cyan")
    table.add_column("数值", justify="right", style="magenta")
    
    for k, v in result.items():
        if isinstance(v, float):
            if k in ["ctr", "cvr"]:
                v_str = f"{v:.2%}"
            elif k in ["roi"]:
                v_str = f"{v:.2f}"
            else:
                v_str = f"{v:,.2f}"
        else:
            v_str = f"{v:,}"
        table.add_row(k.upper(), v_str)
    
    console.print(table)
    
    # 趋势输出（简单：按日期汇总）
    if "date" in df.columns:
        console.print("\n[bold]📈 趋势概览（按日）[/bold]")
        daily = df.groupby(df["date"].dt.date).apply(calc_metrics).reset_index()
        preview = daily.tail(7)  # 最近7天
        
        trend_table = Table(show_header=True)
        for col in ["date", "ctr", "cvr", "cpa", "roi"]:
            trend_table.add_column(col.upper())
        
        for _, row in preview.iterrows():
            trend_table.add_row(
                str(row["date"]),
                f"{row['ctr']:.2%}",
                f"{row['cvr']:.2%}",
                f"¥{row['cpa']:.2f}",
                f"{row['roi']:.2f}"
            )
        console.print(trend_table)

@app.command()
def suggest_optimization(
    data_file: Path = typer.Argument(..., help="数据JSON文件"),
    campaign_id: str = typer.Option(None, "--campaign-id", "-c", help="活动ID"),
    output: Path = typer.Option("suggestions.json", "--output", "-o", help="输出文件")
):
    """
    基于规则生成优化建议
    """
    if not data_file.exists():
        console.print(f"[red]❌ 文件不存在: {data_file}[/red]")
        raise typer.Exit(1)
    
    with open(data_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    df = pd.DataFrame(data["data"])
    df["date"] = pd.to_datetime(df["date"])
    
    if campaign_id:
        if "campaign_id" in df.columns:
            df = df[df["campaign_id"] == campaign_id]
        else:
            df = df[df["campaign"] == campaign_id]
    
    suggestions = []
    metrics = {}
    
    # 计算整体指标
    total_cost = df["cost"].sum()
    total_impressions = df["impressions"].sum()
    total_clicks = df["clicks"].sum()
    total_conversions = df["conversions"].sum() if "conversions" in df.columns else 0
    total_revenue = df["revenue"].sum() if "revenue" in df.columns else 0
    
    metrics["ctr"] = total_clicks / total_impressions if total_impressions > 0 else 0
    metrics["cvr"] = total_conversions / total_clicks if total_clicks > 0 else 0
    metrics["cpa"] = total_cost / total_conversions if total_conversions > 0 else 0
    metrics["roi"] = total_revenue / total_cost if total_cost > 0 else 0
    
    # 规则1: ROI检查
    if metrics["roi"] > 2.0 and total_cost / (df["cost"].sum() + 1e-9) < 0.8:
        suggestions.append({
            "type": "budget_increase",
            "priority": "high",
            "message": f"ROI高达{metrics['roi']:.2f}且预算未用满，建议增加20%预算"
        })
    elif metrics["roi"] < 1.0 and len(df) >= 3:
        suggestions.append({
            "type": "budget_decrease",
            "priority": "high",
            "message": f"ROI持续低于1.0 ({metrics['roi']:.2f})，建议暂停或降低出价"
        })
    
    # 规则2: CTR检查（与行业基准对比）
    ctr_benchmark = 0.02  # 2%
    if metrics["ctr"] < ctr_benchmark * 0.5:
        suggestions.append({
            "type": "creative_refresh",
            "priority": "medium",
            "message": f"CTR仅{metrics['ctr']:.2%}，远低于行业基准{ctr_benchmark:.2%}，建议更换创意素材"
        })
    
    # 规则3: 时段分析（如果有小时级数据）
    if "hour" in df.columns or (len(df) > 30 and "date" in df.columns):
        # 简化：假设有 hour 列
        pass
    
    # 规则4: CPA检查
    if total_conversions > 0:
        cpa_benchmark = 50.0  # 示例基准，实际应动态获取
        if metrics["cpa"] > cpa_benchmark * 1.5:
            suggestions.append({
                "type": "cpa_high",
                "priority": "medium",
                "message": f"CPA ¥{metrics['cpa']:.2f} 超过基准 {cpa_benchmark:.2f}，建议优化转化路径或调整出价"
            })
    
    result = {
        "campaign": campaign_id or "all",
        "analysis_date": datetime.now().isoformat(),
        "metrics": {k: float(v) if isinstance(v, (int, float)) else v for k, v in metrics.items()},
        "suggestions": suggestions,
        "suggestion_count": len(suggestions)
    }
    
    with open(output, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2)
    
    console.print(f"[green]✅ 优化建议生成完成[/green]")
    console.print(f"发现建议: {len(suggestions)} 条")
    
    if suggestions:
        table = Table(title="建议清单")
        table.add_column("优先级", justify="center")
        table.add_column("类型", style="cyan")
        table.add_column("建议内容", style="yellow")
        
        for s in suggestions:
            priority_color = {"high": "red", "medium": "yellow", "low": "green"}.get(s["priority"], "white")
            table.add_row(
                f"[{priority_color}]{s['priority']}[/{priority_color}]",
                s["type"],
                s["message"][:50] + ("..." if len(s["message"]) > 50 else "")
            )
        console.print(table)
    
    console.print(f"📝 详情已保存: {output}")

@app.command()
def export_updates(
    suggestions_file: Path = typer.Argument(..., help="建议JSON文件"),
    format: str = typer.Option("csv", "--format", "-f", help="导出格式: csv | excel"),
    output: Path = typer.Option("updates.csv", "--output", "-o", help="输出文件")
):
    """
    将优化建议导出为平台可上传的格式
    """
    with open(suggestions_file, "r", encoding="utf-8") as f:
        data = json.load(f)
    
    updates = []
    for s in data.get("suggestions", []):
        if s["type"] == "budget_increase":
            updates.append({
                "action": "adjust_budget",
                "multiplier": 1.2,
                "reason": s["message"]
            })
        elif s["type"] == "budget_decrease":
            updates.append({
                "action": "adjust_budget",
                "multiplier": 0.8,
                "reason": s["message"]
            })
        elif s["type"] == "creative_refresh":
            updates.append({
                "action": "replace_creative",
                "reason": s["message"]
            })
    
    if not updates:
        console.print("[yellow]⚠️ 没有可导出的操作[/yellow]")
        return
    
    df = pd.DataFrame(updates)
    
    if format == "csv":
        df.to_csv(output, index=False, encoding="utf-8-sig")
    else:
        df.to_excel(output, index=False)
    
    console.print(f"[green]✅ 导出完成: {output}[/green]")
    console.print(f"可执行操作数: {len(updates)}")

@app.command()
def analyze_all(
    data_dir: Path = typer.Option(Path("data"), "--data-dir", "-d", help="包含多个JSON数据的目录"),
    output: Path = typer.Option("all_platforms_report.md", "--output", "-o", help="汇总报告")
):
    """
    分析所有已导入的跨平台数据
    """
    json_files = list(data_dir.glob("*.json"))
    if not json_files:
        console.print(f"[red]❌ 目录 {data_dir} 中没有JSON文件[/red]")
        raise typer.Exit(1)
    
    all_metrics = []
    
    for jf in json_files:
        with open(jf, "r", encoding="utf-8") as f:
            try:
                d = json.load(f)
                platform = d.get("platform", "unknown")
                df = pd.DataFrame(d["data"])
                
                # 计算
                cost = df["cost"].sum()
                revenue = df["revenue"].sum() if "revenue" in df.columns else 0
                impressions = df["impressions"].sum()
                clicks = df["clicks"].sum()
                conversions = df["conversions"].sum() if "conversions" in df.columns else 0
                
                metrics = {
                    "platform": platform,
                    "cost": cost,
                    "revenue": revenue,
                    "impressions": impressions,
                    "clicks": clicks,
                    "conversions": conversions,
                    "ctr": clicks / impressions if impressions > 0 else 0,
                    "cvr": conversions / clicks if clicks > 0 else 0,
                    "roi": revenue / cost if cost > 0 else 0
                }
                all_metrics.append(metrics)
            except Exception as e:
                console.print(f"[yellow]⚠️ 跳过 {jf}: {e}[/yellow]")
    
    # 汇总报告
    report = f"""# 跨平台效果汇总报告

生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
分析平台数: {len(all_metrics)}

## 平台对比

| 平台 | 花费 | 曝光 | 点击 | 转化 | CTR | CVR | ROI |
|------|------|------|------|------|-----|-----|-----|
"""
    
    for m in all_metrics:
        report += f"| {m['platform']} | ¥{m['cost']:,.0f} | {m['impressions']:,.0f} | {m['clicks']:,.0f} | {m['conversions']:,.0f} | {m['ctr']:.2%} | {m['cvr']:.2%} | {m['roi']:.2f} |\n"
    
    with open(output, "w", encoding="utf-8") as f:
        f.write(report)
    
    console.print(f"[green]✅ 跨平台报告已生成: {output}[/green]")
    
    # 控制台表格
    table = Table(title="平台效果总览")
    table.add_column("平台", style="cyan")
    table.add_column("花费", justify="right")
    table.add_column("CTR", justify="right")
    table.add_column("CVR", justify="right")
    table.add_column("ROI", justify="right")
    
    for m in all_metrics:
        table.add_row(
            m["platform"],
            f"¥{m['cost']:,.0f}",
            f"{m['ctr']:.2%}",
            f"{m['cvr']:.2%}",
            f"{m['roi']:.2f}"
        )
    console.print(table)

if __name__ == "__main__":
    app()
