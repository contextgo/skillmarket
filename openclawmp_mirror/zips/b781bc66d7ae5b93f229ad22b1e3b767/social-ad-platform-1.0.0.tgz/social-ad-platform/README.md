# 社交广告平台助手 (social-ad-platform)

**多平台广告数据半自动化管理工具**

---

## 📦 功能概览

| 命令 | 功能 |
|------|------|
| `import` | 导入平台CSV数据并标准化 |
| `analyze-campaign` | 分析单个活动效果（指标+趋势） |
| `analyze-all` | 跨平台数据汇总对比 |
| `suggest-optimization` | 基于规则的优化建议 |
| `export-updates` | 导出批量更新操作方案 |

---

## 🚀 快速开始

```bash
# 安装依赖
cd social-ad-platform
pip install -r requirements.txt

# 1. 从平台后台导出CSV（见下方各平台指南）
# 2. 导入数据
social-ad-platform import --platform douyin douyin_export.csv -o douyin.json

# 3. 分析活动
social-ad-platform analyze-campaign douyin.json -c "camp_001" -d 7

# 4. 获取优化建议
social-ad-platform suggest-optimization douyin.json -c "camp_001" -o suggestions.json

# 5. 导出操作清单
social-ad-platform export-updates suggestions.json -f csv -o updates.csv
```

---

## 📊 数据导入格式

系统支持的通用字段（平台CSV列名会自动映射）：

| 标准字段 | 说明 | 平台常见名 |
|----------|------|-----------|
| `campaign_id` | 活动ID | 计划ID、campaign id |
| `campaign` | 活动名称 | 计划名称、campaign_name |
| `date` | 投放日期 | 日期、day |
| `impressions` | 曝光量 | 展示、曝光 |
| `clicks` | 点击量 | 点击 |
| `conversions` | 转化量 | 转化、转化数 |
| `cost` | 花费（元） | 消费、费用 |
| `revenue` | 收入（元，可选） | 营收、收益 |

---

## 📈 支持平台

### 🎵 抖音 / 巨量引擎
**导出路径：** 巨量引擎广告管理平台 → 报表 → 自定义报表  
**关键维度：** 计划、日  
**必选指标：** 展示、点击、转化、消费  
**导出格式：** CSV

### 🌸 小红书蒲公英
**导出路径：** 蒲公英平台 → 数据管理 → 合作笔记效果  
**关键维度：** 笔记、日  
**必选指标：** 曝光、互动、转化（下单/表单）  
**导出格式：** CSV（UTF-8编码）

### 📺 B站花火
**导出路径：** B站花火平台 → 数据看板 → 导出  
**指标：** 播放量、点击、转化  
**注意：** B站转化数据可能有延迟（T+2）

### 🐦 微博粉丝通
**导出路径：** 微博粉丝通 → 数据报告 → 下载  
**关键指标：** 曝光、转发、点击、转化

### 💬 微信广告
**导出路径：** 微信广告平台 → 报表中心 → 广告效果报表  
**关键指标：** 曝光、点击、关注/转化

---

## 🔍 核心命令详解

### import

自动识别平台并标准化列名。

```bash
# 自动检测（从文件名）
social-ad-platform import data/douyin.csv

# 指定平台
social-ad-platform import -p bilibili data/bilibili.csv -o bl.json
```

---

### analyze-campaign

计算活动的核心KPI。

```bash
# 分析最近7天
social-ad-platform analyze-campaign douyin.json -c "camp_001" -d 7

# 分析全部活动（不指定-c）
social-ad-platform analyze-campaign douyin.json
```

输出：
- 汇总表格（CTR、CVR、CPA、ROI）
- 近7天趋势预览（按日）

---

### suggest-optimization

规则引擎生成建议。

**触发规则：**
- ROI > 2.0 且预算未用满 → 建议加预算
- ROI < 1.0 持续3天 → 建议暂停/降预算
- CTR < 行业基准50% → 建议换创意
- CPA > 基准150% → 建议优化转化路径

```bash
social-ad-platform suggest-optimization douyin.json -c "camp_001" -o suggest.json
```

输出JSON包含：
```json
{
  "campaign": "camp_001",
  "metrics": {"ctr": 0.025, "cvr": 0.08, "roi": 2.5},
  "suggestions": [
    {
      "type": "budget_increase",
      "priority": "high",
      "message": "ROI高达2.50且预算未用满，建议增加20%预算"
    }
  ]
}
```

---

### export-updates

将建议转化为可操作的表单。

```bash
social-ad-platform export-updates suggest.json -f csv -o batch_update.csv
```

输出CSV示例：
```csv
action,multiplier,reason
adjust_budget,1.2,ROI高达2.50且预算未用满，建议增加20%预算
replace_creative,,CTR仅1.2%，建议更换创意素材
```

---

### analyze-all

跨平台数据汇总对比。

```bash
# 将所有平台的JSON放在 data/ 目录
social-ad-platform analyze-all --data-dir data -o report.md
```

输出Markdown报告：
- 各平台总花费、曝光、点击、转化
- 平均CTR、CVR、ROI对比表

---

## 🎯 典型工作流

```bash
# Day 1: 导出并导入各平台数据
for p in douyin xhs bilibili; do
  social-ad-platform import --platform $p exports/${p}_$(date +%Y%m%d).csv -o data/${p}.json
done

# Day 2: 分析上周表现
social-ad-platform analyze-all --data-dir data -o weekly_report.md

# Day 3: 识别问题campaign并生成建议
for f in data/*.json; do
  social-ad-platform suggest-optimization $f -o suggestions/$(basename $f .json)_sugg.json
done

# Day 4: 导出批量更新任务
cat suggestions/*.json | python merge_suggestions.py > consolidated.json
social-ad-platform export-updates consolidated.json -f csv -o updates.csv
```

---

## ⚙️ 规则阈值配置

当前硬编码阈值位于 `main.py` 的 `suggest_optimization` 函数中：

```python
ctr_benchmark = 0.02  # 2% 行业平均CTR
cpa_benchmark = 50.0  # 50元 CPA基准
roi_threshold_high = 2.0
roi_threshold_low = 1.0
budget_usage_threshold = 0.8  # 80%
```

**如需自定义，请修改源码或提出Issue。**

---

## 🐛 常见问题

**Q: 导入报错列名不匹配**  
A: 检查CSV是否包含必要字段。可在GitHub Issue中提供样本数据，我会更新映射表。

**Q: 如何获取小时级数据？**  
A: 平台导出时选择"小时"维度，数据会增加 `hour` 列，支持时段分析。

**Q: ROI计算为负或NaN**  
A: 确保 `revenue` 字段存在且为数值。无收入数据时可仅分析CPA。

**Q: 批量操作是否可以直接调用API？**  
A: 目前半自动化模式，导出CSV仍需手动上传平台。未来考虑OAuth授权自动推送。

---

## 📈 Roadmap

- [ ] 支持更多平台（快手、知乎、抖音国际版）
- [ ] 创意素材自动评分（基于历史CTR）
- [ ] 竞品对标（同类campaign横向对比）
- [ ] 自动化数据拉取（登录+爬虫/API）
- [ ] 邮件报告自动发送

---

**版本:** 1.0.0  
**最后更新:** 2025-03-14
