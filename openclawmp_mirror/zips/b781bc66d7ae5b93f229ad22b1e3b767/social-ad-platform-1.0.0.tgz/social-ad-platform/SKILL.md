---
name: social-ad-platform
displayName: 社交广告平台助手
description: 半自动化广告平台管理工具 - 支持抖音、小红书、B站、微博、微信广告的数据导入、分析与优化建议
version: 1.0.0
type: skill
tags: advertising,social-media,douyin,xiaohongshu,bilibili,optimization
---

# 社交广告平台助手 (social-ad-platform)

专为Social Digital AE设计的跨平台广告管理工具。由于各平台API限制，本工具采用"半自动化"工作流：从平台后台导出CSV → 导入分析 → 生成优化建议 → 手动执行。

## 支持平台

- 🎵 **抖音/巨量引擎** - DOU+、千川、信息流
- 🌸 **小红书蒲公英** - 品牌合作、效果广告
- 📺 **B站花火** - UP主合作、品牌广告
- 🐦 **微博粉丝通** - 热搜、信息流
- 💬 **微信广告** - 公众号、朋友圈

---

## 核心功能

### 📋 活动导入 (list-campaigns)
导入平台导出的CSV数据，自动识别平台类型并标准化字段。

### 📊 效果分析 (analyze-campaign)
计算投放效果CTR、CVR、CPA、ROI，按时间趋势展示。

### 💡 优化建议 (suggest-optimization)
基于规则引擎给出优化方案：
- 预算重新分配（高ROI活动加预算）
- 创意替换建议（低CTR换素材）
- 定向调整（高CVR人群扩大）
- 时段优化（分时段效果分析）

### 📤 导出更新 (export-updates)
将优化方案导出为平台可识别的格式（CSV/Excel），方便批量上传。

---

## 工作流程

```bash
# 1. 从各平台后台导出数据（CSV格式）
# 2. 统一导入分析
social-ad-platform import --platform douyin --file douyin_export.csv
social-ad-platform import --platform xiaohongshu --file xhs_export.csv

# 3. 合并分析所有平台
social-ad-platform analyze-all --data merged.json --output analysis_report.md

# 4. 获取某个活动的优化建议
social-ad-platform suggest-optimization --campaign-id "camp_12345" --days 7

# 5. 导出批量更新方案
social-ad-platform export-updates --suggestions suggestions.json --format csv
```

---

## 数据格式

### 平台通用格式（导入要求）

```csv
campaign_id,campaign_name,start_date,end_date,impressions,clicks,conversions,cost,revenue
cam_001,春季大促,2025-03-01,2025-03-15,100000,2500,125,5000,15000
```

### 平台特定字段（可选）

**抖音巨量引擎：**
- `douyin_account` - 抖音号
- `douyin_ad_type` - 广告类型 (DOU+/千川/信息流)
- `creative_type` - 创意类型 (视频/图片)

**小红书蒲公英：**
- `xhs_kol_id` - KOL ID
- `xhs_note_type` - 笔记类型 (图文/视频)
- `xhs_exposure_type` - 曝光类型 (搜索/推荐)

---

## 优化规则库

### 规则1：ROI阈值调整
- **触发条件**：ROI > 2.0 且预算使用率 < 80%
- **建议**："建议增加20%预算"
- **触发条件**：ROI < 1.0 持续3天
- **建议**："建议暂停或降低出价"

### 规则2：CTR优化
- **触发条件**：CTR < 行业基准50%
- **建议**："建议替换创意素材，测试新图片/视频"

### 规则3：时段分析
- 按小时统计数据，识别高转化时段
- 建议："建议在20:00-22:00提高出价"

### 规则4：人群定向
- 分析高转化人群特征（年龄、地域、兴趣）
- 建议："扩大相似人群投放"

---

## 安装

```bash
cd social-ad-platform
pip install -r requirements.txt
```

---

## 快速示例

```bash
# 导入抖音数据
social-ad-platform import --platform douyin --file douyin_export.csv --output douyin_data.json

# 分析某个campaign（最近7天）
social-ad-platform analyze-campaign --data douyin_data.json --campaign-id "cam_001" --days 7

# 获取优化建议（JSON格式）
social-ad-platform suggest-optimization \
  --data douyin_data.json \
  --campaign-id "cam_001" \
  --output suggestions.json

# 导出为平台可导入格式
social-ad-platform export-updates --suggestions suggestions.json --format csv --output updates.csv
```

---

## 平台数据导出指南

### 抖音巨量引擎
1. 登录巨量引擎广告管理平台
2. 选择"广告报表"
3. 时间范围：最近7-30天
4. 维度：选择"计划"或"广告"
5. 指标包含：消耗、展示、点击、转化
6. 导出为CSV

### 小红书蒲公英
1. 进入蒲公英平台"数据管理"
2. 选择"合作笔记效果"
3. 导出包含：笔记ID、曝光、互动、转化
4. CSV编码选择UTF-8

---

## 注意事项

- 本工具**不直接调用平台API**，仅做本地数据分析
- 优化建议**仅供参考**，实际执行需人工确认
- 平台数据导出需至少 **T+1** 才能看到完整数据
- 不同广告账户的基准值不同，请结合实际调整规则阈值

---

## 故障排除

**问题：导入失败，列名不匹配**
- 确保CSV包含必要字段：campaign_id, impressions, clicks, conversions, cost
- 可使用 `--map` 参数手动映射字段名

**问题：ROI计算为NaN**
- 检查 revenue 字段是否存在且为数值
- 无revenue数据时可只分析CPA、CTR

---

## 待办功能（Roadmap）

- [ ] 支持更多平台（快手磁力引擎、知乎知+）
- [ ] 创意素材自动打分（基于历史CTR）
- [ ] 竞品对标分析（对比同类campaign）
- [ ] 自动化导出：直接登录后拉取数据（需API权限）

---

**版本:** 1.0.0  
**最后更新:** 2025-03-14
