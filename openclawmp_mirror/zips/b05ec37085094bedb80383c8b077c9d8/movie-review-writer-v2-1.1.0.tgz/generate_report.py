#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
影评手术刀 - Word文档生成器
基于天线同学风格的影评文章生成
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
import json
import sys
from datetime import datetime

class MovieReviewGenerator:
    def __init__(self, data_file=None):
        self.doc = Document()
        self.data = self.load_data(data_file) if data_file else self.get_default_data()
        self.setup_styles()
    
    def load_data(self, data_file):
        """加载研究数据"""
        try:
            with open(data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return self.get_default_data()
    
    def get_default_data(self):
        """默认数据结构"""
        return {
            "movie_name": "电影名称",
            "theme_type": "成长与代际",
            "hook": "开篇金句",
            "relationship_analysis": "",
            "dimension_upgrade": "",
            "core_insight": "",
            "golden_quotes": [],
            "interaction_question": "",
            "author": "影评手术刀",
            "date": datetime.now().strftime("%Y-%m-%d")
        }
    
    def setup_styles(self):
        """设置文档样式"""
        # 设置中文字体
        self.doc.styles['Normal'].font.name = 'Microsoft YaHei'
        self.doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        self.doc.styles['Normal'].font.size = Pt(10.5)
    
    def add_heading(self, text, level=1):
        """添加标题"""
        heading = self.doc.add_heading(text, level=level)
        heading.alignment = WD_ALIGN_PARAGRAPH.LEFT
        for run in heading.runs:
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            if level == 1:
                run.font.color.rgb = RGBColor(0, 51, 102)
                run.font.size = Pt(18)
            elif level == 2:
                run.font.color.rgb = RGBColor(0, 102, 153)
                run.font.size = Pt(14)
        return heading
    
    def add_paragraph(self, text, bold=False, color=None, italic=False):
        """添加段落"""
        p = self.doc.add_paragraph(text)
        for run in p.runs:
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            run.bold = bold
            run.italic = italic
            if color:
                run.font.color.rgb = color
        return p
    
    def add_quote(self, text):
        """添加引用/金句"""
        p = self.doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.3)
        p.paragraph_format.right_indent = Inches(0.3)
        run = p.add_run(f'"{text}"')
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
        run.font.color.rgb = RGBColor(0, 102, 153)
        run.italic = True
        return p
    
    def add_logic_chain(self, chain_steps):
        """添加逻辑链可视化"""
        self.add_heading("逻辑链", level=2)
        
        for i, step in enumerate(chain_steps, 1):
            p = self.doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.2)
            
            # 步骤编号
            run = p.add_run(f"{i}. ")
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            run.bold = True
            run.font.color.rgb = RGBColor(0, 102, 153)
            
            # 步骤内容
            run = p.add_run(step)
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            
            # 添加箭头（除了最后一步）
            if i < len(chain_steps):
                p = self.doc.add_paragraph()
                p.paragraph_format.left_indent = Inches(0.5)
                run = p.add_run("↓")
                run.font.name = 'Microsoft YaHei'
                run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
                run.font.color.rgb = RGBColor(150, 150, 150)
    
    def add_cover(self):
        """添加封面"""
        # 空行
        for _ in range(4):
            self.doc.add_paragraph()
        
        # 主标题
        title = self.doc.add_paragraph()
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = title.add_run("影评手术刀")
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(24)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0, 51, 102)
        
        # 副标题
        subtitle = self.doc.add_paragraph()
        subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
        movie_name = self.data.get("movie_name", "电影名称")
        run = subtitle.add_run(f"《{movie_name}》")
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(18)
        run.font.color.rgb = RGBColor(0, 102, 153)
        
        # 空行
        for _ in range(3):
            self.doc.add_paragraph()
        
        # 信息
        info = self.doc.add_paragraph()
        info.alignment = WD_ALIGN_PARAGRAPH.CENTER
        theme = self.data.get("theme_type", "")
        date = self.data.get("date", "")
        run = info.add_run(f"主题类型：{theme}\n日期：{date}")
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(100, 100, 100)
        
        # 分页
        self.doc.add_page_break()
    
    def add_opening(self):
        """添加开篇：抓钩子"""
        self.add_heading("一、开篇：抓钩子", level=1)
        
        hook = self.data.get("hook", "")
        if hook:
            self.add_quote(hook)
            self.doc.add_paragraph()
        
        self.add_paragraph("（此处展开开篇论述，制造认知冲突，预告核心观点）")
    
    def add_relationship_analysis(self):
        """添加第一部分：拆关系"""
        self.add_heading("二、拆关系：显微镜下的互动", level=1)
        
        # 逻辑链
        chain_steps = [
            "表面现象（剧情/冲突）",
            "关系拆解（夫妻/父子/师徒/个体与系统）",
            "动机剖析（为什么这样做）"
        ]
        self.add_logic_chain(chain_steps)
        
        self.doc.add_paragraph()
        
        content = self.data.get("relationship_analysis", "")
        if content:
            self.add_paragraph(content)
        else:
            self.add_paragraph("（此处进行关系拆解分析，不剧透关键情节）")
    
    def add_dimension_upgrade(self):
        """添加第二部分：升维度"""
        self.add_heading("三、升维度：从个人到时代", level=1)
        
        # 逻辑链
        chain_steps = [
            "个人命运（主角的选择与困境）",
            "社会结构（阶级/性别/权力关系）",
            "时代症候（内卷/算法/身份焦虑）"
        ]
        self.add_logic_chain(chain_steps)
        
        self.doc.add_paragraph()
        
        content = self.data.get("dimension_upgrade", "")
        if content:
            self.add_paragraph(content)
        else:
            self.add_paragraph("（此处进行时代维度升华，映射当下社会情绪）")
    
    def add_core_insight(self):
        """添加第三部分：核心洞察"""
        self.add_heading("四、核心洞察", level=1)
        
        content = self.data.get("core_insight", "")
        if content:
            self.add_paragraph(content)
        else:
            self.add_paragraph("（此处总结核心观点）")
        
        # 金句
        quotes = self.data.get("golden_quotes", [])
        if quotes:
            self.doc.add_paragraph()
            self.add_heading("金句提炼", level=2)
            for quote in quotes:
                self.add_quote(quote)
                self.doc.add_paragraph()
    
    def add_ending(self):
        """添加结尾：互动引导"""
        self.add_heading("五、写在最后", level=1)
        
        self.add_paragraph("（此处进行总结性论述）")
        self.doc.add_paragraph()
        
        # 互动问题
        question = self.data.get("interaction_question", "")
        if question:
            self.add_heading("互动话题", level=2)
            p = self.doc.add_paragraph()
            run = p.add_run(f"💬 {question}")
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            run.font.color.rgb = RGBColor(0, 102, 153)
            run.bold = True
    
    def generate(self, output_path=None):
        """生成完整报告"""
        # 封面
        self.add_cover()
        
        # 各章节
        self.add_opening()
        self.add_relationship_analysis()
        self.add_dimension_upgrade()
        self.add_core_insight()
        self.add_ending()
        
        # 保存
        if not output_path:
            movie_name = self.data.get("movie_name", "影评")
            output_path = f"影评手术刀_{movie_name}_{datetime.now().strftime('%Y%m%d')}.docx"
        
        self.doc.save(output_path)
        print(f"影评已生成：{output_path}")
        return output_path


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='生成影评Word文档')
    parser.add_argument('--data', '-d', help='数据文件路径(JSON格式)')
    parser.add_argument('--output', '-o', help='输出文件路径')
    
    args = parser.parse_args()
    
    generator = MovieReviewGenerator(args.data)
    output_path = generator.generate(args.output)
    
    print(f"✅ 影评生成完成：{output_path}")


if __name__ == '__main__':
    main()
