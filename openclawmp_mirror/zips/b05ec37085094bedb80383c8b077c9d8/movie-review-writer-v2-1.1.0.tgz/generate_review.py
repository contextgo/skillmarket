#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
影评手术刀 - 公众号文章生成器
直接产出可发布的完整影评文章
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml.ns import qn
import json
import sys
from datetime import datetime

class MovieReviewGenerator:
    def __init__(self, data_file=None):
        self.doc = Document()
        self.data = self.load_data(data_file) if data_file else self.get_default_data()
        self.setup_styles()
    
    def load_data(self, data_file):
        """加载数据"""
        try:
            with open(data_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return self.get_default_data()
    
    def get_default_data(self):
        """默认数据"""
        return {
            "movie_name": "电影名称",
            "theme_type": "成长与代际",
            "title_options": [],
            "selected_title": "",
            "hook": "",
            "opening": "",
            "relationship_analysis": "",
            "dimension_upgrade": "",
            "core_insight": "",
            "golden_quotes": [],
            "interaction_question": "",
            "author": "影评手术刀",
            "date": datetime.now().strftime("%Y-%m-%d")
        }
    
    def setup_styles(self):
        """设置文档样式"""
        self.doc.styles['Normal'].font.name = 'Microsoft YaHei'
        self.doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        self.doc.styles['Normal'].font.size = Pt(11)
    
    def add_title(self, text, is_main=True):
        """添加标题"""
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER if is_main else WD_ALIGN_PARAGRAPH.LEFT
        run = p.add_run(text)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        if is_main:
            run.font.size = Pt(18)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0, 51, 102)
        else:
            run.font.size = Pt(14)
            run.font.bold = True
            run.font.color.rgb = RGBColor(0, 102, 153)
        return p
    
    def add_paragraph(self, text, bold=False, color=None, is_quote=False):
        """添加段落"""
        p = self.doc.add_paragraph()
        if is_quote:
            p.paragraph_format.left_indent = Inches(0.3)
            p.paragraph_format.right_indent = Inches(0.3)
        
        run = p.add_run(text)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(11)
        run.bold = bold
        if color:
            run.font.color.rgb = color
        if is_quote:
            run.italic = True
            run.font.color.rgb = RGBColor(0, 102, 153)
        return p
    
    def add_section_title(self, text):
        """添加章节标题"""
        p = self.doc.add_paragraph()
        run = p.add_run(text)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(13)
        run.font.bold = True
        run.font.color.rgb = RGBColor(0, 102, 153)
        return p
    
    def add_divider(self):
        """添加分隔线"""
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run("—" * 20)
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.color.rgb = RGBColor(200, 200, 200)
    
    def add_title_options(self):
        """添加标题选项"""
        self.add_title("标题选项", is_main=False)
        options = self.data.get("title_options", [])
        for i, option in enumerate(options, 1):
            p = self.doc.add_paragraph()
            p.paragraph_format.left_indent = Inches(0.2)
            run = p.add_run(f"{i}. {option}")
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            run.font.size = Pt(11)
        self.doc.add_paragraph()
    
    def add_main_title(self):
        """添加主标题"""
        title = self.data.get("selected_title", "")
        if title:
            self.add_title(title, is_main=True)
            self.doc.add_paragraph()
    
    def add_opening(self):
        """添加开篇"""
        hook = self.data.get("hook", "")
        opening = self.data.get("opening", "")
        
        if hook:
            self.add_paragraph(f'"{hook}"', is_quote=True)
            self.doc.add_paragraph()
        
        if opening:
            self.add_paragraph(opening)
            self.doc.add_paragraph()
    
    def add_relationship_analysis(self):
        """添加关系分析"""
        self.add_section_title("一、拆关系：显微镜下的控制")
        self.doc.add_paragraph()
        
        content = self.data.get("relationship_analysis", "")
        if content:
            paragraphs = content.split('\n\n')
            for para in paragraphs:
                if para.strip():
                    self.add_paragraph(para.strip())
                    self.doc.add_paragraph()
    
    def add_dimension_upgrade(self):
        """添加维度升华"""
        self.add_section_title("二、升维度：从家庭到时代")
        self.doc.add_paragraph()
        
        content = self.data.get("dimension_upgrade", "")
        if content:
            paragraphs = content.split('\n\n')
            for para in paragraphs:
                if para.strip():
                    self.add_paragraph(para.strip())
                    self.doc.add_paragraph()
    
    def add_core_insight(self):
        """添加核心洞察"""
        self.add_section_title("三、核心洞察")
        self.doc.add_paragraph()
        
        content = self.data.get("core_insight", "")
        if content:
            paragraphs = content.split('\n\n')
            for para in paragraphs:
                if para.strip():
                    self.add_paragraph(para.strip())
                    self.doc.add_paragraph()
        
        # 金句
        quotes = self.data.get("golden_quotes", [])
        if quotes:
            self.doc.add_paragraph()
            self.add_section_title("金句提炼")
            for quote in quotes:
                self.add_paragraph(f"• {quote}", is_quote=False)
    
    def add_ending(self):
        """添加结尾"""
        self.add_divider()
        self.doc.add_paragraph()
        
        # 互动问题
        question = self.data.get("interaction_question", "")
        if question:
            p = self.doc.add_paragraph()
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = p.add_run(f"💬 {question}")
            run.font.name = 'Microsoft YaHei'
            run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
            run.font.size = Pt(11)
            run.font.color.rgb = RGBColor(0, 102, 153)
            run.bold = True
        
        self.doc.add_paragraph()
        
        # 作者信息
        author = self.data.get("author", "影评手术刀")
        date = self.data.get("date", "")
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        run = p.add_run(f"—— {author} {date}")
        run.font.name = 'Microsoft YaHei'
        run._element.rPr.rFonts.set(qn('w:eastAsia'), 'Microsoft YaHei')
        run.font.size = Pt(10)
        run.font.color.rgb = RGBColor(150, 150, 150)
    
    def generate(self, output_path=None):
        """生成完整影评"""
        # 标题选项
        self.add_title_options()
        
        # 分页
        self.doc.add_page_break()
        
        # 主标题
        self.add_main_title()
        
        # 开篇
        self.add_opening()
        
        # 各章节
        self.add_relationship_analysis()
        self.add_dimension_upgrade()
        self.add_core_insight()
        
        # 结尾
        self.add_ending()
        
        # 保存
        if not output_path:
            movie_name = self.data.get("movie_name", "影评")
            output_path = f"影评_{movie_name}_{datetime.now().strftime('%Y%m%d')}.docx"
        
        self.doc.save(output_path)
        print(f"✅ 影评文章已生成：{output_path}")
        return output_path


def main():
    """主函数"""
    import argparse
    
    parser = argparse.ArgumentParser(description='生成公众号影评文章')
    parser.add_argument('--data', '-d', help='数据文件路径(JSON格式)')
    parser.add_argument('--output', '-o', help='输出文件路径')
    
    args = parser.parse_args()
    
    generator = MovieReviewGenerator(args.data)
    output_path = generator.generate(args.output)
    
    print(f"✅ 文章生成完成！可直接复制到公众号发布。")
    print(f"📄 文件路径：{output_path}")


if __name__ == '__main__':
    main()
