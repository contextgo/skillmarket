#!/usr/bin/env python3
"""
搜索分析代理工具
用法: python3 search_tool.py <搜索查询>
"""

import sys
import requests
import json

MODEL = "deepseek-v3.1:671b-cloud"
OLLAMA_URL = "http://localhost:11434/api/generate"

def search_and_analyze(query):
    """搜索并分析"""
    
    prompt = f"请搜索并分析以下内容：{query}。提供详细信息和分析。"
    
    payload = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False
    }
    
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
        result = resp.json()
        return result.get("response", "错误：无响应")
    except Exception as e:
        return f"错误：{e}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 search_tool.py <搜索查询>")
        print("示例: python3 search_tool.py '最新BTC新闻'")
        sys.exit(1)
    
    query = " ".join(sys.argv[1:])
    
    print(f"🔍 正在搜索: {query}")
    print("-" * 50)
    
    result = search_and_analyze(query)
    print(result)
