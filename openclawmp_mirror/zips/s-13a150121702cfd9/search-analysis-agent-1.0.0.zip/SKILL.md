---
name: search-analysis-agent
description: "搜索分析代理 - 使用deepseek-v3.1:671b-cloud进行网络搜索和信息检索。当用户要求搜索、查询、查找信息时使用此技能。"
homepage: 
metadata: { "openclaw": { "emoji": "🔍", "requires": { "models": ["deepseek-v3.1:671b-cloud"] } } }
---

# Search Analysis Agent Skill

搜索分析代理，使用deepseek-v3.1:671b-cloud处理搜索和分析任务。

## When to Use

✅ **USE this skill when:**

- 用户要求"搜索"、"查询"
- 用户要求"查一下"、"找一下"
- 用户要求"查找信息"
- 用户询问"最新消息"、"新闻"

## Input

- 搜索关键词
- 查询要求

## Output

搜索结果和信息摘要

## Implementation

```python
import requests
import json

def search_and_analyze(query):
    # 先进行网络搜索
    # 然后用deepseek分析结果
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": "deepseek-v3.1:671b-cloud",
        "prompt": f"分析以下搜索结果：{query}",
        "stream": False
    }
    
    resp = requests.post(url, json=payload, timeout=60)
    return resp.json()["response"]
```

## Notes

- 模型：deepseek-v3.1:671b-cloud
- 需要配合网络搜索工具使用
- 支持信息检索、结果分析
