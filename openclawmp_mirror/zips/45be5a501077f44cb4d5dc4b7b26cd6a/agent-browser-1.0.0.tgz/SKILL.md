---
name: agent-browser
description: |
  A fast Rust-based headless browser automation CLI with Node.js fallback that enables AI agents 
  to navigate, click, type, and snapshot pages via structured commands. Supports video recording, 
  network interception, session management, and device emulation.
read_when:
  - Automating web interactions
  - Extracting structured data from pages
  - Filling forms programmatically
  - Testing web UIs
  - Recording browser sessions
metadata:
  emoji: 🌐
  requires:
    bins: ["node", "npm"]
  os: ["linux", "darwin", "win32"]
---

# Agent Browser - Browser Automation

## Use Cases

- User says "open a browser and go to example.com"
- User says "fill out this form automatically"
- User says "take a screenshot of the page"
- User says "record a demo video of the workflow"
- User wants to extract data from a webpage
- User wants to automate a web UI test

## Installation

### npm (Recommended)

```bash
npm install -g agent-browser
agent-browser install
agent-browser install --with-deps
```

### From Source

```bash
git clone https://github.com/vercel-labs/agent-browser
cd agent-browser
pnpm install
pnpm build
agent-browser install
```

## Core Workflow

```
1. Navigate: agent-browser open <url>
2. Snapshot: agent-browser snapshot -i (returns elements with refs like @e1, @e2)
3. Interact: Use refs from snapshot to click, fill, etc.
4. Re-snapshot: After navigation or DOM changes
```

## Commands Reference

### Navigation
| Command | Description |
|---------|-------------|
| `open <url>` | Navigate to URL |
| `back` / `forward` / `reload` | Browser navigation |
| `close` | Close browser |

### Snapshot (Page Analysis)
| Command | Description |
|---------|-------------|
| `snapshot` | Full accessibility tree |
| `snapshot -i` | Interactive elements only (recommended) |
| `snapshot -c` | Compact output |
| `snapshot -d 3` | Limit depth to 3 |
| `snapshot -s "#main"` | Scope to CSS selector |

### Element Interactions (Use @refs from snapshot)
| Command | Description |
|---------|-------------|
| `click @e1` | Click element |
| `fill @e2 "text"` | Clear and type |
| `type @e2 "text"` | Type without clearing |
| `press Enter` / `press Control+a` | Press key or combo |
| `hover @e1` | Hover over element |
| `select @e1 "value"` | Select dropdown |
| `upload @e1 file.pdf` | Upload file |
| `scroll down 500` | Scroll page |
| `scrollintoview @e1` | Scroll element into view |
| `drag @e1 @e2` | Drag and drop |

### Information Extraction
| Command | Description |
|---------|-------------|
| `get text @e1` | Get element text |
| `get value @e1` | Get input value |
| `get attr @e1 href` | Get attribute |
| `get title` / `get url` | Page info |
| `get count ".item"` | Count elements |

### Screenshots & Recording
| Command | Description |
|---------|-------------|
| `screenshot` | Screenshot to stdout |
| `screenshot path.png` | Save to file |
| `screenshot --full` | Full page screenshot |
| `pdf output.pdf` | Save as PDF |
| `record start ./demo.webm` | Start video recording |
| `record stop` | Stop recording |

### Wait Commands
| Command | Description |
|---------|-------------|
| `wait @e1` | Wait for element |
| `wait 2000` | Wait milliseconds |
| `wait --text "Success"` | Wait for text |
| `wait --url "/dashboard"` | Wait for URL |
| `wait --load networkidle` | Wait for network idle |

### Session & State
| Command | Description |
|---------|-------------|
| `state save auth.json` | Save session state |
| `state load auth.json` | Load saved state |
| `--session <name>` | Use isolated session |

### Network Control
| Command | Description |
|---------|-------------|
| `network route <url>` | Intercept requests |
| `network route <url> --abort` | Block requests |
| `network route <url> --body '{}'` | Mock response |

### Device & Settings
| Command | Description |
|---------|-------------|
| `set viewport 1920 1080` | Set viewport |
| `set device "iPhone 14"` | Emulate device |
| `set geo 37.7749 -122.4194` | Set geolocation |
| `set offline on` | Toggle offline |
| `set headers '{"X-Key":"v"}'` | Custom headers |

## Example Workflows

### Form Submission
```bash
agent-browser open https://example.com/form
agent-browser snapshot -i
# Output shows: textbox "Email" [ref=e1], button "Submit" [ref=e2]

agent-browser fill @e1 "user@example.com"
agent-browser click @e2
agent-browser wait --load networkidle
agent-browser snapshot -i
```

### Authentication with Saved State
```bash
# First login
agent-browser open https://app.example.com/login
agent-browser snapshot -i
agent-browser fill @e1 "username"
agent-browser fill @e2 "password"
agent-browser click @e3
agent-browser wait --url "/dashboard"
agent-browser state save auth.json

# Later sessions
agent-browser state load auth.json
agent-browser open https://app.example.com/dashboard
```

### Data Extraction
```bash
agent-browser open https://example.com/products
agent-browser snapshot -i
agent-browser get text @e1  # Product name
agent-browser get text @e2  # Price
agent-browser click @e3     # Next page
agent-browser wait 1000
agent-browser snapshot -i
```

## Options

- `--session <name>` - Isolated session
- `--json` - JSON output
- `--full` - Full page screenshot
- `--headed` - Show browser window
- `--timeout <ms>` - Command timeout
- `--cdp <port>` - Connect via Chrome DevTools Protocol

## Important Notes

- **Refs change on navigation** - Always re-snapshot after page changes
- **Use `fill` not `type`** for input fields to clear existing text
- **Add `wait` after complex operations** to ensure page stability
- **Sessions are isolated** - Use `--session` for parallel browsers

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Command not found (Linux ARM64) | Use full path in bin folder |
| Element not found | Use snapshot to get correct ref |
| Page not loaded | Add wait command after navigation |
| Need to debug | Use `--headed` to see browser window |

## Related Links

- Skill issues: https://github.com/TheSethRose/Agent-Browser-CLI
- agent-browser CLI: https://github.com/vercel-labs/agent-browser
