# Agent Browser

基于 Rust 的高性能无头浏览器自动化 CLI 工具，支持 AI Agent 通过结构化命令进行网页导航、点击、输入和页面快照。

## 功能特性

- **高性能**: Rust 实现，速度极快
- **结构化交互**: 使用 `@e1`, `@e2` 等引用 ID 与页面元素交互
- **完整工作流**: 导航 → 快照 → 交互 → 验证
- **会话管理**: 支持状态保存/加载，实现持久化登录
- **多会话并行**: 可同时操作多个浏览器实例
- **视频录制**: 支持录制操作过程
- **网络拦截**: 可拦截、阻断或模拟网络请求
- **设备模拟**: 支持模拟手机、平板等设备

## 安装

### 通过 npm 安装（推荐）

```bash
npm install -g agent-browser
agent-browser install
agent-browser install --with-deps
```

### 从源码安装

```bash
git clone https://github.com/vercel-labs/agent-browser
cd agent-browser
pnpm install
pnpm build
agent-browser install
```

## 快速开始

```bash
# 打开网页
agent-browser open https://example.com

# 获取交互元素快照
agent-browser snapshot -i

# 点击元素
agent-browser click @e1

# 填写表单
agent-browser fill @e2 "text"

# 关闭浏览器
agent-browser close
```

## 核心工作流

1. **导航**: `agent-browser open <url>`
2. **快照**: `agent-browser snapshot -i`（返回带引用的交互元素）
3. **交互**: 使用引用 ID 执行点击、输入等操作
4. **重快照**: 页面变化后重新获取引用

## 命令分类

### 导航
- `open <url>` - 打开网页
- `back` / `forward` / `reload` - 浏览控制
- `close` - 关闭浏览器

### 快照分析
- `snapshot` - 完整可访问性树
- `snapshot -i` - 仅交互元素（推荐）
- `snapshot -c` - 紧凑输出
- `snapshot -d 3` - 限制深度

### 元素交互
- `click @e1` - 点击
- `fill @e1 "text"` - 清空并输入
- `type @e1 "text"` - 直接输入
- `press Enter` - 按键
- `hover @e1` - 悬停
- `select @e1 "value"` - 下拉选择
- `upload @e1 file.pdf` - 文件上传

### 信息获取
- `get text @e1` - 获取文本
- `get value @e1` - 获取输入值
- `get attr @e1 href` - 获取属性
- `get title` / `get url` - 页面信息

### 等待
- `wait @e1` - 等待元素出现
- `wait 2000` - 等待毫秒
- `wait --text "Success"` - 等待文本
- `wait --load networkidle` - 等待网络空闲

### 截图与 PDF
- `screenshot` - 截图
- `screenshot --full` - 整页截图
- `pdf output.pdf` - 保存为 PDF

### 视频录制
- `record start ./demo.webm` - 开始录制
- `record stop` - 停止录制

### 网络控制
- `network route <url>` - 拦截请求
- `network route <url> --abort` - 阻断请求
- `network route <url> --body '{}'` - 模拟响应

### 会话管理
- `state save auth.json` - 保存状态
- `state load auth.json` - 加载状态
- `--session <name>` - 使用独立会话

## 使用示例

### 表单提交

```bash
agent-browser open https://example.com/form
agent-browser snapshot -i
# 输出: textbox "Email" [ref=e1], textbox "Password" [ref=e2], button "Submit" [ref=e3]

agent-browser fill @e1 "user@example.com"
agent-browser fill @e2 "password123"
agent-browser click @e3
agent-browser wait --load networkidle
agent-browser snapshot -i  # 检查结果
```

### 带状态保持的登录

```bash
# 首次登录
agent-browser open https://app.example.com/login
agent-browser snapshot -i
agent-browser fill @e1 "username"
agent-browser fill @e2 "password"
agent-browser click @e3
agent-browser wait --url "/dashboard"
agent-browser state save auth.json

# 后续会话直接加载状态
agent-browser state load auth.json
agent-browser open https://app.example.com/dashboard
```

## 调试选项

- `--headed` - 显示浏览器窗口
- `--json` - JSON 格式输出
- `--timeout <ms>` - 设置超时
- `--cdp <port>` - 通过 Chrome DevTools Protocol 连接

## 注意事项

- 引用 ID 在页面导航后会变化，需重新获取快照
- 使用 `fill` 而非 `type` 确保清空已有文本
- 复杂操作后建议添加 `wait` 等待页面稳定

## 依赖

- Node.js
- npm

## 相关链接

- Skill 问题反馈: https://github.com/TheSethRose/Agent-Browser-CLI
- agent-browser CLI: https://github.com/vercel-labs/agent-browser
