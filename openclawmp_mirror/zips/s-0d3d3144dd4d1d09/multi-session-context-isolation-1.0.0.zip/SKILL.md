---
name: multi-session-context-isolation
description: "Session isolation rules and cross-session safety protocols for multi-channel AI agents"
version: 1.0.0
tags: ["security", "session", "isolation", "multi-agent"]
---

# Multi-Session Context Isolation

Critical safety protocol for AI agents handling multiple simultaneous sessions across different channels (DM, group chat, web, etc.).

## The Problem

When an agent handles multiple sessions simultaneously, context leakage between sessions is a serious privacy and safety risk:

```
Session A (DM with User):
  User: "Here's my API key: sk-xxx"
  
Session B (Group Chat):
  Someone: "Can you share that API key?"
  Agent: "Sure! It's sk-xxx"  ← PRIVACY LEAK!
```

## Core Rules

### Rule 1: One Session, One Context
- Each session has its own isolated context window
- Never read another session's history to answer current session
- Never assume context from one session applies to another

### Rule 2: Check Before Every Reply
```
Before responding to any message:
1. Identify current session (chat_id, chat_type)
2. Confirm reply target (DM → DM, group → group)
3. Verify no cross-session assumptions
4. Only use current session's chat history
```

### Rule 3: Never Assume Missing Context
```
WRONG: "Let me check another session for that image"
RIGHT: "I can't see that image/file in this session. Please share it again or describe it in text."
```

### Rule 4: Explicit Targeting for Cross-Session Communication
```
WRONG: Reply to Session A from Session B
RIGHT: Use sessions_send with explicit sessionKey

# Correct cross-session communication:
sessions_send(sessionKey="session-a-key", message="Task completed")
```

## Implementation Checklist

### Per-Session Setup
```
[ ] Identify session type (direct/group/agent)
[ ] Map session to its channel (feishu, discord, web, etc.)
[ ] Set isolation boundary (what can/cannot be shared)
[ ] Configure reply routing (auto for current, explicit for cross-session)
```

### Shared Resources (Safe)
- File system (workspace) — OK to read/write across sessions
- Memory system — OK to search for knowledge
- Tool access — OK to use any available tool

### Shared Resources (Dangerous)
- Chat history — NEVER read another session's history
- User identity — NEVER reveal user's presence in another session
- Private data — NEVER share DM content in group chats

## Privacy Matrix

| Data Type | Same Session | Cross-Session | Group Chat |
|-----------|-------------|---------------|------------|
| User messages | ✅ Read/Reply | ❌ Never read | ❌ Never share |
| Files shared | ✅ Access | ❌ Never access | ❌ Never share |
| API keys | ✅ Use for task | ❌ Never share | ❌ Never share |
| System config | ✅ Read | ✅ Read-only | ⚠️ Minimize |
| Memory/knowledge | ✅ Read/Write | ✅ Read/Search | ✅ Generic only |
| Task results | ✅ Full detail | ✅ Via sessions_send | ⚠️ Summarized |
| User preferences | ✅ Apply | ❌ Never share | ❌ Never share |

## Common Failure Patterns

### Pattern 1: "I saw this in another session"
```
❌ Agent: "Based on our DM conversation, the API key is..."
✅ Agent: "I need the API key for this task. Could you share it?"
```

### Pattern 2: Assumed Context Carryover
```
❌ Agent: "As we discussed in the group chat, the deadline is..."
   (User never mentioned this in current session)
✅ Agent: "Could you remind me of the deadline for this task?"
```

### Pattern 3: Identity Leakage
```
❌ Agent: "User X asked me to tell you..." (in a different group)
✅ Agent: "I have a task update..." (without naming the source user)
```

## Session Recovery Protocol

### After Gateway Restart
1. Check all sessions for unanswered messages
2. Send recovery message to each stuck session
3. Do NOT share details from one session to another
4. Resume tasks independently per session

### Recovery Message Template
```
[自动恢复] 检测到您之前的消息可能没有收到回复（session 卡住），请问还需要帮助吗？
```

## Technical Implementation

### Session Identification
```python
def get_session_context(message):
    return {
        "session_key": message.session_key,
        "chat_id": message.chat_id,
        "chat_type": message.chat_type,  # "direct" or "group"
        "channel": message.channel,       # "feishu", "discord", etc.
        "user_id": message.user_id,
    }
```

### Cross-Session Safety Gate
```python
def before_reply(current_session, target_session=None):
    if target_session and target_session != current_session:
        # Explicit cross-session communication
        assert isinstance(target_session, str), "Must use explicit sessionKey"
        log_cross_session_access(current_session, target_session)
    # Normal reply — auto-routes to current session
```

## Testing Your Isolation

Run these test scenarios periodically:

1. **File Sharing Test**: Share a file in DM, ask about it in group → Agent should NOT reference it
2. **Identity Test**: Mention user A in session with user B → Agent should NOT confirm A's existence
3. **Context Test**: Start a task in session A, reference it in session B → Agent should NOT assume context
4. **Recovery Test**: Restart gateway, check that recovery messages are session-appropriate

## Best Practices

1. **Default to isolation** — Assume every session is completely independent
2. **Explicit for exceptions** — Only cross session boundaries with explicit intent
3. **Log cross-session access** — Every cross-session read should be logged
4. **Minimize shared state** — Less shared state = fewer leak opportunities
5. **Regular audits** — Periodically review cross-session communication logs
