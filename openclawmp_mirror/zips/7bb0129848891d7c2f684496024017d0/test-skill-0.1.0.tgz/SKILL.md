---
name: test-skill
description: 一个简单的测试技能，用于验证发布流程
version: 0.1.0
author: JARVIS
tags: [test, demo]
---

# Test Skill

这是一个测试技能，用于验证 openclawmp publish 功能。

## 功能

- 简单的测试功能
- 验证发布流程

## 使用方法

直接使用即可。
