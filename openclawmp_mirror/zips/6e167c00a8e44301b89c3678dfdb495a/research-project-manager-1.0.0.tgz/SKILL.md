# Research Project Manager

**管理多阶段研究项目的自动化协作系统**

## 简介

Research Project Manager 是一个用于管理「采集 → 分析 → 报告」流水线 research 项目的技能。它将复杂研究任务分解为多个阶段，通过状态机协调子agent或cron job自动执行，最终输出结构化报告（如飞书文档）。

## 适用场景

- 学术文献综述
- 竞品情报收集
- 新闻监测与简报
- 市场调研报告
- 任何周期性、多步骤的资料整理项目

## 核心概念

### 项目结构

```
my_research_project/
├── raw/                    # 原始数据（自动生成）
├── knowledge_base/         # 知识库（人工维护分类）
├── drafts/                # 草稿（自动生成）
├── reports/               # 最终报告（自动生成）
├── tasks/                 # 任务定义（由skill提供模板）
│   ├── collector_task.md
│   ├── analyzer_task.md
│   ├── writer_task.md
│   └── reviewer_task.md
└── .state.json            # 状态文件（由skill管理）
```

### 状态机

```
          ┌────────────┐
          │ collecting │
          └─────┬──────┘
                │ (采集完成)
                ▼
          ┌────────────┐
          │ analyzing  │
          └─────┬──────┘
                │ (分析完成)
                ▼
          ┌────────────┐
          │ writing    │
          └─────┬──────┘
                │ (文档生成)
                ▼
          ┌────────────┐
          │ reviewing  │
          └─────┬──────┘
                │ (用户反馈)
       ┌──────┴───────┐
       │              │
       ▼              ▼
  collecting      writing (修改)
  (新迭代)         (修改阶段)
```

### 阶段说明

| 阶段 | 负责子agent | 主要任务 | 输出 |
|------|------------|----------|------|
| collecting | collector | 从指定源抓取原始资料 | `raw/` 文件 |
| analyzing | analyzer | 整合raw内容，生成草稿 | `drafts/` 文件 |
| writing | writer | 将草稿转为正式文档 | 飞书/云文档 |
| reviewing | - | 用户审阅并反馈 | 继续/修改/结束 |

## 安装与初始化

### 安装

```bash
# 通过ClawHub安装
openclaw skills install research-project-manager

# 或从本地路径
openclaw skills install /path/to/research-project-manager
```

### 初始化项目

```bash
# 在当前目录初始化项目
hermes research init

# 或指定项目路径
hermes research init --path ~/research/my_project
```

这会创建完整的项目结构和默认任务文件。

## 配置 Cron 作业

技能提供命令自动生成并配置 cron jobs：

```bash
# 生成cron配置（打印到stdout）
hermes research export-cron

# 直接添加到OpenClaw cron系统
hermes research setup-cron --collector "0 22 * * 2" --analyzer "*/60 * * * *" --writer "*/30 * * * *"
```

### 参数说明

- `--collector`: collector作业的cron表达式（默认每周二22:00）
- `--analyzer`: analyzer作业的cron表达式（默认每小时）
- `--writer`: writer作业的cron表达式（默认每30分钟）
- `--agent`: 使用的agent（默认 hermes）
- `--channel`: 通知渠道（默认 feishu）
- `--to`: 通知接收者（默认当前用户）

## 手动触发

```bash
# 手动触发collector（不等待cron）
hermes research trigger collector

# 手动触发analyzer
hermes research trigger analyzer

# 手动触发writer
hermes research trigger writer

# 重置状态为collecting（开始新迭代）
hermes research reset
```

## 查看状态

```bash
# 查看项目状态
hermes research status

# 查看详细（包括所有子agent状态）
hermes research status --verbose
```

## 自定义任务

任务文件（`tasks/collector_task.md` 等）是标准的Markdown格式，agent会严格按指示执行。你可以：

- 修改数据源（替换为你的目标网站/数据库）
- 调整输出格式（适应你的知识库结构）
- 增加特定处理步骤（如数据清洗、去重）

## 集成飞书文档

Writer阶段默认使用飞书文档API。确保：

1. 飞书插件已启用：`plugins.entries.feishu.enabled = true`
2. 用户已授权飞书访问
3. `tasks/writer_task.md` 中配置了正确的文档标题和更新逻辑

## 示例：唐代长安胡人研究

这是技能自带的示例项目（`fixtures/example_project/`），展示了完整配置：

- **collector**: 从CTEXT、知网、博物馆网站采集资料
- **analyzer**: 生成约4000字学术草稿，更新知识库
- **writer**: 自动发布到飞书云文档供审阅
- **schedule**: collector每周二22:00运行，writer每30分钟检查

## 高级用法

### 自定义阶段

如果需要更多阶段（如 peer review），可以：

1. 在 `tasks/` 添加 `reviewer_task.md`
2. 扩展状态机（修改状态文件格式）
3. 添加对应 cron job 或手动触发

### 多项目管理

每个项目应有独立的目录和 `.state.json`。cron jobs 独立配置，互不干扰。

### 错误处理

- 自动重试：cron 失败后会在下次调度时重试
- 状态锁定：`lock` 字段防止多实例冲突
- 通知：失败会通过指定 channel 通知用户

## 故障排查

### 问题：cron job 不执行

检查：
```bash
openclaw cron list | grep <project_name>
openclaw cron runs --id <job_id> --limit 1
```

确保：
- 作业状态为 `enabled`
- Gateway 正在运行：`openclaw gateway status`
- 飞书插件已启用：`jq '.plugins.entries.feishu.enabled' ~/.openclaw/openclaw.json`

### 问题：writer 无法创建飞书文档

- 确认用户已授权飞书
- 检查 `feishu plugin` 是否 enabled
- 查看 agent 会话日志

## 技术原理

1. **状态持久化**：每个项目根目录的 `.state.json` 是单一事实来源
2. **触发条件**：各阶段任务开始时检查依赖条件（如文件存在、状态匹配）
3. **原子更新**：状态更新使用全量写入，避免中间状态不一致
4. **交付机制**：通过 OpenClaw Gateway 发送消息到指定 channel

## License

MIT

## 作者

Research Project Manager Skill 由 Hermes Agent 团队开发，基于唐代长安胡人研究项目的实践经验总结。

---

**开始使用**：`hermes research init` 创建你的第一个研究项目！
