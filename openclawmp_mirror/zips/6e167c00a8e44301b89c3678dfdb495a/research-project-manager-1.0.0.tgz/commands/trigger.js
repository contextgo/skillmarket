#!/usr/bin/env node
/**
 * hermes research trigger
 * 手动触发特定阶段
 */

const path = require('path');
const fs = require('fs');

const args = process.argv.slice(2);

if (args.includes('--help') || args.includes('-h')) {
  console.log(`Usage: hermes research trigger <stage>

Stages:
  collector   资料采集阶段
  analyzer    分析生成阶段
  writer      撰写文档阶段

Examples:
  hermes research trigger collector
  hermes research trigger analyzer
`);
  process.exit(0);
}

const stage = args[0];
const validStages = ['collector', 'analyzer', 'writer'];

if (!validStages.includes(stage)) {
  throw new Error(`无效的阶段: ${stage}。有效值: ${validStages.join(', ')}`);
}

// 获取项目根目录
const projectRoot = process.cwd();
const statePath = path.join(projectRoot, '.state.json');

if (!fs.existsSync(statePath)) {
  throw new Error(`未找到 .state.json，请确认在项目根目录运行`);
}

// 根据阶段查找对应的 cron job ID
const state = JSON.parse(fs.readFileSync(statePath, 'utf8'));
const jobId = state.cron_jobs[stage];

if (!jobId) {
  throw new Error(`项目配置中未找到 ${stage} 的 cron job ID`);
}

// 执行触发
const { execSync } = require('child_process');
try {
  execSync(`openclaw cron run --expect-final ${jobId}`, { stdio: 'inherit' });
  console.log(`✅ 已手动触发 ${stage} (jobId: ${jobId})`);
} catch (e) {
  console.error(`❌ 触发失败:`, e.message);
  process.exit(1);
}