#!/usr/bin/env node
/**
 * hermes research init
 * 创建新研究项目并配置初始状态
 */

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

// 解析命令行参数
const args = process.argv.slice(2);
let projectName = null;
let projectPath = process.cwd();

// 查找可用选项
const options = {
  '--project': '项目名称',
  '--path': '项目目录（可选，默认当前目录）'
};

if (args.includes('--help') || args.includes('-h')) {
  console.log(`Usage: hermes research init [options]

Options:
  --project <name>   项目名称（必须）
  --path <path>      项目根目录（可选，默认当前目录）

Examples:
  hermes research init --project "family_tree"
  hermes research init                # 在当前目录创建项目
  hermes research init --path .     # 明确当前目录
`);
  process.exit(0);
}

// 解析参数
for (let i = 0; i < args.length; i++) {
  switch(args[i]) {
    case '--project':
      projectName = args[i+1];
      i++;
      break;
    case '--path':
      projectPath = args[i+1];
      i++;
      break;
    default:
      throw new Error(`未知参数: ${args[i]}`);
  }
}

if (!projectName) {
  throw new Error('项目名称必填。使用 --project 参数指定');
}

// 创建项目目录结构
console.log(`创建项目结构，项目名称: ${projectName} 在 ${projectPath} ...`);
const fullPath = path.join(projectPath, projectName);

if (!fs.existsSync(fullPath)) {
  fs.mkdirSync(fullPath, { recursive: true });
}

// 复制模板结构
const templatesPath = path.join(__dirname, '../../templates');
const sources = [
  path.join(templatesPath, 'default_state.json'),
  path.join(templatesPath, 'tasks/collector_task.md'),
  path.join(templatesPath, 'tasks/analyzer_task.md'),
  path.join(templatesPath, 'tasks/writer_task.md'),
  path.join(templatesPath, 'project_structure.md')
];

let success = true;
for (const source of sources) {
  try {
    const srcStat = fs.statSync(source);
    const relPath = path.relative(templatesPath, source);
    const destPath = path.join(fullPath, relPath);
    fs.mkdirSync(path.dirname(destPath), { recursive: true });
    fs.copyFileSync(source, destPath);
    console.log(`  ➤ ${relPath} ✓`);
  } catch (e) {
    console.log(`  ❌ ${source} 复制失败: ${e.message}`);
    success = false;
  }
}

// 如果tasks目录不存在，创建
if (!fs.existsSync(path.join(fullPath, 'tasks'))) {
  fs.mkdirSync(path.join(fullPath, 'tasks'));
}

// 复制任务模板（如果存在）
const tasksTemplatePath = path.join(__dirname, '../../templates/tasks');
if (fs.existsSync(tasksTemplatePath) && fs.readdirSync(tasksTemplatePath).length > 0) {
  const tasksFiles = fs.readdirSync(tasksTemplatePath);
  for (const file of tasksFiles) {
    const src = path.join(tasksTemplatePath, file);
    const dest = path.join(fullPath, 'tasks', file);
    fs.copyFileSync(src, dest);
    console.log(`  ➤ tasks/${file} ✓`);
  }
}

// 创建 .state.json（使用模板）
const stateTemplate = path.join(__dirname, '../../templates/default_state.json');
const stateDest = path.join(fullPath, '.state.json');
fs.copyFileSync(stateTemplate, stateDest);

// 最后检查是否成功
if (success) {
  console.log(`\n✅ 项目已成功创建！`);
  console.log(`   项目路径: ${fullPath}`);
  console.log(`   初始状态文件: ${stateDest}`);
  console.log(`\n可以运行以下命令继续配置和使用：`);
  console.log('   hermes research status --project', projectName);
  console.log('   hermes research trigger collector');
} else {
  throw new Error('创建项目过程中出现错误');
}