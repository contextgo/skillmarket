#!/usr/bin/env node
/**
 * hermes research export-cron
 * 导出 cron 作业配置为 Shell 脚本
 */

const path = require('path');
const fs = require('fs');

const projectRoot = process.cwd();
const statePath = path.join(projectRoot, '.state.json');

if (!fs.existsSync(statePath)) {
  throw new Error('未找到 .state.json，请确认在项目根目录运行');
}

const state = JSON.parse(fs.readFileSync(statePath, 'utf8'));
const jobs = state.cron_jobs;

// 获取完整的 cron 作业信息（需要查询 openclaw cron list）
const { execSync } = require('child_process');
let cronList;
try {
  const output = execSync('openclaw cron list --json', { encoding: 'utf8' });
  cronList = JSON.parse(output);
} catch (e) {
  throw new Error('无法获取 cron 作业列表，请确保 openclaw 已安装并运行');
}

// 生成 shell 脚本内容
const scriptLines = [
  '#!/bin/bash',
  `# Research Project: ${state.project}`,
  `# 导出时间: ${new Date().toISOString()}`,
  '',
  '# 使用以下命令添加作业到 OpenClaw Cron:',
  '# openclaw cron add ...'
];

for (const [stage, jobId] of Object.entries(jobs)) {
  const job = cronList.find(j => j.id === jobId);
  if (job) {
    scriptLines.push('');
    scriptLines.push(`# ${stage} (${job.name})`);
    scriptLines.push(`# Cron: ${job.schedule.expr}`);
    scriptLines.push(`# Agent: ${job.agentId}`);
    scriptLines.push(`# 手动触发: openclaw cron run --expect-final ${jobId}`);
  }
}

console.log(scriptLines.join('\n'));