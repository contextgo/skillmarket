#!/usr/bin/env node
/**
 * hermes research status
 * 查看项目状态
 */

const path = require('path');
const fs = require('fs');

const args = process.argv.slice(2);
let verbose = false;

if (args.includes('--help') || args.includes('-h')) {
  console.log(`Usage: hermes research status [options]

Options:
  --verbose        查看详细状态（包括子agent状态、cron信息）
  --project <path> 指定项目目录（默认当前目录）

Examples:
  hermes research status
  hermes research status --verbose
`);
  process.exit(0);
}

for (let i = 0; i < args.length; i++) {
  switch(args[i]) {
    case '--verbose':
      verbose = true;
      break;
    default:
      throw new Error(`未知参数: ${args[i]}`);
  }
}

const projectRoot = process.cwd();
const statePath = path.join(projectRoot, '.state.json');
if (!fs.existsSync(statePath)) {
  throw new Error(`未找到 .state.json，请确保在项目根目录运行`);
}

const state = JSON.parse(fs.readFileSync(statePath, 'utf8'));

console.log(`项目: ${state.project}\n`);
console.log(`当前阶段: ${state.phase}`);
console.log(`迭代次数: ${state.iteration}\n`);

console.log('子agent状态:');
Object.entries(state.subagent_states || {}).forEach(([k, v]) => {
  console.log(`  ${k}: ${v}`);
});

if (state.documents) {
  console.log('\n文档信息:');
  console.log(`  飞书文档ID: ${state.documents.feishu_id || '未创建'}`);
  console.log(`  版本: v${state.documents.version}`);
  if (state.documents.feishu_url) {
    console.log(`  链接: ${state.documents.feishu_url}`);
  }
}

if (state.pending_questions && state.pending_questions.length > 0) {
  console.log(`\n待研究问题 (${state.pending_questions.length}):`);
  state.pending_questions.forEach((q, i) => console.log(`  ${i+1}. ${q}`));
}

if (verbose) {
  console.log('\n完整状态 JSON:');
  console.log(JSON.stringify(state, null, 2));
}