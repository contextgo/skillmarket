#!/usr/bin/env node
/**
 * hermes research setup-cron
 * 自动将任务添加到 openclaw cron
 */

const path = require('path');
const fs = require('fs');
const { execSync } = require('child_process');

// 解析命令行参数
const args = process.argv.slice(2);
let options = {
  collector: null,
  analyzer: null,
  writer: null,
  agent: 'hermes',
  channel: 'feishu',
  to: null,
  model: 'minimax/MiniMax-M2.7',
  timeout: '600'
};

function showHelp() {
  console.log(`Usage: hermes research setup-cron [options]

Options:
  --collector <cron>    Collector cron expression (default: 0 22 * * 2)
  --analyzer <cron>     Analyzer cron expression (default: */60 * * * *)
  --writer <cron>       Writer cron expression (default: */30 * * * *)
  --agent <agent>       Agent to use (default: hermes)
  --channel <channel>   Notification channel (default: feishu)
  --to <target>         Notification recipient (required)
  --model <model>       Model override (default: minimax/MiniMax-M2.7)
  --timeout <seconds>   Job timeout (default: 600)

Examples:
  hermes research setup-cron --to "user:ou_xxxxx"
  hermes research setup-cron --collector "0 22 * * 2" --analyzer "*/30 * * * *" --to "user:ou_xxxxx"
`);
  process.exit(0);
}

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  switch (arg) {
    case '--collector': options.collector = args[++i]; break;
    case '--analyzer': options.analyzer = args[++i]; break;
    case '--writer': options.writer = args[++i]; break;
    case '--agent': options.agent = args[++i]; break;
    case '--channel': options.channel = args[++i]; break;
    case '--to': options.to = args[++i]; break;
    case '--model': options.model = args[++i]; break;
    case '--timeout': options.timeout = args[++i]; break;
    case '--help': case '-h': showHelp();
    default: throw new Error(`Unknown option: ${arg}`);
  }
}

if (!options.to) {
  throw new Error('必须指定 --to 参数，例如: --to "user:ou_xxxxx"');
}

// 设置默认值
options.collector = options.collector || '0 22 * * 2';
options.analyzer = options.analyzer || '*/60 * * * *';
options.writer = options.writer || '*/30 * * * *';

// 读取项目 state 和 tasks
const projectRoot = process.cwd();
const statePath = path.join(projectRoot, '.state.json');
if (!fs.existsSync(statePath)) {
  throw new Error('未找到 .state.json，请确认在项目根目录运行');
}
const state = JSON.parse(fs.readFileSync(statePath, 'utf8'));
const tasksDir = path.join(projectRoot, 'tasks');

const getTaskFile = (name) => {
  const file = path.join(tasksDir, `${name}_task.md`);
  return fs.existsSync(file) ? file : null;
};

// 定义要添加的作业
const jobs = [
  {
    name: state.cron_jobs?.collector || 'research_collector',
    cron: options.collector,
    taskFile: getTaskFile('collector') || path.join(tasksDir, 'collector_task.md'),
    message: `[${state.project}] 执行资料采集。请严格按任务文件执行。`
  },
  {
    name: state.cron_jobs?.analyzer || 'research_analyzer',
    cron: options.analyzer,
    taskFile: getTaskFile('analyzer') || path.join(tasksDir, 'analyzer_task.md'),
    message: `[${state.project}] 执行分析生成。请严格按任务文件执行。`
  },
  {
    name: state.cron_jobs?.writer || 'research_writer',
    cron: options.writer,
    taskFile: getTaskFile('writer') || path.join(tasksDir, 'writer_task.md'),
    message: `[${state.project}] 执行文档撰写。请严格按任务文件执行。`
  }
];

// 添加作业函数
function addJob(job) {
  if (!fs.existsSync(job.taskFile)) {
    console.warn(`⚠  任务文件不存在: ${job.taskFile}，跳过`);
    return null;
  }

  const taskContent = fs.readFileSync(job.taskFile, 'utf8');
  const fullMessage = `${job.message}\n\n${taskContent}`;

  try {
    const cmd = `openclaw cron add --name "${job.name}" --agent ${options.agent} --cron "${job.cron}" --message "${fullMessage.replace(/"/g, '\\"')}" --model ${options.model} --timeout ${options.timeout} --channel ${options.channel} --to "${options.to}" --best-effort-deliver`;
    const output = execSync(cmd, { encoding: 'utf8' });
    const result = JSON.parse(output);
    console.log(`✅ ${job.name} 已添加 (ID: ${result.id})`);
    return result.id;
  } catch (e) {
    console.error(`❌ 添加失败: ${job.name}`, e.message);
    return null;
  }
}

console.log(`正在配置项目: ${state.project}\n`);
const ids = {};
for (const job of jobs) {
  const id = addJob(job);
  if (id) ids[job.name] = id;
}

// 更新 state.json 中的 cron_job IDs
if (Object.keys(ids).length > 0) {
  state.cron_jobs = ids;
  fs.writeFileSync(statePath, JSON.stringify(state, null, 2));
  console.log('\n✅ cron 作业已配置完成并写入 .state.json');
  console.log('\n手动触发测试:');
  console.log('  hermes research trigger collector');
  console.log('Status: openclaw cron list');
}