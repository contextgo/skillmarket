# 发布指南

本 Skill 已完成开发，可以发布到 [ClawHub](https://clawhub.ai)。

## 前置条件

- 已安装 Node.js 和 `clawhub` CLI
- 拥有 ClawHub 账号并登录

## 安装 ClawHub CLI

```bash
npm install -g @openclaw/clawhub
```

## 一键发布

```bash
cd ~/.openclaw/skills/research-project-manager
./scripts/publish.sh
```

脚本会：
1. 检查登录状态，必要时打开浏览器授权
2. 确认发布信息
3. 上传所有文件到 ClawHub Registry

发布后，Skill 将获得可用 slug: `research-project-manager`

## 手动发布

也可以直接调用：

```bash
cd ~/.openclaw/skills/research-project-manager

clawhub publish . \
  --name "Research Project Manager" \
  --version "1.0.0" \
  --tags "research,automation,project-management" \
  --changelog "Initial release"
```

## 发布后验证

```bash
clawhub inspect research-project-manager
```

## 本地测试

在发布前，可以在本地测试 Skill 功能：

```bash
cd ~/.openclaw/skills/research-project-manager
# 链接到 skills 目录（如果尚未symlink）
# 通常在 ~/.openclaw/skills/ 下已是开发版

# 创建测试项目
mkdir -p ~/test_project && cd ~/test_project
hermes research init --project my_test
hermes research status --verbose
```

## 更新发布

修改代码后，更新 `package.json` 中的 `version`，然后重新运行发布脚本。

## Support

- Skill 仓库: https://clawhub.ai/skills/research-project-manager
- 问题反馈: 在 ClawHub 上提交 issue
