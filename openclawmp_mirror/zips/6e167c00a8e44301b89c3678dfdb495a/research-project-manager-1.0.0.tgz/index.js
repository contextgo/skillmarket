// Research Project Manager Skill entry point
// This file registers the skill with OpenClaw and provides command routing

const { join } = require('path');

module.exports = function register(skillRegistry) {
  // Register slash commands
  skillRegistry.registerCommands([
    {
      name: 'research init',
      description: 'Initialize a new research project',
      category: 'Configuration',
      handler: require('./commands/init')
    },
    {
      name: 'research status',
      description: 'Show project status',
      category: 'Info',
      handler: require('./commands/status')
    },
    {
      name: 'research trigger',
      description: 'Manually trigger a stage',
      category: 'Tools & Skills',
      args_hint: '<stage>',
      handler: require('./commands/trigger')
    },
    {
      name: 'research export-cron',
      description: 'Export cron job definitions',
      category: 'Info',
      handler: require('./commands/export-cron')
    },
    {
      name: 'research setup-cron',
      description: 'Setup cron jobs automatically',
      category: 'Configuration',
      handler: require('./commands/setup-cron')
    }
  ]);

  // Register skill metadata
  skillRegistry.setMetadata({
    name: 'research-project-manager',
    version: '1.0.0',
    description: 'Multi-stage research workflow automation with state machine',
    author: 'Hermes Agent Team',
    license: 'MIT',
    configSchema: {
      type: 'object',
      properties: {
        defaultCronExpr: {
          type: 'object',
          properties: {
            collector: { type: 'string', default: '0 22 * * 2' },
            analyzer: { type: 'string', default: '*/60 * * * *' },
            writer: { type: 'string', default: '*/30 * * * *' }
          }
        },
        defaultAgent: { type: 'string', default: 'hermes' },
        defaultChannel: { type: 'string', default: 'feishu' }
      }
    }
  });

  console.log('Research Project Manager skill loaded');
};
