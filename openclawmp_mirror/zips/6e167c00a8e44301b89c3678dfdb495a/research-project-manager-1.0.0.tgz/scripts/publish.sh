#!/bin/bash
# 发布 Research Project Manager 到 ClawHub
# 首次运行会要求登录（浏览器授权）

set -e

cd "$(dirname "$0")/.."

echo "=== Research Project Manager Skill 发布脚本 ==="
echo ""

# 检查是否已登录
if ! clawhub whoami > /dev/null 2>&1; then
  echo "尚未登录 ClawHub。正在打开浏览器进行授权..."
  clawhub login
fi

echo "当前登录用户:"
clawhub whoami

echo ""
echo "准备发布..."
echo "名称: Research Project Manager"
echo "版本: 1.0.0"
echo "标签: research,automation,project-management"
echo ""

read -p "按 Enter 开始发布，或 Ctrl+C 取消..."

clawhub publish . \
  --name "Research Project Manager" \
  --version "1.0.0" \
  --tags "research,automation,project-management" \
  --changelog "Initial release based on Tang Huren research project. Features state-machine driven multi-stage research workflow."

echo ""
echo "✅ 发布完成！"
echo ""
echo "其他人可以通过以下命令安装："
echo "  openclaw skills install research-project-manager"
echo "或在 ClawHub 搜索: research-project-manager"
echo ""