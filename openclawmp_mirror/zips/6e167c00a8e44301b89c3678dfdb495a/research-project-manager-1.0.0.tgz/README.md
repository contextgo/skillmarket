# Research Project Manager Skill

管理多阶段研究项目的自动化协作系统。

## 快速开始

```bash
# 1. 安装技能
openclaw skills install research-project-manager

# 2. 初始化新项目
cd ~/research
hermes research init --project my_study

# 3. 查看状态
cd my_study
hermes research status

# 4. 手动触发阶段（可选）
hermes research trigger collector
```

## 核心功能

- 自动化的资料采集 → 分析 → 报告流水线
- 状态机驱动，确保各阶段有序衔接
- 与飞书文档集成，自动推送给审阅人
- 支持 cron 定时调度
- 可插拔的任务定义（Markdown模板）

## 详细文档

详见 [SKILL.md](SKILL.md)
