# 项目目录结构

```
{project_root}/
├── raw/                        # 原始数据（自动生成）
│   ├── 2026-04-14_ctext_旧唐书_关键词.md
│   ├── 2026-04-14_cnki_论文摘要.md
│   └── ...
├── knowledge_base/             # 知识库（人工维护分类）
│   ├── 职业.md
│   ├── 宗教.md
│   ├── 居住区.md
│   └── 性别角色.md
├── drafts/                     # 草稿（自动生成）
│   └── 项目标题初稿.md
├── reports/                    # 最终报告（自动生成）
│   └── 项目标题_v1_2026-04-14.md
├── tasks/                      # 任务定义（由skill提供模板）
│   ├── collector_task.md
│   ├── analyzer_task.md
│   ├── writer_task.md
│   └── reviewer_task.md (optional)
├── .state.json                 # 状态文件（由skill自动管理）
└── README.md                   # 项目说明（可选）
```

## 目录说明

- **raw/**: 只追加不删除，保留所有原始材料供追溯
- **knowledge_base/**: 结构化知识，可手动补充
- **drafts/**: 每次analyzer输出的中间草稿
- **reports/**: writer输出的最终版本，按版本号和时间命名
- **tasks/**: 自定义任务定义，可根据项目需求修改
- **.state.json**: 驱动整个流程的状态机，不要手动修改（除非调试）

## 命名约定

- 文件名: `YYYY-MM-DD_<source>_<描述>.md`
- 版本: v1, v2... 或 日期戳
- 状态字段: 小写 snake_case

## 排除文件

`raw/` 和 `drafts/` 中可以添加 `.gitignore` 规则（如果需要版本控制）:
```
*.tmp
.DS_Store
```
