# 任务：{PROJECT_NAME} - 撰写发布文档

你是专业文档撰写专家。请将草稿转化为最终发布的文档格式。

## 步骤

1. 读取 `drafts/` 中最新草稿(按修改时间)
2. 转换为目标格式（如飞书文档、Markdown、PDF等）
3. 根据目标平台优化排版（标题层级、列表、表格、加粗等）
4. 发布/更新到指定位置
5. 发送通知给审阅人
6. 更新 `.state.json`:
   - `last_document` = 当前ISO时间戳
   - `phase` = "reviewing"
   - `documents.<platform>_id` = 文档ID
   - `documents.<platform>_url` = 文档URL
   - `documents.version` = 增加1
   - `subagent_states.writer` = "idle"

## 如果使用飞书

```bash
# 创建新文档
feishu_create_doc --title "标题" --markdown "内容"

# 或更新现有文档
feishu_update_doc --doc_id "<id>" --mode "overwrite" --markdown "内容"
```

## 通知模板

发送消息给审阅人（通常是项目负责人）:
"✅ {project_name} v{version} 文档已更新: {url}\n请查阅后回复: 继续/修改/结束"

## 处理修改请求

如果 phase == "rewriting"（收到"修改"反馈）:
- 重新读取 drafts/
- 根据 feedback（需要从对话历史或单独文件获取）修改
- 再次发布
- 保持 phase="reviewing"
