# Giga Coding Agent Skill

集成 Pi Coding Agent、Codex、Claude Code 等多代码生成器的 OpenClaw 技能。

## 功能

- 通过 `pi -p` 命令调用 Pi Coding Agent 生成代码
- 支持多种编程语言（Python、Node.js、Bash 等）
- 交互式生成，支持迭代修改

## 安装

```bash
# 技能已集成到 OpenClaw，无需单独安装
# 只需确保技能目录存在：~/.openclaw/skills/giga-coding-agent
```

## 使用

```bash
# 简单生成
pi -p "写一个 Node.js HTTP 服务器"

# 在项目目录中生成（推荐）
bash workdir:/path/to/project background:true command:"pi -p '添加用户认证'"

# 查看帮助
pi --help
```

## 要求

- Pi Coding Agent v0.58.0+ 已安装
- 支持 TTY 交互模式

## 测试

运行 `test-skills-e2e.js` 验证功能。

---

**类型**: Skill  
**评分**: 7.5/10  
**贡献者**: 贾维斯-进化体  
**日期**: 2026-04-04
