---
name: makecontents-v2
displayName: MakeContents AI 资讯 Agent 技能 v2
description: 基于 RSS 的 AI 资讯聚合、内容创作与 Agent 自动化工具。支持资讯拉取、AI 翻译、三类推送（AINews/AITopics/AITools）、小红书风格图文创作、飞书多维表归档，实现 Agent 全自动运行。
version: 2.0.0
type: skill
tags: [rss, ai-news, content-creation, agent-automation, xiaohongshu, feishu]
---

# MakeContents AI 资讯 Agent 技能 v2

> 订阅 RSS/RSSHub 信源 → 自动拉取资讯 → AI 翻译/筛选 → 一键推送微信/同步飞书 → 图文内容创作与渲染 → Agent 全自动运行

## 功能概览

| 模块 | 功能 |
|---|---|
| **资讯聚合** | 支持 RSSHub 路由和标准 RSS，按信源分组展示，正向/黑名单关键词双重过滤 |
| **AI 翻译** | 对指定信源自动调用大模型翻译为中文 |
| **三类推送** | AINews（速报）/ AITopics（话题引导）/ AITools（工具推荐），并行推送微信、保存到指定飞书知识库 |
| **内容创作** | 图片上传 + 大模型生成封面文案，渲染 1080×1440 封面图与详情图，小红书风格预览 |
| **资源库** | 原始资讯归档、已保存资讯列表、已保存内容宫格展示 |
| **飞书多维表** | 创作内容一键存入多维表，供人工审核后发布 |
| **Agent 接口** | 暴露完整 API，配合 Agent Skills 实现全自动资讯筛选、推送、创作、归档、通知 |

---

## 前置要求

### 服务部署

**方式一：本地开发**
```bash
git clone https://github.com/comeonzhj/AutoContents.git
cd AutoContents
./start.sh
```
访问：前端 `http://localhost:3711`，API `http://localhost:3710/api`

**方式二：Docker 部署**
```bash
git clone https://github.com/comeonzhj/AutoContents.git
cd AutoContents
docker compose -p makecontent up -d --build
```
访问：`http://服务器IP:3710`

### 系统配置

首次运行后进入「系统配置」页面完成以下配置：

#### 大模型配置
翻译、编辑（推送）、创作三个场景可使用不同模型，兼容所有 OpenAI 接口格式（DeepSeek、通义、Kimi 等）。

| 字段 | 说明 |
|---|---|
| 模型名称 | 如 `deepseek-chat`、`gpt-4o` |
| Base URL | 如 `https://api.deepseek.com`（末尾无需加 `/v1`） |
| API Key | 对应平台的密钥 |
| 系统提示词 | AITopics 和 AITools 可单独配置推送风格 |

#### 飞书配置
在[飞书开放平台](https://open.feishu.cn/)创建自建应用，开通文档/知识库/多维表读写权限。

| 字段 | 说明 |
|---|---|
| App ID / App Secret | 应用凭证 |
| Space ID | 知识库 ID |
| 父节点 Token | AINews 文档存放的父节点 |
| 多维表 URL | 直接粘贴浏览器地址栏 URL，自动解析参数 |
| 机器人 Webhook | Agent 完成创作后的通知地址 |

**多维表格字段要求**（务必严格按此格式创建）：
```json
{
  "资讯": "文本",
  "url": "文本",
  "标题": "文本",
  "正文": "文本",
  "Tags": "文本",
  "封面": [附件],
  "详情图": [附件],
  "创作时间": "文本"
}
```

#### 小红书发布配置
- 在「小红书发布」Tab 中填写有效的 Cookie（含 `a1` 和 `web_session` 字段）
- 开启「发布开关」（`xhs_enabled = 1`）
- **注意**：Agent 发布时强制 `is_private: true`，需人类在 App 审核后设为公开

#### 关键词过滤
- **正向关键词**：只有命中列表中任意关键词的资讯才显示（留空则全部显示）
- **屏蔽关键词**：包含关键词的资讯直接过滤，不进入数据库

---

## Agent 执行流程

### 流程一：学习选择规律

先读取 `references/agent-rules.md`，如包含内容筛选规律则直接使用；否则：

1. 调用 `GET /api/news/agent-summary` 获取学习数据
2. 分析数据：
   - `saved_news`：用户推送过的资讯（含 push_type）
   - `all_news_in_period`：对应时段所有资讯
   - 对比两个列表，提炼被选中资讯的共同特征
3. 将分析的规律追加到 `references/agent-rules.md`

**分析角度**：
- 被选中资讯的来源分布（哪些信源更受偏好）
- 被选中资讯的主题特征（关键词、话题类型）
- 推送类型分布（用户倾向于哪类推送）
- 内容创作选题特征（哪类话题被创作）

### 流程二：资讯推送

1. 调用 `POST /api/news/fetch` 拉取最新资讯
2. 调用 `GET /api/news/grouped?agent=1` 获取资讯列表（已推送条目自动排除）
3. 使用 `references/agent-rules.md` 中的筛选规律
4. 根据规律从列表中筛选 0-5 条有价值的资讯（无有价值资讯可直接结束）
5. 对每条资讯：
   - 判断推送类型（ainews / aitopics / aitools）
   - 生成 `news_title`（≤30字）和 `news_summary`（100-200字）
   - 调用对应推送接口：
     ```
     POST /api/news/{id}/ainews
     POST /api/news/{id}/aitopics
     POST /api/news/{id}/aitools
     ```
6. 完成后调用 `POST /api/content/notify-bot` 通知人类

**推送类型判断原则**：
- `ainews`：客观事实类资讯，速报风格
- `aitopics`：有争议或引人思考的话题，末尾加引导性问题
- `aitools`：新工具/新产品发布，突出功能和使用场景

### 流程三：内容创作

1. 从资讯列表选定 0-3 条适合内容创作的资讯（有深度或有趣的话题）
2. 对每条资讯，构造参数并调用 `POST /api/content/agent-render`：
   - `news_id`：资讯 ID
   - `source_url`：原始链接（description中的链接，非资讯链接；服务会自动截图）
   - `cover_word`：1-2个英文单词，全大写
   - `cover_title`：≤15字，有冲击力的中文标题
   - `cover_description`：≤20字，补充说明
   - `cover_emoji`：1个相关 Emoji
   - `content_type`：`news`/`tools`/`topics`/`default`（决定配色）
   - `title`：≤20字，小红书风格标题
   - `content`：正文，500-800字，小红书风格
   - `tags`：3-5个标签，逗号分隔
3. 获取渲染结果的 `saved_content_id`、`cover_url`、`detail_urls`
4. 调用 `POST /api/content/save-to-bitable` 存入飞书多维表
5. **（可选）发布到小红书**：若开关已开启，调用 `POST /api/content/publish-xhs`：
   ```json
   {
     "title": "{title（≤20字）}",
     "desc": "{content}",
     "cover_url": "{cover_url}",
     "detail_urls": ["{detail_urls[0]}", "..."],
     "is_private": true
   }
   ```
   - **Agent 必须传 `"is_private": true`**，笔记以「仅自己可见」发布
   - 若返回"小红书发布功能未开启"，静默跳过
6. 调用 `POST /api/content/notify-bot` 发送通知

---

## API 参考

### 基础信息
- **Base URL**：`http://<服务器IP>:3710/api`
- 所有请求/响应均为 JSON（下载接口除外）
- 成功响应：`{ "success": true, "data": ... }`
- 失败响应：`{ "success": false, "error": "错误信息" }`

### 核心接口

#### 资讯接口

| 接口 | 方法 | 说明 |
|---|---|---|
| `/news/fetch` | POST | 拉取最新资讯 |
| `/news/grouped?agent=1` | GET | 获取资讯列表（Agent 模式自动过滤已推送） |
| `/news/agent-summary` | GET | 获取 Agent 学习摘要 |
| `/news/{id}/ainews` | POST | AINews 推送 |
| `/news/{id}/aitopics` | POST | AITopics 推送 |
| `/news/{id}/aitools` | POST | AITools 推送 |
| `/news/{id}/save` | POST | 保存资讯 |
| `/news/{id}/hide` | POST | 隐藏资讯 |
| `/news/saved` | GET | 获取已保存资讯 |

#### 内容创作接口

| 接口 | 方法 | 说明 |
|---|---|---|
| `/content/agent-render` | POST | Agent 一步完成创作渲染 |
| `/content/save-to-bitable` | POST | 保存内容到飞书多维表 |
| `/content/publish-xhs` | POST | 发布到小红书（需开启开关） |
| `/content/notify-bot` | POST | 飞书机器人通知 |
| `/content/saved` | GET | 获取已保存内容列表 |

**颜色自动选择规则**：
| content_type | 颜色 | 场景 |
|---|---|---|
| `default` | `#06FFA5` 翠绿 | 通用 |
| `news` | `#FF6B35` 橙红 | 新闻资讯 |
| `tools` | `#5478EB` 蓝紫 | 工具推荐 |
| `topics` | `#FFD700` 金黄 | 话题讨论 |

详细 API 文档见 `references/api.md`

---

## 注意事项

- 截图详情图可能因目标网站防爬而失败，失败时静默跳过，只生成封面
- 推送接口会自动标记资讯为已保存，无需手动调用 save 接口
- Agent 生成内容时，`news_title` 和 `news_summary` 直接作为推送内容，需保证质量
- 每次执行完整流程后，建议执行一次学习流程以更新规律记忆
- **小红书发布**：发布开关默认关闭，由人类决定是否授权。Agent 应尊重此开关，收到"未开启"错误时静默跳过

---

## 相关链接

- GitHub: https://github.com/comeonzhj/AutoContents
- 原版技能: makecontents

---

## License

MIT
