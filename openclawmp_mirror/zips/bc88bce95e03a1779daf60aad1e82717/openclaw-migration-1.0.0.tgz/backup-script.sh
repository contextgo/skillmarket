#!/bin/bash
# OpenClaw 自动备份脚本
# 用法: ./backup-script.sh [保留天数]

set -e

# 使用官方环境变量
OPENCLAW_DIR="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
BACKUP_DIR="${BACKUP_DIR:-$HOME/backup}"
RETENTION_DAYS="${1:-7}"
DATE=$(date +%Y%m%d)
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# 创建备份目录
mkdir -p "$BACKUP_DIR"

echo "🦐 OpenClaw 备份开始: $TIMESTAMP"
echo "OpenClaw 目录: $OPENCLAW_DIR"
echo "备份目录: $BACKUP_DIR"
echo "保留天数: $RETENTION_DAYS"

# 切换到 OpenClaw 目录
cd "$OPENCLAW_DIR"

# 打包（排除 node_modules 等大体积目录）
BACKUP_FILE="$BACKUP_DIR/openclaw-backup-$DATE.tar.gz"
tar -czvf "$BACKUP_FILE" \
  --exclude='*.jsonl' \
  --exclude='*.log' \
  --exclude='*.sock' \
  --exclude='**/node_modules' \
  --exclude='canvas' \
  --exclude='completions' \
  --exclude='logs' \
  --exclude='agents/*/sessions' \
  .

# 检查备份文件
if [ -f "$BACKUP_FILE" ]; then
  SIZE=$(ls -lh "$BACKUP_FILE" | awk '{print $5}')
  echo "✅ 备份完成: $BACKUP_FILE ($SIZE)"
else
  echo "❌ 备份失败"
  exit 1
fi

# 清理旧备份
echo "清理 $RETENTION_DAYS 天前的旧备份..."
DELETED=$(find "$BACKUP_DIR" -name "openclaw-backup-*.tar.gz" -mtime +$RETENTION_DAYS -delete -print | wc -l)
echo "已删除 $DELETED 个旧备份文件"

# 显示当前备份列表
echo ""
echo "当前备份列表:"
ls -lht "$BACKUP_DIR"/openclaw-backup-*.tar.gz 2>/dev/null | head -5

echo ""
echo "🎉 备份完成！"
