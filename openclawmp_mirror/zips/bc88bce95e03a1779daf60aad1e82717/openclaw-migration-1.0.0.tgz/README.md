# 给你的 OpenClaw 搬家：迁移到新云服务器完整指南

让 Agent 掌握 OpenClaw 迁移的完整流程，实现平滑搬迁、数据不丢失、配置自动恢复。

> 本指南基于 [OpenClaw 官方文档](https://docs.openclaw.ai) 编写，引用来源：
> - [Agent Workspace](https://docs.openclaw.ai/concepts/agent-workspace) - 工作区结构和备份策略
> - [FAQ - Migrating](https://docs.openclaw.ai/help/faq#can-i-migrate-my-setup-to-a-new-machine-mac-mini-without-redoing-onboarding) - 迁移步骤

---

## 迁移流程概览

```
┌─────────────┐    ┌─────────────┐    ┌─────────────┐    ┌─────────────┐
│  旧服务器    │ →  │  本地/中转   │ →  │  新服务器    │ →  │  验证完成    │
│  打包备份    │    │  下载存储    │    │  上传恢复    │    │  功能正常    │
└─────────────┘    └─────────────┘    └─────────────┘    └─────────────┘
```

---

## 一、打包备份（旧服务器）

### 使用官方环境变量

OpenClaw 使用 `$OPENCLAW_STATE_DIR` 环境变量指定主目录，默认为 `~/.openclaw`。备份脚本应直接使用此环境变量：

```bash
# 直接使用官方环境变量
OPENCLAW_DIR="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
```

### 需要备份的目录

根据 [OpenClaw 官方文档](https://docs.openclaw.ai/concepts/agent-workspace#what-is-not-in-the-workspace)，以下内容需要备份：

| 目录/文件 | 说明 |
|-----------|------|
| **workspace/** | 记忆、身份、用户信息、自定义技能 |
| **openclaw.json** | 主配置文件（模型、渠道、网关） |
| **identity/** | 设备身份和密钥（保持设备 ID 不变） |
| **credentials/** | OAuth tokens、API keys |
| **skills/** | 全局技能包 |
| **experiences/** | 经验包 |
| **devices/** | 已配对设备信息 |
| **cron/** | 定时任务配置 |
| **extensions/** | 自定义扩展 |
| **.env** | 环境变量（如有） |

### 排除 node_modules 减小体积

OpenClaw 是 Node.js 项目，`node_modules` 目录体积巨大，必须排除：

```bash
--exclude='**/node_modules'
```

其他可排除项：
- `**/*.jsonl` - Session 历史日志
- `**/*.log` - 日志文件
- `**/*.sock` - Socket 文件
- `canvas/` - Canvas UI 缓存
- `agents/*/sessions/` - Session 存储

### 完整打包命令

```bash
#!/bin/bash
# OpenClaw 备份脚本

# 使用官方环境变量
OPENCLAW_DIR="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
BACKUP_DIR="${BACKUP_DIR:-$HOME/backup}"
DATE=$(date +%Y%m%d)

# 创建备份目录
mkdir -p "$BACKUP_DIR"

echo "🦐 OpenClaw 备份开始"
echo "OpenClaw 目录: $OPENCLAW_DIR"
echo "备份目录: $BACKUP_DIR"

# 切换到 OpenClaw 目录
cd "$OPENCLAW_DIR"

# 打包（排除 node_modules 等大体积目录）
tar -czvf "$BACKUP_DIR/openclaw-backup-$DATE.tar.gz" \
  --exclude='*.jsonl' \
  --exclude='*.log' \
  --exclude='*.sock' \
  --exclude='**/node_modules' \
  --exclude='canvas' \
  --exclude='completions' \
  --exclude='logs' \
  --exclude='agents/*/sessions' \
  .

# 验证备份
if [ -f "$BACKUP_DIR/openclaw-backup-$DATE.tar.gz" ]; then
  SIZE=$(ls -lh "$BACKUP_DIR/openclaw-backup-$DATE.tar.gz" | awk '{print $5}')
  echo "✅ 备份完成: openclaw-backup-$DATE.tar.gz ($SIZE)"
else
  echo "❌ 备份失败"
  exit 1
fi
```

---

## 二、下载备份到本地

从旧服务器下载备份文件到本地电脑或中转位置。

### 方式 A：SCP 下载（有公网 IP）

```bash
scp root@旧服务器IP:~/backup/openclaw-backup-YYYYMMDD.tar.gz ./
```

### 方式 B：SFTP 工具

使用 FileZilla、Cyberduck、Termius 等 SFTP 客户端下载。

### 方式 C：通过 Channel 发送（小文件）

如果备份文件较小（< 50MB），可以通过飞书/Telegram 等渠道直接发送：

```
请将 ~/backup/openclaw-backup.tar.gz 文件发送给我
```

---

## 三、上传到新服务器

### 方式 A：SCP 上传

```bash
scp ./openclaw-backup.tar.gz root@新服务器IP:~/.tmp/openclaw-backup/
```

### 方式 B：通过 Channel 接收

用户在飞书/Telegram 等渠道发送备份文件，Agent 接收后保存到 `~/.tmp/openclaw-backup/`。

---

## 四、在新服务器恢复

**根据新服务器的状态，选择不同的恢复策略：**

### 场景 A：全新的服务器（未启动 OpenClaw）

**直接覆盖**到 OpenClaw 项目目录：

```bash
#!/bin/bash
# 全新服务器恢复脚本

OPENCLAW_DIR="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
BACKUP_FILE="$HOME/.tmp/openclaw-backup/openclaw-backup.tar.gz"

echo "🦐 全新服务器恢复"

# 确保 OpenClaw 目录存在
mkdir -p "$OPENCLAW_DIR"

# 直接解压覆盖
cd "$OPENCLAW_DIR"
tar -xzvf "$BACKUP_FILE"

echo "✅ 恢复完成"
echo ""
echo "下一步："
echo "  1. 运行: openclaw doctor --fix"
echo "  2. 重启: openclaw gateway restart"
```

### 场景 B：已启动的 OpenClaw 服务器

**智能合并**，保护现有配置：

**给 Agent 的指令：**

```
在你的服务器有个之前 OpenClaw 的文件备份。现在需要你将这个备份文件解压，并且将备份文件（需要有选择性的，不能一股脑覆盖）中的文件合并到当前的 OpenClaw 项目的文件中，如果当前项目没有的则添加，如果当前项目中有的则比较之后追加。

特别注意：一些模型的配置和 channel（例如飞书）的 appId、key 之类的信息要慎重，当前项目已经有的就用当前项目的。
```

**智能合并脚本：**

```bash
#!/bin/bash
# 智能合并恢复脚本（已启动的 OpenClaw）

OPENCLAW_DIR="${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
RESTORE_DIR="$HOME/.tmp/openclaw-backup"
BACKUP_FILE="$RESTORE_DIR/openclaw-backup.tar.gz"

echo "🦐 智能合并恢复"
echo "OpenClaw 目录: $OPENCLAW_DIR"
echo "备份文件: $BACKUP_FILE"

# 解压到临时目录
mkdir -p "$RESTORE_DIR/extracted"
cd "$RESTORE_DIR/extracted"
tar -xzvf "$BACKUP_FILE"

# ============ 1. 添加缺失的目录 ============
echo ""
echo "📦 步骤 1: 添加缺失的目录"

for dir in skills devices identity experiences credentials cron; do
  if [ -d "$dir" ] && [ ! -d "$OPENCLAW_DIR/$dir" ]; then
    cp -r "$dir" "$OPENCLAW_DIR/"
    echo "  ✅ 已添加: $dir"
  elif [ -d "$dir" ] && [ -d "$OPENCLAW_DIR/$dir" ]; then
    echo "  ⏭️  跳过（已存在）: $dir"
  fi
done

# ============ 2. 恢复 extensions（新增的） ============
echo ""
echo "📦 步骤 2: 恢复 extensions"

if [ -d "extensions" ]; then
  mkdir -p "$OPENCLAW_DIR/extensions"
  for ext in extensions/*/; do
    ext_name=$(basename "$ext")
    if [ ! -d "$OPENCLAW_DIR/extensions/$ext_name" ]; then
      cp -r "$ext" "$OPENCLAW_DIR/extensions/"
      echo "  ✅ 已添加扩展: $ext_name"
    else
      echo "  ⏭️  跳过扩展（已存在）: $ext_name"
    fi
  done
fi

# ============ 3. 恢复 workspace（智能合并） ============
echo ""
echo "📦 步骤 3: 恢复 workspace"

if [ -d "workspace" ]; then
  mkdir -p "$OPENCLAW_DIR/workspace"
  
  # 3.1 skills 目录
  if [ -d "workspace/skills" ]; then
    mkdir -p "$OPENCLAW_DIR/workspace/skills"
    for skill in workspace/skills/*/; do
      skill_name=$(basename "$skill")
      if [ ! -d "$OPENCLAW_DIR/workspace/skills/$skill_name" ]; then
        cp -r "$skill" "$OPENCLAW_DIR/workspace/skills/"
        echo "  ✅ 已添加技能: $skill_name"
      else
        echo "  ⏭️  跳过技能（已存在）: $skill_name"
      fi
    done
  fi
  
  # 3.2 memory 目录
  if [ -d "workspace/memory" ]; then
    if [ ! -d "$OPENCLAW_DIR/workspace/memory" ]; then
      cp -r workspace/memory "$OPENCLAW_DIR/workspace/"
      echo "  ✅ 已恢复: workspace/memory"
    else
      # 合并日志文件
      for file in workspace/memory/*.md; do
        [ -f "$file" ] || continue
        filename=$(basename "$file")
        if [ ! -f "$OPENCLAW_DIR/workspace/memory/$filename" ]; then
          cp "$file" "$OPENCLAW_DIR/workspace/memory/"
          echo "  ✅ 已添加日志: $filename"
        fi
      done
    fi
  fi
  
  # 3.3 关键文件（如果当前不存在则添加）
  for file in MEMORY.md NOW.md IDENTITY.md USER.md AGENTS.md SOUL.md TOOLS.md HEARTBEAT.md; do
    if [ -f "workspace/$file" ] && [ ! -f "$OPENCLAW_DIR/workspace/$file" ]; then
      cp "workspace/$file" "$OPENCLAW_DIR/workspace/"
      echo "  ✅ 已添加: workspace/$file"
    elif [ -f "workspace/$file" ] && [ -f "$OPENCLAW_DIR/workspace/$file" ]; then
      echo "  ⏭️  保留当前: workspace/$file"
    fi
  done
fi

# ============ 4. 恢复 cron 配置 ============
echo ""
echo "📦 步骤 4: 恢复 cron 配置"

if [ -f "cron/jobs.json" ]; then
  if [ ! -f "$OPENCLAW_DIR/cron/jobs.json" ]; then
    mkdir -p "$OPENCLAW_DIR/cron"
    cp cron/jobs.json "$OPENCLAW_DIR/cron/"
    echo "  ✅ 已恢复: cron/jobs.json"
  else
    echo "  ⏭️  保留当前: cron/jobs.json"
  fi
fi

# ============ 5. 处理 openclaw.json（最关键） ============
echo ""
echo "📦 步骤 5: 处理 openclaw.json"
echo ""
echo "⚠️  重要：openclaw.json 需要手动合并！"
echo ""
echo "保留当前项目的："
echo "  - models.providers.* (模型配置和 API Key)"
echo "  - channels.*.appId / appSecret / token (渠道凭证)"
echo "  - gateway.auth.token (网关 Token)"
echo ""
echo "从备份合并的："
echo "  - skills.entries (技能配置)"
echo "  - plugins.entries (插件配置)"

# 清理临时目录
rm -rf "$RESTORE_DIR/extracted"

echo ""
echo "🎉 智能合并完成！"
echo ""
echo "下一步："
echo "  1. 手动合并 openclaw.json 配置"
echo "  2. 运行: openclaw doctor --fix"
echo "  3. 重启: openclaw gateway restart"
```

### 合并 openclaw.json 配置

**⚠️ 最关键的一步：保护敏感配置！**

| 保留当前项目的配置 | 从备份合并的配置 |
|-------------------|-----------------|
| `models.providers.*` | `skills.entries` |
| `channels.*.appId` | `plugins.entries` |
| `channels.*.appSecret` | `cron.enabled` |
| `channels.*.token` | |
| `gateway.auth.token` | |

让 Agent 帮你合并：

```
请帮我合并备份的 openclaw.json 配置到当前项目：
1. 保留当前项目的 models.providers、channels.*.appId/appSecret/token、gateway.auth.token
2. 合并备份中的 skills.entries（当前没有的添加）
3. 添加备份中有但当前没有的 plugins.entries
```

---

## 五、验证迁移结果

```bash
# 运行诊断
openclaw doctor --fix

# 检查状态
openclaw status
openclaw gateway status

# 检查 Cron 任务
openclaw cron list
```

### 完整检查清单

- [ ] `workspace/MEMORY.md` 存在
- [ ] `identity/device.json` 存在且设备 ID 正确
- [ ] `skills/` 或 `workspace/skills/` 目录存在
- [ ] `openclaw.json` 配置正确（敏感信息已保护）
- [ ] `openclaw doctor` 无错误
- [ ] Gateway 正常运行

---

## 六、配置自动备份

```bash
# 每天凌晨 3 点自动备份
openclaw cron add \
  --name "OpenClaw Daily Backup" \
  --cron "0 3 * * *" \
  --session isolated \
  --message "执行 OpenClaw 自动备份：

1. 使用环境变量：OPENCLAW_DIR=\${OPENCLAW_STATE_DIR:-\$HOME/.openclaw}
2. 创建备份目录：mkdir -p ~/backup
3. 打包：cd \$OPENCLAW_DIR && tar -czvf ~/backup/openclaw-backup-\$(date +%Y%m%d).tar.gz --exclude='*.jsonl' --exclude='*.log' --exclude='**/node_modules' .
4. 清理 7 天前的旧备份
5. 汇报备份结果" \
  --announce
```

---

## 附录：快速参考

### 打包命令

```bash
cd "${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
tar -czvf ~/backup/openclaw-backup.tar.gz --exclude='*.jsonl' --exclude='*.log' --exclude='**/node_modules' .
```

### 恢复命令（全新服务器）

```bash
cd "${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
tar -xzvf ~/.tmp/openclaw-backup/openclaw-backup.tar.gz
openclaw doctor --fix
```

### 恢复命令（已启动服务器）

```
在你的服务器有个之前 OpenClaw 的文件备份。现在需要你将这个备份文件解压，并且将备份文件（需要有选择性的，不能一股脑覆盖）中的文件合并到当前的 OpenClaw 项目的文件中。

特别注意：模型配置和 channel（飞书等）的 appId、key 等敏感信息，当前项目已存在的用当前项目的。
```

---

*此经验基于 OpenClaw 官方文档编写，适用于 OpenClaw 2026.3.x 版本。*
