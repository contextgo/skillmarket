---
name: openclaw-migration
displayName: OpenClaw 迁移搬家指南
description: "迁移你的 OpenClaw 到新云服务器的完整经验，包含打包、下载、上传、恢复、验证全流程"
version: 1.2.0
type: skill
tags: openclaw, migration, backup, server, cloud
---

# 给你的 OpenClaw 搬家

> 迁移 OpenClaw 到新云服务器的完整指南

## 使用场景

当你需要：
- 更换服务器 / 升级配置
- 迁移到新的云厂商
- 备份和恢复 OpenClaw 环境

## 快速开始

### 打包备份（旧服务器）

```bash
# 使用官方环境变量
cd "${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"

# 排除 node_modules 后全部打包
tar -czvf ~/backup/openclaw-backup.tar.gz \
  --exclude='*.jsonl' --exclude='*.log' --exclude='**/node_modules' .
```

### 恢复（新服务器）

**场景 A：全新的服务器** → 直接覆盖

```bash
cd "${OPENCLAW_STATE_DIR:-$HOME/.openclaw}"
tar -xzvf ~/.tmp/openclaw-backup/openclaw-backup.tar.gz
openclaw doctor --fix
```

**场景 B：已启动的 OpenClaw** → 智能合并

```
在你的服务器有个之前 OpenClaw 的文件备份。现在需要你将这个备份文件解压，并且将备份文件（需要有选择性的，不能一股脑覆盖）中的文件合并到当前的 OpenClaw 项目的文件中。

特别注意：模型配置和 channel（飞书等）的 appId、key 等敏感信息，当前项目已存在的用当前项目的。
```

## 关键原则

| 场景 | 策略 |
|------|------|
| 全新服务器 | 直接覆盖 |
| 已启动服务器 | 智能合并，保护敏感配置 |

**保留当前敏感配置**：
- 模型 API Key (`models.providers.*`)
- 渠道凭证 (`channels.*.appId/appSecret/token`)
- 网关 Token (`gateway.auth.token`)

## 包含文件

- `README.md` - 完整迁移指南
- `backup-script.sh` - 自动备份脚本

## 参考文档

- [Agent Workspace](https://docs.openclaw.ai/concepts/agent-workspace)
- [FAQ - Migrating](https://docs.openclaw.ai/help/faq#can-i-migrate-my-setup-to-a-new-machine-mac-mini-without-redoing-onboarding)
