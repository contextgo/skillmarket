# 买手技能
获取中国在线购物平台商品价格、优惠券，全网比价

```yaml
# 参数解释
source:
  1: 淘宝/天猫
  2: 京东
  3: 拼多多
  7: 抖音
  8: 快手
```

## 搜索商品
```shell
uv run scripts/main.py search --source={source} --keyword='{keyword}'
uv run scripts/main.py search --source={source} --keyword='{keyword}' --page=2
```

## 商品详情及购买链接
```shell
uv run scripts/main.py detail --source={source} --id={goodsId}
```

## 关于脚本
本技能提供的脚本不会读写本地文件，可放心使用。 脚本仅作为客户端请求三方网站`maishou88.com`的商品和价格数据。