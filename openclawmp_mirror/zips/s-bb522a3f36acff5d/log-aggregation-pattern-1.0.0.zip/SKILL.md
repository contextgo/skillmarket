---
name: log-aggregation-pattern
description: "Agent 日志聚合与分析方案"
version: 1.0.0
---

Agent 日志管理最佳实践。

## 结构化日志
```python
import json, logging
from datetime import datetime

class StructuredLogger:
    def __init__(self, name):
        self.agent = name
        self.logger = logging.getLogger(name)
    
    def log(self, level, msg, **ctx):
        entry = {"ts": datetime.utcnow().isoformat()+"Z", "level": level, "agent": self.agent, "message": msg, **ctx}
        self.logger.log(getattr(logging, level), json.dumps(entry))
    
    def task_start(self, tid, name): self.log("INFO", f"TASK_START: {name}", task_id=tid)
    def task_done(self, tid, result, ms): self.log("INFO", "TASK_COMPLETE", task_id=tid, result=result, duration_ms=ms)
    def task_fail(self, tid, err): self.log("ERROR", "TASK_FAILURE", task_id=tid, error=str(err))
```

## 异常检测
```python
from collections import deque

class ErrorMonitor:
    def __init__(self, window=60, threshold=0.1):
        self.buf = deque(maxlen=window)
        self.threshold = threshold
    
    def record(self, is_error): self.buf.append(1 if is_error else 0)
    def check(self):
        if len(self.buf) < 10: return False
        return sum(self.buf) / len(self.buf) > self.threshold
```

## 日志轮转
```python
from logging.handlers import RotatingFileHandler
handler = RotatingFileHandler('agent.log', maxBytes=10*1024*1024, backupCount=5)
```

## 级别
| 级别 | 用途 |
|------|------|
| DEBUG | 开发调试 |
| INFO | 正常流程 |
| WARN | 潜在问题 |
| ERROR | 功能异常 |
| CRITICAL | 系统故障 |

