#!/bin/bash
# deploy_wewe_rss.sh - 部署 wewe-rss 微信公众号订阅系统
# 参数: [AUTH_CODE] [CRON_EXPRESSION]

set -e

AUTH_CODE="${1:-wewerss2026}"
CRON_EXPRESSION="${2:-0 8,14,20 * * *}"
DATA_DIR="$HOME/wewe-rss/data"
CONTAINER_NAME="wewe-rss"
PORT="4000"

echo "🚀 部署 wewe-rss 公众号订阅系统"
echo ""
echo "配置："
echo "  - 访问密码: $AUTH_CODE"
echo "  - 更新频率: $CRON_EXPRESSION"
echo "  - 数据目录: $DATA_DIR"
echo "  - 端口: $PORT"
echo ""

# 检查 Docker 是否运行
if ! docker info &> /dev/null; then
    echo "❌ Docker 未运行"
    echo "   请先运行 setup_docker.sh 安装并启动 Docker"
    exit 1
fi

# 创建数据目录
mkdir -p "$DATA_DIR"

# 检查是否已有容器运行
if docker ps -a --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
    echo "⚠️ 检测到已存在的 $CONTAINER_NAME 容器"
    
    # 检查配置是否相同
    CURRENT_AUTH=$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' $CONTAINER_NAME 2>/dev/null | grep AUTH_CODE | cut -d= -f2)
    CURRENT_CRON=$(docker inspect --format '{{range .Config.Env}}{{println .}}{{end}}' $CONTAINER_NAME 2>/dev/null | grep CRON_EXPRESSION | cut -d= -f2)
    
    if [ "$CURRENT_AUTH" = "$AUTH_CODE" ] && [ "$CURRENT_CRON" = "$CRON_EXPRESSION" ]; then
        # 配置相同，只需确保容器运行
        if docker ps --format '{{.Names}}' | grep -q "^${CONTAINER_NAME}$"; then
            echo "✅ wewe-rss 已在运行，配置无变化"
        else
            echo "🔄 重启已停止的容器..."
            docker start $CONTAINER_NAME
            echo "✅ wewe-rss 已重启"
        fi
    else
        # 配置不同，需要重建
        echo "🔄 配置已变更，重建容器..."
        docker stop $CONTAINER_NAME 2>/dev/null || true
        docker rm $CONTAINER_NAME 2>/dev/null || true
        
        echo "🐳 启动新容器..."
        docker run -d \
            --name $CONTAINER_NAME \
            -p $PORT:4000 \
            -e DATABASE_TYPE=sqlite \
            -e AUTH_CODE="$AUTH_CODE" \
            -e "CRON_EXPRESSION=$CRON_EXPRESSION" \
            -v "$DATA_DIR:/app/data" \
            cooderl/wewe-rss-sqlite:latest
        
        echo "✅ wewe-rss 已重新部署"
    fi
else
    # 配置国内镜像加速（如果需要）
    echo "🐳 拉取 wewe-rss 镜像..."
    
    # 尝试直接拉取，如果失败则配置镜像加速
    if ! docker pull cooderl/wewe-rss-sqlite:latest 2>/dev/null; then
        echo "⚠️ 直接拉取失败，尝试配置镜像加速..."
        
        # 检查是否已有 daemon.json
        DOCKER_CONFIG_DIR="$HOME/.docker"
        mkdir -p "$DOCKER_CONFIG_DIR"
        
        if [ ! -f "$DOCKER_CONFIG_DIR/daemon.json" ]; then
            echo '{"registry-mirrors": ["https://docker.1ms.run"]}' > "$DOCKER_CONFIG_DIR/daemon.json"
            echo "   已配置镜像加速，请重启 Docker Desktop 后重试"
            echo ""
            echo "   macOS: 点击菜单栏 Docker 图标 → Restart"
            echo "   或在 Docker Desktop → Settings → Docker Engine 中添加："
            echo '   "registry-mirrors": ["https://docker.1ms.run"]'
            exit 1
        fi
        
        # 再次尝试
        docker pull cooderl/wewe-rss-sqlite:latest
    fi
    
    echo "🐳 启动 wewe-rss 容器..."
    docker run -d \
        --name $CONTAINER_NAME \
        -p $PORT:4000 \
        -e DATABASE_TYPE=sqlite \
        -e AUTH_CODE="$AUTH_CODE" \
        -e "CRON_EXPRESSION=$CRON_EXPRESSION" \
        -v "$DATA_DIR:/app/data" \
        cooderl/wewe-rss-sqlite:latest
    
    echo "✅ wewe-rss 部署成功！"
fi

# 等待服务启动
echo ""
echo "⏳ 等待服务启动..."
sleep 3

# 检查服务是否正常
if curl -s http://localhost:$PORT > /dev/null; then
    echo ""
    echo "═══════════════════════════════════════════════════════"
    echo "✅ wewe-rss 已成功运行！"
    echo ""
    echo "📍 访问地址: http://localhost:$PORT/dash"
    echo "🔑 访问密码: $AUTH_CODE"
    echo ""
    echo "📋 下一步："
    echo "   1. 打开浏览器访问上面的地址"
    echo "   2. 点击「账号管理」→「添加账号」"
    echo "   3. 用微信扫码登录微信读书"
    echo "   4. 点击「添加」添加公众号订阅"
    echo "═══════════════════════════════════════════════════════"
else
    echo "⚠️ 服务可能还在启动中，请稍后访问 http://localhost:$PORT/dash"
fi
