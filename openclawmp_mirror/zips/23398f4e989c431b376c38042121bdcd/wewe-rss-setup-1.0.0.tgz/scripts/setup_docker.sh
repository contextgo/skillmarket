#!/bin/bash
# setup_docker.sh - 检查并安装 Docker
# 用于 macOS (Intel/Apple Silicon)

set -e

echo "🐳 检查 Docker 环境..."

# 检查 Docker 是否已安装
if command -v docker &> /dev/null; then
    # 检查 Docker 是否运行
    if docker info &> /dev/null; then
        echo "✅ Docker 已安装且正在运行"
        docker --version
        exit 0
    else
        echo "⚠️ Docker 已安装但未运行"
        
        # macOS: 尝试启动 Docker Desktop
        if [[ "$OSTYPE" == "darwin"* ]]; then
            if [ -d "/Applications/Docker.app" ]; then
                echo "🚀 正在启动 Docker Desktop..."
                open /Applications/Docker.app
                echo ""
                echo "⏳ 等待 Docker Desktop 启动..."
                echo "👆 请在 Mac 屏幕上完成授权（可能需要输入密码）"
                echo ""
                
                # 等待 Docker 启动（最多 120 秒）
                for i in {1..24}; do
                    sleep 5
                    if docker info &> /dev/null; then
                        echo "✅ Docker Desktop 启动成功！"
                        exit 0
                    fi
                    echo "   等待中... ($((i*5))s)"
                done
                
                echo "❌ Docker Desktop 启动超时，请手动检查"
                exit 1
            fi
        fi
        
        echo "❌ 请手动启动 Docker"
        exit 1
    fi
fi

echo "📦 Docker 未安装，开始安装..."

# macOS 安装
if [[ "$OSTYPE" == "darwin"* ]]; then
    # 检测架构
    ARCH=$(uname -m)
    if [ "$ARCH" = "arm64" ]; then
        DOCKER_URL="https://desktop.docker.com/mac/main/arm64/Docker.dmg"
    else
        DOCKER_URL="https://desktop.docker.com/mac/main/amd64/Docker.dmg"
    fi
    
    echo "⬇️ 下载 Docker Desktop for Mac ($ARCH)..."
    cd ~/Downloads
    curl -L -o Docker.dmg "$DOCKER_URL"
    
    echo "📀 挂载安装包..."
    hdiutil attach Docker.dmg -nobrowse
    
    echo "📁 安装 Docker.app..."
    cp -R "/Volumes/Docker/Docker.app" /Applications/
    
    echo "📀 卸载安装包..."
    hdiutil detach /Volumes/Docker
    
    # 清理
    rm -f Docker.dmg
    
    # 修复可能的 md5 命令问题
    if [ ! -f /usr/local/bin/md5 ] && [ -f /sbin/md5 ]; then
        echo "🔧 修复 md5 命令..."
        echo "⚠️ 需要管理员权限，请输入密码："
        sudo ln -sf /sbin/md5 /usr/local/bin/md5
    fi
    
    echo "🚀 启动 Docker Desktop..."
    open /Applications/Docker.app
    
    echo ""
    echo "═══════════════════════════════════════════════════════"
    echo "👆 请在 Mac 屏幕上完成以下操作："
    echo "   1. 同意服务条款"
    echo "   2. 授权系统权限（输入 Mac 密码）"
    echo "   3. 等待 Docker Desktop 启动完成"
    echo "═══════════════════════════════════════════════════════"
    echo ""
    
    # 等待 Docker 启动
    echo "⏳ 等待 Docker Desktop 启动..."
    for i in {1..36}; do
        sleep 5
        if docker info &> /dev/null; then
            echo ""
            echo "✅ Docker Desktop 安装并启动成功！"
            docker --version
            exit 0
        fi
        echo "   等待中... ($((i*5))s)"
    done
    
    echo ""
    echo "❌ Docker Desktop 启动超时"
    echo "   请确保已在屏幕上完成授权"
    echo "   然后重新运行此脚本"
    exit 1

# Linux 安装
elif [[ "$OSTYPE" == "linux-gnu"* ]]; then
    echo "🐧 检测到 Linux 系统"
    
    # 检查是否是 Debian/Ubuntu
    if command -v apt-get &> /dev/null; then
        echo "📦 使用 apt 安装 Docker..."
        sudo apt-get update
        sudo apt-get install -y docker.io docker-compose
        sudo systemctl start docker
        sudo systemctl enable docker
        
        # 添加当前用户到 docker 组
        sudo usermod -aG docker $USER
        
        echo "✅ Docker 安装成功！"
        echo "⚠️ 请注销并重新登录以使用 Docker（或运行 'newgrp docker'）"
        exit 0
    fi
    
    # 检查是否是 RHEL/CentOS
    if command -v yum &> /dev/null; then
        echo "📦 使用 yum 安装 Docker..."
        sudo yum install -y docker docker-compose
        sudo systemctl start docker
        sudo systemctl enable docker
        sudo usermod -aG docker $USER
        
        echo "✅ Docker 安装成功！"
        echo "⚠️ 请注销并重新登录以使用 Docker"
        exit 0
    fi
    
    echo "❌ 不支持的 Linux 发行版"
    echo "   请手动安装 Docker: https://docs.docker.com/engine/install/"
    exit 1

else
    echo "❌ 不支持的操作系统: $OSTYPE"
    exit 1
fi
