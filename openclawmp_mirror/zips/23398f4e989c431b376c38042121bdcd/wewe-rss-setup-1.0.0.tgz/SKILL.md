---
name: wewe-rss-setup
description: |
  部署 wewe-rss 微信公众号订阅系统，把任意公众号转成 RSS 订阅源。
  
  使用场景：
  (1) 用户想订阅微信公众号、获取公众号更新
  (2) 用户想把公众号内容同步到 Twitter、Telegram 等平台
  (3) 用户想用 RSS 阅读器统一管理公众号
  (4) 用户想监控或抓取公众号文章
  
  触发关键词：公众号订阅、公众号 RSS、微信文章订阅、wewe-rss、公众号转 RSS、抓取公众号、微信读书订阅、自动获取公众号文章
---

# wewe-rss 部署技能

## 这个技能能帮用户做什么

**一句话**：让用户能像订阅播客一样订阅微信公众号。

**解决的问题**：
- 微信公众号没有 RSS，无法用 RSS 阅读器订阅
- 想自动获取公众号更新，同步到其他平台（Twitter、Telegram 等）
- 不想每天手动打开微信看有没有新文章

**用户得到什么**：
- 一个本地运行的 RSS 服务
- 可以订阅任意公众号
- 每天自动更新 3 次（8:00 / 14:00 / 20:00）
- RSS 链接可以接入任何 RSS 阅读器或自动化工具

**适合谁**：
- 内容创作者（同步自己公众号到其他平台）
- 信息重度用户（用 RSS 统一管理信息源）
- 想做公众号监控/分析的人

---

## 你要做什么

帮用户在本地部署 wewe-rss，让他们能订阅任意微信公众号并获得 RSS 源。

## ⚠️ 前置检查（开始前先确认）

**不支持的情况，直接告诉用户：**

| 情况 | 回复 |
|------|------|
| Windows 系统 | "抱歉，目前只支持 macOS 和 Linux。Windows 需要用 WSL2，配置比较复杂。" |
| 没有微信账号 | "这个方案需要微信账号扫码登录微信读书，没有微信暂时无法使用。" |
| 电脑内存 < 4GB | "Docker 需要至少 4GB 内存，你的电脑配置可能跑不动。" |
| 已经装过 wewe-rss | 先检查 `docker ps -a | grep wewe-rss`，如果有就问用户是要"重新配置"还是"继续使用现有的" |

## 关于 `{baseDir}`

`{baseDir}` 是这个技能的安装目录。执行脚本时替换为实际路径，例如：
- `~/.openclaw/skills/wewe-rss-setup/scripts/setup_docker.sh`

## 执行流程

按顺序执行，遇到需要用户配合的步骤就停下来等。

---

### 1️⃣ 检查环境

**先检查操作系统**：
```bash
uname -s
```
- `Darwin` = macOS ✅
- `Linux` = Linux ✅
- 其他 = 暂不支持，告诉用户

**检查 Docker 是否已安装且运行**：
```bash
docker info 2>&1
```

**如果成功**（输出包含 Server Version）→ 跳到步骤 3

**如果失败** → 继续步骤 2 安装 Docker

---

### 2️⃣ 安装 Docker

#### macOS

##### 2.1 预处理：修复 md5 命令

macOS 上 Docker 安装可能报 `md5: command not found`，先修复：

```bash
# 检查 md5 是否存在
which md5 || echo "NEED_FIX"
```

如果输出 `NEED_FIX`，执行：
```bash
sudo ln -sf /sbin/md5 /usr/local/bin/md5
```

告诉用户：
> "需要修复一个系统命令，请在电脑上输入密码授权。"

#### 2.2 下载安装 Docker Desktop

```bash
bash {baseDir}/scripts/setup_docker.sh
```

脚本会自动下载、安装、启动 Docker Desktop。

#### 2.3 等待用户授权

告诉用户：
> "Docker 正在安装，请在电脑屏幕上：
> 1. 同意服务条款
> 2. 输入密码授权
> 3. 等待菜单栏 Docker 图标**停止转动**
> 
> 完成后告诉我。"

**等用户回复**

#### 2.4 验证安装成功

```bash
docker info 2>&1 | head -5
```

**如果失败**，可能是还没启动完，再等 30 秒重试。

**如果仍然失败**，检查错误信息：
- `Cannot connect to Docker daemon` → Docker Desktop 没启动，让用户点击菜单栏图标
- `permission denied` → 让用户重启电脑后重试

#### Linux

直接运行安装脚本：
```bash
bash {baseDir}/scripts/setup_docker.sh
```

脚本会自动检测发行版（Debian/Ubuntu/CentOS）并安装。

**安装后告诉用户**：
> "Docker 安装成功！请运行 `newgrp docker` 或重新登录终端，然后告诉我。"

**等用户回复**

---

### 3️⃣ 部署 wewe-rss

#### 3.1 拉取镜像

```bash
docker pull cooderl/wewe-rss-sqlite:latest
```

**如果超时或失败**（常见于国内网络），配置镜像加速：

```bash
# 创建 Docker 配置目录
mkdir -p ~/.docker

# 写入镜像加速配置
cat > ~/.docker/daemon.json << 'EOF'
{
  "registry-mirrors": ["https://docker.1ms.run"]
}
EOF
```

告诉用户：
> "网络有点慢，我配置了镜像加速。请点击菜单栏 Docker 图标 → Restart，重启后告诉我。"

**等用户回复后**，重新拉取镜像。

#### 3.2 启动容器

```bash
bash {baseDir}/scripts/deploy_wewe_rss.sh
```

#### 3.3 验证服务启动

```bash
curl -s http://localhost:4000 | head -3
```

有 HTML 响应就是成功。

**如果端口被占用**：
```bash
lsof -i:4000
```
让用户停止占用进程，或改用其他端口（修改脚本 PORT 变量）。

---

### 4️⃣ 引导用户扫码登录

先说明风险：
> "接下来需要用微信扫码登录微信读书。
> 
> ⚠️ 建议用**微信小号**登录。万一触发风控，只影响微信读书（24小时恢复），不影响微信聊天和支付。
> 
> 准备好了吗？"

**等用户确认后**，给出步骤：
> "请在电脑上：
> 1. 打开 http://localhost:4000/dash
> 2. 点击右上角「账号管理」
> 3. 点击「添加账号」
> 4. 用微信扫码登录
> 5. **不要勾选"24小时后自动退出"**
> 
> 登录成功后告诉我。"

**等用户回复**

---

### 5️⃣ 添加公众号订阅

> "登录成功！把你想订阅的公众号文章链接发给我。
> 
> 链接格式：`https://mp.weixin.qq.com/s/xxxxx`
> 
> 随便一篇文章都行，我会自动识别是哪个公众号。"

**收到链接后**，有两种方式：

**方式 A：浏览器自动化（推荐，如果有 browser 工具）**
```
1. browser(action=open, url="http://localhost:4000/dash")
2. browser(action=snapshot) → 找"添加"按钮 ref
3. browser(action=act, kind=click, ref=添加按钮)
4. browser(action=snapshot) → 找输入框 ref
5. browser(action=act, kind=type, ref=输入框, text=用户的链接)
6. browser(action=snapshot) → 找"确定"按钮 ref
7. browser(action=act, kind=click, ref=确定按钮)
8. browser(action=snapshot) → 确认出现"添加成功"提示
```

**方式 B：引导用户手动操作（如果没有 browser 工具）**
> "请在浏览器里：
> 1. 打开 http://localhost:4000/dash
> 2. 点击「添加」按钮
> 3. 粘贴这个链接：[用户的链接]
> 4. 点击「确定」
> 
> 添加成功后告诉我。"

**等用户回复**

添加成功后：
> "✅ 已订阅「公众号名称」！还有其他想订阅的吗？"

用户说没有了 → 进入步骤 6

---

### 6️⃣ 验证 & 完成

**验证订阅是否成功**：
```bash
curl -s "http://localhost:4000/feeds/all.atom" | head -20
```

如果能看到 XML 内容和文章标题，就是成功了。

**如果是空的**，点击一次"更新全部"：
```
browser 打开 http://localhost:4000/dash → 点击"更新全部"
```

等几秒后再检查 RSS。

**成功后告诉用户**：
> "全部搞定！🎉
> 
> 📍 管理地址：http://localhost:4000/dash
> 📡 RSS 地址：http://localhost:4000/feeds/all.atom
> 
> 系统每天 8:00、14:00、20:00 自动更新。有新文章会出现在 RSS 里。
> 
> 💡 小提示：电脑关机后服务会停止，下次开机后打开 Docker Desktop 就会自动恢复。"

---

## 常见问题速查

| 现象 | 原因 | 解决 |
|------|------|------|
| `md5: command not found` | macOS 缺命令 | `sudo ln -sf /sbin/md5 /usr/local/bin/md5` |
| Docker 拉镜像超时 | 国内网络问题 | 配置镜像加速后重启 Docker |
| `Cannot connect to Docker daemon` | Docker 没启动 | 让用户点击菜单栏 Docker 图标启动 |
| 端口 4000 被占用 | 其他程序占用 | `lsof -i:4000` 查看并停止 |
| 添加公众号失败 | 触发微信读书风控 | 等 24 小时自动恢复 |
| 扫码后提示异常 | 账号风险 | 换个微信小号试试 |

---

## 关键信息

- 服务地址：http://localhost:4000/dash
- 数据目录：~/wewe-rss/data（容器删了数据还在）
- 容器名：wewe-rss
- 更新频率：每天 8/14/20 点
