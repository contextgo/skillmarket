# Database Migration Patterns

## Zero-Downtime Migrations

### Expand-Contract Pattern
1. **Expand**: Add new column/table (non-breaking)
2. **Migrate**: Backfill data (dual-write)
3. **Contract**: Remove old column/table (breaking)

### Adding Columns
```sql
-- Step 1: Add nullable or with default (safe)
ALTER TABLE users ADD COLUMN email VARCHAR(255);

-- Step 2: Backfill
UPDATE users SET email = ...;

-- Step 3: Add NOT NULL constraint
ALTER TABLE users ALTER COLUMN email SET NOT NULL;
```

### Renaming Columns
1. Add new column
2. Dual-write to both columns
3. Migrate reads to new column
4. Drop old column

## Safe Operations
- Add column (nullable or default)
- Add index (CONCURRENTLY in PostgreSQL)
- Add table
- Add constraint (NOT VALID first)

## Dangerous Operations (Plan Carefully)
- Remove column → use view wrapper first
- Change column type → create new, migrate, swap
- Rename table → use view alias first
- Add NOT NULL → backfill first

## Rollback Strategy
- Every migration needs a down migration
- Test rollback in staging
- Feature flags for code that depends on schema
- Keep rollback SQL in version control

## Tools
- PostgreSQL: pg_partman for partitioning
- Flyway/Liquibase: versioned migrations
- Django/Rails: built-in migration frameworks