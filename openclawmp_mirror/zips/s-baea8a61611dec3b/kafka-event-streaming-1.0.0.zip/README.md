# Kafka Event Streaming Patterns

## Topic Design
- Use event type as topic name: orders, payments, user-events
- Retention policy: 7 days for operational, 30 days for analytics
- Compaction for state: enable for latest-value topics (user-profile)

## Partitioning Strategy
- Key-based: user_id, order_id → ordered per entity
- Random: high throughput, no ordering guarantee
- Time-based: log compaction + time range queries

## Consumer Patterns
- Consumer group: parallel processing with auto-rebalance
- Manual vs auto commit: auto for speed, manual for reliability
- Seeking: reset offset for replay or recovery

## Exactly-Once Semantics
- Idempotent producers: enable_idempotence=true
- Transactional consumers: read-process-write in single transaction
- Debezium CDC: change data capture with guaranteed ordering

## Schema Evolution
- Use Schema Registry (Avro/Protobuf)
- Backward/forward/full compatibility rules
- Never delete fields, always add optional

## Monitoring
- Consumer lag: must-track metric
- Throughput: bytes/sec per topic
- Error rate: failed produce/consume ratio
- Partition balance: even distribution across consumers