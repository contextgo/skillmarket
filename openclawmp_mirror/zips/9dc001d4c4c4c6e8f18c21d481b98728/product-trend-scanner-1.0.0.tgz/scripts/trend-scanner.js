#!/usr/bin/env node
/**
 * 电商爆款趋势扫描器
 * 使用 Tavily API 聚合跨平台热度数据
 */

const https = require('https');

const TAVILY_API_KEY = process.env.TAVILY_API_KEY || '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';
const TAVILY_API_URL = 'api.tavily.com';

// Tavily 搜索
async function tavilySearch(query, options = {}) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify({
      api_key: TAVILY_API_KEY,
      query: query,
      search_depth: options.depth || 'basic',
      include_answer: options.answer !== false,
      max_results: options.maxResults || 10,
      include_domains: options.domains || [],
      exclude_domains: options.excludeDomains || []
    });

    const req = https.request({
      hostname: TAVILY_API_URL,
      path: '/search',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve(JSON.parse(data));
        } catch (e) {
          reject(new Error('Invalid JSON response'));
        }
      });
    });

    req.on('error', reject);
    req.write(postData);
    req.end();
  });
}

// 分析跨平台热度
async function analyzeTrend(productName) {
  console.log(`🔍 正在分析 "${productName}" 的跨平台热度...\n`);

  try {
    // 1. 小红书热度
    const xhsQuery = `${productName} 小红书 测评 推荐`;
    const xhsResult = await tavilySearch(xhsQuery, { 
      depth: 'basic', 
      maxResults: 10,
      include_domains: ['xiaohongshu.com', 'zhihu.com', 'baijiahao.baidu.com']
    });

    // 2. 抖音热度
    const douyinQuery = `${productName} 抖音 视频 热度`;
    const douyinResult = await tavilySearch(douyinQuery, { 
      depth: 'basic', 
      maxResults: 10 
    });

    // 3. 综合趋势
    const trendQuery = `${productName} 2024 2025 销量 趋势 市场`;
    const trendResult = await tavilySearch(trendQuery, { 
      depth: 'advanced', 
      maxResults: 10 
    });

    // 生成报告
    generateReport(productName, {
      xiaohongshu: xhsResult,
      douyin: douyinResult,
      trend: trendResult
    });

  } catch (error) {
    console.error('❌ 分析失败:', error.message);
  }
}

// 生成分析报告
function generateReport(productName, data) {
  const xhsCount = data.xiaohongshu.results?.length || 0;
  const douyinCount = data.douyin.results?.length || 0;
  const trendAnswer = data.trend.answer || '';

  // 简单热度评分
  let heatScore = 0;
  if (xhsCount > 5) heatScore += 30;
  else if (xhsCount > 0) heatScore += 15;
  
  if (douyinCount > 5) heatScore += 30;
  else if (douyinCount > 0) heatScore += 15;
  
  if (trendAnswer.includes('热销') || trendAnswer.includes('爆款')) heatScore += 20;
  if (trendAnswer.includes('上升') || trendAnswer.includes('增长')) heatScore += 20;

  console.log('='.repeat(50));
  console.log(`📊 ${productName} 热度分析报告`);
  console.log('='.repeat(50));
  console.log();
  
  console.log(`🔥 综合热度评分: ${heatScore}/100`);
  console.log(getHeatEmoji(heatScore));
  console.log();

  console.log('📱 小红书热度:');
  console.log(`   - 相关内容: ${xhsCount} 条`);
  if (data.xiaohongshu.results && data.xiaohongshu.results.length > 0) {
    console.log('   - 热门内容:');
    data.xiaohongshu.results.slice(0, 3).forEach((r, i) => {
      console.log(`     ${i + 1}. ${r.title?.substring(0, 40)}...`);
    });
  }
  console.log();

  console.log('🎵 抖音热度:');
  console.log(`   - 相关内容: ${douyinCount} 条`);
  if (data.douyin.results && data.douyin.results.length > 0) {
    console.log('   - 热门话题:');
    data.douyin.results.slice(0, 3).forEach((r, i) => {
      console.log(`     ${i + 1}. ${r.title?.substring(0, 40)}...`);
    });
  }
  console.log();

  if (trendAnswer) {
    console.log('📈 市场趋势分析:');
    console.log(`   ${trendAnswer.substring(0, 200)}...`);
    console.log();
  }

  console.log('💡 选品建议:');
  console.log(getSuggestion(heatScore));
  console.log();
  console.log('='.repeat(50));
}

function getHeatEmoji(score) {
  if (score >= 80) return '   ⭐⭐⭐⭐⭐ 爆款潜力 - 强烈推荐';
  if (score >= 60) return '   ⭐⭐⭐⭐ 热度不错 - 可以考虑';
  if (score >= 40) return '   ⭐⭐⭐ 一般热度 - 谨慎入场';
  if (score >= 20) return '   ⭐⭐ 热度较低 - 观望为主';
  return '   ⭐ 热度很低 - 不建议入场';
}

function getSuggestion(score) {
  if (score >= 80) {
    return '   ✅ 市场热度高，正处于上升期\n   ✅ 建议快速跟进，抢占流量\n   ⚠️ 注意供应链管理，避免缺货';
  } else if (score >= 60) {
    return '   ✅ 有一定市场基础\n   ✅ 可以差异化切入\n   📊 建议先做小规模测试';
  } else if (score >= 40) {
    return '   ⚠️ 市场热度一般\n   📊 建议分析竞品差异化空间\n   ⏳ 或等待更好的入场时机';
  } else {
    return '   ❌ 当前热度较低\n   💡 建议寻找其他品类\n   📚 可关注但暂不入场';
  }
}

// CLI 接口
const args = process.argv.slice(2);
const command = args[0];

if (!command || command === 'help') {
  console.log(`
电商爆款趋势扫描器 v1.0.0

用法:
  trend-scan <产品名称>        分析产品跨平台热度趋势
  trend-scan help              显示帮助信息

示例:
  trend-scan 便携榨汁杯
  trend-scan 无线蓝牙耳机
  trend-scan 瑜伽裤

环境变量:
  TAVILY_API_KEY               Tavily API 密钥（可选，默认使用内置密钥）
`);
  process.exit(0);
}

// 执行分析
const productName = args.join(' ');
analyzeTrend(productName);
