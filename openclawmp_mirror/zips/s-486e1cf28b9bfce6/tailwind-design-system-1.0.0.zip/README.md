# Tailwind CSS Design System

## Overview
Enterprise design system with Tailwind CSS for unified visual language.

## Design Tokens

### Color System
Define brand colors with 50-900 scale. Semantic colors auto-adapt to dark mode.

### Spacing & Typography
- 4px base grid
- Modular scale for font sizes
- Line height: 1.5 body / 1.25 headings

## Component Patterns

### Button Variants
primary/secondary/ghost/danger with consistent radius, padding, hover states.

### Form Controls
Unified input/select/textarea: border, focus ring, error state.

### Card System
Fixed padding + shadow hierarchy + hover effects.

## Dark Mode
- Use dark: prefix
- Semantic color tokens auto-adapt
- prefers-color-scheme auto-switch

## Responsive Strategy
Mobile-first: sm(640) → md(768) → lg(1024) → xl(1280) → 2xl(1536)

## Maintenance
- @layer for style priority
- @apply for common combinations
- eslint-plugin-tailwindcss to prevent class bloat
- Regular purge config audit