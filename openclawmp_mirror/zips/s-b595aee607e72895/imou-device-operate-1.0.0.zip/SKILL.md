---
name: imou-device-operate
displayName: 乐橙设备操控
version: 1.0.0
description: >
  乐橙（Imou）设备操控技能。支持云台转动控制（上下左右等方向）、设备画面抓图及图片下载。
  适用于：乐橙云台控制、设备抓图、下载设备图片、PTZ控制等场景。
metadata:
  {
    "openclaw":
      {
        "emoji": "🎮",
        "requires": { "env": ["IMOU_APP_ID", "IMOU_APP_SECRET"], "pip": ["requests"] },
        "primaryEnv": "IMOU_APP_ID",
        "install":
          [
            { "id": "python-requests", "kind": "pip", "package": "requests", "label": "安装 requests 依赖" }
          ]
      }
  }
---

# 🎮 乐橙设备操控

操控乐橙云端设备：云台转动（PTZ）、设备画面抓图、下载抓图图片。

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install requests
```

### 2. 配置环境变量（必填）

```bash
export IMOU_APP_ID="你的应用ID"
export IMOU_APP_SECRET="你的应用密钥"
export IMOU_BASE_URL="API基础地址"
```

**API 基础地址说明：**

| 区域 | 数据中心 | 基础地址 |
|------|---------|---------|
| 中国大陆 | — | `https://openapi.lechange.cn` |
| 海外 | 东亚 | `https://openapi-sg.easy4ip.com:443` |
| 海外 | 中欧 | `https://openapi-fk.easy4ip.com:443` |
| 海外 | 美西 | `https://openapi-or.easy4ip.com:443` |

**如何获取 App ID 和 App Secret：**
- 访问 [乐橙开放平台](https://open.imou.com) 注册开发者账号
- 进入「应用管理」-「应用信息」获取 `appId` 和 `appSecret`

### 3. 运行命令

```bash
# 设备抓图（返回可下载的图片URL，可选保存到本地）
python3 {baseDir}/scripts/device_operate.py snapshot 设备序列号 通道ID [--save 保存路径]

# 云台控制（操作码: 0-10，持续时间：毫秒）
python3 {baseDir}/scripts/device_operate.py ptz 设备序列号 通道ID 操作码 持续时间毫秒
```

**云台操作码说明：**

| 操作码 | 方向 |
|-------|-----|
| 0 | 上 |
| 1 | 下 |
| 2 | 左 |
| 3 | 右 |
| 4 | 左上 |
| 5 | 左下 |
| 6 | 右上 |
| 7 | 右下 |
| 8 | 放大 |
| 9 | 缩小 |
| 10 | 停止 |

## ✨ 功能特性

1. **设备抓图**：调用 setDeviceSnapEnhanced 获取抓图 URL（有效期2小时），可选 `--save` 下载到本地文件
2. **云台控制**：controlMovePTZ 控制云台转动，支持方向操作（0-10）和持续时间（毫秒）。设备需支持 PT/PTZ 功能

## 📡 请求标识

所有请求都会携带请求头 `Client-Type: OpenClaw`，用于平台识别。

## 📚 API 参考文档

| 接口 | 文档地址 |
|-----|---------|
| 开发规范 | https://open.imou.com/document/pages/c20750/ |
| 获取 accessToken | https://open.imou.com/document/pages/fef620/ |
| 设备抓图（增强版） | https://open.imou.com/document/pages/09fe83/ |
| 云台转动控制 | https://open.imou.com/document/pages/66c489/ |

更多请求/响应格式详见 `references/imou-operate-api.md`

## 💡 使用提示

- **Token 有效期**：每次运行自动获取，有效期3天
- **抓图间隔**：同一设备请求间隔应 ≥1秒；抓图 URL 有效期2小时
- **云台控制**：使用操作码 10（停止）停止转动；持续时间为毫秒

## 🔒 数据流向说明

| 数据 | 发送至 | 用途 |
|-----|-------|-----|
| appId, appSecret | 乐橙开放平台 | 获取 accessToken |
| accessToken, deviceId, channelId 等 | 乐橙开放平台 | 设备抓图、云台控制 |

所有请求仅发送至配置的 `IMOU_BASE_URL`（乐橙官方API），不涉及第三方。
