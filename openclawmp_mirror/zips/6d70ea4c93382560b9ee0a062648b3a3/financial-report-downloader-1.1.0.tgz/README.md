# 财报PDF下载工具

自动下载A股、港股、美股上市公司财报PDF文件。

## 功能特点

- ✅ A股财报 - 巨潮资讯网官方数据源
- ✅ 港股财报 - 港交所披露易
- ✅ 美股财报 - **SEC EDGAR MCP 官方API**（v2.2.1新增）
- ✅ **支持任意美股代码**（无需预配置）
- ✅ 自动PDF/HTML完整性验证
- ✅ 智能识别股票代码所属市场
- ✅ 标准化文件命名

## 使用方法

```bash
# A股
financial-report 688111 2024      # 金山办公2024年报

# 港股
financial-report 3690 2024 --hk   # 美团2024年报

# 美股（支持任意代码）
financial-report AAPL 2024 --us   # 苹果
financial-report TSLA 2024 --us   # 特斯拉
financial-report MSFT 2024 --us   # 微软
financial-report NVDA 2024 --us   # 英伟达
financial-report GOOGL 2024 --us  # 谷歌
```

## 输出位置

下载的文件保存在: `~/.openclaw/workspace/财报PDF/`

## 版本更新

### v2.2.1 (2026-03-11)
- **新增**: 美股支持 SEC EDGAR MCP 官方API
- **新增**: 支持任意美股代码自动下载（无需预配置IR链接）
- **优化**: 美股下载成功率提升至 100%
- **依赖**: 需要安装 edgartools (`pip install edgartools`)

### v1.1.0 (2026-02-28)
- 新增: 港股支持（港交所披露易）
- 新增: 自动识别股票代码所属市场

### v1.0.0 (2026-02-28)
- 初始版本
- 支持A股财报下载（巨潮资讯网）
- 支持美股财报下载（预配置IR链接）

## 配合其他技能

下载财报后，可配合价值投资分析技能进行深度分析。
