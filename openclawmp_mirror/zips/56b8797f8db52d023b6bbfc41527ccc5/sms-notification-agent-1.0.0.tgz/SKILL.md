---
name: sms-notification-agent
description: "Agent 短信通知方案"
version: 1.0.0
---

Agent 发送短信通知的方案。

## 方案选择
| 服务 | 适用 | 成本 |
|------|------|------|
| Twilio | 国际 | $0.0079/条 |
| 阿里云短信 | 中国 | 0.045/条 |

## Twilio 实现
```python
from twilio.rest import Client

class SMSNotifier:
    def __init__(self, sid, token, from_num):
        self.client = Client(sid, token)
        self.from_num = from_num
        self.sent = 0
        self.max_daily = 100
    
    def send(self, to, message):
        if self.sent >= self.max_daily:
            return {"success": False, "error": "limit"}
        msg = self.client.messages.create(body=message[:160], from_=self.from_num, to=to)
        self.sent += 1
        return {"success": True, "sid": msg.sid}
```

## 告警分级
| 级别 | 条件 | 方式 |
|------|------|------|
| P0 | 服务不可用 | SMS + 电话 |
| P1 | 核心异常 | SMS |
| P2 | 性能下降 | 邮件 + IM |
| P3 | 非关键 | 日志 |

## 注意
- 避免深夜发送
- 频率限制防轰炸
- 失败降级到邮件

