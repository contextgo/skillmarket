# Minimax Coding Plan 用量查询

查询 Minimax Coding Plan 用量，自动从 openclaw.json 读取 API Key。

## 功能

- 查询当前 Minimax Coding Plan API 使用量
- 自动从 openclaw.json 读取 API Key，无需手动配置
- 显示输入/输出 token 消耗统计

## 适用场景

使用 Minimax 模型的用户想了解 Coding Plan 额度消耗情况。
