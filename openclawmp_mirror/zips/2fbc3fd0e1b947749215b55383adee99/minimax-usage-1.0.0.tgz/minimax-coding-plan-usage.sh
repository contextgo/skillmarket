#!/bin/bash
# Minimax Coding Plan 用量查询
# 自动从 openclaw.json 读取当前模型的 API Key

OPENCLAW_JSON="/mnt/sata1-4/OpenClaw/Configs/OpenClawMgr/data/.openclaw/openclaw.json"

API_KEY=$(python3 -c "
import json
with open('${OPENCLAW_JSON}') as f:
    d = json.load(f)
print(d['models']['providers']['minimax-cn']['apiKey'])
" 2>/dev/null)

if [ -z "$API_KEY" ]; then
    echo "❌ 无法从 openclaw.json 获取 MINIMAX API Key"
    exit 1
fi

echo "🔍 查询 Minimax Coding Plan 用量..."

RESPONSE=$(curl -s --location 'https://www.minimaxi.com/v1/api/openplatform/coding_plan/remains' \
  --header "Authorization: Bearer $API_KEY" \
  --header 'Content-Type: application/json' \
  --write-out "\nHTTP_STATUS:%{http_code}" 2>/dev/null)

STATUS=$(echo "$RESPONSE" | grep "HTTP_STATUS" | cut -d: -f2)
BODY=$(echo "$RESPONSE" | grep -v "HTTP_STATUS")

if [ "$STATUS" = "200" ]; then
    echo "$BODY" | python3 -c "
import json, sys, math
d = json.load(sys.stdin)
code = d.get('base_resp', {}).get('status_code', -1)
if code != 0:
    print(f'❌ API错误: code={code}')
    sys.exit(0)

items = d.get('model_remains', [])
# 找 MiniMax-M* 相关条目
coding = None
for item in items:
    name = item.get('model_name', '')
    if 'MiniMax-M' in name or 'minimax-m' in name.lower():
        coding = item
        break

if not coding:
    print('未找到 Coding Plan 条目')
    sys.exit(0)

total = coding.get('current_interval_total_count', 0)
actual_used = coding.get('current_interval_usage_count', 0)
remaining = total - actual_used
reset_ms = coding.get('remains_time', 0)
reset_h = reset_ms / 3600000
pct = round(remaining / total * 100) if total > 0 else 0

print(f'''
📊 Minimax Coding Plan 状态
   已用: {remaining} / {total} ({pct}%)
   剩余: {actual_used}
   重置时间: {reset_h:.1f}h
''')
if pct >= 80:
    print('🔴 警告：用量超过 80%，请注意额度')
elif pct >= 60:
    print('🟡 注意：用量超过 60%')
else:
    print('💚 用量正常')
" 2>/dev/null
else
    echo "❌ 请求失败，HTTP状态码: $STATUS"
    echo "$BODY"
fi
