---
name: minimax-usage
description: 查询 Minimax Coding Plan 用量，自动从 openclaw.json 读取 API Key
metadata: {"clawdbot":{"emoji":"📊"}}
---

# Minimax Coding Plan 用量查询

## 使用方式

```bash
bash skills/minimax-coding-plan-usage/minimax-coding-plan-usage.sh
```

## 输出示例

```
🔍 查询 Minimax Coding Plan 用量...

📊 Minimax Coding Plan 状态
   已用: 255 / 1500 (17%)
   剩余: 1245
   重置时间: 3h 17m

💚 用量正常
```

## 实现说明

- API Key 自动从 `openclaw.json` 的 `minimax-cn` provider 配置读取
- 无需手动配置 .env
- 接口：`GET https://www.minimaxi.com/v1/api/openplatform/coding_plan/remains`
