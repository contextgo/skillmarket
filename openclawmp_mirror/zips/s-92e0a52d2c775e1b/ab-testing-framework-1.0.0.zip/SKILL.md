---
name: ab-testing-framework
description: "Agent 自动化 A/B 测试框架"
version: 1.0.0
---

A/B 测试自动化框架：实验设计到统计决策。

## 流量分配
```python
import hashlib

def assign_variant(user_id, experiment, variants):
    h = int(hashlib.md5(f"{user_id}:{experiment}".encode()).hexdigest(), 16)
    total = sum(variants.values())
    cum = 0
    for v, w in variants.items():
        cum += w
        if h % total < cum: return v
    return list(variants.keys())[-1]
```

## 统计检验
```python
from scipy import stats

def analyze(control, treatment):
    n1, x1 = len(control), sum(control)
    n2, x2 = len(treatment), sum(treatment)
    p1, p2 = x1/n1, x2/n2
    pp = (x1+x2)/(n1+n2)
    se = (pp*(1-pp)*(1/n1+1/n2))**0.5
    z = (p2-p1) / se if se > 0 else 0
    pv = 2 * (1 - stats.norm.cdf(abs(z)))
    return {"control": p1, "treatment": p2, "lift": (p2-p1)/p1 if p1 else 0, "p_value": pv, "significant": pv < 0.05}
```

## 决策
- p < 0.05 且 lift >= 5% → 发布实验组
- p < 0.05 且 lift < -5% → 保持对照组
- 否则 → 继续收集

## 注意
- 样本量不足不提前停止
- 多重比较 Bonferroni 校正
- 同用户同实验只分配一次

