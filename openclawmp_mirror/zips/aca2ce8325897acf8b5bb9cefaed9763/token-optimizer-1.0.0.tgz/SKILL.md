---
name: token-optimizer
version: 1.0.0
description: AI对话Token智能优化助手，自动压缩历史对话、删除冗余信息、智能摘要，在保持上下文连贯性的同时降低30-50% Token消耗，专为高用量用户设计。
author: xiaodezi-skills
license: MIT
price: 59
platforms:
  - openclaw
tags:
  - token
  - optimization
  - cost-saving
  - efficiency
---

# 💰 Token 优化助手

> 降低AI对话成本30-50%，保持上下文连贯性

## ✨ 核心功能

- 智能压缩对话历史，删除冗余
- 保留关键信息和决策点
- 实时Token监控
- 智能摘要生成
- 成本节省报告

## 💰 定价

**¥59/月** - 无限制使用

## 📖 使用方法

1. 安装技能
2. 开启Token优化模式
3. 自动后台优化
4. 查看节省报告

---

*让每一分Token都花在刀刃上！*
