#!/usr/bin/env python3
"""
Behavior Logger
记录所有操作行为，用于追溯和审计
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional


class BehaviorLogger:
    """行为日志记录器"""

    def __init__(self, config: dict):
        self.config = config.get("openclaw_rescue", {})
        self.log_dir = Path.home() / ".workbuddy" / "openclaw_rescue"
        self.log_dir.mkdir(parents=True, exist_ok=True)

        self.log_file = self.log_dir / "behavior_log.jsonl"
        self.error_file = self.log_dir / "error_log.jsonl"

    def log(self, entry: dict):
        """
        记录行为条目
        """
        entry["_timestamp"] = datetime.now(timezone.utc).isoformat()
        entry["_type"] = "behavior"

        try:
            with open(self.log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            print(f"Failed to write behavior log: {e}")

    def log_error(self, task_type: str, error: str, context: dict = None):
        """
        记录错误
        """
        entry = {
            "task_type": task_type,
            "error": error,
            "context": context or {},
            "_timestamp": datetime.now(timezone.utc).isoformat(),
            "_type": "error"
        }

        try:
            with open(self.error_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        except Exception as e:
            print(f"Failed to write error log: {e}")

    def get_recent_logs(self, limit: int = 50, log_type: str = "behavior") -> list:
        """
        获取最近的日志
        """
        log_file = self.log_file if log_type == "behavior" else self.error_file

        if not log_file.exists():
            return []

        try:
            entries = []
            with open(log_file, "r", encoding="utf-8") as f:
                for line in f:
                    if line.strip():
                        entries.append(json.loads(line))

            return entries[-limit:]
        except Exception as e:
            print(f"Failed to read logs: {e}")
            return []

    def get_logs_by_task(self, task_type: str, limit: int = 20) -> list:
        """
        按任务类型查询日志
        """
        all_logs = self.get_recent_logs(limit=200)

        filtered = [
            log for log in all_logs
            if log.get("task_type") == task_type
        ]

        return filtered[-limit:]

    def get_error_summary(self) -> dict:
        """
        获取错误摘要
        """
        error_logs = self.get_recent_logs(limit=1000, log_type="error")

        summary = {
            "total_errors": len(error_logs),
            "by_type": {},
            "recent": error_logs[-5:] if error_logs else []
        }

        for log in error_logs:
            task_type = log.get("task_type", "unknown")
            summary["by_type"][task_type] = summary["by_type"].get(task_type, 0) + 1

        return summary

    def export_logs(self, output_path: str, log_type: str = "all", days: int = 7) -> bool:
        """
        导出日志
        """
        try:
            entries = []

            if log_type in ["all", "behavior"]:
                entries.extend(self.get_recent_logs(limit=10000))

            if log_type in ["all", "error"]:
                entries.extend(self.get_recent_logs(limit=10000, log_type="error"))

            # 去重
            seen = set()
            unique_entries = []
            for entry in entries:
                key = entry.get("_timestamp", "")
                if key not in seen:
                    seen.add(key)
                    unique_entries.append(entry)

            # 按时间排序
            unique_entries.sort(key=lambda x: x.get("_timestamp", ""))

            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)

            with open(output_file, "w", encoding="utf-8") as f:
                f.write(json.dumps(unique_entries, ensure_ascii=False, indent=2))

            return True
        except Exception as e:
            print(f"Failed to export logs: {e}")
            return False

    def clear_old_logs(self, days: int = 30) -> dict:
        """
        清理旧日志
        """
        cutoff = datetime.now(timezone.utc).timestamp() - days * 86400
        result = {"deleted": 0, "errors": []}

        for log_file in [self.log_file, self.error_file]:
            if not log_file.exists():
                continue

            try:
                entries = []
                with open(log_file, "r", encoding="utf-8") as f:
                    for line in f:
                        if line.strip():
                            entry = json.loads(line)
                            timestamp = entry.get("_timestamp", "")
                            # 简单解析时间
                            if timestamp:
                                try:
                                    from datetime import datetime
                                    entry_time = datetime.fromisoformat(timestamp.replace("Z", "+00:00"))
                                    if entry_time.timestamp() >= cutoff:
                                        entries.append(entry)
                                except:
                                    entries.append(entry)

                # 重写文件
                with open(log_file, "w", encoding="utf-8") as f:
                    for entry in entries:
                        f.write(json.dumps(entry, ensure_ascii=False) + "\n")

                deleted = len(entries)
                if deleted > 0:
                    result["deleted"] += deleted

            except Exception as e:
                result["errors"].append(str(e))

        return result
