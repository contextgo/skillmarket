#!/usr/bin/env python3
"""
OpenClaw Rescue - Guardian Module
主协调器，调度所有子模块
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path

# 导入子模块
from .token_budget import TokenBudget
from .injection_shield import InjectionShield
from .memory_forcer import MemoryForcer
from .behavior_logger import BehaviorLogger
from .hallucination_checker import HallucinationChecker
from .net_stabilizer import NetStabilizer
from .feedback_generator import FeedbackGenerator


class Guardian:
    """OpenClaw Rescue 主协调器"""

    def __init__(self, config_path: str = None):
        self.config = self._load_config(config_path)
        self.token_budget = TokenBudget(self.config)
        self.injection_shield = InjectionShield(self.config)
        self.memory_forcer = MemoryForcer(self.config)
        self.behavior_logger = BehaviorLogger(self.config)
        self.hallucination_checker = HallucinationChecker(self.config)
        self.net_stabilizer = NetStabilizer(self.config)
        self.feedback_generator = FeedbackGenerator(self.config)

        self.task_log = []

    def _load_config(self, config_path: str = None) -> dict:
        """加载配置文件"""
        if config_path is None:
            config_path = Path(__file__).parent.parent / "references" / "config.yaml"

        # 读取 config.yaml（简化处理，实际用 yaml 库）
        default_config = {
            "openclaw_rescue": {
                "enabled": True,
                "strict_mode": False,
                "token_budget": {
                    "max_per_task": 8000,
                    "max_per_day": 50000,
                    "warning_threshold": 0.8
                },
                "security": {
                    "block_injection": True,
                    "log_suspicious": True,
                    "confirm_sensitive": True
                },
                "memory": {
                    "auto_write": True,
                    "consistency_check": True,
                    "retention_days": 90
                },
                "network": {
                    "search_retry": 3,
                    "stream_timeout": 30,
                    "fallback_engines": ["brave", "duckduckgo", "tavily"]
                },
                "feedback": {
                    "level": "concise",
                    "show_token": True,
                    "show_time": True
                }
            }
        }
        return default_config

    def pre_check(self, user_input: str, context: dict = None) -> dict:
        """任务执行前检查"""
        result = {
            "passed": True,
            "warnings": [],
            "blocks": [],
            "token_estimate": 0,
            "injection_risk": None
        }

        # 1. Token 预算检查
        token_estimate = self.token_budget.estimate(user_input)
        result["token_estimate"] = token_estimate
        token_check = self.token_budget.check_budget(token_estimate)
        if not token_check["passed"]:
            result["passed"] = False
            result["blocks"].append(token_check["reason"])

        # 2. 安全扫描
        injection_result = self.injection_shield.scan_input(user_input)
        result["injection_risk"] = injection_result
        if injection_result["detected"]:
            if self.config["openclaw_rescue"]["security"]["block_injection"]:
                result["passed"] = False
                result["blocks"].append(f"Prompt Injection 检测: {injection_result['pattern']}")
            else:
                result["warnings"].append(f"可疑输入: {injection_result['pattern']}")

        # 3. 记忆召回
        if context:
            recalled = self.memory_forcer.recall(context)
            result["recalled_memories"] = recalled

        return result

    def execute(self, task: dict, user_confirmed: bool = False) -> dict:
        """执行任务并监控"""
        start_time = datetime.now(timezone.utc)

        execute_result = {
            "success": False,
            "output": None,
            "error": None,
            "hallucination_flags": [],
            "token_used": 0
        }

        task_type = task.get("type", "unknown")
        task_content = task.get("content", "")

        # 敏感操作确认
        if self._is_sensitive(task_type) and not user_confirmed:
            execute_result["needs_confirmation"] = True
            execute_result["confirmation_prompt"] = self._generate_confirm_prompt(task)
            return execute_result

        try:
            # 执行网络相关任务时的稳定化
            if task_type in ["search", "api_call", "stream"]:
                result = self.net_stabilizer.execute_with_stabilization(task)
            else:
                # 其他任务直接执行（由 AI 模型本身执行）
                result = {"success": True, "output": task_content}

            execute_result["success"] = result.get("success", False)
            execute_result["output"] = result.get("output")

            # 幻觉检测
            if execute_result["output"]:
                hallu_result = self.hallucination_checker.analyze(execute_result["output"])
                execute_result["hallucination_flags"] = hallu_result["flags"]

            # 记录行为
            self.behavior_logger.log({
                "timestamp": start_time.isoformat(),
                "task_type": task_type,
                "content_summary": task_content[:100],
                "success": execute_result["success"],
                "token_used": execute_result.get("token_used", 0)
            })

        except Exception as e:
            execute_result["error"] = str(e)
            self.behavior_logger.log_error(task_type, str(e))

        execute_result["execution_time"] = (datetime.now(timezone.utc) - start_time).total_seconds()
        return execute_result

    def post_check(self, task_result: dict) -> dict:
        """任务完成后处理"""
        # 强制记忆写入
        if self.config["openclaw_rescue"]["memory"]["auto_write"]:
            self.memory_forcer.write(task_result)

        # 生成反馈
        feedback = self.feedback_generator.generate(task_result)

        return {
            "task_result": task_result,
            "feedback": feedback
        }

    def _is_sensitive(self, task_type: str) -> bool:
        """检查是否敏感操作"""
        confirm_actions = self.config.get("white_list", {}).get("confirm", [])
        return task_type in confirm_actions

    def _generate_confirm_prompt(self, task: dict) -> str:
        """生成确认提示"""
        task_type = task.get("type", "unknown")
        prompts = {
            "send_message": f"确认要发送消息吗？内容：{task.get('content', '')[:50]}...",
            "delete_file": f"确认要删除文件吗？{task.get('target', '')}",
            "execute_command": f"确认要执行命令吗？{task.get('command', '')[:50]}...",
            "api_call": f"确认要调用外部 API 吗？"
        }
        return prompts.get(task_type, f"确认执行这个操作？")

    def report(self, pre_result: dict, execute_result: dict, post_result: dict) -> str:
        """生成最终报告"""
        return self.feedback_generator.format_report(
            pre_result, execute_result, post_result
        )


# 便捷函数
def create_guardian(config_path: str = None) -> Guardian:
    """创建 Guardian 实例"""
    return Guardian(config_path)


def run_with_protection(task: dict, user_input: str, context: dict = None) -> dict:
    """一键运行：检查 + 执行 + 报告"""
    guardian = create_guardian()

    # Pre-check
    pre = guardian.pre_check(user_input, context)
    if not pre["passed"]:
        return {
            "stage": "pre_check",
            "passed": False,
            "blocks": pre["blocks"]
        }

    # Execute
    exec_result = guardian.execute(task)
    if exec_result.get("needs_confirmation"):
        return {
            "stage": "confirmation",
            "passed": True,
            "needs_confirmation": True,
            "prompt": exec_result["confirmation_prompt"]
        }

    # Post-check
    post = guardian.post_check(exec_result)

    # Report
    report = guardian.report(pre, exec_result, post)

    return {
        "stage": "complete",
        "passed": exec_result["success"],
        "report": report,
        "details": {
            "pre": pre,
            "execute": exec_result,
            "post": post
        }
    }
