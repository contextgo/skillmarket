#!/usr/bin/env python3
"""
Net Stabilizer
网络稳定化模块 - 搜索重试、流式输出兜底
"""

import time
import asyncio
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass


@dataclass
class SearchResult:
    """搜索结果"""
    success: bool
    content: str = ""
    error: str = ""
    engine: str = ""
    latency: float = 0.0


class NetStabilizer:
    """网络稳定化控制器"""

    def __init__(self, config: dict):
        self.config = config.get("openclaw_rescue", {}).get("network", {})
        self.max_retries = self.config.get("search_retry", 3)
        self.stream_timeout = self.config.get("stream_timeout", 30)
        self.fallback_engines = self.config.get("fallback_engines", ["brave", "duckduckgo", "tavily"])

        self.engine_map = {
            "brave": self._search_brave,
            "duckduckgo": self._search_duckduckgo,
            "tavily": self._search_tavily,
        }

    async def search_with_retry(self, query: str, engines: List[str] = None) -> SearchResult:
        """
        多引擎搜索，自动重试和降级
        """
        if engines is None:
            engines = self.fallback_engines

        last_error = ""

        for engine in engines:
            if engine not in self.engine_map:
                continue

            for attempt in range(self.max_retries):
                try:
                    start_time = time.time()
                    result = await self.engine_map[engine](query)
                    latency = time.time() - start_time

                    if result.success:
                        result.engine = engine
                        result.latency = latency
                        return result

                    last_error = result.error

                    # 失败后稍等再重试
                    if attempt < self.max_retries - 1:
                        time.sleep(0.5 * (attempt + 1))

                except Exception as e:
                    last_error = str(e)

        # 所有引擎都失败
        return SearchResult(
            success=False,
            error=f"All engines failed. Last error: {last_error}",
            engine="none"
        )

    def execute_with_stabilization(self, task: dict) -> dict:
        """
        执行任务并稳定化
        同步版本，用于通用任务执行
        """
        task_type = task.get("type", "")

        if task_type == "search":
            # 对于搜索，使用重试逻辑
            # 注意：实际搜索由 AI 模型的工具调用执行
            # 这里主要是提供重试策略
            return {"success": True, "stabilization": "search_retry_enabled"}

        elif task_type == "stream":
            # 流式输出，启用超时和重连
            return {"success": True, "stabilization": "stream_fallback_enabled"}

        elif task_type == "api_call":
            # API 调用，启用超时
            return {"success": True, "stabilization": "api_timeout_enabled"}

        else:
            return {"success": True}

    async def _search_brave(self, query: str) -> SearchResult:
        """Brave Search"""
        try:
            # 这里应该调用 Brave Search API
            # 简化实现
            await asyncio.sleep(0.1)  # 模拟网络延迟
            return SearchResult(
                success=True,
                content=f"[Brave] Search results for: {query}",
                engine="brave"
            )
        except Exception as e:
            return SearchResult(success=False, error=str(e), engine="brave")

    async def _search_duckduckgo(self, query: str) -> SearchResult:
        """DuckDuckGo Search"""
        try:
            await asyncio.sleep(0.1)
            return SearchResult(
                success=True,
                content=f"[DuckDuckGo] Search results for: {query}",
                engine="duckduckgo"
            )
        except Exception as e:
            return SearchResult(success=False, error=str(e), engine="duckduckgo")

    async def _search_tavily(self, query: str) -> SearchResult:
        """Tavily AI Search"""
        try:
            await asyncio.sleep(0.1)
            return SearchResult(
                success=True,
                content=f"[Tavily] Search results for: {query}",
                engine="tavily"
            )
        except Exception as e:
            return SearchResult(success=False, error=str(e), engine="tavily")

    def health_check(self) -> Dict:
        """
        网络健康检测
        """
        return {
            "status": "ok",
            "engines_available": list(self.engine_map.keys()),
            "configured_engines": self.fallback_engines,
            "max_retries": self.max_retries,
            "stream_timeout": self.stream_timeout
        }
