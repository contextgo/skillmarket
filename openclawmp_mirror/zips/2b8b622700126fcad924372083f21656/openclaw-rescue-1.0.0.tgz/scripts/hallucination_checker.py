#!/usr/bin/env python3
"""
Hallucination Checker
检测 AI 输出中的幻觉和不可靠陈述
"""

import re
from typing import List, Dict, Tuple
from dataclasses import dataclass


@dataclass
class FactClaim:
    """事实性陈述"""
    text: str
    claim_type: str  # number, date, person, location, organization
    confidence: float  # 0-1
    verified: bool = False


class HallucinationChecker:
    """幻觉检测器"""

    # 事实陈述的正则模式
    FACT_PATTERNS = {
        "number": [
            r"(\d+(?:\.\d+)?)\s*(%|percent|人|次|个|元|美元|人民币|年|月|日)",
            r"(?:大约|约|大概)\s*(\d+(?:\.\d+)?)",
            r"(?:增长|下降|增加|减少)\s*(\d+(?:\.\d+)?)\s*%",
        ],
        "date": [
            r"(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日",
            r"(\d{4})-(\d{2})-(\d{2})",
            r"(?:在|于)\s*(\d{4})\s*年",
        ],
        "person": [
            r"(?:是|为|被称为)\s*([A-Z][a-z]+\s+[A-Z][a-z]+)",
            r"(?:创始人|CEO|总裁|总监|教授|博士)\s*([A-Z][a-z]+)",
        ],
        "location": [
            r"在\s*([A-Z][a-z]+(?:\s+[A-Z][a-z]+)?)\s*(?:的|市|省|国|洲)",
            r"(?:位于|总部在)\s*([A-Z][a-z]+)",
        ],
        "organization": [
            r"(?:公司|企业|机构|组织|大学|医院|医院)\s*([A-Z][A-Za-z]+)",
        ]
    }

    # 不可靠陈述的信号词
    UNCERTAINTY_SIGNALS = [
        "可能", "也许", "大概", "大约", "似乎", "看起来",
        "probably", "maybe", "perhaps", "might", "could be",
        "据说是", "据传", "听说", "有人说",
    ]

    # 高风险陈述信号（需要验证）
    HIGH_RISK_SIGNALS = [
        "据统计", "数据显示", "研究表明", "专家称", "官方表示",
        "confirmed", "officially", "research shows", "studies indicate",
    ]

    def __init__(self, config: dict = None):
        self.config = config or {}

        # 编译正则
        self._compiled_fact_patterns = {}
        for claim_type, patterns in self.FACT_PATTERNS.items():
            self._compiled_fact_patterns[claim_type] = [
                re.compile(p, re.IGNORECASE) for p in patterns
            ]

    def analyze(self, text: str) -> Dict:
        """
        分析文本中的幻觉风险
        """
        if not text:
            return {"flags": [], "fact_claims": [], "risk_score": 0}

        flags = []
        fact_claims = []
        risk_score = 0

        # 1. 提取事实性陈述
        claims = self._extract_fact_claims(text)
        fact_claims.extend(claims)

        # 2. 检测不确定性陈述
        uncertainty_flags = self._detect_uncertainty(text)
        flags.extend(uncertainty_flags)
        risk_score += len(uncertainty_flags) * 0.5

        # 3. 检测高风险陈述
        high_risk_flags = self._detect_high_risk(text)
        flags.extend(high_risk_flags)
        risk_score += len(high_risk_flags) * 2

        # 4. 检测逻辑矛盾
        contradictions = self._detect_contradictions(text)
        flags.extend(contradictions)
        risk_score += len(contradictions) * 3

        # 5. 标记需要验证的事实
        for claim in claims:
            if claim.claim_type in ["number", "date"]:
                flags.append({
                    "type": "unverified_fact",
                    "text": claim.text[:100],
                    "claim_type": claim.claim_type,
                    "confidence": claim.confidence,
                    "suggestion": "建议验证数字/日期准确性"
                })
                risk_score += 1 * (1 - claim.confidence)

        return {
            "flags": flags,
            "fact_claims": [
                {
                    "text": c.text,
                    "type": c.claim_type,
                    "confidence": c.confidence,
                    "verified": c.verified
                }
                for c in fact_claims
            ],
            "risk_score": min(risk_score, 10),  # 最高10分
            "risk_level": self._get_risk_level(risk_score)
        }

    def _extract_fact_claims(self, text: str) -> List[FactClaim]:
        """提取事实性陈述"""
        claims = []

        for claim_type, patterns in self._compiled_fact_patterns.items():
            for pattern in patterns:
                matches = pattern.finditer(text)
                for match in matches:
                    claims.append(FactClaim(
                        text=match.group(0),
                        claim_type=claim_type,
                        confidence=0.7,  # 默认置信度
                        verified=False
                    ))

        return claims

    def _detect_uncertainty(self, text: str) -> List[Dict]:
        """检测不确定性陈述"""
        flags = []

        for signal in self.UNCERTAINTY_SIGNALS:
            if signal.lower() in text.lower():
                # 找到上下文
                idx = text.lower().find(signal.lower())
                context = text[max(0, idx-20):min(len(text), idx+40)]

                flags.append({
                    "type": "uncertainty",
                    "signal": signal,
                    "context": context,
                    "severity": "low",
                    "suggestion": "不确定的陈述，仅供参考"
                })

        return flags

    def _detect_high_risk(self, text: str) -> List[Dict]:
        """检测高风险陈述"""
        flags = []

        for signal in self.HIGH_RISK_SIGNALS:
            if signal.lower() in text.lower():
                idx = text.lower().find(signal.lower())
                context = text[max(0, idx-10):min(len(text), idx+50)]

                flags.append({
                    "type": "high_risk_claim",
                    "signal": signal,
                    "context": context,
                    "severity": "medium",
                    "suggestion": "引用性陈述，建议追查来源"
                })

        return flags

    def _detect_contradictions(self, text: str) -> List[Dict]:
        """检测逻辑矛盾"""
        flags = []

        # 检测数字矛盾（如前文说增长后文说下降）
        growth_words = ["增长", "增加", "上升", "上涨", "增长", "increase", "grow", "rise"]
        decline_words = ["下降", "减少", "下跌", "下滑", "降低", "decrease", "decline", "fall"]

        has_growth = any(w in text.lower() for w in growth_words)
        has_decline = any(w in text.lower() for w in decline_words)

        if has_growth and has_decline:
            flags.append({
                "type": "logical_contradiction",
                "description": "文本同时包含增长和下降描述",
                "severity": "high",
                "suggestion": "检查数字一致性"
            })

        # 检测肯定与否定矛盾
        contradictions = [
            (r"不是.*?是", r"是.*?不是"),
            (r"没有.*?有", r"有.*?没有"),
            (r"不会.*?会", r"会.*?不会"),
        ]

        for pos_pattern, neg_pattern in contradictions:
            pos_matched = re.search(pos_pattern, text)
            neg_matched = re.search(neg_pattern, text)

            if pos_matched and neg_matched:
                # 确保不在同一子句中
                if abs(pos_matched.start() - neg_matched.start()) > 100:
                    flags.append({
                        "type": "assertion_contradiction",
                        "severity": "medium",
                        "suggestion": "检测到肯定与否定并存"
                    })

        return flags

    def _get_risk_level(self, score: float) -> str:
        """根据分数获取风险等级"""
        if score < 2:
            return "low"
        elif score < 5:
            return "medium"
        elif score < 8:
            return "high"
        else:
            return "critical"

    def flag_for_validation(self, claim: str) -> str:
        """
        标记需要验证的内容
        返回带标记的文本
        """
        return f"[⚠️待验证] {claim} [/⚠️]"
