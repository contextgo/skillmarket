#!/usr/bin/env python3
"""
Injection Shield
检测和防御 Prompt Injection 攻击
"""

import re
from typing import List, Dict


class InjectionShield:
    """Prompt Injection 防护盾"""

    # 注入模式库
    INJECTION_PATTERNS = {
        # 指令反转
        "ignore_instructions": [
            r"忽略?(之前|以上|所有|先前)的?(指令|指示|说明|规则|系统)",
            r"(忘记|忘掉)。(指令|系统提示|角色)",
            r"(ignore|forget|p disregard)\s+(previous|above|all|prior)\s+(instructions?|directives?)",
        ],
        # 角色扮演绕过
        "role_play_bypass": [
            r"<\|?(system|ai|human|im_start|im_end)\|>?",
            r"<!\[CDATA\[.*?\]\]>",
            r"{{{(.*?)}}}",
        ],
        # 编码绕过
        "encoding_bypass": [
            r"\\\\[nrt]",
            r"\\x[0-9a-fA-F]{2}",
            r"\\u[0-9a-fA-F]{4}",
            r"base64[:=]",
        ],
        # 分隔符注入
        "delimiter_injection": [
            r"^---+$",
            r"^\.\.\.$",
            r"===\s*User\s*===",
            r"\[SYSTEM\]|\[SYSTEM_MESSAGE\]",
        ],
        # 提示词泄露
        "prompt_leak": [
            r"reveal\s+(your\s+)?(system\s+)?prompt",
            r"(your\s+)?(system\s+)?prompt\s+is",
            r"tell\s+me\s+(your\s+)?(hidden\s+)?instructions?",
        ],
        # 指令覆盖
        "instruction_override": [
            r"你(现在)?是?.*?(专家|assistant|AI)",
            r"(instead|rather)\s+of\s+(what|doing)",
            r"new\s+instruction:\s*",
            r"\#\s*新指令",
        ]
    }

    # 风险关键词
    RISK_KEYWORDS = [
        "密码", "password", "api_key", "secret", "token",
        "sudo", "rm -rf", "del /", "format",
        "eval", "exec", "compile(",
    ]

    def __init__(self, config: dict):
        self.config = config.get("openclaw_rescue", {}).get("security", {})
        self.block_injection = self.config.get("block_injection", True)
        self.log_suspicious = self.config.get("log_suspicious", True)

        # 编译正则
        self._compiled_patterns = {}
        for category, patterns in self.INJECTION_PATTERNS.items():
            self._compiled_patterns[category] = [
                re.compile(p, re.IGNORECASE | re.MULTILINE)
                for p in patterns
            ]

    def scan_input(self, text: str) -> Dict:
        """
        扫描用户输入
        返回检测结果
        """
        if not text:
            return {"detected": False, "patterns": [], "risk_score": 0}

        findings = []
        risk_score = 0

        # 按类别检测
        for category, patterns in self._compiled_patterns.items():
            for pattern in patterns:
                matches = pattern.findall(text)
                if matches:
                    findings.append({
                        "category": category,
                        "pattern": pattern.pattern,
                        "matches": matches[:3],  # 最多记录3个
                        "severity": self._get_severity(category)
                    })
                    risk_score += self._get_severity(category)

        # 风险关键词检查
        for keyword in self.RISK_KEYWORDS:
            if keyword.lower() in text.lower():
                findings.append({
                    "category": "risk_keyword",
                    "keyword": keyword,
                    "severity": 3
                })
                risk_score += 3

        return {
            "detected": len(findings) > 0,
            "patterns": findings,
            "risk_score": risk_score,
            "is_high_risk": risk_score >= 5
        }

    def scan_context(self, text: str) -> Dict:
        """
        扫描上下文（AI 输出或工具返回）
        更关注提示词泄露和异常内容
        """
        # 检测是否有被篡改的迹象
        findings = []

        # 检测是否有异常的系统提示词
        if re.search(r"\[SYSTEM_PROMPT\]:", text):
            findings.append({
                "category": "prompt_leak",
                "location": "context",
                "severity": 4
            })

        # 检测是否有编码内容被植入
        if re.search(r"\\\\x|\\\\u[0-9a-f]", text):
            findings.append({
                "category": "encoding_bypass",
                "location": "context",
                "severity": 3
            })

        return {
            "anomalies": findings,
            "is_safe": len(findings) == 0
        }

    def quarantine(self, text: str) -> str:
        """
        隔离可疑内容
        将检测到的注入片段替换为占位符
        """
        quarantined = text

        for category, patterns in self._compiled_patterns.items():
            for pattern in patterns:
                # 替换为 [BLOCKED: category]
                quarantined = pattern.sub(f"[BLOCKED:{category}]", quarantined)

        return quarantined

    def get_warning_message(self, scan_result: Dict) -> str:
        """生成警告消息"""
        if not scan_result["detected"]:
            return ""

        messages = ["⚠️ 安全警告：检测到可疑输入"]
        for finding in scan_result["patterns"]:
            cat = finding.get("category", "unknown")
            messages.append(f"  - {cat}: {finding.get('pattern', finding.get('keyword', ''))[:50]}")

        return "\n".join(messages)

    def _get_severity(self, category: str) -> int:
        """获取类别严重等级"""
        severity_map = {
            "ignore_instructions": 5,    # 最高危
            "role_play_bypass": 4,
            "encoding_bypass": 3,
            "delimiter_injection": 3,
            "prompt_leak": 4,
            "instruction_override": 4,
            "risk_keyword": 3
        }
        return severity_map.get(category, 2)
