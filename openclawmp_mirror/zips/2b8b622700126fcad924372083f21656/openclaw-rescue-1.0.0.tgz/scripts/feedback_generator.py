#!/usr/bin/env python3
"""
Feedback Generator
生成用户友好的状态反馈
"""

from typing import Dict, Optional
from dataclasses import dataclass


@dataclass
class FeedbackLevel:
    """反馈详细程度"""
    MINIMAL = "minimal"
    CONCISE = "concise"
    DETAILED = "detailed"


class FeedbackGenerator:
    """反馈生成器"""

    def __init__(self, config: dict):
        self.config = config.get("openclaw_rescue", {}).get("feedback", {})
        self.level = self.config.get("level", "concise")
        self.show_token = self.config.get("show_token", True)
        self.show_time = self.config.get("show_time", True)

    def generate(self, task_result: dict) -> str:
        """
        生成单行反馈
        """
        if not task_result.get("success", False):
            return f"❌ 任务失败: {task_result.get('error', '未知错误')}"

        parts = ["✅ 任务完成"]

        if self.show_token and "token_used" in task_result:
            parts.append(f"Token: {task_result['token_used']}")

        if self.show_time and "execution_time" in task_result:
            parts.append(f"耗时: {task_result['execution_time']:.1f}s")

        if task_result.get("hallucination_flags"):
            parts.append(f"⚠️ {len(task_result['hallucination_flags'])} 项待验证")

        return " | ".join(parts)

    def format_report(self, pre_result: dict, execute_result: dict, post_result: dict) -> str:
        """
        格式化完整报告
        """
        lines = []

        # 标题
        lines.append("=" * 40)
        lines.append("OpenClaw Rescue 执行报告")
        lines.append("=" * 40)

        # Pre-check 结果
        if pre_result.get("warnings"):
            lines.append("\n⚠️ 警告:")
            for warning in pre_result["warnings"]:
                lines.append(f"  - {warning}")

        if pre_result.get("injection_risk") and pre_result["injection_risk"].get("detected"):
            lines.append("\n🔒 安全扫描:")
            lines.append(f"  - 检测到可疑输入: {pre_result['injection_risk'].get('pattern', '未知')}")

        # 执行结果
        lines.append("\n📋 执行结果:")
        if execute_result.get("success"):
            lines.append("  ✅ 成功")
        else:
            lines.append(f"  ❌ 失败: {execute_result.get('error', '未知错误')}")

        if self.show_token and "token_used" in execute_result:
            lines.append(f"  📊 Token消耗: {execute_result['token_used']}")

        if self.show_time and "execution_time" in execute_result:
            lines.append(f"  ⏱️ 执行时间: {execute_result['execution_time']:.2f}s")

        # 幻觉检测
        if execute_result.get("hallucination_flags"):
            lines.append(f"\n⚠️ 幻觉风险 ({len(execute_result['hallucination_flags'])}项):")
            for flag in execute_result["hallucination_flags"][:3]:  # 最多显示3个
                lines.append(f"  - [{flag.get('type', 'unknown')}] {flag.get('suggestion', '')}")

        # 反馈
        if post_result.get("feedback"):
            lines.append(f"\n💬 {post_result['feedback']}")

        lines.append("=" * 40)

        return "\n".join(lines)

    def format_confirmation(self, prompt: str, context: dict = None) -> str:
        """
        格式化确认请求
        """
        lines = [
            "⚠️ 需要确认",
            "-" * 20,
            prompt
        ]

        if context:
            lines.append("\n操作详情:")
            for key, value in context.items():
                lines.append(f"  {key}: {value}")

        lines.append("-" * 20)
        lines.append("请确认是否继续 (yes/no)")

        return "\n".join(lines)
