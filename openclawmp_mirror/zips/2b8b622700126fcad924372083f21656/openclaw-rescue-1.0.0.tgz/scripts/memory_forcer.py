#!/usr/bin/env python3
"""
Memory Forcer
强制记忆写入 + 智能召回
"""

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import List, Dict, Optional


class MemoryForcer:
    """强制记忆管理系统"""

    def __init__(self, config: dict):
        self.config = config.get("openclaw_rescue", {}).get("memory", {})
        self.auto_write = self.config.get("auto_write", True)
        self.consistency_check = self.config.get("consistency_check", True)
        self.retention_days = self.config.get("retention_days", 90)

        self.memory_dir = Path.home() / ".workbuddy" / "memory"
        self.memory_dir.mkdir(parents=True, exist_ok=True)

        self.today_file = self.memory_dir / f"{datetime.now(timezone.utc).strftime('%Y-%m-%d')}.md"

    def recall(self, context: dict = None) -> List[Dict]:
        """
        根据上下文召回相关记忆
        """
        if context is None:
            return []

        recalled = []
        context_keywords = self._extract_keywords(context)

        # 读取最近7天的记忆
        for i in range(7):
            date = datetime.now(timezone.utc).timestamp() - i * 86400
            date_str = datetime.fromtimestamp(date, timezone.utc).strftime('%Y-%m-%d')
            mem_file = self.memory_dir / f"{date_str}.md"

            if mem_file.exists():
                try:
                    content = mem_file.read_text(encoding='utf-8')
                    # 简单关键词匹配
                    for keyword in context_keywords:
                        if keyword.lower() in content.lower():
                            recalled.append({
                                "date": date_str,
                                "relevance": keyword,
                                "excerpt": self._extract_excerpt(content, keyword)
                            })
                            break
                except:
                    pass

        return recalled[:10]  # 最多返回10条

    def write(self, task_result: dict) -> bool:
        """
        强制写入记忆
        """
        if not self.auto_write:
            return False

        try:
            entry = self._format_entry(task_result)
            self._append_to_daily(entry)
            self._cleanup_old_entries()
            return True
        except Exception as e:
            print(f"Memory write failed: {e}")
            return False

    def check_consistency(self) -> List[Dict]:
        """
        检查记忆一致性
        返回矛盾条目
        """
        contradictions = []

        # 读取最近记忆
        entries = []
        for i in range(self.retention_days):
            date = datetime.now(timezone.utc).timestamp() - i * 86400
            date_str = datetime.fromtimestamp(date, timezone.utc).strftime('%Y-%m-%d')
            mem_file = self.memory_dir / f"{date_str}.md"

            if mem_file.exists():
                entries.extend(self._parse_memory_file(mem_file))

        # 检查矛盾（简化版：检查同一任务的不同结果）
        task_map = {}
        for entry in entries:
            task_key = entry.get("task", "")[:50]  # 前50字符作为key
            if task_key in task_map:
                prev_result = task_map[task_key]["result"]
                curr_result = entry.get("result")
                if prev_result != curr_result:
                    contradictions.append({
                        "task": task_key,
                        "previous": prev_result,
                        "current": curr_result,
                        "dates": [task_map[task_key]["date"], entry.get("date")]
                    })
            else:
                task_map[task_key] = entry

        return contradictions

    def force_write(self, key_info: List[str], metadata: dict = None) -> bool:
        """
        手动强制写入关键信息
        """
        task_result = {
            "task": "用户手动记忆",
            "result": "写入成功",
            "key_info": key_info,
            "metadata": metadata or {}
        }
        return self.write(task_result)

    def _extract_keywords(self, context: dict) -> List[str]:
        """从上下文提取关键词"""
        keywords = []

        # 从 task 提取
        if "task" in context:
            keywords.extend(context["task"].split()[:5])

        # 从 user_input 提取
        if "user_input" in context:
            keywords.extend(context["user_input"].split()[:5])

        # 过滤短词
        keywords = [k for k in keywords if len(k) >= 2]

        return keywords[:10]

    def _format_entry(self, task_result: dict) -> str:
        """格式化记忆条目"""
        now = datetime.now(timezone.utc)

        entry = f"""
## {now.strftime('%H:%M')} - {task_result.get('task', '未知任务')}

- **结果**: {task_result.get('result', '未知')}
- **Key Info**: {', '.join(task_result.get('key_info', [])) or '无'}
- **Token消耗**: {task_result.get('token_used', 'N/A')}
"""
        if task_result.get("decisions"):
            entry += f"- **决策**: {', '.join(task_result['decisions'])}\n"

        return entry

    def _append_to_daily(self, entry: str):
        """追加到今日记忆文件"""
        if self.today_file.exists():
            existing = self.today_file.read_text(encoding='utf-8')
            # 检查是否已存在相同条目（防重复）
            if entry.strip() not in existing:
                self.today_file.write_text(existing + entry, encoding='utf-8')
        else:
            # 创建新文件
            header = f"""# 记忆日志 - {datetime.now(timezone.utc).strftime('%Y-%m-%d')}

---
"""
            self.today_file.write_text(header + entry, encoding='utf-8')

    def _parse_memory_file(self, mem_file: Path) -> List[Dict]:
        """解析记忆文件"""
        entries = []
        try:
            content = mem_file.read_text(encoding='utf-8')
            # 简单解析 ## 时间 - 任务 格式
            import re
            pattern = r'## (\d{2}:\d{2}) - (.+?)\n(.+?)(?=## |$)'
            matches = re.findall(pattern, content, re.DOTALL)

            for time, task, body in matches:
                entry = {
                    "time": time,
                    "task": task.strip(),
                    "date": mem_file.stem
                }
                # 解析结果
                result_match = re.search(r'\*\*结果\*\*: (.+)', body)
                if result_match:
                    entry["result"] = result_match.group(1).strip()

                entries.append(entry)
        except:
            pass

        return entries

    def _extract_excerpt(self, content: str, keyword: str, context_chars: int = 100) -> str:
        """提取关键词周围的上下文"""
        lower_content = content.lower()
        lower_keyword = keyword.lower()

        idx = lower_content.find(lower_keyword)
        if idx == -1:
            return content[:context_chars]

        start = max(0, idx - context_chars // 2)
        end = min(len(content), idx + len(keyword) + context_chars // 2)

        excerpt = content[start:end]
        if start > 0:
            excerpt = "..." + excerpt
        if end < len(content):
            excerpt = excerpt + "..."

        return excerpt.strip()

    def _cleanup_old_entries(self):
        """清理过期记忆"""
        cutoff = datetime.now(timezone.utc).timestamp() - self.retention_days * 86400

        for mem_file in self.memory_dir.glob("*.md"):
            try:
                mtime = mem_file.stat().st_mtime
                if mtime < cutoff:
                    mem_file.unlink()
            except:
                pass
