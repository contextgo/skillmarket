#!/usr/bin/env python3
"""
Token Budget Controller
Token 预算控制，防止单次任务或单日消耗超限
"""

import os
from datetime import datetime, date
from pathlib import Path


class TokenBudget:
    """Token 预算控制器"""

    # 中文 token 估算比率（粗略）
    CHINESE_RATIO = 2.5  # 1个中文 ≈ 2.5 tokens
    ENGLISH_RATIO = 1.0  # 1个英文 ≈ 1 token

    def __init__(self, config: dict):
        self.config = config.get("openclaw_rescue", {}).get("token_budget", {})
        self.max_per_task = self.config.get("max_per_task", 8000)
        self.max_per_day = self.config.get("max_per_day", 50000)
        self.warning_threshold = self.config.get("warning_threshold", 0.8)

        self._load_daily_usage()

    def _load_daily_usage(self):
        """加载今日使用量"""
        log_dir = Path.home() / ".workbuddy" / "openclaw_rescue"
        log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = log_dir / "token_usage.json"

        if self.log_file.exists():
            try:
                import json
                data = json.loads(self.log_file.read_text())
                today = date.today().isoformat()
                if data.get("date") == today:
                    self.daily_used = data.get("used", 0)
                else:
                    self.daily_used = 0
            except:
                self.daily_used = 0
        else:
            self.daily_used = 0

    def _save_daily_usage(self):
        """保存今日使用量"""
        import json
        self.log_file.write_text(json.dumps({
            "date": date.today().isoformat(),
            "used": self.daily_used
        }))

    def estimate(self, text: str) -> int:
        """
        估算 Token 消耗
        使用粗略字符统计，非精确模型调用量
        """
        chinese_chars = sum(1 for c in text if ord(c) > 127)
        english_chars = len(text) - chinese_chars

        estimated = int(chinese_chars * self.CHINESE_RATIO + english_chars * self.ENGLISH_RATIO)
        return max(estimated, 100)  # 最小估算 100 tokens

    def check_budget(self, estimated: int) -> dict:
        """
        检查预算是否充足
        返回检查结果
        """
        result = {
            "passed": True,
            "reason": None,
            "warnings": []
        }

        # 检查单次任务预算
        if estimated > self.max_per_task:
            result["passed"] = False
            result["reason"] = f"单次任务预估 {estimated} tokens，超过限制 {self.max_per_task}"

        # 检查单日预算
        projected_daily = self.daily_used + estimated
        if projected_daily > self.max_per_day:
            result["passed"] = False
            result["reason"] = f"今日预估 {projected_daily} tokens，超过日限额 {self.max_per_day}"

        # 警告阈值检查
        if result["passed"]:
            if estimated > self.max_per_task * self.warning_threshold:
                result["warnings"].append(f"单次任务消耗较高 ({estimated}/{self.max_per_task})")

            if projected_daily > self.max_per_day * self.warning_threshold:
                result["warnings"].append(f"今日消耗接近限额 ({projected_daily}/{self.max_per_day})")

        return result

    def record_usage(self, actual_tokens: int):
        """记录实际使用量"""
        self.daily_used += actual_tokens
        self._save_daily_usage()

    def get_status(self) -> dict:
        """获取当前预算状态"""
        return {
            "daily_used": self.daily_used,
            "daily_limit": self.max_per_day,
            "daily_remaining": self.max_per_day - self.daily_used,
            "per_task_limit": self.max_per_task
        }
