# Lygo Champion Arkos Celestial Architect

This package was reconstructed from openclawmp asset metadata because the upstream download did not provide a valid zip.
