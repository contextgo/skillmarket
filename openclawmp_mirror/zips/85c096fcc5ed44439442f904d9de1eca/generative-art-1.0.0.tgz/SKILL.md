---
name: generative-art
description: 生成艺术与创意编程工具 — 使用代码生成算法艺术，支持分形、流场、粒子系统、几何图案等多种创意编程模式
---

# 生成艺术与创意编程工具

## 概述

本技能是一个强大的生成艺术与创意编程工具集，帮助用户通过代码创建令人惊叹的算法艺术作品。支持多种编程语言和输出格式，涵盖分形生成、流场可视化、粒子系统、几何图案等创意编程领域。

---

## 核心能力

### 1. 分形艺术生成

分形是数学与艺术的完美结合，本工具支持多种经典分形类型的生成：

#### 1.1 Mandelbrot 集

Mandelbrot 集是最著名的分形之一，通过迭代复数函数 z = z² + c 生成。

```python
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap

def generate_mandelbrot(width=1920, height=1080, x_min=-2.5, x_max=1.0,
                         y_min=-1.25, y_max=1.25, max_iter=256, seed=42):
    """生成 Mandelbrot 集分形图像
    
    参数:
        width: 图像宽度（像素）
        height: 图像高度（像素）
        x_min, x_max: 复平面 X 轴范围
        y_min, y_max: 复平面 Y 轴范围
        max_iter: 最大迭代次数
        seed: 随机种子，用于颜色映射的确定性
    """
    np.random.seed(seed)
    
    # 创建复平面网格
    x = np.linspace(x_min, x_max, width)
    y = np.linspace(y_min, y_max, height)
    X, Y = np.meshgrid(x, y)
    C = X + 1j * Y
    
    # 初始化
    Z = np.zeros_like(C)
    divergence = np.zeros(C.shape, dtype=int)
    
    # 迭代计算
    for i in range(max_iter):
        mask = np.abs(Z) <= 2
        Z[mask] = Z[mask] ** 2 + C[mask]
        divergence[mask] = i
    
    # 归一化并应用颜色映射
    divergence = divergence / max_iter
    
    # 创建自定义颜色映射
    colors = plt.cm.inferno(divergence)
    
    fig, ax = plt.subplots(1, 1, figsize=(19.2, 10.8), dpi=100)
    ax.imshow(colors, extent=[x_min, x_max, y_min, y_max])
    ax.axis('off')
    plt.savefig('mandelbrot.png', bbox_inches='tight', pad_inches=0, dpi=100)
    plt.close()
    
    return divergence

# 使用示例：生成经典 Mandelbrot 集
generate_mandelbrot(max_iter=512, seed=42)

# 使用示例：缩放到特定区域（海马谷）
generate_mandelbrot(x_min=-0.75, x_max=-0.74, y_min=0.1, y_max=0.11,
                    max_iter=1024, seed=123)
```

#### 1.2 Julia 集

Julia 集是 Mandelbrot 集的变体，固定 c 值并迭代 z₀：

```python
def generate_julia(width=1920, height=1080, c=-0.7 + 0.27015j,
                    max_iter=300, seed=42):
    """生成 Julia 集分形图像
    
    参数:
        c: Julia 集的复数常量
        max_iter: 最大迭代次数
        seed: 随机种子
    """
    np.random.seed(seed)
    
    x = np.linspace(-1.5, 1.5, width)
    y = np.linspace(-1.5, 1.5, height)
    X, Y = np.meshgrid(x, y)
    Z = X + 1j * Y
    
    divergence = np.zeros(Z.shape, dtype=float)
    
    for i in range(max_iter):
        mask = np.abs(Z) <= 2
        Z[mask] = Z[mask] ** 2 + c
        divergence += mask
    
    divergence /= max_iter
    
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100)
    ax.imshow(divergence, cmap='magma', extent=[-1.5, 1.5, -1.5, 1.5])
    ax.axis('off')
    plt.savefig('julia_set.png', bbox_inches='tight', pad_inches=0, dpi=100)
    plt.close()
    return divergence

# 经典 Julia 集参数
generate_julia(c=-0.7 + 0.27015j, max_iter=300, seed=42)
generate_julia(c=-0.8 + 0.156j, max_iter=500, seed=88)
generate_julia(c=0.285 + 0.01j, max_iter=400, seed=77)
```

#### 1.3 L-System（林登迈尔系统）

L-System 是一种基于字符串重写规则的分形生成方法：

```python
import turtle

class LSystem:
    """L-System 分形生成器"""
    
    def __init__(self, axiom, rules, angle=25, length=5, iterations=5):
        self.axiom = axiom
        self.rules = rules
        self.angle = angle
        self.length = length
        self.iterations = iterations
    
    def generate(self):
        """生成 L-System 字符串"""
        current = self.axiom
        for _ in range(self.iterations):
            next_str = []
            for char in current:
                next_str.append(self.rules.get(char, char))
            current = ''.join(next_str)
        return current
    
    def draw(self, filename='lsystem.png'):
        """绘制 L-System 分形"""
        import turtle
        t = turtle.Turtle()
        t.speed(0)
        t.hideturtle()
        t.penup()
        t.goto(-400, -300)
        t.pendown()
        
        screen = turtle.Screen()
        screen.setup(1920, 1080)
        screen.bgcolor('black')
        t.pencolor('white')
        
        stack = []
        instructions = self.generate()
        
        for char in instructions:
            if char == 'F':
                t.forward(self.length)
            elif char == '+':
                t.right(self.angle)
            elif char == '-':
                t.left(self.angle)
            elif char == '[':
                stack.append((t.heading(), t.position()))
            elif char == ']':
                heading, position = stack.pop()
                t.penup()
                t.goto(position)
                t.setheading(heading)
                t.pendown()
        
        screen.getcanvas().postscript(file=filename.replace('.png', '.eps'))
        t.getscreen().getcanvas().postscript(file=filename.replace('.png', '.ps'))

# 分形树
tree = LSystem(
    axiom="X",
    rules={"X": "F+[[X]-X]-F[-FX]+X", "F": "FF"},
    angle=25, length=3, iterations=6
)
tree.draw('fractal_tree.png')

# Koch 雪花曲线
koch = LSystem(
    axiom="F--F--F",
    rules={"F": "F+F--F+F"},
    angle=60, length=3, iterations=4
)
koch.draw('koch_snowflake.png')

# Sierpinski 三角
sierpinski = LSystem(
    axiom="F-G-G",
    rules={"F": "F-G+F+G-F", "G": "GG"},
    angle=120, length=3, iterations=6
)
sierpinski.draw('sierpinski.png')

# 龙曲线
dragon = LSystem(
    axiom="FX",
    rules={"X": "X+YF+", "Y": "-FX-Y"},
    angle=90, length=5, iterations=12
)
dragon.draw('dragon_curve.png')

# Hilbert 曲线
hilbert = LSystem(
    axiom="A",
    rules={"A": "-BF+AFA+FB-", "B": "+AF-BFB-FA+"},
    angle=90, length=5, iterations=6
)
hilbert.draw('hilbert_curve.png')
```

---

### 2. 流场与粒子系统

#### 2.1 Perlin Noise 流场

```python
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

class PerlinNoise:
    """简化版 Perlin Noise 实现"""
    
    def __init__(self, seed=42):
        self.seed = seed
        np.random.seed(seed)
        self.permutation = np.arange(256, dtype=int)
        np.random.shuffle(self.permutation)
        self.permutation = np.tile(self.permutation, 2)
    
    def _fade(self, t):
        """平滑插值函数"""
        return t * t * t * (t * (t * 6 - 15) + 10)
    
    def _gradient(self, hash_val, x, y):
        """梯度计算"""
        h = hash_val & 3
        if h == 0: return x + y
        elif h == 1: return -x + y
        elif h == 2: return x - y
        else: return -x - y
    
    def noise(self, x, y):
        """计算 2D Perlin Noise 值"""
        X = int(np.floor(x)) & 255
        Y = int(np.floor(y)) & 255
        x -= np.floor(x)
        y -= np.floor(y)
        
        u = self._fade(x)
        v = self._fade(y)
        
        A = self.permutation[X] + Y
        B = self.permutation[X + 1] + Y
        
        return self._lerp(v,
            self._lerp(u,
                self._gradient(self.permutation[A], x, y),
                self._gradient(self.permutation[B], x - 1, y)),
            self._lerp(u,
                self._gradient(self.permutation[A + 1], x, y - 1),
                self._gradient(self.permutation[B + 1], x - 1, y - 1)))
    
    def _lerp(self, t, a, b):
        return a + t * (b - a)


def generate_flow_field(width=1920, height=1080, scale=0.005,
                         noise_scale=4.0, num_particles=5000, steps=100, seed=42):
    """生成基于 Perlin Noise 的流场可视化
    
    参数:
        width, height: 画布尺寸
        scale: 网格缩放比例
        noise_scale: 噪声缩放
        num_particles: 粒子数量
        steps: 每个粒子的步数
        seed: 随机种子
    """
    np.random.seed(seed)
    perlin = PerlinNoise(seed)
    
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100, facecolor='black')
    ax.set_facecolor('black')
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)
    ax.axis('off')
    
    # 生成调色板
    palette = plt.cm.plasma(np.linspace(0.2, 0.9, num_particles))
    
    # 初始化粒子
    particles_x = np.random.uniform(0, width, num_particles)
    particles_y = np.random.uniform(0, height, num_particles)
    
    for step in range(steps):
        for i in range(num_particles):
            x, y = particles_x[i], particles_y[i]
            
            # 计算噪声角度
            angle = perlin.noise(x * scale, y * scale) * noise_scale * np.pi
            
            # 绘制线段
            dx = np.cos(angle) * 2
            dy = np.sin(angle) * 2
            
            alpha = max(0.1, 1.0 - step / steps)
            ax.plot([x, x + dx], [y, y + dy],
                    color=palette[i], alpha=alpha, linewidth=0.5)
            
            # 更新粒子位置
            particles_x[i] = (x + dx) % width
            particles_y[i] = (y + dy) % height
    
    plt.savefig('flow_field.png', bbox_inches='tight', pad_inches=0,
                facecolor='black', dpi=100)
    plt.close()

generate_flow_field(seed=42)
generate_flow_field(num_particles=8000, steps=150, noise_scale=6.0, seed=88)
```

#### 2.2 粒子系统动画

```python
from PIL import Image, ImageDraw
import math

class ParticleSystem:
    """通用粒子系统"""
    
    def __init__(self, width=1920, height=1080, num_particles=3000, seed=42):
        self.width = width
        self.height = height
        self.num_particles = num_particles
        self.seed = seed
        
        np.random.seed(seed)
        self.particles = {
            'x': np.random.uniform(0, width, num_particles),
            'y': np.random.uniform(0, height, num_particles),
            'vx': np.random.normal(0, 0.5, num_particles),
            'vy': np.random.normal(0, 0.5, num_particles),
            'life': np.random.uniform(0.5, 1.0, num_particles),
            'size': np.random.uniform(1, 3, num_particles),
            'color_hue': np.random.uniform(0, 360, num_particles),
        }
    
    def update(self, force_func=None):
        """更新粒子状态"""
        p = self.particles
        
        if force_func:
            fx, fy = force_func(p['x'], p['y'])
            p['vx'] += fx * 0.01
            p['vy'] += fy * 0.01
        
        # 应用阻尼
        p['vx'] *= 0.99
        p['vy'] *= 0.99
        
        # 速度限制
        speed = np.sqrt(p['vx']**2 + p['vy']**2)
        max_speed = 3.0
        mask = speed > max_speed
        p['vx'][mask] *= max_speed / speed[mask]
        p['vy'][mask] *= max_speed / speed[mask]
        
        # 更新位置
        p['x'] += p['vx']
        p['y'] += p['vy']
        
        # 边界处理（环绕）
        p['x'] = p['x'] % self.width
        p['y'] = p['y'] % self.height
        
        # 衰减生命值
        p['life'] *= 0.999
    
    def render_frame(self, filename='particle_frame.png'):
        """渲染当前帧"""
        img = Image.new('RGB', (self.width, self.height), (10, 10, 15))
        draw = ImageDraw.Draw(img)
        
        for i in range(self.num_particles):
            if self.particles['life'][i] < 0.1:
                continue
            
            x = int(self.particles['x'][i])
            y = int(self.particles['y'][i])
            size = int(self.particles['size'][i])
            hue = self.particles['color_hue'][i]
            life = self.particles['life'][i]
            
            # HSV 转 RGB
            r, g, b = self._hsv_to_rgb(hue / 360.0, 0.8, life)
            color = (int(r * 255), int(g * 255), int(b * 255))
            
            draw.ellipse([x - size, y - size, x + size, y + size], fill=color)
        
        img.save(filename, quality=95)
        return img
    
    @staticmethod
    def _hsv_to_rgb(h, s, v):
        """HSV 到 RGB 颜色转换"""
        if s == 0.0:
            return v, v, v
        i = int(h * 6.0)
        f = (h * 6.0) - i
        p = v * (1.0 - s)
        q = v * (1.0 - s * f)
        t = v * (1.0 - s * (1.0 - f))
        i %= 6
        if i == 0: return v, t, p
        if i == 1: return q, v, p
        if i == 2: return p, v, t
        if i == 3: return p, q, v
        if i == 4: return t, p, v
        return v, p, q


# 引力粒子系统
def gravity_force(x, y):
    """向中心引力"""
    cx, cy = 960, 540
    dx = cx - x
    dy = cy - y
    dist = np.sqrt(dx**2 + dy**2) + 1
    force = 50.0 / dist
    return dx / dist * force, dy / dist * force


def generate_particle_animation(frames=60, seed=42):
    """生成粒子系统动画 GIF"""
    system = ParticleSystem(num_particles=5000, seed=seed)
    images = []
    
    for frame in range(frames):
        system.update(force_func=gravity_force)
        img = system.render_frame(f'frame_{frame:03d}.png')
        images.append(img)
    
    # 保存为 GIF
    images[0].save(
        'particle_animation.gif',
        save_all=True,
        append_images=images[1:],
        duration=50,
        loop=0
    )
    return images

generate_particle_animation(frames=60, seed=42)
```

---

### 3. 几何图案生成器

#### 3.1 螺旋图（Spirograph）

```python
import numpy as np
import matplotlib.pyplot as plt

def generate_spirograph(R=300, r=127, d=200, rotations=50, width=1920, height=1080, seed=42):
    """生成螺旋图（内摆线/外摆线）
    
    参数:
        R: 外圆半径
        r: 内圆半径
        d: 画笔到内圆中心的距离
        rotations: 旋转次数
    """
    np.random.seed(seed)
    
    theta = np.linspace(0, rotations * 2 * np.pi, rotations * 1000)
    
    # 内摆线方程
    x = (R - r) * np.cos(theta) + d * np.cos((R - r) / r * theta)
    y = (R - r) * np.sin(theta) - d * np.sin((R - r) / r * theta)
    
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100, facecolor='#0a0a0f')
    ax.set_facecolor('#0a0a0f')
    ax.axis('off')
    
    # 多层叠加效果
    colors = plt.cm.rainbow(np.linspace(0, 1, len(theta)))
    
    for i in range(len(theta) - 1):
        ax.plot(x[i:i+2], y[i:i+2], color=colors[i], linewidth=0.3, alpha=0.8)
    
    ax.set_xlim(-R * 1.3, R * 1.3)
    ax.set_ylim(-R * 1.1, R * 1.1)
    
    plt.savefig('spirograph.png', bbox_inches='tight', pad_inches=0,
                facecolor='#0a0a0f', dpi=100)
    plt.close()

# 经典螺旋图参数组合
generate_spirograph(R=300, r=127, d=200, rotations=50, seed=42)
generate_spirograph(R=400, r=175, d=250, rotations=80, seed=88)
generate_spirograph(R=250, r=100, d=180, rotations=100, seed=123)

# 多层螺旋图叠加
def generate_multi_spirograph(width=1920, height=1080, seed=42):
    """多层螺旋图叠加"""
    np.random.seed(seed)
    
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100, facecolor='black')
    ax.set_facecolor('black')
    ax.axis('off')
    
    params = [
        (300, 127, 200, 50, 'cyan'),
        (400, 175, 250, 40, 'magenta'),
        (250, 100, 180, 60, 'yellow'),
    ]
    
    for R, r, d, rotations, color in params:
        theta = np.linspace(0, rotations * 2 * np.pi, rotations * 1000)
        x = (R - r) * np.cos(theta) + d * np.cos((R - r) / r * theta)
        y = (R - r) * np.sin(theta) - d * np.sin((R - r) / r * theta)
        ax.plot(x, y, color=color, linewidth=0.3, alpha=0.6)
    
    ax.set_aspect('equal')
    plt.savefig('multi_spirograph.png', bbox_inches='tight', pad_inches=0,
                facecolor='black', dpi=100)
    plt.close()

generate_multi_spirograph(seed=42)
```

#### 3.2 Voronoi 图

```python
from scipy.spatial import Voronoi, voronoi_plot_2d

def generate_voronoi_art(num_points=200, width=1920, height=1080, seed=42):
    """生成 Voronoi 图艺术
    
    参数:
        num_points: 种子点数量
        width, height: 画布尺寸
        seed: 随机种子
    """
    np.random.seed(seed)
    
    # 生成随机种子点
    points = np.random.rand(num_points, 2) * [width, height]
    
    # 计算 Voronoi 图
    vor = Voronoi(points)
    
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100, facecolor='black')
    ax.set_facecolor('black')
    
    # 为每个区域着色
    for i, region_idx in enumerate(vor.point_region):
        region = vor.regions[region_idx]
        if -1 not in region and len(region) > 0:
            polygon = [vor.vertices[v] for v in region]
            hue = i / num_points
            rgb = plt.cm.Set3(hue)
            ax.fill(*zip(*polygon), color=rgb, alpha=0.7)
    
    # 绘制边界
    voronoi_plot_2d(vor, ax=ax, show_points=False, show_vertices=False,
                    line_colors='white', line_width=0.5)
    
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)
    ax.axis('off')
    
    plt.savefig('voronoi_art.png', bbox_inches='tight', pad_inches=0,
                facecolor='black', dpi=100)
    plt.close()

generate_voronoi_art(num_points=150, seed=42)
generate_voronoi_art(num_points=300, seed=88)
```

#### 3.3 镶嵌图案（Tessellation）

```python
def generate_tessellation(pattern_type='hexagonal', width=1920, height=1080,
                           tile_size=40, seed=42):
    """生成镶嵌图案
    
    参数:
        pattern_type: 图案类型 ('hexagonal', 'triangular', 'penrose')
        tile_size: 瓷片大小
        seed: 随机种子
    """
    np.random.seed(seed)
    
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100, facecolor='white')
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)
    ax.axis('off')
    
    if pattern_type == 'hexagonal':
        h = tile_size * np.sqrt(3) / 2
        cols = int(width / (tile_size * 1.5)) + 2
        rows = int(height / h) + 2
        
        for row in range(rows):
            for col in range(cols):
                cx = col * tile_size * 1.5
                cy = row * h + (h / 2 if col % 2 else 0)
                
                # 六边形顶点
                angles = np.linspace(0, 2 * np.pi, 7)[:-1] + np.pi / 6
                hex_x = cx + tile_size * 0.5 * np.cos(angles)
                hex_y = cy + tile_size * 0.5 * np.sin(angles)
                
                color = plt.cm.Set2(np.random.random())
                ax.fill(hex_x, hex_y, color=color, edgecolor='white', linewidth=1)
    
    elif pattern_type == 'triangular':
        side = tile_size
        h = side * np.sqrt(3) / 2
        cols = int(width / (side / 2)) + 2
        rows = int(height / h) + 2
        
        for row in range(rows):
            for col in range(cols):
                cx = col * side / 2
                cy = row * h
                
                # 交替朝上的三角形
                if (row + col) % 2 == 0:
                    points = [(cx, cy), (cx + side, cy), (cx + side/2, cy + h)]
                else:
                    points = [(cx, cy + h), (cx + side, cy + h), (cx + side/2, cy)]
                
                color = plt.cm.tab10(np.random.random() * 10)
                ax.fill(*zip(*points), color=color, edgecolor='white', linewidth=0.5)
    
    plt.savefig(f'tessellation_{pattern_type}.png', bbox_inches='tight',
                pad_inches=0, dpi=100)
    plt.close()

generate_tessellation('hexagonal', tile_size=50, seed=42)
generate_tessellation('triangular', tile_size=40, seed=88)
```

---

### 4. 噪声景观生成

#### 4.1 Simplex Noise 地形

```python
def generate_noise_landscape(width=1920, height=1080, octaves=6,
                              persistence=0.5, lacunarity=2.0, seed=42):
    """使用分形布朗运动（FBM）生成地形景观
    
    参数:
        width, height: 图像尺寸
        octaves: 噪声叠加层数
        persistence: 每层振幅衰减
        lacunarity: 每层频率增加
        seed: 随机种子
    """
    np.random.seed(seed)
    perlin = PerlinNoise(seed)
    
    landscape = np.zeros((height, width))
    
    for octave in range(octaves):
        freq = lacunarity ** octave
        amp = persistence ** octave
        
        for y in range(height):
            for x in range(width):
                nx = x / width * freq * 4
                ny = y / height * freq * 4
                landscape[y, x] += perlin.noise(nx, ny) * amp
    
    # 归一化到 0-1
    landscape = (landscape - landscape.min()) / (landscape.max() - landscape.min())
    
    # 地形着色
    colors = np.zeros((*landscape.shape, 3))
    
    # 水面（蓝色）
    water_mask = landscape < 0.4
    colors[water_mask] = [0.1, 0.3, 0.7]
    
    # 沙滩（黄色）
    sand_mask = (landscape >= 0.4) & (landscape < 0.45)
    colors[sand_mask] = [0.9, 0.8, 0.5]
    
    # 草地（绿色）
    grass_mask = (landscape >= 0.45) & (landscape < 0.7)
    colors[grass_mask] = [0.2, 0.6, 0.2]
    
    # 山地（棕色）
    mountain_mask = (landscape >= 0.7) & (landscape < 0.85)
    colors[mountain_mask] = [0.5, 0.4, 0.3]
    
    # 雪山（白色）
    snow_mask = landscape >= 0.85
    colors[snow_mask] = [0.95, 0.95, 1.0]
    
    # 平滑过渡
    from scipy.ndimage import gaussian_filter
    colors = gaussian_filter(colors, sigma=1.5)
    
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100)
    ax.imshow(colors)
    ax.axis('off')
    plt.savefig('noise_landscape.png', bbox_inches='tight', pad_inches=0, dpi=100)
    plt.close()
    return landscape

generate_noise_landscape(octaves=6, persistence=0.5, seed=42)
```

---

### 5. 颜色理论与调色板生成

```python
def generate_palette(num_colors=5, palette_type='harmonious', seed=42):
    """生成和谐调色板
    
    参数:
        num_colors: 颜色数量
        palette_type: 调色板类型
            - 'harmonious': 和谐色
            - 'complementary': 互补色
            - 'analogous': 类似色
            - 'triadic': 三色组
            - 'split_complementary': 分裂互补色
        seed: 随机种子
    """
    np.random.seed(seed)
    
    base_hue = np.random.random() * 360
    
    if palette_type == 'harmonious':
        hues = np.linspace(base_hue, base_hue + 180, num_colors) % 360
    elif palette_type == 'complementary':
        hues = [base_hue, (base_hue + 180) % 360]
        for _ in range(num_colors - 2):
            hues.append((base_hue + np.random.uniform(-30, 30)) % 360)
    elif palette_type == 'analogous':
        hues = [(base_hue + i * 30) % 360 for i in range(num_colors)]
    elif palette_type == 'triadic':
        hues = [(base_hue + i * 120) % 360 for i in range(3)]
        for _ in range(num_colors - 3):
            hues.append(np.random.choice(hues))
    elif palette_type == 'split_complementary':
        hues = [
            base_hue,
            (base_hue + 150) % 360,
            (base_hue + 210) % 360,
        ]
        for _ in range(num_colors - 3):
            hues.append(np.random.choice(hues))
    
    # 生成饱和度和明度
    saturations = np.random.uniform(0.5, 0.9, num_colors)
    values = np.random.uniform(0.6, 0.95, num_colors)
    
    # 使用 colorsys 转换
    import colorsys
    palette = []
    for h, s, v in zip(hues, saturations, values):
        r, g, b = colorsys.hsv_to_rgb(h / 360, s, v)
        palette.append((r, g, b))
    
    # 可视化调色板
    fig, ax = plt.subplots(figsize=(12, 3), dpi=150)
    ax.set_xlim(0, num_colors)
    ax.set_ylim(0, 1)
    ax.axis('off')
    
    for i, color in enumerate(palette):
        rect = plt.Rectangle((i, 0), 1, 1, facecolor=color)
        ax.add_patch(rect)
        ax.text(i + 0.5, -0.1, f'#{int(color[0]*255):02x}{int(color[1]*255):02x}{int(color[2]*255):02x}',
                ha='center', va='top', fontsize=8)
    
    plt.savefig(f'palette_{palette_type}.png', bbox_inches='tight', dpi=150)
    plt.close()
    
    return palette

# 生成各种类型调色板
generate_palette(palette_type='harmonious', seed=42)
generate_palette(palette_type='complementary', seed=88)
generate_palette(palette_type='analogous', seed=123)
generate_palette(palette_type='triadic', seed=456)
generate_palette(palette_type='split_complementary', seed=789)
```

---

### 6. SVG 输出用于 Web 嵌入

```python
def generate_svg_art(filename='art.svg', width=800, height=600, seed=42):
    """生成 SVG 格式的生成艺术，可直接嵌入网页
    
    参数:
        filename: 输出文件名
        width, height: SVG 尺寸
        seed: 随机种子
    """
    np.random.seed(seed)
    
    svg_parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {width} {height}" '
        f'width="{width}" height="{height}">',
        f'<rect width="{width}" height="{height}" fill="#0a0a0f"/>',
    ]
    
    # 生成同心圆图案
    cx, cy = width // 2, height // 2
    max_radius = min(width, height) // 2
    
    for i in range(200):
        radius = max_radius * (i / 200) ** 0.7
        hue = (i * 1.8 + seed * 10) % 360
        
        offset_x = np.sin(i * 0.1) * 20
        offset_y = np.cos(i * 0.1) * 20
        
        stroke_color = f'hsl({hue}, 80%, 60%)'
        stroke_width = 1.5 + np.sin(i * 0.05) * 0.5
        
        svg_parts.append(
            f'<circle cx="{cx + offset_x}" cy="{cy + offset_y}" '
            f'r="{radius}" fill="none" stroke="{stroke_color}" '
            f'stroke-width="{stroke_width:.2f}" opacity="0.7"/>'
        )
    
    # 添加几何线条
    for i in range(50):
        angle = (i / 50) * 2 * np.pi
        x1 = cx + np.cos(angle) * 50
        y1 = cy + np.sin(angle) * 50
        x2 = cx + np.cos(angle + np.pi/6) * max_radius
        y2 = cy + np.sin(angle + np.pi/6) * max_radius
        
        hue = (i * 7.2) % 360
        svg_parts.append(
            f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" '
            f'stroke="hsl({hue}, 70%, 50%)" stroke-width="0.5" opacity="0.4"/>'
        )
    
    svg_parts.append('</svg>')
    
    with open(filename, 'w') as f:
        f.write('\n'.join(svg_parts))
    
    return filename

generate_svg_art('generative_art.svg', seed=42)
```

---

### 7. HTML Canvas 输出

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>生成艺术 - HTML Canvas</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { background: #0a0a0f; overflow: hidden; }
        canvas { display: block; }
        #controls {
            position: fixed; top: 20px; right: 20px;
            background: rgba(0,0,0,0.7); padding: 15px;
            border-radius: 8px; color: white; font-family: monospace;
            z-index: 10;
        }
        #controls button {
            background: #333; color: white; border: 1px solid #555;
            padding: 5px 10px; margin: 3px; cursor: pointer;
            border-radius: 4px;
        }
        #controls button:hover { background: #555; }
    </style>
</head>
<body>
    <div id="controls">
        <button onclick="changePattern('flow')">流场</button>
        <button onclick="changePattern('spiral')">螺旋</button>
        <button onclick="changePattern('constellation')">星座</button>
        <button onclick="clearCanvas()">清空</button>
    </div>
    <canvas id="artCanvas"></canvas>
    <script>
        const canvas = document.getElementById('artCanvas');
        const ctx = canvas.getContext('2d');
        
        function resize() {
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
        }
        resize();
        window.addEventListener('resize', resize);
        
        // 简化版 Perlin Noise
        class SimplexNoise {
            constructor(seed = 42) {
                this.grad3 = [
                    [1,1,0],[-1,1,0],[1,-1,0],[-1,-1,0],
                    [1,0,1],[-1,0,1],[1,0,-1],[-1,0,-1],
                    [0,1,1],[0,-1,1],[0,1,-1],[0,-1,-1]
                ];
                this.perm = new Array(512);
                const p = new Array(256);
                for (let i = 0; i < 256; i++) p[i] = i;
                // Fisher-Yates shuffle with seed
                let s = seed;
                for (let i = 255; i > 0; i--) {
                    s = (s * 16807) % 2147483647;
                    const j = s % (i + 1);
                    [p[i], p[j]] = [p[j], p[i]];
                }
                for (let i = 0; i < 512; i++) this.perm[i] = p[i & 255];
            }
            
            noise2D(x, y) {
                const F2 = 0.5 * (Math.sqrt(3.0) - 1.0);
                const G2 = (3.0 - Math.sqrt(3.0)) / 6.0;
                
                const s = (x + y) * F2;
                const i = Math.floor(x + s);
                const j = Math.floor(y + s);
                const t = (i + j) * G2;
                
                const X0 = i - t, Y0 = j - t;
                const x0 = x - X0, y0 = y - Y0;
                
                let i1, j1;
                if (x0 > y0) { i1 = 1; j1 = 0; }
                else { i1 = 0; j1 = 1; }
                
                const x1 = x0 - i1 + G2, y1 = y0 - j1 + G2;
                const x2 = x0 - 1.0 + 2.0 * G2, y2 = y0 - 1.0 + 2.0 * G2;
                
                const ii = i & 255, jj = j & 255;
                
                let n0, n1, n2;
                let t0 = 0.5 - x0*x0 - y0*y0;
                if (t0 < 0) n0 = 0;
                else {
                    t0 *= t0;
                    const gi0 = this.perm[ii + this.perm[jj]] % 12;
                    n0 = t0 * t0 * (this.grad3[gi0][0]*x0 + this.grad3[gi0][1]*y0);
                }
                
                let t1 = 0.5 - x1*x1 - y1*y1;
                if (t1 < 0) n1 = 0;
                else {
                    t1 *= t1;
                    const gi1 = this.perm[ii + i1 + this.perm[jj + j1]] % 12;
                    n1 = t1 * t1 * (this.grad3[gi1][0]*x1 + this.grad3[gi1][1]*y1);
                }
                
                let t2 = 0.5 - x2*x2 - y2*y2;
                if (t2 < 0) n2 = 0;
                else {
                    t2 *= t2;
                    const gi2 = this.perm[ii + 1 + this.perm[jj + 1]] % 12;
                    n2 = t2 * t2 * (this.grad3[gi2][0]*x2 + this.grad3[gi2][1]*y2);
                }
                
                return 70.0 * (n0 + n1 + n2);
            }
        }
        
        const noise = new SimplexNoise(42);
        let particles = [];
        let currentPattern = 'flow';
        let animId;
        
        function createParticles(count = 3000) {
            particles = [];
            for (let i = 0; i < count; i++) {
                particles.push({
                    x: Math.random() * canvas.width,
                    y: Math.random() * canvas.height,
                    vx: 0, vy: 0,
                    life: Math.random(),
                    hue: Math.random() * 360,
                    size: Math.random() * 2 + 0.5
                });
            }
        }
        
        function updateFlowField() {
            const time = Date.now() * 0.001;
            const scale = 0.003;
            
            particles.forEach(p => {
                const angle = noise.noise2D(p.x * scale, p.y * scale + time * 0.1) * Math.PI * 4;
                p.vx += Math.cos(angle) * 0.3;
                p.vy += Math.sin(angle) * 0.3;
                p.vx *= 0.95;
                p.vy *= 0.95;
                p.x += p.vx;
                p.y += p.vy;
                
                // 环绕
                if (p.x < 0) p.x = canvas.width;
                if (p.x > canvas.width) p.x = 0;
                if (p.y < 0) p.y = canvas.height;
                if (p.y > canvas.height) p.y = 0;
                
                ctx.fillStyle = `hsla(${(p.hue + time * 10) % 360}, 80%, 60%, 0.15)`;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });
        }
        
        function updateSpiral() {
            const cx = canvas.width / 2;
            const cy = canvas.height / 2;
            const time = Date.now() * 0.0005;
            
            ctx.fillStyle = 'rgba(10, 10, 15, 0.03)';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            
            particles.forEach(p => {
                const dx = p.x - cx;
                const dy = p.y - cy;
                const dist = Math.sqrt(dx * dx + dy * dy);
                const angle = Math.atan2(dy, dx) + 0.02 + (1 / (dist + 50)) * 5;
                
                p.x = cx + Math.cos(angle) * dist;
                p.y = cy + Math.sin(angle) * dist;
                
                const hue = (dist * 0.5 + time * 100) % 360;
                ctx.fillStyle = `hsla(${hue}, 80%, 60%, 0.6)`;
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
                ctx.fill();
            });
        }
        
        function animate() {
            switch(currentPattern) {
                case 'flow':
                    ctx.fillStyle = 'rgba(10, 10, 15, 0.01)';
                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                    updateFlowField();
                    break;
                case 'spiral':
                    updateSpiral();
                    break;
                case 'constellation':
                    updateConstellation();
                    break;
            }
            animId = requestAnimationFrame(animate);
        }
        
        function changePattern(pattern) {
            currentPattern = pattern;
            ctx.fillStyle = '#0a0a0f';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            createParticles();
        }
        
        function clearCanvas() {
            ctx.fillStyle = '#0a0a0f';
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            createParticles();
        }
        
        createParticles();
        animate();
    </script>
</body>
</html>
```

---

### 8. 参数化艺术与种子随机

```python
def parameterized_art(seed=42, style='abstract', complexity=5):
    """参数化艺术生成器
    
    参数:
        seed: 随机种子（相同种子生成相同艺术）
        style: 艺术风格 ('abstract', 'geometric', 'organic', 'cosmic')
        complexity: 复杂度 (1-10)
    """
    np.random.seed(seed)
    perlin = PerlinNoise(seed)
    
    width, height = 1920, 1080
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100, facecolor='#050510')
    ax.set_facecolor('#050510')
    ax.axis('off')
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)
    
    num_elements = complexity * 50
    
    if style == 'abstract':
        for i in range(num_elements):
            x = np.random.uniform(0, width)
            y = np.random.uniform(0, height)
            size = np.random.uniform(10, 200) * (complexity / 5)
            hue = (seed * 37 + i * 7) % 360
            color = plt.cm.hsv(hue / 360)
            
            shape_type = np.random.choice(['circle', 'rect', 'ellipse'])
            alpha = np.random.uniform(0.1, 0.5)
            
            if shape_type == 'circle':
                circle = plt.Circle((x, y), size, color=color, alpha=alpha)
                ax.add_patch(circle)
            elif shape_type == 'rect':
                rect = plt.Rectangle((x - size/2, y - size/2), size, size * np.random.uniform(0.5, 2),
                                      color=color, alpha=alpha, angle=np.random.uniform(0, 360))
                ax.add_patch(rect)
            elif shape_type == 'ellipse':
                ellipse = matplotlib.patches.Ellipse((x, y), size * 2, size,
                                                      angle=np.random.uniform(0, 360),
                                                      color=color, alpha=alpha)
                ax.add_patch(ellipse)
    
    elif style == 'geometric':
        # 基于网格的几何图案
        grid_size = max(5, 50 - complexity * 4)
        for gx in np.arange(0, width, grid_size):
            for gy in np.arange(0, height, grid_size):
                noise_val = perlin.noise(gx * 0.01, gy * 0.01)
                angle = noise_val * np.pi * 2
                size = (noise_val + 1) * grid_size * 0.3
                hue = (noise_val + 1) * 180
                
                color = plt.cm.twilight((hue + seed) % 360 / 360)
                line_x = [gx - np.cos(angle) * size, gx + np.cos(angle) * size]
                line_y = [gy - np.sin(angle) * size, gy + np.sin(angle) * size]
                ax.plot(line_x, line_y, color=color, linewidth=1, alpha=0.8)
    
    elif style == 'organic':
        # 有机形态
        for i in range(num_elements):
            t = np.linspace(0, np.pi * 2 * np.random.uniform(2, 8), 500)
            cx = np.random.uniform(width * 0.2, width * 0.8)
            cy = np.random.uniform(height * 0.2, height * 0.8)
            
            r = 50 + 100 * np.sin(t * np.random.randint(2, 8)) * np.cos(t * np.random.randint(1, 4))
            x = cx + r * np.cos(t)
            y = cy + r * np.sin(t)
            
            hue = (i * 360 / num_elements + seed * 30) % 360
            ax.plot(x, y, color=plt.cm.hsv(hue / 360), linewidth=0.8, alpha=0.6)
    
    elif style == 'cosmic':
        # 宇宙风格
        # 星空背景
        for _ in range(num_elements * 5):
            x = np.random.uniform(0, width)
            y = np.random.uniform(0, height)
            size = np.random.exponential(1)
            alpha = np.random.uniform(0.3, 1.0)
            ax.plot(x, y, '.', color='white', markersize=size, alpha=alpha)
        
        # 星云
        for i in range(complexity * 3):
            cx = np.random.uniform(width * 0.1, width * 0.9)
            cy = np.random.uniform(height * 0.1, height * 0.9)
            size = np.random.uniform(100, 400)
            
            theta = np.linspace(0, 2 * np.pi, 100)
            for r_factor in np.linspace(0.1, 1.0, 20):
                r = size * r_factor
                noise_r = r + perlin.noise(cx * 0.01 + r_factor, cy * 0.01) * 50
                x = cx + noise_r * np.cos(theta)
                y = cy + noise_r * np.sin(theta)
                
                hue = (i * 60 + seed * 20) % 360
                alpha = 0.1 * (1 - r_factor)
                ax.fill(x, y, color=plt.cm.hsv(hue / 360), alpha=alpha)
    
    plt.savefig(f'parametric_{style}_seed{seed}.png',
                bbox_inches='tight', pad_inches=0, facecolor='#050510', dpi=100)
    plt.close()

# 生成不同风格的参数化艺术
for seed in [42, 88, 123, 256, 512]:
    parameterized_art(seed=seed, style='abstract', complexity=7)
    parameterized_art(seed=seed, style='geometric', complexity=5)
    parameterized_art(seed=seed, style='organic', complexity=6)
    parameterized_art(seed=seed, style='cosmic', complexity=8)
```

---

### 9. 导出功能

```python
def export_art(art_func, output_format='png', **kwargs):
    """统一导出接口
    
    参数:
        art_func: 生成艺术的函数
        output_format: 输出格式 ('png', 'svg', 'gif')
        kwargs: 传递给生成函数的参数
    """
    if output_format == 'png':
        result = art_func(**kwargs)
        # 自动保存为 PNG（函数内部处理）
        print(f"已导出为 PNG 格式")
    
    elif output_format == 'svg':
        filename = kwargs.pop('filename', 'art.svg')
        generate_svg_art(filename=filename, **kwargs)
        print(f"已导出为 SVG 格式: {filename}")
    
    elif output_format == 'gif':
        frames = kwargs.get('frames', 30)
        images = []
        for i in range(frames):
            img = art_func(frame=i, **kwargs)
            images.append(img)
        images[0].save('animation.gif', save_all=True,
                       append_images=images[1:], duration=50, loop=0)
        print(f"已导出为 GIF 格式 (共 {frames} 帧)")

# 使用示例
export_art(generate_mandelbrot, 'png', max_iter=256, seed=42)
export_art(generate_svg_art, 'svg', seed=88)
export_art(generate_particle_animation, 'gif', frames=30, seed=123)
```

---

### 10. 创意编程最佳实践

1. **种子确定性**：始终使用随机种子，确保相同参数生成相同结果，便于调试和复现。
2. **参数化设计**：将所有美学参数提取为可调参数，方便探索不同风格。
3. **性能优化**：使用 NumPy 向量化运算代替逐像素循环，大幅提升生成速度。
4. **分层渲染**：将复杂作品分解为多个图层，分别渲染后合成。
5. **颜色空间**：使用 HSV/HSL 颜色空间进行调色，比直接操作 RGB 更直观。
6. **导出多样性**：同时提供位图（PNG）和矢量（SVG）输出，满足不同场景需求。
7. **交互式探索**：提供 HTML Canvas 版本，支持实时参数调节和动画预览。
8. **分辨率自适应**：设计时考虑不同分辨率和长宽比的适配。

---

## 使用指南

当用户请求生成艺术时，按以下步骤操作：

1. **确定风格**：询问用户偏好的艺术风格（分形、流场、几何、抽象等）。
2. **设置参数**：根据用户需求设置尺寸、颜色方案、复杂度等参数。
3. **选择种子**：使用确定性种子确保可复现，同时提供不同种子选项。
4. **生成代码**：根据选定风格提供完整的 Python 代码。
5. **输出格式**：确认用户需要的输出格式（PNG、SVG、GIF、HTML Canvas）。
6. **执行生成**：运行代码并输出结果。
7. **迭代优化**：根据用户反馈调整参数，进行迭代优化。

---

## 常见场景示例

### 场景 1：生成社交媒体头像
```python
# 生成 400x400 的抽象几何艺术头像
parameterized_art(seed=42, style='geometric', complexity=7)
# 调整画布为正方形后重新生成
```

### 场景 2：生成网页背景
```python
# 生成柔和的噪声背景
generate_noise_landscape(width=1920, height=1080, octaves=4, persistence=0.3, seed=42)
# 或生成 SVG 格式
generate_svg_art('background.svg', width=1920, height=1080, seed=42)
```

### 场景 3：生成艺术展览系列
```python
# 使用不同种子生成系列作品
for seed in range(1, 11):
    parameterized_art(seed=seed * 42, style='abstract', complexity=8)
```

### 场景 4：生成 NFT 艺术
```python
# 使用多种参数组合生成唯一艺术品
for i in range(100):
    seed = hash(f"nft_collection_{i}") % 10000
    style = np.random.choice(['abstract', 'geometric', 'cosmic'])
    complexity = np.random.randint(3, 10)
    parameterized_art(seed=seed, style=style, complexity=complexity)
```
