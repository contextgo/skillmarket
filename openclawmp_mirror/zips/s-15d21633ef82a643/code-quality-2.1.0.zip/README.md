> **安全提示**: v2.1.0 已修复以下安全问题：
> - 循环导入风险
> - 数据库孤儿数据问题
> - 命令注入漏洞
> - 数据库连接无限等待问题
> - 日志配置全局污染问题
> 建议所有用户升级到 v2.1.0+

# code-quality 代码质量审查系统

工业级代码质量审查系统，从静态检查清单进化为具备自动化、历史追踪、趋势分析的完整解决方案。

## 核心能力

| 能力 | 说明 |
|------|------|
| **多语言支持** | Python、TypeScript/JavaScript、Go，每种语言有专项检查清单和工具适配器 |
| **自动化检查** | 集成 pylint、mypy、bandit、eslint、tsc、golint、go vet、staticcheck 等工具 |
| **四维度审查** | 正确性、安全性、可维护性、性能 |
| **历史追踪** | SQLite 数据库存储审查历史，支持趋势分析 |
| **趋势仪表盘** | 生成 HTML/Markdown 可视化报告 |
| **CI/CD 集成** | GitHub Actions、GitLab CI 模板 |
| **多格式输出** | Markdown、JSON、SARIF（GitHub Security 兼容） |

## 快速开始

### 1. 基础用法

```python
from scripts.analyzer import CodeQualityAnalyzer
from scripts.database import HistoryDatabase
from scripts.dashboard import DashboardGenerator
from scripts.report import ReportGenerator

# 创建分析器
analyzer = CodeQualityAnalyzer("/path/to/your/project")

# 执行审查
result = analyzer.analyze(depth="standard")

# 生成报告
report_gen = ReportGenerator()
markdown_report = report_gen.generate(result, format="markdown")

# 保存到历史数据库
db = HistoryDatabase()
review_id = db.save_review("/path/to/your/project", result)

# 生成仪表盘
dashboard = DashboardGenerator(db)
html_dashboard = dashboard.generate("/path/to/your/project", format="html")
```

### 2. 项目级配置

在项目根目录创建 `.codequality.yaml`：

```yaml
# 覆盖默认配置
review:
  default_depth: deep
  
dimensions:
  correctness:
    test_coverage:
      threshold: 90  # 提高覆盖率要求
      
  maintainability:
    cyclomatic_complexity:
      threshold: 8   # 更严格的复杂度限制

tools:
  python:
    pylint:
      enabled: true
      disable:
        - "C0103"
```

### 3. CI/CD 集成

**GitHub Actions**：
复制 `templates/github-action.yml` 到 `.github/workflows/code-quality.yml`

**GitLab CI**：
复制 `templates/gitlab-ci.yml` 到项目根目录

## 审查深度

| 深度 | 覆盖维度 | 耗时 | 适用场景 |
|------|---------|------|---------|
| `quick` | 正确性、安全性 | 2-5 分钟 | 单文件修改、紧急修复 |
| `standard` | 四维度全覆盖 | 10-20 分钟 | 功能模块、常规审查 |
| `deep` | 四维度 + 架构影响分析 | 30+ 分钟 | 架构变更、发布前审查 |

## 四维度量化标准

### 正确性

| 检查项 | 阈值 | 说明 |
|--------|------|------|
| 测试覆盖率 | ≥80% | 业界共识的收益拐点 |
| 边界条件覆盖 | 每个公共函数 ≥3 个边界用例 | 空值、极值、类型边界 |
| 错误处理覆盖 | 100% | 每个外部调用必须有错误处理 |
| 类型注解覆盖 | 100% | 公共 API 必须类型注解 |

### 安全性

| 检查项 | 阈值 | 说明 |
|--------|------|------|
| 输入验证 | 100% | 所有用户输入必须验证/转义 |
| 敏感数据 | 零硬编码 | 密钥/密码必须通过环境变量 |
| 依赖安全 | CVSS < 7.0 | 无已知高危漏洞 |
| 权限控制 | 最小权限 | 每个模块只访问职责范围内资源 |

### 可维护性

| 检查项 | 阈值 | 说明 |
|--------|------|------|
| 圈复杂度 | ≤10 | McCabe 建议值 |
| 函数长度 | ≤50 行 | 超过一屏认知负担过高 |
| 文件长度 | ≤400 行 | 超大文件通常职责不清 |
| 重复代码 | 相同逻辑 ≤2 处 | 第三次出现必须抽象 |

### 性能

| 检查项 | 阈值 | 说明 |
|--------|------|------|
| 算法复杂度 | 避免 O(n²)（数据量>1000） | 千级数据时已可感知延迟 |
| 数据库查询 | 零 N+1 查询 | 最常见的性能杀手 |
| 资源释放 | 100% | 所有打开的资源必须关闭 |
| 缓存策略 | 重复计算应有缓存 | 最低成本的性能优化 |

## 语言专项检查

### Python

- **类型注解**：强制公共 API 类型注解，使用 mypy 严格模式
- **异常处理**：优先捕获具体异常，禁止裸 except
- **安全模式**：bandit 扫描，检测 SQL 注入、硬编码密码等
- **性能模式**：检查列表推导式、生成器使用、字符串拼接

### TypeScript

- **严格模式**：启用所有严格类型检查选项
- **异步模式**：优先 async/await，禁止 floating promises
- **React 专项**：检查 hooks 规则、渲染优化
- **安全模式**：XSS 防护、环境变量验证

### Go

- **错误处理**：显式错误检查，禁止丢弃错误
- **Context 传播**：外部调用必须传递 context
- **并发安全**：检查竞态条件、goroutine 泄漏
- **性能模式**：检查内存分配、字符串拼接、切片预分配

## 历史追踪与趋势分析

### 数据库结构

```
projects          → 项目信息
reviews           → 审查记录
metrics           → 指标数据
issues            → 问题详情
```

### 趋势分析

```python
# 获取指标趋势
trend = db.get_metric_trend(
    project_path="/path/to/project",
    metric_name="test_coverage",
    days=30
)

# 对比上次审查
comparison = db.compare_with_previous(
    project_path="/path/to/project",
    current_review_id=review_id
)
```

### 仪表盘

```python
# 生成 HTML 仪表盘
dashboard_html = dashboard.generate(
    project_path="/path/to/project",
    format="html",
    days=30
)

# 生成 Markdown 仪表盘
dashboard_md = dashboard.generate(
    project_path="/path/to/project",
    format="markdown"
)
```

## 输出格式

### Markdown（人类可读）

- 总体评级和发现摘要
- 按严重级别分组的问题列表
- 详细指标数据
- 修复建议

### JSON（机器可读）

```json
{
  "project_path": "/path/to/project",
  "overall_rating": "🟢 通过",
  "dimensions": [...],
  "timestamp": "2026-03-16 10:30:00"
}
```

### SARIF（GitHub Security 兼容）

- 符合 SARIF 2.1.0 标准
- 可在 GitHub Security tab 中查看
- 支持规则定义和结果定位

## 目录结构

```
code-quality/
├── SKILL.md                    # 本文件
├── config/
│   ├── default.yaml           # 默认配置
│   ├── python.yaml            # Python 专项
│   ├── typescript.yaml        # TypeScript 专项
│   └── go.yaml                # Go 专项
├── scripts/
│   ├── analyzer.py            # 核心分析引擎
│   ├── database.py            # 历史追踪数据库
│   ├── dashboard.py           # 趋势仪表盘
│   ├── report.py              # 报告生成器
│   └── tools/                 # 工具适配器
│       ├── base.py
│       ├── pylint_adapter.py
│       ├── mypy_adapter.py
│       └── bandit_adapter.py
├── templates/
│   ├── github-action.yml      # GitHub Actions 模板
│   └── gitlab-ci.yml          # GitLab CI 模板
└── examples/                  # 使用示例
```

## 与其他技能的协作

| 场景 | 协作技能 | 分工 |
|------|---------|------|
| 多文件审查 | multi-agent-collab | 用"开发→测试→审查"三角色模板 |
| 合同中的代码 | contract-review | code-quality 审代码，contract-review 审条款 |
| 项目级审查 | planning-with-files | 用 task_plan.md 跟踪审查进度 |

## 依赖

### 必需依赖
```bash
pip install pyyaml
```

### 可选工具（根据项目类型）

**Python 项目:**
```bash
pip install pylint mypy bandit pytest
```

**TypeScript/JavaScript 项目:**
```bash
npm install -g eslint typescript
```

**Go 项目:**
```bash
go install golang.org/x/lint/golint@latest
go install honnef.co/go/tools/cmd/staticcheck@latest
```

### 安装所有依赖
```bash
pip install -r requirements.txt
```

## 安全特性

- **命令注入防护**: 所有外部命令参数使用 `shlex.quote` 转义
- **路径验证**: 配置文件路径必须在项目目录内
- **数据库安全**: 外键约束带级联删除，防止孤儿数据
- **连接超时**: 数据库连接 30 秒超时，防止无限等待
- **配置深度限制**: 配置合并最大深度 10 层，防止栈溢出
- **安全 YAML 解析**: 使用 `yaml.safe_load` 防止代码执行

## 性能维度检查

v2.1.0 新增性能模式检测，自动识别以下问题：

| 模式 | 说明 | 严重级别 |
|------|------|---------|
| N+1 查询 | 循环内执行数据库查询 | 🔴 HIGH |
| 字符串拼接 | 循环内使用 += 拼接字符串 | 🟡 MEDIUM |
| range(len()) | 使用 range(len()) 而非 enumerate | 🔵 LOW |
| 文件重复读取 | 未缓存的文件读取操作 | 🔵 LOW |

## 配置优先级

配置按以下优先级合并（后覆盖前）：

1. `config/default.yaml` - 全局默认
2. `config/{language}.yaml` - 语言专项
3. `.codequality.yaml` - 项目级
4. 传入的配置参数 - 运行时

## 使用限制

- 自动化工具需要本地安装，未安装时自动跳过
- 历史数据库默认存储在项目 `.codequality/` 目录
- SARIF 输出需要完整的文件路径信息
- 趋势分析需要至少 2 次审查记录

## 升级说明

### 从 v2.0 升级到 v2.1

1. 新增 `scripts/models.py`，所有类型定义迁移至此
2. 修复循环导入问题，适配器现在从 `models` 导入类型
3. 性能维度检查已实现（之前为空）
4. TypeScript 和 Go 工具适配器已添加
5. CI/CD 模板更新为本地脚本执行模式

### 从 v1.0 升级到 v2.0：

1. 新增 `scripts/` 目录，包含自动化引擎
2. 新增 `config/` 目录，支持多语言配置
3. 新增历史追踪功能，自动创建 `.codequality/` 目录
4. 报告格式扩展，支持 JSON 和 SARIF
5. 原有检查清单仍可用，作为静态参考