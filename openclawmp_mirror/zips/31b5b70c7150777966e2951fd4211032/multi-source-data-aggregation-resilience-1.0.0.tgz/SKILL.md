---
name: multi-source-data-aggregation-resilience
description: "Resilient multi-source data aggregation with automatic failover"
version: 1.0.0
---

# multi source data aggregation resilience

A pattern for aggregating data from multiple sources with automatic failover, source quality tracking, and graceful degradation. Designed for prediction market monitoring where data availability directly impacts signal accuracy.

## Source Management

- **Health Tracking**: Track consecutive failures per source with configurable thresholds
- **Automatic Recovery**: Periodic health checks on failed sources
- **Priority Ranking**: Rank sources by reliability and data freshness
- **Network Resilience**: HTTP proxy fallback, DNS pollution detection, timeout handling

## Implementation

Maintain a source registry with health metrics:
- workingSources / failedSources per round
- Recovery events logged when sources come back online
- Minimum viable source count (continue if >= 2/5 sources working)
- Extended outage detection (log when >5 rounds with degraded sources)
