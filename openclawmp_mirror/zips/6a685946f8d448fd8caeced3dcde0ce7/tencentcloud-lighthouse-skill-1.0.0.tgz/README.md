# tencentcloud-lighthouse-skill

**类型**: skill

Manage Tencent Cloud Lighthouse (轻量应用服务器) — auto-setup mcporter + MCP, query instances, monitoring & alerting, self-diagnostics, firewall, snapshots, remote command execution (TAT). Use when user asks about Lighthouse or 轻量应用服务器. NOT for CVM or other cloud server types.

## 快速开始

当用户提到 tencentcloud-lighthouse-skill 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
