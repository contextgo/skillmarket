---
name: feishu-automation-advanced
description: "飞书自动化进阶 - Bitable数据管理、文档操作、消息推送、群组绑定"
version: 1.0.0
tags: ["feishu", "automation", "bitable", "document", "notification"]
---

# 飞书自动化进阶

使用 OpenClaw 飞书插件实现高级自动化的完整方案，涵盖多维表格、文档、消息和群组管理。

## 核心能力

### 1. Bitable (多维表格) 操作

```python
# 获取表格元数据
meta = feishu_bitable_get_meta(url="https://open.feishu.cn/base/xxx?table=yyy")
# 返回: app_token, table_id, table_list

# 列出字段
fields = feishu_bitable_list_fields(app_token, table_id)

# 创建记录
feishu_bitable_create_record(
    app_token=app_token,
    table_id=table_id,
    fields={
        "标题": "任务名称",
        "状态": "进行中",
        "负责人": [{"id": "ou_xxx"}],
        "截止日期": "2026-03-20"
    }
)

# 更新记录
feishu_bitable_update_record(
    app_token=app_token,
    table_id=table_id,
    record_id=record_id,
    fields={"状态": "已完成"}
)
```

### 2. 文档操作

```python
# 创建文档
doc = feishu_doc(action="create", title="日报", content="## 今日工作\n...")

# 读取文档
content = feishu_doc(action="read", doc_token="xxx")

# 追加内容
feishu_doc(action="append", doc_token="xxx", content="\n## 新增内容\n...")

# 创建表格
feishu_doc(action="create_table", doc_token="xxx",
           row_size=5, column_size=3, column_width=[100, 200, 150])

# 写入表格数据
feishu_doc(action="write_table_cells", doc_token="xxx", table_block_id="tbl_xxx",
           values=[["姓名", "得分"], ["张三", "95"]])
```

### 3. 消息推送

```python
# 发送消息
message(action="send",
         channel="feishu",
         target="ou_xxx或chat_id",
         message="📊 今日报告\n- 任务完成度：80%\n- 异常：0个")

# 群聊信息
chat_info = feishu_chat(action="info", chat_id="oc_xxx")
members = feishu_chat(action="members", chat_id="oc_xxx")
```

## 实战场景

### 场景 1：自动日报

```
Cron 触发 → 读取任务状态 → 生成日报 → 写入文档 → 推送群聊
```

### 场景 2：任务跟踪

```
用户发消息 → 创建 Bitable 记录 → 定时检查进度 → 状态更新通知
```

### 场景 3：知识库管理

```python
# 搜索知识库
results = feishu_wiki(action="search", query="关键词")

# 创建知识节点
feishu_wiki(action="create", space_id="wsn_xxx",
            title="新文档", parent_node_token="wk_xxx")
```

## 多账号配置

支持多个飞书 Bot 账号绑定不同群聊：

```yaml
accounts:
  main:       # 主 Bot - 日常助手
  developer:  # 开发 Bot - 技术群
  trader:     # 交易 Bot - 交易群
  content:    # 内容 Bot - 内容群
```

## 注意事项

1. **权限范围**：每个 Bot 需要在飞书管理后台配置权限
2. **消息格式**：支持 Markdown，但飞书渲染有限制
3. **速率限制**：API 调用不要超过 QPS 限制
4. **文档 Token**：从 URL `/docx/xxx` 中提取 `xxx` 部分
