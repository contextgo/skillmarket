---
name: huawei-ppt-generator
description: "华为风格PPT生成技能，适用于汇报、述职、方案、研究和演示文稿输出。触发词：华为PPT、述职PPT、汇报PPT、方案PPT、presentation、slide deck。This skill should be used when a presentation should follow a structured, enterprise-style, clean layout."
version: "1.1.0"
last_updated: "2026-04-15"
---

# Huawei PPT Generator

## 目标
生成结构清晰、商务感强、可直接交付的演示文稿。

## 流程

### Phase 1: Brief Check
- 确认主题、场景、页数和受众
- 明确是否偏汇报、方案或研究

### Phase 2: Outline
- 先定目录，再定每页标题
- 每页只放一个结论点

### Phase 3: Draft
- 填充标题、要点、数据和备注
- 控制文字密度，避免一页塞满

### Phase 4: Polish
- 统一版式、字号、颜色和对齐
- 检查逻辑顺序和视觉节奏

## 失败处理
- 需求不清时先确认
- 数据不足时先补证据
- 结论模糊时先重写标题

## 验收标准
- 页面标题能单独读懂
- 整体风格统一
- 适合正式场合使用
