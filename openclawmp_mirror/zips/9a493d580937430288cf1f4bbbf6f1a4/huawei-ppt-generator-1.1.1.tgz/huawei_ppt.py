from pptx import Presentation
from pptx.util import Pt, Cm
from pptx.dml.color import RGBColor
import os

# 🔥 强制绑定华为规范母版
MASTER_FILE = "~/.openclaw/workspace/huawei_master.pptx"
SAVE_PATH = "~/Desktop/华为企业级PPT.pptx"

# 华为官方固定参数
HUAWEI_RED = RGBColor(0xE0, 0x20, 0x20)
HUAWEI_BLACK = RGBColor(0x00, 0x00, 0x00)
HUAWEI_FONT = "HarmonyOS Sans"

def generate_ppt(ppt_title, pages):
    # 加载华为母版
    prs = Presentation(os.path.expanduser(MASTER_FILE))
    
    # 封面页
    slide = prs.slides.add_slide(prs.slide_layouts[0])
    slide.shapes.title.text = ppt_title
    slide.shapes.title.text_frame.paragraphs[0].font.name = HUAWEI_FONT
    slide.shapes.title.text_frame.paragraphs[0].font.color.rgb = HUAWEI_RED

    # 内容页
    for page in pages:
        slide = prs.slides.add_slide(prs.slide_layouts[1])
        
        # 标题
        title_box = slide.shapes.title
        title_box.text = page["title"]
        title_box.text_frame.paragraphs[0].font.name = HUAWEI_FONT
        title_box.text_frame.paragraphs[0].font.size = Pt(32)
        
        # 正文
        content_box = slide.placeholders[1]
        content_box.text = "\n".join(page["points"])
        for p in content_box.text_frame.paragraphs:
            p.font.name = HUAWEI_FONT
            p.font.size = Pt(24)
            p.font.color.rgb = HUAWEI_BLACK

    prs.save(os.path.expanduser(SAVE_PATH))
    print(f"✅ 华为企业级PPT生成完成：{SAVE_PATH}")