#!/usr/bin/env python3
"""
Bitable Export Skill
将飞书多维表格数据导出为 CSV 或 Excel

直接使用飞书 API，不依赖 OpenClaw 模块。
需要环境变量 FEISHU_APP_TOKEN 或参数提供。
"""

import json
import csv
import sys
import os
import requests
from datetime import datetime
from pathlib import Path

try:
    import openpyxl
    from openpyxl import Workbook
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

def list_records(app_token, table_id, access_token=None):
    """从飞书 API 获取多维表格记录"""
    if not access_token:
        access_token = os.environ.get('FEISHU_ACCESS_TOKEN')
        if not access_token:
            # 尝试从 OpenClaw 配置文件读取
            try:
                with open('/root/.config/openclaw/feishu/token.json') as f:
                    data = json.load(f)
                    access_token = data.get('access_token') or data.get('token')
            except:
                pass

    if not access_token:
        raise Exception("No access token. Set FEISHU_ACCESS_TOKEN or configure OpenClaw feishu skill.")

    url = f"https://open.feishu.cn/open-apis/bitable/v1/apps/{app_token}/tables/{table_id}/records"
    all_records = []
    page_token = None

    while True:
        params = {"page_size": 500}
        if page_token:
            params["page_token"] = page_token

        resp = requests.get(
            url,
            params=params,
            headers={"Authorization": f"Bearer {access_token}"}
        )
        if resp.status_code != 200:
            raise Exception(f"API error: {resp.status_code} {resp.text}")

        data = resp.json()
        items = data.get("data", {}).get("items", [])
        all_records.extend(items)

        page_token = data.get("data", {}).get("page_token")
        if not page_token:
            break

    return {"records": all_records}

def export_csv(records, output_path):
    """导出为 CSV"""
    if not records:
        print("No records to export")
        return False

    field_names = set()
    for record in records:
        field_names.update(record.get('fields', {}).keys())
    field_names = sorted(list(field_names))

    with open(output_path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=field_names)
        writer.writeheader()
        for record in records:
            row = {}
            for field in field_names:
                value = record.get('fields', {}).get(field, '')
                if isinstance(value, (dict, list)):
                    value = json.dumps(value, ensure_ascii=False)
                row[field] = value
            writer.writerow(row)

    print(f"✅ Exported {len(records)} records to {output_path}")
    return True

def export_xlsx(records, output_path):
    """导出为 Excel"""
    if not HAS_OPENPYXL:
        print("Error: openpyxl not installed. Run: pip install openpyxl")
        return False

    if not records:
        print("No records to export")
        return False

    field_names = set()
    for record in records:
        field_names.update(record.get('fields', {}).keys())
    field_names = sorted(list(field_names))

    wb = Workbook()
    ws = wb.active
    ws.title = "Data"
    ws.append(field_names)

    for record in records:
        row = []
        for field in field_names:
            value = record.get('fields', {}).get(field, '')
            if isinstance(value, (dict, list)):
                value = json.dumps(value, ensure_ascii=False)
            row.append(value)
        ws.append(row)

    wb.save(output_path)
    print(f"✅ Exported {len(records)} records to {output_path}")
    return True

def main():
    if len(sys.argv) < 4:
        print("Usage:")
        print("  bitable-export csv <app_token> <table_id> [output.csv]")
        print("  bitable-export xlsx <app_token> <table_id> [output.xlsx]")
        print("\nEnvironment:")
        print("  FEISHU_ACCESS_TOKEN - your Feishu access token")
        sys.exit(1)

    format_type = sys.argv[1]
    app_token = sys.argv[2]
    table_id = sys.argv[3]
    output = sys.argv[4] if len(sys.argv) > 4 else None

    if format_type not in ['csv', 'xlsx']:
        print("Error: format must be 'csv' or 'xlsx'")
        sys.exit(1)

    try:
        print(f"📥 Fetching records from bitable {app_token}/{table_id}...")
        data = list_records(app_token, table_id)
        records = data.get('records', [])

        if not records:
            print("No records found")
            sys.exit(0)

        print(f"📊 Found {len(records)} records")

        if not output:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            ext = 'csv' if format_type == 'csv' else 'xlsx'
            output = f"bitable_export_{timestamp}.{ext}"

        if format_type == 'csv':
            success = export_csv(records, output)
        else:
            success = export_xlsx(records, output)

        if not success:
            sys.exit(1)

    except Exception as e:
        print(f"❌ Error: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
