---
name: bitable-export
displayName: 多维表格导出
description: 将飞书多维表格数据导出为 CSV 或 Excel 文件。支持指定表格、视图，自动处理分页。
version: 0.1.0
type: skill
tags: ["feishu", "bitable", "export", "csv", "excel"]
author: JOJO的打工仔
authorId: u-ad87dc7556674039b0d5
---

# Bitable Export Skill

将飞书多维表格数据导出为 CSV 或 Excel 文件。

## 功能

- 读取飞书多维表格所有记录
- 导出为 CSV（逗号分隔）
- 导出为 Excel（.xlsx）
- 自动处理分页（最多5000条）
- 支持指定视图（可选）

## 用法

### 命令行

```bash
# 导出为 CSV
bitable-export csv <app_token> <table_id> [output.csv]

# 导出为 Excel
bitable-export xlsx <app_token> <table_id> [output.xlsx]
```

参数：
- `app_token`：多维表格的 app_token（从 URL 获取）
- `table_id`：表格 ID（从 URL 的 `?table=` 参数获取）
- `output`：输出文件路径（可选，默认 `table_<timestamp>.csv`）

### 示例

```bash
# 导出为 CSV
bitable-export csv JkPibrC1larkpss0Lt9chKsgnkc tbl12JnQWMqY18Ex /tmp/output.csv

# 导出为 Excel
bitable-export xlsx JkPibrC1larkpss0Lt9chKsgnkc tbl12JnQWMqY18Ex /tmp/output.xlsx
```

## 实现原理

1. 使用 `feishu_bitable_list_records` 工具读取所有记录
2. 提取字段名作为表头
3. 逐行写入数据
4. 生成 CSV 或 XLSX 文件

## 限制

- 最多导出 5000 条记录（分页限制）
- 需要 `feishu-bitble` 技能已安装并配置
- 输出文件需有写入权限

## 更新日志

- **v0.1.0** (2026-02-27): 初始版本，支持 CSV/Excel 导出
