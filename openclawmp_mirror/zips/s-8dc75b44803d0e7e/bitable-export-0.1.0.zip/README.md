# 多维表格导出技能 (bitable-export)

将飞书多维表格数据导出为 CSV 或 Excel 文件。

## 安装

```bash
openclawmp install skill/@u-ad87dc7556674039b0d5/bitable-export
```

## 使用方法

### 导出为 CSV

```bash
bitable-export csv <app_token> <table_id> [output.csv]
```

### 导出为 Excel

```bash
bitable-export xlsx <app_token> <table_id> [output.xlsx]
```

### 示例

```bash
# 导出为 CSV（自动生成文件名）
bitable-export csv JkPibrC1larkpss0Lt9chKsgnkc tbl12JnQWMqY18Ex

# 导出为指定文件
bitable-export xlsx JkPibrC1larkpss0Lt9chKsgnkc tbl12JnQWMqY18Ex /tmp/my_data.xlsx
```

## 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `app_token` | 多维表格的 app_token | `JkPibrC1larkpss0Lt9chKsgnkc` |
| `table_id` | 表格 ID（URL 中 `?table=` 后面的部分） | `tbl12JnQWMqY18Ex` |
| `output` | 输出文件路径（可选） | `/tmp/data.csv` |

## 如何获取 app_token 和 table_id

打开飞书多维表格 URL：
```
https://starrydata.feishu.cn/base/APP_TOKEN?table=TABLE_ID&view=...
```
- `APP_TOKEN` 就是 app_token
- `TABLE_ID` 就是 table_id

## 功能特点

- ✅ 支持 CSV 和 Excel 格式
- ✅ 自动处理分页（最多 5000 条记录）
- ✅ 自动生成表头
- ✅ 支持复杂字段（转为 JSON 字符串）
- ✅ UTF-8 with BOM（Excel 打开不乱码）

## 依赖

- Python 3.x
- openpyxl（Excel 导出需要）
  ```bash
  pip install openpyxl
  ```

## 限制

- 最多导出 5000 条记录（受分页限制）
- 需要 `feishu-bitble` 技能已安装并配置
- 大型表格导出可能需要较长时间

## 更新日志

- **v0.1.0** (2026-02-27): 初始版本

---

**有问题或建议？欢迎反馈！** 🚀
