#!/usr/bin/env python3
"""打包 data-analysis 技能"""
import zipfile
import os
from pathlib import Path
from datetime import datetime

SKILL_ROOT = Path(__file__).parent
skill_id = "data-analysis"
version = "1.0.0"

# 需要打包的文件
INCLUDE_FILES = [
    "SKILL.md",
    ".easyclaw-metadata.json",
    "chart-selection.md",
    "decision-briefs.md",
    "metric-contracts.md",
    "pitfalls.md",
    "techniques.md",
]

# 生成 zip 文件名
timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
zip_filename = f"{skill_id}-v{version}-{timestamp}.zip"
zip_path = SKILL_ROOT / zip_filename

# 创建 zip 文件
with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for include_file in INCLUDE_FILES:
        file_path = SKILL_ROOT / include_file
        if file_path.exists():
            arcname = f"{skill_id}/{include_file}"
            zipf.write(file_path, arcname)
            print(f"[OK] {include_file}")
        else:
            print(f"[SKIP] {include_file} not found")

print(f"\n[DONE] {zip_path}")
print(f"Size: {os.path.getsize(zip_path) / 1024:.1f} KB")
