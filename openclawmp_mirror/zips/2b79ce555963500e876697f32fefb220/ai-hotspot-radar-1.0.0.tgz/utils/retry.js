/**
 * Retry Utility with Exponential Backoff
 * 指数退避重试机制
 */

const ErrorCategory = {
  NETWORK: 'NETWORK',           // 网络错误（可重试）
  TIMEOUT: 'TIMEOUT',           // 超时错误（可重试）
  RATE_LIMIT: 'RATE_LIMIT',     // 限流错误（可重试，需长延迟）
  SERVER: 'SERVER',             // 服务器错误（可重试）
  CLIENT: 'CLIENT',             // 客户端错误（不可重试）
  AUTH: 'AUTH',                 // 认证错误（不可重试）
  NOT_FOUND: 'NOT_FOUND',       // 资源不存在（不可重试）
  UNKNOWN: 'UNKNOWN'            // 未知错误
};

/**
 * 错误分类器
 * @param {Error} error - 错误对象
 * @returns {string} 错误类别
 */
function classifyError(error) {
  if (!error) return ErrorCategory.UNKNOWN;

  const message = (error.message || '').toLowerCase();
  const code = error.code || '';
  const statusCode = error.statusCode || error.status || 0;

  // 网络相关错误
  if (
    code.includes('ECONNREFUSED') ||
    code.includes('ECONNRESET') ||
    code.includes('ETIMEDOUT') ||
    code.includes('ENOTFOUND') ||
    code.includes('EPIPE') ||
    message.includes('network') ||
    message.includes('socket')
  ) {
    return ErrorCategory.NETWORK;
  }

  // 超时错误（排除网络连接超时，那是网络错误）
  if (
    (code.includes('TIMEOUT') && !code.includes('ETIMEDOUT')) ||
    (message.includes('timeout') && !message.includes('connection')) ||
    message.includes('request timeout')
  ) {
    return ErrorCategory.TIMEOUT;
  }

  // HTTP 状态码分类
  if (statusCode) {
    if (statusCode === 429) return ErrorCategory.RATE_LIMIT;
    if (statusCode >= 500) return ErrorCategory.SERVER;
    if (statusCode === 401 || statusCode === 403) return ErrorCategory.AUTH;
    if (statusCode === 404) return ErrorCategory.NOT_FOUND;
    if (statusCode >= 400 && statusCode < 500) return ErrorCategory.CLIENT;
  }

  // Twitter API 特定错误
  if (message.includes('rate limit')) return ErrorCategory.RATE_LIMIT;
  if (message.includes('unauthorized')) return ErrorCategory.AUTH;
  if (message.includes('not found')) return ErrorCategory.NOT_FOUND;

  return ErrorCategory.UNKNOWN;
}

/**
 * 检查错误是否可重试
 * @param {string} category - 错误类别
 * @returns {boolean}
 */
function isRetryable(category) {
  return [
    ErrorCategory.NETWORK,
    ErrorCategory.TIMEOUT,
    ErrorCategory.RATE_LIMIT,
    ErrorCategory.SERVER,
    ErrorCategory.UNKNOWN
  ].includes(category);
}

/**
 * 计算延迟时间（指数退避 + 抖动）
 * @param {number} attempt - 当前尝试次数（从0开始）
 * @param {Object} options - 配置选项
 * @returns {number} 延迟时间（毫秒）
 */
function calculateDelay(attempt, options = {}) {
  const {
    baseDelay = 1000,           // 基础延迟：1秒
    maxDelay = 60000,           // 最大延迟：60秒
    factor = 2,                 // 指数因子
    jitter = true               // 是否添加抖动
  } = options;

  // 指数退避：baseDelay * factor^attempt
  let delay = baseDelay * Math.pow(factor, attempt);

  // 限制最大延迟
  delay = Math.min(delay, maxDelay);

  // 添加随机抖动（±25%）避免惊群效应
  if (jitter) {
    const jitterFactor = 0.75 + Math.random() * 0.5;
    delay = Math.floor(delay * jitterFactor);
  }

  return delay;
}

/**
 * 带重试的异步函数执行器
 * @param {Function} fn - 要执行的异步函数
 * @param {Array} args - 函数参数
 * @param {Object} options - 重试配置
 * @returns {Promise<any>}
 */
async function withRetry(fn, args = [], options = {}) {
  const {
    maxRetries = 3,             // 最大重试次数
    baseDelay = 1000,           // 基础延迟
    maxDelay = 60000,           // 最大延迟
    factor = 2,                 // 指数因子
    jitter = true,              // 抖动
    onRetry = null,             // 重试回调
    shouldRetry = null,         // 自定义重试判断函数
    retryableCategories = null  // 可重试的错误类别
  } = options;

  let lastError;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = await fn(...args);
      
      // 成功时记录日志（如果有重试过）
      if (attempt > 0) {
        console.log(`[Retry] Success after ${attempt} retry(s)`);
      }
      
      return result;
    } catch (error) {
      lastError = error;
      const category = classifyError(error);
      
      // 判断是否应该重试
      let retryable = isRetryable(category);
      
      // 使用自定义重试判断
      if (shouldRetry && typeof shouldRetry === 'function') {
        retryable = shouldRetry(error, category, attempt);
      }

      // 使用自定义可重试类别
      if (retryableCategories && Array.isArray(retryableCategories)) {
        retryable = retryableCategories.includes(category);
      }

      // 最后一次尝试或不可重试的错误
      if (attempt >= maxRetries || !retryable) {
        console.error(`[Retry] Giving up after ${attempt + 1} attempt(s). Category: ${category}`);
        throw error;
      }

      // 计算延迟
      const delay = calculateDelay(attempt, { baseDelay, maxDelay, factor, jitter });

      // 限流错误使用更长的延迟
      const actualDelay = category === ErrorCategory.RATE_LIMIT 
        ? Math.max(delay, 60000)  // 限流至少等待60秒
        : delay;

      console.log(`[Retry] Attempt ${attempt + 1}/${maxRetries + 1} failed (${category}). Retrying in ${actualDelay}ms...`);

      // 调用重试回调
      if (onRetry && typeof onRetry === 'function') {
        onRetry(error, attempt + 1, actualDelay, category);
      }

      // 等待后重试
      await sleep(actualDelay);
    }
  }

  throw lastError;
}

/**
 * 睡眠函数
 * @param {number} ms - 毫秒
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 创建带重试的函数包装器
 * @param {Function} fn - 原始函数
 * @param {Object} options - 重试配置
 * @returns {Function}
 */
function createRetryableFunction(fn, options = {}) {
  return async function(...args) {
    return withRetry(fn, args, options);
  };
}

/**
 * 批量重试执行器 - 带并发控制
 * @param {Array<Function>} tasks - 任务数组
 * @param {Object} options - 配置
 * @returns {Promise<Array>}
 */
async function batchWithRetry(tasks, options = {}) {
  const {
    concurrency = 3,            // 并发数
    maxRetries = 3,
    baseDelay = 1000,
    stopOnError = false         // 遇到错误是否停止
  } = options;

  const results = [];
  const errors = [];
  const executing = [];

  for (let i = 0; i < tasks.length; i++) {
    const task = tasks[i];
    const promise = withRetry(task, [], { maxRetries, baseDelay })
      .then(result => ({ status: 'fulfilled', value: result, index: i }))
      .catch(error => {
        const errorResult = { status: 'rejected', reason: error, index: i };
        if (stopOnError) {
          throw error;
        }
        return errorResult;
      });

    results.push(promise);

    // 并发控制
    if (executing.length >= concurrency) {
      await Promise.race(executing);
    }

    executing.push(promise);
    promise.then(() => {
      const index = executing.indexOf(promise);
      if (index > -1) executing.splice(index, 1);
    });
  }

  const settled = await Promise.all(results);
  
  return settled.map(result => 
    result.status === 'fulfilled' 
      ? result.value 
      : null
  );
}

module.exports = {
  withRetry,
  createRetryableFunction,
  batchWithRetry,
  classifyError,
  isRetryable,
  calculateDelay,
  ErrorCategory,
  sleep
};
