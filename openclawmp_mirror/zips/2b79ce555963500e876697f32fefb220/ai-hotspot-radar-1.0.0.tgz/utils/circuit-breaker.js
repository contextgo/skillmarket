/**
 * Circuit Breaker Pattern Implementation
 * 熔断器模式实现 - 防止级联故障
 */

const CircuitState = {
  CLOSED: 'CLOSED',      // 正常状态 - 请求正常通过
  OPEN: 'OPEN',          // 熔断状态 - 请求直接失败
  HALF_OPEN: 'HALF_OPEN' // 半开状态 - 允许部分请求测试服务是否恢复
};

class CircuitBreaker {
  constructor(options = {}) {
    this.name = options.name || 'default';
    this.failureThreshold = options.failureThreshold || 5;      // 错误阈值：5次
    this.successThreshold = options.successThreshold || 2;      // 成功阈值：连续成功2次恢复
    this.timeout = options.timeout || 300000;                   // 冷却时间：5分钟（毫秒）
    this.monitorInterval = options.monitorInterval || 60000;    // 监控窗口：1分钟

    this.state = CircuitState.CLOSED;
    this.failures = 0;
    this.successes = 0;
    this.lastFailureTime = null;
    this.nextAttempt = Date.now();
    this.errorLog = []; // 错误日志，用于分析

    // 统计信息
    this.stats = {
      totalRequests: 0,
      totalSuccesses: 0,
      totalFailures: 0,
      lastStateChange: null
    };

    // 启动定时清理
    this._startCleanupTimer();
  }

  /**
   * 执行被保护的函数
   * @param {Function} fn - 要执行的异步函数
   * @param {...any} args - 函数参数
   * @returns {Promise<any>}
   */
  async execute(fn, ...args) {
    this.stats.totalRequests++;

    // 检查熔断器状态
    if (this.state === CircuitState.OPEN) {
      if (Date.now() < this.nextAttempt) {
        const remainingTime = Math.ceil((this.nextAttempt - Date.now()) / 1000);
        throw new CircuitBreakerOpenError(
          `Circuit breaker '${this.name}' is OPEN. Retry after ${remainingTime}s`,
          this.getState()
        );
      }
      // 进入半开状态
      this._transitionTo(CircuitState.HALF_OPEN);
    }

    try {
      const result = await fn(...args);
      this._onSuccess();
      this.stats.totalSuccesses++;
      return result;
    } catch (error) {
      this._onFailure(error);
      this.stats.totalFailures++;
      throw error;
    }
  }

  /**
   * 成功回调
   */
  _onSuccess() {
    if (this.state === CircuitState.HALF_OPEN) {
      this.successes++;
      if (this.successes >= this.successThreshold) {
        this._transitionTo(CircuitState.CLOSED);
      }
    } else {
      // 正常状态下，重置失败计数
      this.failures = 0;
    }
  }

  /**
   * 失败回调
   */
  _onFailure(error) {
    this.failures++;
    this.lastFailureTime = Date.now();
    this.nextAttempt = Date.now() + this.timeout;

    // 记录错误
    this.errorLog.push({
      timestamp: new Date().toISOString(),
      error: error.message,
      type: error.name
    });

    // 限制错误日志大小
    if (this.errorLog.length > 50) {
      this.errorLog.shift();
    }

    if (this.state === CircuitState.HALF_OPEN) {
      // 半开状态下失败，立即熔断
      this._transitionTo(CircuitState.OPEN);
    } else if (this.failures >= this.failureThreshold) {
      // 达到错误阈值，熔断
      this._transitionTo(CircuitState.OPEN);
    }
  }

  /**
   * 状态转换
   */
  _transitionTo(newState) {
    const oldState = this.state;
    this.state = newState;
    this.stats.lastStateChange = new Date().toISOString();

    // 重置计数器
    if (newState === CircuitState.CLOSED) {
      this.failures = 0;
      this.successes = 0;
    } else if (newState === CircuitState.HALF_OPEN) {
      this.successes = 0;
    }

    console.log(`[CircuitBreaker:${this.name}] ${oldState} -> ${newState}`);
  }

  /**
   * 启动定时清理器
   */
  _startCleanupTimer() {
    setInterval(() => {
      const now = Date.now();
      // 清理过期的错误记录（超过监控窗口）
      const cutoff = now - this.monitorInterval;
      const oldLength = this.errorLog.length;
      this.errorLog = this.errorLog.filter(log => new Date(log.timestamp).getTime() > cutoff);
      
      // 如果在CLOSED状态且错误日志被清理，重置失败计数
      if (this.state === CircuitState.CLOSED && this.errorLog.length < oldLength) {
        this.failures = this.errorLog.length;
      }
    }, this.monitorInterval);
  }

  /**
   * 获取当前状态
   */
  getState() {
    return {
      name: this.name,
      state: this.state,
      failures: this.failures,
      successes: this.successes,
      failureThreshold: this.failureThreshold,
      successThreshold: this.successThreshold,
      timeout: this.timeout,
      nextAttempt: this.nextAttempt,
      lastFailureTime: this.lastFailureTime,
      stats: this.stats,
      recentErrors: this.errorLog.slice(-5)
    };
  }

  /**
   * 强制重置熔断器
   */
  reset() {
    this.state = CircuitState.CLOSED;
    this.failures = 0;
    this.successes = 0;
    this.errorLog = [];
    this.nextAttempt = Date.now();
    console.log(`[CircuitBreaker:${this.name}] Manually reset to CLOSED`);
  }

  /**
   * 检查是否允许请求
   */
  canExecute() {
    if (this.state === CircuitState.CLOSED) return true;
    if (this.state === CircuitState.HALF_OPEN) return true;
    return Date.now() >= this.nextAttempt;
  }
}

/**
 * 熔断器打开错误
 */
class CircuitBreakerOpenError extends Error {
  constructor(message, circuitState) {
    super(message);
    this.name = 'CircuitBreakerOpenError';
    this.circuitState = circuitState;
  }
}

/**
 * 熔断器管理器 - 管理多个熔断器实例
 */
class CircuitBreakerManager {
  constructor() {
    this.breakers = new Map();
  }

  /**
   * 获取或创建熔断器
   */
  get(name, options = {}) {
    if (!this.breakers.has(name)) {
      this.breakers.set(name, new CircuitBreaker({ name, ...options }));
    }
    return this.breakers.get(name);
  }

  /**
   * 获取所有熔断器状态
   */
  getAllStates() {
    const states = {};
    for (const [name, breaker] of this.breakers) {
      states[name] = breaker.getState();
    }
    return states;
  }

  /**
   * 重置指定熔断器
   */
  reset(name) {
    const breaker = this.breakers.get(name);
    if (breaker) {
      breaker.reset();
    }
  }

  /**
   * 重置所有熔断器
   */
  resetAll() {
    for (const breaker of this.breakers.values()) {
      breaker.reset();
    }
  }
}

// 导出单例管理器
const circuitBreakerManager = new CircuitBreakerManager();

module.exports = {
  CircuitBreaker,
  CircuitBreakerManager,
  CircuitBreakerOpenError,
  CircuitState,
  circuitBreakerManager
};
