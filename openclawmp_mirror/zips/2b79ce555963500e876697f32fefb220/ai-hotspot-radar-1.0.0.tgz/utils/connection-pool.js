/**
 * SQLite Connection Pool
 * SQLite 连接池实现
 * 
 * 注意：SQLite 是文件级锁，真正的并发有限
 * 此连接池主要用于管理多个读连接和一个写连接
 */

const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

class ConnectionPool {
  constructor(dbPath = 'data/hotspots.db', options = {}) {
    this.dbPath = dbPath;
    this.options = {
      maxReadConnections: options.maxReadConnections || 3,    // 最大读连接数
      maxWriteConnections: options.maxWriteConnections || 1,  // 最大写连接数（SQLite限制）
      acquireTimeout: options.acquireTimeout || 5000,         // 获取连接超时（毫秒）
      idleTimeout: options.idleTimeout || 300000,             // 空闲超时（5分钟）
      ...options
    };

    this.readPool = [];       // 读连接池
    this.writePool = [];      // 写连接池
    this.waitingQueue = [];   // 等待队列
    this.isInitialized = false;
    this.stats = {
      totalCreated: 0,
      totalAcquired: 0,
      totalReleased: 0,
      totalWaited: 0,
      currentActive: 0,
      peakActive: 0
    };

    // 确保目录存在
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    this._init();
  }

  /**
   * 初始化连接池
   */
  _init() {
    if (this.isInitialized) return;

    // 创建主连接（用于写操作）
    const mainConnection = this._createConnection();
    this.writePool.push({
      connection: mainConnection,
      inUse: false,
      lastUsed: Date.now(),
      isMain: true
    });

    // 预创建读连接
    for (let i = 0; i < this.options.maxReadConnections; i++) {
      const conn = this._createConnection();
      this.readPool.push({
        connection: conn,
        inUse: false,
        lastUsed: Date.now(),
        isMain: false
      });
    }

    this.isInitialized = true;

    // 启动空闲连接清理定时器
    this._startCleanupTimer();

    console.log(`[ConnectionPool] Initialized with ${this.options.maxReadConnections} read connections`);
  }

  /**
   * 创建数据库连接
   */
  _createConnection() {
    const db = new Database(this.dbPath, { verbose: undefined });
    
    // 启用 WAL 模式
    db.pragma('journal_mode = WAL');
    db.pragma('synchronous = NORMAL');
    db.pragma('cache_size = -20000');
    db.pragma('mmap_size = 268435456');
    db.pragma('temp_store = MEMORY');
    
    this.stats.totalCreated++;
    return db;
  }

  /**
   * 获取连接
   * @param {string} mode - 'read' 或 'write'
 * @returns {Promise<Object>}
   */
  async acquire(mode = 'read') {
    const startTime = Date.now();
    const pool = mode === 'write' ? this.writePool : this.readPool;
    const maxConnections = mode === 'write' 
      ? this.options.maxWriteConnections 
      : this.options.maxReadConnections;

    return new Promise((resolve, reject) => {
      const tryAcquire = () => {
        // 查找空闲连接
        const available = pool.find(conn => !conn.inUse);
        
        if (available) {
          available.inUse = true;
          available.lastUsed = Date.now();
          this.stats.totalAcquired++;
          this.stats.currentActive++;
          this.stats.peakActive = Math.max(this.stats.peakActive, this.stats.currentActive);
          
          const waitTime = Date.now() - startTime;
          if (waitTime > 0) {
            this.stats.totalWaited++;
          }

          resolve({
            connection: available.connection,
            release: () => this._release(available, pool)
          });
          return;
        }

        // 如果没有空闲连接且未达到上限，创建新连接（仅限读模式）
        if (mode === 'read' && pool.length < maxConnections) {
          const newConn = {
            connection: this._createConnection(),
            inUse: true,
            lastUsed: Date.now(),
            isMain: false
          };
          pool.push(newConn);
          this.stats.totalAcquired++;
          this.stats.currentActive++;
          
          resolve({
            connection: newConn.connection,
            release: () => this._release(newConn, pool)
          });
          return;
        }

        // 加入等待队列
        const timeout = setTimeout(() => {
          const index = this.waitingQueue.indexOf(tryAcquire);
          if (index > -1) {
            this.waitingQueue.splice(index, 1);
          }
          reject(new Error(`Connection acquire timeout after ${this.options.acquireTimeout}ms`));
        }, this.options.acquireTimeout);

        this.waitingQueue.push(() => {
          clearTimeout(timeout);
          tryAcquire();
        });
      };

      tryAcquire();
    });
  }

  /**
   * 释放连接
   */
  _release(connectionWrapper, pool) {
    connectionWrapper.inUse = false;
    connectionWrapper.lastUsed = Date.now();
    this.stats.totalReleased++;
    this.stats.currentActive--;

    // 通知等待队列
    if (this.waitingQueue.length > 0) {
      const next = this.waitingQueue.shift();
      next();
    }
  }

  /**
   * 执行查询（读操作）
   * @param {string} sql - SQL语句
   * @param {Array} params - 参数
   * @returns {Promise<any>}
   */
  async query(sql, params = []) {
    const { connection, release } = await this.acquire('read');
    try {
      const stmt = connection.prepare(sql);
      return stmt.all(...params);
    } finally {
      release();
    }
  }

  /**
   * 执行单个查询（读操作）
   * @param {string} sql - SQL语句
   * @param {Array} params - 参数
   * @returns {Promise<any>}
   */
  async get(sql, params = []) {
    const { connection, release } = await this.acquire('read');
    try {
      const stmt = connection.prepare(sql);
      return stmt.get(...params);
    } finally {
      release();
    }
  }

  /**
   * 执行更新（写操作）
   * @param {string} sql - SQL语句
   * @param {Array} params - 参数
   * @returns {Promise<any>}
   */
  async run(sql, params = []) {
    const { connection, release } = await this.acquire('write');
    try {
      const stmt = connection.prepare(sql);
      return stmt.run(...params);
    } finally {
      release();
    }
  }

  /**
   * 事务执行
   * @param {Function} fn - 事务函数
   * @returns {Promise<any>}
   */
  async transaction(fn) {
    const { connection, release } = await this.acquire('write');
    try {
      const transaction = connection.transaction(fn);
      return transaction();
    } finally {
      release();
    }
  }

  /**
   * 启动清理定时器
   */
  _startCleanupTimer() {
    setInterval(() => {
      const now = Date.now();
      const idleTimeout = this.options.idleTimeout;

      // 清理读连接池中的空闲超时连接（保留至少1个）
      const initialReadCount = this.readPool.length;
      this.readPool = this.readPool.filter((conn, index) => {
        // 保留至少一个连接
        if (index === 0) return true;
        
        // 关闭超时且未使用的连接
        if (!conn.inUse && (now - conn.lastUsed) > idleTimeout) {
          try {
            conn.connection.close();
          } catch (e) {
            console.error('[ConnectionPool] Error closing connection:', e.message);
          }
          return false;
        }
        return true;
      });

      const closedCount = initialReadCount - this.readPool.length;
      if (closedCount > 0) {
        console.log(`[ConnectionPool] Closed ${closedCount} idle connections`);
      }
    }, 60000); // 每分钟检查一次
  }

  /**
   * 获取统计信息
   */
  getStats() {
    return {
      ...this.stats,
      readPoolSize: this.readPool.length,
      writePoolSize: this.writePool.length,
      activeReadConnections: this.readPool.filter(c => c.inUse).length,
      activeWriteConnections: this.writePool.filter(c => c.inUse).length,
      waitingQueueLength: this.waitingQueue.length
    };
  }

  /**
   * 关闭连接池
   */
  close() {
    console.log('[ConnectionPool] Closing all connections...');
    
    // 关闭所有连接
    [...this.readPool, ...this.writePool].forEach(conn => {
      try {
        conn.connection.close();
      } catch (e) {
        console.error('[ConnectionPool] Error closing connection:', e.message);
      }
    });

    this.readPool = [];
    this.writePool = [];
    this.isInitialized = false;
    
    console.log('[ConnectionPool] All connections closed');
  }
}

// 单例模式
let defaultPool = null;

function getConnectionPool(dbPath, options) {
  if (!defaultPool) {
    defaultPool = new ConnectionPool(dbPath, options);
  }
  return defaultPool;
}

module.exports = {
  ConnectionPool,
  getConnectionPool
};
