/**
 * Health Monitor
 * 系统健康监控模块
 * 
 * 监控项：
 * - 熔断器状态
 * - 数据库连接池状态
 * - API 错误率
 * - 系统资源使用情况
 */

const { circuitBreakerManager } = require('./circuit-breaker');
const os = require('os');

class HealthMonitor {
  constructor(options = {}) {
    this.options = {
      checkInterval: options.checkInterval || 60000,  // 默认1分钟检查一次
      alertThreshold: options.alertThreshold || {
        errorRate: 0.1,      // 错误率超过10%告警
        responseTime: 5000,  // 响应时间超过5秒告警
        cpuUsage: 80,        // CPU使用率超过80%告警
        memoryUsage: 85      // 内存使用率超过85%告警
      },
      ...options
    };

    this.metrics = {
      requests: { total: 0, success: 0, failed: 0 },
      responseTimes: [],
      errors: new Map(),
      startTime: Date.now()
    };

    this.isRunning = false;
    this.checkTimer = null;
  }

  /**
   * 启动监控
   */
  start() {
    if (this.isRunning) return;
    
    this.isRunning = true;
    console.log('[HealthMonitor] Started monitoring');
    
    this.checkTimer = setInterval(() => {
      this._performHealthCheck();
    }, this.options.checkInterval);
  }

  /**
   * 停止监控
   */
  stop() {
    if (!this.isRunning) return;
    
    this.isRunning = false;
    if (this.checkTimer) {
      clearInterval(this.checkTimer);
      this.checkTimer = null;
    }
    console.log('[HealthMonitor] Stopped monitoring');
  }

  /**
   * 执行健康检查
   */
  _performHealthCheck() {
    const report = this.generateReport();
    
    // 检查告警阈值
    const alerts = this._checkAlerts(report);
    
    if (alerts.length > 0) {
      console.warn('[HealthMonitor] Alerts:', alerts);
    }

    // 定期输出健康报告（每5次检查输出一次）
    if (this.metrics.requests.total % 5 === 0) {
      console.log('[HealthMonitor] Health check:', JSON.stringify(report.summary, null, 2));
    }
  }

  /**
   * 检查告警
   */
  _checkAlerts(report) {
    const alerts = [];
    const { errorRate, avgResponseTime, cpuUsage, memoryUsage } = report.summary;
    const { alertThreshold } = this.options;

    if (errorRate > alertThreshold.errorRate) {
      alerts.push({
        type: 'ERROR_RATE_HIGH',
        message: `Error rate ${(errorRate * 100).toFixed(2)}% exceeds threshold ${(alertThreshold.errorRate * 100).toFixed(2)}%`,
        severity: 'warning'
      });
    }

    if (avgResponseTime > alertThreshold.responseTime) {
      alerts.push({
        type: 'RESPONSE_TIME_HIGH',
        message: `Average response time ${avgResponseTime}ms exceeds threshold ${alertThreshold.responseTime}ms`,
        severity: 'warning'
      });
    }

    if (cpuUsage > alertThreshold.cpuUsage) {
      alerts.push({
        type: 'CPU_USAGE_HIGH',
        message: `CPU usage ${cpuUsage.toFixed(2)}% exceeds threshold ${alertThreshold.cpuUsage}%`,
        severity: 'critical'
      });
    }

    if (memoryUsage > alertThreshold.memoryUsage) {
      alerts.push({
        type: 'MEMORY_USAGE_HIGH',
        message: `Memory usage ${memoryUsage.toFixed(2)}% exceeds threshold ${alertThreshold.memoryUsage}%`,
        severity: 'critical'
      });
    }

    // 检查熔断器状态
    const circuitStates = circuitBreakerManager.getAllStates();
    for (const [name, state] of Object.entries(circuitStates)) {
      if (state.state === 'OPEN') {
        alerts.push({
          type: 'CIRCUIT_BREAKER_OPEN',
          message: `Circuit breaker '${name}' is OPEN`,
          severity: 'critical',
          details: state
        });
      }
    }

    return alerts;
  }

  /**
   * 记录请求
   */
  recordRequest(success, responseTime, error = null) {
    this.metrics.requests.total++;
    
    if (success) {
      this.metrics.requests.success++;
    } else {
      this.metrics.requests.failed++;
    }

    // 记录响应时间（保留最近100个）
    this.metrics.responseTimes.push(responseTime);
    if (this.metrics.responseTimes.length > 100) {
      this.metrics.responseTimes.shift();
    }

    // 记录错误
    if (error) {
      const errorType = error.name || error.code || 'UNKNOWN';
      const current = this.metrics.errors.get(errorType) || 0;
      this.metrics.errors.set(errorType, current + 1);
    }
  }

  /**
   * 生成健康报告
   */
  generateReport() {
    const { total, success, failed } = this.metrics.requests;
    const errorRate = total > 0 ? failed / total : 0;
    
    const responseTimes = this.metrics.responseTimes;
    const avgResponseTime = responseTimes.length > 0 
      ? responseTimes.reduce((a, b) => a + b, 0) / responseTimes.length 
      : 0;

    // 系统资源
    const cpuUsage = os.loadavg()[0] * 100 / os.cpus().length;
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const memoryUsage = ((totalMemory - freeMemory) / totalMemory) * 100;

    // 熔断器状态
    const circuitStates = circuitBreakerManager.getAllStates();

    // 错误统计
    const errorStats = {};
    for (const [type, count] of this.metrics.errors) {
      errorStats[type] = count;
    }

    const uptime = Date.now() - this.metrics.startTime;

    return {
      timestamp: new Date().toISOString(),
      summary: {
        uptime: Math.floor(uptime / 1000),
        totalRequests: total,
        successRate: total > 0 ? (success / total * 100).toFixed(2) + '%' : 'N/A',
        errorRate: errorRate,
        avgResponseTime: Math.round(avgResponseTime),
        cpuUsage: cpuUsage,
        memoryUsage: memoryUsage
      },
      circuitBreakers: circuitStates,
      errors: errorStats,
      system: {
        platform: os.platform(),
        arch: os.arch(),
        nodeVersion: process.version,
        pid: process.pid,
        memory: {
          total: Math.round(totalMemory / 1024 / 1024) + 'MB',
          free: Math.round(freeMemory / 1024 / 1024) + 'MB',
          used: Math.round((totalMemory - freeMemory) / 1024 / 1024) + 'MB',
          usage: memoryUsage.toFixed(2) + '%'
        }
      }
    };
  }

  /**
   * 获取熔断器状态
   */
  getCircuitBreakerStatus() {
    return circuitBreakerManager.getAllStates();
  }

  /**
   * 重置熔断器
   */
  resetCircuitBreaker(name) {
    circuitBreakerManager.reset(name);
  }

  /**
   * 重置所有熔断器
   */
  resetAllCircuitBreakers() {
    circuitBreakerManager.resetAll();
  }

  /**
   * 重置指标
   */
  resetMetrics() {
    this.metrics = {
      requests: { total: 0, success: 0, failed: 0 },
      responseTimes: [],
      errors: new Map(),
      startTime: Date.now()
    };
  }
}

// 单例模式
let defaultMonitor = null;

function getHealthMonitor(options) {
  if (!defaultMonitor) {
    defaultMonitor = new HealthMonitor(options);
  }
  return defaultMonitor;
}

module.exports = {
  HealthMonitor,
  getHealthMonitor
};
