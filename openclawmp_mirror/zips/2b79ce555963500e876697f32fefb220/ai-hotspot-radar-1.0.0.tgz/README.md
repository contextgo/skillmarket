# AI Hotspot Crawler

一个基于 OpenClaw Agent Skill 的多平台热点抓取与智能评分系统。

## ✨ 特性

- **多平台接入**：Twitter/X, Reddit, Hacker News, Product Hunt, LinkedIn, 微博, 小红书, 即刻, 掘金, V2EX
- **像素风 UI**：复古 8-bit 风格 Web 界面
- **热度评分系统**：AI 自动评分 + 人类反馈迭代
- **实时热力图**：Canvas 渲染的像素热力分布
- **可扩展架构**：模块化平台适配器，轻松添加新平台

## 📦 项目结构

```
hotspot-crawler-project/
├── src/
│   ├── server.js          # Express 服务器 + 定时任务
│   ├── platforms/         # 平台适配器
│   │   └── index.js       # 各平台抓取逻辑
│   ├── scorers/           # 评分系统
│   │   └── index.js       # AI评分 + 反馈迭代
│   ├── storage/           # 数据存储
│   │   └── index.js       # SQLite 操作封装
│   └── public/            # 前端静态资源
│       └── index.html     # 像素风 UI
├── data/                  # SQLite 数据库文件（自动生成）
├── package.json
└── .env.example
```

## 🚀 快速开始

### 1. 安装依赖

```bash
cd hotspot-crawler-project
npm install
```

### 2. 配置环境变量

```bash
cp .env.example .env
# 编辑 .env 文件，根据需要调整配置
```

### 3. 启动服务

```bash
npm start
```

访问 `http://localhost:3000` 查看像素风界面。

## 🔧 配置说明

### 监控账号

编辑 `src/server.js` 中的 `watchedAccounts` 对象，添加需要监控的账号：

```js
const watchedAccounts = {
  twitter: ['elonmusk', 'sama'],
  reddit: ['programming', 'technology'],
  weibo: ['1689123456'], // 微博UID
  xiaohongshu: ['user_id'],
  // ...
};
```

### RSSHub 实例

默认使用公共 RSSHub (https://rsshub.app)。若需加速或自定义，可在 `.env` 中设置 `RSSHUB_URL`。

## 🎯 核心功能

### 1. 自动抓取

- 服务器启动后自动执行一次全量抓取
- 每小时定时抓取（可配置）
- 支持手动触发抓取（UI 按钮）

### 2. 智能评分

AI 评分因子包括：
- 互动热度（点赞、评论、转发）
- 时效性（24小时内加分）
- 作者影响力
- 内容长度
- 平台权重

评分公式：加权综合得分 (0-100)

### 3. 人类反馈

用户可通过界面进行：
- 评分（1-5星）
- 操作（like/dislike/comment/share/flag）
- 评论

反馈数据将迭代优化 AI 评分模型。

### 4. 数据存储

使用 SQLite，包含：
- `hotspots`：热点内容
- `scores`：评分记录（AI + 人类）
- `feedback`：用户反馈
- `watched_accounts`：监控账号

## 🎨 像素风界面

- **热力配色**：根据分数显示红/橙/黄/灰
- **像素热力图**：Canvas 绘制高分热点矩阵
- **复古风格**：Press Start 2P 字体 + 块状布局
- **交互反馈**：悬停发光、点击查看详情

## 🧪 API 接口

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/hotspots` | 获取热点列表 |
| GET | `/api/hotspots/:id` | 获取热点详情 |
| POST | `/api/feedback` | 提交人类反馈 |
| POST | `/api/crawl` | 手动触发抓取 |
| GET | `/api/stats` | 获取统计信息 |

## 📈 迭代优化

系统会根据人类反馈自动调整 AI 评分权重。初始权重基于经验设定，随着反馈数据积累，评分准确性将不断提升。

## ⚠️ 注意事项

- LinkedIn 需要 Puppeteer 支持，确保已安装 Chromium
- 国内平台依赖 RSSHub，确保网络可达
- 生产环境建议配置更稳定的 RSSHub 实例

## 📄 许可证

MIT