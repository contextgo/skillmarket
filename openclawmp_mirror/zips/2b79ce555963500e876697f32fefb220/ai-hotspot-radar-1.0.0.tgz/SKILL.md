---
name: ai-hotspot-radar
displayName: AI Hotspot Radar
version: 2.0.0
description: |
  智能 AI 热点雷达系统 - 多平台聚合、智能评分、个性化推荐。
  采用双曲衰减算法 + Simpson 多样性指数，实现精准的热点排序和推荐。
  
  核心特性：
  - 15+ 平台热点聚合 (GitHub, HN, Reddit, 掘金等)
  - 智能评分算法 (时间衰减 + 互动加权 + 来源权威性)
  - 个性化推荐系统 (基于用户行为的智能排序)
  - 实时反馈机制 (用户评分即时影响推荐)
  - 多语言翻译支持 (自动中英互译)
  
author: echo
tags:
  - ai
  - hotspot
  - radar
  - aggregator
  - recommendation
  - scoring
  - trending
homepage: https://github.com/echo/ai-hotspot-radar
license: MIT
---

# AI Hotspot Radar

> 智能 AI 热点雷达系统 - 让优质内容浮出水面

## 核心算法

### 双曲衰减评分算法

与传统指数衰减不同，我们采用双曲衰减函数：

```
score(t) = S₀ / (1 + λt)
```

其中：
- S₀: 初始评分
- λ: 衰减系数 (根据时间段动态调整)
- t: 时间偏移量

**优势**: 保留长尾价值，避免热点过早沉没

### 分段半衰期设计

| 时间段 | 半衰期 | 适用场景 |
|--------|--------|----------|
| 0-1h | 2h | 突发热点 |
| 1-6h | 4h | 快速传播 |
| 6-24h | 8h | 持续发酵 |
| 1-3d | 24h | 深度讨论 |
| >7d | 48h | 长尾价值 |

### Simpson 多样性指数

多平台交叉验证，避免单一平台刷分：

```
D = 1 - Σ(nᵢ/N)²
```

其中 nᵢ 为第 i 平台的互动数，N 为总互动数

**加成规则**: D > 0.7 时，评分 ×1.2-1.6

## 技术架构

```
┌─────────────────────────────────────────┐
│           AI Hotspot Radar              │
├─────────────────────────────────────────┤
│  Frontend (Vue.js + Pixel Art UI)      │
├─────────────────────────────────────────┤
│  API Layer (Express.js)                │
├─────────────────────────────────────────┤
│  Scoring Engine                        │
│  ├── Decay Engine (双曲衰减)            │
│  └── Personalized Engine (个性化)       │
├─────────────────────────────────────────┤
│  Data Layer                            │
│  ├── SQLite (热点存储)                  │
│  └── Translation Cache                  │
├─────────────────────────────────────────┤
│  Crawler Adapters (15+ platforms)      │
└─────────────────────────────────────────┘
```

## 功能特性

### 热点聚合
- ✅ GitHub Trending
- ✅ Hacker News
- ✅ Reddit (r/MachineLearning, r/LocalLLaMA)
- ✅ Product Hunt
- ✅ 掘金
- ✅ 机器之心
- ✅ 即刻
- ✅ 小红书
- ✅ v2ex
- ✅ 36氪
- ✅ 更多平台持续添加...

### 智能评分
- ⏰ 时间衰减 (双曲函数)
- 👍 互动加权 (点赞/评论/分享)
- 🏆 来源权威性 (平台权重)
- 🌐 多平台交叉验证

### 个性化推荐
- 👤 用户画像分析
- ⭐ 收藏偏好学习
- 📊 反馈实时更新
- 🎯 智能排序切换

### 多语言支持
- 🌐 自动中英互译
- 🤖 多引擎翻译 (StepFun, GPT-4, DeepL)
- ✅ 翻译质量监控

## 快速开始

### 本地部署

```bash
# 克隆项目
git clone https://github.com/echo/ai-hotspot-radar.git
cd ai-hotspot-radar

# 安装依赖
npm install

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件

# 启动服务
npm start
```

访问 http://localhost:3000

### Docker 部署

```bash
# 使用 Docker Compose
docker-compose up -d

# 或使用单容器
docker run -d -p 3000:3000 echo/ai-hotspot-radar
```

## API 文档

### 获取热点列表

```http
GET /api/hotspots?limit=50&sort=smart&platform=github
```

**参数**:
- `limit`: 返回数量 (默认 50)
- `sort`: 排序方式 (smart/time/score)
- `platform`: 平台筛选

**响应**:
```json
{
  "hotspots": [
    {
      "id": "github_xxx",
      "title": "...",
      "title_zh": "...",
      "platform": "github",
      "avg_score": 85.5,
      "crawled_at": "2026-03-31T12:00:00Z"
    }
  ]
}
```

### 提交反馈

```http
POST /api/feedback
Content-Type: application/json

{
  "hotspot_id": "github_xxx",
  "action": "like",
  "user_id": "anonymous"
}
```

## 技术博客

- [双曲衰减算法在热点评分中的应用](https://zhuanlan.zhihu.com/p/xxx)
- [AI 热点雷达架构设计](https://juejin.cn/post/xxx)

## 开源贡献

欢迎提交 Issue 和 PR！

## 许可证

MIT License

---

*Made with ❤️ by Echo*
