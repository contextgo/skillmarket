# AI 热点抓取系统 - 技术设计文档

## 1. 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                      前端界面 (Pixel Art UI)                │
│                  HTML + CSS + JavaScript                  │
│                  热力图 Canvas 渲染                        │
└──────────────────────────────┬──────────────────────────────┘
                               │ REST API
┌──────────────────────────────▼──────────────────────────────┐
│                   后端服务器 (Express)                      │
│  ├─ 抓取调度 (Cron + 手动触发)                             │
│  ├─ 平台适配器 (Pluggable Adapters)                        │
│  ├─ 评分引擎 (AI + 反馈迭代)                               │
│  └─ API 路由 (Hotspots / Feedback / Stats)                │
└──────────────────────────────┬──────────────────────────────┘
                               │
┌──────────────────────────────▼──────────────────────────────┐
│                    数据存储 (SQLite)                        │
│  ├─ hotspots (热点内容)                                    │
│  ├─ scores (评分记录)                                      │
│  ├─ feedback (人类反馈)                                    │
│  └─ watched_accounts (监控账号)                           │
└─────────────────────────────────────────────────────────────┘
```

## 2. 模块详解

### 2.1 平台适配器 (Platform Adapters)

每个平台实现统一的接口：

```js
interface PlatformAdapter {
  name: string;
  fetchHotspots(accountIds: string[]): Promise<Hotspot[]>;
  normalizeData(raw: any): Hotspot;
}
```

支持的平台：
- **海外**：Twitter (RSS via Nitter), Reddit (JSON API), Hacker News (Algolia API), Product Hunt (RSS), LinkedIn (Puppeteer)
- **国内**：微博、小红书、即刻、掘金、V2EX (主要通过 RSSHub)

### 2.2 评分系统 (Scoring Engine)

#### AI 自动评分因子

| 因子 | 权重 | 说明 |
|------|------|------|
| 互动热度 (engagement) | 35% | 原始互动数归一化 (max 1000) |
| 时效性 (freshness) | 25% | 24h内满分，一周内线性衰减 |
| 作者影响力 (authorInfluence) | 15% | 预留扩展 (粉丝数、权威度) |
| 内容长度 (contentLength) | 10% | 200+字符满分 |
| 平台权重 (platformWeight) | 15% | 各平台基础权重 |

#### 分数 = Σ(因子值 × 权重) × 100

### 2.3 反馈迭代机制

人类反馈会记录到 `feedback` 表，并生成 "human" 源评分。系统定期计算：

- AI 评分与人类评分的平均偏差
- 根据偏差调整因子权重（未来版本）

当前版本：人类评分直接作为独立评分源，与 AI 评分并行展示。

## 3. 数据模型

### hotspots
```sql
id TEXT PK
platform TEXT
title TEXT
content TEXT
author TEXT
author_id TEXT
url TEXT UNIQUE
media_urls JSON
metrics JSON
raw_data JSON
crawled_at DATETIME
published_at DATETIME
```

### scores
```sql
id TEXT PK
hotspot_id TEXT FK
source TEXT ('ai' | 'human')
score REAL (0-100)
factors JSON
feedback TEXT
created_at DATETIME
```

### feedback
```sql
id TEXT PK
hotspot_id TEXT FK
user_id TEXT
action TEXT ('like' | 'dislike' | 'comment' | 'share' | 'flag')
rating INTEGER (1-5)
comment TEXT
created_at DATETIME
```

## 4. API 设计

| 方法 | 路径 | 功能 | 参数 |
|------|------|------|------|
| GET | `/api/hotspots` | 列表 | `platform`, `limit`, `offset`, `sort`, `minScore` |
| GET | `/api/hotspots/:id` | 详情 | - |
| POST | `/api/feedback` | 提交反馈 | `hotspot_id`, `user_id`, `action`, `rating`, `comment` |
| POST | `/api/crawl` | 手动抓取 | `platforms[]` (可选) |
| GET | `/api/stats` | 统计 | - |

## 5. 前端像素风设计

### 视觉元素
- **配色方案**：黑底 + 霓虹绿 (#00ff00) + 热力色 (红/橙/黄)
- **字体**：Press Start 2P (Google Fonts)
- **边框**：4px 实线/虚线，无圆角
- **热力图**：Canvas 绘制 20px 像素块

### 交互
- 卡片悬停：发光 + 上浮效果
- 点击卡片：打开详情模态框
- 热力图按钮：切换 Canvas 显示
- 强制抓取：异步触发，刷新提示

## 6. 部署指南

### 6.1 环境要求
- Node.js >= 18
- npm or yarn
- (可选) Chromium for LinkedIn 抓取

### 6.2 快速部署
```bash
git clone <repo>
cd hotspot-crawler-project
chmod +x deploy.sh
./deploy.sh
```

### 6.3 配置 .env
```env
PORT=3000
RSSHUB_URL=https://rsshub.app
PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium
CRAWL_INTERVAL_HOURS=1
DEBUG=false
```

## 7. 扩展新平台

1. 在 `src/platforms/index.js` 创建适配器类：

```js
class MyPlatformAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'myplatform';
  }
  async fetchHotspots(accountIds) { ... }
  normalizeData(raw) { ... }
}
```

2. 在 `platforms` 导出对象中注册
3. 在 `watchedAccounts` 中添加监控账号

## 8. 性能与优化

- **SQLite 索引**：在常用查询字段 (platform, crawled_at, author_id) 上建立索引
- **分页查询**：API 默认 LIMIT 50，支持 offset
- **批量插入**：使用 `INSERT OR REPLACE` 减少重复检查
- **RSS 缓存**：RSSHub 自带缓存，减少源站压力

## 9. 已知限制

- **LinkedIn**：需要 Puppeteer，首次运行会下载 Chromium (~100MB)
- **即刻**：暂无公开 RSS/API，需等待扩展
- **评分因子**：当前使用启发式规则，未来可训练机器学习模型
- **用户系统**：当前使用随机 user_id，实际需对接认证系统

## 10. 未来路线图

- [ ] 引入机器学习评分模型
- [ ] 用户账户系统 + 个性化推荐
- [ ] 更多平台 (YouTube, Medium, 知乎)
- [ ] 实时 WebSocket 推送
- [ ] 数据导出 (CSV/JSON)
- [ ] 多语言支持