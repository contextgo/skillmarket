/**
 * 翻译质量分析 - 趋势分析和自动改进
 */

class TranslationAnalytics {
  constructor(storage) {
    this.storage = storage;
  }

  // 获取翻译质量趋势
  getQualityTrend(days = 7) {
    const trend = this.storage.db.prepare(`
      SELECT 
        date(created_at) as date,
        COUNT(*) as count,
        AVG(rating) as avg_rating,
        COUNT(CASE WHEN rating >= 4 THEN 1 END) as high_quality,
        COUNT(CASE WHEN rating = 3 THEN 1 END) as medium_quality,
        COUNT(CASE WHEN rating <= 2 THEN 1 END) as low_quality
      FROM translation_feedback
      WHERE created_at >= datetime('now', '-${days} days')
      GROUP BY date(created_at)
      ORDER BY date
    `).all();

    return trend;
  }

  // 获取引擎质量对比
  getEngineQuality() {
    // 从翻译结果中提取引擎信息（需要在翻译时记录）
    // 这里基于用户反馈统计
    const stats = this.storage.db.prepare(`
      SELECT 
        AVG(rating) as avg_rating,
        COUNT(*) as total
      FROM translation_feedback
    `).get();

    return stats;
  }

  // 获取需要改进的翻译
  getTranslationsNeedImprovement(limit = 10) {
    return this.storage.db.prepare(`
      SELECT 
        h.id,
        h.platform,
        h.title,
        h.title_zh,
        AVG(f.rating) as avg_rating,
        COUNT(f.id) as feedback_count
      FROM hotspots h
      JOIN translation_feedback f ON h.id = f.hotspot_id
      GROUP BY h.id
      HAVING avg_rating < 3
      ORDER BY feedback_count DESC
      LIMIT ?
    `).all(limit);
  }

  // 获取高频改进建议
  getCommonSuggestions(limit = 10) {
    return this.storage.db.prepare(`
      SELECT 
        suggested_translation,
        COUNT(*) as count,
        AVG(rating) as avg_rating
      FROM translation_feedback
      WHERE suggested_translation IS NOT NULL 
        AND suggested_translation != ''
      GROUP BY suggested_translation
      ORDER BY count DESC
      LIMIT ?
    `).all(limit);
  }

  // 生成质量报告
  generateReport() {
    const trend = this.getQualityTrend(30);
    const engineStats = this.getEngineQuality();
    const needImprovement = this.getTranslationsNeedImprovement(5);
    const suggestions = this.getCommonSuggestions(5);

    const totalFeedback = trend.reduce((sum, d) => sum + d.count, 0);
    const avgRating = trend.length > 0 
      ? trend.reduce((sum, d) => sum + d.avg_rating * d.count, 0) / totalFeedback 
      : 0;

    return {
      summary: {
        total_feedback: totalFeedback,
        avg_rating: avgRating.toFixed(2),
        satisfaction_rate: trend.reduce((sum, d) => sum + d.high_quality, 0) / totalFeedback * 100
      },
      trend,
      engine_stats: engineStats,
      need_improvement: needImprovement,
      common_suggestions: suggestions,
      recommendations: this.generateRecommendations(avgRating, needImprovement)
    };
  }

  // 生成改进建议
  generateRecommendations(avgRating, needImprovement) {
    const recommendations = [];

    if (avgRating < 3.5) {
      recommendations.push('整体翻译质量偏低，建议优先使用 GPT-4 或 DeepL 引擎');
    }

    if (needImprovement.length > 0) {
      recommendations.push(`有 ${needImprovement.length} 条翻译需要人工改进，建议优先处理`);
    }

    recommendations.push('定期审查用户反馈，持续优化翻译质量');
    recommendations.push('考虑为技术术语建立统一翻译词库');

    return recommendations;
  }

  // 自动改进翻译（基于用户反馈）
  async autoImproveTranslations(translator, limit = 5) {
    const toImprove = this.getTranslationsNeedImprovement(limit);
    const improved = [];

    for (const item of toImprove) {
      try {
        // 获取用户建议的翻译
        const suggestions = this.storage.db.prepare(`
          SELECT suggested_translation, rating
          FROM translation_feedback
          WHERE hotspot_id = ? AND suggested_translation IS NOT NULL
          ORDER BY rating DESC
          LIMIT 1
        `).get(item.id);

        if (suggestions && suggestions.rating >= 4) {
          // 使用用户建议的翻译
          this.storage.updateHotspot(item.id, {
            title_zh: suggestions.suggested_translation
          });
          improved.push({
            id: item.id,
            old: item.title_zh,
            new: suggestions.suggested_translation,
            source: 'user_feedback'
          });
        } else {
          // 重新翻译
          const result = await translator.translateToChinese(item.title, 200, { returnQuality: true });
          if (result.quality.score >= 80) {
            this.storage.updateHotspot(item.id, {
              title_zh: result.text
            });
            improved.push({
              id: item.id,
              old: item.title_zh,
              new: result.text,
              source: 'retranslate',
              quality: result.quality.score
            });
          }
        }
      } catch (err) {
        console.error(`[TranslationAnalytics] Failed to improve ${item.id}:`, err.message);
      }
    }

    return improved;
  }

  // 获取平台翻译质量对比
  getPlatformQuality() {
    return this.storage.db.prepare(`
      SELECT 
        h.platform,
        COUNT(f.id) as feedback_count,
        AVG(f.rating) as avg_rating,
        COUNT(CASE WHEN f.rating >= 4 THEN 1 END) as high_quality,
        COUNT(CASE WHEN f.rating <= 2 THEN 1 END) as low_quality
      FROM hotspots h
      JOIN translation_feedback f ON h.id = f.hotspot_id
      GROUP BY h.platform
      ORDER BY avg_rating DESC
    `).all();
  }
}

module.exports = TranslationAnalytics;
