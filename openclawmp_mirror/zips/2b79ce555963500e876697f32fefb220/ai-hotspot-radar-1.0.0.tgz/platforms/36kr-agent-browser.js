/**
 * 36氪 (36kr) Agent Browser Adapter
 * 使用 AI-optimized browser automation 抓取 36氪 AI 相关内容
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class SanliuKrAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config = {}) {
    super(config);
    this.name = '36kr';
    this.baseUrl = 'https://36kr.com';
    this.aiTopics = [
      '/information/technology',  // 科技频道
      '/information/AI',          // AI 频道
      '/search/articles/人工智能', // AI 搜索
      '/search/articles/大模型',
      '/search/articles/ChatGPT'
    ];
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 关键词用于内容过滤
    const aiKeywords = [
      'AI', '人工智能', '大模型', 'LLM', 'GPT', 'ChatGPT', 'Claude',
      '机器学习', '深度学习', '神经网络', 'transformer',
      'OpenAI', 'Anthropic', 'Google', 'Gemini',
      '智谱', '文心一言', '通义千问', 'Kimi', '阶跃星辰',
      'AI芯片', 'AI应用', 'AI Agent', '智能体'
    ];

    try {
      // 抓取 36氪科技/AI 频道
      for (const topic of this.aiTopics) {
        try {
          const url = `${this.baseUrl}${topic}`;
          console.log(`[36kr] Fetching: ${url}`);
          
          const feedItems = await this.fetchWithAgentBrowser(url, {
            // 等待文章列表加载
            waitForSelector: '.article-item, .information-flow-item, .kr-flow-article-item',
            // 提取文章数据
            extractData: () => {
              const items = [];
              const articleElements = document.querySelectorAll('.article-item, .information-flow-item, .kr-flow-article-item');
              
              articleElements.forEach((el, index) => {
                if (index >= 20) return; // 限制数量
                
                const titleEl = el.querySelector('.article-item-title, .article-title, .title, h4 a');
                const descEl = el.querySelector('.article-item-description, .article-desc, .summary, .description');
                const authorEl = el.querySelector('.article-item-author, .author-name, .kr-flow-author');
                const timeEl = el.querySelector('.article-item-time, .time, .kr-flow-time');
                const linkEl = el.querySelector('a');
                
                if (titleEl) {
                  items.push({
                    title: titleEl.textContent?.trim() || '',
                    content: descEl?.textContent?.trim() || '',
                    author: authorEl?.textContent?.trim() || '36氪',
                    published_at: timeEl?.textContent?.trim() || new Date().toISOString(),
                    url: linkEl?.href || ''
                  });
                }
              });
              
              return items;
            }
          });

          // 过滤 AI 相关内容
          for (const item of feedItems) {
            const text = `${item.title} ${item.content}`.toLowerCase();
            const isAI = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
            
            if (isAI && item.title) {
              results.push(this.normalizeData({
                id: `36kr_${this.extractId(item.url)}_${Date.now()}`,
                title: item.title,
                content: item.content,
                author: item.author,
                url: item.url.startsWith('http') ? item.url : `${this.baseUrl}${item.url}`,
                published_at: this.parseTime(item.published_at)
              }));
            }
          }
          
          console.log(`[36kr] Fetched ${feedItems.length} items from ${topic}`);
          
          // 添加延迟避免请求过快
          await new Promise(r => setTimeout(r, 2000));
          
        } catch (err) {
          console.error(`[36kr] Failed to fetch ${topic}:`, err.message);
        }
      }
      
      console.log(`[36kr] Total AI-related items: ${results.length}`);
    } catch (err) {
      console.error('[36kr] Adapter error:', err.message);
    }
    
    return results;
  }

  extractId(url) {
    if (!url) return Date.now().toString();
    const match = url.match(/\/(\d+)/);
    return match ? match[1] : Date.now().toString();
  }

  parseTime(timeStr) {
    if (!timeStr) return new Date().toISOString();
    
    // 处理相对时间格式
    if (timeStr.includes('分钟前')) {
      const mins = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - mins * 60000).toISOString();
    }
    if (timeStr.includes('小时前')) {
      const hours = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - hours * 3600000).toISOString();
    }
    if (timeStr.includes('天前')) {
      const days = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - days * 86400000).toISOString();
    }
    
    // 尝试直接解析
    const date = new Date(timeStr);
    return isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
  }

  normalizeData(item) {
    return {
      id: item.id,
      platform: this.name,
      title: item.title.substring(0, 200),
      content: item.content || item.title,
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: {
        views: 0,
        engagement: 0
      }
    };
  }
}

module.exports = { SanliuKrAgentBrowserAdapter };
