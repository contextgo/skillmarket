/**
 * GitHub Trending Adapter using Agent Browser
 * Scrapes github.com/trending for AI repositories
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class GitHubAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config) {
    super(config);
    this.name = 'github';
    this.baseUrl = 'https://github.com';
    this.trendingUrl = 'https://github.com/trending';
    
    // AI 相关语言和技术
    this.aiLanguages = ['python', 'jupyter-notebook'];
    this.aiKeywords = [
      'AI', 'artificial-intelligence', 'machine-learning', 'deep-learning',
      'LLM', 'GPT', 'transformer', 'neural-network', 'pytorch', 'tensorflow',
      'langchain', 'openai', 'claude', 'llama', 'mistral', 'huggingface',
      'RAG', 'embeddings', 'vector-database', 'agent', 'autogpt'
    ];
  }

  async fetchHotspots() {
    const results = [];
    
    try {
      console.log('[GitHubAgentBrowser] Fetching trending...');
      
      // Open trending page with AI-related languages
      const url = `${this.trendingUrl}/python?since=daily`;
      await this.open(url);
      await this.wait(3000);
      
      // Extract trending repos
      const repos = await this.extractTrendingRepos();
      
      for (const repo of repos.slice(0, 15)) {
        if (this.isAIRepo(repo)) {
          results.push(this.normalizeData(repo));
        }
      }
      
    } catch (err) {
      console.error('[GitHubAgentBrowser] Failed:', err.message);
    }
    
    await this.close();
    return results;
  }

  async extractTrendingRepos() {
    const repos = [];
    
    try {
      // Get snapshot
      const snapshot = await this.snapshot({ interactive: false });
      const lines = snapshot.split('\n');
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        // Look for repository links (format: owner/repo)
        if (line.includes('link') && line.includes('/')) {
          const match = line.match(/link\s+"([^"]+)"\s+\[ref=([^\]]+)\]/);
          if (match) {
            const text = match[1];
            const ref = match[2];
            
            // Check if it's a repo name (contains / but not http)
            if (text.includes('/') && !text.includes('http') && !text.includes(' ')) {
              const parts = text.split('/');
              if (parts.length === 2 && parts[0] && parts[1]) {
                const [owner, name] = parts;
                
                // Look for stars in nearby lines
                let stars = 0;
                let description = '';
                
                for (let j = i + 1; j < Math.min(i + 8, lines.length); j++) {
                  // Extract stars
                  const starMatch = lines[j].match(/(\d+)\s*stars?/i);
                  if (starMatch) {
                    stars = parseInt(starMatch[1].replace(/,/g, ''));
                  }
                  
                  // Extract description
                  if (!description && lines[j].includes('text') && !lines[j].includes('stars')) {
                    const descMatch = lines[j].match(/text\s+"([^"]+)"/);
                    if (descMatch && descMatch[1].length > 10) {
                      description = descMatch[1];
                    }
                  }
                }
                
                repos.push({
                  owner: owner,
                  name: name,
                  fullName: text,
                  description: description,
                  stars: stars,
                  url: `https://github.com/${text}`
                });
              }
            }
          }
        }
      }
    } catch (err) {
      console.error('[GitHubAgentBrowser] Extract error:', err.message);
    }
    
    return repos;
  }

  isAIRepo(repo) {
    const text = `${repo.name} ${repo.description}`.toLowerCase();
    return this.aiKeywords.some(keyword => 
      text.includes(keyword.toLowerCase())
    );
  }

  normalizeData(item) {
    // Calculate score based on stars
    let score = 50;
    if (item.stars > 1000) score = 95;
    else if (item.stars > 500) score = 85;
    else if (item.stars > 200) score = 75;
    else if (item.stars > 100) score = 65;
    else if (item.stars > 50) score = 55;
    
    score = Math.min(100, Math.max(0, score));
    
    return {
      id: this.generateId(item),
      platform: this.name,
      title: `${item.fullName}: ${item.description || 'AI Repository'}`,
      content: item.description || '',
      author: item.owner,
      author_id: item.owner,
      url: item.url,
      published_at: new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        stars: item.stars
      },
      score: score,
      avg_score: score,
      is_ai_related: true
    };
  }
}

module.exports = { GitHubAgentBrowserAdapter };
