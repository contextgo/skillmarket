/**
 * GitHub Trending Adapter using simple HTTP requests
 * Uses GitHub API to fetch trending repositories
 */

const axios = require('axios');

class GitHubSimpleAdapter {
  constructor(config) {
    this.config = config;
    this.name = 'github';
    this.baseUrl = 'https://api.github.com';
    
    // AI 相关关键词
    this.aiKeywords = [
      'AI', 'artificial-intelligence', 'machine-learning', 'deep-learning',
      'LLM', 'GPT', 'transformer', 'neural-network', 'pytorch', 'tensorflow',
      'langchain', 'openai', 'claude', 'llama', 'mistral', 'huggingface',
      'RAG', 'embeddings', 'vector-database', 'agent', 'autogpt'
    ];
  }

  async fetchHotspots(accounts = []) {
    const results = [];
    
    try {
      // 如果提供了账号列表，获取这些组织的仓库
      if (accounts && accounts.length > 0) {
        console.log(`[GitHubSimple] Fetching repos from ${accounts.length} accounts...`);
        
        for (const account of accounts) {
          try {
            // 获取用户/组织的仓库
            const repos = await this.fetchUserRepos(account);
            console.log(`[GitHubSimple] ${account}: ${repos.length} repos`);
            
            for (const repo of repos) {
              if (this.isAIRepo(repo)) {
                results.push(this.normalizeData(repo));
              }
            }
          } catch (err) {
            console.error(`[GitHubSimple] Failed to fetch ${account}:`, err.message);
          }
        }
      } else {
        // 默认：搜索热门AI仓库
        console.log('[GitHubSimple] Fetching trending repositories...');
        
        const query = 'AI machine-learning deep-learning LLM GPT';
        const url = `${this.baseUrl}/search/repositories?q=${encodeURIComponent(query)}&sort=updated&order=desc&per_page=20`;
        
        const response = await axios.get(url, {
          headers: {
            'Accept': 'application/vnd.github.v3+json',
            'User-Agent': 'Hotspot-Crawler/1.0'
          },
          timeout: 30000
        });
        
        const repos = response.data.items || [];
        console.log(`[GitHubSimple] Found ${repos.length} repositories`);
        
        for (const repo of repos) {
          if (this.isAIRepo(repo)) {
            results.push(this.normalizeData(repo));
          }
        }
      }
      
    } catch (err) {
      console.error('[GitHubSimple] Failed:', err.message);
    }
    
    return results;
  }

  async fetchUserRepos(username) {
    // 获取用户或组织的公开仓库，按最近更新时间排序
    const url = `${this.baseUrl}/users/${username}/repos?sort=updated&direction=desc&per_page=10`;
    
    const response = await axios.get(url, {
      headers: {
        'Accept': 'application/vnd.github.v3+json',
        'User-Agent': 'Hotspot-Crawler/1.0'
      },
      timeout: 30000
    });
    
    return response.data || [];
  }

  isAIRepo(repo) {
    const text = `${repo.name} ${repo.description || ''} ${repo.topics?.join(' ') || ''}`.toLowerCase();
    return this.aiKeywords.some(keyword => 
      text.includes(keyword.toLowerCase())
    );
  }

  normalizeData(item) {
    // Calculate score based on stars
    const stars = item.stargazers_count || 0;
    let score = 50;
    if (stars > 10000) score = 95;
    else if (stars > 5000) score = 90;
    else if (stars > 1000) score = 85;
    else if (stars > 500) score = 80;
    else if (stars > 200) score = 75;
    else if (stars > 100) score = 70;
    else if (stars > 50) score = 60;
    
    score = Math.min(100, Math.max(0, score));
    
    return {
      id: `github_${item.id}`,
      platform: this.name,
      title: `${item.full_name}: ${item.description || 'AI Repository'}`,
      content: item.description || '',
      author: item.owner.login,
      author_id: item.owner.login,
      url: item.html_url,
      published_at: item.updated_at || new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        stars: stars,
        forks: item.forks_count || 0,
        language: item.language
      },
      score: score,
      avg_score: score,
      is_ai_related: true
    };
  }
}

module.exports = { GitHubSimpleAdapter };
