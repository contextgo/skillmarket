/**
 * Agent Browser Adapter - Token-efficient browser automation
 * Uses agent-browser CLI for web scraping with minimal token consumption
 * 
 * Based on: https://mp.weixin.qq.com/s/MvwmwhXMCmGh7mABOv01_Q
 * Author: 迁徙Lab
 * Adapted for: OpenClaw AI Hotspot Crawler
 */

const { execSync } = require('child_process');

// Base PlatformAdapter class (avoid circular dependency)
class PlatformAdapterBase {
  constructor(config = {}) {
    this.config = config;
    this.name = 'base';
  }

  async fetchHotspots(accountIds = []) {
    throw new Error('fetchHotspots must be implemented by subclass');
  }

  normalizeData(rawData) {
    throw new Error('normalizeData must be implemented by subclass');
  }

  generateId(item) {
    return `${this.name}_${item.id || item.url || item.title || Date.now()}`;
  }
}

class AgentBrowserAdapter extends PlatformAdapterBase {
  constructor(config) {
    super(config);
    this.sessionName = `hotspot-${this.name}-${Date.now()}`;
    this.useAgentBrowser = true;
    this.timeout = config.timeout || 30000;
  }

  /**
   * Execute agent-browser command
   * FIXED: Disable CDP mode, use headless browser only
   */
  exec(command, options = {}) {
    // DISABLED: CDP mode requires Chrome debugging port which is not available
    // Always use headless mode (agent-browser default behavior)
    const fullCommand = `agent-browser --session ${this.sessionName} ${command}`;
    
    console.log(`[AgentBrowser:${this.name}] > ${command}`);
    
    try {
      const result = execSync(fullCommand, {
        encoding: 'utf-8',
        timeout: options.timeout || this.timeout,
        stdio: ['pipe', 'pipe', 'pipe']
      });
      return result.trim();
    } catch (error) {
      console.error(`[AgentBrowser:${this.name}] Error: ${error.message}`);
      throw error;
    }
  }

  /**
   * Open URL in browser
   */
  async open(url) {
    return this.exec(`open "${url}"`);
  }

  /**
   * Get interactive elements snapshot (token-efficient)
   * Returns only interactive elements, not full DOM
   */
  async snapshot(options = {}) {
    const mode = options.interactive !== false ? '-i' : '';
    const compact = options.compact ? '-c' : '';
    return this.exec(`snapshot ${mode} ${compact}`);
  }

  /**
   * Click element by ref
   */
  async click(ref) {
    return this.exec(`click ${ref}`);
  }

  /**
   * Fill input field
   */
  async fill(ref, text) {
    return this.exec(`fill ${ref} "${text}"`);
  }

  /**
   * Press key
   */
  async press(key) {
    return this.exec(`press ${key}`);
  }

  /**
   * Wait for milliseconds
   */
  async wait(ms = 1000) {
    return this.exec(`wait ${ms}`);
  }

  /**
   * Close browser session
   */
  async close() {
    try {
      return this.exec('close');
    } catch (e) {
      // Ignore close errors
    }
  }

  /**
   * Parse snapshot to extract structured data
   * Converts agent-browser output to usable format
   */
  parseSnapshot(snapshot) {
    const lines = snapshot.split('\n').filter(line => line.trim());
    const elements = [];
    
    for (const line of lines) {
      // Parse format: type "text" [ref=eN]
      const match = line.match(/^(\w+)\s+"([^"]*)"\s+\[ref=([^\]]+)\]/);
      if (match) {
        elements.push({
          type: match[1],
          text: match[2],
          ref: match[3]
        });
      }
    }
    
    return elements;
  }

  /**
   * Extract links from snapshot
   */
  extractLinks(snapshot) {
    const elements = this.parseSnapshot(snapshot);
    return elements.filter(el => el.type === 'link');
  }

  /**
   * Extract buttons from snapshot
   */
  extractButtons(snapshot) {
    const elements = this.parseSnapshot(snapshot);
    return elements.filter(el => el.type === 'button');
  }

  /**
   * Extract text inputs from snapshot
   */
  extractInputs(snapshot) {
    const elements = this.parseSnapshot(snapshot);
    return elements.filter(el => el.type === 'textbox' || el.type === 'input');
  }

  /**
   * Find element by text content
   */
  findByText(snapshot, text) {
    const elements = this.parseSnapshot(snapshot);
    return elements.find(el => 
      el.text.toLowerCase().includes(text.toLowerCase())
    );
  }

  /**
   * Scroll page
   */
  async scroll(direction = 'down', amount = 500) {
    // Use JavaScript evaluation for scrolling
    return this.exec(`eval "window.scrollBy(0, ${direction === 'down' ? amount : -amount})"`);
  }

  /**
   * Get page title
   */
  async getTitle() {
    return this.exec('eval "document.title"');
  }

  /**
   * Get current URL
   */
  async getUrl() {
    return this.exec('eval "window.location.href"');
  }

  /**
   * Check if element exists
   */
  async hasElement(selector) {
    try {
      const result = this.exec(`eval "document.querySelector('${selector}') !== null"`);
      return result === 'true';
    } catch (e) {
      return false;
    }
  }

  /**
   * Wait for element to appear
   */
  async waitForElement(ref, timeout = 10000) {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const snapshot = await this.snapshot({ interactive: true });
      const elements = this.parseSnapshot(snapshot);
      if (elements.some(el => el.ref === ref)) {
        return true;
      }
      await this.wait(500);
    }
    return false;
  }

  /**
   * Save session state
   */
  async saveState(filename) {
    return this.exec(`state save "${filename}"`);
  }

  /**
   * Load session state
   */
  async loadState(filename) {
    return this.exec(`state load "${filename}"`);
  }

  /**
   * Set device for mobile simulation
   */
  async setDevice(device) {
    return this.exec(`set device "${device}"`);
  }

  /**
   * Block network requests by pattern
   */
  async blockNetwork(pattern) {
    return this.exec(`network route "${pattern}" --abort`);
  }

  /**
   * Take screenshot
   */
  async screenshot(filename) {
    return this.exec(`screenshot "${filename}"`);
  }

  /**
   * Full page screenshot
   */
  async screenshotFull(filename) {
    return this.exec(`screenshot --full "${filename}"`);
  }
}

module.exports = { PlatformAdapterBase, AgentBrowserAdapter };
