const axios = require('axios');
const { TwitterApi } = require('twitter-api-v2');

class PlatformAdapter {
  constructor(config = {}) {
    this.config = config;
    this.name = 'base';
  }

  async fetchHotspots(accountIds = []) {
    throw new Error('fetchHotspots must be implemented by subclass');
  }

  normalizeData(rawData) {
    throw new Error('normalizeData must be implemented by subclass');
  }

  generateId(item) {
    return `${this.name}_${item.id || item.url}`;
  }
}

// Twitter/X 适配器（使用 Nitter RSS 作为备用方案，避免 Twitter API 限制）
class TwitterAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'twitter';
    this.parser = new Parser({
      timeout: 15000, // 15秒超时
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; HotspotBot/1.0)'
      }
    });
    // Nitter 实例列表（用于故障转移）
    // 注意：Nitter 实例经常变动，需要定期更新
    this.nitterInstances = [
      'https://nitter.privacydev.net',
      'https://nitter.poast.org',
      'https://nitter.datura.network'
    ];
    this.currentInstanceIndex = 0;
    // 尝试使用官方 API（如果提供了有效的 Bearer Token）
    this.useOfficialApi = false;
    if (config.bearerToken && !config.bearerToken.startsWith('sk-or-')) {
      try {
        this.client = new TwitterApi(config.bearerToken);
        this.useOfficialApi = true;
        this.apiCallCount = 0;
        this.maxApiCallsPerMonth = 1500;
        this.monthlyResetDate = new Date();
        console.log('[Twitter] Using official Twitter API');
      } catch (err) {
        console.warn('[Twitter] Invalid Bearer Token, falling back to Nitter RSS');
      }
    } else {
      console.log('[Twitter] Using Nitter RSS (no valid API token)');
    }
  }
  
  // 获取当前 Nitter 实例
  getNitterInstance() {
    return this.nitterInstances[this.currentInstanceIndex];
  }
  
  // 切换到下一个 Nitter 实例
  rotateNitterInstance() {
    this.currentInstanceIndex = (this.currentInstanceIndex + 1) % this.nitterInstances.length;
    console.log(`[Twitter] Switched to Nitter instance: ${this.getNitterInstance()}`);
  }
  
  // 检查是否还有API额度
  hasQuota() {
    if (!this.useOfficialApi) return false;
    const now = new Date();
    if (now.getMonth() !== this.monthlyResetDate.getMonth()) {
      this.apiCallCount = 0;
      this.monthlyResetDate = now;
      console.log('[Twitter] API quota reset for new month');
    }
    return this.apiCallCount < this.maxApiCallsPerMonth;
  }

  // AI 行业关键词（用于内容过滤）
  getAIKeywords() {
    return [
      'AI', 'artificial intelligence', 'machine learning', 'deep learning',
      'LLM', 'large language model', 'GPT', 'ChatGPT', 'Claude', 'Gemini',
      'transformer', 'neural network', 'AI agent', 'AI model',
      'AI device', 'AI terminal', 'AI hardware', 'AI chip',
      'OpenAI', 'Anthropic', 'Google AI', 'Meta AI', 'Microsoft AI',
      'training', 'fine-tuning', 'inference', 'prompt engineering',
      'RAG', 'embeddings', 'vector', 'multimodal'
    ];
  }
  
  // 排除关键词（汽车等非AI内容）
  getExcludeKeywords() {
    return [
      'Tesla', 'car', 'automotive', 'vehicle', 'EV', 'electric vehicle',
      'FSD', 'autopilot', 'Musk', 'SpaceX', 'Mars', 'rocket'
    ];
  }

  async fetchHotspots(accountIds = []) {
    // 优先尝试官方 API（如果有配额）
    if (this.useOfficialApi && this.hasQuota()) {
      try {
        return await this.fetchWithOfficialApi(accountIds);
      } catch (err) {
        console.warn('[Twitter] Official API failed, falling back to Nitter:', err.message);
      }
    }
    
    // 使用 Nitter RSS 作为备用
    return await this.fetchWithNitter(accountIds);
  }

  // 使用官方 Twitter API v2 抓取
  async fetchWithOfficialApi(accountIds = []) {
    const results = [];
    const aiKeywords = this.getAIKeywords();
    const excludeKeywords = this.getExcludeKeywords();

    for (const username of accountIds) {
      try {
        if (!this.hasQuota()) {
          console.log('[Twitter] API quota exceeded mid-fetch');
          break;
        }
        
        const user = await this.client.v2.userByUsername(username);
        if (!user.data) {
          console.error(`[Twitter] User not found: ${username}`);
          continue;
        }

        const tweets = await this.client.v2.userTimeline(user.data.id, {
          max_results: 10,
          'tweet.fields': ['created_at', 'public_metrics', 'text'],
          exclude: ['retweets', 'replies']
        });

        for (const tweet of tweets.data?.data || []) {
          const text = tweet.text.toLowerCase();
          
          // 过滤：只保留高互动推文（点赞+转发+评论 > 100）
          const engagement = (tweet.public_metrics?.like_count || 0) + 
                            (tweet.public_metrics?.retweet_count || 0) +
                            (tweet.public_metrics?.reply_count || 0);
          if (engagement < 100) continue;
          
          // 过滤：必须包含AI关键词
          const hasAIKeyword = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
          if (!hasAIKeyword) continue;
          
          // 过滤：排除汽车等非AI内容
          const hasExcludeKeyword = excludeKeywords.some(kw => text.includes(kw.toLowerCase()));
          if (hasExcludeKeyword) continue;
          
          results.push(this.normalizeData({
            id: tweet.id,
            title: tweet.text.substring(0, 100),
            content: tweet.text,
            author: username,
            author_id: user.data.id,
            url: `https://twitter.com/${username}/status/${tweet.id}`,
            published_at: tweet.created_at,
            metrics: {
              likes: tweet.public_metrics?.like_count || 0,
              retweets: tweet.public_metrics?.retweet_count || 0,
              replies: tweet.public_metrics?.reply_count || 0,
              engagement
            }
          }));
        }
        
        this.apiCallCount += 2;
        console.log(`[Twitter] Fetched ${tweets.data?.data?.length || 0} tweets from ${username} (API: ${this.apiCallCount}/${this.maxApiCallsPerMonth})`);
      } catch (err) {
        console.error(`[Twitter] Failed to fetch ${username}:`, err.message);
      }
    }
    return results;
  }

  // 使用 Nitter RSS 抓取（备用方案）
  async fetchWithNitter(accountIds = []) {
    const results = [];
    const aiKeywords = this.getAIKeywords();
    const excludeKeywords = this.getExcludeKeywords();
    
    // 尝试多个 Nitter 实例
    for (let attempt = 0; attempt < this.nitterInstances.length; attempt++) {
      const nitterBase = this.getNitterInstance();
      let successCount = 0;
      
      for (const username of accountIds) {
        try {
          // Nitter RSS 格式: https://nitter.net/username/rss
          const feedUrl = `${nitterBase}/${username}/rss`;
          const feed = await this.parser.parseURL(feedUrl);
          
          for (const item of feed.items) {
            const text = (item.title || item.contentSnippet || '').toLowerCase();
            
            // 过滤：必须包含AI关键词
            const hasAIKeyword = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
            if (!hasAIKeyword) continue;
            
            // 过滤：排除汽车等非AI内容
            const hasExcludeKeyword = excludeKeywords.some(kw => text.includes(kw.toLowerCase()));
            if (hasExcludeKeyword) continue;
            
            // 从 Nitter URL 提取 tweet ID
            const tweetId = this.extractTweetId(item.link);
            
            results.push(this.normalizeData({
              id: tweetId || item.guid || item.link,
              title: item.title?.substring(0, 100) || '',
              content: item.contentSnippet || item.title || '',
              author: username,
              author_id: username,
              url: item.link?.replace(nitterBase, 'https://twitter.com') || `https://twitter.com/${username}/status/${tweetId}`,
              published_at: item.pubDate || new Date().toISOString(),
              metrics: { engagement: 0 } // RSS 无法获取互动数据
            }));
          }
          
          successCount++;
          console.log(`[Twitter/Nitter] Fetched ${feed.items?.length || 0} tweets from ${username} via ${nitterBase}`);
        } catch (err) {
          console.error(`[Twitter/Nitter] Failed to fetch ${username} from ${nitterBase}:`, err.message);
        }
      }
      
      // 如果成功获取了数据，不再尝试其他实例
      if (successCount > 0) {
        break;
      }
      
      // 否则切换到下一个实例
      this.rotateNitterInstance();
    }
    
    return results;
  }
  
  // 从 Nitter URL 提取 tweet ID
  extractTweetId(url) {
    if (!url) return null;
    const match = url.match(/status\/(\d+)/);
    return match ? match[1] : null;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content,
      author: item.author,
      author_id: item.author_id,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: item.metrics || { engagement: 0 }
    };
  }
}

// Reddit 适配器（使用 JSON API）
class RedditAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'reddit';
    this.parser = new Parser({ timeout: 15000 });
    this.rsshubUrl = config.rsshubUrl || 'https://rsshub.app';
  }

  async fetchHotspots(accountIds = []) {
    const results = [];

    // AI 行业关键词
    const aiKeywords = ['AI', 'artificial intelligence', 'machine learning', 'deep learning', 'LLM', 'GPT', 'ChatGPT', 'Claude', 'Gemini', 'transformer', 'neural network', 'OpenAI', 'Anthropic'];
    
    for (const subreddit of accountIds) {
      try {
        // 使用 RSSHub 作为 Reddit 的 RSS 源
        const feedUrl = `${this.rsshubUrl}/reddit/r/${subreddit}`;
        console.log(`[Reddit] Fetching via RSSHub: ${feedUrl}`);
        
        const feed = await this.parser.parseURL(feedUrl);
        
        for (const item of feed.items) {
          const text = (item.title + ' ' + item.contentSnippet).toLowerCase();
          
          // 过滤：只保留AI相关内容
          const hasAIKeyword = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
          if (!hasAIKeyword) continue;
          
          // 从 RSSHub URL 提取 Reddit 链接
          const redditUrl = item.link || '';
          const postId = this.extractPostId(redditUrl);
          
          const normalized = this.normalizeData({
            id: postId || item.guid,
            title: item.title,
            content: item.contentSnippet || '',
            author: item.author || 'unknown',
            url: redditUrl,
            score: 0, // RSS 无法获取分数
            num_comments: 0,
            published_at: item.pubDate,
            subreddit: subreddit
          });
          results.push(normalized);
        }
        
        console.log(`[Reddit] Fetched ${feed.items?.length || 0} posts from r/${subreddit}`);
      } catch (err) {
        console.error(`[Reddit] Failed to fetch r/${subreddit}:`, err.message);
      }
    }
    return results;
  }
  
  extractPostId(url) {
    // 从 Reddit URL 提取 post ID
    // https://www.reddit.com/r/artificial/comments/abc123/title/
    const match = url.match(/\/comments\/([a-z0-9]+)/i);
    return match ? match[1] : null;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content || '',
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: new Date(item.created_utc * 1000).toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        score: item.score || 0,
        comments: item.num_comments || 0,
        engagement: (item.score || 0) + (item.num_comments || 0)
      }
    };
  }
}

// Hacker News 适配器（使用 Algolia API）
class HackerNewsAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'hackernews';
  }

  async fetchHotspots(accountIds = []) {
    // HN 不需要账号列表，直接抓取热门
    try {
      const response = await axios.get('https://hn.algolia.com/api/v1/search_by_date?tags=front_page&hitsPerPage=30');
      const hits = response.data.hits;

      return hits.map(item => this.normalizeData(item));
    } catch (err) {
      console.error('[HackerNews] Failed to fetch:', err.message);
      return [];
    }
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.url || item.story_text || '',
      author: item.author,
      author_id: item.author,
      url: item.url || `https://news.ycombinator.com/item?id=${item.objectID}`,
      published_at: new Date(item.created_at).toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        points: item.points || 0,
        num_comments: item.num_comments || 0,
        engagement: (item.points || 0) + (item.num_comments || 0)
      }
    };
  }
}

// Product Hunt 适配器（RSS）
const Parser = require('rss-parser');

class ProductHuntAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'producthunt';
    this.parser = new Parser();
  }

  async fetchHotspots(accountIds = []) {
    try {
      const feed = await this.parser.parseURL('https://www.producthunt.com/feed?format=rss');

      return feed.items.map(item => this.normalizeData({
        id: item.guid || item.link,
        title: item.title,
        content: item.contentSnippet || item.content || '',
        author: item.creator || 'Product Hunt',
        url: item.link,
        published_at: item.pubDate
      }));
    } catch (err) {
      console.error('[ProductHunt] Failed to fetch:', err.message);
      return [];
    }
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content || '',
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: { engagement: 0 }
    };
  }
}

// LinkedIn 适配器（需登录，使用 Puppeteer）
class LinkedInAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'linkedin';
    this.puppeteer = require('puppeteer');
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    const browser = await this.puppeteer.launch({
      headless: 'new',
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

    try {
      const page = await browser.newPage();
      await page.setUserAgent('Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36');

      // LinkedIn 需要登录，这里简化处理：抓取公开 feed
      await page.goto('https://www.linkedin.com/feed/', { waitUntil: 'networkidle2', timeout: 30000 });

      // 提取帖子
      const posts = await page.evaluate(() => {
        const items = [];
        const nodes = document.querySelectorAll('.feed-shared-update-v2');
        nodes.forEach(node => {
          const titleEl = node.querySelector('.feed-shared-actor__name');
          const contentEl = node.querySelector('.feed-shared-text');
          const linkEl = node.querySelector('a[href*="/posts/"]');
          items.push({
            title: titleEl?.innerText?.substring(0, 100) || '',
            content: contentEl?.innerText || '',
            url: linkEl?.href || '',
            author: titleEl?.innerText?.split(' ')[0] || ''
          });
        });
        return items;
      });

      for (const post of posts) {
        results.push(this.normalizeData({
          ...post,
          id: post.url,
          published_at: new Date().toISOString()
        }));
      }

      await browser.close();
    } catch (err) {
      await browser.close();
      console.error('[LinkedIn] Failed:', err.message);
    }

    return results;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content,
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: { engagement: 0 }
    };
  }
}

// 模拟数据生成器（用于演示无法访问的平台）
function generateMockHotspots(platform, count = 5) {
  const aiTopics = [
    { title: 'OpenAI 发布 GPT-5 预览版，性能提升 40%', author: 'AI前线', engagement: 1200 },
    { title: 'Claude 4 即将上线，支持 500K 上下文', author: '科技日报', engagement: 980 },
    { title: 'Midjourney V7 发布，图像生成质量大幅提升', author: '设计周刊', engagement: 850 },
    { title: 'Google DeepMind 推出新一代 AlphaGo', author: '量子位', engagement: 720 },
    { title: 'Meta 开源 Llama 4，参数量达 2T', author: '机器之心', engagement: 650 },
    { title: 'ChatGPT 中文版正式上线', author: '36氪', engagement: 540 },
    { title: 'AI 编程助手 Cursor 融资 5 亿美元', author: '投资界', engagement: 480 },
    { title: 'Stable Diffusion 3 开源发布', author: '开源中国', engagement: 420 }
  ];
  
  return aiTopics.slice(0, count).map((topic, i) => ({
    id: `${platform}_mock_${Date.now()}_${i}`,
    platform: platform,
    title: topic.title,
    content: `${topic.title} - 这是模拟数据，用于展示平台功能`,
    author: topic.author,
    author_id: topic.author,
    url: `https://example.com/${platform}/${i}`,
    published_at: new Date(Date.now() - i * 3600000).toISOString(),
    crawled_at: new Date().toISOString(),
    metrics: { engagement: topic.engagement, views: topic.engagement * 10 },
    score: Math.min(100, Math.round(topic.engagement / 20))
  }));
}

// 国内平台适配器

// 微博适配器（使用微博热搜 API + 模拟数据备用）
class WeiboAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'weibo';
    this.parser = new Parser();
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 关键词过滤
    const aiKeywords = ['AI', '人工智能', '大模型', 'LLM', 'GPT', 'Claude', 'Agent', '机器学习', '深度学习', 'ChatGPT', 'OpenAI', '智谱', '文心一言', '通义千问', 'Kimi'];
    
    try {
      // 使用微博热搜 API
      const response = await fetch('https://weibo.com/ajax/side/hotSearch', {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
          'Accept': 'application/json'
        }
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data = await response.json();
      const hotList = data.data?.realtime || [];
      
      // 过滤 AI 相关内容
      for (const item of hotList) {
        const title = item.note || '';
        const isAI = aiKeywords.some(kw => title.toLowerCase().includes(kw.toLowerCase()));
        
        if (isAI) {
          results.push(this.normalizeData({
            id: `weibo_${item.mid || Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
            title: title,
            content: item.word_scheme || title,
            author: '微博热搜',
            url: `https://s.weibo.com/weibo?q=${encodeURIComponent(title)}`,
            published_at: new Date().toISOString(),
            metrics: {
              rank: item.rank || 0,
              hot: item.raw_hot || 0,
              category: item.category || 'general'
            }
          }));
        }
      }
      
      console.log(`[Weibo] Fetched ${results.length} AI-related hot topics`);
    } catch (err) {
      console.error('[Weibo] Failed to fetch hot search:', err.message);
      // Fallback: 尝试 RSSHub
      if (accountIds.length > 0) {
        const rssResults = await this.fetchFromRSSHub(accountIds);
        if (rssResults.length > 0) return rssResults;
      }
    }
    
    // 返回已抓取的结果（即使没有达到预期数量）
    return results;
    
    return results;
  }
  
  async fetchFromRSSHub(accountIds) {
    const results = [];
    const baseUrl = this.config.weiboRss || 'https://rsshub.app/weibo';
    
    for (const uid of accountIds) {
      try {
        const feed = await this.parser.parseURL(`${baseUrl}/user/${uid}`);
        for (const item of feed.items) {
          results.push(this.normalizeData({
            id: item.guid || item.link,
            title: item.title,
            content: item.contentSnippet || '',
            author: item.author || uid,
            url: item.link,
            published_at: item.pubDate
          }));
        }
      } catch (err) {
        console.error(`[Weibo RSSHub] Failed to fetch user ${uid}:`, err.message);
      }
    }
    return results;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title.substring(0, 100),
      content: item.content || '',
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: { engagement: 0 }
    };
  }
}

// 小红书适配器（使用搜索 API）
class XiaohongshuAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'xiaohongshu';
    this.parser = new Parser();
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 关键词
    const aiKeywords = ['AI', '人工智能', '大模型', 'ChatGPT', 'Claude', 'Midjourney', 'Stable Diffusion', 'AI绘画', 'AI工具'];
    
    try {
      // 使用小红书搜索 API 获取 AI 相关笔记
      for (const keyword of aiKeywords.slice(0, 3)) { // 限制关键词数量
        try {
          const searchUrl = `https://www.xiaohongshu.com/search_result?keyword=${encodeURIComponent(keyword)}`;
          
          // 由于小红书有反爬，这里使用模拟数据
          // 实际部署时需要使用无头浏览器或官方 API
          console.log(`[小红书] Searching for: ${keyword}`);
          
          // 模拟延迟
          await new Promise(r => setTimeout(r, 500));
        } catch (err) {
          console.error(`[小红书] Search error for ${keyword}:`, err.message);
        }
      }
      
      // 尝试 RSSHub 作为备用
      if (accountIds.length > 0) {
        const rssResults = await this.fetchFromRSSHub(accountIds);
        results.push(...rssResults);
      }
      
      console.log(`[小红书] Fetched ${results.length} items`);
    } catch (err) {
      console.error('[小红书] Failed to fetch:', err.message);
    }
    
    return results;
  }
  
  async fetchFromRSSHub(accountIds) {
    const results = [];
    const baseUrl = this.config.rsshubUrl || 'https://rsshub.app';
    
    for (const userId of accountIds) {
      try {
        const feed = await this.parser.parseURL(`${baseUrl}/xiaohongshu/user/${userId}`);
        for (const item of feed.items) {
          results.push(this.normalizeData({
            id: item.guid || item.link,
            title: item.title,
            content: item.contentSnippet || '',
            author: item.author || '',
            url: item.link,
            published_at: item.pubDate
          }));
        }
      } catch (err) {
        console.error(`[小红书 RSSHub] Failed to fetch user ${userId}:`, err.message);
      }
    }
    return results;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content || '',
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: { engagement: 0 }
    };
  }
}

// 即刻适配器（使用 RSSHub）
class JikeAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'jike';
    this.parser = new Parser();
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 相关话题
    const aiTopics = ['AI', '人工智能', 'ChatGPT', '大模型'];
    
    try {
      // 尝试 RSSHub 的即刻主题 RSS
      for (const topic of aiTopics) {
        try {
          const feed = await this.parser.parseURL(`https://rsshub.app/jike/topic/${encodeURIComponent(topic)}`);
          for (const item of feed.items) {
            results.push(this.normalizeData({
              id: item.guid || item.link,
              title: item.title,
              content: item.contentSnippet || '',
              author: item.author || '即刻用户',
              url: item.link,
              published_at: item.pubDate
            }));
          }
        } catch (err) {
          console.error(`[即刻] Failed to fetch topic ${topic}:`, err.message);
        }
      }
      
      console.log(`[即刻] Fetched ${results.length} items`);
    } catch (err) {
      console.error('[即刻] Failed to fetch:', err.message);
    }
    
    return results;
  }
  
  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content || '',
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: { engagement: 0 }
    };
  }
}

// 掘金适配器（RSS）
class juejinAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'juejin';
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 关键词过滤
    const aiKeywords = ['AI', '人工智能', '大模型', 'LLM', 'GPT', 'Claude', 'Agent', '机器学习', '深度学习', 'transformer', 'OpenAI', 'ChatGPT', 'Copilot', 'Cursor', 'Codeium'];
    
    try {
      // 使用掘金官方 API 获取热榜
      const response = await axios.get('https://api.juejin.cn/content_api/v1/content/article_rank', {
        params: {
          category_id: '1', // 综合
          type: 'hot',
          aid: '2608',
          uuid: '7145810834687166991',
          spider: '0'
        },
        headers: { 
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 15000
      });

      if (response.data.err_no !== 0) {
        console.error('[掘金] API error:', response.data.err_msg);
        return results;
      }

      const articles = response.data.data || [];
      
      for (const article of articles) {
        const content = article.content || {};
        const counter = article.content_counter || {};
        const author = article.author || {};
        
        const title = content.title || '';
        const text = title.toLowerCase();
        
        // 过滤：只保留AI相关内容
        const hasAIKeyword = aiKeywords.some(kw => 
          text.includes(kw.toLowerCase()) || 
          title.includes(kw)
        );
        if (!hasAIKeyword) continue;
        
        // 计算热度分数 (0-100)
        const viewCount = counter.view || 0;
        const likeCount = counter.like || 0;
        const collectCount = counter.collect || 0;
        const commentCount = counter.comment_count || 0;
        const hotRank = counter.hot_rank || 0;
        
        // 热度分数基于掘金的热榜排名
        const score = Math.min(100, Math.round(hotRank / 100));
        
        results.push(this.normalizeData({
          id: content.content_id,
          title: title,
          content: '', // API 不返回正文，后续通过浏览器获取
          author: author.name || 'Unknown',
          author_id: author.user_id || '',
          url: `https://juejin.cn/post/${content.content_id}`,
          published_at: new Date().toISOString(), // API 不返回时间
          metrics: {
            views: viewCount,
            likes: likeCount,
            collects: collectCount,
            comments: commentCount,
            hot_rank: hotRank,
            engagement: likeCount + collectCount + commentCount
          },
          score: score
        }));
      }
      
      console.log(`[掘金] Fetched ${results.length} AI-related articles from hot list`);
    } catch (err) {
      console.error('[掘金] Failed to fetch:', err.message);
    }
    
    return results;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content || '',
      author: item.author,
      author_id: item.author_id,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: item.metrics || { engagement: 0 },
      score: item.score || 0
    };
  }
}

// V2EX 适配器（使用官方 API + RSSHub 备用）
class V2EXAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'v2ex';
    this.parser = new Parser();
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    const aiKeywords = ['AI', '人工智能', 'ChatGPT', 'Claude', '大模型', 'LLM', 'OpenAI', '机器学习'];
    
    try {
      // 使用 V2EX 官方 API
      const response = await fetch('https://www.v2ex.com/api/topics/hot.json', {
        headers: { 'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36' }
      });
      
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      
      const topics = await response.json();
      
      for (const topic of topics) {
        const title = topic.title || '';
        const content = topic.content || '';
        const text = (title + ' ' + content).toLowerCase();
        
        if (aiKeywords.some(kw => text.includes(kw.toLowerCase()))) {
          results.push(this.normalizeData({
            id: `v2ex_${topic.id}`,
            title: title,
            content: content,
            author: topic.member?.username || 'v2ex',
            author_id: topic.member?.id?.toString() || '',
            url: topic.url || `https://www.v2ex.com/t/${topic.id}`,
            published_at: new Date(topic.created * 1000).toISOString(),
            metrics: { replies: topic.replies || 0, views: topic.views || 0 }
          }));
        }
      }
      
      console.log(`[V2EX] Fetched ${results.length} AI-related topics`);
    } catch (err) {
      console.error('[V2EX] API failed:', err.message);
      // Fallback to RSSHub
      try {
        const feed = await this.parser.parseURL('https://rsshub.app/v2ex/hot');
        return feed.items.map(item => this.normalizeData({
          id: item.guid || item.link,
          title: item.title,
          content: item.contentSnippet || '',
          author: item.author || 'v2ex',
          url: item.link,
          published_at: item.pubDate
        }));
      } catch (rssErr) {
        console.error('[V2EX RSSHub] Failed:', rssErr.message);
      }
    }
    
    return results;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content || '',
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: item.metrics || { engagement: 0 }
    };
  }
}

// 中国大模型海外监控平台（Twitter/X 上的中国AI账号，使用 Nitter RSS 备用）
class ChinaAIAdapter extends PlatformAdapter {
  constructor(config) {
    super(config);
    this.name = 'chinaai';
    this.parser = new Parser({
      timeout: 15000,
      headers: {
        'User-Agent': 'Mozilla/5.0 (compatible; HotspotBot/1.0)'
      }
    });
    this.nitterInstances = [
      'https://nitter.privacydev.net',
      'https://nitter.poast.org',
      'https://nitter.datura.network'
    ];
    this.currentInstanceIndex = 0;
    
    // 尝试使用官方 API
    this.useOfficialApi = false;
    if (config.bearerToken && !config.bearerToken.startsWith('sk-or-')) {
      try {
        this.client = new TwitterApi(config.bearerToken);
        this.useOfficialApi = true;
        this.apiCallCount = 0;
        this.maxApiCallsPerMonth = 1500;
        this.monthlyResetDate = new Date();
        console.log('[ChinaAI] Using official Twitter API');
      } catch (err) {
        console.warn('[ChinaAI] Invalid Bearer Token, falling back to Nitter RSS');
      }
    } else {
      console.log('[ChinaAI] Using Nitter RSS (no valid API token)');
    }
  }
  
  getNitterInstance() {
    return this.nitterInstances[this.currentInstanceIndex];
  }
  
  rotateNitterInstance() {
    this.currentInstanceIndex = (this.currentInstanceIndex + 1) % this.nitterInstances.length;
    console.log(`[ChinaAI] Switched to Nitter instance: ${this.getNitterInstance()}`);
  }
  
  hasQuota() {
    if (!this.useOfficialApi) return false;
    const now = new Date();
    if (now.getMonth() !== this.monthlyResetDate.getMonth()) {
      this.apiCallCount = 0;
      this.monthlyResetDate = now;
    }
    return this.apiCallCount < this.maxApiCallsPerMonth;
  }

  // 中国大模型相关关键词
  getChinaAIKeywords() {
    return [
      'deepseek', 'qwen', 'chatglm', 'baichuan', 'ernie', 'pangu',
      'stepfun', 'step-claw', '月之暗面', 'kimi', '智谱', '百川',
      '文心一言', '通义千问', '盘古大模型', '阶跃星辰', '零一万物',
      'minimax', '商汤', 'sensechat', '讯飞星火', 'chatlaw'
    ];
  }

  async fetchHotspots(accountIds = []) {
    if (this.useOfficialApi && this.hasQuota()) {
      try {
        return await this.fetchWithOfficialApi(accountIds);
      } catch (err) {
        console.warn('[ChinaAI] Official API failed, falling back to Nitter:', err.message);
      }
    }
    return await this.fetchWithNitter(accountIds);
  }

  async fetchWithOfficialApi(accountIds = []) {
    const results = [];
    const chinaAIKeywords = this.getChinaAIKeywords();

    for (const username of accountIds) {
      try {
        if (!this.hasQuota()) break;
        
        const user = await this.client.v2.userByUsername(username);
        if (!user.data) continue;

        const tweets = await this.client.v2.userTimeline(user.data.id, {
          max_results: 10,
          'tweet.fields': ['created_at', 'public_metrics', 'text'],
          exclude: ['retweets', 'replies']
        });
        
        this.apiCallCount += 2;

        for (const tweet of tweets.data?.data || []) {
          const text = tweet.text.toLowerCase();
          
          const hasChinaAI = chinaAIKeywords.some(kw => text.includes(kw.toLowerCase()));
          if (!hasChinaAI) continue;
          
          const engagement = (tweet.public_metrics?.like_count || 0) + 
                            (tweet.public_metrics?.retweet_count || 0) +
                            (tweet.public_metrics?.reply_count || 0);
          
          results.push(this.normalizeData({
            id: tweet.id,
            title: tweet.text.substring(0, 100),
            content: tweet.text,
            author: username,
            author_id: user.data.id,
            url: `https://twitter.com/${username}/status/${tweet.id}`,
            published_at: tweet.created_at,
            metrics: {
              likes: tweet.public_metrics?.like_count || 0,
              retweets: tweet.public_metrics?.retweet_count || 0,
              replies: tweet.public_metrics?.reply_count || 0,
              engagement
            }
          }));
        }
        console.log(`[ChinaAI] Fetched from ${username} (API: ${this.apiCallCount}/${this.maxApiCallsPerMonth})`);
      } catch (err) {
        console.error(`[ChinaAI] Failed ${username}:`, err.message);
      }
    }
    return results;
  }

  async fetchWithNitter(accountIds = []) {
    const results = [];
    const chinaAIKeywords = this.getChinaAIKeywords();
    
    for (let attempt = 0; attempt < this.nitterInstances.length; attempt++) {
      const nitterBase = this.getNitterInstance();
      let successCount = 0;
      
      for (const username of accountIds) {
        try {
          const feedUrl = `${nitterBase}/${username}/rss`;
          const feed = await this.parser.parseURL(feedUrl);
          
          for (const item of feed.items) {
            const text = (item.title || item.contentSnippet || '').toLowerCase();
            
            const hasChinaAI = chinaAIKeywords.some(kw => text.includes(kw.toLowerCase()));
            if (!hasChinaAI) continue;
            
            const tweetId = this.extractTweetId(item.link);
            
            results.push(this.normalizeData({
              id: tweetId || item.guid || item.link,
              title: item.title?.substring(0, 100) || '',
              content: item.contentSnippet || item.title || '',
              author: username,
              author_id: username,
              url: item.link?.replace(nitterBase, 'https://twitter.com') || `https://twitter.com/${username}/status/${tweetId}`,
              published_at: item.pubDate || new Date().toISOString(),
              metrics: { engagement: 0 }
            }));
          }
          
          successCount++;
          console.log(`[ChinaAI/Nitter] Fetched ${feed.items?.length || 0} tweets from ${username} via ${nitterBase}`);
        } catch (err) {
          console.error(`[ChinaAI/Nitter] Failed ${username} from ${nitterBase}:`, err.message);
        }
      }
      
      if (successCount > 0) break;
      this.rotateNitterInstance();
    }
    
    return results;
  }
  
  extractTweetId(url) {
    if (!url) return null;
    const match = url.match(/status\/(\d+)/);
    return match ? match[1] : null;
  }

  normalizeData(item) {
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.content,
      author: item.author,
      author_id: item.author_id,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: item.metrics || { engagement: 0 }
    };
  }
}

// Agent Browser Adapters (Token-efficient scraping)
const { AgentBrowserAdapter } = require('./agent-browser-adapter');
const { TwitterAgentBrowserAdapter } = require('./twitter-agent-browser');
const { WeiboAgentBrowserAdapter } = require('./weibo-agent-browser');
const { ZhihuAgentBrowserAdapter } = require('./zhihu-agent-browser');
const { GitHubAgentBrowserAdapter } = require('./github-agent-browser');
const { SanliuAgentBrowserAdapter } = require('./sanliu-agent-browser');
const { JiqizhixinAgentBrowserAdapter } = require('./jiqizhixin-agent-browser');

// 新增平台适配器 (v3.0 功能增强)
const { SanliuKrAgentBrowserAdapter } = require('./36kr-agent-browser');
const { GeekParkAgentBrowserAdapter } = require('./geekpark-agent-browser');
const { iFanrAgentBrowserAdapter } = require('./ifanr-agent-browser');
const { BilibiliAgentBrowserAdapter } = require('./bilibili-agent-browser');

module.exports = {
  PlatformAdapter,
  TwitterAdapter,
  RedditAdapter,
  HackerNewsAdapter,
  ProductHuntAdapter,
  LinkedInAdapter,
  WeiboAdapter,
  XiaohongshuAdapter,
  ChinaAIAdapter,
  JikeAdapter,
  juejinAdapter,
  V2EXAdapter,
  // Agent Browser adapters
  AgentBrowserAdapter,
  TwitterAgentBrowserAdapter,
  WeiboAgentBrowserAdapter,
  ZhihuAgentBrowserAdapter,
  GitHubAgentBrowserAdapter,
  SanliuAgentBrowserAdapter,
  JiqizhixinAgentBrowserAdapter,
  // 新增平台适配器 (v3.0)
  SanliuKrAgentBrowserAdapter,    // 36氪
  GeekParkAgentBrowserAdapter,    // 极客公园
  iFanrAgentBrowserAdapter,       // 爱范儿
  BilibiliAgentBrowserAdapter     // Bilibili
};