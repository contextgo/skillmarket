/**
 * 掘金浏览器适配器 - 获取文章正文内容
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class JuejinBrowserAdapter extends AgentBrowserAdapter {
  constructor(config = {}) {
    super(config);
    this.name = 'juejin';
    this.baseUrl = 'https://juejin.cn';
  }

  async fetchArticleContent(articleId) {
    const url = `${this.baseUrl}/post/${articleId}`;
    
    try {
      // 使用浏览器获取文章详情
      const result = await this.browserFetch(url, {
        waitFor: '.article-content',
        extract: {
          content: '.article-content',
          summary: '.article-summary',
          tags: '.tag-list .tag'
        }
      });

      if (result && result.content) {
        // 清理内容
        return this.cleanContent(result.content);
      }
    } catch (err) {
      console.error(`[掘金浏览器] 获取文章 ${articleId} 失败:`, err.message);
    }

    return '';
  }

  cleanContent(html) {
    if (!html) return '';
    
    // 移除 HTML 标签
    let text = html
      .replace(/<script[^>]*>.*?<\/script>/gs, '')
      .replace(/<style[^>]*>.*?<\/style>/gs, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
    
    // 截取前 500 字符作为概述
    if (text.length > 500) {
      text = text.substring(0, 500) + '...';
    }
    
    return text;
  }

  async enrichHotspots(hotspots) {
    console.log(`[掘金浏览器] 开始为 ${hotspots.length} 条热点获取内容...`);
    
    const enriched = [];
    for (let i = 0; i < hotspots.length; i++) {
      const h = hotspots[i];
      console.log(`[掘金浏览器] [${i + 1}/${hotspots.length}] 获取: ${h.title.substring(0, 40)}...`);
      
      try {
        const content = await this.fetchArticleContent(h.id);
        if (content) {
          enriched.push({
            ...h,
            content: content
          });
        } else {
          enriched.push(h);
        }
        
        // 延迟避免请求过快
        await this.delay(1000);
      } catch (err) {
        console.error(`[掘金浏览器] 处理失败:`, err.message);
        enriched.push(h);
      }
    }
    
    return enriched;
  }

  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

module.exports = { JuejinBrowserAdapter };
