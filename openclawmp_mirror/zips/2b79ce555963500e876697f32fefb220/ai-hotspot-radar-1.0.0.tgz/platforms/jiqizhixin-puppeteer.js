/**
 * 机器之心 Puppeteer Adapter
 * 使用 Puppeteer 直接抓取
 */

const puppeteer = require('puppeteer-core');

class JiqizhixinPuppeteerAdapter {
  constructor(config) {
    this.name = 'jiqizhixin';
    this.baseUrl = 'https://www.jiqizhixin.com';
    this.articlesUrl = 'https://www.jiqizhixin.com/articles';
  }

  async fetchHotspots() {
    const results = [];
    
    console.log('[JiqizhixinPuppeteer] Fetching articles...');
    
    const browser = await puppeteer.launch({
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    try {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });
      
      // 访问文章列表页
      await page.goto(this.articlesUrl, { waitUntil: 'networkidle2', timeout: 30000 });
      
      // 等待文章加载
      await page.waitForSelector('.article-item, .article-list-item, article', { timeout: 10000 });
      
      // 提取文章
      const articles = await page.evaluate(() => {
        const items = [];
        
        // 尝试多种选择器
        const selectors = [
          '.article-item',
          '.article-list-item',
          'article',
          '.post-item',
          '[class*="article"]'
        ];
        
        let elements = [];
        for (const selector of selectors) {
          elements = document.querySelectorAll(selector);
          if (elements.length > 0) break;
        }
        
        elements.forEach((el, index) => {
          try {
            // 提取标题
            const titleEl = el.querySelector('h2, h3, .title, a[href*="/articles/"]');
            const title = titleEl ? titleEl.textContent.trim() : '';
            
            // 提取链接
            const linkEl = el.querySelector('a[href*="/articles/"]');
            const href = linkEl ? linkEl.href : '';
            const articleId = href.match(/articles\/(\d+)/)?.[1] || `article_${index}`;
            
            // 提取摘要
            const summaryEl = el.querySelector('.summary, .desc, p');
            const summary = summaryEl ? summaryEl.textContent.trim() : '';
            
            // 提取作者
            const authorEl = el.querySelector('.author, [class*="author"]');
            const author = authorEl ? authorEl.textContent.trim() : '机器之心';
            
            if (title && href) {
              items.push({
                id: articleId,
                title: title,
                content: summary || title,
                url: href,
                author: author
              });
            }
          } catch (e) {
            // 忽略错误
          }
        });
        
        return items;
      });
      
      console.log(`[JiqizhixinPuppeteer] Found ${articles.length} articles`);
      
      // 转换为标准格式
      for (const article of articles.slice(0, 20)) {
        results.push({
          id: `jqx_${article.id}`,
          platform: this.name,
          title: article.title,
          content: article.content,
          author: article.author,
          author_id: article.author,
          url: article.url,
          published_at: new Date().toISOString(),
          crawled_at: new Date().toISOString(),
          metrics: {
            views: 0
          },
          score: 75,
          avg_score: 75,
          is_ai_related: true
        });
      }
      
    } catch (err) {
      console.error('[JiqizhixinPuppeteer] Failed:', err.message);
    } finally {
      await browser.close();
    }
    
    return results;
  }
}

module.exports = { JiqizhixinPuppeteerAdapter };
