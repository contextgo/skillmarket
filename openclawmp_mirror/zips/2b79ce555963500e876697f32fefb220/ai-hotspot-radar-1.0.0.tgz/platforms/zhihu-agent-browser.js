/**
 * 知乎 (Zhihu) Agent Browser Adapter
 * 使用 AI-optimized browser automation 抓取知乎 AI 相关内容
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class ZhihuAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config = {}) {
    super(config);
    this.name = 'zhihu';
    this.baseUrl = 'https://www.zhihu.com';
    this.searchKeywords = [
      '人工智能',
      '大模型',
      'ChatGPT',
      'OpenAI',
      '机器学习',
      '深度学习',
      'AI应用',
      '具身智能',
      'AI Agent'
    ];
    // AI 相关话题
    this.aiTopics = [
      '19559450',   // 人工智能话题
      '19559451',   // 机器学习话题
      '19559452',   // 深度学习话题
      '19559453',   // 神经网络话题
      '19559454',   // 自然语言处理话题
    ];
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 关键词用于内容过滤
    const aiKeywords = [
      'AI', '人工智能', '大模型', 'LLM', 'GPT', 'ChatGPT', 'Claude',
      '机器学习', '深度学习', '神经网络', 'transformer',
      'OpenAI', 'Anthropic', 'Google', 'Gemini',
      '智谱', '文心一言', '通义千问', 'Kimi', '阶跃星辰',
      'AI应用', 'AI Agent', '智能体', '具身智能'
    ];

    try {
      // 1. 抓取 AI 话题下的热门回答
      for (const topicId of this.aiTopics) {
        try {
          const topicUrl = `${this.baseUrl}/topic/${topicId}/hot`;
          console.log(`[Zhihu] Fetching topic: ${topicId}`);
          
          const feedItems = await this.fetchWithAgentBrowser(topicUrl, {
            waitForSelector: '.ContentItem, .List-item, .Card',
            extractData: () => {
              const items = [];
              const contentElements = document.querySelectorAll('.ContentItem, .List-item, .Card');
              
              contentElements.forEach((el, index) => {
                if (index >= 15) return;
                
                const titleEl = el.querySelector('.ContentItem-title, .ContentItem-title a, h2 a, .title');
                const contentEl = el.querySelector('.RichContent-inner, .RichContent, .content');
                const authorEl = el.querySelector('.AuthorInfo-name, .author, .UserLink');
                const voteEl = el.querySelector('.VoteButton--up, .VoteButton, .vote-count');
                const commentEl = el.querySelector('.ContentItem-action, .comment-count');
                const linkEl = el.querySelector('a');
                
                if (titleEl || contentEl) {
                  items.push({
                    title: titleEl?.textContent?.trim() || contentEl?.textContent?.trim().substring(0, 100) || '',
                    content: contentEl?.textContent?.trim().substring(0, 500) || '',
                    author: authorEl?.textContent?.trim() || '知乎用户',
                    votes: voteEl?.textContent?.trim() || '0',
                    comments: commentEl?.textContent?.trim() || '0',
                    url: linkEl?.href || window.location.href
                  });
                }
              });
              
              return items;
            }
          });

          // 过滤并添加结果
          for (const item of feedItems) {
            const text = `${item.title} ${item.content}`.toLowerCase();
            const isAI = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
            
            if (isAI && item.title) {
              results.push(this.normalizeData({
                id: `zhihu_topic_${topicId}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                title: item.title,
                content: item.content,
                author: item.author,
                url: item.url.startsWith('http') ? item.url : `${this.baseUrl}${item.url}`,
                metrics: {
                  votes: this.parseNumber(item.votes),
                  comments: this.parseNumber(item.comments)
                }
              }));
            }
          }
          
          console.log(`[Zhihu] Fetched ${feedItems.length} items from topic ${topicId}`);
          
          // 添加延迟
          await new Promise(r => setTimeout(r, 3000));
          
        } catch (err) {
          console.error(`[Zhihu] Failed to fetch topic ${topicId}:`, err.message);
        }
      }

      // 2. 搜索 AI 相关问题
      for (const keyword of this.searchKeywords.slice(0, 3)) { // 限制搜索数量
        try {
          const searchUrl = `${this.baseUrl}/search?type=content&q=${encodeURIComponent(keyword)}`;
          console.log(`[Zhihu] Searching: ${keyword}`);
          
          const feedItems = await this.fetchWithAgentBrowser(searchUrl, {
            waitForSelector: '.SearchResult-Card, .ContentItem, .List-item',
            extractData: () => {
              const items = [];
              const resultElements = document.querySelectorAll('.SearchResult-Card, .ContentItem, .List-item');
              
              resultElements.forEach((el, index) => {
                if (index >= 10) return;
                
                const titleEl = el.querySelector('.ContentItem-title, .title, h2 a, h3 a');
                const contentEl = el.querySelector('.RichContent-inner, .RichContent, .content');
                const authorEl = el.querySelector('.AuthorInfo-name, .author');
                const voteEl = el.querySelector('.VoteButton--up, .vote-count');
                const linkEl = el.querySelector('a');
                
                if (titleEl) {
                  items.push({
                    title: titleEl.textContent?.trim() || '',
                    content: contentEl?.textContent?.trim().substring(0, 300) || '',
                    author: authorEl?.textContent?.trim() || '知乎用户',
                    votes: voteEl?.textContent?.trim() || '0',
                    url: linkEl?.href || ''
                  });
                }
              });
              
              return items;
            }
          });

          // 过滤并添加结果
          for (const item of feedItems) {
            const text = `${item.title} ${item.content}`.toLowerCase();
            const isAI = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
            
            if (isAI && item.title) {
              results.push(this.normalizeData({
                id: `zhihu_search_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
                title: item.title,
                content: item.content,
                author: item.author,
                url: item.url.startsWith('http') ? item.url : `${this.baseUrl}${item.url}`,
                metrics: {
                  votes: this.parseNumber(item.votes),
                  engagement: this.parseNumber(item.votes)
                }
              }));
            }
          }
          
          console.log(`[Zhihu] Fetched ${feedItems.length} search results for: ${keyword}`);
          
          // 添加延迟
          await new Promise(r => setTimeout(r, 3000));
          
        } catch (err) {
          console.error(`[Zhihu] Search error for ${keyword}:`, err.message);
        }
      }
      
      console.log(`[Zhihu] Total AI-related items: ${results.length}`);
    } catch (err) {
      console.error('[Zhihu] Adapter error:', err.message);
    }
    
    return results;
  }

  parseNumber(numStr) {
    if (!numStr) return 0;
    const cleanStr = numStr.replace(/[^\d.K万]/g, '');
    const num = parseFloat(cleanStr);
    if (cleanStr.includes('K') || cleanStr.includes('k')) return Math.round(num * 1000);
    if (cleanStr.includes('万')) return Math.round(num * 10000);
    return num || 0;
  }

  normalizeData(item) {
    const votes = item.metrics?.votes || 0;
    const comments = item.metrics?.comments || 0;
    
    return {
      id: item.id,
      platform: this.name,
      title: item.title.substring(0, 200),
      content: item.content || item.title,
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at || new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        votes: votes,
        comments: comments,
        engagement: votes + comments * 2
      }
    };
  }
}

module.exports = { ZhihuAgentBrowserAdapter };
