/**
 * Reddit Puppeteer Adapter
 * 使用 Puppeteer 直接抓取 r/artificial
 */

const puppeteer = require('puppeteer-core');

class RedditPuppeteerAdapter {
  constructor(config) {
    this.name = 'reddit';
    this.baseUrl = 'https://www.reddit.com';
    this.targetUrl = 'https://www.reddit.com/r/artificial/hot/';
  }

  async fetchHotspots() {
    const results = [];
    
    console.log('[RedditPuppeteer] Fetching from ' + this.targetUrl);
    
    const browser = await puppeteer.launch({
      executablePath: '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
    
    try {
      const page = await browser.newPage();
      await page.setViewport({ width: 1280, height: 800 });
      
      // 访问 Reddit
      await page.goto(this.targetUrl, { waitUntil: 'networkidle2', timeout: 60000 });
      
      // 等待内容加载
      await new Promise(r => setTimeout(r, 8000));
      
      // 检查页面是否加载成功
      const postCount = await page.evaluate(() => document.querySelectorAll('shreddit-post').length);
      console.log(`[RedditPuppeteer] Found ${postCount} shreddit-post elements`);
      
      // 提取帖子（使用 shreddit-post 自定义元素）
      const posts = await page.evaluate(() => {
        const posts = [];
        
        // Reddit 使用 shreddit-post 自定义元素
        const postElements = document.querySelectorAll('shreddit-post');
        console.log(`[RedditPuppeteer:page] Found ${postElements.length} posts in page context`);
        
        postElements.forEach((el, index) => {
          try {
            // 从自定义元素属性获取数据
            const permalink = el.getAttribute('permalink');
            const titleSlot = el.querySelector('[slot="title"]');
            const title = titleSlot ? titleSlot.textContent.trim() : '';
            const commentCount = parseInt(el.getAttribute('comment-count') || '0');
            
            // 从 permalink 提取 post ID
            const postId = permalink ? permalink.match(/comments\/(\w+)/)?.[1] : `post_${index}`;
            const url = permalink ? 'https://www.reddit.com' + permalink : '';
            
            // 尝试获取作者（Reddit 使用 /user/ 或 /u/）
            const authorEl = el.querySelector('a[href^="/user/"]') || el.querySelector('a[href^="/u/"]');
            const author = authorEl ? authorEl.textContent.replace(/^u\//, '').trim() : 'unknown';
            
            if (title && url) {
              posts.push({
                id: postId,
                title: title,
                url: url,
                author: author,
                comments: commentCount
              });
            }
          } catch (e) {
            // 忽略错误
          }
        });
        
        return posts;
      });
      
      console.log(`[RedditPuppeteer] Found ${posts.length} posts`);
      
      // 转换为标准格式
      for (const post of posts.slice(0, 25)) {
        // 计算热度分数（基于评论数）
        const score = Math.min(100, Math.round(post.comments * 2 + 50));
        
        results.push({
          id: `reddit_${post.id}`,
          platform: this.name,
          title: post.title,
          content: post.title,
          author: post.author,
          author_id: post.author,
          url: post.url,
          published_at: new Date().toISOString(),
          crawled_at: new Date().toISOString(),
          metrics: {
            comments: post.comments,
            engagement: post.comments
          },
          score: score,
          avg_score: score,
          is_ai_related: true
        });
      }
      
    } catch (err) {
      console.error('[RedditPuppeteer] Failed:', err.message);
    } finally {
      await browser.close();
    }
    
    return results;
  }
}

module.exports = { RedditPuppeteerAdapter };
