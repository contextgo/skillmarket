/**
 * 36Kr (36氪) Adapter using Agent Browser
 * Scrapes 36kr.com for AI news and articles
 * 
 * UPDATED: Use /information/web_news/ instead of search (bypasses anti-bot)
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class SanliuAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config) {
    super(config);
    this.name = '36kr';
    this.baseUrl = 'https://36kr.com';
    // UPDATED: Use news page instead of search (avoids anti-bot)
    this.newsUrl = 'https://36kr.com/information/web_news/';
    
    // AI 关键词
    this.aiKeywords = [
      'AI', '人工智能', '大模型', 'LLM', 'GPT', 'Claude', 'ChatGPT',
      'OpenAI', '机器学习', '深度学习', '神经网络', 'Transformer',
      '文心一言', '通义千问', 'Kimi', '智谱', '豆包',
      '算法', '模型训练', '推理', '提示词', 'RAG',
      'AI芯片', 'AI应用', 'AI创业', 'AI投资',
      'Seedance', 'Copilot', 'Agent', '智能体', 'Token',
      'DeepSeek', '字节', 'Siri', 'OpenAI', 'Anthropic'
    ];
  }

  async fetchHotspots() {
    const results = [];
    
    try {
      console.log('[36krAgentBrowser] Fetching news from ' + this.newsUrl);
      
      // Open news page (not search page - avoids anti-bot)
      await this.open(this.newsUrl);
      await this.wait(5000); // Wait for JS rendering
      
      // Extract articles using JavaScript evaluation
      const articles = await this.extractArticlesWithJS();
      
      console.log(`[36krAgentBrowser] Found ${articles.length} AI articles`);
      
      for (const article of articles.slice(0, 15)) {
        results.push(this.normalizeData(article));
      }
      
    } catch (err) {
      console.error('[36krAgentBrowser] Failed:', err.message);
    }
    
    await this.close();
    return results;
  }

  async extractArticlesWithJS() {
    try {
      // Use JavaScript to extract articles from the rendered page
      const jsCode = `
        (() => {
          const articles = [];
          const seen = new Set();
          
          // Find all article links
          document.querySelectorAll('a[href^="/p/"]').forEach(link => {
            const title = link.textContent.trim();
            const href = link.href;
            
            // Filter: length check and AI keywords
            if (title.length > 15 && title.length < 100 && !seen.has(title)) {
              const aiKeywords = ${JSON.stringify(this.aiKeywords)};
              const isAI = aiKeywords.some(kw => title.includes(kw));
              
              if (isAI) {
                seen.add(title);
                articles.push({
                  title: title,
                  url: href,
                  id: href.match(/\\/p\\/(\\d+)/)?.[1] || Date.now()
                });
              }
            }
          });
          
          return articles.slice(0, 15);
        })()
      `;
      
      // Execute via agent-browser eval
      const result = this.exec(`eval "${jsCode.replace(/"/g, '\\"')}"`);
      return JSON.parse(result || '[]');
    } catch (err) {
      console.error('[36krAgentBrowser] JS extract error:', err.message);
      return [];
    }
  }

  normalizeData(item) {
    // Calculate score based on freshness (newer = higher)
    let score = 70; // Base score for 36氪
    
    score = Math.min(100, Math.max(0, score));
    
    // 36氪文章通常不显示具体作者，使用平台名
    const author = '36氪';
    
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.title,
      author: author,
      author_id: '36kr',
      url: item.url,
      published_at: new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: item.metrics || {},
      score: score,
      avg_score: score,
      is_ai_related: true
    };
  }
}

module.exports = { SanliuAgentBrowserAdapter };
