/**
 * Bilibili Agent Browser Adapter
 * 使用 AI-optimized browser automation 抓取 Bilibili AI 相关内容
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class BilibiliAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config = {}) {
    super(config);
    this.name = 'bilibili';
    this.baseUrl = 'https://www.bilibili.com';
    this.searchKeywords = [
      '人工智能',
      '大模型',
      'ChatGPT',
      'AI教程',
      '机器学习',
      '深度学习',
      'OpenAI',
      'Claude',
      'AI应用'
    ];
    // AI 相关 UP 主
    this.aiUpmasters = [
      '415407',      // 李沐
      '327280337',   // 跟李沐学AI
      '25876945',    // 人工智能教程
      '481434238',   // AI算法工程师
    ];
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 关键词用于内容过滤
    const aiKeywords = [
      'AI', '人工智能', '大模型', 'LLM', 'GPT', 'ChatGPT', 'Claude',
      '机器学习', '深度学习', '神经网络', 'transformer',
      'OpenAI', 'Anthropic', 'Google', 'Gemini',
      '智谱', '文心一言', '通义千问', 'Kimi',
      'AI教程', 'AI应用', 'AI工具'
    ];

    try {
      // 1. 搜索 AI 相关视频
      for (const keyword of this.searchKeywords) {
        try {
          const searchUrl = `${this.baseUrl}/search?keyword=${encodeURIComponent(keyword)}`;
          console.log(`[Bilibili] Searching: ${keyword}`);
          
          const feedItems = await this.fetchWithAgentBrowser(searchUrl, {
            waitForSelector: '.video-list-item, .bili-video-card, .search-result-list .video-list-item',
            extractData: () => {
              const items = [];
              const videoElements = document.querySelectorAll('.video-list-item, .bili-video-card, .search-result-list .video-list-item');
              
              videoElements.forEach((el, index) => {
                if (index >= 15) return;
                
                const titleEl = el.querySelector('.bili-video-card__info--tit, .title, .video-title, a[title]');
                const authorEl = el.querySelector('.bili-video-card__info--author, .up-name, .author');
                const viewEl = el.querySelector('.bili-video-card__stats--item, .play-text, .view');
                const linkEl = el.querySelector('a');
                
                if (titleEl) {
                  items.push({
                    title: titleEl.textContent?.trim() || titleEl.getAttribute('title') || '',
                    author: authorEl?.textContent?.trim() || 'B站UP主',
                    views: viewEl?.textContent?.trim() || '0',
                    url: linkEl?.href || ''
                  });
                }
              });
              
              return items;
            }
          });

          // 过滤并添加结果
          for (const item of feedItems) {
            const text = item.title.toLowerCase();
            const isAI = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
            
            if (isAI && item.title) {
              results.push(this.normalizeData({
                id: `bilibili_${this.extractId(item.url)}_${Date.now()}`,
                title: item.title,
                content: `B站视频: ${item.title}`,
                author: item.author,
                url: item.url.startsWith('http') ? item.url : `${this.baseUrl}${item.url}`,
                metrics: {
                  views: this.parseViews(item.views)
                }
              }));
            }
          }
          
          console.log(`[Bilibili] Fetched ${feedItems.length} videos for keyword: ${keyword}`);
          
          // 添加延迟
          await new Promise(r => setTimeout(r, 3000));
          
        } catch (err) {
          console.error(`[Bilibili] Search error for ${keyword}:`, err.message);
        }
      }

      // 2. 抓取指定 UP 主的视频
      const upmasters = accountIds.length > 0 ? accountIds : this.aiUpmasters;
      for (const uid of upmasters) {
        try {
          const spaceUrl = `${this.baseUrl}/space/${uid}/video`;
          console.log(`[Bilibili] Fetching UP主: ${uid}`);
          
          const feedItems = await this.fetchWithAgentBrowser(spaceUrl, {
            waitForSelector: '.video-list-item, .small-item, .bili-video-card',
            extractData: () => {
              const items = [];
              const videoElements = document.querySelectorAll('.video-list-item, .small-item, .bili-video-card');
              
              videoElements.forEach((el, index) => {
                if (index >= 10) return;
                
                const titleEl = el.querySelector('.title, .bili-video-card__info--tit');
                const viewEl = el.querySelector('.play, .view, .bili-video-card__stats--item');
                const timeEl = el.querySelector('.time, .bili-video-card__info--date');
                const linkEl = el.querySelector('a');
                
                if (titleEl) {
                  items.push({
                    title: titleEl.textContent?.trim() || titleEl.getAttribute('title') || '',
                    views: viewEl?.textContent?.trim() || '0',
                    published_at: timeEl?.textContent?.trim() || '',
                    url: linkEl?.href || ''
                  });
                }
              });
              
              return items;
            }
          });

          // 过滤 AI 相关内容
          for (const item of feedItems) {
            const text = item.title.toLowerCase();
            const isAI = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
            
            if (isAI && item.title) {
              results.push(this.normalizeData({
                id: `bilibili_${this.extractId(item.url)}_${Date.now()}`,
                title: item.title,
                content: `B站视频: ${item.title}`,
                author: `UP主:${uid}`,
                url: item.url.startsWith('http') ? item.url : `${this.baseUrl}${item.url}`,
                published_at: this.parseTime(item.published_at),
                metrics: {
                  views: this.parseViews(item.views)
                }
              }));
            }
          }
          
          console.log(`[Bilibili] Fetched ${feedItems.length} videos from UP主 ${uid}`);
          
          // 添加延迟
          await new Promise(r => setTimeout(r, 3000));
          
        } catch (err) {
          console.error(`[Bilibili] Failed to fetch UP主 ${uid}:`, err.message);
        }
      }
      
      console.log(`[Bilibili] Total AI-related videos: ${results.length}`);
    } catch (err) {
      console.error('[Bilibili] Adapter error:', err.message);
    }
    
    return results;
  }

  extractId(url) {
    if (!url) return Date.now().toString();
    const match = url.match(/BV[a-zA-Z0-9]+/) || url.match(/av(\d+)/);
    return match ? match[0] : Date.now().toString();
  }

  parseViews(viewStr) {
    if (!viewStr) return 0;
    const num = parseFloat(viewStr);
    if (viewStr.includes('万')) return Math.round(num * 10000);
    if (viewStr.includes('千')) return Math.round(num * 1000);
    if (viewStr.includes('百万')) return Math.round(num * 1000000);
    return num || 0;
  }

  parseTime(timeStr) {
    if (!timeStr) return new Date().toISOString();
    
    // 处理相对时间格式
    if (timeStr.includes('分钟前')) {
      const mins = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - mins * 60000).toISOString();
    }
    if (timeStr.includes('小时前')) {
      const hours = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - hours * 3600000).toISOString();
    }
    if (timeStr.includes('天前')) {
      const days = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - days * 86400000).toISOString();
    }
    
    // 尝试直接解析
    const date = new Date(timeStr);
    return isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
  }

  normalizeData(item) {
    return {
      id: item.id,
      platform: this.name,
      title: item.title.substring(0, 200),
      content: item.content || item.title,
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at || new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        views: item.metrics?.views || 0,
        engagement: item.metrics?.views || 0
      }
    };
  }
}

module.exports = { BilibiliAgentBrowserAdapter };
