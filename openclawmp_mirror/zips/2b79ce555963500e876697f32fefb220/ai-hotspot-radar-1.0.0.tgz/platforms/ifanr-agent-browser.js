/**
 * 爱范儿 (iFanr) Agent Browser Adapter
 * 使用 AI-optimized browser automation 抓取爱范儿 AI 相关内容
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class iFanrAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config = {}) {
    super(config);
    this.name = 'ifanr';
    this.baseUrl = 'https://www.ifanr.com';
    this.aiTopics = [
      '/category/ai',         // AI 分类
      '/tag/人工智能',         // AI 标签
      '/tag/大模型',
      '/tag/ChatGPT',
      '/tag/OpenAI',
      '/tag/生成式AI'
    ];
  }

  async fetchHotspots(accountIds = []) {
    const results = [];
    
    // AI 关键词用于内容过滤
    const aiKeywords = [
      'AI', '人工智能', '大模型', 'LLM', 'GPT', 'ChatGPT', 'Claude',
      '机器学习', '深度学习', '神经网络', 'transformer',
      'OpenAI', 'Anthropic', 'Google', 'Gemini',
      '智谱', '文心一言', '通义千问', 'Kimi', '阶跃星辰',
      'AI芯片', 'AI应用', 'AI Agent', '智能体', '具身智能',
      'Copilot', 'Cursor', 'Midjourney', 'Stable Diffusion'
    ];

    try {
      // 抓取爱范儿 AI 分类
      for (const topic of this.aiTopics) {
        try {
          const url = `${this.baseUrl}${topic}`;
          console.log(`[iFanr] Fetching: ${url}`);
          
          const feedItems = await this.fetchWithAgentBrowser(url, {
            // 等待文章列表加载
            waitForSelector: '.article-item, .article-card, .c-single-news, article',
            // 提取文章数据
            extractData: () => {
              const items = [];
              const articleElements = document.querySelectorAll('.article-item, .article-card, .c-single-news, article');
              
              articleElements.forEach((el, index) => {
                if (index >= 20) return; // 限制数量
                
                const titleEl = el.querySelector('.article-title, .title, h2 a, h3 a, .c-single-news__title');
                const descEl = el.querySelector('.article-summary, .summary, .description, .c-single-news__summary');
                const authorEl = el.querySelector('.author-name, .author, .c-single-news__author');
                const timeEl = el.querySelector('.time, .publish-time, .c-single-news__time');
                const linkEl = el.querySelector('a');
                
                if (titleEl) {
                  items.push({
                    title: titleEl.textContent?.trim() || '',
                    content: descEl?.textContent?.trim() || '',
                    author: authorEl?.textContent?.trim() || '爱范儿',
                    published_at: timeEl?.textContent?.trim() || new Date().toISOString(),
                    url: linkEl?.href || ''
                  });
                }
              });
              
              return items;
            }
          });

          // 过滤 AI 相关内容
          for (const item of feedItems) {
            const text = `${item.title} ${item.content}`.toLowerCase();
            const isAI = aiKeywords.some(kw => text.includes(kw.toLowerCase()));
            
            if (isAI && item.title) {
              results.push(this.normalizeData({
                id: `ifanr_${this.extractId(item.url)}_${Date.now()}`,
                title: item.title,
                content: item.content,
                author: item.author,
                url: item.url.startsWith('http') ? item.url : `${this.baseUrl}${item.url}`,
                published_at: this.parseTime(item.published_at)
              }));
            }
          }
          
          console.log(`[iFanr] Fetched ${feedItems.length} items from ${topic}`);
          
          // 添加延迟避免请求过快
          await new Promise(r => setTimeout(r, 2000));
          
        } catch (err) {
          console.error(`[iFanr] Failed to fetch ${topic}:`, err.message);
        }
      }
      
      console.log(`[iFanr] Total AI-related items: ${results.length}`);
    } catch (err) {
      console.error('[iFanr] Adapter error:', err.message);
    }
    
    return results;
  }

  extractId(url) {
    if (!url) return Date.now().toString();
    const match = url.match(/\/(\d+)/);
    return match ? match[1] : Date.now().toString();
  }

  parseTime(timeStr) {
    if (!timeStr) return new Date().toISOString();
    
    // 处理相对时间格式
    if (timeStr.includes('分钟前')) {
      const mins = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - mins * 60000).toISOString();
    }
    if (timeStr.includes('小时前')) {
      const hours = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - hours * 3600000).toISOString();
    }
    if (timeStr.includes('天前')) {
      const days = parseInt(timeStr.match(/(\d+)/)?.[1] || 0);
      return new Date(Date.now() - days * 86400000).toISOString();
    }
    
    // 尝试直接解析
    const date = new Date(timeStr);
    return isNaN(date.getTime()) ? new Date().toISOString() : date.toISOString();
  }

  normalizeData(item) {
    return {
      id: item.id,
      platform: this.name,
      title: item.title.substring(0, 200),
      content: item.content || item.title,
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: item.published_at,
      crawled_at: new Date().toISOString(),
      metrics: {
        views: 0,
        engagement: 0
      }
    };
  }
}

module.exports = { iFanrAgentBrowserAdapter };
