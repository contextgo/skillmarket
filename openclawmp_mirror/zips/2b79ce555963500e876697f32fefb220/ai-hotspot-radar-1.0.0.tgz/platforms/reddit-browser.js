/**
 * Reddit Browser Adapter
 * 使用浏览器直接抓取 r/artificial，绕过 RSSHub
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class RedditBrowserAdapter extends AgentBrowserAdapter {
  constructor(config) {
    super(config);
    this.name = 'reddit';
    this.baseUrl = 'https://www.reddit.com';
    this.targetUrl = 'https://www.reddit.com/r/artificial/hot/';
  }

  async fetchHotspots() {
    const results = [];
    
    try {
      console.log('[RedditBrowser] Fetching from ' + this.targetUrl);
      
      // 打开 Reddit r/artificial 热榜
      await this.open(this.targetUrl);
      await this.wait(5000); // 等待页面加载
      
      // 使用 JavaScript 提取帖子
      const posts = await this.page.evaluate(() => {
        const posts = [];
        
        // 查找所有帖子元素
        const postElements = document.querySelectorAll('[data-testid="post-container"], .Post, article');
        
        postElements.forEach((el, index) => {
          try {
            // 提取标题
            const titleEl = el.querySelector('h3, [data-testid="post-title"], a[data-click-id="body"]');
            const title = titleEl ? titleEl.textContent.trim() : '';
            
            // 提取链接
            const linkEl = el.querySelector('a[href*="/r/artificial/comments/"]');
            const href = linkEl ? linkEl.href : '';
            const postId = href.match(/comments\/(\w+)/)?.[1] || `post_${index}`;
            
            // 提取投票数
            const voteEl = el.querySelector('[data-testid="upvote-button"], [data-testid="downvote-button"]');
            const votesText = el.textContent.match(/(\d+)\s*votes?/i);
            const votes = votesText ? parseInt(votesText[1]) : 0;
            
            // 提取评论数
            const commentEl = el.querySelector('[data-testid="comment-button"], a[href*="/comments/"]');
            const commentsText = el.textContent.match(/(\d+)\s*comments?/i);
            const comments = commentsText ? parseInt(commentsText[1]) : 0;
            
            // 提取作者
            const authorEl = el.querySelector('a[href^="/u/"], a[href^="/user/"]');
            const author = authorEl ? authorEl.textContent.replace(/^u\//, '').trim() : 'unknown';
            
            if (title && href) {
              posts.push({
                id: postId,
                title: title,
                url: href,
                author: author,
                votes: votes,
                comments: comments
              });
            }
          } catch (e) {
            // 忽略单个帖子提取错误
          }
        });
        
        return posts;
      });
      
      console.log(`[RedditBrowser] Found ${posts.length} posts`);
      
      // 转换为标准格式
      for (const post of posts.slice(0, 25)) {
        // 计算热度分数 (0-100)
        const score = Math.min(100, Math.round((post.votes + post.comments * 2) / 10));
        
        results.push(this.normalizeData({
          id: post.id,
          title: post.title,
          content: post.title, // Reddit 帖子内容需要进入详情页
          author: post.author,
          url: post.url,
          votes: post.votes,
          comments: post.comments,
          score: score
        }));
      }
      
    } catch (err) {
      console.error('[RedditBrowser] Failed:', err.message);
    }
    
    await this.close();
    return results;
  }

  normalizeData(item) {
    return {
      id: `reddit_${item.id}`,
      platform: this.name,
      title: item.title,
      content: item.content,
      author: item.author,
      author_id: item.author,
      url: item.url,
      published_at: new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        votes: item.votes || 0,
        comments: item.comments || 0,
        engagement: (item.votes || 0) + (item.comments || 0)
      },
      score: item.score || 50,
      avg_score: item.score || 50,
      is_ai_related: true
    };
  }
}

module.exports = { RedditBrowserAdapter };
