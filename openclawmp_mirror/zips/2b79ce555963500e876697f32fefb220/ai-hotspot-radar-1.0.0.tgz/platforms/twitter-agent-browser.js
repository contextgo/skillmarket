/**
 * Twitter/X Adapter using Agent Browser
 * Token-efficient scraping without API limits
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class TwitterAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config) {
    super(config);
    this.name = 'twitter';
    this.baseUrl = 'https://twitter.com';
    this.searchUrl = 'https://twitter.com/search';
    
    // AI 监控账号列表
    this.aiAccounts = [
      'sama',           // Sam Altman
      'ylecun',         // Yann LeCun
      'karpathy',       // Andrej Karpathy
      'goodfellow_ian', // Ian Goodfellow
      'AndrewYNg',      // Andrew Ng
      'hardmaru',       // David Ha
      'DrJimFan',       // Jim Fan
      'bindureddy',     // Bindu Reddy
      'lmsysorg',       // LMSYS
      'huggingface',    // Hugging Face
    ];
    
    // AI 关键词
    this.aiKeywords = [
      'AI', 'artificial intelligence', 'machine learning', 'deep learning',
      'LLM', 'GPT', 'Claude', 'Gemini', 'OpenAI', 'Anthropic',
      'neural network', 'transformer', 'AI model', 'AI agent'
    ];
  }

  async fetchHotspots(accounts = this.aiAccounts) {
    const results = [];
    
    for (const account of accounts.slice(0, 3)) { // Limit to avoid rate limits
      try {
        console.log(`[TwitterAgentBrowser] Fetching @${account}...`);
        
        // Open profile
        await this.open(`${this.baseUrl}/${account}`);
        await this.wait(3000);
        
        // Get tweets
        const tweets = await this.extractTweets();
        
        for (const tweet of tweets) {
          if (this.isAIContent(tweet.text)) {
            results.push(this.normalizeData({
              ...tweet,
              author: account,
              platform: this.name
            }));
          }
        }
        
        // Wait between accounts
        await this.wait(2000);
      } catch (err) {
        console.error(`[TwitterAgentBrowser] Failed to fetch @${account}:`, err.message);
      }
    }
    
    await this.close();
    return results;
  }

  async extractTweets() {
    const tweets = [];
    
    try {
      // Scroll to load more tweets
      for (let i = 0; i < 3; i++) {
        await this.scroll('down', 800);
        await this.wait(1000);
      }
      
      // Get snapshot
      const snapshot = await this.snapshot({ interactive: false });
      
      // Parse tweets from snapshot
      // Twitter structure: articles with data-testid="tweet"
      const lines = snapshot.split('\n');
      let currentTweet = null;
      
      for (const line of lines) {
        // Look for tweet text indicators
        if (line.includes('article') || line.includes('tweet')) {
          if (currentTweet && currentTweet.text) {
            tweets.push(currentTweet);
          }
          currentTweet = { text: '', engagement: 0 };
        }
        
        // Extract text content
        if (currentTweet && line.includes('text')) {
          const textMatch = line.match(/text\s+"([^"]+)"/);
          if (textMatch) {
            currentTweet.text += ' ' + textMatch[1];
          }
        }
        
        // Extract engagement
        if (line.includes('reply') || line.includes('like') || line.includes('retweet')) {
          const numMatch = line.match(/(\d+)/);
          if (numMatch) {
            currentTweet.engagement += parseInt(numMatch[1]);
          }
        }
      }
      
      // Add last tweet
      if (currentTweet && currentTweet.text) {
        tweets.push(currentTweet);
      }
    } catch (err) {
      console.error('[TwitterAgentBrowser] Extract error:', err.message);
    }
    
    return tweets.filter(t => t.text && t.text.length > 20);
  }

  isAIContent(text) {
    const lowerText = text.toLowerCase();
    return this.aiKeywords.some(keyword => 
      lowerText.includes(keyword.toLowerCase())
    );
  }

  normalizeData(item) {
    const engagement = item.engagement || 0;
    const score = Math.min(100, Math.round(engagement / 10));
    
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.text.substring(0, 100) + (item.text.length > 100 ? '...' : ''),
      content: item.text,
      author: item.author,
      author_id: item.author,
      url: `${this.baseUrl}/${item.author}/status/${item.id || Date.now()}`,
      published_at: new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        engagement: engagement,
        likes: Math.floor(engagement * 0.6),
        replies: Math.floor(engagement * 0.3),
        retweets: Math.floor(engagement * 0.1)
      },
      score: score,
      avg_score: score,
      is_ai_related: true
    };
  }
}

module.exports = { TwitterAgentBrowserAdapter };
