/**
 * Weibo Adapter using Agent Browser
 * Scrapes weibo.com hot search for AI content
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class WeiboAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config) {
    super(config);
    this.name = 'weibo';
    this.baseUrl = 'https://weibo.com';
    this.hotSearchUrl = 'https://s.weibo.com/top/summary';
    
    // AI 关键词（中文）
    this.aiKeywords = [
      'AI', '人工智能', '大模型', 'LLM', 'GPT', 'Claude', 'ChatGPT',
      'OpenAI', 'Anthropic', '谷歌', '百度', '阿里', '腾讯',
      '机器学习', '深度学习', '神经网络', 'Transformer',
      '文心一言', '通义千问', '豆包', 'Kimi', '智谱'
    ];
  }

  async fetchHotspots() {
    const results = [];
    
    try {
      console.log('[WeiboAgentBrowser] Fetching hot search...');
      
      // Open hot search page
      await this.open(this.hotSearchUrl);
      await this.wait(3000);
      
      // Extract hot topics
      const topics = await this.extractHotTopics();
      
      for (const topic of topics.slice(0, 20)) {
        if (this.isAIContent(topic.title)) {
          results.push(this.normalizeData(topic));
        }
      }
      
    } catch (err) {
      console.error('[WeiboAgentBrowser] Failed:', err.message);
    }
    
    await this.close();
    return results;
  }

  async extractHotTopics() {
    const topics = [];
    
    try {
      // Get snapshot
      const snapshot = await this.snapshot({ interactive: false });
      
      // Parse hot topics from Weibo structure
      // Weibo hot search table structure
      const lines = snapshot.split('\n');
      
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        
        // Look for rank indicators (top, 1, 2, 3, etc.)
        if (line.match(/^(top|\d+)\s/)) {
          const rank = line.trim();
          
          // Next lines should contain topic info
          let title = '';
          let heat = 0;
          let j = i + 1;
          
          while (j < lines.length && j < i + 5) {
            const nextLine = lines[j];
            
            // Extract title
            if (nextLine.includes('link') && !title) {
              const match = nextLine.match(/link\s+"([^"]+)"/);
              if (match) {
                title = match[1];
              }
            }
            
            // Extract heat value
            if (nextLine.match(/\d+\s*万?/)) {
              const numMatch = nextLine.match(/(\d+)/);
              if (numMatch) {
                heat = parseInt(numMatch[1]);
                if (nextLine.includes('万')) {
                  heat *= 10000;
                }
              }
            }
            
            j++;
          }
          
          if (title) {
            topics.push({
              rank: rank,
              title: title,
              heat: heat,
              url: `https://s.weibo.com/weibo?q=${encodeURIComponent(title)}`
            });
          }
        }
      }
    } catch (err) {
      console.error('[WeiboAgentBrowser] Extract error:', err.message);
    }
    
    return topics;
  }

  isAIContent(title) {
    const lowerTitle = title.toLowerCase();
    return this.aiKeywords.some(keyword => 
      lowerTitle.includes(keyword.toLowerCase())
    );
  }

  normalizeData(item) {
    // Calculate score based on rank and heat
    let score = 50;
    
    if (item.rank === 'top' || item.rank === '1') score = 95;
    else if (item.rank === '2') score = 90;
    else if (item.rank === '3') score = 85;
    else if (parseInt(item.rank) <= 10) score = 80 - parseInt(item.rank) * 2;
    else score = 60 - parseInt(item.rank) * 0.5;
    
    // Adjust by heat
    if (item.heat > 1000000) score += 5;
    if (item.heat > 5000000) score += 5;
    
    score = Math.min(100, Math.max(0, Math.round(score)));
    
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.title,
      author: '微博热搜',
      author_id: 'weibo_hot',
      url: item.url,
      published_at: new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        heat: item.heat,
        rank: item.rank
      },
      score: score,
      avg_score: score,
      is_ai_related: true
    };
  }
}

module.exports = { WeiboAgentBrowserAdapter };
