/**
 * Twitter/X Adapter using Official API
 * Requires TWITTER_BEARER_TOKEN in environment
 * 
 * 优化特性：
 * - 熔断器保护（Circuit Breaker）
 * - 指数退避重试（Exponential Backoff Retry）
 * - 错误分类处理
 */

const fetch = require('node-fetch');
const HttpsProxyAgent = require('https-proxy-agent');
const { circuitBreakerManager } = require('../utils/circuit-breaker');
const { withRetry, classifyError, ErrorCategory } = require('../utils/retry');

const PROXY_URL = process.env.HTTP_PROXY || 'http://127.0.0.1:7890';
const proxyAgent = new HttpsProxyAgent(PROXY_URL);

class TwitterAPIAdapter {
  constructor(config) {
    this.name = 'twitter';
    this.baseUrl = 'https://api.twitter.com/2';
    this.bearerToken = config.bearerToken || process.env.TWITTER_BEARER_TOKEN;
    
    // 初始化熔断器（错误阈值：5次/分钟，冷却时间：5分钟）
    this.circuitBreaker = circuitBreakerManager.get('twitter-api', {
      failureThreshold: 5,      // 5次错误触发熔断
      successThreshold: 2,      // 连续2次成功恢复
      timeout: 300000,          // 5分钟冷却时间
      monitorInterval: 60000    // 1分钟监控窗口
    });
    
    // 重试配置
    this.retryOptions = {
      maxRetries: 3,            // 最多重试3次
      baseDelay: 1000,          // 基础延迟1秒
      maxDelay: 30000,          // 最大延迟30秒
      factor: 2,                // 指数因子
      retryableCategories: [    // 可重试的错误类型
        ErrorCategory.NETWORK,
        ErrorCategory.TIMEOUT,
        ErrorCategory.SERVER,
        ErrorCategory.UNKNOWN
      ],
      onRetry: (error, attempt, delay, category) => {
        console.log(`[TwitterAPI] Retry ${attempt}/3 after ${delay}ms due to ${category}: ${error.message}`);
      }
    };
    
    // AI 监控账号列表 - Tier 1: LLM 大厂 & 顶级研究者
    this.aiAccounts = [
      // LLM 大厂官方账号
      'sama',           // Sam Altman - OpenAI CEO
      'OpenAI',         // OpenAI 官方
      'AnthropicAI',    // Anthropic 官方
      'GoogleAI',       // Google AI 官方
      'DeepMind',       // Google DeepMind
      'MetaAI',         // Meta AI 官方
      'xai',            // xAI 官方
      'Azure',          // Microsoft Azure AI
      'AWS',            // Amazon Web Services AI
      
      // 顶级 AI 研究者
      'ylecun',         // Yann LeCun - Meta AI 首席科学家
      'karpathy',       // Andrej Karpathy - 前 Tesla AI 总监, OpenAI 创始成员
      'AndrewYNg',      // Andrew Ng - AI 教父
      'DrJimFan',       // Jim Fan - NVIDIA 高级研究科学家
      'goodfellow_ian', // Ian Goodfellow - GAN 之父
      'hardmaru',       // David Ha - Google Brain, Stable Diffusion
      'fchollet',       // François Chollet - Keras 作者
      'jeremyphoward',  // Jeremy Howard - fast.ai 创始人
      'EMostaque',      // Emad Mostaque - Stability AI 创始人
      
      // 具身智能 & 机器人
      'UnitreeRobotics', // Unitree Robotics - 宇树科技
      'Figure_robot',    // Figure AI - 人形机器人
      'BostonDynamics',  // Boston Dynamics
      'tesla_optimus',   // Tesla Optimus
      '1x_Tech',         // 1X Technologies
      
      // 开源 & 社区
      'lmsysorg',       // LMSYS - Chatbot Arena
      'huggingface',    // Hugging Face
      'LangChainAI',    // LangChain
      'llama_index',    // LlamaIndex
      'weights_biases', // Weights & Biases
      ' replicate ',    // Replicate
      
      // 投资机构 & 行业观察者
      'paulg',          // Paul Graham - YC 创始人
      'pmarca',         // Marc Andreessen - a16z
      'eladgil',        // Elad Gil - 天使投资人
      'naval',          // Naval Ravikant
      'balajis',        // Balaji Srinivasan
      
      // 中国 AI 公司海外账号
      'AlibabaCloud',   // 阿里云
      'BaiduResearch',  // 百度研究院
      'realByteDance',  // 字节跳动
      'DeepSeek_AI'     // DeepSeek
    ];
    
    // AI 关键词 - 扩展体系
    this.aiKeywords = {
      // Tier 1: 核心 AI 技术
      core: [
        'AI', 'artificial intelligence', 'machine learning', 'deep learning',
        'LLM', 'large language model', 'foundation model', 'generative AI',
        'GPT', 'GPT-4', 'GPT-5', 'Claude', 'Gemini', 'Llama', 'Mistral',
        'OpenAI', 'Anthropic', 'Google AI', 'DeepMind', 'Meta AI', 'xAI',
        'neural network', 'transformer', 'attention mechanism', 'diffusion model',
        'AI model', 'AI agent', 'multi-agent', 'autonomous agent'
      ],
      
      // Tier 2: 具身智能 & 机器人
      robotics: [
        'robotics', 'robot', 'humanoid', 'humanoid robot',
        'embodied AI', 'embodied intelligence', '具身智能',
        'Unitree', '宇树', 'Figure AI', 'Boston Dynamics', 'Tesla Optimus',
        'manipulation', 'locomotion', 'dexterity',
        'sim-to-real', 'real world robot'
      ],
      
      // Tier 3: AI 应用 & 工具
      applications: [
        'ChatGPT', 'Copilot', 'Cursor', 'Codeium', 'Devin',
        'Midjourney', 'Stable Diffusion', 'DALL-E', 'Sora',
        'RAG', 'retrieval augmented generation',
        'vector database', 'embedding', 'fine-tuning',
        'prompt engineering', 'chain of thought', 'function calling'
      ],
      
      // Tier 4: 基础设施 & 硬件
      infrastructure: [
        'NVIDIA', 'GPU', 'TPU', 'AI chip', 'AI hardware',
        'training', 'inference', 'distributed training',
        'H100', 'A100', 'GH200', 'Blackwell',
        'CUDA', 'PyTorch', 'TensorFlow', 'JAX'
      ],
      
      // Tier 5: 中国 AI
      china: [
        '智谱', 'ChatGLM', 'GLM-4',
        '文心一言', 'ERNIE', '百度 AI',
        '通义千问', 'Qwen', '阿里 AI',
        'Kimi', '月之暗面', 'Moonshot',
        '阶跃星辰', 'StepFun',
        'DeepSeek', 'DeepSeek-V2', 'DeepSeek-Coder',
        '讯飞星火', 'iFlytek',
        '商汤', 'SenseTime', '商量',
        '百川', 'Baichuan',
        '零一万物', '01.AI',
        'MiniMax',
        'AI 中国', 'Chinese AI', 'China AI'
      ],
      
      // Tier 6: 政策 & 伦理
      policy: [
        'AI regulation', 'AI policy', 'AI governance',
        'AI safety', 'AI alignment', 'AI ethics',
        'EU AI Act', 'AI bill', 'AI law',
        'AGI', 'artificial general intelligence',
        'AI risk', 'existential risk', 'x-risk'
      ]
    };
    
    // 合并所有关键词用于快速检查
    this.allKeywords = Object.values(this.aiKeywords).flat();
  }

  async fetchHotspots(accounts = []) {
    if (!this.bearerToken) {
      console.error('[TwitterAPI] No bearer token provided');
      return [];
    }

    const results = [];
    
    try {
      // 使用熔断器保护整个请求流程
      await this.circuitBreaker.execute(async () => {
        // 如果提供了账号列表，获取这些账号的推文
        if (accounts && accounts.length > 0) {
          console.log(`[TwitterAPI] Fetching tweets from ${accounts.length} accounts...`);
          
          for (const username of accounts) {
            try {
              // 使用带重试的函数获取推文
              const tweets = await withRetry(
                this.fetchUserTweets.bind(this),
                [username, 5],
                this.retryOptions
              );
              console.log(`[TwitterAPI] ${username}: ${tweets.length} tweets`);
              
              for (const tweet of tweets) {
                if (this.isAIContent(tweet.text)) {
                  results.push(this.normalizeData(tweet));
                }
              }
            } catch (err) {
              // 分类错误并记录
              const category = classifyError(err);
              console.error(`[TwitterAPI] Failed to fetch ${username}: [${category}] ${err.message}`);
              
              // 如果是认证错误，立即停止
              if (category === ErrorCategory.AUTH) {
                throw err;
              }
              
              // 继续处理下一个账号
              continue;
            }
          }
        } else {
          // 默认：搜索AI相关推文
          const searchQuery = 'AI artificial intelligence lang:en -is:retweet';
          const tweets = await withRetry(
            this.searchTweets.bind(this),
            [searchQuery, 20],
            this.retryOptions
          );
          
          for (const tweet of tweets) {
            if (this.isAIContent(tweet.text)) {
              results.push(this.normalizeData(tweet));
            }
          }
        }
        
        console.log(`[TwitterAPI] Fetched ${results.length} AI tweets`);
      });
    } catch (err) {
      // 熔断器打开或其他致命错误
      if (err.name === 'CircuitBreakerOpenError') {
        console.error('[TwitterAPI] Circuit breaker is OPEN:', err.message);
      } else {
        console.error('[TwitterAPI] Failed:', err.message);
      }
    }
    
    return results;
  }

  async fetchUserTweets(username, maxResults = 5) {
    // 获取用户的推文
    // 注意：需要 Twitter API v2 的 User Tweet timeline 权限
    const url = new URL(`${this.baseUrl}/users/by/username/${username}`);
    
    const userResponse = await fetch(url.toString(), {
      agent: proxyAgent,
      headers: {
        'Authorization': `Bearer ${this.bearerToken}`,
        'Content-Type': 'application/json'
      },
      timeout: 10000 // 10秒超时
    });
    
    if (!userResponse.ok) {
      const errorText = await userResponse.text();
      console.error(`[TwitterAPI] HTTP ${userResponse.status} for ${username}:`, errorText.substring(0, 200));
      
      // 创建带有状态码的错误对象，便于重试机制分类
      const error = new Error(`Failed to get user ${username}: HTTP ${userResponse.status}`);
      error.statusCode = userResponse.status;
      error.status = userResponse.status;
      throw error;
    }
    
    const userData = await userResponse.json();
    const userId = userData.data?.id;
    
    if (!userId) {
      return [];
    }
    
    // 获取用户推文
    const tweetsUrl = new URL(`${this.baseUrl}/users/${userId}/tweets`);
    tweetsUrl.searchParams.append('max_results', Math.min(maxResults, 10));
    tweetsUrl.searchParams.append('tweet.fields', 'created_at,public_metrics,author_id');
    
    const tweetsResponse = await fetch(tweetsUrl.toString(), {
      agent: proxyAgent,
      headers: {
        'Authorization': `Bearer ${this.bearerToken}`,
        'Content-Type': 'application/json'
      },
      timeout: 10000 // 10秒超时
    });
    
    if (!tweetsResponse.ok) {
      const error = new Error(`Failed to get tweets for ${username}: HTTP ${tweetsResponse.status}`);
      error.statusCode = tweetsResponse.status;
      error.status = tweetsResponse.status;
      throw error;
    }
    
    const data = await tweetsResponse.json();
    
    return (data.data || []).map(tweet => ({
      ...tweet,
      author: { username, name: username }
    }));
  }

  async searchTweets(query, maxResults = 10) {
    const url = new URL(`${this.baseUrl}/tweets/search/recent`);
    url.searchParams.append('query', query);
    url.searchParams.append('max_results', Math.min(maxResults, 100));
    url.searchParams.append('tweet.fields', 'created_at,public_metrics,author_id');
    url.searchParams.append('expansions', 'author_id');
    url.searchParams.append('user.fields', 'username,name');

    const response = await fetch(url.toString(), {
      agent: proxyAgent,
      headers: {
        'Authorization': `Bearer ${this.bearerToken}`,
        'Content-Type': 'application/json'
      },
      timeout: 15000 // 15秒超时
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      const error = new Error(errorData.detail || `HTTP ${response.status}`);
      error.statusCode = response.status;
      error.status = response.status;
      error.responseData = errorData;
      throw error;
    }

    const data = await response.json();
    
    // Map users to tweets
    const users = new Map();
    if (data.includes?.users) {
      for (const user of data.includes.users) {
        users.set(user.id, user);
      }
    }

    return (data.data || []).map(tweet => ({
      ...tweet,
      author: users.get(tweet.author_id)
    }));
  }

  /**
   * 获取熔断器状态
   */
  getCircuitBreakerState() {
    return this.circuitBreaker.getState();
  }

  /**
   * 重置熔断器
   */
  resetCircuitBreaker() {
    this.circuitBreaker.reset();
  }

  isAIContent(text) {
    if (!text) return false;
    const lowerText = text.toLowerCase();
    return this.allKeywords.some(keyword => 
      lowerText.includes(keyword.toLowerCase())
    );
  }
  
  /**
   * 获取内容匹配的关键词类别
   * @param {string} text - 推文内容
   * @returns {Object} 匹配结果 { isAI: boolean, categories: string[], matchedKeywords: string[] }
   */
  getContentCategories(text) {
    if (!text) return { isAI: false, categories: [], matchedKeywords: [] };
    
    const lowerText = text.toLowerCase();
    const categories = [];
    const matchedKeywords = [];
    
    for (const [category, keywords] of Object.entries(this.aiKeywords)) {
      const matches = keywords.filter(kw => lowerText.includes(kw.toLowerCase()));
      if (matches.length > 0) {
        categories.push(category);
        matchedKeywords.push(...matches);
      }
    }
    
    return {
      isAI: categories.length > 0,
      categories: [...new Set(categories)],
      matchedKeywords: [...new Set(matchedKeywords)]
    };
  }

  normalizeData(tweet) {
    const metrics = tweet.public_metrics || {};
    const engagement = (metrics.like_count || 0) + (metrics.retweet_count || 0) * 2 + (metrics.reply_count || 0);
    
    // Calculate score based on engagement
    let score = 50;
    if (engagement > 1000) score = 95;
    else if (engagement > 500) score = 85;
    else if (engagement > 200) score = 75;
    else if (engagement > 100) score = 65;
    else if (engagement > 50) score = 55;
    
    score = Math.min(100, Math.max(0, score));
    
    const author = tweet.author || {};
    const username = author.username || 'unknown';
    
    return {
      id: `twitter_${tweet.id}`,
      platform: this.name,
      title: tweet.text.substring(0, 100) + (tweet.text.length > 100 ? '...' : ''),
      content: tweet.text,
      author: author.name || username,
      author_id: username,
      url: `https://twitter.com/${username}/status/${tweet.id}`,
      published_at: tweet.created_at,
      crawled_at: new Date().toISOString(),
      metrics: {
        likes: metrics.like_count || 0,
        retweets: metrics.retweet_count || 0,
        replies: metrics.reply_count || 0,
        impressions: metrics.impression_count || 0
      },
      score: score,
      avg_score: score,
      is_ai_related: true
    };
  }
}

module.exports = { TwitterAPIAdapter };
