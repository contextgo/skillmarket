/**
 * Reddit CDP Adapter
 * 使用现有 Chrome 实例（通过 CDP）抓取 Reddit
 */

const { execSync } = require('child_process');

class RedditCDPAdapter {
  constructor(config) {
    this.name = 'reddit';
    this.baseUrl = 'https://www.reddit.com';
    this.targetUrl = 'https://www.reddit.com/r/artificial/hot/';
    this.chromePort = process.env.CHROME_DEBUG_PORT || '31010';
  }

  exec(command) {
    const fullCommand = `agent-browser --cdp ${this.chromePort} ${command}`;
    try {
      const result = execSync(fullCommand, {
        encoding: 'utf-8',
        timeout: 30000,
        stdio: ['pipe', 'pipe', 'pipe']
      });
      return result.trim();
    } catch (error) {
      console.error(`[RedditCDP] Error: ${error.message}`);
      throw error;
    }
  }

  async fetchHotspots() {
    const results = [];
    
    try {
      console.log('[RedditCDP] Fetching from ' + this.targetUrl);
      
      // 打开 Reddit
      this.exec(`open "${this.targetUrl}"`);
      await new Promise(r => setTimeout(r, 8000));
      
      // 提取帖子 - 简化 JS 代码
      const jsCode = `(() => {
        const posts = [];
        document.querySelectorAll('shreddit-post').forEach((el, index) => {
          if (index >= 25) return;
          try {
            const permalink = el.getAttribute('permalink');
            const titleSlot = el.querySelector('[slot="title"]');
            const title = titleSlot ? titleSlot.textContent.trim() : '';
            const commentCount = parseInt(el.getAttribute('comment-count') || '0');
            const postId = permalink ? permalink.match(/comments\\/(\\w+)/)?.[1] : null;
            const url = permalink ? 'https://www.reddit.com' + permalink : '';
            const authorEl = el.querySelector('a[href^="/user/"]');
            const author = authorEl ? authorEl.textContent.replace(/^u\\//, '').trim() : 'unknown';
            if (title && url && postId) {
              posts.push({id: postId, title, url, author, comments: commentCount});
            }
          } catch (e) {}
        });
        return JSON.stringify(posts);
      })()`;
      
      const result = this.exec(`eval "${jsCode.replace(/"/g, '\\"')}"`);
      
      console.log('[RedditCDP] Raw result type:', typeof result);
      console.log('[RedditCDP] Raw result:', result.substring(0, 300));
      
      // 解析结果
      let posts = [];
      try {
        // 如果结果已经是字符串形式的 JSON，直接解析
        if (typeof result === 'string' && result.startsWith('"') && result.endsWith('"')) {
          // 双重转义的 JSON，需要解析两次
          const unescaped = JSON.parse(result);
          posts = JSON.parse(unescaped);
        } else {
          posts = JSON.parse(result);
        }
      } catch (e) {
        console.error('[RedditCDP] JSON parse error:', e.message);
        posts = [];
      }
      
      console.log(`[RedditCDP] Found ${posts.length} posts`);
      
      // 转换为标准格式
      for (const post of posts) {
        const score = Math.min(100, Math.round(post.comments * 2 + 50));
        results.push({
          id: `reddit_${post.id}`,
          platform: this.name,
          title: post.title,
          content: post.title,
          author: post.author,
          author_id: post.author,
          url: post.url,
          published_at: new Date().toISOString(),
          crawled_at: new Date().toISOString(),
          metrics: { comments: post.comments, engagement: post.comments },
          score: score,
          avg_score: score,
          is_ai_related: true
        });
      }
      
    } catch (err) {
      console.error('[RedditCDP] Failed:', err.message);
    }
    
    return results;
  }
}

module.exports = { RedditCDPAdapter };
