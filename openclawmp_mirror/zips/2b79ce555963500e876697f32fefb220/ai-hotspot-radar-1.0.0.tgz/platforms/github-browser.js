/**
 * GitHub Trending Adapter using OpenClaw Browser Skill
 * Scrapes github.com/trending for AI repositories
 */

class GitHubBrowserAdapter {
  constructor(config) {
    this.name = 'github';
    this.baseUrl = 'https://github.com';
    this.trendingUrl = 'https://github.com/trending';
    
    // AI 相关关键词
    this.aiKeywords = [
      'AI', 'artificial-intelligence', 'machine-learning', 'deep-learning',
      'LLM', 'GPT', 'transformer', 'neural-network', 'pytorch', 'tensorflow',
      'langchain', 'openai', 'claude', 'llama', 'mistral', 'huggingface',
      'RAG', 'embeddings', 'vector-database', 'agent', 'autogpt',
      'crewai', 'dify', 'langflow', 'ollama', 'vllm', 'llamaindex'
    ];
  }

  async fetchHotspots(browser) {
    const results = [];
    
    try {
      console.log('[GitHubBrowser] Fetching trending Python repos...');
      
      // Use OpenClaw browser skill
      const page = await browser.open('https://github.com/trending/python?since=daily');
      await new Promise(r => setTimeout(r, 3000));
      
      // Get snapshot
      const snapshot = await browser.snapshot();
      
      // Parse trending repos from snapshot
      const repos = this.parseTrendingRepos(snapshot);
      console.log(`[GitHubBrowser] Found ${repos.length} repos`);
      
      // Filter AI repos
      for (const repo of repos.slice(0, 20)) {
        if (this.isAIRepo(repo)) {
          results.push(this.normalizeData(repo));
        }
      }
      
      console.log(`[GitHubBrowser] Filtered ${results.length} AI repos`);
      
    } catch (err) {
      console.error('[GitHubBrowser] Failed:', err.message);
    }
    
    return results;
  }

  parseTrendingRepos(snapshot) {
    const repos = [];
    const lines = snapshot.split('\n');
    
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      
      // Look for repository links (format: owner/repo)
      if (line.includes('link') && line.includes('/')) {
        const match = line.match(/link\s+"([^"]+)"\s+\[ref=([^\]]+)\]/);
        if (match) {
          const text = match[1];
          
          // Check if it's a repo name (contains / but not http)
          if (text.includes('/') && !text.includes('http') && !text.includes(' ')) {
            const parts = text.split('/');
            if (parts.length === 2 && parts[0] && parts[1]) {
              const [owner, name] = parts;
              
              // Look for stars in nearby lines
              let stars = 0;
              let description = '';
              
              for (let j = i + 1; j < Math.min(i + 10, lines.length); j++) {
                // Extract stars
                const starMatch = lines[j].match(/(\d[\d,]*)\s*stars?/i);
                if (starMatch) {
                  stars = parseInt(starMatch[1].replace(/,/g, ''));
                }
                
                // Extract description
                if (!description && lines[j].includes('text')) {
                  const descMatch = lines[j].match(/text\s+"([^"]+)"/);
                  if (descMatch && descMatch[1].length > 5 && !descMatch[1].includes('stars')) {
                    description = descMatch[1];
                  }
                }
              }
              
              repos.push({
                owner: owner,
                name: name,
                fullName: text,
                description: description,
                stars: stars,
                url: `https://github.com/${text}`
              });
            }
          }
        }
      }
    }
    
    return repos;
  }

  isAIRepo(repo) {
    const text = `${repo.name} ${repo.description}`.toLowerCase();
    return this.aiKeywords.some(keyword => 
      text.includes(keyword.toLowerCase())
    );
  }

  normalizeData(item) {
    // Calculate score based on stars
    let score = 50;
    if (item.stars > 1000) score = 95;
    else if (item.stars > 500) score = 85;
    else if (item.stars > 200) score = 75;
    else if (item.stars > 100) score = 65;
    else if (item.stars > 50) score = 55;
    
    score = Math.min(100, Math.max(0, score));
    
    const id = `github_${item.owner}_${item.name}_${Date.now()}`;
    
    return {
      id: id,
      platform: this.name,
      title: `${item.fullName}: ${item.description || 'AI Repository'}`,
      content: item.description || '',
      author: item.owner,
      author_id: item.owner,
      url: item.url,
      published_at: new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        stars: item.stars,
        language: 'Python'
      },
      score: score,
      avg_score: score,
      is_ai_related: true
    };
  }
}

module.exports = { GitHubBrowserAdapter };
