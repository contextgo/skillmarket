/**
 * 机器之心 (Jiqizhixin) Adapter using Agent Browser
 * Scrapes jiqizhixin.com for AI news
 * 
 * UPDATED: Use /articles instead of /articles/hot (bypasses login requirement)
 */

const { AgentBrowserAdapter } = require('./agent-browser-adapter');

class JiqizhixinAgentBrowserAdapter extends AgentBrowserAdapter {
  constructor(config) {
    super(config);
    this.name = 'jiqizhixin';
    this.baseUrl = 'https://www.jiqizhixin.com';
    // UPDATED: Use articles page instead of hot (no login required)
    this.articlesUrl = 'https://www.jiqizhixin.com/articles';
    
    // AI 关键词（机器之心专注 AI，几乎所有内容都是 AI 相关）
    this.aiKeywords = [
      'AI', '人工智能', '大模型', 'LLM', 'GPT', 'Claude',
      '机器学习', '深度学习', '神经网络', '计算机视觉', 'NLP',
      'OpenAI', 'Google', 'Meta', 'Microsoft', '百度', '阿里', '腾讯',
      '算法', '论文', '研究', '突破', '创新', 'CVPR', 'ICLR', 'CHI',
      'DeepSeek', 'Qwen', 'aiXcoder', '具身智能', '多智能体'
    ];
  }

  async fetchHotspots() {
    const results = [];
    
    try {
      console.log('[JiqizhixinAgentBrowser] Fetching articles from ' + this.articlesUrl);
      
      // Open articles page (not hot page - no login required)
      await this.open(this.articlesUrl);
      await this.wait(5000); // Wait for JS rendering
      
      // Extract articles using JavaScript evaluation
      const articles = await this.extractArticlesWithJS();
      
      console.log(`[JiqizhixinAgentBrowser] Found ${articles.length} AI articles`);
      
      // 机器之心专注 AI，默认所有内容都是 AI 相关
      for (const article of articles.slice(0, 20)) {
        results.push(this.normalizeData(article));
      }
      
    } catch (err) {
      console.error('[JiqizhixinAgentBrowser] Failed:', err.message);
    }
    
    await this.close();
    return results;
  }

  async extractArticlesWithJS() {
    try {
      // Use JavaScript to extract articles from the rendered page
      const jsCode = `
        (() => {
          const articles = [];
          const seen = new Set();
          const text = document.body.innerText;
          const lines = text.split('\\n').filter(l => l.trim());
          
          for (let i = 0; i < lines.length; i++) {
            const line = lines[i].trim();
            
            // Article titles are typically longer and contain AI keywords
            if (line.length > 20 && line.length < 100 && 
                (line.includes('AI') || line.includes('模型') || line.includes('论文') || 
                 line.includes('DeepSeek') || line.includes('清华') || line.includes('CVPR') ||
                 line.includes('ICLR') || line.includes('CHI') || line.includes('智能体'))) {
              
              if (seen.has(line)) continue;
              seen.add(line);
              
              // Look for date in next few lines
              let date = '';
              for (let j = i + 1; j < Math.min(i + 3, lines.length); j++) {
                if (lines[j].match(/今天|昨天|\\d{2}月\\d{2}日/)) {
                  date = lines[j];
                  break;
                }
              }
              
              articles.push({
                title: line,
                date: date,
                id: 'jqx_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9)
              });
            }
          }
          
          return articles.slice(0, 15);
        })()
      `;
      
      // Execute via agent-browser eval
      const result = this.exec(`eval "${jsCode.replace(/"/g, '\\"')}"`);
      return JSON.parse(result || '[]');
    } catch (err) {
      console.error('[JiqizhixinAgentBrowser] JS extract error:', err.message);
      return [];
    }
  }

  normalizeData(item) {
    // Calculate score based on freshness
    let score = 75; // Base score for 机器之心 (AI-focused media)
    
    if (item.date === '今天') score += 10;
    else if (item.date === '昨天') score += 5;
    
    score = Math.min(100, Math.max(0, score));
    
    return {
      id: this.generateId(item),
      platform: this.name,
      title: item.title,
      content: item.title,
      author: item.author || '机器之心',
      author_id: item.author || 'jiqizhixin',
      url: `https://www.jiqizhixin.com/search?q=${encodeURIComponent(item.title)}`,
      published_at: new Date().toISOString(),
      crawled_at: new Date().toISOString(),
      metrics: {
        views: item.views || 0,
        date: item.date
      },
      score: score,
      avg_score: score,
      is_ai_related: true // 机器之心专注 AI
    };
  }
}

module.exports = { JiqizhixinAgentBrowserAdapter };
