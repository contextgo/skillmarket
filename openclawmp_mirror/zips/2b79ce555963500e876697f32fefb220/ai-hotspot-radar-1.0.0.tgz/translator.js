// 翻译模块 - 多引擎翻译，确保可靠性
const axios = require('axios');

class Translator {
  constructor(apiKey, baseUrl = 'https://openrouter.ai/api/v1') {
    // 优先使用传入的 apiKey，其次环境变量，最后使用默认免费API
    this.apiKey = apiKey || process.env.OPENROUTER_API_KEY || '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';
    this.baseUrl = baseUrl;
    // 更新引擎优先级：OpenRouter Step-3.5-Flash 免费版优先
    this.engines = ['openrouter-step35', 'stepfun', 'libretranslate'];
    this.openrouterModel = 'openrouter/stepfun/step-3.5-flash:free';
  }

  // 翻译质量评估
  evaluateQuality(original, translation) {
    const metrics = {
      lengthRatio: translation.length / original.length,
      hasChinese: /[\u4e00-\u9fa5]/.test(translation),
      chineseRatio: (translation.match(/[\u4e00-\u9fa5]/g) || []).length / translation.length,
      preservedTerms: this.countPreservedTerms(original, translation),
      isTruncated: translation.endsWith('...') && !original.endsWith('...')
    };

    // 计算质量分数 (0-100)
    let score = 0;
    
    // 有中文内容 +30
    if (metrics.hasChinese) score += 30;
    
    // 中文比例适中 (20%-80%) +20
    if (metrics.chineseRatio >= 0.2 && metrics.chineseRatio <= 0.8) score += 20;
    
    // 长度比例合理 (0.5-2.0) +20
    if (metrics.lengthRatio >= 0.5 && metrics.lengthRatio <= 2.0) score += 20;
    
    // 保留了技术术语 +20
    if (metrics.preservedTerms > 0) score += 20;
    
    // 没有被截断 +10
    if (!metrics.isTruncated) score += 10;

    return {
      score: Math.min(100, score),
      metrics,
      quality: score >= 80 ? 'high' : score >= 60 ? 'medium' : 'low'
    };
  }

  // 统计保留的技术术语
  countPreservedTerms(original, translation) {
    const techTerms = ['AI', 'LLM', 'GPT', 'API', 'GPU', 'CPU', 'ML', 'NLP', 'CV', 'RL', 'LLaMA', 'Claude', 'OpenAI', 'GitHub', 'Google', 'Meta', 'Microsoft', 'Amazon', 'Apple', 'Twitter', 'Reddit', 'JavaScript', 'Python', 'React', 'Vue', 'Node.js', 'Docker', 'Kubernetes', 'AWS', 'Azure', 'GCP'];
    
    let count = 0;
    for (const term of techTerms) {
      if (original.includes(term) && translation.includes(term)) {
        count++;
      }
    }
    return count;
  }

  // 检测文本语言
  detectLanguage(text) {
    const chineseChars = text.match(/[\u4e00-\u9fa5]/g);
    if (chineseChars && chineseChars.length > text.length * 0.3) {
      return 'zh';
    }
    return 'en';
  }

  // GPT-4 翻译 - 最高质量
  async translateWithGPT4(text) {
    console.log('[Translator] Using GPT-4 (highest quality)...');
    const response = await axios.post(`${this.baseUrl}/chat/completions`, {
      model: 'openai/gpt-4o-mini',
      messages: [
        {
          role: 'system',
          content: `You are an expert translator specializing in AI and technology content translation from English to Chinese.

Translation Guidelines:
1. Translate to natural, fluent Simplified Chinese (简体中文)
2. Preserve technical terms: AI, LLM, API, GPU, GPT, Claude, OpenAI, GitHub, etc.
3. Keep company names, product names, and GitHub repos in original form
4. Make the translation concise and suitable for news headlines
5. Maintain the original meaning, tone, and emphasis
6. For code repositories, keep the format: "username/repo-name: description"
7. Return ONLY the translation, no explanations, no quotes

Quality Standards:
- High: Accurate, natural, preserves all technical terms
- Medium: Understandable but may lose some nuance
- Low: Literal translation or missing key terms

Examples of high-quality translations:
- "Open-source AI system outperforms GPT-4 on coding benchmarks" 
  → "开源AI系统在编程基准测试中超越GPT-4"
- "GitHub Copilot gets major update with new features" 
  → "GitHub Copilot 重大更新，新增多项功能"
- "Anthropic releases Claude 3.7 with extended thinking" 
  → "Anthropic 发布 Claude 3.7，支持扩展思考模式"`
        },
        {
          role: 'user',
          content: `Translate this technology news headline to Chinese:\n\n${text}`
        }
      ],
      temperature: 0.2,
      max_tokens: 1000
    }, {
      headers: {
        'Authorization': `Bearer ${this.apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://hotspot-radar.local',
        'X-Title': 'Hotspot Radar Translator'
      },
      timeout: 30000
    });

    return response.data.choices?.[0]?.message?.content?.trim();
  }

  // 主翻译方法 - 使用 OpenRouter API (StepFun Step 3.5 Flash Free)
  async translateWithOpenRouterStep35(text) {
    try {
      console.log('[Translator] Using OpenRouter Step 3.5 Flash (Free)...');
      
      const response = await axios.post(`${this.baseUrl}/chat/completions`, {
        model: 'openrouter/stepfun/step-3.5-flash:free',
        messages: [
          {
            role: 'system',
            content: `You are an expert translator specializing in AI and technology content. Translate English to natural, fluent Simplified Chinese (简体中文).

Rules:
1. Preserve technical terms: AI, LLM, API, GPU, GPT, Claude, OpenAI, GitHub, etc.
2. Keep company names, product names, GitHub repos in original form
3. Make translation concise, suitable for news headlines
4. Maintain original meaning and tone
5. Return ONLY the translation, no explanations, no quotes, no prefixes

Examples:
- "Open-source AI system outperforms GPT-4" → "开源AI系统性能超越GPT-4"
- "GitHub Copilot gets major update" → "GitHub Copilot 迎来重大更新"`
          },
          {
            role: 'user',
            content: `Translate to Chinese:\n\n${text}`
          }
        ],
        temperature: 0.2,
        max_tokens: 1000
      }, {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json',
          'HTTP-Referer': 'https://hotspot-radar.local',
          'X-Title': 'AI Hotspot Radar'
        },
        timeout: 30000
      });

      return response.data.choices?.[0]?.message?.content?.trim();
    } catch (err) {
      console.error('[OpenRouter-Step3.5] Failed:', err.message);
      return null;
    }
  }

  // 备用翻译 - 使用本地 StepFun（优化提示词）
  async translateWithStepFun(text) {
    try {
      const response = await axios.post('http://127.0.0.1:3199/v1/chat/completions', {
        model: 'stepfun/step-alpha',
        messages: [
          {
            role: 'system',
            content: `You are an expert translator specializing in AI and technology content. 

Translation guidelines:
1. Translate English to natural, fluent Chinese (简体中文)
2. Preserve technical terms: AI, LLM, API, GPU, etc. can remain in English
3. Keep company names, product names, and GitHub repos in original form
4. Make the translation concise and suitable for news headlines
5. Maintain the original meaning and tone
6. Return ONLY the translation, no explanations, no quotes

Examples:
- "Open-source AI system outperforms GPT-4" → "开源AI系统性能超越GPT-4"
- "GitHub Copilot gets major update" → "GitHub Copilot 迎来重大更新"
- "New LLM from Anthropic beats benchmarks" → "Anthropic 新大模型刷新基准测试记录"`
          },
          {
            role: 'user',
            content: `Translate this to Chinese:\n\n${text}`
          }
        ],
        temperature: 0.2,
        max_tokens: 1000
      }, {
        headers: {
          'Authorization': 'Bearer stepfun-model-proxy',
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });
      let result = response.data.choices?.[0]?.message?.content?.trim();
      
      // 过滤掉可能的系统提示词残留
      if (result) {
        // 移除常见的前缀模式
        const prefixesToRemove = [
          "I'll translate this to Chinese following your guidelines:",
          "I'll translate this to Chinese:",
          "Translation:",
          "翻译：",
          "译文：",
          "以下是翻译：",
          "Here's the translation:",
          "Here is the translation:"
        ];
        
        for (const prefix of prefixesToRemove) {
          if (result.toLowerCase().startsWith(prefix.toLowerCase())) {
            result = result.substring(prefix.length).trim();
          }
          // 也检查是否包含在开头（带换行）
          const idx = result.toLowerCase().indexOf(prefix.toLowerCase());
          if (idx === 0 || (idx > 0 && idx < 10)) {
            result = result.substring(idx + prefix.length).trim();
          }
        }
        
        // 移除开头的冒号或换行
        result = result.replace(/^[：:\n\s]+/, '');
      }
      
      return result;
    } catch (err) {
      console.error('[StepFun] Failed:', err.message);
      return null;
    }
  }

  // 第三备用 - 使用 LibreTranslate (免费开源)
  async translateWithLibreTranslate(text) {
    try {
      const response = await axios.post('https://libretranslate.de/translate', {
        q: text,
        source: 'en',
        target: 'zh',
        format: 'text'
      }, {
        headers: { 'Content-Type': 'application/json' },
        timeout: 20000
      });
      return response.data.translatedText;
    } catch (err) {
      console.error('[LibreTranslate] Failed:', err.message);
      return null;
    }
  }

  // DeepL 翻译 (高质量，需要 API Key)
  async translateWithDeepL(text) {
    const apiKey = process.env.DEEPL_API_KEY;
    if (!apiKey) {
      console.log('[DeepL] No API key configured, skipping');
      return null;
    }
    
    try {
      console.log('[Translator] Using DeepL...');
      const response = await axios.post('https://api-free.deepl.com/v2/translate', {
        text: [text],
        source_lang: 'EN',
        target_lang: 'ZH',
        preserve_formatting: true
      }, {
        headers: {
          'Authorization': `DeepL-Auth-Key ${apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 20000
      });
      return response.data.translations?.[0]?.text;
    } catch (err) {
      console.error('[DeepL] Failed:', err.message);
      return null;
    }
  }

  // Google Translate (需要 API Key)
  async translateWithGoogle(text) {
    const apiKey = process.env.GOOGLE_TRANSLATE_API_KEY;
    if (!apiKey) {
      console.log('[Google] No API key configured, skipping');
      return null;
    }
    
    try {
      console.log('[Translator] Using Google Translate...');
      const response = await axios.post(`https://translation.googleapis.com/language/translate/v2?key=${apiKey}`, {
        q: text,
        source: 'en',
        target: 'zh-CN',
        format: 'text'
      }, {
        timeout: 20000
      });
      return response.data.data?.translations?.[0]?.translatedText;
    } catch (err) {
      console.error('[Google] Failed:', err.message);
      return null;
    }
  }

  // 翻译文本为中文（带质量评估）
  async translateToChinese(text, maxLength = 500, options = {}) {
    if (!text || text.trim().length === 0) return '';
    
    // 如果已经是中文为主，直接返回
    if (this.detectLanguage(text) === 'zh') {
      return text;
    }

    // 截断过长文本
    const truncated = text.length > maxLength ? text.substring(0, maxLength) + '...' : text;

    const engines = [
      { name: 'OpenRouter-Step3.5', fn: () => this.translateWithOpenRouterStep35(truncated), priority: 1 },
      { name: 'StepFun', fn: () => this.translateWithStepFun(truncated), priority: 2 },
      { name: 'LibreTranslate', fn: () => this.translateWithLibreTranslate(truncated), priority: 3 }
    ];

    let bestResult = null;
    let bestQuality = 0;

    for (const engine of engines) {
      try {
        console.log(`[Translator] Trying ${engine.name}...`);
        const result = await engine.fn();
        
        if (!result || result === truncated) continue;

        // 评估翻译质量
        const quality = this.evaluateQuality(truncated, result);
        console.log(`[Translator] ${engine.name} quality: ${quality.score}/100 (${quality.quality})`);

        // 使用监控器检测异常
        const anomalies = translationMonitor.detectAnomaly(truncated, result, engine.name);
        if (anomalies.length > 0) {
          console.error(`[Translator] ANOMALY DETECTED in ${engine.name}:`, anomalies.map(a => a.type));
          // 清理翻译结果
          result = translationMonitor.sanitizeTranslation(result);
          // 记录异常
          translationMonitor.reportAnomaly(
            options.hotspotId || 'unknown',
            truncated,
            result,
            engine.name,
            anomalies
          );
        }

        // 高质量翻译直接返回
        if (quality.quality === 'high') {
          if (options.returnQuality) {
            return { text: result, quality, engine: engine.name };
          }
          return result;
        }

        // 记录最佳结果
        if (quality.score > bestQuality) {
          bestQuality = quality.score;
          bestResult = { text: result, quality, engine: engine.name };
        }

        // 中等质量可接受
        if (quality.quality === 'medium') {
          if (options.returnQuality) {
            return { text: result, quality, engine: engine.name };
          }
          return result;
        }

      } catch (err) {
        console.error(`[${engine.name}] Failed:`, err.message);
      }
    }

    // 返回最佳结果（即使质量较低）
    if (bestResult) {
      console.log(`[Translator] Using best result from ${bestResult.engine} (score: ${bestResult.quality.score})`);
      if (options.returnQuality) {
        return bestResult;
      }
      return bestResult.text;
    }

    // 都失败，返回原文
    return text;
  }

  // 批量翻译热点
  async translateHotspots(hotspots) {
    const translated = [];
    for (const hotspot of hotspots) {
      try {
        const titleZh = await this.translateToChinese(hotspot.title, 200);
        const contentZh = await this.translateToChinese(hotspot.content, 500);
        
        translated.push({
          ...hotspot,
          title_zh: titleZh,
          content_zh: contentZh,
          is_translated: true
        });
      } catch (err) {
        console.error('[Translator] Failed to translate hotspot:', err.message);
        translated.push({
          ...hotspot,
          title_zh: hotspot.title,
          content_zh: hotspot.content,
          is_translated: false
        });
      }
    }
    return translated;
  }
}

// 翻译质量监控器
class TranslationMonitor {
  constructor() {
    this.anomalyPatterns = [
      /I'll translate this to Chinese/i,
      /Translation guidelines:/i,
      /Here is the translation:/i,
      /Here's the translation:/i,
      /译文[：:]/,
      /翻译[：:]/,
      /以下是翻译/,
      /^[\s\n]*[：:]/,
      /Return ONLY the translation/i,
      /You are an expert translator/i
    ];
    this.qualityThreshold = 40; // 质量分数阈值
    this.alertCount = 0;
    this.maxAlertsPerHour = 10;
    this.lastAlertTime = 0;
  }

  // 检测翻译异常
  detectAnomaly(original, translation, engine) {
    const anomalies = [];

    // 1. 检测系统提示词残留
    for (const pattern of this.anomalyPatterns) {
      if (pattern.test(translation)) {
        anomalies.push({
          type: 'system_prompt_leak',
          pattern: pattern.toString(),
          severity: 'high'
        });
      }
    }

    // 2. 检测翻译质量过低
    if (translation.length < original.length * 0.1) {
      anomalies.push({
        type: 'too_short',
        severity: 'medium',
        details: `Translation too short: ${translation.length} vs ${original.length}`
      });
    }

    // 3. 检测无中文内容
    if (!/[\u4e00-\u9fa5]/.test(translation)) {
      anomalies.push({
        type: 'no_chinese',
        severity: 'high',
        details: 'No Chinese characters in translation'
      });
    }

    // 4. 检测重复内容
    if (translation === original) {
      anomalies.push({
        type: 'no_translation',
        severity: 'medium',
        details: 'Translation same as original'
      });
    }

    return anomalies;
  }

  // 记录异常并告警
  reportAnomaly(hotspotId, original, translation, engine, anomalies) {
    const now = Date.now();
    
    // 限制告警频率
    if (now - this.lastAlertTime < 3600000) { // 1小时内
      this.alertCount++;
      if (this.alertCount > this.maxAlertsPerHour) {
        return; // 超过阈值，静默处理
      }
    } else {
      this.alertCount = 0;
      this.lastAlertTime = now;
    }

    // 记录到日志
    console.error('[TranslationMonitor] ANOMALY DETECTED:', {
      hotspotId,
      engine,
      anomalies: anomalies.map(a => a.type),
      original: original.substring(0, 100),
      translation: translation.substring(0, 100),
      timestamp: new Date().toISOString()
    });

    // 高严重度异常，记录到数据库
    const highSeverityAnomalies = anomalies.filter(a => a.severity === 'high');
    if (highSeverityAnomalies.length > 0) {
      this.saveAnomalyToDatabase(hotspotId, original, translation, engine, anomalies);
    }
  }

  // 保存异常到数据库
  async saveAnomalyToDatabase(hotspotId, original, translation, engine, anomalies) {
    try {
      const Storage = require('./storage');
      const storage = new Storage();
      
      storage.saveTranslationAnomaly({
        hotspot_id: hotspotId,
        original_text: original,
        translated_text: translation,
        engine,
        anomaly_types: JSON.stringify(anomalies.map(a => a.type)),
        severity: anomalies.some(a => a.severity === 'high') ? 'high' : 'medium',
        created_at: new Date().toISOString()
      });
      
      console.log('[TranslationMonitor] Anomaly saved to database');
    } catch (err) {
      console.error('[TranslationMonitor] Failed to save anomaly:', err.message);
    }
  }

  // 清理翻译结果
  sanitizeTranslation(translation) {
    if (!translation) return '';
    
    let cleaned = translation;
    
    // 移除系统提示词残留
    const patterns = [
      /I'll translate this to Chinese[^\n]*\n*/gi,
      /Translation guidelines:[^\n]*\n*/gi,
      /Here is the translation:[^\n]*\n*/gi,
      /Here's the translation:[^\n]*\n*/gi,
      /Return ONLY the translation[^\n]*\n*/gi,
      /You are an expert translator[\s\S]*?Examples:[\s\S]*?→[^\n]*\n*/gi
    ];
    
    for (const pattern of patterns) {
      cleaned = cleaned.replace(pattern, '');
    }
    
    // 移除开头的冒号和换行
    cleaned = cleaned.replace(/^[\s：:\n]+/, '');
    
    return cleaned.trim();
  }
}

// 创建全局监控器实例
const translationMonitor = new TranslationMonitor();

// 导出
module.exports = Translator;
module.exports.TranslationMonitor = TranslationMonitor;
module.exports.translationMonitor = translationMonitor;
