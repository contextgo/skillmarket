const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');
const { getConnectionPool } = require('../utils/connection-pool');

class Storage {
  constructor(dbPath = 'data/hotspots.db', usePool = false) {
    // 确保目录存在
    const dir = path.dirname(dbPath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }

    this.dbPath = dbPath;
    this.usePool = usePool;
    this.pool = null;

    if (usePool) {
      // 使用连接池
      this.pool = getConnectionPool(dbPath, {
        maxReadConnections: 3,
        maxWriteConnections: 1,
        acquireTimeout: 5000,
        idleTimeout: 300000
      });
      console.log('[Storage] Using connection pool mode');
    } else {
      // 启用 WAL 模式以提升并发性能
      this.db = new Database(dbPath, { 
        verbose: undefined,
        fileMustExist: false
      });
      
      // 启用 WAL 模式
      this.db.pragma('journal_mode = WAL');
      // 设置同步模式为 NORMAL，平衡性能和数据安全
      this.db.pragma('synchronous = NORMAL');
      // 设置缓存大小（约 20MB）
      this.db.pragma('cache_size = -20000');
      // 启用内存映射 I/O
      this.db.pragma('mmap_size = 268435456'); // 256MB
      // 设置临时存储为内存
      this.db.pragma('temp_store = MEMORY');
    }
    
    this.init();
  }

  init() {
    // 热点内容表（添加翻译字段）
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS hotspots (
        id TEXT PRIMARY KEY,
        platform TEXT NOT NULL,
        title TEXT NOT NULL,
        title_zh TEXT,
        content TEXT,
        content_zh TEXT,
        author TEXT,
        author_id TEXT,
        url TEXT UNIQUE,
        media_urls TEXT,
        metrics TEXT,
        raw_data TEXT,
        crawled_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        published_at DATETIME
      )
    `);

    // 创建索引
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_platform ON hotspots(platform)');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_crawled ON hotspots(crawled_at)');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_author ON hotspots(author_id)');
    
    // 复合索引 - 优化平台+时间查询（用于按平台筛选并按时间排序）
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_platform_published ON hotspots(platform, published_at DESC)');
    
    // 复合索引 - 优化热点评分+更新时间查询（用于热度排序）
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_score_updated ON hotspots(avg_score DESC, crawled_at DESC) WHERE avg_score > 0');

    // 评分表（AI自动评分 + 人类反馈）
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS scores (
        id TEXT PRIMARY KEY,
        hotspot_id TEXT NOT NULL,
        source TEXT NOT NULL, -- 'ai' or 'human'
        score REAL NOT NULL,
        factors TEXT, -- JSON: { engagement: 0.8, freshness: 0.6, ... }
        feedback TEXT, -- 人类反馈评论
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (hotspot_id) REFERENCES hotspots(id) ON DELETE CASCADE
      )
    `);
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_hotspot ON scores(hotspot_id)');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_source ON scores(source)');

    // 收藏表（服务器端存储，防止清理时误删）
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS favorites (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hotspot_id TEXT NOT NULL,
        user_id TEXT DEFAULT 'anonymous',
        title TEXT,
        url TEXT,
        platform TEXT,
        favorited_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (hotspot_id) REFERENCES hotspots(id) ON DELETE CASCADE
      )
    `);
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_favorite_hotspot ON favorites(hotspot_id)');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_favorite_user ON favorites(user_id)');

    // 用户反馈记录表
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS feedback (
        id TEXT PRIMARY KEY,
        hotspot_id TEXT NOT NULL,
        user_id TEXT NOT NULL,
        action TEXT NOT NULL, -- 'like', 'dislike', 'comment', 'share', 'flag'
        rating INTEGER, -- 1-5 星评分
        comment TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (hotspot_id) REFERENCES hotspots(id) ON DELETE CASCADE
      )
    `);
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_user ON feedback(user_id)');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_action ON feedback(action)');

    // 平台账号监控表
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS watched_accounts (
        platform TEXT NOT NULL,
        account_id TEXT NOT NULL,
        account_name TEXT,
        last_crawled DATETIME,
        active INTEGER DEFAULT 1,
        PRIMARY KEY (platform, account_id)
      )
    `);
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_active ON watched_accounts(active)');

    // 翻译反馈表
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS translation_feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hotspot_id TEXT NOT NULL,
        rating INTEGER NOT NULL, -- 1-5 星评分
        comment TEXT,
        suggested_translation TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (hotspot_id) REFERENCES hotspots(id) ON DELETE CASCADE
      )
    `);
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_translation_hotspot ON translation_feedback(hotspot_id)');

    // 翻译异常监控表
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS translation_anomalies (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hotspot_id TEXT NOT NULL,
        original_text TEXT NOT NULL,
        translated_text TEXT NOT NULL,
        engine TEXT NOT NULL,
        anomaly_types TEXT NOT NULL, -- JSON array
        severity TEXT NOT NULL, -- 'high', 'medium', 'low'
        status TEXT DEFAULT 'open', -- 'open', 'fixed', 'ignored'
        fixed_at DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (hotspot_id) REFERENCES hotspots(id) ON DELETE CASCADE
      )
    `);
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_anomaly_hotspot ON translation_anomalies(hotspot_id)');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_anomaly_severity ON translation_anomalies(severity)');
    this.db.exec('CREATE INDEX IF NOT EXISTS idx_anomaly_status ON translation_anomalies(status)');

    // 分数聚合视图（实时热度排名）
    this.db.exec(`
      CREATE VIEW IF NOT EXISTS hotspot_rankings AS
      SELECT
        h.*,
        COALESCE((SELECT AVG(score) FROM scores WHERE hotspot_id = h.id), 0) as avg_score,
        (SELECT COUNT(*) FROM scores WHERE hotspot_id = h.id) as score_count,
        (SELECT COUNT(*) FROM feedback WHERE hotspot_id = h.id) as feedback_count
      FROM hotspots h
    `);
  }

  // 保存热点
  saveHotspot(hotspot) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO hotspots
      (id, platform, title, title_zh, content, content_zh, author, author_id, url, media_urls, metrics, raw_data, crawled_at, published_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(
      hotspot.id,
      hotspot.platform,
      hotspot.title,
      hotspot.title_zh || null,
      hotspot.content || '',
      hotspot.content_zh || null,
      hotspot.author || '',
      hotspot.author_id || '',
      hotspot.url,
      JSON.stringify(hotspot.media_urls || []),
      typeof hotspot.metrics === 'string' ? hotspot.metrics : JSON.stringify(hotspot.metrics || {}),
      typeof hotspot.raw_data === 'string' ? hotspot.raw_data : JSON.stringify(hotspot.raw_data || {}),
      hotspot.crawled_at || new Date().toISOString(),
      hotspot.published_at || null
    );
  }

  // 保存评分
  saveScore(score) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO scores
      (id, hotspot_id, source, score, factors, feedback, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(
      score.id || `${score.hotspot_id}_${score.source}_${Date.now()}`,
      score.hotspot_id,
      score.source,
      score.score,
      JSON.stringify(score.factors || {}),
      score.feedback || '',
      score.created_at || new Date().toISOString()
    );
  }

  // 保存用户反馈
  saveFeedback(feedback) {
    const stmt = this.db.prepare(`
      INSERT INTO feedback (id, hotspot_id, user_id, action, rating, comment, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(
      feedback.id || `fb_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      feedback.hotspot_id,
      feedback.user_id,
      feedback.action,
      feedback.rating || null,
      feedback.comment || '',
      feedback.created_at || new Date().toISOString()
    );
  }

  // 获取热点（支持分页、排序）
  getHotspots(options = {}) {
    const {
      platform = null,
      limit = 50,
      offset = 0,
      sortBy = 'h.crawled_at',
      sortOrder = 'DESC',
      minScore = null
    } = options;

    // 使用子查询先聚合评分和反馈，避免 GROUP BY 问题
    // 优先使用 hotspots 表中的 avg_score，如果没有则使用 scores 表的计算值
    let query = `
      SELECT h.*, 
             COALESCE(NULLIF(h.avg_score, 0), s.avg_score, 0) as avg_score,
             COALESCE(s.score_count, 0) as score_count,
             COALESCE(f.feedback_count, 0) as feedback_count
      FROM hotspots h
      LEFT JOIN (
        SELECT hotspot_id, 
               AVG(score) as avg_score,
               COUNT(DISTINCT id) as score_count
        FROM scores
        GROUP BY hotspot_id
      ) s ON h.id = s.hotspot_id
      LEFT JOIN (
        SELECT hotspot_id, 
               COUNT(DISTINCT id) as feedback_count
        FROM feedback
        GROUP BY hotspot_id
      ) f ON h.id = f.hotspot_id
    `;
    
    const params = [];
    const conditions = [];

    if (platform) {
      conditions.push('h.platform = ?');
      params.push(platform);
    }

    if (minScore !== null) {
      conditions.push('COALESCE(s.avg_score, 0) >= ?');
      params.push(minScore);
    }

    if (conditions.length > 0) {
      query += ' WHERE ' + conditions.join(' AND ');
    }

    // 默认排序：有评分的热点优先，然后按时间排序
    if (sortBy === 'h.crawled_at') {
      query += ` ORDER BY COALESCE(NULLIF(h.avg_score, 0), s.avg_score, 0) DESC, h.crawled_at ${sortOrder} LIMIT ? OFFSET ?`;
    } else {
      query += ` ORDER BY ${sortBy} ${sortOrder} LIMIT ? OFFSET ?`;
    }
    params.push(limit, offset);

    return this.db.prepare(query).all(...params);
  }

  // 获取单个热点详情
  getHotspotById(id) {
    // 使用子查询避免 GROUP BY 问题
    const query = `
      SELECT h.*, 
             COALESCE(s.avg_score, 0) as avg_score,
             s.scores_json as ai_scores,
             f.actions_json as user_actions
      FROM hotspots h
      LEFT JOIN (
        SELECT hotspot_id, 
               AVG(score) as avg_score,
               json_group_array(score) as scores_json
        FROM scores
        GROUP BY hotspot_id
      ) s ON h.id = s.hotspot_id
      LEFT JOIN (
        SELECT hotspot_id, 
               json_group_array(action) as actions_json
        FROM feedback
        GROUP BY hotspot_id
      ) f ON h.id = f.hotspot_id
      WHERE h.id = ?
    `;
    return this.db.prepare(query).get(id);
  }

  // 更新热点状态（标记已处理等）
  updateHotspot(id, updates) {
    const fields = [];
    const params = [];
    for (const [key, value] of Object.entries(updates)) {
      fields.push(`${key} = ?`);
      params.push(value);
    }
    params.push(id);
    const stmt = this.db.prepare(`UPDATE hotspots SET ${fields.join(', ')} WHERE id = ?`);
    return stmt.run(...params);
  }

  // 删除热点
  deleteHotspot(id) {
    const stmt = this.db.prepare('DELETE FROM hotspots WHERE id = ?');
    return stmt.run(id);
  }

  // 获取统计信息
  getStats() {
    return {
      totalHotspots: this.db.prepare('SELECT COUNT(*) as cnt FROM hotspots').get().cnt,
      totalPlatforms: this.db.prepare('SELECT COUNT(DISTINCT platform) as cnt FROM hotspots').get().cnt,
      avgScore: this.db.prepare('SELECT AVG(avg_score) as avg FROM hotspots WHERE avg_score > 0').get().avg || 0,
      recentActivity: this.db.prepare(`
        SELECT platform, COUNT(*) as count 
        FROM hotspots 
        GROUP BY platform
        ORDER BY count DESC
      `).all()
    };
  }

  // 关闭连接
  close() {
    this.db.close();
  }

  // ==================== 通知相关方法 ====================

  // 保存通知
  saveNotification(notification) {
    const stmt = this.db.prepare(`
      INSERT INTO notifications (hotspot_id, type, title, message)
      VALUES (?, ?, ?, ?)
    `);
    return stmt.run(notification.hotspot_id, notification.type, notification.title, notification.message);
  }

  // 获取通知设置
  getNotificationSettings() {
    return this.db.prepare('SELECT * FROM notification_settings WHERE id = 1').get();
  }

  // 更新通知设置
  updateNotificationSettings(settings) {
    const fields = [];
    const params = [];
    for (const [key, value] of Object.entries(settings)) {
      if (key !== 'id') {
        fields.push(`${key} = ?`);
        params.push(value);
      }
    }
    params.push(1); // id = 1
    const stmt = this.db.prepare(`
      UPDATE notification_settings SET ${fields.join(', ')}, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `);
    return stmt.run(...params);
  }

  // 获取未读通知
  getUnreadNotifications(limit = 20) {
    return this.db.prepare(`
      SELECT n.*, h.title as hotspot_title, h.url as hotspot_url, h.avg_score
      FROM notifications n
      LEFT JOIN hotspots h ON n.hotspot_id = h.id
      WHERE n.is_read = 0
      ORDER BY n.created_at DESC
      LIMIT ?
    `).all(limit);
  }

  // 标记通知为已读
  markNotificationAsRead(notificationId) {
    return this.db.prepare('UPDATE notifications SET is_read = 1 WHERE id = ?').run(notificationId);
  }

  // 根据热点ID获取通知
  getNotificationByHotspotId(hotspotId) {
    return this.db.prepare('SELECT * FROM notifications WHERE hotspot_id = ?').get(hotspotId);
  }

  // ==================== 数据清理方法 ====================

  // 删除过期热点（默认保留7天，被收藏的热点不会被删除）
  deleteExpiredHotspots(days = 7) {
    // 首先获取将被删除的热点数量（用于日志）
    const countStmt = this.db.prepare(`
      SELECT COUNT(*) as count 
      FROM hotspots 
      WHERE crawled_at < datetime('now', '-${days} days')
      AND id NOT IN (SELECT DISTINCT hotspot_id FROM favorites)
    `);
    const willDelete = countStmt.get().count;
    
    // 获取被保护的热点数量
    const protectedStmt = this.db.prepare(`
      SELECT COUNT(DISTINCT h.id) as count
      FROM hotspots h
      JOIN favorites f ON h.id = f.hotspot_id
      WHERE h.crawled_at < datetime('now', '-${days} days')
    `);
    const protectedCount = protectedStmt.get().count;
    
    // 执行删除（排除被收藏的热点）
    const stmt = this.db.prepare(`
      DELETE FROM hotspots 
      WHERE crawled_at < datetime('now', '-${days} days')
      AND id NOT IN (SELECT DISTINCT hotspot_id FROM favorites)
    `);
    const result = stmt.run();
    
    console.log(`[Storage] Deleted ${result.changes} expired hotspots (older than ${days} days)`);
    if (protectedCount > 0) {
      console.log(`[Storage] Protected ${protectedCount} favorited hotspots from deletion`);
    }
    return result.changes;
  }

  // 获取过期热点数量（排除被收藏的）
  getExpiredHotspotsCount(days = 7) {
    return this.db.prepare(`
      SELECT COUNT(*) as count 
      FROM hotspots h
      WHERE h.crawled_at < datetime('now', '-${days} days')
      AND NOT EXISTS (
        SELECT 1 FROM favorites f WHERE f.hotspot_id = h.id
      )
    `).get().count;
  }

  // ==================== 收藏方法 ====================

  // 添加收藏
  addFavorite(hotspotId, userId = 'anonymous', hotspotData = {}) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO favorites (hotspot_id, user_id, title, url, platform, favorited_at)
      VALUES (?, ?, ?, ?, ?, datetime('now'))
    `);
    return stmt.run(hotspotId, userId, hotspotData.title || '', hotspotData.url || '', hotspotData.platform || '');
  }

  // 取消收藏
  removeFavorite(hotspotId, userId = 'anonymous') {
    const stmt = this.db.prepare(`
      DELETE FROM favorites WHERE hotspot_id = ? AND user_id = ?
    `);
    return stmt.run(hotspotId, userId);
  }

  // 获取用户的收藏列表
  getFavorites(userId = 'anonymous') {
    return this.db.prepare(`
      SELECT f.*, h.title, h.url, h.platform, h.author, h.avg_score
      FROM favorites f
      LEFT JOIN hotspots h ON f.hotspot_id = h.id
      WHERE f.user_id = ?
      ORDER BY f.favorited_at DESC
    `).all(userId);
  }

  // 检查是否已收藏
  isFavorited(hotspotId, userId = 'anonymous') {
    const result = this.db.prepare(`
      SELECT COUNT(*) as count FROM favorites WHERE hotspot_id = ? AND user_id = ?
    `).get(hotspotId, userId);
    return result.count > 0;
  }

  // 获取被收藏的热点ID列表
  getFavoritedHotspotIds() {
    return this.db.prepare(`
      SELECT DISTINCT hotspot_id FROM favorites
    `).all().map(r => r.hotspot_id);
  }

  // 添加待推送通知（用于 SSE）
  addPendingNotification(notification) {
    // 存储到内存或临时表，前端通过 SSE 获取
    if (!this.pendingNotifications) {
      this.pendingNotifications = [];
    }
    this.pendingNotifications.push({
      ...notification,
      created_at: new Date().toISOString()
    });
    // 只保留最近 100 条
    if (this.pendingNotifications.length > 100) {
      this.pendingNotifications.shift();
    }
  }

  // 获取待推送通知
  getPendingNotifications() {
    const notifications = this.pendingNotifications || [];
    this.pendingNotifications = []; // 清空已获取的
    return notifications;
  }

  // ==================== 翻译异常监控方法 ====================

  // 保存翻译异常
  saveTranslationAnomaly(anomaly) {
    const stmt = this.db.prepare(`
      INSERT INTO translation_anomalies 
      (hotspot_id, original_text, translated_text, engine, anomaly_types, severity, created_at)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(
      anomaly.hotspot_id,
      anomaly.original_text,
      anomaly.translated_text,
      anomaly.engine,
      anomaly.anomaly_types,
      anomaly.severity,
      anomaly.created_at
    );
  }

  // 获取翻译异常列表
  getTranslationAnomalies(options = {}) {
    const { severity, status, limit = 50, offset = 0 } = options;
    let sql = 'SELECT * FROM translation_anomalies WHERE 1=1';
    const params = [];
    
    if (severity) {
      sql += ' AND severity = ?';
      params.push(severity);
    }
    if (status) {
      sql += ' AND status = ?';
      params.push(status);
    }
    
    sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);
    
    return this.db.prepare(sql).all(...params);
  }

  // 修复翻译异常
  fixTranslationAnomaly(id, fixedTranslation) {
    const stmt = this.db.prepare(`
      UPDATE translation_anomalies 
      SET status = 'fixed', fixed_at = datetime('now')
      WHERE id = ?
    `);
    return stmt.run(id);
  }

  // 获取异常统计
  getTranslationAnomalyStats() {
    return this.db.prepare(`
      SELECT 
        severity,
        status,
        COUNT(*) as count
      FROM translation_anomalies
      GROUP BY severity, status
    `).all();
  }

  // 扫描数据库中的异常翻译
  scanForTranslationAnomalies() {
    const anomalies = [];
    
    // 检测包含系统提示词残留的翻译
    const suspiciousPatterns = [
      '%I\'ll translate this%',
      '%Translation guidelines%',
      '%Here is the translation%',
      '%You are an expert translator%'
    ];
    
    for (const pattern of suspiciousPatterns) {
      const results = this.db.prepare(`
        SELECT id, title, title_zh, content, content_zh 
        FROM hotspots 
        WHERE title_zh LIKE ? OR content_zh LIKE ?
      `).all(pattern, pattern);
      
      anomalies.push(...results);
    }
    
    return anomalies;
  }
}

module.exports = Storage;