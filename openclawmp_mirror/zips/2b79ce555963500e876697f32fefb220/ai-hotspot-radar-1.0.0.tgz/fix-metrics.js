const Storage = require('./storage');

const storage = new Storage();

// 获取所有热点
const hotspots = storage.db.prepare('SELECT id, metrics FROM hotspots').all();

console.log(`[FixMetrics] Checking ${hotspots.length} hotspots`);

let fixed = 0;
for (const h of hotspots) {
  try {
    let metrics = h.metrics;
    
    // 检查是否是双重转义的字符串
    if (typeof metrics === 'string' && metrics.startsWith('"') && metrics.includes('\\"')) {
      // 解析双重转义
      metrics = JSON.parse(metrics);
      
      // 更新数据库
      storage.db.prepare('UPDATE hotspots SET metrics = ? WHERE id = ?').run(metrics, h.id);
      fixed++;
      console.log(`[FixMetrics] Fixed: ${h.id.substring(0, 50)}...`);
    }
  } catch (e) {
    console.error(`[FixMetrics] Failed to fix ${h.id}:`, e.message);
  }
}

console.log(`[FixMetrics] Fixed ${fixed} hotspots`);
