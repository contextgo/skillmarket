#!/usr/bin/env node
/**
 * 翻译异常定期扫描脚本
 * 扫描数据库中的异常翻译内容并修复
 */

const Storage = require('../storage');
const { translationMonitor } = require('../translator');

async function scanAndFixAnomalies() {
  console.log('[Scan] Starting translation anomaly scan...');
  
  const storage = new Storage();
  
  // 1. 扫描数据库中的异常翻译
  const anomalies = storage.scanForTranslationAnomalies();
  console.log(`[Scan] Found ${anomalies.length} anomalies in database`);
  
  let fixedCount = 0;
  
  for (const hotspot of anomalies) {
    console.log(`[Scan] Processing: ${hotspot.id}`);
    
    // 清理 title_zh
    if (hotspot.title_zh) {
      const cleanedTitle = translationMonitor.sanitizeTranslation(hotspot.title_zh);
      if (cleanedTitle !== hotspot.title_zh) {
        storage.updateHotspot(hotspot.id, { title_zh: cleanedTitle });
        console.log(`[Scan] Fixed title_zh for ${hotspot.id}`);
        fixedCount++;
      }
    }
    
    // 清理 content_zh
    if (hotspot.content_zh) {
      const cleanedContent = translationMonitor.sanitizeTranslation(hotspot.content_zh);
      if (cleanedContent !== hotspot.content_zh) {
        storage.updateHotspot(hotspot.id, { content_zh: cleanedContent });
        console.log(`[Scan] Fixed content_zh for ${hotspot.id}`);
        fixedCount++;
      }
    }
  }
  
  // 2. 获取异常统计
  const stats = storage.getTranslationAnomalyStats();
  console.log('[Scan] Anomaly stats:', stats);
  
  console.log(`[Scan] Completed. Fixed ${fixedCount} anomalies.`);
  
  // 关闭数据库连接
  if (storage.db) {
    storage.db.close();
  }
}

// 如果直接运行此脚本
if (require.main === module) {
  scanAndFixAnomalies().catch(err => {
    console.error('[Scan] Error:', err);
    process.exit(1);
  });
}

module.exports = { scanAndFixAnomalies };
