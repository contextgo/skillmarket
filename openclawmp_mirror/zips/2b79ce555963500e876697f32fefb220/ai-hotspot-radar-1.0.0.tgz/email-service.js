/**
 * 邮件服务模块 - 每日热点摘要
 * 使用 Resend API 发送邮件
 */

const axios = require('axios');

class EmailService {
  constructor(config = {}) {
    this.apiKey = config.apiKey || process.env.RESEND_API_KEY;
    this.fromEmail = config.fromEmail || 'Hotspot Radar <hotspot@resend.dev>';
    this.baseUrl = 'https://api.resend.com';
  }

  // 发送邮件
  async sendEmail({ to, subject, html, text }) {
    if (!this.apiKey) {
      console.error('[Email] RESEND_API_KEY not configured');
      return { success: false, error: 'API key not configured' };
    }

    try {
      const response = await axios.post(
        `${this.baseUrl}/emails`,
        {
          from: this.fromEmail,
          to,
          subject,
          html,
          text
        },
        {
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json'
          }
        }
      );

      console.log('[Email] Sent successfully:', response.data.id);
      return { success: true, id: response.data.id };
    } catch (err) {
      console.error('[Email] Failed:', err.response?.data || err.message);
      return { success: false, error: err.response?.data || err.message };
    }
  }

  // 生成每日摘要 HTML
  generateDailyDigestHTML(hotspots, stats) {
    const date = new Date().toLocaleDateString('zh-CN', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      weekday: 'long'
    });

    const topHotspots = hotspots
      .sort((a, b) => (b.avg_score || 0) - (a.avg_score || 0))
      .slice(0, 10);

    const hotspotsHTML = topHotspots.map((h, i) => `
      <tr style="border-bottom: 1px solid #e5e7eb;">
        <td style="padding: 12px; vertical-align: top;">
          <span style="display: inline-flex; align-items: center; justify-content: center; width: 28px; height: 28px; background: ${this.getScoreColor(h.avg_score)}; color: white; border-radius: 6px; font-weight: 600; font-size: 13px;">${h.avg_score || 0}</span>
        </td>
        <td style="padding: 12px;">
          <div style="font-weight: 600; color: #111827; margin-bottom: 4px;">${h.title || 'Untitled'}</div>
          <div style="font-size: 13px; color: #6b7280; margin-bottom: 4px;">${h.title_zh || ''}</div>
          <div style="font-size: 12px; color: #9ca3af;">
            <span style="background: #f3f4f6; padding: 2px 8px; border-radius: 4px; margin-right: 8px;">${h.platform}</span>
            ${h.llm_models ? h.llm_models.map(m => `<span style="background: #dbeafe; color: #1e40af; padding: 2px 8px; border-radius: 4px; margin-right: 4px;">${m}</span>`).join('') : ''}
          </div>
        </td>
      </tr>
    `).join('');

    return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>AI 热点日报</title>
</head>
<body style="margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #f9fafb;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background: #f9fafb;">
    <tr>
      <td align="center" style="padding: 40px 20px;">
        <table width="600" cellpadding="0" cellspacing="0" style="background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);">
          <!-- Header -->
          <tr>
            <td style="background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%); padding: 32px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 24px; font-weight: 700;">🔥 AI 热点雷达</h1>
              <p style="color: #94a3b8; margin: 8px 0 0 0; font-size: 14px;">${date}</p>
            </td>
          </tr>

          <!-- Stats -->
          <tr>
            <td style="padding: 24px 32px; background: #f8fafc;">
              <table width="100%" cellpadding="0" cellspacing="0">
                <tr>
                  <td align="center" style="padding: 16px; background: white; border-radius: 8px; margin-right: 8px;">
                    <div style="font-size: 28px; font-weight: 700; color: #0ea5e9;">${stats.total}</div>
                    <div style="font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">总热点</div>
                  </td>
                  <td width="8"></td>
                  <td align="center" style="padding: 16px; background: white; border-radius: 8px;">
                    <div style="font-size: 28px; font-weight: 700; color: #8b5cf6;">${stats.avgScore}</div>
                    <div style="font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">平均分</div>
                  </td>
                  <td width="8"></td>
                  <td align="center" style="padding: 16px; background: white; border-radius: 8px;">
                    <div style="font-size: 28px; font-weight: 700; color: #f59e0b;">${stats.highScore}</div>
                    <div style="font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">高分热点</div>
                  </td>
                  <td width="8"></td>
                  <td align="center" style="padding: 16px; background: white; border-radius: 8px;">
                    <div style="font-size: 28px; font-weight: 700; color: #10b981;">${stats.platforms}</div>
                    <div style="font-size: 12px; color: #64748b; text-transform: uppercase; letter-spacing: 0.5px;">平台数</div>
                  </td>
                </tr>
              </table>
            </td>
          </tr>

          <!-- Hotspots List -->
          <tr>
            <td style="padding: 24px 32px;">
              <h2 style="color: #111827; font-size: 18px; font-weight: 600; margin: 0 0 16px 0;">🏆 TOP 10 热门话题</h2>
              <table width="100%" cellpadding="0" cellspacing="0" style="font-size: 14px;">
                ${hotspotsHTML}
              </table>
            </td>
          </tr>

          <!-- Footer -->
          <tr>
            <td style="padding: 24px 32px; background: #f8fafc; text-align: center; border-top: 1px solid #e5e7eb;">
              <p style="color: #6b7280; font-size: 13px; margin: 0;">
                由 AI 热点雷达自动生成<br>
                <a href="http://localhost:3000" style="color: #0ea5e9; text-decoration: none;">查看完整数据 →</a>
              </p>
            </td>
          </tr>
        </table>
      </td>
    </tr>
  </table>
</body>
</html>
    `;
  }

  // 获取分数颜色
  getScoreColor(score) {
    if (score >= 80) return '#ff4757';
    if (score >= 60) return '#ffa502';
    if (score >= 40) return '#2ed573';
    return '#70a1ff';
  }

  // 生成纯文本版本
  generateDailyDigestText(hotspots, stats) {
    const date = new Date().toLocaleDateString('zh-CN');
    const topHotspots = hotspots
      .sort((a, b) => (b.avg_score || 0) - (a.avg_score || 0))
      .slice(0, 10);

    let text = `🔥 AI 热点雷达 - ${date}\n\n`;
    text += `📊 今日统计\n`;
    text += `- 总热点: ${stats.total}\n`;
    text += `- 平均分: ${stats.avgScore}\n`;
    text += `- 高分热点: ${stats.highScore}\n`;
    text += `- 平台数: ${stats.platforms}\n\n`;
    text += `🏆 TOP 10 热门话题\n\n`;

    topHotspots.forEach((h, i) => {
      text += `${i + 1}. [${h.avg_score || 0}] ${h.title || 'Untitled'}\n`;
      if (h.title_zh) text += `   ${h.title_zh}\n`;
      text += `   平台: ${h.platform}\n\n`;
    });

    text += `查看完整数据: http://localhost:3000`;
    return text;
  }

  // 发送每日摘要
  async sendDailyDigest(to, hotspots, stats) {
    const subject = `🔥 AI 热点日报 - ${new Date().toLocaleDateString('zh-CN')}`;
    const html = this.generateDailyDigestHTML(hotspots, stats);
    const text = this.generateDailyDigestText(hotspots, stats);

    return this.sendEmail({ to, subject, html, text });
  }
}

module.exports = EmailService;
