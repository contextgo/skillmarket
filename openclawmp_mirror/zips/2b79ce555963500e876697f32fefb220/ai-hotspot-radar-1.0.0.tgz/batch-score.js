const Storage = require('./storage');
const { Scorer } = require('./scorers');

async function batchScoreAll() {
  const storage = new Storage();
  const scorer = new Scorer(storage);
  
  // 获取所有没有评分的热点
  const hotspots = storage.db.prepare(`
    SELECT h.* FROM hotspots h
    WHERE NOT EXISTS (SELECT 1 FROM scores s WHERE s.hotspot_id = h.id)
    ORDER BY h.crawled_at DESC
  `).all();
  
  console.log(`[BatchScore] Found ${hotspots.length} hotspots without scores`);
  
  if (hotspots.length === 0) {
    console.log('[BatchScore] No hotspots to score');
    return;
  }
  
  // 解析 metrics
  hotspots.forEach(h => {
    try {
      h.metrics = JSON.parse(h.metrics || '{}');
    } catch (e) {
      h.metrics = {};
    }
  });
  
  // 批量评分
  const scores = await scorer.batchScore(hotspots);
  
  console.log(`[BatchScore] Scored ${scores.length} hotspots`);
  
  // 统计
  const avgScore = scores.reduce((sum, s) => sum + s.score, 0) / scores.length;
  console.log(`[BatchScore] Average score: ${avgScore.toFixed(2)}`);
  
  // 显示前10个
  console.log('\n[BatchScore] Top 10 scores:');
  scores
    .sort((a, b) => b.score - a.score)
    .slice(0, 10)
    .forEach(s => {
      const h = hotspots.find(h => h.id === s.hotspot_id);
      console.log(`  ${s.score} - ${h?.platform} - ${h?.title?.substring(0, 50)}...`);
    });
}

batchScoreAll().catch(console.error);
