/**
 * Performance Optimization Configuration
 * 性能优化配置
 */

module.exports = {
  // ========== 数据库优化配置 ==========
  database: {
    // WAL 模式配置
    wal: {
      enabled: true,
      synchronous: 'NORMAL',      // NORMAL 模式平衡性能和数据安全
      cacheSize: -20000,          // 约20MB缓存（负值表示页数）
      mmapSize: 268435456,        // 256MB内存映射
      tempStore: 'MEMORY'         // 临时表存储在内存
    },
    
    // 连接池配置
    pool: {
      enabled: false,             // 默认关闭，需要时开启
      maxReadConnections: 3,      // 最大读连接数
      maxWriteConnections: 1,     // 最大写连接数（SQLite限制为1）
      acquireTimeout: 5000,       // 获取连接超时（毫秒）
      idleTimeout: 300000         // 空闲超时（5分钟）
    },
    
    // 索引配置
    indexes: [
      // 基础索引
      { name: 'idx_platform', table: 'hotspots', columns: ['platform'] },
      { name: 'idx_crawled', table: 'hotspots', columns: ['crawled_at'] },
      { name: 'idx_author', table: 'hotspots', columns: ['author_id'] },
      
      // 复合索引 - 平台+时间（用于按平台筛选并按时间排序）
      { 
        name: 'idx_platform_published', 
        table: 'hotspots', 
        columns: ['platform', 'published_at DESC'] 
      },
      
      // 复合索引 - 评分+时间（用于热度排序）
      { 
        name: 'idx_score_updated', 
        table: 'hotspots', 
        columns: ['avg_score DESC', 'crawled_at DESC'],
        where: 'avg_score > 0'
      }
    ]
  },

  // ========== 熔断器配置 ==========
  circuitBreaker: {
    // Twitter API 熔断器
    twitter: {
      failureThreshold: 5,        // 5次错误触发熔断
      successThreshold: 2,        // 连续2次成功恢复
      timeout: 300000,            // 冷却时间：5分钟（毫秒）
      monitorInterval: 60000      // 监控窗口：1分钟
    },
    
    // 默认熔断器配置
    default: {
      failureThreshold: 5,
      successThreshold: 2,
      timeout: 300000,
      monitorInterval: 60000
    }
  },

  // ========== 重试配置 ==========
  retry: {
    // 默认重试配置
    default: {
      maxRetries: 3,              // 最大重试次数
      baseDelay: 1000,            // 基础延迟：1秒
      maxDelay: 60000,            // 最大延迟：60秒
      factor: 2,                  // 指数因子
      jitter: true                // 添加抖动
    },
    
    // Twitter API 重试配置
    twitter: {
      maxRetries: 3,
      baseDelay: 1000,
      maxDelay: 30000,            // Twitter API 最大延迟30秒
      factor: 2,
      jitter: true,
      retryableCategories: [      // 可重试的错误类型
        'NETWORK',
        'TIMEOUT',
        'SERVER',
        'UNKNOWN'
      ]
    },
    
    // 限流错误特殊配置
    rateLimit: {
      maxRetries: 2,
      baseDelay: 60000,           // 限流等待至少60秒
      maxDelay: 300000,           // 最大5分钟
      factor: 1.5,
      jitter: true
    }
  },

  // ========== 健康监控配置 ==========
  healthMonitor: {
    enabled: true,
    checkInterval: 60000,         // 检查间隔：1分钟
    
    // 告警阈值
    alertThreshold: {
      errorRate: 0.1,             // 错误率超过10%告警
      responseTime: 5000,         // 响应时间超过5秒告警
      cpuUsage: 80,               // CPU使用率超过80%告警
      memoryUsage: 85             // 内存使用率超过85%告警
    }
  },

  // ========== API 超时配置 ==========
  timeouts: {
    twitter: {
      userLookup: 10000,          // 用户查询：10秒
      tweets: 10000,              // 获取推文：10秒
      search: 15000               // 搜索：15秒
    }
  }
};
