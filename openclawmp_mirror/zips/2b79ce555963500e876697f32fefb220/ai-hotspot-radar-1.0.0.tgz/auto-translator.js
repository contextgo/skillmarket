/**
 * 自动翻译服务 - 定期为无翻译的热点添加翻译
 */

const Translator = require('./translator');

class AutoTranslator {
  constructor(storage, options = {}) {
    this.storage = storage;
    this.translator = new Translator();
    this.batchSize = options.batchSize || 50; // 每次翻译数量（增加）
    this.intervalHours = options.intervalHours || 2; // 每2小时运行一次（加快）
    this.minLength = options.minLength || 10; // 最小内容长度
    this.delayMs = options.delayMs || 200; // 延迟 200ms（加快）
    this.isRunning = false;
  }

  // 启动自动翻译服务
  start() {
    console.log(`[AutoTranslator] 启动自动翻译服务，每 ${this.intervalHours} 小时运行一次`);
    this.run(); // 立即运行一次
    
    // 定期运行
    this.intervalId = setInterval(() => {
      this.run();
    }, this.intervalHours * 60 * 60 * 1000);
  }

  // 停止服务
  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
    this.isRunning = false;
    console.log('[AutoTranslator] 已停止');
  }

  // 运行批量翻译
  async run() {
    if (this.isRunning) {
      console.log('[AutoTranslator] 上一次任务仍在运行，跳过');
      return;
    }

    this.isRunning = true;
    console.log('[AutoTranslator] 开始批量翻译任务...');

    try {
      // 获取需要翻译的热点
      const hotspots = this.getHotspotsNeedTranslation();
      
      if (hotspots.length === 0) {
        console.log('[AutoTranslator] 没有需要翻译的热点');
        this.isRunning = false;
        return;
      }

      console.log(`[AutoTranslator] 找到 ${hotspots.length} 条需要翻译的热点`);

      let successCount = 0;
      let failCount = 0;

      // 使用并行翻译（每次 5 条）
      const concurrency = 5;
      for (let i = 0; i < hotspots.length; i += concurrency) {
        const batch = hotspots.slice(i, i + concurrency);
        const batchNum = Math.floor(i / concurrency) + 1;
        const totalBatches = Math.ceil(hotspots.length / concurrency);
        
        console.log(`[AutoTranslator] 批次 ${batchNum}/${totalBatches} (${batch.length} 条)`);

        // 并行翻译
        const promises = batch.map(async (h, idx) => {
          console.log(`[AutoTranslator] [${i + idx + 1}/${hotspots.length}] ${h.platform}: ${h.title.substring(0, 40)}...`);

          try {
            // 检测原文是否已经是中文（中文字符占比超过30%）
            const isChineseTitle = this.isChineseText(h.title);
            const isChineseContent = h.content && this.isChineseText(h.content);
            
            let titleZh = '';
            let contentZh = '';
            
            // 翻译标题（如果原文不是中文）
            if (!isChineseTitle) {
              titleZh = await this.translator.translateToChinese(h.title, 200);
            } else {
              // 原文是中文，title_zh 保持为空（使用 title 即可）
              titleZh = '';
              console.log(`[AutoTranslator] ℹ️ 标题已是中文，跳过翻译: ${h.title.substring(0, 30)}...`);
            }
            
            // 翻译内容（如果原文不是中文且足够长）
            if (!isChineseContent && h.content && h.content.length > this.minLength) {
              contentZh = await this.translator.translateToChinese(h.content, 500);
            }

            // 保存到数据库（只保存非空值）
            const updates = {};
            if (titleZh) updates.title_zh = titleZh;
            if (contentZh) updates.content_zh = contentZh;
            
            if (Object.keys(updates).length > 0) {
              this.storage.updateHotspot(h.id, updates);
              console.log(`[AutoTranslator] ✅ 翻译成功: ${titleZh?.substring(0, 30) || contentZh?.substring(0, 30) || '无翻译'}...`);
            } else {
              // 标记为已处理（设置空值避免重复处理）
              this.storage.updateHotspot(h.id, { title_zh: '', content_zh: '' });
              console.log(`[AutoTranslator] ℹ️ 中文内容，标记为已处理: ${h.title.substring(0, 30)}...`);
            }
            
            return { success: true };

          } catch (err) {
            console.error(`[AutoTranslator] ❌ 翻译失败: ${err.message}`);
            return { success: false };
          }
        });

        const results = await Promise.all(promises);
        successCount += results.filter(r => r.success).length;
        failCount += results.filter(r => !r.success).length;

        // 批次间延迟
        if (i + concurrency < hotspots.length) {
          await this.delay(this.delayMs * 2);
        }
      }

      console.log(`[AutoTranslator] 任务完成: ${successCount} 成功, ${failCount} 失败`);

    } catch (err) {
      console.error('[AutoTranslator] 任务出错:', err.message);
    } finally {
      this.isRunning = false;
    }
  }

  // 获取需要翻译的热点
  getHotspotsNeedTranslation() {
    return this.storage.db.prepare(`
      SELECT id, platform, title, content 
      FROM hotspots 
      WHERE (title_zh IS NULL OR title_zh = '') 
        AND title IS NOT NULL 
        AND title != ''
      ORDER BY crawled_at DESC
      LIMIT ?
    `).all(this.batchSize);
  }

  // 延迟函数
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  // 手动触发翻译（API 调用）
  async translateNow(limit = 10) {
    const originalBatchSize = this.batchSize;
    this.batchSize = limit;
    await this.run();
    this.batchSize = originalBatchSize;
  }

  // 检测文本是否主要是中文（中文字符占比超过30%）
  isChineseText(text) {
    if (!text || text.length === 0) return false;
    
    // 匹配中文字符（包括中文标点）
    const chineseRegex = /[\u4e00-\u9fa5\u3000-\u303f\uff00-\uffef]/g;
    const chineseChars = text.match(chineseRegex) || [];
    const chineseRatio = chineseChars.length / text.length;
    
    return chineseRatio > 0.3; // 中文字符占比超过30%认为是中文
  }
}

module.exports = AutoTranslator;
