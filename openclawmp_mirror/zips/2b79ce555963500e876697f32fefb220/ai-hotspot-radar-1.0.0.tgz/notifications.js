// 通知模块 - 管理热点推送和提醒
const axios = require('axios');

class NotificationManager {
  constructor(storage) {
    this.storage = storage;
  }

  // 检查是否需要发送通知
  async checkAndNotify(hotspot) {
    const settings = this.getSettings();
    
    // 检查分数阈值
    if (hotspot.score < settings.min_score_threshold) {
      return false;
    }

    // 检查是否已通知过
    const existing = this.storage.getNotificationByHotspotId(hotspot.id);
    if (existing) {
      return false;
    }

    // 创建通知
    const notification = {
      hotspot_id: hotspot.id,
      type: 'high_score',
      title: `🔥 High Score Alert: ${hotspot.title.substring(0, 50)}...`,
      message: `Score: ${hotspot.score} | Platform: ${hotspot.platform} | Author: ${hotspot.author}`
    };

    this.storage.saveNotification(notification);

    // 发送浏览器通知
    if (settings.enable_browser_notification) {
      this.sendBrowserNotification(notification, hotspot);
    }

    // 发送 Webhook
    if (settings.enable_webhook && settings.webhook_url) {
      this.sendWebhook(notification, hotspot, settings.webhook_url);
    }

    console.log(`[Notification] Sent for hotspot: ${hotspot.id} (Score: ${hotspot.score})`);
    return true;
  }

  // 获取通知设置
  getSettings() {
    return this.storage.getNotificationSettings() || {
      min_score_threshold: 80,
      enable_browser_notification: true,
      enable_webhook: false,
      webhook_url: '',
      daily_digest: true
    };
  }

  // 更新设置
  updateSettings(settings) {
    return this.storage.updateNotificationSettings(settings);
  }

  // 发送浏览器通知（通过 SSE 推送到前端）
  sendBrowserNotification(notification, hotspot) {
    // 存储到待推送队列，前端通过 SSE 获取
    this.storage.addPendingNotification({
      ...notification,
      hotspot_url: hotspot.url,
      hotspot_score: hotspot.score,
      hotspot_platform: hotspot.platform
    });
  }

  // 发送 Webhook
  async sendWebhook(notification, hotspot, webhookUrl) {
    try {
      await axios.post(webhookUrl, {
        type: 'hotspot_alert',
        data: {
          id: hotspot.id,
          title: hotspot.title,
          url: hotspot.url,
          score: hotspot.score,
          platform: hotspot.platform,
          author: hotspot.author,
          published_at: hotspot.published_at
        },
        notification: {
          title: notification.title,
          message: notification.message,
          created_at: new Date().toISOString()
        }
      }, {
        timeout: 10000,
        headers: { 'Content-Type': 'application/json' }
      });
      console.log(`[Webhook] Sent to ${webhookUrl}`);
    } catch (err) {
      console.error(`[Webhook] Failed to send:`, err.message);
    }
  }

  // 获取未读通知
  getUnreadNotifications(limit = 20) {
    return this.storage.getUnreadNotifications(limit);
  }

  // 标记通知为已读
  markAsRead(notificationId) {
    return this.storage.markNotificationAsRead(notificationId);
  }

  // 生成每日摘要
  async generateDailyDigest() {
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    
    const hotspots = this.storage.getHotspots({
      since: yesterday.toISOString(),
      limit: 50,
      sortBy: 'avg_score',
      sortOrder: 'DESC'
    });

    const topHotspots = hotspots.filter(h => h.avg_score >= 70).slice(0, 10);
    
    if (topHotspots.length === 0) {
      return null;
    }

    return {
      date: new Date().toISOString(),
      total: hotspots.length,
      top_count: topHotspots.length,
      top_hotspots: topHotspots.map(h => ({
        title: h.title,
        score: h.avg_score,
        platform: h.platform,
        url: h.url
      }))
    };
  }
}

module.exports = NotificationManager;
