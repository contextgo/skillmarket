/**
 * 收藏管理模块 (服务器同步版)
 */

class FavoritesManager {
  constructor() {
    this.storageKey = 'hotspot_favorites';
    this.favorites = [];
    this.userId = 'anonymous'; // 可扩展为用户系统
    this.init();
  }

  // 初始化：从服务器加载收藏
  async init() {
    await this.loadFromServer();
    // 同时保留 localStorage 作为离线缓存
    const localData = this.loadFromLocal();
    if (this.favorites.length === 0 && localData.length > 0) {
      // 如果服务器没有数据，但有本地数据，同步到服务器
      console.log('[Favorites] Syncing local data to server...');
      for (const item of localData) {
        await this.syncToServer(item.id, true);
      }
    }
  }

  // 从 localStorage 加载（离线缓存）
  loadFromLocal() {
    try {
      const data = localStorage.getItem(this.storageKey);
      return data ? JSON.parse(data) : [];
    } catch (err) {
      console.error('[Favorites] Failed to load from local:', err);
      return [];
    }
  }

  // 保存到 localStorage（离线缓存）
  saveToLocal() {
    try {
      localStorage.setItem(this.storageKey, JSON.stringify(this.favorites));
    } catch (err) {
      console.error('[Favorites] Failed to save to local:', err);
    }
  }

  // 从服务器加载收藏
  async loadFromServer() {
    try {
      const response = await fetch(`/api/favorites?user_id=${this.userId}`);
      if (response.ok) {
        const data = await response.json();
        this.favorites = data.map(f => ({
          id: f.hotspot_id,
          platform: f.platform,
          title: f.title,
          title_zh: f.title_zh,
          url: f.url,
          author: f.author,
          avg_score: f.avg_score,
          favorited_at: f.favorited_at
        }));
        this.saveToLocal();
        console.log('[Favorites] Loaded from server:', this.favorites.length);
      }
    } catch (err) {
      console.error('[Favorites] Failed to load from server:', err);
      // 从本地加载作为回退
      this.favorites = this.loadFromLocal();
    }
  }

  // 同步到服务器
  async syncToServer(hotspotId, isAdd) {
    try {
      if (isAdd) {
        await fetch('/api/favorites', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ hotspot_id: hotspotId, user_id: this.userId })
        });
      } else {
        await fetch(`/api/favorites/${encodeURIComponent(hotspotId)}?user_id=${this.userId}`, {
          method: 'DELETE'
        });
      }
      return true;
    } catch (err) {
      console.error('[Favorites] Failed to sync to server:', err);
      return false;
    }
  }

  // 添加收藏
  async add(hotspot) {
    if (!hotspot || !hotspot.id) return false;
    
    // 检查是否已存在
    if (this.isFavorited(hotspot.id)) {
      return false;
    }
    
    const favorite = {
      id: hotspot.id,
      platform: hotspot.platform,
      title: hotspot.title,
      title_zh: hotspot.title_zh,
      url: hotspot.url,
      author: hotspot.author,
      avg_score: hotspot.avg_score,
      tags: hotspot.tags,
      llm_models: hotspot.llm_models,
      summary: hotspot.summary,
      favorited_at: new Date().toISOString()
    };
    
    this.favorites.unshift(favorite);
    this.saveToLocal();
    
    // 同步到服务器
    await this.syncToServer(hotspot.id, true);
    
    console.log('[Favorites] Added:', hotspot.id);
    return true;
  }

  // 移除收藏
  async remove(hotspotId) {
    const index = this.favorites.findIndex(f => f.id === hotspotId);
    if (index === -1) return false;
    
    this.favorites.splice(index, 1);
    this.saveToLocal();
    
    // 同步到服务器
    await this.syncToServer(hotspotId, false);
    
    console.log('[Favorites] Removed:', hotspotId);
    return true;
  }

  // 切换收藏状态
  async toggle(hotspot) {
    if (this.isFavorited(hotspot.id)) {
      await this.remove(hotspot.id);
      return false; // 返回 false 表示已取消收藏
    } else {
      await this.add(hotspot);
      return true; // 返回 true 表示已收藏
    }
  }

  // 检查是否已收藏
  isFavorited(hotspotId) {
    return this.favorites.some(f => f.id === hotspotId);
  }

  // 获取所有收藏
  getAll() {
    return this.favorites;
  }

  // 获取收藏数量
  getCount() {
    return this.favorites.length;
  }

  // 导出为 Markdown
  exportToMarkdown() {
    const date = new Date().toLocaleDateString('zh-CN');
    let md = `# AI 热点收藏 - ${date}\n\n`;
    md += `共 ${this.favorites.length} 条收藏\n\n`;
    
    this.favorites.forEach((f, i) => {
      md += `## ${i + 1}. ${f.title}\n\n`;
      if (f.title_zh) md += `**中文**: ${f.title_zh}\n\n`;
      md += `- **平台**: ${f.platform}\n`;
      md += `- **评分**: ${f.avg_score || 'N/A'}\n`;
      md += `- **作者**: ${f.author || 'Unknown'}\n`;
      md += `- **链接**: ${f.url}\n`;
      if (f.summary) md += `- **摘要**: ${f.summary}\n`;
      if (f.llm_models && f.llm_models.length > 0) {
        md += `- **相关模型**: ${f.llm_models.join(', ')}\n`;
      }
      md += `- **收藏时间**: ${new Date(f.favorited_at).toLocaleString('zh-CN')}\n\n`;
      md += `---\n\n`;
    });
    
    return md;
  }

  // 导出为 JSON
  exportToJSON() {
    return JSON.stringify(this.favorites, null, 2);
  }

  // 下载文件
  downloadFile(content, filename, type) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

  // 导出收藏
  export(format = 'markdown') {
    const date = new Date().toISOString().split('T')[0];
    
    if (format === 'markdown') {
      const content = this.exportToMarkdown();
      this.downloadFile(content, `hotspot-favorites-${date}.md`, 'text/markdown');
    } else if (format === 'json') {
      const content = this.exportToJSON();
      this.downloadFile(content, `hotspot-favorites-${date}.json`, 'application/json');
    }
  }

  // 清空收藏
  clear() {
    this.favorites = [];
    this.saveFavorites();
    console.log('[Favorites] Cleared all');
  }

  // 搜索收藏
  search(query) {
    const lowerQuery = query.toLowerCase();
    return this.favorites.filter(f => 
      (f.title && f.title.toLowerCase().includes(lowerQuery)) ||
      (f.title_zh && f.title_zh.toLowerCase().includes(lowerQuery)) ||
      (f.platform && f.platform.toLowerCase().includes(lowerQuery)) ||
      (f.author && f.author.toLowerCase().includes(lowerQuery))
    );
  }
}

// 全局实例
const favoritesManager = new FavoritesManager();
