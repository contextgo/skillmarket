/**
 * 内容分析器 - 提取标签、摘要、识别LLM
 */

const LLM_MODELS = {
  // OpenAI
  'gpt-4': { name: 'GPT-4', company: 'OpenAI', color: '#10a37f' },
  'gpt-4o': { name: 'GPT-4o', company: 'OpenAI', color: '#10a37f' },
  'gpt-4o-mini': { name: 'GPT-4o Mini', company: 'OpenAI', color: '#10a37f' },
  'gpt-3.5': { name: 'GPT-3.5', company: 'OpenAI', color: '#10a37f' },
  'o1': { name: 'o1', company: 'OpenAI', color: '#10a37f' },
  'o3': { name: 'o3', company: 'OpenAI', color: '#10a37f' },
  'o4-mini': { name: 'o4-mini', company: 'OpenAI', color: '#10a37f' },
  'chatgpt': { name: 'ChatGPT', company: 'OpenAI', color: '#10a37f' },
  
  // Anthropic
  'claude': { name: 'Claude', company: 'Anthropic', color: '#d4a574' },
  'claude-3': { name: 'Claude 3', company: 'Anthropic', color: '#d4a574' },
  'claude-3.5': { name: 'Claude 3.5', company: 'Anthropic', color: '#d4a574' },
  'claude-3.7': { name: 'Claude 3.7', company: 'Anthropic', color: '#d4a574' },
  'claude-opus': { name: 'Claude Opus', company: 'Anthropic', color: '#d4a574' },
  'claude-sonnet': { name: 'Claude Sonnet', company: 'Anthropic', color: '#d4a574' },
  'claude-haiku': { name: 'Claude Haiku', company: 'Anthropic', color: '#d4a574' },
  
  // Google
  'gemini': { name: 'Gemini', company: 'Google', color: '#4285f4' },
  'gemini-1.5': { name: 'Gemini 1.5', company: 'Google', color: '#4285f4' },
  'gemini-2.0': { name: 'Gemini 2.0', company: 'Google', color: '#4285f4' },
  'gemini-pro': { name: 'Gemini Pro', company: 'Google', color: '#4285f4' },
  'gemini-ultra': { name: 'Gemini Ultra', company: 'Google', color: '#4285f4' },
  'gemma': { name: 'Gemma', company: 'Google', color: '#4285f4' },
  
  // Meta
  'llama': { name: 'LLaMA', company: 'Meta', color: '#0668e1' },
  'llama-2': { name: 'LLaMA 2', company: 'Meta', color: '#0668e1' },
  'llama-3': { name: 'LLaMA 3', company: 'Meta', color: '#0668e1' },
  'llama-3.1': { name: 'LLaMA 3.1', company: 'Meta', color: '#0668e1' },
  'llama-3.2': { name: 'LLaMA 3.2', company: 'Meta', color: '#0668e1' },
  'llama-3.3': { name: 'LLaMA 3.3', company: 'Meta', color: '#0668e1' },
  'llama-4': { name: 'LLaMA 4', company: 'Meta', color: '#0668e1' },
  
  // 国内模型
  'deepseek': { name: 'DeepSeek', company: 'DeepSeek', color: '#4d6bfa' },
  'deepseek-r1': { name: 'DeepSeek-R1', company: 'DeepSeek', color: '#4d6bfa' },
  'deepseek-v3': { name: 'DeepSeek-V3', company: 'DeepSeek', color: '#4d6bfa' },
  'qwen': { name: 'Qwen', company: 'Alibaba', color: '#ff6a00' },
  'qwen-2': { name: 'Qwen 2', company: 'Alibaba', color: '#ff6a00' },
  'qwen-2.5': { name: 'Qwen 2.5', company: 'Alibaba', color: '#ff6a00' },
  'qwen-max': { name: 'Qwen Max', company: 'Alibaba', color: '#ff6a00' },
  'yi': { name: 'Yi', company: '01.AI', color: '#00b4ff' },
  'yi-large': { name: 'Yi Large', company: '01.AI', color: '#00b4ff' },
  'baichuan': { name: 'Baichuan', company: 'Baichuan', color: '#2e7d32' },
  'chatglm': { name: 'ChatGLM', company: 'Zhipu', color: '#1a73e8' },
  'glm-4': { name: 'GLM-4', company: 'Zhipu', color: '#1a73e8' },
  'kimi': { name: 'Kimi', company: 'Moonshot', color: '#00d4aa' },
  'kimi-k1.5': { name: 'Kimi K1.5', company: 'Moonshot', color: '#00d4aa' },
  'hunyuan': { name: 'Hunyuan', company: 'Tencent', color: '#0052d9' },
  'ernie': { name: 'Ernie', company: 'Baidu', color: '#2932e1' },
  'wenxin': { name: 'Wenxin', company: 'Baidu', color: '#2932e1' },
  'doubao': { name: 'Doubao', company: 'ByteDance', color: '#00d4aa' },
  
  // 其他
  'mistral': { name: 'Mistral', company: 'Mistral', color: '#ff6b35' },
  'mixtral': { name: 'Mixtral', company: 'Mistral', color: '#ff6b35' },
  'codex': { name: 'Codex', company: 'OpenAI', color: '#10a37f' },
  'opus': { name: 'Opus', company: 'Anthropic', color: '#d4a574' },
  'sonnet': { name: 'Sonnet', company: 'Anthropic', color: '#d4a574' },
  'haiku': { name: 'Haiku', company: 'Anthropic', color: '#d4a574' },
};

const AI_KEYWORDS = [
  'AI', 'artificial intelligence', 'machine learning', 'deep learning',
  'neural network', 'transformer', 'LLM', 'large language model',
  'agent', 'RAG', 'fine-tuning', 'prompt', 'token',
  'embedding', 'vector', 'diffusion', 'multimodal'
];

const TOPIC_KEYWORDS = {
  'coding': ['code', 'coding', 'programming', 'developer', 'github', 'repository'],
  'image': ['image', 'image generation', 'stable diffusion', 'dall-e', 'midjourney'],
  'video': ['video', 'sora', 'video generation', 'animation'],
  'audio': ['audio', 'voice', 'speech', 'music', 'tts'],
  'research': ['research', 'paper', 'benchmark', 'evaluation', 'dataset'],
  'product': ['product', 'launch', 'release', 'update', 'feature'],
  'business': ['business', 'startup', 'funding', 'investment', 'revenue'],
  'safety': ['safety', 'alignment', 'rlhf', 'constitutional ai', 'guardrails']
};

class ContentAnalyzer {
  constructor() {
    this.llmModels = LLM_MODELS;
    this.aiKeywords = AI_KEYWORDS;
    this.topicKeywords = TOPIC_KEYWORDS;
  }

  // 分析内容
  analyze(text, title = '') {
    const content = (title + ' ' + text).toLowerCase();
    
    return {
      llmModels: this.detectLLMs(content),
      tags: this.extractTags(content),
      summary: this.generateSummary(text),
      category: this.categorize(content)
    };
  }

  // 检测涉及的LLM
  detectLLMs(content) {
    const detected = [];
    
    for (const [key, model] of Object.entries(this.llmModels)) {
      // 检查各种变体
      const patterns = [
        key.toLowerCase(),
        model.name.toLowerCase(),
        model.name.toLowerCase().replace(/[-\s]/g, ''),
        model.name.toLowerCase().replace(/[-\s]/g, '-')
      ];
      
      if (patterns.some(pattern => content.includes(pattern))) {
        if (!detected.find(d => d.name === model.name)) {
          detected.push(model);
        }
      }
    }
    
    return detected.slice(0, 3); // 最多返回3个
  }

  // 提取标签
  extractTags(content) {
    const tags = [];
    
    // AI关键词标签
    for (const keyword of this.aiKeywords) {
      if (content.includes(keyword.toLowerCase())) {
        tags.push(keyword);
      }
    }
    
    // 主题分类标签
    for (const [category, keywords] of Object.entries(this.topicKeywords)) {
      if (keywords.some(kw => content.includes(kw.toLowerCase()))) {
        tags.push(category);
      }
    }
    
    return [...new Set(tags)].slice(0, 5); // 去重，最多5个
  }

  // 生成摘要
  generateSummary(text) {
    if (!text) return '';
    
    // 清理文本
    let summary = text
      .replace(/\s+/g, ' ')
      .replace(/https?:\/\/\S+/g, '')
      .trim();
    
    // 截取前150字符
    if (summary.length > 150) {
      summary = summary.substring(0, 150) + '...';
    }
    
    return summary;
  }

  // 内容分类
  categorize(content) {
    for (const [category, keywords] of Object.entries(this.topicKeywords)) {
      if (keywords.some(kw => content.includes(kw.toLowerCase()))) {
        return category;
      }
    }
    return 'general';
  }
}

// 导出
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { ContentAnalyzer, LLM_MODELS };
}
