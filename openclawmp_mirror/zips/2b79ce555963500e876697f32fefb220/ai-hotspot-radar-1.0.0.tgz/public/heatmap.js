/**
 * 热力图模块 - 展示平台热度分布
 */

class HeatmapManager {
  constructor() {
    this.container = null;
    this.data = [];
  }

  // 显示热力图
  show(hotspots) {
    this.data = hotspots;
    this.createModal();
    this.render();
  }

  // 创建模态框
  createModal() {
    // 移除已存在的模态框
    const existing = document.querySelector('.heatmap-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.className = 'heatmap-modal';
    modal.innerHTML = `
      <div class="heatmap-overlay" onclick="heatmapManager.close()"></div>
      <div class="heatmap-content">
        <div class="heatmap-header">
          <h2>🔥 平台热力图</h2>
          <button class="heatmap-close" onclick="heatmapManager.close()">✕</button>
        </div>
        <div class="heatmap-body">
          <div class="heatmap-grid"></div>
          <div class="heatmap-legend">
            <span class="legend-item"><span class="legend-color" style="background: #ff4757"></span> 高热 (≥80)</span>
            <span class="legend-item"><span class="legend-color" style="background: #ffa502"></span> 中热 (60-79)</span>
            <span class="legend-item"><span class="legend-color" style="background: #2ed573"></span> 低热 (40-59)</span>
            <span class="legend-item"><span class="legend-color" style="background: #70a1ff"></span> 冷点 (<40)</span>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    this.container = modal.querySelector('.heatmap-grid');

    // 添加动画
    setTimeout(() => {
      modal.classList.add('active');
    }, 10);
  }

  // 渲染热力图
  render() {
    if (!this.container) return;

    // 按平台分组统计
    const platformStats = {};
    this.data.forEach(h => {
      const platform = h.platform;
      if (!platformStats[platform]) {
        platformStats[platform] = {
          count: 0,
          totalScore: 0,
          highScore: 0
        };
      }
      platformStats[platform].count++;
      platformStats[platform].totalScore += h.avg_score || 50;
      if (h.avg_score >= 80) platformStats[platform].highScore++;
    });

    // 计算平均热度
    const platforms = Object.entries(platformStats).map(([name, stats]) => ({
      name,
      count: stats.count,
      avgScore: Math.round(stats.totalScore / stats.count),
      highScore: stats.highScore
    })).sort((a, b) => b.avgScore - a.avgScore);

    // 渲染网格
    this.container.innerHTML = platforms.map(p => {
      const heat = p.avgScore >= 80 ? 'high' : p.avgScore >= 60 ? 'medium' : p.avgScore >= 40 ? 'low' : 'cold';
      const size = Math.min(100, 20 + p.count * 3);
      
      return `
        <div class="heatmap-cell" data-heat="${heat}" style="--size: ${size}px">
          <div class="cell-name">${p.name.toUpperCase()}</div>
          <div class="cell-score">${p.avgScore}</div>
          <div class="cell-count">${p.count} 热点</div>
          ${p.highScore > 0 ? `<div class="cell-badge">${p.highScore} 🔥</div>` : ''}
        </div>
      `;
    }).join('');
  }

  // 关闭模态框
  close() {
    const modal = document.querySelector('.heatmap-modal');
    if (modal) {
      modal.classList.remove('active');
      setTimeout(() => modal.remove(), 300);
    }
  }
}

// 全局实例
const heatmapManager = new HeatmapManager();
