/**
 * AI Hotspot Radar - Dynamic Frontend
 * Auto-refresh data from API
 */

// API Base URL
const API_BASE = '';

// 检测文本是否主要是中文
function isChineseText(text) {
  if (!text || text.length === 0) return false;
  const chineseRegex = /[\u4e00-\u9fa5\u3000-\u303f\uff00-\uffef]/g;
  const chineseChars = text.match(chineseRegex) || [];
  return chineseChars.length / text.length > 0.3;
}

// State
let currentPlatform = 'all';
let hotspots = [];
let filteredHotspots = [];
let platforms = [];
let stats = {};
let searchQuery = '';

// Register Service Worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js')
      .then((registration) => {
        console.log('[PWA] Service Worker registered:', registration.scope);
      })
      .catch((err) => {
        console.log('[PWA] Service Worker registration failed:', err);
      });
  });
}

// Initialize
async function init() {
  console.log('🚀 AI Hotspot Radar initializing...');
  
  // Load initial data
  await Promise.all([
    loadStats(),
    loadPlatforms(),
    loadHotspots()
  ]);
  
  // Setup event listeners
  setupEventListeners();
  setupSearchAndFilterListeners();
  
  // Auto-refresh every 30 seconds
  setInterval(() => {
    loadHotspots();
    loadStats();
  }, 30000);
  
  console.log('✅ Initialization complete');
}

// Setup search and filter listeners
function setupSearchAndFilterListeners() {
  // Search event
  window.addEventListener('search', (e) => {
    searchQuery = e.detail.query.toLowerCase().trim();
    applyFilters();
  });
  
  // Platform filter event
  window.addEventListener('platformFilter', (e) => {
    currentPlatform = e.detail.platform;
    loadHotspots();
    updatePlatformList();
    // Update filter dropdown
    if (typeof updatePlatformFilter === 'function') {
      updatePlatformFilter(platforms, currentPlatform);
    }
  });
}

// Apply search and platform filters
function applyFilters() {
  if (!searchQuery) {
    filteredHotspots = hotspots;
  } else {
    filteredHotspots = hotspots.filter(h => {
      const title = (h.title || '').toLowerCase();
      const titleZh = (h.title_zh || '').toLowerCase();
      const content = (h.content || '').toLowerCase();
      const contentZh = (h.content_zh || '').toLowerCase();
      const platform = (h.platform || '').toLowerCase();
      const author = (h.author || '').toLowerCase();
      
      return title.includes(searchQuery) ||
             titleZh.includes(searchQuery) ||
             content.includes(searchQuery) ||
             contentZh.includes(searchQuery) ||
             platform.includes(searchQuery) ||
             author.includes(searchQuery);
    });
  }
  
  updateHotspotsUI();
}

// Load stats
async function loadStats() {
  try {
    const response = await fetch(`${API_BASE}/api/stats`);
    stats = await response.json();
    updateStatsUI();
  } catch (err) {
    console.error('Failed to load stats:', err);
  }
}

// Load platforms
async function loadPlatforms() {
  try {
    // Get unique platforms from hotspots
    const response = await fetch(`${API_BASE}/api/hotspots?limit=1000`);
    const data = await response.json();
    
    // API returns array directly
    const hotspotsArray = Array.isArray(data) ? data : (data.hotspots || []);
    
    // Extract unique platforms
    const platformSet = new Set(hotspotsArray.map(h => h.platform) || []);
    platforms = ['all', ...Array.from(platformSet).sort()];
    
    updatePlatformList();
  } catch (err) {
    console.error('Failed to load platforms:', err);
    // Fallback platforms
    platforms = ['all', 'hackernews', 'producthunt', 'juejin', 'reddit', '36kr', 'jiqizhixin'];
    updatePlatformList();
  }
}

// Load hotspots
async function loadHotspots() {
  try {
    const url = currentPlatform === 'all' 
      ? `${API_BASE}/api/hotspots?limit=50`
      : `${API_BASE}/api/hotspots?platform=${currentPlatform}&limit=50`;
    
    const response = await fetch(url);
    const data = await response.json();
    // API returns array directly, not {hotspots: [...]}
    hotspots = Array.isArray(data) ? data : (data.hotspots || []);
    
    // Reset filtered hotspots when loading new data
    filteredHotspots = [];
    
    console.log(`Loaded ${hotspots.length} hotspots`);
    applyFilters();
  } catch (err) {
    console.error('Failed to load hotspots:', err);
    showError('Failed to load hotspots');
  }
}

// Update stats UI
function updateStatsUI() {
  const statCards = document.querySelectorAll('.stat-card');
  if (statCards.length < 4) return;
  
  const total = stats.totalHotspots || 0;
  const platformCount = stats.totalPlatforms || 0;
  const avgScore = Math.round(stats.avgScore || 0);
  
  statCards[0].querySelector('.stat-value').textContent = total;
  statCards[1].querySelector('.stat-value').textContent = platformCount.toString().padStart(2, '0');
  statCards[2].querySelector('.stat-value').textContent = avgScore;
  statCards[3].querySelector('.stat-value').textContent = new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }) + ' UTC';
}

// Update platform list
function updatePlatformList() {
  const platformList = document.querySelector('.platform-list');
  if (!platformList) return;
  
  const platformNames = {
    'all': '全部平台',
    'hackernews': 'Hacker News',
    'producthunt': 'Product Hunt',
    'juejin': '掘金',
    'reddit': 'Reddit',
    '36kr': '36氪',
    'jiqizhixin': '机器之心',
    'github': 'GitHub',
    'zhihu': '知乎',
    'weibo': '微博'
  };
  
  platformList.innerHTML = platforms.map(p => {
    const count = p === 'all' 
      ? (stats.totalHotspots || 0)
      : (stats.recentActivity?.find(a => a.platform === p)?.count || 0);
    const isActive = p === currentPlatform;
    
    return `
      <li class="platform-item ${isActive ? 'active' : ''}" data-platform="${p}">
        <span class="platform-dot"></span>
        <span class="platform-name">${platformNames[p] || p}</span>
        <span class="platform-count">${count}</span>
      </li>
    `;
  }).join('');
  
  // Re-attach click handlers
  document.querySelectorAll('.platform-item').forEach(item => {
    item.addEventListener('click', () => {
      currentPlatform = item.dataset.platform;
      loadHotspots();
      updatePlatformList();
      // Update filter dropdown
      if (typeof updatePlatformFilter === 'function') {
        updatePlatformFilter(platforms, currentPlatform);
      }
    });
  });
  
  // Update filter dropdown
  if (typeof updatePlatformFilter === 'function') {
    updatePlatformFilter(platforms, currentPlatform);
  }
}

// Update hotspots UI
function updateHotspotsUI() {
  const container = document.querySelector('.hotspot-list');
  if (!container) return;
  
  // Use filtered hotspots if available, otherwise use all hotspots
  const displayHotspots = filteredHotspots.length > 0 || searchQuery ? filteredHotspots : hotspots;
  
  if (displayHotspots.length === 0) {
    container.innerHTML = searchQuery ? 
      '<div class="empty-state">🔍 未找到匹配 "' + escapeHtml(searchQuery) + '" 的热点</div>' :
      '<div class="empty-state">No hotspots found</div>';
    return;
  }
  
  // 初始化内容分析器
  const analyzer = new ContentAnalyzer();
  
  // 计算24小时前的时间
  const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
  
  container.innerHTML = displayHotspots.map((h, index) => {
    const score = Math.round(h.avg_score || h.score || 50);
    const heat = score >= 80 ? 'fire' : score >= 60 ? 'hot' : score >= 40 ? 'warm' : 'cold';
    const rank = index + 1;
    
    const metrics = h.metrics ? JSON.parse(h.metrics) : {};
    
    // 判断是否是新热点（24小时内）
    const crawledAt = new Date(h.crawled_at);
    const isNew = crawledAt > oneDayAgo;
    
    // 判断是否是热热点（分数>=80）
    const isHot = score >= 80;
    
    // 生成标签HTML
    let tagsHtml = '';
    if (isNew) {
      tagsHtml += `<span class="tag-new">New</span>`;
    }
    if (isHot) {
      tagsHtml += `<span class="tag-hot">Hot</span>`;
    }
    
    // 分析内容
    const analysis = analyzer.analyze(h.content || '', h.title || '');
    
    // 生成LLM标签HTML
    let llmTagsHtml = '';
    if (analysis.llmModels.length > 0) {
      llmTagsHtml = `<div class="llm-tags">` + 
        analysis.llmModels.map(m => 
          `<span class="llm-tag" data-company="${m.company}" title="${m.company}">${m.name}</span>`
        ).join('') + 
        `</div>`;
    }
    
    // 生成主题标签HTML
    let topicTagsHtml = '';
    if (analysis.tags.length > 0) {
      topicTagsHtml = `<div class="topic-tags">` +
        analysis.tags.slice(0, 4).map(tag => 
          `<span class="topic-tag">${tag}</span>`
        ).join('') +
        `</div>`;
    }
    
    // 生成摘要HTML（优先使用中文翻译）
    let summaryHtml = '';
    const summaryText = h.content_zh || analysis.summary || '';
    if (summaryText && summaryText.length > 20) {
      summaryHtml = `<div class="card-summary">${escapeHtml(summaryText)}</div>`;
    }
    
    // 检查是否已收藏
    const isFavorited = favoritesManager.isFavorited(h.id);
    
    return `
      <div class="hotspot-card" data-heat="${heat}" data-id="${h.id}">
        <div class="card-left">
          <div class="score-ring" data-heat="${heat}">${score}</div>
          ${rank <= 3 ? `<span class="rank-badge">TOP ${rank}</span>` : ''}
        </div>
        <div class="card-content" onclick="window.open('${h.url}', '_blank')" style="cursor:pointer; flex:1;">
          <div class="card-platform">${h.platform.toUpperCase()} ${h.author ? '// ' + h.author.toUpperCase() : ''} ${tagsHtml}</div>
          <div class="card-title">${escapeHtml(h.title)}</div>
          ${h.title_zh && !isChineseText(h.title) ? `<div class="card-title-zh">${escapeHtml(h.title_zh)}</div>` : ''}
          ${llmTagsHtml}
          ${topicTagsHtml}
          ${summaryHtml}
        </div>
        <div class="card-right">
          <div class="card-actions">
            <button class="btn-favorite ${isFavorited ? 'active' : ''}" onclick="event.stopPropagation(); toggleFavorite('${h.id}')" title="${isFavorited ? '取消收藏' : '收藏'}">
              ${isFavorited ? '★' : '☆'}
            </button>
            <button class="btn-preference" onclick="event.stopPropagation(); showPreferenceModal('${h.id}')" title="喜好描述">
              💭
            </button>
            <button class="btn-translate ${h.title_zh ? 'translated' : ''}" onclick="event.stopPropagation(); translateHotspot('${h.id}')" title="${h.title_zh ? '已翻译' : '翻译'}">
              ${h.title_zh ? '✓中' : '中'}
            </button>
          </div>
          <div class="card-meta">
            <span>👤 ${h.author_id || h.author || 'Unknown'}</span>
            <span>🔥 ${metrics.likes || metrics.heat || metrics.points || metrics.upvotes || metrics.score || metrics.engagement || metrics.stars || metrics.todayStars || metrics.replies || 0}</span>
            <span>💬 ${metrics.comments || metrics.num_comments || 0}</span>
            <span>🕒 ${formatTime(h.crawled_at)}</span>
          </div>
        </div>
      </div>
    `;
  }).join('');
}

// Setup event listeners
function setupEventListeners() {
  // Crawl button
  const crawlBtn = document.querySelector('.btn-crawl');
  if (crawlBtn) {
    crawlBtn.addEventListener('click', startCrawl);
  }
  
  // 热力图按钮
  const heatmapBtn = document.querySelector('.btn-heatmap');
  if (heatmapBtn) {
    heatmapBtn.addEventListener('click', showHeatmap);
  }
  
  // 趋势分析按钮
  const trendBtn = document.querySelector('.btn-trend');
  if (trendBtn) {
    trendBtn.addEventListener('click', showTrendAnalysis);
  }
  
  // 通知按钮
  const notifBtn = document.querySelector('.btn-notifications');
  if (notifBtn) {
    notifBtn.addEventListener('click', showNotifications);
  }
  
  // 设置按钮
  const settingsBtn = document.querySelector('.btn-settings');
  if (settingsBtn) {
    settingsBtn.addEventListener('click', showSettings);
  }
}

// 显示热力图
function showHeatmap() {
  if (typeof heatmapManager !== 'undefined') {
    heatmapManager.show(hotspots);
  } else {
    showNotification('🔥 热力图加载中...');
  }
}

// 显示趋势分析
function showTrendAnalysis() {
  if (typeof trendsManager !== 'undefined') {
    trendsManager.show(hotspots);
  } else {
    showNotification('📊 趋势分析加载中...');
  }
}

// 显示通知
function showNotifications() {
  if (typeof notificationsManager !== 'undefined') {
    notificationsManager.show();
  } else {
    showNotification('🔔 通知中心加载中...');
  }
}

// 显示设置
function showSettings() {
  if (typeof settingsManager !== 'undefined') {
    settingsManager.show();
  } else {
    showNotification('⚙️ 设置面板加载中...');
  }
}

// 切换收藏
async function toggleFavorite(hotspotId) {
  const hotspot = hotspots.find(h => h.id === hotspotId);
  if (!hotspot) return;
  
  const isFavorited = await favoritesManager.toggle(hotspot);
  
  // 更新按钮状态
  const btn = document.querySelector(`.hotspot-card[data-id="${hotspotId}"] .btn-favorite`);
  if (btn) {
    btn.classList.toggle('active', isFavorited);
    btn.innerHTML = isFavorited ? '★' : '☆';
    btn.title = isFavorited ? '取消收藏' : '收藏';
  }
  
  showNotification(isFavorited ? '⭐ 已收藏' : '☆ 已取消收藏');
}

// 显示收藏列表
async function showFavorites() {
  if (typeof favoritesManager === 'undefined') {
    showNotification('❌ 收藏功能加载失败');
    return;
  }
  
  // 确保收藏数据已从服务器加载
  await favoritesManager.loadFromServer();
  const favorites = favoritesManager.getAll();
  
  // 创建模态框
  const modal = document.createElement('div');
  modal.className = 'favorites-modal';
  modal.innerHTML = `
    <div class="favorites-overlay" onclick="closeFavorites()"></div>
    <div class="favorites-content">
      <div class="favorites-header">
        <h2>⭐ 我的收藏 (${favorites.length})</h2>
        <div class="favorites-actions">
          <button class="btn-export-md" onclick="favoritesManager.export('markdown')">导出 Markdown</button>
          <button class="btn-export-json" onclick="favoritesManager.export('json')">导出 JSON</button>
          <button class="favorites-close" onclick="closeFavorites()">✕</button>
        </div>
      </div>
      <div class="favorites-body">
        ${favorites.length === 0 ? `
          <div class="favorites-empty">
            <div class="empty-icon">⭐</div>
            <div class="empty-text">暂无收藏</div>
            <div class="empty-hint">点击热点卡片上的 ☆ 即可收藏</div>
          </div>
        ` : `
          <div class="favorites-list">
            ${favorites.map(f => `
              <div class="favorite-item" data-id="${f.id}">
                <div class="favorite-score">${f.avg_score || 0}</div>
                <div class="favorite-content" onclick="window.open('${f.url}', '_blank')">
                  <div class="favorite-platform">${f.platform.toUpperCase()}</div>
                  <div class="favorite-title">${escapeHtml(f.title)}</div>
                  ${f.title_zh ? `<div class="favorite-title-zh">${escapeHtml(f.title_zh)}</div>` : ''}
                  <div class="favorite-meta">
                    <span>${f.author || 'Unknown'}</span>
                    <span>收藏于 ${new Date(f.favorited_at).toLocaleDateString('zh-CN')}</span>
                  </div>
                </div>
                <button class="btn-remove" onclick="event.stopPropagation(); removeFavorite('${f.id}')">✕</button>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  setTimeout(() => {
    modal.classList.add('active');
  }, 10);
}

// 关闭收藏列表
function closeFavorites() {
  const modal = document.querySelector('.favorites-modal');
  if (modal) {
    modal.classList.remove('active');
    setTimeout(() => modal.remove(), 300);
  }
}

// 移除收藏
async function removeFavorite(hotspotId) {
  await favoritesManager.remove(hotspotId);
  showFavorites(); // 刷新列表
  
  // 更新主列表中的按钮状态
  const btn = document.querySelector(`.hotspot-card[data-id="${hotspotId}"] .btn-favorite`);
  if (btn) {
    btn.classList.remove('active');
    btn.innerHTML = '☆';
    btn.title = '收藏';
  }
}

// Start crawl with progress
async function startCrawl() {
  const btn = document.querySelector('.btn-crawl');
  const progressModal = document.querySelector('.progress-modal');
  const progressFill = document.querySelector('.progress-modal-fill');
  const progressText = document.querySelector('.progress-modal-text');
  const progressPercent = document.querySelector('.progress-modal-percent');
  const progressPlatform = document.querySelector('.progress-modal-platform');
  
  // 显示进度浮窗
  if (progressModal) progressModal.style.display = 'flex';
  if (btn) {
    btn.disabled = true;
    btn.textContent = '⏳ 抓取中...';
  }
  
  // 模拟进度更新（实际应该从API获取进度）
  const platforms = ['GitHub', 'V2EX', 'Reddit', '36氪', '机器之心', '掘金', 'Product Hunt', 'Hacker News'];
  let current = 0;
  
  const updateProgress = () => {
    if (current < platforms.length) {
      const percent = Math.round((current / platforms.length) * 100);
      if (progressFill) progressFill.style.width = `${percent}%`;
      if (progressPercent) progressPercent.textContent = `${percent}%`;
      if (progressText) progressText.textContent = `正在抓取 ${platforms[current]}...`;
      if (progressPlatform) progressPlatform.textContent = `${current + 1}/${platforms.length} 平台`;
      current++;
      setTimeout(updateProgress, 800);
    }
  };
  
  updateProgress();
  
  try {
    const response = await fetch(`${API_BASE}/api/crawl`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ platforms: platforms.filter(p => p !== 'all') })
    });
    
    const result = await response.json();
    console.log('Crawl result:', result);
    
    // 完成进度
    if (progressFill) progressFill.style.width = '100%';
    if (progressPercent) progressPercent.textContent = '100%';
    if (progressText) progressText.textContent = '抓取完成！';
    if (progressPlatform) progressPlatform.textContent = `✅ 完成`;
    
    // Reload data
    await loadHotspots();
    await loadStats();
    
    // 延迟隐藏进度浮窗，显示完成浮窗
    setTimeout(() => {
      if (progressModal) progressModal.style.display = 'none';
      showCrawlCompleteModal(result);
    }, 800);
    
  } catch (err) {
    console.error('Crawl failed:', err);
    if (progressText) progressText.textContent = '抓取失败';
    if (progressPercent) progressPercent.textContent = '❌';
    showError('抓取失败: ' + err.message);
    setTimeout(() => {
      if (progressModal) progressModal.style.display = 'none';
    }, 1500);
  } finally {
    if (btn) {
      btn.disabled = false;
      btn.textContent = '▶ 立即抓取';
    }
  }
}

// Utility: Escape HTML
function escapeHtml(text) {
  if (!text) return '';
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

// Utility: Format time
function formatTime(timestamp) {
  if (!timestamp) return 'Unknown';
  const date = new Date(timestamp);
  const now = new Date();
  const diff = (now - date) / 1000; // seconds
  
  if (diff < 60) return 'Just now';
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`;
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`;
  return `${Math.floor(diff / 86400)}d ago`;
}

// Utility: Show notification
function showNotification(message) {
  const notif = document.createElement('div');
  notif.className = 'notification';
  notif.textContent = message;
  document.body.appendChild(notif);
  
  setTimeout(() => {
    notif.remove();
  }, 3000);
}

// Utility: Show error
function showError(message) {
  console.error(message);
  showNotification('❌ ' + message);
}

// 显示抓取完成浮窗
function showCrawlCompleteModal(result) {
  // 移除已存在的浮窗
  const existing = document.querySelector('.crawl-complete-modal');
  if (existing) existing.remove();
  
  const modal = document.createElement('div');
  modal.className = 'crawl-complete-modal';
  modal.innerHTML = `
    <div class="crawl-complete-content">
      <div class="crawl-complete-icon">✅</div>
      <div class="crawl-complete-title">抓取完成！</div>
      <div class="crawl-complete-stats">
        <div class="crawl-stat">
          <span class="crawl-stat-number">${result.total || 0}</span>
          <span class="crawl-stat-label">新增热点</span>
        </div>
        ${result.details ? `
        <div class="crawl-stat">
          <span class="crawl-stat-number">${Object.keys(result.details).length}</span>
          <span class="crawl-stat-label">平台</span>
        </div>
        ` : ''}
      </div>
      <button class="crawl-complete-close" onclick="this.closest('.crawl-complete-modal').remove()">知道了</button>
    </div>
  `;
  
  // 点击背景关闭
  modal.addEventListener('click', (e) => {
    if (e.target === modal) modal.remove();
  });
  
  document.body.appendChild(modal);
  
  // 自动关闭（5秒后）
  const autoCloseTimer = setTimeout(() => {
    if (modal.parentNode) modal.remove();
  }, 5000);
  
  // 如果用户手动关闭，清除定时器
  modal.querySelector('.crawl-complete-close').addEventListener('click', () => {
    clearTimeout(autoCloseTimer);
  });
}

// ==================== 喜好描述功能 ====================

// 显示喜好描述模态框
function showPreferenceModal(hotspotId) {
  const hotspot = hotspots.find(h => h.id === hotspotId);
  if (!hotspot) return;
  
  // 移除已存在的模态框
  const existing = document.querySelector('.preference-modal');
  if (existing) existing.remove();
  
  const modal = document.createElement('div');
  modal.className = 'preference-modal';
  modal.innerHTML = `
    <div class="preference-overlay" onclick="closePreferenceModal()"></div>
    <div class="preference-content">
      <div class="preference-header">
        <h2>💭 喜好描述</h2>
        <button class="preference-close" onclick="closePreferenceModal()">✕</button>
      </div>
      <div class="preference-body">
        <div class="preference-hotspot-info">
          <div class="preference-platform">${hotspot.platform.toUpperCase()}</div>
          <div class="preference-title">${escapeHtml(hotspot.title)}</div>
        </div>
        
        <div class="preference-rating">
          <label>评分（1-5星）：</label>
          <div class="star-rating">
            ${[1,2,3,4,5].map(i => `<span class="star" data-rating="${i}" onclick="setStarRating(${i})">☆</span>`).join('')}
          </div>
          <input type="hidden" id="preference-rating-value" value="">
        </div>
        
        <div class="preference-actions">
          <label>喜好类型：</label>
          <div class="action-buttons">
            <button class="action-btn positive" data-action="like" onclick="setPreferenceAction('like')">👍 喜欢</button>
            <button class="action-btn positive" data-action="interested" onclick="setPreferenceAction('interested')">🎯 感兴趣</button>
            <button class="action-btn positive" data-action="useful" onclick="setPreferenceAction('useful')">💡 有用</button>
          </div>
          <div class="action-buttons" style="margin-top: 8px;">
            <button class="action-btn negative" data-action="dislike" onclick="setPreferenceAction('dislike')">👎 不喜欢</button>
            <button class="action-btn negative" data-action="irrelevant" onclick="setPreferenceAction('irrelevant')">🚫 不相关</button>
            <button class="action-btn negative" data-action="spam" onclick="setPreferenceAction('spam')">🗑️ 垃圾内容</button>
          </div>
          <input type="hidden" id="preference-action-value" value="">
        </div>
        
        <div class="preference-comment">
          <label>详细描述（可选）：</label>
          <textarea id="preference-comment-text" placeholder="描述您对这个热点的看法、为什么喜欢/不喜欢、希望看到更多类似内容吗？"></textarea>
        </div>
        
        <div class="preference-tags">
          <label>标签（可选，用逗号分隔）：</label>
          <input type="text" id="preference-tags-text" placeholder="例如：AI工具, 开源项目, 教程">
        </div>
      </div>
      <div class="preference-footer">
        <button class="btn-cancel" onclick="closePreferenceModal()">取消</button>
        <button class="btn-submit" onclick="submitPreference('${hotspotId}')">提交</button>
      </div>
    </div>
  `;
  
  document.body.appendChild(modal);
  
  // 动画显示
  requestAnimationFrame(() => {
    modal.classList.add('active');
  });
}

// 关闭喜好描述模态框
function closePreferenceModal() {
  const modal = document.querySelector('.preference-modal');
  if (modal) {
    modal.classList.remove('active');
    setTimeout(() => modal.remove(), 300);
  }
}

// 设置星级评分
function setStarRating(rating) {
  document.getElementById('preference-rating-value').value = rating;
  document.querySelectorAll('.star-rating .star').forEach((star, index) => {
    star.textContent = index < rating ? '★' : '☆';
    star.classList.toggle('active', index < rating);
  });
}

// 设置喜好类型
function setPreferenceAction(action) {
  document.getElementById('preference-action-value').value = action;
  document.querySelectorAll('.action-buttons .action-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.action === action);
  });
}

// 提交喜好描述
async function submitPreference(hotspotId) {
  const rating = document.getElementById('preference-rating-value').value;
  const action = document.getElementById('preference-action-value').value;
  const comment = document.getElementById('preference-comment-text').value;
  const tags = document.getElementById('preference-tags-text').value;
  
  if (!rating && !action) {
    alert('请至少选择评分或喜好类型');
    return;
  }
  
  try {
    const response = await fetch('/api/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        hotspot_id: hotspotId,
        user_id: 'user_' + (localStorage.getItem('userId') || 'anonymous'),
        action: action || 'comment',
        rating: rating ? parseInt(rating) : null,
        comment: comment + (tags ? '\n标签: ' + tags : '')
      })
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('[Preference] Submitted:', result);
      
      // 更新本地热点分数（实时反馈）
      if (result.personalizedScore) {
        const index = hotspots.findIndex(h => h.id === hotspotId);
        if (index !== -1) {
          const oldScore = hotspots[index].score || hotspots[index].avg_score || 0;
          const newScore = result.personalizedScore.score;
          hotspots[index].score = newScore;
          hotspots[index].avg_score = newScore; // 同步更新 avg_score
          hotspots[index].personalizationBonus = result.personalizedScore.personalizationBonus;
          hotspots[index].feedbackDescription = result.personalizedScore.feedbackDescription;
          
          // 实时更新卡片显示
          updateHotspotScore(hotspotId, newScore, result.personalizedScore.feedbackDescription);
          
          // 显示分数变化
          const change = newScore - oldScore;
          const changeText = change > 0 ? `+${change}` : `${change}`;
          const changeEmoji = change > 0 ? '📈' : change < 0 ? '📉' : '➡️';
          showToast(`${changeEmoji} 分数变化: ${oldScore} → ${newScore} (${changeText})`);
          
          // 自动重新排序（带动画）
          setTimeout(() => {
            animateReorderHotspots();
          }, 1000);
        }
      }
      
      closePreferenceModal();
    } else {
      const error = await response.json();
      alert('提交失败: ' + (error.error || '未知错误'));
    }
  } catch (err) {
    console.error('[Preference] Submit failed:', err);
    alert('提交失败，请稍后重试');
  }
}

// 显示提示消息
function showToast(message) {
  const toast = document.createElement('div');
  toast.className = 'toast-message';
  toast.textContent = message;
  document.body.appendChild(toast);
  
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });
  
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 300);
  }, 3000);
}

// 更新单个热点卡片（用于翻译后局部刷新）
function updateHotspotCard(hotspotId) {
  const h = hotspots.find(h => h.id === hotspotId);
  if (!h) return;
  
  const card = document.querySelector(`.hotspot-card[data-id="${hotspotId}"]`);
  if (!card) return;
  
  // 更新按钮状态
  const btn = card.querySelector('.btn-translate');
  if (btn) {
    btn.textContent = h.title_zh ? '✓中' : '中';
    btn.classList.toggle('translated', !!h.title_zh);
    btn.title = h.title_zh ? '已翻译' : '翻译';
    btn.disabled = false;
  }
  
  // 更新或添加中文标题
  let titleZhEl = card.querySelector('.card-title-zh');
  if (h.title_zh && !isChineseText(h.title)) {
    if (!titleZhEl) {
      const titleEl = card.querySelector('.card-title');
      if (titleEl) {
        titleZhEl = document.createElement('div');
        titleZhEl.className = 'card-title-zh';
        titleEl.after(titleZhEl);
      }
    }
    if (titleZhEl) {
      titleZhEl.textContent = h.title_zh;
    }
  }
}

// 实时更新热点分数显示
function updateHotspotScore(hotspotId, newScore, feedbackDescription) {
  const card = document.querySelector(`.hotspot-card[data-id="${hotspotId}"]`);
  if (!card) return;
  
  // 更新分数圆环
  const scoreRing = card.querySelector('.score-ring');
  if (scoreRing) {
    const oldScore = parseInt(scoreRing.textContent) || 0;
    scoreRing.textContent = newScore;
    
    // 添加动画效果
    scoreRing.style.transform = 'scale(1.2)';
    scoreRing.style.transition = 'transform 0.3s ease';
    
    // 根据分数变化添加颜色
    if (newScore > oldScore) {
      scoreRing.style.color = '#22c55e'; // 绿色 - 提升
    } else if (newScore < oldScore) {
      scoreRing.style.color = '#ef4444'; // 红色 - 下降
    }
    
    setTimeout(() => {
      scoreRing.style.transform = 'scale(1)';
      scoreRing.style.color = ''; // 恢复默认颜色
    }, 1000);
  }
  
  // 添加反馈说明标签
  if (feedbackDescription && feedbackDescription !== '无反馈') {
    let feedbackTag = card.querySelector('.feedback-tag');
    if (!feedbackTag) {
      feedbackTag = document.createElement('span');
      feedbackTag.className = 'feedback-tag';
      const platformEl = card.querySelector('.card-platform');
      if (platformEl) {
        platformEl.appendChild(feedbackTag);
      }
    }
    feedbackTag.textContent = ` [${feedbackDescription}]`;
    feedbackTag.style.color = feedbackDescription.includes('负面') || feedbackDescription.includes('降权') 
      ? '#ef4444' : '#22c55e';
  }
}

// ==================== 手动翻译功能 ====================

// 翻译热点
async function translateHotspot(hotspotId) {
  const hotspot = hotspots.find(h => h.id === hotspotId);
  if (!hotspot) return;
  
  // 如果已经有翻译，显示确认
  if (hotspot.title_zh) {
    if (!confirm('该热点已有翻译，是否重新翻译？')) {
      return;
    }
  }
  
  // 显示加载状态
  const btn = document.querySelector(`.hotspot-card[data-id="${hotspotId}"] .btn-translate`);
  if (btn) {
    btn.textContent = '...';
    btn.disabled = true;
  }
  
  try {
    const response = await fetch('/api/translate/single', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ hotspot_id: hotspotId })
    });
    
    if (response.ok) {
      const result = await response.json();
      console.log('[Translate] Success:', result);
      
      // 更新本地数据
      const index = hotspots.findIndex(h => h.id === hotspotId);
      if (index !== -1 && result.title_zh) {
        hotspots[index].title_zh = result.title_zh;
        hotspots[index].content_zh = result.content_zh;
        console.log('[Translate] Updated local data:', hotspots[index].title_zh);
        
        // 直接更新DOM，避免重新渲染整个列表
        updateHotspotCard(hotspotId);
        showToast('翻译完成！');
      } else {
        showToast('翻译失败：未返回有效结果');
      }
    } else {
      const error = await response.json();
      showToast('翻译失败: ' + (error.error || '未知错误'));
    }
  } catch (err) {
    console.error('[Translate] Failed:', err);
    showToast('翻译失败，请稍后重试');
  } finally {
    // 按钮状态会在 updateHotspotsUI 中重新渲染
  }
}

// 动画重新排序热点卡片
function animateReorderHotspots() {
  const container = document.querySelector('.hotspot-list');
  if (!container) return;
  
  // 获取所有卡片
  const cards = Array.from(container.querySelectorAll('.hotspot-card'));
  if (cards.length === 0) return;
  
  // 记录当前位置
  const positions = new Map();
  cards.forEach(card => {
    const rect = card.getBoundingClientRect();
    positions.set(card.dataset.id, { top: rect.top, left: rect.left });
  });
  
  // 按新分数排序热点数据
  hotspots.sort((a, b) => (b.score || b.avg_score || 0) - (a.score || a.avg_score || 0));
  
  // 重新渲染（但不立即显示）
  updateHotspotsUI();
  
  // 获取新位置并应用动画
  const newCards = Array.from(container.querySelectorAll('.hotspot-card'));
  newCards.forEach(card => {
    const oldPos = positions.get(card.dataset.id);
    if (oldPos) {
      const newRect = card.getBoundingClientRect();
      const deltaY = oldPos.top - newRect.top;
      
      // 应用动画
      card.style.transform = `translateY(${deltaY}px)`;
      card.style.transition = 'none';
      
      // 强制重绘
      card.offsetHeight;
      
      // 开始动画
      card.style.transition = 'transform 0.5s cubic-bezier(0.4, 0, 0.2, 1)';
      card.style.transform = '';
    }
  });
  
  // 动画完成后清除样式
  setTimeout(() => {
    newCards.forEach(card => {
      card.style.transition = '';
      card.style.transform = '';
    });
  }, 500);
}

// 切换个性化排序
let isPersonalizedSort = false;

async function togglePersonalizedSort() {
  isPersonalizedSort = !isPersonalizedSort;
  
  const btn = document.querySelector('.btn-personalized');
  const label = document.getElementById('personalized-label');
  
  if (isPersonalizedSort) {
    btn.classList.add('active');
    label.textContent = '智能排序 ✓';
    showToast('已切换到智能排序（基于您的喜好反馈）');
    await loadPersonalizedHotspots();
  } else {
    btn.classList.remove('active');
    label.textContent = '智能排序';
    showToast('已切换到默认排序');
    await loadHotspots();
  }
}

// 加载个性化排序的热点
async function loadPersonalizedHotspots() {
  try {
    const userId = 'user_' + (localStorage.getItem('userId') || 'anonymous');
    const response = await fetch(`${API_BASE}/api/hotspots/personalized?user_id=${userId}&limit=50`);
    const data = await response.json();
    hotspots = Array.isArray(data) ? data : [];
    
    console.log(`[Personalized] Loaded ${hotspots.length} hotspots with personalized ranking`);
    updateHotspotsUI();
  } catch (err) {
    console.error('[Personalized] Failed to load:', err);
    showError('加载个性化排序失败');
  }
}

// Start app when DOM is ready
document.addEventListener('DOMContentLoaded', init);
