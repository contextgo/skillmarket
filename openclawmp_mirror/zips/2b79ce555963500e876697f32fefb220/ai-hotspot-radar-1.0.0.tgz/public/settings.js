/**
 * 设置面板模块 - 配置系统参数
 */

class SettingsManager {
  constructor() {
    this.container = null;
    this.settings = {
      minScore: 80,
      autoCrawl: true,
      crawlInterval: 6,
      notifications: true,
      browserNotif: false,
      webhook: ''
    };
  }

  // 显示设置面板
  show() {
    this.loadSettings();
    this.createModal();
    this.render();
  }

  // 加载设置
  loadSettings() {
    const saved = localStorage.getItem('hotspotSettings');
    if (saved) {
      this.settings = { ...this.settings, ...JSON.parse(saved) };
    }
  }

  // 保存设置
  saveSettings() {
    localStorage.setItem('hotspotSettings', JSON.stringify(this.settings));
  }

  // 创建模态框
  createModal() {
    const existing = document.querySelector('.settings-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.className = 'settings-modal';
    modal.innerHTML = `
      <div class="settings-overlay" onclick="settingsManager.close()"></div>
      <div class="settings-content">
        <div class="settings-header">
          <h2>⚙️ 设置</h2>
          <button class="settings-close" onclick="settingsManager.close()">✕</button>
        </div>
        <div class="settings-body">
          <div class="settings-section">
            <h3>📊 抓取设置</h3>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">自动抓取</div>
                <div class="setting-desc">定时自动抓取新热点</div>
              </div>
              <label class="switch">
                <input type="checkbox" id="setting-auto-crawl" ${this.settings.autoCrawl ? 'checked' : ''}>
                <span class="slider"></span>
              </label>
            </div>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">抓取间隔</div>
                <div class="setting-desc">小时</div>
              </div>
              <select class="setting-select" id="setting-interval">
                <option value="1" ${this.settings.crawlInterval === 1 ? 'selected' : ''}>1小时</option>
                <option value="3" ${this.settings.crawlInterval === 3 ? 'selected' : ''}>3小时</option>
                <option value="6" ${this.settings.crawlInterval === 6 ? 'selected' : ''}>6小时</option>
                <option value="12" ${this.settings.crawlInterval === 12 ? 'selected' : ''}>12小时</option>
                <option value="24" ${this.settings.crawlInterval === 24 ? 'selected' : ''}>24小时</option>
              </select>
            </div>
          </div>

          <div class="settings-section">
            <h3>🔔 通知设置</h3>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">高分通知</div>
                <div class="setting-desc">推送高分热点通知</div>
              </div>
              <label class="switch">
                <input type="checkbox" id="setting-notifications" ${this.settings.notifications ? 'checked' : ''}>
                <span class="slider"></span>
              </label>
            </div>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">分数阈值</div>
                <div class="setting-desc">触发通知的最低分数</div>
              </div>
              <input type="number" class="setting-input" id="setting-min-score" 
                     value="${this.settings.minScore}" min="0" max="100">
            </div>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">浏览器通知</div>
                <div class="setting-desc">桌面推送通知</div>
              </div>
              <label class="switch">
                <input type="checkbox" id="setting-browser-notif" ${this.settings.browserNotif ? 'checked' : ''}>
                <span class="slider"></span>
              </label>
            </div>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">Webhook URL</div>
                <div class="setting-desc">接收通知的外部地址</div>
              </div>
              <input type="text" class="setting-input" id="setting-webhook" 
                     value="${this.settings.webhook}" placeholder="https://...">
            </div>
          </div>

          <div class="settings-section">
            <h3>📧 邮件订阅</h3>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">订阅邮箱</div>
                <div class="setting-desc">接收每日热点摘要</div>
              </div>
              <div style="display: flex; gap: 8px;">
                <input type="email" class="setting-input" id="setting-email" 
                       value="${this.settings.email || ''}" placeholder="your@email.com" style="width: 180px;">
                <button class="btn btn-primary" onclick="settingsManager.subscribeEmail()" style="padding: 8px 16px; font-size: 12px;">订阅</button>
              </div>
            </div>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">发送频率</div>
                <div class="setting-desc">每日摘要发送时间</div>
              </div>
              <select class="setting-select" id="setting-email-time">
                <option value="08:00">08:00</option>
                <option value="09:00" selected>09:00</option>
                <option value="10:00">10:00</option>
                <option value="18:00">18:00</option>
                <option value="20:00">20:00</option>
              </select>
            </div>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">测试邮件</div>
                <div class="setting-desc">立即发送一封测试邮件</div>
              </div>
              <button class="btn btn-secondary" onclick="settingsManager.sendTestEmail()" style="padding: 8px 16px; font-size: 12px;">发送测试</button>
            </div>
          </div>

          <div class="settings-section">
            <h3>🎨 显示设置</h3>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">显示摘要</div>
                <div class="setting-desc">在卡片中显示内容摘要</div>
              </div>
              <label class="switch">
                <input type="checkbox" id="setting-show-summary" checked>
                <span class="slider"></span>
              </label>
            </div>
            <div class="setting-item">
              <div class="setting-info">
                <div class="setting-label">显示翻译</div>
                <div class="setting-desc">显示中文翻译</div>
              </div>
              <label class="switch">
                <input type="checkbox" id="setting-show-translation" checked>
                <span class="slider"></span>
              </label>
            </div>
          </div>
        </div>
        <div class="settings-footer">
          <button class="btn btn-secondary" onclick="settingsManager.close()">取消</button>
          <button class="btn btn-primary" onclick="settingsManager.save()">保存设置</button>
        </div>
      </div>
    `;

    document.body.appendChild(modal);

    setTimeout(() => {
      modal.classList.add('active');
    }, 10);
  }

  // 渲染
  render() {
    // 绑定事件
    document.getElementById('setting-auto-crawl')?.addEventListener('change', (e) => {
      this.settings.autoCrawl = e.target.checked;
    });
    document.getElementById('setting-interval')?.addEventListener('change', (e) => {
      this.settings.crawlInterval = parseInt(e.target.value);
    });
    document.getElementById('setting-notifications')?.addEventListener('change', (e) => {
      this.settings.notifications = e.target.checked;
    });
    document.getElementById('setting-min-score')?.addEventListener('change', (e) => {
      this.settings.minScore = parseInt(e.target.value);
    });
    document.getElementById('setting-browser-notif')?.addEventListener('change', (e) => {
      this.settings.browserNotif = e.target.checked;
    });
    document.getElementById('setting-webhook')?.addEventListener('change', (e) => {
      this.settings.webhook = e.target.value;
    });
    document.getElementById('setting-email')?.addEventListener('change', (e) => {
      this.settings.email = e.target.value;
    });
  }

  // 订阅邮件
  async subscribeEmail() {
    const email = document.getElementById('setting-email')?.value;
    const scheduleTime = document.getElementById('setting-email-time')?.value || '09:00';
    
    if (!email) {
      showNotification('❌ 请输入邮箱地址');
      return;
    }
    
    try {
      const response = await fetch('/api/email/subscribe', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, scheduleType: 'daily', scheduleTime })
      });
      const result = await response.json();
      
      if (result.success) {
        showNotification('✅ 订阅成功！');
        this.settings.email = email;
        this.saveSettings();
      } else {
        showNotification('❌ 订阅失败: ' + (result.error || '未知错误'));
      }
    } catch (err) {
      showNotification('❌ 订阅失败: ' + err.message);
    }
  }

  // 发送测试邮件
  async sendTestEmail() {
    const email = document.getElementById('setting-email')?.value;
    
    if (!email) {
      showNotification('❌ 请先输入邮箱地址');
      return;
    }
    
    showNotification('📧 正在发送测试邮件...');
    
    try {
      const response = await fetch('/api/email/test', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const result = await response.json();
      
      if (result.success) {
        showNotification('✅ 测试邮件已发送！');
      } else {
        showNotification('❌ 发送失败: ' + (result.error?.message || '未知错误'));
      }
    } catch (err) {
      showNotification('❌ 发送失败: ' + err.message);
    }
  }

  // 保存
  save() {
    this.saveSettings();
    showNotification('✅ 设置已保存');
    this.close();
  }

  // 关闭模态框
  close() {
    const modal = document.querySelector('.settings-modal');
    if (modal) {
      modal.classList.remove('active');
      setTimeout(() => modal.remove(), 300);
    }
  }
}

// 全局实例
const settingsManager = new SettingsManager();
