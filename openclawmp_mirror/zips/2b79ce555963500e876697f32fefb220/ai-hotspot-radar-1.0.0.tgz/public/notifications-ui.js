/**
 * 通知中心模块 - 展示系统通知
 */

class NotificationsManager {
  constructor() {
    this.container = null;
    this.notifications = [];
  }

  // 显示通知中心
  show() {
    this.loadNotifications();
    this.createModal();
    this.render();
  }

  // 加载通知数据
  async loadNotifications() {
    try {
      const response = await fetch('/api/notifications?limit=20');
      const data = await response.json();
      this.notifications = data.notifications || [];
    } catch (err) {
      console.error('Failed to load notifications:', err);
      this.notifications = [];
    }
  }

  // 创建模态框
  createModal() {
    const existing = document.querySelector('.notifications-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.className = 'notifications-modal';
    modal.innerHTML = `
      <div class="notifications-overlay" onclick="notificationsManager.close()"></div>
      <div class="notifications-content">
        <div class="notifications-header">
          <h2>🔔 通知中心</h2>
          <div class="notifications-actions">
            <button class="btn-mark-all" onclick="notificationsManager.markAllRead()">全部已读</button>
            <button class="notifications-close" onclick="notificationsManager.close()">✕</button>
          </div>
        </div>
        <div class="notifications-body">
          <div class="notifications-list"></div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    this.container = modal.querySelector('.notifications-list');

    setTimeout(() => {
      modal.classList.add('active');
    }, 10);
  }

  // 渲染通知列表
  render() {
    if (!this.container) return;

    if (this.notifications.length === 0) {
      this.container.innerHTML = `
        <div class="notifications-empty">
          <div class="empty-icon">🔔</div>
          <div class="empty-text">暂无通知</div>
          <div class="empty-hint">高分热点将自动推送至此</div>
        </div>
      `;
      return;
    }

    this.container.innerHTML = this.notifications.map(n => {
      const time = this.formatTime(n.created_at);
      const isRead = n.read || false;
      
      return `
        <div class="notification-item ${isRead ? 'read' : 'unread'}" data-id="${n.id}">
          <div class="notification-dot"></div>
          <div class="notification-content">
            <div class="notification-title">${n.title}</div>
            <div class="notification-message">${n.message}</div>
            <div class="notification-time">${time}</div>
          </div>
          <button class="notification-delete" onclick="notificationsManager.delete('${n.id}')">✕</button>
        </div>
      `;
    }).join('');
  }

  // 标记全部已读
  markAllRead() {
    this.notifications.forEach(n => n.read = true);
    this.render();
    showNotification('✅ 全部标记为已读');
  }

  // 删除通知
  delete(id) {
    this.notifications = this.notifications.filter(n => n.id !== id);
    this.render();
  }

  // 格式化时间
  formatTime(timestamp) {
    if (!timestamp) return 'Unknown';
    const date = new Date(timestamp);
    const now = new Date();
    const diff = (now - date) / 1000;
    
    if (diff < 60) return '刚刚';
    if (diff < 3600) return `${Math.floor(diff / 60)}分钟前`;
    if (diff < 86400) return `${Math.floor(diff / 3600)}小时前`;
    return `${Math.floor(diff / 86400)}天前`;
  }

  // 关闭模态框
  close() {
    const modal = document.querySelector('.notifications-modal');
    if (modal) {
      modal.classList.remove('active');
      setTimeout(() => modal.remove(), 300);
    }
  }
}

// 全局实例
const notificationsManager = new NotificationsManager();
