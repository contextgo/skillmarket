/**
 * 趋势分析模块 - 展示热点趋势图表
 */

class TrendsManager {
  constructor() {
    this.container = null;
    this.data = [];
  }

  // 显示趋势分析
  show(hotspots) {
    this.data = hotspots;
    this.createModal();
    this.render();
  }

  // 创建模态框
  createModal() {
    const existing = document.querySelector('.trends-modal');
    if (existing) existing.remove();

    const modal = document.createElement('div');
    modal.className = 'trends-modal';
    modal.innerHTML = `
      <div class="trends-overlay" onclick="trendsManager.close()"></div>
      <div class="trends-content">
        <div class="trends-header">
          <h2>📊 趋势分析</h2>
          <button class="trends-close" onclick="trendsManager.close()">✕</button>
        </div>
        <div class="trends-body">
          <div class="trends-stats">
            <div class="trend-stat">
              <div class="trend-value" id="trend-total">0</div>
              <div class="trend-label">总热点</div>
            </div>
            <div class="trend-stat">
              <div class="trend-value" id="trend-avg">0</div>
              <div class="trend-label">平均分</div>
            </div>
            <div class="trend-stat">
              <div class="trend-value" id="trend-high">0</div>
              <div class="trend-label">高分热点</div>
            </div>
            <div class="trend-stat">
              <div class="trend-value" id="trend-new">0</div>
              <div class="trend-label">24h新增</div>
            </div>
          </div>
          <div class="trends-chart">
            <h3>平台分布</h3>
            <div class="chart-bars" id="platform-chart"></div>
          </div>
          <div class="trends-chart">
            <h3>分数分布</h3>
            <div class="chart-bars" id="score-chart"></div>
          </div>
          <div class="trends-top">
            <h3>🏆 热门话题 TOP 5</h3>
            <div class="top-list" id="top-topics"></div>
          </div>
        </div>
      </div>
    `;

    document.body.appendChild(modal);
    this.container = modal;

    setTimeout(() => {
      modal.classList.add('active');
    }, 10);
  }

  // 渲染趋势
  render() {
    if (!this.container) return;

    // 统计数据
    const total = this.data.length;
    const avgScore = Math.round(this.data.reduce((sum, h) => sum + (h.avg_score || 50), 0) / total);
    const highScore = this.data.filter(h => (h.avg_score || 0) >= 80).length;
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const newCount = this.data.filter(h => new Date(h.crawled_at) > oneDayAgo).length;

    document.getElementById('trend-total').textContent = total;
    document.getElementById('trend-avg').textContent = avgScore;
    document.getElementById('trend-high').textContent = highScore;
    document.getElementById('trend-new').textContent = newCount;

    // 平台分布图表
    const platformStats = {};
    this.data.forEach(h => {
      platformStats[h.platform] = (platformStats[h.platform] || 0) + 1;
    });

    const platformChart = document.getElementById('platform-chart');
    const maxPlatform = Math.max(...Object.values(platformStats));
    platformChart.innerHTML = Object.entries(platformStats)
      .sort((a, b) => b[1] - a[1])
      .map(([name, count]) => {
        const percent = (count / maxPlatform) * 100;
        return `
          <div class="chart-bar">
            <div class="bar-label">${name.toUpperCase()}</div>
            <div class="bar-track">
              <div class="bar-fill" style="width: ${percent}%"></div>
            </div>
            <div class="bar-value">${count}</div>
          </div>
        `;
      }).join('');

    // 分数分布图表
    const scoreRanges = {
      '90-100': 0,
      '80-89': 0,
      '70-79': 0,
      '60-69': 0,
      '50-59': 0,
      '<50': 0
    };

    this.data.forEach(h => {
      const score = h.avg_score || 50;
      if (score >= 90) scoreRanges['90-100']++;
      else if (score >= 80) scoreRanges['80-89']++;
      else if (score >= 70) scoreRanges['70-79']++;
      else if (score >= 60) scoreRanges['60-69']++;
      else if (score >= 50) scoreRanges['50-59']++;
      else scoreRanges['<50']++;
    });

    const scoreChart = document.getElementById('score-chart');
    const maxScore = Math.max(...Object.values(scoreRanges));
    scoreChart.innerHTML = Object.entries(scoreRanges)
      .map(([range, count]) => {
        const percent = maxScore > 0 ? (count / maxScore) * 100 : 0;
        return `
          <div class="chart-bar">
            <div class="bar-label">${range}</div>
            <div class="bar-track">
              <div class="bar-fill" style="width: ${percent}%"></div>
            </div>
            <div class="bar-value">${count}</div>
          </div>
        `;
      }).join('');

    // TOP 5 热门话题
    const topList = document.getElementById('top-topics');
    topList.innerHTML = this.data
      .sort((a, b) => (b.avg_score || 0) - (a.avg_score || 0))
      .slice(0, 5)
      .map((h, i) => `
        <div class="top-item">
          <div class="top-rank">${i + 1}</div>
          <div class="top-info">
            <div class="top-title">${h.title.substring(0, 60)}${h.title.length > 60 ? '...' : ''}</div>
            <div class="top-meta">${h.platform.toUpperCase()} | ${h.avg_score || 50} 分</div>
          </div>
        </div>
      `).join('');
  }

  // 关闭模态框
  close() {
    const modal = document.querySelector('.trends-modal');
    if (modal) {
      modal.classList.remove('active');
      setTimeout(() => modal.remove(), 300);
    }
  }
}

// 全局实例
const trendsManager = new TrendsManager();
