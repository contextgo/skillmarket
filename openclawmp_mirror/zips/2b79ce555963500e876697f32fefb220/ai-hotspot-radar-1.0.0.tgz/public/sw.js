// Service Worker for PWA
const CACHE_NAME = 'hotspot-radar-v1';
const STATIC_ASSETS = [
  '/',
  '/index.html',
  '/app.js',
  '/content-analyzer.js',
  '/favorites.js',
  '/heatmap.js',
  '/trends.js',
  '/notifications-ui.js',
  '/settings.js',
  '/websocket.js'
];

// 安装时缓存静态资源
self.addEventListener('install', (event) => {
  console.log('[Service Worker] Installing...');
  
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[Service Worker] Caching static assets');
      return cache.addAll(STATIC_ASSETS);
    })
  );
  
  self.skipWaiting();
});

// 激活时清理旧缓存
self.addEventListener('activate', (event) => {
  console.log('[Service Worker] Activating...');
  
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames
          .filter((name) => name !== CACHE_NAME)
          .map((name) => caches.delete(name))
      );
    })
  );
  
  self.clients.claim();
});

// 拦截请求
self.addEventListener('fetch', (event) => {
  const { request } = event;
  
  // API 请求不缓存
  if (request.url.includes('/api/') || request.url.includes('/ws')) {
    event.respondWith(fetch(request));
    return;
  }
  
  // 静态资源使用缓存优先策略
  event.respondWith(
    caches.match(request).then((cached) => {
      // 返回缓存或发起网络请求
      const fetchPromise = fetch(request).then((networkResponse) => {
        // 更新缓存
        if (networkResponse.ok) {
          const clone = networkResponse.clone();
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(request, clone);
          });
        }
        return networkResponse;
      });
      
      return cached || fetchPromise;
    })
  );
});

// 处理推送通知
self.addEventListener('push', (event) => {
  console.log('[Service Worker] Push received:', event);
  
  const data = event.data ? event.data.json() : {};
  const title = data.title || '🔥 AI 热点雷达';
  const options = {
    body: data.body || '新热点提醒',
    icon: '/icons/icon-192x192.png',
    badge: '/icons/icon-72x72.png',
    tag: data.tag || 'hotspot',
    requireInteraction: data.requireInteraction || false,
    data: data.data || {}
  };
  
  event.waitUntil(
    self.registration.showNotification(title, options)
  );
});

// 点击通知
self.addEventListener('notificationclick', (event) => {
  console.log('[Service Worker] Notification click:', event);
  
  event.notification.close();
  
  const url = event.notification.data?.url || '/';
  
  event.waitUntil(
    clients.matchAll({ type: 'window' }).then((clientList) => {
      // 如果已有窗口打开，聚焦它
      for (const client of clientList) {
        if (client.url === url && 'focus' in client) {
          return client.focus();
        }
      }
      // 否则打开新窗口
      if (clients.openWindow) {
        return clients.openWindow(url);
      }
    })
  );
});

// 后台同步
self.addEventListener('sync', (event) => {
  console.log('[Service Worker] Background sync:', event.tag);
  
  if (event.tag === 'sync-hotspots') {
    event.waitUntil(syncHotspots());
  }
});

async function syncHotspots() {
  try {
    const response = await fetch('/api/hotspots?limit=50');
    const data = await response.json();
    console.log('[Service Worker] Synced hotspots:', data.length);
    return data;
  } catch (err) {
    console.error('[Service Worker] Sync failed:', err);
  }
}
