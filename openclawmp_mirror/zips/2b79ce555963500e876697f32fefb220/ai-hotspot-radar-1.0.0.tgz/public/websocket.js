/**
 * WebSocket 实时推送模块
 */

class WebSocketManager {
  constructor() {
    this.ws = null;
    this.reconnectInterval = 3000;
    this.reconnectAttempts = 0;
    this.maxReconnectAttempts = 5;
    this.listeners = new Map();
    this.isConnected = false;
  }

  // 连接 WebSocket
  connect() {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    
    console.log('[WebSocket] Connecting to', wsUrl);
    
    try {
      this.ws = new WebSocket(wsUrl);
      
      this.ws.onopen = () => {
        console.log('[WebSocket] Connected');
        this.isConnected = true;
        this.reconnectAttempts = 0;
        this.emit('connected', {});
        showNotification('🟢 实时推送已连接');
      };
      
      this.ws.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          console.log('[WebSocket] Received:', data.type);
          this.handleMessage(data);
        } catch (err) {
          console.error('[WebSocket] Failed to parse message:', err);
        }
      };
      
      this.ws.onclose = () => {
        console.log('[WebSocket] Disconnected');
        this.isConnected = false;
        this.emit('disconnected', {});
        this.attemptReconnect();
      };
      
      this.ws.onerror = (err) => {
        console.error('[WebSocket] Error:', err);
        this.emit('error', err);
      };
      
    } catch (err) {
      console.error('[WebSocket] Failed to connect:', err);
      this.attemptReconnect();
    }
  }

  // 尝试重连
  attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.log('[WebSocket] Max reconnection attempts reached');
      showNotification('🔴 实时推送连接失败，请刷新页面重试');
      return;
    }
    
    this.reconnectAttempts++;
    console.log(`[WebSocket] Reconnecting in ${this.reconnectInterval}ms (attempt ${this.reconnectAttempts})`);
    
    setTimeout(() => {
      this.connect();
    }, this.reconnectInterval);
  }

  // 处理消息
  handleMessage(data) {
    switch (data.type) {
      case 'new_hotspot':
        this.emit('new_hotspot', data.data);
        this.showNewHotspotNotification(data.data);
        break;
      case 'hotspot_update':
        this.emit('hotspot_update', data.data);
        break;
      case 'crawl_progress':
        this.emit('crawl_progress', data.data);
        break;
      case 'crawl_complete':
        this.emit('crawl_complete', data.data);
        showNotification(`✅ 抓取完成！新增 ${data.data.newCount} 条热点`);
        break;
      case 'high_score_alert':
        this.emit('high_score_alert', data.data);
        this.showHighScoreNotification(data.data);
        break;
      case 'ping':
        this.send({ type: 'pong' });
        break;
      default:
        this.emit(data.type, data.data);
    }
  }

  // 显示新热点通知
  showNewHotspotNotification(hotspot) {
    // 浏览器通知
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('🔥 新热点', {
        body: hotspot.title,
        icon: '/favicon.ico',
        tag: hotspot.id
      });
    }
    
    // 页面内通知
    showNotification(`🔥 新热点: ${hotspot.title.substring(0, 30)}...`);
  }

  // 显示高分预警通知
  showHighScoreNotification(hotspot) {
    // 浏览器通知
    if ('Notification' in window && Notification.permission === 'granted') {
      new Notification('⭐ 高分热点预警', {
        body: `[${hotspot.avg_score}] ${hotspot.title}`,
        icon: '/favicon.ico',
        tag: hotspot.id,
        requireInteraction: true
      });
    }
    
    // 页面内通知
    showNotification(`⭐ 高分热点: [${hotspot.avg_score}] ${hotspot.title.substring(0, 30)}...`, 5000);
  }

  // 发送消息
  send(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data));
    } else {
      console.warn('[WebSocket] Not connected, cannot send:', data);
    }
  }

  // 订阅事件
  on(event, callback) {
    if (!this.listeners.has(event)) {
      this.listeners.set(event, []);
    }
    this.listeners.get(event).push(callback);
  }

  // 取消订阅
  off(event, callback) {
    if (this.listeners.has(event)) {
      const callbacks = this.listeners.get(event);
      const index = callbacks.indexOf(callback);
      if (index > -1) {
        callbacks.splice(index, 1);
      }
    }
  }

  // 触发事件
  emit(event, data) {
    if (this.listeners.has(event)) {
      this.listeners.get(event).forEach(callback => {
        try {
          callback(data);
        } catch (err) {
          console.error('[WebSocket] Error in listener:', err);
        }
      });
    }
  }

  // 断开连接
  disconnect() {
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    this.isConnected = false;
  }

  // 请求浏览器通知权限
  async requestNotificationPermission() {
    if (!('Notification' in window)) {
      console.log('[WebSocket] Notifications not supported');
      return false;
    }
    
    const permission = await Notification.requestPermission();
    return permission === 'granted';
  }
}

// 全局实例
const wsManager = new WebSocketManager();

// 页面加载后自动连接
document.addEventListener('DOMContentLoaded', () => {
  // 延迟连接，确保页面完全加载
  setTimeout(() => {
    wsManager.connect();
  }, 1000);
});
