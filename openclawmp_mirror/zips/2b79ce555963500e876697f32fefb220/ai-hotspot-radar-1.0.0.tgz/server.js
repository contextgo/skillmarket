const express = require('express');
const cors = require('cors');
const cron = require('node-cron');
const path = require('path');
const fs = require('fs');
const http = require('http');
const WebSocket = require('ws');

// 全局异常处理，防止进程崩溃
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});
process.on('uncaughtException', (err) => {
  console.error('Uncaught Exception:', err);
  // 不退出进程，继续运行
});

const Storage = require('./storage');
const { 
  PlatformAdapter, TwitterAdapter, RedditAdapter, HackerNewsAdapter, ProductHuntAdapter, 
  LinkedInAdapter, WeiboAdapter, XiaohongshuAdapter, JikeAdapter, juejinAdapter, V2EXAdapter, 
  ChinaAIAdapter, TwitterAgentBrowserAdapter, WeiboAgentBrowserAdapter, ZhihuAgentBrowserAdapter, 
  GitHubAgentBrowserAdapter, SanliuAgentBrowserAdapter, JiqizhixinAgentBrowserAdapter,
  // 新增平台适配器 (v3.0)
  SanliuKrAgentBrowserAdapter, GeekParkAgentBrowserAdapter, iFanrAgentBrowserAdapter,
  BilibiliAgentBrowserAdapter
} = require('./platforms');
const { GitHubSimpleAdapter } = require('./platforms/github-simple');
const { RedditBrowserAdapter } = require('./platforms/reddit-browser');
const { RedditPuppeteerAdapter } = require('./platforms/reddit-puppeteer');
const { RedditCDPAdapter } = require('./platforms/reddit-cdp');
const { TwitterAPIAdapter } = require('./platforms/twitter-api');
const JiqizhixinWechatAdapter = require('./platforms/jiqizhixin-wechat');
const { Scorer, FeedbackHandler, PersonalizedScoringEngine } = require('./scorers');
const Translator = require('./translator');
const NotificationManager = require('./notifications');
const EmailScheduler = require('./email-scheduler');
const AutoTranslator = require('./auto-translator');

// 加载环境变量
require('dotenv').config();

// 确保数据目录存在
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// 初始化
const storage = new Storage(process.env.DB_PATH || path.join(dataDir, 'hotspots.db'));
const scorer = new Scorer(storage);
const personalizedEngine = new PersonalizedScoringEngine(storage);
const feedbackHandler = new FeedbackHandler(storage);
const translator = new Translator(
  process.env.OPENROUTER_API_KEY,
  'https://openrouter.ai/api/v1'
);
const notificationManager = new NotificationManager(storage);
const emailScheduler = new EmailScheduler(storage);

// 平台配置（移除 LinkedIn，避免违反 robots.txt）
// 新增 Agent Browser 适配器用于 token-efficient 抓取
const useAgentBrowser = process.env.USE_AGENT_BROWSER === 'true';

const platforms = {
  // Twitter/X - 使用官方 API 适配器
  twitter: new TwitterAPIAdapter({ bearerToken: process.env.TWITTER_BEARER_TOKEN }),
  weibo: useAgentBrowser 
    ? new WeiboAgentBrowserAdapter({}) 
    : new WeiboAdapter({ weiboRss: 'https://rsshub.app/weibo' }),
  
  // 新增 Agent Browser 平台 (v3.0)
  zhihu: new ZhihuAgentBrowserAdapter({}),
  github: new GitHubSimpleAdapter({}),
  '36kr': new SanliuKrAgentBrowserAdapter({}),
  geekpark: new GeekParkAgentBrowserAdapter({}),
  ifanr: new iFanrAgentBrowserAdapter({}),
  bilibili: new BilibiliAgentBrowserAdapter({}),
  jiqizhixin: new JiqizhixinWechatAdapter({}),
  
  // 原有适配器
  reddit: new RedditCDPAdapter({}),
  hackernews: new HackerNewsAdapter(),
  producthunt: new ProductHuntAdapter(),
  xiaohongshu: new XiaohongshuAdapter({ rsshubUrl: 'https://rsshub.app' }),
  jike: new JikeAdapter(),
  juejin: new juejinAdapter({ rsshubUrl: 'https://rsshub.app' }),
  v2ex: new V2EXAdapter(),
  chinaai: new ChinaAIAdapter({ bearerToken: process.env.TWITTER_BEARER_TOKEN })
};

// 监控账号列表（优化：减少Twitter账号数量，控制API额度）
const watchedAccounts = {
  // X/Twitter - AI行业大佬和KOL
  twitter: [
    // OpenAI & Anthropic
    'sama',              // Sam Altman - OpenAI CEO
    'gdb',               // Greg Brockman - OpenAI Co-founder
    'miramurati',        // Mira Murati - OpenAI CTO
    'woj_zaremba',       // Wojciech Zaremba - OpenAI Co-founder
    'DarioAmodei',       // Dario Amodei - Anthropic CEO
    'DanielaAmodei',     // Daniela Amodei - Anthropic President
    
    // DeepLearning & Research Leaders
    'AndrewYNg',         // Andrew Ng - DeepLearning.AI
    'ylecun',            // Yann LeCun - Meta AI Chief Scientist
    'karpathy',          // Andrej Karpathy - ex-OpenAI, Tesla
    'goodfellow_ian',    // Ian Goodfellow - GAN之父
    'NandoDF',           // Nando de Freitas - DeepMind
    'JeffDean',          // Jeff Dean - Google AI Lead
    'fchollet',          // François Chollet - Keras作者
    'hardmaru',          // David Ha - Google Brain
    'DrJimFan',          // Jim Fan - NVIDIA
    'bindureddy',        // Bindu Reddy - Abacus.AI CEO
    'EMostaque',         // Emad Mostaque - Stability AI创始人
    
    // AI Companies & Labs
    'OpenAI',            // OpenAI官方
    'AnthropicAI',       // Anthropic官方
    'DeepMind',          // DeepMind官方
    'GoogleAI',          // Google AI官方
    'MetaAI',            // Meta AI官方
    'StanfordHAI',       // Stanford HAI
    'huggingface',       // Hugging Face
    'lmsysorg',          // LMSYS Org
    'LangChainAI',       // LangChain
    'llama_index',       // LlamaIndex
    'weaviate_io',       // Weaviate
    'pinecone',          // Pinecone
    'chroma',            // Chroma
    
    // AI Researchers & Engineers
    'jeremyphoward',     // Jeremy Howard - fast.ai
    'RichardSocher',     // Richard Socher - You.com
    'ClementDelangue',   // Clément Delangue - Hugging Face CEO
    'alexjc',            // Alex J. Champandard - AI研究员
    'swyx',              // Shawn Wang - AI工程师
    'simonw',            // Simon Willison - Datasette
    'paulg',             // Paul Graham - YC
    'naval',             // Naval Ravikant - 投资人
    'elonmusk',          // Elon Musk - xAI
    
    // AI News & Media
    'AI_News_News',      // AI News
    'TheSequenceAI',     // The Sequence
    'AITopics',          // AI Topics
    'AI__Newsletter',    // AI Newsletter
    
    // v3.0 新增: 具身智能/机器人
    'UnitreeRobotics',   // Unitree Robotics - 宇树科技
    'Figure_robot',      // Figure AI - 人形机器人
    'BostonDynamics',    // Boston Dynamics
    'tesla_optimus',     // Tesla Optimus
    '1x_Tech',           // 1X Technologies
    
    // v3.0 新增: 投资/行业观察者
    'paulg',             // Paul Graham - YC 创始人
    'pmarca',            // Marc Andreessen - a16z
    'eladgil',           // Elad Gil - 天使投资人
    
    // v3.0 新增: 中国 AI 公司
    'AlibabaCloud',      // 阿里云
    'BaiduResearch',     // 百度研究院
    'realByteDance',     // 字节跳动
    'DeepSeek_AI'        // DeepSeek
  ],
  
  // GitHub - 监控AI组织和关键开发者
  github: [
    'openai',            // OpenAI
    'anthropics',        // Anthropic
    'google',            // Google
    'google-research',   // Google Research
    'deepmind',          // DeepMind
    'meta-llama',        // Meta LLaMA
    'facebookresearch',  // Meta Research
    'microsoft',         // Microsoft
    'huggingface',       // Hugging Face
    'langchain-ai',      // LangChain
    'run-llama',         // LlamaIndex
    'chroma-core',       // Chroma
    'weaviate',          // Weaviate
    'pinecone-io',       // Pinecone
    'qdrant',            // Qdrant
    'milvus-io',         // Milvus
    'autonomous-ai',     // AutoGPT
    'significant-gravitas', // AutoGPT组织
    'continuedev',       // Continue.dev
    'cursor',            // Cursor
    'sourcegraph',       // Cody
    'tabbyml',           // Tabby
    'withcatai',         // CAI
    'mlc-ai',            // MLC AI
    'vllm-project',      // vLLM
    'ollama',            // Ollama
    'janhq',             // Jan
    'lmstudio',          // LM Studio
    'sindresorhus',      // 知名开发者
    'microsoft/semantic-kernel', // Microsoft Semantic Kernel
    'Azure-Samples'      // Azure Samples
  ],
  
  reddit: ['artificial', 'MachineLearning', 'LocalLLaMA', 'singularity', 'OpenAI', 'ChatGPT', 'ClaudeAI'],
  hackernews: [], // 不需要账号，抓取全站热门
  weibo: ['1689123456'],
  xiaohongshu: ['5c9aed5910d9b82734b17806'],
  juejin: ['1647951553076334'],
  v2ex: [],
  zhihu: [], // 知乎通过话题抓取
  bilibili: ['415407', '327280337', '25876945', '481434238'],
  geekpark: [], // 极客公园通过话题抓取
  ifanr: [], // 爱范儿通过话题抓取
  chinaai: ['sama', 'ylecun', 'karpathy', 'DrJimFan', 'bindureddy', 'EMostaque']
};

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// API 路由

// 获取热点列表
app.get('/api/hotspots', (req, res) => {
  try {
    const { platform, limit = 50, offset = 0, sort = 'crawled_at', order = 'desc', minScore } = req.query;
    const hotspots = storage.getHotspots({
      platform,
      limit: parseInt(limit),
      offset: parseInt(offset),
      sortBy: sort === 'score' ? 'avg_score' : 'h.crawled_at',
      sortOrder: order.toUpperCase(),
      minScore: minScore ? parseFloat(minScore) : null
    });
    res.json(hotspots);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取热点详情
// 个性化推荐 API（放在 /:id 之前）
app.get('/api/hotspots/personalized', (req, res) => {
  try {
    const { user_id, limit = 50 } = req.query;
    const hotspots = storage.getHotspots({ limit: parseInt(limit) });
    
    // 使用个性化引擎重新排序
    const personalized = personalizedEngine.batchCalculatePersonalized(
      hotspots,
      user_id || 'user_anonymous'
    );
    
    res.json(personalized);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取用户偏好摘要
app.get('/api/user/preferences', (req, res) => {
  try {
    const summary = personalizedEngine.getUserPreferenceSummary();
    res.json(summary);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 刷新用户偏好（在提交反馈后调用）
app.post('/api/user/preferences/refresh', (req, res) => {
  try {
    personalizedEngine.loadUserPreferences();
    const summary = personalizedEngine.getUserPreferenceSummary();
    res.json({ success: true, preferences: summary });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 手动翻译单个热点
app.post('/api/translate/single', async (req, res) => {
  try {
    const { hotspot_id } = req.body;
    
    if (!hotspot_id) {
      return res.status(400).json({ error: 'Missing hotspot_id' });
    }
    
    // 获取热点
    const hotspot = storage.getHotspotById(hotspot_id);
    if (!hotspot) {
      return res.status(404).json({ error: 'Hotspot not found' });
    }
    
    console.log(`[Translate] Translating hotspot: ${hotspot_id}`);
    
    // 翻译标题
    let title_zh = '';
    if (hotspot.title && !isChineseText(hotspot.title)) {
      try {
        title_zh = await translator.translateToChinese(hotspot.title, 200);
        console.log(`[Translate] Title: "${hotspot.title.substring(0, 50)}..." -> "${title_zh.substring(0, 50)}..."`);
      } catch (err) {
        console.error('[Translate] Title translation failed:', err.message);
      }
    }
    
    // 翻译内容
    let content_zh = '';
    if (hotspot.content && !isChineseText(hotspot.content)) {
      try {
        content_zh = await translator.translateToChinese(hotspot.content, 1000);
      } catch (err) {
        console.error('[Translate] Content translation failed:', err.message);
      }
    }
    
    // 更新数据库
    const updates = {};
    if (title_zh) updates.title_zh = title_zh;
    if (content_zh) updates.content_zh = content_zh;
    
    if (Object.keys(updates).length > 0) {
      storage.updateHotspot(hotspot_id, updates);
      console.log(`[Translate] Saved translation for ${hotspot_id}`);
    }
    
    res.json({
      success: true,
      hotspot_id,
      title_zh: title_zh || hotspot.title_zh || null,
      content_zh: content_zh || hotspot.content_zh || null
    });
    
  } catch (err) {
    console.error('[Translate] API error:', err);
    res.status(500).json({ error: err.message });
  }
});

// 辅助函数：检测中文文本
function isChineseText(text) {
  if (!text) return false;
  return /[\u4e00-\u9fa5]/.test(text);
}

app.get('/api/hotspots/:id', (req, res) => {
  try {
    const hotspot = storage.getHotspotById(req.params.id);
    if (!hotspot) {
      return res.status(404).json({ error: 'Not found' });
    }
    res.json(hotspot);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 提交人类反馈
app.post('/api/feedback', (req, res) => {
  try {
    const { hotspot_id, user_id, action, rating, comment } = req.body;
    if (!hotspot_id || !user_id || !action) {
      return res.status(400).json({ error: 'Missing required fields' });
    }
    
    // 保存反馈
    const feedback = feedbackHandler.submitFeedback({
      hotspot_id,
      user_id,
      action,
      rating: rating ? parseInt(rating) : null,
      comment
    });
    
    // 更新基础分数
    feedbackHandler.updateScoreFromFeedback(hotspot_id);
    
    // 重新加载用户偏好（使新反馈立即生效）
    personalizedEngine.loadUserPreferences();
    
    // 获取热点并计算新的个性化分数
    const hotspot = storage.getHotspotById(hotspot_id);
    let personalizedScore = null;
    if (hotspot) {
      personalizedScore = personalizedEngine.calculatePersonalizedScore(hotspot, user_id);
      
      // 保存个性化分数到数据库（用于持久化排名）
      storage.updateHotspot(hotspot_id, {
        avg_score: personalizedScore.score,
        personalization_bonus: personalizedScore.personalizationBonus,
        feedback_description: personalizedScore.feedbackDescription
      });
    }
    
    res.json({
      ...feedback,
      personalizedScore,
      message: '反馈已提交，排名已更新'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 手动触发抓取（带进度）
app.post('/api/crawl', async (req, res) => {
  try {
    const { platforms: targetPlatforms, async: isAsync } = req.body;
    const targetList = targetPlatforms || Object.keys(platforms);
    
    // 异步模式：立即返回，后台执行
    if (isAsync) {
      res.json({ status: 'started', platforms: targetList, message: 'Crawling in background' });
      
      // 后台执行抓取
      setImmediate(async () => {
        const progress = { total: targetList.length, current: 0, platform: '', results: [] };
        
        for (const name of targetList) {
          progress.current++;
          progress.platform = name;
          console.log(`[Async Crawl] ${progress.current}/${progress.total}: ${name}`);
          
          try {
            const adapter = platforms[name];
            if (!adapter) continue;
            const accounts = watchedAccounts[name] || [];
            const hotspots = await adapter.fetchHotspots(accounts);
            
            let savedCount = 0;
            for (const h of hotspots) {
              try {
                storage.saveHotspot(h);
                savedCount++;
                if (h.score && h.score > 0) {
                  storage.saveScore({
                    hotspot_id: h.id,
                    source: 'platform',
                    score: h.score,
                    factors: { platform: name, raw_score: h.score }
                  });
                }
              } catch (e) {
                console.error(`Failed to save: ${e.message}`);
              }
            }
            
            // 异步翻译
            if (hotspots.length > 0) {
              translator.translateHotspots(hotspots).then(translated => {
                for (const h of translated) {
                  if (h.is_translated) {
                    storage.updateHotspot(h.id, { title_zh: h.title_zh, content_zh: h.content_zh });
                  }
                }
              }).catch(e => console.error('Translation error:', e.message));
            }
            
            progress.results.push({ platform: name, count: hotspots.length, saved: savedCount });
          } catch (err) {
            console.error(`[Async Crawl Error] ${name}:`, err.message);
            progress.results.push({ platform: name, count: 0, error: err.message });
          }
        }
        
        console.log('[Async Crawl] Completed:', progress.results);
      });
      
      return;
    }
    
    // 同步模式（带进度）
    const progress = { total: targetList.length, current: 0, platform: '', results: [] };
    
    // 发送初始进度
    res.writeHead(200, {
      'Content-Type': 'application/json',
      'Transfer-Encoding': 'chunked'
    });
    
    for (const name of targetList) {
      progress.current++;
      progress.platform = name;
      console.log(`[Crawl Progress] ${progress.current}/${progress.total}: ${name}`);
      
      try {
        const adapter = platforms[name];
        if (!adapter) continue;
        const accounts = watchedAccounts[name] || [];
        const hotspots = await adapter.fetchHotspots(accounts);
        
        // 保存并翻译
        let savedCount = 0;
        for (const h of hotspots) {
          try {
            storage.saveHotspot(h);
            savedCount++;
            
            // 保存评分（如果热点有 score 字段）
            if (h.score && h.score > 0) {
              storage.saveScore({
                hotspot_id: h.id,
                source: 'platform',
                score: h.score,
                factors: { platform: name, raw_score: h.score }
              });
            }
          } catch (e) {
            console.error(`Failed to save: ${e.message}`);
          }
        }
        
        // 自动翻译
        if (hotspots.length > 0) {
          try {
            const translated = await translator.translateHotspots(hotspots);
            for (const h of translated) {
              if (h.is_translated) {
                storage.updateHotspot(h.id, { title_zh: h.title_zh, content_zh: h.content_zh });
              }
            }
          } catch (e) {
            console.error('Translation error:', e.message);
          }
        }
        
        progress.results.push({ platform: name, count: hotspots.length, saved: savedCount });
        
        // 发送进度更新
        res.write(JSON.stringify({ progress, done: false }) + '\n');
      } catch (err) {
        console.error(`[Crawl Error] ${name}:`, err.message);
        progress.results.push({ platform: name, count: 0, error: err.message });
        res.write(JSON.stringify({ progress, done: false }) + '\n');
      }
    }
    
    // 最终响应
    res.write(JSON.stringify({ progress, done: true, total: progress.results.reduce((a, r) => a + r.count, 0) }));
    res.end();
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取统计
app.get('/api/stats', (req, res) => {
  try {
    const stats = storage.getStats();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 抓取逻辑（带同步刷新和删除）
async function crawlPlatforms(platformNames) {
  const allHotspots = [];
  const crawledPlatformIds = new Map(); // 记录每个平台抓取到的热点ID
  
  for (const name of platformNames) {
    const adapter = platforms[name];
    if (!adapter) {
      console.warn(`Platform ${name} not configured, skipping`);
      continue;
    }
    const accounts = watchedAccounts[name] || [];
    console.log(`Crawling ${name} with ${accounts.length} accounts...`);
    try {
      const hotspots = await adapter.fetchHotspots(accounts);
      const platformIds = new Set();
      let savedCount = 0;
      let updatedCount = 0;
      
      for (const h of hotspots) {
        try {
          // 检查是否已存在
          const existing = storage.getHotspotById(h.id);
          if (existing) {
            updatedCount++;
            // 合并数据：保留现有评分，更新互动数据
            h.avg_score = existing.avg_score;
          }
          
          storage.saveHotspot(h);
          savedCount++;
          platformIds.add(h.id);
          
          // 检查是否需要发送通知
          if (h.score >= 70) {
            notificationManager.checkAndNotify(h).catch(err => {
              console.error('Notification error:', err.message);
            });
          }
        } catch (saveErr) {
          console.error(`    Failed to save hotspot from ${name}:`, saveErr.message);
        }
      }
      
      crawledPlatformIds.set(name, platformIds);
      allHotspots.push(...hotspots);
      console.log(`  -> ${hotspots.length} items (new: ${savedCount - updatedCount}, updated: ${updatedCount}) from ${name}`);
    } catch (err) {
      console.error(`  -> Error crawling ${name}:`, err.message);
    }
  }
  
  // 同步删除：删除平台上已不存在的热点
  await syncDeletedHotspots(crawledPlatformIds);
  
  return allHotspots;
}

// 同步删除已不存在的热点
async function syncDeletedHotspots(crawledPlatformIds) {
  console.log('[Sync] Checking for deleted hotspots...');
  let deletedCount = 0;
  
  for (const [platformName, crawledIds] of crawledPlatformIds) {
    try {
      // 获取该平台数据库中的所有热点ID
      const dbHotspots = storage.getHotspots({ platform: platformName, limit: 10000 });
      const dbIds = new Set(dbHotspots.map(h => h.id));
      
      // 找出已删除的热点
      for (const dbId of dbIds) {
        if (!crawledIds.has(dbId)) {
          // 检查是否超过24小时（避免误删临时缺失的数据）
          const hotspot = dbHotspots.find(h => h.id === dbId);
          const ageHours = (Date.now() - new Date(hotspot.crawled_at).getTime()) / (1000 * 60 * 60);
          
          if (ageHours > 24) {
            storage.deleteHotspot(dbId);
            console.log(`  [Sync] Deleted: ${dbId} (not found on ${platformName}, age: ${ageHours.toFixed(1)}h)`);
            deletedCount++;
          }
        }
      }
    } catch (err) {
      console.error(`[Sync] Error syncing ${platformName}:`, err.message);
    }
  }
  
  if (deletedCount > 0) {
    console.log(`[Sync] Total deleted: ${deletedCount} hotspots`);
  }
}

// 定时任务（每6小时抓取一次，控制API额度消耗）
cron.schedule('0 */6 * * *', async () => {
  console.log('Running scheduled crawl...');
  try {
    const hotspots = await crawlPlatforms(Object.keys(platforms));
    if (hotspots.length > 0) {
      try {
        await scorer.batchScore(hotspots);
        console.log(`Scheduled crawl complete: ${hotspots.length} new items`);
      } catch (scoreErr) {
        console.error('Scoring failed in scheduled crawl:', scoreErr.message);
      }
    } else {
      console.log('Scheduled crawl: no new hotspots');
    }
  } catch (err) {
    console.error('Scheduled crawl failed:', err.message);
  }
});

// 定时评分更新任务（每30分钟更新所有热点评分，实现时间衰减）
cron.schedule('*/30 * * * *', async () => {
  console.log('Running scheduled score update with decay...');
  try {
    const allHotspots = storage.getHotspots({ limit: 10000 });
    if (allHotspots.length > 0) {
      // 使用新的衰减引擎重新计算所有热点评分
      const scoredHotspots = scorer.decayEngine.batchCalculate(allHotspots);
      
      // 更新数据库中的评分
      let updatedCount = 0;
      for (const item of scoredHotspots) {
        try {
          storage.updateHotspot(item.id, { 
            avg_score: item.score,
            score_breakdown: JSON.stringify(item.breakdown)
          });
          updatedCount++;
        } catch (err) {
          console.error(`[ScoreUpdate] Failed to update ${item.id}:`, err.message);
        }
      }
      
      console.log(`[ScoreUpdate] Updated ${updatedCount}/${allHotspots.length} hotspots with decay algorithm`);
    }
  } catch (err) {
    console.error('[ScoreUpdate] Scheduled score update failed:', err.message);
  }
});

// 初始化时立即抓取一次（带错误隔离和自动翻译）
setTimeout(async () => {
  console.log('Initial crawl on startup...');
  try {
    const hotspots = await crawlPlatforms(Object.keys(platforms));
    console.log(`Fetched ${hotspots.length} hotspots from all platforms`);
    
    if (hotspots.length > 0) {
      // 自动翻译为中文
      console.log('Translating hotspots to Chinese...');
      try {
        const translated = await translator.translateHotspots(hotspots);
        // 更新存储的翻译内容
        for (const h of translated) {
          if (h.is_translated) {
            storage.updateHotspot(h.id, { title_zh: h.title_zh, content_zh: h.content_zh });
          }
        }
        console.log(`Translated ${translated.filter(h => h.is_translated).length}/${hotspots.length} hotspots`);
      } catch (transErr) {
        console.error('Translation failed:', transErr.message);
      }
      
      try {
        const scores = await scorer.batchScore(hotspots);
        console.log(`Initial crawl complete: ${hotspots.length} items, ${scores.length} scored`);
      } catch (scoreErr) {
        console.error('Scoring failed, but continuing:', scoreErr.message);
        console.log('Initial crawl complete (without scoring):', hotspots.length, 'items');
      }
    } else {
      console.log('No hotspots fetched, will retry on schedule');
    }
  } catch (err) {
    console.error('Initial crawl failed:', err);
    console.log('Server will continue running, next crawl in 6 hours');
  }
}, 5000);

// ==================== 通知 API ====================

// 获取通知设置
app.get('/api/notifications/settings', (req, res) => {
  try {
    const settings = notificationManager.getSettings();
    res.json(settings);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 更新通知设置
app.post('/api/notifications/settings', (req, res) => {
  try {
    const settings = req.body;
    notificationManager.updateSettings(settings);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取未读通知
app.get('/api/notifications', (req, res) => {
  try {
    const { limit = 20 } = req.query;
    const notifications = notificationManager.getUnreadNotifications(parseInt(limit));
    res.json(notifications);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 标记通知为已读
app.post('/api/notifications/:id/read', (req, res) => {
  try {
    notificationManager.markAsRead(req.params.id);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// SSE 端点 - 实时推送通知
app.get('/api/notifications/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');

  // 发送初始连接成功消息
  res.write('data: {"type": "connected"}\n\n');

  // 定期检查新通知
  const interval = setInterval(() => {
    const pending = storage.getPendingNotifications();
    if (pending.length > 0) {
      pending.forEach(notification => {
        res.write(`data: ${JSON.stringify({ type: 'notification', data: notification })}\n\n`);
      });
    }
  }, 3000);

  // 客户端断开时清理
  req.on('close', () => {
    clearInterval(interval);
  });
});

// 手动测试通知
app.post('/api/notifications/test', async (req, res) => {
  try {
    const { hotspot_id } = req.body;
    const hotspot = storage.getHotspotById(hotspot_id);
    if (!hotspot) {
      return res.status(404).json({ error: 'Hotspot not found' });
    }
    const sent = await notificationManager.checkAndNotify(hotspot);
    res.json({ success: sent, message: sent ? 'Notification sent' : 'Notification not sent (may be below threshold or already notified)' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== 邮件订阅 API ====================

// 获取邮件订阅列表
app.get('/api/email/subscriptions', async (req, res) => {
  try {
    const subscriptions = await emailScheduler.getSubscriptions();
    res.json(subscriptions);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 添加邮件订阅
app.post('/api/email/subscribe', async (req, res) => {
  try {
    const { email, scheduleType = 'daily', scheduleTime = '09:00' } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    const result = await emailScheduler.addSubscription(email, { scheduleType, scheduleTime });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 取消邮件订阅
app.post('/api/email/unsubscribe', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    const result = await emailScheduler.removeSubscription(email);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== 自动翻译 API ====================

// 获取翻译统计
app.get('/api/translation/stats', (req, res) => {
  try {
    const stats = storage.db.prepare(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN title_zh IS NOT NULL AND title_zh != '' THEN 1 END) as translated,
        COUNT(CASE WHEN title_zh IS NULL OR title_zh = '' THEN 1 END) as pending
      FROM hotspots
    `).get();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 手动触发批量翻译
app.post('/api/translation/run', async (req, res) => {
  try {
    const { limit = 10 } = req.body;
    const autoTranslator = new AutoTranslator(storage, { batchSize: limit });
    
    // 异步运行翻译
    autoTranslator.run().then(() => {
      console.log('[API] Manual translation completed');
    });
    
    res.json({ 
      success: true, 
      message: `Translation started for ${limit} hotspots`,
      status: 'running'
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 测试翻译质量
app.post('/api/translation/test', async (req, res) => {
  try {
    const { text } = req.body;
    if (!text) {
      return res.status(400).json({ error: 'Text is required' });
    }
    
    const result = await translator.translateToChinese(text, 500, { returnQuality: true });
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 提交翻译反馈
app.post('/api/translation/feedback', (req, res) => {
  try {
    const { hotspot_id, rating, comment, suggested_translation } = req.body;
    
    if (!hotspot_id || !rating) {
      return res.status(400).json({ error: 'hotspot_id and rating are required' });
    }
    
    // 保存反馈到数据库
    const stmt = storage.db.prepare(`
      INSERT INTO translation_feedback (hotspot_id, rating, comment, suggested_translation, created_at)
      VALUES (?, ?, ?, ?, datetime('now'))
    `);
    stmt.run(hotspot_id, rating, comment || '', suggested_translation || '');
    
    // 如果用户提供了更好的翻译，更新热点
    if (suggested_translation && rating >= 4) {
      storage.updateHotspot(hotspot_id, { title_zh: suggested_translation });
    }
    
    res.json({ success: true, message: 'Feedback recorded' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取翻译反馈统计
app.get('/api/translation/feedback-stats', (req, res) => {
  try {
    const stats = storage.db.prepare(`
      SELECT 
        COUNT(*) as total_feedback,
        AVG(rating) as avg_rating,
        COUNT(CASE WHEN rating >= 4 THEN 1 END) as high_quality,
        COUNT(CASE WHEN rating = 3 THEN 1 END) as medium_quality,
        COUNT(CASE WHEN rating <= 2 THEN 1 END) as low_quality
      FROM translation_feedback
    `).get();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== 数据清理 API ====================

// 获取过期热点统计
app.get('/api/cleanup/stats', (req, res) => {
  try {
    const { days = 7 } = req.query;
    const expiredCount = storage.getExpiredHotspotsCount(parseInt(days));
    const totalCount = storage.db.prepare('SELECT COUNT(*) as cnt FROM hotspots').get().cnt;
    
    res.json({
      total_hotspots: totalCount,
      expired_hotspots: expiredCount,
      retention_days: parseInt(days),
      will_delete: expiredCount
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 手动执行清理（需要管理员权限）
app.post('/api/cleanup/run', (req, res) => {
  try {
    const { days = 7, dry_run = false } = req.body;
    
    const expiredCount = storage.getExpiredHotspotsCount(parseInt(days));
    
    if (expiredCount === 0) {
      return res.json({
        success: true,
        message: 'No expired hotspots to delete',
        deleted: 0,
        retention_days: parseInt(days)
      });
    }
    
    if (dry_run) {
      return res.json({
        success: true,
        message: `Would delete ${expiredCount} hotspots (dry run)`,
        would_delete: expiredCount,
        retention_days: parseInt(days)
      });
    }
    
    const deleted = storage.deleteExpiredHotspots(parseInt(days));
    
    res.json({
      success: true,
      message: `Deleted ${deleted} expired hotspots`,
      deleted: deleted,
      retention_days: parseInt(days)
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== 收藏 API ====================

// 获取收藏列表
app.get('/api/favorites', (req, res) => {
  try {
    const { user_id = 'anonymous' } = req.query;
    const favorites = storage.getFavorites(user_id);
    res.json(favorites);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 添加收藏
app.post('/api/favorites', (req, res) => {
  try {
    const { hotspot_id, user_id = 'anonymous' } = req.body;
    
    if (!hotspot_id) {
      return res.status(400).json({ error: 'hotspot_id is required' });
    }
    
    // 获取热点信息
    const hotspot = storage.getHotspotById(hotspot_id);
    if (!hotspot) {
      return res.status(404).json({ error: 'Hotspot not found' });
    }
    
    storage.addFavorite(hotspot_id, user_id, hotspot);
    res.json({ success: true, message: 'Added to favorites' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 取消收藏
app.delete('/api/favorites/:hotspot_id', (req, res) => {
  try {
    const { hotspot_id } = req.params;
    const { user_id = 'anonymous' } = req.query;
    
    storage.removeFavorite(hotspot_id, user_id);
    res.json({ success: true, message: 'Removed from favorites' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 检查是否已收藏
app.get('/api/favorites/check/:hotspot_id', (req, res) => {
  try {
    const { hotspot_id } = req.params;
    const { user_id = 'anonymous' } = req.query;
    
    const isFavorited = storage.isFavorited(hotspot_id, user_id);
    res.json({ is_favorited: isFavorited });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ==================== 翻译质量分析 API ====================

const TranslationAnalytics = require('./translation-analytics');
const translationAnalytics = new TranslationAnalytics(storage);

// 获取翻译质量趋势
app.get('/api/translation/trend', (req, res) => {
  try {
    const { days = 7 } = req.query;
    const trend = translationAnalytics.getQualityTrend(parseInt(days));
    res.json(trend);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取需要改进的翻译
app.get('/api/translation/need-improvement', (req, res) => {
  try {
    const { limit = 10 } = req.query;
    const items = translationAnalytics.getTranslationsNeedImprovement(parseInt(limit));
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取平台翻译质量对比
app.get('/api/translation/platform-quality', (req, res) => {
  try {
    const stats = translationAnalytics.getPlatformQuality();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 生成翻译质量报告
app.get('/api/translation/report', (req, res) => {
  try {
    const report = translationAnalytics.generateReport();
    res.json(report);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 自动改进翻译
app.post('/api/translation/auto-improve', async (req, res) => {
  try {
    const { limit = 5 } = req.body;
    const improved = await translationAnalytics.autoImproveTranslations(translator, parseInt(limit));
    res.json({
      success: true,
      improved_count: improved.length,
      improved
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 发送测试邮件
app.post('/api/email/test', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      return res.status(400).json({ error: 'Email is required' });
    }
    const result = await emailScheduler.sendTest(email);
    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 初始化邮件调度器
emailScheduler.init().catch(err => {
  console.error('Failed to initialize email scheduler:', err);
});

// WebSocket 广播函数
function broadcast(message) {
  if (global.wss) {
    global.wss.clients.forEach(client => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(JSON.stringify(message));
      }
    });
  }
}

// 导出广播函数供其他模块使用
global.broadcastHotspot = (hotspot) => {
  broadcast({ type: 'new_hotspot', data: hotspot });
};

global.broadcastHighScore = (hotspot) => {
  broadcast({ type: 'high_score_alert', data: hotspot });
};

global.broadcastCrawlProgress = (progress) => {
  broadcast({ type: 'crawl_progress', data: progress });
};

global.broadcastCrawlComplete = (result) => {
  broadcast({ type: 'crawl_complete', data: result });
};

// 启动服务器
const PORT = process.env.PORT || 3000;
const server = http.createServer(app);

// 创建 WebSocket 服务器
const wss = new WebSocket.Server({ server, path: '/ws' });
global.wss = wss;

wss.on('connection', (ws) => {
  console.log('[WebSocket] Client connected');
  
  // 发送欢迎消息
  ws.send(JSON.stringify({ type: 'connected', message: 'Welcome to Hotspot Radar' }));
  
  // 心跳检测
  const pingInterval = setInterval(() => {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify({ type: 'ping' }));
    }
  }, 30000);
  
  ws.on('message', (message) => {
    try {
      const data = JSON.parse(message);
      console.log('[WebSocket] Received:', data.type);
      
      if (data.type === 'pong') {
        // 客户端响应心跳
      }
    } catch (err) {
      console.error('[WebSocket] Invalid message:', err);
    }
  });
  
  ws.on('close', () => {
    console.log('[WebSocket] Client disconnected');
    clearInterval(pingInterval);
  });
  
  ws.on('error', (err) => {
    console.error('[WebSocket] Error:', err);
  });
});

server.listen(PORT, () => {
  console.log(`Hotspot Crawler Server running on http://localhost:${PORT}`);
  console.log(`WebSocket available at ws://localhost:${PORT}/ws`);
  console.log(`Pixel Art UI available at http://localhost:${PORT}/index.html`);
  
  // 启动自动翻译服务（优化配置）
  const autoTranslator = new AutoTranslator(storage, {
    batchSize: 50,      // 每次翻译 50 条
    intervalHours: 2,   // 每 2 小时运行一次
    delayMs: 200        // 200ms 延迟
  });
  autoTranslator.start();
  
  // 启动定时清理任务 - 每天凌晨3点删除7天前的旧热点
  const CLEANUP_HOUR = 3;
  const CLEANUP_MINUTE = 0;
  const RETENTION_DAYS = 7;
  
  setInterval(() => {
    const now = new Date();
    if (now.getHours() === CLEANUP_HOUR && now.getMinutes() === CLEANUP_MINUTE) {
      console.log(`[Cleanup] Starting daily cleanup (retention: ${RETENTION_DAYS} days)`);
      const deleted = storage.deleteExpiredHotspots(RETENTION_DAYS);
      console.log(`[Cleanup] Deleted ${deleted} expired hotspots`);
    }
  }, 60000); // 每分钟检查一次
  
  // 启动时显示当前过期热点数量
  const expiredCount = storage.getExpiredHotspotsCount(RETENTION_DAYS);
  if (expiredCount > 0) {
    console.log(`[Cleanup] Found ${expiredCount} hotspots older than ${RETENTION_DAYS} days`);
  }
});

// ==================== 翻译异常监控 API ====================

// 获取翻译异常列表
app.get('/api/translation-anomalies', (req, res) => {
  try {
    const { severity, status, limit, offset } = req.query;
    const anomalies = storage.getTranslationAnomalies({
      severity,
      status,
      limit: parseInt(limit) || 50,
      offset: parseInt(offset) || 0
    });
    res.json(anomalies);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 获取翻译异常统计
app.get('/api/translation-anomalies/stats', (req, res) => {
  try {
    const stats = storage.getTranslationAnomalyStats();
    res.json(stats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 手动触发扫描
app.post('/api/translation-anomalies/scan', async (req, res) => {
  try {
    const { scanAndFixAnomalies } = require('./scripts/scan-translation-anomalies');
    await scanAndFixAnomalies();
    res.json({ success: true, message: 'Scan completed' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 修复翻译异常
app.post('/api/translation-anomalies/:id/fix', (req, res) => {
  try {
    const result = storage.fixTranslationAnomaly(req.params.id);
    res.json({ success: true, changes: result.changes });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});