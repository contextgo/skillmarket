/**
 * 个性化评分引擎
 * 根据用户喜好反馈调整热点排序
 * 
 * 核心逻辑：
 * - 手动评分低 → 降权显示
 * - 选择不喜欢 → 降权显示
 * - 评论表达不匹配 → 降权显示
 * - 标签不匹配 → 降权显示
 * - 相反情况 → 提升排名
 */

const { DecayScoringEngine } = require('./decay-engine');

class PersonalizedScoringEngine extends DecayScoringEngine {
  constructor(storage, config = {}) {
    super(config);
    this.storage = storage;
    
    // 用户直接反馈权重（强信号）
    this.directFeedbackWeights = {
      like: 1.5,        // 喜欢 - 提升50%
      interested: 1.3,  // 感兴趣 - 提升30%
      useful: 1.4,      // 有用 - 提升40%
      dislike: 0.3,     // 不喜欢 - 降权70%（强降权）
      irrelevant: 0.4,  // 不相关 - 降权60%
      spam: 0.2,        // 垃圾内容 - 降权80%
      comment: 1.0      // 中性评论
    };
    
    // 评分映射（1-5星）
    this.ratingWeights = {
      1: 0.4,   // 1星 - 降权60%
      2: 0.6,   // 2星 - 降权40%
      3: 1.0,   // 3星 - 中性
      4: 1.3,   // 4星 - 提升30%
      5: 1.5    // 5星 - 提升50%
    };
    
    // 标签偏好
    this.tagPreferences = new Map();
    
    // 平台偏好
    this.platformPreferences = new Map();
    
    // 作者偏好
    this.authorPreferences = new Map();
    
    // 负面关键词（用于评论语义分析）
    this.negativeKeywords = [
      '不感兴趣', '没兴趣', '无聊', '垃圾', '没用', '无关', '不相关',
      '不喜欢', '讨厌', '反感', '失望', '差', '烂', '水', '骗',
      'uninterested', 'boring', 'useless', 'irrelevant', 'spam',
      'dislike', 'hate', 'bad', 'waste', 'disappointed'
    ];
    
    // 正面关键词
    this.positiveKeywords = [
      '喜欢', '感兴趣', '有用', '有帮助', '不错', '好', '棒', '优秀',
      '需要', '想要', '关注', '期待', 'like', 'useful', 'helpful',
      'good', 'great', 'excellent', 'love', 'want', 'need'
    ];
    
    // 加载用户偏好
    this.loadUserPreferences();
  }
  
  /**
   * 加载用户偏好数据
   */
  loadUserPreferences() {
    try {
      // 从 feedback 表加载用户反馈
      const feedbacks = this.storage.db.prepare(`
        SELECT hotspot_id, action, rating, comment, created_at
        FROM feedback
        WHERE user_id LIKE 'user_%'
        ORDER BY created_at DESC
      `).all();
      
      for (const fb of feedbacks) {
        this.updatePreferenceFromFeedback(fb);
      }
      
      console.log(`[PersonalizedEngine] Loaded ${feedbacks.length} user preferences`);
    } catch (err) {
      console.error('[PersonalizedEngine] Failed to load preferences:', err.message);
    }
  }
  
  /**
   * 从反馈更新偏好
   */
  updatePreferenceFromFeedback(feedback) {
    const { hotspot_id, action, rating, comment } = feedback;
    
    // 获取热点信息
    const hotspot = this.storage.getHotspotById(hotspot_id);
    if (!hotspot) return;
    
    // 分析评论情感
    const sentiment = this.analyzeSentiment(comment);
    
    // 计算综合权重
    let weight = this.directFeedbackWeights[action] || 1.0;
    
    // 如果有评分，结合评分权重
    if (rating) {
      const ratingWeight = this.ratingWeights[rating] || 1.0;
      weight = (weight + ratingWeight) / 2; // 平均权重
    }
    
    // 结合评论情感
    if (sentiment === 'negative') {
      weight *= 0.7; // 负面评论额外降权
    } else if (sentiment === 'positive') {
      weight *= 1.2; // 正面评论额外提升
    }
    
    // 更新平台偏好
    const platformWeight = this.platformPreferences.get(hotspot.platform) || 1.0;
    this.platformPreferences.set(
      hotspot.platform,
      platformWeight * 0.8 + weight * 0.2
    );
    
    // 更新作者偏好
    if (hotspot.author) {
      const authorWeight = this.authorPreferences.get(hotspot.author) || 1.0;
      this.authorPreferences.set(
        hotspot.author,
        authorWeight * 0.8 + weight * 0.2
      );
    }
    
    // 从评论中提取标签偏好
    if (comment) {
      const tags = this.extractTags(comment);
      for (const tag of tags) {
        const tagWeight = this.tagPreferences.get(tag) || 1.0;
        // 根据情感调整标签权重
        const tagMultiplier = sentiment === 'negative' ? 0.5 : 
                             sentiment === 'positive' ? 1.5 : 1.0;
        this.tagPreferences.set(
          tag,
          tagWeight * 0.8 + weight * tagMultiplier * 0.2
        );
      }
    }
  }
  
  /**
   * 分析评论情感
   */
  analyzeSentiment(comment) {
    if (!comment) return 'neutral';
    
    const lowerComment = comment.toLowerCase();
    let negativeScore = 0;
    let positiveScore = 0;
    
    for (const keyword of this.negativeKeywords) {
      if (lowerComment.includes(keyword.toLowerCase())) {
        negativeScore++;
      }
    }
    
    for (const keyword of this.positiveKeywords) {
      if (lowerComment.includes(keyword.toLowerCase())) {
        positiveScore++;
      }
    }
    
    if (negativeScore > positiveScore) return 'negative';
    if (positiveScore > negativeScore) return 'positive';
    return 'neutral';
  }
  
  /**
   * 从评论提取标签
   */
  extractTags(comment) {
    const tags = [];
    
    // 提取显式标签（格式：标签: xxx 或 #xxx）
    const tagMatch = comment.match(/标签[:：]\s*([^\n]+)/);
    if (tagMatch) {
      const tagList = tagMatch[1].split(/[,，]/).map(t => t.trim()).filter(Boolean);
      tags.push(...tagList);
    }
    
    // 提取关键词
    const keywords = [
      'AI工具', '开源项目', '教程', '论文', '产品发布',
      '技术讨论', '行业新闻', '投资', '创业公司',
      '大模型', 'LLM', 'Agent', 'RAG', '多模态'
    ];
    
    for (const keyword of keywords) {
      if (comment.toLowerCase().includes(keyword.toLowerCase())) {
        tags.push(keyword);
      }
    }
    
    return [...new Set(tags)]; // 去重
  }
  
  /**
   * 计算个性化评分
   */
  calculatePersonalizedScore(hotspot, userId = null) {
    // 基础衰减评分
    const baseScore = this.calculateScore(hotspot);
    const breakdown = this.getScoreBreakdown(hotspot);
    
    // 获取用户对此热点的直接反馈
    const directFeedback = this.getDirectFeedback(hotspot.id, userId);
    
    // 个性化加成
    let personalizationBonus = 1.0;
    let feedbackDescription = '无反馈';
    
    // 1. 直接反馈影响（最强信号）
    if (directFeedback) {
      const { action, rating, comment, sentiment } = directFeedback;
      
      // 基础动作权重
      let actionWeight = this.directFeedbackWeights[action] || 1.0;
      
      // 评分权重
      if (rating) {
        const ratingWeight = this.ratingWeights[rating] || 1.0;
        // 低评分强降权，高评分强提升
        actionWeight = actionWeight * 0.3 + ratingWeight * 0.7;
      }
      
      // 评论情感调整
      if (sentiment === 'negative') {
        actionWeight *= 0.6; // 负面评论强降权
        feedbackDescription = '负面反馈';
      } else if (sentiment === 'positive') {
        actionWeight *= 1.3; // 正面评论强提升
        feedbackDescription = '正面反馈';
      } else {
        feedbackDescription = action;
      }
      
      personalizationBonus *= actionWeight;
      
      // 标签不匹配检测
      if (comment) {
        const userPreferredTags = Array.from(this.tagPreferences.entries())
          .filter(([tag, weight]) => weight > 1.2)
          .map(([tag]) => tag);
        
        const contentTags = this.extractContentTags(hotspot);
        const hasMatchingTag = userPreferredTags.some(tag => contentTags.includes(tag));
        
        if (userPreferredTags.length > 0 && !hasMatchingTag) {
          // 用户有明确偏好，但内容不匹配 - 降权
          personalizationBonus *= 0.8;
          feedbackDescription += ' (标签不匹配)';
        }
      }
    } else {
      // 2. 间接偏好影响（无直接反馈时）
      
      // 平台偏好加成
      const platformPref = this.platformPreferences.get(hotspot.platform) || 1.0;
      personalizationBonus *= (1 + (platformPref - 1) * 0.5);
      
      // 作者偏好加成
      if (hotspot.author) {
        const authorPref = this.authorPreferences.get(hotspot.author) || 1.0;
        personalizationBonus *= (1 + (authorPref - 1) * 0.3);
      }
      
      // 内容标签匹配加成
      const contentTags = this.extractContentTags(hotspot);
      let tagMatchScore = 0;
      for (const tag of contentTags) {
        const tagPref = this.tagPreferences.get(tag);
        if (tagPref) {
          tagMatchScore += (tagPref - 1) * 0.3;
        }
      }
      personalizationBonus *= (1 + Math.min(tagMatchScore, 0.6));
    }
    
    // 限制加成范围（0.2 - 2.0）
    personalizationBonus = Math.max(0.2, Math.min(2.0, personalizationBonus));
    
    // 最终个性化评分
    const personalizedScore = Math.round(baseScore * personalizationBonus);
    
    return {
      score: this.clamp(personalizedScore, 0, 100),
      baseScore,
      personalizationBonus: Math.round(personalizationBonus * 100) / 100,
      feedbackDescription,
      directFeedback,
      breakdown: {
        ...breakdown,
        platformPreference: Math.round((this.platformPreferences.get(hotspot.platform) || 1.0) * 100) / 100,
        authorPreference: hotspot.author ? Math.round((this.authorPreferences.get(hotspot.author) || 1.0) * 100) / 100 : 1.0,
        personalizationBonus: Math.round(personalizationBonus * 100) / 100
      }
    };
  }
  
  /**
   * 获取用户对热点的直接反馈
   */
  getDirectFeedback(hotspotId, userId) {
    try {
      const feedback = this.storage.db.prepare(`
        SELECT action, rating, comment, created_at
        FROM feedback
        WHERE hotspot_id = ? AND user_id = ?
        ORDER BY created_at DESC
        LIMIT 1
      `).get(hotspotId, userId || 'user_anonymous');
      
      if (!feedback) return null;
      
      return {
        ...feedback,
        sentiment: this.analyzeSentiment(feedback.comment)
      };
    } catch (err) {
      return null;
    }
  }
  
  /**
   * 从热点内容提取标签
   */
  extractContentTags(hotspot) {
    const tags = [];
    const text = `${hotspot.title} ${hotspot.content || ''}`.toLowerCase();
    
    const tagKeywords = {
      'AI工具': ['tool', '工具', 'utility', 'plugin', 'extension'],
      '开源项目': ['open source', 'github', '开源', '仓库'],
      '教程': ['tutorial', 'guide', 'how to', '教程', '指南'],
      '论文': ['paper', 'research', 'arxiv', '论文', '研究'],
      '产品发布': ['launch', 'release', 'product', '发布', '新品'],
      '技术讨论': ['discussion', ' debate', '技术讨论'],
      '行业新闻': ['news', 'announced', '新闻', '资讯'],
      '大模型': ['llm', 'gpt', 'claude', 'gemini', '大模型', '大语言模型'],
      'Agent': ['agent', 'bot', 'autonomous', '智能体'],
      'RAG': ['rag', 'retrieval', '向量', 'embedding'],
      '多模态': ['multimodal', 'vision', 'image', '多模态', '视觉']
    };
    
    for (const [tag, keywords] of Object.entries(tagKeywords)) {
      if (keywords.some(kw => text.includes(kw.toLowerCase()))) {
        tags.push(tag);
      }
    }
    
    return tags;
  }
  
  /**
   * 批量计算个性化评分
   */
  batchCalculatePersonalized(hotspots, userId = null) {
    const scored = hotspots.map(h => ({
      ...h,
      ...this.calculatePersonalizedScore(h, userId)
    }));
    
    // 按个性化评分排序
    return scored.sort((a, b) => b.score - a.score);
  }
  
  /**
   * 获取用户偏好摘要
   */
  getUserPreferenceSummary() {
    const summary = {
      platforms: Object.fromEntries(this.platformPreferences),
      authors: Object.fromEntries(this.authorPreferences),
      tags: Object.fromEntries(this.tagPreferences),
      feedbackStats: { like: 0, dislike: 0, interested: 0, useful: 0 }
    };
    
    // 统计反馈数量
    try {
      const stats = this.storage.db.prepare(`
        SELECT action, COUNT(*) as count
        FROM feedback
        WHERE user_id LIKE 'user_%'
        GROUP BY action
      `).all();
      
      for (const row of stats) {
        summary.feedbackStats[row.action] = row.count;
      }
    } catch (err) {
      console.error('[PersonalizedEngine] Failed to get feedback stats:', err.message);
    }
    
    return summary;
  }
  
  /**
   * 限制值范围
   */
  clamp(value, min, max) {
    return Math.min(max, Math.max(min, value));
  }
}

module.exports = { PersonalizedScoringEngine };
