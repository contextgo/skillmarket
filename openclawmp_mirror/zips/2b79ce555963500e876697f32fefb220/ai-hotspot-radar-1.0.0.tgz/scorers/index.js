const Storage = require('../storage');
const { DecayScoringEngine } = require('./decay-engine');

class Scorer {
  constructor(storage) {
    this.storage = storage;
    // 初始化新的评分衰减引擎
    this.decayEngine = new DecayScoringEngine();
  }

  // AI 自动评分（使用新的衰减算法）
  computeAIScore(hotspot) {
    // 使用新的 DecayScoringEngine 计算评分
    const score = this.decayEngine.calculateScore(hotspot);
    const breakdown = this.decayEngine.getScoreBreakdown(hotspot);
    
    return {
      score,
      factors: breakdown
    };
  }
  
  // 获取评分详细分解
  getScoreBreakdown(hotspot) {
    return this.decayEngine.getScoreBreakdown(hotspot);
  }

  // 批量评分并存储
  async batchScore(hotspots) {
    const scores = [];
    for (const hotspot of hotspots) {
      try {
        const { score, factors } = await this.computeAIScore(hotspot);
        const aiScore = {
          id: `ai_${hotspot.id}_${Date.now()}`,
          hotspot_id: hotspot.id,
          source: 'ai',
          score,
          factors,
          created_at: new Date().toISOString()
        };
        scores.push(aiScore);
        this.storage.saveScore(aiScore);
      } catch (err) {
        console.error(`[Scorer] Failed to score hotspot ${hotspot.id}:`, err.message);
        // 继续处理下一条，不中断
      }
    }
    return scores;
  }

  // 根据人类反馈调整AI分数（迭代优化）
  async refineScoresWithFeedback() {
    // 统计人类评分与AI评分的差异，调整因子权重
    // 这里简化：直接使用人类反馈的平均分与AI分做加权
    const allScores = this.storage.db.prepare(`
      SELECT h.id, 
             AVG(CASE WHEN s.source = 'ai' THEN s.score ELSE NULL END) as ai_score,
             AVG(CASE WHEN s.source = 'human' THEN s.score ELSE NULL END) as human_score
      FROM hotspots h
      LEFT JOIN scores s ON h.id = s.hotspot_id
      GROUP BY h.id
      HAVING ai_score IS NOT NULL
    `).all();

    // 计算调整系数：如果人类评分普遍高于AI，则提高权重
    let totalDiff = 0;
    let count = 0;
    for (const row of allScores) {
      if (row.human_score) {
        totalDiff += row.human_score - row.ai_score;
        count++;
      }
    }

    const adjustment = count > 0 ? totalDiff / count : 0;
    return { adjustment, samples: count };
  }
}

// 人类反馈处理
class FeedbackHandler {
  constructor(storage) {
    this.storage = storage;
  }

  // 提交反馈
  submitFeedback(feedback) {
    return this.storage.saveFeedback(feedback);
  }

  // 获取热点的人类反馈统计
  getFeedbackStats(hotspotId) {
    const stats = this.storage.db.prepare(`
      SELECT 
        COUNT(*) as count,
        AVG(rating) as avg_rating,
        COUNT(CASE WHEN action = 'like' THEN 1 END) as likes,
        COUNT(CASE WHEN action = 'dislike' THEN 1 END) as dislikes
      FROM feedback
      WHERE hotspot_id = ?
    `).get(hotspotId);
    return stats;
  }

  // 根据反馈更新分数
  updateScoreFromFeedback(hotspotId) {
    try {
      const stats = this.getFeedbackStats(hotspotId);
      if (!stats.avg_rating) return null;

      // 将1-5星评分转换为0-100分
      const humanScore = stats.avg_rating * 20;

      const score = {
        id: `human_${hotspotId}_${Date.now()}`,
        hotspot_id: hotspotId,
        source: 'human',
        score: humanScore,
        factors: { rating: stats.avg_rating, count: stats.count },
        created_at: new Date().toISOString()
      };

      this.storage.saveScore(score);
      return score;
    } catch (err) {
      console.error(`[FeedbackHandler] Failed to update score for hotspot ${hotspotId}:`, err.message);
      return null;
    }
  }
}

const { PersonalizedScoringEngine } = require('./personalized-engine');

module.exports = { Scorer, FeedbackHandler, PersonalizedScoringEngine };