/**
 * AI Hotspot Radar - 热点评分衰减算法引擎
 * @version 3.0.0 - 增强版
 * 
 * 核心公式: S(t) = [I_base × W_platform × A_source + C_cross] × D(t) × V_viral × T_trend
 * 
 * 新增特性:
 * - 趋势速度计算 (Trend Velocity)
 * - 来源权威性分级 (Source Authority Levels)
 * - 增强的实体权重体系
 */

class DecayScoringEngine {
  constructor(config = {}) {
    // 可覆盖的默认配置
    this.config = {
      // 互动权重
      interactionWeights: {
        likes: 1.0,
        comments: 3.0,
        shares: 5.0,
        fire: 8.0,
        saves: 2.5,
        views: 0.5,
        stars: 2.0,
        forks: 1.5,
        upvotes: 1.2,
        ...config.interactionWeights
      },
      
      // 平台基础配置 - 新增来源权威性分级
      platforms: {
        // Tier 1: 顶级技术社区 (权威性最高)
        hackernews: { 
          baseWeight: 1.3, 
          credibility: 0.98, 
          recencyBoost: 1.2, 
          category: 'tech',
          authorityLevel: 5,  // 1-5 级，5为最高
          authorityBonus: 1.15
        },
        github: { 
          baseWeight: 1.2, 
          credibility: 0.95, 
          recencyBoost: 1.1, 
          category: 'tech',
          authorityLevel: 5,
          authorityBonus: 1.15
        },
        lobsters: { 
          baseWeight: 1.25, 
          credibility: 0.95, 
          recencyBoost: 1.15, 
          category: 'tech',
          authorityLevel: 5,
          authorityBonus: 1.15
        },
        
        // Tier 2: 产品/社交平台
        producthunt: { 
          baseWeight: 1.15, 
          credibility: 0.92, 
          recencyBoost: 1.1, 
          category: 'product',
          authorityLevel: 4,
          authorityBonus: 1.1
        },
        reddit: { 
          baseWeight: 1.1, 
          credibility: 0.90, 
          recencyBoost: 1.0, 
          category: 'social',
          authorityLevel: 3,
          authorityBonus: 1.05
        },
        twitter: { 
          baseWeight: 1.0, 
          credibility: 0.95, 
          recencyBoost: 1.0, 
          category: 'social',
          authorityLevel: 4,
          authorityBonus: 1.1
        },
        
        // Tier 3: 国内技术社区
        zhihu: { 
          baseWeight: 0.9, 
          credibility: 0.85, 
          recencyBoost: 0.9, 
          category: 'content',
          authorityLevel: 3,
          authorityBonus: 1.05
        },
        juejin: { 
          baseWeight: 0.85, 
          credibility: 0.82, 
          recencyBoost: 0.9, 
          category: 'tech',
          authorityLevel: 3,
          authorityBonus: 1.05
        },
        v2ex: { 
          baseWeight: 0.8, 
          credibility: 0.85, 
          recencyBoost: 0.9, 
          category: 'tech',
          authorityLevel: 3,
          authorityBonus: 1.05
        },
        
        // Tier 4: 国内科技媒体
        '36kr': { 
          baseWeight: 0.85, 
          credibility: 0.80, 
          recencyBoost: 0.9, 
          category: 'news',
          authorityLevel: 3,
          authorityBonus: 1.05
        },
        jiqizhixin: { 
          baseWeight: 0.9, 
          credibility: 0.88, 
          recencyBoost: 0.9, 
          category: 'news',
          authorityLevel: 4,
          authorityBonus: 1.1
        },
        geekpark: { 
          baseWeight: 0.85, 
          credibility: 0.82, 
          recencyBoost: 0.9, 
          category: 'news',
          authorityLevel: 3,
          authorityBonus: 1.05
        },
        ifanr: { 
          baseWeight: 0.85, 
          credibility: 0.82, 
          recencyBoost: 0.9, 
          category: 'news',
          authorityLevel: 3,
          authorityBonus: 1.05
        },
        
        // Tier 5: 社交媒体/视频平台
        weibo: { 
          baseWeight: 0.85, 
          credibility: 0.80, 
          recencyBoost: 1.0, 
          category: 'social',
          authorityLevel: 2,
          authorityBonus: 1.0
        },
        bilibili: { 
          baseWeight: 0.8, 
          credibility: 0.78, 
          recencyBoost: 0.9, 
          category: 'video',
          authorityLevel: 2,
          authorityBonus: 1.0
        },
        xiaohongshu: { 
          baseWeight: 0.75, 
          credibility: 0.75, 
          recencyBoost: 0.9, 
          category: 'social',
          authorityLevel: 2,
          authorityBonus: 1.0
        },
        
        ...config.platforms
      },
      
      // 多平台加成参数
      crossPlatform: {
        alpha: 0.3,
        beta: 0.5,
        maxBonus: 1.6,
        ...config.crossPlatform
      },
      
      // 病毒传播参数
      viral: {
        kappa: 0.5,
        g50: 0.1, // 10%/小时
        ...config.viral
      },
      
      // 趋势速度参数 - 新增
      trendVelocity: {
        // 增长速度阈值 (%/小时)
        thresholds: {
          explosive: 0.5,   // >50%/小时 - 爆发式增长
          rapid: 0.2,       // >20%/小时 - 快速增长
          steady: 0.05,     // >5%/小时 - 稳定增长
          slow: 0.01        // >1%/小时 - 缓慢增长
        },
        // 趋势速度权重
        weights: {
          explosive: 1.3,   // 爆发式 +30%
          rapid: 1.15,      // 快速 +15%
          steady: 1.05,     // 稳定 +5%
          slow: 1.0,        // 缓慢 无加成
          flat: 0.95        // 停滞 -5%
        },
        // 计算窗口（小时）
        windowHours: 3,
        ...config.trendVelocity
      },
      
      // 评分范围
      scoreRange: {
        min: 0,
        max: 100,
        ...config.scoreRange
      },
      
      // 归一化中位数参考值
      normalizationMedians: {
        likes: 100,
        comments: 20,
        shares: 10,
        fire: 5,
        saves: 15,
        views: 1000,
        stars: 50,
        forks: 20,
        upvotes: 30,
        ...config.normalizationMedians
      },
      
      // 实体权重配置（按优先级）- 扩展版
      entityWeights: {
        // Tier 1: LLM 大厂（最高优先级）
        'openai': 1.5, 'anthropic': 1.5, 'google': 1.5, 'deepmind': 1.5,
        'meta': 1.5, 'llama': 1.5, 'xai': 1.5, 'grok': 1.5,
        'microsoft': 1.5, 'azure': 1.5, 'amazon': 1.5, 'aws': 1.5,
        'nvidia': 1.5, 'huggingface': 1.5,
        
        // Tier 2: 具身智能/终端设备（次优先级）
        'unitree': 1.3, '宇树': 1.3, 'figure': 1.3, 'boston dynamics': 1.3,
        'tesla': 1.3, 'optimus': 1.3, 'robot': 1.2, '机器人': 1.2,
        'embodied': 1.3, '具身智能': 1.3, '人形机器人': 1.3,
        
        // Tier 3: 中国 AI 头部公司
        '智谱': 1.25, 'chatglm': 1.25, 'glm-4': 1.25,
        '文心一言': 1.25, 'ernie': 1.25, '百度 ai': 1.25,
        '通义千问': 1.25, 'qwen': 1.25, '阿里 ai': 1.25,
        'kimi': 1.25, '月之暗面': 1.25, 'moonshot': 1.25,
        'deepseek': 1.25, 'deepseek-v2': 1.25,
        '阶跃星辰': 1.25, 'stepfun': 1.25,
        'minimax': 1.2, '商汤': 1.2, 'sensetime': 1.2,
        '百川': 1.2, 'baichuan': 1.2,
        '零一万物': 1.2, '01.ai': 1.2,
        
        // Tier 4: 政策创新（第四优先级）
        'policy': 1.1, 'regulation': 1.1, '标准': 1.1, '政策': 1.1,
        'insurance': 1.1, '保险': 1.1, 'iso': 1.1, '国标': 1.1,
        'ai act': 1.1, 'ai governance': 1.1, 'ai safety': 1.1,
        
        // Tier 5: 热门工具/框架
        'langchain': 1.15, 'llamaindex': 1.15, 'crewai': 1.15,
        'cursor': 1.15, 'copilot': 1.15, 'codeium': 1.15,
        'midjourney': 1.15, 'stable diffusion': 1.15, 'dall-e': 1.15,
        'sora': 1.15, 'runway': 1.15,
        
        ...config.entityWeights
      },
      
      // 权威账号配置 - 新增
      authorityAccounts: {
        // Tier 1: 顶级研究者/创始人 (最高权威性)
        tier1: [
          'sama', 'karpathy', 'ylecun', 'AndrewYNg', 'goodfellow_ian',
          'fchollet', 'jeremyphoward', 'DrJimFan', 'hardmaru', 'EMostaque'
        ],
        // Tier 2: 官方机构账号
        tier2: [
          'OpenAI', 'AnthropicAI', 'GoogleAI', 'DeepMind', 'MetaAI',
          'xai', 'Azure', 'AWS', 'NVIDIA', 'huggingface'
        ],
        // Tier 3: 具身智能/机器人公司
        tier3: [
          'UnitreeRobotics', 'Figure_robot', 'BostonDynamics', 'tesla_optimus'
        ],
        // 权威性权重
        weights: { tier1: 1.2, tier2: 1.15, tier3: 1.1 }
      }
    };
  }

  /**
   * 计算热点综合评分
   * @param {Object} hotspot - 热点数据
   * @returns {number} 最终评分 (0-100)
   */
  calculateScore(hotspot) {
    let { 
      metrics = {}, 
      platform,
      platforms = [],
      published_at,
      crawled_at,
      interactionHistory = [],
      author_id,
      author
    } = hotspot;

    // 解析 metrics（如果是字符串）
    if (typeof metrics === 'string') {
      try {
        metrics = JSON.parse(metrics);
      } catch (e) {
        metrics = {};
      }
    }

    // 1. 计算基础互动分数
    const baseInteraction = this.calculateBaseInteraction(metrics);
    
    // 2. 计算平台权重（包含来源权威性）
    const platformWeight = this.calculatePlatformWeight(platform || platforms);
    
    // 3. 计算来源权威性加成 - 新增
    const authorityBonus = this.calculateAuthorityBonus(platform, author_id || author);
    
    // 4. 计算多平台交叉验证加成
    const crossPlatformBonus = this.calculateCrossPlatformBonus(platforms);
    
    // 5. 计算时间衰减因子
    const ageHours = this.calculateAgeHours(published_at || crawled_at);
    const decayFactor = this.calculateDecayFactor(ageHours);
    
    // 6. 计算病毒传播系数
    const viralFactor = this.calculateViralFactor(interactionHistory, metrics);
    
    // 7. 计算趋势速度因子 - 新增
    const trendVelocityFactor = this.calculateTrendVelocity(interactionHistory, ageHours);
    
    // 8. 计算实体权重加成
    const entityWeight = this.calculateEntityWeight(hotspot);
    
    // 9. 综合计算
    // 调整公式: [I_base × W_platform × A_source + C_cross] × D(t) × V_viral × T_trend
    const rawScore = (baseInteraction * platformWeight * authorityBonus + crossPlatformBonus) 
                     * decayFactor 
                     * viralFactor
                     * trendVelocityFactor  // 趋势速度加成
                     * entityWeight
                     * 10; // 放大系数
    
    // 10. 归一化到目标范围
    return this.clamp(Math.round(rawScore), this.config.scoreRange.min, this.config.scoreRange.max);
  }

  /**
   * 获取评分详细分解 - 增强版
   */
  getScoreBreakdown(hotspot) {
    let { 
      metrics = {}, 
      platform, 
      platforms = [], 
      published_at, 
      crawled_at, 
      interactionHistory = [],
      author_id,
      author
    } = hotspot;
    
    // 解析 metrics（如果是字符串）
    if (typeof metrics === 'string') {
      try {
        metrics = JSON.parse(metrics);
      } catch (e) {
        metrics = {};
      }
    }
    
    const ageHours = this.calculateAgeHours(published_at || crawled_at);
    const trendInfo = this.getTrendVelocityInfo(interactionHistory, ageHours);
    
    return {
      baseInteraction: this.calculateBaseInteraction(metrics),
      platformWeight: this.calculatePlatformWeight(platform || platforms),
      authorityBonus: this.calculateAuthorityBonus(platform, author_id || author),
      crossPlatformBonus: this.calculateCrossPlatformBonus(platforms),
      decayFactor: this.calculateDecayFactor(ageHours),
      viralFactor: this.calculateViralFactor(interactionHistory, metrics),
      trendVelocityFactor: trendInfo.factor,
      trendVelocityLevel: trendInfo.level,
      trendGrowthRate: trendInfo.growthRate,
      ageHours: Math.round(ageHours * 10) / 10,
      entityWeight: this.calculateEntityWeight(hotspot)
    };
  }

  /**
   * 基础互动分数计算
   */
  calculateBaseInteraction(metrics) {
    const { interactionWeights, normalizationMedians } = this.config;
    
    // 映射不同平台的字段到统一格式
    const normalizedMetrics = this.normalizeMetrics(metrics);
    
    let score = 0;
    for (const [type, count] of Object.entries(normalizedMetrics)) {
      if (interactionWeights[type] && normalizationMedians[type] && count > 0) {
        const normalized = this.smoothNormalize(count, normalizationMedians[type]);
        score += interactionWeights[type] * normalized;
      }
    }
    
    return score;
  }

  /**
   * 标准化不同平台的指标字段
   */
  normalizeMetrics(metrics) {
    // 优先使用 engagement 作为综合互动指标
    const engagement = metrics.engagement || 0;
    
    return {
      likes: metrics.likes || metrics.points || (engagement > 0 ? engagement * 0.5 : 0),
      comments: metrics.comments || metrics.num_comments || metrics.replies || 0,
      shares: metrics.shares || metrics.retweets || 0,
      fire: metrics.fire || metrics.hot || 0,
      saves: metrics.saves || metrics.bookmarks || 0,
      views: metrics.views || metrics.impressions || (engagement > 0 ? engagement * 10 : 0),
      stars: metrics.stars || metrics.todayStars || 0,
      forks: metrics.forks || 0,
      upvotes: metrics.upvotes || metrics.score || 0
    };
  }

  /**
   * 平滑归一化: x / (x + x50)
   */
  smoothNormalize(value, median) {
    if (!median || median <= 0) return 0;
    return value / (value + median);
  }

  /**
   * 计算平台权重（包含来源权威性分级）
   */
  calculatePlatformWeight(platform) {
    if (!platform) return 1.0;
    
    // 处理数组或字符串
    let platformId = Array.isArray(platform) ? platform[0] : platform;
    if (typeof platformId === 'object' && platformId.id) {
      platformId = platformId.id;
    }
    
    const config = this.config.platforms[platformId];
    if (!config) return 1.0;
    
    // 基础权重 × 可信度 × 时效性加成 × 权威性加成
    return config.baseWeight * config.credibility * config.recencyBoost * (config.authorityBonus || 1.0);
  }

  /**
   * 计算来源权威性加成 - 新增
   * @param {string} platform - 平台
   * @param {string} author - 作者/账号
   * @returns {number} 权威性加成系数
   */
  calculateAuthorityBonus(platform, author) {
    if (!author) return 1.0;
    
    const authorLower = author.toLowerCase();
    const { authorityAccounts } = this.config;
    
    // 检查是否在权威账号列表中
    for (const [tier, accounts] of Object.entries(authorityAccounts)) {
      if (tier === 'weights') continue;
      
      const isMatch = accounts.some(acc => 
        authorLower === acc.toLowerCase() || 
        authorLower.includes(acc.toLowerCase())
      );
      
      if (isMatch) {
        const weight = authorityAccounts.weights[tier] || 1.0;
        console.log(`[Authority] Matched ${tier} account: ${author} => ${weight}x`);
        return weight;
      }
    }
    
    return 1.0;
  }

  /**
   * 计算趋势速度因子 - 新增
   * @param {Array} interactionHistory - 互动历史
   * @param {number} ageHours - 内容年龄（小时）
   * @returns {number} 趋势速度因子
   */
  calculateTrendVelocity(interactionHistory, ageHours) {
    const trendInfo = this.getTrendVelocityInfo(interactionHistory, ageHours);
    return trendInfo.factor;
  }

  /**
   * 获取趋势速度信息 - 新增
   * @param {Array} interactionHistory - 互动历史
   * @param {number} ageHours - 内容年龄（小时）
   * @returns {Object} { factor, level, growthRate }
   */
  getTrendVelocityInfo(interactionHistory, ageHours) {
    const { trendVelocity } = this.config;
    
    // 如果没有历史数据或内容太新，返回默认值
    if (!interactionHistory || interactionHistory.length < 2 || ageHours < 0.5) {
      return { factor: 1.0, level: 'unknown', growthRate: 0 };
    }
    
    // 只使用最近窗口期的数据
    const windowHours = trendVelocity.windowHours;
    const cutoffTime = Date.now() - windowHours * 60 * 60 * 1000;
    const recentHistory = interactionHistory.filter(h => h.timestamp > cutoffTime);
    
    if (recentHistory.length < 2) {
      return { factor: 1.0, level: 'insufficient_data', growthRate: 0 };
    }
    
    // 计算平均增长率 (%/小时)
    let totalGrowthRate = 0;
    let validSamples = 0;
    
    for (let i = 1; i < recentHistory.length; i++) {
      const prev = recentHistory[i - 1].count || recentHistory[i - 1].total || 0;
      const curr = recentHistory[i].count || recentHistory[i].total || 0;
      const timeDiff = recentHistory[i].timestamp - recentHistory[i-1].timestamp;
      const hoursDiff = timeDiff / (1000 * 60 * 60);
      
      if (prev > 0 && hoursDiff > 0.1) { // 至少间隔6分钟
        const growthRate = ((curr - prev) / prev) / hoursDiff;
        totalGrowthRate += growthRate;
        validSamples++;
      }
    }
    
    if (validSamples === 0) {
      return { factor: 1.0, level: 'flat', growthRate: 0 };
    }
    
    const avgGrowthRate = totalGrowthRate / validSamples;
    
    // 确定趋势级别
    let level = 'flat';
    if (avgGrowthRate >= trendVelocity.thresholds.explosive) {
      level = 'explosive';
    } else if (avgGrowthRate >= trendVelocity.thresholds.rapid) {
      level = 'rapid';
    } else if (avgGrowthRate >= trendVelocity.thresholds.steady) {
      level = 'steady';
    } else if (avgGrowthRate >= trendVelocity.thresholds.slow) {
      level = 'slow';
    }
    
    // 如果是负增长，标记为 declining
    if (avgGrowthRate < 0) {
      level = 'declining';
    }
    
    const factor = trendVelocity.weights[level] || 1.0;
    
    return {
      factor,
      level,
      growthRate: Math.round(avgGrowthRate * 1000) / 1000 // 保留3位小数
    };
  }

  /**
   * 多平台交叉验证加成
   */
  calculateCrossPlatformBonus(platforms) {
    if (!platforms || platforms.length <= 1) return 1.0;
    
    const { alpha, beta, maxBonus } = this.config.crossPlatform;
    const n = platforms.length;
    
    // 计算平台多样性 (Simpson's Index)
    const categories = this.categorizePlatforms(platforms);
    const diversityScore = this.calculateDiversity(categories);
    
    const bonus = 1 + alpha * Math.log(1 + beta * n * diversityScore);
    return Math.min(bonus, maxBonus);
  }

  /**
   * 平台分类
   */
  categorizePlatforms(platforms) {
    const categories = {};
    
    for (const platform of platforms) {
      const id = typeof platform === 'string' ? platform : (platform.id || platform.platform);
      const config = this.config.platforms[id];
      const cat = config?.category || 'other';
      categories[cat] = (categories[cat] || 0) + 1;
    }
    
    return categories;
  }

  /**
   * 计算多样性指数 (Simpson's Diversity Index)
   */
  calculateDiversity(categories) {
    const total = Object.values(categories).reduce((a, b) => a + b, 0);
    if (total === 0) return 0;
    
    let sumSquared = 0;
    for (const count of Object.values(categories)) {
      const p = count / total;
      sumSquared += p * p;
    }
    
    return 1 - sumSquared;
  }

  /**
   * 计算热点年龄（小时）
   */
  calculateAgeHours(timestamp) {
    if (!timestamp) return 0;
    const published = new Date(timestamp);
    const now = new Date();
    return (now - published) / (1000 * 60 * 60);
  }

  /**
   * 时间衰减因子 - 双曲衰减 + 分段半衰期
   */
  calculateDecayFactor(ageHours) {
    // 定义衰减阶段
    const phases = [
      { threshold: 1, halfLife: 2, gamma: 1.5 },      // 0-1小时
      { threshold: 6, halfLife: 4, gamma: 1.2 },      // 1-6小时
      { threshold: 24, halfLife: 8, gamma: 1.0 },     // 6-24小时
      { threshold: 72, halfLife: 24, gamma: 0.8 },    // 1-3天
      { threshold: 168, halfLife: 48, gamma: 0.6 }    // 3-7天
    ];
    
    // 超过7天，返回最小保留值
    if (ageHours > 168) {
      return 0.1;
    }
    
    // 找到当前阶段
    let phase = phases[phases.length - 1];
    for (const p of phases) {
      if (ageHours < p.threshold) {
        phase = p;
        break;
      }
    }
    
    // 双曲衰减公式: 1 / (1 + (t/t_half)^gamma)
    return 1 / (1 + Math.pow(ageHours / phase.halfLife, phase.gamma));
  }

  /**
   * 病毒传播系数
   */
  calculateViralFactor(interactionHistory, currentMetrics) {
    if (!interactionHistory || interactionHistory.length < 2) {
      // 没有历史数据时，基于当前互动量估算
      const totalEngagement = Object.values(currentMetrics || {}).reduce((a, b) => a + (b || 0), 0);
      if (totalEngagement > 1000) return 1.15;
      if (totalEngagement > 500) return 1.1;
      return 1.0;
    }
    
    const { kappa, g50 } = this.config.viral;
    
    // 计算最近的增长率
    const recent = interactionHistory.slice(-3);
    let totalGrowthRate = 0;
    let validSamples = 0;
    
    for (let i = 1; i < recent.length; i++) {
      const prev = recent[i - 1].count || recent[i - 1].total || 0;
      const curr = recent[i].count || recent[i].total || 0;
      const timeDiff = recent[i].timestamp - recent[i-1].timestamp;
      const hoursDiff = timeDiff / (1000 * 60 * 60);
      
      if (prev > 0 && hoursDiff > 0) {
        const growthRate = ((curr - prev) / prev) / hoursDiff;
        if (growthRate > 0) {
          totalGrowthRate += growthRate;
          validSamples++;
        }
      }
    }
    
    if (validSamples === 0) return 1.0;
    
    const avgGrowthRate = totalGrowthRate / validSamples;
    
    // 病毒传播系数: 1 + kappa * (g / (g + g50))
    const viralBoost = kappa * (avgGrowthRate / (avgGrowthRate + g50));
    return 1 + viralBoost;
  }

  /**
   * 数值范围限制
   */
  clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
  }

  /**
   * 批量计算多个热点评分
   */
  batchCalculate(hotspots) {
    return hotspots.map(h => ({
      id: h.id,
      score: this.calculateScore(h),
      breakdown: this.getScoreBreakdown(h)
    })).sort((a, b) => b.score - a.score);
  }

  /**
   * 判断热点是否需要重新评分（基于更新策略）
   */
  shouldRecalculate(hotspot, lastCalculatedAt) {
    const ageHours = this.calculateAgeHours(hotspot.published_at || hotspot.crawled_at);
    const hoursSinceLastCalc = lastCalculatedAt 
      ? (Date.now() - new Date(lastCalculatedAt).getTime()) / (1000 * 60 * 60)
      : Infinity;
    
    // 根据热点年龄确定更新频率
    let recalcInterval;
    if (ageHours < 1) recalcInterval = 5/60;      // 5分钟
    else if (ageHours < 6) recalcInterval = 0.25;  // 15分钟
    else if (ageHours < 24) recalcInterval = 0.5;  // 30分钟
    else recalcInterval = 2;                        // 2小时
    
    return hoursSinceLastCalc >= recalcInterval;
  }

  /**
   * 计算实体权重加成
   * 优先级: LLM大厂(1.5x) > 中国AI(1.25x) > 具身智能(1.3x) > 热门工具(1.15x) > 政策创新(1.1x)
   * @param {Object} hotspot - 热点数据
   * @returns {number} 实体权重 (默认 1.0)
   */
  calculateEntityWeight(hotspot) {
    const { entityWeights } = this.config;
    const text = `${hotspot.title || ''} ${hotspot.content || ''}`.toLowerCase();
    
    let maxWeight = 1.0;
    const matchedEntities = [];
    
    // 检查每个实体关键词
    for (const [entity, weight] of Object.entries(entityWeights)) {
      if (text.includes(entity.toLowerCase())) {
        if (weight > maxWeight) {
          maxWeight = weight;
        }
        matchedEntities.push({ entity, weight });
      }
    }
    
    // 如果有多个实体匹配，记录日志
    if (matchedEntities.length > 0) {
      console.log(`[EntityWeight] Matched: ${matchedEntities.map(e => e.entity).join(', ')} => ${maxWeight}x`);
    }
    
    return maxWeight;
  }
  
  /**
   * 获取平台权威性等级 - 新增
   * @param {string} platform - 平台名称
   * @returns {Object} { level, name, description }
   */
  getPlatformAuthorityInfo(platform) {
    if (!platform) return { level: 0, name: 'unknown', description: '未知平台' };
    
    const config = this.config.platforms[platform];
    if (!config) return { level: 0, name: platform, description: '未配置平台' };
    
    const level = config.authorityLevel || 1;
    const descriptions = {
      5: '顶级技术社区 - 极高权威性',
      4: '知名平台/官方账号 - 高权威性',
      3: '专业社区/媒体 - 中等权威性',
      2: '社交媒体/视频平台 - 一般权威性',
      1: '其他平台 - 基础权威性'
    };
    
    return {
      level,
      name: platform,
      category: config.category,
      credibility: config.credibility,
      authorityBonus: config.authorityBonus,
      description: descriptions[level] || '未分级'
    };
  }
}

module.exports = { DecayScoringEngine };
