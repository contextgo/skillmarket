/**
 * 邮件调度模块 - 定时发送每日摘要
 */

const EmailService = require('./email-service');
const Storage = require('./storage');

class EmailScheduler {
  constructor(storage) {
    this.storage = storage;
    this.db = storage && storage.db ? storage.db : null;
    this.emailService = new EmailService();
    this.jobs = new Map();
  }

  // 初始化调度器
  async init() {
    console.log('[EmailScheduler] Initializing...');
    
    // 加载已保存的调度任务
    await this.loadSchedules();
    
    console.log('[EmailScheduler] Initialized');
  }

  // 加载保存的调度设置
  async loadSchedules() {
    if (!this.db) return;
    
    try {
      const stmt = this.db.prepare('SELECT * FROM email_schedules WHERE enabled = 1');
      const schedules = stmt.all();
      
      for (const schedule of schedules) {
        this.scheduleJob(schedule);
      }
      
      console.log(`[EmailScheduler] Loaded ${schedules.length} schedules`);
    } catch (err) {
      // 表可能不存在，创建表
      this.createTables();
    }
  }

  // 创建数据库表
  createTables() {
    if (!this.db) return;
    
    try {
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS email_schedules (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          email TEXT NOT NULL,
          schedule_type TEXT DEFAULT 'daily', -- daily, weekly
          schedule_time TEXT DEFAULT '09:00', -- HH:MM format
          enabled INTEGER DEFAULT 1,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
          last_sent_at DATETIME,
          send_count INTEGER DEFAULT 0
        )
      `);
      console.log('[EmailScheduler] Tables created');
    } catch (err) {
      console.error('[EmailScheduler] Failed to create tables:', err);
    }
  }

  // 添加邮件订阅
  async addSubscription(email, options = {}) {
    if (!this.db) return { success: false, error: 'Database not available' };
    
    const { scheduleType = 'daily', scheduleTime = '09:00' } = options;
    
    try {
      // 检查是否已存在
      const checkStmt = this.db.prepare('SELECT * FROM email_schedules WHERE email = ?');
      const existing = checkStmt.get(email);
      
      if (existing) {
        // 更新设置
        const updateStmt = this.db.prepare(
          `UPDATE email_schedules 
           SET schedule_type = ?, schedule_time = ?, enabled = 1
           WHERE email = ?`
        );
        updateStmt.run(scheduleType, scheduleTime, email);
        console.log('[EmailScheduler] Updated subscription:', email);
      } else {
        // 新建订阅
        const insertStmt = this.db.prepare(
          `INSERT INTO email_schedules (email, schedule_type, schedule_time, enabled)
           VALUES (?, ?, ?, 1)`
        );
        insertStmt.run(email, scheduleType, scheduleTime);
        console.log('[EmailScheduler] Added subscription:', email);
      }
      
      // 重新加载调度
      await this.loadSchedules();
      
      return { success: true };
    } catch (err) {
      console.error('[EmailScheduler] Failed to add subscription:', err);
      return { success: false, error: err.message };
    }
  }

  // 取消订阅
  async removeSubscription(email) {
    if (!this.db) return { success: false, error: 'Database not available' };
    
    try {
      const stmt = this.db.prepare('UPDATE email_schedules SET enabled = 0 WHERE email = ?');
      stmt.run(email);
      
      // 取消调度任务
      if (this.jobs.has(email)) {
        clearTimeout(this.jobs.get(email));
        this.jobs.delete(email);
      }
      
      console.log('[EmailScheduler] Removed subscription:', email);
      return { success: true };
    } catch (err) {
      console.error('[EmailScheduler] Failed to remove subscription:', err);
      return { success: false, error: err.message };
    }
  }

  // 调度任务
  scheduleJob(schedule) {
    // 取消现有任务
    if (this.jobs.has(schedule.email)) {
      clearTimeout(this.jobs.get(schedule.email));
    }
    
    // 计算下次执行时间
    const nextRun = this.calculateNextRun(schedule.schedule_time);
    const delay = nextRun - Date.now();
    
    console.log(`[EmailScheduler] Scheduled for ${schedule.email} at ${new Date(nextRun).toLocaleString()}`);
    
    // 设置定时器
    const timer = setTimeout(() => {
      this.sendDigest(schedule);
    }, delay);
    
    this.jobs.set(schedule.email, timer);
  }

  // 计算下次执行时间
  calculateNextRun(scheduleTime) {
    const [hours, minutes] = scheduleTime.split(':').map(Number);
    const now = new Date();
    const next = new Date();
    next.setHours(hours, minutes, 0, 0);
    
    // 如果今天时间已过，设为明天
    if (next <= now) {
      next.setDate(next.getDate() + 1);
    }
    
    return next.getTime();
  }

  // 发送摘要
  async sendDigest(schedule) {
    console.log(`[EmailScheduler] Sending digest to ${schedule.email}`);
    
    if (!this.storage) {
      console.error('[EmailScheduler] Storage not available');
      return;
    }
    
    try {
      // 获取热点数据 (24小时内)
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const hotspots = this.storage.getHotspots({ since, limit: 100 });
      const stats = this.storage.getStats();
      
      // 发送邮件
      const result = await this.emailService.sendDailyDigest(
        schedule.email,
        hotspots,
        stats
      );
      
      if (result.success) {
        // 更新发送记录
        const updateStmt = this.db.prepare(
          `UPDATE email_schedules 
           SET last_sent_at = CURRENT_TIMESTAMP, send_count = send_count + 1
           WHERE email = ?`
        );
        updateStmt.run(schedule.email);
        
        console.log(`[EmailScheduler] Digest sent to ${schedule.email}`);
      } else {
        console.error(`[EmailScheduler] Failed to send to ${schedule.email}:`, result.error);
      }
      
      // 重新调度下次发送
      this.scheduleJob(schedule);
      
    } catch (err) {
      console.error('[EmailScheduler] Error sending digest:', err);
      // 即使失败也重新调度
      this.scheduleJob(schedule);
    }
  }

  // 立即发送测试邮件
  async sendTest(email) {
    console.log(`[EmailScheduler] Sending test email to ${email}`);
    
    if (!this.storage) {
      return { success: false, error: 'Storage not available' };
    }
    
    try {
      // 获取热点数据 (24小时内)
      const since = new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString();
      const hotspots = this.storage.getHotspots({ since, limit: 100 });
      const stats = this.storage.getStats();
      
      const result = await this.emailService.sendDailyDigest(email, hotspots, stats);
      
      if (result.success) {
        console.log(`[EmailScheduler] Test email sent to ${email}`);
      } else {
        console.error(`[EmailScheduler] Test email failed:`, result.error);
      }
      
      return result;
    } catch (err) {
      console.error('[EmailScheduler] Test email error:', err);
      return { success: false, error: err.message };
    }
  }

  // 获取所有订阅
  async getSubscriptions() {
    if (!this.db) return [];
    
    try {
      const stmt = this.db.prepare('SELECT * FROM email_schedules ORDER BY created_at DESC');
      return stmt.all();
    } catch (err) {
      return [];
    }
  }

  // 停止所有调度
  stopAll() {
    for (const [email, timer] of this.jobs) {
      clearTimeout(timer);
    }
    this.jobs.clear();
    console.log('[EmailScheduler] All jobs stopped');
  }
}

module.exports = EmailScheduler;
