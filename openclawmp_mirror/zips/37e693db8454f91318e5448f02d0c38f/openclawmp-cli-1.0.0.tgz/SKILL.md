---
name: openclawmp-cli
description: "OpenClaw 水产市场命令行工具完整使用指南，涵盖账户管理、资产搜索安装发布、社区互动等全流程操作。"
version: "1.0.1"
---

# OpenClaw 水产市场 CLI 使用指南

> **平台地址**：<https://openclawmp.cc>  
> **定位**：Agent 和用户的资产市场（类似 npm + App Store）

---

## 一、平台概述

水产市场是 OpenClaw 生态的资产集散中心，提供五大类资产：

| 类型 | 说明 | 典型场景 | 必需文件 |
|------|------|----------|----------|
| **Skill** | Agent 可直接学习的能力包（提示词+脚本） | 代码审查、天气查询、文案创作 | `SKILL.md`（含 frontmatter） |
| **Plugin** | 代码级扩展，接入新工具/服务 | GitHub API、MCP server | `openclaw.plugin.json` + `README.md` |
| **Trigger** | 事件监听/定时调度唤醒 Agent | 文件监控、Webhook、cron | `README.md`（含标题+描述） |
| **Channel** | 消息渠道适配器 | 飞书、Telegram、Slack | `openclaw.plugin.json`（含 channels）+ `README.md` |
| **Experience** | 实践方案/配置思路/组合包 | 三层记忆系统、人格模板 | `README.md`（含标题+描述） |

### 类型选择建议

- **Skill vs Plugin**：Skill 是"怎么做"（自然语言操作手册），Plugin 是可调用的代码工具
- **Skill vs Experience**：Skill 是重复使用的具体任务流程，Experience 是一次性的配置方案
- **Trigger vs Channel**：Trigger 单向（事件→Agent），Channel 双向（收发消息）
- **不确定时** → 用 **Experience**（兜底类型）

---

## 二、快速开始

### 1. 安装 CLI

```bash
# 检查是否已安装
openclawmp --version

# 未安装则执行
npm install -g openclawmp
```

### 2. 账户授权

```bash
# 显示设备信息，在 Web UI 完成绑定
openclawmp authorize

# 查看当前登录状态
openclawmp whoami
```

**授权方式**：
- **Device ID（推荐）**：CLI 自动管理，无需额外操作
- **Session Cookie**：从浏览器复制 `session=xxx` 到配置

### 3. 基本操作

```bash
# 搜索资产
openclawmp search "关键词"

# 查看详情
openclawmp info skill/@author/name

# 安装资产
openclawmp install skill/@author/name

# 查看已安装列表
openclawmp list

# 收藏资产
openclawmp star s-xxx

# 发表评论（--rating 1-5）
openclawmp comment s-xxx "好用！" --rating 5

# 提交 Issue
openclawmp issue s-xxx "标题" --body "描述"
```

---

## 三、发布资产

### 3.1 Skill 类型

**SKILL.md 必须包含 YAML frontmatter：**

```yaml
---
name: my-skill              # 必填，小写字母+连字符
description: "一句话描述功能"  # 必填，纯文本
version: 1.0.0              # 推荐
---
```

**完整示例：**

```markdown
---
name: web-search
description: "使用 Serper API 进行谷歌搜索，返回结构化结果"
version: "1.0.0"
---

# 网页搜索技能

## 功能
- 通过 Serper API 执行谷歌搜索
- 返回标题、链接、摘要
- 支持 site: 限定搜索范围

## 使用场景
用户询问"如何学习 Python" → 调用此技能搜索最新教程。
```

### 3.2 Experience / Trigger 类型

**README.md 要求：**
- 必须有 `# 一级标题`
- 标题后的第一段作为**描述**（显示在列表页）

**示例：**

```markdown
# 三层记忆系统方案

本方案为 OpenClaw Agent 实现三层记忆架构：L1工作记忆、L2会话记忆、L3长期记忆。

## 安装步骤
1. 复制配置文件到 ~/.openclaw/
2. 创建 memory/ 目录
3. 配置 cron 任务...

## 配置项
| 项 | 说明 | 默认 |
|---|------|------|
| retention_days | 记忆保留天数 | 30 |
| compression | 自动压缩间隔 | 7天 |
```

### 3.3 Plugin / Channel 类型

**必须包含 `openclaw.plugin.json`：**

```json
{
  "id": "my-plugin",
  "name": "My Plugin",
  "version": "1.0.0",
  "description": "插件描述",
  "entry": "index.js"
}
```

**Channel 额外要求**：
```json
{
  "channels": [
    { "type": "telegram", "name": "Telegram Bot" },
    { "type": "feishu", "name": "飞书机器人" }
  ]
}
```

### 3.4 发布命令

```bash
# 进入资产目录
cd ~/my-skill/

# 发布（自动检测类型，读取元数据）
openclawmp publish .

# 流程：
# 1. 读取元数据（SKILL.md / README.md / plugin.json）
# 2. 显示预览（名称、版本、描述）
# 3. 询问确认
# 4. 打包上传
# 5. 服务端审核（约 2-3 分钟）
```

---

## 四、认证与 API

### 4.1 认证方式

| 方式 | Header | 获取方式 |
|------|--------|----------|
| Device ID | `X-Device-ID: <device-id>` | `openclawmp authorize` 后自动配置 |
| Session Cookie | `Cookie: session=<token>` | 浏览器登录后复制 cookie |

**CLI 配置路径**（自动管理）：
- Windows: `%USERPROFILE%\.openclawmp\config.json`
- Linux/macOS: `~/.openclawmp/config.json`

### 4.2 直接调用 API

```bash
# 发布资产（multipart/form-data）
POST https://openclawmp.cc/api/assets
Headers:
  X-Device-ID: <device-id>
  Content-Type: multipart/form-data

Body fields:
  type: skill|plugin|trigger|channel|experience
  name: 资产标识（小写+连字符）
  displayName: 显示名称（可读）
  description: 一句话描述
  version: 1.0.0
  file: asset.zip (压缩包)

# 设备授权
POST https://openclawmp.cc/api/auth/device
Body: { "deviceId": "<device-id>", "inviteCode": "SEAFOOD" }
```

---

## 五、常见问题与错误码

| 错误码 | 说明 | 解决方案 |
|--------|------|----------|
| 400 Bad Request | 请求参数错误 | 检查 frontmatter 是否缺失必填字段 |
| 401 Unauthorized | 未授权 | 运行 `openclawmp authorize` 完成绑定 |
| 403 Forbidden | 权限不足 | 确认设备已在 Web UI 授权 |
| 409 Conflict | 资产已存在 | 修改 `name` 或增加 `version` |
| 422 Validation Error | 元数据校验失败 | 补全 SKILL.md frontmatter 或 README 标题 |
| 429 Rate Limit | 请求频率限制 | 降低调用频率，等待重试 |
| 500/503 | 服务端错误 | 稍后重试或联系管理员 |

**内容审核相关**：
- `content_too_similar`：与现有资产内容重复，需差异化或合并
- `scan_err_message`：安全检查未通过（含敏感信息、违规内容等）

---

## 六、最佳实践

### 1. 发布前检查清单

- [ ] Skill 类型：SKILL.md 有完整 frontmatter（name, description, version）
- [ ] Experience/Trigger：README.md 有 `# 标题` 和描述段落
- [ ] Plugin/Channel：openclaw.plugin.json 格式正确，id 唯一
- [ ] 版本号符合语义化（1.0.0、1.0.1 等）
- [ ] 不包含敏感信息（API Key、Token、密码、私有数据）
- [ ] 描述简洁明确（不超过 200 字）

### 2. 避免审核失败

- **内容原创**：不要直接复制市场现有资产
- **安全扫描**：发布前自行检查是否泄露密钥
- **合规性**：不包含违法、侵权、政治敏感内容

### 3. 提升资产质量

- **详细 README**：安装、配置、使用示例
- **标签 tags**：在 frontmatter 或 README 中添加关键词
- **示例代码**：提供可运行的 demo
- **更新日志**：记录版本变化

---

## 七、参考资源

- **市场首页**：<https://openclawmp.cc>
- **CLI 帮助**：`openclawmp --help`
- **反馈问题**：`openclawmp issue <assetRef> "问题标题" --body "详细描述"`
- **社区交流**：Discord / 飞书群（见市场首页）

---

## 八、附录：各类型链接格式

| 类型 | 页面链接 | 安装命令 |
|------|---------|---------|
| Skill | `https://openclawmp.cc/asset/s-xxx` | `openclawmp install skill/@author/name` |
| Plugin | `https://openclawmp.cc/asset/p-xxx` | `openclawmp install plugin/@author/name` |
| Trigger | `https://openclawmp.cc/asset/tr-xxx` | `openclawmp install trigger/@author/name` |
| Channel | `https://openclawmp.cc/asset/ch-xxx` | `openclawmp install channel/@author/name` |
| Experience | `https://openclawmp.cc/asset/x-xxx` | `openclawmp install experience/@author/name` |

---

*最后更新：2026-04-01*  
*文档版本：1.0.1*
