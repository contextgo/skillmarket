---
name: gateway-health-monitor
description: "Health monitoring and auto-recovery for OpenClaw Gateway with proxy detection, process checks, and session recovery"
version: 1.0.0
---

# OpenClaw Gateway Health Monitor

Comprehensive health monitoring system for OpenClaw Gateway daemon. Detects proxy failures, process crashes, session stalls, and automatically triggers recovery procedures.

## When to Use

- Your OpenClaw Gateway runs 24/7 and needs monitoring
- You experience intermittent proxy/network issues
- You want automatic session recovery after Gateway restarts
- You need proactive health alerts before problems cascade

## Health Checks

### 1. Process Status

```bash
openclaw gateway status
```

### 2. Proxy Availability

```python
def check_proxy(host='127.0.0.1', port=7897, timeout=2):
    """Check if proxy service is listening"""
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((host, port))
        sock.close()
        return True
    except (socket.timeout, ConnectionRefusedError):
        return False
```

### 3. External API Reachability

```bash
# Quick reachability test (without proxy issues)
curl -s -o /dev/null -w "%{http_code}" --noproxy "*" https://evomap.ai/a2a/health
```

### 4. Session Liveness

```python
# Check if any sessions have stalled (user message without agent reply)
sessions = list_sessions()
for session in sessions:
    last_msg = get_last_message(session)
    if last_msg.role == 'user' and last_msg.age_minutes > 30:
        alert(f"Stalled session: {session.key}")
```

## Recovery Procedures

### Gateway Restart

```bash
openclaw gateway restart
```

### Post-Restart Recovery

After a Gateway restart:

1. **Report status**: Tell the user the Gateway has restarted
2. **Check recovery files**: Look for `temp/recovery-*.json`
3. **Scan stuck sessions**: Check all sessions for user messages without replies
4. **Resume tasks**: Check daily notes for In Progress items
5. **Never stay silent**: Always report something

### Proxy Recovery

When proxy is down:
1. Log the failure with timestamp
2. Skip network-dependent tasks (EvoMap, Polymarket)
3. Continue local tasks (memory maintenance, file organization)
4. Set up a check loop (every 10 minutes) to detect proxy return
5. When proxy returns, resume skipped tasks

## Alert Thresholds

| Condition | Action |
|-----------|--------|
| Gateway process not running | Immediate alert |
| Proxy down > 5 min | Warning log |
| Proxy down > 30 min | Alert user |
| Proxy down > 2 hours | Critical alert |
| Session stalled > 30 min | Auto-recovery attempt |
| 3+ consecutive task failures | Circuit breaker activation |

## Scheduling

Run health checks as part of heartbeat polling:

```
Every heartbeat:
  - Check Gateway process (always)
  - Check proxy availability (rotate: every 3rd heartbeat)
  - Scan stalled sessions (rotate: every 5th heartbeat)
  - Check task progress (rotate: every 3rd heartbeat)
```

During quiet hours (23:00-08:00), only check critical items (process + proxy).
