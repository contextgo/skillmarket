---
name: NanoBanana-PPT-Skills-Zhipu
version: 2.1.0
description: 基于智谱AI CogView生成高质量PPT图片，支持PIL文字叠加确保中文显示清晰
---

# PPT Generator Pro - 智谱AI版

基于智谱AI CogView-4模型生成高质量PPT图片，使用PIL进行文字叠加，确保中文显示清晰可读。

## ✨ 功能特性

- 🤖 **AI背景生成** - 使用智谱CogView-4生成精美PPT背景
- 📝 **PIL文字叠加** - 系统字体渲染，中文清晰可读
- 🎨 **玻璃拟态风格** - 内置渐变毛玻璃专业风格
- 🖼️ **16:9横版比例** - 1344x768分辨率，适合演示
- 🎮 **交互式播放器** - HTML5播放器，支持键盘导航

## 📦 系统要求

### 环境变量

**必需：**
- `ZHIPU_API_KEY`: 智谱AI API密钥
  - 获取地址: https://open.bigmodel.cn/usercenter/apikeys

**可选（用于视频功能）：**
- `KLING_ACCESS_KEY`: 可灵AI Access Key
- `KLING_SECRET_KEY`: 可灵AI Secret Key

### Python依赖

```bash
pip install pillow python-dotenv
```

### 视频功能依赖（可选）

```bash
# Windows
choco install ffmpeg

# macOS
brew install ffmpeg

# Ubuntu/Debian
sudo apt-get install ffmpeg
```

## 🚀 使用方法

### 快速开始

1. 设置API Key
```bash
export ZHIPU_API_KEY="your-api-key"
```

2. 创建PPT规划文件 `slides.json`:
```json
{
  "title": "我的PPT",
  "slides": [
    {"slide_number": 1, "page_type": "cover", "content": "标题\n副标题"},
    {"slide_number": 2, "page_type": "content", "content": "要点1\n要点2"},
    {"slide_number": 3, "page_type": "data", "content": "数据A: 100\n数据B: 200"}
  ]
}
```

3. 生成PPT
```bash
python3 generate_ppt.py --plan slides.json --style gradient-glass.md --output my_ppt
```

4. 查看结果
```bash
start my_ppt/index.html
```

### 页面类型

| 类型 | 说明 | 文字布局 |
|------|------|---------|
| `cover` | 封面页 | 标题居中，副标题下方 |
| `content` | 内容页 | 左对齐，分点显示 |
| `data` | 数据页 | 左侧文字，右侧预留图表区 |

## 📝 工作原理

### 两阶段生成

1. **AI生成背景**
   - 调用智谱CogView-4 API
   - 生成纯视觉背景（无文字）
   - 玻璃拟态、渐变效果

2. **PIL文字叠加**
   - 自动检测系统中文字体
   - 根据页面类型智能布局
   - 添加阴影增强可读性

### 字体检测

自动寻找以下字体：
- Windows: 微软雅黑、黑体、宋体
- Linux: 文泉驿、Noto Sans CJK
- macOS: 苹方、STHeiti

## 🎨 风格模板

### gradient-glass.md

渐变毛玻璃风格特点：
- Apple Keynote极简主义
- 霓虹紫/电光蓝/珊瑚橙渐变
- 3D玻璃物体 + 电影级光照
- 毛玻璃材质效果

## 📁 输出结构

```
my_ppt/
├── images/
│   ├── slide-01.png
│   ├── slide-02.png
│   └── ...
├── index.html          # 交互式播放器
└── prompts.json        # 生成记录
```

## ⌨️ 播放器快捷键

- `← →` - 上一页/下一页
- `Home` - 回到首页
- `End` - 跳到末页
- `空格` - 暂停/继续自动播放
- `ESC` - 全屏切换

## ⚠️ 注意事项

1. **API额度**: 智谱CogView按调用次数计费，请确保账户有足够额度
2. **生成时间**: 每张图片约30-60秒，请耐心等待
3. **字体问题**: 如中文显示异常，请确保系统安装了中文字体
4. **分辨率**: CogView最大横版为1344x768，暂不支持更高分辨率

## 🔧 故障排除

### 文字不显示
```bash
# 检查Pillow安装
pip install pillow

# 检查系统字体
python3 -c "from PIL import ImageFont; print(ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 20))"
```

### API调用失败
- 检查 `ZHIPU_API_KEY` 是否设置正确
- 确认API Key未过期
- 检查网络连接

## 📄 许可证

MIT License

## 🙏 致谢

- 基于歸藏的原版NanoBanana-PPT-Skills修改
- 使用智谱AI CogView-4模型
- 适配国内API环境
