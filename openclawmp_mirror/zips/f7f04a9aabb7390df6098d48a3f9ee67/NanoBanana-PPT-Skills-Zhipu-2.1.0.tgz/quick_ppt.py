#!/usr/bin/env python3
"""
一键生成 PPT - 交互式快速生成工具
只需输入主题和内容描述，自动生成 PPT
"""

import json
import os
import subprocess
import sys
from datetime import datetime


def main():
    print("=" * 60)
    print("PPT 一键生成工具")
    print("=" * 60)
    print()

    # 1. 获取主题
    title = input("PPT 标题: ").strip()
    if not title:
        print("错误: 标题不能为空")
        return

    # 2. 获取页数
    print()
    print("选择页数:")
    print("  1. 3页 (封面+内容+总结)")
    print("  2. 5页 (推荐)")
    print("  3. 7页")
    print("  4. 自定义")
    choice = input("选择 (1-4): ").strip() or "2"

    page_map = {"1": 3, "2": 5, "3": 7}
    if choice == "4":
        total = int(input("输入页数: ").strip() or "5")
    else:
        total = page_map.get(choice, 5)

    # 3. 获取内容
    print()
    print(f"输入每页的主要内容 (共{total}页):")
    print("提示: 每页用一句话描述核心内容")
    print()

    slides = []

    # 封面
    subtitle = input("第1页 - 封面副标题/作者: ").strip()
    slides.append({
        "slide_number": 1,
        "page_type": "cover",
        "content": f"{title}\n{subtitle}" if subtitle else title
    })

    # 中间页
    for i in range(2, total):
        content = input(f"第{i}页 - 内容: ").strip()
        if not content:
            content = f"第{i}页内容"
        slides.append({
            "slide_number": i,
            "page_type": "content",
            "content": content
        })

    # 总结页
    summary = input(f"第{total}页 - 总结/感谢: ").strip()
    if not summary:
        summary = "谢谢观看"
    slides.append({
        "slide_number": total,
        "page_type": "data",
        "content": summary
    })

    # 4. 选择风格
    print()
    print("选择风格:")
    print("  1. 渐变毛玻璃 (科技感)")
    choice = input("选择 (1): ").strip() or "1"
    style = "gradient-glass.md"

    # 5. 生成文件名
    timestamp = datetime.now().strftime("%m%d_%H%M%S")
    safe_title = "".join(c for c in title if c.isalnum() or c in (' ', '-', '_')).strip()
    output_name = f"{safe_title}_{timestamp}".replace(' ', '_')

    # 6. 保存规划文件
    plan = {
        "title": title,
        "slides": slides
    }

    plan_file = f"plan_{output_name}.json"
    with open(plan_file, 'w', encoding='utf-8') as f:
        json.dump(plan, f, ensure_ascii=False, indent=2)

    print()
    print(f"规划文件已保存: {plan_file}")

    # 7. 执行生成
    print()
    print("开始生成 PPT...")
    print("-" * 60)

    cmd = [
        sys.executable, "generate_ppt.py",
        "--plan", plan_file,
        "--style", style,
        "--output", output_name
    ]

    result = subprocess.run(cmd)

    if result.returncode == 0:
        print()
        print("=" * 60)
        print("PPT 生成完成!")
        print("=" * 60)
        print(f"输出目录: {output_name}")
        print(f"播放器: {output_name}\\index.html")
        print()
        print("打开方式:")
        print(f"  start {output_name}\\index.html")

        # 询问是否打开
        open_now = input("\n是否立即打开? (y/n): ").strip().lower()
        if open_now == 'y':
            subprocess.run(["start", f"{output_name}\\index.html"], shell=True)
    else:
        print("生成失败，请检查错误信息")


if __name__ == "__main__":
    main()
