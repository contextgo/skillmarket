#!/usr/bin/env python3
"""
PPT Generator - Generate PPT slide images using ZhipuAI CogView API.

Modified from the original Gemini-based version to use ZhipuAI CogView-4
for image generation, making it work with a domestic Chinese API.

NEW: Text overlay support - generates clean background images and overlays
readable Chinese text using PIL/Pillow.
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

try:
    from dotenv import load_dotenv
except ImportError:
    def load_dotenv(*args, **kwargs):
        pass

try:
    from PIL import Image, ImageDraw, ImageFont
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False
    print("Warning: PIL not available, text overlay disabled")


# =============================================================================
# Constants
# =============================================================================

DEFAULT_RESOLUTION = "1344x768"
DEFAULT_TEMPLATE_PATH = "templates/viewer.html"
OUTPUT_BASE_DIR = "outputs"

ZHIPU_API_URL = "https://open.bigmodel.cn/api/paas/v4/images/generations"
ZHIPU_MODEL = "cogview-4-250304"

RESOLUTION_MAP = {
    "1344x768": (1344, 768),
    "1024x1024": (1024, 1024),
    "768x1344": (768, 1344),
    "2K": (1344, 768),
    "4K": (1344, 768),
}

# Font settings for Chinese text overlay
FONT_SIZE_TITLE = 72
FONT_SIZE_SUBTITLE = 48
FONT_SIZE_BODY = 36
FONT_SIZE_SMALL = 28


# =============================================================================
# Environment Configuration
# =============================================================================

def find_and_load_env() -> bool:
    """Find and load .env file from multiple locations."""
    current_dir = Path(__file__).parent
    env_locations = [
        current_dir / ".env",
        *[parent / ".env" for parent in current_dir.parents],
    ]

    for env_path in env_locations:
        if env_path.exists():
            load_dotenv(str(env_path), override=True)
            print(f"Loaded environment from: {env_path}")
            return True
        if env_path.parent != current_dir and (env_path.parent / ".git").exists():
            break

    load_dotenv(override=True)
    print("Warning: No .env file found, using system environment variables")
    return False


# =============================================================================
# Style Template
# =============================================================================

def load_style_template(style_path: str) -> str:
    """Load and parse style template file."""
    with open(style_path, "r", encoding="utf-8") as f:
        content = f.read()

    start_marker = "## "
    end_idx = content.find(start_marker, len(start_marker))

    if start_idx := content.find(start_marker) != -1 and end_idx != -1:
        return content[start_idx + len(start_marker):end_idx].strip()

    return content


# =============================================================================
# Prompt Generation (without text in image)
# =============================================================================

def generate_background_prompt(
    style_template: str,
    page_type: str,
    slide_number: int,
    total_slides: int,
) -> str:
    """
    Generate a prompt for background image generation.
    IMPORTANT: Do NOT include text content in the prompt.
    Text will be overlaid separately for better quality.
    """
    prompt_parts = [style_template, "\n\n"]

    is_cover = page_type == "cover" or slide_number == 1
    is_data = page_type == "data" or slide_number == total_slides

    if is_cover:
        prompt_parts.append(
            """生成一张PPT封面页背景图片。
设计要求：
- 中心放置一个大型复杂的3D玻璃物体
- 背景使用延伸的极光波浪效果
- 霓虹紫/电光蓝/珊瑚橙渐变
- 电影级光照，柔和的阴影和发光效果
- 16:9横版比例，高质量
- **重要：图片中不要包含任何文字，保持纯视觉背景**
- 预留中心区域用于后期添加标题文字"""
        )
    elif is_data:
        prompt_parts.append(
            """生成一张PPT数据/总结页背景图片。
设计要求：
- 分屏布局，左侧留白区域，右侧数据可视化区域
- 浮动的大型发光3D数据图表元素
- 玻璃拟态效果，毛玻璃材质
- 霓虹渐变背景
- 16:9横版比例，高质量
- **重要：图片中不要包含任何文字，保持纯视觉背景**
- 左侧预留空白区域用于后期添加文字"""
        )
    else:
        prompt_parts.append(
            """生成一张PPT内容页背景图片。
设计要求：
- Bento网格布局，模块化圆角矩形容器
- 玻璃拟态效果，毛玻璃材质带模糊
- 容器内预留空白区域用于放置内容
- 霓虹紫/电光蓝渐变背景
- 16:9横版比例，高质量
- **重要：图片中不要包含任何文字，保持纯视觉背景**
- 多个内容区块预留空白位置"""
        )

    return "".join(prompt_parts)


# =============================================================================
# Text Overlay with PIL
# =============================================================================

def find_chinese_font() -> Optional[str]:
    """Find a suitable Chinese font on the system."""
    # Windows common Chinese fonts
    windows_fonts = [
        "C:/Windows/Fonts/msyh.ttc",      # Microsoft YaHei
        "C:/Windows/Fonts/simhei.ttf",    # SimHei
        "C:/Windows/Fonts/simsun.ttc",    # SimSun
        "C:/Windows/Fonts/msyhbd.ttc",    # Microsoft YaHei Bold
    ]
    
    # Linux common fonts
    linux_fonts = [
        "/usr/share/fonts/truetype/wqy/wqy-zenhei.ttc",
        "/usr/share/fonts/truetype/wqy/wqy-microhei.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
    ]
    
    # macOS fonts
    mac_fonts = [
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/STHeiti Light.ttc",
        "/Library/Fonts/Arial Unicode.ttf",
    ]
    
    all_fonts = windows_fonts + linux_fonts + mac_fonts
    
    for font_path in all_fonts:
        if os.path.exists(font_path):
            return font_path
    
    return None


def overlay_text_on_image(
    image_path: str,
    content_text: str,
    page_type: str,
    output_path: str,
) -> bool:
    """
    Overlay Chinese text on the generated background image.
    Returns True if successful, False otherwise.
    """
    if not PIL_AVAILABLE:
        print(f"  Warning: PIL not available, skipping text overlay")
        return False
    
    font_path = find_chinese_font()
    if not font_path:
        print(f"  Warning: No Chinese font found, skipping text overlay")
        return False
    
    try:
        # Open image
        img = Image.open(image_path)
        draw = ImageDraw.Draw(img)
        width, height = img.size
        
        # Parse content text
        lines = content_text.strip().split('\n')
        
        # Load fonts
        try:
            font_title = ImageFont.truetype(font_path, FONT_SIZE_TITLE)
            font_subtitle = ImageFont.truetype(font_path, FONT_SIZE_SUBTITLE)
            font_body = ImageFont.truetype(font_path, FONT_SIZE_BODY)
            font_small = ImageFont.truetype(font_path, FONT_SIZE_SMALL)
        except Exception as e:
            print(f"  Warning: Font loading failed: {e}")
            return False
        
        # Determine layout based on page type
        if page_type == "cover":
            # Cover: Center title, smaller subtitle below
            title = lines[0] if lines else ""
            subtitle = '\n'.join(lines[1:]) if len(lines) > 1 else ""
            
            # Draw title (center, upper-middle)
            bbox = draw.textbbox((0, 0), title, font=font_title)
            text_width = bbox[2] - bbox[0]
            x = (width - text_width) // 2
            y = height // 3
            
            # Draw with shadow for readability
            draw.text((x+2, y+2), title, font=font_title, fill=(0, 0, 0, 128))
            draw.text((x, y), title, font=font_title, fill=(255, 255, 255, 255))
            
            # Draw subtitle
            if subtitle:
                bbox = draw.textbbox((0, 0), subtitle, font=font_subtitle)
                text_width = bbox[2] - bbox[0]
                x = (width - text_width) // 2
                y = height // 3 + FONT_SIZE_TITLE + 30
                draw.text((x+1, y+1), subtitle, font=font_subtitle, fill=(0, 0, 0, 128))
                draw.text((x, y), subtitle, font=font_subtitle, fill=(240, 240, 240, 255))
        
        elif page_type == "data":
            # Data page: Left side text, right side visualization
            # Left column for text
            left_margin = width // 20
            y = height // 5
            
            for i, line in enumerate(lines):
                if i == 0:  # Title
                    draw.text((left_margin+1, y+1), line, font=font_subtitle, fill=(0, 0, 0, 128))
                    draw.text((left_margin, y), line, font=font_subtitle, fill=(255, 255, 255, 255))
                    y += FONT_SIZE_SUBTITLE + 20
                else:  # Data lines
                    draw.text((left_margin+1, y+1), line, font=font_body, fill=(0, 0, 0, 128))
                    draw.text((left_margin, y), line, font=font_body, fill=(255, 255, 255, 230))
                    y += FONT_SIZE_BODY + 15
        
        else:  # content page
            # Content page: Bento grid style
            # Simple layout: title at top, content below
            margin = width // 15
            y = height // 8
            
            for i, line in enumerate(lines):
                if i == 0:  # Section title
                    draw.text((margin+1, y+1), line, font=font_subtitle, fill=(0, 0, 0, 128))
                    draw.text((margin, y), line, font=font_subtitle, fill=(255, 255, 255, 255))
                    y += FONT_SIZE_SUBTITLE + 25
                elif line.startswith('-') or line.startswith('•'):
                    # Bullet point
                    draw.text((margin+1, y+1), line, font=font_body, fill=(0, 0, 0, 128))
                    draw.text((margin, y), line, font=font_body, fill=(255, 255, 255, 230))
                    y += FONT_SIZE_BODY + 15
                elif line[0:2].isdigit() and '. ' in line[:4]:
                    # Numbered list
                    draw.text((margin+1, y+1), line, font=font_body, fill=(0, 0, 0, 128))
                    draw.text((margin, y), line, font=font_body, fill=(255, 255, 255, 230))
                    y += FONT_SIZE_BODY + 15
                else:
                    # Regular text
                    draw.text((margin+1, y+1), line, font=font_body, fill=(0, 0, 0, 128))
                    draw.text((margin, y), line, font=font_body, fill=(255, 255, 255, 230))
                    y += FONT_SIZE_BODY + 15
        
        # Save result
        img.save(output_path, "PNG")
        return True
        
    except Exception as e:
        print(f"  Text overlay failed: {e}")
        return False


# =============================================================================
# Image Generation (ZhipuAI CogView)
# =============================================================================

def get_zhipu_api_key() -> str:
    """Get ZhipuAI API key from environment."""
    api_key = os.environ.get("ZHIPU_API_KEY")
    if not api_key:
        print("Error: ZHIPU_API_KEY environment variable not set")
        print("Please set: export ZHIPU_API_KEY='your-api-key'")
        print("Get your key at: https://open.bigmodel.cn/usercenter/apikeys")
        sys.exit(1)
    return api_key


def download_image(url: str, save_path: str) -> bool:
    """Download image from URL to local path."""
    try:
        req = urllib.request.Request(url)
        resp = urllib.request.urlopen(req, timeout=60)
        with open(save_path, "wb") as f:
            f.write(resp.read())
        return True
    except Exception as e:
        print(f"  Failed to download image: {e}")
        return False


def generate_slide(
    style_template: str,
    page_type: str,
    content_text: str,
    slide_number: int,
    total_slides: int,
    output_dir: str,
    resolution: str = DEFAULT_RESOLUTION,
) -> Optional[str]:
    """
    Generate a single PPT slide with background + text overlay.
    """
    print(f"Generating slide {slide_number}...")

    api_key = get_zhipu_api_key()
    
    # Step 1: Generate background image (no text)
    bg_prompt = generate_background_prompt(style_template, page_type, slide_number, total_slides)
    
    request_data = json.dumps({
        "model": ZHIPU_MODEL,
        "prompt": bg_prompt,
        "size": resolution,
        "n": 1,
    }).encode("utf-8")

    req = urllib.request.Request(
        ZHIPU_API_URL,
        data=request_data,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
    )

    bg_image_path = None
    try:
        resp = urllib.request.urlopen(req, timeout=120)
        result = json.loads(resp.read().decode("utf-8"))

        if "data" in result and len(result["data"]) > 0:
            image_url = result["data"][0].get("url")
            if image_url:
                bg_image_path = os.path.join(output_dir, "images", f"slide-{slide_number:02d}_bg.png")
                if not download_image(image_url, bg_image_path):
                    print(f"  Slide {slide_number} failed: Could not download background")
                    return None
        else:
            print(f"  Slide {slide_number} failed: No image data in response")
            return None

    except Exception as e:
        print(f"  Slide {slide_number} failed: {e}")
        return None

    # Step 2: Overlay text on background
    final_path = os.path.join(output_dir, "images", f"slide-{slide_number:02d}.png")
    
    if overlay_text_on_image(bg_image_path, content_text, page_type, final_path):
        print(f"  Slide {slide_number} saved: {final_path}")
        # Clean up background file
        try:
            os.remove(bg_image_path)
        except:
            pass
        return final_path
    else:
        # Fallback: use background without text
        os.rename(bg_image_path, final_path)
        print(f"  Slide {slide_number} saved (no text overlay): {final_path}")
        return final_path


# =============================================================================
# Output Generation
# =============================================================================

def generate_viewer_html(output_dir: str, slide_count: int, template_path: str) -> str:
    """Generate HTML viewer for slides playback."""
    if os.path.exists(template_path):
        with open(template_path, "r", encoding="utf-8") as f:
            html_template = f.read()

        slides_list = [f"'images/slide-{i:02d}.png'" for i in range(1, slide_count + 1)]
        html_content = html_template.replace(
            "/* IMAGE_LIST_PLACEHOLDER */",
            ",\n            ".join(slides_list),
        )
    else:
        slides_list = [f"'images/slide-{i:02d}.png'" for i in range(1, slide_count + 1)]
        slides_js = ",\n            ".join(slides_list)
        html_content = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PPT Viewer</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{ background: #1a1a2e; display: flex; justify-content: center; align-items: center; min-height: 100vh; font-family: sans-serif; }}
        .viewer {{ position: relative; width: 90vw; max-width: 1200px; }}
        .slide {{ width: 100%; border-radius: 12px; box-shadow: 0 20px 60px rgba(0,0,0,0.5); }}
        .controls {{ display: flex; justify-content: center; gap: 20px; margin-top: 20px; }}
        .controls button {{ padding: 10px 24px; border: none; border-radius: 8px; background: #6c5ce7; color: white; font-size: 16px; cursor: pointer; transition: 0.2s; }}
        .controls button:hover {{ background: #a29bfe; }}
        .counter {{ color: #ccc; font-size: 14px; text-align: center; margin-top: 10px; }}
    </style>
</head>
<body>
    <div class="viewer">
        <img class="slide" id="slide" src="" alt="Slide">
        <div class="controls">
            <button onclick="prev()">← Previous</button>
            <button onclick="next()">Next →</button>
        </div>
        <div class="counter" id="counter"></div>
    </div>
    <script>
        const slides = [{slides_js}];
        let current = 0;
        function show() {{ document.getElementById('slide').src = slides[current]; document.getElementById('counter').textContent = (current + 1) + ' / ' + slides.length; }}
        function prev() {{ if (current > 0) {{ current--; show(); }} }}
        function next() {{ if (current < slides.length - 1) {{ current++; show(); }} }}
        document.addEventListener('keydown', e => {{ if (e.key === 'ArrowLeft') prev(); if (e.key === 'ArrowRight') next(); if (e.key === 'Home') {{ current = 0; show(); }} if (e.key === 'End') {{ current = slides.length - 1; show(); }} }});
        show();
    </script>
</body>
</html>"""

    html_path = os.path.join(output_dir, "index.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html_content)

    print(f"  Viewer HTML generated: {html_path}")
    return html_path


def save_prompts(output_dir: str, prompts_data: Dict[str, Any]) -> str:
    """Save all prompts to JSON file."""
    prompts_path = os.path.join(output_dir, "prompts.json")
    with open(prompts_path, "w", encoding="utf-8") as f:
        json.dump(prompts_data, f, ensure_ascii=False, indent=2)
    print(f"  Prompts saved: {prompts_path}")
    return prompts_path


# =============================================================================
# Main Entry Point
# =============================================================================

def create_argument_parser() -> argparse.ArgumentParser:
    """Create and configure argument parser."""
    parser = argparse.ArgumentParser(
        description="PPT Generator - Generate PPT images using ZhipuAI CogView API with text overlay",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Example usage:
  python generate_ppt.py --plan slides_plan.json --style gradient-glass.md

Environment variables:
  ZHIPU_API_KEY: ZhipuAI API key (required)
  Get your key at: https://open.bigmodel.cn/usercenter/apikeys

Requirements:
  pip install pillow  (for text overlay)
""",
    )

    parser.add_argument("--plan", required=True, help="Path to slides plan JSON file")
    parser.add_argument("--style", required=True, help="Path to style template file")
    parser.add_argument("--resolution", default=DEFAULT_RESOLUTION, help=f"Image resolution (default: {DEFAULT_RESOLUTION})")
    parser.add_argument("--output", help="Output directory path")
    parser.add_argument("--template", default=DEFAULT_TEMPLATE_PATH, help="HTML template path")
    parser.add_argument("--no-text-overlay", action="store_true", help="Disable text overlay (use AI-generated text)")

    return parser


def main() -> None:
    """Main entry point for PPT generation."""
    find_and_load_env()

    parser = create_argument_parser()
    args = parser.parse_args()

    # Load slides plan
    with open(args.plan, "r", encoding="utf-8") as f:
        slides_plan = json.load(f)

    # Load style template
    style_template = load_style_template(args.style)

    # Create output directory
    if args.output:
        output_dir = args.output
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_dir = f"{OUTPUT_BASE_DIR}/{timestamp}"

    os.makedirs(os.path.join(output_dir, "images"), exist_ok=True)

    # Check PIL availability
    if not PIL_AVAILABLE:
        print("Warning: Pillow not installed. Text overlay disabled.")
        print("Install with: pip install pillow")

    # Print configuration
    slides = slides_plan["slides"]
    total_slides = len(slides)

    print("=" * 60)
    print("PPT Generator Started (ZhipuAI CogView + Text Overlay)")
    print("=" * 60)
    print(f"Model: {ZHIPU_MODEL}")
    print(f"Style: {args.style}")
    print(f"Resolution: {args.resolution}")
    print(f"Slides: {total_slides}")
    print(f"Text Overlay: {'Disabled' if args.no_text_overlay else 'Enabled'}")
    print(f"Output: {output_dir}")
    print("=" * 60)
    print()

    # Initialize prompts data
    prompts_data: Dict[str, Any] = {
        "metadata": {
            "title": slides_plan.get("title", "Untitled Presentation"),
            "total_slides": total_slides,
            "resolution": args.resolution,
            "model": ZHIPU_MODEL,
            "style": args.style,
            "generated_at": datetime.now().isoformat(),
        },
        "slides": [],
    }

    # Generate each slide
    success_count = 0
    for slide_info in slides:
        slide_number = slide_info["slide_number"]
        page_type = slide_info.get("page_type", "content")
        content_text = slide_info["content"]

        if args.no_text_overlay:
            # Fallback: skip text overlay, use background only
            print("  Text overlay disabled, using background only")
            image_path = generate_slide(
                style_template, page_type, content_text,
                slide_number, total_slides, output_dir, args.resolution
            )
        else:
            # New method: background + text overlay
            image_path = generate_slide(
                style_template, page_type, content_text,
                slide_number, total_slides, output_dir, args.resolution
            )

        if image_path:
            success_count += 1

        prompts_data["slides"].append({
            "slide_number": slide_number,
            "page_type": page_type,
            "content": content_text,
            "image_path": image_path,
        })

        print()

    # Save prompts
    save_prompts(output_dir, prompts_data)

    # Generate viewer HTML
    generate_viewer_html(output_dir, total_slides, args.template)

    # Print completion summary
    print()
    print("=" * 60)
    print(f"Generation Complete! ({success_count}/{total_slides} slides)")
    print("=" * 60)
    print(f"Output directory: {output_dir}")
    print(f"Viewer HTML: {os.path.join(output_dir, 'index.html')}")
    print()
    print("Open viewer in browser:")
    print(f"  start {os.path.join(output_dir, 'index.html')}")
    print()


if __name__ == "__main__":
    main()
