---
name: mcp-builder-kit
description: MCP 服务器快速构建工具箱，提供完整的 Model Context Protocol 服务器开发指南，包括项目脚手架、工具定义、资源模板、传输层配置、认证安全、测试调试和发布部署的完整工作流。
---

# MCP 服务器构建工具箱 (MCP Builder Kit)

> 作者：知白守黑1024

## 概述

MCP（Model Context Protocol）是一种开放协议，让 AI 模型能够与外部工具和数据源进行标准化交互。本工具箱提供从零开始构建 MCP 服务器的完整指南，涵盖项目脚手架生成、工具定义模式、资源和提示词模板、传输层配置、认证安全、测试调试以及发布部署的全流程。

---

## 1. MCP 协议基础

### 1.1 什么是 MCP？

MCP（Model Context Protocol）是 Anthropic 推出的开放协议，定义了 AI 应用与外部数据源/工具之间的通信标准。

**核心概念：**

| 概念 | 说明 |
|------|------|
| **Host（宿主）** | AI 应用（如 Claude Desktop、Cursor） |
| **Client（客户端）** | MCP 协议客户端，由宿主应用内嵌 |
| **Server（服务器）** | 提供 tools/resources/prompts 的服务端 |
| **Tool（工具）** | 服务器暴露的函数，AI 可以调用 |
| **Resource（资源）** | 服务器提供的数据内容 |
| **Prompt（提示）** | 服务器提供的提示词模板 |
| **Transport（传输）** | 客户端与服务器的通信方式 |

### 1.2 MCP 通信架构

```
┌──────────────┐     ┌──────────────┐     ┌──────────────┐
│   Host App   │     │  MCP Client  │     │  MCP Server  │
│ (Claude etc) │────▶│  (内置在宿主) │────▶│ (你的服务)    │
└──────────────┘     └──────────────┘     └──────────────┘
                            │
                     stdio / HTTP SSE
```

### 1.3 三种能力类型

1. **Tools（工具）**：AI 可调用的函数
2. **Resources（资源）**：AI 可读取的数据
3. **Prompts（提示模板）**：预定义的提示词模板

---

## 2. 项目脚手架

### 2.1 TypeScript MCP 服务器模板

#### 使用官方 SDK 快速创建

```bash
# 创建项目目录
mkdir my-mcp-server && cd my-mcp-server

# 初始化项目
npm init -y

# 安装 MCP SDK
npm install @modelcontextprotocol/sdk zod

# 安装开发依赖
npm install -D typescript @types/node tsx
```

#### 完整的 package.json 配置

```json
{
  "name": "my-mcp-server",
  "version": "1.0.0",
  "description": "My MCP Server",
  "type": "module",
  "main": "dist/index.js",
  "scripts": {
    "build": "tsc",
    "dev": "tsx watch src/index.ts",
    "start": "node dist/index.js",
    "inspector": "npx @modelcontextprotocol/inspector node dist/index.js"
  },
  "dependencies": {
    "@modelcontextprotocol/sdk": "^1.12.1",
    "zod": "^3.24.2"
  },
  "devDependencies": {
    "typescript": "^5.7.3",
    "@types/node": "^22.13.5",
    "tsx": "^4.19.3"
  }
}
```

#### tsconfig.json 配置

```json
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "Node16",
    "moduleResolution": "Node16",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true,
    "resolveJsonModule": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules", "dist"]
}
```

### 2.2 Python MCP 服务器模板

```bash
# 创建项目目录
mkdir my-mcp-server && cd my-mcp-server

# 创建虚拟环境
python -m venv venv
source venv/bin/activate  # Linux/Mac
# venv\Scripts\activate   # Windows

# 安装 MCP SDK
pip install mcp[cli]

# 创建项目文件结构
touch server.py pyproject.toml
```

#### pyproject.toml 配置

```toml
[project]
name = "my-mcp-server"
version = "0.1.0"
description = "My MCP Server"
requires-python = ">=3.10"
dependencies = [
    "mcp[cli]>=1.0.0",
]

[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project.scripts]
my-mcp-server = "server:main"
```

### 2.3 推荐项目结构

```
my-mcp-server/
├── src/
│   ├── index.ts          # 入口文件
│   ├── tools/            # 工具定义
│   │   ├── index.ts
│   │   ├── weather.ts
│   │   └── database.ts
│   ├── resources/        # 资源定义
│   │   ├── index.ts
│   │   └── templates.ts
│   ├── prompts/          # 提示模板
│   │   ├── index.ts
│   │   └── code-review.ts
│   ├── lib/              # 工具库
│   │   ├── auth.ts
│   │   └── utils.ts
│   └── types/            # 类型定义
│       └── index.ts
├── dist/                 # 编译输出
├── tests/                # 测试文件
│   ├── tools.test.ts
│   └── integration.test.ts
├── package.json
├── tsconfig.json
└── README.md
```

---

## 3. 工具定义模式（Tools）

### 3.1 完整的 TypeScript MCP 服务器示例

```typescript
// src/index.ts
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { z } from "zod";

// 创建 MCP 服务器实例
const server = new McpServer({
  name: "my-awesome-server",
  version: "1.0.0",
});

// ============================================================
// 工具定义示例 1：简单的计算器工具
// ============================================================
server.tool(
  "calculate",                    // 工具名称
  "执行数学计算",                   // 工具描述
  {
    expression: z.string().describe("数学表达式，例如 '2 + 3 * 4'"),
  },
  async ({ expression }) => {
    try {
      // 安全的数学计算（不使用 eval）
      const sanitized = expression.replace(/[^0-9+\-*/().%\s]/g, "");
      const result = Function(`"use strict"; return (${sanitized})`)();

      return {
        content: [
          {
            type: "text",
            text: `计算结果：${expression} = ${result}`,
          },
        ],
      };
    } catch (error) {
      return {
        content: [
          {
            type: "text",
            text: `计算错误：无法解析表达式 "${expression}"`,
          },
        ],
        isError: true,
      };
    }
  }
);

// ============================================================
// 工具定义示例 2：带丰富参数的工具
// ============================================================
server.tool(
  "query_database",
  "查询数据库中的数据",
  {
    table: z.string().describe("表名"),
    columns: z.array(z.string()).optional().describe("要查询的列名列表"),
    where: z.string().optional().describe("WHERE 条件（不包含 WHERE 关键字）"),
    limit: z.number().min(1).max(1000).default(100).describe("返回行数限制"),
    order_by: z.string().optional().describe("排序字段"),
    order_dir: z.enum(["ASC", "DESC"]).default("DESC").describe("排序方向"),
  },
  async ({ table, columns, where, limit, order_by, order_dir }) => {
    // 构建安全的 SQL 查询
    const selectCols = columns?.join(", ") || "*";
    let sql = `SELECT ${selectCols} FROM ${table}`;

    const params: any[] = [];

    if (where) {
      sql += ` WHERE ${where}`;
    }

    if (order_by) {
      sql += ` ORDER BY ${order_by} ${order_dir}`;
    }

    sql += ` LIMIT ${limit}`;

    // 执行查询（此处为示例，实际使用时连接真实数据库）
    return {
      content: [
        {
          type: "text",
          text: `生成的 SQL:\n${sql}\n\n注意：实际使用时请连接数据库执行此查询。`,
        },
      ],
    };
  }
);

// ============================================================
// 工具定义示例 3：返回图片内容的工具
// ============================================================
server.tool(
  "generate_qr_code",
  "生成二维码图片",
  {
    text: z.string().describe("二维码内容"),
    size: z.number().min(100).max(1000).default(300).describe("图片尺寸（像素）"),
    format: z.enum(["png", "svg"]).default("png").describe("输出格式"),
  },
  async ({ text, size, format }) => {
    // 生成 QR 码（此处为示意，实际需要安装 QR 码库）
    const qrPlaceholder = `[QR Code: ${text}]`;

    if (format === "svg") {
      return {
        content: [
          {
            type: "image",
            data: Buffer.from(qrPlaceholder).toString("base64"),
            mimeType: "image/svg+xml",
          },
        ],
      };
    }

    return {
      content: [
        {
          type: "text",
          text: `已生成 ${size}x${size} 的 ${format} 格式二维码，内容: "${text}"`,
        },
      ],
    };
  }
);

// ============================================================
// 启动服务器
// ============================================================
async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error("MCP Server 已启动（stdio 传输）");
}

main().catch(console.error);
```

### 3.2 工具定义最佳实践

#### 命名规范

```typescript
// ✅ 好的命名：动词_名词，清晰表达意图
"search_files"        // 搜索文件
"read_database"       // 读取数据库
"send_notification"   // 发送通知
"analyze_code"        // 分析代码

// ❌ 不好的命名：过于模糊
"search"              // 搜索什么？
"read"                // 读取什么？
"process"             // 处理什么？
```

#### 描述编写规范

```typescript
// ✅ 好的描述：包含用途、输入、输出
"在指定目录中递归搜索包含关键词的文件，返回匹配的文件路径和相关行号"

// ❌ 不好的描述：过于简短
"搜索文件"

// ✅ 好的参数描述
{
  path: z.string().describe("要搜索的目录绝对路径，例如 /home/user/project"),
  keyword: z.string().describe("搜索关键词，支持正则表达式"),
  extensions: z.array(z.string()).optional()
    .describe("文件扩展名过滤，例如 ['.ts', '.js']。不指定则搜索所有文件"),
}

// ❌ 不好的参数描述
{
  path: z.string().describe("路径"),
  keyword: z.string().describe("关键词"),
}
```

#### 错误处理模式

```typescript
server.tool(
  "safe_operation",
  "安全的操作工具",
  { input: z.string() },
  async ({ input }) => {
    try {
      // 参数验证
      if (!input || input.trim().length === 0) {
        return {
          content: [{ type: "text", text: "错误：输入不能为空" }],
          isError: true,
        };
      }

      // 执行操作
      const result = await performOperation(input);

      // 返回结构化结果
      return {
        content: [
          {
            type: "text",
            text: JSON.stringify({
              success: true,
              data: result,
              timestamp: new Date().toISOString(),
            }, null, 2),
          },
        ],
      };
    } catch (error) {
      // 错误返回
      const errorMessage = error instanceof Error ? error.message : "未知错误";
      return {
        content: [
          {
            type: "text",
            text: `操作失败：${errorMessage}`,
          },
        ],
        isError: true,
      };
    }
  }
);
```

---

## 4. 资源定义模式（Resources）

### 4.1 静态资源

```typescript
// 定义静态资源
server.resource(
  "project-readme",                           // 资源名称
  "file:///project/README.md",                // URI
  "项目的 README 文档",                        // 描述
  async (uri) => {
    const readmeContent = await fs.readFile("/project/README.md", "utf-8");
    return {
      contents: [
        {
          uri: uri.href,
          mimeType: "text/markdown",
          text: readmeContent,
        },
      ],
    };
  }
);

// 定义模板资源（带参数）
server.resource(
  "code-template",
  "template://code/{language}/{pattern}",
  "代码模板资源",
  async (uri) => {
    const { language, pattern } = extractParams(uri.pathname);
    const template = getTemplate(language, pattern);

    return {
      contents: [
        {
          uri: uri.href,
          mimeType: "text/plain",
          text: template,
        },
      ],
    };
  }
);
```

### 4.2 动态资源列表

```typescript
// 注册资源列表处理器
server.setRequestHandler(
  ListResourcesRequestSchema,
  async () => {
    const resources = [
      {
        uri: "file:///config/settings.json",
        name: "配置文件",
        description: "应用的配置信息",
        mimeType: "application/json",
      },
      {
        uri: "file:///logs/latest.log",
        name: "最新日志",
        description: "最近的应用日志",
        mimeType: "text/plain",
      },
    ];
    return { resources };
  }
);
```

---

## 5. 提示模板模式（Prompts）

### 5.1 定义提示模板

```typescript
server.prompt(
  "code-review",                              // 提示名称
  "代码审查提示模板",                           // 描述
  {
    code: z.string().describe("要审查的代码"),
    language: z.string().describe("编程语言"),
    focus: z.enum(["security", "performance", "readability", "all"])
      .default("all")
      .describe("审查重点"),
  },
  async ({ code, language, focus }) => {
    const focusInstructions = {
      security: "重点关注安全问题：SQL注入、XSS、CSRF、认证授权等",
      performance: "重点关注性能问题：算法复杂度、内存使用、I/O 优化等",
      readability: "重点关注代码可读性：命名规范、代码结构、注释质量等",
      all: "全面审查：安全性、性能、可读性、最佳实践",
    };

    return {
      messages: [
        {
          role: "user",
          content: {
            type: "text",
            text: `请对以下 ${language} 代码进行审查。

审查重点：${focusInstructions[focus]}

代码：
\`\`\`${language}
${code}
\`\`\`

请按照以下格式输出审查结果：
1. 【严重问题】必须立即修复
2. 【建议改进】推荐优化
3. 【风格建议】可选改进
4. 【亮点】做得好的地方`,
          },
        },
      ],
    };
  }
);
```

### 5.2 更多提示模板示例

```typescript
// API 文档生成提示
server.prompt(
  "generate-api-docs",
  "为代码生成 API 文档",
  {
    endpoint_code: z.string().describe("API 端点代码"),
    framework: z.string().default("express").describe("使用的框架"),
  },
  async ({ endpoint_code, framework }) => {
    return {
      messages: [
        {
          role: "user",
          content: {
            type: "text",
            text: `请为以下 ${framework} API 端点生成完整的文档，包括：
- 端点描述
- 请求方法和路径
- 请求参数（Query/Body/Path）
- 响应格式
- 错误码说明
- 使用示例

代码：
${endpoint_code}`,
          },
        },
      ],
    };
  }
);

// Bug 调试提示
server.prompt(
  "debug-assistant",
  "调试辅助提示模板",
  {
    error_message: z.string().describe("错误信息"),
    relevant_code: z.string().describe("相关代码"),
    context: z.string().optional().describe("额外上下文"),
  },
  async ({ error_message, relevant_code, context }) => {
    return {
      messages: [
        {
          role: "user",
          content: {
            type: "text",
            text: `我遇到了以下错误：

${error_message}

相关代码：
${relevant_code}

${context ? `额外上下文：${context}` : ""}

请帮我分析可能的原因并提供修复方案。`,
          },
        },
      ],
    };
  }
);
```

---

## 6. 传输层配置

### 6.1 stdio 传输（本地开发推荐）

```typescript
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";

async function main() {
  const server = new McpServer({ name: "my-server", version: "1.0.0" });
  // ... 注册 tools/resources/prompts ...

  const transport = new StdioServerTransport();
  await server.connect(transport);
}

main().catch(console.error);
```

**配置 Claude Desktop 使用 stdio 传输：**

```json
// ~/Library/Application Support/Claude/claude_desktop_config.json (macOS)
// %APPDATA%\Claude\claude_desktop_config.json (Windows)
{
  "mcpServers": {
    "my-server": {
      "command": "node",
      "args": ["/path/to/my-mcp-server/dist/index.js"],
      "env": {
        "API_KEY": "your-api-key"
      }
    }
  }
}
```

### 6.2 HTTP SSE 传输（远程部署）

```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { SSEServerTransport } from "@modelcontextprotocol/sdk/server/sse.js";
import express from "express";

const app = express();

app.get("/sse", async (req, res) => {
  const transport = new SSEServerTransport("/messages", res);
  const server = new McpServer({ name: "my-server", version: "1.0.0" });
  // ... 注册 tools/resources/prompts ...
  await server.connect(transport);

  // 处理客户端消息
  app.post("/messages", async (req, res) => {
    await transport.handlePostMessage(req, res);
  });
});

app.listen(3001, () => {
  console.log("MCP SSE Server 运行在 http://localhost:3001");
});
```

### 6.3 Streamable HTTP 传输

```typescript
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { StreamableHTTPServerTransport } from "@modelcontextprotocol/sdk/server/streamableHttp.js";
import express from "express";

const app = express();
app.use(express.json());

const server = new McpServer({ name: "my-server", version: "1.0.0" });
// ... 注册 tools/resources/prompts ...

let transport: StreamableHTTPServerTransport;

app.post("/mcp", async (req, res) => {
  if (!transport) {
    transport = new StreamableHTTPServerTransport({ sessionIdGenerator: () => crypto.randomUUID() });
    await server.connect(transport);
  }
  await transport.handleRequest(req, res);
});

app.get("/mcp", async (req, res) => {
  if (!transport) {
    res.status(404).send("Not initialized. Send a POST request first.");
    return;
  }
  await transport.handleRequest(req, res);
});

app.delete("/mcp", async (req, res) => {
  if (transport) {
    await transport.handleRequest(req, res);
    transport = null;
  }
});

app.listen(3001, () => {
  console.log("MCP Streamable HTTP Server 运行在 http://localhost:3001/mcp");
});
```

---

## 7. 认证与安全模式

### 7.1 API Key 认证

```typescript
// 简单的 API Key 验证中间件
function createAuthMiddleware(validKeys: string[]) {
  return (req: express.Request, res: express.Response, next: express.NextFunction) => {
    const authHeader = req.headers.authorization;

    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      res.status(401).json({ error: "缺少认证令牌" });
      return;
    }

    const token = authHeader.slice(7);
    if (!validKeys.includes(token)) {
      res.status(403).json({ error: "无效的认证令牌" });
      return;
    }

    next();
  };
}

// 使用中间件
app.use("/mcp", createAuthMiddleware([
  process.env.API_KEY_1!,
  process.env.API_KEY_2!,
]));
```

### 7.2 安全最佳实践

```typescript
// 1. 输入验证和清理
const safeString = z.string()
  .max(10000)                    // 限制长度
  .transform(s => s.trim())      // 清理空格
  .refine(s => !s.includes("<script>"), { message: "不允许脚本标签" });

// 2. 敏感信息过滤
function sanitizeOutput(data: any): any {
  const sensitiveFields = ["password", "token", "secret", "apiKey", "creditCard"];
  const sanitized = { ...data };

  for (const field of sensitiveFields) {
    if (field in sanitized) {
      sanitized[field] = "***REDACTED***";
    }
  }

  return sanitized;
}

// 3. 操作速率限制
const rateLimiter = new Map<string, { count: number; resetTime: number }>();

function checkRateLimit(clientId: string, maxRequests: number = 60, windowMs: number = 60000): boolean {
  const now = Date.now();
  const record = rateLimiter.get(clientId);

  if (!record || now > record.resetTime) {
    rateLimiter.set(clientId, { count: 1, resetTime: now + windowMs });
    return true;
  }

  if (record.count >= maxRequests) {
    return false;
  }

  record.count++;
  return true;
}
```

---

## 8. 测试 MCP 服务器

### 8.1 使用 MCP Inspector 调试

```bash
# 安装并启动 MCP Inspector
npx @modelcontextprotocol/inspector node dist/index.js

# 或使用 URL 连接
npx @modelcontextprotocol/inspector --url http://localhost:3001/mcp
```

MCP Inspector 提供以下功能：
- 列出所有 tools/resources/prompts
- 手动调用工具并查看结果
- 查看通信日志
- 测试不同的输入参数

### 8.2 编写自动化测试

```typescript
// tests/tools.test.ts
import { Client } from "@modelcontextprotocol/sdk/client/index.js";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { spawn } from "child_process";

async function createTestClient() {
  const client = new Client({ name: "test-client", version: "1.0.0" });

  const serverProcess = spawn("node", ["dist/index.js"]);
  const transport = new StdioClientTransport({
    reader: serverProcess.stdout,
    writer: serverProcess.stdin,
  });

  await client.connect(transport);
  return { client, cleanup: () => serverProcess.kill() };
}

describe("MCP Server Tools", () => {
  let client: Client;
  let cleanup: () => void;

  beforeAll(async () => {
    ({ client, cleanup } = await createTestClient());
  });

  afterAll(() => {
    cleanup();
  });

  test("calculate 工具应该正确计算", async () => {
    const result = await client.callTool({
      name: "calculate",
      arguments: { expression: "2 + 3 * 4" },
    });

    expect(result.content[0].text).toContain("14");
  });

  test("无效表达式应该返回错误", async () => {
    const result = await client.callTool({
      name: "calculate",
      arguments: { expression: "invalid ///" },
    });

    expect(result.isError).toBe(true);
  });
});
```

---

## 9. 发布到 MCP 目录

### 9.1 Smithery 发布

```bash
# 安装 Smithery CLI
npm install -g @smithery/cli

# 初始化 Smithery 配置
smithery init

# 发布到 Smithery
smithery publish

# 安装你的 MCP 服务器
npx @smithery/cli install @your-username/my-mcp-server
```

### 9.2 在 Claude Desktop 中使用

编辑 Claude Desktop 配置文件：

- **macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
- **Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "my-server": {
      "command": "npx",
      "args": ["-y", "@your-username/my-mcp-server"],
      "env": {
        "API_KEY": "your-api-key-here"
      }
    }
  }
}
```

### 9.3 在 Cursor 中使用

在 Cursor 设置中的 MCP 配置中添加：

```json
{
  "mcpServers": {
    "my-server": {
      "command": "node",
      "args": ["/absolute/path/to/dist/index.js"]
    }
  }
}
```

---

## 10. 调试与故障排除

### 10.1 常见问题

| 问题 | 原因 | 解决方案 |
|------|------|---------|
| 连接超时 | stdio 传输未正确初始化 | 确保服务器正确连接 transport |
| 工具不可见 | 工具未正确注册 | 检查 server.tool() 调用 |
| 参数验证失败 | Zod schema 与输入不匹配 | 检查参数类型和约束 |
| 权限错误 | 文件系统访问受限 | 检查文件路径和权限 |
| JSON-RPC 错误 | 协议格式不正确 | 使用 MCP Inspector 检查通信 |

### 10.2 调试日志

```typescript
// 启用调试日志
const DEBUG = process.env.DEBUG === "true";

function debugLog(message: string, data?: any) {
  if (DEBUG) {
    console.error(`[DEBUG] ${new Date().toISOString()} - ${message}`);
    if (data) {
      console.error(JSON.stringify(data, null, 2));
    }
  }
}

// 在工具中使用
server.tool("debug_tool", "调试工具", { input: z.string() }, async ({ input }) => {
  debugLog("收到请求", { input });
  // ... 处理逻辑 ...
  debugLog("处理完成");
  return { content: [{ type: "text", text: "完成" }] };
});
```

### 10.3 性能优化

```typescript
// 1. 并行处理多个独立操作
async function parallelFetch(urls: string[]) {
  return Promise.all(urls.map(url => fetch(url)));
}

// 2. 结果缓存
const cache = new Map<string, { data: any; expiry: number }>();

function getCached<T>(key: string, ttl: number, fetcher: () => Promise<T>): Promise<T> {
  const cached = cache.get(key);
  if (cached && Date.now() < cached.expiry) {
    return Promise.resolve(cached.data);
  }

  return fetcher().then(data => {
    cache.set(key, { data, expiry: Date.now() + ttl });
    return data;
  });
}

// 3. 分页处理大数据集
server.tool(
  "list_large_dataset",
  "分页获取大数据集",
  { page: z.number().default(1), pageSize: z.number().default(50) },
  async ({ page, pageSize }) => {
    const offset = (page - 1) * pageSize;
    const data = await db.query("SELECT * FROM items LIMIT ? OFFSET ?", [pageSize, offset]);
    return { content: [{ type: "text", text: JSON.stringify(data) }] };
  }
);
```

---

## 11. 完整 Python MCP 服务器示例

```python
# server.py
from mcp.server.fastmcp import FastMCP

# 创建 MCP 服务器
mcp = FastMCP("my-python-server")

@mcp.tool()
def calculate(expression: str) -> str:
    """执行安全的数学计算
    
    Args:
        expression: 数学表达式，例如 '2 + 3 * 4'
    """
    try:
        # 安全计算（仅允许数字和运算符）
        import re
        sanitized = re.sub(r'[^0-9+\-*/().%\s]', '', expression)
        result = eval(sanitized)  # 已清理输入
        return f"计算结果：{expression} = {result}"
    except Exception as e:
        return f"计算错误：{e}"

@mcp.tool()
def get_weather(city: str, unit: str = "celsius") -> str:
    """获取指定城市的天气信息
    
    Args:
        city: 城市名称
        unit: 温度单位，celsius 或 fahrenheit
    """
    # 这里接入真实的天气 API
    return f"{city} 当前天气：晴，温度 25{unit[0].upper()}"

@mcp.resource("config://app")
def get_config() -> str:
    """获取应用配置"""
    return '{"name": "my-app", "version": "1.0.0"}'

@mcp.prompt()
def code_review(code: str, language: str) -> str:
    """生成代码审查提示"""
    return f"""请审查以下 {language} 代码：

```{language}
{code}
```

请提供改进建议。"""

if __name__ == "__main__":
    # stdio 传输（默认）
    mcp.run()

    # SSE 传输（远程部署）
    # mcp.run(transport="sse")
```

---

## 12. 快速参考

### 开发流程

1. **初始化项目** → 使用脚手架创建项目结构
2. **定义工具** → 使用 `server.tool()` 注册工具
3. **添加资源** → 使用 `server.resource()` 暴露数据
4. **创建提示** → 使用 `server.prompt()` 定义模板
5. **本地测试** → 使用 MCP Inspector 调试
6. **部署发布** → 推送到 npm/PyPI 或 MCP 目录
7. **客户端配置** → 在 Claude/Cursor 中配置连接

### 关键命令

```bash
# 开发
npm run dev              # 开发模式（TypeScript）
python server.py         # 开发模式（Python）

# 测试
npx @modelcontextprotocol/inspector node dist/index.js

# 构建
npm run build            # TypeScript 编译

# 发布
npm publish              # 发布到 npm
smithery publish         # 发布到 Smithery
```
