# MCP 服务器构建工具箱 (MCP Builder Kit)

> 作者：知白守黑1024

## 简介

MCP（Model Context Protocol）服务器构建工具箱是一个全面的 MCP 服务器开发指南和脚手架工具。提供从零开始构建 MCP 服务器的完整工作流，包括项目初始化、工具/资源/提示定义、传输层配置、认证安全、测试调试和发布部署。

## 核心功能

- **项目脚手架**：TypeScript 和 Python 双语言项目模板，快速启动开发
- **工具定义模式**：完整的 Tool 定义最佳实践，包括命名规范、参数验证和错误处理
- **资源定义模式**：静态和动态资源定义指南
- **提示模板模式**：可复用的 Prompt 模板设计
- **传输层配置**：支持 stdio、HTTP SSE、Streamable HTTP 三种传输方式
- **认证与安全**：API Key 认证、输入验证、速率限制等安全模式
- **测试调试**：MCP Inspector 调试工具和自动化测试方案
- **发布部署**：npm/PyPI 发布和 Claude Desktop、Cursor 等客户端配置

## 适用场景

| 场景 | 说明 |
|------|------|
| 构建自定义工具 | 为 AI 助手创建专属的函数工具 |
| 数据源集成 | 将数据库、API 等数据源暴露给 AI |
| 内部系统对接 | 让 AI 能操作企业内部系统 |
| 开源贡献 | 发布 MCP 服务器供社区使用 |
| 团队协作 | 统一团队 AI 工具开发标准 |

## 支持的语言

| 语言 | SDK | 推荐场景 |
|------|-----|---------|
| TypeScript | `@modelcontextprotocol/sdk` | 复杂逻辑、前后端统一 |
| Python | `mcp` | 数据处理、AI/ML 集成 |

## 配置说明

### 环境要求

- Node.js >= 18（TypeScript）
- Python >= 3.10（Python）
- npm 或 bun（包管理器）

### 客户端配置

在 Claude Desktop 配置文件中添加 MCP 服务器：

```json
{
  "mcpServers": {
    "my-server": {
      "command": "node",
      "args": ["/path/to/dist/index.js"],
      "env": { "API_KEY": "your-key" }
    }
  }
}
```

## 版本

v1.0.0
