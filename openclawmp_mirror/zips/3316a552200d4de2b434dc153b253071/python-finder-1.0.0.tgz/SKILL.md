---
name: python-finder
description: "跨平台 Python 解释器智能检测工具。自动发现系统中可用的 Python 命令（python3/python/py），返回最佳可用选项及其版本信息。解决不同操作系统和环境下的 Python 命令不一致问题。"
metadata:
  version: "1.0.0"
  author: "Vice"
  tags: ["python", "cross-platform", "environment", "detection"]
---

# Python Finder

智能检测系统中可用的 Python 解释器，解决跨平台 Python 命令不一致问题。

## 功能

- 自动检测 `python3`、`python`、`py` 等常见 Python 命令
- 返回最佳可用命令及其版本信息
- 支持 Windows、macOS、Linux 跨平台
- 提供 JSON 格式输出，便于脚本调用

## 使用场景

- 编写跨平台的自动化脚本
- 在不确定 Python 命令名称的环境中执行 Python 脚本
- 需要检测 Python 版本兼容性时

## 使用方法

### 命令行调用

```bash
# 基础用法 - 输出 JSON 格式的检测结果
python3 <skill-dir>/scripts/find_python.py

# 在 PowerShell 中
python C:/Users/EMan/.stepclaw/skills/python-finder/scripts/find_python.py
```

### 输出格式

```json
{
  "success": true,
  "command": "python3",
  "version": "Python 3.13.12",
  "path": "C:\\Users\\...\\python.exe",
  "all_found": [
    {
      "command": "python3",
      "version": "Python 3.13.12",
      "path": "..."
    },
    {
      "command": "python",
      "version": "Python 3.11.9",
      "path": "..."
    }
  ]
}
```

### 在脚本中使用

```python
import subprocess
import json

# 调用 python-finder 获取最佳 Python 命令
result = subprocess.run(
    ["python3", "path/to/find_python.py"],
    capture_output=True,
    text=True
)
data = json.loads(result.stdout)

if data["success"]:
    best_python = data["command"]
    # 使用检测到的命令执行其他脚本
    subprocess.run([best_python, "your_script.py"])
```

## 检测优先级

1. `python3` - 优先尝试（现代系统的标准）
2. `python` - 备选（Windows 和一些旧系统）
3. `py` - 最后尝试（Windows Python Launcher）

## 错误处理

如果未找到任何可用的 Python 解释器：

```json
{
  "success": false,
  "error": "未找到可用的 Python 解释器",
  "candidates": ["python3", "python", "py"]
}
```

## 注意事项

- 检测超时时间为 5 秒
- 返回的版本信息包含完整的版本字符串（如 "Python 3.13.12"）
- 路径信息可能因系统配置而异

## 依赖

- Python 3.7+
- 标准库：`subprocess`, `sys`, `os`, `pathlib`, `json`
