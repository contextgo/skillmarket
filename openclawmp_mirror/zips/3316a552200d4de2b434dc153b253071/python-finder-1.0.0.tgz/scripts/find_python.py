#!/usr/bin/env python3
"""
跨平台 Python 命令智能检测工具
自动发现可用的 Python 解释器并返回最佳命令

用法:
    python find_python.py              # 输出 JSON 格式的检测结果
    python find_python.py --best       # 只输出最佳命令名称
    python find_python.py --version    # 输出最佳命令的版本
    python find_python.py --path       # 输出最佳命令的完整路径
    python find_python.py --all        # 输出所有找到的 Python 解释器

返回代码:
    0 - 成功找到可用的 Python 解释器
    1 - 未找到任何可用的 Python 解释器
"""

import argparse
import json
import subprocess
import sys
from pathlib import Path
from typing import Optional


# 检测候选命令（按优先级排序）
CANDIDATES = ["python3", "python", "py"]


def check_python_cmd(cmd: str) -> tuple[bool, str, str]:
    """
    检查指定的 Python 命令是否可用
    
    Args:
        cmd: 要检查的命令名称
        
    Returns:
        (是否可用, 版本号, 完整路径)
    """
    try:
        # 检查 --version
        result = subprocess.run(
            [cmd, "--version"],
            capture_output=True,
            text=True,
            timeout=5
        )
        if result.returncode != 0:
            return False, "", ""
        
        version = (result.stdout.strip() or result.stderr.strip()).replace("Python ", "")
        
        # 获取完整路径
        path_result = subprocess.run(
            [cmd, "-c", "import sys; print(sys.executable)"],
            capture_output=True,
            text=True,
            timeout=5
        )
        full_path = path_result.stdout.strip() if path_result.returncode == 0 else cmd
        
        return True, version, full_path
        
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception):
        return False, "", ""


def parse_version(version_str: str) -> tuple[int, ...]:
    """解析版本字符串为元组，用于比较"""
    try:
        parts = version_str.split(".")
        return tuple(int(p) for p in parts[:3] if p.isdigit())
    except:
        return (0, 0, 0)


def find_all_pythons() -> list[dict]:
    """查找所有可用的 Python 解释器"""
    found = []
    
    for cmd in CANDIDATES:
        available, version, path = check_python_cmd(cmd)
        if available:
            found.append({
                "command": cmd,
                "version": version,
                "version_tuple": parse_version(version),
                "path": path
            })
    
    # 按版本号降序排序（优先使用更新的版本）
    found.sort(key=lambda x: x["version_tuple"], reverse=True)
    
    # 移除用于排序的临时字段
    for item in found:
        del item["version_tuple"]
    
    return found


def find_best_python() -> Optional[dict]:
    """
    查找最佳的 Python 解释器
    优先返回 python3（如果可用且版本较新），否则返回版本最新的
    """
    all_found = find_all_pythons()
    
    if not all_found:
        return None
    
    # 优先选择 python3（如果可用）
    python3_item = next((p for p in all_found if p["command"] == "python3"), None)
    if python3_item:
        return python3_item
    
    # 否则返回版本最新的
    return all_found[0]


def main():
    parser = argparse.ArgumentParser(
        description="跨平台 Python 解释器智能检测工具"
    )
    parser.add_argument(
        "--best",
        action="store_true",
        help="只输出最佳命令名称"
    )
    parser.add_argument(
        "--version",
        action="store_true",
        help="输出最佳命令的版本号"
    )
    parser.add_argument(
        "--path",
        action="store_true",
        help="输出最佳命令的完整路径"
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="输出所有找到的 Python 解释器"
    )
    
    args = parser.parse_args()
    
    if args.all:
        all_found = find_all_pythons()
        if all_found:
            print(json.dumps(all_found, indent=2, ensure_ascii=False))
            return 0
        else:
            print("未找到可用的 Python 解释器", file=sys.stderr)
            return 1
    
    best = find_best_python()
    
    if not best:
        if args.best:
            print("", end="")
        elif args.version:
            print("", end="")
        elif args.path:
            print("", end="")
        else:
            result = {
                "success": False,
                "error": "未找到可用的 Python 解释器",
                "candidates": CANDIDATES
            }
            print(json.dumps(result, indent=2, ensure_ascii=False))
        return 1
    
    if args.best:
        print(best["command"])
    elif args.version:
        print(best["version"])
    elif args.path:
        print(best["path"])
    else:
        all_found = find_all_pythons()
        result = {
            "success": True,
            "command": best["command"],
            "version": best["version"],
            "path": best["path"],
            "all_found": all_found
        }
        print(json.dumps(result, indent=2, ensure_ascii=False))
    
    return 0


if __name__ == "__main__":
    sys.exit(main())
