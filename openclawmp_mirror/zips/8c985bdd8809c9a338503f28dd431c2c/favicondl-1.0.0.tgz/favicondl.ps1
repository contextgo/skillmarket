#!/usr/bin/env pwsh
# FaviconDL - Download favicon via favicondl.com
# Usage: favicondl.ps1 <domain> [size] [output_path]

param(
    [Parameter(Mandatory=$true)][string]$Domain,
    [string]$Size = "128",
    [string]$Output = "./favicon.png"
)

$URL = "https://favicondl.com/api/favicon?domain=$Domain&size=$Size&format=redirect"

Write-Host "Fetching favicon for $Domain at ${Size}px..."

$bytes = curl.exe -L -s $URL -o $Output

if ($LASTEXITCODE -eq 0 -and (Test-Path $Output)) {
    $size = (Get-Item $Output).Length
    Write-Host "Saved: $Output ($size bytes)" -ForegroundColor Green
} else {
    Write-Host "Error: Failed to download favicon" -ForegroundColor Red
    exit 1
}
