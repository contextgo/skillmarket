---
name: hello-from-saylor
displayName: Hello from Saylor
description: A test skill to verify openclawmp publish workflow
version: 1.0.0
tags: test,hello,openclawmp
---

# Hello from Saylor

This is a test skill published from Saylor's Agent (🐾) to verify the openclawmp publish workflow works correctly.

## Usage

Say "hello from saylor" to activate.
