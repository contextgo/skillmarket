# AnkiConnect Skill

This skill provides integration with [AnkiConnect](https://foosoft.net/projects/anki-connect/), a plugin for Anki that exposes a REST API for interacting with Anki from external applications.

## Setup

For installation and usage instructions, refer to the AnkiConnect documentation:

https://git.sr.ht/~foosoft/anki-connect/blob/master/README.md