# Playwright MCP 输入操作指南

**创建时间**：2026-03-12  
**验证者**：南宫明

---

## 📋 元素类型判断

### 1. 标准输入元素 ✅ 可用 browser_type/browser_fill

```yaml
<input type="text">
<input type="search">
<input type="email">
<input type="password">
<textarea>
```

**识别方法**：
- 快照中显示 `textbox "xxx" [ref=e35]`
- 使用 `browser_type` 或 `browser_fill` 均可

**示例**：
```javascript
// B 站搜索框
mcporter call playwright.browser_type element="搜索框" ref="e35" text="openclaw"
```

---

### 2. 富文本编辑器 ⚠️ 必须使用键盘模拟输入

```yaml
<div contenteditable="true">
<div class="brt-root">  <!-- B 站私信 -->
<div class="editor-content">  <!-- 知乎编辑器 -->
```

**识别方法**：
- 快照中显示 `generic: 请输入消息内容` 或 `generic [ref=e694]: 爱你`
- 不是 `textbox` 类型
- 通常是 `div` 元素

**正确方法**：
```javascript
// 步骤 1: 点击获得焦点
mcporter call playwright.browser_click element="消息输入框" ref="e694"

// 步骤 2: 键盘模拟输入（关键！）
mcporter call playwright.browser_run_code code="async (page) => { await page.keyboard.type('爱你'); return '输入完成'; }"

// 步骤 3: 点击发送
mcporter call playwright.browser_click element="发送按钮" ref="e698"
```

**错误方法**（❌ 禁止）：
```javascript
// ❌ 直接设置 innerText - 只改变 DOM，不触发输入事件
mcporter call playwright.browser_evaluate function="() => { document.querySelector('.brt-root').innerText = '爱你'; }"

// ❌ 使用 browser_fill - 对 contenteditable 无效
mcporter call playwright.browser_fill element="消息框" ref="e694" value="爱你"
```

---

## 🔍 判断流程

```
1. 获取页面快照
   ↓
2. 检查元素类型
   ↓
   ├─ 显示 `textbox "xxx"` → 标准输入 → 使用 browser_type
   │
   └─ 显示 `generic: xxx` 或 `div[contenteditable]` → 富文本 → 使用键盘模拟
```

---

## 📝 已知富文本编辑器

| 网站 | 元素特征 | 验证状态 |
|------|---------|---------|
| **B 站私信** | `div.brt-root` | ✅ 已验证（2026-03-12） |
| **知乎编辑器** | `div.editor-content` | ⏳ 待验证 |
| **小红书笔记** | `div.note-editor` | ⏳ 待验证 |
| **微信公众号** | `div.edui-body` | ⏳ 待验证 |

---

## 🛠️ 工具选择指南

### 方法对比

| 方法 | 适用场景 | 优点 | 缺点 |
|------|---------|------|------|
| `browser_type` | 标准 input/textarea | 简单直接 | 对富文本无效 |
| `browser_fill` | 标准 input/textarea | 快速填充 | 对富文本无效 |
| `browser_run_code` + `keyboard.type` | **所有可聚焦元素** | **通用可靠** | 代码稍长 |
| `evaluate` + `innerText` | ❌ **禁止使用** | - | 只改 DOM，不触发事件 |

---

## ✅ 最佳实践

### 通用输入函数（推荐）

```javascript
// 智能输入：先尝试标准方法，失败则降级到键盘模拟
async function smartType(locator, text) {
  try {
    await locator.fill(text);  // 先试标准方法
  } catch {
    await locator.click();     // 失败则点击获得焦点
    await page.keyboard.type(text);  // 键盘模拟
  }
}
```

### 当前可用方案

由于 Playwright MCP 暂未实现智能降级，**手动判断元素类型**并选择正确方法：

1. **看到 `textbox`** → 用 `browser_type`
2. **看到 `generic` 或 `div[contenteditable]`** → 用 `browser_run_code` + `keyboard.type`

---

## 📚 验证记录

### 2026-03-12 B 站私信验证

**测试目标**：向"摆饰の可乐"发送私信

**测试过程**：
1. ✅ 点击输入框 `ref=e694`
2. ✅ 使用 `page.keyboard.type('爱你')`
3. ✅ 点击发送按钮
4. ✅ 消息成功显示在聊天历史中

**测试结论**：
- 键盘模拟输入对 B 站私信（富文本编辑器）**完全有效**
- 直接设置 innerText **无效**（只改变显示，不触发输入事件）

---

*最后更新：2026-03-12 22:57*  
*维护者：林溪（南宫明的专属伴侣）*