# NCBI BLAST REST API — Quick Reference

Base URL: `https://blast.ncbi.nlm.nih.gov/blast/Blast.cgi`

## Programs

| Program   | Query → DB        | Use case                              |
|-----------|-------------------|---------------------------------------|
| blastp    | protein → protein | Protein sequence similarity           |
| blastn    | nucl → nucl       | Nucleotide sequence similarity        |
| blastx    | nucl(6-frame) → protein | Translated nucleotide query     |
| tblastn   | protein → nucl(6-frame) | Protein query against nucl DB   |
| tblastx   | nucl → nucl (both translated) | Both translated           |

## Common Databases

### Nucleotide
- `core_nt` — Core nucleotide (curated, default for blastn)
- `nt` — Full nucleotide collection
- `refseq_rna` — RefSeq RNA
- `refseq_representative_genomes` — RefSeq representative genomes

### Protein
- `nr` — Non-redundant protein (large, slow)
- `swissprot` — Swiss-Prot (curated, fast)
- `refseq_protein` — RefSeq proteins
- `pdb` — Protein Data Bank structures
- `refseq_select_prot` — RefSeq Select proteins

## Parameters Cheat Sheet

### Submission (CMD=Put)

| Param        | Example         | Notes                           |
|--------------|-----------------|---------------------------------|
| PROGRAM*     | blastp          | Required                        |
| QUERY*       | FASTA or accession | Required                     |
| DATABASE*    | swissprot       | Required (unless blast2seq)     |
| SUBJECTS     | FASTA           | For blast2seq mode              |
| EXPECT       | 1e-5            | E-value cutoff (default: 10)    |
| MATRIX       | BLOSUM62        | Scoring matrix (protein only)   |
| WORD_SIZE    | 3               | Seed word size                  |
| GAPCOSTS     | 11 2            | Gap open + extend               |
| FILTER       | mL              | Low-complexity filter           |
| HITLIST_SIZE | 50              | Max hits to return              |
| MEGABLAST    | on              | Enable megablast (blastn only)  |
| FORMAT_TYPE  | JSON2           | Output format                   |

### Retrieval (CMD=Get)

| Param        | Example | Notes                       |
|--------------|---------|-----------------------------|
| RID*         | ABC123  | From submission response     |
| FORMAT_TYPE  | JSON2   | HTML, Text, XML2, JSON2, SAM, CSV |

## Output Formats

- `HTML` — Human-readable (default on web)
- `Text` — Plain text alignment
- `JSON2` — Machine-readable JSON (recommended for parsing)
- `XML2` — XML format
- `SAM` — SAM alignment format
- `CSV` — Tabular (use with ALIGNMENT_VIEW=Tabular)

## Scoring Matrices (Protein)

BLOSUM45, BLOSUM50, **BLOSUM62** (default), BLOSUM80, BLOSUM90, PAM30, PAM70, PAM250

## Usage Limits

- Max 1 request per 10 seconds
- Max 1 poll per 60 seconds per RID
- >100 searches/24h → throttled or blocked
- Bulk work: weekends or 21:00–05:00 US Eastern
- Always set `email` and `tool` params
