# Parsing BLAST Results

## JSON2 Format (Recommended)

JSON2 is the recommended machine-readable format. Structure:

```
{
  "BlastOutput2": [{
    "report": {
      "program": "blastp",
      "version": "...",
      "search_target": { "db": "swissprot" },
      "results": {
        "search": {
          "query_id": "...",
          "query_title": "...",
          "query_len": 123,
          "hits": [
            {
              "num": 1,
              "description": [{ "id": "sp|P01112|...", "accession": "P01112", "title": "..." }],
              "len": 189,
              "hsps": [{
                "num": 1,
                "bit_score": 123.4,
                "score": 315,
                "evalue": 1.23e-30,
                "identity": 100,
                "positive": 120,
                "query_from": 1,
                "query_to": 123,
                "hit_from": 1,
                "hit_to": 189,
                "align_len": 189,
                "gaps": 5,
                "qseq": "MTEY...",
                "hseq": "MTEY...",
                "midline": "MTEY..."
              }]
            }
          ],
          "stat": { ... }
        }
      }
    }
  }]
}
```

## Key Fields for Analysis

- `hits[].description[0].accession` — Hit accession number
- `hits[].description[0].title` — Hit description
- `hits[].hsps[].evalue` — Expect value (lower = more significant)
- `hits[].hsps[].bit_score` — Bit score (higher = better)
- `hits[].hsps[].identity` — Number of identical residues/bases
- `hits[].hsps[].align_len` — Alignment length
- `hits[].hsps[].gaps` — Gap count
- `hits[].hsps[].qseq` / `hseq` — Aligned sequences
- `hits[].hsps[].midline` — Alignment midline (matches/mismatches)

## Percent Identity Calculation

```
percent_identity = (identity / align_len) * 100
```

## Quick Python Parsing

```python
import json

with open("results.json") as f:
    data = json.load(f)

for report in data["BlastOutput2"]:
    search = report["report"]["results"]["search"]
    for hit in search.get("hits", []):
        desc = hit["description"][0]
        hsp = hit["hsps"][0]
        print(f"{desc['accession']}\t{desc['title'][:60]}\t"
              f"E={hsp['evalue']:.2e}\tScore={hsp['bit_score']:.1f}\t"
              f"Identity={hsp['identity']}/{hsp['align_len']}")
```
