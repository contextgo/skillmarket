---
name: blast-api
description: "Run NCBI BLAST sequence similarity searches via REST API. Supports blastp (protein-protein), blastn (nucleotide-nucleotide), blastx (translated nucleotide vs protein), tblastn (protein vs translated nucleotide), tblastx (both translated), and blast2seq (two-sequence alignment). Use when the user asks to BLAST a sequence, compare sequences, find homologs, check sequence similarity, align proteins or nucleotides, or search NCBI databases (nr, swissprot, core_nt, pdb, refseq). Triggers: BLAST, blastp, blastn, blastx, tblastn, sequence alignment, homology search, sequence similarity, NCBI BLAST, protein search, nucleotide search."
---

# BLAST API Skill

Run NCBI BLAST searches programmatically via `scripts/blast_search.py`. Zero dependencies beyond Python 3 stdlib.

## Quick Start

```bash
# Protein search against SwissProt
python scripts/blast_search.py -p blastp -d swissprot -q "MTEYKLVVVGAGGVGKSALT..."

# Nucleotide search with megablast
python scripts/blast_search.py -p blastn -d core_nt --megablast -qf sequence.fasta

# Translated search
python scripts/blast_search.py -p blastx -d swissprot -qf nucleotide.fasta

# Two-sequence alignment
python scripts/blast_search.py -p blastp -q "MTEY..." -s "MKKL..."

# Submit only (async)
python scripts/blast_search.py -p blastp -d nr -q "MTEY..." --submit-only
# → {"rid": "ABC123", "rtoe": 45}

# Fetch later
python scripts/blast_search.py --rid ABC123 -f JSON2 -o results.json
```

## Workflow

1. **Determine program** from query/target types:
   - Protein → protein DB: `blastp`
   - Nucleotide → nucleotide DB: `blastn` (add `--megablast` for highly similar seqs)
   - Nucleotide → protein DB: `blastx`
   - Protein → nucleotide DB: `tblastn`
   - Two sequences: add `--subject` instead of `--database`

2. **Choose database** — see [references/api-reference.md](references/api-reference.md) for full list:
   - Protein: `swissprot` (fast, curated), `nr` (comprehensive), `pdb` (structures)
   - Nucleotide: `core_nt` (curated), `nt` (full)

3. **Run script** — handles submission, polling (respects NCBI rate limits), and result retrieval automatically.

4. **Parse results** — default JSON2 format. See [references/parsing-results.md](references/parsing-results.md) for JSON structure and parsing patterns.

## Key Parameters

| Flag              | Purpose                         | Example                |
|-------------------|---------------------------------|------------------------|
| `-p / --program`  | BLAST program                   | blastp, blastn, blastx |
| `-d / --database` | Target database                 | swissprot, core_nt     |
| `-q / --query`    | Sequence string (FASTA/accession)| "MTEYKLVV..."         |
| `-qf / --query-file` | Input FASTA file             | input.fasta            |
| `-s / --subject`  | Second sequence (blast2seq)     | "MKKLVV..."            |
| `-sf / --subject-file` | Subject FASTA file          | subject.fasta          |
| `-e / --expect`   | E-value threshold               | 1e-5                   |
| `-m / --matrix`   | Scoring matrix                  | BLOSUM62               |
| `-f / --format`   | Output format                   | JSON2, Text, XML2      |
| `-o / --output`   | Save to file                    | results.json           |
| `--megablast`     | Enable megablast                | (flag)                 |
| `--hitlist-size`  | Max hits                        | 50                     |
| `--max-wait`      | Timeout in seconds              | 600                    |

## NCBI Rate Limits

The script respects these automatically, but be aware:
- **10s minimum** between any API requests
- **60s minimum** between polls for same RID
- **100 searches / 24h** soft limit before throttling
- For bulk work: use `--submit-only`, collect RIDs, fetch later

## Interpreting Results

Key metrics in output:
- **E-value**: Expected number of chance hits. Lower = more significant. `<1e-5` is generally significant.
- **Bit score**: Normalized score. Higher = better alignment.
- **Identity %**: `identity / align_len × 100`. >30% suggests homology for proteins.
- **Coverage**: Check `query_from/to` vs `query_len` to assess how much of the query aligned.

## References

- [API parameter reference](references/api-reference.md) — programs, databases, parameters, scoring matrices
- [Parsing results guide](references/parsing-results.md) — JSON2 structure, field meanings, Python parsing code
