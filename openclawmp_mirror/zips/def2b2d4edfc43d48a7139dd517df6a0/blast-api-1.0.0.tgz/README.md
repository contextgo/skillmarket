# NCBI BLAST API

通过 NCBI REST API 直接在对话中运行 BLAST 序列相似性搜索。支持全部五种 BLAST 程序（blastp / blastn / blastx / tblastn / tblastx）以及双序列比对（blast2seq），覆盖蛋白质和核酸序列分析的常见场景。

## 能力

- **蛋白质搜索** — blastp 查询 SwissProt、nr、PDB、RefSeq 等数据库
- **核酸搜索** — blastn / megablast 查询 core_nt、nt、RefSeq RNA 等数据库
- **翻译搜索** — blastx（核酸→蛋白库）、tblastn（蛋白→核酸库）、tblastx（双向翻译）
- **双序列比对** — 两条序列直接对齐，无需指定数据库
- **异步支持** — 可仅提交获取 RID，稍后轮询取结果
- **多种输出格式** — JSON2（推荐解析）、Text、XML2、HTML、SAM、CSV

## 特点

- 纯 Python 标准库实现，零额外依赖
- 自动遵守 NCBI 限速规则（10s 请求间隔、60s 轮询间隔）
- 支持 FASTA 字符串、Accession、GI 号及文件输入
- 内置结果解析参考文档和 Python 代码示例

## 适用场景

- 查找蛋白质/基因的同源序列
- 验证序列注释或物种归属
- 比较两条序列的相似度
- 在已知数据库中搜索未知序列的功能注释
- 结构生物学中寻找 PDB 模板

## 使用示例

```
帮我用 blastp 在 SwissProt 里搜一下这个蛋白序列：MTEYKLVVVGAGGVGKSALT...
把这两条蛋白序列做个比对
用 blastn 在 core_nt 里搜这个核酸序列
```
