#!/usr/bin/env python3
"""
NCBI BLAST REST API client.

Usage:
    # Submit + poll + fetch in one shot (default JSON2 output):
    python blast_search.py --program blastp --database swissprot --query "MTEYKLVVVGAGGVGKSALT..."

    # Submit only (returns RID):
    python blast_search.py --program blastn --database core_nt --query-file seq.fasta --submit-only

    # Poll / fetch existing RID:
    python blast_search.py --rid ABC123 --format JSON2

    # Two-sequence alignment (blast2seq):
    python blast_search.py --program blastp --query "MTEY..." --subject "MKKL..." --format Text

    # From FASTA file:
    python blast_search.py --program blastx --database swissprot --query-file input.fasta

    # Megablast:
    python blast_search.py --program blastn --database core_nt --query-file seq.fasta --megablast

Respects NCBI usage guidelines:
  - >=10s between requests
  - >=60s between polls for same RID
  - Includes email & tool parameters
"""

import argparse
import json
import re
import sys
import time
import urllib.parse
import urllib.request

BLAST_URL = "https://blast.ncbi.nlm.nih.gov/blast/Blast.cgi"
DEFAULT_TOOL = "openclaw-blast-skill"
DEFAULT_EMAIL = ""

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _post(params: dict) -> str:
    """POST to BLAST API, return response text."""
    data = urllib.parse.urlencode(params).encode("utf-8")
    req = urllib.request.Request(BLAST_URL, data=data, method="POST")
    req.add_header("User-Agent", DEFAULT_TOOL)
    with urllib.request.urlopen(req, timeout=120) as resp:
        return resp.read().decode("utf-8", errors="replace")


def _get(params: dict) -> str:
    """GET from BLAST API, return response text."""
    url = BLAST_URL + "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url)
    req.add_header("User-Agent", DEFAULT_TOOL)
    with urllib.request.urlopen(req, timeout=120) as resp:
        return resp.read().decode("utf-8", errors="replace")


def _extract_rid(html: str) -> str | None:
    """Extract RID from Put response."""
    m = re.search(r"RID\s*=\s*(\S+)", html)
    return m.group(1) if m else None


def _extract_rtoe(html: str) -> int:
    """Extract estimated wait time (RTOE) in seconds."""
    m = re.search(r"RTOE\s*=\s*(\d+)", html)
    return int(m.group(1)) if m else 30


def _check_status(rid: str) -> str:
    """Check search status. Returns: WAITING, READY, UNKNOWN, or FAILED."""
    text = _get({"CMD": "Get", "RID": rid, "FORMAT_OBJECT": "SearchInfo"})
    if "Status=WAITING" in text:
        return "WAITING"
    if "Status=FAILED" in text:
        return "FAILED"
    if "Status=UNKNOWN" in text:
        return "UNKNOWN"
    if "Status=READY" in text:
        return "READY"
    # Fallback heuristic
    if "WAITING" in text:
        return "WAITING"
    return "UNKNOWN"


# ---------------------------------------------------------------------------
# Core API
# ---------------------------------------------------------------------------

def submit_search(
    program: str,
    query: str,
    database: str | None = None,
    subject: str | None = None,
    megablast: bool = False,
    expect: float | None = None,
    matrix: str | None = None,
    word_size: int | None = None,
    gapcosts: str | None = None,
    filter_: str | None = None,
    hitlist_size: int | None = None,
    format_type: str = "JSON2",
    email: str = DEFAULT_EMAIL,
    tool: str = DEFAULT_TOOL,
    extra_params: dict | None = None,
) -> tuple[str, int]:
    """Submit a BLAST search. Returns (RID, estimated_seconds)."""

    params: dict = {
        "CMD": "Put",
        "PROGRAM": program,
        "QUERY": query,
        "FORMAT_TYPE": format_type,
    }

    # blast2seq mode: use SUBJECTS instead of DATABASE
    if subject:
        params["SUBJECTS"] = subject
        params["BLAST_SPEC"] = "blast2seq"
    elif database:
        params["DATABASE"] = database
    else:
        raise ValueError("Either --database or --subject is required")

    if megablast:
        params["MEGABLAST"] = "on"
    if expect is not None:
        params["EXPECT"] = str(expect)
    if matrix:
        params["MATRIX"] = matrix
    if word_size is not None:
        params["WORD_SIZE"] = str(word_size)
    if gapcosts:
        params["GAPCOSTS"] = gapcosts
    if filter_ is not None:
        params["FILTER"] = filter_
    if hitlist_size is not None:
        params["HITLIST_SIZE"] = str(hitlist_size)
    if email:
        params["email"] = email
    if tool:
        params["tool"] = tool

    if extra_params:
        params.update(extra_params)

    body = _post(params)
    rid = _extract_rid(body)
    if not rid:
        print("ERROR: Failed to extract RID from BLAST response.", file=sys.stderr)
        print(body[:2000], file=sys.stderr)
        sys.exit(1)

    rtoe = _extract_rtoe(body)
    return rid, rtoe


def poll_until_ready(rid: str, rtoe: int = 30, max_wait: int = 600) -> str:
    """Poll until search is READY. Returns final status."""
    print(f"RID: {rid}", file=sys.stderr)
    print(f"Estimated wait: {rtoe}s", file=sys.stderr)

    # Initial wait — use RTOE but cap at 120s
    initial_wait = min(rtoe, 120)
    if initial_wait > 0:
        print(f"Waiting {initial_wait}s before first poll...", file=sys.stderr)
        time.sleep(initial_wait)

    elapsed = initial_wait
    poll_interval = 60  # NCBI requires >= 60s between polls

    while elapsed < max_wait:
        status = _check_status(rid)
        print(f"[{elapsed}s] Status: {status}", file=sys.stderr)

        if status == "READY":
            return status
        if status in ("FAILED", "UNKNOWN"):
            return status

        time.sleep(poll_interval)
        elapsed += poll_interval

    return "TIMEOUT"


def fetch_results(
    rid: str,
    format_type: str = "JSON2",
    descriptions: int | None = None,
    alignments: int | None = None,
) -> str:
    """Fetch results for a completed search."""
    params: dict = {
        "CMD": "Get",
        "RID": rid,
        "FORMAT_TYPE": format_type,
    }
    if descriptions is not None:
        params["DESCRIPTIONS"] = str(descriptions)
    if alignments is not None:
        params["ALIGNMENTS"] = str(alignments)

    return _get(params)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def main():
    p = argparse.ArgumentParser(
        description="NCBI BLAST REST API client",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )

    # Input
    p.add_argument("--query", "-q", help="Query sequence (accession, GI, or FASTA string)")
    p.add_argument("--query-file", "-qf", help="Path to query FASTA file")
    p.add_argument("--subject", "-s", help="Subject sequence for blast2seq")
    p.add_argument("--subject-file", "-sf", help="Path to subject FASTA file")

    # Program & DB
    p.add_argument("--program", "-p", choices=["blastn", "blastp", "blastx", "tblastn", "tblastx"],
                    default="blastp", help="BLAST program (default: blastp)")
    p.add_argument("--database", "-d", help="Database name (e.g. core_nt, swissprot, nr, refseq_protein)")
    p.add_argument("--megablast", action="store_true", help="Enable megablast (blastn only)")

    # Parameters
    p.add_argument("--expect", "-e", type=float, help="E-value threshold")
    p.add_argument("--matrix", "-m", help="Scoring matrix (e.g. BLOSUM62, PAM250)")
    p.add_argument("--word-size", "-w", type=int, help="Word size")
    p.add_argument("--gapcosts", "-g", help="Gap costs as 'existence extension' (e.g. '11 2')")
    p.add_argument("--filter", help="Low complexity filter (T/F/L/mL)")
    p.add_argument("--hitlist-size", type=int, help="Max number of hits to keep")

    # Output
    p.add_argument("--format", "-f", default="JSON2",
                    choices=["HTML", "Text", "XML2", "JSON2", "JSON2_S", "SAM", "CSV"],
                    help="Output format (default: JSON2)")
    p.add_argument("--descriptions", type=int, help="Number of descriptions")
    p.add_argument("--alignments", type=int, help="Number of alignments")

    # Mode
    p.add_argument("--rid", help="Existing RID to poll/fetch (skip submission)")
    p.add_argument("--submit-only", action="store_true", help="Submit and print RID, don't wait")
    p.add_argument("--max-wait", type=int, default=600, help="Max seconds to wait (default: 600)")

    # Meta
    p.add_argument("--email", default=DEFAULT_EMAIL, help="Contact email for NCBI")
    p.add_argument("--tool", default=DEFAULT_TOOL, help="Tool name for NCBI")

    # Output file
    p.add_argument("--output", "-o", help="Save results to file instead of stdout")

    args = p.parse_args()

    # Resolve query
    query = args.query
    if args.query_file:
        with open(args.query_file, "r") as fh:
            query = fh.read().strip()
    
    # Resolve subject
    subject = args.subject
    if args.subject_file:
        with open(args.subject_file, "r") as fh:
            subject = fh.read().strip()

    # Mode: fetch existing RID
    if args.rid:
        rid = args.rid
        status = poll_until_ready(rid, max_wait=args.max_wait)
        if status != "READY":
            print(f"ERROR: Search status = {status}", file=sys.stderr)
            sys.exit(1)
        result = fetch_results(rid, args.format, args.descriptions, args.alignments)
    else:
        # Need a query
        if not query:
            p.error("--query or --query-file is required for submission")

        rid, rtoe = submit_search(
            program=args.program,
            query=query,
            database=args.database,
            subject=subject,
            megablast=args.megablast,
            expect=args.expect,
            matrix=args.matrix,
            word_size=args.word_size,
            gapcosts=args.gapcosts,
            filter_=args.filter,
            hitlist_size=args.hitlist_size,
            format_type=args.format,
            email=args.email,
            tool=args.tool,
        )

        if args.submit_only:
            print(json.dumps({"rid": rid, "rtoe": rtoe}))
            return

        status = poll_until_ready(rid, rtoe, args.max_wait)
        if status != "READY":
            print(f"ERROR: Search status = {status}", file=sys.stderr)
            sys.exit(1)
        result = fetch_results(rid, args.format, args.descriptions, args.alignments)

    # Output
    if args.output:
        with open(args.output, "w", encoding="utf-8") as fh:
            fh.write(result)
        print(f"Results saved to {args.output}", file=sys.stderr)
    else:
        print(result)


if __name__ == "__main__":
    main()
