const fs = require('fs');
const path = require('path');

class OpenClawMPLoginSkill {
    constructor() {
        this.name = 'openclawmp-login';
        this.displayName = 'OpenClawMP登录页面';
        this.version = '1.0.0';
        this.description = '水产市场登录页面，提供GitHub、邮箱和微信登录选项';
    }

    async getInfo() {
        return {
            name: this.name,
            displayName: this.displayName,
            version: this.version,
            description: this.description,
            author: 'SkillCraft Team',
            tags: ['openclawmp', 'login', 'authentication'],
            category: 'utility',
            createdAt: '2026-04-07',
            updatedAt: '2026-04-07'
        };
    }

    async getTools() {
        return [
            {
                name: 'getLoginPage',
                description: '获取OpenClawMP登录页面',
                parameters: {
                    type: 'object',
                    properties: {
                        format: {
                            type: 'string',
                            enum: ['html', 'text'],
                            default: 'html',
                            description: '返回格式'
                        }
                    }
                }
            }
        ];
    }

    async executeTool(toolName, parameters) {
        if (toolName === 'getLoginPage') {
            const htmlPath = path.join(__dirname, 'openclawmp-login.html');
            if (fs.existsSync(htmlPath)) {
                const htmlContent = fs.readFileSync(htmlPath, 'utf8');
                if (parameters.format === 'text') {
                    return {
                        success: true,
                        content: htmlContent.replace(/<[^>]*>/g, '')
                    };
                } else {
                    return {
                        success: true,
                        content: htmlContent
                    };
                }
            } else {
                return {
                    success: false,
                    error: '登录页面文件不存在'
                };
            }
        }
        return {
            success: false,
            error: '工具不存在'
        };
    }
}

module.exports = OpenClawMPLoginSkill;