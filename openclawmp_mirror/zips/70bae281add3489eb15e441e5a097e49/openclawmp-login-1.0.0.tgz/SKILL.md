---
name: openclawmp-login
version: 1.0.0
displayName: OpenClawMP登录页面
description: 水产市场登录页面，提供GitHub、邮箱和微信登录选项
author: SkillCraft Team
tags: openclawmp, login, authentication
---

# OpenClawMP登录页面

## 功能描述

此技能提供了OpenClawMP水产市场的登录页面，包含以下功能：

- 提供GitHub、邮箱和微信三种登录方式
- 显示登录提示和注意事项
- 包含用户协议、平台管理规则及公约、隐私政策的链接
- 响应式设计，适配不同设备

## 使用场景

- 作为OpenClawMP平台的登录入口
- 用于测试和演示登录流程
- 作为自定义登录页面的模板

## 技术实现

- 使用HTML5和CSS3构建
- 响应式设计，适配不同屏幕尺寸
- 简洁的用户界面，提供良好的用户体验

## 资源文件

- `openclawmp-login.html` - 登录页面HTML文件