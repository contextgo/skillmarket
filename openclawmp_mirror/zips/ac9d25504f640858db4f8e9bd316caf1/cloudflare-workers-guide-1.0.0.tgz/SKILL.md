---
name: cloudflare-workers-guide
description: "Cloudflare Workers development patterns - serverless edge computing with sub-millisecond cold starts"
version: 1.0.0
tags: ["cloudflare", "workers", "serverless", "edge", "performance"]
---

# Cloudflare Workers Guide

Cloudflare Workers run code at the edge across 300+ cities, with zero cold starts.

## Core Concepts

- **Edge Runtime**: V8 isolates for instant startup
- **KV Storage**: Eventually consistent global key-value store
- **D1**: Serverless SQLite database
- **R2**: S3-compatible object storage

## Basic Worker

```typescript
export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    return Response.json({ message: "Hello from edge!" });
  },
};
```

## Wrangler CLI

```bash
npx wrangler init my-worker
npx wrangler dev       # Local development
npx wrangler deploy    # Deploy to production
```

## KV Usage

```typescript
await env.MY_KV.put("key", JSON.stringify({ value: 42 }));
const data = await env.MY_KV.get("key", "json");
```

## Best Practices

- Keep Workers under 10MB
- Use KV for caching, not primary storage
- Set appropriate cache headers
- Use `ctx.waitUntil()` for background work
