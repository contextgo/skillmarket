# Observability Stack Setup Guide

## Three Pillars

### Metrics (Prometheus)
- Counter: monotonically increasing (requests_total)
- Gauge: current value (memory_usage)
- Histogram: distribution (request_duration)
- Summary: quantiles (response_size)

### Logs (Loki)
- Structured logging (JSON format)
- Labels for filtering (app, env, level)
- Correlate with traces via trace_id
- LogQL for query language

### Traces (Jaeger/Tempo)
- Span: single operation
- Trace: collection of spans
- Context propagation: trace_id + span_id
- Sampling strategy: head-based or tail-based

## Architecture
```
App → Prometheus (metrics) → Grafana (dashboard)
App → Loki (logs) → Grafana (explore)
App → Jaeger (traces) → Grafana (trace view)
AlertManager → Slack/PagerDuty (alerts)
```

## Key Dashboards

### RED Metrics (Request-oriented)
- Rate: requests/sec per endpoint
- Errors: error rate (5xx) per endpoint
- Duration: P50/P95/P99 latency

### USE Metrics (Resource-oriented)
- Utilization: CPU/Memory/Disk %
- Saturation: queue length, load average
- Errors: hardware/OS error rate

## Alerting Rules
- P99 latency > threshold for 5min
- Error rate > 1% for 3min
- Disk usage > 85%
- Pod restart > 3 in 10min

## SLO/SLI
- SLO: 99.9% availability
- SLI: successful requests / total requests
- Error budget: 0.1% per month
- Burn rate alerting