# FitClaw Public Core — Usage Guide v1

## How to think about this package

This package is best used as a **workflow layer**.
It is not a full private production deployment.

Use it when you want a public-safe coaching foundation.

---

## Recommended reading order

1. `SKILL.md`
2. `references/public-description-v1.md`
3. `references/fitclaw-onboarding-public.md`
4. `references/fitclaw-hydration-public.md`
5. `references/fitclaw-nutrition-public.md`
6. `references/fitclaw-training-public.md`

---

## Typical ways to use it

### 1. Learn the workflow
Read each module as a reusable coaching pattern.

### 2. Repackage into your own agent
Use the public-safe modules as building blocks for:
- onboarding
- habit support
- nutrition guidance
- training structure

### 3. Extend with private layers
If you run your own private deployment, you can later add:
- your own memory system
- your own internal knowledge base
- your own notification / reporting / media flows

Do not assume those private layers are part of this public package.

---

## Best use cases

This package is especially useful for:
- AI coaching agent builders
- workflow designers
- prompt/skill architects
- people turning a private coaching method into reusable public-safe assets

---

## Important boundary

Do not mistake this package for a full turnkey coaching business system.

It gives you a structured method layer.
It does not include private production data, private credentials, or private operating assets.

---

## One-line usage guidance

**Use FitClaw Public Core when you want the coaching workflow logic without the private production layer.**
