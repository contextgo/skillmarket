# FitClaw Public Core — Public Description v1

## What it is

**FitClaw Public Core** is a public-safe coaching workflow package extracted from the FitClaw project.

It packages four reusable coaching modules:
1. onboarding
2. hydration support
3. nutrition guidance
4. training framework guidance

This package is designed to show the **method** behind the coaching system without exposing:
- private user data,
- live runtime configuration,
- internal credentials,
- or production-only assets.

---

## Who it is for

This package is useful for people who want to:
- study a structured AI fitness coaching workflow,
- reuse a coaching methodology in their own agent,
- understand how onboarding / hydration / nutrition / training can be connected into one system,
- or build a safer public-facing foundation before adding private production data.

---

## What makes it valuable

FitClaw Public Core is not just “fitness advice.”

Its value is that it turns coaching into a **repeatable workflow**:
- welcome the user without friction,
- build a usable baseline,
- create simple adherence loops,
- give macro-based nutrition guidance,
- and generate a training structure that can evolve through feedback.

---

## What is included

### 1. Onboarding
A lightweight but structured intake workflow that helps an AI coach:
- establish trust,
- collect the minimum baseline,
- and move the user into the next useful step without overwhelming them.

### 2. Hydration
A practical hydration coaching workflow that:
- estimates a usable daily target,
- translates it into a simple routine,
- and keeps the user consistent without fake precision.

### 3. Nutrition
A macro-oriented nutrition workflow that:
- evaluates meal structure,
- prioritizes protein and food composition,
- and turns vague diet advice into more actionable coaching.

### 4. Training
A training-structure workflow that:
- chooses an appropriate split,
- calibrates starting loads conservatively,
- and treats training as an evolving loop instead of a fixed template.

---

## What is NOT included

This public package does **not** include:
- private user records,
- private images or reports,
- internal credentials,
- live model/auth configuration,
- or private production scripts.

It is a **public-safe workflow layer**, not the full private FitClaw operating system.

---

## Example use cases

- “I want to build a coaching agent and need a clean onboarding module.”
- “I want a hydration support flow that feels practical, not robotic.”
- “I want to see how macro-based nutrition guidance can be structured into a reusable skill.”
- “I want a training framework that balances split logic, load calibration, and feedback loops.”

---

## Suggested usage pattern

A builder can use this package as:
1. a direct workflow reference,
2. a seed for a larger coaching agent,
3. or a public-safe base layer before adding private domain memory and private runtime integrations.

---

## One-line summary

**FitClaw Public Core is a public-safe AI fitness coaching workflow pack that turns onboarding, hydration, nutrition, and training into reusable coaching modules.**
