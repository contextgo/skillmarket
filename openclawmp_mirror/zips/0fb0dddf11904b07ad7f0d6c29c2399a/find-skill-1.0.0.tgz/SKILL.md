---
name: find-skill
version: "1.0.0"
last_updated: "2026-04-07"
changelog: "- initial release"
description: "技能查找工具，搜索和安装ClawHub技能。触发词：find skill、搜索技能、skill search。&"
metadata:
  {
    "openclaw":
      {
        "requires": { "bins": ["find", "clawhub"] },
        "user-invocable": true
      },
  }
---

# Find Skill 全能搜索工具

## 两大核心功能
### 一、本地文件搜索
和之前功能完全一致，支持按名称、类型、大小、时间等条件搜索本地文件和目录。

#### 常用命令
```bash
# 按文件名搜索
find-file <搜索目录> "*关键词*"

# 搜索所有md文件
find-file ~ "*.md" -type f

# 搜索大于100MB的大文件
find-file . -size +100M -type f

# 搜索最近24小时修改的文件
find-file . -mtime -1 -type f
```

---
### 二、ClawHub技能搜索/安装/管理
新增技能市场管理功能，一站式搜索、安装、更新、卸载所有公开技能。

#### 1. 搜索技能
```bash
find-skill search "关键词"
```
示例：搜索所有AI相关技能
```
find-skill search "AI"
```

#### 2. 安装技能
```bash
find-skill install <技能名称>
```
示例：安装summarize技能
```
find-skill install summarize
```
自动安装到当前工作区的skills目录下，覆盖旧版本。

#### 3. 批量安装多个技能
```bash
find-skill install summarize web-search tavily-search
```

#### 4. 查看已安装技能列表
```bash
find-skill list
```

#### 5. 更新已安装技能
```bash
# 更新单个技能
find-skill update <技能名称>

# 更新所有已安装技能到最新版本
find-skill update --all
```

#### 6. 卸载技能
```bash
find-skill uninstall <技能名称>
```

#### 7. 查看技能详情
```bash
find-skill info <技能名称>
```
返回技能的功能说明、版本号、作者、依赖等详细信息。

---
## 特点
✅ 一站式管理：本地文件搜索+技能市场管理二合一
✅ 自动去重：安装技能时自动检查是否已安装，避免重复
✅ 自动更新：支持一键更新所有技能到最新官方版本
✅ 依赖检查：安装技能时自动检查依赖是否满足，提示缺失依赖
