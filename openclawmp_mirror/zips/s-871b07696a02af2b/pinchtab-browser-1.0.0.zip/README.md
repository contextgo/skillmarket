# PinchTab 浏览器自动化技能

> **专为 AI Agent 设计的浏览器控制 API**

---

## 📖 概述

PinchTab 是一个独立的 HTTP 服务器，让 AI Agent 直接控制 Chrome 浏览器。

### 核心特性

- ✅ **12MB Go 二进制** - 轻量级，高性能
- ✅ **HTTP API** - RESTful 接口，易于调用
- ✅ **Token 高效** - 优化 token 使用（800 tokens vs 10,000）
- ✅ **多实例管理** - 支持多个浏览器实例并行运行
- ✅ **Stealth 模式** - 避免被网站检测
- ✅ **实时仪表盘** - 监控所有实例状态

---

## 🚀 快速开始

### 1. 安装 PinchTab

```bash
# 克隆仓库
git clone https://github.com/pinchtab/pinchtab.git
cd pinchtab

# 运行安装脚本
./doctor.sh

# 构建二进制
go build ./cmd/pinchtab
```

### 2. 启动服务器

```bash
pinchtab
```

服务器将在 `http://localhost:9867` 启动

---

## 🔧 命令行工具

### 浏览器控制

```bash
# 导航到 URL
pinchtab nav https://pinchtab.com

# 获取页面快照
pinchtab snap -i

# 点击元素（通过 ref）
pinchtab click e5

# 提取文本（Token 高效）
pinchtab text
```

### 实例管理

```bash
# 创建实例
curl -s -X POST http://localhost:9867/instances/launch \
  -H "Content-Type: application/json" \
  -d '{"name":"work","mode":"headless"}'

# 在实例中打开标签页
TAB=$(curl -s -X POST http://localhost:9867/instances/$INST/tabs/open \
  -H "Content-Type: application/json" \
  -d '{"url":"https://pinchtab.com"}' | jq -r '.tabId')

# 获取快照
curl "http://localhost:9867/tabs/$TAB/snapshot?filter=interactive"

# 点击元素
curl -X POST "http://localhost:9867/tabs/$TAB/action" \
  -H "Content-Type: application/json" \
  -d '{"kind":"click","ref":"e5"}'
```

---

## 📊 API 竽点

### 实例管理

| 端点 | 方法 | 说明 |
|------|------|------|
| `/instances/launch` | POST | 创建新实例 |
| `/instances/start` | POST | 启动实例 |
| `/instances` | GET | 列出所有实例 |
| `/instances/{id}` | GET | 获取实例详情 |
| `/instances/{id}` | DELETE | 删除实例 |

### 标签页管理

| 端点 | 方法 | 说明 |
|------|------|------|
| `/instances/{id}/tabs/open` | POST | 打开新标签页 |
| `/instances/{id}/tabs` | GET | 列出所有标签页 |
| `/tabs/{id}/snapshot` | GET | 获取页面快照 |
| `/tabs/{id}/action` | POST | 执行操作（点击、输入等） |

---

## 🎯 使用场景

### 1. 网页抓取

```bash
# 创建实例
INST=$(curl -s -X POST http://localhost:9867/instances/launch \
  -H "Content-Type: application/json" \
  -d '{"name":"scraper","mode":"headless"}' | jq -r '.id')

# 打开目标页面
TAB=$(curl -s -X POST http://localhost:9867/instances/$INST/tabs/open \
  -H "Content-Type: application/json" \
  -d '{"url":"https://example.com"}' | jq -r '.tabId')

# 提取数据
curl "http://localhost:9867/tabs/$TAB/snapshot?filter=interactive"
```

### 2. 自动化测试

```bash
# 创建实例（非 headless 模式）
curl -s -X POST http://localhost:9867/instances/launch \
  -H "Content-Type: application/json" \
  -d '{"name":"test","mode":"normal"}'

# 执行测试流程...
```

### 3. AI Agent 浏览

```bash
# Token 高效提取
pinchtab text  # 仅 800 tokens

# 点击交互
pinchtab click e5

# 表单填写
pinchtab fill e3 "user@pinchtab.com"
```

---

## 🔒 安全特性

- **Stealth 注入** - 避免被检测为自动化工具
- **Profile 隔离** - 每个实例独立的浏览器配置
- **Cookie 管理** - 自动处理 cookies
- **请求拦截** - 监控和修改网络请求

---

## 📈 性能对比

| 特性 | PinchTab | Puppeteer | Playwright |
|------|----------|-----------|------------|
| **Token 消耗** | 800 | 10,000+ | 10,000+ |
| **启动时间** | <1s | 2-3s | 2-3s |
| **内存占用** | 50MB | 100MB+ | 100MB+ |
| **并发实例** | 10+ | 5 | 5 |
| **AI 友好** | ✅ | ⚠️ | ⚠️ |

---

## 🛠️ 高级功能

### 1. 多实例并行

```bash
# 同时启动 3 个实例
curl -s -X POST http://localhost:9867/instances/start \
  -H "Content-Type: application/json" \
  -d '{"profileId":"alice","mode":"headless"}'

curl -s -X POST http://localhost:9867/instances/start \
  -H "Content-Type: application/json" \
  -d '{"profileId":"bob","mode":"headless"}'

curl -s -X POST http://localhost:9867/instances/start \
  -H "Content-Type: application/json" \
  -d '{"profileId":"charlie","mode":"headless"}'
```

### 2. 实时监控

访问 `http://localhost:9867/dashboard` 查看所有实例的实时状态。

---

## 📚 相关资源

- **GitHub**: https://github.com/pinchtab/pinchtab
- **文档**: https://pinchtab.com/docs
- **许可证**: MIT

---

## ⏳ 安装状态

**当前状态**: ⏳ 安装中

**下一步**:
1. 从源码构建 Go 二进制
2. 启动 HTTP 服务器
3. 集成到 OpenClaw 技能系统

---

**安装时间**: 2026-03-13
**维护者**: Chaotang