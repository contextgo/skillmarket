# Bounty Hunter 配置

## 环境变量

### GITHUB_TOKEN（必需）

GitHub Personal Access Token，用于：
- 搜索赏金任务（GitHub Issues）
- 提交 Pull Request
- 管理仓库交互

**配置方式**：
```bash
# 已配置到 OpenClaw 环境变量
# 位置：~/.openclaw/openclaw.json → env.GITHUB_TOKEN
```

**权限要求**：
- `repo` - 完整仓库读写
- `read:org` - 读取组织信息
- `read:user` - 读取用户信息

**获取方式**：
1. 访问 https://github.com/settings/tokens
2. 生成新令牌（classic）
3. 勾选 `repo` 权限
4. 复制令牌

### UPWORK_API_KEY（可选）

Upwork API 访问密钥（如果使用 Upwork 平台）。

### HAKERONE_API_KEY（可选）

HackerOne API 密钥（如果使用 Bug Bounty 平台）。

---

## 收入追踪

**账本位置**：`~/.openclaw/workspace/INCOME_MANAGEMENT.md`

每次完成任务后，Atlas 会自动更新此文件记录收入。

---

## 安全提醒

⚠️ **永远不要**：
- 将 Token 提交到 Git 仓库
- 在聊天中分享 Token
- 硬编码到脚本中

✅ **正确做法**：
- 使用环境变量（OpenClaw 自动加载）
- 定期轮换 Token（90天）
- 给 Token 设置最小必要权限
