# LLM Prompt 工程模式库

## 基础模式
1. 角色-任务-格式三段式
2. Few-Shot 示例（2-3个输入输出对）
3. Chain-of-Thought（一步一步思考）

## 高级模式
4. Self-Consistency（采样5次取多数）
5. Tree-of-Thought（多路径评估选最优）
6. ReAct（Thought -> Action -> Observation 循环）

## 实用技巧
- 分隔符用 ### 或 ---
- 复杂任务拆子任务(function calling)
- 输出约束用 JSON Schema
- 防幻觉：要求"不确定时说不知道"
- 长文档：先总结再深入
- 温度参数：创意0.8，分析0.2