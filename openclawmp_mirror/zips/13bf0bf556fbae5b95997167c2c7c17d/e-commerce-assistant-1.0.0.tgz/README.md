# E-commerce Assistant

跨境电商运营 AI 助手

## 功能特点

- 🤖 **AI 自动化** - 自动爬取竞品、自动计算利润、自动分析数据
- 📦 **多平台支持** - Amazon、eBay、notonthehighstreet、uncommongoods
- 📊 **Notion 集成** - 数据自动同步到 Notion 模板
- 📈 **数据分析** - 选品分析、广告分析、财务分析

## 安装

```bash
# 克隆项目
git clone <repo-url>
cd e-commerce-assistant

# 安装依赖
pip install -r requirements.txt

# 安装浏览器
playwright install chromium
```

## 配置

编辑 `EXTEND.md` 配置你的 Notion API Key 和数据库 ID。

## 使用

```python
from src.tools import scrape_amazon, scrape_ebay_search
import asyncio

# 爬取 Amazon 产品
result = asyncio.run(scrape_amazon("B08N5WRWNW"))

# 爬取 eBay 搜索结果
results = asyncio.run(scrape_ebay_search("phone case", limit=5))
```

## 项目结构

```
e-commerce-assistant/
├── src/              # 源代码
│   ├── tools.py      # 核心功能
│   └── __init__.py
├── tests/            # 测试文件
├── examples/         # 示例代码
├── SKILL.md         # AI 技能说明
├── EXTEND.md        # 配置文件
├── README.md        # 项目说明
└── requirements.txt  # Python 依赖
```

## 赞助

如果对你有帮助，欢迎 ⭐ Star！

---
跨境电商 | Python | Notion | AI
