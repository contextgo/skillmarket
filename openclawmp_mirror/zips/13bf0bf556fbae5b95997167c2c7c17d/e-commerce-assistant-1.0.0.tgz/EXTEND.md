# 电商助手 - 扩展配置

## Notion API 配置

```markdown
NOTION_API_KEY=你的API Key
PARENT_PAGE_ID=你的Parent Page ID
```

## 数据库 ID

```markdown
# 基础数据库
DATABASE_TASKS=你的每日任务数据库ID      # 每日任务
DATABASE_SELECTION=你的选品库ID           # 选品库
DATABASE_CALCULATOR=你的利润计算器ID      # 利润计算器
DATABASE_COMPETITOR=你的竞品监控ID        # 竞品监控
DATABASE_PRICE_HISTORY=你的价格历史ID     # 价格历史
DATABASE_LISTING=你的Listing库ID          # Listing库
DATABASE_LOGISTICS=你的物流追踪ID         # 物流追踪
DATABASE_ADS=你的广告中心ID               # 广告中心
DATABASE_CUSTOMER=你的客服台ID            # 客服台
DATABASE_FINANCE=你的财务账本ID           # 财务账本
DATABASE_DASHBOARD=你的数据仪表盘ID       # 数据仪表盘

# 分析数据库
DATABASE_STORE_INFO=你的商店信息ID        # 商店信息
DATABASE_SELECTION_ANALYSIS=你的选品分析ID  # 选品分析报告
DATABASE_ADS_ANALYSIS=你的广告分析ID       # 广告分析
DATABASE_FINANCE_ANALYSIS=你的财务分析ID    # 财务分析
DATABASE_OPERATION_ANALYSIS=你的运营分析ID  # 综合运营分析
```

## 用户偏好

```markdown
DEFAULT_PLATFORM=Amazon
DEFAULT_MARKET=美国
DEFAULT_CURRENCY=USD
TIMEZONE=Asia/Shanghai
```

## 常用模板

### 邮件回复模板
- 物流延迟道歉模板
- 退款处理模板
- 差评跟进模板
- 索评请求模板

### 广告策略模板
- 新品冷启动策略
- 爆款推广策略
- 稳定期维护策略
