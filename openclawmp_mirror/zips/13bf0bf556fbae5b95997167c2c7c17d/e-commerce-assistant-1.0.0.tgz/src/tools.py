#!/usr/bin/env python3
"""
电商助手 - 工具函数
提供利润计算、ACOS/ROAS、竞品爬虫等功能
"""

import asyncio
import os
import re
from datetime import datetime
from playwright.async_api import async_playwright


# ============ 利润计算 ============

def calculate_profit(price: float, cost: float) -> dict:
    """计算利润和利润率"""
    profit = price - cost
    profit_rate = (profit / price * 100) if price > 0 else 0
    return {
        "price": price,
        "cost": cost,
        "profit": round(profit, 2),
        "profit_rate": round(profit_rate, 2)
    }


def calculate_profit_detailed(price: float, purchase_cost: float,
                              shipping: float = 0, fba_fee: float = 0,
                              other_cost: float = 0) -> dict:
    """详细利润计算（包含各项成本）"""
    total_cost = purchase_cost + shipping + fba_fee + other_cost
    profit = price - total_cost
    profit_rate = (profit / price * 100) if price > 0 else 0

    return {
        "售价": price,
        "采购成本": purchase_cost,
        "头程运费": shipping,
        "FBA费用": fba_fee,
        "其他成本": other_cost,
        "总成本": round(total_cost, 2),
        "利润": round(profit, 2),
        "利润率": round(profit_rate, 2)
    }


# ============ 广告指标计算 ============

def calculate_acos(spend: float, sales: float) -> dict:
    """计算 ACOS"""
    acos = (spend / sales * 100) if sales > 0 else 0
    return {
        "spend": spend,
        "sales": sales,
        "acos": round(acos, 2)
    }


def calculate_roas(sales: float, spend: float) -> dict:
    """计算 ROAS"""
    roas = sales / spend if spend > 0 else 0
    return {
        "sales": sales,
        "spend": spend,
        "roas": round(roas, 2)
    }


def calculate_roi(sales: float, spend: float, cost: float) -> dict:
    """计算 ROI"""
    roi = ((sales - cost) / spend * 100) if spend > 0 else 0
    return {
        "sales": sales,
        "spend": spend,
        "cost": cost,
        "roi": round(roi, 2)
    }


def calculate_ctr(clicks: int, impressions: int) -> dict:
    """计算点击率"""
    ctr = (clicks / impressions * 100) if impressions > 0 else 0
    return {
        "clicks": clicks,
        "impressions": impressions,
        "ctr": round(ctr, 2)
    }


# ============ 竞品爬虫 ============

# 平台配置
PLATFORMS = {
    "amazon": {
        "url_template": "https://www.amazon.{domain}/dp/{id}",
        "id_name": "ASIN",
        "selectors": {
            "title": "#productTitle",
            "price": ".a-price-whole",
            "rating": ".a-icon-alt",
            "reviews": "#acrCustomerReviewText",
            "image": "#landingImage"
        }
    },
    "ebay": {
        "url_template": "search",
        "id_name": "搜索关键词",
        "selectors": {
            "title": ".x-item-title__mainTitle",
            "price": "#prcIsum",
            "rating": ".reviews-star-rating",
            "reviews": "#rvwTermsCnt",
            "image": ".ux-image-magnify__image--original",
            "search_url": "https://www.ebay.com/sch/i.html?_nkw={id}"
        }
    },
    "etsy": {
        "url_template": "https://www.etsy.com/search?q={id}",
        "id_name": "搜索关键词",
        "selectors": {
            "title": ".wt-grid__item-absolute-setup",
            "price": ".currency-value",
            "rating": ".wt-nr-w-color",
            "reviews": ".wt-nr-b5",
            "image": ".wt-position-absolute"
        }
    },
    "temu": {
        "url_template": "https://www.temu.com/{country}/item-{id}.html",
        "id_name": "ID",
        "selectors": {
            "title": ".goods-title",
            "price": ".price",
            "rating": ".rating-score",
            "reviews": ".review-count",
            "image": ".goods-img"
        }
    },
    "notonthehighstreet": {
        "url_template": "https://www.notonthehighstreet.com/{id}",
        "id_name": "产品URL",
        "type": "product_url"
    },
    "uncommongoods": {
        "url_template": "https://www.uncommongoods.com/product/{id}",
        "id_name": "产品ID",
        "type": "product_id"
    }
}


async def scrape_ebay_search(keyword: str, limit: int = 3) -> list:
    """爬取 eBay 搜索结果"""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        # 搜索 URL
        url = f"https://www.ebay.com/sch/i.html?_nkw={keyword}"
        print(f"正在打开: {url}")

        try:
            await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            await page.wait_for_timeout(5000)

            results = []

            # 获取产品链接
            links = await page.query_selector_all('a[href*="/itm/"]')

            seen_urls = set()
            count = 0

            for link in links:
                if count >= limit:
                    break

                href = await link.get_attribute("href")
                if not href or href in seen_urls:
                    continue

                # 清理 URL，只保留基础部分
                if "?" in href:
                    href = href.split("?")[0]

                seen_urls.add(href)

                # 访问产品页
                try:
                    await page.goto(href, timeout=30000, wait_until="domcontentloaded")
                    await page.wait_for_timeout(2000)

                    result = {
                        "platform": "ebay",
                        "keyword": keyword,
                        "url": href
                    }

                    # 标题
                    try:
                        title = await page.locator(".x-item-title__mainTitle").text_content()
                        result["title"] = title.strip()[:100]
                    except:
                        result["title"] = "N/A"

                    # 价格
                    try:
                        price = await page.locator(".x-price-primary span").text_content()
                        result["price"] = price.strip()
                    except:
                        result["price"] = "N/A"

                    # 评分
                    try:
                        rating = await page.locator(".reviews-star-rating").text_content()
                        result["rating"] = rating.strip()
                    except:
                        result["rating"] = "N/A"

                    # 评论数
                    try:
                        reviews = await page.locator("#rvwTermsCnt").text_content()
                        result["reviews"] = reviews.strip()
                    except:
                        result["reviews"] = "0"

                    # 主图
                    try:
                        img = await page.locator(".ux-image-carousel-item img").first.get_attribute("src")
                        result["image"] = img
                    except:
                        result["image"] = "N/A"

                    result["timestamp"] = datetime.now().isoformat()
                    results.append(result)
                    count += 1
                    print(f"  ✅ 抓取成功: {result.get('title', 'N/A')[:40]}...")

                except Exception as e:
                    print(f"  ⚠️ 抓取失败: {str(e)[:40]}")

            return results

        except Exception as e:
            return [{"error": str(e)}]
        finally:
            await browser.close()


async def scrape_notonthehighstreet(keyword: str) -> dict:
    """爬取 notonthehighstreet 搜索结果"""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        # 支持完整URL或关键词
        if keyword.startswith("http"):
            url = keyword
        else:
            url = f"https://www.notonthehighstreet.com/search?phrase={keyword}"

        print(f"正在打开: {url}")

        try:
            await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            await page.wait_for_timeout(5000)

            # 使用JavaScript提取搜索结果
            product_data = await page.evaluate('''
                () => {
                    const links = document.querySelectorAll('a[href*="/product/"]');
                    if (links.length === 0) return null;

                    const link = links[0];
                    const href = link.getAttribute('href');

                    // 尝试从父元素获取产品信息
                    let parent = link;
                    for(let i=0; i<5; i++) {
                        parent = parent?.parentElement;
                        if(!parent) break;
                        const text = parent?.textContent;
                        if(text && text.length > 20 && text.length < 200) {
                            // 提取标题和价格
                            const title = text.replace(/£\\d+\\.\\d+/, '').trim().substring(0, 100);
                            const priceMatch = text.match(/£\\d+\\.?\\d*/);
                            return {
                                title: title,
                                price: priceMatch ? priceMatch[0] : 'N/A',
                                url: href
                            };
                        }
                    }

                    return {title: 'N/A', price: 'N/A', url: href};
                }
            ''')

            if not product_data:
                return {"status": "error", "message": "未找到产品"}

            result = {
                "platform": "notonthehighstreet",
                "title": product_data.get("title", "N/A")[:100],
                "price": product_data.get("price", "N/A"),
                "image": product_data.get("image", "N/A"),
                "url": product_data.get("url", url),
                "timestamp": datetime.now().isoformat()
            }

            return result

        except Exception as e:
            return {"error": str(e)}
        finally:
            await browser.close()


async def scrape_uncommongoods(keyword: str) -> dict:
    """爬取 uncommongoods 搜索结果"""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        # 使用搜索URL
        if keyword.startswith("http"):
            url = keyword
        else:
            url = f"https://www.uncommongoods.com/search?text={keyword}"

        print(f"正在打开: {url}")

        try:
            await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            await page.wait_for_timeout(10000)  # 等待更长时间

            # 使用JavaScript提取搜索结果
            product_data = await page.evaluate('''
                () => {
                    const names = document.querySelectorAll('.product__name');
                    if (names.length === 0) return null;

                    // 获取第一个真正的产品（跳过 membership）
                    for (const name of names) {
                        const text = name.textContent || '';
                        if (text.toLowerCase().includes('membership')) continue;

                        // 获取链接
                        const link = name.closest('a');
                        const href = link?.getAttribute('href') || '';

                        // 获取价格（从同一行）
                        const parent = name.closest('[class*="product-message"]') || name.parentElement;
                        const parentText = parent?.textContent || '';
                        const priceMatch = parentText.match(/\\$\\d+\\.?\\d*/);

                        return {
                            title: text.trim().substring(0, 100),
                            price: priceMatch ? priceMatch[0] : 'N/A',
                            url: href ? 'https://www.uncommongoods.com' + href : 'N/A'
                        };
                    }

                    return {title: names[0]?.textContent?.trim() || 'N/A', price: 'N/A', url: 'N/A'};
                }
            ''')

            if not product_data:
                return {"status": "error", "message": "未找到产品"}

            result = {
                "platform": "uncommongoods",
                "title": product_data.get("title", "N/A")[:100],
                "price": product_data.get("price", "N/A"),
                "image": product_data.get("image", "N/A"),
                "url": product_data.get("url", url),
                "timestamp": datetime.now().isoformat()
            }

            return result

        except Exception as e:
            return {"error": str(e)}
        finally:
            await browser.close()


async def scrape_etsy_search(keyword: str, limit: int = 3) -> list:
    """爬取 Etsy 搜索结果"""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        url = f"https://www.etsy.com/search?q={keyword}"
        print(f"正在打开: {url}")

        try:
            await page.goto(url, timeout=30000, wait_until="domcontentloaded")
            await page.wait_for_timeout(5000)

            results = []

            # 获取产品卡片
            cards = await page.query_selector_all('[data-listing-id]')
            print(f"找到 {len(cards)} 个产品")

            for i, card in enumerate(cards[:limit]):
                try:
                    result = {
                        "platform": "etsy",
                        "keyword": keyword
                    }

                    # 标题
                    try:
                        title = await card.locator('a').first.get_attribute('title')
                        if not title:
                            title = await card.locator('.wt-text-body-01').first.text_content()
                        result["title"] = title.strip()[:100] if title else "N/A"
                    except:
                        result["title"] = "N/A"

                    # 价格
                    try:
                        price = await card.locator('.currency-value').first.text_content()
                        result["price"] = price.strip()
                    except:
                        result["price"] = "N/A"

                    # 评分
                    try:
                        rating = await card.locator('.wt-nr-w-color').first.text_content()
                        result["rating"] = rating.strip()
                    except:
                        result["rating"] = "N/A"

                    # 评论数
                    try:
                        reviews = await card.locator('.wt-nr-b5').first.text_content()
                        result["reviews"] = reviews.strip()
                    except:
                        result["reviews"] = "0"

                    # 主图
                    try:
                        img = await card.locator('img').first.get_attribute('src')
                        result["image"] = img
                    except:
                        result["image"] = "N/A"

                    result["timestamp"] = datetime.now().isoformat()
                    results.append(result)
                    print(f"  ✅ {i+1}. {result.get('title', 'N/A')[:40]}...")

                except Exception as e:
                    print(f"  ⚠️ 抓取失败: {str(e)[:40]}")

            return results

        except Exception as e:
            return [{"error": str(e)}]
        finally:
            await browser.close()


async def scrape_product(platform: str, product_id: str, domain: str = "com") -> dict:
    """通用爬虫，支持多平台"""
    platform = platform.lower()

    if platform not in PLATFORMS:
        return {"error": f"不支持的平台: {platform}，支持的平台: {list(PLATFORMS.keys())}"}

    config = PLATFORMS[platform]

    # eBay 使用搜索模式
    if platform == "ebay":
        results = await scrape_ebay_search(product_id, limit=1)
        if results and "error" not in results[0]:
            return results[0]
        return {"error": "eBay 抓取失败"}

    # Etsy 使用搜索模式
    if platform == "etsy":
        results = await scrape_etsy_search(product_id, limit=1)
        if results and "error" not in results[0]:
            return results[0]
        return {"error": "Etsy 抓取失败"}

    url = config["url_template"].format(domain=domain, id=product_id)

    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        print(f"正在打开: {url}")

        try:
            await page.goto(url, timeout=30000)
            await page.wait_for_load_state("domcontentloaded")
            await page.wait_for_timeout(2000)

            result = {
                "platform": platform,
                "id": product_id,
                "url": url
            }

            # 获取标题
            try:
                title = await page.locator(config["selectors"]["title"]).first.text_content()
                result["title"] = title.strip()[:100]
            except:
                result["title"] = "N/A"

            # 获取价格
            try:
                price = await page.locator(config["selectors"]["price"]).first.text_content()
                result["price"] = price.strip()
            except:
                result["price"] = "N/A"

            # 获取评分
            try:
                rating = await page.locator(config["selectors"]["rating"]).first.text_content()
                result["rating"] = rating.strip()
            except:
                result["rating"] = "N/A"

            # 获取评论数
            try:
                reviews = await page.locator(config["selectors"]["reviews"]).first.text_content()
                result["reviews"] = reviews.strip()
            except:
                result["reviews"] = "0"

            # 获取主图
            try:
                image = await page.locator(config["selectors"]["image"]).first.get_attribute("src")
                result["image"] = image
            except:
                result["image"] = "N/A"

            result["timestamp"] = datetime.now().isoformat()
            return result

        except Exception as e:
            return {"error": str(e)}
        finally:
            await browser.close()


async def scrape_amazon(asin: str) -> dict:
    """爬取亚马逊产品信息（使用搜索页面）"""
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=True)
        page = await browser.new_page()

        # 使用搜索URL代替直接产品页，绕过反爬
        url = f"https://www.amazon.com/s?k={asin}"
        print(f"正在打开: {url}")

        try:
            await page.goto(url, timeout=30000)
            await page.wait_for_timeout(5000)

            # 使用JavaScript提取产品数据
            product_data = await page.evaluate('''
                () => {
                    const results = document.querySelectorAll('[data-component-type="s-search-result"]');
                    if (results.length === 0) return null;

                    const first = results[0];
                    // 使用正确的选择器
                    const title = first.querySelector('.s-title-instructions-style span')?.textContent ||
                                  first.querySelector('[data-cy="title-recipe"] span')?.textContent || '';
                    const priceWhole = first.querySelector('.a-price-whole')?.textContent || '';
                    const priceFraction = first.querySelector('.a-price-fraction')?.textContent || '00';
                    const rating = first.querySelector('[aria-label*="stars"]')?.getAttribute('aria-label') || '';
                    const img = first.querySelector('img')?.src || '';
                    const asin = first.getAttribute('data-asin') || '';

                    // 格式化价格
                    let formattedPrice = 'N/A';
                    if (priceWhole) {
                        formattedPrice = '$' + priceWhole.replace(/,/g, '') + '.' + priceFraction;
                    }

                    return {
                        title: title.trim(),
                        price: formattedPrice,
                        rating: rating.replace(', rating details', '').trim(),
                        image: img,
                        asin: asin
                    };
                }
            ''')

            if not product_data:
                return {"status": "error", "message": "未找到产品"}

            result = {
                "asin": product_data.get("asin", asin),
                "title": product_data.get("title", "N/A")[:100],
                "price": product_data.get("price", "N/A"),
                "rating": product_data.get("rating", "N/A"),
                "reviews": product_data.get("rating", "N/A"),  # 使用rating作为reviews
                "image": product_data.get("image", "N/A"),
                "url": f"https://www.amazon.com/dp/{product_data.get('asin', asin)}",
                "timestamp": datetime.now().isoformat()
            }

            return result

        except Exception as e:
            return {"error": str(e)}
        finally:
            await browser.close()


def scrape_amazon_sync(asin: str) -> dict:
    """同步版本的爬虫"""
    return asyncio.run(scrape_amazon(asin))


# ============ 解析命令 ============

def parse_profit_command(text: str) -> dict:
    """解析利润计算命令"""
    # 匹配 "售价$30，成本$15" 或 "售价30，成本15" 等格式
    price_match = re.search(r'售价[为是：:]?\s*\$?(\d+\.?\d*)', text)
    cost_match = re.search(r'成本[为是：:]?\s*\$?(\d+\.?\d*)', text)

    if price_match and cost_match:
        return {
            "price": float(price_match.group(1)),
            "cost": float(cost_match.group(1))
        }
    return None


def parse_acos_command(text: str) -> dict:
    """解析 ACOS 计算命令"""
    spend_match = re.search(r'花费[为是：:]?\s*\$?(\d+\.?\d*)', text)
    sales_match = re.search(r'销售额?[为是：:]?\s*\$?(\d+\.?\d*)', text)

    if spend_match and sales_match:
        return {
            "spend": float(spend_match.group(1)),
            "sales": float(sales_match.group(1))
        }
    return None


def parse_roas_command(text: str) -> dict:
    """解析 ROAS 计算命令"""
    spend_match = re.search(r'花费[为是：:]?\s*\$?(\d+\.?\d*)', text)
    sales_match = re.search(r'销售额?[为是：:]?\s*\$?(\d+\.?\d*)', text)

    if spend_match and sales_match:
        return {
            "spend": float(spend_match.group(1)),
            "sales": float(sales_match.group(1))
        }
    return None


# ============ Notion 导入 ============
# 从环境变量读取配置，或使用 .env 文件

NOTION_API_KEY = os.environ.get("NOTION_API_KEY", "")
NOTION_DATABASE_COMPETITOR = os.environ.get("NOTION_DATABASE_COMPETITOR", "")
NOTION_DATABASE_STORE_INFO = os.environ.get("NOTION_DATABASE_STORE_INFO", "")
NOTION_DATABASE_SELECTION_ANALYSIS = os.environ.get("NOTION_DATABASE_SELECTION_ANALYSIS", "")
NOTION_DATABASE_ADS_ANALYSIS = os.environ.get("NOTION_DATABASE_ADS_ANALYSIS", "")
NOTION_DATABASE_FINANCE_ANALYSIS = os.environ.get("NOTION_DATABASE_FINANCE_ANALYSIS", "")
NOTION_DATABASE_OPERATION_ANALYSIS = os.environ.get("NOTION_DATABASE_OPERATION_ANALYSIS", "")


def import_to_notion(product_data: dict) -> dict:
    """导入产品数据到 Notion 竞品监控"""
    import requests

    url = f"https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    # 提取数据
    platform = product_data.get("platform", "Amazon")
    title = product_data.get("title", "N/A")
    price = product_data.get("price", "N/A")
    rating = product_data.get("rating", "N/A")
    reviews = product_data.get("reviews", "0")
    image = product_data.get("image", "")
    asin = product_data.get("id", product_data.get("asin", ""))
    category = product_data.get("category", "")  # 类目
    description = product_data.get("description", "")  # 描述
    product_url = product_data.get("url", "")  # 产品URL

    # 清理价格
    price_value = None
    if price and price != "N/A":
        import re
        price_match = re.search(r'[\d,.]+', str(price))
        if price_match:
            price_value = float(price_match.group().replace(",", ""))

    # 清理评分
    rating_value = None
    if rating and rating != "N/A":
        import re
        rating_match = re.search(r'[\d.]+', str(rating))
        if rating_match:
            rating_value = float(rating_match.group())

    # 清理评论数
    reviews_value = 0
    if reviews and reviews != "N/A" and reviews != "0":
        import re
        reviews_match = re.search(r'[\d,]+', str(reviews))
        if reviews_match:
            reviews_value = int(reviews_match.group().replace(",", ""))

    # 构建 Notion 属性
    properties = {
        "产品名称": {
            "title": [{"text": {"content": title[:100]}}]
        },
        "平台": {
            "select": {"name": platform.capitalize()}
        },
        "当前价格": {
            "number": price_value
        },
        "评分": {
            "number": rating_value
        },
        "评论数": {
            "number": reviews_value
        },
        "图片": {
            "url": image if image and image != "N/A" else None
        },
        "ASIN": {
            "rich_text": [{"text": {"content": asin}}]
        },
        "监控状态": {
            "select": {"name": "待分析"}
        },
        "添加时间": {
            "date": {"start": datetime.now().isoformat()}
        },
        "产品链接": {
            "url": product_url if product_url else None
        },
        "备注": {
            "rich_text": [{"text": {"content": (category + '\\n\\n' + description)[:1000]}}] if category or description else []
        }
    }

    data = {
        "parent": {"database_id": NOTION_DATABASE_COMPETITOR},
        "properties": properties
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            result = response.json()
            return {
                "success": True,
                "page_id": result.get("id"),
                "title": title[:30]
            }
        else:
            return {
                "success": False,
                "error": response.text
            }
    except Exception as e:
        return {
            "success": False,
            "error": str(e)
        }


def scrape_and_import(platform: str, keyword: str) -> dict:
    """爬取并导入到 Notion"""
    async def run():
        if platform.lower() == "amazon":
            # Amazon 需要 ASIN
            result = await scrape_amazon(keyword)
            return import_to_notion(result)
        elif platform.lower() == "ebay":
            # eBay 搜索
            results = await scrape_ebay_search(keyword, limit=1)
            if results and "error" not in results[0]:
                return import_to_notion(results[0])
            return {"success": False, "error": "eBay 抓取失败"}
        elif platform.lower() == "notonthehighstreet" or platform.lower() == "noths":
            # notonthehighstreet
            result = await scrape_notonthehighstreet(keyword)
            if "error" not in result:
                return import_to_notion(result)
            return {"success": False, "error": result.get("error", "NOTHS 抓取失败")}
        elif platform.lower() == "uncommongoods" or platform.lower() == "ug":
            # uncommongoods
            result = await scrape_uncommongoods(keyword)
            if "error" not in result:
                return import_to_notion(result)
            return {"success": False, "error": result.get("error", "UncommonGoods 抓取失败")}
        else:
            return {"success": False, "error": f"不支持的平台: {platform}"}

    return asyncio.run(run())


# ============ 每日任务提醒 ============

NOTION_DATABASE_TASKS = os.environ.get("NOTION_DATABASE_TASKS", "")


def get_daily_tasks_summary() -> dict:
    """获取每日任务汇总"""
    import requests

    url = f"https://api.notion.com/v1/databases/{NOTION_DATABASE_TASKS}/query"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    # 查询所有任务
    data = {"page_size": 100}

    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code != 200:
            return {"error": f"API错误: {response.status_code}"}

        results = response.json().get("results", [])
        if not results:
            return {"completed": [], "pending": [], "expired": []}

        tasks = {
            "completed": [],
            "pending": [],
            "expired": []
        }

        today = datetime.now().date()

        for item in results:
            try:
                props = item.get("properties", {})
                if not props:
                    continue

                # 任务名称
                title_data = props.get("任务名称", {})
                if title_data and title_data.get("title"):
                    title = title_data["title"][0].get("text", {}).get("content", "未命名")
                else:
                    title = "未命名"

                # 状态
                status_data = props.get("状态", {}).get("select", {})
                status = status_data.get("name", "待处理") if status_data else "待处理"

                # 优先级
                priority_data = props.get("优先级", {}).get("select", {})
                priority = priority_data.get("name", "中") if priority_data else "中"

                # 计划日期
                plan_date = None
                plan_date_str = ""
                date_data = props.get("计划日期", {}).get("date")
                if date_data and date_data.get("start"):
                    plan_date_str = date_data["start"]
                    try:
                        plan_date = datetime.fromisoformat(plan_date_str.replace("Z", "+00:00")).date()
                    except:
                        plan_date = None

                task_info = {
                    "id": item.get("id"),
                    "title": title,
                    "priority": priority,
                    "status": status,
                    "plan_date": plan_date_str
                }

                if status == "已完成":
                    tasks["completed"].append(task_info)
                elif plan_date and plan_date < today:
                    tasks["expired"].append(task_info)
                else:
                    tasks["pending"].append(task_info)

            except Exception as e:
                continue

        # 按优先级排序
        priority_order = {"高": 0, "中": 1, "低": 2}
        tasks["pending"].sort(key=lambda x: priority_order.get(x["priority"], 1))

        return tasks

    except Exception as e:
        return {"error": str(e)}


def format_task_summary(tasks: dict) -> str:
    """格式化任务汇总"""
    if "error" in tasks:
        return f"⚠️ 获取任务失败: {tasks['error']}"

    completed = tasks.get("completed", [])
    pending = tasks.get("pending", [])
    expired = tasks.get("expired", [])

    summary = "📋 今日任务提醒\n\n"
    summary += f"✅ 已完成: {len(completed)} 个\n"
    summary += f"⏳ 待完成: {len(pending)} 个\n"
    summary += f"❌ 已过期: {len(expired)} 个\n\n"

    if expired:
        summary += "⚠️ 已过期任务:\n"
        for t in expired[:3]:
            priority_emoji = {"高": "🔴", "中": "🟡", "低": "🟢"}.get(t["priority"], "⚪")
            summary += f"  {priority_emoji} {t['title']}\n"
        summary += "\n"

    if pending:
        summary += "⏳ 待完成任务:\n"
        for t in pending[:5]:
            priority_emoji = {"高": "🔴", "中": "🟡", "低": "🟢"}.get(t["priority"], "⚪")
            summary += f"  {priority_emoji} [{t['priority']}] {t['title']}\n"

    if not completed and not pending and not expired:
        summary += "🎉 暂无任务，快去添加吧！\n"

    return summary


def update_task_status(page_id: str, status: str) -> dict:
    """更新任务状态"""
    import requests

    url = f"https://api.notion.com/v1/pages/{page_id}"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    data = {
        "properties": {
            "状态": {
                "select": {"name": status}
            }
        }
    }

    if status == "已完成":
        data["properties"]["完成日期"] = {
            "date": {"start": datetime.now().isoformat()}
        }

    try:
        response = requests.patch(url, headers=headers, json=data)
        if response.status_code == 200:
            return {"success": True}
        else:
            return {"success": False, "error": response.text}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============ 商店信息 ============

def add_store_info(store_data: dict) -> dict:
    """添加商店信息"""
    import requests

    url = "https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    properties = {}

    if store_data.get("店铺名称"):
        properties["店铺名称"] = {"title": [{"text": {"content": store_data["店铺名称"]}}]}

    if store_data.get("平台"):
        properties["平台"] = {"select": {"name": store_data["平台"]}}

    if store_data.get("店铺ID"):
        properties["店铺ID"] = {"rich_text": [{"text": {"content": store_data["店铺ID"]}}]}

    if store_data.get("主营类目"):
        properties["主营类目"] = {"multi_select": [{"name": c} for c in store_data["主营类目"]]}

    if store_data.get("月销售额") is not None:
        properties["月销售额"] = {"number": store_data["月销售额"]}

    if store_data.get("月销量") is not None:
        properties["月销量"] = {"number": store_data["月销量"]}

    if store_data.get("广告预算") is not None:
        properties["广告预算"] = {"number": store_data["广告预算"]}

    if store_data.get("评分") is not None:
        properties["评分"] = {"number": store_data["评分"]}

    if store_data.get("店铺状态"):
        properties["店铺状态"] = {"select": {"name": store_data["店铺状态"]}}

    properties["添加时间"] = {"date": {"start": datetime.now().isoformat()}}

    data = {
        "parent": {"database_id": NOTION_DATABASE_STORE_INFO},
        "properties": properties
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            return {"success": True, "page_id": response.json().get("id")}
        return {"success": False, "error": response.text}
    except Exception as e:
        return {"success": False, "error": str(e)}


def get_stores() -> list:
    """获取所有商店信息"""
    import requests

    url = f"https://api.notion.com/v1/databases/{NOTION_DATABASE_STORE_INFO}/query"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    try:
        response = requests.post(url, headers=headers, json={"page_size": 100})
        if response.status_code != 200:
            return []

        results = response.json().get("results", [])
        stores = []

        for item in results:
            props = item.get("properties", {})

            store = {
                "id": item.get("id"),
                "店铺名称": props.get("店铺名称", {}).get("title", [{}])[0].get("text", {}).get("content", ""),
                "平台": props.get("平台", {}).get("select", {}).get("name", ""),
            }
            stores.append(store)

        return stores
    except:
        return []


# ============ 选品分析报告 ============

def add_selection_analysis(analysis_data: dict) -> dict:
    """添加选品分析报告"""
    import requests

    url = "https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    properties = {}

    if analysis_data.get("分析标题"):
        properties["分析标题"] = {"title": [{"text": {"content": analysis_data["分析标题"]}}]}

    if analysis_data.get("搜索关键词"):
        properties["搜索关键词"] = {"rich_text": [{"text": {"content": analysis_data["搜索关键词"]}}]}

    if analysis_data.get("分析平台"):
        properties["分析平台"] = {"multi_select": [{"name": p} for p in analysis_data["分析平台"]]}

    if analysis_data.get("竞品数量") is not None:
        properties["竞品数量"] = {"number": analysis_data["竞品数量"]}

    if analysis_data.get("价格区间"):
        properties["价格区间"] = {"rich_text": [{"text": {"content": analysis_data["价格区间"]}}]}

    if analysis_data.get("平均评分") is not None:
        properties["平均评分"] = {"number": analysis_data["平均评分"]}

    if analysis_data.get("热门价格"):
        properties["热门价格"] = {"rich_text": [{"text": {"content": analysis_data["热门价格"]}}]}

    if analysis_data.get("竞争程度"):
        properties["竞争程度"] = {"select": {"name": analysis_data["竞争程度"]}}

    if analysis_data.get("AI分析结论"):
        properties["AI分析结论"] = {"rich_text": [{"text": {"content": analysis_data["AI分析结论"]}}]}

    if analysis_data.get("选品建议"):
        properties["选品建议"] = {"rich_text": [{"text": {"content": analysis_data["选品建议"]}}]}

    if analysis_data.get("推荐产品"):
        properties["推荐产品"] = {"rich_text": [{"text": {"content": analysis_data["推荐产品"]}}]}

    properties["分析日期"] = {"date": {"start": datetime.now().isoformat()}}

    if analysis_data.get("状态"):
        properties["状态"] = {"select": {"name": analysis_data["状态"]}}

    data = {
        "parent": {"database_id": NOTION_DATABASE_SELECTION_ANALYSIS},
        "properties": properties
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            return {"success": True, "page_id": response.json().get("id")}
        return {"success": False, "error": response.text}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============ 广告分析 ============

def add_ads_analysis(ads_data: dict) -> dict:
    """添加广告分析"""
    import requests

    url = "https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    properties = {}

    if ads_data.get("活动名称"):
        properties["活动名称"] = {"title": [{"text": {"content": ads_data["活动名称"]}}]}

    if ads_data.get("平台"):
        properties["平台"] = {"select": {"name": ads_data["平台"]}}

    if ads_data.get("广告类型"):
        properties["广告类型"] = {"select": {"name": ads_data["广告类型"]}}

    if ads_data.get("花费") is not None:
        properties["花费"] = {"number": ads_data["花费"]}

    if ads_data.get("销售额") is not None:
        properties["销售额"] = {"number": ads_data["销售额"]}

    if ads_data.get("曝光量") is not None:
        properties["曝光量"] = {"number": ads_data["曝光量"]}

    if ads_data.get("点击量") is not None:
        properties["点击量"] = {"number": ads_data["点击量"]}

    if ads_data.get("ACOS") is not None:
        properties["ACOS"] = {"number": ads_data["ACOS"]}

    if ads_data.get("ROAS") is not None:
        properties["ROAS"] = {"number": ads_data["ROAS"]}

    if ads_data.get("CTR") is not None:
        properties["CTR"] = {"number": ads_data["CTR"]}

    if ads_data.get("转化率") is not None:
        properties["转化率"] = {"number": ads_data["转化率"]}

    if ads_data.get("AI优化建议"):
        properties["AI优化建议"] = {"rich_text": [{"text": {"content": ads_data["AI优化建议"]}}]}

    if ads_data.get("分析周期"):
        properties["分析周期"] = {"select": {"name": ads_data["分析周期"]}}

    properties["记录日期"] = {"date": {"start": datetime.now().isoformat()}}

    data = {
        "parent": {"database_id": NOTION_DATABASE_ADS_ANALYSIS},
        "properties": properties
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            return {"success": True, "page_id": response.json().get("id")}
        return {"success": False, "error": response.text}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============ 财务分析 ============

def add_finance_analysis(finance_data: dict) -> dict:
    """添加财务分析"""
    import requests

    url = "https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    properties = {}

    if finance_data.get("分析标题"):
        properties["分析标题"] = {"title": [{"text": {"content": finance_data["分析标题"]}}]}

    if finance_data.get("期间"):
        properties["期间"] = {"select": {"name": finance_data["期间"]}}

    if finance_data.get("总收入") is not None:
        properties["总收入"] = {"number": finance_data["总收入"]}

    if finance_data.get("总支出") is not None:
        properties["总支出"] = {"number": finance_data["总支出"]}

    if finance_data.get("净利润") is not None:
        properties["净利润"] = {"number": finance_data["净利润"]}

    if finance_data.get("毛利率") is not None:
        properties["毛利率"] = {"number": finance_data["毛利率"]}

    if finance_data.get("广告支出") is not None:
        properties["广告支出"] = {"number": finance_data["广告支出"]}

    if finance_data.get("采购成本") is not None:
        properties["采购成本"] = {"number": finance_data["采购成本"]}

    if finance_data.get("物流成本") is not None:
        properties["物流成本"] = {"number": finance_data["物流成本"]}

    if finance_data.get("平台费用") is not None:
        properties["平台费用"] = {"number": finance_data["平台费用"]}

    if finance_data.get("其他支出") is not None:
        properties["其他支出"] = {"number": finance_data["其他支出"]}

    if finance_data.get("ROI") is not None:
        properties["ROI"] = {"number": finance_data["ROI"]}

    if finance_data.get("AI财务建议"):
        properties["AI财务建议"] = {"rich_text": [{"text": {"content": finance_data["AI财务建议"]}}]}

    properties["分析日期"] = {"date": {"start": datetime.now().isoformat()}}

    data = {
        "parent": {"database_id": NOTION_DATABASE_FINANCE_ANALYSIS},
        "properties": properties
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            return {"success": True, "page_id": response.json().get("id")}
        return {"success": False, "error": response.text}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============ 综合运营分析 ============

def add_operation_analysis(op_data: dict) -> dict:
    """添加综合运营分析"""
    import requests

    url = "https://api.notion.com/v1/pages"
    headers = {
        "Authorization": f"Bearer {NOTION_API_KEY}",
        "Notion-Version": "2022-06-28",
        "Content-Type": "application/json"
    }

    properties = {}

    if op_data.get("报告标题"):
        properties["报告标题"] = {"title": [{"text": {"content": op_data["报告标题"]}}]}

    if op_data.get("店铺"):
        properties["店铺"] = {"select": {"name": op_data["店铺"]}}

    if op_data.get("分析周期"):
        properties["分析周期"] = {"select": {"name": op_data["分析周期"]}}

    if op_data.get("销售概况"):
        properties["销售概况"] = {"rich_text": [{"text": {"content": op_data["销售概况"]}}]}

    if op_data.get("广告表现"):
        properties["广告表现"] = {"rich_text": [{"text": {"content": op_data["广告表现"]}}]}

    if op_data.get("财务状况"):
        properties["财务状况"] = {"rich_text": [{"text": {"content": op_data["财务状况"]}}]}

    if op_data.get("竞品动态"):
        properties["竞品动态"] = {"rich_text": [{"text": {"content": op_data["竞品动态"]}}]}

    if op_data.get("问题诊断"):
        properties["问题诊断"] = {"rich_text": [{"text": {"content": op_data["问题诊断"]}}]}

    if op_data.get("AI运营方案"):
        properties["AI运营方案"] = {"rich_text": [{"text": {"content": op_data["AI运营方案"]}}]}

    if op_data.get("优先级"):
        properties["优先级"] = {"select": {"name": op_data["优先级"]}}

    if op_data.get("执行状态"):
        properties["执行状态"] = {"select": {"name": op_data["执行状态"]}}

    if op_data.get("AI总结"):
        properties["AI总结"] = {"rich_text": [{"text": {"content": op_data["AI总结"]}}]}

    properties["分析日期"] = {"date": {"start": datetime.now().isoformat()}}

    data = {
        "parent": {"database_id": NOTION_DATABASE_OPERATION_ANALYSIS},
        "properties": properties
    }

    try:
        response = requests.post(url, headers=headers, json=data)
        if response.status_code == 200:
            return {"success": True, "page_id": response.json().get("id")}
        return {"success": False, "error": response.text}
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============ 主函数 ============

if __name__ == "__main__":
    # 测试利润计算
    result = calculate_profit(30, 15)
    print(f"利润计算: {result}")

    # 测试 ACOS
    acos = calculate_acos(50, 200)
    print(f"ACOS: {acos}")
