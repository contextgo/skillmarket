"""
E-commerce Assistant - 跨境电商运营 AI 助手
"""

__version__ = "1.0.0"
