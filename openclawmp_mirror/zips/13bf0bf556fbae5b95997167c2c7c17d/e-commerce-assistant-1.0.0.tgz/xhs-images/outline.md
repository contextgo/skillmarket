---
strategy: b
name: Information-Dense
style: notion
layout: varies
image_count: 4
---

## P1 Cover
**Type**: cover
**Title**: 用Notion+AI做跨境电商
**Subtitle**: 每年省下好几万软件钱
**Visual**: Notion logo + AI robot icon, blue tech color scheme
**Layout**: sparse

## P2 Info-Graphic
**Type**: content
**Title**: AI帮你做这5件事
**Content**:
1. 查竞品 - 不用一个个看
2. 算利润 - ACOS/ROAS自动算
3. 写Listing - 标题五点描述AI生成
4. 管数据 - 全部存Notion
5. 做分析 - 选品/广告/财务分析
**Layout**: list

## P3 Comparison
**Type**: content
**Title**: 以前 vs 现在
**Left**: 手动查数据、算利润、记表格
**Right**: AI干活、Notion记录
**Layout**: comparison

## P4 Cost-Comparison
**Type**: content
**Title**: 一年软件费省多少？
**Data**:
- 买软件: $1800-6600/年
- 用Notion+AI: $0-500/年
**Visual**: Data chart style
**Layout**: dense
