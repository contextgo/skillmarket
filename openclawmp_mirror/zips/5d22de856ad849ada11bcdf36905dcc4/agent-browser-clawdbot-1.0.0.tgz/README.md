# agent-browser-clawdbot

**类型**: skill

Headless browser automation CLI optimized for AI agents with accessibility tree snapshots and ref-based element selection

## 快速开始

当用户提到 agent-browser-clawdbot 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
