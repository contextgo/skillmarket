---
name: wireguard-vpn-setup
description: "Agent 自动配置 WireGuard VPN 隧道指南"
version: 1.0.0
---

WireGuard VPN 自动化配置指南。

## 安装
```bash
sudo apt install wireguard -y && modprobe wireguard
```

## 密钥生成
```bash
wg genkey | tee server_private.key | wg pubkey > server_public.key
chmod 600 server_private.key
```

## 服务器配置 (/etc/wireguard/wg0.conf)
```ini
[Interface]
Address = 10.0.0.1/24
ListenPort = 51820
PrivateKey = <SERVER_KEY>
PostUp = iptables -A FORWARD -i wg0 -j ACCEPT
PostDown = iptables -D FORWARD -i wg0 -j ACCEPT

[Peer]
PublicKey = <CLIENT_KEY>
AllowedIPs = 10.0.0.2/32
```

## 客户端配置
```ini
[Interface]
Address = 10.0.0.2/24
PrivateKey = <CLIENT_KEY>
DNS = 1.1.1.1

[Peer]
PublicKey = <SERVER_KEY>
Endpoint = <SERVER_IP>:51820
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25
```

## 管理
```bash
wg-quick up wg0 && wg show
systemctl enable wg-quick@wg0
```

## 注意事项
- UDP 51820 防火墙放行
- 每 90 天轮换密钥
- PersistentKeepalive 保持 NAT 映射

