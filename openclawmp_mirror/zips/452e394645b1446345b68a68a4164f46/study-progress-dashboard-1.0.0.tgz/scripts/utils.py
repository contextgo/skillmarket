#!/usr/bin/env python3
"""
Feishu API 工具封装

统一调用 lark-cli 并处理常见错误
避免硬编码路径，所有路径通过参数或环境变量传递

Author: Friday AI Assistant
License: MIT
"""

import subprocess
import json
import os
from typing import Dict, List, Optional, Any
from pathlib import Path

# 环境变量
LARK_CLI = os.getenv("LARK_CLI", "lark-cli")
OPENCLAW_HOME = os.getenv("OPENCLAW_HOME", str(Path.home() / ".openclaw"))

class FeishuAPI:
    """Feishu API 封装类"""

    def __init__(self, cli_path: str = None):
        self.cli = cli_path or LARK_CLI
        self._check_cli()

    def _check_cli(self):
        """检查 lark-cli 是否可用"""
        try:
            result = subprocess.run([self.cli, "--version"], capture_output=True, timeout=5)
            if result.returncode != 0:
                raise RuntimeError(f"lark-cli 不可用: {result.stderr.decode()}")
        except FileNotFoundError:
            raise RuntimeError(f"未找到 lark-cli: {self.cli}")

    def run(self, args: List[str], input_data: Optional[str] = None,
            timeout: int = 30) -> Dict:
        """
        执行 lark-cli 命令

        Args:
            args: 命令参数列表（不含 'lark-cli' 本身）
            input_data: 标准输入数据（JSON 字符串）
            timeout: 超时秒数

        Returns:
            解析后的 JSON 对象
        """
        cmd = [self.cli] + args
        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                input=input_data,
                timeout=timeout
            )
            if result.returncode != 0:
                error_msg = result.stderr.strip() or "Unknown error"
                raise RuntimeError(f"lark-cli 执行失败: {error_msg}")
            return json.loads(result.stdout)
        except subprocess.TimeoutExpired:
            raise RuntimeError(f"lark-cli 调用超时 ({timeout}s)")
        except json.JSONDecodeError as e:
            raise RuntimeError(f"JSON 解析失败: {e}\n原始输出: {result.stdout[:500]}")

    def auth_whoami(self) -> Dict:
        """获取当前用户信息"""
        return self.run(["auth", "whoami"])

    def get_user_open_id(self) -> str:
        """快捷获取 open_id"""
        return self.auth_whoami().get("open_id", "")

    # ============ Bitable 操作 ============

    def bitable_app_list(self, page_size: int = 50) -> Dict:
        """列出多维表格应用"""
        return self.run([
            "bitable", "app", "list",
            "--page-size", str(page_size)
        ])

    def bitable_app_create(self, name: str, folder_token: str = None) -> Dict:
        """创建多维表格应用"""
        args = ["bitable", "app", "create", "--name", name]
        if folder_token:
            args.extend(["--folder-token", folder_token])
        return self.run(args)

    def bitable_app_get(self, app_token: str) -> Dict:
        """获取应用元数据"""
        return self.run(["bitable", "app", "get", "--app-token", app_token])

    def bitable_table_create(self, app_token: str, table_name: str,
                            fields: List[Dict] = None) -> Dict:
        """
        创建数据表

        Args:
            app_token: 应用 token
            table_name: 表名
            fields: 字段定义列表（可选，后续添加）
        """
        result = self.run([
            "bitable", "app", "table", "create",
            "--app-token", app_token,
            "--name", table_name
        ])
        table_id = result.get("table_id")

        # 如果提供了字段定义，创建字段
        if fields:
            for field in fields:
                self.bitable_field_create(app_token, table_id, field)

        return {"table_id": table_id, "name": table_name}

    def bitable_field_create(self, app_token: str, table_id: str,
                            field_def: Dict) -> Dict:
        """创建字段"""
        args = [
            "bitable", "app", "table", "field", "create",
            "--app-token", app_token,
            "--table-id", table_id,
            "--field-name", field_def["field_name"],
            "--type", str(field_def["type"])
        ]
        # 处理 property（如 options, formatter）
        if field_def.get("property"):
            # 注意：lark-cli 可能需要将 property 转为 JSON 字符串参数
            # 这里假设 --property 参数接受 JSON
            args.extend(["--property", json.dumps(field_def["property"], ensure_ascii=False)])

        return self.run(args)

    def bitable_record_create(self, app_token: str, table_id: str,
                             fields: Dict) -> Dict:
        """创建单条记录"""
        return self.run([
            "bitable", "app", "table", "record", "create",
            "--app-token", app_token,
            "--table-id", table_id
        ], json.dumps({"fields": fields}))

    def bitable_record_batch_create(self, app_token: str, table_id: str,
                                   records: List[Dict]) -> Dict:
        """批量创建记录"""
        return self.run([
            "bitable", "app", "table", "record", "batch-create",
            "--app-token", app_token,
            "--table-id", table_id
        ], json.dumps({"records": [{"fields": r} for r in records]}))

    # ============ Calendar 操作 ============

    def calendar_event_list(self, start_time: str, end_time: str,
                          page_size: int = 100) -> Dict:
        """
        查询日历事件

        Args:
            start_time: ISO 8601 格式开始时间
            end_time: ISO 8601 格式结束时间
            page_size: 每页数量
        """
        return self.run([
            "calendar", "event", "list",
            "--start-time", start_time,
            "--end-time", end_time,
            "--page-size", str(page_size)
        ])

    # ============ 辅助函数 ============

    @staticmethod
    def classify_subject(summary: str) -> Optional[str]:
        """根据事件标题识别科目"""
        summary_lower = summary.lower()
        if any(kw in summary_lower for kw in ["🎯", "背单词", "单词", "英语", "english"]):
            return "英语"
        elif any(kw in summary_lower for kw in ["🔢", "数学", "math", "高数"]):
            return "数学"
        elif any(kw in summary_lower for kw in ["📘", "专业课", "专业"]):
            return "专业课"
        return None

    @staticmethod
    def classify_time_slot(timestamp: str) -> str:
        """根据时间戳判断时间段"""
        try:
            from datetime import datetime
            # 处理时区
            if "Z" in timestamp:
                timestamp = timestamp.replace("Z", "+00:00")
            elif "+" not in timestamp:
                timestamp = timestamp + "+08:00"
            dt = datetime.fromisoformat(timestamp)
            hour = dt.hour
            if 5 <= hour < 12:
                return "上午"
            elif 12 <= hour < 18:
                return "下午"
            else:
                return "晚上"
        except Exception:
            return "下午"

    @staticmethod
    def calc_duration_minutes(event: Dict) -> float:
        """计算事件时长（分钟）"""
        start = event.get("start_time", "")
        end = event.get("end_time", "")
        try:
            from datetime import datetime
            for ts in [start, end]:
                if "Z" in ts:
                    ts = ts.replace("Z", "+00:00")
                elif "+" not in ts:
                    ts = ts + "+08:00"

            start_dt = datetime.fromisoformat(start)
            end_dt = datetime.fromisoformat(end)
            return (end_dt - start_dt).total_seconds() / 60
        except Exception:
            return 60.0

# ============ 独立函数接口 ============

_api = None

def get_api() -> FeishuAPI:
    """获取全局 API 实例（单例）"""
    global _api
    if _api is None:
        _api = FeishuAPI()
    return _api

def run_lark_cli_safe(args: List[str], input_data: Optional[str] = None) -> Dict:
    """安全调用 lark-cli（供外部使用）"""
    return get_api().run(args, input_data)
