---
name: study-progress-dashboard
description: 一键创建 Feishu 多维表格学习进度追踪系统，自动从日历导入事件、计算统计、生成周报
version: 1.0.0
author: Friday (OpenClaw Agent)
category: productivity
tags:
  - study
  - progress-tracking
  - feishu
  - bitable
  - calendar
  - dashboard
---

# Study Progress Dashboard Skill

## Overview

This skill creates a comprehensive study progress tracking system on Feishu (Lark) Bitable, designed originally for graduate exam preparation but adaptable to any learning scenario.

**Key Features:**
- Three linked tables: Study Sessions, Subject Stats, Weekly Reports
- Automatic calendar event ingestion (keyword-based subject detection)
- Time slot classification (morning/afternoon/evening)
- Auto-calculated statistics and weakness identification
- Weekly report generation with actionable insights

## Installation

Prerequisites:
- OpenClaw with Feishu integration
- `lark-cli` configured and authenticated
- Feishu app with Bitable and Calendar scopes

```bash
# Clone or copy to OpenClaw skills directory
cp -r . ~/.openclaw/workspace/skills/study-progress-dashboard/

# Verify installation
openclaw skills list | grep study-progress
```

## Usage

### Create Dashboard (First Time)

```bash
# Basic creation with default name
python scripts/create_dashboard.py

# Custom name and export config for backup
python scripts/create_dashboard.py --name "我的考研看板" --output ~/dashboard-config.json
```

### Import Calendar Events

```bash
# Import last 7 days of study events from calendar
python scripts/create_dashboard.py --import-calendar --days 7

# Import for specific user
python scripts/create_dashboard.py --import-calendar --days 30 --user-open-id ou_xxx
```

### Update Existing Dashboard

```bash
# Use existing bitable token to add new calendar events
python scripts/create_dashboard.py --bitable-token UlUlbGyjOas96OsSbRrckFQDnaf --import-calendar --days 1
```

## Schema Design

### Table 1: Study Sessions (记录表)

| Field | Type | Description |
|-------|------|-------------|
| 日期 | DateTime | Study date (primary key) |
| 科目 | SingleSelect | Subject: English/Math/Specialty |
| 学习时长 | Number | Duration in minutes |
| 时间段 | SingleSelect | Morning/Afternoon/Evening |
| 完成度 | Number | Completion percentage (0-100) |
| 掌握程度 | Number | Mastery rating (1-5 stars) |
| 难点笔记 | Text | Notes on difficulties |
| 关联日历事件 | URL | Link to source calendar event |

### Table 2: Subject Stats (科目统计表)

| Field | Type | Description |
|-------|------|-------------|
| 科目 | SingleSelect | Subject name |
| 总时长 | Number | Total study minutes |
| 平均时长 | Number | Average minutes per session |
| 完成率趋势 | Number | Completion rate trend (%) |
| 薄弱环节 | Text | Identified weak areas |
| 目标差距 | Text | Gap to target (planned vs actual) |

### Table 3: Weekly Reports (周报表)

| Field | Type | Description |
|-------|------|-------------|
| 周次 | Text | Week identifier (e.g., "W14") |
| 开始日期 | DateTime | Week start date |
| 结束日期 | DateTime | Week end date |
| 各科时长汇总 | Text | Subject breakdown (JSON or formatted) |
| 与上周对比 | Text | Week-over-week comparison |
| 调整建议 | Text | Recommendations for next week |

## Calendar Event Mapping

The script automatically parses Feishu calendar events and maps them to subjects based on:

| Keyword / Emoji | Subject | Notes |
|-----------------|---------|-------|
| 🎯, "背单词", "单词" | English | Vocabulary study |
| 🔢, "数学" | Math | Problem sets, lectures |
| 📘, "专业课" | Specialty | Major-specific topics |

Event duration (in minutes) is extracted from the calendar event's time range.

## Configuration

Environment variables (optional but recommended):

```bash
export FEISHU_APP_ID=your_app_id
export FEISHU_APP_SECRET=your_app_secret
export FEISHU_USER_OPEN_ID=your_open_id  # for user-specific operations
```

Command-line arguments:

- `--name`: Dashboard title (default: "考研进度追踪看板")
- `--output`: JSON file to save dashboard metadata (for backup/restore)
- `--bitable-token`: Existing app token to modify (skips creation)
- `--import-calendar`: Trigger calendar import
- `--days`: Number of past days to import (default: 7)
- `--user-open-id`: Specific user's calendar to read (default: current user)

## Output

On success, the script outputs:

```json
{
  "status": "success",
  "bitable_token": "UlUlbGyjOas96OsSbRrckFQDnaf",
  "tables": {
    "sessions": "tbl0mr868ReAIQgS",
    "stats": "tbliN2wPVoY8U1kK",
    "weekly": "tblmxsdsF1T0NXoZ"
  },
  "records_imported": 12,
  "calendar_sync": true
}
```

## Troubleshooting

**Error: "Bitable app already exists"**
- Use `--bitable-token` to target existing app, or delete the old one manually.

**No calendar events imported**
- Check that calendar events contain subject keywords (🎯🔢📘)
- Verify `lark-cli` is authenticated: `lark-cli auth whoami`
- Ensure you have Calendar read permissions

**Permission denied**
- Confirm Feishu app has `bitable:app` and `calendar:event` scopes
- Re-auth with: `lark-cli auth login`

## Roadmap

- [ ] Add email notification for weekly summary
- [ ] Support custom subject keywords
- [ ] Integrate with task management (Feishu Tasks)
- [ ] Mobile-friendly view template
- [ ] Export to Excel/PDF

## License

MIT

## Credits

Built by Friday AI Assistant for William's graduate exam preparation. Open-sourced under MIT.
