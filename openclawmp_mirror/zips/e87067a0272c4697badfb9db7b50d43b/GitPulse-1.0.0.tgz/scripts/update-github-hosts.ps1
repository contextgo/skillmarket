﻿#Requires -Version 5.1
<#
.SYNOPSIS
    生成 GitHub 安全 hosts 推荐配置（基于 api.github.com/meta 白名单）
.DESCRIPTION
    1. 自动拉取/更新 github_meta.json
    2. 基于 meta 白名单测试 DNS 解析的 IP
    3. 生成 github_hosts_safe.txt（仅推荐配置）
    4. 默认不直接写入系统 hosts —— 该步骤由 AI 分析合并后执行
    5. 提供 -Apply 参数：在 AI 无管理员权限时，可自动申请 UAC 提权完成系统写入
.PARAMETER Apply
    将 github_hosts_safe.txt 中的内容安全写入系统 hosts 文件。如果当前 shell 无管理员权限，会自动弹出 UAC 提权窗口。
.PARAMETER NoMetaUpdate
    跳过更新 github_meta.json，使用本地已有文件
#>
param(
    [switch]$Apply,
    [switch]$NoMetaUpdate
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$ErrorActionPreference = "Stop"
$metaPath = "github_meta.json"

# Helper: exit with clear message
function Exit-WithError {
    param([string]$Message, [int]$Code = 1)
    Write-Error $Message
    exit $Code
}

# --- 自动管理员提权（仅当 -Apply 且非管理员时） ---
$isAdmin = ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
if ($Apply -and -not $isAdmin) {
    Write-Host "需要管理员权限来修改系统 hosts，正在申请提升..." -ForegroundColor Yellow
    $argList = @("-ExecutionPolicy", "Bypass", "-File", $PSCommandPath, "-Apply")
    if ($NoMetaUpdate) { $argList += "-NoMetaUpdate" }
    Start-Process powershell -Verb RunAs -ArgumentList $argList -Wait
    exit
}
# --- 提权结束 ---

# 1. 更新 meta（可选）
if (-not $NoMetaUpdate) {
    Write-Host "正在拉取最新 api.github.com/meta..." -ForegroundColor Cyan
    if (-not (Get-Command curl.exe -ErrorAction SilentlyContinue)) {
        Exit-WithError "找不到 curl.exe，请确保系统已安装 curl 或手动下载 $metaPath 到当前目录。"
    }
    try {
        curl.exe -s --max-time 30 https://api.github.com/meta -o "$metaPath.tmp"
        if ($LASTEXITCODE -ne 0) { throw "curl 返回非零退出码: $LASTEXITCODE" }
        if (-not (Test-Path "$metaPath.tmp")) { throw "下载文件未生成" }
        if ((Get-Item "$metaPath.tmp").Length -lt 1000) {
            Remove-Item "$metaPath.tmp" -Force
            throw "下载内容过小，可能网络异常"
        }
        # Validate JSON
        $null = Get-Content "$metaPath.tmp" -Raw | ConvertFrom-Json
        Move-Item -Path "$metaPath.tmp" -Destination $metaPath -Force
        Write-Host "已更新 $metaPath" -ForegroundColor Green
    } catch {
        if (Test-Path "$metaPath.tmp") { Remove-Item "$metaPath.tmp" -Force }
        if (Test-Path $metaPath) {
            Write-Warning "拉取最新 meta 失败（$_），将使用本地缓存的 $metaPath"
        } else {
            Exit-WithError "拉取失败且本地无缓存。建议手动下载 https://api.github.com/meta 保存为 $metaPath。原始错误: $_"
        }
    }
}

# 2. 读取并校验 meta
if (-not (Test-Path $metaPath)) {
    Exit-WithError "$metaPath 不存在。请先运行脚本不带 -NoMetaUpdate，或手动下载 meta。"
}

try {
    $meta = Get-Content -Path $metaPath -Raw | ConvertFrom-Json
} catch {
    Exit-WithError "$metaPath 解析为 JSON 失败，文件可能损坏。建议删除后重新下载。错误: $_"
}

$requiredFields = @('web', 'api', 'git')
foreach ($field in $requiredFields) {
    if (-not $meta.$field) {
        Exit-WithError "$metaPath 缺少必要字段 '$field'，可能不是有效的 GitHub meta 响应。"
    }
}

# 辅助函数
function Test-IpInCidr {
    param([string]$Ip, [string]$Cidr)
    try {
        $parts = $Cidr.Split('/')
        $baseIp = $parts[0]
        $prefix = [int]$parts[1]
        $ipBytes = [System.Net.IPAddress]::Parse($Ip).GetAddressBytes()
        $baseBytes = [System.Net.IPAddress]::Parse($baseIp).GetAddressBytes()
        [Array]::Reverse($ipBytes)
        [Array]::Reverse($baseBytes)
        $ipInt = [BitConverter]::ToUInt32($ipBytes, 0)
        $baseInt = [BitConverter]::ToUInt32($baseBytes, 0)
        $mask = [uint32]::MaxValue -shl (32 - $prefix)
        return ($ipInt -band $mask) -eq ($baseInt -band $mask)
    } catch { return $false }
}

function Test-IpTrusted {
    param([string]$Ip, [string[]]$Cidrs)
    foreach ($cidr in $Cidrs) {
        if ($cidr -match ':') { continue }
        if ($cidr -eq "$Ip/32") { return $true }
        if (Test-IpInCidr -Ip $Ip -Cidr $cidr) { return $true }
    }
    return $false
}

$domainMap = @{
    "github.com"                   = $meta.web
    "gist.github.com"              = $meta.web
    "raw.githubusercontent.com"    = $meta.web
    "api.github.com"               = $meta.api
    "codeload.github.com"          = $meta.web + $meta.git
    "github.global.ssl.fastly.net" = $meta.web
    "objects.githubusercontent.com"= $meta.web
}

$pingCount = 4
$results = @()
$allTrustedUnreachable = $true

Write-Host "`n正在基于 meta 白名单测试 GitHub 域名..." -ForegroundColor Cyan

foreach ($entry in $domainMap.GetEnumerator()) {
    $domain = $entry.Key
    $trustedCidrs = $entry.Value
    Write-Host "[$domain]" -ForegroundColor Yellow -NoNewline

    try {
        $records = Resolve-DnsName -Name $domain -Type A -ErrorAction Stop |
            Where-Object { $_.QueryType -eq 'A' -or $_.Type -eq 'A' } |
            Select-Object -ExpandProperty IPAddress -Unique
    } catch {
        Write-Host " 解析失败" -ForegroundColor Red
        continue
    }

    $best = $null
    $tested = 0
    foreach ($ip in $records) {
        if (-not (Test-IpTrusted -Ip $ip -Cidrs $trustedCidrs)) { continue }
        $tested++
        try {
            $avg = [math]::Round((Test-Connection -ComputerName $ip -Count $pingCount -ErrorAction Stop |
                Measure-Object -Property ResponseTime -Average).Average, 1)
            if (-not $best -or $avg -lt $best.Avg) { $best = @{ IP = $ip; Avg = $avg } }
            $allTrustedUnreachable = $false
        } catch {}
    }

    if ($best) {
        $results += [PSCustomObject]@{ Domain = $domain; IP = $best.IP; AvgMs = $best.Avg }
        Write-Host " -> $($best.IP) ($($best.Avg)ms)" -ForegroundColor Green
    } else {
        Write-Host " -> 无可用 IP (测试了 $tested 个可信IP)" -ForegroundColor Red
    }
}

if ($results.Count -eq 0) {
    if ($allTrustedUnreachable) {
        Exit-WithError "所有 GitHub 域名均无可用 IP。可能原因：DNS 污染严重、防火墙拦截、或需要代理/VPN。建议检查网络环境后再试。"
    } else {
        Exit-WithError "未生成任何有效 hosts 条目。所有域名均解析失败或无可信 IP。"
    }
}

# 3. 生成 hosts 块
$hostsBlock = @("# === GitHub Safe Hosts (Generated at $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) ===")
foreach ($r in $results) { $hostsBlock += "{0,-24} {1}" -f $r.IP, $r.Domain }
$hostsBlock += "# === End GitHub Safe Hosts ===`n"

$outputFile = "github_hosts_safe.txt"
$hostsBlock | Out-File -FilePath $outputFile -Encoding utf8 -Force
Write-Host "`n配置已保存到: $outputFile" -ForegroundColor Green

# 4. 如果指定了 -Apply，执行系统写入
if ($Apply) {
    Write-Host "正在应用配置到系统 hosts..." -ForegroundColor Cyan
    $systemHosts = "$env:SystemRoot\System32\drivers\etc\hosts"

    try {
        # 备份
        $backup = "$systemHosts.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
        Copy-Item -Path $systemHosts -Destination $backup -Force
        Write-Host "已备份原 hosts: $backup" -ForegroundColor Gray

        # 清理旧块
        $content = Get-Content -Path $systemHosts -Raw -ErrorAction Stop
        $pattern = '(?s)\r?\n# === GitHub Safe Hosts \(Generated at.*?\r?\n# === End GitHub Safe Hosts ===\r?\n'
        $content = [regex]::Replace($content, $pattern, "`n")

        # 追加新块
        $content += "`n" + ($hostsBlock -join "`r`n")
        $content | Out-File -FilePath $systemHosts -Encoding utf8 -Force

        ipconfig /flushdns | Out-Null
        Write-Host "已成功写入系统 hosts 并刷新 DNS 缓存！" -ForegroundColor Green
    } catch {
        Write-Error "写入失败: $_"
        exit 1
    }
} else {
    Write-Host "下一步：由 AI 读取当前系统 hosts，分析并安全合并后写入。" -ForegroundColor Yellow
    Write-Host "如果 AI 没有管理员权限，可运行本脚本并带上 -Apply 参数进行自动提权写入。" -ForegroundColor Gray
}
