﻿---
name: GitPulse
description: >
  安全更新 Windows 系统 hosts 文件以修复 GitHub 访问问题。基于 GitHub 官方 api.github.com/meta IP 白名单进行可信校验。
  触发场景包括：用户说 GitHub 打不开、GitHub 很慢、GitHub 无法访问、GitHub 连接超时、git clone 失败、
  raw.githubusercontent.com 无法访问/下载失败、gist.github.com 打不开、api.github.com 访问被拒绝、
  GitHub 页面加载不出来、GitHub 被墙、GitHub DNS 污染、需要修改/更新/替换/刷新/写入 GitHub hosts、
  系统 hosts 文件怎么改、hosts 映射、怎么给 GitHub 换 IP、github.com 解析失败、
  codeload.github.com 下载慢、objects.githubusercontent.com 拒绝连接，
  或任何与"GitHub + hosts/DNS/访问慢/打不开"相关的请求。
---

# GitPulse — GitHub Hosts 更新助手

使用经过 `api.github.com/meta` 官方 IP 白名单校验的安全 IP，更新系统 hosts 文件，修复 GitHub 访问问题。**绝不允许脚本直接覆盖系统 hosts 文件** — 必须由 AI 逐行分析、安全合并，避免误删 Docker、VPN、公司内网等重要条目。

## 核心原则

**每个关键步骤前，必须向用户展示当前状态，并征求用户明确同意后再继续。**

如果任何一步失败或状态异常，**立即停止**，向用户报告当前精确状态，并给出明确的恢复路径。当前步骤未完成时，绝不允许进入下一步。

---

## 交互式工作流

### 阶段 0：启动前确认

向用户说明将要执行的操作：
1. 拉取 GitHub 官方 `api.github.com/meta` 数据
2. 测试可信 IP 并生成推荐 hosts 块
3. 读取当前系统 hosts 文件
4. 展示差异分析（diff）
5. 在用户确认后写入系统 hosts 并刷新 DNS

**在阶段 0 必须询问用户："是否继续？" 得到肯定答复后再开始。**

---

### 阶段 1：生成安全推荐配置

运行脚本：

```powershell
.\GitPulse\scripts\update-github-hosts.ps1
```

脚本生成：
- `github_meta.json` — 官方 meta 原始响应
- `github_hosts_safe.txt` — 推荐的 hosts 块

#### 故障处理

| 问题 | 应对措施 |
|---------|----------|
| `curl.exe` 不存在 / 网络不通 / 下载失败 | 告知用户检查网络，或手动下载 meta 文件到当前目录，然后使用 `-NoMetaUpdate` 重试。停止。 |
| `github_meta.json` 缺失或 JSON 解析失败 | 停止。没有有效的官方白名单时不允许继续。 |
| `meta` 缺少必要字段（`web`/`api`/`git`） | 停止。文件可能损坏或非官方响应。 |
| 所有域名解析到的 IP 均不在白名单内 | 警告用户 DNS 污染可能非常严重。停止，并建议使用代理或 VPN。 |
| 所有可信 IP 均 Ping 不通 | 警告用户 GitHub 官方 IP 当前不可达。停止，并建议检查防火墙或代理设置。 |
| `github_hosts_safe.txt` 为空 | 停止。不允许继续。 |

#### 阶段 1 结束动作

**向用户汇报测试结果**，格式如下：

```
已生成安全推荐配置，测试结果如下：
- github.com -> 20.205.243.166 (100ms) ✅
- api.github.com -> 20.205.243.168 (101ms) ✅
- raw.githubusercontent.com -> 185.199.110.133 (113ms) ✅
...

如果继续，下一步将读取你的系统 hosts 文件，分析现有内容并展示差异对比。
```

**必须等待用户回复"继续"、"好"、"下一步"等肯定答复后，才能进入阶段 2。**

---

### 阶段 2：读取当前系统 hosts 文件

使用文件读取工具读取 `C:\WINDOWS\System32\drivers\etc\hosts`。

#### 故障处理

| 问题 | 应对措施 |
|---------|----------|
| 读取文件返回权限不足 | **禁止继续写入**。告知用户文件被锁定或无权限访问，展示 `github_hosts_safe.txt` 内容供手动复制。停止。 |
| hosts 文件不存在（极罕见） | 向用户报告此异常，说明将新建一个标准 hosts 文件。**必须征得用户同意后再创建**。 |
| 文件为空或只有空白字符 | 视为空文件，告知用户当前 hosts 为空。继续。 |

#### 阶段 2 结束动作

**向用户展示当前 hosts 文件的完整内容**（或告知为空/不存在），并说明：

```
已读取当前系统 hosts 文件，内容包括：
[展示 hosts 内容]

如果继续，下一步将分析新旧差异，并向你展示修改方案（diff）。
```

**必须等待用户明确同意后，才能进入阶段 3。**

---

### 阶段 3：分析差异并展示修改方案

AI 执行分析：
1. **扫描**现有 hosts 中是否有 `# === GitHub Safe Hosts` 到 `# === End GitHub Safe Hosts ===` 的标记块。如果有，仅标记该块为待删除。
2. **完整保留**所有其他内容。
3. 将 `github_hosts_safe.txt` 中的新块标记为待追加。
4. 检查同一域名在文件其他位置是否已存在，如有则标记为待注释。

#### 阶段 3 结束动作

**必须向用户展示完整的 diff（修改前 vs 修改后）**，格式如下：

```diff
- 删除的内容
+ 新增的内容
  保留的内容（可选展示）
```

并附上一句话总结：
> "以上是你的系统 hosts 文件的修改方案。我会删除旧的 GitHub 块（如果有），保留 Docker/公司内网等其他条目，追加新的 GitHub 安全 IP。是否确认写入？"

**必须等待用户明确回复"确认"、"写入"、"应用"等肯定答复后，才能进入阶段 4。**

如果用户回复"不"、"算了"、"再想想"等否定答复，立即停止，并告知用户推荐的 hosts 块已保存在 `github_hosts_safe.txt` 中，可随时手动应用。

#### 特殊处理

| 问题 | 应对措施 |
|---------|----------|
| 发现多个不一致的 GitHub 风格块 | 向用户展示相关段落，**询问应替换哪一个**，禁止猜测。 |
| 同一域名出现在关键的公司/VPN 块中 | 在 diff 中高亮提醒用户，询问是否注释掉公司块中的重复域名，还是保留两者。 |
| 分析结果看起来可疑（大量内容消失） | **禁止直接进入阶段 4**。向用户说明异常，建议检查原始文件，或让用户决定如何处理。 |

---

### 阶段 4：备份与写入

在用户确认 diff 后，AI 尝试写入系统 hosts 文件：

1. **创建带时间戳的备份**：
   ```powershell
   $backup = "$env:SystemRoot\System32\drivers\etc\hosts.bak.$(Get-Date -Format 'yyyyMMddHHmmss')"
   Copy-Item "$env:SystemRoot\System32\drivers\etc\hosts" $backup -Force
   ```
2. 使用文件写入工具将合并后的内容写回系统 hosts 文件。
3. 执行 `ipconfig /flushdns`。

#### 故障处理

| 问题 | 应对措施 |
|---------|----------|
| 备份失败（权限不足） | **禁止写入**。告知用户备份失败，建议使用管理员权限运行，或手动应用。停止。 |
| 备份成功但 AI 写入工具权限不足 | AI 调用 bundled 脚本进行自动 UAC 提权写入：<br>` .\GitPulse\scripts\update-github-hosts.ps1 -Apply `<br>该脚本检测到非管理员权限时会自动弹出 UAC 窗口，用户点击"是"后即可完成写入。 |
| 备份成功但写入失败 | 告知用户备份位置（如 `hosts.bak.xxx`），并给出恢复命令。停止。 |

#### 阶段 4 结束动作

- 如果 AI 直接写入成功：
  > "已写入系统 hosts 文件，备份为 `hosts.bak.xxx`，DNS 缓存已刷新。下一步将读取文件进行验证。是否继续？"
- 如果由脚本 `-Apply` 提权写入：
  > "已通过 UAC 提权完成系统 hosts 写入，DNS 缓存已刷新。下一步将读取文件进行验证。是否继续？"

**必须等待用户明确同意后，才能进入阶段 5。**

---

### 阶段 5：验证

再次读取 hosts 文件，检查：
- 新的 GitHub 块是否完整存在
- Docker、VPN、公司内网等原有条目是否完好
- 文件是否被截断或重复

#### 故障处理

| 问题 | 应对措施 |
|---------|----------|
| 验证发现 Docker/公司条目丢失 | **立即从备份恢复**。告知用户发生了数据丢失，并展示丢失内容。停止。 |
| 验证发现 GitHub 块缺失或被截断 | **立即从备份恢复**。可能安全软件拦截了写入。停止。 |
| 验证通过 | 告知用户更新成功，并提示备份位置和恢复方法。 |

#### 阶段 5 结束动作

**向用户展示最终 hosts 文件的摘要**（重点展示 GitHub 块和保留的关键条目），并告知：
- 更新成功
- 备份文件位置
- 如果浏览器仍打不开，参考"常见问题排查"章节

---

## 常见问题排查：hosts 已更新但浏览器仍打不开

如果阶段 5 验证通过，但用户反馈浏览器仍然无法访问 GitHub，按以下分层顺序排查。

### 第一步：确认系统层是否已通

在 PowerShell 中执行：

```powershell
curl.exe -s -I --connect-timeout 5 https://github.com
```

| 结果 | 含义 | 下一步 |
|------|------|--------|
| 返回 `HTTP/1.1 200 OK` | **系统 hosts 已生效**，问题在浏览器层面 | 跳到"浏览器排查" |
| 返回 `timeout`、`refused`、`reset` | **系统层也不通**，443 端口被拦截 | 跳到"系统层仍不通" |

### 第二步：浏览器排查（系统层已通时使用）

Chromium 内核浏览器（Edge/Chrome）经常有自己的 DNS 缓存或安全 DNS 机制，导致绕过系统 hosts。

**每次排查一步后，都让用户测试浏览器是否可以打开 GitHub，不要一次性执行太多步骤。**

1. **彻底结束浏览器进程并重启**
   - 按 `Ctrl+Shift+Esc` 结束所有 **Microsoft Edge** / **Google Chrome** 进程，或运行：
     ```powershell
     Get-Process msedge -ErrorAction SilentlyContinue | Stop-Process -Force
     ```

2. **使用 InPrivate / 无痕窗口测试**
   - Edge: `Ctrl+Shift+N`；Chrome: `Ctrl+Shift+Incognito`
   - 如果能打开 → 说明是普通窗口的**缓存或扩展**导致。让用户清除缓存或禁用扩展。
   - 如果打不开 → 继续第 3 步。

3. **关闭浏览器的"安全 DNS"**
   - Edge: `edge://settings/privacy` → 关闭"使用安全的 DNS 指定如何查找网站的网络地址"
   - Chrome: `chrome://settings/security` → 关闭"使用安全 DNS"
   - 这是最常见的原因：开启后浏览器会走 Cloudflare DoH，**完全绕过 Windows hosts**。

4. **检查代理/翻墙扩展**
   - Edge: `edge://extensions/` → 暂时禁用 Clash、SwitchyOmega 等扩展。

5. **清除浏览器内部 DNS 缓存**
   - Edge/Chrome: `edge://net-internals/#dns` → 点击 "Clear host cache"

### 第三步：系统层仍不通（curl 也失败）

如果 `curl` 也超时或连接被拒绝，说明 **TCP 443 端口被防火墙/GFW 直接拦截**，或存在 **SNI 阻断**。此时换 IP 已经无能为力。

应对措施：
- 告知用户：**hosts 只能解决 DNS 污染，无法绕过协议层封锁**。
- 建议改用代理/VPN（Clash、V2Ray、Netch 等）作为根本解决方案。
- 如果用户坚持，可以尝试从 `api.github.com/meta` 的 `web` 字段中挑一个不同的 `/32` IP 测试，但成功率极低。**测试前必须再次征得用户同意**。

---

## 恢复指南（Cheat Sheet）

如果过程中出现任何问题，在**管理员 PowerShell** 中执行以下命令恢复：

```powershell
# 列出所有备份
Get-ChildItem "$env:SystemRoot\System32\drivers\etc\hosts.bak.*"

# 恢复到最新的备份
$latest = (Get-ChildItem "$env:SystemRoot\System32\drivers\etc\hosts.bak.*" | Sort-Object LastWriteTime -Descending | Select-Object -First 1).FullName
Copy-Item $latest "$env:SystemRoot\System32\drivers\etc\hosts" -Force
ipconfig /flushdns
```

## 重要安全规则

- **禁止让 PowerShell 脚本直接写入系统 hosts 文件。** 脚本被严格限制为只生成 `github_hosts_safe.txt`。
- **每个关键阶段必须展示状态并等待用户确认**，不允许全自动静默执行。
- **修改前必须读取现有 hosts 文件。**
- **写入前必须创建带时间戳的备份。**
- **任何一步失败必须立即停止**，不允许进入下一步。
- 写入后必须再次读取验证。

## 安装与分发本 Skill

本 Skill 采用兼容 [AgentSkills](https://agentskills.io) 的标准格式，可在任何支持该协议的 AI 客户端中使用。

### 通用安装方式

将 `GitPulse` 文件夹放入你使用的 AI 客户端的 skills 目录即可：
- **OpenClaw**：`~/.openclaw/skills/GitPulse/` 或 `<workspace>/skills/GitPulse/`
- **Claude Code**：`~/.claude/skills/GitPulse/`
- 其他支持 AgentSkills 的客户端：参考其文档中对应的 skills 加载路径

### 使用 `.skill` 分发包

`GitPulse.skill` 是一个标准 zip 格式的分发包。解压到对应客户端的 skills 目录即可生效：

```powershell
# 示例：安装到 OpenClaw 用户目录
Expand-Archive -Path "GitPulse.skill" -DestinationPath "$env:USERPROFILE\.openclaw\skills\GitPulse"
```

### 发布到 ClawHub（水产市场）

若要将本 skill 发布到 ClawHub，需满足以下规则：
- **根目录必须有 `.metadata.json`**，包含 `assetType`（`skill`）、`name`、`displayName`、`semver`、`category`、`tags`
- **根目录必须有 `README.md`**，包含：
  1. 一级标题（`# 标题`）
  2. 描述段落（标题后的第一段正文，说明解决什么问题、如何使用）

GitPulse 已包含符合要求的 `.metadata.json` 和 `README.md`，可直接用于发布。

---

## 域名与白名单字段对照表

| 域名 | 使用的 meta 白名字段 |
|--------|------------------------------|
| `github.com` | `web` |
| `gist.github.com` | `web` |
| `raw.githubusercontent.com` | `web` |
| `api.github.com` | `api` |
| `codeload.github.com` | `web` + `git` |
| `github.global.ssl.fastly.net` | `web` |
| `objects.githubusercontent.com` | `web` |
