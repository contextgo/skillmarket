#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信文件快速打开工具
配合每日总结报告使用，可通过输入编号快速打开文件
"""

import os
import sys
import json
from pathlib import Path

def load_report_data(report_date=None):
    """加载报告数据"""
    # 查找最新的报告文件
    desktop = Path.home() / "Desktop"
    
    if report_date:
        report_file = desktop / f"微信文件总结报告_{report_date}.json"
    else:
        # 查找最新的json报告
        reports = list(desktop.glob("微信文件总结报告_*.json"))
        if not reports:
            print("❌ 未找到报告数据文件")
            return None
        report_file = max(reports, key=lambda x: x.stat().st_mtime)
    
    if not report_file.exists():
        print(f"❌ 报告文件不存在: {report_file}")
        return None
    
    with open(report_file, 'r', encoding='utf-8') as f:
        return json.load(f)

def show_files(data):
    """显示文件列表"""
    print("\n" + "="*60)
    print("📋 微信文件列表")
    print("="*60)
    
    for item in data:
        urgency_mark = ""
        if item.get('urgency', 0) >= 4:
            urgency_mark = " 🔴紧急"
        elif item.get('urgency', 0) >= 3:
            urgency_mark = " 🟠加急"
        
        print(f"\n[{item['index']}] {item['smart_name']}{urgency_mark}")
        print(f"    类型: {item['file_type']} | 大小: {item['size']}")
        if item.get('deadlines'):
            print(f"    ⏰ 时限: {'、'.join(item['deadlines'])}")

def open_file(data, file_index):
    """打开指定文件"""
    for item in data:
        if item['index'] == file_index:
            file_path = item.get('original_path', '')
            if not file_path:
                print(f"❌ 文件路径不存在")
                return
            
            if not os.path.exists(file_path):
                print(f"❌ 文件不存在: {file_path}")
                return
            
            print(f"\n📂 正在打开: {item['smart_name']}")
            print(f"   路径: {file_path}")
            
            try:
                # Windows打开文件
                os.startfile(file_path)
                print(f"✅ 文件已打开")
            except Exception as e:
                print(f"❌ 打开失败: {e}")
                print(f"💡 请手动复制路径打开: {file_path}")
            return
    
    print(f"❌ 未找到编号为 {file_index} 的文件")

def main():
    print("="*60)
    print("微信文件快速打开工具")
    print("="*60)
    print("💡 配合每日总结报告使用")
    print("="*60)
    
    # 加载数据
    data = load_report_data()
    if not data:
        print("\n请先生成每日总结报告")
        input("\n按回车键退出...")
        return
    
    while True:
        show_files(data)
        
        print("\n" + "-"*60)
        print("操作选项:")
        print("  [1-99] 输入编号打开对应文件")
        print("  [a]    打开所有文件（慎用）")
        print("  [r]    刷新列表")
        print("  [q]    退出")
        print("-"*60)
        
        choice = input("\n请输入选项: ").strip().lower()
        
        if choice == 'q':
            print("👋 再见！")
            break
        elif choice == 'r':
            data = load_report_data()
            if not data:
                print("❌ 刷新失败")
        elif choice == 'a':
            confirm = input("确定要打开所有文件吗？(y/n): ").strip().lower()
            if confirm == 'y':
                for item in data:
                    open_file(data, item['index'])
        elif choice.isdigit():
            file_index = int(choice)
            open_file(data, file_index)
            input("\n按回车键继续...")
        else:
            print("❌ 无效选项")

if __name__ == "__main__":
    main()
