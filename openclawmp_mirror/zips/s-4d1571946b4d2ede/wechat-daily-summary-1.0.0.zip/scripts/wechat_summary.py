#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
微信文件每日总结工具（增强版）
功能：读取微信缓存目录中最近24小时的文件，生成详细的总结报告
      包括：内容摘要、关键时限、报送要求等
"""

import os
import sys
import io
import re
import json
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Tuple

# ============== 配置区域 ==============
SOURCE_DIR = r"D:\wechat_cache\xwechat_files\protosshua_dc0f\msg\file"
OUTPUT_DIR = r"C:\Users\hua\Desktop"

# 支持的文件类型
SUPPORTED_EXTENSIONS = [
    '.pdf', '.doc', '.docx', '.xls', '.xlsx', 
    '.ppt', '.pptx', '.txt', '.csv', '.jpg', 
    '.jpeg', '.png', '.gif', '.bmp', '.webp'
]

# 时间相关关键词
TIME_KEYWORDS = [
    '截止日期', '截止时间', '完成时限', '报送时间', '提交时间', '截止时间',
    '请于', '日前', '月', '日前完成', '周报', '月报', '季报', '年报',
    '每日', '每周', '每月', '每季度', '每年',
    '上午', '下午', '前完成', '前报送', '前提交',
    '2026年', '2025年', '2027年',
    '春节', '元宵节', '元旦', '国庆', '中秋', '端午', '清明', '五一', '劳动节'
]

# ============== 文件信息提取 ==============

class FileInfoExtractor:
    """提取文件信息和内容"""
    
    @staticmethod
    def get_file_info(file_path: Path) -> Dict:
        """获取文件基本信息"""
        stat = file_path.stat()
        return {
            'path': str(file_path),
            'name': file_path.name,
            'stem': file_path.stem,
            'extension': file_path.suffix.lower(),
            'size': stat.st_size,
            'modified_time': datetime.fromtimestamp(stat.st_mtime),
            'content': ''
        }
    
    @staticmethod
    def extract_content(file_path: Path) -> str:
        """提取文件内容"""
        ext = file_path.suffix.lower()
        
        try:
            if ext in ['.pdf']:
                return FileInfoExtractor._extract_pdf(file_path)
            elif ext in ['.docx']:
                return FileInfoExtractor._extract_docx(file_path)
            elif ext in ['.doc']:
                return file_path.stem
            elif ext in ['.xlsx', '.xls', '.csv']:
                return FileInfoExtractor._extract_excel(file_path)
            elif ext in ['.pptx', '.ppt']:
                return FileInfoExtractor._extract_ppt(file_path)
            elif ext in ['.txt']:
                return FileInfoExtractor._extract_text(file_path)
            elif ext in ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp']:
                return FileInfoExtractor._extract_image_ocr(file_path)
            else:
                return file_path.stem
        except Exception as e:
            print(f"    [警告] 提取失败 {file_path.name}: {e}")
            return file_path.stem
    
    @staticmethod
    def _extract_pdf(file_path: Path) -> str:
        try:
            import fitz
            doc = fitz.open(str(file_path))
            text = ""
            for page_num in range(min(10, len(doc))):  # 增加到10页
                text += doc[page_num].get_text()
            doc.close()
            return text[:8000] if text.strip() else file_path.stem  # 增加到8000字符
        except:
            return file_path.stem
    
    @staticmethod
    def _extract_docx(file_path: Path) -> str:
        try:
            import docx2txt
            text = docx2txt.process(str(file_path))
            return text[:8000] if text.strip() else file_path.stem
        except:
            try:
                from docx import Document
                doc = Document(str(file_path))
                texts = [para.text for para in doc.paragraphs]
                content = '\n'.join(texts)
                return content[:8000] if content.strip() else file_path.stem
            except:
                return file_path.stem
    
    @staticmethod
    def _extract_excel(file_path: Path) -> str:
        try:
            import pandas as pd
            if str(file_path).endswith('.csv'):
                df = pd.read_csv(str(file_path), nrows=50)
            else:
                df = pd.read_excel(str(file_path), nrows=50)
            return df.to_string()[:5000]
        except:
            return file_path.stem
    
    @staticmethod
    def _extract_ppt(file_path: Path) -> str:
        try:
            from pptx import Presentation
            prs = Presentation(str(file_path))
            texts = []
            for slide in prs.slides[:10]:  # 增加到10页
                for shape in slide.shapes:
                    if hasattr(shape, "text") and shape.text:
                        texts.append(shape.text)
            content = '\n'.join(texts)
            return content[:8000] if content.strip() else file_path.stem
        except:
            return file_path.stem
    
    @staticmethod
    def _extract_text(file_path: Path) -> str:
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()[:8000]
        except:
            try:
                with open(file_path, 'r', encoding='gbk') as f:
                    return f.read()[:8000]
            except:
                return file_path.stem
    
    @staticmethod
    def _extract_image_ocr(file_path: Path) -> str:
        try:
            from PIL import Image
            import pytesseract
            
            tesseract_paths = [
                r'C:\Program Files\Tesseract-OCR\tesseract.exe',
                r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
                r'C:\Tesseract-OCR\tesseract.exe',
            ]
            for path in tesseract_paths:
                if os.path.exists(path):
                    pytesseract.pytesseract.tesseract_cmd = path
                    break
            
            image = Image.open(str(file_path))
            text = pytesseract.image_to_string(image, lang='chi_sim+eng')
            return text[:5000] if text.strip() else f"[图片] {file_path.stem}"
        except:
            return f"[图片] {file_path.stem}"


# ============== 智能内容分析器 ==============

class ContentAnalyzer:
    """分析文件内容，提取关键信息和生成摘要"""
    
    # 时间相关正则表达式
    TIME_PATTERNS = [
        r'(\d{4}年\d{1,2}月\d{1,2}日)[前]*[前]*[前]*完成',
        r'(\d{1,2}月\d{1,2}日)[前]*[前]*[前]*完成',
        r'(\d{4}年\d{1,2}月\d{1,2}日)[前]*[前]*[前]*报送',
        r'(\d{1,2}月\d{1,2}日)[前]*[前]*[前]*报送',
        r'请于(\d{4}年\d{1,2}月\d{1,2}日)',
        r'请于(\d{1,2}月\d{1,2}日)',
        r'(\d{4}[-/]\d{1,2}[-/]\d{1,2})',
        r'截止时间[：:]\s*(\d{4}年\d{1,2}月\d{1,2}日)',
        r'截止时间[：:]\s*(\d{1,2}月\d{1,2}日)',
        r'截止日期[：:]\s*(\d{4}年\d{1,2}月\d{1,2}日)',
        r'截止日期[：:]\s*(\d{1,2}月\d{1,2}日)',
        r'(每日|每周|每月|每季度|每年|日报|周报|月报|季报|年报)',
        r'(上午|下午)(\d{1,2}[点:：]\d{1,2})*[前]*',
        r'(春节|元宵节|元旦|国庆|中秋|端午|清明|五一|劳动节)',
    ]
    
    # 报送要求关键词
    SUBMISSION_KEYWORDS = [
        '报送', '提交', '上报', '反馈', '报送至', '发送至',
        '报至', '报送到', '发送至', '发送到', '提交到',
        '联系人', '联系电话', '联系方式', '邮箱', '邮箱地址'
    ]
    
    # 紧急程度关键词
    URGENCY_KEYWORDS = {
        '特急': 5, '加急': 4, '急件': 4, '紧急': 4,
        '尽快': 3, '及时': 3, '迅速': 3,
        '请高度重视': 3, '请务必': 3, '请立即': 4
    }
    
    @staticmethod
    def analyze_content(content: str, file_name: str) -> Dict:
        """分析内容，返回结构化信息"""
        if not content or len(content) < 10:
            return {
                'summary': '文件内容较少，无法提取有效信息。',
                'deadlines': [],
                'submission_requirements': '',
                'urgency_level': 1,
                'content_complexity': 'simple'
            }
        
        # 提取关键信息
        deadlines = ContentAnalyzer._extract_deadlines(content)
        submission = ContentAnalyzer._extract_submission_requirements(content)
        urgency = ContentAnalyzer._calculate_urgency(content)
        complexity = ContentAnalyzer._assess_complexity(content)
        
        # 生成智能摘要
        summary = ContentAnalyzer._generate_summary(content, file_name, deadlines, submission, complexity)
        
        return {
            'summary': summary,
            'deadlines': deadlines,
            'submission_requirements': submission,
            'urgency_level': urgency,
            'content_complexity': complexity
        }
    
    @staticmethod
    def _extract_deadlines(content: str) -> List[str]:
        """提取时间要求/截止日期"""
        deadlines = []
        
        for pattern in ContentAnalyzer.TIME_PATTERNS:
            matches = re.findall(pattern, content)
            for match in matches:
                if isinstance(match, tuple):
                    match = ''.join(match)
                if match and len(match) > 2:
                    # 清理并标准化
                    match = match.strip()
                    if match not in deadlines:
                        deadlines.append(match)
        
        # 去重并限制数量
        seen = set()
        unique_deadlines = []
        for d in deadlines[:5]:  # 最多5个
            key = d.replace('年', '').replace('月', '').replace('日', '')
            if key not in seen:
                seen.add(key)
                unique_deadlines.append(d)
        
        return unique_deadlines[:3]  # 最多返回3个
    
    @staticmethod
    def _extract_submission_requirements(content: str) -> str:
        """提取报送要求"""
        requirements = []
        content_lower = content.lower()
        
        # 查找报送相关句子
        for keyword in ContentAnalyzer.SUBMISSION_KEYWORDS:
            # 找到关键词位置
            idx = content_lower.find(keyword)
            if idx != -1:
                # 提取前后文（前后30个字符）
                start = max(0, idx - 30)
                end = min(len(content), idx + 60)
                context = content[start:end].replace('\n', ' ')
                requirements.append(context)
        
        if requirements:
            # 选择最具体的一条
            best_req = max(requirements, key=len)
            return best_req[:80]  # 限制长度
        
        return ''
    
    @staticmethod
    def _calculate_urgency(content: str) -> int:
        """计算紧急程度（1-5）"""
        urgency_score = 1
        content_lower = content.lower()
        
        for keyword, score in ContentAnalyzer.URGENCY_KEYWORDS.items():
            if keyword in content_lower:
                urgency_score = max(urgency_score, score)
        
        return urgency_score
    
    @staticmethod
    def _assess_complexity(content: str) -> str:
        """评估内容复杂度"""
        # 简单内容特征
        if len(content) < 200:
            return 'simple'
        
        # 检查是否为简单表格/名单
        lines = content.split('\n')
        if len(lines) < 5 and all(len(line) < 50 for line in lines):
            return 'simple'
        
        # 检查是否有实质内容
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', content))
        if chinese_chars < 100:
            return 'simple'
        
        return 'complex'
    
    @staticmethod
    def _generate_summary(content: str, file_name: str, deadlines: List[str], submission: str, complexity: str) -> str:
        """生成智能摘要（2-3句话）"""
        
        # 简单内容：一句话概括
        if complexity == 'simple':
            return ContentAnalyzer._simple_summary(content, file_name)
        
        # 复杂内容：2-3句话
        sentences = []
        
        # 第一句：文件类型和主题
        doc_type = ContentAnalyzer._identify_document_type(content, file_name)
        subject = ContentAnalyzer._extract_subject(content, file_name)
        sentences.append(f"{doc_type}：{subject}。")
        
        # 第二句：核心要求/内容
        core_requirement = ContentAnalyzer._extract_core_requirement(content)
        if core_requirement:
            sentences.append(core_requirement)
        
        # 第三句：时间要求
        if deadlines:
            deadline_str = '、'.join(deadlines[:2])
            if submission:
                sentences.append(f"请于{deadline_str}前{submission[:20]}。")
            else:
                sentences.append(f"完成时限：{deadline_str}。")
        
        summary = ''.join(sentences)
        return summary[:200] if len(summary) > 200 else summary
    
    @staticmethod
    def _simple_summary(content: str, file_name: str) -> str:
        """简单内容摘要"""
        # 提取文件类型
        ext = Path(file_name).suffix.lower()
        type_names = {
            '.xlsx': '表格', '.xls': '表格', '.csv': '表格',
            '.docx': '文档', '.doc': '文档',
            '.pdf': '文件', '.pptx': '演示文稿'
        }
        type_name = type_names.get(ext, '文件')
        
        # 检查内容特征
        if '值班' in file_name or '值班' in content:
            return f"值班安排表，包含人员排班信息。"
        if '名单' in file_name or '清单' in content:
            return f"人员名单/清单，列有相关对象信息。"
        if '报表' in file_name or '统计' in content:
            return f"数据统计表格，包含相关统计信息。"
        
        # 默认简单描述
        chinese_chars = len(re.findall(r'[\u4e00-\u9fff]', content))
        if chinese_chars < 50:
            return f"{type_name}内容较为简单，无详细说明信息。"
        
        # 提取前50个字符作为概要
        preview = content[:80].replace('\n', ' ').strip()
        return f"{type_name}：{preview}..." if len(preview) > 50 else f"{type_name}：{preview}"
    
    @staticmethod
    def _identify_document_type(content: str, file_name: str) -> str:
        """识别文档类型"""
        content_lower = content.lower()
        file_lower = file_name.lower()
        
        type_keywords = [
            ('通知', ['通知', '通告', '公告']),
            ('工作方案', ['方案', '工作计划']),
            ('工作总结', ['总结', '工作报告']),
            ('会议纪要', ['会议纪要', '会议记录', '座谈']),
            ('提示函', ['提示函', '工作提示']),
            ('通报', ['通报', '情况通报']),
            ('请示', ['请示', '申请']),
            ('批复', ['批复', '回复']),
        ]
        
        for doc_type, keywords in type_keywords:
            if any(kw in content_lower or kw in file_lower for kw in keywords):
                return doc_type
        
        return '文件'
    
    @staticmethod
    def _extract_subject(content: str, file_name: str) -> str:
        """提取主题"""
        # 尝试从文件名提取
        stem = Path(file_name).stem
        # 去除常见后缀
        for suffix in ['(1)', '(2)', '（1）', '（2）', '副本', '最终版']:
            stem = stem.replace(suffix, '')
        
        if len(stem) > 5 and not all(c in '0123456789abcdef' for c in stem.lower()[:8]):
            return stem.strip()
        
        # 从内容提取第一句话
        lines = [line.strip() for line in content.split('\n') if line.strip()]
        for line in lines[:3]:
            # 去除常见前缀
            line = re.sub(r'^(关于|有关|至于)', '', line)
            if len(line) > 10 and len(line) < 100:
                return line
        
        return '相关工作安排'
    
    @staticmethod
    def _extract_core_requirement(content: str) -> str:
        """提取核心要求"""
        content_lower = content.lower()
        
        # 查找要求类语句
        requirement_patterns = [
            r'(请|要求|务必|必须)[^。]*完成[^。]*。',
            r'(请|要求|务必|必须)[^。]*报送[^。]*。',
            r'(请|要求|务必|必须)[^。]*落实[^。]*。',
            r'(请|要求|务必|必须)[^。]*整改[^。]*。',
            r'现[将]?要求[^。]*。',
        ]
        
        for pattern in requirement_patterns:
            matches = re.findall(pattern, content_lower)
            if matches:
                # 还原原始内容
                match_str = matches[0]
                idx = content_lower.find(match_str)
                if idx != -1:
                    original = content[idx:idx+len(match_str)+50]
                    return original[:80] + '。'
        
        # 查找目的/目标
        if '为确保' in content or '为做好' in content:
            idx = content.find('为确保') if '为确保' in content else content.find('为做好')
            end_idx = content.find('，', idx)
            if end_idx == -1:
                end_idx = content.find('。', idx)
            if end_idx != -1:
                return content[idx:end_idx+1]
        
        return ''


# ============== 文件扫描器 ==============

class WeChatFileScanner:
    """扫描微信文件目录"""
    
    def __init__(self, source_dir: str):
        self.source_dir = Path(source_dir)
        self.cutoff_time = datetime.now() - timedelta(hours=24)
    
    def scan_recent_files(self) -> List[Dict]:
        """扫描最近24小时的文件"""
        files = []
        
        if not self.source_dir.exists():
            print(f"[错误] 源目录不存在: {self.source_dir}")
            return files
        
        print(f"\n📁 扫描目录: {self.source_dir}")
        print(f"⏰ 截止时间: {self.cutoff_time.strftime('%Y-%m-%d %H:%M:%S')}")
        
        for file_path in self.source_dir.rglob('*'):
            if not file_path.is_file():
                continue
            
            if file_path.suffix.lower() not in SUPPORTED_EXTENSIONS:
                continue
            
            try:
                mtime = datetime.fromtimestamp(file_path.stat().st_mtime)
                if mtime < self.cutoff_time:
                    continue
                
                file_info = FileInfoExtractor.get_file_info(file_path)
                files.append(file_info)
                print(f"  ✓ 找到: {file_path.name}")
                
            except Exception as e:
                print(f"  ✗ 错误读取 {file_path}: {e}")
        
        files.sort(key=lambda x: x['modified_time'], reverse=True)
        return files


# ============== 总结生成器 ==============

class SummaryGenerator:
    """生成文件总结"""
    
    @staticmethod
    def generate_summary_data(files: List[Dict]) -> List[Dict]:
        """为每个文件生成总结数据"""
        summary_list = []
        
        print(f"\n📋 分析文件内容...")
        
        for idx, file_info in enumerate(files, 1):
            print(f"  [{idx}/{len(files)}] {file_info['name']}")
            
            # 提取内容
            content = FileInfoExtractor.extract_content(Path(file_info['path']))
            file_info['content'] = content
            
            # 智能分析
            analysis = ContentAnalyzer.analyze_content(content, file_info['name'])
            
            summary_list.append({
                'index': idx,
                'original_name': file_info['name'],
                'original_path': file_info['path'],  # 保存原始路径用于超链接
                'smart_name': SummaryGenerator._generate_smart_name(file_info),
                'summary': analysis['summary'],
                'deadlines': analysis['deadlines'],
                'submission': analysis['submission_requirements'],
                'urgency': analysis['urgency_level'],
                'complexity': analysis['content_complexity'],
                'file_type': SummaryGenerator._get_file_type_name(file_info['extension']),
                'modified_time': file_info['modified_time'].strftime('%Y-%m-%d %H:%M'),
                'size': SummaryGenerator._format_size(file_info['size'])
            })
        
        return summary_list
    
    @staticmethod
    def _generate_smart_name(file_info: Dict) -> str:
        """生成智能名称"""
        stem = file_info['stem']
        
        # 清理常见后缀
        for suffix in ['(1)', '(2)', '(3)', '（1）', '（2）', '（3）', '副本', '最终版', '修改版']:
            stem = stem.replace(suffix, '')
        
        stem = stem.strip()
        
        if len(stem) > 3 and not all(c in '0123456789abcdef' for c in stem.lower()[:8]):
            return stem[:60]
        
        ext_map = {
            '.pdf': 'PDF文档',
            '.doc': 'Word文档',
            '.docx': 'Word文档',
            '.xls': 'Excel表格',
            '.xlsx': 'Excel表格',
            '.ppt': 'PPT演示',
            '.pptx': 'PPT演示',
            '.txt': '文本文件',
            '.csv': '数据表格',
            '.jpg': '图片',
            '.jpeg': '图片',
            '.png': '图片'
        }
        
        return ext_map.get(file_info['extension'], '文件')
    
    @staticmethod
    def _get_file_type_name(ext: str) -> str:
        """获取文件类型名称"""
        type_map = {
            '.pdf': 'PDF',
            '.doc': 'Word',
            '.docx': 'Word',
            '.xls': 'Excel',
            '.xlsx': 'Excel',
            '.ppt': 'PPT',
            '.pptx': 'PPT',
            '.txt': '文本',
            '.csv': 'CSV',
            '.jpg': '图片',
            '.jpeg': '图片',
            '.png': '图片',
            '.gif': '图片'
        }
        return type_map.get(ext, '其他')
    
    @staticmethod
    def _format_size(size_bytes: int) -> str:
        """格式化文件大小"""
        if size_bytes < 1024:
            return f"{size_bytes}B"
        elif size_bytes < 1024 * 1024:
            return f"{size_bytes/1024:.1f}KB"
        else:
            return f"{size_bytes/(1024*1024):.1f}MB"


# ============== Word报告生成器 ==============

class WordReportGenerator:
    """生成Word总结报告"""
    
    @staticmethod
    def add_hyperlink(paragraph, text, url):
        """在段落中添加超链接"""
        try:
            import docx.opc.constants
            import docx.oxml.shared
            from docx.oxml.shared import qn as oqn
        except ImportError:
            # 如果导入失败，直接返回普通文本
            run = paragraph.add_run(text)
            run.font.color.rgb = RGBColor(5, 99, 193)
            run.font.underline = True
            return None
        
        # 创建超链接关系
        part = paragraph.part
        r_id = part.relate_to(url, docx.opc.constants.RELATIONSHIP_TYPE.HYPERLINK, is_external=True)
        
        # 创建超链接元素
        hyperlink = docx.oxml.shared.OxmlElement('w:hyperlink')
        hyperlink.set(docx.oxml.shared.qn('r:id'), r_id)
        
        # 创建run元素
        new_run = docx.oxml.shared.OxmlElement('w:r')
        
        # 设置样式
        rPr = docx.oxml.shared.OxmlElement('w:rPr')
        
        # 添加颜色（蓝色）
        color = docx.oxml.shared.OxmlElement('w:color')
        color.set(oqn('w:val'), '0563C1')
        rPr.append(color)
        
        # 添加下划线
        u = docx.oxml.shared.OxmlElement('w:u')
        u.set(oqn('w:val'), 'single')
        rPr.append(u)
        
        new_run.append(rPr)
        
        # 添加文本
        t = docx.oxml.shared.OxmlElement('w:t')
        t.text = text
        new_run.append(t)
        
        hyperlink.append(new_run)
        paragraph._p.append(hyperlink)
        
        return hyperlink
    
    @staticmethod
    def generate_report(summary_list: List[Dict]) -> str:
        """生成Word文档并返回路径"""
        try:
            from docx import Document
            import docx.opc.constants
            import docx.oxml.shared
            from docx.shared import Pt, RGBColor, Inches
            from docx.enum.text import WD_ALIGN_PARAGRAPH
            from docx.oxml.ns import qn
        except ImportError:
            print("[错误] 未安装python-docx，请先运行: pip install python-docx")
            return ""
        
        doc = Document()
        
        # 设置中文字体
        doc.styles['Normal'].font.name = '微软雅黑'
        doc.styles['Normal']._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
        
        # 标题
        title = doc.add_heading('微信文件每日总结报告', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # 日期信息
        date_para = doc.add_paragraph()
        date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        date_run = date_para.add_run(f'统计时间: {datetime.now().strftime("%Y年%m月%d日 %H:%M")}（最近24小时）')
        date_run.font.size = Pt(10)
        date_run.font.color.rgb = RGBColor(128, 128, 128)
        
        doc.add_paragraph()
        
        # 统计信息
        stats_para = doc.add_paragraph()
        stats_run = stats_para.add_run(f'共发现 {len(summary_list)} 个文件')
        stats_run.font.size = Pt(12)
        stats_run.bold = True
        
        # 使用说明
        note_para = doc.add_paragraph()
        note_run = note_para.add_run('💡 提示：点击文件名可打开文件，按住Ctrl键同时点击')
        note_run.font.size = Pt(9)
        note_run.font.color.rgb = RGBColor(0, 128, 0)
        note_run.italic = True
        
        # 紧急文件标记
        urgent_files = [s for s in summary_list if s['urgency'] >= 4]
        if urgent_files:
            urgent_para = doc.add_paragraph()
            urgent_run = urgent_para.add_run(f'⚠️ 紧急文件: {len(urgent_files)} 个')
            urgent_run.font.size = Pt(11)
            urgent_run.font.color.rgb = RGBColor(255, 0, 0)
            urgent_run.bold = True
        
        doc.add_paragraph()
        
        # 文件详情
        for idx, item in enumerate(summary_list, 1):
            # 获取原始文件路径
            original_path = item.get('original_path', '')
            
            # 文件标题（带超链接）
            heading_para = doc.add_paragraph()
            heading_para.style = 'Heading 2'
            
            # 添加序号
            num_run = heading_para.add_run(f"{idx}. ")
            num_run.font.size = Pt(14)
            num_run.font.bold = True
            
            # 添加带超链接的文件名
            if original_path and os.path.exists(original_path):
                # 使用原始路径（不编码），Word在Windows上通常能处理
                # 将反斜杠转换为正斜杠以适应file协议
                file_url = original_path.replace('\\', '/')
                if not file_url.startswith('file://'):
                    file_url = 'file:///' + file_url
                WordReportGenerator.add_hyperlink(heading_para, item['smart_name'], file_url)
            else:
                # 如果没有路径或文件不存在，只显示名称
                name_run = heading_para.add_run(item['smart_name'])
                name_run.font.size = Pt(14)
                name_run.font.bold = True
            
            # 添加文件路径（可复制）
            path_para = doc.add_paragraph()
            path_label = path_para.add_run("📂 文件位置：")
            path_label.font.size = Pt(9)
            path_label.font.color.rgb = RGBColor(128, 128, 128)
            
            if original_path:
                path_text = path_para.add_run(original_path)
                path_text.font.size = Pt(9)
                path_text.font.color.rgb = RGBColor(128, 128, 128)
            
            # 添加快速操作提示
            tip_para = doc.add_paragraph()
            tip_text = tip_para.add_run("💡 提示：可复制上方路径直接打开，或尝试Ctrl+点击文件名")
            tip_text.font.size = Pt(8)
            tip_text.font.color.rgb = RGBColor(0, 128, 0)
            tip_text.italic = True
            
            # 基本信息
            info_para = doc.add_paragraph()
            info_para.add_run(f"类型: {item['file_type']} | ").font.size = Pt(10)
            info_para.add_run(f"时间: {item['modified_time']} | ").font.size = Pt(10)
            info_para.add_run(f"大小: {item['size']}").font.size = Pt(10)
            
            # 紧急标记
            if item['urgency'] >= 4:
                urgent_text = info_para.add_run(" 【紧急】")
                urgent_text.font.color.rgb = RGBColor(255, 0, 0)
                urgent_text.bold = True
                urgent_text.font.size = Pt(10)
            elif item['urgency'] >= 3:
                urgent_text = info_para.add_run(" 【加急】")
                urgent_text.font.color.rgb = RGBColor(255, 165, 0)
                urgent_text.font.size = Pt(10)
            elif item['urgency'] >= 3:
                urgent_text = info_para.add_run(" 【加急】")
                urgent_text.font.color.rgb = RGBColor(255, 165, 0)
                urgent_text.font.size = Pt(10)
            
            # 内容摘要
            summary_para = doc.add_paragraph()
            summary_title = summary_para.add_run("内容摘要：")
            summary_title.bold = True
            summary_title.font.size = Pt(10)
            summary_content = summary_para.add_run(item['summary'])
            summary_content.font.size = Pt(10)
            
            # 时限要求
            if item['deadlines']:
                deadline_para = doc.add_paragraph()
                deadline_title = deadline_para.add_run("⏰ 时限要求：")
                deadline_title.bold = True
                deadline_title.font.size = Pt(10)
                deadline_title.font.color.rgb = RGBColor(0, 102, 204)
                deadline_content = deadline_para.add_run('、'.join(item['deadlines']))
                deadline_content.font.size = Pt(10)
                deadline_content.font.color.rgb = RGBColor(0, 102, 204)
            
            # 报送要求
            if item['submission']:
                submit_para = doc.add_paragraph()
                submit_title = submit_para.add_run("📤 报送要求：")
                submit_title.bold = True
                submit_title.font.size = Pt(10)
                submit_content = submit_para.add_run(item['submission'])
                submit_content.font.size = Pt(10)
            
            # 分隔线
            doc.add_paragraph('_' * 50)
        
        # 备注
        doc.add_paragraph()
        note_para = doc.add_paragraph()
        note_run = note_para.add_run('注：本报告由AI自动生成，红色标记为紧急文件，蓝色标记为时限要求。')
        note_run.font.size = Pt(9)
        note_run.font.color.rgb = RGBColor(128, 128, 128)
        note_run.italic = True
        
        # 保存文件
        timestamp = datetime.now().strftime('%Y%m%d_%H%M')
        output_path = Path(OUTPUT_DIR) / f'微信文件总结报告_{timestamp}.docx'
        doc.save(str(output_path))
        
        # JSON generation disabled - user doesn't want JSON files
        # json_path = Path(OUTPUT_DIR) / f'微信文件总结报告_{timestamp}.json'
        # with open(json_path, 'w', encoding='utf-8') as f:
        #     json.dump(summary_list, f, ensure_ascii=False, indent=2)
        
        print(f"\n✅ 报告已生成: {output_path}")
        return str(output_path)


# ============== 主程序 ==============

def main():
    """主函数"""
    print("=" * 60)
    print("微信文件每日总结工具（增强版）")
    print("=" * 60)
    print(f"源目录: {SOURCE_DIR}")
    print(f"输出目录: {OUTPUT_DIR}")
    print("=" * 60)
    
    # 1. 扫描文件
    scanner = WeChatFileScanner(SOURCE_DIR)
    recent_files = scanner.scan_recent_files()
    
    if not recent_files:
        print("\nℹ️ 最近24小时内没有发现新文件。")
        return
    
    print(f"\n📊 共找到 {len(recent_files)} 个文件")
    
    # 2. 生成总结
    generator = SummaryGenerator()
    summary_list = generator.generate_summary_data(recent_files)
    
    # 3. 生成Word报告
    print("\n📝 生成Word报告...")
    report_path = WordReportGenerator.generate_report(summary_list)
    
    if report_path:
        print(f"\n✅ 完成！报告已保存到桌面:")
        print(f"   Word报告: {report_path}")
        
        # 显示紧急文件提醒
        urgent_count = len([s for s in summary_list if s['urgency'] >= 4])
        if urgent_count > 0:
            print(f"\n⚠️  提醒：发现 {urgent_count} 个紧急文件，请注意处理！")
        
        # 显示使用说明
        print("\n" + "="*60)
        print("📖 使用说明")
        print("="*60)
        print("1. 打开Word报告，查看文件摘要")
        print("2. 如Ctrl+点击无法打开文件，可复制文件路径手动打开")
        print("3. 或使用快速打开工具:")
        print(f"   python scripts\\open_file.py")
        print("="*60)
    else:
        print("\n❌ 报告生成失败")


if __name__ == "__main__":
    main()
