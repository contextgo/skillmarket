---
name: wechat-daily-summary
description: Scan WeChat cache directory for files modified in the last 24 hours, extract content from documents/spreadsheets/PDFs/images, generate intelligent summaries with detailed content analysis, key deadlines, submission requirements, and urgency indicators. Creates a comprehensive Word report on desktop with file path display and a helper tool to open files. Use when user needs detailed daily summaries of WeChat received files with content extraction and intelligent analysis.
---

# 微信文件每日总结（增强版 - 带文件路径和快速打开工具）

自动扫描微信缓存目录中最近24小时收到的文件，进行深度内容分析并生成详细总结报告。

## Key Features

### 1. Deep Content Analysis
   - Extract full text from PDFs, Word, Excel, PowerPoint
   - OCR for images
   - Content complexity assessment

### 2. Intelligent Summarization
   - 2-3 sentence summary for complex documents
   - 1 sentence for simple files
   - Document type identification (通知/方案/通报/提示函/etc.)

### 3. Key Information Extraction
   - **Deadlines**: 截止日期、完成时限、报送时间
   - **Submission requirements**: 报送方式、联系人、邮箱
   - **Urgency levels**: 特急/加急/紧急标记
   - **Core requirements**: 主要工作要求

### 4. File Path Display ⭐
   - Each file shows its full path (copyable)
   - Helper script to open files by number
   - JSON data file for programmatic access

### 5. Report Format
   - Each file has detailed section
   - Color-coded urgency indicators (red for urgent)
   - Highlighted deadline requirements (blue)
   - File path displayed for easy access

## Usage

### Generate Report
```bash
python scripts/wechat_summary.py
```

### Quick Open Files (if Ctrl+Click doesn't work)
```bash
python scripts/open_file.py
```

Then enter file number to open it.

## Output Files

1. **Word Report**: `微信文件总结报告_YYYYMMDD_HHMM.docx`
   - Human-readable summary with all details
   - File paths displayed for each file

2. **JSON Data**: `微信文件总结报告_YYYYMMDD_HHMM.json`
   - Structured data for the helper tool
   - Contains all file paths and metadata

## How to Open Files

Since Word hyperlinks to local files may be blocked by security settings:

### Method 1: Copy Path (Always Works)
1. Open Word report
2. Find the file path displayed under each file
3. Copy the path
4. Paste in File Explorer address bar or Run dialog (Win+R)

### Method 2: Quick Open Tool (Recommended)
```bash
python scripts\open_file.py
```
- Shows numbered list of all files
- Enter number to open specific file
- Shows urgent files marked in red

### Method 3: Try Ctrl+Click (May Work)
- In Word, hold Ctrl and click the blue filename
- May be blocked by Word security settings

## Report Example

```
1. 严格落实节假日重大危险源提级管控工作
   📂 文件位置：D:\wechat_cache\xwechat_files\...\严格落实节假日重大危险源提级管控工作.docx
   💡 提示：可复制上方路径直接打开，或尝试Ctrl+点击文件名
   
   类型: Word | 时间: 2026-02-14 15:30 | 大小: 156KB
   
   内容摘要：
   工作方案：关于节假日重大危险源提级管控。要求各单位高度重视，
   切实加强安全管理，落实各项防范措施。请于2月15日前完成相关工作。
   
   ⏰ 时限要求：2月15日
```

## Configuration

Edit `scripts/wechat_summary.py`:
- `SOURCE_DIR`: WeChat cache path
- `OUTPUT_DIR`: Report output location

## Dependencies

- Python 3.8+
- python-docx
- PyMuPDF
- python-docx/docx2txt
- pandas/openpyxl
- python-pptx
- pytesseract/Pillow

## Scheduled Execution

Recommended: Daily at 7:00 AM via OpenClaw cron
