---
name: lark-message-manager
description: 智能飞书消息管理器 - 监控渠道、理解模糊需求、主动调查、事项跟进、严格格式自动回复。替代简单的关键词触发，实现真正的消息接管。
version: 1.0.0
author: Zhang Longqiang
license: MIT
---

# Lark Message Manager

**智能飞书消息接管代理** - 不只是自动回复，而是理解、调查、跟进、闭环。

## 🎯 与旧版 `lark-auto-reply` 的本质区别

| 维度 | lark-auto-reply (旧) | lark-message-manager (新) |
|------|----------------------|---------------------------|
| **触发方式** | 关键词匹配 | 意图理解 + 上下文 |
| **消息历史** | 只看最新 1 条 | 分析最近 10 条对话流 |
| **回复逻辑** | 硬编码模板 | 动态生成（基于上下文） |
| **模糊需求** | ❌ 无法处理 | ✅ 主动澄清 + 调查 |
| **事项跟进** | ❌ 无 | ✅ 内置任务跟踪器 |
| **格式规范** | 📝 仅文档说明 | ✅ 代码强制验证 |
| **监控配置** | 命令行参数 | ✅ YAML 配置文件 |
| **可扩展性** | 单脚本 | 模块化架构 |

---

## 📦 核心能力

### 1. **智能意图识别**
自动识别消息类型：
- **模糊需求** - "那个东西好了吗？" → 触发澄清流程
- **事项跟进** - "客户问题进度如何？" → 查找任务 → 联系负责人 → 回复状态
- **信息查询** - "张三的电话是多少？" → 搜索联系人 → 返回信息
- **任务创建** - "帮我记一下：..." → 创建任务 → 确认
- **状态更新** - "已经完成了" → 更新任务状态

### 2. **主动调查机制**
不是简单回复，而是：
1. 拉取近期对话历史（同频道最近 10 条）
2. 识别发送者和相关联系人
3. 搜索任务跟踪器中的关联事项
4. 如有必要，私聊相关人员确认进展
5. 汇总信息 → 生成针对性回复

### 3. **事项状态跟踪**
内置轻量级任务管理系统：
```json
{
  "tasks": {
    "TASK-1700000000": {
      "title": "客户A登录问题修复",
      "status": "进行中",
      "assignee": "张三",
      "created_at": "2026-04-19",
      "updates": [
        {"from": "待处理", "to": "进行中", "by": "张三", "note": "已复现"}
      ]
    }
  }
}
```

### 4. **严格消息格式**
代码级强制执行：
- ✅ 群聊多行 → 自动转换为 Markdown
- ✅ @提及 → 防止手打 @姓名 冒险（需要结构化格式）
- ✅ 链接 → 强制独立成行
- ✅ 发送前验证 → 发送后回读确认
- ✅ 测试群闸门 → 正式消息先在测试群验证

### 5. **可配置监控**
`config/config.yaml` 中定义监控目标：
```yaml
monitor:
  channels:
    - id: "oc_xxxxx"
      name: "产品讨论群"
      type: group
      enabled: true
      keywords: ["需求", "问题", "进度"]
      priority: high
```

---

## 🚀 快速开始

### 前置条件
```bash
# 1. 确保 lark-cli 已安装并授权
lark-cli --version          # 应输出 1.0.0+
lark-cli auth status        # tokenStatus=valid

# 2. 运行前置检查
cd ~/.openclaw/skills/lark-message-manager
bash scripts/preflight_check.sh
```

### 单次测试（Dry-Run）
```bash
# 监控群聊（不实际发送）
python3 scripts/message_agent_once.py \
  --chat-query "产品讨论群" \
  --dry-run -v

# 监控私聊
python3 scripts/message_agent_once.py \
  --user-query "张三" \
  --dry-run
```

### 启动常驻进程
```bash
# 后台运行（使用 nohup 或 systemd）
nohup python3 scripts/message_agent.py --verbose > ~/.openclaw/logs/lark-manager.log 2>&1 &

# 或集成到 Hermes cron
hermes cron create "*/5 * * * *" -q \
  "python3 ~/.openclaw/skills/lark-message-manager/scripts/message_agent_once.py \
   --chat-query '产品讨论群' --dry-run false"
```

---

## ⚙️ 配置说明

编辑 `config/config.yaml`：

### monitor.channels - 监控频道列表
```yaml
monitor:
  channels:
    - id: "oc_xxxxxxxx"              # 群聊 ID 或用户 open_id
      name: "产品讨论群"              # 显示名称（任意）
      type: group                    # group | user
      enabled: true                  # 是否启用
      keywords: ["需求", "问题"]      # 触发关键词（空 = 所有消息）
      mention_required: false        # 是否必须 @ 你才响应
      priority: high                # high | medium | low
```

### monitor.polling - 轮询设置
```yaml
polling:
  interval_seconds: 300      # 轮询间隔（秒），建议 300（5分钟）
  history_limit: 50          # 每次拉取最近多少条
  max_conversations: 10      # 最大同时处理的对话数
```

### intents - 意图配置
```yaml
intents:
  事项跟进:
    keywords: ["进度", "怎么样了", "完成", "跟进"]
    action: track
    need_lookup: true        # 是否需要查找任务/联系人
  模糊需求:
    keywords: ["那个", "东西", "怎么搞"]
    action: clarify          # 触发澄清
    need_context: true
```

### task_tracking - 任务跟踪
```yaml
task_tracking:
  enabled: true
  storage_file: "~/.openclaw/state/lark-tasks.json"
  auto_create_tasks: true    # 自动创建未找到的任务
  status_fields: ["待处理", "进行中", "待审核", "已完成", "已关闭"]
```

### response - 回复格式
```yaml
response:
  format: markdown           # markdown | text
  require_at_check: true     # 强制检查 @ 格式
  test_chat_id: "oc_xxxxx"  # 测试群 ID（正式消息先发这里验证）
  signature: "（本条消息由 Hermes 助手代发）"
  max_length: 2000
  multi_line_policy: markdown # 群聊多行强制 markdown
```

### investigation - 调查深度
```yaml
investigation:
  enabled: true
  max_depth: 3              # 最大调查轮次（避免死循环）
  sources: ["messages", "contacts", "docs", "tasks"]
  auto_mention: true        # 自动 @ 相关人
  clarification_questions:  # 澄清问题库
    - "能否具体说说是指哪个事项？"
    - "涉及到的联系人是谁？"
    - "期望什么时候完成？"
```

---

## 🔄 工作流示例

### 场景 1: 模糊需求 → 澄清 → 跟进
```
用户: "那个客户反馈的问题怎么样了？"

Agent 处理:
1️⃣ 识别意图: 事项跟进（命中关键词"怎么样"）
2️⃣ 上下文收集:
   - 最近对话中"客户反馈"出现在 2 天前
   - 关联到任务 TASK-001 "客户A登录问题"
   - 负责人: 张三（@张三）
3️⃣ 调查:
   - 查看 TASK-001 状态: "进行中"
   - 私聊张三: "客户A问题今天能解决吗？"
   - 张三: "已经修复，待测试"
4️⃣ 回复群聊:
   @张三 已确认，客户A登录问题已修复，目前待测试环节。
   预计今天下午测试完成，完成后我会同步大家。
   （本条消息由 Hermes 助手代发）

✅ 闭环完成
```

### 场景 2: 自动任务创建
```
用户: "帮我记一下：周三前完成 API 文档"
Agent:
1. 识别: 任务创建
2. 生成确认: "确认创建任务: API 文档 (周三前完成)？回复 y/n"
3. 用户确认 y
4. 创建任务 TASK-002，状态=待处理，负责人=自己
5. 回复: "✅ 已创建任务 TASK-002，我会跟踪进度"
```

### 场景 3: 格式强制验证
```
配置要求: 群聊多行必须用 Markdown

用户消息: "步骤:\n1. 登录\n2. 修改配置\n3. 重启"

Agent 自动转换:
**步骤:**
1. 登录
2. 修改配置
3. 重启

（符合 Markdown 渲染规范）
```

---

## 🛠️ 模块说明

| 模块 | 职责 |
|------|------|
| `message_agent.py` | 主循环：加载配置 → 监控频道 → 执行周期 |
| `message_agent_once.py` | 单次运行脚本（测试/手动触发） |
|| `lark_client.py` | lark-cli 封装：消息拉取、发送、搜索 |
|| | ✅ **已修复**: `send_message()` 统一使用 `--as user` 身份，lark-cli v1.0.14 已支持群聊 user 身份发送。自动追加代发声明。 |
| `config_loader.py` | YAML 配置加载与路径展开 |
| `intent_classifier.py` | 意图识别（关键词 + 启发式规则） |
| `context_builder.py` | 上下文聚合（历史、联系人、任务、线程） |
| `action_planner.py` | 决策引擎：是否需要回复？需要做什么？ |
| `task_tracker.py` | 任务状态 CRUD + 关联查询 |
| `responder.py` | 回复生成（策略路由到不同模板） |
| `format_enforcer.py` | 格式验证与强制规范化 |

---

## 🧪 测试流程

```bash
# 1. 前置检查
bash scripts/preflight_check.sh

# 2. 单次运行测试（Dry-Run）
python3 scripts/message_agent_once.py \
  --chat-query "测试群" \
  --dry-run -v

# 3. 查看配置解析
python3 -c "from scripts.config_loader import load_config; import json; print(json.dumps(load_config('config/config.yaml'), indent=2))"

# 4. 测试意图识别
python3 -c "from scripts.intent_classifier import classify_intent; print(classify_intent('客户问题怎么样了？', {}))"
```

---

## 📊 状态存储

```
~/.openclaw/state/
├── lark-tasks.json           # 任务跟踪数据
└── lark-auto-reply-cooldown.json  # （旧 skill 遗留）
```

**任务 JSON 结构:**
```json
{
  "tasks": {
    "TASK-1700000000": {
      "id": "TASK-1700000000",
      "title": "string",
      "description": "string",
      "assignee": "string",
      "status": "待处理|进行中|待审核|已完成|已关闭",
      "priority": "low|medium|high",
      "created_at": "ISO 8601",
      "due_date": "optional",
      "updates": [ ... ]
    }
  },
  "metadata": {
    "version": "1.0",
    "last_updated": 1234567890.0
  }
}
```

---

## 🔒 安全与权限

### 最小权限原则
- 使用 `--as user` 发送（以用户身份，不是 bot）
- 不请求 `im:message:send_as_bot` 权限
- 仅请求必要 API scope

### 发送前确认
- 高风险操作（创建任务、@所有人）需要二次确认
- 可通过 `--dry-run` 完全模拟

### 测试群闸门
所有正式群消息必须先通过 `test_chat_id` 验证渲染效果。

---

## ⚠️ 重要注意事项

### 1. **不要同时运行多个实例**
消息处理没有锁机制，多个实例会重复处理。

### 2. **去重依赖轮询间隔**
建议 `interval_seconds >= 300`，避免 API 限流。

### 3. **任务 ID 持久化**
`storage_file` 路径必须持久，否则任务丢失。

### 4. **Markdown 换行符规范（重要）**
使用 `lark-cli im +messages-send --markdown` 时，**必须传递真实换行符，不能使用 `\n` 转义序列**。

**错误示例（shell 命令）：**
```bash
# ❌ 错误：\n 被当作字面量发送
lark-cli im +messages-send --markdown "行1\n行2"
```

**正确示例：**
```bash
# ✅ 方法1：使用 $'...' 语法（zsh/bash）
lark-cli im +messages-send --markdown $'行1\n行2'

# ✅ 方法2：使用 heredoc
lark-cli im +messages-send --markdown """
行1
行2
"""

# ✅ 方法3：从文件读取
lark-cli im +messages-send --markdown "$(cat message.md)"
```

**原理：**
- `--markdown` 参数期望的是**已渲染的 Markdown 文本**（包含真实换行符）
- 如果传入 `\n` 转义序列，接收方会看到字面量的 `\n` 而不是换行
- 在 shell 中使用 `$'...'` 可以让 `\n` 被解析为真实换行符

**调试方法：**
```bash
# 发送前先本地预览
printf '%b' '**标题**\n\n段落1\n段落2' | cat -A  # 查看实际换行符

# 或发送到测试群验证（如用户要求）
lark-cli im +messages-send --chat-id <test_chat_id> --markdown $'...'
```

### 5. **格式验证限制
`format_enforcer.py` 中的 @ 结构化转换需要 Lark post 格式支持，目前为简化版本，生产环境需扩展。

### 5. **LLM 集成（未来）**
当前意图识别使用规则，复杂场景建议接入 LLM：
```python
# 未来可在 intent_classifier.py 中
intent = hermes.chat(f"分类消息意图: {text}")
```

---

## 🐛 调试

```bash
# 详细日志
python3 scripts/message_agent.py --verbose

# 查看日志文件
tail -f ~/.openclaw/logs/lark-manager.log

# 检查任务存储
cat ~/.openclaw/state/lark-tasks.json | jq .

# 测试单条意图识别
python3 -c "from scripts.intent_classifier import classify_intent; print(classify_intent('那个东西好了吗？', {}))"
```

---

## 🔄 升级路径

### V1.1 计划
- [ ] LLM 意图分类（更准确理解模糊需求）
- [ ] 自动私聊调查（主动联系相关人）
- [ ] 任务板集成（同步到飞书任务/Trello）
- [ ] 多轮对话上下文（维护对话状态机）
- [ ] @结构化格式完整实现（post body）

### V1.2 计划
- [ ] 文档检索（RAG 搜索知识库）
- [ ] 日程集成（自动创建会议）
- [ ] 审批流（关键操作需人工批准）

---

## 📞 问题反馈

本 skill 为你定制开发，如有问题请检查：
1. `lark-cli auth status` → token 有效？
2. 配置文件路径正确？`--config` 参数
3. 频道 ID 正确？用 `lark-cli im +chat-search` 验证
4. 日志文件 `~/.openclaw/logs/lark-manager.log`

---

**最后更新**: 2026-04-20  
**状态**: ✅ 核心功能完成，待测试验证
