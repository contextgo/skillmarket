# memory-hygiene

**类型**: skill

Audit, clean, and optimize Clawdbot's vector memory (LanceDB). Use when memory is bloated with junk, token usage is high from irrelevant auto-recalls, or setting up memory maintenance automation.

## 快速开始

当用户提到 memory-hygiene 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
