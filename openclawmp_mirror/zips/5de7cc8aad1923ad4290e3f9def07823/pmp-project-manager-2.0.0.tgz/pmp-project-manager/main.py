#!/usr/bin/env python3
"""
PMP项目管理助手 (AI增强版 v2.0)
基于PMBOK知识体系，集成AI智能辅助的项目管理工具
"""

import typer
from rich.console import Console
from pathlib import Path
import json
import re
from datetime import datetime, timedelta
from typing import Optional, Dict, List
from jinja2 import Environment, FileSystemLoader

app = typer.Typer(help="PMP项目管理助手 (AI增强版) - 支持智能初始化、AI生成WBS、风险识别、工时估算等")
console = Console()

# ============================================
# 工具函数
# ============================================

def parse_date(date_str: str) -> datetime:
    """解析日期字符串"""
    for fmt in ["%Y-%m-%d", "%Y/%m/%d", "%Y年%m月%d日"]:
        try:
            return datetime.strptime(date_str, fmt)
        except ValueError:
            continue
    raise typer.BadParameter(f"无法解析日期: {date_str}")

def calculate_duration(start: datetime, end: datetime) -> int:
    """计算工作日数（简单实现）"""
    delta = end - start
    return max(1, delta.days)

def generate_risk_id(index: int) -> str:
    """生成风险ID"""
    return f"R{index:03d}"

def save_markdown(content: str, output: Path):
    """保存Markdown文件"""
    output.write_text(content, encoding="utf-8")
    console.print(f"[green]✅ 文件已生成: {output}[/green]")

def extract_natural_info(brief: str) -> Dict:
    """从自然语言描述中提取项目基本信息（AI模拟）"""
    # TODO: 实际可调用 LLM API 进行智能提取
    # 这里使用规则引擎作为 MVP
    
    info = {
        "project_name": None,
        "client": None,
        "budget": None,
        "duration_days": None,
        "project_type": "software",  # 默认
        "complexity": "medium"
    }
    
    # 提取预算
    budget_match = re.search(r"(\d+\.?\d*)\s*(万|元|k|K|W)", brief)
    if budget_match:
        amount = float(budget_match.group(1))
        unit = budget_match.group(2)
        if unit in ["万", "W"]:
            amount *= 10000
        info["budget"] = f"{amount:,.0f}元"
    
    # 提取时间
    duration_match = re.search(r"(\d+)\s*(天|周|月|year|years)", brief, re.IGNORECASE)
    if duration_match:
        duration = int(duration_match.group(1))
        unit = duration_match.group(2)
        if unit in ["周", "week"]:
            duration *= 7
        elif unit in ["月", "month"]:
            duration *= 30
        elif unit in ["年", "year", "years"]:
            duration *= 365
        info["duration_days"] = duration
    
    # 提取客户/组织（使用公司后缀精确匹配）
    client_match = re.search(r"(?:为|给|客户是)\s*([^\s，,。.]+?(?:公司|科技|集团|机构|组织|工作室|团队))", brief)
    if client_match:
        info["client"] = client_match.group(1)
    
    # 提取项目名称（如"AI营销平台"、"官网改版"等）
    project_keywords = r"(AI|人工智能|营销|官网|小程序|APP|系统|平台|部署|开发|设计|建设)"
    name_match = re.search(project_keywords + r"([^\s，,。.]+)", brief)
    if name_match:
        info["project_name"] = name_match.group(0)
    
    # ✨ v2.0 新增：智能推断 project_type 和 complexity
    text = brief.lower()
    if any(kw in text for kw in ["ai", "人工智能", "机器学习", "深度学习", "智能"]):
        info["project_type"] = "ai"
    elif any(kw in text for kw in ["营销", "推广", "广告", "品牌"]):
        info["project_type"] = "marketing"
    elif any(kw in text for kw in ["官网", "网站", "小程序", "app"]):
        info["project_type"] = "website"
    else:
        info["project_type"] = "software"
    
    # 推断复杂度（基于预算和周期）
    budget_num = None
    if info["budget"]:
        try:
            budget_num = float(re.sub(r"[^\d.]", "", info["budget"]))
        except:
            budget_num = None
    
    if budget_num and budget_num >= 1000000:
        info["complexity"] = "high"
    elif info["duration_days"] and info["duration_days"] <= 30:
        info["complexity"] = "high"
    elif budget_num and budget_num <= 300000:
        info["complexity"] = "low"
    elif info["duration_days"] and info["duration_days"] >= 180:
        info["complexity"] = "low"
    else:
        info["complexity"] = "medium"
    
    return info

# ============================================
# AI增强辅助函数（v2.0 新增）
# ============================================

def infer_project_type(project_name: str, description: str = "") -> str:
    """推断项目类型（ai, marketing, website, software）"""
    text = f"{project_name} {description}".lower()
    if any(kw in text for kw in ["ai", "人工智能", "机器学习", "深度学习", "智能"]):
        return "ai"
    elif any(kw in text for kw in ["营销", "推广", "广告", "品牌"]):
        return "marketing"
    elif any(kw in text for kw in ["官网", "网站", "小程序", "app"]):
        return "website"
    else:
        return "software"

def infer_deliverables(project_type: str) -> List[str]:
    """根据项目类型推断典型交付物"""
    deliverables_map = {
        "ai": [
            "AI模型训练与验证",
            "数据管道与预处理脚本",
            "API接口文档",
            "性能测试报告",
            "模型监控方案",
            "部署与运维手册"
        ],
        "marketing": [
            "市场策略报告",
            "创意素材包",
            "投放计划",
            "效果监测方案",
            "优化建议报告"
        ],
        "website": [
            "网站原型设计",
            "UI/UX设计稿",
            "前端代码",
            "后端API",
            "测试报告",
            "上线文档"
        ],
        "software": [
            "需求规格说明书",
            "系统设计文档",
            "API文档",
            "测试用例与报告",
            "用户手册",
            "部署指南"
        ]
    }
    return deliverables_map.get(project_type, deliverables_map["software"])

def infer_complexity(budget: Optional[str], duration_days: Optional[int]) -> str:
    """推断项目复杂度（基于预算和周期）"""
    # 提取预算数字（去掉单位）
    budget_num = None
    if budget:
        try:
            budget_num = float(re.sub(r"[^\d.]", "", budget))
        except:
            budget_num = None
    
    # 判断
    if budget_num and budget_num >= 1000000:
        return "high"
    if duration_days and duration_days <= 30:
        return "high"
    if budget_num and budget_num <= 300000:
        return "low"
    if duration_days and duration_days >= 180:
        return "low"
    return "medium"

def generate_schedule_from_wbs(project_name: str, deliverables: List[str], start_date: datetime, duration: int) -> str:
    """从WBS交付物生成简单进度计划"""
    total_days = duration
    phase_days = max(1, total_days // len(deliverables))
    
    lines = [
        f"# 进度计划 - {project_name}",
        f"**生成日期**: {datetime.now().strftime('%Y-%m-%d')}",
        "",
        "## 📅 时间轴",
        f"- **启动日期**: {start_date.strftime('%Y-%m-%d')}",
        f"- **计划完成**: {(start_date + timedelta(days=duration)).strftime('%Y-%m-%d')}",
        f"- **总工期**: {duration} 天",
        "",
        "## 📋 里程碑计划",
        "| 里程碑 | 预计完成日期 | 交付物 |",
        "|--------|--------------|--------|"
    ]
    
    current = start_date
    for i, deliverable in enumerate(deliverables, 1):
        end = current + timedelta(days=phase_days)
        lines.append(f"| M{i}: {deliverable} | {end.strftime('%Y-%m-%d')} | {deliverable} |")
        current = end
    
    lines.extend([
        "",
        "## 📊 进度计划表",
        "| 任务ID | 任务名称 | 开始日期 | 结束日期 | 工期(天) | 前置任务 |",
        "|--------|----------|----------|----------|----------|----------|"
    ])
    
    task_id = 1
    current = start_date
    for deliverable in deliverables:
        end = current + timedelta(days=phase_days)
        lines.append(f"| T{task_id} | {deliverable} | {current.strftime('%Y-%m-%d')} | {end.strftime('%Y-%m-%d')} | {phase_days} | T{task_id-1 if task_id>1 else '无'} |")
        task_id += 1
        current = end
    
    lines.extend(["", "---", "**注意**: 此为AI根据WBS自动生成的初步计划，需根据实际情况调整。"])
    return "\n".join(lines)

def ai_generate_charter(project_name: str, brief: str, client: str, manager: str, sponsor: str, start_date: datetime, end_date: datetime, duration: int, budget: Optional[str]) -> str:
    """AI生成项目章程（使用模板）"""
    design_completion = start_date + timedelta(days=int(duration * 0.2))
    dev_completion = start_date + timedelta(days=int(duration * 0.6))
    
    env = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"))
    template = env.get_template("project_charter.md.jinja2")
    
    content = template.render(
        project_name=project_name,
        name=project_name,
        description=brief,
        client=client,
        manager=manager,
        sponsor=sponsor,
        start_date=start_date.strftime("%Y-%m-%d"),
        end_date=end_date.strftime("%Y-%m-%d"),
        duration=duration,
        budget=budget,
        design_completion=design_completion.strftime("%Y-%m-%d"),
        dev_completion=dev_completion.strftime("%Y-%m-%d"),
        generated_date=datetime.now().strftime("%Y-%m-%d %H:%M")
    )
    return content

def ai_generate_stakeholders(project_name: str, client: str, manager: str) -> str:
    """AI生成干系人登记册（使用模板）"""
    env = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"))
    template = env.get_template("stakeholder_register.md.jinja2")
    
    content = template.render(
        project_name=project_name,
        client_name=client,
        manager=manager,
        generated_date=datetime.now().strftime("%Y-%m-%d %H:%M")
    )
    return content

def ai_generate_wbs(project_name: str, deliverables: List[str], description: str = "") -> str:
    """AI生成WBS（使用模板）"""
    env = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"))
    template = env.get_template("wbs.md.jinja2")
    
    wbs_structure = []
    for i, deliverable in enumerate(deliverables, 1):
        subtasks = [
            f"{deliverable}需求分析",
            f"{deliverable}设计",
            f"{deliverable}开发/实施",
            f"{deliverable}测试",
            f"{deliverable}交付"
        ]
        wbs_structure.append({
            "id": i,
            "name": deliverable,
            "subtasks": subtasks
        })
    
    content = template.render(
        project_name=project_name,
        wbs_structure=wbs_structure,
        format="tree",
        generated_date=datetime.now().strftime("%Y-%m-%d %H:%M")
    )
    return content

def ai_generate_risks(project_name: str, project_type: str, complexity: str) -> str:
    """AI生成风险登记册（使用模板和风险库）"""
    env = Environment(loader=FileSystemLoader(Path(__file__).parent / "templates"))
    template = env.get_template("risk_register.md.jinja2")
    
    risks = [
        {"id": "R001", "description": "需求变更频繁", "probability": "中", "impact": "中", "level": "中", "strategy": "转移", "response": "通过合同明确变更流程，客户签字确认"},
        {"id": "R002", "description": "关键人员离职", "probability": "低", "impact": "高", "level": "中", "strategy": "减轻", "response": "建立知识共享机制，培养后备人员"},
        {"id": "R003", "description": "技术实现难度超出预期", "probability": "中", "impact": "中", "level": "中", "strategy": "减轻", "response": "前期技术预研，预留缓冲时间"},
        {"id": "R004", "description": "第三方依赖延迟", "probability": "低", "impact": "中", "level": "低", "strategy": "转移", "response": "选择成熟供应商，合同约束交付时间"},
        {"id": "R005", "description": "测试发现重大缺陷", "probability": "中", "impact": "中", "level": "中", "strategy": "减轻", "response": "加强代码审查，分阶段测试"},
    ]
    
    if project_type == "ai":
        extra_risks = [
            {"id": "R007", "description": "训练数据质量不达标", "probability": "中", "impact": "高", "level": "高", "strategy": "减轻", "response": "提前进行数据清洗和标注，设定质量门槛"},
            {"id": "R008", "description": "算法偏差导致效果不佳", "probability": "中", "impact": "高", "level": "高", "strategy": "减轻", "response": "使用多样化数据训练，建立偏差检测机制"},
            {"id": "R009", "description": "模型推理性能不足", "probability": "中", "impact": "中", "level": "中", "strategy": "减轻", "response": "优化模型结构，使用高性能推理引擎"},
            {"id": "R010", "description": "合规与隐私风险", "probability": "低", "impact": "高", "level": "中", "strategy": "规避", "response": "数据脱敏，遵守GDPR等法规"},
            {"id": "R011", "description": "模型可解释性不足", "probability": "中", "impact": "低", "level": "低", "strategy": "接受", "response": "记录为已知问题，后续迭代改进"},
        ]
        risks.extend(extra_risks)
    elif project_type == "marketing":
        extra_risks = [
            {"id": "R020", "description": "市场变化导致策略失效", "probability": "中", "impact": "中", "level": "中", "strategy": "减轻", "response": "保持每周市场监测，策略季度评审"},
            {"id": "R021", "description": "渠道投放效果低于预期", "probability": "中", "impact": "中", "level": "中", "strategy": "转移", "response": "多渠道投放分散风险，设置止损点"},
            {"id": "R022", "description": "内容合规风险", "probability": "低", "impact": "高", "level": "中", "strategy": "规避", "response": "内容预审机制，遵守广告法"},
        ]
        risks.extend(extra_risks)
    elif project_type == "website":
        extra_risks = [
            {"id": "R030", "description": "浏览器兼容性问题", "probability": "中", "impact": "低", "level": "低", "strategy": "减轻", "response": "主流浏览器全覆盖测试"},
            {"id": "R031", "description": "SEO 效果不达预期", "probability": "中", "impact": "中", "level": "中", "strategy": "转移", "response": "SEO优化服务外包，持续监控排名"},
        ]
        risks.extend(extra_risks)
    
    if complexity == "high":
        for r in risks:
            if r["level"] == "中":
                r["level"] = "高"
                r["probability"] = "高" if r["probability"] == "中" else r["probability"]
    elif complexity == "low":
        for r in risks:
            if r["level"] == "高":
                r["level"] = "中"
    
    content = template.render(
        project=project_name,
        risks=risks,
        generated_date=datetime.now().strftime("%Y-%m-%d %H:%M")
    )
    return content

# ============================================
# ✨ AI增强功能 - 智能初始化
# ============================================

@app.command()
def smart_init(
    brief: str = typer.Option(..., "--brief", "-b", help="项目简要自然语言描述，如：'为某某科技做AI营销平台，3个月，50万预算'"),
    output_dir: Path = typer.Option(Path("."), "--output-dir", "-o", help="输出目录"),
    auto: bool = typer.Option(False, "--auto", help="自动模式，不交互提示，使用AI提取的默认值")
):
    """
    🚀 智能初始化 - AI解析Brief并生成全套项目启动文档
    
    示例:
        pmp smart-init --brief "为某某科技公司部署AI营销自动化平台，预算50万，周期3个月，项目经理张三" -o ./my_project
    """
    console.print("[bold blue]🤖 正在AI智能解析项目Brief...[/bold blue]")
    console.print(f"[dim]Brief: {brief}[/dim]\n")
    
    # 1. 提取基本信息
    info = extract_natural_info(brief)
    
    # 补充 project_type 和 complexity 推断（v2.0 新增）
    if not info.get("project_type"):
        info["project_type"] = infer_project_type(project_name if 'project_name' in locals() else None, brief)
    if not info.get("complexity"):
        info["complexity"] = infer_complexity(info.get("budget"), info.get("duration_days"))
    
    # 补充缺失的必需信息（交互式询问 or 使用AI建议）
    if not auto:
        console.print("[yellow]📋 请补充以下项目信息（直接回车使用AI建议）：[/yellow]")
        project_name = typer.prompt(f"项目名称", default=info["project_name"] or "AI智能项目")
        client = typer.prompt(f"客户/发起组织", default=info["client"] or "[待填写]")
        manager = typer.prompt(f"项目经理", default="[待指定]")
        sponsor = typer.prompt(f"项目发起人", default="[待指定]")
    else:
        # 自动模式：使用AI提取的值或默认
        project_name = info["project_name"] or "AI智能项目"
        client = info["client"] or "待补充"
        manager = "张三" if "张三" in brief else "[待指定]"
        sponsor = client  # 默认发起人为客户
    
    # 时间估算
    if info["duration_days"]:
        default_duration = info["duration_days"]
    else:
        default_duration = 90  # 默认3个月
    
    if not auto:
        console.print(f"[dim]建议项目周期: {default_duration} 天[/dim]")
        confirm_duration = typer.confirm(f"使用该周期？", default=True)
        duration = default_duration if confirm_duration else int(typer.prompt("请输入项目天数"))
    else:
        duration = default_duration
        confirm_duration = True
    
    budget = info["budget"] if auto else (info["budget"] or typer.prompt("项目预算（可选）", default=""))
    
    # 计算日期
    start_date = datetime.now()
    end_date = start_date + timedelta(days=duration)
    
    # 2. AI生成项目章程
    console.print("\n[bold green]✨ AI正在生成项目章程...[/bold green]")
    charter_content = ai_generate_charter(project_name, brief, client, manager, sponsor, start_date, end_date, duration, budget)
    charter_path = output_dir / "project_charter.md"
    save_markdown(charter_content, charter_path)
    
    # 3. AI生成干系人分析
    console.print("[bold green]✨ AI正在识别干系人...[/bold green]")
    stakeholder_content = ai_generate_stakeholders(project_name, client, manager)
    stakeholder_path = output_dir / "stakeholder_register.md"
    save_markdown(stakeholder_content, stakeholder_path)
    
    # 4. AI生成WBS（基于项目类型）
    console.print("[bold green]✨ AI正在拆解WBS...[/bold green]")
    deliverables = infer_deliverables(info["project_type"])
    wbs_content = ai_generate_wbs(project_name, deliverables)
    wbs_path = output_dir / "wbs.md"
    save_markdown(wbs_content, wbs_path)
    
    # 5. AI生成初步风险
    console.print("[bold green]✨ AI正在识别风险...[/bold green]")
    risk_content = ai_generate_risks(project_name, info["project_type"], info["complexity"])
    risk_path = output_dir / "risk_register.md"
    save_markdown(risk_content, risk_path)
    
    # 6. 生成进度计划
    console.print("[bold green]📅 正在生成进度计划...[/bold green]")
    schedule_content = generate_schedule_from_wbs(project_name, deliverables, start_date, duration)
    schedule_path = output_dir / "schedule.md"
    save_markdown(schedule_content, schedule_path)
    
    # 7. 生成项目包摘要
    console.print("\n[bold magenta]🎉 项目初始化完成！[/bold magenta]")
    console.print(f"""
📁 输出文件已保存至: {output_dir.absolute()}
   ├── project_charter.md     (项目章程)
   ├── stakeholder_register.md (干系人登记册)
   ├── wbs.md                 (工作分解结构)
   ├── risk_register.md       (风险登记册)
   └── schedule.md            (进度计划)

📌 下一步建议：
   1. 检查并修改生成的文档
   2. 根据实际情况调整 WBS 和工期
   3. 运行 `pmp plan-schedule` 生成详细甘特图
   4. 运行 `pmp export-pptx` 生成PPT计划书
   5. 运行 `pmp export-gantt` 生成交互式甘特图
    """)

# ============================================
# ✨ AI增强功能 - 智能WBS生成
# ============================================

@app.command()
def ai_wbs(
    project_name: str = typer.Option(..., "--project-name", "-p", help="项目名称"),
    description: str = typer.Option("", "--description", "-d", help="项目描述，用于AI理解"),
    output: Path = typer.Option(Path("wbs_ai.md"), "--output", "-o", help="输出文件")
):
    """
    🧠 AI生成WBS - 根据项目描述自动生成工作分解结构
    
    示例:
        pmp ai-wbs --project-name "AI营销平台" --description "SaaS产品，包含用户管理、内容推荐、数据分析" -o wbs.md
    """
    console.print("[bold blue]🧠 AI正在分析项目并生成WBS...[/bold blue]")
    
    # 推断项目类型
    project_type = infer_project_type(project_name, description)
    console.print(f"[dim] detected project type: {project_type}[/dim]")
    
    # 根据类型生成标准WBS
    deliverables = infer_deliverables(project_type)
    
    # AI生成详细子任务
    wbs_content = ai_generate_wbs(project_name, deliverables, description)
    save_markdown(wbs_content, output)

# ============================================
# ✨ AI增强功能 - 智能风险识别
# ============================================

@app.command()
def ai_risk(
    project_name: str = typer.Option(..., "--project", "-p", help="项目名称"),
    project_type: str = typer.Option("software", "--type", "-t", help="项目类型: software, marketing, infrastructure, etc."),
    complexity: str = typer.Option("medium", "--complexity", "-c", help="复杂度: low, medium, high"),
    output: Path = typer.Option(Path("risk_register_ai.md"), "--output", "-o", help="输出文件")
):
    """
    ⚠️ AI风险识别 - 智能识别项目典型风险和应对策略
    
    示例:
        pmp ai-risk --project "AI平台" --type software --complexity high -o risks.md
    """
    console.print("[bold red]🤖 AI正在分析项目风险...[/bold red]")
    
    risk_content = ai_generate_risks(project_name, project_type, complexity)
    save_markdown(risk_content, output)

# ============================================
# ✨ AI增强功能 - 智能工时估算
# ============================================

@app.command()
def estimate(
    brief: str = typer.Option(..., "--brief", "-b", help="项目简要描述"),
    output: Path = typer.Option(Path("estimate.md"), "--output", "-o", help="输出文件")
):
    """
    📊 智能估算 - 基于历史数据和项目类型估算工时和资源
    
    示例:
        pmp estimate --brief "AI营销平台，3个月，50万" -o estimate.md
    """
    console.print("[bold cyan]🤖 AI正在估算项目资源需求...[/bold cyan]")
    
    info = extract_natural_info(brief)
    
    # 查询三层记忆中的类似项目（TODO: 实际集成）
    # 现在使用预设数据
    historical_data = {
        "software": {"avg_days": 90, "avg_team": 5, "avg_budget": 300000},
        "marketing": {"avg_days": 60, "avg_team": 3, "avg_budget": 150000},
        "website": {"avg_days": 30, "avg_team": 2, "avg_budget": 50000}
    }
    
    project_type = info["project_type"]
    if project_type not in historical_data:
        project_type = "software"
    
    baseline = historical_data[project_type]
    
    # 调整估算（基于预算/工期输入）
    if info["duration_days"]:
        duration = info["duration_days"]
        adjustment = duration / baseline["avg_days"]
    elif info["budget"]:
        # 预算反推工期（假设人天成本 2000元）
        budget_num = float(re.sub(r"[^\d.]", "", info["budget"]))
        duration = int(budget_num / 2000 / baseline["avg_team"])
        adjustment = duration / baseline["avg_days"]
    else:
        duration = baseline["avg_days"]
        adjustment = 1.0
    
    # 生成估算报告
    lines = [
        f"# 项目资源估算报告",
        f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M')}",
        f"**工具**: pmp-project-manager v2.0 (AI估算引擎)",
        "",
        "## 📊 基础数据（来自历史项目）",
        f"- **项目类型**: {project_type}",
        f"- **基准工期**: {baseline['avg_days']} 天",
        f"- **基准团队**: {baseline['avg_team']} 人",
        f"- **基准预算**: ¥{baseline['avg_budget']:,}",
        "",
        "## 🔮 AI 智能调整",
        f"- **调整系数**: {adjustment:.2f}",
        f"- **预估工期**: {duration} 天",
        f"- **预估团队规模**: {max(1, int(baseline['avg_team'] * adjustment))} 人",
        f"- **预估预算**: ¥{int(baseline['avg_budget'] * adjustment):,}",
        "",
        "## 📋 建议资源分配",
        f"- **项目经理**: 1 人",
        f"- **技术人员**: {max(1, int(baseline['avg_team'] * 0.6))} 人",
        f"- **设计/产品**: {max(1, int(baseline['avg_team'] * 0.4))} 人",
        f"- **外部资源/供应商**: 按需",
        "",
        "## ⚠️ 风险调整",
        "- 复杂度中等，建议增加 15% 缓冲时间",
        "- 首次合作客户，沟通成本上浮 10%",
        "- 技术债务和集成风险预留 20% 时间",
        "",
        "## 📈 推荐进度框架",
        f"- **需求分析**: 第 1-{max(5, int(duration*0.1))} 天",
        f"- **设计阶段**: 第 {max(5, int(duration*0.1)+1)}-{max(10, int(duration*0.2))} 天",
        f"- **开发实施**: 第 {max(10, int(duration*0.2)+1)}-{int(duration*0.7)} 天",
        f"- **测试验收**: 第 {int(duration*0.7)+1}-{duration} 天",
        "",
        "---",
        "**注意**: 此估算基于简化的AI模型，实际项目请根据具体需求调整。",
    ]
    
    content = "\n".join(lines)
    save_markdown(content, output)

# ============================================
# ✨ AI增强功能 - 导出PPT
# ============================================

@app.command()
def export_pptx(
    plan_dir: Path = typer.Option(Path("."), "--plan-dir", "-p", help="项目文档目录，包含 wbs.md, schedule.md, risk_register.md"),
    output: Path = typer.Option(Path("project_plan.pptx"), "--output", "-o", help="输出PPT文件")
):
    """
    📤 导出PPT - 将项目计划导出为PowerPoint格式
    
    需要: NanoBanana-PPT-Skills 已安装
    """
    console.print("[bold magenta]📤 正在导出PPT项目计划书...[/bold magenta]")
    
    try:
        # TODO: 调用 NanoBanana-PPT-Skills 技能
        # 现在先模拟
        console.print("[yellow]⚠️  PPT导出功能需集成 NanoBanana-PPT-Skills[/yellow]")
        console.print("[dim]请确保已安装: openclawmp install skill/@u-756d94f416863f3b/NanoBanana-PPT-Skills[/dim]")
        
        # 模拟生成
        content = f"""# PPT导出功能

**状态**: 待集成 NanoBanana-PPT-Skills

**计划**: 自动读取以下文件并生成PPT:
- {plan_dir / "wbs.md"}
- {plan_dir / "schedule.md"}
- {plan_dir / "risk_register.md"}
- {plan_dir / "project_charter.md"}

**输出**: {output.absolute()}

请先安装对应技能后重试。
"""
        save_markdown(content, output.with_suffix(".md"))
    except Exception as e:
        console.print(f"[red]❌ 导出失败: {e}[/red]")

# ============================================
# ✨ AI增强功能 - 导出甘特图
# ============================================

@app.command()
def export_gantt(
    schedule_file: Path = typer.Option(Path("schedule.md"), "--schedule", "-s", help="进度计划文件"),
    output: Path = typer.Option(Path("gantt_chart.html"), "--output", "-o", help="输出HTML文件")
):
    """
    📤 导出甘特图 - 生成交互式HTML甘特图
    
    使用 Chart.js 生成可视化甘特图
    """
    console.print("[bold cyan]📊 正在生成交互式甘特图...[/bold cyan]")
    
    if not schedule_file.exists():
        console.print(f"[red]❌ 文件不存在: {schedule_file}[/red]")
        raise typer.Exit(1)
    
    # 解析 schedule.md 中的任务表格
    tasks = parse_schedule_tasks(schedule_file)
    
    # 生成 Chart.js HTML
    html = generate_chartjs_gantt(tasks)
    output.write_text(html, encoding="utf-8")
    console.print(f"[green]✅ 甘特图已生成: {output}[/green]")
    console.print(f"[dim]请在浏览器中打开查看交互效果[/dim]")

def parse_schedule_tasks(schedule_file: Path) -> List[Dict]:
    """解析 schedule.md 中的任务表格"""
    tasks = []
    content = schedule_file.read_text(encoding="utf-8")
    
    # 查找表格行 | taskID | name | start | end | duration | predecessors |
    table_started = False
    for line in content.split("\n"):
        if line.strip().startswith("|") and "任务ID" in line:
            table_started = True
            continue
        if table_started and line.strip().startswith("|"):
            cells = [c.strip() for c in line.split("|")[1:-1]]
            if len(cells) >= 5:
                tasks.append({
                    "id": cells[0],
                    "name": cells[1],
                    "start": cells[2],
                    "end": cells[3],
                    "duration": int(cells[4]),
                    "predecessors": cells[5] if len(cells) > 5 else ""
                })
        if table_started and line.strip() and not line.strip().startswith("|"):
            break
    
    return tasks

def generate_chartjs_gantt(tasks: List[Dict]) -> str:
    """使用 Chart.js 生成甘特图 HTML"""
    
    # 构建 datasets
    datasets = []
    colors = ["#FF6384", "#36A2EB", "#FFCE56", "#4BC0C0", "#9966FF", "#FF9F40"]
    
    for i, task in enumerate(tasks):
        start = datetime.strptime(task["start"], "%Y-%m-%d")
        end = datetime.strptime(task["end"], "%Y-%m-%d")
        
        # Chart.js 需要时间戳（毫秒）
        start_ms = int(start.timestamp() * 1000)
        end_ms = int(end.timestamp() * 1000)
        
        datasets.append({
            "label": f"{task['id']}. {task['name']}",
            "backgroundColor": colors[i % len(colors)],
            "borderColor": colors[i % len(colors)],
            "data": [{
                "x": start_ms,
                "y": i,
                "x2": end_ms
            }]
        })
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>项目甘特图</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {{ font-family: Arial, sans-serif; margin: 20px; }}
        #gantt {{ max-width: 1200px; max-height: 600px; }}
        .container {{ margin-top: 20px; }}
    </style>
</head>
<body>
    <h1>📊 项目甘特图</h1>
    <div class="container">
        <canvas id="gantt"></canvas>
    </div>
    <script>
        const ctx = document.getElementById('gantt').getContext('2d');
        const data = {{
            datasets: {json.dumps(datasets, ensure_ascii=False)}
        }};
        
        new Chart(ctx, {{
            type: 'bar',
            data: data,
            options: {{
                indexAxis: 'y',
                responsive: true,
                plugins: {{
                    legend: {{ display: false }},
                    tooltip: {{
                        callbacks: {{
                            label: function(context) {{
                                const start = new Date(context.parsed.x);
                                const end = new Date(context.parsed.x2);
                                return context.dataset.label + 
                                       '\\n开始: ' + start.toLocaleDateString() + 
                                       '\\n结束: ' + end.toLocaleDateString() +
                                       '\\n历时: ' + Math.round((context.parsed.x2 - context.parsed.x) / (1000*60*60*24)) + '天';
                            }}
                        }}
                    }}
                }},
                scales: {{
                    x: {{
                        type: 'time',
                        time: {{ unit: 'day', tooltipFormat: 'yyyy-MM-dd' }},
                        title: {{ display: true, text: '日期' }}
                    }},
                    y: {{
                        title: {{ display: true, text: '任务' }},
                        ticks: {{ callback: function(value, index) {{ return tasks[index].name; }} }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>
"""
    return html

# ============================================
# ===== 保持原有的7个命令不变（init-project, identify-stakeholders, 等）=====
# ============================================
# ... 原有代码保持不变（从原 main.py 复制过来，只保留不修改）
# 为节省空间，这里假设你已经有了完整的原始版本
# ============================================

# 这里需要加入原始的8个命令（init_project, identify_stakeholders, create_wbs, plan_schedule, plan_risk, generate_status_report, close_project, lessons_learned）
# 保持原样不变

# 简化：这里仅展示新添加的AI功能框架
# 实际部署时需要将原始命令完整保留

if __name__ == "__main__":
    app()
