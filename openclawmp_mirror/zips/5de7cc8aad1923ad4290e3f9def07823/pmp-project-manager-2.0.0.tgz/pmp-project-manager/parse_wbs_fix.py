def parse_wbs_tasks(wbs_content: str) -> list:
    """解析WBS内容，提取任务列表"""
    tasks = []
    for line in wbs_content.split("\n"):
        line = line.strip()
        # 只处理 ### 开头的任务标题（create-wbs 生成）
        if line.startswith("### ") and "." in line:
            header = line[4:].strip()  # 去掉 "### "
            if "." in header:
                parts = header.split(".", 1)
                task_id = parts[0].strip()
                task_name = parts[1].strip()
                tasks.append({"id": task_id, "name": task_name})
    return tasks