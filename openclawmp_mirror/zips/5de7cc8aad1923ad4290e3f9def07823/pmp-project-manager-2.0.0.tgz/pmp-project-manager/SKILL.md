---
name: pmp-project-manager
displayName: PMP项目管理助手
description: 基于PMBOK知识体系的专业项目管理工具，支持项目启动、规划、执行、监控、收尾全流程文档生成和项目管理自动化
version: 1.0.0
type: skill
tags: project-management, pmp, pmbok, saas, enterprise, documentation
---

# PMP项目管理助手

基于PMBOK第6/7版知识体系，为SaaS和企业级项目提供的全流程项目管理自动化工具。

## 核心功能

### 🚀 项目启动阶段
- `init-project` - 初始化项目，生成项目章程和相关方登记册
- `identify-stakeholders` - 识别和分析相关方

### 📋 项目规划阶段
- `create-wbs` - 创建工作分解结构（WBS）
- `plan-schedule` - 制定项目进度计划（甘特图/时间线）
- `plan-communication` - 制定沟通管理计划
- `plan-risk` - 识别风险并制定应对策略
- `create-project-plan` - 整合生成完整项目管理计划

### 📊 项目执行与监控
- `track-progress` - 跟踪项目进度并生成状态报告
- `manage-changes` - 处理变更请求（变更控制）
- `generate-status-report` - 生成周期性状态报告

### 🎯 项目收尾
- `close-project` - 项目收尾，生成总结报告和经验教训
- `lessons-learned` - 记录经验教训登记册

## 快速开始

### 安装
```bash
cd pmp-project-manager
pip install -r requirements.txt
```

### 初始化新项目
```bash
# 交互式创建项目基础信息
pmp init-project --name "SaaS产品上线项目" --description "为客户部署AI营销自动化平台" --client "某某科技公司" --manager "张三" --output ./project_charter.md

# 识别相关方
pmp identify-stakeholders --input ./project_charter.md --output ./stakeholders.md
```

### 创建工作分解结构
```bash
pmp create-wbs \
  --project-name "AI营销平台部署" \
  --deliverables "系统部署,数据迁移,用户培训,试运行" \
  --format tree \
  --output ./wbs.md
```

### 生成项目进度计划
```bash
pmp plan-schedule \
  --wbs ./wbs.md \
  --estimates '{"系统部署": 10, "数据迁移": 5, "用户培训": 3, "试运行": 7}' \
  --dependencies '{"用户培训":["系统部署"], "试运行":["数据迁移","用户培训"]}' \
  --start-date 2026-03-15 \
  --output ./schedule.md
```

### 风险管理
```bash
pmp plan-risk \
  --project "AI平台部署" \
  --risks '数据迁移失败,用户配合度低,需求范围蔓延,关键人员离职' \
  --output ./risk_register.md
```

### 生成状态报告
```bash
pmp generate-status-report \
  --project "AI平台部署" \
  --period "2026-03-08至2026-03-14" \
  --progress "系统部署完成80%,数据迁移完成50%,用户培训待开始" \
  --issues "数据迁移工具兼容性问题需要解决" \
  --next-steps "完成数据迁移,启动用户培训" \
  --output ./status_report_0314.md
```

## 模板库

所有模板位于 `templates/` 目录，支持自定义：

- `project_charter.md` - 项目章程（含项目目的、目标、主要可交付成果、关键里程碑）
- `stakeholder_register.md` - 相关方登记册（姓名、职位、影响程度、沟通需求）
- `wbs_template.md` - 工作分解结构模板（层级化任务清单）
- `risk_register.md` - 风险登记册（风险描述、概率、影响、应对策略）
- `status_report.md` - 项目状态报告模板（进度、问题、下一步）
- `lessons_learned.md` - 经验教训总结
- `communication_plan.md` - 沟通管理计划

## 技术栈

- **核心引擎**：Python 3.9+，Typer（CLI），Jinja2（模板渲染）
- **文档生成**：Markdown（支持HTML/PDF导出）
- **项目管理**：遵循PMBOK第6版/第7版标准
- **适用场景**：SaaS项目交付、企业数字化转型、产品研发、市场活动

## 输出示例

### 项目章程关键章节
```markdown
# 项目章程

## 项目基本信息
- 项目名称：AI营销平台部署
- 项目发起人：某某科技公司CEO
- 项目经理：张三
- 项目周期：2026-03-15 至 2026-05-30

## 项目目标
在本阶段，完成AI营销自动化平台在客户公司的部署上线，
实现营销数据对接、自动化营销、效果分析等核心功能。

## 关键里程碑
- 2026-03-20：需求确认完成
- 2026-04-10：系统部署完成
- 2026-04-25：数据迁移完成
- 2026-05-10：用户培训完成
- 2026-05-30：项目正式上线
```

### 风险登记册
| 风险ID | 风险描述 | 概率 | 影响 | 等级 | 应对策略 |
|--------|----------|------|------|------|----------|
| R001 | 数据迁移失败或数据丢失 | 中 | 高 | 高 | 制定详细迁移方案，执行前完整备份 |
| R002 | 用户配合度低，需求变更频繁 | 高 | 中 | 高 | 建立变更控制流程，明确范围边界 |

## 自定义扩展

所有模板文件位于 `templates/`，可根据公司品牌风格修改：
- 添加公司Logo和配色
- 调整章节结构和内容
- 添加附加字段（如预算、资源分配矩阵）

## 技术支持

如需定制或扩展功能，请阅读源码或联系作者。