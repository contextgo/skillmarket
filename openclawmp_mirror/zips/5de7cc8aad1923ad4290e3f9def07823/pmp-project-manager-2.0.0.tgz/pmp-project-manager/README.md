# PMP项目管理助手 (AI增强版 v2.0)

🎉 **新升级：AI智能驱动，一键生成完整项目计划！** 🎉

基于PMBOK知识体系的**AI智能项目管理工具**，支持项目全生命周期文档生成和管理。

## ✨ AI增强功能（v2.0 新特性）

### 🚀 智能初始化 `smart-init`
用自然语言描述项目，AI 自动提取并生成项目章程草案：
```bash
python3 main.py smart-init --brief "为某某科技公司部署AI营销平台，预算50万，周期3个月，项目经理张三"
```

### 🧠 AI生成WBS `ai-wbs`
根据项目描述自动生成工作分解结构，无需手动输入所有任务：
```bash
python3 main.py ai-wbs --project-name "AI营销平台部署" --description "SaaS产品交付项目"
```

### ⚠️ AI风险识别 `ai-risk`
智能识别项目类型相关的典型风险，生成风险登记册：
```bash
python3 main.py ai-risk --project-type "software" --complexity high
```

### 📊 智能估算 `estimate`
基于历史数据（三层记忆）和项目类型，智能估算工日和资源需求：
```bash
python3 main.py estimate --brief "..."  # 返回工时范围和建议进度
```

### 📤 可视化导出
- `export-pptx` - 一键生成 PPT 项目计划（需 NanoBanana-PPT-Skills）
- `export-gantt` - 生成交互式 HTML 甘特图

---

## 安装

```bash
cd pmp-project-manager
pip install -r requirements.txt
```

## 快速使用

### 1️⃣ 项目启动
```bash
# 生成项目章程
python3 main.py init-project \
  --name "AI营销平台部署" \
  --description "为客户部署AI营销自动化平台" \
  --client "某某科技公司" \
  --manager "张三" \
  --sponsor "李总" \
  --start-date 2026-03-15 \
  --end-date 2026-05-30 \
  --output project_charter.md

# 识别相关方
python3 main.py identify-stakeholders \
  --input project_charter.md \
  --output stakeholder_register.md
```

### 2️⃣ 项目规划
```bash
# 创建工作分解结构（WBS）
python3 main.py create-wbs \
  --project-name "AI营销平台部署" \
  --deliverables "系统部署,数据迁移,用户培训,试运行" \
  --format tree \
  --output wbs.md

# 制定进度计划
python3 main.py plan-schedule \
  --wbs wbs.md \
  --estimates '{"系统部署": 10, "数据迁移": 5, "用户培训": 3, "试运行": 7}' \
  --dependencies '{"用户培训":["系统部署"], "试运行":["数据迁移","用户培训"]}' \
  --start-date 2026-03-15 \
  --output schedule.md

# 风险管理计划
python3 main.py plan-risk \
  --project "AI营销平台部署" \
  --risks '数据迁移失败,用户配合度低,需求范围蔓延,关键人员离职' \
  --output risk_register.md
```

### 3️⃣ 项目监控
```bash
# 生成状态报告
python3 main.py generate-status-report \
  --project "AI营销平台部署" \
  --period "2026-03-08至2026-03-14" \
  --progress "系统部署完成80%,数据迁移完成50%,用户培训待开始" \
  --issues "数据迁移工具兼容性问题需要解决" \
  --next-steps "完成数据迁移,启动用户培训" \
  --output status_report.md
```

### 4️⃣ 项目收尾
```bash
# 项目总结
python3 main.py close-project \
  --project "AI营销平台部署" \
  --actual-start 2026-03-15 \
  --actual-end 2026-05-28 \
  --outcomes "成功上线AI营销平台，实现自动化营销" \
  --output closeout_report.md

# 经验教训
python3 main.py lessons-learned \
  --project "AI营销平台部署" \
  --successes "需求分析充分,团队协作高效" \
  --failures "数据迁移工具选型失误" \
  --improvements "加强工具测试,提前备份方案" \
  --output lessons_learned.md
```

## 输出文件说明

| 文件 | 对应 PMBOK | 用途 |
|------|------------|------|
| `project_charter.md` | 项目章程 | 正式批准项目，授权项目经理 |
| `stakeholder_register.md` | 相关方登记册 | 记录所有相关方信息和沟通需求 |
| `wbs.md` | 范围管理计划 | 工作分解结构，定义项目范围 |
| `schedule.md` | 进度管理计划 | 详细时间表和里程碑 |
| `risk_register.md` | 风险管理计划 | 风险识别、分析、应对 |
| `communication_plan.md` | 沟通管理计划 | 沟通策略和频率 |
| `status_report.md` | 监控过程 | 定期状态汇报 |
| `closeout_report.md` | 收尾过程 | 项目总结和交付物确认 |
| `lessons_learned.md` | 组织过程资产 | 经验教训归档 |

## 模板自定义

所有模板位于 `templates/` 目录，可根据公司风格修改：
- `project_charter.md.jinja2`
- `stakeholder_register.md.jinja2`
- `wbs.md.jinja2`
- `risk_register.md.jinja2`
- `status_report.md.jinja2`
- `closeout_report.md.jinja2`
- `lessons_learned.md.jinja2`

## 技术栈

- **Python 3.9+**
- **Typer** - CLI框架
- **Jinja2** - 模板引擎
- **Rich** - 终端美化

## 遵循标准

本工具严格遵循 **PMBOK第6版** 知识体系，覆盖：
- 五大过程组（启动、规划、执行、监控、收尾）
- 十大知识领域（整合、范围、进度、成本、质量、资源、沟通、风险、采购、相关方）

## License

MIT