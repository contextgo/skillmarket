# Agent 每日汇报规范

适用于任何多 agent 系统的通用汇报规范。

## 核心原则

### 1. 只汇报自己的工作

每个 agent 只汇报自己实际执行的工作，不要把其他 agent 的工作写进自己的汇报。

### 2. 不汇报"汇报本身"

以下内容不属于工作成果，不应写入汇报：
- "完成了每日汇报"
- "生成了汇报文件"
- "发送了消息"
- "运行了汇报任务"

汇报是流程，不是工作。

### 3. 简洁有数据

- 每项工作一行简述
- 有量化数据优先呈现
- 突出关键成果，避免流水账

## 工作内容来源

汇报前，从以下来源收集工作内容：

### 1. Session 对话记录

使用 sessions_list 获取过去 24 小时活跃 session：

```
sessions_list(activeMinutes=1440)
```

筛选规则：
- 只选择属于该 agent 自己的 session
- 排除 subagent session（session key 包含 `:subagent:` 或 `:run:`）
- 用 sessions_history 拉取对话记录（每个 session limit=50）

### 2. Memory 当日记忆

读取自己工作目录下的 memory 文件：
- 路径：`{workspace}/memory/YYYY-MM-DD.md`
- 内容：当日记录的工作、决策、问题等

### 3. 合并整理

将 session 记录和 memory 内容合并，去除重复，整理为汇报内容。

## 汇报日志路径

### 路径规则

1. 优先读取 TOOLS.md 中"每日工作汇报"字眼定义的路径
2. 如果没有定义，默认路径：`{workspace}/daily/`
3. 文件命名：`{agentid}-report-YYYY-MM-DD.md`

### 示例

Agent ID 为 `main`，日期 2026-03-27：
- 有 TOOLS.md 定义：使用定义路径
- 无定义：`~/workspace-main/daily/main-report-2026-03-27.md`

## Cron 设置

### 创建 Cron 任务

使用 `openclaw cron add` 命令创建定时汇报任务：

```bash
openclaw cron add --name "{agent名称} - 每日工作汇报" \
  --schedule "0 23 * * *" \
  --agent "{agentid}" \
  --payload '{"prompt": "按照 agent-daily-report skill 规范生成今日工作汇报"}'
```

### 参数说明

| 参数 | 说明 |
|------|------|
| `--name` | 任务名称，建议格式：`{agent名称} - 每日工作汇报` |
| `--schedule` | cron 表达式，如 `0 23 * * *` 表示每天 23:00 |
| `--agent` | 执行任务的 agent ID |
| `--payload` | JSON 格式的任务内容，prompt 字段指定汇报指令 |
| `--disabled` | 添加时禁用任务，后续手动启用 |

### 启用/禁用任务

```bash
# 启用任务
openclaw cron enable "{任务名称}"

# 禁用任务
openclaw cron disable "{任务名称}"
```

### 配置推送（可选）

如需将汇报推送到消息渠道，在 payload 中添加 delivery 配置：

```json
{
  "prompt": "按照 agent-daily-report skill 规范生成今日工作汇报",
  "delivery": {
    "to": "",
    "channel": ""
  }
}
```

填写说明：
- `to` — 目标地址，需包含完整前缀（如 `qqbot:c2c:xxx`、`telegram:c2c:xxx`）
- `channel` — 渠道类型（如 `qqbot`、`telegram`、`discord`）

## 汇报模板

见 assets/template.md。