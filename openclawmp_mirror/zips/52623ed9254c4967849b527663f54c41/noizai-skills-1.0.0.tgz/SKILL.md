---
name: noizai-voice-kit
description: NoizAI语音技能合集：TTS文本转语音、角色对话、情绪语音控制、视频翻译、新闻播客生成
license: MIT
---

# NoizAI Voice Kit

NoizAI 语音技能合集，提供生产级语音合成能力。

## 包含技能

| 技能 | 功能 |
|------|------|
| tts | 文本转语音，支持 Kokoro/Noiz 后端 |
| chat-with-anyone | 用任意角色声音对话 |
| characteristic-voice | 情绪语气控制 |
| video-translation | 视频语音翻译+配音 |
| daily-news-caster | 双人新闻播客生成 |
| template-skill | 技能开发模板 |

## 安装

```bash
npx openclawmp install skill/@noizai/noizai-voice-kit
```

## 使用

详见各技能的 SKILL.md 文件。
