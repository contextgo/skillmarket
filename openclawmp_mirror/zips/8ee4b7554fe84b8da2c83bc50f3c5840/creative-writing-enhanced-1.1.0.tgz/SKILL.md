---
name: creative-writing
description: "长篇创作辅助 Skill。借鉴 webnovel-writer 架构，提供 RAG 记忆、六维审查、追读力系统、项目管理、自动导演、卷战略工作台。适用于：写小说、剧本、长文、连载内容。触发词：写小说、创作故事、连载、creative-writing、/write-novel、网文、小说创作。"
license: MIT
---

# Creative Writing Skill (Enhanced)

长篇创作辅助系统，解决 AI 写作中的"遗忘"和"幻觉"问题。

## 🎯 核心能力

| 能力 | 说明 | 状态 |
|------|------|------|
| **RAG 记忆** | 基于文件系统的长篇记忆（无需 mem9） | ✅ 增强 |
| **六维审查** | 爽点/一致性/节奏/OOC/连贯/追读力 | ✅ 已有 |
| **追读力系统** | 钩子管理、债务追踪、期待回收 | ✅ 已有 |
| **防幻觉** | 大纲即法律、设定即物理、发明需识别 | ✅ 已有 |
| **项目管理** | 多本小说 CRUD、状态跟踪 | ✨ 新增 |
| **自动导演 v0.1** | 灵感 → 世界观 → 角色 → 大纲 → 前3章 | ✨ 新增 |
| **卷战略工作台** | 推荐卷数 + 节奏板 + 章节列表 | ✨ 新增 |
| **伏笔追踪** | 结构化伏笔记录与回收管理 | ✨ 新增 |

---

## 📁 项目结构

```
~/.openclaw/workspace/creative-writing-projects/
├── projects.json              # 项目索引
├── <project-id>/
│   ├── project.json           # 项目元数据
│   ├── world.md               # 世界观设定
│   ├── characters/            # 角色卡片（JSON/MD）
│   │   ├── protagonist.md
│   │   ├── antagonist.md
│   │   └── supporting.md
│   ├── outline.md             # 章节大纲
│   ├── volumes/               # 卷规划
│   │   └── volume-1/
│   │       ├── plan.md        # 卷战略 + 节奏板
│   │       ├── pacing-board.json
│   │       ├── chapters.json  # 章节列表
│   │       └── chapters/      # 章节正文
│   │           └── 1.md
│   ├── debts.json             # 追读力债务
│   └── state.json             # 项目状态
```

---

## 🎬 工作流

### 1. 初始化项目
```
用户：初始化小说项目《无限流之末世杀神》，题材是末世+系统+杀伐果断
→ Skill：调用 creative-writing-project.js create
→ 创建项目目录和基础文件
```

### 2. 自动导演 v0.1
```
用户：生成《无限流之末世杀神》的世界观、角色和大纲，灵感：穿越+杀神系统+末世丧尸
→ Skill：调用 creative-writing-director.js direct <projectId> "<灵感>"
→ 自动生成：
  - world.md（世界规则、势力、特殊要素）
  - characters/（3-5个核心角色卡片）
  - outline.md（前3章大纲）
  - volumes/volume-1/plan.md（第一卷节奏板）
```

### 3. 卷战略规划
```
用户：规划《无限流之末世杀神》的卷数和章节
→ Skill：调用 creative-writing-volume.js plan <projectId> --words=240000 --chapters=25
→ 生成：
  - volumes/volume-1/plan.md
  - volumes/volume-1/pacing-board.json
  - volumes/volume-1/chapters.json
```

### 4. 章节写作
```
用户：写第一卷第1章，林云觉醒杀神系统
→ Skill：读取 world.md、角色卡片、大纲、节奏板
→ 生成章节正文，遵守 Strand Weave 比例
→ 自动检查六维审查
→ 记录伏笔到 debts.json
```

### 5. 六维审查
```
用户：审查第1章
→ Skill：调用 creative-writing-checker.py
→ 输出：爽点评分、一致性检查、节奏分析、OOC检测、连贯性、追读力
→ 如有问题，自动生成修复建议
```

### 6. 伏笔回收
```
用户：查询伏笔债务
→ Skill：读取 debts.json，列出所有未回收伏笔
→ 写作时自动建议回收机会
```

---

## 🔧 新增脚本说明

| 脚本 | 功能 | 调用方式 |
|------|------|---------|
| `creative-writing-project.js` | 项目管理 CRUD | `node scripts/creative-writing-project.js create <title> <genre>` |
| `creative-writing-director.js` | 自动导演 v0.1 | `node scripts/creative-writing-director.js direct <projectId> <灵感>` |
| `creative-writing-volume.js` | 卷战略规划 | `node scripts/creative-writing-volume.js plan <projectId> [--words=240000]` |
| `creative-writing-foreshadow.js` | 伏笔追踪管理 | 待创建 |
| `creative-writing-checker.py` | 六维审查（已有） | 自动调用 |
| `creative-writing-rag.js` | RAG 记忆检索（增强） | 待更新（文件存储） |

---

## 📊 六维审查标准

| Checker | 检查内容 | 阈值 |
|---------|----------|------|
| **High-point** | 爽点密度与质量 | ≥ 每 2000 字 1 个 |
| **Consistency** | 设定一致性（战力/地点/时间线） | 0 冲突 |
| **Pacing** | 节奏控制（Strand 比例） | Quest 60% ±10% |
| **OOC** | 人物行为是否偏离人设 | 0 处 |
| **Continuity** | 场景与叙事连贯性 | 0 断裂 |
| **Reader-pull** | 钩子强度、期待管理 | 每章 ≥ 1 个钩子 |

---

## 🧵 Strand Weave 节奏系统

| Strand | 含义 | 理想占比 | 红线 |
|--------|------|---------|------|
| **Quest** | 主线剧情 | 60% | 连续不超过 5 章 |
| **Fire** | 感情/冲突线 | 20% | 断档不超过 10 章 |
| **Constellation** | 世界观扩展 | 20% | 断档不超过 15 章 |

**卷战略节奏板**：`volumes/volume-N/pacing-board.json` 自动生成每章 Strand 比例

---

## 🪝 追读力系统 & 伏笔追踪

### 债务类型
- **钩子债务**：伏笔未回收
- **期待债务**：读者期待未兑现
- **情感债务**：情感线未完结

### 结构化追踪
```json
{
  "debts": [
    {
      "id": "hook_001",
      "type": "hook",
      "chapter": 1,
      "description": "林云获得的神秘戒指来历",
      "expectedChapter": "≤ 10",
      "status": "pending",
      "payoffRef": null
    }
  ]
}
```

---

## 🧠 与 Evolver 集成

- **信号检测**：六维审查警报 → Evolver 信号
- **策略选择**：根据问题类型选择修复基因
- **固化经验**：成功的修复策略固化为 Capsule

---

## 📦 依赖

- **Node.js**: 18+（脚本运行）
- **Python**: 3.8+（checker.py）
- **Evolver**: 可选（自动优化）
- **mem9**: 不再依赖（改用文件存储）

---

## 🚀 快速开始示例

```bash
# 1. 创建项目
node /home/node/.openclaw/skills/creative-writing/scripts/creative-writing-project.js create "无限流之末世杀神" "末世+系统+无限流"

# 2. 获取项目ID（从输出或 list）
node .../creative-writing-project.js list

# 3. 自动导演（生成世界观/角色/大纲）
node /home/node/.openclaw/skills/creative-writing/scripts/creative-writing-director.js direct <projectId> "穿越者林云获得杀神系统，在末世丧尸世界杀伐果断"

# 4. 卷战略规划
node /home/node/.openclaw/skills/creative-writing/scripts/creative-writing-volume.js plan <projectId> --words=240000 --chapters=25

# 5. 开始写作（通过对话触发）
用户：写第一卷第1章，林云觉醒杀神系统
```

---

*基于 webnovel-writer 架构，为 OpenClaw 深度增强*
*版本: v2.0 (2026-04-04 增强版)*chology.md` - 读者心理

---

## Templates

- `templates/novel-init.md` - 小说初始化模板
- `templates/chapter-plan.md` - 章节规划模板
- `templates/character-card.md` - 角色卡片模板
- `templates/world-building.md` - 世界观模板

---

## 依赖

- **mem9**: 云端长篇记忆
- **qwen3-embedding**: 本地 Embedding (4096 维)
- **Evolver**: 自进化机制
- **PUA Skill**: 质量驱动

---

*基于 webnovel-writer 架构，为 OpenClaw 定制*
