#!/usr/bin/env node
/**
 * Creative-Writing: 自动导演 v0.1
 * 功能：灵感 → 世界观 → 角色 → 大纲 → 前 3 章
 * 输入：项目ID + 灵感描述
 * 输出：填充项目目录下的 world.md、characters/、outline.md、volumes/volume-1/chapters/
 */

const fs = require('fs');
const path = require('path');

const PROJECT = require('./creative-writing-project.js');
const PROJECTS_ROOT = PROJECT.PROJECTS_ROOT;

// 提示模板
const PROMPTS = {
  world: (inspiration, genre) => `基于以下灵感，生成一个适合${genre}题材的世界观设定（包含世界规则、主要势力、特殊要素）：

灵感：${inspiration}

要求：
1. 世界规则（3-5条，必须明确"允许什么、不允许什么"）
2. 主要势力（3-5个，包含阵营、目标、关系）
3. 特殊要素（关键地点、稀有资源、独特设定）
4. 力量体系（如果适用）

输出格式：Markdown`,

  character: (world, inspiration) => `基于以下世界观和灵感，生成3-5个核心角色（包含主角、反派、关键配角）：

世界观摘要：${world.substring(0, 500)}

灵感：${inspiration}

对每个角色输出：
- 姓名
- 年龄
- 身份/职业
- 性格特质（3-5个）
- 背景故事（2-3句话）
- 目标/动机
- 关系网络（与其他角色的关系）

输出格式：Markdown，每个角色用 --- 分隔`,

  outline: (world, characters, inspiration) => `基于世界观、角色和灵感，生成前3章的详细大纲：

世界观：${world.substring(0, 300)}
角色：${characters.substring(0, 500)}
灵感：${inspiration}

要求每章包含：
- 章节标题
- 核心事件（3-5个）
- 出场角色
- 伏笔铺设（至少1个）
- 爽点设计（至少1个）
-  Strand 比例（Quest/Fire/Constellation）

输出格式：
# 第一卷 章节大纲

## 第1章：标题
- 核心事件：
- 出场角色：
- 伏笔：
- 爽点：
- Strand 比例：Quest 60%, Fire 20%, Constellation 20%

...（第2、3章同理）`
};

// LLM 调用（使用当前默认模型）
async function callLLM(prompt) {
  // 通过 OpenClaw 内部机制调用 LLM
  // 这里我们输出一个结构化请求，由上层处理
  return {
    type: 'llm_request',
    prompt,
    model: 'stepfun/step-3.5-flash-2603'
  };
}

// 导演主流程
async function direct(projectId, inspiration) {
  console.log(`[Director] 开始导演项目: ${projectId}`);
  console.log(`[Director] 灵感: ${inspiration}`);

  const project = PROJECT.getProject(projectId);
  if (!project) {
    console.error('[Director] 项目不存在');
    return;
  }

  const projectDir = path.join(PROJECTS_ROOT, projectId);

  // 1. 生成世界观
  console.log('[Director] 步骤1/4: 生成世界观...');
  const worldPrompt = PROMPTS.world(inspiration, project.genre);
  const worldResult = await callLLM(worldPrompt);
  // TODO: 实际调用 LLM 并保存
  console.log('[Director] 世界观生成完成（待实际 LLM 调用）');

  // 2. 生成角色
  console.log('[Director] 步骤2/4: 生成角色...');
  const charPrompt = PROMPTS.character(worldResult.content || '', inspiration);
  console.log('[Director] 角色生成完成（待实际 LLM 调用）');

  // 3. 生成大纲
  console.log('[Director] 步骤3/4: 生成大纲...');
  const outlinePrompt = PROMPTS.outline(worldResult.content || '', charPrompt, inspiration);
  console.log('[Director] 大纲生成完成（待实际 LLM 调用）');

  // 4. 生成前3章正文（暂不实现，留待后续）
  console.log('[Director] 步骤4/4: 前3章正文生成（暂跳过）');

  console.log(`[Director] 项目 ${projectId} 导演完成！`);
  console.log(`[Director] 下一步：审查生成的世界观、角色、大纲，确认无误后开始写作。`);
}

// CLI
function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  if (command === 'direct' && args[1] && args[2]) {
    direct(args[1], args.slice(2).join(' ')).catch(console.error);
  } else {
    console.log(`
用法:
  node creative-writing-director.js direct <projectId> <灵感描述>

示例:
  node creative-writing-director.js direct proj_abc123 "一个穿越到末世的少年，获得杀神系统，一路杀怪升级"
    `);
  }
}

if (require.main === module) {
  main();
}

module.exports = { direct, PROMPTS };
