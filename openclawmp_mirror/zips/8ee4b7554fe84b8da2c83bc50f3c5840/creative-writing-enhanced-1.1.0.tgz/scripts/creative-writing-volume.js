#!/usr/bin/env node
/**
 * Creative-Writing: 卷战略工作台
 * 功能：推荐卷数 + 节奏板 + 章节列表规划
 * 输入：项目ID、当前进度
 * 输出：卷规划文件、节奏板、章节列表
 */

const fs = require('fs');
const path = require('path');

const PROJECT = require('./creative-writing-project.js');
const PROJECTS_ROOT = PROJECT.PROJECTS_ROOT;

// Strand Weave 节奏比例（默认）
const DEFAULT_STRAND_RATIO = {
  Quest: 60,    // 主线
  Fire: 20,     // 感情/冲突
  Constellation: 20  // 世界观扩展
};

// 计算建议卷数（基于总字数预估）
function suggestVolumes(estimatedWordCount, targetWordsPerVolume = 80000) {
  const volumes = Math.ceil(estimatedWordCount / targetWordsPerVolume);
  return {
    suggested: volumes,
    targetWordsPerVolume,
    totalEstimated: estimatedWordCount,
    breakdown: Array.from({ length: volumes }, (_, i) => ({
      volume: i + 1,
      startWord: i * targetWordsPerVolume,
      endWord: Math.min((i + 1) * targetWordsPerVolume, estimatedWordCount),
      targetWords: Math.min(targetWordsPerVolume, estimatedWordCount - i * targetWordsPerVolume)
    }))
  };
}

// 生成节奏板（单卷）
function generatePacingBoard(volumeNumber, chapterCount, strandRatio = DEFAULT_STRAND_RATIO) {
  const board = [];
  const totalChapters = chapterCount;

  for (let ch = 1; ch <= totalChapters; ch++) {
    // 根据章节位置调整 Strand 比例（简化算法）
    let q, f, c;
    if (ch <= totalChapters * 0.2) {
      // 开头：多 World-building (Constellation)
      q = strandRatio.Quest * 0.5;
      f = strandRatio.Fire * 0.5;
      c = strandRatio.Constellation * 1.5;
    } else if (ch >= totalChapters * 0.8) {
      // 结尾：高潮集中 (Quest + Fire)
      q = strandRatio.Quest * 1.3;
      f = strandRatio.Fire * 1.3;
      c = strandRatio.Constellation * 0.4;
    } else {
      // 中段：平衡
      q = strandRatio.Quest;
      f = strandRatio.Fire;
      c = strandRatio.Constellation;
    }

    // 归一化
    const sum = q + f + c;
    board.push({
      chapter: ch,
      Quest: Math.round(q / sum * 100),
      Fire: Math.round(f / sum * 100),
      Constellation: Math.round(c / sum * 100),
      note: getChapterNote(ch, totalChapters)
    });
  }

  return board;
}

function getChapterNote(ch, total) {
  if (ch === 1) return '开篇：引入世界观、主角登场、 Hook';
  if (ch <= 3) return '铺垫：建立角色关系、铺设伏笔';
  if (ch <= total - 2) return '发展：主线推进、冲突升级';
  if (ch === total - 1) return '高潮前奏：期待累积';
  if (ch === total) return '高潮/收尾：主要冲突解决';
  return '过渡';
}

// 生成章节列表
function generateChapterList(volumeNumber, chapterCount, outline) {
  const chapters = [];
  for (let i = 1; i <= chapterCount; i++) {
    chapters.push({
      number: i,
      title: `第${i}章（待定）`,
      status: 'planned',
      wordCountTarget: 2500,
      keyPoints: [],
      foreshadow: [],
      payoffRefs: []
    });
  }
  return chapters;
}

// 主流程：为项目生成卷战略
function planVolumes(projectId, options = {}) {
  console.log(`[VolumeStrategy] 开始规划项目: ${projectId}`);

  const project = PROJECT.getProject(projectId);
  if (!project) {
    console.error('[VolumeStrategy] 项目不存在');
    return;
  }

  const projectDir = path.join(PROJECTS_ROOT, projectId);
  const volumesDir = path.join(projectDir, 'volumes');

  // 参数
  const totalWords = options.totalWords || 240000; // 默认 24 万字（3卷，每卷8万）
  const chaptersPerVolume = options.chaptersPerVolume || 25; // 每卷25章

  // 1. 建议卷数
  const suggestion = suggestVolumes(totalWords);
  console.log(`[VolumeStrategy] 建议卷数: ${suggestion.suggested} 卷（预估总字数 ${totalWords}）`);

  // 2. 为每卷创建规划
  for (let v = 1; v <= suggestion.suggested; v++) {
    const volumeDir = path.join(volumesDir, `volume-${v}`);
    fs.mkdirSync(volumeDir, { recursive: true });

    // 节奏板
    const pacingBoard = generatePacingBoard(v, chaptersPerVolume);
    fs.writeFileSync(
      path.join(volumeDir, 'pacing-board.json'),
      JSON.stringify(pacingBoard, null, 2)
    );

    // 章节列表
    const chapters = generateChapterList(v, chaptersPerVolume);
    fs.writeFileSync(
      path.join(volumeDir, 'chapters.json'),
      JSON.stringify(chapters, null, 2)
    );

    // 卷计划文档
    const planMd = `# 第 ${v} 卷 战略规划

## 基本信息
- 目标字数: ${suggestion.breakdown[v-1].targetWords}
- 章节数: ${chaptersPerVolume}
- 章节编号: ${(v-1)*chaptersPerVolume + 1} - ${v*chaptersPerVolume}

## Strand Weave 节奏板

| 章节 | Quest | Fire | Constellation | 备注 |
|------|-------|------|---------------|------|
${pacingBoard.map(c => `| ${c.chapter} | ${c.Quest}% | ${c.Fire}% | ${c.Constellation}% | ${c.note} |`).join('\n')}

## 章节列表
${chapters.map(ch => `- 第${ch.number}章: ${ch.title} (目标 ${ch.wordCountTarget} 字)`).join('\n')}

## 伏笔铺设计划
- 本章伏笔：
- 前文回收：
- 长期伏笔：

## 关键节点
- 本章高潮：
- 角色成长：
- 世界观揭示：

---
*生成时间: ${new Date().toISOString()}*
`;

    fs.writeFileSync(path.join(volumeDir, 'plan.md'), planMd);

    console.log(`[VolumeStrategy] 第 ${v} 卷规划完成: ${volumeDir}`);
  }

  // 3. 更新项目元数据
  PROJECT.updateProject(projectId, {
    'metadata.volumeCount': suggestion.suggested,
    'metadata.chapterCount': suggestion.suggested * chaptersPerVolume,
    'metadata.targetWordCount': totalWords,
    'updatedAt': new Date().toISOString()
  });

  console.log(`[VolumeStrategy] 项目规划完成！`);
  console.log(`[VolumeStrategy] 目录: ${volumesDir}`);
}

// CLI
function main() {
  const args = process.argv.slice(2);
  if (args[0] === 'plan' && args[1]) {
    const options = {};
    args.slice(2).forEach(arg => {
      if (arg.startsWith('--words=')) {
        options.totalWords = parseInt(arg.split('=')[1], 10);
      }
      if (arg.startsWith('--chapters=')) {
        options.chaptersPerVolume = parseInt(arg.split('=')[1], 10);
      }
    });
    planVolumes(args[1], options);
  } else {
    console.log(`
用法:
  node creative-writing-volume.js plan <projectId> [--words=240000] [--chapters=25]

示例:
  node creative-writing-volume.js plan proj_abc123 --words=240000 --chapters=25
    `);
  }
}

if (require.main === module) {
  main();
}

module.exports = { suggestVolumes, generatePacingBoard, planVolumes };
