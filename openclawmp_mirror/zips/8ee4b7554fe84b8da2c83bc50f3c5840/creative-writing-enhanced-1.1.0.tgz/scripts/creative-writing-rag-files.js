#!/usr/bin/env node
/**
 * Creative-Writing: 文件式 RAG 记忆检索
 * 替代 mem9 云端，使用本地文件系统
 * 功能：关键词搜索 + 全文片段提取
 */

const fs = require('fs');
const path = require('path');

const PROJECT = require('./creative-writing-project.js');
const PROJECTS_ROOT = PROJECT.PROJECTS_ROOT;

/**
 * 在项目目录中搜索相关文档
 * @param {string} projectId - 项目ID
 * @param {string} query - 查询文本
 * @param {object} options - 选项
 * @returns {Array<SearchResult>}
 */
async function search(projectId, query, options = {}) {
  const limit = options.limit || 5;
  const projectDir = path.join(PROJECTS_ROOT, projectId);

  if (!fs.existsSync(projectDir)) {
    console.error(`[RAG] 项目不存在: ${projectId}`);
    return [];
  }

  // 要搜索的文件类型
  const searchExts = ['.md', '.json', '.txt'];
  const results = [];

  // 递归遍历项目目录
  function walk(dir) {
    const entries = fs.readdirSync(dir, { withFileTypes: true });
    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        // 跳过一些目录
        if (!['node_modules', '.git', 'logs'].includes(entry.name)) {
          walk(fullPath);
        }
      } else if (searchExts.includes(path.extname(entry.name))) {
        try {
          const content = fs.readFileSync(fullPath, 'utf8');
          const score = calculateScore(content, query);
          if (score > 0) {
            results.push({
              path: fullPath,
              score,
              snippet: extractSnippet(content, query),
              type: path.extname(entry.name).slice(1)
            });
          }
        } catch (e) {
          // 忽略无法读取的文件
        }
      }
    }
  }

  walk(projectDir);

  // 按评分排序，取前 limit 条
  results.sort((a, b) => b.score - a.score);
  return results.slice(0, limit);
}

/**
 * 计算文本与查询的相关度评分（简单关键词匹配）
 */
function calculateScore(text, query) {
  const keywords = query.toLowerCase().split(/\s+/).filter(w => w.length > 1);
  if (keywords.length === 0) return 0;

  const textLower = text.toLowerCase();
  let score = 0;

  keywords.forEach(kw => {
    const regex = new RegExp(kw, 'gi');
    const matches = textLower.match(regex);
    if (matches) {
      score += matches.length;
    }
    // 完整短语加分
    if (textLower.includes(query.toLowerCase())) {
      score += 5;
    }
  });

  return score;
}

/**
 * 提取包含查询词的文本片段
 */
function extractSnippet(text, query, maxLength = 200) {
  const pos = text.toLowerCase().indexOf(query.toLowerCase());
  if (pos === -1) {
    return text.substring(0, maxLength) + '...';
  }

  const start = Math.max(0, pos - 50);
  const end = Math.min(text.length, pos + query.length + 150);
  let snippet = text.substring(start, end).trim();

  if (start > 0) snippet = '...' + snippet;
  if (end < text.length) snippet = snippet + '...';

  return snippet;
}

/**
 * 存储记忆到本地文件（追加到项目记忆文件）
 */
function store(projectId, content, tags = [], source = 'creative-writing') {
  const projectDir = path.join(PROJECTS_ROOT, projectId);
  const memoryFile = path.join(projectDir, 'memory.md');

  const entry = `## [${new Date().toISOString()}] ${source}\n标签: ${tags.join(', ')}\n\n${content}\n\n---\n\n`;

  fs.appendFileSync(memoryFile, entry, 'utf8');
  console.log(`[RAG] 记忆已存储: ${memoryFile}`);
  return `local_${Date.now()}`;
}

/**
 * 获取相关上下文（用于写作前加载）
 */
async function getContext(projectId, queries = ['世界观', '角色', '大纲']) {
  const context = {};
  for (const q of queries) {
    const results = await search(projectId, q, { limit: 3 });
    context[q] = results.map(r => r.snippet).join('\n\n');
  }
  return context;
}

// CLI 测试
if (require.main === module) {
  const args = process.argv.slice(2);
  if (args.length < 2) {
    console.log('用法: node creative-writing-rag-files.js <projectId> <query> [limit=5]');
    process.exit(1);
  }
  (async () => {
    const results = await search(args[0], args[1], { limit: parseInt(args[2]) || 5 });
    console.log(`找到 ${results.length} 个相关片段:`);
    results.forEach((r, i) => {
      console.log(`\n[${i+1}] 文件: ${path.basename(r.path)} (评分: ${r.score})`);
      console.log(`片段: ${r.snippet}`);
    });
  })();
}

module.exports = { search, store, getContext };
