#!/usr/bin/env node
/**
 * Creative-Writing: 伏笔追踪管理
 * 功能：记录伏笔、追踪状态、回收提醒
 * 存储：projects/<id>/debts.json
 */

const fs = require('fs');
const path = require('path');

const PROJECT = require('./creative-writing-project.js');
const PROJECTS_ROOT = PROJECT.PROJECTS_ROOT;

// 债务类型枚举
const DEBT_TYPES = {
  HOOK: 'hook',        // 钩子伏笔
  EXPECTATION: 'expectation', // 期待债务
  EMOTION: 'emotion',  // 情感债务
  MYSTERY: 'mystery'   // 悬念/谜团
};

// 获取项目的 debts 文件路径
function getDebtsPath(projectId) {
  return path.join(PROJECTS_ROOT, projectId, 'debts.json');
}

// 读取债务
function readDebts(projectId) {
  const debtsPath = getDebtsPath(projectId);
  if (!fs.existsSync(debtsPath)) {
    return { debts: [], version: '1.0' };
  }
  try {
    return JSON.parse(fs.readFileSync(debtsPath, 'utf8'));
  } catch (e) {
    console.error('读取债务文件失败:', e.message);
    return { debts: [], version: '1.0' };
  }
}

// 写入债务
function writeDebts(projectId, data) {
  const debtsPath = getDebtsPath(projectId);
  fs.writeFileSync(debtsPath, JSON.stringify(data, null, 2), 'utf8');
}

// 添加伏笔
function addDebt(projectId, debt) {
  const data = readDebts(projectId);
  const newDebt = {
    id: `debt_${Date.now().toString(36)}_${Math.random().toString(36).substring(2, 6)}`,
    type: debt.type,
    chapter: debt.chapter,
    description: debt.description,
    expectedChapter: debt.expectedChapter || null,
    status: 'pending', // pending, paid, cancelled
    payoffRef: null,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };

  data.debts.push(newDebt);
  writeDebts(projectId, data);

  console.log(`[Debt] 已添加伏笔 [${newDebt.type}] ${newDebt.description.substring(0, 30)}... (ID: ${newDebt.id})`);
  return newDebt;
}

// 回收伏笔
function payDebt(debtId, projectId, payoffDetails) {
  const data = readDebts(projectId);
  const debt = data.debts.find(d => d.id === debtId);

  if (!debt) {
    console.error(`[Debt] 伏笔未找到: ${debtId}`);
    return false;
  }

  if (debt.status === 'paid') {
    console.warn(`[Debt] 伏笔已回收: ${debtId}`);
    return false;
  }

  debt.status = 'paid';
  debt.payoffRef = payoffDetails || `回收于章节 ${Date.now()}`;
  debt.updatedAt = new Date().toISOString();

  writeDebts(projectId, data);
  console.log(`[Debt] ✅ 伏笔已回收: ${debt.description.substring(0, 50)}`);
  return true;
}

// 列出待回收伏笔
function listPending(projectId, options = {}) {
  const data = readDebts(projectId);
  const pending = data.debts.filter(d => d.status === 'pending');

  if (options.type) {
    pending.filter(d => d.type === options.type);
  }

  console.log(`[Debt] 待回收伏笔 (${pending.length} 个):`);
  pending.forEach(d => {
    const chapter = d.expectedChapter ? ` (期望: ${d.expectedChapter}章)` : '';
    console.log(`  [${d.type}] ${d.description.substring(0, 60)}... [${d.chapter}章]${chapter}`);
    console.log(`        ID: ${d.id}`);
  });

  return pending;
}

// 统计报告
function getReport(projectId) {
  const data = readDebts(projectId);
  const total = data.debts.length;
  const pending = data.debts.filter(d => d.status === 'pending').length;
  const paid = data.debts.filter(d => d.status === 'paid').length;

  const byType = {};
  data.debts.forEach(d => {
    byType[d.type] = (byType[d.type] || 0) + 1;
  });

  return {
    total,
    pending,
    paid,
    ratio: total > 0 ? (paid / total).toFixed(2) : 0,
    byType
  };
}

// CLI
function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  const projectId = args[1];

  if (!projectId) {
    console.log('用法: node creative-writing-foreshadow.js <projectId> <command> [options]');
    process.exit(1);
  }

  switch (command) {
    case 'add':
      addDebt(projectId, {
        type: args[2] || 'hook',
        chapter: parseInt(args[3], 10) || 1,
        description: args.slice(4).join(' ') || '未命名伏笔',
        expectedChapter: args[5] || null
      });
      break;
    case 'pay':
      payDebt(args[2], projectId, args[3]);
      break;
    case 'list':
      listPending(projectId);
      break;
    case 'report':
      console.log(JSON.stringify(getReport(projectId), null, 2));
      break;
    default:
      console.log(`
命令:
  add <type> <chapter> <description> [expectedChapter]  添加伏笔
  pay <debtId> [payoffDetails]                           回收伏笔
  list                                                   列出待回收
  report                                                 统计报告

类型: hook, expectation, emotion, mystery
      `);
  }
}

if (require.main === module) {
  main();
}

module.exports = { addDebt, payDebt, listPending, getReport, DEBT_TYPES };
