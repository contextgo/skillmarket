#!/usr/bin/env node
/**
 * Creative-Writing: 项目管理模块
 * 功能：多本小说 CRUD、项目状态管理、元数据存储
 * 存储位置：~/.openclaw/workspace/creative-writing-projects/
 */

const fs = require('fs');
const path = require('path');

const PROJECTS_ROOT = path.join(process.env.HOME || process.env.USERPROFILE, '.openclaw', 'workspace', 'creative-writing-projects');
const INDEX_FILE = path.join(PROJECTS_ROOT, 'projects.json');

// 确保目录存在
function ensureDirs() {
  if (!fs.existsSync(PROJECTS_ROOT)) {
    fs.mkdirSync(PROJECTS_ROOT, { recursive: true });
  }
}

// 读取项目索引
function readIndex() {
  ensureDirs();
  if (!fs.existsSync(INDEX_FILE)) {
    return { projects: [], version: '1.0' };
  }
  try {
    const raw = fs.readFileSync(INDEX_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    console.error('读取项目索引失败:', e.message);
    return { projects: [], version: '1.0' };
  }
}

// 写入项目索引
function writeIndex(index) {
  fs.writeFileSync(INDEX_FILE, JSON.stringify(index, null, 2), 'utf8');
}

// 生成项目ID（时间戳 + 随机）
function generateProjectId() {
  const ts = Date.now().toString(36);
  const rand = Math.random().toString(36).substring(2, 8);
  return `proj_${ts}_${rand}`;
}

// 创建项目
function createProject(title, genre, options = {}) {
  const index = readIndex();
  const projectId = generateProjectId();

  const project = {
    id: projectId,
    title,
    genre,
    status: 'planning', // planning, writing, reviewing, completed, archived
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    metadata: {
      wordCount: 0,
      chapterCount: 0,
      volumeCount: 0,
      ...options.metadata
    },
    config: {
      enableSixDimensionalReview: true,
      enableForeshadowTracking: true,
      enableRAG: true,
      storageType: 'file', // 不使用 mem9，改用文件
      ...options.config
    }
  };

  index.projects.push(project);
  writeIndex(index);

  // 创建项目目录
  const projectDir = path.join(PROJECTS_ROOT, projectId);
  fs.mkdirSync(projectDir, { recursive: true });

  // 初始化子目录
  fs.mkdirSync(path.join(projectDir, 'characters'));
  fs.mkdirSync(path.join(projectDir, 'volumes'));
  fs.mkdirSync(path.join(projectDir, 'chapters'));
  fs.mkdirSync(path.join(projectDir, 'debts'));

  // 写入项目元数据
  fs.writeFileSync(path.join(projectDir, 'project.json'), JSON.stringify(project, null, 2));

  console.log(`[Project] 创建成功: ${title} (ID: ${projectId})`);
  console.log(`[Project] 目录: ${projectDir}`);

  return project;
}

// 列出项目
function listProjects(filter = {}) {
  const index = readIndex();
  let projects = index.projects;

  if (filter.status) {
    projects = projects.filter(p => p.status === filter.status);
  }

  console.log(`[Project] 共 ${projects.length} 个项目:`);
  projects.forEach(p => {
    console.log(`  [${p.status}] ${p.title} (ID: ${p.id}, 字数: ${p.metadata.wordCount || 0})`);
  });

  return projects;
}

// 获取项目详情
function getProject(projectId) {
  const index = readIndex();
  const project = index.projects.find(p => p.id === projectId);
  if (!project) {
    console.error(`[Project] 项目未找到: ${projectId}`);
    return null;
  }

  const projectDir = path.join(PROJECTS_ROOT, projectId);
  const projectFile = path.join(projectDir, 'project.json');

  if (fs.existsSync(projectFile)) {
    try {
      const detail = JSON.parse(fs.readFileSync(projectFile, 'utf8'));
      return detail;
    } catch (e) {
      console.error('读取项目文件失败:', e.message);
    }
  }

  return project;
}

// 更新项目
function updateProject(projectId, updates) {
  const index = readIndex();
  const projectIdx = index.projects.findIndex(p => p.id === projectId);
  if (projectIdx === -1) {
    console.error(`[Project] 项目未找到: ${projectId}`);
    return null;
  }

  index.projects[projectIdx] = {
    ...index.projects[projectIdx],
    ...updates,
    updatedAt: new Date().toISOString()
  };

  writeIndex(index);

  const projectDir = path.join(PROJECTS_ROOT, projectId);
  fs.writeFileSync(path.join(projectDir, 'project.json'), JSON.stringify(index.projects[projectIdx], null, 2));

  console.log(`[Project] 已更新: ${projectId}`);
  return index.projects[projectIdx];
}

// 删除项目
function deleteProject(projectId) {
  const index = readIndex();
  const projectIdx = index.projects.findIndex(p => p.id === projectId);
  if (projectIdx === -1) {
    console.error(`[Project] 项目未找到: ${projectId}`);
    return false;
  }

  const project = index.projects[projectIdx];
  index.projects.splice(projectIdx, 1);
  writeIndex(index);

  const projectDir = path.join(PROJECTS_ROOT, projectId);
  if (fs.existsSync(projectDir)) {
    fs.rmSync(projectDir, { recursive: true, force: true });
  }

  console.log(`[Project] 已删除: ${project.title} (${projectId})`);
  return true;
}

// CLI 入口
function main() {
  const args = process.argv.slice(2);
  const command = args[0];

  switch (command) {
    case 'create':
      createProject(args[1], args[2], {});
      break;
    case 'list':
      listProjects();
      break;
    case 'get':
      console.log(JSON.stringify(getProject(args[1]), null, 2));
      break;
    case 'update':
      // 简单解析 key=value
      const updates = {};
      args.slice(2).forEach(pair => {
        const [k, v] = pair.split('=');
        updates[k] = v;
      });
      updateProject(args[1], updates);
      break;
    case 'delete':
      deleteProject(args[1]);
      break;
    default:
      console.log(`
Usage:
  node creative-writing-project.js create <title> <genre>
  node creative-writing-project.js list
  node creative-writing-project.js get <projectId>
  node creative-writing-project.js update <projectId> <key>=<value> [...]
  node creative-writing-project.js delete <projectId>
      `);
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  createProject,
  listProjects,
  getProject,
  updateProject,
  deleteProject,
  PROJECTS_ROOT
};
