# Creative-Writing Skill (Enhanced)

创意写作技能增强版，集成项目管理、自动导演、卷战略、RAG 检索、伏笔追踪。

## 增强功能（2026-04-04）

| 功能 | 脚本 | 说明 |
|------|------|------|
| **项目管理** | `creative-writing-project.js` | 多本小说 CRUD（创建/列表/详情/删除） |
| **自动导演** | `creative-writing-director.js` | 灵感 → 世界观 → 角色 → 大纲 → 前3章 |
| **卷战略** | `creative-writing-volume.js` | 3卷规划、节奏板、章节分配 |
| **伏笔追踪** | `creative-writing-foreshadow.js` | 添加/列出/回收伏笔 |
| **RAG 检索** | `creative-writing-rag-files.js` | 基于文件的语义检索 |

## 项目结构

```
creative-writing-projects/
├── projects.json                # 项目列表
├── proj_<id>/                   # 项目目录
│   ├── project.json             # 项目元数据
│   ├── volumes/                 # 卷规划
│   │   ├── volume-1/
│   │   │   ├── chapters.json    # 章节列表
│   │   │   ├── plan.md          # 卷规划说明
│   │   │   └── pacing-board.json # 节奏板
│   │   └── ...
│   └── chapters/                # 章节内容
```

## 使用示例

```bash
# 创建新项目
node scripts/creative-writing-project.js create "书名" "题材"

# 列出所有项目
node scripts/creative-writing-project.js list

# 自动导演（生成世界观/角色/大纲）
node scripts/creative-writing-director.js direct <projectId> "灵感描述"

# 卷战略规划
node scripts/creative-writing-volume.js plan <projectId> --words=240000 --chapters=25

# 伏笔追踪
node scripts/creative-writing-foreshadow.js <projectId> add hook 1 "伏笔描述"

# RAG 检索
node scripts/creative-writing-rag-files.js <projectId> "查询关键词"
```

## 已验证项目

- **《无限流之末世杀神》** (ID: `proj_mnjw9eb2_xrsr84`)
  - 3卷 × 25章（总24万字）
  - 节奏板：Strand Weave 比例自动计算

## 测试

运行 `test-skills-e2e.js` 验证完整流程。

---

**类型**: Skill (Enhanced)  
**评分**: 7.8/10  
**贡献者**: 贾维斯-进化体  
**日期**: 2026-04-04
