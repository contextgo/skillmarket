# 度量衡专家系统 - 安装索引

> **你需要的不是克隆一个数字分身，而是要拥有专家思维和视野，才能在Agent时代从胜利走向胜利！**

---

## 一键安装

```bash
# 安装核心系统
npx dlh365 add dlh365-expert-system

# 查看帮助
npx dlh365 --help
```

---

## 专家技能完整列表

### 国际专家 (7位)

| 专家 | 英文名 | 核心领域 | 核心智模 | 安装命令 |
|:---:|--------|---------|---------|----------|
| 乔布斯 | Steve Jobs | 产品/设计/战略 | 聚焦即说不、端到端控制 | `npx dlh365 add dlh365/steve-jobs-skill` |
| 马斯克 | Elon Musk | 工程/成本/创新 | 第一性原理、渐近极限法 | `npx dlh365 add dlh365/elon-musk-skill` |
| 芒格 | Charlie Munger | 投资/思维 | 多元思维、逆向思考 | `npx dlh365 add dlh365/munger-skill` |
| 费曼 | Richard Feynman | 学习/教学 | 费曼学习法、怀疑精神 | `npx dlh365 add dlh365/feynman-skill` |
| 纳瓦尔 | Naval Ravikant | 财富/人生 | 欲望即合同、特定知识 | `npx dlh365 add dlh365/naval-skill` |
| 塔勒布 | Nassim Taleb | 风险/不确定性 | 反脆弱、黑天鹅 | `npx dlh365 add dlh365/taleb-skill` |
| 稻盛和夫 | Inamori Kazuo | 经营/哲学 | 阿米巴、付出不亚于任何人 | `npx dlh365 add dlh365/inamori-kazuo-skill` |

### 中国专家 (7位)

| 专家 | 拼音 | 核心领域 | 核心智模 | 安装命令 |
|:---:|------|---------|---------|----------|
| 张一鸣 | Zhang Yiming | 产品/算法 | 延迟满足、确定性价值 | `npx dlh365 add dlh365/zhangyiming-skill` |
| 王兴 | Wang Xing | 战略/竞争 | 无限游戏、终局思维 | `npx dlh365 add dlh365/wangxing-skill` |
| 任正非 | Ren Zhengfei | 管理/组织 | 熵减理论、灰度决策 | `npx dlh365 add dlh365/renzhengfei-skill` |
| 段永平 | Duan Yongping | 投资/经营 | 本分文化、不为清单 | `npx dlh365 add dlh365/duanyongping-skill` |
| 曹德旺 | Cao Dewang | 制造/人生 | 敬天爱人、实业思维 | `npx dlh365 add dlh365/caodewan-skill` |
| 沈南鹏 | Shen Nanpeng | 投资/创业 | 赛道选择、增长逻辑 | `npx dlh365 add dlh365/shennanpeng-skill` |
| 张雪峰 | Zhang Xuefeng | 教育/职业 | ROI教育观、阶层流动 | `npx dlh365 add dlh365/zhangxuefeng-skill` |

---

## 按场景推荐

| 场景 | 推荐专家 | 安装 |
|------|---------|------|
| 产品设计决策 | 乔布斯、张一鸣 | `npx dlh365 add dlh365/steve-jobs-skill` |
| 商业模式优化 | 张一鸣、王兴 | `npx dlh365 add dlh365/zhangyiming-skill` |
| 投资决策分析 | 芒格、段永平 | `npx dlh365 add dlh365/munger-skill` |
| 竞争策略制定 | 王兴、马斯克 | `npx dlh365 add dlh365/wangxing-skill` |
| 组织变革推进 | 任正非、稻盛和夫 | `npx dlh365 add dlh365/renzhengfei-skill` |
| 学习方法优化 | 费曼、纳瓦尔 | `npx dlh365 add dlh365/feynman-skill` |
| 风险管理 | 塔勒布、芒格 | `npx dlh365 add dlh365/taleb-skill` |
| 职业规划 | 张雪峰、纳瓦尔 | `npx dlh365 add dlh365/zhangxuefeng-skill` |

---

## 批量安装

```bash
# 安装所有国际专家
npx dlh365 add dlh365/international-experts

# 安装所有中国专家  
npx dlh365 add dlh365/chinese-experts

# 安装全部专家
npx dlh365 add dlh365/all-experts
```

---

## 蒸馏新专家

```bash
# 蒸馏任何你感兴趣的专家
npx dlh365 distil "稻盛和夫"
npx dlh365 distil "曹德旺"
npx dlh365 distil "段永平"
npx dlh365 distil "沈南鹏"
```

---

**版本**: v2.0.0
**更新**: 2026年4月
