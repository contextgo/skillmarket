# 度量衡专家系统 - 完整安装指南

## 一、快速开始

### 1. 安装核心系统

```bash
# 安装度量衡专家系统核心
npx dlh365 add dlh365-expert-system
```

### 2. 安装专家视角技能

```bash
# 国际专家
npx dlh365 add dlh365/steve-jobs-skill      # 乔布斯：产品/设计/战略
npx dlh365 add dlh365/elon-musk-skill       # 马斯克：工程/成本/第一性原理
npx dlh365 add dlh365/munger-skill          # 芒格：投资/多元思维/逆向思考
npx dlh365 add dlh365/feynman-skill         # 费曼：学习/教学/科学思维
npx dlh365 add dlh365/naval-skill           # 纳瓦尔：财富/杠杆/人生哲学
npx dlh365 add dlh365/taleb-skill           # 塔勒布：风险/反脆弱/不确定性
npx dlh365 add dlh365/inamori-kazuo-skill  # 稻盛和夫：阿米巴经营/付出不亚于任何人

# 中国专家
npx dlh365 add dlh365/zhangyiming-skill     # 张一鸣：算法思维/延迟满足/组织进化
npx dlh365 add dlh365/wangxing-skill        # 王兴：长期主义/战略定力/无边界
npx dlh365 add dlh365/renzhengfei-skill     # 任正非：危机意识/奋斗者文化/熵减
npx dlh365 add dlh365/duanyongping-skill    # 段永平：本分文化/不为清单/长期主义
npx dlh365 add dlh365/caodewan-skill        # 曹德旺：敬天爱人/实业思维/成本控制
npx dlh365 add dlh365/shennanpeng-skill     # 沈南鹏：投资逻辑/赛道选择/创业者特质
npx dlh365 add dlh365/zhangxuefeng-skill    # 张雪峰：ROI教育观/阶层流动现实主义
```

### 3. 一键安装全部专家

```bash
# 安装所有已蒸馏的专家技能
npx dlh365 add dlh365/all-experts
```

---

## 二、兼容性说明

度量衡专家系统兼容以下平台：

### Claude Code

```bash
# Claude Code 用户直接使用
npx dlh365 add dlh365-expert-system
```

### OpenClaw / ClawHub

```bash
# OpenClaw 用户使用兼容命令
npx clawhub install dlh365-expert-system
```

### Cursor / 其他 AI IDE

```bash
# Cursor 用户
npx skills add dlh365-expert-system --agent cursor
```

### 传统 npx skills 用户

```bash
# 兼容原有 npx skills 命令
npx skills add dlh365/dlh365-expert-system
```

---

## 三、核心功能使用

### 功能一：蒸馏专家视角

创建新的专家视角技能：

```
> 蒸馏一个稻盛和夫
> 造一个曹德旺的视角Skill
> 帮我做一个段永平的Skill
```

系统会自动执行：
1. 六路并行采集（著作、访谈、社交、批评、决策、时间线）
2. 三重验证提炼（跨域复现、预测能力、排他特征）
3. 生成技能文件
4. 质量验证

### 功能二：调用专家视角

使用已安装的专家视角分析问题：

```
> 用芒格的视角帮我分析这个投资决策
> 费曼会怎么解释量子计算？
> 张一鸣会怎么看待这个产品方向？
> 切换到任正非，分析我们团队的组织问题
```

### 功能三：多专家会诊

让多个专家同时分析同一问题：

```
> 组织一场专家会诊：芒格、张一鸣、任正非
> 问题是：公司发展遇到瓶颈，应该多元化还是深耕主业？
```

### 功能四：思维模型迁移

将专家的思维模型应用到新领域：

```
> 用马斯克的"第一性原理"分析教育行业
> 用张一鸣的"确定性价值"分析我们的产品
```

---

## 四、专家技能详细列表

### 国际专家

| 专家 | 核心领域 | 核心智模 | 安装命令 |
|------|---------|---------|----------|
| **乔布斯** | 产品/设计/战略 | 聚焦即说不、端到端控制、现实扭曲场 | `npx dlh365 add dlh365/steve-jobs-skill` |
| **马斯克** | 工程/成本/创新 | 渐近极限法、第一性原理、五步工作法 | `npx dlh365 add dlh365/elon-musk-skill` |
| **芒格** | 投资/思维/决策 | 多元思维模型、逆向思考、能力圈 | `npx dlh365 add dlh365/munger-skill` |
| **费曼** | 学习/教学/科学 | 费曼学习法、怀疑精神、科学美学 | `npx dlh365 add dlh365/feynman-skill` |
| **纳瓦尔** | 财富/杠杆/人生 | 欲望即合同、特定知识、杠杆思维 | `npx dlh365 add dlh365/naval-skill` |
| **塔勒布** | 风险/不确定性 | 反脆弱、黑天鹅、杠铃策略 | `npx dlh365 add dlh365/taleb-skill` |
| **稻盛和夫** | 经营/哲学/人生 | 阿米巴经营、付出不亚于任何人、敬天爱人 | `npx dlh365 add dlh365/inamori-kazuo-skill` |

### 中国专家

| 专家 | 核心领域 | 核心智模 | 安装命令 |
|------|---------|---------|----------|
| **张一鸣** | 产品/算法/组织 | 延迟满足、确定性价值、信息分发本质 | `npx dlh365 add dlh365/zhangyiming-skill` |
| **王兴** | 战略/竞争/长期主义 | 无限游戏、战略定力、终局思维 | `npx dlh365 add dlh365/wangxing-skill` |
| **任正非** | 管理/组织/危机 | 熵减理论、奋斗者文化、危机驱动 | `npx dlh365 add dlh365/renzhengfei-skill` |
| **段永平** | 投资/经营/人生 | 本分文化、不为清单、长期主义 | `npx dlh365 add dlh365/duanyongping-skill` |
| **曹德旺** | 制造/管理/人生 | 敬天爱人、实业思维、成本控制 | `npx dlh365 add dlh365/caodewan-skill` |
| **沈南鹏** | 投资/创业/赛道 | 赛道选择、创业者画像、增长逻辑 | `npx dlh365 add dlh365/shennanpeng-skill` |
| **张雪峰** | 教育/职业规划 | ROI教育观、阶层流动现实主义 | `npx dlh365 add dlh365/zhangxuefeng-skill` |

---

## 五、相关技能生态

### 同类技能推荐

度量衡专家系统与以下技能形成互补：

| 技能名称 | 功能 | 安装命令 |
|---------|------|----------|
| **女娲.skill** | 专家思维蒸馏（原型） | `npx skills add alchaincyf/nuwa-skill` |
| **同事.skill** | 蒸馏身边同事的工作习惯 | `npx skills add titanwings/colleague-skill` |
| **superpowers** | 完整AI编程框架 | `npx skills add obra/superpowers` |
| **find-skills** | 技能发现工具 | `npx skills add vercel-labs/skills` |

### 扩展技能市场

| 平台 | 说明 | 链接 |
|------|------|------|
| **skills.sh** | Vercel官方技能排行榜 | [skills.sh](https://skills.sh) |
| **ClawHub** | OpenClaw技能市场 | [clawhub.org](https://clawd.org.cn) |
| **鱼皮AI导航** | 中文技能导航 | [ai.codefather.cn/skills](https://ai.codefather.cn/skills) |
| **skillsmp** | GitHub技能索引 | [skillsmp.com](https://skillsmp.com/zh) |

---

## 六、自蒸馏指南

### 从自己蒸馏技能

```bash
# 准备数据
mkdir -p my-expert-data
# 将你的文章、周报、聊天记录放入该目录

# 启动自蒸馏
> 蒸馏我自己，基于我的公众号文章、周报和工作笔记
```

### 从身边专家蒸馏

```bash
# 蒸馏导师
> 蒸馏我的导师，基于他给我的论文修改意见和组会发言

# 蒸馏同事
> 蒸馏离职同事，基于他的项目文档和飞书沟通记录
```

### 数据源建议

| 数据类型 | 推荐来源 | 提取价值 |
|---------|---------|---------|
| 文字作品 | 公众号、博客、周报、复盘文档 | 思考框架、价值观、表达风格 |
| 沟通记录 | 飞书、钉钉、微信、邮件 | 决策逻辑、沟通风格、应对模式 |
| 工作成果 | 代码库、设计稿、方案文档 | 专业技能、工作规范、质量标准 |
| 录屏讲解 | 操作演示、培训视频 | 隐性知识、决策过程、异常处理 |

---

## 七、常见问题

### Q1: 安装后如何确认技能已加载？

```
> 列出已安装的专家技能
```

系统会显示已安装的专家列表及其版本。

### Q2: 如何更新技能？

```bash
# 更新单个技能
npx dlh365 update dlh365/zhangyiming-skill

# 更新所有技能
npx dlh365 update --all
```

### Q3: 专家观点与我的实际情况不符怎么办？

专家视角是参考框架，不是标准答案。使用时：
1. 理解专家的思考逻辑
2. 结合自己的实际情况
3. 做出适合自己的决策

### Q4: 如何判断技能质量？

每个技能都有质量等级标注：
- ⭐⭐⭐ 生产级：可直接用于重要决策
- ⭐⭐ 实验级：用于探索性讨论，需结合其他信息验证
- ⭐ 参考级：仅供了解专家思路

---

## 八、最佳实践

### 1. 多专家交叉验证

对于重要决策，建议：
```
> 用芒格、张一鸣、任正非三个视角分析这个决策
```
比较不同视角的分析结果，获得更全面的判断。

### 2. 先诊断再开方

使用专家视角时：
- 先描述完整的问题背景
- 提供足够的上下文信息
- 让专家理解你的具体情境

### 3. 关注思考逻辑

比答案更重要的是：
- 专家如何分析问题
- 使用了什么心智模型
- 决策的权衡逻辑是什么

### 4. 持续迭代

定期更新技能：
- 专家的观点会演进
- 技能会随时间衰减
- 建议每季度检查更新

---

## 九、贡献与反馈

### 如何贡献

1. 提交新专家蒸馏请求
2. 完善现有专家的心智模型
3. 分享使用案例和效果反馈
4. 提交代码优化建议

### 联系方式

- GitHub Issues: [项目地址]
- 邮箱: [联系邮箱]
- 微信公众号: 度量衡

---

## 十、版本历史

### v2.0.0 (2026-04)
- 新增8位中国专家视角技能
- 新增多专家会诊功能
- 新增思维模型迁移功能
- 统一使用 `npx dlh365` 命令体系
- 优化三重验证机制

### v1.0.0
- 基础蒸馏功能
- 六路并行采集
- 三重验证提炼
- 六层提取框架

---

**核心理念**：

> 你需要的不是克隆一个数字分身，而是要拥有专家思维和视野，才能在Agent时代从胜利走向胜利！
