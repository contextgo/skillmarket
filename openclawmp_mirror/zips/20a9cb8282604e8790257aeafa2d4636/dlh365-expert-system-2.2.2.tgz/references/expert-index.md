# 度量衡专家技能索引

本文档汇总所有已蒸馏的专家技能及相关资源，方便查找和安装。

---

## 一、专家技能完整列表

### 国际专家 (6位)

| 编号 | 专家 | 英文名 | 核心领域 | 核心智模(3个) | 安装命令 |
|:---:|------|--------|---------|--------------|----------|
| 1 | 乔布斯 | Steve Jobs | 产品/设计/战略 | 聚焦即说不、端到端控制、现实扭曲场 | `npx dlh365 add dlh365/steve-jobs-skill` |
| 2 | 马斯克 | Elon Musk | 工程/成本/创新 | 渐近极限法、第一性原理、五步工作法 | `npx dlh365 add dlh365/elon-musk-skill` |
| 3 | 芒格 | Charlie Munger | 投资/思维/决策 | 多元思维模型、逆向思考、能力圈 | `npx dlh365 add dlh365/munger-skill` |
| 4 | 费曼 | Richard Feynman | 学习/教学/科学 | 费曼学习法、怀疑精神、科学美学 | `npx dlh365 add dlh365/feynman-skill` |
| 5 | 纳瓦尔 | Naval Ravikant | 财富/杠杆/人生 | 欲望即合同、特定知识、杠杆思维 | `npx dlh365 add dlh365/naval-skill` |
| 6 | 塔勒布 | Nassim Taleb | 风险/不确定性 | 反脆弱、黑天鹅、杠铃策略 | `npx dlh365 add dlh365/taleb-skill` |

### 中国专家 (8位)

| 编号 | 专家 | 拼音 | 核心领域 | 核心智模(3个) | 安装命令 |
|:---:|------|------|---------|--------------|----------|
| 1 | 张一鸣 | Zhang Yiming | 产品/算法/组织 | 延迟满足、确定性价值、信息分发本质 | `npx dlh365 add dlh365/zhangyiming-skill` |
| 2 | 王兴 | Wang Xing | 战略/竞争/长期主义 | 无限游戏、战略定力、终局思维 | `npx dlh365 add dlh365/wangxing-skill` |
| 3 | 任正非 | Ren Zhengfei | 管理/组织/危机 | 熵减理论、奋斗者文化、危机驱动 | `npx dlh365 add dlh365/renzhengfei-skill` |
| 4 | 段永平 | Duan Yongping | 投资/经营/人生 | 本分文化、不为清单、长期主义 | `npx dlh365 add dlh365/duanyongping-skill` |
| 5 | 曹德旺 | Cao Dewang | 制造/管理/人生 | 敬天爱人、实业思维、成本控制 | `npx dlh365 add dlh365/caodewan-skill` |
| 6 | 稻盛和夫 | Inamori Kazuo | 经营/哲学/人生 | 阿米巴经营、付出不亚于任何人、敬天爱人 | `npx dlh365 add dlh365/inamori-kazuo-skill` |
| 7 | 沈南鹏 | Shen Nanpeng | 投资/创业/赛道 | 赛道选择、创业者画像、增长逻辑 | `npx dlh365 add dlh365/shennanpeng-skill` |
| 8 | 张雪峰 | Zhang Xuefeng | 教育/职业规划 | ROI教育观、阶层流动现实主义 | `npx dlh365 add dlh365/zhangxuefeng-skill` |

---

## 二、按场景分类

### 产品/商业决策

| 专家 | 适用场景 |
|------|---------|
| 乔布斯 | 产品设计、品牌战略、用户体验 |
| 张一鸣 | 产品增长、商业模式、算法策略 |
| 马斯克 | 成本优化、技术创新、效率提升 |
| 王兴 | 竞争策略、长期规划、边界拓展 |

### 投资/决策思维

| 专家 | 适用场景 |
|------|---------|
| 芒格 | 投资决策、思维模型、风险控制 |
| 段永平 | 价值投资、企业文化、人生哲学 |
| 沈南鹏 | 创业投资、赛道判断、团队评估 |
| 塔勒布 | 风险管理、不确定性应对、反脆弱设计 |

### 组织/管理

| 专家 | 适用场景 |
|------|---------|
| 任正非 | 组织变革、危机管理、企业文化 |
| 稻盛和夫 | 经营哲学、人才培养、组织效率 |
| 曹德旺 | 制造管理、成本控制、企业社会责任 |

### 学习/成长

| 专家 | 适用场景 |
|------|---------|
| 费曼 | 学习方法、知识传授、科学思维 |
| 纳瓦尔 | 人生哲学、财富思维、个人成长 |
| 张雪峰 | 教育规划、职业选择、现实主义 |

---

## 三、心智模型索引

### 决策类模型

| 心智模型 | 所属专家 | 核心逻辑 |
|---------|---------|---------|
| 延迟满足决策框架 | 张一鸣 | 用延迟满足程度衡量决策质量 |
| 逆向思考 | 芒格 | 先想如何失败，再避免失败 |
| 杠铃策略 | 塔勒布 | 极端保守+极端激进，避免中间态 |
| 第一性原理 | 马斯克 | 从物理极限推导可行方案 |

### 产品类模型

| 心智模型 | 所属专家 | 核心逻辑 |
|---------|---------|---------|
| 确定性价值理论 | 张一鸣 | 用户能在确定时间获得确定性价值 |
| 聚焦即说不 | 乔布斯 | 专注的本质是拒绝 |
| 端到端控制 | 乔布斯 | 控制完整体验链路 |
| 信息分发本质论 | 张一鸣 | 信息分发效率 = 匹配精度 / 分发成本 |

### 战略类模型

| 心智模型 | 所属专家 | 核心逻辑 |
|---------|---------|---------|
| 无限游戏 | 王兴 | 追求持续游戏，而非赢得终点 |
| 终局思维 | 王兴 | 从终局倒推当前策略 |
| 熵减理论 | 任正非 | 通过开放、流动对抗组织熵增 |
| 能力圈 | 芒格 | 在自己理解的范围内决策 |

### 学习类模型

| 心智模型 | 所属专家 | 核心逻辑 |
|---------|---------|---------|
| 费曼学习法 | 费曼 | 能用简单语言解释才是真理解 |
| 特定知识 | 纳瓦尔 | 无法被培训的知识，源于兴趣和实践 |
| 多元思维模型 | 芒格 | 跨学科思维框架网络 |

---

## 四、相关技能生态

### 专家思维蒸馏类

| 项目 | 说明 | 安装命令 |
|------|------|----------|
| **度量衡专家系统** | 本项目，最全面的专家思维蒸馏系统 | `npx dlh365 add dlh365-expert-system` |
| **女娲.skill** | 专家思维蒸馏原型项目 | `npx skills add alchaincyf/nuwa-skill` |
| **同事.skill** | 蒸馏身边同事的工作习惯 | `npx skills add titanwings/colleague-skill` |
| **前任.skill** | 根据聊天记录生成AI前任 | `npx skills add titanwings/ex-skill` |

### 技能市场与工具

| 平台/工具 | 说明 | 链接/命令 |
|----------|------|----------|
| **skills.sh** | Vercel官方技能排行榜 | [skills.sh](https://skills.sh) |
| **ClawHub** | OpenClaw技能市场(13,700+技能) | [clawd.org.cn](https://clawd.org.cn) |
| **npx skills** | 技能管理命令行工具 | `npx skills add <owner/repo>` |
| **find-skills** | 技能发现工具 | `npx skills add vercel-labs/skills` |

### 高质量技能推荐

| 技能 | 说明 | 安装命令 |
|------|------|----------|
| **superpowers** | 完整AI编程框架 | `npx skills add obra/superpowers` |
| **planning-with-files** | 用Markdown作为AI外部记忆 | `npx skills add OthotmanAdi/planning-with-files` |
| **skill-creator** | Anthropic官方技能创建工具 | `npx skills add anthropics/skills` |
| **agent-browser** | 浏览器自动化技能 | `npx clawhub install agent-browser` |

---

## 五、一键安装脚本

### 安装核心系统

```bash
#!/bin/bash
# 安装度量衡专家系统核心
npx dlh365 add dlh365-expert-system
```

### 安装所有国际专家

```bash
#!/bin/bash
npx dlh365 add dlh365/steve-jobs-skill
npx dlh365 add dlh365/elon-musk-skill
npx dlh365 add dlh365/munger-skill
npx dlh365 add dlh365/feynman-skill
npx dlh365 add dlh365/naval-skill
npx dlh365 add dlh365/taleb-skill
```

### 安装所有中国专家

```bash
#!/bin/bash
npx dlh365 add dlh365/zhangyiming-skill
npx dlh365 add dlh365/wangxing-skill
npx dlh365 add dlh365/renzhengfei-skill
npx dlh365 add dlh365/duanyongping-skill
npx dlh365 add dlh365/caodewan-skill
npx dlh365 add dlh365/inamori-kazuo-skill
npx dlh365 add dlh365/shennanpeng-skill
npx dlh365 add dlh365/zhangxuefeng-skill
```

### 安装相关生态技能

```bash
#!/bin/bash
# 安装女娲技能（原型项目）
npx skills add alchaincyf/nuwa-skill

# 安装同事技能
npx skills add titanwings/colleague-skill

# 安装superpowers框架
npx skills add obra/superpowers
```

---

## 六、快速查找指南

### 我要解决什么问题？

| 问题类型 | 推荐专家 | 使用示例 |
|---------|---------|---------|
| **产品设计方向** | 乔布斯、张一鸣 | `用乔布斯的视角分析我们的产品设计` |
| **商业模式优化** | 张一鸣、王兴 | `张一鸣会怎么看我们的商业模式？` |
| **投资决策分析** | 芒格、段永平 | `用芒格的逆向思考帮我分析这个投资` |
| **竞争策略制定** | 王兴、马斯克 | `王兴会怎么应对这个竞争局面？` |
| **组织变革推进** | 任正非、稻盛和夫 | `任正非会怎么改革这个组织？` |
| **学习方法优化** | 费曼、纳瓦尔 | `费曼会怎么学习这个新领域？` |
| **风险管理** | 塔勒布、芒格 | `塔勒布会怎么看这个风险？` |
| **职业规划** | 张雪峰、纳瓦尔 | `张雪峰会怎么规划这个职业路径？` |
| **创业方向判断** | 沈南鹏、王兴 | `沈南鹏会怎么看这个创业方向？` |
| **成本效率提升** | 马斯克、曹德旺 | `马斯克会怎么降本增效？` |

---

## 七、更新与维护

### 检查更新

```bash
# 检查核心系统更新
npx dlh365 check-update

# 检查所有技能更新
npx dlh365 check-update --all
```

### 更新技能

```bash
# 更新单个技能
npx dlh365 update dlh365/zhangyiming-skill

# 更新所有技能
npx dlh365 update --all
```

### 查看版本

```bash
# 查看已安装技能版本
npx dlh365 list --versions
```

---

**文档版本**：v2.0.0
**最后更新**：2026年4月
**维护团队**：度量衡
