#!/usr/bin/env python3

from __future__ import annotations

import re
from typing import Any

from common import trim_string


BASE_DELIVERY_INSTRUCTIONS = {
    "narration": "旁白叙述，语气中立清晰",
    "inner_monologue": "内心独白，声音更轻、更近，语气克制，贴近呼吸感，略慢",
}

PHONE_SERVICE_ROLE_HINTS = {
    "customer_service": ["客服", "坐席", "工号", "customer_service", "service_agent", "support_agent"],
    "user": ["用户", "客户", "顾客", "投诉人", "来电人", "caller", "user"],
}


def sanitize_spoken_text(text: Any) -> str:
    value = str(text or "")
    value = re.sub(r"\r", " ", value)
    value = re.sub(r"\\+[nrt]", " ", value)
    value = re.sub(r"\\+", " ", value)
    value = re.sub(r"[`*_#~^]+", " ", value)
    value = re.sub(r"[<>\[\]{}]", " ", value)
    value = re.sub(r"[|]", " ", value)
    value = re.sub(r"[•●▪◦◆◇□■▲▼※★☆☞☛→←↑↓]", " ", value)
    value = re.sub(r"-{3,}", "，", value)
    value = re.sub(r"[—–]{2,}", "，", value)
    value = re.sub(r"\.{3,}", "……", value)
    value = re.sub(r"…{3,}", "……", value)
    value = re.sub(r"\s+", " ", value).strip()
    value = re.sub(r"\s*([，。！？；：、])", r"\1", value)
    value = re.sub(r"([（【《“「『])\s+", r"\1", value)
    value = re.sub(r"\s+([）】》”」』])", r"\1", value)
    return value.strip()


def sanitize_instruction_text(text: Any) -> str:
    value = sanitize_spoken_text(text)
    value = re.sub(r"^[，。！？；：、\-\s]+", "", value)
    value = re.sub(r"[，。！？；：、\-\s]+$", "", value)
    return value.strip()


def split_instruction_value(value: Any) -> list[str]:
    text = sanitize_instruction_text(value)
    if not text:
        return []
    parts = [segment.strip() for segment in re.split(r"[，,、；;]", text) if segment.strip()]
    return parts


def contains_any(text: str, needles: list[str]) -> bool:
    return any(needle and needle in text for needle in needles)


def looks_like_solution_text(text: str) -> bool:
    return contains_any(
        text,
        ["申请", "安排", "保障", "催促", "处理", "解决", "退还", "补偿", "备注", "标记"],
    ) or ("我会" in text or "我可以" in text)


def split_spoken_units(text: str) -> list[str]:
    clean = sanitize_spoken_text(text)
    if not clean:
        return []

    units = [part.strip() for part in re.findall(r"[^。！？!?；;]+[。！？!?；;]?", clean) if part.strip()]
    # If a long turn has only one sentence, split at comma-level clauses so
    # inline context can follow the actual emotional turn instead of only the
    # first few characters.
    if len(units) <= 1 and len(clean) > 48:
        comma_units = [part.strip() for part in re.findall(r"[^，,。！？!?；;]+[，,。！？!?；;]?", clean) if part.strip()]
        if len(comma_units) > 1:
            return comma_units
    return units or [clean]


class InstructionBuilder:
    def __init__(
        self,
        *,
        max_length: int = 200,
        input_max_length: int = 1000,
        separator: str = "，",
        truncation_suffix: str = "...",
        enable_expression_enrichment: bool = True,
        max_inline_cues: int = 4,
    ) -> None:
        self.max_length = max_length
        self.input_max_length = input_max_length
        self.separator = separator
        self.truncation_suffix = truncation_suffix
        self.enable_expression_enrichment = enable_expression_enrichment
        self.max_inline_cues = max(1, int(max_inline_cues))

    def contains_instruction(self, parts: list[str], instruction: str) -> bool:
        target = sanitize_instruction_text(instruction).lower()
        if not target:
            return False
        return any(
            existing.lower() == target or existing.lower() in target or target in existing.lower()
            for existing in parts
        )

    def dedupe_parts(self, parts: list[str]) -> list[str]:
        merged: list[str] = []
        for part in parts:
            clean_part = sanitize_instruction_text(part)
            if not clean_part:
                continue
            if not self.contains_instruction(merged, clean_part):
                merged.append(clean_part)
        return merged

    def merge_instruction_parts(self, *parts: str | None) -> str:
        flattened: list[str] = []
        for value in parts:
            if not trim_string(value):
                continue
            flattened.extend(split_instruction_value(value))
        return self.separator.join(self.dedupe_parts(flattened))

    def parse_structured_global_instruction(self, global_instruction: str) -> dict[str, list[str]] | None:
        if not re.search(r"[｜|]", global_instruction) or not re.search(r"[:=：]", global_instruction):
            return None

        parsed = {
            "scene": [],
            "narration": [],
            "dialogue": [],
            "customer_service": [],
            "user": [],
            "shared": [],
        }

        matched = False
        chunks = [part.strip() for part in re.split(r"[｜|]", global_instruction) if part.strip()]
        for chunk in chunks:
            match = re.match(r"^(场景|旁白|对白|客服|坐席|用户|客户|共享|通用)\s*[:=：]\s*(.+)$", chunk)
            if not match:
                parsed["shared"].extend(split_instruction_value(chunk))
                continue

            matched = True
            key, raw_value = match.group(1), match.group(2)
            values = split_instruction_value(raw_value)
            if key == "场景":
                parsed["scene"].extend(values)
            elif key == "旁白":
                parsed["narration"].extend(values)
            elif key == "对白":
                parsed["dialogue"].extend(values)
            elif key in {"客服", "坐席"}:
                parsed["customer_service"].extend(values)
            elif key in {"用户", "客户"}:
                parsed["user"].extend(values)
            else:
                parsed["shared"].extend(values)

        return parsed if matched else None

    def parse_legacy_global_instruction(self, global_instruction: str) -> dict[str, list[str]]:
        normalized = sanitize_spoken_text(global_instruction)
        scene_match = re.search(r"整体保持([^，。]+)", normalized)
        narration_match = re.search(r"旁白([^，。]+)", normalized)
        dialogue_match = re.search(r"(?:人物对白|角色对白|对白)([^，。]+)", normalized)
        customer_service_match = re.search(r"(?:客服|坐席)的?([^和，。；;]+)", normalized)
        user_match = re.search(r"(?:用户|客户|顾客)的?([^，。；;]+)", normalized)

        scene = split_instruction_value(f"保持{scene_match.group(1)}") if scene_match else []
        narration = split_instruction_value(narration_match.group(1)) if narration_match else []
        dialogue = split_instruction_value(dialogue_match.group(1)) if dialogue_match else []
        customer_service = split_instruction_value(customer_service_match.group(1)) if customer_service_match else []
        user = split_instruction_value(user_match.group(1)) if user_match else []
        if ("客服" in normalized or "坐席" in normalized) and re.search(r"专业|礼貌", normalized):
            customer_service.extend(["专业礼貌"])

        residual = []
        for part in re.split(r"[，。]", normalized):
            clean_part = part.strip()
            if not clean_part:
                continue
            if clean_part.startswith("整体保持") or clean_part.startswith("旁白") or re.match(r"^(人物对白|角色对白|对白)", clean_part):
                continue
            if re.search(r"(客服|坐席|用户|客户|顾客)的", clean_part):
                continue
            if re.search(r"专业|礼貌", clean_part) and ("客服" in normalized or "坐席" in normalized):
                continue
            residual.append(clean_part)

        return {
            "scene": scene,
            "narration": narration,
            "dialogue": dialogue,
            "customer_service": self.dedupe_parts(customer_service),
            "user": self.dedupe_parts(user),
            "shared": self.dedupe_parts(residual),
        }

    def resolve_applicable_global_instructions(
        self,
        *,
        speaker: str,
        delivery_mode: str,
        global_instruction: str,
    ) -> list[str]:
        effective = sanitize_instruction_text(global_instruction)
        if not effective:
            return []

        structured = self.parse_structured_global_instruction(effective)
        if structured:
            role_specific = structured["narration"] if speaker == "narrator" or delivery_mode == "narration" else structured["dialogue"]
            speaker_text = speaker.casefold()
            if contains_any(speaker_text, PHONE_SERVICE_ROLE_HINTS["customer_service"]):
                role_specific = role_specific + structured.get("customer_service", [])
            elif contains_any(speaker_text, PHONE_SERVICE_ROLE_HINTS["user"]):
                role_specific = role_specific + structured.get("user", [])
            return self.dedupe_parts(structured["shared"] + structured["scene"] + role_specific)

        legacy = self.parse_legacy_global_instruction(effective)
        role_specific = legacy["narration"] if speaker == "narrator" or delivery_mode == "narration" else legacy["dialogue"]
        speaker_text = speaker.casefold()
        if contains_any(speaker_text, PHONE_SERVICE_ROLE_HINTS["customer_service"]):
            role_specific = role_specific + legacy.get("customer_service", [])
        elif contains_any(speaker_text, PHONE_SERVICE_ROLE_HINTS["user"]):
            role_specific = role_specific + legacy.get("user", [])
        return self.dedupe_parts(legacy["shared"] + legacy["scene"] + role_specific)

    def detect_role_kind(self, segment: dict[str, Any]) -> str:
        context = " ".join(
            [
                trim_string(segment.get("speaker")),
                trim_string(segment.get("character_name")),
                trim_string(segment.get("character_instruction")),
            ]
        ).casefold()
        if contains_any(context, PHONE_SERVICE_ROLE_HINTS["customer_service"]):
            return "customer_service"
        if contains_any(context, PHONE_SERVICE_ROLE_HINTS["user"]):
            return "user"
        return "generic"

    def build_unit_cue(
        self,
        *,
        segment: dict[str, Any],
        unit_text: str,
        unit_index: int,
        total_units: int,
        inline_instruction: str,
    ) -> str:
        role_kind = self.detect_role_kind(segment)
        text = sanitize_spoken_text(unit_text)
        inline = sanitize_instruction_text(inline_instruction)
        cues: list[str] = []

        if unit_index == 0 and inline:
            cues.append(inline)

        if role_kind == "customer_service":
            if unit_index == 0:
                cues.append("像真人电话里说，别播音腔")
            if contains_any(text, ["您好", "请问", "我是工号", "客服中心"]):
                cues.append("自然微笑，开场别端着")
            elif contains_any(text, ["抱歉", "不好", "失望", "耽误"]):
                cues.append("歉意要具体，轻轻停顿")
            elif contains_any(text, ["理解", "明白", "您说得对", "确实"]):
                cues.append("先接住情绪，语气放软")
            elif contains_any(text, ["查", "核实", "联系", "确认", "稍等"]):
                cues.append("转办事口吻，清楚利落")
            elif contains_any(text, ["系统显示", "根据", "反馈", "预计", "记录"]):
                cues.append("解释放慢，信息说清")
            elif looks_like_solution_text(text):
                cues.append("给方案时更有担当")
            elif contains_any(text, ["工单", "编号", "TS", "202"]):
                cues.append("编号读慢，逐字清楚")
            elif contains_any(text, ["感谢", "再见", "祝您"]):
                cues.append("收尾放轻，自然礼貌")
            elif total_units > 1:
                cues.append("顺着上一句自然转折")
        elif role_kind == "user":
            if unit_index == 0:
                cues.append("真实投诉电话口吻，别一直同一种怒气")
            if contains_any(text, ["离谱", "不满意", "不需要", "完全", "干什么", "影响"]):
                cues.append("火气上来，重点词加重")
            elif contains_any(text, ["几点", "是不是", "如果", "为什么", "？", "?"]):
                cues.append("追问上扬，节奏更紧")
            elif contains_any(text, ["现在", "今天", "上午", "下午", "三点", "六点", "等"]):
                cues.append("强调时间，语速略快")
            elif contains_any(text, ["手机号", "订单", "工单号"]):
                cues.append("不情愿但信息说清")
            elif contains_any(text, ["好", "行", "先这样"]):
                cues.append("压着不满，短促收尾")
            elif total_units > 1:
                cues.append("后半句情绪继续顶上来")
        else:
            if unit_index == 0 and inline:
                cues.append("口语自然，不要平铺直叙")
            elif total_units > 1:
                cues.append("稍停，承接上一句")

        merged = self.merge_instruction_parts(*cues)
        if len(merged) <= 42:
            return merged
        short_parts = split_instruction_value(merged)[:3]
        return self.separator.join(short_parts)

    def build_enriched_dialogue_input_text(
        self,
        *,
        clean_text: str,
        inline_instruction: str,
        raw_text: str,
        segment: dict[str, Any],
        fallback_input_text: str,
    ) -> str:
        if not self.enable_expression_enrichment:
            return fallback_input_text
        if trim_string(segment.get("delivery_mode")) != "dialogue":
            return fallback_input_text

        units = split_spoken_units(clean_text)
        if not units:
            return fallback_input_text
        if len(units) == 1 and not trim_string(inline_instruction) and self.detect_role_kind(segment) == "generic":
            return fallback_input_text

        max_cues = min(self.max_inline_cues, len(units))
        for cue_limit in range(max_cues, 0, -1):
            rendered: list[str] = []
            used_cues: list[str] = []
            for unit_index, unit in enumerate(units):
                cue = ""
                if unit_index < cue_limit:
                    cue = self.build_unit_cue(
                        segment=segment,
                        unit_text=unit,
                        unit_index=unit_index,
                        total_units=len(units),
                        inline_instruction=inline_instruction,
                    )
                    if self.contains_instruction(used_cues, cue):
                        cue = ""
                if cue:
                    used_cues.append(cue)
                    rendered.append(f"（{cue}）{unit}")
                else:
                    rendered.append(unit)

            candidate = "".join(rendered)
            if len(candidate) <= self.input_max_length:
                return candidate

        return fallback_input_text

    def build_tts_input_text(
        self,
        *,
        clean_text: str,
        inline_instruction: str,
        raw_text: str,
        segment: dict[str, Any] | None = None,
    ) -> str:
        safe_clean_text = sanitize_spoken_text(clean_text)
        safe_inline_instruction = sanitize_instruction_text(inline_instruction)
        normalized_raw = sanitize_spoken_text(raw_text)
        if not safe_inline_instruction:
            fallback_input_text = safe_clean_text
        elif re.match(r"^[（(][^）)]+[）)]", normalized_raw):
            fallback_input_text = re.sub(r"^[（(][^）)]+[）)]", f"（{safe_inline_instruction}）", normalized_raw, count=1)
        else:
            fallback_input_text = f"（{safe_inline_instruction}）{safe_clean_text}"

        if not segment:
            return fallback_input_text

        return self.build_enriched_dialogue_input_text(
            clean_text=safe_clean_text,
            inline_instruction=safe_inline_instruction,
            raw_text=normalized_raw,
            segment=segment,
            fallback_input_text=fallback_input_text,
        )

    def build_dynamic_turn_instruction(
        self,
        *,
        segment: dict[str, Any],
        clean_text: str,
        inline_instruction: str,
    ) -> str:
        if trim_string(segment.get("delivery_mode")) != "dialogue":
            return ""

        role_kind = self.detect_role_kind(segment)
        text = sanitize_spoken_text(clean_text)
        inline = sanitize_instruction_text(inline_instruction)
        cues: list[str] = []

        if role_kind == "customer_service":
            cues.append("电话客服真人感，避免播音腔和机械客服腔")
            if contains_any(text, ["您好", "请问", "客服中心"]):
                cues.append("开场有微笑感，礼貌但不端")
            if contains_any(text, ["抱歉", "失望", "耽误"]):
                cues.append("歉意真诚，句尾轻落")
            if contains_any(text, ["理解", "明白", "您说得对", "确实"]):
                cues.append("先共情再推进")
            if contains_any(text, ["查", "核实", "联系", "确认", "稍等"]):
                cues.append("办事口吻清楚，有短暂停顿")
            if contains_any(text, ["系统显示", "反馈", "预计", "记录"]):
                cues.append("解释信息时放慢")
            if looks_like_solution_text(text):
                cues.append("给方案时语气更确定")
        elif role_kind == "user":
            cues.append("真实投诉电话情绪，不要全程同一强度")
            if contains_any(text, ["离谱", "不满意", "不需要", "完全", "影响"]):
                cues.append("不满更外露，关键词加重")
            if contains_any(text, ["几点", "是不是", "如果", "为什么", "？", "?"]):
                cues.append("追问更紧，尾音上扬")
            if contains_any(text, ["现在", "今天", "上午", "下午", "三点", "六点", "等"]):
                cues.append("时间压力读出来")
            if contains_any(text, ["好", "行", "先这样"]):
                cues.append("短促收尾，仍带余怒")
        elif inline:
            cues.append(f"本句{inline}")

        if inline and not self.contains_instruction(cues, inline):
            cues.append(inline)
        return self.merge_instruction_parts(*cues)

    def smart_truncate(self, text: str) -> str:
        if len(text) <= self.max_length:
            return text

        punct_matches = list(re.finditer(r"[，。！？,\.!?；;]", text))
        for match in reversed(punct_matches):
            if match.start() < self.max_length - len(self.truncation_suffix):
                return text[: match.start() + 1] + self.truncation_suffix

        safe_zone_start = max(0, self.max_length - 30)
        safe_zone_end = max(0, self.max_length - len(self.truncation_suffix))
        for index in range(safe_zone_end, safe_zone_start - 1, -1):
            if text[index : index + 1] in {" ", "，", "。", "、"}:
                return text[: index + 1] + self.truncation_suffix

        return text[: safe_zone_end] + self.truncation_suffix

    def build_for_segment(
        self,
        segment: dict[str, Any],
        *,
        role_stable_instruction: str = "",
        global_instruction: str = "",
    ) -> dict[str, str | int]:
        clean_text = sanitize_spoken_text(
            segment.get("clean_text")
            or segment.get("tts_input_text")
            or segment.get("raw_text")
        )
        inline_instruction = sanitize_instruction_text(segment.get("inline_instruction"))
        scene_instruction = sanitize_instruction_text(segment.get("scene_instruction"))
        role_stable = sanitize_instruction_text(role_stable_instruction)
        segment_character_instruction = sanitize_instruction_text(segment.get("character_instruction"))
        delivery_mode = trim_string(segment.get("delivery_mode")) or "dialogue"

        tts_input_text = self.build_tts_input_text(
            clean_text=clean_text,
            inline_instruction=inline_instruction,
            raw_text=trim_string(segment.get("raw_text")) or clean_text,
            segment=segment,
        )
        dynamic_turn_instruction = self.build_dynamic_turn_instruction(
            segment=segment,
            clean_text=clean_text,
            inline_instruction=inline_instruction,
        )
        effective_character_instruction = self.merge_instruction_parts(
            role_stable,
            segment_character_instruction,
        )

        parts: list[str] = []
        base_instruction = BASE_DELIVERY_INSTRUCTIONS.get(delivery_mode, "")
        if base_instruction:
            parts.append(base_instruction)
        if scene_instruction and not self.contains_instruction(parts, scene_instruction):
            parts.append(scene_instruction)
        if dynamic_turn_instruction and not self.contains_instruction(parts, dynamic_turn_instruction):
            parts.append(dynamic_turn_instruction)
        if role_stable and not self.contains_instruction(parts, role_stable):
            parts.append(role_stable)
        if segment_character_instruction and not self.contains_instruction(parts, segment_character_instruction):
            parts.append(segment_character_instruction)

        for global_part in self.resolve_applicable_global_instructions(
            speaker=trim_string(segment.get("speaker")),
            delivery_mode=delivery_mode,
            global_instruction=global_instruction,
        ):
            if not self.contains_instruction(parts, global_part):
                parts.append(global_part)

        combined_instruction = self.separator.join(self.dedupe_parts(parts))
        if len(combined_instruction) > self.max_length:
            combined_instruction = self.smart_truncate(combined_instruction)

        return {
            "clean_text": clean_text,
            "tts_input_text": tts_input_text,
            "inline_instruction": inline_instruction,
            "scene_instruction": scene_instruction,
            "role_stable_instruction": role_stable,
            "character_instruction": effective_character_instruction,
            "expression_instruction": dynamic_turn_instruction,
            "instruction": combined_instruction,
            "instruction_length": len(combined_instruction),
        }
