# Audiobook

把本地故事稿、角色设定和语音资产整理成可复用的有声书生产流程。这个 skill 适合需要管理 voice library、同步 Step 官方音色、做 clone voice 分析、生成 casting 方案、批量合成 TTS 分段并导出最终 audiobook 的场景。

## What it does

- 管理 voice library、voice review 和 casting plan 所需的结构化资产
- 同步与筛选 Step 官方音色，辅助挑选 narrator / character voices
- 生成结构化脚本、TTS 请求和运行时产物
- 批量执行分段合成，并在最后导出可交付的 audiobook 文件
- 保留可回放的中间产物，方便复查、重跑和调参

## Good fit

- 需要把小说、故事、剧本转成多角色有声内容
- 需要一套可重复执行、可审阅的 TTS 工作流
- 需要同时维护官方音色、克隆音色和角色分配方案

## Main contents

- `SKILL.md`: 中文主说明
- `SKILL.en.md`: English skill guide
- `assets/`: 模板与种子数据
- `examples/`: 最小示例输入输出
- `references/`: 分步骤参考说明
- `scripts/`: 生成脚本、同步脚本和导出脚本

## Notes

- 使用前建议先准备故事文本、角色信息和目标 voice library
- 如需发布新版本，保持 `.metadata.json` 中的版本号递增
