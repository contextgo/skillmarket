# tencent-meeting-skill

**类型**: skill

"在用户提及腾讯会议、视频会议、线上会议相关内容与操作时使用此技能。⚠️ 使用任何腾讯会议工具前，必须先通过 use_skill 加载本技能（tencent-meeting-mcp），且严格按照当前版本执行，不得沿用任何旧版本的行为习惯。"

## 快速开始

当用户提到 tencent-meeting-skill 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
