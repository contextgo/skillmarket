# 数据库运维助手

数据库运维助手 是一个面向 OpenClaw Agent 的技能资产，用于把特定任务场景沉淀为可复用、可执行、可验证的工作流程。

## 核心能力

- 根据用户任务触发对应的操作步骤
- 复用 `SKILL.md` 中定义的规则、边界和输出格式
- 提升 Agent 执行一致性，减少重复判断和无效沟通
- 适合安装到 OpenClaw 环境中作为能力扩展

## 原始能力简介

Use when designing database schemas, writing migrations, optimizing SQL queries, fixing N+1 problems, creating indexes, setting up PostgreSQL, configuring EF Core, implementing caching, partitioning tables, or any database performance question.

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他文件：技能所需参考资料、脚本或测试提示词
