# 智林记账 App 功能说明

## 技术栈

- **前端**：Streamlit（Python Web 框架，手机浏览器原生体验）
- **数据库**：SQLite（轻量、无需额外部署）
- **图表**：Plotly（交互式图表）
- **部署**：pip 安装 or Docker

---

## 功能页面

### 1. 记一笔

- **类型切换**：支出 / 收入（Segmented Control）
- **日期选择**：默认当天，可修改
- **金额输入**：数字键盘，支持小数
- **分类选择**：下拉菜单，图标 + 名称
- **备注**：文本框，最多 200 字
- **保存**：保存后自动清空表单

**默认支出分类**（10个）：
🍜餐饮、🚗交通、🛒购物、🏠居住、💊医疗、📚教育、🎮娱乐、📱通讯、🔀转账支出、❓其他支出

**默认收入分类**（5个）：
💰工资、🎁奖金、📈投资收益、🔄转账收入、💵其他收入

---

### 2. 历史记录

- **时间筛选**：年份 + 月份下拉选择
- **汇总显示**：当月收入合计、支出合计
- **流水列表**：按日期倒序，每条显示：
  - 分类图标 + 名称
  - 日期
  - 金额（收入绿色、支出红色）
  - 备注
  - 删除按钮

---

### 3. 月度报表

- **时间筛选**：年份 + 月份下拉选择
- **核心指标**：收入、支出、结余（结余为负标红）
- **饼图**：支出分类占比（Plotly Pie，环形图）
- **条形图**：各分类金额横向柱状图

---

### 4. 设置

- **修改密码**：需输入当前密码 + 新密码 + 确认密码
- **分类管理**：只读展示收入/支出分类列表

---

## 数据库结构

```sql
-- 分类表
CREATE TABLE categories (
    id INTEGER PRIMARY KEY,
    name TEXT,
    icon TEXT,
    type TEXT -- 'income' or 'expense'
);

-- 记账记录表
CREATE TABLE records (
    id INTEGER PRIMARY KEY,
    date TEXT,        -- 'YYYY-MM-DD'
    type TEXT,        -- 'income' or 'expense'
    amount REAL,
    category_id INTEGER,
    note TEXT,
    created_at TEXT
);

-- 设置表
CREATE TABLE settings (
    key TEXT PRIMARY KEY,
    value TEXT
);
```

---

## 安全机制

- 访问密码保护（SQLite 存储，加密可扩展）
- 默认密码：123456
- 密码在设置页修改
