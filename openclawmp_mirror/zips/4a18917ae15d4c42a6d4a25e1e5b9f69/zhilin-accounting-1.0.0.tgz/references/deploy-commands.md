# 各平台部署命令参考

---

## 方式一：pip 直接运行（Ubuntu/Debian 推荐）

```bash
# 安装依赖
pip3 install streamlit pandas plotly

# 初始化数据库
python3 init_db.py

# 启动服务
streamlit run app.py --server.port 8501 --server.address 0.0.0.0 --server.headless true
```

---

## 方式二：deploy.sh 一键脚本（Ubuntu/Debian）

```bash
scp accounting_app.tar.gz root@YOUR_SERVER_IP:/opt/
ssh root@YOUR_SERVER_IP
cd /opt
tar -xzf accounting_app.tar.gz
cd accounting_app
chmod +x deploy.sh && ./deploy.sh
```

---

## 方式三：Docker 部署（跨平台）

```bash
# 构建镜像
docker build -t accounting-app .

# 运行容器
docker run -d \
  --name accounting \
  -p 8501:8501 \
  -v $(pwd)/data:/app/data \
  accounting-app
```

---

## 方式四：Docker Compose

```bash
docker-compose up -d
```

---

## Nginx 反向代理（域名访问）

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:8501;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

---

## 进程管理

```bash
# 查看进程
ps aux | grep streamlit

# 停止
pkill -f streamlit

# 重启
pkill -f streamlit && nohup streamlit run app.py --server.port 8501 --server.address 0.0.0.0 > app.log 2>&1 &

# 查看日志
tail -f /opt/accounting_app/app.log
```

---

## 防火墙设置（Ubuntu）

```bash
# 开放端口
ufw allow 8501/tcp

# 重启防火墙
ufw reload
```

---

## 开机自启（systemd）

```ini
# /etc/systemd/system/accounting.service
[Unit]
Description=Zhilin Accounting App
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=/opt/accounting_app
ExecStart=/usr/bin/python3 -m streamlit run app.py --server.port 8501 --server.address 0.0.0.0
Restart=always

[Install]
WantedBy=multi-user.target
```

```bash
systemctl enable accounting
systemctl start accounting
systemctl status accounting
```
