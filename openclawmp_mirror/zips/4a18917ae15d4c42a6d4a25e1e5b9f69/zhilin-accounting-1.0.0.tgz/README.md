# 💰 智林记账 App 一键部署

帮用户快速搭建一个私人记账 Web 应用，并部署到云服务器。手机浏览器直接访问，体验等同于原生 App。

## 功能

- 零基础 5 分钟搭建完成
- 收支记录 + 分类 + 历史流水 + 月度报表
- 支持 Docker 部署
- 默认访问密码保护

## 快速开始

1. 生成代码包：`tar -czf accounting_app.tar.gz accounting_app/`
2. 上传：`scp accounting_app.tar.gz root@<服务器IP>:/opt/`
3. 部署：`cd /opt && tar -xzf accounting_app.tar.gz && cd accounting_app && ./deploy.sh`
4. 访问：`http://<服务器IP>:8501`，默认密码 `123456`

## 技术栈

Streamlit + SQLite + Plotly，支持 pip 和 Docker 两种部署方式。
