---
name: zhilin-accounting
description: 一键为用户搭建个人记账 Web App 并部署到云服务器的完整工作流。从需求确认、代码生成、本地打包到服务器部署，全部自动化。适用于想快速拥有一个私人记账工具的用户。
tags: [accounting, streamlit, deployment, web-app, sqlite]
category: productivity
semver: 1.0.0
---

# 🐚 智林记账 App 快速部署 Skill

帮助用户搭建并部署一个私人记账 Web 应用（Streamlit + SQLite），运行在云服务器上，手机浏览器直接访问。

---

## 📦 Skill 包含什么

- **accounting_app.tar.gz** — 完整应用代码包（含 app.py、database.py、requirements.txt、deploy.sh、Dockerfile）
- **部署流程** — 服务器连接 → 上传 → 解压 → 一键部署 → 访问验证

---

## ⚡ 执行流程（4 步完成）

### Step 1：确认基本信息

向用户确认以下内容（直接默认即可，也可以跳过用 [] 里的建议）：

| 问题 | 默认建议 |
|------|---------|
| 功能版本 | 基础版（收支记录 + 分类 + 历史 + 月报） |
| 服务器系统 | Ubuntu / Debian |
| 是否有域名 | 否（用 IP:8501 访问）|

> 如果用户选进阶版（预算/多账户/图表/导出），告知需要扩展 `database.py` 和 `app.py`，当前先按基础版执行。

### Step 2：生成代码包

在本地生成压缩包（已预先准备好，直接打包）：

```bash
tar -czf accounting_app.tar.gz accounting_app/
```

### Step 3：上传并部署

```bash
# 上传压缩包到服务器
scp accounting_app.tar.gz root@<服务器IP>:/opt/

# SSH 登录并部署
ssh root@<服务器IP>
cd /opt
tar -xzf accounting_app.tar.gz
cd accounting_app
chmod +x deploy.sh && ./deploy.sh
```

### Step 4：验证访问

告知用户访问地址：
```
http://<服务器IP>:8501
默认密码：123456
```

---

## 🧩 代码包结构

```
accounting_app/
├── app.py              # Streamlit 主应用
├── database.py         # SQLite 数据库操作
├── init_db.py          # 数据库初始化脚本
├── requirements.txt    # Python 依赖
├── deploy.sh          # 一键部署脚本（Ubuntu/Debian）
├── Dockerfile          # Docker 部署
├── docker-compose.yml  # Docker Compose 部署
└── README.md           # 使用说明
```

---

## 🔑 默认配置

- **访问密码**：`123456`（用户可在 App 内设置页修改）
- **数据库**：SQLite，存储在 `data/accounting.db`
- **端口**：8501
- **分类预置**：15 个常用收支分类

---

## 📱 App 功能清单

| 页面 | 功能 |
|------|------|
| ✏️ 记一笔 | 支出/收入 + 日期 + 分类 + 金额 + 备注 |
| 📋 历史记录 | 按年月筛选，支持删除记录 |
| 📊 月度报表 | Pie 饼图 + Bar 条形图，支出构成分析 |
| ⚙️ 设置 | 修改访问密码，查看分类列表 |

---

## 🆕 进阶功能（可选扩展）

如用户有需要，可扩展以下功能：

1. **多账户** — 现金/支付宝/微信/银行卡分别记账
2. **预算管理** — 月度预算设置，超支预警
3. **数据导出** — 导出 CSV/Excel
4. **数据可视化增强** — 趋势图、对比图
5. **多用户** — 不同用户独立账本

---

## ⚠️ 常见部署问题

### 端口被占用

```bash
# 查找占用进程
lsof -i :8501
# 杀掉后重开
pkill -f streamlit && ./deploy.sh
```

### pip 安装失败

```bash
# 升级 pip
pip3 install --upgrade pip
# 再装依赖
pip3 install -r requirements.txt
```

### Streamlit 启动报错

```bash
# 查看日志
cat /opt/accounting_app/app.log
```

### 域名访问

在 Nginx 中添加反向代理：

```nginx
server {
    listen 80;
    server_name your-domain.com;
    location / {
        proxy_pass http://127.0.0.1:8501;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

---

## 📁 参考文件

- `references/app-features.md` — App 完整功能说明
- `references/deploy-commands.md` — 各平台部署命令参考
