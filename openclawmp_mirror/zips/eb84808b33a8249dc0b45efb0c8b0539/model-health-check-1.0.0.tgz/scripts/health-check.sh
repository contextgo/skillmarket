#!/bin/bash
# Model Health Check: Gateway 稳定性自动巡检
# 每 60 秒检测 Gateway 进程和 API 状态，异常时自动重启

GATEWAY_CMD="openclaw gateway"
HEALTH_URL="http://localhost:3578/health"
LOG_FILE="/tmp/model-health-check.log"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

log "🏥 Health Check Monitor Started"

while true; do
    # 1. 检查 Gateway 进程
    if ! pgrep -f "openclaw" > /dev/null 2>&1; then
        log "❌ Gateway process not found. Restarting..."
        $GATEWAY_CMD start >> "$LOG_FILE" 2>&1
        sleep 5
        if pgrep -f "openclaw" > /dev/null 2>&1; then
            log "✅ Gateway restarted successfully"
        else
            log "⚠️ Gateway restart failed"
        fi
        sleep 55
        continue
    fi

    # 2. 检查 API 健康
    HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 --max-time 10 "$HEALTH_URL" 2>/dev/null)
    if [ "$HTTP_CODE" != "200" ]; then
        log "❌ API health check failed (HTTP $HTTP_CODE). Restarting..."
        $GATEWAY_CMD restart >> "$LOG_FILE" 2>&1
        sleep 10
        NEW_CODE=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 5 --max-time 10 "$HEALTH_URL" 2>/dev/null)
        if [ "$NEW_CODE" = "200" ]; then
            log "✅ Gateway recovered (HTTP $NEW_CODE)"
        else
            log "⚠️ Gateway still unhealthy after restart (HTTP $NEW_CODE)"
        fi
    fi

    sleep 60
done
