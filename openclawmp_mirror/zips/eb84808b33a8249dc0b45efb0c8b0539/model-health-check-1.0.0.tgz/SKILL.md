---
name: model-health-check
description: "AI 模型/Gateway 稳定性自动巡检与自愈：每 60 秒检测 Gateway 进程和 API 响应状态，异常时自动重启恢复。解决 AI 助手掉线、模型 API 超时、进程崩溃后无人发现的问题。触发词：模型巡检、Gateway 监控、自动重启、稳定性检查、health check。"
---

# Model Health Check · 模型稳定性自动巡检

## 解决什么问题
Gateway 进程崩溃、模型 API 超时、网络波动 → AI 助手"失联"，发现时已经错过大量消息。

## 工作原理
LaunchAgent 每 60 秒执行巡检：
1. **进程检测**：Gateway 进程是否存活
2. **API 探活**：向本地 API 发送健康检查请求
3. **自动恢复**：检测异常时自动重启 Gateway
4. **日志记录**：所有操作记录到日志文件

## 安装

### 方式 A：使用 fix-my-claw（推荐）
```bash
# 安装 fix-my-claw
pip install fix-my-claw

# 部署 LaunchAgent
cp scripts/com.user.fix-my-claw.plist ~/Library/LaunchAgents/
# 编辑 plist 中的路径指向你的 fix-my-claw 安装位置
launchctl load ~/Library/LaunchAgents/com.user.fix-my-claw.plist
```

### 方式 B：使用独立脚本
```bash
cp scripts/health-check.sh ~/bin/
chmod +x ~/bin/health-check.sh
cp scripts/com.user.model-health-check.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.user.model-health-check.plist
```

### 验证
```bash
# 检查巡检状态
launchctl list | grep -E "fix-my-claw|model-health"
# 查看日志
tail -20 /tmp/fix-my-claw-stdout.log
```

## 巡检逻辑
```
每 60 秒循环：
  1. pgrep openclaw → 进程存活？
     - 否 → openclaw gateway start → 记录重启
  2. curl localhost:3578/health → API 正常？
     - 否 → openclaw gateway restart → 记录重启
  3. 一切正常 → 静默等待下一轮
```

## 卸载
```bash
launchctl unload ~/Library/LaunchAgents/com.user.fix-my-claw.plist
rm ~/Library/LaunchAgents/com.user.fix-my-claw.plist
```
