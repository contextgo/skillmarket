# JWT + OAuth2 Authentication Guide

## Overview
Modern authentication and authorization for web applications.

## JWT Best Practices

### Security Config
- Algorithm: RS256 for issuance, HS256 for internal
- Expiry: Access Token 15min, Refresh Token 7 days
- Storage: Access in memory, Refresh in HttpOnly Cookie
- Transport: Always HTTPS

### Refresh Flow
Access Token expires → Client detects 401 → Auto refresh with Refresh Token → Silent, seamless

## OAuth2 Flows

### Scenario Selection
| Scenario | Flow |
|----------|------|
| SPA | Authorization Code + PKCE |
| Server App | Authorization Code |
| Mobile | Authorization Code + PKCE |
| Server-to-Server | Client Credentials |

### PKCE Protection
1. Generate code_verifier (random string)
2. Compute code_challenge = SHA256(code_verifier)
3. Send challenge in auth request
4. Send verifier in token request
5. Server validates

## RBAC Model
Role-based permissions: admin (full), editor (read+write), viewer (read only)
Resource-level access control per role.

## Security Checklist
- Token expiry ≤ 15 minutes?
- Refresh Token HttpOnly + Secure?
- Token revocation implemented?
- JWT algorithm confusion prevented?
- Re-authentication for sensitive ops?
