# 人性化AI文本

用于检测和转换AI生成文本以绕过检测器的综合CLI。基于[维基百科的AI写作迹象](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing)。

## 快速开始

```bash
# 检测AI模式
python scripts/detect.py text.txt

# 转换为类人风格
python scripts/transform.py text.txt -o clean.txt

# 对比前后差异
python scripts/compare.py text.txt -o clean.txt
```

---

## 检测类别

分析器根据维基百科指南检查**16种模式类别**：

### 关键（立即AI检测）
| 类别 | 示例 |
|----------|----------|
| 引用错误 | `oaicite`, `turn0search`, `contentReference` |
| 知识截止 | "as of my last training", "based on available information" |
| 聊天机器人痕迹 | "I hope this helps", "Great question!", "As an AI" |
| Markdown | `**bold**`, `## headers`, ``` code blocks ``` |

### 高信号
| 类别 | 示例 |
|----------|----------|
| AI词汇 | delve, tapestry, landscape, pivotal, underscore, foster |
| 意义膨胀 | "serves as a testament", "pivotal moment", "indelible mark" |
| 宣传性语言 | vibrant, groundbreaking, nestled, breathtaking |
| 系动词回避 | "serves as" instead of "is", "boasts" instead of "has" |

### 中等信号
| 类别 | 示例 |
|----------|----------|
| 表面-ing形式 | "highlighting the importance", "fostering collaboration" |
| 填充短语 | "in order to", "due to the fact that", "Additionally," |
| 模糊归因 | "experts believe", "industry reports suggest" |
| 挑战公式 | "Despite these challenges", "Future outlook" |

### 风格信号
| 类别 | 示例 |
|----------|----------|
| 弯引号 | "" instead of "" (ChatGPT签名) |
| 破折号过度使用 | 过度使用—来强调 |
| 否定平行结构 | "Not only... but also", "It's not just... it's" |
| 三一律 | 强制性的三联体，如"创新、灵感和洞察" |

---

## 脚本

### detect.py — 扫描AI模式

```bash
python scripts/detect.py essay.txt
python scripts/detect.py essay.txt -j  # JSON输出
python scripts/detect.py essay.txt -s  # 仅分数
echo "text" | python scripts/detect.py
```

**输出：**
- 问题数量和词数
- AI概率（低/中/高/非常高）
- 按类别分类
- 标记可自动修复的模式

### transform.py — 重写文本

```bash
python scripts/transform.py essay.txt
python scripts/transform.py essay.txt -o output.txt
python scripts/transform.py essay.txt -a  # 激进模式
python scripts/transform.py essay.txt -q  # 静默模式
```

**自动修复：**
- 引用错误（oaicite, turn0search）
- Markdown（**, ##, ```）
- 聊天机器人句子
- 系动词回避 → "is/has"
- 填充短语 → 简化形式
- 弯引号 → 直引号

**激进模式（-a）：**
- 简化-ing从句
- 减少破折号使用

### compare.py — 前后对比分析

```bash
python scripts/compare.py essay.txt
python scripts/compare.py essay.txt -a -o clean.txt
```

显示转换前后的并排检测分数

---

## 工作流程

1. **扫描**检测风险：
   ```bash
   python scripts/detect.py document.txt
   ```

2. **转换**并比较：
   ```bash
   python scripts/compare.py document.txt -o document_v2.txt
   ```

3. **验证**改进：
   ```bash
   python scripts/detect.py document_v2.txt -s
   ```

4. **人工审核**AI词汇和宣传语言（需要判断）

---

## AI概率评分

| 评级 | 标准 |
|--------|----------|
| 非常高 | 存在引用错误、知识截止日期或聊天机器人痕迹 |
| 高 | >30个问题或>5%问题密度 |
| 中等 | >15个问题或>2%问题密度 |
| 低 | <15个问题且<2%密度 |

---

## 自定义模式

编辑 `scripts/patterns.json` 以添加/修改：
- `ai_vocabulary` — 要标记的词汇
- `significance_inflation` — 夸大短语
- `promotional_language` — 营销用语
- `copula_avoidance` — 短语 → 替换
- `filler_replacements` — 短语 → 更简单的形式
- `chatbot_artifacts` — 触发句子删除的短语

---

## 批量处理

```bash
# 扫描所有文件
for f in *.txt; do
  echo "=== $f ==="
  python scripts/detect.py "$f" -s
done

# 转换所有markdown
for f in *.md; do
  python scripts/transform.py "$f" -a -o "${f%.md}_clean.md" -q
done
```

---

## 参考

基于维基百科的[AI写作迹象](https://en.wikipedia.org/wiki/Wikipedia:Signs_of_AI_writing)，由WikiProject AI Cleanup维护。模式记录自数千个AI生成文本示例。

关键洞察："LLM使用统计算法来猜测接下来应该出现什么。结果往往倾向于最统计上可能的结果，适用于最广泛的各种情况。"