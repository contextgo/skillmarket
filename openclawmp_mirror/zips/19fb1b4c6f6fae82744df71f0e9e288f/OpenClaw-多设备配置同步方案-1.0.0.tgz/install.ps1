# OpenClaw 配置恢复脚本 (Windows)
# 适配新目录结构

$ErrorActionPreference = "Stop"

Write-Host "🦞 OpenClaw 配置恢复脚本" -ForegroundColor Cyan
Write-Host "==========================" -ForegroundColor Cyan

# 路径配置
$backupDir = $PSScriptRoot | Split-Path -Parent
$stepclawDir = Join-Path $env:USERPROFILE ".stepclaw"

Write-Host "`n📁 备份目录: $backupDir" -ForegroundColor Yellow
Write-Host "📁 目标目录: $stepclawDir" -ForegroundColor Yellow

# 确认操作
$confirm = Read-Host "`n这将覆盖现有的 OpenClaw 配置，是否继续? (y/N)"
if ($confirm -ne 'y' -and $confirm -ne 'Y') {
    Write-Host "已取消" -ForegroundColor Red
    exit 0
}

# 创建目录
New-Item -ItemType Directory -Force -Path $stepclawDir | Out-Null

# 1. 恢复 config
$configSource = Join-Path $backupDir "config\openclaw.json"
$configTarget = Join-Path $stepclawDir "openclaw.json"

if (Test-Path $configSource) {
    if (Test-Path $configTarget) {
        $backupName = "openclaw.json.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"
        Copy-Item $configTarget (Join-Path $stepclawDir $backupName) -Force
        Write-Host "✅ 原配置已备份为: $backupName" -ForegroundColor Green
    }
    
    Copy-Item $configSource $configTarget -Force
    Write-Host "✅ config/openclaw.json 已恢复" -ForegroundColor Green
} else {
    Write-Warning "未找到 openclaw.json"
}

# 2. 恢复 data 目录
$dataDirs = @("workspace", "memory", "cron", "experiences", "skills")

foreach ($dir in $dataDirs) {
    $source = Join-Path $backupDir "data\$dir"
    $target = Join-Path $stepclawDir $dir
    
    if (Test-Path $source) {
        if (Test-Path $target) {
            $backupName = "$dir.backup.$(Get-Date -Format 'yyyyMMddHHmmss')"
            Rename-Item $target (Join-Path $stepclawDir $backupName)
        }
        Copy-Item $source $target -Recurse -Force
        Write-Host "✅ data/$dir/ 已恢复" -ForegroundColor Green
    }
}

# 3. 验证配置完整性
Write-Host "`n🔐 配置验证:" -ForegroundColor Cyan
Write-Host "========================" -ForegroundColor Cyan

if (Test-Path $configTarget) {
    $content = Get-Content $configTarget -Raw
    $configOk = $true
    
    # 检查是否包含占位符
    if ($content -match "YOUR_FEISHU_APP_SECRET|YOUR_GATEWAY_TOKEN|YOUR_API_KEY") {
        Write-Host "⚠️  检测到配置占位符，需要填入真实值" -ForegroundColor Yellow
        $configOk = $false
    }
    
    # 检查是否包含真实值
    if ($content -match '"appSecret":\s*"[^"_]{10,}"') {
        Write-Host "✅ 飞书应用密钥已配置" -ForegroundColor Green
    }
    if ($content -match '"token":\s*"[^"_]{10,}"') {
        Write-Host "✅ Gateway 令牌已配置" -ForegroundColor Green
    }
    if ($content -match '"apiKey":\s*"[^"_]{5,}"') {
        Write-Host "✅ API 密钥已配置" -ForegroundColor Green
    }
    
    if ($configOk) {
        Write-Host "`n✅ 所有配置已完成，可直接使用！" -ForegroundColor Green
    } else {
        Write-Host "`n📖 请编辑 $configTarget 填入真实值" -ForegroundColor Yellow
    }
}

# 4. 创建同步脚本
$syncScript = @'
# OpenClaw 配置同步脚本 (Windows)
$ErrorActionPreference = "Stop"

$backupDir = Join-Path $env:USERPROFILE ".stepclaw-backup"
$stepclawDir = Join-Path $env:USERPROFILE ".stepclaw"

Write-Host "🔄 同步 OpenClaw 配置到 GitHub..." -ForegroundColor Cyan

if (-not (Test-Path $backupDir)) {
    Write-Error "备份目录不存在"
    exit 1
}

# 复制 config
Copy-Item (Join-Path $stepclawDir "openclaw.json") (Join-Path $backupDir "config\openclaw.json") -Force

# 复制 data
$dataDirs = @("workspace", "memory", "cron", "experiences", "skills")
foreach ($dir in $dataDirs) {
    $source = Join-Path $stepclawDir $dir
    $target = Join-Path $backupDir "data\$dir"
    if (Test-Path $source) {
        if (Test-Path $target) { Remove-Item $target -Recurse -Force }
        Copy-Item $source $target -Recurse -Force
    }
}

# Git 提交
Set-Location $backupDir
git add .
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
git commit -m "sync: $timestamp"
git push origin main

Write-Host "✅ 同步完成!" -ForegroundColor Green
'@

$syncScript | Set-Content (Join-Path $stepclawDir "sync.ps1")
Write-Host "`n✅ 同步脚本已创建" -ForegroundColor Green

# 5. 创建快捷命令
$profilePath = $PROFILE
if (-not (Test-Path $profilePath)) {
    New-Item -ItemType File -Path $profilePath -Force | Out-Null
}

$syncFunction = @"

# OpenClaw 快捷命令
function claw-sync {
    & "$stepclawDir\sync.ps1"
}

function claw-status {
    cd "$backupDir"
    git status
}
"@

if (-not (Select-String -Path $profilePath -Pattern "claw-sync" -Quiet)) {
    $syncFunction | Add-Content $profilePath
    Write-Host "✅ 快捷命令已添加到 PowerShell 配置" -ForegroundColor Green
    Write-Host "   使用 'claw-sync' 快速同步配置" -ForegroundColor White
}

Write-Host "`n🎉 恢复完成!" -ForegroundColor Cyan
Write-Host "`n下一步:" -ForegroundColor Yellow
Write-Host "1. 如需编辑配置: notepad $configTarget" -ForegroundColor White
Write-Host "2. 重启 OpenClaw Gateway" -ForegroundColor White
Write-Host "3. 运行 claw-sync 或 ~/.stepclaw/sync.ps1 同步更改" -ForegroundColor White
