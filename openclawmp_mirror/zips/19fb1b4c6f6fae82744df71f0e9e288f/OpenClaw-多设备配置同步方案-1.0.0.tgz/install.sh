#!/bin/bash
# OpenClaw 配置恢复脚本 (Mac/Linux)
# 适配新目录结构

set -e

echo -e "\033[36m🦞 OpenClaw 配置恢复脚本\033[0m"
echo -e "\033[36m==========================\033[0m"

# 路径配置
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BACKUP_DIR="$(dirname "$SCRIPT_DIR")"
STEPCLAW_DIR="$HOME/.stepclaw"

echo -e "\n\033[33m📁 备份目录: $BACKUP_DIR\033[0m"
echo -e "\033[33m📁 目标目录: $STEPCLAW_DIR\033[0m"

# 确认操作
read -p "
这将覆盖现有的 OpenClaw 配置，是否继续? (y/N) " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo -e "\033[31m已取消\033[0m"
    exit 0
fi

# 创建目录
mkdir -p "$STEPCLAW_DIR"

# 1. 恢复 config
CONFIG_SOURCE="$BACKUP_DIR/config/openclaw.json"
CONFIG_TARGET="$STEPCLAW_DIR/openclaw.json"

if [ -f "$CONFIG_SOURCE" ]; then
    # 如果目标存在，备份原配置
    if [ -f "$CONFIG_TARGET" ]; then
        BACKUP_NAME="openclaw.json.backup.$(date +%Y%m%d%H%M%S)"
        cp "$CONFIG_TARGET" "$STEPCLAW_DIR/$BACKUP_NAME"
        echo -e "\033[32m✅ 原配置已备份为: $BACKUP_NAME\033[0m"
    fi
    
    cp "$CONFIG_SOURCE" "$CONFIG_TARGET"
    echo -e "\033[32m✅ config/openclaw.json 已恢复\033[0m"
else
    echo -e "\033[33m⚠️ 未找到 openclaw.json\033[0m"
fi

# 2. 恢复 data 目录
DATA_DIRS=("workspace" "memory" "cron" "experiences" "skills")

for dir in "${DATA_DIRS[@]}"; do
    SOURCE="$BACKUP_DIR/data/$dir"
    TARGET="$STEPCLAW_DIR/$dir"
    
    if [ -d "$SOURCE" ]; then
        if [ -d "$TARGET" ]; then
            BACKUP_NAME="$dir.backup.$(date +%Y%m%d%H%M%S)"
            mv "$TARGET" "$STEPCLAW_DIR/$BACKUP_NAME"
        fi
        cp -r "$SOURCE" "$STEPCLAW_DIR/"
        echo -e "\033[32m✅ data/$dir/ 已恢复\033[0m"
    fi
done

# 3. 验证配置完整性
echo -e "\n\033[36m🔐 配置验证:\033[0m"
echo -e "\033[36m========================\033[0m"

if [ -f "$CONFIG_TARGET" ]; then
    CONFIG_OK=true
    
    # 检查是否包含占位符
    if grep -q "YOUR_FEISHU_APP_SECRET\|YOUR_GATEWAY_TOKEN\|YOUR_API_KEY" "$CONFIG_TARGET"; then
        echo -e "\033[33m⚠️  检测到配置占位符，需要填入真实值\033[0m"
        CONFIG_OK=false
    fi
    
    # 检查是否包含真实值
    if grep -q '"appSecret":\s*"[^"_]\{10,\}"' "$CONFIG_TARGET"; then
        echo -e "\033[32m✅ 飞书应用密钥已配置\033[0m"
    fi
    if grep -q '"token":\s*"[^"_]\{10,\}"' "$CONFIG_TARGET"; then
        echo -e "\033[32m✅ Gateway 令牌已配置\033[0m"
    fi
    if grep -q '"apiKey":\s*"[^"_]\{5,\}"' "$CONFIG_TARGET"; then
        echo -e "\033[32m✅ API 密钥已配置\033[0m"
    fi
    
    if [ "$CONFIG_OK" = true ]; then
        echo -e "\n\033[32m✅ 所有配置已完成，可直接使用！\033[0m"
    else
        echo -e "\n\033[33m📖 请编辑 $CONFIG_TARGET 填入真实值\033[0m"
    fi
fi

# 4. 创建同步脚本
SYNC_SCRIPT="$STEPCLAW_DIR/sync.sh"
cat > "$SYNC_SCRIPT" << 'EOF'
#!/bin/bash
# OpenClaw 配置同步脚本 (Mac/Linux)

set -e

BACKUP_DIR="$HOME/.stepclaw-backup"
STEPCLAW_DIR="$HOME/.stepclaw"

echo -e "\033[36m🔄 同步 OpenClaw 配置到 GitHub...\033[0m"

# 检查备份目录
if [ ! -d "$BACKUP_DIR" ]; then
    echo -e "\033[31m错误: 备份目录不存在\033[0m"
    echo -e "\033[33m请先克隆仓库: git clone git@github.com:bayi-95/my-claw.git ~/.stepclaw-backup\033[0m"
    exit 1
fi

# 复制 config
cp "$STEPCLAW_DIR/openclaw.json" "$BACKUP_DIR/config/"

# 复制 data
DATA_DIRS=("workspace" "memory" "cron" "experiences" "skills")
for dir in "${DATA_DIRS[@]}"; do
    SOURCE="$STEPCLAW_DIR/$dir"
    TARGET="$BACKUP_DIR/data/$dir"
    if [ -d "$SOURCE" ]; then
        if [ -d "$TARGET" ]; then
            rm -rf "$TARGET"
        fi
        cp -r "$SOURCE" "$BACKUP_DIR/data/"
    fi
done

# Git 操作
cd "$BACKUP_DIR"

# 检查是否有更改
if [ -z "$(git status --porcelain)" ]; then
    echo -e "\033[32m✅ 没有需要同步的更改\033[0m"
    exit 0
fi

echo -e "\033[33m📤 提交更改...\033[0m"
git add .
TIMESTAMP=$(date "+%Y-%m-%d %H:%M")
git commit -m "sync: $TIMESTAMP"
git push origin main

echo -e "\033[32m✅ 同步完成!\033[0m"
EOF

chmod +x "$SYNC_SCRIPT"
echo -e "\n\033[32m✅ 同步脚本已创建: $SYNC_SCRIPT\033[0m"
echo -e "\033[37m   运行 ./sync.sh 即可同步配置到 GitHub\033[0m"

echo -e "\n\033[36m🎉 恢复完成!\033[0m"
echo -e "\n\033[33m下一步:\033[0m"
echo -e "\033[37m1. 如需编辑配置: nano $CONFIG_TARGET\033[0m"
echo -e "\033[37m2. 重启 OpenClaw Gateway\033[0m"
echo -e "\033[37m3. 运行 ./sync.sh 同步更改\033[0m"
