# OpenClaw 配置同步脚本 (Windows)
# 用于将本地更改同步到 GitHub
# 注意：这是私人仓库，保留所有敏感信息

$ErrorActionPreference = "Stop"

$backupDir = Join-Path $env:USERPROFILE ".stepclaw-backup"
$stepclawDir = Join-Path $env:USERPROFILE ".stepclaw"

Write-Host "🔄 同步 OpenClaw 配置到 GitHub..." -ForegroundColor Cyan
Write-Host "   ⚠️  私人仓库模式：保留所有敏感信息" -ForegroundColor Yellow

# 检查备份目录是否存在
if (-not (Test-Path $backupDir)) {
    Write-Error "备份目录不存在: $backupDir"
    Write-Host "请先克隆仓库: git clone git@github.com:bayi-95/my-claw.git ~/.stepclaw-backup" -ForegroundColor Yellow
    exit 1
}

# 定义需要同步的目录和文件（匹配 .stepclaw-backup 目录结构）
$syncItems = @(
    # 核心配置（保留敏感信息）-> config/
    @{ Source = (Join-Path $stepclawDir "openclaw.json"); Target = (Join-Path $backupDir "config"); Type = "File"; TargetName = "openclaw.json" },
    
    # Workspace -> data/workspace/
    @{ Source = (Join-Path $stepclawDir "workspace"); Target = (Join-Path $backupDir "data\workspace"); Type = "Directory" },
    
    # Memory - 记忆文件 -> data/memory/
    @{ Source = (Join-Path $stepclawDir "memory"); Target = (Join-Path $backupDir "data\memory"); Type = "Directory" },
    
    # Cron - 定时任务 -> data/cron/
    @{ Source = (Join-Path $stepclawDir "cron"); Target = (Join-Path $backupDir "data\cron"); Type = "Directory" },
    
    # Experiences - 自定义体验 -> data/experiences/
    @{ Source = (Join-Path $stepclawDir "experiences"); Target = (Join-Path $backupDir "data\experiences"); Type = "Directory" },
    
    # Skills - 本地技能 -> data/skills/
    @{ Source = (Join-Path $stepclawDir "skills"); Target = (Join-Path $backupDir "data\skills"); Type = "Directory" }
)

# 执行同步
foreach ($item in $syncItems) {
    $source = $item.Source
    $target = $item.Target
    $type = $item.Type
    $targetName = $item.TargetName
    
    if (-not (Test-Path $source)) {
        Write-Host "⚠️  跳过: $source (不存在)" -ForegroundColor Yellow
        continue
    }
    
    # 确保目标父目录存在
    $targetParent = Split-Path $target -Parent
    if (-not (Test-Path $targetParent)) {
        New-Item -ItemType Directory -Path $targetParent -Force | Out-Null
    }
    
    $displayName = if ($targetName) { $targetName } else { Split-Path $source -Leaf }
    Write-Host "📁 同步: $displayName -> $(Split-Path $target -Leaf)" -ForegroundColor Yellow
    
    if ($type -eq "File") {
        # 文件同步：如果指定了 TargetName，使用它；否则保持原文件名
        $destPath = if ($targetName) { Join-Path $target $targetName } else { $target }
        Copy-Item $source $destPath -Force
    } else {
        # 目录同步：先删除旧目录，再复制新目录
        if (Test-Path $target) {
            Remove-Item $target -Recurse -Force
        }
        Copy-Item $source $target -Recurse -Force
    }
}

# 排除不需要同步的文件
$excludePatterns = @(
    "*.sqlite",      # 数据库文件
    "*.log",         # 日志文件
    "*.tmp",         # 临时文件
    "node_modules",  # 依赖目录
    "__pycache__",   # Python缓存
    ".git"           # Git目录（如果存在）
)

# 清理排除的文件
foreach ($pattern in $excludePatterns) {
    Get-ChildItem $backupDir -Recurse -Filter $pattern -ErrorAction SilentlyContinue | ForEach-Object {
        Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
        Write-Host "🗑️  排除: $($_.FullName.Replace($backupDir, ''))" -ForegroundColor Gray
    }
}

# Git 操作
Set-Location $backupDir

# 先拉取远程更改，避免非快进拒绝
Write-Host "📥 拉取远程更改..." -ForegroundColor Yellow
try {
    git pull origin main --rebase
    Write-Host "✅ 已同步远程更改" -ForegroundColor Green
} catch {
    Write-Warning "拉取远程更改时出现问题，尝试继续..."
}

# 检查是否有更改
$status = git status --porcelain
if ([string]::IsNullOrWhiteSpace($status)) {
    Write-Host "✅ 没有需要同步的更改" -ForegroundColor Green
    exit 0
}

Write-Host "📤 提交更改..." -ForegroundColor Yellow
git add .
$timestamp = Get-Date -Format "yyyy-MM-dd HH:mm"
$changes = (git diff --cached --stat) | Out-String
git commit -m "sync: $timestamp`n`n$changes"

# 推送更改（使用简单的重试逻辑）
try {
    git push origin main
    Write-Host "✅ 同步完成!" -ForegroundColor Green
} catch {
    Write-Warning "推送失败，尝试先拉取再推送..."
    git pull origin main --rebase
    git push origin main
    Write-Host "✅ 同步完成（已解决冲突）!" -ForegroundColor Green
}

Write-Host "✅ 同步完成!" -ForegroundColor Green
Write-Host "`n📝 提交信息: sync: $timestamp" -ForegroundColor Gray
