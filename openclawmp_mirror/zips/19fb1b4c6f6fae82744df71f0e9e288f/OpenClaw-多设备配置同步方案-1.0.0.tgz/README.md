# OpenClaw 多设备配置同步方案

> 一个完整的多设备 OpenClaw 配置备份与同步解决方案

## 功能特性

- ✅ **自动备份**：每6小时自动同步配置到 GitHub
- ✅ **多设备同步**：Windows/Mac/Linux 全平台支持
- ✅ **智能初始化**：新设备一键恢复配置
- ✅ **完整备份**：config、workspace、memory、cron、experiences、skills
- ✅ **冲突解决**：自动处理合并冲突
- ✅ **安全设计**：私有仓库，保留敏感信息

## 快速开始

### 1. 创建 GitHub 私有仓库

```bash
# 在 GitHub 创建私有仓库，例如：my-claw
```

### 2. 初始化备份

在当前设备上执行：

```powershell
# Windows
~/.stepclaw/scripts/backup-openclaw.ps1 -RepoUrl "https://github.com/YOUR_USERNAME/my-claw"
```

```bash
# Mac/Linux
~/.stepclaw/scripts/backup-openclaw.sh --repo-url "https://github.com/YOUR_USERNAME/my-claw"
```

### 3. 新设备恢复配置

在新设备上发送 GitHub 仓库链接给 OpenClaw：

```
https://github.com/YOUR_USERNAME/my-claw
```

OpenClaw 会自动：
1. 克隆仓库
2. 恢复所有配置
3. 设置自动同步

## 目录结构

```
my-claw/
├── config/              # 核心配置（openclaw.json）
├── data/
│   ├── workspace/       # 工作区文件
│   ├── memory/          # 记忆文件
│   ├── cron/            # 定时任务
│   ├── experiences/     # 自定义体验
│   └── skills/          # 本地技能
├── scripts/
│   ├── install.ps1      # Windows 安装脚本
│   ├── install.sh       # Mac/Linux 安装脚本
│   ├── auto-init-from-github.ps1  # 智能初始化
│   └── sync-claw.ps1    # 快速同步命令
└── README.md
```

## 安全警告 ⚠️

**重要**：此方案设计为**私有仓库**使用

- `openclaw.json` 包含敏感信息（API密钥、token等）
- 请确保 GitHub 仓库设置为 **Private**
- 不要分享仓库访问权限给不信任的人
- 定期检查仓库访问日志

## 手动同步

```powershell
# Windows
claw-sync
# 或
~/.stepclaw/sync.ps1
```

```bash
# Mac/Linux
claw-sync
# 或
~/.stepclaw/sync.sh
```

## 故障排除

### 同步失败（非快进拒绝）

```bash
cd ~/.stepclaw-backup
git pull origin main --rebase
git push origin main
```

### 配置文件冲突

同步脚本会自动备份冲突文件（带时间戳后缀），手动检查并合并即可。

## 平台支持

| 平台 | 状态 | 说明 |
|------|------|------|
| Windows | ✅ 完整支持 | PowerShell 脚本 |
| macOS | ✅ 完整支持 | Bash 脚本 |
| Linux | ✅ 完整支持 | Bash 脚本 |

## 贡献

此方案基于 OpenClaw 官方推荐的最佳实践整理而成。

## 许可证

MIT License - 自由使用，风险自负
