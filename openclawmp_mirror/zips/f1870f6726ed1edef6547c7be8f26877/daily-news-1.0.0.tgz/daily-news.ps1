# Daily News Fetcher for OpenClaw (Fixed v2)
# Uses 36kr RSS - proper XML handling
param(
    [string]$WorkDir = "$env:USERPROFILE\.openclaw\workspace",
    [int]$MaxNews = 15
)

$ErrorActionPreference = "Stop"
$dateStr = Get-Date -Format "yyyy-MM-dd"

# Logging
$logDir = Join-Path $WorkDir "logs"
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Path $logDir -Force | Out-Null }
$logFile = Join-Path $logDir "daily-news-$dateStr.log"

function Write-Log {
    param([string]$Msg)
    $ts = Get-Date -Format "HH:mm:ss"
    "$ts - $Msg" | Out-File -FilePath $logFile -Append -Encoding UTF8
    Write-Host $ts - $Msg
}

try {
    Write-Log "Fetching 36kr RSS..."
    $resp = Invoke-WebRequest -Uri "https://36kr.com/feed" -UseBasicParsing -TimeoutSec 30
    $xml = [xml]$resp.Content

    $items = $xml.rss.channel.item
    Write-Log "Found $($items.Count) items"
    $count = [Math]::Min($MaxNews, $items.Count)

    $newsList = @()
    for ($i = 0; $i -lt $count; $i++) {
        $item = $items[$i]
        $title = $item.title -replace '\s+', ' '

        # Get link as plain text
        $linkNode = $item.link
        $link = ""
        if ($linkNode -is [string]) {
            $link = $linkNode.Trim()
        } elseif ($linkNode -ne $null) {
            $link = $linkNode.InnerText.Trim()
        }

        $pubDate = $item.pubDate

        $newsList += [PSCustomObject]@{
            Title = $title
            Source = "36kr"
            Url = $link
            Category = if ($i -eq 0) { "Headline" } else { "News" }
            PubDate = $pubDate
        }
    }

    # Generate markdown
    $markdown = "# Daily News Summary - $dateStr`n`n> $($newsList.Count) curated news items for Dymas`n`n"
    foreach ($item in $newsList) {
        $markdown += "## $($item.Title)`n"
        $markdown += "**Source**: [$($item.Source)]($($item.Url))`n"
        $markdown += "**Link**: <$($item.Url)>`n"
        if ($item.PubDate) {
            $markdown += "**Published**: $($item.PubDate)`n"
        }
        $markdown += "`n"
    }
    $markdown += "---`n"
    $markdown += "*Generated*: $(Get-Date -Format 'HH:mm')`n"
    $markdown += "*Schedule*: Daily 09:00 Beijing`n"
    $markdown += "*Source*: 36kr RSS Feed`n"

    # Save files
    $summaryFile = Join-Path $WorkDir "INBOX_NEWS_$dateStr.md"
    [System.IO.File]::WriteAllText($summaryFile, $markdown, [System.Text.Encoding]::UTF8)

    $inboxFile = Join-Path $WorkDir "INBOX.md"
    # Create a summary for sending (first 10 news items)
    $shortContent = "# Daily News Summary - $dateStr`n`n>今日精选新闻（前10条）`n`n"
    for ($i = 0; $i -lt [Math]::Min(10, $newsList.Count); $i++) {
        $item = $newsList[$i]
        $shortContent += "## $($item.Title)`n**链接**: <$($item.Url)>`n`n"
    }
    $shortContent += "---`n"
    $shortContent += "*完整内容请查看 INBOX_NEWS_$dateStr.md 文件*`n"
    $shortContent += "*数据源: 36kr RSS | 推送时间: 09:00 北京时间*`n"
    [System.IO.File]::WriteAllText($inboxFile, $shortContent, [System.Text.Encoding]::UTF8)

    Write-Log "Success: Generated $($newsList.Count) news items"
    Write-Log "Saved: $summaryFile"
    exit 0

} catch {
    Write-Log "ERROR: $($_.Exception.Message)"
    exit 1
}
