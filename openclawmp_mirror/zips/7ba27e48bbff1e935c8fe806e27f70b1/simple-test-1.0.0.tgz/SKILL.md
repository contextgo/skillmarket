---
name: simple-test
description: A simple test skill
version: 1.0.0
---

# Simple Test

This is a simple test skill.
