---
name: markdown-formatter
description: Markdown格式优化助手 | 自动优化Markdown文档格式，统一表格样式，修复链接，生成目录索引
---

# Markdown格式优化助手

自动优化Markdown文档的格式，统一样式，修复损坏的链接，生成目录索引。

## 适用场景

- 文档排版混乱需要整理
- 批量处理Markdown文件
- 生成文档目录导航
- 修复失效的内部链接
- 统一团队文档格式

## 核心功能

| 功能 | 说明 |
|------|------|
| 格式标准化 | 统一标题层级、列表符号、空行规范 |
| 表格美化 | 统一表格宽度、对齐方式 |
| 链接修复 | 检测并修复失效的内部链接 |
| 目录生成 | 自动生成文档目录（TOC） |
| 图片优化 | 检查图片路径，提取Alt文本 |
| 代码块标注 | 识别代码语言并标注 |

## 使用方法

```powershell
# 优化单个文件
md-formatter optimize -i "readme.md" -o "readme_clean.md"

# 批量处理目录
md-formatter batch -i "./docs/" -o "./docs_clean/"

# 生成目录索引
md-formatter toc -i "readme.md" -o "readme_with_toc.md"

# 检查失效链接
md-formatter check-links -i "readme.md"
```

### 对话式

```
用户：帮我优化这份Markdown文档的格式，统一表格样式
[粘贴文档内容]

用户：给这份文档自动生成一个目录索引

用户：检查这个文档里有没有失效的图片链接
```

## 输出规范

- 标题层级连续（H1→H2→H3，不跳级）
- 表格统一使用简洁样式
- 代码块标注语言
- 链接保留原始URL
- 空行规范（段落间1空行，标题前后1空行）
