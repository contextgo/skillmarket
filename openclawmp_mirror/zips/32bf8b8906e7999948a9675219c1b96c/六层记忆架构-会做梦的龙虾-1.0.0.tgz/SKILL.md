---
name: 六层记忆架构（会做梦的龙虾）
description: |
  六层记忆架构，让 AI Agent 真正实现持久化记忆。

  触发词（无需 @，自动拦截）：
  - 「记一下xxx」「帮我记住xxx」「记作xxx」「存档xxx」→ 写入记忆
  - 「我想起xxx」「你记得xxx吗」「之前说过xxx」→ 检索记忆

  触发即写入 L2 本地层，然后自动同步到 L3 mem9 云端和 L4 IMA 知识库。
  次日凌晨 03:30 自动运行「庄周梦蝶」整理脚本，去重、降噪、刷新、评分。
  每周五 23:40 执行 PARA 周流转，项目归档，知识沉淀。
  ---

  ⚠️ 安装后需要配置以下环境变量才能正常使用（详见 Setup 章节）：
  - MEM9_API_KEY（mem9 云端记忆，可选）
  - IMA_OPENAPI_CLIENTID + IMA_OPENAPI_APIKEY（IMA 知识沉淀，可选）
  - 若不配置，Skill 降级为 L2 单层模式（仅本地 PARA 写入）
version: 1.0.0
homepage: https://openclawmp.cc
metadata:
  openclaw:
    emoji: '🦞'
    requires:
      env:
        - MEM9_API_KEY
        - IMA_OPENAPI_CLIENTID
        - IMA_OPENAPI_APIKEY
        - IMA_KNOWLEDGE_BASE_ID
    primaryEnv: 'MEM9_API_KEY'
---

# 🦞 六层记忆架构（会做梦的龙虾）

让 AI Agent 实现真正持久化的记忆系统，模仿人类记忆的写入→检索→整理→归档完整闭环。

## 六层架构

| 层 | 名称 | 存储位置 | 说明 |
|---|------|----------|------|
| L1 | 会话上下文 | LLM Context | 单次对话内有效 |
| L2 | PARA 本地层 | `.workbuddy/memory/` | 草稿层，快速写入，永久保存 |
| L3 | mem9 云端层 | mem9.ai | 跨会话语义检索，云端持久化 |
| L4 | IMA 知识沉淀层 | 腾讯文档 IMA | 人类可读备份，双重保险 |
| L5 | 庄周梦蝶 | 定时自动运行 | 凌晨 03:30 去重/降噪/刷新/评分 |
| L6 | PARA 流转 | L2 归档区 | 每周五 23:40 项目归档 + 知识沉淀 |

## 触发词

### 记忆写入（自动拦截，无需 @）
- 「记一下xxx」
- 「帮我记住xxx」
- 「记作xxx」
- 「存档xxx」

### 记忆检索（自动拦截）
- 「我想起xxx」
- 「你记得xxx吗」
- 「之前说过xxx」

## 安装后配置 ⚠️

Skill 源码**不包含任何 API Key**，所有凭证通过环境变量注入。

### 必须配置的环境变量

```bash
# L3 mem9 云端记忆（必须，否则 L3 跳过）
export MEM9_API_KEY="your_mem9_api_key"

# L4 IMA 腾讯文档知识沉淀（必须，否则 L4 跳过）
export IMA_OPENAPI_CLIENTID="your_ima_client_id"
export IMA_OPENAPI_APIKEY="your_ima_api_key"

# L4 知识库（可选，不填则自动创建新笔记）
export IMA_KNOWLEDGE_BASE_ID="your_knowledge_base_id"
```

### mem9 API Key 获取
1. 访问 https://mem9.ai 注册账号
2. 调用 `POST https://api.mem9.ai/v1alpha1/mem9s` 获取 API Key
3. 将 Key 填入 `MEM9_API_KEY`

### IMA API Key 获取
1. 访问 https://ima.qq.com/agent-interface 获取 Client ID 和 API Key
2. 将两个值分别填入 `IMA_OPENAPI_CLIENTID` 和 `IMA_OPENAPI_APIKEY`

### 降级说明
若不填写上述环境变量，Skill 降级为 **L2 单层模式**：
- 记忆仅写入 `.workbuddy/memory/` 本地 PARA 层
- L3 / L4 / L5 / L6 功能跳过，不影响正常使用
- 每次执行时会提示：`[六层记忆] MEM9_API_KEY 未配置，L3 层跳过`

## PARA 分类规则

| PARA 分类 | 说明 | 示例 |
|-----------|------|------|
| **projects** | 有明确截止日的短期项目 | 「写公众号文章」「开发 Skill X」 |
| **areas** | 长期维护的领域（无截止日） | 「AI Agent 研究」「内容运营」 |
| **resources** | 感兴趣的潜在素材 | 「RAG 技术」「产品方法论」 |
| **archive** | 已完成/已放弃的归档 | 旧项目、停更内容 |

**默认写入层**：若触发词中未指定分类，默认写入 `projects/`（当前项目）。

## 定时任务

| 任务 | 时间 | 功能 |
|------|------|------|
| **庄周梦蝶·日整理** | 每天 03:30 | 去重、降噪、刷新 |
| **庄周梦蝶·评分** | 每天 03:45 | 记忆权重计算，淘汰低分 |
| **PARA 周流转** | 每周五 23:40 | 项目归档 + IMA 知识沉淀 |
| **L3 健康检查** | 每小时 | mem9 连通性 + 重试缓冲队列 |

## "记起来"完整链路

```
用户：「记一下 xxx」
        ↓
L2 PARA 本地写入（< 1s，始终执行）
        ↓ 异步 5s
L3 mem9 写入（如已配置 MEM9_API_KEY）
        ↓ 异步 10s
L4 IMA 写入（如已配置 IMA_OPENAPI_CLIENTID）
        ↓
次日凌晨 03:30 庄周梦蝶
        ├─ 去重：同一信息出现 ≥3 次 → 合并
        ├─ 降噪：30 天未调用 → 权重 -1
        ├─ 刷新：过时内容 → 用最新状态重写
        └─ 评分：权重 < 阈值 → 移入 archive
        ↓
每周五 23:40 PARA 周流转
        ├─ 已完成项目 → 移入 archive
        └─ 生成摘要 → 写入 IMA 知识库
```

## 模块说明

| 文件 | 作用 |
|------|------|
| `memory/router.py` | 分析内容，判断写入哪个 PARA 层 |
| `memory/layers/L2_para.py` | 本地 PARA 文件写入 |
| `memory/layers/L3_mem9.py` | mem9 REST API 写入 |
| `memory/layers/L4_ima.py` | IMA 笔记/知识库写入 |
| `memory/layers/L5_zhuangzhou.py` | 庄周梦蝶整理核心逻辑 |
| `scripts/remember.py` | 「记一下」触发主脚本 |
| `scripts/recall.py` | 「我想起」检索脚本 |
| `scripts/zhuangzhou_run.py` | 庄周梦蝶定时执行入口 |
| `memory/para_map.json` | PARA 分类关键词映射表 |

## 调用示例

```bash
# 记忆写入
python scripts/remember.py "记一下这个公众号选题：AI Agent 工作流设计"

# 记忆检索
python scripts/recall.py "之前说过的 RAG 方案"

# 手动运行庄周梦蝶（一般由定时任务自动触发）
python scripts/zhuangzhou_run.py
```
