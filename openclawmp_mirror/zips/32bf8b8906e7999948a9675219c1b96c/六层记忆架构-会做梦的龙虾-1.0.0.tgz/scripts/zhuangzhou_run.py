"""
庄周梦蝶定时执行入口
用法: python zhuangzhou_run.py

建议通过定时任务调用：
  Windows: 任务计划程序
  每天 03:30 执行: python scripts/zhuangzhou_run.py

同时输出完整整理报告
"""

import sys
import os

SKILL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, SKILL_DIR)

from memory.layers.L5_zhuangzhou import run_zhuangzhou


if __name__ == "__main__":
    print("=" * 50)
    print("庄周梦蝶启动...")
    print("=" * 50)

    result = run_zhuangzhou()

    print()
    print(result.get("report", ""))
    print()
    print(f"整理结果: 共扫描 {result['total_entries']} 条记忆，"
          f"去重 {result['deduped']} 条，"
          f"归档 {result['archived']} 条，"
          f"保留 {result.get('remaining', '?')} 条")

    if result.get("report_file"):
        print(f"归档文件: {result['report_file']}")

    print("=" * 50)
    print("庄周梦蝶完成。")
    print("=" * 50)
