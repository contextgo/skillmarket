"""
「我想起」记忆检索脚本
用法: python recall.py <检索内容>

混合检索：L2 本地 PARA → L3 mem9 语义 → L4 IMA 搜索
返回加权合并后的记忆列表
"""

import sys
import os
import json
from datetime import datetime

SKILL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, SKILL_DIR)

from memory.layers import L2_para, L3_mem9, L4_ima


def local_search(content: str, para_type: str = None) -> list:
    """
    L2 本地文件检索（关键词匹配）
    """
    results = []
    from memory import router

    para_dirs = router.PARA_DIRS if para_type is None else {para_type: router.PARA_DIRS.get(para_type, "")}

    for ptype, dir_path in para_dirs.items():
        if not os.path.exists(dir_path):
            continue
        for filename in os.listdir(dir_path):
            if not filename.endswith(".md"):
                continue
            filepath = os.path.join(dir_path, filename)
            try:
                with open(filepath, "r", encoding="utf-8") as f:
                    text = f.read()
                    if content.lower() in text.lower():
                        results.append({
                            "layer": "L2",
                            "para_type": ptype,
                            "file": filepath,
                            "snippet": text[:200],
                            "score": 1.0,
                        })
            except Exception:
                pass

    return results


def merge_results(l2_results: list, l3_results: list, l4_results: list) -> list:
    """
    混合检索结果按相关性排序
    L3 mem9 语义检索权重最高（语义理解），
    L2/L4 关键词匹配作为补充
    """
    merged = []

    for r in l3_results:
        merged.append({
            **r,
            "layer": "L3",
            "source": "mem9",
            "score": 0.9,
        })

    for r in l2_results:
        merged.append({
            **r,
            "layer": "L2",
            "source": "本地文件",
            "score": 0.7,
        })

    for r in l4_results:
        merged.append({
            **r,
            "layer": "L4",
            "source": "IMA",
            "score": 0.6,
        })

    # 按 score 降序
    merged.sort(key=lambda x: x["score"], reverse=True)
    return merged[:10]  # 最多返回 10 条


def main():
    if len(sys.argv) < 2:
        print("用法: python recall.py <检索内容>")
        sys.exit(1)

    query = sys.argv[1]
    print(f"[六层记忆] 检索: {query}")

    # 并行检索三层
    print("[六层记忆] 检索 L2 本地 PARA 层...")
    l2 = local_search(query)

    print("[六层记忆] 检索 L3 mem9 语义层...")
    l3_result = L3_mem9.search(query)
    l3 = l3_result.get("results", []) if l3_result.get("success") else []
    if not l3_result.get("success"):
        print(f"[六层记忆] ⚠ L3 mem9: {l3_result.get('error')}")

    print("[六层记忆] 检索 L4 IMA 笔记...")
    l4_result = L4_ima.search_notes(query)
    l4 = l4_result.get("results", []) if l4_result.get("success") else []
    if not l4_result.get("success"):
        print(f"[六层记忆] ⚠ L4 IMA: {l4_result.get('error')}")

    merged = merge_results(l2, l3, l4)

    print(f"\n[六层记忆] 共找到 {len(merged)} 条相关记忆：\n")
    for i, item in enumerate(merged, 1):
        print(f"--- 记忆 {i} [{item['layer']}] ---")
        print(f"来源: {item.get('source', 'unknown')}")
        print(f"内容: {item.get('snippet', item.get('content', ''))[:150]}")
        print()

    return merged


if __name__ == "__main__":
    main()
