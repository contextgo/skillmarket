"""
「记一下」触发主脚本
用法: python remember.py <记忆内容>

完整链路：
  L2 立即写入 → L3 mem9 异步写入 → L4 IMA 异步写入
"""

import sys
import os
import json
import time
import threading

SKILL_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, SKILL_DIR)

from memory.layers import L2_para, L3_mem9, L4_ima


def main():
    if len(sys.argv) < 2:
        print("用法: python remember.py <记忆内容>")
        sys.exit(1)

    content = sys.argv[1]
    tags = sys.argv[2:] if len(sys.argv) > 2 else []

    print(f"[六层记忆] 收到记忆: {content[:50]}{'...' if len(content) > 50 else ''}")

    results = {"L2": None, "L3": None, "L4": None}

    # === L2 同步写入（必须，立即）===
    l2_result = L2_para.write(content=content, tags=tags)
    results["L2"] = l2_result
    if l2_result["success"]:
        print(f"[六层记忆] ✓ L2 PARA 写入成功 → {l2_result['para_type']}/")
    else:
        print(f"[六层记忆] ✗ L2 PARA 写入失败: {l2_result['error']}")

    # === L3 mem9 异步写入（5s 后）===
    def async_l3():
        time.sleep(5)
        l3_result = L3_mem9.write(content=content, tags=tags)
        results["L3"] = l3_result
        if l3_result["success"]:
            print(f"[六层记忆] ✓ L3 mem9 写入成功")
        else:
            print(f"[六层记忆] ⚠ L3 mem9: {l3_result['error']}")

    l3_thread = threading.Thread(target=async_l3, daemon=True)
    l3_thread.start()

    # === L4 IMA 异步写入（10s 后）===
    def async_l4():
        time.sleep(10)
        # 标题取前 30 字
        title = content[:30] + ("..." if len(content) > 30 else "")
        l4_result = L4_ima.write_note(title=title, content=content, tags=tags)
        results["L4"] = l4_result
        if l4_result["success"]:
            print(f"[六层记忆] ✓ L4 IMA 笔记写入成功 → doc_id: {l4_result['doc_id']}")
        else:
            print(f"[六层记忆] ⚠ L4 IMA: {l4_result['error']}")

    l4_thread = threading.Thread(target=async_l4, daemon=True)
    l4_thread.start()

    # 等待 L2 完成，返回结果
    print(f"[六层记忆] 记忆写入完成。L2={results['L2']['success']}, L3/L4 异步写入中...")

    print(json.dumps(results, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
