"""
L4 IMA 腾讯文档知识沉淀层
通过 IMA OpenAPI 将记忆写入笔记和知识库

依赖环境变量（Skill 源码不包含任何 Key）：
  - IMA_OPENAPI_CLIENTID
  - IMA_OPENAPI_APIKEY
  - IMA_KNOWLEDGE_BASE_ID（可选，不填则创建新笔记）
"""

import sys
import os
import json
import time

IMA_BASE_URL = "https://ima.qq.com"


def get_credentials():
    """从环境变量获取 IMA 凭证"""
    return (
        os.environ.get("IMA_OPENAPI_CLIENTID", ""),
        os.environ.get("IMA_OPENAPI_APIKEY", ""),
    )


def get_knowledge_base_id():
    return os.environ.get("IMA_KNOWLEDGE_BASE_ID", "")


def is_enabled():
    client_id, api_key = get_credentials()
    return bool(client_id and api_key)


def _headers(client_id: str, api_key: str):
    return {
        "ima-openapi-clientid": client_id,
        "ima-openapi-apikey": api_key,
        "Content-Type": "application/json",
    }


def _post(path: str, body: dict, client_id: str = None, api_key: str = None) -> dict:
    """通用 POST 请求"""
    if client_id is None or api_key is None:
        client_id, api_key = get_credentials()

    import urllib.request

    payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(
        f"{IMA_BASE_URL}/{path}",
        data=payload,
        headers=_headers(client_id, api_key),
        method="POST",
    )
    with urllib.request.urlopen(req, timeout=15) as resp:
        return json.loads(resp.read().decode("utf-8"))


def write_note(title: str, content: str, tags: list = None) -> dict:
    """
    在 IMA 创建一篇新笔记

    参数:
        title: 笔记标题
        content: 笔记正文
        tags: 标签列表

    返回:
        {
            "success": bool,
            "layer": "L4",
            "doc_id": str,
            "error": str or None
        }
    """
    if not is_enabled():
        return {
            "success": False,
            "layer": "L4",
            "doc_id": None,
            "error": "IMA_OPENAPI_CLIENTID 或 IMA_OPENAPI_APIKEY 未配置，跳过 L4 层",
        }

    # 构建笔记正文
    full_content = content
    if tags:
        full_content += f"\n\nTags: {', '.join(tags)}"
    full_content += f"\n\n> 由 六层记忆架构（会做梦的龙虾）自动写入 | {time.strftime('%Y-%m-%d %H:%M')}"

    body = {
        "title": title[:100],  # IMA 标题限制
        "content": full_content,
        "content_format": 1,  # Markdown
    }

    try:
        result = _post("openapi/v1/notes/import_doc", body)
        doc_id = result.get("data", {}).get("doc_id", "")
        return {
            "success": bool(doc_id),
            "layer": "L4",
            "doc_id": doc_id,
            "error": None if doc_id else "IMA 返回无 doc_id",
        }
    except Exception as e:
        _add_to_retry_queue(title, content, tags)
        return {
            "success": False,
            "layer": "L4",
            "doc_id": None,
            "error": str(e),
        }


def append_to_knowledge_base(doc_id: str, content: str) -> dict:
    """
    将内容追加到指定知识库条目
    """
    if not is_enabled():
        return {
            "success": False,
            "layer": "L4",
            "error": "IMA 凭证未配置，跳过 L4 层",
        }

    body = {
        "doc_id": doc_id,
        "content": content,
        "content_format": 1,
    }

    try:
        result = _post("openapi/v1/notes/append_doc", body)
        return {
            "success": True,
            "layer": "L4",
            "doc_id": doc_id,
            "error": None,
        }
    except Exception as e:
        return {
            "success": False,
            "layer": "L4",
            "doc_id": doc_id,
            "error": str(e),
        }


def search_notes(query: str, limit: int = 5) -> dict:
    """
    搜索 IMA 笔记
    """
    if not is_enabled():
        return {
            "success": False,
            "layer": "L4",
            "results": [],
            "error": "IMA 凭证未配置，跳过 L4 层",
        }

    body = {"query": query, "limit": limit}

    try:
        result = _post("openapi/v1/notes/search", body)
        return {
            "success": True,
            "layer": "L4",
            "results": result.get("data", {}).get("docs", []),
            "error": None,
        }
    except Exception as e:
        return {
            "success": False,
            "layer": "L4",
            "results": [],
            "error": str(e),
        }


def _add_to_retry_queue(title: str, content: str, tags: list):
    """失败时添加到重试队列"""
    SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    retry_path = os.path.join(SKILL_DIR, ".retry_queue.json")
    retry_queue = []
    if os.path.exists(retry_path):
        try:
            with open(retry_path, "r", encoding="utf-8") as f:
                retry_queue = json.load(f)
        except Exception:
            pass

    retry_queue.append({
        "title": title,
        "content": content,
        "tags": tags,
        "timestamp": time.time(),
        "layer": "L4",
    })

    with open(retry_path, "w", encoding="utf-8") as f:
        json.dump(retry_queue, f, ensure_ascii=False)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python L4_ima.py <write|search> <标题> [内容]")
        sys.exit(1)

    action = sys.argv[1]
    title = sys.argv[2] if len(sys.argv) > 2 else ""
    content = sys.argv[3] if len(sys.argv) > 3 else title

    if action == "write":
        result = write_note(title, content)
    elif action == "search":
        result = search_notes(title)
    else:
        print(f"未知动作: {action}")
        sys.exit(1)

    print(json.dumps(result, ensure_ascii=False, indent=2))
