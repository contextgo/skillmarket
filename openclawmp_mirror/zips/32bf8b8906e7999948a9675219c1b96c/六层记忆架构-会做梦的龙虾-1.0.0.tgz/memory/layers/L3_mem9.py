"""
L3 mem9 云端向量层
通过 mem9 REST API 写入记忆，带语义检索能力

依赖: MEM9_API_KEY 环境变量（Skill 源码不包含任何 Key）
"""

import sys
import os
import json
import time
import hashlib

MEM9_API_URL = "https://api.mem9.ai/v1alpha2"


def get_api_key():
    """从环境变量获取 mem9 API Key"""
    return os.environ.get("MEM9_API_KEY", "")


def is_enabled():
    """检查是否配置了 mem9"""
    return bool(get_api_key())


def _headers():
    return {
        "X-API-Key": get_api_key(),
        "Content-Type": "application/json",
    }


def write(content: str, memory_id: str = None, tags: list = None) -> dict:
    """
    写入一条记忆到 mem9

    参数:
        content: 记忆内容
        memory_id: 可选，指定 memory ID（用于更新）
        tags: 标签

    返回:
        {
            "success": bool,
            "layer": "L3",
            "memory_id": str,
            "error": str or None
        }
    """
    if not is_enabled():
        return {
            "success": False,
            "layer": "L3",
            "memory_id": None,
            "error": "MEM9_API_KEY 未配置，跳过 L3 层",
        }

    if memory_id is None:
        memory_id = hashlib.sha256(content.encode("utf-8")).hexdigest()[:16]

    payload = {"id": memory_id, "content": content}
    if tags:
        payload["tags"] = tags

    try:
        import urllib.request

        req = urllib.request.Request(
            f"{MEM9_API_URL}/mem9s",
            data=json.dumps(payload).encode("utf-8"),
            headers=_headers(),
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return {
                "success": True,
                "layer": "L3",
                "memory_id": result.get("id", memory_id),
                "error": None,
            }
    except Exception as e:
        _add_to_retry_queue(content, memory_id, tags)
        return {
            "success": False,
            "layer": "L3",
            "memory_id": memory_id,
            "error": str(e),
        }


def search(query: str, limit: int = 5) -> dict:
    """
    语义检索 mem9 记忆
    """
    if not is_enabled():
        return {
            "success": False,
            "layer": "L3",
            "results": [],
            "error": "MEM9_API_KEY 未配置，跳过 L3 层",
        }

    try:
        import urllib.request

        payload = {"query": query, "limit": limit, "hybrid": True}
        req = urllib.request.Request(
            f"{MEM9_API_URL}/mem9s/search",
            data=json.dumps(payload).encode("utf-8"),
            headers=_headers(),
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return {
                "success": True,
                "layer": "L3",
                "results": result.get("results", []),
                "error": None,
            }
    except Exception as e:
        return {
            "success": False,
            "layer": "L3",
            "results": [],
            "error": str(e),
        }


def _add_to_retry_queue(content: str, memory_id: str, tags: list):
    """失败时添加到重试队列"""
    SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    retry_path = os.path.join(SKILL_DIR, ".retry_queue.json")
    retry_queue = []
    if os.path.exists(retry_path):
        try:
            with open(retry_path, "r", encoding="utf-8") as f:
                retry_queue = json.load(f)
        except Exception:
            pass

    retry_queue.append({
        "content": content,
        "memory_id": memory_id,
        "tags": tags,
        "timestamp": time.time(),
        "layer": "L3",
    })

    with open(retry_path, "w", encoding="utf-8") as f:
        json.dump(retry_queue, f, ensure_ascii=False)


def health_check() -> dict:
    """健康检查"""
    if not is_enabled():
        return {"ok": False, "reason": "MEM9_API_KEY 未配置"}

    try:
        import urllib.request

        req = urllib.request.Request(
            f"{MEM9_API_URL}/mem9s?limit=1",
            headers=_headers(),
            method="GET",
        )
        with urllib.request.urlopen(req, timeout=10) as resp:
            return {"ok": True, "status_code": resp.status}
    except Exception as e:
        return {"ok": False, "reason": str(e)}


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python L3_mem9.py <write|search|health> [内容]")
        sys.exit(1)

    action = sys.argv[1]
    content = sys.argv[2] if len(sys.argv) > 2 else ""

    if action == "write":
        result = write(content)
    elif action == "search":
        result = search(content)
    elif action == "health":
        result = health_check()
    else:
        print(f"未知动作: {action}")
        sys.exit(1)

    print(json.dumps(result, ensure_ascii=False, indent=2))
