"""
L2 PARA 本地层
直接调用 router.py 的 write_memory
"""

import sys
import os
import json

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# 引用同目录的 router
import router

MEMORY_LAYER = "L2"


def write(content: str, para_type: str = None, tags: list = None) -> dict:
    """
    写入 L2 PARA 本地层

    参数:
        content: 记忆内容
        para_type: PARA 分类，默认由 router 自动推断
        tags: 标签列表

    返回:
        {
            "success": bool,
            "layer": "L2",
            "para_type": str,
            "file_path": str,
            "error": str or None
        }
    """
    return router.write_memory(content=content, para_type=para_type, tags=tags)


def read_today(para_type: str = None) -> list:
    """
    读取今天的记忆条目

    参数:
        para_type: 过滤特定 PARA 类型，None 则读所有层
    """
    from datetime import datetime

    today = datetime.now().strftime("%Y-%m-%d")
    entries = []

    para_dirs = router.PARA_DIRS if para_type is None else {para_type: router.PARA_DIRS.get(para_type)}

    for ptype, dir_path in para_dirs.items():
        if not os.path.exists(dir_path):
            continue
        day_file = os.path.join(dir_path, f"{today}.md")
        if os.path.exists(day_file):
            try:
                with open(day_file, "r", encoding="utf-8") as f:
                    entries.append({"para_type": ptype, "content": f.read()})
            except Exception:
                pass

    return entries


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python L2_para.py <记忆内容>")
        sys.exit(1)

    content = sys.argv[1]
    para_type = sys.argv[2] if len(sys.argv) > 2 else None
    result = write(content, para_type)
    print(json.dumps(result, ensure_ascii=False, indent=2))
