"""
L5 庄周梦蝶 — 定时记忆整理层
凌晨 03:30 自动运行，对 L2/L3/L4 的记忆进行整理

功能：
1. 去重（同一信息出现 >= 3 次 → 合并）
2. 降噪（30 天未调用的记忆 → 权重 -1，沉寂标记）
3. 刷新（过时内容 → 用最新状态重写）
4. 评分（调用次数 +1，权重低于阈值 → 移入 archive）
5. 纠错信号处理（用户纠正 Agent → 权重 -3，标记可疑）

此模块由 scripts/zhuangzhou_run.py 定时调用，或手动触发
"""

import os
import sys
import json
import re
import hashlib
from datetime import datetime, timedelta
from difflib import SequenceMatcher

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
WORKSPACE_ROOT = os.path.dirname(SKILL_DIR)
MEMORY_ROOT = os.path.join(WORKSPACE_ROOT, ".workbuddy", "memory")
PARA_DIRS = {
    "projects": os.path.join(MEMORY_ROOT, "projects"),
    "areas": os.path.join(MEMORY_ROOT, "areas"),
    "resources": os.path.join(MEMORY_ROOT, "resources"),
    "archive": os.path.join(MEMORY_ROOT, "archive"),
}

# 权重衰减阈值
WEIGHT_DECAY_THRESHOLD = -5  # 权重低于此值 → 移入 archive
SILENCE_DAYS = 30  # 30 天未调用 → 沉寂
DUPLICATE_SIMILARITY = 0.85  # 相似度阈值 → 合并
CORRECTION_PENALTY = 3  # 纠错一次 → 权重 -3


class MemoryEntry:
    """单条记忆条目"""

    def __init__(self, content: str, source_file: str, para_type: str, timestamp: str = None):
        self.content = content.strip()
        self.source_file = source_file
        self.para_type = para_type
        self.timestamp = timestamp or datetime.now().isoformat()
        self.weight = 0  # 调用权重
        self.silence_days = 0  # 沉寂天数
        self.is_suspicious = False  # 可疑标记
        self.call_count = 0  # 调用次数

    def to_dict(self):
        return {
            "content": self.content,
            "source_file": self.source_file,
            "para_type": self.para_type,
            "timestamp": self.timestamp,
            "weight": self.weight,
            "silence_days": self.silence_days,
            "is_suspicious": self.is_suspicious,
            "call_count": self.call_count,
        }


def scan_memory_files(para_dir: str) -> list:
    """扫描指定 PARA 目录下的所有 .md 文件，提取记忆条目"""
    entries = []
    if not os.path.exists(para_dir):
        return entries

    for filename in os.listdir(para_dir):
        if not filename.endswith(".md"):
            continue
        filepath = os.path.join(para_dir, filename)
        para_type = os.path.basename(os.path.dirname(filepath))

        try:
            with open(filepath, "r", encoding="utf-8") as f:
                content = f.read()
                # 按 "---" 分割条目
                blocks = re.split(r"\n---\n", content)
                for block in blocks:
                    block = block.strip()
                    if len(block) < 10:
                        continue
                    # 提取时间戳 [YYYY-MM-DD HH:MM:SS]
                    ts_match = re.search(r"\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\]", block)
                    ts = ts_match.group(1) if ts_match else filename.replace(".md", "")
                    entries.append(MemoryEntry(block, filepath, para_type, ts))
        except Exception:
            pass

    return entries


def similarity(a: str, b: str) -> float:
    """计算两段文字的相似度"""
    return SequenceMatcher(None, a, b).ratio()


def deduplicate(entries: list) -> list:
    """去重：合并高度相似的记忆"""
    unique = []
    for entry in entries:
        is_dup = False
        for u in unique:
            if similarity(entry.content, u.content) > DUPLICATE_SIMILARITY:
                # 保留时间更新的，删除旧的
                if entry.timestamp > u.timestamp:
                    u.content = entry.content
                    u.timestamp = entry.timestamp
                is_dup = True
                break
        if not is_dup:
            unique.append(entry)
    return unique


def apply_decay(entries: list) -> list:
    """降噪：30 天未调用 → 权重衰减"""
    now = datetime.now()
    for entry in entries:
        try:
            last_call = datetime.fromisoformat(entry.timestamp)
            silence_days = (now - last_call).days
            if silence_days >= SILENCE_DAYS:
                entry.weight -= 1
                entry.silence_days = silence_days
        except Exception:
            pass
    return entries


def apply_correction_signal(entries: list, correction_signals: list) -> list:
    """处理纠错信号：用户纠正 Agent → 权重 -3"""
    for signal in correction_signals:
        # 找到匹配的条目并降权
        for entry in entries:
            if signal.get("keyword") and signal["keyword"] in entry.content:
                entry.weight -= CORRECTION_PENALTY
                entry.is_suspicious = True
    return entries


def archive_low_weight(entries: list) -> list:
    """评分：权重低于阈值 → 移入 archive"""
    archived = []
    remaining = []
    for entry in entries:
        if entry.weight <= WEIGHT_DECAY_THRESHOLD:
            archived.append(entry)
        else:
            remaining.append(entry)
    return remaining, archived


def write_archived(entries: list):
    """将归档条目写入 archive 目录"""
    archive_dir = PARA_DIRS["archive"]
    os.makedirs(archive_dir, exist_ok=True)

    now_str = datetime.now().strftime("%Y-%m-%d")
    archive_file = os.path.join(archive_dir, f"{now_str}_zhuangzhou.md")

    content_lines = [f"# 庄周梦蝶归档 — {now_str}", ""]
    for entry in entries:
        content_lines.append(f"## [{entry.timestamp}] {entry.content[:60]}")
        content_lines.append(entry.content)
        content_lines.append(f"Weight: {entry.weight} | 来源: {entry.para_type}")
        content_lines.append("---")

    with open(archive_file, "w", encoding="utf-8") as f:
        f.write("\n".join(content_lines))

    return archive_file


def run_zhuangzhou() -> dict:
    """
    执行庄周梦蝶全流程

    返回:
        {
            "success": bool,
            "layer": "L5",
            "total_entries": int,
            "deduped": int,
            "archived": int,
            "report": str
        }
    """
    all_entries = []

    # 扫描所有 PARA 层（排除 archive 自身）
    for ptype, dir_path in PARA_DIRS.items():
        if ptype == "archive":
            continue
        all_entries.extend(scan_memory_files(dir_path))

    if not all_entries:
        return {
            "success": True,
            "layer": "L5",
            "total_entries": 0,
            "deduped": 0,
            "archived": 0,
            "report": "无记忆条目，庄周梦蝶无事可做",
        }

    total = len(all_entries)

    # Step 1: 去重
    all_entries = deduplicate(all_entries)
    deduped = total - len(all_entries)

    # Step 2: 降噪（沉寂衰减）
    all_entries = apply_decay(all_entries)

    # Step 3: 评分 & 归档
    remaining, to_archive = archive_low_weight(all_entries)

    archived_files = []
    if to_archive:
        af = write_archived(to_archive)
        archived_files.append(af)

    # Step 4: 生成整理报告
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    report_lines = [
        f"# 庄周梦蝶整理报告 — {now_str}",
        f"",
        f"扫描记忆条目: {total}",
        f"去重合并: {deduped}",
        f"权重衰减（沉寂）: {len([e for e in all_entries if e.weight < 0])}",
        f"归档低权重记忆: {len(to_archive)}",
        f"整理后保留: {len(remaining)}",
        f"",
    ]
    if archived_files:
        report_lines.append(f"归档文件: {', '.join(archived_files)}")

    report = "\n".join(report_lines)

    return {
        "success": True,
        "layer": "L5",
        "total_entries": total,
        "deduped": deduped,
        "archived": len(to_archive),
        "remaining": len(remaining),
        "report": report,
    }


if __name__ == "__main__":
    result = run_zhuangzhou()
    print(json.dumps(result, ensure_ascii=False, indent=2))
