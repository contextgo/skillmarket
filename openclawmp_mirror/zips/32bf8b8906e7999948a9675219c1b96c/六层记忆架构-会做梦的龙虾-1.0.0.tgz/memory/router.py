"""
记忆路由：根据内容推断写入哪个 PARA 层
L2 本地 PARA 层写入模块

分类规则：
- projects：包含项目关键词（开发/写/策划/执行/截止/deadline）或有明确动词+目标
- areas：包含长期领域词（研究/运营/管理/维护/持续）无截止日暗示
- resources：包含素材词（文章/资料/笔记/收藏/觉得有趣）
- archive：已完成的、或明确说"归档"的内容
"""

import json
import re
import sys
import os
from datetime import datetime

SKILL_DIR = os.path.dirname(os.path.abspath(__file__))
WORKSPACE_ROOT = os.path.dirname(os.path.dirname(SKILL_DIR))
PARA_MAP_PATH = os.path.join(SKILL_DIR, "para_map.json")
MEMORY_ROOT = os.path.join(WORKSPACE_ROOT, ".workbuddy", "memory")

# PARA 子目录
PARA_DIRS = {
    "projects": os.path.join(MEMORY_ROOT, "projects"),
    "areas": os.path.join(MEMORY_ROOT, "areas"),
    "resources": os.path.join(MEMORY_ROOT, "resources"),
    "archive": os.path.join(MEMORY_ROOT, "archive"),
}


def load_para_map():
    """加载 PARA 分类映射规则"""
    try:
        with open(PARA_MAP_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"projects": [], "areas": [], "resources": [], "archive": []}


def ensure_para_dirs():
    """确保所有 PARA 目录存在"""
    for para_type, dir_path in PARA_DIRS.items():
        os.makedirs(dir_path, exist_ok=True)


def route(content: str, explicit_type: str = None) -> str:
    """
    根据内容判断 PARA 分类

    参数:
        content: 记忆内容
        explicit_type: 显式指定的类型（如用户说「记到 projects 里」）
    返回:
        para_type: projects | areas | resources | archive
    """
    # 优先级1：显式指定
    if explicit_type and explicit_type in PARA_DIRS:
        return explicit_type

    # 优先级2：从内容关键词推断
    para_map = load_para_map()
    content_lower = content.lower()

    scores = {"projects": 0, "areas": 0, "resources": 0, "archive": 0}

    for keyword in para_map.get("projects", []):
        if keyword in content_lower:
            scores["projects"] += 1

    for keyword in para_map.get("areas", []):
        if keyword in content_lower:
            scores["areas"] += 1

    for keyword in para_map.get("resources", []):
        if keyword in content_lower:
            scores["resources"] += 1

    # archive 特殊：直接匹配
    archive_indicators = ["归档", "archive", "已完成", "停更", "废弃", "完成"]
    for indicator in archive_indicators:
        if indicator in content:
            scores["archive"] += 10  # 高权重
            break

    # 正则额外检测 projects（有动词+宾语结构）
    project_patterns = [
        r"写\d+篇",
        r"开发.+skill",
        r"完成.+截止",
        r"截止日期",
        r"deadline",
        r"发布.+\d+月",
        r"策划.+(活动|专题|内容)",
    ]
    for pattern in project_patterns:
        if re.search(pattern, content_lower):
            scores["projects"] += 3

    # 得分最高者
    winner = max(scores, key=lambda k: scores[k])
    if scores[winner] > 0:
        return winner

    # 默认：projects（当前项目）
    return "projects"


def write_memory(content: str, para_type: str = None, tags: list = None) -> dict:
    """
    将记忆写入本地 PARA 层

    返回:
        {
            "success": bool,
            "layer": "L2",
            "para_type": str,
            "file_path": str,
            "error": str or None
        }
    """
    ensure_para_dirs()

    if para_type is None:
        para_type = route(content)

    if tags is None:
        tags = []

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    date_str = datetime.now().strftime("%Y-%m-%d")

    # 文件名：按日期分文件，同一天多次写入追加
    memory_file = os.path.join(PARA_DIRS[para_type], f"{date_str}.md")

    # 构建写入内容块
    entry = f"\n## [{timestamp}] {content[:60]}{'...' if len(content) > 60 else ''}\n\n{content}\n\n"
    if tags:
        entry += f"Tags: {', '.join(tags)}\n\n"
    entry += "---\n"

    try:
        with open(memory_file, "a", encoding="utf-8") as f:
            f.write(entry)

        return {
            "success": True,
            "layer": "L2",
            "para_type": para_type,
            "file_path": memory_file,
            "error": None,
        }
    except Exception as e:
        return {
            "success": False,
            "layer": "L2",
            "para_type": para_type,
            "file_path": memory_file,
            "error": str(e),
        }


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python router.py <记忆内容>")
        sys.exit(1)

    content = sys.argv[1]
    para_type = sys.argv[2] if len(sys.argv) > 2 else None
    result = write_memory(content, para_type)
    print(json.dumps(result, ensure_ascii=False, indent=2))
