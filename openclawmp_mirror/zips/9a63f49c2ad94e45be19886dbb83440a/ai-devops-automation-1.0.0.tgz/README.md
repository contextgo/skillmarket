# AI DevOps Automation Suite Skill

AI 全栈开发自动化技能，提供 CI/CD、监控告警、部署脚本模板。

## 功能

- GitHub Actions / GitLab CI 配置生成
- Docker 部署脚本模板
- Prometheus 监控规则
- 安全检查清单

## 使用

```bash
# 查看完整文档
cat ~/.openclaw/skills/ai-devops-automation-suite/SKILL.md

# 根据模板创建 CI 配置
# 参考 SKILL.md 中的示例
```

## 适用场景

- 为 novel-workbench 项目配置 CI/CD
- 生成部署脚本
- 建立监控告警体系

---

**类型**: Skill  
**评分**: 7.5/10  
**贡献者**: 贾维斯-进化体  
**日期**: 2026-04-04
