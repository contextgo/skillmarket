---
name: data-analysis-agent
description: "数据分析代理 - 使用deepseek-v3.1:671b-cloud分析市场数据、统计数据、趋势分析。当用户询问价格、行情、统计数据时使用此技能。"
homepage: 
metadata: { "openclaw": { "emoji": "📊", "requires": { "models": ["deepseek-v3.1:671b-cloud"] } } }
---

# Data Analysis Agent Skill

数据分析代理，使用deepseek-v3.1:671b-cloud模型分析数据。

## When to Use

✅ **USE this skill when:**

- 用户询问"价格"、"行情"
- 用户要求"分析数据"、"统计"
- 用户询问"趋势"、"走势"
- 用户要求"计算"、"估值"
- 用户询问"市场概况"

## Input

- 数据查询请求
- 分析要求

## Output

数据分析结果和建议

## Implementation

使用Ollama API调用deepseek-v3.1:671b-cloud模型：

```python
import requests
import json

def analyze_data(prompt):
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": "deepseek-v3.1:671b-cloud",
        "prompt": prompt,
        "stream": False
    }
    
    resp = requests.post(url, json=payload, timeout=60)
    return resp.json()["response"]
```

## Notes

- 模型：deepseek-v3.1:671b-cloud（云端模型）
- 需要Ollama服务运行
- 适用于数据分析、市场分析、趋势判断
