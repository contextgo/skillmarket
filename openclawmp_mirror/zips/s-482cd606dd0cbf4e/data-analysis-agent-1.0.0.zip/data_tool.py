#!/usr/bin/env python3
"""
数据分析代理工具
用法: python3 data_tool.py <分析请求>
"""

import sys
import requests
import json

MODEL = "deepseek-v3.1:671b-cloud"
OLLAMA_URL = "http://localhost:11434/api/generate"

def analyze_data(prompt):
    """调用deepseek分析数据"""
    
    payload = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False
    }
    
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
        result = resp.json()
        return result.get("response", "错误：无响应")
    except Exception as e:
        return f"错误：{e}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 data_tool.py <分析请求>")
        print("示例: python3 data_tool.py '分析当前BTC价格趋势'")
        sys.exit(1)
    
    prompt = " ".join(sys.argv[1:])
    
    print(f"📊 正在分析: {prompt}")
    print("-" * 50)
    
    result = analyze_data(prompt)
    print(result)
