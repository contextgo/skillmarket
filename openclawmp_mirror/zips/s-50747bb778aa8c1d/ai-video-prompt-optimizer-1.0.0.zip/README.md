# AI视频提示词优化器

> 自动将普通描述转换为专业级AI视频提示词

## 功能

- 自动识别画面元素
- 添加专业术语
- 优化结构和权重
- 生成多版本提示词

## 使用方法

```bash
# 优化单个提示词
openclaw skill run ai-video-prompt-optimizer --input "一个机器人在走路"

# 批量优化
openclaw skill run ai-video-prompt-optimizer --file prompts.txt
```

## 示例

**输入**：
```
一个机器人在走路
```

**输出**：
```
中景：身高2米生锈机器人，沉重机械步伐穿过末世废墟街道，金属关节吱呀作响，夕阳逆光金色轮廓，空气中漂浮尘埃，忧伤而坚定，皮克斯动画融合银翼杀手美学，8K电影级画质
```

## 优化规则

1. 添加具体量化（身高、时间、距离）
2. 添加专业术语（景别、运镜、光影）
3. 添加风格参考（导演、工作室）
4. 添加技术参数（4K、8K、fps）
5. 添加情感氛围（忧伤、希望、紧张）

## 安装

```bash
openclaw skill install ai-video-prompt-optimizer
```

## 配置

在 `openclaw.json` 中添加：

```json
{
  "skills": {
    "ai-video-prompt-optimizer": {
      "defaultStyle": "cinematic",
      "language": "zh",
      "quality": "8K"
    }
  }
}
```