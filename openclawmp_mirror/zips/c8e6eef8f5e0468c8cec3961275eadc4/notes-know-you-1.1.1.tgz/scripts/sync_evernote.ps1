#Requires -Version 7.0
<#
.SYNOPSIS
    Sync Evernote notes to local Markdown files
.DESCRIPTION
    This script performs a full sync from Evernote/Yinxiang to local Markdown:
    1. Sync from Evernote cloud to local database
    2. Export ENEX files from database
    3. Convert ENEX to separate Markdown files per note
    4. Organize by category/notebook structure (including empty notebooks)
#>

param(
    [string]$DbPath = $env:NOTES_DB_PATH,
    [string]$ExportDir = $env:NOTES_EXPORT_DIR,
    [string]$Backend = $env:NOTES_BACKEND,
    [string]$Token = $env:NOTES_TOKEN,
    [string]$PythonPath = "C:\Users\EMan\AppData\Local\Microsoft\WindowsApps\python.exe"
)

# Ensure pandoc is in PATH
$pandocPath = "C:\Users\EMan\AppData\Local\Microsoft\WinGet\Packages\JohnMacFarlane.Pandoc_Microsoft.Winget.Source_8wekyb3d8bbwe\pandoc-3.9.0.2"
if (Test-Path $pandocPath) {
    $env:Path = "$pandocPath;$env:Path"
}

# Validate parameters
if (-not $DbPath) { throw "NOTES_DB_PATH not set" }
if (-not $ExportDir) { $ExportDir = (Split-Path $DbPath -Parent) + "\markdown" }
if (-not $Backend) { $Backend = "china" }

$enexDir = Join-Path (Split-Path $ExportDir -Parent) "enex"
$scriptDir = Split-Path $MyInvocation.MyCommand.Path -Parent

Write-Host "=== Evernote Sync Started ===" -ForegroundColor Cyan
Write-Host "Database: $DbPath"
Write-Host "Export Dir: $ExportDir"
Write-Host "ENEX Dir: $enexDir"
Write-Host "Python: $PythonPath"
Write-Host ""

# Step 1: Sync from Evernote
Write-Host "Step 1: Syncing from Evernote..." -ForegroundColor Yellow
$syncArgs = @("-m", "evernote_backup", "sync", "-d", $DbPath)
if ($Token) {
    # Use reauth if token provided and sync might fail
    & $PythonPath -m evernote_backup reauth -d $DbPath -t $Token 2>$null
}
& $PythonPath @syncArgs
if ($LASTEXITCODE -ne 0) {
    throw "Sync failed with exit code $LASTEXITCODE"
}

# Step 2: Export to ENEX
Write-Host ""
Write-Host "Step 2: Exporting to ENEX..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $enexDir -Force | Out-Null

# Clean up old ENEX files (recursively including subdirectories)
$oldEnexFiles = Get-ChildItem -Path $enexDir -Filter "*.enex" -Recurse -ErrorAction SilentlyContinue
if ($oldEnexFiles) {
    Write-Host "  Cleaning up $($oldEnexFiles.Count) old ENEX file(s)..." -ForegroundColor Gray
    $oldEnexFiles | Remove-Item -Force
    
    # Also remove empty subdirectories
    $subdirs = Get-ChildItem -Path $enexDir -Directory -Recurse -ErrorAction SilentlyContinue
    foreach ($dir in $subdirs) {
        if ((Get-ChildItem -Path $dir.FullName -Recurse -ErrorAction SilentlyContinue).Count -eq 0) {
            Remove-Item -Path $dir.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

& $PythonPath -m evernote_backup export -d $DbPath $enexDir
if ($LASTEXITCODE -ne 0) {
    throw "Export failed with exit code $LASTEXITCODE"
}

# Step 3: Get all notebooks from database (including empty ones)
Write-Host ""
Write-Host "Step 3: Reading notebook list from database..." -ForegroundColor Yellow

$tempJsonFile = Join-Path $env:TEMP "evernote_notebooks_$(Get-Random).json"

$pythonScript = @"
import sqlite3
import json
import sys

db_path = sys.argv[1]
output_file = sys.argv[2]
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

cursor.execute('''
SELECT n.name, n.stack, COUNT(n2.notebook_guid) as note_count
FROM notebooks n
LEFT JOIN notes n2 ON n.guid = n2.notebook_guid AND n2.is_active = 1
GROUP BY n.guid, n.name, n.stack
ORDER BY n.name
''')

notebooks = []
for row in cursor.fetchall():
    notebooks.append({
        'name': row[0],
        'stack': row[1] if row[1] else '',
        'note_count': row[2]
    })

with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(notebooks, f, ensure_ascii=False)
conn.close()
"@

& $PythonPath -c $pythonScript $DbPath $tempJsonFile
$allNotebooks = Get-Content $tempJsonFile -Encoding UTF8 | ConvertFrom-Json
Remove-Item $tempJsonFile -ErrorAction SilentlyContinue

# Clean and recreate markdown directory
Remove-Item -Path $ExportDir -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $ExportDir -Force | Out-Null

$totalNotes = 0
$notebookCount = 0
$emptyNotebookCount = 0

# Step 4: Convert to Markdown
Write-Host ""
Write-Host "Step 4: Converting to Markdown..." -ForegroundColor Yellow

# Process all notebooks from database
foreach ($notebook in $allNotebooks) {
    $notebookName = $notebook.name
    $stack = $notebook.stack
    $noteCount = $notebook.note_count
    
    # Determine target directory based on stack
    if ($stack) {
        # Use stack name as category directory
        $catDir = Join-Path $ExportDir $stack
        New-Item -ItemType Directory -Path $catDir -Force | Out-Null
        $targetDir = $catDir
    } else {
        # No stack - treat as root-level
        $targetDir = $ExportDir
    }
    
    # Check if there's an ENEX file for this notebook
    $enexFileName = "$notebookName.enex"
    $enexFile = $null
    
    if ($stack -and (Test-Path (Join-Path $enexDir $stack))) {
        $enexFile = Get-ChildItem (Join-Path $enexDir $stack) -Filter $enexFileName -ErrorAction SilentlyContinue | Select-Object -First 1
    } else {
        $enexFile = Get-ChildItem $enexDir -Filter $enexFileName -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    
    if ($enexFile -and $enexFile.Name -notmatch "\(\d+\)\.enex$") {
        # Has ENEX file - convert it
        Write-Host "  Converting: $notebookName ($noteCount notes)" -ForegroundColor Gray
        
        $output = & python3 (Join-Path $scriptDir "enex_to_markdown_separate.py") $enexFile.FullName $targetDir 2>&1
        Write-Host "    $output" -ForegroundColor DarkGray
        
        if ($output -match "Converted (\d+) notes") {
            $totalNotes += [int]$matches[1]
            $notebookCount++
        }
    } elseif ($noteCount -eq 0) {
        # Empty notebook - create empty folder
        $notebookDir = Join-Path $targetDir $notebookName
        New-Item -ItemType Directory -Path $notebookDir -Force | Out-Null
        Write-Host "  Created empty notebook: $notebookName" -ForegroundColor DarkGray
        $emptyNotebookCount++
        $notebookCount++
    }
}

# Summary
Write-Host ""
Write-Host "=== Sync Complete ===" -ForegroundColor Green
Write-Host "Total notebooks: $notebookCount"
Write-Host "  - With notes: $($notebookCount - $emptyNotebookCount)"
Write-Host "  - Empty: $emptyNotebookCount"
Write-Host "Total notes: $totalNotes"
Write-Host "Export directory: $ExportDir"

# Update config with sync stats
$configPath = Join-Path (Split-Path $scriptDir -Parent) "config.json"
if (Test-Path $configPath) {
    try {
        $config = Get-Content $configPath -Raw | ConvertFrom-Json
        $config.last_sync_time = (Get-Date -Format "yyyy-MM-dd HH:mm:ss")
        $config.sync_count = ($config.sync_count + 1)
        $config | ConvertTo-Json -Depth 10 | Set-Content $configPath -Encoding UTF8
    }
    catch {
        Write-Warning "Failed to update config file: $_"
    }
}

# Return statistics for further processing
@{
    Notebooks = $notebookCount
    EmptyNotebooks = $emptyNotebookCount
    TotalNotes = $totalNotes
    ExportDir = $ExportDir
    ConfigPath = $configPath
} | ConvertTo-Json -Compress
