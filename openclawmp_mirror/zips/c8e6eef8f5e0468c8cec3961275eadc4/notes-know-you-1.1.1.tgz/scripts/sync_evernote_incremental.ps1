#Requires -Version 7.0
<#
.SYNOPSIS
    Incremental sync Evernote notes to local Markdown files
.DESCRIPTION
    This script performs incremental sync from Evernote/Yinxiang to local Markdown:
    1. Sync from Evernote cloud to local database
    2. Export only recently updated notes (default: 7 days)
    3. Convert new/updated ENEX to separate Markdown files
    4. Skip unchanged notebooks for faster sync
#>

param(
    [string]$DbPath = $env:NOTES_DB_PATH,
    [string]$ExportDir = $env:NOTES_EXPORT_DIR,
    [string]$Backend = $env:NOTES_BACKEND,
    [string]$Token = $env:NOTES_TOKEN,
    [string]$PythonPath = "C:\Users\EMan\AppData\Local\Microsoft\WindowsApps\python.exe",
    [int]$DaysBack = 7,  # Only process notes updated in last N days
    [switch]$FullSync = $false  # Force full sync if needed
)

# Ensure pandoc is in PATH
$pandocPath = "C:\Users\EMan\AppData\Local\Microsoft\WinGet\Packages\JohnMacFarlane.Pandoc_Microsoft.Winget.Source_8wekyb3d8bbwe\pandoc-3.9.0.2"
if (Test-Path $pandocPath) {
    $env:Path = "$pandocPath;$env:Path"
}

# Validate parameters
if (-not $DbPath) { throw "NOTES_DB_PATH not set" }
if (-not $ExportDir) { $ExportDir = (Split-Path $DbPath -Parent) + "\markdown" }
if (-not $Backend) { $Backend = "china" }

$enexDir = Join-Path (Split-Path $ExportDir -Parent) "enex"
$scriptDir = Split-Path $MyInvocation.MyCommand.Path -Parent
$stateFile = Join-Path (Split-Path $ExportDir -Parent) ".sync_state.json"

Write-Host "=== Evernote Incremental Sync Started ===" -ForegroundColor Cyan
Write-Host "Database: $DbPath"
Write-Host "Export Dir: $ExportDir"
Write-Host "ENEX Dir: $enexDir"
Write-Host "Days Back: $DaysBack"
Write-Host "Full Sync: $FullSync"
Write-Host ""

# Calculate cutoff date
$cutoffDate = (Get-Date).AddDays(-$DaysBack)
$cutoffTimestamp = [int64]($cutoffDate.ToUniversalTime() - [datetime]'1970-01-01').TotalMilliseconds

Write-Host "Processing notes updated since: $($cutoffDate.ToString('yyyy-MM-dd HH:mm:ss'))" -ForegroundColor Gray

# Step 1: Sync from Evernote
Write-Host ""
Write-Host "Step 1: Syncing from Evernote..." -ForegroundColor Yellow
$syncArgs = @("-m", "evernote_backup", "sync", "-d", $DbPath)
if ($Token) {
    & $PythonPath -m evernote_backup reauth -d $DbPath -t $Token 2>$null
}
& $PythonPath @syncArgs
if ($LASTEXITCODE -ne 0) {
    throw "Sync failed with exit code $LASTEXITCODE"
}

# Step 2: Get notebooks and deleted notes from database
Write-Host ""
Write-Host "Step 2: Reading notebooks from database..." -ForegroundColor Yellow

$tempJsonFile = Join-Path $env:TEMP "evernote_notebooks_$(Get-Random).json"
$deletedNotesFile = Join-Path $env:TEMP "evernote_deleted_$(Get-Random).json"

$pythonScript = @"
import sqlite3
import json
import sys

db_path = sys.argv[1]
output_file = sys.argv[2]
deleted_file = sys.argv[3]

conn = sqlite3.connect(db_path)
cursor = conn.cursor()

# Get all notebooks with note counts
cursor.execute('''
    SELECT n.name, n.stack, COUNT(n2.notebook_guid) as note_count
    FROM notebooks n
    LEFT JOIN notes n2 ON n.guid = n2.notebook_guid AND n2.is_active = 1
    GROUP BY n.guid, n.name, n.stack
    ORDER BY n.name
''')

notebooks = []
for row in cursor.fetchall():
    notebooks.append({
        'name': row[0],
        'stack': row[1] if row[1] else '',
        'note_count': row[2]
    })

with open(output_file, 'w', encoding='utf-8') as f:
    json.dump(notebooks, f, ensure_ascii=False)

# Get recently deleted notes (inactive notes)
cursor.execute('''
    SELECT n.title, n.notebook_guid, nb.name as notebook_name, nb.stack
    FROM notes n
    JOIN notebooks nb ON n.notebook_guid = nb.guid
    WHERE n.is_active = 0
''')

deleted_notes = []
for row in cursor.fetchall():
    deleted_notes.append({
        'title': row[0],
        'notebook_guid': row[1],
        'notebook_name': row[2],
        'stack': row[3] if row[3] else ''
    })

with open(deleted_file, 'w', encoding='utf-8') as f:
    json.dump(deleted_notes, f, ensure_ascii=False)

conn.close()

print(f'Found {len(notebooks)} notebooks total', file=sys.stderr)
print(f'Found {len(deleted_notes)} deleted notes', file=sys.stderr)
"@

& $PythonPath -c $pythonScript $DbPath $tempJsonFile $deletedNotesFile
$allNotebooks = Get-Content $tempJsonFile -Encoding UTF8 | ConvertFrom-Json
$deletedNotes = Get-Content $deletedNotesFile -Encoding UTF8 | ConvertFrom-Json
Remove-Item $tempJsonFile -ErrorAction SilentlyContinue
Remove-Item $deletedNotesFile -ErrorAction SilentlyContinue

Write-Host "  Found $($allNotebooks.Count) notebooks total" -ForegroundColor Gray
Write-Host "  Found $($deletedNotes.Count) deleted notes in database" -ForegroundColor Gray

# Filter notebooks for incremental sync
$notebooksToProcess = @()
if ($FullSync) {
    $notebooksToProcess = $allNotebooks
    Write-Host "  Full sync mode: processing all notebooks" -ForegroundColor Gray
} else {
    # Check each notebook's markdown folder modification time
    foreach ($notebook in $allNotebooks) {
        $notebookName = $notebook.name
        $stack = $notebook.stack
        $noteCount = $notebook.note_count
        
        # Determine target directory
        if ($stack) {
            $targetDir = Join-Path $ExportDir $stack
        } else {
            $targetDir = $ExportDir
        }
        $notebookDir = Join-Path $targetDir $notebookName
        
        # Check if notebook needs update
        $needsUpdate = $false
        if ($noteCount -eq 0) {
            # Empty notebook - only create if folder doesn't exist
            if (-not (Test-Path $notebookDir)) {
                $needsUpdate = $true
            }
        } else {
            # Check if folder exists and has recent files
            if (Test-Path $notebookDir) {
                $recentFiles = Get-ChildItem -Path $notebookDir -Filter "*.md" -ErrorAction SilentlyContinue | 
                    Where-Object { $_.LastWriteTime -gt $cutoffDate }
                if (-not $recentFiles) {
                    $needsUpdate = $true
                }
            } else {
                $needsUpdate = $true
            }
        }
        
        if ($needsUpdate) {
            $notebooksToProcess += $notebook
        }
    }
    Write-Host "  Incremental mode: processing $($notebooksToProcess.Count) notebooks needing update" -ForegroundColor Gray
}

# Step 3: Export only needed notebooks to ENEX
Write-Host ""
Write-Host "Step 3: Exporting to ENEX (incremental)..." -ForegroundColor Yellow
New-Item -ItemType Directory -Path $enexDir -Force | Out-Null

# Clean up old ENEX files (recursively including subdirectories)
$oldEnexFiles = Get-ChildItem -Path $enexDir -Filter "*.enex" -Recurse -ErrorAction SilentlyContinue
if ($oldEnexFiles) {
    Write-Host "  Cleaning up $($oldEnexFiles.Count) old ENEX file(s)..." -ForegroundColor Gray
    $oldEnexFiles | Remove-Item -Force
    
    # Also remove empty subdirectories
    $subdirs = Get-ChildItem -Path $enexDir -Directory -Recurse -ErrorAction SilentlyContinue
    foreach ($dir in $subdirs) {
        if ((Get-ChildItem -Path $dir.FullName -Recurse -ErrorAction SilentlyContinue).Count -eq 0) {
            Remove-Item -Path $dir.FullName -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
}

# Export only if we have notebooks to process
$hasWorkToDo = $notebooksToProcess.Count -gt 0 -or $deletedNotes.Count -gt 0
if (-not $hasWorkToDo) {
    Write-Host "  No work needed. Sync complete!" -ForegroundColor Green
    exit 0
}

if ($notebooksToProcess.Count -eq 0) {
    Write-Host "  No notebooks need updating, but will clean up deleted notes." -ForegroundColor Gray
}

& $PythonPath -m evernote_backup export -d $DbPath $enexDir
if ($LASTEXITCODE -ne 0) {
    throw "Export failed with exit code $LASTEXITCODE"
}

# Step 4: Clean up deleted notes
Write-Host ""
Write-Host "Step 4: Cleaning up deleted notes..." -ForegroundColor Yellow

$deletedCount = 0
foreach ($deleted in $deletedNotes) {
    $title = $deleted.title
    $notebookName = $deleted.notebook_name
    $stack = $deleted.stack
    
    # Determine target directory
    if ($stack) {
        $targetDir = Join-Path $ExportDir $stack
    } else {
        $targetDir = $ExportDir
    }
    $notebookDir = Join-Path $targetDir $notebookName
    
    # Find and delete the markdown file for this note
    if (Test-Path $notebookDir) {
        # Try to find file by title pattern (notes are named: YYYY-MM-DD - Title.md)
        $safeTitle = $title -replace '[\\/:*?"<>|]', '_'
        $pattern = "* - $safeTitle.md"
        $files = Get-ChildItem -Path $notebookDir -Filter $pattern -ErrorAction SilentlyContinue
        
        foreach ($file in $files) {
            Write-Host "  Deleting: $($file.Name)" -ForegroundColor DarkGray
            $file | Remove-Item -Force
            $deletedCount++
        }
    }
}

if ($deletedCount -gt 0) {
    Write-Host "  Deleted $deletedCount note file(s)" -ForegroundColor Gray
} else {
    Write-Host "  No deleted notes to clean up" -ForegroundColor Gray
}

# Step 5: Convert to Markdown (incremental)
Write-Host ""
Write-Host "Step 5: Converting to Markdown (incremental)..." -ForegroundColor Yellow

# Ensure export directory exists (don't delete existing files)
New-Item -ItemType Directory -Path $ExportDir -Force | Out-Null

$totalNotes = 0
$notebookCount = 0
$emptyNotebookCount = 0
$skippedCount = 0

foreach ($notebook in $notebooksToProcess) {
    $notebookName = $notebook.name
    $stack = $notebook.stack
    $noteCount = $notebook.note_count
    $lastUpdated = $notebook.last_updated
    
    # Determine target directory
    if ($stack) {
        $catDir = Join-Path $ExportDir $stack
        New-Item -ItemType Directory -Path $catDir -Force | Out-Null
        $targetDir = $catDir
    } else {
        $targetDir = $ExportDir
    }
    
    # Check if there's an ENEX file
    $enexFileName = "$notebookName.enex"
    $enexFile = $null
    
    if ($stack -and (Test-Path (Join-Path $enexDir $stack))) {
        $enexFile = Get-ChildItem (Join-Path $enexDir $stack) -Filter $enexFileName -ErrorAction SilentlyContinue | Select-Object -First 1
    } else {
        $enexFile = Get-ChildItem $enexDir -Filter $enexFileName -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    
    if ($enexFile -and $enexFile.Name -notmatch "\(\d+\)\.enex$") {
        Write-Host "  Converting: $notebookName ($noteCount notes)" -ForegroundColor Gray
        
        $output = & python3 (Join-Path $scriptDir "enex_to_markdown_separate.py") $enexFile.FullName $targetDir 2>&1
        Write-Host "    $output" -ForegroundColor DarkGray
        
        if ($output -match "Converted (\d+) notes") {
            $totalNotes += [int]$matches[1]
            $notebookCount++
        }
    } elseif ($noteCount -eq 0) {
        # Empty notebook - create folder if not exists
        $notebookDir = Join-Path $targetDir $notebookName
        if (-not (Test-Path $notebookDir)) {
            New-Item -ItemType Directory -Path $notebookDir -Force | Out-Null
            Write-Host "  Created empty notebook: $notebookName" -ForegroundColor DarkGray
            $emptyNotebookCount++
        } else {
            $skippedCount++
        }
        $notebookCount++
    }
}

# Summary
Write-Host ""
Write-Host "=== Incremental Sync Complete ===" -ForegroundColor Green
Write-Host "Notebooks processed: $notebookCount"
Write-Host "  - With notes: $($notebookCount - $emptyNotebookCount)"
Write-Host "  - Empty: $emptyNotebookCount"
Write-Host "  - Skipped (already exists): $skippedCount"
Write-Host "Total notes converted: $totalNotes"
Write-Host "Export directory: $ExportDir"

# Save sync state
$syncState = @{
    LastSync = (Get-Date).ToString('o')
    NotebooksProcessed = $notebookCount
    NotesConverted = $totalNotes
    DaysBack = $DaysBack
} | ConvertTo-Json

$syncState | Out-File -FilePath $stateFile -Encoding UTF8

# Return statistics
@{
    Notebooks = $notebookCount
    EmptyNotebooks = $emptyNotebookCount
    Skipped = $skippedCount
    TotalNotes = $totalNotes
    ExportDir = $ExportDir
} | ConvertTo-Json -Compress
