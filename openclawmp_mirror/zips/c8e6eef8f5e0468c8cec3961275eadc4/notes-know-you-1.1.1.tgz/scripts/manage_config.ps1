#Requires -Version 7.0
<#
.SYNOPSIS
    Manage notes-know-you skill configuration
.DESCRIPTION
    This script manages the configuration for the notes-know-you skill,
    including the auto_update_ai_memory setting.
#>

param(
    [Parameter(Mandatory = $false)]
    [ValidateSet("show", "enable-auto-update", "disable-auto-update", "")]
    [string]$Action = "show"
)

$scriptDir = Split-Path $MyInvocation.MyCommand.Path -Parent
$skillDir = Split-Path $scriptDir -Parent
$configPath = Join-Path $skillDir "config.json"

# Default configuration
$defaultConfig = @{
    auto_update_ai_memory = $false
    last_sync_time = $null
    sync_count = 0
}

# Ensure config file exists
function Ensure-ConfigFile {
    if (-not (Test-Path $configPath)) {
        $defaultConfig | ConvertTo-Json -Depth 10 | Set-Content -Path $configPath -Encoding UTF8
        Write-Host "Created default config file at: $configPath" -ForegroundColor Yellow
    }
}

# Read config file
function Read-Config {
    Ensure-ConfigFile
    try {
        $content = Get-Content -Path $configPath -Raw -Encoding UTF8
        $config = $content | ConvertFrom-Json -AsHashtable
        # Ensure all default keys exist
        foreach ($key in $defaultConfig.Keys) {
            if (-not $config.ContainsKey($key)) {
                $config[$key] = $defaultConfig[$key]
            }
        }
        return $config
    }
    catch {
        Write-Warning "Failed to read config file, using defaults"
        return $defaultConfig.Clone()
    }
}

# Write config file
function Write-Config($config) {
    $config | ConvertTo-Json -Depth 10 | Set-Content -Path $configPath -Encoding UTF8
}

# Main logic
$config = Read-Config

switch ($Action) {
    "show" {
        $autoUpdateStatus = if ($config.auto_update_ai_memory) { "ON ✅" } else { "OFF ❌" }
        $lastSync = if ($config.last_sync_time) { $config.last_sync_time } else { "Never" }

        Write-Host ""
        Write-Host "📋 notes-know-you Configuration" -ForegroundColor Cyan
        Write-Host ""
        Write-Host "  Config file: $configPath" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Auto-update AI memory: $autoUpdateStatus" -ForegroundColor $(if ($config.auto_update_ai_memory) { "Green" } else { "Yellow" })
        Write-Host "  Last sync: $lastSync" -ForegroundColor Gray
        Write-Host "  Total syncs: $($config.sync_count)" -ForegroundColor Gray
        Write-Host ""
        Write-Host "  Commands:" -ForegroundColor Cyan
        Write-Host "    /notes-know-you config auto-update on   → Enable auto-update" -ForegroundColor Gray
        Write-Host "    /notes-know-you config auto-update off  → Disable auto-update" -ForegroundColor Gray
        Write-Host ""

        # Return config as JSON for programmatic use
        $config | ConvertTo-Json -Compress
    }

    "enable-auto-update" {
        $config.auto_update_ai_memory = $true
        Write-Config $config
        Write-Host ""
        Write-Host "✅ Auto-update enabled!" -ForegroundColor Green
        Write-Host ""
        Write-Host "The AI will now automatically update USER.md and Memory files after each sync." -ForegroundColor Gray
        Write-Host ""
    }

    "disable-auto-update" {
        $config.auto_update_ai_memory = $false
        Write-Config $config
        Write-Host ""
        Write-Host "✅ Auto-update disabled!" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "The AI will ask for confirmation before updating USER.md and Memory files." -ForegroundColor Gray
        Write-Host ""
    }
}
