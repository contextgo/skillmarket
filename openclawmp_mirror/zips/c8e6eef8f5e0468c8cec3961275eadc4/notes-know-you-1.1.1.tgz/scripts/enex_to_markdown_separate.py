"""
Convert ENEX file to separate Markdown files for each note.
Each note becomes its own .md file in a subdirectory named after the notebook.
"""
from __future__ import annotations

import argparse
import html
import io
import re
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

import chardet
from bs4 import BeautifulSoup


def detect_encoding(file_path: Path) -> str:
    """Detect file encoding using chardet."""
    with open(file_path, "rb") as f:
        raw_data = f.read()
        result = chardet.detect(raw_data)
        detected = result.get("encoding", "utf-8")
        confidence = result.get("confidence", 0)
        
        # For Chinese encodings (GBK/GB18030/GB2312), use even low confidence
        # as these encodings often have low detection confidence but are correct
        if detected and detected.lower() in ("gbk", "gb18030", "gb2312"):
            return detected
        
        # Fall back to utf-8 if confidence is too low for other encodings
        if confidence and confidence < 0.5:
            return "utf-8"
        return detected or "utf-8"


def read_enex_with_encoding(enex_path: Path) -> str:
    """Read ENEX file with automatic encoding detection."""
    encoding = detect_encoding(enex_path)
    try:
        with open(enex_path, "r", encoding=encoding) as f:
            return f.read()
    except UnicodeDecodeError:
        # Fallback to utf-8 if detected encoding fails
        with open(enex_path, "r", encoding="utf-8", errors="replace") as f:
            return f.read()


INVALID_FILENAME_CHARS = r'[\\/:*?"<>|]'


def sanitize_filename(name: str, max_length: int = 100) -> str:
    cleaned = re.sub(INVALID_FILENAME_CHARS, "_", name).strip()
    cleaned = re.sub(r"\s+", " ", cleaned)
    return cleaned[:max_length] or "untitled"


def strip_enml_wrappers(content: str) -> str:
    content = re.sub(r"<\?xml[^>]*\?>", "", content, flags=re.IGNORECASE).strip()
    content = re.sub(r"<!DOCTYPE[^>]*>", "", content, flags=re.IGNORECASE).strip()
    return content


def prepare_html(content: str) -> str:
    soup = BeautifulSoup(strip_enml_wrappers(content), "xml")
    note = soup.find("en-note")
    root = note if note is not None else soup

    for todo in root.find_all("en-todo"):
        checked = todo.get("checked", "").lower() == "true"
        todo.replace_with(soup.new_string("[x] " if checked else "[ ] "))

    for media in root.find_all("en-media"):
        media_type = media.get("type", "attachment")
        media.replace_with(soup.new_string(f"[Attachment: {media_type}]"))

    for br in root.find_all("br"):
        br.replace_with(soup.new_string("\n"))

    for tag in root.find_all(["span", "font"]):
        tag.unwrap()

    for a in root.find_all("a"):
        href = a.get("href")
        text = a.get_text(" ", strip=True)
        if href:
            a.replace_with(soup.new_string(f"[{text}]({href})"))
        else:
            a.replace_with(soup.new_string(text))

    for div in root.find_all("div"):
        div.insert_before(soup.new_string("\n"))
        div.insert_after(soup.new_string("\n"))
        div.unwrap()

    for tag in root.find_all(True):
        allowed = {}
        if tag.name == "img" and tag.get("src"):
            allowed["src"] = tag.get("src")
        if tag.name == "a" and tag.get("href"):
            allowed["href"] = tag.get("href")
        tag.attrs = allowed

    return "".join(str(child) for child in root.contents)


def html_to_markdown(html_content: str) -> str:
    result = subprocess.run(
        ["pandoc", "--from=html", "--to=gfm"],
        input=html_content,
        capture_output=True,
        text=True,
        encoding="utf-8",
        check=True,
    )
    return result.stdout.strip()


def clean_markdown(markdown: str) -> str:
    markdown = re.sub(r"(?m)^\\(#{1,6}\s)", r"\1", markdown)
    markdown = markdown.replace(r"\[", "[").replace(r"\]", "]")
    markdown = re.sub(r"(?m)^[ \t]*</?div>[ \t]*\n?", "", markdown)
    markdown = re.sub(r"(?m)^[ \t]*</?span[^>]*>[ \t]*\n?", "", markdown)
    markdown = re.sub(r"(?m)^[ \t]*<!--\s*-->[ \t]*\n?", "", markdown)
    markdown = re.sub(r"\n{3,}", "\n\n", markdown)
    return markdown.strip()


def note_to_markdown(note_el: ET.Element) -> tuple[str, str, str, str]:
    """Convert a note element to markdown. Returns (title, created, updated, markdown_content)"""
    title = note_el.findtext("title", default="Untitled")
    created = note_el.findtext("created", default="")
    updated = note_el.findtext("updated", default="")
    content = note_el.findtext("content", default="")
    source_url = note_el.findtext("note-attributes/source-url", default="")

    md_body = clean_markdown(html_to_markdown(prepare_html(content)))
    
    # Build frontmatter and content
    lines = [f"# {title}", ""]

    if created:
        lines.append(f"- Created: `{created}`")
    if updated:
        lines.append(f"- Updated: `{updated}`")
    if source_url:
        lines.append(f"- Source: `{html.unescape(source_url)}`")

    if len(lines) > 2:
        lines.append("")

    if md_body:
        lines.append(md_body)

    return title, created, updated, "\n".join(lines).rstrip() + "\n"


def format_date_for_filename(date_str: str) -> str:
    """Convert Evernote date format to YYYY-MM-DD for filename"""
    if not date_str or len(date_str) < 8:
        return ""
    # Evernote format: 20251121T031851Z
    try:
        year = date_str[:4]
        month = date_str[4:6]
        day = date_str[6:8]
        return f"{year}-{month}-{day}"
    except:
        return ""


def convert_enex_to_separate_markdown(enex_path: Path, output_dir: Path) -> int:
    """Convert ENEX to separate markdown files. Returns count of notes converted."""
    notebook_name = sanitize_filename(enex_path.stem)
    notebook_dir = output_dir / notebook_name
    notebook_dir.mkdir(parents=True, exist_ok=True)
    
    count = 0
    
    # Read with automatic encoding detection
    enex_content = read_enex_with_encoding(enex_path)
    
    # Parse from string using BytesIO for iterparse compatibility
    context = ET.iterparse(io.BytesIO(enex_content.encode("utf-8")), events=("end",))
    
    for _event, elem in context:
        if elem.tag != "note":
            continue

        title, created, updated, md_content = note_to_markdown(elem)
        
        # Create filename: YYYY-MM-DD - Title.md
        date_prefix = format_date_for_filename(created)
        if date_prefix:
            filename = f"{date_prefix} - {sanitize_filename(title)}.md"
        else:
            filename = f"{sanitize_filename(title)}.md"
        
        output_file = notebook_dir / filename
        
        # Handle duplicates by adding a number
        counter = 1
        original_output_file = output_file
        while output_file.exists():
            stem = original_output_file.stem
            suffix = original_output_file.suffix
            output_file = notebook_dir / f"{stem} ({counter}){suffix}"
            counter += 1

        with output_file.open("w", encoding="utf-8") as out:
            out.write(md_content)
        
        count += 1
        elem.clear()

    return count


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Convert an ENEX file into separate Markdown files for each note."
    )
    parser.add_argument("input", type=Path, help="Path to the ENEX file")
    parser.add_argument("output_dir", type=Path, help="Directory for the output notebook folder")
    args = parser.parse_args()

    converted = convert_enex_to_separate_markdown(args.input, args.output_dir)
    notebook_name = sanitize_filename(args.input.stem)
    print(f"Converted {converted} notes to {args.output_dir / notebook_name}")


if __name__ == "__main__":
    main()
