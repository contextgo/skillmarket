---
name: notes-know-you
description: Sync Evernote notebooks to local Markdown, analyze your notes, and update USER.md + Memory files so the AI truly understands who you are
user-invocable: true
metadata:
  openclaw:
    requires:
      bins: [python, pandoc]
      env: [NOTES_DB_PATH]
    primaryEnv: NOTES_DB_PATH
    emoji: "📓"
    os: [darwin, linux, win32]
---

# notes-know-you

通过你的印象笔记，让 AI 真正了解你。

This skill syncs your Evernote/Yinxiang notebooks to local Markdown files, analyzes
the content, and updates the agent's USER.md and Memory files with structured insights —
so your AI assistant always has the right context about who you are.

---

## Configuration

Set the following environment variables before using this skill:

| Variable | Required | Description |
|---|---|---|
| `NOTES_DB_PATH` | Yes | Absolute path to your `evernote-backup` database file (e.g., `F:\notes\en_backup.db`) |
| `NOTES_BACKEND` | No | `china` for Yinxiang (default), `evernote` for international |
| `NOTES_TOKEN` | No | Developer token (use if password auth fails) |
| `NOTES_EXPORT_DIR` | No | Where to write exported Markdown files (default: same directory as db, under `evernote/markdown/`) |
| `NOTES_MEMORY_DIR` | No | Where to write memory files (default: auto-detected) |

### Auto-Update AI Memory

By default, the skill **does not** automatically update USER.md and Memory files after sync.
You can enable this in two ways:

1. **Interactive**: Run `/notes-know-you` and answer the prompt
2. **Config file**: Edit `{skill_dir}/config.json` and set `"auto_update_ai_memory": true`

When enabled, the skill will automatically analyze notes and update AI memory after each sync.

---

## Usage

```
/notes-know-you                        — full sync: pull → convert → (ask) → update memory
/notes-know-you sync                   — same as above
/notes-know-you analyze                — skip sync, re-analyze existing Markdown files only
/notes-know-you setup-cron [interval]  — set up recurring auto-sync (e.g., setup-cron 24h)
/notes-know-you config                 — show current configuration
/notes-know-you config auto-update on  — enable auto-update AI memory
/notes-know-you config auto-update off — disable auto-update AI memory
```

**Auto-Update Behavior:**
- Default: **OFF** — After sync, the skill will ask if you want to update AI memory
- When enabled: Automatically update USER.md and Memory files after each sync
- When disabled: Ask for confirmation before updating AI memory

---

## Step-by-Step Instructions

### Step 0 — Check Configuration

1. Verify `NOTES_DB_PATH` is set and the file exists.
2. If not set, ask the user:
   - "Where is your evernote-backup database file?"
   - "Are you using Yinxiang (China) or international Evernote?"
   - "Do you have a developer token?"
3. If the database doesn't exist yet, guide them through first-time setup (see references/setup.md).
4. Determine:
   - `db_path` = `$NOTES_DB_PATH`
   - `db_dir` = parent directory of `db_path`
   - `enex_dir` = `$NOTES_EXPORT_DIR/../enex` or `{db_dir}/evernote/`
   - `markdown_dir` = `$NOTES_EXPORT_DIR` or `{db_dir}/evernote/markdown/`
   - `backend` = `$NOTES_BACKEND` or `china`
   - `skill_scripts_dir` = directory containing this skill's scripts/

### Step 0.5 — Check Auto-Update Setting

Read `{skill_dir}/config.json` to check `auto_update_ai_memory` setting.

**If the config file doesn't exist**, create it with default values:
```json
{
  "auto_update_ai_memory": false,
  "last_sync_time": null,
  "sync_count": 0
}
```

**Behavior based on setting:**
- `auto_update_ai_memory: true` → Skip to Step 1, automatically update AI memory after sync
- `auto_update_ai_memory: false` → After sync completes, ask the user:
  > "Sync complete! 🎉\n> \n> Do you want me to analyze your notes and update USER.md + Memory files?\n> This helps the AI understand you better based on your latest notes.\n> \n> Reply 'yes' to proceed, or 'no' to skip.\n> \n> 💡 Tip: You can enable auto-update by running `/notes-know-you config auto-update on`"

### Step 1 — Sync from Evernote

Run:
```bash
python -m evernote_backup sync -d "{db_path}"
```

**If rate limited** (`CRITICAL: Rate limit reached`): stop and tell the user to wait 25–30 minutes before retrying.

**If auth fails**: guide the user to get a developer token:
- Yinxiang: visit `https://app.yinxiang.com/api/DeveloperToken.action` while logged in
- International: visit `https://www.evernote.com/api/DeveloperToken.action`

Then update auth:
```bash
python -m evernote_backup reauth -d "{db_path}" -t "{token}"
```

### Step 2 — Export to ENEX

```bash
python -m evernote_backup export -d "{db_path}" "{enex_dir}"
```

This creates one `.enex` file per notebook under `enex_dir`.

### Step 3 — Convert ENEX to Markdown

For every `.enex` file found recursively under `enex_dir`, run:
```bash
python "{skill_scripts_dir}/enex_to_markdown_separate.py" "{enex_file}" "{markdown_dir}"
```

This produces a subdirectory for each notebook with separate Markdown files per note:
```
markdown/
├── 101 - 前端/
│   ├── 2025-11-21 - 从 58MB 到 2.6MB：React 性能优化.md
│   ├── 2025-09-01 - 从「高级开发工程师」到....md
│   └── ...
├── 102 - 赚钱/
│   └── ...
```

Each note is saved as a separate file with format: `YYYY-MM-DD - 笔记标题.md`

Keep a list of all generated Markdown files and their notebook names.

### Step 4 — Analyze Notes Content

Read the generated Markdown files. The new structure has each note as a separate file:
```
markdown/
├── 100 - Work｜工作/
│   ├── 101 - 前端/
│   │   ├── 2025-11-21 - 从 58MB 到 2.6MB：React 性能优化.md
│   │   └── ...
```

**Analysis strategy:**
1. First, scan directory structure to understand notebook organization
2. Read recent notes (last 60 days) in full — these are in filenames with recent dates
3. For older notes, read titles and skim content for recurring themes
4. Notes can be large — use judgment on depth of reading

Extract insights by notebook type:

**Diary / Daily notes** (filenames containing: Daily, Diary, Journal, 日记, 每日, 每天):
- Daily routines and recurring habits
- Emotional patterns and frequent concerns
- Goals and aspirations mentioned
- Recent life events (last 30 days) — record with approximate dates

**Work / Project notes** (Work, Project, Todo, Tasks, 工作, 项目):
- Current active projects and their status
- Professional skills and tools used
- Goals and deadlines

**Personal / People notes** (人, People, Friends, Family, 朋友, 家人):
- Key relationships and social context
- Personal values and beliefs expressed

**Reading / Clippings** (Books, 我的剪藏, Clippings, Reading, 读书):
- Topics and domains of sustained interest
- Preferred content formats (books, articles, videos)

**General / Other notebooks**:
- Any recurring themes or topics
- Explicit preferences or opinions stated

### Step 5 — Update USER.md

Locate the memory directory:
1. Check `$NOTES_MEMORY_DIR`
2. Check `.openclaw/` in the current project root
3. Check `~/.claude/projects/{current_project_hash}/memory/`
4. Fall back to creating `.memory/` in the current directory

Read existing `USER.md` if it exists. **Merge, do not overwrite** — preserve facts not
contradicted by the notes.

Write (or update) `USER.md` with this structure:

```markdown
# User Profile

_Last updated from notes: {today's date}_

## Identity
[Name if found, role/occupation if mentioned, location if mentioned]

## Interests & Domains
[Topics that appear frequently — be specific, e.g. "投资/财经" not just "finance"]

## Daily Habits & Routines
[Patterns from diary: sleep schedule, exercise, diet, work patterns]

## Goals
### Short-term (within 3 months)
[Specific goals with any deadlines found]
### Long-term
[Life goals, career goals, major aspirations]

## Values & Principles
[Core values or recurring philosophical themes in the notes]

## Skills & Expertise
[Professional and personal skills with rough proficiency level if inferable]

## Current Context
[What's happening in their life right now — active projects, recent events, current focus]

## Relationships
[Key people mentioned and their relationship to the user]
```

### Step 6 — Write Memory Files

For each significant, specific insight, create a memory file in the memory directory.

Use the formats below, saved as `{type}_{topic}.md`:

**User memory** (personal attributes, preferences, background facts):
```markdown
---
name: {descriptive name}
description: {one-line summary — specific enough to judge relevance}
type: user
---

{fact or insight}
```

**Project memory** (ongoing projects, goals with context):
```markdown
---
name: {project name}
description: {what this project is and why it matters}
type: project
---

{fact or insight}

**Why:** {motivation behind this project}
**How to apply:** {how knowing this should shape AI responses}
```

**Feedback memory** (explicit preferences the user has expressed in notes):
```markdown
---
name: {preference topic}
description: {what the user wants or doesn't want}
type: feedback
---

{the rule or preference}

**Why:** {reason given or inferred from notes}
**How to apply:** {when this guidance is relevant}
```

After writing all memory files, update `MEMORY.md` (the index file) with one line per
new or updated memory:
```
- [Title](file.md) — one-line hook
```

### Step 7 — Report to User

Summarize what was done:

```
✅ Synced {N} notebooks, {M} notes total
📄 Converted to Markdown: {list of notebook names}
👤 USER.md updated — {N} sections changed
🧠 Memory files: {N} created, {M} updated
📌 Top insights extracted:
   1. ...
   2. ...
   3. ...

⚙️  Configuration:
   Auto-update AI memory: {ON/OFF}
   Run `/notes-know-you config auto-update on` to enable automatic updates
```

---

## Config Command

When the user runs `/notes-know-you config`:

1. Read `{skill_dir}/config.json`
2. Display current configuration:
   ```
   📋 notes-know-you Configuration
   
   Auto-update AI memory: {ON/OFF}
   Last sync: {datetime or "Never"}
   Total syncs: {N}
   
   Commands:
   - /notes-know-you config auto-update on  → Enable auto-update
   - /notes-know-you config auto-update off → Disable auto-update
   ```

When the user runs `/notes-know-you config auto-update on`:
1. Update `config.json`: `"auto_update_ai_memory": true`
2. Confirm: "✅ Auto-update enabled. The AI will automatically update USER.md and Memory files after each sync."

When the user runs `/notes-know-you config auto-update off`:
1. Update `config.json`: `"auto_update_ai_memory": false`
2. Confirm: "✅ Auto-update disabled. The AI will ask for confirmation before updating USER.md and Memory files."

---

## Cron Setup

When the user runs `/notes-know-you setup-cron [interval]`:

1. Default interval: `24h`
2. Parse the interval (e.g., `6h`, `12h`, `24h`, `7d`)
3. Use the agent's cron/scheduler to register a recurring job
4. The cron job should trigger a system event with the sync instructions (see Payload below)
5. Confirm to the user: "Scheduled notes-know-you to run every {interval}. Next run: {datetime}."

### Cron Payload

```json
{
  "name": "印象笔记每日同步",
  "schedule": { "kind": "every", "everyMs": 86400000 },
  "payload": {
    "kind": "systemEvent",
    "text": "执行印象笔记每日同步任务：\n\n1. 运行 PowerShell 脚本进行完整同步：\n   & \"C:\\Users\\EMan\\.stepclaw\\skills\\notes-know-you\\scripts\\sync_evernote.ps1\"\n\n2. 脚本会自动完成：\n   - 从 Evernote 云同步到本地数据库\n   - 导出 ENEX 文件\n   - 转换为独立 Markdown 文件\n   - 按分类/笔记本组织目录结构\n\n3. 检查配置：读取 config.json 中的 auto_update_ai_memory 设置\n\n4. 如果 auto_update_ai_memory 为 true：\n   - 自动分析新笔记并更新 USER.md 和 Memory\n   - 发送同步完成报告\n\n5. 如果 auto_update_ai_memory 为 false（默认）：\n   - 发送同步完成通知，询问是否更新 AI memory\n   - 等待用户回复后再决定是否分析笔记"
  },
  "sessionTarget": "main"
}
```

---

## Privacy Note

All note content stays local. Nothing is sent to external services beyond passing note
text through the AI model's context window for analysis. ENEX files and Markdown files
remain on your machine.
