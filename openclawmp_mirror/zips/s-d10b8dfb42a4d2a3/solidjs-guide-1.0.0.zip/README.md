# SolidJS Guide

SolidJS provides true reactivity with fine-grained DOM updates, no virtual DOM, and JSX syntax similar to React.

## Why SolidJS

- **True reactivity**: Signal-based updates (not diffing)
- **No virtual DOM**: Direct DOM manipulation
- **Tiny runtime**: ~7KB gzipped
- **React-like JSX**: Easy learning curve for React devs
- **Fast benchmarks**: Consistently top of JS framework benchmarks

## Signals (Core Primitive)

```jsx
import { createSignal } from 'solid-js';

function Counter() {
  const [count, setCount] = createSignal(0);
  return <button onClick={() => setCount(count() + 1)}>{count()}</button>;
}
```

## Create Effect

```jsx
import { createSignal, createEffect } from 'solid-js';

const [name, setName] = createSignal("Solid");

createEffect(() => {
  console.log(`Hello, ${name()}!`); // Runs when name changes
});
```

## Components

```jsx
// Components run once, not on every render
function Greeting(props) {
  return <h1>Hello, {props.name}</h1>;
}
```

## SolidStart (Full-Stack)

```bash
npx create-solid@latest my-app
```

## Performance Tips

- Components execute once (no re-rendering)
- Use `<Show>` and `<For>` instead of ternaries and `.map()`
- Use `createMemo` for expensive computations
- Use `createStore` for complex state objects
- Avoid creating functions inside JSX