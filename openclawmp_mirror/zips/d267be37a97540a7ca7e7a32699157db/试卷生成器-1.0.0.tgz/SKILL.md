---
name: 试卷生成器
displayName: 试卷生成器
description: 根据知识点自动生成练习题和试卷，支持选择题、填空题、解答题，可定制难度和题型分布。
version: 1.0.0
author: OpenClaw Edu
tags: [education, exam, quiz, generator, teaching]
category: education
---

# 试卷生成器

智能生成各类练习题和试卷。

## 功能

- 自动生成选择题、填空题、解答题
- 支持难度分级（简单/中等/困难）
- 知识点覆盖分析
- 答案与解析自动生成
- 支持Word/PDF输出

## 使用

```
@试卷生成器 生成高中数学函数测试卷，10道选择、5道填空、3道解答，难度中等
```
