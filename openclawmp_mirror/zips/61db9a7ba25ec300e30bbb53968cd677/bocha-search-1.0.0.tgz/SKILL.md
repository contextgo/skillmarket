---
name: bocha-search
description: "博查 (Bocha) AI Search API executor. High-quality native AI search engine optimized for AI Context parsing, returns snippet, source name, and URL."
version: 1.0.0
---

# 🐟 博查 (Bocha) Search API 技能

这个技能集成了**博查 (Bocha)** 的原生 AI 搜索 API。
博查搜索是一个专门为 AI 准备的搜索引擎，它可以提供极其丰富、干净的网页摘要和全网检索结果，非常适合做研究、数据收集和联网搜索任务。自带高质量 Snippet，极低幻觉率。

## ⚙️ 环境和密钥

- 需要配置环境变量 `BOCHA_API_KEY`（前往 [博查AI开放平台](https://open.bochaai.com) 获取 API Key）
- 默认端点：`https://api.bochaai.com/v1/web-search`

## 🚀 使用方法

当需要搜索最新信息或做深度调研时，使用 `exec` 工具运行随附的 Python 脚本。
脚本路径需要你根据实际安装位置（通常是 `~/.openclaw/skills/bocha-search/scripts/search.py`）进行调用。

```bash
export BOCHA_API_KEY="sk-xxxxxx"

# 默认搜索前 10 条结果
python3 /path/to/bocha-search/scripts/search.py "AI搜索趋势"

# 指定获取 20 条结果（最高 50）
python3 /path/to/bocha-search/scripts/search.py "AI搜索趋势" -c 20
```

## 📊 结果解析
调用后会返回多条干净的 Markdown 结构化数据，包含：
- **名称与标题**
- **URL**（方便进一步使用 `web_fetch` 等工具深入抓取正文）
- **站点名称与发布时间**
- **富摘要 (Snippet)**：非常关键，大部分常规问题可以直接从这里获取答案，无需再请求网页原文。

## 💡 何时使用？
- 在执行 **调研 (Research)** 任务时，作为首选和最高优先级的底层搜索 API（替代不稳定或被限流的常规搜索接口）。
- 需要做多源交叉比对时，使用 Bocha 获得国内/国际优质源。
