import os
import sys
import json
import urllib.request
import argparse

def bocha_search(query, count=10):
    url = "https://api.bochaai.com/v1/web-search"
    api_key = os.environ.get("BOCHA_API_KEY")
    if not api_key:
        print("Error: Please set BOCHA_API_KEY environment variable")
        return
    
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    data = {
        "query": query,
        "count": count
    }
    
    req = urllib.request.Request(url, data=json.dumps(data).encode("utf-8"), headers=headers)
    try:
        with urllib.request.urlopen(req) as response:
            result = json.loads(response.read().decode("utf-8"))
            
            if result.get("code") != 200:
                print(f"Error: {result.get('msg')}")
                return
                
            web_pages = result.get("data", {}).get("webPages", {}).get("value", [])
            
            print(f"=== Bocha Search Results for: '{query}' ===\n")
            for idx, page in enumerate(web_pages):
                print(f"[{idx+1}] {page.get('name')}")
                print(f"URL: {page.get('url')}")
                print(f"Site: {page.get('siteName', 'N/A')} | Published: {page.get('datePublished', 'N/A')}")
                print(f"Snippet: {page.get('snippet')}")
                print("-" * 50)
                
    except Exception as e:
        print(f"Search failed: {e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Bocha Web Search")
    parser.add_argument("query", help="Search query")
    parser.add_argument("-c", "--count", type=int, default=10, help="Number of results")
    args = parser.parse_args()
    bocha_search(args.query, args.count)
