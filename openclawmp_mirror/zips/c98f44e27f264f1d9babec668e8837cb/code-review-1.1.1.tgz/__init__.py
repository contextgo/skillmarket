"""
Code Review Skill - Standardized Skill Interface
=================================================
Version: 1.1.0
Last Updated: 2026-04-08
"""

import re
from typing import Dict, Any, List


class CodeReviewSkill:
    """Code review skill with standardized validate/execute methods"""
    
    NAME = "code-review"
    VERSION = "1.1.0"
    
    # 安全问题模式
    SECURITY_PATTERNS = [
        (r'eval\s*\(', '使用eval()可能有代码注入风险'),
        (r'exec\s*\(', '使用exec()可能有代码注入风险'),
        (r'password\s*=\s*["\']', '硬编码密码 detected'),
        (r'api[_-]?key\s*=\s*["\']', '硬编码API密钥 detected'),
        (r'SQL\s*\*.*from', 'SQL注入风险：使用字符串拼接'),
        (r'\.innerHTML\s*=', 'XSS风险：直接赋值innerHTML'),
        (r'os\.system\s*\(', 'OS命令注入风险'),
    ]
    
    # 性能问题模式
    PERFORMANCE_PATTERNS = [
        (r'for\s+.*in\s+.*:\s+.*for\s+', '嵌套循环可能导致O(n²)'),
        (r'\.append\s*\(.*\)\s*\*\*.*for', '在循环中重复append，预先分配大小'),
        (r'sleep\s*\(\s*0\.', '无意义的sleep(0)'),
    ]
    
    def __init__(self):
        self.triggers = ["code review", "review code", "PR review", "代码审查"]
        self.focus_areas = ["security", "performance", "maintainability", "correctness", "testing"]
    
    def get_schema(self) -> Dict[str, Any]:
        """返回Skill Schema"""
        return {
            "name": self.NAME,
            "version": self.VERSION,
            "triggers": self.triggers,
            "capabilities": ["security-scan", "performance-analysis", "code-quality"],
            "parameters": {
                "type": "object",
                "properties": {
                    "code": {
                        "type": "string",
                        "description": "Code to review",
                        "required": True
                    },
                    "language": {
                        "type": "string",
                        "default": "auto-detect"
                    },
                    "focus": {
                        "type": "array",
                        "items": {"type": "string", "enum": self.focus_areas}
                    }
                },
                "required": ["code"]
            }
        }
    
    def validate(self, params: Dict[str, Any]) -> bool:
        """
        验证输入参数
        
        Args:
            params: 参数字典，必须包含code
            
        Returns:
            bool: True有效，False无效
        """
        if not params:
            return False
        
        if "code" not in params:
            return False
        
        code = params.get("code", "").strip()
        if not code or len(code) < 10:
            return False  # 代码太短，可能无效
        
        # 验证focus参数
        if "focus" in params:
            focus_list = params["focus"]
            if not isinstance(focus_list, list):
                return False
            for f in focus_list:
                if f not in self.focus_areas:
                    return False
        
        return True
    
    def execute(self, params: Dict[str, Any]) -> Dict[str, Any]:
        """
        执行代码审查
        
        Args:
            params: 验证后的参数字典
            
        Returns:
            dict: 审查结果
        """
        code = params.get("code", "")
        language = params.get("language", "auto-detect")
        focus = params.get("focus", ["security", "performance", "maintainability"])
        
        # 自动检测语言
        if language == "auto-detect":
            language = self._detect_language(code)
        
        findings = []
        
        # 安全审查
        if "security" in focus:
            findings.extend(self._check_security(code))
        
        # 性能审查
        if "performance" in focus:
            findings.extend(self._check_performance(code))
        
        # 可维护性审查
        if "maintainability" in focus:
            findings.extend(self._check_maintainability(code))
        
        # 计算严重程度
        severity = self._calculate_severity(findings)
        
        return {
            "success": True,
            "language": language,
            "findings": findings,
            "severity": severity,
            "summary": f"Found {len(findings)} issue(s)"
        }
    
    def _detect_language(self, code: str) -> str:
        """自动检测编程语言"""
        if 'def ' in code and ':' in code:
            return "Python"
        elif 'function' in code or 'const ' in code:
            return "JavaScript"
        elif 'func ' in code and '{' in code:
            return "Go"
        elif 'public class' in code:
            return "Java"
        elif 'defn ' in code:
            return "Clojure"
        else:
            return "Unknown"
    
    def _check_security(self, code: str) -> List[Dict[str, Any]]:
        """检查安全问题"""
        findings = []
        for pattern, message in self.SECURITY_PATTERNS:
            if re.search(pattern, code, re.IGNORECASE):
                findings.append({
                    "type": "security",
                    "severity": "high",
                    "message": message,
                    "pattern": pattern
                })
        return findings
    
    def _check_performance(self, code: str) -> List[Dict[str, Any]]:
        """检查性能问题"""
        findings = []
        for pattern, message in self.PERFORMANCE_PATTERNS:
            if re.search(pattern, code, re.IGNORECASE):
                findings.append({
                    "type": "performance",
                    "severity": "medium",
                    "message": message,
                    "pattern": pattern
                })
        return findings
    
    def _check_maintainability(self, code: str) -> List[Dict[str, Any]]:
        """检查可维护性问题"""
        findings = []
        
        # 检查函数长度
        lines = code.split('\n')
        in_function = False
        func_lines = 0
        
        for line in lines:
            if 'def ' in line or 'function' in line:
                in_function = True
                func_lines = 0
            elif in_function:
                func_lines += 1
                if func_lines > 50:
                    findings.append({
                        "type": "maintainability",
                        "severity": "low",
                        "message": f"Function is {func_lines} lines, consider splitting"
                    })
                    in_function = False
        
        return findings
    
    def _calculate_severity(self, findings: List[Dict]) -> str:
        """计算总体严重程度"""
        if not findings:
            return "none"
        
        has_high = any(f.get("severity") == "high" for f in findings)
        has_medium = any(f.get("severity") == "medium" for f in findings)
        
        if has_high:
            return "high"
        elif has_medium:
            return "medium"
        else:
            return "low"


# 便捷函数
def review_code(code: str, focus: List[str] = None) -> Dict[str, Any]:
    """快速代码审查"""
    skill = CodeReviewSkill()
    params = {"code": code, "focus": focus or ["security", "performance"]}
    
    if not skill.validate(params):
        return {"success": False, "error": "Invalid parameters"}
    
    return skill.execute(params)


# 测试
if __name__ == "__main__":
    skill = CodeReviewSkill()
    
    # 测试验证
    print("=== Validate Tests ===")
    print(f"Empty: {skill.validate({})}")  # False
    print(f"Short code: {skill.validate({'code': 'x=1'})}")  # False
    print(f"Valid: {skill.validate({'code': 'def main():\n    print(1)'})}")  # True
    
    # 测试审查
    print("\n=== Execute Test ===")
    code = """
def eval_user_input(user_input):
    result = eval(user_input)
    return result
password = "123456"
"""
    result = skill.execute({"code": code, "focus": ["security"]})
    print(result)