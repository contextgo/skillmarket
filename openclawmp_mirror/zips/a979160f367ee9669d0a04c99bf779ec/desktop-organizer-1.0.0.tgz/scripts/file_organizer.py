#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')
"""
桌面文件智能整理工具
功能：扫描桌面文件，根据内容自动分类整理到目标目录
"""

import os
import shutil
import json
import re
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Tuple, Optional

# ============== 配置区域 ==============
SOURCE_DIR = r"C:\Users\hua\Desktop"
TARGET_DIR = r"D:\各种临时性报表"

# 文件类型扩展名
FILE_TYPES = {
    'images': ['.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp'],
    'word': ['.doc', '.docx'],
    'excel': ['.xls', '.xlsx', '.csv'],
    'ppt': ['.ppt', '.pptx'],
    'pdf': ['.pdf']
}

# 所有支持的扩展名
ALL_EXTENSIONS = []
for exts in FILE_TYPES.values():
    ALL_EXTENSIONS.extend(exts)

# 分类规则（关键词）
CLASSIFICATION_RULES = {
    '01-财务报表': ['报销', '预算', '结算', '发票', '财务', '费用', '成本', '收入', '支出', '账款', '税务', '会计', '付款', '收款', '报销单'],
    '02-项目文档': ['项目', '方案', '计划', '执行', '进度', '里程碑', '交付', '实施', '开发', '上线', '阶段', '成果', '试点', '推广'],
    '03-会议记录': ['会议', '纪要', '讨论', '决议', '议程', '会议纪要', '会议记录', '座谈会', '研讨会', '专题会', '汇报会'],
    '04-合同协议': ['合同', '协议', '条款', '签约', '合作', '约定', '违约', '甲方', '乙方', '丙方', '第三方', '双方'],
    '05-个人资料': ['简历', '证书', '证件', '学历', '学位', '资格', '获奖', '荣誉', '个人'],
    '06-工作文档': ['工作', '总结', '汇报', '通知', '通报', '检查', '整改', '报告', '函', '管理', '制度', '规定', '要求'],
    '07-安全文档': ['安全', '应急', '危险', '管控', '防范', '风险', '隐患', '防护', '危险源', '事故', '灾害', '演练', '提示函'],
    '99-未分类': []
}

# ============== 文本提取工具类 ==============

class TextExtractor:
    """从各种文件类型中提取文本内容"""
    
    @staticmethod
    def extract_text(file_path: str) -> str:
        """根据文件类型选择对应的提取方法"""
        ext = Path(file_path).suffix.lower()
        
        if ext in FILE_TYPES['images']:
            return TextExtractor.extract_from_image(file_path)
        elif ext in FILE_TYPES['word']:
            return TextExtractor.extract_from_word(file_path)
        elif ext in FILE_TYPES['excel']:
            return TextExtractor.extract_from_excel(file_path)
        elif ext in FILE_TYPES['ppt']:
            return TextExtractor.extract_from_ppt(file_path)
        elif ext in FILE_TYPES['pdf']:
            return TextExtractor.extract_from_pdf(file_path)
        else:
            return ""
    
    @staticmethod
    def extract_from_image(file_path: str) -> str:
        """从图片中提取文本（OCR）"""
        try:
            from PIL import Image
            import pytesseract
            
            # 设置 Tesseract 路径（Windows 常见安装位置）
            tesseract_paths = [
                r'C:\Program Files\Tesseract-OCR\tesseract.exe',
                r'C:\Program Files (x86)\Tesseract-OCR\tesseract.exe',
                r'C:\Tesseract-OCR\tesseract.exe',
            ]
            
            for path in tesseract_paths:
                if os.path.exists(path):
                    pytesseract.pytesseract.tesseract_cmd = path
                    break
            
            image = Image.open(file_path)
            
            # 对中文进行OCR
            text = pytesseract.image_to_string(image, lang='chi_sim+eng')
            return text.strip()
        except ImportError:
            print(f"  [警告] 未安装OCR依赖，跳过图片内容提取。运行: pip install pytesseract Pillow")
            return ""
        except Exception as e:
            print(f"  [警告] OCR提取失败: {e}")
            return ""
    
    @staticmethod
    def extract_from_word(file_path: str) -> str:
        """从Word文档提取文本"""
        ext = Path(file_path).suffix.lower()
        
        # 处理旧版 .doc 文件
        if ext == '.doc':
            # 如果无法解析，返回文件名用于分类
            return Path(file_path).stem
        
        # 处理 .docx 文件
        try:
            import docx2txt
            text = docx2txt.process(file_path)
            return text.strip()[:5000]  # 限制长度
        except ImportError:
            try:
                from docx import Document
                doc = Document(file_path)
                texts = [para.text for para in doc.paragraphs]
                return '\n'.join(texts)[:5000]
            except ImportError:
                print(f"  [警告] 未安装Word处理依赖，跳过。运行: pip install python-docx docx2txt")
                return Path(file_path).stem
        except Exception as e:
            print(f"  [警告] Word提取失败: {e}")
            return Path(file_path).stem
    
    @staticmethod
    def extract_from_excel(file_path: str) -> str:
        """从Excel文件提取文本"""
        try:
            import pandas as pd
            
            if file_path.endswith('.csv'):
                df = pd.read_csv(file_path, nrows=50)
            else:
                df = pd.read_excel(file_path, nrows=50, sheet_name=None)
                if isinstance(df, dict):
                    # 多个sheet，合并前50行
                    texts = []
                    for sheet_name, sheet_df in df.items():
                        texts.append(f"Sheet: {sheet_name}")
                        texts.append(sheet_df.head(50).to_string())
                    return '\n'.join(texts)[:5000]
            
            return df.head(50).to_string()[:5000]
        except ImportError:
            print(f"  [警告] 未安装Excel处理依赖，跳过。运行: pip install pandas openpyxl xlrd")
            return ""
        except Exception as e:
            print(f"  [警告] Excel提取失败: {e}")
            return ""
    
    @staticmethod
    def extract_from_ppt(file_path: str) -> str:
        """从PPT提取文本"""
        try:
            from pptx import Presentation
            prs = Presentation(file_path)
            texts = []
            
            for slide in prs.slides:
                for shape in slide.shapes:
                    if hasattr(shape, "text") and shape.text:
                        texts.append(shape.text)
            
            return '\n'.join(texts)[:5000]
        except ImportError:
            print(f"  [警告] 未安装PPT处理依赖，跳过。运行: pip install python-pptx")
            return ""
        except Exception as e:
            print(f"  [警告] PPT提取失败: {e}")
            return ""
    
    @staticmethod
    def extract_from_pdf(file_path: str) -> str:
        """从PDF提取文本"""
        # 首先尝试 PyMuPDF (推荐)
        try:
            import fitz  # PyMuPDF
            doc = fitz.open(file_path)
            text = ""
            for page_num in range(min(10, len(doc))):
                text += doc[page_num].get_text()
            doc.close()
            if text.strip():
                return text[:5000]
        except ImportError:
            pass
        except Exception as e:
            print(f"  [警告] PyMuPDF提取失败: {e}")
        
        # 备选方案：PyPDF2
        try:
            import PyPDF2
            
            text = ""
            with open(file_path, 'rb') as f:
                pdf_reader = PyPDF2.PdfReader(f)
                for page_num in range(min(10, len(pdf_reader.pages))):
                    page_text = pdf_reader.pages[page_num].extract_text()
                    if page_text:
                        text += page_text + "\n"
            
            if text.strip():
                return text[:5000]
        except ImportError:
            print(f"  [警告] 未安装PDF处理依赖，尝试使用文件名分类。运行: pip install pymupdf")
        except Exception as e:
            print(f"  [警告] PyPDF2提取失败: {e}")
        
        # 如果都失败，返回文件名用于分类
        return Path(file_path).stem


# ============== 文件分类器 ==============

class FileClassifier:
    """根据内容智能分类文件"""
    
    def __init__(self, rules: Dict[str, List[str]]):
        self.rules = rules
    
    def classify(self, file_path: str, content: str, filename: str) -> Tuple[str, str]:
        """
        根据文件内容和文件名进行分类
        返回: (分类文件夹名, 分类依据)
        """
        # 合并文件名和内容进行分析
        search_text = f"{filename} {content}".lower()
        
        # 记录匹配到的关键词
        matches = {}
        
        for category, keywords in self.rules.items():
            match_count = 0
            matched_keywords = []
            
            for keyword in keywords:
                if keyword.lower() in search_text:
                    match_count += 1
                    matched_keywords.append(keyword)
            
            if match_count > 0:
                matches[category] = {
                    'count': match_count,
                    'keywords': matched_keywords
                }
        
        if matches:
            # 选择匹配关键词最多的分类
            best_category = max(matches.items(), key=lambda x: x[1]['count'])
            category_name = best_category[0]
            reason = f"匹配关键词: {', '.join(best_category[1]['keywords'][:3])}"
            return category_name, reason
        else:
            return '99-未分类', '无匹配关键词'


# ============== 文件整理器 ==============

class FileOrganizer:
    """文件整理主类"""
    
    def __init__(self, source_dir: str, target_dir: str, dry_run: bool = True):
        self.source_dir = Path(source_dir)
        self.target_dir = Path(target_dir)
        self.dry_run = dry_run
        self.classifier = FileClassifier(CLASSIFICATION_RULES)
        self.extractor = TextExtractor()
        self.report = []
        self.stats = {
            'total_files': 0,
            'processed': 0,
            'skipped': 0,
            'errors': 0,
            'categories': {}
        }
    
    def scan_files(self) -> List[Path]:
        """扫描源目录中的目标文件"""
        files = []
        
        if not self.source_dir.exists():
            print(f"[错误] 源目录不存在: {self.source_dir}")
            return files
        
        # 排除的临时文件模式
        exclude_patterns = ['~$', '.tmp', '.temp', '.~']
        
        for item in self.source_dir.iterdir():
            if item.is_file():
                # 排除临时文件
                if any(item.name.startswith(p) for p in exclude_patterns):
                    continue
                # 排除Office临时文件（~$开头）
                if item.name.startswith('~$'):
                    continue
                    
                ext = item.suffix.lower()
                if ext in ALL_EXTENSIONS:
                    files.append(item)
        
        return sorted(files)
    
    def get_unique_filename(self, target_path: Path) -> Path:
        """获取唯一的文件名（处理冲突）"""
        if not target_path.exists():
            return target_path
        
        stem = target_path.stem
        suffix = target_path.suffix
        parent = target_path.parent
        counter = 1
        
        while True:
            new_name = f"{stem}_{counter:03d}{suffix}"
            new_path = parent / new_name
            if not new_path.exists():
                return new_path
            counter += 1
    
    def process_file(self, file_path: Path) -> Dict:
        """处理单个文件"""
        result = {
            'original_path': str(file_path),
            'filename': file_path.name,
            'category': None,
            'target_path': None,
            'reason': None,
            'status': 'pending',
            'content_preview': None
        }
        
        print(f"\n  处理: {file_path.name}")
        
        try:
            # 提取内容
            print(f"    正在提取内容...")
            content = self.extractor.extract_text(str(file_path))
            
            # 内容预览（用于报告）
            result['content_preview'] = content[:200].replace('\n', ' ') if content else ""
            
            # 分类
            print(f"    正在分析分类...")
            category, reason = self.classifier.classify(
                str(file_path), 
                content, 
                file_path.name
            )
            
            result['category'] = category
            result['reason'] = reason
            
            # 确定目标路径
            category_dir = self.target_dir / category
            target_file = category_dir / file_path.name
            target_file = self.get_unique_filename(target_file)
            
            result['target_path'] = str(target_file)
            
            # 执行移动（如果不是dry run）
            if not self.dry_run:
                print(f"    创建目录: {category_dir}")
                category_dir.mkdir(parents=True, exist_ok=True)
                
                print(f"    移动文件到: {target_file}")
                shutil.move(str(file_path), str(target_file))
                result['status'] = 'moved'
            else:
                result['status'] = 'dry_run'
            
            print(f"    ✓ 分类: {category}")
            print(f"    ✓ 依据: {reason}")
            
        except Exception as e:
            result['status'] = 'error'
            result['error'] = str(e)
            print(f"    ✗ 错误: {e}")
        
        return result
    
    def run(self):
        """运行整理任务"""
        print("=" * 60)
        print("桌面文件智能整理工具")
        print("=" * 60)
        print(f"源目录: {self.source_dir}")
        print(f"目标目录: {self.target_dir}")
        print(f"模式: {'【模拟运行 - Dry Run】' if self.dry_run else '【实际执行】'}")
        print("=" * 60)
        
        # 扫描文件
        print("\n📁 第1步: 扫描文件...")
        files = self.scan_files()
        self.stats['total_files'] = len(files)
        
        if not files:
            print("  未找到符合条件的文件。")
            return
        
        print(f"  找到 {len(files)} 个文件:")
        for f in files:
            print(f"    - {f.name}")
        
        # 处理和分类
        print("\n📋 第2步: 分析文件内容并分类...")
        
        for file_path in files:
            result = self.process_file(file_path)
            self.report.append(result)
            
            # 更新统计
            category = result.get('category', '未知')
            if category:
                self.stats['categories'][category] = self.stats['categories'].get(category, 0) + 1
            
            if result['status'] == 'error':
                self.stats['errors'] += 1
            else:
                self.stats['processed'] += 1
        
        # 生成报告
        print("\n📊 第3步: 生成整理报告...")
        self.generate_report()
        
        # 输出摘要
        print("\n" + "=" * 60)
        print("整理摘要")
        print("=" * 60)
        print(f"总文件数: {self.stats['total_files']}")
        print(f"成功处理: {self.stats['processed']}")
        print(f"错误: {self.stats['errors']}")
        print("\n分类统计:")
        for cat, count in sorted(self.stats['categories'].items()):
            print(f"  - {cat}: {count} 个文件")
        
        if self.dry_run:
            print("\n" + "!" * 60)
            print("⚠️  这是模拟运行（Dry Run），没有实际移动文件！")
            print("   要实际执行，请将 dry_run 参数设为 False")
            print("!" * 60)
    
    def generate_report(self):
        """生成整理报告"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        report_dir = Path(__file__).parent / "reports"
        report_dir.mkdir(exist_ok=True)
        
        # JSON 报告
        json_path = report_dir / f"file_organization_report_{timestamp}.json"
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'source_dir': str(self.source_dir),
                'target_dir': str(self.target_dir),
                'dry_run': self.dry_run,
                'stats': self.stats,
                'details': self.report
            }, f, ensure_ascii=False, indent=2)
        
        # Markdown 报告
        md_path = report_dir / f"file_organization_report_{timestamp}.md"
        with open(md_path, 'w', encoding='utf-8') as f:
            f.write("# 文件整理报告\n\n")
            f.write(f"**生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            f.write(f"**源目录**: `{self.source_dir}`\n\n")
            f.write(f"**目标目录**: `{self.target_dir}`\n\n")
            f.write(f"**运行模式**: {'模拟运行 (Dry Run)' if self.dry_run else '实际执行'}\n\n")
            
            f.write("## 统计摘要\n\n")
            f.write(f"- 总文件数: {self.stats['total_files']}\n")
            f.write(f"- 成功处理: {self.stats['processed']}\n")
            f.write(f"- 错误: {self.stats['errors']}\n\n")
            
            f.write("### 分类统计\n\n")
            f.write("| 分类 | 文件数 |\n")
            f.write("|------|--------|\n")
            for cat, count in sorted(self.stats['categories'].items()):
                f.write(f"| {cat} | {count} |\n")
            
            f.write("\n## 详细记录\n\n")
            f.write("| 文件名 | 分类 | 分类依据 | 原始位置 | 目标位置 | 状态 |\n")
            f.write("|--------|------|----------|----------|----------|------|\n")
            
            for item in self.report:
                status_emoji = {
                    'dry_run': '⏳',
                    'moved': '✅',
                    'error': '❌',
                    'pending': '⏸️'
                }.get(item['status'], '❓')
                
                f.write(f"| {item['filename']} | {item.get('category', '-')} | "
                       f"{item.get('reason', '-')} | `{item['original_path']}` | "
                       f"`{item.get('target_path', '-')}` | {status_emoji} {item['status']} |\n")
        
        print(f"  ✓ JSON报告: {json_path}")
        print(f"  ✓ Markdown报告: {md_path}")


def main():
    """主函数"""
    import sys
    
    # 解析命令行参数
    dry_run = True
    if '--execute' in sys.argv or '-e' in sys.argv:
        dry_run = False
    
    # 创建整理器并运行
    organizer = FileOrganizer(
        source_dir=SOURCE_DIR,
        target_dir=TARGET_DIR,
        dry_run=dry_run
    )
    
    organizer.run()
    
    if dry_run:
        print("\n" + "-" * 60)
        print("要实际执行文件移动，请运行:")
        print("  python file_organizer.py --execute")
        print("  或")
        print("  python file_organizer.py -e")
        print("-" * 60)


if __name__ == "__main__":
    main()
