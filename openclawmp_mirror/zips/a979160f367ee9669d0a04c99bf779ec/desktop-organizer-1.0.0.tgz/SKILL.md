---
name: desktop-organizer
description: Auto-organize desktop files (images, Word, Excel, PPT, PDF) to categorized folders based on content analysis. Use when user wants to organize files from Desktop to D:\各种临时性报表 with automatic content-based classification into subfolders like 财务报表, 项目文档, 会议记录, 合同协议, 工作文档, 安全文档, or 未分类. Supports scheduled execution and dry-run preview.
---

# Desktop File Organizer

Automatically organize desktop documents into categorized folders based on content analysis.

## What It Does

1. **Scan** desktop for supported file types (images, Word, Excel, PPT, PDF)
2. **Extract content** using OCR and text extraction
3. **Classify** files based on keywords into categories
4. **Move** files to appropriate subfolders in `D:\各种临时性报表`

## Classification Categories

| Folder | Keywords |
|--------|----------|
| 01-财务报表 | 报销、预算、结算、发票、财务、费用、成本、收入、支出、账款、税务、会计 |
| 02-项目文档 | 项目、方案、计划、执行、进度、里程碑、交付、实施、开发、上线 |
| 03-会议记录 | 会议、纪要、讨论、决议、议程、会议纪要、座谈会、研讨会 |
| 04-合同协议 | 合同、协议、条款、签约、合作、约定、违约、甲方、乙方 |
| 05-个人资料 | 简历、证书、证件、学历、学位、资格、获奖、荣誉 |
| 06-工作文档 | 工作、总结、汇报、通知、通报、检查、整改、报告、函、管理 |
| 07-安全文档 | 安全、应急、危险、管控、防范、风险、隐患、事故、演练、提示函 |
| 99-未分类 | 无匹配关键词 |

## Usage

### Dry Run (Preview)
```bash
python scripts/file_organizer.py
```

### Execute
```bash
python scripts/file_organizer.py --execute
```

## File Structure

```
desktop-organizer/
├── SKILL.md
└── scripts/
    └── file_organizer.py
```

## Dependencies

- Python 3.8+
- pillow
- python-docx
- docx2txt
- pandas
- openpyxl
- xlrd
- python-pptx
- pymupdf
- pytesseract (requires Tesseract OCR installed)

## Configuration

Edit `file_organizer.py` to customize:
- `SOURCE_DIR`: Source directory (default: Desktop)
- `TARGET_DIR`: Target directory (default: D:\各种临时性报表)
- `CLASSIFICATION_RULES`: Category keywords

## Scheduled Execution

Use OpenClaw cron to schedule automatic runs:
```bash
openclaw cron add --name "desktop-organize" --schedule "0 6 * * *" --command "python scripts/file_organizer.py --execute"
```
