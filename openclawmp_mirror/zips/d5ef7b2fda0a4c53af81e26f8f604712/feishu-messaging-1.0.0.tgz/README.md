# feishu-messaging

**类型**: skill

|

## 快速开始

当用户提到 feishu-messaging 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
