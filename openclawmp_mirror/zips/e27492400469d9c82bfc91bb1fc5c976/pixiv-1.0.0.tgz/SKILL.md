---
name: pixiv
description: "Pixiv图片下载器，支持每日排行榜、收藏下载、标签搜索、指定ID下载"
---

# Pixiv 图片下载器

四合一下载器，支持每日排行榜、收藏下载、标签搜索、指定ID下载。自动压缩大图、推送飞书。

## 使用方法

```powershell
cd C:\Users\29213\.openclaw\workspace\skills\pixiv\scripts
python pixiv_all_in_one.py --mode <模式> [参数]
```

## 模式说明

| 模式 | 命令 | 说明 |
|------|------|------|
| 每日排行榜 | `--mode daily` | 下载総合排行榜 |
| 收藏下载 | `--mode bookmarks` | 下载自己收藏夹 |
| 标签搜索 | `--mode search --tag "关键词"` | 按关键词搜索 |
| 指定ID下载 | `--mode id --ids "ID1,ID2,..."` | 下载指定作品ID |

## 示例

```powershell
# 每日排行榜 Top10
python pixiv_all_in_one.py --mode daily

# 下载收藏（前20个）
python pixiv_all_in_one.py --mode bookmarks --limit 20

# 搜索初音未来
python pixiv_all_in_one.py --mode search --tag "初音" --limit 15

# 指定ID下载
python pixiv_all_in_one.py --mode id --ids "118964463,141126499,111928967"
```

## 工作流程

1. **下载原图** → 保存到 `output/pixiv/对应目录/`
2. **检查压缩** → 遍历所有图片，>10MB 自动压缩
3. **推送飞书** → 发送压缩版（如果存在）否则发原图
4. **清理** → 推送成功后删除压缩版，保留原图

## 输出目录

```
C:\Users\29213\.openclaw\workspace\output\pixiv\
├── 每日排行榜/      # --mode daily
├── 收藏/            # --mode bookmarks
├── 搜索_初音/        # --mode search --tag "初音"
└── 指定ID/          # --mode id --ids "..."
```

# Pixiv 图片下载器

> 配置：需要在脚本中设置 COOKIES 和 FEISHU_TARGET

## 注意事项

- Cookie 有效期几天到几周，过期需更新
- 原图 >10MB 会自动压缩为 1500px 宽、JPEG 质量 85
- 指定ID模式使用 pixiv.re CDN 加速下载
- 推送后自动删除压缩版，保留原图文件
- 文件名只用作品 ID，避免乱码问题
