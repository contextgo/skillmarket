# -*- coding: utf-8 -*-
"""
Pixiv 下载器 - 四合一版本
支持：每日排行榜、收藏下载、标签搜索、指定ID下载
"""
import requests
import subprocess
import time
import argparse
import os
import re
from pathlib import Path
from PIL import Image

# ============ 配置 =============
COOKIES = {
    "PHPSESSID": "113941901_sbrvz4YfHDZRdtnLIPamBfBbJEbnik02",
}

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    "Referer": "https://www.pixiv.net/",
}

PROXY = {
    "http": "http://127.0.0.1:7890",
    "https": "http://127.0.0.1:7890",
}

OUTPUT_DIR = Path(r"C:\Users\29213\.openclaw\workspace\output\pixiv")
FEISHU_TARGET = "你的飞书ID"
MAX_SIZE_MB = 10
# =================================

session = requests.Session()
session.cookies.update(COOKIES)
session.headers.update(HEADERS)


def get_user_id():
    """获取用户ID"""
    r = session.get("https://www.pixiv.net/", timeout=15)
    m = re.search(r'"userId":"(\d+)"', r.text)
    return m.group(1) if m else None


def get_all_bookmarks(user_id):
    """获取所有收藏"""
    all_works = []
    offset = 0
    limit = 48
    
    while True:
        url = f"https://www.pixiv.net/ajax/user/{user_id}/illusts/bookmarks"
        params = {'offset': offset, 'limit': limit, 'rest': 'show', 'tag': '', 'date_for': 'unknow'}
        
        r = session.get(url, params=params, timeout=15)
        if r.status_code != 200:
            break
        
        data = r.json()
        works = data.get('body', {}).get('works', [])
        
        if not works:
            break
            
        all_works.extend(works)
        offset += limit
        
        if len(works) < limit:
            break
    
    return all_works


def search_by_tag(tag, limit=20):
    """标签搜索"""
    url = f"https://www.pixiv.net/ajax/search/artworks/{tag}?word={tag}&order=date_d&mode=all&p=1"
    
    for attempt in range(3):
        try:
            r = session.get(url, timeout=20, proxies=PROXY if PROXY.get("http") else None)
            if r.status_code == 200:
                data = r.json()
                return data.get("body", {}).get("illustManga", {}).get("data", [])[:limit]
        except Exception as e:
            print(f"  ⚠️ 尝试 {attempt+1} 失败: {e}")
            time.sleep(2)
    
    return []


def get_daily_top(limit=10):
    """每日排行榜"""
    url = "https://www.pixiv.net/ajax/search/artworks/総合?word=総合&order=date_d&mode=all&p=1"
    
    for attempt in range(3):
        try:
            r = session.get(url, timeout=20, proxies=PROXY if PROXY.get("http") else None)
            if r.status_code == 200:
                data = r.json()
                return data.get("body", {}).get("illustManga", {}).get("data", [])[:limit]
        except Exception as e:
            print(f"  ⚠️ 尝试 {attempt+1} 失败: {e}")
            time.sleep(2)
    
    return []


def get_original_url_by_id(illust_id):
    """通过ID获取原图URL和标题（使用API）"""
    url = f"https://www.pixiv.net/ajax/illust/{illust_id}?lang=zh"
    proxies = PROXY if PROXY.get("http") else None
    try:
        r = session.get(url, timeout=15, proxies=proxies)
        if r.status_code == 200:
            data = r.json()
            body = data.get('body', {})
            urls = body.get('urls', {})
            original = urls.get('original', '')
            title = body.get('title', f'illust_{illust_id}')
            return original, title
    except Exception as e:
        print(f"  ⚠️ 获取URL失败: {e}")
    return None, None


def get_original_url(illust_id):
    """获取原图URL"""
    url = f"https://www.pixiv.net/ajax/illust/{illust_id}"
    r = session.get(url, timeout=15, proxies=PROXY if PROXY.get("http") else None)
    if r.status_code == 200:
        data = r.json()
        return data.get('body', {}).get('urls', {}).get('original', '')
    return None


def download_image(img_url, output_path):
    """下载单张图片"""
    try:
        r = session.get(img_url, timeout=60, proxies=PROXY if PROXY.get("http") else None)
        if r.status_code == 200:
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_bytes(r.content)
            return True
    except Exception as e:
        print(f"  ❌ 下载失败: {e}")
    return False


def download_by_id(illust_id, title, output_dir):
    """使用 pixiv.re CDN 下载指定ID"""
    original_url, api_title = get_original_url_by_id(illust_id)
    
    if not original_url:
        return False
    
    # 使用 pixiv.re CDN 代理
    download_url = original_url.replace('i.pximg.net', 'i.pixiv.re')
    
    try:
        r = session.get(download_url, timeout=120)
        if r.status_code != 200:
            print(f"  ❌ 下载失败: {r.status_code}")
            return False
        
        ext = original_url.split('.')[-1]
        # 清理文件名
        safe_title = "".join(c for c in (title or api_title) if c not in r'<>:"/\|?*')[:30]
        filename = f"{illust_id}_{safe_title}.{ext}"
        output_path = output_dir / filename
        
        output_path.write_bytes(r.content)
        size = len(r.content) / 1024 / 1024
        print(f"  ✅ {api_title} ({size:.1f}MB)")
        return True
        
    except Exception as e:
        print(f"  ❌ 错误: {e}")
        return False


def compress_image(path):
    """压缩超过10MB的图片，返回压缩后的路径（如果有）"""
    size_mb = path.stat().st_size / 1024 / 1024
    
    if size_mb <= MAX_SIZE_MB:
        return None
    
    try:
        img = Image.open(path)
        if img.mode == 'RGBA':
            img = img.convert('RGB')
        
        w, h = img.size
        if w > 1500:
            new_w = 1500
            new_h = int(h * (1500/w))
            img = img.resize((new_w, new_h), Image.Resampling.LANCZOS)
        
        compressed_path = path.with_name(path.stem + "_压缩.jpg")
        img.save(compressed_path, 'JPEG', quality=85, optimize=True)
        
        new_size = compressed_path.stat().st_size / 1024 / 1024
        print(f"  📦 压缩: {size_mb:.1f}MB -> {new_size:.1f}MB")
        return compressed_path
        
    except Exception as e:
        print(f"  ❌ 压缩失败: {e}")
        return None


def send_to_feishu(file_path, caption):
    """发送到飞书"""
    try:
        result = subprocess.run([
            "openclaw", "message", "send",
            "--target", FEISHU_TARGET,
            "--file", str(file_path),
            caption
        ], capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"  ✅ 已发送: {caption}")
            return True
        else:
            print(f"  ❌ 发送失败: {result.stderr}")
            return False
    except Exception as e:
        print(f"  ❌ 发送异常: {e}")
        return False


def process_and_send(image_dir):
    """遍历目录，检查压缩并发送"""
    image_files = list(image_dir.glob("*.jpg")) + list(image_dir.glob("*.png"))
    
    if not image_files:
        print("  ⚠️ 没有图片")
        return
    
    print(f"\n📸 开始处理 {len(image_files)} 张图片...")
    
    for i, img_path in enumerate(image_files):
        # 检查是否需要压缩
        compressed_path = compress_image(img_path)
        
        # 优先发送压缩版，否则发原图
        send_path = compressed_path if compressed_path else img_path
        caption = f"{img_path.stem}"
        
        if send_to_feishu(send_path, caption):
            # 发送成功后删除压缩版，保留原图
            if compressed_path and compressed_path.exists():
                compressed_path.unlink()
                print(f"  🗑️ 已删除压缩版")
        
        time.sleep(2)


def main():
    parser = argparse.ArgumentParser(description="Pixiv 下载器 - 四合一")
    parser.add_argument("--mode", choices=["daily", "bookmarks", "search", "id"], required=True, help="下载模式")
    parser.add_argument("--tag", type=str, help="搜索关键词（仅 search 模式用）")
    parser.add_argument("--ids", type=str, help="作品ID列表，逗号分隔（仅 id 模式用，如: 118964463,141126499）")
    parser.add_argument("--limit", type=int, default=10, help="下载数量")
    
    args = parser.parse_args()
    
    print("=" * 50)
    print("🎨 Pixiv 下载器 - 四合一")
    print("=" * 50)
    
    if args.mode == "daily":
        print("\n📊 获取每日排行榜...")
        output_dir = OUTPUT_DIR / "每日排行榜"
        items = get_daily_top(args.limit)
        mode_name = "每日排行榜"
        
    elif args.mode == "bookmarks":
        print("\n⭐ 获取收藏...")
        user_id = get_user_id()
        if not user_id:
            print("❌ 无法获取用户ID，请检查Cookie")
            return
        items = get_all_bookmarks(user_id)
        output_dir = OUTPUT_DIR / "收藏"
        mode_name = "收藏"
        
    elif args.mode == "search":
        if not args.tag:
            print("❌ search 模式需要 --tag 参数")
            return
        print(f"\n🔍 搜索: {args.tag}")
        output_dir = OUTPUT_DIR / f"搜索_{args.tag}"
        items = search_by_tag(args.tag, args.limit)
        mode_name = f"搜索_{args.tag}"
        
    elif args.mode == "id":
        if not args.ids:
            print("❌ id 模式需要 --ids 参数")
            return
        # 解析ID列表
        id_list = [x.strip() for x in args.ids.split(',') if x.strip()]
        items = [{"id": int(x), "title": ""} for x in id_list]
        output_dir = OUTPUT_DIR / "指定ID"
        mode_name = "指定ID"
    
    print(f"找到 {len(items)} 个作品，开始下载...")
    
    # 下载
    output_dir.mkdir(parents=True, exist_ok=True)
    downloaded = 0
    
    for i, item in enumerate(items):
        illust_id = item.get("id")
        title = item.get("title", f"illust_{illust_id}")[:30]
        
        print(f"{i+1}. {title}...", end=" ")
        
        if args.mode == "id":
            # 指定ID模式：使用 pixiv.re CDN
            if download_by_id(illust_id, title, output_dir):
                downloaded += 1
                print("✅")
            else:
                print("❌")
        else:
            img_url = get_original_url(illust_id)
            if img_url:
                img_path = output_dir / f"{illust_id}.jpg"
                if download_image(img_url, img_path):
                    downloaded += 1
                    print("✅")
                else:
                    print("❌")
            else:
                print("⚠️ 无原图")
        
        time.sleep(0.5)
    
    print(f"\n✅ 下载完成: {downloaded}/{len(items)}")
    
    # 处理并发送
    if downloaded > 0:
        process_and_send(output_dir)
    
    print(f"\n📁 保存位置: {output_dir}")


if __name__ == "__main__":
    main()
