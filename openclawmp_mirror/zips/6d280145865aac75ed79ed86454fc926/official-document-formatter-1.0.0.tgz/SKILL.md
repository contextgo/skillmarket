---
name: official-document-formatter
description: Automatically format documents to comply with Chinese government official document standards (GB/T 9704-2012). Apply correct fonts (FangZheng XiaoBiaoSong, FangSong_GB2312), font sizes, line spacing, margins, and paragraph indentation. Includes format checker tool. Use when user needs to format official government documents, reports, notices, or any document requiring strict official formatting standards.
---

# 政府公文智能排版工具

将普通文档自动排版为符合**GB/T 9704-2012《党政机关公文格式》** 国家标准的正式公文。

## Features

### 1. 自动格式识别
- 智能识别文档标题、层级标题（一、（一）、1.（1））
- 自动区分正文和标题
- 保留原文档结构

### 2. 标准公文格式

#### 页面设置
| 项目 | 标准值 |
|------|--------|
| 纸张 | A4 (210mm × 297mm) |
| 上边距 | 37mm |
| 下边距 | 35mm |
| 左边距 | 28mm |
| 右边距 | 26mm |

#### 字体字号
| 元素 | 字体 | 字号 |
|------|------|------|
| 文档标题 | 方正小标宋简体 | 二号 (22磅) |
| 一级标题 | 黑体 | 三号 (16磅) |
| 二级标题 | 楷体_GB2312 | 三号 (16磅) |
| 正文 | 仿宋_GB2312 | 三号 (16磅) |

#### 段落格式
- **行距**: 固定值 28-30磅（标准28.95磅）
- **首行缩进**: 2字符（约0.74cm）
- **标题对齐**: 文档标题居中，正文左对齐

### 3. 层级结构自动格式化
支持四级标题自动识别和格式化：
```
一、XXXX（一级标题 - 黑体）
（一）XXXX（二级标题 - 楷体加粗）
1. XXXX（三级标题 - 仿宋加粗）
（1）XXXX（四级标题 - 仿宋）
```

### 4. 格式检查工具
附带格式检查脚本，验证文档是否符合标准。

## Usage

### 基本用法
```bash
python scripts/official_formatter.py 输入文件.docx
```

### 指定输出路径
```bash
python scripts/official_formatter.py 输入文件.docx -o 输出文件.docx
```

### 检查现有文档格式
```bash
python scripts/check_format.py 文档.docx
```

## Supported Input Formats

- `.docx` - Word文档（推荐）
- `.txt` - 纯文本文件

## Output

生成符合标准的公文格式Word文档，保存到桌面（默认）。

## Example

**输入前：**
```
关于进一步加强安全生产工作的通知

各部门：
为做好安全生产工作，现将有关事项通知如下：
一、提高思想认识
各部门要高度重视...
（一）加强组织领导
要成立专门工作组...
1. 明确责任分工
各单位要...
```

**输出后：**
```
          【方正小标宋简体 二号 居中】
      关于进一步加强安全生产工作的通知

【仿宋_GB2312 三号 首行缩进2字符】
各部门：

【仿宋_GB2312 三号 首行缩进2字符】
为做好安全生产工作，现将有关事项通知如下：

【黑体 三号】
一、提高思想认识

【仿宋_GB2312 三号 首行缩进2字符】
各部门要高度重视...

【楷体_GB2312 三号 加粗 首行缩进2字符】
（一）加强组织领导

【仿宋_GB2312 三号 首行缩进2字符】
要成立专门工作组...

【仿宋_GB2312 三号 加粗 首行缩进2字符】
1. 明确责任分工

【仿宋_GB2312 三号 首行缩进2字符】
各单位要...
```

## Important Notes

### 字体安装
使用此工具前，请确保系统已安装标准公文字体：
- **方正小标宋简体** - 文档标题
- **仿宋_GB2312** - 正文
- **黑体** - 一级标题
- **楷体_GB2312** - 二级标题

如果字体未安装，Word会使用替代字体，可能导致格式偏差。

### 标准依据
本工具格式基于：
- **GB/T 9704-2012**《党政机关公文格式》国家标准
- **中办发〔2012〕14号**《党政机关公文处理工作条例》

## Scripts

- `official_formatter.py` - 主排版程序
- `check_format.py` - 格式检查工具

## Dependencies

- Python 3.8+
- python-docx
