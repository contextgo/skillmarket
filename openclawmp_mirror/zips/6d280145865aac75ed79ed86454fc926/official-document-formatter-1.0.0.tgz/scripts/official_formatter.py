#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
政府公文智能排版工具
功能：将普通文档自动排版为符合GB/T 9704-2012标准的政府公文格式
"""

import os
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

import re
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from dataclasses import dataclass

# ============== 政府公文格式标准 (GB/T 9704-2012) ==============

@dataclass
class DocumentFormat:
    """公文格式标准"""
    # 页面设置
    page_width: int = 210  # A4宽度(mm)
    page_height: int = 297  # A4高度(mm)
    margin_top: int = 37  # 上边距(mm)
    margin_bottom: int = 35  # 下边距(mm)
    margin_left: int = 28  # 左边距(mm)
    margin_right: int = 26  # 右边距(mm)
    
    # 字体设置
    title_font: str = '方正小标宋简体'  # 标题字体
    body_font: str = '仿宋_GB2312'  # 正文字体
    header_font: str = '黑体'  # 一级标题字体
    subheader_font: str = '楷体_GB2312'  # 二级标题字体
    
    # 字号设置(磅)
    title_size: int = 22  # 二号(22磅)
    header_size: int = 16  # 三号(16磅)
    body_size: int = 16  # 三号(16磅)
    subheader_size: int = 16  # 三号(16磅)
    
    # 行距设置
    line_spacing: float = 28.95  # 固定值28-30磅，标准约28.95磅
    title_spacing: float = 1.5  # 标题行距倍数
    
    # 段落设置
    first_line_indent: float = 0.74  # 首行缩进2字符(cm)
    paragraph_spacing: float = 0  # 段前段后间距


# ============== 文档解析器 ==============

class DocumentParser:
    """解析原始文档内容"""
    
    @staticmethod
    def parse_word(file_path: str) -> List[Dict]:
        """解析Word文档"""
        try:
            from docx import Document
            doc = Document(file_path)
            
            paragraphs = []
            for para in doc.paragraphs:
                if para.text.strip():
                    paragraphs.append({
                        'text': para.text.strip(),
                        'style': para.style.name if para.style else 'Normal',
                        'is_title': DocumentParser._is_title(para.text),
                        'level': DocumentParser._detect_level(para.text)
                    })
            
            return paragraphs
        except Exception as e:
            print(f"[错误] 解析Word失败: {e}")
            return []
    
    @staticmethod
    def parse_text(content: str) -> List[Dict]:
        """解析纯文本"""
        paragraphs = []
        for line in content.split('\n'):
            line = line.strip()
            if line:
                paragraphs.append({
                    'text': line,
                    'style': 'Normal',
                    'is_title': DocumentParser._is_title(line),
                    'level': DocumentParser._detect_level(line)
                })
        return paragraphs
    
    @staticmethod
    def _is_title(text: str) -> bool:
        """判断是否为标题"""
        title_patterns = [
            r'^\d+[、\.．]\s*',  # 1. 一、
            r'^[一二三四五六七八九十]+[、\.．]\s*',  # 一、
            r'^（[一二三四五六七八九十]+）',  # （一）
            r'^\([一二三四五六七八九十]+\)',  # (一)
            r'^[\(（]\d+[\)）]',  # (1) （1）
            r'^关于.+的+(通知|通报|报告|请示|批复|函|意见|方案|总结)',
            r'^.+(工作|实施)方案$',
        ]
        
        for pattern in title_patterns:
            if re.match(pattern, text):
                return True
        
        # 短文本且没有标点，可能是标题
        if len(text) < 50 and not re.search(r'[，。；：]', text):
            return True
        
        return False
    
    @staticmethod
    def _detect_level(text: str) -> int:
        """检测标题层级"""
        # 一级标题：一、二、三、
        if re.match(r'^[一二三四五六七八九十]+[、\.．]', text):
            return 1
        # 二级标题：（一）（二）
        if re.match(r'^（[一二三四五六七八九十]+）', text):
            return 2
        # 三级标题：1. 2. 
        if re.match(r'^\d+[、\.．]', text):
            return 3
        # 四级标题：（1）（2）
        if re.match(r'^（\d+）', text):
            return 4
        
        # 根据文档位置和内容判断
        if len(text) < 20 and ('通知' in text or '报告' in text):
            return 0  # 文档标题
        
        return -1  # 正文


# ============== 公文格式化器 ==============

class OfficialDocumentFormatter:
    """政府公文格式化器"""
    
    def __init__(self):
        self.format = DocumentFormat()
    
    def format_paragraph(self, para: Dict, doc, is_doc_title: bool = False):
        """格式化单个段落"""
        text = para['text']
        level = para.get('level', -1)
        
        # 创建新段落
        new_para = doc.add_paragraph()
        
        # 根据类型应用不同格式
        if is_doc_title or level == 0:
            self._apply_title_format(new_para, text)
        elif level == 1:
            self._apply_header1_format(new_para, text)
        elif level == 2:
            self._apply_header2_format(new_para, text)
        elif level == 3:
            self._apply_header3_format(new_para, text)
        elif level == 4:
            self._apply_header4_format(new_para, text)
        else:
            self._apply_body_format(new_para, text)
        
        return new_para
    
    def _apply_title_format(self, para, text: str):
        """应用文档标题格式"""
        run = para.add_run(text)
        run.font.name = self.format.title_font
        run.font.size = Pt(self.format.title_size)
        run.font.bold = True
        
        # 设置中文字体
        run._element.rPr.rFonts.set(qn('w:eastAsia'), self.format.title_font)
        
        # 段落格式
        para.alignment = WD_ALIGN_PARAGRAPH.CENTER
        para.paragraph_format.line_spacing = Pt(self.format.title_size * self.format.title_spacing)
        para.paragraph_format.space_after = Pt(18)  # 标题后空一行
    
    def _apply_header1_format(self, para, text: str):
        """应用一级标题格式（一、）"""
        run = para.add_run(text)
        run.font.name = self.format.header_font
        run.font.size = Pt(self.format.header_size)
        run.font.bold = True
        run._element.rPr.rFonts.set(qn('w:eastAsia'), self.format.header_font)
        
        para.paragraph_format.line_spacing = Pt(self.format.line_spacing)
        para.paragraph_format.space_before = Pt(12)
        para.paragraph_format.space_after = Pt(6)
    
    def _apply_header2_format(self, para, text: str):
        """应用二级标题格式（一）"""
        run = para.add_run(text)
        run.font.name = self.format.subheader_font
        run.font.size = Pt(self.format.subheader_size)
        run.font.bold = True
        run._element.rPr.rFonts.set(qn('w:eastAsia'), self.format.subheader_font)
        
        para.paragraph_format.line_spacing = Pt(self.format.line_spacing)
        para.paragraph_format.first_line_indent = Cm(self.format.first_line_indent)
        para.paragraph_format.space_before = Pt(6)
        para.paragraph_format.space_after = Pt(6)
    
    def _apply_header3_format(self, para, text: str):
        """应用三级标题格式（1.）"""
        run = para.add_run(text)
        run.font.name = self.format.body_font
        run.font.size = Pt(self.format.body_size)
        run.font.bold = True
        run._element.rPr.rFonts.set(qn('w:eastAsia'), self.format.body_font)
        
        para.paragraph_format.line_spacing = Pt(self.format.line_spacing)
        para.paragraph_format.first_line_indent = Cm(self.format.first_line_indent)
    
    def _apply_header4_format(self, para, text: str):
        """应用四级标题格式（1）"""
        run = para.add_run(text)
        run.font.name = self.format.body_font
        run.font.size = Pt(self.format.body_size)
        run._element.rPr.rFonts.set(qn('w:eastAsia'), self.format.body_font)
        
        para.paragraph_format.line_spacing = Pt(self.format.line_spacing)
        para.paragraph_format.first_line_indent = Cm(self.format.first_line_indent)
    
    def _apply_body_format(self, para, text: str):
        """应用正文格式"""
        run = para.add_run(text)
        run.font.name = self.format.body_font
        run.font.size = Pt(self.format.body_size)
        run._element.rPr.rFonts.set(qn('w:eastAsia'), self.format.body_font)
        
        para.paragraph_format.line_spacing = Pt(self.format.line_spacing)
        para.paragraph_format.first_line_indent = Cm(self.format.first_line_indent)
        para.paragraph_format.space_after = Pt(0)
    
    def setup_page(self, doc):
        """设置页面格式"""
        section = doc.sections[0]
        
        # 页面尺寸（A4）
        section.page_width = Mm(self.format.page_width)
        section.page_height = Mm(self.format.page_height)
        
        # 页边距
        section.top_margin = Mm(self.format.margin_top)
        section.bottom_margin = Mm(self.format.margin_bottom)
        section.left_margin = Mm(self.format.margin_left)
        section.right_margin = Mm(self.format.margin_right)


# ============== 主程序 ==============

def format_official_document(input_path: str, output_path: str = None):
    """
    将文档格式化为政府公文格式
    
    Args:
        input_path: 输入文件路径(.docx或.txt)
        output_path: 输出文件路径，默认在桌面
    """
    try:
        from docx import Document
        from docx.shared import Pt, Mm, Cm
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        from docx.oxml.ns import qn
    except ImportError:
        print("[错误] 未安装python-docx，请先运行: pip install python-docx")
        return None
    
    print("="*60)
    print("政府公文智能排版工具")
    print("="*60)
    print(f"输入文件: {input_path}")
    
    # 检查输入文件
    input_file = Path(input_path)
    if not input_file.exists():
        print(f"[错误] 文件不存在: {input_path}")
        return None
    
    # 确定输出路径
    if not output_path:
        desktop = Path.home() / "Desktop"
        output_path = desktop / f"公文排版_{input_file.stem}.docx"
    
    # 解析文档
    print("\n📖 正在解析文档...")
    if input_file.suffix.lower() in ['.docx', '.doc']:
        paragraphs = DocumentParser.parse_word(str(input_file))
    elif input_file.suffix.lower() == '.txt':
        with open(input_file, 'r', encoding='utf-8') as f:
            content = f.read()
        paragraphs = DocumentParser.parse_text(content)
    else:
        print(f"[错误] 不支持的文件格式: {input_file.suffix}")
        return None
    
    print(f"✓ 解析完成，共 {len(paragraphs)} 个段落")
    
    # 创建新文档
    print("\n📝 正在应用公文格式...")
    doc = Document()
    formatter = OfficialDocumentFormatter()
    
    # 设置页面
    formatter.setup_page(doc)
    
    # 格式化段落
    doc_title_set = False
    for i, para in enumerate(paragraphs):
        # 判断是否为文档标题（第一个标题或最长的短文本）
        is_doc_title = False
        if not doc_title_set and para.get('is_title') and i < 3:
            is_doc_title = True
            doc_title_set = True
        
        formatter.format_paragraph(para, doc, is_doc_title)
    
    # 保存文档
    doc.save(str(output_path))
    print(f"\n✅ 公文排版完成！")
    print(f"📄 输出文件: {output_path}")
    
    # 打印格式说明
    print("\n" + "="*60)
    print("📋 已应用的公文格式标准")
    print("="*60)
    print("【页面设置】")
    print(f"  纸张: A4 (210mm × 297mm)")
    print(f"  页边距: 上{formatter.format.margin_top}mm 下{formatter.format.margin_bottom}mm 左{formatter.format.margin_left}mm 右{formatter.format.margin_right}mm")
    print("\n【字体设置】")
    print(f"  标题: {formatter.format.title_font} 二号({formatter.format.title_size}磅)")
    print(f"  正文: {formatter.format.body_font} 三号({formatter.format.body_size}磅)")
    print(f"  一级标题: {formatter.format.header_font} 三号 加粗")
    print(f"  二级标题: {formatter.format.subheader_font} 三号 加粗")
    print("\n【段落设置】")
    print(f"  行距: 固定值 {formatter.format.line_spacing}磅")
    print(f"  首行缩进: 2字符({formatter.format.first_line_indent}cm)")
    print("="*60)
    
    return str(output_path)


def main():
    """主函数 - 命令行入口"""
    import argparse
    
    parser = argparse.ArgumentParser(description='政府公文智能排版工具')
    parser.add_argument('input', help='输入文件路径(.docx或.txt)')
    parser.add_argument('-o', '--output', help='输出文件路径(可选)')
    
    args = parser.parse_args()
    
    format_official_document(args.input, args.output)


if __name__ == "__main__":
    # 如果没有命令行参数，使用示例
    if len(sys.argv) == 1:
        print("使用示例:")
        print("  python official_formatter.py 输入文件.docx")
        print("  python official_formatter.py 输入文件.docx -o 输出文件.docx")
        print("\n支持格式: .docx, .txt")
    else:
        main()
