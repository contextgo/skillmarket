#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
公文格式快速检查工具
检查Word文档是否符合政府公文格式标准
"""

import os
import sys
from pathlib import Path
from docx import Document
from docx.shared import Pt, Mm

def check_official_format(file_path: str):
    """检查文档格式是否符合标准"""
    print("="*60)
    print("政府公文格式检查工具")
    print("="*60)
    
    doc = Document(file_path)
    issues = []
    warnings = []
    
    # 检查页面设置
    section = doc.sections[0]
    
    # 页面尺寸检查
    page_width = section.page_width.mm
    page_height = section.page_height.mm
    if abs(page_width - 210) > 5 or abs(page_height - 297) > 5:
        issues.append(f"❌ 页面尺寸: {page_width:.0f}mm × {page_height:.0f}mm (应为 A4 210mm × 297mm)")
    else:
        print("✓ 页面尺寸: A4 (210mm × 297mm)")
    
    # 页边距检查
    top = section.top_margin.mm
    bottom = section.bottom_margin.mm
    left = section.left_margin.mm
    right = section.right_margin.mm
    
    if abs(top - 37) > 3:
        issues.append(f"❌ 上边距: {top:.0f}mm (标准: 37mm)")
    if abs(bottom - 35) > 3:
        issues.append(f"❌ 下边距: {bottom:.0f}mm (标准: 35mm)")
    if abs(left - 28) > 3:
        issues.append(f"❌ 左边距: {left:.0f}mm (标准: 28mm)")
    if abs(right - 26) > 3:
        issues.append(f"❌ 右边距: {right:.0f}mm (标准: 26mm)")
    
    if len([i for i in issues if '边距' in i]) == 0:
        print(f"✓ 页边距: 上{top:.0f}mm 下{bottom:.0f}mm 左{left:.0f}mm 右{right:.0f}mm")
    
    # 检查字体和字号
    print("\n📄 检查字体格式...")
    
    fonts_found = set()
    sizes_found = set()
    
    for para in doc.paragraphs[:20]:  # 只检查前20段
        for run in para.runs:
            if run.font.name:
                fonts_found.add(run.font.name)
            if run.font.size:
                sizes_found.add(run.font.size.pt)
    
    # 标准字体检查
    standard_fonts = ['方正小标宋简体', '仿宋_GB2312', '黑体', '楷体_GB2312', 'FangSong', 'SimHei', 'KaiTi']
    has_standard_font = any(f in str(fonts_found) for f in standard_fonts)
    
    if has_standard_font:
        print(f"✓ 发现标准公文字体")
    else:
        warnings.append(f"⚠️  未使用标准公文字体，当前字体: {fonts_found}")
    
    print(f"  使用字体: {', '.join(fonts_found)}")
    print(f"  字号: {', '.join([f'{s:.0f}pt' for s in sizes_found])}")
    
    # 检查结果汇总
    print("\n" + "="*60)
    print("📊 检查结果")
    print("="*60)
    
    if issues:
        print(f"\n❌ 发现 {len(issues)} 个问题:")
        for issue in issues:
            print(f"  {issue}")
    
    if warnings:
        print(f"\n⚠️  发现 {len(warnings)} 个警告:")
        for warning in warnings:
            print(f"  {warning}")
    
    if not issues and not warnings:
        print("\n✅ 文档格式符合政府公文标准！")
    elif not issues:
        print("\n✅ 文档基本符合标准，有轻微警告")
    else:
        print(f"\n❌ 文档不符合标准，请使用 official_formatter.py 重新排版")
    
    print("="*60)


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("使用示例:")
        print("  python check_format.py 文档.docx")
    else:
        check_official_format(sys.argv[1])
