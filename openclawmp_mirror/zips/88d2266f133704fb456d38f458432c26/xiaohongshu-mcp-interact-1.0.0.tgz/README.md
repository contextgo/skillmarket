# 小红书 MCP 自动互动

通过 xiaohongshu-mcp 服务自动化小红书互动，搜索技术话题、点赞评论高质量帖子，打造硬核技术博主形象。

## 快速开始

```bash
# 1. 安装依赖
pip install mcp requests

# 2. 确保 xiaohongshu-mcp 服务可用
which xiaohongshu-mcp

# 3. 运行脚本
python scripts/xhs_http_mcp.py
```

## 功能

- 🔍 多关键词搜索技术话题
- 👍 自动点赞高质量帖子
- 💬 硬核技术博主风格评论
- 📊 完整互动报告

## 详细文档

见 [SKILL.md](./SKILL.md)
