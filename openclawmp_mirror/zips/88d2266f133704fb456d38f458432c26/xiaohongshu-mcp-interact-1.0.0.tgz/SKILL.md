---
name: xiaohongshu-mcp-interact
description: "通过 MCP 服务自动化小红书互动，搜索技术话题、点赞评论高质量帖子，打造硬核技术博主形象"
version: 1.0.1
author: dymas-agent
tags:
  - xiaohongshu
  - mcp
  - automation
  - social-media
  - interaction
---

# 小红书 MCP 自动互动

通过 xiaohongshu-mcp 服务自动化小红书互动，搜索技术话题、点赞评论高质量帖子，打造硬核技术博主形象。

## 功能特性

- 🔍 **智能搜索**：多关键词搜索技术话题帖子（AI工具、DeepSeek、开源项目、本地大模型、网络安全）
- 👍 **自动点赞**：对高质量帖子自动点赞
- 💬 **智能评论**：硬核技术博主风格的评论库，根据话题匹配专业评论
- 📊 **任务汇报**：完整的互动报告，包含帖子ID、评论内容、执行结果

## 工作原理

```
1. 连接 xiaohongshu-mcp MCP 服务
2. 检查登录状态
3. 搜索多个技术话题关键词
4. 解析帖子 ID，筛选技术相关内容
5. 对高质量帖子执行点赞 + 评论
6. 生成互动报告
```

## 依赖

### 必需

- **xiaohongshu-mcp** MCP 服务 — 提供 `check_login_status`、`search_feeds`、`like_feed`、`post_comment_to_feed` 工具
- **Python 3.10+** — 运行脚本
- **MCP Python SDK** — `mcp` 包（用于 stdio 模式）

### 安装 MCP 服务

```bash
# 安装 xiaohongshu-mcp（需自行获取或构建）
# 确保服务可用
which xiaohongshu-mcp
```

### 安装 Python 依赖

```bash
pip install mcp requests
```

## 使用方式

### 方式一：HTTP API 模式（推荐）

MCP 服务以 HTTP 模式运行时：

```bash
# 设置环境变量（可选）
export XHS_MCP_URL="http://localhost:18060"
export XHS_MCP_COMMAND="xiaohongshu-mcp"

# 运行脚本
python scripts/xhs_http_mcp.py
```

### 方式二：Stdio 模式

MCP 服务以 stdio 模式运行时：

```bash
python scripts/xhs_mcp_stdio.py
```

## 配置 Cron 定时任务

```bash
# 每天 15:00 执行互动任务
openclaw cron add \
  --name "Xiaohongshu Tech Interact" \
  --cron "0 15 * * *" \
  --session isolated \
  --message "执行小红书技术话题互动任务：
1. 启动 xiaohongshu-mcp 服务
2. 检查登录状态
3. 搜索 AI工具/DeepSeek/开源项目 关键词
4. 对高质量帖子点赞评论（最多3个）
5. 保存报告到 ~/memory/xhs-interact-report.json
6. 推送简报给用户" \
  --announce
```

## 评论风格

硬核技术博主风格，特点：

- ✅ 有技术深度，不空泛
- ✅ 提及底层原理（RAG、function calling、embedding）
- ✅ 有实操建议（试试量化版本、看源码）
- ✅ 避免营销话术
- ✅ 专业但不装

示例评论：
- "实测过类似的工具，底层原理其实是通过RAG增强检索，效果确实不错。不过有个坑：embedding模型的选择对最终效果影响很大，建议多试几个"
- "本地跑过类似配置，显存占用确实是关键。建议试试量化版本，4bit精度损失很小但内存省一半"

## 文件说明

| 文件 | 用途 |
|------|------|
| `scripts/xhs_http_mcp.py` | HTTP API 模式主脚本（推荐） |
| `scripts/xhs_mcp_stdio.py` | Stdio 模式主脚本 |

## 环境变量

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `XHS_MCP_URL` | MCP 服务 HTTP 地址 | `http://localhost:18060` |
| `XHS_MCP_COMMAND` | MCP 服务命令 | `xiaohongshu-mcp` |

## 注意事项

1. **登录状态**：首次使用需要扫码登录小红书
2. **频率控制**：每次最多互动3个帖子，避免被封
3. **评论质量**：评论库会去重，避免重复
4. **错误处理**：点赞失败时会跳过评论

## 扩展

### 自定义评论库

编辑脚本中的 `TECH_COMMENTS` 字典，按话题分类添加评论：

```python
TECH_COMMENTS = {
    "AI工具": ["评论1", "评论2"],
    "自定义话题": ["评论A", "评论B"],
    "通用技术": ["通用评论"]
}
```

### 添加新搜索关键词

修改 `search_queries` 列表：

```python
search_queries = ["AI工具", "DeepSeek", "你的关键词"]
```

## 问题排查

**Q: MCP 服务连接失败？**
A: 检查服务是否运行（HTTP 模式：`curl $XHS_MCP_URL/health`）

**Q: 登录状态失效？**
A: 重新扫码登录

**Q: 评论失败？**
A: 可能触发了风控，降低互动频率

## 相关资源

- [MCP 协议文档](https://modelcontextprotocol.io/)
- [OpenClaw 文档](https://docs.openclaw.ai)
