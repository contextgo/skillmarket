#!/usr/bin/env python3
"""
小红书技术话题互动 - 通过 xiaohongshu-mcp HTTP API
自动搜索技术话题、点赞评论高质量帖子
"""
import subprocess
import json
import time
import requests
import re
import sys
import os

# MCP 服务地址（可通过环境变量配置）
MCP_URL = os.environ.get("XHS_MCP_URL", "http://localhost:18060")

# 硬核技术博主风格评论
TECH_COMMENTS = [
    "实测过类似的工具，底层原理其实是通过RAG增强检索，效果确实不错。不过有个坑：embedding模型的选择对最终效果影响很大，建议多试几个",
    "这个架构设计挺有意思，动手试试才知道细节。代码不会骗人，建议看看它的GitHub仓库",
    "原理是这样的：这类工具大多基于LLM的function calling能力，关键是prompt engineering的质量",
    "源码读过，架构确实干净。核心是它的插件系统设计，扩展性很强，动手试试改个插件就懂了",
    "本地跑过类似配置，显存占用确实是关键。建议试试量化版本，4bit精度损失很小但内存省一半",
]

class MCPClient:
    def __init__(self):
        self.session_id = None
        self.request_id = 0
    
    def request(self, method, params=None, timeout=60):
        """发送 JSON-RPC 请求"""
        self.request_id += 1
        url = f"{MCP_URL}/mcp"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream"
        }
        if self.session_id:
            headers["Mcp-Session-Id"] = self.session_id
        
        data = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": method,
            "params": params or {}
        }
        
        resp = requests.post(url, json=data, headers=headers, timeout=timeout)
        
        # 获取 session ID
        new_sid = resp.headers.get("Mcp-Session-Id")
        if new_sid:
            self.session_id = new_sid
        
        # 解析 JSON 响应
        try:
            return resp.json()
        except:
            return {"raw": resp.text}
    
    def initialize(self):
        """初始化 MCP 会话"""
        result = self.request("initialize", {
            "protocolVersion": "2024-11-05",
            "capabilities": {},
            "clientInfo": {"name": "xhs-tech", "version": "1.0"}
        }, timeout=30)
        
        print(f"   Session ID: {self.session_id}")
        
        # 发送 initialized 通知
        time.sleep(1)
        self.request("notifications/initialized", timeout=10)
        
        # 等待服务器就绪
        time.sleep(3)
        
        return result
    
    def call_tool(self, name, arguments, timeout=120):
        """调用 MCP 工具"""
        result = self.request("tools/call", {
            "name": name,
            "arguments": arguments
        }, timeout=timeout)
        
        if "result" in result:
            content = result["result"].get("content", [{}])
            if content:
                return content[0].get("text", "")
        elif "error" in result:
            return f"Error: {result['error']}"
        return str(result)

def parse_search_results(raw_text):
    """解析搜索结果，提取帖子信息"""
    feeds = []
    
    try:
        data = json.loads(raw_text)
        items = data.get("data", {}).get("items", [])
        for item in items:
            note_card = item.get("noteCard", {})
            feed_id = item.get("id", "")
            title = note_card.get("displayTitle", "")
            user = note_card.get("user", {})
            nickname = user.get("nickname", user.get("nickName", ""))
            likes = note_card.get("interactInfo", {}).get("likedCount", "0")
            
            if feed_id:
                feeds.append({
                    "id": feed_id,
                    "title": title,
                    "author": nickname,
                    "likes": likes
                })
    except json.JSONDecodeError:
        # 使用正则表达式解析
        ids = re.findall(r'"id"\s*:\s*"([0-9a-f]{24})"', raw_text, re.IGNORECASE)
        titles = re.findall(r'"displayTitle"\s*:\s*"([^"]+)"', raw_text)
        
        for i, fid in enumerate(ids[:10]):
            feeds.append({
                "id": fid,
                "title": titles[i] if i < len(titles) else "Unknown",
                "author": "",
                "likes": "0"
            })
    
    return feeds

def main():
    print("="*60)
    print("🤖 小红书技术话题互动 - 硬核技术博主")
    print("="*60)
    print()
    
    # MCP 服务命令（可通过环境变量或参数配置）
    mcp_command = os.environ.get("XHS_MCP_COMMAND", "xiaohongshu-mcp")
    
    # 启动 MCP 服务
    print("🚀 启动 xiaohongshu-mcp 服务...")
    mcp_proc = subprocess.Popen(
        [mcp_command],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    print(f"   PID: {mcp_proc.pid}\n")
    
    try:
        # 等待服务启动
        print("⏳ 等待服务启动...")
        for i in range(10):
            try:
                resp = requests.get(f"{MCP_URL}/health", timeout=5)
                if resp.status_code == 200:
                    print("   ✅ 服务就绪\n")
                    break
            except:
                pass
            time.sleep(1)
        else:
            print("❌ 服务启动超时")
            return
        
        # 初始化 MCP 客户端
        print("🔄 初始化 MCP 会话...")
        client = MCPClient()
        init_result = client.initialize()
        
        if "error" in init_result:
            print(f"   ❌ 初始化失败: {init_result['error']}")
            return
        
        print("   ✅ 初始化完成\n")
        
        # 检查登录状态
        print("🔍 检查登录状态...")
        login_status = client.call_tool("check_login_status", {}, timeout=30)
        print(f"   状态: {login_status[:100] if login_status else '未知'}")
        
        if "未登录" in login_status or "请先" in login_status:
            print("❌ 需要登录小红书")
            return
        
        print("✅ 已登录\n")
        
        # 搜索技术话题
        print("🔎 搜索技术话题...")
        search_queries = ["AI工具", "DeepSeek", "开源项目"]
        all_feeds = []
        
        for query in search_queries:
            print(f"   搜索: {query}...", end=" ", flush=True)
            result = client.call_tool("search_feeds", {"keyword": query}, timeout=120)
            
            if result and len(result) > 100 and "Error" not in result:
                feeds = parse_search_results(result)
                all_feeds.extend(feeds)
                print(f"✓ 找到 {len(feeds)} 个帖子")
            else:
                print(f"✗ ({result[:80] if result else '无结果'})")
            
            time.sleep(2)
        
        if not all_feeds:
            print("\n❌ 无搜索结果")
            return
        
        print(f"\n✅ 总共找到 {len(all_feeds)} 个帖子\n")
        
        # 选择高质量帖子 (按点赞数排序)
        all_feeds.sort(key=lambda x: int(x.get("likes", "0")), reverse=True)
        
        # 互动
        print("💬 开始互动...\n")
        actions = []
        
        for i, feed in enumerate(all_feeds[:8]):
            if len(actions) >= 3:
                break
            
            feed_id = feed["id"]
            title = feed.get("title", "Unknown")[:30]
            author = feed.get("author", "")
            likes = feed.get("likes", "0")
            
            print(f"--- 互动 {len(actions)+1} ---")
            print(f"   帖子: {title}...")
            print(f"   作者: {author} | 点赞: {likes}")
            print(f"   ID: {feed_id}")
            
            # 点赞
            like_result = client.call_tool("like_feed", {"feed_id": feed_id, "xsec_token": ""}, timeout=60)
            print(f"   👍 点赞: {like_result[:60] if like_result else '超时'}")
            
            if like_result and ("成功" in like_result or "ok" in like_result.lower() or "已" in like_result):
                # 评论
                comment = TECH_COMMENTS[i % len(TECH_COMMENTS)]
                comment_result = client.call_tool(
                    "post_comment_to_feed", 
                    {"feed_id": feed_id, "xsec_token": "", "content": comment},
                    timeout=60
                )
                print(f"   💬 评论: {comment_result[:60] if comment_result else '超时'}")
                print(f"   内容: {comment[:50]}...")
                
                actions.append({
                    "id": feed_id,
                    "title": title,
                    "author": author,
                    "comment": comment,
                    "like_result": like_result[:60] if like_result else "",
                    "comment_result": comment_result[:60] if comment_result else ""
                })
                print(f"   ✅ 成功\n")
            else:
                print(f"   ⚠️ 跳过评论\n")
            
            time.sleep(3)
        
        # 汇报
        print("="*60)
        print("📊 任务汇报")
        print("="*60)
        print(f"✅ 成功互动: {len(actions)} 个帖子\n")
        
        for idx, action in enumerate(actions, 1):
            print(f"--- 互动 {idx} ---")
            print(f"帖子: {action['title']}")
            print(f"作者: {action['author']}")
            print(f"帖子ID: {action['id']}")
            print(f"评论: {action['comment'][:60]}...")
            print()
        
        # 保存报告
        report = {
            "time": time.strftime("%Y-%m-%d %H:%M:%S"),
            "actions": actions,
            "total_feeds_found": len(all_feeds)
        }
        
        report_path = os.path.expanduser("~/memory/xhs-interact-report.json")
        os.makedirs(os.path.dirname(report_path), exist_ok=True)
        with open(report_path, "w") as f:
            json.dump(report, f, ensure_ascii=False, indent=2)
        print(f"📄 报告已保存: {report_path}")
        
    finally:
        print("🛑 停止 MCP 服务...")
        mcp_proc.terminate()
        try:
            mcp_proc.wait(timeout=5)
        except:
            mcp_proc.kill()

if __name__ == "__main__":
    main()
