#!/usr/bin/env python3
"""
小红书技术话题互动 - Stdio 模式
通过 MCP stdio 协议与 xiaohongshu-mcp 服务交互
"""
import asyncio
import json
import sys
import re
import time
import os

try:
    from mcp.client.stdio import StdioServerParameters, stdio_client
    from mcp import ClientSession
except ImportError:
    print("Error: MCP client not installed. Run: pip install mcp")
    sys.exit(1)

# 硬核技术博主风格评论库
TECH_COMMENTS = {
    "AI工具": [
        "实测过类似的工具，底层原理其实是通过RAG增强检索，效果确实不错。不过有个坑：embedding模型的选择对最终效果影响很大，建议多试几个",
        "这个工具的架构设计挺有意思，动手试试才知道细节。代码不会骗人，建议看看它的GitHub仓库",
        "原理是这样的：这类工具大多基于LLM的function calling能力，关键是prompt engineering的质量",
    ],
    "开源项目": [
        "源码读过，架构确实干净。核心是它的插件系统设计，扩展性很强，动手试试改个插件就懂了",
        "这个项目的贡献者指南写得很详细，适合入门开源。代码不会骗人，提个PR比看十遍文档都有用",
        "原理是这样的：它用事件驱动架构解耦了各模块，调试起来比想象中简单",
    ],
    "网络安全": [
        "这个思路很硬核，不过实操要注意边界：生产环境别直接上，先在隔离环境测试。安全无小事",
        "原理是这样的：本质是利用了协议层的gap，动手试试能更深刻理解。但切记授权测试",
        "代码不会骗人，建议对比一下修复前后的diff，能学到很多安全设计的细节",
    ],
    "本地大模型": [
        "本地跑过类似配置，显存占用确实是关键。建议试试量化版本，4bit精度损失很小但内存省一半",
        "动手试试才发现，推理速度瓶颈往往在内存带宽。代码不会骗人，用nvprof看看就知道了",
        "原理是这样的：KV cache优化是大模型推理的必考点，这个项目的实现很值得学习",
    ],
    "DeepSeek": [
        "DeepSeek的MoE架构设计确实有东西，开源模型里算很用心的。动手试试它的API，响应质量能感受到",
        "代码不会骗人，DeepSeek-V3的推理代码写得挺清晰，适合学习大模型架构",
        "原理是这样的：它的MLA注意力机制是个亮点，显著降低了KV cache显存占用",
    ],
    "通用技术": [
        "这个技术点讲得很清楚，动手试试才知道细节。建议看看原文档，会有更深的理解",
        "原理是这样的，但实操要注意版本兼容性。踩过坑才知道文档的重要性",
        "代码不会骗人，建议自己写个demo跑一遍，比看十遍教程都管用",
    ],
}

async def main():
    print("="*60)
    print("🤖 小红书技术话题互动 - 硬核技术博主")
    print("="*60)
    print()
    
    # MCP 服务路径（可通过环境变量配置）
    mcp_command = os.environ.get("XHS_MCP_COMMAND", "xiaohongshu-mcp")
    
    server_params = StdioServerParameters(command=mcp_command)
    
    results = {"login_ok": False, "feeds": [], "actions": [], "errors": []}
    
    try:
        async with stdio_client(server_params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                print("✅ MCP 会话初始化成功\n")
                
                # Step 1: Check login
                print("🔍 检查登录状态")
                try:
                    result = await session.call_tool("check_login_status", {})
                    login_text = result.content[0].text
                    print(login_text[:200])
                    
                    if "未登录" in login_text or "not logged" in login_text.lower():
                        print("❌ 未登录，需要扫码")
                        return
                    
                    results["login_ok"] = True
                    print("✅ 已登录\n")
                except Exception as e:
                    print(f"登录检查失败: {e}")
                    return
                
                # Step 2: Search technical topics
                search_queries = ["AI工具", "DeepSeek", "开源项目"]
                all_feeds = []
                
                print("🔎 搜索热门技术话题")
                
                for query in search_queries:
                    print(f"\n搜索: {query}")
                    try:
                        result = await session.call_tool("search_feeds", {
                            "keyword": query,
                            "count": 10
                        })
                        text = result.content[0].text
                        print(f"  获取 {len(text)} 字符")
                        all_feeds.append({"query": query, "raw": text})
                        await asyncio.sleep(1.5)
                    except Exception as e:
                        print(f"  搜索错误: {e}")
                
                results["feeds"] = all_feeds
                print(f"\n✅ 搜索完成\n")
                
                # Step 3: Parse and select posts
                print("📋 解析帖子...")
                feed_candidates = []
                
                for feed_info in all_feeds:
                    raw = feed_info["raw"]
                    query = feed_info["query"]
                    note_ids = re.findall(r'[0-9a-f]{24}', raw, re.IGNORECASE)
                    
                    for nid in list(set(note_ids))[:5]:
                        feed_candidates.append({
                            "id": nid,
                            "query": query,
                        })
                    
                    print(f"  {query}: {len(note_ids)} 个帖子ID")
                
                # Remove duplicates
                seen = set()
                unique_feeds = []
                for f in feed_candidates:
                    if f["id"] not in seen:
                        seen.add(f["id"])
                        unique_feeds.append(f)
                
                print(f"\n去重后 {len(unique_feeds)} 个唯一帖子\n")
                
                # Step 4: Interact
                print("💬 开始互动...\n")
                interactions = 0
                used_comments = set()
                
                for i, feed in enumerate(unique_feeds[:8]):
                    if interactions >= 3:
                        break
                    
                    feed_id = feed["id"]
                    query = feed["query"]
                    print(f"--- 帖子 {i+1}: {feed_id[:12]}... ({query}) ---")
                    
                    try:
                        # Like
                        result = await session.call_tool("like_feed", {
                            "feed_id": feed_id,
                            "xsec_token": ""
                        })
                        like_result = result.content[0].text
                        print(f"  👍 点赞: {like_result[:80]}")
                        
                        like_success = ("success" in like_result.lower() or 
                                       "ok" in like_result.lower() or 
                                       "已" in like_result or "成功" in like_result)
                        
                        if like_success:
                            # Pick comment based on topic
                            topic_key = query if query in TECH_COMMENTS else "通用技术"
                            available = [c for c in TECH_COMMENTS[topic_key] if c not in used_comments]
                            if not available:
                                available = TECH_COMMENTS["通用技术"]
                            
                            comment = available[0]
                            used_comments.add(comment)
                            
                            # Comment
                            result = await session.call_tool("post_comment_to_feed", {
                                "feed_id": feed_id,
                                "xsec_token": "",
                                "content": comment
                            })
                            comment_result = result.content[0].text
                            print(f"  💬 评论: {comment[:50]}...")
                            print(f"     结果: {comment_result[:80]}")
                            
                            results["actions"].append({
                                "feed_id": feed_id,
                                "topic": query,
                                "comment": comment,
                            })
                            interactions += 1
                            print(f"  ✅ 成功 (总计: {interactions})")
                        else:
                            print(f"  ⚠️ 点赞可能失败，跳过评论")
                        
                    except Exception as e:
                        print(f"  ✗ 互动错误: {e}")
                    
                    await asyncio.sleep(3)
                
                # Report
                print("\n" + "="*60)
                print("📊 任务汇报")
                print("="*60)
                print(f"✅ 成功互动: {len(results['actions'])} 个帖子\n")
                
                for idx, action in enumerate(results["actions"], 1):
                    print(f"--- 互动 {idx} ---")
                    print(f"话题: {action['topic']}")
                    print(f"帖子: {action['feed_id'][:20]}...")
                    print(f"评论: {action['comment'][:60]}...")
                    print()
                
    except Exception as e:
        print(f"MCP连接错误: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(main())
