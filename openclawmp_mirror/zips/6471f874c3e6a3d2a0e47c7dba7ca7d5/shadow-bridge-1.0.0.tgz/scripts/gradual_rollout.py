#!/usr/bin/env python3
"""
灰度发布控制器
管理渐进式迁移的流量切换
"""
import json
import time
from datetime import datetime, timedelta

class GradualRollout:
    """灰度发布控制器"""
    
    STAGES = [
        {"name": "canary", "traffic": 0.01, "duration_hours": 24},
        {"name": "small", "traffic": 0.10, "duration_hours": 48},
        {"name": "medium", "traffic": 0.50, "duration_hours": 72},
        {"name": "full", "traffic": 1.00, "duration_hours": None}
    ]
    
    def __init__(self, stages=None, rollback_threshold=None):
        self.stages = stages or self.STAGES
        self.rollback_threshold = rollback_threshold or {
            "error_rate_multiplier": 2.0,
            "latency_multiplier": 1.5
        }
        self.current_stage = 0
        self.stage_start_time = None
        self.metrics_history = []
        
    def start(self):
        """开始灰度发布"""
        self.current_stage = 0
        self.stage_start_time = datetime.now()
        return self.get_status()
    
    def get_status(self):
        """获取当前状态"""
        stage = self.stages[self.current_stage]
        if self.stage_start_time:
            elapsed = datetime.now() - self.stage_start_time
        else:
            elapsed = timedelta(0)
        
        return {
            "stage": stage["name"],
            "stage_index": self.current_stage,
            "traffic_percent": stage["traffic"] * 100,
            "duration_hours": stage["duration_hours"],
            "elapsed_hours": elapsed.total_seconds() / 3600,
            "can_advance": self._can_advance(),
            "should_rollback": self._should_rollback()
        }
    
    def record_metrics(self, error_rate, latency, throughput=None):
        """记录指标"""
        self.metrics_history.append({
            "timestamp": datetime.now().isoformat(),
            "error_rate": error_rate,
            "latency": latency,
            "throughput": throughput
        })
        
        # 只保留最近100条
        if len(self.metrics_history) > 100:
            self.metrics_history = self.metrics_history[-100:]
    
    def _can_advance(self):
        """是否可以进入下一阶段"""
        stage = self.stages[self.current_stage]
        if stage["duration_hours"] is None:
            return False  # full stage
        
        elapsed = datetime.now() - self.stage_start_time
        return elapsed.total_seconds() >= stage["duration_hours"] * 3600
    
    def _should_rollback(self):
        """是否应该回滚"""
        if len(self.metrics_history) < 10:
            return False
        
        # 计算最近10条的平均值
        recent = self.metrics_history[-10:]
        avg_error = sum(m["error_rate"] for m in recent) / len(recent)
        avg_latency = sum(m["latency"] for m in recent) / len(recent)
        
        # 与阈值比较
        if avg_error > self.rollback_threshold.get("error_rate", 0.01):
            return True
        if avg_latency > self.rollback_threshold.get("latency", 1000):
            return True
        
        return False
    
    def advance(self):
        """进入下一阶段"""
        if not self._can_advance():
            return False
        
        if self.current_stage < len(self.stages) - 1:
            self.current_stage += 1
            self.stage_start_time = datetime.now()
            return True
        
        return False
    
    def rollback(self):
        """回滚到上一阶段"""
        if self.current_stage > 0:
            self.current_stage -= 1
            self.stage_start_time = datetime.now()
            return True
        return False
    
    def export_report(self):
        """导出报告"""
        return {
            "current_stage": self.get_status(),
            "metrics_summary": {
                "total_records": len(self.metrics_history),
                "avg_error_rate": sum(m["error_rate"] for m in self.metrics_history) / len(self.metrics_history) if self.metrics_history else 0,
                "avg_latency": sum(m["latency"] for m in self.metrics_history) / len(self.metrics_history) if self.metrics_history else 0
            },
            "rollback_threshold": self.rollback_threshold
        }


def main():
    """命令行入口"""
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python gradual_rollout.py <command>")
        print("Commands: start, status, advance, rollback, report")
        return
    
    command = sys.argv[1]
    controller = GradualRollout()
    
    if command == "start":
        status = controller.start()
        print(json.dumps(status, indent=2))
    
    elif command == "status":
        print(json.dumps(controller.get_status(), indent=2))
    
    elif command == "advance":
        if controller.advance():
            print("Advanced to next stage")
        else:
            print("Cannot advance yet")
        print(json.dumps(controller.get_status(), indent=2))
    
    elif command == "rollback":
        if controller.rollback():
            print("Rolled back to previous stage")
        else:
            print("Cannot rollback (already at first stage)")
        print(json.dumps(controller.get_status(), indent=2))
    
    elif command == "report":
        print(json.dumps(controller.export_report(), indent=2))
    
    else:
        print(f"Unknown command: {command}")


if __name__ == '__main__':
    main()
