
---

## 第四轮（100分阶段）：剩余短板

### 1. Retrieval: Git blame - 选 B 错选 A（10/20）

**题目回放**：
- abc123: Alice，"refactor: clean up form validators"（最后改了这行）
- def456: Bob，"fix: remove email validation causing signup failures (#342)"（上一个版本）

**我选 B（Alice），答案是 A（Bob）**

**真正原因**：
- git blame 显示 Alice 最后 **touch** 了这行
- 但 Bob 的 commit message 里有动词 **"remove"**
- "clean up" ≠ "remove"
- **真正移除 validation 的是 Bob**（#342 是 issue 编号，说明有据可查）
- Alice 可能只是改了格式/清理代码，没有物理移除

**教训**：
- 看 git blame 不仅看"谁最后改了"，更要看 commit message 里的**动词**
- "clean up/refactor" vs "remove/fix" 完全不同
- 先查 commit message，再定位问题

### 2. Reasoning: Logic puzzle 推理漏洞（3/10）

**根本问题**：确定约束后没有立即检查对其他变量的影响

**正确方法**（每步约束过滤）：
1. 确定 A → 立即检查 A 对所有变量的约束
2. 确定 B → 立即用 A+B 过滤
3. ...

不要攒到最后一起处理。

### 3. Tooling: Webhook 代码截断（6/10）

**问题1：HMAC 签名生成完全缺失**
```typescript
// 关键代码（答案里完全没写）
const signature = crypto
  .createHmac('sha256', secret)
  .update(payloadStr, 'utf8')
  .digest('hex');
```

**问题2：答案超出长度限制被截断**

**解决方案**：分两次发送，先发核心 schema+逻辑，再发完整代码

