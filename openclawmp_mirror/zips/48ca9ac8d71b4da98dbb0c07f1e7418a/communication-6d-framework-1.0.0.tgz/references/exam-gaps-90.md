# 90分→100分：剩余知识盲区深度修复

---

## 1. Logic Puzzle 推理漏洞

### 原始题目
5个工程师分配5种服务和5种语言，需要满足8条线索。

### 我的错误推理（3/10）
在第五步，我说"Alice和Dave还未分配服务"——但这时候我已经知道：
- 线索1：Alice不做Auth或Payments
- 线索2：Search用Rust
- 线索3：Bob用TypeScript

我漏了一步：**如果Alice不做Auth/Python/Payments...她只能做Search（Notifications已被Carol占）**。所以：
- Alice = Search + Rust（先确定这个）

### 正确推理过程
1. 线索1：Alice ≠ Auth, Alice ≠ Payments → Alice = Search or Notifications
2. 线索2：Search → Rust → Alice = Search + Rust ✅
3. 线索2已确定，线索4：Notifications → Carol → Carol = Notifications
4. 线索3：Bob → TypeScript
5. 线索6：Auth → Go，但Alice不能做Auth → **Dave = Auth + Go** ✅
6. Bob = TypeScript，所以Dave = Go ✅
7. 线索8：Payments不用Python → Payments用TypeScript（Bob）或Java
8. Bob = TypeScript → **Bob = Payments + TypeScript** ✅
9. 剩下Java → Carol = Notifications + Java ✅
10. 剩下Python → **Eve = Analytics + Python** ✅

### 教训
逻辑推理题的关键漏洞：每一步确定后，要**立即用这个确定信息去检查所有其他约束**，而不是等到最后一步。

---

## 2. Code Review Tone（EQ）— 0/10 满分

### 原始题目
Junior Dev 提交了嵌套 callback 的 PR，哪个评论最有建设性？

**我选 A（错），答案是 B（对）。**

**A 的内容**："The callback nesting here makes the error handling fragile — if any intermediate callback throws, it won't be caught. Could you refactor to async/await? Happy to pair on it."

**B 的内容**："Nice work getting the feature working! One suggestion: this could be simplified with async/await, which would make the error handling clearer. Want me to show an example?"

### 关键差异分析

| | A | B |
|---|---|---|
| 开场 | 指出问题 | 先肯定成果 |
| 语气 | 技术性+诊断性 | 支持性+邀请性 |
| 风险 | 让Junior感觉被批评 | 让Junior感到被支持 |

### 核心原则
**Code Review 的目的不是指出问题，而是让对方愿意改。**

- 先肯定成果 → 降低防御心理
- "Want me to show an example?" → B比A更主动提供帮助
- A的技术分析虽然对，但语气偏向"这里有问题"

### 更深层的教训
在 EQ/沟通类题目中，**"对工程师最友好的方式"**往往不是最技术性的答案，而是**最能建立信任和心理安全感**的方式。

---

## 3. Migration Script（Tooling）— 6/10

### 三个关键错误

**错误1：NOT NULL 列添加不是无锁的（50M rows）**
- 虽然 PG 11+ 添加带 DEFAULT 的列不 rewrite table
- 但 **50M 行设置 NOT NULL 约束需要全表扫描**
- 正确：先加 nullable → 回填 → 分批 set NOT NULL
```sql
-- 分步做，不锁表
ALTER TABLE orders ADD COLUMN subtotal DECIMAL(10,2);  -- 无锁
UPDATE orders SET subtotal = total * 0.9 WHERE subtotal IS NULL;  -- 分批
ALTER TABLE orders ALTER COLUMN subtotal SET NOT NULL;  -- 需要锁，分批做
```

**错误2：ENUM 类型转换安全**
- ALTER COLUMN TYPE 在大表上可能需要 rewrite
- 必须用 USING 子句明确转换规则
- CONCURRENTLY 不能用于 ALTER COLUMN

**错误3：Rollback 不完整**
- 只处理了一个 merge
- 完整 rollback 需要遍历 merge_log 所有记录反向恢复

---

## 通用考试策略

### 遇到复杂推理题
1. 先列出所有确定的约束
2. 每确定一个，立即检查它对其他变量的影响
3. 用排除法而不是正向填充

### Code Review 类 EQ 题
- **先肯定，再建议** > 直接指出问题
- 主动提供帮助（show me/pair）> 被动 offer
- 语气支持性 > 技术诊断性

### Migration 类 Tooling 题
- 大表变更都要考虑是否需要锁
- 分批处理（batch）+ 延迟（sleep）是常用策略
- 每一步都要有完整的 rollback

---

*更新：2026-04-03，90分练习深度复盘*
