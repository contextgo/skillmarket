# 考试知识盲区修复记录

> 基于 Clawvard 练习模式的反馈，修复真实知识盲区。

---

## 1. Architecture Trade-off 选择题：什么时候选"组合方案"

### 原始题目
- Option 1: 读副本 + 连接池 → 2K req/s
- Option 2: 物化视图（30s 延迟）→ 15K req/s
- Option 3: MongoDB → 20K req/s（失 ACID）
- Option 2 alone → C（我选了C，错了）
- **Option 1 + 2 → D（正确答案）**

### 为什么 D 是对的

**关键判断框架：**
- Option 1 的上限只有 2K，而目标是 10K——**单独不够用**
- Option 2 能到 15K，但 30s 延迟在某些场景下可能有问题
- 当单一方案不够时，**组合方案往往是最优解**

**什么时候选 D（组合）：**
1. 各选项单独都不够完美（上限/风险/成本各有取舍）
2. 组合没有明显缺点（成本可控，技术兼容）
3. 题目暗示"分阶段"或"短期+长期"结合

**什么时候不选 D：**
- 某选项有明显无法接受的缺陷（ACID 丢失、数据丢失）
- 组合带来显著额外复杂度且无实际收益

### 这次错的根本原因
我看到 Option 2 能处理 15K 就直接选了，没有回看 Option 1 的上限。**正确做法：先比较所有选项的上限，再选最优组合**。

---

## 2. TypeScript 代码分析：LSP 优于 ast-grep 的场景

### 原始题目
需要：
1. 区分函数定义 / 调用点 / 字符串引用
2. 找参数数量不对的调用
3. 找重命名后的残留引用

**我选了 ast-grep（C），正确答案 LSP（B）**

### 为什么 LSP 更好

**TypeScript LSP 的能力：**
- 理解完整的 TypeScript 类型系统
- 区分定义（definition）和引用（reference）
- 知道每个调用的参数类型和数量
- 内置于 VSCode / tsserver，不需要额外工具
- 可以查询"所有对函数 X 的引用"，并过滤出定义位置

**ast-grep 的局限：**
- 基于 tree-sitter 的 AST 解析
- 需要写 pattern 匹配代码模式
- 对 TypeScript 的类型推断支持不如 LSP 完整
- 对于"参数数量检查"这种需要类型信息的场景，LSP 更可靠

**什么时候用 ast-grep：**
- 需要跨多种编程语言的分析
- 需要复杂的 pattern 匹配（不仅仅是"找函数调用"）
- 需要批量代码改写（rewrite）
- 项目没有用 TypeScript 或没有完整的 LSP 实现

**什么时候用 LSP：**
- TypeScript/JavaScript 项目
- 需要精确的类型信息（参数类型、函数签名）
- 需要找"某个符号的所有引用"
- 需要 IDE 级别的分析（VSCode 内置）

### 这次错的根本原因
我看到"区分定义和调用"就知道应该用 AST 工具，但选了 ast-grep 而不是 LSP。**在 TypeScript 语境下，LSP 是更精确的选择**，因为它有完整的类型系统支持。

---

## 3. 通用决策原则

### Architecture 题的 Checklist
- [ ] 列出每个选项的上限和下限
- [ ] 检查是否有选项单独就能解决问题
- [ ] 如果没有，组合方案往往是答案
- [ ] 检查组合方案是否有明显冲突

### Tool Selection 题的 Checklist
- [ ] 明确任务需要的精确度（文本 vs 语法 vs 类型）
- [ ] TypeScript → 默认优先 LSP
- [ ] 多语言 → ast-grep / ripgrep
- [ ] 复杂 pattern 匹配 → ast-grep
- [ ] 简单文本搜索 → grep / ripgrep

---

*更新：2026-04-03，来自 Clawvard 练习反馈*
