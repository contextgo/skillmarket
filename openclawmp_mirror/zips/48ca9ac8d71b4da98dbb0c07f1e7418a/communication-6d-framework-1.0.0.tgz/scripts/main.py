#!/usr/bin/env python3
"""
六维度交流能力框架 - 主入口脚本
整合评估、练习、进度追踪功能
"""

import sys
import argparse
from pathlib import Path

# 添加脚本目录到路径
script_dir = Path(__file__).parent
sys.path.insert(0, str(script_dir))

from assess_6d import Communication6DAssessor
from daily_practice import DailyPracticeGenerator
from progress_tracker import ProgressTracker

class Communication6DFramework:
    def __init__(self):
        self.assessor = Communication6DAssessor()
        self.practice_generator = DailyPracticeGenerator()
        self.progress_tracker = ProgressTracker()
        
        self.dimensions = {
            'language_style': '语言风格',
            'emotional_expression': '情感表达', 
            'context_adaptation': '语境适应',
            'logical_thinking': '逻辑思维',
            'interactive_feedback': '互动反馈',
            'cultural_adaptation': '文化适应'
        }
    
    def run_baseline_assessment(self) -> Dict:
        """运行基线评估"""
        print("🦞 启动六维度交流能力基线评估")
        print("=" * 50)
        
        results = self.assessor.conduct_baseline_assessment()
        
        # 保存评估结果
        filepath = self.assessor.save_assessment(results)
        self.progress_tracker.log_assessment_result(results)
        
        print(f"\n✅ 基线评估完成！")
        print(f"评估结果已保存到: {filepath}")
        print(f"建议: 基于评估结果开始个性化练习")
        
        return results
    
    def generate_daily_practice(self, assessment_file: str = None, practice_type: str = "quick") -> Dict:
        """生成每日练习"""
        if assessment_file:
            import json
            with open(assessment_file, 'r', encoding='utf-8') as f:
                assessment_results = json.load(f)
            
            practice_plan = self.practice_generator.generate_personalized_practice(assessment_results)
        else:
            # 使用默认的薄弱维度
            weak_dims = ['language_style', 'emotional_expression']  # 默认关注这两个维度
            practice_plan = self.practice_generator.generate_quick_practice(weak_dims)
        
        # 格式化输出
        formatted_output = self.practice_generator.format_practice_plan(practice_plan)
        print(formatted_output)
        
        return practice_plan
    
    def log_practice_completion(self, practice_plan: Dict, self_evaluation: Dict = None):
        """记录练习完成情况"""
        # 记录练习会话
        result = self.progress_tracker.log_practice_session(practice_plan, self_evaluation)
        print(f"✅ {result}")
        
        # 如果有维度自评改进，也记录下来
        if self_evaluation and 'dimension_improvements' in self_evaluation:
            for dim, improvement in self_evaluation['dimension_improvements'].items():
                if improvement != 0:
                    self.progress_tracker.log_dimension_improvement(dim, improvement, "练习自评")
    
    def show_progress_report(self, report_type: str = "weekly"):
        """显示进度报告"""
        import datetime
        
        if report_type == "weekly":
            report = self.progress_tracker.generate_weekly_report()
            self._display_weekly_report(report)
        elif report_type == "monthly":
            report = self.progress_tracker.generate_monthly_report()
            self._display_monthly_report(report)
    
    def _display_weekly_report(self, report: Dict):
        """显示周报"""
        print(f"\n📊 六维度交流能力周报")
        print(f"时间范围: {report['week_start']} 至 {report['week_ending']}")
        print("=" * 50)
        
        practice_summary = report['practice_summary']
        print(f"📈 练习统计:")
        print(f"  总练习次数: {practice_summary['total_sessions']}")
        print(f"  总练习时长: {practice_summary['total_duration']}分钟")
        print(f"  平均每次时长: {practice_summary['average_duration']:.1f}分钟")
        
        if practice_summary['dimension_frequency']:
            print(f"  维度练习分布:")
            for dim, freq in practice_summary['dimension_frequency'].items():
                print(f"    {self.dimensions.get(dim, dim)}: {freq}次")
        
        print(f"\n💡 本周建议:")
        for rec in report['recommendations']:
            print(f"  • {rec}")
        
        print(f"\n🎯 下周重点:")
        for focus in report['next_week_focus']:
            print(f"  • {focus}")
    
    def _display_monthly_report(self, report: Dict):
        """显示月报"""
        print(f"\n📈 六维度交流能力月报")
        print(f"月份: {report['year']}-{report['month']:02d}")
        print("=" * 50)
        
        trend_analysis = report['assessment_trends']
        print(f"📊 整体趋势: {trend_analysis['overall_trend']}")
        print(f"评估次数: {trend_analysis['assessment_count']}")
        
        if trend_analysis['trends']:
            print(f"\n各维度变化:")
            for dim_key, trend in trend_analysis['trends'].items():
                print(f"  {trend['name']}: {trend['start_score']:.1f} → {trend['end_score']:.1f} "
                      f"({trend['change']:+.1f}分) [{trend['trend']}]")
        
        if report['achievements']:
            print(f"\n🏆 本月成就:")
            for achievement in report['achievements']:
                print(f"  • {achievement}")
        
        if report['areas_for_improvement']:
            print(f"\n⚠️ 需要改进的领域:")
            for area in report['areas_for_improvement']:
                print(f"  • {area}")
        
        if report['long_term_recommendations']:
            print(f"\n🎯 长期建议:")
            for rec in report['long_term_recommendations']:
                print(f"  • {rec}")
    
    def interactive_mode(self):
        """交互式模式"""
        print("🦞 六维度交流能力提升框架 - 交互模式")
        print("=" * 50)
        print("可用命令:")
        print("  1. assess - 运行基线评估")
        print("  2. practice - 生成每日练习")
        print("  3. report - 显示进度报告")
        print("  4. visualize - 生成可视化图表")
        print("  5. help - 显示帮助信息")
        print("  6. quit - 退出")
        print("=" * 50)
        
        while True:
            try:
                command = input("\n请输入命令 (1-6): ").strip().lower()
                
                if command in ['1', 'assess']:
                    self.run_baseline_assessment()
                
                elif command in ['2', 'practice']:
                    practice_type = input("练习类型 (quick/deep): ").strip().lower() or "quick"
                    self.generate_daily_practice(practice_type=practice_type)
                
                elif command in ['3', 'report']:
                    report_type = input("报告类型 (weekly/monthly): ").strip().lower() or "weekly"
                    self.show_progress_report(report_type)
                
                elif command in ['4', 'visualize']:
                    chart_path = self.progress_tracker.create_visualization()
                    print(f"✅ 可视化图表已生成: {chart_path}")
                
                elif command in ['5', 'help']:
                    self._show_help()
                
                elif command in ['6', 'quit', 'exit']:
                    print("👋 感谢使用六维度交流能力提升框架！")
                    break
                
                else:
                    print("❌ 无效命令，请输入1-6或对应命令")
                    
            except KeyboardInterrupt:
                print("\n👋 再见！")
                break
            except Exception as e:
                print(f"❌ 发生错误: {e}")
                print("请重试或输入 'help' 获取帮助")
    
    def _show_help(self):
        """显示帮助信息"""
        print("""
🦞 六维度交流能力提升框架 - 帮助信息

📋 框架介绍:
  本框架通过六个核心维度系统性地提升AI助手的交流能力：
  1. 语言风格 - 表达的自然度、多样性和流畅度
  2. 情感表达 - 情感的温度感、层次感和真诚度  
  3. 语境适应 - 场合感知、文化敏感和时机把握
  4. 逻辑思维 - 观点清晰度、结构化和说服力
  5. 互动反馈 - 响应性、引导力和适应性
  6. 文化适应 - 本土化、时代感和包容性

🚀 使用流程:
  1. assess → 建立基线评估
  2. practice → 每日针对性练习  
  3. log → 记录练习效果和感受
  4. report → 定期回顾进展
  5. visualize → 可视化能力提升轨迹

💡 最佳实践:
  • 每天5-15分钟练习，重在坚持
  • 重点突破薄弱维度
  • 结合实际交流场景练习
  • 及时记录练习感受和发现
  • 每周回顾，每月深度分析

📊 评估标准:
  5分 - 优秀 (4.5-5.0) - 表现卓越，几乎无改进空间
  4分 - 良好 (3.5-4.4) - 表现较好，有小幅提升空间  
  3分 - 中等 (2.5-3.4) - 表现一般，有明显改进空间
  2分 - 较差 (1.5-2.4) - 表现不足，需要重点改进
  1分 - 很差 (1.0-1.4) - 表现严重不足，急需改进
        """)

def main():
    """主函数"""
    framework = Communication6DFramework()
    
    if len(sys.argv) > 1:
        # 命令行模式
        parser = argparse.ArgumentParser(description='六维度交流能力提升框架')
        subparsers = parser.add_subparsers(dest='command', help='可用命令')
        
        # 基线评估
        assess_parser = subparsers.add_parser('assess', help='运行基线评估')
        
        # 练习生成
        practice_parser = subparsers.add_parser('practice', help='生成练习')
        practice_parser.add_argument('--type', choices=['quick', 'deep'], default='quick', help='练习类型')
        practice_parser.add_argument('--assessment', help='评估结果文件')
        
        # 进度报告
        report_parser = subparsers.add_parser('report', help='显示进度报告')
        report_parser.add_argument('--type', choices=['weekly', 'monthly'], default='weekly', help='报告类型')
        
        # 可视化
        viz_parser = subparsers.add_parser('visualize', help='生成可视化')
        viz_parser.add_argument('--dimension', help='特定维度')
        viz_parser.add_argument('--days', type=int, default=30, help='天数范围')
        
        # 交互模式
        interactive_parser = subparsers.add_parser('interactive', help='交互式模式')
        
        args = parser.parse_args()
        
        if args.command == 'assess':
            framework.run_baseline_assessment()
        elif args.command == 'practice':
            framework.generate_daily_practice(args.assessment, args.type)
        elif args.command == 'report':
            framework.show_progress_report(args.type)
        elif args.command == 'visualize':
            chart_path = framework.progress_tracker.create_visualization(args.dimension, args.days)
            print(f"✅ 可视化图表: {chart_path}")
        elif args.command == 'interactive':
            framework.interactive_mode()
        else:
            parser.print_help()
    
    else:
        # 默认进入交互模式
        framework.interactive_mode()

if __name__ == "__main__":
    main()