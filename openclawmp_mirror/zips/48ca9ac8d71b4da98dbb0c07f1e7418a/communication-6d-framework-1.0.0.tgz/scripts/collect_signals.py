#!/usr/bin/env python3
"""
交流质量信号采集脚本
从 OpenClaw session 历史中采集交流质量问题的信号
"""

import json
import sys
import re
from datetime import datetime, timedelta
from pathlib import Path

# 信号类型定义
SIGNAL_TYPES = {
    "Failure": {
        "patterns": [
            r"算了|不用了|我自己来",
            r"不对(?:，|．)应该",
            r"不对(?:，|．)不是",
            r"这不行|太差了|离谱",
            r"听不懂|说人话|太AI了",
            r"能不能?简单点|太啰嗦",
            r"你到底想表达什么",
            r"你说的是?",
            r"慢死了|怎么这么慢",
            r"重新说|再说一遍",
            r"越说越.*乱",
            r"表达不清|说不清楚",
        ],
        "dimensions": ["语言风格", "情感表达", "语境适应"],
        "priority": 3
    },
    "Missing": {
        "patterns": [
            r"我无法|我没法",
            r"我不知道怎么回应",
            r"目前不支持",
            r"我做不到",
            r"这个我帮不了",
            r"没有.*能力",
            r"不知道.*怎么办",
            r"不知道怎么.*安慰",
            r"不知道怎么.*回应",
        ],
        "dimensions": ["情感表达", "互动反馈", "文化适应"],
        "priority": 4
    },
    "Inefficiency": {
        "patterns": [
            r"快一点|能不能?直接",
            r"太长了|精简一下",
            r"说重点|挑重点",
            r"能不能?简短",
            r"说了.*遍",
            r"还没说到重点",
            r"能?简洁点",
            r"短一点|少说",
        ],
        "dimensions": ["逻辑思维", "语言风格", "互动反馈"],
        "priority": 5
    },
    "Suggestion": {
        "patterns": [
            r"能不能?换个说法",
            r"太死板了",
            r"能不能?幽默",
            r"像人一样",
            r"别总是一本正经",
            r"自然点",
            r"能不能?口语化",
            r"换个?风格",
            r"温柔点|热情点",
            r"正经点|严肃点",
        ],
        "dimensions": ["语言风格", "情感表达", "互动反馈"],
        "priority": 2
    }
}

def load_signal_file():
    """加载已有的信号记录"""
    signal_file = Path.home() / "memory" / "communication-signals.md"
    if signal_file.exists():
        return signal_file.read_text()
    return ""

def save_signal(session_key, signal_type, description, dimension, signals_md_path):
    """保存信号到 memory 文件"""
    memory_dir = Path.home() / "memory"
    memory_dir.mkdir(exist_ok=True)
    signal_file = memory_dir / "communication-signals.md"
    
    today = datetime.now().strftime("%Y-%m-%d")
    entry = f"- [{today}] [{signal_type}] {description} | session: {session_key} | 关联维度: {dimension}\n"
    
    existing = signal_file.read_text() if signal_file.exists() else ""
    signal_file.write_text(existing + entry)
    return entry

def analyze_message(text, session_key):
    """分析单条消息，检测交流质量问题信号"""
    found_signals = []
    
    for signal_type, config in SIGNAL_TYPES.items():
        for pattern in config["patterns"]:
            if re.search(pattern, text, re.IGNORECASE):
                # 选择最相关的维度（这里简化处理，选择第一个匹配的模式对应的维度）
                dimension = config["dimensions"][0]
                found_signals.append({
                    "type": signal_type,
                    "dimension": dimension,
                    "priority": config["priority"],
                    "pattern": pattern,
                    "matched_text": text[:100]  # 截取匹配文本片段
                })
                break  # 每种类型只记录一次
    
    return found_signals

def format_report(signals, summary):
    """生成每日交流复盘报告"""
    today = datetime.now().strftime("%Y-%m-%d")
    
    # 按维度分组
    by_dimension = {}
    for s in signals:
        dim = s["dimension"]
        if dim not in by_dimension:
            by_dimension[dim] = []
        by_dimension[dim].append(s)
    
    report = f"""
📋 交流质量日报 — {today}

🔍 交流质量信号（按优先级）：
"""
    # 按优先级排序输出
    sorted_signals = sorted(signals, key=lambda x: x["priority"])
    for i, s in enumerate(sorted_signals[:10], 1):
        dim_emoji = {"语言风格": "💬", "情感表达": "❤️", "语境适应": "🎭", 
                     "逻辑思维": "🧠", "互动反馈": "🔄", "文化适应": "🌏"}.get(s["dimension"], "📝")
        report += f"{i}. [{s['type']}] {dim_emoji} {s['dimension']} — {s['matched_text'][:50]}...\n"
    
    report += f"\n📊 信号统计：\n"
    for dim, dim_signals in by_dimension.items():
        type_counts = {}
        for s in dim_signals:
            t = s["type"]
            type_counts[t] = type_counts.get(t, 0) + 1
        counts_str = ", ".join([f"{k}:{v}" for k, v in type_counts.items()])
        report += f"- {dim}: {len(dim_signals)} 个信号 ({counts_str})\n"
    
    # 推荐练习维度
    if by_dimension:
        # 优先推荐高频或高优先级的维度
        dim_scores = {}
        for dim, dim_signals in by_dimension.items():
            # 加权计分：Failure和Suggestion权重更高
            score = 0
            for s in dim_signals:
                weight = 6 - s["priority"]  # priority越小权重越高
                score += weight
            dim_scores[dim] = score
        
        top_dim = max(dim_scores, key=dim_scores.get)
        report += f"\n🎯 今日练习建议：\n"
        report += f"重点练习维度：{top_dim}\n"
        report += f"（基于{len(by_dimension[top_dim])}个信号，包括"
        top_types = list(set([s['type'] for s in by_dimension[top_dim]]))
        report += "、".join(top_types) + "）\n"
    
    report += f"\n⏰ 上次采集时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
    
    return report

def main():
    # 简单实现：输出使用说明
    print("""
🔍 交流质量信号采集工具

使用方法：
1. 通过 OpenClaw Cron 任务调用
2. 或直接运行：python3 scripts/collect_signals.py --mode scan

功能：
- 扫描指定时间范围内的 session 历史
- 识别交流质量问题的信号
- 保存到 memory/communication-signals.md
- 生成每日交流复盘报告

配置项（在 SKILL.md 中）：
- signal_scan_hours: 回看小时数（默认 24）
- max_signals: 最多保存多少条信号（默认 50）
- signal_retention_days: 信号保留天数（默认 30）
""")
    
    # 如果有 --report 参数，生成报告
    if "--report" in sys.argv:
        signal_file = Path.home() / "memory" / "communication-signals.md"
        if signal_file.exists():
            content = signal_file.read_text()
            print(f"\n📊 已采集信号摘要：\n{content[:500]}...")
        else:
            print("\n暂无信号记录")

if __name__ == "__main__":
    main()
