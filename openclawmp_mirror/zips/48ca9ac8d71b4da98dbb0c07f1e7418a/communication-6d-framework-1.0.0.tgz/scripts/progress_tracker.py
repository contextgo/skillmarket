#!/usr/bin/env python3
"""
六维度交流能力进度追踪和报告生成工具
记录练习效果，生成改进报告，支持长期趋势分析
"""

import json
import datetime
from typing import Dict, List, Tuple
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np

class ProgressTracker:
    def __init__(self, data_dir: str = ".communication_data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.progress_file = self.data_dir / "progress_history.json"
        self.assessments_dir = self.data_dir / "assessments"
        self.assessments_dir.mkdir(exist_ok=True)
        
        self.dimensions = {
            'language_style': '语言风格',
            'emotional_expression': '情感表达',
            'context_adaptation': '语境适应',
            'logical_thinking': '逻辑思维',
            'interactive_feedback': '互动反馈',
            'cultural_adaptation': '文化适应'
        }
    
    def log_practice_session(self, practice_data: Dict, self_evaluation: Dict = None) -> str:
        """记录练习会话"""
        session_record = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': 'practice_session',
            'practice_type': practice_data.get('type', 'unknown'),
            'focus_dimensions': practice_data.get('focus_dimensions', []),
            'exercises_completed': len(practice_data.get('exercises', [])),
            'total_duration': practice_data.get('total_duration', 0),
            'self_evaluation': self_evaluation or {},
            'notes': practice_data.get('notes', ''),
            'mood': practice_data.get('mood', 'neutral'),
            'energy_level': practice_data.get('energy_level', 'medium')
        }
        
        # 加载现有进度数据
        progress_data = self._load_progress_data()
        
        # 添加新记录
        progress_data['sessions'].append(session_record)
        
        # 保存更新
        self._save_progress_data(progress_data)
        
        return f"练习记录已保存 (ID: {len(progress_data['sessions'])}"
    
    def log_dimension_improvement(self, dimension: str, improvement: float, context: str = "") -> str:
        """记录特定维度的改进"""
        improvement_record = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': 'dimension_improvement',
            'dimension': dimension,
            'improvement': improvement,  # +0.1, +0.3 等
            'context': context,
            'new_score': None  # 将在完整评估时更新
        }
        
        progress_data = self._load_progress_data()
        progress_data['improvements'].append(improvement_record)
        self._save_progress_data(progress_data)
        
        return f"维度改进记录: {self.dimensions.get(dimension, dimension)} +{improvement}"
    
    def log_assessment_result(self, assessment_results: Dict) -> str:
        """记录评估结果"""
        # 保存完整的评估结果
        timestamp = datetime.datetime.now()
        filename = f"assessment_{timestamp.strftime('%Y%m%d_%H%M%S')}.json"
        filepath = self.assessments_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(assessment_results, f, ensure_ascii=False, indent=2)
        
        # 记录评估摘要到进度数据
        assessment_summary = {
            'timestamp': timestamp.isoformat(),
            'type': 'assessment',
            'filename': filename,
            'overall_score': assessment_results.get('overall_score', 0),
            'dimension_scores': {
                dim: data.get('score', 0) 
                for dim, data in assessment_results.get('dimensions', {}).items()
            }
        }
        
        progress_data = self._load_progress_data()
        progress_data['assessments'].append(assessment_summary)
        self._save_progress_data(progress_data)
        
        return f"评估结果已保存: {filename}"
    
    def generate_weekly_report(self, week_ending: datetime.date = None) -> Dict:
        """生成周报"""
        if week_ending is None:
            week_ending = datetime.date.today()
        
        week_start = week_ending - datetime.timedelta(days=6)
        
        progress_data = self._load_progress_data()
        
        # 筛选本周数据
        week_sessions = [
            s for s in progress_data['sessions']
            if week_start <= datetime.datetime.fromisoformat(s['timestamp']).date() <= week_ending
        ]
        
        week_improvements = [
            i for i in progress_data['improvements']
            if week_start <= datetime.datetime.fromisoformat(i['timestamp']).date() <= week_ending
        ]
        
        # 生成报告
        report = {
            'week_start': week_start.isoformat(),
            'week_ending': week_ending.isoformat(),
            'practice_summary': self._analyze_practice_sessions(week_sessions),
            'improvement_summary': self._analyze_improvements(week_improvements),
            'recommendations': [],
            'next_week_focus': []
        }
        
        # 基于本周表现生成下周建议
        report['recommendations'] = self._generate_weekly_recommendations(report)
        report['next_week_focus'] = self._suggest_next_week_focus(report)
        
        return report
    
    def generate_monthly_report(self, month: int = None, year: int = None) -> Dict:
        """生成月报"""
        if month is None or year is None:
            today = datetime.date.today()
            month = today.month
            year = today.year
        
        progress_data = self._load_progress_data()
        
        # 筛选本月数据
        month_sessions = [
            s for s in progress_data['sessions']
            if datetime.datetime.fromisoformat(s['timestamp']).month == month and
            datetime.datetime.fromisoformat(s['timestamp']).year == year
        ]
        
        month_assessments = [
            a for a in progress_data['assessments']
            if datetime.datetime.fromisoformat(a['timestamp']).month == month and
            datetime.datetime.fromisoformat(a['timestamp']).year == year
        ]
        
        # 生成本月趋势分析
        trend_analysis = self._analyze_monthly_trends(month_assessments)
        
        report = {
            'month': month,
            'year': year,
            'monthly_summary': self._analyze_practice_sessions(month_sessions),
            'assessment_trends': trend_analysis,
            'achievements': self._identify_achievements(trend_analysis),
            'areas_for_improvement': self._identify_improvement_areas(trend_analysis),
            'long_term_recommendations': []
        }
        
        report['long_term_recommendations'] = self._generate_monthly_recommendations(report)
        
        return report
    
    def create_visualization(self, dimension: str = None, days: int = 30) -> str:
        """创建能力提升可视化图表"""
        progress_data = self._load_progress_data()
        
        # 筛选指定时间段的数据
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=days)
        
        relevant_assessments = [
            a for a in progress_data['assessments']
            if start_date <= datetime.datetime.fromisoformat(a['timestamp']).date() <= end_date
        ]
        
        if not relevant_assessments:
            return "没有足够的数据生成可视化图表"
        
        # 创建图表
        plt.style.use('seaborn-v0_8')
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 10))
        
        if dimension and dimension in self.dimensions:
            # 特定维度的趋势图
            self._plot_dimension_trend(ax1, relevant_assessments, dimension)
        else:
            # 所有维度的综合雷达图
            self._plot_radar_chart(ax1, relevant_assessments[-1])  # 使用最新评估
        
        # 练习频率柱状图
        self._plot_practice_frequency(ax2, progress_data['sessions'], start_date, end_date)
        
        plt.tight_layout()
        
        # 保存图表
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        chart_filename = f"progress_chart_{timestamp}.png"
        chart_path = self.data_dir / chart_filename
        
        plt.savefig(chart_path, dpi=300, bbox_inches='tight')
        plt.close()
        
        return str(chart_path)
    
    def _load_progress_data(self) -> Dict:
        """加载进度数据"""
        if self.progress_file.exists():
            with open(self.progress_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # 初始化数据结构
            return {
                'sessions': [],
                'improvements': [],
                'assessments': [],
                'metadata': {
                    'created_at': datetime.datetime.now().isoformat(),
                    'version': '1.0'
                }
            }
    
    def _save_progress_data(self, data: Dict):
        """保存进度数据"""
        with open(self.progress_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def _analyze_practice_sessions(self, sessions: List[Dict]) -> Dict:
        """分析练习会话数据"""
        if not sessions:
            return {
                'total_sessions': 0,
                'total_duration': 0,
                'average_duration': 0,
                'dimension_frequency': {},
                'practice_consistency': 0
            }
        
        total_duration = sum(s.get('total_duration', 0) for s in sessions)
        
        # 统计各维度练习频率
        dimension_freq = {}
        for session in sessions:
            for dim in session.get('focus_dimensions', []):
                dimension_freq[dim] = dimension_freq.get(dim, 0) + 1
        
        # 计算练习一致性（基于时间间隔）
        consistency = self._calculate_consistency(sessions)
        
        return {
            'total_sessions': len(sessions),
            'total_duration': total_duration,
            'average_duration': total_duration / len(sessions) if sessions else 0,
            'dimension_frequency': dimension_freq,
            'practice_consistency': consistency
        }
    
    def _analyze_improvements(self, improvements: List[Dict]) -> Dict:
        """分析改进记录"""
        if not improvements:
            return {
                'total_improvements': 0,
                'dimension_breakdown': {},
                'average_improvement': 0,
                'biggest_improvement': 0
            }
        
        # 按维度统计
        dimension_breakdown = {}
        total_improvement = 0
        biggest_improvement = 0
        
        for improvement in improvements:
            dim = improvement['dimension']
            value = improvement['improvement']
            
            if dim not in dimension_breakdown:
                dimension_breakdown[dim] = {'count': 0, 'total': 0, 'average': 0}
            
            dimension_breakdown[dim]['count'] += 1
            dimension_breakdown[dim]['total'] += value
            dimension_breakdown[dim]['average'] = dimension_breakdown[dim]['total'] / dimension_breakdown[dim]['count']
            
            total_improvement += value
            biggest_improvement = max(biggest_improvement, value)
        
        return {
            'total_improvements': len(improvements),
            'dimension_breakdown': dimension_breakdown,
            'average_improvement': total_improvement / len(improvements),
            'biggest_improvement': biggest_improvement
        }
    
    def _analyze_monthly_trends(self, assessments: List[Dict]) -> Dict:
        """分析月度趋势"""
        if not assessments:
            return {'trends': {}, 'overall_trend': 'stable'}
        
        # 按时间排序
        sorted_assessments = sorted(assessments, key=lambda x: x['timestamp'])
        
        # 计算各维度趋势
        trends = {}
        for dim_key, dim_name in self.dimensions.items():
            scores = [a['dimension_scores'].get(dim_key, 0) for a in sorted_assessments]
            if len(scores) >= 2:
                # 简单线性趋势
                trend = scores[-1] - scores[0]
                trends[dim_key] = {
                    'name': dim_name,
                    'start_score': scores[0],
                    'end_score': scores[-1],
                    'change': trend,
                    'trend': 'improving' if trend > 0.3 else 'declining' if trend < -0.3 else 'stable'
                }
        
        # 总体趋势
        overall_changes = [t['change'] for t in trends.values()]
        overall_trend = 'improving' if sum(overall_changes) > 0.5 else 'declining' if sum(overall_changes) < -0.5 else 'stable'
        
        return {
            'trends': trends,
            'overall_trend': overall_trend,
            'assessment_count': len(assessments)
        }
    
    def _generate_weekly_recommendations(self, weekly_report: Dict) -> List[str]:
        """生成周度建议"""
        recommendations = []
        
        practice_summary = weekly_report['practice_summary']
        improvement_summary = weekly_report['improvement_summary']
        
        # 基于练习频率的建议
        if practice_summary['total_sessions'] < 3:
            recommendations.append("建议增加练习频率，每周至少3次练习")
        elif practice_summary['total_sessions'] > 7:
            recommendations.append("练习频率很高，注意保持质量而非数量")
        
        # 基于改进记录的建议
        if improvement_summary['total_improvements'] == 0:
            recommendations.append("本周没有记录改进，建议更详细地记录练习感受")
        
        # 基于维度偏好的建议
        dim_freq = practice_summary.get('dimension_frequency', {})
        if dim_freq:
            most_practiced = max(dim_freq.items(), key=lambda x: x[1])
            least_practiced = min(dim_freq.items(), key=lambda x: x[1])
            
            if most_practiced[1] > least_practiced[1] * 2:
                recommendations.append(f"{most_practiced[0]}练习较多，可以增加{least_practiced[0]}的练习")
        
        return recommendations
    
    def _suggest_next_week_focus(self, weekly_report: Dict) -> List[str]:
        """建议下周重点"""
        focus_areas = []
        
        # 基于本周表现的智能建议
        practice_summary = weekly_report['practice_summary']
        dim_freq = practice_summary.get('dimension_frequency', {})
        
        # 选择练习最少的维度作为下周重点
        if dim_freq:
            least_practiced = min(dim_freq.items(), key=lambda x: x[1])
            focus_areas.append(f"重点练习{least_practiced[0]}维度")
        
        # 添加通用建议
        focus_areas.extend([
            "保持每日5分钟快速练习",
            "记录每次练习的具体感受",
            "关注实际交流中的改进效果"
        ])
        
        return focus_areas
    
    def _identify_achievements(self, trend_analysis: Dict) -> List[str]:
        """识别成就"""
        achievements = []
        
        for dim_key, trend in trend_analysis['trends'].items():
            if trend['trend'] == 'improving' and trend['change'] >= 0.5:
                achievements.append(f"{trend['name']}维度显著提升（+{trend['change']:.1f}分）")
        
        if not achievements:
            achievements.append("保持稳定的表现，继续练习")
        
        return achievements
    
    def _identify_improvement_areas(self, trend_analysis: Dict) -> List[str]:
        """识别需要改进的领域"""
        areas = []
        
        for dim_key, trend in trend_analysis['trends'].items():
            if trend['trend'] == 'declining':
                areas.append(f"{trend['name']}维度需要关注（{trend['change']:.1f}分）")
        
        if not areas:
            areas.append("所有维度表现稳定，可以继续当前练习计划")
        
        return areas
    
    def _generate_monthly_recommendations(self, monthly_report: Dict) -> List[str]:
        """生成月度长期建议"""
        recommendations = []
        
        trend_analysis = monthly_report['assessment_trends']
        
        # 基于长期趋势的建议
        if trend_analysis['overall_trend'] == 'improving':
            recommendations.append("整体趋势良好，保持当前练习节奏")
            recommendations.append("可以考虑增加练习难度或复杂度")
        elif trend_analysis['overall_trend'] == 'declining':
            recommendations.append("整体表现有下降趋势，需要调整练习策略")
            recommendations.append("建议重新审视练习方法，可能需要外部指导")
        else:
            recommendations.append("表现稳定，可以尝试新的练习方法")
        
        # 基于具体维度的建议
        for dim_key, trend in trend_analysis['trends'].items():
            if trend['change'] >= 1.0:
                recommendations.append(f"{trend['name']}进步显著，可以作为优势维度重点发展")
            elif trend['change'] <= -0.5:
                recommendations.append(f"{trend['name']}需要重点关注，可能需要专门的练习计划")
        
        return recommendations
    
    def _calculate_consistency(self, sessions: List[Dict]) -> float:
        """计算练习一致性（0-1）"""
        if len(sessions) < 2:
            return 0.0
        
        # 基于时间间隔的一致性计算
        timestamps = [datetime.datetime.fromisoformat(s['timestamp']) for s in sessions]
        timestamps.sort()
        
        intervals = []
        for i in range(1, len(timestamps)):
            interval = (timestamps[i] - timestamps[i-1]).total_seconds() / 3600  # 小时
            intervals.append(interval)
        
        # 理想间隔是24小时，计算与理想间隔的偏离程度
        ideal_interval = 24
        deviations = [abs(interval - ideal_interval) / ideal_interval for interval in intervals]
        avg_deviation = sum(deviations) / len(deviations)
        
        # 一致性分数（偏离越小，一致性越高）
        consistency = max(0, 1 - avg_deviation)
        return round(consistency, 2)
    
    def _plot_dimension_trend(self, ax, assessments: List[Dict], dimension: str):
        """绘制特定维度趋势图"""
        if not assessments:
            return
        
        dates = [datetime.datetime.fromisoformat(a['timestamp']).date() for a in assessments]
        scores = [a['dimension_scores'].get(dimension, 0) for a in assessments]
        
        ax.plot(dates, scores, marker='o', linewidth=2, markersize=6)
        ax.set_title(f'{self.dimensions.get(dimension, dimension)} 能力趋势')
        ax.set_xlabel('日期')
        ax.set_ylabel('分数')
        ax.grid(True, alpha=0.3)
        ax.set_ylim(0, 5.5)
        
        # 添加趋势线
        if len(scores) >= 2:
            z = np.polyfit(range(len(scores)), scores, 1)
            p = np.poly1d(z)
            ax.plot(dates, p(range(len(scores))), "--", alpha=0.7, color='red')
    
    def _plot_radar_chart(self, ax, latest_assessment: Dict):
        """绘制雷达图"""
        dimensions = list(self.dimensions.keys())
        scores = [latest_assessment['dimension_scores'].get(dim, 0) for dim in dimensions]
        
        # 设置雷达图
        angles = np.linspace(0, 2 * np.pi, len(dimensions), endpoint=False).tolist()
        scores += scores[:1]  # 闭合图形
        angles += angles[:1]
        
        ax.plot(angles, scores, 'o-', linewidth=2, color='blue', alpha=0.7)
        ax.fill(angles, scores, alpha=0.25, color='blue')
        ax.set_xticks(angles[:-1])
        ax.set_xticklabels([self.dimensions[dim] for dim in dimensions])
        ax.set_ylim(0, 5)
        ax.set_title('六维度能力雷达图', pad=20)
        ax.grid(True)
    
    def _plot_practice_frequency(self, ax, sessions: List[Dict], start_date: datetime.date, end_date: datetime.date):
        """绘制练习频率图"""
        # 按日期统计练习次数
        date_counts = {}
        current_date = start_date
        while current_date <= end_date:
            date_counts[current_date] = 0
            current_date += datetime.timedelta(days=1)
        
        for session in sessions:
            session_date = datetime.datetime.fromisoformat(session['timestamp']).date()
            if start_date <= session_date <= end_date:
                date_counts[session_date] = date_counts.get(session_date, 0) + 1
        
        dates = list(date_counts.keys())
        counts = list(date_counts.values())
        
        ax.bar(dates, counts, alpha=0.7, color='green')
        ax.set_title('练习频率统计')
        ax.set_xlabel('日期')
        ax.set_ylabel('练习次数')
        ax.grid(True, alpha=0.3)

def main():
    """命令行接口"""
    import argparse
    
    tracker = ProgressTracker()
    
    parser = argparse.ArgumentParser(description='六维度交流能力进度追踪工具')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 记录练习
    log_parser = subparsers.add_parser('log', help='记录练习会话')
    log_parser.add_argument('--type', required=True, help='练习类型')
    log_parser.add_argument('--focus', nargs='+', help='重点维度')
    log_parser.add_argument('--duration', type=int, help='练习时长')
    log_parser.add_argument('--notes', help='练习笔记')
    log_parser.add_argument('--mood', default='neutral', help='心情')
    log_parser.add_argument('--energy', default='medium', help='精力水平')
    
    # 记录改进
    improve_parser = subparsers.add_parser('improve', help='记录维度改进')
    improve_parser.add_argument('--dimension', required=True, help='维度')
    improve_parser.add_argument('--value', type=float, required=True, help='改进值')
    improve_parser.add_argument('--context', help='改进背景')
    
    # 生成报告
    report_parser = subparsers.add_parser('report', help='生成报告')
    report_parser.add_argument('--type', choices=['weekly', 'monthly'], default='weekly', help='报告类型')
    report_parser.add_argument('--date', help='报告日期 (YYYY-MM-DD)')
    report_parser.add_argument('--visual', action='store_true', help='生成可视化图表')
    
    # 可视化
    viz_parser = subparsers.add_parser('visualize', help='生成可视化')
    viz_parser.add_argument('--dimension', help='特定维度')
    viz_parser.add_argument('--days', type=int, default=30, help='天数范围')
    
    args = parser.parse_args()
    
    if args.command == 'log':
        practice_data = {
            'type': args.type,
            'focus_dimensions': args.focus or [],
            'total_duration': args.duration or 0,
            'notes': args.notes or '',
            'mood': args.mood,
            'energy_level': args.energy
        }
        result = tracker.log_practice_session(practice_data)
        print(f"✅ {result}")
    
    elif args.command == 'improve':
        result = tracker.log_dimension_improvement(args.dimension, args.value, args.context)
        print(f"✅ {result}")
    
    elif args.command == 'report':
        if args.type == 'weekly':
            date = datetime.date.fromisoformat(args.date) if args.date else datetime.date.today()
            report = tracker.generate_weekly_report(date)
            print(f"📊 周报 ({report['week_start']} to {report['week_ending']})")
            print(f"练习会话: {report['practice_summary']['total_sessions']}")
            print(f"总时长: {report['practice_summary']['total_duration']}分钟")
            print(f"建议: {', '.join(report['recommendations'])}")
            print(f"下周重点: {', '.join(report['next_week_focus'])}")
            
            if args.visual:
                chart_path = tracker.create_visualization(days=7)
                print(f"📈 可视化图表: {chart_path}")
        
        else:  # monthly
            today = datetime.date.today()
            report = tracker.generate_monthly_report(today.month, today.year)
            print(f"📈 月报 ({today.year}-{today.month:02d})")
            print(f"成就: {', '.join(report['achievements'])}")
            print(f"改进领域: {', '.join(report['areas_for_improvement'])}")
            print(f"长期建议: {', '.join(report['long_term_recommendations'])}")
            
            if args.visual:
                chart_path = tracker.create_visualization(days=30)
                print(f"📊 可视化图表: {chart_path}")
    
    elif args.command == 'visualize':
        chart_path = tracker.create_visualization(args.dimension, args.days)
        print(f"📊 可视化图表已生成: {chart_path}")
    
    else:
        # 显示帮助
        parser.print_help()

if __name__ == "__main__":
    main()