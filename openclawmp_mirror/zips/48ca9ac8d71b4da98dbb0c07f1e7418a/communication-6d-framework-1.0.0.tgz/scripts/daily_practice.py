#!/usr/bin/env python3
"""
六维度交流能力日常练习生成器
基于评估结果生成个性化的日常练习任务
"""

import json
import random
import datetime
from typing import Dict, List, Tuple
from pathlib import Path

class DailyPracticeGenerator:
    def __init__(self):
        self.practice_templates = {
            'language_style': {
                'quick': [
                    {
                        'name': 'AI痕迹消除',
                        'duration': 3,
                        'task': '识别并改写以下表达中的AI痕迹',
                        'examples': [
                            '这标志着我们在能力提升方面迈出了重要的一步',
                            '这不仅提高了效率，也增强了用户体验',
                            '随着时间的推移，我们逐渐认识到'
                        ],
                        'solution_hints': [
                            '尝试：我们在能力提升上又前进了一小步',
                            '尝试：效率提高了，用户体验也更好了',
                            '尝试：慢慢地，我们发现'
                        ]
                    },
                    {
                        'name': '句式多样化',
                        'duration': 2,
                        'task': '用3种不同方式表达同一个意思',
                        'examples': ['技能安装成功'],
                        'targets': ['口语化', '正式但自然', '简洁有力']
                    }
                ],
                'deep': [
                    {
                        'name': '长文自然化改写',
                        'duration': 15,
                        'task': '将一段技术文档改写成更自然的对话体',
                        'material': '技术文档片段',
                        'requirements': ['保持技术准确性', '增加对话感', '减少术语堆砌']
                    },
                    {
                        'name': '语境适应练习',
                        'duration': 15,
                        'task': '同一信息在不同场合的表达方式',
                        'scenarios': ['向朋友解释', '在工作会议中', '写邮件通知'],
                        'content': '新技术功能介绍'
                    }
                ]
            },
            'emotional_expression': {
                'quick': [
                    {
                        'name': '温度添加练习',
                        'duration': 3,
                        'task': '为冰冷的技术表达添加适当情感',
                        'examples': [
                            '系统性能提升了20%',
                            '安装过程完成',
                            '发现了一个新的问题'
                        ],
                        'emotion_types': ['兴奋', '欣慰', '担忧', '惊喜']
                    },
                    {
                        'name': '情感层次化',
                        'duration': 2,
                        'task': '表达从一种情感到另一种情感的转变',
                        'transitions': ['失望→希望', '困惑→理解', '担心→放心']
                    }
                ],
                'deep': [
                    {
                        'name': '情感故事构建',
                        'duration': 20,
                        'task': '讲述一个技术问题解决过程中的情感变化',
                        'structure': ['遇到困难时的挫败', '找到解决方案时的兴奋', '最终实现时的满足'],
                        'requirements': '要真实，不要夸张'
                    }
                ]
            },
            'context_adaptation': {
                'quick': [
                    {
                        'name': '场合切换练习',
                        'duration': 3,
                        'task': '同一内容在不同正式程度下的表达',
                        'contexts': ['很正式', '一般工作', '很随意'],
                        'content': '项目进度汇报'
                    },
                    {
                        'name': '文化敏感度',
                        'duration': 2,
                        'task': '识别可能的文化敏感表达并提供替代',
                        'examples': ['这个时间对大家都很方便', '这个做法很正常']
                    }
                ],
                'deep': [
                    {
                        'name': '跨文化交际模拟',
                        'duration': 15,
                        'task': '模拟与不同文化背景用户的交流',
                        'cultures': ['直接型', '含蓄型', '关系导向', '任务导向'],
                        'scenarios': ['需求澄清', '问题解决', '意见分歧']
                    }
                ]
            },
            'logical_thinking': {
                'quick': [
                    {
                        'name': '逻辑清晰度检查',
                        'duration': 3,
                        'task': '识别并改进逻辑跳跃的表达',
                        'examples': ['因为A，所以Z', '很明显，我们应该这样做'],
                        'improvement': '补充中间推理步骤'
                    },
                    {
                        'name': '结构化表达',
                        'duration': 2,
                        'task': '用"总-分-总"结构重新组织表达',
                        'content_types': ['问题分析', '方案介绍', '观点阐述']
                    }
                ],
                'deep': [
                    {
                        'name': '复杂问题分析',
                        'duration': 20,
                        'task': '分析一个有多个因素的技术问题',
                        'structure': ['问题定义', '影响因素识别', '优先级排序', '解决方案构建'],
                        'requirements': '逻辑链条要清晰完整'
                    }
                ]
            },
            'interactive_feedback': {
                'quick': [
                    {
                        'name': '提问技巧练习',
                        'duration': 3,
                        'task': '将陈述句改写成更有效的提问',
                        'examples': [
                            '你应该这样做',
                            '这个方法有问题',
                            '我们需要更多信息'
                        ],
                        'target_types': ['开放式问题', '澄清性问题', '引导性问题']
                    },
                    {
                        'name': '反馈即时性',
                        'duration': 2,
                        'task': '对用户不同输入的恰当响应方式',
                        'user_inputs': ['感谢', '抱怨', '质疑', '赞同'],
                        'response_styles': ['温暖回应', '理解共情', '耐心解释', '积极互动']
                    }
                ],
                'deep': [
                    {
                        'name': '困难对话处理',
                        'duration': 15,
                        'task': '模拟处理用户不满或误解的情况',
                        'scenarios': ['用户对结果不满意', '用户误解了功能', '用户情绪激动'],
                        'principles': ['先理解再解释', '承认感受', '提供解决方案']
                    }
                ]
            },
            'cultural_adaptation': {
                'quick': [
                    {
                        'name': '本土化表达',
                        'duration': 3,
                        'task': '将翻译腔改写成地道中文表达',
                        'examples': [
                            '这将会对你有帮助',
                            '让我来协助你',
                            '这是一个很好的问题'
                        ],
                        'native_alternatives': ['这样可能帮到你', '我来帮你', '这个问题问得好']
                    },
                    {
                        'name': '时代感把握',
                        'duration': 2,
                        'task': '识别并更新过时的表达方式',
                        'categories': ['网络用语', '流行表达', '过时词汇']
                    }
                ],
                'deep': [
                    {
                        'name': '代际交流适应',
                        'duration': 15,
                        'task': '针对不同年龄段调整表达方式',
                        'age_groups': ['年轻人(18-30)', '中年人(30-50)', '老年人(50+)'],
                        'adjustment_aspects': ['用词选择', '语速节奏', '话题偏好', '技术理解']
                    }
                ]
            }
        }
        
        self.difficulty_levels = {
            'beginner': '基础级 - 适合刚开始练习的用户',
            'intermediate': '进阶级 - 适合有一定基础的用户',
            'advanced': '高级 - 适合追求精通的用户'
        }
    
    def generate_quick_practice(self, weak_dimensions: List[str], difficulty: str = 'intermediate') -> Dict:
        """生成5分钟快速练习"""
        practice_plan = {
            'type': 'quick',
            'total_duration': 5,
            'exercises': [],
            'focus_dimensions': weak_dimensions,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        # 为每个薄弱维度选择1-2个快速练习
        time_per_exercise = 5 // len(weak_dimensions) if weak_dimensions else 1
        
        for dim in weak_dimensions[:3]:  # 最多3个维度，避免超时
            if dim in self.practice_templates and self.practice_templates[dim]['quick']:
                exercise = random.choice(self.practice_templates[dim]['quick'])
                exercise_copy = exercise.copy()
                exercise_copy['dimension'] = dim
                exercise_copy['allocated_time'] = min(exercise_copy.get('duration', 2), time_per_exercise)
                practice_plan['exercises'].append(exercise_copy)
        
        # 如果还有时间，添加一个综合练习
        remaining_time = 5 - sum(ex.get('allocated_time', 0) for ex in practice_plan['exercises'])
        if remaining_time >= 2:
            # 添加一个跨维度的综合练习
            comprehensive_exercise = {
                'name': '综合自然化检查',
                'duration': remaining_time,
                'dimension': 'comprehensive',
                'task': '检查一段日常对话，识别所有六个维度可以改进的地方',
                'allocated_time': remaining_time
            }
            practice_plan['exercises'].append(comprehensive_exercise)
        
        return practice_plan
    
    def generate_deep_practice(self, focus_dimensions: List[str], difficulty: str = 'intermediate') -> Dict:
        """生成30分钟深度练习"""
        practice_plan = {
            'type': 'deep',
            'total_duration': 30,
            'exercises': [],
            'focus_dimensions': focus_dimensions,
            'timestamp': datetime.datetime.now().isoformat()
        }
        
        # 为每个重点维度选择一个深度练习
        time_per_exercise = 25 // len(focus_dimensions) if focus_dimensions else 5
        
        for i, dim in enumerate(focus_dimensions[:2]):  # 最多2个维度，保证深度
            if dim in self.practice_templates and self.practice_templates[dim]['deep']:
                exercise = random.choice(self.practice_templates[dim]['deep'])
                exercise_copy = exercise.copy()
                exercise_copy['dimension'] = dim
                exercise_copy['allocated_time'] = min(exercise_copy.get('duration', 15), time_per_exercise)
                exercise_copy['sequence'] = i + 1
                practice_plan['exercises'].append(exercise_copy)
        
        # 添加5分钟的总结反思时间
        reflection_exercise = {
            'name': '练习总结与反思',
            'duration': 5,
            'dimension': 'reflection',
            'task': '总结本次练习的收获，记录可以改进的地方，规划下次练习重点',
            'allocated_time': 5,
            'sequence': len(practice_plan['exercises']) + 1,
            'questions': [
                '哪个练习最有收获？',
                '哪些地方还需要改进？',
                '下次练习应该重点关注什么？'
            ]
        }
        practice_plan['exercises'].append(reflection_exercise)
        
        return practice_plan
    
    def generate_personalized_practice(self, assessment_results: Dict, available_time: int = 5) -> Dict:
        """基于评估结果生成个性化练习"""
        # 识别薄弱维度（分数低于3.5的）
        weak_dimensions = []
        for dim_key, dim_data in assessment_results['dimensions'].items():
            if dim_data['score'] < 3.5:
                weak_dimensions.append(dim_key)
        
        # 如果没有明显薄弱维度，选择分数相对较低的
        if not weak_dimensions:
            # 按分数排序，选择最低的2-3个
            sorted_dims = sorted(assessment_results['dimensions'].items(), 
                               key=lambda x: x[1]['score'])
            weak_dimensions = [dim[0] for dim in sorted_dims[:2]]
        
        # 根据可用时间选择练习类型
        if available_time <= 10:
            return self.generate_quick_practice(weak_dimensions)
        else:
            return self.generate_deep_practice(weak_dimensions)
    
    def create_practice_schedule(self, assessment_results: Dict, days: int = 7) -> List[Dict]:
        """创建一周练习计划"""
        schedule = []
        
        # 基础安排：快速练习每天，深度练习隔天
        for day in range(1, days + 1):
            daily_plan = {
                'day': day,
                'date': (datetime.datetime.now() + datetime.timedelta(days=day-1)).isoformat(),
                'quick_practice': self.generate_personalized_practice(assessment_results, 5),
                'deep_practice': None
            }
            
            # 每隔一天安排深度练习
            if day % 2 == 1:
                daily_plan['deep_practice'] = self.generate_personalized_practice(assessment_results, 30)
            
            schedule.append(daily_plan)
        
        return schedule
    
    def format_practice_plan(self, practice_plan: Dict) -> str:
        """格式化输出练习计划"""
        output = []
        output.append("🦞 六维度交流能力练习计划")
        output.append("=" * 40)
        output.append(f"类型: {'快速练习' if practice_plan['type'] == 'quick' else '深度练习'}")
        output.append(f"总时长: {practice_plan['total_duration']}分钟")
        output.append(f"重点维度: {', '.join(practice_plan['focus_dimensions'])}")
        output.append("")
        
        for i, exercise in enumerate(practice_plan['exercises'], 1):
            output.append(f"练习 {i}: {exercise['name']}")
            output.append(f"维度: {exercise['dimension']}")
            output.append(f"时长: {exercise['allocated_time']}分钟")
            output.append(f"任务: {exercise['task']}")
            
            if 'examples' in exercise:
                output.append("示例:")
                for example in exercise['examples']:
                    output.append(f"  - {example}")
            
            if 'questions' in exercise:
                output.append("思考问题:")
                for question in exercise['questions']:
                    output.append(f"  - {question}")
            
            output.append("")
        
        return "\n".join(output)

def main():
    """主函数 - 命令行接口"""
    import sys
    import argparse
    
    generator = DailyPracticeGenerator()
    
    parser = argparse.ArgumentParser(description='六维度交流能力练习生成器')
    parser.add_argument('--type', choices=['quick', 'deep', 'personalized'], 
                       default='personalized', help='练习类型')
    parser.add_argument('--time', type=int, default=5, help='可用时间（分钟）')
    parser.add_argument('--assessment', help='评估结果文件路径')
    parser.add_argument('--focus', nargs='+', help='重点维度')
    parser.add_argument('--schedule', type=int, help='生成一周计划（天数）')
    
    args = parser.parse_args()
    
    if args.type == 'personalized' and args.assessment:
        # 基于评估结果的个性化练习
        import json
        with open(args.assessment, 'r', encoding='utf-8') as f:
            assessment_results = json.load(f)
        
        if args.schedule:
            # 生成一周计划
            schedule = generator.create_practice_schedule(assessment_results, args.schedule)
            print(f"🦞 生成了一周的练习计划（{args.schedule}天）")
            for day_plan in schedule:
                print(f"\n--- 第{day_plan['day']}天 ---")
                print(generator.format_practice_plan(day_plan['quick_practice']))
                if day_plan['deep_practice']:
                    print("\n--- 深度练习 ---")
                    print(generator.format_practice_plan(day_plan['deep_practice']))
        else:
            # 生成单次个性化练习
            practice_plan = generator.generate_personalized_practice(assessment_results, args.time)
            print(generator.format_practice_plan(practice_plan))
    
    elif args.type == 'quick' and args.focus:
        # 快速练习
        practice_plan = generator.generate_quick_practice(args.focus)
        print(generator.format_practice_plan(practice_plan))
    
    elif args.type == 'deep' and args.focus:
        # 深度练习
        practice_plan = generator.generate_deep_practice(args.focus)
        print(generator.format_practice_plan(practice_plan))
    
    else:
        # 默认生成示例练习
        example_focus = ['language_style', 'emotional_expression']
        practice_plan = generator.generate_quick_practice(example_focus)
        print(generator.format_practice_plan(practice_plan))

if __name__ == "__main__":
    main()