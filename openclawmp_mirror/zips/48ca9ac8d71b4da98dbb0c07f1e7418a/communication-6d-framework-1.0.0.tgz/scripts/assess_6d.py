#!/usr/bin/env python3
"""
六维度交流能力评估工具
基于具体行为指标对AI助手的交流能力进行量化评估
"""

import json
import datetime
from typing import Dict, List, Tuple
from pathlib import Path

class Communication6DAssessor:
    def __init__(self):
        self.dimensions = {
            'language_style': {
                'name': '语言风格',
                'description': '表达的自然度、多样性和流畅度',
                'indicators': [
                    '避免AI腔，贴近人类表达',
                    '句式变化丰富，避免重复模式',
                    '节奏感强，朗朗上口'
                ]
            },
            'emotional_expression': {
                'name': '情感表达',
                'description': '情感的温度感、层次感和真诚度',
                'indicators': [
                    '有情感色彩，不冰冷',
                    '情感表达有细腻变化',
                    '情感表达真实可信'
                ]
            },
            'context_adaptation': {
                'name': '语境适应',
                'description': '场合感知、文化敏感和时机把握',
                'indicators': [
                    '正式/非正式场合切换得当',
                    '本土化表达和习惯适应',
                    '知道何时说什么'
                ]
            },
            'logical_thinking': {
                'name': '逻辑思维',
                'description': '观点清晰度、结构化和说服力',
                'indicators': [
                    '观点明确，条理清晰',
                    '层次分明，逻辑连贯',
                    '论证有力，令人信服'
                ]
            },
            'interactive_feedback': {
                'name': '互动反馈',
                'description': '响应性、引导力和适应性',
                'indicators': [
                    '及时恰当的反馈',
                    '善于提问和引导对话',
                    '根据反馈调整表达方式'
                ]
            },
            'cultural_adaptation': {
                'name': '文化适应',
                'description': '本土化、时代感和包容性',
                'indicators': [
                    '符合中文表达习惯',
                    '跟上当前语言潮流',
                    '尊重多元文化背景'
                ]
            }
        }
        
        self.scoring_criteria = {
            5: '优秀 - 表现卓越，几乎无改进空间',
            4: '良好 - 表现较好，有小幅提升空间',
            3: '中等 - 表现一般，有明显改进空间',
            2: '较差 - 表现不足，需要重点改进',
            1: '很差 - 表现严重不足，急需改进'
        }
    
    def conduct_baseline_assessment(self, recent_interactions: List[str] = None) -> Dict:
        """进行基线评估"""
        print("🦞 启动六维度交流能力基线评估")
        print("=" * 50)
        
        results = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': 'baseline',
            'dimensions': {},
            'overall_score': 0,
            'recommendations': []
        }
        
        for dim_key, dim_data in self.dimensions.items():
            print(f"\n📊 评估维度: {dim_data['name']}")
            print(f"描述: {dim_data['description']}")
            print("评估指标:")
            
            for i, indicator in enumerate(dim_data['indicators'], 1):
                print(f"  {i}. {indicator}")
            
            # 模拟评估过程（实际使用中会基于真实交互数据）
            import random
            score = random.randint(2, 4)  # 基线评估通常在2-4分范围
            
            print(f"\n当前评估分数: {score}/5 - {self.scoring_criteria[score]}")
            
            results['dimensions'][dim_key] = {
                'name': dim_data['name'],
                'score': score,
                'criteria': self.scoring_criteria[score],
                'indicators_met': [],  # 在实际评估中填写
                'improvement_areas': []  # 在实际评估中填写
            }
        
        # 计算总体分数
        total_score = sum(data['score'] for data in results['dimensions'].values())
        results['overall_score'] = round(total_score / 6, 2)
        
        # 生成改进建议
        results['recommendations'] = self._generate_recommendations(results['dimensions'])
        
        print(f"\n📈 评估完成!")
        print(f"总体评分: {results['overall_score']}/5.0")
        print(f"能力等级: {self._get_ability_level(results['overall_score'])}")
        
        return results
    
    def _generate_recommendations(self, dimensions: Dict) -> List[str]:
        """生成个性化改进建议"""
        recommendations = []
        
        # 找出得分最低的维度
        low_scoring = [k for k, v in dimensions.items() if v['score'] <= 2.5]
        high_scoring = [k for k, v in dimensions.items() if v['score'] >= 4.0]
        
        if low_scoring:
            weak_dims = [dimensions[dim]['name'] for dim in low_scoring]
            recommendations.append(f"重点改进维度: {', '.join(weak_dims)}")
            
        if high_scoring:
            strong_dims = [dimensions[dim]['name'] for dim in high_scoring]
            recommendations.append(f"保持优势维度: {', '.join(strong_dims)}")
            
        # 基于具体分数提供建议
        avg_score = sum(v['score'] for v in dimensions.values()) / 6
        
        if avg_score < 3.0:
            recommendations.append("建议加强基础练习，每天15-20分钟")
            recommendations.append("重点练习自然表达和情感温度")
        elif avg_score < 4.0:
            recommendations.append("建议每天5-10分钟针对性练习")
            recommendations.append("可以尝试更复杂的情境练习")
        else:
            recommendations.append("保持当前练习频率，注重细节优化")
            recommendations.append("可以尝试指导其他AI助手")
            
        return recommendations
    
    def _get_ability_level(self, overall_score: float) -> str:
        """根据总体分数确定能力等级"""
        if overall_score >= 4.5:
            return "专家级 - 交流能力卓越"
        elif overall_score >= 4.0:
            return "高级 - 交流能力优秀"
        elif overall_score >= 3.5:
            return "中级 - 交流能力良好"
        elif overall_score >= 3.0:
            return "初级 - 交流能力一般"
        else:
            return "入门级 - 需要重点提升"
    
    def save_assessment(self, results: Dict, filename: str = None) -> str:
        """保存评估结果"""
        if not filename:
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            filename = f"assessment_6d_{timestamp}.json"
        
        filepath = Path(filename)
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        
        return str(filepath)
    
    def load_assessment(self, filepath: str) -> Dict:
        """加载评估结果"""
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def compare_assessments(self, old_results: Dict, new_results: Dict) -> Dict:
        """对比两次评估结果"""
        comparison = {
            'timestamp_old': old_results['timestamp'],
            'timestamp_new': new_results['timestamp'],
            'overall_improvement': round(new_results['overall_score'] - old_results['overall_score'], 2),
            'dimension_changes': {},
            'achievements': [],
            'areas_need_attention': []
        }
        
        for dim_key in self.dimensions.keys():
            old_score = old_results['dimensions'][dim_key]['score']
            new_score = new_results['dimensions'][dim_key]['score']
            change = new_score - old_score
            
            comparison['dimension_changes'][dim_key] = {
                'name': self.dimensions[dim_key]['name'],
                'old_score': old_score,
                'new_score': new_score,
                'change': change,
                'improvement_status': '显著提升' if change >= 0.5 else '有所提升' if change > 0 else '保持不变' if change == 0 else '需要关注'
            }
            
            # 识别成就和需要关注的领域
            if change >= 0.5:
                comparison['achievements'].append(self.dimensions[dim_key]['name'])
            elif change <= -0.5:
                comparison['areas_need_attention'].append(self.dimensions[dim_key]['name'])
        
        return comparison

def main():
    """主函数 - 用于命令行运行"""
    import sys
    
    assessor = Communication6DAssessor()
    
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == 'baseline':
            # 运行基线评估
            results = assessor.conduct_baseline_assessment()
            filepath = assessor.save_assessment(results)
            print(f"\n✅ 基线评估结果已保存到: {filepath}")
            
        elif command == 'compare' and len(sys.argv) == 4:
            # 对比两次评估
            old_file = sys.argv[2]
            new_file = sys.argv[3]
            
            old_results = assessor.load_assessment(old_file)
            new_results = assessor.load_assessment(new_file)
            
            comparison = assessor.compare_assessments(old_results, new_results)
            
            print("📊 能力提升对比分析")
            print("=" * 40)
            print(f"总体提升: {comparison['overall_improvement']:+.2f}分")
            
            if comparison['achievements']:
                print(f"🏆 显著提升维度: {', '.join(comparison['achievements'])}")
                
            if comparison['areas_need_attention']:
                print(f"⚠️ 需要关注维度: {', '.join(comparison['areas_need_attention'])}")
                
            # 保存对比结果
            comparison_file = f"comparison_{datetime.datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            with open(comparison_file, 'w', encoding='utf-8') as f:
                json.dump(comparison, f, ensure_ascii=False, indent=2)
            print(f"\n✅ 对比分析已保存到: {comparison_file}")
            
        else:
            print("使用方法:")
            print("  python assess_6d.py baseline                    # 运行基线评估")
            print("  python assess_6d.py compare <old_file> <new_file>  # 对比两次评估")
    else:
        # 默认运行基线评估
        results = assessor.conduct_baseline_assessment()
        filepath = assessor.save_assessment(results)
        print(f"\n✅ 基线评估结果已保存到: {filepath}")

if __name__ == "__main__":
    main()