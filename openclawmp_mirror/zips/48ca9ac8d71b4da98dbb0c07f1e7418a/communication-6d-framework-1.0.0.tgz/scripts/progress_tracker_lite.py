#!/usr/bin/env python3
"""
六维度交流能力进度追踪和报告生成工具 - 轻量版
不依赖matplotlib，使用文本图表
"""

import json
import datetime
from typing import Dict, List, Tuple
from pathlib import Path

class ProgressTracker:
    def __init__(self, data_dir: str = ".communication_data"):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(exist_ok=True)
        
        self.progress_file = self.data_dir / "progress_history.json"
        self.assessments_dir = self.data_dir / "assessments"
        self.assessments_dir.mkdir(exist_ok=True)
        
        self.dimensions = {
            'language_style': '语言风格',
            'emotional_expression': '情感表达',
            'context_adaptation': '语境适应',
            'logical_thinking': '逻辑思维',
            'interactive_feedback': '互动反馈',
            'cultural_adaptation': '文化适应'
        }
    
    def log_practice_session(self, practice_data: Dict, self_evaluation: Dict = None) -> str:
        """记录练习会话"""
        session_record = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': 'practice_session',
            'practice_type': practice_data.get('type', 'unknown'),
            'focus_dimensions': practice_data.get('focus_dimensions', []),
            'exercises_completed': len(practice_data.get('exercises', [])),
            'total_duration': practice_data.get('total_duration', 0),
            'self_evaluation': self_evaluation or {},
            'notes': practice_data.get('notes', ''),
            'mood': practice_data.get('mood', 'neutral'),
            'energy_level': practice_data.get('energy_level', 'medium')
        }
        
        # 加载现有进度数据
        progress_data = self._load_progress_data()
        
        # 添加新记录
        progress_data['sessions'].append(session_record)
        
        # 保存更新
        self._save_progress_data(progress_data)
        
        return f"练习记录已保存 (ID: {len(progress_data['sessions'])}"
    
    def log_dimension_improvement(self, dimension: str, improvement: float, context: str = "") -> str:
        """记录特定维度的改进"""
        improvement_record = {
            'timestamp': datetime.datetime.now().isoformat(),
            'type': 'dimension_improvement',
            'dimension': dimension,
            'improvement': improvement,  # +0.1, +0.3 等
            'context': context,
            'new_score': None  # 将在完整评估时更新
        }
        
        progress_data = self._load_progress_data()
        progress_data['improvements'].append(improvement_record)
        self._save_progress_data(progress_data)
        
        return f"维度改进记录: {self.dimensions.get(dimension, dimension)} +{improvement}"
    
    def log_assessment_result(self, assessment_results: Dict) -> str:
        """记录评估结果"""
        # 保存完整的评估结果
        timestamp = datetime.datetime.now()
        filename = f"assessment_{timestamp.strftime('%Y%m%d_%H%M%S')}.json"
        filepath = self.assessments_dir / filename
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(assessment_results, f, ensure_ascii=False, indent=2)
        
        # 记录评估摘要到进度数据
        assessment_summary = {
            'timestamp': timestamp.isoformat(),
            'type': 'assessment',
            'filename': filename,
            'overall_score': assessment_results.get('overall_score', 0),
            'dimension_scores': {
                dim: data.get('score', 0) 
                for dim, data in assessment_results.get('dimensions', {}).items()
            }
        }
        
        progress_data = self._load_progress_data()
        progress_data['assessments'].append(assessment_summary)
        self._save_progress_data(progress_data)
        
        return f"评估结果已保存: {filename}"
    
    def generate_weekly_report(self, week_ending: datetime.date = None) -> Dict:
        """生成周报"""
        if week_ending is None:
            week_ending = datetime.date.today()
        
        week_start = week_ending - datetime.timedelta(days=6)
        
        progress_data = self._load_progress_data()
        
        # 筛选本周数据
        week_sessions = [
            s for s in progress_data['sessions']
            if week_start <= datetime.datetime.fromisoformat(s['timestamp']).date() <= week_ending
        ]
        
        week_improvements = [
            i for i in progress_data['improvements']
            if week_start <= datetime.datetime.fromisoformat(i['timestamp']).date() <= week_ending
        ]
        
        # 生成报告
        report = {
            'week_start': week_start.isoformat(),
            'week_ending': week_ending.isoformat(),
            'practice_summary': self._analyze_practice_sessions(week_sessions),
            'improvement_summary': self._analyze_improvements(week_improvements),
            'recommendations': [],
            'next_week_focus': []
        }
        
        # 基于本周表现生成下周建议
        report['recommendations'] = self._generate_weekly_recommendations(report)
        report['next_week_focus'] = self._suggest_next_week_focus(report)
        
        return report
    
    def create_text_visualization(self, dimension: str = None, days: int = 30) -> str:
        """创建文本可视化图表"""
        progress_data = self._load_progress_data()
        
        # 筛选指定时间段的数据
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=days)
        
        relevant_assessments = [
            a for a in progress_data['assessments']
            if start_date <= datetime.datetime.fromisoformat(a['timestamp']).date() <= end_date
        ]
        
        if not relevant_assessments:
            return "没有足够的数据生成可视化图表"
        
        # 创建文本图表
        output = []
        output.append("🦞 六维度交流能力提升可视化")
        output.append("=" * 50)
        
        if dimension and dimension in self.dimensions:
            # 特定维度的趋势文本图
            output.extend(self._create_dimension_text_chart(relevant_assessments, dimension))
        else:
            # 所有维度的综合视图
            output.extend(self._create_overall_text_chart(relevant_assessments[-1]))
        
        return "\n".join(output)
    
    def _create_dimension_text_chart(self, assessments: List[Dict], dimension: str) -> List[str]:
        """创建特定维度的文本趋势图"""
        output = []
        output.append(f"📊 {self.dimensions.get(dimension, dimension)} 能力趋势")
        output.append("-" * 40)
        
        if not assessments:
            output.append("暂无评估数据")
            return output
        
        # 提取分数和时间
        scores = [a['dimension_scores'].get(dimension, 0) for a in assessments]
        dates = [datetime.datetime.fromisoformat(a['timestamp']).strftime('%m%d') for a in assessments]
        
        output.append("分数变化:")
        for i, (date, score) in enumerate(zip(dates, scores)):
            bar_length = int(score * 10)  # 将5分制转换为50字符长度
            bar = "█" * bar_length + "░" * (50 - bar_length)
            output.append(f"{date}: {score:.1f}/5.0 │{bar}│")
        
        # 计算趋势
        if len(scores) >= 2:
            trend = scores[-1] - scores[0]
            trend_text = "↗️ 上升" if trend > 0.2 else "↘️ 下降" if trend < -0.2 else "→ 稳定"
            output.append(f"\n整体趋势: {trend_text} ({trend:+.2f}分)")
        
        return output
    
    def _create_overall_text_chart(self, latest_assessment: Dict) -> List[str]:
        """创建综合能力文本雷达图"""
        output = []
        output.append("📈 六维度能力雷达图（文本版）")
        output.append("-" * 40)
        
        scores = latest_assessment['dimension_scores']
        overall = latest_assessment.get('overall_score', sum(scores.values()) / len(scores))
        
        output.append(f"总体评分: {overall:.2f}/5.0")
        output.append("")
        
        # 创建雷达图的文本表示
        output.append("维度能力分布:")
        for dim_key, dim_name in self.dimensions.items():
            score = scores.get(dim_key, 0)
            bar_length = int(score * 10)
            bar = "█" * bar_length + "░" * (50 - bar_length)
            
            # 添加能力等级描述
            if score >= 4.5:
                level = "🌟 专家级"
            elif score >= 4.0:
                level = "💪 高级"
            elif score >= 3.0:
                level = "📈 中级"
            elif score >= 2.0:
                level = "📚 初级"
            else:
                level = "🎯 入门级"
            
            output.append(f"{dim_name:8s}: {score:.1f}/5.0 │{bar}│ {level}")
        
        # 添加改进建议的图形表示
        output.append("")
        output.append("改进优先级:")
        sorted_dims = sorted(scores.items(), key=lambda x: x[1])
        
        for i, (dim_key, score) in enumerate(sorted_dims[:3]):  # 显示最需要改进的3个
            priority = "🔥 高" if i == 0 else "⚡ 中" if i == 1 else "📋 低"
            output.append(f"  {priority} {self.dimensions[dim_key]}")
        
        return output
    
    def _load_progress_data(self) -> Dict:
        """加载进度数据"""
        if self.progress_file.exists():
            with open(self.progress_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        else:
            # 初始化数据结构
            return {
                'sessions': [],
                'improvements': [],
                'assessments': [],
                'metadata': {
                    'created_at': datetime.datetime.now().isoformat(),
                    'version': '1.0'
                }
            }
    
    def _save_progress_data(self, data: Dict):
        """保存进度数据"""
        with open(self.progress_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def _analyze_practice_sessions(self, sessions: List[Dict]) -> Dict:
        """分析练习会话数据"""
        if not sessions:
            return {
                'total_sessions': 0,
                'total_duration': 0,
                'average_duration': 0,
                'dimension_frequency': {},
                'practice_consistency': 0
            }
        
        total_duration = sum(s.get('total_duration', 0) for s in sessions)
        
        # 统计各维度练习频率
        dimension_freq = {}
        for session in sessions:
            for dim in session.get('focus_dimensions', []):
                dimension_freq[dim] = dimension_freq.get(dim, 0) + 1
        
        # 计算练习一致性（基于时间间隔）
        consistency = self._calculate_consistency(sessions)
        
        return {
            'total_sessions': len(sessions),
            'total_duration': total_duration,
            'average_duration': total_duration / len(sessions) if sessions else 0,
            'dimension_frequency': dimension_freq,
            'practice_consistency': consistency
        }
    
    def _analyze_improvements(self, improvements: List[Dict]) -> Dict:
        """分析改进记录"""
        if not improvements:
            return {
                'total_improvements': 0,
                'dimension_breakdown': {},
                'average_improvement': 0,
                'biggest_improvement': 0
            }
        
        # 按维度统计
        dimension_breakdown = {}
        total_improvement = 0
        biggest_improvement = 0
        
        for improvement in improvements:
            dim = improvement['dimension']
            value = improvement['improvement']
            
            if dim not in dimension_breakdown:
                dimension_breakdown[dim] = {'count': 0, 'total': 0, 'average': 0}
            
            dimension_breakdown[dim]['count'] += 1
            dimension_breakdown[dim]['total'] += value
            dimension_breakdown[dim]['average'] = dimension_breakdown[dim]['total'] / dimension_breakdown[dim]['count']
            
            total_improvement += value
            biggest_improvement = max(biggest_improvement, value)
        
        return {
            'total_improvements': len(improvements),
            'dimension_breakdown': dimension_breakdown,
            'average_improvement': total_improvement / len(improvements),
            'biggest_improvement': biggest_improvement
        }
    
    def _generate_weekly_recommendations(self, weekly_report: Dict) -> List[str]:
        """生成周度建议"""
        recommendations = []
        
        practice_summary = weekly_report['practice_summary']
        
        # 基于练习频率的建议
        if practice_summary['total_sessions'] < 3:
            recommendations.append("建议增加练习频率，每周至少3次练习")
        elif practice_summary['total_sessions'] > 7:
            recommendations.append("练习频率很高，注意保持质量而非数量")
        
        # 基于改进记录的建议
        improvement_summary = weekly_report['improvement_summary']
        if improvement_summary['total_improvements'] == 0:
            recommendations.append("本周没有记录改进，建议更详细地记录练习感受")
        
        # 通用建议
        recommendations.extend([
            "保持每日5分钟快速练习",
            "记录每次练习的具体感受",
            "关注实际交流中的改进效果"
        ])
        
        return recommendations
    
    def _suggest_next_week_focus(self, weekly_report: Dict) -> List[str]:
        """建议下周重点"""
        focus_areas = []
        
        # 基于本周表现的智能建议
        practice_summary = weekly_report['practice_summary']
        dim_freq = practice_summary.get('dimension_frequency', {})
        
        # 选择练习最少的维度作为下周重点
        if dim_freq:
            least_practiced = min(dim_freq.items(), key=lambda x: x[1])
            focus_areas.append(f"重点练习{least_practiced[0]}维度")
        
        # 添加通用建议
        focus_areas.extend([
            "保持每日5分钟快速练习",
            "记录每次练习的具体感受",
            "关注实际交流中的改进效果"
        ])
        
        return focus_areas
    
    def _calculate_consistency(self, sessions: List[Dict]) -> float:
        """计算练习一致性（0-1）"""
        if len(sessions) < 2:
            return 0.0
        
        # 基于时间间隔的一致性计算
        timestamps = [datetime.datetime.fromisoformat(s['timestamp']) for s in sessions]
        timestamps.sort()
        
        intervals = []
        for i in range(1, len(timestamps)):
            interval = (timestamps[i] - timestamps[i-1]).total_seconds() / 3600  # 小时
            intervals.append(interval)
        
        # 理想间隔是24小时，计算与理想间隔的偏离程度
        ideal_interval = 24
        deviations = [abs(interval - ideal_interval) / ideal_interval for interval in intervals]
        avg_deviation = sum(deviations) / len(deviations)
        
        # 一致性分数（偏离越小，一致性越高）
        consistency = max(0, 1 - avg_deviation)
        return round(consistency, 2)

def main():
    """命令行接口"""
    import argparse
    
    tracker = ProgressTracker()
    
    parser = argparse.ArgumentParser(description='六维度交流能力进度追踪工具')
    subparsers = parser.add_subparsers(dest='command', help='可用命令')
    
    # 记录练习
    log_parser = subparsers.add_parser('log', help='记录练习会话')
    log_parser.add_argument('--type', required=True, help='练习类型')
    log_parser.add_argument('--focus', nargs='+', help='重点维度')
    log_parser.add_argument('--duration', type=int, help='练习时长')
    log_parser.add_argument('--notes', help='练习笔记')
    log_parser.add_argument('--mood', default='neutral', help='心情')
    log_parser.add_argument('--energy', default='medium', help='精力水平')
    
    # 记录改进
    improve_parser = subparsers.add_parser('improve', help='记录维度改进')
    improve_parser.add_argument('--dimension', required=True, help='维度')
    improve_parser.add_argument('--value', type=float, required=True, help='改进值')
    improve_parser.add_argument('--context', help='改进背景')
    
    # 生成报告
    report_parser = subparsers.add_parser('report', help='生成报告')
    report_parser.add_argument('--type', choices=['weekly', 'monthly'], default='weekly', help='报告类型')
    report_parser.add_argument('--date', help='报告日期 (YYYY-MM-DD)')
    
    # 可视化
    viz_parser = subparsers.add_parser('visualize', help='生成可视化')
    viz_parser.add_argument('--dimension', help='特定维度')
    viz_parser.add_argument('--days', type=int, default=30, help='天数范围')
    
    args = parser.parse_args()
    
    if args.command == 'log':
        practice_data = {
            'type': args.type,
            'focus_dimensions': args.focus or [],
            'total_duration': args.duration or 0,
            'notes': args.notes or '',
            'mood': args.mood,
            'energy_level': args.energy
        }
        result = tracker.log_practice_session(practice_data)
        print(f"✅ {result}")
    
    elif args.command == 'improve':
        result = tracker.log_dimension_improvement(args.dimension, args.value, args.context)
        print(f"✅ {result}")
    
    elif args.command == 'report':
        if args.type == 'weekly':
            date = datetime.date.fromisoformat(args.date) if args.date else datetime.date.today()
            report = tracker.generate_weekly_report(date)
            print(f"📊 周报 ({report['week_start']} to {report['week_ending']})")
            print(f"练习会话: {report['practice_summary']['total_sessions']}")
            print(f"总时长: {report['practice_summary']['total_duration']}分钟")
            print(f"建议: {', '.join(report['recommendations'])}")
            print(f"下周重点: {', '.join(report['next_week_focus'])}")
        
        else:  # monthly
            today = datetime.date.today()
            report = tracker.generate_monthly_report(today.month, today.year)
            print(f"📈 月报 ({today.year}-{today.month:02d})")
            print(f"成就: {', '.join(report['achievements'])}")
            print(f"改进领域: {', '.join(report['areas_for_improvement'])}")
            print(f"长期建议: {', '.join(report['long_term_recommendations'])}")
    
    elif args.command == 'visualize':
        chart_text = tracker.create_text_visualization(args.dimension, args.days)
        print(chart_text)
    
    else:
        # 显示帮助
        parser.print_help()

if __name__ == "__main__":
    main()