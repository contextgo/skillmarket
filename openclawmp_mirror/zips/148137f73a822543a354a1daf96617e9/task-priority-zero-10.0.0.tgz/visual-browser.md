---
name: visual-browser
description: 视觉驱动的浏览器操控模块。通过截图感知页面→AI分析布局→执行点击/输入操作。连接已有的Edge/Chrome浏览器，保留登录状态。用于需要实时操控浏览器的场景：浏览网页、填写表单、点击按钮、提取数据、多步骤Web操作。
---

# 视觉浏览器模块（Visual Browser）

## 核心能力

通过"截图→分析→操作"循环，像人一样操控浏览器。不依赖DOM结构，只看页面截图就能识别按钮、输入框、链接等元素并操作。

## 环境要求

- Node.js >= 18
- @anthropic-ai/sdk 或兼容的视觉模型API
- Chrome/Edge 浏览器（开启远程调试端口）

## 安装

```bash
npm install @anthropic-ai/sdk puppeteer-core
```

## 连接浏览器

### 方式1：连接已有的Edge浏览器（推荐）
```bash
# 先启动Edge，开启调试端口
start msedge --remote-debugging-port=9222
```

### 方式2：连接已有的Chrome浏览器
```bash
start chrome --remote-debugging-port=9222
```

## 核心操作流程

### 截图→分析→操作 循环

每次操作都遵循这个循环：

1. **截图**：通过CDP获取当前页面截图
2. **分析**：用视觉模型分析截图，识别页面元素
3. **操作**：根据分析结果执行点击/输入/滚动
4. **验证**：再次截图，确认操作结果

### 关键规则

1. **每次只执行一个操作** — 操作后必须截图验证再决定下一步
2. **同步执行** — 不能后台运行，必须等待结果
3. **等待加载** — 操作后等待页面加载完成再截图
4. **报告结果** — 完成后向用户汇报

## 使用方式

### 通过Python脚本操控（适配当前环境）

```python
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
visual-browser: 视觉驱动的浏览器操控
通过CDP连接浏览器 → 截图 → 图像分析 → 执行操作
"""
import json
import base64
import urllib.request
import ssl
import subprocess
import time
import os

class VisualBrowser:
    def __init__(self, debug_port=9222):
        self.debug_port = debug_port
        self.ctx = ssl.create_default_context()
        self.ctx.check_hostname = False
        self.ctx.verify_mode = ssl.CERT_NONE
        self.ws_url = None
        self.page_id = None
    
    def connect(self):
        """连接到已打开的浏览器"""
        req = urllib.request.Request(f'http://localhost:{self.debug_port}/json')
        with urllib.request.urlopen(req, timeout=5) as resp:
            pages = json.loads(resp.read().decode('utf-8'))
            for page in pages:
                if page.get('type') == 'page':
                    self.ws_url = page['webSocketDebuggerUrl']
                    self.page_id = page['id']
                    return True
        return False
    
    def screenshot(self, save_path):
        """通过CDP截取当前页面截图"""
        # 使用CDP HTTP API截图
        req = urllib.request.Request(
            f'http://localhost:{self.debug_port}/json',
        )
        # 通过subprocess调用CDP命令截图
        script = f'''
const CDP = require('chrome-remote-interface');
(async () => {{
    const client = await CDP({{port: {self.debug_port}}});
    const {{Page}} = client;
    await Page.enable();
    const {{data}} = await Page.captureScreenshot({{format: 'png'}});
    require('fs').writeFileSync('{save_path}', Buffer.from(data, 'base64'));
    await client.close();
}})();
'''
        # 简化版：直接用Python的websocket
        pass
    
    def navigate(self, url):
        """导航到指定URL"""
        pass
    
    def click(self, x, y):
        """点击指定坐标"""
        pass
    
    def type_text(self, text):
        """输入文本"""
        pass
    
    def scroll(self, direction='down', amount=300):
        """滚动页面"""
        pass
```

### 实际使用流程

由于我的环境限制，实际操作流程为：

#### 步骤1：启动浏览器
```bash
start msedge --remote-debugging-port=9222 "https://target-url.com"
```

#### 步骤2：截图
使用 `desktop_analyze_image` 工具分析页面截图，识别：
- 按钮位置和文字
- 输入框位置
- 链接和可点击元素
- 页面整体布局

#### 步骤3：执行操作
通过CDP协议发送命令：
- `Input.dispatchMouseEvent` — 点击
- `Input.dispatchKeyEvent` — 键盘输入
- `Page.navigate` — 导航
- `Runtime.evaluate` — 执行JavaScript

#### 步骤4：验证结果
再次截图，确认操作是否成功

## 与现有工具的配合

| 场景 | 使用工具 |
|------|---------|
| 简单API调用 | Python urllib（不需要视觉） |
| 需要登录的网站操作 | visual-browser（保留登录状态） |
| 复杂表单填写 | visual-browser（看到表单再填） |
| 数据提取 | visual-browser截图 + 图像分析 |
| 批量操作 | Python脚本（效率更高） |

## 当前限制

1. **截图分析有延迟** — 每次截图+分析需要几秒
2. **坐标精度** — 依赖图像分析的坐标识别精度
3. **动态内容** — 页面动画/加载中截图可能不准
4. **无法实时感知** — 不是真正的"实时视觉"，而是"截图循环"

## 未来优化方向

1. **DOM辅助** — 截图+DOM结构双重验证，提高准确率
2. **元素高亮** — 注入JS高亮可交互元素，辅助视觉识别
3. **操作录制** — 记录操作序列，支持回放
4. **错误恢复** — 操作失败时自动回退并重试
