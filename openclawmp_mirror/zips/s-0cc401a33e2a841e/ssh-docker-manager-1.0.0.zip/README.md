# 🐳 SSH Docker 管理器

> 通过 SSH 远程管理 Linux 设备的 Docker 容器

## 功能

- 🔌 SSH 远程连接设备
- 📊 查看容器状态
- ▶️/⏹️/🔄 启动/停止/重启容器
- 📜 查看容器日志
- 🗑️ 删除容器/镜像
- 💾 容器资源监控

## 配置

首次使用前，先配置设备信息：

```bash
# 编辑设备配置
vi ~/.openclaw/skills/ssh-docker-manager/devices.json
```

配置格式：

```json
{
  "defaultDevice": "your-device-name",
  "devices": {
    "your-device-name": {
      "host": "192.168.x.x",
      "port": 22,
      "user": "your-username",
      "password": "your-password",
      "dockerPath": "/path/to/docker"
    }
  }
}
```

## 命令

### 查看所有容器

```bash
node scripts/docker.js --list
# 或
node scripts/docker.js --list --device tnas
```

### 查看容器状态

```bash
node scripts/docker.js --status <容器名>
# 例: node scripts/docker.js --status mumuainovel
```

### 启动容器

```bash
node scripts/docker.js --start <容器名>
```

### 停止容器

```bash
node scripts/docker.js --stop <容器名>
```

### 重启容器

```bash
node scripts/docker.js --restart <容器名>
```

### 查看日志

```bash
node scripts/docker.js --logs <容器名> --lines 50
```

### 进入容器

```bash
node scripts/docker.js --exec <容器名> --command "ls -la"
```

### 查看资源使用

```bash
node scripts/docker.js --stats
```

### 清理停止的容器

```bash
node scripts/docker.js --prune
```

## 示例

```
# 查看所有容器
> node scripts/docker.js --list

# 重启 moviepilot
> node scripts/docker.js --restart jxxghp-moviepilot-v2

# 查看 cloudsaver 日志
> node scripts/docker.js --logs jiangrui1994-cloudsaver --lines 100
```

## 设备管理

添加新设备：

```bash
# 编辑 devices.json 添加新设备
vi ~/.openclaw/skills/ssh-docker-manager/devices.json
```

## 注意

- 所有命令需要 SSH 访问权限
- 确保目标设备 Docker 已运行
- 部分设备 docker 命令路径特殊，需配置 dockerPath