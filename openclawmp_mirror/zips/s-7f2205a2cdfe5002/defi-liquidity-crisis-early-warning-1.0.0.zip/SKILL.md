---
name: defi-liquidity-crisis-early-warning
description: "Early warning system for detecting DeFi liquidity crises before they cascade, using on-chain metrics and protocol health indicators"
version: 1.0.0
---

# DeFi Liquidity Crisis Early Warning System

A multi-layer detection framework for identifying DeFi liquidity stress before it cascades into protocol failures, bank runs, or cross-protocol contagion.

## Why Early Detection Matters

DeFi liquidity crises escalate fast:
- Curve Finance depeg (2022): $1B+ lost in 48 hours
- LUNA/UST collapse (2022): $60B wiped in days
- Silicon Valley Bank (2023): USDC depegged 10% in hours

Early warning = minutes to hours of reaction time for agents.

## Detection Layers

### Layer 1: Stablecoin Health (Check every 5 min)

```
Depeg Score = |Market_Price - Peg_Value| / Peg_Value × 100%

Alert thresholds:
  Score > 0.3%: ⚠️ Monitor (natural volatility)
  Score > 1.0%: 🔴 Warning (possible stress)
  Score > 3.0%: 🚨 Critical (active crisis)
  Score > 5.0%: 💀 Catastrophic (cascade likely)
```

Key metrics to track:
- USDC: DEX vs CEX price spread
- DAI: Redemption rate on MakerDAO
- USDT: Premium/discount on Binance/P2P
- Frax: CR ratio (collateralization rate)

### Layer 2: DEX Liquidity Depth (Check every 15 min)

```
Liquidity Stress = 1 - (Current_TV_L / 7D_Avg_TV_L)

Alert thresholds:
  Stress > 20%: Liquidity withdrawing
  Stress > 40%: Rapid withdrawal (bank run signal)
  Stress > 60%: Critical — protocol may fail
```

Monitor pools:
- Top 10 Uniswap V3 pools by volume
- Curve 3pool and stETH pools
- Top Aave/Compound markets by TVL

### Layer 3: Whale Movement Detection (Check every 30 min)

```
Whale Alert Score = Sum(tx_value > $1M in last 1h) / Protocol_TV_L

Alert thresholds:
  Score > 0.5%: Significant whale activity
  Score > 2.0%: Coordinated withdrawal likely
  Score > 5.0%: Whale bank run in progress
```

Data sources:
- Whale Alert API
- Etherscan large transfer monitoring
- Nansen smart money tracking

### Layer 4: Protocol Governance Signals (Check every hour)

```
Governance Risk = (Emergency_proposals + Parameter_changes) / Normal_rate

High-risk signals:
- Emergency timelock bypass proposals
- Sudden collateral ratio changes
- Fee increases (protocol trying to retain liquidity)
- Pause/unpause toggles activated
```

### Layer 5: Cross-Protocol Contagion Risk (Check every hour)

```
Contagion Score = Σ(Protocol_i_Stress × Exposure_to_affected_protocol)

Common contagion vectors:
  Shared collateral (ETH used in multiple protocols)
  Shared liquidators (one protocol's liquidation cascades)
  Token dependencies (lpToken of Protocol A used in Protocol B)
  Bridge risk (wrapped tokens depend on bridge solvency)
```

## Crisis Response Protocol

```
[Depeg Detected > 1%]
  → Pause all DeFi-related trades
  → Check if isolated to one stablecoin or systemic
  → Monitor Layer 2-5 for escalation

[Layer 2+ confirms stress]
  → Reduce DeFi exposure to zero
  → Move to safe assets (CEX, hardware wallet)
  → Alert user with confidence score

[Contagion detected]
  → Exit all correlated positions
  → Short affected tokens if possible
  → Track recovery timeline
```

## Agent Integration Pattern

```python
class DeFiWatchdog:
    def __init__(self):
        self.alerts = []
        self.crisis_mode = False
    
    def check_stablecoins(self):
        for coin in ["USDC", "DAI", "USDT", "FRAX"]:
            depeg = get_depeg_score(coin)
            if depeg > 1.0:
                self.alerts.append({
                    "level": "CRITICAL" if depeg > 3 else "WARNING",
                    "coin": coin,
                    "depeg": depeg,
                    "timestamp": now()
                })
        self._assess_crisis_level()
    
    def _assess_crisis_level(self):
        critical_count = sum(1 for a in self.alerts if a["level"] == "CRITICAL")
        if critical_count >= 2:
            self.crisis_mode = True
            return "DEFI_CRISIS_DETECTED"
        elif critical_count >= 1:
            return "ELEVATED_RISK"
        return "NORMAL"
```

## Prediction Market Application

This system informs Polymarket positions on:
- "Will USDC depeg > 5% by [date]?"
- "Will a major DeFi protocol fail in 2026?"
- "Will there be a crypto bank run in Q2 2026?"

## Data Sources

| Data | Source | Update Frequency |
|------|--------|-----------------|
| Stablecoin prices | CoinGecko, DEX on-chain | Real-time |
| DEX TVL | DeFi Llama, on-chain | 5-15 min |
| Whale transactions | Whale Alert, Etherscan | Real-time |
| Governance proposals | Tally, Snapshot | Hourly |
| Bridge TVL | L2Beat, DeFi Llama | 15 min |

## Version

1.0.0 - Multi-layer DeFi liquidity monitoring framework
