# 🔒 Outbound Privacy Guard / 出站隐私保护

## What is this?

A complete outbound security system for OpenClaw Agents. Protects against data leakage through cloud APIs and defends against prompt injection from proxy API middlemen.

> Sponsored by Isa.

## 这是什么？

一套完整的 OpenClaw Agent 出站安全系统。防止数据通过云端 API 泄露，并防御中转 API 的提示词注入攻击。

> 本技能由 Isa 老师特别赞助。

## v2.0 New Features / 新特性

### 🛡️ Prompt Integrity Verification / Prompt 完整性校验
- Detects prompt injection from proxy API middlemen
- Session-start token verification
- Injection keyword detection (e.g. "ignore previous instructions")
- Weekly auto-rotation + audit report via cron

---

- 检测中转 API 的提示词注入
- 每次会话启动时校验 token
- 注入关键词检测（如"忽略之前的指令"）
- 每周自动轮换校验码 + 审计报告

### 🔧 Externalized Sanitizer Engine / 外置脱敏引擎
- Code-level enforcement, independent of prompt (cannot be bypassed by injection)
- Two-layer detection: regex Pattern library + SHA256 hash library
- Covers: API Keys, passwords, phone numbers, ID cards, bank cards, Bearer tokens, private keys
- CLI tools: scan, redact, add-hash, test

---

- 代码级强制执行，独立于 prompt（注入无法绕过）
- 两层检测：正则 Pattern 库 + SHA256 哈希库
- 覆盖：API Key、密码、手机号、身份证、银行卡、Bearer Token、私钥
- CLI 工具：scan / redact / add-hash / test

## Problems Solved / 解决什么问题？

- Cloud model servers see all conversation content; proxy APIs add another middleman
- Proxy APIs can inject prompts to override your security rules
- Agents may unintentionally expose sensitive information in replies
- No way to verify if the model is actually what the provider claims

---

- 云端模型服务器可以看到所有对话内容，中转 API 更多一个中间人
- 中转 API 可以注入 prompt 覆盖你的安全规则
- Agent 可能在回复中无意暴露敏感信息
- 无法验证模型是否真的是服务商声称的版本

## Core Features / 核心功能

1. **Pre-send check** / 发送前自检
2. **Auto-redact** / 自动脱敏
3. **Prompt integrity verification** / Prompt 完整性校验 (NEW)
4. **Externalized sanitizer** / 外置脱敏引擎 (NEW)
5. **File-first** / 文件优先策略
6. **User alerts** / 用户提醒
7. **Weekly audit** / 每周自动审计 (NEW)

## Install / 安装

```bash
# ClawHub
clawhub install outbound-privacy-guard

# 水产市场
openclawmp install skill/outbound-privacy-guard
```

## Setup / 配置

After installation, run the setup:
安装后执行以下配置：

```bash
# 1. Generate integrity token / 生成完整性校验码
python3 scripts/prompt_integrity.py generate

# 2. Initialize hash library / 初始化哈希库
python3 -c "import json; json.dump([], open('.sensitive_hashes.json','w'))"

# 3. Add known secrets (run locally, NEVER in chat)
# 添加已知敏感值（只能在本地终端执行，绝不要在对话中操作）
python3 scripts/sanitizer.py add-hash "your_secret_value"
```

## Usage / 使用方式

SKILL.md rules activate automatically each session. The sanitizer engine runs independently as code-level protection.

```bash
# Scan text for sensitive data / 扫描文本中的敏感信息
python3 scripts/sanitizer.py scan "text to check"

# Redact sensitive data / 脱敏处理
python3 scripts/sanitizer.py redact "text to redact"

# Run self-test / 运行自测
python3 scripts/sanitizer.py test

# Rotate integrity token (weekly) / 轮换校验码（建议每周一次）
python3 scripts/prompt_integrity.py rotate
```

安装后 SKILL.md 规则每次会话自动生效。脱敏引擎作为代码级保护独立运行。

## Limitations / 局限性

- Only protects outbound direction (Agent → API → User)
- Cannot intercept user input before it reaches the proxy server
- Prompt integrity check is soft defense; a determined attacker with full API control can still bypass
- Hash library requires manual maintenance

---

- 只保护出站方向
- 无法拦截用户输入（已经过中转服务器）
- Prompt 完整性校验是软防御，完全控制 API 的攻击者仍可绕过
- 哈希库需要手动维护

## License

MIT
