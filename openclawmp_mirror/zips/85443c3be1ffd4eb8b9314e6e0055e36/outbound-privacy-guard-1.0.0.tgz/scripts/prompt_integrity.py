#!/usr/bin/env python3
"""Prompt 完整性校验工具
生成、轮换、验证校验码，防止中转 API 注入 prompt"""
import json, os, secrets, hashlib, time

INTEGRITY_FILE = os.path.expanduser('~/.openclaw/workspace/.prompt_integrity.json')

def generate():
    """生成新的校验码"""
    token = secrets.token_hex(8)
    data = {
        'token': token,
        'hash': hashlib.sha256(token.encode()).hexdigest(),
        'created': int(time.time()),
        'version': 1
    }
    with open(INTEGRITY_FILE, 'w') as f:
        json.dump(data, f, indent=2)
    os.chmod(INTEGRITY_FILE, 0o600)
    return token

def verify(token_input):
    """验证校验码是否匹配"""
    if not os.path.exists(INTEGRITY_FILE):
        return False, "校验文件不存在"
    data = json.load(open(INTEGRITY_FILE))
    expected_hash = data.get('hash', '')
    input_hash = hashlib.sha256(token_input.encode()).hexdigest()
    if input_hash == expected_hash:
        return True, "校验通过"
    return False, "校验失败：token 不匹配"

def get_current():
    """获取当前校验码"""
    if not os.path.exists(INTEGRITY_FILE):
        return None
    data = json.load(open(INTEGRITY_FILE))
    return data.get('token')

def rotate():
    """轮换校验码"""
    old = get_current()
    new = generate()
    return old, new

if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("用法: prompt_integrity.py [generate|verify|rotate|current]")
        sys.exit(1)
    cmd = sys.argv[1]
    if cmd == 'generate':
        token = generate()
        print(f"新校验码: {token}")
    elif cmd == 'verify':
        token = sys.argv[2] if len(sys.argv) > 2 else input("输入校验码: ")
        ok, msg = verify(token)
        print(msg)
        sys.exit(0 if ok else 1)
    elif cmd == 'rotate':
        old, new = rotate()
        print(f"旧: {old} → 新: {new}")
    elif cmd == 'current':
        t = get_current()
        print(t if t else "未生成")
