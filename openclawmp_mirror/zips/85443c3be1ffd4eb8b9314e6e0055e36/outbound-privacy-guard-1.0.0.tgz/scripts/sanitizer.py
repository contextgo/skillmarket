#!/usr/bin/env python3
"""外置脱敏引擎 — 输入输出敏感信息检测与脱敏
独立于 prompt 运行，代码级强制执行"""
import re, json, os, hashlib

# ============================================================
# 第一层：Pattern 库（通用格式匹配）
# ============================================================
PATTERNS = {
    # API Keys
    'openai_key': r'sk-[a-zA-Z0-9]{32,}',
    'anthropic_key': r'sk-ant-[a-zA-Z0-9\-]{32,}',
    'aws_key': r'AKIA[0-9A-Z]{16}',
    'generic_key': r'(?i)(api[_-]?key|secret[_-]?key|access[_-]?token)\s*[:=]\s*["\']?([a-zA-Z0-9\-_]{20,})["\']?',
    'bearer_token': r'Bearer\s+[a-zA-Z0-9\-_.]{20,}',

    # 密码
    'password': r'(?i)(password|passwd|pwd|密码)\s*[:=：]\s*[^\s,，;；]{6,32}',

    # 个人信息（中国）
    'phone_cn': r'(?<!\d)1[3-9]\d{9}(?!\d)',
    'id_card': r'(?<!\d)\d{17}[\dXx](?!\d)',
    'bank_card': r'(?<!\d)\d{16,19}(?!\d)',
    'email': r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}',

    # 私钥/证书
    'private_key': r'-----BEGIN\s+(RSA\s+)?PRIVATE\s+KEY-----',
    'wallet_key': r'(?i)(private[_-]?key|mnemonic|seed[_-]?phrase)\s*[:=]\s*\S+',
}

# ============================================================
# 第二层：哈希库（已知敏感值精准匹配）
# ============================================================
HASH_FILE = os.path.expanduser('~/.openclaw/workspace/.sensitive_hashes.json')

def load_hashes():
    if os.path.exists(HASH_FILE):
        return set(json.load(open(HASH_FILE)))
    return set()

def add_hash(value):
    hashes = load_hashes()
    hashes.add(hashlib.sha256(value.encode()).hexdigest())
    with open(HASH_FILE, 'w') as f:
        json.dump(list(hashes), f)
    os.chmod(HASH_FILE, 0o600)

def check_hash(value):
    hashes = load_hashes()
    return hashlib.sha256(value.encode()).hexdigest() in hashes

# ============================================================
# 扫描引擎
# ============================================================
def scan(text):
    """扫描文本中的敏感信息，返回匹配列表（高优先级 pattern 优先）"""
    # 优先级顺序：精确匹配 > 通用匹配
    priority_order = [
        'private_key', 'wallet_key',
        'openai_key', 'anthropic_key', 'aws_key', 'bearer_token',
        'generic_key', 'password',
        'id_card', 'phone_cn', 'bank_card', 'email',
    ]
    findings = []
    matched_ranges = set()

    for name in priority_order:
        pattern = PATTERNS.get(name)
        if not pattern:
            continue
        for match in re.finditer(pattern, text):
            # 检查是否与已匹配区间重叠
            overlap = False
            for s, e in matched_ranges:
                if match.start() < e and match.end() > s:
                    overlap = True
                    break
            if overlap:
                continue
            matched_ranges.add((match.start(), match.end()))
            findings.append({
                'type': name,
                'match': match.group()[:20] + '***',
                'start': match.start(),
                'end': match.end(),
                'full_match': match.group()
            })
    # 哈希库检查
    for word in re.split(r'[\s,;:=\'"]+', text):
        if len(word) >= 16 and check_hash(word):
            findings.append({
                'type': 'known_secret',
                'match': word[:8] + '***',
                'start': text.index(word),
                'end': text.index(word) + len(word),
                'full_match': word
            })
    return findings

# ============================================================
# 脱敏引擎
# ============================================================
REDACT_MAP = {
    'openai_key': '[OPENAI_KEY]',
    'anthropic_key': '[ANTHROPIC_KEY]',
    'aws_key': '[AWS_KEY]',
    'generic_key': '[API_KEY]',
    'bearer_token': '[BEARER_TOKEN]',
    'password': '[PASSWORD]',
    'phone_cn': '[PHONE]',
    'id_card': '[ID_CARD]',
    'bank_card': '[BANK_CARD]',
    'email': '[EMAIL]',
    'private_key': '[PRIVATE_KEY]',
    'wallet_key': '[WALLET_KEY]',
    'known_secret': '[KNOWN_SECRET]',
}

def redact(text):
    """脱敏文本，返回 (脱敏后文本, 发现数量)"""
    findings = scan(text)
    if not findings:
        return text, 0
    # 按位置倒序替换，避免偏移
    findings.sort(key=lambda x: x['start'], reverse=True)
    result = text
    for f in findings:
        placeholder = REDACT_MAP.get(f['type'], '[REDACTED]')
        result = result[:f['start']] + placeholder + result[f['end']:]
    return result, len(findings)

# ============================================================
# CLI 接口
# ============================================================
if __name__ == '__main__':
    import sys
    if len(sys.argv) < 2:
        print("用法:")
        print("  sanitizer.py scan <text>     扫描敏感信息")
        print("  sanitizer.py redact <text>   脱敏处理")
        print("  sanitizer.py add-hash <val>  添加已知敏感值哈希")
        print("  sanitizer.py test            运行自测")
        sys.exit(1)

    cmd = sys.argv[1]
    if cmd == 'scan':
        text = ' '.join(sys.argv[2:]) if len(sys.argv) > 2 else sys.stdin.read()
        findings = scan(text)
        if findings:
            print(f"⚠️ 发现 {len(findings)} 处敏感信息：")
            for f in findings:
                print(f"  [{f['type']}] {f['match']}")
        else:
            print("✅ 未发现敏感信息")

    elif cmd == 'redact':
        text = ' '.join(sys.argv[2:]) if len(sys.argv) > 2 else sys.stdin.read()
        result, count = redact(text)
        if count:
            print(f"⚠️ 脱敏 {count} 处：")
        print(result)

    elif cmd == 'add-hash':
        val = sys.argv[2]
        add_hash(val)
        print(f"✅ 已添加哈希（sha256: {hashlib.sha256(val.encode()).hexdigest()[:16]}...）")

    elif cmd == 'test':
        test_cases = [
            "我的key是 sk-abc123def456ghi789jkl012mno345pqr",
            "密码：MyP@ssw0rd123!",
            "联系电话 13812345678",
            "身份证 110101199001011234",
            "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.test",
            "这是一段正常文本，没有敏感信息",
        ]
        for tc in test_cases:
            findings = scan(tc)
            status = f"⚠️ {len(findings)}处" if findings else "✅ 安全"
            print(f"{status} | {tc[:40]}")
