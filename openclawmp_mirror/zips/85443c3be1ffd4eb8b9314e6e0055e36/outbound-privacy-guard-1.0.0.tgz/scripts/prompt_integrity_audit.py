#!/usr/bin/env python3
"""每周 Prompt 完整性抽检脚本"""
import json, os, time, hashlib, secrets

INTEGRITY_FILE = os.path.expanduser('~/.openclaw/workspace/.prompt_integrity.json')
REPORT_FILE = '/tmp/prompt_integrity_report.json'

def rotate_token():
    """轮换校验码"""
    old_data = {}
    if os.path.exists(INTEGRITY_FILE):
        old_data = json.load(open(INTEGRITY_FILE))
    
    new_token = secrets.token_hex(8)
    new_data = {
        'token': new_token,
        'hash': hashlib.sha256(new_token.encode()).hexdigest(),
        'created': int(time.time()),
        'previous_hash': old_data.get('hash', ''),
        'version': old_data.get('version', 0) + 1
    }
    with open(INTEGRITY_FILE, 'w') as f:
        json.dump(new_data, f, indent=2)
    os.chmod(INTEGRITY_FILE, 0o600)
    return old_data.get('token', 'N/A'), new_token, new_data['version']

def check_file_integrity():
    """检查关键文件是否被篡改"""
    ws = os.path.expanduser('~/.openclaw/workspace')
    files = ['SOUL.md', 'AGENTS.md', 'SECURITY.md']
    results = {}
    for f in files:
        path = os.path.join(ws, f)
        if os.path.exists(path):
            content = open(path).read()
            results[f] = {
                'exists': True,
                'size': len(content),
                'hash': hashlib.sha256(content.encode()).hexdigest()[:16]
            }
        else:
            results[f] = {'exists': False}
    return results

def generate_report():
    """生成完整抽检报告"""
    old_token, new_token, version = rotate_token()
    file_check = check_file_integrity()
    
    report = {
        'timestamp': int(time.time()),
        'token_rotated': True,
        'token_version': version,
        'file_integrity': file_check,
        'status': 'ok'
    }
    
    with open(REPORT_FILE, 'w') as f:
        json.dump(report, f, indent=2, ensure_ascii=False)
    
    # 生成人类可读摘要
    summary = f"🔐 Prompt 完整性周检报告\n\n"
    summary += f"校验码已轮换（v{version}）\n\n"
    summary += "关键文件状态：\n"
    for fname, info in file_check.items():
        if info.get('exists'):
            summary += f"✅ {fname} ({info['size']}B, hash:{info['hash']})\n"
        else:
            summary += f"❌ {fname} 缺失！\n"
    
    return summary

if __name__ == '__main__':
    print(generate_report())
