---
name: i18n-toolkit
description: 智能国际化本地化工具，自动提取硬编码文本生成多语言资源文件，支持复数规则、RTL适配和文化敏感内容
---

# 多语言本地化工具

## 使用场景

当用户需要以下操作时使用本技能：
- 扫描代码提取硬编码文本，生成多语言资源文件
- 将已有翻译文件转换为另一种框架格式
- 处理复杂本地化问题（复数、RTL、日期/货币格式）
- 检查翻译质量和一致性
- 创建和维护术语表
- 评估本地化工作量和优先级

## 支持的框架和格式

| 框架 | 格式 | 文件扩展名 |
|------|------|-----------|
| React | i18next JSON | `en.json`, `zh-CN.json` |
| Vue | vue-i18n JSON/YAML | `en.json`, `zh-CN.yaml` |
| Next.js | next-intl JSON | `messages/en.json` |
| Angular | XLF / ARB | `messages.xlf`, `messages.arb` |
| Flutter | ARB | `app_en.arb`, `app_zh.arb` |
| Android | XML | `strings.xml` |
| iOS | Strings / Stringsdict | `Localizable.strings` |
| React Native | i18next JSON | `locales/en.json` |

## 硬编码文本扫描

### 扫描规则

识别以下类型的硬编码文本：
- **JSX/模板中的文本**：`<h1>Hello World</h1>`, `<p>欢迎注册</p>`
- **字符串字面量**：`alert('操作成功')`, `throw new Error('无效参数')`
- **属性值**：`placeholder="请输入邮箱"`, `title="删除确认"`
- **条件渲染文本**：`{isLoading ? '加载中...' : '加载完成'}`
- **模板字符串**：`` `共 ${count} 条结果` ``

### 不应提取的文本

以下类型不应被提取为翻译键：
- CSS 类名、HTML 属性（class, id, data-*）
- 代码逻辑字符串（变量名、函数名）
- API 端点 URL
- 正则表达式
- console.log 调试文本
- 已包裹在 i18n 调用中的文本

### 输出格式

```json
// 原始代码
// <h1>欢迎使用我们的平台</h1>
// <p>请输入您的邮箱地址</p>
// <button>立即注册</button>
// <span>已有账号？</span><a>请登录</a>

// 提取后生成的翻译文件
{
  "common": {
    "welcome": "欢迎使用我们的平台",
    "enterEmail": "请输入您的邮箱地址",
    "registerNow": "立即注册",
    "hasAccount": "已有账号？",
    "login": "请登录"
  }
}

// 替换后的代码
// <h1>{t('common.welcome')}</h1>
// <p>{t('common.enterEmail')}</p>
// <button>{t('common.registerNow')}</button>
// <span>{t('common.hasAccount')}</span><a>{t('common.login')}</a>
```

## 翻译键命名规范

### 扁平化 vs 嵌套化

**推荐嵌套化**（按页面/模块分组）：

```json
{
  "auth": {
    "login": {
      "title": "登录",
      "email": "邮箱地址",
      "password": "密码",
      "submit": "登录",
      "forgotPassword": "忘记密码？",
      "noAccount": "还没有账号？",
      "register": "立即注册"
    },
    "register": {
      "title": "注册",
      "confirmPassword": "确认密码",
      "agreeTerms": "我已阅读并同意{terms}",
      "termsLink": "服务条款"
    }
  },
  "common": {
    "loading": "加载中...",
    "error": "出错了",
    "retry": "重试",
    "cancel": "取消",
    "confirm": "确认",
    "save": "保存",
    "delete": "删除",
    "search": "搜索",
    "noData": "暂无数据"
  },
  "validation": {
    "required": "{field}不能为空",
    "email": "请输入有效的邮箱地址",
    "minLength": "{field}至少{min}个字符",
    "maxLength": "{field}最多{max}个字符",
    "passwordMismatch": "两次密码输入不一致"
  }
}
```

## 复数和变量处理

### ICU MessageFormat 语法

```json
{
  "cart": {
    "itemCount": "{count, plural, =0 {购物车是空的} one {购物车中有 # 件商品} other {购物车中共有 # 件商品}}",
    "totalPrice": "总计：{price, number, currency}",
    "lastUpdated": "最后更新于 {time, time, short}"
  }
}
```

### 各语言复数规则

| 语言 | 复数规则 |
|------|---------|
| 中文/日文/韩文 | 无复数变化（0和1用同一形式） |
| 英文 | 1=singular, other=plural |
| 法文 | 0/1=singular, other=plural |
| 阿拉伯文 | 0, 1, 2, few, many, other（6种形式） |
| 俄文 | 1, few, many, other（4种形式） |
| 波兰文 | 1, few, many, other（4种形式） |

## 文化和区域适配

### 日期时间格式

```
| 地区 | 日期格式 | 时间格式 |
|------|---------|---------|
| 中国 | 2026年4月15日 | 14:30 |
| 美国 | April 15, 2026 | 2:30 PM |
| 英国 | 15 April 2026 | 14:30 |
| 日本 | 2026年4月15日 | 14:30 |
| 德国 | 15. April 2026 | 14:30 |
```

### 货币格式

```
| 货币 | 符号位置 | 示例 |
|------|---------|------|
| CNY | 前置 | ¥1,234.56 |
| USD | 前置 | $1,234.56 |
| EUR | 后置 | 1.234,56€ |
| JPY | 前置（无小数）| ¥123,456 |
```

### RTL 布局适配

支持阿拉伯语、希伯来语等从右到左语言的布局适配：
- CSS logical properties（`margin-inline-start` 替代 `margin-left`）
- `dir="rtl"` 属性设置
- 镜像图标和布局方向
- 混合 LTR/RTL 内容处理

## 翻译质量检查

### 自动化检查项

- **完整性检查**：所有语言的翻译键是否一一对应
- **占位符检查**：变量插值 `{variable}` 是否在各语言中保持一致
- **HTML 标签检查**：翻译中是否保留了必要的 HTML 标签
- **长度检查**：翻译文本是否超出 UI 容器预期长度（提供 30%/50% 增长预警）
- **术语一致性**：同一术语在不同位置是否使用相同翻译
- **标点符号**：中文翻译是否使用中文标点，英文翻译是否使用英文标点
- **数字格式**：是否使用该语言习惯的数字格式

### 术语表管理

维护核心术语的多语言对照表：

```json
{
  "productName": {
    "en": "Product Name",
    "zh-CN": "产品名称",
    "ja": "製品名",
    "ko": "제품명",
    "ar": "اسم المنتج"
  },
  "features": {
    "en": "Features",
    "zh-CN": "功能特性",
    "ja": "機能",
    "ko": "기능",
    "ar": "الميزات"
  }
}
```

## 本地化优先级评估

根据目标市场推荐本地化优先级：

```
Tier 1（最高优先级，直接收益）：
- 英语（全球通用，约 15 亿使用人口）
- 简体中文（中国大陆，约 10 亿使用人口）
- 西班牙语（拉丁美洲 + 西班牙，约 5 亿）

Tier 2（高优先级，扩展市场）：
- 日语（日本市场，高 ARPU）
- 韩语（韩国市场，高 ARPU）
- 德语（欧洲最大经济体）
- 法语（法语区国家）

Tier 3（按需扩展）：
- 阿拉伯语（中东和北非市场）
- 葡萄牙语（巴西市场）
- 俄语（俄语区国家）
- 印地语（印度市场）
```

## 格式转换工具

支持以下格式之间的互相转换：
- JSON ↔ YAML ↔ CSV（翻译键值对照表）
- JSON → Android XML
- JSON → iOS Strings
- JSON → Flutter ARB
- CSV → 任何 JSON 格式（适合翻译团队协作）
