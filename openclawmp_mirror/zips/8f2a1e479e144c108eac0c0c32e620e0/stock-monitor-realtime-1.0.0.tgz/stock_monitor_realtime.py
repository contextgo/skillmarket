#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
股票实时监控系统 v1.0
=====================
每15分钟检查监控列表，异动≥5%或涨停时提醒

监控列表（9只）：
- 301512 智信精密
- 301486 致尚科技  
- 300570 太辰光
- 300580 贝斯特
- 300433 蓝思科技
- 603859 能科科技
- 603881 数据港
- 603893 瑞芯微
- 002195 岩山科技

触发条件：
1. 涨跌幅 ≥ 5%
2. 涨停（涨幅 ≥ 19.9% 创业板/科创板，≥ 9.9% 主板）
3. 跌停（跌幅 ≤ -19.9% 创业板/科创板，≤ -9.9% 主板）
"""

import os
import sys
import json
import akshare as ak
from datetime import datetime
from pathlib import Path

# 监控列表
WATCH_LIST = {
    "301512": {"name": "智信精密", "board": "创业板", "limit_up": 19.9, "limit_down": -19.9},
    "301486": {"name": "致尚科技", "board": "创业板", "limit_up": 19.9, "limit_down": -19.9},
    "300570": {"name": "太辰光", "board": "创业板", "limit_up": 19.9, "limit_down": -19.9},
    "300580": {"name": "贝斯特", "board": "创业板", "limit_up": 19.9, "limit_down": -19.9},
    "300433": {"name": "蓝思科技", "board": "创业板", "limit_up": 19.9, "limit_down": -19.9},
    "603859": {"name": "能科科技", "board": "沪市主板", "limit_up": 9.9, "limit_down": -9.9},
    "603881": {"name": "数据港", "board": "沪市主板", "limit_up": 9.9, "limit_down": -9.9},
    "603893": {"name": "瑞芯微", "board": "沪市主板", "limit_up": 9.9, "limit_down": -9.9},
    "002195": {"name": "岩山科技", "board": "深市主板", "limit_up": 9.9, "limit_down": -9.9},
    "600184": {"name": "光电股份", "board": "沪市主板", "limit_up": 9.9, "limit_down": -9.9},
}

# 状态文件（记录上次价格，避免重复提醒）
STATE_FILE = Path(r"E:\阶跃AI文件输出\记忆系统\stock_monitor_state.json")

# 输出目录
OUTPUT_DIR = Path(r"E:\阶跃AI文件输出\成果输出\股票监控")
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)


def load_state():
    """加载上次监控状态"""
    if STATE_FILE.exists():
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_state(state):
    """保存监控状态"""
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        json.dump(state, f, ensure_ascii=False, indent=2)


def get_realtime_data():
    """获取实时行情数据"""
    try:
        # 获取所有A股实时行情
        df = ak.stock_zh_a_spot_em()
        
        # 筛选监控列表
        watch_codes = list(WATCH_LIST.keys())
        df = df[df["代码"].isin(watch_codes)]
        
        result = {}
        for _, row in df.iterrows():
            code = row["代码"]
            result[code] = {
                "name": row["名称"],
                "price": float(row["最新价"]) if pd.notna(row["最新价"]) else 0,
                "change_pct": float(row["涨跌幅"]) if pd.notna(row["涨跌幅"]) else 0,
                "change_amount": float(row["涨跌额"]) if pd.notna(row["涨跌额"]) else 0,
                "volume": row["成交量"],
                "turnover": row["成交额"],
            }
        return result
    except Exception as e:
        print(f"[ERROR] 获取实时数据失败: {e}")
        return {}


def check_alerts(data, state):
    """检查触发条件"""
    alerts = []
    current_time = datetime.now().strftime("%H:%M")
    
    for code, info in data.items():
        if code not in WATCH_LIST:
            continue
            
        config = WATCH_LIST[code]
        change_pct = info["change_pct"]
        price = info["price"]
        
        # 检查涨停
        if change_pct >= config["limit_up"]:
            alert_key = f"{code}_limit_up"
            if state.get(alert_key) != current_time[:4]:  # 同小时内不重复提醒
                alerts.append({
                    "type": "涨停",
                    "code": code,
                    "name": config["name"],
                    "price": price,
                    "change_pct": change_pct,
                    "priority": "high"
                })
                state[alert_key] = current_time[:4]
        
        # 检查跌停
        elif change_pct <= config["limit_down"]:
            alert_key = f"{code}_limit_down"
            if state.get(alert_key) != current_time[:4]:
                alerts.append({
                    "type": "跌停",
                    "code": code,
                    "name": config["name"],
                    "price": price,
                    "change_pct": change_pct,
                    "priority": "high"
                })
                state[alert_key] = current_time[:4]
        
        # 检查≥5%异动（未涨停跌停）
        elif abs(change_pct) >= 5:
            alert_key = f"{code}_alert_{current_time[:4]}"
            if state.get(alert_key) != current_time[:4]:
                alerts.append({
                    "type": "大幅异动",
                    "code": code,
                    "name": config["name"],
                    "price": price,
                    "change_pct": change_pct,
                    "priority": "medium"
                })
                state[alert_key] = current_time[:4]
    
    return alerts, state


def format_alert_message(alerts):
    """格式化提醒消息"""
    if not alerts:
        return None
    
    now = datetime.now().strftime("%m月%d日 %H:%M")
    msg = f"[股票异动提醒] {now}\n"
    msg += "=" * 40 + "\n\n"
    
    # 高优先级（涨停跌停）放前面
    high_priority = [a for a in alerts if a["priority"] == "high"]
    medium_priority = [a for a in alerts if a["priority"] == "medium"]
    
    for alert in high_priority + medium_priority:
        emoji = "🔴" if alert["type"] in ["涨停", "跌停"] else "⚠️"
        direction = "📈" if alert["change_pct"] > 0 else "📉"
        msg += f"{emoji} [{alert['type']}] {alert['code']} {alert['name']}\n"
        msg += f"   {direction} 价格: {alert['price']:.2f}  涨跌: {alert['change_pct']:+.2f}%\n\n"
    
    return msg


def save_report(alerts, data):
    """保存监控报告"""
    now = datetime.now()
    filename = f"stock_monitor_{now.strftime('%Y%m%d_%H%M')}.md"
    filepath = OUTPUT_DIR / filename
    
    content = f"# 股票监控报告 {now.strftime('%Y-%m-%d %H:%M')}\n\n"
    
    if alerts:
        content += "## 异动提醒\n\n"
        for alert in alerts:
            content += f"- **{alert['type']}**: {alert['code']} {alert['name']}\n"
            content += f"  - 价格: {alert['price']:.2f}\n"
            content += f"  - 涨跌: {alert['change_pct']:+.2f}%\n\n"
    else:
        content += "## 监控状态\n\n无异常\n\n"
    
    content += "## 全部监控股票\n\n"
    content += "| 代码 | 名称 | 价格 | 涨跌幅 | 状态 |\n"
    content += "|:---|:---|---:|---:|:---|\n"
    
    for code, config in WATCH_LIST.items():
        if code in data:
            info = data[code]
            change_pct = info["change_pct"]
            if change_pct >= config["limit_up"]:
                status = "🔴涨停"
            elif change_pct <= config["limit_down"]:
                status = "🔴跌停"
            elif abs(change_pct) >= 5:
                status = "⚠️异动"
            else:
                status = "正常"
            content += f"| {code} | {config['name']} | {info['price']:.2f} | {change_pct:+.2f}% | {status} |\n"
    
    with open(filepath, "w", encoding="utf-8") as f:
        f.write(content)
    
    return filepath


def main():
    """主函数"""
    print(f"[{datetime.now().strftime('%H:%M:%S')}] 开始股票实时监控...")
    
    # 加载状态
    state = load_state()
    
    # 获取实时数据
    data = get_realtime_data()
    if not data:
        print("[ERROR] 未获取到数据")
        return
    
    print(f"[OK] 获取到 {len(data)} 只股票数据")
    
    # 检查提醒
    alerts, state = check_alerts(data, state)
    
    # 保存状态
    save_state(state)
    
    # 格式化消息
    message = format_alert_message(alerts)
    
    # 输出结果
    if message:
        print("\n" + "=" * 40)
        print(message)
        print("=" * 40)
        
        # 保存到提醒文件（供其他系统读取）
        alert_file = OUTPUT_DIR / "latest_alert.txt"
        with open(alert_file, "w", encoding="utf-8") as f:
            f.write(message)
    else:
        print("[OK] 无异常")
    
    # 保存报告
    report_path = save_report(alerts, data)
    print(f"[OK] 报告已保存: {report_path}")
    
    return message


if __name__ == "__main__":
    import pandas as pd  # 延迟导入
    main()
