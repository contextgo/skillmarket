---
name: feishu-thread-mode
displayName: 飞书话题模式任务跟踪
description: 在飞书对话中使用话题模式追踪多步骤任务进度，所有进度消息折叠在话题中，不干扰主聊天流。支持自动触发（步骤>2）、应用身份发送、防错机制。
version: 5.0.0
author: OpenClaw Team
platform: feishu
tags: feishu, thread, task-tracker, productivity
---

# 飞书话题模式任务跟踪技能

**版本**: V5.0 ✅ 重构版（2026-03-10）  
**作者**: OpenClaw Team  
**更新日期**: 2026-03-10 14:15  
**适用平台**: 飞书（Feishu/Lark）  
**状态**: ✅ 生产就绪（重构完成，防错增强）

---

## 📋 技能概述

### 功能
在飞书对话中使用**话题模式**追踪多步骤任务的执行进度，所有进度消息折叠在话题中，不干扰主聊天流。

### 触发条件

**自动触发**（满足任一条件）：
- ✅ 任务步骤数 > 2
- ✅ 用户消息以 "话题！" 或 "thread！" 开头
- ✅ 用户明确说 "用话题模式"

**手动触发词**：
- "话题！"
- "thread！"
- "用话题模式"
- "在话题里回复"

### 特点
- ✅ **话题在机器人回复下创建** - 用户不会自动订阅，不打扰
- ✅ **纯文本格式** - 简洁清晰，飞书原生支持
- ✅ **完整执行历史** - 可随时查看任务执行过程
- ✅ **多任务隔离** - 每个任务独立话题
- ✅ **应用身份** - 消息显示为机器人（🤖 助手）
- ✅ **自动读取凭证** - 从 `/home/admin/.openclaw/openclaw.json` 自动获取
- ✅ **V5.0 新增** - 防错机制、自动退出、封装方法

### ✅ 已验证（2026-03-10 14:15）

**V5.0 测试结果**：
- ✅ 凭证自动读取成功（从 openclaw.json 自动获取）
- ✅ 身份检查正常（显示"应用身份（机器人）"）
- ✅ 自动判断函数正常（5/5 测试通过）
- ✅ run_task 封装方法正常
- ✅ 任务完成标志机制正常
- ✅ 自动退出机制正常（sys.exit(0)）
- ✅ 所有消息显示机器人身份
- ✅ 所有消息在话题中折叠

---

## 🔧 工具类：ThreadTracker V5.0

**位置**: `/home/admin/.openclaw/workspace/skills/feishu-thread-mode/feishu_thread_tracker_v5.py`

### 核心方法

#### 推荐方式：使用 run_task 封装（不会犯错！）

```python
from feishu_thread_tracker_v5 import ThreadTracker

# 初始化（自动读取凭证）
tracker = ThreadTracker()

# 定义任务函数
def my_task(thread_id):
    tracker.update_progress(thread_id, "步骤 1: 查询天气")
    # 执行任务...
    tracker.update_progress(thread_id, "步骤 2: 生成海报")
    # 执行任务...
    return "任务结果"

# 执行任务（自动管理完整流程）
tracker.run_task(user_msg_id, "任务名称", my_task)
# ✅ 自动调用 complete_task
# ✅ 自动 sys.exit(0)
# ✅ 不会再发消息！
```

#### 传统方式：手动管理流程

```python
from feishu_thread_tracker_v5 import ThreadTracker

tracker = ThreadTracker()

# 启动任务
thread_id = tracker.start_task(user_msg_id, "任务名称")

# 更新进度
tracker.update_progress(thread_id, "步骤 1", detail="详细说明")

# 完成任务
tracker.complete_task(
    thread_id,
    "任务名称",
    result="结果摘要",
    steps=["步骤 1", "步骤 2", "步骤 3"]
)
# ⚠️ 脚本应在此结束，不要再发消息！
# ⚠️ 会自动输出醒目警告
```

### 自动判断函数

```python
from feishu_thread_tracker_v5 import should_use_thread

# 自动判断是否使用话题模式
if should_use_thread(user_message, estimated_steps=3):
    # 使用话题模式
    tracker = ThreadTracker()
    # ...
else:
    # 直接回复
    # ...
```

**判断条件**:
1. 用户消息以 "话题！" 或 "thread！" 开头 → True
2. 任务步骤数 > 2 → True
3. 包含 "用话题模式" 等关键词 → True
4. 其他 → False

---

## 🚀 自动判断逻辑

### 何时使用话题模式？

```python
def should_use_thread(task_steps: int, user_message: str) -> bool:
    """
    判断是否应该使用话题模式
    
    条件：
    1. 任务步骤数 > 2
    2. 用户消息以 "话题！" 或 "thread！" 开头
    3. 用户明确说 "用话题模式"
    """
    # 条件 1: 步骤数 > 2
    if task_steps > 2:
        return True
    
    # 条件 2: 用户明确要求
    if user_message.startswith("话题！") or user_message.startswith("thread！"):
        return True
    
    # 条件 3: 包含关键词
    if "用话题模式" in user_message or "在话题里" in user_message:
        return True
    
    return False
```

### 使用示例

**示例 1: 多步骤任务（自动触发）**
```
用户：帮我查询北京天气并制作壁纸
  ↓（检测到 3 个步骤：查询天气→获取数据→生成壁纸）
机器人：📋 任务已接收：查询北京天气并制作壁纸
    └─ [话题] 
       ├─ 🕐 08:30 任务开始
       ├─ ⏳ 查询天气数据
       ├─ ⏳ 获取天气信息
       ├─ ⏳ 生成壁纸
       └─ ✅ 任务完成
```

**示例 2: 用户明确要求**
```
用户：话题！帮我处理这个文件
  ↓（用户以"话题！"开头）
机器人：📋 任务已接收：处理文件
    └─ [话题] 进度更新...
```

**示例 3: 简单任务（不使用话题）**
```
用户：今天天气怎么样？
  ↓（单步骤，直接回复）
机器人：北京今天晴朗，15°C
```

---

## ⚙️ 配置指南

### 1. 创建飞书应用

1. 访问 https://open.feishu.cn/app
2. 创建自建应用
3. 获取 **App ID** 和 **App Secret**

### 2. 配置权限

在飞书开放平台添加权限：
- ✅ `im:message` - 发送消息
- ✅ `im:message:reply` - 回复消息

### 3. 环境变量配置

```bash
# 在 OpenClaw 环境中配置
export FEISHU_APP_ID="cli_xxxx"
export FEISHU_APP_SECRET="xxxx"
```

### 4. 在技能中使用

```python
import os
from feishu_thread_tracker import ThreadTracker

# 从环境变量读取配置
APP_ID = os.getenv("FEISHU_APP_ID")
APP_SECRET = os.getenv("FEISHU_APP_SECRET")

# 初始化跟踪器
tracker = ThreadTracker(APP_ID, APP_SECRET)

# 判断是否使用话题模式
user_message = "帮我查询天气并制作壁纸"
task_steps = 3  # 预估步骤数

if task_steps > 2 or user_message.startswith("话题！"):
    # 使用话题模式
    thread_id = tracker.start_task(message_id, "任务名称")
    tracker.update_progress(thread_id, "步骤 1")
    # ...
    tracker.complete_task(thread_id, "任务名称", result="结果")
else:
    # 直接回复
    send_reply(message_id, "直接回复内容")
```

---

## 📝 最佳实践

### 1. 步骤划分建议

| 步骤数 | 建议 |
|--------|------|
| 1 步 | 直接回复 |
| 2 步 | 直接回复或简单话题 |
| 3+ 步 | **必须使用话题模式** |

### 2. 📁 文件处理规则（2026-03-09 23:03 更新 ⭐）

**默认规则**:
```
收到文件 → 上传到飞书云盘"周数人"文件夹 → 发送云盘链接
```

**目录结构**（自动创建）:
```
周数人/
├── 技能文档/
│   ├── 飞书话题模式/
│   ├── 魔搭图片生成/
│   └── 每日总结同步/
├── 工作记录/
│   └── 2026-03/
├── 配置文件/
└── 临时文件/
```

**例外情况**（只有这些才直接发文件）:
- ✅ 用户说"发云文档"
- ✅ 用户说"直接发文件"
- ✅ 用户说"别发链接，发文件"

**技术限制**（飞书 API）:
| 身份类型 | 上传图片 | 上传文件 | 发送文件到话题 |
|---------|---------|---------|---------------|
| **应用身份**（机器人） | ✅ 可以 | ❌ 不行 | ❌ 无权访问用户文件 |
| **用户身份**（OAuth） | ✅ 可以 | ✅ 可以 | ✅ 可以 |

**话题模式文件发送**:
- ❌ 应用身份无法上传文件到消息（错误 234001）
- ✅ 可以发送云盘链接到话题中
- ⚠️ 需要用户 OAuth 才能直接发文件到话题

**代码示例**:
```python
# ✅ 默认：上传到云盘，发送链接
file_url = upload_to_feishu_drive(file_path, folder="周数人/技能文档/")
send_to_thread(thread_id, f"📎 文件已上传：{file_url}")

# ✅ 例外：用户要求直接发文件（需要 OAuth）
feishu_im_user_message(
    action="reply",
    message_id=thread_id,
    msg_type="file",
    content=f'{{"file_key":"{file_key}"}}',
    reply_in_thread=True
)
```

### 2. 进度消息格式

```
⏳ 步骤名称
   详细说明（可选）

✅ 任务完成：任务名称
   执行步骤：
   • 步骤 1
   • 步骤 2
   • 步骤 3
   
   结果：具体结果
   
✨ 任务圆满完成！
```

### 3. 错误处理

```python
try:
    tracker.update_progress(thread_id, "关键步骤")
    # 执行可能出错的代码
except Exception as e:
    tracker.send_error(thread_id, str(e), step="关键步骤")
```

---

## 🔍 常见问题

### Q: 为什么话题在机器人回复下创建？

**A**: 飞书的话题订阅规则：
- 话题在**用户消息**下创建 → 用户自动订阅（会收到通知）
- 话题在**机器人回复**下创建 → 用户不会自动订阅（不打扰）

### Q: 如何判断任务步骤数？

**A**: 根据任务类型预估：
```python
TASK_STEPS = {
    "查询天气": 2,      # 查询→返回
    "天气 + 壁纸": 3,   # 查询→获取→生成
    "图片生成": 3,      # 提交→轮询→下载
    "数据处理": 4,      # 读取→处理→分析→输出
}
```

### Q: 话题会保存多久？

**A**: 永久保存（除非手动删除），可随时查看历史。

---

## 📦 文件清单

| 文件 | 说明 |
|------|------|
| `SKILL.md` | 技能定义文档 |
| `feishu_thread_tracker.py` | 话题跟踪工具类 |
| `examples.py` | 使用示例 |
| `README.md` | 详细说明 |
| `requirements.txt` | Python 依赖 |

---

**版本**: V4.0  
**最后更新**: 2026-03-09  
**维护者**: OpenClaw Team
