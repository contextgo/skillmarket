#!/usr/bin/env python3
"""
话题模式任务跟踪 - 完整示例

演示如何使用 ThreadTracker 完成一个多步骤任务
"""

import sys
sys.path.insert(0, '.')

from feishu_thread_tracker import ThreadTracker
import time


def example_weather_query():
    """
    示例 1：查询天气任务
    """
    print("=" * 50)
    print("示例 1：查询天气")
    print("=" * 50)
    
    # 配置
    tracker = ThreadTracker(
        app_id="cli_xxxx",
        app_secret="xxxx"
    )
    
    # 用户消息 ID（从消息上下文获取）
    user_msg_id = "om_xxxx"
    
    # 启动任务
    thread_id = tracker.start_task(user_msg_id, "查询北京天气")
    
    if not thread_id:
        print("❌ 任务启动失败")
        return
    
    # 模拟任务执行
    tracker.update_progress(thread_id, "连接天气服务", "正在建立连接...")
    time.sleep(1)
    
    tracker.update_progress(thread_id, "获取数据", "下载天气信息...")
    time.sleep(1)
    
    tracker.update_progress(thread_id, "分析处理", "整理温度范围...")
    time.sleep(1)
    
    # 完成任务
    tracker.complete_task(
        thread_id,
        "查询北京天气",
        result="北京明天：晴朗，2°C ~ 11°C，微风",
        steps=["连接服务", "获取数据", "分析处理"]
    )
    
    print("✅ 示例 1 完成\n")


def example_with_error_handling():
    """
    示例 2：带错误处理的任务
    """
    print("=" * 50)
    print("示例 2：带错误处理")
    print("=" * 50)
    
    tracker = ThreadTracker(
        app_id="cli_xxxx",
        app_secret="xxxx"
    )
    
    user_msg_id = "om_xxxx"
    thread_id = tracker.start_task(user_msg_id, "数据处理")
    
    if not thread_id:
        return
    
    try:
        tracker.update_progress(thread_id, "读取文件")
        # 模拟读取
        time.sleep(0.5)
        
        tracker.update_progress(thread_id, "分析数据")
        # 模拟可能出错的操作
        # raise Exception("数据格式错误")  # 取消注释测试错误处理
        time.sleep(0.5)
        
        tracker.update_progress(thread_id, "生成报告")
        time.sleep(0.5)
        
        tracker.complete_task(
            thread_id,
            "数据处理",
            result="处理完成，生成报告 10 页",
            steps=["读取文件", "分析数据", "生成报告"]
        )
        
    except Exception as e:
        tracker.send_error(thread_id, str(e), step="分析数据")
    
    print("✅ 示例 2 完成\n")


def example_multi_task():
    """
    示例 3：多任务并行
    """
    print("=" * 50)
    print("示例 3：多任务并行")
    print("=" * 50)
    
    tracker = ThreadTracker(
        app_id="cli_xxxx",
        app_secret="xxxx"
    )
    
    user_msg_id = "om_xxxx"
    
    # 启动多个任务
    thread_id_1 = tracker.start_task(user_msg_id, "任务 A：查询天气")
    thread_id_2 = tracker.start_task(user_msg_id, "任务 B：查询日程")
    thread_id_3 = tracker.start_task(user_msg_id, "任务 C：处理文件")
    
    # 分别更新进度
    if thread_id_1:
        tracker.update_progress(thread_id_1, "获取数据")
    
    if thread_id_2:
        tracker.update_progress(thread_id_2, "查询日历")
    
    if thread_id_3:
        tracker.update_progress(thread_id_3, "读取文件")
    
    # 分别完成
    if thread_id_1:
        tracker.complete_task(thread_id_1, "任务 A", result="天气晴朗")
    
    if thread_id_2:
        tracker.complete_task(thread_id_2, "任务 B", result="日程已查询")
    
    if thread_id_3:
        tracker.complete_task(thread_id_3, "任务 C", result="文件处理完成")
    
    print("✅ 示例 3 完成\n")


def example_car_wash_advice():
    """
    示例 4：实际场景 - 洗车建议
    """
    print("=" * 50)
    print("示例 4：洗车建议（实际场景）")
    print("=" * 50)
    
    tracker = ThreadTracker(
        app_id="cli_xxxx",
        app_secret="xxxx"
    )
    
    user_msg_id = "om_xxxx"
    
    # 启动任务
    thread_id = tracker.start_task(user_msg_id, "查询天气并判断洗车适宜度")
    
    if not thread_id:
        return
    
    # 查询天气
    tracker.update_progress(thread_id, "查询天气数据", "正在获取明天天气...")
    time.sleep(1)
    
    # 模拟天气数据
    weather = {
        "city": "北京",
        "weather": "多云转晴",
        "temp": "5°C ~ 15°C",
        "rain_prob": 10
    }
    
    tracker.update_progress(
        thread_id,
        "获取天气信息",
        f"{weather['city']}：{weather['weather']}\n"
        f"温度：{weather['temp']}\n"
        f"降水概率：{weather['rain_prob']}%"
    )
    time.sleep(1)
    
    # 分析洗车适宜度
    tracker.update_progress(thread_id, "分析洗车条件", "评估天气条件...")
    time.sleep(1)
    
    # 生成建议
    if weather['rain_prob'] < 20:
        advice = "✅ 适合洗车\n\n明天无雨，天气良好，洗完车不易弄脏"
    else:
        advice = "❌ 不建议洗车\n\n有降水可能，建议等天气好转"
    
    tracker.complete_task(
        thread_id,
        "查询天气并判断洗车适宜度",
        result=advice,
        steps=["查询天气", "获取信息", "分析条件", "生成建议"]
    )
    
    print("✅ 示例 4 完成\n")


if __name__ == "__main__":
    print("\n🚀 话题模式任务跟踪 - 完整示例\n")
    
    # 运行示例（取消注释需要测试的示例）
    # example_weather_query()
    # example_with_error_handling()
    # example_multi_task()
    # example_car_wash_advice()
    
    print("✨ 所有示例完成！")
    print("\n提示：取消注释示例函数来运行特定示例")
