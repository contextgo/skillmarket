#!/usr/bin/env python3
"""
话题模式自动判断工具

功能：根据任务复杂度自动判断是否使用话题模式
作者：OpenClaw Team
版本：V1.0
日期：2026-03-09
"""

import os
import re
from typing import Tuple, List, Optional


# =============================================================================
# 任务步骤预估配置
# =============================================================================

# 常见任务类型及其预估步骤数
TASK_STEPS_MAP = {
    # 图片生成类
    "图片": 3,           # 提交→轮询→下载
    "绘画": 3,
    "文生图": 3,
    "生成图片": 3,
    "画一": 3,
    
    # 天气类
    "天气": 2,           # 查询→返回
    "气温": 2,
    "预报": 2,
    
    # 天气 + 衍生任务
    "天气.*壁纸": 4,     # 查询→获取→设计→生成
    "天气.*图片": 4,
    "天气.*报告": 3,     # 查询→获取→整理
    
    # 数据处理类
    "处理.*文件": 3,     # 读取→处理→输出
    "分析.*数据": 4,     # 读取→清洗→分析→报告
    "转换.*格式": 2,     # 读取→转换
    
    # 搜索类
    "搜索": 2,           # 搜索→整理
    "查询": 2,
    "查找": 2,
    
    # 文档类
    "创建.*文档": 3,     # 准备→创建→格式化
    "写.*文章": 3,       # 构思→写作→润色
    "总结": 3,           # 收集→整理→输出
    
    # 多步骤复合任务
    "并": 3,             # 包含"并"通常是多任务
    "然后": 3,
    "之后": 3,
}

# 明确要求使用话题模式的关键词
THREAD_KEYWORDS = [
    "话题！",
    "thread！",
    "用话题模式",
    "在话题里",
    "话题回复",
    "thread 模式",
]

# 简单任务关键词（即使有其他特征也不使用话题）
SIMPLE_TASK_KEYWORDS = [
    "你好",
    "在吗",
    "谢谢",
    "再见",
    "早上好",
    "晚上好",
]


# =============================================================================
# 核心函数
# =============================================================================

def count_task_steps(task_description: str) -> int:
    """
    根据任务描述预估步骤数
    
    Args:
        task_description: 任务描述文本
        
    Returns:
        预估的步骤数
    """
    max_steps = 1  # 默认单步骤
    
    # 检查是否包含复合任务连接词
    if "并" in task_description or "然后" in task_description or "之后" in task_description:
        max_steps = max(max_steps, 3)
    
    # 检查任务类型关键词
    for keyword, steps in TASK_STEPS_MAP.items():
        if re.search(keyword, task_description, re.IGNORECASE):
            max_steps = max(max_steps, steps)
    
    # 检查是否有多个动词（暗示多步骤）
    verbs = ["查询", "获取", "生成", "创建", "处理", "分析", "下载", "上传", "发送", "制作"]
    verb_count = sum(1 for verb in verbs if verb in task_description)
    if verb_count >= 2:
        max_steps = max(max_steps, verb_count + 1)
    
    return max_steps


def has_thread_keyword(message: str) -> bool:
    """
    检查消息是否包含话题模式关键词
    
    Args:
        message: 用户消息
        
    Returns:
        是否包含话题关键词
    """
    message = message.strip()
    
    # 检查是否以话题关键词开头
    for keyword in THREAD_KEYWORDS:
        if message.startswith(keyword):
            return True
    
    # 检查是否包含话题关键词
    for keyword in THREAD_KEYWORDS:
        if keyword in message:
            return True
    
    return False


def is_simple_chat(message: str) -> bool:
    """
    检查是否是简单聊天（不需要话题模式）
    
    Args:
        message: 用户消息
        
    Returns:
        是否是简单聊天
    """
    message = message.strip().lower()
    
    for keyword in SIMPLE_TASK_KEYWORDS:
        if keyword in message:
            return True
    
    # 检查是否是问候语
    if re.match(r"^(早 | 好 | 嗨 | hello|hi|hey)[，,!.!]*", message):
        return True
    
    # 检查是否是纯表情或简短回复
    if len(message) <= 5 and not re.search(r"[\u4e00-\u9fa5a-zA-Z]", message):
        return True
    
    return False


def should_use_thread_mode(
    user_message: str,
    estimated_steps: Optional[int] = None,
    custom_threshold: int = 2
) -> Tuple[bool, str]:
    """
    判断是否应该使用话题模式
    
    Args:
        user_message: 用户消息
        estimated_steps: 预估步骤数（如果不传则自动计算）
        custom_threshold: 自定义步骤阈值（默认>2 使用话题）
        
    Returns:
        (是否使用话题模式，原因说明)
    """
    # 1. 检查是否是简单聊天
    if is_simple_chat(user_message):
        return False, "简单聊天，不需要话题模式"
    
    # 2. 检查用户是否明确要求使用话题
    if has_thread_keyword(user_message):
        return True, "用户明确要求使用话题模式"
    
    # 3. 自动计算步骤数
    if estimated_steps is None:
        estimated_steps = count_task_steps(user_message)
    
    # 4. 根据步骤数判断
    if estimated_steps > custom_threshold:
        return True, f"任务复杂度较高（预估{estimated_steps}个步骤）"
    
    return False, f"任务简单（预估{estimated_steps}个步骤）"


# =============================================================================
# 使用示例
# =============================================================================

if __name__ == "__main__":
    # 测试用例
    test_cases = [
        "生成图片：一只猫咪",
        "话题！帮我处理这个文件",
        "查询北京天气",
        "查询北京天气并制作壁纸",
        "你好",
        "帮我分析数据并生成报告，然后发送邮件",
        "文生图：夕阳下的海滩",
        "用话题模式处理这个任务",
    ]
    
    print("=" * 60)
    print("话题模式自动判断测试")
    print("=" * 60)
    
    for message in test_cases:
        should_use, reason = should_use_thread_mode(message)
        steps = count_task_steps(message)
        
        status = "✅ 使用话题" if should_use else "❌ 直接回复"
        print(f"\n消息：{message}")
        print(f"预估步骤：{steps}")
        print(f"判断：{status}")
        print(f"原因：{reason}")
