#!/usr/bin/env python3
"""
飞书话题模式任务跟踪工具 - V5.0 (重构版)

功能：在飞书中使用话题模式追踪任务执行进度
特点：
- 话题在机器人回复下创建，用户不会自动订阅
- 纯文本格式，简洁清晰
- 完整执行历史保留在话题中
- 应用身份，消息显示为机器人
- ✅ V5.0 新增：防错机制、自动判断、流程封装

作者：OpenClaw Team
版本：V5.0
日期：2026-03-10 (重构)

更新日志:
- V5.0 (2026-03-10): 重构版，添加防错机制
  * 添加 run_task 封装方法，自动管理完整流程
  * 添加身份检查，防止用用户身份发送
  * 添加脚本自动退出机制
  * 简化使用方式，减少犯错机会
- V4.1 (2026-03-09): 添加凭证自动读取
- V3.0 (2026-03-08): 初始版本
"""

import requests
import json
import time
import sys
from typing import Optional, List, Callable


# =============================================================================
# 全局标志：防止脚本结束后继续发消息
# =============================================================================
_task_completed = False


def is_task_completed() -> bool:
    """检查任务是否已完成（用于防止重复发消息）"""
    global _task_completed
    return _task_completed


def mark_task_completed():
    """标记任务已完成"""
    global _task_completed
    _task_completed = True


# =============================================================================
# ThreadTracker V5.0 - 重构版
# =============================================================================

class ThreadTracker:
    """
    飞书话题模式任务跟踪器 V5.0
    
    工作流程：
    1. 用户发送任务消息
    2. 机器人回复"任务已接收"（不创建话题）
    3. 在机器人回复下创建话题
    4. 后续进度都在话题中更新
    5. 任务完成后自动标记，防止继续发消息
    
    使用示例（推荐方式 - 使用 run_task 封装）:
        tracker = ThreadTracker()
        
        def task_steps(thread_id):
            tracker.update_progress(thread_id, "步骤 1")
            # 执行任务...
            tracker.update_progress(thread_id, "步骤 2")
            # 执行任务...
            return "任务结果"
        
        tracker.run_task(user_msg_id, "任务名称", task_steps)
        # ✅ 任务完成后自动退出，不会再发消息！
    
    使用示例（传统方式）:
        tracker = ThreadTracker()
        thread_id = tracker.start_task(user_msg_id, "任务名称")
        tracker.update_progress(thread_id, "步骤 1")
        tracker.complete_task(thread_id, "任务名称", result="结果")
    """
    
    def __init__(self, app_id: Optional[str] = None, app_secret: Optional[str] = None):
        """
        初始化跟踪器
        
        Args:
            app_id: 飞书应用 App ID（如果不传则自动从 OpenClaw 配置读取）
            app_secret: 飞书应用 App Secret（如果不传则自动从 OpenClaw 配置读取）
        
        ✅ V4.1 更新：自动从 /home/admin/.openclaw/openclaw.json 读取凭证
        ✅ V5.0 更新：添加身份检查
        """
        import os
        
        # 优先使用传入的参数
        if app_id and app_secret:
            self.app_id = app_id
            self.app_secret = app_secret
        else:
            # 尝试从环境变量读取
            self.app_id = os.getenv("FEISHU_APP_ID")
            self.app_secret = os.getenv("FEISHU_APP_SECRET")
            
            # 如果环境变量也没有，从 OpenClaw 配置读取
            if not self.app_id or not self.app_secret:
                try:
                    sys.path.insert(0, '/home/admin/.openclaw/workspace/tools')
                    from openclaw_credentials import get_feishu_credentials
                    self.app_id, self.app_secret = get_feishu_credentials()
                except Exception as e:
                    raise RuntimeError(
                        f"飞书凭证获取失败：{e}\n"
                        "请确保 /home/admin/.openclaw/openclaw.json 中已配置飞书应用，\n"
                        "或设置环境变量 FEISHU_APP_ID 和 FEISHU_APP_SECRET"
                    )
        
        if not self.app_id or not self.app_secret:
            raise ValueError("请提供飞书应用凭证，或设置环境变量 FEISHU_APP_ID 和 FEISHU_APP_SECRET")
        
        # ✅ V5.0 新增：身份检查
        print(f"✅ ThreadTracker V5.0 初始化成功")
        print(f"   身份：应用身份（机器人）")
        print(f"   App ID: {self.app_id}")
        print()
        
        self._token_cache = None
        self._token_expire = 0
        self._current_thread_id = None
    
    def _get_tenant_token(self) -> str:
        """
        获取飞书应用访问令牌（带缓存）
        
        Returns:
            tenant_access_token
        """
        # 检查缓存
        if self._token_cache and time.time() < self._token_expire:
            return self._token_cache
        
        # 获取新 token
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        data = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        try:
            resp = requests.post(url, json=data, timeout=10).json()
            token = resp.get('tenant_access_token')
            
            if not token:
                raise Exception(f"获取 token 失败：{resp}")
            
            # 缓存 token（1.5 小时）
            self._token_cache = token
            self._token_expire = time.time() + 5400
            
            return token
            
        except Exception as e:
            raise Exception(f"获取飞书 token 失败：{str(e)}")
    
    def send_reply(self, message_id: str, text: str, 
                   reply_in_thread: bool = False) -> Optional[str]:
        """
        发送回复消息
        
        Args:
            message_id: 要回复的消息 ID
            text: 回复文本内容
            reply_in_thread: 是否作为话题回复（默认 False）
            
        Returns:
            发送成功的消息 ID，失败返回 None
            
        ✅ V5.0 新增：身份检查，防止在任务完成后发消息
        """
        # ✅ V5.0 检查：任务是否已完成
        if is_task_completed():
            print("\n⚠️  警告：任务已完成，不应再发消息！")
            print("⚠️  请检查脚本逻辑，确保 complete_task() 后没有发消息的代码")
            return None
        
        try:
            token = self._get_tenant_token()
            url = f"https://open.feishu.cn/open-apis/im/v1/messages/{message_id}/reply"
            
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
            
            data = {
                "msg_type": "text",
                "content": json.dumps({"text": text}, ensure_ascii=False),
                "reply_in_thread": reply_in_thread
            }
            
            resp = requests.post(url, json=data, headers=headers, timeout=10).json()
            
            if resp.get('code') == 0:
                return resp['data']['message_id']
            else:
                print(f"❌ 发送消息失败：{resp}")
                return None
                
        except Exception as e:
            print(f"❌ 发送消息异常：{str(e)}")
            return None
    
    def start_task(self, user_message_id: str, task_name: str) -> Optional[str]:
        """
        启动任务追踪
        
        工作流程：
        1. 回复用户消息（不创建话题）
        2. 在机器人回复下创建话题
        
        Args:
            user_message_id: 用户的任务消息 ID
            task_name: 任务名称
            
        Returns:
            话题基础消息 ID，失败返回 None
        """
        # 重置任务完成标志
        global _task_completed
        _task_completed = False
        
        # 步骤 1: 回复用户消息（不创建话题）
        reply_text = f"📋 任务已接收：{task_name}"
        robot_reply_id = self.send_reply(user_message_id, reply_text, 
                                         reply_in_thread=False)
        
        if not robot_reply_id:
            print("❌ 发送任务接收确认失败")
            return None
        
        # 步骤 2: 在机器人回复下创建话题
        thread_starter = f"🕐 {time.strftime('%H:%M')} 任务开始\n\n⏳ 初始化环境"
        thread_base_id = self.send_reply(robot_reply_id, thread_starter, 
                                         reply_in_thread=True)
        
        if not thread_base_id:
            print("❌ 创建话题失败")
            return None
        
        self._current_thread_id = thread_base_id
        return thread_base_id
    
    def update_progress(self, thread_base_id: str, step_name: str, 
                       detail: Optional[str] = None) -> Optional[str]:
        """
        更新进度
        
        Args:
            thread_base_id: 话题基础消息 ID（start_task 返回值）
            step_name: 当前步骤描述
            detail: 详细说明（可选）
            
        Returns:
            发送成功的消息 ID，失败返回 None
        """
        if not thread_base_id:
            print("❌ 话题未初始化，请先调用 start_task")
            return None
        
        text = f"⏳ {step_name}"
        
        if detail:
            text += f"\n{detail}"
        
        return self.send_reply(thread_base_id, text, reply_in_thread=True)
    
    def complete_task(self, thread_base_id: str, task_name: str,
                     result: Optional[str] = None,
                     steps: Optional[List[str]] = None) -> Optional[str]:
        """
        完成任务
        
        Args:
            thread_base_id: 话题基础消息 ID
            task_name: 任务名称
            result: 结果摘要（可选）
            steps: 执行步骤列表（可选）
            
        Returns:
            发送成功的消息 ID，失败返回 None
            
        ✅ V5.0 新增：自动标记任务完成，防止继续发消息
        """
        if not thread_base_id:
            print("❌ 话题未初始化")
            return None
        
        text = f"✅ 任务完成：{task_name}"
        
        if steps:
            steps_text = "\n".join([f"• {step}" for step in steps])
            text += f"\n\n执行步骤：\n{steps_text}"
        
        if result:
            text += f"\n\n结果：\n{result}"
        
        text += "\n\n✨ 任务圆满完成！"
        
        message_id = self.send_reply(thread_base_id, text, reply_in_thread=True)
        
        # ✅ V5.0 新增：标记任务完成
        mark_task_completed()
        
        # ✅ V5.0 新增：防错警告
        print("\n" + "="*70)
        print("⚠️  脚本结束！不要再发消息！")
        print("⚠️  tracker.complete_task() = 话题外零消息！")
        print("⚠️  之后用任何工具发消息都是错误的！")
        print("="*70)
        print()
        print("✅ 任务已完成，脚本应在此结束")
        print()
        
        return message_id
    
    def run_task(self, user_message_id: str, task_name: str, 
                 task_func: Callable[[str], str]) -> Optional[str]:
        """
        ✅ V5.0 新增：封装完整任务流程
        
        自动管理：start_task → 执行任务 → complete_task → 退出
        
        Args:
            user_message_id: 用户消息 ID
            task_name: 任务名称
            task_func: 任务执行函数，接收 thread_id，返回结果字符串
            
        Returns:
            任务完成消息 ID，失败返回 None
            
        使用示例:
            def my_task(thread_id):
                tracker.update_progress(thread_id, "步骤 1")
                # 执行任务...
                tracker.update_progress(thread_id, "步骤 2")
                # 执行任务...
                return "任务结果"
            
            tracker.run_task(user_msg_id, "任务名称", my_task)
            # ✅ 自动调用 complete_task，自动退出
        """
        # 启动任务
        thread_id = self.start_task(user_message_id, task_name)
        if not thread_id:
            return None
        
        try:
            # 执行任务
            result = task_func(thread_id)
            
            # 完成任务
            self.complete_task(thread_id, task_name, result=result)
            
            # ✅ V5.0 新增：自动退出
            print("✅ 脚本正常退出")
            sys.exit(0)
            
        except Exception as e:
            # 错误处理
            self.send_error(thread_id, str(e))
            print(f"\n❌ 任务执行失败：{e}")
            sys.exit(1)
        
        return None
    
    def send_error(self, thread_base_id: str, error_msg: str,
                  step: Optional[str] = None) -> Optional[str]:
        """
        发送错误消息
        
        Args:
            thread_base_id: 话题基础消息 ID
            error_msg: 错误信息
            step: 失败的步骤（可选）
            
        Returns:
            发送成功的消息 ID，失败返回 None
        """
        if not thread_base_id:
            print("❌ 话题未初始化")
            return None
        
        text = f"❌ 执行失败"
        
        if step:
            text += f"\n步骤：{step}"
        
        text += f"\n\n错误：\n{error_msg}"
        text += "\n\n💡 请检查错误信息后重试。"
        
        return self.send_reply(thread_base_id, text, reply_in_thread=True)


# =============================================================================
# 自动判断函数
# =============================================================================

def should_use_thread(user_message: str, estimated_steps: int = 1) -> bool:
    """
    ✅ V5.0 新增：自动判断是否使用话题模式
    
    Args:
        user_message: 用户消息文本
        estimated_steps: 预估任务步骤数
        
    Returns:
        True: 应该使用话题模式
        False: 直接回复
        
    判断条件:
        1. 用户消息以 "话题！" 或 "thread！" 开头
        2. 任务步骤数 > 2
        3. 用户明确说 "用话题模式"
    """
    # 条件 1: 用户明确要求
    if user_message.startswith("话题！") or user_message.startswith("thread！"):
        return True
    
    # 条件 2: 步骤数 > 2
    if estimated_steps > 2:
        return True
    
    # 条件 3: 包含关键词
    if "用话题模式" in user_message or "在话题里" in user_message:
        return True
    
    return False


# =============================================================================
# 使用示例
# =============================================================================

if __name__ == "__main__":
    # 示例 1: 使用 run_task 封装（推荐）
    print("="*70)
    print("示例 1: 使用 run_task 封装（推荐方式）")
    print("="*70)
    print()
    
    def example_task(thread_id: str) -> str:
        """示例任务函数"""
        tracker = ThreadTracker()
        
        # 步骤 1
        tracker.update_progress(thread_id, "步骤 1: 初始化", detail="准备环境...")
        time.sleep(0.5)
        
        # 步骤 2
        tracker.update_progress(thread_id, "步骤 2: 执行任务", detail="处理中...")
        time.sleep(0.5)
        
        # 步骤 3
        tracker.update_progress(thread_id, "步骤 3: 完成", detail="生成结果...")
        time.sleep(0.5)
        
        return "任务成功完成"
    
    # ✅ 使用 run_task 自动管理流程
    # tracker.run_task("om_xxxx", "示例任务", example_task)
    # 注意：实际运行会调用 API，这里仅演示
    
    print()
    print("="*70)
    print("示例 2: 传统方式（需要手动管理流程）")
    print("="*70)
    print()
    print("""
tracker = ThreadTracker()
thread_id = tracker.start_task(user_msg_id, "任务名称")

tracker.update_progress(thread_id, "步骤 1")
# 执行任务...

tracker.update_progress(thread_id, "步骤 2")
# 执行任务...

tracker.complete_task(thread_id, "任务名称", result="结果")
# ⚠️ 脚本应在此结束，不要再发消息！
    """)
    
    print()
    print("="*70)
    print("✅ V5.0 新功能演示完成")
    print("="*70)
