#!/usr/bin/env python3
"""
飞书话题模式任务跟踪工具 - V3.0

功能：在飞书中使用话题模式追踪任务执行进度
特点：
- 话题在机器人回复下创建，用户不会自动订阅
- 纯文本格式，简洁清晰
- 完整执行历史保留在话题中
- 应用身份，消息显示为机器人

作者：OpenClaw Team
版本：V3.0
日期：2026-03-08
"""

import requests
import json
import time
from typing import Optional, List


class ThreadTracker:
    """
    飞书话题模式任务跟踪器
    
    工作流程：
    1. 用户发送任务消息
    2. 机器人回复"任务已接收"（不创建话题）
    3. 在机器人回复下创建话题
    4. 后续进度都在话题中更新
    
    使用示例：
        tracker = ThreadTracker(app_id="cli_xxx", app_secret="xxx")
        thread_id = tracker.start_task(user_msg_id, "任务名称")
        tracker.update_progress(thread_id, "步骤名称")
        tracker.complete_task(thread_id, "任务名称", result="结果")
    """
    
    def __init__(self, app_id: Optional[str] = None, app_secret: Optional[str] = None):
        """
        初始化跟踪器
        
        Args:
            app_id: 飞书应用 App ID（如果不传则自动从 OpenClaw 配置读取）
            app_secret: 飞书应用 App Secret（如果不传则自动从 OpenClaw 配置读取）
        
        ✅ V4.1 更新：自动从 /home/admin/.openclaw/openclaw.json 读取凭证
        """
        import os
        import sys
        
        # 优先使用传入的参数
        if app_id and app_secret:
            self.app_id = app_id
            self.app_secret = app_secret
        else:
            # 尝试从环境变量读取
            self.app_id = os.getenv("FEISHU_APP_ID")
            self.app_secret = os.getenv("FEISHU_APP_SECRET")
            
            # 如果环境变量也没有，从 OpenClaw 配置读取
            if not self.app_id or not self.app_secret:
                try:
                    sys.path.insert(0, '/home/admin/.openclaw/workspace/tools')
                    from openclaw_credentials import get_feishu_credentials
                    self.app_id, self.app_secret = get_feishu_credentials()
                except Exception as e:
                    raise RuntimeError(
                        f"飞书凭证获取失败：{e}\n"
                        "请确保 /home/admin/.openclaw/openclaw.json 中已配置飞书应用，\n"
                        "或设置环境变量 FEISHU_APP_ID 和 FEISHU_APP_SECRET"
                    )
        
        if not self.app_id or not self.app_secret:
            raise ValueError("请提供飞书应用凭证，或设置环境变量 FEISHU_APP_ID 和 FEISHU_APP_SECRET")
        
        self._token_cache = None
        self._token_expire = 0
    
    def _get_tenant_token(self) -> str:
        """
        获取飞书应用访问令牌（带缓存）
        
        Returns:
            tenant_access_token
        """
        # 检查缓存
        if self._token_cache and time.time() < self._token_expire:
            return self._token_cache
        
        # 获取新 token
        url = "https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal"
        data = {
            "app_id": self.app_id,
            "app_secret": self.app_secret
        }
        
        try:
            resp = requests.post(url, json=data, timeout=10).json()
            token = resp.get('tenant_access_token')
            
            if not token:
                raise Exception(f"获取 token 失败：{resp}")
            
            # 缓存 token（1.5小时）
            self._token_cache = token
            self._token_expire = time.time() + 5400
            
            return token
            
        except Exception as e:
            raise Exception(f"获取飞书 token 失败：{str(e)}")
    
    def send_reply(self, message_id: str, text: str, 
                   reply_in_thread: bool = False) -> Optional[str]:
        """
        发送回复消息
        
        Args:
            message_id: 要回复的消息 ID
            text: 回复文本内容
            reply_in_thread: 是否作为话题回复（默认 False）
            
        Returns:
            发送成功的消息 ID，失败返回 None
        """
        try:
            token = self._get_tenant_token()
            url = f"https://open.feishu.cn/open-apis/im/v1/messages/{message_id}/reply"
            
            headers = {
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json"
            }
            
            data = {
                "msg_type": "text",
                "content": json.dumps({"text": text}, ensure_ascii=False),
                "reply_in_thread": reply_in_thread
            }
            
            resp = requests.post(url, json=data, headers=headers, timeout=10).json()
            
            if resp.get('code') == 0:
                return resp['data']['message_id']
            else:
                print(f"❌ 发送消息失败：{resp}")
                return None
                
        except Exception as e:
            print(f"❌ 发送消息异常：{str(e)}")
            return None
    
    def start_task(self, user_message_id: str, task_name: str) -> Optional[str]:
        """
        启动任务追踪
        
        工作流程：
        1. 回复用户消息（不创建话题）
        2. 在机器人回复下创建话题
        
        Args:
            user_message_id: 用户的任务消息 ID
            task_name: 任务名称
            
        Returns:
            话题基础消息 ID，失败返回 None
        """
        # 步骤 1: 回复用户消息（不创建话题）
        reply_text = f"📋 任务已接收：{task_name}"
        robot_reply_id = self.send_reply(user_message_id, reply_text, 
                                         reply_in_thread=False)
        
        if not robot_reply_id:
            print("❌ 发送任务接收确认失败")
            return None
        
        # 步骤 2: 在机器人回复下创建话题
        thread_starter = f"🕐 {time.strftime('%H:%M')} 任务开始\n\n⏳ 初始化环境"
        thread_base_id = self.send_reply(robot_reply_id, thread_starter, 
                                         reply_in_thread=True)
        
        if not thread_base_id:
            print("❌ 创建话题失败")
            return None
        
        return thread_base_id
    
    def update_progress(self, thread_base_id: str, step_name: str, 
                       detail: Optional[str] = None) -> Optional[str]:
        """
        更新进度
        
        Args:
            thread_base_id: 话题基础消息 ID（start_task 返回值）
            step_name: 当前步骤描述
            detail: 详细说明（可选）
            
        Returns:
            发送成功的消息 ID，失败返回 None
        """
        if not thread_base_id:
            print("❌ 话题未初始化，请先调用 start_task")
            return None
        
        text = f"⏳ {step_name}"
        
        if detail:
            text += f"\n{detail}"
        
        return self.send_reply(thread_base_id, text, reply_in_thread=True)
    
    def complete_task(self, thread_base_id: str, task_name: str,
                     result: Optional[str] = None,
                     steps: Optional[List[str]] = None) -> Optional[str]:
        """
        完成任务
        
        Args:
            thread_base_id: 话题基础消息 ID
            task_name: 任务名称
            result: 结果摘要（可选）
            steps: 执行步骤列表（可选）
            
        Returns:
            发送成功的消息 ID，失败返回 None
        """
        if not thread_base_id:
            print("❌ 话题未初始化")
            return None
        
        text = f"✅ 任务完成：{task_name}"
        
        if steps:
            steps_text = "\n".join([f"• {step}" for step in steps])
            text += f"\n\n执行步骤：\n{steps_text}"
        
        if result:
            text += f"\n\n结果：\n{result}"
        
        text += "\n\n✨ 任务圆满完成！"
        
        message_id = self.send_reply(thread_base_id, text, reply_in_thread=True)
        
        # ⚠️ 2026-03-10 13:30 新增：防错警告
        print("\n" + "="*60)
        print("⚠️  脚本结束！不要再发消息！")
        print("⚠️  tracker.complete_task() = 话题外零消息！")
        print("⚠️  之后用任何工具发消息都是错误的！")
        print("="*60)
        
        return message_id
    
    def send_error(self, thread_base_id: str, error_msg: str,
                  step: Optional[str] = None) -> Optional[str]:
        """
        发送错误消息
        
        Args:
            thread_base_id: 话题基础消息 ID
            error_msg: 错误信息
            step: 失败的步骤（可选）
            
        Returns:
            发送成功的消息 ID，失败返回 None
        """
        if not thread_base_id:
            print("❌ 话题未初始化")
            return None
        
        text = f"❌ 执行失败"
        
        if step:
            text += f"\n步骤：{step}"
        
        text += f"\n\n错误：\n{error_msg}"
        text += "\n\n💡 请检查错误信息后重试。"
        
        return self.send_reply(thread_base_id, text, reply_in_thread=True)


# =============================================================================
# 使用示例
# =============================================================================

if __name__ == "__main__":
    # 配置（替换为你的应用凭证）
    APP_ID = "cli_xxxx"
    APP_SECRET = "xxxx"
    
    # 示例：用户消息 ID（实际使用时从消息上下文获取）
    USER_MESSAGE_ID = "om_xxxx"
    
    # 创建跟踪器
    tracker = ThreadTracker(APP_ID, APP_SECRET)
    
    # 启动任务
    thread_id = tracker.start_task(USER_MESSAGE_ID, "查询北京天气")
    
    if thread_id:
        # 更新进度
        tracker.update_progress(thread_id, "查询数据", "正在获取天气信息...")
        time.sleep(1)
        
        tracker.update_progress(thread_id, "处理数据")
        time.sleep(1)
        
        # 完成任务
        tracker.complete_task(
            thread_id,
            "查询北京天气",
            result="北京明天：晴朗，2°C ~ 11°C",
            steps=["初始化", "查询", "处理", "生成"]
        )
        
        print("\n🎉 任务完成！")
    else:
        print("\n❌ 任务启动失败")
