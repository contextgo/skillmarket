# 飞书话题模式任务跟踪技能

## 📋 简介

在飞书对话中使用**话题模式**追踪多步骤任务的执行进度，所有进度消息折叠在话题中，不干扰主聊天流。

**核心特性**：
- ✅ 自动判断：步骤数 > 2 的任务自动使用话题模式
- ✅ 用户触发：支持 "话题！"、"thread！" 等触发词
- ✅ 不打扰：话题在机器人回复下创建，用户不会自动订阅
- ✅ 完整历史：所有执行步骤保留在话题中

---

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 配置环境变量

```bash
export FEISHU_APP_ID="cli_xxxx"
export FEISHU_APP_SECRET="xxxx"
```

### 3. 使用示例

```python
from feishu_thread_tracker import ThreadTracker
from thread_auto_detect import should_use_thread_mode

# 初始化跟踪器
tracker = ThreadTracker()

# 判断是否使用话题模式
user_message = "帮我查询天气并制作壁纸"
should_use, reason = should_use_thread_mode(user_message)

if should_use:
    # 启动任务
    thread_id = tracker.start_task(user_message_id, "任务名称")
    
    # 更新进度
    tracker.update_progress(thread_id, "步骤 1")
    tracker.update_progress(thread_id, "步骤 2")
    
    # 完成任务
    tracker.complete_task(thread_id, "任务名称", result="结果")
else:
    # 直接回复
    print("直接回复内容")
```

---

## 📁 文件说明

| 文件 | 说明 |
|------|------|
| `SKILL.md` | 技能定义文档（触发词、参数、执行方式） |
| `feishu_thread_tracker.py` | 话题跟踪工具类（核心功能） |
| `thread_auto_detect.py` | 自动判断是否使用话题模式 |
| `examples_usage.py` | 完整使用示例 |
| `examples.py` | 旧版示例（保留兼容） |
| `requirements.txt` | Python 依赖 |

---

## 🎯 自动判断规则

### 使用话题模式的条件（满足任一）：

1. **步骤数 > 2**：自动计算任务复杂度
2. **用户明确要求**：消息包含 "话题！"、"thread！" 等关键词
3. **多步骤任务**：包含 "并"、"然后" 等连接词

### 示例：

| 用户消息 | 判断 | 原因 |
|---------|------|------|
| "生成图片：一只猫咪" | ✅ 使用话题 | 3 个步骤（提交→轮询→下载） |
| "话题！处理文件" | ✅ 使用话题 | 用户明确要求 |
| "查询天气" | ❌ 直接回复 | 单步骤任务 |
| "查询天气并制作壁纸" | ✅ 使用话题 | 4 个步骤 |
| "你好" | ❌ 直接回复 | 简单聊天 |

---

## 🔧 API 参考

### ThreadTracker 类

```python
# 初始化
tracker = ThreadTracker(app_id=None, app_secret=None)
# 参数可从环境变量读取：FEISHU_APP_ID, FEISHU_APP_SECRET

# 启动任务
thread_id = tracker.start_task(user_message_id: str, task_name: str)

# 更新进度
tracker.update_progress(thread_base_id: str, step_name: str, detail: str = None)

# 完成任务
tracker.complete_task(
    thread_base_id: str,
    task_name: str,
    result: str = None,
    steps: List[str] = None
)

# 错误处理
tracker.send_error(thread_base_id: str, error_msg: str, step: str = None)
```

### 自动判断函数

```python
# 判断是否使用话题模式
should_use, reason = should_use_thread_mode(
    user_message: str,
    estimated_steps: int = None,
    custom_threshold: int = 2
)

# 计算任务步骤数
steps = count_task_steps(task_description: str)

# 检查话题关键词
has_keyword = has_thread_keyword(message: str)
```

---

## 📝 最佳实践

### 1. 进度消息格式

```
⏳ 步骤名称
   详细说明（可选）

✅ 任务完成：任务名称
   执行步骤：
   • 步骤 1
   • 步骤 2
   
   结果：具体结果
   
✨ 任务圆满完成！
```

### 2. 错误处理

```python
try:
    tracker.update_progress(thread_id, "关键步骤")
    # 执行代码...
except Exception as e:
    tracker.send_error(thread_id, str(e), step="关键步骤")
```

### 3. 多任务隔离

```python
# 每个任务使用独立的话题 ID
thread_1 = tracker.start_task(msg_id, "任务 A")
thread_2 = tracker.start_task(msg_id, "任务 B")

# 分别更新，互不干扰
tracker.update_progress(thread_1, "步骤 A1")
tracker.update_progress(thread_2, "步骤 B1")
```

---

## 🔍 常见问题

### Q: 如何获取飞书应用凭证？

**A**: 
1. 访问 https://open.feishu.cn/app
2. 创建自建应用
3. 在"凭证与基础信息"中获取 App ID 和 App Secret

### Q: 需要配置哪些权限？

**A**: 
- `im:message` - 发送消息
- `im:message:reply` - 回复消息

### Q: 为什么话题在机器人回复下创建？

**A**: 避免用户自动订阅话题，减少打扰。

---

## 📄 许可证

MIT License

---

**版本**: V4.0  
**最后更新**: 2026-03-09  
**维护者**: OpenClaw Team
