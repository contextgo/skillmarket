#!/usr/bin/env python3
"""
话题模式使用示例

演示如何在实际场景中使用话题模式跟踪任务
"""

import sys
import os

# 添加技能目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from feishu_thread_tracker import ThreadTracker
from thread_auto_detect import should_use_thread_mode, count_task_steps


# =============================================================================
# 示例 1: 简单判断
# =============================================================================

def example_1_auto_detect():
    """示例 1: 自动判断是否使用话题模式"""
    
    print("=" * 60)
    print("示例 1: 自动判断是否使用话题模式")
    print("=" * 60)
    
    test_messages = [
        "生成图片：一只猫咪在海边",
        "话题！帮我处理这个文件",
        "查询北京天气",
        "查询北京天气并制作壁纸",
        "你好",
        "帮我分析数据并生成报告，然后发送邮件",
    ]
    
    for message in test_messages:
        should_use, reason = should_use_thread_mode(message)
        steps = count_task_steps(message)
        
        status = "✅ 使用话题" if should_use else "❌ 直接回复"
        print(f"\n📝 消息：{message}")
        print(f"   预估步骤：{steps}")
        print(f"   判断：{status}")
        print(f"   原因：{reason}")


# =============================================================================
# 示例 2: 完整任务流程
# =============================================================================

def example_2_full_workflow():
    """示例 2: 完整的任务执行流程（模拟）"""
    
    print("\n" + "=" * 60)
    print("示例 2: 完整的任务执行流程（模拟）")
    print("=" * 60)
    
    # 模拟用户消息
    user_message = "帮我查询北京天气并制作壁纸"
    user_message_id = "om_xxxx"  # 实际使用时从上下文获取
    
    # 判断是否使用话题模式
    should_use, reason = should_use_thread_mode(user_message)
    
    print(f"\n📝 用户消息：{user_message}")
    print(f"   判断结果：{'使用话题模式' if should_use else '直接回复'}")
    print(f"   原因：{reason}")
    
    if should_use:
        print("\n🔧 初始化话题跟踪器...")
        print("   tracker = ThreadTracker()")
        
        print("\n🚀 启动任务...")
        print(f"   thread_id = tracker.start_task('{user_message_id}', '查询天气并制作壁纸')")
        
        print("\n📊 更新进度...")
        print("   tracker.update_progress(thread_id, '查询天气数据')")
        print("   tracker.update_progress(thread_id, '获取天气信息')")
        print("   tracker.update_progress(thread_id, '设计壁纸布局')")
        print("   tracker.update_progress(thread_id, '生成壁纸图片')")
        
        print("\n✅ 完成任务...")
        print("   tracker.complete_task(")
        print("       thread_id,")
        print("       '查询天气并制作壁纸',")
        print("       result='北京明天：晴朗，15°C',")
        print("       steps=['查询', '获取', '设计', '生成']")
        print("   )")


# =============================================================================
# 示例 3: 错误处理
# =============================================================================

def example_3_error_handling():
    """示例 3: 错误处理示例"""
    
    print("\n" + "=" * 60)
    print("示例 3: 错误处理")
    print("=" * 60)
    
    print("""
try:
    # 启动任务
    thread_id = tracker.start_task(user_msg_id, "数据处理")
    
    # 执行步骤 1
    tracker.update_progress(thread_id, "读取文件")
    # ... 读取代码
    
    # 执行步骤 2（可能出错）
    tracker.update_progress(thread_id, "分析数据")
    # ... 分析代码（可能抛出异常）
    
    # 完成
    tracker.complete_task(thread_id, "数据处理", result="完成")
    
except Exception as e:
    # 错误处理
    tracker.send_error(thread_id, str(e), step="分析数据")
    """)


# =============================================================================
# 示例 4: 多任务并行
# =============================================================================

def example_4_parallel_tasks():
    """示例 4: 多任务并行处理"""
    
    print("\n" + "=" * 60)
    print("示例 4: 多任务并行处理")
    print("=" * 60)
    
    print("""
# 任务 1: 查询天气
thread_id_1 = tracker.start_task(user_msg_id, "查询北京天气")

# 任务 2: 查询上海天气
thread_id_2 = tracker.start_task(user_msg_id, "查询上海天气")

# 分别更新进度
tracker.update_progress(thread_id_1, "步骤 A1: 查询数据")
tracker.update_progress(thread_id_2, "步骤 B1: 查询数据")

# 等待任务完成...

tracker.complete_task(thread_id_1, "查询北京天气", result="北京：晴朗")
tracker.complete_task(thread_id_2, "查询上海天气", result="上海：多云")
    """)


# =============================================================================
# 示例 5: 环境变量配置
# =============================================================================

def example_5_env_config():
    """示例 5: 环境变量配置"""
    
    print("\n" + "=" * 60)
    print("示例 5: 环境变量配置")
    print("=" * 60)
    
    print("""
# 方法 1: 在 shell 中设置
export FEISHU_APP_ID="cli_xxxx"
export FEISHU_APP_SECRET="xxxx"

# 方法 2: 在 .env 文件中
# .env
FEISHU_APP_ID=cli_xxxx
FEISHU_APP_SECRET=xxxx

# 方法 3: 在代码中直接指定（不推荐用于生产环境）
tracker = ThreadTracker(
    app_id="cli_xxxx",
    app_secret="xxxx"
)

# 推荐：从环境变量读取
tracker = ThreadTracker()  # 自动从环境变量读取
    """)


# =============================================================================
# 主函数
# =============================================================================

def main():
    """运行所有示例"""
    
    print("\n" + "🎯" * 30)
    print("飞书话题模式使用示例")
    print("🎯" * 30 + "\n")
    
    example_1_auto_detect()
    example_2_full_workflow()
    example_3_error_handling()
    example_4_parallel_tasks()
    example_5_env_config()
    
    print("\n" + "=" * 60)
    print("✅ 所有示例运行完成！")
    print("=" * 60)
    print("\n💡 提示：实际使用时，请替换为真实的飞书应用凭证和消息 ID")


if __name__ == "__main__":
    main()
