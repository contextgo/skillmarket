# Acceptance Spec (DSL)

- Case ID:
- Given:
- When:
- Then:
- Hard Assertions:
- Semantic Criteria:
- Risk Checks:
- Pass Threshold:
