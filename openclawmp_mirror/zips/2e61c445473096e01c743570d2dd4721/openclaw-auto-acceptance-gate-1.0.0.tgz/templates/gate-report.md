# Gate Report

- Release ID:
- Verdict: PASS / QUARANTINE / BLOCK
- Score:
- Failed Cases:
- Root Causes:
- Fix Commands:
- Rollback Needed: Yes/No
