---
name: amazon-listing-cosmo-A9
displayName: 亚马逊 Listing COSMO+A9 生成器
description: 基于亚马逊 COSMO 意图算法 + A9 权重规则，自动生成高收录高转化标题、五点、描述、Search Terms
version: 1.0.0
author: your-name
tags: [亚马逊, Listing, A9, COSMO, 关键词, 跨境电商, 竞品优化]
license: MIT
---

# amazon-listing-cosmo-A9
亚马逊 Listing 自动化生成技能，严格遵循亚马逊 A9 关键词权重规则 + COSMO 语义意图算法。

## 功能
- 自动生成高权重标题（≤200 字符）
- 五点描述按 痛点→功能→收益→场景 结构
- 长描述增强语义相关性，提升 COSMO 收录
- Search Terms 只补长尾，不重复埋词
- 全程合规，不夸大、不违规词

## 使用方式
在 OpenClaw 中直接调用，传入产品信息即可自动输出完整 Listing。