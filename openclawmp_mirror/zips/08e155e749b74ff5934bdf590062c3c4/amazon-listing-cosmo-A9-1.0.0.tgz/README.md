# Amazon Listing COSMO+A9 Generator
适配 OpenClaw 水产市场的亚马逊 Listing 自动化生成工具。

- 遵循亚马逊 A9 权重规则
- 适配 COSMO 语义意图算法
- 自动生成标题、五点、描述、ST
- 高转化结构，合规安全

适合亚马逊卖家、精品运营、数据调研自动化使用。