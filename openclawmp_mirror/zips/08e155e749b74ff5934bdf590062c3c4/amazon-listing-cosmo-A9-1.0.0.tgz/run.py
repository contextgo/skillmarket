def generate_listing(product):
    product_name = product.get("product_name", "")
    core_keywords = product.get("core_keywords", [])
    features = product.get("features", [])
    pain_points = product.get("pain_points", [])
    usage_scene = product.get("usage_scene", "")
    audience = product.get("audience", "")
    specs = product.get("specs", "")

    kw1 = core_keywords[0] if core_keywords else ""
    kw2 = core_keywords[1] if len(core_keywords) > 1 else ""
    ft1 = features[0] if features else ""
    ft2 = features[1] if len(features) > 1 else ""
    pain1 = pain_points[0] if pain_points else ""

    # Title (A9 权重结构，控制长度)
    title = f"{product_name} with {ft1} & {ft2} | {kw1} for {usage_scene} | {audience}"
    title = title[:190]

    # 5 Bullets (COSMO 友好：痛点→功能→收益→场景)
    bullets = [
        f"✅ Solve {pain1} easily with our upgraded {ft1} design, ensuring stable performance in any scene.",
        f"✅ Optimized {ft2} provides better using experience, perfect for daily use by {audience}.",
        f"✅ High-quality construction ensures durability and long service life for various scenarios.",
        f"✅ Universal compatibility: {specs}, fit for most standard devices in the market.",
        f"✅ Ideal for {usage_scene}, bringing convenience and efficiency to your daily life."
    ]

    # Description (语义增强，利于 COSMO)
    description = f"""
{product_name} is designed to provide better experience for {audience}.
With {ft1} and {ft2}, this product effectively solves common problems like {pain1}.
Suitable for {usage_scene}, it combines practicality and durability to meet daily needs.
Premium material and solid structure ensure reliable performance and long-term usage.
    """.strip()

    # Search Terms (不重复标题，补长尾)
    st_parts = []
    if kw1:
        st_parts.append(kw1)
    if kw2:
        st_parts.append(kw2)
    st_parts.append(usage_scene)
    st_parts.append(audience)
    search_terms = " ".join(st_parts)

    return {
        "title": title,
        "bullets": bullets,
        "description": description,
        "search_terms": search_terms
    }


# 入口（OpenClaw 标准格式）
def run(args):
    return generate_listing(args)