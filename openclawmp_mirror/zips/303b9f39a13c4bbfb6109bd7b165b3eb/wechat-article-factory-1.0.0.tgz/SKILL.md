---
name: "wechat-article-factory"
assetId: "5a537b22706a44fea37ec968de33f1b6"
description: "公众号文章自动化工厂。覆盖「选题 → 搜索热点 → 生成标题 → 写正文 → 生成封面 → 发布到草稿箱」全链路。用户想写公众号文章、搜热点、自动发布公众号时触发。"
---

# WeChat Article Factory — 公众号文章自动化工厂

## 概述

端到端的微信公众号内容生产流水线，从选题到发布一键完成。

**一句话**：说个主题，10 秒后草稿箱见。

## 工作流程

```
用户: 给我写一篇关于 AI Agent 的文章
  ↓
s1 搜索热点 → 给出 3~5 个实时热点
  ↓
s2 生成标题 → 给出 5 个标题候选
  ↓
s3 写大纲 → 用户确认
  ↓
s4 写正文 + 三遍审校 → 去 AI 味、调节奏、事实核查
  ↓
s5 生成封面 → 用户确认
  ↓
s6 发布草稿箱 → media_id 确认
```

**全程可干预**：换主题、换标题、换封面、随时重来。

## 触发方式

- 「写一篇公众号文章」「帮我写篇文章发布到公众号」
- 「搜热点」「今日科技热点」
- 「AI Agent」+ 「写文章」→ 自动进入流水线
- 「发布到草稿箱」「推送到公众号」

## 文章风格

对标「数字生命卡兹克」：
- 观点鲜明，有判断
- 信息密度高
- 第一/第二人称，有温度
- 不使用他人具体案例和数据

## 三遍审校

每篇文章必须经过：

1. **去 AI 味**：删除 inflation 词汇（赋能、迭代、颠覆、助力…）
2. **节奏优化**：短句替代长句，段落留白
3. **事实核查**：对数据、日期、术语做二次确认

## 富格式写作支持

公众号支持以下富格式元素：

| 格式 | 语法 | 状态 |
|------|------|------|
| 任务清单 | `- [x]` `- [ ]` | ✅ 直接支持 |
| 键盘按键 | `<kbd>Ctrl</kbd>` | ✅ 直接支持 |
| 脚注 | `[^1]` 文末 `[^1]: ...` | ✅ 直接支持 |
| 状态表格 | Emoji + 表格 | ✅ 直接支持 |
| 代码块 | ` ```lang ` | ✅ 支持 34+ 语言 |
| 架构图 | ` ```text ` 等宽绘图 | ✅ 直接支持 |
| 引用块 | `> ` | ✅ 直接支持 |
| Mermaid 图 | ` ```mermaid ` | ⚠️ 需截图 |
| LaTeX 公式 | `$...$` | ⚠️ 需截图 |
| 高亮 | `==text==` | ⚠️ 需截图 |

## 封面图生成（4 方案 fallback）

| 优先级 | 方案 | 说明 |
|--------|------|------|
| 1 | AI 绘图 | Hunyuan / DALL-E 队列空闲时 |
| 2 | PowerShell System.Drawing | 稳定可靠，~5s |
| 3 | SVG + Puppeteer | 有系统浏览器时 |
| 4 | SVG 文件 | 任何情况，用户手动另存 |

封面尺寸：900×383px（公众号封面标准比例）

## 微信公众号配置

使用前需在公众号后台完成以下配置：

### 1. 设置 IP 白名单

在「设置与开发 → 基本配置」中添加白名单。

获取当前出口 IP：
```bash
curl ifconfig.me
```

### 2. 获取 AppID 和 AppSecret

在「设置与开发 → 基本配置」获取。

### 3. 配置环境变量（可选）

```
WECHAT_APP_ID=wx1234567890abcdef
WECHAT_APP_SECRET=xxxxxxxxxxxxxxxx
WECHAT_COVER_PATH=/path/to/cover.png
```

## 内部模块架构

```
src/
├── pipelines/
│   └── ContentFactoryPipeline.js    # 流水线状态机（s1~s6）
├── modules/
│   ├── s1_hotspot/                  # 热点搜索（RSS + Tavily）
│   ├── s2_titles/                   # 标题生成
│   ├── s3_outline/                  # 大纲确认
│   ├── s4_article/                  # 正文写作 + 三遍审校
│   ├── s5_cover/                    # 封面生成 + 压缩
│   └── s6_publish/                  # 发布到草稿箱
├── agents/
│   ├── ArticleWriterAgent.js        # 写手 Agent
│   └── WechatWriterAgent.js         # 审校 Agent
├── services/
│   ├── WechatPublisher.js           # 公众号 API（token / 封面上传 / 草稿）
│   └── WechatPublishingService.js   # 封面生成服务
└── skills/
    └── web_search/                   # 搜索服务（RSS + Tavily）
```

## 故障排查

遇到问题时，先查阅 `references/troubleshooting.md`：

**最常见问题**：

| 症状 | 解决方案 |
|------|---------|
| 封面图上传 40113 | 检查 MIME 类型与文件扩展名是否匹配 |
| Python 脚本乱码 | 用 `-File` 代替 `-Command`，写 .ps1 文件 |
| baoyu-md-to-html 报错 | 检查 bun 依赖：`bun pm cache rm && bun install` |
| 草稿发布失败 | 检查 AppID / AppSecret / IP 白名单 |

## 跳步参数

完整流水线默认执行。如需跳步：

```
--topic="xxx"    跳过 s1，直接以 xxx 为主題
--modules=s2,s3  只运行指定模块
--resume         从快照恢复（断点续跑）
--clear          清除会话快照
```
