# 公众号自动化发布故障排查手册

> 核心教训：Windows + Node.js + 子进程 + 非 ASCII 字符 = 编码地狱

---

## 一、封面图生成失败

### 症状
封面文件 1011 字节，内容为 XML 错误信息。
```
<?xml version="1.0" encoding="..."?>
<Error>SyntaxError: invalid syntax...
```

### 根因
Python 单行命令中的多行代码被 `replace(/\n/g, ' ')` 拍成一行，`#` 注释吞掉后续代码。

### 修复方案

**❌ 错误做法**
```javascript
// 错误：单行 -c 传多行代码
execSync(`python -c "${pyScript.replace(/\n/g, ' ')}"`)
```

**✅ 正确做法：写 .ps1 文件 + `-File` 执行**
```javascript
// 写文件（UTF-8 BOM，确保中文正确）
writeFileSync(psFile, '\ufeff' + psScript, 'utf8');
// 用 -File 执行（不用 -Command）
execSync(`powershell -NoProfile -ExecutionPolicy Bypass -File "${psFile}"`)
```

### PowerShell 编码对照表

| 写法 | 编码 | 中文支持 |
|------|------|---------|
| `-Command "..."` | 系统默认 | ❌ 乱码 |
| `-File script.ps1`（UTF-8+BOM） | UTF-8 | ✅ |
| `-File script.ps1` | UTF-16LE | ✅ |

---

## 二、baoyu-md-to-html 报错

### 症状
```
error: Unknown argument: --output
error: Unknown argument: --json-output
```

### 根因
调用了不存在的参数。

### 有效参数（实测）
```bash
bun run main.ts <mdPath> --theme <themeId> --keep-title --cite --count
```

**有效主题**：`default`, `grace`, `modern`, `simple`

**输出方式**：HTML 文件写入 md 同目录（无需指定 `--output`）

---

## 三、WechatPublisher MIME 类型错误

### 症状
```
errcode: 40113
errmsg: "file type unallowed"
```

### 根因
`Content-Type: image/png` 硬编码，但压缩后封面是 `.webp`。

### 修复
根据文件扩展名动态检测：
```javascript
const ext = (filename.split('.').pop() || 'png').toLowerCase();
const mimeMap = { jpg:'image/jpeg', png:'image/png', webp:'image/webp' };
const mimeType = mimeMap[ext] || 'image/png';
```

---

## 四、bun 依赖损坏

### 症状
```
error: Cannot find module "unist-util-visit-parents"
```

### 修复
```bash
bun pm cache rm
cd <skillDir>
bun install
```

---

## 五、快速验证清单

```
封面图：文件大小 > 10KB ✓ | 文件头是 PNG ✓ | 能上传到微信 ✓
HTML：字符数 > 1000 ✓ | 含 <html> ✓
MIME：Content-Type 与文件扩展名匹配 ✓
```

---

*v1.0.0 | 2026-04-05*
