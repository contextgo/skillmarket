# 公众号自动化发布 — 环境配置指南

## 快速开始

### 1. 安装依赖

```bash
# Node.js >= 18（检查版本）
node --version

# bun（用于 baoyu-md-to-html）
npm install -g bun

# Python 3（用于封面图备用方案）
python --version
```

### 2. 安装 Skill

```bash
openclawmp install skill/@<author>/wechat-article-factory
```

### 3. 配置微信公众号

#### 获取 AppID 和 AppSecret

1. 登录 [微信公众平台](https://mp.weixin.qq.com)
2. 「设置与开发」→「基本配置」
3. 记录 AppID 和 AppSecret

#### 设置 IP 白名单

1. 同上页面，找到「IP白名单」
2. 添加 WorkBuddy 出口 IP（运行 `curl ifconfig.me` 查看）

#### 获取 Access Token（手动测试）

```bash
curl "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=YOUR_APPID&secret=YOUR_SECRET"
```

返回 `{ "access_token": "...", "expires_in": 7200 }` 即成功。

### 4. 配置封面图（可选）

封面图生成会自动 fallback：
- AI 绘图 → PowerShell → SVG

如需指定固定封面：
```bash
export WECHAT_COVER_PATH=/path/to/your/cover.png
```

### 5. 运行测试

```bash
# 完整流水线
node scripts/run-factory.mjs --topic="AI Agent 工作流的最新进展"

# 指定模块
node scripts/run-factory.mjs --modules=s2_titles,s3_outline

# 从快照恢复
node scripts/run-factory.mjs --session=<sessionId> --resume
```

## 依赖清单

| 依赖 | 版本 | 用途 | 安装 |
|------|------|------|------|
| Node.js | >= 18 | 运行时 | nodejs.org |
| bun | latest | TS/依赖 | `npm i -g bun` |
| Python | 3.x | 备用封面生成 | python.org |
| PowerShell | 5.1+ | 封面图生成 | 系统自带 |

## 常见问题

**Q: 提示 access_token 过期**
A: Token 有效期 2 小时，流水线会自动刷新。如频繁失效，检查服务器时间是否准确。

**Q: 封面图上传失败 40113**
A: 确认文件格式与扩展名一致（PNG 用 .png，WebP 用 .webp）。参考 troubleshooting.md。

**Q: 报 "由于技术原因，此域名…"**
A: 微信 API 在部分地区有访问限制，建议使用与公众号注册地一致的服务器。

---

*v1.0.0 | 2026-04-05*
