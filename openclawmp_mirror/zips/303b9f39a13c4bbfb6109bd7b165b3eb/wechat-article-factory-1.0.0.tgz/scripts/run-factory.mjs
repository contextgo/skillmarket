/**
 * wechat-article-factory - 公众号文章自动化工厂
 *
 * 工作目录：{skill_root}/scripts/
 * 依赖：{workspace}/src/content-factory/
 *
 * CLI 参数：
 *   --topic=xxx        跳过 s1，直接以 xxx 为主題
 *   --modules=a,b,c   只运行指定模块
 *   --resume           从快照恢复
 *   --clear            清除快照并退出
 *   --session=xxx      指定会话 ID
 *   --workspace=xxx   指定工作区路径（默认取父目录的父目录）
 */
import { parseArgs } from 'util';
import { existsSync, mkdirSync, writeFileSync, readFileSync, copyFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { randomUUID } from 'crypto';

const __dirname = dirname(fileURLToPath(import.meta.url));
const SKILL_ROOT = __dirname;

// 默认工作区：scripts/ → ../../
const DEFAULT_WORKSPACE = join(SKILL_ROOT, '..', '..');
const OUT_DIR = join(SKILL_ROOT, '..', '..', 'memory', 'content-factory', new Date().toISOString().slice(0, 10));

function log(...args) {
  const ts = new Date().toISOString().slice(11, 19);
  console.error(`[${ts}] ${args.join(' ')}`);
}

const { values: args } = parseArgs({
  options: {
    topic: { type: 'string' },
    modules: { type: 'string' },
    resume: { type: 'boolean', default: false },
    clear: { type: 'boolean', default: false },
    session: { type: 'string' },
    workspace: { type: 'string' },
  },
  allowPositionals: false,
});

const WORKSPACE = args.workspace || DEFAULT_WORKSPACE;
const PIPELINE_FILE = join(WORKSPACE, 'src', 'content-factory', 'pipeline.js');

let ContentPipeline;
try {
  ({ ContentPipeline } = await import(`file://${PIPELINE_FILE}`));
} catch (e) {
  log(`\u274c 无法加载流水线模块`);
  log(`   工作区: ${WORKSPACE}`);
  log(`   期望路径: ${PIPELINE_FILE}`);
  log(`   提示: 使用 --workspace 参数指定正确工作区`);
  process.exit(1);
}

const sessionId = args.session || randomUUID();
mkdirSync(OUT_DIR, { recursive: true });

function getModulesToRun() {
  if (args.modules) return args.modules.split(',').map(m => m.trim());
  return null;
}

function setupPipeline(pipeline) {
  pipeline.on('module_start', ({ module }) => log(`\u25b6\ufe0f ${module}`));
  pipeline.on('module_done', ({ module, ctx }) => {
    const elapsed = ctx.elapsed ? `(${(ctx.elapsed() / 1000).toFixed(1)}s)` : '';
    log(`\u2705 ${module} ${elapsed}`);
  });
  pipeline.on('module_error', ({ module, error }) => log(`\u274c ${module}: ${error.message}`));
  pipeline.on('pipeline_error', ({ module, error }) => log(`\u{1F6A8} 流水线中断（${module}）: ${error.message}`));
}

async function main() {
  log('═══════════════════════════════════════');
  log('\ud83d\udce6 \u516c\u4f17\u53f7\u6587\u7ae0\u5de5\u5382 \u2014 \u6d41\u6c34\u7ebf\u6267\u884c');
  log(`   Workspace: ${WORKSPACE}`);
  log(`   Session:   ${sessionId.slice(0, 8)}...`);
  log('═══════════════════════════════════════');

  const pipeline = new ContentPipeline(sessionId);
  setupPipeline(pipeline);

  if (args.clear) {
    log('\ud83d\uddd1\ufe0f \u6e05\u9664\u5feb\u7167');
    const snapFile = join(WORKSPACE, 'src', 'content-factory', 'snapshots', `${sessionId}.json`);
    if (existsSync(snapFile)) {
      const { unlinkSync } = await import('fs');
      unlinkSync(snapFile);
      log('\u2705 \u5feb\u7167\u5df2\u6e05\u9664');
    }
    process.exit(0);
  }

  const modules = getModulesToRun();
  const topic = args.topic;

  if (args.resume) {
    log('\ud83d\udd04 \u4ece\u5feb\u7167\u6062\u590d...');
    try {
      const results = await pipeline.resume();
      log('\u2705 \u6062\u590d\u6210\u529f');
      return;
    } catch (e) {
      log(`\u26a0\ufe0f \u6062\u590d\u5931\u8d25\uff08${e.message}\uff09\uff0c\u6539\u4e3a\u6b63\u5e38\u6267\u884c`);
    }
  }

  if (topic) {
    log(`\ud83d\udcdd \u4e3b\u9898\u6a21\u5f0f: "${topic}"\uff08\u8df3\u8fc7 s1\uff09`);
    pipeline.ctx.data = pipeline.ctx.data || {};
    pipeline.ctx.data.s1_hotspot = {
      hotspots: [{ title: topic, source: 'user_topic', url: '', time: new Date().toISOString() }],
      ok: true,
    };
  }

  const t0 = Date.now();
  let results;

  try {
    if (modules) {
      log(`\ud83c\udfaf \u6a21\u5757: ${modules.join(' \u2192 ')}`);
      results = await pipeline.run(modules);
    } else {
      log('\ud83d\ude80 \u5168\u6d41\u7a0b: s1 \u2192 s2 \u2192 s3 \u2192 s4 \u2192 s5 \u2192 s6');
      results = await pipeline.run();
    }
  } catch (e) {
    log(`\u{1F6A8} \u6d41\u6c34\u7ebf\u5f02\u5e38: ${e.message}`);
    process.exit(1);
  }

  const totalMs = Date.now() - t0;
  log('');
  log('═══════════════════════════════════════');
  log(`\u2705 \u5b8c\u6210\uff0c\u8017\u65f6 ${(totalMs / 1000).toFixed(1)}s`);
  log('═══════════════════════════════════════');

  if (results.s6_publish?.media_id) log(`\ud83d\udce4 media_id: ${results.s6_publish.media_id}`);
  if (results.s5_cover?.coverPath) log(`\ud83d\uddbc \u5c01\u9762: ${results.s5_cover.coverPath}`);
  if (results.s4_article?.article) log(`\ud83d\udcdd \u6b63\u6587: ${results.s4_article.article.length} \u5b57`);
  log('');
  log(`\ud83d\udcbe \u7ed3\u679c\u76ee\u5f55: ${OUT_DIR}/${sessionId}/`);
}

main().catch(e => { log(`\u274c \u672a\u6355\u83b7\u5f02\u5e38: ${e.message}`); process.exit(1); });
