Add-Type -AssemblyName System.Drawing
param(
    [string]$OutputPath = "cover.png",
    [string]$Title = "Article Cover",
    [string]$Subtitle = ""
)
$W = 900; $H = 383
$bitmap = New-Object System.Drawing.Bitmap($W, $H)
$g = [System.Drawing.Graphics]::FromImage($bitmap)
$g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
$g.TextRenderingHint = [System.Drawing.Text.TextRenderingHint]::AntiAlias
$bg = [System.Drawing.Color]::FromArgb(255, 10, 22, 40)
$g.Clear($bg)
# Grid lines
$pen = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(30, 80, 120), 1)
for ($i = 0; $i -lt 14; $i++) {
    $y = 25 + $i * 26
    $g.DrawLine($pen, 0, $y, $W, $y)
}
$pen.Dispose()
# Accent circle
$pen2 = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(20, 100, 160), 50)
$g.DrawEllipse($pen2, ($W - 300), -50, 400, 400)
$pen2.Dispose()
# Divider
$pen3 = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(0, 212, 255), 3)
$g.DrawLine($pen3, [int]($W/2 - 220), [int]($H/2 - 50), [int]($W/2 + 220), [int]($H/2 - 50))
$pen3.Dispose()
# Fonts
try {
    $font1 = New-Object System.Drawing.Font("Microsoft YaHei", 28, [System.Drawing.FontStyle]::Bold)
    $font2 = New-Object System.Drawing.Font("Microsoft YaHei", 20, [System.Drawing.FontStyle]::Bold)
    $font3 = New-Object System.Drawing.Font("Microsoft YaHei", 13)
} catch {
    $font1 = New-Object System.Drawing.Font("Arial", 28, [System.Drawing.FontStyle]::Bold)
    $font2 = New-Object System.Drawing.Font("Arial", 20, [System.Drawing.FontStyle]::Bold)
    $font3 = New-Object System.Drawing.Font("Arial", 13)
}
$sf = New-Object System.Drawing.StringFormat
$sf.Alignment = [System.Drawing.StringAlignment]::Center
$sf.LineAlignment = [System.Drawing.StringAlignment]::Center
# Title
$rect1 = New-Object System.Drawing.RectangleF(0, [int]($H/2 - 60), $W, 50)
$g.DrawString($Title, $font1, [System.Drawing.Brushes]::White, $rect1, $sf)
# Subtitle
if ($Subtitle) {
    $rect2 = New-Object System.Drawing.RectangleF(0, [int]($H/2 - 5), $W, 45)
    $cyan = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(0, 212, 255))
    $g.DrawString($Subtitle, $font2, $cyan, $rect2, $sf)
    $cyan.Dispose()
}
# Watermark
$rect3 = New-Object System.Drawing.RectangleF(0, [int]($H - 55), $W, 30)
$tagBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(180, 0, 212, 255))
$g.DrawString("AI Writing | Workflow Automation | Productivity", $font3, $tagBrush, $rect3, $sf)
$tagBrush.Dispose()
$g.Dispose()
$font1.Dispose(); $font2.Dispose(); $font3.Dispose()
# Save
$outDir = [System.IO.Path]::GetDirectoryName($OutputPath)
if (-not [System.IO.Directory]::Exists($outDir)) {
    New-Item -ItemType Directory -Path $outDir -Force | Out-Null
}
$bitmap.Save($OutputPath, [System.Drawing.Imaging.ImageFormat]::Png)
$bitmap.Dispose()
Write-Host "DONE: $OutputPath"
