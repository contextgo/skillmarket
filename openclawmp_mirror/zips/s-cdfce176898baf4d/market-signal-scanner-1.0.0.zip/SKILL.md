---
name: market-signal-scanner
description: "Automated market signal detection and scoring from multiple news sources for prediction market trading"
version: 1.0.0
---

# Market Signal Scanner

Scan multiple news sources for market-moving signals and score them for prediction market positions.

## When to Use

When you need to assess current market conditions for prediction markets (Polymarket, Kalshi, Metaculus, etc.).

## Process

### Step 1: Define Markets
List the prediction markets you're monitoring:
```
1. Oil $90+ (geopolitical)
2. Bitcoin $100K
3. Ethereum $5K
4. [Custom markets...]
```

### Step 2: Aggregate News
Fetch from multiple sources in parallel:
- Use `web_fetch` for known news URLs
- Use `web_search` for broad queries (mind daily quota)
- Prioritize: geopolitics, crypto, macro, regulatory

### Step 3: Score Signals
For each news item:
1. **Relevance**: Does it directly affect any monitored market? (1-5)
2. **Magnitude**: How significant is the impact? (1-5)
3. **Confirmation**: How many sources report it? (1-5)
4. **Direction**: Bullish (+1) or Bearish (-1)?

### Step 4: Aggregate
```
Market Confidence = Σ(Score_i) / (Max_Score × N)
```

### Step 5: Report
Format output as:
```
📊 Market Signal Report [Timestamp]
━━━━━━━━━━━━━━━━━━━━━━━━
🏆 [Market Name]: XX.X% (↑/↓/→)
   Signals: N items
   Key: [Most impactful signal]
   Risk: [Main risk factor]
```

## Output Format

```markdown
### 📊 Signal Summary
| Market | Confidence | Signals | Trend | Key Driver |
|--------|-----------|---------|-------|------------|
| Oil $90 | 100% | 18 | → | Hormuz closure |
| BTC $100K | 82.5% | 5 | ↑ | Safe haven demand |
```

## Tips

- Always check at least 4 different sources
- Track signal count changes between rounds
- Watch for de-escalation signals that reverse sentiment
- Note API quota usage to avoid running out mid-scan
