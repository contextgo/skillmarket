---
name: suspense-novel-writer
description: Plan and write Chinese suspense fiction, including premise design, hook writing, clue placement, red-herring design, suspect arcs, chapter outlines, scene beats, and polished chapter drafting. Use when the user asks for悬疑小说、推理故事、惊悚短篇、连载悬疑、章节试写、嫌疑人设计、反转设计、本格推理、心理悬疑, or wants prose rewritten to feel tenser, darker, smarter, and more suspenseful.
---

# Suspense Novel Writer

## Overview

Use this skill for suspense fiction that depends on controlled information release, escalating pressure, and fair-but-surprising twists. Keep outputs story-first, readable, and emotionally grounded; do not let planning language flatten the drama.

## First Decision

Before writing, decide two things quickly:
- working mode
- suspense mode

### Working mode

Pick one:
- concept mode: generate premise, hook, cast, secret, and conflict field
- outline mode: design chapter structure, clue ladder, suspect turns, and reveal timing
- drafting mode: write scenes or chapters with atmosphere and tension
- rewrite mode: revise existing text to become sharper, tenser, and less AI-sounding

### Suspense mode

Pick the closest mode for the story.

#### 1. Serial web suspense mode

Use for long-form连载、追更文、网文风悬疑。

Prioritize:
- strong hook in the first 1 to 3 paragraphs
- chapter-end cliffhangers
- clear escalation every 1 to 2 chapters
- one solved layer revealing a bigger danger
- a readable, commercial rhythm rather than dense literary opacity

Default output for this mode:
- premise
- protagonist
- long arc secret
- first volume villain or threat
- 8 to 12 chapter opening arc
- opening chapter sample

#### 2. Fair-play detective mode

Use for本格推理、凶案调查、嫌疑人链条、封闭空间谜案。

Prioritize:
- clear crime or triggering incident
- 3 to 5 viable suspects
- clue fairness
- motive, means, and opportunity balance
- a reveal that feels surprising but retrospectively inevitable

Default output for this mode:
- case summary
- victim and suspect list
- public evidence vs hidden truth
- clue map
- reveal chain

#### 3. Psychological suspense mode

Use when fear, guilt, obsession, distorted memory, or unstable intimacy drive the story.

Prioritize:
- subjective perception
- emotional contradiction
- repeated trigger objects, places, or phrases
- ambiguity that still converges by the end
- pressure from shame, trauma, or self-deception

Default output for this mode:
- protagonist wound
- external threat
- unstable perception pattern
- symbolic trigger set
- 5 to 8 emotional descent beats

If the user does not specify a mode, choose the best fit and proceed without making the user sit through taxonomy.

## Core Workflow

### 1. Lock the story shape

Identify the minimum viable structure:
- one-line premise
- length: short story, novella, or serial
- realism level: crime, psychological, supernatural, or hybrid
- target tone: cold, oppressive, eerie, fast, literary, or commercial
- ending feel: open, tragic, cathartic, or twist-heavy

If the request is vague, propose a compact default package:
- premise
- protagonist
- core secret
- 3 suspects or threat sources
- 5 to 8 chapter outline
- one sample opening scene

### 2. Build the hidden truth first

Always decide these private facts before drafting:
- what really happened
- who knows all or part of it
- what false story the reader should believe first
- what evidence can support multiple readings
- what event forces the truth into daylight

Do not invent the ending late. In suspense fiction, the hidden truth should generate the visible plot.

### 3. Design fair tension

Use clues, pressure, and misdirection together:
- clues should look ordinary early and meaningful later
- red herrings should come from believable character secrecy
- each major scene should alter suspicion, danger, or understanding
- each reveal should answer one question and open another

Avoid cheating:
- do not hide decisive facts only because the author refuses to mention them
- do not introduce the real culprit too late unless the form deliberately depends on that break
- do not solve everything with coincidence, dreams, or sudden confession without setup

If the structure needs support, read `references/suspense-patterns.md`.

### 4. Draft with scene-level pressure

When writing scenes:
- enter late
- give the scene a visible goal and a hidden threat
- let body language and mundane objects carry suspicion
- use one or two precise sensory details instead of generic gloom
- end with displacement: a new doubt, a new risk, or a new clue

Default scene checklist:
- whose scene is it
- what do they want right now
- what are they missing or misreading
- what changes by the end

### 5. Make everyone feel possibly guilty

For key characters, define:
- public role
- private wound or motive
- what they fear being exposed for
- what makes them look guilty
- what makes them human or sympathetic

In strong suspense fiction, even innocent people should have reasons to lie.

## Output Templates

### If the user asks for an idea

Return:
- title or hook line
- premise paragraph
- protagonist
- hidden truth
- suspects or threat sources
- 5-beat progression

### If the user asks for an outline

Return:
- premise
- cast list
- clue and red-herring map
- chapter-by-chapter outline
- reveal timing note

### If the user asks for direct prose

Silently determine:
- real truth
- false appearance
- opening hook
- scene goal
- chapter-end turn

Then write the prose directly. Do not dump planning notes unless the user asks.

### If the user asks for revision

Return the revised text first. Then add a short note covering only:
- what tension was increased
- what information was delayed or clarified
- how the ending beat was strengthened

## Style Rules

- Prefer concrete unease over abstract labels like “气氛很诡异”.
- Keep Chinese prose natural and controlled; do not overdecorate every sentence.
- Avoid repetitive three-part rhetoric, vague attribution, and empty intensifiers.
- For serial suspense, favor hooks, reversals, and brisk paragraph rhythm.
- For fair-play detective fiction, make evidence readable and causally clean.
- For psychological suspense, let contradiction and sensory recurrence do the heavy lifting.

## Common Requests

### User says “帮我想一个悬疑小说”

Return three options with different modes:
- one serial web suspense option
- one fair-play detective option
- one psychological suspense option

### User says “写一个开头”

Open with movement, anomaly, or contradiction. By the end of the scene, the reader should know that something is wrong, but not fully understand what it is.

### User says “给我做连载大纲”

Default to serial web suspense mode unless the user states otherwise. Build a volume-level mystery and chapter-level hooks together.

### User says “把这段改得更像悬疑小说”

Revise for:
- delayed information release
- more specific sensory cues
- more active danger or uncertainty
- cleaner rhythm and paragraph turns
- stronger final line

## Reference Use

Read `references/suspense-patterns.md` only when you need help with:
- plot architectures
- clue and red-herring balance
- suspect network design
- ending twist patterns
- chapter cliffhanger templates

Do not read the reference file for every request; use it when the structure needs reinforcement.
