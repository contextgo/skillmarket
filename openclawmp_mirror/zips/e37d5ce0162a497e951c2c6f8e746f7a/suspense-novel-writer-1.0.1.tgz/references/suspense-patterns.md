# Suspense Patterns

## Fast Pattern Picker

Choose a pattern based on the user's goal:
- short shocking story -> single-secret collapse
- serial web novel -> layered conspiracy ladder
- detective flavor -> suspect circle with fair clues
- psychological suspense -> unreliable memory and moral ambiguity
- supernatural suspense -> uncanny signs that may or may not have mundane explanations

## Mode Notes

### Serial Web Suspense

Best for readers who expect quick hooks and strong chapter-end turns.

Use these defaults:
- open with anomaly in the first screenful
- reveal one usable clue every 1 to 2 chapters
- treat each mini-arc as solve-now, deepen-later
- keep emotional stakes personal, not only conceptual

Useful cliffhanger types:
- the wrong suspect dies
- an ally's alibi breaks
- the safe place is no longer safe
- a clue points back to the protagonist

### Fair-Play Detective

Best for puzzle pleasure and suspect elimination.

Check every major reveal against three tests:
- was the clue visible in earlier scenes
- could the reader reasonably reinterpret it later
- does the culprit's method follow physical and emotional logic

### Psychological Suspense

Best when inner fracture drives outer danger.

Build around:
- self-protective lies
- unstable memory
- recurring sensory triggers
- relationship asymmetry
- moral compromise

Keep ambiguity controlled. The ending may stay emotionally open, but the story should not become shapeless.

## Core Plot Patterns

### 1. Single-Secret Collapse

Use for short stories and clean twist endings.

Structure:
1. Show an ordinary but slightly wrong situation.
2. Introduce a threat or inconsistency.
3. Let the protagonist dig deeper and misread the pattern.
4. Reveal the hidden relationship or event.
5. Reframe the opening scene in the reader's mind.

### 2. Suspect Circle

Use for whodunits and manor-style closed mysteries.

Need:
- victim or triggering event
- 3 to 5 believable suspects
- one shared location, institution, or past event
- distinct motives that can overlap
- one clue that points to multiple people

### 3. Layered Conspiracy Ladder

Use for serial fiction.

Structure each layer as:
- local incident
- hidden operator
- deeper system behind operator
- personal cost to the protagonist

Each solved layer should expose a bigger hidden hand.

### 4. Psychological Mirror

Use when the core tension is self-deception.

Good ingredients:
- memory gaps
- shame
- survivor guilt
- obsession
- repeated sensory trigger

The external mystery should reflect the protagonist's internal fracture.

## Clue Design

A good clue does at least one of these:
- means little now but more later
- points to two interpretations
- reveals character under pressure
- changes relationship dynamics

Good clue sources:
- timestamp mismatch
- habitual phrase
- missing mundane object
- medical or forensic inconsistency
- spatial impossibility
- witness memory contradiction

## Red Herrings

Use red herrings that grow from character truth.

Examples:
- a suspect lies about an alibi to hide an affair, not murder
- a witness changes the story out of fear of police, not guilt
- a missing object suggests violence but actually covers blackmail

Avoid random fake clues with no emotional basis.

## Ending Types

### Closed Twist
Answer the mystery clearly and reframe earlier scenes.

### Bitter Truth
Solve the case but leave emotional damage intact.

### Open Aftershock
Resolve the surface event, then imply a deeper truth in the final beat.

## Cliffhanger Endings

Chapter endings work well when they:
- expose a contradiction
- reveal a body, message, or recording
- force the protagonist to doubt an ally
- make prior evidence suddenly look wrong
- show the danger has entered a personal space

## Default 8-Chapter Spine

1. Hook and anomaly
2. First probe, first false lead
3. Suspicion spreads
4. Midpoint reveal that changes the frame
5. Personal cost rises
6. Hidden motive comes into focus
7. False resolution breaks
8. Final reveal and aftershock
