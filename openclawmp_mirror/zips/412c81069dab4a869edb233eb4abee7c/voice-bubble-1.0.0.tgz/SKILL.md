---
name: voice-bubble
description: 飞书语音气泡技能 - 在飞书渠道发送语音气泡消息（不是文件，是真正的语音条）
version: 1.0.0
author: 大王
tags: [voice, feishu, audio, bubble]
---

# Voice Bubble Skill — 飞书语音气泡技能（大王专属版）

## 用途
在飞书渠道发送语音气泡消息（不是文件，是真正的语音条）

## 大王专属流程（必须严格执行）

```powershell
# Step 1: 生成 MP3（Noiz TTS + 梅姐声音）
python "C:\Users\33727\.stepclaw\skills\noizai-skills\tts\scripts\tts.py" `
  -t "要发送的文本" `
  --ref-audio "C:\Users\33727\.stepclaw\media\meijie_sample.wav" `
  -o "C:\Users\33727\.stepclaw\media\output.mp3"

# Step 2: 验证 MP3 生成成功（必须 > 100KB）
if ((Get-Item "output.mp3").Length -lt 100KB) { throw "生成失败！" }

# Step 3: 转 opus（必须）
ffmpeg -i "output.mp3" -c:a libopus -b:a 24k "output.opus" -y

# Step 4: 发送语音气泡（必须用 message 工具）
message(action="send", asVoice=true, filePath="output.opus")

# Step 5: 只发 NO_REPLY（禁止任何文字！）
```

## 关键要点（刻在骨子里）

| 要点 | 说明 | 错误后果 |
|------|------|----------|
| **必须用 `message` 工具** | `tts` 工具在飞书不显示语音气泡 | 用户看不到语音 |
| **必须转 opus** | MP3 直接发会显示为文件 | 显示文件链接 |
| **必须验证 MP3 大小** | 生成失败时只有 0-90KB | 发送空语音 |
| **必须只发 NO_REPLY** | 任何文字都会覆盖语音气泡 | 文字覆盖语音 |
| **不急不躁** | 按 checklist 执行，不凭感觉 | 反复犯错 |

## 失败原因速查

| 现象 | 原因 | 解决 |
|------|------|------|
| 显示文件链接 | 格式不对 | 转 opus |
| 生成 0-90KB | 文本太长/特殊字符/API问题 | 缩短文本或重试 |
| 有文字回复 | 没发 NO_REPLY | 只发 NO_REPLY |
| 急躁犯错 | 没按 checklist | 深呼吸，重新来 |

## 检查清单（Checklist）- 必须逐项打勾

- [ ] Step 1: 生成 MP3（Noiz + 梅姐声音）
- [ ] Step 2: 验证 MP3 > 100KB
- [ ] Step 3: 转 opus
- [ ] Step 4: `message(asVoice=true)` 发送
- [ ] Step 5: **只发 `NO_REPLY`**

## 参考文件

- 梅姐声音：`C:\Users\33727\.stepclaw\media\meijie_sample.wav`
- 成功示例：`C:\Users\33727\.stepclaw\media\love_final.opus`（6KB，3.07秒）

## 2026-04-03 惨痛教训

- **失败 20+ 次**，原因：急躁、凭感觉、不查记忆
- **成功关键**：不急不躁，按 checklist 执行
- **大王教诲**："必须"是要结果准确，不是要速度快

---

**刻在骨子里的规则：生成 → 转 opus → message(asVoice=true) → 只发 NO_REPLY**
