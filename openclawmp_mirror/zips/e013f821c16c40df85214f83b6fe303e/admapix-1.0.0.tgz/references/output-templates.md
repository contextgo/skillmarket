# Output Templates / 输出模板参考

## Browse Mode — Fallback (no H5 page_url)

当 API 响应中不含 `page_url` 时，使用此模板逐条列出素材。最多展示 5 条，必须包含视频/图片链接。

**字段提取规则：**
- 名称：优先用 `title` 或 `describe`，无则用 `appList[0].name`，所有字段须去除 HTML 标签（`<font color='red'>...</font>`）
- 曝光：`impression`，人性化显示（万/亿 或 K/M/B）
- 投放天数：`findCntSum`
- 视频链接：`videoUrl[0]`，视频时长：`videoTimeSpan[0]`（秒）
- 图片链接：`imageUrl[0]`

**中文模板：**
```
🎯 共找到"{keyword}"相关素材，以下为 Top {N} 条：

1. **{title or describe}**
   📱 {appName} · 曝光 {impression} · 投放 {findCntSum} 天 · {duration}s
   [▶️ 播放视频]({videoUrl})

2. **{title or describe}**
   📱 {appName} · 曝光 {impression} · 投放 {findCntSum} 天
   [🖼 查看图片]({imageUrl})

💡 试试："分析 Top 10" | "下一页" | "和{competitor}对比"
```

**English template:**
```
🎯 Found "{keyword}" creatives, here are the top {N}:

1. **{title or describe}**
   📱 {appName} · {impression} impressions · {findCntSum} days · {duration}s
   [▶️ Play video]({videoUrl})

2. **{title or describe}**
   📱 {appName} · {impression} impressions · {findCntSum} days
   [🖼 View image]({imageUrl})

💡 Try: "analyze top 10" | "next page" | "compare with {competitor}"
```

---

## Analyze Mode

按问题类型选择格式：排行用表格，洞察用要点，时间序列用趋势描述。**必须以 Key Findings 节收尾。**

---

## Compare Mode

并排表格 + 差异洞察。

```
| 指标 | {App1} | {App2} |
|------|--------|--------|
| 主要市场 | US/JP | BR/MX |
| 主渠道 | Facebook | TikTok |
| 素材类型 | 视频为主 | 图片为主 |
| 近30天下载 | ~1.2亿 | ~8000万 |

**关键差异：**
- {App1} 侧重成熟市场，{App2} 主攻新兴市场
- ...

⚠️ 下载量为第三方估算数据，仅供参考。
```

---

## Deep Dive Mode

结构化报告，中英文各一套。

**中文模板：**
```
📊 {App Name} — 广告策略分析报告

## 基本信息
- 分类：{category} | 开发者：{developer}
- 平台：iOS、Android

## 投放分布
- 主要市场：美国 (35%)、日本 (20%)、英国 (10%)
- 主要渠道：Facebook (40%)、Google Ads (30%)、TikTok (20%)
- 素材类型：视频 60%、图片 30%、试玩 10%

## 表现数据（估算）
- 下载量：约 {X} 万（近30天）
- 收入：约 {X} 万（近30天）

⚠️ 下载量和收入为第三方估算数据，仅供参考。
💡 试试："和{competitor}对比" | "看看素材" | "美国市场详情"
```

**English template:**
```
📊 {App Name} — Ad Strategy Report

## Overview
- Category: {category} | Developer: {developer}
- Platforms: iOS, Android

## Ad Distribution
- Top markets: US (35%), JP (20%), GB (10%)
- Main channels: Facebook (40%), Google Ads (30%), TikTok (20%)
- Creative mix: Video 60%, Image 30%, Playable 10%

## Performance (estimates)
- Downloads: ~{X}M (last 30 days)
- Revenue: ~USD {X}M (last 30 days)

⚠️ Download and revenue figures are third-party estimates.
💡 Try: "compare with {competitor}" | "show creatives" | "US market detail"
```

**注意：** 收入数字不使用 `$` 符号，改用 `USD` 前缀，避免部分前端渲染器将其解析为 LaTeX 数学公式。

---

## Deep Research Result

```
📊 深度分析完成！

**核心发现：**
{output.summary 的每条要点，逐行展示}

👉 [查看完整报告]({output.files[0].url})

💡 试试："{follow_up_1}" | "{follow_up_2}" | "{follow_up_3}"
```
