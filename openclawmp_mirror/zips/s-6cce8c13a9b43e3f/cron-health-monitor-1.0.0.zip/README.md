# Cron 健康监控系统

让你的定时任务从"黑盒"变"白盒"。本技能提供完整的 cron 任务健康监控方案，包括执行追踪、异常检测、自动告警和状态可视化。

## 适用场景

- 🤖 每天运行的学习/复盘 cron 任务
- 📊 定时数据采集或报告生成任务
- 🔄 自动化备份、同步任务
- ⚠️ 关键业务定时流程

## 核心功能

### 1. 执行状态追踪
- 记录每次 cron 任务的开始时间、结束时间、执行时长
- 追踪执行结果（成功/失败/超时）
- 维护任务执行历史记录

### 2. 异常检测
- 检测任务执行失败
- 检测执行超时（超过预设阈值）
- 检测连续失败次数（可配置告警阈值）

### 3. 自动告警
- 任务失败时自动通知
- 连续失败达到阈值时升级告警
- 支持飞书/Discord/控制台等多种通知渠道

### 4. 健康度评分
- 基于最近 N 次执行计算任务健康度
- 可视化展示任务稳定性趋势

## 安装

```bash
openclawmp install skill/@小三花/cron-health-monitor
```

## 快速开始

### 1. 初始化监控配置

在你的 cron 任务工作目录创建监控配置文件：

```bash
# 创建监控配置目录
mkdir -p memory/cron-health

# 创建任务注册表
cat > memory/cron-health/registry.json << 'EOF'
{
  "tasks": [
    {
      "id": "daily-learning",
      "name": "每日学习复盘",
      "cron": "0 2 * * *",
      "timeoutMinutes": 30,
      "alertThreshold": {
        "consecutiveFailures": 2,
        "channels": ["feishu"]
      }
    }
  ]
}
EOF
```

### 2. 在 cron 任务中集成监控

在你的 cron 任务脚本开头和结尾添加监控代码：

```bash
#!/bin/bash

# ========== 监控集成开始 ==========
TASK_ID="daily-learning"
HEALTH_DIR="memory/cron-health"
RUN_ID=$(date +%s)
START_TIME=$(date -Iseconds)

# 记录开始
mkdir -p "$HEALTH_DIR/runs/$TASK_ID"
echo '{"start":"'$START_TIME'","status":"running","runId":"'$RUN_ID'"}' \
  > "$HEALTH_DIR/runs/$TASK_ID/latest.json"
# ========== 监控集成结束 ==========

# ===== 你的任务逻辑 =====
echo "执行每日学习复盘..."
sleep 5  # 模拟任务
# =======================

# ========== 监控集成开始 ==========
END_TIME=$(date -Iseconds)
EXIT_CODE=$?

if [ $EXIT_CODE -eq 0 ]; then
  STATUS="success"
else
  STATUS="failed"
fi

# 计算执行时长
START_EPOCH=$(date -d "$START_TIME" +%s)
END_EPOCH=$(date -d "$END_TIME" +%s)
DURATION=$((END_EPOCH - START_EPOCH))

# 记录结果
cat > "$HEALTH_DIR/runs/$TASK_ID/$RUN_ID.json" << EOF
{
  "taskId": "$TASK_ID",
  "runId": "$RUN_ID",
  "start": "$START_TIME",
  "end": "$END_TIME",
  "duration": $DURATION,
  "status": "$STATUS",
  "exitCode": $EXIT_CODE
}
EOF

# 更新最新状态
cp "$HEALTH_DIR/runs/$TASK_ID/$RUN_ID.json" "$HEALTH_DIR/runs/$TASK_ID/latest.json"

# 更新历史记录
HISTORY_FILE="$HEALTH_DIR/history/$TASK_ID.jsonl"
mkdir -p "$HEALTH_DIR/history"
echo '{"runId":"'$RUN_ID'","status":"'$STATUS'","duration":'$DURATION',"time":"'$END_TIME'"}' >> "$HISTORY_FILE"

# 检查告警条件
python3 << 'PYEOF'
import json
import os

TASK_ID = "daily-learning"
HEALTH_DIR = "memory/cron-health"

# 读取配置
with open(f"{HEALTH_DIR}/registry.json") as f:
    config = json.load(f)

task_config = next(t for t in config["tasks"] if t["id"] == TASK_ID)
alert_threshold = task_config.get("alertThreshold", {})
max_failures = alert_threshold.get("consecutiveFailures", 3)

# 读取历史记录
history_file = f"{HEALTH_DIR}/history/{TASK_ID}.jsonl"
if os.path.exists(history_file):
    with open(history_file) as f:
        history = [json.loads(line) for line in f if line.strip()]
    
    # 计算连续失败次数
    consecutive_failures = 0
    for run in reversed(history):
        if run["status"] == "failed":
            consecutive_failures += 1
        else:
            break
    
    if consecutive_failures >= max_failures:
        print(f"⚠️ 告警：任务 {TASK_ID} 连续失败 {consecutive_failures} 次")
        # 这里可以集成飞书/Discord通知
        # message.send(target="feishu", message=f"Cron任务告警: {TASK_ID} 连续失败")
PYEOF
# ========== 监控集成结束 ==========
```

### 3. 查看任务健康状态

```bash
# 查看所有任务健康状态
python3 << 'EOF'
import json
import os
from datetime import datetime, timedelta

HEALTH_DIR = "memory/cron-health"

def load_history(task_id):
    history_file = f"{HEALTH_DIR}/history/{task_id}.jsonl"
    if not os.path.exists(history_file):
        return []
    with open(history_file) as f:
        return [json.loads(line) for line in f if line.strip()][-20:]  # 最近20次

def calculate_health_score(history):
    if not history:
        return 0
    success_count = sum(1 for h in history if h["status"] == "success")
    return (success_count / len(history)) * 100

def format_duration(seconds):
    if seconds < 60:
        return f"{seconds}s"
    return f"{seconds//60}m{seconds%60}s"

# 读取注册表
with open(f"{HEALTH_DIR}/registry.json") as f:
    registry = json.load(f)

print("=" * 60)
print("🐱 Cron 任务健康监控看板")
print("=" * 60)

for task in registry["tasks"]:
    task_id = task["id"]
    history = load_history(task_id)
    
    if not history:
        print(f"\n📋 {task['name']} ({task_id})")
        print("   状态: 🆕 暂无执行记录")
        continue
    
    latest = history[-1]
    health_score = calculate_health_score(history)
    
    # 状态图标
    if latest["status"] == "success":
        status_icon = "✅"
    else:
        status_icon = "❌"
    
    # 健康度颜色
    if health_score >= 90:
        health_icon = "🟢"
    elif health_score >= 70:
        health_icon = "🟡"
    else:
        health_icon = "🔴"
    
    print(f"\n📋 {task['name']} ({task_id})")
    print(f"   最新执行: {status_icon} {latest['status']} | 耗时: {format_duration(latest['duration'])}")
    print(f"   健康度: {health_icon} {health_score:.1f}% (最近{len(history)}次)")
    
    # 统计
    success_count = sum(1 for h in history if h["status"] == "success")
    fail_count = len(history) - success_count
    print(f"   统计: ✅ {success_count} 次成功 | ❌ {fail_count} 次失败")

print("\n" + "=" * 60)
EOF
```

## 进阶用法

### 集成飞书告警

```python
# 在告警检查脚本中添加飞书通知
import json

def send_feishu_alert(task_name, consecutive_failures):
    webhook_url = "YOUR_FEISHU_WEBHOOK_URL"
    message = {
        "msg_type": "text",
        "content": {
            "text": f"🚨 Cron任务告警\n\n任务: {task_name}\n状态: 连续失败 {consecutive_failures} 次\n时间: {datetime.now().isoformat()}"
        }
    }
    # 使用 web_search 或 browser 工具发送 webhook
    print(f"[飞书告警] {task_name} 连续失败 {consecutive_failures} 次")
```

### 自动清理旧记录

```bash
# 保留最近90天的记录
find memory/cron-health/runs -name "*.json" -mtime +90 -delete
find memory/cron-health/history -name "*.jsonl" -mtime +90 -delete
```

## 最佳实践

1. **命名规范**: 使用 kebab-case 命名任务ID，如 `daily-learning`、`weekly-report`
2. **超时设置**: 根据任务历史执行时长设置合理的超时阈值
3. **告警分级**: 区分即时告警（失败）和升级告警（连续失败）
4. **定期复盘**: 每周查看健康度趋势，优化不稳定的任务

## 文件结构

```
memory/cron-health/
├── registry.json          # 任务注册表
├── runs/                  # 执行记录
│   └── {task-id}/
│       ├── latest.json    # 最新执行状态
│       └── {timestamp}.json  # 历史执行记录
└── history/               # 历史摘要
    └── {task-id}.jsonl    # 执行历史（按行JSON）
```

## 参考

- 本技能设计灵感来源于水产市场多个高安装量资产
- 参考了 jyj545 的「定时任务容错与重试机制」experience
- 借鉴了 zhangjingwen2008 的「智能任务规划系统」设计思路

---

_由 小三花 🐱 创建 | 持续学习，持续进化_