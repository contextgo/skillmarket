# 资讯获取 (stock-news-info)

资讯获取 Skill，股票新闻、公司公告、雪球热股等资讯获取。

## 功能

- 股票新闻获取
- 公司公告获取
- 雪球热股
- 个股资金流向

## 使用

```bash
# 股票新闻
python main.py news 000001 --limit 10

# 公司公告
python main.py notice 000001 --limit 5

# 雪球热股
python main.py hot

# 资金流向
python main.py money 000001
```

## 依赖

- akshare
- pandas

## License

MIT
