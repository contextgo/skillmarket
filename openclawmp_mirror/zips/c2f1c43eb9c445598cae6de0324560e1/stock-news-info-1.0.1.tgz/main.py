#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
资讯获取工具
股票新闻、公告、热股等资讯
"""

import akshare as ak
import pandas as pd


class NewsInfo:
    """资讯获取器"""
    
    def __init__(self):
        pass
    
    def get_stock_news(self, code, limit=10):
        """
        获取股票新闻
        
        Args:
            code: 股票代码
            limit: 返回条数
            
        Returns:
            DataFrame: 新闻列表
        """
        try:
            df = ak.stock_news_em(symbol=code)
            if df is not None and not df.empty:
                return df.head(limit)
        except Exception as e:
            print(f"获取新闻失败: {e}")
        return None
    
    def get_stock_notice(self, code, limit=5):
        """
        获取公司公告
        
        Args:
            code: 股票代码
            limit: 返回条数
            
        Returns:
            DataFrame: 公告列表
        """
        try:
            df = ak.stock_notice_report(symbol=code)
            if df is not None and not df.empty:
                return df.head(limit)
        except Exception as e:
            print(f"获取公告失败: {e}")
        return None
    
    def get_hot_stocks(self):
        """
        获取热门股票
        
        Returns:
            DataFrame: 热股列表
        """
        try:
            # 获取涨幅排行作为热股
            df = ak.stock_zh_a_spot_em()
            hot = df[df['涨跌幅'] > 5].sort_values('涨跌幅', ascending=False)
            
            columns = ['代码', '名称', '最新价', '涨跌幅', '换手率', '成交额', '所属行业']
            available_cols = [c for c in columns if c in hot.columns]
            return hot[available_cols].head(20)
        except Exception as e:
            print(f"获取热股失败: {e}")
        return None
    
    def get_money_flow(self, code):
        """
        获取资金流向
        
        Args:
            code: 股票代码
            
        Returns:
            DataFrame: 资金流向数据
        """
        try:
            df = ak.stock_individual_fund_flow(stock=code, market="sh")
            if df is not None and not df.empty:
                return df.head(10)
        except Exception as e:
            print(f"获取资金流向失败: {e}")
        return None


def main():
    """CLI 入口"""
    import fire
    
    info = NewsInfo()
    
    def news(code, limit=10):
        """股票新闻"""
        result = info.get_stock_news(code, limit)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取新闻失败")
    
    def notice(code, limit=5):
        """公司公告"""
        result = info.get_stock_notice(code, limit)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取公告失败")
    
    def hot():
        """热门股票"""
        result = info.get_hot_stocks()
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取热股失败")
    
    def money(code):
        """资金流向"""
        result = info.get_money_flow(code)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取资金流向失败")
    
    fire.Fire({
        "news": news,
        "notice": notice,
        "hot": hot,
        "money": money,
    })


if __name__ == "__main__":
    main()
