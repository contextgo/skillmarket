---
name: auto-caff
description: "macOS 防休眠守护：插电自动禁止系统休眠，拔电自动恢复。确保 AI 助手 7×24h 在线不断联。适用于 Mac 部署 OpenClaw/Clawdbot 需要持续在线的场景。触发词：防休眠、caffeinate、合盖断联、always on。"
---

# Auto-Caff · macOS 防休眠守护

## 解决什么问题
Mac 合盖或待机后系统休眠，导致：
- AI 助手断联，消息收不到
- 定时任务（cron job）失效
- WebSocket 连接断开

## 工作原理
LaunchAgent 常驻后台，每 10 秒检测电源状态：
- **插电** → 自动启动 `caffeinate -ism`（禁止 idle/system/disk sleep）
- **拔电** → 自动停止 caffeinate，恢复系统休眠，保护电池

## 安装

### 1. 部署脚本
```bash
cp scripts/caff-monitor.sh ~/bin/caff-monitor.sh
chmod +x ~/bin/caff-monitor.sh
```

### 2. 安装 LaunchAgent
```bash
cp scripts/com.user.caffmonitor.plist ~/Library/LaunchAgents/
launchctl load ~/Library/LaunchAgents/com.user.caffmonitor.plist
```

### 3. 验证
```bash
# 确认进程运行
pgrep caffeinate && echo "✅ 防休眠已启动"
# 查看日志
tail -5 /tmp/caff-monitor.log
```

## 卸载
```bash
launchctl unload ~/Library/LaunchAgents/com.user.caffmonitor.plist
rm ~/Library/LaunchAgents/com.user.caffmonitor.plist
```
