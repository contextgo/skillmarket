#!/bin/bash
# Auto-Caff: 插电防休眠守护脚本
# 每 10 秒检测电源状态，插电时自动启动 caffeinate

PID_FILE="/tmp/auto_caff.pid"

echo "🔋 Power Monitor Started..."

while true; do
    if pmset -g ps | grep -q "AC Power"; then
        # 插电状态
        if [ -f "$PID_FILE" ] && ps -p $(cat "$PID_FILE") > /dev/null 2>&1; then
            : # 已在运行
        else
            echo "[$(date)] 🔌 Plugged in. Starting caffeinate..."
            caffeinate -ism &
            echo $! > "$PID_FILE"
        fi
    else
        # 电池状态
        if [ -f "$PID_FILE" ]; then
            PID=$(cat "$PID_FILE")
            echo "[$(date)] 🔋 Unplugged. Stopping caffeinate (PID $PID)..."
            kill $PID 2>/dev/null
            rm "$PID_FILE"
        fi
    fi
    sleep 10
done
