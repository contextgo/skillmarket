#!/usr/bin/env python3
"""
Web Browser - 网页内容提取
使用 aiohttp + BeautifulSoup
"""

import asyncio
import aiohttp
from bs4 import BeautifulSoup
from typing import Tuple, List, Dict, Optional
import urllib.parse


DEFAULT_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
    "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
    "Accept-Encoding": "gzip, deflate, br",
    "DNT": "1",
    "Connection": "keep-alive",
    "Upgrade-Insecure-Requests": "1",
}


async def fetch_page(url: str, timeout: int = 10, headers: Dict = None) -> Tuple[str, int]:
    """
    抓取网页

    Args:
        url: 网页URL
        timeout: 超时时间（秒）
        headers: 自定义请求头

    Returns:
        (html内容, HTTP状态码)
    """
    hdrs = headers or DEFAULT_HEADERS

    async with aiohttp.ClientSession() as session:
        try:
            async with session.get(url, headers=hdrs, timeout=timeout) as resp:
                html = await resp.text()
                return html, resp.status
        except aiohttp.ClientError as e:
            return f"网络错误: {e}", 0
        except asyncio.TimeoutError:
            return "请求超时", 0


def extract_title(html: str) -> str:
    """提取页面标题"""
    soup = BeautifulSoup(html, 'html.parser')
    if soup.title and soup.title.string:
        return soup.title.string.strip()
    return "无标题"


def extract_text(html: str, max_length: int = 5000) -> str:
    """
    提取页面正文文本
    移除script、style、nav、footer等非内容标签
    """
    soup = BeautifulSoup(html, 'html.parser')

    # 移除不需要的标签
    for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside', 'form', 'iframe']):
        tag.decompose()

    # 获取文本
    text = soup.get_text(separator='\n', strip=True)

    # 清理多余空行
    lines = [line.strip() for line in text.split('\n') if line.strip()]
    text = '\n'.join(lines)

    if len(text) > max_length:
        text = text[:max_length] + "..."
    return text


def extract_links(html: str, base_url: Optional[str] = None) -> List[Dict]:
    """
    提取页面中的所有链接

    Returns:
        [{'text': '链接文本', 'href': '绝对URL'}, ...]
    """
    soup = BeautifulSoup(html, 'html.parser')
    links = []

    for a in soup.find_all('a', href=True):
        href = a['href']
        text = a.get_text(strip=True) or href

        # 转换为绝对URL
        if base_url and not href.startswith(('http://', 'https://', 'mailto:', 'tel:')):
            href = urllib.parse.urljoin(base_url, href)

        links.append({'text': text, 'href': href})

    return links


async def get_page_summary(url: str, timeout: int = 10) -> Dict:
    """
    一步获取页面摘要

    Returns:
        {
            'url': 原始URL,
            'title': 页面标题,
            'text': 正文摘要,
            'links': 链接列表,
            'status': HTTP状态码,
            'error': 错误信息（如果有）
        }
    """
    html, status = await fetch_page(url, timeout=timeout)

    if status != 200:
        return {
            'url': url,
            'title': '',
            'text': '',
            'links': [],
            'status': status,
            'error': html if isinstance(html, str) and html.startswith(('网络错误', '请求超时')) else f"HTTP {status}"
        }

    title = extract_title(html)
    text = extract_text(html)
    links = extract_links(html, base_url=url)

    return {
        'url': url,
        'title': title,
        'text': text,
        'links': links,
        'status': status,
        'error': None
    }


def format_summary(summary: Dict, max_text: int = 300, max_links: int = 5) -> str:
    """格式化摘要为可读字符串"""
    if summary['error']:
        return f"❌ 访问失败: {summary['error']} (状态码: {summary['status']})"

    lines = [
        f"📄 {summary['title']}",
        f"🔗 {summary['url']}",
        "",
        summary['text'][:max_text] + ("..." if len(summary['text']) > max_text else ""),
        "",
        f"✅ 提取链接: {len(summary['links'])} 个"
    ]

    if summary['links']:
        lines.append("📎 主要链接:")
        for link in summary['links'][:max_links]:
            lines.append(f"  • {link['text'][:50]}: {link['href']}")

    return "\n".join(lines)


# 命令行测试
if __name__ == "__main__":
    async def test():
        url = input("输入URL: ") or "https://example.com"
        print(f"\n🔍 抓取: {url}\n")
        summary = await get_page_summary(url)
        print(format_summary(summary))

    asyncio.run(test())
