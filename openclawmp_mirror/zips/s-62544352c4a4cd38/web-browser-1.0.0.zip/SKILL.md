---
name: web-browser
description: "Fetch and extract content from web pages. Uses aiohttp + BeautifulSoup. Can get page title, text content, links, images."
metadata:
  openclaw:
    emoji: "🌐"
    requires:
      bins: ["python3"]
      packages: ["aiohttp", "beautifulsoup4"]
---

# Web Browser Skill

获取网页内容（无需浏览器GUI，适合服务器环境）。

## 功能

- ✅ 抓取网页HTML
- ✅ 提取标题、正文、链接
- ✅ 过滤脚本和样式
- ✅ 支持自定义User-Agent
- ✅ 超时和错误处理

## 安装依赖

```bash
pip3 install aiohttp beautifulsoup4
```

## 使用

### 基本用法

```python
from web_browser import fetch_page, extract_links, extract_text

# 1. 获取页面
html, status = await fetch_page("https://example.com")

# 2. 提取标题
title = extract_title(html)

# 3. 提取正文文本
text = extract_text(html)

# 4. 提取所有链接
links = extract_links(html, base_url="https://example.com")
```

### 一步到位

```python
from web_browser import get_page_summary

summary = await get_page_summary("https://news.example.com/article")
print(f"标题: {summary['title']}")
print(f"摘要: {summary['text'][:200]}...")
print(f"链接数: {len(summary['links'])}")
```

## 函数参考

### `fetch_page(url: str, timeout: int = 10) -> Tuple[str, int]`

抓取网页，返回 (html, status_code)

### `extract_title(html: str) -> str`

提取页面标题

### `extract_text(html: str, max_length: int = 5000) -> str`

提取纯文本（移除script、style等）

### `extract_links(html: str, base_url: str = None) -> List[Dict]`

提取链接，返回 `[{'text': '...', 'href': '...'}, ...]`

### `get_page_summary(url: str, timeout: int = 10) -> Dict`

一步获取页面摘要（标题、文本、链接、状态码）

## 集成到OpenClaw

```python
from web_browser import get_page_summary

async def handle_message(raw_msg):
    if "查看网页" in raw_msg["content"]:
        # 提取URL
        url = extract_url(raw_msg["content"])
        if not url:
            return "请提供网页URL"

        summary = await get_page_summary(url)
        if summary['status'] != 200:
            return f"❌ 无法访问: HTTP {summary['status']}"

        response = f"📄 {summary['title']}\n\n{summary['text'][:300]}...\n\n✅ 共提取 {len(summary['links'])} 个链接"
        return response
```

## 示例输出

```
📄 Example Domain

This domain is for use in illustrative examples in documents. You may use this domain in literature without prior coordination or...

✅ 共提取 1 个链接
```

## 注意事项

- ⚠️ 遵守目标网站的robots.txt
- ⚠️ 不要频繁请求（建议间隔≥2秒）
- ⚠️ 有些网站需要JavaScript渲染（本工具仅获取静态HTML）
- ✅ 支持HTTP/HTTPS
- ✅ 自动处理重定向

## 故障排除

| 问题 | 原因 | 解决 |
|------|------|------|
| 403 Forbidden | 网站拒绝访问 | 添加更真实的User-Agent头 |
| 超时 | 网络慢或网站慢 | 增加timeout参数 |
| 乱码 | 编码问题 | 确保response.encoding正确 |
| 无内容 | 动态渲染 | 需要Selenium/Playwright（不在本技能范围） |

---

**这就是一个轻量级浏览器，适合大多数静态网页抓取。**
