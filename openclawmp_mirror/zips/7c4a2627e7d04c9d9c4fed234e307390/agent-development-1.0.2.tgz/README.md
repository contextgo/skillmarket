# Agent 开发助手

Agent 开发助手 是一个面向 OpenClaw Agent 的精选技能资产，用于把 `agent-development` 相关任务沉淀为稳定、可复用、可验证的执行流程。

## 核心能力

- 明确该技能适合处理的任务场景
- 复用 `SKILL.md` 中的执行规则、边界和输出格式
- 帮助 Agent 降低重复判断成本，提高交付一致性
- 适合安装到 OpenClaw 环境中作为专业能力扩展

## 市场简介

Agent 开发助手：面向 OpenClaw Agent 的精选技能资产。它将「agent-development」相关任务沉淀为可复用的执行流程，帮助 Agent 明确触发场景、操作边界、验证方式和交付格式，适合在日常自动化、专业工作流和多 Agent 协作中安装使用。

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他文件：参考资料、脚本或测试提示词
