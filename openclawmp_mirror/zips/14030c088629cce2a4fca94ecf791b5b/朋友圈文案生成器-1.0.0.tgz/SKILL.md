---
name: 朋友圈文案生成器
displayName: 朋友圈文案生成器
description: 根据课程亮点和学生成果，生成多条朋友圈文案，支持多种风格。
version: 1.0.0
author: OpenClaw Edu
tags: [education, social, wechat, marketing, content]
category: education
---

# 朋友圈文案生成器

生成教育机构朋友圈文案。

## 功能

- 课程亮点提取
- 多风格文案生成
- 励志型/幽默型/专业型
- 家长/学生双视角

## 使用

```
@朋友圈文案生成器 为这次竞赛获奖生成5条朋友圈文案
```
