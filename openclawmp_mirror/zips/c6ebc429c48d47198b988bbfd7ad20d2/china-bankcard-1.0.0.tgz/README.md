# china-bankcard - 中国银行卡号查询技能

## 安装状态
✅ **本地已安装** - 位于 `~/.openclaw/workspace/skills/china-bankcard/`

## 快速使用

### 方式 1: 自然语言查询
直接对我说：
- "查一下 6228480568087904070 是什么银行"
- "这张卡是信用卡还是借记卡？"
- "帮我验证银行卡号 6222021234567890"

### 方式 2: 命令行
```bash
python3 ~/.openclaw/workspace/skills/china-bankcard/bankcard_lookup.py 6228480568087904070
```

### 方式 3: Python 调用
```python
from skills.china_bankcard.bankcard_lookup import lookup_bankcard, format_result

result = lookup_bankcard("6228480568087904070")
print(format_result(result))
```

## 技能文件
```
~/.openclaw/workspace/skills/china-bankcard/
├── SKILL.md              # 技能说明文档
├── package.json          # NPM 风格配置（用于 ClawHub 发布）
├── bankcard_lookup.py    # 核心查询程序
└── __init__.py           # Python 模块入口
```

## 发布到 ClawHub（可选）
如需公开发布到 ClawHub 市场：

1. 登录 ClawHub
```bash
clawhub login
```

2. 发布技能
```bash
cd ~/.openclaw/workspace/skills/china-bankcard
clawhub publish --slug "china-bankcard" --name "China Bankcard" --version "1.0.0" .
```

3. 验证发布
```bash
clawhub search china-bankcard
```

## 支持银行（16 家）
- 中国农业银行 (95599)
- 中国工商银行 (95588)
- 中国建设银行 (95533)
- 中国银行 (95566)
- 交通银行 (95559)
- 招商银行 (95555)
- 邮储银行 (95580)
- 中信银行 (95558)
- 光大银行 (95595)
- 民生银行 (95568)
- 兴业银行 (95561)
- 平安银行 (95511)
- 浦发银行 (95528)
- 广发银行 (95508)
- 华夏银行 (95577)

## 功能特性
✅ 识别发卡行
✅ 判断卡种（借记卡/信用卡）
✅ 识别卡组织（银联）
✅ 提供客服电话
✅ Luhn 算法校验
✅ 完全离线运行
✅ 免费无 API 费用

## 限制
❌ 不支持联行号查询
❌ 不支持小众银行/外资银行
❌ 不支持实时卡状态查询

## 扩展 BIN 数据库
如需添加更多银行，编辑 `bankcard_lookup.py` 中的 `BANK_BIN_DB` 字典：

```python
BANK_BIN_DB = {
    "622XXX": ("银行名称", "借记卡/信用卡", "银联", "客服电话"),
    # ... 添加更多
}
```

## 许可证
MIT License

## 作者
墨鱼 (OpenClaw Workspace)

## 更新日期
2026-04-14
