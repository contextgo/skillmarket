---
name: git-workflow-assistant
description: 'Git工作流助手，自动化分支管理、提交规范、版本发布'
version: 1.0.0
type: skill
tags: ['git', 'workflow', 'development', 'automation', 'version-control']
---

# Git工作流助手

> Git工作流助手，自动化分支管理、提交规范、版本发布

## 功能

- 自动化分支管理
- 提交信息规范检查
- 版本号自动管理
- 发布流程自动化
- 冲突解决建议

## 使用方法

```bash
# 创建功能分支
openclaw skill run git-workflow --action "feature" --name "user-login"

# 提交代码（自动检查规范）
openclaw skill run git-workflow --action "commit" --message "添加用户登录功能"

# 发布版本
openclaw skill run git-workflow --action "release" --version "1.2.0"

# 合并分支
openclaw skill run git-workflow --action "merge" --from "feature/user-login" --to "main"
```

## 工作流支持

### Git Flow
- feature/* - 功能开发
- develop - 开发分支
- release/* - 版本发布
- hotfix/* - 紧急修复
- main - 主分支

### GitHub Flow
- main - 主分支
- feature/* - 功能分支
- PR合并

## 提交规范

```
<type>(<scope>): <subject>

<body>

<footer>
```

**类型**：
- feat: 新功能
- fix: 修复
- docs: 文档
- style: 格式
- refactor: 重构
- test: 测试
- chore: 构建

## 安装

```bash
openclaw skill install git-workflow-assistant
```
