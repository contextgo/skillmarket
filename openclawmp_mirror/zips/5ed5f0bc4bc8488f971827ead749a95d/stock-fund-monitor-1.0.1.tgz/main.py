#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
基金监控工具
LOF/ETF份额监控、溢价率分析、套利机会识别
"""

import akshare as ak
import pandas as pd


class FundMonitor:
    """基金监控器"""
    
    def __init__(self):
        pass
    
    def get_etf_share(self):
        """
        获取ETF份额变动
        
        Returns:
            DataFrame: ETF份额数据
        """
        try:
            df = ak.fund_etf_spot_em()
            if df is not None and not df.empty:
                columns = ['代码', '名称', '最新价', '涨跌幅', '成交额', '所属行业']
                available_cols = [c for c in columns if c in df.columns]
                return df[available_cols].head(30)
        except Exception as e:
            print(f"获取ETF份额失败: {e}")
        return None
    
    def get_lof_premium(self):
        """
        获取LOF溢价率
        
        Returns:
            DataFrame: LOF溢价率数据
        """
        try:
            df = ak.fund_lof_spot_em()
            if df is not None and not df.empty:
                # 计算溢价率（如果有相关数据）
                columns = ['代码', '名称', '最新价', '涨跌幅', '成交额']
                available_cols = [c for c in columns if c in df.columns]
                return df[available_cols].head(30)
        except Exception as e:
            print(f"获取LOF溢价率失败: {e}")
        return None
    
    def find_arbitrage(self):
        """
        寻找套利机会
        
        Returns:
            DataFrame: 套利机会列表
        """
        try:
            # 获取LOF数据，筛选高溢价或高折价的
            df = ak.fund_lof_spot_em()
            if df is not None and not df.empty:
                # 筛选涨跌幅较大的（可能有套利机会）
                arb = df[abs(df['涨跌幅']) > 3].copy() if '涨跌幅' in df.columns else df.head(10)
                
                columns = ['代码', '名称', '最新价', '涨跌幅', '成交额']
                available_cols = [c for c in columns if c in arb.columns]
                return arb[available_cols]
        except Exception as e:
            print(f"寻找套利机会失败: {e}")
        return None
    
    def get_ark_holdings(self, fund="ARKK"):
        """
        获取ARK基金持仓
        
        Args:
            fund: ARK基金代码 (ARKK, ARKQ, ARKW, ARKG, ARKF)
            
        Returns:
            DataFrame: ARK持仓数据
        """
        try:
            # 使用akshare获取ARK持仓
            df = ak.stock_ark_holdings(symbol=fund)
            if df is not None and not df.empty:
                return df.head(20)
        except Exception as e:
            print(f"获取ARK持仓失败: {e}")
        return None
    
    def get_fund_holding(self, code):
        """
        获取基金重仓股
        
        Args:
            code: 股票代码
            
        Returns:
            DataFrame: 持仓基金列表
        """
        try:
            df = ak.stock_report_fund_hold(symbol="基金持仓", date="20241231")
            if df is not None and not df.empty:
                # 筛选特定股票的持仓基金
                if '股票代码' in df.columns:
                    holdings = df[df['股票代码'] == code]
                    columns = ['股票代码', '股票简称', '基金名称', '持仓市值', '占流通股比例']
                    available_cols = [c for c in columns if c in holdings.columns]
                    return holdings[available_cols].head(20)
        except Exception as e:
            print(f"获取基金重仓失败: {e}")
        return None


def main():
    """CLI 入口"""
    import fire
    
    monitor = FundMonitor()
    
    def etf_share():
        """ETF份额变动"""
        result = monitor.get_etf_share()
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取ETF份额失败")
    
    def lof_premium():
        """LOF溢价率"""
        result = monitor.get_lof_premium()
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取LOF溢价率失败")
    
    def arbitrage():
        """套利机会"""
        result = monitor.find_arbitrage()
        if result is not None:
            print("=== 套利机会 ===")
            print(result.to_string(index=False))
        else:
            print("未找到套利机会")
    
    def ark(fund="ARKK"):
        """ARK持仓"""
        result = monitor.get_ark_holdings(fund)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取ARK持仓失败")
    
    def fund_holding(code):
        """基金重仓股"""
        result = monitor.get_fund_holding(code)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("获取基金重仓失败")
    
    fire.Fire({
        "etf-share": etf_share,
        "lof-premium": lof_premium,
        "arbitrage": arbitrage,
        "ark": ark,
        "fund-holding": fund_holding,
    })


if __name__ == "__main__":
    main()
