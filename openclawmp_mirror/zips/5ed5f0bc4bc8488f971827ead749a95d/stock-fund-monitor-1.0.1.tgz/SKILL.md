# stock-fund-monitor Skill

## Description

基金监控 Skill，LOF/ETF 场内份额监控、溢价率分析、套利机会识别。

## Capabilities

- ETF/LOF 份额变动监控
- 基金溢价率/折价率分析
- 套利机会识别
- ARK 基金持仓跟踪
- 基金重仓股分析

## Usage

```bash
# ETF份额变动
python main.py etf-share

# LOF溢价率
python main.py lof-premium

# 套利机会
python main.py arbitrage

# ARK持仓
python main.py ark --fund ARKK

# 基金重仓股
python main.py fund-holding --code 000001
```

## Dependencies

- akshare
- pandas

## License

MIT
