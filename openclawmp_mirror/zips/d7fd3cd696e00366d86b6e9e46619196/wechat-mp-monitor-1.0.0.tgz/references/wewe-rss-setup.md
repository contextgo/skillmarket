# WeWe-RSS 部署指南

WeWe-RSS 是一个将微信公众号转为 RSS 订阅的开源工具，比搜狗搜索更稳定可靠。

## 部署方式

### 方式一：Docker 部署（推荐）

#### 使用 SQLite 版本（无需 MySQL）

```bash
# 创建数据目录
mkdir -p ~/wewe-rss/data

# 启动服务
docker run -d \
  --name wewe-rss \
  -p 4000:4000 \
  -e DATABASE_TYPE=sqlite \
  -e AUTH_CODE=your_auth_code \
  -v ~/wewe-rss/data:/app/data \
  cooderl/wewe-rss-sqlite:latest
```

#### 使用 MySQL 版本

```bash
# 创建 Docker 网络
docker network create wewe-rss

# 启动 MySQL
docker run -d \
  --name db \
  -e MYSQL_ROOT_PASSWORD=your_password \
  -e TZ='Asia/Shanghai' \
  -e MYSQL_DATABASE='wewe-rss' \
  -v db_data:/var/lib/mysql \
  --network wewe-rss \
  mysql:8.3.0 --mysql-native-password=ON

# 启动 WeWe-RSS
docker run -d \
  --name wewe-rss \
  -p 4000:4000 \
  -e DATABASE_URL='mysql://root:your_password@db:3306/wewe-rss?schema=public&connect_timeout=30&pool_timeout=30&socket_timeout=30' \
  -e AUTH_CODE=your_auth_code \
  --network wewe-rss \
  cooderl/wewe-rss:latest
```

### 方式二：云服务器部署

在阿里云/腾讯云等服务器上部署，确保 24 小时在线更新。

## 使用步骤

1. **访问服务**
   - 打开 `http://localhost:4000`（本地）或服务器地址
   - 输入 AUTH_CODE 登录

2. **扫码登录**
   - 使用微信读书扫码登录
   - 授权后即可添加公众号

3. **添加公众号**
   - 在管理界面添加要监控的公众号
   - 系统会自动获取历史文章

4. **获取 RSS 链接**
   - 每个公众号会生成独立的 RSS 链接
   - 格式：`http://localhost:4000/feeds/MP_WXS_xxx.rss`

5. **定时更新**
   - 后台会自动定时更新文章
   - 也可手动触发更新

## RSS 接口格式

- **JSON**: `/feeds/MP_WXS_xxx.json`
- **RSS**: `/feeds/MP_WXS_xxx.rss`
- **Atom**: `/feeds/MP_WXS_xxx.atom`

## 高级功能

### 标题过滤

```
/feeds/all.atom?title_include=关键词
/feeds/MP_WXS_xxx.json?title_include=关键词1|关键词2&title_exclude=排除词
```

### 手动更新

```
/feeds/MP_WXS_xxx.rss?update=true
```

### 限制数量

```
/feeds/MP_WXS_xxx.json?limit=30
```

## 与 OpenClaw 集成

部署完成后，可以：

1. 使用 `web_fetch` 工具定期获取 RSS 内容
2. 设置 cron 定时任务自动检查更新
3. 解析 RSS 并汇总发送通知

## 优势对比

| 特性 | 搜狗搜索 | WeWe-RSS |
|------|----------|----------|
| 实时性 | 有延迟 | 接近实时 |
| 稳定性 | 可能触发反爬 | 稳定可靠 |
| 完整性 | 部分文章缺失 | 较完整 |
| 全文获取 | 仅摘要 | 支持全文 |
| 部署成本 | 无需部署 | 需要部署 |

## 注意事项

- 需要微信读书账号
- 首次添加公众号可能需要等待同步
- 建议定期备份数据目录
