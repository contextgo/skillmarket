#!/usr/bin/env python3
"""
微信公众号监控脚本
通过搜狗微信搜索获取公众号最新文章
"""

import json
import sys
import urllib.parse
from datetime import datetime

def search_wechat_account(account_name):
    """
    生成搜狗微信搜索 URL
    """
    encoded_name = urllib.parse.quote(account_name)
    return f"https://weixin.sogou.com/weixin?type=2&query={encoded_name}"

def format_article(title, summary, date, account):
    """
    格式化单篇文章信息
    """
    return {
        "account": account,
        "title": title,
        "summary": summary,
        "date": date
    }

def generate_report(articles):
    """
    生成汇总报告
    """
    report = ["# 微信公众号文章更新汇总\n"]
    report.append(f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}\n")
    report.append("=" * 50 + "\n")
    
    current_account = None
    for article in articles:
        if article["account"] != current_account:
            current_account = article["account"]
            report.append(f"\n## {current_account}\n")
        
        report.append(f"**{article['title']}**\n")
        report.append(f"- 日期: {article['date']}\n")
        report.append(f"- 摘要: {article['summary'][:100]}...\n\n")
    
    return "\n".join(report)

def load_accounts(config_path):
    """
    从配置文件加载账号列表
    """
    try:
        with open(config_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return [acc["name"] for acc in data.get("accounts", [])]
    except Exception as e:
        print(f"Error loading accounts: {e}", file=sys.stderr)
        return []

if __name__ == "__main__":
    # 示例用法
    if len(sys.argv) > 1:
        account = sys.argv[1]
        url = search_wechat_account(account)
        print(f"搜索 URL: {url}")
    else:
        # 加载默认账号列表
        accounts = load_accounts("references/accounts.json")
        print(f"监控账号数: {len(accounts)}")
        for acc in accounts[:5]:  # 只显示前5个
            print(f"- {acc}: {search_wechat_account(acc)}")
