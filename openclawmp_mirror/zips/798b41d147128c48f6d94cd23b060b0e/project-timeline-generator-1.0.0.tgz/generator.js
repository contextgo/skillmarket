/**
 * 项目时间线生成器
 */

const fs = require('fs');

/**
 * 解析里程碑列表
 */
function parseMilestones(input) {
  const lines = input.split('\n').filter(l => l.trim());
  const milestones = [];
  
  lines.forEach(line => {
    // 匹配 "名称: 日期" 或 "名称 - 日期" 或 "- 名称 日期"
    const patterns = [
      /^(.+?)[:：\-]\s*(\d{4}[-/]\d{1,2}[-/]\d{1,2})/,
      /^[-*]\s*(.+?)\s+(\d{4}[-/]\d{1,2}[-/]\d{1,2})/,
      /^(.+?)\s+(\d{4}[-/]\d{1,2}[-/]\d{1,2})/
    ];
    
    for (const pattern of patterns) {
      const match = line.match(pattern);
      if (match) {
        milestones.push({
          name: match[1].trim(),
          date: match[2].trim()
        });
        break;
      }
    }
  });
  
  return milestones.sort((a, b) => new Date(a.date) - new Date(b.date));
}

/**
 * 生成Markdown时间线
 */
function generateMarkdownTimeline(milestones, projectName) {
  const today = new Date().toISOString().slice(0, 10);
  
  let md = `# ${projectName || '项目'}时间线\n\n`;
  md += `生成日期：${today}\n\n`;
  md += `## 📅 里程碑时间线\n\n`;
  
  milestones.forEach((m, i) => {
    const isPast = m.date < today;
    const isToday = m.date === today;
    const icon = isToday ? '🔴' : isPast ? '✅' : '⏳';
    const daysFromStart = milestones.length > 1 
      ? Math.round((new Date(m.date) - new Date(milestones[0].date)) / (1000*60*60*24))
      : 0;
    
    md += `${icon} **${m.name}** — ${m.date}`;
    if (daysFromStart > 0) {
      md += ` （第${daysFromStart + 1}天）`;
    }
    md += '\n';
  });
  
  md += '\n## 📊 甘特图\n\n';
  
  // 甘特图参数
  const startDate = new Date(milestones[0].date);
  const endDate = new Date(milestones[milestones.length - 1].date);
  const totalDays = Math.max(1, Math.round((endDate - startDate) / (1000*60*60*24)));
  const colWidth = Math.min(50, Math.max(10, Math.floor(60 / milestones.length)));
  
  // 绘制甘特图
  const maxNameLen = Math.max(...milestones.map(m => m.name.length));
  
  milestones.forEach(m => {
    const start = new Date(m.start || m.date);
    const end = new Date(m.end || m.date);
    const duration = Math.max(1, Math.round((end - start) / (1000*60*60*24)));
    const leftPad = Math.max(0, Math.round((start - startDate) / (1000*60*60*24)));
    
    const nameStr = m.name.padEnd(maxNameLen, ' ');
    const barLen = Math.max(1, Math.round(duration / totalDays * 60));
    const leftSpaces = ' '.repeat(Math.max(0, Math.min(leftPad, 60)));
    const bar = '█'.repeat(Math.min(barLen, 60 - leftPad));
    
    md += `${nameStr} |${leftSpaces}${bar}\n`;
  });
  
  md += '\n## 📅 日历视图\n\n';
  
  // 生成每月进度
  const months = {};
  milestones.forEach(m => {
    const month = m.date.slice(0, 7);
    if (!months[month]) months[month] = [];
    months[month].push(m);
  });
  
  for (const [month, items] of Object.entries(months)) {
    md += `### ${month}\n`;
    items.forEach(m => {
      const day = m.date.split(/[-/]/)[2];
      md += `- ${day.padStart(2, '0')}日：${m.name}\n`;
    });
    md += '\n';
  }
  
  return md;
}

/**
 * 生成Excel甘特图
 */
function generateExcelTimeline(milestones, projectName, outputPath) {
  const xlsx = require('xlsx');
  const wb = xlsx.utils.book_new();
  
  // Sheet1: 里程碑
  const milestoneData = [
    ['序号', '里程碑', '计划日期', '状态', '备注'],
    ...milestones.map((m, i) => {
      const today = new Date().toISOString().slice(0, 10);
      const status = m.date < today ? '已完成' : m.date === today ? '进行中' : '待开始';
      return [i + 1, m.name, m.date, status, ''];
    })
  ];
  
  const ws1 = xlsx.utils.aoa_to_sheet(milestoneData);
  xlsx.utils.book_append_sheet(wb, ws1, '里程碑');
  
  // Sheet2: 甘特图
  const startDate = new Date(milestones[0]?.date || new Date());
  const endDate = new Date(milestones[milestones.length - 1]?.date || new Date());
  const totalDays = Math.max(1, Math.round((endDate - startDate) / (1000*60*60*24)) + 7);
  
  const ganttData = [['任务']];
  for (let d = 0; d < totalDays; d++) {
    const date = new Date(startDate);
    date.setDate(date.getDate() + d);
    ganttData[0].push(date.toISOString().slice(5, 10));
  }
  
  milestones.forEach(m => {
    const row = [m.name];
    const mStart = new Date(m.date);
    for (let d = 0; d < totalDays; d++) {
      const date = new Date(startDate);
      date.setDate(date.getDate() + d);
      row.push(date.toISOString().slice(0, 10) === m.date ? '█' : '');
    }
    ganttData.push(row);
  });
  
  const ws2 = xlsx.utils.aoa_to_sheet(ganttData);
  xlsx.utils.book_append_sheet(wb, ws2, '甘特图');
  
  xlsx.writeFile(wb, outputPath);
  console.log(`✅ Excel甘特图已生成: ${outputPath}`);
}

// CLI
const args = process.argv.slice(2);
if (args.length > 0) {
  const input = args.join('\n');
  const milestones = parseMilestones(input);
  
  if (milestones.length === 0) {
    console.log('用法: node generator.js "任务1: 2026-03-15" "任务2: 2026-03-20"');
    console.log('或: node generator.js milestone.txt');
    return;
  }
  
  console.log('解析到的里程碑:');
  milestones.forEach(m => console.log(`  ${m.name} - ${m.date}`));
  
  const md = generateMarkdownTimeline(milestones, '项目时间线');
  console.log('\n' + md);
}

module.exports = { parseMilestones, generateMarkdownTimeline, generateExcelTimeline };
