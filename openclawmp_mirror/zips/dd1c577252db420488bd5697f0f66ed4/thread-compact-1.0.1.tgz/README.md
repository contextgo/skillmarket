# 对话压缩 /compact

把当前会话中较旧的对话压缩成结构化摘要，自动保留 ① 未完成的待办 ② 已调用的技能及其结果 ③ 你提过的偏好/纠正 ④ 频道上下文（平台、群/私聊、置顶消息）。最近的若干轮对话原样保留。适合长期运行的 7×24 代理、群聊、多话题讨论，以及需要连续调用多个 SkillHub 技能的场景。仅手动触发，永不自动压缩 — 你始终掌控何时压缩。

## 功能特性

- **手动触发**：斜杠命令 `/compact`、`/压缩`，或自然语言"压缩对话"、"summarize this thread"
- **结构化保留**：待办事项、技能调用记录、用户偏好、频道上下文四类关键信息永不丢失
- **最近轮次原样保留**：最近 ~8 轮或 ~2000 tokens 不动
- **原子提交 + 60 分钟撤销**：`/compact undo` 可还原最近一次压缩
- **可选聚焦**：`/compact focus:<话题>` 按指定话题压缩
- **全频道支持**：飞书 / WeCom / Slack / Discord 富卡片；微信 / Telegram / WhatsApp / iMessage / DingTalk 纯文本降级
- **不自动触发**：上下文接近满时仅友好提示，绝不未经指令执行

## 安装

```bash
openclawmp install skill/thread-compact --target-dir ./skills
```

## 使用方法

1. **手动触发压缩**：在会话中输入 `/compact` 或 `/压缩`
2. **按话题压缩**：`/compact focus:<话题>`（例：`/compact focus:下沙高校合作`）
3. **撤销压缩**：1 小时内输入 `/compact undo` 还原
4. **取回完整 JSON**（纯文本频道）：`/recall`

## 配置说明

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `recent_tail_max_tokens` | 最近轮次保留的 token 上限 | 2000 |
| `recent_tail_max_turns` | 最近轮次保留的轮数上限 | 8 |
| `min_turns_to_compact` | 低于此轮数不压缩 | 5 |
| `undo_window_minutes` | 撤销窗口（分钟） | 60 |
| `soft_nudge_threshold_pct` | 软提示阈值（% 上下文预算） | 85 |
| `group_permission` | 群聊中谁可调用 | `anyone`（可改 `admin_only`） |

## 依赖

- StepClaw ≥ 0.3.0
- 代理默认模型（推荐 `step-3.5-flash`）
- 无外部 API 调用；仅使用代理自身模型

## 资产结构

```
compact/
├── .metadata.json           # 资产元数据
├── README.md                # 本文件
├── SKILL.md                 # Skill 完整定义（行为、触发、提示词）
└── references/
    ├── schema.json          # 输出 JSON Schema
    └── example-output.json  # 示例输出
```

## 反馈

按 StepClaw 用户 FAQ 手册流程反馈：

```
【阶跃号】<UID>
【设备ID】<DID>
【技能】/compact (thread-compact v1.0.0)
【问题描述】...
```

---

*作者：LiXuan@StepFun · 2026-04-17*
