# /compact — Thread Compact Skill Definition

把当前对话线程中较旧的部分压缩成结构化摘要，保留关键状态（待办事项、已调用的技能、用户偏好、频道上下文），释放上下文额度。最近若干轮对话原样保留。手动触发，永不自动运行。

---

## 一、触发方式

**仅手动触发** — 用户显式调用，无 token 阈值自动压缩，无后台静默压缩。

### 斜杠命令
- `/compact` — 默认压缩
- `/压缩` — 中文别名
- `/compact focus:<话题>` — 按指定话题压缩
- `/compact undo` — 撤销最近一次压缩（1 小时内有效）

### 自然语言触发
**中文：** 压缩对话 · 总结前文 · 压缩一下 · 把前面总结一下 · 清理对话历史
**English：** summarize this thread · compact this chat · compress the conversation · clean up the thread

### 软提示
当对话 token 数接近频道上下文的 85% 时，代理**可以**回复一行建议："上下文较长，如需压缩请输入 /compact"。但**不得**未经用户指令执行压缩。

---

## 二、运行时行为

调用时执行：

1. **选择分界线：** 向前扫描线程，保留最近 **≤2000 tokens** 或 **≤8 轮**（先到者为准）的原文，其余进入压缩范围。
2. **运行摘要提示词：** 用 Step-3.5 Flash 对分界线之前的内容跑"六、系统提示词"中的提示。
3. **输出替换块：** 一段结构化 JSON（机器可读，schema 见 `references/schema.json`）+ 一段人类可读的中/英文 recap。
4. **原子提交：** 用摘要块替换旧轮次；最近轮次保持原样。任何步骤失败则整体回滚，原线程不变。
5. **持久化：** JSON 块写入代理记忆层，成为后续轮次的权威线程状态（代理读 JSON，不再重读原始历史）。

### 跳过条件
- 线程少于 5 轮 → 不压缩，回复"No compaction needed — thread too short."

### 撤销
- 压缩后 60 分钟内：`/compact undo` 可从事务日志还原压缩前状态。
- 超过 60 分钟：撤销失效。

---

## 三、必须保留的四类信息

| 类别 | 内容 | 保留规则 |
|---|---|---|
| `active_tasks` | 未完成的待办 / 待处理项 | 每条带 `source_turn`。用户明确标记"已完成"的剔除。 |
| `skills_invoked` | 本线程调用过的 SkillHub 技能 | 记录输入摘要、输出摘要、**持久化副作用**（文件、多维表格行、日历事件等，不记录临时输出）。 |
| `user_preferences` | 用户在本线程中的纠正 / 偏好 | 改写为祈使式指令（"Prefer X"、"Never Y"）。最多 10 条，重复项合并。 |
| `channel_context` | 频道 / 线程元数据 | 平台、群 vs 私聊、参与者及其角色、置顶消息。 |

---

## 四、输出格式（因频道而异）

| 频道 | 显示 |
|---|---|
| 飞书 / WeCom / Slack / Discord | 可折叠互动卡片，标题 `🗜️ 对话已压缩 · N 轮 → 摘要`，底部「撤销」按钮 |
| 微信 / Telegram / WhatsApp / iMessage / DingTalk | 纯文本回复 `✅ 已压缩 N 轮对话。\n\n<recap>`。完整 JSON 存入记忆层，用户用 `/recall` 取回 |

无论哪种频道，**JSON 块始终写入代理记忆层**作为权威状态。可见消息是视图，不是真相源。

---

## 五、边界情况

| 情况 | 行为 |
|---|---|
| 线程 < 5 轮 | 跳过，回复 "No compaction needed — thread too short." |
| 线程含二进制附件（图、PDF、音频） | 按文件名 / ID 引用，不再尝试描述内容 |
| 多用户群聊 | 摘要中保留按发言人归属（`user:ZhangSan said X; agent replied Y`） |
| 压缩中途失败 | 原子回滚，原线程完好，向 SkillHub 遥测上报失败 |
| `/compact focus:<话题>` 无命中 | 回退为默认压缩，回复"未找到 `<话题>` 相关内容，已执行默认压缩。" |
| 频道不支持富卡片但技能尝试发送 | 自动降级为纯文本格式 |
| 压缩时有技能正在运行 | 排队到该技能结束后执行，绝不打断运行中的技能 |

---

## 六、系统提示词

运行时注入以下变量：`{{THREAD}}` · `{{RECENT_TAIL}}` · `{{CHANNEL_META}}` · `{{FOCUS}}`。

```
You are the StepClaw /compact skill. You compress a long conversation thread into
a faithful summary that preserves state for future turns.

## Inputs
- {{THREAD}} — the turns to compact (everything before the boundary)
- {{RECENT_TAIL}} — the turns you MUST NOT summarize (shown for context only)
- {{CHANNEL_META}} — platform, thread type, participants, pinned messages
- {{FOCUS}} — optional topic to emphasize (may be empty)

## Output (emit in this exact order; nothing else)

1. A fenced ```json``` block matching references/schema.json EXACTLY. All top-level
   fields required; use null for absent-but-applicable values, never omit keys.

2. A fenced ```recap``` block with a human-readable summary, in the thread's
   dominant language (Chinese if >50% of user turns are Chinese, else English):

   **话题主线：** <1–3 sentences>
   **已完成：** <bulleted list>
   **待办：** <mirror of active_tasks>
   **关键决定：** <bulleted list with reasoning>

## Rules
- Be faithful. Never invent facts. If unsure, omit.
- Preserve per-speaker attribution in multi-user threads.
- Reference attachments by filename/ID only; never re-describe binary content.
- Respect FOCUS if provided — over-index on FOCUS-related turns.
- If THREAD < 5 turns: emit minimal JSON (empty arrays) and a one-line recap
  "No compaction needed — thread too short."
- Never reveal RECENT_TAIL in the recap.
- Token estimates: word count × 1.3 is fine for tokens_before/tokens_after.
- Timestamps: ISO 8601, default +08:00 unless channel metadata says otherwise.
- No extra prose before the JSON block or after the recap block.
```

---

## 七、兼容性

- **StepClaw 版本**：≥ 0.3.0
- **模型**：继承代理默认模型（推荐 step-3.5-flash）
- **频道**：所有 StepClaw 支持的频道
- **OpenClaw ClawHub 可移植性**：提示词和 schema 框架中立，仅需调整频道 UX 即可镜像到 ClawHub

---

## 八、权限

- 私聊：任何人可调用
- 群聊：默认任何人可调用（可改为仅管理员）
- 读权限：线程历史
- 写权限：代理记忆层、线程内容（替换旧轮次）

---

*See also:* `references/schema.json` · `references/example-output.json`
