# AI 工具知识库

> 记录各类 AI 应用、工具的学习笔记
> 存放位置：~/.qclaw/skills/learning-knowledge-base/ai-tools-knowledge.md
> 建立时间：2026-04-08

---

## Tavo App

**类型**：Android AI 角色扮演聊天工具

**包名**：`app.bitbear.tavo`
**下载来源**：脚本之家（jb51.net）、官方帮助中心（docs.tavo.cc）
**版本**：v0.66.0（2026-01-08）

### 核心定位

专为 AI 角色扮演爱好者打造的聊天工具，主打**无内容审查**、**可自定义**。

### 主要功能

| 功能 | 说明 |
|------|------|
| 角色卡 | 从头创建或导入 SillyTavern 格式角色卡，支持各大热门角色卡网站 |
| 私有 API | 直连热门 AI 模型，无中间商，无限制 |
| 群聊 | 支持剧情演绎、party、后宫等多人聊天 |
| 世界观（Lorebook） | 动态注入背景知识，保持上下文连贯 |
| 正则表达式控制 | 精准控制 AI 回应风格与生成策略 |
| 文本转语音 | 集成 ElevenLabs，支持本地 MultiTTS 免费选项 |
| 长期记忆 | 自动提取对话关键信息，AI 记住过往交流 |

### 使用门槛

- 需要自有 API Key（支持主流大模型 API）
- Android 端，无 iOS 版本信息

### 相关链接

- 官网帮助中心：https://docs.tavoai.dev/（新域名，docs.tavo.cc 会跳转）
- 下载（脚本之家）：https://www.jb51.net/softs/38243.html

---

## Tavo 帮助中心完整学习（2026-04-08）

### 一、API 设置

#### 1.1 支持的模型平台

| 平台 | 说明 |
|------|------|
| Volink | 主推平台 |
| Gemini | Google AI Studio |
| Claude | Anthropic |
| DeepSeek | 深度求索官方 |
| OpenAI | 需要梯子 |
| 豆包/火山/字节跳动 | 内含 DeepSeek |
| OpenRouter | 聚合平台 |

#### 1.2 API 配置步骤

1. 打开 APP → 菜单栏 → API连接 → 新建
2. 填入 API Key，选择模型平台和模型
3. 保存（海外模型需开梯子）

#### 1.3 模型参数设置

| 参数 | 作用 |
|------|------|
| 上下文记忆长度 | 控制模型能记住的对话历史长度 |
| 回复令牌限制 | 限制单次回复最大长度 |
| 温度（Temperature） | 控制随机性，高=多样，低=确定 |
| Top-P | 数值低=性格单一，高=多面 |
| Top-K | 数值低=风格固定，高=多变 |
| 流式输出开关 | 逐字显示 vs 一次性完整显示 |

#### 1.4 常见错误及解决

| 错误 | 原因 | 解决 |
|------|------|------|
| API Key 无效 | 密钥错误/过期/撤销 | 检查大小写、空格、有效期 |
| 地理位置限制 | OpenAI/Claude/Gemini 限制中国 IP | 切换网络节点 |
| 模型未开通 | 部分模型需后台手动开通 | 如 Doubao 需在后台开通 |
| 模型繁忙 | 服务器高负载 | 稍后重试 |
| resource exhausted | 余额不足 | 充值 |
| 模型返回为空 | 流式传输问题 | 关闭流式传输 |
| 免费额度用完 | 每日额度耗尽 | 等待重置或升级付费 |
| 请求体积超限 | 单条消息太大 | 调低记忆量 |
| 内容被过滤 | 敏感内容被拦截 | 调整聊天内容 |

---

### 二、角色管理

#### 2.1 创建角色

1. 打开 APP → 角色 → 新建
2. 添加头像、填写名称和描述
3. 保存

#### 2.2 导入角色卡

| 方式 | 步骤 |
|------|------|
| JSON 导入 | 从文件导入 → 选择 JSON 文件 → 保存 |
| 图片导入 | 从照片图库导入 → 选择 PNG 图片 → 保存（PNG 需包含文本块） |
| URL 导入 | 输入角色连接 → 导入 → 保存（仅支持单连接，私人角色可能失败） |

---

### 三、预设（Preset）

预设是一套为角色设定的基础配置和行为模式，帮助快速设置身份、性格、行为准则。

#### 3.1 基础提示词

| 提示词 | 作用 | 示例 |
|--------|------|------|
| 用户身份 | 定义与角色的关系 | `{{user}}是{{char}}的好友，互动时表现出亲密和关怀` |
| 角色设定 | 设定身份背景 | `{{char}}是聪明且好奇的探险家，目标是找到失落宝藏` |
| 性格特点 | 描述性格特征 | `{{char}}性格冷静、理智，面对困境时展现坚定决心` |
| 情景设定 | 当前环境背景 | `{{char}}正站在古老图书馆中，四周堆满尘封书籍` |
| 新示例聊天 | 对话示例 | `{{char}}：你觉得任务能完成吗？\n{{user}}：我们一起努力` |
| 新聊天 | 新对话开场 | `{{char}}：今天是个好日子！你有什么计划？` |
| 群聊推进 | 多人对话推进 | `{{char}}在群聊中提到：大家都准备好了吗？` |
| 继续推进 | 推动情节发展 | `{{char}}继续说：既然准备好了，就开始吧` |
| AI帮答 | AI 回答风格 | `如果{{user}}询问背景，AI会回答：我是探险家...` |

#### 3.2 其他提示词

| 提示词 | 作用 |
|--------|------|
| Main Prompt | 总体指导，设定行为基调和对话方向 |
| Word Info (Before) | 对话前的背景信息或词汇要求 |
| Persona Description | 角色个性和行为特征 |
| Char Description | 外貌、衣着等物理特征 |
| Char Personality | 性格特质和待人方式 |
| Scenario | 当前情境设定 |
| Enhance Definitions | 强化特定行为定义 |
| Auxiliary Prompt | 辅助性提示，对话风格建议 |
| World Info (After) | 对话后世界变化，推动情节 |
| Chat Examples | 对话示例 |
| Chat History | 过去对话内容参考 |
| Post-History Instructions | 输出格式要求，控制篇幅和排版 |

---

### 四、聊天功能

#### 4.1 聊天操作

| 操作 | 说明 |
|------|------|
| 按角色筛选 | 快速定位与特定角色的对话 |
| 重命名 | 点击顶部对话名称修改 |
| 置顶 | 对话条目右侧 ⋮ → 置顶 |
| 查看统计 | 右上角菜单栏 → 底部 → 统计（陪伴天数、消息数、总字数） |
| 重启聊天 | 右上角菜单栏 → 底部 → 重启聊天（清空历史，不可恢复） |
| 克隆聊天 | 对话条目右侧 ⋮ → 克隆聊天（完整复制） |
| 删除聊天 | 对话条目右侧 ⋮ → 删除（永久删除，不可恢复） |
| 查看历史聊天 | 角色页面 → 角色右侧 ⋮ → 历史聊天 |

#### 4.2 高级设定（侧边栏）

| 功能 | 说明 |
|------|------|
| 切换 API 连接 | 快速更换 API 服务或模型 |
| 启用/切换预设 | 切换对话预设模板 |
| 启用/切换世界书 | 切换背景知识库 |
| 启用/切换正则 | 切换正则表达式规则 |
| 开启长记忆 | 激活长时记忆功能 |

#### 4.3 导入导出

| 操作 | 说明 |
|------|------|
| 导入聊天记录 | 侧边栏 → + → 导入聊天记录 → 选择 .jsonl 文件 |
| 导出聊天记录 | 右上角菜单栏 → 底部 → 导出 → 选择格式（.txt / .json） |

---

### 五、群聊

#### 5.1 发起群聊

1. 左侧菜单栏 → + → 发起群聊
2. 勾选角色 → 确认开启

#### 5.2 管理群成员

- **添加成员**：侧边栏 → 群成员 → 添加
- **移出成员**：成员右侧 ×
- **禁言成员**：成员右侧消息图标切换

#### 5.3 回复模式

| 模式 | 说明 |
|------|------|
| 自然聊天 | 被@的角色优先回复；无@则随机一位发言 |
| 全员回复 | 每条消息所有角色都会回复 |
| 指定发言 | 必须通过 @角色名 指定发言人 |

---

### 六、主题定制

操作路径：侧边栏 → 更多 → 主题

可调整元素：
- 聊天背景、状态栏
- 消息气泡样式、字体
- 聊天头像显示方式
- 内心戏提示样式

---

### 七、Tavo vs SillyTavern 差异

| 特性 | Tavo | SillyTavern |
|------|------|-------------|
| 平台 | Android App | Web/PC |
| API 配置 | 内置多平台支持 | 需手动配置 |
| 世界观 | 支持世界书（Lorebook） | 完整 Lorebook |
| 正则 | 支持正则规则 | 完整 Regex |
| 群聊 | 三种回复模式 | 四种模式（多 Pooled） |
| 长记忆 | 内置功能 | 需插件 |
| 内容审查 | **无** | 取决于 API |
| 角色卡格式 | 兼容 SillyTavern | 标准 |

---

### 八、高级前端渲染（Web）

**功能**：让聊天页面渲染标准 HTML 与 CSS，支持强大灵活的页面美化。

**开启方法**：
1. 打开主界面 → 点击左上角打开左侧边栏
2. 点击底部"更多" → 点击"设置"
3. 点击"高级前端渲染" → 打开开关

**使用方式**：
在聊天页改写任一气泡，粘贴 HTML 代码：
```html
这是一行有<span style="color: red">红色</span>的字
同时也有<strong>粗体</strong>
有时候还能看到图片<img src="https://..." />
```

**JavaScript 支持**：高级前端渲染支持 JavaScript 脚本执行。

---

### 九、JavaScript API

**版本**：Since v0.75.0

Tavo JavaScript API 是面向玩家及创作者提供的一套 JavaScript 接口，开启 JavaScript 支持时可获得强大功能和高可玩性。

#### 9.1 变量 API

| 方法 | 说明 |
|------|------|
| `tavo.get(name[, scope])` | 获取变量值 |
| `tavo.set(name, value[, scope])` | 设置变量值 |
| `tavo.unset(name[, scope])` | 删除变量 |

**作用域 (scope)**：
- `"chat"`：聊天作用域（默认），仅在当前聊天内可访问
- `"global"`：全局作用域，跨对话访问与保存

**路径支持**：`tavo.get('status.hp')` 获取嵌套值

**提示词中使用变量**：
- `{{getvar::name}}` - 获取聊天变量
- `{{getglobalvar::name}}` - 获取全局变量

#### 9.2 消息 API (`tavo.message.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.message.find(indexRange[, filter])` | 按楼层范围和过滤器查找消息 |
| `await tavo.message.get(messageId)` | 按 ID 获取单条消息 |
| `await tavo.message.current()` | 获取执行代码所在的消息 |
| `await tavo.message.count()` | 获取消息总数 |
| `await tavo.message.append(message)` | 追加消息 |
| `await tavo.message.update(message)` | 更新消息 |
| `await tavo.message.delete(messageId)` | 删除消息 |

#### 9.3 聊天 API (`tavo.chat.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.chat.current()` | 获取当前聊天信息 |
| `await tavo.chat.update(chat)` | 更新当前聊天 |

#### 9.4 角色 API (`tavo.character.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.character.all()` | 获取所有角色概要 |
| `await tavo.character.get(characterId)` | 获取单个角色 |
| `await tavo.character.find(name[, options])` | 按名称查找角色 |
| `await tavo.character.create(character)` | 创建角色 |
| `await tavo.character.update(character)` | 更新角色 |
| `await tavo.character.delete(characterId)` | 删除角色 |

#### 9.5 用户身份 API (`tavo.persona.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.persona.all()` | 获取所有用户身份 |
| `await tavo.persona.get(personaId)` | 获取单个用户身份 |
| `await tavo.persona.find(name[, options])` | 按名称查找 |
| `await tavo.persona.create(persona)` | 创建用户身份 |
| `await tavo.persona.update(persona)` | 更新用户身份 |
| `await tavo.persona.delete(personaId)` | 删除用户身份 |

#### 9.6 预设 API (`tavo.preset.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.preset.all()` | 获取所有预设摘要 |
| `await tavo.preset.get(presetId)` | 获取单个预设 |
| `await tavo.preset.find(name[, options])` | 按名称查找 |
| `await tavo.preset.create(preset)` | 创建预设 |
| `await tavo.preset.update(preset)` | 更新预设 |
| `await tavo.preset.delete(presetId)` | 删除预设 |

#### 9.7 世界书 API (`tavo.lorebook.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.lorebook.all()` | 获取所有世界书 |
| `await tavo.lorebook.get(lorebookId)` | 获取单个世界书 |
| `await tavo.lorebook.find(name[, options])` | 按名称查找 |
| `await tavo.lorebook.create(lorebook)` | 创建世界书 |
| `await tavo.lorebook.update(lorebook)` | 更新世界书 |
| `await tavo.lorebook.delete(lorebookId)` | 删除世界书 |

#### 9.8 正则 API (`tavo.regex.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.regex.all()` | 获取所有正则摘要 |
| `await tavo.regex.get(regexId)` | 获取单个正则 |
| `await tavo.regex.find(name[, options])` | 按名称查找 |
| `await tavo.regex.create(regex)` | 创建正则 |
| `await tavo.regex.update(regex)` | 更新正则 |
| `await tavo.regex.delete(regexId)` | 删除正则 |

**正则条目字段 (RegexEntry)**：
- `name`：规则显示名
- `findRegex`：查找用正则（支持 `/pattern/flags` 写法）
- `replaceString`：替换为的字符串
- `trimStrings`：额外要裁剪的字符串列表
- `placements`：作用位置（`'user'`, `'char'`, `'reasoning'`, `'lorebook'`）
- `timing`：执行时机（`'display'`, `'send'`, `'sendAndDisplay'`, `'receive'`, `'editAndReceive'`）
- `substitution`：宏替换方式（`'none'`, `'raw'`, `'escaped'`）
- `minDepth` / `maxDepth`：消息深度限制
- `enabled`：是否启用

#### 9.9 长记忆 API (`tavo.memory.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.memory.current()` | 获取当前聊天记忆 |
| `await tavo.memory.update(memory)` | 更新记忆 |

#### 9.10 生成请求 API (`tavo.generate`)

```javascript
await tavo.generate(prompt, options)
```

**options 字段**：
- `context`：是否带当前对话上下文（默认 `false`）
- `preset`：预设 ID 或对象
- `settings`：覆盖模型参数（temperature, topP, maxCompletionTokens 等）

#### 9.11 输入框 API (`tavo.input.*`)

| 方法 | 说明 |
|------|------|
| `await tavo.input.get()` | 读取输入框内容 |
| `tavo.input.set(text)` | 覆盖写入输入框 |
| `tavo.input.append(text)` | 追加到输入框 |
| `tavo.input.clear()` | 清空输入框 |
| `tavo.input.send()` | 触发发送消息 |

#### 9.12 工具 API (`tavo.utils.*`)

| 方法 | 说明 |
|------|------|
| `tavo.utils.toast(text)` | 显示轻量 toast 提示 |
| `tavo.utils.openUrl(url)` | 在外部浏览器打开 URL |
| `tavo.utils.export(name, data)` | 导出文件 |

---

### 十、宏（Macros）

**功能**：动态注入内容到角色定义、预设、世界书、正则及其他生成提示词的地方。

**一般写法**：`{{<宏名称>}}`，带参数用双冒号分割：`{{getvar::hp}}`

#### 10.1 角色宏

| 宏 | 说明 |
|----|------|
| `{{user}}` | 用户身份名字 |
| `{{char}}` | 角色名字 |
| `{{group}}` / `{{charIfNotGroup}}` | 群聊的所有角色 |
| `{{groupNotMuted}}` | 群聊中未被禁言的角色 |

#### 10.2 角色卡宏

| 宏 | 说明 |
|----|------|
| `{{charDescription}}` / `{{description}}` | 角色设定 |
| `{{charPersonality}}` / `{{personality}}` | 角色性格特点 |
| `{{charScenario}}` / `{{scenario}}` | 场景描述 |
| `{{persona}}` | 用户身份描述 |
| `{{charPrompt}}` | Main Prompt 内容 |
| `{{charInstruction}}` / `{{charJailbreak}}` | Post-History Instructions |
| `{{mesExamples}}` / `{{mesExamplesRaw}}` | 对话示例（渲染/原文） |
| `{{charVersion}}` | 角色版本 |
| `{{charCreatorNotes}}` / `{{creatorNotes}}` | 备注 |

#### 10.3 消息宏

| 宏 | 说明 |
|----|------|
| `{{lastMessage}}` | 最后一条消息 |
| `{{input}}` | 用户输入消息 |
| `{{lastUserMessage}}` | 最后一条用户消息 |
| `{{lastCharMessage}}` | 最后一条角色消息 |

#### 10.4 日期与时间宏

| 宏 | 说明 |
|----|------|
| `{{time}}` | 当前时间 |
| `{{date}}` | 当前日期 |
| `{{weekday}}` | 当前星期 |
| `{{isotime}}` | ISO时间（小时:分钟） |
| `{{isodate}}` | ISO日期（年-月-日） |
| `{{idleDuration}}` | 距离上次消息的时长 |
| `{{time::UTC+9}}` | 指定时区时间 |

#### 10.5 随机数宏

| 宏 | 说明 |
|----|------|
| `{{random::1::3::5}}` | 在指定值中随机 |
| `{{roll::3d6}}` | 摇骰子（3颗6面骰） |

#### 10.6 格式化宏

| 宏 | 说明 |
|----|------|
| `{{newline}}` / `{{newline::<行数>}}` | 换行 |
| `{{space}}` / `{{space::<空格数>}}` | 空格 |
| `{{trim}}` | 移除前后空格和换行 |
| `{{noop}}` | 空 |
| `{{//<注释>}}` | 注释（渲染为空） |
| `\{\{char\}\}` | 转义宏 |

#### 10.7 聊天变量宏

| 宏 | 说明 |
|----|------|
| `{{setvar::<变量名>::<值>}}` | 设置变量 |
| `{{addvar::<变量名>::<值>}}` | 增加值（数字加法/列表追加/文字拼接） |
| `{{incvar::<变量名>}}` | 变量 +1 |
| `{{decvar::<变量名>}}` | 变量 -1 |
| `{{getvar::<变量名>}}` | 获取变量值 |

#### 10.8 全局变量宏

| 宏 | 说明 |
|----|------|
| `{{setglobalvar::<变量名>::<值>}}` | 设置全局变量 |
| `{{addglobalvar::<变量名>::<值>}}` | 增加全局变量值 |
| `{{incglobalvar::<变量名>}}` | 全局变量 +1 |
| `{{decglobalvar::<变量名>}}` | 全局变量 -1 |
| `{{getglobalvar::<变量名>}}` | 获取全局变量值 |

#### 10.9 应用场景

**预设 Prompt**：让 AI 每次回复时自动执行特定宏
```
你的回复里必须遵守：
1. 每当角色受到伤害：{{decvar::hp}}
2. 回复末尾附状态栏：【HP: {{getvar::hp}} | 回合: {{getvar::round}}】
3. 每次回复后回合+1：{{incvar::round}}
```

**世界书条目**：触发关键词时自动初始化变量
```
触发关键词：地下城
【你已进入地下城。初始化：
{{setvar::dungeon_floor::1}}
{{setvar::enemies_left::5}}
{{setvar::trap_count::0}}】
```

**正则脚本**：输入端简写展开
```
输入：-hp5 → 自动变成 5个 {{decvar::hp}}
输入：+gold20 → 自动变成 {{addvar::gold::20}}
```

---

---

## 十一、Tavo 角色卡（chara_card_v3）规范

> ⚠️ **重要：这是给瑶瑶自己看的格式规范，下次写角色卡必须严格遵守**
> 参考范本：`C:\Users\hyss\Desktop\Tavo_陆执礼_A7Ps.json`

### 11.1 顶层结构

```json
{
  "spec": "chara_card_v3",
  "spec_version": "3.0",
  "data": { ... }
}
```

**常见导入错误**：
- ❌ 少了 `spec` 或 `spec_version`
- ❌ 直接写内容，没有包在 `data` 里面
- ❌ `spec_version` 写成 "2.0" 或其他版本（Tavo v3 必须用 "3.0"）

### 11.2 data 顶层字段（必须全都有）

| 字段 | 类型 | 说明 | 常见错误 |
|------|------|------|---------|
| `avatar` | string | 头像路径（相对路径或URL），如 `charaCard/xxx.webp` | ❌ 空字符串 |
| `name` | string | 角色名 | ✅ 必须有 |
| `description` | string | 角色描述（外貌/性格/背景） | ✅ 必须有 |
| `first_mes` | string | 首次消息/开场白 | ✅ 必须有 |
| `personality` | string | 性格关键词（逗号分隔） | ✅ 必须有 |
| `scenario` | string | 场景设定 | ✅ 必须有 |
| `mes_example` | string | 消息示例（带 `<START>` 标记） | ✅ 必须有 |
| `creator_notes` | string | **角色扮演指南（★核心★）** | ✅ 必须有 |
| `system_prompt` | string | 系统提示（通常为空） | ✅ 空字符串 `""` |
| `post_history_instructions` | string | 后续历史指令（通常为空） | ✅ 空字符串 `""` |
| `alternate_greetings` | array | 替代开场白数组 | ✅ 可以是空数组 `[]` |
| `character_book` | object | 世界书对象 | ✅ 可以是空对象 `{}` |
| `tags` | array | 标签数组 | ✅ 可以是空数组 `[]` |
| `creator` | string | 创建者名字 | ✅ 必须有 |
| `character_version` | string | 角色版本（可以空字符串） | ✅ 空字符串 `""` |
| `nickname` | string | 昵称（可以 null） | ✅ null |
| `creator_notes_multilingual` | object | 多语言备注 | ✅ 空对象 `{}` |
| `source` | string | 来源（可以空字符串） | ✅ 空字符串 `""` |
| `group_only_greetings` | array | 群聊专用开场白 | ✅ 空数组 `[]` |
| `creation_date` | number | 创建日期（Unix时间戳，秒） | ✅ 必须有 |
| `modification_date` | number | 修改日期（Unix时间戳，秒） | ✅ 必须有 |

### 11.3 character_book 世界书结构

**错误写法（瑶瑶之前常犯）**：
- ❌ 直接写数组 `[{ ... }]`
- ❌ 少了 `extensions` 字段

**正确写法**：
```json
"character_book": {
  "name": "世界书名称",
  "entries": [
    {
      "keys": ["关键词1", "关键词2"],
      "content": "具体内容",
      "extensions": {
        "selectiveLogic": 0,
        "position": 0,
        "depth": 4,
        "role": 0,
        "match_whole_words": true,
        "probability": 100,
        "useProbability": true,
        "sticky": 0,
        "cooldown": 0,
        "delay": 0,
        "exclude_recursion": false,
        "prevent_recursion": false,
        "delay_until_recursion": false,
        "group": "",
        "group_override": false,
        "group_weight": 100,
        "use_group_scoring": false,
        "scan_depth": 2,
        "case_sensitive": false,
        "automation_id": "",
        "vectorized": false
      },
      "enabled": true,
      "use_regex": false,
      "insertion_order": 10,
      "id": 0,
      "name": "条目名称",
      "comment": "备注",
      "selective": false,
      "case_sensitive": false,
      "constant": true,
      "position": "before_char",
      "display_index": 1
    }
  ]
}
```

**世界书条目必填字段检查清单**：
- ✅ `keys` — 触发关键词数组（不能为空数组 `[]`）
- ✅ `content` — 内容
- ✅ `extensions` — 扩展配置（对象，**不能省略**，即使是空配置也要写）
- ✅ `enabled` — 是否启用（`true`）
- ✅ `use_regex` — 是否用正则（`false`）
- ✅ `position` — 位置（`"before_char"`）

**常见导入错误**：
- ❌ 世界书条目少了 `extensions` 对象
- ❌ `keys` 写成空数组导致触发不了
- ❌ 忘了写 `position` 字段

### 11.4 extensions.regex_scripts 正则脚本结构

```json
"regex_scripts": [
  {
    "id": "165c145d-9916-4d29-9862-3a4f3d4913f5",
    "scriptName": "【触发】信任增加",
    "findRegex": "\\+信任(\\d+)",
    "replaceString": "{{addvar::shen_trust::$1}}",
    "trimStrings": [],
    "placement": [],
    "disabled": false,
    "markdownOnly": false,
    "promptOnly": true,
    "runOnEdit": false,
    "substituteRegex": 0,
    "minDepth": null,
    "maxDepth": null
  }
]
```

**常见导入错误**：
- ❌ `id` 字段用了随机字符串但格式不对（要用 UUID v4 格式）
- ❌ 少了必填字段（如 `scriptName`、`findRegex`）
- ❌ `trimStrings`、`placement` 字段省略导致报错

### 11.5 瑶瑶写角色卡自检流程

写完角色卡后，对照以下清单逐项检查：

```
□ spec = "chara_card_v3"
□ spec_version = "3.0"
□ data 顶层字段全都有（21个字段）
□ system_prompt = ""（空字符串，不是 null）
□ post_history_instructions = ""（空字符串，不是 null）
□ character_book.entries[].extensions 存在且完整
□ character_book.entries[].keys 不是空数组
□ character_book.entries[].position = "before_char"
□ regex_scripts 条目 id 是合法 UUID 格式
□ regex_scripts 条目字段完整
□ creation_date 和 modification_date 是 Unix 时间戳（秒）
```

### 11.6 Tavo 角色卡模板（可直接套用）

```json
{
  "spec": "chara_card_v3",
  "spec_version": "3.0",
  "data": {
    "avatar": "charaCard/avatar.webp",
    "name": "角色名",
    "description": "角色描述（外貌/性格/背景）",
    "first_mes": "首次消息/开场白",
    "personality": "性格关键词1, 性格关键词2, 性格关键词3",
    "scenario": "场景设定",
    "mes_example": "<START>\n{{char}}：xxx\n{{user}}：（xxx）",
    "creator_notes": "★角色扮演指南★\n\n★核心规则\n- 你（{{user}}）= 角色名\n- {{char}} = AI扮演的所有NPC\n- 用第一人称扮演角色直接说话\n- 可用（）写内心独白或*斜体*写动作",
    "system_prompt": "",
    "post_history_instructions": "",
    "alternate_greetings": [],
    "character_book": {
      "name": "世界书名称",
      "entries": []
    },
    "tags": ["标签1", "标签2"],
    "creator": "瑶瑶",
    "character_version": "",
    "nickname": null,
    "creator_notes_multilingual": {},
    "source": "",
    "group_only_greetings": [],
    "creation_date": 1712736000,
    "modification_date": 1712736000,
    "extensions": {
      "regex_scripts": []
    }
  }
}
```

---

*最后更新：2026-04-10*
