# A股选股器 (A-Stock Picker)

> 智能A股选股工具，基于技术指标和基本面分析，每日生成优质股票清单

## 🎯 功能特点

| 特性 | 说明 |
|:---|:---|
| **技术指标选股** | 均线金叉、MACD金叉、RSI超卖、成交量放量 |
| **基本面筛选** | 市盈率、市值、股价多维度过滤 |
| **评分排序** | 综合评分系统，输出Top 50股票 |
| **数据导出** | 自动生成CSV格式的选股清单 |

## 📊 选股指标

### 技术指标
- ✅ 均线金叉 (5日 > 10日)
- ✅ MACD金叉 (DIF > DEA)
- ✅ RSI超卖 (< 30)
- ✅ 成交量放量 (> 20日均量1.5倍)

### 基本面条件
- ✅ 市盈率: 0-100
- ✅ 市值: ≥50亿元
- ✅ 股价: 5-500元

## 🚀 快速开始

```bash
# 安装依赖
pip install akshare pandas numpy

# 运行选股
python scripts/stock_picker.py
```

## 📁 输出结果

生成文件：`stock_picks_YYYYMMDD.csv`

包含字段：
- 股票代码、名称、最新价、涨跌幅
- 市盈率、总市值
- MA5/MA10/MA20、RSI、MACD
- 触发信号、综合评分

## 🔧 自定义配置

编辑 `scripts/stock_picker.py` 修改参数：

```python
results = pick_stocks(
    enable_ma_golden_cross=True,   # 均线金叉
    enable_macd_golden_cross=True, # MACD金叉
    rsi_oversold=30,               # RSI超卖阈值
    pe_max=100,                    # 市盈率上限
    market_cap_min=50,             # 最小市值(亿)
    max_results=50                 # 输出数量
)
```

## 📦 安装

```bash
openclawmp install skill/bb62029e974643d7ab231d87c8b82ac6
```

## 📝 版本历史

| 版本 | 日期 | 说明 |
|:---:|:---:|:---|
| 1.0.0 | 2026-04-09 | 初始版本，基础选股功能 |

## 👤 作者

用户发布

## 🏷️ 标签

`#stock` `#picker` `#a-share` `#trading` `#quantitative`
