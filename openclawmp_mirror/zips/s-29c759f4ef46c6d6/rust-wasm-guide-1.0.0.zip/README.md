# Rust WebAssembly Guide

Compile Rust to WebAssembly for high-performance computation in the browser, running at near-native speed.

## Setup

```bash
# Install wasm-pack
cargo install wasm-pack

# Create project
cargo new --lib my-wasm-lib
cd my-wasm-lib

# Add wasm-bindgen
# Cargo.toml
[lib]
crate-type = ["cdylib", "rlib"]

[dependencies]
wasm-bindgen = "0.2"
```

## Basic WASM Function

```rust
use wasm_bindgen::prelude::*;

#[wasm_bindgen]
pub fn fibonacci(n: u32) -> u64 {
    match n {
        0 => 0,
        1 => 1,
        _ => fibonacci(n - 1) + fibonacci(n - 2),
    }
}

#[wasm_bindgen]
pub fn process_data(input: &str) -> String {
    input.chars().rev().collect()
}
```

## Build and Use

```bash
# Build WASM package
wasm-pack build --target web

# Or target nodejs/bundler
wasm-pack build --target bundler
```

```javascript
// Use in JavaScript
import init, { fibonacci, process_data } from './pkg/my_wasm_lib.js';

await init();
console.log(fibonacci(10));     // 55
console.log(process_data("hi")); // "ih"
```

## Performance Tips

- Use `wasm-bindgen` for JS interop
- Avoid `serde` for simple types (use direct bindings)
- Use `js_sys` and `web_sys` for browser APIs
- Profile with Chrome DevTools for WASM performance
- Use `#[wasm_bindgen(inline_js)]` for JS snippets