#!/usr/bin/env python3
"""
One-click installer for Study Reminder.
Copies scripts to ~/goal-tasks/scripts/ and registers launchd service.
"""

import os
import shutil
import subprocess
from pathlib import Path

INSTALL_DIR = Path.home() / "goal-tasks" / "scripts"
PLIST_DIR = Path.home() / "Library" / "LaunchAgents"
PLIST_NAME = "com.study.active-reminder.plist"
SCRIPT_NAME = "active_reminder.py"
DAEMON_LABEL = "com.study.active-reminder"


def main():
    print("=" * 50)
    print("  Study Reminder - Installer")
    print("=" * 50)

    # 1. Create install directory
    INSTALL_DIR.mkdir(parents=True, exist_ok=True)
    print(f"[1/4] Install directory: {INSTALL_DIR}")

    # 2. Copy daemon script
    src = Path(__file__).parent / SCRIPT_NAME
    dst = INSTALL_DIR / SCRIPT_NAME
    shutil.copy2(src, dst)
    dst.chmod(0o755)
    print(f"[2/4] Copied: {dst}")

    # 3. Generate plist with correct path
    plist_src = Path(__file__).parent / PLIST_NAME
    plist_content = plist_src.read_text()
    plist_content = plist_content.replace("__INSTALL_PATH__", str(INSTALL_DIR))
    plist_dst = PLIST_DIR / PLIST_NAME
    PLIST_DIR.mkdir(parents=True, exist_ok=True)
    plist_dst.write_text(plist_content)
    print(f"[3/4] Plist: {plist_dst}")

    # 4. Load launchd service
    subprocess.run(["launchctl", "unload", str(plist_dst)], capture_output=True)
    result = subprocess.run(["launchctl", "load", str(plist_dst)], capture_output=True, text=True)
    if result.returncode == 0:
        print(f"[4/4] Service loaded: {DAEMON_LABEL}")
    else:
        print(f"[4/4] Warning: {result.stderr.strip()}")

    # Verify
    check = subprocess.run(["launchctl", "list"], capture_output=True, text=True)
    if DAEMON_LABEL in check.stdout:
        print(f"\n  Service is RUNNING!")
    else:
        print(f"\n  Warning: Service may not be running. Check with: launchctl list | grep study")

    print(f"\n  Logs: {Path.home() / 'goal-tasks' / 'active_reminder.log'}")
    print("  To uninstall: launchctl unload " + str(plist_dst))


if __name__ == "__main__":
    main()
