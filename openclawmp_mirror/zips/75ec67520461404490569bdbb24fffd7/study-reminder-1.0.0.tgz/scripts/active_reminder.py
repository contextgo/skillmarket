#!/usr/bin/env python3
"""
Study Reminder Daemon v2
Runs in background, checks time every 60 seconds, triggers dialog notifications.
Designed to be managed by macOS launchd.
"""

import subprocess
import time
from datetime import datetime
from pathlib import Path

# === Configuration ===
LOG_FILE = Path.home() / "goal-tasks" / "active_reminder.log"

# Reminder schedule: (minutes_from_midnight, "HH:MM", "title", "message")
REMINDERS = [
    (6 * 60 + 20,  "06:20", "Morning Start",  "Time to study! Morning session 6:20-7:20"),
    (7 * 60 + 20,  "07:20", "Morning Check",   "Morning study session ended. Check your progress!"),
    (21 * 60 + 0,  "21:00", "Evening Start",   "Evening practice time! Code + LeetCode 21:00-23:00"),
    (23 * 60 + 0,  "23:00", "Evening End",     "Study session over. Check progress and rest!"),
]

# Track triggered reminders to avoid duplicates per day
_triggered = set()


def log(msg):
    """Append timestamped message to log file."""
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {msg}\n")


def send_alert(title, message):
    """Send both a dialog (must dismiss) and a notification (subtle banner)."""
    # Dialog - requires manual dismiss, cannot be missed
    subprocess.Popen([
        "osascript", "-e",
        f'display dialog "{message}" with title "{title}" '
        f'buttons {{"OK"}} default button 1 with icon note'
    ])
    # Notification - subtle banner as backup
    subprocess.run([
        "osascript", "-e",
        f'display notification "{message}" with title "{title}" sound name "Glass"'
    ], check=False)
    log(f"Alert sent: {title}")


def check_and_remind():
    """Check current time against reminder schedule."""
    now = datetime.now()
    today = now.strftime("%Y-%m-%d")
    current_minutes = now.hour * 60 + now.minute

    for target_minutes, time_str, title, message in REMINDERS:
        key = f"{today}_{time_str}"
        if current_minutes == target_minutes and key not in _triggered:
            send_alert(title, message)
            _triggered.add(key)


def main():
    log("Study Reminder Daemon v2 started")
    while True:
        try:
            check_and_remind()
        except Exception as e:
            log(f"Error: {e}")
        time.sleep(60)


if __name__ == "__main__":
    main()
