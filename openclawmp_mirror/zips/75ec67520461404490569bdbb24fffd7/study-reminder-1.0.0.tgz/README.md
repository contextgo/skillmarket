# Study Reminder

Automated study reminder system for macOS that pops up non-missable dialog notifications at configured study times. Built on launchd + Python + osascript, providing persistent background reminders that start at login and auto-restart on crash.

## What It Solves

If you have a fixed daily study schedule and keep forgetting to start or stop on time, this skill runs a lightweight background daemon that checks the clock every 60 seconds and fires system-level dialog popups at your chosen times. Unlike subtle banner notifications, these dialogs require manual dismissal, making them impossible to miss.

## Key Capabilities

- One-click install via `python3 scripts/install_reminder.py`
- Configurable reminder times (edit a simple Python list)
- Persistent across reboots via macOS launchd (RunAtLoad + KeepAlive)
- Dual notification: dialog popup (must dismiss) + banner notification (backup)
- Duplicate prevention: each reminder fires only once per day

## Quick Start

```bash
python3 scripts/install_reminder.py
```

Customize reminder times by editing `scripts/active_reminder.py`:

```python
REMINDERS = [
    (6*60+20,  "06:20", "Morning Start",  "Time to study!"),
    (21*60+0,  "21:00", "Evening Start",   "Evening practice time!"),
]
```

## Architecture

```
launchd (macOS service manager)
  └── active_reminder.py (Python daemon, checks every 60s)
        └── osascript (AppleScript bridge)
              └── display dialog (non-missable popup)
```
