---
name: study-reminder
description: Study reminder and scheduling system for macOS. Automatically sends dialog notifications at configured study times using launchd + Python + osascript. Use when users want to (1) set up automatic study reminders, (2) configure daily learning schedules, (3) create persistent background reminder services on macOS, or (4) learn about launchd/osascript automation patterns.
---

# Study Reminder

Automated study reminder system for macOS that pops up dialog notifications at configured times. Uses launchd for persistence and osascript for notifications.

## Quick Start

Install the reminder service:

```bash
python3 scripts/install_reminder.py
```

This installs the launchd service, Python daemon, and reminder script. Customize reminder times in `scripts/active_reminder.py`.

## Architecture

```
launchd (macOS service manager)
  └── active_reminder.py (Python daemon, runs every 60s)
        └── osascript (macOS scripting bridge)
              └── display dialog (popup notification)
```

Three layers work together:

1. **launchd**: macOS native service manager. Starts the daemon at login, auto-restarts on crash. Configured via plist in `~/Library/LaunchAgents/`.
2. **Python daemon**: Infinite loop checking time every 60 seconds. Triggers alerts when current minute matches a configured reminder time.
3. **osascript**: macOS command-line tool for AppleScript. Used to pop dialogs (`display dialog`) and send notifications (`display notification`).

## Configure Reminder Times

Edit the `reminders` list in `scripts/active_reminder.py`:

```python
reminders = [
    (6*60+20,  "06:20", "Morning Start",  "Time to study!"),
    (7*60+20,  "07:20", "Morning Check",   "Morning session done?"),
    (21*60+0,  "21:00", "Evening Start",   "Evening practice time!"),
    (23*60+0,  "23:00", "Evening End",     "Study session over. Rest!"),
]
```

Each tuple: `(minutes_from_midnight, "HH:MM", "title", "message")`

## Manage the Service

```bash
# Check status
launchctl list | grep study-reminder

# Stop service
launchctl unload ~/Library/LaunchAgents/com.study.active-reminder.plist

# Start service
launchctl load ~/Library/LaunchAgents/com.study.active-reminder.plist

# View logs
cat ~/goal-tasks/active_reminder.log
```

## Key Implementation Details

- **Prevents duplicate triggers**: Uses `triggered` set with date-prefixed keys (e.g., `"2026-04-08_06:20"`)
- **Dialog vs notification**: `display dialog` requires manual dismiss (user cannot miss it). `display notification` is a subtle banner (easily missed). Both are sent for redundancy.
- **KeepAlive = true**: If Python crashes, launchd restarts it automatically
- **RunAtLoad = true**: Service starts when user logs in
- **sleep(60)**: Checks time every 60 seconds; if exact minute is missed (e.g., heavy load), that reminder is skipped until next day

## Troubleshooting

- **No notifications**: Check System Preferences > Notifications > Script Editor is allowed
- **Service not running**: `launchctl load` the plist file
- **Computer was asleep**: launchd catches up on missed schedules after wake
- **Need to test**: Run `osascript -e 'display dialog "Test" with title "Study" buttons {"OK"}'`

## Files

- `scripts/active_reminder.py` - Main daemon script
- `scripts/install_reminder.py` - One-click installer
- `scripts/com.study.active-reminder.plist` - launchd configuration template
