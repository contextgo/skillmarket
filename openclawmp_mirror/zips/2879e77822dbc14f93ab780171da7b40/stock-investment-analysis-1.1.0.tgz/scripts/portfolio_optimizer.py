"""
投资组合优化器
基于现代投资组合理论的资产配置工具
"""

import json
import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


@dataclass
class Asset:
    """资产"""
    name: str
    asset_type: str  # 股票、债券、现金、商品等
    expected_return: float  # 预期收益率
    volatility: float  # 波动率
    correlation: Dict[str, float]  # 与其他资产的相关性
    
    def __post_init__(self):
        self.expected_return = self.expected_return / 100  # 转为小数
        self.volatility = self.volatility / 100


@dataclass
class PortfolioResult:
    """组合结果"""
    weights: Dict[str, float]
    expected_return: float
    volatility: float
    sharpe_ratio: float


class PortfolioOptimizer:
    """投资组合优化器"""
    
    def __init__(self, risk_free_rate: float = 0.03):
        """
        初始化
        risk_free_rate: 无风险利率(默认3%)
        """
        self.risk_free_rate = risk_free_rate
        self.assets: Dict[str, Asset] = {}
        
    def add_asset(self, asset: Asset):
        """添加资产"""
        self.assets[asset.name] = asset
        
    def calculate_portfolio_return(self, weights: Dict[str, float]) -> float:
        """计算组合预期收益"""
        portfolio_return = 0
        for name, weight in weights.items():
            if name in self.assets:
                portfolio_return += weight * self.assets[name].expected_return
        return portfolio_return
        
    def calculate_portfolio_volatility(self, weights: Dict[str, float]) -> float:
        """计算组合波动率"""
        variance = 0
        
        # 方差项
        for name1, weight1 in weights.items():
            if name1 not in self.assets:
                continue
            for name2, weight2 in weights.items():
                if name2 not in self.assets:
                    continue
                    
                asset1 = self.assets[name1]
                asset2 = self.assets[name2]
                
                # 获取相关系数
                if name1 == name2:
                    correlation = 1.0
                else:
                    correlation = asset1.correlation.get(name2, 0.5)
                
                variance += weight1 * weight2 * asset1.volatility * asset2.volatility * correlation
                
        return math.sqrt(variance)
        
    def calculate_sharpe_ratio(self, weights: Dict[str, float]) -> float:
        """计算夏普比率"""
        portfolio_return = self.calculate_portfolio_return(weights)
        portfolio_volatility = self.calculate_portfolio_volatility(weights)
        
        if portfolio_volatility == 0:
            return 0
            
        return (portfolio_return - self.risk_free_rate) / portfolio_volatility
        
    def optimize_max_sharpe(self) -> PortfolioResult:
        """优化：最大化夏普比率"""
        # 简化的优化方法：网格搜索
        best_sharpe = -float('inf')
        best_weights = None
        
        # 获取资产列表
        asset_names = list(self.assets.keys())
        n = len(asset_names)
        
        if n == 0:
            return None
            
        # 生成权重组合
        steps = 20
        from itertools import product
        ranges = [i / steps for i in range(steps + 1)]
        
        for weights_list in product(ranges, repeat=n):
            # 归一化
            total = sum(weights_list)
            if total == 0:
                continue
            weights = {name: w / total for name, w in zip(asset_names, weights_list)}
            
            sharpe = self.calculate_sharpe_ratio(weights)
            
            if sharpe > best_sharpe:
                best_sharpe = sharpe
                best_weights = weights
                
        if best_weights is None:
            return None
            
        return PortfolioResult(
            weights=best_weights,
            expected_return=self.calculate_portfolio_return(best_weights),
            volatility=self.calculate_portfolio_volatility(best_weights),
            sharpe_ratio=best_sharpe
        )
        
    def optimize_min_volatility(self) -> PortfolioResult:
        """优化：最小波动率"""
        best_vol = float('inf')
        best_weights = None
        
        asset_names = list(self.assets.keys())
        n = len(asset_names)
        
        if n == 0:
            return None
            
        steps = 20
        from itertools import product
        ranges = [i / steps for i in range(steps + 1)]
        
        for weights_list in product(ranges, repeat=n):
            total = sum(weights_list)
            if total == 0:
                continue
            weights = {name: w / total for name, w in zip(asset_names, weights_list)}
            
            vol = self.calculate_portfolio_volatility(weights)
            
            if vol < best_vol:
                best_vol = vol
                best_weights = weights
                
        if best_weights is None:
            return None
            
        return PortfolioResult(
            weights=best_weights,
            expected_return=self.calculate_portfolio_return(best_weights),
            volatility=best_vol,
            sharpe_ratio=self.calculate_sharpe_ratio(best_weights)
        )
        
    def efficient_frontier(self, num_points: int = 20) -> List[Dict]:
        """计算有效前沿"""
        results = []
        
        # 目标收益范围
        min_return = min(a.expected_return for a in self.assets.values())
        max_return = max(a.expected_return for a in self.assets.values())
        
        step = (max_return - min_return) / num_points
        
        for target_return in [min_return + i * step for i in range(num_points + 1)]:
            # 寻找满足目标收益的最小波动组合
            best_vol = float('inf')
            best_weights = None
            
            asset_names = list(self.assets.keys())
            n = len(asset_names)
            
            if n == 0:
                continue
                
            steps = 10
            from itertools import product
            ranges = [i / steps for i in range(steps + 1)]
            
            for weights_list in product(ranges, repeat=n):
                total = sum(weights_list)
                if total == 0:
                    continue
                weights = {name: w / total for name, w in zip(asset_names, weights_list)}
                
                portfolio_return = self.calculate_portfolio_return(weights)
                portfolio_vol = self.calculate_portfolio_volatility(weights)
                
                # 检查是否满足目标收益
                if abs(portfolio_return - target_return) < 0.001:
                    if portfolio_vol < best_vol:
                        best_vol = portfolio_vol
                        best_weights = weights
                        
            if best_weights:
                results.append({
                    "target_return": f"{target_return * 100:.2f}%",
                    "min_volatility": f"{best_vol * 100:.2f}%",
                    "sharpe_ratio": round(self.calculate_sharpe_ratio(best_weights), 2)
                })
                
        return results


class AssetAllocator:
    """资产配置器"""
    
    # 风险配置文件
    RISK_PROFILES = {
        "保守型": {
            "stocks": 20,
            "bonds": 60,
            "cash": 20,
            "description": "以债券和现金为主，追求稳定收益"
        },
        "稳健型": {
            "stocks": 40,
            "bonds": 40,
            "cash": 20,
            "description": "股债平衡，追求稳健增值"
        },
        "平衡型": {
            "stocks": 60,
            "bonds": 30,
            "cash": 10,
            "description": "偏重股票，追求较高收益"
        },
        "积极型": {
            "stocks": 80,
            "bonds": 15,
            "cash": 5,
            "description": "以股票为主，追求高收益"
        },
        "激进型": {
            "stocks": 100,
            "bonds": 0,
            "cash": 0,
            "description": "全部投资股票，追求最高收益"
        }
    }
    
    def __init__(self, risk_profile: str = "稳健型", age: int = 35):
        """
        初始化
        risk_profile: 风险偏好
        age: 年龄
        """
        self.risk_profile = risk_profile
        self.age = age
        
    def get_allocation(self) -> Dict:
        """获取配置建议"""
        profile = self.RISK_PROFILES.get(self.risk_profile, self.RISK_PROFILES["稳健型"])
        
        # 根据年龄调整（年龄法则：股票比例 = 100 - 年龄）
        age_adjusted_stocks = min(100, max(0, 100 - self.age))
        
        # 如果年龄调整后与配置文件差异较大，取两者平均
        if abs(age_adjusted_stocks - profile["stocks"]) > 20:
            adjusted_stocks = (age_adjusted_stocks + profile["stocks"]) // 2
        else:
            adjusted_stocks = profile["stocks"]
            
        remaining = 100 - adjusted_stocks
        # 债券和现金的比例
        bonds_ratio = remaining * (profile["bonds"] / (profile["bonds"] + profile["cash"])) if profile["bonds"] + profile["cash"] > 0 else 0
        cash_ratio = remaining - bonds_ratio
        
        return {
            "risk_profile": self.risk_profile,
            "age": self.age,
            "allocation": {
                "stocks": adjusted_stocks,
                "bonds": int(bonds_ratio),
                "cash": int(cash_ratio)
            },
            "description": profile["description"],
            "age_based_adjustment": f"基于{self.risk_profile}偏好和{self.age}岁年龄的建议"
        }
        
    def get_etf_recommendation(self) -> Dict:
        """获取ETF配置建议"""
        allocation = self.get_allocation()
        
        # ETF推荐
        etf_recommendations = {
            "stocks": ["沪深300ETF", "中证500ETF", "创业板ETF"],
            "bonds": ["国债ETF", "企业债ETF", "货币ETF"],
            "cash": ["货币ETF", "短期理财"]
        }
        
        return {
            "allocation": allocation["allocation"],
            "etf_recommendations": etf_recommendations
        }


def main():
    """主函数 - 示例用法"""
    # 创建优化器
    optimizer = PortfolioOptimizer(risk_free_rate=0.03)
    
    # 添加资产
    optimizer.add_asset(Asset(
        name="A股",
        asset_type="股票",
        expected_return=12,
        volatility=25,
        correlation={"A股": 1.0, "美股": 0.3, "债券": -0.1, "黄金": 0.2}
    ))
    
    optimizer.add_asset(Asset(
        name="美股",
        asset_type="股票",
        expected_return=10,
        volatility=20,
        correlation={"A股": 0.3, "美股": 1.0, "债券": 0.1, "黄金": 0.1}
    ))
    
    optimizer.add_asset(Asset(
        name="债券",
        asset_type="债券",
        expected_return=4,
        volatility=5,
        correlation={"A股": -0.1, "美股": 0.1, "债券": 1.0, "黄金": 0.3}
    ))
    
    optimizer.add_asset(Asset(
        name="黄金",
        asset_type="商品",
        expected_return=6,
        volatility=15,
        correlation={"A股": 0.2, "美股": 0.1, "债券": 0.3, "黄金": 1.0}
    ))
    
    # 优化：最大化夏普比率
    result = optimizer.optimize_max_sharpe()
    print("=== 最大化夏普比率组合 ===")
    print(f"权重: {result.weights}")
    print(f"预期收益: {result.expected_return * 100:.2f}%")
    print(f"波动率: {result.volatility * 100:.2f}%")
    print(f"夏普比率: {result.sharpe_ratio:.2f}")
    
    print("\n=== 最小波动率组合 ===")
    min_vol = optimizer.optimize_min_volatility()
    print(f"权重: {min_vol.weights}")
    print(f"预期收益: {min_vol.expected_return * 100:.2f}%")
    print(f"波动率: {min_vol.volatility * 100:.2f}%")
    print(f"夏普比率: {min_vol.sharpe_ratio:.2f}")
    
    # 资产配置示例
    print("\n=== 资产配置建议 ===")
    allocator = AssetAllocator(risk_profile="稳健型", age=35)
    print(json.dumps(allocator.get_allocation(), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
