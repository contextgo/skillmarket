"""
股票投资分析器
基于长期投资、价值投资原则的股票分析工具
"""

import json
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class StockData:
    """股票数据"""
    code: str
    name: str
    price: float
    eps: float  # 每股收益
    bvps: float  # 每股净资产
    dividend: float  # 每股股息
    dividend_growth_rate: float  # 股息增长率
    earnings_growth_rate: float  # 盈利增长率
    pe_ratio: float  # 市盈率
    pb_ratio: float  # 市净率
    roe: float  # 净资产收益率
    debt_ratio: float  # 资产负债率


class StockAnalyzer:
    """股票分析器"""
    
    def __init__(self, stock_code: str):
        self.stock_code = stock_code
        self.stock_data: Optional[StockData] = None
        
    def set_stock_data(self, data: Dict):
        """设置股票数据"""
        self.stock_data = StockData(**data)
        
    def analyze(self) -> Dict:
        """执行完整分析"""
        if not self.stock_data:
            return {"error": "请先设置股票数据"}
            
        return {
            "basic_analysis": self._basic_analysis(),
            "valuation": self._valuation_analysis(),
            "financial_health": self._financial_health(),
            "growth_assessment": self._growth_assessment(),
            "recommendation": self._generate_recommendation()
        }
        
    def _basic_analysis(self) -> Dict:
        """基本分析"""
        data = self.stock_data
        
        # 投资风格判断
        if data.pe_ratio < 15 and data.pb_ratio < 1.5:
            style = "价值型"
        elif data.eps > 0 and data.earnings_growth_rate > 15:
            style = "成长型"
        else:
            style = "平衡型"
            
        # 股息分析
        dividend_yield = (data.dividend / data.price) * 100 if data.price > 0 else 0
        
        return {
            "style": style,
            "dividend_yield": f"{dividend_yield:.2f}%",
            "pe_ratio": data.pe_ratio,
            "pb_ratio": data.pb_ratio,
            "roe": f"{data.roe * 100:.2f}%"
        }
        
    def _valuation_analysis(self) -> Dict:
        """估值分析"""
        data = self.stock_data
        
        # 市盈率估值
        # 合理市盈率根据风格调整
        if data.roe > 0.15:
            reasonable_pe = 20
        elif data.roe > 0.10:
            reasonable_pe = 15
        else:
            reasonable_pe = 10
            
        pe_fair_price = data.eps * reasonable_pe
        
        # 市净率估值
        reasonable_pb = 1.5
        pb_fair_price = data.bvps * reasonable_pb
        
        # 股息折现模型
        required_return = 0.08  # 必要收益率8%
        if data.dividend_growth_rate < required_return:
            ddm_price = data.dividend / (required_return - data.dividend_growth_rate)
        else:
            ddm_price = None
            
        # 综合估值
        prices = [p for p in [pe_fair_price, pb_fair_price, ddm_price] if p is not None]
        avg_price = sum(prices) / len(prices) if prices else 0
        
        # 安全边际
        margin_of_safety = (avg_price - data.price) / avg_price * 100 if avg_price > 0 else 0
        
        return {
            "pe_valuation": round(pe_fair_price, 2),
            "pb_valuation": round(pb_fair_price, 2),
            "ddm_valuation": round(ddm_price, 2) if ddm_price else "N/A",
            "average_fair_price": round(avg_price, 2),
            "current_price": data.price,
            "margin_of_safety": f"{margin_of_safety:.2f}%",
            "valuation_signal": "低估" if margin_of_safety > 20 else ("合理" if margin_of_safety > -10 else "高估")
        }
        
    def _financial_health(self) -> Dict:
        """财务健康分析"""
        data = self.stock_data
        
        # 资产负债率评估
        if data.debt_ratio < 0.4:
            debt_status = "优良"
        elif data.debt_ratio < 0.6:
            debt_status = "中等"
        else:
            debt_status = "风险较高"
            
        # ROE评估
        if data.roe > 0.15:
            roe_status = "优秀"
        elif data.roe > 0.10:
            roe_status = "良好"
        else:
            roe_status = "一般"
            
        return {
            "debt_ratio": f"{data.debt_ratio * 100:.2f}%",
            "debt_status": debt_status,
            "roe": f"{data.roe * 100:.2f}%",
            "roe_status": roe_status,
            "health_score": self._calculate_health_score()
        }
        
    def _calculate_health_score(self) -> int:
        """计算健康评分"""
        score = 0
        data = self.stock_data
        
        # 盈利能力 (40分)
        if data.roe > 0.15:
            score += 40
        elif data.roe > 0.10:
            score += 25
        else:
            score += 10
            
        # 财务稳健性 (30分)
        if data.debt_ratio < 0.4:
            score += 30
        elif data.debt_ratio < 0.6:
            score += 15
            
        # 股息保障 (30分)
        if data.dividend > 0:
            score += 15
        if data.dividend_growth_rate > 0:
            score += 15
            
        return score
        
    def _growth_assessment(self) -> Dict:
        """成长性评估"""
        data = self.stock_data
        
        if data.earnings_growth_rate > 0.20:
            growth_status = "高速增长"
        elif data.earnings_growth_rate > 0.10:
            growth_status = "稳定增长"
        elif data.earnings_growth_rate > 0:
            growth_status = "低速增长"
        else:
            growth_status = "负增长"
            
        return {
            "earnings_growth_rate": f"{data.earnings_growth_rate * 100:.2f}%",
            "growth_status": growth_status,
            "dividend_growth_rate": f"{data.dividend_growth_rate * 100:.2f}%"
        }
        
    def _generate_recommendation(self) -> Dict:
        """生成投资建议"""
        analysis = self.analyze()
        
        score = 0
        
        # 估值评分
        if analysis["valuation"]["valuation_signal"] == "低估":
            score += 30
        elif analysis["valuation"]["valuation_signal"] == "合理":
            score += 15
            
        # 财务健康评分
        health_score = analysis["financial_health"]["health_score"]
        score += health_score // 2
        
        # 成长性评分
        growth_rate = self.stock_data.earnings_growth_rate
        if growth_rate > 0.15:
            score += 20
        elif growth_rate > 0:
            score += 10
            
        # 生成建议
        if score >= 70:
            recommendation = "强烈推荐买入"
        elif score >= 50:
            recommendation = "建议买入"
        elif score >= 30:
            recommendation = "持有观望"
        else:
            recommendation = "建议回避"
            
        return {
            "score": score,
            "recommendation": recommendation,
            "reason": self._generate_reason(analysis)
        }
        
    def _generate_reason(self, analysis: Dict) -> List[str]:
        """生成推荐理由"""
        reasons = []
        
        val = analysis["valuation"]
        if val["valuation_signal"] == "低估":
            reasons.append(f"估值低估，安全边际{int(float(val['margin_of_safety'].strip('%')))}%")
            
        health = analysis["financial_health"]
        if health["health_score"] >= 60:
            reasons.append(f"财务健康，评分{health['health_score']}")
            
        growth = analysis["growth_assessment"]
        if "增长" in growth["growth_status"]:
            reasons.append(f"盈利{growth['growth_status']}")
            
        return reasons


def main():
    """主函数 - 示例用法"""
    # 示例：分析一只股票
    sample_data = {
        "code": "600519",
        "name": "贵州茅台",
        "price": 1800.0,
        "eps": 50.0,
        "bvps": 180.0,
        "dividend": 25.0,
        "dividend_growth_rate": 0.12,
        "earnings_growth_rate": 0.15,
        "pe_ratio": 36.0,
        "pb_ratio": 10.0,
        "roe": 0.28,
        "debt_ratio": 0.25
    }
    
    analyzer = StockAnalyzer("600519")
    analyzer.set_stock_data(sample_data)
    
    result = analyzer.analyze()
    print(json.dumps(result, ensure_ascii=False, indent=2))
    

if __name__ == "__main__":
    main()
