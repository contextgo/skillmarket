"""
估值计算工具
多种估值方法的实现
"""

import json
from typing import Dict, Optional


class ValuationCalculator:
    """估值计算器"""
    
    def __init__(self):
        pass
        
    def pe_valuation(self, eps: float, pe_ratio: float) -> Dict:
        """
        市盈率估值法
        eps: 每股收益
        pe_ratio: 市盈率
        """
        fair_price = eps * pe_ratio
        
        return {
            "method": "市盈率估值法(P/E)",
            "formula": "合理价格 = 每股收益 × 合理市盈率",
            "inputs": {
                "eps": eps,
                "pe_ratio": pe_ratio
            },
            "fair_price": round(fair_price, 2),
            "interpretation": self._interpret_pe(pe_ratio)
        }
        
    def _interpret_pe(self, pe_ratio: float) -> str:
        """解读市盈率"""
        if pe_ratio < 10:
            return "低市盈率，可能被低估或存在风险"
        elif pe_ratio < 20:
            return "合理市盈率范围"
        elif pe_ratio < 30:
            return "较高市盈率，需要高增长支撑"
        else:
            return "高市盈率，风险较大"
            
    def pb_valuation(self, bvps: float, pb_ratio: float) -> Dict:
        """
        市净率估值法
        bvps: 每股净资产
        pb_ratio: 市净率
        """
        fair_price = bvps * pb_ratio
        
        return {
            "method": "市净率估值法(P/B)",
            "formula": "合理价格 = 每股净资产 × 合理市净率",
            "inputs": {
                "bvps": bvps,
                "pb_ratio": pb_ratio
            },
            "fair_price": round(fair_price, 2),
            "interpretation": self._interpret_pb(pb_ratio)
        }
        
    def _interpret_pb(self, pb_ratio: float) -> str:
        """解读市净率"""
        if pb_ratio < 1:
            return "市净率低于1，可能被低估（价值股）或存在困境"
        elif pb_ratio < 3:
            return "合理市净率范围"
        elif pb_ratio < 5:
            return "较高市净率，需要强盈利能力支撑"
        else:
            return "高市净率，风险较大"
            
    def ddm_valuation(self, dividend: float, growth_rate: float, 
                      required_return: float = 0.08) -> Dict:
        """
        股息折现模型
        dividend: 当前股息
        growth_rate: 股息增长率
        required_return: 必要收益率
        """
        # Gordon增长模型
        if growth_rate >= required_return:
            return {
                "method": "股息折现模型(DDM)",
                "error": "股息增长率必须小于必要收益率",
                "inputs": {
                    "dividend": dividend,
                    "growth_rate": f"{growth_rate * 100}%",
                    "required_return": f"{required_return * 100}%"
                }
            }
            
        fair_price = dividend * (1 + growth_rate) / (required_return - growth_rate)
        
        return {
            "method": "股息折现模型(DDM)",
            "formula": "合理价格 = 股息 × (1+g) / (r-g)",
            "inputs": {
                "dividend": dividend,
                "growth_rate": f"{growth_rate * 100}%",
                "required_return": f"{required_return * 100}%"
            },
            "fair_price": round(fair_price, 2),
            "interpretation": self._interpret_ddm(required_return, growth_rate)
        }
        
    def _interpret_ddm(self, required_return: float, growth_rate: float) -> str:
        """解读DDM"""
        spread = required_return - growth_rate
        if spread > 0.05:
            return "高安全边际"
        elif spread > 0.03:
            return "合理估值"
        else:
            return "估值较高"
            
    def dcf_valuation(self, cash_flows: list, terminal_growth: float = 0.03,
                     discount_rate: float = 0.10) -> Dict:
        """
        现金流折现估值
        cash_flows: 未来各期现金流
        terminal_growth: 永续增长率
        discount_rate: 折现率
        """
        # 计算现值
        pv = 0
        for i, cf in enumerate(cash_flows, 1):
            pv += cf / ((1 + discount_rate) ** i)
            
        # 终值
        if len(cash_flows) > 0:
            terminal_value = cash_flows[-1] * (1 + terminal_growth) / (discount_rate - terminal_growth)
            terminal_pv = terminal_value / ((1 + discount_rate) ** len(cash_flows))
        else:
            terminal_pv = 0
            
        total_value = pv + terminal_pv
        
        return {
            "method": "现金流折现估值(DCF)",
            "formula": "价值 = Σ CFt/(1+r)^t + TV/(1+r)^n",
            "inputs": {
                "cash_flows": cash_flows,
                "terminal_growth": f"{terminal_growth * 100}%",
                "discount_rate": f"{discount_rate * 100}%"
            },
            "present_value": round(pv, 2),
            "terminal_value": round(terminal_value, 2),
            "terminal_pv": round(terminal_pv, 2),
            "total_fair_price": round(total_value, 2),
            "interpretation": "基于DCF模型的企业价值"
        }
        
    def graham_valuation(self, eps: float, bvps: float, 
                        required_return: float = 0.10,
                        growth_rate: float = 0.0) -> Dict:
        """
        格雷厄姆估值公式
        V = √(22.5 × EPS × BPS)
        或考虑成长性: V = EPS × (8.5 + 2g)
        """
        # 基础公式
        v1 = (22.5 * eps * bvps) ** 0.5
        
        # 成长性公式
        g = growth_rate * 100  # 转为百分比
        v2 = eps * (8.5 + 2 * g)
        
        # 综合
        fair_price = (v1 + v2) / 2
        
        return {
            "method": "格雷厄姆估值法",
            "formula": "V = √(22.5 × EPS × BPS) 或 V = EPS × (8.5 + 2g)",
            "inputs": {
                "eps": eps,
                "bvps": bvps,
                "required_return": f"{required_return * 100}%",
                "growth_rate": f"{growth_rate * 100}%"
            },
            "value_formula1": round(v1, 2),
            "value_formula2": round(v2, 2),
            "fair_price": round(fair_price, 2),
            "interpretation": "价值投资奠基人格雷厄姆的估值方法"
        }
        
    def peg_valuation(self, pe_ratio: float, growth_rate: float) -> Dict:
        """
        PEG估值法
        PEG = P/E / g
        """
        if growth_rate <= 0:
            return {
                "method": "PEG估值法",
                "error": "增长率必须为正"
            }
            
        peg = pe_ratio / (growth_rate * 100)
        
        interpretation = ""
        if peg < 0.5:
            interpretation = "严重低估"
        elif peg < 1:
            interpretation = "可能被低估"
        elif peg < 1.5:
            interpretation = "合理"
        else:
            interpretation = "可能高估"
            
        return {
            "method": "PEG估值法",
            "formula": "PEG = P/E / g",
            "inputs": {
                "pe_ratio": pe_ratio,
                "growth_rate": f"{growth_rate * 100}%"
            },
            "peg": round(peg, 2),
            "interpretation": interpretation,
            "note": "PEG=1为合理，<1可能被低估，>1可能高估"
        }
        
    def reverse_buyback_valuation(self, price: float, buyback_ratio: float,
                                   shares_reduced: float) -> Dict:
        """
        回购股数估值法
        用于估算回购对每股收益的影响
        """
        # 假设原EPS为1
        original_eps = 1.0
        
        # 回购后EPS
        new_eps = original_eps / (1 - buyback_ratio)
        
        # 估值提升
        pe_ratio_assumed = 15
        new_price = new_eps * pe_ratio_assumed
        
        return {
            "method": "回购股数影响估算",
            "formula": "新EPS = 原EPS / (1 - 回购比例)",
            "inputs": {
                "assumed_price": price,
                "buyback_ratio": f"{buyback_ratio * 100}%",
                "shares_reduced": shares_reduced
            },
            "original_eps": original_eps,
            "new_eps": round(new_eps, 2),
            "eps_increase": f"{(new_eps - original_eps) / original_eps * 100:.1f}%",
            "implied_price": round(new_price, 2),
            "interpretation": f"回购{int(buyback_ratio * 100)}%股份可提升EPS约{(new_eps/original_eps - 1) * 100:.1f}%"
        }


class MarginOfSafetyCalculator:
    """安全边际计算器"""
    
    def calculate(self, current_price: float, fair_price: float) -> Dict:
        """计算安全边际"""
        if fair_price <= 0:
            return {"error": "合理价格必须大于0"}
            
        margin = (fair_price - current_price) / fair_price * 100
        
        if margin > 30:
            signal = "非常大安全边际，建议买入"
        elif margin > 20:
            signal = "较大安全边际，可以买入"
        elif margin > 10:
            signal = "有一定安全边际，谨慎买入"
        elif margin > 0:
            signal = "安全边际较小，观望为主"
        else:
            signal = "没有安全边际，建议回避"
            
        return {
            "current_price": current_price,
            "fair_price": round(fair_price, 2),
            "margin_of_safety": f"{margin:.2f}%",
            "signal": signal,
            "recommendation": "买入" if margin > 20 else ("持有" if margin > 10 else "观望")
        }
        
    def calculate_target_price(self, current_price: float, 
                               target_margin: float = 20) -> Dict:
        """计算目标买入价格"""
        target_price = current_price * (1 - target_margin / 100)
        
        return {
            "current_price": current_price,
            "target_margin": f"{target_margin}%",
            "target_buy_price": round(target_price, 2),
            "potential_upside": f"{target_margin}%"
        }


def main():
    """示例用法"""
    calc = ValuationCalculator()
    
    print("=== 市盈率估值 ===")
    print(json.dumps(calc.pe_valuation(eps=2.5, pe_ratio=15), ensure_ascii=False, indent=2))
    
    print("\n=== 市净率估值 ===")
    print(json.dumps(calc.pb_valuation(bvps=10, pb_ratio=2), ensure_ascii=False, indent=2))
    
    print("\n=== 股息折现模型 ===")
    print(json.dumps(calc.ddm_valuation(dividend=0.5, growth_rate=0.05, required_return=0.10), 
                    ensure_ascii=False, indent=2))
    
    print("\n=== 格雷厄姆估值 ===")
    print(json.dumps(calc.graham_valuation(eps=2.5, bvps=10, growth_rate=0.08), 
                    ensure_ascii=False, indent=2))
    
    print("\n=== PEG估值 ===")
    print(json.dumps(calc.peg_valuation(pe_ratio=20, growth_rate=0.15), 
                    ensure_ascii=False, indent=2))
    
    print("\n=== 安全边际计算 ===")
    safety = MarginOfSafetyCalculator()
    print(json.dumps(safety.calculate(current_price=100, fair_price=130), 
                    ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
