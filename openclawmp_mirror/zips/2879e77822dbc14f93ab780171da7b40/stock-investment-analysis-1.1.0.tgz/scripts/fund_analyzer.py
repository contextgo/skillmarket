"""
基金分析器
基于晨星评级、基金规模、费用率等因素的基金分析工具
"""

import json
from dataclasses import dataclass
from typing import Dict, List, Optional


@dataclass
class FundData:
    """基金数据"""
    code: str
    name: str
    nav: float  # 单位净值
    total_asset: float  # 资产规模(亿元)
    fee_manager: float  # 管理费率
    fee_custodian: float  # 托管费率
    fee_sales: float  # 销售服务费率
    fee_buy: float  # 申购费率
    fee_redemption: float  # 赎回费率
    manager_name: str  # 基金经理
    manager_tenure_years: float  # 任职年限
    annual_return_1y: float  # 近1年收益率
    annual_return_3y: float  # 近3年收益率
    annual_return_5y: float  # 近5年收益率
    volatility: float  # 波动率
    sharpe_ratio: float  # 夏普比率
    max_drawdown: float  # 最大回撤
    morningstar_rating: int  # 晨星评级(1-5)


class FundAnalyzer:
    """基金分析器"""
    
    def __init__(self, fund_code: str):
        self.fund_code = fund_code
        self.fund_data: Optional[FundData] = None
        
    def set_fund_data(self, data: Dict):
        """设置基金数据"""
        self.fund_data = FundData(**data)
        
    def analyze(self) -> Dict:
        """执行完整分析"""
        if not self.fund_data:
            return {"error": "请先设置基金数据"}
            
        return {
            "cost_analysis": self._cost_analysis(),
            "performance_analysis": self._performance_analysis(),
            "risk_analysis": self._risk_analysis(),
            "manager_analysis": self._manager_analysis(),
            "size_analysis": self._size_analysis(),
            "morningstar_analysis": self._morningstar_analysis(),
            "recommendation": self._generate_recommendation()
        }
        
    def _cost_analysis(self) -> Dict:
        """费用分析"""
        data = self.fund_data
        
        # 总年化费用率
        total_annual_cost = data.fee_manager + data.fee_custodian + data.fee_sales
        
        # 费用评估
        if total_annual_cost < 0.5:
            cost_rating = "低"
        elif total_annual_cost < 1.0:
            cost_rating = "中等"
        else:
            cost_rating = "高"
            
        return {
            "total_annual_cost": f"{total_annual_cost:.2f}%",
            "management_fee": f"{data.fee_manager:.2f}%",
            "custodian_fee": f"{data.fee_custodian:.2f}%",
            "sales_fee": f"{data.fee_sales:.2f}%",
            "buy_fee": f"{data.fee_buy:.2f}%",
            "redemption_fee": f"{data.fee_redemption:.2f}%",
            "cost_rating": cost_rating,
            "cost_impact": self._calculate_cost_impact(total_annual_cost)
        }
        
    def _calculate_cost_impact(self, annual_cost: float) -> str:
        """计算费用对收益的影响"""
        # 假设投资10万元，持有10年
        investment = 100000
        years = 10
        # 假设年化收益7%
        gross_return = investment * ((1 + 0.07) ** years - 1)
        # 扣除费用后的收益
        net_return = investment * ((1 + 0.07 - annual_cost/100) ** years - 1)
        # 费用造成的损失
        cost_loss = gross_return - net_return
        
        return f"10年预计损失约{int(cost_loss)}元"
        
    def _performance_analysis(self) -> Dict:
        """业绩分析"""
        data = self.fund_data
        
        # 计算综合业绩得分
        score = 0
        
        # 近1年业绩 (20分)
        if data.annual_return_1y > 20:
            score += 20
        elif data.annual_return_1y > 10:
            score += 15
        elif data.annual_return_1y > 0:
            score += 10
            
        # 近3年业绩 (30分)
        if data.annual_return_3y > 50:
            score += 30
        elif data.annual_return_3y > 30:
            score += 20
        elif data.annual_return_3y > 0:
            score += 10
            
        # 近5年业绩 (30分)
        if data.annual_return_5y > 100:
            score += 30
        elif data.annual_return_5y > 50:
            score += 20
        elif data.annual_return_5y > 0:
            score += 10
            
        # 业绩持续性 (20分)
        if data.annual_return_3y > data.annual_return_1y:
            score += 10
        if data.annual_return_5y > data.annual_return_3y:
            score += 10
            
        # 业绩评级
        if score >= 80:
            performance_rating = "优秀"
        elif score >= 60:
            performance_rating = "良好"
        elif score >= 40:
            performance_rating = "中等"
        else:
            performance_rating = "一般"
            
        return {
            "return_1y": f"{data.annual_return_1y:.2f}%",
            "return_3y": f"{data.annual_return_3y:.2f}%",
            "return_5y": f"{data.annual_return_5y:.2f}%",
            "performance_score": score,
            "performance_rating": performance_rating,
            "consistency": "稳定" if score > 60 else "波动较大"
        }
        
    def _risk_analysis(self) -> Dict:
        """风险分析"""
        data = self.fund_data
        
        # 风险评分
        risk_score = 0
        
        # 波动率 (30分)
        if data.volatility < 10:
            risk_score += 30
        elif data.volatility < 20:
            risk_score += 20
        elif data.volatility < 30:
            risk_score += 10
            
        # 最大回撤 (40分)
        if data.max_drawdown > -10:
            risk_score += 40
        elif data.max_drawdown > -20:
            risk_score += 25
        elif data.max_drawdown > -30:
            risk_score += 10
            
        # 夏普比率 (30分)
        if data.sharpe_ratio > 1.0:
            risk_score += 30
        elif data.sharpe_ratio > 0.5:
            risk_score += 20
        elif data.sharpe_ratio > 0:
            risk_score += 10
            
        # 风险评级
        if risk_score >= 80:
            risk_rating = "低风险"
        elif risk_score >= 60:
            risk_rating = "中等风险"
        else:
            risk_rating = "较高风险"
            
        return {
            "volatility": f"{data.volatility:.2f}%",
            "max_drawdown": f"{data.max_drawdown:.2f}%",
            "sharpe_ratio": round(data.sharpe_ratio, 2),
            "risk_score": risk_score,
            "risk_rating": risk_rating
        }
        
    def _manager_analysis(self) -> Dict:
        """基金经理分析"""
        data = self.fund_data
        
        # 经理评分
        score = 0
        
        # 任职年限 (50分)
        if data.manager_tenure_years >= 10:
            score += 50
        elif data.manager_tenure_years >= 5:
            score += 35
        elif data.manager_tenure_years >= 3:
            score += 20
        else:
            score += 10
            
        # 评级
        if score >= 40:
            manager_rating = "优秀"
        elif score >= 25:
            manager_rating = "良好"
        else:
            manager_rating = "一般"
            
        return {
            "manager_name": data.manager_name,
            "tenure_years": f"{data.manager_tenure_years:.1f}年",
            "manager_score": score,
            "manager_rating": manager_rating
        }
        
    def _size_analysis(self) -> Dict:
        """规模分析"""
        data = self.fund_data
        
        # 规模评级
        if data.total_asset > 500:
            size_rating = "超大规模"
            size_signal = "可能影响灵活性"
        elif data.total_asset > 100:
            size_rating = "大规模"
            size_signal = "正常范围"
        elif data.total_asset > 20:
            size_rating = "中等规模"
            size_signal = "较好"
        else:
            size_rating = "小规模"
            size_signal = "需关注清盘风险"
            
        return {
            "total_asset": f"{data.total_asset:.2f}亿元",
            "size_rating": size_rating,
            "size_signal": size_signal
        }
        
    def _morningstar_analysis(self) -> Dict:
        """晨星评级分析"""
        data = self.fund_data
        
        rating = data.morningstar_rating
        rating_desc = {
            5: "五星级 - 最高评级",
            4: "四星级 - 优秀",
            3: "三星级 - 中等",
            2: "二星级 - 较低",
            1: "一星级 - 最低"
        }
        
        return {
            "rating": rating,
            "rating_desc": rating_desc.get(rating, "未评级"),
            "is_top_rating": rating >= 4
        }
        
    def _generate_recommendation(self) -> Dict:
        """生成投资建议"""
        analysis = self.analyze()
        
        score = 0
        
        # 业绩得分 (40分)
        score += analysis["performance_analysis"]["performance_score"] * 0.4
        
        # 风险得分 (25分)
        score += analysis["risk_analysis"]["risk_score"] * 0.25
        
        # 经理得分 (15分)
        score += analysis["manager_analysis"]["manager_score"] * 0.15
        
        # 晨星评级 (20分)
        score += analysis["morningstar_analysis"]["rating"] * 4
        
        # 生成建议
        if score >= 70:
            recommendation = "强烈推荐"
        elif score >= 55:
            recommendation = "建议买入"
        elif score >= 40:
            recommendation = "持有观望"
        else:
            recommendation = "建议回避"
            
        return {
            "score": round(score, 1),
            "recommendation": recommendation,
            "pros": self._generate_pros(analysis),
            "cons": self._generate_cons(analysis)
        }
        
    def _generate_pros(self, analysis: Dict) -> List[str]:
        """生成优势"""
        pros = []
        
        if analysis["morningstar_analysis"]["is_top_rating"]:
            pros.append("晨星高评级")
            
        if analysis["performance_analysis"]["performance_rating"] in ["优秀", "良好"]:
            pros.append("业绩优秀")
            
        if analysis["cost_analysis"]["cost_rating"] == "低":
            pros.append("费用低廉")
            
        if analysis["manager_analysis"]["manager_rating"] == "优秀":
            pros.append("优秀基金经理")
            
        if analysis["risk_analysis"]["risk_rating"] == "低风险":
            pros.append("风险控制良好")
            
        return pros
        
    def _generate_cons(self, analysis: Dict) -> List[str]:
        """生成劣势"""
        cons = []
        
        if analysis["size_analysis"]["size_rating"] == "超大规模":
            cons.append("规模过大可能影响灵活性")
            
        if analysis["cost_analysis"]["cost_rating"] == "高":
            cons.append("费用较高")
            
        if analysis["risk_analysis"]["risk_rating"] == "较高风险":
            cons.append("风险较高")
            
        return cons


class FundComparator:
    """基金对比器"""
    
    def __init__(self):
        self.funds: List[FundAnalyzer] = []
        
    def add_fund(self, fund_data: Dict):
        """添加基金"""
        code = fund_data["code"]
        analyzer = FundAnalyzer(code)
        analyzer.set_fund_data(fund_data)
        self.funds.append(analyzer)
        
    def compare(self) -> Dict:
        """对比分析"""
        if not self.funds:
            return {"error": "请先添加基金"}
            
        results = []
        for fund in self.funds:
            analysis = fund.analyze()
            results.append({
                "code": fund.fund_code,
                "name": fund.fund_data.name,
                "score": analysis["recommendation"]["score"],
                "recommendation": analysis["recommendation"]["recommendation"]
            })
            
        # 按评分排序
        results.sort(key=lambda x: x["score"], reverse=True)
        
        return {
            "rankings": results,
            "recommended": results[0] if results else None
        }


def main():
    """主函数 - 示例用法"""
    # 示例：分析一只基金
    sample_data = {
        "code": "110011",
        "name": "易方达消费行业股票",
        "nav": 3.4567,
        "total_asset": 350.5,
        "fee_manager": 1.5,
        "fee_custodian": 0.25,
        "fee_sales": 0.0,
        "fee_buy": 1.5,
        "fee_redemption": 0.5,
        "manager_name": "张坤",
        "manager_tenure_years": 8.5,
        "annual_return_1y": 15.5,
        "annual_return_3y": 65.8,
        "annual_return_5y": 128.3,
        "volatility": 18.5,
        "sharpe_ratio": 0.85,
        "max_drawdown": -18.2,
        "morningstar_rating": 5
    }
    
    analyzer = FundAnalyzer("110011")
    analyzer.set_fund_data(sample_data)
    
    result = analyzer.analyze()
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
