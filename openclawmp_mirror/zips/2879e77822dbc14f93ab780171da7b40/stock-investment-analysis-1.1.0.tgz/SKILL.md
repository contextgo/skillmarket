---
name: stock-investment-analysis
description: 股票投资分析技能 - 基于长期投资、资产配置、指数化投资等核心原则的系统性投资分析工具
---

# 股票投资分析技能

## 技能概述

本技能提供系统性的股票投资分析能力，基于长期投资、资产配置、指数化投资等核心投资原则，帮助投资者进行科学的投资决策。

## 核心投资原则

### 1. 长期投资
- 坚持长期持有策略，避免短期投机
- 复利效应是财富增长的核心动力
- 忽视市场短期波动，专注长期价值

### 2. 回报的本质
- 投资收益来源于企业盈利增长
- 理解股息再投资的复利效应
- 区分价格波动与实际回报

### 3. 资产配置
- 根据风险承受能力确定资产配置比例
- 股债平衡是基础配置策略
- 定期再平衡维持目标配置

### 4. 投资简单化
- 避免复杂投资策略
- 坚持能力圈原则
- 专注简单易懂的投资标的

### 5. 指数化投资
- 被动投资优于主动投资
- 低成本是长期收益的关键
- 分散投资降低非系统性风险

## 分析框架

### 股票投资风格分析
- 价值型：低市盈率、低市净率
- 成长型：高盈利增长率、高市盈率
- 平衡型：兼顾价值与成长

### 估值方法
```python
# 市盈率法 (P/E)
fair_price = earnings_per_share * reasonable_pe

# 市净率法 (P/B)
fair_price = book_value_per_share * reasonable_pb

# 股息折现模型
fair_price = dividend_per_share / (required_return - dividend_growth_rate)
```

### 风险评估
- 市场风险（系统性风险）
- 行业风险
- 个股风险
- 流动性风险

## 投资决策流程

### 1. 行业分析
- 行业生命周期判断
- 行业竞争格局分析
- 政策影响评估

### 2. 公司分析
- 商业模式评估
- 竞争优势识别
- 财务健康度检查

### 3. 估值分析
- 相对估值法
- 绝对估值法
- 安全边际计算

### 4. 买入策略
- 分批建仓策略
- 定投策略
- 回调买入策略

## 基金分析功能

### 基金筛选指标
- 基金业绩持续性
- 基金经理能力
- 基金规模影响
- 费用率影响

### 晨星评级应用
- 五星基金筛选标准
- 晨星评级局限性
- 综合评估方法

## 使用示例

### 基本股票分析
```python
from stock_analyzer import StockAnalyzer

analyzer = StockAnalyzer("股票代码")
analysis = analyzer.run_analysis()
print(analysis["recommendation"])
```

### 基金对比分析
```python
from fund_analyzer import FundComparator

comparator = FundComparator()
result = comparator.compare(["基金代码1", "基金代码2"])
print(result["recommended_fund"])
```

### 资产配置建议
```python
from asset_allocator import AssetAllocator

allocator = AssetAllocator(risk_profile="稳健型")
allocation = allocator.get_allocation()
print(allocation)
```

## 分析脚本

### scripts/stock_analyzer.py
股票基本面分析脚本

### scripts/fund_analyzer.py
基金分析筛选脚本

### scripts/portfolio_optimizer.py
投资组合优化脚本

### scripts/value_calculator.py
估值计算工具脚本

## 参考文档

### references/investment_principles.md
详细投资原则说明 - 包含长期投资、资产配置、指数化投资等核心原则

### references/valuation_methods.md
估值方法详解 - 包含市盈率、市净率、DDM、DCF等估值方法

### references/risk_management.md
风险管理指南 - 包含风险识别、风险评估、风险控制方法

## 模板资源

### templates/stock_analysis_template.md
股票分析报告模板 - 完整的股票分析报告框架

### templates/fund_selection_template.md
基金筛选模板 - 基金对比筛选分析框架

### templates/portfolio_template.md
投资组合管理模板 - 资产配置和持仓管理框架

## 技能文件结构

```
stock-investment-analysis/
├── SKILL.md                    # 技能主文件
├── scripts/                     # 分析脚本
│   ├── stock_analyzer.py       # 股票分析器
│   ├── fund_analyzer.py        # 基金分析器
│   ├── portfolio_optimizer.py  # 投资组合优化器
│   └── value_calculator.py     # 估值计算器
├── references/                  # 参考文档
│   └── investment_principles.md # 投资核心原则
└── templates/                   # 模板资源
    ├── stock_analysis_template.md    # 股票分析模板
    ├── fund_selection_template.md    # 基金筛选模板
    └── portfolio_template.md         # 投资组合模板
```

---
**技能版本**: 1.1
**创建日期**: 2026年3月18日
**更新内容**: 
- 新增股票分析脚本
- 新增基金分析脚本
- 新增投资组合优化器
- 新增估值计算工具
- 新增分析模板
- 新增投资原则参考文档
**适用对象**: 个人投资者、基金投资者
