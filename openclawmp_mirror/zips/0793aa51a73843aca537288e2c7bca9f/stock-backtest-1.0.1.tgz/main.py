#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
策略回测工具
股票策略回测、绩效分析
"""

import json
from datetime import datetime

import akshare as ak
import numpy as np
import pandas as pd


class Backtest:
    """回测引擎"""
    
    def __init__(self, initial_capital=100000):
        self.initial_capital = initial_capital
        self.capital = initial_capital
        self.position = 0
        self.trades = []
        self.daily_values = []
    
    def get_data(self, code, start_date, end_date):
        """获取历史数据"""
        try:
            df = ak.stock_zh_a_hist(symbol=code, period="daily", 
                                    start_date=start_date.replace("-", ""), 
                                    end_date=end_date.replace("-", ""), 
                                    adjust="qfq")
            return df
        except Exception as e:
            print(f"获取数据失败: {e}")
            return None
    
    def ma_cross_strategy(self, df, short=5, long=20):
        """
        均线交叉策略
        
        Args:
            df: 历史数据
            short: 短期均线
            long: 长期均线
            
        Returns:
            list: 交易信号
        """
        df['MA_short'] = df['收盘'].rolling(window=short).mean()
        df['MA_long'] = df['收盘'].rolling(window=long).mean()
        
        signals = []
        for i in range(1, len(df)):
            if df['MA_short'].iloc[i] > df['MA_long'].iloc[i] and df['MA_short'].iloc[i-1] <= df['MA_long'].iloc[i-1]:
                signals.append({'date': df['日期'].iloc[i], 'type': 'buy', 'price': df['收盘'].iloc[i]})
            elif df['MA_short'].iloc[i] < df['MA_long'].iloc[i] and df['MA_short'].iloc[i-1] >= df['MA_long'].iloc[i-1]:
                signals.append({'date': df['日期'].iloc[i], 'type': 'sell', 'price': df['收盘'].iloc[i]})
        
        return signals
    
    def run_backtest(self, code, start_date, end_date, strategy="MA_CROSS"):
        """
        运行回测
        
        Args:
            code: 股票代码
            start_date: 开始日期
            end_date: 结束日期
            strategy: 策略名称
            
        Returns:
            dict: 回测结果
        """
        df = self.get_data(code, start_date, end_date)
        if df is None:
            return None
        
        # 生成交易信号
        if strategy == "MA_CROSS":
            signals = self.ma_cross_strategy(df)
        else:
            print(f"未知策略: {strategy}")
            return None
        
        # 执行交易
        for signal in signals:
            if signal['type'] == 'buy' and self.position == 0:
                shares = int(self.capital / signal['price'] / 100) * 100  # 整手买入
                if shares > 0:
                    cost = shares * signal['price']
                    self.capital -= cost
                    self.position = shares
                    self.trades.append({
                        'date': signal['date'],
                        'type': 'buy',
                        'price': signal['price'],
                        'shares': shares,
                        'amount': cost
                    })
            
            elif signal['type'] == 'sell' and self.position > 0:
                revenue = self.position * signal['price']
                self.capital += revenue
                self.trades.append({
                    'date': signal['date'],
                    'type': 'sell',
                    'price': signal['price'],
                    'shares': self.position,
                    'amount': revenue
                })
                self.position = 0
        
        # 计算最终价值
        final_price = df['收盘'].iloc[-1]
        final_value = self.capital + self.position * final_price
        
        # 计算收益率
        total_return = (final_value - self.initial_capital) / self.initial_capital * 100
        
        # 计算年化收益率
        days = len(df)
        annual_return = ((1 + total_return/100) ** (365/days) - 1) * 100 if days > 0 else 0
        
        # 计算最大回撤
        df['value'] = self.initial_capital * (1 + df['收盘'].pct_change().cumsum())
        df['cummax'] = df['value'].cummax()
        df['drawdown'] = (df['value'] - df['cummax']) / df['cummax']
        max_drawdown = df['drawdown'].min() * 100
        
        result = {
            "code": code,
            "strategy": strategy,
            "start_date": start_date,
            "end_date": end_date,
            "initial_capital": self.initial_capital,
            "final_value": round(final_value, 2),
            "total_return": f"{total_return:.2f}%",
            "annual_return": f"{annual_return:.2f}%",
            "max_drawdown": f"{max_drawdown:.2f}%",
            "trade_count": len(self.trades),
            "trades": self.trades
        }
        
        return result
    
    def generate_report(self, result):
        """生成绩效报告"""
        if result is None:
            return
        
        print("=" * 50)
        print("策略回测报告")
        print("=" * 50)
        print(f"股票代码: {result['code']}")
        print(f"策略: {result['strategy']}")
        print(f"回测区间: {result['start_date']} ~ {result['end_date']}")
        print("-" * 50)
        print(f"初始资金: {result['initial_capital']}")
        print(f"最终价值: {result['final_value']}")
        print(f"总收益率: {result['total_return']}")
        print(f"年化收益率: {result['annual_return']}")
        print(f"最大回撤: {result['max_drawdown']}")
        print(f"交易次数: {result['trade_count']}")
        print("=" * 50)
        
        if result['trades']:
            print("\n交易记录:")
            for trade in result['trades']:
                print(f"  {trade['date']} {trade['type'].upper()} {trade['shares']}股 @ {trade['price']}")


def main():
    """CLI 入口"""
    import fire
    
    bt = Backtest()
    
    def run(strategy="MA_CROSS", start="2023-01-01", end="2024-01-01", code="000001"):
        """运行回测"""
        result = bt.run_backtest(code, start, end, strategy)
        if result:
            bt.generate_report(result)
            # 保存结果
            with open("backtest_result.json", "w", encoding="utf-8") as f:
                json.dump(result, f, ensure_ascii=False, indent=2)
            print("\n结果已保存到 backtest_result.json")
        else:
            print("回测失败")
    
    def report(result_file="backtest_result.json"):
        """查看报告"""
        try:
            with open(result_file, "r", encoding="utf-8") as f:
                result = json.load(f)
            bt.generate_report(result)
        except Exception as e:
            print(f"读取结果失败: {e}")
    
    fire.Fire({
        "run": run,
        "report": report,
    })


if __name__ == "__main__":
    main()
