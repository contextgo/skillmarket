# 策略回测 (stock-backtest)

策略回测 Skill，股票策略回测、绩效分析、参数优化。

## 功能

- 策略回测
- 绩效指标计算
- 收益率曲线
- 风险分析

## 使用

```bash
# 回测策略
python main.py run --strategy MA_CROSS --start 2023-01-01 --end 2024-01-01 --code 000001

# 绩效分析
python main.py report --result backtest_result.json
```

## 依赖

- akshare
- pandas
- numpy

## License

MIT
