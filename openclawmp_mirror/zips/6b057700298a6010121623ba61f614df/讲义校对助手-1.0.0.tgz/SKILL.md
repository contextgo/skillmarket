---
name: 讲义校对助手
displayName: 讲义校对助手
description: 自动校对教学讲义，找出错别字、语法错误、概念错误，生成详细校对报告。
version: 1.0.0
author: OpenClaw Edu
tags: [education, proofreading, document, teaching, quality]
category: education
---

# 讲义校对助手

自动校对教学讲义。

## 功能

- 错别字检测
- 语法检查
- 概念核查
- 术语一致性检查
- 生成校对报告

## 使用

```
@讲义校对助手 校对这份物理讲义，找出所有错误
```
