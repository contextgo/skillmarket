---
name: meeting-minutes-generator
description: '自动生成会议纪要，提取关键信息、行动项、决策点'
version: 1.0.0
type: skill
tags: ['meeting', 'minutes', 'productivity', 'automation', 'office']
---

# 会议纪要生成器

> 自动生成会议纪要，提取关键信息、行动项、决策点

## 功能

- 自动提取会议关键信息
- 识别行动项和负责人
- 记录决策点
- 生成结构化纪要
- 支持多种输出格式

## 使用方法

```bash
# 从文字记录生成
openclaw skill run meeting-minutes --text "会议记录内容"

# 从文件生成
openclaw skill run meeting-minutes --file "meeting.txt"

# 从语音转录生成
openclaw skill run meeting-minutes --audio "meeting.mp3"
```

## 输出格式

```markdown
# 会议纪要

## 基本信息
- **会议主题**：产品迭代规划
- **时间**：2024-03-15 14:00-15:30
- **地点**：会议室A
- **主持人**：张三
- **记录人**：李四

## 参会人员
- 张三（产品经理）
- 李四（技术负责人）
- 王五（设计师）

## 会议内容

### 1. 上周回顾
- 完成了用户调研
- 修复了3个关键bug

### 2. 本周计划
- 启动新功能开发
- 优化页面加载速度

## 决策点
- ✅ 确定使用React框架
- ✅ 下周一开始开发

## 行动项

| 任务 | 负责人 | 截止日期 | 优先级 |
|------|--------|----------|--------|
| 完成原型设计 | 王五 | 3月20日 | 高 |
| 搭建项目框架 | 李四 | 3月18日 | 高 |
| 编写需求文档 | 张三 | 3月17日 | 中 |

## 下次会议
- **时间**：3月22日 14:00
- **议题**：原型评审
```

## 安装

```bash
openclaw skill install meeting-minutes-generator
```
