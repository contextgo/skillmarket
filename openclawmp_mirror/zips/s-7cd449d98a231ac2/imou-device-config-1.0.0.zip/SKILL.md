---
name: imou-device-config
displayName: 乐橙设备配置
version: 1.0.0
description: >
  乐橙（Imou）设备通道安防配置管理。支持动检计划设置、动检灵敏度调节、隐私模式开关。
  针对物模型设备（productId非空），优先读取产品物模型定义，基于物模型完成设备配置（属性查询/设置、服务调用）。
  适用于：动检计划、动检灵敏度、隐私模式、物模型配置、属性查询/设置、事件下发等场景。
metadata:
  {
    "openclaw":
      {
        "emoji": "⚙️",
        "requires": { "env": ["IMOU_APP_ID", "IMOU_APP_SECRET"], "pip": ["requests"] },
        "primaryEnv": "IMOU_APP_ID",
        "install":
          [
            { "id": "python-requests", "kind": "pip", "package": "requests", "label": "安装 requests 依赖" }
          ]
      }
  }
---

# ⚙️ 乐橙设备配置

管理乐橙设备通道的安防配置：动检计划、动检灵敏度、隐私模式（镜头遮蔽）。支持 PaaS 设备（productId为空）和 IoT 物模型设备（productId非空）。**针对物模型设备，优先读取产品物模型定义，基于物模型完成所有设备配置**（属性查询/设置、服务调用）。

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install requests
```

### 2. 配置环境变量（必填）

```bash
export IMOU_APP_ID="你的应用ID"
export IMOU_APP_SECRET="你的应用密钥"
export IMOU_BASE_URL="API基础地址"
```

**API 基础地址说明：**

| 区域 | 数据中心 | 基础地址 |
|------|---------|---------|
| 中国大陆 | — | `https://openapi.lechange.cn` |
| 海外 | 东亚 | `https://openapi-sg.easy4ip.com:443` |
| 海外 | 中欧 | `https://openapi-fk.easy4ip.com:443` |
| 海外 | 美西 | `https://openapi-or.easy4ip.com:443` |

**如何获取 App ID 和 App Secret：**
- 访问 [乐橙开放平台](https://open.imou.com) 注册开发者账号
- 进入「应用管理」-「应用信息」获取 `appId` 和 `appSecret`

### 3. 运行命令

**PaaS 设备（productId为空）：**

```bash
# 查询通道动检计划
python3 {baseDir}/scripts/device_config.py plan get 设备序列号 通道ID

# 设置动检计划（period: 周期, beginTime/endTime: 时间 HH:mm:ss）
python3 {baseDir}/scripts/device_config.py plan set 设备序列号 通道ID --rules '[{"period":"Monday,Tuesday","beginTime":"08:00:00","endTime":"18:00:00"}]'

# 设置动检灵敏度（1-5，1最低，5最高）
python3 {baseDir}/scripts/device_config.py sensitivity set 设备序列号 通道ID 3

# 查询隐私模式（镜头遮蔽）状态
python3 {baseDir}/scripts/device_config.py privacy get 设备序列号 通道ID

# 开启/关闭隐私模式
python3 {baseDir}/scripts/device_config.py privacy set 设备序列号 通道ID on
python3 {baseDir}/scripts/device_config.py privacy set 设备序列号 通道ID off
```

**IoT 物模型设备（productId非空）：**

```bash
# 步骤1：读取产品物模型（必需，获取属性/服务引用标识）
python3 {baseDir}/scripts/device_config.py iot model 产品ID [--verbose] [--json]

# 步骤2：基于物模型进行属性查询/设置和服务调用
# 属性查询（refs 来自物模型）
python3 {baseDir}/scripts/device_config.py iot property-get 产品ID 设备序列号 '["3301","3302"]' [--json]

# 属性设置
python3 {baseDir}/scripts/device_config.py iot property-set 产品ID 设备序列号 '{"3301":1,"3302":2}'

# 服务调用（事件/命令）
python3 {baseDir}/scripts/device_config.py iot service 产品ID 设备序列号 服务引用 [--content '{}']
```

## ✨ 功能特性

1. **动检计划**：按通道获取或设置报警计划（PaaS）。规则包含周期（周一至周日）、开始时间、结束时间（HH:mm:ss）
2. **动检灵敏度**：设置通道灵敏度等级 1-5（PaaS）
3. **隐私模式**：按通道获取或设置镜头遮蔽开关（PaaS）
4. **IoT 物模型**：针对 productId 非空设备，**先读取产品物模型**，然后基于模型定义进行**属性查询**（按模型引用标识获取）、**属性设置**（按模型设置引用-值）、**事件/命令**（按模型调用服务）。配置由物模型定义驱动，引用标识和能力必须从模型解析

## 📊 设备类型与配置策略

- **productId 为空（PaaS 设备）**：使用使能类 API（`getDeviceCameraStatus` / `setDeviceCameraStatus`）、`deviceAlarmPlan`、`modifyDeviceAlarmPlan`、`setDeviceAlarmSensitivity`。仅 `accessType=PaaS` 的设备支持
- **productId 非空（物模型设备）**：**优先读取产品物模型**（`iot model 产品ID`）。所有设备配置（属性查询/设置、事件/命令下发）**基于物模型定义**执行：使用物模型中的属性引用和服务引用进行 `iot property-get`、`iot property-set` 和 `iot service`。不假设引用标识，始终从产品模型解析

## 📡 请求标识

所有请求都会携带请求头 `Client-Type: OpenClaw`，用于平台识别。

## 📚 API 参考文档

| 接口 | 文档地址 |
|-----|---------|
| 开发规范 | https://open.imou.com/document/pages/c20750/ |
| 获取 accessToken | https://open.imou.com/document/pages/fef620/ |
| 使能定义 | https://open.imou.com/document/pages/389c19/ |
| 设置使能 | https://open.imou.com/document/pages/8214a7/ |
| 获取使能 | https://open.imou.com/document/pages/2e535e/ |
| 获取动检计划 | https://open.imou.com/document/pages/4d571d/ |
| 设置动检计划 | https://open.imou.com/document/pages/542ccc/ |
| 设置动检灵敏度 | https://open.imou.com/document/pages/83f1b4/ |
| IoT 物模型概述 | https://open.imou.com/document/pages/1acdf4/ |
| 获取产品物模型 | https://open.imou.com/document/pages/2a238c/ |
| 获取 IoT 属性 | https://open.imou.com/document/pages/919bcf/ |
| 设置 IoT 属性 | https://open.imou.com/document/pages/532cdf/ |
| IoT 服务调用 | https://open.imou.com/document/pages/fa0726/ |

更多请求/响应格式详见 `references/imou-config-api.md`

## 💡 使用提示

- **Token 有效期**：每次运行自动获取，有效期3天。如需跨运行缓存，请自行实现过期处理逻辑
- **使能类型**：隐私模式使用 `closeCamera`（通道级）。动检使能使用 `motionDetect`（通道级）。详见使能定义文档
- **动检计划规则**：每条规则包含 `period`（如 "Monday" 或 "Monday,Wednesday,Friday"）、`beginTime`、`endTime`（HH:mm:ss）
- **物模型优先**：对于 productId 非空设备，始终先读取产品物模型（`iot model 产品ID`）；然后使用物模型的属性/服务定义（引用标识、数据类型、输入/输出数据）进行所有查询/设置和服务调用。不要跨产品硬编码引用标识
- **IoT 引用标识**：属性和服务引用标识是字符串（如 "3301"），来自物模型。布尔属性设置时用 0/1。服务 `content` 是按模型的输入参数，无输入时用 `{}`

## 🔒 数据流向说明

| 数据 | 发送至 | 用途 |
|-----|-------|-----|
| appId, appSecret | 乐橙开放平台 | 获取 accessToken |
| accessToken, deviceId, channelId, productId 等 | 乐橙开放平台 | 查询/设置计划、灵敏度、使能；IoT 物模型、属性查询/设置、服务调用 |

所有请求仅发送至配置的 `IMOU_BASE_URL`（乐橙官方API），不涉及第三方。
