---
name: 作文批改助手
displayName: 作文批改助手
description: 自动批改学生作文，找出错别字、拼音错误、语法问题，生成批改报告。
version: 1.0.0
author: OpenClaw Edu
tags: [education, essay, correction, chinese, teaching]
category: education
---

# 作文批改助手

自动批改学生作文。

## 功能

- OCR识别手写作文
- 错别字检测
- 拼音错误检查
- 语法问题标记
- 生成批改报告

## 使用

```
@作文批改助手 批改这篇三年级作文
```
