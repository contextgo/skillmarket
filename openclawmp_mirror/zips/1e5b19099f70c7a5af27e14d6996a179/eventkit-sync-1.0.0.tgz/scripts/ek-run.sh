#!/bin/bash
# Compile ek-sync.swift if needed, then run it
# Usage: echo '<json>' | bash ek-run.sh <action> [flags]
# Actions: create, list, update, delete, search
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
BIN="/tmp/ek-sync"
SRC="$SCRIPT_DIR/ek-sync.swift"

if [ ! -f "$BIN" ] || [ "$SRC" -nt "$BIN" ]; then
  swiftc "$SRC" -o "$BIN" -framework EventKit 2>&1
  if [ $? -ne 0 ]; then echo "ERROR: Swift compilation failed"; exit 1; fi
fi

cat | "$BIN" "$@"
