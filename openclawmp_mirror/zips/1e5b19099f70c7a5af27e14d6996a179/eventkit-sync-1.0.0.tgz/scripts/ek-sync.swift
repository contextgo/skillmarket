#!/usr/bin/env swift
// EventKit Sync - Full CRUD for Calendar events and Reminders
// Usage: echo '<json>' | swift ek-sync.swift <action> [flags]
// Actions: create, list, update, delete
// Flags: --events, --reminders, --calendar NAME, --reminder-list NAME, --dry-run

import EventKit
import Foundation

// MARK: - Arg parsing
let allArgs = Array(CommandLine.arguments.dropFirst())
let action = allArgs.first ?? "create"
var doEvents = false
var doReminders = false
var calendarName: String? = nil
var reminderListName: String? = nil
var dryRun = false
var listDays: Int = 7
var timezone = "Asia/Shanghai"

var i = 1
while i < allArgs.count {
    let arg = allArgs[i]
    switch arg {
    case "--events": doEvents = true
    case "--reminders": doReminders = true
    case "--calendar": i += 1; calendarName = allArgs[i]
    case "--reminder-list": i += 1; reminderListName = allArgs[i]
    case "--dry-run": dryRun = true
    case "--days": i += 1; listDays = Int(allArgs[i]) ?? 7
    case "--tz": i += 1; timezone = allArgs[i]
    default: break
    }
    i += 1
}
if !doEvents && !doReminders { doEvents = true; doReminders = true }

let tz = TimeZone(identifier: timezone) ?? TimeZone(identifier: "Asia/Shanghai")!

let df = DateFormatter()
df.dateFormat = "yyyy-MM-dd HH:mm"
df.timeZone = tz

let dfDate = DateFormatter()
dfDate.dateFormat = "yyyy-MM-dd"
dfDate.timeZone = tz

let dfISO = ISO8601DateFormatter()
dfISO.timeZone = tz

let store = EKEventStore()

// MARK: - Helpers
func parseDate(_ val: Any?) -> Date? {
    guard let s = val as? String else { return nil }
    return df.date(from: s) ?? dfDate.date(from: s) ?? dfISO.date(from: s)
}

func findCalendar(named name: String?) -> EKCalendar? {
    guard let name = name else { return nil }
    return store.calendars(for: .event).first { $0.title.lowercased() == name.lowercased() }
}

func findReminderList(named name: String?) -> EKCalendar? {
    guard let name = name else { return nil }
    return store.calendars(for: .reminder).first { $0.title.lowercased() == name.lowercased() }
}

func formatDate(_ d: Date) -> String {
    df.string(from: d)
}

func rruleString(_ r: [String: Any]) -> String? {
    // Accept either a raw RRULE string or structured object
    if let s = r["rrule"] as? String { return s }
    guard let freq = r["freq"] as? String else { return nil }
    var parts = ["FREQ=\(freq.uppercased())"]
    if let count = r["count"] as? Int { parts.append("COUNT=\(count)") }
    if let until = r["until"] as? String { parts.append("UNTIL=\(until.replacingOccurrences(of: "-", with: "").replacingOccurrences(of: ":", with: "").replacingOccurrences(of: " ", with: "T"))") }
    if let interval = r["interval"] as? Int { parts.append("INTERVAL=\(interval)") }
    if let byday = r["byday"] as? String { parts.append("BYDAY=\(byday.uppercased())") }
    if let bymonthday = r["bymonthday"] as? Int { parts.append("BYMONTHDAY=\(bymonthday)") }
    return parts.joined(separator: ";")
}

func priorityValue(_ val: Any?) -> Int {
    // EKReminder priority: 0=none, 1=high, 5=medium, 9=low
    if let n = val as? Int { return n }
    if let s = val as? String {
        switch s.lowercased() {
        case "high", "高", "紧急", "重要": return 1
        case "medium", "中": return 5
        case "low", "低": return 9
        default: return 0
        }
    }
    return 0
}

// MARK: - Read JSON from stdin (for create/update/delete)
func readInput() -> [[String: Any]] {
    let data = FileHandle.standardInput.readDataToEndOfFile()
    if data.isEmpty { return [] }
    if let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] { return arr }
    if let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] { return [obj] }
    print("ERROR: Invalid JSON input.")
    exit(1)
}

// MARK: - CREATE
func createEvents(_ items: [[String: Any]]) {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToEvents { granted, error in
        defer { sem.signal() }
        guard granted else { print("ERROR: Calendar access denied: \(error?.localizedDescription ?? "")"); return }
        let cal = findCalendar(named: calendarName) ?? store.defaultCalendarForNewEvents
        print("📅 Calendar: \(cal?.title ?? "default")")

        for item in items {
            let title = item["title"] as? String ?? "Untitled"
            guard let start = parseDate(item["start"]) else {
                print("  ⚠️ Skipped (no start): \(title)"); continue
            }
            let isAllDay = item["allday"] as? Bool ?? false
            let end = parseDate(item["end"]) ?? (isAllDay ? start : start.addingTimeInterval(3600))
            let location = item["location"] as? String
            let desc = item["description"] as? String
            let remindMin = item["remind_min"] as? Int ?? -1
            let urlStr = item["url"] as? String
            let recurrence = item["recurrence"] as? [String: Any]

            if dryRun { print("  🔍 [dry-run] \(title) | \(formatDate(start)) → \(formatDate(end))"); continue }

            let event = EKEvent(eventStore: store)
            event.title = title
            event.startDate = start
            event.endDate = end
            event.isAllDay = isAllDay
            event.location = location
            event.notes = desc
            event.calendar = cal
            if let urlStr = urlStr, let url = URL(string: urlStr) { event.url = url }
            if remindMin >= 0 { event.addAlarm(EKAlarm(relativeOffset: -Double(remindMin) * 60)) }
            if let recurrence = recurrence, let rule = rruleString(recurrence) {
                if let rrule = EKRecurrenceRule(recurrenceWith: rule) {
                    event.addRecurrenceRule(rrule)
                }
            }
            do {
                try store.save(event, span: .thisEvent)
                print("  ✅ \(title) | \(formatDate(start))")
            } catch {
                print("  ❌ \(title): \(error.localizedDescription)")
            }
        }
    }
    sem.wait()
}

func createReminders(_ items: [[String: Any]]) {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToReminders { granted, error in
        defer { sem.signal() }
        guard granted else { print("ERROR: Reminders access denied: \(error?.localizedDescription ?? "")"); return }
        let rc = findReminderList(named: reminderListName) ?? store.defaultCalendarForNewReminders()
        print("☑️ Reminder list: \(rc?.title ?? "default")")

        for item in items {
            let title = item["title"] as? String ?? "Untitled"
            guard let start = parseDate(item["start"]) else {
                print("  ⚠️ Skipped (no start): \(title)"); continue
            }
            let location = item["location"] as? String
            let desc = item["description"] as? String
            let remindMin = item["remind_min"] as? Int ?? -1
            let prio = priorityValue(item["priority"])

            if dryRun { print("  🔍 [dry-run] \(title) | \(formatDate(start))"); continue }

            let r = EKReminder(eventStore: store)
            r.title = title
            r.calendar = rc
            r.priority = prio
            var notes = ""
            if let location = location { notes += "📍 \(location)" }
            if let desc = desc { notes += notes.isEmpty ? desc : "\n\(desc)" }
            if !notes.isEmpty { r.notes = notes }
            r.dueDateComponents = Calendar.current.dateComponents(in: tz, from: start)
            if remindMin >= 0 {
                r.addAlarm(EKAlarm(absoluteDate: start.addingTimeInterval(-Double(remindMin) * 60)))
            }
            do {
                try store.save(r, commit: true)
                print("  ✅ \(title) | \(formatDate(start))")
            } catch {
                print("  ❌ \(title): \(error.localizedDescription)")
            }
        }
    }
    sem.wait()
}

// MARK: - LIST
func listEvents() {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToEvents { granted, _ in
        defer { sem.signal() }
        guard granted else { print("ERROR: Calendar access denied"); return }

        let start = Date()
        let end = Calendar.current.date(byAdding: .day, value: listDays, to: start)!
        var calendars: [EKCalendar]? = nil
        if let name = calendarName, let c = findCalendar(named: name) { calendars = [c] }

        let predicate = store.predicateForEvents(withStart: start, end: end, calendars: calendars)
        let events = store.events(matching: predicate).sorted { $0.startDate < $1.startDate }

        print("📅 Events (\(events.count)) in next \(listDays) days:")
        for e in events {
            let remind = e.alarms?.first.map { Int(-$0.relativeOffset / 60) }.map { "\($0)min" } ?? "none"
            print("  \(e.eventIdentifier ?? "?") | \(e.title ?? "?") | \(formatDate(e.startDate)) → \(formatDate(e.endDate)) | 📍\(e.location ?? "-") | ⏰\(remind) | 📅\(e.calendar.title)")
        }
    }
    sem.wait()
}

func listReminders() {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToReminders { granted, _ in
        defer { sem.signal() }
        guard granted else { print("ERROR: Reminders access denied"); return }

        var calendars: [EKCalendar]? = nil
        if let name = reminderListName, let c = findReminderList(named: name) { calendars = [c] }

        let predicate = store.predicateForReminders(in: calendars)
        let innerSem = DispatchSemaphore(value: 0)
        store.fetchReminders(matching: predicate) { reminders in
            let items = (reminders ?? []).filter { !$0.isCompleted }
                .sorted { ($0.dueDateComponents?.date ?? .distantFuture) < ($1.dueDateComponents?.date ?? .distantFuture) }
            print("☑️ Reminders (\(items.count) incomplete):")
            for r in items.prefix(50) {
                let due = r.dueDateComponents?.date.map { formatDate($0) } ?? "no date"
                print("  \(r.calendarItemExternalIdentifier ?? "?") | \(r.title ?? "?") | \(due) | 📋\(r.calendar.title)")
            }
            innerSem.signal()
        }
        innerSem.wait()
    }
    sem.wait()
}

// MARK: - UPDATE
func updateEvents(_ items: [[String: Any]]) {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToEvents { granted, _ in
        defer { sem.signal() }
        guard granted else { print("ERROR: Calendar access denied"); return }

        for item in items {
            guard let uid = item["id"] as? String else { print("  ⚠️ Skipped (no id)"); continue }
            guard let event = store.event(withIdentifier: uid) else { print("  ⚠️ Event not found: \(uid)"); continue }

            if let title = item["title"] as? String { event.title = title }
            if let start = parseDate(item["start"]) { event.startDate = start }
            if let end = parseDate(item["end"]) { event.endDate = end }
            if let loc = item["location"] as? String { event.location = loc }
            if let desc = item["description"] as? String { event.notes = desc }
            if let rm = item["remind_min"] as? Int {
                event.alarms?.forEach { event.removeAlarm($0) }
                if rm >= 0 { event.addAlarm(EKAlarm(relativeOffset: -Double(rm) * 60)) }
            }

            if dryRun { print("  🔍 [dry-run] Update: \(event.title ?? "?")"); continue }
            do {
                try store.save(event, span: .thisEvent)
                print("  ✅ Updated: \(event.title ?? "?")")
            } catch {
                print("  ❌ \(event.title ?? "?"): \(error.localizedDescription)")
            }
        }
    }
    sem.wait()
}

// MARK: - DELETE
func deleteEvents(_ items: [[String: Any]]) {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToEvents { granted, _ in
        defer { sem.signal() }
        guard granted else { print("ERROR: Calendar access denied"); return }

        for item in items {
            guard let uid = item["id"] as? String else { print("  ⚠️ Skipped (no id)"); continue }
            guard let event = store.event(withIdentifier: uid) else { print("  ⚠️ Event not found: \(uid)"); continue }
            if dryRun { print("  🔍 [dry-run] Delete: \(event.title ?? "?")"); continue }
            do {
                try store.remove(event, span: .thisEvent)
                print("  🗑️ Deleted: \(event.title ?? "?")")
            } catch {
                print("  ❌ \(event.title ?? "?"): \(error.localizedDescription)")
            }
        }
    }
    sem.wait()
}

func deleteReminders(_ items: [[String: Any]]) {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToReminders { granted, _ in
        defer { sem.signal() }
        guard granted else { print("ERROR: Reminders access denied"); return }

        for item in items {
            guard let uid = item["id"] as? String else { print("  ⚠️ Skipped (no id)"); continue }
            guard let event = store.calendarItem(withIdentifier: uid) as? EKReminder else { print("  ⚠️ Reminder not found: \(uid)"); continue }
            if dryRun { print("  🔍 [dry-run] Delete: \(event.title ?? "?")"); continue }
            do {
                try store.remove(event, commit: true)
                print("  🗑️ Deleted: \(event.title ?? "?")")
            } catch {
                print("  ❌ \(event.title ?? "?"): \(error.localizedDescription)")
            }
        }
    }
    sem.wait()
}

// MARK: - SEARCH (by title keyword)
func searchEvents(_ items: [[String: Any]]) {
    let sem = DispatchSemaphore(value: 0)
    store.requestFullAccessToEvents { granted, _ in
        defer { sem.signal() }
        guard granted else { print("ERROR: Calendar access denied"); return }

        let query = items.first?["query"] as? String ?? ""
        let days = items.first?["days"] as? Int ?? 30
        let start = Calendar.current.date(byAdding: .day, value: -days, to: Date())!
        let end = Calendar.current.date(byAdding: .day, value: days, to: Date())!
        let predicate = store.predicateForEvents(withStart: start, end: end, calendars: nil)
        let events = store.events(matching: predicate)
            .filter { ($0.title ?? "").localizedCaseInsensitiveContains(query) || ($0.location ?? "").localizedCaseInsensitiveContains(query) }
            .sorted { $0.startDate < $1.startDate }

        print("🔍 Search '\(query)' (\(events.count) results):")
        for e in events {
            print("  \(e.eventIdentifier ?? "?") | \(e.title ?? "?") | \(formatDate(e.startDate)) → \(formatDate(e.endDate)) | 📍\(e.location ?? "-") | 📅\(e.calendar.title)")
        }
    }
    sem.wait()
}

// MARK: - Main
switch action {
case "create":
    let items = readInput()
    if doEvents { createEvents(items) }
    if doReminders { createReminders(items) }
case "list":
    if doEvents { listEvents() }
    if doReminders { listReminders() }
case "update":
    let items = readInput()
    if doEvents { updateEvents(items) }
case "delete":
    let items = readInput()
    if doEvents { deleteEvents(items) }
    if doReminders { deleteReminders(items) }
case "search":
    let items = readInput()
    if doEvents { searchEvents(items) }
default:
    print("Unknown action: \(action). Use: create, list, update, delete, search")
    exit(1)
}

print("\n🎉 Done!")

// MARK: - EKRecurrenceRule from RRULE string
extension EKRecurrenceRule {
    convenience init?(recurrenceWith rrule: String) {
        let parts = rrule.split(separator: ";").reduce(into: [String: String]()) { dict, part in
            let kv = part.split(separator: "=", maxSplits: 1)
            if kv.count == 2 { dict[String(kv[0])] = String(kv[1]) }
        }
        guard let freqStr = parts["FREQ"] else { return nil }
        let freq: EKRecurrenceFrequency
        switch freqStr {
        case "DAILY": freq = .daily
        case "WEEKLY": freq = .weekly
        case "MONTHLY": freq = .monthly
        case "YEARLY": freq = .yearly
        default: return nil
        }
        let interval = parts["INTERVAL"].flatMap { Int($0) } ?? 1
        let count = parts["COUNT"].flatMap { Int($0) }

        var daysOfWeek: [EKRecurrenceDayOfWeek]? = nil
        if let byday = parts["BYDAY"] {
            let dayMap: [String: EKWeekday] = ["MO":.monday,"TU":.tuesday,"WE":.wednesday,"TH":.thursday,"FR":.friday,"SA":.saturday,"SU":.sunday]
            daysOfWeek = byday.split(separator: ",").compactMap { dayMap[String($0)] }.map { EKRecurrenceDayOfWeek($0) }
        }
        var daysOfMonth: [NSNumber]? = nil
        if let bmd = parts["BYMONTHDAY"], let d = Int(bmd) { daysOfMonth = [NSNumber(value: d)] }

        let end: EKRecurrenceEnd? = count.map { EKRecurrenceEnd(occurrenceCount: $0) }

        self.init(recurrenceWith: freq, interval: interval, daysOfTheWeek: daysOfWeek, daysOfTheMonth: daysOfMonth, monthsOfTheYear: nil, weeksOfTheYear: nil, daysOfTheYear: nil, setPositions: nil, end: end)
    }
}
