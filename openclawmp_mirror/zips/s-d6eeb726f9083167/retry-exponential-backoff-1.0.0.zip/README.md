# 指数退避重试模式

## 核心公式

```
delay = min(base_delay × 2^attempt + jitter, max_delay)
```

每次失败等待时间翻倍，加上随机抖动防止惊群效应。

## Python 实现

```python
import time, random, logging
from functools import wraps

def retry_with_backoff(max_retries=5, base_delay=1.0, max_delay=60.0,
                       jitter=True, retryable_errors=(Exception,)):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(max_retries + 1):
                try:
                    return func(*args, **kwargs)
                except retryable_errors as e:
                    if attempt >= max_retries:
                        raise
                    delay = min(base_delay * (2 ** attempt), max_delay)
                    if jitter:
                        delay *= (0.5 + random.random())
                    logging.warning(f"Retry {attempt+1}/{max_retries} after {delay:.1f}s: {e}")
                    time.sleep(delay)
        return wrapper
    return decorator

# 使用
@retry_with_backoff(max_retries=3, base_delay=2.0,
                    retryable_errors=(ConnectionError, TimeoutError))
def fetch_data(url):
    return requests.get(url, timeout=10).json()
```

## 分级重试策略

| HTTP 状态码 | 建议延迟 | 重试次数 | 说明 |
|-------------|---------|---------|------|
| 429 | 读取 Retry-After | 3 | Rate limit |
| 500 | 2s base | 5 | Server error |
| 502 | 5s base | 3 | Bad gateway |
| 503 | 10s base | 2 | Maintenance |
| 401 | 不重试 | 0 | 认证失败 |
| 403 | 不重试 | 0 | 禁止访问 |

## 常见陷阱

1. 没有抖动 → 惊群效应
2. 没有最大延迟 → 等待过长
3. 重试不可重试的错误 → 浪费时间
4. 不读 Retry-After 头 → 429 时等太久或太短
5. 不记录日志 → 无法排查