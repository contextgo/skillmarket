---
name: 互动游戏开发
displayName: 互动游戏开发
description: 开发在线课程互动小游戏，支持知识问答、抢答、闯关等类型。
version: 1.0.0
author: OpenClaw Edu
tags: [education, game, interactive, html, javascript]
category: education
---

# 互动游戏开发

开发课程互动小游戏。

## 功能

- 知识问答游戏
- 计分系统
- 倒计时功能
- 排行榜
- HTML5输出

## 使用

```
@互动游戏开发 开发一个物理力学知识问答游戏
```
