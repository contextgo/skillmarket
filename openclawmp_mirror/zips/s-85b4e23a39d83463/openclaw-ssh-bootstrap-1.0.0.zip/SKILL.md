---
name: openclaw-ssh-bootstrap
description: "Bootstrap and configure OpenClaw on a remote Linux server over SSH, especially Ubuntu/Debian VPS hosts using API-key model providers such as Google Gemini and chat channels such as Telegram. Use when the user wants an end-to-end remote setup: read the official OpenClaw docs first, inspect the remote host, install Node/OpenClaw, run non-interactive onboarding, patch model and channel config, restart the gateway, verify health, and complete pairing while redacting secrets from saved notes or published artifacts."
---

# OpenClaw SSH Bootstrap

Use this skill to turn a clean remote Linux VPS into a working OpenClaw host without inventing commands or leaking secrets.

## Quick workflow

1. Read the official docs first.
   - Start with `docs/start/getting-started.md`.
   - Then read only the extra docs needed for the chosen provider/channel, usually:
     - `docs/start/setup.md`
     - `docs/start/wizard.md`
     - `docs/start/wizard-cli-automation.md`
     - provider/channel docs such as `docs/channels/telegram.md`

2. Probe the remote host over SSH before changing anything.
   - Detect OS/version.
   - Check whether Node, npm, and `openclaw` already exist.
   - Prefer a clean Ubuntu LTS host.

3. Install OpenClaw with the official installer when missing.
   - Recommended Linux installer:
     - `curl -fsSL https://openclaw.ai/install.sh | bash -s -- --no-onboard`
   - Confirm `node`, `npm`, and `openclaw --version` afterwards.

4. Run non-interactive onboarding with the provider API key.
   - Use documented flags only.
   - Prefer `--install-daemon` and `--daemon-runtime node` on VPS hosts.
   - Skip channels during onboarding when channel setup is easier to patch afterwards.

5. Patch config explicitly after onboarding.
   - Set `agents.defaults.model.primary` to the exact requested model.
   - Add the requested channel config.
   - For Telegram on a personal VPS, default to:
     - `dmPolicy: pairing`
     - `groupPolicy: disabled`
   - Keep `gateway.bind = loopback` unless the user explicitly needs LAN/Tailnet/public exposure.

6. Restart and verify.
   - Restart the OpenClaw gateway service.
   - Check service health, gateway logs, and channel health.
   - Run `openclaw health` or `openclaw status --deep` when useful.

7. Finish Telegram pairing.
   - Ask the user to message the bot first.
   - Then approve the returned pairing code with:
     - `openclaw pairing approve telegram <PAIRING_CODE>`
   - Confirm there are no pending pairing requests left.

## Decision rules

### Bind mode
- Use `loopback` by default on remote VPS setups.
- Use `tailnet` only when the user explicitly wants Tailscale access.
- Use `lan` or custom public binds only when the user explicitly accepts the exposure.
- Remember: Telegram bots do not require public Gateway bind if the bot runs on the server itself.

### Telegram defaults
- Use `pairing` for DM access unless the user explicitly wants a looser policy.
- Disable groups by default for first-time deployments.
- After approval, verify the user can DM the bot normally.

### Secret hygiene
- Never publish or commit:
  - server IPs tied to private context unless the user wants them public
  - usernames/passwords
  - API keys
  - bot tokens
  - gateway tokens
  - pairing codes
- Replace them with placeholders like:
  - `<SERVER_IP>`
  - `<SSH_USER>`
  - `<SSH_PASSWORD>`
  - `<GEMINI_API_KEY>`
  - `<TELEGRAM_BOT_TOKEN>`
  - `<PAIRING_CODE>`

## References

- For the end-to-end Linux VPS procedure and command order, read `references/linux-vps-workflow.md`.
- For publication/redaction rules, read `references/redaction-and-placeholders.md`.
- If local SSH tooling lacks password automation, use `scripts/ssh_run.py` as a minimal Paramiko helper.

## Output expectations

When using this skill, produce:
- a short deployment summary
- the exact non-sensitive commands used or templated commands with placeholders
- any final user actions still required, such as messaging the Telegram bot to obtain a pairing code
- a short explanation of security choices, especially bind mode and pairing mode
