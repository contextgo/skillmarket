#!/usr/bin/env python3
import argparse
import json
import sys

try:
    import paramiko
except ImportError:
    print("paramiko is required. Install with: python -m pip install paramiko", file=sys.stderr)
    sys.exit(2)


def main() -> int:
    parser = argparse.ArgumentParser(description="Run a single remote SSH command with password auth.")
    parser.add_argument("host")
    parser.add_argument("user")
    parser.add_argument("password")
    parser.add_argument("command")
    parser.add_argument("--timeout", type=int, default=30)
    args = parser.parse_args()

    client = paramiko.SSHClient()
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    client.connect(
        hostname=args.host,
        username=args.user,
        password=args.password,
        timeout=args.timeout,
        banner_timeout=args.timeout,
        auth_timeout=args.timeout,
    )
    stdin, stdout, stderr = client.exec_command(args.command, timeout=args.timeout)
    exit_status = stdout.channel.recv_exit_status()
    result = {
        "exit_status": exit_status,
        "stdout": stdout.read().decode("utf-8", errors="replace"),
        "stderr": stderr.read().decode("utf-8", errors="replace"),
    }
    print(json.dumps(result, ensure_ascii=True))
    client.close()
    return exit_status


if __name__ == "__main__":
    raise SystemExit(main())
