# Redaction and placeholders

Use this reference when converting a real deployment session into reusable public documentation or a shareable skill.

## Always redact

- Server IPs tied to a private deployment
- SSH usernames when sensitive
- SSH passwords
- API keys
- Bot tokens
- Gateway tokens
- Pairing codes
- Auth profile contents containing secrets
- Raw config files that still include secrets

## Preferred placeholders

- `<SERVER_IP>`
- `<SSH_USER>`
- `<SSH_PASSWORD>`
- `<GEMINI_API_KEY>`
- `<TELEGRAM_BOT_TOKEN>`
- `<GATEWAY_TOKEN>`
- `<PAIRING_CODE>`
- `<WORKSPACE_DIR>`

## Good publication practice

- Keep the workflow real, but generalize the environment.
- Preserve exact OpenClaw commands when they are safe.
- Replace secret-bearing values inline instead of deleting the whole example.
- State why `loopback` and `pairing` were chosen when documenting security posture.

## Avoid

- publishing literal `openclaw.json` dumps that still contain tokens
- publishing `auth-profiles.json` with live keys
- mixing real host details with a public README
