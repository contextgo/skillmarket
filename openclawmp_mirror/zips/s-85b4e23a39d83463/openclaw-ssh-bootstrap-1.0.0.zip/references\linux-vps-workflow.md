# Linux VPS workflow

Use this reference when deploying OpenClaw to a remote Ubuntu/Debian VPS over SSH.

## 1. Read official docs first

Minimum doc set:
- `docs/start/getting-started.md`
- `docs/start/setup.md`
- `docs/start/wizard.md`
- `docs/start/wizard-cli-automation.md`
- provider/channel docs as needed, for example `docs/channels/telegram.md`

## 2. Probe the server

Run read-only checks first:

```bash
uname -a
cat /etc/os-release
command -v node || true
node --version || true
command -v npm || true
npm --version || true
command -v openclaw || true
```

## 3. Install OpenClaw if missing

```bash
curl -fsSL https://openclaw.ai/install.sh | bash -s -- --no-onboard
```

Verify:

```bash
node --version
npm --version
openclaw --version
```

## 4. Run onboarding non-interactively

Gemini API-key example:

```bash
openclaw onboard --non-interactive \
  --accept-risk \
  --mode local \
  --auth-choice gemini-api-key \
  --gemini-api-key "<GEMINI_API_KEY>" \
  --secret-input-mode plaintext \
  --gateway-port 18789 \
  --gateway-bind loopback \
  --install-daemon \
  --daemon-runtime node \
  --skip-channels \
  --skip-skills \
  --skip-search \
  --skip-ui \
  --json
```

Notes:
- Replace `plaintext` with `ref` only when the deployment environment is prepared for SecretRef/env-based storage.
- `loopback` is the safe default for a VPS Telegram deployment.

## 5. Patch config after onboarding

Typical edits:
- `agents.defaults.model.primary = google/gemini-2.0-flash`
- add Telegram channel config

Minimal Telegram block:

```json
{
  "channels": {
    "telegram": {
      "enabled": true,
      "botToken": "<TELEGRAM_BOT_TOKEN>",
      "dmPolicy": "pairing",
      "groupPolicy": "disabled"
    }
  }
}
```

## 6. Restart the gateway

For the user service installed by onboarding:

```bash
export XDG_RUNTIME_DIR=/run/user/$(id -u)
systemctl --user daemon-reload
systemctl --user restart openclaw-gateway.service
systemctl --user --no-pager --full status openclaw-gateway.service
```

## 7. Verify health

Useful checks:

```bash
openclaw health
openclaw status --deep
journalctl --user -u openclaw-gateway.service -n 120 --no-pager
```

For Telegram specifically, the health output should show the bot username if connected.

## 8. Complete Telegram pairing

1. Ask the user to send any message to the bot.
2. The bot returns a pairing code.
3. Approve it:

```bash
openclaw pairing approve telegram <PAIRING_CODE>
```

4. Verify there are no pending requests:

```bash
openclaw pairing list telegram
```

## 9. Explain the result clearly

Report:
- installed OpenClaw version
- chosen default model
- channel configuration status
- whether pairing is complete
- whether the Gateway is bound to loopback or something broader
