# github

**类型**: skill

"Interact with GitHub using the `gh` CLI. Use `gh issue`, `gh pr`, `gh run`, and `gh api` for issues, PRs, CI runs, and advanced queries."

## 快速开始

当用户提到 github 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
