# iOS 移动开发助手

> 覆盖 Swift/SwiftUI 全栈开发的专业助手，提供代码生成、架构设计、性能优化和 App Store 提交等全流程支持。

## 简介

iOS 移动开发助手是面向 iOS 开发者的综合辅助工具，涵盖从 Swift 语言基础到高级架构模式、从数据持久化到网络层设计、从 UI 组件到性能优化的全方位支持。无论你是初学者还是资深开发者，都能从中获得实用的代码模板和最佳实践。

## 核心功能

### 🦅 Swift 语言
- 可选值安全解包（if-let、guard-let、nil 合并）
- 枚举与关联值、协议与泛型
- async/await 并发编程与 Actor
- Result 类型与自定义错误处理

### 🎨 SwiftUI 组件
- @State、@Binding、@Observable 状态管理
- 自定义组件与 ViewModifier
- 动画与过渡效果
- NavigationStack 与 Sheet/Alert

### 📱 UIKit 模式
- 视图控制器生命周期管理
- Programmatic Auto Layout
- UICollectionView Compositional Layout
- Diffable DataSource

### 🏗️ 架构模式
- **MVVM**：适合中小项目，代码简洁
- **VIPER**：模块化清晰，适合大项目
- **Clean Architecture**：分层解耦，可测试性强

### 💾 数据持久化
- Core Data 完整 CRUD 操作
- SwiftData（iOS 17+）现代方案
- UserDefaults 与 @AppStorage 封装
- @propertyWrapper 自定义存储

### 🌐 网络层
- URLSession 封装（泛型 + async/await）
- Endpoint 设计模式
- 认证 token 管理
- 图片缓存策略

### 🧪 测试
- XCTest 单元测试编写
- Mock 对象与协议驱动测试
- Swift Testing 新框架
- Snapshot Testing

### ⚡ 性能优化
- 列表性能优化与行高复用
- 图片降采样与内存管理
- 启动速度优化
- Instruments 性能分析建议

### 🚀 App Store 提交
- 完整的提交前检查清单
- 权限声明配置
- TestFlight 构建与分发
- 截图与元数据要求

## 使用场景

1. **快速开发新 App**：使用推荐的目录结构和架构模板快速搭建项目
2. **代码审查与重构**：获取最佳实践建议，改进代码质量
3. **架构选型**：根据项目规模选择合适的架构模式（MVVM/VIPER/Clean）
4. **问题排查**：查阅常见编译错误和运行时错误的解决方案
5. **App 上架**：按检查清单逐项确认，避免审核被拒

## 配置说明

### 开发环境要求

- **Xcode**：16.0+（支持 Swift 6 和 Swift Testing）
- **iOS 部署目标**：iOS 16.0+（SwiftData 需要 iOS 17+）
- **Swift**：5.9+（推荐 6.0）

### 依赖管理工具

| 工具 | 适用场景 |
|------|---------|
| Swift Package Manager (SPM) | 推荐首选，Apple 官方支持 |
| CocoaPods | 传统项目，社区包丰富 |
| Carthage | 需要源码级控制 |

### 推荐开发工具

- **Instruments**：性能分析和内存泄漏检测
- **SF Symbols**：系统图标浏览器
- **Accessibility Inspector**：无障碍功能检查
- **Previews**：SwiftUI 实时预览

## 作者

知白守黑1024
