---
name: ios-dev-companion
description: iOS移动开发助手 - 覆盖Swift/SwiftUI代码生成与审查、Xcode项目结构、UIKit组件模式、MVVM/VIPER/Clean Architecture架构、Core Data/SwiftData、网络层、Auto Layout、App Store提交检查清单、XCTest测试、性能优化和常见错误排查。
---

# iOS 移动开发助手

## 概述

本技能是全面的 iOS 开发助手，提供 Swift/SwiftUI 代码生成与审查、架构设计模式、数据持久化、网络层搭建、UI 布局、测试编写、性能优化和 App Store 提交等全流程支持。适用于从初学者到高级 iOS 开发者的各个阶段。

---

## 一、Swift 语言基础与进阶

### 1.1 基础数据类型与可选值

```swift
// 可选值安全解包
var username: String? = "developer"

// if-let 解包
if let name = username {
    print("Hello, \(name)")
}

// guard-let 提前返回（推荐用于函数参数验证）
func processUser(_ name: String?, age: Int?) {
    guard let name = name, let age = age, age >= 0 else {
        print("Invalid user data")
        return
    }
    print("Processing \(name), age \(age)")
}

// nil 合并运算符
let displayName = username ?? "Guest"

// 可选链
let upperName = username?.uppercased()
```

### 1.2 枚举与关联值

```swift
// 带关联值的枚举
enum NetworkResult<Value> {
    case success(Value)
    case failure(Error)
    case loading
}

// 使用
func handleResult(_ result: NetworkResult<[User]>) {
    switch result {
    case .success(let users):
        print("Loaded \(users.count) users")
    case .failure(let error):
        print("Error: \(error.localizedDescription)")
    case .loading:
        print("Loading...")
    }
}
```

### 1.3 协议与泛型

```swift
// 协议定义
protocol Identifiable {
    var id: UUID { get }
}

protocol Repository {
    associatedtype Entity: Identifiable
    func fetch(by id: UUID) async throws -> Entity?
    func save(_ entity: Entity) async throws
    func delete(_ entity: Entity) async throws
}

// 泛型约束
func findElement<T: Identifiable & Equatable>(
    in array: [T],
    matching id: UUID
) -> T? {
    array.first { $0.id == id }
}
```

### 1.4 async/await 并发

```swift
// 异步函数
func fetchUserData() async throws -> User {
    let (data, _) = try await URLSession.shared.data(
        from: URL(string: "https://api.example.com/user")!
    )
    return try JSONDecoder().decode(User.self, from: data)
}

// 并行执行多个异步任务
func fetchDashboard() async throws -> Dashboard {
    async let user = fetchUserData()
    async let notifications = fetchNotifications()
    async let feed = fetchFeed()

    return try await Dashboard(
        user: user,
        notifications: notifications,
        feed: feed
    )
}

// TaskGroup
func fetchAllUsers() async throws -> [User] {
    let urls = (1...5).map { URL(string: "https://api.example.com/users/\($0)")! }

    return try await withThrowingTaskGroup(of: User.self) { group in
        for url in urls {
            group.addTask {
                let (data, _) = try await URLSession.shared.data(from: url)
                return try JSONDecoder().decode(User.self, from: data)
            }
        }
        return try await group.reduce(into: [User]()) { result, user in
            result.append(user)
        }
    }
}

// Actor
actor UserDataStore {
    private var cache: [UUID: User] = [:]

    func getUser(_ id: UUID) -> User? {
        cache[id]
    }

    func updateUser(_ user: User) {
        cache[user.id] = user
    }
}
```

### 1.5 Result 类型与错误处理

```swift
enum AppError: LocalizedError {
    case networkError(statusCode: Int)
    case decodingError
    case invalidInput
    case unauthorized

    var errorDescription: String? {
        switch self {
        case .networkError(let code):
            return "网络请求失败，状态码: \(code)"
        case .decodingError:
            return "数据解析失败"
        case .invalidInput:
            return "输入数据无效"
        case .unauthorized:
            return "未授权，请重新登录"
        }
    }
}

func loadData() -> Result<Data, AppError> {
    // ...
    return .success(data)
}
```

---

## 二、SwiftUI 组件模式

### 2.1 基础视图与修饰器

```swift
import SwiftUI

struct ProfileView: View {
    let user: User

    var body: some View {
        ScrollView {
            VStack(spacing: 16) {
                // 异步图片加载
                AsyncImage(url: URL(string: user.avatarURL)) { phase in
                    switch phase {
                    case .success(let image):
                        image
                            .resizable()
                            .aspectRatio(contentMode: .fill)
                    case .failure:
                        Image(systemName: "person.circle.fill")
                            .resizable()
                            .foregroundColor(.gray)
                    @default:
                        ProgressView()
                    }
                }
                .frame(width: 120, height: 120)
                .clipShape(Circle())
                .shadow(radius: 8)

                Text(user.name)
                    .font(.title.bold())
                    .foregroundStyle(.primary)

                Text(user.bio)
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding()
        }
        .navigationTitle("个人资料")
    }
}
```

### 2.2 @State, @Binding, @ObservedObject, @StateObject, @EnvironmentObject

```swift
// @State - 视图本地状态
struct CounterView: View {
    @State private var count = 0

    var body: some View {
        VStack(spacing: 20) {
            Text("计数: \(count)")
                .font(.largeTitle)

            HStack(spacing: 20) {
                Button("-1") { count -= 1 }
                    .buttonStyle(.bordered)
                Button("+1") { count += 1 }
                    .buttonStyle(.borderedProminent)
            }
        }
    }
}

// @Observable (iOS 17+)
@Observable
class TaskStore {
    var tasks: [Task] = []
    var isLoading = false

    func loadTasks() async { /* ... */ }
    func addTask(_ task: Task) { tasks.append(task) }
    func removeTask(_ task: Task) { tasks.removeAll { $0.id == task.id } }
}

struct TaskListView: View {
    @State private var store = TaskStore()

    var body: some View {
        List(store.tasks) { task in
            TaskRow(task: task)
        }
        .task { await store.loadTasks() }
        .overlay {
            if store.isLoading {
                ProgressView("加载中...")
            }
        }
    }
}

// @Environment - 环境值注入
struct ThemedView: View {
    @Environment(\.colorScheme) var colorScheme
    @Environment(\.dismiss) var dismiss

    var body: some View {
        VStack {
            Text(colorScheme == .dark ? "深色模式" : "浅色模式")
            Button("关闭") { dismiss() }
        }
    }
}
```

### 2.3 自定义组件

```swift
// 可复用的卡片组件
struct InfoCard<Content: View>: View {
    let title: String
    let subtitle: String?
    @ViewBuilder let content: Content

    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title)
                    .font(.headline)
                if let subtitle {
                    Text(subtitle)
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            content
        }
        .padding()
        .background(.background)
        .clipShape(RoundedRectangle(cornerRadius: 12))
        .shadow(color: .black.opacity(0.1), radius: 8, y: 4)
    }
}

// 使用
InfoCard(title: "项目进度", subtitle: "本周更新") {
    ProgressView(value: 0.7) {
        Text("70%")
    }
    .tint(.green)
}
```

### 2.4 自定义修饰器

```swift
struct CardModifier: ViewModifier {
    var cornerRadius: CGFloat = 12
    var shadowRadius: CGFloat = 8

    func body(content: Content) -> some View {
        content
            .padding()
            .background(.ultraThinMaterial)
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius))
            .shadow(color: .black.opacity(0.1), radius: shadowRadius, y: 4)
    }
}

extension View {
    func cardStyle(cornerRadius: CGFloat = 12) -> some View {
        modifier(CardModifier(cornerRadius: cornerRadius))
    }
}

// 使用
Text("Hello")
    .cardStyle()
```

### 2.5 动画

```swift
struct AnimatedToggle: View {
    @State private var isExpanded = false

    var body: some View {
        VStack {
            Button("展开/收起") {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.8)) {
                    isExpanded.toggle()
                }
            }

            if isExpanded {
                Text("展开的内容区域")
                    .font(.body)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(.blue.opacity(0.1))
                    .cornerRadius(8)
                    .transition(.asymmetric(
                        insertion: .scale(scale: 0.8).combined(with: .opacity),
                        removal: .scale(scale: 0.8).combined(with: .opacity)
                    ))
            }
        }
    }
}
```

### 2.6 Navigation 与 Sheet

```swift
// NavigationStack (iOS 16+)
struct AppNavigation: View {
    var body: some View {
        NavigationStack {
            List {
                NavigationLink("用户列表", value: Route.userList)
                NavigationLink("设置", value: Route.settings)
            }
            .navigationDestination(for: Route.self) { route in
                switch route {
                case .userList:
                    UserListView()
                case .settings:
                    SettingsView()
                }
            }
            .navigationTitle("首页")
        }
    }
}

enum Route: Hashable {
    case userList
    case settings
}

// Sheet 与 ConfirmationDialog
struct SheetExample: View {
    @State private var showingSheet = false
    @State private var showingAlert = false

    var body: some View {
        VStack(spacing: 20) {
            Button("显示 Sheet") { showingSheet = true }
            Button("确认删除") { showingAlert = true }
        }
        .sheet(isPresented: $showingSheet) {
            FormView()
        }
        .confirmationDialog("确定要删除吗？", isPresented: $showingAlert) {
            Button("删除", role: .destructive) { /* 删除逻辑 */ }
            Button("取消", role: .cancel) { }
        }
    }
}
```

---

## 三、UIKit 组件模式

### 3.1 UIKit 视图控制器基础

```swift
import UIKit

class UserListViewController: UIViewController {
    private let tableView = UITableView(frame: .zero, style: .insetGrouped)
    private var users: [User] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "用户列表"
        view.backgroundColor = .systemBackground
        setupTableView()
        loadUsers()
    }

    private func setupTableView() {
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "UserCell")
        view.addSubview(tableView)
        tableView.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            tableView.topAnchor.constraint(equalTo: view.topAnchor),
            tableView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            tableView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            tableView.bottomAnchor.constraint(equalTo: view.bottomAnchor)
        ])
    }

    private func loadUsers() {
        Task {
            do {
                users = try await UserRepository.shared.fetchAll()
                tableView.reloadData()
            } catch {
                showError(error)
            }
        }
    }

    private func showError(_ error: Error) {
        let alert = UIAlertController(
            title: "错误",
            message: error.localizedDescription,
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "确定", style: .default))
        present(alert, animated: true)
    }
}

extension UserListViewController: UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        users.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserCell", for: indexPath)
        cell.textLabel?.text = users[indexPath.row].name
        return cell
    }
}
```

### 3.2 Programmatic Auto Layout

```swift
extension UIView {
    func addSubview(_ child: UIView, constraints: (UIView) -> [NSLayoutConstraint]) {
        addSubview(child)
        child.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate(constraints(child))
    }
}

// 使用
class ProfileHeader: UIView {
    private let avatarImageView = UIImageView()
    private let nameLabel = UILabel()
    private let bioLabel = UILabel()

    init() {
        super.init(frame: .zero)

        addSubview(avatarImageView) { view in
            [
                view.topAnchor.constraint(equalTo: topAnchor, constant: 16),
                view.centerXAnchor.constraint(equalTo: centerXAnchor),
                view.widthAnchor.constraint(equalToConstant: 80),
                view.heightAnchor.constraint(equalToConstant: 80)
            ]
        }

        addSubview(nameLabel) { view in
            [
                view.topAnchor.constraint(equalTo: avatarImageView.bottomAnchor, constant: 12),
                view.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
                view.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16)
            ]
        }

        addSubview(bioLabel) { view in
            [
                view.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 4),
                view.leadingAnchor.constraint(equalTo: leadingAnchor, constant: 16),
                view.trailingAnchor.constraint(equalTo: trailingAnchor, constant: -16),
                view.bottomAnchor.constraint(equalTo: bottomAnchor, constant: -16)
            ]
        }

        // 配置样式
        avatarImageView.contentMode = .scaleAspectFill
        avatarImageView.clipsToBounds = true
        avatarImageView.layer.cornerRadius = 40
        avatarImageView.backgroundColor = .systemGray5

        nameLabel.font = .systemFont(ofSize: 20, weight: .bold)
        nameLabel.textAlignment = .center

        bioLabel.font = .systemFont(ofSize: 14)
        bioLabel.textColor = .secondaryLabel
        bioLabel.textAlignment = .center
        bioLabel.numberOfLines = 0
    }

    required init?(coder: NSCoder) { fatalError() }
}
```

### 3.3 UICollectionView Compositional Layout

```swift
import UIKit

enum Section { case main }

class GridViewController: UIViewController {
    private var collectionView: UICollectionView!
    private var dataSource: UICollectionViewDiffableDataSource<Section, Item>!

    override func viewDidLoad() {
        super.viewDidLoad()
        configureCollectionView()
        configureDataSource()
    }

    private func configureCollectionView() {
        collectionView = UICollectionView(frame: view.bounds, collectionViewLayout: createLayout())
        collectionView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        view.addSubview(collectionView)
    }

    private func createLayout() -> UICollectionViewLayout {
        let itemSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(0.5),
            heightDimension: .estimated(200)
        )
        let item = NSCollectionLayoutItem(layoutSize: itemSize)
        item.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 8, bottom: 8, trailing: 8)

        let groupSize = NSCollectionLayoutSize(
            widthDimension: .fractionalWidth(1.0),
            heightDimension: .estimated(200)
        )
        let group = NSCollectionLayoutGroup.horizontal(layoutSize: groupSize, subitems: [item])

        let section = NSCollectionLayoutSection(group: group)
        section.contentInsets = NSDirectionalEdgeInsets(top: 8, leading: 0, bottom: 8, trailing: 0)

        return UICollectionViewCompositionalLayout(section: section)
    }

    private func configureDataSource() {
        let cellRegistration = UICollectionView.CellRegistration<ItemCell, Item> { cell, _, item in
            cell.configure(with: item)
        }

        dataSource = UICollectionViewDiffableDataSource<Section, Item>(
            collectionView: collectionView
        ) { collectionView, indexPath, item in
            collectionView.dequeueConfiguredReusableCell(
                using: cellRegistration, for: indexPath, item: item
            )
        }
    }
}
```

---

## 四、架构模式

### 4.1 MVVM 架构

```swift
// Model
struct User: Codable, Identifiable {
    let id: UUID
    var name: String
    var email: String
    var avatarURL: String
}

// ViewModel
@Observable
class UserViewModel {
    private(set) var users: [User] = []
    private(set) var isLoading = false
    private(set) var errorMessage: String?

    private let repository: UserRepositoryProtocol

    init(repository: UserRepositoryProtocol = UserRepository()) {
        self.repository = repository
    }

    func loadUsers() async {
        isLoading = true
        errorMessage = nil
        do {
            users = try await repository.fetchAllUsers()
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoading = false
    }

    func deleteUser(_ user: User) async {
        do {
            try await repository.delete(user)
            users.removeAll { $0.id == user.id }
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

// Protocol（便于测试）
protocol UserRepositoryProtocol {
    func fetchAllUsers() async throws -> [User]
    func delete(_ user: User) async throws
}

// View
struct UserListView: View {
    var viewModel: UserViewModel

    var body: some View {
        NavigationStack {
            Group {
                if viewModel.isLoading {
                    ProgressView()
                } else if let error = viewModel.errorMessage {
                    VStack {
                        Text(error).foregroundStyle(.red)
                        Button("重试") { Task { await viewModel.loadUsers() } }
                    }
                } else {
                    List(viewModel.users) { user in
                        UserRowView(user: user)
                    }
                }
            }
            .navigationTitle("用户")
            .task { await viewModel.loadUsers() }
            .refreshable { await viewModel.loadUsers() }
        }
    }
}
```

### 4.2 VIPER 架构

```swift
// --- View ---
protocol UserListViewProtocol: AnyObject {
    func displayUsers(_ users: [User])
    func displayError(_ message: String)
}

class UserListViewController: UIViewController, UserListViewProtocol {
    var presenter: UserListPresenterProtocol?

    func displayUsers(_ users: [User]) {
        tableView.reloadData()
    }

    func displayError(_ message: String) {
        showAlert(message)
    }
}

// --- Presenter ---
protocol UserListPresenterProtocol: AnyObject {
    var view: UserListViewProtocol? { get set }
    func viewDidLoad()
    func didSelectUser(_ user: User)
}

class UserListPresenter: UserListPresenterProtocol {
    weak var view: UserListViewProtocol?
    private let interactor: UserListInteractorProtocol
    private let router: UserListRouterProtocol

    init(interactor: UserListInteractorProtocol, router: UserListRouterProtocol) {
        self.interactor = interactor
        self.router = router
    }

    func viewDidLoad() {
        interactor.fetchUsers()
    }

    func didSelectUser(_ user: User) {
        router.navigateToUserDetail(user)
    }
}

// --- Interactor ---
protocol UserListInteractorProtocol {
    var presenter: UserListInteractorOutputProtocol? { get set }
    func fetchUsers()
}

class UserListInteractor: UserListInteractorProtocol {
    weak var presenter: UserListInteractorOutputProtocol?
    private let repository: UserRepository

    init(repository: UserRepository) {
        self.repository = repository
    }

    func fetchUsers() {
        Task {
            do {
                let users = try await repository.fetchAllUsers()
                presenter?.didFetchUsers(users)
            } catch {
                presenter?.didFailFetching(error)
            }
        }
    }
}

// --- Router ---
protocol UserListRouterProtocol {
    func navigateToUserDetail(_ user: User)
}

class UserListRouter: UserListRouterProtocol {
    weak var viewController: UIViewController?

    func navigateToUserDetail(_ user: User) {
        let detailVC = UserDetailRouter.createModule(for: user)
        viewController?.navigationController?.pushViewController(detailVC, animated: true)
    }
}
```

### 4.3 Clean Architecture（Swift）

```swift
// Domain Layer - Use Case
protocol GetUserListUseCaseProtocol {
    func execute() async throws -> [User]
}

class GetUserListUseCase: GetUserListUseCaseProtocol {
    private let repository: UserRepositoryProtocol

    init(repository: UserRepositoryProtocol) {
        self.repository = repository
    }

    func execute() async throws -> [User] {
        try await repository.getAll()
    }
}

// Domain Layer - Repository Interface
protocol UserRepositoryProtocol {
    func getAll() async throws -> [User]
    func save(_ user: User) async throws
    func delete(_ id: UUID) async throws
}

// Data Layer - Repository Implementation
class UserRepositoryImpl: UserRepositoryProtocol {
    private let remoteDataSource: UserRemoteDataSource
    private let localDataSource: UserLocalDataSource

    init(remote: UserRemoteDataSource, local: UserLocalDataSource) {
        self.remoteDataSource = remote
        self.localDataSource = localDataSource
    }

    func getAll() async throws -> [User] {
        do {
            let users = try await remoteDataSource.fetchUsers()
            try await localDataSource.cache(users)
            return users
        } catch {
            return try await localDataSource.getCachedUsers()
        }
    }

    func save(_ user: User) async throws {
        try await remoteDataSource.createUser(user)
    }

    func delete(_ id: UUID) async throws {
        try await remoteDataSource.deleteUser(id)
    }
}
```

---

## 五、数据持久化

### 5.1 Core Data

```swift
import CoreData

// 管理器
class CoreDataManager {
    static let shared = CoreDataManager()
    let persistentContainer: NSPersistentContainer

    private init() {
        persistentContainer = NSPersistentContainer(name: "AppModel")
        persistentContainer.loadPersistentStores { _, error in
            if let error = error {
                fatalError("Core Data store failed to load: \(error)")
            }
        }
        persistentContainer.viewContext.automaticallyMergesChangesFromParent = true
    }

    var viewContext: NSManagedObjectContext {
        persistentContainer.viewContext
    }

    func save() {
        let context = viewContext
        if context.hasChanges {
            try? context.save()
        }
    }
}

// CRUD 操作
class UserDAO {
    private let context = CoreDataManager.shared.viewContext

    func create(name: String, email: String) -> UserEntity {
        let user = UserEntity(context: context)
        user.id = UUID()
        user.name = name
        user.email = email
        user.createdAt = Date()
        CoreDataManager.shared.save()
        return user
    }

    func fetchAll() -> [UserEntity] {
        let request: NSFetchRequest<UserEntity> = UserEntity.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        return (try? context.fetch(request)) ?? []
    }

    func delete(_ user: UserEntity) {
        context.delete(user)
        CoreDataManager.shared.save()
    }
}
```

### 5.2 SwiftData（iOS 17+）

```swift
import SwiftData

@Model
final class Task {
    var id: UUID
    var title: String
    var isCompleted: Bool
    var createdAt: Date
    var priority: TaskPriority

    init(title: String, priority: TaskPriority = .medium) {
        self.id = UUID()
        self.title = title
        self.isCompleted = false
        self.createdAt = Date()
        self.priority = priority
    }

    enum TaskPriority: String, Codable, CaseIterable {
        case low, medium, high
    }
}

// 在 App 入口配置
@main
struct TaskApp: App {
    var body: some Scene {
        WindowGroup {
            TaskListView()
        }
        .modelContainer(for: Task.self)
    }
}

// 使用 SwiftData 的 View
struct TaskListView: View {
    @Environment(\.modelContext) private var modelContext
    @Query(sort: \Task.createdAt, order: .reverse) private var tasks: [Task]
    @State private var newText = ""

    var body: some View {
        NavigationStack {
            VStack {
                HStack {
                    TextField("新任务", text: $newText)
                        .textFieldStyle(.roundedBorder)
                    Button("添加") {
                        let task = Task(title: newText)
                        modelContext.insert(task)
                        newText = ""
                    }
                    .disabled(newText.isEmpty)
                }
                .padding()

                List {
                    ForEach(tasks) { task in
                        TaskRow(task: task)
                    }
                    .onDelete(perform: deleteTasks)
                }
            }
            .navigationTitle("任务列表")
        }
    }

    private func deleteTasks(at offsets: IndexSet) {
        for index in offsets {
            modelContext.delete(tasks[index])
        }
    }
}
```

### 5.3 UserDefaults 与 AppStorage

```swift
// SwiftUI AppStorage
struct SettingsView: View {
    @AppStorage("isDarkMode") private var isDarkMode = false
    @AppStorage("userName") private var userName = ""
    @AppStorage("launchCount") private var launchCount = 0

    var body: some View {
        Form {
            Toggle("深色模式", isOn: $isDarkMode)
            TextField("用户名", text: $userName)
            Text("启动次数: \(launchCount)")
        }
    }
}

// UserDefaults 封装
@propertyWrapper
struct UserDefault<T: Codable> {
    let key: String
    let defaultValue: T

    var wrappedValue: T {
        get {
            if let data = UserDefaults.standard.data(forKey: key),
               let value = try? JSONDecoder().decode(T.self, from: data) {
                return value
            }
            return defaultValue
        }
        set {
            if let data = try? JSONEncoder().encode(newValue) {
                UserDefaults.standard.set(data, forKey: key)
            }
        }
    }
}
```

---

## 六、网络层

### 6.1 URLSession 封装

```swift
import Foundation

enum HTTPMethod: String {
    case GET, POST, PUT, PATCH, DELETE
}

protocol APIClientProtocol {
    func request<T: Decodable>(
        _ endpoint: Endpoint,
        responseType: T.Type
    ) async throws -> T
}

struct APIClient: APIClientProtocol {
    private let session: URLSession
    private let baseURL: URL

    init(baseURL: URL = URL(string: "https://api.example.com")!,
         session: URLSession = .shared) {
        self.baseURL = baseURL
        self.session = session
    }

    func request<T: Decodable>(
        _ endpoint: Endpoint,
        responseType: T.Type
    ) async throws -> T {
        let request = try buildRequest(from: endpoint)
        let (data, response) = try await session.data(for: request)

        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.invalidResponse
        }

        guard (200...299).contains(httpResponse.statusCode) else {
            throw APIError.serverError(statusCode: httpResponse.statusCode)
        }

        do {
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            return try decoder.decode(T.self, from: data)
        } catch {
            throw APIError.decodingError(error)
        }
    }

    private func buildRequest(from endpoint: Endpoint) throws -> URLRequest {
        let url = baseURL.appendingPathComponent(endpoint.path)
        var request = URLRequest(url: url)
        request.httpMethod = endpoint.method.rawValue
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        // 添加认证头
        if let token = AuthManager.shared.accessToken {
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        }

        if let body = endpoint.body {
            request.httpBody = try JSONEncoder().encode(body)
        }

        return request
    }
}

struct Endpoint {
    let path: String
    let method: HTTPMethod
    let body: Encodable?
    let queryItems: [URLQueryItem]?

    static var users: Self {
        Endpoint(path: "/users", method: .GET, body: nil, queryItems: nil)
    }

    static func createUser(_ user: CreateUserRequest) -> Self {
        Endpoint(path: "/users", method: .POST, body: user, queryItems: nil)
    }
}

enum APIError: LocalizedError {
    case invalidResponse
    case serverError(statusCode: Int)
    case decodingError(Error)
    case networkError(Error)

    var errorDescription: String? {
        switch self {
        case .invalidResponse: return "无效的响应"
        case .serverError(let code): return "服务器错误 (\(code))"
        case .decodingError(let error): return "数据解析失败: \(error.localizedDescription)"
        case .networkError(let error): return "网络错误: \(error.localizedDescription)"
        }
    }
}
```

### 6.2 图片缓存

```swift
actor ImageCache {
    static let shared = ImageCache()
    private let cache = NSCache<NSString, UIImage>()

    init() {
        cache.countLimit = 100
        cache.totalCostLimit = 50 * 1024 * 1024 // 50MB
    }

    func image(forKey key: String) -> UIImage? {
        cache.object(forKey: key as NSString)
    }

    func setImage(_ image: UIImage, forKey key: String) {
        cache.setObject(image, forKey: key as NSString)
    }
}
```

---

## 七、Xcode 项目结构

### 7.1 推荐项目目录结构

```
MyApp/
├── App/
│   ├── AppDelegate.swift
│   └── SceneDelegate.swift
├── Features/
│   ├── Auth/
│   │   ├── ViewModels/
│   │   ├── Views/
│   │   └── Models/
│   ├── Home/
│   │   ├── ViewModels/
│   │   ├── Views/
│   │   └── Models/
│   └── Profile/
│       ├── ViewModels/
│       ├── Views/
│       └── Models/
├── Core/
│   ├── Network/
│   │   ├── APIClient.swift
│   │   ├── Endpoints.swift
│   │   └── AuthManager.swift
│   ├── Storage/
│   │   ├── CoreDataStack.swift
│   │   └── UserDefaultsManager.swift
│   └── Extensions/
│       ├── String+Extensions.swift
│       ├── View+Extensions.swift
│       └── Date+Extensions.swift
├── DesignSystem/
│   ├── Components/
│   ├── Theme/
│   └── Assets.xcassets/
├── Resources/
│   ├── Localizable.xcstrings
│   └── Info.plist
└── Tests/
    ├── UnitTests/
    └── UITests/
```

---

## 八、XCTest 单元测试

### 8.1 ViewModel 测试

```swift
import XCTest
@testable import MyApp

final class UserViewModelTests: XCTestCase {
    private var sut: UserViewModel!
    private var mockRepository: MockUserRepository!

    override func setUp() {
        super.setUp()
        mockRepository = MockUserRepository()
        sut = UserViewModel(repository: mockRepository)
    }

    override func tearDown() {
        sut = nil
        mockRepository = nil
        super.tearDown()
    }

    func testLoadUsersSuccess() async {
        // Given
        let expectedUsers = [
            User(id: UUID(), name: "Alice", email: "alice@test.com", avatarURL: ""),
            User(id: UUID(), name: "Bob", email: "bob@test.com", avatarURL: "")
        ]
        mockRepository.stubbedFetchResult = expectedUsers

        // When
        await sut.loadUsers()

        // Then
        XCTAssertEqual(sut.users.count, 2)
        XCTAssertEqual(sut.users.first?.name, "Alice")
        XCTAssertFalse(sut.isLoading)
        XCTAssertNil(sut.errorMessage)
    }

    func testLoadUsersFailure() async {
        // Given
        mockRepository.stubbedError = APIError.serverError(statusCode: 500)

        // When
        await sut.loadUsers()

        // Then
        XCTAssertTrue(sut.users.isEmpty)
        XCTAssertNotNil(sut.errorMessage)
        XCTAssertFalse(sut.isLoading)
    }
}

class MockUserRepository: UserRepositoryProtocol {
    var stubbedFetchResult: [User]!
    var stubbedError: Error?

    func fetchAllUsers() async throws -> [User] {
        if let error = stubbedError { throw error }
        return stubbedFetchResult ?? []
    }

    func delete(_ user: User) async throws {
        // mock implementation
    }
}
```

### 8.2 Snapshot 测试

```swift
// 使用 Swift Testing (Xcode 16+)
import Testing
import SnapshotTesting
@testable import MyApp

@Suite("UserListView Snapshots")
struct UserListViewSnapshotTests {
    @Test("light mode")
    func lightMode() {
        let users = [
            User(id: UUID(), name: "Alice", email: "alice@test.com", avatarURL: ""),
            User(id: UUID(), name: "Bob", email: "bob@test.com", avatarURL: "")
        ]
        let viewModel = UserViewModel()
        viewModel.users = users

        let view = UserListView(viewModel: viewModel)
        assertSnapshot(of: view, as: .image)
    }
}
```

---

## 九、性能优化

### 9.1 列表性能优化

```swift
// SwiftUI 列表性能最佳实践
struct OptimizedListView: View {
    let items: [Item]

    var body: some View {
        List(items) { item in
            ItemRow(item: item)
                .id(item.id) // 确保唯一标识
        }
        .listStyle(.plain)
        .environment(\.defaultMinListRowHeight, 60) // 固定行高
    }
}

// UITableViewCell 复用优化
class OptimizedCell: UITableViewCell {
    private static let reuseIdentifier = "OptimizedCell"

    static func register(in tableView: UITableView) {
        tableView.register(OptimizedCell.self, forCellReuseIdentifier: reuseIdentifier)
    }

    static func dequeue(from tableView: UITableView, for indexPath: IndexPath) -> OptimizedCell {
        tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath) as! OptimizedCell
    }

    func configure(with item: Item) {
        // 重置状态避免复用污染
        textLabel?.text = item.title
        imageView?.image = item.thumbnailImage
    }
}
```

### 9.2 内存优化

```swift
// 懒加载大对象
class HeavyDataProcessor {
    lazy var expensiveCache: [String: Data] = {
        print("初始化缓存...")
        return [:]
    }()

    // 使用 weak 避免循环引用
    weak var delegate: DataProcessorDelegate?
}

// 图片降采样
extension UIImage {
    func downsample(to size: CGSize, scale: CGFloat = UIScreen.main.scale) -> UIImage {
        let imageSourceOptions = [kCGImageSourceShouldCache: false] as CFDictionary
        guard let imageSource = CGImageSourceCreateWithData(
            self.jpegData(compressionQuality: 0.8)! as CFData, imageSourceOptions
        ) else { return self }

        let maxDimensionInPixels = max(size.width, size.height) * scale
        let downsampleOptions = [
            kCGImageSourceCreateThumbnailFromImageAlways: true,
            kCGImageSourceShouldCacheImmediately: true,
            kCGImageSourceCreateThumbnailWithTransform: true,
            kCGImageSourceThumbnailMaxPixelSize: maxDimensionInPixels
        ] as CFDictionary

        guard let thumbnail = CGImageSourceCreateThumbnailAtIndex(imageSource, 0, downsampleOptions) else { return self }
        return UIImage(cgImage: thumbnail)
    }
}
```

### 9.3 启动优化

```swift
// 延迟加载非关键模块
@main
struct OptimizedApp: App {
    init() {
        // 仅初始化必要配置
        AppConfiguration.setup()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .onAppear {
                    // 延迟初始化非关键服务
                    Task {
                        AnalyticsManager.shared.initialize()
                        CrashReporter.shared.start()
                    }
                }
        }
    }
}
```

---

## 十、常见错误排查

### 10.1 编译错误

| 错误信息 | 原因 | 解决方案 |
|---------|------|---------|
| `Use of unresolved identifier` | 变量/类型未定义或未导入 | 检查命名空间和 import 语句 |
| `Type 'X' does not conform to protocol 'Y'` | 缺少协议要求的实现 | 添加缺失的协议方法/属性 |
| `Value of type 'Optional' not unwrapped` | 未处理可选值 | 使用 if-let、guard-let 或 ?/! |
| `Generic parameter could not be inferred` | 泛型类型推断失败 | 显式指定泛型类型参数 |
| `Cannot assign value of type 'X' to type 'Y'` | 类型不匹配 | 检查类型转换或使用 as? |

### 10.2 运行时错误

| 错误 | 原因 | 解决方案 |
|------|------|---------|
| `EXC_BAD_ACCESS` | 内存访问越界/野指针 | 开启 Address Sanitizer，检查强/弱引用 |
| `fatal error: Index out of range` | 数组越界 | 添加边界检查 |
| `unexpectedly found nil` | 强制解包 nil | 使用安全解包 |
| `Thread 1: signal SIGABRT` | 未捕获异常 | 查看 `NSException` 信息 |
| `This application is modifying the autolayout engine from a background thread` | 后台线程修改 UI | 回到主线程操作 UI |

### 10.3 Auto Layout 调试

```swift
// 在开发阶段添加视图边界可视化
#if DEBUG
extension UIView {
    func showBorders() {
        subviews.forEach { view in
            view.layer.borderWidth = 1
            view.layer.borderColor = UIColor.red.cgColor
            view.showBorders()
        }
    }
}
#endif
```

---

## 十一、App Store 提交检查清单

### 提交前检查

- [ ] **图标与启动页**
  - [ ] App 图标：1024x1024，无透明通道
  - [ ] 各尺寸图标已包含在 Assets 中
  - [ ] 启动页适配所有屏幕尺寸
  - [ ] 深色模式启动页适配

- [ ] **应用信息**
  - [ ] Bundle Identifier 唯一且一致
  - [ ] Version 和 Build 号正确递增
  - [ ] Info.plist 必填字段完整
  - [ ] App Category 正确选择

- [ ] **权限与隐私**
  - [ ] Info.plist 中声明所有使用到的权限描述
    - `NSCameraUsageDescription`
    - `NSPhotoLibraryUsageDescription`
    - `NSLocationWhenInUseUsageDescription`
    - `NSMicrophoneUsageDescription`
    - `NSContactsUsageDescription`
  - [ ] 隐私政策 URL 已填写
  - [ ] 数据收集声明准确填写

- [ ] **功能测试**
  - [ ] 所有核心功能在真机上测试通过
  - [ ] iPad 适配（如支持）
  - [ ] 深色模式测试
  - [ ] 网络断开/弱网环境测试
  - [ ] 低内存/后台状态测试
  - [ ] VoiceOver 无障碍测试

- [ ] **代码质量**
  - [ ] 无编译警告
  - [ ] 无调试代码或 TODO 遗留
  - [ ] 检查硬编码的 API Key/Secret
  - [ ] 移除所有 print/console.log 语句
  - [ ] 第三方 SDK 版本合规

- [ ] **App Store Connect**
  - [ ] 截图覆盖所有设备尺寸
  - [ ] App 描述、关键词、支持 URL 准确
  - [ ] 年龄分级问卷完成
  - [ ] 加密声明（如使用 HTTPS）
  - [ ] 广告标识符声明（如使用 IDFA）

### TestFlight 测试

```bash
# 使用 xcodebuild 命令行构建
xcodebuild archive \
  -workspace MyApp.xcworkspace \
  -scheme MyApp \
  -configuration Release \
  -archivePath ./build/MyApp.xcarchive

# 导出 IPA
xcodebuild -exportArchive \
  -archivePath ./build/MyApp.xcarchive \
  -exportPath ./build/ipa \
  -exportOptionsPlist ExportOptions.plist
```

---

## 十二、实用扩展

### 12.1 常用 Swift 扩展

```swift
// String 扩展
extension String {
    var isValidEmail: Bool {
        NSPredicate(format: "SELF MATCHES %@", "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}")
            .evaluate(with: self)
    }

    var localized: String {
        NSLocalizedString(self, comment: "")
    }
}

// Date 扩展
extension Date {
    var formatted: String {
        formatted("yyyy-MM-dd HH:mm")
    }

    func formatted(_ format: String) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = format
        formatter.locale = Locale(identifier: "zh_CN")
        return formatter.string(from: self)
    }

    var isToday: Bool {
        Calendar.current.isDateInToday(self)
    }
}

// View 扩展
extension View {
    func hideKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }

    func conditionallyHidden(_ condition: Bool) -> some View {
        opacity(condition ? 0 : 1)
            .frame(height: condition ? 0 : nil)
    }
}

// Bundle 扩展
extension Bundle {
    var appVersion: String {
        infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0"
    }

    var buildNumber: String {
        infoDictionary?[kCFBundleVersionKey as String] as? String ?? "1"
    }
}
```

---

## 快速参考

| 领域 | 关键点 |
|------|--------|
| **SwiftUI 状态** | @State（本地）、@Binding（传递）、@Observable（对象） |
| **架构选择** | 小项目 → MVVM；中项目 → MVVM + Clean Architecture；大项目 → VIPER |
| **数据持久化** | 简单数据 → UserDefaults；结构化 → SwiftData/Core Data |
| **网络层** | 封装 URLSession + Endpoint + 泛型解码 |
| **性能** | 列表复用、图片降采样、懒加载、避免主线程阻塞 |
| **测试** | Protocol 驱动的 Mock、XCTest + Swift Testing |
| **提交** | 权限声明、截图、隐私政策、无调试代码 |
