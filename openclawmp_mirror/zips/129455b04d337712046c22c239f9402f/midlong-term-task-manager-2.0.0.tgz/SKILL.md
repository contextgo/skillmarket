---
name: midlong-term-task-manager
displayName: 中长期任务管理
description: 专为 AI Agent 设计的任务管理系统，集成心跳检查，自动跟踪进度，防止遗忘
version: 2.0.0
tags: [task-management, automation, productivity, agent-tools, heartbeat]
---

# 中长期任务管理 - Agent 必备工具

## 🎯 技能概述

帮助 AI Agent 管理跨天/跨周的中长期任务，避免遗忘和延期。

**核心特性：**
- 🔔 心跳检查自动集成（每 30 分钟 review）
- 📊 任务进度可视化
- ⏰ 延期自动提醒
- 📁 独立存储（不干扰三层记忆系统）

```json
{
  "tasks": [
    {
      "id": "TSK-20260330-001",
      "name": "学习中长期任务管理",
      "description": "悠悠学习任务管理技能的开发",
      "type": "learning",
      "priority": "high",
      "status": "in_progress",
      "created_at": "2026-03-30T10:30:00+08:00",
      "due_date": "2026-04-06",
      "decomposed": [
        {
          "subtask": "设计数据结构",
          "status": "done",
          "due_date": "2026-03-30"
        },
        {
          "subtask": "编写 SKILL.md",
          "status": "in_progress",
          "due_date": "2026-03-30"
        },
        {
          "subtask": "创建心跳检查脚本",
          "status": "pending",
          "due_date": "2026-03-31"
        }
      ],
      "progress": 33,
      "last_updated": "2026-03-30T10:30:00+08:00",
      "blocked_by": null,
      "depends_on": [],
      "tags": ["skill-development", "self-improvement"]
    }
  ]
}
```

---

## 任务状态

| 状态 | 说明 | 心跳检查动作 |
|------|------|-------------|
| `pending` | 待开始 | 检查是否到达开始日期 |
| `in_progress` | 进行中 | 记录进度，检查是否延期 |
| `blocked` | 阻塞 | 提醒解除阻塞条件 |
| `completed` | 已完成 | 归档，生成总结 |
| `paused` | 暂停 | 记录暂停原因 |
| `cancelled` | 已取消 | 归档 |

---

## 使用方法

### 添加任务

```bash
# 命令格式
task_add <name> --due <YYYY-MM-DD> --priority <low|medium|high> --desc <description>

# 示例
task_add "学习具身智能" --due 2026-04-15 --priority high --desc "帮助智哥了解具身智能基础"
```

### 命令行工具

**位置：** `~/.openclaw/skills/midlong-term-task-manager/task`

```bash
# 添加任务
task add "学习具身智能" --due 2026-04-15 --priority high

# 列出任务
task list
task list in_progress

# 更新任务
task update TSK-20260330-001 --progress 50 --status in_progress

# 完成任务
task complete TSK-20260330-001

# 运行心跳检查
task check
```

### 更新进度（旧 API，保留兼容）

```bash
task_update <task_id> --progress <0-100> --status <status> --note <note>
```

---

## 心跳检查集成

在 `HEARTBEAT.md` 中添加：

```markdown
### 【6】任务进度检查
- 运行 `~/.openclaw/skills/midlong-term-task-manager/task check`
- 检查所有 `in_progress` 任务
- 记录进度到 `.tasks/logs/YYYY-MM-DD.md`
- 如有延期风险，在汇报中提醒
```

---

## Cron 配置

```bash
# 任务检查（心跳时运行，每 30 分钟）
# 在 HEARTBEAT.md 中调用脚本

# 每日总结（每天 20:00）
0 20 * * * ~/.openclaw/skills/midlong-term-task-manager/scripts/daily_summary.sh >> ~/.openclaw/workspace/.tasks/daily.log 2>&1

# 每周 review（每周一 09:00）
0 9 * * 1 ~/.openclaw/skills/midlong-term-task-manager/scripts/weekly_review.sh >> ~/.openclaw/workspace/.tasks/weekly.log 2>&1
```

---

## 与三层记忆系统集成

**正确做法：**
1. ✅ 任务进度日志 → `.tasks/logs/YYYY-MM-DD.md`
2. ✅ 任务完成总结 → `.learnings/LEARNINGS.md`
3. ✅ 由三层记忆技能自动压缩到 MEMORY.md

**错误做法：**
- ❌ 直接编辑 MEMORY.md
- ❌ 直接写入 `memory/YYYY-MM-DD.md`（这是三层记忆技能的 L2 存储）

---

## 文件结构

```
~/.openclaw/skills/midlong-term-task-manager/
├── SKILL.md              # 技能说明
└── scripts/
    ├── task_check.sh     # 心跳检查脚本
    ├── daily_summary.sh  # 每日总结脚本
    └── weekly_review.sh  # 每周 review 脚本

~/.openclaw/workspace/.tasks/
├── tasks.json            # 任务数据库
└── logs/
    └── YYYY-MM-DD.md     # 每日进度日志
```

---

## 最佳实践

1. **及时登记** - 接到任务立即记录，避免遗忘
2. **合理分解** - 长期任务分解为周/日计划
3. **定期 review** - 心跳时自动检查进度
4. **诚实记录** - 延期不隐瞒，及时调整计划
5. **完成总结** - 每个任务完成后记录学习心得

---

## 版本历史

- **v0.1.0** (2026-03-30) - 初始版本，基础功能
