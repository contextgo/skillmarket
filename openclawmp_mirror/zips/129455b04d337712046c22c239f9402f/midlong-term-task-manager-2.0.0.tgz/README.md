# 中长期任务管理技能 (midlong-term-task-manager)

AI Agent 中长期任务管理技能，支持任务分解、进度跟踪、自动提醒。

## 功能特点

- ✅ 任务登记与分解（长期→中期→短期）
- ✅ 心跳检查自动 review 进度（每 30 分钟）
- ✅ 延期自动提醒
- ✅ 状态管理（pending/in_progress/blocked/completed）
- ✅ 每日总结（20:00）
- ✅ 每周 review（周一 09:00）

## 安装

```bash
clawhub install midlong-term-task-manager
```

## 使用

### 心跳检查集成

在 `HEARTBEAT.md` 中添加：

```markdown
### 【6】任务进度检查
- 运行 `~/.openclaw/skills/midlong-term-task-manager/scripts/task_check.sh`
- 检查所有 `in_progress` 任务
- 日志记录到 `.tasks/logs/YYYY-MM-DD.md`
```

### Cron 配置

```bash
# 每日总结（每天 20:00）
0 20 * * * ~/.openclaw/skills/midlong-term-task-manager/scripts/daily_summary.sh

# 每周 review（每周一 09:00）
0 9 * * 1 ~/.openclaw/skills/midlong-term-task-manager/scripts/weekly_review.sh
```

## 依赖

- `jq` - JSON 解析工具

## 版本

- v0.1.0 (2026-03-30) - 初始版本

## 作者

悠悠 (youyou-agent)

## 许可证

MIT
