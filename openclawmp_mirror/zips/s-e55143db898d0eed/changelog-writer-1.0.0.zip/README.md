# 更新日志(Changelog)助手

## 更新日志格式（Keep a Changelog）

```markdown
# 更新日志

本文档按照[Keep a Changelog](https://keepachangelog.com/zh-CN/1.0.0/)格式编写。

## [版本号] - YYYY-MM-DD

### Added（新增）
- 新功能描述

### Changed（变更）
- 功能变更描述

### Deprecated（弃用）
- 即将弃用的功能

### Removed（移除）
- 已移除的功能

### Fixed（修复）
- Bug修复描述

### Security（安全）
- 安全相关更新
```

## 更新日志示例

```markdown
# 更新日志

## [2.1.0] - 2024-03-15

### Added
- 新增用户画像功能
- 新增数据导出为Excel功能
- 新增批量操作支持
- 新增API限流功能

### Changed
- 优化页面加载速度，提升50%
- 优化数据库查询性能
- 改进了移动端适配体验

### Deprecated
- `old_api_v1()` 将在3.0版本移除，请使用 `new_api_v2()`

### Fixed
- 修复了导出大数据量时内存溢出问题
- 修复了特定浏览器下图表显示异常
- 修复了搜索结果分页不准确的问题

### Security
- 升级依赖库版本，修补安全漏洞

---

## [2.0.0] - 2024-01-01

### Added
- 全新设计的用户界面
- 支持多语言（中文、英文、日文）
- 支持深色模式
- 新增数据分析模块

### Changed
- 全面重构底层架构
- 数据库从MySQL迁移到PostgreSQL
- API版本从v1升级到v2

### Breaking Changes（破坏性变更）
- 旧版API不再兼容，请参考迁移指南
- 配置文件格式变更
- 最低支持Node.js 18版本

### Removed
- 移除Flash依赖
- 移除IE浏览器支持
```

## 版本号规范

```markdown
版本号格式：主版本.次版本.修订号

主版本（MAJOR）：不兼容的重大API变更
次版本（MINOR）：向后兼容的功能新增
修订号（PATCH）：向后兼容的问题修复

示例：
1.0.0 → 1.0.1 → 1.1.0 → 2.0.0
```

## 变更类型说明

| 类型 | 英文 | 说明 |
|------|------|------|
| 新增 | Added | 新功能 |
| 变更 | Changed | 功能变化 |
| 弃用 | Deprecated | 即将移除 |
| 移除 | Removed | 已移除功能 |
| 修复 | Fixed | Bug修复 |
| 安全 | Security | 安全更新 |

## 提交信息规范（Conventional Commits）

```markdown
格式：<type>(<scope>): <subject>

类型：
- feat：新功能
- fix：Bug修复
- docs：文档更新
- style：格式调整
- refactor：重构
- perf：性能优化
- test：测试相关
- chore：构建/工具

示例：
feat(user): 新增用户注册功能
fix(order): 修复订单支付回调问题
docs(api): 更新API文档
refactor(auth): 重构登录模块
```

## 快速生成更新日志

```markdown
# 自动生成脚本思路

1. 收集提交记录
git log --pretty=format:"%s" v1.0.0..v2.0.0

2. 按类型分类
feat: 5个
fix: 3个
docs: 2个

3. 按模块分组
user: 3个
order: 4个
payment: 3个

4. 生成CHANGELOG.md
```

## 发布说明模板

```markdown
# v2.1.0 发布说明

发布日期：2024-03-15
发布类型：功能更新

## 重要更新

### 🎉 用户画像功能上线
新功能描述...

### ⚡ 性能大幅提升
性能改进描述...

## 功能详情

### 新增功能
1. xxx
2. xxx

### 功能优化
1. xxx
2. xxx

### Bug修复
1. xxx
2. xxx

## 升级指南

### 从v2.0.x升级
1. 备份数据
2. 执行迁移脚本
3. 更新配置文件
4. 重启服务

### 迁移脚本
```bash
./migrate.sh v2.0 v2.1
```

## 已知问题
- xxx

## 下一步计划
- v2.2.0：xxx
- v3.0.0：xxx

## 反馈与问题
如有问题请提交Issue
```