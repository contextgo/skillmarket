﻿# -*- coding: utf-8 -*-
"""
水产市场资产发布脚本
用途：自动化发布资产到 openclawmp.cc 水产市场
创建时间：2026-03-13
作者：林溪

使用方法:
    python publish-openclawmp-asset.py <资产目录> <资产类型> <资产名称> <显示名称> <描述>

示例:
    python publish-openclawmp-asset.py ./my-skill skill my-skill "我的技能" "技能描述"
"""

import requests
import json
import os
import sys
import tarfile
import tempfile
from pathlib import Path

# ============================================================================
# 配置
# ============================================================================

API_BASE = "https://openclawmp.cc"
OPENCLAW_DIR = Path.home() / ".openclaw"
DEVICE_FILE = OPENCLAW_DIR / "identity" / "device.json"
AUTH_FILE = OPENCLAW_DIR / "identity" / "device-auth.json"

# ============================================================================
# 辅助函数
# ============================================================================

def read_device_auth():
    """读取设备认证信息"""
    if not DEVICE_FILE.exists():
        raise FileNotFoundError(f"设备文件不存在：{DEVICE_FILE}")
    if not AUTH_FILE.exists():
        raise FileNotFoundError(f"认证文件不存在：{AUTH_FILE}")
    
    with open(DEVICE_FILE, 'r', encoding='utf-8') as f:
        device_data = json.load(f)
        device_id = device_data.get('deviceId')
    
    with open(AUTH_FILE, 'r', encoding='utf-8') as f:
        auth_data = json.load(f)
        operator_token = auth_data.get('tokens', {}).get('operator', {}).get('token')
    
    if not device_id:
        raise ValueError("未找到 deviceId")
    if not operator_token:
        raise ValueError("未找到 operator token")
    
    return device_id, operator_token

def create_tarball(source_dir, output_path):
    """创建 tar.gz 压缩包"""
    source_path = Path(source_dir)
    if not source_path.exists():
        raise FileNotFoundError(f"资产目录不存在：{source_path}")
    
    with tarfile.open(output_path, "w:gz") as tar:
        for item in source_path.rglob("*"):
            if item.name.startswith('.'):
                continue
            if item.is_file():
                arcname = item.relative_to(source_path)
                tar.add(item, arcname=arcname)
    
    return output_path

def validate_asset_type(asset_type, source_dir):
    """验证资产类型和必需文件"""
    source_path = Path(source_dir)
    
    if asset_type == "skill":
        if not (source_path / "SKILL.md").exists():
            raise FileNotFoundError(f"Skill 类型需要 SKILL.md 文件")
    elif asset_type in ["trigger", "experience", "plugin", "channel"]:
        if not (source_path / "README.md").exists():
            raise FileNotFoundError(f"{asset_type} 类型需要 README.md 文件")
    
    return True

def publish_asset(metadata, tarball_path, device_id, operator_token):
    """发布资产到水产市场"""
    headers = {
        "X-Device-ID": device_id,
        "Authorization": f"Bearer {operator_token}"
    }
    
    with open(tarball_path, 'rb') as f:
        files = {
            'package': ('package.tar.gz', f, 'application/gzip'),
            'metadata': (None, json.dumps(metadata, ensure_ascii=False), 'application/json')
        }
        
        response = requests.post(
            f"{API_BASE}/api/v1/assets/publish",
            headers=headers,
            files=files,
            timeout=60
        )
    
    return response

def main():
    """主函数"""
    if len(sys.argv) < 6:
        print("用法：python publish-openclawmp-asset.py <资产目录> <资产类型> <资产名称> <显示名称> <描述> [标签]")
        print("示例：python publish-openclawmp-asset.py ./my-skill skill my-skill \"我的技能\" \"技能描述\" tag1,tag2")
        sys.exit(1)
    
    # 解析参数
    source_dir = sys.argv[1]
    asset_type = sys.argv[2]
    asset_name = sys.argv[3]
    display_name = sys.argv[4]
    description = sys.argv[5]
    tags = sys.argv[6].split(",") if len(sys.argv) > 6 and sys.argv[6] else []
    
    # 验证资产类型
    valid_types = ["skill", "trigger", "experience", "plugin", "channel"]
    if asset_type not in valid_types:
        print(f" 无效的资产类型：{asset_type}")
        print(f"有效类型：{', '.join(valid_types)}")
        sys.exit(1)
    
    try:
        # 1. 读取设备认证
        print(" 读取设备认证信息...")
        device_id, operator_token = read_device_auth()
        print(f" 设备 ID: {device_id[:12]}...")
        
        # 2. 验证资产
        print(" 验证资产文件...")
        validate_asset_type(asset_type, source_dir)
        print(f" 资产验证通过")
        
        # 3. 创建压缩包
        print(" 创建压缩包...")
        tarball_path = Path(tempfile.gettempdir()) / f"openclawmp-{asset_name}.tar.gz"
        create_tarball(source_dir, tarball_path)
        size_kb = tarball_path.stat().st_size / 1024
        print(f" 压缩包大小：{size_kb:.1f}KB")
        
        # 4. 准备 metadata
        metadata = {
            "name": asset_name,
            "displayName": display_name,
            "type": asset_type,
            "version": "1.0.0",
            "description": description,
            "tags": tags,
        }
        
        # 5. 发布资产
        print(" 发布资产...")
        response = publish_asset(metadata, tarball_path, device_id, operator_token)
        
        # 6. 处理响应
        if response.status_code == 201:
            data = response.json().get('data', {})
            asset_id = data.get('id')
            print("")
            print(" 发布成功！")
            print("")
            print(f"资产 ID: {asset_id}")
            print(f"资产名称：{display_name}")
            print(f"类型：{asset_type}")
            print(f"页面：https://openclawmp.cc/asset/{asset_id}")
            print("")
            
            # 清理临时文件
            try:
                tarball_path.unlink()
            except:
                pass
            
            return asset_id
        else:
            print(f" 发布失败 (HTTP {response.status_code})")
            print(f"错误：{response.text}")
            sys.exit(1)
            
    except Exception as e:
        print(f" 错误：{str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
