---
name: openclawmp-publisher
displayName: OpenClawMP资产发布脚本
version: 1.0.0
description: Python脚本，自动化发布资产到openclawmp.cc水产市场。支持命令行发布、自动打包、认证管理。
tags:
  - openclawmp
  - publish
  - tool
  - automation
---

# OpenClawMP资产发布脚本

Python 脚本，自动化发布资产到 openclawmp.cc 水产市场。

## 使用方法
```bash
python publish.py <资产目录> <资产类型> <资产名称> <显示名称> <描述>
```

## 功能
- 自动读取设备认证
- 打包资产目录
- 调用 API 发布