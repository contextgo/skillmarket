# 歌词转录技能

通过 OpenAI Whisper 或 ElevenLabs Scribe API 将音频文件转录为带时间戳的歌词（LRC/SRT/JSON）。

## API 密钥设置指南

**在转录之前，您必须检查用户的 API 密钥是否已配置。** 运行以下命令检查：

```bash
cd "{project_root}/{.claude or .codex}/skills/acestep-lyrics-transcription/" && bash ./scripts/acestep-lyrics-transcription.sh config --check-key
```

此命令仅报告活动提供商的 API 密钥是否已设置或为空 — 它不会打印实际的密钥值。**切勿读取或显示用户的 API 密钥内容。** 不要对密钥字段使用 `config --get` 或直接读取 `config.json`。`config --list` 命令是安全的 — 它会自动将 API 密钥掩码为 `***` 输出。

**如果命令报告密钥为空**，您必须停止并指导用户在继续之前配置它。切勿在没有有效密钥的情况下尝试转录 — 它将失败。

使用 `AskUserQuestion` 要求用户提供其 API 密钥，并提供以下选项和指导：

1. 告诉用户当前活动的提供商（openai 或 elevenlabs）及其 API 密钥未配置。解释没有它无法继续转录。
2. 提供获取密钥的明确说明：
   - **OpenAI**：在 https://platform.openai.com/api-keys 获取 API 密钥 — 需要启用计费的 OpenAI 账户。Whisper API 的费用约为 $0.006/分钟。
   - **ElevenLabs**：在 https://elevenlabs.io/app/settings/api-keys 获取 API 密钥 — 需要 ElevenLabs 账户。免费套餐包含有限的积分。
3. 如果他们已经有该提供商的密钥，还提供切换到另一个提供商的选项。
4. 用户提供密钥后，使用以下命令配置它：
   ```bash
   cd "{project_root}/{.claude or .codex}/skills/acestep-lyrics-transcription/" && bash ./scripts/acestep-lyrics-transcription.sh config --set <provider>.api_key <KEY>
   ```
5. 如果用户想要切换提供商，还需运行：
   ```bash
   cd "{project_root}/{.claude or .codex}/skills/acestep-lyrics-transcription/" && bash ./scripts/acestep-lyrics-transcription.sh config --set provider <provider_name>
   ```
6. 配置后，重新运行 `config --check-key` 以在继续前验证密钥已设置。

**如果 API 密钥已配置**，直接进行转录而无需询问。

## 快速开始

```bash
# 1. cd 到此技能目录
cd {project_root}/{.claude or .codex}/skills/acestep-lyrics-transcription/

# 2. 配置 API 密钥（选择一个）
./scripts/acestep-lyrics-transcription.sh config --set openai.api_key sk-...
# 或
./scripts/acestep-lyrics-transcription.sh config --set elevenlabs.api_key ...
./scripts/acestep-lyrics-transcription.sh config --set provider elevenlabs

# 3. 转录
./scripts/acestep-lyrics-transcription.sh transcribe --audio /path/to/song.mp3 --language zh

# 4. 输出保存到：{project_root}/acestep_output/<filename>.lrc
```

## 先决条件

- curl, jq, python3 (或 python)
- OpenAI 或 ElevenLabs 的 API 密钥

## 脚本使用

```bash
./scripts/acestep-lyrics-transcription.sh transcribe --audio <file> [options]

选项：
  -a, --audio      音频文件路径（必需）
  -l, --language   语言代码（zh, en, ja 等）
  -f, --format     输出格式：lrc, srt, json（默认：lrc）
  -p, --provider   API 提供商：openai, elevenlabs（覆盖配置）
  -o, --output     输出文件路径（默认：acestep_output/<filename>.lrc）
```

## 转录后歌词校正（必需）

**关键**：转录后，您必须在使用 LRC 文件进行 MV 渲染之前手动校正它。转录模型经常在歌词上产生错误：

- 专有名词："ACE-Step" → "AC step"，"Spotify" → "spot a fly"
- 发音相似的词："arrives" → "eyes"，"open source" → "open sores"
- 合并/拆分的词："lighting up" → "lightin' nup"

### 校正工作流程

1. **使用 Read 工具读取转录的 LRC 文件**
2. **从 ACE-Step 输出 JSON 文件中读取原始歌词**
3. **将原始歌词作为整体参考**：不要尝试逐行对齐 — 转录经常与原始歌词不同地拆分、合并或重新排序行。相反，完整阅读原始歌词以了解正确的措辞，然后扫描每个 LRC 行并根据您对原始歌词的了解纠正任何错误识别的词。
4. **纠正转录错误**：用正确的原始词替换错误识别的词，保持时间戳不变
5. **使用 Write 工具写回校正后的 LRC**

### 校正内容

- 用正确的原始版本替换错误识别的词
- 保持所有 `[MM:SS.cc]` 时间戳完全不变（转录的时间戳是准确的）
- 不要添加诸如 `[Verse]` 或 `[Chorus]` 之类的结构标签 — LRC 应只有带时间戳的文本行

### 示例

**转录（错误）：**
```
[00:46.96]AC step alive,
[00:50.80]one point five eyes.
```

**原始歌词参考：**
```
ACE-Step alive
One point five arrives
```

**校正（正确）：**
```
[00:46.96]ACE-Step alive,
[00:50.80]One point five arrives.
```

## 配置

配置文件：`scripts/config.json`

```bash
# 切换提供商
./scripts/acestep-lyrics-transcription.sh config --set provider openai
./scripts/acestep-lyrics-transcription.sh config --set provider elevenlabs

# 设置 API 密钥
./scripts/acestep-lyrics-transcription.sh config --set openai.api_key sk-...
./scripts/acestep-lyrics-transcription.sh config --set elevenlabs.api_key ...

# 查看配置
./scripts/acestep-lyrics-transcription.sh config --list
```

| 选项 | 默认值 | 描述 |
|--------|---------|-------------|
| `provider` | `openai` | 活动提供商：`openai` 或 `elevenlabs` |
| `output_format` | `lrc` | 默认输出：`lrc`、`srt` 或 `json` |
| `openai.api_key` | `""` | OpenAI API 密钥 |
| `openai.api_url` | `https://api.openai.com/v1` | OpenAI API 基础 URL |
| `openai.model` | `whisper-1` | OpenAI 模型（whisper-1 用于词级时间戳） |
| `elevenlabs.api_key` | `""` | ElevenLabs API 密钥 |
| `elevenlabs.api_url` | `https://api.elevenlabs.io/v1` | ElevenLabs API 基础 URL |
| `elevenlabs.model` | `scribe_v2` | ElevenLabs 模型 |

## 提供商说明

| 提供商 | 模型 | 词级时间戳 | 定价 |
|----------|-------|-----------------|---------|
| OpenAI | whisper-1 | 是（段落+词） | $0.006/分钟 |
| ElevenLabs | scribe_v2 | 是（词级） | 因计划而异 |

- OpenAI `whisper-1` 是唯一支持词级时间戳的 OpenAI 模型
- ElevenLabs `scribe_v2` 返回带类型过滤的词级时间戳
- 两者都支持多语言转录

## 示例

```bash
# 基本转录（使用配置默认值）
./scripts/acestep-lyrics-transcription.sh transcribe --audio song.mp3

# 中文歌曲转 LRC
./scripts/acestep-lyrics-transcription.sh transcribe --audio song.mp3 --language zh

# 使用 ElevenLabs，输出 SRT
./scripts/acestep-lyrics-transcription.sh transcribe --audio song.mp3 --provider elevenlabs --format srt

# 自定义输出路径
./scripts/acestep-lyrics-transcription.sh transcribe --audio song.mp3 --output ./my_lyrics.lrc
```