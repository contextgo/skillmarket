# Microservice Design Patterns

## Overview
微服务架构中经过验证的设计模式，帮助构建可扩展、可维护的分布式系统。

## Decomposition Patterns

### Strangler Fig
渐进式拆分：在单体应用前放置 API Gateway，逐步将请求路由到新服务。

```
Client → API Gateway → [Old Monolith] + [New Service A] + [New Service B]
```

### Sidecar
将辅助功能（监控、日志、配置）部署为 sidecar 容器，与主服务共享网络命名空间。

```yaml
apiVersion: v1
kind: Pod
spec:
  containers:
    - name: app
      image: my-app:latest
    - name: sidecar
      image: log-collector:latest
      volumeMounts:
        - name: shared-logs
          mountPath: /var/log/app
```

### Backend for Frontend (BFF)
为不同客户端（Web、Mobile、API）提供定制化的后端 API。

## Communication Patterns

### Sync: gRPC
```protobuf
service OrderService {
  rpc CreateOrder(OrderRequest) returns (OrderResponse);
  rpc GetOrder(OrderId) returns (OrderResponse);
}
```

### Async: Event-Driven (Kafka)
```python
# Producer
producer.send('order-events', key=order_id, value=order_data)

# Consumer
consumer.subscribe(['order-events'])
for msg in consumer:
    process_order(msg.value)
```

### Saga Pattern (Distributed Transactions)
```
Create Order → Reserve Inventory → Process Payment → Ship
    ↓              ↓                   ↓              ↓
  Compensate    Release Reserve    Refund Payment  Cancel Shipment
  (if failed)   (if payment fails) (if shipping fails)
```

## Data Patterns

### CQRS
分离读写模型，优化各自性能。

### Event Sourcing
存储事件而非当前状态，可重建任意时间点的状态。

### API Composition
聚合多个服务的数据，统一返回给客户端。

## Resilience Patterns

### Circuit Breaker
```
CLOSED → (failures >= threshold) → OPEN → (timeout) → HALF-OPEN → (success) → CLOSED
```

### Bulkhead
隔离不同服务的资源池，防止故障扩散。

### Retry with Exponential Backoff
```python
@retry(stop=stop_after_attempt(3), wait=wait_exponential(multiplier=1, max=10))
def call_service():
    return requests.get(url, timeout=5)
```

## When NOT to Use Microservices
- Team < 5 developers → monolith first
- Low traffic (< 1000 QPS) → monolith with modules
- Tight consistency requirements → consider distributed monolith
- Early-stage startup → ship fast, refactor later