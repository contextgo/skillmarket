# Windows Core Audio API 参考

## IAudioEndpointVolume 接口

核心音频端点音量控制接口。

### GUID
```
5CDF2C82-841E-4546-9722-0CF74078229A
```

### 主要方法

| 方法 | 说明 |
|------|------|
| `SetMasterVolumeLevelScalar(float level, ref Guid eventContext)` | 设置主音量 (0.0-1.0) |
| `GetMasterVolumeLevelScalar(out float level)` | 获取当前音量 |
| `SetMute(bool mute, ref Guid eventContext)` | 设置静音状态 |
| `GetMute(out bool mute)` | 获取静音状态 |

## IMMDeviceEnumerator 接口

音频设备枚举器。

### GUID
```
A95664D2-9614-4F35-A746-DE8DB63617E6
```

### 主要方法

| 方法 | 说明 |
|------|------|
| `GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice device)` | 获取默认音频设备 |

### 参数说明
- `dataFlow`: 0=EPlayback (输出), 1=ECapture (输入)
- `role`: 1=Multimedia

## MMDeviceEnumerator 类

COM 类用于创建设备枚举器。

### CLSID
```
BCDE0395-E52F-467C-8E3D-C4579291692E
```

## PowerShell 完整实现

```powershell
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAudioEndpointVolume {
    int f1(); int f2(); int f3(); int f4();
    int SetMasterVolumeLevelScalar(float level, ref Guid eventContext);
    int f6(); int f7(); int f8(); int f9(); int f10();
    int GetMasterVolumeLevelScalar(out float level);
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid eventContext);
    int GetMute(out bool mute);
}

[Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IMMDevice {
    int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
}

[Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IMMDeviceEnumerator {
    int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
}

[ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
public class MMDeviceEnumeratorComObject { }

public static class AudioApi {
    static IAudioEndpointVolume GetVolumeControl() {
        var enumerator = new MMDeviceEnumeratorComObject() as IMMDeviceEnumerator;
        IMMDevice device = null;
        Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(0, 1, out device));
        object volObj = null;
        var volGuid = typeof(IAudioEndpointVolume).GUID;
        Marshal.ThrowExceptionForHR(device.Activate(ref volGuid, 0, IntPtr.Zero, out volObj));
        return (IAudioEndpointVolume)volObj;
    }
    
    public static void SetVolume(float percent) {
        float normalized = Math.Max(0, Math.Min(100, percent)) / 100f;
        Guid g = Guid.Empty;
        Marshal.ThrowExceptionForHR(GetVolumeControl().SetMasterVolumeLevelScalar(normalized, ref g));
    }
    
    public static float GetVolume() {
        float v;
        Marshal.ThrowExceptionForHR(GetVolumeControl().GetMasterVolumeLevelScalar(out v));
        return v * 100;
    }
    
    public static void SetMute(bool mute) {
        Guid g = Guid.Empty;
        Marshal.ThrowExceptionForHR(GetVolumeControl().SetMute(mute, ref g));
    }
    
    public static bool GetMute() {
        bool m;
        Marshal.ThrowExceptionForHR(GetVolumeControl().GetMute(out m));
        return m;
    }
}
"@ -ReferencedAssemblies System.Core

# 使用示例
[AudioApi]::SetVolume(60)
[AudioApi]::GetVolume()
[AudioApi]::SetMute($true)
[AudioApi]::GetMute()
```

## 注意事项

1. 需要 Windows Vista 或更高版本
2. 需要管理员权限访问某些音频设备
3. API 调用可能抛出 COM 异常，需适当处理
