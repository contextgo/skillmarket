# Windows WMI 显示器控制 API

## WmiMonitorBrightness 类

用于查询显示器当前亮度信息。

### 命名空间
```
root/wmi
```

### 属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Active` | boolean | 显示器是否活动 |
| `CurrentBrightness` | uint8 | 当前亮度值 (0-100) |
| `Levels` | uint8[] | 支持的亮度级别数组 |
| `InstanceName` | string | 实例名称 |

### PowerShell 查询

```powershell
Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightness

# 获取当前亮度
$brightness = Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightness | Select-Object -First 1
$brightness.CurrentBrightness
```

## WmiMonitorBrightnessMethods 类

用于设置显示器亮度。

### 命名空间
```
root/wmi
```

### 方法

#### WmiSetBrightness

```csharp
uint32 WmiSetBrightness(
    uint32 Timeout,
    uint8 Brightness
);
```

**参数：**
- `Timeout`: 超时时间（秒）
- `Brightness`: 目标亮度值 (0-100)

### PowerShell 设置亮度

```powershell
# 设置亮度到 60%
$monitor = Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods
$monitor.WmiSetBrightness(1, 60)

# 使用 CIM cmdlet (PowerShell 7+)
$cim = Get-CimInstance -Namespace root/wmi -ClassName WmiMonitorBrightnessMethods
Invoke-CimMethod -InputObject $cim -MethodName WmiSetBrightness -Arguments @{Timeout = 1; Brightness = 60}
```

## 完整 PowerShell 函数

```powershell
function Set-ScreenBrightness {
    param([Parameter(Mandatory=$true)]
          [ValidateRange(0,100)]
          [int]$Level)
    
    try {
        $monitor = Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods -ErrorAction Stop
        $monitor.WmiSetBrightness(1, $Level)
        Write-Host "亮度已设置为 $Level%" -ForegroundColor Green
    }
    catch {
        Write-Error "设置亮度失败: $_"
        Write-Host "提示: 此功能需要显示器支持 DDC/CI 协议" -ForegroundColor Yellow
    }
}

function Get-ScreenBrightness {
    try {
        $brightness = Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightness | Select-Object -First 1
        if ($brightness) {
            $brightness.CurrentBrightness
        } else {
            Write-Error "无法获取亮度信息"
        }
    }
    catch {
        Write-Error "查询失败: $_"
    }
}

# 使用示例
Set-ScreenBrightness -Level 60
Get-ScreenBrightness
```

## 注意事项

1. **硬件要求**: 显示器必须支持 DDC/CI (Display Data Channel / Command Interface) 协议
2. **驱动程序**: 需要安装正确的显卡驱动程序
3. **兼容性**: 部分笔记本电脑和外接显示器可能不支持此功能
4. **权限**: 通常不需要管理员权限，但某些系统配置可能需要

## 替代方案

如果 WMI 方法不可用，可以尝试以下替代方案：

### 使用第三方工具

```powershell
# 使用 NirCmd (需先下载)
nircmd.exe setbrightness 60

# 使用 Monitorian (Microsoft Store 应用)
# 通过命令行调用
```

### 使用 API 调用（需要显示器支持）

```powershell
Add-Type @"
using System;
using System.Runtime.InteropServices;
public class Monitor {
    [DllImport("dxva2.dll", SetLastError = true)]
    public static extern bool SetMonitorBrightness(IntPtr hMonitor, uint dwNewBrightness);
    
    [DllImport("dxva2.dll", SetLastError = true)]
    public static extern bool GetMonitorBrightness(IntPtr hMonitor, out uint pdwMinimumBrightness, out uint pdwCurrentBrightness, out uint pdwMaximumBrightness);
}
"@
# 注意: 这需要先用 EnumDisplayMonitors 获取显示器句柄
```
