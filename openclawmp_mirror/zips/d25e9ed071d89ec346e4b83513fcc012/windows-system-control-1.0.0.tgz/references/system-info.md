# Windows 系统信息 WMI 类

## Win32_OperatingSystem

操作系统信息。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Caption` | string | 操作系统名称 |
| `Version` | string | 操作系统版本 |
| `OSArchitecture` | string | 操作系统架构 (32/64位) |
| `InstallDate` | datetime | 安装日期 |
| `LastBootUpTime` | datetime | 上次启动时间 |
| `TotalVisibleMemorySize` | uint64 | 总物理内存 (KB) |
| `FreePhysicalMemory` | uint64 | 可用物理内存 (KB) |
| `TotalVirtualMemorySize` | uint64 | 总虚拟内存 (KB) |
| `FreeVirtualMemory` | uint64 | 可用虚拟内存 (KB) |

### PowerShell 查询

```powershell
Get-CimInstance Win32_OperatingSystem | Select-Object Caption, Version, OSArchitecture, TotalVisibleMemorySize
```

## Win32_ComputerSystem

计算机系统信息。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Name` | string | 计算机名 |
| `Manufacturer` | string | 制造商 |
| `Model` | string | 型号 |
| `SystemType` | string | 系统类型 |
| `TotalPhysicalMemory` | uint64 | 总物理内存 (字节) |
| `NumberOfProcessors` | uint16 | 处理器数量 |
| `NumberOfLogicalProcessors` | uint16 | 逻辑处理器数量 |

### PowerShell 查询

```powershell
Get-CimInstance Win32_ComputerSystem | Select-Object Name, Manufacturer, Model, TotalPhysicalMemory
```

## Win32_Processor

处理器信息。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Name` | string | 处理器名称 |
| `Manufacturer` | string | 制造商 |
| `NumberOfCores` | uint16 | 核心数 |
| `NumberOfLogicalProcessors` | uint16 | 逻辑处理器数 |
| `MaxClockSpeed` | uint32 | 最大频率 (MHz) |
| `CurrentClockSpeed` | uint32 | 当前频率 (MHz) |
| `LoadPercentage` | uint16 | 当前负载 (%) |

### PowerShell 查询

```powershell
Get-CimInstance Win32_Processor | Select-Object Name, NumberOfCores, MaxClockSpeed, LoadPercentage
```

## Win32_PhysicalMemory

物理内存信息。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Capacity` | uint64 | 容量 (字节) |
| `Speed` | uint32 | 速度 (MHz) |
| `Manufacturer` | string | 制造商 |
| `PartNumber` | string | 部件号 |

### PowerShell 查询

```powershell
Get-CimInstance Win32_PhysicalMemory | Select-Object Manufacturer, Capacity, Speed | Format-Table -AutoSize

# 计算总内存
$totalMem = (Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum).Sum / 1GB
Write-Host "总内存: $([math]::Round($totalMem, 2)) GB"
```

## Win32_LogicalDisk

逻辑磁盘信息。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `DeviceID` | string | 盘符 |
| `Size` | uint64 | 总大小 (字节) |
| `FreeSpace` | uint64 | 可用空间 (字节) |
| `DriveType` | uint32 | 驱动器类型 (3=本地磁盘) |
| `FileSystem` | string | 文件系统 |

### PowerShell 查询

```powershell
Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | Select-Object DeviceID, Size, FreeSpace, FileSystem

# 格式化为可读格式
Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
    $size = [math]::Round($_.Size / 1GB, 2)
    $free = [math]::Round($_.FreeSpace / 1GB, 2)
    $used = [math]::Round(($_.Size - $_.FreeSpace) / 1GB, 2)
    $percentUsed = [math]::Round((($_.Size - $_.FreeSpace) / $_.Size) * 100, 1)
    
    [PSCustomObject]@{
        Drive = $_.DeviceID
        Total = "$size GB"
        Used = "$used GB ($percentUsed%)"
        Free = "$free GB"
    }
}
```

## Win32_VideoController

显卡信息。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Name` | string | 显卡名称 |
| `AdapterRAM` | uint32 | 显存大小 (字节) |
| `VideoModeDescription` | string | 当前分辨率 |
| `CurrentRefreshRate` | uint32 | 当前刷新率 |
| `MaxRefreshRate` | uint32 | 最大刷新率 |
| `VideoProcessor` | string | 视频处理器 |

### PowerShell 查询

```powershell
Get-CimInstance Win32_VideoController | Select-Object Name, AdapterRAM, VideoModeDescription, CurrentRefreshRate

# 获取显存为 GB
Get-CimInstance Win32_VideoController | ForEach-Object {
    $vram = [math]::Round($_.AdapterRAM / 1GB, 2)
    [PSCustomObject]@{
        Name = $_.Name
        VRAM = "$vram GB"
        Resolution = $_.VideoModeDescription
        RefreshRate = "$($_.CurrentRefreshRate) Hz"
    }
}
```

## Win32_Battery

电池信息（笔记本电脑）。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Name` | string | 电池名称 |
| `EstimatedChargeRemaining` | uint16 | 剩余电量 (%) |
| `EstimatedRunTime` | uint32 | 预计运行时间 (分钟) |
| `BatteryStatus` | uint16 | 电池状态 |

### PowerShell 查询

```powershell
Get-CimInstance Win32_Battery | Select-Object Name, EstimatedChargeRemaining, BatteryStatus
```

## Win32_NetworkAdapter

网络适配器信息。

### 常用属性

| 属性 | 类型 | 说明 |
|------|------|------|
| `Name` | string | 适配器名称 |
| `NetConnectionStatus` | uint16 | 连接状态 |
| `MACAddress` | string | MAC 地址 |
| `Speed` | uint64 | 速度 (bps) |

### PowerShell 查询

```powershell
Get-CimInstance Win32_NetworkAdapter | Where-Object {$_.NetConnectionStatus -ne $null} | 
    Select-Object Name, NetConnectionStatus, MACAddress, Speed

# 连接状态映射
# 2 = Connected, 7 = Media disconnected
```

## 完整系统信息脚本

```powershell
function Get-FullSystemInfo {
    Write-Host "`n========== 系统信息 ==========" -ForegroundColor Cyan
    
    # 操作系统
    $os = Get-CimInstance Win32_OperatingSystem
    Write-Host "操作系统: $($os.Caption) $($os.Version)" -ForegroundColor White
    Write-Host "架构: $($os.OSArchitecture)" -ForegroundColor White
    Write-Host "安装日期: $($os.InstallDate)" -ForegroundColor White
    
    # 计算机信息
    $comp = Get-CimInstance Win32_ComputerSystem
    Write-Host "`n计算机名: $($comp.Name)" -ForegroundColor White
    Write-Host "制造商: $($comp.Manufacturer)" -ForegroundColor White
    Write-Host "型号: $($comp.Model)" -ForegroundColor White
    
    # CPU
    $cpu = Get-CimInstance Win32_Processor
    Write-Host "`nCPU: $($cpu.Name)" -ForegroundColor White
    Write-Host "核心数: $($cpu.NumberOfCores)" -ForegroundColor White
    Write-Host "逻辑处理器: $($cpu.NumberOfLogicalProcessors)" -ForegroundColor White
    Write-Host "频率: $($cpu.MaxClockSpeed) MHz" -ForegroundColor White
    
    # 内存
    $mem = Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum
    $totalMem = [math]::Round($mem.Sum / 1GB, 2)
    Write-Host "`n总内存: $totalMem GB" -ForegroundColor White
    
    # 磁盘
    Write-Host "`n磁盘信息:" -ForegroundColor White
    Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
        $total = [math]::Round($_.Size / 1GB, 2)
        $free = [math]::Round($_.FreeSpace / 1GB, 2)
        $used = $total - $free
        [int]$percentFree = ($_.FreeSpace / $_.Size) * 100
        Write-Host "  $($_.DeviceID) - 已用: $used GB / $total GB (可用: $free GB, $percentFree%)" -ForegroundColor Gray
    }
    
    # 显卡
    $gpu = Get-CimInstance Win32_VideoController
    Write-Host "`n显卡:" -ForegroundColor White
    $gpu | ForEach-Object {
        $vram = [math]::Round($_.AdapterRAM / 1GB, 2)
        Write-Host "  $($_.Name) - 显存: $vram GB, 分辨率: $($_.VideoModeDescription)" -ForegroundColor Gray
    }
    
    Write-Host "`n==============================`n" -ForegroundColor Cyan
}

Get-FullSystemInfo
```
