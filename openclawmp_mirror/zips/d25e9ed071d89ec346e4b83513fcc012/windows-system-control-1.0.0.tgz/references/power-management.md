# Windows 电源管理 API 参考

## user32.dll API

### LockWorkStation

锁定工作站（锁屏）。

```csharp
[DllImport("user32.dll")]
public static extern void LockWorkStation();
```

**PowerShell 实现：**
```powershell
Add-Type -MemberDefinition @"
[DllImport("user32.dll")]
public static extern void LockWorkStation();
"@ -Name Win32 -Namespace Native
[Native.Win32]::LockWorkStation()
```

### SystemParametersInfo

设置系统参数，包括桌面壁纸。

```csharp
[DllImport("user32.dll", CharSet=CharSet.Auto)]
public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
```

**常量：**
- `SPI_SETDESKWALLPAPER = 20` - 设置桌面壁纸
- `SPIF_UPDATEINIFILE = 0x01` - 更新 INI 文件
- `SPIF_SENDCHANGE = 0x02` - 发送 WM_SETTINGCHANGE 消息

**PowerShell 实现：**
```powershell
Add-Type -MemberDefinition @"
[DllImport("user32.dll", CharSet=CharSet.Auto)]
public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
public static void SetWallpaper(string path) {
    SystemParametersInfo(20, 0, path, 0x01 | 0x02);
}
"@ -Name Wallpaper -Namespace Win32
[Win32.Wallpaper]::SetWallpaper("C:\\Path\\To\\Wallpaper.jpg")
```

### ExitWindowsEx

关机或重启系统。

```csharp
[DllImport("user32.dll")]
public static extern int ExitWindowsEx(int uFlags, int dwReason);
```

**常量：**
| 常量 | 值 | 说明 |
|------|----|----|
| EWX_LOGOFF | 0x00000000 | 注销 |
| EWX_SHUTDOWN | 0x00000001 | 关机 |
| EWX_REBOOT | 0x00000002 | 重启 |
| EWX_FORCE | 0x00000004 | 强制关闭应用程序 |
| EWX_POWEROFF | 0x00000008 | 关闭电源 |

**PowerShell 实现：**
```powershell
Add-Type -MemberDefinition @"
[DllImport("user32.dll")]
public static extern int ExitWindowsEx(int uFlags, int dwReason);
"@ -Name Win32 -Namespace Native

# 关机
[Native.Win32]::ExitWindowsEx(0x01 -bor 0x04, 0)

# 重启
[Native.Win32]::ExitWindowsEx(0x02 -bor 0x04, 0)

# 注销
[Native.Win32]::ExitWindowsEx(0x00 -bor 0x04, 0)
```

## powrprof.dll API

### SetSuspendState

设置系统挂起状态（睡眠/休眠）。

```csharp
[DllImport("powrprof.dll")]
public static extern bool SetSuspendState(bool hibernate, bool forceCritical, bool disableWakeEvent);
```

**参数：**
- `hibernate`: `true` 为休眠, `false` 为睡眠
- `forceCritical`: `true` 强制关闭应用程序
- `disableWakeEvent`: `true` 禁用唤醒事件

**PowerShell 实现：**
```powershell
Add-Type -MemberDefinition @"
[DllImport("powrprof.dll")]
public static extern bool SetSuspendState(bool hibernate, bool forceCritical, bool disableWakeEvent);
"@ -Name Power -Namespace Native

# 睡眠
[Native.Power]::SetSuspendState($false, $true, $false)

# 休眠
[Native.Power]::SetSuspendState($true, $true, $false)
```

### SetThreadExecutionState

防止系统进入睡眠状态。

```csharp
[DllImport("kernel32.dll")]
public static extern int SetThreadExecutionState(int esFlags);
```

**常量：**
| 常量 | 值 | 说明 |
|------|----|----|
| ES_AWAYMODE_REQUIRED | 0x00000040 | 离开模式 |
| ES_CONTINUOUS | 0x80000000 | 持续状态 |
| ES_DISPLAY_REQUIRED | 0x00000002 | 防止显示器关闭 |
| ES_SYSTEM_REQUIRED | 0x00000001 | 防止系统睡眠 |

**PowerShell 实现：**
```powershell
Add-Type -MemberDefinition @"
[DllImport("kernel32.dll")]
public static extern int SetThreadExecutionState(int esFlags);
"@ -Name Kernel32 -Namespace Native

# 防止系统睡眠和显示器关闭
[Native.Kernel32]::SetThreadExecutionState(0x80000000 -bor 0x00000001 -bor 0x00000002)

# 恢复默认
[Native.Kernel32]::SetThreadExecutionState(0x80000000)
```

## powercfg 命令

### 查看电源计划

```powershell
powercfg /list
```

### 设置电源计划

```powershell
# 高性能模式
powercfg /setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c

# 平衡模式
powercfg /setactive 381b4222-f694-41f0-9685-ff5bb260df2e

# 节能模式
powercfg /setactive a1841308-3541-4fab-bc81-f71556f20b4a
```

### 修改电源设置

```powershell
# 设置显示器关闭时间（使用电池，分钟）
powercfg /change monitor-timeout-dc 5

# 设置显示器关闭时间（接通电源，分钟）
powercfg /change monitor-timeout-ac 10

# 设置睡眠时间（使用电池，分钟）
powercfg /change standby-timeout-dc 15

# 设置睡眠时间（接通电源，分钟）
powercfg /change standby-timeout-ac 30
```

## 注意事项

1. **管理员权限**: 部分电源操作需要管理员权限
2. **关机/重启**: 强制关闭可能导致数据丢失
3. **睡眠/休眠**: 确保系统已启用休眠功能（`powercfg /hibernate on`）
4. **锁屏**: 需要用户登录会话才能正常工作
