---
name: windows-system-control
description: Windows 系统设置全面控制技能。使用 Windows Core Audio API 精确控制音量（1%步进）、静音状态；使用 WMI 控制屏幕亮度；使用 Win32 API 控制电源（锁屏、睡眠、休眠、关机、重启）、桌面壁纸；使用 PowerShell 国际化模块控制输入语言和显示语言。提供高精度设置和状态查询能力。
---

# Windows 系统控制技能

使用 Windows 原生 API 精确控制系统设置。

## 功能列表

### 🎵 音频控制 (Core Audio API)
- **精度**: 1% 步进
- **音量设置**: `Volume` - 设置音量 0-100%
- **静音控制**: `Mute` / `Unmute`
- **状态查询**: 集成在 SystemInfo 中

### 🔆 显示器控制 (WMI)
- **亮度设置**: `Brightness` - 设置屏幕亮度 0-100%
- **依赖**: 需要显示器支持 DDC/CI 协议

### 🖥️ 壁纸设置 (Win32 API)
- **设置壁纸**: `Wallpaper` - 设置桌面背景图片

### 🔒 电源管理 (Win32 API)
- **锁屏**: `Lock`
- **睡眠**: `Sleep`
- **休眠**: `Hibernate`
- **关机**: `Shutdown`
- **重启**: `Reboot`

### 🌐 语言控制 (PowerShell 国际化)
- **查看语言**: `Language` - 显示当前输入语言列表
- **切换输入**: `Input` - 切换到指定输入语言
- **设置语言**: `Lang` - 设置用户显示语言（需重新登录）

### ℹ️ 系统信息 (WMI)
- **查询信息**: `SystemInfo` - 显示系统详细信息

## 使用方式

```powershell
.\system-control.ps1 -Action <Action> [-Value <Value>] [-Path <Path>] [-Lang <Code>] [-InputCode <Code>]
```

## 示例

### 音频控制
```powershell
.\system-control.ps1 -Action Volume -Value 35    # 设置音量 35%
.\system-control.ps1 -Action Mute                 # 静音
.\system-control.ps1 -Action Unmute               # 取消静音
```

### 显示器控制
```powershell
.\system-control.ps1 -Action Brightness -Value 80  # 设置亮度 80%
```

### 电源管理
```powershell
.\system-control.ps1 -Action Lock       # 锁屏
.\system-control.ps1 -Action Sleep      # 睡眠
.\system-control.ps1 -Action Hibernate  # 休眠
.\system-control.ps1 -Action Shutdown   # 关机
.\system-control.ps1 -Action Reboot     # 重启
```

### 壁纸设置
```powershell
.\system-control.ps1 -Action Wallpaper -Path "C:\Path\To\Image.jpg"
```

### 语言控制
```powershell
.\system-control.ps1 -Action Language              # 查看语言列表
.\system-control.ps1 -Action Input -InputCode "en-US"  # 切换到英语
.\system-control.ps1 -Action Language -Lang "zh-CN"     # 设置显示语言为中文
```

### 系统信息
```powershell
.\system-control.ps1 -Action SystemInfo
```

## 语言代码参考

| 代码 | 语言 |
|------|------|
| `zh-CN` | 中文(简体) |
| `zh-TW` | 中文(繁体) |
| `en-US` | 英语(美国) |
| `en-GB` | 英语(英国) |
| `ja-JP` | 日语 |
| `ko-KR` | 韩语 |
| `de-DE` | 德语 |
| `fr-FR` | 法语 |
| `es-ES` | 西班牙语 |
| `ru-RU` | 俄语 |
| `it-IT` | 意大利语 |
| `pt-BR` | 葡萄牙语 |

## 技术实现

### Core Audio API
```csharp
// IAudioEndpointVolume 接口 (完整 vtable，必须按顺序声明所有方法)
// 注意：必须包含 RegisterControlChangeNotify、UnregisterControlChangeNotify、
// GetChannelCount、SetMasterVolumeLevel 等前置方法，否则 COM vtable 偏移错误
// IMMDevice.Activate 的 clsCtx 参数必须为 1 (CLSCTX_INPROC_SERVER)
RegisterControlChangeNotify(pNotify)
UnregisterControlChangeNotify(pNotify)
GetChannelCount(out pnChannelCount)
SetMasterVolumeLevel(fLevelDB, eventContext)
SetMasterVolumeLevelScalar(level, eventContext)  // 0.0 - 1.0
GetMasterVolumeLevel(out fLevelDB)
GetMasterVolumeLevelScalar(out level)
SetChannelVolumeLevel(nChannel, fLevelDB, eventContext)
SetChannelVolumeLevelScalar(nChannel, fLevel, eventContext)
GetChannelVolumeLevel(nChannel, out fLevelDB)
GetChannelVolumeLevelScalar(nChannel, out fLevel)
SetMute(mute, eventContext)
GetMute(out mute)
```

### WMI 显示器控制
```powershell
Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods
WmiSetBrightness(timeout, brightness)  // 0 - 100
```

### Win32 API 电源管理
```csharp
LockWorkStation()
SetSuspendState(hibernate, force, disableWake)
ExitWindowsEx(flags, reason)
SystemParametersInfo(SPI_SETDESKWALLPAPER, ...)
```

### PowerShell 语言控制
```powershell
Get-WinUserLanguageList
Set-WinUserLanguageList -LanguageList <code> -Force
```

## 降级策略

如果 Core Audio API 加载失败，自动回退到 `WScript.Shell.SendKeys` 键盘模拟。

## 备用脚本

- `fix-volume.ps1` - 独立的音量/静音控制脚本，使用完整 IAudioEndpointVolume 接口
  ```powershell
  .\fix-volume.ps1 -TargetVolume 60           # 设置音量 60%
  .\fix-volume.ps1 -MuteAction unmute         # 取消静音
  .\fix-volume.ps1 -MuteAction mute           # 静音
  .\fix-volume.ps1 -MuteAction unmute -TargetVolume 60  # 取消静音并设置音量
  ```

## 变更日志

### v4.2 (2026-03-16) - Core Audio API 修复
- **修复**: `IAudioEndpointVolume` COM 接口声明补全完整 vtable（添加 RegisterControlChangeNotify、UnregisterControlChangeNotify、GetChannelCount、SetMasterVolumeLevel 等前置方法），解决因 vtable 偏移导致的 `AccessViolationException` 错误
- **修复**: `IMMDevice.Activate` 的 `clsCtx` 参数从 `0` 改为 `1` (CLSCTX_INPROC_SERVER)
- **新增**: `fix-volume.ps1` 备用脚本，支持 `-MuteAction` 参数控制静音状态

## 参考文档

- `audio-api.md` - Core Audio API 详细文档
- `display-api.md` - WMI 显示器控制
- `power-management.md` - Win32 电源管理 API
- `system-info.md` - WMI 系统信息查询
