param(
    [int]$TargetVolume = -1,
    [string]$MuteAction = ""
)

$code = @"
using System;
using System.Runtime.InteropServices;

namespace FixAudio {
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    public class MMDeviceEnumerator { }

    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMMDeviceEnumerator {
        int NotImpl1();
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
    }

    [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMMDevice {
        int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
    }

    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IAudioEndpointVolume {
        int RegisterControlChangeNotify(IntPtr pNotify);
        int UnregisterControlChangeNotify(IntPtr pNotify);
        int GetChannelCount(out uint pnChannelCount);
        int SetMasterVolumeLevel(float fLevelDB, ref Guid pguidEventContext);
        int SetMasterVolumeLevelScalar(float fLevel, ref Guid pguidEventContext);
        int GetMasterVolumeLevel(out float pfLevelDB);
        int GetMasterVolumeLevelScalar(out float pfLevel);
        int SetChannelVolumeLevel(uint nChannel, float fLevelDB, ref Guid pguidEventContext);
        int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, ref Guid pguidEventContext);
        int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
        int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, ref Guid pguidEventContext);
        int GetMute([MarshalAs(UnmanagedType.Bool)] out bool pbMute);
    }

    public static class VolumeHelper {
        public static IAudioEndpointVolume GetEndpointVolume() {
            var enumerator = new MMDeviceEnumerator() as IMMDeviceEnumerator;
            IMMDevice device;
            Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(0, 1, out device));
            object volumeObj;
            var iid = typeof(IAudioEndpointVolume).GUID;
            Marshal.ThrowExceptionForHR(device.Activate(ref iid, 1, IntPtr.Zero, out volumeObj));
            return volumeObj as IAudioEndpointVolume;
        }

        public static float GetVolume() {
            var vol = GetEndpointVolume();
            float level;
            Marshal.ThrowExceptionForHR(vol.GetMasterVolumeLevelScalar(out level));
            return level * 100f;
        }

        public static void SetVolume(float percent) {
            var vol = GetEndpointVolume();
            float normalized = Math.Max(0f, Math.Min(1f, percent / 100f));
            Guid ctx = Guid.Empty;
            Marshal.ThrowExceptionForHR(vol.SetMasterVolumeLevelScalar(normalized, ref ctx));
        }

        public static bool GetMute() {
            var vol = GetEndpointVolume();
            bool muted;
            Marshal.ThrowExceptionForHR(vol.GetMute(out muted));
            return muted;
        }

        public static void SetMute(bool mute) {
            var vol = GetEndpointVolume();
            Guid ctx = Guid.Empty;
            Marshal.ThrowExceptionForHR(vol.SetMute(mute, ref ctx));
        }
    }
}
"@

try {
    Add-Type -TypeDefinition $code -ErrorAction Stop

    # Handle mute/unmute
    if ($MuteAction -eq "unmute") {
        $isMuted = [FixAudio.VolumeHelper]::GetMute()
        Write-Host "Current mute state: $isMuted"
        [FixAudio.VolumeHelper]::SetMute($false)
        $newMute = [FixAudio.VolumeHelper]::GetMute()
        Write-Host "Mute state now: $newMute"
    } elseif ($MuteAction -eq "mute") {
        [FixAudio.VolumeHelper]::SetMute($true)
        Write-Host "Muted"
    }

    # Handle volume
    if ($TargetVolume -ge 0) {
        $current = [FixAudio.VolumeHelper]::GetVolume()
        Write-Host "Current volume: $([math]::Round($current))%"
        [FixAudio.VolumeHelper]::SetVolume($TargetVolume)
        $newVol = [FixAudio.VolumeHelper]::GetVolume()
        Write-Host "Volume set to: $([math]::Round($newVol))%"
    }
} catch {
    Write-Host "Error: $_"
}
