param([int]$TargetVolume = 60)

# Use SndVol / nircmd approach or SendKeys fallback
# First try using PowerShell 5's built-in COM approach

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

[Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IAudioEndpointVolume2 {
    int RegisterControlChangeNotify(IntPtr pNotify);
    int UnregisterControlChangeNotify(IntPtr pNotify);
    int GetChannelCount(out uint pnChannelCount);
    int SetMasterVolumeLevel(float fLevelDB, ref Guid pguidEventContext);
    int SetMasterVolumeLevelScalar(float fLevel, ref Guid pguidEventContext);
    int GetMasterVolumeLevel(out float pfLevelDB);
    int GetMasterVolumeLevelScalar(out float pfLevel);
    int SetChannelVolumeLevel(uint nChannel, float fLevelDB, ref Guid pguidEventContext);
    int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, ref Guid pguidEventContext);
    int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
    int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
    int SetMute([MarshalAs(UnmanagedType.Bool)] bool bMute, ref Guid pguidEventContext);
    int GetMute([MarshalAs(UnmanagedType.Bool)] out bool pbMute);
    int GetVolumeStepInfo(out uint pnStep, out uint pnStepCount);
    int VolumeStepUp(ref Guid pguidEventContext);
    int VolumeStepDown(ref Guid pguidEventContext);
    int QueryHardwareSupport(out uint pdwHardwareSupportMask);
    int GetVolumeRange(out float pflVolumeMindB, out float pflVolumeMaxdB, out float pflVolumeIncrementdB);
}

public static class AudioHelper2 {
    [DllImport("ole32.dll")]
    static extern int CoCreateInstance(ref Guid clsid, IntPtr pUnkOuter, uint dwClsContext, ref Guid riid, out IntPtr ppv);

    // IMMDeviceEnumerator
    static readonly Guid CLSID_MMDeviceEnumerator = new Guid("BCDE0395-E52F-467C-8E3D-C4579291692E");
    static readonly Guid IID_IMMDeviceEnumerator = new Guid("A95664D2-9614-4F35-A746-DE8DB63617E6");
    static readonly Guid IID_IAudioEndpointVolume = new Guid("5CDF2C82-841E-4546-9722-0CF74078229A");

    [DllImport("ole32.dll")]
    static extern int CoInitializeEx(IntPtr pvReserved, uint dwCoInit);

    public static void SetVolume(float level) {
        // Use SendKeys approach as fallback
        throw new NotImplementedException("Use managed approach");
    }
}
"@ -ErrorAction SilentlyContinue

# Fallback: Use WScript.Shell SendKeys to control volume
# First mute/unmute to ensure known state, then set volume
$wsh = New-Object -ComObject WScript.Shell

# Press volume down 50 times to reach 0
for ($i = 0; $i -lt 50; $i++) { 
    $wsh.SendKeys([char]174)  # Volume Down
}
Start-Sleep -Milliseconds 300

# Now press volume up to reach target (each press = 2%)
$pressCount = [math]::Round($TargetVolume / 2)
for ($i = 0; $i -lt $pressCount; $i++) { 
    $wsh.SendKeys([char]175)  # Volume Up
}
Start-Sleep -Milliseconds 200

Write-Host "Volume set to approximately ${TargetVolume}%"
