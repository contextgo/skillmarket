# Windows System Control Script
# Version: 4.1 - Language and Input switching support

param(
    [Parameter(Mandatory=$true)]
    [ValidateSet("Volume", "Mute", "Unmute", "Brightness", "Wallpaper", 
                "Lock", "Sleep", "Hibernate", "Shutdown", "Reboot",
                "SystemInfo", "Language", "Input")]
    [string]$Action,
    
    [Parameter()]
    [int]$Value = -1,
    
    [Parameter()]
    [string]$Path = "",
    
    [Parameter()]
    [string]$Lang = "",
    
    [Parameter()]
    [string]$InputCode = ""
)

# ============================================
# Core Audio API
# ============================================
$CoreAudioCode = @"
using System;
using System.Runtime.InteropServices;

namespace CoreAudio {
    [ComImport, Guid("BCDE0395-E52F-467C-8E3D-C4579291692E")]
    public class MMDeviceEnumerator { }

    [Guid("A95664D2-9614-4F35-A746-DE8DB63617E6"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMMDeviceEnumerator {
        int EnumAudioEndpoints(int dataFlow, int stateMask, out IntPtr devices);
        int GetDefaultAudioEndpoint(int dataFlow, int role, out IMMDevice endpoint);
    }

    [Guid("D666063F-1587-4E43-81F1-B948E807363F"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IMMDevice {
        int Activate(ref Guid iid, int clsCtx, IntPtr activationParams, [MarshalAs(UnmanagedType.IUnknown)] out object ppInterface);
    }

    [Guid("5CDF2C82-841E-4546-9722-0CF74078229A"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    public interface IAudioEndpointVolume {
        int RegisterControlChangeNotify(IntPtr pNotify);
        int UnregisterControlChangeNotify(IntPtr pNotify);
        int GetChannelCount(out uint pnChannelCount);
        int SetMasterVolumeLevel(float fLevelDB, ref Guid pguidEventContext);
        int SetMasterVolumeLevelScalar(float level, ref Guid eventContext);
        int GetMasterVolumeLevel(out float pfLevelDB);
        int GetMasterVolumeLevelScalar(out float level);
        int SetChannelVolumeLevel(uint nChannel, float fLevelDB, ref Guid pguidEventContext);
        int SetChannelVolumeLevelScalar(uint nChannel, float fLevel, ref Guid pguidEventContext);
        int GetChannelVolumeLevel(uint nChannel, out float pfLevelDB);
        int GetChannelVolumeLevelScalar(uint nChannel, out float pfLevel);
        int SetMute([MarshalAs(UnmanagedType.Bool)] bool mute, ref Guid eventContext);
        int GetMute([MarshalAs(UnmanagedType.Bool)] out bool mute);
    }

    public static class VolumeController {
        private static IAudioEndpointVolume GetVolumeControl() {
            var enumerator = new MMDeviceEnumerator() as IMMDeviceEnumerator;
            IMMDevice device = null;
            Marshal.ThrowExceptionForHR(enumerator.GetDefaultAudioEndpoint(0, 1, out device));
            object volumeObj = null;
            var volumeGuid = typeof(IAudioEndpointVolume).GUID;
            Marshal.ThrowExceptionForHR(device.Activate(ref volumeGuid, 1, IntPtr.Zero, out volumeObj));
            return volumeObj as IAudioEndpointVolume;
        }

        public static float GetVolume() {
            IAudioEndpointVolume vol = GetVolumeControl();
            float currentVolume = 0;
            Marshal.ThrowExceptionForHR(vol.GetMasterVolumeLevelScalar(out currentVolume));
            return currentVolume * 100;
        }

        public static void SetVolume(float percent) {
            IAudioEndpointVolume vol = GetVolumeControl();
            float normalizedLevel = Math.Max(0, Math.Min(100, percent)) / 100f;
            Guid eventContext = Guid.Empty;
            Marshal.ThrowExceptionForHR(vol.SetMasterVolumeLevelScalar(normalizedLevel, ref eventContext));
        }

        public static bool GetMute() {
            IAudioEndpointVolume vol = GetVolumeControl();
            bool isMuted = false;
            Marshal.ThrowExceptionForHR(vol.GetMute(out isMuted));
            return isMuted;
        }

        public static void SetMute(bool mute) {
            IAudioEndpointVolume vol = GetVolumeControl();
            Guid eventContext = Guid.Empty;
            Marshal.ThrowExceptionForHR(vol.SetMute(mute, ref eventContext));
        }
    }
}
"@

$CoreAudioAvailable = $false
try {
    Add-Type -TypeDefinition $CoreAudioCode -ReferencedAssemblies System.Core -ErrorAction Stop
    $CoreAudioAvailable = $true
}
catch {
    Write-Warning "Core Audio API not available"
}

# ============================================
# Volume Control
# ============================================
function Set-SystemVolume {
    param([int]$level)
    
    if ($CoreAudioAvailable) {
        try {
            $current = [CoreAudio.VolumeController]::GetVolume()
            Write-Host "Current: $([math]::Round($current, 1))% -> " -NoNewline -ForegroundColor Gray
            [CoreAudio.VolumeController]::SetVolume($level)
            $new = [CoreAudio.VolumeController]::GetVolume()
            Write-Host "$([math]::Round($new, 1))%" -ForegroundColor Green
            return
        }
        catch {
            Write-Warning "Core Audio failed"
        }
    }
    
    $wsh = New-Object -ComObject WScript.Shell
    for ($i = 0; $i -lt 50; $i++) { $wsh.SendKeys([char]174) }
    Start-Sleep -Milliseconds 200
    $pressCount = [math]::Round($level / 2)
    for ($i = 0; $i -lt $pressCount; $i++) { $wsh.SendKeys([char]175) }
    Write-Host "Volume ~$level%" -ForegroundColor Green
}

function Toggle-Mute {
    param([bool]$mute)
    
    if ($CoreAudioAvailable) {
        try {
            $currentMute = [CoreAudio.VolumeController]::GetMute()
            if ($currentMute -ne $mute) {
                [CoreAudio.VolumeController]::SetMute($mute)
            }
            Write-Host $(if ($mute) { "Muted" } else { "Unmuted" }) -ForegroundColor Green
            return
        }
        catch {
            Write-Warning "Core Audio failed"
        }
    }
    
    $wsh = New-Object -ComObject WScript.Shell
    $wsh.SendKeys([char]173)
    Write-Host "Mute toggled" -ForegroundColor Green
}

# ============================================
# Brightness Control
# ============================================
function Set-MonitorBrightness {
    param([int]$level)
    try {
        $monitor = Get-WmiObject -Namespace root/wmi -Class WmiMonitorBrightnessMethods -ErrorAction Stop
        $monitor.WmiSetBrightness(1, $level)
        Write-Host "Brightness set to $level%" -ForegroundColor Green
    }
    catch {
        Write-Error "Failed to set brightness"
    }
}

# ============================================
# Language Control
# ============================================
function Get-LanguageList {
    try {
        $langs = Get-WinUserLanguageList
        Write-Host "`n=== Input Languages ===" -ForegroundColor Cyan
        foreach ($lang in $langs) {
            $default = if ($lang.IsDefault) { " *" } else { "" }
            Write-Host "  $($lang.LanguageTag) | $($lang.DisplayName)$default" -ForegroundColor White
        }
        Write-Host ""
    }
    catch {
        Write-Error "Failed to get languages: $_"
    }
}

function Switch-InputLanguage {
    param([string]$code)
    
    if ($code) {
        try {
            Set-WinUserLanguageList -LanguageList $code -Force
            Write-Host "Switched to $code" -ForegroundColor Green
        }
        catch {
            Write-Error "Failed to switch: $_"
        }
    }
    else {
        Get-LanguageList
    }
}

function Set-UserLanguage {
    param([string]$languageCode)
    
    if ($languageCode -notmatch '^[a-z]{2}-[A-Z]{2}$') {
        Write-Error "Invalid code. Use: zh-CN, en-US, ja-JP, etc."
        return
    }
    
    $current = Get-WinUserLanguageList
    $exists = $current | Where-Object { $_.LanguageTag -eq $languageCode }
    
    if (-not $exists) {
        Write-Host "Adding $languageCode..." -ForegroundColor Yellow
    }
    
    try {
        Set-WinUserLanguageList -LanguageList $languageCode -Force
        Write-Host "Language set to $languageCode" -ForegroundColor Green
    }
    catch {
        Write-Error "Failed: $_"
    }
}

# ============================================
# Power Management
# ============================================
$PowerCode = @"
using System.Runtime.InteropServices;
public class PowerApi {
    [DllImport("user32.dll")] public static extern void LockWorkStation();
    [DllImport("user32.dll")] public static extern int ExitWindowsEx(int uFlags, int dwReason);
    [DllImport("powrprof.dll")] public static extern bool SetSuspendState(bool hibernate, bool force, bool disableWake);
    [DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern int SystemParametersInfo(int uAction, int uParam, string lpvParam, int fuWinIni);
}
"@
try { Add-Type -TypeDefinition $PowerCode -ReferencedAssemblies System.Core } catch {}

function Lock-WorkStation { [PowerApi]::LockWorkStation() }
function Suspend-System { param([bool]$hibernate) [PowerApi]::SetSuspendState($hibernate, $true, $false) }
function Stop-System { param([bool]$reboot) $flags = if ($reboot) { 6 } else { 5 }; [PowerApi]::ExitWindowsEx($flags, 0) }
function Set-Wallpaper { param([string]$path) [PowerApi]::SystemParametersInfo(20, 0, $path, 3) }

# ============================================
# System Info
# ============================================
function Get-SystemInfo {
    Write-Host "=== System Information ===" -ForegroundColor Cyan
    
    if ($CoreAudioAvailable) {
        $vol = [CoreAudio.VolumeController]::GetVolume()
        $mute = [CoreAudio.VolumeController]::GetMute()
        Write-Host "Volume: $([math]::Round($vol, 1))% | Muted: $mute" -ForegroundColor White
    }
    
    $os = Get-CimInstance Win32_OperatingSystem
    $comp = Get-CimInstance Win32_ComputerSystem
    $cpu = Get-CimInstance Win32_Processor
    $mem = Get-CimInstance Win32_PhysicalMemory | Measure-Object -Property Capacity -Sum
    
    Write-Host "OS: $($os.Caption) $($os.Version)" -ForegroundColor White
    Write-Host "Computer: $($comp.Name)" -ForegroundColor White
    Write-Host "CPU: $($cpu.Name)" -ForegroundColor White
    Write-Host "Memory: $([math]::Round($mem.Sum/1GB,2)) GB" -ForegroundColor White
    
    Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" | ForEach-Object {
        Write-Host "Disk $($_.DeviceID): $([math]::Round($_.FreeSpace/1GB,2))GB / $([math]::Round($_.Size/1GB,2))GB" -ForegroundColor White
    }
}

# ============================================
# Main
# ============================================
switch ($Action) {
    "Volume" { if ($Value -ge 0 -and $Value -le 100) { Set-SystemVolume -level $Value } }
    "Mute" { Toggle-Mute -mute $true }
    "Unmute" { Toggle-Mute -mute $false }
    "Brightness" { if ($Value -ge 0 -and $Value -le 100) { Set-MonitorBrightness -level $Value } }
    "Wallpaper" { if ($Path) { Set-Wallpaper -path $Path } }
    "Lock" { Lock-WorkStation; Write-Host "Locked" -ForegroundColor Green }
    "Sleep" { Suspend-System -hibernate $false }
    "Hibernate" { Suspend-System -hibernate $true }
    "Shutdown" { Stop-System -reboot $false }
    "Reboot" { Stop-System -reboot $true }
    "SystemInfo" { Get-SystemInfo }
    "Language" { 
        if ($Lang) { Set-UserLanguage -languageCode $Lang }
        else { Get-LanguageList }
    }
    "Input" { Switch-InputLanguage -code $InputCode }
}
