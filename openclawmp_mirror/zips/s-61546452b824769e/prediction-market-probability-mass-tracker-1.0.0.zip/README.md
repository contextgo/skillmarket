# Prediction Market Probability Mass Tracker

Tracks how probability mass migrates between price bands in prediction markets, detecting when the market is restructuring its probability distribution rather than reversing direction.

## When to Use

- Mid-range probabilities ($100-110 for Oil) drop while tail probabilities ($120+) rise
- Floor probabilities remain stable while peak probabilities shift
- Multiple price bands show synchronized movement in opposite directions

## Core Concept

Probability mass migration is when the market doesn't change its overall view but restructures how it prices different outcomes. This is NOT a directional reversal — it's a distribution shift.

**Example**: Oil at or above $100 drops 0.5%, Oil at or above $110 drops 0.65%, but Oil at or above $120 rises 1.0%. The market is still bullish on Oil but is becoming less certain about the exact ceiling while increasing tail risk expectations.

## Detection Algorithm

```python
def detect_mass_migration(bands):
    """
    bands: dict of {threshold: probability_change}
    Returns: MigrationEvent or None
    """
    mid_range_change = sum(bands[k] for k in bands if 90 <= k <= 110)
    tail_change = sum(bands[k] for k in bands if k > 120)
    
    if mid_range_change < -0.005 and tail_change > 0.005:
        return MigrationEvent(
            type="tail_risk_repricing",
            mass_shift=abs(mid_range_change) + tail_change,
            direction="mid_to_tail"
        )
    return None
```

## Key Signals

| Pattern | Interpretation | Action |
|---------|---------------|--------|
| Mid-range down, tail up | Re-pricing extreme outcomes | Add tail protection |
| Floor stable, mid-range diverging | Wide confidence band | Reduce concentrated mid positions |
| All bands same direction | Trend continuation | Follow the trend |
| Floor drops first | Early reversal warning | Reduce all positions |

## Integration with Polymarket

Monitor Gamma API for multi-strike markets (Oil, BTC) with different time horizons. Calculate net probability mass shift per round.

**Thresholds**:
- 0.5%+ simultaneous mid-range change = monitor
- 1.0%+ mass shift = action signal
- 2.0%+ = regime change alert

## Practical Application

During Oil monitoring round 52, the tracker detected the first mass migration in 51 rounds:
- $100: -0.5%, $110: -0.65% (mid-range loss: 1.15%)
- $120: +1.0% (tail gain: 1.0%)
- $90: 0% (floor unchanged)

This indicates: Oil stays elevated but the market is restructuring its ceiling expectations.