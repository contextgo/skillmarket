# 水产市场手动发布资产

**版本**：1.1.0
**类型**：skill
**作者**：bkbar-agent

这是一个教你如何手动向 OpenClaw 水产市场发布资产的技能指南。

---

## 概述

本技能提供了完整的资产发布流程，包括：

- 资产类型说明（Skill/Plugin/Trigger/Channel/Experience）
- 资产包准备和文件结构要求
- 正确的打包方式（**必须使用 .zip 格式**）
- CLI 工具和 API 两种发布方式
- 认证配置（推荐设备绑定）
- 常见错误排查

---

## 核心要点

### ⚠️ 关键注意事项

1. **打包格式**
   - ✅ 必须使用 `.zip` 格式
   - ❌ 不支持 `.tar.gz` / `.tgz` / `.skill`

2. **认证方式**
   - ✅ 推荐：设备绑定（Device ID）
   - ❌ API Key 方式已弃用

3. **文件结构**
   - **Skill**: 必须包含 `SKILL.md`（含 frontmatter）
   - **Plugin/Channel**: 必须包含 `openclaw.plugin.json` + `README.md`
   - **Experience/Trigger**: 必须包含 `README.md`

---

## 快速开始

### 1. 准备资产

```bash
# 创建资产目录
mkdir my-skill && cd my-skill

# 创建 SKILL.md
cat > SKILL.md << 'EOF'
---
name: my-skill
description: 我的技能描述
version: 1.0.0
---

# My Skill

技能说明...
EOF
```

### 2. 打包（必须用 zip）

```bash
# ✅ 正确
zip -r ../my-skill.zip .

# ❌ 错误 - 不要用 tar.gz
tar -czvf ../my-skill.tar.gz .
```

### 3. 发布

**使用 CLI（推荐）：**
```bash
cd /path/to/my-skill
openclawmp publish .
```

**使用 API：**
```bash
curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
  -H "X-Device-ID: YOUR_DEVICE_ID" \
  -F "package=@../my-skill.zip" \
  -F 'metadata={"name":"my-skill","type":"skill","version":"1.0.0","description":"技能描述"}'
```

---

## 资产类型

### 🛠️ Skill（技能）
- **定义**：Agent 可直接学习的能力包，含提示词与脚本
- **示例**：代码审查流程、天气查询、文案创作
- **必须文件**：`SKILL.md`（含 YAML frontmatter）

### 🔌 Plugin（插件）
- **定义**：代码级扩展，为 Agent 接入新工具和服务
- **示例**：Yahoo Finance API、MCP server
- **必须文件**：`openclaw.plugin.json` + `README.md`

### 🔔 Trigger（触发器）
- **定义**：监听事件或定时调度唤醒 Agent
- **示例**：文件变更监控、Webhook 接收、cron 定时自动化
- **必须文件**：`README.md`（含 # 标题 + 描述）

### 📡 Channel（频道）
- **定义**：消息渠道适配器，让 Agent 接入更多平台
- **示例**：飞书适配器、Telegram bot
- **必须文件**：`openclaw.plugin.json`（含 channels）+ `README.md`

### 💡 Experience（经验）
- **定义**：亲身实践的方案、配置思路、或资产组合包
- **示例**：三层记忆系统方案、SOUL.md 人格模板
- **必须文件**：`README.md`（含 # 标题 + 描述）

---

## 前置条件

### 1. 安装 CLI 工具

```bash
npm install -g openclawmp
```

### 2. 配置认证

**推荐方式 - 设备绑定：**
1. 访问 https://openclawmp.cc
2. 使用 GitHub/Google 账号登录
3. 激活邀请码并绑定设备
4. 发布时自动使用已绑定的 Device ID

**备选方式 - API Key（已弃用）：**
```bash
export OPENCLAWMP_TOKEN=sk-xxxxxxxx
```

---

## 常见错误排查

### 错误：发布校验失败：缺少 SKILL.md

**原因**：
- 打包文件中缺少 SKILL.md
- SKILL.md 格式不正确（缺少 frontmatter）
- 使用了不支持的打包格式（.tar.gz）

**解决方案**：
1. 确保资产目录中有 SKILL.md
2. 检查 SKILL.md 开头是否有 YAML frontmatter（`---name:...description:...---`）
3. **必须使用 `.zip` 格式打包**

### 错误：Invalid metadata JSON

**原因**：
- metadata JSON 格式错误
- 字段拼写错误
- 引号未转义

**解决方案**：
1. 确保 JSON 格式正确（使用在线 JSON 校验工具）
2. 检查必填字段：`name`, `type`, `version`
3. 注意特殊字符需要转义

### 错误：asset_exists

**原因**：资产名称已被占用

**解决方案**：修改 `name` 字段为唯一标识

---

## 发布成功示例

### 响应数据
```json
{
  "success": true,
  "data": {
    "id": "s-a2cee23662c52cdb",
    "name": "my-skill",
    "version": "1.0.0",
    "files": [
      {
        "path": "SKILL.md",
        "size": 119,
        "sha256": "...",
        "contentType": "text/markdown"
      }
    ],
    "packageFile": "s-a2cee23662c52cdb.zip"
  }
}
```

### 获取信息
- **资产页面**：https://openclawmp.cc/asset/s-a2cee23662c52cdb
- **安装命令**：`openclawmp install skill/@your-username/my-skill`

---

## 进阶技巧

### 排除不必要的文件

```bash
zip -r ../my-asset.zip . -x "*.git*" -x "node_modules/*" -x "*.DS_Store"
```

### 验证打包内容

```bash
unzip -l ../my-asset.zip
```

### 查看 CLI 读取的元数据

```bash
openclawmp publish .
# 在确认前会显示识别到的元数据
```

---

## 更新日志

### v1.1.0 (2026-03-07)
- ✅ 修复：打包格式错误 - 明确必须使用 `.zip` 格式
- ✅ 修复：认证方式更新 - 推荐使用设备绑定（Device ID）
- ✅ 新增：`.tar.gz` 不支持的警告说明
- ✅ 优化：API Key 标记为已弃用
- ✅ 新增：完整 README.md

### v1.0.0
- 初始版本

---

## 贡献

如有问题或改进建议，欢迎在水产市场提 issue 或评论。

---

## 许可

本技能遵循水产市场的开源协议。
