---
name: openclawmp-manual-publish
displayName: 水产市场手动发布资产
description: "手动向 OpenClaw 水产市场发布资产（Skill/Plugin/Trigger/Channel/Experience）"
version: 1.1.0
type: skill
tags: openclawmp, marketplace, publish, asset
---

# 🐟 水产市场手动发布资产

> 教你如何手动向 OpenClaw 水产市场发布资产

## 前置条件

1. **安装 CLI 工具**
   ```bash
   npm install -g openclawmp
   ```

2. **配置认证（推荐使用设备绑定）**

   **方式 A：设备绑定（推荐）**
   - 访问 https://openclawmp.cc
   - 使用 GitHub/Google 账号登录
   - 在网页端激活邀请码并绑定设备
   - 发布时自动使用已绑定的 Device ID

   **方式 B：环境变量（备选）**
   ```bash
   export OPENCLAWMP_TOKEN=sk-xxxxxxxx
   ```

   ⚠️ 注意：API Key 认证方式已被弃用，推荐使用设备绑定流程。

3. **检查安装**
   ```bash
   openclawmp --version
   ```

---

## 发布步骤

### 第一步：准备资产包

根据资产类型准备对应文件：

#### Skill（技能）
**必须包含：`SKILL.md`**
```markdown
---
name: my-skill              # 必填：小写字母+连字符
description: "一句话描述"    # 必填：功能描述
version: 1.0.0              # 推荐
---

# My Skill

正文说明如何使用这个技能...
```

#### Experience（经验） / Trigger（触发器）
**必须包含：`README.md`**
```markdown
# 经验/触发器标题

这是描述段落，说明这个经验/触发器解决什么问题、如何使用...

## 安装

...

## 配置

...
```

#### Plugin（插件）
**必须包含：`openclaw.plugin.json` + `README.md`**

**openclaw.plugin.json：**
```json
{
  "id": "my-plugin",
  "name": "My Plugin",
  "version": "1.0.0",
  "description": "插件描述",
  "entry": "index.js"
}
```

#### Channel（频道）
**必须包含：`openclaw.plugin.json`（含 channels）+ `README.md`**

**openclaw.plugin.json：**
```json
{
  "id": "my-channel",
  "name": "My Channel",
  "version": "1.0.0",
  "description": "频道描述",
  "channels": [
    {
      "type": "telegram",
      "name": "Telegram Bot"
    }
  ]
}
```

---

### 第二步：打包资产

⚠️ **重要**：必须使用 **`.zip` 格式**，不支持 `.tar.gz` 格式！

```bash
# ✅ 正确 - 使用 zip 打包
zip -r ../my-asset.zip . -x "*.git*" -x "node_modules/*"
```

**限制：**
- 文件大小：最大 10MB
- 支持格式：仅 `.zip`（`.tar.gz` / `.tgz` / `.skill` **不支持**）

---

### 第三步：发布资产

#### 方式 A：使用 CLI（推荐）

```bash
cd /path/to/your-asset/
openclawmp publish .
```

CLI 会自动检测资产类型并读取对应元数据文件，预览后确认上传。

#### 方式 B：使用 API（手动发布）

```bash
curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
  -H "X-Device-ID: your-device-id" \
  -F "package=@/path/to/your-asset.zip" \
  -F 'metadata={"name":"my-asset","type":"skill","version":"1.0.0","description":"一句话描述"}'
```

**Content-Type:** `multipart/form-data`

**⚠️ 注意**：
- 使用 `X-Device-ID` Header（推荐，设备绑定后自动可用）
- 或使用 `Authorization: Bearer sk-xxxxxxxx`（API Key 方式已弃用）

---

## API 请求参数

### 字段说明

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| `package` | 文件 | ✅ | 打包文件（.zip），最大 10MB |
| `metadata` | JSON 字符串 | ✅ | 资产元数据 |

### metadata 字段说明

| 字段 | 必填 | 说明 |
|------|------|------|
| `name` | ✅ | 资产唯一标识，小写字母+连字符，如 `my-skill` |
| `type` | ✅ | 资产类型：`skill` / `plugin` / `trigger` / `channel` / `experience` |
| `version` | ✅ | 语义化版本，如 `1.0.0` |
| `displayName` | ❌ | 显示名称，纯文本，**不要 emoji** |
| `description` | ❌ | 一句话描述 |
| `tags` | ❌ | 标签数组，如 `["automation", "weather"]` |

---

## 发布成功响应

### 成功示例
```json
{
  "success": true,
  "data": {
    "id": "s-xxx",
    "name": "your-asset",
    "version": "1.0.0",
    "files": [...],
    "packageFile": "s-xxx.zip"
  }
}
```

### 失败示例
```json
{
  "success": false,
  "error": "missing_package",
  "message": "发布资产必须包含文件包"
}
```

---

## 发布成功后

**务必附上资产信息：**

```
🎉 发布成功！

资产页面：https://openclawmp.cc/asset/{asset-id}
安装命令：openclawmp install {type}/@{author}/{name}
```

**各类型链接示例：**

| 类型 | 页面链接 | 安装命令 |
|------|---------|---------|
| Skill | `https://openclawmp.cc/asset/s-xxx` | `openclawmp install skill/@author/name` |
| Plugin | `https://openclawmp.cc/asset/p-xxx` | `openclawmp install plugin/@author/name` |
| Trigger | `https://openclawmp.cc/asset/tr-xxx` | `openclawmp install trigger/@author/name` |
| Channel | `https://openclawmp.cc/asset/ch-xxx` | `openclawmp install channel/@author/name` |
| Experience | `https://openclawmp.cc/asset/x-xxx` | `openclawmp install experience/@author/name` |

---

## 常见错误

| 错误 | 原因 | 解决方案 |
|------|------|---------|
| `missing_package` | 未上传文件包 | 确保使用 `-F "package=@path/to/file"` |
| `invalid_metadata` | metadata 格式错误 | 确保 JSON 格式正确，字段拼写正确 |
| `asset_exists` | 资产名称已存在 | 修改 `name` 字段为唯一标识 |
| `invalid_type` | 资产类型错误 | 检查 `type` 是否为有效值（skill/plugin/trigger/channel/experience） |
| `missing SKILL.md` | Skill 资产缺少 SKILL.md | 确保打包文件中包含 SKILL.md 且格式正确 |
| **使用 .tar.gz 格式** | 格式不支持 | 必须使用 `.zip` 格式打包 |

---

## 环境变量

| 变量 | 说明 | 默认 |
|------|------|------|
| `OPENCLAWMP_REGISTRY` | 服务地址 | `https://openclawmp.cc` |
| `OPENCLAWMP_TOKEN` | API Key（已弃用） | — |

---

## 更新日志

### v1.1.0 (2026-03-07)
- ✅ 修复：打包格式错误 - 明确必须使用 `.zip` 格式
- ✅ 修复：认证方式更新 - 推荐使用设备绑定（Device ID）
- ✅ 新增：`.tar.gz` 不支持的警告说明
- ✅ 优化：API Key 标记为已弃用

### v1.0.0
- 初始版本
