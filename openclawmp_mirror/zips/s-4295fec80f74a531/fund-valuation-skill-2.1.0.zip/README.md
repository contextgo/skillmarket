# 🚀 基金估值助手 - 快速入门

> **适合谁？** 每天关注基金净值的个人投资者、想把握买卖时机的 active trader  
> **核心价值：** 在下午 15:00 前实时估算今日净值，决定是否赎回/加仓  
> **部署难度：** ⭐☆☆☆☆（5 分钟 Docker 一键启动）

## 核心能力

### 1. 基金估值实时计算
- 获取昨日基金净值（公开数据）
- 抓取基金持仓股票实时涨跌幅
- 按持仓比例计算加权涨跌幅
- 推算当日估算净值

### 2. 多基金支持
- 支持多只基金同时监控
- 持仓池本地配置（用户编辑）
- 自动更新持仓信息（可选）

### 3. 预警机制
- 用户设定涨跌幅阈值
- 达到阈值时主动提醒（console、邮件或 webhook）
- 可配置通知频率和渠道

### 4. Web 实时监控面板（新！）
- 基于 FastAPI + Bootstrap 响应式界面
- 实时展示多基金估值状态
- 自动刷新（5秒间隔）
- 阈值预警自动高亮显示
- 支持 PC 和手机端访问

### 5. 邮件通知（新！）
- 阈值触发时自动发送预警邮件
- SMTP 配置（支持 TLS/SSL）
- HTML 精美邮件模板
- 多收件人支持

### 6. 本地运行
- 无需第三方 API key
- 数据源：公开可访问
- 所有计算在本地完成

## 💎 核心亮点

✅ **实时性强** - 股票盘分钟内更新，WebSocket 秒级推送  
✅ **零成本** - 无需任何 API key，数据全公开  
✅ **隐私安全** - 所有数据本地处理，不依赖第三方云端  
✅ **灵活预警** - 自定义涨跌幅阈值，邮件/控制台/Webhook 多通道通知  
✅ **可视化** - Bootstrap 响应式面板 + ECharts 历史图表  
✅ **Docker 友好** - 一条命令启动，适合 NAS/服务器常驻  

## 📦 功能清单

| 功能 | CLI | Web UI | Docker |
|------|-----|--------|--------|
| 多基金估值计算 | ✅ | ✅ | ✅ |
| 实时推送 (WebSocket) | ❌ | ✅ | ✅ |
| 历史数据图表 | ❌ | ✅ | ✅ |
| 邮件预警 | ✅ | ✅ | ✅ |
| Webhook 通知 | ✅ | ❌ | ✅ |
| 配置管理 UI | ❌ | ✅ | ✅ |
| 自动盯盘 (watch) | ✅ | ❌ | ✅ |

## 🎯 典型使用场景

1. **盘中发现机会** - 上午看到某基金估算大跌 3%，决定下午先买入，预期第二天反弹
2. **避免冲动操作** - 设置 5% 止盈/止损，到点自动邮件提醒，避免盯盘焦虑
3. **团队监控** - 多个基金放在一个面板，一目了然，支持手机访问
4. **数据自主** - 对第三方 App 不放心？自己跑 Docker，持仓数据完全掌控

## 💰 定价与升级

**当前版本 (v2.0.0) - 完全免费**

> 所有核心功能（估值计算、Web 面板、邮件通知、Docker 部署）全部开源免费。

**未来 SaaS 化路线图：**
- Free: 5 个基金 + 30 天历史
- Basic (¥19/月): 50 个基金 + 完整历史 + CSV 导出 + 周报
- Pro (¥79/月): 无限制 + 信号分析 + 政策预警 + API 访问

**独立技能版保持免费，SaaS 版为需要云服务用户提供额外价值。**

---

## 🚀 快速开始（3 步搞定）

### 1. 安装依赖

```bash
# 方式 A：基础 CLI（最小依赖）
pip install akshare typer rich pandas

# 方式 B：完整 Web 版（推荐）
pip install -r requirements.txt
```

### 2. 配置基金

 easiest 方式：复制示例配置
```bash
cp data/fund_holdings.example.json data/fund_holdings.json
```

然后编辑 `data/fund_holdings.json`，添加你关心的基金代码。格式：
```json
{
  "funds": {
    "110011": {
      "name": "易方达优质精选混合",
      "holdings": [
        {"code": "600519", "name": "贵州茅台", "weight": 0.0897},
        {"code": "000858", "name": "五粮液", "weight": 0.0752}
      ],
      "last_nav": 1.2345,
      "thresholds": {"low": -0.03, "high": 0.03}
    }
  }
}
```

**如何获取持仓？**
- 天天基金网页面搜索基金代码 → "持仓" 标签页
- 复制前 10 大重仓股，权重总和调到 1.0 左右即可

### 3. 启动

```bash
# CLI 模式（适合命令行用户）
python -m fund_valuation.cli --watch --interval 300

# Web 面板（推荐！）
uvicorn fund_valuation.web:app --reload --port 8080
# 浏览器打开 http://localhost:8080
```

Done！你会看到实时估算净值和涨跌幅。

---

## 📖 详细文档

### CLI 使用

```bash
# 查询单只基金
python -m fund_valuation.cli single 110011

# 查询所有配置的基金
python -m fund_valuation.cli all

# 持续观察模式（每 5 分钟刷新一次）
python -m fund_valuation.cli watch --interval 300

# 查看历史数据（图表）
python -m fund_valuation.cli history 110011 --days 30

# 检查配置
python -m fund_valuation.upgrade_check
```

### Web 监控面板

启动后访问 `http://localhost:8080`，功能包括：

- **实时状态卡片** - 显示最新估算净值和涨跌幅
- **阈值预警** - 超过设定范围自动红色/绿色高亮
- **历史图表** - 使用 ECharts 展示近 30 天净值走势
- **贡献分析** - 饼图展示各持仓股票对涨跌的贡献度
- **配置管理** - 在线编辑基金配置（无需重启）
- **邮件设置** - 嵌入 SMTP 配置表单

WebSocket 每 5 秒自动推送更新，无需手动刷新。

### 邮件通知

配置邮箱后，当基金涨跌幅超过阈值时自动发送 HTML 邮件。

支持 SMTP/TLS，常见邮箱：
- Gmail: `smtp.gmail.com:587`（需开启 App Password）
- QQ: `smtp.qq.com:465`（需授权码）
- 163: `smtp.163.com:465`

配置方式：
1. Web 面板 → "邮件设置" 页面填写
2. 或编辑 `data/email_config.json`

---

## 🔧 高级功能

### 盯盘监控（v2.1+）

基于估值数据，新增 **新闻 + 技术分析 + 信号生成** 全链路监控：

```bash
# 执行单次监控分析
python -m fund_valuation.monitor

# 定时监控（每30分钟）
python -m fund_valuation.monitor-watch --interval 1800

# 查看最新信号
python -m fund_valuation.cli signals --limit 5
```

监控内容包括：
- **技术指标**：MA5/MA20、趋势判断、均线位置
- **新闻情绪**：爬取新浪财经、东方财富、Gov.cn，正面/中性/负面
- **交易信号**：STRONG_BUY / BUY / HOLD / SELL / STRONG_SELL
- **通知推送**：自动发送邮件或 Webhook

### Docker 部署

```bash
# 构建镜像
docker build -t fund-valuation .

# 运行
docker run -d \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  --name fund-val \
  fund-valuation
```

适合在 NAS (群晖) 或云服务器长期运行。

---

## 🐛 故障排除

### 常见问题

#### Q: akshare 无法获取数据
**A:** 
- 检查网络，某些数据源可能需要代理
- 尝试使用国内源或 VPN
- 查看日志中的具体错误（`logging.DEBUG`）

#### Q: Web 页面打不开
**A:** 
- 确认端口 8080 未被占用：`lsof -i:8080`
- 启动时使用 `--host 0.0.0.0` 监听所有接口
- 防火墙是否放行

#### Q: 估算净值偏差大
**A:**
- 持仓权重需总和 ≈ 1.0，否则误差会被放大
- 重仓股数据源延迟（通常几分钟内）
- 使用最新 `last_nav`（昨日净值）

#### Q: 邮件发送失败
**A:**
- 检查 SMTP 配置是否正确（端口、TLS）
- Gmail 需开启 "App Password" 并关闭两步验证
- 查看 `data/email_config.json` 和日志

---

## 📂 配置文件说明

| 文件 | 用途 | 说明 |
|------|------|------|
| `data/fund_holdings.json` | 基金持仓配置 | 用户编辑，添加要监控的基金 |
| `data/email_config.json` | 邮件通知配置 | Web 保存后自动生成 |
| `data/cache.db` | 数据缓存 | SQLite，自动清理过期数据 |
| `logs/app.log` | 运行日志 | 默认输出到控制台，可重定向 |

---

## 🧪 测试与验证

验证安装是否成功：

```bash
# 1. CLI 测试
python -m fund_valuation.cli --version
# 应输出版本号: 2.0.0

# 2. Web 测试
uvicorn fund_valuation.web:app --port 8080 &
curl -s http://localhost:8080/health | jq .
# 应看到 {"status": "ok", "version": "2.0.0", ...}

# 3. 邮件测试
python -c "
from fund_valuation.email import EmailNotifier, EmailConfig
cfg = EmailConfig(smtp_host='smtp.gmail.com', smtp_port=587, ...)
notifier = EmailNotifier(cfg)
notifier.send('测试邮件', '基金估值助手工作正常')
"
```

---

## 🙏 致谢与贡献

- 数据源：[akshare](https://github.com/akfamily/akshare) - 免费开源财经数据
- Web 框架：[FastAPI](https://fastapi.tiangolo.com/)
- 前端：Bootstrap 5 + ECharts
- 监控：Prometheus Client

**Author:** 龙小策 (Long Xiaoce) 🐉  
**Community:** 欢迎在 [水产市场](https://openclawmp.cc) 提交 Issues 和 Stars！

```bash
# 安装依赖
pip install akshare typer rich pandas

# 启动命令行
python -m fund_valuation.cli --fund 110011 --threshold -2.0,2.0

# 持续观察模式（每 5 分钟刷新）
python -m fund_valuation.cli --watch --interval 300

# 查看所有基金
python -m fund_valuation.cli --all
```

### Web 监控界面（推荐！）

```bash
# 安装完整依赖（包含 FastAPI）
pip install -r requirements.txt

# 启动 Web 面板
fund-valuation-web --port 8080
# 或：python -m fund_valuation.web --port 8080

# 访问 http://localhost:8080 查看实时估值
```

Web 功能：
- 实时刷新（5秒）
- 阈值预警颜色高亮
- 响应式设计（手机/PC）
- 邮件配置界面（在线设置）

## 配置说明

### 1. 基金配置

编辑 `data/fund_holdings.json` 添加要监控的基金：

```json
{
  "funds": {
    "110011": {
      "name": "易方达优质精选混合",
      "holdings": [
        {"code": "600519", "name": "贵州茅台", "weight": 0.0897},
        {"code": "000858", "name": "五粮液", "weight": 0.0752},
        {"code": "000568", "name": "泸州老窖", "weight": 0.0621}
      ],
      "last_nav": 1.2345,
      "thresholds": {"low": -0.03, "high": 0.03}
    }
  }
}
```

**字段说明**：
- `holdings`: 持仓列表，需填股票代码、名称、权重（建议总和≈1.0）
- `last_nav`: 昨日单位净值（可从天天基金查询）
- `thresholds`: 预警阈值，低于/高于时触发提醒

### 2. 邮件通知配置

#### 方式一：Web 界面配置（推荐）
启动 Web 面板后，进入"邮件配置"页面填写：
- SMTP 服务器（如 smtp.gmail.com:587）
- 用户名和密码/授权码
- 发件人邮箱
- 收件人邮箱列表

#### 方式二：手动编辑配置
`data/email_config.json`（启动 Web 后自动生成）：
```json
{
  "smtp_host": "smtp.gmail.com",
  "smtp_port": 587,
  "smtp_user": "your-email@gmail.com",
  "smtp_password": "your-password",
  "from_email": "your-email@gmail.com",
  "to_emails": ["receiver@example.com"],
  "use_tls": true
}
```

## 技术实现

- **数据源**：akshare、天天基金公开数据
- **更新频率**：分钟级（取决于行情 API）
- **估算公式**：`今日估算值 = 昨日单位净值 × (1 + 持仓加权涨跌幅)`
- **错误处理**：网络异常时使用缓存或提示

## 🚀 新增：盯盘监控功能（v2.1+）

基于估值数据，新增 **新闻爬取 + 技术分析 + 信号生成** 的全链路监控：

### 功能清单

| 功能 | 命令 / API | 描述 |
|------|------------|------|
| **信号生成** | `fund-monitor` <br> `POST /api/monitor/run` | 执行单次完整监控分析（新闻 + 技术指标 + 信号） |
| **定时监控** | `fund-monitor-watch --interval 1800` | 以指定间隔自动运行监控 |
| **查看信号** | `fund-signals --limit 10` <br> `GET /api/monitor/signals` | 从报告读取最新的监控信号 |
| **查看新闻** | `fund-news 110011` <br> `GET /api/monitor/news/{code}` | 显示与该基金相关的财经新闻 |
| **通知推送** | `POST /api/monitor/notify` | 将信号通过邮件/Webhook推送给用户 |

### 工作流程

```
1. 读取净值历史（data/history/fund_XXX.jsonl）
2. 计算技术指标（MA5/MA20、短期/中期趋势、均线位置）
3. 爬取相关新闻（RSS + 关键词过滤）
   - 新浪财经、东方财富、Gov.cn 政策公告
4. 分析新闻情绪（正面/中性/负面）
5. 根据规则生成交易信号：
   - 🔥 STRONG_BUY: 技术+情绪双强，低位机会
   - 📈 BUY: 趋势向上或情绪正面
   - ⏸️ HOLD: 震荡不明
   - 📉 SELL: 趋势走弱或情绪负面
   - ❄️ STRONG_SELL: 连续下行 + 重大利空
6. 输出建议操作（买入/卖出/持有 + 置信度）
```

### 信号规则示例

- **强烈买入**：短期+中期趋势向上、新闻情绪正面、相对均线低位（-5%以下）
- **买入**：短期趋势向上、情绪非负面
- **卖出**：短期+中期趋势向下、新闻情绪负面
- **强烈卖出**：连续下行、情绪严重负面、跌破均线 10%

### 新闻爬取来源

- **RSS 源**：新浪财经、东方财富等（可扩展）
- **政策公告**：Gov.cn 金融政策栏目
- **相关性过滤**：基于基金名称、关键词自动筛选
- **缓存机制**：15分钟缓存，避免重复抓取

### 通知与提醒

- **邮件通知**：可配置 SMTP，信号生成后自动发送
- **Webhook**：推送到企业微信、钉钉、Slack 等
- **WebSocket**：Web 面板实时接收最新信号

### CLI 使用示例

```bash
# 监控所有基金（生成报告）
python -m fund_valuation.cli monitor

# 仅监控一只基金
python -m fund_valuation.cli monitor 110011

# 定时监控（每30分钟）
python -m fund_valuation.cli monitor-watch --interval 1800

# 查看最新信号
python -m fund_valuation.cli signals --limit 5

# 查看某基金相关新闻
python -m fund_valuation.cli news 110011 --count 10
```

### Web API

- `POST /api/monitor/run` - 触发监控
- `GET /api/monitor/report` - 获取完整报告
- `GET /api/monitor/signals?limit=10` - 获取最新信号列表
- `GET /api/monitor/news/{fund_code}?count=5` - 获取基金新闻
- `POST /api/monitor/notify` - 发送信号通知（email/webhook/websocket）

---

## 技术实现

- **数据源**：akshare、天天基金公开数据
- **更新频率**：分钟级（取决于行情 API）
- **估算公式**：`今日估算值 = 昨日单位净值 × (1 + 持仓加权涨跌幅)`
- **错误处理**：网络异常时使用缓存或提示
- **新闻爬取**：feedparser + BeautifulSoup
- **情绪分析**：基于关键词匹配
- **技术指标**：MA、趋势判断

## 合规声明

⚠️ **重要提示**：
- 本工具仅为**个人估算参考**和**监控辅助**，不提供任何投资建议
- 估算净值可能与实际净值存在偏差，请以基金公司官方公布为准
- 用户需自行承担投资风险
- 请勿用于高频交易或自动化交易决策

所有数据均来自公开渠道，使用者应遵守数据源的使用条款。