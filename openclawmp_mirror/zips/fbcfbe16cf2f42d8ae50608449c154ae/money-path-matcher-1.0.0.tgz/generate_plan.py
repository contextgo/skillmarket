#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
赚钱方案Word文档生成器
根据用户输入生成个性化的赚钱方案Word文档
"""

from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE
from docx.oxml.ns import qn
import json
import sys
import os

def set_chinese_font(run, font_name='微软雅黑', size=11, bold=False, color=None):
    """设置中文字体"""
    run.font.name = font_name
    run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)
    run.font.size = Pt(size)
    run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)

def add_heading_zh(doc, text, level=1):
    """添加中文标题"""
    heading = doc.add_heading(level=level)
    run = heading.add_run(text)
    colors = {
        1: (0, 112, 192),  # 蓝色
        2: (68, 114, 196),  # 深蓝
        3: (0, 0, 0)  # 黑色
    }
    set_chinese_font(run, '微软雅黑', 16 if level==1 else 14 if level==2 else 12, 
                     bold=True, color=colors.get(level, (0,0,0)))
    return heading

def add_paragraph_zh(doc, text, bold=False, size=11, align='left', color=None):
    """添加中文段落"""
    p = doc.add_paragraph()
    if align == 'center':
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    elif align == 'right':
        p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    
    run = p.add_run(text)
    set_chinese_font(run, '微软雅黑', size, bold, color)
    return p

def generate_money_plan(user_info, output_path=None):
    """
    生成赚钱方案Word文档
    
    user_info: dict 包含用户信息
        - resources: 拥有的资源
        - time: 可投入时间
        - risk: 风险偏好
        - goal: 目标
        - skills: 技能
        - capital: 本金
    """
    
    doc = Document()
    
    # 设置默认字体
    style = doc.styles['Normal']
    style.font.name = '微软雅黑'
    style._element.rPr.rFonts.set(qn('w:eastAsia'), '微软雅黑')
    
    # ========== 封面 ==========
    doc.add_paragraph()
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 标题
    title = doc.add_paragraph()
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = title.add_run('赚钱方案执行手册')
    set_chinese_font(run, '微软雅黑', 24, bold=True, color=(0, 112, 192))
    
    doc.add_paragraph()
    
    # 副标题
    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = subtitle.add_run('根据您的条件定制 · 可直接执行')
    set_chinese_font(run, '微软雅黑', 14, color=(128, 128, 128))
    
    doc.add_paragraph()
    doc.add_paragraph()
    
    # 生成日期
    from datetime import datetime
    date_p = doc.add_paragraph()
    date_p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run = date_p.add_run(f'生成日期：{datetime.now().strftime("%Y年%m月%d日")}')
    set_chinese_font(run, '微软雅黑', 11, color=(128, 128, 128))
    
    # 分页
    doc.add_page_break()
    
    # ========== 一、条件分析 ==========
    add_heading_zh(doc, '一、您的条件分析', 1)
    
    add_heading_zh(doc, '1. 资源盘点', 2)
    resources = user_info.get('resources', '未明确')
    add_paragraph_zh(doc, f'• 拥有资源：{resources}')
    
    skills = user_info.get('skills', '无特殊技能')
    add_paragraph_zh(doc, f'• 技能水平：{skills}')
    
    capital = user_info.get('capital', '无本金')
    add_paragraph_zh(doc, f'• 资金情况：{capital}')
    
    network = user_info.get('network', '人脉一般')
    add_paragraph_zh(doc, f'• 人脉资源：{network}')
    
    add_heading_zh(doc, '2. 时间投入', 2)
    time_commit = user_info.get('time', '每天1-2小时')
    add_paragraph_zh(doc, f'• 可投入时间：{time_commit}')
    
    add_heading_zh(doc, '3. 风险偏好', 2)
    risk = user_info.get('risk', '中等')
    add_paragraph_zh(doc, f'• 风险承受力：{risk}')
    
    add_heading_zh(doc, '4. 目标设定', 2)
    goal = user_info.get('goal', '增加收入')
    add_paragraph_zh(doc, f'• 赚钱目标：{goal}')
    
    doc.add_page_break()
    
    # ========== 二、推荐维度 ==========
    add_heading_zh(doc, '二、推荐赚钱维度', 1)
    
    # 根据用户信息匹配维度
    main_dimension = match_dimension(user_info)
    
    add_heading_zh(doc, f'主维度：{main_dimension["name"]}', 2)
    add_paragraph_zh(doc, main_dimension["description"])
    
    add_heading_zh(doc, '匹配理由', 2)
    for reason in main_dimension["reasons"]:
        add_paragraph_zh(doc, f'• {reason}')
    
    doc.add_page_break()
    
    # ========== 三、执行方案 ==========
    add_heading_zh(doc, '三、具体执行方案', 1)
    
    add_heading_zh(doc, f'推荐方向：{main_dimension["direction"]}', 2)
    
    add_heading_zh(doc, '启动难度', 2)
    difficulty = main_dimension.get("difficulty", "★★☆☆☆")
    add_paragraph_zh(doc, f'难度等级：{difficulty}')
    
    add_heading_zh(doc, '操作步骤', 2)
    for i, step in enumerate(main_dimension["steps"], 1):
        add_paragraph_zh(doc, f'{i}. {step}')
    
    add_heading_zh(doc, '第一周行动计划', 2)
    for i, action in enumerate(main_dimension["week1"], 1):
        add_paragraph_zh(doc, f'Day {i}：{action}')
    
    add_heading_zh(doc, '预计收益', 2)
    earnings = main_dimension.get("earnings", "视具体情况而定")
    add_paragraph_zh(doc, f'• 第1个月：{earnings.get("month1", "1000-3000元")}')
    add_paragraph_zh(doc, f'• 第3个月：{earnings.get("month3", "3000-5000元")}')
    add_paragraph_zh(doc, f'• 稳定后：{earnings.get("stable", "5000元+/月")}')
    
    doc.add_page_break()
    
    # ========== 四、避坑指南 ==========
    add_heading_zh(doc, '四、避坑指南', 1)
    
    add_heading_zh(doc, '常见陷阱', 2)
    traps = [
        '先交钱的项目 → 一律拒绝',
        '高收益承诺 → 警惕诈骗',
        '拉人头模式 → 涉嫌传销',
        '刷单返利 → 100%骗局',
        '违规内容 → 法律红线'
    ]
    for trap in traps:
        add_paragraph_zh(doc, f'• {trap}')
    
    add_heading_zh(doc, '法律风险提示', 2)
    add_paragraph_zh(doc, '⚠️ 重要提醒：')
    add_paragraph_zh(doc, '• 本方案仅提供合法合规建议')
    add_paragraph_zh(doc, '• 任何涉及传销、诈骗、违法的项目坚决不做')
    add_paragraph_zh(doc, '• 投资有风险，入市需谨慎')
    add_paragraph_zh(doc, '• 依法纳税，保留交易记录')
    
    add_heading_zh(doc, '防骗 Checklist', 2)
    checklist = [
        '是否要求先交钱？→ 是则拒绝',
        '收益是否高得不合理？→ 是则警惕',
        '是否需要拉人头？→ 是则远离',
        '是否了解清楚运作模式？→ 否则不做',
        '是否签订正规合同？→ 否则谨慎'
    ]
    for item in checklist:
        add_paragraph_zh(doc, f'□ {item}')
    
    doc.add_page_break()
    
    # ========== 五、进阶建议 ==========
    add_heading_zh(doc, '五、进阶建议', 1)
    
    add_heading_zh(doc, '如何放大收益', 2)
    scaling = main_dimension.get("scaling", [
        '持续提升专业技能',
        '建立个人品牌',
        '拓展客户/渠道',
        '开发被动收入'
    ])
    for tip in scaling:
        add_paragraph_zh(doc, f'• {tip}')
    
    add_heading_zh(doc, '长期发展路径', 2)
    add_paragraph_zh(doc, '• 第一阶段（1-3个月）：跑通流程，验证模式')
    add_paragraph_zh(doc, '• 第二阶段（3-6个月）：稳定收入，优化效率')
    add_paragraph_zh(doc, '• 第三阶段（6-12个月）：放大规模，建立壁垒')
    add_paragraph_zh(doc, '• 第四阶段（1年+）：被动收入，财务自由')
    
    # 保存文档
    if not output_path:
        desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
        output_path = os.path.join(desktop, '赚钱方案执行手册.docx')
    
    doc.save(output_path)
    print(f'方案已生成：{output_path}')
    return output_path

def match_dimension(user_info):
    """根据用户信息匹配赚钱维度"""
    
    # 提取关键信息
    has_skill = user_info.get('skills') and user_info.get('skills') != '无'
    has_capital = user_info.get('capital') and '无' not in user_info.get('capital', '')
    has_network = '人脉' in user_info.get('network', '') or '广' in user_info.get('network', '')
    time_full = '全职' in user_info.get('time', '') or '8' in user_info.get('time', '')
    
    # 匹配逻辑
    if has_skill:
        return {
            "name": "技能维度",
            "description": "靠专业能力变现，单价高、越做越值钱。适合有一技之长的人。",
            "reasons": [
                "您具备专业技能，可以直接变现",
                "技能变现单价高，成长空间大",
                "可积累作品集，越做越值钱"
            ],
            "direction": "技能服务 + 作品变现",
            "difficulty": "★★☆☆☆",
            "steps": [
                "整理技能，制作3-5个样例作品",
                "在闲鱼/小红书/猪八戒等平台发布接单信息",
                "接第一单，积累案例和好评",
                "逐步提升单价，建立个人品牌",
                "后期可售卖模板/课程，实现被动收入"
            ],
            "week1": [
                "整理技能，确定服务方向",
                "制作3个样例作品",
                "注册接单平台账号",
                "发布服务信息",
                "主动寻找第一单",
                "完成第一单交付",
                "收集反馈，优化服务"
            ],
            "earnings": {
                "month1": "1000-3000元",
                "month3": "3000-8000元",
                "stable": "8000-20000元/月"
            },
            "scaling": [
                "持续提升专业技能",
                "建立作品集和个人品牌",
                "从接单转向卖模板/课程",
                "组建团队，承接大项目"
            ]
        }
    elif has_network:
        return {
            "name": "信息维度",
            "description": "靠信息差赚钱，轻资产、不用囤货。适合人脉广、善于沟通的人。",
            "reasons": [
                "您人脉资源丰富，信息灵通",
                "信息差变现轻资产、启动快",
                "人脉是核心竞争力，难以复制"
            ],
            "direction": "资源撮合 + 中介服务",
            "difficulty": "★★★☆☆",
            "steps": [
                "梳理人脉资源，分类整理",
                "了解各方需求（找客户/找货源/找合作）",
                "促成第一单撮合，收取佣金",
                "建立信任，形成口碑",
                "扩大撮合范围，提高佣金收入"
            ],
            "week1": [
                "梳理人脉清单",
                "分类整理资源",
                "主动了解需求",
                "寻找匹配机会",
                "促成第一单",
                "收取第一笔佣金",
                "总结经验，优化流程"
            ],
            "earnings": {
                "month1": "500-2000元",
                "month3": "2000-8000元",
                "stable": "8000-30000元/月"
            },
            "scaling": [
                "建立信息数据库",
                "发展下线/合作伙伴",
                "从撮合转向平台化",
                "提供增值服务（咨询、培训）"
            ]
        }
    elif has_capital:
        return {
            "name": "资本维度",
            "description": "用钱生钱，被动收入强。适合有本金、能承受风险的人。",
            "reasons": [
                "您有本金，可以让钱为你工作",
                "被动收入，时间自由",
                "复利效应，长期增值"
            ],
            "direction": "稳健理财组合",
            "difficulty": "★★★☆☆",
            "steps": [
                "学习基础理财知识",
                "评估风险承受能力",
                "配置资产（稳健+成长）",
                "定期复盘调整",
                "长期坚持，享受复利"
            ],
            "week1": [
                "学习理财基础知识",
                "评估自身风险承受力",
                "开设投资账户",
                "研究投资产品",
                "完成首次配置",
                "建立投资记录",
                "设定复盘提醒"
            ],
            "earnings": {
                "month1": "视市场情况而定",
                "month3": "年化4%-8%",
                "stable": "被动收入，长期增值"
            },
            "scaling": [
                "持续学习投资知识',
                "优化资产配置',
                "增加本金投入',
                "拓展投资品类'
            ]
        }
    else:
        # 默认：时间维度
        return {
            "name": "时间维度",
            "description": "靠出卖时间换钱，上手快、立刻见钱。适合时间充裕、急需用钱的人。",
            "reasons": [
                "您时间充裕，可以立即开始",
                "无需技能积累，门槛最低",
                "立刻见钱，解决燃眉之急"
            ],
            "direction": "多平台兼职组合",
            "difficulty": "★☆☆☆☆",
            "steps": [
                "注册美团众包/蜂鸟众包等跑腿平台",
                "利用碎片时间接单",
                "同时学习一项技能（剪辑/写作等）",
                "3个月后转向技能变现",
                "实现从时间换钱到技能换钱的升级"
            ],
            "week1": [
                "注册跑腿平台账号",
                "完成平台培训",
                "接第一单跑腿",
                "熟悉平台规则",
                "每天抽1小时学习技能",
                "总结时间管理经验",
                "规划技能学习路径"
            ],
            "earnings": {
                "month1": "1000-3000元",
                "month3": "2000-5000元",
                "stable": "3000-8000元/月"
            },
            "scaling": [
                "提升单位时间价值",
                "学习技能，转型升级',
                "从执行者转向组织者',
                "建立团队，承接大项目'
            ]
        }

if __name__ == '__main__':
    # 示例用法
    user_info = {
        'resources': '会剪辑，有电脑',
        'skills': '会基础剪辑，用剪映',
        'capital': '无本金',
        'network': '人脉一般',
        'time': '每天晚上2小时',
        'risk': '低',
        'goal': '长期副业，月入5000'
    }
    
    if len(sys.argv) > 1:
        # 从JSON文件读取用户信息
        with open(sys.argv[1], 'r', encoding='utf-8') as f:
            user_info = json.load(f)
    
    output_path = sys.argv[2] if len(sys.argv) > 2 else None
    generate_money_plan(user_info, output_path)
