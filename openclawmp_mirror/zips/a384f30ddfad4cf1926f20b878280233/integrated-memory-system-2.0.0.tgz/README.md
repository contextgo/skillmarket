# 三层记忆系统增强版

分层记忆 + Qdrant 向量检索 + BM25 混合搜索 + Weibull 衰减 + Smart Extraction + 自我改进治理。

## 功能

- **分层记忆**：Core（核心）/ Working（工作）/ Peripheral（边缘）三层，差异化衰减
- **向量检索**：基于 Qdrant 的语义搜索，硅基流动 Qwen3-Embedding-8B
- **BM25 混合搜索**：RRF 融合（向量70% + BM25 30%），精确关键词 + 语义理解
- **Weibull 衰减引擎**：composite = 0.4×时间 + 0.3×频率 + 0.3×固有价值
- **Smart Extraction**：LLM 驱动，从 session 内容自动提炼6类记忆
- **自我改进治理**：自动 review LEARNINGS/ERRORS，合并重复、降级已解决

## 适用场景

需要持久化记忆、跨会话理解上下文的 AI Agent 场景。
