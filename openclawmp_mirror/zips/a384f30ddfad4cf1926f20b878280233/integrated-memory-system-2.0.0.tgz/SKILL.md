---
name: integrated-memory-system
slug: integrated-memory-system
version: 2.0.0
description: 三层记忆系统增强版 — 分层记忆 + Qdrant 向量检索 + BM25 混合搜索 + Weibull 衰减 + Smart Extraction + 自我改进治理
---

# 三层记忆系统 v2.0

## 架构概览

```
用户输入 → Smart Extraction → Qdrant (向量+元数据)
                          ↓
              Weibull 衰减引擎（自动淘汰）
                          ↓
              BM25 Hybrid Search（关键词+向量）
                          ↓
              Self-Improvement Review（定期治理）
```

## 核心能力

### 1. BM25 + Hybrid Search（混合检索）

**脚本**: `scripts/bm25_hybrid.py`

```
用法: python3 scripts/bm25_hybrid.py <查询语句>
```

**原理**: RRF (Reciprocal Rank Fusion) 融合向量检索 + BM25 关键词检索

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `VECTOR_WEIGHT` | 0.7 | 向量权重 |
| `BM25_WEIGHT` | 0.3 | 关键词权重 |
| `RRF_K` | 60 | RRF 融合参数 |
| `recency_half_life_days` | 14 | 时间衰减半衰期 |

**何时用**: 记忆检索时同时需要语义理解 + 关键词精确匹配

---

### 2. Weibull 衰减引擎

**脚本**: `scripts/weibull_decay.py`

```
# Dry-run（默认，不实际删除）
python3 scripts/weibull_decay.py

# 执行归档/删除
python3 scripts/weibull_decay.py --apply --no-archive --delete
```

**原理**: Weibull 衰减模型

```
recency = exp(-lambda × days^beta)

composite = 0.4×时间衰减 + 0.3×频率 + 0.3×固有价值
```

| 层级 | Beta | 衰减地板 |
|------|------|---------|
| core | 0.8 | 0.9 |
| working | 1.0 | 0.7 |
| peripheral | 1.3 | 0.5 |

**何时用**: 每周定时任务，自动淘汰低价值记忆

---

### 3. Smart Extraction（智能提炼）

**脚本**: `scripts/smart_extract.py`

```
# 直接提取文本
python3 scripts/smart_extract.py <文本内容>

# 从 session 文件提取
python3 scripts/smart_extract.py --session <session.jsonl>
```

**LLM 提取 6 类记忆**:
- `preference` — 用户偏好
- `fact` — 客观事实
- `decision` — 决策结论
- `entity` — 实体/对象
- `lesson` — 教训/错误
- `other` — 其他

**何时用**: session 结束后自动提炼关键信息存入 Qdrant

---

### 4. Self-Improvement Governance（自我改进治理）

**脚本**: `scripts/self_improve_review.py`

```
# Dry-run
python3 scripts/self_improve_review.py

# 执行
python3 scripts/self_improve_review.py --apply
```

**功能**:
- 自动检测已解决条目 → 降级
- 合并重复 LEARNINGS/ERRORS 条目
- 淘汰 >90天 且重要度 <0.6 的过时条目
- 生成可读摘要报告

**何时用**: 每周 cron 任务

---

## 向量检索配置

| 配置 | 值 |
|------|-----|
| 向量数据库 | Qdrant |
| 地址 | `http://192.168.110.100:6333` |
| 集合名 | `nunu_memories` |
| Embedding | SiliconFlow Qwen3-Embedding-8B (4096维) |
| API Key | `sk-doiahqvctrbspplryxibdpuxjngntayfcpdmjgzpsxzzueyj` |

## 现有工具

| 工具 | 脚本 | 用途 |
|------|------|------|
| 向量检索 | `scripts/vector_search.py` | 基础语义搜索 |
| 混合检索 | `scripts/bm25_hybrid.py` | 向量+关键词融合 |
| 记忆存储 | `scripts/vector_search.py --add` | 添加记忆 |
| 衰减引擎 | `scripts/weibull_decay.py` | 自动淘汰低价值记忆 |
| 智能提炼 | `scripts/smart_extract.py` | LLM 驱动提取 |
| 自我回顾 | `scripts/self_improve_review.py` | LEARNINGS/ERRORS 治理 |

## cron 建议

```cron
# 每周一 9:00 — Weibull 衰减 + 自我回顾
0 9 * * 1 python3 ~/.openclaw/workspace/scripts/weibull_decay.py --apply

# 每周一 9:30 — 自我改进治理
0 9 * * 1 python3 ~/.openclaw/workspace/scripts/self_improve_review.py --apply
```

## 触发词

- `混合检索`、`BM25`、`关键词搜索`
- `记忆衰减`、`weibull`、`清理记忆`
- `智能提炼`、`提取记忆`、`session 总结`
- `自我回顾`、`治理`、`review learnings`
