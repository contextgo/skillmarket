#!/usr/bin/env python3
"""
恋爱配对问卷 — 星座版
基于12星座元素特质，设计5题核心问卷
输出：配对兼容性评分 + 关系建议
"""

# =====================
# 问卷题目
# =====================
QUESTIONS = [
    {
        "id": 1,
        "question": "约会时，你更喜欢：",
        "options": [
            {"A": "热闹的社交场合，认识新朋友", "type": "fire_wind"},
            {"B": "安静有氛围的餐厅，只有两个人", "type": "water_earth"},
        ],
        "analysis": {
            "fire_wind": "偏向火象/风象——需要外部刺激和社交能量",
            "water_earth": "偏向水象/土象——需要情感深度和安全感",
        },
    },
    {
        "id": 2,
        "question": "伴侣没有及时回复消息，你会：",
        "options": [
            {"A": "继续自己的生活，稍后再看", "type": "air"},
            {"B": "忍不住想：他是不是不在乎我了", "type": "earth"},
            {"C": "主动发一条，但假装若无其事", "type": "water"},
            {"D": "想很多，但假装没事", "type": "fire"},
        ],
        "analysis": {
            "air": "风象偏理性，需要独立空间",
            "earth": "土象偏务实，但容易过度担忧安全感",
            "water": "水象敏感，情感需求高",
            "fire": "火象直接，但会用行动掩饰不安",
        },
    },
    {
        "id": 3,
        "question": "这段关系中，你最在意的是：",
        "options": [
            {"A": "精神共鸣，能聊到灵魂深处", "type": "water_fire"},
            {"B": "现实稳定，有未来规划", "type": "earth"},
            {"C": "新鲜感，每天都有心跳", "type": "fire_air"},
            {"D": "被理解，被完整接纳", "type": "water_earth"},
        ],
        "analysis": {
            "water_fire": "深度情感连接，灵魂伴侣类型",
            "earth": "务实派，需要实际保障",
            "fire_air": "追求刺激和多巴胺",
            "water_earth": "需要安全感和归属感",
        },
    },
    {
        "id": 4,
        "question": "吵架时，你通常会：",
        "options": [
            {"A": "沉默或冷战后主动和好", "type": "water"},
            {"B": "当场说清楚，不憋着", "type": "fire"},
            {"C": "讲逻辑，分析对错", "type": "air"},
            {"D": "忍着，算了不计较", "type": "earth"},
        ],
        "analysis": {
            "water": "水象用感受在处理冲突",
            "fire": "火象直接但容易冲动",
            "air": "风象喜欢理性沟通",
            "earth": "土象避免冲突，追求和谐",
        },
    },
    {
        "id": 5,
        "question": "理想中的恋爱节奏是：",
        "options": [
            {"A": "每天都要有互动，黏在一起", "type": "water"},
            {"B": "独立空间重要，但要有深度陪伴", "type": "fire_air"},
            {"C": "有共同目标，一起成长", "type": "earth"},
            {"D": "随性而为，不刻意定义关系", "type": "air"},
        ],
        "analysis": {
            "water": "高情感需求，需要高频连接",
            "fire_air": "既需要独立也需要共鸣",
            "earth": "需要共同成长和稳定性",
            "air": "自由主义，不喜欢框架束缚",
        },
    },
]

# =====================
# 星座元素映射
# =====================
ZODIAC_ELEMENTS = {
    "白羊座": "fire", "狮子座": "fire", "射手座": "fire",
    "金牛座": "earth", "处女座": "earth", "摩羯座": "earth",
    "双子座": "air", "天秤座": "air", "水瓶座": "air",
    "巨蟹座": "water", "天蝎座": "water", "双鱼座": "water",
}

# 元素兼容性评分
ELEMENT_SCORES = {
    ("fire", "fire"): 3, ("fire", "air"): 5, ("fire", "water"): 1, ("fire", "earth"): 2,
    ("air", "air"): 3, ("air", "water"): 2, ("air", "earth"): 2, ("air", "fire"): 5,
    ("water", "water"): 3, ("water", "earth"): 4, ("water", "fire"): 1, ("water", "air"): 2,
    ("earth", "earth"): 4, ("earth", "fire"): 2, ("earth", "air"): 2, ("earth", "water"): 4,
}


def get_element(zodiac: str) -> str:
    """获取星座的元素"""
    return ZODIAC_ELEMENTS.get(zodiac, "unknown")


def calculate_compatibility(zodiac_a: str, zodiac_b: str) -> dict:
    """计算星座配对兼容性"""
    elem_a = get_element(zodiac_a)
    elem_b = get_element(zodiac_b)
    score = ELEMENT_SCORES.get((elem_a, elem_b), 3)
    
    labels = {
        5: ("极佳CP", "★★★★★", "天生一对"),
        4: ("很好CP", "★★★★☆", "和谐稳定"),
        3: ("中等CP", "★★★☆☆", "需要磨合"),
        2: ("有挑战", "★★☆☆☆", "差异明显"),
        1: ("高难度", "★☆☆☆☆", "慎重复"),
    }
    label, stars, note = labels.get(score, labels[3])
    
    return {
        "score": score,
        "stars": stars,
        "label": label,
        "note": note,
        "element_a": elem_a,
        "element_b": elem_b,
    }


def run_quiz() -> dict:
    """交互式运行问卷，返回回答结果"""
    print("\n🔮 恋爱配对问卷（星座版）\n")
    print("=" * 40)
    print("请依次选择，每题1-2个字母（如AB）\n")
    
    answers = {}
    for q in QUESTIONS:
        print(f"第{q['id']}题：{q['question']}")
        for opt_dict in q["options"]:
            for opt_key, opt_text in opt_dict.items():
                if opt_key == "type":
                    continue
                print(f"  {opt_key}: {opt_text}")
        choice = input("你的选择：").strip().upper()
        answers[q["id"]] = choice
        print()
    
    return answers


def generate_report(
    zodiac_a: str,
    zodiac_b: str,
    user_answers: dict,
    user_type: str = "提问方"
) -> str:
    """生成配对分析报告"""
    compat = calculate_compatibility(zodiac_a, zodiac_b)
    
    # 统计回答类型分布
    type_counts = {"air": 0, "earth": 0, "water": 0, "fire": 0}
    for q in QUESTIONS:
        choice = user_answers.get(q["id"], "A")
        # 遍历所有选项，找到用户选择的字母对应的type
        for opt_dict in q["options"]:
            for opt_key, opt_val in opt_dict.items():
                if opt_key == "type":
                    continue
                if opt_key in choice:
                    t = opt_dict.get("type", "")
                    for t2 in ["air", "earth", "water", "fire"]:
                        if t2 in t:
                            type_counts[t2] += 1
    
    dominant = max(type_counts, key=type_counts.get)
    type_labels = {
        "air": "风象（理性自由）",
        "earth": "土象（务实稳定）",
        "water": "水象（情感深度）",
        "fire": "火象（热情直接）",
    }
    
    report = f"""
╔══════════════════════════════════════════╗
║   🌟 恋爱配对分析报告                    ║
╚══════════════════════════════════════════╝

【基本信息】
测试方：{user_type}
星座A：{zodiac_a}（{compat['element_a']}元素）
星座B：{zodiac_b}（{compat['element_b']}元素）

【星座配对】{compat['stars']}
  {compat['label']} — {compat['note']}

【性格主导】
测试方主导类型：{type_labels.get(dominant, '未知')}
（{', '.join([f"{k}:{v}题" for k,v in type_counts.items() if v > 0])}）

【关系适配建议】
"""
    
    if compat["score"] >= 4:
        report += f"""
✅ 你们是天然的「{compat['element_a']}+{compat['element_b']}」组合
—— 相处成本低，天然理解对方的行为逻辑
—— 建议：保持新鲜感，给关系注入活力

"""
    elif compat["score"] == 3:
        report += f"""
⚠️ 你们属于典型的「{compat['element_a']}+{compat['element_b']}」组合
—— 差异是吸引力也是摩擦来源
—— 建议：欣赏差异而非改变对方

"""
    else:
        report += f"""
🔴 你们是「{compat['element_a']}+{compat['element_b']}」组合
—— 需要刻意经营和理解
—— 建议：建立沟通机制，避免硬碰硬

"""
    
    report += """【恋爱配对结论】
  配对结论仅供参考，真正的关系质量取决于双方成长意愿
  
  🔮 夜观星想说：
  "星座能告诉你你们天然合不合，但无法替代真实的相处。
   好的关系是彼此的修行，不是天生一对就万事大吉。"
"""
    return report


if __name__ == "__main__":
    import sys
    
    print("🌟 恋爱配对问卷开始\n")
    
    zodiac_a = input("你的星座（例如：处女座）：").strip()
    zodiac_b = input("对方的星座（例如：射手座）：").strip()
    
    answers = run_quiz()
    report = generate_report(zodiac_a, zodiac_b, answers)
    print(report)
    
    # 同时输出星座单独兼容性
    compat = calculate_compatibility(zodiac_a, zodiac_b)
    print(f"\n📊 星座速配指数：{compat['stars']}（{compat['label']}）")
