#!/usr/bin/env python3
"""
塔罗牌每日抽取脚本
3张牌：Challenge / Guidance / Blessing
纯本地实现，无需外部依赖
"""
import random, datetime, json
from pathlib import Path

# 大阿尔卡纳 22 张（0=愚人，21=世界）
MAJOR_ARCANA = [
    (0,  "愚人",     "新的开始，但不要忽略脚下的悬崖",          "放下计划，跟随直觉走一步",          "意外的好运即将降临"),
    (1,  "魔术师",   "资源齐备，但方向未明",                    "把现有资源真正用起来",                "一个想法开始成形"),
    (2,  "女祭司",   "表面平静，暗流涌动",                    "倾听内心的声音，而非表面的噪音",      "隐藏的答案即将浮出水面"),
    (3,  "女皇",     "丰盛，但可能是假象",                    "照顾好自己的状态再行动",              "实际的帮助来自女性友人"),
    (4,  "皇帝",     "秩序与控制，压力大",                     "不要硬碰硬，换个方式推进",            "一个决定会带来长期收益"),
    (5,  "教皇",     "传统力量，团队压力",                    "找到可信赖的人商量",                  "获得授权或正式认可"),
    (6,  "恋人",     "选择困难，或感情波动",                   "跟随内心的价值判断",                  "一个关键关系出现突破"),
    (7,  "战车",     "冲突或竞争，需要果断",                    "稳住方向，不被他人的节奏带走",         "克服一个重要障碍"),
    (8,  "力量",     "内在力量被挑战，表面强势",               "用温柔的方式展现真正的勇气",           "突破一个心理限制"),
    (9,  "隐者",     "孤独前行，看不清方向",                  "减少社交，专注核心任务",               "找到问题的关键线索"),
    (10, "命运之轮",  "运势转折，外部力量主导",                  "不要对抗变化，顺势而为",               "好运向你倾斜"),
    (11, "正义",     "清算或真相浮现，压力责任",                "做决定前先收集全部事实",              "一个公正的结果出现"),
    (12, "倒吊人",   "暂停，看似停滞",                         "换个角度看问题，倒立也有价值",         "等待是必要的步骤"),
    (13, "死神",     "结束，恐惧，但也是新生",                 "告别旧模式，才能迎接新的",             "一个阶段正式结束，轻装前行"),
    (14, "节制",     "平衡被打破，需要调和",                   "减少极端，给生活留白",                 "找到新的平衡点"),
    (15, "恶魔",     "诱惑或枷锁，外部压力",                  "认清什么是真正的束缚",                  "摆脱一个不健康的循环"),
    (16, "塔",       "突然的变动，计划外冲击",                  "快速评估损失，收拾局面",                 "看清谁真正支持你"),
    (17, "星星",     "希望，但需要时间",                      "保持信心，但不要盲目乐观",              "一个愿景开始变得具体"),
    (18, "月亮",     "迷茫或欺骗，感知不清晰",                  "不要在情绪激动时做判断",               "真相即将照亮黑暗"),
    (19, "太阳",     "顺利，开心，光明",                       "享受当下，但不要浪费",                  "一个愿望开始实现"),
    (20, "审判",     "评估或召唤，重要节点",                   "回顾过去，接受召唤",                    "一个决定影响深远"),
    (21, "世界",     "完成一个循环，成功",                     "庆祝，然后继续出发",                   "目标达成，新的可能打开"),
]

# 副标题
POSITION_LABELS = ["🔴 挑战牌", "🔵 指引牌", "🟢 祝福牌"]
ORIENTATION = ["正位", "逆位"]

def draw_cards(seed=None):
    """抽取3张不重复的牌"""
    if seed:
        random.seed(seed)
    else:
        random.seed(datetime.datetime.now().strftime("%Y%m%d"))  # 每日固定种子
    drawn = random.sample(MAJOR_ARCANA, 3)
    results = []
    for i, (num, name, challenge, guidance, blessing) in enumerate(drawn):
        orient = random.choice(ORIENTATION)
        if orient == "逆位":
            # 逆位：挑战加剧，指引模糊，祝福延迟
            challenge = "【逆位】" + challenge.replace("但", "且")
            guidance = "【逆位】" + guidance + "（需更多耐心）"
            blessing = "【逆位】" + blessing + "（时机未到）"
        results.append({
            "position": POSITION_LABELS[i],
            "name": name,
            "num": num,
            "orientation": orient,
            "challenge": challenge,
            "guidance": guidance,
            "blessing": blessing
        })
    return results

def format_tarot_section(cards):
    """格式化为夜观星风格的塔罗部分"""
    lines = ["━━━━━━━━━━━━━━━━━━", "🌙 塔罗今日指引", ""]
    for card in cards:
        lines.append(f"{card['position']} · {card['name']}（{card['orientation']}）")
        lines.append(f"  挑战：{card['challenge']}")
        lines.append(f"  指引：{card['guidance']}")
        lines.append(f"  祝福：{card['blessing']}")
        lines.append("")
    return "\n".join(lines).strip()

if __name__ == "__main__":
    cards = draw_cards()
    print(format_tarot_section(cards))
    # 输出 JSON 供脚本调用
    print(json.dumps(cards, ensure_ascii=False, indent=2))
