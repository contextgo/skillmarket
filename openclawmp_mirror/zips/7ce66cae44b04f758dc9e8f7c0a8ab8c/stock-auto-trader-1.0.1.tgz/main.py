#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动交易工具
实盘交易、条件单、持仓管理

⚠️ 风险提示：本工具涉及实盘交易，请充分了解风险后再使用！
"""

import json
import os
from pathlib import Path

import requests


class AutoTrader:
    """自动交易器"""
    
    def __init__(self, config_path=None):
        self.config = self._load_config(config_path)
        self.api_url = self.config.get('api_url', '')
        self.account = self.config.get('account', '')
        self.token = self.config.get('token', '')
    
    def _load_config(self, config_path):
        """加载配置"""
        if config_path is None:
            config_path = Path(__file__).parent / "config" / "config.json"
        
        if not os.path.exists(config_path):
            config_path = Path(__file__).parent / "config" / "sample.json"
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    
    def get_fund(self):
        """查询资金"""
        # 模拟数据，实际需要接入券商API
        print("⚠️ 注意：这是模拟数据，请配置真实券商API")
        return {
            "可用资金": 100000.00,
            "总资产": 150000.00,
            "持仓市值": 50000.00,
            "冻结资金": 0.00,
        }
    
    def get_position(self):
        """查询持仓"""
        print("⚠️ 注意：这是模拟数据，请配置真实券商API")
        return [
            {
                "代码": "000001",
                "名称": "平安银行",
                "持仓数量": 1000,
                "可用数量": 1000,
                "成本价": 10.50,
                "当前价": 11.20,
                "市值": 11200.00,
                "盈亏": 700.00,
                "盈亏率": "6.67%"
            }
        ]
    
    def buy(self, code, price, volume):
        """
        买入股票
        
        Args:
            code: 股票代码
            price: 买入价格
            volume: 买入数量
        """
        print(f"⚠️ 模拟买入：{code} {volume}股 @ {price}")
        print("注意：请配置真实券商API后再进行实盘交易")
        return {
            "order_id": "SIM" + str(hash(f"{code}{price}{volume}")),
            "code": code,
            "type": "买入",
            "price": price,
            "volume": volume,
            "status": "模拟订单"
        }
    
    def sell(self, code, price, volume):
        """
        卖出股票
        
        Args:
            code: 股票代码
            price: 卖出价格
            volume: 卖出数量
        """
        print(f"⚠️ 模拟卖出：{code} {volume}股 @ {price}")
        print("注意：请配置真实券商API后再进行实盘交易")
        return {
            "order_id": "SIM" + str(hash(f"{code}{price}{volume}")),
            "code": code,
            "type": "卖出",
            "price": price,
            "volume": volume,
            "status": "模拟订单"
        }
    
    def cancel(self, order_id):
        """
        撤单
        
        Args:
            order_id: 订单ID
        """
        print(f"⚠️ 模拟撤单：{order_id}")
        return {"status": "模拟撤单成功"}


def main():
    """CLI 入口"""
    import fire
    
    print("=" * 60)
    print("⚠️  自动交易工具 - 风险提示")
    print("=" * 60)
    print("本工具涉及实盘交易，可能导致资金损失。")
    print("请先在模拟盘充分测试，小额资金试用。")
    print("=" * 60)
    print()
    
    trader = AutoTrader()
    
    def fund():
        """查询资金"""
        result = trader.get_fund()
        for k, v in result.items():
            print(f"{k}: {v}")
    
    def position():
        """查询持仓"""
        result = trader.get_position()
        if result:
            for pos in result:
                for k, v in pos.items():
                    print(f"{k}: {v}")
                print("-" * 40)
    
    def buy(code, price, volume):
        """买入"""
        result = trader.buy(code, price, volume)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    def sell(code, price, volume):
        """卖出"""
        result = trader.sell(code, price, volume)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    def cancel(order_id):
        """撤单"""
        result = trader.cancel(order_id)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    fire.Fire({
        "fund": fund,
        "position": position,
        "buy": buy,
        "sell": sell,
        "cancel": cancel,
    })


if __name__ == "__main__":
    main()
