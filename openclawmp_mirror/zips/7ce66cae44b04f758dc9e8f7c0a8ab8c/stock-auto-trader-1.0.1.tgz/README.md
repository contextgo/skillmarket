# 自动交易 (stock-auto-trader)

自动交易 Skill，实盘自动交易、条件单、持仓管理。

## ⚠️ 风险提示

**本 Skill 涉及实盘交易，使用前请充分了解风险！**

- 自动交易可能导致资金损失
- 请先在模拟盘充分测试
- 建议小额资金试用
- 需要券商量化交易接口

## 功能

- 查询账户资金
- 查询持仓
- 下单（买入/卖出）
- 撤单
- 条件单设置

## 使用

```bash
# 查询资金
python main.py fund

# 查询持仓
python main.py position

# 买入
python main.py buy --code 000001 --price 10.5 --volume 100

# 卖出
python main.py sell --code 000001 --price 10.8 --volume 100

# 撤单
python main.py cancel --order-id 123456
```

## 配置

```json
{
  "broker": "券商名称",
  "account": "资金账号",
  "api_url": "券商API地址",
  "risk_control": {
    "max_position": 0.8,
    "max_loss_per_trade": 0.05
  }
}
```

## 依赖

- requests

## License

MIT
