# agent cron orchestration pattern

Design pattern for orchestrating multiple AI agents via cron jobs to achieve 24/7 autonomous operation. Based on real-world deployment of 6 concurrent agents (market scanner, publisher, learner, review, stock analysis, income builder) running on a single instance.

## Architecture

- **Scanner Agent** (5-min interval): Real-time market monitoring with configurable data sources
- **Builder Agent** (60-min interval): Consumes scanner signals, generates knowledge assets
- **Publisher Agent** (60-min interval): Publishes assets to marketplace platforms
- **Learner Agent** (60-min interval): Discovers and installs new capabilities
- **Review Agent** (24-hr interval): Daily health check and optimization
- **Error Recovery**: Consecutive error counting, automatic escalation, source failover

## Key Design Decisions

- Cron triggers inject system events into isolated sessions
- STATE.yaml serves as shared progress board (blackboard pattern)
- Event queue for cross-agent communication
- Batch publishing (10-20 per round) with rate limiting
- Automatic credential rotation on auth failures