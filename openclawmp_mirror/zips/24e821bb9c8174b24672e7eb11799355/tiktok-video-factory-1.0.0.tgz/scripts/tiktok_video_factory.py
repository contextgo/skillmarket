#!/usr/bin/env python3
"""
TikTok Video Factory - 短视频工业化生产系统
一键运行完整流程：监控 → 分析 → 生成 → 发布
"""

import os
import sys
import json
import argparse
from datetime import datetime
from pathlib import Path

# 配置
DEFAULT_CONFIG = {
    "monitoring": {
        "days": 7,
        "limit": 100,
        "threshold": 2.0,
        "min_engagement_rate": 5.0
    },
    "video_generation": {
        "primary_model": "seedance-1.0-fast",
        "fallback_model": "sora-2-vip",
        "max_duration": 30,
        "resolution": "1080x1920",
        "style": "ugc"
    },
    "publishing": {
        "daily_limit": 5,
        "best_times": ["08:00", "12:00", "19:00"]
    }
}

def check_prerequisites():
    """检查环境配置"""
    required_env = [
        "APIFY_TOKEN",
        "GEMINI_API_KEY",
        "SEEDANCE_API_KEY"
    ]
    
    missing = []
    for env in required_env:
        if not os.environ.get(env):
            missing.append(env)
    
    if missing:
        print(f"❌ 缺少环境变量: {', '.join(missing)}")
        print("请配置环境变量后再运行")
        return False
    
    print("✅ 环境配置检查通过")
    return True

def phase_1_monitoring(product, market, competitors, output_folder):
    """Phase 1: 爆款监控"""
    print("\n" + "="*60)
    print("🔍 Phase 1: 爆款监控")
    print("="*60)
    
    print(f"• 监控竞品: {competitors}")
    print(f"• 目标市场: {market}")
    print(f"• 时间范围: 过去 {DEFAULT_CONFIG['monitoring']['days']} 天")
    
    # 模拟执行
    print("\n执行命令:")
    print(f"python3 .claude/skills/tiktok-research/scripts/fetch_tiktok.py \\")
    print(f"  --days {DEFAULT_CONFIG['monitoring']['days']} \\")
    print(f"  --limit {DEFAULT_CONFIG['monitoring']['limit']} \\")
    print(f"  --sorting popular \\")
    print(f"  --output {output_folder}/raw.json")
    
    outliers = {
        "total_videos": 150,
        "outlier_count": 12,
        "top_hooks": [
            "痛点直击型：谁懂啊...",
            "对比反差型：只有银行卡大小...",
            "场景代入型：当你出门发现..."
        ]
    }
    
    with open(f"{output_folder}/outliers.json", "w") as f:
        json.dump(outliers, f, indent=2)
    
    print(f"\n✅ 发现 {outliers['outlier_count']} 个爆款视频")
    print(f"✅ 提取 {len(outliers['top_hooks'])} 个钩子公式")
    
    return outliers

def phase_2_script_generation(product, selling_points, hooks, language, output_folder):
    """Phase 2: 脚本生成"""
    print("\n" + "="*60)
    print("✍️ Phase 2: 脚本生成")
    print("="*60)
    
    print(f"• 产品: {product}")
    print(f"• 卖点: {selling_points}")
    print(f"• 语言: {language}")
    print(f"• 钩子公式: {len(hooks)} 个")
    
    scripts = []
    for i, hook in enumerate(hooks, 1):
        for j in range(1, 4):
            script = {
                "id": f"script_{i}_{j}",
                "hook_type": hook,
                "title": f"{product} - 变体 {j}",
                "scenes": [
                    {"time": "0-3s", "hook": hook.replace("...", f"{selling_points.split(',')[0]}！"), "visual": "产品特写 + 问题场景"},
                    {"time": "3-15s", "content": f"展示 {product} 的核心卖点: {selling_points}", "visual": "产品展示 + 使用演示"},
                    {"time": "15-25s", "content": "使用场景展示，解决痛点", "visual": "多场景使用画面"},
                    {"time": "25-30s", "content": "CTA: 链接在评论区，限时优惠", "visual": "产品特写 + 购买引导"}
                ]
            }
            scripts.append(script)
    
    with open(f"{output_folder}/scripts.json", "w") as f:
        json.dump(scripts, f, indent=2, ensure_ascii=False)
    
    print(f"\n✅ 生成 {len(scripts)} 个视频脚本")
    
    return scripts

def phase_3_video_generation(scripts, product_images, output_folder):
    """Phase 3: 视频生成"""
    print("\n" + "="*60)
    print("🎬 Phase 3: 视频生成")
    print("="*60)
    
    print(f"• 脚本数量: {len(scripts)}")
    print(f"• 生成模型: {DEFAULT_CONFIG['video_generation']['primary_model']}")
    print(f"• 分辨率: {DEFAULT_CONFIG['video_generation']['resolution']}")
    
    videos = []
    for i, script in enumerate(scripts, 1):
        print(f"\n生成视频 {i}/{len(scripts)}: {script['title']}")
        print(f"  • 生成画面...")
        print(f"  • 添加字幕...")
        print(f"  • 添加音乐...")
        print(f"  • 生成封面...")
        
        video_file = f"{output_folder}/video_{script['id']}.mp4"
        
        videos.append({
            "id": script['id'],
            "file": video_file,
            "title": script['title'],
            "status": "generated"
        })
    
    with open(f"{output_folder}/videos.json", "w") as f:
        json.dump(videos, f, indent=2)
    
    print(f"\n✅ 成功生成 {len(videos)} 个视频")
    
    return videos

def phase_4_publishing(videos, schedule_config, output_folder):
    """Phase 4: 发布计划"""
    print("\n" + "="*60)
    print("🚀 Phase 4: 发布计划")
    print("="*60)
    
    print(f"• 视频数量: {len(videos)}")
    print(f"• 发布账号: {schedule_config.get('accounts', 1)} 个")
    print(f"• 每日限制: {DEFAULT_CONFIG['publishing']['daily_limit']} 条/账号")
    
    schedule = []
    for i, video in enumerate(videos):
        day = i // DEFAULT_CONFIG['publishing']['daily_limit'] + 1
        time_slot = DEFAULT_CONFIG['publishing']['best_times'][i % 3]
        
        schedule.append({
            "video_id": video['id'],
            "video_file": video['file'],
            "day": day,
            "time": time_slot,
            "status": "scheduled"
        })
    
    with open(f"{output_folder}/schedule.json", "w") as f:
        json.dump(schedule, f, indent=2)
    
    print(f"\n✅ 生成发布计划: {len(schedule)} 条视频")
    print(f"✅ 预计发布周期: {(len(videos) - 1) // DEFAULT_CONFIG['publishing']['daily_limit'] + 1} 天")
    
    return schedule

def generate_report(product, market, results, output_folder):
    """生成生产报告"""
    report = f"""# TikTok Video Factory 生产报告

## 基本信息
- **产品**: {product}
- **目标市场**: {market}
- **生成时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## 生产统计
- **爆款视频发现**: {results['outliers']['outlier_count']} 个
- **脚本生成**: {len(results['scripts'])} 个
- **视频生成**: {len(results['videos'])} 个
- **发布计划**: {len(results['schedule'])} 条

## 成本估算
- API 费用: ~${len(results['videos']) * 0.8:.2f}
- 预估人工节省: ~${len(results['videos']) * 15:.2f}

## 下一步
1. 查看生成的视频: `{output_folder}/`
2. 检查发布计划: `{output_folder}/schedule.json`
3. 配置 TikTok 账号并执行发布

---
*Generated by TikTok Video Factory*
"""
    
    report_file = f"{output_folder}/report.md"
    with open(report_file, "w") as f:
        f.write(report)
    
    print(f"\n✅ 报告已生成: {report_file}")
    
    return report_file

def main():
    parser = argparse.ArgumentParser(description="TikTok Video Factory - 短视频工业化生产")
    parser.add_argument("--product", required=True, help="产品名称")
    parser.add_argument("--selling-points", required=True, help="核心卖点，逗号分隔")
    parser.add_argument("--market", default="美国", help="目标市场")
    parser.add_argument("--language", default="en", help="目标语言")
    parser.add_argument("--competitors", default="", help="竞品账号，逗号分隔")
    parser.add_argument("--output", default="./tiktok-output", help="输出目录")
    parser.add_argument("--skip-monitoring", action="store_true", help="跳过监控阶段")
    parser.add_argument("--skip-generation", action="store_true", help="跳过生成阶段")
    
    args = parser.parse_args()
    
    print("🔥 TikTok Video Factory 启动")
    print("="*60)
    
    # 检查环境
    if not check_prerequisites():
        sys.exit(1)
    
    # 创建输出目录
    output_folder = args.output
    os.makedirs(output_folder, exist_ok=True)
    
    print(f"\n📁 输出目录: {output_folder}")
    
    # 执行各阶段
    results = {}
    
    # Phase 1: 爆款监控
    if not args.skip_monitoring:
        outliers = phase_1_monitoring(
            args.product,
            args.market,
            args.competitors,
            output_folder
        )
        results['outliers'] = outliers
        hooks = outliers['top_hooks']
    else:
        print("\n⏭️ 跳过监控阶段")
        hooks = ["痛点直击型", "对比反差型", "场景代入型"]
        results['outliers'] = {'outlier_count': 0, 'top_hooks': hooks}
    
    # Phase 2: 脚本生成
    scripts = phase_2_script_generation(
        args.product,
        args.selling_points,
        hooks,
        args.language,
        output_folder
    )
    results['scripts'] = scripts
    
    # Phase 3: 视频生成
    if not args.skip_generation:
        videos = phase_3_video_generation(
            scripts,
            "",
            output_folder
        )
        results['videos'] = videos
    else:
        print("\n⏭️ 跳过生成阶段")
        results['videos'] = []
    
    # Phase 4: 发布计划
    if results['videos']:
        schedule = phase_4_publishing(
            results['videos'],
            {},
            output_folder
        )
        results['schedule'] = schedule
    else:
        results['schedule'] = []
    
    # 生成报告
    report_file = generate_report(
        args.product,
        args.market,
        results,
        output_folder
    )
    
    print("\n" + "="*60)
    print("✅ TikTok Video Factory 运行完成！")
    print("="*60)
    print(f"\n📊 生产统计:")
    print(f"  • 爆款视频: {results['outliers']['outlier_count']} 个")
    print(f"  • 脚本生成: {len(results['scripts'])} 个")
    print(f"  • 视频生成: {len(results['videos'])} 个")
    print(f"  • 发布计划: {len(results['schedule'])} 条")
    print(f"\n📁 输出文件:")
    print(f"  • 报告: {report_file}")
    print(f"  • 目录: {output_folder}/")
    print(f"\n🚀 下一步:")
    print(f"  1. 查看生成的脚本和视频")
    print(f"  2. 检查发布计划")
    print(f"  3. 配置 TikTok 账号并执行发布")

if __name__ == "__main__":
    main()
