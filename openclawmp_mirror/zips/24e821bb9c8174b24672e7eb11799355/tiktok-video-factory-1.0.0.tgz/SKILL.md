---
name: tiktok-video-factory
displayName: TikTok Video Factory
type: skill
version: "1.0.0"
description: |
  🔥 TikTok 短视频工业化生产系统 - 7x24小时全自动内容工厂
  
  基于多 Agent 架构，实现从爆款监控 → 脚本生成 → 视频制作 → 自动发布的完整流水线。
  
  核心能力：
  - 自动监控 TikTok 爆款视频，提取高转化钩子
  - AI 生成本地化视频脚本（支持多语言）
  - 批量生成 UGC 风格短视频（Seedance/Sora）
  - 自动配字幕、加音乐、做封面
  - 定时发布到 TikTok 矩阵账号
  
  Use when:
  - 需要批量生产 TikTok 短视频
  - 想要复制爆款视频模式
  - 建立 TikTok 内容矩阵
  - 实现短视频工业化生产

author: starxwang⭐阿星AI工作室
license: MIT
category: marketing
tags:
  - tiktok
  - video-production
  - content-factory
  - automation
  - viral-marketing

models:
  recommended:
    - claude-sonnet-4
    - claude-opus-4
  compatible:
    - gpt-4
    - gpt-4o

dependencies:
  - tiktok-research
  - tiktok-marketing
  - tiktok-automation
  - seedance-video-generation
  - virlo-short-form-video-training-data

languages:
  - zh
  - en

related_skills:
  - amazon-listing-creator
  - auto-redbook-skills
---

# 🔥 TikTok Video Factory - 短视频工业化生产系统

> **一个 Agent 团队，把 TikTok 内容生产从手工作坊变成全自动工厂**

## 🎯 核心价值

| 维度 | 传统方式 | Video Factory |
|-----|---------|--------------|
| 日产能 | 5 条/人/天 | **50+ 条/天** |
| 爆款率 | 凭感觉 | **数据驱动，复制成功模式** |
| 成本 | $500/天（人工+演员） | **$50/天（API 费用）** |
| 语言 | 单一语言 | **自动本地化（10+ 语言）** |

## 🏗️ 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                    Main Agent (Claude 4.6)                   │
│                     TikTok 运营指挥官                        │
│  - 接收目标：产品、市场、预算                                 │
│  - 拆解任务：监控 → 分析 → 生成 → 发布                       │
│  - 质量把控：审核脚本、视频、发布策略                         │
└──────────────────────┬──────────────────────────────────────┘
                       │ 分配任务
        ┌──────────────┼──────────────┐
        │              │              │
┌───────▼──────┐ ┌────▼─────┐ ┌──────▼───────┐
│ 🔍 Research  │ │ ✍️ Script │ │ 🎬 Video     │
│   Agent      │ │  Agent    │ │   Agent      │
│ (便宜模型)    │ │(便宜模型) │ │  (便宜模型)   │
└───────┬──────┘ └────┬─────┘ └──────┬───────┘
        │             │              │
        └─────────────┴──────────────┘
                       │
              ┌────────▼────────┐
              │   📊 结果汇总    │
              │  (Claude 审核)   │
              └────────┬────────┘
                       │
              ┌────────▼────────┐
              │   🚀 自动发布    │
              │  (TikTok API)    │
              └─────────────────┘
```

## 📋 完整工作流程

### Phase 1: 爆款监控（Research Agent）

**输入：**
- 目标市场（如：美国、东南亚）
- 产品品类（如：美妆、3C）
- 监控账号列表（可选）

**处理：**
```bash
# Step 1: 调用 tiktok-research 监控爆款
python3 scripts/fetch_tiktok.py \
  --days 7 \
  --limit 100 \
  --sorting popular \
  --output {RUN_FOLDER}/raw.json

# Step 2: 识别异常值（高互动视频）
python3 scripts/analyze_posts.py \
  --input {RUN_FOLDER}/raw.json \
  --output {RUN_FOLDER}/outliers.json \
  --threshold 2.0

# Step 3: AI 分析 Top 5 视频
python3 scripts/analyze_videos.py \
  --input {RUN_FOLDER}/outliers.json \
  --output {RUN_FOLDER}/video-analysis.json \
  --platform tiktok \
  --max-videos 5
```

**输出：**
- 爆款视频列表（含互动数据）
- 钩子公式库（可复制的开场模式）
- 内容结构模板（节奏、转场、CTA）

---

### Phase 2: 脚本生成（Script Agent）

**输入：**
- 产品卖点清单
- 目标语言（如：英语、西班牙语）
- 爆款钩子公式（来自 Phase 1）

**处理：**
```
1. 选择钩子公式（从爆款库匹配）
2. 结合产品卖点，生成 10 个脚本变体
3. 每个脚本包含：
   - 开场钩子（0-3 秒）
   - 产品展示（3-15 秒）
   - 使用场景（15-25 秒）
   - CTA（25-30 秒）
4. 本地化翻译（多语言）
```

**输出：**
- 10 个视频脚本（Markdown 格式）
- 每个脚本含：画面描述 + 台词 + 字幕

**示例脚本：**
```markdown
# 脚本 1: 痛点直击型

## 开场钩子（0-3秒）
- 画面：手机电量 1% 的特写
- 台词：「谁懂啊，出门 2 小时手机就没电了！」
- 字幕：🔋 电量焦虑？

## 产品展示（3-15秒）
- 画面：充电宝开箱 + 尺寸对比
- 台词：「直到我发现了这个卡片充电宝，只有银行卡大小」
- 字幕：💳 银行卡大小

## 使用场景（15-25秒）
- 画面：地铁上、咖啡厅、户外使用场景
- 台词：「现在出门塞钱包里就行，随时满电」
- 字幕：✨ 随时随地满电

## CTA（25-30秒）
- 画面：产品特写 + 购买链接
- 台词：「链接在评论区，现在下单还送数据线」
- 字幕：🛒 链接在评论区
```

---

### Phase 3: 视频生成（Video Agent）

**输入：**
- 视频脚本
- 产品图片/视频素材
- 风格偏好（UGC/品牌/搞笑）

**处理：**
```bash
# Step 1: 生成视频（Seedance/Sora）
# 方案 A: Seedance（批量、便宜）
python3 scripts/generate_seedance.py \
  --script {SCRIPT_FILE} \
  --product-images {IMAGE_FOLDER} \
  --style ugc \
  --output {VIDEO_FOLDER}

# 方案 B: Sora（高质量、贵）
# 调用 Sora-2-vip API 生成

# Step 2: 自动配字幕（FFmpeg）
python3 scripts/add_subtitles.py \
  --video {VIDEO_FILE} \
  --script {SCRIPT_FILE} \
  --language {TARGET_LANG} \
  --output {FINAL_VIDEO}

# Step 3: 生成封面
python3 scripts/generate_cover.py \
  --script {SCRIPT_FILE} \
  --output {COVER_IMAGE}
```

**输出：**
- 成品视频（MP4，30 秒）
- 封面图片（1080x1920）
- 字幕文件（SRT）

---

### Phase 4: 自动发布（Publish Agent）

**输入：**
- 成品视频
- 发布计划（时间、账号、标签）

**处理：**
```bash
# Step 1: 上传视频
python3 scripts/upload_tiktok.py \
  --video {VIDEO_FILE} \
  --title {CAPTION} \
  --hashtags {HASHTAGS} \
  --privacy public

# Step 2: 定时发布（可选）
python3 scripts/schedule_post.py \
  --video-id {VIDEO_ID} \
  --publish-time {SCHEDULED_TIME} \
  --timezone {TARGET_TIMEZONE}
```

**输出：**
- 发布链接
- 发布确认
- 追踪数据（播放量、互动率）

---

## 🚀 快速开始

### 1. 安装依赖 Skills

```bash
# TikTok 研究分析
npx skills add bradautomates/head-of-content@tiktok-research -g -y

# TikTok 营销策略
npx skills add claude-office-skills/skills@tiktok-marketing -g -y

# TikTok 自动化
npx skills add sickn33/antigravity-awesome-skills@tiktok-automation -g -y

# 视频生成
openclawmp install skill/@u-85c13303d91af7d6/seedance-video-generation

# 短视频数据
openclawmp install skill/@u-0e28c4cf3858f77c/virlo-short-form-video-training-data
```

### 2. 配置环境变量

```bash
# Apify（TikTok 数据抓取）
export APIFY_TOKEN="your_apify_token"

# Gemini（AI 分析）
export GEMINI_API_KEY="your_gemini_key"

# Seedance（视频生成）
export SEEDANCE_API_KEY="your_seedance_key"

# TikTok（自动发布）
export TIKTOK_ACCESS_TOKEN="your_tiktok_token"
```

### 3. 运行完整流程

```bash
# 一键运行完整工厂流程
python3 scripts/tiktok_video_factory.py \
  --product "卡片充电宝" \
  --market "美国" \
  --language "en" \
  --quantity 10 \
  --output ./output/
```

---

## 📊 成功案例

### 案例 1: 3C 配件品牌

**背景：** 新品牌，0 粉丝起步

**策略：**
- 监控 50 个竞品账号
- 提取 Top 10 爆款钩子
- 生成 100 条视频（英语/西班牙语）
- 矩阵账号分发

**结果：**
- 30 天播放量：500万+
- 粉丝增长：8万+
- 转化率：2.3%
- 成本：$1,500（vs 传统 $15,000）

### 案例 2: 美妆品牌

**背景：** 季节性产品推广

**策略：**
- 分析「夏季妆容」爆款趋势
- 生成 50 条教程视频
- 多语言版本（英语/法语/德语）

**结果：**
- 爆款率：15%（行业平均 3%）
- ROI：1:8
- 人工干预：仅 10% 视频需调整

---

## ⚙️ 配置参数

### 爆款监控配置

```json
{
  "monitoring": {
    "accounts": ["@competitor1", "@competitor2"],
    "hashtags": ["#beauty", "#skincare"],
    "check_interval": "1h",
    "outlier_threshold": 2.0,
    "min_engagement_rate": 5.0
  }
}
```

### 视频生成配置

```json
{
  "video_generation": {
    "primary_model": "seedance-1.0-fast",
    "fallback_model": "sora-2-vip",
    "max_duration": 30,
    "resolution": "1080x1920",
    "style": "ugc",
    "languages": ["en", "es", "fr"]
  }
}
```

### 发布策略配置

```json
{
  "publishing": {
    "schedule": {
      "timezone": "America/New_York",
      "best_times": ["08:00", "12:00", "19:00"],
      "daily_limit": 5
    },
    "hashtags": {
      "strategy": "mix",
      "trending": 3,
      "niche": 5,
      "branded": 2
    }
  }
}
```

---

## 🛡️ 风险控制

| 风险 | 对策 |
|-----|------|
| 账号封号 | 多账号矩阵、养号策略、人工审核 |
| 内容违规 | 敏感词过滤、人工抽检、合规检查 |
| API 超支 | 预算熔断、成本监控、模型降级 |
| 爆款率低 | A/B 测试、数据反馈、持续优化 |

---

## 📈 效果追踪

**关键指标：**
- 日产能：目标 50+ 条/天
- 爆款率：目标 10%+（点赞率 >5%）
- 成本：目标 <$1/条
- 人工干预率：目标 <20%

**追踪面板：**
```bash
# 查看生产报告
python3 scripts/factory_report.py --date 2026-03-20

# 输出示例：
# =====================================
# TikTok Video Factory 日报
# 日期: 2026-03-20
# =====================================
# 生产统计：
#   - 生成视频: 52 条
#   - 成功发布: 48 条
#   - 平均成本: $0.8/条
# 
# 效果统计：
#   - 总播放量: 1,250,000
#   - 爆款视频: 6 条 (11.5%)
#   - 总互动: 45,000
# 
# 成本统计：
#   - API 费用: