# MiniMax MCP Image Skill

使用 MiniMax Coding Plan MCP 的 `understand_image` 工具识别飞书消息中的图片。

## 功能

- 自动检测飞书消息中的图片附件
- 通过 MiniMax MCP 识别图片内容
- 将识别结果注入 Agent 上下文

## 前置要求

1. **安装 uvx**（已安装）
   ```bash
   curl -LsSf https://astral.sh/uv/install.sh | sh
   ```

2. **获取 MiniMax Coding Plan API Key**
   - 访问：https://platform.minimaxi.com/subscribe/coding-plan
   - 订阅并获取 API Key

## 安装 Skill

```bash
cd ~/.openclaw/skills/minimax-mcp-image
npm install
npm run build
openclaw skill install .
```

## 配置环境变量

设置 `MINIMAX_API_KEY`：

```bash
# 临时测试
export MINIMAX_API_KEY="your-api-key-here"

# 或永久添加到 ~/.openclaw/.env（如果支持）
echo "MINIMAX_API_KEY=your-api-key-here" >> ~/.openclaw/.env
```

## 使用

Skill 会自动监听飞书消息。当消息包含图片时，会调用 MCP 识别并将结果添加到上下文。

Agent 就能"看到"图片并回复相关问题。

## 调试

查看日志：
```bash
tail -f ~/.openclaw/logs/node.log | grep "[Skill]"
```

## 故障排除

- 如果看到 `uvx: command not found`，请确保 uvx 已安装并添加到 PATH
- 如果 MCP 连接失败，检查 API Key 是否有效
- 图片格式需为 JPEG、PNG、GIF、WebP，大小 ≤ 20MB

## 相关文档

- [MiniMax MCP 指南](https://platform.minimaxi.com/docs/coding-plan/mcp-guide)
- [OpenClaw Skill 开发](https://docs.openclaw.ai)