---
name: minimax-mcp-image
displayName: MiniMax MCP 图片识别
description: 使用 MiniMax Coding Plan MCP 的 understand_image 工具自动识别飞书消息中的图片
version: 0.2.0
type: skill
tags: minimax, mcp, image, feishu
---

# MiniMax MCP 图片识别

## 重要：自动执行

当飞书消息包含图片时，你**必须自动执行**以下步骤：

1. 从消息上下文中获取图片路径（飞书会自动下载图片到 `~/.openclaw/media/inbound/`）
2. 使用 Python 或 Node.js 脚本调用 MCP 识别图片
3. 将识别结果告诉用户

## MCP 调用方法

### 方法1：使用 Python 脚本（推荐）

```python
import subprocess
import json

api_key = "YOUR_API_KEY_HERE"
image_path = "~/.openclaw/media/inbound/图片文件名.png"

# 构建 MCP 请求
request = json.dumps({
    "jsonrpc": "2.0",
    "id": 1,
    "method": "tools/call",
    "params": {
        "name": "understand_image",
        "arguments": {
            "prompt": "详细描述这张图片的内容",
            "image_source": image_path
        }
    }
})

# 通过 uvx 运行 MCP
cmd = f'echo \'{request}\' | uvx minimax-coding-plan-mcp -y'
result = subprocess.run(cmd, shell=True, capture_output=True, text=True, 
                       env={"MINIMAX_API_KEY": api_key, "MINIMAX_API_HOST": "https://api.minimaxi.com"})
print(result.stdout)
```

### 方法2：使用 Node.js 脚本

```javascript
const { spawn } = require('child_process');

const apiKey = "YOUR_API_KEY_HERE";
const imagePath = "~/.openclaw/media/inbound/图片文件名.png";

const mcp = spawn('uvx', ['minimax-coding-plan-mcp', '-y'], {
  env: { ...process.env, MINIMAX_API_KEY: apiKey, MINIMAX_API_HOST: 'https://api.minimaxi.com' },
  stdio: ['pipe', 'pipe', 'pipe']
});

let output = '';
mcp.stdout.on('data', d => output += d.toString());

// 初始化 MCP
mcp.stdin.write(JSON.stringify({
  jsonrpc: '2.0', id: 1, method: 'initialize',
  params: { protocolVersion: '2024-11-05', capabilities: {}, clientInfo: { name: 'agent', version: '1.0' } }
}) + '\n');

setTimeout(() => {
  // 调用 understand_image
  mcp.stdin.write(JSON.stringify({
    jsonrpc: '2.0', id: 2, method: 'tools/call',
    params: { name: 'understand_image', arguments: { prompt: '详细描述这张图片', image_source: imagePath } }
  }) + '\n');
  
  setTimeout(() => {
    console.log(output);
    mcp.kill();
  }, 15000);
}, 3000);
```

## 关键要点

1. **图片路径**：从消息事件的 attachments 或 media 字段获取，或者查看 `~/.openclaw/media/inbound/` 目录中最新的文件
2. **API Key**：从 skill 配置中获取 `MINIMAX_API_KEY`
3. **参数名**：使用 `image_source` 而不是 `image_url`
4. **必须执行**：当消息包含图片时，不要只是说"我需要调用 MCP"，而是**立即执行**脚本获取结果

## 错误处理

如果 MCP 返回错误：
- 检查 API Key 是否正确
- 检查图片路径是否存在
- 确保使用 `image_source` 参数名
