const { MiniMaxMCPClient } = require('../src/mcp-client')

// 兼容 OpenClaw  skill 加载（可能是 require 或 import）
;(async () => {
  const mcpClient = new MiniMaxMCPClient()

  // 监听消息事件 (OpenClaw 提供 agent 对象)
  if (typeof agent !== 'undefined' && agent.on) {
    agent.on('channel.message', async (event) => {
      try {
        // 只处理飞书频道
        if (event.channel !== 'feishu') {
          return
        }

        // 检查是否有图片附件
        const attachments = event.attachments || []
        const imageAttachments = attachments.filter(a => a.type === 'image' || (a.contentType && a.contentType.startsWith('image/')))

        if (imageAttachments.length === 0) {
          return // 没有图片，跳过
        }

        console.log(`[Skill] 检测到 ${imageAttachments.length} 张图片，开始识别...`)

        // 连接 MCP
        await mcpClient.connect()

        // 处理每张图片
        const descriptions = []
        for (const attachment of imageAttachments) {
          const imagePath = attachment.path || attachment.url
          if (!imagePath) continue

          console.log(`[Skill] 识别图片: ${imagePath}`)
          try {
            const description = await mcpClient.understandImage(imagePath, '详细描述这张图片的内容')
            descriptions.push(description)
            console.log(`[Skill] 识别结果: ${description.substring(0, 100)}...`)
          } catch (error) {
            console.error(`[Skill] 图片识别失败:`, error.message)
          }
        }

        // 将识别结果注入到上下文
        if (descriptions.length > 0) {
          const contextSummary = `[图片识别结果]\n${descriptions.map((d, i) => `图片${i + 1}: ${d}`).join('\n')}`
          // 将图片描述添加到系统消息，让 Agent 能看到
          if (agent.context && agent.context.append) {
            agent.context.append('system', contextSummary)
            console.log('[Skill] 图片描述已注入上下文')
          }
        }
      } catch (error) {
        console.error('[Skill] 处理消息时出错:', error)
      }
    })

    console.log('[Skill] MiniMax MCP Image Skill 已启动，等待消息...')
  } else {
    console.error('[Skill] Agent object not found. Are you running inside OpenClaw?')
  }

  // 优雅退出
  process.on('SIGINT', async () => {
    console.log('[Skill] 正在断开 MCP 连接...')
    await mcpClient.disconnect()
    process.exit(0)
  })

  process.on('SIGTERM', async () => {
    console.log('[Skill] 正在断开 MCP 连接...')
    await mcpClient.disconnect()
    process.exit(0)
  })
})().catch(console.error)