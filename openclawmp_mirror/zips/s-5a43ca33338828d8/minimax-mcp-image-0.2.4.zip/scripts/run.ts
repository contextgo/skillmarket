import { MiniMaxMCPClient } from '../src/mcp-client.js'

// 声明全局 agent 对象（OpenClaw Skill 运行时提供）
declare const agent: any

async function main() {
  const mcpClient = new MiniMaxMCPClient()

  // 监听飞书消息事件
  agent.on('channel.message', async (event: any) => {
    try {
      // 只处理飞书频道
      if (event.channel !== 'feishu') {
        return
      }

      // 检查是否有图片附件
      const attachments: any[] = event.attachments || []
      const imageAttachments = attachments.filter((a: any) => 
        a.type === 'image' || a.contentType?.startsWith('image/')
      )

      if (imageAttachments.length === 0) {
        return // 没有图片，跳过
      }

      console.log(`[Skill] 检测到 ${imageAttachments.length} 张图片`)

      // 连接 MCP
      await mcpClient.connect()

      // 处理每张图片
      const descriptions: string[] = []
      for (const attachment of imageAttachments) {
        const imagePath = attachment.path || attachment.localPath
        if (!imagePath) continue

        console.log(`[Skill] 识别图片: ${imagePath}`)
        try {
          const description = await mcpClient.understandImage(imagePath, '详细描述这张图片的内容')
          descriptions.push(description)
        } catch (error: any) {
          console.error(`[Skill] 识别失败:`, error.message)
        }
      }

      // 将识别结果注入上下文
      if (descriptions.length > 0) {
        const summary = `[图片识别结果]\n${descriptions.map((d, i) => `${i+1}. ${d}`).join('\n')}`
        agent.context.append('system', summary)
        console.log('[Skill] 已注入图片描述到上下文')
      }
    } catch (error) {
      console.error('[Skill] 处理错误:', error)
    }
  })

  // 退出处理
  process.on('SIGINT', async () => {
    await mcpClient.disconnect()
    process.exit(0)
  })

  console.log('[Skill] MiniMax MCP Image 已启动')
}

main()
