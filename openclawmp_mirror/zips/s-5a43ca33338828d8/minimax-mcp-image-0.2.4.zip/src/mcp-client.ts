// MiniMax MCP Client - 使用 MCP SDK

import { Client } from "@modelcontextprotocol/sdk";

export class MiniMaxMCPClient {
  private client: any = null;
  private connected: boolean = false;

  async connect(): Promise<void> {
    if (this.connected) return;

    try {
      // 通过 uvx 启动 MCP 服务器
      this.client = new Client(
        {
          name: "minimax-mcp-image",
          version: "1.0.0"
        },
        {
          command: "uvx",
          args: ["minimax-coding-plan-mcp", "-y"],
          env: {
            MINIMAX_API_KEY: process.env.MINIMAX_API_KEY || '',
            MINIMAX_API_HOST: process.env.MINIMAX_API_HOST || 'https://api.minimaxi.com',
            MINIMAX_MCP_BASE_PATH: process.env.MINIMAX_MCP_BASE_PATH || '/tmp/minimax-mcp'
          }
        }
      );

      await this.client.connect();
      this.connected = true;
      console.log('[MiniMaxMCP] MCP 服务器已连接');
    } catch (error: any) {
      console.error('[MiniMaxMCP] 连接失败:', error.message);
      throw error;
    }
  }

  async understandImage(imagePath: string, prompt: string = '详细描述这张图片的内容'): Promise<string> {
    if (!this.connected) {
      await this.connect();
    }

    try {
      // 调用 MCP 的 understand_image 工具
      const result = await this.client.callTool({
        name: "understand_image",
        arguments: {
          image_url: imagePath,
          prompt: prompt
        }
      });

      // 解析结果
      if (result.content && result.content.length > 0) {
        const textContent = result.content.find((c: any) => c.type === 'text');
        if (textContent) {
          return textContent.text;
        }
      }

      return '图片识别完成';
    } catch (error: any) {
      console.error('[MiniMaxMCP] 识别失败:', error.message);
      return `识别失败: ${error.message}`;
    }
  }

  async disconnect(): Promise<void> {
    if (this.client) {
      await this.client.close();
      this.client = null;
    }
    this.connected = false;
    console.log('[MiniMaxMCP] 已断开');
  }
}
