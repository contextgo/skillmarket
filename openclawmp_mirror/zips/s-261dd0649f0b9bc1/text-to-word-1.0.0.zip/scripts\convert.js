#!/usr/bin/env node

/**
 * Text/Markdown/HTML to Word Converter
 *
 * Supports converting various input formats to Word documents (.docx)
 *
 * Usage:
 *   node convert.js input.md output.docx
 *   node convert.js https://example.com output.docx
 *   node convert.js --batch input-dir/ output-dir/
 *   node convert.js --toc input.md output.docx
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

// Check if docx is installed
let docx;
try {
  docx = require('docx');
} catch (err) {
  console.error('Error: docx module not found. Please install it first:');
  console.error('  npm install docx');
  process.exit(1);
}

// Parse command line arguments
const args = process.argv.slice(2);
const options = {
  input: null,
  output: null,
  batch: false,
  toc: false,
  encoding: 'utf8'
};

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  if (arg === '--batch') {
    options.batch = true;
  } else if (arg === '--toc') {
    options.toc = true;
  } else if (arg.startsWith('--encoding=')) {
    options.encoding = arg.split('=')[1];
  } else if (!options.input) {
    options.input = arg;
  } else if (!options.output) {
    options.output = arg;
  }
}

// Validate arguments
if (!options.input) {
  console.error('Usage: node convert.js <input> <output>');
  console.error('Options:');
  console.error('  --batch       Batch process directory');
  console.error('  --toc          Generate table of contents');
  console.error('  --encoding=<enc> Specify encoding (default: utf8)');
  console.error('');
  console.error('Examples:');
  console.error('  node convert.js input.md output.docx');
  console.error('  node convert.js https://example.com output.docx');
  console.error('  node convert.js --batch input-dir/ output-dir/');
  process.exit(1);
}

/**
 * Check if input is a URL
 */
function isURL(str) {
  return str.startsWith('http://') || str.startsWith('https://');
}

/**
 * Read file content
 */
function readFile(filePath, encoding = 'utf8') {
  try {
    return fs.readFileSync(filePath, encoding);
  } catch (err) {
    console.error(`Error reading file ${filePath}:`, err.message);
    process.exit(1);
  }
}

/**
 * Fetch web page content
 */
function fetchURL(url) {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (chunk) => {
        data += chunk;
      });
      res.on('end', () => {
        // Extract main content from HTML (simple approach)
        // Remove HTML tags and get text
        const text = data
          .replace(/<script[^>]*>[\s\S]*?<\/script>/g, '')
          .replace(/<style[^>]*>[\s\S]*?<\/style>/g, '')
          .replace(/<[^>]+>/g, '\n')
          .replace(/\n\s*\n/g, '\n')
          .replace(/^\s+|\s+$/g, '');
        resolve(text.trim());
      });
    }).on('error', (err) => {
      reject(err);
    });
  });
}

/**
 * Parse Markdown to Word elements
 */
function parseMarkdown(markdown) {
  const lines = markdown.split('\n');
  const elements = [];
  let codeBlock = null;
  let listLevel = 0;
  let inList = false;

  for (const line of lines) {
    // Code block
    if (line.trim().startsWith('```')) {
      if (codeBlock) {
        // End code block
        elements.push(new docx.Paragraph({
          text: codeBlock,
          style: 'code',
          spacing: { line: 240 }
        }));
        codeBlock = null;
      } else {
        // Start code block
        codeBlock = '';
      }
      continue;
    }

    if (codeBlock) {
      codeBlock += line + '\n';
      continue;
    }

    // Headings
    if (line.startsWith('###')) {
      listLevel = 0;
      inList = false;
      elements.push(new docx.Paragraph({
        text: line.substring(3).trim(),
        heading: docx.HeadingLevel.HEADING_3,
        spacing: { after: 200 }
      }));
    } else if (line.startsWith('##')) {
      listLevel = 0;
      inList = false;
      elements.push(new docx.Paragraph({
        text: line.substring(2).trim(),
        heading: docx.HeadingLevel.HEADING_2,
        spacing: { after: 250 }
      }));
    } else if (line.startsWith('#')) {
      listLevel = 0;
      inList = false;
      elements.push(new docx.Paragraph({
        text: line.substring(1).trim(),
        heading: docx.HeadingLevel.HEADING_1,
        spacing: { after: 300 }
      }));
    }
    // Lists
    else if (line.match(/^(\s*)([-*])\s+(.+)/)) {
      const match = line.match(/^(\s*)([-*])\s+(.+)/);
      const indent = match[1].length;
      const content = match[2];

      if (!inList) {
        listLevel = 0;
        inList = true;
      }

      // Handle nested lists
      if (indent === 0) {
        listLevel = 0;
      } else if (indent === 2) {
        listLevel = 1;
      } else if (indent === 4) {
        listLevel = 2;
      }

      elements.push(new docx.Paragraph({
        text: content,
        bullet: { level: listLevel },
        spacing: { after: 150 }
      }));
    }
    // Horizontal rule
    else if (line.match(/^---+$/)) {
      elements.push(new docx.Paragraph({
        text: '',
        border: { bottom: { style: docx.BorderStyle.SINGLE, size: 1 } }
      }));
    }
    // Regular paragraph
    else if (line.trim()) {
      listLevel = 0;
      inList = false;

      // Bold and italic
      let text = line.trim()
        .replace(/\*\*(.+?)\*\*/g, '**$1**') // Bold
        .replace(/\*(.+?)\*/g, '*$1*') // Italic
        .replace(/__(.+?)__/g, '**$1**') // Bold
        .replace(/_(.+?)_/g, '*$1*'); // Italic

      if (text) {
        elements.push(new docx.Paragraph({
          text: text,
          spacing: { after: 200 }
        }));
      }
    }
    // Empty line
    else {
      elements.push(new docx.Paragraph({ text: '', spacing: { after: 100 } }));
    }
  }

  return elements;
}

/**
 * Parse plain text to Word elements
 */
function parsePlainText(text) {
  const paragraphs = text.split(/\n\s*\n/);
  return paragraphs
    .map(p => p.trim())
    .filter(p => p)
    .map(p => new docx.Paragraph({
      text: p,
      spacing: { after: 200 }
    }));
}

/**
 * Generate Table of Contents
 */
function generateTOC(elements) {
  const tocElements = [];
  let headingNumber = [0, 0, 0]; // H1, H2, H3

  for (const el of elements) {
    if (el.heading === docx.HeadingLevel.HEADING_1) {
      headingNumber[0]++;
      headingNumber[1] = 0;
      headingNumber[2] = 0;
      tocElements.push(new docx.Paragraph({
        text: `${headingNumber[0]}. ${el.text}`,
        heading: docx.HeadingLevel.HEADING_2,
        spacing: { after: 100 }
      }));
    } else if (el.heading === docx.HeadingLevel.HEADING_2) {
      headingNumber[1]++;
      headingNumber[2] = 0;
      tocElements.push(new docx.Paragraph({
        text: `${headingNumber[0]}.${headingNumber[1]} ${el.text}`,
        spacing: { after: 100 }
      }));
    }
  }

  return tocElements;
}

/**
 * Create Word document
 */
function createDocument(elements, toc = false) {
  const docElements = [];

  // Add TOC if requested
  if (toc) {
    docElements.push(new docx.Paragraph({
      text: '目录',
      heading: docx.HeadingLevel.HEADING_1,
      spacing: { after: 200 }
    }));
    docElements.push(...generateTOC(elements));
    docElements.push(new docx.Paragraph({
      text: '',
      border: { bottom: { style: docx.BorderStyle.SINGLE, size: 1 } }
    }));
  }

  docElements.push(...elements);

  return new docx.Document({
    sections: [
      {
        properties: {},
        children: docElements
      }
    ]
  });
}

/**
 * Main conversion function
 */
async function convert(input, output, options) {
  try {
    let content;

    // Read input
    if (isURL(input)) {
      console.log(`Fetching content from URL: ${input}`);
      content = await fetchURL(input);
      console.log('Content fetched successfully');
    } else {
      console.log(`Reading file: ${input}`);
      content = readFile(input, options.encoding);
    }

    // Parse content
    let elements;

    // Detect file type
    if (input.endsWith('.md') || input.endsWith('.markdown')) {
      console.log('Detected Markdown format');
      elements = parseMarkdown(content);
    } else if (input.endsWith('.html') || input.endsWith('.htm')) {
      console.log('Detected HTML format (treating as text)');
      elements = parsePlainText(content.replace(/<[^>]+>/g, ''));
    } else {
      console.log('Detected plain text format');
      elements = parsePlainText(content);
    }

    // Create document
    console.log('Creating Word document...');
    const doc = createDocument(elements, options.toc);

    // Save file
    const outputPath = path.resolve(output);
    docx.Packer.toBuffer(doc).then((buffer) => {
      fs.writeFileSync(outputPath, buffer);
      console.log(`✓ Document created successfully: ${outputPath}`);
      console.log(`✓ Total elements: ${elements.length}`);
      if (options.toc) {
        console.log('✓ Table of contents generated');
      }
    }).catch((err) => {
      console.error('Error saving document:', err);
      process.exit(1);
    });

  } catch (err) {
    console.error('Error during conversion:', err.message);
    process.exit(1);
  }
}

/**
 * Batch conversion
 */
async function batchConvert(inputDir, outputDir, options) {
  try {
    const inputPath = path.resolve(inputDir);
    const outputPath = path.resolve(outputDir);

    // Create output directory if not exists
    if (!fs.existsSync(outputPath)) {
      fs.mkdirSync(outputPath, { recursive: true });
    }

    // Get all markdown files
    const files = fs.readdirSync(inputPath)
      .filter(f => f.endsWith('.md') || f.endsWith('.markdown') || f.endsWith('.txt'));

    if (files.length === 0) {
      console.log('No files found to convert');
      return;
    }

    console.log(`Found ${files.length} files to convert`);

    let successCount = 0;
    let failCount = 0;

    for (const file of files) {
      const inputFile = path.join(inputPath, file);
      const outputFile = path.join(outputPath, file.replace(/\.(md|markdown|txt)$/, '.docx'));

      try {
        await convert(inputFile, outputFile, { ...options, silent: true });
        successCount++;
        console.log(`✓ ${file} → ${path.basename(outputFile)}`);
      } catch (err) {
        failCount++;
        console.error(`✗ ${file}: ${err.message}`);
      }
    }

    console.log('');
    console.log('Batch conversion complete:');
    console.log(`  Total files: ${files.length}`);
    console.log(`  Success: ${successCount}`);
    console.log(`  Failed: ${failCount}`);

  } catch (err) {
    console.error('Error during batch conversion:', err.message);
    process.exit(1);
  }
}

// Main execution
(async () => {
  console.log('=== Text to Word Converter ===');
  console.log('');

  if (options.batch) {
    await batchConvert(options.input, options.output, options);
  } else {
    await convert(options.input, options.output, options);
  }

  console.log('');
  console.log('Conversion complete!');
})();
