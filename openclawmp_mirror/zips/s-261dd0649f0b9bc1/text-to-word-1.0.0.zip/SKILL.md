---
name: text-to-word
description: "Convert text, web content, and Markdown files to Word documents (.docx format)"
version: 1.0.0
---

# Text to Word Converter

将文本、网页内容、Markdown 文件等转换为 Word 文档的技能。

## 何时激活

当需要将以下格式转换为 Word 文档时激活此技能：
- 纯文本文件
- Markdown (.md) 文件
- 网页内容（URL）
- 富文本或格式化文本

## 技能描述

本技能提供通用的文档转换功能，支持：
- **Markdown 转 Word**：将 Markdown 文件转换为格式化的 Word 文档
- **纯文本转 Word**：将文本内容转换为 Word 文档
- **网页内容转 Word**：获取网页内容并转换为 Word 文档
- **批量转换**：支持批量处理多个文件

## 支持的输入格式

| 输入格式 | 文件扩展名 | 说明 |
|----------|------------|------|
| Markdown | .md, .markdown | 支持 Markdown 语法（标题、列表、表格、代码块等）|
| 纯文本 | .txt | 纯文本内容 |
| 网页 | URL | 通过 URL 获取网页内容 |
| HTML | .html | HTML 格式内容 |

## 使用方法

### 方式一：命令行调用（推荐）

**Markdown 转 Word：**
```bash
node scripts/convert.js input.md output.docx
```

**纯文本转 Word：**
```bash
node scripts/convert.js input.txt output.docx
```

**网页转 Word：**
```bash
node scripts/convert.js https://example.com output.docx
```

### 方式二：在脚本目录下直接运行

```bash
cd scripts
# 转换单个文件
node convert.js ../input.md ../output.docx

# 转换整个目录
node convert.js --batch ../markdown-files/ ../output/
```

### 方式三：通过环境变量指定输入

```bash
# 设置输入文件
export INPUT_FILE="path/to/input.md"
# 运行转换
node scripts/convert.js
```

## 功能特性

### Markdown 支持

- ✅ 标题（# H1, ## H2, ### H3）
- ✅ 列表（有序、无序）
- ✅ 粗体/斜体
- ✅ 链接和图片
- ✅ 代码块和行内代码
- ✅ 表格（基础支持）
- ✅ 引用和分隔线

### 文档格式

- 自动生成目录（可选）
- 标题层次化
- 段落间距调整
- 字体和样式统一
- UTF-8 编码支持

### 批量处理

支持批量转换目录中的所有 Markdown 文件：
```bash
node scripts/convert.js --batch ./input-dir/ ./output-dir/
```

## 配置选项

### 输出格式

支持以下输出格式：
- `.docx`（推荐）：Microsoft Word 2007+ 格式，兼容性最好
- `.doc`：旧版 Word 格式

### 样式自定义

可以在转换脚本中修改样式：
- 标题字体和大小
- 正文字体和大小
- 行间距和段间距
- 代码块背景色
- 表格边框样式

## 高级功能

### 插入目录

```bash
node scripts/convert.js --toc input.md output.docx
```

### 自定义模板

```bash
node scripts/convert.js --template custom-template.docx input.md output.docx
```

### 处理图片

自动处理 Markdown 中的图片：
- 本地图片路径
- 网络 URL 图片（会自动下载）
- 图片尺寸优化

## 错误处理

### 常见问题

**问题1：文件路径包含空格**
```bash
# 使用引号包裹路径
node scripts/convert.js "input file.md" "output file.docx"
```

**问题2：编码问题**
- 脚本默认使用 UTF-8 编码
- 如果遇到编码问题，指定编码：`--encoding gbk`

**问题3：中文乱码**
- 确保输入文件是 UTF-8 编码
- 使用 .docx 格式而不是 .doc

## 测试方法

### 单个文件测试

```bash
cd scripts
node convert.js ../test/input.md ../test/output.docx
```

### 批量测试

```bash
cd scripts
node convert.js --batch ../test-markdown/ ../test-output/
```

### 网页转换测试

```bash
cd scripts
node convert.js https://github.com ../test/webpage.docx
```

## 扩展性

如需支持更多格式：
1. 修改 `scripts/convert.js`
2. 添加新的解析器
3. 添加格式检测逻辑
4. 更新 SKILL.md 文档

## 技术实现

- **核心库**：docx（Node.js）
- **解析器**：自定义 Markdown 解析器
- **字符编码**：UTF-8
- **输出质量**：支持复杂格式（表格、图片）

## 注意事项

- ⚠️ .doc 格式兼容性较差，建议使用 .docx
- ⚠️ 复杂表格可能需要手动调整
- ⚠️ 图片会嵌入到文档中，可能增加文件大小
- ⚠️ 网页转换需要网络连接
