# Text to Word Converter

> 将文本、网页内容、Markdown 文件等转换为 Word 文档的通用工具

## 功能特性

- ✅ **多格式支持**：Markdown、纯文本、HTML、网页内容
- ✅ **批量转换**：支持批量处理整个目录
- ✅ **目录生成**：自动生成文档目录
- ✅ **格式保留**：保留标题、列表、粗体、斜体等格式
- ✅ **编码支持**：支持 UTF-8 和其他编码

## 安装

### 前置要求

```bash
npm install docx
```

### 克隆项目

```bash
git clone <repository-url>
cd text-to-word-skill
npm install
```

## 使用方法

### 基本用法

**Markdown 转 Word：**
```bash
node scripts/convert.js input.md output.docx
```

**纯文本转 Word：**
```bash
node scripts/convert.js input.txt output.docx
```

**网页转 Word：**
```bash
node scripts/convert.js https://example.com output.docx
```

### 高级用法

**生成目录：**
```bash
node scripts/convert.js --toc input.md output.docx
```

**批量转换：**
```bash
node scripts/convert.js --batch input-dir/ output-dir/
```

**指定编码：**
```bash
node scripts/convert.js --encoding gbk input.txt output.docx
```

## 支持的 Markdown 语法

| 语法 | 说明 |
|------|------|
| `# H1` | 一级标题 |
| `## H2` | 二级标题 |
| `### H3` | 三级标题 |
| `* 列表项` | 无序列表 |
| `- 列表项` | 无序列表 |
| `**粗体**` | 粗体文本 |
| `*斜体*` | 斜体文本 |
| `---` | 分隔线 |
| ` ``` 代码块 ``` ` | 代码块 |

## 示例

### 示例 1：转换 Markdown 文件

输入文件 `example.md`：
```markdown
# 标题

这是一段普通的文本。

## 二级标题

- 列表项 1
- 列表项 2

**粗体** 和 *斜体* 文本。
```

命令：
```bash
node scripts/convert.js example.md output.docx
```

### 示例 2：批量转换

```bash
# 转换整个目录的 Markdown 文件
node scripts/convert.js --batch ./markdown-files/ ./output-docx/
```

### 示例 3：网页转 Word

```bash
# 将网页内容转换为 Word 文档
node scripts/convert.js https://github.com webpage.docx
```

## 文件结构

```
text-to-word-skill/
├── SKILL.md           # OpenClaw 技能说明
├── README.md          # 项目说明
├── package.json       # 项目配置
├── scripts/
│   └── convert.js  # 主转换脚本
└── tests/
    └── test.md       # 测试文件
```

## 测试

### 运行测试

```bash
# 单个文件测试
node scripts/convert.js tests/test.md test-output.docx

# 批量转换测试
node scripts/convert.js --batch tests/ test-output/
```

### 验证输出

使用 Microsoft Word 或 WPS 打开生成的 .docx 文件，验证：
- 格式是否正确
- 中文是否显示正常
- 标题层次是否正确
- 列表是否正确显示

## 故障排除

### 问题：docx 模块未找到

**错误信息：**
```
Error: docx module not found. Please install it first:
  npm install docx
```

**解决方案：**
```bash
npm install docx
```

### 问题：中文乱码

**可能原因：**
1. 输入文件不是 UTF-8 编码
2. 使用了错误的编码参数

**解决方案：**
```bash
# 确保输入文件是 UTF-8 编码
# 使用 --encoding 参数指定正确编码
node scripts/convert.js --encoding utf8 input.md output.docx
```

### 问题：文件路径包含空格

**解决方案：**
```bash
# 使用引号包裹路径
node scripts/convert.js "input file.md" "output file.docx"
```

## 技术实现

- **核心库**：[docx](https://www.npmjs.com/package/docx)
- **Node.js 版本**：>= 14.0.0
- **编码**：UTF-8（默认）

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！

---

**作者**：小7
**版本**：1.0.0
