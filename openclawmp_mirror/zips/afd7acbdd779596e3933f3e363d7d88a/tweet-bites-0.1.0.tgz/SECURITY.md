# Security Policy

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 0.1.x   | ✅ (current)       |

## Reporting a Vulnerability

This skill uses Twitter cookies stored locally. Follow these best practices:

1. **Never commit `cookies.json`** — It's in `.gitignore`. If accidentally committed, revoke Twitter session immediately.
2. **Rotate cookies periodically** — Twitter sessions expire; re-authenticate every few weeks.
3. **Email credentials** — If using SMTP, store passwords in environment variables, not in `email.json`. Example:
   ```json
   {
     "smtp": {
       "password_env": "SMTP_PASSWORD"
     }
   }
   ```
4. **Report issues** — Open an issue on GitHub or contact the maintainer.

## Data Handling

- All scraped tweet data is stored locally in `output/`
- No data is sent to third parties except your configured email/SMTP server
- The skill does not retain Twitter credentials beyond what x-cli needs
- You are responsible for complying with Twitter's Terms of Service

---

*Last updated: 2026-03-09*