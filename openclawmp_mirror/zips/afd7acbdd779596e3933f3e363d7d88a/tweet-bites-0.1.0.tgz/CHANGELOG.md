# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.0] - 2026-03-09

### Added
- Initial release
- Fetch corporate Twitter/X accounts with date range filtering
- Generate editorial Markdown reports with engagement ranking
- Email delivery via mailx or SMTP
- Tiered company monitoring (tier1/tier2/tier3)
- OpenClaw natural language integration
- CLI pipeline: `run.py` orchestrates fetch → generate → send
- Configurable via `config/companies.json` and `config/email.json`

### Technical
- Python 3.11+ scripts
- Depends on x-cli (twikit) for Twitter access
- No API key required (uses cookies)
- Rate-limit aware (adjustable per-company count)

---

## [Planned] - Future

- Keyword-based filtering and alerting
- Sentiment analysis per company
- Historical trend charts
- Multi-language abstracts (English/Chinese)
- Dashboard UI (Web)
- Slack/Discord/Telegram webhooks
- Database backend (SQLite/Postgres)
