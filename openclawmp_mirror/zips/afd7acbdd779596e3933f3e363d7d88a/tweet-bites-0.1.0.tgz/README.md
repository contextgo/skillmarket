# Tweet Bites 🍪

> 来自 Twitter/X 的公司新闻摘要，由 AI agent  curation。

**版本:** 0.1.0  
**兼容性:** OpenClaw v0.3+  
**许可证:** MIT  
**依赖:** x-cli (twikit==2.3.3)

---

## 🚀 快速开始

### 前置条件

1. **安装并认证 x-cli**
   ```bash
   git clone https://github.com/your-org/x-cli.git ~/.openclaw/workspace/skills/x-cli
   cd ~/.openclaw/workspace/skills/x-cli
   uv venv && source .venv/bin/activate
   uv pip install twikit==2.3.3
   ```
   然后配置 `cookies.json`（从浏览器导出 Twitter 登录 cookies）

2. **Python 3.11+**（推荐 uv 或 pip）
3. **Unix 环境**（macOS/Linux），有 `mailx` 命令用于发邮件（或用 SMTP）
4. **OpenClaw agent**（自然语言触发支持）

### 安装 Skill

```bash
# 方式 1: 直接复制文件夹
cp -r tweet-bites ~/.openclaw/workspace/skills/

# 方式 2: 通过 ClawHub/水产市场
openclawmp install tweet-bites
# 或
clawhub install tweet-bites
```

### 配置

1. **编辑监控公司列表** `config/companies.json`
   ```json
   {
     "tier1": ["OpenAI", "GoogleAI", "AnthropicAI", "xai", "MetaAI", "TencentAI_News"],
     "tier2": ["MistralAI", "Cohere", "HuggingFace"],
     "tier3": ["NotionHQ", "GitHub"]
   }
   ```

2. **配置收件人** `config/email.json`
   ```json
   {
     "send_email": true,
     "method": "mailx",
     "recipients": ["your@email.com"],
     "subject_prefix": "[Tweet Bites]"
   }
   ```

---

## 📊 功能亮点

- ✅ **无需 API Key** — 基于 x-cli + Twitter cookies
- ✅ **自动编辑洞察** — 生成战略趋势分析
- ✅ **分层监控** — Tier 1/2/3 过滤噪音
- ✅ **邮件推送** — 支持 mailx 或 SMTP
- ✅ **OpenClaw 集成** — 自然语言触发
- ✅ **开箱即用** — 21 家公司预设，即装即跑

---

## 🏗️ 项目结构

```
tweet-bites/
├── SKILL.md               # OpenClaw skill 元数据（含 frontmatter）
├── README.md              # 本文档
├── skill.json             # ClawHub 元数据
├── CHANGELOG.md           # 版本历史
├── SECURITY.md            # 安全策略
├── install.sh             # 一键安装脚本
├── config/
│   ├── companies.json    # 监控公司列表（可编辑）
│   └── email.json        # 邮件配置（可编辑）
├── scripts/
│   ├── fetch_corps.py    # 抓取推文
│   ├── generate_report.py# 生成报告
│   ├── send_report.py    # 发送邮件
│   └── run.py            # 主入口
└── output/               # 运行输出（自动生成）
```

---

## 📋 使用方法

### 命令行直接运行

```bash
# 抓取上周数据并发送邮件报告
python scripts/run.py last_week you@example.com

# 指定日期范围
python scripts/run.py 2026-03-01:2026-03-08

# 仅抓取（调试用）
python scripts/fetch_corps.py last_week

# 列出现有公司
python scripts/run.py list_companies
```

### 通过 OpenClaw 触发（推荐）

安装后，用自然语言唤醒：

- "抓取上周大公司动态并生成周报"
- "创建本周 AI 公司动态报告发到我邮箱"
- "列出所有监控的公司"
- "测试 Twitter 连接"

---

## 📈 报告示例

```markdown
# 🏢 大公司动态周报 (2026-03-09)

## 📈 执行摘要
- 监控公司总数: 17 家
- 有效推文总数: 31 条

### 🎯 核心发现
1. **Anthropic 深耕安全场景**: 与 Mozilla 合作发现 22 个 Firefox 高危漏洞
2. **xAI 垂直整合**: 1.2GW 电力设施建设
3. **Google 主打性价比**: Gemini 3.1 Flash-Lite 发布

## 🔥 Top 5 重磅动态
1. [OpenAI] GPT-5.4 发布 (31K likes)
2. [AnthropicAI] Claude 发现 22 个漏洞 (14K likes)
...
```

---

## ⚙️ 配置选项

### 调整抓取数量

编辑 `scripts/fetch_corps.py`，修改 `count=50` 为其他值（根据 rate limit 调整）。

### 更换报告模板

编辑 `scripts/generate_report.py` 的 `generate_report()` 函数，Markdown 结构可自由定制。

### 定时任务 (Cron)

```bash
# crontab -e
# 每周一早上 8:00 自动生成上周报告
0 8 * * 1 cd ~/.openclaw/workspace/skills/tweet-bites && python scripts/run.py last_week you@example.com
```

---

## 🛠️ 支持的动作 (Actions)

| 动作 | 说明 | 参数 |
|------|------|------|
| `generate_report` | 完整流程（抓取→生成→发送） | `date_range`, `companies?`, `send_email?` |
| `fetch` | 仅抓取 Twitter 数据 | `date_range`, `companies?` |
| `generate` | 从现有数据生成报告 | `input_dir`, `output_path?` |
| `send_email` | 邮件发送 | `report_path`, `recipient?` |
| `list_companies` | 打印公司列表 | 无 |
| `test_connection` | 测试 x-cli 连接 | 无 |

---

## ❓ 常见问题

### Q: 出现 404 错误？
A: 某些公司 handle 可能不正确或账号已停用。检查 `config/companies.json` 并移除无效条目。

### Q: 认证错误？
A: 重新登录 Twitter，更新 `x-cli/cookies.json`（ cookies 会过期，需定期刷新）。

### Q: 邮件发送失败？
A: 确保系统有 `mailx`（macOS: `brew install heirloom-mailx`；Linux: `apt install mailutils`）。或者配置 SMTP。

### Q: 抓不到推文？
A: 日期范围可能太窄，或该公司上周确实没发推。扩大范围或手动验证账号。

### Q: 运行卡住？
A: 可能是网络超时或被限流。降低 `--count`，或在 `fetch_corps.py` 中加入延迟。

---

## 📦 发布信息

- **Skill Slug**: `tweet-bites`
- **Display Name**: `Tweet Bites 🍪`
- **Asset ID**: `s-5fe014acddad3ed1`
- **Marketplace**: https://openclawmp.cc/asset/s-5fe014acddad3ed1

---

## 📜 许可证

MIT — 自由使用、修改、分发。

---

## 🙏 致谢

- 基于 OpenClaw 生态构建
- Twitter 数据抓取使用 [twikit](https://github.com/encode42/twikit)
- 报告生成参考行业新闻简报格式

---

**版本:** 0.1.0 | 最后更新: 2026-03-09
