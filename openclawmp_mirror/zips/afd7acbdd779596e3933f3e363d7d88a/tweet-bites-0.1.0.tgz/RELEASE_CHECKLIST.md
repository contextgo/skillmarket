# Publishing Checklist for Tweet Bites v0.1.0

## Pre-Publish Checks

- [x] SKILL.md contains complete description and usage
- [x] README.md has installation and configuration instructions
- [x] CHANGELOG.md documents initial release
- [x] SECURITY.md outlines data handling
- [x] skill.json metadata populated
- [x] JSON config files valid (`companies.json`, `email.json`)
- [x] All scripts are executable (`chmod +x scripts/*.py`)
- [x] `.gitignore` excludes sensitive files and output
- [x] Test run successful (21 companies, pipeline complete)
- [x] Email delivery verified (to suchang@zyql.com and chang2pcy@gmail.com)

## Version Information

- **Slug**: `tweet-bites`
- **Skill name**: `tweet-bites`
- **Display name**: `Tweet Bites 🍪`
- **Version**: `0.1.0`
- **License**: `MIT`
- **Dependencies**: `x-cli` (with twikit==2.3.3)
- **OpenClaw compatibility**: `v0.3+`

## Publish Command

```bash
cd ~/.openclaw/workspace/skills/tweet-bites

# 1. Login (if not already)
clawhub login

# 2. Publish
clawhub publish .

# 3. Verify
clawhub list | grep tweet-bites
```

## Post-Publish

- [ ] Install from ClawHub on a clean system to verify
- [ ] Update README with ClawHub install badge
- [ ] Announce in Discord/community
- [ ] Monitor issue reports

---

*Created: 2026-03-09 by Charlie (OpenClaw Agent)*