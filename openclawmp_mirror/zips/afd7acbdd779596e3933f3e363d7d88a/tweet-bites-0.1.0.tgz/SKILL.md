---
name: tweet-bites
displayName: Tweet Bites
description: "从 Twitter/X 自动抓取 AI 公司官方推文，生成带战略洞察的周报并邮件发送。"
version: 0.1.1
type: skill
tags: twitter, monitor, report, ai-companies, news-aggregator, corporate-intelligence, assistant_friendly
---

# Tweet Bites 🍪

> Bite-sized corporate news from Twitter/X, curated by an AI agent.

## 🚀 Quick Start

### Prerequisites

1. **x-cli** installed and authenticated
   ```bash
   git clone https://github.com/your-org/x-cli.git ~/.openclaw/workspace/skills/x-cli
   cd ~/.openclaw/workspace/skills/x-cli
   uv venv && source .venv/bin/activate
   uv pip install twikit==2.3.3
   ```
   Then configure `cookies.json` with valid Twitter session cookies.

2. **Python 3.11+** with `uv` or `pip`
3. **Unix environment** with `mailx` (for email) or SMTP configuration
4. **OpenClaw** agent (for NLP triggering)

### Install Skill

```bash
# Clone or copy this skill directory
cp -r tweet-bites ~/.openclaw/workspace/skills/
# or
clawhub install tweet-bites
```

---

## 📋 Features

- ✅ **No API key required** — Uses x-cli with Twitter cookies
- ✅ **Editorial insights** — Auto-generated strategic analysis
- ✅ **Tiered monitoring** — Focus on top-tier companies, filter noise
- ✅ **Email delivery** — Plain text or SMTP HTML
- ✅ **OpenClaw integration** — Natural language triggers
- ✅ **Extensible** — Easy to add custom analysis modules

---

## 🏗️ Project Structure

```
tweet-bites/
├── SKILL.md              # This file (with frontmatter)
├── README.md             # Full documentation
├── skill.json            # ClawHub metadata (optional)
├── config/
│   ├── companies.json   # Monitored company handles (edit this)
│   └── email.json       # Email configuration (edit this)
├── scripts/
│   ├── fetch_corps.py   # Scrape Twitter via x-cli
│   ├── generate_report.py   # Generate Markdown report
│   ├── send_report.py   # Email delivery
│   └── run.py           # Main pipeline entry
└── output/              # Generated data (runtime)
```

---

## ⚙️ Configuration

### Customize Monitored Companies

Edit `config/companies.json`:

```json
{
  "description": "Corporate Twitter handles by monitoring priority",
  "tier1": [
    "OpenAI", "GoogleAI", "AnthropicAI", "xai", "MetaAI",
    "TencentAI_News", "Kimi_Moonshot", "Microsoft"
  ],
  "tier2": [
    "MistralAI", "Cohere", "HuggingFace", "Replicate",
    "StepFun", "01AI", "AlephAlpha", "StabilityAI"
  ],
  "tier3": [
    "NotionHQ", "GitHub", "Slack", "Discord", "RunwayML"
  ]
}
```

**Note:** Company handles must be exact Twitter usernames (case-insensitive). Some handles may be inactive or protected.

### Email Settings (optional)

Edit `config/email.json`:

```json
{
  "send_email": true,
  "method": "mailx",    // or "smtp"
  "recipients": ["you@example.com"],
  "subject_prefix": "[OpenClaw] Tweet Bites"
}
```

For `smtp` method, fill `smtp` block with host, port, username, password, TLS settings.

---

## 📊 Report Example

```markdown
# 🏢 大公司动态周报 (2026-03-09)

## 📈 执行摘要
- 监控公司总数: 17 家
- 有效推文总数: 31 条

### 🎯 核心发现
1. **Anthropic 深耕安全场景**: 与 Mozilla 合作发现 22 个 Firefox 高危漏洞
2. **xAI 垂直整合**: 1.2GW 电力设施建设
3. **Google 主打性价比**: Gemini 3.1 Flash-Lite 发布

## 🔥 Top 5 重磅动态
1. [Midjourney] you can still use all our old models... (1.3K likes)
2. [NotionHQ] @MiniMax_AI 🤝 (23 likes)
...
```

---

## 🔧 Usage

### Direct Execution

```bash
# Generate last week's report and email it
python scripts/run.py last_week you@example.com

# Custom date range
python scripts/run.py 2026-03-01:2026-03-08

# Fetch only (for debugging)
python scripts/fetch_corps.py last_week | head -20
```

### Natural Language Triggers (OpenClaw)

Once installed, trigger with phrases like:

- "抓取上周大公司动态并生成周报"
- "创建本周 AI 公司动态报告发到我邮箱"
- "列出所有监控的公司"
- "测试 Twitter 连接"

---

## Supported Actions

| Action | Description | Parameters |
|--------|-------------|------------|
| `generate_report` | Full pipeline (fetch→generate→email) | `date_range`, `companies?`, `send_email?` |
| `fetch` | Scrape Twitter only | `date_range`, `companies?` |
| `generate` | Create report from existing data | `input_dir`, `output_path?` |
| `send_email` | Deliver report via email | `report_path`, `recipient?` |
| `list_companies` | Print configured company tiers | none |
| `test_connection` | Verify x-cli and Twitter auth | none |

---

## Requirements & Limitations

- **Twitter Rate Limits**: x-cli uses twikit; excessive requests may trigger limits. Adjust `--count` per company in `scripts/fetch_corps.py` (default 50).
- **Account Access**: Requires valid Twitter cookies (no API key). Cookies expire; re-authenticate periodically.
- **Company Coverage**: Some official accounts are inactive (e.g., MetaAI, Microsoft). Chinese companies prefer Weibo; X coverage may be sparse.
- **Date Range**: `x_search.py` supports Twitter's `since:` and `until:` operators (max ~7 days for full results). Longer ranges may miss older tweets.
- **Email**: Requires `mailx` (BSD/macOS) or `mutt` (Linux) for attachment-free sending. For richer formatting, configure SMTP with HTML.

---

## Troubleshooting

| Issue | Diagnosis | Fix |
|-------|-----------|-----|
| 404 Not Found errors | Handle incorrect or account doesn't exist | Remove/revise entry in `config/companies.json` |
| Authentication errors | Invalid/expired cookies | Re-login to Twitter, update `x-cli/cookies.json` |
| Email not sending | No `mailx` or misconfigured | Install `mailx` or enable SMTP in `config/email.json` |
| No tweets fetched | Date range too narrow or account silent | Extend date range, verify account manually on X.com |
| Script hangs | Network timeout or rate limit | Reduce `--count`, add delays |

---

## Customization

### Change Report Template

Edit `scripts/generate_report.py` function `generate_report()`.

### Add Analytics

Track trends over time by storing each day's `output/corp-YYYY-MM-DD/` directory and creating weekly/monthly aggregators.

### Daily Cron Job

```bash
# crontab -e
0 8 * * 1  cd ~/.openclaw/workspace/skills/tweet-bites && python scripts/run.py this_week you@example.com
```

---

## Future Enhancements

- [ ] Keyword-based filtering and alerting
- [ ] Sentiment analysis per company
- [ ] Comparative dashboard (HTML)
- [ ] Multi-language abstracts (中文/English)
- [ ] Database storage (SQLite) for historical queries
- [ ] Webhook notifications (Slack/Discord/Telegram)

---

## License

MIT. Feel free to fork, modify, and redistribute.

---

## Support

- Issues: https://github.com/your-org/tweet-bites/issues
- OpenClaw: `clawhub install tweet-bites` (when published)
- Version: 0.1.0 (Initial release)

---

*Built with OpenClaw · Python 3.11 · x-cli · twikit*
