# ✅ Tweet Bites 🍪 — Ready for ClawHub Publishing

**Skill Path:** `/Users/jyxc-dz-0100132/.openclaw/workspace/skills/tweet-bites`

---

## 📦 文件清单 (已验证)

```
tweet-bites/
├── SKILL.md                   ✅ OpenClaw skill metadata
├── README.md                  ✅ User documentation (4700+ words)
├── skill.json                 ✅ ClawHub metadata (slug: tweet-bites)
├── CHANGELOG.md               ✅ Version history
├── SECURITY.md                ✅ Security policy
├── RELEASE_CHECKLIST.md      ✅ Publishing checklist
├── CLawHUB_PUBLISH_GUIDE.md  ✅ Publishing guide (this)
├── install.sh                 ✅ Installer script (executable)
├── __init__.py                ✅ Package marker
├── config/
│   ├── companies.json        ✅ Monitored companies (21 handles)
│   └── email.json            ✅ Email config template
├── scripts/
│   ├── fetch_corps.py        ✅ Scraper (x-cli wrapper)
│   ├── generate_report.py    ✅ Report generator
│   ├── send_report.py        ✅ Email sender
│   └── run.py                ✅ Main pipeline
└── output/                    ✅ Empty (runtime generated, not included)
```

---

## 🎯 发布表单填写 (openclawmp.cc)

| Field | Value |
|-------|-------|
| **Slug** | `tweet-bites` |
| **Skill name** | `tweet-bites` |
| **Display name** | `Tweet Bites 🍪` |
| **Version** | `0.1.0` |
| **License** | `MIT` |
| **Description** (short) | Bite-sized corporate news from Twitter/X, curated by an AI agent. |
| **Summary** (long) | Automated monitoring and editorial reporting for corporate AI/tech Twitter/X accounts. Scrape official company handles, analyze engagement, generate strategic insights, and email reports. Use when user asks for company news, weekly digests, or competitive intelligence. |
| **Tags** | `twitter`, `monitor`, `report`, `ai-companies`, `news-aggregator`, `corporate-intelligence`, `assistant_friendly` |
| **Dependencies** | `x-cli (with twikit==2.3.3)`<br>Python 3.11+, Unix environment (mailx) |
| **OpenClaw Min Version** | `0.3.0` |
| **Skill Type** | `assistant_friendly` |
| **Decision** | `keep` |

---

## 🚀 发布步骤

### Option A: Using ClawHub CLI (推荐)

```bash
# 1. Login (opens browser)
clawhub login

# 2. Navigate to skill directory
cd ~/.openclaw/workspace/skills/tweet-bites

# 3. Publish
clawhub publish .

# 4. Verify
clawhub list | grep tweet-bites
```

### Option B: Web Upload (openclawmp.cc)

1. Go to https://openclawmp.cc/explore
2. Click "Publish" or "Upload Skill"
3. Fill the form using the values above
4. Upload the entire `tweet-bites/` folder as ZIP or select folder
5. Submit and wait for validation

---

## 📸 所需截图 (可选但推荐)

- **Report sample**: `output/` is empty, but you can run `python scripts/run.py last_week test@example.com` to generate one, then screenshot the email/report.
- **Pipeline demo**: Terminal output showing fetch → generate → send.
- **Config editing**: Show `config/companies.json` snippet.

---

## 🧪 验证安装（发布后）

```bash
# Install from ClawHub
clawhub install tweet-bites

# Test (dry-run without email)
python ~/.openclaw/workspace/skills/tweet-bites/scripts/run.py last_week

# Or trigger via OpenClaw NLP:
# "抓取上周大公司动态并生成周报"
```

---

## ⚠️ 注意事项

1. **x-cli prerequisite**: Users must install and authenticate x-cli first. Document this clearly in README (✅ done).
2. **Cookies expiration**: Mention in docs that cookies need periodic renewal.
3. **Output directory**: `output/` will be created on first run; it's gitignored locally but can be empty in the package.
4. **Email method**: Default is `mailx`; if unavailable, user must configure SMTP in `config/email.json`.
5. **Rate limits**: Default `--count` per company is 50; adjust if hitting limits.

---

## 📊 Expected Behavior

- **Fetch**: 21 companies, each returns 0-10 tweets for a 3-day window (depending on activity).
- **Generate**: Report includes top 5 tweets, company ranking, editorial insights.
- **Email**: Sent via `mailx` if configured; subject contains "Tweet Bites".

---

## 🔄 Post-Publish Checklist

- [ ] Publish succeeds without validation errors
- [ ] Skill appears in explore search ("tweet bites")
- [ ] Skill page displays description and tags correctly
- [ ] Install command works on a clean OpenClaw instance
- [ ] Pipeline runs end-to-end on a fresh install (with x-cli set up)
- [ ] README renders properly on ClawHub (check badges, code blocks)

---

## 🎉 Done!

**Tweet Bites** is ready to be published to openclawmp.cc.

*Questions? Check README.md or open an issue.*
