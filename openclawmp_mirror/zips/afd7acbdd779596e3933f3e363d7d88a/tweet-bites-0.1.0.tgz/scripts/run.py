#!/usr/bin/env python3
"""
Main entrypoint: fetch + generate + optional email.
Usage: python run.py last_week [recipient_email]
"""

import sys
import os
import subprocess
import json

SCRIPTS_DIR = os.path.dirname(__file__)
OUTPUT_ROOT = os.path.join(SCRIPTS_DIR, "..", "output")

def load_config():
    config_path = os.path.join(SCRIPTS_DIR, "..", "config", "email.json")
    if os.path.exists(config_path):
        with open(config_path) as f:
            return json.load(f)
    return {"send_email": False, "recipients": []}

def run_pipeline(date_range, recipient=None):
    """Run full pipeline."""
    print(f"🚀 Starting Corp Twitter Monitor: {date_range}")

    # 1. Fetch
    print("\n📥 Step 1: Fetching tweets...")
    fetch_cmd = [os.path.join(SCRIPTS_DIR, "fetch_corps.py"), date_range]
    result = subprocess.run(fetch_cmd, capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"[ERROR] Fetch failed: {result.stderr}")
        sys.exit(1)

    # Determine output dir (last line should contain path)
    output_dir = None
    for line in reversed(result.stdout.split("\n")):
        if "Output:" in line:
            output_dir = line.split("Output:")[1].strip()
            break
    if not output_dir:
        output_dir = os.path.join(OUTPUT_ROOT, f"corp-{date_range}")

    # 2. Generate
    print("\n📊 Step 2: Generating report...")
    report_cmd = [os.path.join(SCRIPTS_DIR, "generate_report.py"), output_dir]
    result = subprocess.run(report_cmd, capture_output=True, text=True)
    print(result.stdout)
    if result.returncode != 0:
        print(f"[ERROR] Generate failed: {result.stderr}")
        sys.exit(1)

    # Get report path (last line)
    report_path = None
    for line in reversed(result.stdout.split("\n")):
        if "Report generated:" in line:
            report_path = line.split("Report generated:")[1].strip()
            break
    if not report_path:
        report_path = os.path.join(OUTPUT_ROOT, f"corp-report-{date_range}.md")

    # 3. Email (optional)
    config = load_config()
    send_to = recipient or config.get("recipients", [None])[0]

    if send_to:
        print(f"\n📧 Step 3: Sending email to {send_to}...")
        send_cmd = [os.path.join(SCRIPTS_DIR, "send_report.py"), report_path, send_to]
        result = subprocess.run(send_cmd, capture_output=True, text=True)
        print(result.stdout)
        if result.returncode != 0:
            print(f"[WARN] Email failed: {result.stderr}")
    else:
        print("\n📭 Email skipped (no recipient)")

    print(f"\n✅ Pipeline complete! Report at: {report_path}")

def main():
    if len(sys.argv) < 2:
        print("Usage: python run.py <date_range> [recipient_email]")
        print("Examples:")
        print("  python run.py last_week suchang@zyql.com")
        print("  python run.py 2026-03-01:2026-03-08")
        sys.exit(1)

    date_range = sys.argv[1]
    recipient = sys.argv[2] if len(sys.argv) > 2 else None

    run_pipeline(date_range, recipient)

if __name__ == "__main__":
    main()
