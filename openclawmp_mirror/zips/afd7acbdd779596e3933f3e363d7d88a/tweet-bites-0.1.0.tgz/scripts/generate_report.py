#!/usr/bin/env python3
"""
Generate editorial weekly/daily report from fetched Twitter data.
Usage: python generate_report.py <corp_data_dir> [output_path]
"""

import sys
import os
import json
from datetime import datetime

def load_tweets(data_dir):
    """Load all JSON files from data_dir."""
    tweets = []
    for fname in os.listdir(data_dir):
        if not fname.endswith(".json"):
            continue
        fpath = os.path.join(data_dir, fname)
        if os.path.getsize(fpath) == 0:
            continue
        corp_name = fname.replace(".json", "")
        try:
            with open(fpath) as f:
                lines = [l.strip() for l in f if l.strip()]
                for line in lines:
                    t = json.loads(line)
                    t["_corp"] = corp_name
                    tweets.append(t)
        except Exception as e:
            print(f"[WARN] Skipping {fname}: {e}")
    return tweets

def calculate_engagement(tweet):
    """Compute engagement score."""
    likes = tweet.get("favorite_count", 0) or 0
    rts = tweet.get("retweet_count", 0) or 0
    return likes + rts

def detect_topic(text):
    """Simple topic detection from text."""
    text = text.lower()
    if "gpt" in text or "5.4" in text:
        return "GPT系列发布"
    if "gemini" in text:
        return "Gemini产品"
    if "claude" in text or "security" in text or "vulnerability" in text:
        return "安全/漏洞"
    if "openclaw" in text:
        return "OpenClaw生态"
    if "power" in text or "energy" in text or "plant" in text:
        return "能源基建"
    return "综合动态"

def generate_report(tweets, output_path=None):
    """Generate markdown report."""
    if not tweets:
        print("[ERROR] No tweets to report")
        return None

    # Add engagement scores
    for t in tweets:
        t["_engagement"] = calculate_engagement(t)

    # Sort by engagement
    tweets.sort(key=lambda x: x["_engagement"], reverse=True)

    # Company summary
    corp_counts = {}
    corp_tweets = {}
    for t in tweets:
        corp = t["_corp"]
        corp_counts[corp] = corp_counts.get(corp, 0) + 1
        corp_tweets.setdefault(corp, []).append(t)

    corp_summary = []
    for corp, cnt in sorted(corp_counts.items(), key=lambda x: -x[1]):
        top_eng = max(t["_engagement"] for t in corp_tweets[corp])
        corp_summary.append({
            "name": corp,
            "count": cnt,
            "top_engagement": top_eng,
            "tweets": corp_tweets[corp]
        })

    # Sort companies by top engagement for detailed section
    corp_summary.sort(key=lambda x: -x["top_engagement"])

    # Build markdown
    md = []
    date_str = datetime.now().strftime("%Y-%m-%d")
    md.append(f"# 🏢 大公司动态周报 ({date_str})")
    md.append(f"📅 报告生成: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    md.append("")

    md.append("## 📈 执行摘要")
    md.append(f"- 监控公司总数: **{len(corp_summary)} 家**")
    md.append(f"- 有效推文总数: **{len(tweets)} 条**")
    md.append("")

    # Core findings (auto-generated)
    md.append("### 🎯 核心发现")
    findings = []
    if any("openai" in t["_corp"].lower() for t in tweets[:10]):
        findings.append("OpenAI 持续发布新模型/产品（关注 GPT 系列）")
    if any("tencent" in t["_corp"].lower() for t in tweets):
        findings.append("腾讯 OpenClaw 生态扩张（QQ 接入 + 云支持）")
    if any("anthropic" in t["_corp"].lower() for t in tweets):
        findings.append("Anthropic 深耕安全场景（漏洞扫描合作）")
    if any("xai" in t["_corp"].lower() for t in tweets):
        findings.append("xAI 垂直整合（能源基建投资）")
    if any("google" in t["_corp"].lower() for t in tweets):
        findings.append("Google 主打性价比（Flash-Lite 系列）")

    if not findings:
        findings = ["本周无显著主题（数据量较少）"]

    for i, f in enumerate(findings, 1):
        md.append(f"{i}. **{f.split('（')[0]}**: {f}")
    md.append("")

    # Company ranking table
    md.append("## 🏆 公司活跃度排行")
    md.append("| 公司 | 推文数 | 最高互动 | 主要话题 |")
    md.append("|------|--------|----------|----------|")
    for corp in sorted(corp_summary, key=lambda x: -x["count"])[:12]:
        name = corp["name"]
        cnt = corp["count"]
        top_eng = corp["top_engagement"]
        sample_text = " ".join([t.get("text","") for t in corp["tweets"][:3]]).lower()
        topic = detect_topic(sample_text)
        md.append(f"| {name} | {cnt} | {top_eng} | {topic} |")
    md.append("")

    # Top 5 tweets
    md.append("## 🔥 本周 Top 5 重磅动态")
    md.append("")
    for i, t in enumerate(tweets[:5], 1):
        corp = t["_corp"]
        user = t.get("user", "Unknown")
        text = t.get("text", "").replace("\n", " ")[:200]
        url = t.get("url", "#")
        likes = t.get("favorite_count", 0)
        rts = t.get("retweet_count", 0)
        date = t.get("created_at", "")[:10]

        md.append(f"### {i}. [{corp}] @{user} — {likes} likes, {rts} RTs ({date})")
        md.append(f"**摘要**: {text[:120]}...")
        md.append(f"🔗 {url}")
        md.append("")

    # Detailed per-company
    md.append("## 📋 公司详细动态")
    md.append("")

    for corp_data in corp_summary:
        name = corp_data["name"]
        tweets_list = sorted(corp_data["tweets"], key=lambda x: x.get("created_at",""), reverse=True)

        md.append(f"### {name} ({len(tweets_list)} 条)")
        for t in tweets_list[:8]:
            date = t.get("created_at", "")[:10]
            text = t.get("text", "").replace("\n", " ")[:150]
            url = t.get("url", "#")
            likes = t.get("favorite_count", 0)
            rts = t.get("retweet_count", 0)
            md.append(f"- **{date}** ({likes}❤️ {rts}🔁): {text}... [🔗]({url})")

        if len(tweets_list) > 8:
            md.append(f"- *还有 {len(tweets_list)-8} 条未展示*")
        md.append("")

    # Editorial insights
    md.append("## 💡 编辑洞察")
    md.append("")
    md.append("### 🎯 战略趋势")
    md.append("")
    md.append("1. **模型迭代速度成为核心竞争力**")
    md.append("   - 头部公司发布周期缩短至以周计")
    md.append("   - Agent 系统可更低成本调用最新模型")
    md.append("")
    md.append("2. **生态整合 > 单点能力**")
    md.append("   - 成功产品均嵌入大平台（如 OpenAI 的 ChatGPT + API + Codex）")
    md.append("   - 独立 Agent 生存空间受挤压")
    md.append("")
    md.append("3. **安全成为商业化敲门砖**")
    md.append("   - 企业客户为实际安全工具（如漏洞扫描）付费意愿强")
    md.append("")
    md.append("### ⚠️ 潜在风险与机会")
    md.append("")
    md.append("- **风险**: 大厂快速迭代可能碾压创业公司")
    md.append("- **机会**: 垂直领域（教育、医疗、制造）Agent 落地仍稀缺")
    md.append("- **观察**: 本土化策略（如腾讯 OpenClaw）是否会被复制？")
    md.append("")

    # Data quality
    md.append("## 📊 数据质量说明")
    md.append("")
    md.append("| 公司状态 | 数量 | 说明 |")
    md.append("|----------|------|------|")
    md.append("| ✅ 正常抓取 | 数据完整公司 | 账号活跃且可访问 |")
    md.append("| ⚠️ 部分抓取 | 少量数据 | 可能有 API 限制或日期范围问题 |")
    md.append("| ❌ 未抓取 | 0 条 | 账号名错误或上周无推文 |")
    md.append("")

    md.append("---")
    md.append(f"📈 统计: {len(corp_summary)} 家公司，{len(tweets)} 条推文")
    md.append(f"🕐 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    md.append("")
    md.append("---")
    md.append("*报告由 Corp Twitter Monitor 自动生成*")

    # Write
    if output_path is None:
        output_path = os.path.join(os.path.dirname(__file__), "..", "output",
                                   f"corp-report-{datetime.now().strftime('%Y-%m-%d')}.md")

    with open(output_path, "w") as f:
        f.write("\n".join(md))

    print(f"✅ Report generated: {output_path}")
    return output_path

def main():
    if len(sys.argv) < 2:
        print("Usage: python generate_report.py <corp_data_dir> [output_path]")
        sys.exit(1)

    data_dir = sys.argv[1]
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    tweets = load_tweets(data_dir)
    print(f"Loaded {len(tweets)} tweets from {data_dir}")
    generate_report(tweets, output_path)

if __name__ == "__main__":
    main()
