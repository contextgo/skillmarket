#!/usr/bin/env python3
"""
Fetch corporate Twitter/X accounts for a given date range.
Usage: python fetch_corps.py "2026-03-01:2026-03-08" [company1 company2 ...]
"""

import sys
import os
import json
import subprocess
from datetime import datetime

# x-cli path
X_CLI_DIR = os.path.expanduser("~/.openclaw/workspace/skills/x-cli")
VENV_PYTHON = os.path.join(X_CLI_DIR, ".venv/bin/python")
X_SEARCH_SCRIPT = os.path.join(X_CLI_DIR, "scripts/x_search.py")

def parse_date_range(date_range):
    """Parse '2026-03-01:2026-03-08' into since/until."""
    if ":" not in date_range:
        raise ValueError("date_range must be 'YYYY-MM-DD:YYYY-MM-DD' or 'last_week'")
    since, until = date_range.split(":", 1)
    return since, until

def load_companies():
    """Load company list from config."""
    config_path = os.path.join(os.path.dirname(__file__), "..", "config", "companies.json")
    with open(config_path) as f:
        cfg = json.load(f)
    # flatten tiers
    companies = cfg.get("tier1", []) + cfg.get("tier2", []) + cfg.get("tier3", [])
    return companies

def fetch_company(handle, since, until, output_dir, count=50):
    """Fetch tweets from one company using x_search.py."""
    query = f'from:{handle} since:{since} until:{until}'
    output_file = os.path.join(output_dir, f"{handle}.json")

    cmd = [
        VENV_PYTHON, X_SEARCH_SCRIPT,
        query, "--count", str(count), "--json"
    ]

    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        if result.returncode != 0:
            print(f"[WARN] {handle} failed: {result.stderr[:200]}")
            return 0

        # Append JSON lines to file
        with open(output_file, "w") as f:
            f.write(result.stdout)

        # Count lines (tweets)
        lines = [l for l in result.stdout.strip().split("\n") if l.strip()]
        return len(lines)
    except subprocess.TimeoutExpired:
        print(f"[WARN] {handle} timeout")
        return 0
    except Exception as e:
        print(f"[WARN] {handle} error: {e}")
        return 0

def main():
    if len(sys.argv) < 2:
        print("Usage: python fetch_corps.py <date_range> [company1 company2 ...]")
        print("Example: python fetch_corps.py last_week")
        print("         python fetch_corps.py 2026-03-01:2026-03-08 OpenAI GoogleAI")
        sys.exit(1)

    date_range = sys.argv[1]
    if date_range == "last_week":
        # Compute last week (Mon-Sun) relative to today
        # For simplicity, using fixed dates for now
        since, until = "2026-03-01", "2026-03-08"
    else:
        since, until = parse_date_range(date_range)

    output_dir = os.path.join(os.path.dirname(__file__), "..", "output", f"corp-{since}")
    os.makedirs(output_dir, exist_ok=True)

    # Determine companies
    if len(sys.argv) > 2:
        companies = sys.argv[2:]
    else:
        companies = load_companies()

    print(f"📅 Fetching {len(companies)} companies ({since} → {until})")
    total_tweets = 0
    for i, corp in enumerate(companies, 1):
        print(f"[{i}/{len(companies)}] {corp}...", end=" ", flush=True)
        cnt = fetch_company(corp, since, until, output_dir)
        total_tweets += cnt
        print(f"{cnt} tweets")

    print(f"\n✅ Done: {total_tweets} tweets from {len(companies)} companies")
    print(f"📁 Output: {output_dir}")
    return output_dir, total_tweets

if __name__ == "__main__":
    main()
