#!/usr/bin/env python3
"""
Send report via email (mailx or SMTP).
Usage: python send_report.py <report_file> [recipient_email]
"""

import sys
import os
import subprocess
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

def send_via_mailx(report_path, recipient, subject_prefix="[OpenClaw] Corp Report"):
    """Send using local mailx command."""
    if not os.path.exists(report_path):
        print(f"[ERROR] Report not found: {report_path}")
        return False

    with open(report_path) as f:
        body = f.read()

    date_str = datetime.now().strftime("%m-%d %H:%M")
    subject = f"{subject_prefix} ({date_str})"

    # Use mailx (Unix)
    proc = subprocess.run(
        ["mailx", "-s", subject, recipient],
        input=body,
        text=True,
        capture_output=True
    )
    if proc.returncode == 0:
        print(f"✅ Email sent via mailx to {recipient}")
        return True
    else:
        print(f"[ERROR] mailx failed: {proc.stderr}")
        return False

def send_via_smtp(report_path, recipient, smtp_config):
    """Send via SMTP (requires config)."""
    # Placeholder for SMTP implementation
    pass

def main():
    if len(sys.argv) < 3:
        print("Usage: python send_report.py <report_file> <recipient_email>")
        sys.exit(1)

    report_path = sys.argv[1]
    recipient = sys.argv[2]

    # Try mailx first
    if shutil.which("mailx"):
        return send_via_mailx(report_path, recipient)
    else:
        print("[ERROR] No mailx found. Configure SMTP in config/email.json")
        sys.exit(1)

if __name__ == "__main__":
    import shutil
    from datetime import datetime
    main()
