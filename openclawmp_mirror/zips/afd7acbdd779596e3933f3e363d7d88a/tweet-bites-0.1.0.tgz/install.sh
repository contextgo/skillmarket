#!/bin/bash
# Install Tweet Bites Skill

set -e

echo "🍪 Installing Tweet Bites..."

# Check prerequisites
echo ""
echo "📋 Checking prerequisites..."

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 not found. Install Python 3.11+ first."
    exit 1
fi

if [ ! -d "$HOME/.openclaw/workspace/skills/x-cli" ]; then
    echo "⚠️  x-cli not found. Please install x-cli first:"
    echo "   git clone <x-cli-repo> ~/.openclaw/workspace/skills/x-cli"
    echo "   cd ~/.openclaw/workspace/skills/x-cli && uv venv && source .venv/bin/activate && uv pip install twikit==2.3.3"
    exit 1
fi

if ! command -v mailx &> /dev/null; then
    echo "⚠️  mailx not found (optional). Install with: brew install heirloom-mailx (macOS) or apt-get install mailutils (Linux)"
fi

# Copy skill files (if not already in place)
SKILL_SRC="$(cd "$(dirname "$0")" && pwd)"
SKILL_DST="$HOME/.openclaw/workspace/skills/tweet-bites"

if [ "$SKILL_SRC" != "$SKILL_DST" ]; then
    echo "📦 Copying skill to $SKILL_DST"
    rm -rf "$SKILL_DST"
    cp -r "$SKILL_SRC" "$SKILL_DST"
fi

# Make scripts executable
chmod +x "$SKILL_DST/scripts/"*.py

echo "✅ Tweet Bites installed!"
echo ""
echo "📖 Next steps:"
echo "1. Ensure x-cli is authenticated (cookies.json configured)"
echo "2. Edit config/companies.json to customize monitored companies"
echo "3. Edit config/email.json to set your email recipient"
echo "4. Test: python $SKILL_DST/scripts/run.py last_week you@example.com"
echo ""
echo "📚 See README.md for full documentation."
