# Tweet Bites 🍪 — ClawHub 发布材料

## 📋 表单填写指南

### 基本 Information
- **Slug**: `tweet-bites` (自动生成，不可修改)
- **Skill name**: `tweet-bites` (与 slug 一致)
- **Display name**: `Tweet Bites 🍪`
- **Version**: `0.1.0`
- **License**: `MIT`
- **Homepage**: (可选，可留空或填 GitHub 仓库)
- **Repository**: (可选，可留空)

### Description (短描述，显示在卡片上)
```
Bite-sized corporate news from Twitter/X, curated by an AI agent.
```

### Summary (长描述，详情页顶部)
```
Automated monitoring and editorial reporting for corporate AI/tech Twitter/X accounts. Scrape official company handles, analyze engagement, generate strategic insights, and email reports. Use when user asks for company news, weekly digests, or competitive intelligence.
```

### Tags / Keywords
```
twitter
monitor
report
ai-companies
news-aggregator
corporate-intelligence
assistant_friendly
```

### Dependencies
```
x-cli (with twikit==2.3.3)
```
另需：Python 3.11+, Unix 环境 (mailx)

### OpenClaw Min Version
```
0.3.0
```

### Skill Type
```
assistant_friendly
```

### Decision
```
keep
```

---

## 📦 上传文件

将整个目录 `tweet-bites/` 打包为 ZIP 或直接上传文件夹。

**必需文件：**
- `SKILL.md` (OpenClaw 用)
- `README.md` (用户文档)
- `skill.json` (元数据)
- `config/companies.json`
- `config/email.json`
- `scripts/run.py` (主入口)
- `scripts/fetch_corps.py`
- `scripts/generate_report.py`
- `scripts/send_report.py`
- `install.sh`

**可选文件：**
- `CHANGELOG.md`
- `SECURITY.md`
- `RELEASE_CHECKLIST.md`
- `.gitignore` (可移除)

---

## 🎯 发布后验证

1. 在 explore 页面搜索 "tweet bites"
2. 点击进入详情页，检查 Description 和 Summary 显示正常
3. 复制安装命令：`clawhub install tweet-bites`
4. 在干净的环境测试安装

---

## 📸 建议截图 (发布时)

- 截图 1: 报告示例 (`output/corp-report-2026-03-09.md` 前几行)
- 截图 2: 运行命令 `python scripts/run.py last_week` 的输出
- 截图 3: 收到的邮件（可选）

---

*Prepared by Charlie for openclawmp.cc*
