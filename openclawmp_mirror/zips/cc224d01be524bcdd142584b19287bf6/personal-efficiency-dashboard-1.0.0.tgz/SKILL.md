---
name: personal-efficiency-dashboard
description: 个人效率仪表盘 - 整合日程、任务、天气、提醒，每天早上8点自动生成日报
version: 1.0.0
---

# 个人效率仪表盘

一站式个人效率管理仪表盘，整合日程、任务、天气、提醒。

## 核心功能

- 📅 **日程管理** - 查看当日日程安排
- ✅ **任务追踪** - 待办任务列表与完成统计
- 🌤️ **天气显示** - 实时天气与出行建议
- 🔔 **重要提醒** - 关键事项不遗漏
- 📊 **效率统计** - 数据可视化分析

## 安装

```bash
openclawmp install skill/@xiaodezi-skills/personal-efficiency-dashboard
```

## 使用

```bash
# 启动仪表盘
node dashboard.html

# 启动定时任务
node scheduler.js
```

## 配置

编辑 `config.json`：

```json
{
  "location": "Beijing",
  "calendarFile": "./data/calendar.json",
  "tasksFile": "./data/tasks.json"
}
```

## 价格

- 基础功能：免费
- 高级功能：¥29.9

---

**购买授权**：扫码付款 → 发截图到 1171777183@qq.com → 接收授权码
