/**
 * 个人效率仪表盘 - 数据收集器
 */

const fs = require('fs').promises;
const path = require('path');
const https = require('https');

class DataCollector {
  constructor(configPath = './config.json') {
    this.configPath = configPath;
    this.dataDir = './data';
  }

  async init() {
    try {
      await fs.mkdir(this.dataDir, { recursive: true });
      this.config = JSON.parse(await fs.readFile(this.configPath, 'utf8'));
    } catch (e) {
      this.config = this.getDefaultConfig();
    }
  }

  getDefaultConfig() {
    return {
      location: 'Beijing',
      calendarFile: './data/calendar.json',
      tasksFile: './data/tasks.json',
      remindersFile: './data/reminders.json'
    };
  }

  // 获取天气数据
  async getWeather() {
    return new Promise((resolve, reject) => {
      const location = this.config.location || 'Beijing';
      const url = `https://wttr.in/${location}?format=j1`;
      
      https.get(url, (res) => {
        let data = '';
        res.on('data', chunk => data += chunk);
        res.on('end', () => {
          try {
            const weather = JSON.parse(data);
            resolve({
              temp: weather.current_condition[0].temp_C,
              desc: weather.current_condition[0].lang_zh[0].value,
              humidity: weather.current_condition[0].humidity,
              wind: weather.current_condition[0].windspeedKmph,
              location: location
            });
          } catch (e) {
            reject(e);
          }
        });
      }).on('error', reject);
    });
  }

  // 获取日程数据
  async getCalendar() {
    try {
      const data = await fs.readFile(this.config.calendarFile, 'utf8');
      return JSON.parse(data);
    } catch (e) {
      return [];
    }
  }

  // 获取任务数据
  async getTasks() {
    try {
      const data = await fs.readFile(this.config.tasksFile, 'utf8');
      return JSON.parse(data);
    } catch (e) {
      return [];
    }
  }

  // 获取提醒数据
  async getReminders() {
    try {
      const data = await fs.readFile(this.config.remindersFile, 'utf8');
      return JSON.parse(data);
    } catch (e) {
      return [];
    }
  }

  // 收集所有数据
  async collectAll() {
    const [weather, calendar, tasks, reminders] = await Promise.all([
      this.getWeather().catch(() => null),
      this.getCalendar(),
      this.getTasks(),
      this.getReminders()
    ]);

    return {
      timestamp: new Date().toISOString(),
      weather,
      calendar,
      tasks,
      reminders,
      stats: {
        totalTasks: tasks.length,
        completedTasks: tasks.filter(t => t.completed).length,
        pendingTasks: tasks.filter(t => !t.completed).length,
        todayEvents: calendar.filter(e => this.isToday(e.date)).length
      }
    };
  }

  isToday(dateStr) {
    const date = new Date(dateStr);
    const today = new Date();
    return date.toDateString() === today.toDateString();
  }
}

module.exports = { DataCollector };
