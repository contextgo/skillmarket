/**
 * 个人效率仪表盘 - 定时任务调度器
 */

const { DataCollector } = require('./data-collector');
const fs = require('fs').promises;

class Scheduler {
  constructor() {
    this.collector = new DataCollector();
    this.tasks = [];
  }

  async init() {
    await this.collector.init();
  }

  // 每天早上8点生成日报
  async generateDailyReport() {
    console.log('[' + new Date().toLocaleString() + '] 生成每日报告...');
    
    try {
      const data = await this.collector.collectAll();
      const reportPath = `./data/reports/daily-${new Date().toISOString().split('T')[0]}.json`;
      
      await fs.mkdir('./data/reports', { recursive: true });
      await fs.writeFile(reportPath, JSON.stringify(data, null, 2));
      
      console.log('✅ 日报已生成:', reportPath);
      return data;
    } catch (error) {
      console.error('❌ 生成日报失败:', error.message);
      throw error;
    }
  }

  // 每小时更新数据
  async updateData() {
    console.log('[' + new Date().toLocaleString() + '] 更新数据...');
    
    try {
      const data = await this.collector.collectAll();
      await fs.writeFile('./data/latest.json', JSON.stringify(data, null, 2));
      console.log('✅ 数据已更新');
      return data;
    } catch (error) {
      console.error('❌ 更新数据失败:', error.message);
    }
  }

  // 启动定时任务
  start() {
    console.log('🚀 启动定时任务调度器...');
    
    // 每小时更新一次
    setInterval(() => this.updateData(), 60 * 60 * 1000);
    
    // 每天早上8点生成日报
    const now = new Date();
    const next8am = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 8, 0, 0);
    if (next8am <= now) next8am.setDate(next8am.getDate() + 1);
    
    const msUntil8am = next8am - now;
    
    setTimeout(() => {
      this.generateDailyReport();
      setInterval(() => this.generateDailyReport(), 24 * 60 * 60 * 1000);
    }, msUntil8am);
    
    console.log('⏰ 下次日报生成时间:', next8am.toLocaleString());
  }
}

// 如果直接运行
if (require.main === module) {
  const scheduler = new Scheduler();
  scheduler.init().then(() => {
    scheduler.start();
  });
}

module.exports = { Scheduler };
