# code-quality 代码质量审查系统

工业级代码质量审查系统，提供多语言自动化检查、历史追踪、趋势分析和 CI/CD 集成。

## 安装

```bash
# 克隆到技能目录
git clone <repo> ~/.stepfun/skills/code-quality

# 安装依赖
pip install pyyaml
```

## 快速开始

```python
from scripts.analyzer import CodeQualityAnalyzer

# 分析项目
analyzer = CodeQualityAnalyzer("/path/to/project")
result = analyzer.analyze(depth="standard")

# 查看结果
print(f"总体评级: {result.overall_rating}")
for dim in result.dimensions:
    print(f"{dim.dimension.value}: {dim.rating}")
```

## 文档

- [完整文档](SKILL.md)
- [配置参考](config/default.yaml)
- [CI/CD 集成](templates/)

## 许可证

MIT
