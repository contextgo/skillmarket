"""
代码质量分析引擎

核心功能：
1. 加载并合并配置（默认 + 语言专项 + 项目级）
2. 检测并调用适当的 linting 工具
3. 解析工具输出并统一格式化
4. 生成结构化的审查结果
"""

import os
import json
import yaml
import subprocess
import re
from pathlib import Path
from typing import Dict, List, Optional, Any, Tuple
import logging

from .models import Severity, Dimension, Issue, DimensionResult, ReviewResult

logger = logging.getLogger(__name__)


class CodeQualityAnalyzer:
    """代码质量分析器"""
    
    def __init__(self, project_path: str, config_path: Optional[str] = None):
        self.project_path = Path(project_path).resolve()
        self.config = self._load_config(config_path)
        self.issues: List[Issue] = []
        self.metrics: Dict[str, Any] = {}
        
    def _load_config(self, config_path: Optional[str]) -> Dict[str, Any]:
        """加载并合并配置"""
        # 1. 加载默认配置
        skill_dir = Path(__file__).parent.parent
        default_config_path = skill_dir / "config" / "default.yaml"
        
        # SECURITY: 必须使用 safe_load，禁止用 load（防止代码执行）
        with open(default_config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
        
        # 2. 检测项目语言并加载专项配置
        language = self._detect_language()
        if language:
            lang_config_path = skill_dir / "config" / f"{language}.yaml"
            if lang_config_path.exists():
                with open(lang_config_path, 'r', encoding='utf-8') as f:
                    lang_config = yaml.safe_load(f)
                config = self._merge_config(config, lang_config)
        
        # 3. 加载项目级配置（如果存在）
        project_config_path = self.project_path / ".codequality.yaml"
        if project_config_path.exists():
            with open(project_config_path, 'r', encoding='utf-8') as f:
                project_config = yaml.safe_load(f)
            config = self._merge_config(config, project_config)
        
        # 4. 加载传入的配置（优先级最高）
        if config_path:
            with open(config_path, 'r', encoding='utf-8') as f:
                override_config = yaml.safe_load(f)
            config = self._merge_config(config, override_config)
        
        return config
    
    def _merge_config(self, base: Dict, override: Dict, depth: int = 0) -> Dict:
        """递归合并配置（带深度限制防止栈溢出）"""
        MAX_DEPTH = 10
        if depth > MAX_DEPTH:
            logger.warning(f"配置合并深度超过 {MAX_DEPTH}，停止递归")
            return override
        
        result = base.copy()
        for key, value in override.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_config(result[key], value, depth + 1)
            else:
                result[key] = value
        return result
    
    def _detect_language(self) -> Optional[str]:
        """检测项目主要语言"""
        file_counts = {}
        
        for ext, lang in [
            ('.py', 'python'),
            ('.ts', 'typescript'),
            ('.tsx', 'typescript'),
            ('.js', 'typescript'),
            ('.go', 'go'),
        ]:
            count = len(list(self.project_path.rglob(f"*{ext}")))
            if count > 0:
                file_counts[lang] = file_counts.get(lang, 0) + count
        
        if not file_counts:
            return None
        
        return max(file_counts, key=file_counts.get)
    
    def analyze(self, depth: str = "standard") -> ReviewResult:
        """执行代码质量分析"""
        import time
        start_time = time.time()
        
        logger.info(f"开始分析项目: {self.project_path}")
        logger.info(f"审查深度: {depth}")
        
        # 根据深度确定要检查的维度
        dimensions_to_check = self._get_dimensions_for_depth(depth)
        
        dimension_results = []
        for dimension in dimensions_to_check:
            result = self._analyze_dimension(dimension)
            dimension_results.append(result)
        
        # 计算总体评级
        overall_rating = self._calculate_overall_rating(dimension_results)
        
        duration = time.time() - start_time
        
        return ReviewResult(
            project_path=str(self.project_path),
            review_depth=depth,
            overall_rating=overall_rating,
            dimensions=dimension_results,
            timestamp=time.strftime("%Y-%m-%d %H:%M:%S"),
            duration_seconds=duration,
        )
    
    def _get_dimensions_for_depth(self, depth: str) -> List[Dimension]:
        """根据审查深度返回要检查的维度"""
        all_dimensions = [
            Dimension.CORRECTNESS,
            Dimension.SECURITY,
            Dimension.MAINTAINABILITY,
            Dimension.PERFORMANCE,
        ]
        
        if depth == "quick":
            # 快速审查只检查正确性和安全性
            return [Dimension.CORRECTNESS, Dimension.SECURITY]
        elif depth == "deep":
            # 深度审查检查所有维度
            return all_dimensions
        else:  # standard
            return all_dimensions
    
    def _analyze_dimension(self, dimension: Dimension) -> DimensionResult:
        """分析单个维度"""
        logger.info(f"分析维度: {dimension.value}")
        
        issues = []
        metrics = {}
        
        # 根据维度调用相应的检查方法
        if dimension == Dimension.CORRECTNESS:
            issues, metrics = self._check_correctness()
        elif dimension == Dimension.SECURITY:
            issues, metrics = self._check_security()
        elif dimension == Dimension.MAINTAINABILITY:
            issues, metrics = self._check_maintainability()
        elif dimension == Dimension.PERFORMANCE:
            issues, metrics = self._check_performance()
        
        # 计算维度评级
        rating = self._calculate_dimension_rating(issues)
        
        # 生成摘要
        summary = self._generate_dimension_summary(dimension, issues, metrics)
        
        return DimensionResult(
            dimension=dimension,
            rating=rating,
            issues=issues,
            metrics=metrics,
            summary=summary,
        )
    
    def _check_correctness(self) -> Tuple[List[Issue], Dict[str, Any]]:
        """检查正确性维度"""
        issues = []
        metrics = {}
        
        # 调用语言特定的工具进行检查
        language = self._detect_language()
        if language:
            tool_issues, tool_metrics = self._run_language_tools(language, "correctness")
            issues.extend(tool_issues)
            metrics.update(tool_metrics)
        
        return issues, metrics
    
    def _check_security(self) -> Tuple[List[Issue], Dict[str, Any]]:
        """检查安全性维度"""
        issues = []
        metrics = {}
        
        language = self._detect_language()
        if language:
            tool_issues, tool_metrics = self._run_language_tools(language, "security")
            issues.extend(tool_issues)
            metrics.update(tool_metrics)
        
        return issues, metrics
    
    def _check_maintainability(self) -> Tuple[List[Issue], Dict[str, Any]]:
        """检查可维护性维度"""
        issues = []
        metrics = {}
        
        language = self._detect_language()
        if language:
            tool_issues, tool_metrics = self._run_language_tools(language, "maintainability")
            issues.extend(tool_issues)
            metrics.update(tool_metrics)
        
        return issues, metrics
    
    def _check_performance(self) -> Tuple[List[Issue], Dict[str, Any]]:
        """检查性能维度"""
        issues = []
        metrics = {}
        
        # 执行静态性能模式检测
        perf_issues, perf_metrics = self._detect_performance_patterns()
        issues.extend(perf_issues)
        metrics.update(perf_metrics)
        
        # 调用语言特定的性能工具
        language = self._detect_language()
        if language:
            tool_issues, tool_metrics = self._run_language_tools(language, "performance")
            issues.extend(tool_issues)
            metrics.update(tool_metrics)
        
        return issues, metrics
    
    def _detect_performance_patterns(self) -> Tuple[List[Issue], Dict[str, Any]]:
        """检测常见的性能问题模式"""
        issues = []
        metrics = {"performance_patterns_checked": 0}
        
        # 获取要检查的文件
        include_patterns = self.config.get("review", {}).get("include", ["**/*.py"])
        exclude_patterns = self.config.get("review", {}).get("exclude", [])
        
        files_to_check = []
        for pattern in include_patterns:
            files_to_check.extend(self.project_path.rglob(pattern))
        
        # 过滤排除的文件
        for exclude in exclude_patterns:
            files_to_check = [f for f in files_to_check if not f.match(exclude)]
        
        # 性能模式规则
        performance_patterns = [
            {
                "name": "loop_database_query",
                "pattern": r"for\s+\w+\s+in\s+\w+:\s*\n\s+.*\.(query|filter|get|all)\(",
                "message": "循环内执行数据库查询（N+1问题）",
                "suggestion": "使用 select_related/prefetch_related 或批量查询",
                "severity": Severity.HIGH,
            },
            {
                "name": "string_concat_in_loop",
                "pattern": r"for\s+\w+\s+in\s+\w+:\s*\n\s+\w+\s*\+?=",
                "message": "循环内字符串拼接",
                "suggestion": "使用列表收集后 ''.join() 或使用 StringIO",
                "severity": Severity.MEDIUM,
            },
            {
                "name": "list_append_in_loop",
                "pattern": r"for\s+\w+\s+in\s+range\s*\(\s*len\s*\(",
                "message": "使用 range(len()) 迭代",
                "suggestion": "使用 enumerate() 或直接迭代",
                "severity": Severity.LOW,
            },
            {
                "name": "repeated_file_read",
                "pattern": r"open\s*\([^)]+\).*read",
                "message": "文件读取操作",
                "suggestion": "确保文件读取有缓存，避免重复读取",
                "severity": Severity.LOW,
            },
        ]
        
        for file_path in files_to_check:
            if not file_path.is_file():
                continue
            
            try:
                content = file_path.read_text(encoding='utf-8', errors='ignore')
                lines = content.split('\n')
                
                for rule in performance_patterns:
                    matches = list(re.finditer(rule["pattern"], content, re.MULTILINE))
                    metrics["performance_patterns_checked"] += len(matches)
                    
                    for match in matches:
                        # 计算行号
                        line_num = content[:match.start()].count('\n') + 1
                        
                        issue = Issue(
                            dimension=Dimension.PERFORMANCE,
                            severity=rule["severity"],
                            file=str(file_path.relative_to(self.project_path)),
                            line=line_num,
                            column=match.start() - content.rfind('\n', 0, match.start()),
                            message=rule["message"],
                            rule_id=rule["name"],
                            suggestion=rule["suggestion"],
                            snippet=lines[line_num-1] if line_num <= len(lines) else None,
                        )
                        issues.append(issue)
                        
            except Exception as e:
                logger.debug(f"检查文件性能模式失败 {file_path}: {e}")
                continue
        
        return issues, metrics
    
    def _run_language_tools(self, language: str, dimension: str) -> Tuple[List[Issue], Dict[str, Any]]:
        """运行语言特定的工具"""
        from .tools import get_tool_adapter
        
        issues = []
        metrics = {}
        
        # 获取该语言该维度启用的工具
        tools_config = self.config.get("tools", {}).get(language, {})
        
        for tool_name, tool_config in tools_config.items():
            if not tool_config.get("enabled", False):
                continue
            
            try:
                adapter = get_tool_adapter(language, tool_name)
                if adapter:
                    tool_issues, tool_metrics = adapter.run(
                        self.project_path,
                        tool_config,
                        dimension,
                    )
                    issues.extend(tool_issues)
                    metrics.update(tool_metrics)
            except Exception as e:
                logger.warning(f"工具 {tool_name} 运行失败: {e}")
        
        return issues, metrics
    
    def _calculate_dimension_rating(self, issues: List[Issue]) -> str:
        """计算维度评级"""
        critical_count = sum(1 for i in issues if i.severity == Severity.CRITICAL)
        high_count = sum(1 for i in issues if i.severity == Severity.HIGH)
        
        if critical_count > 0:
            return "🔴"
        elif high_count > 0:
            return "🟡"
        else:
            return "🟢"
    
    def _calculate_overall_rating(self, dimension_results: List[DimensionResult]) -> str:
        """计算总体评级"""
        ratings = [d.rating for d in dimension_results]
        
        if "🔴" in ratings:
            return "🔴 需修复"
        elif "🟡" in ratings:
            return "🟡 有改进空间"
        else:
            return "🟢 通过"
    
    def _generate_dimension_summary(self, dimension: Dimension, 
                                    issues: List[Issue], 
                                    metrics: Dict[str, Any]) -> str:
        """生成维度摘要"""
        severity_counts = {}
        for issue in issues:
            severity_counts[issue.severity.value] = severity_counts.get(issue.severity.value, 0) + 1
        
        summary_parts = []
        if severity_counts:
            parts = [f"{k}: {v}" for k, v in severity_counts.items()]
            summary_parts.append(f"发现问题: {', '.join(parts)}")
        else:
            summary_parts.append("未发现明显问题")
        
        if metrics:
            metric_parts = [f"{k}={v:.1f}" if isinstance(v, float) else f"{k}={v}" 
                          for k, v in list(metrics.items())[:3]]
            summary_parts.append(f"关键指标: {', '.join(metric_parts)}")
        
        return "; ".join(summary_parts)