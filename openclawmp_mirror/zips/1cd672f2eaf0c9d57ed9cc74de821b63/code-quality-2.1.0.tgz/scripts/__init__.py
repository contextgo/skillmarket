"""
code-quality 自动化代码审查引擎

提供多语言代码质量检查、历史追踪和趋势分析功能。
"""

__version__ = "2.0.0"
__author__ = "code-quality skill"

# 从 models 导入共享类型
from .models import (
    Severity,
    Dimension,
    Issue,
    DimensionResult,
    ReviewResult,
)

# 从各模块导入主要类
from .analyzer import CodeQualityAnalyzer
from .database import HistoryDatabase
from .dashboard import DashboardGenerator
from .report import ReportGenerator

__all__ = [
    # 版本信息
    "__version__",
    "__author__",
    # 数据模型
    "Severity",
    "Dimension",
    "Issue",
    "DimensionResult",
    "ReviewResult",
    # 核心类
    "CodeQualityAnalyzer",
    "HistoryDatabase",
    "DashboardGenerator",
    "ReportGenerator",
]