"""
共享数据模型

提取自 analyzer.py，用于打破循环导入。
所有工具适配器和分析器共享这些类型定义。
"""

from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any
from enum import Enum


class Severity(Enum):
    """问题严重级别"""
    CRITICAL = "critical"  # 必须修复
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"


class Dimension(Enum):
    """审查维度"""
    CORRECTNESS = "correctness"
    SECURITY = "security"
    MAINTAINABILITY = "maintainability"
    PERFORMANCE = "performance"


@dataclass
class Issue:
    """单个代码问题"""
    dimension: Dimension
    severity: Severity
    file: str
    line: int
    column: int
    message: str
    rule_id: str
    suggestion: str
    snippet: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "dimension": self.dimension.value,
            "severity": self.severity.value,
            "file": self.file,
            "line": self.line,
            "column": self.column,
            "message": self.message,
            "rule_id": self.rule_id,
            "suggestion": self.suggestion,
            "snippet": self.snippet,
        }


@dataclass
class DimensionResult:
    """单个维度的审查结果"""
    dimension: Dimension
    rating: str  # 🟢 🟡 🔴
    issues: List[Issue]
    metrics: Dict[str, Any]
    summary: str


@dataclass
class ReviewResult:
    """完整审查结果"""
    project_path: str
    review_depth: str
    overall_rating: str
    dimensions: List[DimensionResult]
    timestamp: str
    duration_seconds: float
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "project_path": self.project_path,
            "review_depth": self.review_depth,
            "overall_rating": self.overall_rating,
            "dimensions": [
                {
                    "dimension": d.dimension.value,
                    "rating": d.rating,
                    "issues": [i.to_dict() for i in d.issues],
                    "metrics": d.metrics,
                    "summary": d.summary,
                }
                for d in self.dimensions
            ],
            "timestamp": self.timestamp,
            "duration_seconds": self.duration_seconds,
        }


__all__ = [
    "Severity",
    "Dimension",
    "Issue",
    "DimensionResult",
    "ReviewResult",
]