"""
历史追踪数据库模块

使用 SQLite 存储代码质量审查历史，支持趋势分析。
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional, Tuple
from dataclasses import asdict
import logging

logger = logging.getLogger(__name__)


class HistoryDatabase:
    """代码质量历史数据库"""
    
    def __init__(self, db_path: Optional[str] = None):
        if db_path is None:
            db_path = ".codequality/history.db"
        
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        
        self._init_database()
    
    def _init_database(self) -> None:
        """初始化数据库表结构"""
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS projects (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    path TEXT UNIQUE NOT NULL,
                    name TEXT,
                    language TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS reviews (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    project_id INTEGER NOT NULL,
                    review_depth TEXT NOT NULL,
                    overall_rating TEXT NOT NULL,
                    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    duration_seconds REAL,
                    result_json TEXT,
                    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS metrics (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    review_id INTEGER NOT NULL,
                    dimension TEXT NOT NULL,
                    metric_name TEXT NOT NULL,
                    metric_value REAL,
                    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE
                )
            """)
            
            conn.execute("""
                CREATE TABLE IF NOT EXISTS issues (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    review_id INTEGER NOT NULL,
                    dimension TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    file TEXT NOT NULL,
                    line INTEGER,
                    rule_id TEXT,
                    message TEXT,
                    FOREIGN KEY (review_id) REFERENCES reviews(id) ON DELETE CASCADE
                )
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_reviews_project 
                ON reviews(project_id, timestamp)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_metrics_review 
                ON metrics(review_id, dimension)
            """)
            
            conn.execute("""
                CREATE INDEX IF NOT EXISTS idx_issues_review 
                ON issues(review_id, dimension, severity)
            """)
            
            conn.commit()
    
    def save_review(self, project_path: str, result: Any) -> int:
        """
        保存审查结果到数据库
        
        Args:
            project_path: 项目路径
            result: ReviewResult 对象
            
        Returns:
            审查记录 ID
        """
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            # 获取或创建项目
            cursor = conn.execute(
                "SELECT id FROM projects WHERE path = ?",
                (project_path,)
            )
            row = cursor.fetchone()
            
            if row:
                project_id = row[0]
                conn.execute(
                    "UPDATE projects SET updated_at = ? WHERE id = ?",
                    (datetime.now().isoformat(), project_id)
                )
            else:
                cursor = conn.execute(
                    """INSERT INTO projects (path, name, language) 
                       VALUES (?, ?, ?)""",
                    (project_path, Path(project_path).name, None)
                )
                project_id = cursor.lastrowid
            
            # 保存审查结果
            cursor = conn.execute(
                """INSERT INTO reviews 
                   (project_id, review_depth, overall_rating, timestamp, duration_seconds, result_json)
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (
                    project_id,
                    result.review_depth,
                    result.overall_rating,
                    result.timestamp,
                    result.duration_seconds,
                    json.dumps(result.to_dict())
                )
            )
            review_id = cursor.lastrowid
            
            # 保存指标
            for dim_result in result.dimensions:
                for metric_name, metric_value in dim_result.metrics.items():
                    conn.execute(
                        """INSERT INTO metrics 
                           (review_id, dimension, metric_name, metric_value)
                           VALUES (?, ?, ?, ?)""",
                        (
                            review_id,
                            dim_result.dimension.value,
                            metric_name,
                            float(metric_value) if isinstance(metric_value, (int, float)) else 0
                        )
                    )
                
                # 保存问题
                for issue in dim_result.issues:
                    conn.execute(
                        """INSERT INTO issues 
                           (review_id, dimension, severity, file, line, rule_id, message)
                           VALUES (?, ?, ?, ?, ?, ?, ?)""",
                        (
                            review_id,
                            issue.dimension.value,
                            issue.severity.value,
                            issue.file,
                            issue.line,
                            issue.rule_id,
                            issue.message
                        )
                    )
            
            conn.commit()
            return review_id
    
    def get_project_history(self, project_path: str, 
                           days: int = 30) -> List[Dict[str, Any]]:
        """
        获取项目历史审查记录
        
        Args:
            project_path: 项目路径
            days: 查询天数
            
        Returns:
            历史记录列表
        """
        since = datetime.now() - timedelta(days=days)
        
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            conn.row_factory = sqlite3.Row
            
            cursor = conn.execute(
                """SELECT r.* FROM reviews r
                   JOIN projects p ON r.project_id = p.id
                   WHERE p.path = ? AND r.timestamp > ?
                   ORDER BY r.timestamp DESC""",
                (project_path, since.isoformat())
            )
            
            return [dict(row) for row in cursor.fetchall()]
    
    def get_metric_trend(self, project_path: str, metric_name: str,
                        dimension: Optional[str] = None,
                        days: int = 30) -> List[Tuple[str, float]]:
        """
        获取指标趋势
        
        Args:
            project_path: 项目路径
            metric_name: 指标名称
            dimension: 维度（可选）
            days: 查询天数
            
        Returns:
            [(timestamp, value), ...]
        """
        since = datetime.now() - timedelta(days=days)
        
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            if dimension:
                cursor = conn.execute(
                    """SELECT r.timestamp, m.metric_value 
                       FROM metrics m
                       JOIN reviews r ON m.review_id = r.id
                       JOIN projects p ON r.project_id = p.id
                       WHERE p.path = ? AND m.metric_name = ? 
                         AND m.dimension = ? AND r.timestamp > ?
                       ORDER BY r.timestamp""",
                    (project_path, metric_name, dimension, since.isoformat())
                )
            else:
                cursor = conn.execute(
                    """SELECT r.timestamp, m.metric_value 
                       FROM metrics m
                       JOIN reviews r ON m.review_id = r.id
                       JOIN projects p ON r.project_id = p.id
                       WHERE p.path = ? AND m.metric_name = ? 
                         AND r.timestamp > ?
                       ORDER BY r.timestamp""",
                    (project_path, metric_name, since.isoformat())
                )
            
            return [(row[0], row[1]) for row in cursor.fetchall()]
    
    def get_issue_trend(self, project_path: str,
                       days: int = 30) -> Dict[str, List[Tuple[str, int]]]:
        """
        获取问题数量趋势（按严重级别）
        
        Args:
            project_path: 项目路径
            days: 查询天数
            
        Returns:
            {severity: [(timestamp, count), ...]}
        """
        since = datetime.now() - timedelta(days=days)
        
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            cursor = conn.execute(
                """SELECT r.timestamp, i.severity, COUNT(*) as count
                   FROM issues i
                   JOIN reviews r ON i.review_id = r.id
                   JOIN projects p ON r.project_id = p.id
                   WHERE p.path = ? AND r.timestamp > ?
                   GROUP BY r.timestamp, i.severity
                   ORDER BY r.timestamp""",
                (project_path, since.isoformat())
            )
            
            trends = {}
            for row in cursor.fetchall():
                timestamp, severity, count = row
                if severity not in trends:
                    trends[severity] = []
                trends[severity].append((timestamp, count))
            
            return trends
    
    def get_latest_review(self, project_path: str) -> Optional[Dict[str, Any]]:
        """获取最新的审查记录"""
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            conn.row_factory = sqlite3.Row
            
            cursor = conn.execute(
                """SELECT r.* FROM reviews r
                   JOIN projects p ON r.project_id = p.id
                   WHERE p.path = ?
                   ORDER BY r.timestamp DESC
                   LIMIT 1""",
                (project_path,)
            )
            
            row = cursor.fetchone()
            return dict(row) if row else None
    
    def compare_with_previous(self, project_path: str, 
                             current_review_id: int) -> Dict[str, Any]:
        """
        与上一次审查结果对比
        
        Args:
            project_path: 项目路径
            current_review_id: 当前审查 ID
            
        Returns:
            对比结果
        """
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            # 获取当前审查
            cursor = conn.execute(
                """SELECT r.*, p.path FROM reviews r
                   JOIN projects p ON r.project_id = p.id
                   WHERE r.id = ?""",
                (current_review_id,)
            )
            current = cursor.fetchone()
            
            if not current:
                return {}
            
            # 获取上一次审查
            cursor = conn.execute(
                """SELECT r.* FROM reviews r
                   JOIN projects p ON r.project_id = p.id
                   WHERE p.path = ? AND r.id < ?
                   ORDER BY r.timestamp DESC
                   LIMIT 1""",
                (project_path, current_review_id)
            )
            previous = cursor.fetchone()
            
            if not previous:
                return {"message": "这是首次审查，无历史对比数据"}
            
            # 对比指标
            cursor = conn.execute(
                """SELECT metric_name, metric_value FROM metrics
                   WHERE review_id = ?""",
                (current_review_id,)
            )
            current_metrics = {row[0]: row[1] for row in cursor.fetchall()}
            
            cursor = conn.execute(
                """SELECT metric_name, metric_value FROM metrics
                   WHERE review_id = ?""",
                (previous[0],)
            )
            previous_metrics = {row[0]: row[1] for row in cursor.fetchall()}
            
            # 计算变化
            changes = {}
            for metric, current_val in current_metrics.items():
                prev_val = previous_metrics.get(metric)
                if prev_val is not None:
                    change = current_val - prev_val
                    change_pct = (change / prev_val * 100) if prev_val != 0 else 0
                    changes[metric] = {
                        "current": current_val,
                        "previous": prev_val,
                        "change": change,
                        "change_percent": change_pct,
                        "trend": "improved" if change > 0 else "degraded" if change < 0 else "stable"
                    }
            
            return {
                "current_review": {
                    "id": current[0],
                    "timestamp": current[4],
                    "rating": current[3],
                },
                "previous_review": {
                    "id": previous[0],
                    "timestamp": previous[4],
                    "rating": previous[3],
                },
                "metric_changes": changes,
            }
    
    def cleanup_old_records(self, retention_days: int = 365) -> int:
        """
        清理旧记录
        
        Args:
            retention_days: 保留天数
            
        Returns:
            删除的记录数
        """
        cutoff = datetime.now() - timedelta(days=retention_days)
        
        with sqlite3.connect(self.db_path, timeout=30) as conn:
            # 删除旧审查记录（关联的指标和问题会自动级联删除）
            cursor = conn.execute(
                "DELETE FROM reviews WHERE timestamp < ?",
                (cutoff.isoformat(),)
            )
            deleted = cursor.rowcount
            
            # 清理没有审查记录的项目
            conn.execute("""
                DELETE FROM projects 
                WHERE id NOT IN (SELECT DISTINCT project_id FROM reviews)
            """)
            
            conn.commit()
            return deleted
