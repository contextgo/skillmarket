"""
质量趋势仪表盘生成器

生成可视化报告，展示代码质量趋势和改进情况。
"""

import json
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
from .database import HistoryDatabase
import logging

logger = logging.getLogger(__name__)


class DashboardGenerator:
    """仪表盘生成器"""
    
    def __init__(self, db: HistoryDatabase):
        self.db = db
    
    def generate(self, project_path: str, 
                output_format: str = "html",
                days: int = 30) -> str:
        """
        生成仪表盘报告
        
        Args:
            project_path: 项目路径
            output_format: 输出格式 (html|markdown|json)
            days: 历史天数
            
        Returns:
            报告内容
        """
        # 收集数据
        data = self._collect_data(project_path, days)
        
        if output_format == "html":
            return self._generate_html(data)
        elif output_format == "markdown":
            return self._generate_markdown(data)
        elif output_format == "json":
            return json.dumps(data, indent=2, ensure_ascii=False)
        else:
            raise ValueError(f"不支持的输出格式: {output_format}")
    
    def _collect_data(self, project_path: str, days: int) -> Dict[str, Any]:
        """收集仪表盘数据"""
        data = {
            "project_path": project_path,
            "generated_at": datetime.now().isoformat(),
            "period_days": days,
        }
        
        # 获取历史记录
        history = self.db.get_project_history(project_path, days)
        data["review_count"] = len(history)
        
        if not history:
            data["message"] = "暂无历史数据"
            return data
        
        # 最新审查
        latest = history[0]
        data["latest_review"] = {
            "timestamp": latest["timestamp"],
            "rating": latest["overall_rating"],
            "depth": latest["review_depth"],
            "duration": latest["duration_seconds"],
        }
        
        # 计算趋势
        data["trends"] = self._calculate_trends(project_path, days)
        
        # 计算统计
        data["statistics"] = self._calculate_statistics(history)
        
        # 生成警报
        data["alerts"] = self._generate_alerts(project_path, data["trends"])
        
        return data
    
    def _calculate_trends(self, project_path: str, days: int) -> Dict[str, Any]:
        """计算各项趋势"""
        trends = {}
        
        # 关键指标趋势
        key_metrics = [
            ("correctness", "test_coverage"),
            ("maintainability", "pylint_score"),
            ("security", "security_issues_count"),
        ]
        
        for dimension, metric in key_metrics:
            metric_trend = self.db.get_metric_trend(
                project_path, metric, dimension, days
            )
            if metric_trend:
                values = [v for _, v in metric_trend]
                trends[f"{dimension}_{metric}"] = {
                    "data": metric_trend,
                    "current": values[-1] if values else 0,
                    "average": sum(values) / len(values) if values else 0,
                    "min": min(values) if values else 0,
                    "max": max(values) if values else 0,
                    "change": values[-1] - values[0] if len(values) > 1 else 0,
                }
        
        # 问题数量趋势
        issue_trend = self.db.get_issue_trend(project_path, days)
        trends["issues_by_severity"] = issue_trend
        
        return trends
    
    def _calculate_statistics(self, history: List[Dict]) -> Dict[str, Any]:
        """计算统计数据"""
        if not history:
            return {}
        
        ratings = [h["overall_rating"] for h in history]
        durations = [h["duration_seconds"] for h in history if h["duration_seconds"]]
        
        # 评级分布
        rating_counts = {}
        for r in ratings:
            rating_counts[r] = rating_counts.get(r, 0) + 1
        
        stats = {
            "total_reviews": len(history),
            "rating_distribution": rating_counts,
            "average_duration": sum(durations) / len(durations) if durations else 0,
            "first_review": history[-1]["timestamp"] if history else None,
            "latest_review": history[0]["timestamp"] if history else None,
        }
        
        # 评级改进率
        if len(ratings) > 1:
            improved = sum(1 for i in range(1, len(ratings)) 
                         if self._rating_value(ratings[i]) > self._rating_value(ratings[i-1]))
            stats["improvement_rate"] = improved / (len(ratings) - 1) * 100
        
        return stats
    
    def _rating_value(self, rating: str) -> int:
        """将评级转换为数值"""
        rating_map = {
            "🔴 需修复": 1,
            "🟡 有改进空间": 2,
            "🟢 通过": 3,
        }
        return rating_map.get(rating, 0)
    
    def _generate_alerts(self, project_path: str, trends: Dict) -> List[Dict]:
        """生成质量警报"""
        alerts = []
        
        # 检查指标下降
        for metric_key, trend_data in trends.items():
            if isinstance(trend_data, dict) and "change" in trend_data:
                change = trend_data["change"]
                if change < -10:  # 下降超过10%
                    alerts.append({
                        "level": "warning",
                        "metric": metric_key,
                        "message": f"{metric_key} 下降 {abs(change):.1f}%",
                        "suggestion": "检查最近的代码变更",
                    })
        
        # 检查问题激增
        if "issues_by_severity" in trends:
            for severity, data in trends["issues_by_severity"].items():
                if len(data) > 1:
                    latest_count = data[-1][1]
                    prev_count = data[-2][1]
                    if latest_count > prev_count * 1.5:  # 增长超过50%
                        alerts.append({
                            "level": "critical" if severity == "critical" else "warning",
                            "severity": severity,
                            "message": f"{severity} 级别问题从 {prev_count} 增至 {latest_count}",
                            "suggestion": "立即审查新增问题",
                        })
        
        return alerts
    
    def _generate_html(self, data: Dict[str, Any]) -> str:
        """生成 HTML 报告"""
        html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>代码质量仪表盘 - {Path(data["project_path"]).name}</title>
    <style>
        * {{ margin: 0; padding: 0; box-sizing: border-box; }}
        body {{
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
            background: #f5f7fa;
            color: #333;
            line-height: 1.6;
        }}
        .container {{
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
        }}
        .header h1 {{ font-size: 28px; margin-bottom: 10px; }}
        .header p {{ opacity: 0.9; }}
        .stats-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .stat-card h3 {{
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
            margin-bottom: 10px;
        }}
        .stat-value {{
            font-size: 32px;
            font-weight: bold;
            color: #333;
        }}
        .stat-change {{
            font-size: 14px;
            margin-top: 5px;
        }}
        .positive {{ color: #10b981; }}
        .negative {{ color: #ef4444; }}
        .section {{
            background: white;
            padding: 25px;
            border-radius: 12px;
            margin-bottom: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }}
        .section h2 {{
            font-size: 20px;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #e5e7eb;
        }}
        .alert {{
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 10px;
        }}
        .alert-warning {{
            background: #fef3c7;
            border-left: 4px solid #f59e0b;
        }}
        .alert-critical {{
            background: #fee2e2;
            border-left: 4px solid #ef4444;
        }}
        .trend-table {{
            width: 100%;
            border-collapse: collapse;
        }}
        .trend-table th, .trend-table td {{
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e5e7eb;
        }}
        .trend-table th {{
            font-weight: 600;
            color: #666;
            font-size: 12px;
            text-transform: uppercase;
        }}
        .rating {{ font-size: 24px; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>代码质量仪表盘</h1>
            <p>{data["project_path"]} | 过去 {data["period_days"]} 天</p>
        </div>
"""
        
        # 统计卡片
        stats = data.get("statistics", {})
        html += '<div class="stats-grid">'
        html += f"""
            <div class="stat-card">
                <h3>审查次数</h3>
                <div class="stat-value">{stats.get("total_reviews", 0)}</div>
            </div>
        """
        
        latest = data.get("latest_review", {})
        html += f"""
            <div class="stat-card">
                <h3>最新评级</h3>
                <div class="stat-value rating">{latest.get("rating", "—")}</div>
            </div>
        """
        
        html += f"""
            <div class="stat-card">
                <h3>平均耗时</h3>
                <div class="stat-value">{stats.get("average_duration", 0):.1f}s</div>
            </div>
        """
        
        improvement = stats.get("improvement_rate", 0)
        change_class = "positive" if improvement > 0 else "negative"
        html += f"""
            <div class="stat-card">
                <h3>改进率</h3>
                <div class="stat-value">{improvement:.1f}%</div>
                <div class="stat-change {change_class}">
                    {"↑" if improvement > 0 else "↓"} {abs(improvement):.1f}%
                </div>
            </div>
        """
        html += '</div>'
        
        # 警报
        alerts = data.get("alerts", [])
        if alerts:
            html += '<div class="section"><h2>质量警报</h2>'
            for alert in alerts:
                level = alert.get("level", "warning")
                html += f"""
                    <div class="alert alert-{level}">
                        <strong>{alert.get("message")}</strong><br>
                        <small>{alert.get("suggestion")}</small>
                    </div>
                """
            html += '</div>'
        
        # 趋势表格
        trends = data.get("trends", {})
        if trends:
            html += '<div class="section"><h2>指标趋势</h2>'
            html += '<table class="trend-table">'
            html += '<tr><th>指标</th><th>当前值</th><th>平均值</th><th>变化</th></tr>'
            
            for metric_key, trend_data in trends.items():
                if isinstance(trend_data, dict) and "current" in trend_data:
                    current = trend_data["current"]
                    avg = trend_data["average"]
                    change = trend_data.get("change", 0)
                    change_class = "positive" if change > 0 else "negative" if change < 0 else ""
                    
                    html += f"""
                        <tr>
                            <td>{metric_key}</td>
                            <td>{current:.2f}</td>
                            <td>{avg:.2f}</td>
                            <td class="{change_class}">{change:+.2f}</td>
                        </tr>
                    """
            
            html += '</table></div>'
        
        html += f"""
        <div class="section">
            <p style="color: #666; font-size: 12px;">
                生成时间: {data["generated_at"]} | 
                code-quality v2.0
            </p>
        </div>
    </div>
</body>
</html>
"""
        
        return html
    
    def _generate_markdown(self, data: Dict[str, Any]) -> str:
        """生成 Markdown 报告"""
        md = f"""# 代码质量仪表盘

**项目**: {data["project_path"]}  
**统计周期**: 过去 {data["period_days"]} 天  
**生成时间**: {data["generated_at"]}

---

## 概览

"""
        
        stats = data.get("statistics", {})
        latest = data.get("latest_review", {})
        
        md += f"""
| 指标 | 数值 |
|------|------|
| 审查次数 | {stats.get("total_reviews", 0)} |
| 最新评级 | {latest.get("rating", "—")} |
| 平均耗时 | {stats.get("average_duration", 0):.1f}s |
| 改进率 | {stats.get("improvement_rate", 0):.1f}% |

"""
        
        # 警报
        alerts = data.get("alerts", [])
        if alerts:
            md += "## 质量警报\n\n"
            for alert in alerts:
                level_emoji = "🔴" if alert.get("level") == "critical" else "🟡"
                md += f"- {level_emoji} **{alert.get('message')}**  \n  {alert.get('suggestion')}\n"
            md += "\n"
        
        # 趋势
        trends = data.get("trends", {})
        if trends:
            md += "## 指标趋势\n\n"
            md += "| 指标 | 当前值 | 平均值 | 变化 |\n"
            md += "|------|--------|--------|------|\n"
            
            for metric_key, trend_data in trends.items():
                if isinstance(trend_data, dict) and "current" in trend_data:
                    current = trend_data["current"]
                    avg = trend_data["average"]
                    change = trend_data.get("change", 0)
                    change_str = f"{change:+.2f}"
                    md += f"| {metric_key} | {current:.2f} | {avg:.2f} | {change_str} |\n"
            
            md += "\n"
        
        md += "---\n\n*由 code-quality v2.0 生成*\n"
        
        return md