"""
报告生成器

支持多种输出格式：Markdown、JSON、SARIF。
"""

import json
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime
from .analyzer import ReviewResult
import logging

logger = logging.getLogger(__name__)


class ReportGenerator:
    """报告生成器"""
    
    def generate(self, result: ReviewResult, 
                format: str = "markdown",
                include_snippets: bool = True,
                snippet_lines: int = 3) -> str:
        """
        生成报告
        
        Args:
            result: 审查结果
            format: 输出格式 (markdown|json|sarif)
            include_snippets: 是否包含代码片段
            snippet_lines: 代码片段行数
            
        Returns:
            报告内容
        """
        if format == "markdown":
            return self._generate_markdown(result, include_snippets, snippet_lines)
        elif format == "json":
            return self._generate_json(result)
        elif format == "sarif":
            return self._generate_sarif(result)
        else:
            raise ValueError(f"不支持的格式: {format}")
    
    def _generate_markdown(self, result: ReviewResult,
                          include_snippets: bool,
                          snippet_lines: int) -> str:
        """生成 Markdown 报告"""
        md = f"""## 代码审查报告

**审查范围**: {result.project_path}  
**审查深度**: {result.review_depth}  
**总体评级**: {result.overall_rating}  
**审查时间**: {result.timestamp}  
**耗时**: {result.duration_seconds:.2f} 秒

### 发现摘要

| 维度 | 评级 | 关键发现 |
|------|------|---------|
"""
        
        for dim in result.dimensions:
            md += f"| {self._dimension_name(dim.dimension)} | {dim.rating} | {dim.summary} |\n"
        
        md += "\n"
        
        # 按严重级别分组问题
        all_issues = []
        for dim in result.dimensions:
            all_issues.extend(dim.issues)
        
        # P0: 必须修复
        critical_issues = [i for i in all_issues if i.severity.value == "critical"]
        high_issues = [i for i in all_issues if i.severity.value == "high"]
        
        if critical_issues or high_issues:
            md += "### 必须修复（P0）\n\n"
            for issue in critical_issues + high_issues:
                md += self._format_issue(issue, include_snippets)
        
        # P1: 建议改进
        medium_issues = [i for i in all_issues if i.severity.value == "medium"]
        if medium_issues:
            md += "### 建议改进（P1）\n\n"
            for issue in medium_issues[:10]:  # 限制数量
                md += self._format_issue(issue, include_snippets)
            if len(medium_issues) > 10:
                md += f"\n*还有 {len(medium_issues) - 10} 个类似问题...*\n"
        
        # P2: 可选优化
        low_issues = [i for i in all_issues if i.severity.value in ("low", "info")]
        if low_issues:
            md += "### 可选优化（P2）\n\n"
            for issue in low_issues[:5]:
                md += self._format_issue(issue, include_snippets)
            if len(low_issues) > 5:
                md += f"\n*还有 {len(low_issues) - 5} 个类似问题...*\n"
        
        # 详细指标
        md += "\n### 详细指标\n\n"
        for dim in result.dimensions:
            if dim.metrics:
                md += f"**{self._dimension_name(dim.dimension)}**:\n"
                for metric, value in dim.metrics.items():
                    if isinstance(value, float):
                        md += f"- {metric}: {value:.2f}\n"
                    else:
                        md += f"- {metric}: {value}\n"
                md += "\n"
        
        md += "---\n\n*由 code-quality 自动生成*\n"
        
        return md
    
    def _format_issue(self, issue, include_snippets: bool) -> str:
        """格式化单个问题"""
        severity_emoji = {
            "critical": "🔴",
            "high": "🟠",
            "medium": "🟡",
            "low": "🔵",
            "info": "⚪",
        }.get(issue.severity.value, "⚪")
        
        md = f"""{severity_emoji} **{issue.message}**
- **位置**: `{issue.file}:{issue.line}:{issue.column}`
- **规则**: {issue.rule_id}
- **建议**: {issue.suggestion}
"""
        
        if include_snippets and issue.snippet:
            md += f"- **代码**:\n```\n{issue.snippet}\n```\n"
        
        md += "\n"
        return md
    
    def _dimension_name(self, dimension) -> str:
        """获取维度中文名"""
        names = {
            "correctness": "正确性",
            "security": "安全性",
            "maintainability": "可维护性",
            "performance": "性能",
        }
        return names.get(dimension.value, dimension.value)
    
    def _generate_json(self, result: ReviewResult) -> str:
        """生成 JSON 报告"""
        return json.dumps(result.to_dict(), indent=2, ensure_ascii=False)
    
    def _generate_sarif(self, result: ReviewResult) -> str:
        """生成 SARIF 报告（GitHub Security 兼容）"""
        sarif = {
            "$schema": "https://raw.githubusercontent.com/oasis-tcs/sarif-spec/master/Schemata/sarif-schema-2.1.0.json",
            "version": "2.1.0",
            "runs": [{
                "tool": {
                    "driver": {
                        "name": "code-quality",
                        "version": "2.0.0",
                        "informationUri": "https://github.com/code-quality",
                    }
                },
                "results": [],
            }]
        }
        
        rules = {}
        results = []
        
        for dim in result.dimensions:
            for issue in dim.issues:
                rule_id = issue.rule_id or f"{dim.dimension.value}-issue"
                
                # 注册规则
                if rule_id not in rules:
                    rules[rule_id] = {
                        "id": rule_id,
                        "name": rule_id,
                        "shortDescription": {
                            "text": issue.message[:100]
                        },
                        "fullDescription": {
                            "text": issue.message
                        },
                        "defaultConfiguration": {
                            "level": self._severity_to_sarif_level(issue.severity)
                        }
                    }
                
                # 添加结果
                sarif_result = {
                    "ruleId": rule_id,
                    "level": self._severity_to_sarif_level(issue.severity),
                    "message": {
                        "text": f"{issue.message}\n\n建议: {issue.suggestion}"
                    },
                    "locations": [{
                        "physicalLocation": {
                            "artifactLocation": {
                                "uri": issue.file,
                            },
                            "region": {
                                "startLine": issue.line,
                                "startColumn": issue.column,
                            }
                        }
                    }]
                }
                
                if issue.snippet:
                    sarif_result["locations"][0]["physicalLocation"]["region"]["snippet"] = {
                        "text": issue.snippet
                    }
                
                results.append(sarif_result)
        
        sarif["runs"][0]["tool"]["driver"]["rules"] = list(rules.values())
        sarif["runs"][0]["results"] = results
        
        return json.dumps(sarif, indent=2, ensure_ascii=False)
    
    def _severity_to_sarif_level(self, severity) -> str:
        """将严重级别转换为 SARIF 级别"""
        mapping = {
            "critical": "error",
            "high": "error",
            "medium": "warning",
            "low": "note",
            "info": "note",
        }
        return mapping.get(severity.value, "warning")