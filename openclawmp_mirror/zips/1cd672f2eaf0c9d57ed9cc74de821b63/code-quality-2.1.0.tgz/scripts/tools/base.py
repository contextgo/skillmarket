"""
工具适配器基类

定义所有工具适配器必须实现的接口。
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import List, Tuple, Dict, Any, Optional
import shutil
import logging

from ..models import Issue

logger = logging.getLogger(__name__)


class ToolAdapter(ABC):
    """工具适配器抽象基类"""
    
    @property
    @abstractmethod
    def tool_name(self) -> str:
        """工具名称"""
        pass
    
    @property
    @abstractmethod
    def supported_dimensions(self) -> List[str]:
        """支持的审查维度"""
        pass
    
    def is_available(self) -> bool:
        """检查工具是否可用"""
        return shutil.which(self.tool_name) is not None
    
    def run(self, project_path: Path, config: Dict[str, Any], 
            dimension: str) -> Tuple[List[Any], Dict[str, Any]]:
        """
        运行工具并返回结果
        
        Args:
            project_path: 项目路径
            config: 工具配置
            dimension: 当前审查维度
            
        Returns:
            (issues, metrics) 元组
        """
        if not self.is_available():
            logger.warning(f"工具 {self.tool_name} 未安装，跳过")
            return [], {}
        
        if dimension not in self.supported_dimensions:
            return [], {}
        
        try:
            return self._execute(project_path, config, dimension)
        except Exception as e:
            logger.error(f"工具 {self.tool_name} 执行失败: {e}")
            return [], {}
    
    @abstractmethod
    def _execute(self, project_path: Path, config: Dict[str, Any],
                 dimension: str) -> Tuple[List[Any], Dict[str, Any]]:
        """
        实际执行工具（子类必须实现）
        """
        pass
    
    def _run_command(self, cmd: List[str], cwd: Optional[Path] = None) -> Tuple[int, str, str]:
        """
        运行命令并返回结果
        
        Args:
            cmd: 命令及参数列表
            cwd: 工作目录
            
        Returns:
            (returncode, stdout, stderr) 元组
        """
        import subprocess
        
        try:
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=True,
                text=True,
                timeout=300,  # 5分钟超时
            )
            return result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired:
            logger.error(f"命令超时: {' '.join(cmd)}")
            return -1, "", "Timeout"
        except Exception as e:
            logger.error(f"命令执行失败: {e}")
            return -1, "", str(e)
    
    def _validate_path(self, path: str, allowed_base: Path) -> bool:
        """
        验证路径是否在允许的目录内（防止目录遍历攻击）
        
        Args:
            path: 要验证的路径
            allowed_base: 允许的基础目录
            
        Returns:
            是否有效
        """
        try:
            target = Path(path).resolve()
            base = allowed_base.resolve()
            return str(target).startswith(str(base))
        except Exception:
            return False