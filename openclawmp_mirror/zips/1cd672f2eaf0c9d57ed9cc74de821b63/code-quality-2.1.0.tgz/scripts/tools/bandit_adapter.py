"""
Bandit 工具适配器

Python 安全漏洞扫描。
"""

import json
import shlex
from pathlib import Path
from typing import List, Tuple, Dict, Any
from .base import ToolAdapter
from ..models import Issue, Severity, Dimension


class BanditAdapter(ToolAdapter):
    """Bandit 适配器"""
    
    @property
    def tool_name(self) -> str:
        return "bandit"
    
    @property
    def supported_dimensions(self) -> List[str]:
        return ["security"]
    
    def _execute(self, project_path: Path, config: Dict[str, Any],
                 dimension: str) -> Tuple[List[Issue], Dict[str, Any]]:
        """执行 Bandit 检查"""
        
        cmd = [
            "bandit",
            "-r",  # 递归
            "-f", "json",  # JSON 输出
            str(project_path),
        ]
        
        # 严重级别过滤
        severity = config.get("severity", "medium")
        cmd.extend(["-ll", self._severity_to_level(severity)])
        
        # 置信度过滤
        confidence = config.get("confidence", "medium")
        cmd.extend(["-ii", self._confidence_to_level(confidence)])
        
        # 跳过的测试
        if config.get("skips"):
            cmd.extend(["-s", ",".join(config["skips"])])
        
        returncode, stdout, stderr = self._run_command(cmd)
        
        issues = []
        metrics = {}
        
        if stdout:
            try:
                bandit_output = json.loads(stdout)
                issues = self._parse_output(bandit_output, project_path)
            except json.JSONDecodeError:
                pass
        
        metrics["security_issues_count"] = len(issues)
        metrics["high_severity_count"] = sum(1 for i in issues if i.severity == Severity.CRITICAL)
        
        return issues, metrics
    
    def _severity_to_level(self, severity: str) -> str:
        """将严重级别转换为 Bandit 级别"""
        mapping = {
            "low": "1",
            "medium": "2",
            "high": "3",
        }
        return mapping.get(severity.lower(), "2")
    
    def _confidence_to_level(self, confidence: str) -> str:
        """将置信度转换为 Bandit 级别"""
        mapping = {
            "low": "1",
            "medium": "2",
            "high": "3",
        }
        return mapping.get(confidence.lower(), "2")
    
    def _parse_output(self, bandit_output: Dict, 
                      project_path: Path) -> List[Issue]:
        """解析 Bandit JSON 输出"""
        issues = []
        
        results = bandit_output.get("results", [])
        
        for result in results:
            severity = self._parse_severity(result.get("issue_severity", "MEDIUM"))
            
            issue = Issue(
                dimension=Dimension.SECURITY,
                severity=severity,
                file=result.get("filename", ""),
                line=result.get("line_number", 0),
                column=result.get("col_offset", 0),
                message=result.get("issue_text", ""),
                rule_id=result.get("test_id", ""),
                suggestion=self._get_suggestion(result.get("test_name", "")),
                snippet=result.get("code", ""),
            )
            issues.append(issue)
        
        return issues
    
    def _parse_severity(self, severity: str) -> Severity:
        """解析严重级别"""
        mapping = {
            "LOW": Severity.LOW,
            "MEDIUM": Severity.MEDIUM,
            "HIGH": Severity.CRITICAL,  # Bandit HIGH 映射为 CRITICAL
        }
        return mapping.get(severity.upper(), Severity.MEDIUM)
    
    def _get_suggestion(self, test_name: str) -> str:
        """根据测试名称获取修复建议"""
        suggestions = {
            "B101": "使用断言时确保不会被优化掉（使用 if not condition: raise AssertionError）",
            "B102": "避免使用 exec 执行动态代码",
            "B103": "设置 subprocess 的 shell=False 防止命令注入",
            "B104": "绑定到 0.0.0.0 会暴露服务到所有网络接口",
            "B105": "硬编码密码存在安全风险，使用环境变量或密钥管理服务",
            "B106": "硬编码密码函数参数，使用安全的密钥管理方式",
            "B107": "函数默认参数中存在硬编码密码",
            "B108": "使用临时文件时确保设置了正确的权限",
            "B110": "try-except-pass 会静默吞掉所有异常，至少记录日志",
            "B301": "pickle 存在反序列化漏洞，避免处理不受信任的数据",
            "B302": "deserialize 存在安全风险，验证输入来源",
            "B303": "使用弱哈希算法（MD5/SHA1），改用 SHA256+",
            "B304": "使用不安全的加密算法，使用现代加密库",
            "B305": "使用不安全的加密模式，使用推荐的加密方案",
            "B306": "使用不安全的随机数生成器，使用 secrets 模块",
            "B307": "eval 存在代码注入风险，避免使用",
            "B308": "mark_safe 可能导致 XSS，确保输入已净化",
            "B309": "HTTPS 连接未验证证书，设置 verify=True",
            "B310": "urllib 请求未验证 URL，可能存在 SSRF 风险",
            "B311": "random 不适用于安全场景，使用 secrets",
            "B312": "telnet 是不安全的协议，使用 SSH",
            "B313": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B314": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B315": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B316": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B317": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B318": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B319": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B320": "XML 解析器存在 XXE 风险，使用 defusedxml",
            "B321": "ftplib 传输未加密，使用 SFTP",
            "B322": "input 在 Python 2 中不安全，使用 raw_input",
            "B323": "SSL/TLS 版本不安全，使用 TLS 1.2+",
            "B324": "使用不安全的哈希函数，使用 hashlib.sha256",
            "B325": "tempnam 存在竞争条件，使用 tempfile 模块",
            "B401": "导入 FTP 模块，考虑使用 SFTP",
            "B402": "导入 pickle 模块，注意反序列化风险",
            "B403": "导入 lxml 模块，注意 XXE 风险",
            "B404": "导入 subprocess 模块，注意命令注入",
            "B405": "导入 xml 模块，注意 XXE 风险",
            "B406": "导入 xml 模块，注意 XXE 风险",
            "B407": "导入 xml 模块，注意 XXE 风险",
            "B408": "导入 xml 模块，注意 XXE 风险",
            "B409": "导入 xml 模块，注意 XXE 风险",
            "B410": "导入 lxml 模块，注意 XXE 风险",
            "B411": "导入 XMLParser 类，注意 XXE 风险",
            "B412": "导入 httpoxy 相关模块，注意代理劫持",
            "B413": "导入 pycrypto 模块，使用 pycryptodome",
            "B414": "导入 xml 模块，注意 XXE 风险",
        }
        return suggestions.get(test_name, "参考 Bandit 文档修复安全问题")
