"""
Go 工具适配器

Go 代码质量检查（golint + go vet + staticcheck）。
"""

import re
from pathlib import Path
from typing import List, Tuple, Dict, Any
from .base import ToolAdapter
from ..models import Issue, Severity, Dimension


class GoLintAdapter(ToolAdapter):
    """Go Lint 适配器（整合 golint, go vet, staticcheck）"""
    
    @property
    def tool_name(self) -> str:
        return "golint"
    
    @property
    def supported_dimensions(self) -> List[str]:
        return ["maintainability", "correctness"]
    
    def _execute(self, project_path: Path, config: Dict[str, Any],
                 dimension: str) -> Tuple[List[Issue], Dict[str, Any]]:
        """执行 Go 代码检查"""
        
        issues = []
        metrics = {}
        
        # 1. 运行 go vet
        vet_issues = self._run_go_vet(project_path)
        issues.extend(vet_issues)
        
        # 2. 运行 golint（如果可用）
        if self._is_tool_available("golint"):
            golint_issues = self._run_golint(project_path, config)
            issues.extend(golint_issues)
        
        # 3. 运行 staticcheck（如果可用）
        if self._is_tool_available("staticcheck"):
            staticcheck_issues = self._run_staticcheck(project_path, config)
            issues.extend(staticcheck_issues)
        
        metrics["go_issues_count"] = len(issues)
        metrics["go_vet_count"] = len(vet_issues)
        
        return issues, metrics
    
    def _is_tool_available(self, tool: str) -> bool:
        """检查工具是否可用"""
        import shutil
        return shutil.which(tool) is not None
    
    def _run_go_vet(self, project_path: Path) -> List[Issue]:
        """运行 go vet"""
        issues = []
        
        cmd = ["go", "vet", "./..."]
        returncode, stdout, stderr = self._run_command(cmd, cwd=project_path)
        
        # go vet 输出到 stderr
        output = stderr or stdout
        if output:
            issues.extend(self._parse_go_vet_output(output))
        
        return issues
    
    def _run_golint(self, project_path: Path, config: Dict[str, Any]) -> List[Issue]:
        """运行 golint"""
        issues = []
        
        cmd = ["golint"]
        
        # 最小置信度
        min_confidence = config.get("min_confidence", 0.8)
        cmd.extend(["-min_confidence", str(min_confidence)])
        
        cmd.append("./...")
        
        returncode, stdout, stderr = self._run_command(cmd, cwd=project_path)
        
        if stdout:
            issues.extend(self._parse_golint_output(stdout))
        
        return issues
    
    def _run_staticcheck(self, project_path: Path, config: Dict[str, Any]) -> List[Issue]:
        """运行 staticcheck"""
        issues = []
        
        cmd = ["staticcheck", "./..."]
        
        returncode, stdout, stderr = self._run_command(cmd, cwd=project_path)
        
        if stdout:
            issues.extend(self._parse_staticcheck_output(stdout))
        
        return issues
    
    def _parse_go_vet_output(self, output: str) -> List[Issue]:
        """解析 go vet 输出"""
        issues = []
        
        # 格式: file:line: message
        pattern = r'^(.*?):(\d+):\s*(.+)$'
        
        for line in output.split('\n'):
            match = re.match(pattern, line.strip())
            if not match:
                continue
            
            file_path = match.group(1)
            line_num = int(match.group(2))
            message = match.group(3)
            
            issue = Issue(
                dimension=Dimension.CORRECTNESS,
                severity=Severity.HIGH,
                file=file_path,
                line=line_num,
                column=0,
                message=message,
                rule_id="go-vet",
                suggestion=self._get_go_vet_suggestion(message),
            )
            issues.append(issue)
        
        return issues
    
    def _parse_golint_output(self, output: str) -> List[Issue]:
        """解析 golint 输出"""
        issues = []
        
        # 格式: file:line:col: message
        pattern = r'^(.*?):(\d+):(\d+):\s*(.+)$'
        
        for line in output.split('\n'):
            match = re.match(pattern, line.strip())
            if not match:
                continue
            
            file_path = match.group(1)
            line_num = int(match.group(2))
            col_num = int(match.group(3))
            message = match.group(4)
            
            issue = Issue(
                dimension=Dimension.MAINTAINABILITY,
                severity=Severity.LOW,
                file=file_path,
                line=line_num,
                column=col_num,
                message=message,
                rule_id="golint",
                suggestion=self._get_golint_suggestion(message),
            )
            issues.append(issue)
        
        return issues
    
    def _parse_staticcheck_output(self, output: str) -> List[Issue]:
        """解析 staticcheck 输出"""
        issues = []
        
        # 格式: file:line:col: message (SAxxxx)
        pattern = r'^(.*?):(\d+):(\d+):\s*(.+?)\s*\((SA\d+)\)$'
        
        for line in output.split('\n'):
            match = re.match(pattern, line.strip())
            if not match:
                continue
            
            file_path = match.group(1)
            line_num = int(match.group(2))
            col_num = int(match.group(3))
            message = match.group(4)
            check_id = match.group(5)
            
            # staticcheck 检查 ID 决定严重级别
            severity = self._staticcheck_severity(check_id)
            
            issue = Issue(
                dimension=Dimension.CORRECTNESS if severity == Severity.HIGH else Dimension.MAINTAINABILITY,
                severity=severity,
                file=file_path,
                line=line_num,
                column=col_num,
                message=message,
                rule_id=check_id,
                suggestion=self._get_staticcheck_suggestion(check_id),
            )
            issues.append(issue)
        
        return issues
    
    def _staticcheck_severity(self, check_id: str) -> Severity:
        """根据 staticcheck ID 确定严重级别"""
        # SA1xxx: 错误
        # SA2xxx: 警告
        # SA4xxx: 简化建议
        # SA5xxx: 代码风格
        # SA6xxx: 性能
        
        if check_id.startswith("SA1"):
            return Severity.HIGH
        elif check_id.startswith("SA2"):
            return Severity.MEDIUM
        elif check_id.startswith("SA6"):
            return Severity.MEDIUM
        else:
            return Severity.LOW
    
    def _get_go_vet_suggestion(self, message: str) -> str:
        """根据 go vet 消息获取建议"""
        suggestions = {
            "Printf": "格式化字符串参数不匹配，检查格式动词和参数数量",
            "unrecognized printf verb": "Printf 格式动词无效",
            "composite literal uses unkeyed fields": "使用带字段名的复合字面量，提高可读性",
            "possible misuse of unsafe.Pointer": "检查 unsafe.Pointer 使用是否正确",
            "error result not checked": "检查函数返回的错误值",
        }
        
        for key, suggestion in suggestions.items():
            if key in message:
                return suggestion
        
        return "参考 go vet 文档修复此问题"
    
    def _get_golint_suggestion(self, message: str) -> str:
        """根据 golint 消息获取建议"""
        suggestions = {
            "should have comment": "添加文档注释说明导出项的用途",
            "comment on exported": "导出项应有文档注释",
            "stutters": "名称与包名重复，简化命名",
            "name will be used as": "包名与类型名组合后重复",
            "don't use underscores": "Go 命名不应使用下划线",
            "don't use ALL_CAPS": "Go 命名不应使用全大写",
        }
        
        for key, suggestion in suggestions.items():
            if key in message:
                return suggestion
        
        return "参考 Go 代码规范修改"
    
    def _get_staticcheck_suggestion(self, check_id: str) -> str:
        """根据 staticcheck ID 获取建议"""
        suggestions = {
            "SA1000": "正则表达式无效，检查语法",
            "SA1001": "模板解析错误",
            "SA1002": "错误的时间格式",
            "SA1003": "不支持的 UTF-8 编码",
            "SA1004": "小睡眠时间可能无效",
            "SA1005": "无用的 fmt.Sprint 调用",
            "SA1006": "Printf 没有格式化动词",
            "SA1007": "URL 解析错误",
            "SA1008": "非正数作为非负参数",
            "SA1010": "regexp.Match 中的括号错误",
            "SA1011": "各种内存别名问题",
            "SA1012": "向 nil 通道发送或接收",
            "SA1013": "io.Seeker 使用错误",
            "SA1014": "错误的 Marshal 调用",
            "SA1015": "使用了已弃用的方法",
            "SA1016": "Trap 信号不可捕获",
            "SA1017": "通道方向错误",
            "SA1018": "strings.Replace 参数错误",
            "SA1019": "使用了已弃用的包/函数",
            "SA1020": "使用了已弃用的 API",
            "SA1021": "使用了已弃用的 API",
            "SA1023": "修改了 range 循环变量",
            "SA1024": "有问题的 API 使用",
            "SA1025": "timer.Reset 使用错误",
            "SA1026": "无法通过 HTTP 传递的通道",
            "SA1027": "atomic 对齐问题",
            "SA1028": "sort 接口实现错误",
            "SA1029": "不推荐的函数使用",
            "SA1030": "strconv.Atoi 错误处理",
            "SA2000": "sync.WaitGroup 错误使用",
            "SA2001": "空的临界区",
            "SA2002": "testing.T 错误使用",
            "SA2003": "Deferred Lock 未解锁",
            "SA3000": "TestMain 没有调用 m.Run()",
            "SA3001": "将 math/rand 的随机数赋值给变量",
            "SA4000": "布尔表达式总是 true/false",
            "SA4001": "&*x 可以简化为 x",
            "SA4003": "比较恒为真或恒为假",
            "SA4004": "循环条件永真或永假",
            "SA4005": "字段赋值永不可达",
            "SA4006": "值未被使用",
            "SA4008": "循环变量在内部函数中使用",
            "SA4009": "函数参数被覆盖",
            "SA4010": "结果未被使用",
            "SA4011": "break 在 select 中无效",
            "SA4012": "比较结果与另一个比较",
            "SA4013": "指针与 nil 比较后解引用",
            "SA4014": "循环内使用 panic/recover",
            "SA4015": "math.Ceil 结果转为 int",
            "SA4016": "某些位操作无意义",
            "SA4017": "对时间取反无意义",
            "SA4018": "自赋值",
            "SA4019": "同名变量在不同作用域",
            "SA4020": "Unreachable case",
            "SA4021": "x = append(y) 是 append 的误用",
            "SA4022": "对 nil 进行类型断言",
            "SA4023": "Impossible comparison",
            "SA4024": "检查字节是否包含字符串",
            "SA4025": "整数除法后转浮点",
            "SA4026": "Go 版本相关的弃用",
            "SA4027": "(*net/url.URL).Query 返回的 map 不应修改",
            "SA4028": "x = range",
            "SA4029": "rand.Seed 的误用",
            "SA4030": "crypto/rand 的误用",
            "SA4031": "检查 never nil 的值",
            "SA5000": "赋值给 nil map",
            "SA5001": "defer Close 在检查错误之前",
            "SA5002": "空 select",
            "SA5003": "defer 在 return 之后",
            "SA5004": "for {} 循环没有 break",
            "SA5005": "最终的零值赋值",
            "SA5007": "无限递归调用",
            "SA5008": "结构体标签重复",
            "SA5009": "Printf 格式错误",
            "SA5010": "不可能的类型断言",
            "SA5011": "可能的 nil 指针解引用",
            "SA5012": "通过 range 循环传递指针",
            "SA6000": "使用 regexp.Match 在循环中",
            "SA6001": "缺失的 context 取消",
            "SA6002": "将 slice 转为 map",
            "SA6003": "将 string 转为 []byte 再转为 string",
            "SA6005": "将 ints 转为 string 使用 fmt.Sprintf",
            "SA9001": "Defer 在循环中",
            "SA9002": "非指针类型的非导出字段",
            "SA9003": "空函数体",
            "SA9004": "只读 channel 被关闭",
            "SA9005": "没有默认 case 的 type switch",
            "SA9006": "重复的 case 条件",
            "SA9007": "有副作用的 defer 参数",
        }
        
        return suggestions.get(check_id, "参考 staticcheck 文档")