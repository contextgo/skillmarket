"""
Pylint 工具适配器

Python 代码质量和风格检查。
"""

import json
import shlex
from pathlib import Path
from typing import List, Tuple, Dict, Any
from .base import ToolAdapter
from ..models import Issue, Severity, Dimension


class PylintAdapter(ToolAdapter):
    """Pylint 适配器"""
    
    @property
    def tool_name(self) -> str:
        return "pylint"
    
    @property
    def supported_dimensions(self) -> List[str]:
        return ["maintainability", "correctness"]
    
    def _execute(self, project_path: Path, config: Dict[str, Any],
                 dimension: str) -> Tuple[List[Issue], Dict[str, Any]]:
        """执行 Pylint 检查"""
        
        # 构建命令
        cmd = [
            "pylint",
            "--output-format=json",
            "--persistent=no",
        ]
        
        # 添加配置文件（使用 shlex.quote 防止命令注入）
        if config.get("config_file"):
            config_file = config["config_file"]
            # 验证路径在项目目录内
            if self._validate_path(config_file, project_path):
                cmd.extend(["--rcfile", shlex.quote(config_file)])
            else:
                logger.warning(f"配置文件路径无效，跳过: {config_file}")
        
        # 添加禁用规则
        if config.get("disable"):
            cmd.extend(["--disable", ",".join(config["disable"])])
        
        # 添加启用规则
        if config.get("enable"):
            cmd.extend(["--enable", ",".join(config["enable"])])
        
        # 指定检查路径
        cmd.append(str(project_path))
        
        # 执行命令
        returncode, stdout, stderr = self._run_command(cmd)
        
        issues = []
        metrics = {}
        
        if stdout:
            try:
                pylint_output = json.loads(stdout)
                issues = self._parse_output(pylint_output, project_path)
            except json.JSONDecodeError:
                pass
        
        # 计算指标
        metrics["pylint_score"] = self._extract_score(stderr)
        metrics["pylint_issues_count"] = len(issues)
        
        return issues, metrics
    
    def _parse_output(self, pylint_output: List[Dict], 
                      project_path: Path) -> List[Issue]:
        """解析 Pylint JSON 输出"""
        issues = []
        
        # Pylint 类型到严重级别的映射
        type_to_severity = {
            "error": Severity.HIGH,
            "warning": Severity.MEDIUM,
            "convention": Severity.LOW,
            "refactor": Severity.LOW,
            "information": Severity.INFO,
        }
        
        # Pylint 类型到维度的映射
        type_to_dimension = {
            "error": Dimension.CORRECTNESS,
            "warning": Dimension.MAINTAINABILITY,
            "convention": Dimension.MAINTAINABILITY,
            "refactor": Dimension.MAINTAINABILITY,
            "information": Dimension.MAINTAINABILITY,
        }
        
        for item in pylint_output:
            msg_type = item.get("type", "warning")
            
            issue = Issue(
                dimension=type_to_dimension.get(msg_type, Dimension.MAINTAINABILITY),
                severity=type_to_severity.get(msg_type, Severity.MEDIUM),
                file=item.get("path", ""),
                line=item.get("line", 0),
                column=item.get("column", 0),
                message=item.get("message", ""),
                rule_id=item.get("symbol", ""),
                suggestion=self._get_suggestion(item.get("symbol", "")),
            )
            issues.append(issue)
        
        return issues
    
    def _extract_score(self, stderr: str) -> float:
        """从 stderr 中提取 Pylint 分数"""
        # Pylint 分数通常在 stderr 的最后一行
        for line in reversed(stderr.split("\n")):
            if "Your code has been rated at" in line:
                try:
                    # 提取 "10/10" 或 "8.5/10" 这样的格式
                    import re
                    match = re.search(r"(\d+\.?\d*)/10", line)
                    if match:
                        return float(match.group(1))
                except:
                    pass
        return 0.0
    
    def _get_suggestion(self, rule_id: str) -> str:
        """根据规则 ID 获取建议"""
        suggestions = {
            "missing-docstring": "添加文档字符串说明函数/类用途",
            "invalid-name": "使用符合 PEP8 规范的命名",
            "line-too-long": "将长行拆分为多行",
            "unused-import": "删除未使用的导入",
            "unused-variable": "删除未使用的变量",
            "redefined-outer-name": "避免变量名与外部作用域冲突",
            "too-many-arguments": "考虑使用配置对象或拆分函数",
            "too-many-branches": "考虑简化逻辑或提取函数",
            "too-many-statements": "函数过长，考虑拆分",
            "duplicate-code": "提取重复逻辑为公共函数",
        }
        return suggestions.get(rule_id, "参考 Pylint 文档修复此问题")