"""
ESLint 工具适配器

TypeScript/JavaScript 代码质量和风格检查。
"""

import json
import shlex
from pathlib import Path
from typing import List, Tuple, Dict, Any
from .base import ToolAdapter
from ..models import Issue, Severity, Dimension


class ESLintAdapter(ToolAdapter):
    """ESLint 适配器"""
    
    @property
    def tool_name(self) -> str:
        return "eslint"
    
    @property
    def supported_dimensions(self) -> List[str]:
        return ["maintainability", "correctness", "security"]
    
    def _execute(self, project_path: Path, config: Dict[str, Any],
                 dimension: str) -> Tuple[List[Issue], Dict[str, Any]]:
        """执行 ESLint 检查"""
        
        cmd = [
            "eslint",
            "--format=json",
            "--ext", ".js,.jsx,.ts,.tsx",
        ]
        
        # 添加配置文件
        if config.get("config_file"):
            config_file = config["config_file"]
            if self._validate_path(config_file, project_path):
                cmd.extend(["--config", shlex.quote(config_file)])
            else:
                self.logger.warning(f"配置文件路径无效，跳过: {config_file}")
        
        # 指定检查路径
        cmd.append(str(project_path))
        
        returncode, stdout, stderr = self._run_command(cmd, cwd=project_path)
        
        issues = []
        metrics = {}
        
        if stdout:
            try:
                eslint_output = json.loads(stdout)
                issues = self._parse_output(eslint_output, project_path)
            except json.JSONDecodeError:
                pass
        
        metrics["eslint_issues_count"] = len(issues)
        metrics["eslint_error_count"] = sum(1 for i in issues if i.severity == Severity.HIGH)
        metrics["eslint_warning_count"] = sum(1 for i in issues if i.severity == Severity.MEDIUM)
        
        return issues, metrics
    
    def _parse_output(self, eslint_output: List[Dict], 
                      project_path: Path) -> List[Issue]:
        """解析 ESLint JSON 输出"""
        issues = []
        
        for file_result in eslint_output:
            file_path = file_result.get("filePath", "")
            messages = file_result.get("messages", [])
            
            for msg in messages:
                severity = self._map_severity(msg.get("severity", 1))
                
                # 映射维度
                rule_id = msg.get("ruleId", "")
                dimension = self._map_dimension(rule_id)
                
                issue = Issue(
                    dimension=dimension,
                    severity=severity,
                    file=file_path,
                    line=msg.get("line", 0),
                    column=msg.get("column", 0),
                    message=msg.get("message", ""),
                    rule_id=rule_id or "eslint-error",
                    suggestion=self._get_suggestion(rule_id),
                )
                issues.append(issue)
        
        return issues
    
    def _map_severity(self, severity: int) -> Severity:
        """映射 ESLint 严重级别"""
        # ESLint: 2=error, 1=warning, 0=off
        mapping = {
            2: Severity.HIGH,
            1: Severity.MEDIUM,
        }
        return mapping.get(severity, Severity.LOW)
    
    def _map_dimension(self, rule_id: str) -> Dimension:
        """根据规则 ID 映射维度"""
        security_rules = [
            "security", "no-eval", "no-implied-eval", "no-new-func",
            "no-script-url", "react/no-danger"
        ]
        
        if any(s in rule_id.lower() for s in security_rules):
            return Dimension.SECURITY
        
        correctness_rules = [
            "no-undef", "no-unused-vars", "no-unreachable",
            "@typescript-eslint/no-unused-vars"
        ]
        
        if any(c in rule_id.lower() for c in correctness_rules):
            return Dimension.CORRECTNESS
        
        return Dimension.MAINTAINABILITY
    
    def _get_suggestion(self, rule_id: str) -> str:
        """根据规则 ID 获取建议"""
        suggestions = {
            "no-unused-vars": "删除未使用的变量，或检查变量名拼写",
            "no-undef": "变量未定义，检查拼写或添加导入",
            "no-console": "生产代码中应避免使用 console.log",
            "no-eval": "eval 存在安全风险，避免使用",
            "@typescript-eslint/no-explicit-any": "避免使用 any 类型，使用具体类型或 unknown",
            "@typescript-eslint/explicit-function-return-type": "为函数添加返回类型注解",
            "react-hooks/exhaustive-deps": "检查 useEffect 依赖数组是否完整",
            "import/no-unresolved": "检查导入路径是否正确",
        }
        return suggestions.get(rule_id, "参考 ESLint 文档修复此问题")