"""
TypeScript Compiler 适配器

TypeScript 类型检查。
"""

import json
import re
from pathlib import Path
from typing import List, Tuple, Dict, Any
from .base import ToolAdapter
from ..models import Issue, Severity, Dimension


class TSCAdapter(ToolAdapter):
    """TypeScript Compiler 适配器"""
    
    @property
    def tool_name(self) -> str:
        return "tsc"
    
    @property
    def supported_dimensions(self) -> List[str]:
        return ["correctness"]
    
    def _execute(self, project_path: Path, config: Dict[str, Any],
                 dimension: str) -> Tuple[List[Issue], Dict[str, Any]]:
        """执行 TypeScript 类型检查"""
        
        cmd = [
            "tsc",
            "--noEmit",  # 不输出文件，只检查
            "--pretty", "false",  # 禁用颜色，便于解析
        ]
        
        # 严格模式
        if config.get("strict"):
            cmd.append("--strict")
        
        # 指定项目配置
        tsconfig_path = project_path / "tsconfig.json"
        if tsconfig_path.exists():
            cmd.extend(["--project", str(tsconfig_path)])
        else:
            # 检查所有 ts 文件
            cmd.extend([str(project_path / "**" / "*.ts")])
        
        returncode, stdout, stderr = self._run_command(cmd, cwd=project_path)
        
        issues = []
        metrics = {}
        
        # tsc 输出到 stderr
        output = stderr or stdout
        if output:
            issues = self._parse_output(output, project_path)
        
        metrics["tsc_issues_count"] = len(issues)
        metrics["tsc_error_count"] = sum(1 for i in issues if i.severity == Severity.HIGH)
        
        return issues, metrics
    
    def _parse_output(self, output: str, project_path: Path) -> List[Issue]:
        """解析 tsc 输出"""
        issues = []
        
        # tsc 错误格式: file(line,col): error TSxxxx: message
        pattern = r'^(.*?)(?:\((\d+),(\d+)\))?:\s*(error|warning)\s+(TS\d+):\s*(.+)$'
        
        for line in output.split('\n'):
            match = re.match(pattern, line.strip())
            if not match:
                continue
            
            file_path = match.group(1) or ""
            line_num = int(match.group(2)) if match.group(2) else 0
            col_num = int(match.group(3)) if match.group(3) else 0
            level = match.group(4)
            error_code = match.group(5)
            message = match.group(6)
            
            severity = Severity.HIGH if level == "error" else Severity.MEDIUM
            
            issue = Issue(
                dimension=Dimension.CORRECTNESS,
                severity=severity,
                file=file_path,
                line=line_num,
                column=col_num,
                message=message,
                rule_id=error_code,
                suggestion=self._get_suggestion(error_code, message),
            )
            issues.append(issue)
        
        return issues
    
    def _get_suggestion(self, error_code: str, message: str) -> str:
        """根据错误码获取建议"""
        suggestions = {
            "TS2322": "类型不兼容，检查赋值两边的类型是否匹配",
            "TS2345": "参数类型错误，检查函数调用参数",
            "TS2304": "找不到名称，检查变量是否已定义或导入",
            "TS7006": "参数隐式为 any 类型，添加类型注解",
            "TS7005": "变量隐式为 any 类型，添加类型注解",
            "TS2554": "参数数量错误，检查函数调用参数个数",
            "TS2349": "无法调用此表达式，检查是否为函数类型",
            "TS2531": "对象可能为 null，添加 null 检查",
            "TS2532": "对象可能为 undefined，添加 undefined 检查",
        }
        
        # 根据消息内容匹配
        if "cannot find name" in message.lower():
            return "变量未定义，检查拼写或添加导入"
        if "is not assignable" in message.lower():
            return "类型不兼容，检查赋值两边的类型"
        if "possibly undefined" in message.lower():
            return "添加 undefined 检查或使用可选链操作符 ?."
        
        return suggestions.get(error_code, "参考 TypeScript 文档修复类型错误")