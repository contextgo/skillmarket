"""
Mypy 工具适配器

Python 静态类型检查。
"""

import json
import shlex
from pathlib import Path
from typing import List, Tuple, Dict, Any
from .base import ToolAdapter
from ..models import Issue, Severity, Dimension


class MypyAdapter(ToolAdapter):
    """Mypy 适配器"""
    
    @property
    def tool_name(self) -> str:
        return "mypy"
    
    @property
    def supported_dimensions(self) -> List[str]:
        return ["correctness"]
    
    def _execute(self, project_path: Path, config: Dict[str, Any],
                 dimension: str) -> Tuple[List[Issue], Dict[str, Any]]:
        """执行 Mypy 检查"""
        
        cmd = [
            "mypy",
            "--show-error-codes",
            "--show-column-numbers",
            "--no-error-summary",
        ]
        
        # 添加配置选项
        if config.get("strict"):
            cmd.append("--strict")
        
        if config.get("python_version"):
            cmd.extend(["--python-version", config["python_version"]])
        
        if config.get("warn_return_any"):
            cmd.append("--warn-return-any")
        
        if config.get("disallow_untyped_defs"):
            cmd.append("--disallow-untyped-defs")
        
        cmd.append(str(project_path))
        
        returncode, stdout, stderr = self._run_command(cmd)
        
        issues = []
        metrics = {}
        
        if stdout:
            issues = self._parse_output(stdout, project_path)
        
        metrics["mypy_issues_count"] = len(issues)
        metrics["type_coverage"] = self._estimate_type_coverage(issues, project_path)
        
        return issues, metrics
    
    def _parse_output(self, output: str, project_path: Path) -> List[Issue]:
        """解析 Mypy 输出"""
        issues = []
        
        for line in output.strip().split("\n"):
            if not line or ":" not in line:
                continue
            
            try:
                # 格式: file:line:col: severity: message [error-code]
                parts = line.split(":", 3)
                if len(parts) < 4:
                    continue
                
                file_path = parts[0]
                line_num = int(parts[1]) if parts[1].isdigit() else 0
                col_num = int(parts[2]) if parts[2].isdigit() else 0
                
                message_part = parts[3].strip()
                
                # 提取严重级别
                severity = Severity.MEDIUM
                if "error:" in message_part.lower():
                    severity = Severity.HIGH
                    message_part = message_part.replace("error:", "").strip()
                elif "warning:" in message_part.lower():
                    severity = Severity.MEDIUM
                    message_part = message_part.replace("warning:", "").strip()
                
                # 提取错误码
                rule_id = ""
                if "[" in message_part and "]" in message_part:
                    start = message_part.rfind("[")
                    end = message_part.rfind("]")
                    if start != -1 and end != -1:
                        rule_id = message_part[start+1:end]
                        message_part = message_part[:start].strip()
                
                issue = Issue(
                    dimension=Dimension.CORRECTNESS,
                    severity=severity,
                    file=file_path,
                    line=line_num,
                    column=col_num,
                    message=message_part,
                    rule_id=rule_id or "type-error",
                    suggestion=self._get_suggestion(rule_id, message_part),
                )
                issues.append(issue)
                
            except Exception:
                continue
        
        return issues
    
    def _estimate_type_coverage(self, issues: List[Issue], 
                                 project_path: Path) -> float:
        """估算类型覆盖率（简化版）"""
        # 实际实现需要统计有类型注解的函数比例
        # 这里使用启发式估算
        if not issues:
            return 100.0
        
        # 根据问题数量估算
        untyped_issues = [i for i in issues if "untyped" in i.message.lower()]
        if not untyped_issues:
            return 95.0
        
        return max(0, 100 - len(untyped_issues) * 5)
    
    def _get_suggestion(self, rule_id: str, message: str) -> str:
        """根据错误类型获取建议"""
        if "untyped" in message.lower():
            return "为函数参数和返回值添加类型注解"
        elif "incompatible" in message.lower():
            return "检查类型是否匹配，必要时进行类型转换或调整"
        elif "missing" in message.lower():
            return "补充缺失的类型定义"
        elif "return" in message.lower():
            return "确保返回值类型与声明一致"
        return "参考 Mypy 文档修复类型问题"
