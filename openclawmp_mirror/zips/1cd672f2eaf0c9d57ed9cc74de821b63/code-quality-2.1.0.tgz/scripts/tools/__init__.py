"""
工具适配器模块

为各种代码检查工具提供统一的接口。
"""

from typing import Optional, Type
from .base import ToolAdapter
from .pylint_adapter import PylintAdapter
from .mypy_adapter import MypyAdapter
from .bandit_adapter import BanditAdapter
from .eslint_adapter import ESLintAdapter
from .tsc_adapter import TSCAdapter
from .golint_adapter import GoLintAdapter

# 工具注册表
_TOOL_REGISTRY = {
    # Python 工具
    ("python", "pylint"): PylintAdapter,
    ("python", "mypy"): MypyAdapter,
    ("python", "bandit"): BanditAdapter,
    
    # TypeScript/JavaScript 工具
    ("typescript", "eslint"): ESLintAdapter,
    ("typescript", "tsc"): TSCAdapter,
    
    # Go 工具
    ("go", "golint"): GoLintAdapter,
}


def get_tool_adapter(language: str, tool_name: str) -> Optional[ToolAdapter]:
    """
    获取工具适配器实例
    
    Args:
        language: 编程语言
        tool_name: 工具名称
        
    Returns:
        工具适配器实例，如果不存在则返回 None
    """
    adapter_class = _TOOL_REGISTRY.get((language, tool_name))
    if adapter_class:
        return adapter_class()
    return None


def register_tool_adapter(language: str, tool_name: str, 
                          adapter_class: Type[ToolAdapter]) -> None:
    """
    注册新的工具适配器
    
    Args:
        language: 编程语言
        tool_name: 工具名称
        adapter_class: 适配器类
    """
    _TOOL_REGISTRY[(language, tool_name)] = adapter_class


def list_available_adapters() -> dict:
    """
    列出所有可用的适配器
    
    Returns:
        {language: [tool_names]}
    """
    result = {}
    for (lang, tool), adapter_class in _TOOL_REGISTRY.items():
        if lang not in result:
            result[lang] = []
        result[lang].append({
            "name": tool,
            "class": adapter_class.__name__,
            "dimensions": adapter_class().supported_dimensions if adapter_class else []
        })
    return result


__all__ = [
    "ToolAdapter",
    "get_tool_adapter",
    "register_tool_adapter",
    "list_available_adapters",
    # 具体适配器类
    "PylintAdapter",
    "MypyAdapter",
    "BanditAdapter",
    "ESLintAdapter",
    "TSCAdapter",
    "GoLintAdapter",
]