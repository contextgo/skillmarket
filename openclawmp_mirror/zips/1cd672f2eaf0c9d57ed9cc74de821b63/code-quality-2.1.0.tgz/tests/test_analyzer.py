"""
code-quality 单元测试
"""

import unittest
import tempfile
import json
from pathlib import Path
from scripts.models import Issue, Severity, Dimension
from scripts.analyzer import CodeQualityAnalyzer
from scripts.database import HistoryDatabase
from scripts.report import ReportGenerator


class TestCodeQualityAnalyzer(unittest.TestCase):
    """测试分析器"""
    
    def setUp(self):
        """创建临时项目目录"""
        self.temp_dir = tempfile.mkdtemp()
        self.project_path = Path(self.temp_dir)
        
        # 创建测试 Python 文件
        (self.project_path / "test_module.py").write_text("""
def hello():
    return "Hello"

def complex_function(x):
    if x > 0:
        if x > 10:
            if x > 100:
                return "big"
            return "medium"
        return "small"
    return "negative"
""")
    
    def test_analyze_quick(self):
        """测试快速审查"""
        analyzer = CodeQualityAnalyzer(self.project_path)
        result = analyzer.analyze(depth="quick")
        
        self.assertEqual(result.review_depth, "quick")
        self.assertIn(result.overall_rating, ["🟢 通过", "🟡 有改进空间", "🔴 需修复"])
        
        # 快速审查只检查 2 个维度
        self.assertLessEqual(len(result.dimensions), 2)
    
    def test_analyze_standard(self):
        """测试标准审查"""
        analyzer = CodeQualityAnalyzer(self.project_path)
        result = analyzer.analyze(depth="standard")
        
        self.assertEqual(result.review_depth, "standard")
        self.assertEqual(len(result.dimensions), 4)
    
    def test_detect_language(self):
        """测试语言检测"""
        analyzer = CodeQualityAnalyzer(self.project_path)
        language = analyzer._detect_language()
        
        self.assertEqual(language, "python")
    
    def test_performance_pattern_detection(self):
        """测试性能模式检测"""
        # 创建包含性能问题的文件
        (self.project_path / "perf_test.py").write_text("""
# N+1 查询模式
for user in users:
    print(user.name)
    order = Order.objects.filter(user=user).first()  # N+1 问题

# 字符串拼接
result = ""
for item in items:
    result += item  # 应该使用 join
""")
        
        analyzer = CodeQualityAnalyzer(self.project_path)
        issues, metrics = analyzer._detect_performance_patterns()
        
        # 应该检测到性能问题
        self.assertGreater(len(issues), 0)
        self.assertIn("performance_patterns_checked", metrics)
    
    def tearDown(self):
        """清理临时目录"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)


class TestHistoryDatabase(unittest.TestCase):
    """测试历史数据库"""
    
    def setUp(self):
        """创建临时数据库"""
        self.temp_dir = tempfile.mkdtemp()
        self.db_path = Path(self.temp_dir) / "test.db"
        self.db = HistoryDatabase(str(self.db_path))
    
    def test_save_and_retrieve(self):
        """测试保存和检索"""
        from scripts.models import ReviewResult, DimensionResult
        import time
        
        # 创建模拟结果
        result = ReviewResult(
            project_path="/test/project",
            review_depth="standard",
            overall_rating="🟢 通过",
            dimensions=[
                DimensionResult(
                    dimension=Dimension.CORRECTNESS,
                    rating="🟢",
                    issues=[],
                    metrics={"test_coverage": 85.5},
                    summary="测试覆盖良好"
                )
            ],
            timestamp="2026-03-16 10:00:00",
            duration_seconds=10.5
        )
        
        # 保存
        review_id = self.db.save_review("/test/project", result)
        self.assertGreater(review_id, 0)
        
        # 检索
        history = self.db.get_project_history("/test/project")
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0]["overall_rating"], "🟢 通过")
    
    def test_metric_trend(self):
        """测试指标趋势"""
        # 这里需要先有数据
        trend = self.db.get_metric_trend("/test/project", "test_coverage")
        self.assertIsInstance(trend, list)
    
    def tearDown(self):
        """清理"""
        import shutil
        shutil.rmtree(self.temp_dir, ignore_errors=True)


class TestReportGenerator(unittest.TestCase):
    """测试报告生成器"""
    
    def setUp(self):
        """创建模拟结果"""
        from scripts.models import ReviewResult, DimensionResult
        
        self.result = ReviewResult(
            project_path="/test/project",
            review_depth="standard",
            overall_rating="🟢 通过",
            dimensions=[
                DimensionResult(
                    dimension=Dimension.CORRECTNESS,
                    rating="🟢",
                    issues=[],
                    metrics={"coverage": 85.0},
                    summary="良好"
                )
            ],
            timestamp="2026-03-16 10:00:00",
            duration_seconds=5.0
        )
        
        self.generator = ReportGenerator()
    
    def test_generate_markdown(self):
        """测试 Markdown 报告"""
        report = self.generator.generate(self.result, format="markdown")
        
        self.assertIn("代码审查报告", report)
        self.assertIn("🟢 通过", report)
        self.assertIn("正确性", report)
    
    def test_generate_json(self):
        """测试 JSON 报告"""
        report = self.generator.generate(self.result, format="json")
        
        data = json.loads(report)
        self.assertEqual(data["overall_rating"], "🟢 通过")
        self.assertEqual(data["review_depth"], "standard")
    
    def test_generate_sarif(self):
        """测试 SARIF 报告"""
        report = self.generator.generate(self.result, format="sarif")
        
        data = json.loads(report)
        self.assertEqual(data["version"], "2.1.0")
        self.assertIn("runs", data)


class TestModels(unittest.TestCase):
    """测试数据模型"""
    
    def test_issue_to_dict(self):
        """测试 Issue 序列化"""
        issue = Issue(
            dimension=Dimension.CORRECTNESS,
            severity=Severity.HIGH,
            file="test.py",
            line=10,
            column=5,
            message="测试消息",
            rule_id="TEST001",
            suggestion="修复建议",
            snippet="code snippet"
        )
        
        data = issue.to_dict()
        self.assertEqual(data["file"], "test.py")
        self.assertEqual(data["severity"], "high")
        self.assertEqual(data["dimension"], "correctness")
    
    def test_review_result_to_dict(self):
        """测试 ReviewResult 序列化"""
        from scripts.models import DimensionResult
        
        result = ReviewResult(
            project_path="/test",
            review_depth="standard",
            overall_rating="🟢 通过",
            dimensions=[],
            timestamp="2026-03-16 10:00:00",
            duration_seconds=5.0
        )
        
        data = result.to_dict()
        self.assertEqual(data["project_path"], "/test")
        self.assertEqual(data["overall_rating"], "🟢 通过")


if __name__ == "__main__":
    unittest.main()
