---
name: 试卷解析生成器
displayName: 试卷解析生成器
description: 为试卷生成详细解析，包含解题思路、易错点、知识点链接。
version: 1.0.0
author: OpenClaw Edu
tags: [education, exam, analysis, solution, teaching]
category: education
---

# 试卷解析生成器

生成试卷详细解析。

## 功能

- 逐题解析
- 解题思路
- 易错点提醒
- 知识点链接
- 多种解法

## 使用

```
@试卷解析生成器 为这份期末试卷生成详细解析
```
