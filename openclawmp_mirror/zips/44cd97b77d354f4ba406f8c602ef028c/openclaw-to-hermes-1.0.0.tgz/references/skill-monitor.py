#!/usr/bin/env python3
"""
skill-monitor — 定期扫描 ~/.hermes/skills/，将 OpenClaw 格式 skill 自动转换

每 5 分钟运行一次（新 skill 最多等 5 分钟就会被转换）
扫描逻辑：
1. 跳过已有 oc- 前缀的目录（已转换）
2. 检查 SKILL.md 是否为 OpenClaw 格式
3. 是 → 调用 convert.py 转换
4. 否 → 跳过
"""

import os, re, sys, subprocess, time
from pathlib import Path

SKILLS_DIR = Path.home() / ".hermes" / "skills"
CONVERTER  = Path.home() / ".hermes" / "skills" / "openclaw-to-hermes" / "convert.py"
STATE_FILE = Path.home() / ".hermes" / ".skill-monitor-state.json"

OC_MARKERS = [
    "allowed-tools",
    "assetId",
    "asset_id",
    "__asset_schema",
    "openclawmp",
]

FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)


def get_frontmatter_keys(content: str) -> set:
    match = FRONTMATTER_RE.match(content)
    if not match:
        return set()
    keys = re.findall(r"^(\w+):", match.group(1), re.MULTILINE)
    return set(keys)


def is_openclaw_format(skill_path: Path) -> bool:
    skill_md = skill_path / "SKILL.md"
    if not skill_md.exists():
        return False
    try:
        content = skill_md.read_text(encoding="utf-8")
    except Exception:
        return False

    fm_keys = get_frontmatter_keys(content)
    fm_str  = content[:1000].lower()

    manifest = skill_path / "manifest.json"
    if manifest.exists():
        try:
            m = manifest.read_text(encoding="utf-8").lower()
            if "openclaw" in m or "__asset_schema" in m:
                return True
        except Exception:
            pass

    for key in ["allowed-tools", "assetId", "asset_id", "__asset_schema"]:
        if key in fm_keys or key in fm_str:
            return True

    if "source: openclaw" in fm_str or "来源：水产市场" in fm_str:
        return True

    return False


def get_last_run() -> float:
    if STATE_FILE.exists():
        try:
            return float(STATE_FILE.read_text())
        except Exception:
            pass
    return 0.0


def set_last_run():
    try:
        STATE_FILE.write_text(str(time.time()))
    except Exception:
        pass


def convert_skill(skill_dir: Path, asset_id: str = ""):
    result = subprocess.run(
        ["python3", str(CONVERTER), str(skill_dir), asset_id],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        print(f"  ✅ 已转换: {skill_dir.name}")
    else:
        print(f"  ⚠️  转换失败: {result.stderr[:200]}")


def scan_and_convert():
    if not SKILLS_DIR.exists():
        return 0

    converted = 0
    for entry in sorted(SKILLS_DIR.iterdir()):
        if not entry.is_dir():
            continue
        if entry.name.startswith("oc-"):
            continue
        if entry.name.startswith("."):
            continue

        if is_openclaw_format(entry):
            print(f"🔄 检测到 OpenClaw skill: {entry.name}")
            convert_skill(entry, entry.name)
            converted += 1
        else:
            print(f"  ⏭️  跳过（已是 Hermes 格式）: {entry.name}")

    return converted


def main():
    last = get_last_run()
    if time.time() - last < 300:
        sys.exit(0)

    print(f"[skill-monitor] 开始扫描 {SKILLS_DIR} ...")
    converted = scan_and_convert()
    set_last_run()
    print(f"[skill-monitor] 完成，转换 {converted} 个 skill")
    return 0


if __name__ == "__main__":
    sys.exit(main())
