# OpenClaw → Hermes Skill 转换器

将水产市场（OpenClaw）的技能包自动转换为 Hermes Agent 格式的懒人工具。

## 它解决什么问题

在水产市场上安装 skill 后，发现格式不兼容、无法直接用于 Hermes Agent？每次手动复制、重写 frontmatter 很麻烦？

这个转换器让整个过程全自动——你只需要安装，剩下的不用管。

## 核心能力

**双保险自动转换：**

1. **拦截层**：当用 `openclaw install` 命令安装 skill 到 `~/.hermes/skills/` 目录时，wrapper 自动拦截、安装完成后立即转换、最后清理原版，整个过程无需人工介入。

2. **Observer 层**：每 5 分钟扫描一次 `~/.hermes/skills/` 目录，任何来源的 OpenClaw 格式 skill（手动复制、GitHub 下载、其他平台迁移）都会被自动发现并转换。

## 工作原理

两种 skill 都是 Markdown + YAML frontmatter，核心差异在于：

- **OpenClaw 格式**：frontmatter 包含 `allowed-tools`、`assetId`、`manifest.json` 等平台特有字段
- **Hermes 格式**：frontmatter 使用 `metadata.hermes.tags` 和 `metadata.source`

转换时只重写 frontmatter 并加上 `oc-` 前缀，原文内容 100% 保留，无任何信息损失。

## 适用场景

- 从水产市场安装 skill 到 Hermes Agent
- 在多个 Agent 平台之间迁移 skill 资产
- 批量统一 skill 格式
- 管理大量来自不同来源的 skill

## 前提条件

- Hermes Agent 环境
- openclawmp CLI 已安装并配置 token

## 使用方式

安装后 skill-monitor 在后台自动运行，无需任何人工操作。

**手动触发扫描：**
```bash
python3 ~/.hermes/scripts/skill-monitor.py
```

**查看监控状态：**
```bash
tail -f ~/.hermes/.skill-monitor-state.json
```
