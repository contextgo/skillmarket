#!/usr/bin/env python3
"""
OpenClaw SKILL.md → Hermes SKILL.md 格式转换器

用法：
    python3 convert.py <skill_dir> [asset_id]

行为：
1. 读取 <skill_dir>/SKILL.md
2. 解析 YAML frontmatter
3. 转换为 Hermes 格式，加 oc- 前缀
4. 写入 <skill_dir>/SKILL.md（原地覆盖）
5. 删除原版 backup（如果存在）
"""

import re, sys, json, shutil
from pathlib import Path

FRONTMATTER_RE = re.compile(r"^---\n(.*?)\n---\n", re.DOTALL)
HERMES_FRONTMATTER = """---
name: {name}
description: {description}
version: {version}
metadata:
  source: openclaw:{asset_id}
  hermes:
    tags: [{tags}]
    category: {category}
---
"""


def extract_frontmatter(content: str) -> tuple[dict, str]:
    """解析 frontmatter，返回 (frontmatter_dict, body_content)"""
    match = FRONTMATTER_RE.match(content)
    if not match:
        return {}, content
    fm_text = match.group(1)
    body = content[match.end():]

    # 简单 YAML 解析（只提取顶层 key: value）
    fm = {}
    for line in fm_text.splitlines():
        m = re.match(r"^(\w+):(.*)$", line)
        if m:
            key, val = m.group(1).strip(), m.group(2).strip().strip('"').strip("'")
            fm[key] = val
    return fm, body


def guess_category(fm: dict, body: str) -> str:
    """根据内容猜测 category"""
    text = (str(fm) + body).lower()
    if any(k in text for k in ["自动化", "automation", "workflow"]):
        return "automation"
    if any(k in text for k in ["小红书", "xiao", "social"]):
        return "social"
    if any(k in text for k in ["飞书", "feishu", "bitable"]):
        return "productivity"
    if any(k in text for k in ["营销", "marketing", "content"]):
        return "marketing"
    return "general"


def convert(content: str, skill_name: str, asset_id: str = "") -> str:
    """将 OpenClaw 格式 content 转换为 Hermes 格式"""
    fm, body = extract_frontmatter(content)

    # 从 frontmatter 提取信息
    name = fm.get("name", skill_name)
    description = fm.get("description", fm.get("desc", ""))
    version = fm.get("version", "1.0.0")
    tags = fm.get("tags", fm.get("tag", "openclaw,hermes"))
    category = fm.get("category", guess_category(fm, body))

    # 清理 tags
    if isinstance(tags, str):
        tags = tags.replace("，", ",").replace("、", ",")
        tags = ",".join(t.strip() for t in tags.split(",") if t.strip())

    new_fm = HERMES_FRONTMATTER.format(
        name="oc-" + name,
        description=description[:200],
        version=version,
        asset_id=asset_id or name,
        tags=tags,
        category=category,
    )
    return new_fm + body


def main():
    if len(sys.argv) < 2:
        print("用法: python3 convert.py <skill_dir> [asset_id]")
        sys.exit(1)

    skill_dir = Path(sys.argv[1])
    asset_id = sys.argv[2] if len(sys.argv) > 2 else ""

    skill_md = skill_dir / "SKILL.md"
    if not skill_md.exists():
        print(f"错误: {skill_md} 不存在")
        sys.exit(1)

    original = skill_md.read_text(encoding="utf-8")

    # 已有 oc- 前缀，跳过
    if 'name: "oc-' in original or "name: oc-" in original:
        print(f"已是 Hermes 格式，跳过: {skill_dir.name}")
        sys.exit(0)

    converted = convert(original, skill_dir.name, asset_id)
    skill_md.write_text(converted, encoding="utf-8")
    print(f"✅ 已转换: {skill_dir.name} → oc-{skill_dir.name}")


if __name__ == "__main__":
    main()
