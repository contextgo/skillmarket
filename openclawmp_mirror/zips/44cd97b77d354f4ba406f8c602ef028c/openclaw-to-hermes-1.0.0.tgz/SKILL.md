---
name: openclaw-to-hermes
description: OpenClaw 水产市场 Skill → Hermes Skill 格式转换器。触发词：编译、转换、移植 openclaw、openclaw skill 转 hermes、水产 skill。
version: 1.2.0
metadata:
  hermes:
    tags: [openclaw, skill-compiler, skill-converter, 水产市场, openclawmp]
    category: productivity
  observer:
    cron_job_id: eb5651830b93
    script: ~/.hermes/scripts/skill-monitor.py
    schedule: every 5m
---

# OpenClaw → Hermes Skill 转换器

## 双保险机制

**方式一（openclaw install 命令）**：
`~/.local/bin/openclaw` 拦截 install 命令，安装到 `~/.hermes/skills/` 时自动转换。

**方式二（skill-monitor observer）**：
每 5 分钟扫描 `~/.hermes/skills/`，任何来源的 OpenClaw 格式 skill 都会自动发现并转换。
- 脚本：`~/.hermes/scripts/skill-monitor.py`
- cron：`eb5651830b93`（每 5 分钟）

```
任意来源放入 skill → ~/.hermes/skills/ → 最多等 5 分钟 → 自动转换完成
```

## 核心原理

两种 skill 都是 Markdown + YAML frontmatter，核心差异：
- OpenClaw frontmatter 含 `allowed-tools`、`assetId`、`manifest.json` 等特殊字段
- Hermes frontmatter 用 `metadata.hermes.tags` 和 `metadata.source`

转换时：重写 frontmatter 加 `oc-` 前缀，原文内容完全保留。

## 用法

**从水产市场安装（推荐加 `--target-dir`）：**
```
openclaw install skill/<assetId> --target-dir ~/.hermes/skills
→ 自动安装 + 转换 + 清理原版 → ~/.hermes/skills/oc-<name>/
```

**手动触发转换（任意 skill）：**
```
python3 ~/.hermes/scripts/skill-monitor.py
```

## 已转换的 skill

| skill | 状态 |
|-------|------|
| oc-idea2mvp | ✅ |
| oc-feishu-bitable-automation | ✅ |
| oc-xiaohongshu-automation | ✅ |
| oc-automation-workflows | ✅ |
| oc-weekly-report-generator | ✅ |

## 安装验证命令

```bash
ln -sf ~/.hermes/node/lib/node_modules/openclawmp/bin/openclawmp.js ~/.local/bin/openclaw
chmod +x ~/.local/bin/openclaw
openclaw oauth <your-token>  # 只需一次
```

## 限制

- Plugin/Trigger/Channel 类型暂不转换
- 已有的 `oc-` 前缀目录会被 monitor 跳过
