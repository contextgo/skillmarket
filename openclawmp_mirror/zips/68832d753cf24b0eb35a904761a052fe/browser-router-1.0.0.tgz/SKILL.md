---
name: browser-router
description: 浏览器自动化工具智能路由。当任务涉及：打开网页/浏览、截图、填表、点击UI、登录会话、内容抓取、数据提取、社媒平台、设备模拟、网络调试、Console分析、JS渲染页面 等任何浏览器操作时自动触发。
---

# browser-router

极简路由规则。内容很少，加载快，强制遵守。

## 路由规则（按优先级）

```
1. 有登录/cookies/session？→ browser tool
2. 是微信/小红书/抖音/微博等社媒？→ apify-ultimate-scraper
3. 静态页面（无JS/无登录）？→ web_fetch
4. 需要设备模拟/移动端/iPhone？→ Playwright MCP
5. 需要网络拦截/Console/性能调试？→ DevTools MCP
6. 通用浏览器操作（浏览/截图/填表）？→ browser tool
7. 以上全部失败/浏览器外UI操作？→ desktop-control
```

## 端口状态检查（必要时）

- Edge (port 18800): `lsof -i :18800`
- Playwright MCP (3001): `lsof -i :3001`
- DevTools MCP (3002): `lsof -i :3002`

## 执行原则

- **简单任务（浏览/截图）：直接用 browser tool，不询问**
- **复杂任务（多步/调试）：告知用户你选的工具和理由**
- **结果导向：browser tool 是默认起点，站不住再换**
- **不需要读手册 → 规则就在这里，直接用**
