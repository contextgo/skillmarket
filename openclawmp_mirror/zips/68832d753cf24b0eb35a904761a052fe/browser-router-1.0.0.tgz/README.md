# 浏览器智能路由（browser-router）

## 这是什么

一个极简的浏览器自动化工具路由规则库。根据任务类型自动选择最合适的浏览器/爬虫工具，避免在多个工具之间反复试错。

## 解决什么问题

当你需要让 AI 操作浏览器时，不同任务适合的工具完全不同：
- 社媒平台（微信/小红书/抖音）→ 需要专用爬虫
- 静态页面 → 轻量抓取工具
- 登录态页面 → 需要复用 cookies 的浏览器
- 移动端模拟 → 需要 Playwright
- 通用浏览/截图 → browser tool 就能搞定

这个 Skill 就是告诉你：**什么情况用什么工具**，以及「所有工具都失效」时的最终兜底方案。

## 核心规则

| 优先级 | 场景 | 工具 |
|--------|------|------|
| 1 | 登录/cookies/session | browser tool |
| 2 | 微信/小红书/抖音/微博 | apify-ultimate-scraper |
| 3 | 静态页面（无JS/无登录） | web_fetch |
| 4 | 设备模拟/移动端/iPhone | Playwright MCP |
| 5 | 网络拦截/Console/性能调试 | DevTools MCP |
| 6 | 通用浏览器操作 | browser tool |
| 7 | 以上全部失败 | desktop-control |

**所有工具链的共同终点：desktop-control**（Mac 任何 UI 都能控制）

## 端口参考

- Edge remote-debugging: port 18800
- Playwright MCP: port 3001
- DevTools MCP: port 3002

## 适用场景

- AI 浏览器自动化工作流
- 多工具协作的决策规则
- 构建稳定的网页抓取/操作流程
- 避免工具选型反复试错
