# StepClaw 飞书机器人绑定 Skill

## 概述

将飞书机器人绑定到 StepClaw 的指定 agent / subagent。

**核心原则**：
- 不直接编辑 `~/.stepclaw/openclaw.json`
- 先调用 `gateway config.get` 读取快照和 `hash`
- 再通过 `gateway config.patch` 写入 JSON 字符串
- Feishu 路由写在顶层 `bindings`

## 执行流程

### 第 1 步：收集信息

向用户确认：

| 信息 | 说明 | 默认值 |
|------|------|--------|
| **Agent ID** | 绑定到哪个 agent / subagent | 必填 |
| **Agent Name** | 若 agent 不存在，用于自动创建时展示 | 同 agent-id |
| **Account ID** | 飞书 account 标识 | 必填 |
| **飞书 App ID** | `cli_xxx` 格式 | 必填 |
| **飞书 App Secret** | 从飞书开放平台获取 | 必填 |
| **DM 策略** | `open` / `pairing` | `open` |
| **群聊策略** | `open` / `allowlist` / `disabled` | `open` |
| **是否需要 @** | 群聊中是否需要 @机器人 | `true` |

### 第 2 步：发现或创建目标 agent

1. 先读取 `agents.list`
2. 如果目标 agent 已存在，则直接绑定
3. 如果目标 agent 不存在，则自动创建：
   - `workspace`: `~/.stepclaw/workspace-<agent-id>`
   - `agentDir`: `~/.stepclaw/agents/<agent-id>/agent`

### 第 3 步：写入配置

先读取配置快照：

```text
gateway config.get
```

拿到 `hash` 后，调用 `gateway config.patch`。注意：
- `raw` 必须是 JSON 字符串
- `bindings` 是顶层数组
- `agents.list` 也是数组，写入时要带完整结果

绑定到指定 subagent 的目标结构示例：

```json
{
  "agents": {
    "list": [
      {"id": "main", "default": true, "workspace": "~/.stepclaw/workspace"},
      {"id": "main-2", "name": "main-2", "workspace": "~/.stepclaw/workspace-main-2", "agentDir": "~/.stepclaw/agents/main-2/agent"}
    ]
  },
  "bindings": [
    {
      "agentId": "main-2",
      "match": {
        "channel": "feishu",
        "accountId": "main-2"
      }
    }
  ],
  "channels": {
    "feishu": {
      "enabled": true,
      "accounts": {
        "main-2": {
          "enabled": true,
          "appId": "<APP_ID>",
          "appSecret": "<APP_SECRET>",
          "dmPolicy": "open",
          "groupPolicy": "open",
          "requireMention": true,
          "allowFrom": ["*"]
        }
      }
    }
  }
}
```

### 第 4 步：冲突处理

- 如果 `bindings` 里已经存在同一个 `channel=feishu + accountId=<ACCOUNT_ID>`，脚本直接报错退出
- 不静默覆盖已有 binding

### 第 5 步：验证

gateway 重载后验证：

1. 目标 account 已写入 `channels.feishu.accounts.<accountId>`
2. 目标 agent 已存在于 `agents.list`
3. 顶层 `bindings` 中存在 `feishu/<accountId> -> <agentId>`
4. 执行 `~/.stepclaw/bin/openclaw gateway status`

### 第 6 步（可选）：Shell 脚本

```bash
bash <skill_dir>/scripts/bind-feishu-bot.sh \
  --agent-id "main-2" \
  --agent-name "客服助手" \
  --account-id "customer-service-bot" \
  --app-id "cli_xxx" \
  --app-secret "xxx" \
  --dm-policy "open" \
  --group-policy "open" \
  --require-mention "true"
```

## 故障排查

| 问题 | 解决方案 |
|------|----------|
| `config.patch` 报 `raw required` | 传 `raw` 字符串，不要传对象 |
| `config.patch` 报 `config base hash required` | 先 `config.get`，再把返回的 `hash` 带回去 |
| account 已存在 binding | 更换 `--account-id`，或手动清理旧 binding |
| 写入后机器人不响应 | 检查飞书应用是否已发布、是否配置长连接事件 |
| 插件未加载 | 确认 `plugins.entries.openclaw-lark.enabled: true` |

## 注意事项

- StepClaw 配置文件是 JSON5，不要用标准 JSON 直接覆盖写回
- 始终优先通过 `gateway config.get` / `gateway config.patch` 修改
- 顶层 `bindings` 才是 Feishu subagent 路由关键配置