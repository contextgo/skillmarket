---
name: 知识树可视化
displayName: 知识树可视化
description: 将教案转换为知识树思维导图，生成PPT可视化，帮助学生理解知识结构。
version: 1.0.0
author: OpenClaw Edu
tags: [education, mindmap, visualization, knowledge, ppt]
category: education
---

# 知识树可视化

教案转知识树思维导图。

## 功能

- 知识点提取
- 构建知识树
- 生成PPT思维导图
- 课后笔记模板

## 使用

```
@知识树可视化 将这份历史教案转换为知识树PPT
```
