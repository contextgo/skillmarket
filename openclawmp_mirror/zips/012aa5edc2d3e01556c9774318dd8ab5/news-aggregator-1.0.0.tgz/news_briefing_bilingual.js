#!/usr/bin/env node
/**
 * 双语新闻简报生成器 v3.0
 * 支持中英文双语输出
 * 国内：新华网 + 人民网 + 央视网
 * 国际：BBC + CNN + Reuters + Guardian
 */

const fs = require('fs');

// 配置
const CONFIG = {
  sources: {
    domestic: [
      { key: 'xinhua', name: '新华网', nameEn: 'Xinhua' },
      { key: 'people', name: '人民网', nameEn: "People's Daily" },
      { key: 'cctv', name: '央视网', nameEn: 'CCTV' }
    ],
    international: [
      { key: 'bbc', name: 'BBC News', nameEn: 'BBC News' },
      { key: 'cnn', name: 'CNN', nameEn: 'CNN' },
      { key: 'reuters', name: 'Reuters', nameEn: 'Reuters' },
      { key: 'guardian', name: 'The Guardian', nameEn: 'The Guardian' }
    ]
  },
  itemsPerSource: 8,
  languages: ['zh', 'en'] // 支持双语
};

// 新闻数据
let newsData = {
  domestic: {},
  international: {}
};

// 设置新闻数据
function setNewsData(data) {
  newsData = data;
}

// 生成中文简报
function generateChineseBriefing() {
  const lines = [];
  const now = new Date();
  
  lines.push('='.repeat(60));
  lines.push('📰 每日新闻简报');
  lines.push('='.repeat(60));
  lines.push(`📅 ${now.getFullYear()}年${now.getMonth() + 1}月${now.getDate()}日`);
  lines.push('');
  
  // 国内新闻
  lines.push('## 🇨🇳 国内要闻');
  lines.push('');
  
  for (const source of CONFIG.sources.domestic) {
    if (newsData.domestic[source.key] && newsData.domestic[source.key].length > 0) {
      lines.push(`### ${source.name}`);
      lines.push('');
      newsData.domestic[source.key].slice(0, 5).forEach((item, i) => {
        lines.push(`${i + 1}. ${item.title}`);
        if (item.summary) lines.push(`   ${item.summary}`);
      });
      lines.push('');
    }
  }
  
  // 国际新闻
  lines.push('## 🌍 国际要闻');
  lines.push('');
  
  for (const source of CONFIG.sources.international) {
    if (newsData.international[source.key] && newsData.international[source.key].length > 0) {
      lines.push(`### ${source.name}`);
      lines.push('');
      newsData.international[source.key].slice(0, CONFIG.itemsPerSource).forEach((item, i) => {
        lines.push(`${i + 1}. ${item.title}`);
      });
      lines.push('');
    }
  }
  
  // 热点聚焦
  lines.push('## 🔥 热点聚焦');
  lines.push('');
  lines.push('- 🇮🇷 伊朗局势：新最高领袖上台，中东战事持续');
  lines.push('- 🛢️ 能源市场：油价突破 $110，全球股市震荡');
  lines.push('- 🇨🇳 国内两会：智能经济新形态写入政府工作报告');
  lines.push('');
  lines.push('='.repeat(60));
  lines.push('💡 提示：回复"新闻8"查看某条新闻详情');
  lines.push('='.repeat(60));
  
  return lines.join('\n');
}

// 生成英文简报
function generateEnglishBriefing() {
  const lines = [];
  const now = new Date();
  
  lines.push('='.repeat(60));
  lines.push('📰 DAILY NEWS BRIEFING');
  lines.push('='.repeat(60));
  lines.push(`📅 ${now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' })}`);
  lines.push('');
  
  // 国内新闻
  lines.push('## 🇨🇳 CHINA HEADLINES');
  lines.push('');
  
  for (const source of CONFIG.sources.domestic) {
    if (newsData.domestic[source.key] && newsData.domestic[source.key].length > 0) {
      lines.push(`### ${source.nameEn}`);
      lines.push('');
      newsData.domestic[source.key].slice(0, 5).forEach((item, i) => {
        lines.push(`${i + 1}. ${item.titleEn || item.title}`);
        if (item.summaryEn) lines.push(`   ${item.summaryEn}`);
      });
      lines.push('');
    }
  }
  
  // 国际新闻
  lines.push('## 🌍 INTERNATIONAL HEADLINES');
  lines.push('');
  
  for (const source of CONFIG.sources.international) {
    if (newsData.international[source.key] && newsData.international[source.key].length > 0) {
      lines.push(`### ${source.nameEn}`);
      lines.push('');
      newsData.international[source.key].slice(0, CONFIG.itemsPerSource).forEach((item, i) => {
        lines.push(`${i + 1}. ${item.title}`);
      });
      lines.push('');
    }
  }
  
  // 热点聚焦
  lines.push('## 🔥 KEY HIGHLIGHTS');
  lines.push('');
  lines.push('- 🇮🇷 IRAN CRISIS: New supreme leader takes power as Middle East war continues');
  lines.push('- 🛢️ ENERGY MARKETS: Oil breaks $110, global stocks volatile');
  lines.push('- 🇨🇳 CHINA TWO SESSIONS: Smart economy written into government work report');
  lines.push('');
  lines.push('='.repeat(60));
  lines.push('💡 Tip: Reply "news [number]" for details, e.g., "news 5"');
  lines.push('='.repeat(60));
  
  return lines.join('\n');
}

// 生成双语简报（合并）
function generateBilingualBriefing() {
  const zh = generateChineseBriefing();
  const en = generateEnglishBriefing();
  
  return {
    chinese: zh,
    english: en,
    combined: zh + '\n\n' + '='.repeat(60) + '\n\n' + en
  };
}

// 保存简报
function saveBriefing(lang = 'both') {
  const date = new Date().toISOString().split('T')[0];
  const briefings = generateBilingualBriefing();
  
  if (lang === 'zh' || lang === 'both') {
    fs.writeFileSync(`daily_briefing_${date}_zh.txt`, briefings.chinese, 'utf8');
  }
  if (lang === 'en' || lang === 'both') {
    fs.writeFileSync(`daily_briefing_${date}_en.txt`, briefings.english, 'utf8');
  }
  if (lang === 'both') {
    fs.writeFileSync(`daily_briefing_${date}_bilingual.txt`, briefings.combined, 'utf8');
  }
  
  fs.writeFileSync(`daily_briefing_${date}.json`, JSON.stringify(newsData, null, 2));
  
  return briefings;
}

// 模拟数据
function demo() {
  setNewsData({
    domestic: {
      xinhua: [
        { title: '新华社经济随笔：读懂"服务"里蕴含的生产力', titleEn: 'Xinhua Economic Essay: Understanding Productivity in Services', summary: '深度解读服务业在经济发展中的重要作用', summaryEn: 'In-depth analysis of service industry role in economic development' },
        { title: '小璇绘两会丨未来五年有哪些"民生礼包"值得期待？', titleEn: 'Two Sessions Illustrated: What "People\'s Livelihood Gifts" to Expect', summary: '图解全国两会民生政策走向', summaryEn: 'Visual guide to Two Sessions policies on education, healthcare, housing' },
        { title: '中国代表：中国将继续以高质量发展为全球南方提供新机遇', titleEn: 'China Representative: High-Quality Development Offers New Opportunities for Global South', summary: '中国将为发展中国家创造更多合作机遇', summaryEn: 'China to create more cooperation opportunities for developing nations' },
        { title: '两会·外长记者会丨王毅：中国是周边和平稳定的关键因素', titleEn: 'Two Sessions: Foreign Minister Wang Yi on Regional Peace', summary: '外交部长王毅表示中国是地区和平稳定的建设者', summaryEn: 'China as builder and guardian of regional peace and stability' },
        { title: '两会特稿·中国经济问答丨建设强大国内市场', titleEn: 'Two Sessions Special: Building Strong Domestic Market', summary: '解读政府工作报告扩大内需战略', summaryEn: 'Government work report strategies for expanding domestic demand' }
      ],
      people: [
        { title: '人民日报评论员文章：坚定不移推进高质量发展', titleEn: 'People\'s Daily Commentary: Unswervingly Promote High-Quality Development' },
        { title: '全国两会：代表委员热议新质生产力', titleEn: 'Two Sessions: Deputies Discuss New Quality Productive Forces' },
        { title: '民生保障再加力 幸福生活有奔头', titleEn: 'Strengthening Livelihood Protection for a Better Life' }
      ],
      cctv: [
        { title: '央视快评：以科技创新引领现代化产业体系建设', titleEn: 'CCTV Commentary: Leading Modern Industrial System with Sci-Tech Innovation' },
        { title: '两会现场：部长通道回应民生热点', titleEn: 'Two Sessions Scene: Ministers Respond to Hot Issues' },
        { title: '焦点访谈：人工智能赋能千行百业', titleEn: 'Focus Interview: AI Empowering All Industries' }
      ]
    },
    international: {
      bbc: [
        { title: "Mojtaba Khamenei to succeed his father as Iran's supreme leader as oil prices surge" },
        { title: "Oil prices surge above $110 and shares slide over Iran war" },
        { title: "Who is Mojtaba Khamenei, Iran's new supreme leader?" },
        { title: "'Night turned into day': Iranians tell of strikes on oil depots" },
        { title: "In maps: Nine days of strikes across the Middle East" },
        { title: "Starmer and Trump speak for first time since president's Iran criticism" },
        { title: "Explosion at US embassy in Oslo may have been terrorism, Norway police say" },
        { title: "Nepal election 2026: Balendra Shah on course to be PM as party heads for landslide" }
      ],
      cnn: [
        { title: "Iran names Khamenei's son new supreme leader as war escalates" },
        { title: "Oil prices soar past $100 a barrel as war escalates" },
        { title: "What to know about Iran's new supreme leader" },
        { title: "Huge fire in Scotland triggers train chaos as historic building partially collapses" },
        { title: "Seventh US service member killed in Iran war after being wounded in attack in Saudi Arabia" },
        { title: "Rihanna's Beverly Hills home hit by gunfire, police say" },
        { title: "Diesel prices are climbing even faster than gas prices. Here's why you should care" },
        { title: "Explosion at US embassy in Oslo may have been terrorism, Norway police say" }
      ],
      reuters: [
        { title: "Oil surges above $110 as Iran war sparks supply fears" },
        { title: "US service member dies from wounds in Saudi attack, seventh killed in Iran war" },
        { title: "Trump meets families of troops killed in Iran war" },
        { title: "Nepal's RSP party set for landslide election win" },
        { title: "Glasgow fire: Building collapses near Central Station" },
        { title: "US embassy explosion in Oslo investigated as possible terrorism" }
      ],
      guardian: [
        { title: "Iran names new supreme leader as Middle East conflict intensifies" },
        { title: "Oil prices surge amid fears of wider Middle East war" },
        { title: "Seventh US soldier killed in Iran war, military confirms" },
        { title: "Trump defends Iran war despite growing US casualties" },
        { title: "Nepal election: Political outsider set to become PM" }
      ]
    }
  });
  
  const briefings = saveBriefing('both');
  
  console.log('中文简报：');
  console.log(briefings.chinese);
  console.log('\n\n英文简报：');
  console.log(briefings.english);
  console.log('\n✅ 双语简报已生成！');
}

// 执行
if (require.main === module) {
  demo();
}

module.exports = {
  setNewsData,
  generateChineseBriefing,
  generateEnglishBriefing,
  generateBilingualBriefing,
  saveBriefing,
  CONFIG
};
