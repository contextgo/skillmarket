---
name: hello-world
version: 1.1.0
description: A minimal example skill that greets the user. Use when the user says "hello world", asks for a greeting, or wants to test that skills work. Great as a template for creating new skills.
---

# Hello World

Greet the user with a friendly "Hello, World! 🌍" message.

If the user asks what this skill does, explain that it's a minimal example skill — a starting point for building more complex skills.
