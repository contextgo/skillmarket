---
name: knowledge-graph-ontology
description: 结构化知识图谱记忆系统，支持实体-关系-属性建模、CRUD操作、语义关联、时间版本控制、知识查询遍历、对话自动提取、去重冲突解决，让Agent拥有可推理、可检索的结构化知识记忆。
---

# 结构化知识图谱记忆系统

本技能定义了一套完整的知识图谱（Knowledge Graph）构建和管理协议，赋予 Agent 结构化、可推理、可检索的知识记忆能力。Agent 能够创建实体和关系、执行语义查询、从对话中自动提取知识、管理知识版本，并处理冲突与去重。

---

## 目录

1. [系统架构概述](#1-系统架构概述)
2. [本体模式定义（Ontology Schema）](#2-本体模式定义ontology-schema)
3. [实体管理（Entity Management）](#3-实体管理entity-management)
4. [关系管理（Relation Management）](#4-关系管理relation-management)
5. [属性管理（Attribute Management）](#5-属性管理attribute-management)
6. [知识查询与遍历（Query & Traversal）](#6-知识查询与遍历query--traversal)
7. [对话知识自动提取](#7-对话知识自动提取)
8. [知识去重与冲突解决](#8-知识去重与冲突解决)
9. [时间版本控制](#9-时间版本控制)
10. [与 Agent 记忆系统集成](#10-与-agent-记忆系统集成)
11. [领域知识图谱构建示例](#11-领域知识图谱构建示例)
12. [知识推理与推断](#12-知识推理与推断)
13. [存储格式与文件结构](#13-存储格式与文件结构)

---

## 1. 系统架构概述

### 1.1 核心概念

```
知识图谱 (Knowledge Graph) 由三个核心要素组成：

┌──────────┐  关系 (Relation)  ┌──────────┐
│  实体 A   │ ──────────────►  │  实体 B   │
│ (Entity)  │                  │ (Entity)  │
│           │                  │           │
│ 属性:     │                  │ 属性:     │
│ - name    │                  │ - name    │
│ - type    │                  │ - type    │
│ - attrs   │                  │ - attrs   │
└──────────┘                  └──────────┘

三元组 (Triple): (主体 Subject, 谓词 Predicate, 客体 Object)
例: (张三,就职于,腾讯)
例: (Python,是一种,编程语言)
例: (React,使用语言,JavaScript)
```

### 1.2 系统分层

```
┌─────────────────────────────────────────┐
│          应用层 (Application Layer)      │
│  对话提取 | 语义查询 | 知识推理 | 报告   │
├─────────────────────────────────────────┤
│          推理层 (Inference Layer)        │
│  关系传递 | 类型继承 | 规则引擎 | 推断   │
├─────────────────────────────────────────┤
│          图层 (Graph Layer)              │
│  实体管理 | 关系管理 | 属性管理 | 遍历   │
├─────────────────────────────────────────┤
│          存储层 (Storage Layer)          │
│  实体文件 | 关系文件 | 索引文件 | 版本   │
└─────────────────────────────────────────┘
```

---

## 2. 本体模式定义（Ontology Schema）

### 2.1 本体文件格式

本体（Ontology）定义了知识图谱中的类型系统，类似于数据库的 Schema。

```json
{
    "ontology": {
        "name": "general-knowledge-ontology",
        "version": "1.0.0",
        "description": "通用知识图谱本体，涵盖人物、组织、技术、项目等核心类型",
        "created_at": "2024-01-15T00:00:00Z",
        "entity_types": [
            {
                "type_name": "Person",
                "display_name": "人物",
                "description": "具体的人物实体",
                "parent_type": null,
                "required_attributes": [
                    {"name": "name", "type": "string", "description": "姓名"},
                    {"name": "role", "type": "string", "description": "职位/角色"}
                ],
                "optional_attributes": [
                    {"name": "email", "type": "string", "description": "邮箱"},
                    {"name": "phone", "type": "string", "description": "电话"},
                    {"name": "location", "type": "string", "description": "所在地"},
                    {"name": "skills", "type": "array<string>", "description": "技能列表"},
                    {"name": "department", "type": "string", "description": "部门"},
                    {"name": "alias", "type": "array<string>", "description": "别名/昵称"}
                ]
            },
            {
                "type_name": "Organization",
                "display_name": "组织",
                "description": "公司、机构、团队等组织实体",
                "parent_type": null,
                "required_attributes": [
                    {"name": "name", "type": "string", "description": "组织名称"},
                    {"name": "org_type", "type": "enum:company|institution|team|community|government", "description": "组织类型"}
                ],
                "optional_attributes": [
                    {"name": "industry", "type": "string", "description": "行业"},
                    {"name": "founded_year", "type": "integer", "description": "成立年份"},
                    {"name": "headquarters", "type": "string", "description": "总部地址"},
                    {"name": "website", "type": "string", "description": "官网"},
                    {"name": "size", "type": "enum:startup|small|medium|large|enterprise", "description": "规模"}
                ]
            },
            {
                "type_name": "Technology",
                "display_name": "技术",
                "description": "编程语言、框架、工具、平台等技术实体",
                "parent_type": null,
                "required_attributes": [
                    {"name": "name", "type": "string", "description": "技术名称"},
                    {"name": "tech_type", "type": "enum:language|framework|library|tool|platform|protocol|database", "description": "技术类型"}
                ],
                "optional_attributes": [
                    {"name": "version", "type": "string", "description": "版本"},
                    {"name": "creator", "type": "string", "description": "创建者"},
                    {"name": "release_year", "type": "integer", "description": "发布年份"},
                    {"name": "license", "type": "string", "description": "许可证"},
                    {"name": "website", "type": "string", "description": "官网/GitHub"},
                    {"name": "paradigm", "type": "array<string>", "description": "编程范式"}
                ]
            },
            {
                "type_name": "Project",
                "display_name": "项目",
                "description": "软件项目、产品、任务等",
                "parent_type": null,
                "required_attributes": [
                    {"name": "name", "type": "string", "description": "项目名称"},
                    {"name": "status", "type": "enum:planning|active|paused|completed|archived", "description": "项目状态"}
                ],
                "optional_attributes": [
                    {"name": "description", "type": "string", "description": "项目描述"},
                    {"name": "start_date", "type": "date", "description": "开始日期"},
                    {"name": "end_date", "type": "date", "description": "结束日期"},
                    {"name": "priority", "type": "enum:critical|high|medium|low", "description": "优先级"},
                    {"name": "tech_stack", "type": "array<string>", "description": "技术栈"},
                    {"name": "repository", "type": "string", "description": "代码仓库"}
                ]
            },
            {
                "type_name": "Concept",
                "display_name": "概念",
                "description": "抽象概念、理论、方法论等",
                "parent_type": null,
                "required_attributes": [
                    {"name": "name", "type": "string", "description": "概念名称"}
                ],
                "optional_attributes": [
                    {"name": "definition", "type": "string", "description": "定义"},
                    {"name": "domain", "type": "string", "description": "所属领域"},
                    {"name": "related_concepts", "type": "array<string>", "description": "相关概念"}
                ]
            },
            {
                "type_name": "Event",
                "display_name": "事件",
                "description": "已发生或将要发生的事件",
                "parent_type": null,
                "required_attributes": [
                    {"name": "name", "type": "string", "description": "事件名称"},
                    {"name": "event_time", "type": "datetime", "description": "事件时间"}
                ],
                "optional_attributes": [
                    {"name": "location", "type": "string", "description": "地点"},
                    {"name": "description", "type": "string", "description": "事件描述"},
                    {"name": "participants", "type": "array<string>", "description": "参与者"},
                    {"name": "outcome", "type": "string", "description": "结果"}
                ]
            },
            {
                "type_name": "Document",
                "display_name": "文档",
                "description": "文档、报告、文章等知识载体",
                "parent_type": null,
                "required_attributes": [
                    {"name": "title", "type": "string", "description": "文档标题"},
                    {"name": "doc_type", "type": "enum:report|spec|article|note|design|manual", "description": "文档类型"}
                ],
                "optional_attributes": [
                    {"name": "author", "type": "string", "description": "作者"},
                    {"name": "created_at", "type": "datetime", "description": "创建时间"},
                    {"name": "tags", "type": "array<string>", "description": "标签"},
                    {"name": "summary", "type": "string", "description": "摘要"},
                    {"name": "source", "type": "string", "description": "来源"}
                ]
            }
        ],
        "relation_types": [
            {
                "relation_name": "works_at",
                "display_name": "就职于",
                "subject_types": ["Person"],
                "object_types": ["Organization"],
                "attributes": [
                    {"name": "title", "type": "string", "description": "职位"},
                    {"name": "start_date", "type": "date", "description": "入职日期"},
                    {"name": "end_date", "type": "date", "description": "离职日期"},
                    {"name": "is_current", "type": "boolean", "description": "是否在职"}
                ]
            },
            {
                "relation_name": "uses",
                "display_name": "使用",
                "subject_types": ["Person", "Project", "Organization"],
                "object_types": ["Technology"],
                "attributes": [
                    {"name": "proficiency", "type": "enum:beginner|intermediate|advanced|expert", "description": "熟练度"},
                    {"name": "since", "type": "date", "description": "开始使用时间"},
                    {"name": "purpose", "type": "string", "description": "用途"}
                ]
            },
            {
                "relation_name": "is_a",
                "display_name": "是一种",
                "subject_types": ["Concept", "Technology"],
                "object_types": ["Concept", "Technology"],
                "description": "IS-A 继承关系，支持推理",
                "attributes": [],
                "transitive": true
            },
            {
                "relation_name": "part_of",
                "display_name": "属于/是...的一部分",
                "subject_types": ["Person", "Project", "Technology"],
                "object_types": ["Organization", "Project", "Technology"],
                "description": "PART-OF 关系",
                "attributes": [
                    {"name": "role", "type": "string", "description": "角色"}
                ]
            },
            {
                "relation_name": "related_to",
                "display_name": "相关于",
                "subject_types": ["*"],
                "object_types": ["*"],
                "description": "通用关联关系",
                "attributes": [
                    {"name": "strength", "type": "enum:strong|moderate|weak", "description": "关联强度"},
                    {"name": "description", "type": "string", "description": "关联说明"}
                ]
            },
            {
                "relation_name": "depends_on",
                "display_name": "依赖于",
                "subject_types": ["Project", "Technology"],
                "object_types": ["Technology", "Project"],
                "description": "依赖关系",
                "attributes": [
                    {"name": "dependency_type", "type": "enum:hard|soft|optional", "description": "依赖类型"}
                ],
                "transitive": true
            },
            {
                "relation_name": "authored",
                "display_name": "创作/编写",
                "subject_types": ["Person"],
                "object_types": ["Document", "Project"],
                "attributes": [
                    {"name": "role", "type": "enum:author|co_author|contributor", "description": "角色"},
                    {"name": "contribution", "type": "string", "description": "贡献内容"}
                ]
            },
            {
                "relation_name": "participated_in",
                "display_name": "参与了",
                "subject_types": ["Person", "Organization"],
                "object_types": ["Event", "Project"],
                "attributes": [
                    {"name": "role", "type": "string", "description": "参与角色"},
                    {"name": "time_range", "type": "string", "description": "参与时间段"}
                ]
            },
            {
                "relation_name": "has_knowledge_about",
                "display_name": "具有...知识",
                "subject_types": ["Person"],
                "object_types": ["Concept", "Technology", "Domain"],
                "attributes": [
                    {"name": "level", "type": "enum:aware|familiar|proficient|expert", "description": "知识水平"},
                    {"name": "verified", "type": "boolean", "description": "是否已验证"},
                    {"name": "source", "type": "string", "description": "知识来源"}
                ]
            }
        ]
    }
}
```

### 2.2 类型继承规则

```
继承规则：
1. 子类型继承父类型的所有属性
2. 子类型可以添加新属性
3. 子类型可以重写属性约束（放宽，不可收紧）
4. 关系的 subject/object 类型约束检查包含父类型

示例：
Technology (父类型)
├── ProgrammingLanguage (编程语言) - 添加 paradigm 属性
├── Framework (框架) - 添加 base_language 属性
├── Library (库) - 添加 compatible_languages 属性
├── Database (数据库) - 添加 db_type 属性
└── Tool (工具) - 添加 platform 属性

如果 person uses ProgrammingLanguage，也匹配 Technology 类型约束
```

---

## 3. 实体管理（Entity Management）

### 3.1 实体创建

```json
{
    "entity": {
        "entity_id": "ent-person-001",
        "entity_type": "Person",
        "name": "张三",
        "created_at": "2024-01-15T10:00:00Z",
        "updated_at": "2024-01-15T10:00:00Z",
        "version": 1,
        "attributes": {
            "name": "张三",
            "role": "高级前端工程师",
            "email": "zhangsan@techcorp.com",
            "phone": "+86 138 0000 1234",
            "location": "上海",
            "skills": ["React", "TypeScript", "Node.js", "GraphQL"],
            "department": "产品技术部",
            "alias": ["三哥", "ZS"]
        },
        "source": {
            "origin": "user_conversation",
            "conversation_id": "conv-2024-01-15-001",
            "extracted_at": "2024-01-15T10:00:00Z",
            "confidence": 0.9
        }
    }
}
```

### 3.2 实体 CRUD 操作规范

```
创建 (Create):
1. 检查本体中是否存在该 entity_type
2. 生成唯一 entity_id
3. 验证必需属性是否完整
4. 检查是否已存在同名实体（去重）
5. 设置 created_at 和 version = 1
6. 写入实体文件

读取 (Read):
1. 按 entity_id 精确查询
2. 按名称模糊搜索
3. 按类型过滤
4. 按属性值过滤
5. 支持分页

更新 (Update):
1. 验证 entity_id 存在
2. 合并新属性（不删除未指定的属性）
3. 更新 updated_at
4. version += 1
5. 创建版本快照（保留历史版本）

删除 (Delete):
1. 软删除：标记 deleted = true，保留数据
2. 硬删除：仅当无任何关系引用时允许
3. 删除前检查依赖关系
4. 记录删除操作日志
```

### 3.3 实体搜索

```bash
# 搜索实体（Agent 可执行的搜索逻辑）
search_entities() {
    local query=$1
    local type=$2  # 可选：按类型过滤

    # 搜索策略：
    # 1. 精确名称匹配
    # 2. 别名匹配
    # 3. 属性值包含搜索词
    # 4. 模糊匹配（编辑距离 ≤ 2）

    echo "搜索: \"$query\" ${type:+(类型: $type)}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # 返回匹配的实体列表，按相关度排序
    # [
    #   {"entity_id": "ent-xxx", "name": "...", "type": "...", "relevance": 0.95},
    #   {"entity_id": "ent-yyy", "name": "...", "type": "...", "relevance": 0.82}
    # ]
}
```

---

## 4. 关系管理（Relation Management）

### 4.1 关系创建

```json
{
    "relation": {
        "relation_id": "rel-001",
        "relation_type": "works_at",
        "subject": {
            "entity_id": "ent-person-001",
            "name": "张三"
        },
        "object": {
            "entity_id": "ent-org-001",
            "name": "科技有限公司"
        },
        "attributes": {
            "title": "高级前端工程师",
            "start_date": "2022-03-15",
            "is_current": true
        },
        "created_at": "2024-01-15T10:00:00Z",
        "updated_at": "2024-01-15T10:00:00Z",
        "version": 1,
        "source": {
            "origin": "user_conversation",
            "confidence": 0.95
        }
    }
}
```

### 4.2 关系存储格式

```json
{
    "relations": [
        {
            "relation_id": "rel-001",
            "relation_type": "works_at",
            "subject_id": "ent-person-001",
            "object_id": "ent-org-001",
            "attributes": {"title": "高级前端工程师", "is_current": true},
            "created_at": "2024-01-15T10:00:00Z",
            "version": 1
        },
        {
            "relation_id": "rel-002",
            "relation_type": "uses",
            "subject_id": "ent-person-001",
            "object_id": "ent-tech-001",
            "attributes": {"proficiency": "expert", "since": "2019-01-01"},
            "created_at": "2024-01-15T10:00:00Z",
            "version": 1
        },
        {
            "relation_id": "rel-003",
            "relation_type": "part_of",
            "subject_id": "ent-project-001",
            "object_id": "ent-org-001",
            "attributes": {"role": "核心产品"},
            "created_at": "2024-01-15T10:00:00Z",
            "version": 1
        }
    ]
}
```

### 4.3 关系约束验证

```
关系验证规则：
1. subject 和 object 的 entity_type 必须符合 relation_type 的定义
2. 必需的关系属性必须提供
3. 不允许创建重复关系（同一 subject + object + relation_type）
4. 自反关系检查（如 is_a 不应指向自身，除非有意为之）
5. 对称关系处理（如 related_to A→B 自动创建 B→A）

唯一性规则：
- (subject_id, relation_type, object_id) 三元组必须唯一
- 如需多条同类型关系，使用不同的 attributes 区分
```

---

## 5. 属性管理（Attribute Management）

### 5.1 属性数据类型

| 类型 | 格式 | 示例 | 校验规则 |
|------|------|------|----------|
| `string` | 任意文本 | `"张三"` | 非空 |
| `integer` | 整数 | `2024` | 合法整数 |
| `float` | 浮点数 | `3.14` | 合法数字 |
| `boolean` | 布尔值 | `true` | true/false |
| `date` | 日期 | `"2024-01-15"` | ISO 8601 |
| `datetime` | 日期时间 | `"2024-01-15T10:00:00Z"` | ISO 8601 |
| `array<string>` | 字符串数组 | `["A", "B"]` | 非空数组 |
| `enum:a\|b\|c` | 枚举 | `"active"` | 必须为枚举值之一 |

### 5.2 属性验证

```json
{
    "attribute_validation": {
        "entity_id": "ent-person-001",
        "entity_type": "Person",
        "validation_result": {
            "valid": true,
            "errors": [],
            "warnings": [
                {
                    "attribute": "email",
                    "message": "邮箱格式需要验证"
                }
            ]
        }
    }
}
```

---

## 6. 知识查询与遍历（Query & Traversal）

### 6.1 基础查询

```json
{
    "query": {
        "type": "get_entity",
        "params": {
            "entity_id": "ent-person-001"
        }
    }
}

{
    "query": {
        "type": "search_entities",
        "params": {
            "keyword": "张三",
            "entity_type": "Person",
            "max_results": 10
        }
    }
}

{
    "query": {
        "type": "get_relations",
        "params": {
            "entity_id": "ent-person-001",
            "direction": "outgoing",
            "relation_type": null
        }
    }
}
```

### 6.2 图遍历查询

```json
{
    "query": {
        "type": "traverse",
        "params": {
            "start_entity": "ent-person-001",
            "max_depth": 2,
            "direction": "both",
            "relation_types": ["works_at", "part_of", "uses"],
            "include_attributes": true,
            "max_results": 50
        },
        "description": "查找张三的同事（通过共同就职的组织）"
    }
}

{
    "query": {
        "type": "path_find",
        "params": {
            "from": "ent-person-001",
            "to": "ent-tech-005",
            "max_depth": 3,
            "relation_types": ["works_at", "uses", "depends_on", "is_a"]
        },
        "description": "查找张三与某技术之间的关联路径"
    }
}
```

### 6.3 模式匹配查询

```json
{
    "query": {
        "type": "pattern_match",
        "params": {
            "pattern": {
                "?person": {"type": "Person"},
                "relation": "works_at",
                "?org": {"type": "Organization", "attributes": {"industry": "互联网"}}
            },
            "return": ["?person", "?org"]
        },
        "description": "查找所有在互联网公司工作的人"
    }
}

{
    "query": {
        "type": "pattern_match",
        "params": {
            "pattern": {
                "?person": {"type": "Person"},
                "relation1": "uses",
                "?tech": {"type": "Technology", "attributes": {"tech_type": "language"}},
                "relation2": "works_at",
                "?org": {"type": "Organization"}
            },
            "return": ["?person", "?tech", "?org"],
            "conditions": "?tech.name == 'Rust'"
        },
        "description": "查找使用 Rust 的员工及其所在公司"
    }
}
```

### 6.4 聚合查询

```json
{
    "query": {
        "type": "aggregate",
        "params": {
            "entity_type": "Technology",
            "group_by": "tech_type",
            "metrics": ["count"],
            "sort_by": "count",
            "order": "desc"
        },
        "description": "统计各技术类型的数量"
    }
}

{
    "query": {
        "type": "aggregate",
        "params": {
            "start_entity_type": "Person",
            "traverse_relation": "works_at",
            "end_entity_type": "Organization",
            "group_by": "end_entity",
            "metrics": ["count"]
        },
        "description": "统计各公司的员工数量"
    }
}
```

---

## 7. 对话知识自动提取

### 7.1 提取规则

Agent 在与用户对话时，应主动识别和提取以下类型的知识：

```
知识提取触发规则：

1. 人物信息：
   - "我叫张三" → 创建 Person 实体
   - "我在腾讯工作" → works_at 关系
   - "我擅长 Python" → uses 关系

2. 组织信息：
   - "我们公司叫ABC科技" → 创建 Organization 实体
   - "ABC科技是做电商的" → 设置 industry 属性

3. 技术信息：
   - "这个项目用 React" → uses 关系
   - "React 是 Meta 开发的" → creator 属性
   - "Next.js 基于 React" → depends_on 关系

4. 项目信息：
   - "我们在做一个电商系统" → 创建 Project 实体
   - "这个项目已经做了3个月了" → 设置 start_date

5. 事件信息：
   - "上周五开了个需求评审会" → 创建 Event 实体

6. 概念信息：
   - "依赖注入是一种设计模式" → 创建 Concept 实体
   - "SOLID 原则包含五个原则" → 设置 attributes
```

### 7.2 提取置信度

```json
{
    "extraction": {
        "raw_statement": "我叫李明，在字节跳动做后端开发，主要用 Go 和 gRPC",
        "extracted_knowledge": [
            {
                "type": "entity",
                "entity_type": "Person",
                "name": "李明",
                "confidence": 0.95,
                "reason": "明确的人物信息声明"
            },
            {
                "type": "relation",
                "relation_type": "works_at",
                "subject": "李明",
                "object": "字节跳动",
                "relation_attributes": {
                    "title": "后端开发工程师"
                },
                "confidence": 0.90,
                "reason": "明确的工作关系声明"
            },
            {
                "type": "relation",
                "relation_type": "uses",
                "subject": "李明",
                "object": "Go",
                "relation_attributes": {
                    "proficiency": "primary",
                    "purpose": "后端开发"
                },
                "confidence": 0.85,
                "reason": "明确的技术使用声明"
            },
            {
                "type": "relation",
                "relation_type": "uses",
                "subject": "李明",
                "object": "gRPC",
                "relation_attributes": {
                    "purpose": "后端开发"
                },
                "confidence": 0.85,
                "reason": "明确的技术使用声明"
            }
        ],
        "extraction_metadata": {
            "conversation_id": "conv-xxx",
            "timestamp": "2024-01-15T14:30:00Z",
            "auto_confirmed": false,
            "requires_verification": false
        }
    }
}
```

### 7.3 提取后确认

```
提取确认规则：
1. confidence >= 0.9: 自动确认，直接入库
2. confidence 0.7-0.9: 优先入库，但标记待验证
3. confidence 0.5-0.7: 需要后续对话确认
4. confidence < 0.5: 暂不入库，仅记录到待确认队列

确认方式：
- 对话中自然追问："你说的XX是YY公司的对吗？"
- 在相关上下文中验证信息一致性
- 用户主动确认
```

---

## 8. 知识去重与冲突解决

### 8.1 去重策略

```json
{
    "deduplication": {
        "strategies": {
            "exact_name_match": {
                "description": "同一类型下名称完全相同的实体",
                "rule": "合并为一个实体，保留更完整的属性",
                "confidence_threshold": 0.95
            },
            "alias_match": {
                "description": "名称匹配另一个实体的别名",
                "rule": "合并，将匹配的名称加入别名列表",
                "confidence_threshold": 0.9
            },
            "fuzzy_match": {
                "description": "名称编辑距离 <= 2 且类型相同",
                "rule": "标记为可能重复，需人工确认",
                "confidence_threshold": 0.7
            },
            "semantic_match": {
                "description": "不同表述但指同一事物（如 'React' 和 'React.js'）",
                "rule": "基于上下文和关系图判断，需确认后合并",
                "confidence_threshold": 0.6
            }
        },
        "merge_rules": {
            "attributes": "保留更完整/更新的值，旧值移入 alias 列表",
            "relations": "合并所有关系，去重同类型关系",
            "versions": "保留两个实体的版本历史",
            "source": "记录所有来源信息"
        }
    }
}
```

### 8.2 冲突解决

```json
{
    "conflict_resolution": {
        "scenario": {
            "description": "同一实体的同一属性存在不同值",
            "example": "实体 '张三' 的 email 属性：旧值 a@old.com，新值 b@new.com"
        },
        "resolution_strategies": [
            {
                "strategy": "latest_wins",
                "description": "最新的值覆盖旧值",
                "use_when": "属性值随时间变化（如职位、电话）",
                "action": "使用 updated_at 最新的值，旧值记录到变更历史"
            },
            {
                "strategy": "merge",
                "description": "合并所有值（适用于数组类型属性）",
                "use_when": "skills、tags 等可累加属性",
                "action": "合并数组并去重"
            },
            {
                "strategy": "most_confident",
                "description": "使用置信度最高的来源",
                "use_when": "不同来源的置信度差异明显",
                "action": "选择 confidence 最高的值"
            },
            {
                "strategy": "most_complete",
                "description": "保留信息最完整的实体",
                "use_when": "两个实体的属性丰富度差异大",
                "action": "以属性更多的实体为主，合并另一个实体的独有属性"
            },
            {
                "strategy": "manual_resolve",
                "description": "标记冲突，等待人工解决",
                "use_when": "自动策略无法判断或置信度都较低",
                "action": "记录冲突详情，在下次交互时询问用户"
            }
        ],
        "conflict_log": {
            "conflict_id": "conf-001",
            "entity_id": "ent-person-001",
            "attribute": "email",
            "old_value": "a@old.com",
            "new_value": "b@new.com",
            "resolution": "latest_wins",
            "resolved_at": "2024-01-15T10:00:00Z",
            "resolved_by": "auto"
        }
    }
}
```

---

## 9. 时间版本控制

### 9.1 版本快照格式

```json
{
    "entity_versions": {
        "entity_id": "ent-person-001",
        "current_version": 3,
        "versions": [
            {
                "version": 1,
                "snapshot": {
                    "entity_type": "Person",
                    "name": "张三",
                    "role": "前端工程师",
                    "skills": ["React", "JavaScript"]
                },
                "created_at": "2024-01-15T10:00:00Z",
                "change_reason": "初始创建",
                "changed_by": "auto_extract"
            },
            {
                "version": 2,
                "snapshot": {
                    "entity_type": "Person",
                    "name": "张三",
                    "role": "高级前端工程师",
                    "skills": ["React", "JavaScript", "TypeScript"],
                    "email": "zhangsan@example.com"
                },
                "created_at": "2024-03-01T14:00:00Z",
                "change_reason": "对话更新：晋升为高级，新增 TypeScript 技能",
                "changed_by": "user_conversation",
                "diff": {
                    "modified": [
                        {"attribute": "role", "old": "前端工程师", "new": "高级前端工程师"},
                        {"attribute": "skills", "old": ["React", "JavaScript"], "new": ["React", "JavaScript", "TypeScript"]}
                    ],
                    "added": [{"attribute": "email", "value": "zhangsan@example.com"}],
                    "removed": []
                }
            },
            {
                "version": 3,
                "snapshot": {
                    "entity_type": "Person",
                    "name": "张三",
                    "role": "前端技术负责人",
                    "skills": ["React", "JavaScript", "TypeScript", "Node.js", "GraphQL"],
                    "email": "zhangsan@newcompany.com",
                    "department": "技术部"
                },
                "created_at": "2024-06-15T09:00:00Z",
                "change_reason": "对话更新：跳槽并晋升",
                "changed_by": "user_conversation",
                "diff": {
                    "modified": [
                        {"attribute": "role", "old": "高级前端工程师", "new": "前端技术负责人"},
                        {"attribute": "email", "old": "zhangsan@example.com", "new": "zhangsan@newcompany.com"},
                        {"attribute": "skills", "old": ["React", "JavaScript", "TypeScript"], "new": ["React", "JavaScript", "TypeScript", "Node.js", "GraphQL"]}
                    ],
                    "added": [{"attribute": "department", "value": "技术部"}],
                    "removed": []
                }
            }
        ]
    }
}
```

### 9.2 版本查询

```
版本操作：
1. 查看当前版本: GET /entities/{id} → 返回最新版本
2. 查看历史版本: GET /entities/{id}/versions → 返回所有版本列表
3. 查看特定版本: GET /entities/{id}/versions/{v} → 返回该版本快照
4. 版本对比: GET /entities/{id}/diff?v1=1&v2=3 → 返回差异
5. 回滚到指定版本: POST /entities/{id}/rollback?v=2 → 创建新版本（内容=v2）
6. 查看变更时间线: GET /entities/{id}/timeline → 按时间线展示变更
```

### 9.3 关系版本控制

```
关系的版本控制规则：
1. 关系属性变更时 version += 1
2. 关系的 subject/object 变更时创建新关系
3. 标记 is_current = false 表示关系已结束
4. 保留历史关系记录用于时间线查询

示例：张三从公司A跳槽到公司B
- 关系 rel-001: (张三, works_at, 公司A) → 设置 is_current=false, end_date=2024-06-01
- 关系 rel-010: (张三, works_at, 公司B) → 新建, is_current=true, start_date=2024-06-15
```

---

## 10. 与 Agent 记忆系统集成

### 10.1 集成架构

```
┌──────────────────────────────────────────────────┐
│                  Agent 记忆系统                     │
├──────────────────────────────────────────────────┤
│                                                  │
│  ┌───────────┐  ┌───────────┐  ┌──────────────┐ │
│  │ 短期记忆   │  │ 长期记忆   │  │  知识图谱     │ │
│  │ (对话上下文)│  │ (经历/事件)│  │  (结构化知识)  │ │
│  │           │  │           │  │              │ │
│  │ 生命周期:  │  │ 生命周期:  │  │ 生命周期:    │ │
│  │ 当前会话   │  │ 持久存储   │  │ 持久存储     │ │
│  └─────┬─────┘  └─────┬─────┘  └──────┬───────┘ │
│        │              │               │          │
│        └──────────────┼───────────────┘          │
│                       │                          │
│              ┌────────▼────────┐                  │
│              │  记忆协调器      │                  │
│              │  (Coordinator)  │                  │
│              └─────────────────┘                  │
└──────────────────────────────────────────────────┘

协调规则：
1. 对话中出现事实性信息 → 自动提取到知识图谱
2. 知识图谱中的信息 → 辅助理解用户意图
3. 长期记忆中的事件 → 关联到知识图谱中的 Event 实体
4. 回答问题时综合三者的信息
```

### 10.2 记忆查询优先级

```
当 Agent 需要回答问题时：

1. 首先检查短期记忆（当前对话上下文）
2. 然后查询知识图谱（结构化事实）
3. 最后检索长期记忆（历史经验和事件）

知识增强回答：
- 知识图谱提供精确事实（人物关系、技术栈、项目状态）
- 长期记忆提供经验判断（之前类似情况的处理方式）
- 短期记忆提供当前上下文（用户正在讨论什么）
```

---

## 11. 领域知识图谱构建示例

### 11.1 软件工程团队知识图谱

```json
{
    "domain_graph": {
        "name": "软件工程团队知识图谱",
        "description": "记录团队成员、技术栈、项目依赖关系的知识图谱",
        "entities": {
            "people": [
                {"entity_id": "ent-p-001", "type": "Person", "name": "张三", "role": "前端技术负责人", "skills": ["React", "TypeScript", "Next.js"]},
                {"entity_id": "ent-p-002", "type": "Person", "name": "李四", "role": "后端架构师", "skills": ["Go", "gRPC", "Kubernetes"]},
                {"entity_id": "ent-p-003", "type": "Person", "name": "王五", "role": "产品经理", "skills": ["需求分析", "用户研究", "Jira"]}
            ],
            "technologies": [
                {"entity_id": "ent-t-001", "type": "Technology", "name": "React", "tech_type": "framework", "paradigm": ["functional", "component-based"]},
                {"entity_id": "ent-t-002", "type": "Technology", "name": "Go", "tech_type": "language", "paradigm": ["concurrent", "procedural"]},
                {"entity_id": "ent-t-003", "type": "Technology", "name": "TypeScript", "tech_type": "language", "paradigm": ["object-oriented", "functional"]},
                {"entity_id": "ent-t-004", "type": "Technology", "name": "PostgreSQL", "tech_type": "database"},
                {"entity_id": "ent-t-005", "type": "Technology", "name": "Docker", "tech_type": "tool"},
                {"entity_id": "ent-t-006", "type": "Technology", "name": "Kubernetes", "tech_type": "platform"}
            ],
            "projects": [
                {"entity_id": "ent-prj-001", "type": "Project", "name": "电商系统", "status": "active", "priority": "high"},
                {"entity_id": "ent-prj-002", "type": "Project", "name": "内部管理后台", "status": "active", "priority": "medium"}
            ],
            "organizations": [
                {"entity_id": "ent-org-001", "type": "Organization", "name": "科技有限公司", "org_type": "company", "industry": "互联网"}
            ]
        },
        "relations": [
            {"relation_type": "works_at", "subject": "ent-p-001", "object": "ent-org-001", "attributes": {"title": "前端技术负责人", "is_current": true}},
            {"relation_type": "works_at", "subject": "ent-p-002", "object": "ent-org-001", "attributes": {"title": "后端架构师", "is_current": true}},
            {"relation_type": "works_at", "subject": "ent-p-003", "object": "ent-org-001", "attributes": {"title": "产品经理", "is_current": true}},
            {"relation_type": "uses", "subject": "ent-p-001", "object": "ent-t-001", "attributes": {"proficiency": "expert"}},
            {"relation_type": "uses", "subject": "ent-p-002", "object": "ent-t-002", "attributes": {"proficiency": "expert"}},
            {"relation_type": "part_of", "subject": "ent-p-001", "object": "ent-prj-001", "attributes": {"role": "前端负责人"}},
            {"relation_type": "part_of", "subject": "ent-p-002", "object": "ent-prj-001", "attributes": {"role": "后端负责人"}},
            {"relation_type": "depends_on", "subject": "ent-t-001", "object": "ent-t-003", "attributes": {"dependency_type": "hard"}},
            {"relation_type": "uses", "subject": "ent-prj-001", "object": "ent-t-004", "attributes": {"purpose": "数据存储"}},
            {"relation_type": "uses", "subject": "ent-prj-001", "object": "ent-t-005", "attributes": {"purpose": "容器化部署"}}
        ]
    }
}
```

### 11.2 知识图谱可视化（文本格式）

```
知识图谱可视化 — 电商系统项目相关

  ┌──────────┐ works_at ┌──────────────┐
  │  张三     │────────►│ 科技有限公司   │
  │ (前端TL)  │         │  (互联网)      │
  └────┬─────┘         └──────▲───────┘
       │                     │ works_at
       │ part_of             │
       ▼                     │
  ┌──────────┐         ┌────┴─────┐
  │ 电商系统   │◄─uses──│  李四     │
  │ (active)  │         │ (后端架构) │
  └────┬─────┘         └────┬─────┘
       │                    │
       │ uses               │ uses
       ▼                    ▼
  ┌──────────┐         ┌──────────┐
  │PostgreSQL│         │   Go     │
  └──────────┘         └──────────┘

  张三 ──uses──► React (expert)
  张三 ──uses──► TypeScript
  React ──depends_on──► TypeScript
  电商系统 ──uses──► Docker
```

---

## 12. 知识推理与推断

### 12.1 推理规则

```json
{
    "inference_rules": [
        {
            "rule_id": "infer-colleague",
            "name": "同事推断",
            "description": "如果 A 和 B 都就职于同一组织，则 A 和 B 是同事",
            "condition": {
                "pattern": [
                    "?A works_at ?Org (is_current=true)",
                    "?B works_at ?Org (is_current=true)"
                ],
                "filter": "?A != ?B"
            },
            "inference": {
                "relation": "related_to",
                "between": ["?A", "?B"],
                "attributes": {
                    "strength": "moderate",
                    "description": "同事关系（通过共同组织推断）"
                },
                "confidence": 0.8
            }
        },
        {
            "rule_id": "infer-tech-stack",
            "name": "技术栈推断",
            "description": "如果项目使用了技术 A，而技术 A 依赖于技术 B，则项目也间接使用 B",
            "condition": {
                "pattern": [
                    "?Project uses ?A",
                    "?A depends_on ?B"
                ]
            },
            "inference": {
                "relation": "uses",
                "between": ["?Project", "?B"],
                "attributes": {
                    "purpose": "间接依赖（通过 A）"
                },
                "confidence": 0.7
            }
        },
        {
            "rule_id": "infer-skill-transfer",
            "name": "技能迁移推断",
            "description": "如果 A 擅长框架 X，而 X 基于 Y，则 A 可能也熟悉 Y",
            "condition": {
                "pattern": [
                    "?Person uses ?X (proficiency=expert)",
                    "?X depends_on ?Y"
                ]
            },
            "inference": {
                "relation": "has_knowledge_about",
                "between": ["?Person", "?Y"],
                "attributes": {
                    "level": "familiar",
                    "verified": false,
                    "source": "技能迁移推断"
                },
                "confidence": 0.6
            }
        },
        {
            "rule_id": "infer-is-a-chain",
            "name": "IS-A 传递推断",
            "description": "IS-A 关系支持传递：A is_a B, B is_a C → A is_a C",
            "condition": {
                "pattern": [
                    "?A is_a ?B",
                    "?B is_a ?C"
                ]
            },
            "inference": {
                "relation": "is_a",
                "between": ["?A", "?C"],
                "confidence": 0.75
            }
        }
    ]
}
```

### 12.2 推理置信度衰减

```
推理置信度衰减规则：
1. 直接关系：confidence = 1.0
2. 一度推理（一步推断）：confidence = 基础置信度 * 0.8
3. 二度推理（两步推断）：confidence = 基础置信度 * 0.6
4. 三度推理（三步推断）：confidence = 基础置信度 * 0.4
5. 超过三度：不自动推理，需显式确认

显示规则：
- confidence >= 0.8: 作为事实展示
- confidence 0.5-0.8: 作为"可能"展示，标注来源为推断
- confidence < 0.5: 仅内部使用，不对外展示
```

---

## 13. 存储格式与文件结构

### 13.1 文件结构

```
~/.knowledge-graph/
├── ontology.json                 # 本体定义
├── entities/                     # 实体存储
│   ├── Person/
│   │   ├── ent-person-001.json
│   │   ├── ent-person-002.json
│   │   └── _index.json          # 实体名称索引
│   ├── Organization/
│   │   ├── ent-org-001.json
│   │   └── _index.json
│   ├── Technology/
│   │   ├── ent-tech-001.json
│   │   └── _index.json
│   ├── Project/
│   │   └── _index.json
│   └── ...
├── relations/                    # 关系存储
│   ├── works_at.json
│   ├── uses.json
│   ├── part_of.json
│   ├── depends_on.json
│   └── related_to.json
├── relations_by_entity/          # 按实体的关系索引
│   ├── ent-person-001.json      # 该实体的所有关系
│   └── ...
├── versions/                     # 版本历史
│   ├── ent-person-001.json      # 该实体的版本历史
│   └── ...
├── pending/                      # 待确认知识
│   ├── extractions.json          # 待确认的提取结果
│   └── conflicts.json            # 待解决的冲突
├── inference/                    # 推断结果缓存
│   └── inferred_relations.json
├── stats/                        # 统计信息
│   └── graph-stats.json
└── backup/                       # 自动备份
    └── kg-backup-2024-01-15.json.gz
```

### 13.2 索引文件格式

```json
{
    "_index": {
        "entity_type": "Person",
        "total_count": 15,
        "entries": [
            {"entity_id": "ent-person-001", "name": "张三", "alias": ["三哥", "ZS"], "created_at": "2024-01-15T10:00:00Z"},
            {"entity_id": "ent-person-002", "name": "李四", "alias": [], "created_at": "2024-01-15T10:05:00Z"}
        ],
        "name_index": {
            "张三": "ent-person-001",
            "李四": "ent-person-002",
            "三哥": "ent-person-001"
        }
    }
}
```

### 13.3 图统计信息

```json
{
    "graph_stats": {
        "generated_at": "2024-01-15T12:00:00Z",
        "entity_counts": {
            "Person": 15,
            "Organization": 5,
            "Technology": 28,
            "Project": 8,
            "Concept": 12,
            "Event": 20,
            "Document": 35
        },
        "total_entities": 123,
        "relation_counts": {
            "works_at": 15,
            "uses": 42,
            "part_of": 18,
            "depends_on": 25,
            "related_to": 30,
            "is_a": 12,
            "authored": 22,
            "participated_in": 35,
            "has_knowledge_about": 40
        },
        "total_relations": 239,
        "pending_extractions": 8,
        "pending_conflicts": 2,
        "inferred_relations": 45,
        "storage_size_mb": 2.4,
        "last_backup": "2024-01-15T03:00:00Z"
    }
}
```

### 13.4 定期维护

```
维护任务：
1. 每日: 更新索引，处理待确认提取，清理过期推断缓存
2. 每周: 图统计，冲突批量处理，备份
3. 每月: 去重扫描，本体审查，性能优化

维护规则：
- 实体无任何关系且超过 90 天 → 标记为 orphan
- 推断关系 30 天未被引用 → 清理
- 待确认提取超过 14 天未确认 → 降低优先级
- 版本历史超过 20 个版本 → 压缩早期版本
```
