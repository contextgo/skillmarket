# OpenClaw 初始化向导

OpenClaw 初始化向导 是一个面向 OpenClaw Agent 的技能资产，用于把特定任务场景沉淀为可复用、可执行、可验证的工作流程。

## 核心能力

- 根据用户任务触发对应的操作步骤
- 复用 `SKILL.md` 中定义的规则、边界和输出格式
- 提升 Agent 执行一致性，减少重复判断和无效沟通
- 适合安装到 OpenClaw 环境中作为能力扩展

## 原始能力简介

OpenClaw 个人 AgentOS 初始化向导 / Bootstrapper。Use when a user wants to initialize, diagnose, upgrade, repair, or health-check a new or existing OpenClaw setup; install baseline skills; add web search and skill discovery; set up HOT/WARM/COLD memory; create an Obsidian-friendly Markdown knowledge base; configure Agent teams; establish self-evolution workflows; reduce context pollution; or bootstrap OpenClaw into a personal AgentOS. 触发词：OpenClaw 初始化、AgentOS 启动器、新用户引导、安装必要 skill、搭建三层记忆、个人知识库、Obsidian、Agent 团队、自进化、健康检查、一键修复、一键升级、上下文污染治理。

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他文件：技能所需参考资料、脚本或测试提示词
