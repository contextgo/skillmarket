#!/usr/bin/env bash
# ============================================================================
# bind-feishu-bot.sh — 给 StepClaw 绑定一个飞书机器人到指定 agent/subagent
# ============================================================================

set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
fail() { echo -e "${RED}❌ $1${NC}"; exit 1; }

extract_first_json() {
  python3 -c 'import json,sys
text = sys.stdin.read()
start = text.find("{")
if start < 0:
    raise SystemExit("no json object found")
obj, _ = json.JSONDecoder().raw_decode(text[start:])
print(json.dumps(obj, ensure_ascii=False))'
}

get_config_json() {
  local attempt raw
  for attempt in 1 2 3 4 5 6 7 8; do
    if raw=$("$OPENCLAW_BIN" gateway call config.get --json 2>/tmp/feishu-bot-binder-config-get.err); then
      printf '%s' "$raw" | extract_first_json
      return 0
    fi
    sleep 1
  done
  return 1
}

usage() {
  cat <<'USAGE'
用法:
  bash bind-feishu-bot.sh \
    --agent-id "main-2" \
    --account-id "main-2" \
    --app-id "cli_xxx" \
    --app-secret "xxx" \
    [--agent-name "客服助手"] \
    [--dm-policy "open"] \
    [--group-policy "open"] \
    [--require-mention "true"]

说明:
  - --account-id 为必填，避免脚本自动猜错飞书 account
  - 若 --agent-id 不存在，脚本会自动创建新 agent
  - 新 agent 默认 workspace: ~/.stepclaw/workspace-<agent-id>
USAGE
}

AGENT_ID=""
AGENT_NAME=""
ACCOUNT_ID=""
APP_ID=""
APP_SECRET=""
DM_POLICY="open"
GROUP_POLICY="open"
REQUIRE_MENTION="true"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --agent-id)        AGENT_ID="${2:-}";        shift 2 ;;
    --agent-name)      AGENT_NAME="${2:-}";      shift 2 ;;
    --account-id)      ACCOUNT_ID="${2:-}";      shift 2 ;;
    --app-id)          APP_ID="${2:-}";          shift 2 ;;
    --app-secret)      APP_SECRET="${2:-}";      shift 2 ;;
    --dm-policy)       DM_POLICY="${2:-}";       shift 2 ;;
    --group-policy)    GROUP_POLICY="${2:-}";    shift 2 ;;
    --require-mention) REQUIRE_MENTION="${2:-}"; shift 2 ;;
    -h|--help)         usage; exit 0 ;;
    *) fail "未知参数: $1" ;;
  esac
done

[[ -n "$AGENT_ID" ]] || fail "缺少 --agent-id"
[[ -n "$ACCOUNT_ID" ]] || fail "缺少 --account-id"
[[ -n "$APP_ID" ]] || fail "缺少 --app-id"
[[ -n "$APP_SECRET" ]] || fail "缺少 --app-secret"
[[ "$APP_ID" =~ ^cli_ ]] || fail "App ID 格式错误，应以 cli_ 开头，当前值: $APP_ID"
[[ "$DM_POLICY" =~ ^(open|pairing)$ ]] || fail "--dm-policy 仅支持 open 或 pairing"
[[ "$GROUP_POLICY" =~ ^(open|allowlist|disabled)$ ]] || fail "--group-policy 仅支持 open / allowlist / disabled"
[[ "$REQUIRE_MENTION" =~ ^(true|false)$ ]] || fail "--require-mention 仅支持 true 或 false"
[[ -n "$AGENT_NAME" ]] || AGENT_NAME="$AGENT_ID"

STEPCLAW_DIR="$HOME/.stepclaw"
CONFIG_FILE="$STEPCLAW_DIR/openclaw.json"
OPENCLAW_BIN="$STEPCLAW_DIR/bin/openclaw"
WORKSPACE_PATH="$STEPCLAW_DIR/workspace-$AGENT_ID"
AGENT_DIR_PATH="$STEPCLAW_DIR/agents/$AGENT_ID/agent"

[[ -f "$CONFIG_FILE" ]] || fail "找不到 $CONFIG_FILE，请先完成 StepClaw 初始化"
[[ -x "$OPENCLAW_BIN" ]] || fail "找不到 StepClaw 自带 CLI: $OPENCLAW_BIN"

echo "============================================"
echo "飞书机器人绑定配置 (StepClaw)"
echo "============================================"
echo "Agent ID:       $AGENT_ID"
echo "Agent Name:     $AGENT_NAME"
echo "Account ID:     $ACCOUNT_ID"
echo "App ID:         $APP_ID"
echo "App Secret:     ${APP_SECRET:0:6}***"
echo "DM Policy:      $DM_POLICY"
echo "Group Policy:   $GROUP_POLICY"
echo "Require @:      $REQUIRE_MENTION"
echo "Workspace:      $WORKSPACE_PATH"
echo "============================================"
echo ""

ok "读取当前配置快照"
CONFIG_GET_JSON=$(get_config_json) || fail "读取当前配置失败，请检查 StepClaw gateway 状态"
BASE_HASH=$(printf '%s' "$CONFIG_GET_JSON" | python3 -c 'import json,sys; print(json.load(sys.stdin)["hash"])') || fail "无法解析 config.get 返回的 hash"
CONFIG_SNAPSHOT_FILE=$(mktemp /tmp/feishu-bot-binder-config.XXXXXX.json)
printf '%s' "$CONFIG_GET_JSON" > "$CONFIG_SNAPSHOT_FILE"

PATCH_JSON=$(python3 - "$CONFIG_SNAPSHOT_FILE" "$AGENT_ID" "$AGENT_NAME" "$ACCOUNT_ID" "$APP_ID" "$APP_SECRET" "$DM_POLICY" "$GROUP_POLICY" "$REQUIRE_MENTION" "$WORKSPACE_PATH" "$AGENT_DIR_PATH" <<'PY'
import json
import sys

config_path, agent_id, agent_name, account_id, app_id, app_secret, dm_policy, group_policy, require_mention, workspace_path, agent_dir_path = sys.argv[1:]
with open(config_path, 'r', encoding='utf-8') as fh:
    payload = json.load(fh)
parsed = payload.get('parsed') or {}
require_mention = require_mention == 'true'

agents = list((((parsed.get('agents') or {}).get('list')) or []))
bindings = list(parsed.get('bindings') or [])
channels = parsed.get('channels') or {}
feishu = channels.get('feishu') or {}
accounts = dict(feishu.get('accounts') or {})

for binding in bindings:
    match = binding.get('match') or {}
    if match.get('channel') == 'feishu' and match.get('accountId') == account_id:
        raise SystemExit(f'binding already exists for feishu accountId={account_id}')

agent_exists = any((agent.get('id') == agent_id) for agent in agents)
if not agent_exists:
    agents.append({
        'id': agent_id,
        'name': agent_name,
        'workspace': workspace_path,
        'agentDir': agent_dir_path,
    })

accounts[account_id] = {
    'enabled': True,
    'appId': app_id,
    'appSecret': app_secret,
    'dmPolicy': dm_policy,
    'groupPolicy': group_policy,
    'requireMention': require_mention,
    'allowFrom': ['*'],
}

bindings.append({
    'agentId': agent_id,
    'match': {
        'channel': 'feishu',
        'accountId': account_id,
    },
})

patch = {
    'agents': {'list': agents},
    'bindings': bindings,
    'channels': {
        'feishu': {
            'enabled': True,
            'accounts': accounts,
        }
    },
    'plugins': {
        'entries': {
            'openclaw-lark': {'enabled': True}
        }
    }
}

print(json.dumps(patch, ensure_ascii=False))
PY
) || {
  rm -f "$CONFIG_SNAPSHOT_FILE"
  fail "无法构建配置补丁。若 accountId 已绑定，请更换 --account-id。"
}

if python3 - "$CONFIG_SNAPSHOT_FILE" "$AGENT_ID" <<'PY'
import json
import sys
with open(sys.argv[1], 'r', encoding='utf-8') as fh:
    payload = json.load(fh)
agents = (((payload.get('parsed') or {}).get('agents') or {}).get('list')) or []
raise SystemExit(0 if any((a.get('id') == sys.argv[2]) for a in agents) else 1)
PY
then
  ok "目标 agent 已存在，准备追加飞书 account 和 binding"
else
  ok "目标 agent 不存在，准备自动创建"
  mkdir -p "$WORKSPACE_PATH" "$AGENT_DIR_PATH"
fi

rm -f "$CONFIG_SNAPSHOT_FILE"

NOTE="飞书机器人 $ACCOUNT_ID 已绑定到 agent $AGENT_ID"
PARAMS_JSON=$(python3 - "$BASE_HASH" "$PATCH_JSON" "$NOTE" <<'PY'
import json
import sys
base_hash = sys.argv[1]
raw = sys.argv[2]
note = sys.argv[3]
print(json.dumps({'baseHash': base_hash, 'raw': raw, 'note': note}, ensure_ascii=False))
PY
) || fail "无法构建 config.patch 参数"

echo "📝 写入配置（accounts + agents.list + bindings）..."
"$OPENCLAW_BIN" gateway call config.patch --json --params "$PARAMS_JSON" >/tmp/feishu-bot-binder-config-patch.json \
  || fail "配置写入失败，请检查 gateway 日志"
ok "配置已写入"

echo ""
echo "🔍 验证配置结果..."
VERIFY_JSON=$(get_config_json) || fail "写入后无法重新读取配置"
VERIFY_FILE=$(mktemp /tmp/feishu-bot-binder-verify.XXXXXX.json)
printf '%s' "$VERIFY_JSON" > "$VERIFY_FILE"
if python3 - "$VERIFY_FILE" "$AGENT_ID" "$ACCOUNT_ID" <<'PY'
import json
import sys
with open(sys.argv[1], 'r', encoding='utf-8') as fh:
    payload = json.load(fh)
agent_id, account_id = sys.argv[2], sys.argv[3]
parsed = payload.get('parsed') or {}
accounts = (((parsed.get('channels') or {}).get('feishu') or {}).get('accounts')) or {}
if account_id not in accounts:
    raise SystemExit(1)
if not any((a.get('id') == agent_id) for a in ((((parsed.get('agents') or {}).get('list')) or []))):
    raise SystemExit(2)
if not any(((b.get('agentId') == agent_id) and ((b.get('match') or {}).get('channel') == 'feishu') and ((b.get('match') or {}).get('accountId') == account_id)) for b in (parsed.get('bindings') or [])):
    raise SystemExit(3)
PY
then
  ok "配置验证通过"
else
  code=$?
  rm -f "$VERIFY_FILE"
  case $code in
    1) fail "写入后未找到目标 feishu account: $ACCOUNT_ID" ;;
    2) fail "写入后未找到目标 agent: $AGENT_ID" ;;
    3) fail "写入后未找到目标 binding: feishu/$ACCOUNT_ID -> $AGENT_ID" ;;
    *) fail "写入后验证失败" ;;
  esac
fi
rm -f "$VERIFY_FILE"

"$OPENCLAW_BIN" gateway status >/tmp/feishu-bot-binder-gateway-status.txt 2>&1 \
  && ok "Gateway 状态检查完成" \
  || warn "Gateway 状态检查未通过，请手动执行: ~/.stepclaw/bin/openclaw gateway status"

echo ""
ok "=========================================="
ok "🎉 飞书机器人绑定完成！"
ok "=========================================="
echo ""
echo "📋 绑定摘要:"
echo "   Agent:      $AGENT_ID ($AGENT_NAME)"
echo "   Account:    $ACCOUNT_ID"
echo "   飞书应用:    $APP_ID"
echo "   Workspace:  $WORKSPACE_PATH"
echo "   DM策略:     $DM_POLICY"
echo "   群聊策略:    $GROUP_POLICY"
echo "   需要@:      $REQUIRE_MENTION"
echo ""
echo "📋 下一步:"
echo "   1. 确认飞书应用已开启机器人能力、事件订阅（长连接）、im.message.receive_v1"
echo "   2. 确认飞书应用已发布上线"
echo "   3. 运行 '~/.stepclaw/bin/openclaw gateway status' 检查诊断"
echo "   4. 在飞书中找到机器人，发一条消息测试"
