# StepClaw Feishu Binder — 绑定到指定 Subagent

这个 Skill 的核心能力是把飞书机器人绑定到 StepClaw 的指定 agent / subagent，而不是只支持 `main`。

它会先读取 `~/.stepclaw/openclaw.json` 中的 `agents.list` 和 `bindings`，然后按下面两种路径工作：
- 目标 agent 已存在：直接写入 feishu account，并追加 account-scoped binding
- 目标 agent 不存在：自动创建新 agent，再一起写入 account 和 binding

## 适用范围

- 把新的飞书 App ID / App Secret 写入 `~/.stepclaw`
- 绑定到已有 subagent
- 自动创建新 subagent
- 写入顶层 `bindings`，把指定 feishu account 路由到指定 agent
- 确保 `plugins.entries.openclaw-lark.enabled = true`

## 前置条件

- StepClaw 已安装
- `~/.stepclaw/bin/openclaw` 可用
- 已拿到飞书应用的 App ID 和 App Secret
- 飞书应用已开启机器人能力，准备配置长连接事件

## 使用方法

```bash
bash <skill_dir>/scripts/bind-feishu-bot.sh \
  --agent-id "main-2" \
  --agent-name "客服助手" \
  --account-id "customer-service-bot" \
  --app-id "cli_a9xxxxxxxxxxxx" \
  --app-secret "your-app-secret-here" \
  --dm-policy "open" \
  --group-policy "open" \
  --require-mention "true"
```

## 参数说明

| 参数 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `--agent-id` | ✅ | - | 目标 agent / subagent 标识 |
| `--agent-name` | ❌ | 同 agent-id | 若自动创建 agent，用于展示名称 |
| `--account-id` | ✅ | - | 飞书 account 标识，避免脚本自动猜错 |
| `--app-id` | ✅ | - | 飞书 App ID（`cli_xxx`） |
| `--app-secret` | ✅ | - | 飞书 App Secret |
| `--dm-policy` | ❌ | `open` | `open` / `pairing` |
| `--group-policy` | ❌ | `open` | `open` / `allowlist` / `disabled` |
| `--require-mention` | ❌ | `true` | 群聊是否必须 @ 机器人 |

## 脚本做了什么

1. 调用 `~/.stepclaw/bin/openclaw gateway call config.get --json`
2. 读取当前 `agents.list`、`bindings` 和配置 `hash`
3. 检查目标 agent 是否存在，不存在则自动创建
4. 检查 `accountId` 是否已被现有 Feishu binding 占用
5. 构造单次 patch，同时写入：
   - `channels.feishu.accounts.<accountId>`
   - `agents.list`
   - 顶层 `bindings`
   - `plugins.entries.openclaw-lark`
6. patch 后重试读取配置，验证 account、agent、binding 都已生效
7. 执行 `gateway status` 做最后检查

## 默认创建策略

如果脚本需要自动创建 agent，会默认使用：
- `workspace`: `~/.stepclaw/workspace-<agent-id>`
- `agentDir`: `~/.stepclaw/agents/<agent-id>/agent`

## 冲突策略

如果同一个 `accountId` 已经存在 Feishu binding，脚本会直接报错退出，不会静默覆盖。

## 多 agent 场景

顶层 `bindings` 的真实结构如下：

```json
{
  "agentId": "main-2",
  "match": {
    "channel": "feishu",
    "accountId": "customer-service-bot"
  }
}
```

这就是把某个飞书机器人路由到指定 subagent 的关键配置。
