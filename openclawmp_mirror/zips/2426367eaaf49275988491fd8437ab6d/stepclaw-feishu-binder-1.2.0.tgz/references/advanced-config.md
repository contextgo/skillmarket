# 高级配置参考

## 先查看已有 subagent

在绑定前，先查看当前 StepClaw 已有哪些 agent：

```bash
~/.stepclaw/bin/openclaw gateway call config.get --json
```

重点关注：
- `agents.list`
- `bindings`
- `channels.feishu.accounts`

## 自动创建 agent 的默认目录

当前脚本在目标 agent 不存在时，会默认创建：

- `workspace`: `~/.stepclaw/workspace-<agent-id>`
- `agentDir`: `~/.stepclaw/agents/<agent-id>/agent`

如果你要自定义这些目录，建议先手动 patch `agents.list`，再执行绑定。

## 群聊白名单

如果 `groupPolicy` 设为 `allowlist`，需要配置允许的群：

```json
{
  "channels": {
    "feishu": {
      "accounts": {
        "<account-id>": {
          "groupPolicy": "allowlist",
          "groupAllowFrom": ["oc_xxx", "oc_yyy"]
        }
      }
    }
  }
}
```

## DM 白名单

限制只有特定用户能私聊：

```json
{
  "channels": {
    "feishu": {
      "accounts": {
        "<account-id>": {
          "dmPolicy": "open",
          "allowFrom": ["ou_xxx", "ou_yyy"]
        }
      }
    }
  }
}
```

## 多 agent / 多机器人路由

Feishu 绑定 subagent 的核心是顶层 `bindings`：

```json
{
  "bindings": [
    {
      "agentId": "main",
      "match": {
        "channel": "feishu",
        "accountId": "bot-a"
      }
    },
    {
      "agentId": "customer-service",
      "match": {
        "channel": "feishu",
        "accountId": "bot-b"
      }
    }
  ]
}
```

## 冲突说明

如果同一个 `accountId` 已经存在于某条 Feishu binding 中：
- 当前脚本会直接退出
- 不会自动改绑到新 agent
- 需要你先手动删除旧 binding，再重新绑定

## 删除绑定

如果要移除一个飞书机器人绑定：

1. 删除 `channels.feishu.accounts.<account-id>`
2. 删除 `bindings` 中对应 `match.channel=feishu + match.accountId=<account-id>` 的条目
3. 再次执行 `~/.stepclaw/bin/openclaw gateway status` 检查诊断
