---
name: obsidian
description: Work with Obsidian vaults (plain Markdown notes) and automate via obsidian-cli.
homepage: https://help.obsidian.md
metadata: {"clawdbot":{"emoji":"💎","requires":{"bins":["obsidian-cli"]},"install":[{"id":"brew","kind":"brew","formula":"yakitrak/yakitrak/obsidian-cli","bins":["obsidian-cli"],"label":"Install obsidian-cli (brew)"}]}}
---

# Obsidian

Obsidian vault = a normal folder on disk.

Vault structure (typical)
- Notes: `*.md` (plain text Markdown; edit with any editor)
- Config: `.obsidian/` (workspace + plugin settings; usually don't touch from scripts)
- Canvases: `*.canvas` (JSON)
- Attachments: whatever folder you chose in Obsidian settings (images/PDFs/etc.)

---

## Prerequisites

Run these checks **once at the start of every session** before any vault operation.
Do NOT proceed past a failing step — all subsequent commands depend on it.

**Step 1 — obsidian-cli available?**
```
obsidian-cli --version
```
- OK: version string printed → continue.
- Fail: run `brew install yakitrak/yakitrak/obsidian-cli`, then re-check.

**Step 2 — Obsidian desktop installed?**
```
ls /Applications/Obsidian.app
```
- OK: directory exists → continue.
- Fail: the `create --open` command will silently fail (URI handler missing).
  Direct file writes (`write_note` in the Python helper) still work.
  Inform the user and use the fallback path for note creation.

**Step 3 — Vault config exists?**
```
cat ~/Library/Application\ Support/obsidian/obsidian.json
```
- OK: JSON with a `vaults` key → continue to "Resolve the working vault".
- Fail (file missing or empty): Obsidian has never been launched on this machine.
  Ask the user to open Obsidian once and create or open a vault, then retry.

---

## Resolve the working vault (always do this first)

Follow this decision tree — stop at the first step that succeeds:

1. `obsidian-cli print-default --path-only`
   → Returns a valid path: use it as the vault root. Done.

2. Empty or error: read the config directly.
   ```
   cat ~/Library/Application\ Support/obsidian/obsidian.json
   ```
   → Find the entry with `"open": true`, or the entry with the highest `"ts"` value.
   → Use its `"path"` field as the vault root.
   → Optionally persist: `obsidian-cli set-default "<vault-folder-name>"`

3. Config has multiple vaults with no clear active one:
   → List them all and ask the user: "Which vault should I work with?"
   → After confirmation: `obsidian-cli set-default "<vault-name>"`

4. Config has no vaults:
   → Stop. Tell the user: "No Obsidian vault detected. Please open Obsidian,
     create or open a vault, then retry."

**Rules:**
- Never guess or hardcode a vault path.
- Multiple vaults are common (iCloud vs `~/Documents`, work vs personal).
  Always confirm with the user if ambiguous.
- Vault name = folder name (path suffix), not the full path.

---

## obsidian-cli quick start

Pick a default vault (once):
- `obsidian-cli set-default "<vault-folder-name>"`
- `obsidian-cli print-default` / `obsidian-cli print-default --path-only`

List all notes (no obsidian-cli equivalent)
- `python3 scripts/obsidian_helper.py list` (use this; obsidian-cli has no "list all" command)
- `python3 scripts/obsidian_helper.py list --folder "Projects"` (limit to a sub-folder)

Search
- `obsidian-cli search "query"` (note names)
- `obsidian-cli search-content "query"` (inside notes; shows snippets + lines)

Create
- **Before creating**, confirm with the user if not already provided:
  - Note title (used as filename; Chinese characters are fine)
  - Target folder (default: vault root if the user does not specify)
  - Content (ask the user to provide, or present an AI-generated draft for confirmation before writing)

- **Primary:** `obsidian-cli create "Folder/New note" --content "..." --open`
  Requires Obsidian URI handler active (Obsidian desktop must be installed and running).
  If the command returns no error but the note does not appear: URI handler is not
  working — use the fallback below.

- **Fallback (always works):** write the `.md` file directly to the vault folder.
  ```
  python3 scripts/obsidian_helper.py write "Folder/New note" "Your content here"
  ```
  Obsidian detects file changes automatically; no restart needed.
  Prefer this fallback when:
  - Obsidian is not currently running.
  - Content contains Chinese or other non-ASCII characters.
  - Content is multi-line or contains shell-special characters (`"`, `'`, `$`, etc.).

- Avoid creating notes under hidden dot-folders (e.g. `.something/...`) — Obsidian ignores them.

Move/rename (safe refactor)
- `obsidian-cli move "old/path/note" "new/path/note"`
- Updates `[[wikilinks]]` and common Markdown links across the vault (main win vs `mv`).

Delete
- `obsidian-cli delete "path/note"`

Prefer direct edits when appropriate: open the `.md` file and change it; Obsidian picks it up.

---

## Working with non-ASCII content (Chinese, etc.)

obsidian-cli works on macOS (UTF-8 terminal by default). Watch out for edge cases:

- **Long or multi-line content via `--content`**: shell quoting breaks easily.
  Use the Python helper's `write` command instead — no quoting issues.

- **Note names with Chinese characters** are safe for `search`, `move`, and `delete`.

- **Garbled search results**: check terminal locale with `locale` — must show UTF-8
  (e.g. `en_US.UTF-8` or `zh_CN.UTF-8`). Fix with `export LANG=en_US.UTF-8`.

- **Recommended pattern for any substantial Chinese content:**
  Write content to a temp `.md` file, then move it into the vault folder directly
  (or use `write_note` in the Python helper). Avoids all shell-quoting issues.

---

## Python helper (scripts/obsidian_helper.py)

A standalone utility for file-system operations on the vault.
**Does not require obsidian-cli.** Use it as a reliable fallback or for
tasks where shell-quoting is a risk (Chinese content, long text, multi-line notes).

Available commands:

| Command | What it does |
|---------|-------------|
| `config` | Print the path to obsidian.json |
| `resolve` | Print the active vault root path |
| `list` | List all .md files (optionally under a sub-folder) |
| `read <note>` | Print a note's content |
| `write <note> <content>` | Write/overwrite a note (UTF-8 safe) |

Quick reference:
```bash
# Find vault config path
python3 scripts/obsidian_helper.py config

# Show active vault root
python3 scripts/obsidian_helper.py resolve

# List all notes
python3 scripts/obsidian_helper.py list

# List notes in a sub-folder
python3 scripts/obsidian_helper.py list --folder "Projects"

# Read a note
python3 scripts/obsidian_helper.py read "Projects/My note"

# Write a note (content as argument)
python3 scripts/obsidian_helper.py write "Projects/My note" "Note body here"

# Write a note (content from stdin — safe for long/Chinese content)
echo "内容" | python3 scripts/obsidian_helper.py write "Projects/笔记" -

# Use a specific vault by name
python3 scripts/obsidian_helper.py resolve --name "Work"
python3 scripts/obsidian_helper.py list --vault "Work"
```

All functions handle UTF-8 encoding explicitly and skip hidden directories
(`.obsidian/`, `.trash/`, etc.) automatically.

Run `python3 scripts/obsidian_helper.py --help` or `<subcommand> --help` for full options.
