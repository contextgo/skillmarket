#!/usr/bin/env python3
"""
obsidian_helper.py — Obsidian vault file-system utilities.

Provides low-level helpers that work without obsidian-cli:
  - find_vault_config()   → path to obsidian.json (OS-aware)
  - resolve_vault()       → active vault root path
  - list_notes()          → list .md files under a folder
  - read_note()           → read a note's content
  - write_note()          → write/overwrite a note safely (UTF-8)

All functions are independent and can be called individually.
Use as a library (import) or run directly with --help for CLI usage.

Encoding: all file I/O is explicit UTF-8, safe for Chinese and other
non-ASCII content — avoids the shell-quoting issues of obsidian-cli.
"""

import json
import os
import sys
import argparse
from pathlib import Path


# ---------------------------------------------------------------------------
# Core helpers
# ---------------------------------------------------------------------------

def find_vault_config() -> Path:
    """
    Return the path to Obsidian's obsidian.json for the current OS.

    macOS : ~/Library/Application Support/obsidian/obsidian.json
    Linux : ~/.config/obsidian/obsidian.json  (Electron default)

    Raises FileNotFoundError if the config does not exist (Obsidian never
    launched, or installed in a non-standard location).
    """
    if sys.platform == "darwin":
        config_path = Path.home() / "Library" / "Application Support" / "obsidian" / "obsidian.json"
    else:
        # Linux fallback (XDG)
        xdg_config = os.environ.get("XDG_CONFIG_HOME", str(Path.home() / ".config"))
        config_path = Path(xdg_config) / "obsidian" / "obsidian.json"

    if not config_path.exists():
        raise FileNotFoundError(
            f"Obsidian config not found at: {config_path}\n"
            "Make sure Obsidian desktop has been launched at least once."
        )
    return config_path


def resolve_vault(vault_name: str | None = None) -> Path:
    """
    Resolve the vault root path.

    Resolution order:
      1. If vault_name is given: match by folder name in obsidian.json vaults.
      2. If not given: pick the vault with "open": true.
      3. If none is open: pick the vault with the most recent "ts" timestamp.
      4. If still ambiguous: raise ValueError listing available vaults.

    Returns the vault root as a Path object.
    """
    config_path = find_vault_config()
    with open(config_path, "r", encoding="utf-8") as f:
        config = json.load(f)

    vaults: dict = config.get("vaults", {})
    if not vaults:
        raise ValueError(
            "No vaults found in obsidian.json. "
            "Open Obsidian and create or open a vault first."
        )

    # Build list of (vault_id, vault_info) for easier iteration
    vault_list = list(vaults.items())

    # 1. Match by name
    if vault_name:
        for vid, vinfo in vault_list:
            p = Path(vinfo["path"])
            if p.name == vault_name or str(p) == vault_name:
                return p
        available = [Path(v["path"]).name for _, v in vault_list]
        raise ValueError(
            f"Vault '{vault_name}' not found. Available: {available}"
        )

    # 2. Currently open vault
    for vid, vinfo in vault_list:
        if vinfo.get("open"):
            return Path(vinfo["path"])

    # 3. Most recently accessed
    vault_list.sort(key=lambda x: x[1].get("ts", 0), reverse=True)
    return Path(vault_list[0][1]["path"])


def list_notes(vault_path: str | Path, folder: str = "") -> list[Path]:
    """
    List all .md files under <vault_path>/<folder>.

    Args:
        vault_path: Root path of the vault (string or Path).
        folder:     Sub-folder relative to vault root. Empty = whole vault.

    Returns:
        Sorted list of Path objects (relative to vault root).

    Skips .obsidian/ and other dot-directories automatically.
    """
    root = Path(vault_path) / folder if folder else Path(vault_path)
    if not root.exists():
        raise FileNotFoundError(f"Folder not found: {root}")

    notes = []
    for p in root.rglob("*.md"):
        # Skip hidden directories (e.g. .obsidian, .trash)
        if any(part.startswith(".") for part in p.parts):
            continue
        notes.append(p.relative_to(vault_path))

    return sorted(notes)


def read_note(vault_path: str | Path, note_path: str) -> str:
    """
    Read a note's content.

    Args:
        vault_path: Root path of the vault.
        note_path:  Path to the note relative to vault root.
                    May omit the .md extension.

    Returns:
        Note content as a UTF-8 string.
    """
    p = Path(vault_path) / note_path
    if not p.suffix:
        p = p.with_suffix(".md")
    if not p.exists():
        raise FileNotFoundError(f"Note not found: {p}")
    return p.read_text(encoding="utf-8")


def write_note(vault_path: str | Path, note_path: str, content: str, overwrite: bool = True) -> Path:
    """
    Write (or overwrite) a note.

    Args:
        vault_path: Root path of the vault.
        note_path:  Path relative to vault root (folders created automatically).
                    May omit .md extension.
        content:    Note body as a UTF-8 string.
        overwrite:  If False and the note exists, raise FileExistsError.

    Returns:
        Absolute Path of the written file.

    Use this instead of `obsidian-cli create` when:
      - Content contains Chinese or other non-ASCII characters.
      - Content is multi-line or contains shell-special characters.
      - Obsidian is not currently running (URI handler unavailable).
    Obsidian detects new/changed files automatically — no restart needed.
    """
    p = Path(vault_path) / note_path
    if not p.suffix:
        p = p.with_suffix(".md")

    if p.exists() and not overwrite:
        raise FileExistsError(f"Note already exists: {p}")

    # Create intermediate directories if needed
    p.parent.mkdir(parents=True, exist_ok=True)

    # Avoid dot-folder paths (Obsidian ignores them)
    for part in p.relative_to(vault_path).parts:
        if part.startswith("."):
            raise ValueError(
                f"Note path contains a hidden segment '{part}'. "
                "Obsidian ignores notes inside dot-folders."
            )

    p.write_text(content, encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# CLI interface
# ---------------------------------------------------------------------------

def _cmd_config(args):
    print(find_vault_config())


def _cmd_resolve(args):
    print(resolve_vault(args.name or None))


def _cmd_list(args):
    vault = resolve_vault(args.vault or None)
    notes = list_notes(vault, args.folder or "")
    for n in notes:
        print(n)


def _cmd_read(args):
    vault = resolve_vault(args.vault or None)
    print(read_note(vault, args.note))


def _cmd_write(args):
    vault = resolve_vault(args.vault or None)
    content = args.content
    if content == "-":
        content = sys.stdin.read()
    written = write_note(vault, args.note, content, overwrite=not args.no_overwrite)
    print(f"Written: {written}")


def main():
    parser = argparse.ArgumentParser(
        description="Obsidian vault file-system helpers (UTF-8 safe, no obsidian-cli required)."
    )
    sub = parser.add_subparsers(dest="cmd", required=True)

    # config
    p_config = sub.add_parser("config", help="Print path to obsidian.json")
    p_config.set_defaults(func=_cmd_config)

    # resolve
    p_resolve = sub.add_parser("resolve", help="Print active vault root path")
    p_resolve.add_argument("--name", help="Vault name to look up (default: active vault)")
    p_resolve.set_defaults(func=_cmd_resolve)

    # list
    p_list = sub.add_parser("list", help="List notes (.md files) in the vault")
    p_list.add_argument("--vault", help="Vault name (default: active vault)")
    p_list.add_argument("--folder", default="", help="Sub-folder to list (default: entire vault)")
    p_list.set_defaults(func=_cmd_list)

    # read
    p_read = sub.add_parser("read", help="Print a note's content")
    p_read.add_argument("note", help="Note path relative to vault root")
    p_read.add_argument("--vault", help="Vault name (default: active vault)")
    p_read.set_defaults(func=_cmd_read)

    # write
    p_write = sub.add_parser("write", help="Write/overwrite a note (UTF-8 safe)")
    p_write.add_argument("note", help="Note path relative to vault root")
    p_write.add_argument("content", help='Note content string, or "-" to read from stdin')
    p_write.add_argument("--vault", help="Vault name (default: active vault)")
    p_write.add_argument("--no-overwrite", action="store_true", help="Fail if note already exists")
    p_write.set_defaults(func=_cmd_write)

    args = parser.parse_args()
    try:
        args.func(args)
    except (FileNotFoundError, FileExistsError, ValueError) as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
