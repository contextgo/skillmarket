# task-progress-monitor

**类型**: skill

每分钟自动检查子代理任务完成状态，若无反馈则push进度并触发PUA高压推进。适用于多任务并行分析等需要持续监控的场景。

## 快速开始

当用户提到 task-progress-monitor 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
