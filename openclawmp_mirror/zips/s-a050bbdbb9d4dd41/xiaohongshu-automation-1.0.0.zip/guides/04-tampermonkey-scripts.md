# 04 - 油猴脚本配置

油猴脚本（Tampermonkey）是浏览器用户脚本管理器，可在小红书页面注入自定义功能，如批量下载、数据提取、界面优化等。

---

## 4.1 环境准备

### 安装 Tampermonkey
1. Chrome 扩展商店搜索 "Tampermonkey"
2. 点击「添加至 Chrome」
3. 扩展图标出现，点击打开管理面板

### 油猴面板
- **仪表盘**：已安装脚本列表
- **创建新脚本**：从头编写
- **实用脚本**：从用户脚本仓库（greasyfork.org）搜索安装

---

## 4.2 脚本1：爆款笔记批量采集

### 功能
- 在小红书搜索页/热榜页批量提取笔记信息
- 一键导出为 CSV
- 自动去重

### 脚本代码
```javascript
// ==UserScript==
// @name         小红书爆款采集助手
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  从小红书搜索/热榜页批量采集笔记数据
// @author       GOGO AI Assistant
// @match        https://www.xiaohongshu.com/explore*
// @match        https://www.xiaohongshu.com/search_result*
// @grant        GM_setClipboard
// @grant        GM_download
// ==/UserScript==

(function() {
    'use strict';

    // 添加采集按钮到页面
    const btn = document.createElement('button');
    btn.textContent = '📥 采集当前页笔记';
    btn.style.cssText = `
        position: fixed; top: 10px; right: 10px; z-index: 9999;
        padding: 8px 16px; background: #ff2442; color: white;
        border: none; border-radius: 4px; cursor: pointer;
        font-weight: bold;
    `;
    document.body.appendChild(btn);

    btn.addEventListener('click', async () => {
        const notes = [];
        const items = document.querySelectorAll('.note-item'); // 根据实际选择器调整

        items.forEach(item => {
            const title = item.querySelector('h3')?.textContent?.trim() || '';
            const link = item.querySelector('a')?.href || '';
            const author = item.querySelector('.author')?.textContent?.trim() || '';
            const likes = item.querySelector('.like-count')?.textContent?.trim() || '0';
            const collects = item.querySelector('.collect-count')?.textContent?.trim() || '0';
            const comments = item.querySelector('.comment-count')?.textContent?.trim() || '0';

            notes.push([title, link, author, likes, collects, comments]);
        });

        // 转换为 CSV
        const csv = '标题,链接,作者,点赞,收藏,评论\n' +
            notes.map(n => `"${n[0]}","${n[1]}","${n[2]}","${n[3]}","${n[4]}","${n[5]}"`).join('\n');

        // 下载文件
        const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8' });
        const url = URL.createObjectURL(blob);
        GM_download({
            url,
            name: `xiaohongshu_hot_${new Date().toISOString().slice(0,10)}.csv`,
            saveAs: true
        });

        alert(`已采集 ${notes.length} 条笔记，开始下载 CSV`);
    });
})();
```

### 使用方法
1. 打开小红书搜索/热榜页
2. 点击右上角红色按钮「📥 采集当前页笔记」
3. 自动下载 CSV 文件
4. 导入飞书表格分析

---

## 4.3 脚本2：笔记详情数据提取

### 功能
- 打开单条笔记，提取详细数据
- 包括：正文、标签、发布时间、互动数、作者信息
- 一键复制为 JSON 或 CSV

### 脚本代码
```javascript
// ==UserScript==
// @name         小红书笔记详情提取
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  提取单条笔记的详细信息
// @grant        GM_setClipboard
// ==/UserScript==

(function() {
    'use strict';

    // 添加提取按钮
    const btn = document.createElement('button');
    btn.textContent = '📋 提取本笔记数据';
    btn.style.cssText = `
        position: fixed; top: 10px; left: 10px; z-index: 9999;
        padding: 8px 16px; background: #07c160; color: white;
        border: none; border-radius: 4px; cursor: pointer;
    `;
    document.body.appendChild(btn);

    btn.addEventListener('click', () => {
        const data = {
            title: document.querySelector('h1')?.textContent?.trim() || '',
            author: document.querySelector('.author-name')?.textContent?.trim() || '',
            authorId: document.querySelector('.author-id')?.textContent?.trim() || '',
            publishDate: document.querySelector('.publish-time')?.textContent?.trim() || '',
            content: document.querySelector('.content')?.textContent?.trim() || '',
            tags: Array.from(document.querySelectorAll('.tag')).map(t => t.textContent.trim()),
            images: Array.from(document.querySelectorAll('.image-item img')).map(img => img.src),
            likes: document.querySelector('.like-count')?.textContent?.trim() || '0',
            collects: document.querySelector('.collect-count')?.textContent?.trim() || '0',
            comments: document.querySelector('.comment-count')?.textContent?.trim() || '0',
            url: window.location.href,
            crawlTime: new Date().toISOString()
        };

        const json = JSON.stringify(data, null, 2);
        navigator.clipboard.writeText(json).then(() => {
            alert('数据已复制到剪贴板（JSON格式）！');
            console.log('小红书笔记数据:', data);
        });
    });
})();
```

### 使用
1. 打开小红书笔记详情页
2. 点击左上角绿色按钮「📋 提取本笔记数据」
3. 数据复制到剪贴板
4. 粘贴到飞书表格或 JSON 文件

---

## 4.4 脚本3：图片/视频批量下载

### 功能
- 在笔记详情页，一键下载所有图片或视频
- 自动创建文件夹，按笔记ID命名

### 脚本代码
```javascript
// ==UserScript==
// @name         小红书图片视频下载
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  批量下载笔记中的图片和视频
// @grant        GM_download
// ==/UserScript==

(function() {
    'use strict';

    const btn = document.createElement('button');
    btn.textContent = '💾 下载全部图片';
    btn.style.cssText = `
        position: fixed; top: 40px; left: 10px; z-index: 9999;
        padding: 8px 16px; background: #ff6b6b; color: white;
        border: none; border-radius: 4px; cursor: pointer;
    `;
    document.body.appendChild(btn);

    btn.addEventListener('click', async () => {
        const images = document.querySelectorAll('.image-item img, .carousel-img');
        const noteId = window.location.pathname.split('/').pop() || 'note';

        for (let i = 0; i < images.length; i++) {
            const img = images[i];
            const src = img.src || img.dataset.src;
            if (!src) continue;

            // 等待图片加载完成
            await new Promise(resolve => {
                if (img.complete) resolve();
                else img.onload = resolve;
            });

            // 下载
            GM_download({
                url: src,
                name: `${noteId}_${i+1}.jpg`,
                saveAs: false // 自动保存到默认下载文件夹
            });

            // 间隔避免过快
            await new Promise(r => setTimeout(r, 500));
        }

        alert(`开始下载 ${images.length} 张图片`);
    });
})();
```

---

## 4.5 脚本4：评论情感分析（高级）

### 功能
- 提取笔记所有评论
- 调用 AI API 分析情感倾向（正面/负面/中性）
- 导出分析结果

### 脚本代码（框架）
```javascript
// ==UserScript==
// @name         小红书评论情感分析
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  分析笔记评论情感倾向
// @grant        GM_xmlhttpRequest
// ==/UserScript==

(function() {
    'use strict';

    const btn = document.createElement('button');
    btn.textContent = '😊 分析评论情感';
    btn.style.cssText = `
        position: fixed; top: 70px; left: 10px; z-index: 9999;
        padding: 8px 16px; background: #4a90e2; color: white;
        border: none; border-radius: 4px; cursor: pointer;
    `;
    document.body.appendChild(btn);

    btn.addEventListener('click', async () => {
        // 1. 滚动加载所有评论
        while (true) {
            const loadMore = document.querySelector('.load-more-comments');
            if (!loadMore) break;
            loadMore.click();
            await new Promise(r => setTimeout(r, 2000));
        }

        // 2. 提取评论
        const commentEls = document.querySelectorAll('.comment-item');
        const comments = Array.from(commentEls).map(el => ({
            user: el.querySelector('.username')?.textContent?.trim(),
            content: el.querySelector('.content')?.textContent?.trim(),
            likes: el.querySelector('.like-count')?.textContent?.trim() || '0'
        }));

        // 3. 调用 AI API 分析情感（示例使用 OpenAI 格式）
        const sentiments = [];
        for (const c of comments) {
            const resp = await GM_xmlhttpRequest({
                method: 'POST',
                url: 'https://api.openai.com/v1/chat/completions',
                headers: {
                    'Authorization': 'Bearer YOUR_API_KEY',
                    'Content-Type': 'application/json'
                },
                data: JSON.stringify({
                    model: 'gpt-3.5-turbo',
                    messages: [{
                        role: 'user',
                        content: `分析这条评论的情感（正面/负面/中性）：${c.content}`
                    }]
                })
            });
            const sentiment = JSON.parse(resp.responseText).choices[0].message.content;
            sentiments.push({...c, sentiment});
        }

        // 4. 导出 CSV
        const csv = '用户,评论内容,点赞,情感\n' +
            sentiments.map(s => `"${s.user}","${s.content}",${s.likes},"${s.sentiment}"`).join('\n');

        const blob = new Blob(['\ufeff' + csv], {type: 'text/csv'});
        const url = URL.createObjectURL(blob);
        GM_download({url, name: `comments_sentiment_${Date.now()}.csv`});

        alert(`分析完成，共 ${sentiments.length} 条评论`);
    });
})();
```

**注意**：需要替换 `YOUR_API_KEY` 为真实的 AI API Key（如 OpenAI、StepFun）。

---

## 4.6 脚本5：界面增强（快捷操作）

### 功能
- 在笔记页面添加快捷按钮
- 一键复制标题、标签、链接
- 快速切换无水印图片查看

### 脚本代码
```javascript
// ==UserScript==
// @name         小红书界面增强
// @namespace    http://tampermonkey.net/
// @version      1.0
// @description  添加快捷操作按钮
// @grant        GM_setClipboard
// ==/UserScript==

(function() {
    'use strict';

    const toolbar = document.createElement('div');
    toolbar.style.cssText = `
        position: fixed; top: 10px; left: 50%; transform: translateX(-50%);
        display: flex; gap: 10px; z-index: 9999;
        background: rgba(255,255,255,0.9); padding: 8px; border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    `;

    const buttons = [
        {text: '📋 复制标题', action: () => {
            const title = document.querySelector('h1')?.textContent?.trim();
            GM_setClipboard(title);
            alert('标题已复制');
        }},
        {text: '🏷️ 复制标签', action: () => {
            const tags = Array.from(document.querySelectorAll('.tag')).map(t => t.textContent.trim()).join(' ');
            GM_setClipboard(tags);
            alert('标签已复制');
        }},
        {text: '🔗 复制链接', action: () => {
            GM_setClipboard(window.location.href);
            alert('链接已复制');
        }},
        {text: '🖼️ 原图模式', action: () => {
            const imgs = document.querySelectorAll('.image-item img');
            imgs.forEach(img => {
                const src = img.src;
                img.src = src.replace(/^[^?]*\?/, '').replace(/@\w+$/, '@original');
            });
            alert('已切换为原图模式');
        }}
    ];

    buttons.forEach(b => {
        const btn = document.createElement('button');
        btn.textContent = b.text;
        btn.style.cssText = 'padding: 6px 12px; border: 1px solid #ddd; background: white; border-radius: 4px; cursor: pointer;';
        btn.onclick = b.action;
        toolbar.appendChild(btn);
    });

    document.body.appendChild(toolbar);
})();
```

---

## 4.7 脚本管理

### 创建新脚本
1. 点击 Tampermonkey 图标 → 仪表盘
2. 点击「+」创建新脚本
3. 粘贴代码，保存（Ctrl+S）
4. 启用开关

### 更新脚本
- 编辑脚本 → 修改 `@version` → 保存
- 或点击「检查更新」自动检测

### 脚本生效范围
- `@match` 指定 URL 模式
- 可设置多个 `@match` 行
- 或使用 `@include`、`@exclude`

---

## 4.8 调试与排错

### 查看控制台
- 打开小红书页面
- F12 → Console
- 脚本 `console.log` 输出会显示在这里

### 常见错误
| 错误 | 原因 | 解决 |
|------|------|------|
| `GM_download is not defined` | 未声明 `@grant GM_download` | 添加 grant 声明 |
| 选择器无效 | 页面结构变化 | 用检查器重新获取选择器 |
| 跨域请求失败 | API 域名不在 `@connect` 列表 | 添加 `@connect api.example.com` |
| 按钮不显示 | `@match` 不匹配当前页 | 检查 URL 和 match 规则 |

---

## 4.9 最佳实践

1. **性能**：避免频繁 DOM 操作，批量处理
2. **兼容性**：选择器尽量通用，避免依赖特定 class（易变）
3. **用户体验**：添加按钮不要遮挡页面内容（固定位置、半透明）
4. **错误提示**：失败时 alert 或 console.error 明确提示
5. **数据安全**：API Key 不要硬编码，用 `GM_getValue`/`GM_setValue` 存储

---

## 4.10 脚本仓库推荐

- **Greasy Fork**：https://greasyfork.org/zh-CN
  - 搜索「小红书」可找到社区脚本
  - 安装前查看评分和评论
  - 注意脚本权限（仅申请必要的 grant）

---

**下一步**：油猴脚本掌握后，继续 [05 - AI 内容生成 Prompt](./05-ai-prompts.md)

---

**维护者**: GOGO AI Assistant
**更新日期**: 2026-02-28
**版本**: 1.0.0
