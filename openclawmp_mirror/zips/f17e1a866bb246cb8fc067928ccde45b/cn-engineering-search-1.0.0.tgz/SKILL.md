# cn-engineering-search

🏗️ 建设工程领域专业搜索工具。基于 Perplexity API，针对工程咨询、造价管控、招标采购、项目管理、商事调解等专业场景优化。

## 功能特性

- 🔍 **工程领域智能搜索**：针对建设工程专业术语和场景优化
- 📋 **快捷查询模板**：内置常用查询类型，一键调用
- 📊 **造价指标检索**：快速获取各地造价指标、价格指数
- 📜 **规范标准查询**：检索最新国家标准、行业规范
- ⚖️ **政策法规解读**：获取最新工程相关政策、司法解释
- 📈 **行业动态追踪**：工程造价、招标代理行业最新动态

## 环境变量

- `PERPLEXITY_API_KEY` (必需): Perplexity API Key

### 配置方式

**方式一：WorkBuddy 环境变量（推荐）**

在 WorkBuddy 设置中配置：
```
PERPLEXITY_API_KEY = your-api-key-here
```

**方式二：系统环境变量**

Windows PowerShell:
```powershell
$env:PERPLEXITY_API_KEY="your-api-key-here"
```

Windows CMD:
```cmd
set PERPLEXITY_API_KEY=your-api-key-here
```

**获取 API Key**：https://www.perplexity.ai/settings/api

## 依赖

- `node` (Node.js 运行时)

## 使用方法

### 基础搜索
```bash
node {baseDir}/scripts/search.mjs "GB/T 50500-2024 建设工程工程量清单计价标准"
```

### 使用快捷模板
```bash
# 查询造价指标
node {baseDir}/scripts/search.mjs --template cost-index "海南省 2024 房屋建筑"

# 查询规范标准
node {baseDir}/scripts/search.mjs --template standard "招标代理服务规范"

# 查询政策法规
node {baseDir}/scripts/search.mjs --template policy "建设工程价款结算暂行办法"

# 查询行业动态
node {baseDir}/scripts/search.mjs --template news "工程造价咨询行业 AI 应用"

# 查询商事调解
node {baseDir}/scripts/search.mjs --template mediation "建设工程合同纠纷调解案例"
```

### 批量搜索
```bash
node {baseDir}/scripts/search.mjs "2026年建筑造价指数" "最新招标代理规范" "工程商事调解案例"
```

### JSON 输出
```bash
node {baseDir}/scripts/search.mjs --json "工程造价咨询行业发展趋势"
```

## 快捷模板说明

| 模板 | 用途 | 示例 |
|------|------|------|
| `cost-index` | 造价指标查询 | 各地单方造价、价格指数 |
| `standard` | 规范标准查询 | 国标、行标、地标 |
| `policy` | 政策法规查询 | 部委文件、司法解释 |
| `news` | 行业动态查询 | 行业报告、市场分析 |
| `mediation` | 商事调解查询 | 调解案例、争议解决 |
| `tender` | 招标采购查询 | 招标规范、评标方法 |
| `contract` | 合同管理查询 | 合同示范文本、条款解读 |

## 工程咨询场景示例

### 造价管控场景
```bash
node {baseDir}/scripts/search.mjs --template cost-index "广东省 2025 市政道路工程"
node {baseDir}/scripts/search.mjs "GB/T 50500-2024 工程量清单计价规范变化"
node {baseDir}/scripts/search.mjs "2026年钢材水泥价格走势预测"
```

### 招标采购场景
```bash
node {baseDir}/scripts/search.mjs --template tender "电子招投标平台操作规范"
node {baseDir}/scripts/search.mjs "评标委员会组成要求 2025"
node {baseDir}/scripts/search.mjs "必须招标的限额标准最新调整"
```

### 合同管理场景
```bash
node {baseDir}/scripts/search.mjs --template contract "建设工程施工合同示范文本 GF-2017-0201"
node {baseDir}/scripts/search.mjs "工程变更签证管理规范"
node {baseDir}/scripts/search.mjs "建设工程价款优先受偿权司法解释"
```

### 商事调解场景
```bash
node {baseDir}/scripts/search.mjs --template mediation "建设工程价款纠纷调解案例"
node {baseDir}/scripts/search.mjs "工期延误索赔调解实务"
node {baseDir}/scripts/search.mjs "工程质量争议调解程序"
```

### 项目管理场景
```bash
node {baseDir}/scripts/search.mjs "GB/T 50326 建设工程项目管理规范"
node {baseDir}/scripts/search.mjs "工程总承包 EPC 管理模式"
node {baseDir}/scripts/search.mjs "全过程工程咨询服务内容"
```

## 注意事项

1. **API Key 配置**：推荐使用 WorkBuddy 环境变量配置 `PERPLEXITY_API_KEY`
2. **模板使用**：建议使用 `--template` 参数获得更精准的专业结果
3. **批量查询**：批量查询会合并为一次 API 调用，节省成本
4. **结果核实**：结果包含引用来源，便于核实信息准确性
5. **网络要求**：需要联网访问 Perplexity API

## 版本信息

- **版本**: 1.0.0
- **作者**: 度量衡智库
- **更新日期**: 2026-04-10
- **依赖**: Perplexity API
