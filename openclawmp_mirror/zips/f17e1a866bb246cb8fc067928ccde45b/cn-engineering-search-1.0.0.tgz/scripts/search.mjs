#!/usr/bin/env node

/**
 * cn-engineering-search
 * 建设工程领域专业搜索工具
 * 基于 Perplexity API，针对工程咨询场景优化
 */

const args = process.argv.slice(2);

// 工程领域查询模板
const TEMPLATES = {
  'cost-index': {
    prefix: '建设工程造价指标 单方造价 价格指数',
    desc: '造价指标查询'
  },
  'standard': {
    prefix: '国家标准 行业标准 规范 GB GB/T',
    desc: '规范标准查询'
  },
  'policy': {
    prefix: '建设工程政策法规 部委文件 司法解释',
    desc: '政策法规查询'
  },
  'news': {
    prefix: '工程造价 招标代理 工程咨询 行业动态',
    desc: '行业动态查询'
  },
  'mediation': {
    prefix: '建设工程商事调解 合同纠纷 争议解决',
    desc: '商事调解查询'
  },
  'tender': {
    prefix: '招标采购 招标投标 评标 政府采购',
    desc: '招标采购查询'
  },
  'contract': {
    prefix: '建设工程合同 施工合同 示范文本',
    desc: '合同管理查询'
  }
};

// 解析参数
const queries = [];
let jsonOutput = false;
let template = null;

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  if (arg === '--json') {
    jsonOutput = true;
  } else if (arg === '--template' && i + 1 < args.length) {
    template = args[i + 1];
    i++; // 跳过下一个参数
  } else if (arg === '--help' || arg === '-h') {
    showHelp();
    process.exit(0);
  } else if (arg === '--list-templates') {
    listTemplates();
    process.exit(0);
  } else if (!arg.startsWith('-')) {
    queries.push(arg);
  }
}

// 显示帮助
function showHelp() {
  console.log(`
🏗️  cn-engineering-search - 建设工程领域专业搜索工具

用法:
  node search.mjs [选项] <查询内容...>

选项:
  --template <类型>     使用预设模板（cost-index, standard, policy, news, mediation, tender, contract）
  --json               输出 JSON 格式
  --list-templates     列出所有可用模板
  --help, -h           显示帮助

示例:
  node search.mjs "GB/T 50500-2024 工程量清单计价规范"
  node search.mjs --template cost-index "海南省 2024 房屋建筑"
  node search.mjs --template standard "招标代理服务规范"
  node search.mjs --template mediation "建设工程价款纠纷"
  node search.mjs --json "工程造价咨询行业发展趋势"
`);
}

// 列出模板
function listTemplates() {
  console.log('\n📋 可用查询模板:\n');
  for (const [key, value] of Object.entries(TEMPLATES)) {
    console.log(`  ${key.padEnd(12)} - ${value.desc}`);
  }
  console.log('');
}

// 验证参数
if (queries.length === 0) {
  console.error('❌ 错误: 请提供查询内容');
  console.error('\n使用 --help 查看帮助，或使用 --list-templates 查看可用模板');
  process.exit(1);
}

// 验证模板
if (template && !TEMPLATES[template]) {
  console.error(`❌ 错误: 未知模板 "${template}"`);
  console.error('\n可用模板:');
  listTemplates();
  process.exit(1);
}

// 检查 API Key（支持 WorkBuddy 环境变量配置）
const apiKey = process.env.PERPLEXITY_API_KEY;
if (!apiKey) {
  console.error('❌ 错误: 未设置 PERPLEXITY_API_KEY 环境变量');
  console.error('\n配置方式:');
  console.error('  方式一（推荐）: 在 WorkBuddy 设置中配置 PERPLEXITY_API_KEY');
  console.error('  方式二: 设置系统环境变量');
  console.error('    Windows PowerShell: $env:PERPLEXITY_API_KEY="your-api-key"');
  console.error('    Windows CMD:        set PERPLEXITY_API_KEY=your-api-key');
  console.error('\n获取 API Key: https://www.perplexity.ai/settings/api');
  console.error('\nWorkBuddy 配置说明:');
  console.error('  1. 打开 WorkBuddy 设置');
  console.error('  2. 添加环境变量: PERPLEXITY_API_KEY = your-api-key');
  console.error('  3. 保存后重启 WorkBuddy 或重新加载 Skill');
  process.exit(1);
}

// 应用模板优化查询
function optimizeQuery(query, templateKey) {
  if (!templateKey || !TEMPLATES[templateKey]) {
    // 默认添加工程领域上下文
    return `建设工程 ${query}`;
  }
  
  const template = TEMPLATES[templateKey];
  return `${template.prefix} ${query}`;
}

// 搜索函数
async function search(queries, template) {
  // 优化查询
  const optimizedQueries = queries.map(q => optimizeQuery(q, template));
  
  console.log(`🔍 正在搜索 (${template ? `模板: ${template}` : '默认模式'})...\n`);
  
  const response = await fetch("https://api.perplexity.ai/search", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      query: optimizedQueries,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Perplexity API 错误 (${response.status}): ${error}`);
  }

  return response.json();
}

// 格式化结果
function formatResult(result, query) {
  const lines = [];
  
  if (query) {
    lines.push(`\n## 🔍 ${query}\n`);
  }

  // 处理数组结果
  if (Array.isArray(result)) {
    for (const item of result.slice(0, 5)) {
      if (item.title) lines.push(`**${item.title}**`);
      if (item.url) lines.push(`🔗 ${item.url}`);
      if (item.snippet) {
        const clean = item.snippet.split('\n')[0].slice(0, 300);
        lines.push(clean + (item.snippet.length > 300 ? '...' : ''));
      }
      lines.push('');
    }
  } else if (result.results) {
    // 嵌套结果格式
    for (const item of result.results.slice(0, 5)) {
      if (item.title) lines.push(`**${item.title}**`);
      if (item.url) lines.push(`🔗 ${item.url}`);
      if (item.snippet) {
        const clean = item.snippet.split('\n')[0].slice(0, 300);
        lines.push(clean + (item.snippet.length > 300 ? '...' : ''));
      }
      lines.push('');
    }
  } else {
    // 未知格式，直接输出
    lines.push(JSON.stringify(result, null, 2));
  }

  return lines.join('\n');
}

// 主程序
try {
  const result = await search(queries, template);
  
  if (jsonOutput) {
    console.log(JSON.stringify(result, null, 2));
  } else {
    // API 返回对象包含 results 数组
    if (Array.isArray(result)) {
      // 多查询返回数组
      result.forEach((r, i) => {
        console.log(formatResult(r, queries.length > 1 ? queries[i] : null));
      });
    } else if (result.results) {
      // 单查询带 results
      console.log(formatResult(result.results, queries[0]));
    } else {
      // 回退处理
      const items = Object.values(result).filter(v => 
        v && typeof v === 'object' && (v.title || v.url || v.snippet)
      );
      if (items.length > 0) {
        console.log(formatResult(items, queries[0]));
      } else {
        console.log(JSON.stringify(result, null, 2));
      }
    }
  }
  
  console.log('\n✅ 搜索完成');
} catch (error) {
  console.error(`\n❌ 错误: ${error.message}`);
  process.exit(1);
}
