# 🏗️ cn-engineering-search

建设工程领域专业搜索工具 - 基于 Perplexity API 的工程咨询智能检索解决方案

## 📌 简介

`cn-engineering-search` 是专为**中国建设工程领域**打造的专业搜索 Skill，针对工程咨询、造价管控、招标采购、项目管理、商事调解等场景进行深度优化。

### 核心定位

- **专业领域**：建设工程全生命周期（决策→设计→招投标→施工→竣工）
- **目标用户**：造价工程师、招标代理师、项目经理、工程律师、调解员
- **数据来源**：Perplexity AI 实时网络搜索 + 权威工程信息源

### 解决的问题

1. **规范标准难查**：GB/T、GB、CECS 等标准分散，更新频繁
2. **造价指标不准**：各地造价指标差异大，时效性要求高
3. **政策法规滞后**：工程相关政策变化快，需要实时追踪
4. **案例参考缺乏**：商事调解、合同纠纷案例检索困难
5. **行业动态闭塞**：难以获取工程造价、招标代理行业最新趋势

---

## ✨ 功能特性

### 🔍 智能搜索能力

| 能力 | 说明 |
|------|------|
| 实时联网检索 | 基于 Perplexity API，获取最新网络信息 |
| 引用溯源 | 每条结果附带来源链接，便于核实 |
| 批量查询 | 支持多关键词一次检索，节省 API 成本 |
| JSON 输出 | 支持结构化数据输出，便于二次处理 |

### 📋 7 大专业模板

针对工程咨询核心场景预设优化模板：

| 模板 | 场景 | 优化效果 |
|------|------|---------|
| `cost-index` | 造价指标查询 | 自动关联"单方造价、价格指数、建安造价" |
| `standard` | 规范标准查询 | 自动关联"GB、GB/T、国家标准、行业标准" |
| `policy` | 政策法规查询 | 自动关联"部委文件、司法解释、管理办法" |
| `news` | 行业动态查询 | 自动关联"工程造价、招标代理、发展趋势" |
| `mediation` | 商事调解查询 | 自动关联"合同纠纷、争议解决、调解案例" |
| `tender` | 招标采购查询 | 自动关联"招标投标、评标、政府采购" |
| `contract` | 合同管理查询 | 自动关联"施工合同、示范文本、GF-2017-0201" |

---

## 🚀 快速开始

### 安装

本 Skill 已部署到本地 WorkBuddy 环境：

```
~/.workbuddy/skills/cn-engineering-search/
```

### 配置 API Key

**方式一：WorkBuddy 环境变量（推荐）**

在 WorkBuddy 设置中配置：
```
PERPLEXITY_API_KEY = your-api-key-here
```

**方式二：系统环境变量**

Windows PowerShell:
```powershell
$env:PERPLEXITY_API_KEY="your-api-key-here"
```

Windows CMD:
```cmd
set PERPLEXITY_API_KEY=your-api-key-here
```

**获取 API Key**：https://www.perplexity.ai/settings/api

### 基础使用

```bash
# 查看帮助
node scripts/search.mjs --help

# 列出所有模板
node scripts/search.mjs --list-templates

# 基础搜索（自动添加工程领域上下文）
node scripts/search.mjs "GB/T 50500-2024 工程量清单计价规范"

# 使用模板搜索（推荐）
node scripts/search.mjs --template cost-index "海南省 2024 房屋建筑"
node scripts/search.mjs --template standard "招标代理服务规范"
node scripts/search.mjs --template mediation "建设工程价款纠纷"

# JSON 输出
node scripts/search.mjs --json "工程造价咨询行业发展趋势"
```

---

## 📖 使用场景示例

### 场景一：造价指标查询

```bash
# 查询海南省房屋建筑造价指标
node scripts/search.mjs --template cost-index "海南省 2024 房屋建筑"

# 查询市政道路工程单方造价
node scripts/search.mjs --template cost-index "广东省 2025 市政道路工程"

# 查询医院建筑经济指标
node scripts/search.mjs --template cost-index "江苏省 2025 医院建筑"
```

### 场景二：规范标准查询

```bash
# 查询最新工程量清单计价规范
node scripts/search.mjs --template standard "GB/T 50500-2024 工程量清单计价"

# 查询项目管理规范
node scripts/search.mjs --template standard "GB/T 50326 项目管理规范"

# 查询招标代理服务规范
node scripts/search.mjs --template standard "招标代理服务规范"
```

### 场景三：商事调解查询

```bash
# 查询工程款纠纷调解案例
node scripts/search.mjs --template mediation "建设工程价款纠纷调解案例"

# 查询工期延误索赔实务
node scripts/search.mjs --template mediation "工期延误索赔调解实务"

# 查询工程质量争议处理
node scripts/search.mjs --template mediation "工程质量争议调解程序"
```

### 场景四：政策法规查询

```bash
# 查询建设工程价款结算规定
node scripts/search.mjs --template policy "建设工程价款结算暂行办法"

# 查询必须招标的限额标准
node scripts/search.mjs --template policy "必须招标的限额标准最新调整"

# 查询工程总承包管理办法
node scripts/search.mjs --template policy "房屋建筑和市政基础设施项目工程总承包管理办法"
```

### 场景五：行业动态追踪

```bash
# 查询 AI 在造价咨询行业的应用
node scripts/search.mjs --template news "工程造价咨询行业 AI 应用现状"

# 查询全过程工程咨询发展
node scripts/search.mjs --template news "全过程工程咨询服务内容和发展趋势"

# 查询电子招投标发展
node scripts/search.mjs --template news "电子招投标平台发展现状"
```

---

## 🛠️ 技术架构

```
cn-engineering-search/
├── SKILL.md              # OpenClaw Skill 规范文件
├── README.md             # 项目简介（本文件）
├── DEVELOPMENT.md        # 开发说明文档
├── scripts/
│   ├── search.mjs        # 核心搜索脚本（Node.js）
│   └── templates.json    # 模板配置文件
```

### 技术栈

- **运行时**：Node.js 18+
- **API**：Perplexity Search API
- **配置**：JSON 模板 + 环境变量
- **规范**：OpenClaw SKILL.md 标准

---

## 📊 与其他工具对比

| 工具 | 定位 | 工程领域优化 | 实时搜索 | 中文支持 |
|------|------|-------------|---------|---------|
| **cn-engineering-search** | 工程咨询专业搜索 | ✅ 深度优化 | ✅ | ✅ |
| Perplexity 官网 | 通用 AI 搜索 | ❌ | ✅ | ✅ |
| 传统搜索引擎 | 通用搜索 | ❌ | ✅ | ✅ |
| 造价通/广联达 | 造价数据平台 | ✅ | ❌（滞后）| ✅ |

---

## 📝 更新日志

### v1.0.0 (2026-04-10)

- ✅ 初始版本发布
- ✅ 7 大专业模板（cost-index, standard, policy, news, mediation, tender, contract）
- ✅ 支持批量查询和 JSON 输出
- ✅ 中文界面和帮助系统
- ✅ WorkBuddy 环境集成

---

## 🤝 贡献与反馈

本项目由**度量衡智库**开发和维护。

如有建议或问题，欢迎反馈。

---

## 📄 许可证

MIT License - 自由使用和修改

---

**🏗️ 让工程咨询信息检索更专业、更高效**
