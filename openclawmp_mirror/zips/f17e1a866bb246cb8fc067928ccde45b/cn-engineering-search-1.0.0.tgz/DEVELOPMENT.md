# 🛠️ cn-engineering-search 开发说明

本文档面向开发者，介绍 Skill 的架构设计、开发规范和扩展方法。

---

## 📐 架构设计

### 整体架构

```
┌─────────────────────────────────────────────────────────────┐
│                     用户输入层                               │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ 基础查询    │  │ 模板查询    │  │ 批量/JSON 查询      │  │
│  └──────┬──────┘  └──────┬──────┘  └──────────┬──────────┘  │
└─────────┼────────────────┼────────────────────┼─────────────┘
          │                │                    │
          └────────────────┴────────────────────┘
                           │
          ┌────────────────▼────────────────────┐
          │           查询处理层                 │
          │  ┌───────────────────────────────┐  │
          │  │ 参数解析 (parseArgs)          │  │
          │  │ 模板匹配 (getTemplate)        │  │
          │  │ 查询优化 (optimizeQuery)      │  │
          │  └───────────────────────────────┘  │
          └────────────────┬────────────────────┘
                           │
          ┌────────────────▼────────────────────┐
          │           API 调用层                 │
          │  ┌───────────────────────────────┐  │
          │  │ Perplexity Search API         │  │
          │  │ POST https://api.perplexity.ai│  │
          │  └───────────────────────────────┘  │
          └────────────────┬────────────────────┘
                           │
          ┌────────────────▼────────────────────┐
          │           结果处理层                 │
          │  ┌───────────────────────────────┐  │
          │  │ 格式化输出 (formatResult)     │  │
          │  │ JSON/文本 转换                │  │
          │  └───────────────────────────────┘  │
          └─────────────────────────────────────┘
```

### 文件职责

| 文件 | 职责 | 关键函数/配置 |
|------|------|--------------|
| `search.mjs` | 核心逻辑 | `parseArgs()`, `optimizeQuery()`, `search()`, `formatResult()` |
| `templates.json` | 模板配置 | 7 个预设模板的关键词和示例 |
| `SKILL.md` | OpenClaw 规范 | 环境变量、依赖、使用说明 |
| `README.md` | 用户文档 | 简介、快速开始、场景示例 |

---

## 🔧 开发环境

### 前置要求

```bash
# Node.js 版本要求
node --version  # >= 18.0.0

# 验证环境
node scripts/search.mjs --help
```

### 项目结构

```
cn-engineering-search/
├── SKILL.md              # OpenClaw 规范文件（必须）
├── README.md             # 项目简介
├── DEVELOPMENT.md        # 开发说明（本文件）
├── scripts/
│   ├── search.mjs        # 核心脚本（入口）
│   └── templates.json    # 模板配置
```

---

## 📝 核心模块详解

### 1. 参数解析模块

```javascript
// 解析命令行参数
const args = process.argv.slice(2);
const queries = [];
let jsonOutput = false;
let template = null;

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  if (arg === '--json') {
    jsonOutput = true;
  } else if (arg === '--template' && i + 1 < args.length) {
    template = args[i + 1];
    i++;
  }
  // ...
}
```

**设计要点**：
- 支持位置参数（查询内容）
- 支持可选参数（`--template`, `--json`, `--help`）
- 参数顺序无关

### 2. 模板系统

```javascript
const TEMPLATES = {
  'cost-index': {
    prefix: '建设工程造价指标 单方造价 价格指数',
    desc: '造价指标查询'
  },
  // ...
};
```

**模板工作原理**：

```
用户输入: "海南省 2024 房屋建筑"
模板: cost-index
优化后: "建设工程造价指标 单方造价 价格指数 海南省 2024 房屋建筑"
                                    ↑
                              自动添加前缀
```

**添加新模板**：

编辑 `templates.json`：

```json
{
  "templates": {
    "new-template": {
      "name": "新模板名称",
      "description": "模板描述",
      "keywords": ["关键词1", "关键词2"],
      "prefix": "自动添加的前缀",
      "examples": ["示例查询1", "示例查询2"]
    }
  }
}
```

然后在 `search.mjs` 的 `TEMPLATES` 对象中添加对应配置。

### 3. API 调用模块

```javascript
async function search(queries, template) {
  const optimizedQueries = queries.map(q => optimizeQuery(q, template));
  
  const response = await fetch("https://api.perplexity.ai/search", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query: optimizedQueries }),
  });
  
  return response.json();
}
```

**API 端点**：`https://api.perplexity.ai/search`

**请求格式**：
```json
{
  "query": ["查询1", "查询2", "查询3"]
}
```

**响应格式**：
```json
{
  "results": [
    {
      "title": "结果标题",
      "url": "来源链接",
      "snippet": "内容摘要"
    }
  ]
}
```

### 4. 结果格式化模块

```javascript
function formatResult(result, query) {
  const lines = [];
  
  if (query) {
    lines.push(`\n## 🔍 ${query}\n`);
  }
  
  // 处理数组结果
  if (Array.isArray(result)) {
    for (const item of result.slice(0, 5)) {
      if (item.title) lines.push(`**${item.title}**`);
      if (item.url) lines.push(`🔗 ${item.url}`);
      if (item.snippet) lines.push(item.snippet.slice(0, 300));
      lines.push('');
    }
  }
  // ...
  return lines.join('\n');
}
```

**输出格式**：
- 最多显示 5 条结果
- 每条包含：标题、链接、摘要
- 摘要限制 300 字符

---

## 🔄 扩展开发

### 添加新模板

**步骤 1**：编辑 `templates.json`

```json
{
  "templates": {
    "safety": {
      "name": "安全管理查询",
      "description": "查询建设工程安全管理、文明施工相关规范",
      "keywords": ["安全管理", "文明施工", "安全检查", "JGJ59"],
      "prefix": "建设工程安全管理 文明施工 JGJ59",
      "examples": [
        "建筑施工安全检查标准",
        "施工现场临时用电安全技术规范"
      ]
    }
  }
}
```

**步骤 2**：更新 `search.mjs`

```javascript
const TEMPLATES = {
  // ... 现有模板
  'safety': {
    prefix: '建设工程安全管理 文明施工 JGJ59',
    desc: '安全管理查询'
  }
};
```

**步骤 3**：更新文档

在 `README.md` 和 `SKILL.md` 中添加新模板说明。

### 修改 API 调用

如需切换到其他搜索 API（如 OpenRouter、AIsa）：

```javascript
// 修改 search 函数
async function search(queries, template) {
  const response = await fetch("https://api.openrouter.ai/search", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${process.env.OPENROUTER_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ query: optimizedQueries }),
  });
  // ...
}
```

### 添加输出格式

如需添加 CSV、Markdown 等输出格式：

```javascript
// 在参数解析中添加
let outputFormat = 'text'; // text | json | csv | markdown

if (arg === '--csv') {
  outputFormat = 'csv';
} else if (arg === '--markdown') {
  outputFormat = 'markdown';
}

// 在结果处理中添加
function formatResultCSV(result) {
  const lines = ['标题,链接,摘要'];
  for (const item of result.results || []) {
    lines.push(`"${item.title}","${item.url}","${item.snippet?.slice(0, 100)}"`);
  }
  return lines.join('\n');
}
```

---

## 🧪 测试

### 本地测试

```bash
# 设置测试环境变量
$env:PERPLEXITY_API_KEY="test-key"

# 测试帮助
node scripts/search.mjs --help

# 测试模板列表
node scripts/search.mjs --list-templates

# 测试模板搜索
node scripts/search.mjs --template cost-index "测试查询"

# 测试 JSON 输出
node scripts/search.mjs --json "测试查询"
```

### 错误处理测试

```bash
# 测试无 API Key
$env:PERPLEXITY_API_KEY=$null
node scripts/search.mjs "测试"
# 预期：显示错误提示和配置说明

# 测试无效模板
node scripts/search.mjs --template invalid "测试"
# 预期：显示可用模板列表

# 测试无查询内容
node scripts/search.mjs
# 预期：显示帮助信息
```

---

## 📦 发布

### 本地部署

Skill 已部署到 WorkBuddy 本地环境：

```
~/.workbuddy/skills/cn-engineering-search/
```

### 发布到 ClawHub（可选）

如需发布到 ClawHub 供他人使用：

```bash
# 1. 确保 SKILL.md 符合规范
# 2. 登录 ClawHub
clawhub login --token YOUR_TOKEN

# 3. 发布
clawhub publish ~/.workbuddy/skills/cn-engineering-search --slug cn-engineering-search --tags engineering,construction,consulting
```

---

## 🔐 安全配置

### API Key 管理

**推荐方式**：WorkBuddy 环境变量

```
WorkBuddy 设置 → 环境变量 → 添加 PERPLEXITY_API_KEY
```

**备选方式**：系统环境变量

```powershell
# Windows PowerShell 配置文件
Add-Content $PROFILE '$env:PERPLEXITY_API_KEY="your-key"'
```

### 安全提示

- ❌ 不要将 API Key 硬编码在代码中
- ❌ 不要将 API Key 提交到 Git 仓库
- ✅ 使用环境变量或 WorkBuddy 配置
- ✅ 定期轮换 API Key

---

## 📚 参考资源

### Perplexity API

- 文档：https://docs.perplexity.ai
- API Key：https://www.perplexity.ai/settings/api
- 定价：https://www.perplexity.ai/pricing

### OpenClaw Skill 规范

- Skill 规范：https://github.com/openclaw/skills
- SKILL.md 格式：https://docs.openclaw.ai/skills

### 工程咨询参考

- GB/T 50500-2024《建设工程工程量清单计价标准》
- GB/T 50326《建设工程项目管理规范》
- GF-2017-0201《建设工程施工合同（示范文本）》

---

## 🤝 贡献指南

### 提交 Issue

- 描述问题场景
- 提供复现步骤
- 附上错误日志

### 提交 PR

1. Fork 本仓库
2. 创建功能分支：`git checkout -b feature/xxx`
3. 提交更改：`git commit -m "Add xxx"`
4. 推送分支：`git push origin feature/xxx`
5. 创建 Pull Request

### 代码规范

- 使用 ESLint 检查代码
- 函数注释使用 JSDoc
- 提交信息使用中文或英文

---

## 📞 联系

**开发者**：度量衡智库

如有问题或建议，欢迎反馈。

---

**Happy Coding! 🚀**
