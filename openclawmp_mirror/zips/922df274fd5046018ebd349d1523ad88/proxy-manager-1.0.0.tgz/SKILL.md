---
name: proxy-manager
description: 系统代理管理器（mihomo/Clash代理）。支持启停代理、状态查询、代理测试。当需要访问Google/GitHub等被墙网站时使用此技能。触发词：代理、proxy、梯子、翻墙、开代理、关代理、代理状态、测试代理
---

# Proxy Manager 技能

基于 mihomo (Clash Meta) 的系统代理管理，端口 `127.0.0.1:7890`（Mixed HTTP + SOCKS5）。

## 快速操作

```bash
# 启动代理
sh ~/.openclaw/workspace/skills/proxy-manager/scripts/proxy.sh start

# 停止代理
sh ~/.openclaw/workspace/skills/proxy-manager/scripts/proxy.sh stop

# 查看状态
sh ~/.openclaw/workspace/skills/proxy-manager/scripts/proxy.sh status

# 测试连通性
sh ~/.openclaw/workspace/skills/proxy-manager/scripts/proxy.sh test

# 获取环境变量（用于 exec 中注入代理）
sh ~/.openclaw/workspace/skills/proxy-manager/scripts/proxy.sh env
```

所有命令输出 JSON 格式，便于解析。

## 在 exec 中使用代理

方式一（推荐）：直接在命令前设置环境变量
```bash
https_proxy=socks5h://127.0.0.1:7890 http_proxy=socks5h://127.0.0.1:7890 curl https://www.google.com
```

方式二：source 环境变量
```bash
eval $(sh ~/.openclaw/workspace/skills/proxy-manager/scripts/proxy.sh env)
curl https://www.google.com
```

## 配置文件

- 内核：`~/.openclaw/mihomo`
- 配置：`~/.openclaw/mihomo-config/config.yaml`
- 日志：`/tmp/mihomo.log`

## 更新订阅

需要更新节点时，提供新的订阅地址，执行：
```bash
# 下载 → 解码 → 生成配置 → 重启
sh ~/.openclaw/workspace/skills/proxy-manager/scripts/proxy.sh restart
```

## 注意事项

- 代理仅绑定 127.0.0.1，不对外暴露
- 重启后代理不会自动启动，需手动执行 `start`
- 日常不需要一直开着代理，用完记得 `stop` 省资源
