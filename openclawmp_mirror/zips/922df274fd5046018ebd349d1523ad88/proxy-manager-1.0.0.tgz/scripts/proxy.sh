#!/bin/sh
# Proxy Manager - mihomo proxy control script
# Usage: proxy.sh <start|stop|status|restart|test>

MIHOMO_BIN="/mnt/sata1-4/OpenClaw/Configs/OpenClawMgr/data/.openclaw/mihomo"
CONFIG_DIR="/mnt/sata1-4/OpenClaw/Configs/OpenClawMgr/data/.openclaw/mihomo-config"
PID_FILE="/tmp/mihomo.pid"
LOG_FILE="/tmp/mihomo.log"
PROXY_ADDR="socks5h://127.0.0.1:7890"

get_pid() {
    pgrep -f "$MIHOMO_BIN" 2>/dev/null | head -1
}

case "$1" in
    start)
        PID=$(get_pid)
        if [ -n "$PID" ]; then
            echo '{"status":"already_running","pid":'$PID',"proxy":"'$PROXY_ADDR'"}'
            exit 0
        fi
        $MIHOMO_BIN -d $CONFIG_DIR -f $CONFIG_DIR/config.yaml > $LOG_FILE 2>&1 &
        PID=$!
        echo $PID > $PID_FILE
        sleep 2
        if kill -0 $PID 2>/dev/null; then
            echo '{"status":"started","pid":'$PID',"proxy":"'$PROXY_ADDR'"}'
        else
            echo '{"status":"failed","error":"process died, check '$LOG_FILE'"}'
            exit 1
        fi
        ;;
    stop)
        PID=$(get_pid)
        if [ -z "$PID" ]; then
            echo '{"status":"not_running"}'
            exit 0
        fi
        kill $PID 2>/dev/null
        rm -f $PID_FILE
        echo '{"status":"stopped","pid":'$PID'}'
        ;;
    status)
        PID=$(get_pid)
        if [ -n "$PID" ]; then
            echo '{"status":"running","pid":'$PID',"proxy":"'$PROXY_ADDR'"}'
        else
            echo '{"status":"stopped"}'
        fi
        ;;
    restart)
        $0 stop
        sleep 1
        $0 start
        ;;
    test)
        PID=$(get_pid)
        if [ -z "$PID" ]; then
            echo '{"status":"proxy_not_running"}'
            exit 1
        fi
        RESULT=$(curl -s --socks5-hostname 127.0.0.1:7890 --connect-timeout 10 -o /dev/null -w "%{http_code}" https://www.google.com 2>&1)
        if [ "$RESULT" = "200" ] || [ "$RESULT" = "301" ] || [ "$RESULT" = "302" ]; then
            echo '{"status":"ok","http_code":'$RESULT'}'
        else
            echo '{"status":"failed","http_code":'$RESULT'}'
        fi
        ;;
    env)
        # Output env vars for proxy
        PID=$(get_pid)
        if [ -z "$PID" ]; then
            echo "# Proxy not running. Start with: proxy.sh start"
            exit 1
        fi
        echo "export http_proxy=socks5h://127.0.0.1:7890"
        echo "export https_proxy=socks5h://127.0.0.1:7890"
        ;;
    *)
        echo '{"error":"usage: proxy.sh <start|stop|status|restart|test|env>"}'
        exit 1
        ;;
esac
