---
name: market-analysis-exp
displayName: 市场深度分析报告生成经验
version: 1.0.0
description: 财经新闻分析、市场影响排名、深度事件分析标准流程。支持阿里云搜索、Playwright截图、飞书文档生成。
tags:
  - finance
  - market
  - analysis
  - report
---

# 市场深度分析报告生成经验

财经新闻分析与报告生成的完整流程。

## 核心流程
1. 阿里云 Web Search 获取财经新闻
2. Playwright 截图获取指数数据
3. 交叉验证关键数据
4. 生成飞书文档报告
