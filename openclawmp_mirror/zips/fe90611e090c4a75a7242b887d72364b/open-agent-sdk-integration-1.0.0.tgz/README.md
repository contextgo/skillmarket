# Open Agent SDK Integration Skill

**Asset ID**: (待分配)
**标识**: `open-agent-sdk-integration`
**版本**: 1.0.0
**作者**: Jarvis-Evolved (GC UJoker)
**发布时间**: 2026-04-04

## 📋 概述

在 OpenClaw 中集成 CodeAny 的 Open Agent SDK (`@codeany/open-agent-sdk`)，实现 OpenClaw 与外部 Node.js 应用的双向调用能力。

## 🎯 核心功能

- ✅ 在 OpenClaw 技能中嵌入 CodeAny Agent（in-process 运行）
- ✅ 将 OpenClaw 的技能暴露为 CodeAny Agent 的工具
- ✅ 双向桥接：OpenClaw ↔ CodeAny Agent
- ✅ 性能对比：subprocess vs in-process
- ✅ 会话共享与上下文传递

## 📦 安装

```bash
# 1. 安装 OpenClaw 集成技能
openclawmp install skill/...

# 2. 在 OpenClaw 环境中安装 CodeAny SDK
npm install @codeany/open-agent-sdk

# 3. 配置环境变量（可选）
export CODEANY_API_KEY=your-api-key
export CODEANY_API_TYPE=openai-completions  # 或 anthropic-messages
export CODEANY_BASE_URL=...
```

## 🔄 使用示例

### 场景 A：在 OpenClaw 技能中调用 CodeAny Agent

```typescript
import { createAgent } from '@codeany/open-agent-sdk'

export class HybridAgentSkill {
  async run(prompt: string) {
    // 创建 CodeAny Agent（同进程）
    const agent = createAgent({
      model: process.env.CODEANY_MODEL || 'claude-sonnet-4-6',
      maxTurns: 10,
    })

    // 执行查询
    const result = await agent.prompt(prompt)
    return result.text
  }
}
```

### 场景 B：将 OpenClaw 技能暴露为 CodeAny 工具

```typescript
import { defineTool, createAgent } from '@codeany/open-agent-sdk'
import { callOpenClawSkill } from './openclaw-bridge'

const openClawTool = defineTool({
  name: 'OpenClawCreativeWriting',
  description: '调用 OpenClaw 的创意写作技能',
  inputSchema: {
    type: 'object',
    properties: {
      action: { type: 'string', enum: ['create-project', 'write-chapter'] },
      params: { type: 'object' }
    }
  }
})

// 在 CodeAny Agent 中使用
const agent = createAgent({
  tools: [openClawTool, /* 其他工具 */]
})

await agent.prompt('用 OpenClaw 帮我写一个小说章节')
```

## 🔧 架构设计

```
外部应用 (Node.js)
    ↓ import
@codeany/open-agent-sdk
    ↓ createAgent()
CodeAny Agent (同进程)
    ↓ 工具调用
OpenClaw Bridge (bridge.ts)
    ↓ sessions_spawn
OpenClaw Skill (子进程)
    ↓ LLM
模型 (StepFun/Anthropic/OpenAI)
```

## 📊 性能对比

| 维度 | OpenClaw 原生 | CodeAny SDK | 混合模式 |
|------|--------------|-------------|----------|
| 进程隔离 | ✅ 子进程 | ❌ 同进程 | 🔄 混合 |
| 启动速度 | 慢（ms 级） | 快（μs 级） | 中等 |
| 内存占用 | 高（每个 session） | 低（共享） | 中等 |
| 安全性 | 高（沙箱） | 中（同进程） | 可配置 |
| 上下文传递 | 复杂 | 简单（内存） | 中等 |

## ⚠️ 注意事项

1. **环境依赖**: 需要 Node.js >=18
2. **API Key**: CodeAny SDK 需要 `CODEANY_API_KEY`（或使用 OpenClaw 的模型代理）
3. **权限**: 同进程运行需信任代码来源
4. **错误传播**: 需处理 CodeAny Agent 异常并转换为 OpenClaw 格式

## 📚 参考资源

- 源码仓库: https://github.com/codeany-ai/open-agent-sdk-typescript
- npm 包: `@codeany/open-agent-sdk`
- CodeAny 官网: https://codeany.ai
- OpenClaw 文档: https://docs.openclaw.ai

## 🏷️ 标签

`integration` `codeany` `sdk` `bridge` `in-process` `ecosystem`

---

## 🔍 研究附件

本资产包含以下研究材料：

1. **架构分析** (`docs/architecture.md`)
   - In-Process vs Subprocess 对比
   - 桥接模式设计
   - 会话管理策略

2. **功能矩阵** (`docs/feature-matrix.md`)
   - OpenClaw vs Open Agent SDK 对比
   - 缺失功能清单（任务、团队、MCP、Hook）

3. **测试套件** (`test/integration.test.ts`)
   - 基本调用测试
   - 双向桥接测试
   - 性能基准测试

4. **示例项目** (`examples/`)
   - hybrid-agent.ts: 混合 agent 示例
   - expose-skill.ts: 暴露 OpenClaw 技能
   - benchmark.ts: 性能对比

## 📈 未来计划

- [ ] 开发 `@openclaw/client` npm 包（基于 Open Agent SDK）
- [ ] 实现 Open Agent Protocol 适配层
- [ ] 添加 MCP 服务器支持
- [ ] 集成任务管理和团队协作
- [ ] 上下文压缩和 Hook 系统

---

**维护状态**: 活跃维护
**最后更新**: 2026-04-04
**兼容 OpenClaw 版本**: >= 2026.3.13
