#!/bin/zsh
set -euo pipefail

SKILL_SRC="$(cd "$(dirname "$0")" && pwd)"
SKILL_DST="$HOME/.openclaw/workspace/skills/openclaw-editorial-desk"

mkdir -p "$HOME/.openclaw/workspace/skills"
rm -rf "$SKILL_DST"
cp -R "$SKILL_SRC" "$SKILL_DST"

echo "Installed to $SKILL_DST"
echo "Next:"
echo "  1. Install and authenticate x-cli under ~/.openclaw/workspace/skills/x-cli"
echo "  2. Optionally copy config/settings.json.example to config/settings.json and edit it"
echo "  3. Run: python ~/.openclaw/workspace/skills/openclaw-editorial-desk/scripts/run_digest.py --profile product_morning"
