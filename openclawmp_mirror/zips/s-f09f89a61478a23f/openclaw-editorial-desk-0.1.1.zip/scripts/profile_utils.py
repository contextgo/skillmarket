#!/usr/bin/env python3

import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
CONFIG_DIR = PACKAGE_ROOT / "config"
PROFILE_REGISTRY_PATH = CONFIG_DIR / "digest_profiles.json"

DEFAULT_SETTINGS = {
    "output_root": "~/Desktop/myopenclaw",
    "timezone": "Asia/Shanghai",
    "x_cli_dir": "~/.openclaw/workspace/skills/x-cli",
    "email_enabled": False,
    "default_recipient": "",
}


def _read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def _expand_path(value: str) -> Path:
    return Path(os.path.expanduser(value)).resolve()


def load_settings() -> dict:
    settings = dict(DEFAULT_SETTINGS)
    settings_path = CONFIG_DIR / "settings.json"
    if settings_path.exists():
        settings.update(_read_json(settings_path))

    env_map = {
        "EDITORIAL_DESK_OUTPUT_ROOT": "output_root",
        "EDITORIAL_DESK_TIMEZONE": "timezone",
        "EDITORIAL_DESK_X_CLI_DIR": "x_cli_dir",
        "EDITORIAL_DESK_DEFAULT_RECIPIENT": "default_recipient",
    }
    for env_key, setting_key in env_map.items():
        if os.environ.get(env_key):
            settings[setting_key] = os.environ[env_key]

    if os.environ.get("EDITORIAL_DESK_EMAIL_ENABLED"):
        settings["email_enabled"] = os.environ["EDITORIAL_DESK_EMAIL_ENABLED"].lower() in {"1", "true", "yes"}

    return settings


SETTINGS = load_settings()
TZ = ZoneInfo(SETTINGS["timezone"])
UTC = ZoneInfo("UTC")
OUTPUT_ROOT = _expand_path(SETTINGS["output_root"])
OUTPUT_DIGEST_DIR = OUTPUT_ROOT / "digests"
OUTPUT_LOG_DIR = OUTPUT_ROOT / "logs"


def load_profile_registry() -> dict:
    return _read_json(PROFILE_REGISTRY_PATH)


def resolve_profile_name(profile_name: Optional[str] = None) -> str:
    registry = load_profile_registry()
    if profile_name:
        return profile_name
    env_profile = os.environ.get("AI_DIGEST_PROFILE")
    if env_profile:
        return env_profile
    return registry["default_profile"]


def load_profile(profile_name: Optional[str] = None) -> tuple[str, dict, dict]:
    registry = load_profile_registry()
    resolved = resolve_profile_name(profile_name)
    profiles = registry["profiles"]
    if resolved not in profiles:
        available = ", ".join(sorted(profiles))
        raise ValueError(f"Unknown profile: {resolved}. Available: {available}")
    meta = profiles[resolved]
    config_path = PACKAGE_ROOT / meta["config_relpath"]
    config = _read_json(config_path)
    return resolved, meta, config


def build_output_paths(profile_name: str, meta: dict, date_str: Optional[str] = None) -> dict:
    current_date = date_str or datetime.now(TZ).strftime("%Y-%m-%d")
    prefix = meta["output_prefix"]
    return {
        "ranked": OUTPUT_DIGEST_DIR / f"{prefix}-ranked-{current_date}.json",
        "report_md": OUTPUT_DIGEST_DIR / f"{prefix}-{current_date}.md",
        "report_html": OUTPUT_DIGEST_DIR / f"{prefix}-{current_date}.html",
    }


def add_profile_arg(parser) -> None:
    parser.add_argument(
        "--profile",
        default=None,
        help="Digest profile slug. Defaults to AI_DIGEST_PROFILE or registry default.",
    )


def ensure_output_dirs() -> None:
    OUTPUT_DIGEST_DIR.mkdir(parents=True, exist_ok=True)
    OUTPUT_LOG_DIR.mkdir(parents=True, exist_ok=True)


def get_x_cli_dir() -> Path:
    return _expand_path(SETTINGS["x_cli_dir"])
