#!/usr/bin/env python3

import concurrent.futures
import hashlib
import html
import re
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta
from email.utils import parsedate_to_datetime
from typing import List, Optional

from profile_utils import UTC

USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Safari/537.36"
HTML_TAG_RE = re.compile(r"<[^>]+>")
WHITESPACE_RE = re.compile(r"\s+")


def clean_text(text: str) -> str:
    value = html.unescape(HTML_TAG_RE.sub(" ", text or ""))
    return WHITESPACE_RE.sub(" ", value).strip()


def parse_datetime(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    try:
        dt = parsedate_to_datetime(value)
        if dt.tzinfo is None:
            return dt.replace(tzinfo=UTC)
        return dt.astimezone(UTC)
    except Exception:
        return None


def fetch_url_text(url: str, timeout: int = 20) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=timeout) as response:
        return response.read().decode("utf-8", errors="replace")


def google_news_rss_url(query: str, locale: str = "en-US", region: str = "US", edition: str = "US:en") -> str:
    encoded_query = urllib.parse.quote_plus(query)
    return (
        "https://news.google.com/rss/search"
        f"?q={encoded_query}&hl={locale}&gl={region}&ceid={edition}"
    )


def make_external_item(source: dict, title: str, link: str, summary: str, published: Optional[datetime], publisher: Optional[str]) -> dict:
    safe_link = link or ""
    item_id = hashlib.md5(f"{source['source_key']}::{safe_link}::{title}".encode("utf-8")).hexdigest()[:16]
    final_published = published or datetime.now(UTC)
    publisher_name = publisher or source["source_name"]
    body = clean_text(" ".join(part for part in [title, summary, publisher_name] if part))
    return {
        "id": f"{source['source_key']}:{item_id}",
        "kind": source["driver"],
        "source_key": source["source_key"],
        "source_name": source["source_name"],
        "publisher": publisher_name,
        "user": publisher_name,
        "name": publisher_name,
        "title": clean_text(title),
        "text": body,
        "summary": clean_text(summary),
        "created_at": final_published.isoformat(),
        "favorite_count": 0,
        "retweet_count": 0,
        "url": safe_link,
    }


def parse_rss_items(xml_text: str, source: dict, cutoff: datetime) -> List[dict]:
    root = ET.fromstring(xml_text)
    items = []
    channel_items = root.findall(".//item")
    if channel_items:
        for item in channel_items[: source.get("max_items", 8)]:
            title = item.findtext("title") or ""
            link = item.findtext("link") or ""
            summary = (
                item.findtext("description")
                or item.findtext("{http://purl.org/rss/1.0/modules/content/}encoded")
                or ""
            )
            published = parse_datetime(item.findtext("pubDate"))
            source_node = item.find("source")
            publisher = source_node.text.strip() if source_node is not None and source_node.text else None
            if published and published < cutoff:
                continue
            items.append(make_external_item(source, title, link, summary, published, publisher))
        return items

    atom_entries = root.findall(".//{http://www.w3.org/2005/Atom}entry")
    for entry in atom_entries[: source.get("max_items", 8)]:
        title = entry.findtext("{http://www.w3.org/2005/Atom}title") or ""
        summary = entry.findtext("{http://www.w3.org/2005/Atom}summary") or ""
        published_text = entry.findtext("{http://www.w3.org/2005/Atom}updated") or entry.findtext("{http://www.w3.org/2005/Atom}published")
        published = None
        if published_text:
            try:
                published = datetime.fromisoformat(published_text.replace("Z", "+00:00")).astimezone(UTC)
            except Exception:
                published = None
        if published and published < cutoff:
            continue
        link = ""
        for link_node in entry.findall("{http://www.w3.org/2005/Atom}link"):
            href = link_node.attrib.get("href")
            if href:
                link = href
                break
        items.append(make_external_item(source, title, link, summary, published, None))
    return items


def fetch_external_source(source: dict, cutoff: datetime) -> List[dict]:
    if source["driver"] == "rss":
        url = source["url"]
    elif source["driver"] == "google_news_rss":
        url = google_news_rss_url(
            source["query"],
            locale=source.get("locale", "en-US"),
            region=source.get("region", "US"),
            edition=source.get("edition", "US:en"),
        )
    else:
        return []

    try:
        xml_text = fetch_url_text(url)
        return parse_rss_items(xml_text, source, cutoff)
    except Exception:
        return []


def fetch_external_items(config: dict, hours_back: int = 72) -> List[dict]:
    sources = list(config.get("external_sources", [])) + list(config.get("search_queries", []))
    if not sources:
        return []

    cutoff = datetime.now(UTC) - timedelta(hours=hours_back)
    results: List[dict] = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(8, len(sources))) as executor:
        futures = [executor.submit(fetch_external_source, source, cutoff) for source in sources]
        for future in concurrent.futures.as_completed(futures):
            results.extend(future.result())
    return results
