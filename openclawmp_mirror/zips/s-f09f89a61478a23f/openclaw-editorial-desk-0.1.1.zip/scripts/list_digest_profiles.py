#!/usr/bin/env python3

from profile_utils import load_profile_registry


def main() -> int:
    registry = load_profile_registry()
    default_profile = registry["default_profile"]
    for slug, meta in registry["profiles"].items():
        marker = " (default)" if slug == default_profile else ""
        print(f"{slug}{marker}")
        print(f"  标题: {meta['title']}")
        print(f"  说明: {meta['description']}")
        print(f"  输出前缀: {meta['output_prefix']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
