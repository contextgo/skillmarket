#!/usr/bin/env python3
"""
Package and optionally publish this skill to openclawmp.cc.
Usage:
  python scripts/publish_to_marketplace.py --dry-run
  python scripts/publish_to_marketplace.py --publish
"""

import argparse
import json
import os
from pathlib import Path
import subprocess
import zipfile
from datetime import datetime

PACKAGE_ROOT = Path(__file__).resolve().parents[1]
DIST_DIR = PACKAGE_ROOT / "dist"


def parse_frontmatter() -> dict:
    skill_md = PACKAGE_ROOT / "SKILL.md"
    content = skill_md.read_text(encoding="utf-8")
    if not content.startswith("---"):
        raise SystemExit("SKILL.md missing frontmatter.")
    _, fm_str, _ = content.split("---", 2)
    data = {}
    for line in fm_str.strip().splitlines():
        if ":" not in line:
            continue
        key, value = line.split(":", 1)
        data[key.strip()] = value.strip().strip("\"'")
    return data


def create_package() -> Path:
    DIST_DIR.mkdir(parents=True, exist_ok=True)
    metadata = parse_frontmatter()
    version = metadata.get("version", "0.1.0")
    output_path = DIST_DIR / f"{metadata['name']}-{version}.zip"

    excludes = {
        ".DS_Store",
        "config/publish.json",
        "config/email.json",
    }
    skip_dirs = {".git", "__pycache__", "dist", ".venv", "output"}

    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(PACKAGE_ROOT):
            dirs[:] = [d for d in dirs if d not in skip_dirs]
            for file_name in files:
                full_path = Path(root) / file_name
                rel_path = full_path.relative_to(PACKAGE_ROOT)
                rel_str = rel_path.as_posix()
                if rel_str in excludes or file_name.endswith(".zip"):
                    continue
                zf.write(full_path, rel_str)
    return output_path


def load_publish_config() -> dict:
    config = {
        "api_base": os.environ.get("OPENCLAWMP_API_BASE", "https://openclawmp.cc/api/v1"),
        "token": os.environ.get("OPENCLAWMP_TOKEN", ""),
        "device_id": os.environ.get("OPENCLAWMP_DEVICE_ID", ""),
    }
    config_path = PACKAGE_ROOT / "config" / "publish.json"
    if config_path.exists():
        data = json.loads(config_path.read_text(encoding="utf-8")).get("openclawmp", {})
        config = {
            "api_base": data.get("api_base", config["api_base"]),
            "token": data.get("token", config["token"]),
            "device_id": data.get("device_id", config["device_id"]),
        }
    return config


def build_metadata(frontmatter: dict) -> dict:
    tags = frontmatter.get("tags", "")
    if isinstance(tags, str):
        tags = [tag.strip() for tag in tags.split(",") if tag.strip()]
    return {
        "name": frontmatter["name"],
        "type": "skill",
        "version": frontmatter.get("version", "0.1.0"),
        "description": frontmatter.get("description", ""),
        "displayName": frontmatter.get("displayName", frontmatter["name"]),
        "tags": tags,
    }


def publish(package_path: Path, metadata: dict) -> int:
    config = load_publish_config()
    if not config["token"] or not config["device_id"]:
        raise SystemExit("Missing OPENCLAWMP_TOKEN / OPENCLAWMP_DEVICE_ID or config/publish.json.")

    command = [
        "curl",
        "-sS",
        "-X",
        "POST",
        f"{config['api_base']}/assets/publish",
        "-H",
        f"Authorization: Bearer {config['token']}",
        "-H",
        f"X-Device-ID: {config['device_id']}",
        "-F",
        f"package=@{package_path}",
        "-F",
        f"metadata={json.dumps(metadata, ensure_ascii=False)}",
    ]
    result = subprocess.run(command, capture_output=True, text=True)
    print(result.stdout.strip())
    if result.returncode != 0:
        print(result.stderr.strip())
    return result.returncode


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--publish", action="store_true", help="Publish after packaging.")
    parser.add_argument("--dry-run", action="store_true", help="Only print metadata and package path.")
    args = parser.parse_args()

    frontmatter = parse_frontmatter()
    metadata = build_metadata(frontmatter)
    package_path = create_package()

    print(json.dumps({"package": str(package_path), "metadata": metadata}, ensure_ascii=False, indent=2))
    if args.publish:
        return publish(package_path, metadata)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
