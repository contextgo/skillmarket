#!/usr/bin/env python3
"""
Run the full editorial pipeline for one profile.
Usage: python scripts/run_digest.py --profile product_morning [--recipient you@example.com] [--no-email]
"""

import argparse
import subprocess
import sys
from pathlib import Path

from profile_utils import CONFIG_DIR, SETTINGS, add_profile_arg, ensure_output_dirs, get_x_cli_dir, load_profile

SCRIPT_DIR = Path(__file__).resolve().parent


def run_step(command: list[str]) -> None:
    subprocess.run(command, cwd=SCRIPT_DIR.parent, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    add_profile_arg(parser)
    parser.add_argument("--recipient", default=None, help="Override recipient for email delivery.")
    parser.add_argument("--no-email", action="store_true", help="Render HTML only.")
    args = parser.parse_args()

    ensure_output_dirs()
    profile_name, _profile_meta, _profile_config = load_profile(args.profile)
    x_python = get_x_cli_dir() / ".venv" / "bin" / "python"
    if not x_python.exists():
        raise SystemExit(
            "x-cli virtualenv Python not found. Install x-cli under ~/.openclaw/workspace/skills/x-cli and create its .venv first."
        )

    run_step([str(x_python), str(SCRIPT_DIR / "score_ai_timeline.py"), "--profile", profile_name])
    run_step([sys.executable, str(SCRIPT_DIR / "build_ai_editor_report_v2.py"), "--profile", profile_name])

    email_config_exists = (CONFIG_DIR / "email.json").exists()
    should_send_email = not args.no_email and (bool(SETTINGS.get("email_enabled")) or email_config_exists)
    render_cmd = [sys.executable, str(SCRIPT_DIR / "render_ai_newspaper_email.py"), "--profile", profile_name]
    if args.recipient:
        render_cmd.append(args.recipient)
    if not should_send_email:
        render_cmd.append("--no-email")
    run_step(render_cmd)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
