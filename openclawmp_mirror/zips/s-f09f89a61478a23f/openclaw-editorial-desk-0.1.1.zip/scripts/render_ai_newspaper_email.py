#!/usr/bin/env python3
"""
Render the editorial report as an HTML newspaper and optionally send email.
Usage: python render_ai_newspaper_email.py [recipient_email] [--profile product_morning] [--no-email]
"""

import argparse
import json
import os
import smtplib
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html import escape
import re

from profile_utils import CONFIG_DIR, SETTINGS, OUTPUT_DIGEST_DIR, TZ, add_profile_arg, build_output_paths, ensure_output_dirs, load_profile

DATE_STR = datetime.now(TZ).strftime("%Y-%m-%d")
URL_RE = re.compile(r"(https?://[^\s<]+)")


def load_email_config() -> dict:
    config = {
        "enabled": bool(SETTINGS.get("email_enabled")),
        "default_recipient": SETTINGS.get("default_recipient", ""),
        "smtp": {
            "host": "",
            "port": 465,
            "username": "",
            "password": "",
            "use_ssl": True,
        },
    }
    config_path = CONFIG_DIR / "email.json"
    if config_path.exists():
        file_config = json.loads(config_path.read_text(encoding="utf-8"))
        config.update({k: v for k, v in file_config.items() if k != "smtp"})
        config["smtp"].update(file_config.get("smtp", {}))

    env_map = {
        "EDITORIAL_DESK_SMTP_HOST": ("smtp", "host"),
        "EDITORIAL_DESK_SMTP_PORT": ("smtp", "port"),
        "EDITORIAL_DESK_SMTP_USER": ("smtp", "username"),
        "EDITORIAL_DESK_SMTP_PASS": ("smtp", "password"),
        "EDITORIAL_DESK_DEFAULT_RECIPIENT": ("default_recipient",),
        "EDITORIAL_DESK_EMAIL_ENABLED": ("enabled",),
    }
    for env_key, path in env_map.items():
        value = None
        if env_key in {"EDITORIAL_DESK_SMTP_PASS"}:
            value = os.environ.get(env_key)
        else:
            value = os.environ.get(env_key)
        if value is None or value == "":
            continue
        if len(path) == 1:
            target_key = path[0]
            if target_key == "enabled":
                config[target_key] = value.lower() in {"1", "true", "yes"}
            else:
                config[target_key] = value
        else:
            top_key, child_key = path
            config[top_key][child_key] = int(value) if child_key == "port" else value
    return config


def md_to_sections(text: str) -> dict:
    lines = text.splitlines()
    sections = {
        "title": "AI 日报",
        "subtitle": "",
        "editors_note": [],
        "core": [],
        "picks": [],
        "briefs": [],
        "trend": [],
        "notes": [],
        "stats": [],
    }

    current = None
    current_item = None
    current_brief = None
    for line in lines:
        if line.startswith("# "):
            sections["title"] = line[2:].strip()
        elif line.startswith("## 📊"):
            current = "editors_note"
            current_item = None
            current_brief = None
        elif line.startswith("## 🎯"):
            current = "core"
            current_item = None
            current_brief = None
        elif line.startswith("## 🔥"):
            current = "picks"
            current_item = None
            current_brief = None
        elif line.startswith("## 🗞"):
            current = "briefs"
            current_item = None
            current_brief = None
        elif line.startswith("## 📈"):
            current = "trend"
            current_item = None
            current_brief = None
        elif line.startswith("## 💡"):
            current = "notes"
            current_item = None
            current_brief = None
        elif line.startswith("## 📋"):
            current = "stats"
            current_item = None
            current_brief = None
        elif line.startswith("### ") and current in {"core", "picks"}:
            current_item = {"title": line[4:].strip(), "bullets": []}
            sections[current].append(current_item)
        elif line.startswith("- "):
            stripped = line[2:].strip()
            if current in {"core", "picks"} and current_item is not None:
                current_item["bullets"].append(stripped)
            elif current == "briefs":
                if stripped.startswith("**短讯 "):
                    current_brief = {"title": stripped, "bullets": []}
                    sections["briefs"].append(current_brief)
                elif current_brief is not None:
                    current_brief["bullets"].append(stripped)
            elif current:
                sections[current].append(stripped)
        else:
            stripped = line.strip()
            if current == "notes" and stripped and stripped[0].isdigit() and ". " in stripped:
                sections[current].append(stripped)
    return sections


def format_inline_md(text: str) -> str:
    text = escape(text)
    while "**" in text:
        start = text.find("**")
        end = text.find("**", start + 2)
        if end == -1:
            break
        inner = text[start + 2:end]
        text = text[:start] + f"<strong>{inner}</strong>" + text[end + 2:]
    text = URL_RE.sub(lambda m: f'<a href="{m.group(1)}">{m.group(1)}</a>', text)
    return text


def render_list(items: list[str]) -> str:
    return "".join(f"<li>{format_inline_md(item)}</li>" for item in items)


def render_story_cards(items: list[dict]) -> str:
    html = []
    for item in items:
        bullets = "".join(f"<li>{format_inline_md(b)}</li>" for b in item["bullets"])
        html.append(
            f"""
        <article class=\"story-card\">
          <h3>{format_inline_md(item['title'])}</h3>
          <ul>{bullets}</ul>
        </article>
        """
        )
    return "".join(html)


def build_html(sections: dict, profile_meta: dict) -> str:
    today = datetime.now(TZ).strftime("%Y-%m-%d %H:%M")
    return f"""<!doctype html>
<html lang=\"zh-CN\">
<head>
  <meta charset=\"utf-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">
  <title>{sections['title']}</title>
  <style>
    :root {{
      --bg: #f4efe6;
      --paper: #fffaf0;
      --ink: #1f1a17;
      --muted: #6f6258;
      --rule: #d8cbb9;
      --accent: #1f5c4a;
      --accent-soft: #ddebe5;
    }}
    * {{ box-sizing: border-box; }}
    body {{ margin: 0; background: radial-gradient(circle at top, #efe4d4, #eadfce 40%, #e7dbc8 100%); color: var(--ink); font-family: Georgia, 'Times New Roman', serif; }}
    a {{ color: var(--accent); text-decoration: none; border-bottom: 1px solid rgba(31,92,74,0.25); }}
    .page {{ max-width: 920px; margin: 0 auto; padding: 20px 12px 32px; }}
    .masthead {{ border-top: 4px double var(--ink); border-bottom: 2px solid var(--ink); padding: 14px 0 12px; text-align: center; }}
    .kicker {{ font-size: 11px; letter-spacing: 0.14em; text-transform: uppercase; color: var(--muted); }}
    .title {{ margin: 8px 0 4px; font-size: clamp(26px, 5.6vw, 44px); line-height: 1.02; letter-spacing: 0.02em; text-transform: uppercase; }}
    .subline {{ font-size: 12px; color: var(--muted); display: flex; justify-content: space-between; gap: 8px; flex-wrap: wrap; border-top: 1px solid var(--rule); margin-top: 10px; padding-top: 8px; }}
    .hero {{ display: grid; grid-template-columns: 1fr; gap: 14px; margin-top: 16px; }}
    .sidebar, .section {{ background: rgba(255,250,240,0.9); border: 1px solid var(--rule); box-shadow: 0 8px 30px rgba(64,42,22,0.05); }}
    .sidebar {{ padding: 14px; }}
    .sidebar h3, .section h3.section-title {{ margin: 0 0 10px; font-size: 13px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--accent); }}
    .sidebar ul, .section ul {{ margin: 0; padding-left: 18px; line-height: 1.6; font-size: 14px; }}
    .main-grid {{ display: grid; grid-template-columns: 1fr; gap: 14px; margin-top: 14px; }}
    .section {{ padding: 14px; }}
    .story-card {{ padding: 12px 0; border-top: 1px solid var(--rule); }}
    .story-card:first-of-type {{ border-top: 0; padding-top: 0; }}
    .story-card h3 {{ margin: 0 0 8px; font-size: 18px; line-height: 1.3; }}
    .story-card ul {{ margin: 0; padding-left: 18px; }}
    .footer {{ margin-top: 16px; padding-top: 10px; border-top: 1px solid var(--rule); color: var(--muted); font-size: 12px; text-align: center; }}
    @media (min-width: 860px) {{
      .main-grid {{ grid-template-columns: minmax(0, 1.55fr) minmax(260px, 0.75fr); align-items: start; }}
    }}
  </style>
</head>
<body>
  <div class=\"page\">
    <header class=\"masthead\">
      <div class=\"kicker\">{profile_meta['kicker']}</div>
      <h1 class=\"title\">{sections['title']}</h1>
      <div class=\"subline\">
        <span>{profile_meta['subtitle']}</span>
        <span>出刊时间：{today}</span>
      </div>
    </header>
    <section class=\"hero\">
      <aside class=\"sidebar\">
        <h3>Morning Edition</h3>
        <ul>{render_list(sections['editors_note'])}</ul>
      </aside>
    </section>
    <section class=\"main-grid\">
      <div>
        <section class=\"section\">
          <h3 class=\"section-title\">头版三条</h3>
          {render_story_cards(sections['core'])}
        </section>
        <section class=\"section\" style=\"margin-top:14px;\">
          <h3 class=\"section-title\">版面续稿</h3>
          {render_story_cards(sections['picks'])}
        </section>
      </div>
      <div>
        <section class=\"section\">
          <h3 class=\"section-title\">侧栏短讯</h3>
          {render_story_cards(sections['briefs'])}
        </section>
        <section class=\"section\" style=\"margin-top:14px;\">
          <h3 class=\"section-title\">趋势雷达</h3>
          <ul>{render_list(sections['trend'])}</ul>
        </section>
        <section class=\"section\" style=\"margin-top:14px;\">
          <h3 class=\"section-title\">编后记</h3>
          <ul>{render_list(sections['notes'])}</ul>
        </section>
      </div>
    </section>
    <section class=\"section\" style=\"margin-top:14px;\">
      <h3 class=\"section-title\">版面附注</h3>
      <ul>{render_list(sections['stats'])}</ul>
    </section>
    <div class=\"footer\">这版是报纸布局 HTML，适合邮箱、Notion 或静态归档，不适合挤在聊天框里看。</div>
  </div>
</body>
</html>
"""


def send_email(html: str, recipient: str, profile_meta: dict, email_config: dict) -> None:
    smtp = email_config["smtp"]
    msg = MIMEMultipart("alternative")
    msg["From"] = smtp["username"]
    msg["To"] = recipient
    msg["Subject"] = f"[{profile_meta['title']}] 报纸版 {DATE_STR}"
    msg.attach(MIMEText(f"请用支持 HTML 的邮箱客户端查看这份 {profile_meta['title']}。", "plain", "utf-8"))
    msg.attach(MIMEText(html, "html", "utf-8"))

    if smtp.get("use_ssl", True):
        with smtplib.SMTP_SSL(smtp["host"], int(smtp["port"])) as server:
            server.login(smtp["username"], smtp["password"])
            server.send_message(msg)
    else:
        with smtplib.SMTP(smtp["host"], int(smtp["port"])) as server:
            server.starttls()
            server.login(smtp["username"], smtp["password"])
            server.send_message(msg)


def validate_email_config(email_config: dict) -> None:
    smtp = email_config["smtp"]
    required = ["host", "port", "username", "password"]
    missing = [key for key in required if not smtp.get(key)]
    if missing:
        raise SystemExit(
            "Email is enabled but SMTP config is incomplete. Fill config/email.json or set EDITORIAL_DESK_SMTP_* env vars."
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("recipient", nargs="?", default=None)
    parser.add_argument("--no-email", action="store_true", help="Only render HTML, do not send email.")
    add_profile_arg(parser)
    args = parser.parse_args()

    ensure_output_dirs()
    profile_name, profile_meta, _profile_config = load_profile(args.profile)
    paths = build_output_paths(profile_name, profile_meta)
    md = paths["report_md"].read_text(encoding="utf-8")
    sections = md_to_sections(md)
    html = build_html(sections, profile_meta)
    paths["report_html"].write_text(html, encoding="utf-8")

    email_config = load_email_config()
    recipient = args.recipient or email_config.get("default_recipient") or ""
    should_send = not args.no_email and bool(email_config.get("enabled")) and bool(recipient)
    if should_send:
        validate_email_config(email_config)
        send_email(html, recipient, profile_meta, email_config)

    print(
        json.dumps(
            {
                "profile": profile_name,
                "html_path": str(paths["report_html"]),
                "recipient": recipient,
                "sent": should_send,
            },
            ensure_ascii=False,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
