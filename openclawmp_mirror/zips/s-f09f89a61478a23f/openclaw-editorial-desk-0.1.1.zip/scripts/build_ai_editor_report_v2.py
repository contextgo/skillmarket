#!/usr/bin/env python3
"""
Build a richer editor-style AI report with stronger commentary and newspaper tone.
Usage: python build_ai_editor_report_v2.py [--profile product_morning]
"""

import argparse
import json
from collections import Counter
from datetime import datetime

from profile_utils import OUTPUT_DIGEST_DIR, TZ, add_profile_arg, build_output_paths, load_profile

DATE_STR = datetime.now(TZ).strftime("%Y-%m-%d")
MAIN_ITEMS = 6
BRIEF_ITEMS = 3


def load_items(ranked_path) -> list[dict]:
    return json.loads(ranked_path.read_text(encoding="utf-8"))


def clean_text(text: str) -> str:
    return " ".join((text or "").replace("\n", " ").split())


def combined_text(item: dict) -> str:
    parts = [item.get("title", ""), item.get("summary", ""), item.get("text", "")]
    return clean_text(" ".join(part for part in parts if part))


def is_x_item(item: dict) -> bool:
    return item.get("kind") == "x"


def source_identity(item: dict) -> str:
    if is_x_item(item):
        return item.get("user", "").lower()
    if item.get("kind") == "google_news_rss":
        return (item.get("publisher") or item.get("user") or item.get("source_key") or "").lower()
    return (item.get("source_key") or item.get("user") or "").lower()


def pool_identity(item: dict) -> str:
    return (item.get("source_key") or item.get("user") or "").lower()


def display_subject(item: dict) -> str:
    if is_x_item(item):
        return f"@{item['user']} ({item['name']})"
    title = clean_text(
        item.get("title")
        or item.get("summary")
        or item.get("text")
        or item.get("source_name")
        or item.get("publisher")
        or "外部来源"
    )
    return title if len(title) <= 100 else title[:97] + "..."


def brief_subject(item: dict) -> str:
    if is_x_item(item):
        return f"@{item['user']}"
    title = clean_text(item.get("title") or item.get("source_name") or item.get("publisher") or "外部来源")
    return title if len(title) <= 36 else title[:33] + "..."


def display_source(item: dict) -> str:
    if is_x_item(item):
        return f"X / @{item['user']}"
    source_name = clean_text(item.get("source_name") or item.get("user") or "外部来源")
    publisher = clean_text(item.get("publisher") or "")
    if publisher and publisher != source_name:
        return f"{source_name} / {publisher}"
    return source_name


def link_label(item: dict) -> str:
    return "原帖" if is_x_item(item) else "原文"


def snippet_text(item: dict, limit: int = 90) -> str:
    if is_x_item(item):
        base = item.get("text", "")
    else:
        base = item.get("summary") or item.get("text") or item.get("title") or ""
    text = clean_text(base)
    return text if len(text) <= limit else text[: limit - 1] + "…"


def theme_label(item: dict) -> str:
    groups = item.get("keyword_groups", [])
    if "china_ai" in groups:
        return "中国 AI"
    if "company_moves" in groups:
        return "公司动作"
    if "work_and_life" in groups:
        return "场景 / 应用"
    if "tool_discovery" in groups:
        return "工具发现"
    if "product_launch" in groups:
        return "产品发布"
    if "platform_moves" in groups:
        return "平台 / 大厂"
    return "综合"


def topic_key(item: dict) -> str:
    text = combined_text(item).lower()
    if any(token in text for token in ["browser", "search", "email", "docs", "document", "slides", "spreadsheet", "calendar", "meeting", "writing", "voice", "audio", "浏览器", "搜索", "邮件", "文档", "表格", "会议", "写作", "语音"]):
        return "daily-workflow"
    if any(token in text for token in ["assistant", "extension", "plugin", "workflow", "automation", "tool", "app", "chrome extension", "工具", "应用", "插件", "自动化"]):
        return "tooling"
    if any(token in text for token in ["月之暗面", "智谱", "minimax", "deepseek", "豆包", "通义", "夸克", "百度", "阿里", "腾讯", "字节", "零一万物", "商汤"]):
        return "china-ai"
    if any(token in text for token in ["融资", "收购", "合作", "定价", "订阅", "企业版", "商业化", "股价", "港股", "概念股", "异动", "pricing", "subscription", "enterprise", "funding", "acquisition", "partnership", "valuation", "revenue"]):
        return "company-moves"
    if any(token in text for token in ["launch", "launched", "release", "released", "rolling out", "available now", "preview", "推出", "发布", "上线", "new feature"]):
        return "product-launch"
    if any(token in text for token in ["openai", "anthropic", "claude", "gemini", "google ai", "chatgpt", "copilot", "meta ai", "xai"]):
        return "platform-moves"
    return source_identity(item)


def is_brief_candidate(item: dict) -> bool:
    text = combined_text(item).lower()
    if len(text) < 30:
        return False
    if text.startswith("rt @") and item.get("score", 0) < 45:
        return False
    if item.get("keyword_groups"):
        return True
    return any(
        token in text
        for token in [
            "pricing",
            "subscription",
            "funding",
            "acquisition",
            "browser",
            "email",
            "docs",
            "voice",
            "assistant",
            "automation",
            "工具",
            "融资",
            "合作",
            "发布",
        ]
    )


def select_main_items(items: list[dict]) -> list[dict]:
    chosen = []
    seen_sources = set()
    seen_topics = set()
    for item in items:
        source_id = source_identity(item)
        topic = topic_key(item)
        if source_id in seen_sources:
            continue
        if topic in seen_topics:
            continue
        chosen.append(item)
        seen_sources.add(source_id)
        seen_topics.add(topic)
        if len(chosen) >= MAIN_ITEMS:
            break
    return chosen


def select_briefs(items: list[dict], main_items: list[dict]) -> list[dict]:
    used_ids = {item["id"] for item in main_items}
    briefs = []
    seen_sources = {source_identity(item) for item in main_items}
    seen_topics = {topic_key(item) for item in main_items}
    for item in items:
        source_id = source_identity(item)
        topic = topic_key(item)
        if item["id"] in used_ids:
            continue
        if source_id in seen_sources:
            continue
        if topic in seen_topics:
            continue
        if not is_brief_candidate(item):
            continue
        briefs.append(item)
        seen_sources.add(source_id)
        seen_topics.add(topic)
        if len(briefs) >= BRIEF_ITEMS:
            break
    return briefs


def importance_line(item: dict) -> str:
    groups = set(item.get("keyword_groups", []))
    text = combined_text(item).lower()
    if "company_moves" in groups:
        return "定价、融资和合作通常比热闹功能更能暴露一家公司接下来准备怎么拿市场。"
    if "work_and_life" in groups:
        return "当 AI 开始进入浏览器、邮件、文档这些高频入口，才算真正接近日常使用。"
    if "tool_discovery" in groups:
        return "值得留意的不是又多一个助手，而是它有没有嵌进现成流程、帮你少切一次应用。"
    if "china_ai" in groups:
        return "中国 AI 的看点正在从模型参数转向产品速度、渠道触达和商业节奏。"
    if "product_launch" in groups:
        return "发布动作不稀缺，真正稀缺的是把新能力推进到普通人愿意反复用的场景。"
    if "platform_moves" in groups:
        return "平台级变化通常会带动一串工具、分发和定价动作一起变化。"
    if "official" in text or "newsroom" in text:
        return "这类官方信息未必最会讲故事，但通常是判断方向变化最稳的底稿。"
    return f"这条不是单纯热闹，它能帮你判断接下来谁会抢入口、抢心智、抢预算。{snippet_text(item, 40)}"


def desk_view(item: dict) -> str:
    groups = set(item.get("keyword_groups", []))
    if "company_moves" in groups:
        return "接下来更值得盯的是价格、合作和渠道，而不是单次发布会的声量。"
    if "work_and_life" in groups:
        return "高频入口一旦被 AI 接管，用户习惯就会比模型参数更难逆转。"
    if "tool_discovery" in groups:
        return "工具竞争很快会从“能不能做”变成“你愿不愿意每天顺手用”。"
    if "china_ai" in groups:
        return "中国公司的分化会更明显：谁能把产品、分发和商业化接起来，谁就更可能跑出来。"
    if "product_launch" in groups:
        return "这类发布后面真正要追的是留存和进入工作流的速度。"
    if "platform_moves" in groups:
        return "大平台一动，下游工具和内容分发通常会跟着重排。"
    return "这条未必定义今天，但可能解释接下来几周谁会先占住用户入口。"


def build_masthead(main_items: list[dict], briefs: list[dict], all_items: list[dict], profile_meta: dict) -> list[str]:
    themes = Counter(theme_label(item) for item in main_items)
    kind_counts = Counter("X" if is_x_item(item) else "外部" for item in all_items)
    lines = ["## 📊 今日版面（Morning Edition)"]
    lines.append(f"- **版面判断**: {profile_meta['description']}")
    lines.append(f"- **版面密度**: 过了 {len(all_items)} 条候选，最后留 {len(main_items)} 条长稿，补 {len(briefs)} 条短讯。")
    lines.append(f"- **候选结构**: X {kind_counts.get('X', 0)} 条，外部信源 {kind_counts.get('外部', 0)} 条。")
    lines.append(f"- **头版主题**: {themes.most_common(1)[0][0] if themes else 'mixed'}")
    lines.append(f"- **编辑取舍**: {profile_meta['focus_line']}")
    lines.append("")
    return lines


def build_core_section(items: list[dict]) -> list[str]:
    lines = ["## 🎯 头版三条", ""]
    for idx, item in enumerate(items[:3], 1):
        lines.append(f"### {idx}. {display_subject(item)} — 编辑打分: {item['score']}")
        lines.append(f"- **来源**: {display_source(item)}")
        lines.append(f"- **信号标签**: {theme_label(item)}")
        lines.append(f"- **为什么值得看**: {importance_line(item)}")
        lines.append(f"- **我的判断**: {desk_view(item)}")
        lines.append(f"- **{link_label(item)}**: {item['url']}")
        lines.append("")
    return lines


def build_pick_section(items: list[dict]) -> list[str]:
    remainder = items[3:]
    lines = [f"## 🔥 版面续稿（其余 {len(remainder)} 条）", ""]
    for idx, item in enumerate(remainder, 4):
        lines.append(f"### {idx}. {display_subject(item)} — 编辑打分: {item['score']}")
        lines.append(f"- **来源**: {display_source(item)}")
        lines.append(f"- **信号标签**: {theme_label(item)}")
        lines.append(f"- **值得留意**: {importance_line(item)}")
        lines.append(f"- **我的判断**: {desk_view(item)}")
        lines.append(f"- **{link_label(item)}**: {item['url']}")
        lines.append("")
    return lines


def build_brief_section(items: list[dict]) -> list[str]:
    lines = ["## 🗞 侧栏短讯", ""]
    if not items:
        lines.append("- 今天短讯位留空，不硬凑。")
        lines.append("")
        return lines
    for idx, item in enumerate(items, 1):
        lines.append(f"- **短讯 {idx} | {brief_subject(item)} | {theme_label(item)}**")
        lines.append(f"- **来源**: {display_source(item)}")
        lines.append(f"- **摘要**: {snippet_text(item, 110)}")
        lines.append(f"- **判断**: {desk_view(item)}")
        lines.append(f"- **{link_label(item)}**: {item['url']}")
        lines.append("")
    return lines


def build_trend_radar(items: list[dict], briefs: list[dict]) -> list[str]:
    selected = items + briefs
    group_counts = Counter(group for item in selected for group in item.get("keyword_groups", []))
    signals = []

    if group_counts["company_moves"]:
        signals.append("这版里反复出现的不是空泛口号，而是定价、融资和合作，说明商业化信号正在压过单纯的模型热度。")
    if group_counts["work_and_life"]:
        signals.append("AI 继续往浏览器、邮件、文档、会议这些高频入口渗透，真正的战场越来越像日常软件而不是模型榜单。")
    if group_counts["tool_discovery"]:
        signals.append("工具竞争正在从“能力展示”转向“入口占领”，能不能顺手嵌进现有流程比 demo 更重要。")
    if group_counts["china_ai"]:
        signals.append("中国 AI 的竞争点正在从参数和概念，转向产品触达、渠道布局和商业节奏。")
    if group_counts["product_launch"]:
        signals.append("发布节奏在加快，但真正该追的是哪些能力开始进入高频场景，而不是停在发布页。")
    if group_counts["platform_moves"]:
        signals.append("平台一旦有动作，下游工具和内容分发会一起重排，所以大厂消息依然值得持续盯。")
    if not signals:
        signals.append("今天真正该看的不是热度，而是哪些信号开始在不同来源里反复出现。")

    lines = ["## 📈 趋势雷达"]
    for signal in signals[:3]:
        lines.append(f"- {signal}")
    lines.append("")
    return lines


def build_learning_notes(main_items: list[dict], briefs: list[dict], all_items: list[dict]) -> list[str]:
    lines = ["## 💡 编后记"]
    notes = []
    group_counts = Counter(group for item in all_items for group in item.get("keyword_groups", []))

    if group_counts["company_moves"]:
        notes.append("这版最值得反复看的，往往不是“模型更强了”这种抽象结论，而是定价、融资和合作，因为它们最能暴露真实战略。")
    if group_counts["work_and_life"]:
        notes.append("当浏览器、邮件、文档、会议这些入口开始反复出现，就说明 AI 正在从一项功能变成新的界面层。")
    if group_counts["tool_discovery"]:
        notes.append("工具值不值得进日报，不看它会不会聊天，看它能不能少让你切一次应用、多帮你完成一步任务。")
    if group_counts["china_ai"]:
        notes.append("看中国 AI 不能只盯技术参数，更要看谁把产品速度、渠道覆盖和商业化接起来，这决定了它能不能形成真实心智。")
    if group_counts["platform_moves"]:
        notes.append("大平台每次改动都会重新分配上下游机会，所以官方源虽然不一定最好看，但仍然值得放在固定观察位。")

    notes.append("这版我继续把同一信源压到一条长稿以内，把版面让给更多来源。日报不是某个账号的精选页，得像一张报纸。")

    for idx, note in enumerate(notes[:3], 1):
        lines.append(f"{idx}. {note}")
    lines.append("")
    return lines


def build_stats(main_items: list[dict], briefs: list[dict], all_items: list[dict], core_source_keys: set[str]) -> list[str]:
    long_source_counts = Counter(
        "核心池" if pool_identity(item) in core_source_keys else "扩展池" for item in main_items
    )
    lines = ["## 📋 版面附注"]
    lines.append(f"- **候选总量**: {len(all_items)} 条")
    lines.append(f"- **长稿入选**: {len(main_items)} 条")
    lines.append(f"- **短讯补充**: {len(briefs)} 条")
    lines.append(f"- **长稿通过率**: ~{round(len(main_items) / max(len(all_items), 1) * 100)}%")
    lines.append(f"- **信源构成**: 核心池 {long_source_counts.get('核心池', 0)} 条，扩展池 {long_source_counts.get('扩展池', 0)} 条")
    lines.append(f"- **出刊时间**: {datetime.now(TZ).strftime('%Y-%m-%d %H:%M:%S')}（上海）")
    return lines


def main() -> int:
    parser = argparse.ArgumentParser()
    add_profile_arg(parser)
    args = parser.parse_args()

    OUTPUT_DIGEST_DIR.mkdir(parents=True, exist_ok=True)
    profile_name, profile_meta, profile_config = load_profile(args.profile)
    paths = build_output_paths(profile_name, profile_meta)
    core_source_keys = {item["handle"].lower() for item in profile_config["core_sources"] if item["tier"] == "core"}
    core_source_keys.update(
        item["source_key"]
        for item in profile_config.get("external_sources", []) + profile_config.get("search_queries", [])
        if item["tier"] == "core"
    )
    all_items = load_items(paths["ranked"])
    main_items = select_main_items(all_items)
    briefs = select_briefs(all_items, main_items)
    lines = [f"# {profile_meta['title']} - {DATE_STR}", ""]
    lines.extend(build_masthead(main_items, briefs, all_items, profile_meta))
    lines.extend(build_core_section(main_items))
    lines.extend(build_pick_section(main_items))
    lines.extend(build_brief_section(briefs))
    lines.extend(build_trend_radar(main_items, briefs))
    lines.extend(build_learning_notes(main_items, briefs, all_items))
    lines.extend(build_stats(main_items, briefs, all_items, core_source_keys))
    paths["report_md"].write_text("\n".join(lines), encoding="utf-8")
    print(str(paths["report_md"]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
