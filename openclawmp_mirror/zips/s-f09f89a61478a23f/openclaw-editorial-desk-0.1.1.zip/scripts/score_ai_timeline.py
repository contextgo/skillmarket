#!/usr/bin/env python3
"""
Score the recent X timeline with editorial heuristics.
Usage: python score_ai_timeline.py [--profile product_morning]

Run this script with the x-cli virtualenv Python, or use scripts/run_digest.py.
"""

import argparse
import asyncio
import json
from datetime import datetime, timedelta
from typing import Optional
import sys

from external_sources import fetch_external_items
from profile_utils import UTC, add_profile_arg, build_output_paths, ensure_output_dirs, get_x_cli_dir, load_profile


def normalize_created_at(value):
    if isinstance(value, str):
        return datetime.strptime(value, "%a %b %d %H:%M:%S %z %Y")
    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value


def clean_text(text: str) -> str:
    return " ".join((text or "").replace("\n", " ").split())


def build_source_map(config: dict) -> dict:
    source_map = {}
    for item in config["core_sources"]:
        source_map[item["handle"].lower()] = item
    for item in config.get("external_sources", []):
        source_map[item["source_key"]] = item
    for item in config.get("search_queries", []):
        source_map[item["source_key"]] = item
    return source_map


def load_x_client_factory():
    x_cli_dir = get_x_cli_dir()
    scripts_dir = x_cli_dir / "scripts"
    if not scripts_dir.exists():
        raise SystemExit(
            "x-cli scripts not found. Set EDITORIAL_DESK_X_CLI_DIR or install x-cli under ~/.openclaw/workspace/skills/x-cli."
        )
    if str(scripts_dir) not in sys.path:
        sys.path.insert(0, str(scripts_dir))
    try:
        from x_utils import get_client  # type: ignore
    except Exception as exc:  # pragma: no cover - environment-dependent import
        raise SystemExit(
            "Failed to import x-cli dependencies. Use scripts/run_digest.py so the scoring step runs inside the x-cli virtualenv."
        ) from exc
    return get_client


async def fetch_timeline_with_retry(client, count: int, attempts: int = 3):
    last_error = None
    for attempt in range(1, attempts + 1):
        try:
            return await client.get_latest_timeline(count=count)
        except Exception as exc:  # pragma: no cover - network retry path
            last_error = exc
            if attempt == attempts:
                raise
            await asyncio.sleep(attempt * 2)
    raise last_error


def dedupe_items(items: list[dict]) -> list[dict]:
    seen_urls = set()
    seen_titles = set()
    deduped = []
    for item in items:
        url = item.get("url", "").strip()
        title = item.get("title", item.get("text", "")).strip().lower()
        url_key = url.split("?")[0] if url else ""
        title_key = title[:140]
        if url_key and url_key in seen_urls:
            continue
        if title_key and title_key in seen_titles:
            continue
        if url_key:
            seen_urls.add(url_key)
        if title_key:
            seen_titles.add(title_key)
        deduped.append(item)
    return deduped


def find_keyword_hits(text: str, config: dict) -> tuple[list[str], list[str], int]:
    lower = text.lower()
    groups = []
    hits = []
    bonus = 0
    indexes = config.get("keyword_indexes", {})
    for group, meta in indexes.items():
        keywords = meta.get("keywords", [])
        matched = [kw for kw in keywords if kw.lower() in lower]
        if matched:
            groups.append(group)
            hits.extend(matched)
            bonus += int(meta.get("weight", 0))
    return groups, hits, bonus


def find_deprioritize_hits(text: str, config: dict) -> list[str]:
    lower = text.lower()
    return [kw for kw in config.get("deprioritize_keywords", []) if kw.lower() in lower]


def is_official_source(source: Optional[dict]) -> bool:
    if not source:
        return False
    topics = set(source.get("topics", []))
    return "official" in topics or "org" in topics


def score_item(item: dict, config: dict, source_map: dict) -> Optional[dict]:
    handle = item["user"].lower()
    text = clean_text(item["text"])
    lower = text.lower()

    if handle in {h.lower() for h in config["hard_filters"]["blocked_handles"]}:
        return None
    if any(term.lower() in lower for term in config["hard_filters"]["blocked_terms"]):
        return None

    rules = config["score_rules"]
    score = rules["base"]
    reasons = []

    source = source_map.get(handle) or source_map.get(item.get("source_key", ""))
    if source:
        if source["tier"] == "core":
            score += rules["core_source_bonus"]
            reasons.append("core source")
        else:
            score += rules["watch_source_bonus"]
            reasons.append("watch source")
        score += round(source["signal_weight"] * 10)
        score -= round(source["noise_penalty"] * 10)

    groups, hits, keyword_bonus = find_keyword_hits(text, config)
    if rules.get("require_source_or_keyword") and not source and not hits:
        return None

    if hits:
        score += keyword_bonus
        reasons.append("keyword hits: " + ", ".join(sorted(set(hits))[:6]))
    if len(groups) >= 2:
        score += rules["multiple_keyword_groups_bonus"]
        reasons.append("cross-topic signal")

    deprioritize_hits = find_deprioritize_hits(text, config)
    if deprioritize_hits:
        score -= min(len(deprioritize_hits), 3) * rules.get("deprioritize_penalty", 0)
        reasons.append("too technical: " + ", ".join(sorted(set(deprioritize_hits))[:4]))

    likes = int(item["favorite_count"])
    retweets = int(item["retweet_count"])
    score += likes // rules["engagement_like_divisor"]
    score += retweets // rules["engagement_retweet_divisor"]

    if item.get("kind") == "x" and text.startswith("RT @"):
        score -= rules["retweet_penalty"]
        reasons.append("retweet penalty")
    if len(text) < 40 and not hits:
        score -= rules["short_generic_penalty"]
        reasons.append("generic short post")
    if is_official_source(source):
        score += rules["official_source_fact_bonus"]
        reasons.append("official fact source")
    if any(word in lower for word in ["i think", "i believe", "hot take"]):
        score -= rules["opinion_penalty"]
        reasons.append("opinion-heavy")

    item["score"] = score
    item["reasons"] = reasons
    item["keyword_groups"] = groups
    item["keyword_hits"] = sorted(set(hits))
    return item


async def main() -> int:
    parser = argparse.ArgumentParser()
    add_profile_arg(parser)
    args = parser.parse_args()

    ensure_output_dirs()
    profile_name, profile_meta, config = load_profile(args.profile)
    out_path = build_output_paths(profile_name, profile_meta)["ranked"]
    timeline_count = config.get("fetch_plan", {}).get("x_timeline", {}).get("count", 120)
    include_x = config.get("fetch_plan", {}).get("x_timeline", {}).get("enabled", True)
    source_map = build_source_map(config)

    tweets = []
    if include_x:
        get_client = load_x_client_factory()
        client = await get_client()
        tweets = await fetch_timeline_with_retry(client, count=timeline_count)

    cutoff = datetime.now(UTC) - timedelta(hours=36)
    candidates = []
    for tweet in tweets:
        created = normalize_created_at(getattr(tweet, "created_at", None))
        if created < cutoff:
            continue
        user = getattr(tweet, "user", None)
        item = {
            "id": getattr(tweet, "id", ""),
            "user": getattr(user, "screen_name", "unknown"),
            "name": getattr(user, "name", "unknown"),
            "text": getattr(tweet, "text", ""),
            "created_at": created.isoformat(),
            "favorite_count": int(getattr(tweet, "favorite_count", 0) or 0),
            "retweet_count": int(getattr(tweet, "retweet_count", 0) or 0),
            "url": f"https://x.com/{getattr(user, 'screen_name', 'i')}/status/{getattr(tweet, 'id', '')}",
            "kind": "x",
        }
        candidates.append(item)

    candidates.extend(fetch_external_items(config, hours_back=config.get("fetch_plan", {}).get("external_hours_back", 72)))

    ranked = []
    for item in dedupe_items(candidates):
        scored = score_item(item, config, source_map)
        if not scored:
            continue
        if scored["score"] >= config["score_rules"]["min_digest_score"]:
            ranked.append(scored)

    ranked.sort(key=lambda x: (x["score"], x["favorite_count"] + x["retweet_count"] * 2), reverse=True)
    out_path.write_text(json.dumps(ranked[:30], ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps({"profile": profile_name, "count": len(ranked[:30]), "path": str(out_path)}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
