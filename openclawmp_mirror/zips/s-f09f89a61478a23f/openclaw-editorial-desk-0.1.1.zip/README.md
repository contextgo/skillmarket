# OpenClaw Editorial Desk

这是一个给非技术读者准备的 AI 编辑部 skill。

它的目标不是把你时间线里最热的内容全部塞给你，而是像一张真正的报纸那样，先做取舍，再做呈现。你看到的应该是“值得读”的内容，而不是“吵得最响”的内容。

## 这个版本能做什么

- 不再只看 X，而是同时使用三层信源：
  - 重点观察账号
  - 官方 RSS
  - 基于关键词的 Google News RSS 检索
- 支持三种可切换阅读场景：
  - `product_morning`
  - `china_ai_watch`
  - `tool_watch`
- 生成报纸风格的 Markdown 和 HTML
- 把关键词当成一级索引，而不是只盯着“谁发了”
- 自动限制同一作者和同一题材的重复占版，让日报更像报纸而不是单账号精选

## 适合谁

这套 skill 默认服务的是非技术核心读者。

它的编辑倾向很明确：

- 更看重产品动作、公司变化、真实可用场景、值得点开的工具
- 主动压低工程细节、benchmark 讨论、纯开发者术语和社交噪音

## 当前可用的三个版本

### `product_morning`

适合看：

- 产品发布
- 平台动作
- 中国 AI 公司变化
- 公司与定价信号
- 浏览器、文档、邮件、搜索、语音这类高频入口

### `china_ai_watch`

适合看：

- 中国 AI 公司
- 发布、合作、商业动作
- 本地化应用入口

这一版额外压低了 `港股`、`异动`、`概念股` 这类看盘式噪音，避免整份内容滑成股票摘要。

### `tool_watch`

适合看：

- 值得点开的工具
- 插件、自动化、工作流辅助
- 浏览器和办公场景入口
- 面向普通用户的 AI 应用

## 包结构

```text
openclaw-editorial-desk/
├── SKILL.md
├── README.md
├── skill.json
├── install.sh
├── config/
│   ├── digest_profiles.json
│   ├── settings.json.example
│   ├── email.json.example
│   ├── publish.json.example
│   └── profiles/
│       ├── product_morning.json
│       ├── china_ai_watch.json
│       └── tool_watch.json
└── scripts/
    ├── run_digest.py
    ├── score_ai_timeline.py
    ├── build_ai_editor_report_v2.py
    ├── render_ai_newspaper_email.py
    ├── external_sources.py
    ├── profile_utils.py
    ├── list_digest_profiles.py
    └── publish_to_marketplace.py
```

## 安装方式

### 方式一：直接安装到 OpenClaw 工作区

```bash
bash install.sh
```

### 方式二：手动复制

```bash
cp -R openclaw-editorial-desk ~/.openclaw/workspace/skills/openclaw-editorial-desk
```

## 运行前提

1. 先安装 `x-cli`，路径默认是 `~/.openclaw/workspace/skills/x-cli`
2. 确保 `x-cli/.venv` 已创建
3. 确保 `x-cli` 已完成登录和 cookie 配置
4. 本机有 Python 3.11+

这套 skill 只在“抓 X 内容”这一步依赖 `x-cli` 的虚拟环境。后续的排序、写稿、HTML 渲染都走普通 Python 运行时。

## 基本用法

```bash
python scripts/list_digest_profiles.py
python scripts/run_digest.py --profile product_morning
python scripts/run_digest.py --profile china_ai_watch
python scripts/run_digest.py --profile tool_watch
```

如果没有配置 SMTP，它依然会生成 Markdown 和 HTML，只是自动跳过发邮件。

默认输出目录是：

```text
~/Desktop/myopenclaw/digests/
```

## 配置项

### 通用设置

先复制：

```bash
cp config/settings.json.example config/settings.json
```

可配置字段：

- `output_root`
- `timezone`
- `x_cli_dir`
- `email_enabled`
- `default_recipient`

### 邮件发送

先复制：

```bash
cp config/email.json.example config/email.json
```

然后填入 SMTP 信息。

### 发布到 openclawmp

先复制：

```bash
cp config/publish.json.example config/publish.json
```

或者使用环境变量：

- `OPENCLAWMP_TOKEN`
- `OPENCLAWMP_DEVICE_ID`
- 可选 `OPENCLAWMP_API_BASE`

## 发布命令

只打包：

```bash
python scripts/publish_to_marketplace.py --dry-run
```

打包并发布：

```bash
python scripts/publish_to_marketplace.py --publish
```

## 当前版本包含什么

`0.1.x` 这一阶段，重点是把它变成一个能分享、能跑通、能让别人看懂方向的编辑部 skill。

已经包含：

- 多信源抓取
- 按场景切换的 profile 体系
- 关键词优先的编辑索引
- 报纸风格 Markdown / HTML 输出
- 不同场景下的版面切换

还没有包含：

- Notion 书架同步
- 从 Notion 阅读笔记回流反馈
- 网页正文抓取和扩展阅读
- 多天级别的编辑记忆

## 后续规划

下一阶段不是盲目加更多信源，而是把它从“日报生成器”推进成“阅读系统”。

### 1. Notion 书架

目标：

- 每一期内容直接进入 Notion
- 日报、周报、专题页、待读清单都沉淀在一个阅读书架里
- 可以按日期、profile、主题、来源检索和回看

预计会增加：

- Notion 数据库结构
- 自动创建 issue 页面
- 保存 Markdown、HTML、摘要、封面字段和 profile 元数据

### 2. 阅读反馈回流

目标：

- 你在 Notion 里的阅读笔记直接变成编辑部反馈
- 批注、判断、收藏行为都会影响后续版面

预计会增加：

- 拉取 Notion 笔记和标签
- 将笔记映射回具体条目或条目簇
- 调整信源权重、关键词权重、头版与短讯的选择逻辑

### 3. 不只是日报

目标：

- 做成书架，而不是只做一份日报

后续会扩成：

- 每日早报
- 每周回顾
- 专题页
- 公司观察页
- 待读清单

### 4. 更成熟的抓源层

当前抓源层故意保持轻量，先验证阅读价值。

接下来更可能补的方向：

- 更多稳定 RSS
- 网页正文抓取
- 更强的 Google News 去重
- 有选择地接入 Reddit、YouTube、播客源和中文平台内容

### 5. 编辑记忆

目标：

- 不要连续几天重复讲同一个角度
- 学会记住读者真正保留和在意的内容

这会需要：

- issue 级记忆
- 信源表现历史
- 基于反馈的版面调整

## 这次发布的意义

这个版本已经足够拿来分享，因为它至少把三件事讲清楚了：

- 非技术读者的 AI 日报，首先要做的是信源设计
- 关键词索引必须和账号源并列，而不是可有可无
- 面向真实阅读的 AI 日报，应该是“编辑过的”，而不是“堆出来的”
