---
name: openclaw-editorial-desk
displayName: OpenClaw Editorial Desk
description: "为非技术读者生成可切换场景的 AI 报纸版日报。支持产品早报、中国 AI 动向、工具雷达三种 profile，基于 X、官方 RSS 和关键词新闻检索做编辑筛选。"
version: 0.1.1
type: skill
tags: digest, editorial, ai-news, personalized-reading, news-aggregator, assistant_friendly
---

# OpenClaw Editorial Desk

在下面这些场景下使用这个 skill：

- 用户想要一份更像报纸的 AI 阅读物，而不是开发者时间线精选
- 用户想在 `product_morning`、`china_ai_watch`、`tool_watch` 之间切换阅读场景
- 用户要调整信源、关键词索引、版面取舍，让内容更贴近非技术核心读者
- 用户需要基于 X、RSS 和关键词新闻检索，生成 Markdown / HTML 的报纸版内容

## 前置条件

1. 已安装 `x-cli`，默认路径为 `~/.openclaw/workspace/skills/x-cli`
2. `x-cli/.venv` 可用，且已完成登录
3. Python 3.11+
4. 如果需要邮件发送，则额外配置 SMTP

## 快速开始

```bash
python scripts/list_digest_profiles.py
python scripts/run_digest.py --profile product_morning
python scripts/run_digest.py --profile china_ai_watch
python scripts/run_digest.py --profile tool_watch
```

默认输出目录：

```text
~/Desktop/myopenclaw/digests
```

## 当前支持的 profile

- `product_morning`：产品、平台、公司动作、生活与工作入口
- `china_ai_watch`：中国 AI 公司、发布、合作、商业信号
- `tool_watch`：工具、插件、自动化、工作流场景

## 关键文件

- `scripts/score_ai_timeline.py`：合并 X、RSS、Google News RSS 候选并打分
- `scripts/build_ai_editor_report_v2.py`：把候选整理成报纸版 Markdown
- `scripts/render_ai_newspaper_email.py`：渲染 HTML，必要时发送邮件
- `config/profiles/*.json`：定义信源、关键词索引、过滤词和权重

## 配置方式

- 复制 `config/settings.json.example` 为 `config/settings.json`
- 复制 `config/email.json.example` 为 `config/email.json`，如果需要邮件发送
- 通过 `AI_DIGEST_PROFILE` 切换默认 profile

## 当前范围

这个版本先交付“编辑部日报生成链路”本身，还没有接入 Notion 书架，也还没有把 Notion 阅读笔记回流为编辑反馈。

更完整的规划写在 `README.md` 里。
