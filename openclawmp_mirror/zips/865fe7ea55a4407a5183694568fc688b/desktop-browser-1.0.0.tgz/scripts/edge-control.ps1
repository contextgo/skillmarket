# Control Edge via COM automation
param(
    [Parameter(Mandatory=$true)]
    [string]$Action,  # open, navigate, close
    
    [string]$Url,
    [string]$WindowTitle
)

function Open-Edge {
    param([string]$Url)
    
    try {
        # Try to get existing Edge instance
        $edge = Get-Process "msedge" -ErrorAction SilentlyContinue | Select-Object -First 1
        
        if ($edge) {
            # Edge is running, open new tab
            Start-Process "msedge.exe" -ArgumentList "--new-tab", $Url
        } else {
            # Start new Edge instance
            Start-Process "msedge.exe" -ArgumentList $Url
        }
        
        Write-Output "Edge: Opened $Url"
    } catch {
        Write-Error "Failed to control Edge: $_"
        exit 1
    }
}

function Close-Edge {
    try {
        Stop-Process -Name "msedge" -Force -ErrorAction SilentlyContinue
        Write-Output "Edge: Closed all instances"
    } catch {
        Write-Error "Failed to close Edge: $_"
        exit 1
    }
}

switch ($Action.ToLower()) {
    "open" { Open-Edge -Url $Url }
    "navigate" { Open-Edge -Url $Url }
    "close" { Close-Edge }
    default {
        Write-Error "Unknown action: $Action. Use: open, navigate, close"
        exit 1
    }
}
