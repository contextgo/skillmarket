# Use Playwright to control local browser
param(
    [Parameter(Mandatory=$true)]
    [string]$Action,  # open, screenshot, evaluate
    
    [string]$Url,
    [string]$Browser = "chrome",  # chrome, edge, firefox
    [string]$Script,
    [string]$OutputPath
)

function Test-Playwright {
    try {
        & npx playwright --version 2>$null
        return $LASTEXITCODE -eq 0
    } catch {
        return $false
    }
}

function Install-Playwright {
    Write-Output "Installing Playwright..."
    & npm install -g @playwright/test
    & npx playwright install chromium
}

function Open-Browser {
    param(
        [string]$Url,
        [string]$Browser
    )
    
    $browserType = switch ($Browser.ToLower()) {
        "chrome" { "chromium" }
        "edge" { "chromium" }
        "firefox" { "firefox" }
        default { "chromium" }
    }
    
    $jsCode = @"
const { chromium, firefox } = require('playwright');

(async () => {
    const browser = await $browserType.launch({ headless: false });
    const page = await browser.newPage();
    await page.goto('$Url');
    console.log('Browser opened: $Url');
    // Keep browser open
})();
"@
    
    $tempFile = [System.IO.Path]::GetTempFileName() + ".js"
    Set-Content -Path $tempFile -Value $jsCode
    
    try {
        & node $tempFile
    } finally {
        Remove-Item $tempFile -ErrorAction SilentlyContinue
    }
}

function Take-Screenshot {
    param(
        [string]$Url,
        [string]$OutputPath
    )
    
    if (-not $OutputPath) {
        $OutputPath = "$env:USERPROFILE\Desktop\screenshot_$(Get-Date -Format 'yyyyMMdd_HHmmss').png"
    }
    
    $jsCode = @"
const { chromium } = require('playwright');

(async () => {
    const browser = await chromium.launch();
    const page = await browser.newPage();
    await page.goto('$Url');
    await page.screenshot({ path: '$OutputPath', fullPage: true });
    await browser.close();
    console.log('Screenshot saved: $OutputPath');
})();
"@
    
    $tempFile = [System.IO.Path]::GetTempFileName() + ".js"
    Set-Content -Path $tempFile -Value $jsCode
    
    try {
        & node $tempFile
    } finally {
        Remove-Item $tempFile -ErrorAction SilentlyContinue
    }
}

# Main
if (-not (Test-Playwright)) {
    Install-Playwright
}

switch ($Action.ToLower()) {
    "open" { Open-Browser -Url $Url -Browser $Browser }
    "screenshot" { Take-Screenshot -Url $Url -OutputPath $OutputPath }
    default {
        Write-Error "Unknown action: $Action. Use: open, screenshot"
        exit 1
    }
}
