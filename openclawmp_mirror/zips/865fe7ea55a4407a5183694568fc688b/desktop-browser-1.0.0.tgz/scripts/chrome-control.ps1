# Control Chrome via COM automation
param(
    [Parameter(Mandatory=$true)]
    [string]$Action,  # open, navigate, close
    
    [string]$Url,
    [string]$WindowTitle
)

function Open-Chrome {
    param([string]$Url)
    
    try {
        # Try to get existing Chrome instance
        $chrome = Get-Process "chrome" -ErrorAction SilentlyContinue | Select-Object -First 1
        
        if ($chrome) {
            # Chrome is running, open new tab
            Start-Process "chrome.exe" -ArgumentList "--new-tab", $Url
        } else {
            # Start new Chrome instance
            Start-Process "chrome.exe" -ArgumentList $Url
        }
        
        Write-Output "Chrome: Opened $Url"
    } catch {
        Write-Error "Failed to control Chrome: $_"
        exit 1
    }
}

function Close-Chrome {
    try {
        Stop-Process -Name "chrome" -Force -ErrorAction SilentlyContinue
        Write-Output "Chrome: Closed all instances"
    } catch {
        Write-Error "Failed to close Chrome: $_"
        exit 1
    }
}

switch ($Action.ToLower()) {
    "open" { Open-Chrome -Url $Url }
    "navigate" { Open-Chrome -Url $Url }
    "close" { Close-Chrome }
    default {
        Write-Error "Unknown action: $Action. Use: open, navigate, close"
        exit 1
    }
}
