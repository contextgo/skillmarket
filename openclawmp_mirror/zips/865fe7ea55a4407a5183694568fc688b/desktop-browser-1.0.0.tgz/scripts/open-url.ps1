# Open URL in user's preferred browser (Edge优先)
param(
    [Parameter(Mandatory=$true)]
    [string]$Url,
    
    [string]$Browser = "edge"  # edge, chrome, default
)

# Validate URL
if (-not ($Url -match '^https?://')) {
    Write-Error "Invalid URL. Must start with http:// or https://"
    exit 1
}

function Get-EdgePath {
    $paths = @(
        "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe",
        "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe",
        "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe"
    )
    foreach ($path in $paths) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

function Get-ChromePath {
    $paths = @(
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    )
    foreach ($path in $paths) {
        if (Test-Path $path) { return $path }
    }
    return $null
}

try {
    switch ($Browser.ToLower()) {
        "edge" {
            $edgePath = Get-EdgePath
            if ($edgePath) {
                Start-Process $edgePath -ArgumentList $Url
                Write-Output "Opened in Edge: $Url"
            } else {
                Start-Process $Url
                Write-Output "Opened in default browser: $Url"
            }
        }
        "chrome" {
            $chromePath = Get-ChromePath
            if ($chromePath) {
                Start-Process $chromePath -ArgumentList $Url
                Write-Output "Opened in Chrome: $Url"
            } else {
                Start-Process $Url
                Write-Output "Opened in default browser: $Url"
            }
        }
        default {
            Start-Process $Url
            Write-Output "Opened in default browser: $Url"
        }
    }
} catch {
    Write-Error "Failed to open URL: $_"
    exit 1
}
