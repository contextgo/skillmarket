---
name: desktop-browser
description: 控制用户桌面上的 Chrome/Edge 浏览器。当用户想在本地浏览器打开网页、自动化浏览器操作或与网页交互时使用。用户偏好 Edge 浏览器。触发词："在我的浏览器打开"、"用我的 Chrome"、"用我的 Edge"、"桌面浏览器"、"本地浏览器"。
---

# 桌面浏览器控制

控制 Windows 上本地的 Edge 或 Chrome 浏览器。

## 用户偏好

**首选浏览器：Edge**

除非用户明确要求 Chrome，否则优先使用 Edge 打开网页。

## 功能

- 在 Edge（首选）或 Chrome 中打开网页
- 通过进程管理控制浏览器
- 新标签页或新窗口
- 关闭浏览器实例

## 浏览器检测路径

Edge 检测路径（按顺序）：
- `%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe`
- `%ProgramFiles%\Microsoft\Edge\Application\msedge.exe`
- `%LOCALAPPDATA%\Microsoft\Edge\Application\msedge.exe`

Chrome 检测路径（按顺序）：
- `%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe`
- `%ProgramFiles%\Google\Chrome\Application\chrome.exe`
- `%LOCALAPPDATA%\Google\Chrome\Application\chrome.exe`

## 使用方法

### 在 Edge 中打开网页（默认）

```powershell
# 直接命令
$edge = Get-ChildItem -Path "${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe", "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($edge) { Start-Process $edge.FullName -ArgumentList "https://example.com" } else { Start-Process "https://example.com" }
```

### 在 Chrome 中打开网页

```powershell
$chrome = Get-ChildItem -Path "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe" -ErrorAction SilentlyContinue | Select-Object -First 1
if ($chrome) { Start-Process $chrome.FullName -ArgumentList "https://example.com" }
```

## 脚本

- `scripts/open-url.ps1` - 使用浏览器自动检测打开网页（Edge 优先）
- `scripts/edge-control.ps1` - Edge 专用控制
- `scripts/chrome-control.ps1` - Chrome 专用控制
- `scripts/playwright-local.ps1` - 使用 Playwright 进行高级自动化

## 安全说明

- 仅在用户明确要求时执行
- 尊重用户的浏览器设置
- 不访问已保存的密码
