# WebSocket Real-Time Application Guide

## Overview
构建可靠的 WebSocket 实时应用，涵盖连接生命周期管理、心跳检测、断线重连和消息处理。

## Connection Lifecycle

```
Connect → Handshake → Open → Message Exchange → Close/Reconnect
                              ↓
                          Heartbeat (ping/pong)
                              ↓
                      Reconnect on failure
```

## Client Implementation (JavaScript)

```javascript
class ResilientWebSocket {
  constructor(url, options = {}) {
    this.url = url;
    this.reconnectDelay = options.reconnectDelay || 1000;
    this.maxReconnectDelay = options.maxReconnectDelay || 30000;
    this.heartbeatInterval = options.heartbeatInterval || 30000;
    this.messageQueue = [];
    this.retryCount = 0;
    this.connect();
  }

  connect() {
    this.ws = new WebSocket(this.url);
    
    this.ws.onopen = () => {
      console.log('Connected');
      this.retryCount = 0;
      this.startHeartbeat();
      this.flushQueue();
    };

    this.ws.onmessage = (event) => {
      if (event.data === 'pong') return;
      this.handleMessage(JSON.parse(event.data));
    };

    this.ws.onclose = () => {
      console.log('Disconnected');
      this.stopHeartbeat();
      this.scheduleReconnect();
    };

    this.ws.onerror = (error) => {
      console.error('WebSocket error:', error);
    };
  }

  send(data) {
    const payload = JSON.stringify(data);
    if (this.ws?.readyState === WebSocket.OPEN) {
      this.ws.send(payload);
    } else {
      this.messageQueue.push(payload);
    }
  }

  scheduleReconnect() {
    const delay = Math.min(
      this.reconnectDelay * Math.pow(1.5, this.retryCount),
      this.maxReconnectDelay
    );
    this.retryCount++;
    setTimeout(() => this.connect(), delay);
  }

  startHeartbeat() {
    this.heartbeatTimer = setInterval(() => {
      if (this.ws?.readyState === WebSocket.OPEN) {
        this.ws.send('ping');
      }
    }, this.heartbeatInterval);
  }

  stopHeartbeat() {
    clearInterval(this.heartbeatTimer);
  }

  flushQueue() {
    while (this.messageQueue.length > 0) {
      this.ws.send(this.messageQueue.shift());
    }
  }
}
```

## Server-Side (Node.js + ws)

```javascript
const WebSocket = require('ws');
const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', (ws) => {
  console.log('Client connected');

  ws.on('message', (data) => {
    // Broadcast to all other clients
    wss.clients.forEach((client) => {
      if (client !== ws && client.readyState === WebSocket.OPEN) {
        client.send(data);
      }
    });
  });

  ws.on('close', () => console.log('Client disconnected'));
});
```

## Crypto Price Stream Example
```javascript
const ws = new WebSocket('wss://stream.binance.com:9443/ws/btcusdt@trade');
ws.onmessage = (event) => {
  const trade = JSON.parse(event.data);
  console.log(`BTC: $${trade.p} (${trade.q} qty)`);
};
```

## Best Practices
1. **Message buffering**: Queue messages during reconnection
2. **Exponential backoff**: Don't hammer the server
3. **Connection state**: Track readyState explicitly
4. **Graceful degradation**: Fall back to polling if WS fails
5. **Compression**: Use permessage-deflate for large payloads