# GitPulse — GitHub Hosts 安全更新助手

GitPulse 帮助你在 Windows 上安全更新系统 hosts 文件，修复 GitHub 访问缓慢或无法连接的问题。基于 GitHub 官方 IP 白名单进行可信校验，并通过 AI 分步分析、安全合并，避免误删你的现有 hosts 条目。

## 使用

安装后，对 AI 说出以下任意内容即可触发：

- "GitHub 打不开"
- "raw.githubusercontent.com 下载不了"
- "GitHub 很慢，换 hosts"
- "更新 GitHub hosts"

触发后，AI 会引导你完成：生成推荐 IP → 读取现有 hosts → 展示差异 diff → 确认后安全写入 → 验证结果。每个关键步骤都会征求你的同意。

## 工作原理

1. **拉取官方白名单**：从 `api.github.com/meta` 获取 GitHub 公布的可信 IP 网段
2. **DNS 可信校验**：解析出的 IP 必须先通过官方白名单校验，防止 DNS 污染引入恶意 IP
3. **Ping 测试**：对可信 IP 进行延迟测试，挑选当前网络环境下最优的节点
4. **安全合并**：AI 读取你的系统 hosts 文件，仅替换旧的 GitHub 块，保留 Docker、VPN、公司内网等其他条目
5. **备份与验证**：写入前自动创建带时间戳的备份，写入后再次读取验证完整性

## 注意事项

- **管理员权限**：修改系统 hosts 文件需要管理员权限
- **自动备份**：每次写入前都会生成 `hosts.bak.时间戳` 备份，出问题可一键恢复
- **hosts 的边界**：hosts 只能解决 DNS 污染导致的访问问题，无法绕过 HTTPS/SNI 等协议层封锁。如果所有 GitHub IP 均不可达，建议配合使用代理或 VPN
