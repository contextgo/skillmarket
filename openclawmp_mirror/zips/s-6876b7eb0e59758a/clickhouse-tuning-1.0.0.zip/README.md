# ClickHouse 性能调优

## 引擎选择
- MergeTree：通用
- ReplacingMergeTree：去重
- SummingMergeTree：预聚合
- AggregatingMergeTree：复杂聚合

## 分区
PARTITION BY toYYYYMM(date) -- 按月
不要按高基数列分区

## 索引
ORDER BY (date, user_id, type) -- 主键=排序键
ALTER ADD INDEX ... TYPE bloom_filter -- 二级索引

## 查询优化
- PREWHERE 减少读取
- 物化视图预聚合
- GROUP BY 低基数列
- 避免 SELECT *

## 配置
max_memory_usage: 80%
max_threads: 8