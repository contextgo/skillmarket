# Compact Engineering Checklists

## DEFINE
- User goal clear?
- Constraints and non-goals known?
- Acceptance criteria testable?

## PLAN
- Tasks are small and ordered?
- Risky files/paths identified?
- Verification chosen before coding?

## BUILD
- Follow project conventions?
- Minimal diff?
- No unrelated cleanup?

## VERIFY
- Tests/lint/build run where possible?
- Manual inspection for docs/config?
- Failure cause recorded if blocked?

## REVIEW
- Correctness edge cases considered?
- Security: auth, secrets, injection, permissions?
- Performance: avoid avoidable N+1, heavy loops, large context waste?
- Maintainability: names, structure, docs, duplication?

## SHIP
- Changed files listed?
- Evidence included?
- Remaining risks/follow-ups named?
- Rollback path obvious for risky changes?
