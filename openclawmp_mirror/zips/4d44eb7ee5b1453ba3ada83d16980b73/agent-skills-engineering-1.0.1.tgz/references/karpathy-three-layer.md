# Karpathy Three-Layer Organization for AgentSkills

Use this when saving AgentSkills knowledge into the personal wiki.

## Layer 1: Facts / Knowledge

Stable concepts worth remembering:

- AI agents need explicit engineering process because they tend to optimize for the shortest path.
- Production software work is a lifecycle: DEFINE → PLAN → BUILD → VERIFY → REVIEW → SHIP.
- Skills should use progressive disclosure: short trigger metadata, concise core instructions, references loaded only when needed.
- Good agent workflows require evidence, not claims: tests, lint, build, logs, screenshots, inspection.

## Layer 2: Skills / Procedures

Reusable procedures:

1. Convert fuzzy request into spec and acceptance criteria.
2. Break work into reversible tasks.
3. Implement incrementally.
4. Verify with the cheapest meaningful test first, then stronger checks if risk demands.
5. Review for correctness/security/performance/maintainability.
6. Ship with summary, evidence, risks, and rollback/follow-up.

## Layer 3: Products / Outputs

Concrete assets that can be produced from the knowledge:

- OpenClaw engineering controller skill.
- Code review SOP.
- AI coding agent task template.
- Release checklist.
- 小红书/公众号内容: “AI Agent 为什么需要工程纪律”.
- Team workflow: PM/Architect/Coder/Auditor/Monitor chain.
