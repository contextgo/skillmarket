# AgentSkills Lifecycle Map

Source: https://github.com/addyosmani/agent-skills

## Positioning

AgentSkills is a production engineering workflow library for AI coding agents. Its value is not a single trick; it forces agents to follow the same lifecycle a senior engineer would use before shipping real software.

## Lifecycle mapping

| Stage | Goal | Representative upstream skills |
|---|---|---|
| DEFINE | Turn vague request into scope and acceptance criteria | idea-refine, spec-driven-development |
| PLAN | Decompose work and pick verification strategy | planning-and-task-breakdown |
| BUILD | Implement in small safe increments | incremental-implementation, api-and-interface-design, frontend-ui-engineering, context-engineering, source-driven-development |
| VERIFY | Prove behavior | test-driven-development, browser-testing-with-devtools, debugging-and-error-recovery |
| REVIEW | Catch quality and risk issues | code-review-and-quality, security-and-hardening, performance-optimization, code-simplification |
| SHIP | Package, version, document, release | git-workflow-and-versioning, ci-cd-and-automation, documentation-and-adrs, shipping-and-launch, deprecation-and-migration |

## Upstream skill inventory

- `api-and-interface-design`: Guides stable API and interface design. Use when designing APIs, module boundaries, or any public interface. Use when creating REST or GraphQL endpoints, defining type contracts between modules, or establishing boundaries between frontend a
- `browser-testing-with-devtools`: Tests in real browsers. Use when building or debugging anything that runs in a browser. Use when you need to inspect the DOM, capture console errors, analyze network requests, profile performance, or verify visual output with real runtime d
- `ci-cd-and-automation`: Automates CI/CD pipeline setup. Use when setting up or modifying build and deployment pipelines. Use when you need to automate quality gates, configure test runners in CI, or establish deployment strategies.
- `code-review-and-quality`: Conducts multi-axis code review. Use before merging any change. Use when reviewing code written by yourself, another agent, or a human. Use when you need to assess code quality across multiple dimensions before it enters the main branch.
- `code-simplification`: Simplifies code for clarity. Use when refactoring code for clarity without changing behavior. Use when code works but is harder to read, maintain, or extend than it should be. Use when reviewing code that has accumulated unnecessary complex
- `context-engineering`: Optimizes agent context setup. Use when starting a new session, when agent output quality degrades, when switching between tasks, or when you need to configure rules files and context for a project.
- `debugging-and-error-recovery`: Guides systematic root-cause debugging. Use when tests fail, builds break, behavior doesn't match expectations, or you encounter any unexpected error. Use when you need a systematic approach to finding and fixing the root cause rather than 
- `deprecation-and-migration`: Manages deprecation and migration. Use when removing old systems, APIs, or features. Use when migrating users from one implementation to another. Use when deciding whether to maintain or sunset existing code.
- `documentation-and-adrs`: Records decisions and documentation. Use when making architectural decisions, changing public APIs, shipping features, or when you need to record context that future engineers and agents will need to understand the codebase.
- `frontend-ui-engineering`: Builds production-quality UIs. Use when building or modifying user-facing interfaces. Use when creating components, implementing layouts, managing state, or when the output needs to look and feel production-quality rather than AI-generated.
- `git-workflow-and-versioning`: Structures git workflow practices. Use when making any code change. Use when committing, branching, resolving conflicts, or when you need to organize work across multiple parallel streams.
- `idea-refine`: Refines ideas iteratively. Refine ideas through structured divergent and convergent thinking. Use "idea-refine" or "ideate" to trigger.
- `incremental-implementation`: Delivers changes incrementally. Use when implementing any feature or change that touches more than one file. Use when you're about to write a large amount of code at once, or when a task feels too big to land in one step.
- `performance-optimization`: Optimizes application performance. Use when performance requirements exist, when you suspect performance regressions, or when Core Web Vitals or load times need improvement. Use when profiling reveals bottlenecks that need fixing.
- `planning-and-task-breakdown`: Breaks work into ordered tasks. Use when you have a spec or clear requirements and need to break work into implementable tasks. Use when a task feels too large to start, when you need to estimate scope, or when parallel work is possible.
- `security-and-hardening`: Hardens code against vulnerabilities. Use when handling user input, authentication, data storage, or external integrations. Use when building any feature that accepts untrusted data, manages user sessions, or interacts with third-party serv
- `shipping-and-launch`: Prepares production launches. Use when preparing to deploy to production. Use when you need a pre-launch checklist, when setting up monitoring, when planning a staged rollout, or when you need a rollback strategy.
- `source-driven-development`: Grounds every implementation decision in official documentation. Use when you want authoritative, source-cited code free from outdated patterns. Use when building with any framework or library where correctness matters.
- `spec-driven-development`: Creates specs before coding. Use when starting a new project, feature, or significant change and no specification exists yet. Use when requirements are unclear, ambiguous, or only exist as a vague idea.
- `test-driven-development`: Drives development with tests. Use when implementing any logic, fixing any bug, or changing any behavior. Use when you need to prove that code works, when a bug report arrives, or when you're about to modify existing functionality.
- `using-agent-skills`: Discovers and invokes agent skills. Use when starting a session or when you need to discover which skill applies to the current task. This is the meta-skill that governs how all other skills are discovered and invoked.