---
name: agent-skills-engineering
description: Engineering discipline controller adapted from addyosmani/agent-skills. Use for AI coding agent workflows, spec-driven development, planning, TDD, incremental implementation, code review, security/performance/accessibility checks, shipping readiness, and production-quality software delivery. 触发词：AgentSkills、工程规范、DEFINE PLAN BUILD VERIFY REVIEW SHIP、spec、plan、build、test、review、ship、代码质量、发布检查。
---

# AgentSkills Engineering

Use this skill when a software task needs production-grade engineering discipline rather than quick patching.

## Core lifecycle

Run the smallest useful loop through:

```text
DEFINE → PLAN → BUILD → VERIFY → REVIEW → SHIP
```

- **DEFINE**: clarify intent, constraints, success criteria, non-goals.
- **PLAN**: break into verifiable tasks, identify risks, choose tests.
- **BUILD**: implement incrementally; prefer small reversible changes.
- **VERIFY**: run tests/lint/build/manual checks appropriate to the change.
- **REVIEW**: inspect correctness, security, performance, maintainability.
- **SHIP**: summarize changes, evidence, risks, rollback/follow-ups.

## Operating rules

1. Do not skip DEFINE for ambiguous work.
2. Do not skip VERIFY for code/config changes unless blocked; name the blocker.
3. Prefer existing project conventions over generic patterns.
4. Keep changes small; avoid rewrites unless the plan justifies them.
5. Use sub-agents for long/complex implementation, review, or verification.
6. Final answer must include evidence: tests, build/lint, file inspection, or blocker.

## When to read references

- Read `references/lifecycle-map.md` for the full skill map and which AgentSkills module applies.
- Read `references/karpathy-three-layer.md` when turning engineering knowledge into user wiki notes: facts/skills/products.
- Read `references/checklists.md` for compact review, security, performance, accessibility, and shipping checklists.

## OpenClaw adaptation

This is a curated controller skill, not a raw mirror of the upstream repository. The upstream repo contains many individual skills; in OpenClaw, this skill coordinates the lifecycle to avoid skill-list bloat and duplicate triggers.
