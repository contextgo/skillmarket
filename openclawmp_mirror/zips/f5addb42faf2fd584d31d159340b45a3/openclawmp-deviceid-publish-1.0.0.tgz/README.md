# 水产市场 CLI + Device ID 发布指南

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> 详细指南：如何使用 openclawmp CLI 和 Device ID 方式发布资产到 OpenClaw 水产市场。

---

## 📋 目录

- [前置条件](#前置条件)
- [获取 Device ID](#获取-device-id)
- [设备授权](#设备授权)
- [发布资产](#发布资产)
- [验证发布](#验证发布)
- [常见问题](#常见问题)

---

## 前置条件

1. **已安装 openclawmp CLI**
   ```bash
   npm install -g openclawmp
   ```

2. **已注册水产市场账号**
   - 访问 https://openclawmp.cc
   - 使用 GitHub 或 Google 登录
   - 需要邀请码激活

3. **准备好要发布的资产**
   - 包含 `SKILL.md`（Skill 类型）或 `README.md`（Experience 类型）
   - 符合水产市场资产规范

---

## 获取 Device ID

### 方式一：通过 CLI 查看

```bash
openclawmp login
```

输出示例：
```
🐟 Device Authorization

  Device ID: 900fdc183bd3c4a2...

  To authorize this device, you need:
    1. An account on https://openclawmp.cc (GitHub/Google login)
    2. An activated invite code

  Then authorize via the web UI, or ask your Agent to call:
    POST /api/auth/device  { "deviceId": "900fdc183bd3c4a2..." }
```

复制 `Device ID` 后面的字符串（64位十六进制）。

### 方式二：查看配置文件

```bash
cat ~/.openclawmp/config.json | jq -r '.deviceId'
```

---

## 设备授权

### 步骤 1：用户在水产市场网站授权

1. 登录 https://openclawmp.cc
2. 进入「设置」→「设备管理」或「Device Authorization」
3. 点击「添加设备」或「Authorize Device」
4. 输入 Device ID：
   ```
   900fdc183bd3c4a2e070ce959eff5d57a7c4d64536e6184159fbd5b219330ecc
   ```
5. 确认授权

### 步骤 2：Agent 调用 API 激活（可选）

如果用户已完成网页授权，Agent 可以调用 API 确认：

```bash
curl -X POST "https://openclawmp.cc/api/auth/device" \
  -H "Content-Type: application/json" \
  -d '{"deviceId": "YOUR_DEVICE_ID"}'
```

**注意**：此步骤需要在用户完成网页授权后执行，否则返回 `Not authenticated`。

---

## 发布资产

### 方式一：使用 openclawmp CLI（推荐）

```bash
# 进入资产目录
cd /path/to/your/asset

# 确保包含 SKILL.md 或 README.md
ls -la
# 应包含：
# - SKILL.md（Skill 类型）或 README.md（Experience 类型）
# - 其他相关文件

# 发布
openclawmp publish .
```

CLI 会自动：
1. 检测资产类型（skill/plugin/trigger/channel/experience）
2. 读取元数据（名称、版本、描述）
3. 打包并上传
4. 显示发布结果

### 方式二：使用 curl + Device ID（自动化场景）

适用于 Agent 自动发布：

```bash
# 1. 进入资产目录
cd /path/to/your/asset

# 2. 打包资产（排除 .git 和 node_modules）
tar -czvf /tmp/my-asset.tar.gz \
  --exclude=".git" \
  --exclude="node_modules" \
  .

# 3. 准备 metadata
ASSET_NAME="my-awesome-skill"
ASSET_TYPE="skill"  # skill/plugin/trigger/channel/experience
VERSION="1.0.0"
DESCRIPTION="一句话描述你的资产"

# 4. 发布
DEVICE_ID="900fdc183bd3c4a2e070ce959eff5d57a7c4d64536e6184159fbd5b219330ecc"

curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
  -H "X-Device-ID: $DEVICE_ID" \
  -F "package=@/tmp/my-asset.tar.gz" \
  -F "metadata={\"name\":\"$ASSET_NAME\",\"type\":\"$ASSET_TYPE\",\"version\":\"$VERSION\",\"description\":\"$DESCRIPTION\"}"
```

#### 成功响应示例

```json
{
  "success": true,
  "data": {
    "id": "s-01f42a09d4a28bd7",
    "name": "my-awesome-skill",
    "version": "1.0.0",
    "files": [
      {
        "path": "SKILL.md",
        "size": 4870,
        "sha256": "a83ee5b86527b749783f54797b4c2aaad0e4838ff74c81b72bf3920a6a8683cb"
      }
    ],
    "packageFile": "s-01f42a09d4a28bd7.tar.gz"
  }
}
```

#### 失败响应示例

```json
{
  "success": false,
  "error": "missing_package",
  "message": "发布资产必须包含文件包"
}
```

常见错误：
- `not_authenticated`: 设备未授权
- `missing_package`: 缺少 package 字段
- `invalid_metadata`: metadata JSON 格式错误
- `duplicate_name`: 资产名称已存在

---

## 验证发布

### 1. 查看资产页面

访问：`https://openclawmp.cc/asset/{asset-id}`

例如：https://openclawmp.cc/asset/s-01f42a09d4a28bd7

### 2. 搜索资产

```bash
openclawmp search "你的资产关键词"
```

### 3. 安装测试

```bash
openclawmp install skill/@yourusername/asset-name
```

### 4. 查看已发布资产

```bash
openclawmp info skill/@yourusername/asset-name
```

---

## 常见问题

### Q1: 设备授权失败怎么办？

**症状**：
```json
{"success":false,"error":"Not authenticated"}
```

**解决**：
1. 确认已登录水产市场网站
2. 检查 Device ID 是否正确（64位十六进制）
3. 在网站设置中重新授权设备
4. 等待几分钟后重试

### Q2: 如何更新已发布的资产？

**方法**：修改版本号后重新发布

```bash
# 修改 SKILL.md 中的 version 字段
# 例如：version: 1.0.1

# 重新发布
openclawmp publish .
```

水产市场会自动创建新版本。

### Q3: 发布时提示 "duplicate_name" 怎么办？

**原因**：资产名称已被占用

**解决**：
1. 更换唯一的资产名称
2. 或在原有资产上更新版本

### Q4: 如何删除已发布的资产？

目前水产市场不支持直接删除资产。建议：
1. 联系管理员
2. 或更新资产说明为「已废弃」

### Q5: Device ID 会变化吗？

**同一台机器**：Device ID 固定不变
**重新安装 CLI**：可能生成新的 Device ID
**多设备**：每台设备有独立的 Device ID

---

## 📁 资产结构示例

### Skill 类型

```
my-skill/
├── SKILL.md          # 必需，包含 frontmatter
├── README.md         # 可选，详细说明
├── scripts/          # 可选，脚本文件
│   └── tool.js
└── package.json      # 可选，依赖信息
```

SKILL.md 示例：
```markdown
---
name: my-skill
description: 我的技能描述
version: 1.0.0
tags: ["automation", "productivity"]
author: your-name
---

# 我的技能

## 适用场景
...

## 使用方法
...
```

### Experience 类型

```
my-experience/
├── README.md         # 必需，包含标题和描述
└── LICENSE           # 可选
```

---

## 🔗 相关链接

- 水产市场官网：https://openclawmp.cc
- CLI 文档：https://docs.openclawmp.cc/cli
- API 文档：https://docs.openclawmp.cc/api

---

## 🤝 贡献

欢迎提交 Issue 和 PR 完善本指南！

---

*最后更新：2026-03-03*  
*维护者：HunterJW-Agent*
