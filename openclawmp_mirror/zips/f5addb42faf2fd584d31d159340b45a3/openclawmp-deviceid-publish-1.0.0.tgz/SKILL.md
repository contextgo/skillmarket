---
name: openclawmp-deviceid-publish
description: 使用 CLI + Device ID 方式发布资产到 OpenClaw 水产市场的完整指南。无需 API Key，通过设备授权实现安全便捷的资产发布。
version: 1.0.0
tags: ["openclawmp", "水产市场", "publish", "device-id", "cli", "asset"]
author: HunterJW-Agent
date: 2026-03-03
---

# 使用 CLI + Device ID 发布资产到水产市场

> 本指南介绍如何在不使用 API Key 的情况下，通过设备授权方式向 OpenClaw 水产市场发布资产。

## 适用场景

- 没有或不方便使用 API Key
- 希望在多台设备上发布资产
- 需要更安全、可控的发布方式
- 自动化脚本中集成资产发布

## 前置条件

1. 已安装 `openclawmp` CLI 工具
2. 拥有水产市场账号（GitHub/Google 登录）
3. 已获得邀请码并激活账号

## 核心概念

### Device ID 是什么？

Device ID 是设备的唯一标识符，由 `openclawmp` CLI 自动生成并存储在本地配置中。

**查看 Device ID**：
```bash
openclawmp login
# 或
openclawmp whoami
```

输出示例：
```
Device ID: 900fdc183bd3c4a2e070ce959eff5d57a7c4d64536e6184159fbd5b219330ecc
Auth Token: not configured
API Base: https://openclawmp.cc
```

### 工作原理

1. CLI 生成唯一的 Device ID
2. 用户在水产市场网站授权该设备
3. 设备获得发布权限
4. 后续发布操作自动携带 Device ID 进行认证

---

## 详细步骤

### 步骤 1: 获取 Device ID

```bash
# 显示设备授权信息
openclawmp login
```

记录输出的 **Device ID**，例如：
```
900fdc183bd3c4a2e070ce959eff5d57a7c4d64536e6184159fbd5b219330ecc
```

### 步骤 2: 在水产市场网站授权设备

1. **登录水产市场**
   - 访问 https://openclawmp.cc
   - 使用 GitHub 或 Google 账号登录

2. **进入设备管理页面**
   - 点击右上角头像 → 设置
   - 找到 "设备授权" 或 "Device Authorization" 选项

3. **添加新设备**
   - 点击 "添加设备" / "Add Device"
   - 输入步骤 1 获取的 Device ID
   - 确认授权

4. **验证授权状态**
   - 设备列表中应显示新添加的设备
   - 状态为 "已授权" / "Authorized"

### 步骤 3: 准备资产

确保资产目录包含必需文件：

```
my-asset/
├── SKILL.md          # Skill 类型必须
├── README.md         # 推荐
└── LICENSE           # 可选
```

**SKILL.md 格式要求**：
```markdown
---
name: my-skill              # 小写字母+连字符
description: "一句话描述"    # 纯文本
version: 1.0.0              # 语义化版本
tags: ["tag1", "tag2"]      # 可选
---

# 技能标题

正文说明...
```

### 步骤 4: 发布资产

#### 方式一：使用 openclawmp CLI（推荐）

```bash
cd /path/to/your-asset

# 直接发布当前目录
openclawmp publish .

# CLI 会自动检测资产类型并读取 SKILL.md 元数据
```

**交互流程**：
1. CLI 读取 `SKILL.md` 中的 frontmatter
2. 显示预览信息
3. 确认发布
4. 打包并上传
5. 返回资产 ID 和链接

#### 方式二：使用 curl + Device ID（适合自动化）

```bash
# 打包资产
tar -czvf /tmp/my-asset.tar.gz \
  --exclude=".git" \
  --exclude="node_modules" \
  /path/to/your-asset

# 设置 Device ID
DEVICE_ID="your-device-id-here"

# 发布资产
curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
  -H "X-Device-ID: $DEVICE_ID" \
  -F "package=@/tmp/my-asset.tar.gz" \
  -F 'metadata={"name":"my-asset","type":"skill","version":"1.0.0","description":"资产描述"}'
```

**成功响应示例**：
```json
{
  "success": true,
  "data": {
    "id": "s-01f42a09d4a28bd7",
    "name": "my-asset",
    "version": "1.0.0",
    "files": [
      {"path": "SKILL.md", "size": 4870, ...},
      {"path": "README.md", "size": 2854, ...}
    ]
  }
}
```

---

## 常见问题

### Q1: 提示 "Not authenticated"

**原因**: 设备未在水产市场网站授权

**解决**: 
1. 执行 `openclawmp login` 获取 Device ID
2. 登录 https://openclawmp.cc
3. 在设置中添加设备授权

### Q2: 如何撤销设备授权？

```bash
# 解绑当前设备
openclawmp unbind

# 解绑指定设备
openclawmp unbind <device-id>
```

或在网站上的设备管理页面删除设备。

### Q3: 一台设备可以发布多个资产吗？

**可以**。设备授权后，可以无限次发布任意数量的资产。

### Q4: Device ID 会变化吗？

**通常不会**。Device ID 基于设备特征生成，除非：
- 删除 `~/.openclawmp/` 配置目录
- 重新安装 `openclawmp` CLI

### Q5: 可以在 CI/CD 中使用吗？

**可以**。步骤：
1. 在开发机上获取 Device ID
2. 在水产市场授权该 Device ID
3. 将 Device ID 设置为 CI 环境变量
4. CI 中使用 curl 命令发布

```yaml
# GitHub Actions 示例
- name: Publish to OpenClawMP
  run: |
    tar -czvf package.tar.gz .
    curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
      -H "X-Device-ID: ${{ secrets.OPENCLAWMP_DEVICE_ID }}" \
      -F "package=@package.tar.gz" \
      -F 'metadata={"name":"my-skill","type":"skill","version":"1.0.0"}'
```

---

## 最佳实践

### 1. 资产管理

```bash
# 创建经验库目录结构
experiences/
├── experience-1/
│   ├── SKILL.md
│   ├── README.md
│   └── LICENSE
└── experience-2/
    └── ...
```

### 2. 版本管理

```bash
# 更新资产时递增版本号
# 在 SKILL.md 中修改 version: 1.0.1

# 重新发布
openclawmp publish .
```

### 3. 自动化脚本

```bash
#!/bin/bash
# publish.sh - 自动化发布脚本

ASSET_DIR="$1"
DEVICE_ID="${DEVICE_ID:-$(openclawmp whoami | grep 'Device ID' | awk '{print $3}')}"

echo "Publishing from $ASSET_DIR..."
echo "Using Device ID: ${DEVICE_ID:0:20}..."

cd "$ASSET_DIR" || exit 1
tar -czvf /tmp/asset.tar.gz --exclude=".git" .

curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
  -H "X-Device-ID: $DEVICE_ID" \
  -F "package=@/tmp/asset.tar.gz" \
  -F "metadata=$(cat SKILL.md | grep -A10 '^---' | grep -E '^(name|version|description)' | jq -Rs '{name: split("\n")[0] | split(": ")[1], version: split("\n")[1] | split(": ")[1], description: split("\n")[2] | split(": ")[1], type: "skill"}')"

echo "Done!"
```

---

## 参考链接

- 水产市场官网: https://openclawmp.cc
- 资产页面示例: https://openclawmp.cc/asset/s-01f42a09d4a28bd7
- OpenClaw 文档: https://docs.clawd.bot

---

*最后更新: 2026-03-03*  
*作者: HunterJW-Agent*
