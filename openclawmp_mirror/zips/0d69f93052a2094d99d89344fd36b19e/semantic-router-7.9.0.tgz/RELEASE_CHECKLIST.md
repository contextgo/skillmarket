# Semantic Router v7.9.0 发布检查清单

## ✅ 版本信息
- [x] 版本号统一为 7.9.0
- [x] clawhub.yaml 版本号：7.9.0
- [x] SKILL.md 版本号：7.9.0
- [x] changelog 添加 7.9.0 条目

## ✅ 文档完整性
- [x] SKILL.md - 主文档
- [x] QUICKSTART.md - 5分钟快速配置指南
- [x] CONFIGURATION_GUIDE.md - 完整配置指南（6个常见坑）
- [x] README_v7.6.3.md - 完整部署指南
- [x] clawhub.yaml - 水产市场元数据

## ✅ 配置文件
- [x] config/pools.json - 三池模型配置模板
- [x] config/tasks.json - 任务类型定义
- [x] scripts/semantic_check.py - 核心检测脚本
- [x] scripts/setup_wizard.py - 配置向导

## ✅ URL 和路径
- [x] homepage: https://openclawmp.cc
- [x] repository: https://openclawmp.cc
- [x] 安装路径：~/.openclaw/skills/semantic-router/
- [x] 命令格式：openclaw market install / openclaw cron

## ✅ 依赖声明
- [x] Python 3.9+
- [x] sentence-transformers >= 2.0.0
- [x] numpy >= 1.21.0
- [x] OpenClaw >= 0.12.0

## ✅ 权限声明
- [x] read_config
- [x] write_config
- [x] manage_cron
- [x] access_logs
- [x] execute_scripts

## 📦 打包准备

### 需要包含的文件
```
semantic-router/
├── SKILL.md
├── QUICKSTART.md
├── README_v7.6.3.md
├── clawhub.yaml
├── config/
│   ├── pools.json
│   └── tasks.json
├── scripts/
│   ├── semantic_check.py
│   └── setup_wizard.py
└── references/
    └── (参考文档)
```

### 排除的文件
- .git/
- __pycache__/
- *.pyc
- .DS_Store
- 测试文件

## 🚀 发布步骤

1. 确认所有检查项通过
2. 打包技能目录
3. 上传到水产市场
4. 测试安装流程
5. 发布公告

## 📝 发布说明模板

```
# Semantic Router v7.9.0 发布

## 新特性
- 生产就绪版本，完整文档
- 新增 QUICKSTART.md 5分钟快速配置指南
- 统一版本号和命令格式

## 改进
- 更新安装路径为标准 skill 目录
- 修正所有命令为 OpenClaw CLI 格式
- 优化文档结构

## 核心功能
- 四层识别：系统过滤→关键词→指示词→语义相似度
- 三池架构：Intelligence/Highspeed/Humanities
- 五分支路由：A/B/B+/C/C-auto
- 全自动 Fallback 回路

## 安装
openclaw market install semantic-router

## 文档
- 快速开始：QUICKSTART.md
- 完整指南：README_v7.6.3.md
```

---

**检查完成时间**: 2026-03-06
**发布状态**: ✅ 准备就绪
