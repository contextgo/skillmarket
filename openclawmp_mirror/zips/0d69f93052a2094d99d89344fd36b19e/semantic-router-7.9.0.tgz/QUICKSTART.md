# Semantic Router 快速开始指南

> 5分钟配置自动模型路由

## 🎯 核心功能

根据对话内容自动选择最合适的模型：
- **开发任务** → Intelligence池（opus/coder）
- **信息查询** → Highspeed池（haiku/flash）
- **内容创作** → Humanities池（sonnet/plus）

---

## ⚡ 快速配置（3步）

### 1. 配置三池模型

编辑 `~/.openclaw/workspace/.lib/pools.json`：

```json
{
  "Intelligence": {
    "name": "智能池",
    "description": "开发、编程、复杂任务",
    "primary": "your-provider/claude-opus-4-6",
    "fallback_1": "qianwen/qwen3-coder-plus"
  },
  "Highspeed": {
    "name": "高速池",
    "description": "查询、检索、快速响应",
    "primary": "your-provider/claude-haiku-4-5",
    "fallback_1": "qianwen/qwen3-max"
  },
  "Humanities": {
    "name": "人文池",
    "description": "写作、翻译、内容生成",
    "primary": "your-provider/claude-sonnet-4-6",
    "fallback_1": "qianwen/qwen3.5-plus"
  }
}
```

### 2. 启用自动路由

```bash
openclaw config set hooks.internal.entries.semantic-router-auto.enabled true
```

### 3. 重启验证

```bash
openclaw gateway restart
```

---

## 🧪 测试验证

发送以下消息测试自动切换：

```
# 测试1：切换到Humanities池
帮我写一篇关于春天的散文

# 测试2：切换到Highspeed池
查一下iPhone 16的价格

# 测试3：切换到Intelligence池
帮我写一个Python脚本，实现文件批量重命名
```

查看日志确认：
```bash
tail -f ~/.openclaw/workspace/.lib/semantic_check.log
```

---

## ⚠️ 常见问题

### 问题1：模型不自动切换

**原因**：Hook未启用

**解决**：
```bash
openclaw config set hooks.internal.entries.semantic-router-auto.enabled true
openclaw gateway restart
```

### 问题2：切换后卡住不响应

**原因**：模型ID配置错误

**解决**：检查 `pools.json` 中的模型ID格式：
```
供应商名/模型名
```

### 问题3：B+分支不切换模型

**说明**：这是设计特性，不是bug

- **B分支**：高关联度（≥0.55），延续当前模型
- **B+分支**：中关联度（0.35~0.55），延续但警告话题漂移
- **C分支**：新任务关键词，切换模型
- **C-auto分支**：低关联度（<0.35），自动切换+清空会话

---

## 📋 完整配置指南

详细配置步骤和踩坑经验，请参考：
- `README_v7.6.3.md` - 完整文档
- `~/.openclaw/semantic-router配置指南.md` - 实战经验

---

## 💡 最佳实践

1. **Fallback策略**：不同供应商互为备用
2. **模型选择**：primary用主力，fallback用备用供应商
3. **日志监控**：定期检查 `semantic_check.log`
4. **不要修改**：不要改技能核心代码，只改配置文件

---

**配置完成后，semantic-router会自动工作，无需手动切换模型！**
