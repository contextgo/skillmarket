# Semantic Router 配置指南

> 让OpenClaw根据对话内容自动选择最合适的模型

## 📋 概述

semantic-router是OpenClaw的一个技能，能够：
- 自动识别任务类型（开发/查询/创作）
- 自动切换到最合适的模型
- 无需手动切换，完全自动化

**三池架构：**
- **Intelligence池**（智能池）：开发、编程、复杂任务 → opus
- **Highspeed池**（高速池）：查询、检索、信息搜索 → haiku
- **Humanities池**（人文池）：内容生成、翻译、写作 → sonnet

---

## ✅ 前置条件

1. OpenClaw >= 0.12.0
2. Python 3.9+
3. semantic-router技能已安装在 `~/.openclaw/skills/semantic-router/`
4. 已配置多个模型供应商（建议Claude + qianwen等）

---

## 🚀 配置步骤

### 第一步：配置三池模型

编辑 `~/.openclaw/workspace/.lib/pools.json`：

```json
{
  "Intelligence": {
    "name": "智能池",
    "description": "开发、自动化、系统运维",
    "primary": "your-provider/claude-opus-4-6",
    "fallback_1": "qianwen/qwen3-coder-plus",
    "fallback_2": "qianwen/deepseek-chat",
    "fallback_3": "qianwen/glm-5"
  },
  "Highspeed": {
    "name": "高速池",
    "description": "信息检索、网页搜索、协调沟通",
    "primary": "your-provider/claude-haiku-4-5",
    "fallback_1": "qianwen/qwen3-max-2026-01-23",
    "fallback_2": "qianwen/deepseek-chat",
    "fallback_3": "qianwen/glm-4.7"
  },
  "Humanities": {
    "name": "人文池",
    "description": "内容生成、问答、培训、多模态识别",
    "primary": "your-provider/claude-sonnet-4-6",
    "fallback_1": "qianwen/qwen3.5-plus",
    "fallback_2": "qianwen/deepseek-chat",
    "fallback_3": "qianwen/glm-4.7"
  },
  "version": "7.7.1"
}
```

**配置原则：**
- primary使用主力模型（Claude）
- fallback_1使用不同供应商的模型（避免单点故障）
- 确保所有模型ID正确且可用

### 第二步：配置任务类型

`~/.openclaw/workspace/.lib/tasks.json` 已由技能提供，通常无需修改。

关键任务类型：
- `development` → Intelligence池（关键词：写代码、编程、bug等）
- `info_retrieval` → Highspeed池（关键词：查一下、查询、价格等）
- `content_generation` → Humanities池（关键词：写作、散文、翻译等）

### 第三步：启用semantic-router hook

运行命令启用：

```bash
openclaw config set hooks.internal.entries.semantic-router-auto.enabled true
```

### 第四步：创建hook脚本

创建 `~/.openclaw/workspace/scripts/semantic_router_hook.sh`：

```bash
#!/bin/bash
USER_INPUT="$1"
CURRENT_POOL="${2:-Intelligence}"

RESULT=$(~/.openclaw/venv/bin/python3 \
  ~/.openclaw/skills/semantic-router/scripts/semantic_check.py \
  "$USER_INPUT" \
  "$CURRENT_POOL" \
  -e 2>/dev/null)

echo "$RESULT" | jq -r '.declaration // empty'
exit 0
```

赋予执行权限：
```bash
chmod +x ~/.openclaw/workspace/scripts/semantic_router_hook.sh
```

### 第五步：修改hook触发时机

编辑 `~/.openclaw/workspace/.kiro/hooks/semantic-router-auto.json`：

```json
{
  "name": "semantic-router-auto",
  "description": "自动语义路由 - 根据消息内容自动切换模型池",
  "trigger": "before_agent_start",
  "enabled": true,
  "action": {
    "type": "shell",
    "command": "~/.openclaw/workspace/scripts/semantic_router_hook.sh",
    "args": ["{message}", "Intelligence"]
  }
}
```

**关键点：**
- `trigger` 必须是 `before_agent_start`（不是 `on_message`）
- `enabled` 必须是 `true`

### 第六步：重启gateway验证

```bash
openclaw gateway restart
```

等待gateway重启完成后，测试自动切换功能。

---

## ⚠️ 关键问题排查（我们踩过的坑）

### 坑1：Hook默认是disabled的 ⭐⭐⭐⭐⭐

**症状：** 配置完成后，模型从不自动切换

**原因：** semantic-router的内置hook默认是禁用状态

**解决：**
```bash
openclaw config set hooks.internal.entries.semantic-router-auto.enabled true
```

**验证：** 检查 `~/.openclaw/openclaw.json` 中：
```json
{
  "hooks": {
    "internal": {
      "entries": {
        "semantic-router-auto": {
          "enabled": true
        }
      }
    }
  }
}
```

### 坑2：参数错误导致不执行切换 ⭐⭐⭐⭐

**症状：** 日志显示 `auto_executed: false`

**原因：** `semantic_check.py` 需要用 `-e` 参数，不是 `--execute`

**错误写法：**
```bash
semantic_check.py "$USER_INPUT" "$CURRENT_POOL" --execute
```

**正确写法：**
```bash
semantic_check.py "$USER_INPUT" "$CURRENT_POOL" -e
```

### 坑3：Hook触发时机错误 ⭐⭐⭐⭐

**症状：** 模型切换了，但agent已经开始用旧模型处理

**原因：** Hook trigger设置为 `on_message`，太晚了

**错误配置：**
```json
{
  "trigger": "on_message"
}
```

**正确配置：**
```json
{
  "trigger": "before_agent_start"
}
```

### 坑4：尝试用Plugin实现（完全不work）⭐⭐⭐

**错误思路：** 创建 `~/.openclaw/extensions/semantic-router/` 插件

**问题：** Plugin注册的hooks从未触发过，OpenClaw的plugin机制不适合这个场景

**正确方案：** 使用semantic-router技能自带的内置hook机制

### 坑5：创建standalone hooks导致streaming卡死 ⭐⭐⭐

**错误思路：** 在 `~/.openclaw/hooks/semantic-router-message/` 创建独立hook

**症状：** Agent回复后，UI一直显示streaming状态

**正确方案：** 不要创建standalone hooks，使用技能内置的hook配置

### 坑6：误以为B+分支是bug ⭐⭐

**现象：** 在对话中提出开发任务，但模型没有切换到opus

**原因：** B+分支是"延续但警告话题漂移"，设计上不切换模型（保持会话连续性）

**理解：** 这不是bug，是semantic-router的设计特性
- B分支：高关联度（≥0.55），延续当前模型
- B+分支：中关联度（0.35~0.55），延续但警告
- C分支：新任务关键词，切换模型但不清空会话
- C-auto分支：低关联度（<0.35），自动/new + 切换模型

### 坑7：semantic_check 不能正确执行 /new 会话 ⭐⭐⭐⭐

**症状：** C-auto 分支应该清空会话，但实际上会话历史没有清空

**原因：** `semantic_check.py` 的 `-e` 参数只能切换模型，无法执行 `/new` 命令

**当前限制：** 
- ✅ 可以自动切换模型池
- ❌ 无法自动清空会话历史
- C-auto 分支的 `/new` 功能目前不可用

**临时方案：** 
- 用户需要手动输入 `/new` 来清空会话
- 或者依赖 B/C 分支（不清空会话，只切换模型）

**未来改进方向：**
- 需要 OpenClaw 提供会话管理 API
- 或者通过 hook 机制支持执行 slash 命令

---

## 🧪 测试验证

### 测试1：切换到Humanities池（sonnet）

发送消息：
```
帮我写一篇关于春天的散文
```

**预期结果：**
- 日志显示切换到 `claude-sonnet-4-6`
- Agent回复确认当前使用sonnet模型

### 测试2：切换到Highspeed池（haiku）

发送消息：
```
查一下iPhone 16的价格
```

**预期结果：**
- 日志显示切换到 `claude-haiku-4-5`
- Agent回复确认当前使用haiku模型

### 测试3：切换到Intelligence池（opus）

发送消息：
```
帮我写一个Python脚本，实现文件批量重命名
```

**预期结果：**
- 日志显示切换到 `claude-opus-4-6`
- Agent回复确认当前使用opus模型

### 查看日志验证

检查semantic-router日志：
```bash
tail -f ~/.openclaw/workspace/.lib/semantic_check.log
```

日志格式示例：
```
[2026-03-06T03:05:12] 帮我写一篇关于春天的散文 | C     content_generation   🔑 score=0.000 grade=new_session
[2026-03-06T03:06:45] 查一下iPhone 16的价格      | C     info_retrieval       🔑 score=0.000 grade=new_session
```

检查API调用日志（在供应商后台）：
- 确认实际调用的模型ID
- 验证切换时间点

---

## 💡 配置最佳实践

### 1. Fallback策略

**原则：** 不同供应商互为备用，避免单点故障

**示例：**
```json
{
  "primary": "custom-provider/claude-opus-4-6",
  "fallback_1": "qianwen/qwen3-coder-plus",
  "fallback_2": "qianwen/deepseek-chat"
}
```

**避免：** 同一供应商的模型互为备用（供应商挂了全挂）

### 2. 模型ID格式

确保模型ID格式正确：
```
供应商名/模型名
```

示例：
- `custom-ai-jiexi6-cn/claude-opus-4-6`
- `qianwen/qwen3-coder-plus`
- `qianwen/deepseek-chat`

### 3. 不要修改技能核心代码

**重要：** 不要修改 `~/.openclaw/skills/semantic-router/scripts/semantic_check.py`

如果需要调整行为，应该：
- 修改 `pools.json` 配置模型
- 修改 `tasks.json` 配置任务类型
- 修改 hook 脚本的参数

### 4. 定期检查日志

监控semantic-router运行状态：
```bash
tail -20 ~/.openclaw/workspace/.lib/semantic_check.log
```

关注：
- 检测方法图标（📊=embedding, 🔑=keyword, 🔍=indicator）
- 相似度分数（score）
- 分支类型（B/B+/C/C-auto）

---

## 📝 总结

**成功配置semantic-router的关键：**

1. ✅ 启用内置hook：`openclaw config set hooks.internal.entries.semantic-router-auto.enabled true`
2. ✅ 使用 `-e` 参数执行自动切换
3. ✅ Hook trigger设置为 `before_agent_start`
4. ✅ 配置多供应商fallback策略
5. ❌ 不要创建plugin或standalone hooks
6. ❌ 不要修改技能核心代码

**配置文件清单：**
- `~/.openclaw/openclaw.json` - 启用hook
- `~/.openclaw/workspace/.lib/pools.json` - 三池模型配置
- `~/.openclaw/workspace/.lib/tasks.json` - 任务类型（技能提供）
- `~/.openclaw/workspace/.kiro/hooks/semantic-router-auto.json` - Hook配置
- `~/.openclaw/workspace/scripts/semantic_router_hook.sh` - Hook执行脚本

配置完成后，semantic-router会自动根据对话内容选择最合适的模型，无需手动切换。
