# Geospatial Data Analysis Guide

## Overview
地理空间数据分析入门，从数据格式到空间查询的完整指南。

## Core Concepts

### Coordinate Systems
- **WGS84 (EPSG:4326)**: GPS 标准，经纬度
- **Web Mercator (EPSG:3857)**: Web 地图标准
- **UTM**: 区域性投影，保持面积/距离比例

### Data Formats
- **GeoJSON**: Web 标准，易解析
- **Shapefile**: 传统 GIS 格式
- **GeoTIFF**: 栅格数据
- **KML**: Google Earth 格式
- **TopoJSON**: GeoJSON 压缩版

## PostGIS Spatial Queries

### Distance Search
```sql
SELECT name, ST_Distance(location, ST_MakePoint(-73.985, 40.748)::geography) AS dist_meters
FROM locations
WHERE ST_DWithin(location, ST_MakePoint(-73.985, 40.748)::geography, 5000)
ORDER BY dist_meters;
```

### Area Calculation
```sql
SELECT name, ST_Area(geom::geography) / 1000000 AS area_sqkm
FROM regions;
```

### Point-in-Polygon
```sql
SELECT p.*
FROM points p, polygons poly
WHERE ST_Contains(poly.geom, p.location);
```

## GeoJSON Processing (Python)
```python
import json
from shapely.geometry import shape, Point

with open('data.geojson') as f:
    geojson = json.load(f)

for feature in geojson['features']:
    geom = shape(feature['geometry'])
    if isinstance(geom, Point):
        print(f"Point: {geom.x}, {geom.y}")
    elif geom.geom_type == 'Polygon':
        print(f"Area: {geom.area:.2f} sq units")
```

## Mapbox Visualization
```javascript
map.on('load', () => {
  map.addSource('points', {
    type: 'geojson',
    data: 'https://api.example.com/points.geojson'
  });
  map.addLayer({
    id: 'circles',
    type: 'circle',
    source: 'points',
    paint: {
      'circle-radius': ['get', 'radius'],
      'circle-color': ['interpolate', ['linear'], ['get', 'intensity'],
        0, '#00ff00', 0.5, '#ffff00', 1, '#ff0000'
      ]
    }
  });
});
```

## Use Cases
- Real estate: property proximity analysis
- Logistics: route optimization, delivery zones
- Retail: store catchment area mapping
- Climate: weather pattern visualization