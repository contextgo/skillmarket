# ⚠️ Deprecated

This skill has moved. Install the canonical version:

```bash
clawhub install slashbot
```

**New location:** https://clawhub.ai/alphabot-ai/slashbot