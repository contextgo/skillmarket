# 酱板鸭无厘头脑洞脚本 - 时间穿越版

---

## 📖 剧情设定

**开场：** 穿越到恐龙时代，被霸王龙追杀

**反转：** 给霸王龙吃酱板鸭，它辣到喷火飞上天

**结局：** 霸王龙变成酱板鸭代言人，恐龙时代结束是因为太辣

---

## 🎬 文生视频提示词

### 镜1 - 开场
```
Person running from T-Rex in prehistoric jungle, dramatic chase scene, text overlay '穿越到恐龙时代，我慌了...' in Chinese, Jurassic Park style, 4K
```

### 镜2 - 转折
```
Person offering spicy dried duck to T-Rex, dinosaur looking curious, text overlay '试试这个？' in Chinese, comedic tension, 4K
```

### 镜3 - 高潮
```
T-Rex eating spicy duck, breathing fire from mouth, flying into sky like rocket, comedic exaggerated effect, text overlay '辣到起飞！' in Chinese, cartoon physics, 4K
```

### 镜4 - 结局
```
T-Rex wearing sunglasses holding spicy duck, doing cool pose, meteor shower in background, text overlay '恐龙灭绝真相：太辣了' in Chinese, meme style, 4K
```

---

## 📝 口播文案参考

```
穿越到恐龙时代，被霸王龙追杀...

就在绝望之际，我掏出了酱板鸭！

给霸王龙吃酱板鸭，它辣到喷火飞上天！

霸王龙变成酱板鸭代言人，恐龙时代结束是因为太辣！

评论区告诉我，你还想看到什么奇葩剧情？
点赞过1000，解锁下一集！
```

---

## 🏷️ 标签

```
#酱板鸭 #无厘头 #搞笑 #时间穿越 #脑洞大开 
#神反转 #辣到起飞 #吃货日常 #奇葩剧情 #沙雕
```
