# 酱板鸭无厘头脑洞脚本 - 外星人版

---

## 📖 剧情设定

**开场：** 外星人入侵地球，人类束手无策

**反转：** 外星人怕辣，酱板鸭成终极武器

**结局：** 酱板鸭拯救地球，人类获得'辣度和平奖'

---

## 🎬 文生视频提示词

### 镜1 - 开场
```
Alien spaceship hovering over city, dramatic invasion scene, people running in panic, text overlay '外星人入侵，人类末日？' in Chinese, sci-fi movie style, 4K cinematic
```

### 镜2 - 转折
```
Close-up of spicy dried duck package glowing with mysterious light, alien tentacle reaching for it cautiously, text overlay '地球最后的希望...' in Chinese, dramatic lighting, 4K
```

### 镜3 - 高潮
```
Alien eating spicy duck, face turning red, steam coming out of ears, comedic exaggerated reaction, other aliens watching in horror, text overlay '辣到变形！' in Chinese, funny sci-fi style, 4K
```

### 镜4 - 结局
```
Aliens retreating in spaceship, holding white flag made of duck bones, Earth people celebrating with spicy duck, text overlay '酱板鸭拯救地球！' in Chinese, epic victory scene, 4K
```

---

## 📝 口播文案参考

```
外星人入侵地球，人类束手无策...

就在绝望之际，我掏出了酱板鸭！

外星人怕辣，酱板鸭成终极武器！

酱板鸭拯救地球，人类获得'辣度和平奖'！

评论区告诉我，你还想看到什么奇葩剧情？
点赞过1000，解锁下一集！
```

---

## 🏷️ 标签

```
#酱板鸭 #无厘头 #搞笑 #外星人 #脑洞大开 
#神反转 #辣到起飞 #吃货日常 #奇葩剧情 #沙雕
```
