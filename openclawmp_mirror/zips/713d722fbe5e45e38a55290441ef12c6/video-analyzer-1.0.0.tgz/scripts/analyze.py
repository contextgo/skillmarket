#!/usr/bin/env python3
"""
视频分析器 - 下载并分析抖音/视频号视频
提取画面、文案、节奏、热门元素
"""

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path
from urllib.parse import urlparse


def download_video(url, output_dir):
    """Download video using yt-dlp"""
    print(f"[DOWNLOAD] Video: {url}")
    
    output_path = Path(output_dir) / "video.mp4"
    
    cmd = [
        "yt-dlp",
        "--no-check-certificate",
        "--format", "best[ext=mp4]/best",
        "--output", str(output_path),
        url
    ]
    
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"[OK] Video downloaded: {output_path}")
        return str(output_path)
    except subprocess.CalledProcessError as e:
        print(f"[ERROR] Download failed: {e}")
        return None


def extract_frames(video_path, output_dir, interval=2):
    """提取关键帧"""
    print(f"🎬 正在提取关键帧 (每{interval}秒)...")
    
    frames_dir = Path(output_dir) / "frames"
    frames_dir.mkdir(exist_ok=True)
    
    cmd = [
        "ffmpeg",
        "-i", video_path,
        "-vf", f"fps=1/{interval},scale=480:-1",
        "-q:v", "2",
        str(frames_dir / "frame_%03d.jpg")
    ]
    
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        frames = list(frames_dir.glob("*.jpg"))
        print(f"✅ 提取了 {len(frames)} 帧")
        return frames_dir
    except subprocess.CalledProcessError as e:
        print(f"❌ 提取帧失败: {e}")
        return None


def extract_audio(video_path, output_dir):
    """提取音频用于语音识别"""
    print("🎵 正在提取音频...")
    
    audio_path = Path(output_dir) / "audio.mp3"
    
    cmd = [
        "ffmpeg",
        "-i", video_path,
        "-vn", "-acodec", "libmp3lame",
        "-q:a", "2",
        str(audio_path)
    ]
    
    try:
        subprocess.run(cmd, check=True, capture_output=True)
        print(f"✅ 音频提取完成: {audio_path}")
        return str(audio_path)
    except subprocess.CalledProcessError as e:
        print(f"❌ 提取音频失败: {e}")
        return None


def transcribe_audio(audio_path, output_dir):
    """使用Whisper进行语音识别"""
    print("📝 正在进行语音识别...")
    
    try:
        import whisper
        
        model = whisper.load_model("base")
        result = model.transcribe(audio_path, language="zh")
        
        transcript_path = Path(output_dir) / "transcript.txt"
        with open(transcript_path, "w", encoding="utf-8") as f:
            f.write(result["text"])
        
        # 保存带时间戳的版本
        segments_path = Path(output_dir) / "transcript_segments.json"
        with open(segments_path, "w", encoding="utf-8") as f:
            json.dump(result["segments"], f, ensure_ascii=False, indent=2)
        
        print(f"✅ 语音识别完成: {transcript_path}")
        return result["text"], result["segments"]
        
    except ImportError:
        print("⚠️ 未安装whisper，跳过语音识别")
        return None, None
    except Exception as e:
        print(f"❌ 语音识别失败: {e}")
        return None, None


def get_video_info(video_path):
    """获取视频基本信息"""
    print("📊 正在获取视频信息...")
    
    cmd = [
        "ffprobe",
        "-v", "error",
        "-show_entries", "format=duration,size,bit_rate",
        "-show_entries", "stream=width,height,r_frame_rate",
        "-of", "json",
        video_path
    ]
    
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, check=True)
        info = json.loads(result.stdout)
        
        # 计算时长
        duration = float(info["format"]["duration"])
        minutes = int(duration // 60)
        seconds = int(duration % 60)
        
        video_info = {
            "duration": f"{minutes}:{seconds:02d}",
            "duration_seconds": duration,
            "size_mb": round(int(info["format"]["size"]) / 1024 / 1024, 2),
            "resolution": f"{info['streams'][0]['width']}x{info['streams'][0]['height']}",
            "frame_rate": eval(info["streams"][0]["r_frame_rate"])
        }
        
        print(f"✅ 视频信息: {video_info['duration']}, {video_info['resolution']}")
        return video_info
        
    except Exception as e:
        print(f"❌ 获取视频信息失败: {e}")
        return {}


def analyze_structure(segments, duration):
    """分析视频结构"""
    if not segments:
        return {}
    
    # 分段分析
    parts = {
        "opening": {"start": 0, "end": min(3, duration), "text": ""},
        "middle": {"start": 3, "end": min(duration * 0.8, duration - 5), "text": ""},
        "ending": {"start": max(duration - 5, 3), "end": duration, "text": ""}
    }
    
    for seg in segments:
        start = seg["start"]
        text = seg["text"]
        
        if start < 3:
            parts["opening"]["text"] += text + " "
        elif start > duration - 5:
            parts["ending"]["text"] += text + " "
        else:
            parts["middle"]["text"] += text + " "
    
    return parts


def generate_analysis_report(video_info, transcript, segments, output_dir):
    """生成分析报告"""
    print("📄 正在生成分析报告...")
    
    # 分析结构
    structure = analyze_structure(segments, video_info.get("duration_seconds", 0))
    
    # 构建分析报告
    analysis = {
        "video_info": video_info,
        "transcript": transcript,
        "structure": structure,
        "key_points": {
            "hook": structure.get("opening", {}).get("text", "")[:100] + "...",
            "climax": structure.get("middle", {}).get("text", "")[:200] + "...",
            "cta": structure.get("ending", {}).get("text", "")[:100] + "..."
        },
        "stats": {
            "total_words": len(transcript) if transcript else 0,
            "speaking_rate": round(len(transcript) / video_info.get("duration_seconds", 1) * 60, 1) if transcript else 0
        }
    }
    
    # 保存JSON
    analysis_path = Path(output_dir) / "analysis.json"
    with open(analysis_path, "w", encoding="utf-8") as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2)
    
    # 生成Markdown报告
    report_path = Path(output_dir) / "report.md"
    with open(report_path, "w", encoding="utf-8") as f:
        f.write(f"# 视频分析报告\n\n")
        f.write(f"## 基本信息\n")
        f.write(f"- 时长: {video_info.get('duration', 'N/A')}\n")
        f.write(f"- 分辨率: {video_info.get('resolution', 'N/A')}\n")
        f.write(f"- 帧率: {video_info.get('frame_rate', 'N/A')} fps\n")
        f.write(f"- 文件大小: {video_info.get('size_mb', 'N/A')} MB\n\n")
        
        f.write(f"## 文案统计\n")
        f.write(f"- 总字数: {analysis['stats']['total_words']}\n")
        f.write(f"- 语速: {analysis['stats']['speaking_rate']} 字/分钟\n\n")
        
        f.write(f"## 结构分析\n")
        f.write(f"### 开场 (前3秒)\n{structure.get('opening', {}).get('text', 'N/A')}\n\n")
        f.write(f"### 中段\n{structure.get('middle', {}).get('text', 'N/A')[:300]}...\n\n")
        f.write(f"### 结尾\n{structure.get('ending', {}).get('text', 'N/A')}\n\n")
        
        f.write(f"## 完整文案\n```\n{transcript}\n```\n")
    
    print(f"✅ 分析报告已生成: {report_path}")
    return analysis


def main():
    parser = argparse.ArgumentParser(description="Video Analyzer")
    parser.add_argument("--url", "-u", required=True, help="Video URL")
    parser.add_argument("--output", "-o", default="./analysis", help="Output directory")
    parser.add_argument("--interval", "-i", type=int, default=2, help="Frame extraction interval (seconds)")
    
    args = parser.parse_args()
    
    # 创建输出目录
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"[START] Analyzing video...")
    print(f"[OUTPUT] Directory: {output_dir}")
    
    # 1. 下载视频
    video_path = download_video(args.url, output_dir)
    if not video_path:
        print("[ERROR] Video download failed, exiting")
        sys.exit(1)
    
    # 2. 获取视频信息
    video_info = get_video_info(video_path)
    
    # 3. 提取关键帧
    frames_dir = extract_frames(video_path, output_dir, args.interval)
    
    # 4. 提取音频
    audio_path = extract_audio(video_path, output_dir)
    
    # 5. 语音识别
    transcript = None
    segments = None
    if audio_path:
        transcript, segments = transcribe_audio(audio_path, output_dir)
    
    # 6. 生成分析报告
    analysis = generate_analysis_report(video_info, transcript, segments, output_dir)
    
    print(f"\n[DONE] Analysis complete!")
    print(f"[REPORT] {output_dir}/report.md")
    print(f"[DATA] {output_dir}/analysis.json")
    print(f"[FRAMES] {output_dir}/frames/")


if __name__ == "__main__":
    main()
