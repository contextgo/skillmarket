#!/usr/bin/env python3
"""
无厘头脑洞酱板鸭脚本生成器
"""

from pathlib import Path


def generate_wulai_scripts(output_dir):
    """生成多个无厘头脑洞版本"""
    
    scripts = {
        "外星人版": {
            "setup": "外星人入侵地球，人类束手无策",
            "twist": "外星人怕辣，酱板鸭成终极武器",
            "ending": "酱板鸭拯救地球，人类获得'辣度和平奖'",
            "prompts": [
                "Alien spaceship hovering over city, dramatic invasion scene, people running in panic, text overlay '外星人入侵，人类末日？' in Chinese, sci-fi movie style, 4K cinematic",
                "Close-up of spicy dried duck package glowing with mysterious light, alien tentacle reaching for it cautiously, text overlay '地球最后的希望...' in Chinese, dramatic lighting, 4K",
                "Alien eating spicy duck, face turning red, steam coming out of ears, comedic exaggerated reaction, other aliens watching in horror, text overlay '辣到变形！' in Chinese, funny sci-fi style, 4K",
                "Aliens retreating in spaceship, holding white flag made of duck bones, Earth people celebrating with spicy duck, text overlay '酱板鸭拯救地球！' in Chinese, epic victory scene, 4K"
            ]
        },
        
        "时间穿越版": {
            "setup": "穿越到恐龙时代，被霸王龙追杀",
            "twist": "给霸王龙吃酱板鸭，它辣到喷火飞上天",
            "ending": "霸王龙变成酱板鸭代言人，恐龙时代结束是因为太辣",
            "prompts": [
                "Person running from T-Rex in prehistoric jungle, dramatic chase scene, text overlay '穿越到恐龙时代，我慌了...' in Chinese, Jurassic Park style, 4K",
                "Person offering spicy dried duck to T-Rex, dinosaur looking curious, text overlay '试试这个？' in Chinese, comedic tension, 4K",
                "T-Rex eating spicy duck, breathing fire from mouth, flying into sky like rocket, comedic exaggerated effect, text overlay '辣到起飞！' in Chinese, cartoon physics, 4K",
                "T-Rex wearing sunglasses holding spicy duck, doing cool pose, meteor shower in background, text overlay '恐龙灭绝真相：太辣了' in Chinese, meme style, 4K"
            ]
        },
        
        "修仙版": {
            "setup": "修仙渡劫失败，被雷劈中",
            "twist": "手里正好拿着酱板鸭，雷劫被辣度中和",
            "ending": "酱板鸭成渡劫神器，飞升成仙后天天吃",
            "prompts": [
                "Cultivator standing on mountain peak, dark clouds gathering, lightning striking down, text overlay '渡劫失败？' in Chinese, xianxia fantasy style, 4K",
                "Close-up of spicy dried duck in cultivator's hand glowing with spiritual energy, lightning hitting the duck, text overlay '以辣抗雷！' in Chinese, magical effect, 4K",
                "Cultivator ascending to heaven riding on giant spicy duck, rainbow clouds, other cultivators watching in shock, text overlay '酱板鸭助我飞升！' in Chinese, epic fantasy scene, 4K",
                "Immortal cultivator in heaven, sitting on cloud eating spicy duck, other gods looking jealous, text overlay '仙界特产：酱板鸭' in Chinese, heavenly comedy, 4K"
            ]
        },
        
        "霸道总裁版": {
            "setup": "霸道总裁冷酷无情，从不笑",
            "twist": "秘书递上酱板鸭，总裁辣到表情失控",
            "ending": "总裁爱上酱板鸭，收购整个酱板鸭产业",
            "prompts": [
                "Handsome CEO in luxury office, cold expression, employees afraid, text overlay '这个总裁，从不笑...' in Chinese, Korean drama style, 4K",
                "Secretary offering spicy dried duck to CEO, dramatic music, CEO looking skeptical, text overlay '试试？' in Chinese, office romance tension, 4K",
                "CEO eating spicy duck, perfect hair messed up, tears streaming down, but smiling, comedic transformation, text overlay '辣到破防！' in Chinese, funny CEO moment, 4K",
                "CEO standing in front of duck factory, holding giant check, employees cheering, text overlay '这厂，我买了！' in Chinese, epic business victory, 4K"
            ]
        },
        
        "丧尸末日版": {
            "setup": "丧尸围城，人类最后避难所即将沦陷",
            "twist": "酱板鸭的辣味让丧尸恢复人性",
            "ending": "酱板鸭治愈丧尸危机，世界和平",
            "prompts": [
                "Zombies surrounding safe house, people terrified behind barricade, apocalyptic atmosphere, text overlay '丧尸围城，末日降临...' in Chinese, Walking Dead style, 4K",
                "Hero throwing spicy dried duck into zombie crowd, zombies stopping and sniffing, text overlay '最后的希望...' in Chinese, dramatic moment, 4K",
                "Zombies eating spicy duck, red faces, tears of joy, returning to human form, comedic miracle, text overlay '辣回人性！' in Chinese, heartwarming comedy, 4K",
                "Former zombies and humans having spicy duck party together, world peace celebration, text overlay '酱板鸭拯救世界' in Chinese, happy ending, 4K"
            ]
        },
        
        "漫威英雄版": {
            "setup": "灭霸打响指，英雄们团灭",
            "twist": "酱板鸭侠出现，辣度太强让灭霸流泪投降",
            "ending": "酱板鸭侠加入复仇者联盟，成为最强战力",
            "prompts": [
                "Thanos snapping fingers, Avengers turning to dust, dramatic defeat scene, text overlay '英雄团灭，世界绝望...' in Chinese, Marvel movie style, 4K",
                "Mysterious hero in spicy duck costume appearing, glowing with spicy aura, text overlay '酱板鸭侠，参上！' in Chinese, superhero entrance, 4K",
                "Spicy Duck Hero feeding Thanos super spicy duck, Thanos crying, infinity gauntlet falling off, comedic defeat, text overlay '辣到投降！' in Chinese, funny superhero battle, 4K",
                "Spicy Duck Hero standing with Avengers team, posing heroically, text overlay '复仇者联盟新成员' in Chinese, epic team shot, 4K"
            ]
        }
    }
    
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)
    
    for name, content in scripts.items():
        filename = name.replace("版", "")
        filepath = output_path / f"jiangbanya_{filename}.md"
        
        script = f"""# 酱板鸭无厘头脑洞脚本 - {name}

---

## 📖 剧情设定

**开场：** {content['setup']}

**反转：** {content['twist']}

**结局：** {content['ending']}

---

## 🎬 文生视频提示词

### 镜1 - 开场
```
{content['prompts'][0]}
```

### 镜2 - 转折
```
{content['prompts'][1]}
```

### 镜3 - 高潮
```
{content['prompts'][2]}
```

### 镜4 - 结局
```
{content['prompts'][3]}
```

---

## 📝 口播文案参考

```
{content['setup']}...

就在绝望之际，我掏出了酱板鸭！

{content['twist']}！

{content['ending']}！

评论区告诉我，你还想看到什么奇葩剧情？
点赞过1000，解锁下一集！
```

---

## 🏷️ 标签

```
#酱板鸭 #无厘头 #搞笑 #{name.replace('版', '')} #脑洞大开 
#神反转 #辣到起飞 #吃货日常 #奇葩剧情 #沙雕
```
"""
        
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(script)
        
        print(f"[OK] Generated: {filepath}")
    
    return output_path


if __name__ == "__main__":
    generate_wulai_scripts("./wulai_scripts")
