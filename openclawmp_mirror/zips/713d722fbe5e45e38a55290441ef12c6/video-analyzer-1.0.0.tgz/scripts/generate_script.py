#!/usr/bin/env python3
"""
基于视频分析生成类似风格脚本
"""

import argparse
import json
import random
from pathlib import Path


# 常见视频风格模板
STYLE_TEMPLATES = {
    "搞笑": {
        "tone": "幽默诙谐",
        "pacing": "快节奏",
        "hook_types": [
            "夸张反应开场",
            "反转预期",
            "制造尴尬",
            "自嘲式开场"
        ],
        "climax_types": [
            "意外反转",
            "夸张表演",
            "神回复",
            "尴尬瞬间"
        ],
        "cta_types": [
            "求点赞",
            "评论区互动",
            "关注追更",
            "分享朋友"
        ]
    },
    "测评": {
        "tone": "专业客观",
        "pacing": "中等节奏",
        "hook_types": [
            "直接展示产品",
            "抛出疑问",
            "对比预告",
            "价格悬念"
        ],
        "climax_types": [
            "真实体验",
            "优缺点总结",
            "性价比分析",
            "购买建议"
        ],
        "cta_types": [
            "评论区讨论",
            "求推荐",
            "关注看更多",
            "点赞支持"
        ]
    },
    "剧情": {
        "tone": "情感共鸣",
        "pacing": "有张有弛",
        "hook_types": [
            "场景代入",
            "冲突前置",
            "悬念设置",
            "情感共鸣"
        ],
        "climax_types": [
            "情感爆发",
            "问题解决",
            "温暖结局",
            "反转收尾"
        ],
        "cta_types": [
            "情感互动",
            "分享故事",
            "关注追更",
            "评论共鸣"
        ]
    },
    "美食": {
        "tone": "诱人食欲",
        "pacing": "快慢结合",
        "hook_types": [
            "成品展示",
            "制作过程",
            "吃播预告",
            "价格悬念"
        ],
        "climax_types": [
            "制作过程",
            "品尝反应",
            "口感描述",
            "推荐总结"
        ],
        "cta_types": [
            "求地址",
            "评论区推荐",
            "关注吃货",
            "点赞收藏"
        ]
    }
}


def load_analysis(analysis_path):
    """加载分析结果"""
    with open(analysis_path, "r", encoding="utf-8") as f:
        return json.load(f)


def extract_formula(analysis):
    """提取爆款公式"""
    structure = analysis.get("structure", {})
    
    formula = {
        "duration": analysis.get("video_info", {}).get("duration_seconds", 30),
        "opening_duration": 3,
        "opening_text": structure.get("opening", {}).get("text", "")[:50],
        "middle_pattern": "叙述+展示",
        "ending_duration": 5,
        "ending_text": structure.get("ending", {}).get("text", "")[:50],
        "speaking_rate": analysis.get("stats", {}).get("speaking_rate", 150)
    }
    
    return formula


def generate_hook(product, style, formula):
    """生成开场钩子"""
    templates = {
        "搞笑": [
            f"我以为{product}只是普通零食，结果...",
            f"挑战吃{product}不喝水，我后悔了！",
            f"朋友推荐的{product}，吃完我想绝交...",
            f"全网最火的{product}，真的好吃吗？"
        ],
        "测评": [
            f"今天测评全网爆火的{product}",
            f"{product}到底值不值得买？",
            f"实测{product}，真实体验分享",
            f"花XX元买的{product}，开箱测评"
        ],
        "剧情": [
            f"那天我收到了一包{product}...",
            f"妈妈说这个{product}很好吃",
            f"加班到深夜，只有{product}陪我",
            f"第一次吃{product}，我哭了"
        ],
        "美食": [
            f"这个{product}看起来就香！",
            f"{product}的正确打开方式",
            f"一口{product}，满嘴留香",
            f"{product}制作全过程"
        ]
    }
    
    hooks = templates.get(style, templates["美食"])
    return random.choice(hooks)


def generate_middle(product, style, analysis):
    """生成中段内容"""
    if style == "搞笑":
        return f"""
【第2镜】5-15秒 - 尝试/ setup
- 展示{product}外观
- 夸张描述期待感
- 制造悬念

【第3镜】15-25秒 - 高潮/反转  
- 第一口反应（夸张表情）
- 辣/麻/香的冲击
- 搞笑吐槽或神回复

【第4镜】25-30秒 - 后续反应
- 继续吃或喝水解辣
- 朋友反应（如有）
- 意外笑点
"""
    elif style == "测评":
        return f"""
【第2镜】5-15秒 - 外观展示
- {product}包装展示
- 打开后的样子
- 气味描述

【第3镜】15-25秒 - 口感测评
- 第一口体验
- 味道层次分析
- 优缺点总结

【第4镜】25-30秒 - 综合评价
- 性价比分析
- 适合人群
- 购买建议
"""
    elif style == "剧情":
        return f"""
【第2镜】5-15秒 - 故事发展
- 吃{product}的场景
- 回忆/情感铺垫
- 细节描写

【第3镜】15-25秒 - 情感高潮
- 味道带来的触动
- 故事转折点
- 情感爆发点

【第4镜】25-30秒 - 温暖结局
- 感悟/总结
- 情感升华
- 余韵留白
"""
    else:  # 美食
        return f"""
【第2镜】5-15秒 - 制作过程/开箱
- {product}外观特写
- 撕开包装的声音
- 食材展示

【第3镜】15-25秒 - 品尝过程
- 第一口慢动作
- 咀嚼特写
- 表情反应

【第4镜】25-30秒 - 口感描述
- 味道层次
- 口感特点
- 推荐指数
"""


def generate_ending(product, style):
    """生成结尾引导"""
    templates = {
        "搞笑": [
            f"这{product}太上头了！评论区告诉我你能吃多辣！",
            f"{product}挑战成功/失败！点赞过1000我再挑战更辣的！",
            f"吃完这包{product}，我悟了...关注我看更多作死挑战！",
            f"{product}测评完毕！你们还想看我吃什么奇葩零食？"
        ],
        "测评": [
            f"总结：{product}值得买！评论区告诉我你想看什么测评~",
            f"{product}测评完成！觉得有用点个赞，关注看更多真实测评！",
            f"这就是{product}的真实体验，你觉得值吗？评论区讨论！",
            f"{product}推荐指数：⭐⭐⭐⭐⭐ 关注我，买前先看测评！"
        ],
        "剧情": [
            f"有时候，一包{product}就能温暖整个夜晚。你有过这样的时刻吗？",
            f"{product}的故事讲完了，但生活还在继续。关注我看更多故事。",
            f"这包{product}，让我想起了...评论区分享你的故事。",
            f"{product}不只是零食，更是一种情怀。点赞支持！"
        ],
        "美食": [
            f"这{product}真的绝了！地址在评论区，点赞收藏不迷路！",
            f"{product}太好吃了！关注我，带你吃遍天下美食！",
            f"吃完{product}，满足！你们还想看什么美食？评论区告诉我！",
            f"{product}打卡成功！求推荐更多好吃的，评论区见！"
        ]
    }
    
    endings = templates.get(style, templates["美食"])
    return random.choice(endings)


def generate_shot_prompts(product, style):
    """生成文生视频提示词"""
    if style == "搞笑":
        return f"""
【镜1 - 开场】
Close-up of excited person holding package of {product}, dramatic lighting, text overlay "我以为这只是普通零食..." in bold Chinese characters, comedic timing setup, 4K, shallow depth of field

【镜2 - 展示】
Product shot of {product} being opened, steam rising, rich colors, appetizing food photography style, dramatic music implied, 4K ultra detailed

【镜3 - 高潮反应】
Extreme close-up of person's face showing exaggerated reaction to eating {product}, eyes wide, comedy expression, slow motion effect, text overlay with funny comment, 4K cinematic

【镜4 - 后续】
Person drinking water or continuing to eat {product} with humorous struggle, friend laughing in background, comedic situation, bright lighting, 4K

【镜5 - 结尾】
Person giving thumbs up or down with {product} package, text overlay with call-to-action, energetic ending, 4K commercial style
"""
    elif style == "测评":
        return f"""
【镜1 - 开场】
Professional product review setup, {product} package on clean table, reviewer looking at camera, text overlay "今天测评{product}", bright studio lighting, 4K professional

【镜2 - 外观】
Detailed product shots of {product}, packaging design, ingredients visible, macro photography style, neutral background, 4K

【镜3 - 体验】
Reviewer taking first bite of {product}, genuine reaction, close-up of texture, analytical expression, 4K documentary style

【镜4 - 总结】
Split screen showing pros and cons of {product}, rating graphics, professional review format, clean design, 4K

【镜5 - 结尾】
Reviewer holding {product} with final verdict expression, text overlay with recommendation, subscribe call-to-action, 4K
"""
    else:  # 美食
        return f"""
【镜1 - 开场】
Beautiful food photography of {product}, steam rising, golden hour lighting, text overlay "这个看起来就香！", appetizing colors, 4K food commercial

【镜2 - 特写】
Extreme close-up of {product} texture, glistening surface, detailed food macro shot, professional food styling, 4K

【镜3 - 品尝】
Slow motion shot of person taking first bite of {product}, satisfaction expression, ASMR eating sounds implied, 4K cinematic

【镜4 - 氛围】
Cozy eating scene with {product}, warm lighting, comfortable setting, lifestyle food photography, 4K

【镜5 - 结尾】
Person giving thumbs up with {product}, happy expression, text overlay with location/price, inviting call-to-action, 4K
"""


def generate_script(analysis_path, product, style, output_path):
    """生成完整脚本"""
    print(f"🎬 正在生成脚本...")
    print(f"   产品: {product}")
    print(f"   风格: {style}")
    
    # 加载分析
    analysis = load_analysis(analysis_path)
    
    # 提取公式
    formula = extract_formula(analysis)
    
    # 生成各部分
    hook = generate_hook(product, style, formula)
    middle = generate_middle(product, style, analysis)
    ending = generate_ending(product, style)
    prompts = generate_shot_prompts(product, style)
    
    # 构建完整脚本
    script = f"""# {product} - {style}风格视频脚本

## 📋 视频信息

| 项目 | 内容 |
|------|------|
| **产品** | {product} |
| **风格** | {style} |
| **参考时长** | {int(formula['duration'])}秒 |
| **语速参考** | {formula['speaking_rate']}字/分钟 |

---

## 🎬 分镜脚本

### 【第1镜】0-5秒 - 开场钩子

**画面：** 吸引眼球的开场

**口播：**
> {hook}

---

{middle}

---

### 【第5镜】30-35秒 - 结尾引导

**画面：** 产品展示 + 引导动作

**口播：**
> {ending}

---

## 📝 完整口播文案

```
{hook}

{middle.replace("【", "").replace("】", "").replace("-", "").replace("镜", "").replace("秒", "").replace("数字", "")}

{ending}
```

---

## 🎨 文生视频提示词

{prompts}

---

## 🏷️ 发布标签

```
#{product.replace(" ", "")} #{'测评' if style == '测评' else '美食' if style == '美食' else '搞笑' if style == '搞笑' else '剧情'} 
#{'真实测评' if style == '测评' else '吃货必备' if style == '美食' else '搞笑日常' if style == '搞笑' else '情感故事'} 
#网红零食 #零食推荐 #试吃 #种草
```

---

## 💡 爆款公式参考

基于分析提取的成功要素：

| 要素 | 参考值 |
|------|--------|
| 开场时长 | {formula['opening_duration']}秒 |
| 总时长 | {int(formula['duration'])}秒 |
| 语速 | {formula['speaking_rate']}字/分钟 |
| 开场模式 | {formula['opening_text'][:30]}... |
| 结尾模式 | {formula['ending_text'][:30]}... |

---

*脚本由 Video Analyzer 技能自动生成*
"""
    
    # 保存脚本
    output_file = Path(output_path)
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(script)
    
    print(f"✅ 脚本已生成: {output_file}")
    return script


def main():
    parser = argparse.ArgumentParser(description="基于视频分析生成脚本")
    parser.add_argument("--analysis", "-a", required=True, help="分析结果JSON文件路径")
    parser.add_argument("--product", "-p", required=True, help="产品名称")
    parser.add_argument("--style", "-s", default="美食", 
                       choices=["搞笑", "测评", "剧情", "美食"],
                       help="视频风格")
    parser.add_argument("--output", "-o", default="./script.md", help="输出脚本路径")
    
    args = parser.parse_args()
    
    generate_script(args.analysis, args.product, args.style, args.output)


if __name__ == "__main__":
    main()
