#!/usr/bin/env python3
"""
快速脚本生成器 - 基于视频标题和描述生成类似风格脚本
"""

import argparse
import random
from pathlib import Path


def generate_jiangbanya_script(output_path):
    """基于"雪山上救过一只酱板鸭"生成类似搞笑脚本"""
    
    script = """# 酱板鸭搞笑视频脚本
## 参考风格：雪山上救过一只酱板鸭（剧情反转+搞笑）

---

## 📋 视频信息

| 项目 | 内容 |
|------|------|
| **产品** | 酱板鸭 |
| **风格** | 搞笑剧情 + 神反转 |
| **参考时长** | 30-45秒 |
| **核心梗** | 意外发现/救命恩人/反转结局 |

---

## 🎬 分镜脚本

### 【第1镜】0-5秒 - 悬念开场

**画面：** 雪地/寒冷场景，一个人瑟瑟发抖

**字幕：** "那天我在雪山上快冻僵了..."

**口播：**
> "你们相信吗？我在雪山上快冻僵的时候，是它救了我！"

**文生视频提示词：**
```
Snowy mountain scene, person shivering in cold with visible breath, dramatic survival situation, text overlay "那天我在雪山上快冻僵了...", cinematic lighting, documentary style, 4K
```

---

### 【第2镜】5-15秒 - 回忆/ setup

**画面：** 回忆画面，从包里掏出一只酱板鸭

**字幕：** "就在我绝望的时候，发现了它..."

**口播：**
> "就在我绝望的时候，我从包里掏出了这只酱板鸭！"

**文生视频提示词：**
```
Close-up of hand pulling out a package of spicy dried duck from backpack, dramatic reveal moment, steam rising from package, text overlay "发现了它...", warm lighting contrasting cold background, 4K cinematic
```

---

### 【第3镜】15-25秒 - 高潮/反转

**画面：** 大口吃酱板鸭，表情从痛苦到满足

**字幕：** "一口下去，我活过来了！"

**口播：**
> "一口下去，辣得我浑身发热！三口下去，我直接活过来了！这酱板鸭，简直就是我的救命恩人啊！"

**文生视频提示词：**
```
Extreme close-up of person taking big bite of spicy duck, expression changing from cold pain to satisfied warmth, steam effect around body indicating warmth, comedic exaggerated reaction, text overlay "一口下去，我活过来了！", 4K slow motion
```

---

### 【第4镜】25-35秒 - 后续/笑点

**画面：** 吃完后精神焕发，在雪山上跳舞/摆pose

**字幕：** "酱板鸭：没想到我还能救人"

**口播：**
> "现在我出门必带酱板鸭！不为别的，就为关键时刻能救命！"

**文生视频提示词：**
```
Person dancing energetically on snowy mountain after eating, vibrant and warm despite cold environment, comedic pose with duck package, text overlay "酱板鸭：没想到我还能救人", bright energetic lighting, funny meme style, 4K
```

---

### 【第5镜】35-40秒 - 结尾引导

**画面：** 举着酱板鸭，对着镜头

**字幕：** "你的救命鸭在这里"

**口播：**
> "你们有什么奇葩的救命经历？评论区告诉我！点赞过1000，我告诉你们这是哪个牌子的酱板鸭！"

**文生视频提示词：**
```
Person holding up spicy dried duck package to camera, pointing at product with big smile, text overlay "你的救命鸭在这里" and "评论区见！", bright commercial lighting, call-to-action pose, 4K
```

---

## 📝 完整口播文案

```
你们相信吗？我在雪山上快冻僵的时候，是它救了我！

就在我绝望的时候，我从包里掏出了这只酱板鸭！

一口下去，辣得我浑身发热！三口下去，我直接活过来了！
这酱板鸭，简直就是我的救命恩人啊！

现在我出门必带酱板鸭！不为别的，就为关键时刻能救命！

你们有什么奇葩的救命经历？评论区告诉我！
点赞过1000，我告诉你们这是哪个牌子的酱板鸭！
```

---

## 🎨 所有文生视频提示词（复制使用）

### 镜1 - 悬念开场
```
Snowy mountain scene, person shivering in cold with visible breath, dramatic survival situation, text overlay "那天我在雪山上快冻僵了..." in Chinese, cinematic lighting, documentary style, 4K quality
```

### 镜2 - 发现酱板鸭
```
Close-up of hand pulling out a package of spicy dried duck from backpack, dramatic reveal moment, steam rising from package, text overlay "发现了它..." in Chinese, warm lighting contrasting cold background, 4K cinematic
```

### 镜3 - 救命时刻（高潮）
```
Extreme close-up of person taking big bite of spicy duck, expression changing from cold pain to satisfied warmth, steam effect around body indicating warmth, comedic exaggerated reaction, text overlay "一口下去，我活过来了！" in Chinese, 4K slow motion
```

### 镜4 - 反转笑点
```
Person dancing energetically on snowy mountain after eating, vibrant and warm despite cold environment, comedic pose with duck package, text overlay "酱板鸭：没想到我还能救人" in Chinese, bright energetic lighting, funny meme style, 4K
```

### 镜5 - 结尾引导
```
Person holding up spicy dried duck package to camera, pointing at product with big smile, text overlay "你的救命鸭在这里" and "评论区见！" in Chinese, bright commercial lighting, call-to-action pose, 4K quality
```

---

## 🏷️ 发布标签

```
#酱板鸭 #雪山上救过一只酱板鸭 #搞笑 #反转 
#救命恩人 #奇葩经历 #零食推荐 #湖南特产 
#辣到起飞 #吃货日常 #神反转 #评论区见
```

---

## 🎵 配乐建议

| 时段 | 风格 |
|------|------|
| 开场 | 紧张悬疑 |
| 发现酱板鸭 | 转折音乐 |
| 高潮 | 欢快搞笑 |
| 结尾 |  energetic |

**推荐BGM：** 抖音热门反转神曲，或"惊不惊喜"类搞笑音乐

---

## 💡 爆款公式

基于"雪山上救过一只酱板鸭"分析：

| 要素 | 应用 |
|------|------|
| **悬念开场** | 极端场景（雪山）+ 生死关头 |
| **意外转折** | 救命的不是人，是食物 |
| **夸张反应** | 辣=发热=救命，逻辑跳跃搞笑 |
| **神结局** | 酱板鸭拟人化，"没想到我还能救人" |
| **互动引导** | 求评论区分享奇葩经历 |

---

*脚本由 Video Analyzer 技能生成*
*参考视频：【超Ai小剧场】你是否在雪山上救过一只酱板鸭*
"""
    
    # 保存脚本
    output_file = Path(output_path)
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(script)
    
    print(f"[OK] Script generated: {output_file}")
    return script


def main():
    parser = argparse.ArgumentParser(description="Quick Script Generator")
    parser.add_argument("--output", "-o", default="./jiangbanya_script.md", help="Output path")
    
    args = parser.parse_args()
    
    generate_jiangbanya_script(args.output)


if __name__ == "__main__":
    main()
