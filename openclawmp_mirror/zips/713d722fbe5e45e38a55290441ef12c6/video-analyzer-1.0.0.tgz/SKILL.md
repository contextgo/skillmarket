---
name: video-analyzer
description: 抖音/视频号视频下载与分析工具。下载热门视频，分析画面内容、文案结构、节奏风格、热门元素，提取爆款公式，生成类似风格脚本。用于蹭热点、学习爆款、内容创作。
version: 1.0.0
metadata:
  openclaw:
    emoji: "🎬"
    requires:
      bins: ["python", "ffmpeg"]
---

# 视频分析器 (Video Analyzer)

下载抖音/视频号热门视频，深度分析其成功要素，提取爆款公式。

## 触发条件

- "分析这个视频"
- "下载抖音视频"
- "学习这个爆款"
- "提取视频文案"
- "分析热门元素"
- "生成类似脚本"

## 功能特性

| 功能 | 说明 |
|------|------|
| **视频下载** | 支持抖音、视频号、快手等平台 |
| **画面分析** | 分镜拆解、视觉风格、色彩氛围 |
| **文案提取** | 语音识别转文字、字幕提取 |
| **节奏分析** | 剪辑节奏、转场方式、时长分配 |
| **热门元素** | 提取爆款公式、情绪曲线、记忆点 |
| **脚本生成** | 基于分析结果生成类似风格脚本 |

## 使用方法

### 1. 下载并分析视频

```bash
python {skillDir}/scripts/analyze.py --url "https://v.douyin.com/xxxxx" --output ./analysis/
```

### 2. 批量分析多个视频

```bash
python {skillDir}/scripts/batch_analyze.py --urls urls.txt --output ./analysis/
```

### 3. 生成类似风格脚本

```bash
python {skillDir}/scripts/generate_script.py --analysis ./analysis/result.json --product "酱板鸭"
```

## 输出结果

分析完成后生成以下文件：

```
analysis/
├── video.mp4              # 下载的视频
├── frames/                # 关键帧截图
│   ├── frame_001.jpg
│   ├── frame_002.jpg
│   └── ...
├── transcript.txt         # 语音转文字
├── analysis.json          # 完整分析报告
├── script_template.md     # 生成的脚本模板
└── report.md              # 可视化分析报告
```

## 分析报告内容

### 基础信息
- 视频时长、分辨率、帧率
- 文件大小、编码格式

### 内容分析
- **分镜数量**：平均每个镜头时长
- **文案结构**：开场→中段→结尾的文案模式
- **情绪曲线**：紧张→放松→高潮的情绪变化
- **记忆点**：最容易记住的画面/台词

### 风格特征
- **视觉风格**：明亮/暗调、饱和度、滤镜类型
- **剪辑节奏**：快剪/慢剪、转场方式
- **音乐类型**：BGM风格、节奏快慢
- **字幕样式**：字体、颜色、动画

### 爆款公式
提取可复制的成功要素：
```json
{
  "hook": "前3秒吸引注意力的方式",
  "conflict": "制造的冲突/好奇心",
  "climax": "高潮点设计",
  "cta": "结尾引导互动的方式",
  "formula": "可复制的结构公式"
}
```

## 依赖安装

```bash
# 安装Python依赖
pip install yt-dlp opencv-python pillow openai-whisper

# 安装FFmpeg（Windows）
winget install ffmpeg
```

## 示例：分析酱板鸭搞笑视频

```bash
# 1. 下载并分析
python scripts/analyze.py \
  --url "https://v.douyin.com/xxxxx" \
  --output ./jiangbanya_analysis/

# 2. 查看分析报告
cat ./jiangbanya_analysis/report.md

# 3. 生成类似脚本
python scripts/generate_script.py \
  --analysis ./jiangbanya_analysis/analysis.json \
  --product "酱板鸭" \
  --style "搞笑" \
  --output ./jiangbanya_script.md
```

## 注意事项

- 仅用于学习分析，尊重原创版权
- 下载的视频仅供个人学习使用
- 生成脚本时请二次创作，避免直接搬运
