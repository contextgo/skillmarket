---
name: cron-orchestration-patterns
description: "Cron 定时自动化编排模式 - Agent 任务调度、心跳保活、错误恢复完整方案"
version: 1.0.0
tags: ["cron", "automation", "scheduling", "openclaw", "orchestration"]
---

# Cron 自动化编排模式

使用 OpenClaw Cron 调度器实现 AI Agent 自动化任务编排的完整方案，包括定时执行、心跳保活、错误恢复和状态管理。

## 核心概念

```
Cron Job → isolated session → 执行任务 → 记录结果 → 通知
```

每个 Cron 任务在独立的 isolated session 中执行，避免相互干扰。

## 任务设计模式

### 模式 1：数据采集器

```
频率：每小时
类型：agentTurn（独立 session）
输入：市场名称列表
输出：结构化数据 + 日志
```

**关键点**：
- 使用 web_fetch/web_search 采集数据
- 结果写入 `memory/daily-notes/`
- 失败自动重试，不影响其他任务

### 模式 2：策略执行器

```
频率：每 4 小时
类型：agentTurn
输入：采集器产出的数据
输出：决策 + 行动
```

**关键点**：
- 读取最新数据做决策
- 执行外部操作（发布资产等）
- 记录决策理由

### 模式 3：心跳保活

```
频率：每 30 分钟
类型：systemEvent（主 session）
输入：无
输出：HEARTBEAT_OK / 汇报
```

**关键点**：
- 检查待办任务
- 检查卡住的 session
- 主动汇报进度

### 模式 4：健康检查

```
频率：每 6 小时
类型：agentTurn
输入：系统状态
输出：检查报告 + 修复操作
```

**关键点**：
- 检查 API 可达性
- 检查磁盘/内存
- 自动修复常见问题

## Cron Job 配置模板

```json
{
  "name": "data-collector",
  "schedule": {
    "kind": "cron",
    "expr": "0 * * * *",
    "tz": "Asia/Ulaanbaatar"
  },
  "payload": {
    "kind": "agentTurn",
    "message": "执行数据采集任务：抓取新闻和市场数据，分析信号",
    "timeoutSeconds": 300
  },
  "delivery": {
    "mode": "announce",
    "channel": "feishu"
  },
  "sessionTarget": "isolated",
  "enabled": true
}
```

## 错误恢复策略

### 网络错误
- curl 超时 → 30s 重试 1 次 → 60s 重试 1 次 → 放弃并记录
- API 403 → 检查认证 → 尝试刷新 Key → 失败则通知用户

### Session 卡住
- 心跳检测到 → 发送恢复消息 → 无响应则标记为 stuck
- GatewayRestart → 自动检查所有 session → 逐个恢复

### Context 溢出
- Memory Flush Protocol：50% 警觉，70% 活跃写入，85% 紧急保存
- 关键状态全部持久化到文件

## 状态管理

```
STATE.yaml（共享黑板）
  ├── task_1: pending
  ├── task_2: in_progress
  ├── task_3: done
  └── task_4: blocked (depends: task_2)
```

## 最佳实践

1. **每个 Job 独立运行**：不要让一个 Job 依赖另一个 Job 的运行时状态
2. **所有状态写入文件**：Session 可能随时重启
3. **设置超时**：防止任务无限挂起
4. **渐进式通知**：非紧急不打扰，重要事件立即通知
5. **日志结构化**：便于后续检索和分析
