---
name: excel-formula-generator
name_en: excel-formula-generator
displayName: 【爆款】Excel公式生成器 | 说话就能做统计汇总
version: 1.0.1
description: "VLOOKUP怎么写？条件统计用什么公式？数据透视表太复杂？这款工具让你用说话的方式生成Excel公式！输入'计算每个部门的平均工资'，立刻得到公式+解释+示例。财务/HR/数据分析师必备！"
description_en: "Generate Excel formulas from natural language! Can't write complex formulas? Describe what you want to calculate, AI generates it. Supports SUMIF, VLOOKUP, PivotTables, and more. Say goodbye to Excel formula troubles."
type: skill
tags:
  - excel
  - spreadsheet
  - formula
  - productivity
  - automation
  - office
  - 数据处理
  - Excel公式
  - Excel技巧
  - 数据汇总
  - 表格
  - 办公
  - 财务
  - HR
  - 数据分析
  - 统计
author: ruiyongwang
author_en: ruiyongwang
license: MIT
category: productivity
category_en: Productivity
---

# Excel公式生成器

## 🔥 痛点场景

- ❌ VLOOKUP总是匹配不到，不知道哪里写错了
- ❌ SUMIF条件求和不会写，数据汇总太难了
- ❌ 领导让做统计，翻遍网络还是写不出来
- ❌ 公式报错了，#N/A #REF看不懂什么意思

## 💡 一句话介绍

用自然语言描述你的需求，AI生成可用的Excel公式：
- 🗣️ 自然语言输入
- 📊 支持复杂公式
- 📖 详细使用说明
- 💡 举一反三示例

---

## 核心功能

### 1. 自然语言 → 公式

**输入示例：**
```
> 计算A列的总和

> 如果B列大于100，显示"高"，否则显示"低"

> 查找C列对应的D列值

> 计算每个部门的平均工资
```

**输出示例：**
```excel
=SUM(A:A)

=IF(B1>100, "高", "低")

=VLOOKUP(E1, C:D, 2, FALSE)

=AVERAGEIF(部门列, "销售部", 工资列)
```

### 2. 公式解释

**逐段解释公式含义：**
```
=SUMIF(A:A, ">=100", B:B)

SUMIF    → 条件求和函数
A:A      → 要检查的区域（第一列）
">=100"  → 条件（大于等于100）
B:B      → 要求和的区域（第二列）

含义：第一列中大于等于100的项，对应第二列求和
```

### 3. 常见模板库

| 需求 | 公式 |
|------|------|
| 求和 | =SUM() |
| 平均值 | =AVERAGE() |
| 计数 | =COUNT() / =COUNTA() |
| 条件求和 | =SUMIF() / =SUMIFS() |
| 条件计数 | =COUNTIF() / =COUNTIFS() |
| 查找 | =VLOOKUP() / =XLOOKUP() |
| 条件判断 | =IF() / =IFS() |
| 日期计算 | =DATEDIF() / =NETWORKDAYS() |

### 4. 错误排查

**自动诊断公式错误：**
```
原公式：=VLOOKUP(A1, B:D, 3, FALSE)
错误：#N/A - 查找值不存在
建议：添加IFERROR包装
修正：=IFERROR(VLOOKUP(A1, B:D, 3, FALSE), "未找到")
```

---

## 使用方式

### 基础用法
```
> 计算A列的和

> 求B列的平均值

> 统计C列大于0的数量
```

### 条件公式
```
> 如果A1大于B1，显示"是"，否则显示"否"

> 计算销售部（部门在A列，工资在C列）的总工资

> 统计A列中"已完成"的数量
```

### 查找引用
```
> 在Sheet2的A列查找当前表的B1，返回对应C列的值

> 查找同时满足：部门="销售" 且 工资>10000 的记录
```

### 数据透视表
```
> 按部门统计工资总额和平均工资

> 计算每月的销售总额和订单数量
```

---

## 公式语法速查

### 常用函数

**数学函数：**
| 函数 | 用途 | 示例 |
|------|------|------|
| SUM | 求和 | =SUM(A1:A10) |
| AVERAGE | 平均值 | =AVERAGE(A1:A10) |
| ROUND | 四舍五入 | =ROUND(A1, 2) |
| ABS | 绝对值 | =ABS(A1) |

**逻辑函数：**
| 函数 | 用途 | 示例 |
|------|------|------|
| IF | 条件判断 | =IF(A1>0,"正","负") |
| AND | 且 | =AND(A1>0, B1>0) |
| OR | 或 | =OR(A1>0, B1>0) |
| IFS | 多条件 | =IFS(A1>=90,"A",A1>=80,"B") |

**查找函数：**
| 函数 | 用途 | 示例 |
|------|------|------|
| VLOOKUP | 垂直查找 | =VLOOKUP(A1, B:D, 3, FALSE) |
| HLOOKUP | 水平查找 | =HLOOKUP(A1, 1:3, 3, FALSE) |
| XLOOKUP | 智能查找 | =XLOOKUP(A1, B:B, C:C) |
| INDEX+MATCH | 组合查找 | =INDEX(C:C, MATCH(A1, B:B, 0)) |

---

## 适用场景

| 场景 | 说明 |
|------|------|
| 财务计算 | 工资、税收、预算统计 |
| 销售报表 | 业绩统计、排名分析 |
| 数据汇总 | 多条件统计求和 |
| 库存管理 | 进销存统计 |
| 项目管理 | 进度跟踪、资源统计 |

---

## 注意事项

1. **单元格引用**：区分绝对引用($A$1)和相对引用(A1)
2. **数据类型**：文本和数字需要正确区分
3. **空值处理**：使用IFERROR处理可能的错误
4. **性能优化**：大量数据避免使用整列引用

---

**让Excel公式不再难！**