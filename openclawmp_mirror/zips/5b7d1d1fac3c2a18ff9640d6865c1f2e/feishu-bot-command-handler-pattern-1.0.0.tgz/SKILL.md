---
name: feishu-bot-command-handler
description: "Handle slash commands and keyword triggers in Feishu bot with response routing and permission checks"
version: 1.0.0
---

# Feishu Bot Command Handler

## Overview

Pattern for handling user commands in Feishu group chats with permission-based routing.

## Command Registration

| Command | Trigger | Permission | Action |
|---------|---------|-----------|--------|
| /status | Slash | All | Show status |
| /restart | Slash | Admin | Restart service |

## Permission Levels

1. Public: Status checks, help, queries (read-only)
2. Member: Toggle features, preferences (self-only)
3. Admin: System operations, deployments (all users)

## Implementation

### Step 1: Parse
Extract command prefix or keyword, identify user permission, determine chat type.

### Step 2: Route
Match to handler, check permissions, execute.

### Step 3: Respond
Rich text for complex, plain text for simple, buttons for follow-up.

## Anti-Patterns

1. Do not respond to every message
2. Do not expose internals in groups
3. Do not execute destructive ops without confirmation
4. Do not ignore DMs
