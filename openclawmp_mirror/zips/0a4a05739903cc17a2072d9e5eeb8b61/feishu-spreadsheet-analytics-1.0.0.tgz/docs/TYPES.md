# TypeScript 类型定义

本文件详细说明 `feishu-spreadsheet-analytics` 的所有公开类型。

## 核心类型

### FieldType

字段数据类型枚举。

```typescript
type FieldType = "string" | "number" | "date" | "boolean" | "mixed";
```

### FieldSchema

字段级别的详细统计和元数据。

```typescript
interface FieldSchema {
  name: string;              // 字段名
  type: FieldType;           // 推断的类型
  nullable: boolean;         // 是否允许空值
  nullCount: number;         // 空值数量
  unique: boolean;           // 是否唯一值
  uniqueCount: number;       // 唯一值数量
  sample: any[];             // 采样值（前几个）

  // 数值字段特有
  min?: number;
  max?: number;
  mean?: number;
  median?: number;
  std?: number;

  // 日期字段特有
  dateFormat?: string;

  // 布尔字段特有
  trueCount?: number;
  falseCount?: number;

  // 文本字段特有
  maxLength?: number;
  avgLength?: number;
}
```

### DataStats

整体数据统计和字段schema。

```typescript
interface DataStats {
  totalRows: number;         // 总行数
  totalColumns: number;      // 总列数
  completeRows: number;      // 完整行数（无空值）
  completeness: number;      // 完成率 (0-1)
  fields: Record<string, FieldSchema>;  // 字段名 → FieldSchema
  typeDistribution: Record<FieldType, number>;  // 类型分布
  warnings: string[];        // 警告信息
}
```

### Distribution

分布分析结果。

```typescript
interface Distribution {
  type: "numeric" | "categorical" | "temporal";
  field: string;

  // 数值字段：直方图
  bins?: Bin[];

  // 分类字段：Top N 值
  topValues?: TopValue[];

  // 时间字段：时间序列
  timeSeries?: TimePoint[];
}

interface Bin {
  range: string;   // 区间表示，如 "0-10"
  count: number;
  percentage: number;
}

interface TopValue {
  value: any;
  count: number;
  percentage: number;
}

interface TimePoint {
  date: string;    // 日期/时间
  count: number;   // 该时段数据量
}
```

### OutlierResult

异常值检测结果。

```typescript
interface OutlierResult {
  field: string;           // 字段名
  method: "iqr" | "zscore"; // 检测方法
  outliers: number[];      // 异常值所在的行索引
  threshold: number;       // 使用的阈值
}
```

### AnalyticsConfig

分析配置。

```typescript
interface AnalyticsConfig {
  spreadsheetToken: string;  // 表格 token（必填）
  sheetId?: string;          // 工作表 ID（可选）
  headerRow?: number;        // 表头行号，默认 1
  dataStartRow?: number;     // 数据起始行，默认 2
  maxRows?: number;          // 最大读取行数限制
  batchSize?: number;        // 分批读取的批次大小
  feishuConfig?: {
    appId?: string;
    appSecret?: string;
  };
}
```

### AnalyticsOptions

分析选项。

```typescript
interface AnalyticsOptions {
  includeDistribution?: boolean;     // 是否包含分布分析
  includeOutliers?: boolean;         // 是否包含异常检测
  outlierMethod?: "iqr" | "zscore"; // 异常检测方法
  outlierThreshold?: number;         // 异常检测阈值
  outputFormat?: "markdown" | "html" | "json";  // 输出格式
  maxSampleSize?: number;            // 采样大小
}
```

### AnalyticsReport

完整的分析报告。

```typescript
interface AnalyticsReport {
  spreadsheetId: string;
  sheetId?: string;
  generatedAt: string;       // ISO 时间戳
  schema: DataStats;         // 数据结构和统计
  distributions?: Distribution[];  // 分布分析
  outliers?: OutlierResult[];      // 异常检测
  rawData?: any[][];         // 原始数据（可选，调试用）
  markdown?: string;         // Markdown 报告（如果生成）
  html?: string;            // HTML 报告（如果生成）
}
```

### ParsedData

解析后的原始数据。

```typescript
interface ParsedData {
  headers: string[];   // 表头
  rows: any[][];       // 数据行
  metadata: {
    source: string;         // 数据来源
    sheetName?: string;     // 工作表名
    totalRows: number;      // 表格总行数
    readRows: number;       // 实际读取行数
  };
}
```

### BatchResult

批量读取单表格的结果。

```typescript
interface BatchResult {
  spreadsheetId: string;
  sheetId?: string;
  success: boolean;
  report?: AnalyticsReport;  // 成功时的报告
  error?: string;            // 失败时的错误信息
}
```

---

## 工具函数类型

详见 `src/utils.ts` 导出。

---

## 更新记录

- **v1.0.0** (2026-03-02): 初始版本，定义所有核心类型