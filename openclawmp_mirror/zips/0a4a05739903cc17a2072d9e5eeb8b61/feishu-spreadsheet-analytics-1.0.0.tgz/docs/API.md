# API Reference

## Table of Contents

- [SpreadsheetReader](#spreadsheetreader)
- [BatchSpreadsheetReader](#batchspreadsheetreader)
- [DataAnalyzer](#dataanalyzer)
- [Reporter](#reporter)
- [SpreadsheetAnalytics](#spreadsheetanalytics)
- [Utility Functions](#utility-functions)
- [Error Classes](#error-classes)

---

## SpreadsheetReader

飞书表格读取器，负责从 Spreadsheet/Bitable 读取数据。

### Constructor

```typescript
new SpreadsheetReader(config: AnalyticsConfig, tools?: Partial<FeishuBitableTools>)
```

**Parameters:**
- `config`: `AnalyticsConfig` - 配置对象
- `tools`: (optional) `Partial<FeishuBitableTools>` - 工具注入（用于测试）

### Methods

#### read(): Promise<ParsedData>

读取表格数据。

**Returns:** `Promise<ParsedData>` - 解析后的数据

**Throws:**
- `SpreadsheetReadError` - 读取失败
- `SpreadsheetNotFoundError` - 表格不存在
- `SheetNotFoundError` - 工作表不存在

**Example:**
```typescript
const reader = new SpreadsheetReader({ spreadsheetToken: "xxx" });
const data = await reader.read();
console.log(data.headers); // string[]
console.log(data.rows);    // any[][]
```

---

## BatchSpreadsheetReader

批量读取多个表格。

### Constructor

```typescript
new BatchSpreadsheetReader(configs: AnalyticsConfig[], tools?: Partial<FeishuBitableTools>)
```

### Methods

#### readAll(): Promise<BatchResult[]>

批量读取所有配置的表格。

**Returns:** `Promise<BatchResult[]>` - 每个表格的读取结果

---

## DataAnalyzer

数据分析器，对 ParsedData 进行统计分析。

### Constructor

```typescript
new DataAnalyzer(data: ParsedData)
```

### Methods

#### inferSchema(): DataStats

推断数据结构和统计信息。

**Returns:** `DataStats` - 包含字段schema和整体统计

#### basicStats(): DataStats

获取基础统计信息（同 `inferSchema`，但可能缓存结果）。

#### fieldStatistics(): Record<string, FieldSchema>

获取每个字段的详细统计。

**Returns:** `Record<string, FieldSchema>` - 字段名到字段统计的映射

#### distributions(limit?: number): Distribution[]

分析字段分布。

**Parameters:**
- `limit`: (optional) 最大分析字段数，默认全部

**Returns:** `Distribution[]` - 分布分析结果

#### detectOutliers(options: {
  method?: "iqr" | "zscore";
  threshold?: number;
}): OutlierResult[]

检测异常值。

**Parameters:**
- `method`: 检测方法，默认 "iqr"
- `threshold`: 阈值，默认 1.5

**Returns:** `OutlierResult[]` - 每个字段的异常值列表

---

## Reporter

报告生成器，将分析结果格式化为多种输出。

### Constructor

```typescript
new Reporter(schema: DataStats, options?: AnalyticsOptions)
```

### Methods

#### generateMarkdown(options?: {
  includeDistribution?: boolean;
  includeOutliers?: boolean;
  maxSampleSize?: number;
}): string

生成 Markdown 格式报告。

#### generateHTML(options?: {
  theme?: "light" | "dark";
  interactive?: boolean;
  charts?: boolean;
}): string

生成 HTML 格式报告（带样式和交互）。

#### toJSON(): AnalyticsReport

导出结构化 JSON 报告。

---

## SpreadsheetAnalytics

一站式分析入口类。

### Constructor

```typescript
new SpreadsheetAnalytics(config: AnalyticsConfig)
```

### Methods

#### analyze(options?: AnalyticsOptions): Promise<AnalyticsReport>

执行完整分析流程（读取 → 分析 → 报告）。

#### readOnly(): Promise<ParsedData>

仅读取数据，不分析。

#### analyzeData(data: ParsedData, options?: AnalyticsOptions): Promise<AnalyticsReport>

直接分析已读取的数据。

#### getConfig(): Readonly<AnalyticsConfig>

获取当前配置。

#### updateConfig(config: Partial<AnalyticsConfig>): void

更新配置。

### Static Functions

#### quickAnalyze(config, options): Promise<AnalyticsReport>

快速分析单表格。

#### batchAnalyze(configs, options): Promise<AnalyticsReport[]>

批量分析多个表格。

---

## Utility Functions

### inferType(value: any): FieldType

推断单个值的类型。

### detectDateFormat(values: string[]): string | null

检测日期格式。

### calculateStats(numbers: number[]): { mean, median, std, min, max }

计算统计指标。

### iqrOutliers(numbers: number[], threshold): number[]

IQR 方法检测异常值。

### zscoreOutliers(numbers: number[], threshold): number[]

Z-score 方法检测异常值。

### formatNumber(num): string

格式化数字显示。

### convertToType(value, targetType): any

类型转换。

### uniquenessRatio(values): number

计算唯一值比例。

### nullRatio(values): number

计算空值比例。

### getSamples(values, maxSize): any[]

获取采样值。

---

## Error Classes

所有错误类都继承自 `Error`：

- `SpreadsheetReadError` - 读取错误基类
- `SpreadsheetNotFoundError` - 表格不存在
- `SheetNotFoundError` - 工作表不存在
- `AnalysisError` - 分析错误
- `ReportGenerationError` - 报告生成错误

每个错误类可能包含额外属性：
- `code`: 错误代码字符串
- `field`: 相关字段名（分析错误）
- `details`: 附加详情

---

## Types

详细类型定义请参考 [`src/types.ts`](./src/types.ts) 或 [类型文档](./TYPES.md)。