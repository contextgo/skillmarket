// 数据类型定义

export type FieldType = "string" | "number" | "date" | "boolean" | "mixed";

export interface FieldSchema {
  name: string;
  type: FieldType;
  nullable: boolean;
  nullCount: number;
  unique: boolean;
  uniqueCount: number;
  sample: any[];
  // 数值字段特有
  min?: number;
  max?: number;
  mean?: number;
  median?: number;
  std?: number;
  // 日期字段特有
  dateFormat?: string;
  // 布尔字段特有
  trueCount?: number;
  falseCount?: number;
  // 文本字段特有
  maxLength?: number;
  avgLength?: number;
}

export interface DataStats {
  totalRows: number;
  totalColumns: number;
  completeRows: number;    // 无空值的行数
  completeness: number;   // 完成率 (0-1)
  fields: Record<string, FieldSchema>;
  typeDistribution: Record<FieldType, number>;
  warnings: string[];
}

export interface Distribution {
  type: "numeric" | "categorical" | "temporal";
  field: string;
  bins?: Bin[];
  topValues?: TopValue[];
  timeSeries?: TimePoint[];
}

export interface Bin {
  range: string;
  count: number;
  percentage: number;
}

export interface TopValue {
  value: any;
  count: number;
  percentage: number;
}

export interface TimePoint {
  date: string;
  count: number;
}

export interface OutlierResult {
  field: string;
  method: "iqr" | "zscore";
  outliers: number[]; // 异常值索引
  threshold: number;
}

export interface AnalyticsConfig {
  spreadsheetToken: string;
  sheetId?: string;
  headerRow?: number;
  dataStartRow?: number;
  maxRows?: number;
  batchSize?: number;
  feishuConfig?: {
    appId?: string;
    appSecret?: string;
  };
}

export interface AnalyticsOptions {
  includeDistribution?: boolean;
  includeOutliers?: boolean;
  outlierMethod?: "iqr" | "zscore";
  outlierThreshold?: number;
  outputFormat?: "markdown" | "html" | "json";
  maxSampleSize?: number;
}

export interface AnalyticsReport {
  spreadsheetId: string;
  sheetId?: string;
  generatedAt: string;
  schema: DataStats;
  distributions?: Distribution[];
  outliers?: OutlierResult[];
  rawData?: any[][]; // 可选，用于调试
}

export interface BatchResult {
  spreadsheetId: string;
  sheetId?: string;
  success: boolean;
  report?: AnalyticsReport;
  error?: string;
}

// 内部数据结构
export interface ParsedData {
  headers: string[];
  rows: any[][];
  metadata: {
    source: string;
    sheetName?: string;
    totalRows: number;
    readRows: number;
  };
}