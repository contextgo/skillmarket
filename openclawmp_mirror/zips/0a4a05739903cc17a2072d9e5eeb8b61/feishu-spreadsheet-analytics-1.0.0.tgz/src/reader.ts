/**
 * 飞书表格读取器
 *
 * 负责从飞书 Spreadsheet/Bitable 读取数据，支持分页、偏移和多个工作表
 *
 * @author GOGO & tob-openclaw
 * @license MIT
 */

import {
  AnalyticsConfig,
  ParsedData,
  BatchResult,
} from "./types";

/**
 * 工具函数类型定义
 * 对应 feishu_bitable_* 系列工具
 */
interface FeishuBitableTools {
  feishu_bitable_get_meta: (params: { url: string }) => Promise<{
    app_token: string;
    table_id: string;
    tables: Array<{ table_id: string; name?: string }>;
  }>;
  feishu_bitable_list_fields: (params: {
    app_token: string;
    table_id: string;
  }) => Promise<Array<{ name: string; type: number }>>;
  feishu_bitable_list_records: (params: {
    app_token: string;
    table_id: string;
    page_size: number;
    page_token?: string;
  }) => Promise<{
    records: Array<{ fields: Record<string, any> }>;
    page_token?: string;
  }>;
}

/**
 * 自定义错误类
 */
export class SpreadsheetReadError extends Error {
  constructor(
    message: string,
    public code: string = "SPREADSHEET_READ_ERROR",
    public details?: any
  ) {
    super(message);
    this.name = "SpreadsheetReadError";
  }
}

export class SpreadsheetNotFoundError extends SpreadsheetReadError {
  constructor(message: string = "表格不存在或无访问权限", details?: any) {
    super(message, "SPREADSHEET_NOT_FOUND", details);
    this.name = "SpreadsheetNotFoundError";
  }
}

export class SheetNotFoundError extends SpreadsheetReadError {
  constructor(message: string = "工作表不存在", details?: any) {
    super(message, "SHEET_NOT_FOUND", details);
    this.name = "SheetNotFoundError";
  }
}

/**
 * 飞书表格读取器
 *
 * 使用 feishu_bitable_* 工具读取数据，支持自动分页和偏移处理
 */
export class SpreadsheetReader {
  private config: Required<AnalyticsConfig>;
  private tools: FeishuBitableTools;

  constructor(
    config: AnalyticsConfig,
    tools?: Partial<FeishuBitableTools>
  ) {
    if (!config.spreadsheetToken) {
      throw new SpreadsheetReadError(
        "缺少必需的 spreadsheetToken 参数",
        "MISSING_TOKEN"
      );
    }

    this.config = {
      spreadsheetToken: config.spreadsheetToken,
      sheetId: config.sheetId || "",
      headerRow: config.headerRow ?? 1,
      dataStartRow: config.dataStartRow ?? 2,
      maxRows: config.maxRows ?? Infinity,
      batchSize: config.batchSize ?? 500,
      feishuConfig: config.feishuConfig || {},
    };

    // 初始化工具（默认从全局获取，支持依赖注入）
    this.tools = tools || (this as any).getDefaultTools?.() || this.createDefaultTools();
  }

  /**
   * 读取表格数据
   *
   * @returns Promise<ParsedData> 解析后的数据
   */
  async read(): Promise<ParsedData> {
    try {
      // 1. 获取表格元数据
      const { app_token, table_id, tables } = await this.getTableMeta();

      // 2. 确定要读取的工作表
      const targetSheet = this.selectSheet(table_id, tables);

      // 3. 读取字段信息（用于确认表头）
      const fields = await this.listFields(app_token, targetSheet);
      const headers = this.extractHeaders(fields);

      // 4. 分页读取数据
      const rows = await this.readAllRows(app_token, targetSheet);

      // 5. 应用偏移和限制
      const processedRows = this.processRows(rows);

      return {
        headers,
        rows: processedRows,
        metadata: {
          source: this.config.spreadsheetToken,
          sheetName: targetSheet,
          totalRows: rows.length,
          readRows: processedRows.length,
        },
      };
    } catch (error: any) {
      if (
        error.name === "SpreadsheetNotFoundError" ||
        error.name === "SheetNotFoundError"
      ) {
        throw error;
      }
      throw new SpreadsheetReadError(
        `读取表格失败: ${error.message}`,
        "READ_FAILED",
        { original: error }
      );
    }
  }

  /**
   * 获取表格元数据
   *
   * @returns Promise<{ app_token: string; table_id: string; tables: any[] }>
   */
  private async getTableMeta() {
    try {
      const result = await this.tools.feishu_bitable_get_meta({
        url: this.config.spreadsheetToken,
      });
      return result;
    } catch (error: any) {
      if (error.code === "BITABLE_NOT_FOUND" || error.code === "INVALID_URL") {
        throw new SpreadsheetNotFoundError(error.message, error);
      }
      throw error;
    }
  }

  /**
   * 选择目标工作表
   *
   * @param defaultTableId - 默认 table_id
   * @param tables - 可用工作表列表
   * @returns 目标 table_id
   */
  private selectSheet(
    defaultTableId: string,
    tables: Array<{ table_id: string; name?: string }>
  ): string {
    // 如果配置了 sheetId，优先使用
    if (this.config.sheetId) {
      // 验证 sheetId 是否存在
      const exists = tables.some((t) => t.table_id === this.config.sheetId);
      if (!exists && tables.length > 0) {
        const available = tables.map((t) => t.name || t.table_id).join(", ");
        throw new SheetNotFoundError(
          `指定的工作表 "${this.config.sheetId}" 不存在。可用工作表：${available}`,
          { available: tables.map((t) => t.table_id) }
        );
      }
      return this.config.sheetId;
    }

    // 如果没有指定且只有一个工作表，使用它
    if (tables.length === 1) {
      return tables[0].table_id;
    }

    // 多个工作表但未指定，返回第一个
    if (tables.length > 1) {
      console.warn(
        `[SpreadsheetReader] 检测到 ${tables.length} 个工作表，未指定 sheetId，将使用第一个工作表`
      );
      return tables[0].table_id;
    }

    // 没有工作表信息，返回默认
    return defaultTableId;
  }

  /**
   * 列出字段（表头）
   *
   * @param appToken - app token
   * @param tableId - table id
   * @returns Promise<any[]> 字段列表
   */
  private async listFields(
    appToken: string,
    tableId: string
  ): Promise<Array<{ name: string }>> {
    try {
      const result = await this.tools.feishu_bitable_list_fields({
        app_token: appToken,
        table_id: tableId,
      });
      return result;
    } catch (error: any) {
      throw new SpreadsheetReadError(
        `获取字段信息失败: ${error.message}`,
        "LIST_FIELDS_FAILED",
        { app_token: appToken, table_id: tableId, error }
      );
    }
  }

  /**
   * 提取表头名称
   *
   * @param fields - 字段列表
   * @returns string[] 表头数组
   */
  private extractHeaders(fields: Array<{ name: string }>): string[] {
    return fields.map((field) => field.name);
  }

  /**
   * 读取所有数据行（分页）
   *
   * @param appToken - app token
   * @param tableId - table id
   * @returns Promise<any[][]> 所有数据行
   */
  private async readAllRows(
    appToken: string,
    tableId: string
  ): Promise<any[][]> {
    const allRows: any[][] = [];
    let pageToken: string | undefined = undefined;
    let totalRead = 0;

    // 计算最大读取行数（考虑偏移）
    const maxRowsToRead =
      this.config.maxRows === Infinity
        ? Infinity
        : this.config.maxRows + (this.config.dataStartRow - 1);

    do {
      const pageSize = this.config.batchSize;
      const remaining = maxRowsToRead === Infinity
        ? pageSize
        : maxRowsToRead - totalRead;

      if (remaining <= 0) {
        break;
      }

      const size = Math.min(pageSize, remaining);

      try {
        const result = await this.tools.feishu_bitable_list_records({
          app_token: appToken,
          table_id: tableId,
          page_size: size,
          page_token: pageToken,
        });

        // 提取记录数据
        const records = result.records || [];
        const rows = records.map((record: { fields: Record<string, any> }) => {
          // 将字段对象转换为数组（按字段顺序）
          return Object.values(record.fields || {});
        });

        allRows.push(...rows);
        totalRead += rows.length;

        pageToken = result.page_token;
      } catch (error: any) {
        throw new SpreadsheetReadError(
          `分页读取失败: ${error.message}`,
          "PAGE_READ_FAILED",
          { page_token: pageToken, error }
        );
      }
    } while (pageToken && totalRead < maxRowsToRead);

    return allRows;
  }

  /**
   * 处理行数据（应用偏移和限制）
   *
   * @param rows - 原始数据行
   * @returns any[][] 处理后的数据行
   */
  private processRows(rows: any[][]): any[][] {
    // 应用 dataStartRow 偏移
    // 注意：feishu_bitable_list_records 只返回数据行，不包含表头
    // dataStartRow 表示从第几行开始读取（默认第2行，跳过表头）
    // 由于 API 返回的就是纯数据，所以我们需要从 rows 中跳过前面几行
    if (this.config.dataStartRow > 2) {
      const skipRows = this.config.dataStartRow - 2;
      rows = rows.slice(skipRows);
    }

    // 应用 maxRows 限制
    if (this.config.maxRows !== Infinity) {
      rows = rows.slice(0, this.config.maxRows);
    }

    return rows;
  }

  /**
   * 获取配置的快照
   *
   * @returns AnalyticsConfig 配置副本
   */
  getConfig(): Readonly<AnalyticsConfig> {
    return { ...this.config };
  }

  /**
   * 创建默认工具集
   * 在真实 OpenClaw 环境中，工具函数应该从全局作用域或 SDK 获取
   * 这里提供基础实现，实际使用时会被覆盖
   */
  private createDefaultTools(): FeishuBitableTools {
    return {
      feishu_bitable_get_meta: async (params: { url: string }) => {
        throw new Error(
          "[SpreadsheetReader] 未找到 feishu_bitable_get_meta 工具。请确保在 OpenClaw 环境中运行，或通过依赖注入提供工具实现。"
        );
      },
      feishu_bitable_list_fields: async (params: {
        app_token: string;
        table_id: string;
      }) => {
        throw new Error(
          "[SpreadsheetReader] 未找到 feishu_bitable_list_fields 工具。"
        );
      },
      feishu_bitable_list_records: async (params: {
        app_token: string;
        table_id: string;
        page_size: number;
        page_token?: string;
      }) => {
        throw new Error(
          "[SpreadsheetReader] 未找到 feishu_bitable_list_records 工具。"
        );
      },
    };
  }
}

/**
 * 批量处理器
 */
export class BatchSpreadsheetReader {
  private readers: SpreadsheetReader[];

  constructor(configs: AnalyticsConfig[], tools?: Partial<FeishuBitableTools>) {
    this.readers = configs.map((config) => new SpreadsheetReader(config, tools));
  }

  /**
   * 批量读取所有表格
   *
   * @returns Promise<BatchResult[]> 批量结果
   */
  async readAll(): Promise<BatchResult[]> {
    const results: BatchResult[] = [];

    for (let i = 0; i < this.readers.length; i++) {
      const reader = this.readers[i];
      const config = reader.getConfig();

      try {
        const data = await reader.read();
        results.push({
          spreadsheetId: config.spreadsheetToken,
          sheetId: config.sheetId,
          success: true,
        });
      } catch (error: any) {
        results.push({
          spreadsheetId: config.spreadsheetToken,
          sheetId: config.sheetId,
          success: false,
          error: error.message,
        });
      }
    }

    return results;
  }
}
