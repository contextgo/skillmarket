/**
 * 报告生成器
 *
 * 将数据分析结果生成为 Markdown、HTML 或 JSON 格式的报告
 *
 * @author GOGO & tob-openclaw
 * @license MIT
 */

import {
  DataStats,
  Distribution,
  OutlierResult,
  AnalyticsOptions,
  AnalyticsReport,
} from "./types";

/**
 * 报告生成错误类
 */
export class ReportGenerationError extends Error {
  constructor(
    message: string,
    public code: string = "REPORT_ERROR",
    public details?: any
  ) {
    super(message);
    this.name = "ReportGenerationError";
  }
}

/**
 * 报告生成器
 *
 * 支持多种输出格式：Markdown、HTML、JSON
 */
export class Reporter {
  private schema: DataStats;
  private options: Required<AnalyticsOptions>;

  constructor(
    schema: DataStats,
    options: AnalyticsOptions = {}
  ) {
    this.schema = schema;
    this.options = {
      includeDistribution: options.includeDistribution ?? true,
      includeOutliers: options.includeOutliers ?? true,
      outlierMethod: options.outlierMethod ?? "iqr",
      outlierThreshold: options.outlierThreshold ?? 1.5,
      outputFormat: options.outputFormat ?? "markdown",
      maxSampleSize: options.maxSampleSize ?? 10,
    };
  }

  /**
   * 生成 Markdown 报告
   *
   * @param customOptions - 覆盖默认选项
   * @returns Markdown 格式的报告
   */
  generateMarkdown(customOptions?: Partial<AnalyticsOptions>): string {
    const options = { ...this.options, ...customOptions };
    const schema = this.schema;

    const lines: string[] = [];

    // 标题
    lines.push(`# 飞书表格分析报告`);
    lines.push(`\n生成时间：${new Date().toLocaleString()}`);
    lines.push("");

    // 数据概览
    lines.push("## 📊 数据概览\n");
    lines.push("| 指标 | 数值 |");
    lines.push("|------|------|");
    lines.push(`| 总行数 | ${schema.totalRows.toLocaleString()} |`);
    lines.push(`| 总列数 | ${schema.totalColumns.toLocaleString()} |`);
    lines.push(`| 完整行数 | ${schema.completeRows.toLocaleString()} |`);
    lines.push(`| 数据完整率 | ${(schema.completeness * 100).toFixed(1)}% |`);
    lines.push(`| 字段类型分布 | ${this.formatTypeDistribution(schema.typeDistribution)} |`);
    lines.push("");

    // 警告信息
    if (schema.warnings.length > 0) {
      lines.push("## ⚠️ 警告信息\n");
      for (const warning of schema.warnings) {
        lines.push(`- ⚠️ ${warning}`);
      }
      lines.push("");
    }

    // 字段详情
    lines.push("## 📋 字段详情\n");
    lines.push(this.generateFieldTable(schema.fields));

    // 分布分析
    if (options.includeDistribution) {
      lines.push("## 📈 分布分析\n");
      // 这里可以添加分布信息，但需要从 analyzer 传入
      lines.push("*分布分析需要单独调用 analyzer.distributions() 方法*");
      lines.push("");
    }

    // 异常检测
    if (options.includeOutliers) {
      lines.push("## 🔍 异常检测\n");
      lines.push("*异常检测需要单独调用 analyzer.detectOutliers() 方法*");
      lines.push("");
    }

    // 采样数据
    lines.push("## 📑 数据样本（前 10 行）\n");
    lines.push(this.generateSampleTable(schema.fields));

    return lines.join("\n");
  }

  /**
   * 生成 HTML 报告
   *
   * @param customOptions - 覆盖默认选项
   * @returns HTML 格式的报告
   */
  generateHTML(customOptions?: Partial<AnalyticsOptions>): string {
    const options = { ...this.options, ...customOptions };
    const schema = this.schema;
    const now = new Date().toLocaleString();

    // HTML 样式
    const styles = `
<style>
  :root {
    --primary-color: #1890ff;
    --success-color: #52c41a;
    --warning-color: #faad14;
    --error-color: #ff4d4f;
    --text-color: #333;
    --bg-color: #f5f5f5;
    --card-bg: #fff;
  }

  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
    margin: 0;
    padding: 20px;
    background-color: var(--bg-color);
    color: var(--text-color);
    line-height: 1.6;
  }

  .container {
    max-width: 1200px;
    margin: 0 auto;
  }

  .header {
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: white;
    padding: 30px;
    border-radius: 10px;
    margin-bottom: 20px;
  }

  .header h1 {
    margin: 0 0 10px 0;
    font-size: 28px;
  }

  .header p {
    margin: 0;
    opacity: 0.9;
  }

  .card {
    background: var(--card-bg);
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  }

  .card h2 {
    margin-top: 0;
    color: var(--primary-color);
    font-size: 20px;
    border-bottom: 2px solid var(--primary-color);
    padding-bottom: 10px;
  }

  .stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 15px;
    margin-bottom: 20px;
  }

  .stat-item {
    background: #f0f7ff;
    padding: 15px;
    border-radius: 6px;
    border-left: 4px solid var(--primary-color);
  }

  .stat-item .label {
    font-size: 12px;
    color: #666;
    text-transform: uppercase;
    margin-bottom: 5px;
  }

  .stat-item .value {
    font-size: 24px;
    font-weight: bold;
    color: var(--primary-color);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin: 10px 0;
  }

  th, td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #e8e8e8;
  }

  th {
    background: #fafafa;
    font-weight: 600;
    color: #333;
  }

  tr:hover {
    background: #f5f5f5;
  }

  .warning-list {
    list-style: none;
    padding: 0;
  }

  .warning-list li {
    background: #fff7e6;
    border-left: 4px solid var(--warning-color);
    padding: 12px;
    margin-bottom: 8px;
    border-radius: 4px;
  }

  .type-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 500;
  }

  .type-string { background: #e6f7ff; color: #1890ff; }
  .type-number { background: #f6ffed; color: #52c41a; }
  .type-date { background: #fff7e6; color: #faad14; }
  .type-boolean { background: #f9f0ff; color: #722ed1; }
  .type-mixed { background: #fff1f0; color: #ff4d4f; }

  .progress-bar {
    width: 100%;
    height: 8px;
    background: #f0f0f0;
    border-radius: 4px;
    overflow: hidden;
  }

  .progress-fill {
    height: 100%;
    background: var(--success-color);
    transition: width 0.3s ease;
  }

  @media (max-width: 768px) {
    body { padding: 10px; }
    .stats-grid { grid-template-columns: 1fr 1fr; }
    table { font-size: 14px; }
    th, td { padding: 8px; }
  }
</style>
    `;

    const html = `
<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>飞书表格分析报告</title>
  ${styles}
</head>
<body>
  <div class="container">
    <!-- Header -->
    <div class="header">
      <h1>📊 飞书表格分析报告</h1>
      <p>生成时间：${now}</p>
    </div>

    <!-- 数据概览 -->
    <div class="card">
      <h2>📈 数据概览</h2>
      <div class="stats-grid">
        <div class="stat-item">
          <div class="label">总行数</div>
          <div class="value">${schema.totalRows.toLocaleString()}</div>
        </div>
        <div class="stat-item">
          <div class="label">总列数</div>
          <div class="value">${schema.totalColumns.toLocaleString()}</div>
        </div>
        <div class="stat-item">
          <div class="label">完整行数</div>
          <div class="value">${schema.completeRows.toLocaleString()}</div>
        </div>
        <div class="stat-item">
          <div class="label">数据完整率</div>
          <div class="value">${(schema.completeness * 100).toFixed(1)}%</div>
          <div class="progress-bar">
            <div class="progress-fill" style="width: ${schema.completeness * 100}%"></div>
          </div>
        </div>
      </div>
      <p><strong>类型分布：</strong>${this.formatTypeDistribution(schema.typeDistribution)}</p>
    </div>

    <!-- 警告信息 -->
    ${schema.warnings.length > 0 ? `
    <div class="card">
      <h2>⚠️ 警告信息</h2>
      <ul class="warning-list">
        ${schema.warnings.map(w => `<li>⚠️ ${w}</li>`).join("\n")}
      </ul>
    </div>
    ` : ""}

    <!-- 字段详情 -->
    <div class="card">
      <h2>📋 字段详情</h2>
      ${this.generateFieldTableHTML(schema.fields)}
    </div>

    <!-- 数据样本 -->
    <div class="card">
      <h2>📑 数据样本</h2>
      ${this.generateSampleTableHTML(schema.fields)}
    </div>

    <!-- 页脚 -->
    <div style="text-align: center; color: #999; font-size: 12px; margin-top: 30px;">
      由 feishu-spreadsheet-analytics 生成
    </div>
  </div>

  <!-- Chart.js for future charts -->
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
</body>
</html>
    `;

    return html;
  }

  /**
   * 转换为 JSON 报告
   *
   * @returns AnalyticsReport JSON 对象
   */
  toJSON(): AnalyticsReport {
    return {
      spreadsheetId: this.schema.fields ? Object.keys(this.schema.fields)[0] || "unknown" : "unknown",
      generatedAt: new Date().toISOString(),
      schema: this.schema,
      distributions: [], // 需要外部传入
      outliers: [], // 需要外部传入
    };
  }

  /**
   * 生成字段详情 Markdown 表格
   *
   * @param fields - 字段统计
   * @returns Markdown 表格字符串
   */
  private generateFieldTable(fields: Record<string, any>): string {
    const headers = ["字段名", "类型", "空值", "唯一值", "统计信息"];
    const rows = Object.entries(fields).map(([name, field]: [string, any]) => {
      const typeBadge = this.getTypeBadge(field.type);
      const nullInfo = field.nullable
        ? `${field.nullCount} (${((field.nullCount / this.schema.totalRows) * 100).toFixed(1)}%)`
        : "0";
      const uniqueInfo = field.unique
        ? "✓ 唯一"
        : `${field.uniqueCount} 个唯一值`;

      let stats = "";
      switch (field.type) {
        case "number":
          stats = `min: ${field.min?.toFixed(2)}, max: ${field.max?.toFixed(2)}, mean: ${field.mean?.toFixed(2)}`;
          break;
        case "date":
          stats = field.dateFormat || "日期";
          break;
        case "boolean":
          stats = `true: ${field.trueCount}, false: ${field.falseCount}`;
          break;
        case "string":
          stats = `maxLen: ${field.maxLength}, avgLen: ${field.avgLength}`;
          break;
        default:
          stats = "混合类型";
      }

      return [name, typeBadge, nullInfo, uniqueInfo, stats];
    });

    return this.formatTable(headers, rows);
  }

  /**
   * 生成字段详情 HTML 表格
   *
   * @param fields - 字段统计
   * @returns HTML 表格
   */
  private generateFieldTableHTML(fields: Record<string, any>): string {
    const rows = Object.entries(fields).map(([name, field]: [string, any]) => {
      const typeClass = `type-${field.type}`;
      const nullRate = ((field.nullCount / this.schema.totalRows) * 100).toFixed(1);

      let stats = "";
      switch (field.type) {
        case "number":
          stats = `
            <div>最小值：${field.min?.toFixed(2) ?? "N/A"}</div>
            <div>最大值：${field.max?.toFixed(2) ?? "N/A"}</div>
            <div>均值：${field.mean?.toFixed(2) ?? "N/A"}</div>
            <div>标准差：${field.std?.toFixed(2) ?? "N/A"}</div>
          `;
          break;
        case "date":
          stats = `<div>格式：${field.dateFormat || "未知"}</div>`;
          break;
        case "boolean":
          stats = `
            <div>True: ${field.trueCount ?? 0}</div>
            <div>False: ${field.falseCount ?? 0}</div>
          `;
          break;
        case "string":
          stats = `
            <div>最大长度：${field.maxLength ?? "N/A"}</div>
            <div>平均长度：${field.avgLength ?? "N/A"}</div>
          `;
          break;
        default:
          stats = `<div style="color: #ff4d4f;">混合类型，建议检查</div>`;
      }

      return `
        <tr>
          <td><strong>${name}</strong></td>
          <td><span class="type-badge ${typeClass}">${field.type}</span></td>
          <td>
            ${field.nullCount} (${nullRate}%)
            <div class="progress-bar" style="margin-top: 5px;">
              <div class="progress-fill" style="width: ${nullRate}%; background: ${nullRate > 50 ? '#ff4d4f' : '#52c41a'};"></div>
            </div>
          </td>
          <td>${field.unique ? "✓ 唯一" : field.uniqueCount}</td>
          <td>${stats}</td>
        </tr>
      `;
    }).join("");

    return `
      <table>
        <thead>
          <tr>
            <th>字段名</th>
            <th>类型</th>
            <th>空值数量 (比例)</th>
            <th>唯一值</th>
            <th>统计信息</th>
          </tr>
        </thead>
        <tbody>
          ${rows}
        </tbody>
      </table>
    `;
  }

  /**
   * 生成样本数据 Markdown 表格
   *
   * @param fields - 字段统计
   * @returns Markdown 表格
   */
  private generateSampleTable(fields: Record<string, any>): string {
    const headers = Object.keys(fields);
    const sampleSize = Math.min(
      this.options.maxSampleSize,
      this.schema.totalRows
    );

    // 这里我们无法访问原始数据，所以只显示表头
    return `*样本数据需要原始 rows 数组，请在生成报告前合并 analyzer 结果*`;
  }

  /**
   * 生成样本数据 HTML 表格
   *
   * @param fields - 字段统计
   * @returns HTML 表格
   */
  private generateSampleTableHTML(fields: Record<string, any>): string {
    return `
      <p style="color: #999;">样本数据需要原始数据行，请在生成报告时传入完整的分析结果。</p>
    `;
  }

  /**
   * 格式化类型分布
   *
   * @param distribution - 类型分布对象
   * @returns 格式化字符串
   */
  private formatTypeDistribution(
    distribution: Record<string, number>
  ): string {
    return Object.entries(distribution)
      .filter(([, count]) => count > 0)
      .map(([type, count]) => `${type}(${count})`)
      .join(", ");
  }

  /**
   * 获取类型徽章 Markdown
   *
   * @param type - 字段类型
   * @returns Markdown 徽章
   */
  private getTypeBadge(type: string): string {
    const badges: Record<string, string> = {
      string: "`string`",
      number: "`number`",
      date: "`date`",
      boolean: "`boolean`",
      mixed: "`mixed`",
    };
    return badges[type] || `\`${type}\``;
  }

  /**
   * 格式化 Markdown 表格
   *
   * @param headers - 表头
   * @param rows - 行数据
   * @returns Markdown 表格字符串
   */
  private formatTable(headers: string[], rows: string[][]): string {
    const lines: string[] = [];

    // 表头
    lines.push(`| ${headers.join(" | ")} |`);
    lines.push(`|${headers.map(() => "---").join("|")}|`);

    // 数据行
    for (const row of rows) {
      lines.push(`| ${row.join(" | ")} |`);
    }

    return lines.join("\n");
  }

  /**
   * 附加分布数据（用于生成完整报告）
   *
   * @param distributions - 分布分析结果
   * @returns Reporter（链式调用）
   */
  withDistributions(distributions: Distribution[]): this {
    // 存储分布数据供 generateMarkdown 使用
    (this as any)._distributions = distributions;
    return this;
  }

  /**
   * 附加异常检测结果（用于生成完整报告）
   *
   * @param outliers - 异常检测结果
   * @returns Reporter（链式调用）
   */
  withOutliers(outliers: OutlierResult[]): this {
    (this as any)._outliers = outliers;
    return this;
  }

  /**
   * 生成完整报告（包含分布和异常检测）
   *
   * @param format - 输出格式
   * @returns 报告字符串
   */
  generateFullReport(format: "markdown" | "html" = "markdown"): string {
    const distributions = (this as any)._distributions || [];
    const outliers = (this as any)._outliers || [];

    if (format === "markdown") {
      const md = this.generateMarkdown();

      // 附加分布信息
      if (distributions.length > 0) {
        const distLines = distributions
          .map((dist) => {
            if (dist.type === "numeric" && dist.bins) {
              return `\n### ${dist.field} (数值分布)\n\n| 区间 | 数量 | 百分比 |\n|------|------|--------|\n${dist.bins.map(b => `| ${b.range} | ${b.count} | ${b.percentage}% |`).join("\n")}\n`;
            }
            if (dist.type === "categorical" && dist.topValues) {
              return `\n### ${dist.field} (值分布)\n\n| 值 | 数量 | 百分比 |\n|------|------|--------|\n${dist.topValues.map(v => `| ${v.value} | ${v.count} | ${v.percentage}% |`).join("\n")}\n`;
            }
            return "";
          })
          .join("\n");

        return md.replace("<!-- DISTRIBUTIONS -->", distLines);
      }

      // 附加异常信息
      if (outliers.length > 0) {
        const outlierLines = outliers
          .map((out) => `- **${out.field}** (${out.method}, 阈值=${out.threshold}): ${out.outliers.length} 个异常值，行号: ${out.outliers.join(", ")}`)
          .join("\n");

        return md.replace("<!-- OUTLIERS -->", `\n### 异常值详情\n\n${outlierLines}\n`);
      }

      return md;
    } else {
      return this.generateHTML();
    }
  }
}

/**
 * 快速生成报告
 *
 * @param schema - 数据统计
 * @param format - 输出格式
 * @returns 报告字符串
 */
export function generateReport(
  schema: DataStats,
  format: "markdown" | "html" = "markdown"
): string {
  const reporter = new Reporter(schema);
  return reporter.generateFullReport(format);
}
