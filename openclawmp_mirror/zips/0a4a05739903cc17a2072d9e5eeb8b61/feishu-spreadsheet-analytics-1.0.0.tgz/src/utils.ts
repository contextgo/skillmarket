/**
 * 工具函数模块 - 提供类型推断、统计计算、日期检测等核心工具
 *
 * @author GOGO & tob-openclaw
 * @license MIT
 */

import { FieldType } from "./types";

/**
 * 推断值的类型
 * 自动检测字符串、数字、布尔值、日期格式
 *
 * @param value - 待检测的值
 * @returns 推断出的字段类型
 */
export function inferType(value: any): FieldType {
  // 处理 null/undefined
  if (value === null || value === undefined) {
    return "string"; // 空值暂归类为 string，由 nullable 标记
  }

  // 布尔值检测
  if (typeof value === "boolean") {
    return "boolean";
  }

  // 数字检测
  if (typeof value === "number") {
    return "number";
  }

  // 字符串类型检测
  if (typeof value === "string") {
    // 尝试解析为数字
    const num = Number(value);
    if (!isNaN(num) && value.trim() !== "" && value.includes(".")) {
      return "number";
    }

    // 尝试解析为布尔值
    const lower = value.toLowerCase().trim();
    if (lower === "true" || lower === "false") {
      return "boolean";
    }

    // 尝试解析为日期
    if (detectDateFormat([value]) !== null) {
      return "date";
    }

    return "string";
  }

  // 其他类型暂视为字符串
  return "string";
}

/**
 * 检测日期格式
 * 从一组字符串中识别常见的日期格式
 *
 * @param values - 字符串数组样本
 * @returns 检测到的日期格式，或 null（无法识别）
 */
export function detectDateFormat(values: string[]): string | null {
  if (!values || values.length === 0) {
    return null;
  }

  // 过滤空值
  const nonEmpty = values.filter(v => v && v.trim() !== "");
  if (nonEmpty.length === 0) {
    return null;
  }

  // 常见日期格式正则表达式
  const datePatterns = [
    { pattern: /^\d{4}-\d{2}-\d{2}$/, format: "YYYY-MM-DD" },
    { pattern: /^\d{2}\/\d{2}\/\d{4}$/, format: "MM/DD/YYYY" },
    { pattern: /^\d{4}\/\d{2}\/\d{2}$/, format: "YYYY/MM/DD" },
    { pattern: /^\d{2}-\d{2}-\d{4}$/, format: "DD-MM-YYYY" },
    { pattern: /^\d{4}\.\d{2}\.\d{2}$/, format: "YYYY.MM.DD" },
    { pattern: /^\d{2}\.\d{2}\.\d{4}$/, format: "DD.MM.YYYY" },
    { pattern: /^\d{4}年\d{2}月\d{2}日$/, format: "YYYY年MM月DD日" },
    { pattern: /^\d{2}:\d{2}:\d{2}$/, format: "HH:MM:SS" },
    { pattern: /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z?$/, format: "ISO8601" },
  ];

  // 统计每种格式的匹配数量
  const formatCounts: Record<string, number> = {};

  for (const value of nonEmpty) {
    const str = value.trim();
    for (const { pattern, format } of datePatterns) {
      if (pattern.test(str)) {
        formatCounts[format] = (formatCounts[format] || 0) + 1;
        break;
      }
    }
  }

  // 找到匹配度最高的格式（至少匹配 50% 的非空值）
  const total = nonEmpty.length;
  const threshold = total * 0.5;

  let bestFormat: string | null = null;
  let bestCount = 0;

  for (const [format, count] of Object.entries(formatCounts)) {
    if (count > bestCount && count >= threshold) {
      bestFormat = format;
      bestCount = count;
    }
  }

  return bestFormat;
}

/**
 * 计算数值数组的统计指标
 *
 * @param numbers - 数值数组
 * @returns 统计对象（均值、中位数、标准差、最小值、最大值）
 */
export function calculateStats(numbers: number[]): {
  mean: number;
  median: number;
  std: number;
  min: number;
  max: number;
} {
  if (numbers.length === 0) {
    return { mean: 0, median: 0, std: 0, min: 0, max: 0 };
  }

  // 排序（用于中位数和极值）
  const sorted = [...numbers].sort((a, b) => a - b);

  // 均值
  const sum = sorted.reduce((acc, val) => acc + val, 0);
  const mean = sum / sorted.length;

  // 中位数
  const mid = Math.floor(sorted.length / 2);
  const median =
    sorted.length % 2 === 0
      ? (sorted[mid - 1] + sorted[mid]) / 2
      : sorted[mid];

  // 标准差
  const variance =
    sorted.reduce((acc, val) => acc + Math.pow(val - mean, 2), 0) /
    sorted.length;
  const std = Math.sqrt(variance);

  // 最小/最大值
  const min = sorted[0];
  const max = sorted[sorted.length - 1];

  return { mean, median, std, min, max };
}

/**
 * 使用 IQR 方法检测异常值
 *
 * @param numbers - 数值数组
 * @param threshold - IQR 倍数阈值（默认 1.5）
 * @returns 异常值的索引数组
 */
export function iqrOutliers(
  numbers: number[],
  threshold: number = 1.5
): number[] {
  if (numbers.length < 4) {
    return []; // 数据太少，无法可靠检测
  }

  const sorted = numbers
    .map((val, idx) => ({ val, idx }))
    .sort((a, b) => a.val - b.val);

  const values = sorted.map(s => s.val);
  const q1Index = Math.floor(values.length * 0.25);
  const q3Index = Math.floor(values.length * 0.75);

  const q1 = values[q1Index];
  const q3 = values[q3Index];
  const iqr = q3 - q1;

  if (iqr === 0) {
    return []; // IQR 为 0，无明显异常
  }

  const lowerBound = q1 - threshold * iqr;
  const upperBound = q3 + threshold * iqr;

  // 找出超出边界的值及其索引
  return sorted
    .filter(s => s.val < lowerBound || s.val > upperBound)
    .map(s => s.idx);
}

/**
 * 使用 Z-score 方法检测异常值
 *
 * @param numbers - 数值数组
 * @param threshold - Z-score 阈值（默认 3）
 * @returns 异常值的索引数组
 */
export function zscoreOutliers(
  numbers: number[],
  threshold: number = 3
): number[] {
  if (numbers.length < 10) {
    return []; // 数据太少，Z-score 不可靠
  }

  const { mean, std } = calculateStats(numbers);

  if (std === 0) {
    return []; // 标准差为 0，所有值相同
  }

  return numbers.reduce((acc: number[], val, idx) => {
    const zscore = Math.abs((val - mean) / std);
    if (zscore > threshold) {
      acc.push(idx);
    }
    return acc;
  }, []);
}

/**
 * 格式化数字显示
 * 添加千位分隔符，保留合适的小数位数
 *
 * @param num - 待格式化的数字
 * @returns 格式化后的字符串
 */
export function formatNumber(num: number): string {
  if (typeof num !== "number" || isNaN(num)) {
    return "N/A";
  }

  // 整数直接使用 toLocaleString
  if (Number.isInteger(num)) {
    return num.toLocaleString();
  }

  // 小数根据大小决定保留位数
  const absNum = Math.abs(num);
  if (absNum >= 1000) {
    return num.toLocaleString(undefined, { maximumFractionDigits: 2 });
  } else if (absNum >= 1) {
    return num.toLocaleString(undefined, { maximumFractionDigits: 4 });
  } else if (absNum > 0) {
    // 小于 1 的小数，最多保留 6 位
    return num.toLocaleString(undefined, { maximumFractionDigits: 6 });
  } else {
    return num.toLocaleString();
  }
}

/**
 * 安全地转换值为指定类型
 *
 * @param value - 原始值
 * @param targetType - 目标类型
 * @returns 转换后的值，转换失败返回原始值
 */
export function convertToType(
  value: any,
  targetType: FieldType
): any {
  if (value === null || value === undefined) {
    return value;
  }

  try {
    switch (targetType) {
      case "number":
        const num = Number(value);
        return isNaN(num) ? value : num;
      case "boolean":
        if (typeof value === "string") {
          const lower = value.toLowerCase().trim();
          if (lower === "true") return true;
          if (lower === "false") return false;
        }
        return Boolean(value);
      case "date":
        const date = new Date(value);
        return isNaN(date.getTime()) ? value : date;
      default:
        return String(value);
    }
  } catch {
    return value;
  }
}

/**
 * 计算唯一值比例
 *
 * @param values - 值数组
 * @returns 唯一值比例 (0-1)
 */
export function uniquenessRatio(values: any[]): number {
  if (!values || values.length === 0) {
    return 0;
  }

  const unique = new Set(values.filter(v => v !== null && v !== undefined));
  return unique.size / values.length;
}

/**
 * 计算空值比例
 *
 * @param values - 值数组
 * @returns 空值比例 (0-1)
 */
export function nullRatio(values: any[]): number {
  if (!values || values.length === 0) {
    return 0;
  }

  const nullCount = values.filter(v => v === null || v === undefined).length;
  return nullCount / values.length;
}

/**
 * 获取样本值（去重、去空）
 *
 * @param values - 值数组
 * @param maxSamples - 最大样本数
 * @returns 样本值数组
 */
export function getSamples(
  values: any[],
  maxSamples: number = 10
): any[] {
  if (!values || values.length === 0) {
    return [];
  }

  const set = new Set(values.filter(v => v !== null && v !== undefined));
  return Array.from(set).slice(0, maxSamples);
}
