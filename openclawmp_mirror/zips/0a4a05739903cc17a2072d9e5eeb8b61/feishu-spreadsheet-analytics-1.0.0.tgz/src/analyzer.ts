/**
 * 数据分析引擎
 *
 * 提供字段类型推断、统计计算、分布分析、异常检测等功能
 *
 * @author GOGO & tob-openclaw
 * @license MIT
 */

import {
  ParsedData,
  DataStats,
  FieldSchema,
  Distribution,
  OutlierResult,
  AnalyticsOptions,
} from "./types";
import {
  inferType,
  detectDateFormat,
  calculateStats,
  iqrOutliers,
  zscoreOutliers,
  uniquenessRatio,
  nullRatio,
  getSamples,
  formatNumber,
} from "./utils";

/**
 * 数据分析错误类
 */
export class AnalysisError extends Error {
  constructor(
    message: string,
    public code: string = "ANALYSIS_ERROR",
    public field?: string,
    public details?: any
  ) {
    super(message);
    this.name = "AnalysisError";
  }
}

/**
 * 数据分析器
 *
 * 对 ParsedData 进行统计分析，生成字段级别的 Schema 和整体统计
 */
export class DataAnalyzer {
  private data: ParsedData;
  private schemaCache?: DataStats;
  private fieldStatsCache?: Record<string, FieldSchema>;

  constructor(data: ParsedData) {
    if (!data.headers || !Array.isArray(data.headers)) {
      throw new AnalysisError("无效的数据格式：缺少 headers", "INVALID_DATA");
    }
    if (!data.rows || !Array.isArray(data.rows)) {
      throw new AnalysisError("无效的数据格式：缺少 rows", "INVALID_DATA");
    }

    this.data = data;
  }

  /**
   * 推断数据结构（Schema）
   * 自动识别字段类型、空值、唯一性等
   *
   * @returns DataStats 完整的统计信息
   */
  inferSchema(): DataStats {
    if (this.schemaCache) {
      return this.schemaCache;
    }

    const headers = this.data.headers;
    const rows = this.data.rows;
    const fieldStats: Record<string, FieldSchema> = {};
    const typeDistribution: Record<string, number> = {
      string: 0,
      number: 0,
      date: 0,
      boolean: 0,
      mixed: 0,
    };

    // 遍历每个字段
    for (let colIdx = 0; colIdx < headers.length; colIdx++) {
      const fieldName = headers[colIdx];
      const values = rows.map((row) => row[colIdx]);

      // 推断类型
      const type = this.inferColumnType(values);

      // 计算统计信息
      const stats = this.calculateFieldStats(fieldName, values, type);

      fieldStats[fieldName] = stats;
      typeDistribution[type]++;

      // 如果有混合类型，标记为 mixed
      if (type === "mixed") {
        typeDistribution.mixed++;
      }
    }

    // 计算整体统计
    const totalRows = rows.length;
    const completeRows = this.countCompleteRows(rows);
    const completeness = totalRows > 0 ? completeRows / totalRows : 0;

    // 生成警告
    const warnings = this.generateWarnings(fieldStats, {
      totalRows,
      completeRows,
      completeness,
    });

    this.schemaCache = {
      totalRows,
      totalColumns: headers.length,
      completeRows,
      completeness,
      fields: fieldStats,
      typeDistribution,
      warnings,
    };

    return this.schemaCache;
  }

  /**
   * 整体统计（便捷方法）
   * 等同于 inferSchema() 的返回，但只计算一次
   *
   * @returns DataStats
   */
  basicStats(): DataStats {
    return this.inferSchema();
  }

  /**
   * 字段级统计
   *
   * @returns Record<string, FieldSchema> 字段名到统计的映射
   */
  fieldStatistics(): Record<string, FieldSchema> {
    if (!this.fieldStatsCache) {
      const schema = this.inferSchema();
      this.fieldStatsCache = schema.fields;
    }
    return this.fieldStatsCache;
  }

  /**
   * 分布分析
   *
   * @param limit - 分类字段的最大分类数
   * @returns Distribution[] 分布结果数组
   */
  distributions(limit: number = 10): Distribution[] {
    const schema = this.inferSchema();
    const distributions: Distribution[] = [];
    const headers = this.data.headers;

    for (let colIdx = 0; colIdx < headers.length; colIdx++) {
      const fieldName = headers[colIdx];
      const field = schema.fields[fieldName];

      if (!field) continue;

      const values = this.data.rows.map((row) => row[colIdx]);
      const distribution = this.analyzeDistribution(fieldName, values, field, limit);

      if (distribution) {
        distributions.push(distribution);
      }
    }

    return distributions;
  }

  /**
   * 异常检测
   *
   * @param options - 检测选项
   * @returns OutlierResult[] 异常结果数组
   */
  detectOutliers(options: {
    method?: "iqr" | "zscore";
    threshold?: number;
    fields?: string[]; // 只检测指定字段
  } = {}): OutlierResult[] {
    const {
      method = "iqr",
      threshold = method === "iqr" ? 1.5 : 3,
      fields,
    } = options;

    const schema = this.inferSchema();
    const outliers: OutlierResult[] = [];

    // 确定要检测的字段（只检测数值类型）
    const targetFields = fields
      ? fields.filter((f) => schema.fields[f]?.type === "number")
      : Object.entries(schema.fields)
          .filter(([, field]) => field.type === "number")
          .map(([name]) => name);

    for (const fieldName of targetFields) {
      const field = schema.fields[fieldName];
      if (!field || field.type !== "number") continue;

      // 获取数值数据
      const colIdx = this.data.headers.indexOf(fieldName);
      const values = this.data.rows
        .map((row) => row[colIdx])
        .filter((v) => typeof v === "number" && !isNaN(v));

      if (values.length < 10) {
        continue; // 数据太少，跳过异常检测
      }

      let outlierIndices: number[];

      if (method === "iqr") {
        outlierIndices = iqrOutliers(values, threshold);
      } else {
        outlierIndices = zscoreOutliers(values, threshold);
      }

      if (outlierIndices.length > 0) {
        outliers.push({
          field: fieldName,
          method,
          outliers: outlierIndices,
          threshold,
        });
      }
    }

    return outliers;
  }

  /**
   * 推断列类型
   *
   * @param values - 列值数组
   * @returns "string" | "number" | "date" | "boolean" | "mixed"
   */
  private inferColumnType(values: any[]): string {
    // 过滤空值
    const nonNull = values.filter((v) => v !== null && v !== undefined);

    if (nonNull.length === 0) {
      return "string"; // 全是空值，默认为字符串
    }

    // 尝试推断每个非空值的类型
    const types = nonNull.map((v) => inferType(v));

    // 如果所有类型相同，直接返回
    const firstType = types[0];
    if (types.every((t) => t === firstType)) {
      return firstType;
    }

    // 如果有混合类型，检查是否主要是数字
    const numberCount = types.filter((t) => t === "number").length;
    if (numberCount / types.length >= 0.8) {
      return "number"; // 主要是数字，视为数值型
    }

    return "mixed";
  }

  /**
   * 计算字段统计
   *
   * @param fieldName - 字段名
   * @param values - 字段值数组
   * @param type - 推断的类型
   * @returns FieldSchema
   */
  private calculateFieldStats(
    fieldName: string,
    values: any[],
    type: string
  ): FieldSchema {
    const nonNull = values.filter((v) => v !== null && v !== undefined);
    const nullCount = values.length - nonNull.length;

    const baseStats: FieldSchema = {
      name: fieldName,
      type: type as any,
      nullable: nullCount > 0,
      nullCount,
      unique: false,
      uniqueCount: 0,
      sample: getSamples(nonNull, 5),
    };

    // 计算唯一值
    const uniqueSet = new Set(nonNull.map(String));
    baseStats.uniqueCount = uniqueSet.size;
    baseStats.unique = uniqueSet.size === nonNull.length;

    switch (type) {
      case "number": {
        const numbers = nonNull.filter((v) => typeof v === "number");
        if (numbers.length > 0) {
          const stats = calculateStats(numbers);
          baseStats.min = stats.min;
          baseStats.max = stats.max;
          baseStats.mean = Number(stats.mean.toFixed(4));
          baseStats.median = Number(stats.median.toFixed(4));
          baseStats.std = Number(stats.std.toFixed(4));
        }
        break;
      }

      case "date": {
        // 尝试检测日期格式
        const strings = nonNull.map((v) => String(v));
        const dateFormat = detectDateFormat(strings);
        if (dateFormat) {
          baseStats.dateFormat = dateFormat;
        }
        break;
      }

      case "boolean": {
        const trueCount = nonNull.filter(
          (v) => v === true || String(v).toLowerCase() === "true"
        ).length;
        baseStats.trueCount = trueCount;
        baseStats.falseCount = nonNull.length - trueCount;
        break;
      }

      case "string": {
        const lengths = nonNull.map((v) => String(v).length);
        if (lengths.length > 0) {
          baseStats.maxLength = Math.max(...lengths);
          baseStats.avgLength = Number(
            (lengths.reduce((a, b) => a + b, 0) / lengths.length).toFixed(2)
          );
        }
        break;
      }

      default: {
        // mixed 类型，不做额外统计
        break;
      }
    }

    return baseStats;
  }

  /**
   * 统计完整行数（无空值的行）
   *
   * @param rows - 所有行数据
   * @returns 完整行数
   */
  private countCompleteRows(rows: any[][]): number {
    return rows.filter((row) => !row.some((cell) => cell === null || cell === undefined)).length;
  }

  /**
   * 生成警告信息
   *
   * @param fieldStats - 字段统计
   * @param overall - 整体统计
   * @returns 警告数组
   */
  private generateWarnings(
    fieldStats: Record<string, FieldSchema>,
    overall: { totalRows: number; completeRows: number; completeness: number }
  ): string[] {
    const warnings: string[] = [];

    // 完整性警告
    if (overall.completeness < 0.8) {
      warnings.push(
        `数据完整率较低：${(overall.completeness * 100).toFixed(1)}%，建议检查缺失值`
      );
    }

    // 字段级警告
    for (const [name, stats] of Object.entries(fieldStats)) {
      const nullRate = stats.nullCount / overall.totalRows;

      // 高缺失率警告
      if (nullRate > 0.5) {
        warnings.push(
          `字段 "${name}" 缺失率过高：${(nullRate * 100).toFixed(1)}%`
        );
      }

      // 唯一性警告（可能为 ID 字段）
      if (stats.unique && overall.totalRows > 1) {
        warnings.push(`字段 "${name}" 所有值唯一，可能是主键或 ID 字段`);
      }

      // 混合类型警告
      if (stats.type === "mixed") {
        warnings.push(`字段 "${name}" 包含混合数据类型，建议检查清洗`);
      }
    }

    return warnings;
  }

  /**
   * 分析单个字段的分布
   *
   * @param fieldName - 字段名
   * @param values - 值数组
   * @param field - 字段统计
   * @param limit - 分类限制
   * @returns Distribution | null
   */
  private analyzeDistribution(
    fieldName: string,
    values: any[],
    field: FieldSchema,
    limit: number
  ): Distribution | null {
    const nonNull = values.filter((v) => v !== null && v !== undefined);

    if (nonNull.length === 0) {
      return null;
    }

    switch (field.type) {
      case "number": {
        // 数值分箱
        const numbers = nonNull.filter((v) => typeof v === "number");
        if (numbers.length === 0) return null;

        const { min, max } = field;
        if (min === undefined || max === undefined) return null;

        // 确定分箱数量（Sturges 公式）
        const binCount = Math.min(
          limit || 10,
          Math.ceil(Math.log2(numbers.length)) + 1
        );
        const binWidth = (max - min) / binCount;

        const bins: { range: string; count: number; percentage: number }[] = [];

        for (let i = 0; i < binCount; i++) {
          const binMin = min + i * binWidth;
          const binMax = i === binCount - 1 ? max : min + (i + 1) * binWidth;

          const count = numbers.filter(
            (n) => n >= binMin && (i === binCount - 1 ? n <= binMax : n < binMax)
          ).length;

          bins.push({
            range: `${formatNumber(binMin)} - ${formatNumber(binMax)}`,
            count,
            percentage: Number(((count / numbers.length) * 100).toFixed(1)),
          });
        }

        return {
          type: "numeric",
          field: fieldName,
          bins,
        };
      }

      case "date": {
        // 日期按时间序列统计（简化）
        const dateCounts: Record<string, number> = {};

        for (const val of nonNull) {
          const dateStr = String(val).split("T")[0]; // 取日期部分
          dateCounts[dateStr] = (dateCounts[dateStr] || 0) + 1;
        }

        const timeSeries = Object.entries(dateCounts)
          .map(([date, count]) => ({
            date,
            count,
          }))
          .sort((a, b) => a.date.localeCompare(b.date))
          .slice(0, limit || 30);

        return {
          type: "temporal",
          field: fieldName,
          timeSeries,
        };
      }

      case "boolean": {
        const trueCount = field.trueCount || 0;
        const falseCount = field.falseCount || 0;

        return {
          type: "categorical",
          field: fieldName,
          topValues: [
            { value: "true", count: trueCount, percentage: Number(((trueCount / nonNull.length) * 100).toFixed(1)) },
            { value: "false", count: falseCount, percentage: Number(((falseCount / nonNull.length) * 100).toFixed(1)) },
          ],
        };
      }

      case "string": {
        // 文本字段：Top N 值
        const valueCounts: Record<string, number> = {};

        for (const val of nonNull) {
          const str = String(val);
          valueCounts[str] = (valueCounts[str] || 0) + 1;
        }

        const topValues = Object.entries(valueCounts)
          .sort((a, b) => b[1] - a[1])
          .slice(0, limit || 10)
          .map(([value, count]) => ({
            value,
            count,
            percentage: Number(((count / nonNull.length) * 100).toFixed(1)),
          }));

        return {
          type: "categorical",
          field: fieldName,
          topValues,
        };
      }

      default: {
        // mixed 类型不做分布分析
        return null;
      }
    }
  }
}

/**
 * 获取数据集的统计摘要
 * 便捷函数，用于快速统计
 *
 * @param data - 数据集
 * @returns DataStats
 */
export function analyzeData(data: ParsedData): DataStats {
  const analyzer = new DataAnalyzer(data);
  return analyzer.inferSchema();
}
