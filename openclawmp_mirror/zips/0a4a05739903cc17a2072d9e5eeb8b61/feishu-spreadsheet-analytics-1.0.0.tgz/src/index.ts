/**
 * Feishu Spreadsheet Analytics
 *
 * 飞书表格数据分析技能主入口
 *
 * @author GOGO & tob-openclaw
 * @license MIT
 * @version 1.0.0
 */

export {
  SpreadsheetReader,
  BatchSpreadsheetReader,
  SpreadsheetReadError,
  SpreadsheetNotFoundError,
  SheetNotFoundError,
} from "./reader";

export {
  DataAnalyzer,
  AnalysisError,
  analyzeData,
} from "./analyzer";

export {
  Reporter,
  ReportGenerationError,
  generateReport,
} from "./reporter";

export {
  inferType,
  detectDateFormat,
  calculateStats,
  iqrOutliers,
  zscoreOutliers,
  formatNumber,
  convertToType,
  uniquenessRatio,
  nullRatio,
  getSamples,
} from "./utils";

export type {
  FieldType,
  FieldSchema,
  DataStats,
  Distribution,
  Bin,
  TopValue,
  TimePoint,
  OutlierResult,
  AnalyticsConfig,
  AnalyticsOptions,
  AnalyticsReport,
  BatchResult,
  ParsedData,
} from "./types";

import { SpreadsheetReader } from "./reader";
import { DataAnalyzer } from "./analyzer";
import { Reporter } from "./reporter";
import {
  AnalyticsConfig,
  AnalyticsOptions,
  AnalyticsReport,
  ParsedData,
  Distribution,
  OutlierResult,
} from "./types";

/**
 * 飞书表格分析主类
 *
 * 提供一站式分析接口，封装读取、分析、报告生成完整流程
 */
export class SpreadsheetAnalytics {
  private config: AnalyticsConfig;

  constructor(config: AnalyticsConfig) {
    this.config = config;
  }

  /**
   * 执行完整分析流程
   *
   * @param options - 分析选项
   * @returns Promise<AnalyticsReport> 完整的分析报告
   */
  async analyze(options: AnalyticsOptions = {}): Promise<AnalyticsReport> {
    const startTime = Date.now();
    console.log(`[SpreadsheetAnalytics] 开始分析: ${this.config.spreadsheetToken}`);

    try {
      // 1. 读取数据
      const reader = new SpreadsheetReader(this.config);
      const data = await reader.read();
      console.log(`[SpreadsheetAnalytics] 读取完成: ${data.rows.length} 行, ${data.headers.length} 列`);

      // 2. 分析数据
      const analyzer = new DataAnalyzer(data);
      const schema = analyzer.inferSchema();
      console.log(`[SpreadsheetAnalytics] 分析完成: ${Object.keys(schema.fields).length} 个字段`);

      // 3. 可选：分布分析
      let distributions: Distribution[] = [];
      if (options.includeDistribution !== false) {
        distributions = analyzer.distributions(options.maxSampleSize);
        console.log(`[SpreadsheetAnalytics] 分布分析完成: ${distributions.length} 个字段`);
      }

      // 4. 可选：异常检测
      let outliers: OutlierResult[] = [];
      if (options.includeOutliers !== false) {
        outliers = analyzer.detectOutliers({
          method: options.outlierMethod,
          threshold: options.outlierThreshold,
        });
        const totalOutliers = outliers.reduce((sum, o) => sum + o.outliers.length, 0);
        console.log(`[SpreadsheetAnalytics] 异常检测完成: 发现 ${totalOutliers} 个异常值`);
      }

      // 5. 生成报告
      const reporter = new Reporter(schema, {
        ...options,
        outputFormat: options.outputFormat || "markdown",
      });

      const report: AnalyticsReport = {
        spreadsheetId: this.config.spreadsheetToken,
        sheetId: this.config.sheetId,
        generatedAt: new Date().toISOString(),
        schema,
        distributions: options.includeDistribution ? distributions : undefined,
        outliers: options.includeOutliers ? outliers : undefined,
      };

      // 6. 生成指定格式的输出
      if (options.outputFormat === "html") {
        // 需要生成 HTML
        (report as any).html = reporter
          .withDistributions(distributions)
          .withOutliers(outliers)
          .generateHTML();
      } else {
        // 默认 Markdown
        (report as any).markdown = reporter
          .withDistributions(distributions)
          .withOutliers(outliers)
          .generateMarkdown();
      }

      const duration = Date.now() - startTime;
      console.log(`[SpreadsheetAnalytics] 分析完成，耗时 ${duration}ms`);

      return report;
    } catch (error: any) {
      console.error(`[SpreadsheetAnalytics] 分析失败:`, error);
      throw error;
    }
  }

  /**
   * 仅读取数据（不分析）
   *
   * @returns Promise<ParsedData> 原始数据
   */
  async readOnly(): Promise<ParsedData> {
    const reader = new SpreadsheetReader(this.config);
    return reader.read();
  }

  /**
   * 仅分析数据（假设数据已读取）
   *
   * @param data - 已读取的数据
   * @param options - 分析选项
   * @returns Promise<AnalyticsReport> 分析报告
   */
  async analyzeData(
    data: ParsedData,
    options: AnalyticsOptions = {}
  ): Promise<AnalyticsReport> {
    const analyzer = new DataAnalyzer(data);
    const schema = analyzer.inferSchema();

    let distributions: Distribution[] = [];
    if (options.includeDistribution !== false) {
      distributions = analyzer.distributions(options.maxSampleSize);
    }

    let outliers: OutlierResult[] = [];
    if (options.includeOutliers !== false) {
      outliers = analyzer.detectOutliers({
        method: options.outlierMethod,
        threshold: options.outlierThreshold,
      });
    }

    const reporter = new Reporter(schema, options);

    return {
      spreadsheetId: this.config.spreadsheetToken,
      sheetId: this.config.sheetId,
      generatedAt: new Date().toISOString(),
      schema,
      distributions: options.includeDistribution ? distributions : undefined,
      outliers: options.includeOutliers ? outliers : undefined,
    };
  }

  /**
   * 获取当前配置
   *
   * @returns AnalyticsConfig
   */
  getConfig(): Readonly<AnalyticsConfig> {
    return { ...this.config };
  }

  /**
   * 更新配置
   *
   * @param config - 新配置（部分更新）
   */
  updateConfig(config: Partial<AnalyticsConfig>): void {
    this.config = { ...this.config, ...config };
  }
}

/**
 * 快速分析函数
 *
 * @param config - 配置
 * @param options - 选项
 * @returns Promise<AnalyticsReport>
 */
export async function quickAnalyze(
  config: AnalyticsConfig,
  options: AnalyticsOptions = {}
): Promise<AnalyticsReport> {
  const analytics = new SpreadsheetAnalytics(config);
  return analytics.analyze(options);
}

/**
 * 批量分析多个表格
 *
 * @param configs - 多个表格配置
 * @param options - 分析选项
 * @returns Promise<AnalyticsReport[]> 所有表格的分析报告
 */
export async function batchAnalyze(
  configs: AnalyticsConfig[],
  options: AnalyticsOptions = {}
): Promise<AnalyticsReport[]> {
  const results: AnalyticsReport[] = [];

  for (const config of configs) {
    try {
      const analytics = new SpreadsheetAnalytics(config);
      const report = await analytics.analyze(options);
      results.push(report);
    } catch (error: any) {
      console.error(`批量分析失败: ${config.spreadsheetToken}`, error);
      // 可以添加错误报告到结果中
      results.push({
        spreadsheetId: config.spreadsheetToken,
        sheetId: config.sheetId,
        generatedAt: new Date().toISOString(),
        schema: {
          totalRows: 0,
          totalColumns: 0,
          completeRows: 0,
          completeness: 0,
          fields: {},
          typeDistribution: {},
          warnings: [`分析失败: ${error.message}`],
        },
      });
    }
  }

  return results;
}

// 默认导出主类
export default SpreadsheetAnalytics;
