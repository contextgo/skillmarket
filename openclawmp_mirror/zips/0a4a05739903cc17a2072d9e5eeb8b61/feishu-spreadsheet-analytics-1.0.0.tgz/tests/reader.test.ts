/**
 * SpreadsheetReader 单元测试
 *
 * @author GOGO & tob-openclaw
 */

import { SpreadsheetReader, SpreadsheetReadError } from "../src/reader";
import { ParsedData } from "../src/types";

/**
 * 创建模拟工具集
 */
function createMockTools() {
  return {
    feishu_bitable_get_meta: async (url: string) => ({
      app_token: "app_xxx",
      table_id: "table_xxx",
      tables: [
        { table_id: "table_xxx", name: "Sheet1" },
        { table_id: "table_yyy", name: "Sheet2" },
      ],
    }),
    feishu_bitable_list_fields: async (appToken: string, tableId: string) => [
      { name: "id", type: 1 },
      { name: "name", type: 1 },
      { name: "age", type: 2 },
      { name: "salary", type: 2 },
      { name: "department", type: 1 },
      { name: "hire_date", type: 5 },
      { name: "is_active", type: 7 },
    ],
    feishu_bitable_list_records: async (
      appToken: string,
      tableId: string,
      pageSize: number,
      pageToken?: string
    ) => {
      const total = 50;
      const start = pageToken ? parseInt(pageToken) : 0;
      const end = Math.min(start + pageSize, total);

      const records = [];
      for (let i = start; i < end; i++) {
        records.push({
          fields: {
            id: i + 1,
            name: `用户${i + 1}`,
            age: 20 + (i % 30),
            salary: 30000 + i * 1000,
            department: i % 2 === 0 ? "技术部" : "市场部",
            hire_date: `202${i % 5}-01-15`,
            is_active: i % 3 !== 0,
          },
        });
      }

      return {
        records,
        page_token: end < total ? String(end) : undefined,
      };
    },
  };
}

describe("SpreadsheetReader", () => {
  const mockTools = createMockTools();

  describe("构造函数", () => {
    test("应该在没有 spreadsheetToken 时抛出错误", () => {
      expect(() => {
        // @ts-ignore
        new SpreadsheetReader({});
      }).toThrow(SpreadsheetReadError);
    });

    test("应该接受有效的配置", () => {
      const config = {
        spreadsheetToken: "sht_xxx",
      };
      const reader = new SpreadsheetReader(config, mockTools);
      expect(reader.getConfig().spreadsheetToken).toBe("sht_xxx");
    });

    test("应该使用默认值", () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
        },
        mockTools
      );
      const config = reader.getConfig();
      expect(config.headerRow).toBe(1);
      expect(config.dataStartRow).toBe(2);
      expect(config.batchSize).toBe(500);
      expect(config.maxRows).toBe(Infinity);
    });

    test("应该允许自定义工具注入", () => {
      const customTools = {
        ...mockTools,
        feishu_bitable_get_meta: async () => ({
          app_token: "custom_app",
          table_id: "custom_table",
          tables: [{ table_id: "custom_table", name: "Custom" }],
        }),
      };

      const reader = new SpreadsheetReader(
        { spreadsheetToken: "sht_xxx" },
        customTools
      );
      expect(reader).toBeDefined();
    });
  });

  describe("读取数据", () => {
    test("应该正确读取全部数据", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
        },
        mockTools
      );

      const data = await reader.read();

      expect(data.headers).toHaveLength(7);
      expect(data.headers).toContain("id");
      expect(data.headers).toContain("name");
      expect(data.headers).toContain("age");

      expect(data.rows).toHaveLength(50);
      expect(data.rows[0]).toHaveLength(7);
    });

    test("应该支持分页读取", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
          batchSize: 10,
        },
        mockTools
      );

      const data = await reader.read();
      expect(data.rows).toHaveLength(50); // 应该全部读取
    });

    test("应该支持 maxRows 限制", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
          maxRows: 15,
        },
        mockTools
      );

      const data = await reader.read();
      expect(data.rows).toHaveLength(15);
    });

    test("应该正确提取表头", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
        },
        mockTools
      );

      const data = await reader.read();
      expect(data.headers).toEqual([
        "id",
        "name",
        "age",
        "salary",
        "department",
        "hire_date",
        "is_active",
      ]);
    });

    test("应该正确填充元数据", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
          maxRows: 10,
        },
        mockTools
      );

      const data = await reader.read();
      expect(data.metadata.source).toBe("sht_xxx");
      expect(data.metadata.totalRows).toBe(50); // 读取的总数
      expect(data.metadata.readRows).toBe(10); // 实际读取的行数
    });

    test("应该正确处理 dataStartRow 偏移", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
          dataStartRow: 3, // 跳过第2行
        },
        mockTools
      );

      const data = await reader.read();
      // 由于 mock 数据有 50 行，dataStartRow=3 会跳过第1行（在 records 中索引0）
      // 但注意：我们的 mock 返回的是纯数据行，没有表头
      // dataStartRow 从第3行开始意味着跳过 3-2=1 行数据
      expect(data.rows.length).toBe(49); // 50 - 1
    });
  });

  describe("工作表选择", () => {
    test("应该使用默认的第一个工作表", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
        },
        mockTools
      );

      const data = await reader.read();
      expect(data.headers).toHaveLength(7);
    });

    test("应该使用指定的 sheetId", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
          sheetId: "table_yyy", // 第二个工作表
        },
        mockTools
      );

      // 注意：当前 mock 中所有工作表返回相同的字段结构
      const data = await reader.read();
      expect(data).toBeDefined();
    });

    test("应该在 sheetId 不存在时抛出错误", async () => {
      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
          sheetId: "invalid_sheet",
        },
        mockTools
      );

      await expect(reader.read()).rejects.toThrow(SpreadsheetReadError);
    });
  });

  describe("错误处理", () => {
    test("应该处理元数据获取失败", async () => {
      const errorTools = {
        ...mockTools,
        feishu_bitable_get_meta: async () => {
          throw { code: "INVALID_URL", message: "无效的表格 URL" };
        },
      };

      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "invalid_url",
        },
        errorTools
      );

      await expect(reader.read()).rejects.toThrow(SpreadsheetReadError);
    });

    test("应该处理字段列表获取失败", async () => {
      const errorTools = {
        ...mockTools,
        feishu_bitable_list_fields: async () => {
          throw new Error("权限不足");
        },
      };

      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
        },
        errorTools
      );

      await expect(reader.read()).rejects.toThrow(SpreadsheetReadError);
    });

    test("应该处理记录读取失败", async () => {
      const errorTools = {
        ...mockTools,
        feishu_bitable_list_records: async () => {
          throw new Error("API 限流");
        },
      };

      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_xxx",
        },
        errorTools
      );

      await expect(reader.read()).rejects.toThrow(SpreadsheetReadError);
    });
  });

  describe("边界情况", () => {
    test("应该处理空表格", async () => {
      const emptyTools = {
        ...mockTools,
        feishu_bitable_list_records: async () => ({
          records: [],
          page_token: undefined,
        }),
      };

      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_empty",
        },
        emptyTools
      );

      const data = await reader.read();
      expect(data.rows).toHaveLength(0);
      expect(data.headers).toHaveLength(7);
    });

    test("应该处理大数据集的分页", async () => {
      // 模拟 1000 条数据，分批读取
      let callCount = 0;
      const pagedTools = {
        ...mockTools,
        feishu_bitable_list_records: async (
          appToken: string,
          tableId: string,
          pageSize: number,
          pageToken?: string
        ) => {
          callCount++;
          const total = 1000;
          const start = pageToken ? parseInt(pageToken) : 0;
          const end = Math.min(start + pageSize, total);

          const records = [];
          for (let i = start; i < end; i++) {
            records.push({
              fields: {
                id: i + 1,
                name: `用户${i + 1}`,
                age: 20 + (i % 30),
                salary: 30000 + i * 1000,
                department: i % 2 === 0 ? "技术部" : "市场部",
                hire_date: `202${i % 5}-01-15`,
                is_active: i % 3 !== 0,
              },
            });
          }

          return {
            records,
            page_token: end < total ? String(end) : undefined,
          };
        },
      };

      const reader = new SpreadsheetReader(
        {
          spreadsheetToken: "sht_large",
          batchSize: 200,
        },
        pagedTools
      );

      const data = await reader.read();
      expect(data.rows).toHaveLength(1000);
      expect(callCount).toBe(5); // 1000 / 200 = 5 次调用
    });
  });
});

describe("BatchSpreadsheetReader", () => {
  const mockTools = createMockTools();

  test("应该批量读取多个表格", async () => {
    const batcher = new (require("../src/reader").BatchSpreadsheetReader)(
      [
        { spreadsheetToken: "sht_1" },
        { spreadsheetToken: "sht_2" },
      ],
      mockTools
    );

    const results = await batcher.readAll();

    expect(results).toHaveLength(2);
    expect(results[0].success).toBe(true);
    expect(results[1].success).toBe(true);
    expect(results[0].report).toBeUndefined(); // 只读取，不分析
  });

  test("应该正确处理批量中的失败", async () => {
    const mixedTools = {
      ...mockTools,
      feishu_bitable_get_meta: async (url: string) => {
        if (url === "sht_1") {
          return mockTools.feishu_bitable_get_meta(url);
        }
        throw new Error("表格不存在");
      },
    };

    const batcher = new (require("../src/reader").BatchSpreadsheetReader)(
      [
        { spreadsheetToken: "sht_1" },
        { spreadsheetToken: "sht_fail" },
      ],
      mixedTools
    );

    const results = await batcher.readAll();

    expect(results).toHaveLength(2);
    expect(results[0].success).toBe(true);
    expect(results[1].success).toBe(false);
    expect(results[1].error).toBeDefined();
  });
});
