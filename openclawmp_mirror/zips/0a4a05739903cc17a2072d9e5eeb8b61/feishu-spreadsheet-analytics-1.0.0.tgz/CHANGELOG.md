# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-03-02

### Added

- Initial release of feishu-spreadsheet-analytics
- Core features:
  - SpreadsheetReader: Read Feishu Spreadsheet/Bitable data with pagination
  - DataAnalyzer: Type inference, basic statistics, distribution analysis, outlier detection
  - Reporter: Generate Markdown, HTML, and JSON reports
  - Utils: Type inference, date format detection, statistical calculations
- Full TypeScript support with strict mode
- Comprehensive examples (basic-stats.ts)
- Unit tests for reader module
- Detailed documentation (README.md, SKILL.md)

### Technical Details

- Built with OpenClaw Skill SDK
- Compatible with Feishu Spreadsheet API
- Supports batch processing and large datasets
- Configurable analysis options
- Custom error classes for robust error handling

---

## [Planned] - Future

- [ ] Add more test coverage (analyzer, reporter, utils)
- [ ] Support for chart generation with Chart.js
- [ ] Multi-threaded processing for large datasets
- [ ] Export to Excel/PDF formats
- [ ] Integration with feishu-doc for automatic report publishing
- [ ] Support for data transformation pipelines
- [ ] Webhook-based scheduled analysis