# 数据分析报告

## 概览

- **表格**: {{spreadsheetId}}
- **工作表**: {{sheetId}}
- **生成时间**: {{generatedAt}}
- **总行数**: {{totalRows}}
- **总列数**: {{totalColumns}}
- **数据完成率**: {{completeness}}%

## 字段详情

| 字段名 | 类型 | 非空率 | 唯一值 | 统计摘要 |
|--------|------|--------|--------|----------|
{{#each fields}}
| {{name}} | {{type}} | {{nonNullRate}}% | {{uniqueRate}}% | {{summary}} |
{{/each}}

## 警告

{{#if warnings}}
{{#each warnings}}
- {{this}}
{{/each}}
{{else}}
无警告
{{/if}}

## 分布分析

{{#if distributions}}
{{#each distributions}}
### {{field}}

{{#if bins}}
| 范围 | 数量 | 占比 |
|------|------|------|
{{#each bins}}
| {{range}} | {{count}} | {{percentage}}% |
{{/each}}
{{/if}}

{{#if topValues}}
| 值 | 出现次数 | 占比 |
|-----|----------|------|
{{#each topValues}}
| {{value}} | {{count}} | {{percentage}}% |
{{/each}}
{{/if}}

{{/each}}
{{/if}}

## 异常检测

{{#if outliers}}
{{#each outliers}}
### {{field}}

发现 **{{outliers.length}}** 个异常值（{{method}} 方法，阈值 {{threshold}}）

行号: {{outliers}}

{{/each}}
{{else}}
未检测到异常值。
{{/if}}

---

*报告由 feishu-spreadsheet-analytics 自动生成*