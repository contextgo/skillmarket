# 自定义报告模板

将自定义的 Markdown 模板放在此目录中。

## 使用方法

Reporter 会自动加载 `templates/` 目录下的模板文件。

### 模板变量

- `{{title}}` - 报告标题
- `{{generatedAt}}` - 生成时间
- `{{schema}}` - 数据结构统计
- `{{distributions}}` - 分布分析
- `{{outliers}}` - 异常检测
- `{{warnings}}` - 警告信息

### 示例模板

```markdown
# {{title}}

生成时间: {{generatedAt}}

## 概览

- 总行数: {{schema.totalRows}}
- 总列数: {{schema.totalColumns}}
- 完整率: {{schema.completeness}}%

{{#if warnings}}
## 警告
{{#each warnings}}
- {{this}}
{{/each}}
{{/if}}
```

### 加载自定义模板

```typescript
const reporter = new Reporter(schema);
reporter.loadTemplate("custom-template.md");
const md = reporter.generateMarkdown();
```
