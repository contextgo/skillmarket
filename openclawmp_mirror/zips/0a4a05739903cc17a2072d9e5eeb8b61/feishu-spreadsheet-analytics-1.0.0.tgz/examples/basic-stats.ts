/**
 * 基础统计示例
 *
 * 演示如何使用 feishu-spreadsheet-analytics 进行数据读取和分析
 *
 * 使用方法:
 * ```bash
 * npx ts-node examples/basic-stats.ts
 * ```
 *
 * @author GOGO & tob-openclaw
 */

import {
  SpreadsheetAnalytics,
  AnalyticsConfig,
  SpreadsheetReader,
  DataAnalyzer,
  Reporter,
  ParsedData,
} from "../src";

/**
 * 示例 1: 一站式分析（推荐）
 *
 * 使用 SpreadsheetAnalytics 主类完成读取、分析、报告生成全流程
 */
async function example1FullAnalysis() {
  console.log("=== 示例 1: 一站式分析 ===\n");

  // 配置（需要替换为真实的表格 token）
  const config: AnalyticsConfig = {
    spreadsheetToken: process.env.FEISHU_SPREADSHEET_TOKEN || "shtxxxxxxxx",
    sheetId: "sheet1", // 可选，不指定则读取第一个工作表
    headerRow: 1,
    dataStartRow: 2,
    batchSize: 1000,
    maxRows: 10000, // 限制最多读取 10000 行
  };

  try {
    // 创建分析器
    const analytics = new SpreadsheetAnalytics(config);

    // 执行分析
    const report = await analytics.analyze({
      includeDistribution: true,
      includeOutliers: true,
      outlierMethod: "iqr",
      outlierThreshold: 1.5,
      outputFormat: "markdown",
      maxSampleSize: 10,
    });

    console.log("📊 分析报告：\n");
    console.log(report.markdown);

    // 也可以获取 JSON 结构化数据
    console.log("\n📋 结构化数据：");
    console.log(JSON.stringify(report, null, 2));

    return report;
  } catch (error: any) {
    console.error("分析失败:", error.message);
    throw error;
  }
}

/**
 * 示例 2: 分步流水线（自定义）
 *
 * 分别使用 Reader、Analyzer、Reporter，便于自定义中间处理
 */
async function example2CustomPipeline() {
  console.log("\n=== 示例 2: 自定义流水线 ===\n");

  const config: AnalyticsConfig = {
    spreadsheetToken: process.env.FEISHU_SPREADSHEET_TOKEN || "shtxxxxxxxx",
    headerRow: 1,
    dataStartRow: 2,
    batchSize: 500,
  };

  try {
    // 步骤 1: 读取数据
    console.log("步骤 1: 读取数据...");
    const reader = new SpreadsheetReader(config);
    const data = await reader.read();
    console.log(`读取完成: ${data.rows.length} 行 × ${data.headers.length} 列`);
    console.log(`表头: ${data.headers.join(", ")}\n`);

    // 步骤 2: 分析数据
    console.log("步骤 2: 分析数据...");
    const analyzer = new DataAnalyzer(data);
    const schema = analyzer.inferSchema();

    console.log("字段类型:");
    for (const [name, field] of Object.entries(schema.fields)) {
      console.log(`  - ${name}: ${field.type} ${field.nullable ? "(可空)" : ""}`);
    }
    console.log(`\n完整率: ${(schema.completeness * 100).toFixed(1)}%`);
    console.log(`警告: ${schema.warnings.length} 条\n`);

    // 步骤 3: 分布分析
    console.log("步骤 3: 分布分析...");
    const distributions = analyzer.distributions(10);
    distributions.forEach((dist) => {
      if (dist.type === "numeric" && dist.bins) {
        console.log(`\n${dist.field} (数值分布):`);
        dist.bins.forEach((bin) => {
          console.log(`  ${bin.range}: ${bin.count} (${bin.percentage}%)`);
        });
      }
      if (dist.type === "categorical" && dist.topValues) {
        console.log(`\n${dist.field} (Top 值):`);
        dist.topValues.forEach((v) => {
          console.log(`  ${v.value}: ${v.count} (${v.percentage}%)`);
        });
      }
    });

    // 步骤 4: 异常检测
    console.log("\n步骤 4: 异常检测...");
    const outliers = analyzer.detectOutliers({
      method: "iqr",
      threshold: 1.5,
    });
    if (outliers.length > 0) {
      outliers.forEach((out) => {
        console.log(`  ${out.field}: ${out.outliers.length} 个异常值`);
      });
    } else {
      console.log("  未发现明显异常值");
    }

    // 步骤 5: 生成报告
    console.log("\n步骤 5: 生成报告...");
    const reporter = new Reporter(schema);
    const markdown = reporter
      .withDistributions(distributions)
      .withOutliers(outliers)
      .generateFullReport("markdown");

    console.log("\n--- 报告预览 ---\n");
    console.log(markdown.slice(0, 1000) + "...\n");

    // 保存到文件
    const fs = await import("fs");
    const path = await import("path");
    const reportPath = path.join(
      process.cwd(),
      `report-${new Date().toISOString().slice(0, 10)}.md`
    );
    fs.writeFileSync(reportPath, markdown, "utf-8");
    console.log(`📄 报告已保存到: ${reportPath}`);

    return { schema, distributions, outliers, markdown };
  } catch (error: any) {
    console.error("自定义流水线失败:", error.message);
    throw error;
  }
}

/**
 * 示例 3: 批量分析
 *
 * 同时分析多个表格
 */
async function example3BatchAnalysis() {
  console.log("\n=== 示例 3: 批量分析 ===\n");

  const configs: AnalyticsConfig[] = [
    {
      spreadsheetToken: "shtxxxxxxxx1",
      sheetId: "sheet1",
    },
    {
      spreadsheetToken: "shtxxxxxxxx2",
      sheetId: "sheet1",
    },
    // 可以添加更多...
  ];

  try {
    const { batchAnalyze } = await import("../src");
    const reports = await batchAnalyze(configs, {
      includeOutliers: false,
    });

    console.log(`批量分析完成: ${reports.length} 个表格\n`);
    reports.forEach((report, idx) => {
      console.log(`${idx + 1}. ${report.spreadsheetId}:`);
      console.log(`   行数: ${report.schema.totalRows}`);
      console.log(`   列数: ${report.schema.totalColumns}`);
      console.log(`   完整率: ${(report.schema.completeness * 100).toFixed(1)}%`);
      console.log(`   警告: ${report.schema.warnings.length} 条\n`);
    });

    return reports;
  } catch (error: any) {
    console.error("批量分析失败:", error.message);
    throw error;
  }
}

/**
 * 示例 4: 使用模拟数据（无需真实表格）
 *
 * 适用于本地测试和学习
 */
async function example4MockData() {
  console.log("\n=== 示例 4: 模拟数据测试 ===\n");

  // 构造模拟数据
  const mockData: ParsedData = {
    headers: ["id", "name", "age", "salary", "department", "hire_date", "is_active"],
    rows: [
      [1, "张三", 28, 50000, "技术部", "2020-03-15", true],
      [2, "李四", 35, 65000, "市场部", "2018-07-22", true],
      [3, "王五", 42, 80000, "技术部", "2015-11-08", true],
      [4, "赵六", 23, 35000, "销售部", "2023-01-10", true],
      [5, "孙七", 31, 55000, "市场部", "2019-09-05", true],
      [6, "周八", null, 48000, "技术部", "2021-04-18", false], // age 缺失
      [7, "吴九", 29, 52000, "销售部", "2020-12-01", true],
      [8, "郑十", 45, 75000, "技术部", "2017-06-30", true],
      [9, "钱一", 26, 42000, "市场部", "2022-02-14", true],
      [10, "陈二", 38, 68000, "技术部", "2016-08-23", true],
    ],
    metadata: {
      source: "mock",
      totalRows: 10,
      readRows: 10,
    },
  };

  console.log("模拟数据集:");
  console.log(`表头: ${mockData.headers.join(", ")}`);
  console.log(`行数: ${mockData.rows.length}\n`);

  // 分析
  const analyzer = new DataAnalyzer(mockData);
  const schema = analyzer.inferSchema();

  console.log("Schema 推断结果:");
  for (const [name, field] of Object.entries(schema.fields)) {
    console.log(`  ${name}: ${field.type}`);
    if (field.type === "number") {
      console.log(`    min=${field.min}, max=${field.max}, mean=${field.mean?.toFixed(2)}`);
    }
  }
  console.log(`\n警告: ${schema.warnings.join(", ")}`);

  // 生成报告
  const reporter = new Reporter(schema);
  const distributions = analyzer.distributions();
  const outliers = analyzer.detectOutliers();

  const markdown = reporter
    .withDistributions(distributions)
    .withOutliers(outliers)
    .generateFullReport("markdown");

  console.log("\n--- Markdown 报告 ---\n");
  console.log(markdown);

  return { schema, distributions, outliers };
}

/**
 * 主函数
 *
 * 根据命令行参数选择运行的示例
 */
async function main() {
  const args = process.argv.slice(2);
  const example = args[0] || "1";

  console.log("🔬 Feishu Spreadsheet Analytics - 示例程序\n");

  switch (example) {
    case "1":
      await example1FullAnalysis();
      break;
    case "2":
      await example2CustomPipeline();
      break;
    case "3":
      await example3BatchAnalysis();
      break;
    case "4":
      await example4MockData();
      break;
    default:
      console.log(`
可用示例:
  1 - 一站式分析（推荐）
  2 - 自定义流水线
  3 - 批量分析
  4 - 模拟数据测试

使用方法: npx ts-node examples/basic-stats.ts [示例编号]
例如: npx ts-node examples/basic-stats.ts 4
      `);
  }
}

// 运行
if (require.main === module) {
  main().catch((err) => {
    console.error("示例执行失败:", err);
    process.exit(1);
  });
}
