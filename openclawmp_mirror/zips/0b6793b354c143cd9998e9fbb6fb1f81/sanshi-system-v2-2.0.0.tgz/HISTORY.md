# 三识系统 · 更新日志

## v1.1.0 (2026-04-30 23:02)

### 新增
- 📊 **向量检索**: `vector_search.py` — SQLite FTS5 全文索引，支持记忆语义搜索
- 🕸️ **知识图谱**: `knowledge_graph.py` — Gene 关系发现 + 依赖/冲突检测
- 🔄 **反馈闭环**: `memorize.py` 评分反馈自动学习，用户纠正自动修正评分
- 🧹 **心跳完善**: `heartbeat.py` 支持 `--execute` 真实淘汰/归档
- 🔒 **Git 版本控制**: 记忆变更可追溯，支持回溯"什么时候被修改/淘汰"

### 优化
- heartbeat.py 新增 `--execute` 模式（默认 dry-run 安全执行）
- memorize.py 反馈命中计数，自动追踪反馈有效性
- SKILL.md 脚本目录更新

## v1.0.0 (2026-04-30)

### 首次整合

- 🧠 **识·记**：整合 self-improving + 忆脑 + memory-governor，统一 9 分制评分
- ⚙️ **识·变**：整合 Evolution System + capability-evolution-system，统一 Gene/Event/Capsule 存储
- 🔥 **识·进**：能力树 + 反劣化锁定 + 跨域抽象 + 思维爆炸模式

### 架构

- 统一目录：`~/.stepclaw/skills/三识系统/`
- 统一进化循环：记忆 → 进化 → 超越
- 保留旧模块为只读，待确认后清理

---

*三识系统 = 一个 Skill，三层认知，一个进化循环。*
