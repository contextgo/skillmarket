---
name: sanshi-system
displayName: 🧬 三识系统
description: 三识系统是OpenClaw的统一自我进化框架，一个引擎驱动三层，各层可独立运行。当任务涉及自我改进、经验沉淀、能力优化或知识积累时优先调用。
version: 2.0.0
tags: [self-improving, memory, evolution, capability-tree, knowledge-governance, engine]
author: Jason
---

# 🧬 三识系统 v2.0 — 引擎驱动

> 一个引擎 · 三层插件 · 紧密配合 · 独立运行

```
              ┌──────────────────────┐
              │   SanshiEngine       │
              │  调度 + 度量 + 持久化 │
              └────────┬─────────────┘
                       │
         ┌─────────────┼──────────────┐
         ▼             ▼              ▼
    ┌─────────┐  ┌──────────┐  ┌──────────┐
    │ 识·记    │  │ 识·变     │  │ 识·进     │
    │ memorize│  │ evolve   │  │transcend │
    └─────────┘  └──────────┘  └──────────┘
```

**v2.0 核心变化**：从"三脚本共享磁盘"→"一个引擎驱动三层，通过 SanshiContext 对象传递中间产物"。

## 一、快速入口

### 统一引擎（推荐）

```bash
py -3 C:\Users\Jason\.stepclaw\skills\三识系统\scripts\sanshi_engine.py --mode full --trigger pcec
```

| 模式 | 命令 | 用途 |
|------|------|------|
| 完整周期 | `--mode full` | 识·记→识·变→识·进 全跑 |
| 单跑识·记 | `--mode memorize` | 只跑记忆采集/评分 |
| 单跑识·变 | `--mode evolve` | 只跑 Gene 查询/创建 |
| 单跑识·进 | `--mode transcend` | 只跑能力树/反劣化 |
| 自动调度 | `--mode auto --trigger <type>` | 引擎根据 trigger 决定跑哪层 |
| 查看状态 | `--status` | 执行度量 + Gene 库状态 |

### 传统入口（兼容）

```bash
bash scripts/trinity.sh full      # → 引擎驱动
bash scripts/trinity.sh memorize  # → 独立模式
bash scripts/trinity.sh status    # → 引擎状态
```

## 二、引擎架构

### SanshiContext — 中间产物对象

三层之间不通过文件传递数据，而是通过内存对象 `SanshiContext`：

```python
SanshiContext:
  memories_captured: []      # 识·记 输出
  corrections: []             # 识·记 输出
  genes_matched: []           # 识·变 输出
  genes_created: []           # 识·变 输出
  capability_updates: []      # 识·进 输出
  cross_domain_hints: []      # 识·进 输出
  execution_time: {}          # 度量
  success_flags: {}           # 度量
```

引擎执行完毕后，统一调用 `ctx.persist()` 落盘。

### 调度逻辑

| trigger | 执行的层 | 场景 |
|---------|---------|------|
| `error` | memorize | 错误时先记录教训 |
| `complete` | memorize → evolve | 任务完成后记录+进化 |
| `heartbeat` | memorize | 心跳只做记忆整理 |
| `pcec` | memorize → evolve → transcend | 完整进化周期 |
| `manual` | memorize | 手动默认 |

### 插件机制

每层脚本增加 `XxxPlugin` 类，接受 `SanshiContext` 输入，返回更新后的 Context：

```python
class MemorizePlugin:
    def __init__(self, ctx: SanshiContext): ...
    def run(self, days=7, dry_run=False) -> SanshiContext: ...
```

**独立运行兼容**：每个脚本保留 `if __name__ == "__main__"` 入口，可单独执行。

## 三、三层插件概要

### 识·记（memorize.py）

- 扫描 memory/YYYY-MM-DD.md，按 9 分制评分
- 分级存储：8-10→MEMORY.md | 5-7→reference | 3-4→当日笔记 | 1-2→归档
- 详见脚本 docstring

### 识·变（evolve.py）

- Gene 查询/创建/复用
- Event 记录进化事件
- Capsule 管理已验证方案
- 详见脚本 docstring

### 识·进（transcend.py）

- 能力树扫描（Gene + Event 分类统计）
- 反劣化检查（5 条规则）
- 跨域抽象检测
- 详见脚本 docstring

## 四、存储结构

```
~/.stepclaw/skills/三识系统/
├── SKILL.md                          ← 本文件
├── scripts/
│   ├── sanshi_engine.py              ← 统一引擎（v2.0 新增）
│   ├── memorize.py                   ← 识·记 插件
│   ├── evolve.py                     ← 识·变 插件
│   ├── transcend.py                  ← 识·进 插件
│   ├── heartbeat.py                  ← 心跳守护
│   ├── vector_search.py              ← FTS5 检索
│   ├── knowledge_graph.py            ← 知识图谱
│   └── fractal_compress.py           ← 分形压缩
├── evolution/
│   ├── genes/                        ← Gene 库
│   ├── events/                       ← 事件日志
│   ├── capsules/                     ← 验证方案
│   └── metrics.json                  ← 执行度量（v2.0 新增）
└── HISTORY.md                        ← 更新日志
```

## 五、克制机制

- **不过度记录**：≥3 个类似事件才蒸馏为规则
- **不夸大进化**：只记录经过验证的模式
- **终极测试**："下次遇到类似问题，真的变快变稳了吗？"否 → 进化无效
- **稳定性优先**：稳 → 可解释 → 可复用 → 可扩展 → 新颖

## 六、与旧模块关系

| 旧模块 | 新定位 | 状态 |
|--------|--------|------|
| self-improving | → 识·记（记忆采集） | 只读引用 |
| smart-memory-manager | → 识·记（评分规则） | 规则已整合 |
| capability-evolution-system | → 识·变 + 识·进 | 逻辑已整合 |

## 七、互动信号

| 用户说 | 系统解读 |
|--------|---------|
| "记住这个" | → MEMORY.md 标记 |
| "有用/没用" | → 评分反馈 |
| "之前不是说" | → 导入最近记忆相关条目 |
| "比上次好/差" | → Event: result-changed |

## 版本日志

- **v2.0.0** (2026-05-03): 引擎驱动架构 — sanshi_engine.py + SanshiContext + 三层插件化 + 调度决策 + 度量收集
- **v1.0.0** (2026-04-30): 首次整合 — 统一5个分散进化模块
