# 迁移指南：从分散模块 → 三识系统

## 映射关系

| 旧模块 | → 新位置 | 迁移内容 |
|--------|---------|---------|
| `~/self-improving/memory.md` | `memory/reference/` 或 `MEMORY.md` | HOT 记忆迁移并合并 |
| `~/self-improving/corrections.md` | `memory/reference/corrections.md` | 纠错记录 |
| `~/self-improving/projects/` | `memory/reference/projects/` | 项目记忆 |
| `~/self-improving/domains/` | `memory/reference/domains/` | 领域记忆 |
| `~/self-improving/archive/` | `memory/archive/` | 归档记忆 |
| `~/evolution/genes/` | `evolution/genes/` | 软链接或复制 |
| `~/evolution/events/` | `evolution/events/` | 同上 |
| `~/evolution/capsules/` | `evolution/capsules/` | 同上 |
| `~/evolution/shared/` | `evolution/shared/` | 同上 |

## 迁移步骤

1. **第一阶段（数据迁移）**: 按上表迁移文件，**只读模式不覆盖**
2. **第二阶段（功能验证）**: 验证三识系统能读写所有迁移内容
3. **第三阶段（旧版弃用）**: 确认旧模块数据全部在 new 中有对应 → 删除旧目录
4. **阶段四（Cron 切换）**: PCEC 任务指向三识系统入口

## 安全原则

- 迁移前先备份：`cp -r ~/self-improving ~/self-improving.bak`
- 新目录 = 追加写入，不覆盖，逐步验证
- 确认迁移成功后才可清理旧模块（需用户确认）
