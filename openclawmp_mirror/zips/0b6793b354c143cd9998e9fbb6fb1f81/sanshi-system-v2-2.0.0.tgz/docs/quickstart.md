# 三识系统快速开始

## 1. 验证安装

```bash
ls ~/.stepclaw/skills/三识系统/SKILL.md
# 应看到文件存在
```

## 2. 创建统一记忆文件

三识记忆层通过软链接统一管理，直接读写 workspace 的 `MEMORY.md` 生效。

确认 `MEMORY.md` 在 workspace 中存在即完成配置。

## 3. 三次扫描（人工注入）

- 1. 读取 `MEMORY.md` 全量
- 2. 读取 `memory/problems-foundations-latest.md` 或等效的每日记忆
- 3. 读取 `memory/YEAR-REPORT-YYYY.md` 或等效的历史精华
- 如果不可能逐一覆盖 → 先用 `memory_search` 命中+覆盖率最高的条目

## 4. 迁移数据（可选）

```bash
# 从旧 self-improving 迁移
python ~/.stepclaw/skills/三识系统/scripts/migrate_from_self_improving.py

#  Evolution System（Gene 库已统一到 三识系统/evolution/）
# Capsule 有任何一个 → 按表格格式转换到记忆库
```

## 5. 设置 PCEC 定时周期

建议用 Cron（每 3 小时）：

```bash
0 */3 * * * cd ~/.stepclaw/workspace && bash ...编辑用完...
```
