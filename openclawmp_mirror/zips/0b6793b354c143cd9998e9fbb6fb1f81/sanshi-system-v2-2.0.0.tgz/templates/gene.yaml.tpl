# Gene 基因模板

> Gene = 可复用的策略模板，经验到 "能力单元" 的浓缩

```yaml
gene_id: [唯一标识]
name: "[名称]"
version: "1.0.0"
created_at: "[ISO 时间]"
last_used: "[ISO 时间]"
source_module: "[来源: self-improving | capability-evolution | memory-governor | Evolution System]"

description: |
  [一段话说明这个Gene解决什么问题]

problem: |
  [更具体的问题描述]

# ─── 策略定义 ───

strategy: |
  [完整的解决流程，可执行，无歧义]

# ─── 三识匹配 ───

# 识·记: 记忆层关联（从记忆中萃取的判断依据）
memory_associations:
  - "[记忆关联1]"
  - "[记忆关联2]"

# 识·变: 可复用路径（PCEC发现的优化空间）
reuse_paths:
  - "[可复用场景1]"

# 识·进: 可迁移/可泛化提示（跨域抽象）
abstraction_hints:
  - "[跨域迁移可能性]"

# ─── 边界 ───

applies_when:
  - [适用条件 1]
  - [适用条件 2]

does_not_apply_when:
  - [排除条件 1]

failure_points:
  - "[常见陷阱]: [规避方法]"

# ─── 数据 ───

success_rate: [0.0 - 1.0]      # 成功率
used_count: [整数]               # 使用次数
last_success: "[ISO 时间]"      # 上次成功
last_failure: "[ISO 时间]"      # 上次失败
```
