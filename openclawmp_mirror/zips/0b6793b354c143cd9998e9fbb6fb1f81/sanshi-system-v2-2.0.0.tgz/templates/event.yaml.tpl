# Event 事件模板

> Event = 进化过程的完整记录，"进化发生什么了"的证据链

```yaml
event_id: "[类型]-[时间戳]"
type: "[capability-upgrade | error-fix | pattern-learned | strategy-optimized | memory-breakthrough]"
status: "[pending | in-progress | resolved | abandoned]"
created_at: "[ISO 时间]"

# ─── 描述 ───
title: "[一句话描述]"
description: |
  [2-5句话描述初始状态 → 变化动作 → 当前状态 → 最终影响]

# ─── 问题 / 机会 ───
problem:
  title: "[问题/机会标题]"
  description: "[详细描述]"
  root_cause: "[根本原因分析]"

# ─── 行动 ───
attempts:
  - step: "[行动描述]"
    moment: "[ISO 时间]"
    outcome: "[结果]"

# ─── 结果 ───
result: "[最终结论]"
impact: "[对各层的影响]

# ─── 三识关联 ───
linked_genes:
  - "[gene_id 1]"
memory_references:
  - "[记忆条目引用1]"
```
