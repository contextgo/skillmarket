#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 心跳守护模块（识·记·守护）
========================================
每日心跳守护：记忆衰减 + 淘汰 + 冲突消解 + 评分反馈 + 自动归档。

用法:
    python heartbeat.py              # 正常运行
    python heartbeat.py --days 3     # 处理最近N天
    python heartbeat.py --execute    # 执行真实淘汰（默认dry-run）
"""

import os
import sys
import json
from datetime import datetime, timedelta
from pathlib import Path

WORKSPACE = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "workspace")
MEMORY_DIR = WORKSPACE / "memory"
REFERENCE_DIR = MEMORY_DIR / "reference"
ARCHIVE_DIR = MEMORY_DIR / "archive"
REPORTS_DIR = MEMORY_DIR / "reports"
MEMORY_MD = WORKSPACE / "MEMORY.md"

SANSHI_ROOT = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "skills", "三识系统")
EVOLUTION_DIR = SANSHI_ROOT / "evolution"
EVENTS_DIR = EVOLUTION_DIR / "events"

# 衰减配置
TEMPORARY_DAYS = 7
REFERENCE_DAYS = 180
ARCHIVE_DAYS = 365


def decay_temporary(execute: bool = False) -> list:
    """临时记忆衰减：超过7天未晋升的降级到archive"""
    decayed = []
    today = datetime.now().date()
    
    for f in sorted(MEMORY_DIR.glob("*.md")):
        if f.name.startswith("202") and f.name.endswith(".md"):
            date_str = f.stem
            try:
                file_date = datetime.strptime(date_str, "%Y-%m-%d").date()
                age = (today - file_date).days
                
                if age > TEMPORARY_DAYS and age <= ARCHIVE_DAYS:
                    action = "reference"
                    decayed.append({"file": f.name, "age_days": age, "action": action})
                    if execute:
                        ref_path = REFERENCE_DIR / f"ref-{f.stem}.md"
                        if not ref_path.exists():
                            REFERENCE_DIR.mkdir(parents=True, exist_ok=True)
                            ref_path.write_text(f.read_text(encoding="utf-8"), encoding="utf-8")
                
                elif age > ARCHIVE_DAYS:
                    action = "archive"
                    decayed.append({"file": f.name, "age_days": age, "action": action})
                    if execute:
                        arch_path = ARCHIVE_DIR / f"archived-{f.stem}.md"
                        if not arch_path.exists():
                            ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
                            arch_path.write_text(f.read_text(encoding="utf-8"), encoding="utf-8")
                        # 删除原文件
                        f.unlink()
                        
            except ValueError:
                pass
    
    return decayed


def check_conflicts() -> list:
    """冲突检测：查找 MEMORY.md 中的矛盾条目"""
    conflicts = []
    if not MEMORY_MD.exists():
        return conflicts
    
    content = MEMORY_MD.read_text(encoding="utf-8")
    lines = content.split("\n")
    for i, line in enumerate(lines):
        for keyword in ["过时", "不再", "已改为", "待验证", "obsolete"]:
            if keyword in line:
                conflicts.append({
                    "line": i + 1,
                    "text": line.strip()[:100],
                    "keyword": keyword,
                })
    
    return conflicts


def scan_reference(execute: bool = False) -> list:
    """扫描 reference 目录，超期的归档"""
    expired = []
    today = datetime.now().date()
    
    for f in REFERENCE_DIR.glob("*.md"):
        for part in f.stem.split("-"):
            if len(part) == 8 and part.isdigit():
                try:
                    file_date = datetime.strptime(part, "%Y%m%d").date()
                    age = (today - file_date).days
                    if age > REFERENCE_DAYS:
                        expired.append({"file": f.name, "age_days": age})
                        if execute:
                            arch_path = ARCHIVE_DIR / f"archived-{f.stem}.md"
                            if not arch_path.exists():
                                ARCHIVE_DIR.mkdir(parents=True, exist_ok=True)
                                arch_path.write_text(f.read_text(encoding="utf-8"), encoding="utf-8")
                            f.unlink()
                except ValueError:
                    pass
    
    return expired


def generate_report(decayed: list, conflicts: list, expired: list, execute: bool = False) -> str:
    """生成心跳守护报告"""
    report_lines = [
        "# 三识心跳守护报告",
        f"时间: {datetime.now().isoformat()}",
        f"执行模式: {'真实执行' if execute else '试运行(dry-run)'}",
        "",
        "## 衰减统计",
        f"- 临时记忆衰减: {len(decayed)} 个",
        f"- 参考记忆超期: {len(expired)} 个",
        f"- 冲突条目: {len(conflicts)} 个",
        "",
    ]
    
    if decayed:
        report_lines.append("### 衰减列表")
        for d in decayed:
            report_lines.append(f"- {d['file']} ({d['age_days']}天) → {d['action']}")
        report_lines.append("")
    
    if conflicts:
        report_lines.append("### 冲突列表")
        for c in conflicts:
            report_lines.append(f"- L{c['line']}: [{c['keyword']}] {c['text']}")
        report_lines.append("")
    
    if expired:
        report_lines.append("### 超期列表")
        for e in expired:
            report_lines.append(f"- {e['file']} ({e['age_days']}天) → archive")
        report_lines.append("")
    
    report = "\n".join(report_lines)
    
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    report_path = REPORTS_DIR / f"heartbeat-{datetime.now().strftime('%Y%m%d')}.md"
    report_path.write_text(report, encoding="utf-8")
    
    return report


def run(days: int = 7, execute: bool = False):
    """主执行流程"""
    print(f"{'[真实执行] ' if execute else '[试运行] '}三识系统 · 心跳守护（识·记·守护）")
    print("=" * 50)
    
    # 1. 临时衰减
    decayed = decay_temporary(execute=execute)
    if decayed:
        print(f"\n📉 临时记忆衰减 ({len(decayed)} 个):")
        for d in decayed:
            print(f"  {d['file']} ({d['age_days']}天) → {d['action']}")
    else:
        print("\n📉 临时记忆: 无需衰减")
    
    # 2. 冲突检测
    conflicts = check_conflicts()
    if conflicts:
        print(f"\n⚠️ 冲突检测 ({len(conflicts)} 个):")
        for c in conflicts:
            print(f"  L{c['line']}: [{c['keyword']}] {c['text']}")
    else:
        print("\n⚠️ 冲突检测: 无冲突")
    
    # 3. 参考超期
    expired = scan_reference(execute=execute)
    if expired:
        print(f"\n📦 参考记忆超期 ({len(expired)} 个):")
        for e in expired:
            print(f"  {e['file']} ({e['age_days']}天) → archive")
    else:
        print("\n📦 参考记忆: 无超期")
    
    # 4. 生成报告
    report = generate_report(decayed, conflicts, expired, execute=execute)
    report_path = REPORTS_DIR / f"heartbeat-{datetime.now().strftime('%Y%m%d')}.md"
    print(f"\n📄 报告: {report_path}")
    
    # 5. 记录 Event
    event_path = EVENTS_DIR / f"ev-heartbeat-{datetime.now().strftime('%Y%m%d-%H%M')}.yaml"
    event_content = f"""# Heartbeat Event
event_id: "ev-heartbeat-{datetime.now().strftime('%Y%m%d-%H%M')}"
type: memory-breakthrough
status: resolved
created_at: "{datetime.now().isoformat()}"
title: "心跳守护"
execute_mode: {"real" if execute else "dry-run"}
description: |
  临时衰减: {len(decayed)}
  冲突检测: {len(conflicts)}
  参考超期: {len(expired)}
"""
    EVENTS_DIR.mkdir(parents=True, exist_ok=True)
    event_path.write_text(event_content, encoding="utf-8")
    print(f"📝 Event: {event_path.name}")


if __name__ == "__main__":
    days = 7
    execute = False
    for i, arg in enumerate(sys.argv[1:], 1):
        if arg.startswith("--days="):
            days = int(arg.split("=")[1])
        elif arg == "--days" and i < len(sys.argv) - 1:
            days = int(sys.argv[i + 1])
        elif arg == "--execute":
            execute = True
    
    run(days=days, execute=execute)
