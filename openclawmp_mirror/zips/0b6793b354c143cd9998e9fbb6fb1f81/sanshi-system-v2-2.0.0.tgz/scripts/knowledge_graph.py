#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 知识图谱模块（识·进增强）
=======================================
基于 JSON 的轻量知识图谱，记录 Gene 之间的依赖/关联/冲突关系。
不需要外部依赖。

用法:
    python knowledge_graph.py add "GeneA" "GeneB" "depends_on"
    python knowledge_graph.py query "GeneA"
    python knowledge_graph.py find-gaps
    python knowledge_graph.py stats
"""

import os
import sys
import json
from datetime import datetime
from pathlib import Path
from collections import defaultdict

SANSHI_ROOT = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "skills", "三识系统")
GRAPH_FILE = SANSHI_ROOT / "evolution" / "shared" / "knowledge_graph.json"
GENES_DIR = SANSHI_ROOT / "evolution" / "genes"
EVENTS_DIR = SANSHI_ROOT / "evolution" / "events"

# 关系类型
REL_TYPES = {
    "depends_on": "依赖",       # A 需要 B 才能工作
    "enhances": "增强",         # A 让 B 更好
    "conflicts": "冲突",        # A 和 B 矛盾
    "replaces": "替代",         # A 替代了 B
    "related": "相关",          # A 和 B 属于同一领域
}


class KnowledgeGraph:
    def __init__(self):
        self.data = {"nodes": [], "edges": [], "updated_at": None}
        if GRAPH_FILE.exists():
            try:
                self.data = json.loads(GRAPH_FILE.read_text(encoding="utf-8"))
            except:
                pass

    def save(self):
        self.data["updated_at"] = datetime.now().isoformat()
        GRAPH_FILE.parent.mkdir(parents=True, exist_ok=True)
        GRAPH_FILE.write_text(json.dumps(self.data, ensure_ascii=False, indent=2), encoding="utf-8")

    def add_node(self, name: str, category: str = "", score: float = 0.0):
        """添加节点"""
        for n in self.data["nodes"]:
            if n["name"] == name:
                return
        self.data["nodes"].append({
            "name": name,
            "category": category,
            "score": score,
            "created_at": datetime.now().isoformat(),
        })
        self.save()

    def add_edge(self, source: str, target: str, relation: str):
        """添加关系"""
        if relation not in REL_TYPES:
            print(f"❌ 未知关系: {relation}")
            print(f"   可用: {', '.join(REL_TYPES.keys())}")
            return

        # 确保节点存在
        self.add_node(source)
        self.add_node(target)

        edge_key = f"{source}|{target}|{relation}"
        for e in self.data["edges"]:
            if f"{e['source']}|{e['target']}|{e['relation']}" == edge_key:
                return  # 已存在

        self.data["edges"].append({
            "source": source,
            "target": target,
            "relation": relation,
            "created_at": datetime.now().isoformat(),
        })
        self.save()
        print(f"✅ {source} --[{REL_TYPES[relation]}]--> {target}")

    def query(self, node_name: str) -> dict:
        """查询节点的关系"""
        related = []
        for e in self.data["edges"]:
            if e["source"] == node_name or e["target"] == node_name:
                related.append(e)
        return {"name": node_name, "relations": related, "count": len(related)}

    def find_gaps(self) -> list:
        """查找孤立节点（没有关系的Gene）"""
        connected = set()
        for e in self.data["edges"]:
            connected.add(e["source"])
            connected.add(e["target"])
        
        gaps = []
        for n in self.data["nodes"]:
            if n["name"] not in connected:
                gaps.append(n["name"])
        return gaps

    def stats(self) -> dict:
        """统计"""
        relation_counts = defaultdict(int)
        for e in self.data["edges"]:
            relation_counts[e["relation"]] += 1
        
        return {
            "nodes": len(self.data["nodes"]),
            "edges": len(self.data["edges"]),
            "relations": dict(relation_counts),
            "updated_at": self.data.get("updated_at", "never"),
        }


def auto_discover_relations():
    """自动发现Gene之间的关系"""
    kg = KnowledgeGraph()
    genes = {}
    
    # 读取所有Gene
    for f in GENES_DIR.glob("*.yaml"):
        content = f.read_text(encoding="utf-8")
        name = ""
        for line in content.split("\n"):
            if line.startswith("name:"):
                name = line.split('"')[1] if '"' in line else line.split(":", 1)[1].strip()
                break
        if name:
            genes[name] = content.lower()
    
    # 检测关系
    gene_names = list(genes.keys())
    for i, name_a in enumerate(gene_names):
        content_a = genes[name_a]
        kg.add_node(name_a, category="auto-discovered")
        
        for name_b in gene_names[i + 1:]:
            content_b = genes[name_b]
            
            # 如果A的内容中提到了B的名字 → 依赖
            if name_b.lower() in content_a:
                kg.add_edge(name_a, name_b, "depends_on")
            
            # 如果内容有大量重叠 → 相关
            words_a = set(content_a.split())
            words_b = set(content_b.split())
            overlap = words_a & words_b
            if len(overlap) >= 5:
                kg.add_edge(name_a, name_b, "related")
    
    kg.save()
    return kg


def run(mode: str = "stats", args: list = None):
    """主入口"""
    kg = KnowledgeGraph()
    
    if mode == "add" and args and len(args) >= 3:
        kg.add_edge(args[0], args[1], args[2])
    
    elif mode == "query" and args:
        result = kg.query(args[0])
        if result["relations"]:
            print(f"🔗 {result['name']} 的关系 ({result['count']} 个):")
            for r in result["relations"]:
                arrow = REL_TYPES.get(r["relation"], r["relation"])
                if r["source"] == args[0]:
                    print(f"  → {r['target']} [{arrow}]")
                else:
                    print(f"  ← {r['source']} [{arrow}]")
        else:
            print(f"🔗 {args[0]} 没有关系（孤立节点）")
    
    elif mode == "find-gaps":
        gaps = kg.find_gaps()
        if gaps:
            print(f"⚠️ 孤立节点 ({len(gaps)} 个):")
            for g in gaps:
                print(f"  - {g}")
        else:
            print("✅ 所有节点都已关联")
    
    elif mode == "auto-discover":
        kg2 = auto_discover_relations()
        print("🔍 自动发现完成")
        s = kg2.stats()
        print(f"  节点: {s['nodes']}, 边: {s['edges']}")
    
    elif mode == "stats":
        s = kg.stats()
        print("📊 知识图谱状态:")
        print(f"  节点: {s['nodes']}")
        print(f"  边: {s['edges']}")
        if s["relations"]:
            print(f"  关系类型:")
            for rel, count in s["relations"].items():
                print(f"    {REL_TYPES.get(rel, rel)}: {count}")
        print(f"  更新: {s['updated_at']}")
    
    else:
        print("用法:")
        print(f"  {sys.argv[0]} add \"A\" \"B\" \"depends_on\"  # 添加关系")
        print(f"  {sys.argv[0]} query \"A\"                    # 查询关系")
        print(f"  {sys.argv[0]} find-gaps                      # 找孤立节点")
        print(f"  {sys.argv[0]} auto-discover                  # 自动发现关系")
        print(f"  {sys.argv[0]} stats                          # 统计")


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "stats"
    args = sys.argv[2:] if len(sys.argv) > 2 else []
    run(mode, args)
