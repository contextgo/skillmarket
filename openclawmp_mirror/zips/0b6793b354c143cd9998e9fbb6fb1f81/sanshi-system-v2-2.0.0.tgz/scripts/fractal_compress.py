#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 分形压缩模块（P3 升级）
===================================
自动从日→周→月→核心记忆压缩。

用法:
    python fractal_compress.py              # 正常运行
    python fractal_compress.py --dry-run    # 试运行
    python fractal_compress.py --week       # 只压缩本周
    python fractal_compress.py --month      # 只压缩本月

压缩规则:
- 每日笔记 → 周末 → 周精华 (weekly/YYYY-WXX.md)
- 4 周精华 → 月末 → 月精华 (monthly/YYYY-MM.md)
- 月精华 → 核心条目 → MEMORY.md
"""

import os
import sys
import json
import re
from datetime import datetime, timedelta
from pathlib import Path

# Paths
MEMORY_DIR = Path(os.path.expanduser("~/.stepclaw/workspace/memory"))
WEEKLY_DIR = MEMORY_DIR / "weekly"
MONTHLY_DIR = MEMORY_DIR / "monthly"
MEMORY_MD = MEMORY_DIR.parent / "MEMORY.md"
REPORTS_DIR = MEMORY_DIR / "reports"

sys.stdout.reconfigure(encoding="utf-8")


def read_daily(date_str):
    """Read a daily memory file and extract key entries."""
    path = MEMORY_DIR / f"{date_str}.md"
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        content = f.read()
    return content


def extract_sections(content):
    """Extract sections from daily memory, return list of (title, body) tuples."""
    sections = []
    current_title = None
    current_body = []
    
    for line in content.split("\n"):
        if line.startswith("## "):
            if current_title and current_body:
                sections.append((current_title, "\n".join(current_body).strip()))
            current_title = line[3:].strip()
            current_body = []
        elif current_title:
            current_body.append(line)
    
    if current_title and current_body:
        sections.append((current_title, "\n".join(current_body).strip()))
    
    return sections


def score_section(title, body):
    """Score a section for importance (1-10)."""
    text = f"{title} {body}".lower()
    score = 4  # base score
    
    # High-value signals
    if any(kw in text for kw in ["✅", "修复", "解决", "root cause", "根因", "已落地"]):
        score += 2
    if any(kw in text for kw in ["核心", "关键", "重要", "critical"]):
        score += 1
    if any(kw in text for kw in ["决策", "决定", "确认"]):
        score += 1
    if any(kw in text for kw in ["教训", "lesson", "经验", "模式", "pattern"]):
        score += 1
    if any(kw in text for kw in ["测试通过", "验证通过", "ok"]):
        score += 1
    
    # Penalize noise
    if any(kw in text for kw in ["心跳", "heartbeat", "扫描", "无变化", "跳过"]):
        score -= 2
    if any(kw in text for kw in ["安静模式", "夜间", "夜间模式"]):
        score -= 2
    
    return min(max(score, 1), 10)


def compress_week(week_start, dry_run=False):
    """Compress a week's daily notes into weekly summary."""
    week_notes = []
    for i in range(7):
        date = week_start + timedelta(days=i)
        date_str = date.strftime("%Y-%m-%d")
        content = read_daily(date_str)
        if content:
            sections = extract_sections(content)
            for title, body in sections:
                s = score_section(title, body)
                if s >= 5:  # Only keep medium+ importance
                    week_notes.append((date_str, title, body, s))
    
    if not week_notes:
        return None
    
    week_num = week_start.isocalendar()[1]
    year = week_start.isocalendar()[0]
    weekly_path = WEEKLY_DIR / f"{year}-W{week_num:02d}.md"
    
    if dry_run:
        print(f"[DRY RUN] Would create: {weekly_path}")
        print(f"  Sections to compress: {len(week_notes)}")
        return weekly_path
    
    # Create weekly summary
    lines = [f"# {year} 年第{week_num:02d}周记忆精华", f"\n压缩时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ""]
    lines.append("## 本周关键条目\n")
    
    core_entries = [(d, t, b, s) for d, t, b, s in week_notes if s >= 8]
    ref_entries = [(d, t, b, s) for d, t, b, s in week_notes if 5 <= s < 8]
    
    if core_entries:
        lines.append("### 核心（8-10分）\n")
        for date_str, title, body, score in core_entries:
            lines.append(f"**[{date_str}] {title}** ({score}/10)")
            # Truncate body to first 3 lines
            body_lines = body.split("\n")[:3]
            for line in body_lines:
                if line.strip():
                    lines.append(f"  {line.strip()}")
            lines.append("")
    
    if ref_entries:
        lines.append(f"### 参考（5-7分）— 共{len(ref_entries)}条\n")
        for date_str, title, _, score in ref_entries:
            lines.append(f"- [{date_str}] {title} ({score}/10)")
        lines.append("")
    
    lines.append(f"---\n*本周压缩: {len(week_notes)}条 → 核心{len(core_entries)}条 + 参考{len(ref_entries)}条*\n")
    
    WEEKLY_DIR.mkdir(parents=True, exist_ok=True)
    with open(weekly_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    
    print(f"[OK] Created: {weekly_path}")
    return weekly_path


def compress_month(month_str, dry_run=False):
    """Compress 4 weekly summaries into monthly summary."""
    year, month = map(int, month_str.split("-"))
    monthly_path = MONTHLY_DIR / f"{month_str}.md"
    
    if dry_run:
        print(f"[DRY RUN] Would create: {monthly_path}")
        return monthly_path
    
    # Read all weekly files for this month
    week_files = sorted(WEEKLY_DIR.glob(f"{year}-W*.md"))
    all_entries = []
    
    for wf in week_files:
        with open(wf, "r", encoding="utf-8", errors="replace") as f:
            content = f.read()
        sections = extract_sections(content)
        for title, body in sections:
            s = score_section(title, body)
            if s >= 7:  # Only keep high importance
                all_entries.append((wf.stem, title, body, s))
    
    if not all_entries:
        return None
    
    lines = [f"# {year}年{month}月记忆精华", f"\n压缩时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}", ""]
    lines.append("## 本月核心条目\n")
    
    for week_name, title, body, score in all_entries:
        lines.append(f"**[{week_name}] {title}** ({score}/10)")
        body_lines = body.split("\n")[:5]
        for line in body_lines:
            if line.strip():
                lines.append(f"  {line.strip()}")
        lines.append("")
    
    lines.append(f"---\n*本月压缩: 周精华{len(week_files)}份 → 核心{len(all_entries)}条*\n")
    
    MONTHLY_DIR.mkdir(parents=True, exist_ok=True)
    with open(monthly_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    
    print(f"[OK] Created: {monthly_path}")
    return monthly_path


def main():
    import argparse
    parser = argparse.ArgumentParser(description="三识系统 · 分形压缩")
    parser.add_argument("--dry-run", action="store_true", help="试运行")
    parser.add_argument("--week", action="store_true", help="只压缩本周")
    parser.add_argument("--month", action="store_true", help="只压缩本月")
    parser.add_argument("--days", type=int, default=7, help="过去N天")
    args = parser.parse_args()
    
    print("三识系统 · 分形压缩")
    print("=" * 40)
    
    if args.week or not args.month:
        # Compress past week
        today = datetime.now()
        week_start = today - timedelta(days=today.weekday())
        compress_week(week_start, dry_run=args.dry_run)
    
    if args.month:
        # Compress current month
        month_str = datetime.now().strftime("%Y-%m")
        compress_month(month_str, dry_run=args.dry_run)
    
    print("\n完成")


if __name__ == "__main__":
    main()
