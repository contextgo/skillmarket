#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
三识系统 · 记忆向量检索模块（识·记增强）
===========================================
基于 SQLite FTS5 的轻量级全文检索 + 相似度匹配。
不需要外部依赖，纯标准库实现。

用法:
    python vector_search.py init          # 初始化索引
    python vector_search.py search "邮箱"  # 搜索记忆
    python vector_search.py stats         # 统计索引状态
    python vector_search.py add "文件" "内容" # 手动添加
"""

import os
import sys
import re
import json
import hashlib
from datetime import datetime
from pathlib import Path
import sqlite3

WORKSPACE = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "workspace")
MEMORY_DIR = WORKSPACE / "memory"
MEMORY_MD = WORKSPACE / "MEMORY.md"

SANSHI_ROOT = Path(os.environ.get("USERPROFILE", "")).joinpath(".stepclaw", "skills", "三识系统")
VECTOR_DB = SANSHI_ROOT / "evolution" / "memory_index.db"


def safe_read(filepath: Path) -> str:
    """Read file with fallback encoding"""
    try:
        return filepath.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        try:
            return filepath.read_text(encoding="gbk")
        except:
            return filepath.read_text(encoding="latin-1")


class MemoryIndex:
    def __init__(self, db_path: str = None):
        self.db_path = db_path or str(VECTOR_DB)
        self.conn = sqlite3.connect(self.db_path)
        self.conn.execute("PRAGMA journal_mode=WAL")
        self._init_tables()

    def _init_tables(self):
        """创建 FTS5 表"""
        self.conn.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS memory_fts USING fts5(
                title, content, category, tags, source,
                tokenize='unicode61'
            )
        """)
        self.conn.execute("""
            CREATE TABLE IF NOT EXISTS memory_meta (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                hash TEXT UNIQUE,
                title TEXT,
                category TEXT,
                score INTEGER,
                created_at TEXT,
                updated_at TEXT,
                access_count INTEGER DEFAULT 0
            )
        """)
        self.conn.commit()

    def add(self, title: str, content: str, category: str = "", tags: str = "", source: str = "", score: int = 0):
        """添加记忆到索引"""
        doc_hash = hashlib.md5(f"{title}{content[:200]}".encode()).hexdigest()[:12]
        now = datetime.now().isoformat()
        try:
            self.conn.execute("""
                INSERT OR IGNORE INTO memory_fts (title, content, category, tags, source)
                VALUES (?, ?, ?, ?, ?)
            """, (title, content, category, tags, source))
            self.conn.execute("""
                INSERT OR IGNORE INTO memory_meta (hash, title, category, score, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (doc_hash, title, category, score, now, now))
            self.conn.commit()
            return True
        except sqlite3.IntegrityError:
            return False

    def search(self, query: str, limit: int = 10) -> list:
        """搜索记忆"""
        # FTS5 全文搜索
        results = self.conn.execute("""
            SELECT title, snippet(memory_fts, 1, '【', '】', '...', 60), category, source,
                   rank
            FROM memory_fts
            WHERE memory_fts MATCH ?
            ORDER BY rank
            LIMIT ?
        """, (query, limit)).fetchall()

        # 同时做元数据查询
        meta_results = self.conn.execute("""
            SELECT title, category, score, access_count
            FROM memory_meta
            WHERE title LIKE ? OR category LIKE ?
            ORDER BY score DESC
            LIMIT ?
        """, (f"%{query}%", f"%{query}%", limit)).fetchall()

        return {
            "fts": [{"title": r[0], "snippet": r[1], "category": r[2], "source": r[3], "rank": r[4]} for r in results],
            "meta": [{"title": r[0], "category": r[1], "score": r[2], "access_count": r[3]} for r in meta_results],
        }

    def stats(self) -> dict:
        """索引统计"""
        fts_count = self.conn.execute("SELECT COUNT(*) FROM memory_fts").fetchone()[0]
        meta_count = self.conn.execute("SELECT COUNT(*) FROM memory_meta").fetchone()[0]
        db_size = os.path.getsize(self.db_path) / 1024 if VECTOR_DB.exists() else 0
        return {
            "fts_documents": fts_count,
            "meta_records": meta_count,
            "db_size_kb": round(db_size, 1),
        }

    def close(self):
        self.conn.close()


def index_existing_files(idx: MemoryIndex):
    """将已存在的 memory 文件索引化"""
    indexed = 0
    
    # 1. MEMORY.md 核心记忆
    if MEMORY_MD.exists():
        content = safe_read(MEMORY_MD)
        # 按 ## 分割章节
        sections = re.split(r'\n## ', content)
        for section in sections:
            if not section.strip():
                continue
            lines = section.split('\n')
            title = lines[0].strip().lstrip('#').strip()
            body = '\n'.join(lines[1:])
            if len(body) > 50:
                idx.add(title=title, content=body, category="core", score=9, source="MEMORY.md")
                indexed += 1
    
    # 2. memory/*.md 每日记忆
    for f in sorted(MEMORY_DIR.glob("*.md")):
        if f.name.startswith("202") and f.name.endswith(".md"):
            content = safe_read(f)
            # 按 ## 分割
            sections = re.split(r'\n## ', content)
            for section in sections:
                if not section.strip():
                    continue
                lines = section.split('\n')
                title = lines[0].strip().lstrip('#').strip()
                body = '\n'.join(lines[1:])
                if len(body) > 50:
                    idx.add(title=title, content=body, category="daily", score=5, source=f.name)
                    indexed += 1
    
    # 3. memory/reference/ 参考记忆
    ref_dir = MEMORY_DIR / "reference"
    if ref_dir.exists():
        for f in ref_dir.glob("*.md"):
            content = safe_read(f)
            title = f.stem
            idx.add(title=title, content=content, category="reference", score=7, source=f.name)
            indexed += 1

    return indexed


def run(mode: str = "stats", query: str = ""):
    """主入口"""
    idx = MemoryIndex()
    
    if mode == "init":
        print("📊 正在索引现有记忆文件...")
        count = index_existing_files(idx)
        print(f"✅ 索引完成: {count} 条记忆")
    
    elif mode == "search" and query:
        results = idx.search(query)
        if results["fts"]:
            print(f"🔍 找到 {len(results['fts'])} 条结果:")
            for i, r in enumerate(results["fts"][:5], 1):
                print(f"\n{i}. [{r['category']}] {r['title']} (来源: {r['source']})")
                print(f"   {r['snippet']}")
        else:
            print(f"未找到匹配 '{query}' 的记忆")
    
    elif mode == "stats":
        s = idx.stats()
        print("📊 向量索引状态:")
        print(f"  FTS 文档: {s['fts_documents']}")
        print(f"  元数据: {s['meta_records']}")
        print(f"  数据库: {s['db_size_kb']} KB")
    
    elif mode == "add" and query:
        # 手动添加格式: "标题|内容"
        parts = query.split("|", 1)
        if len(parts) == 2:
            idx.add(title=parts[0], content=parts[1], category="manual", score=5)
            print(f"✅ 已添加: {parts[0]}")
        else:
            print("用法: python vector_search.py add \"标题|内容\"")
    
    idx.close()


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "stats"
    query = " ".join(sys.argv[2:]) if len(sys.argv) > 2 else ""
    run(mode, query)
