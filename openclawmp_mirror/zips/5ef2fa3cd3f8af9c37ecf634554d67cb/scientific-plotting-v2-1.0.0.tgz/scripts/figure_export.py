"""
图表导出模块

提供标准化的图表导出功能，支持多种格式和期刊要求
"""

import matplotlib.pyplot as plt
from matplotlib.figure import Figure
import os
from typing import List, Optional, Union
import numpy as np


def save_publication_figure(
    fig: Figure,
    filename: str,
    formats: List[str] = ['pdf', 'png'],
    dpi: int = 300,
    transparent: bool = False,
    bbox_inches: str = 'tight',
    pad_inches: float = 0.05,
    **kwargs
) -> List[str]:
    """
    导出出版级图表
    
    将图表保存为多种格式，满足期刊投稿要求
    
    Args:
        fig: matplotlib Figure对象
        filename: 文件名（不含扩展名）
        formats: 输出格式列表，支持 'pdf', 'png', 'tiff', 'eps', 'svg'
        dpi: 分辨率（位图格式），默认300
        transparent: 是否透明背景，默认False
        bbox_inches: 边界框设置，默认'tight'
        pad_inches: 边距（英寸），默认0.05
        **kwargs: 其他传递给savefig的参数
    
    Returns:
        List[str]: 保存的文件路径列表
    
    Raises:
        ValueError: 当格式不支持时
    
    Example:
        >>> import matplotlib.pyplot as plt
        >>> fig, ax = plt.subplots()
        >>> ax.plot([1, 2, 3], [1, 4, 9])
        >>> files = save_publication_figure(fig, 'figure1', formats=['pdf', 'png'])
        >>> print(files)
        ['figure1.pdf', 'figure1.png']
    """
    # 支持的格式
    supported_formats = ['pdf', 'png', 'tiff', 'eps', 'svg', 'jpg', 'jpeg']
    
    # 验证格式
    invalid_formats = [f for f in formats if f.lower() not in supported_formats]
    if invalid_formats:
        raise ValueError(
            f"不支持的格式: {invalid_formats}。"
            f"支持格式: {supported_formats}"
        )
    
    saved_files = []
    
    # 确保输出目录存在
    output_dir = os.path.dirname(filename)
    if output_dir and not os.path.exists(output_dir):
        os.makedirs(output_dir, exist_ok=True)
    
    # 保存各种格式
    for fmt in formats:
        fmt_lower = fmt.lower()
        
        # 处理JPEG格式别名
        if fmt_lower in ['jpg', 'jpeg']:
            output_path = f"{filename}.jpg"
            fig.savefig(
                output_path,
                format='jpeg',
                dpi=dpi,
                transparent=transparent,
                bbox_inches=bbox_inches,
                pad_inches=pad_inches,
                **kwargs
            )
        elif fmt_lower == 'tiff':
            # TIFF格式需要特殊处理
            output_path = f"{filename}.tiff"
            fig.savefig(
                output_path,
                format='tiff',
                dpi=dpi,
                transparent=transparent,
                bbox_inches=bbox_inches,
                pad_inches=pad_inches,
                **kwargs
            )
        else:
            output_path = f"{filename}.{fmt_lower}"
            fig.savefig(
                output_path,
                format=fmt_lower,
                dpi=dpi,
                transparent=transparent,
                bbox_inches=bbox_inches,
                pad_inches=pad_inches,
                **kwargs
            )
        
        saved_files.append(output_path)
    
    return saved_files


def save_for_journal(
    fig: Figure,
    filename: str,
    journal_name: str = 'default',
    output_dir: str = '.',
    **kwargs
) -> List[str]:
    """
    按期刊要求导出图表
    
    根据期刊规范自动选择格式、分辨率等参数
    
    Args:
        fig: matplotlib Figure对象
        filename: 文件名（不含扩展名）
        journal_name: 期刊名称，支持 'nature', 'science', 'cell', 'default'
        output_dir: 输出目录，默认当前目录
        **kwargs: 其他传递给save_publication_figure的参数
    
    Returns:
        List[str]: 保存的文件路径列表
    
    Example:
        >>> import matplotlib.pyplot as plt
        >>> fig, ax = plt.subplots()
        >>> ax.plot([1, 2, 3], [1, 4, 9])
        >>> files = save_for_journal(fig, 'figure1', 'nature')
    """
    # 导入期刊配置
    try:
        from scripts.style_presets import get_journal_config
    except ImportError:
        from style_presets import get_journal_config
    
    # 获取期刊配置
    config = get_journal_config(journal_name)
    export_config = config.get('export', {})
    
    # 从配置中提取参数
    formats = export_config.get('formats', ['pdf', 'png'])
    dpi = export_config.get('dpi', 300)
    transparent = export_config.get('transparent', False)
    
    # 合并kwargs
    save_kwargs = {**kwargs}
    if 'dpi' not in save_kwargs:
        save_kwargs['dpi'] = dpi
    if 'transparent' not in save_kwargs:
        save_kwargs['transparent'] = transparent
    
    # 构建完整路径
    full_path = os.path.join(output_dir, filename)
    
    # 调用通用导出函数
    return save_publication_figure(
        fig,
        full_path,
        formats=formats,
        **save_kwargs
    )


def export_figure_set(
    figures: List[Figure],
    base_name: str,
    journal_name: str = 'default',
    output_dir: str = '.',
    start_index: int = 1
) -> dict:
    """
    批量导出图表集
    
    将多个图表按序号批量导出
    
    Args:
        figures: Figure对象列表
        base_name: 基础文件名（如 'figure'）
        journal_name: 期刊名称
        output_dir: 输出目录
        start_index: 起始序号，默认1
    
    Returns:
        dict: {序号: [文件路径列表]}
    
    Example:
        >>> import matplotlib.pyplot as plt
        >>> figs = [plt.figure() for _ in range(3)]
        >>> result = export_figure_set(figs, 'figure', 'nature')
        >>> print(result)
        {1: ['figure1.pdf', 'figure1.png'], 2: [...], 3: [...]}
    """
    result = {}
    
    for idx, fig in enumerate(figures, start=start_index):
        filename = f"{base_name}{idx}"
        saved_files = save_for_journal(fig, filename, journal_name, output_dir)
        result[idx] = saved_files
    
    return result


def save_figure_with_metadata(
    fig: Figure,
    filename: str,
    metadata: dict,
    formats: List[str] = ['pdf'],
    **kwargs
) -> List[str]:
    """
    保存图表并添加元数据
    
    为PDF文件添加元数据信息
    
    Args:
        fig: matplotlib Figure对象
        filename: 文件名（不含扩展名）
        metadata: 元数据字典，可包含：
            - 'Title': 标题
            - 'Author': 作者
            - 'Subject': 主题
            - 'Keywords': 关键词
            - 'Creator': 创建者
        formats: 输出格式列表
        **kwargs: 其他参数
    
    Returns:
        List[str]: 保存的文件路径列表
    
    Example:
        >>> metadata = {
        ...     'Title': 'Figure 1',
        ...     'Author': 'John Doe',
        ...     'Subject': 'Research Data'
        ... }
        >>> files = save_figure_with_metadata(fig, 'figure1', metadata)
    """
    # 设置PDF元数据
    if 'pdf' in [f.lower() for f in formats]:
        metadata_dict = {}
        if 'Title' in metadata:
            metadata_dict['Title'] = metadata['Title']
        if 'Author' in metadata:
            metadata_dict['Author'] = metadata['Author']
        if 'Subject' in metadata:
            metadata_dict['Subject'] = metadata['Subject']
        if 'Keywords' in metadata:
            metadata_dict['Keywords'] = metadata['Keywords']
        if 'Creator' in metadata:
            metadata_dict['Creator'] = metadata['Creator']
        
        kwargs['metadata'] = metadata_dict
    
    return save_publication_figure(fig, filename, formats=formats, **kwargs)


def create_figure_archive(
    figures: List[Figure],
    archive_name: str,
    journal_name: str = 'default',
    temp_dir: str = './temp_figures'
) -> str:
    """
    创建图表归档文件
    
    将多个图表打包成ZIP文件
    
    Args:
        figures: Figure对象列表
        archive_name: 归档文件名（不含扩展名）
        journal_name: 期刊名称
        temp_dir: 临时目录
    
    Returns:
        str: 归档文件路径
    
    Example:
        >>> import matplotlib.pyplot as plt
        >>> figs = [plt.figure() for _ in range(3)]
        >>> archive = create_figure_archive(figs, 'all_figures', 'nature')
        >>> print(archive)
        'all_figures.zip'
    """
    import zipfile
    import shutil
    
    # 创建临时目录
    if os.path.exists(temp_dir):
        shutil.rmtree(temp_dir)
    os.makedirs(temp_dir)
    
    try:
        # 保存所有图表
        file_list = []
        for idx, fig in enumerate(figures, start=1):
            filename = f"figure_{idx}"
            saved_files = save_for_journal(fig, filename, journal_name, temp_dir)
            file_list.extend(saved_files)
        
        # 创建ZIP文件
        archive_path = f"{archive_name}.zip"
        with zipfile.ZipFile(archive_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for file_path in file_list:
                zipf.write(file_path, os.path.basename(file_path))
        
        return archive_path
    
    finally:
        # 清理临时目录
        if os.path.exists(temp_dir):
            shutil.rmtree(temp_dir)


def optimize_for_print(
    fig: Figure,
    target_size: tuple = (3.5, 2.5),
    dpi: int = 300
) -> Figure:
    """
    优化图表用于打印
    
    调整图表尺寸和分辨率以适应打印需求
    
    Args:
        fig: matplotlib Figure对象
        target_size: 目标尺寸（英寸），(width, height)
        dpi: 目标分辨率
    
    Returns:
        Figure: 优化后的Figure对象
    
    Example:
        >>> fig, ax = plt.subplots()
        >>> fig_optimized = optimize_for_print(fig, (7, 5), 600)
    """
    # 设置图表尺寸
    fig.set_size_inches(target_size)
    fig.set_dpi(dpi)
    
    return fig


if __name__ == '__main__':
    # 测试代码
    import matplotlib.pyplot as plt
    
    # 创建测试图表
    fig, ax = plt.subplots(figsize=(3.5, 2.5))
    ax.plot([1, 2, 3], [1, 4, 9], linewidth=0.5)
    ax.set_xlabel('X axis')
    ax.set_ylabel('Y axis')
    
    # 测试保存
    print("测试保存图表...")
    files = save_publication_figure(fig, 'test_figure', formats=['pdf', 'png'])
    print(f"已保存: {files}")
    
    # 测试期刊导出
    print("\n测试期刊导出...")
    files = save_for_journal(fig, 'test_nature', 'nature')
    print(f"Nature格式: {files}")
    
    print("\n导出测试完成")
