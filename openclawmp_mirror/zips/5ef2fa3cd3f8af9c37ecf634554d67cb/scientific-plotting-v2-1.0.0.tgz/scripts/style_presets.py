"""
期刊样式配置模块

提供顶级期刊（Nature、Science、Cell等）的样式配置功能
"""

import matplotlib.pyplot as plt
import matplotlib as mpl
from typing import Dict, Optional


# 期刊配置字典
JOURNAL_CONFIGS = {
    'nature': {
        'figure': {
            'figsize': (3.5, 2.5),  # 单栏宽度（英寸）
            'dpi': 300,
        },
        'font': {
            'family': 'Arial',
            'size': 7,
            'weight': 'normal',
        },
        'axes': {
            'linewidth': 0.5,
            'labelsize': 7,
            'titlesize': 7,
            'tick.major.width': 0.5,
            'tick.minor.width': 0.5,
            'tick.major.size': 3,
            'tick.minor.size': 2,
        },
        'lines': {
            'linewidth': 0.5,
            'markersize': 4,
        },
        'legend': {
            'fontsize': 7,
            'frameon': False,
        },
        'export': {
            'formats': ['pdf', 'png'],
            'dpi': 300,
            'transparent': False,
        }
    },

    'science': {
        'figure': {
            'figsize': (5.5, 4.0),  # Science单栏宽度
            'dpi': 300,
        },
        'font': {
            'family': 'Arial',
            'size': 9,
            'weight': 'normal',
        },
        'axes': {
            'linewidth': 0.75,
            'labelsize': 9,
            'titlesize': 9,
            'tick.major.width': 0.75,
            'tick.minor.width': 0.75,
            'tick.major.size': 4,
            'tick.minor.size': 2,
        },
        'lines': {
            'linewidth': 0.75,
            'markersize': 5,
        },
        'legend': {
            'fontsize': 9,
            'frameon': True,
        },
        'export': {
            'formats': ['pdf', 'png'],
            'dpi': 300,
            'transparent': False,
        }
    },

    'cell': {
        'figure': {
            'figsize': (6.5, 4.5),  # Cell单栏宽度
            'dpi': 300,
        },
        'font': {
            'family': 'Arial',
            'size': 10,
            'weight': 'normal',
        },
        'axes': {
            'linewidth': 1.0,
            'labelsize': 10,
            'titlesize': 10,
            'tick.major.width': 1.0,
            'tick.minor.width': 0.8,
            'tick.major.size': 4,
            'tick.minor.size': 2,
        },
        'lines': {
            'linewidth': 1.0,
            'markersize': 6,
        },
        'legend': {
            'fontsize': 10,
            'frameon': True,
        },
        'export': {
            'formats': ['pdf', 'png', 'tiff'],
            'dpi': 300,
            'transparent': False,
        }
    },

    'default': {
        'figure': {
            'figsize': (4.0, 3.0),
            'dpi': 150,
        },
        'font': {
            'family': 'sans-serif',
            'size': 8,
            'weight': 'normal',
        },
        'axes': {
            'linewidth': 0.5,
            'labelsize': 8,
            'titlesize': 8,
            'tick.major.width': 0.5,
            'tick.minor.width': 0.5,
            'tick.major.size': 3,
            'tick.minor.size': 2,
        },
        'lines': {
            'linewidth': 0.5,
            'markersize': 4,
        },
        'legend': {
            'fontsize': 8,
            'frameon': False,
        },
        'export': {
            'formats': ['pdf', 'png'],
            'dpi': 300,
            'transparent': False,
        }
    }
}


def apply_publication_style() -> None:
    """
    应用基础出版样式

    设置适合学术出版的基础参数，包括：
    - 字体族为sans-serif（Arial/Helvetica）
    - 基础字号为8pt
    - 线条宽度为0.5pt
    - 坐标轴样式和刻度参数
    - PDF/PS字体设置

    Returns:
        None
    """
    # 设置字体
    plt.rcParams['font.family'] = 'sans-serif'
    plt.rcParams['font.sans-serif'] = ['Arial', 'Helvetica', 'DejaVu Sans']
    plt.rcParams['font.size'] = 8
    plt.rcParams['font.weight'] = 'normal'

    # 设置坐标轴
    plt.rcParams['axes.linewidth'] = 0.5
    plt.rcParams['axes.labelsize'] = 8
    plt.rcParams['axes.titlesize'] = 8
    plt.rcParams['axes.labelweight'] = 'normal'
    plt.rcParams['axes.spines.top'] = True
    plt.rcParams['axes.spines.right'] = True

    # 设置刻度
    plt.rcParams['xtick.major.width'] = 0.5
    plt.rcParams['xtick.minor.width'] = 0.5
    plt.rcParams['ytick.major.width'] = 0.5
    plt.rcParams['ytick.minor.width'] = 0.5
    plt.rcParams['xtick.major.size'] = 3
    plt.rcParams['xtick.minor.size'] = 2
    plt.rcParams['ytick.major.size'] = 3
    plt.rcParams['ytick.minor.size'] = 2
    plt.rcParams['xtick.labelsize'] = 8
    plt.rcParams['ytick.labelsize'] = 8
    plt.rcParams['xtick.direction'] = 'in'
    plt.rcParams['ytick.direction'] = 'in'

    # 设置线条
    plt.rcParams['lines.linewidth'] = 0.5
    plt.rcParams['lines.markersize'] = 4

    # 设置图例
    plt.rcParams['legend.fontsize'] = 8
    plt.rcParams['legend.frameon'] = False
    plt.rcParams['legend.borderpad'] = 0.3
    plt.rcParams['legend.columnspacing'] = 1.0
    plt.rcParams['legend.handletextpad'] = 0.5

    # 设置图表
    plt.rcParams['figure.dpi'] = 150
    plt.rcParams['savefig.dpi'] = 300
    plt.rcParams['savefig.bbox'] = 'tight'
    plt.rcParams['savefig.pad_inches'] = 0.05

    # 设置PDF/PS字体
    plt.rcParams['pdf.fonttype'] = 42  # TrueType字体
    plt.rcParams['ps.fonttype'] = 42

    # 设置图像插值
    plt.rcParams['image.interpolation'] = 'none'
    plt.rcParams['image.cmap'] = 'viridis'


def configure_for_journal(journal_name: str = 'default') -> Dict:
    """
    配置期刊特定参数

    根据期刊要求自动调整图表尺寸、字体大小、线条粗细等参数

    Args:
        journal_name: 期刊名称，支持 'nature', 'science', 'cell', 'default'

    Returns:
        Dict: 期刊配置字典，包含所有样式参数

    Raises:
        ValueError: 当期刊名称不支持时

    Example:
        >>> config = configure_for_journal('nature')
        >>> print(config['font']['size'])
        7
    """
    # 获取期刊配置（使用字典的get方法，避免KeyError）
    config = JOURNAL_CONFIGS.get(journal_name.lower())

    if config is None:
        available_journals = ', '.join(JOURNAL_CONFIGS.keys())
        raise ValueError(
            f"不支持的期刊: '{journal_name}'。"
            f"可用期刊: {available_journals}"
        )

    # 应用字体设置
    font_config = config.get('font', {})
    plt.rcParams['font.family'] = font_config.get('family', 'sans-serif')
    if font_config.get('family') in ['Arial', 'Helvetica']:
        plt.rcParams['font.sans-serif'] = [font_config['family'], 'DejaVu Sans']
    plt.rcParams['font.size'] = font_config.get('size', 8)
    plt.rcParams['font.weight'] = font_config.get('weight', 'normal')

    # 应用坐标轴设置
    axes_config = config.get('axes', {})
    plt.rcParams['axes.linewidth'] = axes_config.get('linewidth', 0.5)
    plt.rcParams['axes.labelsize'] = axes_config.get('labelsize', 8)
    plt.rcParams['axes.titlesize'] = axes_config.get('titlesize', 8)
    plt.rcParams['xtick.major.width'] = axes_config.get('tick.major.width', 0.5)
    plt.rcParams['xtick.minor.width'] = axes_config.get('tick.minor.width', 0.5)
    plt.rcParams['ytick.major.width'] = axes_config.get('tick.major.width', 0.5)
    plt.rcParams['ytick.minor.width'] = axes_config.get('tick.minor.width', 0.5)
    plt.rcParams['xtick.major.size'] = axes_config.get('tick.major.size', 3)
    plt.rcParams['xtick.minor.size'] = axes_config.get('tick.minor.size', 2)
    plt.rcParams['ytick.major.size'] = axes_config.get('tick.major.size', 3)
    plt.rcParams['ytick.minor.size'] = axes_config.get('tick.minor.size', 2)
    plt.rcParams['xtick.labelsize'] = axes_config.get('labelsize', 8)
    plt.rcParams['ytick.labelsize'] = axes_config.get('labelsize', 8)

    # 应用线条设置
    lines_config = config.get('lines', {})
    plt.rcParams['lines.linewidth'] = lines_config.get('linewidth', 0.5)
    plt.rcParams['lines.markersize'] = lines_config.get('markersize', 4)

    # 应用图例设置
    legend_config = config.get('legend', {})
    plt.rcParams['legend.fontsize'] = legend_config.get('fontsize', 8)
    plt.rcParams['legend.frameon'] = legend_config.get('frameon', False)

    # 应用图表设置
    figure_config = config.get('figure', {})
    plt.rcParams['figure.dpi'] = figure_config.get('dpi', 150)
    plt.rcParams['savefig.dpi'] = figure_config.get('dpi', 300)

    # 应用PDF字体设置
    plt.rcParams['pdf.fonttype'] = 42
    plt.rcParams['ps.fonttype'] = 42

    return config


def get_journal_config(journal_name: str = 'default') -> Dict:
    """
    获取期刊配置字典

    返回指定期刊的完整配置信息，包括尺寸、字体、线条等参数

    Args:
        journal_name: 期刊名称，支持 'nature', 'science', 'cell', 'default'

    Returns:
        Dict: 期刊配置字典

    Raises:
        ValueError: 当期刊名称不支持时

    Example:
        >>> config = get_journal_config('nature')
        >>> print(config['figure']['figsize'])
        (3.5, 2.5)
    """
    config = JOURNAL_CONFIGS.get(journal_name.lower())

    if config is None:
        available_journals = ', '.join(JOURNAL_CONFIGS.keys())
        raise ValueError(
            f"不支持的期刊: '{journal_name}'。"
            f"可用期刊: {available_journals}"
        )

    # 返回配置的深拷贝，避免外部修改影响原始配置
    import copy
    return copy.deepcopy(config)


def get_available_journals() -> list:
    """
    获取支持的期刊列表

    Returns:
        list: 支持的期刊名称列表

    Example:
        >>> journals = get_available_journals()
        >>> print(journals)
        ['nature', 'science', 'cell', 'default']
    """
    return list(JOURNAL_CONFIGS.keys())


def get_figure_size(journal_name: str, columns: int = 1) -> tuple:
    """
    获取期刊图表尺寸

    根据期刊和栏数返回推荐的图表尺寸

    Args:
        journal_name: 期刊名称
        columns: 栏数（1=单栏，2=双栏）

    Returns:
        tuple: (width, height) 图表尺寸（英寸）

    Example:
        >>> size = get_figure_size('nature', columns=2)
        >>> print(size)
        (7.0, 2.5)
    """
    config = get_journal_config(journal_name)
    base_size = config['figure']['figsize']

    if columns == 2:
        # 双栏：宽度×2，高度保持不变
        # 期刊规范中双栏仅加宽，高度由内容决定，不随列数翻倍
        return (base_size[0] * 2, base_size[1])
    elif columns == 1:
        return base_size
    else:
        raise ValueError("columns参数必须为1（单栏）或2（双栏）")


if __name__ == '__main__':
    # 测试代码
    print("可用期刊:", get_available_journals())
    print("\nNature配置:")
    nature_config = get_journal_config('nature')
    print(f"  图表尺寸: {nature_config['figure']['figsize']}")
    print(f"  字体大小: {nature_config['font']['size']}")

    # 测试样式应用
    configure_for_journal('nature')
    print("\nNature样式已应用")
