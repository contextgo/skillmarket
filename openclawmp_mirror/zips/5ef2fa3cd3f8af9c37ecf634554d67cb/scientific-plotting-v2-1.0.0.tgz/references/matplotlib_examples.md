# Matplotlib 出版级图表示例

本文档包含多种图表类型的完整示例代码，可直接用于生成符合期刊投稿标准的学术图表。

## 目录

1. [基础线图](#基础线图)
2. [多面板布局](#多面板布局)
3. [误差棒图](#误差棒图)
4. [箱线图和小提琴图](#箱线图和小提琴图)
5. [热图](#热图)
6. [柱状图](#柱状图)
7. [散点图](#散点图)
8. [显著性标注](#显著性标注)
9. [复杂多面板图](#复杂多面板图)

---

## 基础线图

符合Nature期刊标准的单面板线图。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import configure_for_journal
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用Nature样式
configure_for_journal('nature')

# 创建数据
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = np.cos(x)

# 获取色盲友好调色板
colors = get_colorblind_palette('okabe_ito')

# 创建图表
fig, ax = plt.subplots(figsize=(3.5, 2.5))

# 绘制线条
ax.plot(x, y1, color=colors[0], label='Sin(x)', linewidth=0.5)
ax.plot(x, y2, color=colors[1], label='Cos(x)', linewidth=0.5)

# 设置标签和图例
ax.set_xlabel('X axis (units)')
ax.set_ylabel('Y axis (units)')
ax.legend(frameon=False, fontsize=7, loc='best')

# 调整刻度
ax.set_xlim(0, 10)
ax.set_ylim(-1.1, 1.1)

# 导出图表
save_publication_figure(fig, 'line_plot', formats=['pdf', 'png'], dpi=300)

plt.close()
print("线图已保存")
```

---

## 多面板布局

包含多个子图的图表布局，常见于展示多个实验结果。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import apply_publication_style
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用基础出版样式
apply_publication_style()

# 创建数据
np.random.seed(42)
x = np.linspace(0, 10, 50)
data_a = np.random.randn(50, 10)
data_b = np.random.randn(50, 10) * 1.5
data_c = np.random.randn(50, 10) * 0.8

# 获取调色板
colors = get_colorblind_palette('wong')

# 创建多面板图表（1行3列）
fig, axes = plt.subplots(1, 3, figsize=(10.5, 2.5))

# 面板A
axes[0].plot(x, data_a.mean(axis=1), color=colors[0], linewidth=0.5)
axes[0].fill_between(
    x,
    data_a.mean(axis=1) - data_a.std(axis=1),
    data_a.mean(axis=1) + data_a.std(axis=1),
    color=colors[0],
    alpha=0.2
)
axes[0].set_xlabel('Time (s)')
axes[0].set_ylabel('Response (a.u.)')
axes[0].text(-0.15, 1.05, 'A', transform=axes[0].transAxes, fontsize=9, fontweight='bold')

# 面板B
axes[1].plot(x, data_b.mean(axis=1), color=colors[1], linewidth=0.5)
axes[1].fill_between(
    x,
    data_b.mean(axis=1) - data_b.std(axis=1),
    data_b.mean(axis=1) + data_b.std(axis=1),
    color=colors[1],
    alpha=0.2
)
axes[1].set_xlabel('Time (s)')
axes[1].set_ylabel('Response (a.u.)')
axes[1].text(-0.15, 1.05, 'B', transform=axes[1].transAxes, fontsize=9, fontweight='bold')

# 面板C
axes[2].plot(x, data_c.mean(axis=1), color=colors[2], linewidth=0.5)
axes[2].fill_between(
    x,
    data_c.mean(axis=1) - data_c.std(axis=1),
    data_c.mean(axis=1) + data_c.std(axis=1),
    color=colors[2],
    alpha=0.2
)
axes[2].set_xlabel('Time (s)')
axes[2].set_ylabel('Response (a.u.)')
axes[2].text(-0.15, 1.05, 'C', transform=axes[2].transAxes, fontsize=9, fontweight='bold')

plt.tight_layout()

# 导出
save_publication_figure(fig, 'multipanel_line', formats=['pdf', 'png'], dpi=300)

plt.close()
print("多面板线图已保存")
```

---

## 误差棒图

展示实验数据均值和标准差的误差棒图。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import configure_for_journal
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用Nature样式
configure_for_journal('nature')

# 创建数据
np.random.seed(42)
conditions = ['Control', 'Treatment A', 'Treatment B', 'Treatment C']
x = np.arange(len(conditions))
data = np.random.randn(len(conditions), 20) * 0.3 + np.array([1, 2, 3, 2.5]).reshape(-1, 1)

# 计算均值和标准差
means = data.mean(axis=1)
stds = data.std(axis=1)

# 获取调色板
colors = get_colorblind_palette('tol_bright')

# 创建图表
fig, ax = plt.subplots(figsize=(3.5, 2.5))

# 绘制误差棒图
ax.errorbar(
    x, means, yerr=stds,
    fmt='o',  # 圆形标记
    color=colors[0],
    capsize=3,  # 误差棒帽长度
    capthick=0.5,  # 误差棒帽宽度
    linewidth=0.5,
    markersize=4
)

# 设置标签
ax.set_xlabel('Condition')
ax.set_ylabel('Response (units)')
ax.set_xticks(x)
ax.set_xticklabels(conditions, rotation=45, ha='right')

# 添加基线
ax.axhline(y=1, color='gray', linestyle='--', linewidth=0.5, alpha=0.5)

plt.tight_layout()

# 导出
save_publication_figure(fig, 'errorbar', formats=['pdf', 'png'], dpi=300)

plt.close()
print("误差棒图已保存")
```

---

## 箱线图和小提琴图

用于展示数据分布的统计图表。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import apply_publication_style
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用基础样式
apply_publication_style()

# 创建数据
np.random.seed(42)
groups = ['Group A', 'Group B', 'Group C']
data = [np.random.randn(50) + i for i in range(len(groups))]

# 获取调色板
colors = get_colorblind_palette('tol_muted')

# 创建多面板图表
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7, 2.5))

# 箱线图
bp = ax1.boxplot(
    data,
    patch_artist=True,
    widths=0.6,
    linewidth=0.5
)

# 设置箱线图颜色
for patch, color in zip(bp['boxes'], colors[:len(groups)]):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)

ax1.set_xlabel('Group')
ax1.set_ylabel('Value')
ax1.set_xticklabels(groups)
ax1.text(-0.15, 1.05, 'A', transform=ax1.transAxes, fontsize=9, fontweight='bold')

# 小提琴图
vp = ax2.violinplot(
    data,
    positions=range(len(groups)),
    showmeans=True,
    showmedians=True
)

# 设置小提琴图颜色
for i, (pc, color) in enumerate(zip(vp['bodies'], colors[:len(groups)])):
    pc.set_facecolor(color)
    pc.set_alpha(0.7)

ax2.set_xlabel('Group')
ax2.set_ylabel('Value')
ax2.set_xticks(range(len(groups)))
ax2.set_xticklabels(groups)
ax2.text(-0.15, 1.05, 'B', transform=ax2.transAxes, fontsize=9, fontweight='bold')

plt.tight_layout()

# 导出
save_publication_figure(fig, 'box_violin', formats=['pdf', 'png'], dpi=300)

plt.close()
print("箱线图和小提琴图已保存")
```

---

## 热图

用于展示矩阵数据或相关性矩阵。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import apply_publication_style
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_sequential_colormap

# 应用基础样式
apply_publication_style()

# 创建相关性矩阵
np.random.seed(42)
n = 6
data = np.random.randn(n, n)
corr_matrix = np.corrcoef(data)

# 标签
labels = ['Gene A', 'Gene B', 'Gene C', 'Gene D', 'Gene E', 'Gene F']

# 创建图表
fig, ax = plt.subplots(figsize=(4, 3.5))

# 获取色盲友好色图
cmap = get_sequential_colormap('iridescent')

# 绘制热图
im = ax.imshow(corr_matrix, cmap=cmap, aspect='auto', vmin=-1, vmax=1)

# 设置刻度和标签
ax.set_xticks(range(n))
ax.set_yticks(range(n))
ax.set_xticklabels(labels, rotation=45, ha='right')
ax.set_yticklabels(labels)

# 添加颜色条
cbar = plt.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
cbar.set_label('Correlation', fontsize=7)
cbar.ax.tick_params(labelsize=7)

# 添加数值标注
for i in range(n):
    for j in range(n):
        text = ax.text(j, i, f'{corr_matrix[i, j]:.2f}',
                       ha='center', va='center', color='black', fontsize=6)

plt.tight_layout()

# 导出
save_publication_figure(fig, 'heatmap', formats=['pdf', 'png'], dpi=300)

plt.close()
print("热图已保存")
```

---

## 柱状图

用于比较不同组别的数值。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import configure_for_journal
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用Nature样式
configure_for_journal('nature')

# 创建数据
categories = ['Category 1', 'Category 2', 'Category 3']
group1 = [3.5, 4.2, 2.8]
group2 = [2.8, 3.5, 3.2]
group3 = [4.1, 3.8, 4.5]

x = np.arange(len(categories))
width = 0.25

# 获取调色板
colors = get_colorblind_palette('okabe_ito')

# 创建图表
fig, ax = plt.subplots(figsize=(3.5, 2.5))

# 绘制柱状图
bars1 = ax.bar(x - width, group1, width, label='Group 1', color=colors[0], linewidth=0.5)
bars2 = ax.bar(x, group2, width, label='Group 2', color=colors[1], linewidth=0.5)
bars3 = ax.bar(x + width, group3, width, label='Group 3', color=colors[2], linewidth=0.5)

# 设置标签和图例
ax.set_xlabel('Category')
ax.set_ylabel('Value (units)')
ax.set_xticks(x)
ax.set_xticklabels(categories)
ax.legend(frameon=False, fontsize=6, ncol=3, loc='upper left')

# 添加网格线
ax.yaxis.grid(True, linestyle='--', linewidth=0.3, alpha=0.5)

plt.tight_layout()

# 导出
save_publication_figure(fig, 'bar_chart', formats=['pdf', 'png'], dpi=300)

plt.close()
print("柱状图已保存")
```

---

## 散点图

用于展示两个变量之间的关系。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import apply_publication_style
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用基础样式
apply_publication_style()

# 创建数据
np.random.seed(42)
n = 50
x1 = np.random.randn(n) * 2
y1 = x1 * 0.8 + np.random.randn(n) * 0.5

x2 = np.random.randn(n) * 2 + 2
y2 = x2 * 0.6 + np.random.randn(n) * 0.5 + 1

# 获取调色板
colors = get_colorblind_palette('tol_vibrant')

# 创建图表
fig, ax = plt.subplots(figsize=(4, 3))

# 绘制散点图
ax.scatter(x1, y1, c=colors[0], s=20, alpha=0.7, label='Group A', edgecolors='black', linewidths=0.3)
ax.scatter(x2, y2, c=colors[1], s=20, alpha=0.7, label='Group B', edgecolors='black', linewidths=0.3)

# 添加趋势线
for x, y, color in [(x1, y1, colors[0]), (x2, y2, colors[1])]:
    z = np.polyfit(x, y, 1)
    p = np.poly1d(z)
    x_line = np.linspace(x.min(), x.max(), 100)
    ax.plot(x_line, p(x_line), color=color, linewidth=0.5, linestyle='--', alpha=0.8)

# 设置标签和图例
ax.set_xlabel('Variable X (units)')
ax.set_ylabel('Variable Y (units)')
ax.legend(frameon=False, fontsize=7, loc='upper left')

plt.tight_layout()

# 导出
save_publication_figure(fig, 'scatter', formats=['pdf', 'png'], dpi=300)

plt.close()
print("散点图已保存")
```

---

## 显著性标注

在图表中添加统计显著性标注（p值或星号）。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import configure_for_journal
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用Nature样式
configure_for_journal('nature')

# 创建数据
np.random.seed(42)
conditions = ['Control', 'Treatment A', 'Treatment B']
x = np.arange(len(conditions))
data = np.random.randn(len(conditions), 20) * 0.3 + np.array([1, 2, 3]).reshape(-1, 1)

means = data.mean(axis=1)
stds = data.std(axis=1)

# 获取调色板
colors = get_colorblind_palette('tol_high_contrast')

# 创建图表
fig, ax = plt.subplots(figsize=(3.5, 2.5))

# 绘制柱状图
bars = ax.bar(x, means, yerr=stds, color=colors, capsize=3, linewidth=0.5)

# 设置标签
ax.set_xlabel('Condition')
ax.set_ylabel('Response (units)')
ax.set_xticks(x)
ax.set_xticklabels(conditions)

# 添加显著性标注
def add_significance(ax, x1, x2, y, text, linewidth=0.5):
    """添加显著性标注"""
    h = y * 0.05
    ax.plot([x1, x1, x2, x2], [y, y+h, y+h, y], color='black', linewidth=linewidth)
    ax.text((x1+x2)/2, y+h, text, ha='center', va='bottom', fontsize=7)

# Control vs Treatment A (p < 0.05)
add_significance(ax, 0, 1, max(means + stds) * 1.1, '*')

# Control vs Treatment B (p < 0.001)
add_significance(ax, 0, 2, max(means + stds) * 1.25, '***')

# Treatment A vs Treatment B (p < 0.01)
add_significance(ax, 1, 2, max(means + stds) * 1.0, '**')

# 添加p值说明
ax.text(
    0.98, 0.98,
    '*p<0.05, **p<0.01, ***p<0.001',
    transform=ax.transAxes,
    fontsize=6,
    ha='right',
    va='top'
)

plt.tight_layout()

# 导出
save_publication_figure(fig, 'significance', formats=['pdf', 'png'], dpi=300)

plt.close()
print("显著性标注图已保存")
```

---

## 复杂多面板图

综合展示多种图表类型的复杂布局。

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import apply_publication_style
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette, get_sequential_colormap

# 应用基础样式
apply_publication_style()

# 创建数据
np.random.seed(42)

# 获取调色板
colors = get_colorblind_palette('wong')

# 创建图表（2行3列）
fig = plt.figure(figsize=(10.5, 7))

# 定义子图布局
ax1 = plt.subplot2grid((2, 3), (0, 0))  # A: 线图
ax2 = plt.subplot2grid((2, 3), (0, 1))  # B: 柱状图
ax3 = plt.subplot2grid((2, 3), (0, 2))  # C: 散点图
ax4 = plt.subplot2grid((2, 3), (1, 0), colspan=2)  # D: 热图（占2列）
ax5 = plt.subplot2grid((2, 3), (1, 2))  # E: 箱线图

# A: 线图
x = np.linspace(0, 10, 50)
ax1.plot(x, np.sin(x), color=colors[0], linewidth=0.5, label='Series 1')
ax1.plot(x, np.cos(x), color=colors[1], linewidth=0.5, label='Series 2')
ax1.set_xlabel('Time (s)')
ax1.set_ylabel('Amplitude')
ax1.legend(frameon=False, fontsize=6)
ax1.text(-0.15, 1.05, 'A', transform=ax1.transAxes, fontsize=9, fontweight='bold')

# B: 柱状图
categories = ['Cat 1', 'Cat 2', 'Cat 3']
values = [3.5, 4.2, 2.8]
ax2.bar(range(len(categories)), values, color=colors[:3], linewidth=0.5)
ax2.set_xlabel('Category')
ax2.set_ylabel('Value')
ax2.set_xticks(range(len(categories)))
ax2.set_xticklabels(categories, fontsize=6)
ax2.text(-0.15, 1.05, 'B', transform=ax2.transAxes, fontsize=9, fontweight='bold')

# C: 散点图
x_scatter = np.random.randn(30) * 2
y_scatter = x_scatter * 0.8 + np.random.randn(30) * 0.5
ax3.scatter(x_scatter, y_scatter, c=colors[0], s=15, alpha=0.7, edgecolors='black', linewidths=0.3)
ax3.set_xlabel('Variable X')
ax3.set_ylabel('Variable Y')
ax3.text(-0.15, 1.05, 'C', transform=ax3.transAxes, fontsize=9, fontweight='bold')

# D: 热图
data_matrix = np.random.randn(10, 15)
cmap = get_sequential_colormap('iridescent')
im = ax4.imshow(data_matrix, cmap=cmap, aspect='auto')
ax4.set_xlabel('Column')
ax4.set_ylabel('Row')
ax4.text(-0.05, 1.05, 'D', transform=ax4.transAxes, fontsize=9, fontweight='bold')
cbar = plt.colorbar(im, ax=ax4, fraction=0.046, pad=0.04)
cbar.ax.tick_params(labelsize=6)

# E: 箱线图
box_data = [np.random.randn(30) + i for i in range(3)]
bp = ax5.boxplot(box_data, patch_artist=True, widths=0.6, linewidth=0.5)
for patch, color in zip(bp['boxes'], colors[:3]):
    patch.set_facecolor(color)
    patch.set_alpha(0.7)
ax5.set_xlabel('Group')
ax5.set_ylabel('Value')
ax5.set_xticklabels(['G1', 'G2', 'G3'], fontsize=6)
ax5.text(-0.15, 1.05, 'E', transform=ax5.transAxes, fontsize=9, fontweight='bold')

plt.tight_layout()

# 导出
save_publication_figure(fig, 'complex_multipanel', formats=['pdf', 'png'], dpi=300)

plt.close()
print("复杂多面板图已保存")
```

---

## 使用建议

### 1. 图表尺寸选择

根据期刊要求选择合适的图表尺寸：

- **Nature单栏**：3.5英寸宽
- **Nature双栏**：7.0英寸宽
- **Science**：5.5英寸宽
- **Cell单栏**：6.5英寸宽

### 2. 调色板选择

根据数据类型选择合适的调色板：

- **分类数据**：Okabe-Ito、Wong、Tol Bright
- **少量分类（≤3）**：Tol High Contrast
- **连续数据**：Tol Sequential色图
- **正负对比**：Tol Diverging色图

### 3. 文件格式选择

- **优先PDF**：矢量图，无损缩放，适合期刊投稿
- **补充PNG**：位图，适合网络展示，需300+ dpi
- **特殊要求**：部分期刊要求TIFF或EPS格式

### 4. 常见问题

**Q: 字体显示问题**
A: 确保系统安装了Arial字体，或修改配置使用Helvetica替代。

**Q: 颜色显示不一致**
A: 使用本技能提供的调色板，避免使用matplotlib默认颜色。

**Q: 导出文件过大**
A: PDF文件通常较小。如需进一步压缩，可降低PNG的dpi或使用图像压缩工具。

---

## 参考资源

- [Matplotlib官方文档](https://matplotlib.org/)
- [Seaborn官方文档](https://seaborn.pydata.org/)
- [Nature投稿指南](https://www.nature.com/nature/for-authors/formatting-guide)
- [Science投稿指南](https://www.science.org/content/page/instructions-preparing-initial-manuscript)
- [Cell投稿指南](https://www.cell.com/cell/author-resources)
