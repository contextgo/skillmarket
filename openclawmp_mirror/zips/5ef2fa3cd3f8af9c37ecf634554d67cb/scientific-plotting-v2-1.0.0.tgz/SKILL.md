---
name: scientific-plotting-v2
description: 出版级学术图表生成工具，一键适配 Nature/Science/Cell 等顶级期刊格式规范（尺寸/字号/线宽），内置 Okabe-Ito/Wong/Paul Tol 色盲友好调色板，支持线图、柱图、散点图、箱线图、热图、多面板布局、显著性标注、误差棒等9种图表类型，导出 PDF/PNG/TIFF/EPS/SVG 高质量格式。
dependency:
  python:
    - matplotlib>=3.5.0
    - numpy>=1.20.0
    - seaborn>=0.11.0
    - Pillow>=8.0.0
---

# 学术图表生成技能

## 任务目标
- **期刊规范**：自动应用 Nature（7pt/3.5"）、Science（9pt/5.5"）、Cell（10pt/6.5"）官方格式参数，告别手动调参
- **色盲友好**：内置7种经过科学验证的调色板（Okabe-Ito/Wong/Paul Tol系列），约8%色觉障碍读者同样可辨
- **图表类型**：线图、柱图、散点图、箱线图、小提琴图、热图、误差棒图、显著性标注图、复杂多面板图
- **高质量导出**：PDF（矢量，首选）/PNG/TIFF（300 dpi）/EPS/SVG，满足不同期刊提交要求
- **触发条件**：需要投稿级图表、配置特定期刊格式、数据可视化、色盲友好配色

## 前置准备
- 依赖说明：scripts脚本所需的依赖包及版本
  ```
  matplotlib>=3.5.0
  numpy>=1.20.0
  seaborn>=0.11.0
  Pillow>=8.0.0
  ```

## 操作步骤

### 标准流程

**步骤1：应用基础出版样式**
- 调用 `scripts/style_presets.py` 中的 `apply_publication_style()` 函数
- 该函数会设置：
  - 字体族为Arial或Helvetica
  - 基础字号为7-9pt
  - 线条宽度为0.5-1.0pt
  - 坐标轴样式和刻度参数
- 示例：
  ```python
  from scripts.style_presets import apply_publication_style
  apply_publication_style()
  ```

**步骤2：配置期刊特定参数**
- 调用 `scripts/style_presets.py` 中的 `configure_for_journal(journal_name)` 函数
- 支持的期刊：
  - `nature`：Nature系列期刊
  - `science`：Science期刊
  - `cell`：Cell系列期刊
  - `default`：通用学术样式
- 该函数会根据期刊要求调整：
  - 图表尺寸（Nature: 3.5×2.5 inches, Science: 5.5×4 inches）
  - 字体大小（Nature: 7pt, Science: 9pt）
  - 线条粗细
  - 分辨率要求
- 示例：
  ```python
  from scripts.style_presets import configure_for_journal
  configure_for_journal('nature')
  ```

**步骤3：创建图表并应用色盲友好配色**
- 智能体根据用户数据类型和需求，使用Matplotlib/Seaborn/Plotly创建图表
- 调用 `assets/color_palettes.py` 应用色盲友好调色板
- 可用调色板：
  - `okabe_ito`：Okabe-Ito调色板（8色）
  - `wong`：Wong调色板（8色）
  - `tol_bright`：Paul Tol亮色系
  - `tol_muted`：Paul Tol柔色系
  - `tol_high_contrast`：Paul Tol高对比度
- 示例：
  ```python
  from assets.color_palettes import get_colorblind_palette

  colors = get_colorblind_palette('okabe_ito')
  plt.plot(x, y, color=colors[0], label='Dataset 1')
  ```

**步骤4：添加专业元素**
- 智能体根据需求添加：
  - 误差棒：使用 `plt.errorbar()` 或在seaborn中设置 `ci` 参数
  - 显著性标注：使用 `plt.text()` 或 `plt.annotate()` 添加p值或星号
  - 多面板布局：使用 `plt.subplots()` 创建多子图
  - 图例优化：调整位置、字体大小和边框样式

**步骤5：导出符合要求的文件**
- 调用 `scripts/figure_export.py` 导出图表
- 支持格式：PDF、PNG、TIFF、EPS、SVG
- 自动设置期刊要求的分辨率（Nature: 300 dpi, Science: 300 dpi）
- 示例：
  ```python
  from scripts.figure_export import save_publication_figure

  save_publication_figure(fig, 'figure1', formats=['pdf', 'png'], dpi=300)
  ```

### 可选分支

**当需要快速生成期刊特定图表**：
- 直接使用 `save_for_journal()` 函数
- 该函数会自动应用期刊样式并导出符合要求的文件
- 示例：
  ```python
  from scripts.figure_export import save_for_journal
  save_for_journal(fig, 'figure1', 'nature')
  ```

**当需要使用Nature样式文件**：
- 使用Matplotlib的样式文件快速应用Nature样式
- 示例：
  ```python
  import matplotlib.pyplot as plt
  plt.style.use('assets/nature.mplstyle')
  ```

**当需要查看完整示例**：
- 参考 `references/matplotlib_examples.md` 中的详细代码示例
- 包含：线图、多面板图、箱线图、热图、小提琴图等多种类型

## 资源索引

### 必要脚本
- [scripts/style_presets.py](scripts/style_presets.py)：期刊样式配置
  - `apply_publication_style()`：应用基础出版样式
  - `configure_for_journal(journal_name)`：配置期刊特定参数
  - `get_journal_config(journal_name)`：获取期刊配置字典

- [scripts/figure_export.py](scripts/figure_export.py)：图表导出功能
  - `save_publication_figure(fig, filename, dpi, formats)`：导出多格式图表
  - `save_for_journal(fig, filename, journal_name)`：按期刊要求导出

### 资产文件
- [assets/color_palettes.py](assets/color_palettes.py)：色盲友好调色板
  - Okabe-Ito、Wong、Paul Tol系列调色板
  - `get_colorblind_palette(name)`：获取调色板
  - `apply_colorblind_palette(ax, palette_name)`：应用到图表

- [assets/nature.mplstyle](assets/nature.mplstyle)：Nature期刊样式文件
  - 可直接用 `plt.style.use()` 加载

### 参考文档
- [references/matplotlib_examples.md](references/matplotlib_examples.md)：完整示例库
  - 包含多种图表类型的完整代码
  - 每个示例都有详细注释
  - 可直接复制修改使用

## 注意事项

1. **字体要求**
   - Nature：Arial或Helvetica，7pt
   - Science：Arial，9pt
   - Cell：Arial或Helvetica，6-14pt
   - 如果系统中没有Arial，可使用Helvetica或sans-serif替代

2. **图表尺寸**
   - Nature单栏：3.5 inches宽
   - Nature双栏：7.0 inches宽
   - Science：5.5 inches宽
   - 建议在设计时就确定图表宽度

3. **分辨率**
   - 位图格式（PNG/TIFF）：至少300 dpi
   - 矢量格式（PDF/EPS/SVG）：无分辨率限制
   - 推荐优先使用PDF格式

4. **色盲友好设计**
   - 约8%的男性和0.5%的女性有色觉障碍
   - 避免仅用红绿区分数据
   - 优先使用本技能提供的调色板
   - 必要时添加纹理或形状作为辅助区分

5. **多面板布局**
   - 使用 `plt.subplots(nrows, ncols)` 创建
   - 子图间距：`plt.tight_layout()` 或 `plt.subplots_adjust()`
   - 子图标签：A、B、C等，使用 `plt.text()` 添加

## 使用示例

### 示例1：投稿 Nature 的单栏线图

```
用户：两组时间序列数据，需要 Nature 投稿标准线图，色盲友好

技能执行：
configure_for_journal('nature')               # 自动设置 7pt 字号、0.5pt 线宽
colors = get_colorblind_palette('okabe_ito')  # 色盲友好调色板
fig, ax = plt.subplots(figsize=(3.5, 2.5))   # Nature 单栏标准尺寸
ax.plot(x, y1, color=colors[0], linewidth=0.5, label='Control')
ax.plot(x, y2, color=colors[1], linewidth=0.5, label='Treatment')
ax.legend(frameon=False, fontsize=7)
save_publication_figure(fig, 'figure1', formats=['pdf', 'png'], dpi=300)
→ 输出：figure1.pdf（矢量）+ figure1.png（300dpi）
```

### 示例1b：原始代码示例（Nature样式）

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import configure_for_journal
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用Nature样式
configure_for_journal('nature')

# 创建数据
x = np.linspace(0, 10, 100)
y1 = np.sin(x)
y2 = np.cos(x)

# 获取色盲友好调色板
colors = get_colorblind_palette('okabe_ito')

# 创建图表
fig, ax = plt.subplots(figsize=(3.5, 2.5))
ax.plot(x, y1, color=colors[0], label='Sin', linewidth=0.5)
ax.plot(x, y2, color=colors[1], label='Cos', linewidth=0.5)

# 设置标签
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')
ax.legend(frameon=False, fontsize=7)

# 导出
save_publication_figure(fig, 'line_plot', formats=['pdf', 'png'], dpi=300)
```

### 示例2：多面板布局（带误差棒）

```python
import matplotlib.pyplot as plt
import numpy as np
from scripts.style_presets import apply_publication_style
from scripts.figure_export import save_publication_figure
from assets.color_palettes import get_colorblind_palette

# 应用基础样式
apply_publication_style()

# 创建数据
np.random.seed(42)
x = np.arange(5)
data1 = np.random.randn(5, 10)
data2 = np.random.randn(5, 10) * 1.5

# 获取调色板
colors = get_colorblind_palette('wong')

# 创建多面板图表
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(7, 2.5))

# 面板A：误差棒图
means1 = data1.mean(axis=1)
stds1 = data1.std(axis=1)
ax1.errorbar(x, means1, yerr=stds1, fmt='o-', color=colors[0],
             capsize=3, capthick=0.5, linewidth=0.5, markersize=4)
ax1.set_xlabel('Condition')
ax1.set_ylabel('Response')
ax1.text(-0.1, 1.1, 'A', transform=ax1.transAxes, fontsize=9, fontweight='bold')

# 面板B：误差棒图
means2 = data2.mean(axis=1)
stds2 = data2.std(axis=1)
ax2.errorbar(x, means2, yerr=stds2, fmt='s-', color=colors[1],
             capsize=3, capthick=0.5, linewidth=0.5, markersize=4)
ax2.set_xlabel('Condition')
ax2.set_ylabel('Response')
ax2.text(-0.1, 1.1, 'B', transform=ax2.transAxes, fontsize=9, fontweight='bold')

plt.tight_layout()

# 导出
save_publication_figure(fig, 'multipanel', formats=['pdf', 'png'], dpi=300)
```

### 示例2：双栏多面板图（含显著性标注）

```
用户：Nature 双栏图，A 面板误差棒，B 面板箱线图，标注 p 值

技能执行：
figsize = get_figure_size('nature', columns=2)  # → (7.0, 2.5)
fig, (ax1, ax2) = plt.subplots(1, 2, figsize=figsize)
# 面板A：误差棒
ax1.errorbar(x, means, yerr=stds, fmt='o-', color=colors[0], capsize=3)
ax1.text(-0.15, 1.05, 'A', transform=ax1.transAxes, fontweight='bold')
# 面板B：箱线图 + 显著性
bp = ax2.boxplot(data, patch_artist=True)
# 添加 *** 标注（p<0.001）
ax2.text(-0.15, 1.05, 'B', transform=ax2.transAxes, fontweight='bold')
save_for_journal(fig, 'figure2', 'nature')
```

### 示例3：快速套用期刊样式文件

```python
import matplotlib.pyplot as plt
import numpy as np

# 直接加载Nature样式文件
plt.style.use('assets/nature.mplstyle')

# 创建图表
x = np.linspace(0, 10, 100)
fig, ax = plt.subplots(figsize=(3.5, 2.5))
ax.plot(x, np.sin(x), linewidth=0.5)
ax.set_xlabel('X axis')
ax.set_ylabel('Y axis')

# 导出
fig.savefig('figure.pdf', dpi=300, bbox_inches='tight')
```

## 快速参考

### 期刊尺寸速查

| 期刊 | 单栏宽度 | 双栏宽度 | 字号 | 字体 |
|------|---------|---------|------|------|
| Nature | 3.5" | 7.0" | 7pt | Arial/Helvetica |
| Science | 5.5" | N/A | 9pt | Arial |
| Cell | 6.5" | 8.5" | 6-14pt | Arial/Helvetica |

### 调色板速查

| 调色板名称 | 颜色数 | 特点 | 适用场景 |
|-----------|--------|------|---------|
| okabe_ito | 8 | 经典色盲友好 | 分类数据 |
| wong | 8 | 高对比度 | 分类数据 |
| tol_bright | 7 | 明亮鲜艳 | 需要高可见度 |
| tol_muted | 7 | 柔和中性 | 学术报告 |
| tol_high_contrast | 3 | 极高对比 | 二/三类数据 |

### 导出格式建议

- **PDF**：首选格式，矢量图，无损缩放
- **PNG**：位图，适合网络展示，需300+ dpi
- **TIFF**：期刊接受度高，位图，需300+ dpi
- **EPS**：矢量图，部分期刊要求
- **SVG**：矢量图，适合网页展示
