"""
色盲友好调色板模块

提供多种色盲友好的调色板，确保图表对所有读者都清晰可辨
"""

import numpy as np
from typing import List, Dict, Optional, Union
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap, ListedColormap
import matplotlib as mpl


# Okabe-Ito 调色板（8色）
# 来源：Okabe & Ito (2008) - Color Universal Design
OKABE_ITO_COLORS = [
    '#E69F00',  # Orange
    '#56B4E9',  # Sky Blue
    '#009E73',  # Bluish Green
    '#F0E442',  # Yellow
    '#0072B2',  # Blue
    '#D55E00',  # Vermillion
    '#CC79A7',  # Reddish Purple
    '#000000',  # Black
]

# Wong 调色板（8色）
# 来源：Wong (2011) - Points of view: Color blindness
WONG_COLORS = [
    '#000000',  # Black
    '#E69F00',  # Orange
    '#56B4E9',  # Sky Blue
    '#009E73',  # Bluish Green
    '#F0E442',  # Yellow
    '#0072B2',  # Blue
    '#D55E00',  # Vermillion
    '#CC79A7',  # Reddish Purple
]

# Paul Tol 调色板系列
# 来源：Paul Tol (2021) - Colour Schemes

# Bright调色板（7色）- 明亮鲜艳
TOL_BRIGHT_COLORS = [
    '#4477AA',  # Blue
    '#EE6677',  # Red
    '#228833',  # Green
    '#CCBB44',  # Yellow
    '#66CCEE',  # Cyan
    '#AA3377',  # Purple
    '#BBBBBB',  # Grey
]

# Muted调色板（9色）- 柔和中性
TOL_MUTED_COLORS = [
    '#332288',  # Indigo
    '#88CCEE',  # Cyan
    '#44AA99',  # Teal
    '#117733',  # Green
    '#999933',  # Olive
    '#DDCC77',  # Sand
    '#CC6677',  # Rose
    '#882255',  # Wine
    '#AA4499',  # Purple
]

# High Contrast调色板（3色）- 极高对比度
TOL_HIGH_CONTRAST_COLORS = [
    '#004488',  # Blue
    '#DDAA33',  # Yellow
    '#BB5566',  # Red
]

# Vibrant调色板（7色）- 充满活力
TOL_VIBRANT_COLORS = [
    '#0077BB',  # Blue
    '#33BBEE',  # Cyan
    '#009988',  # Teal
    '#EE7733',  # Orange
    '#CC3311',  # Red
    '#EE3377',  # Magenta
    '#BBBBBB',  # Grey
]

# Light调色板（9色）- 浅色系
TOL_LIGHT_COLORS = [
    '#77AADD',  # Light Blue
    '#99DDFF',  # Light Cyan
    '#44BB99',  # Mint
    '#BBCC33',  # Pear
    '#AAAA00',  # Olive
    '#EEDD88',  # Light Yellow
    '#EE8866',  # Light Orange
    '#FFAABB',  # Light Pink
    '#DDDDDD',  # Pale Grey
]

# 连续型调色板（用于热图、等高线图等）
TOL_SEQUENTIAL = {
    'iridescent': [
        '#FEFBE9', '#FCF7D5', '#F5F3C1', '#EAF6B8',
        '#B8E596', '#7ACA90', '#4CAB8F', '#388B89',
        '#2B7A8B', '#206978', '#155567', '#0A3C53',
        '#042A3F'
    ],
    'devon': [
        '#F7F7F7', '#D9D9D9', '#B4B4B4', '#8C8C8C',
        '#6B6B6B', '#4D4D4D', '#2B2B2B', '#000000'
    ],
    'lajolla': [
        '#FCFFFD', '#F0F8F4', '#D9EFE2', '#B8E5D1',
        '#8DD9BE', '#5ECBA8', '#3ABA90', '#26A879',
        '#1B9563', '#14804E', '#0F6A3A', '#0A542C',
        '#063E1F', '#032813', '#00140A'
    ]
}

# 发散型调色板（用于正负值对比）
TOL_DIVERGING = {
    'sunset': [
        '#364B9A', '#4A7BB7', '#6A9ECF', '#94C2DB',
        '#C0D7EE', '#E6EFF6', '#FFFFFF',
        '#FDECC9', '#F7CCA8', '#F0A88A', '#E6826B',
        '#D65444', '#C72E22', '#A21610'
    ],
    'buwr': [
        '#2166AC', '#3A7BB0', '#5390B4', '#6BA5B8',
        '#84BABC', '#9CD0C0', '#B5E5C4', '#FFFFFF',
        '#FFD0AC', '#FFB88B', '#FFA06A', '#FF8849',
        '#FF7029', '#F95707', '#E05005'
    ]
}


# 调色板字典（用于get_colorblind_palette函数）
COLORBLIND_PALETTES = {
    'okabe_ito': OKABE_ITO_COLORS,
    'wong': WONG_COLORS,
    'tol_bright': TOL_BRIGHT_COLORS,
    'tol_muted': TOL_MUTED_COLORS,
    'tol_high_contrast': TOL_HIGH_CONTRAST_COLORS,
    'tol_vibrant': TOL_VIBRANT_COLORS,
    'tol_light': TOL_LIGHT_COLORS,
}


def get_colorblind_palette(name: str = 'okabe_ito') -> List[str]:
    """
    获取色盲友好调色板
    
    Args:
        name: 调色板名称，支持：
            - 'okabe_ito': Okabe-Ito调色板（8色）
            - 'wong': Wong调色板（8色）
            - 'tol_bright': Paul Tol亮色系（7色）
            - 'tol_muted': Paul Tol柔色系（9色）
            - 'tol_high_contrast': Paul Tol高对比度（3色）
            - 'tol_vibrant': Paul Tol活力系（7色）
            - 'tol_light': Paul Tol浅色系（9色）
    
    Returns:
        List[str]: 十六进制颜色代码列表
    
    Raises:
        ValueError: 当调色板名称不支持时
    
    Example:
        >>> colors = get_colorblind_palette('okabe_ito')
        >>> print(colors[:3])
        ['#E69F00', '#56B4E9', '#009E73']
    """
    palette = COLORBLIND_PALETTES.get(name.lower())
    
    if palette is None:
        available_palettes = ', '.join(COLORBLIND_PALETTES.keys())
        raise ValueError(
            f"不支持的调色板: '{name}'。"
            f"可用调色板: {available_palettes}"
        )
    
    return palette.copy()


def get_available_palettes() -> List[str]:
    """
    获取可用的调色板列表
    
    Returns:
        List[str]: 调色板名称列表
    
    Example:
        >>> palettes = get_available_palettes()
        >>> print(palettes)
        ['okabe_ito', 'wong', 'tol_bright', ...]
    """
    return list(COLORBLIND_PALETTES.keys())


def apply_colorblind_palette(
    ax: plt.Axes,
    palette_name: str = 'okabe_ito',
    n_colors: Optional[int] = None
) -> plt.Axes:
    """
    将色盲友好调色板应用到图表
    
    设置当前颜色循环为指定的调色板
    
    Args:
        ax: matplotlib Axes对象
        palette_name: 调色板名称
        n_colors: 使用的颜色数量，None表示使用全部
    
    Returns:
        plt.Axes: 应用了调色板的Axes对象
    
    Example:
        >>> import matplotlib.pyplot as plt
        >>> fig, ax = plt.subplots()
        >>> ax = apply_colorblind_palette(ax, 'wong')
        >>> for i in range(3):
        ...     ax.plot([1, 2, 3], [i]*3)
    """
    colors = get_colorblind_palette(palette_name)
    
    if n_colors is not None and n_colors < len(colors):
        colors = colors[:n_colors]
    
    # 设置颜色循环
    ax.set_prop_cycle('color', colors)
    
    return ax


def create_colormap(
    colors: List[str],
    name: str = 'custom',
    N: int = 256
) -> LinearSegmentedColormap:
    """
    从颜色列表创建连续型色图
    
    Args:
        colors: 颜色列表（十六进制或颜色名称）
        name: 色图名称
        N: 色图分辨率
    
    Returns:
        LinearSegmentedColormap: matplotlib色图对象
    
    Example:
        >>> colors = ['#E69F00', '#56B4E9', '#009E73']
        >>> cmap = create_colormap(colors, 'my_cmap')
    """
    return LinearSegmentedColormap.from_list(name, colors, N=N)


def get_sequential_colormap(name: str = 'iridescent') -> LinearSegmentedColormap:
    """
    获取连续型色图
    
    用于热图、等高线图等需要连续颜色变化的图表
    
    Args:
        name: 色图名称，支持 'iridescent', 'devon', 'lajolla'
    
    Returns:
        LinearSegmentedColormap: matplotlib色图对象
    
    Raises:
        ValueError: 当色图名称不支持时
    
    Example:
        >>> cmap = get_sequential_colormap('iridescent')
        >>> plt.imshow(data, cmap=cmap)
    """
    colors = TOL_SEQUENTIAL.get(name.lower())
    
    if colors is None:
        available_cmaps = ', '.join(TOL_SEQUENTIAL.keys())
        raise ValueError(
            f"不支持的色图: '{name}'。"
            f"可用色图: {available_cmaps}"
        )
    
    return create_colormap(colors, f'tol_{name}')


def get_diverging_colormap(name: str = 'sunset') -> LinearSegmentedColormap:
    """
    获取发散型色图
    
    用于显示正负值对比，中心点为中性色
    
    Args:
        name: 色图名称，支持 'sunset', 'buwr'
    
    Returns:
        LinearSegmentedColormap: matplotlib色图对象
    
    Raises:
        ValueError: 当色图名称不支持时
    
    Example:
        >>> cmap = get_diverging_colormap('sunset')
        >>> plt.imshow(correlation_matrix, cmap=cmap, center=0)
    """
    colors = TOL_DIVERGING.get(name.lower())
    
    if colors is None:
        available_cmaps = ', '.join(TOL_DIVERGING.keys())
        raise ValueError(
            f"不支持的色图: '{name}'。"
            f"可用色图: {available_cmaps}"
        )
    
    return create_colormap(colors, f'tol_{name}')


def demonstrate_palette(
    palette_name: str = 'okabe_ito',
    figsize: tuple = (8, 2)
) -> plt.Figure:
    """
    展示调色板效果
    
    创建一个图表展示调色板中的所有颜色
    
    Args:
        palette_name: 调色板名称
        figsize: 图表尺寸
    
    Returns:
        plt.Figure: 展示调色板的图表对象
    
    Example:
        >>> fig = demonstrate_palette('okabe_ito')
        >>> fig.savefig('palette_demo.png')
    """
    colors = get_colorblind_palette(palette_name)
    n_colors = len(colors)
    
    fig, ax = plt.subplots(figsize=figsize)
    
    # 绘制色块
    for i, color in enumerate(colors):
        ax.bar(i, 1, color=color, edgecolor='black', linewidth=0.5)
    
    # 设置标签
    ax.set_xlim(-0.5, n_colors - 0.5)
    ax.set_ylim(0, 1)
    ax.set_xticks(range(n_colors))
    ax.set_xticklabels([f'{i+1}' for i in range(n_colors)])
    ax.set_yticks([])
    ax.set_title(f'{palette_name} Palette ({n_colors} colors)', fontsize=10)
    ax.spines['top'].set_visible(False)
    ax.spines['right'].set_visible(False)
    ax.spines['left'].set_visible(False)
    
    plt.tight_layout()
    return fig


def get_color_by_index(
    palette_name: str = 'okabe_ito',
    index: int = 0
) -> str:
    """
    获取调色板中指定索引的颜色
    
    Args:
        palette_name: 调色板名称
        index: 颜色索引（从0开始）
    
    Returns:
        str: 十六进制颜色代码
    
    Raises:
        IndexError: 当索引超出范围时
    
    Example:
        >>> color = get_color_by_index('okabe_ito', 0)
        >>> print(color)
        '#E69F00'
    """
    colors = get_colorblind_palette(palette_name)
    
    if index < 0 or index >= len(colors):
        raise IndexError(
            f"索引 {index} 超出范围。"
            f"调色板 '{palette_name}' 有 {len(colors)} 种颜色。"
        )
    
    return colors[index]


def register_colormaps():
    """
    注册所有Paul Tol色图到matplotlib
    
    注册后可以直接通过名称使用，如 plt.imshow(data, cmap='tol_iridescent')
    
    Example:
        >>> register_colormaps()
        >>> plt.imshow(data, cmap='tol_iridescent')
    """
    # 注册连续型色图
    for name, colors in TOL_SEQUENTIAL.items():
        cmap = create_colormap(colors, f'tol_{name}')
        mpl.colormaps.register(cmap, name=f'tol_{name}')
    
    # 注册发散型色图
    for name, colors in TOL_DIVERGING.items():
        cmap = create_colormap(colors, f'tol_{name}')
        mpl.colormaps.register(cmap, name=f'tol_{name}')


if __name__ == '__main__':
    # 测试代码
    print("可用调色板:", get_available_palettes())
    
    # 测试Okabe-Ito调色板
    colors = get_colorblind_palette('okabe_ito')
    print(f"\nOkabe-Ito调色板（{len(colors)}色）:")
    for i, color in enumerate(colors):
        print(f"  {i+1}: {color}")
    
    # 展示调色板
    fig = demonstrate_palette('okabe_ito')
    fig.savefig('okabe_ito_demo.png', dpi=150, bbox_inches='tight')
    print("\n调色板展示已保存到 okabe_ito_demo.png")
    
    # 注册色图
    register_colormaps()
    print("\n所有色图已注册到matplotlib")
