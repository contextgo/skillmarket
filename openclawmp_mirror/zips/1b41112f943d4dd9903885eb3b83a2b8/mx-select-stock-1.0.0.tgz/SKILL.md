---
name: mx_select_stock
description: 妙想智能选股，支持按行情指标、财务指标等条件筛选股票，可查询指定行业/板块内的股票、上市公司及板块指数成分股，支持股票/上市公司/板块/指数推荐，实时数据避免大模型使用过时信息。
required_env_vars:
  - MX_APIKEY
credentials:
  - type: api_key
    name: MX_APIKEY
    description: 从东方财富技能市场 Skills 页面获取的 API Key
---

# mx_select_stock 妙想智能选股 Skill

基于东方财富妙想 API 的智能选股技能，支持自然语言查询 A 股/港股/美股/板块/ETF，实时筛选并输出结构化结果。

## 配置

| 配置项 | 说明 |
|--------|------|
| API Key | 通过环境变量 `MX_APIKEY` 设置 |
| 默认输出目录 | `~/.easyclaw/workspace/mx_data/output/`（自动创建，Windows/macOS/Linux 均适用） |
| 输出文件前缀 | `mx_select_stock_` |

**输出文件：**
- `mx_select_stock_{query}.csv` — 筛选结果（UTF-8 with BOM，Excel 可直接打开）
- `mx_select_stock_{query}_description.txt` — 结果说明
- `mx_select_stock_{query}_raw.json` — API 原始数据

## 使用方式

**第一步：获取 API Key**

前往东方财富妙想 Skills 页面获取 API Key。

**第二步：设置环境变量**

```bash
# Windows CMD
set MX_APIKEY=your_api_key_here

# PowerShell
$env:MX_APIKEY='your_api_key_here'

# Linux / macOS
export MX_APIKEY=your_api_key_here
```

**第三步：运行脚本**

```bash
python mx_select_stock.py "选股条件"
```

**示例：**

```bash
python mx_select_stock.py "今日涨幅超过2%的A股"
python mx_select_stock.py "股价大于50元的银行股"
python mx_select_stock.py "市盈率低于20倍的沪深300成分股"
```

> **安全注意事项**
> - 本 Skill 会将查询关键词发送至东方财富官方 API（`mkapi2.dfcfs.com`）进行解析检索
> - API Key 仅通过环境变量读取，不会硬编码在脚本中

## 数据结果为空

若无返回数据，请前往东方财富妙想 AI 手动进行选股操作。

## 接口字段说明

### 顶层状态字段

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `status` | 数字 | 接口状态，`0` = 成功 |
| `message` | 字符串 | 接口提示，`ok` = 成功 |
| `data.code` | 字符串 | 选股业务状态码，`100` = 解析成功 |
| `data.msg` | 字符串 | 选股业务提示信息 |
| `data.data.resultType` | 数字 | 结果类型，`2000` 为标准选股结果 |
| `data.data.result.total` | 数字 | 符合条件的股票总数量 |
| `data.data.result.totalRecordCount` | 数字 | 与 `total` 一致，用于校验 |

### 列定义：`data.data.result.columns`

每个对象对应表格一列，与 `dataList` 的行数据键一一映射：

| 子字段 | 类型 | 说明 |
|--------|------|------|
| `title` | 字符串 | 列标题，如 `最新价 (元)`、`涨跌幅 (%)` |
| `key` | 字符串 | 列唯一业务键，与 `dataList` 对象的键映射，如 `NEWEST_PRICE`、`CHG` |
| `dateMsg` | 字符串 | 列数据对应日期，如 `2026.03.12` |
| `sortable` | 布尔 | 是否支持排序 |
| `sortWay` | 字符串 | 默认排序方向，`desc` = 降序，`asc` = 升序 |
| `redGreenAble` | 布尔 | 是否支持涨跌红绿着色 |
| `unit` | 字符串 | 数值单位，如 `元`、`%`、`股`、`倍` |
| `dataType` | 字符串 | 数据类型，`String` / `Double` / `Long` |

### 行数据：`data.data.result.dataList`

每个对象对应一只符合条件的股票，核心字段如下：

| 键 | 类型 | 说明 |
|----|------|------|
| `SERIAL` | 字符串 | 行序号 |
| `SECURITY_CODE` | 字符串 | 股票代码，如 `603866`、`300991` |
| `SECURITY_SHORT_NAME` | 字符串 | 股票简称，如 `桃李面包`、`创益通` |
| `MARKET_SHORT_NAME` | 字符串 | 市场简称，`SH` = 上交所，`SZ` = 深交所 |
| `NEWEST_PRICE` | 数字/字符串 | 最新价（元） |
| `CHG` | 数字/字符串 | 涨跌幅（%） |
| `PCHG` | 数字/字符串 | 涨跌额（元） |

### 选股条件统计字段

| 字段路径 | 类型 | 说明 |
|----------|------|------|
| `responseConditionList` | 数组 | 各单条筛选条件统计 |
| `responseConditionList[].describe` | 字符串 | 条件描述，如 `今日涨跌幅在 [1.5%, 2.5%] 之间` |
| `responseConditionList[].stockCount` | 数字 | 该条件匹配的股票数量 |
| `totalCondition.describe` | 字符串 | 组合条件描述 |
| `totalCondition.stockCount` | 数字 | 组合条件最终匹配数量，与 `result.total` 一致 |
| `parserText` | 字符串 | 条件解析文本，多条件以 `;` 分隔 |
