# TEMU 卖家助手

> 自动化 TEMU 商品上传与管理，让电商运营更高效

## 功能概览

### ✅ 已支持功能

| 功能 | API | 说明 |
|------|-----|------|
| 商品上传 | `bg.glo.goods.add` | 完整商品信息上传，含SKU、属性、图片 |
| 商品列表 | `bg.glo.goods.list.get` | 查询店铺所有商品 |
| 商品详情 | `bg.glo.goods.detail.get` | 获取单个商品完整信息 |
| 商品更新 | `bg.glo.goods.update` | 更新商品信息 |
| 图片上传 | `bg.goods.image.upload.global` | 上传商品图片 |
| 库存管理 | `bg.btg.goods.stock.*` | 库存查询与更新 |

### 🔄 部分支持（需权限）

| 功能 | API | 说明 |
|------|-----|------|
| 核价查询 | `bg.price.review.*` | 需开通核价权限 |
| 调价申请 | `bg.semi.adjust.*` | 需开通调价权限 |

---

## 一、API 配置

### 1. 获取凭证

联系 TEMU Partner 获取以下凭证：
- `AppKey`
- `AppSecret`
- `AccessToken`

### 2. 签名算法

```python
import hashlib
import json

def sign(params, secret):
    """TEMU MD5签名"""
    processed = {}
    for k, v in params.items():
        if isinstance(v, (dict, list)):
            # 复杂对象序列化为紧凑JSON
            processed[k] = json.dumps(v, separators=(',', ':'), ensure_ascii=False)
        else:
            processed[k] = v
    
    # 按字母顺序排序
    sorted_params = sorted(processed.items())
    
    # 拼接: secret + key1value1 + key2value2 + ... + secret
    sign_str = ""
    for key, value in sorted_params:
        if value is not None:
            sign_str += f"{key}{value}"
    sign_str = secret + sign_str + secret
    
    # MD5加密并转大写
    return hashlib.md5(sign_str.encode()).hexdigest().upper()
```

### 3. 请求示例

```python
import requests
import time

GATEWAY = "https://openapi-b-partner.temu.com/openapi/router"

def call_api(api_type, biz_params, app_key, app_secret, access_token):
    params = {
        "type": api_type,
        "app_key": app_key,
        "access_token": access_token,
        "timestamp": str(int(time.time())),
        "data_type": "JSON",
        "sign_method": "md5"
    }
    params.update(biz_params)
    params["sign"] = sign(params, app_secret)
    
    response = requests.post(GATEWAY, json=params, 
                            headers={"Content-Type": "application/json"}, 
                            timeout=60)
    return response.json()
```

---

## 二、商品上传

### 完整请求结构

```json
{
  "cat1Id": 27011,
  "cat2Id": 28946,
  "cat3Id": 29166,
  "cat4Id": 29183,
  "cat5Id": 29193,
  "cat6Id": 0,
  "cat7Id": 0,
  "cat8Id": 0,
  "cat9Id": 0,
  "cat10Id": 0,
  
  "productName": "商品标题",
  "materialImgUrl": "主图URL",
  "carouselImageUrls": ["轮播图1", "轮播图2", "..."],
  
  "productWhExtAttrReq": {
    "outerGoodsUrl": "",
    "productOrigin": {
      "countryShortName": "CN",
      "region2Id": 43000000000006
    }
  },
  
  "productOuterPackageImageReqs": [{"imageUrl": "外包装图"}],
  "productOuterPackageReq": {"packageShape": 1, "packageType": 0},
  
  "sizeTemplateIds": [尺码表ID],
  "showSizeTemplateIds": [尺码表ID],
  
  "productPropertyReqs": [
    {"pid": 4, "vid": 166, "propName": "护理说明", "propValue": "不可洗", "refPid": 20, "templatePid": 1578361}
  ],
  
  "productSpecPropertyReqs": [
    {"parentSpecId": 1001, "specId": 2001, "specName": "白色", "vid": 376, "refPid": 63, "pid": 13}
  ],
  
  "productSkcReqs": [{
    "previewImgUrls": ["预览图"],
    "extCode": "商品编码",
    "productSkuReqs": [
      {
        "thumbUrl": "SKU图",
        "supplierPrice": 36800,
        "currencyType": "CNY",
        "productSkuSpecReqs": [
          {"parentSpecId": 1001, "specId": 2001, "specName": "白色", "vid": 376},
          {"parentSpecId": 3001, "specId": 15132, "specName": "35", "vid": 328}
        ],
        "productSkuSuggestedPriceReq": {"suggestedPrice": 168800, "suggestedPriceCurrencyType": "CNY"},
        "productSkuWhExtAttrReq": {
          "productSkuVolumeReq": {"len": 300, "width": 180, "height": 100},
          "productSkuWeightReq": {"value": 750000}
        }
      }
    ]
  }]
}
```

### ⚠️ 关键注意事项

1. **SKU完整性**: 必须包含所有颜色 × 所有尺码的组合
   - 例：3颜色 × 8尺码 = 24个SKU
   - 不完整会报错"尺码表包含不合法的尺码规格"

2. **图片尺寸**: 详情图文层的 width/height 必须与实际图片一致
   - 错误: `"width": 1200` 但图片实际 1024x1024
   - 解决: 使用实际尺寸或不传该字段

3. **产地信息**: 必须在 `productWhExtAttrReq.productOrigin` 中填写
   - `countryShortName`: "CN"
   - `region2Id`: 地区ID（如广州 43000000000006）

4. **尺码表ID**: 需要有效的 `sizeTemplateIds`
   - 可通过 TEMU 后台创建或查询现有商品获取

---

## 三、类目属性映射

### 女鞋类目 (29193) 示例

| 属性名 | pid | 示例值 |
|--------|-----|--------|
| 护理说明 | 4 | 不可洗(vid=166) |
| 图案 | 10 | 其他(vid=26499) |
| 鞋跟类型 | 709 | 细高跟(vid=19009) |
| 鞋面材料 | 1294 | 人造革(vid=76705) |

### 颜色规格 (parentSpecId=1001)

| 颜色 | specId | vid |
|------|--------|-----|
| 白色 | 2001 | 376 |
| 黑色 | 3002 | 378 |
| 杏色 | 16068 | 457 |

### 尺码规格 (parentSpecId=3001)

| 尺码 | specId | vid |
|------|--------|-----|
| 35 | 15132 | 328 |
| 36 | 16128 | 329 |
| 37 | 16129 | 330 |
| 38 | 15133 | 331 |
| 39 | 16130 | 332 |
| 40 | 16131 | 333 |
| 41 | 16132 | 334 |
| 42 | 15134 | 335 |

---

## 四、常见错误码

| 错误码 | 错误信息 | 解决方案 |
|--------|----------|----------|
| 7000015 | sign is invalid | 检查签名算法，JSON序列化用 compact 格式 |
| 3000000 | 字段不能为空 | 检查必填字段 |
| 2000306 | 详情图文图片宽度不正确 | width/height 必须与图片实际尺寸一致 |
| - | 尺码表包含不合法的尺码规格 | 确保SKU数量 = 颜色数 × 尺码数 |
| - | 请先添加尺码表再发布 | 必须传递 sizeTemplateIds |
| - | 非服饰类目spu轮播图最少为5张 | carouselImageUrls 至少5张 |

---

## 五、数据库集成

### 商品图片存储

```sql
-- 商品图片表
CREATE TABLE t_temu_goods_images (
    id INT PRIMARY KEY AUTO_INCREMENT,
    ext_code VARCHAR(50),           -- 商品编码
    color_vid INT,                  -- 颜色VID
    image_url VARCHAR(500),         -- 图片URL
    image_type VARCHAR(20)          -- 图片类型
);

-- 类目属性表
CREATE TABLE t_temu_meta_property (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cat_id INT,                     -- 类目ID
    pid INT,                        -- 属性ID
    name VARCHAR(100),              -- 属性名
    ref_pid INT,                    -- 引用属性ID
    is_sale TINYINT                 -- 是否销售属性
);

-- 属性值表
CREATE TABLE t_temu_meta_property_value (
    id INT PRIMARY KEY AUTO_INCREMENT,
    cat_id INT,
    pid INT,
    vid INT,                        -- 属性值ID
    value VARCHAR(100),             -- 属性值
    spec_id INT,                    -- 规格ID
    group_id INT                    -- 分组ID
);
```

---

## 六、批量上传流程

```python
async def batch_upload(excel_path, db_config):
    """批量上传商品"""
    # 1. 读取Excel商品信息
    products = parse_excel(excel_path)
    
    # 2. 从数据库获取图片
    images = query_images_from_db(db_config)
    
    # 3. 逐个上传
    for product in products:
        # 构建完整SKU
        skus = build_all_skus(product, images)
        
        # 调用API
        result = call_api("bg.glo.goods.add", build_request(product, skus))
        
        if result.get("success"):
            print(f"✅ {product['name']} 上传成功")
        else:
            print(f"❌ {product['name']} 失败: {result.get('errorMsg')}")
```

---

## 七、相关资源

- TEMU Partner 后台: https://agentpartner.temu.com
- API 文档: https://agentpartner.temu.com/document
- Gateway: `https://openapi-b-partner.temu.com/openapi/router`

---

*技能版本: 1.0.0 | 更新时间: 2026-03-16*