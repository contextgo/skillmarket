---
name: smart-email-classifier
description: 智能邮件分类和优先级排序系统
version: 1.0.0
---

# 智能邮件分类 Skill

自动分析收件箱，将邮件分类为工作、个人、 newsletters、垃圾邮件，并提取待办事项和会议邀请。

## 功能
- 📧 多标签分类（工作/个人/推广/垃圾）
- ⏰ 优先级评分（紧急度 x 重要性）
- 📋 自动提取行动项（截止日期、任务）
- 🤖 生成回复草稿（常用场景模板）
- 📊 邮件统计报告（每周/月）

## 安装
```bash
openclawmp install skill/@your-username/smart-email-classifier
```

## 配置
需提供邮箱 IMAP 凭据及 OpenAI API Key（用于内容理解）。
