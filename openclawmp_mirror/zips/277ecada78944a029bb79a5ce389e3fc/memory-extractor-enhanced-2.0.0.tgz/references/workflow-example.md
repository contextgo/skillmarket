# 完整工作流示例

本示例展示了记忆提取器增强版在实际对话结束后的完整提取过程。

---

## 场景

**对话内容摘要：**
- 用户要求扫描 `/Users/audrey/` 路径下的环境配置
- 发现了几个配置问题：PATH缺失、环境变量未设置、Git配置不完整
- 完成了配置优化，创建了干净的zshrc配置
- 用户问"这个过程中你学到了什么"，AI总结了学习收获
- 用户决定去水产市场发布增强版的记忆提取器赚积分
- 当前对话结束，需要提取记忆

---

## 提取结果示例

### 1. Candidate Memories

1. **环境配置系统性排查方法论**
   - Type: `insight`
   - Target file: `insights/environment-configuration.md`
   - Operation: `create`
   - Brief content: 建立了完整的环境配置排查流程：安装检查 → PATH检查 → 环境变量检查 → 配置文件检查 → 权限检查

2. **openclawmp PATH配置问题解决**
   - Type: `error`
   - Target file: `errors/openclawmp-command-not-found.md`
   - Operation: `create`
   - Brief content: 问题：npm全局安装后找不到命令；原因：npm-global/bin不在PATH中；解决：添加到zshrc；预防：新工具安装后立即验证

3. **OpenClaw环境变量标准配置**
   - Type: `reference`
   - Target file: `REFERENCES.md`
   - Operation: `update`
   - Brief content: OPENCLAW_HOME=/Users/audrey/.openclaw, OPENCLAW_CONFIG=/Users/audrey/.openclaw/config.json

4. **Git全局配置最佳实践**
   - Type: `insight`
   - Target file: `insights/git-configuration.md`
   - Operation: `create`
   - Brief content: 应该设置用户名、邮箱、默认分支，这些配置对于协作很重要

5. **用户当前目标：去水产市场赚积分获取经验**
   - Type: `project`
   - Target file: `projects/seafood-market-practice.md`
   - Operation: `create`
   - Brief content: 通过增强已有技能并发布回市场来练习完整工作流，获得积分和经验

6. **环境配置优化完成总结**
   - Type: `decision`
   - Target file: `DECISIONS.md`
   - Operation: `create`
   - Brief content: 决定采用干净的zshrc配置，包含所有必要路径，备份原有配置供回滚

### 2. Updates Made

- Created `insights/environment-configuration.md`: 系统性环境排查方法论
- Created `errors/openclawmp-command-not-found.md`: openclawmp找不到命令问题记录
- Updated `REFERENCES.md`: 添加OpenClaw标准环境变量配置
- Created `insights/git-configuration.md`: Git配置最佳实践
- Created `projects/seafood-market-practice.md`: 水产市场实践项目记录
- Created `DECISIONS.md`: 记录环境配置优化相关决策

### 3. Skipped Items & Why

- 临时文件路径：跳过，因为会变化，可以从文件系统读取
- 单步命令输出：跳过，因为不是持久信息，用户可以重新运行
- 用户已经知道的基础Git知识：跳过，不需要重复
- 会话中间的临时状态：跳过，属于SESSION-STATE.md，不是持久记忆

---

## 📊 分类检查

在这个例子中，我们正确使用了：

- ✅ `insight` - 学习心得和方法论
- ✅ `error` - 错误和修复记录
- ✅ `reference` - 参考信息和环境变量
- ✅ `project` - 项目和目标信息
- ✅ `decision` - 决策记录

---

## 🔄 后续流程

提取完成后：

1. **L1（会话）**：这个提取结果已经记录到 `memory/YYYY-MM-DD.md`
2. **L2（信号）**：重要信号会被提炼到 `signals.md`
3. **L3（知识）**：每周会将重要信号压缩到 `MEMORY.md`
4. **L4（语义）**：memsearch 会更新语义索引

---

这个示例展示了如何在实际对话结束后使用记忆提取器增强版。完整的工作流确保重要信息被正确分类和持久化，支持AI的持续成长和自我进化。 🚀✨