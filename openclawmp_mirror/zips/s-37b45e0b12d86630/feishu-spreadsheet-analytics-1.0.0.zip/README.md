# Feishu Spreadsheet Analytics

一个强大的飞书在线表格数据分析技能，提供智能识别、统计分析和报告生成功能。

## 核心功能

- 📊 智能读取：自动读取飞书 Spreadsheet 数据，支持多表格、多工作表
- 🔍 结构识别：自动识别字段类型（文本、数字、日期、布尔等）、数据质量
- 📈 统计分析：基础统计（计数、均值、最大/最小、标准差）、分布分析、异常检测
- 🧹 数据清洗：去重、空值处理、格式标准化、去空格
- 📑 报告生成：生成结构化报告（Markdown/HTML/JSON），支持自定义模板
- 🔄 批量处理：支持批量分析多个表格，结果汇总

## 使用场景

- 快速了解表格数据概况
- 自动生成数据质量报告
- 检测数据异常和 outliers
- 多表格对比分析
- 定期自动化数据统计

## 快速开始

```bash
# 安装技能
openclawmp install skill/@u-ad87dc7556674039b0d5/feishu-spreadsheet-analytics

# 基础使用
@GOGO 使用 feishu-spreadsheet-analytics 分析表格 https://example.com/spreadsheet/xxx
```

详细文档请参考 `docs/` 目录。

## 技术栈

- OpenClaw Skill SDK
- TypeScript
- 飞书 API (Spreadsheet)
- 统计计算库（内置）

## 版本

v1.0.0 - 初始版本，包含核心读写、基础统计、报告生成

## 作者

Created by GOGO & tob-openclaw