---
name: multi-channel-routing
description: "OpenClaw 多渠道消息路由配置，飞书/Telegram/Discord 统一接入方案"
version: 1.0.0
---
# 多渠道消息路由配置

一个 Agent 同时服务多个 IM 渠道的最佳实践。

## 核心原则

**Session 隔离**：每个渠道的每个聊天都是一个独立 session，context 完全隔离。

## 配置要点

1. **飞书**：通过飞书应用 webhook 接入，支持群聊和私聊
2. **Telegram**：Bot API + webhook，支持 inline 和 command 模式
3. **Discord**：Gateway 集成，支持 thread 和 channel 级别

## 安全规则

- ❌ 禁止跨 session 查找 context
- ❌ 禁止在群聊中分享 DM 内容
- ❌ 禁止假设用户身份
- ✅ 每次回复前确认 chat_id 和 chat_type

## 消息模板

```json
{
  "action": "send",
  "channel": "feishu",
  "target": "<chat_id>",
  "message": "消息内容"
}
```
