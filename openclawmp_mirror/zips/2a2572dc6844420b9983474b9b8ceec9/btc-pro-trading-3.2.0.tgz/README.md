# BTC Pro Trading Extension

BTC 多策略概率分析 + ICT/SMC结构识别 + 实时TradingView图表 + 虚拟盘跟踪

## 功能特性

### 📊 多策略分析引擎
- **趋势跟踪**: EMA均线排列 + 日线趋势共振
- **均值回归**: RSI超买超卖 + 布林带位置
- **突破交易**: 20周期高低点突破 + 成交量确认
- **MACD动量**: 柱状图趋势 + 金叉死叉
- **ICT/SMC结构**: HH/HL/LH/LL识别 + Order Block + FVG
- **成交量分析**: VWAP位置 + 放量缩量判断

### 🎯 信号系统
- 多空概率分布可视化
- 信号强度评分 (0-100%)
- 策略一致性检查
- 30分钟信号冷却期
- 桌面通知提醒

### 💰 交易计划
- 自动计算入场/止损/止盈
- 强趋势30%仓位 / 弱趋势15%仓位
- ATR-based 止损设置
- 一键开仓 (虚拟盘)

### 📈 实时图表
- TradingView Lightweight Charts
- 支持 15m/1H/4H/1D 周期
- 成交量柱状图
- 可拖拽悬浮窗口

### 💼 虚拟盘管理
- 持仓盈亏实时计算
- 止盈止损自动触发
- 胜率统计
- 历史交易记录

## 安装步骤

### 1. 安装依赖
```bash
cd btc-pro-trading
npm install
```

### 2. 开发模式
```bash
npm run dev
```

### 3. 生产构建
```bash
npm run build
```

### 4. 加载到 Chrome
1. 打开 Chrome 扩展管理页面: `chrome://extensions/`
2. 开启"开发者模式"
3. 点击"加载已解压的扩展程序"
4. 选择 `dist` 文件夹

## 项目结构

```
btc-pro-trading/
├── src/
│   ├── background/          # Service Worker
│   │   └── index.ts        # 策略引擎 + 数据获取
│   ├── popup/              # 弹出窗口
│   │   ├── components/     # React组件
│   │   ├── App.tsx         # 主应用
│   │   └── styles.css      # 样式
│   ├── chart/              # 图表页面
│   │   ├── ChartPage.tsx   # TradingView图表
│   │   └── chart.css
│   ├── content/            # 内容脚本
│   │   └── index.ts        # 页面注入
│   ├── utils/              # 工具函数
│   │   ├── api.ts          # Binance API
│   │   ├── indicators.ts   # 技术指标
│   │   ├── strategies.ts   # 策略分析
│   │   └── tradePlan.ts    # 交易计划生成
│   └── types/              # TypeScript类型
│       └── index.ts
├── public/                 # 静态资源
│   ├── popup.html
│   ├── chart.html
│   └── icons/
├── manifest.json           # 扩展配置
├── package.json
├── tsconfig.json
├── webpack.config.js
└── tailwind.config.js
```

## 技术栈

- **Manifest V3**: Chrome扩展最新标准
- **React 18**: UI框架
- **TypeScript**: 类型安全
- **Tailwind CSS**: 样式系统
- **Lightweight Charts**: TradingView图表库
- **Lucide React**: 图标库

## 策略权重

| 策略 | 权重 | 说明 |
|------|------|------|
| 趋势跟踪 | 1.2 | 最重要 |
| ICT/SMC结构 | 1.1 | 高权重 |
| 突破交易 | 1.1 | 高权重 |
| 均值回归 | 1.0 | 标准权重 |
| MACD动量 | 1.0 | 标准权重 |
| 成交量分析 | 0.9 | 辅助权重 |

## 信号判断逻辑

```
综合概率 = Σ(策略概率 × 权重) / Σ权重

LONG条件:
- 看多概率 > 看空概率
- 看多概率 > 45%
- 策略一致性 > 40%

SHORT条件:
- 看空概率 > 看多概率
- 看空概率 > 45%
- 策略一致性 > 40%
```

## 交易计划参数

### 强趋势模式 (信号强度 > 70% 且 一致性 > 60%)
- 仓位: 30%
- 止损: 1.5 × ATR
- 止盈1: 3 × ATR
- 止盈2: 5 × ATR

### 弱趋势模式
- 仓位: 15%
- 止损: 1.5 × ATR
- 止盈1: 2 × ATR
- 止盈2: 3 × ATR

## 更新日志

### v3.0.0 (2026-04-03)
- ✨ 全新 React + TypeScript 架构
- ✨ 6策略并行分析引擎
- ✨ ICT/SMC 结构识别 (HH/HL/OB/FVG)
- ✨ TradingView 实时图表
- ✨ 虚拟盘持仓管理
- ✨ 深色主题 + 玻璃态 UI
- ✨ 信号通知系统

## 免责声明

本扩展仅供学习和研究使用，不构成投资建议。加密货币交易风险极高，请谨慎决策。

## License

MIT