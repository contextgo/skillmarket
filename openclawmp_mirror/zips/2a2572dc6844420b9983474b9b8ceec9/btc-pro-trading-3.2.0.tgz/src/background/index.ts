// ==========================================
// Background Service Worker
// ==========================================

import type { CombinedAnalysis, StrategyResult, Position } from '../types';
import { fetchMultipleTimeframes } from '../utils/api';
import { 
  analyzeTrendFollowing, 
  analyzeMeanReversion, 
  analyzeBreakout, 
  analyzeMACD, 
  analyzeICTStructure, 
  analyzeVolume 
} from '../utils/strategies';
import { generateTradePlan } from '../utils/tradePlan';

const CHECK_INTERVAL = 1; // 每分钟检查
const SIGNAL_COOLDOWN_MS = 30 * 60 * 1000; // 30分钟冷却

let lastSignal: 'LONG' | 'SHORT' | 'WAIT' | null = null;
let lastNotifyTime = 0;

// 初始化
chrome.runtime.onStartup.addListener(() => {
  console.log('[BTC Pro] Extension started');
  chrome.alarms.create('btc-check', { periodInMinutes: CHECK_INTERVAL });
  checkSignal();
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('[BTC Pro] Extension installed');
  chrome.alarms.create('btc-check', { periodInMinutes: CHECK_INTERVAL });
  checkSignal();
  
  // 初始化存储
  chrome.storage.local.set({
    portfolio: {
      balance: 10000,
      positions: [],
      totalPnl: 0,
      totalPnlPercent: 0,
      winRate: 0,
      totalTrades: 0
    },
    settings: {
      enabled: true,
      minSignalStrength: 55,
      minConsensus: 40,
      cooldownMinutes: 30,
      priceAlerts: true
    }
  });
});

// 定时检查
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'btc-check') {
    checkSignal();
  }
});

async function checkSignal() {
  try {
    console.log('[BTC Pro] Checking signal...');
    
    const { klines4h, klines1d, ticker } = await fetchMultipleTimeframes();
    
    if (!klines4h || !klines1d || !ticker) {
      console.error('[BTC Pro] Failed to fetch data');
      return;
    }
    
    // 运行所有策略
    const strategies: StrategyResult[] = [
      analyzeTrendFollowing(klines4h, klines1d),
      analyzeMeanReversion(klines4h),
      analyzeBreakout(klines4h),
      analyzeMACD(klines4h),
      analyzeICTStructure(klines4h, klines1d),
      analyzeVolume(klines4h)
    ];
    
    // 综合分析
    const analysis = combineStrategies(strategies, ticker);
    
    // 生成交易计划
    const tradePlan = generateTradePlan(analysis, klines4h);
    
    // 保存到存储
    await chrome.storage.local.set({
      lastUpdate: Date.now(),
      analysis,
      tradePlan
    });
    
    // 检查是否需要通知
    await maybeNotify(analysis);
    
    // 更新持仓状态
    await updatePositions(ticker.price);
    
    console.log('[BTC Pro] Analysis complete:', analysis.signal);
    
  } catch (error) {
    console.error('[BTC Pro] Check failed:', error);
  }
}

function combineStrategies(strategies: StrategyResult[], ticker: { price: number; changePercent: number }): CombinedAnalysis {
  const weights: Record<string, number> = {
    '趋势跟踪': 1.2,
    '均值回归': 1.0,
    '突破交易': 1.1,
    'MACD动量': 1.0,
    'ICT/SMC结构': 1.1,
    '成交量分析': 0.9
  };
  
  let totalLongProb = 0;
  let totalShortProb = 0;
  let activeStrategies = 0;
  
  for (const s of strategies) {
    const weight = weights[s.name] || 1.0;
    totalLongProb += s.longProb * weight;
    totalShortProb += s.shortProb * weight;
    activeStrategies += weight;
  }
  
  const avgLongProb = activeStrategies > 0 ? totalLongProb / activeStrategies : 0;
  const avgShortProb = activeStrategies > 0 ? totalShortProb / activeStrategies : 0;
  
  let finalSignal: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  let signalStrength = 0;
  
  if (avgLongProb > avgShortProb && avgLongProb > 45) {
    finalSignal = 'LONG';
    signalStrength = avgLongProb;
  } else if (avgShortProb > avgLongProb && avgShortProb > 45) {
    finalSignal = 'SHORT';
    signalStrength = avgShortProb;
  }
  
  const longCount = strategies.filter(s => s.signal === 'LONG').length;
  const shortCount = strategies.filter(s => s.signal === 'SHORT').length;
  const consensus = Math.max(longCount, shortCount) / strategies.length;
  
  return {
    price: ticker.price,
    change: ticker.changePercent,
    longProb: Math.round(avgLongProb),
    shortProb: Math.round(avgShortProb),
    signal: finalSignal,
    signalStrength: Math.round(signalStrength),
    consensus: Math.round(consensus * 100),
    strategies,
    timestamp: Date.now()
  };
}

async function maybeNotify(analysis: CombinedAnalysis) {
  const { settings } = await chrome.storage.local.get('settings');
  if (!settings?.enabled) return;
  
  const now = Date.now();
  const cooledDown = (now - lastNotifyTime) > SIGNAL_COOLDOWN_MS;
  
  const shouldNotify = 
    analysis.signal !== 'WAIT' &&
    analysis.signal !== lastSignal &&
    analysis.signalStrength >= settings.minSignalStrength &&
    analysis.consensus >= settings.minConsensus &&
    cooledDown;
  
  if (shouldNotify) {
    const direction = analysis.signal === 'LONG' ? '看多' : '看空';
    const prob = analysis.signal === 'LONG' ? analysis.longProb : analysis.shortProb;
    
    chrome.notifications.create(`btc-signal-${now}`, {
      type: 'basic',
      iconUrl: 'icons/icon128.png',
      title: `BTC ${direction}信号`,
      message: `综合概率: ${prob}% | 策略一致性: ${analysis.consensus}%\n价格: $${analysis.price.toFixed(2)}`,
      priority: 2
    });
    
    lastNotifyTime = now;
  }
  
  lastSignal = analysis.signal;
}

async function updatePositions(currentPrice: number) {
  const { portfolio } = await chrome.storage.local.get('portfolio');
  if (!portfolio) return;
  
  let updated = false;
  
  for (const position of portfolio.positions) {
    if (position.status !== 'OPEN') continue;
    
    // 检查止盈止损
    if (position.side === 'LONG') {
      if (currentPrice <= position.stopLoss) {
        position.status = 'CLOSED';
        position.closedAt = Date.now();
        position.closedPrice = currentPrice;
        position.pnl = (currentPrice - position.entryPrice) * position.quantity;
        position.pnlPercent = ((currentPrice - position.entryPrice) / position.entryPrice) * 100;
        updated = true;
      } else if (currentPrice >= position.takeProfit1 && position.status === 'OPEN') {
        // 部分止盈
        position.status = 'PARTIAL';
        updated = true;
      }
    } else {
      if (currentPrice >= position.stopLoss) {
        position.status = 'CLOSED';
        position.closedAt = Date.now();
        position.closedPrice = currentPrice;
        position.pnl = (position.entryPrice - currentPrice) * position.quantity;
        position.pnlPercent = ((position.entryPrice - currentPrice) / position.entryPrice) * 100;
        updated = true;
      }
    }
  }
  
  if (updated) {
    // 重新计算组合统计
    const closedPositions = portfolio.positions.filter((p: Position) => p.status === 'CLOSED');
    const winningTrades = closedPositions.filter((p: Position) => (p.pnl || 0) > 0).length;
    
    portfolio.totalPnl = closedPositions.reduce((sum: number, p: Position) => sum + (p.pnl || 0), 0);
    portfolio.totalPnlPercent = (portfolio.totalPnl / portfolio.balance) * 100;
    portfolio.winRate = closedPositions.length > 0 ? (winningTrades / closedPositions.length) * 100 : 0;
    portfolio.totalTrades = closedPositions.length;
    
    await chrome.storage.local.set({ portfolio });
  }
}

// 消息处理
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === 'refresh') {
    checkSignal().then(() => sendResponse({ success: true }));
    return true;
  }
  
  if (message.action === 'openPosition') {
    openPosition(message.position).then(() => sendResponse({ success: true }));
    return true;
  }
  
  if (message.action === 'closePosition') {
    closePosition(message.positionId, message.price).then(() => sendResponse({ success: true }));
    return true;
  }
  
  return false;
});

async function openPosition(position: Position) {
  const { portfolio } = await chrome.storage.local.get('portfolio');
  if (!portfolio) return;
  
  portfolio.positions.push(position);
  portfolio.balance -= position.entryPrice * position.quantity;
  
  await chrome.storage.local.set({ portfolio });
}

async function closePosition(positionId: string, closePrice: number) {
  const { portfolio } = await chrome.storage.local.get('portfolio');
  if (!portfolio) return;
  
  const position = portfolio.positions.find((p: Position) => p.id === positionId);
  if (!position || position.status === 'CLOSED') return;
  
  position.status = 'CLOSED';
  position.closedAt = Date.now();
  position.closedPrice = closePrice;
  
  if (position.side === 'LONG') {
    position.pnl = (closePrice - position.entryPrice) * position.quantity;
    position.pnlPercent = ((closePrice - position.entryPrice) / position.entryPrice) * 100;
  } else {
    position.pnl = (position.entryPrice - closePrice) * position.quantity;
    position.pnlPercent = ((position.entryPrice - closePrice) / position.entryPrice) * 100;
  }
  
  portfolio.balance += closePrice * position.quantity;
  
  await chrome.storage.local.set({ portfolio });
}

// 调试函数
(self as any).testCheck = async () => {
  console.log('[BTC Pro] Manual test check...');
  await checkSignal();
  const data = await chrome.storage.local.get(['analysis', 'tradePlan']);
  console.log('[BTC Pro] Current data:', data);
  return data;
};