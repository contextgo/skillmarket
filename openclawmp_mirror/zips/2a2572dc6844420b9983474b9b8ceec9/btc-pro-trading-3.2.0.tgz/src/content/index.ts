// ==========================================
// Content Script - Injected into Binance pages
// ==========================================

// Content script for Binance pages
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.action === 'getPageData') {
    // Extract data from Binance page if available
    const data = extractBinanceData();
    sendResponse(data);
  }
  return true;
});

function extractBinanceData() {
  // Try to extract price data from Binance page
  const priceElement = document.querySelector('[data-testid="asset-price"]');
  const changeElement = document.querySelector('[data-testid="price-change-percent"]');
  
  return {
    price: priceElement ? parseFloat(priceElement.textContent?.replace(/[^0-9.]/g, '') || '0') : 0,
    change: changeElement ? parseFloat(changeElement.textContent?.replace(/[^0-9.-]/g, '') || '0') : 0,
    url: window.location.href,
    timestamp: Date.now()
  };
}

// Inject a small indicator showing the extension is active
function injectIndicator() {
  const indicator = document.createElement('div');
  indicator.id = 'btc-pro-indicator';
  indicator.innerHTML = `
    <div style="
      position: fixed;
      top: 10px;
      right: 10px;
      z-index: 9999;
      background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
      border: 1px solid #e94560;
      border-radius: 8px;
      padding: 8px 12px;
      color: white;
      font-size: 12px;
      font-family: -apple-system, BlinkMacSystemFont, sans-serif;
      box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
    ">
      <span style="color: #e94560;">●</span>
      BTC Pro Active
    </div>
  `;
  
  indicator.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'openPopup' });
  });
  
  document.body.appendChild(indicator);
}

// Run when DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', injectIndicator);
} else {
  injectIndicator();
}

console.log('[BTC Pro] Content script loaded');