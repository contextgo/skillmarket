import { useState, useEffect, useCallback } from 'react';
import { 
  Activity, 
  RefreshCw, 
  Settings,
  PieChart,
  BarChart3
} from 'lucide-react';
import type { CombinedAnalysis, TradePlan, Position } from '../types';
import { PriceHeader } from './components/PriceHeader';
import { SignalCard } from './components/SignalCard';
import { ProbabilityBars } from './components/ProbabilityBars';
import { StrategyList } from './components/StrategyList';
import { TradePlanCard } from './components/TradePlanCard';
import { PositionList } from './components/PositionList';
import { TabButton } from './components/TabButton';

type Tab = 'signal' | 'positions';

export default function App() {
  const [analysis, setAnalysis] = useState<CombinedAnalysis | null>(null);
  const [tradePlan, setTradePlan] = useState<TradePlan | null>(null);
  const [positions, setPositions] = useState<Position[]>([]);
  const [lastUpdate, setLastUpdate] = useState<number>(0);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('signal');
  const [isRefreshing, setIsRefreshing] = useState(false);

  const loadData = useCallback(async () => {
    try {
      const data = await chrome.storage.local.get([
        'analysis', 
        'tradePlan', 
        'portfolio', 
        'lastUpdate'
      ]);
      
      if (data.analysis) {
        setAnalysis(data.analysis);
        setTradePlan(data.tradePlan || null);
        setLastUpdate(data.lastUpdate || 0);
      }
      
      if (data.portfolio) {
        setPositions(data.portfolio.positions || []);
      }
      
      setError(null);
    } catch (err) {
      setError('加载数据失败');
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData();
    
    const handleStorageChange = (changes: { [key: string]: chrome.storage.StorageChange }) => {
      if (changes.analysis) {
        setAnalysis(changes.analysis.newValue);
      }
      if (changes.tradePlan) {
        setTradePlan(changes.tradePlan.newValue);
      }
      if (changes.portfolio) {
        setPositions(changes.portfolio.newValue.positions || []);
      }
      if (changes.lastUpdate) {
        setLastUpdate(changes.lastUpdate.newValue);
      }
    };
    
    chrome.storage.onChanged.addListener(handleStorageChange);
    return () => chrome.storage.onChanged.removeListener(handleStorageChange);
  }, [loadData]);

  const handleRefresh = async () => {
    setIsRefreshing(true);
    try {
      await chrome.runtime.sendMessage({ action: 'refresh' });
      await loadData();
    } catch (err) {
      console.error('Refresh failed:', err);
    } finally {
      setTimeout(() => setIsRefreshing(false), 500);
    }
  };

  const handleOpenPosition = async (side: 'LONG' | 'SHORT') => {
    if (!tradePlan || !analysis) return;
    
    const position: Position = {
      id: `pos-${Date.now()}`,
      symbol: 'BTCUSDT',
      side,
      entryPrice: tradePlan.entry,
      quantity: tradePlan.positionSize / tradePlan.entry,
      stopLoss: tradePlan.stopLoss,
      takeProfit1: tradePlan.takeProfit1,
      takeProfit2: tradePlan.takeProfit2,
      status: 'OPEN',
      openedAt: Date.now()
    };
    
    await chrome.runtime.sendMessage({ action: 'openPosition', position });
    await loadData();
  };

  const handleClosePosition = async (positionId: string) => {
    if (!analysis) return;
    
    await chrome.runtime.sendMessage({ 
      action: 'closePosition', 
      positionId, 
      price: analysis.price 
    });
    await loadData();
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-screen bg-dark-900">
        <div className="text-center">
          <div className="w-10 h-10 border-3 border-accent-blue border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-400 text-sm">加载中...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center h-screen bg-dark-900 p-4">
        <div className="text-center">
          <p className="text-red-400 mb-4">{error}</p>
          <button 
            onClick={handleRefresh}
            className="px-4 py-2 bg-accent-blue rounded-lg text-sm font-medium"
          >
            重试
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-900 text-white">
      {/* Header */}
      <header className="glass sticky top-0 z-10 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Activity className="w-5 h-5 text-accent-blue" />
            <h1 className="font-bold text-lg">BTC Pro</h1>
          </div>
          <div className="flex items-center gap-2">
            <button 
              onClick={handleRefresh}
              className={`p-2 rounded-lg hover:bg-dark-600 transition-colors ${isRefreshing ? 'animate-spin' : ''}`}
            >
              <RefreshCw className="w-4 h-4 text-gray-400" />
            </button>
            <button className="p-2 rounded-lg hover:bg-dark-600 transition-colors">
              <Settings className="w-4 h-4 text-gray-400" />
            </button>
          </div>
        </div>
      </header>

      {/* Price Header */}
      {analysis && (
        <PriceHeader 
          price={analysis.price} 
          change={analysis.change}
          lastUpdate={lastUpdate}
        />
      )}

      {/* Tabs - 只保留信号和持仓 */}
      <div className="flex px-4 py-2 gap-1 border-b border-dark-600">
        <TabButton 
          active={activeTab === 'signal'} 
          onClick={() => setActiveTab('signal')}
          icon={<BarChart3 className="w-4 h-4" />}
          label="信号"
        />
        <TabButton 
          active={activeTab === 'positions'} 
          onClick={() => setActiveTab('positions')}
          icon={<PieChart className="w-4 h-4" />}
          label="持仓"
          badge={positions.filter(p => p.status === 'OPEN').length}
        />
      </div>

      {/* Content */}
      <main className="p-4 space-y-4">
        {activeTab === 'signal' && analysis && (
          <div className="space-y-4 animate-fade-in">
            {/* Signal Card */}
            <SignalCard 
              signal={analysis.signal}
              signalStrength={analysis.signalStrength}
              consensus={analysis.consensus}
            />

            {/* Probability Bars */}
            <ProbabilityBars 
              longProb={analysis.longProb}
              shortProb={analysis.shortProb}
            />

            {/* Trade Plan */}
            {tradePlan && (
              <TradePlanCard 
                plan={tradePlan}
                onOpenPosition={handleOpenPosition}
              />
            )}

            {/* Strategy List */}
            <StrategyList strategies={analysis.strategies} />
          </div>
        )}

        {activeTab === 'positions' && (
          <PositionList 
            positions={positions}
            currentPrice={analysis?.price || 0}
            onClosePosition={handleClosePosition}
          />
        )}
      </main>

      {/* Footer */}
      <footer className="px-4 py-3 border-t border-dark-600 text-center">
        <p className="text-xs text-gray-500">
          数据来自 Binance • 仅供参考，不构成投资建议
        </p>
      </footer>
    </div>
  );
}
