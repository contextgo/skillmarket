import React from 'react';
import { ArrowUp, ArrowDown, Minus, Zap } from 'lucide-react';

interface SignalCardProps {
  signal: 'LONG' | 'SHORT' | 'WAIT';
  signalStrength: number;
  consensus: number;
}

export const SignalCard: React.FC<SignalCardProps> = ({ signal, signalStrength, consensus }) => {
  const config = {
    LONG: {
      bg: 'bg-long/10 border-long/30',
      text: 'text-long',
      icon: ArrowUp,
      label: '看多信号',
      glow: 'glow-long'
    },
    SHORT: {
      bg: 'bg-short/10 border-short/30',
      text: 'text-short',
      icon: ArrowDown,
      label: '看空信号',
      glow: 'glow-short'
    },
    WAIT: {
      bg: 'bg-gray-500/10 border-gray-500/30',
      text: 'text-gray-400',
      icon: Minus,
      label: '观望',
      glow: ''
    }
  };

  const { bg, text, icon: Icon, label, glow } = config[signal];

  return (
    <div className={`rounded-xl p-4 border ${bg} ${glow}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <Icon className={`w-6 h-6 ${text}`} />
          <span className={`text-xl font-bold ${text}`}>{label}</span>
        </div>
        {signal !== 'WAIT' && (
          <div className="flex items-center gap-1 px-2 py-1 rounded-full bg-dark-600/50">
            <Zap className="w-3 h-3 text-accent-amber" />
            <span className="text-xs font-medium">{signalStrength}%</span>
          </div>
        )}
      </div>
      
      <div className="space-y-2">
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-400">信号强度</span>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-dark-600 rounded-full overflow-hidden">
              <div 
                className={`h-full rounded-full transition-all duration-500 ${
                  signal === 'LONG' ? 'bg-long' : signal === 'SHORT' ? 'bg-short' : 'bg-gray-500'
                }`}
                style={{ width: `${signalStrength}%` }}
              />
            </div>
            <span className="font-mono w-10 text-right">{signalStrength}%</span>
          </div>
        </div>
        
        <div className="flex items-center justify-between text-sm">
          <span className="text-gray-400">策略一致性</span>
          <div className="flex items-center gap-2">
            <div className="w-24 h-2 bg-dark-600 rounded-full overflow-hidden">
              <div 
                className="h-full bg-accent-blue rounded-full transition-all duration-500"
                style={{ width: `${consensus}%` }}
              />
            </div>
            <span className="font-mono w-10 text-right">{consensus}%</span>
          </div>
        </div>
      </div>
    </div>
  );
};