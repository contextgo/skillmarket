import React from 'react';
import { Wallet, TrendingUp, TrendingDown, Target, BarChart3 } from 'lucide-react';
import type { Portfolio } from '../../types/index.js';

interface PortfolioSummaryProps {
  portfolio: Portfolio;
}

export const PortfolioSummary: React.FC<PortfolioSummaryProps> = ({ portfolio }) => {
  const isProfit = portfolio.totalPnl >= 0;
  
  return (
    <div className="space-y-4 animate-fade-in">
      {/* Total Balance */}
      <div className="glass rounded-xl p-4">
        <div className="flex items-center gap-2 text-gray-400 text-sm mb-2">
          <Wallet className="w-4 h-4" />
          总资产
        </div>
        <div className="text-3xl font-bold font-mono">
          ${portfolio.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
      </div>

      {/* PnL Summary */}
      <div className="glass rounded-xl p-4">
        <h3 className="text-sm font-medium text-gray-400 mb-4 flex items-center gap-2">
          <BarChart3 className="w-4 h-4" />
          盈亏统计
        </h3>
        
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-dark-600/30 rounded-lg p-3">
            <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
              {isProfit ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
              总盈亏
            </div>
            <div className={`font-mono font-medium ${isProfit ? 'text-long' : 'text-short'}`}>
              {isProfit ? '+' : ''}${portfolio.totalPnl.toFixed(2)}
            </div>
            <div className={`text-xs ${isProfit ? 'text-long' : 'text-short'}`}>
              {isProfit ? '+' : ''}{portfolio.totalPnlPercent.toFixed(2)}%
            </div>
          </div>
          
          <div className="bg-dark-600/30 rounded-lg p-3">
            <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
              <Target className="w-3 h-3" />
              胜率
            </div>
            <div className="font-mono font-medium">
              {portfolio.winRate.toFixed(1)}%
            </div>
            <div className="text-xs text-gray-500">
              {portfolio.totalTrades} 笔交易
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="glass rounded-xl p-4">
        <h3 className="text-sm font-medium text-gray-400 mb-4">详细数据</h3>
        
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-gray-500 text-sm">总交易次数</span>
            <span className="font-mono">{portfolio.totalTrades}</span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-500 text-sm">盈利次数</span>
            <span className="font-mono text-long">
              {Math.round(portfolio.totalTrades * portfolio.winRate / 100)}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-500 text-sm">亏损次数</span>
            <span className="font-mono text-short">
              {portfolio.totalTrades - Math.round(portfolio.totalTrades * portfolio.winRate / 100)}
            </span>
          </div>
          
          <div className="flex items-center justify-between">
            <span className="text-gray-500 text-sm">当前持仓</span>
            <span className="font-mono">
              {portfolio.positions.filter(p => p.status === 'OPEN').length} 笔
            </span>
          </div>
        </div>
      </div>
    </div>
  );
};