import React, { useState } from 'react';
import { ChevronDown, ChevronUp, TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { StrategyResult } from '../../types/index.js';

interface StrategyListProps {
  strategies: StrategyResult[];
}

export const StrategyList: React.FC<StrategyListProps> = ({ strategies }) => {
  const [expanded, setExpanded] = useState<Set<string>>(new Set());

  const toggleExpand = (name: string) => {
    const newExpanded = new Set(expanded);
    if (newExpanded.has(name)) {
      newExpanded.delete(name);
    } else {
      newExpanded.add(name);
    }
    setExpanded(newExpanded);
  };

  const getSignalIcon = (signal: string) => {
    switch (signal) {
      case 'LONG':
        return <TrendingUp className="w-4 h-4 text-long" />;
      case 'SHORT':
        return <TrendingDown className="w-4 h-4 text-short" />;
      default:
        return <Minus className="w-4 h-4 text-gray-500" />;
    }
  };

  const getSignalClass = (signal: string) => {
    switch (signal) {
      case 'LONG':
        return 'bg-long/20 text-long border-long/30';
      case 'SHORT':
        return 'bg-short/20 text-short border-short/30';
      default:
        return 'bg-gray-500/10 text-gray-400 border-gray-500/20';
    }
  };

  return (
    <div className="glass rounded-xl p-4">
      <h3 className="text-sm font-medium text-gray-400 mb-3">策略分析 ({strategies.length}个策略)</h3>
      
      <div className="space-y-2">
        {strategies.map((strategy) => (
          <div 
            key={strategy.name}
            className="bg-dark-600/30 rounded-lg overflow-hidden"
          >
            <button
              onClick={() => toggleExpand(strategy.name)}
              className="w-full px-3 py-3 flex items-center justify-between hover:bg-dark-600/50 transition-colors"
            >
              <div className="flex items-center gap-3">
                {getSignalIcon(strategy.signal)}
                <span className="font-medium text-sm">{strategy.name}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-1 rounded text-xs font-medium border ${getSignalClass(strategy.signal)}`}>
                  {strategy.signal === 'LONG' ? '看多' : strategy.signal === 'SHORT' ? '看空' : '观望'}
                </span>
                {expanded.has(strategy.name) ? (
                  <ChevronUp className="w-4 h-4 text-gray-500" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-gray-500" />
                )}
              </div>
            </button>
            
            {expanded.has(strategy.name) && (
              <div className="px-3 pb-3 animate-slide-up">
                <div className="space-y-2 text-xs">
                  <div className="flex items-center gap-4">
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-gray-500">看多</span>
                        <span className="font-mono text-long">{strategy.longProb}%</span>
                      </div>
                      <div className="h-1.5 bg-dark-600 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-long rounded-full"
                          style={{ width: `${strategy.longProb}%` }}
                        />
                      </div>
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-gray-500">看空</span>
                        <span className="font-mono text-short">{strategy.shortProb}%</span>
                      </div>
                      <div className="h-1.5 bg-dark-600 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-short rounded-full"
                          style={{ width: `${strategy.shortProb}%` }}
                        />
                      </div>
                    </div>
                  </div>
                  
                  <div className="pt-2 border-t border-dark-600/50">
                    <p className="text-gray-400 mb-1">分析依据:</p>
                    <ul className="space-y-1">
                      {strategy.reasons.slice(0, 3).map((reason, idx) => (
                        <li key={idx} className="text-gray-500 flex items-start gap-2">
                          <span className="text-accent-blue">•</span>
                          {reason}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};