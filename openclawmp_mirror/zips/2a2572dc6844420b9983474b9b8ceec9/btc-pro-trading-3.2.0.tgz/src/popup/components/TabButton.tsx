import React from 'react';

interface TabButtonProps {
  active: boolean;
  onClick: () => void;
  icon: React.ReactNode;
  label: string;
  badge?: number;
}

export const TabButton: React.FC<TabButtonProps> = ({ 
  active, 
  onClick, 
  icon, 
  label,
  badge 
}) => {
  return (
    <button
      onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg text-sm font-medium transition-colors ${
        active 
          ? 'bg-accent-blue/20 text-accent-blue border border-accent-blue/30' 
          : 'text-gray-400 hover:bg-dark-600/50 hover:text-gray-300'
      }`}
    >
      {icon}
      <span>{label}</span>
      {badge !== undefined && badge > 0 && (
        <span className="px-1.5 py-0.5 bg-accent-blue text-white text-xs rounded-full min-w-[18px] text-center">
          {badge}
        </span>
      )}
    </button>
  );
};