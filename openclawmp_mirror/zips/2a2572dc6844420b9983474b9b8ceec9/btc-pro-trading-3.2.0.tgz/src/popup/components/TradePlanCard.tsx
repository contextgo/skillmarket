import React from 'react';
import { Target, Shield, TrendingUp, Flame, Zap } from 'lucide-react';
import type { TradePlan } from '../../types/index.js';

interface TradePlanCardProps {
  plan: TradePlan;
  onOpenPosition: (side: 'LONG' | 'SHORT') => void;
}

export const TradePlanCard: React.FC<TradePlanCardProps> = ({ plan, onOpenPosition }) => {
  const isAggressive = plan.mode === 'aggressive';
  
  return (
    <div className="glass rounded-xl p-4">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-sm font-medium text-gray-400 flex items-center gap-2">
          <Target className="w-4 h-4" />
          交易计划
        </h3>
        <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-xs ${
          isAggressive ? 'bg-long/20 text-long' : 'bg-accent-amber/20 text-accent-amber'
        }`}>
          {isAggressive ? <Flame className="w-3 h-3" /> : <Zap className="w-3 h-3" />}
          {isAggressive ? '强趋势 30%' : '弱趋势 15%'}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-3 mb-4">
        <div className="bg-dark-600/50 rounded-lg p-3">
          <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
            <Target className="w-3 h-3" />
            入场
          </div>
          <div className="font-mono font-medium">${plan.entry.toFixed(2)}</div>
        </div>
        
        <div className="bg-dark-600/50 rounded-lg p-3">
          <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
            <Shield className="w-3 h-3" />
            止损
          </div>
          <div className="font-mono font-medium text-short">${plan.stopLoss.toFixed(2)}</div>
        </div>
        
        <div className="bg-dark-600/50 rounded-lg p-3">
          <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
            <TrendingUp className="w-3 h-3" />
            止盈1
          </div>
          <div className="font-mono font-medium text-long">${plan.takeProfit1.toFixed(2)}</div>
        </div>
        
        <div className="bg-dark-600/50 rounded-lg p-3">
          <div className="flex items-center gap-2 text-gray-400 text-xs mb-1">
            <TrendingUp className="w-3 h-3" />
            止盈2
          </div>
          <div className="font-mono font-medium text-long">${plan.takeProfit2.toFixed(2)}</div>
        </div>
      </div>
      
      <div className="flex items-center justify-between text-xs text-gray-400 mb-4">
        <span>风险: {plan.riskPercent.toFixed(2)}%</span>
        <span>仓位: ${plan.positionSize.toFixed(0)}</span>
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        <button
          onClick={() => onOpenPosition('LONG')}
          className="flex items-center justify-center gap-2 py-3 bg-long/20 hover:bg-long/30 border border-long/30 rounded-lg text-long font-medium transition-colors"
        >
          <TrendingUp className="w-4 h-4" />
          开多
        </button>
        <button
          onClick={() => onOpenPosition('SHORT')}
          className="flex items-center justify-center gap-2 py-3 bg-short/20 hover:bg-short/30 border border-short/30 rounded-lg text-short font-medium transition-colors"
        >
          <TrendingUp className="w-4 h-4 rotate-180" />
          开空
        </button>
      </div>
    </div>
  );
};