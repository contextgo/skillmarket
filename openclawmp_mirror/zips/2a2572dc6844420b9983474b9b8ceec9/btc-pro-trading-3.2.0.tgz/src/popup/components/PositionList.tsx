import React from 'react';
import { X, TrendingUp, Clock } from 'lucide-react';
import type { Position } from '../../types/index.js';

interface PositionListProps {
  positions: Position[];
  currentPrice: number;
  onClosePosition: (id: string) => void;
}

export const PositionList: React.FC<PositionListProps> = ({ 
  positions, 
  currentPrice, 
  onClosePosition 
}) => {
  const openPositions = positions.filter(p => p.status === 'OPEN' || p.status === 'PARTIAL');
  const closedPositions = positions.filter(p => p.status === 'CLOSED').slice(0, 5);

  const calculatePnl = (position: Position) => {
    if (position.side === 'LONG') {
      return (currentPrice - position.entryPrice) * position.quantity;
    } else {
      return (position.entryPrice - currentPrice) * position.quantity;
    }
  };

  const calculatePnlPercent = (position: Position) => {
    const pnl = calculatePnl(position);
    return (pnl / (position.entryPrice * position.quantity)) * 100;
  };

  const formatTime = (timestamp: number) => {
    return new Date(timestamp).toLocaleDateString() + ' ' + new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <div className="space-y-4 animate-fade-in">
      {/* Open Positions */}
      {openPositions.length > 0 && (
        <div className="glass rounded-xl p-4">
          <h3 className="text-sm font-medium text-gray-400 mb-3 flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            当前持仓 ({openPositions.length})
          </h3>
          
          <div className="space-y-3">
            {openPositions.map((position) => {
              const pnl = calculatePnl(position);
              const pnlPercent = calculatePnlPercent(position);
              const isProfit = pnl >= 0;
              
              return (
                <div 
                  key={position.id}
                  className="bg-dark-600/30 rounded-lg p-3"
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-1 rounded text-xs font-medium ${
                        position.side === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                      }`}>
                        {position.side === 'LONG' ? '多' : '空'}
                      </span>
                      <span className="font-mono text-sm">{position.symbol}</span>
                    </div>
                    <button
                      onClick={() => onClosePosition(position.id)}
                      className="p-1 hover:bg-dark-600 rounded transition-colors"
                    >
                      <X className="w-4 h-4 text-gray-400" />
                    </button>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-2 text-xs mb-2">
                    <div>
                      <span className="text-gray-500">入场: </span>
                      <span className="font-mono">${position.entryPrice.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">当前: </span>
                      <span className="font-mono">${currentPrice.toFixed(2)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">数量: </span>
                      <span className="font-mono">{position.quantity.toFixed(4)}</span>
                    </div>
                    <div>
                      <span className="text-gray-500">止损: </span>
                      <span className="font-mono text-short">${position.stopLoss.toFixed(2)}</span>
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between pt-2 border-t border-dark-600/50">
                    <div className={`flex items-center gap-1 ${isProfit ? 'text-long' : 'text-short'}`}>
                      <span className="font-mono font-medium">{isProfit ? '+' : ''}${pnl.toFixed(2)}</span>
                      <span className="text-xs">({isProfit ? '+' : ''}{pnlPercent.toFixed(2)}%)</span>
                    </div>
                    <span className="text-xs text-gray-500">{formatTime(position.openedAt)}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Closed Positions */}
      {closedPositions.length > 0 && (
        <div className="glass rounded-xl p-4">
          <h3 className="text-sm font-medium text-gray-400 mb-3 flex items-center gap-2">
            <Clock className="w-4 h-4" />
            历史记录
          </h3>
          
          <div className="space-y-2">
            {closedPositions.map((position) => {
              const isProfit = (position.pnl || 0) >= 0;
              
              return (
                <div 
                  key={position.id}
                  className="bg-dark-600/20 rounded-lg p-3 opacity-70"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className={`px-2 py-0.5 rounded text-xs ${
                        position.side === 'LONG' ? 'bg-long/20 text-long' : 'bg-short/20 text-short'
                      }`}>
                        {position.side === 'LONG' ? '多' : '空'}
                      </span>
                      <span className="text-xs text-gray-400">{formatTime(position.openedAt)}</span>
                    </div>
                    <div className={`flex items-center gap-1 ${isProfit ? 'text-long' : 'text-short'}`}>
                      <span className="font-mono text-sm">{isProfit ? '+' : ''}${(position.pnl || 0).toFixed(2)}</span>
                      <span className="text-xs">({isProfit ? '+' : ''}{(position.pnlPercent || 0).toFixed(2)}%)</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {openPositions.length === 0 && closedPositions.length === 0 && (
        <div className="glass rounded-xl p-8 text-center">
          <TrendingUp className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-500 text-sm">暂无持仓</p>
          <p className="text-gray-600 text-xs mt-1">在信号页面根据交易计划开仓</p>
        </div>
      )}
    </div>
  );
};