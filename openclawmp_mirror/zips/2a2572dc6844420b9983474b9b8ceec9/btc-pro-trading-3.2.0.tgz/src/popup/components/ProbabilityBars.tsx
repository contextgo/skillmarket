import React from 'react';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface ProbabilityBarsProps {
  longProb: number;
  shortProb: number;
}

export const ProbabilityBars: React.FC<ProbabilityBarsProps> = ({ longProb, shortProb }) => {
  return (
    <div className="glass rounded-xl p-4">
      <h3 className="text-sm font-medium text-gray-400 mb-3">多空概率分布</h3>
      
      <div className="space-y-3">
        {/* Long Probability */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-long" />
              <span className="text-gray-300">看多概率</span>
            </div>
            <span className="font-mono font-medium text-long">{longProb}%</span>
          </div>
          <div className="h-3 bg-dark-600 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-long-dark to-long rounded-full transition-all duration-500"
              style={{ width: `${longProb}%` }}
            />
          </div>
        </div>
        
        {/* Short Probability */}
        <div className="space-y-1">
          <div className="flex items-center justify-between text-sm">
            <div className="flex items-center gap-2">
              <TrendingDown className="w-4 h-4 text-short" />
              <span className="text-gray-300">看空概率</span>
            </div>
            <span className="font-mono font-medium text-short">{shortProb}%</span>
          </div>
          <div className="h-3 bg-dark-600 rounded-full overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-short-dark to-short rounded-full transition-all duration-500"
              style={{ width: `${shortProb}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
};