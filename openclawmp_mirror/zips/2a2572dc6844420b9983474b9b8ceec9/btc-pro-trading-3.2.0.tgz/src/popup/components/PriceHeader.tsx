import React from 'react';
import { TrendingUp, TrendingDown, Clock } from 'lucide-react';

interface PriceHeaderProps {
  price: number;
  change: number;
  lastUpdate: number;
}

export const PriceHeader: React.FC<PriceHeaderProps> = ({ price, change, lastUpdate }) => {
  const isPositive = change >= 0;
  const updateTime = lastUpdate ? new Date(lastUpdate).toLocaleTimeString() : '--:--';
  
  // change 已经是百分比值（如 2.5 表示 +2.5%）
  const displayChange = change;
  
  return (
    <div className="px-4 py-4 bg-gradient-to-r from-dark-800 to-dark-700">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold font-mono">
              ${price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <span className={`flex items-center gap-1 text-sm font-medium ${isPositive ? 'text-long' : 'text-short'}`}>
              {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              {isPositive ? '+' : ''}{displayChange.toFixed(2)}%
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1 text-xs text-gray-500">
          <Clock className="w-3 h-3" />
          <span>{updateTime}</span>
        </div>
      </div>
    </div>
  );
};