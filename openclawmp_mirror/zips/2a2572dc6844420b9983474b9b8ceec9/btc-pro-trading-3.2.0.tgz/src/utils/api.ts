// ==========================================
// Binance API Integration
// ==========================================

import type { Kline, Ticker } from '../types';

const BINANCE_API_BASE = 'https://api.binance.com';
const BINANCE_FAPI_BASE = 'https://fapi.binance.com';

// Fetch kline data
export async function fetchKlines(
  symbol: string = 'BTCUSDT',
  interval: string = '1h',
  limit: number = 100
): Promise<Kline[]> {
  const url = `${BINANCE_API_BASE}/api/v3/klines?symbol=${symbol}&interval=${interval}&limit=${limit}`;
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch klines: ${response.status}`);
  }
  
  const data = await response.json();
  
  return data.map((item: any[]) => ({
    time: item[0],
    open: parseFloat(item[1]),
    high: parseFloat(item[2]),
    low: parseFloat(item[3]),
    close: parseFloat(item[4]),
    volume: parseFloat(item[5])
  }));
}

// Fetch 24h ticker data
export async function fetchTicker(symbol: string = 'BTCUSDT'): Promise<Ticker> {
  const url = `${BINANCE_API_BASE}/api/v3/ticker/24hr?symbol=${symbol}`;
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to fetch ticker: ${response.status}`);
  }
  
  const data = await response.json();
  
  return {
    price: parseFloat(data.lastPrice),
    change: parseFloat(data.priceChange),
    changePercent: parseFloat(data.priceChangePercent),
    high24h: parseFloat(data.highPrice),
    low24h: parseFloat(data.lowPrice),
    volume: parseFloat(data.volume)
  };
}

// Fetch multiple timeframes
export async function fetchMultipleTimeframes(symbol: string = 'BTCUSDT') {
  try {
    const [klines15m, klines1h, klines4h, klines1d, ticker] = await Promise.all([
      fetchKlines(symbol, '15m', 100),
      fetchKlines(symbol, '1h', 100),
      fetchKlines(symbol, '4h', 100),
      fetchKlines(symbol, '1d', 100),
      fetchTicker(symbol)
    ]);
    
    return {
      klines15m,
      klines1h,
      klines4h,
      klines1d,
      ticker
    };
  } catch (error) {
    console.error('[BTC Pro] Failed to fetch data:', error);
    throw error;
  }
}

// Fetch funding rate (for futures)
export async function fetchFundingRate(symbol: string = 'BTCUSDT') {
  const url = `${BINANCE_FAPI_BASE}/fapi/v1/fundingRate?symbol=${symbol}&limit=1`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) return null;
    
    const data = await response.json();
    return data[0] ? parseFloat(data[0].fundingRate) : null;
  } catch {
    return null;
  }
}

// Fetch open interest
export async function fetchOpenInterest(symbol: string = 'BTCUSDT') {
  const url = `${BINANCE_FAPI_BASE}/fapi/v1/openInterest?symbol=${symbol}`;
  
  try {
    const response = await fetch(url);
    if (!response.ok) return null;
    
    const data = await response.json();
    return {
      openInterest: parseFloat(data.openInterest),
      timestamp: data.time
    };
  } catch {
    return null;
  }
}