// ==========================================
// Trading Strategies Implementation
// ==========================================

import type { Kline, StrategyResult, ICTStructure, OrderBlock, FVG } from '../types/index.js';
import { calcEMA, calcRSI, calcMACD, calcBollinger, calcVolumeProfile } from './indicators';

// 1. Trend Following Strategy
export function analyzeTrendFollowing(klines: Kline[], _higherKlines: Kline[]): StrategyResult {
  const closes = klines.map(k => k.close);
  const ema20 = calcEMA(closes, 20);
  const ema50 = calcEMA(closes, 50);
  const ema200 = calcEMA(closes, 200);
  
  const current = closes.length - 1;
  const price = closes[current];
  
  // Trend strength
  const trend20 = ema20[current] > ema20[current - 5] ? 'up' : 'down';
  const trend50 = ema50[current] > ema50[current - 10] ? 'up' : 'down';
  const trend200 = price > ema200[current] ? 'bullish' : 'bearish';
  
  // Alignment score
  let alignmentScore = 0;
  if (ema20[current] > ema50[current]) alignmentScore += 25;
  if (ema50[current] > ema200[current]) alignmentScore += 25;
  if (trend20 === trend50) alignmentScore += 25;
  if (trend200 === 'bullish') alignmentScore += 25;
  
  const longProb = trend200 === 'bullish' ? alignmentScore : alignmentScore * 0.3;
  const shortProb = trend200 === 'bearish' ? alignmentScore : alignmentScore * 0.3;
  
  let signal: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  if (longProb > 60) signal = 'LONG';
  else if (shortProb > 60) signal = 'SHORT';
  
  return {
    name: '趋势跟踪',
    longProb: Math.round(longProb),
    shortProb: Math.round(shortProb),
    signal,
    confidence: Math.max(longProb, shortProb),
    reasons: [
      `EMA20趋势: ${trend20 === 'up' ? '上升' : '下降'}`,
      `EMA50趋势: ${trend50 === 'up' ? '上升' : '下降'}`,
      `长期趋势: ${trend200 === 'bullish' ? '牛市' : '熊市'}`
    ]
  };
}

// 2. Mean Reversion Strategy
export function analyzeMeanReversion(klines: Kline[]): StrategyResult {
  const rsi = calcRSI(klines, 14);
  const bollinger = calcBollinger(klines, 20, 2);
  
  if (!bollinger) {
    return {
      name: '均值回归',
      longProb: 0,
      shortProb: 0,
      signal: 'WAIT',
      confidence: 0,
      reasons: ['数据不足']
    };
  }
  
  const position = bollinger.position;
  
  // Oversold/overbought conditions
  const isOversold = rsi < 30 && position < 0.2;
  const isOverbought = rsi > 70 && position > 0.8;
  
  const longProb = isOversold ? 70 + (30 - rsi) : rsi < 40 ? 40 : 20;
  const shortProb = isOverbought ? 70 + (rsi - 70) : rsi > 60 ? 40 : 20;
  
  let signal: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  if (longProb > 65) signal = 'LONG';
  else if (shortProb > 65) signal = 'SHORT';
  
  return {
    name: '均值回归',
    longProb: Math.round(longProb),
    shortProb: Math.round(shortProb),
    signal,
    confidence: Math.max(longProb, shortProb),
    reasons: [
      `RSI: ${rsi.toFixed(1)}`,
      `布林带位置: ${(position * 100).toFixed(1)}%`,
      isOversold ? '超卖状态' : isOverbought ? '超买状态' : '中性区间'
    ]
  };
}

// 3. Breakout Strategy
export function analyzeBreakout(klines: Kline[]): StrategyResult {
  const period = 20;
  if (klines.length < period + 5) {
    return {
      name: '突破交易',
      longProb: 0,
      shortProb: 0,
      signal: 'WAIT',
      confidence: 0,
      reasons: ['数据不足']
    };
  }
  
  const recent = klines.slice(-period);
  const highs = recent.map(k => k.high);
  const lows = recent.map(k => k.low);
  
  const highest = Math.max(...highs);
  const lowest = Math.min(...lows);
  const current = klines[klines.length - 1];
  const prev = klines[klines.length - 2];
  
  // Breakout detection
  const breakoutUp = current.close > highest && prev.close <= highest;
  const breakoutDown = current.close < lowest && prev.close >= lowest;
  
  // Volume confirmation
  const avgVolume = recent.reduce((sum, k) => sum + k.volume, 0) / period;
  const volumeConfirm = current.volume > avgVolume * 1.5;
  
  let longProb = 0;
  let shortProb = 0;
  
  if (breakoutUp) {
    longProb = volumeConfirm ? 80 : 60;
  } else if (current.close > highest * 0.98) {
    longProb = 40;
  }
  
  if (breakoutDown) {
    shortProb = volumeConfirm ? 80 : 60;
  } else if (current.close < lowest * 1.02) {
    shortProb = 40;
  }
  
  let signal: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  if (longProb > 60) signal = 'LONG';
  else if (shortProb > 60) signal = 'SHORT';
  
  return {
    name: '突破交易',
    longProb: Math.round(longProb),
    shortProb: Math.round(shortProb),
    signal,
    confidence: Math.max(longProb, shortProb),
    reasons: [
      `区间高点: $${highest.toFixed(2)}`,
      `区间低点: $${lowest.toFixed(2)}`,
      breakoutUp ? '向上突破' : breakoutDown ? '向下突破' : '区间内波动',
      volumeConfirm ? '成交量确认' : '成交量不足'
    ]
  };
}

// 4. MACD Momentum Strategy
export function analyzeMACD(klines: Kline[]): StrategyResult {
  const macd = calcMACD(klines, 12, 26, 9);
  
  const histogramRising = macd.histogram > 0 && macd.trend === 'up';
  const histogramFalling = macd.histogram < 0 && macd.trend === 'down';
  
  const bullishCross = macd.macd > macd.signal && macd.histogram > 0;
  const bearishCross = macd.macd < macd.signal && macd.histogram < 0;
  
  let longProb = 0;
  let shortProb = 0;
  
  if (bullishCross && histogramRising) {
    longProb = 75;
  } else if (bullishCross) {
    longProb = 55;
  } else if (macd.macd > macd.signal) {
    longProb = 40;
  }
  
  if (bearishCross && histogramFalling) {
    shortProb = 75;
  } else if (bearishCross) {
    shortProb = 55;
  } else if (macd.macd < macd.signal) {
    shortProb = 40;
  }
  
  let signal: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  if (longProb > 55) signal = 'LONG';
  else if (shortProb > 55) signal = 'SHORT';
  
  return {
    name: 'MACD动量',
    longProb: Math.round(longProb),
    shortProb: Math.round(shortProb),
    signal,
    confidence: Math.max(longProb, shortProb),
    reasons: [
      `MACD: ${macd.macd.toFixed(4)}`,
      `信号线: ${macd.signal.toFixed(4)}`,
      `柱状图: ${macd.histogram > 0 ? '上升' : '下降'}`,
      bullishCross ? '金叉' : bearishCross ? '死叉' : '无交叉'
    ]
  };
}

// 5. ICT/SMC Structure Analysis
export function analyzeICTStructure(klines: Kline[], _higherKlines: Kline[]): StrategyResult {
  const structure = identifyICTStructure(klines);
  const orderBlocks = findOrderBlocks(klines);
  const fvgs = findFVGs(klines);
  
  const currentPrice = klines[klines.length - 1].close;
  
  // Check if price is near bullish order block
  const nearBullishOB = orderBlocks.some(ob => 
    ob.type === 'bullish' && 
    currentPrice >= ob.low && 
    currentPrice <= ob.high * 1.02
  );
  
  // Check if price is near bearish order block
  const nearBearishOB = orderBlocks.some(ob => 
    ob.type === 'bearish' && 
    currentPrice <= ob.high && 
    currentPrice >= ob.low * 0.98
  );
  
  // Check for FVG fills
  const bullishFVG = fvgs.find(f => f.type === 'bullish' && currentPrice >= f.low && currentPrice <= f.high);
  const bearishFVG = fvgs.find(f => f.type === 'bearish' && currentPrice <= f.high && currentPrice >= f.low);
  
  let longProb = 0;
  let shortProb = 0;
  
  if (structure.trend === 'bullish' && nearBullishOB) {
    longProb = 70;
  } else if (nearBullishOB) {
    longProb = 50;
  } else if (bullishFVG) {
    longProb = 45;
  }
  
  if (structure.trend === 'bearish' && nearBearishOB) {
    shortProb = 70;
  } else if (nearBearishOB) {
    shortProb = 50;
  } else if (bearishFVG) {
    shortProb = 45;
  }
  
  let signal: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  if (longProb > 55) signal = 'LONG';
  else if (shortProb > 55) signal = 'SHORT';
  
  return {
    name: 'ICT/SMC结构',
    longProb: Math.round(longProb),
    shortProb: Math.round(shortProb),
    signal,
    confidence: Math.max(longProb, shortProb),
    reasons: [
      `结构趋势: ${structure.trend === 'bullish' ? '牛市' : structure.trend === 'bearish' ? '熊市' : '中性'}`,
      nearBullishOB ? '接近看涨订单块' : nearBearishOB ? '接近看跌订单块' : '无订单块',
      bullishFVG ? '看涨FVG区域' : bearishFVG ? '看跌FVG区域' : '无FVG'
    ]
  };
}

// Helper: Identify ICT Structure
function identifyICTStructure(klines: Kline[]): ICTStructure {
  const swings = findSwingPoints(klines, 5);
  
  let hh = 0, hl = 0, lh = 0, ll = 0;
  let bos: 'bullish' | 'bearish' | null = null;
  
  if (swings.length >= 4) {
    const recent = swings.slice(-4);
    
    // Check for higher highs and higher lows
    if (recent[2].high > recent[0].high && recent[3].low > recent[1].low) {
      hh = recent[2].high;
      hl = recent[3].low;
      bos = 'bullish';
    }
    
    // Check for lower highs and lower lows
    if (recent[2].high < recent[0].high && recent[3].low < recent[1].low) {
      lh = recent[2].high;
      ll = recent[3].low;
      bos = 'bearish';
    }
  }
  
  const trend = bos === 'bullish' ? 'bullish' : bos === 'bearish' ? 'bearish' : 'neutral';
  
  return { trend, hh, hl, lh, ll, bos };
}

// Helper: Find Swing Points
function findSwingPoints(klines: Kline[], strength: number = 5) {
  const swings: { index: number; high: number; low: number; type: 'high' | 'low' }[] = [];
  
  for (let i = strength; i < klines.length - strength; i++) {
    const isHigh = klines.slice(i - strength, i).every(k => k.high <= klines[i].high) &&
                   klines.slice(i + 1, i + strength + 1).every(k => k.high <= klines[i].high);
    
    const isLow = klines.slice(i - strength, i).every(k => k.low >= klines[i].low) &&
                  klines.slice(i + 1, i + strength + 1).every(k => k.low >= klines[i].low);
    
    if (isHigh) swings.push({ index: i, high: klines[i].high, low: klines[i].low, type: 'high' });
    if (isLow) swings.push({ index: i, high: klines[i].high, low: klines[i].low, type: 'low' });
  }
  
  return swings;
}

// Helper: Find Order Blocks
function findOrderBlocks(klines: Kline[]): OrderBlock[] {
  const obs: OrderBlock[] = [];
  const swings = findSwingPoints(klines, 3);
  
  for (let i = 1; i < swings.length; i++) {
    const prev = swings[i - 1];
    const curr = swings[i];
    
    // Bullish OB: before a bullish move
    if (prev.type === 'low' && curr.type === 'high' && curr.high > prev.high) {
      const obIndex = prev.index - 1;
      if (obIndex >= 0) {
        obs.push({
          type: 'bullish',
          high: klines[obIndex].high,
          low: klines[obIndex].low,
          pullback: true,
          index: obIndex
        });
      }
    }
    
    // Bearish OB: before a bearish move
    if (prev.type === 'high' && curr.type === 'low' && curr.low < prev.low) {
      const obIndex = prev.index - 1;
      if (obIndex >= 0) {
        obs.push({
          type: 'bearish',
          high: klines[obIndex].high,
          low: klines[obIndex].low,
          pullback: true,
          index: obIndex
        });
      }
    }
  }
  
  return obs.slice(-5); // Return last 5
}

// Helper: Find Fair Value Gaps
function findFVGs(klines: Kline[]): FVG[] {
  const fvgs: FVG[] = [];
  
  for (let i = 2; i < klines.length; i++) {
    const prev = klines[i - 2];
    const curr = klines[i];
    
    // Bullish FVG
    if (curr.low > prev.high) {
      fvgs.push({
        type: 'bullish',
        high: curr.low,
        low: prev.high,
        index: i - 1
      });
    }
    
    // Bearish FVG
    if (curr.high < prev.low) {
      fvgs.push({
        type: 'bearish',
        high: prev.low,
        low: curr.high,
        index: i - 1
      });
    }
  }
  
  return fvgs.slice(-5);
}

// 6. Volume Analysis Strategy
export function analyzeVolume(klines: Kline[]): StrategyResult {
  const vp = calcVolumeProfile(klines, 20);
  
  if (!vp) {
    return {
      name: '成交量分析',
      longProb: 0,
      shortProb: 0,
      signal: 'WAIT',
      confidence: 0,
      reasons: ['数据不足']
    };
  }
  
  const currentPrice = klines[klines.length - 1].close;
  const aboveVWAP = currentPrice > vp.vwap;
  const volumeSpike = vp.ratio > 2;
  const highVolume = vp.ratio > 1.5;
  
  let longProb = 0;
  let shortProb = 0;
  
  if (aboveVWAP && volumeSpike) {
    longProb = 70;
  } else if (aboveVWAP && highVolume) {
    longProb = 55;
  } else if (aboveVWAP) {
    longProb = 40;
  }
  
  if (!aboveVWAP && volumeSpike) {
    shortProb = 70;
  } else if (!aboveVWAP && highVolume) {
    shortProb = 55;
  } else if (!aboveVWAP) {
    shortProb = 40;
  }
  
  let signal: 'LONG' | 'SHORT' | 'WAIT' = 'WAIT';
  if (longProb > 60) signal = 'LONG';
  else if (shortProb > 60) signal = 'SHORT';
  
  return {
    name: '成交量分析',
    longProb: Math.round(longProb),
    shortProb: Math.round(shortProb),
    signal,
    confidence: Math.max(longProb, shortProb),
    reasons: [
      `VWAP: $${vp.vwap.toFixed(2)}`,
      `成交量比: ${vp.ratio.toFixed(2)}x`,
      aboveVWAP ? '价格在VWAP上方' : '价格在VWAP下方',
      volumeSpike ? '成交量激增' : highVolume ? '成交量放大' : '成交量正常'
    ]
  };
}