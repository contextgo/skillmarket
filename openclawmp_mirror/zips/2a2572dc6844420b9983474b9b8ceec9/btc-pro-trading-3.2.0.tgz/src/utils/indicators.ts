// ==========================================
// Technical Indicators
// ==========================================

import type { Kline } from '../types';

export function calcEMA(data: number[], period: number): number[] {
  const k = 2 / (period + 1);
  const ema = [data[0]];
  for (let i = 1; i < data.length; i++) {
    ema.push(data[i] * k + ema[i - 1] * (1 - k));
  }
  return ema;
}

export function calcRSI(klines: Kline[], period = 14): number {
  if (klines.length < period + 1) return 50;
  
  const changes: number[] = [];
  for (let i = 1; i < klines.length; i++) {
    changes.push(klines[i].close - klines[i - 1].close);
  }
  
  let gains = 0, losses = 0;
  for (let i = 0; i < period; i++) {
    if (changes[i] > 0) gains += changes[i];
    else losses -= changes[i];
  }
  
  let avgGain = gains / period;
  let avgLoss = losses / period;
  
  for (let i = period; i < changes.length; i++) {
    const gain = changes[i] > 0 ? changes[i] : 0;
    const loss = changes[i] < 0 ? -changes[i] : 0;
    avgGain = (avgGain * (period - 1) + gain) / period;
    avgLoss = (avgLoss * (period - 1) + loss) / period;
  }
  
  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
}

export function calcMACD(klines: Kline[], fast = 12, slow = 26, signal = 9) {
  const closes = klines.map(k => k.close);
  const emaFast = calcEMA(closes, fast);
  const emaSlow = calcEMA(closes, slow);
  const macdLine = emaFast.map((v, i) => v - emaSlow[i]);
  const signalLine = calcEMA(macdLine, signal);
  const histogram = macdLine.map((v, i) => v - signalLine[i]);
  
  return {
    macd: macdLine[macdLine.length - 1],
    signal: signalLine[signalLine.length - 1],
    histogram: histogram[histogram.length - 1],
    trend: histogram[histogram.length - 1] > histogram[histogram.length - 2] ? 'up' : 'down'
  };
}

export function calcBollinger(klines: Kline[], period = 20, stdDev = 2) {
  if (klines.length < period) return null;
  
  const closes = klines.slice(-period).map(k => k.close);
  const sma = closes.reduce((a, b) => a + b) / period;
  const variance = closes.reduce((sum, c) => sum + Math.pow(c - sma, 2), 0) / period;
  const std = Math.sqrt(variance);
  const current = klines[klines.length - 1].close;
  
  return {
    upper: sma + stdDev * std,
    middle: sma,
    lower: sma - stdDev * std,
    position: (current - (sma - stdDev * std)) / ((sma + stdDev * std) - (sma - stdDev * std)),
    width: (2 * stdDev * std) / sma
  };
}

export function calcATR(klines: Kline[], period = 14): number {
  const trs: number[] = [];
  for (let i = 1; i < klines.length; i++) {
    const tr = Math.max(
      klines[i].high - klines[i].low,
      Math.abs(klines[i].high - klines[i - 1].close),
      Math.abs(klines[i].low - klines[i - 1].close)
    );
    trs.push(tr);
  }
  
  if (trs.length < period) {
    return trs.length > 0 ? trs.reduce((a, b) => a + b) / trs.length : 0;
  }
  return trs.slice(-period).reduce((a, b) => a + b) / period;
}

export function calcADX(klines: Kline[], period = 14) {
  if (klines.length < period * 2 + 1) {
    return { adx: 0, plusDI: 0, minusDI: 0 };
  }
  
  const plusDM: number[] = [];
  const minusDM: number[] = [];
  const trList: number[] = [];
  
  for (let i = 1; i < klines.length; i++) {
    const highDiff = klines[i].high - klines[i - 1].high;
    const lowDiff = klines[i - 1].low - klines[i].low;
    plusDM.push(Math.max(highDiff, 0) > Math.max(lowDiff, 0) ? Math.max(highDiff, 0) : 0);
    minusDM.push(Math.max(lowDiff, 0) > Math.max(highDiff, 0) ? Math.max(lowDiff, 0) : 0);
    trList.push(Math.max(
      klines[i].high - klines[i].low,
      Math.abs(klines[i].high - klines[i - 1].close),
      Math.abs(klines[i].low - klines[i - 1].close)
    ));
  }
  
  const smooth = (data: number[], p: number): number[] => {
    const result = [data.slice(0, p).reduce((a, b) => a + b)];
    for (let i = p; i < data.length; i++) {
      result.push(result[result.length - 1] - result[result.length - 1] / p + data[i]);
    }
    return result;
  };
  
  const smoothTR = smooth(trList, period);
  const smoothPlus = smooth(plusDM, period);
  const smoothMinus = smooth(minusDM, period);
  
  const plusDI = smoothPlus.map((v, i) => smoothTR[i] === 0 ? 0 : v / smoothTR[i] * 100);
  const minusDI = smoothMinus.map((v, i) => smoothTR[i] === 0 ? 0 : v / smoothTR[i] * 100);
  
  const dxList: number[] = [];
  for (let i = 0; i < plusDI.length; i++) {
    const sum = plusDI[i] + minusDI[i];
    dxList.push(sum === 0 ? 0 : Math.abs(plusDI[i] - minusDI[i]) / sum * 100);
  }
  
  const adx = dxList.slice(-period).reduce((a, b) => a + b) / period;
  
  return {
    adx,
    plusDI: plusDI[plusDI.length - 1],
    minusDI: minusDI[minusDI.length - 1]
  };
}

export function calcVolumeProfile(klines: Kline[], periods = 20) {
  if (klines.length < periods) return null;
  
  const recent = klines.slice(-periods);
  const totalVolume = recent.reduce((sum, k) => sum + k.volume, 0);
  const avgVolume = totalVolume / periods;
  const currentVolume = recent[recent.length - 1].volume;
  const vwap = recent.reduce((sum, k) => sum + k.volume * (k.high + k.low + k.close) / 3, 0) / totalVolume;
  
  return {
    avgVolume,
    currentVolume,
    ratio: currentVolume / avgVolume,
    vwap
  };
}