// ==========================================
// Trade Plan Generator
// ==========================================

import type { CombinedAnalysis, TradePlan, Kline } from '../types';
import { calcATR } from './indicators';

export function generateTradePlan(
  analysis: CombinedAnalysis,
  klines: Kline[],
  riskPercent: number = 2
): TradePlan | null {
  if (analysis.signal === 'WAIT') {
    return null;
  }
  
  const currentPrice = analysis.price;
  const atr = calcATR(klines, 14);
  
  // Calculate position size based on risk
  const balance = 10000; // Default balance
  const riskAmount = balance * (riskPercent / 100);
  
  let entry: number;
  let stopLoss: number;
  let takeProfit1: number;
  let takeProfit2: number;
  let positionSize: number;
  
  if (analysis.signal === 'LONG') {
    // Long position
    entry = currentPrice;
    stopLoss = entry - (atr * 2);
    takeProfit1 = entry + (atr * 2);
    takeProfit2 = entry + (atr * 4);
    
    const riskPerUnit = entry - stopLoss;
    positionSize = riskAmount / riskPerUnit;
  } else {
    // Short position
    entry = currentPrice;
    stopLoss = entry + (atr * 2);
    takeProfit1 = entry - (atr * 2);
    takeProfit2 = entry - (atr * 4);
    
    const riskPerUnit = stopLoss - entry;
    positionSize = riskAmount / riskPerUnit;
  }
  
  // Determine mode based on signal strength
  const mode: 'aggressive' | 'conservative' = analysis.signalStrength > 70 ? 'aggressive' : 'conservative';
  
  return {
    entry: parseFloat(entry.toFixed(2)),
    stopLoss: parseFloat(stopLoss.toFixed(2)),
    takeProfit1: parseFloat(takeProfit1.toFixed(2)),
    takeProfit2: parseFloat(takeProfit2.toFixed(2)),
    riskPercent,
    positionSize: parseFloat(positionSize.toFixed(4)),
    mode
  };
}

export function validateTradePlan(plan: TradePlan, currentPrice: number): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Check risk/reward ratio
  const risk = Math.abs(plan.entry - plan.stopLoss);
  const reward1 = Math.abs(plan.takeProfit1 - plan.entry);
  const reward2 = Math.abs(plan.takeProfit2 - plan.entry);
  
  const rr1 = reward1 / risk;
  const rr2 = reward2 / risk;
  
  if (rr1 < 1) {
    errors.push('风险/收益比过低 (TP1)');
  }
  
  if (rr2 < 2) {
    errors.push('第二止盈位风险/收益比建议大于2');
  }
  
  // Check if price is too far from entry
  const priceDiff = Math.abs(currentPrice - plan.entry) / plan.entry;
  if (priceDiff > 0.02) {
    errors.push('当前价格与入场价偏差超过2%，建议重新评估');
  }
  
  // Check stop loss distance
  const stopDistance = risk / plan.entry;
  if (stopDistance > 0.05) {
    errors.push('止损距离过大 (>5%)，建议缩小仓位或调整策略');
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

export function calculatePositionSize(
  balance: number,
  entry: number,
  stopLoss: number,
  riskPercent: number
): number {
  const riskAmount = balance * (riskPercent / 100);
  const riskPerUnit = Math.abs(entry - stopLoss);
  
  if (riskPerUnit === 0) return 0;
  
  return riskAmount / riskPerUnit;
}

export function estimateProfit(
  positionSize: number,
  entry: number,
  exit: number,
  side: 'LONG' | 'SHORT'
): { pnl: number; pnlPercent: number } {
  const priceDiff = side === 'LONG' ? exit - entry : entry - exit;
  const pnl = positionSize * priceDiff;
  const pnlPercent = (priceDiff / entry) * 100;
  
  return {
    pnl: parseFloat(pnl.toFixed(2)),
    pnlPercent: parseFloat(pnlPercent.toFixed(2))
  };
}