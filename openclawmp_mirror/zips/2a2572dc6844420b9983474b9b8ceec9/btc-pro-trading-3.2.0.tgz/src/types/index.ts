// ==========================================
// BTC Pro Trading - Type Definitions
// ==========================================

export interface Kline {
  time: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export interface Ticker {
  price: number;
  change: number;
  changePercent: number;
  high24h: number;
  low24h: number;
  volume: number;
}

export interface StrategyResult {
  name: string;
  longProb: number;
  shortProb: number;
  signal: 'LONG' | 'SHORT' | 'WAIT';
  confidence: number;
  reasons: string[];
}

export interface CombinedAnalysis {
  price: number;
  change: number;
  longProb: number;
  shortProb: number;
  signal: 'LONG' | 'SHORT' | 'WAIT';
  signalStrength: number;
  consensus: number;
  strategies: StrategyResult[];
  timestamp: number;
}

export interface TradePlan {
  entry: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  riskPercent: number;
  positionSize: number;
  mode: 'aggressive' | 'conservative';
}

export interface Position {
  id: string;
  symbol: string;
  side: 'LONG' | 'SHORT';
  entryPrice: number;
  quantity: number;
  stopLoss: number;
  takeProfit1: number;
  takeProfit2: number;
  status: 'OPEN' | 'CLOSED' | 'PARTIAL';
  openedAt: number;
  closedAt?: number;
  closedPrice?: number;
  pnl?: number;
  pnlPercent?: number;
}

export interface Portfolio {
  balance: number;
  positions: Position[];
  totalPnl: number;
  totalPnlPercent: number;
  winRate: number;
  totalTrades: number;
}

export interface ICTStructure {
  trend: 'bullish' | 'bearish' | 'neutral';
  hh: number;
  hl: number;
  lh: number;
  ll: number;
  bos: 'bullish' | 'bearish' | null;
}

export interface OrderBlock {
  type: 'bullish' | 'bearish';
  high: number;
  low: number;
  pullback: boolean;
  index: number;
}

export interface FVG {
  type: 'bullish' | 'bearish';
  high: number;
  low: number;
  index: number;
}

export interface NotificationSettings {
  enabled: boolean;
  minSignalStrength: number;
  minConsensus: number;
  cooldownMinutes: number;
  priceAlerts: boolean;
}

export interface ExtensionState {
  analysis: CombinedAnalysis | null;
  portfolio: Portfolio;
  settings: NotificationSettings;
  lastUpdate: number;
  isLoading: boolean;
  error: string | null;
}