import { useEffect, useRef, useState } from 'react';
import { createChart, IChartApi, ISeriesApi, CandlestickData, HistogramData } from 'lightweight-charts';
import type { CombinedAnalysis } from '../types/index.js';

export default function ChartPage() {
  const chartContainerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candlestickSeriesRef = useRef<ISeriesApi<'Candlestick'> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<'Histogram'> | null>(null);
  
  const [timeframe, setTimeframe] = useState('1h');
  const [analysis, setAnalysis] = useState<CombinedAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!chartContainerRef.current) return;

    // 创建图表
    const chart = createChart(chartContainerRef.current, {
      layout: {
        background: { color: '#0a0a0f' },
        textColor: '#888',
      },
      grid: {
        vertLines: { color: '#1a1a25' },
        horzLines: { color: '#1a1a25' },
      },
      crosshair: {
        mode: 1,
        vertLine: {
          color: '#3b82f6',
          labelBackgroundColor: '#3b82f6',
        },
        horzLine: {
          color: '#3b82f6',
          labelBackgroundColor: '#3b82f6',
        },
      },
      rightPriceScale: {
        borderColor: '#353545',
      },
      timeScale: {
        borderColor: '#353545',
        timeVisible: true,
      },
    });

    // 创建K线系列
    const candlestickSeries = chart.addCandlestickSeries({
      upColor: '#00d084',
      downColor: '#ff4757',
      borderUpColor: '#00d084',
      borderDownColor: '#ff4757',
      wickUpColor: '#00d084',
      wickDownColor: '#ff4757',
    });

    // 创建成交量系列
    const volumeSeries = chart.addHistogramSeries({
      color: '#3b82f6',
      priceFormat: {
        type: 'volume',
      },
      priceScaleId: '',
    });
    volumeSeries.priceScale().applyOptions({
      scaleMargins: {
        top: 0.8,
        bottom: 0,
      },
    });

    chartRef.current = chart;
    candlestickSeriesRef.current = candlestickSeries;
    volumeSeriesRef.current = volumeSeries;

    // 加载数据
    loadData(timeframe);

    // 监听存储变化
    const handleStorageChange = (changes: { [key: string]: chrome.storage.StorageChange }) => {
      if (changes.analysis) {
        setAnalysis(changes.analysis.newValue);
      }
    };
    
    chrome.storage.onChanged.addListener(handleStorageChange);
    
    // 初始加载分析数据
    chrome.storage.local.get('analysis').then(data => {
      if (data.analysis) {
        setAnalysis(data.analysis);
      }
    });

    // 响应式调整
    const handleResize = () => {
      chart.applyOptions({
        width: chartContainerRef.current?.clientWidth || 800,
        height: chartContainerRef.current?.clientHeight || 400,
      });
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      chrome.storage.onChanged.removeListener(handleStorageChange);
      chart.remove();
    };
  }, []);

  // 时间周期变化时重新加载
  useEffect(() => {
    loadData(timeframe);
  }, [timeframe]);

  const loadData = async (tf: string) => {
    setIsLoading(true);
    try {
      // 获取K线数据
      const response = await fetch(
        `https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=${tf}&limit=500`
      );
      const data = await response.json();
      
      const candles: CandlestickData[] = data.map((d: any[]) => ({
        time: d[0] / 1000,
        open: parseFloat(d[1]),
        high: parseFloat(d[2]),
        low: parseFloat(d[3]),
        close: parseFloat(d[4]),
      }));

      const volumes: HistogramData[] = data.map((d: any[]) => ({
        time: d[0] / 1000,
        value: parseFloat(d[5]),
        color: parseFloat(d[4]) >= parseFloat(d[1]) ? '#00d08480' : '#ff475780',
      }));

      candlestickSeriesRef.current?.setData(candles);
      volumeSeriesRef.current?.setData(volumes);
      
      chartRef.current?.timeScale().fitContent();
    } catch (error) {
      console.error('Failed to load chart data:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const timeframes = [
    { label: '15m', value: '15m' },
    { label: '1H', value: '1h' },
    { label: '4H', value: '4h' },
    { label: '1D', value: '1d' },
  ];

  return (
    <div className="flex flex-col h-screen bg-dark-900">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 bg-dark-800 border-b border-dark-600">
        <div className="flex items-center gap-4">
          <h1 className="font-bold text-lg">BTC/USDT</h1>
          {analysis && (
            <div className="flex items-center gap-2">
              <span className="font-mono text-xl">${analysis.price.toLocaleString()}</span>
              <span className={`text-sm ${analysis.change >= 0 ? 'text-long' : 'text-short'}`}>
                {analysis.change >= 0 ? '+' : ''}{analysis.change.toFixed(2)}%
              </span>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-1">
          {timeframes.map((tf) => (
            <button
              key={tf.value}
              onClick={() => setTimeframe(tf.value)}
              className={`timeframe-btn ${timeframe === tf.value ? 'active' : ''}`}
            >
              {tf.label}
            </button>
          ))}
        </div>
      </div>

      {/* Signal Info */}
      {analysis && (
        <div className="flex items-center gap-4 px-4 py-2 bg-dark-700/50 border-b border-dark-600 text-xs">
          <div className="flex items-center gap-2">
            <span className="text-gray-400">信号:</span>
            <span className={`font-medium ${
              analysis.signal === 'LONG' ? 'text-long' : 
              analysis.signal === 'SHORT' ? 'text-short' : 'text-gray-400'
            }`}>
              {analysis.signal === 'LONG' ? '看多' : 
               analysis.signal === 'SHORT' ? '看空' : '观望'}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">强度:</span>
            <span className="font-medium">{analysis.signalStrength}%</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">看多:</span>
            <span className="font-medium text-long">{analysis.longProb}%</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-gray-400">看空:</span>
            <span className="font-medium text-short">{analysis.shortProb}%</span>
          </div>
        </div>
      )}

      {/* Chart */}
      <div className="flex-1 relative">
        {isLoading && (
          <div className="absolute inset-0 flex items-center justify-center bg-dark-900/80 z-10">
            <div className="w-8 h-8 border-2 border-accent-blue border-t-transparent rounded-full animate-spin" />
          </div>
        )}
        <div ref={chartContainerRef} className="tv-chart" />
      </div>
    </div>
  );
}