import React from 'react';
import { createRoot } from 'react-dom/client';
import ChartPage from './ChartPage';
import './chart.css';

const container = document.getElementById('root');
if (container) {
  const root = createRoot(container);
  root.render(
    <React.StrictMode>
      <ChartPage />
    </React.StrictMode>
  );
}