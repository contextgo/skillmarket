/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx}',
    './public/*.html'
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        // 深色主题配色
        dark: {
          900: '#0a0a0f',
          800: '#12121a',
          700: '#1a1a25',
          600: '#252535',
          500: '#353545',
        },
        // 交易配色
        long: {
          DEFAULT: '#00d084',
          light: '#00e676',
          dark: '#00b060',
          glow: 'rgba(0, 208, 132, 0.3)'
        },
        short: {
          DEFAULT: '#ff4757',
          light: '#ff6b7a',
          dark: '#e03e4c',
          glow: 'rgba(255, 71, 87, 0.3)'
        },
        accent: {
          blue: '#3b82f6',
          purple: '#8b5cf6',
          cyan: '#06b6d4',
          amber: '#f59e0b'
        }
      },
      fontFamily: {
        mono: ['JetBrains Mono', 'Fira Code', 'monospace'],
        sans: ['Inter', 'system-ui', 'sans-serif']
      },
      backdropBlur: {
        xs: '2px'
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
        'slide-up': 'slideUp 0.3s ease-out',
        'fade-in': 'fadeIn 0.2s ease-out'
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 5px rgba(0, 208, 132, 0.3)' },
          '100%': { boxShadow: '0 0 20px rgba(0, 208, 132, 0.5)' }
        },
        slideUp: {
          '0%': { transform: 'translateY(10px)', opacity: '0' },
          '100%': { transform: 'translateY(0)', opacity: '1' }
        },
        fadeIn: {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' }
        }
      }
    }
  },
  plugins: []
}