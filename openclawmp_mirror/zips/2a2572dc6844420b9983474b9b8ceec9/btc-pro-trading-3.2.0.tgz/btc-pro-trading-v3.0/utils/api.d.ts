import type { Kline, Ticker } from '../types';
export declare function fetchKlines(symbol?: string, interval?: string, limit?: number): Promise<Kline[]>;
export declare function fetchTicker(symbol?: string): Promise<Ticker>;
export declare function fetchMultipleTimeframes(symbol?: string): Promise<{
    klines15m: Kline[];
    klines1h: Kline[];
    klines4h: Kline[];
    klines1d: Kline[];
    ticker: Ticker;
}>;
export declare function fetchFundingRate(symbol?: string): Promise<number | null>;
export declare function fetchOpenInterest(symbol?: string): Promise<{
    openInterest: number;
    timestamp: any;
} | null>;
//# sourceMappingURL=api.d.ts.map