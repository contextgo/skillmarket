import type { CombinedAnalysis, TradePlan, Kline } from '../types';
export declare function generateTradePlan(analysis: CombinedAnalysis, klines: Kline[], riskPercent?: number): TradePlan | null;
export declare function validateTradePlan(plan: TradePlan, currentPrice: number): {
    valid: boolean;
    errors: string[];
};
export declare function calculatePositionSize(balance: number, entry: number, stopLoss: number, riskPercent: number): number;
export declare function estimateProfit(positionSize: number, entry: number, exit: number, side: 'LONG' | 'SHORT'): {
    pnl: number;
    pnlPercent: number;
};
//# sourceMappingURL=tradePlan.d.ts.map