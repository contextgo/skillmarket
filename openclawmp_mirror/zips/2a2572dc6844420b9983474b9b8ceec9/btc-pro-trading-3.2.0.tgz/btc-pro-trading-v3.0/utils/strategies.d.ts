import type { Kline, StrategyResult } from '../types/index.js';
export declare function analyzeTrendFollowing(klines: Kline[], _higherKlines: Kline[]): StrategyResult;
export declare function analyzeMeanReversion(klines: Kline[]): StrategyResult;
export declare function analyzeBreakout(klines: Kline[]): StrategyResult;
export declare function analyzeMACD(klines: Kline[]): StrategyResult;
export declare function analyzeICTStructure(klines: Kline[], _higherKlines: Kline[]): StrategyResult;
export declare function analyzeVolume(klines: Kline[]): StrategyResult;
//# sourceMappingURL=strategies.d.ts.map