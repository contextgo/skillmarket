import type { Kline } from '../types';
export declare function calcEMA(data: number[], period: number): number[];
export declare function calcRSI(klines: Kline[], period?: number): number;
export declare function calcMACD(klines: Kline[], fast?: number, slow?: number, signal?: number): {
    macd: number;
    signal: number;
    histogram: number;
    trend: string;
};
export declare function calcBollinger(klines: Kline[], period?: number, stdDev?: number): {
    upper: number;
    middle: number;
    lower: number;
    position: number;
    width: number;
} | null;
export declare function calcATR(klines: Kline[], period?: number): number;
export declare function calcADX(klines: Kline[], period?: number): {
    adx: number;
    plusDI: number;
    minusDI: number;
};
export declare function calcVolumeProfile(klines: Kline[], periods?: number): {
    avgVolume: number;
    currentVolume: number;
    ratio: number;
    vwap: number;
} | null;
//# sourceMappingURL=indicators.d.ts.map