import React from 'react';
import type { Position } from '../../types/index.js';
interface PositionListProps {
    positions: Position[];
    currentPrice: number;
    onClosePosition: (id: string) => void;
}
export declare const PositionList: React.FC<PositionListProps>;
export {};
//# sourceMappingURL=PositionList.d.ts.map