import React from 'react';
import type { Portfolio } from '../../types/index.js';
interface PortfolioSummaryProps {
    portfolio: Portfolio;
}
export declare const PortfolioSummary: React.FC<PortfolioSummaryProps>;
export {};
//# sourceMappingURL=PortfolioSummary.d.ts.map