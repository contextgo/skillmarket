import React from 'react';
interface PriceHeaderProps {
    price: number;
    change: number;
    lastUpdate: number;
}
export declare const PriceHeader: React.FC<PriceHeaderProps>;
export {};
//# sourceMappingURL=PriceHeader.d.ts.map