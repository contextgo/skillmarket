import React from 'react';
interface ProbabilityBarsProps {
    longProb: number;
    shortProb: number;
}
export declare const ProbabilityBars: React.FC<ProbabilityBarsProps>;
export {};
//# sourceMappingURL=ProbabilityBars.d.ts.map