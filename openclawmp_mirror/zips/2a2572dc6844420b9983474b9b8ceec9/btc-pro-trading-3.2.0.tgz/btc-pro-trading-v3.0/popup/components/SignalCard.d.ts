import React from 'react';
interface SignalCardProps {
    signal: 'LONG' | 'SHORT' | 'WAIT';
    signalStrength: number;
    consensus: number;
}
export declare const SignalCard: React.FC<SignalCardProps>;
export {};
//# sourceMappingURL=SignalCard.d.ts.map