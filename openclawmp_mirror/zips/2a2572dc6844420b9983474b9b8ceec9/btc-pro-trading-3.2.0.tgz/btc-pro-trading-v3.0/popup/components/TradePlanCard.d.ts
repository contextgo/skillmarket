import React from 'react';
import type { TradePlan } from '../../types/index.js';
interface TradePlanCardProps {
    plan: TradePlan;
    onOpenPosition: (side: 'LONG' | 'SHORT') => void;
}
export declare const TradePlanCard: React.FC<TradePlanCardProps>;
export {};
//# sourceMappingURL=TradePlanCard.d.ts.map