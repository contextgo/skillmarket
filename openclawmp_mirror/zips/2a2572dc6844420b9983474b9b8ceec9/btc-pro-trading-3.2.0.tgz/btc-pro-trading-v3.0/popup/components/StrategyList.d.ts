import React from 'react';
import type { StrategyResult } from '../../types/index.js';
interface StrategyListProps {
    strategies: StrategyResult[];
}
export declare const StrategyList: React.FC<StrategyListProps>;
export {};
//# sourceMappingURL=StrategyList.d.ts.map