import React from 'react';
interface TabButtonProps {
    active: boolean;
    onClick: () => void;
    icon: React.ReactNode;
    label: string;
    badge?: number;
}
export declare const TabButton: React.FC<TabButtonProps>;
export {};
//# sourceMappingURL=TabButton.d.ts.map