declare function extractBinanceData(): {
    price: number;
    change: number;
    url: string;
    timestamp: number;
};
declare function injectIndicator(): void;
//# sourceMappingURL=index.d.ts.map