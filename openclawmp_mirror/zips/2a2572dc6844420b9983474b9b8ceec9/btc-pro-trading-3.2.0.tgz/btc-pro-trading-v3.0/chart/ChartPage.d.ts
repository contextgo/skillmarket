export default function ChartPage(): import("react/jsx-runtime").JSX.Element;
//# sourceMappingURL=ChartPage.d.ts.map