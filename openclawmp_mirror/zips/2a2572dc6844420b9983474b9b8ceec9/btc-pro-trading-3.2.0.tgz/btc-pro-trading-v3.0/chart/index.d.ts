import './chart.css';
//# sourceMappingURL=index.d.ts.map