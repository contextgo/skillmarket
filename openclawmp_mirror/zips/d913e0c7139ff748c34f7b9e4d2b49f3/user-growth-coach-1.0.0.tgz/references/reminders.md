# Reminders (建议配置)

## Default Schedule
- 每日 21:30：`复盘`
- 每周日 20:30：`周盘`
- 每月最后一天 21:00：`月盘`

## Reminder Message Style
- 简短、无说教
- 示例：
  - `今天收尾了吗？复盘。`
  - `周盘时间到：进步/失误/下周聚焦。`
  - `月盘：给四维打分并定下月主线。`

## Channel
优先当前聊天渠道（Feishu DM）。

## Execution Note
定时任务建议由 OpenClaw Cron/任务调度配置执行，消息内容只发触发词（如“复盘”），由 Skill 自动展开流程。
