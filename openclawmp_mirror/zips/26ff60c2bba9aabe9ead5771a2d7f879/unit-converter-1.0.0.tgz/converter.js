/**
 * 工程单位换算工具
 */

const CONVERSIONS = {
  // ===== 长度 =====
  length: {
    mm: 1,
    cm: 10,
    m: 1000,
    in: 25.4,
    inch: 25.4,
    mil: 0.0254,
    um: 0.001,
    μm: 0.001
  },
  // ===== 力 =====
  force: {
    N: 1,
    kN: 1000,
    kgf: 9.80665,
    lbf: 4.44822,
    dyn: 0.00001
  },
  // ===== 扭矩 =====
  torque: {
    'N·m': 1,
    'N.m': 1,
    'N*m': 1,
    'kN·m': 1000,
    'kgf·m': 9.80665,
    'kgf·cm': 0.0980665,
    'mN·m': 0.001,
    'lbf·in': 0.1129848,
    'lbf·ft': 1.355818
  },
  // ===== 功率 =====
  power: {
    W: 1,
    kW: 1000,
    MW: 1000000,
    hp: 745.7,
    PS: 735.5,
    mW: 0.001,
    W: 1
  },
  // ===== 压力 =====
  pressure: {
    Pa: 1,
    kPa: 1000,
    MPa: 1000000,
    GPa: 1000000000,
    bar: 100000,
    psi: 6894.76,
    atm: 101325,
    mmHg: 133.322
  },
  // ===== 磁感应强度 =====
  magnetic: {
    T: 1,
    mT: 0.001,
    μT: 0.000001,
    G: 0.0001,
    kG: 0.1,
    Gauss: 0.0001
  },
  // ===== 频率/转速 =====
  frequency: {
    Hz: 1,
    kHz: 1000,
    MHz: 1000000,
    GHz: 1000000000,
    rpm: 1/60,
    'rad/s': 1/(2*Math.PI)
  },
  // ===== 角度 =====
  angle: {
    rad: 1,
    deg: Math.PI/180,
    deg2: Math.PI/180
  },
  // ===== 温度（需要特殊处理）=====
  temperature: 'special'
};

const SPECIAL_TEMP = {
  'C-F': { fn: (v) => v * 9/5 + 32, inv: (v) => (v - 32) * 5/9 },
  'F-C': { fn: (v) => (v - 32) * 5/9, inv: (v) => v * 9/5 + 32 },
  'C-K': { fn: (v) => v + 273.15, inv: (v) => v - 273.15 },
  'K-C': { fn: (v) => v - 273.15, inv: (v) => v + 273.15 },
  'F-K': { fn: (v) => (v - 32) * 5/9 + 273.15, inv: (v) => (v - 273.15) * 9/5 + 32 },
  'K-F': { fn: (v) => (v - 273.15) * 9/5 + 32, inv: (v) => (v - 32) * 5/9 + 273.15 }
};

function convert(value, fromUnit, toUnit) {
  // 温度特殊处理
  if (fromUnit === '℃' || fromUnit === 'C') {
    fromUnit = 'C';
  }
  if (toUnit === '℉' || toUnit === 'F') {
    toUnit = 'F';
  }
  if (fromUnit === 'K' && toUnit === '℃') {
    toUnit = 'C';
  }
  if (fromUnit === '℃' && toUnit === 'K') {
    toUnit = 'C';
  }
  
  const tempKey = `${fromUnit}-${toUnit}`;
  if (SPECIAL_TEMP[tempKey]) {
    return SPECIAL_TEMP[tempKey].fn(value);
  }

  // 查找单位属于哪个类别
  for (const [category, units] of Object.entries(CONVERSIONS)) {
    if (category === 'temperature' || typeof units === 'function') continue;
    if (fromUnit in units && toUnit in units) {
      const base = units[fromUnit];
      const baseVal = value * base;
      return baseVal / units[toUnit];
    }
  }

  // 转速/频率特殊处理
  if (fromUnit === 'rpm' && toUnit === 'rad/s') {
    return value * 2 * Math.PI / 60;
  }
  if (fromUnit === 'rad/s' && toUnit === 'rpm') {
    return value * 60 / (2 * Math.PI);
  }

  throw new Error(`不支持的单位换算: ${fromUnit} → ${toUnit}`);
}

function autoConvert(value, fromUnit) {
  // 智能识别单位并转换
  const results = {};
  for (const [category, units] of Object.entries(CONVERSIONS)) {
    if (category === 'temperature' || typeof units === 'function') continue;
    if (fromUnit in units) {
      for (const [unit, base] of Object.entries(units)) {
        if (unit !== fromUnit) {
          results[unit] = parseFloat((value * units[fromUnit] / base).toFixed(6));
        }
      }
    }
  }
  return results;
}

// CLI
const args = process.argv.slice(2);
if (args.length >= 3) {
  const value = parseFloat(args[0]);
  const from = args[1];
  const to = args[2];
  try {
    const result = convert(value, from, to);
    console.log(`${value} ${from} = ${result.toFixed(6)} ${to}`);
  } catch (e) {
    console.log(`错误: ${e.message}`);
  }
} else if (args.length === 2) {
  const value = parseFloat(args[0]);
  const from = args[1];
  console.log(`\n${value} ${from} 换算为其他单位:`);
  const results = autoConvert(value, from);
  for (const [unit, val] of Object.entries(results)) {
    console.log(`  ${val} ${unit}`);
  }
} else {
  console.log(`用法:
  node converter.js <值> <源单位> <目标单位>
  node converter.js <值> <单位>   (换算为所有常用单位)

示例:
  node converter.js 500 "N·m" "kgf·m"
  node converter.js 1500 rpm "rad/s"
  node converter.js 100 kgf·m
`);
}

module.exports = { convert, autoConvert };
