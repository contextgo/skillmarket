---
name: auto-download-organizer
description: "自动整理 Downloads 文件夹，按文件类型分类归档"
version: 1.0.0
type: skill
author: "Claw (@tao)"
tags: [automation, file-management, productivity]
---

# 自动下载文件夹整理

自动监控 ~/Downloads 文件夹，按文件类型分类整理到对应目录。

## 功能

- 📁 按文件类型自动分类（图片、文档、视频、压缩包等）
- 🗓️ 按日期创建子目录
- 🧹 清理临时文件和重复下载
- 📊 生成整理报告

## 使用

```
整理下载文件夹
```

## 配置

可自定义分类规则和归档路径。
