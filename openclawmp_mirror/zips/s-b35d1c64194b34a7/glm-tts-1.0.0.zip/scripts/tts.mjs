#!/usr/bin/env node

/**
 * GLM 文本转语音
 * 使用智谱AI GLM-TTS API
 */

function usage() {
  console.error(`Usage: tts.mjs "文本" [options]
Options:
  -v <voice>     音色ID (default: shineyue)
  -o <file>      输出文件 (default: output.mp3)
  --speed <n>    语速 0.5-2.0 (default: 1.0)
  --volume <n>   音量 0.1-1.0 (default: 1.0)`);
  process.exit(2);
}

const args = process.argv.slice(2);
if (args.length === 0) usage();

let text = args[0];
let voice = 'shineyue';
let outputFile = 'output.mp3';
let speed = 1.0;
let volume = 1.0;

for (let i = 1; i < args.length; i++) {
  const a = args[i];
  if (a === '-v' && args[i + 1]) {
    voice = args[i + 1];
    i++;
  } else if (a === '-o' && args[i + 1]) {
    outputFile = args[i + 1];
    i++;
  } else if (a === '--speed' && args[i + 1]) {
    speed = parseFloat(args[i + 1]);
    i++;
  } else if (a === '--volume' && args[i + 1]) {
    volume = parseFloat(args[i + 1]);
    i++;
  }
}

const API_KEY = process.env.ZHIPU_API_KEY;
if (!API_KEY) {
  console.error('错误: 请设置 ZHIPU_API_KEY 环境变量');
  process.exit(1);
}

const https = require('https');
const fs = require('fs');

const postData = JSON.stringify({
  model: 'glm-tts',
  input: text,
  voice: voice,
  speed,
  volume
});

const options = {
  hostname: 'open.bigmodel.cn',
  path: '/api/paas/v4/audio generation/speech',
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  }
};

const req = https.request(options, (res) => {
  if (res.statusCode === 200) {
    const file = fs.createWriteStream(outputFile);
    res.pipe(file);
    file.on('finish', () => {
      console.log(`✅ 已保存到: ${outputFile}`);
    });
  } else {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      try {
        const result = JSON.parse(data);
        console.error('错误:', result.error?.message || '未知错误');
      } catch (e) {
        console.error('错误:', data);
      }
      process.exit(1);
    });
  }
});

req.on('error', (e) => {
  console.error('请求错误:', e.message);
  process.exit(1);
});

req.write(postData);
req.end();
