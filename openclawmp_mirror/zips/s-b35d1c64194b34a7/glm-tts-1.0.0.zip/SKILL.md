---
name: glm-tts
displayName: GLM 文本转语音
description: 使用智谱AI GLM-TTS将文本转换为自然语音，支持多种声音、情感控制和语调调整。
homepage: https://open.bigmodel.cn
---

# GLM 文本转语音

> 使用智谱AI GLM-TTS将文本转换为自然语音

## 特点

- 多音色支持
- 情感控制
- 语调调整
- 中文效果优秀

## 环境要求

- Node.js 18+
- 智谱AI API Key

## 认证方式

```bash
export ZHIPU_API_KEY="your-api-key"
```

获取API Key: https://open.bigmodel.cn/usercenter/apikeys

## 使用方法

```bash
node {baseDir}/scripts/tts.mjs "要转换的文本" -v "vivo_tts_clarity"
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `-v` | 音色ID | shineyue (女声) |
| `-o` | 输出文件 | output.mp3 |
| `--speed` | 语速 (0.5-2.0) | 1.0 |
| `--volume` | 音量 (0.1-1.0) | 1.0 |

## 可用音色

| 音色ID | 描述 |
|--------|------|
| shineyue | 讯飞小旭（女声） |
| vivo_tts_clarity | 清晰音质版 |
| t迪亚 | 女声 |
| t迪哥 | 男声 |
| chat_tts | 聊天风格 |

## 示例

```bash
# 基本用法
node {baseDir}/scripts/tts.mjs "你好，这是测试"

# 指定音色
node {baseDir}/scripts/tts.mjs "你好" -v "t迪亚"

# 调整语速
node {baseDir}/scripts/tts.mjs "你好" --speed 1.2

# 保存到文件
node {baseDir}/scripts/tts.mjs "你好" -o hello.mp3
```

---

*基于智谱AI官方TTS API*
