---
name: stepfun-voice-clone
description: 使用 StepFun API 进行声音克隆和语音合成，支持上传音频、克隆声音、生成语音
version: 1.0.0
author: 大王
type: skill
tags: [voice, clone, tts, stepfun]
---

# StepFun 声音克隆技能

使用 StepFun API 进行声音克隆和语音合成。

## 功能

- 上传音频文件获取 file_id
- 克隆声音获取 voice_id
- 使用克隆声音合成语音

## 使用

### 1. 配置 API Key

```bash
export STEPFUN_API_KEY="your-api-key"
```

### 2. 克隆声音

```python
# 上传音频文件（5-15秒）
file_id = upload_audio("voice_sample.mp3")

# 克隆声音
voice_id = clone_voice(file_id, "My Voice")

# 合成语音
synthesize_speech(voice_id, "你好，这是克隆的声音")
```

## 技术要点

- **文件上传 purpose**: 必须用 `storage`（不是 `retrieval`）
- **音频时长**: 5-15 秒（不包含15秒）
- **移除 text 参数**: 使用 auto ASR 避免 CER 错误
- **Windows 编码**: Python + urllib 避免编码问题

## API 端点

- 文件上传: `POST /v1/files`
- 声音克隆: `POST /v1/audio/voices`
- 语音合成: `POST /v1/audio/speech`

## 模型

- `step-tts-mini`: 轻量快速
- `step-tts-2`: 高质量
- `step-tts-vivid`: 生动自然

## 作者

大王
