#!/usr/bin/env python3
"""StepFun 声音克隆工具"""
import urllib.request
import json
import os

API_KEY = os.getenv('STEPFUN_API_KEY')
BASE_URL = 'https://api.stepfun.com/v1'

def upload_audio(filepath):
    """上传音频文件，返回 file_id"""
    with open(filepath, 'rb') as f:
        audio_bytes = f.read()
    
    boundary = '----Boundary' + os.urandom(4).hex()
    
    body = (
        f'--{boundary}\r\n'
        f'Content-Disposition: form-data; name="purpose"\r\n\r\n'
        f'storage\r\n'  # 关键：必须用 storage
        f'--{boundary}\r\n'
        f'Content-Disposition: form-data; name="file"; filename="voice.mp3"\r\n'
        f'Content-Type: audio/mpeg\r\n\r\n'
    ).encode('utf-8') + audio_bytes + (
        f'\r\n--{boundary}--\r\n'
    ).encode('utf-8')
    
    req = urllib.request.Request(
        f'{BASE_URL}/files',
        data=body,
        headers={
            'Authorization': f'Bearer {API_KEY}',
            'Content-Type': f'multipart/form-data; boundary={boundary}'
        },
        method='POST'
    )
    
    with urllib.request.urlopen(req) as response:
        result = json.loads(response.read().decode('utf-8'))
        return result['id']

def clone_voice(file_id, voice_name):
    """克隆声音，返回 voice_id"""
    payload = {
        "model": "step-tts-mini",
        "voice_name": voice_name,
        "file_id": file_id
        # 注意：不要加 text 参数，用 auto ASR
    }
    
    json_data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    
    req = urllib.request.Request(
        f'{BASE_URL}/audio/voices',
        data=json_data,
        headers={
            'Authorization': f'Bearer {API_KEY}',
            'Content-Type': 'application/json'
        },
        method='POST'
    )
    
    with urllib.request.urlopen(req) as response:
        result = json.loads(response.read().decode('utf-8'))
        return result['id']

def synthesize_speech(voice_id, text, output_path="output.mp3"):
    """使用克隆声音合成语音"""
    payload = {
        "model": "step-tts-mini",
        "input": text,
        "voice": voice_id,
        "response_format": "mp3"
    }
    
    json_data = json.dumps(payload, ensure_ascii=False).encode('utf-8')
    
    req = urllib.request.Request(
        f'{BASE_URL}/audio/speech',
        data=json_data,
        headers={
            'Authorization': f'Bearer {API_KEY}',
            'Content-Type': 'application/json'
        },
        method='POST'
    )
    
    with urllib.request.urlopen(req) as response:
        audio_data = response.read()
        with open(output_path, 'wb') as f:
            f.write(audio_data)
        return len(audio_data)

if __name__ == '__main__':
    # 示例用法
    print("StepFun 声音克隆工具")
    print("1. 准备 5-15 秒的音频文件")
    print("2. 设置 STEPFUN_API_KEY 环境变量")
    print("3. 调用 upload_audio() → clone_voice() → synthesize_speech()")
