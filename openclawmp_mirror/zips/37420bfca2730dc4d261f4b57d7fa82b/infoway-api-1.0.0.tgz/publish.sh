#!/bin/bash
# Infoway API 技能发布脚本

echo "🐟 开始发布 Infoway API 技能到水产市场..."
echo ""

# 检查 manifest.json
if [ ! -f "manifest.json" ]; then
    echo "❌ manifest.json 不存在"
    exit 1
fi

echo "✅ manifest.json 存在"
cat manifest.json | head -15
echo ""

# 检查 SKILL.md
if [ ! -f "SKILL.md" ]; then
    echo "❌ SKILL.md 不存在"
    exit 1
fi

echo "✅ SKILL.md 存在"
head -5 SKILL.md
echo ""

# 尝试发布
echo "🚀 开始发布..."
echo "Y" | openclawmp publish ./

echo ""
echo "📋 发布完成！"
echo ""
echo "如果发布失败，请:"
echo "1. 访问 https://openclawmp.cc"
echo "2. 登录账号"
echo "3. 在设备上完成授权"
echo "4. 再次运行此脚本"
