# Infoway API 文档索引

## 官方文档

- [Infoway API 文档首页](https://docs.infoway.io)
- [A 股实时行情接口](https://docs.infoway.io/readme/china-a-shares-realtime-market-data-api)
- [港股实时行情接口](https://docs.infoway.io/readme/hong-kong-realtime-market-data-api)
- [美股实时行情接口](https://docs.infoway.io/readme/usa-realtime-market-data-api)

## REST API

### 基础信息
- [GET 查询产品列表](https://docs.infoway.io/rest-api/basic-info/get-symbol-list)
- [GET 获取产品基础信息](https://docs.infoway.io/rest-api/basic-info/get-symbol-basic-info)
- [GET 获取市场交易日信息](https://docs.infoway.io/rest-api/basic-info/get-market-trading-days)
- [GET 获取市场交易时间](https://docs.infoway.io/rest-api/basic-info/get-market-trading-hours)

### 行情数据
- [POST 获取历史/实时 K 线](https://docs.infoway.io/rest-api/http-endpoints/get-candles)
- [GET 实时成交明细](https://docs.infoway.io/rest-api/http-endpoints/get-trade)
- [GET 实时买卖盘口](https://docs.infoway.io/rest-api/http-endpoints/get-depth)

## WebSocket API

- [WebSocket 订阅地址说明](https://docs.infoway.io/websocket-api/endpoints)
- [WebSocket 代码示例](https://docs.infoway.io/websocket-api/code-examples)
- [实时成交明细订阅](https://docs.infoway.io/websocket-api/subscribe-and-unsubscribe/trade-subscribe)
- [实时 K 线订阅](https://docs.infoway.io/websocket-api/subscribe-and-unsubscribe/candles-subscribe)
- [实时买卖盘口订阅](https://docs.infoway.io/websocket-api/subscribe-and-unsubscribe/depth-subscribe)

## 接入流程

1. [快速开始](https://docs.infoway.io/getting-started/quick-start)
2. [API Key 申请](https://docs.infoway.io/getting-started/api-key-application)
3. [接口限制说明](https://docs.infoway.io/getting-started/api-limitation)
4. [错误码说明](https://docs.infoway.io/getting-started/error-codes)

## 接口地址

### 股票 (A 股/港股/美股)
```
https://data.infoway.io/stock/v2/batch_kline
https://data.infoway.io/stock/v2/trade
https://data.infoway.io/stock/v2/depth
```

### 加密货币
```
https://data.infoway.io/crypto/v2/batch_kline
```

### 外汇/商品/期货
```
https://data.infoway.io/common/v2/batch_kline
```

## 请求头

```json
{
  "apiKey": "your_api_key_here"
}
```

## 响应格式

```json
{
  "ret": 200,
  "msg": "success",
  "traceId": "xxx",
  "data": [...]
}
```

## 错误码

| 错误码 | 说明 |
|--------|------|
| 200 | 成功 |
| 400 | 参数错误 |
| 401 | API Key 无效 |
| 429 | 请求频率超限 |
| 500 | 服务器错误 |
