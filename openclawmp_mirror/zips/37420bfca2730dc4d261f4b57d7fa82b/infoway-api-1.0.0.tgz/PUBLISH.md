# 🐟 Infoway API 技能发布说明

## ✅ 发布准备完成

**技能目录**: `/root/.openclaw/skills/infoway-api/`

**包含文件**:
- ✅ SKILL.md (已修复 frontmatter 格式)
- ✅ manifest.json (schema v1)
- ✅ README.md
- ✅ scripts/ (4 个 Python 脚本)
- ✅ references/ (API 文档)

---

## ⚠️ 发布失败原因

**错误**: `HTTP 400: Invalid metadata JSON`

**根本原因**: **设备未认证**

虽然你说已经绑定设备了，但系统仍然显示：
```
Auth Token: not configured
```

---

## 🔧 解决方案

### 方案 1: 网页发布（推荐 ⭐）

1. **访问**: https://openclawmp.cc
2. **登录**: GitHub/Google 账号
3. **点击**: "发布资产" 或 "Publish"
4. **上传**: 整个 `infoway-api/` 目录
5. **填写信息**:
   ```
   名称：infoway-api
   显示名：Infoway API 金融数据查询
   类型：skill
   版本：1.0.0
   描述：Infoway API 金融数据查询工具。支持 A 股/港股/美股/外汇/加密货币/期货的实时行情、K 线、盘口数据查询。
   标签：finance, stock, crypto, forex, infoway
   分类：金融
   ```
6. **提交**

---

### 方案 2: 完成设备认证后再发布

#### 步骤 1: 验证设备状态
```bash
openclawmp whoami
```

应该显示：
```
Auth Token: xxxxxx (不是 not configured)
```

#### 步骤 2: 如果未认证，访问网页授权
1. 访问 https://openclawmp.cc
2. 登录后进入"设备管理"
3. 找到设备 ID: `69adc12c63ff...`
4. 点击"授权"

#### 步骤 3: 再次发布
```bash
cd /root/.openclaw/skills/infoway-api
openclawmp publish ./
```

---

## 📦 技能元数据

```json
{
  "schema": 1,
  "type": "skill",
  "name": "infoway-api",
  "displayName": "Infoway API 金融数据查询",
  "version": "1.0.0",
  "author": "Mateo Lim",
  "description": "Infoway API 金融数据查询工具。支持 A 股/港股/美股/外汇/加密货币/期货的实时行情、K 线、盘口数据查询。",
  "tags": ["finance", "stock", "crypto", "forex", "infoway"],
  "category": "金融",
  "hasPackage": true
}
```

---

## 📋 SKILL.md Frontmatter

```yaml
---
name: infoway-api
description: Infoway API 金融数据查询工具。支持 A 股/港股/美股/外汇/加密货币/期货的实时行情、K 线、盘口数据查询。
---
```

---

## ✅ 已修复的问题

1. ✅ 移除 SKILL.md 中的 metadata 字段（应该放在 manifest.json）
2. ✅ 移除 SKILL.md 中的 license 字段
3. ✅ 简化 description（移除多行格式）
4. ✅ 移除 category 中的斜杠（`金融/数据` → `金融`）
5. ✅ 移除 manifest.json 中的 license 字段
6. ✅ 移除 manifest.json 中的 authorId 字段

---

## 🎯 下一步

**推荐**: 直接访问 https://openclawmp.cc 网页发布

**或者**: 
1. 确认设备已授权（`openclawmp whoami` 显示 Auth Token）
2. 再次执行 `openclawmp publish ./`

---

**创建时间**: 2026-03-10 16:18  
**技能版本**: 1.0.0  
**作者**: Mateo Lim
