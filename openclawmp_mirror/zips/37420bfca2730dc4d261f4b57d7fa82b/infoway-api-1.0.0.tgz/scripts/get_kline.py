#!/usr/bin/env python3
"""
Infoway API - 获取 K 线数据
用法：python get_kline.py <股票代码> [--type <K 线类型>] [--num <数量>]
"""

import requests
import json
import time
import sys
import os

# 配置
API_KEY = os.environ.get('INFOWAY_API_KEY', '')
BASE_URL = 'https://data.infoway.io/stock/v2/batch_kline'

def load_api_key():
    """从 TOOLS.md 加载 API Key"""
    if API_KEY:
        return API_KEY
    
    tools_path = os.path.expanduser('~/.openclaw/workspace/TOOLS.md')
    if os.path.exists(tools_path):
        with open(tools_path, 'r', encoding='utf-8') as f:
            content = f.read()
            if 'Infoway API' in content:
                for line in content.split('\n'):
                    if 'API Key:' in line and '-' not in line.split('API Key:')[0]:
                        key = line.split('API Key:')[1].strip()
                        if '...' not in key:  # 跳过脱敏的 key
                            return key
    return ''

def get_kline(symbol, kline_type=1, kline_num=5):
    """
    获取 K 线数据
    
    Args:
        symbol: 股票代码 (如 002594.SZ, TSLA.US)
        kline_type: K 线类型 (1=1 分钟，8=日 K，9=周 K，10=月 K)
        kline_num: 获取数量 (最多 500)
    
    Returns:
        dict: K 线数据
    """
    api_key = load_api_key()
    if not api_key:
        print("❌ 错误：未找到 Infoway API Key，请在 TOOLS.md 中配置")
        return None
    
    # 根据股票代码判断市场
    if '.US' in symbol:
        url = 'https://data.infoway.io/stock/v2/batch_kline'
    elif '.SZ' in symbol or '.SH' in symbol:
        url = 'https://data.infoway.io/stock/v2/batch_kline'
    elif '.HK' in symbol:
        url = 'https://data.infoway.io/stock/v2/batch_kline'
    else:
        url = 'https://data.infoway.io/common/v2/batch_kline'
    
    headers = {
        'apiKey': api_key,
        'Content-Type': 'application/json'
    }
    
    payload = {
        'klineType': kline_type,
        'klineNum': kline_num,
        'codes': symbol
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            if data.get('ret') == 200:
                return data
            else:
                print(f"❌ API 返回错误：{data.get('msg')}")
                return None
        else:
            print(f"❌ HTTP 错误：{response.status_code}")
            print(f"响应：{response.text[:200]}")
            return None
            
    except Exception as e:
        print(f"❌ 请求失败：{e}")
        return None

def format_kline(kline_data):
    """格式化 K 线数据输出"""
    if not kline_data or not kline_data.get('data'):
        return
    
    print("\n" + "=" * 70)
    print(f"📊 {kline_data['data'][0]['s']} K 线数据")
    print("=" * 70)
    
    for item in kline_data['data']:
        symbol = item.get('s')
        print(f"\n股票代码：{symbol}")
        print("-" * 70)
        
        if item.get('respList'):
            # 反转列表，从旧到新
            resp_list = item['respList'][::-1]
            
            print(f"{'时间':<20} {'开盘':>10} {'最高':>10} {'最低':>10} {'收盘':>10} {'成交量':>12} {'涨跌幅':>10}")
            print("-" * 70)
            
            for kline in resp_list:
                timestamp = int(kline['t'])
                time_str = time.strftime('%Y-%m-%d %H:%M', time.localtime(timestamp))
                
                print(f"{time_str:<20} "
                      f"{float(kline['o']):>10.2f} "
                      f"{float(kline['h']):>10.2f} "
                      f"{float(kline['l']):>10.2f} "
                      f"{float(kline['c']):>10.2f} "
                      f"{int(float(kline['v'])):>12} "
                      f"{kline['pc']:>10}")
    
    print("=" * 70)

def main():
    if len(sys.argv) < 2:
        print("用法：python get_kline.py <股票代码> [--type <K 线类型>] [--num <数量>]")
        print("\n示例:")
        print("  python get_kline.py 002594.SZ                    # 比亚迪 1 分钟 K 线 (5 根)")
        print("  python get_kline.py TSLA.US --type 8 --num 30   # 特斯拉日 K 线 (30 根)")
        print("  python get_kline.py 600519.SH --type 8          # 茅台日 K 线")
        print("\nK 线类型:")
        print("  1=1 分钟，2=5 分钟，3=15 分钟，4=30 分钟")
        print("  5=1 小时，6=2 小时，7=4 小时，8=日 K，9=周 K，10=月 K")
        sys.exit(1)
    
    symbol = sys.argv[1]
    kline_type = 1
    kline_num = 5
    
    # 解析参数
    i = 2
    while i < len(sys.argv):
        if sys.argv[i] == '--type' and i + 1 < len(sys.argv):
            kline_type = int(sys.argv[i + 1])
            i += 2
        elif sys.argv[i] == '--num' and i + 1 < len(sys.argv):
            kline_num = int(sys.argv[i + 1])
            i += 2
        else:
            i += 1
    
    print(f"🔍 正在获取 {symbol} 的 K 线数据...")
    data = get_kline(symbol, kline_type, kline_num)
    
    if data:
        format_kline(data)
        
        # 返回 JSON 格式供程序使用
        print("\n📄 JSON 数据:")
        print(json.dumps(data, indent=2, ensure_ascii=False))

if __name__ == '__main__':
    main()
