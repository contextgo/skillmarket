#!/usr/bin/env python3
"""
Infoway API - 快速查询工具
用法：python query.py <股票代码>
"""

import sys
import os

# 添加脚本路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from get_kline import get_kline, format_kline
from get_depth import get_depth, format_depth

def quick_query(symbol):
    """快速查询股票信息"""
    print(f"\n🔍 查询 {symbol} 的行情信息...\n")
    
    # 1. 获取最新 K 线
    print("=" * 70)
    print("📊 最新行情")
    print("=" * 70)
    kline_data = get_kline(symbol, kline_type=1, kline_num=1)
    if kline_data and kline_data.get('data'):
        item = kline_data['data'][0]
        if item.get('respList'):
            latest = item['respList'][0]
            print(f"股票代码：{item['s']}")
            print(f"最新价：  ¥{float(latest['c']):.2f}")
            print(f"涨跌幅：  {latest['pc']} ({latest['pca']})")
            print(f"成交量：  {int(float(latest['v']))} 手")
            print(f"成交额：  ¥{float(latest['vw']):,.2f}")
    
    # 2. 获取五档盘口
    print("\n" + "=" * 70)
    print("📈 五档盘口")
    print("=" * 70)
    depth_data = get_depth(symbol)
    if depth_data and depth_data.get('data'):
        format_depth(depth_data)
    
    print("\n✅ 查询完成")

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print("用法：python query.py <股票代码>")
        print("\n示例:")
        print("  python query.py 002594.SZ    # 比亚迪")
        print("  python query.py 600519.SH    # 贵州茅台")
        print("  python query.py TSLA.US      # 特斯拉")
        sys.exit(1)
    
    quick_query(sys.argv[1])
