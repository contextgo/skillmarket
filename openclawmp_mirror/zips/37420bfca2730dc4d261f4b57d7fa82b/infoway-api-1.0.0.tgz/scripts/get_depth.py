#!/usr/bin/env python3
"""
Infoway API - 获取五档盘口数据
用法：python get_depth.py <股票代码>
"""

import requests
import json
import sys
import os

API_KEY = os.environ.get('INFOWAY_API_KEY', '')

def load_api_key():
    """从 TOOLS.md 加载 API Key"""
    if API_KEY:
        return API_KEY
    
    tools_path = os.path.expanduser('~/.openclaw/workspace/TOOLS.md')
    if os.path.exists(tools_path):
        with open(tools_path, 'r', encoding='utf-8') as f:
            content = f.read()
            if 'Infoway API' in content:
                for line in content.split('\n'):
                    if 'API Key:' in line and '-' not in line.split('API Key:')[0]:
                        key = line.split('API Key:')[1].strip()
                        if '...' not in key:
                            return key
    return ''

def get_depth(symbol):
    """获取五档盘口数据"""
    api_key = load_api_key()
    if not api_key:
        print("❌ 错误：未找到 Infoway API Key")
        return None
    
    # 盘口 API 路径
    url = 'https://data.infoway.io/stock/v2/quote/depth'
    headers = {'apiKey': api_key}
    params = {'code': symbol}
    
    try:
        response = requests.get(url, headers=headers, params=params, timeout=10)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"❌ HTTP 错误：{response.status_code}")
            return None
    except Exception as e:
        print(f"❌ 请求失败：{e}")
        return None

def format_depth(depth_data):
    """格式化盘口数据输出"""
    if not depth_data or not depth_data.get('data'):
        return
    
    print("\n" + "=" * 50)
    print(f"📊 {depth_data['data']['s']} 五档盘口")
    print("=" * 50)
    
    data = depth_data['data']
    
    # 卖盘 (b)
    if data.get('b'):
        print("\n🔴 卖盘 (Ask)")
        print(f"{'档位':<8} {'价格':>12} {'数量':>12}")
        print("-" * 35)
        for i, (price, vol) in enumerate(zip(data['b'][0], data['b'][1]), 1):
            print(f"卖{i:<7} {float(price):>12.2f} {int(float(vol)):>12}")
    
    # 买盘 (a)
    if data.get('a'):
        print("\n🟢 买盘 (Bid)")
        print(f"{'档位':<8} {'价格':>12} {'数量':>12}")
        print("-" * 35)
        for i, (price, vol) in enumerate(zip(data['a'][0], data['a'][1]), 1):
            print(f"买{i:<7} {float(price):>12.2f} {int(float(vol)):>12}")
    
    print("=" * 50)

def main():
    if len(sys.argv) < 2:
        print("用法：python get_depth.py <股票代码>")
        print("\n示例:")
        print("  python get_depth.py 600519.SH")
        print("  python get_depth.py TSLA.US")
        sys.exit(1)
    
    symbol = sys.argv[1]
    print(f"🔍 正在获取 {symbol} 的五档盘口...")
    
    data = get_depth(symbol)
    if data and data.get('ret') == 200:
        format_depth(data)
        print("\n📄 JSON 数据:")
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print("❌ 获取失败")

if __name__ == '__main__':
    main()
