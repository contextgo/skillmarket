#!/usr/bin/env python3
"""
Infoway API - 获取实时成交数据
用法：python get_trade.py <股票代码>
"""

import requests
import json
import time
import sys
import os

API_KEY = os.environ.get('INFOWAY_API_KEY', '')

def load_api_key():
    """从 TOOLS.md 加载 API Key"""
    if API_KEY:
        return API_KEY
    
    tools_path = os.path.expanduser('~/.openclaw/workspace/TOOLS.md')
    if os.path.exists(tools_path):
        with open(tools_path, 'r', encoding='utf-8') as f:
            content = f.read()
            if 'Infoway API' in content:
                for line in content.split('\n'):
                    if 'API Key:' in line and '-' not in line.split('API Key:')[0]:
                        key = line.split('API Key:')[1].strip()
                        if '...' not in key:
                            return key
    return ''

def get_trade(symbol):
    """获取实时成交数据"""
    api_key = load_api_key()
    if not api_key:
        print("❌ 错误：未找到 Infoway API Key")
        return None
    
    url = 'https://data.infoway.io/stock/v2/trade'
    headers = {'apiKey': api_key}
    params = {'code': symbol}
    
    try:
        response = requests.get(url, headers=headers, params=params, timeout=10)
        if response.status_code == 200:
            return response.json()
        else:
            print(f"❌ HTTP 错误：{response.status_code}")
            return None
    except Exception as e:
        print(f"❌ 请求失败：{e}")
        return None

def main():
    if len(sys.argv) < 2:
        print("用法：python get_trade.py <股票代码>")
        print("\n示例:")
        print("  python get_trade.py 002594.SZ")
        print("  python get_trade.py TSLA.US")
        sys.exit(1)
    
    symbol = sys.argv[1]
    print(f"🔍 正在获取 {symbol} 的实时成交数据...")
    
    data = get_trade(symbol)
    if data and data.get('ret') == 200:
        print(f"\n✅ 成功获取 {symbol} 成交数据")
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print("❌ 获取失败")

if __name__ == '__main__':
    main()
