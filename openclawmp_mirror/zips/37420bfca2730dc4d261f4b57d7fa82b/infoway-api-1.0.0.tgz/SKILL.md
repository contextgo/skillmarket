---
name: infoway-api
description: Infoway API 金融数据查询工具。支持 A 股/港股/美股/外汇/加密货币/期货的实时行情、K 线、盘口数据查询。
---

# Infoway API Skill

基于 Infoway API 的全球金融市场实时行情查询工具。

## 快速开始

### 1. 配置 API Key

在 `TOOLS.md` 中添加：

```markdown
## API Tokens

### Infoway API
- API Key: your_api_key_here
- 用途：A 股/港股/美股/外汇/加密货币/期货实时行情
```

### 2. 使用方式

```python
# 查询 A 股 K 线
python scripts/get_kline.py 002594.SZ

# 查询美股行情
python scripts/get_quote.py TSLA.US

# 查询五档盘口
python scripts/get_depth.py 600519.SH
```

## 支持的市场

| 市场 | 代码后缀 | 示例 |
|------|---------|------|
| A 股 | `.SZ` / `.SH` | `002594.SZ` (比亚迪), `600519.SH` (茅台) |
| 港股 | `.HK` | `0700.HK` (腾讯), `9988.HK` (阿里) |
| 美股 | `.US` | `TSLA.US` (特斯拉), `AAPL.US` (苹果) |
| 加密货币 | 直接代码 | `BTCUSDT`, `ETHUSDT` |
| 外汇 | 直接代码 | `EURUSD`, `USDCNY` |
| 期货 | 直接代码 | `CL` (原油), `GC` (黄金) |

## 支持的接口

### 1. K 线数据 (Candles)

**脚本**: `scripts/get_kline.py`

**支持周期**:
- 1: 1 分钟 K
- 2: 5 分钟 K
- 3: 15 分钟 K
- 4: 30 分钟 K
- 5: 1 小时 K
- 6: 2 小时 K
- 7: 4 小时 K
- 8: 日 K
- 9: 周 K
- 10: 月 K

**示例**:
```bash
# 查询比亚迪 1 分钟 K 线（5 根）
python scripts/get_kline.py 002594.SZ --type 1 --num 5

# 查询特斯拉日 K 线（30 根）
python scripts/get_kline.py TSLA.US --type 8 --num 30
```

### 2. 实时成交 (Trade)

**脚本**: `scripts/get_trade.py`

**示例**:
```bash
python scripts/get_trade.py 002594.SZ
```

### 3. 五档盘口 (Depth)

**脚本**: `scripts/get_depth.py`

**示例**:
```bash
python scripts/get_depth.py 600519.SH
```

### 4. 基础信息 (Basic Info)

**脚本**: `scripts/get_info.py`

**示例**:
```bash
python scripts/get_info.py AAPL.US
```

## 返回数据说明

### K 线数据

```json
{
  "s": "002594.SZ",
  "respList": [
    {
      "t": "1773125400",      // 秒时间戳
      "o": "96.600",         // 开盘价
      "h": "96.600",         // 最高价
      "l": "96.600",         // 最低价
      "c": "96.600",         // 收盘价
      "v": "8292",           // 成交量
      "vw": "801007.20",     // 成交额
      "pc": "-0.01%",        // 涨跌幅
      "pca": "-0.010"        // 涨跌额
    }
  ]
}
```

### 盘口数据

```json
{
  "s": "600519.SH",
  "a": [
    ["96.61", "96.62"],  // 买一价、买二价...
    ["100", "200"]        // 买一量、买二量...
  ],
  "b": [
    ["96.60", "96.59"],  // 卖一价、卖二价...
    ["150", "300"]        // 卖一量、卖二量...
  ]
}
```

## 错误处理

| 错误码 | 说明 | 处理方式 |
|--------|------|----------|
| 200 | 成功 | - |
| 400 | 参数错误 | 检查请求参数 |
| 401 | API Key 无效 | 检查 TOOLS.md 配置 |
| 429 | 请求频率超限 | 等待后重试 |
| 500 | 服务器错误 | 稍后重试 |

## 频率限制

根据你的套餐等级有不同的频率限制：
- 免费版：约 10 次/分钟
- 付费版：更高频率

详细限制见：[接口限制说明](https://docs.infoway.io/getting-started/api-limitation)

## 参考资料

- [官方文档](https://docs.infoway.io)
- [A 股行情接口](https://docs.infoway.io/readme/china-a-shares-realtime-market-data-api)
- [K 线接口](https://docs.infoway.io/rest-api/http-endpoints/get-candles)
- [成交接口](https://docs.infoway.io/rest-api/http-endpoints/get-trade)
- [盘口接口](https://docs.infoway.io/rest-api/http-endpoints/get-depth)
