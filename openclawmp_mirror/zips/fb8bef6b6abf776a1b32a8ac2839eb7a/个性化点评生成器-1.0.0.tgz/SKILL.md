---
name: 个性化点评生成器
displayName: 个性化点评生成器
description: 根据学生测试成绩和表现，生成个性化点评，鼓励为主，指出改进方向。
version: 1.0.0
author: OpenClaw Edu
tags: [education, feedback, student, evaluation, teaching]
category: education
---

# 个性化点评生成器

生成学生个性化点评。

## 功能

- 成绩分析
- 薄弱环节识别
- 生成鼓励性点评
- 指出改进方向
- Excel批量输出

## 使用

```
@个性化点评生成器 根据这份成绩表为每个学生生成点评
```
