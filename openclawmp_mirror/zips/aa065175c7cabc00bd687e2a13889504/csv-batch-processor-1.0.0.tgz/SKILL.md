---
name: csv-batch-processor
description: CSV批量处理工具 | 批量合并、分割、筛选、去重CSV文件，支持Excel互转和编码转换
---

# CSV批量处理工具

高效处理CSV文件的命令行工具，支持批量合并、分割、去重、筛选、格式转换、编码处理。

## 适用场景

- 多供应商报价单合并
- 实验数据批量整理
- 质量检验记录汇总
- 报表数据预处理
- Excel文件批量转CSV

## 核心功能

| 功能 | 说明 | 示例 |
|------|------|------|
| 合并 | 多个CSV按行合并 | 合并多个供应商报价单 |
| 分割 | 按行数或条件分割 | 大文件拆分为小文件 |
| 去重 | 按指定列去重 | 去除重复订单记录 |
| 筛选 | 按条件过滤行 | 筛选特定供应商数据 |
| 格式转换 | CSV↔Excel互转 | 将xlsx转csv |
| 编码转换 | UTF-8/GBK互转 | 解决中文乱码 |
| 汇总统计 | 按列分组求和/计数 | 统计各供应商总额 |

## 使用方法

### 命令行调用

```powershell
# 合并CSV
csv-processor merge -i "C:\data\*.csv" -o "C:\output\merged.csv"

# 按列去重
csv-processor dedup -i "input.csv" -o "output.csv" -k "订单号"

# 筛选数据
csv-processor filter -i "input.csv" -o "output.csv" -c "供应商" -v "国产A"

# Excel转CSV
csv-processor xlsx2csv -i "input.xlsx" -o "output.csv"

# CSV转Excel
csv-processor csv2xlsx -i "input.csv" -o "output.xlsx"

# 编码转换（解决乱码）
csv-processor encode -i "input.csv" -o "output.csv" -from "GBK" -to "UTF-8"
```

### 对话式调用

```
用户：帮我把 D:\data 文件夹下所有CSV合并成一个文件，去除重复行，按"日期"列排序

用户：筛选出所有供应商为"华阳"的记录，导出到新文件

用户：这批CSV文件打开乱码，应该是GBK编码，转成UTF-8
```

## 输出格式

- 保持原始列顺序不变
- 保留表头行
- 编码默认UTF-8
- 数字列不做多余格式化

## 依赖要求

- Node.js（用于JS版本）
- 或 PowerShell 5.0+（内置版本）

## 示例：电机供应商报价汇总

1. 收集多家供应商报价CSV
2. 使用 `merge` 合并所有报价单
3. 使用 `dedup -k 物料编号` 去除重复物料
4. 使用 `filter -c 供应商 -v 华阳` 筛选目标供应商
5. 汇总结果用于比价分析
