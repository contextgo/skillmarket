/**
 * CSV批量处理工具
 * 支持：合并、分割、去重、筛选、格式转换、编码转换
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// ============ 核心处理函数 ============

/**
 * 读取CSV文件
 */
function readCSV(filePath, options = {}) {
  const { encoding = 'utf8', delimiter = ',' } = options;
  const content = fs.readFileSync(filePath, { encoding });
  const lines = content.split(/\r?\n/).filter(l => l.trim());
  if (lines.length === 0) return { headers: [], rows: [] };
  
  const headers = parseCSVLine(lines[0], delimiter);
  const rows = lines.slice(1).map(line => parseCSVLine(line, delimiter));
  
  return { headers, rows };
}

/**
 * 解析CSV行（处理引号包裹的字段）
 */
function parseCSVLine(line, delimiter = ',') {
  const result = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === delimiter && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

/**
 * 写入CSV文件
 */
function writeCSV(filePath, data, options = {}) {
  const { encoding = 'utf8', delimiter = ',', headers } = options;
  let content = '';
  
  if (headers) {
    content += headers.join(delimiter) + '\n';
  }
  
  data.forEach(row => {
    content += row.map(cell => {
      const str = String(cell ?? '');
      return str.includes(delimiter) || str.includes('"') || str.includes('\n')
        ? `"${str.replace(/"/g, '""')}"`
        : str;
    }).join(delimiter) + '\n';
  });
  
  fs.writeFileSync(filePath, content, { encoding });
}

/**
 * 合并多个CSV文件
 */
function mergeCSV(inputPaths, outputPath, options = {}) {
  const { delimiter = ',', keepHeaders = true } = options;
  const allRows = [];
  let allHeaders = null;
  
  inputPaths.forEach((filePath, idx) => {
    try {
      const { headers, rows } = readCSV(filePath, { delimiter });
      if (idx === 0) {
        allHeaders = headers;
      }
      if (keepHeaders && idx > 0) {
        // 跳过后续文件的表头
        allRows.push(...rows);
      } else {
        allRows.push(...rows);
      }
      console.log(`✅ 已合并: ${path.basename(filePath)} (${rows.length} 行)`);
    } catch (e) {
      console.error(`❌ 读取失败: ${filePath} - ${e.message}`);
    }
  });
  
  if (allHeaders) {
    writeCSV(outputPath, allRows, { delimiter, headers: allHeaders });
    console.log(`✅ 合并完成: ${outputPath} (共 ${allRows.length} 行)`);
  }
}

/**
 * 按列去重
 */
function dedupCSV(inputPath, outputPath, keyColumn, options = {}) {
  const { delimiter = ',' } = options;
  const { headers, rows } = readCSV(inputPath, { delimiter });
  
  const keyIdx = headers.indexOf(keyColumn);
  if (keyIdx === -1) {
    throw new Error(`找不到列 "${keyColumn}"，可用列：${headers.join(', ')}`);
  }
  
  const seen = new Set();
  const uniqueRows = [];
  
  rows.forEach(row => {
    const key = row[keyIdx];
    if (!seen.has(key)) {
      seen.add(key);
      uniqueRows.push(row);
    }
  });
  
  writeCSV(outputPath, uniqueRows, { delimiter, headers });
  console.log(`✅ 去重完成: ${path.basename(outputPath)} (原始 ${rows.length} 行 → 去重后 ${uniqueRows.length} 行)`);
  return { original: rows.length, unique: uniqueRows.length };
}

/**
 * 按条件筛选
 */
function filterCSV(inputPath, outputPath, column, value, options = {}) {
  const { delimiter = ',' } = options;
  const { headers, rows } = readCSV(inputPath, { delimiter });
  
  const colIdx = headers.indexOf(column);
  if (colIdx === -1) {
    throw new Error(`找不到列 "${column}"，可用列：${headers.join(', ')}`);
  }
  
  const filtered = rows.filter(row => {
    const cell = String(row[colIdx] ?? '');
    return cell.includes(value);
  });
  
  writeCSV(outputPath, filtered, { delimiter, headers });
  console.log(`✅ 筛选完成: ${path.basename(outputPath)} (匹配 ${filtered.length} 行)`);
  return { total: rows.length, matched: filtered.length };
}

/**
 * 按列排序
 */
function sortCSV(inputPath, outputPath, sortColumn, options = {}) {
  const { delimiter = ',', descending = false } = options;
  const { headers, rows } = readCSV(inputPath, { delimiter });
  
  const colIdx = headers.indexOf(sortColumn);
  if (colIdx === -1) {
    throw new Error(`找不到列 "${sortColumn}"`);
  }
  
  const sorted = [...rows].sort((a, b) => {
    const va = a[colIdx] ?? '';
    const vb = b[colIdx] ?? '';
    const cmp = va.localeCompare(vb, 'zh-CN');
    return descending ? -cmp : cmp;
  });
  
  writeCSV(outputPath, sorted, { delimiter, headers });
  console.log(`✅ 排序完成: ${path.basename(outputPath)}`);
}

/**
 * 按列分组统计
 */
function summarizeCSV(inputPath, groupColumn, sumColumn, options = {}) {
  const { delimiter = ',' } = options;
  const { headers, rows } = readCSV(inputPath, { delimiter });
  
  const groupIdx = headers.indexOf(groupColumn);
  const sumIdx = headers.indexOf(sumColumn);
  
  if (groupIdx === -1 || sumIdx === -1) {
    throw new Error(`找不到指定列`);
  }
  
  const groups = {};
  rows.forEach(row => {
    const key = row[groupIdx] ?? '(空)';
    const val = parseFloat(row[sumIdx]) || 0;
    groups[key] = (groups[key] || 0) + val;
  });
  
  console.log(`\n📊 分组统计 (按 "${groupColumn}" 汇总 "${sumColumn}"):`);
  Object.entries(groups)
    .sort((a, b) => b[1] - a[1])
    .forEach(([key, sum]) => {
      console.log(`  ${key}: ${sum.toFixed(2)}`);
    });
  
  return groups;
}

/**
 * Excel转CSV (需要exceljs或xlsx库)
 */
function xlsx2csv(inputPath, outputPath) {
  try {
    const xlsx = require('xlsx');
    const workbook = xlsx.readFile(inputPath);
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const data = xlsx.utils.sheet_to_csv(sheet);
    fs.writeFileSync(outputPath, data, 'utf8');
    console.log(`✅ Excel转CSV完成: ${path.basename(outputPath)}`);
  } catch (e) {
    if (e.code === 'MODULE_NOT_FOUND') {
      console.error('❌ 需要安装xlsx库: npm install xlsx');
    } else {
      console.error(`❌ 转换失败: ${e.message}`);
    }
  }
}

/**
 * 编码转换
 */
function convertEncoding(inputPath, outputPath, fromEncoding, toEncoding = 'utf8') {
  const content = fs.readFileSync(inputPath, { encoding: fromEncoding });
  fs.writeFileSync(outputPath, content, { encoding: toEncoding });
  console.log(`✅ 编码转换完成: ${fromEncoding} → ${toEncoding}`);
}

// ============ CLI 入口 ============

const [,, cmd, ...argsList] = process.argv;

const COMMANDS = {
  merge: () => {
    const iIdx = argsList.indexOf('-i');
    const oIdx = argsList.indexOf('-o');
    if (iIdx === -1 || oIdx === -1) {
      console.log('用法: csv-processor merge -i "*.csv" -o "output.csv"');
      return;
    }
    const inputs = argsList[iIdx + 1].split(',').map(f => f.trim());
    mergeCSV(inputs, argsList[oIdx + 1]);
  },
  
  dedup: () => {
    const iIdx = argsList.indexOf('-i');
    const oIdx = argsList.indexOf('-o');
    const kIdx = argsList.indexOf('-k');
    if (iIdx === -1 || oIdx === -1 || kIdx === -1) {
      console.log('用法: csv-processor dedup -i "input.csv" -o "output.csv" -k "列名"');
      return;
    }
    dedupCSV(argsList[iIdx + 1], argsList[oIdx + 1], argsList[kIdx + 1]);
  },
  
  filter: () => {
    const iIdx = argsList.indexOf('-i');
    const oIdx = argsList.indexOf('-o');
    const cIdx = argsList.indexOf('-c');
    const vIdx = argsList.indexOf('-v');
    if ([iIdx, oIdx, cIdx, vIdx].some(i => i === -1)) {
      console.log('用法: csv-processor filter -i "input.csv" -o "output.csv" -c "列名" -v "值"');
      return;
    }
    filterCSV(argsList[iIdx + 1], argsList[oIdx + 1], argsList[cIdx + 1], argsList[vIdx + 1]);
  },
  
  sort: () => {
    const iIdx = argsList.indexOf('-i');
    const oIdx = argsList.indexOf('-o');
    const sIdx = argsList.indexOf('-s');
    if ([iIdx, oIdx, sIdx].some(i => i === -1)) {
      console.log('用法: csv-processor sort -i "input.csv" -o "output.csv" -s "列名"');
      return;
    }
    sortCSV(argsList[iIdx + 1], argsList[oIdx + 1], argsList[sIdx + 1]);
  },
  
  summarize: () => {
    const iIdx = argsList.indexOf('-i');
    const gIdx = argsList.indexOf('-g');
    const sIdx = argsList.indexOf('-s');
    if ([iIdx, gIdx, sIdx].some(i => i === -1)) {
      console.log('用法: csv-processor summarize -i "input.csv" -g "分组列" -s "求和列"');
      return;
    }
    summarizeCSV(argsList[iIdx + 1], argsList[gIdx + 1], argsList[sIdx + 1]);
  },
  
  xlsx2csv: () => {
    const iIdx = argsList.indexOf('-i');
    const oIdx = argsList.indexOf('-o');
    if ([iIdx, oIdx].some(i => i === -1)) {
      console.log('用法: csv-processor xlsx2csv -i "input.xlsx" -o "output.csv"');
      return;
    }
    xlsx2csv(argsList[iIdx + 1], argsList[oIdx + 1]);
  },
  
  encode: () => {
    const iIdx = argsList.indexOf('-i');
    const oIdx = argsList.indexOf('-o');
    const fIdx = argsList.indexOf('-from');
    const tIdx = argsList.indexOf('-to');
    if ([iIdx, oIdx, fIdx].some(i => i === -1)) {
      console.log('用法: csv-processor encode -i "input.csv" -o "output.csv" -from "GBK" -to "UTF-8"');
      return;
    }
    convertEncoding(argsList[iIdx + 1], argsList[oIdx + 1], argsList[fIdx + 1], argsList[tIdx + 1] || 'utf8');
  }
};

if (COMMANDS[cmd]) {
  COMMANDS[cmd]();
} else {
  console.log(`
CSV批量处理工具
================
用法: csv-processor <命令> [选项]

命令:
  merge    合并多个CSV文件
  dedup    按列去重
  filter   按条件筛选
  sort     按列排序
  summarize 按列分组统计
  xlsx2csv Excel转CSV
  encode   编码转换

示例:
  csv-processor merge -i "*.csv" -o "merged.csv"
  csv-processor dedup -i "input.csv" -o "output.csv" -k "订单号"
  csv-processor filter -i "input.csv" -o "output.csv" -c "供应商" -v "华阳"
  csv-processor encode -i "input.csv" -o "output.csv" -from "GBK" -to "UTF-8"
`);
}

module.exports = { readCSV, writeCSV, mergeCSV, dedupCSV, filterCSV, sortCSV, summarizeCSV, xlsx2csv, convertEncoding };
