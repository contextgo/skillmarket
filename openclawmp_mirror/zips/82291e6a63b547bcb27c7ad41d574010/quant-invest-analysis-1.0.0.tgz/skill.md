---
name: quant-invest-analysis
description: 量化投资分析系统，整合股票数据获取、技术指标计算、回测框架和投资组合管理。支持A股、美股、港股的多维度分析，包括基本面、技术面、资金面、消息面等四维一体分析体系。
---

# 量化投资分析系统

一个全面的量化投资分析框架，提供数据采集、策略回测、风险管理和投资组合优化功能。

## 核心功能

### 1. 数据采集与处理
- 实时/历史行情获取（多市场：A股、美股、港股）
- 技术指标计算（MA、MACD、RSI、KDJ、布林带等）
- 基本面数据获取（财报、估值、财务指标）
- 资金流向分析（主力资金、北向资金、融资融券）

### 2. 策略回测引擎
- 事件驱动回测框架
- 支持多种策略类型（趋势跟踪、均值回归、多因子、统计套利）
- 详细的风险指标计算（最大回撤、夏普比率、索提诺比率、胜率等）
- 参数优化与稳健性测试

### 3. 投资组合管理
- 组合构建与再平衡
- 风险平价配置
- 业绩归因分析
- 持仓监控与预警

### 4. 四维一体分析
- **基本面**：财务健康度、盈利能力、成长性、估值水平
- **技术面**：趋势判断、买卖点信号、支撑阻力、量价关系
- **资金面**：主力动向、资金流入流出、筹码分布
- **消息面**：新闻情绪、事件驱动、政策影响、舆情分析

## 快速开始

### 环境要求
```bash
# Python 3.10+
pip install pandas numpy matplotlib seaborn yfinance akshare tushare scipy scikit-learn
```

### 基本用法

#### 单只股票分析
```bash
uv run scripts/analyze.py --symbol AAPL --market us
uv run scripts/analyze.py --symbol 600519 --market cn
```

#### 组合回测
```bash
uv run scripts/backtest.py --strategy momentum --start 2020-01-01 --end 2024-12-31
```

#### 投资组合优化
```bash
uv run scripts/portfolio.py --optimize risk_parity --assets AAPL,MSFT,GOOGL,AMZN
```

## 目录结构

```
quant-invest-analysis/
├── SKILL.md                 # 技能说明文档
├── scripts/                 # 执行脚本
│   ├── analyze.py          # 个股分析
│   ├── backtest.py         # 策略回测
│   ├── portfolio.py        # 组合管理
│   ├── factors.py          # 多因子模型
│   └── risk.py             # 风险分析
├── lib/                    # 核心库
│   ├── data/               # 数据获取
│   ├── indicators/         # 技术指标
│   ├── strategies/         # 策略实现
│   └── utils/              # 工具函数
├── config/                 # 配置文件
│   ├── markets.yaml       # 市场配置
│   └── strategies.yaml    # 策略参数
├── tests/                  # 单元测试
├── data/                   # 本地缓存数据
└── outputs/               # 分析结果输出
```

## 分析流程

### 1. 数据准备
```python
from lib.data import MarketData

md = MarketData()
df = md.get_price('AAPL', start='2023-01-01', end='2024-12-31')
```

### 2. 技术指标计算
```python
from lib.indicators import TechnicalIndicators

ti = TechnicalIndicators(df)
df['MA20'] = ti.sma(period=20)
df['RSI'] = ti.rsi(period=14)
df['MACD'], df['Signal'], df['Histogram'] = ti.macd()
```

### 3. 策略信号生成
```python
from lib.strategies import MomentumStrategy

strategy = MomentumStrategy(df)
signals = strategy.generate_signals(fast_period=10, slow_period=30)
```

### 4. 回测执行
```python
from lib.backtest import BacktestEngine

bt = BacktestEngine(df, signals)
results = bt.run(initial_capital=100000)
```

### 5. 绩效评估
```python
from lib.risk import PerformanceMetrics

pm = PerformanceMetrics(results['returns'])
print(f"年化收益: {pm.annual_return:.2%}")
print(f"最大回撤: {pm.max_drawdown:.2%}")
print(f"夏普比率: {pm.sharpe_ratio:.2f}")
```

## 策略示例

### 双均线策略
```python
# 买入条件：短期均线上穿长期均线
# 卖出条件：短期均线下穿长期均线
fast_ma = df['Close'].rolling(10).mean()
slow_ma = df['Close'].rolling(30).mean()
signals = (fast_ma > slow_ma) & (fast_ma.shift(1) <= slow_ma.shift(1))
```

### RSI超卖超买策略
```python
# RSI < 30 买入，RSI > 70 卖出
rsi = df['RSI']
signals = pd.DataFrame(index=df.index)
signals['buy'] = (rsi < 30) & (rsi.shift(1) >= 30)
signals['sell'] = (rsi > 70) & (rsi.shift(1) <= 70)
```

### 多因子选股策略
```python
from lib.factors import MultiFactorModel

mfm = MultiFactorModel(universe='沪深300')
scores = mfm.composite_score(
    factors=['value', 'quality', 'momentum'],
    weights=[0.4, 0.3, 0.3],
    ascending=[True, False, False]  # value越小越好，quality和momentum越大越好
)
top_n = mfm.select_top(scores, n=50)
```

## 数据源

### 内置数据源
- **A股**：akshare, tushare（需token）
- **美股**：yfinance
- **港股**：akshare

### 配置数据源
编辑 `config/markets.yaml`：
```yaml
data_sources:
  cn:
    default: akshare
    tushare: ${TUSHARE_TOKEN}  # 环境变量
  us:
    default: yfinance
```

## 输出报告

分析完成后会生成：
- `outputs/performance_report.html` - 完整的HTML报告
- `outputs/equity_curve.png` - 资金曲线图
- `outputs/drawdown_chart.png` - 回撤分析图
- `outputs/metrics.json` - 绩效指标JSON
- `outputs/trades.csv` - 交易明细

## 注意事项

1. **数据质量**：回测前检查数据完整性，处理缺失值和异常值
2. **幸存者偏差**：使用包含退市股票的全量数据
3. **交易成本**：设置合理的佣金和滑点（建议A股0.1%，美股0.05%）
4. **样本外测试**：务必进行样本外验证，避免过拟合
5. **实盘前验证**：建议用模拟盘或小资金实盘测试至少1个月

## 参考文档

- `scripts/analyze.py` - 个股分析脚本示例
- `scripts/backtest.py` - 回测框架示例
- `scripts/portfolio.py` - 组合管理示例
- `lib/strategies/` - 策略实现库
- `lib/indicators/` - 技术指标库

## 版本

- 当前版本：1.0.0
- 最后更新：2026-03-31

---

⚠️ **免责声明**：本工具仅供学习和研究使用，不构成任何投资建议。量化策略存在亏损风险，请谨慎决策，风险自担。
