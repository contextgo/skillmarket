#!/usr/bin/env python3
"""
frame.py - Extract frames from a video using ffmpeg.

Subcommands:
  check   Verify a video file exists and show its details (run this first)
  frame   Extract a single frame

Usage:
  python frame.py check <video>
  python frame.py frame <video> --out <path>
  python frame.py frame <video> --time HH:MM:SS --out <path>
  python frame.py frame <video> --index N --out <path>

Examples:
  python frame.py check video.mp4
  python frame.py frame video.mp4 --out ./frame.jpg
  python frame.py frame video.mp4 --time 00:00:10 --out ./frame-10s.jpg
  python frame.py frame video.mp4 --index 5 --out ./frame5.png

Extensible: batch, clip and other subcommands can be added without
breaking the existing check/frame interface.
"""

import argparse
import os
import shutil
import subprocess
import sys
from pathlib import Path


# ---------------------------------------------------------------------------
# ffmpeg detection
# ---------------------------------------------------------------------------

def _find_ffmpeg_in_registry():
    """
    Windows-only: search for ffmpeg in registry PATH entries that the current
    process has not yet inherited (e.g. installed via winget in the same session).

    Checks both user PATH (HKCU) and system PATH (HKLM) in that order.
    Returns the directory containing ffmpeg.exe, or None if not found.
    """
    try:
        import winreg
    except ImportError:
        return None  # Not Windows

    hives = [
        (winreg.HKEY_CURRENT_USER,  r'Environment', 'PATH'),
        (winreg.HKEY_LOCAL_MACHINE,
         r'SYSTEM\CurrentControlSet\Control\Session Manager\Environment', 'PATH'),
    ]

    for hive, subkey, value_name in hives:
        try:
            key = winreg.OpenKey(hive, subkey)
            raw, _ = winreg.QueryValueEx(key, value_name)
            winreg.CloseKey(key)
        except OSError:
            continue

        for directory in raw.split(';'):
            directory = directory.strip()
            if not directory:
                continue
            candidate = Path(directory) / 'ffmpeg.exe'
            try:
                if candidate.is_file():
                    return directory
            except OSError:
                continue

    return None


def check_ffmpeg():
    """
    Verify ffmpeg is available. On Windows, also checks the registry PATH for
    installations made in the current session (e.g. via winget) that the
    process has not yet inherited. If found, injects the directory into the
    current process PATH so subsequent subprocess calls can use it.

    Exits with code 1 and prints install instructions if ffmpeg is not found.
    """
    if shutil.which('ffmpeg') is not None:
        return  # Already visible in process PATH

    # Windows fallback: scan registry PATH for newly installed ffmpeg
    ffmpeg_dir = _find_ffmpeg_in_registry()
    if ffmpeg_dir:
        os.environ['PATH'] = ffmpeg_dir + os.pathsep + os.environ.get('PATH', '')
        return  # Now visible; no restart needed

    print(
        'Error: ffmpeg not found.\n'
        '\n'
        'Install ffmpeg:\n'
        '  Mac:     brew install ffmpeg\n'
        '  Windows: winget install Gyan.FFmpeg --source winget\n'
        '           (or: choco install ffmpeg)\n'
        '  Linux:   sudo apt install ffmpeg\n'
        '\n'
        'If already installed, open a new terminal so PATH is refreshed,\n'
        'or re-run this script — it will locate ffmpeg automatically.\n',
        file=sys.stderr,
    )
    sys.exit(1)


# ---------------------------------------------------------------------------
# Video file lookup helpers
# ---------------------------------------------------------------------------

VIDEO_EXTS = {'.mp4', '.mov', '.avi', '.mkv', '.wmv', '.flv', '.webm', '.m4v'}


def _list_video_files(directory: Path) -> list:
    """Return sorted list of video files in directory."""
    if not directory.is_dir():
        return []
    return sorted(f for f in directory.iterdir() if f.suffix.lower() in VIDEO_EXTS)


def _find_similar(video: Path) -> list:
    """
    Find video files whose name matches *video* after stripping spaces and
    lowercasing. Returns a list of matching Path objects.
    """
    candidates = _list_video_files(video.parent)
    target_norm = video.stem.replace(' ', '').lower()
    return [f for f in candidates if f.stem.replace(' ', '').lower() == target_norm]


# ---------------------------------------------------------------------------
# check subcommand
# ---------------------------------------------------------------------------

def cmd_check(args):
    """
    Verify a video file exists and print its details.
    If the file is not found, list similar files or all video files in the folder.
    Exit 0 on success, exit 1 if not found.
    """
    video = Path(args.video)

    if video.is_file():
        size_mb = video.stat().st_size / (1024 * 1024)
        print(f'OK: {video}')
        print(f'    Size: {size_mb:.1f} MB')
        sys.exit(0)

    # File not found — try to help
    print(f'Not found: {video}', file=sys.stderr)
    print('', file=sys.stderr)

    similar = _find_similar(video)
    if similar:
        print('Did you mean:', file=sys.stderr)
        for f in similar:
            print(f'  {f}', file=sys.stderr)
    else:
        all_videos = _list_video_files(video.parent)
        if all_videos:
            print(f'Video files in {video.parent}:', file=sys.stderr)
            for f in all_videos:
                print(f'  {f}', file=sys.stderr)
        else:
            print(f'No video files found in: {video.parent}', file=sys.stderr)

    sys.exit(1)


# ---------------------------------------------------------------------------
# frame extraction logic
# ---------------------------------------------------------------------------

def extract_frame(video, out, time=None, index=None):
    """
    Extract a single frame from *video* and write it to *out*.

    Priority: time > index > first frame (index 0).
    Returns the output path on success; raises SystemExit on failure.
    """
    video = Path(video)
    out = Path(out)

    if not video.is_file():
        print(
            f'Error: file not found: {video}\n'
            f'\n'
            f'Run `check` first to verify the path:\n'
            f'  python frame.py check "{video}"\n',
            file=sys.stderr,
        )
        sys.exit(1)

    out.parent.mkdir(parents=True, exist_ok=True)

    base = ['ffmpeg', '-hide_banner', '-loglevel', 'error', '-y']

    if time is not None:
        cmd = base + ['-ss', time, '-i', str(video), '-frames:v', '1', str(out)]
    elif index is not None:
        cmd = base + [
            '-i', str(video),
            '-vf', f'select=eq(n\\,{index})',
            '-vframes', '1',
            str(out),
        ]
    else:
        cmd = base + [
            '-i', str(video),
            '-vf', 'select=eq(n\\,0)',
            '-vframes', '1',
            str(out),
        ]

    result = subprocess.run(cmd, stderr=subprocess.PIPE, text=True)
    if result.returncode != 0:
        print(f'Error: ffmpeg failed:\n{result.stderr}', file=sys.stderr)
        sys.exit(result.returncode)

    return out


def cmd_frame(args):
    check_ffmpeg()
    out = extract_frame(
        video=args.video,
        out=args.out,
        time=args.time,
        index=args.index,
    )
    print(str(out))


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def build_parser():
    parser = argparse.ArgumentParser(
        prog='frame.py',
        description='Extract frames from a video using ffmpeg.',
    )
    sub = parser.add_subparsers(dest='command', required=True)

    # -- check --
    p_check = sub.add_parser(
        'check',
        help='Verify a video file exists and show its details. Run this before frame.',
    )
    p_check.add_argument('video', help='Video file path to verify.')
    p_check.set_defaults(func=cmd_check)

    # -- frame --
    p_frame = sub.add_parser('frame', help='Extract a single frame.')
    p_frame.add_argument('video', help='Input video file path.')
    p_frame.add_argument('--out', required=True, help='Output image path (.jpg or .png).')
    p_frame.add_argument(
        '--time', default=None, metavar='HH:MM:SS',
        help='Timestamp to extract (e.g. 00:00:10). Takes priority over --index.',
    )
    p_frame.add_argument(
        '--index', type=int, default=None, metavar='N',
        help='Zero-based frame number. Default: 0 (first frame).',
    )
    p_frame.set_defaults(func=cmd_frame)

    # Future subcommands (batch, clip) can be added here
    # without affecting the existing check/frame interface.

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == '__main__':
    main()
