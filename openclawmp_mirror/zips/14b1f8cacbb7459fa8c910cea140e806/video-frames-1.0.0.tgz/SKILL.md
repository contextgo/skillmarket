---
name: video-frames
description: >
  Extracts a single frame or thumbnail from a video file using ffmpeg.
  Use when the user wants to capture a screenshot from a video, grab a frame
  at a specific timestamp, inspect video content at a particular moment, or
  generate a thumbnail from any video format (mp4, mov, avi, mkv, etc.).
  Always use the provided scripts/frame.py — do not call ffmpeg directly.
allowed-tools:
  - RunTerminalCommand
---

# Video Frames (ffmpeg)

Extract a single frame from a video as a `.jpg` or `.png` image.

## Prerequisites

ffmpeg must be installed and available in PATH:

```
Mac:     brew install ffmpeg
Windows: winget install Gyan.FFmpeg --source winget
Linux:   sudo apt install ffmpeg
```

**Windows note:** After installation, open a new terminal before running the
script. If you prefer not to restart, the script detects ffmpeg from the
Windows registry automatically — just run it directly.

## How to use

**Always run `frame.py` — never call `ffmpeg` directly.**
The script handles ffmpeg detection, PATH resolution, and error reporting
consistently across platforms.

**Finding the script path:**
1. The directory containing this SKILL.md is `SKILL_DIR`
2. The script full path is `SKILL_DIR/scripts/frame.py`

### Step 1 — Verify the video file path

Always run `check` first to confirm the exact file path before extracting.
If the file is not found, the script lists similar or all video files in the folder.

```bash
python SKILL_DIR/scripts/frame.py check "path/to/video.mp4"
```

On success (exit 0): proceed to Step 2.
On failure (exit 1): use the exact filename shown in the output and re-run check.

### Step 2 — Extract frames

**First frame (default):**

```bash
python SKILL_DIR/scripts/frame.py frame "video.mp4" --out ./frame.jpg
```

**At a timestamp:**

```bash
python SKILL_DIR/scripts/frame.py frame "video.mp4" --time 00:00:10 --out ./frame-10s.jpg
```

**By frame number:**

```bash
python SKILL_DIR/scripts/frame.py frame "video.mp4" --index 5 --out ./frame5.png
```

Mac/Linux users may also use the bash script directly:

```bash
bash SKILL_DIR/scripts/frame.sh "video.mp4" --time 00:00:10 --out ./frame-10s.jpg
```

## Notes

- Run `check` before `frame` — this ensures the file path is correct.
- `--time` takes priority over `--index` when both are provided.
- Use `.jpg` for quick sharing; use `.png` for crisp UI or text frames.
- The output directory is created automatically if it does not exist.
- On success, the script prints the output file path to stdout.
