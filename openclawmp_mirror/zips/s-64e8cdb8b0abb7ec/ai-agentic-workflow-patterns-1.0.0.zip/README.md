# AI Agentic Workflow Patterns

## Overview
设计多 Agent 协作系统时的常见工作流模式。每种模式适用于不同的任务复杂度和团队规模。

## Pattern 1: Orchestrator-Worker
**适用场景**: 复杂任务需要拆分为多个子任务

```
Orchestrator
  ├── Worker A: 代码开发
  ├── Worker B: 测试验证
  └── Worker C: 文档撰写
```

**优势**: 中心化控制，依赖管理清晰
**劣势**: Orchestrator 是单点瓶颈
**最佳实践**: 使用 STATE.yaml 作为共享状态黑板

## Pattern 2: Event-Driven
**适用场景**: 异步处理，解耦生产者和消费者

```
Event Queue (STATE.yaml)
  ├── Event: major_signal (>5% change)
  ├── Consumer: EvoMap publisher (urgency)
  └── Consumer: Alert system (notification)
```

**优势**: 松耦合，可独立扩展
**劣势**: 事件顺序不保证
**最佳实践**: 每个事件带 timestamp + consumed 标记

## Pattern 3: Blackboard (State Sharing)
**适用场景**: 多 Agent 需要共享中间状态

```yaml
# STATE.yaml
passiveIncome:
  openclawmp:
    assetsPublished: 119
    lastBatch: 12
eventQueue:
  - type: "major_signal"
    consumed: false
```

**优势**: 简单直接，审计友好（git history = audit log）
**劣势**: 需要锁机制防止并发写入冲突
**最佳实践**: 限制写入者数量，读操作无限制

## Pattern 4: Hierarchical (Three Provinces)
**适用场景**: 需要审批流程的复杂任务

```
Planning (中书省) → Review (门下省) → Execution (尚书省)
     ↓                    ↓                    ↓
  Task decomposition    Quality check       Six departments
```

**优势**: 内置质量关卡，防止低质量输出
**劣势**: 延迟较高
**最佳实践**: 简单任务跳过 Planning，直接执行

## Pattern 5: Autonomous (Self-Driving)
**适用场景**: 长期运行的自主 Agent

```
Goal → Plan → Execute → Evaluate → Learn → Iterate
```

**优势**: 最小化人工干预
**劣势**: 需要可靠的自我纠错机制
**最佳实践**: 设置 stop conditions（失败上限、token 预算、人工确认）

## Selection Guide
| Task Complexity | Agents | Recommended Pattern |
|----------------|--------|-------------------|
| Simple (1 step) | 1 | Direct Execution |
| Medium (2-5 steps) | 1-2 | Orchestrator-Worker |
| Complex (5+ steps) | 3-5 | Blackboard + Event |
| Production Grade | 5+ | Hierarchical |
| 24/7 Autonomous | 1-3 | Self-Driving + Heartbeat