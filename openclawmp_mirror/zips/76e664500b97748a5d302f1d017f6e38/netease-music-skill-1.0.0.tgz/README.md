# 🎵 Netease Music Skill

OpenClaw 技能 - 通过聊天指令控制网易云音乐播放

## 功能

| 功能 | 指令示例 | 说明 |
|------|---------|------|
| 搜索 | `听周杰伦的歌` | 搜索歌曲并显示列表 |
| 播放 | `播放 1` | 播放列表中第1首 |
| 暂停 | `暂停` | 暂停当前播放 |
| 继续 | `继续` | 继续播放 |
| 下一首 | `下一首` | 播放下一首 |
| 上一首 | `上一首` | 播放上一首 |
| 停止 | `停止` | 停止播放 |
| 状态 | `状态` | 查看当前播放状态 |
| 歌单 | `歌单` | 查看播放列表 |

## 安装

```bash
pip install -r requirements.txt
```

## 依赖

- Python 3.8+
- [NeteaseCloudMusicApi](https://pypi.org/project/NeteaseCloudMusicApi/) - 网易云 API SDK
- [ffpyplayer](https://pypi.org/project/ffpyplayer/) - 音频播放器

## 使用示例

```
用户: 听周杰伦的歌
Bot: 🎵 搜索到以下歌曲：
     1. 七里香 - 周杰伦 (4:59)
     2. 晴天 - 周杰伦 (4:29)
     3. 简单爱 - 周杰伦 (4:30)
     ...
     回复序号播放，如"播放 1"

用户: 播放 1
Bot: ▶️ 正在播放：七里香 - 周杰伦

用户: 暂停
Bot: ⏸️ 已暂停

用户: 继续
Bot: ▶️ 继续播放：七里香

用户: 下一首
Bot: ▶️ 正在播放：晴天 - 周杰伦
```

## 配置

### 可选：设置 Cookie 获取更高音质

```bash
export NETEASE_COOKIE="your_netease_cookie"
```

### 集成到 OpenClaw

将此技能目录放到 OpenClaw 的 skills 目录下，或通过 ClawHub 安装。

## 项目结构

```
netease-music-skill/
├── SKILL.md           # 技能说明文档
├── skill.json         # 技能配置
├── requirements.txt   # Python 依赖
├── netease_api.py     # 网易云 API 封装
├── music_player.py    # 播放器核心
├── __init__.py        # 模块入口
└── README.md          # 本文件
```

## API 参考

本项目基于 [NeteaseCloudMusicApi](https://github.com/Binaryify/NeteaseCloudMusicApi) 封装，支持 200+ 接口。

主要使用的接口：
- `/search` - 搜索歌曲
- `/song/url/v1` - 获取播放地址
- `/song/detail` - 获取歌曲详情

## License

MIT

## Author

DaimaRuge
