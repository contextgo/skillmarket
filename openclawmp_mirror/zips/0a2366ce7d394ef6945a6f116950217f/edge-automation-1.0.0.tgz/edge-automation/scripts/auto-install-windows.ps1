# Auto-install script for agent-browser on Windows (Edge version)
# This script checks and installs all required dependencies automatically

Write-Host "🔍 Checking agent-browser installation..." -ForegroundColor Cyan

# Define paths
$AB_HOME = "$HOME\Documents\agent-browser"
$AB_BIN = "$AB_HOME\bin\agent-browser.cmd"

# Check if agent-browser binary exists
if (Test-Path $AB_BIN) {
    Write-Host "✓ agent-browser binary found" -ForegroundColor Green
    
    # Test if it works
    Set-Location $AB_HOME
    $env:AGENT_BROWSER_HOME = $AB_HOME
    try {
        & $AB_BIN --version 2>$null
        if ($LASTEXITCODE -eq 0) {
            Write-Host "✓ agent-browser is working correctly" -ForegroundColor Green
            exit 0
        }
    } catch {
        Write-Host "⚠️  agent-browser binary exists but not working, rebuilding..." -ForegroundColor Yellow
    }
}

# Check if repository exists
if (-not (Test-Path $AB_HOME)) {
    Write-Host "📦 Cloning agent-browser repository..." -ForegroundColor Cyan
    Set-Location "$HOME\Documents"
    git clone https://github.com/vercel-labs/agent-browser.git
    Set-Location agent-browser
} else {
    Write-Host "✓ Repository found" -ForegroundColor Green
    Set-Location $AB_HOME
}

# Check Node.js
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
    Write-Host "❌ Node.js not found. Please install Node.js first." -ForegroundColor Red
    Write-Host "Download from: https://nodejs.org/" -ForegroundColor Yellow
    exit 1
}
Write-Host "✓ Node.js found: $(node --version)" -ForegroundColor Green

# Check pnpm
if (-not (Get-Command pnpm -ErrorAction SilentlyContinue)) {
    Write-Host "📦 Installing pnpm..." -ForegroundColor Cyan
    npm install -g pnpm
}
Write-Host "✓ pnpm found: $(pnpm --version)" -ForegroundColor Green

# Install dependencies
Write-Host "📦 Installing dependencies..." -ForegroundColor Cyan
pnpm install

# Install Playwright Chromium
Write-Host "📦 Installing Playwright Chromium..." -ForegroundColor Cyan
npx playwright install chromium

# Check Rust
if (-not (Get-Command cargo -ErrorAction SilentlyContinue)) {
    Write-Host "📦 Installing Rust toolchain..." -ForegroundColor Cyan
    Invoke-WebRequest -Uri "https://win.rustup.rs" -OutFile "$env:TEMP\rustup-init.exe"
    & "$env:TEMP\rustup-init.exe" -y --default-toolchain stable
    $env:PATH = "$HOME\.cargo\bin;$env:PATH"
}
Write-Host "✓ Rust found: $(cargo --version)" -ForegroundColor Green

# Build native binary
Write-Host "🔨 Building agent-browser native binary..." -ForegroundColor Cyan
pnpm build

# Create bin directory and wrapper
if (-not (Test-Path "$AB_HOME\bin")) {
    New-Item -ItemType Directory -Path "$AB_HOME\bin" -Force | Out-Null
}

# Create wrapper script
@"
@echo off
set AGENT_BROWSER_HOME=$AB_HOME
cd /d %AGENT_BROWSER_HOME%
node dist/index.js %*
"@ | Set-Content "$AB_BIN"

Write-Host "✓ agent-browser installed successfully!" -ForegroundColor Green

# Verify Edge is available
$edgePath = $null
$edgePaths = @(
    "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe"
)

foreach ($path in $edgePaths) {
    if (Test-Path $path) {
        $edgePath = $path
        break
    }
}

if ($edgePath) {
    Write-Host "✓ Microsoft Edge found: $edgePath" -ForegroundColor Green
} else {
    Write-Host "⚠️  Microsoft Edge not found. Please install Edge." -ForegroundColor Yellow
}

Write-Host ""
Write-Host "✅ Installation complete! Run start-edge-windows.ps1 to start Edge with automation support." -ForegroundColor Green
