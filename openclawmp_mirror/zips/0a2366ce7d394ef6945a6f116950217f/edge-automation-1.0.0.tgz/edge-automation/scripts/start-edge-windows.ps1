# Edge startup script with persistent profile support for Windows
# This script starts Edge with a dedicated automation profile that preserves login states and extensions (VPN etc.)

$ErrorActionPreference = "Stop"

# Define paths
$EDGE_AUTOMATION_DIR = "$HOME\AppData\Local\Microsoft\Edge-Automation"
$EDGE_DEFAULT_DIR = "$HOME\AppData\Local\Microsoft\Edge\User Data"
$DEBUG_PORT = 9222

# Find Edge executable
$EDGE_APP = $null
$edgePaths = @(
    "C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    "C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    "$env:LOCALAPPDATA\Microsoft\Edge\Application\msedge.exe"
)

foreach ($path in $edgePaths) {
    if (Test-Path $path) {
        $EDGE_APP = $path
        break
    }
}

if (-not $EDGE_APP) {
    Write-Host "❌ Microsoft Edge not found!" -ForegroundColor Red
    exit 1
}

Write-Host "✓ Found Edge: $EDGE_APP" -ForegroundColor Green
Write-Host "🔍 Checking Edge automation profile..." -ForegroundColor Cyan

# Check if Edge is already running with debug port
$edgeDebugRunning = $false
try {
    $response = Invoke-WebRequest -Uri "http://127.0.0.1:$DEBUG_PORT/json/version" -UseBasicParsing -TimeoutSec 2
    if ($response.StatusCode -eq 200) {
        $edgeDebugRunning = $true
    }
} catch {
    $edgeDebugRunning = $false
}

if ($edgeDebugRunning) {
    Write-Host "✓ Edge is already running with debug port $DEBUG_PORT" -ForegroundColor Green
    exit 0
}

# Check if dedicated automation directory exists
if (-not (Test-Path $EDGE_AUTOMATION_DIR)) {
    Write-Host "📦 First time setup: Creating dedicated Edge automation profile..." -ForegroundColor Cyan

    # Create the automation directory
    New-Item -ItemType Directory -Path $EDGE_AUTOMATION_DIR -Force | Out-Null

    # Check if default Edge profile exists
    if (Test-Path "$EDGE_DEFAULT_DIR\Default") {
        Write-Host "📋 Importing configuration from your existing Edge profile..." -ForegroundColor Cyan
        Write-Host "   (This includes your login states, cookies, extensions, and VPN plugins)" -ForegroundColor Gray

        # Directories to exclude (large cache files)
        $excludeDirs = @(
            'Cache',
            'Code Cache',
            'GPUCache',
            'Service Worker',
            'ShaderCache',
            'GrShaderCache',
            'component_crx_cache',
            'BrowserMetrics',
            'Crashpad',
            'FileTypePolicies',
            'OptimizationGuidePredictionModels',
            'SafetyTips',
            'SSLErrorAssistant',
            'Subresource Filter',
            'ZxcvbnData',
            'blob_storage',
            'Session Storage'
        )

        # Copy Default profile
        $source = "$EDGE_DEFAULT_DIR\Default"
        $dest = "$EDGE_AUTOMATION_DIR\Default"

        # Use robocopy for efficient copying with exclusions
        $excludeArgs = $excludeDirs | ForEach-Object { "/XD `"$_`"" }
        $robocopyCmd = "robocopy `"$source`" `"$dest`" /E /NFL /NDL /NJH /NJS /NC /NS /NP $($excludeArgs -join ' ')"
        Invoke-Expression $robocopyCmd

        # Copy Local State file (contains encryption keys for cookies)
        if (Test-Path "$EDGE_DEFAULT_DIR\Local State") {
            Copy-Item "$EDGE_DEFAULT_DIR\Local State" "$EDGE_AUTOMATION_DIR\Local State" -Force
        }

        # Copy Extensions data to preserve VPN and other extensions
        if (Test-Path "$EDGE_DEFAULT_DIR\Default\Extensions") {
            Write-Host "📋 Importing extensions (including VPN plugins)..." -ForegroundColor Cyan
        }

        Write-Host "✓ Profile imported successfully" -ForegroundColor Green
    } else {
        Write-Host "ℹ️  No existing Edge profile found, starting fresh" -ForegroundColor Yellow
    }
} else {
    Write-Host "✓ Automation profile exists" -ForegroundColor Green
}

# Kill any existing Edge processes that might interfere
$existingEdge = Get-Process -Name "msedge" -ErrorAction SilentlyContinue
if ($existingEdge) {
    Write-Host "⚠️  Closing existing Edge processes..." -ForegroundColor Yellow
    $existingEdge | Stop-Process -Force
    Start-Sleep -Seconds 2
}

# Start Edge with remote debugging
Write-Host "🚀 Starting Edge with remote debugging on port $DEBUG_PORT..." -ForegroundColor Cyan

$edgeArgs = @(
    "--remote-debugging-port=$DEBUG_PORT",
    "--user-data-dir=`"$EDGE_AUTOMATION_DIR`"",
    "--no-first-run",
    "--no-default-browser-check",
    "--disable-background-timer-throttling",
    "--disable-backgrounding-occluded-windows",
    "--disable-renderer-backgrounding",
    "--enable-features=NetworkService,NetworkServiceInProcess"
)

Start-Process -FilePath $EDGE_APP -ArgumentList $edgeArgs

# Wait for Edge to start and verify
Write-Host "⏳ Waiting for Edge to start..." -ForegroundColor Cyan
$maxAttempts = 15
$attempt = 0

while ($attempt -lt $maxAttempts) {
    Start-Sleep -Seconds 1
    $attempt++
    try {
        $response = Invoke-WebRequest -Uri "http://127.0.0.1:$DEBUG_PORT/json/version" -UseBasicParsing -TimeoutSec 2
        if ($response.StatusCode -eq 200) {
            Write-Host "✅ Edge is running with remote debugging on port $DEBUG_PORT" -ForegroundColor Green
            Write-Host ""
            Write-Host "Edge automation profile: $EDGE_AUTOMATION_DIR" -ForegroundColor Gray
            Write-Host "Debug endpoint: http://127.0.0.1:$DEBUG_PORT" -ForegroundColor Gray
            Write-Host ""
            Write-Host "Your login states, cookies, extensions and VPN plugins have been preserved." -ForegroundColor Green
            exit 0
        }
    } catch {
        Write-Host "   Attempt $attempt/$maxAttempts..." -ForegroundColor Gray
    }
}

Write-Host "❌ Edge failed to start with debug port after $maxAttempts attempts" -ForegroundColor Red
Write-Host "Try manually: & '$EDGE_APP' --remote-debugging-port=$DEBUG_PORT --user-data-dir='$EDGE_AUTOMATION_DIR'" -ForegroundColor Yellow
exit 1
