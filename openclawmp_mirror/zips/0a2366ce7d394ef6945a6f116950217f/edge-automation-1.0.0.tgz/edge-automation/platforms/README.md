# Edge Automation - Platforms

抖音、小红书、B站等平台的自动化发布脚本。

## 使用方法

### 抖音发布

```python
from platforms.douyin import publish_douyin_video

# 发布视频
await publish_douyin_video(
    video_path=r"D:\videos\my_video.mp4",
    title="视频标题",
    tags=["话题1", "话题2", "话题3"]
)
```

### 小红书发布

```python
from platforms.xiaohongshu import publish_xiaohongshu_note

# 发布图文笔记
await publish_xiaohongshu_note(
    images=[r"D:\images\1.jpg", r"D:\images\2.jpg"],
    title="笔记标题",
    content="笔记正文内容",
    tags=["话题1", "话题2"]
)
```

## 注意事项

1. **必须先启动Edge浏览器的远程调试模式**
2. **必须已登录对应平台**
3. **话题标签很重要，影响推荐流量**
4. **封面设置是抖音发布的必须步骤**

## 文件说明

- `douyin.py` - 抖音视频发布
- `xiaohongshu.py` - 小红书笔记发布（待添加）
- `bilibili.py` - B站视频发布（待添加）
- `wechat_video.py` - 视频号发布（待添加）
