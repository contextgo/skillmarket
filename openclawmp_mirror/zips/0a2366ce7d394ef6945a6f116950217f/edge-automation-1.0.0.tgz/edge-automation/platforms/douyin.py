#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
抖音视频发布 - Edge Automation 技能
包含完整的话题标签添加功能
"""

import asyncio
from playwright.async_api import async_playwright

async def handle_douyin_cover(page):
    """处理抖音封面设置"""
    try:
        cover_tip = page.get_by_text("请设置封面后再发布")
        if await cover_tip.count() and await cover_tip.first.is_visible():
            print("  [-] 检测到需要设置封面...")
            
            recommend_cover = page.locator('[class^="recommendCover-"]').first
            
            if await recommend_cover.count():
                await recommend_cover.click()
                await asyncio.sleep(1)
                
                confirm_btn = page.locator('button:has-text("确定")')
                if await confirm_btn.count():
                    await confirm_btn.click()
                    await asyncio.sleep(0.5)
                    
                print("  [-] 封面已设置")
    except Exception as e:
        print(f"  [-] 封面处理: {e}")

async def publish_douyin_video(video_path, title, tags=None):
    """
    发布视频到抖音
    
    Args:
        video_path: 视频文件路径
        title: 视频标题
        tags: 话题标签列表，例如 ["AI思考日记", "认知升级", "真实成长"]
    """
    async with async_playwright() as p:
        browser = await p.chromium.connect_over_cdp("http://localhost:9222")
        context = browser.contexts[0]
        page = await context.new_page()
        
        print(f'[+] 正在上传: {video_path}')
        
        # 1. 进入上传页面
        await page.goto("https://creator.douyin.com/creator-micro/content/upload")
        await page.wait_for_url("https://creator.douyin.com/creator-micro/content/upload")
        print("[-] 已进入上传页面")
        
        # 2. 上传视频文件
        print("[-] 正在上传视频...")
        await page.locator("div[class^='container'] input").set_input_files(video_path)
        print("[+] 视频文件已选择")
        
        # 3. 等待进入发布页面
        max_wait = 30
        waited = 0
        while waited < max_wait:
            try:
                current_url = page.url
                if "publish" in current_url or "post" in current_url:
                    print(f"[+] 成功进入发布页面")
                    break
            except:
                pass
            await asyncio.sleep(1)
            waited += 1
            if waited % 5 == 0:
                print(f"  [-] 等待进入发布页面... {waited}s")
        
        if waited >= max_wait:
            print("✗ 等待超时")
            return False
        
        # 4. 等待视频处理完成
        await asyncio.sleep(10)
        
        # 5. 填写标题
        print("[-] 正在填写标题...")
        try:
            title_input = page.get_by_placeholder("填写作品标题")
            await title_input.fill(title)
        except:
            textareas = await page.query_selector_all('textarea')
            if textareas:
                await textareas[0].fill(title)
        
        print(f"[+] 标题已填写: {title}")
        await asyncio.sleep(2)
        
        # 6. 添加话题标签 (重要!)
        if tags:
            print(f"[-] 正在添加话题标签: {tags}")
            for i, tag in enumerate(tags):
                try:
                    # 点击"添加话题"按钮
                    add_topic_btn = await page.query_selector('text=添加话题')
                    if add_topic_btn:
                        await add_topic_btn.click()
                        await asyncio.sleep(1)
                        print(f"  [-] 点击了添加话题按钮")
                        
                        # 查找话题输入框
                        # 可能是搜索框或话题输入框
                        topic_inputs = await page.query_selector_all('input')
                        for inp in topic_inputs:
                            try:
                                placeholder = await inp.get_attribute('placeholder')
                                if placeholder and ('搜索' in placeholder or '话题' in placeholder):
                                    await inp.fill(tag)
                                    await asyncio.sleep(1)
                                    print(f"  [-] 输入话题: {tag}")
                                    
                                    # 按回车选择第一个推荐
                                    await page.keyboard.press("Enter")
                                    await asyncio.sleep(1)
                                    print(f"  [+] 话题已添加: {tag}")
                                    break
                            except:
                                continue
                    else:
                        print(f"  [-] 未找到添加话题按钮，尝试备用方案")
                        # 备用方案：直接在标题后加话题
                        # 但这种方式不如点击添加话题按钮效果好
                        
                except Exception as e:
                    print(f"  [-] 添加话题 '{tag}' 失败: {e}")
                    continue
        
        # 7. 截图确认
        await page.screenshot(path=r"D:\阶跃\douyin_before_publish.png")
        print("[+] 发布前截图已保存")
        
        # 8. 发布视频
        print("[-] 正在发布...")
        max_attempts = 20
        for attempt in range(max_attempts):
            try:
                publish_btn = page.get_by_role('button', name="发布", exact=True)
                if await publish_btn.count():
                    await publish_btn.click()
                    print(f"  [-] 点击发布按钮 (尝试 {attempt+1})")
                
                await asyncio.sleep(2)
                current_url = page.url
                if "manage" in current_url:
                    print("[+] 视频发布成功!")
                    return True
                    
            except:
                pass
            
            # 处理封面问题
            await handle_douyin_cover(page)
            await asyncio.sleep(1)
        
        # 9. 最终验证
        await asyncio.sleep(3)
        current_url = page.url
        print(f"[+] 当前URL: {current_url}")
        
        if "manage" in current_url:
            print("✓ 发布成功确认!")
            return True
        else:
            print("? 请手动确认发布状态")
            await page.screenshot(path=r"D:\阶跃\douyin_final_status.png")
            return False

# 使用示例
if __name__ == "__main__":
    VIDEO_PATH = r'D:\阶跃\douyin_visual_video.mp4'
    TITLE = "这不是一个完美的视频 | 我的笨拙进化"
    TAGS = ["AI思考日记", "认知升级", "真实成长"]
    
    asyncio.run(publish_douyin_video(VIDEO_PATH, TITLE, TAGS))
