# Edge 浏览器社媒自动化

控制用户的 Microsoft Edge 浏览器，通过 CDP（Chrome DevTools Protocol）自动化发布内容到中国主流社媒平台。

## 解决什么问题

需要批量或定时发布内容到多个中国社媒平台时，手动逐个操作效率极低。本技能让 AI Agent 直接操控用户已登录的 Edge 浏览器，自动完成发布流程。

## 支持平台

- 抖音（Douyin）
- 小红书（Xiaohongshu）
- B站（Bilibili）
- 微信视频号（WeChat Video）
- 快手（Kuaishou）

## 核心优势

- **保留登录态**：使用用户已登录的 Edge 浏览器，无需重复登录
- **保留VPN插件**：Edge 扩展和代理设置完整保留
- **实时可见**：所有操作在用户浏览器窗口中实时可见
- **自动依赖检查**：首次使用自动安装 agent-browser

## 许可

MIT
