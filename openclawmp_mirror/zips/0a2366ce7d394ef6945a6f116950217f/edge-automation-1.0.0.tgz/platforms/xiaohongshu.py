import asyncio
from playwright.async_api import async_playwright

async def publish_xiaohongshu_note(images, title, content, tags=None):
    """
    发布笔记到小红书
    
    Args:
        images: 图片文件路径列表 (最多9张)
        title: 笔记标题
        content: 笔记正文
        tags: 话题标签列表
    """
    async with async_playwright() as p:
        # 连接到已运行的Edge浏览器
        browser = await p.chromium.connect_over_cdp("http://localhost:9222")
        context = browser.contexts[0]
        page = await context.new_page()
        
        try:
            # 进入创作中心
            print("正在进入小红书创作中心...")
            await page.goto("https://creator.xiaohongshu.com/creator/home")
            await page.wait_for_load_state("networkidle", timeout=60000)
            
            # 点击发布图文笔记按钮
            print("正在点击发布图文笔记按钮...")
            # 尝试多种选择器
            publish_btn = None
            selectors = [
                'text=发布图文笔记',
                'text=发布图文',
                'button:has-text("发布")',
                'div:has-text("发布图文笔记")'
            ]
            
            for selector in selectors:
                try:
                    publish_btn = await page.query_selector(selector)
                    if publish_btn:
                        await publish_btn.click()
                        print(f"发布图文笔记按钮点击成功，使用选择器: {selector}")
                        break
                except:
                    continue
            
            if not publish_btn:
                print("未找到发布图文笔记按钮")
                # 截图保存以便调试
                await page.screenshot(path="xiaohongshu_publish_btn_error.png")
                print("错误截图已保存为 xiaohongshu_publish_btn_error.png")
                return False
            
            # 等待页面加载
            await page.wait_for_load_state("networkidle", timeout=60000)
            
            # 上传图片
            print("正在上传图片...")
            file_input = await page.query_selector('input[type="file"]')
            if not file_input:
                # 尝试其他选择器
                file_input = await page.query_selector('input[type="file"][accept="image/*"]')
                if not file_input:
                    # 尝试查找上传图片按钮
                    upload_btn = await page.query_selector('text=上传图片')
                    if upload_btn:
                        await upload_btn.click()
                        await asyncio.sleep(2)
                        file_input = await page.query_selector('input[type="file"]')
                    else:
                        # 尝试查找其他上传按钮
                        upload_btns = await page.query_selector_all('button')
                        for btn in upload_btns:
                            try:
                                text = await btn.inner_text()
                                if '上传' in text:
                                    await btn.click()
                                    await asyncio.sleep(2)
                                    file_input = await page.query_selector('input[type="file"]')
                                    if file_input:
                                        break
                            except:
                                continue
            
            if file_input:
                await file_input.set_input_files(images)
                print("图片上传成功")
            else:
                print("未找到文件上传输入框")
                # 截图保存以便调试
                await page.screenshot(path="xiaohongshu_upload_error.png")
                print("错误截图已保存为 xiaohongshu_upload_error.png")
                return False
            
            # 等待图片上传完成
            await asyncio.sleep(3)
            
            # 填写标题
            print("正在填写标题...")
            title_input = await page.query_selector('input[placeholder*="标题"]')
            if title_input:
                await title_input.fill(title)
                print("标题填写成功")
            else:
                print("未找到标题输入框")
                return False
            
            # 填写正文
            print("正在填写正文...")
            content_input = await page.query_selector('div[contenteditable="true"]')
            if not content_input:
                content_input = await page.query_selector('textarea[placeholder*="正文"]')
            
            if content_input:
                await content_input.fill(content)
                print("正文填写成功")
            else:
                print("未找到正文输入框")
                return False
            
            # 添加话题标签
            if tags:
                print("正在添加话题标签...")
                # 直接在正文中添加话题标签
                tag_text = " " + " ".join([f"#{tag}" for tag in tags])
                await content_input.fill(content + tag_text)
                print("话题标签添加成功")
            
            # 等待页面稳定
            await asyncio.sleep(2)
            
            # 发布
            print("正在发布笔记...")
            publish_btn = await page.query_selector('button:has-text("发布")')
            if not publish_btn:
                publish_btn = await page.query_selector('button:has-text("发布笔记")')
            
            if publish_btn:
                await publish_btn.click()
                print("发布按钮点击成功")
            else:
                print("未找到发布按钮")
                return False
            
            # 等待发布完成
            print("等待发布完成...")
            try:
                await page.wait_for_url("**/manage**", timeout=30000)
                print("✓ 发布成功!")
                return True
            except:
                # 检查是否有发布成功的提示
                success_alert = await page.query_selector('text=发布成功')
                if success_alert:
                    print("✓ 发布成功!")
                    return True
                else:
                    print("发布可能失败，正在检查状态...")
                    return False
                    
        except Exception as e:
            print(f"发布过程中出现错误: {e}")
            # 截图保存以便调试
            await page.screenshot(path="xiaohongshu_error.png")
            print("错误截图已保存为 xiaohongshu_error.png")
            return False
        finally:
            await browser.close()

async def main():
    """
    主函数
    """
    # 配置参数
    images = [r"d:\网站\longxiashequ\ai_finance_cover_new.png"]
    title = "AI金融科技：未来金融的新引擎"
    content = "AI金融科技正在重塑整个金融行业的格局。从智能投顾到风险管理，从客户服务到市场分析，人工智能技术的应用无处不在。\n\n**AI在金融领域的主要应用：**\n\n• 智能投顾：基于算法为投资者提供个性化的投资建议\n• 风险管理：实时监控市场风险，预测潜在危机\n• 客户服务：智能客服24小时响应客户需求\n• 欺诈检测：利用机器学习识别异常交易行为\n• 市场分析：处理海量数据，发现市场趋势\n\n**如何利用AI提升金融服务：**\n\n1. 数据驱动决策：收集并分析客户数据，提供更精准的金融产品\n2. 自动化流程：减少人工操作，提高效率降低成本\n3. 个性化服务：根据客户行为和偏好提供定制化方案\n4. 实时监控：随时掌握市场动态和风险变化\n\n**未来趋势：**\n\n• 区块链与AI的结合，打造更安全的金融生态\n• 量子计算在金融建模中的应用\n• 智能合约的广泛应用\n• 金融科技与传统金融机构的深度融合"
    tags = ["AI金融", "金融科技", "人工智能", "投资", "风险管理"]
    
    # 执行发布
    success = await publish_xiaohongshu_note(images, title, content, tags)
    
    if success:
        print("\n🎉 小红书笔记发布成功！")
    else:
        print("\n❌ 小红书笔记发布失败，请检查错误信息。")

if __name__ == "__main__":
    asyncio.run(main())
