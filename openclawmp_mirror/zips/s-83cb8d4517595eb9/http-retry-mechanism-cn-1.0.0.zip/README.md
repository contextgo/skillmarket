# HTTP 重试机制（中国大陆优化版）

基于 EvoMap.ai 高评分胶囊 (GDI 64.6) 适配的 HTTP 重试机制 Skill，针对中国大陆网络环境深度优化。

## 核心数据

| 指标 | 数值 |
|------|------|
| 来源胶囊 GDI | 64.6/100 |
| 成功率提升 | ~30% |
| 版本 | 2.0.0 |

## 功能特性

### 1. 指数退避重试 (Exponential Backoff)
- 智能延迟计算，避免下游服务过载
- 支持四种抖动策略：FULL / EQUAL / DECORRELATED / NONE

### 2. 超时控制 (Timeout Handling)
- AbortController 精确控制请求超时
- 支持连接超时和请求超时分离

### 3. 熔断器模式 (Circuit Breaker)
- 防止下游 API 被压垮，实现故障隔离
- 支持 CLOSED / OPEN / HALF_OPEN 三种状态

### 4. 中国大陆网络优化 🇨🇳
- **国内 DNS 优化**：阿里/腾讯/114 DNS
- **智能路由选择**：自动识别国内/海外域名
- **访问海外服务优化**：GitHub、Docker Hub 等

## 适用场景

- 微服务间 HTTP 通信
- 第三方 API 调用（国内/海外）
- 不稳定网络环境下的请求
- 高并发场景下的请求优化
- 中国大陆地区网络环境

## 安装

```bash
openclawmp install skill/@http-retry-mechanism-cn
```

## 快速使用

### 基础使用

```typescript
import { get, post } from 'http-retry-mechanism-cn';

// GET 请求（自动重试）
const data = await get('https://api.example.com/data');

// POST 请求（自动重试）
const result = await post('https://api.example.com/users', {
  name: '张三'
});
```

### 高级配置

```typescript
import { createHttpClient } from 'http-retry-mechanism-cn';

const client = createHttpClient({
  retry: {
    maxRetries: 5,
    initialDelayMs: 500,
    maxDelayMs: 10000,
    enableJitter: true
  },
  timeout: {
    requestTimeoutMs: 30000,
    connectTimeoutMs: 10000
  },
  enableCircuitBreaker: true
});
```

### 国内网络优化

```typescript
import { getChinaNetworkStats } from 'http-retry-mechanism-cn';

// 查看网络优化状态
console.log(getChinaNetworkStats());
// 自动识别 github.com 需要代理，aliyun.com 直连
```

## 国内网络优化详情

### 国内直连域名
- 阿里云、腾讯云、华为云
- 淘宝、天猫、京东
- 微信、QQ、微博、抖音

### 海外代理域名
- GitHub、Docker Hub
- Google、YouTube
- OpenAI、HuggingFace

## 配置参数

### RetryConfig

| 参数 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| maxRetries | number | 3 | 最大重试次数 |
| initialDelayMs | number | 1000 | 初始延迟（毫秒） |
| maxDelayMs | number | 30000 | 最大延迟（毫秒） |
| backoffMultiplier | number | 2 | 退避乘数 |
| enableJitter | boolean | true | 启用抖动 |

## 技术架构

```
┌─────────────────────────────────────────────────────────────┐
│              HTTP Retry Skill (CN)                          │
├─────────────────────────────────────────────────────────────┤
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │   Client    │  │   Retry     │  │   Circuit Breaker   │  │
│  │   Request   │─▶│   Manager   │─▶│                     │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│         │                │                    │              │
│         ▼                ▼                    ▼              │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │  Timeout    │  │  Jitter     │  │   Connection Pool   │  │
│  │  Controller │  │  Strategy   │  │                     │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│         │                                                    │
│         ▼                                                    │
│  ┌──────────────────────────────────────────────────────┐   │
│  │              中国大陆网络优化层                       │   │
│  │  - DNS 优化 (阿里/腾讯/114 DNS)                      │   │
│  │  - 智能路由 (国内直连/海外代理)                       │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

## 参考来源

- EvoMap 胶囊: sha256:6c8b2bef4652d5113cc802b6995a8e9f5da8b5b1ffe3d6bc639e2ca8ce27edec
- GDI 分数: 64.6/100

## 许可证

MIT License