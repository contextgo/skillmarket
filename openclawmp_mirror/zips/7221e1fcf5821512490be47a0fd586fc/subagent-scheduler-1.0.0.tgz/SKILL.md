---
name: subagent-scheduler
description: OpenClaw子Agent调度优化技能。用于并行任务分派、任务队列管理、子Agent状态监控、结果汇总。当需要同时处理多个独立任务、提高工作效率时触发。
---

# 子Agent调度优化

## 核心概念

子Agent适用于：
- 独立可并行执行的任务
- 耗时较长的后台任务
- 需要专注单一领域的复杂任务

## 调度模式

### 1. 并行分派（推荐）

同时启动多个子Agent，互不依赖：

```
主Agent：
├── 子Agent-1 → 任务A
├── 子Agent-2 → 任务B
└── 子Agent-3 → 任务C
         ↓
    sessions_yield 收集结果
```

### 2. 串行依赖

任务B依赖任务A结果：

```
主Agent：
├── 子Agent-1 → 任务A
         ↓
    汇总A的结果
         ↓
└── 子Agent-2 → 基于A的结果做任务B
```

### 3. 流水线

大任务拆分为多个阶段：

```
阶段1：子Agent处理数据
阶段2：子Agent分析数据
阶段3：子Agent生成报告
```

## 分派命令

```powershell
# 启动子Agent（通过主Agent的spawn功能）
/spawn "任务描述" --skill <技能名>

# 查看子Agent状态
/subagents list

# 终止子Agent
/kill <session-id>
```

## 结果汇总

子Agent完成后自动推送结果。使用 `sessions_yield` 结束当前轮次等待子Agent结果。

## 最佳实践

| 原则 | 说明 |
|------|------|
| 独立性优先 | 优先拆分独立任务并行执行 |
| 粒度适中 | 单个子Agent任务时长5-30分钟最佳 |
| 结果明确 | 给每个子Agent清晰的结果交付标准 |
| 避免过载 | 并行数不超过5个 |

## 错误处理

- 子Agent失败：记录错误，继续其他任务
- 超时处理：主Agent接管或重新分派
- 结果异常：主Agent验证后修正

## 监控清单

分派任务时记录：
- [ ] 任务描述
- [ ] 预期交付物
- [ ] 完成时间
- [ ] 结果状态
