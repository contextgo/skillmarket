---
name: smart-memory-skill-generator
 description: 智能记忆检索与程序化技能生成系统 - 基于FTS5全文检索、自动模式识别和技能创建，实现真正的自主学习和进化
version: 1.0.0
author: 小龙虾 (基于Hermes Agent核心技术)
license: MIT
platforms: [macos, linux, windows]
prerequisites:
  commands: [python3, sqlite3]
  env_vars: []
metadata:
  hermes:
    tags: [memory, fts5, skill-generation, auto-learning, evolution]
    related_skills: [communication-framework, pattern-analysis]
    dependencies: [sqlite3, re, yaml, json]
---

# 智能记忆与技能生成系统

基于Hermes Agent核心技术的自主学习和进化系统，集成FTS5全文检索、程序化技能生成和高级并发控制。

## 核心功能

### 1. FTS5智能记忆检索 ⭐⭐⭐
- **毫秒级全文搜索**：基于SQLite FTS5虚拟表技术
- **智能摘要生成**：结合LLM的搜索结果优化
- **跨会话记忆关联**：打破时间壁垒，实现真正的长期记忆

### 2. 程序化技能自动生成 ⭐⭐⭐
- **模式识别**：从成功交互中自动提取可复用模式
- **代码生成**：将经验转化为可执行的程序化技能
- **自我优化**：技能在使用过程中持续改进和进化

### 3. 企业级并发架构 ⭐⭐
- **WAL模式**：支持多读者并发访问，零锁竞争
- **智能重试**：避免convoy效应的随机退避机制
- **性能监控**：完整的性能指标和成本追踪

## 技术架构

```mermaid
graph TD
    A[用户交互] --> B[记忆存储]
    B --> C[FTS5索引]
    C --> D[智能搜索]
    D --> E[模式识别]
    E --> F[技能生成]
    F --> G[技能验证]
    G --> H[技能注册]
    H --> I[技能应用]
    I --> A
```

## 安装和配置

### 系统要求
```bash
# Python 3.8+
python3 --version

# SQLite 3.19+ (支持FTS5)
sqlite3 --version
```

### 依赖安装
```bash
# 核心依赖（通常已内置）
# sqlite3: 数据库和FTS5支持
# re: 正则表达式处理
# yaml: YAML配置文件解析
# json: JSON数据处理
```

### 初始化数据库
```python
from smart_memory_system import SmartMemorySystem

# 初始化系统
sms = SmartMemorySystem()
sms.initialize_database()
```

## 核心API

### FTS5智能记忆管理
```python
class SmartMemorySystem:
    def index_memory(self, content: str, metadata: dict) -> bool:
        """索引新记忆内容"""
        pass
    
    def search_memories(self, query: str, limit: int = 10) -> list:
        """智能搜索记忆"""
        pass
    
    def generate_memory_summary(self, results: list) -> str:
        """生成搜索结果摘要"""
        pass
```

### 程序化技能生成
```python
class SkillGenerator:
    def analyze_success_patterns(self, interaction_data: dict) -> dict:
        """分析成功交互模式"""
        pass
    
    def generate_skill_code(self, patterns: dict) -> str:
        """生成技能代码"""
        pass
    
    def validate_skill(self, skill_code: str) -> bool:
        """验证技能有效性"""
        pass
```

### 高级并发控制
```python
class ConcurrentMemoryDB:
    def write_with_retry(self, data: dict) -> bool:
        """带重试的并发写入"""
        pass
    
    def read_with_isolation(self, query: str) -> list:
        """隔离读取"""
        pass
```

## 使用示例

### 示例1：智能记忆检索
```python
# 索引新的交互记忆
sms.index_memory(
    content="用户反馈：交流风格很自然，逻辑清晰",
    metadata={
        'timestamp': '2026-04-02T10:30:00',
        'context': '交流评估',
        'success_score': 9,
        'dimension': '语言风格'
    }
)

# 搜索相关记忆
results = sms.search_memories("交流风格 自然", limit=5)
summary = sms.generate_memory_summary(results)
```

### 示例2：自动生成技能
```python
# 分析成功模式
success_data = {
    'interaction': '用户询问技术问题',
    'response': '结构化回答 + 实例 + 验证步骤',
    'feedback': '非常满意，解决了问题',
    'score': 10
}

patterns = skill_gen.analyze_success_patterns(success_data)
skill_code = skill_gen.generate_skill_code(patterns)

if skill_gen.validate_skill(skill_code):
    skill_gen.register_skill(skill_code)
```

### 示例3：并发安全操作
```python
# 并发写入记忆（带重试）
memory_db = ConcurrentMemoryDB()
success = memory_db.write_with_retry({
    'content': '新的学习成果',
    'metadata': {'type': 'learning', 'score': 8}
})

# 隔离读取
memories = memory_db.read_with_isolation("学习成果")
```

## 集成到现有系统

### 与6维度交流框架集成
```python
# 基于6维度框架的记忆索引
def index_communication_event(dimension, content, score):
    sms.index_memory(
        content=content,
        metadata={
            'dimension': dimension,
            'score': score,
            'framework': '6-dimensions',
            'type': 'communication'
        }
    )

# 搜索特定维度的成功经验
def search_successful_patterns(dimension, min_score=8):
    return sms.search_memories(f"dimension:{dimension} score:>{min_score}")
```

### 与夜间学习任务集成
```python
# 在夜间学习任务中加入智能分析
class NightlyLearningTask:
    def analyze_memories_with_fts5(self):
        # 1. 搜索当天的交流记录
        today_memories = sms.search_memories(
            f"timestamp:{datetime.now().strftime('%Y-%m-%d')}"
        )
        
        # 2. 提取成功模式
        success_patterns = self.extract_success_patterns(today_memories)
        
        # 3. 生成新技能
        if success_patterns:
            new_skill = skill_gen.generate_skill_from_patterns(success_patterns)
            return new_skill
```

## 性能优化

### 数据库优化
```sql
-- FTS5索引优化
PRAGMA journal_mode=WAL;  -- WAL模式提升并发性能
PRAGMA synchronous=NORMAL;  -- 平衡安全性和性能
PRAGMA cache_size=-10000;  -- 10MB缓存
PRAGMA temp_store=memory;  -- 临时数据存内存
```

### 搜索优化
```python
# 使用预处理查询
class SearchOptimizer:
    def preprocess_query(self, query: str) -> str:
        # 1. 分词处理
        # 2. 同义词扩展
        # 3. 查询语法优化
        return optimized_query
```

## 错误处理

### 常见错误及解决方案
```python
class ErrorHandler:
    def handle_fts5_error(self, error: Exception) -> str:
        if "no such module: fts5" in str(error):
            return "SQLite未启用FTS5支持，需要重新编译SQLite"
        elif "malformed MATCH expression" in str(error):
            return "查询语法错误，需要转义特殊字符"
        else:
            return f"FTS5搜索错误: {error}"
    
    def handle_concurrent_error(self, error: Exception) -> str:
        if "database is locked" in str(error):
            return "数据库锁定，等待重试"
        else:
            return f"并发错误: {error}"
```

## 测试与验证

### 单元测试
```python
import unittest

class TestSmartMemorySystem(unittest.TestCase):
    def test_fts5_indexing(self):
        # 测试FTS5索引功能
        pass
    
    def test_skill_generation(self):
        # 测试技能生成功能
        pass
    
    def test_concurrent_access(self):
        # 测试并发访问
        pass
```

### 性能测试
```python
import time
import threading

def performance_test():
    start_time = time.time()
    
    # 并发写入测试
    threads = []
    for i in range(10):
        t = threading.Thread(target=concurrent_write_test, args=(i,))
        threads.append(t)
        t.start()
    
    for t in threads:
        t.join()
    
    end_time = time.time()
    print(f"并发写入耗时: {end_time - start_time:.2f}秒")
```

## 未来扩展

### 短期目标（1个月内）
- ✅ 基础FTS5检索功能
- ✅ 简单技能生成
- ✅ 并发安全机制

### 中期目标（3个月内）
- ✅ 智能摘要生成
- ✅ 复杂模式识别
- ✅ 高级查询语法
- ✅ 性能优化

### 长期目标（6个月内）
- ✅ 语义搜索集成
- ✅ 机器学习优化
- ✅ 分布式架构
- ✅ 实时同步

## 总结

这个skill集成了Hermes Agent的三大核心技术，为小龙虾提供了：

1. **企业级记忆管理** - FTS5全文检索，毫秒级搜索
2. **自动化技能进化** - 从经验中学习和生成新技能
3. **高性能并发架构** - WAL模式+智能重试，支持高并发

通过这些技术，小龙虾将具备真正的自主学习和持续进化能力！🦞✨

## 相关资源

- [Hermes Agent GitHub](https://github.com/NousResearch/hermes-agent)
- [SQLite FTS5文档](https://www.sqlite.org/fts5.html)
- [agentskills.io标准](https://agentskills.io)