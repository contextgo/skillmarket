#!/usr/bin/env python3
"""
智能记忆与技能生成系统 - 演示脚本
展示FTS5检索、程序化技能生成和并发优化的实际效果
"""

import sys
import os
import time
import threading
from datetime import datetime
from pathlib import Path

# 添加当前目录到Python路径
sys.path.insert(0, str(Path(__file__).parent))

from smart_memory_system import SmartMemorySystem, MemoryEntry
from tools import (
    memory_index_tool,
    memory_search_tool,
    skill_generation_tool,
    system_stats_tool,
    analyze_communication_patterns
)

def print_demo_header(title):
    """打印演示标题"""
    print(f"\n{'='*60}")
    print(f"🦞 {title}")
    print(f"{'='*60}")

def demo_fts5_memory_system():
    """演示FTS5记忆系统"""
    print_demo_header("FTS5全文检索系统演示")
    
    # 初始化系统
    sms = SmartMemorySystem("demo_smart_memory.db")
    
    # 添加测试记忆（模拟真实的交流记录）
    test_memories = [
        {
            'content': '用户反馈：小龙虾的交流风格很自然，回答问题逻辑清晰，特别是技术问题的分析很有条理',
            'context': {'type': 'user_feedback', 'session': 'tech_discussion', 'user_mood': 'satisfied'},
            'success_score': 9,
            'dimension': '逻辑思维'
        },
        {
            'content': '交流评估：语言适应性强，能根据用户的技术水平调整表达方式，举例恰当',
            'context': {'type': 'evaluation', 'session': 'communication_review', 'complexity': 'adaptive'},
            'success_score': 8,
            'dimension': '语境适应'
        },
        {
            'content': '用户表示：回复很有耐心，理解准确，情感表达恰到好处，让人感到被理解',
            'context': {'type': 'feedback', 'session': 'support_interaction', 'emotion': 'positive'},
            'success_score': 10,
            'dimension': '情感表达'
        },
        {
            'content': '技术问题解决：结构化思考，分步骤分析，提供验证方法，用户问题得到圆满解决',
            'context': {'type': 'problem_solving', 'session': 'tech_support', 'outcome': 'resolved'},
            'success_score': 9,
            'dimension': '逻辑思维'
        },
        {
            'content': '文化适应良好：考虑到用户的背景和需求，表达方式得体，文化敏感度高的回应',
            'context': {'type': 'cultural_adaptation', 'session': 'diverse_user', 'cultural_context': 'considered'},
            'success_score': 8,
            'dimension': '文化适应'
        }
    ]
    
    print("📚 正在索引测试记忆...")
    for i, memory in enumerate(test_memories, 1):
        success = sms.add_memory(**memory)
        print(f"  记忆{i}索引: {'✅' if success else '❌'}")
    
    print("\n🔍 演示FTS5智能搜索:")
    
    # 测试1: 基础关键词搜索
    print("\n1. 搜索'交流风格 自然':")
    results = sms.search_memories("交流风格 OR 自然", limit=3)
    for result in results:
        print(f"  📄 {result['content'][:100]}...")
        print(f"     评分: {result['success_score']}, 维度: {result['dimension']}")
    
    # 测试2: 高评分过滤搜索
    print("\n2. 高评分搜索(≥9分):")
    high_score_results = sms.search_memories("技术 OR 问题", min_score=9, limit=5)
    print(f"  找到 {len(high_score_results)} 条高评分记忆")
    for result in high_score_results:
        print(f"  ⭐ {result['content'][:80]}... (评分: {result['success_score']})")
    
    # 测试3: 维度特定搜索
    print("\n3. 逻辑思维维度搜索:")
    dimension_results = sms.search_memories("问题 OR 分析", dimension="逻辑思维", limit=3)
    print(f"  逻辑思维维度找到 {len(dimension_results)} 条记忆")
    for result in dimension_results:
        print(f"  🧠 {result['content'][:80]}...")
    
    # 显示统计信息
    print("\n📊 系统统计:")
    stats = sms.get_system_stats()
    for key, value in stats.items():
        print(f"  {key}: {value}")

def demo_concurrent_performance():
    """演示并发性能"""
    print_demo_header("并发性能演示")
    
    sms = SmartMemorySystem("demo_concurrent.db")
    
    def worker_task(worker_id, num_operations):
        """工作线程任务"""
        success_count = 0
        for i in range(num_operations):
            success = sms.add_memory(
                content=f"并发测试记忆 - 工作线程{worker_id} - 操作{i}",
                context={
                    'worker_id': worker_id,
                    'operation_id': i,
                    'timestamp': datetime.now().isoformat()
                },
                success_score=8,
                dimension="并发测试"
            )
            if success:
                success_count += 1
        
        return success_count
    
    print("⚡ 并发写入测试 (5个线程，每个20次操作):")
    
    # 创建并启动线程
    threads = []
    results = [0] * 5  # 存储每个线程的结果
    
    start_time = time.time()
    
    for i in range(5):
        thread = threading.Thread(
            target=lambda idx: results.__setitem__(idx, worker_task(idx, 20)),
            args=(i,)
        )
        threads.append(thread)
        thread.start()
    
    # 等待所有线程完成
    for thread in threads:
        thread.join()
    
    end_time = time.time()
    
    total_success = sum(results)
    total_operations = 5 * 20
    success_rate = (total_success / total_operations) * 100
    
    print(f"  总操作数: {total_operations}")
    print(f"  成功数: {total_success}")
    print(f"  成功率: {success_rate:.1f}%")
    print(f"  总耗时: {end_time - start_time:.2f}秒")
    print(f"  平均每秒操作: {total_operations/(end_time - start_time):.1f}")

def demo_skill_generation():
    """演示技能生成"""
    print_demo_header("程序化技能生成演示")
    
    # 使用工具接口
    print("🤖 正在基于成功经验生成技能...")
    
    result = skill_generation_tool(
        auto_generate=True,
        memory_filter="交流效果 成功"
    )
    
    if result['success'] and result['skill_code']:
        print("✅ 技能生成成功！")
        print(f"📊 分析了 {result['memory_count']} 条成功经验")
        print(f"🔧 生成技能代码长度: {len(result['skill_code'])} 字符")
        
        # 显示生成的技能代码片段
        print("\n📝 生成的技能代码预览:")
        lines = result['skill_code'].split('\n')
        for i, line in enumerate(lines[:15]):  # 显示前15行
            print(f"  {i+1:2d}: {line}")
        if len(lines) > 15:
            print(f"  ... ({len(lines)-15} 行更多代码)")
        
        # 显示识别的模式
        if result['patterns']:
            print("\n🎯 识别的成功模式:")
            for dimension, pattern in result['patterns'].items():
                if dimension != 'common':
                    print(f"  {dimension}: {pattern.get('sample_count', 0)} 个样本")
    else:
        print(f"❌ 技能生成失败: {result.get('message', '未知错误')}")

def demo_tool_integration():
    """演示工具集成"""
    print_demo_header("工具集成演示")
    
    print("🔧 使用工具接口进行高级分析...")
    
    # 使用高级分析工具
    analysis_result = analyze_communication_patterns(
        dimension=None,  # 分析所有维度
        days=30  # 分析最近30天
    )
    
    if analysis_result['success']:
        print("✅ 交流模式分析完成")
        print(f"📊 分析了 {analysis_result['memory_count']} 条记忆")
        
        patterns = analysis_result['patterns']
        if patterns:
            print("\n🎯 发现的主要模式:")
            for dimension, pattern in patterns.items():
                if dimension != 'common' and pattern.get('sample_count', 0) > 0:
                    print(f"  {dimension}:")
                    print(f"    样本数: {pattern['sample_count']}")
                    print(f"    平均评分: {pattern.get('average_score', 0):.1f}")
                    if 'key_elements' in pattern:
                        print(f"    关键要素: {', '.join(pattern['key_elements'][:5])}")
    else:
        print(f"❌ 分析失败: {analysis_result.get('error', '未知错误')}")

def demo_performance_benchmark():
    """演示性能基准测试"""
    print_demo_header("性能基准测试")
    
    sms = SmartMemorySystem("benchmark.db")
    
    print("📈 性能基准测试:")
    
    # 测试1: 单条记忆索引性能
    print("\n1. 单条记忆索引性能:")
    start_time = time.time()
    for i in range(100):
        sms.add_memory(
            content=f"基准测试记忆 {i} - 交流效果评估数据",
            context={"test_id": i, "type": "benchmark"},
            success_score=8,
            dimension="性能测试"
        )
    index_time = time.time() - start_time
    print(f"  索引100条记忆耗时: {index_time:.3f}秒")
    print(f"  平均每条耗时: {index_time/100*1000:.1f}ms")
    
    # 测试2: 搜索性能
    print("\n2. 搜索性能测试:")
    test_queries = ["交流效果", "用户满意", "逻辑清晰", "技术问题", "情感表达"]
    
    for query in test_queries:
        start_time = time.time()
        results = sms.search_memories(query, limit=10)
        search_time = time.time() - start_time
        print(f"  搜索'{query}': {search_time*1000:.1f}ms (找到{len(results)}条结果)")
    
    # 测试3: 统计信息获取性能
    print("\n3. 统计信息获取性能:")
    start_time = time.time()
    stats = sms.get_system_stats()
    stats_time = time.time() - start_time
    print(f"  获取统计信息耗时: {stats_time*1000:.1f}ms")
    print(f"  当前记忆总数: {stats.get('total_memories', 0)}")
    
    # 显示最终统计
    print(f"\n📊 最终系统统计:")
    final_stats = sms.get_system_stats()
    for key, value in final_stats.items():
        if isinstance(value, (int, float)):
            print(f"  {key}: {value}")

def main():
    """主演示函数"""
    print("🦞 小龙虾智能记忆与技能生成系统 - 完整演示")
    print("="*70)
    print("基于Hermes Agent核心技术：FTS5 + 自动技能生成 + WAL并发控制")
    print("="*70)
    
    try:
        # 运行所有演示
        demo_fts5_memory_system()
        demo_concurrent_performance()
        demo_skill_generation()
        demo_tool_integration()
        demo_performance_benchmark()
        
        print_demo_header("演示总结")
        print("✅ 所有演示完成！")
        print("\n🎯 系统核心能力验证:")
        print("  ✅ FTS5全文检索：毫秒级搜索，智能过滤")
        print("  ✅ 并发写入：多线程安全，高成功率")
        print("  ✅ 自动技能生成：基于成功经验，代码自动生成")
        print("  ✅ 高级分析工具：模式识别，优化建议")
        print("  ✅ 性能基准：高效索引，快速搜索")
        
        print(f"\n🚀 系统已准备就绪！")
        print("   可以集成到现有的OpenClaw环境中")
        print("   为小龙虾提供真正的自主学习和进化能力！")
        
    except Exception as e:
        print(f"\n❌ 演示过程中出现错误: {e}")
        import traceback
        traceback.print_exc()
        return 1
    
    return 0

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)