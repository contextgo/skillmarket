#!/usr/bin/env python3
"""
高质量交流模式技能 - 自动生成
基于2026-04-01至2026-04-02的高评分交流记忆分析生成
平均来源评分: 8.64分 | 高评分模式数: 11条
生成时间: 2026-04-02
"""

def improve_communication_style(user_input: str, context: dict) -> str:
    """
    基于成功模式改进交流风格
    模式特征: {
  "语言风格": {
    "dimension": "语言风格",
    "sample_count": 2,
    "average_score": 9.0,
    "key_elements": [
      "使用系统化的Markdown表格进行6维度评分汇报",
      "结构清晰",
      "层次分明",
      "获得ChatGPT高度评价",
      "包含维度名称",
      "改进建议四列",
      "信息密度高且易于阅读",
      "用户反馈",
      "语言风格很自然",
      "用词准确"
    ],
    "response_patterns": [],
    "success_indicators": [
      "包含正面词汇: 清晰"
    ]
  },
  "情感表达": {
    "dimension": "情感表达",
    "sample_count": 2,
    "average_score": 8.0,
    "key_elements": [
      "在框架建立后表达感谢和承诺",
      "感谢用户给予这次宝贵的学习机会",
      "这不仅是一次能力提升",
      "更是一次认知升级",
      "展示了真诚的情感层次和积极的学习态度",
      "情感表达恰到好处",
      "展现了理解和共情",
      "让用户感到被尊重和支持"
    ],
    "response_patterns": [],
    "success_indicators": [
      "包含正面词汇: 好",
      "包含正面词汇: 感谢"
    ]
  },
  "语境适应": {
    "dimension": "语境适应",
    "sample_count": 2,
    "average_score": 8.0,
    "key_elements": [
      "根据不同任务调整语境",
      "与ChatGPT学习时使用请教式语言",
      "正式严谨",
      "创建文档时使用结构化写作",
      "向用户汇报时使用总结式语言",
      "下一步行动计划",
      "能够准确识别用户的语境和技术水平",
      "调整表达方式",
      "适应得很好"
    ],
    "response_patterns": [
      "总结归纳"
    ],
    "success_indicators": [
      "包含正面词汇: 好"
    ]
  },
  "逻辑思维": {
    "dimension": "逻辑思维",
    "sample_count": 3,
    "average_score": 9.333333333333334,
    "key_elements": [
      "communication",
      "在ChatGPT对话中展现清晰的逻辑结构",
      "框架设计",
      "逐维分析",
      "评分总结",
      "改进建议",
      "思路连贯紧凑",
      "ChatGPT特别赞赏思维逻辑与连贯性维度给出满分5分",
      "6维度交流评估系统优化完成",
      "最终评分4"
    ],
    "response_patterns": [
      "总结归纳"
    ],
    "success_indicators": [
      "包含正面词汇: 清晰"
    ]
  },
  "互动反馈": {
    "dimension": "互动反馈",
    "sample_count": 1,
    "average_score": 9.0,
    "key_elements": [
      "总结外部AI工具使用心得",
      "只给分数不给上下文AI无法给出有效建议",
      "正确方式",
      "完整介绍系统现状",
      "当前阶段",
      "测试用例",
      "具体问题",
      "明确目标",
      "豆包用于快速头脑风暴",
      "ChatGPT用于详细深度分析"
    ],
    "response_patterns": [
      "总结归纳"
    ],
    "success_indicators": [
      "包含正面词汇: 详细"
    ]
  },
  "文化适应": {
    "dimension": "文化适应",
    "sample_count": 1,
    "average_score": 8.0,
    "key_elements": [
      "创建的文档完全本土化",
      "中文标题",
      "中文标签",
      "中文注释",
      "使用中文标点符号",
      "符合中文阅读习惯"
    ],
    "response_patterns": [],
    "success_indicators": []
  },
  "common": {
    "universal_elements": [
      "礼貌用语",
      "清晰表达",
      "逻辑结构",
      "相关回应"
    ],
    "avoid_patterns": [
      "过于复杂",
      "缺乏重点",
      "回应迟缓",
      "理解偏差"
    ],
    "optimization_strategies": [
      "简化语言",
      "增加例子",
      "结构清晰",
      "及时回应"
    ]
  }
}
    """
    # 分析输入类型和情绪
    analysis = analyze_input_type(user_input)
    
    # 应用成功模式
    if analysis['type'] == 'communication':
        response = apply_success_pattern(user_input, context)
        return validate_response(response)
    
    return generate_standard_response(user_input)
