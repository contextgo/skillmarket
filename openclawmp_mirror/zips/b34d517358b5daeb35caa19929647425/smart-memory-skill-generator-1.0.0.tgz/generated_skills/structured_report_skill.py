
#!/usr/bin/env python3
"""
structured_report_skill - 结构化汇报技能
基于FTS5分析识别的高评分模式生成
核心模式: Markdown表格 + 四段式逻辑 + 信息完整原则
来源: 6维度框架学习(2026-04-01) + 评估系统优化(2026-04-02)
"""

def structured_report_template(data: dict) -> str:
    """
    生成结构化汇报内容
    适用于: 评估报告、学习总结、项目汇报
    
    模板结构:
    1. 核心成果（一句话概括）
    2. 详细数据（Markdown表格）
    3. 关键突破（技术/方法论）
    4. 下一步计划（具体行动）
    """
    report = []
    report.append(f"## {data.get('title', '汇报标题')}")
    report.append("")
    report.append(data.get('summary', '核心成果简述'))
    report.append("")
    
    if 'table' in data:
        report.append("| 维度 | 数值 | 说明 |")
        report.append("|------|------|------|")
        for row in data['table']:
            report.append(f"| {row[0]} | {row[1]} | {row[2]} |")
        report.append("")
    
    if 'breakthrough' in data:
        report.append("### 核心技术突破")
        for item in data['breakthrough']:
            report.append(f"- {item}")
        report.append("")
    
    if 'next_steps' in data:
        report.append("### 下一步行动")
        for step in data['next_steps']:
            report.append(f"- [ ] {step}")
        report.append("")
    
    return "\n".join(report)


def external_ai_communication_prompt(system_status: dict, phase: str, 
                                      test_data: list, problem: str, 
                                      goal: str) -> str:
    """
    构建给外部AI的完整沟通prompt
    避免"只给分数不给上下文"的无效沟通
    
    Args:
        system_status: 系统现状描述
        phase: 当前阶段(基线评估/优化/测试)
        test_data: 测试数据或案例
        problem: 具体问题描述
        goal: 明确目标
    """
    prompt = f"""【系统现状】
{json.dumps(system_status, ensure_ascii=False, indent=2)}

【当前阶段】
{phase}

【测试数据/案例】
{json.dumps(test_data, ensure_ascii=False, indent=2)}

【具体问题】
{problem}

【明确目标】
{goal}

请基于以上完整信息给出针对性建议。"""
    return prompt


# 技能元数据
SKILL_METADATA = {
    "name": "structured_report_skill",
    "version": "1.0.0",
    "source": "FTS5 smart memory analysis",
    "generation_date": "2026-04-02",
    "avg_source_score": 8.64,
    "dimensions": {
        "语言风格": "Markdown表格+结构化层次",
        "逻辑思维": "四段式框架+数据驱动",
        "互动反馈": "信息完整原则"
    },
    "patterns": [
        "框架设计→逐维分析→评分总结→改进建议",
        "信息完整性: 现状+阶段+数据+问题+目标",
        "多文档体系: 理论+操作+记录+记忆"
    ]
}

if __name__ == "__main__":
    # 测试技能
    test_data = {
        "title": "6维度交流能力提升报告",
        "summary": "评估系统优化完成，最终评分4.64/5.0，超过4.55目标",
        "table": [
            ["语言风格", "4.83", "从3.45提升，句式向量优化"],
            ["情感表达", "4.62", "236词库+强度分级"],
            ["总体", "4.64", "超过4.55目标"]
        ],
        "breakthrough": [
            "语言风格: 5分类→6维向量+余弦相似度",
            "情感表达: 20词→236词库"
        ],
        "next_steps": [
            "日常应用新评分算法",
            "持续优化各维度得分"
        ]
    }
    print(structured_report_template(test_data))
