#!/usr/bin/env python3
"""
智能记忆与技能生成系统 - 核心实现
基于Hermes Agent的核心技术：FTS5全文检索、程序化技能生成、WAL并发控制
"""

import sqlite3
import json
import time
import threading
import re
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass
from contextlib import contextmanager

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

@dataclass
class MemoryEntry:
    """记忆条目数据结构"""
    content: str
    timestamp: str
    context: Dict[str, Any]
    success_score: Optional[int] = None
    dimension: Optional[str] = None

@dataclass
class SkillPattern:
    """技能模式数据结构"""
    pattern_type: str
    description: str
    code_template: str
    validation_rules: List[str]

class FTS5MemoryEngine:
    """
    FTS5全文检索引擎
    基于Hermes Agent的session_search_tool.py实现
    """
    
    def __init__(self, db_path: str = "smart_memory.db"):
        self.db_path = Path(db_path)
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_database()
    
    def _init_database(self):
        """初始化FTS5数据库"""
        with self._get_connection() as conn:
            # 创建主表
            conn.execute("""
                CREATE TABLE IF NOT EXISTS memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    content TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    context TEXT,  -- JSON格式
                    success_score INTEGER,
                    dimension TEXT,
                    created_at REAL DEFAULT (strftime('%s', 'now'))
                )
            """)
            
            # 创建FTS5虚拟表
            conn.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
                    content,
                    content='memories',
                    content_rowid='id'
                )
            """)
            
            # 创建触发器维护FTS5索引
            conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_fts_insert AFTER INSERT ON memories BEGIN
                    INSERT INTO memories_fts(rowid, content) VALUES (new.id, new.content);
                END
            """)
            
            conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_fts_delete AFTER DELETE ON memories BEGIN
                    INSERT INTO memories_fts(memories_fts, rowid, content) VALUES('delete', old.id, old.content);
                END
            """)
            
            conn.execute("""
                CREATE TRIGGER IF NOT EXISTS memories_fts_update AFTER UPDATE ON memories BEGIN
                    INSERT INTO memories_fts(memories_fts, rowid, content) VALUES('delete', old.id, old.content);
                    INSERT INTO memories_fts(rowid, content) VALUES (new.id, new.content);
                END
            """)
            
            # 创建索引优化查询性能
            conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_timestamp ON memories(timestamp)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_dimension ON memories(dimension)")
            conn.execute("CREATE INDEX IF NOT EXISTS idx_memories_score ON memories(success_score)")
            
            conn.commit()
            logger.info("FTS5数据库初始化完成")
    
    @contextmanager
    def _get_connection(self):
        """获取数据库连接（上下文管理器）"""
        conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        try:
            # 启用WAL模式提升并发性能（学习Hermes的优化）
            conn.execute("PRAGMA journal_mode=WAL")
            conn.execute("PRAGMA synchronous=NORMAL")
            conn.execute("PRAGMA cache_size=-10000")  # 10MB缓存
            yield conn
        finally:
            conn.close()
    
    def index_memory(self, memory: MemoryEntry) -> bool:
        """索引新记忆（模仿Hermes的session存储）"""
        try:
            with self._get_connection() as conn:
                cursor = conn.execute("""
                    INSERT INTO memories (content, timestamp, context, success_score, dimension)
                    VALUES (?, ?, ?, ?, ?)
                """, (
                    memory.content,
                    memory.timestamp,
                    json.dumps(memory.context),
                    memory.success_score,
                    memory.dimension
                ))
                conn.commit()
                
                memory_id = cursor.lastrowid
                logger.info(f"记忆已索引: ID={memory_id}, 维度={memory.dimension}")
                return True
        except Exception as e:
            logger.error(f"记忆索引失败: {e}")
            return False
    
    def search_memories(self, query: str, limit: int = 10, 
                       min_score: Optional[int] = None,
                       dimension: Optional[str] = None) -> List[Dict[str, Any]]:
        """智能搜索记忆（核心功能，模仿Hermes的FTS5搜索）"""
        try:
            with self._get_connection() as conn:
                # 先执行FTS5搜索获取匹配的记忆ID
                fts_query = f"""
                    SELECT rowid, rank
                    FROM memories_fts
                    WHERE memories_fts MATCH ?
                    ORDER BY rank
                    LIMIT 1000
                """
                
                fts_cursor = conn.execute(fts_query, (query,))
                matched_ids = [row[0] for row in fts_cursor.fetchall()]
                
                if not matched_ids:
                    return []
                
                # 构建ID列表用于主查询
                id_placeholders = ','.join(['?' for _ in matched_ids])
                
                # 主查询：获取完整记忆信息并应用过滤条件
                main_conditions = [f"m.id IN ({id_placeholders})"]
                main_params = matched_ids.copy()
                
                if min_score is not None:
                    main_conditions.append("m.success_score >= ?")
                    main_params.append(min_score)
                
                if dimension is not None:
                    main_conditions.append("m.dimension = ?")
                    main_params.append(dimension)
                
                where_clause = " AND ".join(main_conditions)
                
                # 执行主查询
                main_sql = f"""
                    SELECT m.id, m.content, m.timestamp, m.context, 
                           m.success_score, m.dimension
                    FROM memories m
                    WHERE {where_clause}
                    ORDER BY m.id
                    LIMIT ?
                """
                main_params.append(limit)
                
                main_cursor = conn.execute(main_sql, main_params)
                results = []
                
                for row in main_cursor.fetchall():
                    results.append({
                        'id': row[0],
                        'content': row[1],
                        'timestamp': row[2],
                        'context': json.loads(row[3]) if row[3] else {},
                        'success_score': row[4],
                        'dimension': row[5]
                    })
                
                logger.info(f"搜索完成: 查询='{query}', 结果数={len(results)}")
                return results
                
        except Exception as e:
            logger.error(f"记忆搜索失败: {e}")
            return []
    
    def get_memory_stats(self) -> Dict[str, Any]:
        """获取记忆统计信息"""
        try:
            with self._get_connection() as conn:
                stats = {}
                
                # 总记忆数
                cursor = conn.execute("SELECT COUNT(*) FROM memories")
                stats['total_memories'] = cursor.fetchone()[0]
                
                # 维度分布
                cursor = conn.execute("""
                    SELECT dimension, COUNT(*) as count 
                    FROM memories 
                    WHERE dimension IS NOT NULL 
                    GROUP BY dimension
                """)
                stats['dimension_distribution'] = dict(cursor.fetchall())
                
                # 平均成功率
                cursor = conn.execute("SELECT AVG(success_score) FROM memories WHERE success_score IS NOT NULL")
                avg_score = cursor.fetchone()[0]
                stats['average_success_score'] = round(avg_score, 2) if avg_score else 0
                
                # 时间范围
                cursor = conn.execute("SELECT MIN(timestamp), MAX(timestamp) FROM memories")
                min_time, max_time = cursor.fetchone()
                stats['time_range'] = {'start': min_time, 'end': max_time}
                
                return stats
        except Exception as e:
            logger.error(f"获取统计信息失败: {e}")
            return {}

class SkillGenerator:
    """
    程序化技能生成器
    基于Hermes Agent的技能生成机制，结合6维度交流框架
    """
    
    def __init__(self):
        self.pattern_templates = self._load_pattern_templates()
        self.skill_templates = self._load_skill_templates()
    
    def _load_pattern_templates(self) -> Dict[str, Any]:
        """加载模式识别模板"""
        return {
            'communication_success': {
                'indicators': ['用户满意', '问题解决', '反馈积极', '评分高'],
                'weight': 1.0
            },
            'logical_structure': {
                'indicators': ['结构化', '分步骤', '清晰', '有条理'],
                'weight': 0.9
            },
            'emotional_intelligence': {
                'indicators': ['共情', '理解', '耐心', '鼓励'],
                'weight': 0.8
            }
        }
    
    def _load_skill_templates(self) -> Dict[str, Any]:
        """加载技能代码模板"""
        return {
            'communication_response': {
                'template': '''
def improve_communication_style(user_input: str, context: dict) -> str:
    """
    基于成功模式改进交流风格
    模式特征: {pattern_features}
    """
    # 分析输入类型和情绪
    analysis = analyze_input_type(user_input)
    
    # 应用成功模式
    if analysis['type'] == '{pattern_type}':
        response = apply_success_pattern(user_input, context)
        return validate_response(response)
    
    return generate_standard_response(user_input)
''',
                'validation_rules': ['代码语法正确', '函数可调用', '参数处理完整']
            }
        }
    
    def analyze_success_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """分析成功记忆模式（核心算法）"""
        try:
            # 筛选高评分记忆
            high_score_memories = [
                m for m in memories 
                if m.get('success_score', 0) >= 8
            ]
            
            if not high_score_memories:
                logger.warning("没有找到高评分记忆用于模式分析")
                return {}
            
            patterns = {}
            
            # 分析6维度框架中的成功模式
            for dimension in ['语言风格', '情感表达', '语境适应', '逻辑思维', '互动反馈', '文化适应']:
                dimension_memories = [
                    m for m in high_score_memories 
                    if m.get('dimension') == dimension
                ]
                
                if dimension_memories:
                    pattern = self._extract_dimension_pattern(dimension_memories, dimension)
                    patterns[dimension] = pattern
            
            # 提取通用成功要素
            common_patterns = self._extract_common_patterns(high_score_memories)
            patterns['common'] = common_patterns
            
            logger.info(f"成功模式分析完成: 发现{len(patterns)}个维度模式")
            return patterns
            
        except Exception as e:
            logger.error(f"模式分析失败: {e}")
            return {}
    
    def _extract_dimension_pattern(self, memories: List[Dict[str, Any]], dimension: str) -> Dict[str, Any]:
        """提取特定维度的成功模式"""
        contents = [m['content'] for m in memories]
        
        # 简单的关键词和模式提取
        pattern = {
            'dimension': dimension,
            'sample_count': len(memories),
            'average_score': sum(m.get('success_score', 0) for m in memories) / len(memories),
            'key_elements': self._extract_key_elements(contents),
            'response_patterns': self._extract_response_patterns(contents),
            'success_indicators': self._identify_success_indicators(contents)
        }
        
        return pattern
    
    def _extract_common_patterns(self, memories: List[Dict[str, Any]]) -> Dict[str, Any]:
        """提取通用成功模式"""
        contents = [m['content'] for m in memories]
        
        return {
            'universal_elements': self._extract_universal_elements(contents),
            'avoid_patterns': self._extract_avoid_patterns(contents),
            'optimization_strategies': self._extract_optimization_strategies(contents)
        }
    
    def _extract_key_elements(self, contents: List[str]) -> List[str]:
        """提取关键要素"""
        # 简化的关键词提取
        all_text = ' '.join(contents)
        words = re.findall(r'\b\w+\b', all_text)
        
        # 统计词频（简单实现）
        word_freq = {}
        for word in words:
            if len(word) > 2:  # 过滤短词
                word_freq[word] = word_freq.get(word, 0) + 1
        
        # 返回高频词
        sorted_words = sorted(word_freq.items(), key=lambda x: x[1], reverse=True)
        return [word for word, freq in sorted_words[:10]]
    
    def _extract_response_patterns(self, contents: List[str]) -> List[str]:
        """提取回应模式"""
        patterns = []
        
        for content in contents:
            # 识别常见的回应结构
            if '首先' in content and '其次' in content:
                patterns.append('结构化分点回应')
            if '例如' in content or '比如' in content:
                patterns.append('举例说明')
            if '总结' in content or '概括' in content:
                patterns.append('总结归纳')
        
        return list(set(patterns))  # 去重
    
    def _identify_success_indicators(self, contents: List[str]) -> List[str]:
        """识别成功指标"""
        indicators = []
        
        positive_words = ['好', '棒', '优秀', '满意', '感谢', '有用', '清晰', '详细']
        for content in contents:
            for word in positive_words:
                if word in content:
                    indicators.append(f"包含正面词汇: {word}")
        
        return list(set(indicators))
    
    def _extract_universal_elements(self, contents: List[str]) -> List[str]:
        """提取通用要素"""
        return ['礼貌用语', '清晰表达', '逻辑结构', '相关回应']
    
    def _extract_avoid_patterns(self, contents: List[str]) -> List[str]:
        """提取需要避免的模式"""
        # 分析失败或低评分的情况
        return ['过于复杂', '缺乏重点', '回应迟缓', '理解偏差']
    
    def _extract_optimization_strategies(self, contents: List[str]) -> List[str]:
        """提取优化策略"""
        return ['简化语言', '增加例子', '结构清晰', '及时回应']
    
    def generate_skill_from_patterns(self, patterns: Dict[str, Any]) -> Optional[str]:
        """基于模式生成技能代码"""
        try:
            if not patterns:
                return None
            
            # 选择最合适的模板
            template_key = 'communication_response'
            template = self.skill_templates[template_key]['template']
            
            # 填充模板
            skill_code = template.format(
                pattern_features=json.dumps(patterns, ensure_ascii=False, indent=2),
                pattern_type='communication'
            )
            
            logger.info(f"生成了基于模式的技能代码，长度: {len(skill_code)}字符")
            return skill_code
            
        except Exception as e:
            logger.error(f"技能代码生成失败: {e}")
            return None
    
    def validate_skill(self, skill_code: str) -> bool:
        """验证生成的技能代码"""
        try:
            # 基础语法检查
            compile(skill_code, '<string>', 'exec')
            
            # 检查必要的函数定义
            if 'def ' not in skill_code:
                return False
            
            # 检查关键要素
            required_elements = ['analyze', 'apply', 'validate']
            for element in required_elements:
                if element not in skill_code:
                    logger.warning(f"技能代码缺少必要元素: {element}")
                    return False
            
            logger.info("技能代码验证通过")
            return True
            
        except SyntaxError as e:
            logger.error(f"技能代码语法错误: {e}")
            return False
        except Exception as e:
            logger.error(f"技能代码验证失败: {e}")
            return False

class ConcurrentMemoryDB:
    """
    并发安全的数据库操作
    基于Hermes Agent的WAL并发控制机制
    """
    
    # 写操作重试配置（学习Hermes的优化策略）
    _WRITE_MAX_RETRIES = 15
    _WRITE_RETRY_MIN_S = 0.020   # 20ms
    _WRITE_RETRY_MAX_S = 0.150   # 150ms
    _CHECKPOINT_EVERY_N_WRITES = 50
    
    def __init__(self, db_path: str = "smart_memory.db"):
        self.db_path = Path(db_path)
        self._write_count = 0
        self._lock = threading.Lock()
    
    def write_with_retry(self, data: Dict[str, Any]) -> bool:
        """带重试机制的并发写入（核心功能）"""
        for attempt in range(self._WRITE_MAX_RETRIES):
            try:
                # 使用WAL模式连接
                conn = sqlite3.connect(str(self.db_path), timeout=1)
                conn.execute("PRAGMA journal_mode=WAL")
                
                with conn:
                    # 执行写入操作
                    conn.execute("""
                        INSERT INTO memories (content, timestamp, context, success_score, dimension)
                        VALUES (?, ?, ?, ?, ?)
                    """, (
                        data['content'],
                        data['timestamp'],
                        json.dumps(data.get('context', {})),
                        data.get('success_score'),
                        data.get('dimension')
                    ))
                
                conn.close()
                
                # 更新写入计数
                with self._lock:
                    self._write_count += 1
                    if self._write_count % self._CHECKPOINT_EVERY_N_WRITES == 0:
                        self._checkpoint_wal()
                
                logger.info(f"并发写入成功 (尝试 {attempt + 1})")
                return True
                
            except sqlite3.OperationalError as e:
                if "database is locked" in str(e):
                    # 数据库锁定，使用随机退避重试
                    import random
                    wait_time = random.uniform(self._WRITE_RETRY_MIN_S, self._WRITE_RETRY_MAX_S)
                    logger.warning(f"数据库锁定，等待 {wait_time:.3f}秒后重试 (尝试 {attempt + 1})")
                    time.sleep(wait_time)
                    continue
                else:
                    logger.error(f"数据库操作错误: {e}")
                    return False
            except Exception as e:
                logger.error(f"写入失败: {e}")
                return False
        
        logger.error(f"写入失败，已达到最大重试次数: {self._WRITE_MAX_RETRIES}")
        return False
    
    def _checkpoint_wal(self):
        """WAL检查点优化"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute("PRAGMA wal_checkpoint(PASSIVE)")
            conn.close()
            logger.info("WAL检查点完成")
        except Exception as e:
            logger.warning(f"WAL检查点失败: {e}")
    
    def read_with_isolation(self, query: str, params: Tuple = ()) -> List[Dict[str, Any]]:
        """隔离读取数据"""
        try:
            conn = sqlite3.connect(str(self.db_path))
            conn.execute("PRAGMA journal_mode=WAL")
            
            cursor = conn.execute(query, params)
            columns = [description[0] for description in cursor.description]
            
            results = []
            for row in cursor.fetchall():
                results.append(dict(zip(columns, row)))
            
            conn.close()
            return results
            
        except Exception as e:
            logger.error(f"读取失败: {e}")
            return []

class SmartMemorySystem:
    """
    智能记忆系统主类
    集成FTS5检索、技能生成、并发控制
    """
    
    def __init__(self, db_path: str = "smart_memory.db"):
        self.fts_engine = FTS5MemoryEngine(db_path)
        self.skill_generator = SkillGenerator()
        self.concurrent_db = ConcurrentMemoryDB(db_path)
        logger.info("智能记忆系统初始化完成")
    
    def add_memory(self, content: str, context: Dict[str, Any], 
                   success_score: Optional[int] = None,
                   dimension: Optional[str] = None) -> bool:
        """添加新记忆"""
        memory = MemoryEntry(
            content=content,
            timestamp=datetime.now().isoformat(),
            context=context,
            success_score=success_score,
            dimension=dimension
        )
        
        # 使用并发安全的方式写入
        memory_data = {
            'content': memory.content,
            'timestamp': memory.timestamp,
            'context': memory.context,
            'success_score': memory.success_score,
            'dimension': memory.dimension
        }
        
        return self.concurrent_db.write_with_retry(memory_data)
    
    def search_memories(self, query: str, limit: int = 10,
                       min_score: Optional[int] = None,
                       dimension: Optional[str] = None) -> List[Dict[str, Any]]:
        """搜索记忆"""
        return self.fts_engine.search_memories(query, limit, min_score, dimension)
    
    def generate_skill_from_memories(self, memories: List[Dict[str, Any]]) -> Optional[str]:
        """从记忆中生成技能"""
        patterns = self.skill_generator.analyze_success_patterns(memories)
        skill_code = self.skill_generator.generate_skill_from_patterns(patterns)
        
        if skill_code and self.skill_generator.validate_skill(skill_code):
            logger.info("成功生成并验证技能代码")
            return skill_code
        
        return None
    
    def get_system_stats(self) -> Dict[str, Any]:
        """获取系统统计信息"""
        stats = self.fts_engine.get_memory_stats()
        stats['system_status'] = 'running'
        stats['last_updated'] = datetime.now().isoformat()
        return stats

# 工具函数 - 供其他skill调用
def smart_memory_index(content: str, context: dict, success_score: int = None, dimension: str = None) -> bool:
    """智能记忆索引接口"""
    sms = SmartMemorySystem()
    return sms.add_memory(content, context, success_score, dimension)

def smart_memory_search(query: str, limit: int = 10, min_score: int = None, dimension: str = None) -> list:
    """智能记忆搜索接口"""
    sms = SmartMemorySystem()
    return sms.search_memories(query, limit, min_score, dimension)

def generate_skill_from_success() -> Optional[str]:
    """从成功经验生成技能"""
    sms = SmartMemorySystem()
    
    # 搜索高评分的成功记忆
    success_memories = sms.search_memories(
        query="成功 有效 满意",
        min_score=8,
        limit=20
    )
    
    if success_memories:
        return sms.generate_skill_from_memories(success_memories)
    
    return None

if __name__ == "__main__":
    # 测试代码
    print("智能记忆与技能生成系统测试")
    
    # 初始化系统
    sms = SmartMemorySystem("test_smart_memory.db")
    
    # 测试记忆索引
    test_memory = {
        'content': '用户反馈：交流风格很自然，逻辑清晰，解决了问题',
        'context': {
            'type': 'user_feedback',
            'session_id': 'test_001',
            'interaction_type': 'problem_solving'
        },
        'success_score': 9,
        'dimension': '交流效果'
    }
    
    success = sms.add_memory(**test_memory)
    print(f"记忆索引结果: {success}")
    
    # 测试搜索
    results = sms.search_memories("交流风格 自然", limit=5)
    print(f"搜索结果数量: {len(results)}")
    
    # 测试统计
    stats = sms.get_system_stats()
    print(f"系统统计: {stats}")
    
    print("测试完成！")