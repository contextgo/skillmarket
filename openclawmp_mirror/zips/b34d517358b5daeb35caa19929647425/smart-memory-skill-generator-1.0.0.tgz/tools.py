#!/usr/bin/env python3
"""
智能记忆与技能生成系统 - 工具接口
提供标准的工具函数接口，供其他skills和系统调用
"""

from smart_memory_system import (
    SmartMemorySystem,
    smart_memory_index,
    smart_memory_search,
    generate_skill_from_success
)
from typing import Dict, List, Any, Optional
import json
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# 全局系统实例
_sms_instance = None

def _get_sms_instance() -> SmartMemorySystem:
    """获取智能记忆系统实例（单例模式）"""
    global _sms_instance
    if _sms_instance is None:
        _sms_instance = SmartMemorySystem()
    return _sms_instance

def memory_index_tool(content: str, context: dict, success_score: int = None, dimension: str = None) -> dict:
    """
    智能记忆索引工具
    
    将新的交互记忆索引到FTS5系统中，支持智能搜索和后续分析。
    
    Args:
        content: 记忆内容文本
        context: 上下文信息（字典格式）
        success_score: 成功评分（1-10，可选）
        dimension: 6维度分类（可选）
    
    Returns:
        dict: 操作结果 {'success': bool, 'message': str, 'memory_id': int}
    """
    try:
        sms = _get_sms_instance()
        success = sms.add_memory(content, context, success_score, dimension)
        
        return {
            'success': success,
            'message': '记忆索引成功' if success else '记忆索引失败',
            'memory_id': id(content)  # 简化实现
        }
    except Exception as e:
        logger.error(f"记忆索引工具错误: {e}")
        return {
            'success': False,
            'message': f'记忆索引失败: {e}',
            'memory_id': None
        }

def memory_search_tool(query: str, limit: int = 10, min_score: int = None, dimension: str = None) -> dict:
    """
    智能记忆搜索工具
    
    使用FTS5全文检索搜索相关记忆，支持复杂的查询条件和过滤。
    
    Args:
        query: 搜索查询（支持FTS5语法）
        limit: 返回结果数量限制
        min_score: 最小成功评分过滤
        dimension: 维度过滤
    
    Returns:
        dict: 搜索结果 {'success': bool, 'results': list, 'count': int}
    """
    try:
        sms = _get_sms_instance()
        results = sms.search_memories(query, limit, min_score, dimension)
        
        return {
            'success': True,
            'results': results,
            'count': len(results),
            'query': query
        }
    except Exception as e:
        logger.error(f"记忆搜索工具错误: {e}")
        return {
            'success': False,
            'results': [],
            'count': 0,
            'error': str(e)
        }

def skill_generation_tool(auto_generate: bool = True, memory_filter: str = None) -> dict:
    """
    技能生成工具
    
    基于成功经验自动生成新的技能代码，支持自动模式识别和代码生成。
    
    Args:
        auto_generate: 是否自动生成（True=全自动，False=手动模式）
        memory_filter: 记忆过滤条件（可选）
    
    Returns:
        dict: 生成结果 {'success': bool, 'skill_code': str, 'patterns': dict}
    """
    try:
        sms = _get_sms_instance()
        
        if auto_generate:
            # 搜索高评分的成功记忆
            if memory_filter:
                query = f"成功 有效 满意 {memory_filter}"
            else:
                query = "成功 有效 满意"
            
            success_memories = sms.search_memories(query, min_score=8, limit=20)
            
            if not success_memories:
                return {
                    'success': False,
                    'skill_code': None,
                    'patterns': {},
                    'message': '没有找到足够的成功经验用于技能生成'
                }
            
            # 生成技能
            skill_code = sms.generate_skill_from_memories(success_memories)
            
            if skill_code:
                return {
                    'success': True,
                    'skill_code': skill_code,
                    'patterns': sms.skill_generator.analyze_success_patterns(success_memories),
                    'memory_count': len(success_memories)
                }
            else:
                return {
                    'success': False,
                    'skill_code': None,
                    'patterns': {},
                    'message': '技能生成失败'
                }
        else:
            return {
                'success': False,
                'skill_code': None,
                'patterns': {},
                'message': '手动模式需要额外参数'
            }
            
    except Exception as e:
        logger.error(f"技能生成工具错误: {e}")
        return {
            'success': False,
            'skill_code': None,
            'patterns': {},
            'error': str(e)
        }

def system_stats_tool() -> dict:
    """
    系统统计工具
    
    获取智能记忆系统的运行统计信息，包括记忆数量、维度分布等。
    
    Returns:
        dict: 统计信息
    """
    try:
        sms = _get_sms_instance()
        stats = sms.get_system_stats()
        
        return {
            'success': True,
            'stats': stats,
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        logger.error(f"系统统计工具错误: {e}")
        return {
            'success': False,
            'stats': {},
            'error': str(e)
        }

# 高级工具函数
def analyze_communication_patterns(dimension: str = None, days: int = 7) -> dict:
    """
    分析交流模式
    
    分析指定时间段内的交流模式，识别成功要素和改进机会。
    
    Args:
        dimension: 特定维度（可选）
        days: 分析天数
    
    Returns:
        dict: 分析结果
    """
    try:
        import datetime
        from datetime import datetime, timedelta
        
        # 构建时间范围查询
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        query = f"timestamp:>{start_date.isoformat()} AND timestamp:<{end_date.isoformat()}"
        if dimension:
            query += f" AND dimension:{dimension}"
        
        # 搜索相关记忆
        results = memory_search_tool(query, limit=100)
        
        if not results['success'] or not results['results']:
            return {
                'success': False,
                'message': '没有找到足够的交流数据用于分析',
                'patterns': {}
            }
        
        # 分析模式
        sms = _get_sms_instance()
        patterns = sms.skill_generator.analyze_success_patterns(results['results'])
        
        return {
            'success': True,
            'patterns': patterns,
            'memory_count': len(results['results']),
            'analysis_period': f"{days}天",
            'dimension': dimension
        }
        
    except Exception as e:
        logger.error(f"交流模式分析错误: {e}")
        return {
            'success': False,
            'patterns': {},
            'error': str(e)
        }

def optimize_memory_search(query: str, context: dict = None) -> dict:
    """
    优化记忆搜索
    
    提供搜索查询优化建议，提升搜索结果的相关性和准确性。
    
    Args:
        query: 原始查询
        context: 搜索上下文
    
    Returns:
        dict: 优化建议
    """
    try:
        # 查询优化建议
        suggestions = {
            'original_query': query,
            'optimized_query': query,  # 简化实现
            'suggestions': [
                '使用更具体的关键词',
                '添加时间范围过滤',
                '指定维度筛选',
                '使用FTS5高级语法'
            ],
            'example_queries': [
                f'"{query}" AND dimension:交流效果',
                f'{query} AND success_score:>8',
                f'"{query}" AND timestamp:>2026-04-01'
            ]
        }
        
        return {
            'success': True,
            'optimization': suggestions
        }
        
    except Exception as e:
        logger.error(f"搜索优化错误: {e}")
        return {
            'success': False,
            'optimization': {},
            'error': str(e)
        }

# 向后兼容的接口
index_memory = memory_index_tool
search_memories = memory_search_tool
generate_skill = skill_generation_tool
get_system_stats = system_stats_tool

if __name__ == "__main__":
    # 测试工具接口
    print("智能记忆与技能生成系统 - 工具接口测试")
    
    # 测试记忆索引
    result = memory_index_tool(
        content="测试记忆：交流效果很好，用户满意",
        context={"type": "test", "session": "demo"},
        success_score=9,
        dimension="交流效果"
    )
    print(f"记忆索引测试: {result}")
    
    # 测试记忆搜索
    search_result = memory_search_tool("交流效果", limit=5)
    print(f"记忆搜索测试: 找到 {search_result['count']} 条结果")
    
    # 测试系统统计
    stats_result = system_stats_tool()
    print(f"系统统计测试: {stats_result['stats']}")
    
    print("工具接口测试完成！")