---
name: smart-memory-config
description: 智能记忆与技能生成系统配置文件
version: 1.0.0
---

# 智能记忆与技能生成系统 - 集成配置

## 快速集成指南

### 1. 系统要求
- Python 3.8+
- SQLite 3.19+ (支持FTS5)
- 2GB+ 可用内存（用于FTS5索引缓存）

### 2. 安装步骤
```bash
# 1. 复制skill到hermes skills目录
cp -r smart-memory-skill-generator ~/.hermes/skills/

# 2. 确保Python依赖可用（通常已内置）
# sqlite3, json, threading, logging, pathlib, datetime

# 3. 初始化数据库
python3 ~/.hermes/skills/smart-memory-skill-generator/smart_memory_system.py
```

### 3. 与现有系统集成

#### 与6维度交流框架集成
```python
# 在communication-framework.md中添加引用
from skills.smart_memory_skill_generator.tools import memory_index_tool, memory_search_tool

# 在交流评估后索引结果
def evaluate_communication(dimension, performance, user_feedback):
    memory_index_tool(
        content=f"{dimension}评估: {performance}, 用户反馈: {user_feedback}",
        context={
            "type": "communication_evaluation",
            "dimension": dimension,
            "evaluation_date": datetime.now().isoformat()
        },
        success_score=performance.get('score', 5),
        dimension=dimension
    )
```

#### 与夜间学习任务集成
```python
# 在夜间学习任务中添加智能分析
from skills.smart_memory_skill_generator.tools import (
    memory_search_tool, 
    skill_generation_tool,
    analyze_communication_patterns
)

def enhanced_nightly_learning():
    # 1. 搜索当天的交流记忆
    today_memories = memory_search_tool(
        query=f"timestamp:{datetime.now().strftime('%Y-%m-%d')}",
        limit=50
    )
    
    # 2. 分析交流模式
    if today_memories['results']:
        patterns = analyze_communication_patterns(
            days=1,
            dimension=None  # 分析所有维度
        )
        
        # 3. 生成改进技能
        skill_result = skill_generation_tool(
            auto_generate=True,
            memory_filter="交流效果"
        )
        
        if skill_result['success']:
            # 保存新生成的技能
            save_generated_skill(skill_result['skill_code'])
```

#### 与自主进化系统集成
```python
# 在现有的自主进化任务中添加智能组件

def enhanced_memory_recap():
    """增强版记忆复盘任务"""
    from smart_memory_skill_generator.tools import (
        memory_search_tool,
        analyze_communication_patterns,
        optimize_memory_search
    )
    
    # 1. 智能搜索前一天的记忆
    memories = memory_search_tool(
        query=f"timestamp:{get_yesterday_date()}",
        min_score=6,  # 只关注评分较高的记忆
        limit=30
    )
    
    # 2. 分析模式
    if memories['count'] > 0:
        patterns = analyze_communication_patterns(
            days=1,
            dimension=None
        )
        
        # 3. 生成改进建议
        suggestions = generate_improvement_suggestions(patterns)
        
        # 4. 更新MEMORY.md
        update_memory_with_insights(suggestions)
```

### 4. 配置选项

#### 数据库配置
```python
# smart_memory_system.py 中的配置参数
class Config:
    DB_PATH = "~/.hermes/skills/smart-memory-skill-generator/smart_memory.db"
    FTS5_CACHE_SIZE = 10000  # 10MB
    MAX_RETRIES = 15
    RETRY_MIN_MS = 20
    RETRY_MAX_MS = 150
```

#### 性能调优
```sql
-- 数据库性能优化
PRAGMA journal_mode=WAL;
PRAGMA synchronous=NORMAL;
PRAGMA cache_size=-10000;
PRAGMA temp_store=memory;
PRAGMA mmap_size=268435456;  -- 256MB内存映射
```

### 5. 使用示例

#### 基本使用
```python
# 索引新记忆
from smart_memory_skill_generator.tools import memory_index_tool

result = memory_index_tool(
    content="用户反馈：回答很清晰，解决了技术问题",
    context={"type": "feedback", "session": "tech_support"},
    success_score=9,
    dimension="逻辑思维"
)
```

#### 高级搜索
```python
# 搜索高评分的交流经验
results = memory_search_tool(
    query="交流效果 用户满意",
    min_score=8,
    dimension="语言风格",
    limit=10
)
```

#### 自动技能生成
```python
# 基于成功经验生成新技能
skill_result = skill_generation_tool(
    auto_generate=True,
    memory_filter="交流效果 成功"
)

if skill_result['success']:
    print(f"生成了新技能，代码长度: {len(skill_result['skill_code'])} 字符")
```

### 6. 监控和维护

#### 系统监控
```python
# 获取系统统计
from smart_memory_skill_generator.tools import system_stats_tool

stats = system_stats_tool()
print(f"总记忆数: {stats['stats']['total_memories']}")
print(f"平均评分: {stats['stats']['average_success_score']}")
```

#### 性能监控
```python
# 性能指标
- 搜索响应时间: <100ms (典型)
- 索引建立时间: <50ms per memory
- 并发写入成功率: >99%
- 数据库大小增长: ~1KB per memory
```

#### 维护任务
```bash
# 定期维护（可添加到cron任务）
# 1. WAL检查点
sqlite3 smart_memory.db "PRAGMA wal_checkpoint(TRUNCATE);"

# 2. 数据库优化
sqlite3 smart_memory.db "VACUUM;"

# 3. 统计信息更新
sqlite3 smart_memory.db "ANALYZE;"
```

### 7. 故障排除

#### 常见问题

**问题1: FTS5模块不可用**
```
Error: no such module: fts5
```
**解决**: 升级SQLite到3.19+版本，或重新编译启用FTS5支持

**问题2: 数据库锁定**
```
Error: database is locked
```
**解决**: 系统自动重试，通常会自动恢复

**问题3: 性能下降**
```
搜索响应时间 > 500ms
```
**解决**: 
- 检查数据库大小（>100MB需要优化）
- 执行VACUUM和ANALYZE
- 考虑分表或归档旧数据

### 8. 扩展开发

#### 添加新的分析维度
```python
# 在SkillGenerator中添加新的模式识别
def _extract_custom_patterns(self, contents: List[str]) -> Dict[str, Any]:
    # 自定义模式提取逻辑
    return custom_patterns
```

#### 集成新的LLM模型
```python
# 在generate_memory_summary中添加新模型支持
def generate_summary_with_new_model(self, results: list, model: str) -> str:
    # 新模型的摘要生成逻辑
    pass
```

### 9. 安全考虑

#### 数据安全
- 所有数据存储在本地SQLite数据库
- 支持加密数据库（需要时）
- 无外部数据传输

#### 访问控制
- 基于文件系统的权限控制
- 支持多用户隔离（通过不同数据库文件）

#### 隐私保护
- 可配置数据保留期限
- 支持数据匿名化处理
- 符合GDPR等隐私法规要求

### 10. 版本更新

#### 更新步骤
1. 备份现有数据库
2. 下载新版本skill
3. 运行数据库迁移脚本
4. 验证功能完整性

#### 兼容性保证
- 向后兼容数据库格式
- 支持平滑升级
- 提供回滚机制

---

通过这份配置，智能记忆与技能生成系统可以完美集成到现有的OpenClaw环境中，为小龙虾提供企业级的自主学习和进化能力！🦞✨