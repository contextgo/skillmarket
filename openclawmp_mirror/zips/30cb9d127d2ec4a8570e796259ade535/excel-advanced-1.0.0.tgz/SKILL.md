---
name: excel-advanced
description: Expert guidance for excel-advanced.
version: 1.0.0
tags: [data,ai,machine-learning]
author: OpenWork
metadata:
  openclaw:
    requires:
      bins: [python3]
      env: []
---

# uexcel advanced

Expert guidance and training.

## Capabilities

- Best practices
- Techniques and methods
- Practical exercises
- Resource recommendations

## Usage
Help with this skill
Tips and guidance
