# 金丝雀发布助手

## 发布策略

| 策略 | 说明 | 适用场景 |
|------|------|----------|
| 金丝雀 | 先发少量实例验证 | 新功能验证 |
| 滚动发布 | 逐步替换所有实例 | 常规发布 |
| 蓝绿发布 | 双环境切换 | 重大变更 |
| A/B测试 | 不同版本对比 | 特性验证 |

## 金丝雀发布流程

```markdown
## 金丝雀发布流程

1. 部署金丝雀版本
   └─ 1-2个金丝雀实例（5-10%流量）
       ↓
2. 验证金丝雀
   ├─ 健康检查
   ├─ 功能验证
   └─ 监控数据
       ↓
3. 逐步扩大
   ├─ 流量10% → 30%
   ├─ 观察3-6小时
   └─ 继续扩大
       ↓
4. 全量发布
   └─ 流量100%
       ↓
5. 清理旧版本
   └─ 删除旧版本实例
```

## 金丝雀配置示例

### Kubernetes配置
```yaml
# Canary Deployment
apiVersion: apps/v1
kind: Deployment
metadata:
  name: app-canary
spec:
  replicas: 2  # 金丝雀实例数
  selector:
    matchLabels:
      app: myapp
      version: canary
  template:
    metadata:
      labels:
        app: myapp
        version: canary
---
# Service
apiVersion: v1
kind: Service
metadata:
  name: app-service
spec:
  selector:
    app: myapp
  ports:
  - port: 80
---
# HPA (Horizontal Pod Autoscaler)
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: app-hpa
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: app
  minReplicas: 3
  maxReplicas: 10
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
```

### Nginx灰度配置
```nginx
# 灰度权重配置
upstream backend {
    server 10.0.0.1:8080;  # 旧版本
    server 10.0.0.2:8080;  # 新版本（金丝雀）
}

server {
    location / {
        proxy_pass http://backend;
        
        # 灰度规则
        # 1. 基于Cookie
        if ($cookie_canary ~* "true") {
            proxy_pass http://10.0.0.2:8080;  # 金丝雀版本
        }
        
        # 2. 基于Header
        if ($http_x_canary = "true") {
            proxy_pass http://10.0.0.2:8080;
        }
        
        # 3. 基于权重
        split_clients "${remote_addr}AAA" $backend_version {
            10% "10.0.0.2:8080";    # 10%流量到新版本
            * "10.0.0.1:8080";       # 90%流量到旧版本
        }
        
        proxy_pass http://backend_version;
    }
}
```

### Istio灰度配置
```yaml
# DestinationRule
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: app-destination
spec:
  host: myapp
  subsets:
  - name: stable
    labels:
      version: stable
  - name: canary
    labels:
      version: canary
---
# VirtualService
apiVersion: networking.istio.io/v1beta1
kind: VirtualService
metadata:
  name: myapp
spec:
  hosts:
  - myapp
  http:
  - route:
    - destination:
        host: myapp
        subset: stable
      weight: 90
    - destination:
        host: myapp
        subset: canary
      weight: 10
```

## 灰度发布检查清单

```markdown
## 发布前检查
- [ ] 代码审查通过
- [ ] 单元测试通过
- [ ] 集成测试通过
- [ ] 准备回滚方案
- [ ] 通知相关人员
- [ ] 监控告警就绪

## 发布中检查
- [ ] 金丝雀实例健康
- [ ] 流量按预期分配
- [ ] 错误率无异常
- [ ] 响应时间无恶化
- [ ] 业务指标正常

## 发布后检查
- [ ] 全部实例更新
- [ ] 旧版本清理
- [ ] 监控数据正常
- [ ] 文档更新
- [ ] 发布记录归档
```

## 灰度策略配置

### 分阶段灰度
```markdown
| 阶段 | 流量比例 | 持续时间 | 观察指标 |
|------|----------|----------|----------|
| 阶段1 | 5% | 2小时 | 错误率、响应时间 |
| 阶段2 | 10% | 2小时 | +业务指标 |
| 阶段3 | 30% | 4小时 | +资源使用 |
| 阶段4 | 50% | 4小时 | +日志分析 |
| 阶段5 | 100% | - | 全面监控 |
```

### 灰度规则
```markdown
| 规则类型 | 说明 | 示例 |
|----------|------|------|
| 用户ID | 特定用户走灰度 | user_id % 100 < 5 |
| 地区 | 特定地区优先 | region = '北京' |
| 设备 | 特定设备优先 | platform = 'iOS' |
| 版本 | 特定版本优先 | app_version >= '2.0' |
| 随机 | 随机百分比 | random < 0.1 |
```

## 回滚操作

```bash
# Kubernetes回滚
kubectl rollout undo deployment/app
kubectl rollout history deployment/app

# ArgoCD回滚
argocd app rollback myapp

# Spinnaker回滚
spinnaker rollback app --region us-east-1

# 手动回滚（Nginx）
# 1. 移除金丝雀upstream
# 2. reload nginx
```

## 监控指标

```markdown
## 灰度发布关键指标

| 指标 | 正常范围 | 告警阈值 |
|------|----------|----------|
| 金丝雀错误率 | < 0.1% | > 1% |
| 金丝雀响应时间 | < 200ms | > 500ms |
| 金丝雀CPU | < 70% | > 90% |
| 金丝雀内存 | < 80% | > 95% |
| 业务成功率 | > 99.9% | < 99.5% |
```