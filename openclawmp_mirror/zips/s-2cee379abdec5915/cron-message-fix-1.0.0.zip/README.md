# Cron任务消息推送修复方案

解决 Cron isolated 会话推送失败的问题。

## 问题现象
- Gateway 握手超时（handshake-timeout）
- message 工具缺少 target 参数

## 解决方案
1. Gateway 重启恢复
2. message 工具添加 target 参数（格式：user:openId）

## 示例
```json
{
  "action": "send",
  "channel": "feishu",
  "target": "user:ou_xxx",
  "message": "任务执行结果"
}
```