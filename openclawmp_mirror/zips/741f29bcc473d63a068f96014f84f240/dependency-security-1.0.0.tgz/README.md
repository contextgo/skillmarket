# 依赖安全扫描指南

## 工具
| 工具 | 特点 |
|------|------|
| npm audit | 零配置，Node.js 内置 |
| Snyk | 全语言，修补建议 |
| Trivy | 容器+依赖+IaC |
| Dependabot | GitHub 自动 PR |
| Grype | 开源免费 |

## 实施
开发：npm audit --production
CI/CD：trivy scan --severity HIGH,CRITICAL
SBOM：syft packages dir:./dist | grype sbom:-

## 应急
1. 评估影响 2. 检查 exploit 3. 升级修补
4. 无法升级用 WAF 5. 记录跟踪
