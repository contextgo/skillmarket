# 🤖 Smart Model Router

智能模型路由系统 - 让 AI 自动选择最适合的模型处理您的任务

## ✨ 功能特性

- **🧠 智能识别**: 自动分析任务类型，匹配最优模型
- **⚡ 快捷切换**: 支持 `/code`, `/long` 等前缀快速指定模型
- **🛡️ 安全可靠**: 模型白名单验证、输入转义、完整错误处理
- **📊 日志记录**: 自动记录模型切换历史，便于追踪分析
- **🔄 可移植**: 跨平台兼容，支持 Linux/macOS/Windows

## 📋 支持的模型映射

| 任务类型 | 触发关键词 | 推荐模型 | 上下文 |
|---------|-----------|---------|--------|
| **代码编程** | 代码、编程、bug、算法、API... | qwen3-coder-plus | 100万 |
| **超长文档** | 论文、PDF、报告、万字... | qwen3.5-plus | 100万 |
| **图文理解** | 图片、截图、看图、OCR... | kimi-k2.5 | 26万 |
| **创意写作** | 写故事、文案、诗歌、小说... | MiniMax-M2.5 | 100万 |
| **快速问答** | 简单、快速、一句话... | glm-5 | 20万 |
| **通用任务** | 其他所有情况 | kimi-k2.5 | 26万 |

## 🚀 使用方法

### 方式一：快捷前缀（推荐）

在对话开头输入以下前缀，自动切换到对应模型：

```
/code 帮我写一个Python爬虫        → 切换到代码模型
/long 总结这份100页的PDF报告      → 切换到长文本模型
/vision 分析这张截图里的数据      → 切换到图文模型
/fast 简要回答这个问题            → 切换到快速模型
/creative 写一个科幻故事          → 切换到创意模型
/default 恢复默认模型             → 切换到默认模型
```

### 方式二：命令行工具

```bash
# 使用 Node.js 脚本
node scripts/router.mjs "帮我debug这段代码"

# 干运行模式（只显示推荐，不切换）
node scripts/router.mjs "写代码" --dry-run

# 显示当前模型
node scripts/router.mjs --current

# 列出所有可用模型
node scripts/router.mjs --list
```

### 方式三：Shell 快捷命令

```bash
# 添加执行权限
chmod +x scripts/switch-model.sh

# 切换到不同模型
./scripts/switch-model.sh code       # 代码模型
./scripts/switch-model.sh long       # 长文本模型
./scripts/switch-model.sh vision     # 图文模型
./scripts/switch-model.sh fast       # 快速模型
./scripts/switch-model.sh creative   # 创意模型
./scripts/switch-model.sh default    # 恢复默认

# 查看帮助
./scripts/switch-model.sh --help
```

## ⚙️ 配置说明

### 自定义关键词

编辑 `scripts/router.mjs` 中的 `MODEL_MAP` 对象，添加您自己的关键词：

```javascript
code: {
  model: 'bailian/qwen3-coder-plus',
  keywords: ['代码', '编程', '您的自定义关键词'],
  contextWindow: 1000000,
  description: '代码生成与编程辅助'
}
```

### 修改默认模型

编辑 `MODEL_MAP.default`：

```javascript
default: {
  model: 'bailian/qwen3.5-plus',  // 修改为您偏好的默认模型
  keywords: [],
  contextWindow: 1000000,
  description: '通用任务'
}
```

## 🔒 安全特性

- ✅ **模型白名单**: 只允许切换到预定义的模型ID
- ✅ **输入转义**: 自动转义 Markdown 特殊字符，防止注入
- ✅ **路径安全**: 安全获取用户主目录，避免目录遍历
- ✅ **错误处理**: 完整的 try-catch 和错误提示
- ✅ **依赖检查**: 自动检查 openclaw 命令是否可用

## 📁 文件结构

```
smart-model-router/
├── SKILL.md              # 技能说明
├── README.md             # 本文件
├── manifest.json         # 技能清单
└── scripts/
    ├── router.mjs        # 核心路由脚本 (Node.js)
    └── switch-model.sh   # 快捷切换脚本 (Bash)
```

## 📝 日志位置

模型切换历史记录在：
```
~/.openclaw/workspace/memory/model-routing-log.md
```

## 🔧 系统要求

- OpenClaw >= 2026.2.0
- Node.js >= 18.0
- Bash >= 4.0 (可选，用于 shell 脚本)

## 🤝 贡献指南

欢迎提交 Issue 和 PR！

## 📄 许可证

MIT License

---

**Made with ❤️ for OpenClaw**
