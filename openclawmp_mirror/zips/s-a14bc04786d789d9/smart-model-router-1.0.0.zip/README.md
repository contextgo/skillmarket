# Smart Model Router

智能模型路由配置 - 根据任务自动选择最优模型

## 🎯 快速切换指令

在对话开头使用以下前缀，自动切换到对应模型：

| 前缀 | 用途 | 切换至 |
|-----|------|--------|
| `/code` | 编程、代码相关 | qwen3-coder-plus (100万上下文) |
| `/long` | 长文档、论文分析 | qwen3.5-plus (100万上下文) |
| `/vision` | 图片、图文理解 | kimi-k2.5 (26万上下文) |
| `/fast` | 快速简短回答 | glm-5 (20万上下文) |
| `/creative` | 创意写作 | MiniMax-M2.5 (100万上下文) |
| `/default` | 恢复默认 | kimi-k2.5 |

## 🧠 自动识别规则

我会根据您的输入自动判断任务类型：

### 代码任务 → qwen3-coder-plus
**关键词**: 代码、编程、bug、函数、API、git、debug、程序、算法、leetcode、python、java、javascript、sql...

### 超长文档 → qwen3.5-plus  
**关键词**: 论文、PDF、报告、总结长文、全书、文献综述、批量处理...

### 图文理解 → kimi-k2.5
**关键词**: 图片、图像、看图、截图、照片、OCR、视觉...

### 创意写作 → MiniMax-M2.5
**关键词**: 写故事、文案、诗歌、小说、创作、编剧、演讲稿...

### 快速问答 → glm-5
**关键词**: 简单、快速、简短、一句话、简要、是或否...

## 💡 使用示例

```
用户: /code 帮我写一个Python爬虫抓取知乎数据
→ 自动切换到 qwen3-coder-plus

用户: /long 总结这份100页的PDF报告
→ 自动切换到 qwen3.5-plus

用户: /vision 分析这张截图里的数据
→ 自动切换到 kimi-k2.5

用户: 今天天气怎么样？
→ 保持默认 kimi-k2.5
```

## ⚙️ 技术实现

路由脚本位置: `~/.openclaw/workspace/skills/smart-model-router/scripts/router.mjs`

日志记录: `~/.openclaw/workspace/memory/model-routing-log.md`
