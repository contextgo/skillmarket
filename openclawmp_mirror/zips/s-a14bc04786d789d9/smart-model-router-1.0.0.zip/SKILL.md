---
name: smart-model-router
description: 智能模型路由系统 - 根据任务类型自动选择最优AI模型
version: 1.0.0
author: OpenClaw Community
license: MIT
---

# Smart Model Router

智能模型路由系统 - 让 AI 自动选择最适合的模型处理您的任务

## 功能特性

- **智能识别**: 自动分析任务类型，匹配最优模型
- **快捷切换**: 支持 `/code`, `/long` 等前缀快速指定模型
- **安全可靠**: 模型白名单验证、输入转义、完整错误处理
- **日志记录**: 自动记录模型切换历史，便于追踪分析
- **可移植**: 跨平台兼容，支持 Linux/macOS/Windows

## 支持的模型映射

| 任务类型 | 触发关键词 | 推荐模型 | 上下文 |
|---------|-----------|---------|--------|
| **代码编程** | 代码、编程、bug、算法... | qwen3-coder-plus | 100万 |
| **超长文档** | 论文、PDF、报告、万字... | qwen3.5-plus | 100万 |
| **图文理解** | 图片、截图、看图... | kimi-k2.5 | 26万 |
| **创意写作** | 写故事、文案、诗歌... | MiniMax-M2.5 | 100万 |
| **快速问答** | 简单、快速、一句话... | glm-5 | 20万 |
| **通用任务** | 其他所有情况 | kimi-k2.5 | 26万 |

## 使用方法

### 快捷前缀

```
/code 帮我写一个Python爬虫        → 切换到代码模型
/long 总结这份100页的PDF报告      → 切换到长文本模型
/vision 分析这张截图里的数据      → 切换到图文模型
/fast 简要回答这个问题            → 切换到快速模型
/creative 写一个科幻故事          → 切换到创意模型
/default 恢复默认模型             → 切换到默认模型
```

### 命令行工具

```bash
node scripts/router.mjs "帮我debug这段代码"
node scripts/router.mjs --current
node scripts/switch-model.sh code
```

## 安全特性

- ✅ 模型白名单验证
- ✅ 用户输入转义
- ✅ 完整错误处理
- ✅ 路径安全检查

## 系统要求

- OpenClaw >= 2026.2.0
- Node.js >= 18.0

## 许可证

MIT License
