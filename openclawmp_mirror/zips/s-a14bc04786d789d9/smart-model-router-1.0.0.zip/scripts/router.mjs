#!/usr/bin/env node
/**
 * Smart Model Router
 * 根据用户输入自动选择最优模型
 * 
 * 安全特性：
 * - 模型白名单验证
 * - 用户输入转义
 * - 完整错误处理
 * - 路径安全检查
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import os from 'os';

// ============ 常量配置 ============

// 允许的模型白名单
const ALLOWED_MODELS = [
  'bailian/qwen3-coder-plus',
  'bailian/qwen3.5-plus',
  'bailian/qwen3-max-2026-01-23',
  'bailian/qwen3-coder-next',
  'bailian/kimi-k2.5',
  'bailian/glm-5',
  'bailian/glm-4.7',
  'bailian/MiniMax-M2.5'
];

// 模型映射配置
const MODEL_MAP = {
  code: {
    model: 'bailian/qwen3-coder-plus',
    keywords: ['代码', '编程', 'bug', '函数', 'API', 'git', 'debug', '程序', '算法', 'leetcode', 'python', 'java', 'javascript', 'cpp', 'c++', 'go', 'rust', 'sql', '数据库', '爬虫', '脚本', '开发', '部署', '运维'],
    contextWindow: 1000000,
    description: '代码生成与编程辅助'
  },
  'long-context': {
    model: 'bailian/qwen3.5-plus',
    keywords: ['论文', 'PDF', '报告', '总结长文', '全书', '文档分析', '文献综述', '研究报告', '白皮书', '长篇小说', '批量处理', '大量文本', '万字', '百页'],
    contextWindow: 1000000,
    description: '超长文档处理'
  },
  vision: {
    model: 'bailian/kimi-k2.5',
    keywords: ['图片', '图像', '看图', '截图', '分析图', '照片', '识别文字', 'OCR', '图片描述', '视觉', '识图', 'img', 'image', 'picture'],
    contextWindow: 262144,
    description: '图文理解'
  },
  creative: {
    model: 'bailian/MiniMax-M2.5',
    keywords: ['写故事', '文案', '诗歌', '小说', '创作', '编剧', '广告词', '宣传稿', '演讲稿', '情书', '润色', '改写'],
    contextWindow: 1000000,
    description: '创意写作'
  },
  fast: {
    model: 'bailian/glm-5',
    keywords: ['简单', '快速', '简短', '一句话', '简要', '概括', '快速回答', '是或否', '是否', '对吗'],
    contextWindow: 202752,
    description: '快速响应'
  },
  default: {
    model: 'bailian/kimi-k2.5',
    keywords: [],
    contextWindow: 262144,
    description: '通用任务'
  }
};

// 强制模型前缀映射
const FORCE_PREFIX_MAP = {
  '[code]': 'code',
  '/code': 'code',
  '[long]': 'long-context',
  '/long': 'long-context',
  '[vision]': 'vision',
  '/vision': 'vision',
  '[fast]': 'fast',
  '/fast': 'fast',
  '[creative]': 'creative',
  '/creative': 'creative',
  '[default]': 'default',
  '/default': 'default'
};

// ============ 工具函数 ============

/**
 * 安全地获取用户主目录
 */
function getHomeDir() {
  const home = process.env.HOME || process.env.USERPROFILE || os.homedir();
  if (!home) {
    throw new Error('无法确定用户主目录 (HOME/USERPROFILE 未设置)');
  }
  return home;
}

/**
 * 转义 Markdown 特殊字符，防止注入
 */
function escapeMarkdown(text) {
  if (typeof text !== 'string') {
    return String(text);
  }
  return text
    .replace(/\\/g, '\\\\')
    .replace(/\*/g, '\\*')
    .replace(/_/g, '\\_')
    .replace(/\[/g, '\\[')
    .replace(/\]/g, '\\]')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/`/g, '\\`')
    .replace(/\|/g, '\\|');
}

/**
 * 验证模型ID是否在白名单中
 */
function validateModel(modelId) {
  if (!ALLOWED_MODELS.includes(modelId)) {
    throw new Error(`非法模型ID: ${modelId}. 允许的模型: ${ALLOWED_MODELS.join(', ')}`);
  }
  return true;
}

/**
 * 检查 openclaw 命令是否可用
 */
function checkOpenclaw() {
  try {
    execSync('which openclaw', { stdio: 'pipe' });
    return true;
  } catch (e) {
    return false;
  }
}

// ============ 核心功能 ============

/**
 * 分析用户输入，确定任务类型
 */
function analyzeTask(userInput) {
  if (typeof userInput !== 'string' || userInput.trim().length === 0) {
    return {
      type: 'default',
      forced: false,
      score: 0,
      reason: '空输入，使用默认模型'
    };
  }

  const trimmedInput = userInput.trim();

  // 检查强制前缀
  for (const [prefix, taskType] of Object.entries(FORCE_PREFIX_MAP)) {
    if (trimmedInput.toLowerCase().startsWith(prefix.toLowerCase())) {
      return {
        type: taskType,
        forced: true,
        reason: `检测到强制前缀 "${prefix}"`
      };
    }
  }

  // 分析关键词匹配
  const scores = {};
  
  for (const [taskType, config] of Object.entries(MODEL_MAP)) {
    if (taskType === 'default') continue;
    
    let score = 0;
    for (const keyword of config.keywords) {
      const regex = new RegExp(keyword.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
      if (regex.test(trimmedInput)) {
        score += 1;
        // 关键词在开头权重更高
        const index = trimmedInput.toLowerCase().indexOf(keyword.toLowerCase());
        if (index >= 0 && index < 50) {
          score += 0.5;
        }
      }
    }
    scores[taskType] = score;
  }

  // 找出得分最高的类型
  let bestType = 'default';
  let bestScore = 0;
  
  for (const [type, score] of Object.entries(scores)) {
    if (score > bestScore) {
      bestScore = score;
      bestType = type;
    }
  }

  return {
    type: bestType,
    forced: false,
    score: bestScore,
    reason: bestScore > 0 ? `匹配关键词得分: ${bestScore.toFixed(1)}` : '无明确特征，使用默认模型'
  };
}

/**
 * 获取当前会话使用的模型
 */
function getCurrentModel() {
  try {
    const output = execSync('openclaw status --json 2>/dev/null', { 
      encoding: 'utf8',
      timeout: 5000,
      stdio: ['pipe', 'pipe', 'ignore']
    });
    const status = JSON.parse(output);
    return status.session?.model || 'unknown';
  } catch (e) {
    console.error(`⚠️ 获取当前模型失败: ${e.message}`);
    return 'unknown';
  }
}

/**
 * 切换模型
 */
function switchModel(modelId, reason) {
  try {
    // 验证模型白名单
    validateModel(modelId);
    
    // 执行切换
    const cmd = `openclaw session model "${modelId}"`;
    execSync(cmd, { 
      encoding: 'utf8',
      timeout: 10000,
      stdio: ['pipe', 'pipe', 'inherit']
    });
    
    console.log(`✅ 已切换模型: ${modelId}`);
    console.log(`📝 原因: ${reason}`);
    
    return true;
  } catch (e) {
    console.error(`❌ 切换模型失败: ${e.message}`);
    return false;
  }
}

/**
 * 记录路由历史
 */
function logRouting(taskType, model, reason, userInput) {
  try {
    const homeDir = getHomeDir();
    const logDir = path.join(homeDir, '.openclaw', 'workspace', 'memory');
    
    // 安全创建目录
    if (!fs.existsSync(logDir)) {
      fs.mkdirSync(logDir, { recursive: true, mode: 0o755 });
    }
    
    const logFile = path.join(logDir, 'model-routing-log.md');
    const timestamp = new Date().toISOString();
    const safeInput = escapeMarkdown(userInput.substring(0, 100));
    const safeReason = escapeMarkdown(reason);
    
    const entry = `\n## ${timestamp}\n- **任务类型**: ${escapeMarkdown(taskType)}\n- **选择模型**: ${escapeMarkdown(model)}\n- **原因**: ${safeReason}\n- **输入摘要**: ${safeInput}${userInput.length > 100 ? '...' : ''}\n`;

    fs.appendFileSync(logFile, entry, { mode: 0o644 });
  } catch (e) {
    console.error(`⚠️ 记录日志失败: ${e.message}`);
    // 日志失败不应影响主流程
  }
}

// ============ 主函数 ============

function printUsage() {
  console.log('用法: router.mjs "<用户输入>" [选项]');
  console.log('');
  console.log('选项:');
  console.log('  --dry-run     只显示推荐模型，不实际切换');
  console.log('  --current     显示当前使用的模型');
  console.log('  --list        列出所有可用模型');
  console.log('  -h, --help    显示帮助');
  console.log('');
  console.log('快捷前缀:');
  console.log('  /code       - 代码编程任务');
  console.log('  /long       - 长文档处理');
  console.log('  /vision     - 图文理解');
  console.log('  /fast       - 快速响应');
  console.log('  /creative   - 创意写作');
  console.log('  /default    - 恢复默认');
}

function main() {
  const args = process.argv.slice(2);
  
  // 帮助
  if (args.includes('-h') || args.includes('--help')) {
    printUsage();
    process.exit(0);
  }

  // 检查 openclaw 是否可用
  if (!checkOpenclaw()) {
    console.error('❌ 错误: openclaw 命令未找到，请确保 OpenClaw 已安装并在 PATH 中');
    process.exit(1);
  }

  // 显示当前模型
  if (args.includes('--current')) {
    const current = getCurrentModel();
    console.log(`当前模型: ${current}`);
    process.exit(0);
  }

  // 列出可用模型
  if (args.includes('--list')) {
    console.log('可用模型列表:');
    ALLOWED_MODELS.forEach(m => console.log(`  - ${m}`));
    process.exit(0);
  }

  // 检查输入
  if (args.length === 0 || args[0].startsWith('--')) {
    printUsage();
    process.exit(1);
  }

  const userInput = args[0];
  const dryRun = args.includes('--dry-run');

  try {
    // 分析任务
    const analysis = analyzeTask(userInput);
    const modelConfig = MODEL_MAP[analysis.type];

    // 验证模型
    validateModel(modelConfig.model);

    console.log('🔍 任务分析结果:');
    console.log(`   类型: ${analysis.type}`);
    console.log(`   描述: ${modelConfig.description}`);
    console.log(`   原因: ${analysis.reason}`);
    console.log(`   推荐模型: ${modelConfig.model}`);
    console.log(`   上下文窗口: ${modelConfig.contextWindow.toLocaleString()} tokens`);

    if (!dryRun) {
      // 执行模型切换
      const success = switchModel(modelConfig.model, analysis.reason);
      
      if (success) {
        // 记录日志
        logRouting(analysis.type, modelConfig.model, analysis.reason, userInput);
      }
      
      process.exit(success ? 0 : 1);
    } else {
      console.log('\n⚠️ 干运行模式 - 未实际切换模型');
      process.exit(0);
    }
  } catch (e) {
    console.error(`❌ 错误: ${e.message}`);
    process.exit(1);
  }
}

main();
