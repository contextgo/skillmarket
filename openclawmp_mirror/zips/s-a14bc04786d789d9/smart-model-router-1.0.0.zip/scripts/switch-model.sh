#!/bin/bash
# ============================================================================
# 快速模型切换脚本
# 安全特性：
# - 严格模式 (set -euo pipefail)
# - 依赖检查
# - 模型白名单验证
# - 可移植路径处理
# ============================================================================

set -euo pipefail

# 版本信息
readonly VERSION="1.0.0"
readonly SCRIPT_NAME="$(basename "$0")"

# ============ 工具函数 ============

# 错误处理
error_exit() {
  echo "❌ 错误: $1" >&2
  exit "${2:-1}"
}

# 信息输出
info() {
  echo "ℹ️  $1"
}

# 成功输出
success() {
  echo "✅ $1"
}

# 检查命令是否存在
check_command() {
  if ! command -v "$1" &> /dev/null; then
    error_exit "$1 命令未找到，请确保已安装并在 PATH 中"
  fi
}

# 显示用法
usage() {
  cat << EOF
用法: ${SCRIPT_NAME} [选项] <模型类型>

快速切换 OpenClaw 会话使用的 AI 模型

选项:
  -h, --help      显示此帮助信息
  -v, --version   显示版本信息
  -c, --current   显示当前使用的模型
  -l, --list      列出所有可用模型

模型类型:
  code       代码编程 (qwen3-coder-plus, 100万上下文)
  long       长文档处理 (qwen3.5-plus, 100万上下文)
  vision     图文理解 (kimi-k2.5, 26万上下文)
  fast       快速响应 (glm-5, 20万上下文)
  creative   创意写作 (MiniMax-M2.5, 100万上下文)
  default    恢复默认 (kimi-k2.5, 26万上下文)

示例:
  ${SCRIPT_NAME} code          # 切换到代码模型
  ${SCRIPT_NAME} vision        # 切换到图文模型
  ${SCRIPT_NAME} --current     # 查看当前模型
  ${SCRIPT_NAME} --list        # 列出所有模型

EOF
}

# 显示版本
version() {
  echo "${SCRIPT_NAME} v${VERSION}"
}

# 列出可用模型
list_models() {
  cat << EOF
可用模型列表:
  bailian/qwen3-coder-plus      代码编程 (100万上下文)
  bailian/qwen3.5-plus          长文档处理 (100万上下文)
  bailian/qwen3-max-2026-01-23  通用任务 (26万上下文)
  bailian/qwen3-coder-next      代码辅助 (26万上下文)
  bailian/kimi-k2.5             图文理解 (26万上下文)
  bailian/glm-5                 快速响应 (20万上下文)
  bailian/glm-4.7               轻量任务 (20万上下文)
  bailian/MiniMax-M2.5          创意写作 (100万上下文)
EOF
}

# 获取当前模型
get_current_model() {
  local current
  current=$(openclaw status --json 2>/dev/null | grep -o '"model":"[^"]*"' | cut -d'"' -f4 || echo "unknown")
  echo "当前模型: ${current}"
}

# 切换模型（带验证）
switch_model() {
  local model_type="$1"
  local model_id=""
  local description=""
  local context=""

  # 模型映射表
  case "${model_type}" in
    code|coder)
      model_id="bailian/qwen3-coder-plus"
      description="代码模型"
      context="100万上下文"
      ;;
    long|long-context)
      model_id="bailian/qwen3.5-plus"
      description="长文本模型"
      context="100万上下文"
      ;;
    vision|img|image)
      model_id="bailian/kimi-k2.5"
      description="图文模型"
      context="26万上下文"
      ;;
    fast|quick)
      model_id="bailian/glm-5"
      description="快速模型"
      context="20万上下文"
      ;;
    creative|write)
      model_id="bailian/MiniMax-M2.5"
      description="创意模型"
      context="100万上下文"
      ;;
    default|reset)
      model_id="bailian/kimi-k2.5"
      description="默认模型"
      context="26万上下文"
      ;;
    *)
      error_exit "未知模型类型: ${model_type}. 使用 -h 查看可用选项。"
      ;;
  esac

  # 验证模型ID格式
  if [[ ! "${model_id}" =~ ^bailian/[a-zA-Z0-9._-]+$ ]]; then
    error_exit "非法模型ID格式: ${model_id}"
  fi

  info "正在切换到 ${description}..."
  
  # 执行切换
  if openclaw session model "${model_id}"; then
    success "已切换到 ${description}: ${model_id} (${context})"
  else
    error_exit "模型切换失败"
  fi
}

# ============ 主逻辑 ============

main() {
  # 检查依赖
  check_command "openclaw"

  # 解析参数
  case "${1:-}" in
    -h|--help)
      usage
      exit 0
      ;;
    -v|--version)
      version
      exit 0
      ;;
    -c|--current)
      get_current_model
      exit 0
      ;;
    -l|--list)
      list_models
      exit 0
      ;;
    "")
      usage
      exit 1
      ;;
    -*)
      error_exit "未知选项: $1. 使用 -h 查看帮助。"
      ;;
    *)
      switch_model "$1"
      ;;
  esac
}

# 运行主函数
main "$@"
