# 记忆系统-增强版 (jiyixitong-wan v2.0)

## 新增功能概览

### 1. 向量搜索能力
- **混合搜索**：结合关键词搜索和语义搜索
- **简单嵌入**：LLM 不可用时自动降级到基于 n-gram 的本地嵌入
- **向量存储**：本地 JSON 文件存储，支持余弦相似度计算
- **自动索引**：保存记忆时自动构建向量索引

### 2. 增强的 LLM 错误处理
- **指数退避重试**：最多 3 次重试，延迟从 1s 到 10s
- **降级机制**：LLM 失败时自动切换到规则提取
- **健康检查**：连续失败 5 次后标记为不可用
- **调用统计**：跟踪成功率、延迟等指标

### 3. OpenClaw 自动触发配置
- **记忆提取**：对话结束时自动提取
- **智能搜索**：检测到关键词时自动搜索相关记忆
- **定期反思**：支持 cron 表达式定时触发
- **自动维护**：每日自动清理和归档

### 4. 备份与导出功能
- **完整备份**：数据库 + 向量 + 配置文件
- **自动压缩**：gzip 压缩节省空间
- **校验和验证**：MD5 校验确保数据完整性
- **JSON 导出**：便于迁移和分享

### 5. 性能监控
- **延迟统计**：搜索和提取的平均延迟
- **调用计数**：各类操作的执行次数
- **系统状态**：LLM 可用性、向量数量等

## 快速开始

### 基础使用

```typescript
import { JiyixitongWan, FreeProviders } from 'jiyixitong-wan';

// 初始化（使用增强配置）
const jyx = new JiyixitongWan({
  dataDir: '~/.jiyixitong-wan',
  backup: {
    enabled: true,
    maxBackups: 7,
    compression: true,
  },
  performance: {
    metricsEnabled: true,
    cacheEnabled: true,
  },
});

// 配置 LLM（可选，支持 Ollama、Groq、Together）
const ollama = FreeProviders.ollama({
  model: 'llama3.2',
  embeddingModel: 'nomic-embed-text',
});
jyx.setLLMProvider(ollama);

// 保存记忆
await jyx.save('用户喜欢使用 TypeScript', {
  type: 'preference',
  importance: 0.9,
  tags: ['技术偏好'],
});

// 混合搜索（关键词 + 语义）
const results = await jyx.search_memories('用户对什么编程语言有偏好？', {
  useHybrid: true,
  keywordWeight: 0.3,
  semanticWeight: 0.7,
  maxResults: 10,
});

// 从对话提取记忆
const memories = await jyx.extract(messages, conversationId);

// 获取系统统计
const stats = await jyx.getStats();
console.log(`总记忆数: ${stats.memories.total}`);
console.log(`向量数: ${stats.vectors.totalVectors}`);
console.log(`LLM 可用: ${stats.llm.isAvailable}`);
```

### 备份与恢复

```typescript
// 创建备份
const backup = await jyx.createBackup();
console.log(`备份创建: ${backup.id}`);

// 列出所有备份
const backups = await jyx.listBackups();

// 恢复备份
await jyx.restoreBackup('backup-1234567890');

// 导出为 JSON
const exportPath = await jyx.exportToJSON();

// 从 JSON 导入
await jyx.importFromJSON('/path/to/export.json');
```

### 性能监控

```typescript
// 获取性能指标
const metrics = jyx.getPerformanceMetrics();
console.log(`搜索次数: ${metrics.search.count}`);
console.log(`平均搜索延迟: ${metrics.search.averageLatencyMs}ms`);

// 获取详细统计
const stats = await jyx.getStats();
console.log('LLM 统计:', stats.llm);
console.log('备份统计:', stats.backups);

// 重置指标
jyx.resetPerformanceMetrics();
```

## OpenClaw 集成

### 配置文件

将 `openclaw.config.json` 复制到 OpenClaw 配置目录：

```bash
cp openclaw.config.json ~/.openclaw/skills/jiyixitong-wan/config.json
```

### 自动触发示例

```json
{
  "triggers": {
    "memory_extraction": {
      "enabled": true,
      "events": ["onConversationEnd"],
      "threshold": 5
    },
    "memory_search": {
      "enabled": true,
      "events": ["onUserQuery"],
      "keywords": ["记得", "之前", "说过"]
    }
  }
}
```

## API 参考

### 增强搜索选项

```typescript
interface EnhancedSearchOptions {
  maxResults?: number;      // 最大结果数（默认 20）
  minScore?: number;        // 最小分数（默认 0.3）
  useSemantic?: boolean;    // 启用语义搜索（默认 true）
  useHybrid?: boolean;      // 启用混合搜索（默认 true）
  keywordWeight?: number;   // 关键词权重（默认 0.3）
  semanticWeight?: number;  // 语义权重（默认 0.7）
}
```

### 系统统计

```typescript
interface SystemStats {
  memories: {
    total: number;
    byType: Record<string, number>;
    byTier: Record<string, number>;
  };
  vectors: {
    totalVectors: number;
    cacheSize: number;
  };
  llm: {
    totalCalls: number;
    successfulCalls: number;
    failedCalls: number;
    averageLatencyMs: number;
    isAvailable: boolean;
  };
  backups: {
    totalBackups: number;
    totalSizeBytes: number;
  };
}
```

## 架构图

```
┌─────────────────────────────────────────────────────────────┐
│                    JiyixitongWan v2.0                       │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │   记忆提取    │  │   记忆搜索    │  │   反思引擎    │      │
│  │  Extractor   │  │    Search    │  │  Reflector   │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                 │                 │               │
│         └─────────────────┼─────────────────┘               │
│                           │                                 │
│              ┌────────────┴────────────┐                   │
│              │     VectorStore         │                   │
│              │  (向量存储 & 相似度计算)   │                   │
│              └────────────┬────────────┘                   │
│                           │                                 │
│         ┌─────────────────┼─────────────────┐              │
│         │                 │                 │               │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐        │
│  │   SQLite    │  │  vectors.json│  │   Backup    │        │
│  │  (记忆数据)  │  │  (向量索引)  │  │  (备份管理)  │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
└─────────────────────────────────────────────────────────────┘
```

## 性能优化建议

1. **向量索引**：定期运行 `rebuildVectorIndex()` 优化搜索性能
2. **备份策略**：根据数据量调整 `maxBackups` 和备份频率
3. **LLM 选择**：本地 Ollama 适合隐私场景，Groq 适合速度优先
4. **混合搜索权重**：根据场景调整 keywordWeight 和 semanticWeight

## 故障排除

### LLM 不可用
- 检查 Ollama 服务是否运行：`ollama serve`
- 查看连续失败计数：`(await jyx.getStats()).llm.failedCalls`
- 系统会自动降级到规则提取

### 向量搜索无结果
- 检查向量索引：`(await jyx.getStats()).vectors.totalVectors`
- 重建索引：`await jyx.rebuildVectorIndex()`
- 降低 minScore 阈值

### 备份失败
- 检查磁盘空间
- 确认备份目录权限
- 查看错误日志

## 版本历史

### v2.0.0 (增强版)
- 添加向量搜索和混合检索
- 增强 LLM 错误处理和降级机制
- 添加备份与导出功能
- 添加性能监控和统计
- OpenClaw 自动触发配置

### v1.0.0 (基础版)
- 基础记忆存储和检索
- SQLite 数据库支持
- MCP 协议支持
- 反思和成长追踪
