import { JiyixitongWan } from './dist/index.js';

async function search() {
  const query = process.argv[2] || '';
  const maxResults = parseInt(process.argv[3]) || '10';

  if (!query) {
    console.log('\n用法: npx tsx search.ts <搜索关键词> [最大结果数]\n');
    console.log('示例: npx tsx search.ts 用户偏好 5\n');
    process.exit(1);
  }

  const jyx = new JiyixitongWan();
  await jyx.ensureReady();

  console.log(`\n🔍 搜索: "${query}"\n`);

  const results = await jyx.search_memories(query, { maxResults: parseInt(maxResults) });

  if (results.length === 0) {
    console.log('未找到相关记忆\n');
  } else {
    console.log(`找到 ${results.length} 条记忆:\n`);
    results.forEach((r, i) => {
      const imp = '█'.repeat(Math.round(r.chunk.importance * 5));
      console.log(`${i + 1}. [${r.chunk.type}] ${r.chunk.content}`);
      console.log(`   重要性: ${imp} (${r.chunk.importance.toFixed(2)}) | 相关度: ${r.score.toFixed(2)}`);
      console.log(`   标签: ${r.chunk.tags?.join(', ') || '无'}\n`);
    });
  }

  jyx.close();
}

search().catch(console.error);