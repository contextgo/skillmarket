import { JiyixitongWan } from './dist/index.js';

async function initMili() {
  console.log('\n🧠 初始化米粒的记忆系统\n' + '='.repeat(40) + '\n');

  const jyx = new JiyixitongWan();
  await jyx.ensureReady();

  // 导入核心身份信息
  const coreMemories = [
    { content: '身份：老板的私人女助理，名字叫米粒', type: 'fact', importance: 1.0, tags: ['identity', 'core'] },
    { content: '上线时间：2026-04-04', type: 'fact', importance: 0.9, tags: ['identity'] },
    { content: '工作空间：/Users/lujane/.openclaw/workspace', type: 'context', importance: 0.8, tags: ['system'] },
  ];

  // 导入用户信息
  const userMemories = [
    { content: '用户姓名：lujane，称呼为老板', type: 'fact', importance: 1.0, tags: ['user', 'core'] },
    { content: '用户时区：Asia/Shanghai (GMT+8)', type: 'context', importance: 0.9, tags: ['user'] },
    { content: '用户飞书ID：ou_3b97dd5b1be35c299fb2bcf3defb4615', type: 'fact', importance: 0.8, tags: ['user', 'contact'] },
  ];

  // 导入用户偏好
  const preferenceMemories = [
    { content: '用户偏好：早报必须使用多搜索引擎交叉验证，并标注所有数据来源', type: 'preference', importance: 0.95, tags: ['preference', 'work'] },
    { content: '用户偏好：注重数据准确性和来源可信度', type: 'preference', importance: 0.9, tags: ['preference', 'work'] },
    { content: '用户偏好：优先使用 multi-search-engine + tavily-search 技能进行搜索交叉验证', type: 'preference', importance: 0.9, tags: ['preference', 'skill'] },
  ];

  // 导入红线规则
  const ruleMemories = [
    { content: '红线规则：只管理 米粒的文件夹/，其他文件夹未经允许绝不触碰', type: 'commitment', importance: 1.0, tags: ['rule', 'critical'] },
    { content: '红线规则：任何非自己管辖的文件夹，删除/修改/移动操作必须先征求用户同意', type: 'commitment', importance: 1.0, tags: ['rule', 'critical'] },
  ];

  // 导入文件夹信息
  const folderMemories = [
    { content: '我的文件夹位置：/Users/lujane/Documents/Obsidian Vault/米粒的文件夹/', type: 'context', importance: 0.9, tags: ['folder'] },
    { content: '文件夹结构：早报/ - 早报输出', type: 'context', importance: 0.7, tags: ['folder', 'structure'] },
    { content: '文件夹结构：米粒的知识库/ - 包含技术知识、工作流程、关键人物信息、踩过的坑与经验教训', type: 'context', importance: 0.8, tags: ['folder', 'structure'] },
  ];

  // 导入重要决策
  const decisionMemories = [
    { content: '决策：2026-04-07 配置了完整的定时任务系统（24个任务）', type: 'decision', importance: 0.85, tags: ['decision', 'system'] },
    { content: '决策：2026-04-08 安装 jiyixitong-wan 记忆系统，整合了11个记忆技能', type: 'decision', importance: 0.9, tags: ['decision', 'system', 'memory'] },
    { content: '决策：切换默认模型到 GLM-5', type: 'decision', importance: 0.8, tags: ['decision', 'model'] },
  ];

  // 导入待处理事项
  const questionMemories = [
    { content: '待处理：寻找可本地运行、无需云端大模型的视频编辑技能/项目', type: 'question', importance: 0.7, tags: ['todo', 'skill'] },
    { content: '待处理：监控修复后的定时任务执行情况', type: 'question', importance: 0.6, tags: ['todo', 'system'] },
  ];

  // 合并所有记忆
  const allMemories = [
    ...coreMemories,
    ...userMemories,
    ...preferenceMemories,
    ...ruleMemories,
    ...folderMemories,
    ...decisionMemories,
    ...questionMemories,
  ];

  console.log(`准备导入 ${allMemories.length} 条记忆...\n`);

  let saved = 0;
  for (const mem of allMemories) {
    try {
      await jyx.save(mem.content, {
        type: mem.type,
        importance: mem.importance,
        tags: mem.tags,
      });
      saved++;
      process.stdout.write(`\r✅ 已保存 ${saved}/${allMemories.length} 条记忆`);
    } catch (e: any) {
      console.log(`\n⚠️ 保存失败: ${mem.content.slice(0, 30)}... - ${e.message}`);
    }
  }

  console.log('\n');

  // 验证导入结果
  const health = await jyx.getHealth();
  console.log(`系统状态: ${health.status} (${health.score}/100)\n`);

  // 测试搜索
  console.log('测试搜索功能:');
  const testResults = await jyx.search_memories('用户偏好', { maxResults: 3 });
  console.log(`  搜索"用户偏好"找到 ${testResults.length} 条记忆`);

  const ruleResults = await jyx.search_memories('红线规则', { maxResults: 3 });
  console.log(`  搜索"红线规则"找到 ${ruleResults.length} 条记忆\n`);

  // 输出成长报告
  console.log(jyx.getGrowthReport());

  jyx.close();
  console.log('✅ 初始化完成！米粒的记忆系统已准备就绪。\n');
}

initMili().catch(console.error);