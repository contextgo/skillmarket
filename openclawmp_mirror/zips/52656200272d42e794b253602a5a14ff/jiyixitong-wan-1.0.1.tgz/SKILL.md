---
name: jiyixitong-wan
description: "完整智能体记忆系统，提供长期记忆、自我反思、成长追踪和智能检索。使用时机：当需要记忆存储、记忆提取、记忆搜索、反思整合、量化追踪、记忆维护时使用。触发词：记忆、记住、回忆、长期记忆、记忆存储、记忆提取、记忆搜索、反思、知识库维护、经验积累。支持MCP协议和智能体隔离。"
---

# 记忆系统-完整版 (jiyixitong-wan)

## 快速开始

```bash
# 安装依赖
npm install

# 编译
npm run build

# 运行测试
node bin/jiyixitong-wan.js test
```

## 核心功能

### 1. 基础使用

```typescript
import { JiyixitongWan } from './dist/index.js';

const jyx = new JiyixitongWan();

// 保存记忆
await jyx.save("用户喜欢TypeScript", { type: 'preference', importance: 0.9 });

// 搜索记忆
const results = await jyx.search_memories("用户对什么框架有偏好？");

// 从对话提取记忆
const memories = await jyx.extract(messages, conversationId);
```

### 2. MCP Server 使用（企业级）

```bash
# 启动 MCP Server
npx jiyixitong-mcp
```

**MCP Tools:**
- `agent_initialize` - 初始化智能体（隔离）
- `memory_save` / `memory_search` - 记忆操作
- `memory_reflect` - 触发反思
- `system_health` / `system_maintain` - 系统维护

详见 [references/mcp-tools.md](references/mcp-tools.md)

### 3. LLM 配置

**方案1: Ollama（本地免费）**
```bash
brew install ollama
ollama serve
ollama pull llama3.2
ollama pull nomic-embed-text
```

**方案2: Groq（免费API）**
```typescript
const groq = FreeProviders.groq('your-api-key');
jyx.setLLMProvider(groq);
```

详见 [references/llm-setup.md](references/llm-setup.md)

## 参考文档

- **架构设计**: [references/architecture.md](references/architecture.md)
- **API参考**: [references/api-reference.md](references/api-reference.md)
- **记忆类型**: [references/memory-types.md](references/memory-types.md)
- **MCP工具**: [references/mcp-tools.md](references/mcp-tools.md)
- **LLM配置**: [references/llm-setup.md](references/llm-setup.md)
- **OpenClaw集成**: [references/openclaw-integration.md](references/openclaw-integration.md)

## CLI命令

```bash
jiyixitong-wan status      # 系统状态
jiyixitong-wan migrate     # 迁移原有记忆
jiyixitong-wan audit       # 审计记忆
jiyixitong-wan clean       # 清理记忆
jiyixitong-wan maintain    # 运行维护
jiyixitong-wan grow        # 成长报告
jiyixitong-wan questions   # 待处理问题
```

## 技术规格

| 参数 | 默认值 | 描述 |
|------|--------|------|
| 数据库引擎 | SQLite | 轻量化存储引擎 |
| 核心记忆上限 | 3,000 tokens | 核心记忆上限 |
| 衰减率 λ | 0.03 | 衰减率 (~23天半衰期) |
| 归档阈值 | 0.05 | 归档阈值 |
| 搜索最大结果 | 20 | 最大搜索结果 |
| 智能体隔离 | ✅ | 多智能体独立存储 |
| MCP协议支持 | ✅ | 企业级集成 |
