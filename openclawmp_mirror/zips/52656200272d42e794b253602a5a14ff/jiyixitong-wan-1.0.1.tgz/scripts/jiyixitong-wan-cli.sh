#!/bin/bash
COMMAND="$1"
WORKSPACE_DIR="/Users/lujane/.openclaw/workspace"

case "$COMMAND" in
    status)
        echo "🧠 记忆系统-完整版状态检查"
        echo "============================="
        echo -e "\n📁 核心文件状态:"
        for file in MEMORY.md IDENTITY.md SOUL.md SESSION-STATE.md; do
            if [ -f "$WORKSPACE_DIR/$file" ]; then
                SIZE=$(du -h "$WORKSPACE_DIR/$file" | cut -f1)
                echo "✅ $file ($SIZE)"
            else
                echo "❌ $file 缺失"
            fi
        done
        echo -e "\n📂 目录结构:"
        for dir in memory/episodes memory/graph/entities memory/procedures memory/vault memory/meta; do
            if [ -d "$WORKSPACE_DIR/$dir" ]; then
                COUNT=$(ls "$WORKSPACE_DIR/$dir" 2>/dev/null | wc -l)
                echo "✅ $dir ($COUNT 文件)"
            else
                echo "❌ $dir 缺失"
            fi
        done
        echo -e "\n🚀 系统状态: 正常运行"
        ;;
    maintain)
        node "$WORKSPACE_DIR/skills/jiyixitong-wan/bin/jiyixitong-wan.js" maintain 2>&1
        ;;
    test)
        node "$WORKSPACE_DIR/skills/jiyixitong-wan/bin/jiyixitong-wan.js" test 2>&1
        ;;
    help|*)
        echo "🧠 记忆系统-完整版 CLI工具"
        echo "用法: bash jiyixitong-wan-cli.sh [status|maintain|test|help]"
        ;;
esac
