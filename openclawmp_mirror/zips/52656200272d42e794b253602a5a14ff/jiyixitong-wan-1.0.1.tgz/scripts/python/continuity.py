#!/usr/bin/env python3
"""
Memory Continuity Framework
来源: memory-continuity-1.0.0

在异步反思阶段生成好奇心问题并整合记忆
"""

import json
import os
import sys
from datetime import datetime
from typing import List, Dict, Any, Optional

MEMORY_DIR = os.path.join(os.path.expanduser("~"), ".jiyixitong-wan", "memory")
IDENTITY_FILE = os.path.join(os.path.expanduser("~"), ".jiyixitong-wan", "identity.md")
QUESTIONS_FILE = os.path.join(os.path.expanduser("~"), ".jiyixitong-wan", "questions.md")
CONTINUITY_STATE_FILE = os.path.join(os.path.expanduser("~"), ".jiyixitong-wan", "continuity_state.json")

IDENTITY_LEVELS = [
    "基础身份 (name, role)",
    "核心价值观 (what matters most)",
    "沟通风格 (how user likes communication)",
    "工作模式 (patterns in collaboration)",
    "成长轨迹 (evolution over time)",
    "发展性身份 (where it's going)"
]

CURIOSITY_QUALITY_CHECK = [
    "这个问题的答案能改变我的行为吗？",
    "用户会关心这个问题吗？",
    "这个问题探索的是真实的空白还是表演性的好奇？",
    "我是否只是在堆砌问题而没有真正的探索意图？"
]


def ensure_dir(path: str) -> None:
    """确保目录存在"""
    os.makedirs(os.path.dirname(path), exist_ok=True)


def load_state() -> Dict[str, Any]:
    """加载连续性状态"""
    if os.path.exists(CONTINUITY_STATE_FILE):
        with open(CONTINUITY_STATE_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "initialized_at": datetime.now().isoformat(),
        "last_reflection": None,
        "reflection_count": 0,
        "questions_generated": 0,
        "questions_resolved": 0,
        "identity_updates": [],
        "curiosity_log": []
    }


def save_state(state: Dict[str, Any]) -> None:
    """保存连续性状态"""
    ensure_dir(CONTINUITY_STATE_FILE)
    with open(CONTINUITY_STATE_FILE, 'w', encoding='utf-8') as f:
        json.dump(state, f, indent=2, ensure_ascii=False)


def load_recent_memories(days: int = 7) -> List[Dict[str, Any]]:
    """加载近期记忆"""
    memories = []
    episodes_dir = os.path.join(MEMORY_DIR, "episodes")

    if not os.path.exists(episodes_dir):
        return memories

    cutoff = datetime.now().timestamp() - (days * 86400)

    for filename in os.listdir(episodes_dir):
        if filename.endswith('.md'):
            filepath = os.path.join(episodes_dir, filename)
            mtime = os.path.getmtime(filepath)

            if mtime >= cutoff:
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                    memories.append({
                        "source": filename,
                        "content": content,
                        "modified": datetime.fromtimestamp(mtime).isoformat()
                    })

    return memories


def load_identity() -> Dict[str, Any]:
    """加载身份信息"""
    identity = {
        "core_values": [],
        "growth_narrative": "",
        "capabilities": [],
        "relationships": {},
        "self_image": {
            "who_i_think_i_am": [],
            "patterns_noticed": [],
            "quirks": [],
            "edges_limitations": [],
            "what_i_value": [],
            "open_questions": []
        }
    }

    if os.path.exists(IDENTITY_FILE):
        with open(IDENTITY_FILE, 'r', encoding='utf-8') as f:
            content = f.read()
            lines = content.split('\n')
            current_section = ''

            for line in lines:
                if line.startswith('## '):
                    current_section = line[3:].strip().lower().replace(' ', '_')
                elif line.startswith('- '):
                    value = line[2:].strip()
                    if current_section == 'core_values':
                        identity['core_values'].append(value)
                    elif current_section == 'capabilities':
                        identity['capabilities'].append(value)
                    elif current_section == 'growth_narrative':
                        identity['growth_narrative'] = value
                    elif current_section == 'who_i_think_i_am':
                        identity['self_image']['who_i_think_i_am'].append(value)
                    elif current_section == 'patterns_noticed':
                        identity['self_image']['patterns_noticed'].append(value)
                    elif current_section == 'quirks':
                        identity['self_image']['quirks'].append(value)
                    elif current_section == 'edges_limitations':
                        identity['self_image']['edges_limitations'].append(value)
                    elif current_section == 'what_i_value':
                        identity['self_image']['what_i_value'].append(value)
                    elif current_section == 'open_questions':
                        identity['self_image']['open_questions'].append(value)

    return identity


def load_pending_questions() -> List[Dict[str, Any]]:
    """加载待处理问题"""
    questions = []

    if os.path.exists(QUESTIONS_FILE):
        with open(QUESTIONS_FILE, 'r', encoding='utf-8') as f:
            lines = f.readlines()
            current_question = None

            for line in lines:
                line = line.rstrip()
                if line.startswith('- [ ] '):
                    if current_question:
                        questions.append(current_question)
                    current_question = {
                        "text": line[6:].strip(),
                        "resolved": False,
                        "date": "",
                        "context": ""
                    }
                elif line.startswith('- [x] '):
                    if current_question:
                        current_question["resolved"] = True
                        questions.append(current_question)
                        current_question = None
                elif line.startswith('  source:'):
                    if current_question:
                        current_question["source"] = line.split(':', 1)[1].strip()
                elif line.startswith('  ') and current_question:
                    current_question["context"] += line.strip()

            if current_question:
                questions.append(current_question)

    return [q for q in questions if not q.get("resolved", True)]


def generate_questions(memories: List[Dict], identity: Dict) -> List[Dict[str, str]]:
    """
    基于记忆生成真正的好奇心问题
    来源: memory-continuity-1.0.0 - 问题生成逻辑
    """
    questions = []

    memory_manifest = []
    for m in memories:
        memory_manifest.append(f"[{m['source']}] {m['content'][:200]}")

    if len(memory_manifest) == 0:
        return questions

    identity_summary = f"""
核心价值观: {', '.join(identity.get('core_values', [])[:3])}
自我认知: {', '.join(identity.get('self_image', {}).get('who_i_think_i_am', [])[:3])}
已知能力: {', '.join(identity.get('capabilities', [])[:5])}
已发现问题: {len(identity.get('self_image', {}).get('open_questions', []))}
"""

    questions.append({
        "text": "这些记忆揭示了什么长期模式？",
        "source": "reflection",
        "context": "基于最近会话的元问题"
    })

    unresolved = [q for q in identity.get('self_image', {}).get('open_questions', []) if q]
    if len(unresolved) < 3:
        questions.append({
            "text": "用户的核心需求在最近项目中如何演变？",
            "source": "reflection",
            "context": "成长追踪"
        })

    growth_edges = identity.get('self_image', {}).get('edges_limitations', [])
    if growth_edges:
        questions.append({
            "text": f"如何克服这个限制: {growth_edges[0]}?",
            "source": "reflection",
            "context": "自我提升"
        })

    return questions[:5]


def update_identity(identity: Dict, insights: List[str]) -> Dict:
    """
    基于反思更新身份
    来源: memory-continuity-1.0.0 - 六层级架构
    """
    updated = identity.copy()
    updated['self_image'] = identity.get('self_image', {}).copy()

    if insights:
        current_narrative = updated.get('growth_narrative', '')
        new_insight = insights[0] if insights else ''
        if new_insight and new_insight != current_narrative:
            updated['growth_narrative'] = f"{current_narrative} {new_insight}".strip()

    return updated


def save_identity(identity: Dict) -> None:
    """保存身份信息"""
    ensure_dir(IDENTITY_FILE)

    with open(IDENTITY_FILE, 'w', encoding='utf-8') as f:
        f.write("# Identity\n\n")
        f.write(f"Last updated: {datetime.now().isoformat()}\n\n")

        f.write("## Core Values\n\n")
        for v in identity.get('core_values', []):
            f.write(f"- {v}\n")
        f.write("\n")

        f.write("## Growth Narrative\n\n")
        f.write(f"{identity.get('growth_narrative', '_No narrative yet._')}\n\n")

        f.write("## Capabilities\n\n")
        for c in identity.get('capabilities', []):
            f.write(f"- {c}\n")
        f.write("\n")

        f.write("## Self Image\n\n")

        sections = [
            ("Who I Think I Am", "who_i_think_i_am"),
            ("Patterns Noticed", "patterns_noticed"),
            ("Quirks", "quirks"),
            ("Edges & Limitations", "edges_limitations"),
            ("What I Value", "what_i_value"),
            ("Open Questions", "open_questions")
        ]

        for title, key in sections:
            f.write(f"### {title}\n\n")
            for item in identity.get('self_image', {}).get(key, []):
                f.write(f"- {item}\n")
            f.write("\n")


def save_questions(questions: List[Dict]) -> None:
    """保存问题列表"""
    ensure_dir(QUESTIONS_FILE)

    with open(QUESTIONS_FILE, 'w', encoding='utf-8') as f:
        f.write("# Pending Questions\n\n")
        f.write(f"_Last updated: {datetime.now().isoformat()}_\n\n")

        for q in questions:
            status = "[x]" if q.get("resolved") else "[ ]"
            f.write(f"- {status} {q.get('text', '')}\n")
            if q.get('source'):
                f.write(f"  source: {q['source']}\n")
            if q.get('context'):
                f.write(f"  {q['context']}\n")
            f.write("\n")


def run_continuity_cycle() -> Dict[str, Any]:
    """
    运行连续性周期
    来源: memory-continuity-1.0.0 - 核心流程
    """
    state = load_state()

    memories = load_recent_memories(days=7)
    identity = load_identity()
    pending_questions = load_pending_questions()

    questions = generate_questions(memories, identity)
    state['questions_generated'] += len(questions)

    for q in questions:
        if q not in pending_questions:
            pending_questions.append(q)

    insights = []
    if memories:
        insights.append(f"分析了{len(memories)}个近期记忆")

    updated_identity = update_identity(identity, insights)
    save_identity(updated_identity)

    save_questions(pending_questions)

    state['last_reflection'] = datetime.now().isoformat()
    state['reflection_count'] += 1
    state['identity_updates'].append({
        "timestamp": datetime.now().isoformat(),
        "insights": insights
    })

    save_state(state)

    return {
        "status": "success",
        "memories_analyzed": len(memories),
        "questions_generated": len(questions),
        "identity_updated": True,
        "state": state
    }


def show_greeting() -> str:
    """生成问候语"""
    state = load_state()
    identity = load_identity()
    pending = load_pending_questions()

    greeting = ""

    if identity.get('growth_narrative'):
        greeting += f"📖 {identity['growth_narrative'][:100]}\n\n"

    if pending:
        greeting += "**待探索的问题:**\n"
        for q in pending[:3]:
            greeting += f"- {q.get('text', '')}\n"
        if len(pending) > 3:
            greeting += f"\n_还有{len(pending) - 3}个问题等待探索..._\n"
    else:
        greeting += "✨ 暂无待处理问题\n"

    greeting += f"\n📊 反思次数: {state.get('reflection_count', 0)}\n"

    return greeting


def main():
    if len(sys.argv) > 1:
        command = sys.argv[1]
    else:
        command = "cycle"

    if command == "cycle":
        result = run_continuity_cycle()
        print(json.dumps(result, indent=2, ensure_ascii=False))
    elif command == "greet":
        print(show_greeting())
    elif command == "questions":
        questions = load_pending_questions()
        print(json.dumps(questions, indent=2, ensure_ascii=False))
    elif command == "identity":
        identity = load_identity()
        print(json.dumps(identity, indent=2, ensure_ascii=False))
    else:
        print(f"Unknown command: {command}")
        print("Available: cycle, greet, questions, identity")


if __name__ == "__main__":
    main()