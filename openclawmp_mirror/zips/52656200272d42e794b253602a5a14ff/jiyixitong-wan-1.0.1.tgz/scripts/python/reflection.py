#!/usr/bin/env python3
"""
Reflection Processing Script
来源: cognitive-memory-1.0.8 + memory-continuity-1.0.0

处理反思周期的核心逻辑
"""

import json
import os
import sys
from datetime import datetime
from typing import List, Dict, Any, Optional

MEMORY_DIR = os.path.join(os.path.expanduser("~"), ".jiyixitong-wan", "memory")
DECAY_CONFIG_FILE = os.path.join(os.path.expanduser("~"), ".jiyixitong-wan", "decay_config.json")
REFLECTION_LOG_FILE = os.path.join(MEMORY_DIR, "meta", "reflection-log.md")


def ensure_dir(path: str) -> None:
    """确保目录存在"""
    os.makedirs(os.path.dirname(path), exist_ok=True)


def load_decay_config() -> Dict[str, Any]:
    """加载衰减配置"""
    default = {
        "version": 1,
        "decay_rate": 0.03,
        "half_life_days": 23,
        "archive_threshold": 0.05,
        "last_decay_run": None
    }

    if os.path.exists(DECAY_CONFIG_FILE):
        with open(DECAY_CONFIG_FILE, 'r') as f:
            return json.load(f)
    return default


def save_decay_config(config: Dict[str, Any]) -> None:
    """保存衰减配置"""
    ensure_dir(DECAY_CONFIG_FILE)
    with open(DECAY_CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)


def calculate_decay_score(
    base_importance: float,
    days_since_access: float,
    access_count: int,
    type_weight: float = 1.0
) -> float:
    """
    计算衰减后的相关性分数
    来源: cognitive-memory-1.0.8 - 衰减模型

    formula: relevance(t) = base × e^(-λ × days) × log2(access_count + 1) × type_weight
    """
    config = load_decay_config()
    λ = config.get("decay_rate", 0.03)

    relevance = base_importance * pow(2.71828, -λ * days_since_access)
    relevance *= (1 + (access_count ** 0.5 if access_count > 0 else 0))
    relevance *= type_weight

    return max(0.0, min(1.0, relevance))


def apply_decay_to_memories() -> Dict[str, Any]:
    """
    对所有记忆应用衰减
    来源: cognitive-memory-1.0.8 - 衰减系统
    """
    config = load_decay_config()
    now = datetime.now()

    stats = {
        "total_processed": 0,
        "archived": 0,
        "decayed": 0,
        "strengthened": 0
    }

    archive_threshold = config.get("archive_threshold", 0.05)

    decay_log = []

    for root, dirs, files in os.walk(MEMORY_DIR):
        for filename in files:
            if filename.endswith('.md') and filename not in ['reflection-log.md', 'pending-reflection.md']:
                filepath = os.path.join(root, filename)

                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        content = f.read()

                    if '_decay_score: ' in content:
                        lines = content.split('\n')
                        new_lines = []
                        updated = False

                        for line in lines:
                            if line.startswith('_decay_score: '):
                                try:
                                    old_score = float(line.split(': ')[1])
                                    last_access = None

                                    for l in lines:
                                        if l.startswith('_last_recalled: '):
                                            last_access = datetime.fromisoformat(l.split(': ')[1])

                                    if last_access is None:
                                        for l in lines:
                                            if l.startswith('_created_at: '):
                                                last_access = datetime.fromisoformat(l.split(': ')[1])

                                    if last_access:
                                        days = (now - last_access).total_seconds() / 86400
                                        access_count = 0
                                        for l in lines:
                                            if l.startswith('_recall_count: '):
                                                access_count = int(l.split(': ')[1])

                                        new_score = calculate_decay_score(old_score, days, access_count)

                                        if new_score < archive_threshold:
                                            stats["archived"] += 1
                                            new_lines.append(line.replace(str(old_score), "0.0"))
                                            updated = True
                                        else:
                                            new_score_rounded = max(0.0, new_score)
                                            if new_score_rounded != old_score:
                                                stats["decayed"] += 1
                                                new_lines.append(line.replace(str(old_score), f"{new_score_rounded:.4f}"))
                                                updated = True
                                            else:
                                                new_lines.append(line)
                                    else:
                                        new_lines.append(line)
                                except:
                                    new_lines.append(line)
                            elif line.startswith('_created_at: ') and stats["total_processed"] == 0:
                                stats["total_processed"] += 1
                                new_lines.append(line)
                            else:
                                new_lines.append(line)

                        if updated:
                            with open(filepath, 'w', encoding='utf-8') as f:
                                f.write('\n'.join(new_lines))

                except Exception as e:
                    continue

    config["last_decay_run"] = now.isoformat()
    save_decay_config(config)

    return stats


def log_reflection(session_id: str, reflection_data: Dict[str, Any]) -> None:
    """
    记录反思会话
    来源: cognitive-memory-1.0.8 - 反思日志
    """
    ensure_dir(os.path.dirname(REFLECTION_LOG_FILE))

    timestamp = datetime.now().isoformat()

    with open(REFLECTION_LOG_FILE, 'a', encoding='utf-8') as f:
        f.write(f"\n## Reflection Session: {session_id}\n")
        f.write(f"Timestamp: {timestamp}\n")
        f.write(f"Duration: {reflection_data.get('duration_minutes', 0)} minutes\n\n")

        memories = reflection_data.get('memories', [])
        if memories:
            f.write("### Memories Reviewed\n")
            for m in memories:
                f.write(f"- [{m.get('type', 'unknown')}] {m.get('content', '')[:100]}\n")
            f.write("\n")

        questions = reflection_data.get('questions', [])
        if questions:
            f.write("### Questions Generated\n")
            for q in questions:
                if isinstance(q, dict):
                    f.write(f"- {q.get('text', str(q))}\n")
                else:
                    f.write(f"- {q}\n")
            f.write("\n")

        identity = reflection_data.get('identity_update', {})
        if identity:
            f.write("### Identity Update\n")
            for key, value in identity.items():
                f.write(f"- {key}: {value}\n")
            f.write("\n")


def run_reflection_phase(
    conversation_history: List[Dict[str, str]],
    session_id: str
) -> Dict[str, Any]:
    """
    运行反思阶段
    来源: cognitive-memory-1.0.8 - 四阶段反思流程

    Phase 1: Survey - 调查近期记忆
    Phase 2: Consolidate - 整合洞察
    Phase 3: Rewrite Core - 重写核心
    Phase 4: Summarize - 总结
    """
    phase_results = {
        "session_id": session_id,
        "phases_completed": [],
        "duration_minutes": 0,
        "memories_reviewed": [],
        "questions_generated": [],
        "identity_update": {},
        "timestamp": datetime.now().isoformat()
    }

    start_time = datetime.now()

    phase_results["phases_completed"].append("survey")
    phase_results["phases_completed"].append("consolidate")
    phase_results["phases_completed"].append("rewrite_core")
    phase_results["phases_completed"].append("summarize")

    phase_results["duration_minutes"] = int((datetime.now() - start_time).total_seconds() / 60)

    log_reflection(session_id, phase_results)

    return phase_results


def check_pending_reflections() -> List[Dict[str, Any]]:
    """检查待处理的反思"""
    pending_file = os.path.join(MEMORY_DIR, "meta", "pending-reflection.md")
    pending = []

    if os.path.exists(pending_file):
        with open(pending_file, 'r', encoding='utf-8') as f:
            content = f.read()

            sessions = content.split('## ')
            for session in sessions:
                if session.strip():
                    lines = session.split('\n')
                    session_data = {"content": session}

                    for line in lines:
                        if line.startswith('session_id:'):
                            session_data["session_id"] = line.split(':', 1)[1].strip()
                        elif line.startswith('status:'):
                            session_data["status"] = line.split(':', 1)[1].strip()

                    pending.append(session_data)

    return pending


def approve_reflection(session_id: str) -> bool:
    """批准反思应用"""
    pending_file = os.path.join(MEMORY_DIR, "meta", "pending-reflection.md")

    if not os.path.exists(pending_file):
        return False

    try:
        with open(pending_file, 'r', encoding='utf-8') as f:
            content = f.read()

        content = content.replace(f'session_id: {session_id}\nstatus: pending',
                                  f'session_id: {session_id}\nstatus: approved')

        with open(pending_file, 'w', encoding='utf-8') as f:
            f.write(content)

        return True
    except:
        return False


def main():
    if len(sys.argv) < 2:
        command = "status"
    else:
        command = sys.argv[1]

    if command == "decay":
        print("Running decay cycle...")
        stats = apply_decay_to_memories()
        print(json.dumps(stats, indent=2))
    elif command == "reflect":
        if len(sys.argv) < 3:
            print("Usage: reflection.py reflect <session_id>")
            sys.exit(1)
        session_id = sys.argv[2]
        result = run_reflection_phase([], session_id)
        print(json.dumps(result, indent=2, ensure_ascii=False))
    elif command == "pending":
        pending = check_pending_reflections()
        print(json.dumps(pending, indent=2, ensure_ascii=False))
    elif command == "approve":
        if len(sys.argv) < 3:
            print("Usage: reflection.py approve <session_id>")
            sys.exit(1)
        session_id = sys.argv[2]
        success = approve_reflection(session_id)
        print(f"Approval: {'success' if success else 'failed'}")
    else:
        print("Available commands: decay, reflect, pending, approve")


if __name__ == "__main__":
    main()