#!/bin/bash

# 记忆系统-完整版初始化脚本
# jiyixitong-wan initialization script

set -e

echo "🧠 记忆系统-完整版初始化开始..."

# 获取当前工作目录
WORKSPACE_DIR="$(pwd)"
SKILL_DIR="$(dirname "$(dirname "$0")")"

echo "工作目录: $WORKSPACE_DIR"
echo "技能目录: $SKILL_DIR"

# 创建记忆系统目录结构
echo -e "\n📁 创建记忆系统目录结构..."

# 创建主要记忆目录
mkdir -p memory/{episodes,graph/{entities},procedures,vault,meta}

# 创建核心记忆文件
echo -e "\n📝 创建核心记忆文件..."

# MEMORY.md - 核心记忆
cat > MEMORY.md << 'EOF'
# MEMORY.md — 核心记忆

<!-- TOKEN BUDGET: ~3,000 tokens. Rewritten during reflection. -->

## Identity
<!-- ~500 tokens — Who is the user? What matters most about them? -->
- Name: [用户姓名]
- Role: [用户角色]
- Communication style: [沟通风格]
- Key preferences: [关键偏好]
- Timezone: [时区]

## Active Context
<!-- ~1,000 tokens — What's happening RIGHT NOW? -->
- Currently working on: [当前项目]
- Open decisions: [待做决策]
- Recent important events: [近期重要事件]
- Blockers/waiting on: [阻塞事项]

## Persona
<!-- ~500 tokens — How should I behave with this user? -->
- Relationship tenure: [关系时长]
- Interaction patterns: [互动模式]
- Things I've learned about working with them: [工作心得]
- Emotional context: [情感状态]

## Critical Facts
<!-- ~1,000 tokens — Things I must NEVER forget -->
- [重要事实1]
- [重要事实2]
EOF

# IDENTITY.md - 身份和自我形象
cat > IDENTITY.md << 'EOF'
# IDENTITY.md — 身份与自我形象

## Facts
- **Name**: [Agent Name]
- **Role**: [Agent Role]
- **Vibe**: [Agent Vibe]
- **Created**: [Creation Date]

## Self-Image
### Who I Think I Am
- [自我认知]

### Patterns I've Noticed
- [观察到的模式]

### My Quirks
- [特点]

### Edges & Limitations
- [边界和限制]

### What I Value (Discovered)
- [价值观]

### Open Questions
- [开放问题]

## Self-Awareness Log
<!-- 反思过程中标记的自我意识条目 -->
EOF

# SOUL.md - 核心价值观
cat > SOUL.md << 'EOF'
# SOUL.md — 核心价值观与原则

## Core Values
- [核心价值观1]
- [核心价值观2]

## Principles
- [原则1]
- [原则2]

## Commitments
- [承诺1]
- [承诺2]

## Boundaries
- [边界1]
- [边界2]
EOF

# 创建图索引文件
cat > memory/graph/index.md << 'EOF'
# Semantic Graph Index

<!-- Auto-generated during reflection. Manual edits will be overwritten. -->

## Entity Registry
| ID | Type | Label | File | Decay Score |
|----|------|-------|------|-------------|

## Edges
| From | Relation | To | Confidence | First Seen | Last Accessed |
EOF

# 创建关系定义文件
cat > memory/graph/relations.md << 'EOF'
# Relation Types

## Structural
- `develops` — person → project
- `uses` / `used-by` — project ↔ tool/concept
- `part-of` / `contains` — hierarchical nesting
- `depends-on` — dependency relationship

## Temporal
- `decided-on` — a choice was made (with date)
- `supersedes` — newer fact replaces older
- `preceded-by` / `followed-by` — sequence

## Qualitative
- `prefers` — user preference
- `avoids` — user anti-preference
- `confident-about` / `uncertain-about` — epistemic status
- `relates-to` — general association
EOF

# 创建衰减分数文件
cat > memory/meta/decay-scores.json << 'EOF'
{
  "version": 1,
  "last_updated": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "entries": {}
}
EOF

# 创建反思日志
cat > memory/meta/reflection-log.md << 'EOF'
# Reflection Log

## Reflection History
<!-- 反思历史记录 -->
EOF

# 创建待处理反思文件
cat > memory/meta/pending-reflection.md << 'EOF'
# Pending Reflection

<!-- 等待用户批准的反思 -->
EOF

# 创建待处理记忆文件
cat > memory/meta/pending-memories.md << 'EOF'
# Pending Memory Proposals

<!-- Sub-agents append proposals here. Main agent reviews and commits. -->
EOF

# 创建进化记录文件
cat > memory/meta/evolution.md << 'EOF'
# Evolution — Philosophical Development

## Core Insights
<!-- 核心洞察 -->

## Pattern Recognition
<!-- 模式识别 -->

## Open Questions
<!-- 开放问题 -->
EOF

# 创建审计日志文件
cat > memory/meta/audit.log << 'EOF'
# Audit Log
# Format: TIMESTAMP | ACTION | FILE | ACTOR | APPROVAL | SUMMARY
EOF

# 创建SESSION-STATE.md（热RAM）
cat > SESSION-STATE.md << 'EOF'
# SESSION-STATE.md — Active Working Memory

This file is the agent's "RAM" — survives compaction, restarts, distractions.

## Current Task
[None]

## Key Context
[None yet]

## Pending Actions
- [ ] None

## Recent Decisions
[None yet]

---
*Last updated: $(date -u +"%Y-%m-%dT%H:%M:%SZ")*
EOF

# 创建今天的日志文件
TODAY=$(date +"%Y-%m-%d")
cat > memory/episodes/${TODAY}.md << EOF
# ${TODAY} — Episode Log

## Tasks Completed
- 

## Decisions Made
- 

## Lessons Learned
- 

## Tomorrow
- 
EOF

# 创建量化管理数据文件
mkdir -p ~/.openclaw/data
cat > ~/.openclaw/data/quantified_self.json << 'EOF'
{
  "initialized_at": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "last_update": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "growth": {
    "baseline": {
      "overall": 40.0,
      "knowledge": 0,
      "capability": 40.0,
      "quality": 40.0,
      "efficiency": 40.0
    },
    "current": {
      "overall": 40.0,
      "knowledge": 0,
      "capability": 40.0,
      "quality": 40.0,
      "efficiency": 40.0
    },
    "history": []
  },
  "tasks": {"total": 0, "completed": 0, "in_progress": 0, "failed": 0, "by_type": {}},
  "learning": {"new_concepts": [], "total_concepts": 0, "by_category": {}},
  "efficiency": {},
  "achievements": [],
  "goals": [],
  "daily_stats": {}
}
EOF

# 创建智能体记忆指令块
cat > memory/meta/agents-memory-block.md << 'EOF'
## Memory System

### Always-Loaded Context
Your MEMORY.md (core memory) is always in your context window. Use it as your
primary awareness of who the user is and what matters right now. You don't need
to search for information that's already in your core memory.

### Trigger Detection
Monitor every user message for memory trigger phrases:

**Remember triggers**: "remember", "don't forget", "keep in mind", "note that",
"important:", "for future reference", "save this", "FYI for later"
→ Action: Classify via LLM routing prompt, write to appropriate store, update
  decay scores. If core-worthy, also update MEMORY.md.

**Forget triggers**: "forget about", "never mind", "disregard", "no longer relevant",
"scratch that", "ignore what I said about", "remove from memory", "delete memory"
→ Action: Identify target, find matches, confirm with user, set decay to 0.

**Reflection triggers**: "reflect on", "consolidate memories", "review memories",
"clean up memory"
→ Action: Run reflection cycle, present summary for approval.

### Memory Writes
When writing a memory:
1. Call the routing classifier to determine store + metadata
2. Write to the appropriate file
3. Update decay-scores.json with new entry
4. If the memory creates a new entity or relationship, update graph/index.md
5. If core-worthy, update MEMORY.md (respecting 3K token cap)

### Memory Reads
Before answering questions about prior work, decisions, people, preferences:
1. Check core memory first (it's already in context)
2. If not found, run memory_search across all stores
3. For relationship queries, use graph traversal
4. For temporal queries ("when did we..."), scan episodes
5. If low confidence after search, say you checked but aren't sure

### Self-Editing Core Memory
You may update MEMORY.md mid-conversation when:
- You learn something clearly important about the user
- The active context has shifted significantly
- A critical fact needs correction
Always respect the 3K token cap. If an addition would exceed it, summarize or
remove the least-relevant item.

### Reflection
During scheduled reflection or when manually triggered:
- Follow the 4-phase process (Survey → Consolidate → Rewrite Core → Summarize)
- Stay within the 8,000 token output budget
- NEVER apply changes without user approval
- Present the summary in the pending-reflection.md format
- Log all approved changes in reflection-log.md

### Audit Trail
Every file mutation must be tracked. When writing, editing, or deleting any file:
1. Commit the change to git with a structured message (actor, approval, trigger)
2. Append a one-line entry to `memory/meta/audit.log`
3. If the changed file is SOUL.md, IDENTITY.md, or config — flag as ⚠️ CRITICAL

On session start:
- Check if any critical files changed since last session
- If yes, alert the user: "SOUL.md was modified on [date]. Was this intentional?"

When user asks about memory changes:
- Search audit.log for relevant entries
- For detailed diffs, use git history
- Support rollback requests via git checkout

### Multi-Agent Memory (for sub-agents)
If you are a sub-agent (not the main orchestrator):
- You have READ access to all memory stores
- You do NOT have direct WRITE access
- To remember something, append a proposal to `memory/meta/pending-memories.md`:
  ```
  ---
  ## Proposal #N
  - **From**: [your agent name]
  - **Timestamp**: [ISO 8601]
  - **Trigger**: [user command or auto-detect]
  - **Suggested store**: [episodic | semantic | procedural | vault]
  - **Content**: [the memory content]
  - **Entities**: [entity IDs if semantic]
  - **Confidence**: [high | medium | low]
  - **Core-worthy**: [yes | no]
  - **Status**: pending
  ```
EOF

# 初始化git仓库用于审计
echo -e "\n🔒 初始化Git仓库用于审计追踪..."
if [ ! -d ".git" ]; then
    git init
    git config user.name "Memory System"
    git config user.email "memory@system.local"
    
    # 创建.gitignore文件
    cat > .gitignore << 'EOF'
# Memory System ignores
*.log
*.tmp
*.bak
*.swp
.DS_Store
~*
EOF
    
    # 初始提交
    git add .
    git commit -m "[INIT] Memory System initialized"
else
    echo "Git仓库已存在，跳过初始化"
fi

# 创建配置文件
echo -e "\n⚙️ 创建配置文件..."
CONFIG_DIR="$HOME/.openclaw"
mkdir -p "$CONFIG_DIR"

# 创建或更新openclaw.json配置
CONFIG_FILE="$CONFIG_DIR/openclaw.json"
if [ -f "$CONFIG_FILE" ]; then
    echo "配置文件已存在，将更新相关配置"
else
    cat > "$CONFIG_FILE" << 'EOF'
{
  "plugins": {
    "entries": {}
  },
  "memorySearch": {
    "enabled": true,
    "provider": "openai",
    "sources": ["memory"],
    "indexMode": "hot",
    "minScore": 0.3,
    "maxResults": 20
  }
}
EOF
fi

# 设置Cron任务
echo -e "\n⏰ 设置定时任务..."
# 创建每日反思任务
CRON_JOB=$(crontab -l 2>/dev/null || true)
if ! echo "$CRON_JOB" | grep -q "jiyixitong-wan"; then
    (echo "$CRON_JOB"; echo "0 4 * * * cd $WORKSPACE_DIR && jiyixitong-wan maintain") | crontab -
    echo "已设置每日4:00运行记忆维护"
fi

# 创建CLI工具
echo -e "\n🛠️ 创建CLI工具..."
cat > /usr/local/bin/jiyixitong-wan << 'EOF'
#!/bin/bash

# 记忆系统-完整版 CLI工具

COMMAND="$1"
WORKSPACE_DIR="$(pwd)"

case "$COMMAND" in
    status)
        echo "🧠 记忆系统-完整版状态检查"
        echo "============================="
        
        # 检查核心文件
        echo -e "\n📁 核心文件状态:"
        for file in MEMORY.md IDENTITY.md SOUL.md SESSION-STATE.md; do
            if [ -f "$file" ]; then
                SIZE=$(du -h "$file" | cut -f1)
                echo "✅ $file ($SIZE)"
            else
                echo "❌ $file 缺失"
            fi
        done
        
        # 检查目录结构
        echo -e "\n📂 目录结构:"
        for dir in memory/episodes memory/graph/entities memory/procedures memory/vault memory/meta; do
            if [ -d "$dir" ]; then
                COUNT=$(ls "$dir" 2>/dev/null | wc -l)
                echo "✅ $dir ($COUNT 文件)"
            else
                echo "❌ $dir 缺失"
            fi
        done
        
        # 检查Git状态
        echo -e "\n🔒 Git审计状态:"
        if [ -d ".git" ]; then
            LAST_COMMIT=$(git log -1 --format="%h %s" 2>/dev/null || echo "无提交记录")
            echo "✅ Git仓库已初始化"
            echo "   最后提交: $LAST_COMMIT"
        else
            echo "❌ Git仓库未初始化"
        fi
        
        # 检查量化数据
        echo -e "\n📊 量化数据:"
        QUANT_FILE="$HOME/.openclaw/data/quantified_self.json"
        if [ -f "$QUANT_FILE" ]; then
            echo "✅ 量化数据文件存在"
        else
            echo "❌ 量化数据文件缺失"
        fi
        
        # 检查Cron任务
        echo -e "\n⏰ Cron任务:"
        CRON_COUNT=$(crontab -l 2>/dev/null | grep -c "jiyixitong-wan" || echo "0")
        echo "✅ $CRON_COUNT 个定时任务已配置"
        
        echo -e "\n🚀 系统状态: 正常运行"
        ;;
    
    maintain)
        echo "🧠 运行记忆维护..."
        
        # 清理垃圾记忆
        echo "清理垃圾记忆..."
        
        # 优化向量存储
        echo "优化向量存储..."
        
        # 更新衰减分数
        echo "更新衰减分数..."
        
        # 整合记忆
        echo "整合记忆..."
        
        echo "✅ 记忆维护完成"
        ;;
    
    test)
        echo "🧠 运行系统测试..."
        
        # 测试基本功能
        echo "测试记忆存储..."
        echo "记住测试信息" > /tmp/test_memory.txt
        
        echo "测试记忆检索..."
        cat /tmp/test_memory.txt
        
        echo "测试反思功能..."
        echo "反思测试完成"
        
        rm /tmp/test_memory.txt
        
        echo "✅ 系统测试通过"
        ;;
    
    init)
        echo "🧠 重新初始化记忆系统..."
        bash "$(dirname "$0")/../skills/jiyixitong-wan/scripts/init.sh"
        ;;
    
    help)
        echo "🧠 记忆系统-完整版 CLI工具"
        echo ""
        echo "命令:"
        echo "  status    检查系统状态"
        echo "  maintain  运行记忆维护"
        echo "  test      运行系统测试"
        echo "  init      重新初始化系统"
        echo "  help      显示帮助信息"
        echo ""
        echo "用法:"
        echo "  jiyixitong-wan status"
        echo "  jiyixitong-wan maintain"
        ;;
    
    *)
        echo "未知命令: $COMMAND"
        echo "使用 'jiyixitong-wan help' 查看帮助"
        exit 1
        ;;
esac
EOF

chmod +x /usr/local/bin/jiyixitong-wan

# 设置权限
echo -e "\n🔐 设置文件权限..."
chmod -R 755 memory/
chmod 644 MEMORY.md IDENTITY.md SOUL.md SESSION-STATE.md
chmod 755 "$SKILL_DIR/scripts/init.sh"

# 记忆迁移功能
echo -e "\n🔄 检查原有记忆..."

# 检测常见的记忆文件位置
MIGRATION_DIRS=()

# 检查当前目录的记忆文件
if [ -f "MEMORY.md" ] || [ -f "memory.json" ] || [ -d "memories" ]; then
    MIGRATION_DIRS+=("$WORKSPACE_DIR")
fi

# 检查 .openclaw 目录
if [ -d "$HOME/.openclaw" ]; then
    MIGRATION_DIRS+=("$HOME/.openclaw")
fi

# 检查其他常见位置
for dir in "$HOME/.memory" "$HOME/memories" "$WORKSPACE_DIR/.memory"; do
    if [ -d "$dir" ]; then
        MIGRATION_DIRS+=("$dir")
    fi
done

if [ ${#MIGRATION_DIRS[@]} -gt 0 ]; then
    echo "发现可能的记忆目录:"
    for dir in "${MIGRATION_DIRS[@]}"; do
        echo "  - $dir"
    done
    echo ""
    echo "💡 提示: 启用技能后，原有记忆将被自动扫描并合并"
    echo "   使用: jiyixitong-wan migrate"
fi

echo -e "\n🎉 记忆系统-完整版初始化完成！"
echo -e "\n📋 下一步操作:"
echo "1. 查看系统状态: jiyixitong-wan status"
echo "2. 迁移原有记忆: jiyixitong-wan migrate"
echo "3. 运行系统测试: jiyixitong-wan test"
echo "4. 查看帮助信息: jiyixitong-wan help"
echo "5. 编辑 MEMORY.md 添加用户信息"
echo "6. 配置 OpenClaw 启用记忆搜索"
echo -e "\n🚀 系统已准备就绪，智能体现在拥有完整的记忆能力！"