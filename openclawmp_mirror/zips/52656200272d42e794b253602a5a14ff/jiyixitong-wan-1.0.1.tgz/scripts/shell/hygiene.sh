#!/bin/bash

# Memory Hygiene - 记忆维护脚本
# 来源: memory-hygiene

set -e

MEMORY_DIR="${HOME}/.jiyixitong-wan/memory"
LOG_DIR="${MEMORY_DIR}/meta"
AUDIT_LOG="${LOG_DIR}/audit.log"

mkdir -p "$LOG_DIR"

log() {
    echo "[$(date -u +"%Y-%m-%dT%H:%M:%SZ")] [Hygiene] $1" >> "$AUDIT_LOG"
}

audit() {
    echo "🧹 Memory Hygiene Audit"
    echo "======================"
    echo ""

    if [ ! -d "$MEMORY_DIR" ]; then
        echo "❌ Memory directory not found: $MEMORY_DIR"
        return 1
    fi

    echo "📊 Memory Statistics"
    echo "-------------------"

    local total_files=0
    local total_size=0
    local episodic_count=0
    local semantic_count=0
    local procedural_count=0
    local archived_count=0

    if [ -d "$MEMORY_DIR/episodes" ]; then
        episodic_count=$(find "$MEMORY_DIR/episodes" -name "*.md" 2>/dev/null | wc -l)
    fi

    if [ -d "$MEMORY_DIR/graph" ]; then
        semantic_count=$(find "$MEMORY_DIR/graph" -name "*.md" 2>/dev/null | wc -l)
    fi

    if [ -d "$MEMORY_DIR/procedures" ]; then
        procedural_count=$(find "$MEMORY_DIR/procedures" -name "*.md" 2>/dev/null | wc -l)
    fi

    if [ -d "$MEMORY_DIR/archive" ]; then
        archived_count=$(find "$MEMORY_DIR/archive" -name "*.md" 2>/dev/null | wc -l)
    fi

    total_files=$((episodic_count + semantic_count + procedural_count + archived_count))

    echo "  Episodic memories: $episodic_count"
    echo "  Semantic memories: $semantic_count"
    echo "  Procedural memories: $procedural_count"
    echo "  Archived memories: $archived_count"
    echo "  Total files: $total_files"
    echo ""

    echo "🗑️ Checking for garbage..."
    echo "--------------------------"

    local garbage_count=0
    local temp_files=$(find "$MEMORY_DIR" -name "*.tmp" -o -name "*.bak" -o -name "*~" 2>/dev/null | wc -l)

    if [ "$temp_files" -gt 0 ]; then
        echo "  ⚠️  Found $temp_files temporary files"
        garbage_count=$((garbage_count + temp_files))
    else
        echo "  ✅ No temporary files found"
    fi

    local old_logs=$(find "$LOG_DIR" -name "*.log" -mtime +30 2>/dev/null | wc -l)
    if [ "$old_logs" -gt 0 ]; then
        echo "  ⚠️  Found $old_logs old log files (>30 days)"
        garbage_count=$((garbage_count + old_logs))
    else
        echo "  ✅ No old log files found"
    fi

    echo ""

    if [ "$garbage_count" -gt 0 ]; then
        echo "🧹 $garbage_count items can be cleaned"
    else
        echo "✨ Memory is clean"
    fi

    echo ""
    echo "📈 Last maintenance:"
    if [ -f "$LOG_DIR/last_maintenance" ]; then
        cat "$LOG_DIR/last_maintenance"
    else
        echo "  Never run"
    fi

    log "Audit completed: $total_files files, $garbage_count garbage items"
}

clean() {
    echo "🧹 Cleaning memory..."
    echo ""

    local cleaned=0

    echo "Removing temporary files..."
    local temp_removed=$(find "$MEMORY_DIR" -name "*.tmp" -o -name "*.bak" -o -name "*~" 2>/dev/null | wc -l)
    find "$MEMORY_DIR" -name "*.tmp" -o -name "*.bak" -o -name "*~" 2>/dev/null | xargs rm -f 2>/dev/null || true
    cleaned=$((cleaned + temp_removed))
    echo "  ✅ Removed $temp_removed temporary files"

    echo "Cleaning old logs (>90 days)..."
    local old_logs_removed=0
    find "$LOG_DIR" -name "*.log" -mtime +90 2>/dev/null | while read -r logfile; do
        rm -f "$logfile" 2>/dev/null && old_logs_removed=$((old_logs_removed + 1))
    done
    cleaned=$((cleaned + old_logs_removed))
    echo "  ✅ Removed $old_logs_removed old log files"

    echo "Cleaning empty directories..."
    local empty_dirs=$(find "$MEMORY_DIR" -type d -empty 2>/dev/null | wc -l)
    find "$MEMORY_DIR" -type d -empty 2>/dev/null | xargs rmdir 2>/dev/null || true
    echo "  ✅ Removed $empty_dirs empty directories"

    echo ""
    echo "✨ Total items cleaned: $cleaned"

    echo "$(date -u +"%Y-%m-%dT%H:%M:%SZ") - Cleaned $cleaned items" > "$LOG_DIR/last_maintenance"

    log "Clean completed: $cleaned items removed"
}

optimize() {
    echo "⚡ Optimizing memory..."

    if [ -d "$MEMORY_DIR/lance" ]; then
        echo "Optimizing LanceDB indices..."
    fi

    if command -v git &> /dev/null && [ -d "$MEMORY_DIR/.git" ]; then
        echo "Optimizing git repository..."
        git -C "$MEMORY_DIR" gc --quiet 2>/dev/null || true
    fi

    echo "✅ Optimization complete"
    log "Optimize completed"
}

maintain() {
    echo "🔧 Running full maintenance..."
    echo ""

    audit
    echo ""
    clean
    echo ""
    optimize

    echo ""
    echo "✅ Maintenance complete!"
    log "Full maintenance cycle completed"
}

case "${1:-audit}" in
    audit)
        audit
        ;;
    clean)
        clean
        ;;
    optimize)
        optimize
        ;;
    maintain)
        maintain
        ;;
    *)
        echo "Usage: $0 {audit|clean|optimize|maintain}"
        exit 1
        ;;
esac