# 反思指南

## 反思流程

### 四阶段反思流程

1. **Survey（调查）**
   - 加载近期会话
   - 识别关键模式
   - 发现成长边缘

2. **Consolidate（整合）**
   - 整合洞察
   - 连接知识点
   - 形成理解

3. **Rewrite Core（重写核心）**
   - 更新身份认知
   - 调整价值观
   - 记录新发现

4. **Summarize（总结）**
   - 生成摘要
   - 提出问题
   - 规划下一步

## 问题生成

### 好奇心问题质量标准

每个生成的问题必须通过以下检查：

1. **实用性检查**: 这个问题的答案能改变我的行为吗？
2. **相关性检查**: 用户会关心这个问题吗？
3. **真实性检查**: 这个问题探索的是真实的空白还是表演性的好奇？
4. **意图检查**: 我是否只是在堆砌问题而没有真正的探索意图？

### 问题来源

| 来源 | 描述 |
|------|------|
| **dream** | 梦境/反思中产生 |
| **reading** | 阅读/学习中发现 |
| **work** | 工作/实践中产生 |
| **reflection** | 深度反思中产生 |

## 身份层级

### 六层级身份架构

1. **基础身份**: name, role
2. **核心价值观**: what matters most
3. **沟通风格**: how user likes communication
4. **工作模式**: patterns in collaboration
5. **成长轨迹**: evolution over time
6. **发展性身份**: where it's going

## 使用脚本

```bash
# 运行连续性周期
python3 scripts/python/continuity.py cycle

# 生成问候语
python3 scripts/python/continuity.py greet

# 查看待处理问题
python3 scripts/python/continuity.py questions

# 运行反思处理
python3 scripts/python/reflection.py decay
python3 scripts/python/reflection.py reflect <session_id>
```

## 配置

反思配置在 `JiyixitongWanConfig` 中：

```typescript
reflection: {
  schedule: "0 4 * * *",    // Cron表达式
  tokenBudget: 8000         // 输出token上限
}
```
