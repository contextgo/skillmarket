# 记忆类型系统

## 认知层 (Cognitive Layers)

| 层级 | 描述 | 存储位置 |
|------|------|---------|
| **episodic** | 情节记忆 - 时间标记的事件 | memory/episodes/ |
| **semantic** | 语义记忆 - 持久的事实和概念 | memory/graph/ |
| **procedural** | 程序记忆 - 工作流程和行为规则 | memory/procedures/ |
| **core** | 核心记忆 - 始终加载的重要信息 | MEMORY.md |

## 记忆类型 (Memory Types)

| 类型 | 描述 | 衰减率 |
|------|------|--------|
| **fact** | 声明性知识 | 0.8x |
| **preference** | 用户偏好 | 1.0x |
| **decision** | 重要决策 | 1.2x |
| **context** | 情境上下文 | 0.6x |
| **correction** | 用户纠正 | 1.5x |
| **commitment** | 承诺和义务 | 1.3x |
| **moment** | 重要时刻 | 0.5x |
| **skill** | 学会的能力 | 1.0x |
| **question** | 好奇问题 | 0.7x |

## 置信度等级 (Confidence Levels)

| 等级 | 范围 | 含义 |
|------|------|------|
| **explicit** | 0.95-1.0 | 用户直接陈述 |
| **implied** | 0.70-0.94 | 强推断 |
| **inferred** | 0.40-0.69 | 模式识别 |
| **speculative** | 0.0-0.39 | 试探性 |

## 记忆层级 (Memory Tiers)

| 层级 | 描述 | 生命周期 |
|------|------|---------|
| **daily** | 日常记忆 | 当天有效 |
| **short-term** | 短期记忆 | 几天到几周 |
| **long-term** | 长期记忆 | 数月到数年 |
| **archive** | 归档记忆 | 永久保存但不可搜索 |

## 情感基调 (Sentiment)

| 情感 | 描述 |
|------|------|
| **frustrated** | 沮丧 - 纠正、重问、恼怒 |
| **curious** | 好奇 - 探索、追问 |
| **satisfied** | 满意 - 认可、感谢 |
| **neutral** | 中性 - 标准交流 |
| **excited** | 兴奋 - 热情、构建新事物 |
| **confused** | 困惑 - 需要澄清 |

## 衰减模型

```
relevance(t) = base × e^(-λ × days) × log2(access_count + 1) × type_weight
```

| 分数范围 | 状态 | 行为 |
|---------|------|------|
| 1.0-0.5 | Active | 完全可搜索 |
| 0.5-0.2 | Fading | 降低优先级 |
| 0.2-0.05 | Dormant | 仅显式搜索 |
| < 0.05 | Archived | 隐藏 |
