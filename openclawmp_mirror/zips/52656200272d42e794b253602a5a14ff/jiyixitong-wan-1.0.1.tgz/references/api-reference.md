# API参考

## JiyixitongWan 类

主入口类，提供完整的记忆系统功能。

### 构造函数

```typescript
const jyx = new JiyixitongWan(config?: Partial<JiyixitongWanConfig>)
```

### 方法

#### 存储方法

```typescript
// 保存记忆
async save(content: string, opts?: {
  type?: string;
  cognitiveLayer?: string;
  importance?: number;
  tags?: string[];
}): Promise<MemoryChunk>

// 搜索记忆
async search_memories(query: string, opts?: {
  maxResults?: number;
  minScore?: number;
}): Promise<SearchResult[]>

// 从对话提取记忆
async extract(
  messages: Array<{ role: string; content: string }>,
  convId: string
): Promise<MemoryChunk[]>
```

#### 反思方法

```typescript
// 运行反思
async reflect(
  conversationHistory: Array<{ role: string; content: string }>
): Promise<Reflection>

// 获取待处理问题
getPendingQuestions(): Question[]

// 生成问候语
getGreeting(): string
```

#### 量化方法

```typescript
// 记录任务
recordTask(task: TaskRecord): void

// 记录学习
recordLearning(concept: ConceptRecord): void

// 获取成长报告
getGrowthReport(): string
```

#### 维护方法

```typescript
// 审计记忆
async audit(): Promise<string>

// 清理记忆
async clean(): Promise<{ deleted: number; archived: number }>

// 运行维护
async maintain(): Promise<string>

// 获取系统健康状态
async getHealth(): Promise<{
  status: 'healthy' | 'degraded' | 'critical';
  score: number;
  issues: string[];
  recommendations: string[];
}>
```

## 类型定义

### MemoryChunk

```typescript
interface MemoryChunk {
  id: string;
  tier: MemoryTier;           // 'daily' | 'short-term' | 'long-term' | 'archive'
  content: string;
  type: MemoryType;           // 'fact' | 'preference' | 'decision' | etc.
  cognitiveLayer: CognitiveLayer; // 'episodic' | 'semantic' | 'procedural' | 'core'
  tags: string[];
  source: string;
  importance: number;         // 0.0 - 1.0
  sentiment: Sentiment;       // 'frustrated' | 'curious' | 'satisfied' | etc.
  createdAt: string;
  lastRecalledAt: string | null;
  recallCount: number;
  embedding?: number[];
  relatedMemories: MemoryEdge[];
  recallOutcomes: RecallOutcome[];
  decayScore?: number;
}
```

### SearchResult

```typescript
interface SearchResult {
  chunk: MemoryChunk;
  score: number;
  matchedTerms?: string[];
}
```

### Reflection

```typescript
interface Reflection {
  session_id: string;
  duration_minutes: number;
  memories: Array<{
    type: MemoryType;
    content: string;
    confidence: number;
    source: string;
  }>;
  questions: Question[];
  identity_update: {
    growth: string;
    narrative: string;
  };
  timestamp: string;
}
```

### Question

```typescript
interface Question {
  id: string;
  text: string;
  source: 'dream' | 'reading' | 'work' | 'reflection';
  date: string;
  resolved: boolean;
  context?: string;
}
```

## 配置选项

```typescript
interface JiyixitongWanConfig {
  memorySearch: {
    enabled: boolean;
    provider: string;
    sources: string[];
    minScore: number;
    maxResults: number;
  };
  extraction: {
    autoExtract: boolean;
    threshold: number;
  };
  decay: {
    rate: number;
    halfLifeDays: number;
    archiveThreshold: number;
  };
  reflection: {
    schedule: string;
    tokenBudget: number;
  };
  quantification: {
    autoTrack: boolean;
    retentionDays: number;
  };
  dataDir: string;
}
```

## 使用示例

### 基本使用

```typescript
import { JiyixitongWan } from './src/index.js';

const jyx = new JiyixitongWan();
await jyx.ensureReady();

// 保存记忆
await jyx.save("用户喜欢TypeScript", {
  type: 'preference',
  importance: 0.9
});

// 搜索记忆
const results = await jyx.search_memories("用户的偏好");
console.log(results);

// 关闭
jyx.close();
```

### 从对话提取

```typescript
const messages = [
  { role: 'user', content: '我喜欢用React开发' },
  { role: 'assistant', content: '好的，我会记住这一点' }
];

const memories = await jyx.extract(messages, 'conv-123');
console.log(`提取了 ${memories.length} 条记忆`);
```

### 量化追踪

```typescript
// 记录任务
jyx.recordTask({
  id: 'task-1',
  type: 'coding',
  title: '实现登录功能',
  status: 'completed',
  quality_score: 8.5,
  duration_minutes: 45
});

// 查看成长报告
console.log(jyx.getGrowthReport());
```
