# OpenClaw 集成指南

## 概述

jiyixitong-wan 技能专为 OpenClaw（龙虾）AI 智能体框架设计，提供完整的记忆管理能力。支持 MCP 协议和智能体隔离，适用于企业级多智能体部署。

## 集成方式

### 方式一：MCP 协议（推荐）

通过 MCP (Model Context Protocol) 协议与 OpenClaw 集成，支持多智能体隔离。

### 方式二：直接代码集成

直接在 OpenClaw 插件中引入记忆系统。

---

## 方式一：MCP 协议集成

### 配置 MCP Server

在 OpenClaw 配置中添加 MCP Server：

```json
{
  "mcpServers": {
    "jiyixitong-wan": {
      "command": "npx",
      "args": ["jiyixitong-mcp"],
      "env": {
        "JIYIXITONG_DATA_DIR": "~/.jiyixitong-wan"
      }
    }
  }
}
```

### 智能体隔离流程

```typescript
// 1. 初始化智能体（隔离）
const initResult = await mcpClient.callTool('agent_initialize', {
  agent_id: 'agent-sales-001',
  agent_name: '销售助手',
  permissions: ['memory:read', 'memory:write', 'reflection:trigger'],
  metadata: {
    department: 'sales',
    region: 'apac'
  }
});

// 2. 保存记忆（自动隔离到 agent-sales-001）
await mcpClient.callTool('memory_save', {
  agent_id: 'agent-sales-001',
  content: '客户A偏好价格方案B',
  type: 'preference',
  importance: 0.9,
  tags: ['客户A', '价格敏感']
});

// 3. 搜索记忆（仅搜索该智能体的记忆）
const searchResult = await mcpClient.callTool('memory_search', {
  agent_id: 'agent-sales-001',
  query: '客户A的偏好',
  max_results: 5
});

// 4. 清理智能体
await mcpClient.callTool('agent_cleanup', {
  agent_id: 'agent-sales-001'
});
```

### 多智能体隔离架构

```
┌─────────────────────────────────────────────────────────────┐
│                    OpenClaw 平台                            │
├─────────────────────────────────────────────────────────────┤
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐      │
│  │  销售助手    │  │  技术支持    │  │  客服机器人  │      │
│  │  agent-001   │  │  agent-002   │  │  agent-003   │      │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘      │
│         │                 │                 │               │
│         └─────────────────┼─────────────────┘               │
│                           │                                 │
│                    ┌──────┴──────┐                         │
│                    │  MCP Server │                         │
│                    │  (jiyixitong-wan)                     │
│                    └──────┬──────┘                         │
│                           │                                 │
│         ┌─────────────────┼─────────────────┐              │
│         │                 │                 │               │
│  ┌──────┴──────┐  ┌──────┴──────┐  ┌──────┴──────┐        │
│  │  销售记忆   │  │  技术记忆   │  │  客服记忆   │        │
│  │  (隔离)     │  │  (隔离)     │  │  (隔离)     │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
└─────────────────────────────────────────────────────────────┘
```

### 隔离特性

| 特性 | 说明 |
|------|------|
| **存储隔离** | 每个智能体独立的数据目录 |
| **身份隔离** | 每个智能体独立的身份认知 |
| **权限控制** | 基于权限的记忆访问控制 |
| **资源隔离** | 独立的向量数据库实例 |

---

## 方式二：直接代码集成

## 安装 Ollama（免费 LLM）

### macOS

```bash
# 使用 Homebrew 安装
brew install ollama

# 启动服务
ollama serve

# 下载模型（在另一个终端）
ollama pull llama3.2           # 对话模型
ollama pull nomic-embed-text   # 嵌入模型
```

### 验证安装

```bash
# 检查服务状态
curl http://localhost:11434/api/tags

# 测试生成
curl http://localhost:11434/api/generate -d '{
  "model": "llama3.2",
  "prompt": "Hello",
  "stream": false
}'
```

## OpenClaw 配置

### 1. 配置 LLM 提供者

在 OpenClaw 配置文件中添加：

```json
{
  "plugins": {
    "entries": {
      "jiyixitong-wan": {
        "enabled": true,
        "config": {
          "llmProvider": {
            "type": "ollama",
            "baseUrl": "http://localhost:11434",
            "model": "llama3.2",
            "embeddingModel": "nomic-embed-text"
          }
        }
      }
    }
  }
}
```

### 2. 使用代码集成

```typescript
import { JiyixitongWan, FreeProviders } from './jiyixitong-wan/src/index.js';

// 初始化记忆系统
const jyx = new JiyixitongWan();

// 配置 Ollama LLM
const ollama = FreeProviders.ollama({
  model: 'llama3.2',
  embeddingModel: 'nomic-embed-text'
});

// 检查 Ollama 是否可用
if (await ollama.isAvailable()) {
  jyx.setLLMProvider(ollama);
  console.log('✅ Ollama 已连接');
} else {
  console.log('⚠️ Ollama 未运行，使用基础模式');
}

// 现在可以使用完整功能
const memories = await jyx.extract(messages, conversationId);
const results = await jyx.search_memories("查询内容");
```

## 替代方案：Groq（免费 API）

如果不想本地运行 Ollama，可以使用 Groq：

```typescript
import { FreeProviders } from './jiyixitong-wan/src/index.js';

// 注册获取 API Key: https://console.groq.com
const groq = FreeProviders.groq('your-groq-api-key');
jyx.setLLMProvider(groq);
```

**注意**：Groq 暂不支持嵌入，语义搜索会回退到关键词搜索。

## OpenClaw 触发器配置

### 自动记忆提取

```json
{
  "triggers": {
    "memory_extraction": {
      "enabled": true,
      "threshold": 5,
      "onConversationEnd": true
    }
  }
}
```

## 完整使用示例

```typescript
// OpenClaw 插件入口
import { JiyixitongWan, FreeProviders } from './src/index.js';

export default {
  name: 'jiyixitong-wan',
  
  async initialize(config) {
    const jyx = new JiyixitongWan(config);
    
    // 自动检测并配置 LLM
    const ollama = FreeProviders.ollama();
    if (await ollama.isAvailable()) {
      jyx.setLLMProvider(ollama);
    }
    
    return jyx;
  },
  
  async onMessage(message, context) {
    const jyx = context.plugins['jiyixitong-wan'];
    
    // 搜索相关记忆
    const memories = await jyx.search_memories(message.content);
    
    // 提取新记忆
    await jyx.extract(context.messages, context.conversationId);
    
    return { memories };
  },
  
  async onConversationEnd(context) {
    const jyx = context.plugins['jiyixitong-wan'];
    
    // 运行反思
    await jyx.reflect(context.messages);
    
    // 记录任务
    jyx.recordTask({
      type: 'conversation',
      status: 'completed',
      quality_score: 8
    });
  }
};
```

## 故障排除

### Ollama 连接失败

```bash
# 检查服务是否运行
curl http://localhost:11434/api/tags

# 如果失败，手动启动
ollama serve

# 检查模型是否下载
ollama list
```

### 嵌入生成失败

如果嵌入模型不可用，系统会自动回退到关键词搜索：

```typescript
// 搜索会自动处理
const results = await jyx.search_memories("查询");
// 如果有嵌入 → 语义搜索
// 如果无嵌入 → 关键词搜索
```

### 内存不足

Ollama 模型需要内存：
- llama3.2: ~4GB RAM
- 如果内存不足，使用 Groq API 代替

## 性能优化

### 本地模式（推荐）
- ✅ 完全免费
- ✅ 数据隐私
- ✅ 无网络延迟
- ⚠️ 需要 4GB+ RAM

### API 模式
- ✅ 无需本地资源
- ✅ 更快响应
- ⚠️ 需要 API Key
- ⚠️ 可能有速率限制
