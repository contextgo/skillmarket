# LLM 配置指南

## 概述

jiyixitong-wan 支持多种 LLM 提供者，包括本地免费方案和云端 API。

## 方案1: Ollama（推荐，完全免费）

### 安装

```bash
# macOS
brew install ollama

# Linux
curl -fsSL https://ollama.com/install.sh | sh

# Windows
# 下载安装包: https://ollama.com/download
```

### 启动服务

```bash
ollama serve
```

### 下载模型

```bash
# 对话模型（约4GB）
ollama pull llama3.2

# 嵌入模型（约500MB）
ollama pull nomic-embed-text
```

### 代码集成

```typescript
import { JiyixitongWan, FreeProviders } from './dist/index.js';

const jyx = new JiyixitongWan();

// 配置 Ollama
const ollama = FreeProviders.ollama({
  model: 'llama3.2',
  embeddingModel: 'nomic-embed-text'
});

// 检查可用性并设置
if (await ollama.isAvailable()) {
  jyx.setLLMProvider(ollama);
  console.log('✅ Ollama 已连接');
}
```

### 验证安装

```bash
# 检查服务状态
curl http://localhost:11434/api/tags

# 测试生成
curl http://localhost:11434/api/generate -d '{
  "model": "llama3.2",
  "prompt": "Hello",
  "stream": false
}'
```

## 方案2: Groq（免费 API）

### 注册

访问 https://console.groq.com 注册获取 API Key

### 代码集成

```typescript
import { FreeProviders } from './dist/index.js';

const groq = FreeProviders.groq('your-groq-api-key');
jyx.setLLMProvider(groq);
```

**注意**: Groq 暂不支持嵌入，语义搜索会回退到关键词搜索。

## 方案3: Together AI（免费额度）

### 注册

访问 https://api.together.xyz 注册获取 API Key

### 代码集成

```typescript
import { FreeProviders } from './dist/index.js';

const together = FreeProviders.together('your-together-api-key');
jyx.setLLMProvider(together);
```

## 方案对比

| 方案 | 成本 | 速度 | 隐私 | 嵌入支持 |
|------|------|------|------|----------|
| Ollama | 免费 | 中等 | ✅ 本地 | ✅ 支持 |
| Groq | 免费额度 | 快 | ❌ 云端 | ❌ 不支持 |
| Together | 免费额度 | 快 | ❌ 云端 | ✅ 支持 |

## 故障排除

### Ollama 连接失败

```bash
# 检查服务是否运行
curl http://localhost:11434/api/tags

# 手动启动
ollama serve

# 检查模型是否下载
ollama list
```

### 内存不足

Ollama 模型需要内存：
- llama3.2: ~4GB RAM
- 如果内存不足，使用 Groq API 代替

### 嵌入生成失败

系统会自动回退到关键词搜索：
```typescript
// 搜索会自动处理
const results = await jyx.search_memories("查询");
// 如果有嵌入 → 语义搜索
// 如果无嵌入 → 关键词搜索
```
