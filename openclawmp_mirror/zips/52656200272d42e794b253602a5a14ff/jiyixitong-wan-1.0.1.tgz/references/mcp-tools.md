# MCP Tools 参考

## 概述

jiyixitong-wan 支持 MCP (Model Context Protocol) 协议，提供 12 个标准化工具供智能体调用。

## 智能体管理工具

### agent_initialize

初始化智能体记忆系统，创建隔离的存储空间。

**参数:**
```json
{
  "agent_id": "string",      // 智能体唯一标识（必需）
  "agent_name": "string",    // 智能体名称（必需）
  "permissions": ["string"], // 权限列表（可选）
  "metadata": {}             // 元数据（可选）
}
```

**示例:**
```json
{
  "agent_id": "sales-assistant-001",
  "agent_name": "销售助手",
  "permissions": ["memory:read", "memory:write"],
  "metadata": { "department": "sales" }
}
```

### agent_list

列出所有已初始化的智能体。

**参数:** 无

### agent_cleanup

清理指定智能体的记忆系统。

**参数:**
```json
{
  "agent_id": "string"  // 智能体ID（必需）
}
```

## 记忆操作工具

### memory_save

保存记忆到指定智能体的记忆系统。

**参数:**
```json
{
  "agent_id": "string",           // 智能体ID（必需）
  "content": "string",            // 记忆内容（必需）
  "type": "fact|preference|...",  // 记忆类型（可选）
  "cognitive_layer": "semantic",  // 认知层（可选）
  "importance": 0.5,              // 重要性 0-1（可选）
  "tags": ["string"]              // 标签（可选）
}
```

### memory_search

搜索智能体的记忆。

**参数:**
```json
{
  "agent_id": "string",    // 智能体ID（必需）
  "query": "string",       // 搜索查询（必需）
  "max_results": 10,       // 最大结果数（可选，默认10）
  "min_score": 0.3         // 最小匹配分数（可选，默认0.3）
}
```

### memory_extract

从对话中提取记忆。

**参数:**
```json
{
  "agent_id": "string",      // 智能体ID（必需）
  "messages": [{             // 对话消息（必需）
    "role": "user|assistant",
    "content": "string"
  }],
  "conversation_id": "string" // 对话ID（必需）
}
```

### memory_reflect

触发反思过程。

**参数:**
```json
{
  "agent_id": "string",      // 智能体ID（必需）
  "conversation_history": []  // 对话历史（可选）
}
```

### memory_get_questions

获取待处理的问题。

**参数:**
```json
{
  "agent_id": "string"  // 智能体ID（必需）
}
```

### memory_get_growth_report

获取成长报告。

**参数:**
```json
{
  "agent_id": "string"  // 智能体ID（必需）
}
```

### memory_record_task

记录任务完成情况。

**参数:**
```json
{
  "agent_id": "string",  // 智能体ID（必需）
  "task": {              // 任务信息（必需）
    "type": "string",
    "title": "string",
    "status": "completed|in_progress|failed",
    "quality_score": 8.5
  }
}
```

## 系统维护工具

### system_health

获取系统健康状态。

**参数:**
```json
{
  "agent_id": "string"  // 智能体ID（可选，不提供则返回所有）
}
```

### system_maintain

运行系统维护。

**参数:**
```json
{
  "agent_id": "string"  // 智能体ID（必需）
}
```

## 智能体隔离架构

```
~/.jiyixitong-wan/agents/
├── agent-a/              # 智能体A的隔离空间
│   ├── lance/            # 向量数据库
│   ├── quantified_self.json
│   ├── identity.md
│   └── questions.md
├── agent-b/              # 智能体B的隔离空间
│   └── ...
└── agent-c/
    └── ...
```

每个智能体拥有：
- 独立的向量数据库
- 独立的身份认知
- 独立的量化数据
- 独立的问题列表
