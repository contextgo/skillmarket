# 安全漏洞扫描报告

**项目**: jiyixitong-wan (完整智能体记忆系统)  
**扫描日期**: 2026-04-09  
**扫描范围**: TypeScript 源代码 (src/*.ts)

---

## 执行摘要

本次安全扫描针对 `jiyixitong-wan` 项目进行了全面的代码审查。该项目是一个基于 TypeScript 的智能体记忆系统，使用 SQLite 作为数据库，通过 MCP (Model Context Protocol) 提供服务。

**总体评估**: 项目整体代码质量良好，但发现 **2 个中等级别** 和 **3 个低级别** 安全问题需要关注。

---

## 关键发现

### 🔴 中等级别问题

#### 1. SQL 注入风险 - LIKE 查询中的用户输入未转义

**文件**: [src/database.ts](file:///Users/lujane/配置技能/jiyixitong-wan/src/database.ts#L190-L209)  
**行号**: 190-209

**问题描述**:
在 `search` 方法中，用户提供的查询字符串直接拼接到 SQL LIKE 语句中，虽然使用了参数化查询，但 `%` 通配符的拼接方式可能导致意外的查询行为。

```typescript
async search(query: string, embedding?: number[], options?: SearchOptions): Promise<SearchResult[]> {
  // ...
  const searchTerm = `%${query}%`;  // 用户输入直接拼接
  const rows = await this.db!.all(
    `SELECT * FROM memories 
     WHERE content LIKE ? OR tags LIKE ?
     ORDER BY importance DESC, created_at DESC
     LIMIT ?`,
    [searchTerm, searchTerm, maxResults]
  );
  // ...
}
```

**潜在影响**:
- 用户可以通过特殊字符影响搜索结果
- 可能导致搜索性能问题（如输入大量通配符）

**修复建议**:
对用户输入进行清理，移除或转义 SQL 通配符字符：

```typescript
const searchTerm = `%${query.replace(/[%_]/g, '\\$&')}%`;
```

---

#### 2. 路径遍历风险 - 文件系统操作未验证路径

**文件**: [src/migration.ts](file:///Users/lujane/配置技能/jiyixitong-wan/src/migration.ts#L35-L66)  
**行号**: 35-66, 71-113, 118-152

**问题描述**:
在 `migrateAll` 和 `migrateFromDirectory` 方法中，从用户提供的 `sourceDirs` 读取文件，但未验证这些路径是否在允许的范围内。

```typescript
async migrateAll(sourceDirs: string[]): Promise<MigrationReport> {
  const report: MigrationReport = { ... };

  for (const dir of sourceDirs) {
    if (!fs.existsSync(dir)) continue;  // 仅检查存在性，不验证路径
    const dirReport = await this.migrateFromDirectory(dir);
    // ...
  }
}
```

**潜在影响**:
- 如果 `sourceDirs` 包含恶意构造的路径，可能读取系统敏感文件
- 可能导致信息泄露

**修复建议**:
添加路径验证，确保只处理预期的目录：

```typescript
import { resolve, normalize } from 'path';

private isPathAllowed(targetPath: string, allowedBase: string): boolean {
  const resolved = normalize(resolve(targetPath));
  const allowed = normalize(resolve(allowedBase));
  return resolved.startsWith(allowed);
}
```

---

### 🟡 低级别问题

#### 3. 不安全的随机数生成 - 用于 ID 生成

**文件**: [src/database.ts](file:///Users/lujane/配置技能/jiyixitong-wan/src/database.ts#L68)  
**行号**: 68

**问题描述**:
在 `save` 方法中使用 `Math.random()` 生成记忆 ID，这在安全敏感场景下不够安全。

```typescript
const id = chunk.id || `memory-${Date.now()}-${Math.random().toString(36).slice(2)}`;
```

**潜在影响**:
- ID 可预测性较高
- 在需要高安全性的场景下可能被利用

**修复建议**:
使用 Node.js 的 `crypto` 模块生成更安全的随机 ID：

```typescript
import { randomUUID, randomBytes } from 'crypto';

const id = chunk.id || `memory-${Date.now()}-${randomBytes(8).toString('hex')}`;
```

---

#### 4. 错误信息泄露 - 详细的错误返回给客户端

**文件**: [src/mcp-server.ts](file:///Users/lujane/配置技能/jiyixitong-wan/src/mcp-server.ts#L343-L353)  
**行号**: 343-353

**问题描述**:
在 MCP 服务器的错误处理中，将原始错误信息直接返回给客户端。

```typescript
} catch (error) {
  return {
    content: [
      {
        type: 'text',
        text: `Error: ${error instanceof Error ? error.message : String(error)}`,
      },
    ],
    isError: true,
  };
}
```

**潜在影响**:
- 可能泄露内部实现细节
- 可能暴露文件系统结构或数据库信息

**修复建议**:
记录详细错误到日志，向客户端返回通用错误信息：

```typescript
} catch (error) {
  console.error('MCP tool error:', error);  // 记录详细错误
  return {
    content: [
      {
        type: 'text',
        text: 'An internal error occurred. Please try again later.',
      },
    ],
    isError: true,
  };
}
```

---

#### 5. 临时目录使用不当

**文件**: [src/cli.ts](file:///Users/lujane/配置技能/jiyixitong-wan/src/cli.ts#L12)  
**行号**: 12

**问题描述**:
CLI 使用了固定的临时目录路径 `/tmp/jiyixitong-test`，在多用户环境下可能导致冲突。

```typescript
const tempDir = path.join('/tmp', 'jiyixitong-test');
```

**潜在影响**:
- 多用户环境下的数据冲突
- 权限问题

**修复建议**:
使用用户特定的临时目录：

```typescript
import { tmpdir } from 'os';
import { randomBytes } from 'crypto';

const tempDir = path.join(tmpdir(), `jiyixitong-${randomBytes(4).toString('hex')}`);
```

---

## 正面安全实践

项目在以下方面表现良好：

1. **参数化查询**: 数据库操作普遍使用参数化查询，有效防止 SQL 注入
2. **输入验证**: MCP 工具的输入使用了 JSON Schema 验证
3. **最小权限**: 文件操作遵循最小权限原则
4. **API 密钥处理**: LLM 提供者中的 API 密钥通过构造函数传入，未硬编码

---

## 修复优先级建议

| 优先级 | 问题 | 原因 |
|--------|------|------|
| 高 | 路径遍历风险 | 可能导致敏感文件访问 |
| 中 | SQL LIKE 注入风险 | 影响搜索功能完整性 |
| 低 | 随机数生成、错误信息泄露、临时目录 | 安全加固建议 |

---

## 附录：检查清单

- [x] SQL 注入检查
- [x] 路径遍历检查
- [x] 敏感信息泄露检查
- [x] 随机数生成检查
- [x] 错误处理检查
- [x] 文件权限检查
- [x] 输入验证检查
- [x] API 密钥处理检查
