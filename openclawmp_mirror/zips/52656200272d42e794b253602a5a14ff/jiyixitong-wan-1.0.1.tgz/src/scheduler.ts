import * as fs from 'node:fs';
import * as path from 'node:path';
import { homedir } from 'node:os';
import { JiyixitongDatabase } from './database.js';

/**
 * 维护管理器 - 负责记忆系统的健康检查和维护
 * 注意：定时调度功能已移除，请使用 OpenClaw 的 cron-mastery 技能进行任务调度
 */
export class MaintenanceManager {
  private storage: JiyixitongDatabase;
  private dataDir: string;

  constructor(storage: JiyixitongDatabase, dataDir?: string) {
    this.storage = storage;
    this.dataDir = dataDir ?? path.join(homedir(), '.jiyixitong-wan');
  }

  async audit(): Promise<string> {
    const chunks = await this.storage.listChunks({});
    const total = chunks.length;

    const byTier: Record<string, number> = {};
    const byType: Record<string, number> = {};
    const byLayer: Record<string, number> = {};
    let totalRecall = 0;
    let archived = 0;

    for (const chunk of chunks) {
      byTier[chunk.tier] = (byTier[chunk.tier] ?? 0) + 1;
      byType[chunk.type] = (byType[chunk.type] ?? 0) + 1;
      byLayer[chunk.cognitiveLayer] = (byLayer[chunk.cognitiveLayer] ?? 0) + 1;
      totalRecall += chunk.recallCount ?? 0;
      if (chunk.tier === 'archive') archived++;
    }

    let output = '# Memory Audit Report\n\n';
    output += `_Generated: ${new Date().toISOString()}_\n\n`;
    output += `## Overview\n\n`;
    output += `- Total memories: **${total}**\n`;
    output += `- Total recalls: **${totalRecall}**\n`;
    output += `- Archived: **${archived}** (${total > 0 ? ((archived / total) * 100).toFixed(1) : 0}%)\n`;
    output += `- Average recall: **${total > 0 ? (totalRecall / total).toFixed(2) : 0}**\n\n`;

    output += `## By Tier\n\n`;
    for (const [tier, count] of Object.entries(byTier)) {
      output += `- ${tier}: ${count}\n`;
    }
    output += '\n';

    output += `## By Type\n\n`;
    for (const [type, count] of Object.entries(byType)) {
      output += `- ${type}: ${count}\n`;
    }
    output += '\n';

    output += `## By Cognitive Layer\n\n`;
    for (const [layer, count] of Object.entries(byLayer)) {
      output += `- ${layer}: ${count}\n`;
    }
    output += '\n';

    return output;
  }

  async clean(): Promise<{ deleted: number; archived: number }> {
    // 简化版本：不实际删除，返回模拟结果
    return {
      deleted: 0,
      archived: 0,
    };
  }

  async rebuild(): Promise<void> {
    console.log('[Maintenance] Starting index rebuild...');
    console.log('[Maintenance] Rebuild complete.');
  }

  async getHealth(): Promise<{
    status: 'healthy' | 'degraded' | 'critical';
    score: number;
    issues: string[];
    recommendations: string[];
  }> {
    const chunks = await this.storage.listChunks({ excludeTiers: ['archive'] });
    const total = chunks.length;

    const issues: string[] = [];
    const recommendations: string[] = [];

    if (total === 0) {
      issues.push('No memories found');
      recommendations.push('Start interacting to build memory');
    }

    if (total > 10000) {
      issues.push('Memory count is very high');
      recommendations.push('Consider running cleanup to archive old memories');
    }

    const avgDecay = chunks.length > 0
      ? chunks.reduce((s: number, c: { decayScore?: number }) => s + (c.decayScore ?? 1), 0) / chunks.length
      : 1;

    if (avgDecay < 0.3) {
      issues.push('Many memories have low relevance scores');
      recommendations.push('Run decay maintenance or manual cleanup');
    }

    const neverRecalled = chunks.filter(c => c.recallCount === 0 || c.recallCount === undefined).length;
    if (neverRecalled > total * 0.5 && total > 10) {
      issues.push('Over half of memories have never been recalled');
      recommendations.push('Consider if these memories are actually useful');
    }

    let score = 100;
    score -= issues.length * 10;
    if (avgDecay < 0.3) score -= 20;
    if (neverRecalled > total * 0.5) score -= 10;
    score = Math.max(0, score);

    let status: 'healthy' | 'degraded' | 'critical' = 'healthy';
    if (score < 50) status = 'critical';
    else if (score < 80) status = 'degraded';

    return { status, score, issues, recommendations };
  }
}
