export type MemoryType = 'fact' | 'preference' | 'decision' | 'context' | 'correction' | 'commitment' | 'moment' | 'skill' | 'question';

export type CognitiveLayer = 'episodic' | 'semantic' | 'procedural' | 'core';

export type MemoryTier = 'daily' | 'short-term' | 'long-term' | 'archive';

export type Sentiment = 'frustrated' | 'curious' | 'satisfied' | 'neutral' | 'excited' | 'confused';

export type ConfidenceLevel = 'explicit' | 'implied' | 'inferred' | 'speculative';

export interface MemoryChunk {
  id: string;
  tier: MemoryTier;
  content: string;
  type: MemoryType;
  cognitiveLayer: CognitiveLayer;
  tags: string[];
  source: string;
  importance: number;
  sentiment: Sentiment;
  createdAt: string;
  updatedAt: string;
  accessedAt: string;
  accessCount: number;
  lastRecalledAt?: string | null;
  recallCount?: number;
  embedding?: number[];
  relatedMemories?: MemoryEdge[];
  recallOutcomes?: RecallOutcome[];
  decayScore?: number;
  confidence?: ConfidenceLevel;
}

export interface MemoryEdge {
  targetId: string;
  relation: string;
  weight: number;
}

export interface RecallOutcome {
  timestamp: string;
  outcome: 'helpful' | 'corrected' | 'irrelevant';
  sessionId: string;
}

export interface DailyLogEntry {
  timestamp: string;
  conversationId: string;
  summary: string;
  extractedFacts: string[];
}

export interface ProceduralRule {
  id: string;
  rule: string;
  domain: 'code' | 'communication' | 'workflow' | 'preference' | 'general';
  confidence: number;
  reinforcements: number;
  contradictions: number;
  evidence: string[];
  createdAt: string;
  updatedAt: string;
}

export interface SearchResult {
  chunk: MemoryChunk;
  score: number;
  matchedTerms?: string[];
}

export interface ListOptions {
  tier?: MemoryTier;
  cognitiveLayer?: CognitiveLayer;
  excludeTiers?: MemoryTier[];
  type?: MemoryType;
  limit?: number;
}

export interface SearchOptions {
  maxResults?: number;
  minScore?: number;
  filter?: string;
}

export interface IngestOptions {
  type?: MemoryType;
  cognitiveLayer?: CognitiveLayer;
  importance?: number;
  tags?: string[];
  sentiment?: Sentiment;
}

export interface QuantifierData {
  meta: {
    version: string;
    initialized_at: string;
    last_update: string;
    conversation_id: string;
  };
  growth: {
    baseline: {
      overall: number;
      knowledge_coverage: number;
      capability_depth: number;
      response_quality: number;
      task_efficiency: number;
    };
    current: {
      overall: number;
      knowledge_coverage: number;
      capability_depth: number;
      response_quality: number;
      task_efficiency: number;
    };
    growth_percent: {
      overall: number;
      knowledge_coverage: number;
      capability_depth: number;
      response_quality: number;
      task_efficiency: number;
    };
    history: Array<{
      timestamp: string;
      overall: number;
      conversation_count: number;
      notes: string;
    }>;
  };
  tasks: {
    total: number;
    completed: number;
    in_progress: number;
    failed: number;
    completion_rate: number;
    average_quality: number;
    average_duration_minutes: number;
    by_type: Record<string, number>;
    recent: TaskRecord[];
  };
  learning: {
    new_concepts: ConceptRecord[];
    total_concepts: number;
    by_category: Record<string, number>;
  };
  efficiency: {
    avg_response_time_seconds: number;
    first_try_success_rate: number;
    avg_iterations_per_task: number;
    time_distribution: {
      thinking_percent: number;
      tool_execution_percent: number;
      output_preparation_percent: number;
    };
    tool_usage_stats: {
      total_calls: number;
      by_tool: Record<string, number>;
    };
  };
  achievements: {
    milestones: AchievementRecord[];
    highlights: AchievementRecord[];
    breakthroughs: AchievementRecord[];
    total_count: number;
  };
  goals: {
    active: GoalRecord[];
    completed: GoalRecord[];
    abandoned: GoalRecord[];
  };
  daily_stats: Record<string, DailyStats>;
  weekly_summary: {
    week_start: string;
    total_conversations: number;
    total_tasks: number;
    total_concepts: number;
    total_achievements: number;
    avg_daily_growth: number;
    best_day: string | null;
    trend: 'improving' | 'stable' | 'declining';
  };
  preferences: {
    report_detail: 'full' | 'summary' | 'minimal';
    auto_track: boolean;
    show_trends: boolean;
    show_progress_bars: boolean;
    retention_days: number;
  };
}

export interface TaskRecord {
  id: string;
  type: string;
  title: string;
  status: 'completed' | 'in_progress' | 'failed';
  quality_score: number;
  duration_minutes: number;
  iterations: number;
  started_at: string;
  completed_at?: string;
  user_satisfaction?: 'high' | 'medium' | 'low';
  tools_used: string[];
}

export interface ConceptRecord {
  name: string;
  category: string;
  mastery_level: number;
  first_learned_at: string;
  last_applied_at?: string;
  applied_count: number;
  source: string;
  related_concepts: string[];
  notes?: string;
}

export interface AchievementRecord {
  id: string;
  type: 'milestone' | 'highlight' | 'breakthrough';
  title: string;
  description: string;
  timestamp: string;
  icon: string;
  related_tasks: string[];
  impact: 'high' | 'medium' | 'low';
}

export interface GoalRecord {
  id: string;
  name: string;
  description: string;
  progress: number;
  target: number;
  unit: string;
  status: 'in_progress' | 'completed' | 'abandoned';
  created_at: string;
  eta_days?: number;
  milestones?: Array<{ name: string; completed: boolean }>;
}

export interface DailyStats {
  date: string;
  conversations: number;
  tasks_completed: number;
  concepts_learned: number;
  achievements_unlocked: number;
  overall_growth: number;
  efficiency_score: number;
  satisfaction_rate: number;
  notes?: string;
}

export interface Reflection {
  session_id: string;
  duration_minutes: number;
  memories: Array<{
    type: MemoryType;
    content: string;
    confidence: number;
    source: string;
  }>;
  questions: Question[];
  identity_update: {
    growth: string;
    narrative: string;
  };
  timestamp: string;
}

export interface Question {
  id: string;
  text: string;
  source: 'dream' | 'reading' | 'work' | 'reflection';
  date: string;
  resolved: boolean;
  context?: string;
}

export interface Identity {
  core_values: string[];
  growth_narrative: string;
  capabilities: string[];
  relationships: Record<string, string>;
  self_image: {
    who_i_think_i_am: string[];
    patterns_noticed: string[];
    quirks: string[];
    edges_limitations: string[];
    what_i_value: string[];
    open_questions: string[];
  };
  last_updated: string;
}

export interface AuditEntry {
  timestamp: string;
  action: 'CREATE' | 'EDIT' | 'APPEND' | 'DELETE' | 'ARCHIVE' | 'MERGE' | 'REVERT' | 'DECAY';
  file: string;
  actor: string;
  approval: string;
  summary: string;
}

export interface JiyixitongWanConfig {
  memorySearch: {
    enabled: boolean;
    provider: string;
    sources: string[];
    minScore: number;
    maxResults: number;
  };
  extraction: {
    autoExtract: boolean;
    threshold: number;
  };
  decay: {
    rate: number;
    halfLifeDays: number;
    archiveThreshold: number;
  };
  reflection: {
    schedule: string;
    tokenBudget: number;
  };
  quantification: {
    autoTrack: boolean;
    retentionDays: number;
  };
  dataDir: string;
}