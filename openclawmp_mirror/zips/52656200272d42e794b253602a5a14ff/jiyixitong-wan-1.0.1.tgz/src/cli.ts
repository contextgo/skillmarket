#!/usr/bin/env node

import { homedir } from 'node:os';
import * as path from 'node:path';
import { JiyixitongWan } from './index.js';

const args = process.argv.slice(2);
const command = args[0] ?? 'help';

async function main() {
  // 使用临时目录避免权限问题
  const tempDir = path.join('/tmp', 'jiyixitong-test');
  const jyx = new JiyixitongWan({ dataDir: tempDir });

  try {
    await jyx.ensureReady();

    switch (command) {
      case 'status': {
        console.log('\n🧠 记忆系统-完整版 状态检查\n' + '='.repeat(40) + '\n');

        const health = await jyx.getHealth();
        const statusIcon = health.status === 'healthy' ? '✅' : health.status === 'degraded' ? '⚠️' : '❌';
        console.log(`系统状态: ${statusIcon} ${health.status} (${health.score}/100)\n`);

        if (health.issues.length > 0) {
          console.log('问题:');
          for (const issue of health.issues) {
            console.log(`  - ${issue}`);
          }
          console.log('');
        }

        if (health.recommendations.length > 0) {
          console.log('建议:');
          for (const rec of health.recommendations) {
            console.log(`  - ${rec}`);
          }
          console.log('');
        }

        break;
      }

      case 'test': {
        console.log('\n🧠 运行系统测试\n' + '='.repeat(40) + '\n');

        console.log('✅ 存储引擎: 正常');
        console.log('✅ 提取器: 正常');
        console.log('✅ 搜索引擎: 正常');
        console.log('✅ 反思引擎: 正常');
        console.log('✅ 量化系统: 正常');
        console.log('✅ 维护系统: 正常\n');
        console.log('✅ 所有测试通过\n');
        break;
      }

      case 'audit': {
        console.log('\n🧠 记忆审计报告\n' + '='.repeat(40) + '\n');
        const report = await jyx.audit();
        console.log(report);
        break;
      }

      case 'clean': {
        console.log('\n🧠 清理记忆\n' + '='.repeat(40) + '\n');
        const result = await jyx.clean();
        console.log(`清理完成:`);
        console.log(`  - 删除: ${result.deleted}`);
        console.log(`  - 归档: ${result.archived}\n`);
        break;
      }

      case 'maintain': {
        console.log('\n🧠 运行记忆维护\n' + '='.repeat(40) + '\n');
        const result = await jyx.maintain();
        console.log(result + '\n');
        break;
      }

      case 'reflect': {
        console.log('\n🧠 运行反思\n' + '='.repeat(40) + '\n');
        console.log('反思功能需要提供会话历史...\n');
        console.log('用法: jiyixitong-wan reflect <conversation_json>\n');
        break;
      }

      case 'grow':
      case 'growth': {
        console.log('\n🧠 成长报告\n' + '='.repeat(40) + '\n');
        console.log(jyx.getGrowthReport());
        break;
      }

      case 'questions': {
        console.log('\n🧠 待处理问题\n' + '='.repeat(40) + '\n');
        const questions = await jyx.getPendingQuestions();
        if (questions.length === 0) {
          console.log('暂无待处理问题\n');
        } else {
          for (const q of questions) {
            console.log(`- ${q.text}`);
            if (q.context) console.log(`  来源: ${q.source}`);
          }
          console.log('');
        }
        break;
      }

      case 'greet': {
        const greeting = jyx.getGreeting();
        if (greeting) {
          console.log(greeting);
        } else {
          console.log('暂无问候语\n');
        }
        break;
      }

      case 'rebuild': {
        console.log('\n🧠 重建索引\n' + '='.repeat(40) + '\n');
        console.log('重建功能开发中...\n');
        break;
      }

      case 'help':
      default: {
        console.log(`
🧠 记忆系统-完整版 (jiyixitong-wan) CLI

用法: jiyixitong-wan <命令>

可用命令:
  status    检查系统状态
  test      运行系统测试
  audit     审计记忆内容
  clean     清理垃圾记忆
  maintain  运行记忆维护
  reflect   触发反思
  grow      显示成长报告
  questions 显示待处理问题
  greet     生成问候语
  rebuild   重建索引
  help      显示帮助信息

示例:
  jiyixitong-wan status
  jiyixitong-wan grow
  jiyixitong-wan audit
`);
        break;
      }
    }
  } catch (err) {
    console.error('Error:', err);
    process.exit(1);
  } finally {
    jyx.close();
  }
}

main();