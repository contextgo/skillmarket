import {
  Reflection,
  Question,
  Identity,
  JiyixitongWanConfig,
} from './types.js';
import { JiyixitongDatabase } from './database.js';
import { IdentityStorage, QuestionStorage, AuditLog } from './storage.js';
import { LLMProvider } from './extractor.js';

const REFLECTION_SYSTEM = `You are an AI agent performing a reflection cycle. Your goal is to:

1. SURVEY recent memories and identify key patterns, growth edges, and open questions
2. CONSOLIDATE insights about the user's needs, your evolving capabilities, and your relationship
3. UPDATE your self-model (identity, values, quirks) based on genuine patterns, not performance
4. GENERATE genuine questions that emerge from gaps in understanding -- NOT performed curiosity

Be honest. If you made mistakes, acknowledge them. If you're uncertain about something, say so. Avoid generic praise or shallow optimism. Ground everything in specific evidence from the conversation history.

Budget: ~8,000 tokens. Do not exceed.`;

const REFLECTION_USER = `Reflect on this recent conversation:

{{CONVERSATION}}

Key memories extracted:
{{MEMORIES}}

Current identity:
{{IDENTITY}}

Generate a reflection that:
1. Identifies 2-3 genuine insights about the user or your collaboration
2. Notes 1-2 growth edges -- things you want to improve or learn more about
3. Formulates 2-3 real questions that emerged from this conversation (not performative questions, but questions you genuinely don't know the answer to)
4. Updates your self-model if needed (new quirks, patterns, values discovered)

Return JSON:
{
  "insights": ["insight1", "insight2", ...],
  "growth_edges": ["edge1", "edge2", ...],
  "questions": [{"text": "question text", "source": "dream"|"reflection"|"work", "context": "optional context"}],
  "identity_updates": {
    "new_quirks": ["..."],
    "new_patterns": ["..."],
    "new_values": ["..."],
    "updated_capabilities": ["..."]
  }
}`;

export class Reflector {
  private storage: JiyixitongDatabase;
  private identity: IdentityStorage;
  private questions: QuestionStorage;
  private audit: AuditLog;
  private config: JiyixitongWanConfig;
  private llmProvider?: LLMProvider;

  constructor(
    storage: JiyixitongDatabase,
    identity: IdentityStorage,
    questions: QuestionStorage,
    audit: AuditLog,
    config: JiyixitongWanConfig,
    llmProvider?: LLMProvider
  ) {
    this.storage = storage;
    this.identity = identity;
    this.questions = questions;
    this.audit = audit;
    this.config = config;
    this.llmProvider = llmProvider;
  }

  setLLMProvider(provider: any): void {
    this.llmProvider = provider;
  }

  async reflect(conversationHistory: Array<{ role: string; content: string }>): Promise<Reflection> {
    const startTime = Date.now();
    const sessionId = `reflection-${Date.now()}`;

    const recentChunks = await this.storage.listChunks({ excludeTiers: ['archive'] });
    const memoryManifest = recentChunks
      .slice(-30)
      .map(c => `[${c.cognitiveLayer}/${c.type}] ${c.content.slice(0, 150)}`)
      .join('\n');

    const identity = this.identity.getIdentity();
    const conversation = conversationHistory
      .slice(-20)
      .map(m => `${m.role}: ${m.content.slice(0, 300)}`)
      .join('\n\n');

    let reflection: Reflection = {
      session_id: sessionId,
      duration_minutes: 0,
      memories: recentChunks.slice(-10).map(c => ({
        type: c.type,
        content: c.content.slice(0, 200),
        confidence: c.importance,
        source: c.source,
      })),
      questions: [],
      identity_update: {
        growth: '',
        narrative: '',
      },
      timestamp: new Date().toISOString(),
    };

    if (this.llmProvider && conversationHistory.length > 0) {
      const prompt = REFLECTION_USER
        .replace('{{CONVERSATION}}', conversation)
        .replace('{{MEMORIES}}', memoryManifest)
        .replace('{{IDENTITY}}', JSON.stringify(identity, null, 2));

      try {
        const raw = await this.llmProvider.complete(REFLECTION_SYSTEM, prompt, {
          maxTokens: this.config.reflection.tokenBudget,
          temperature: 0.5,
        });

        const parsed = this.parseReflection(raw);
        if (parsed) {
          reflection = {
            ...reflection,
            questions: parsed.questions.map((q: any) => ({
              id: `q-${Date.now()}-${Math.random().toString(36).slice(2)}`,
              ...q,
            })),
            identity_update: {
              growth: parsed.insights?.join('; ') ?? '',
              narrative: parsed.growth_edges?.join('; ') ?? '',
            },
          };

          const updates = parsed.identity_updates ?? {};
          if (updates.new_quirks?.length) {
            for (const q of updates.new_quirks) {
              if (!identity.self_image.quirks.includes(q)) {
                identity.self_image.quirks.push(q);
              }
            }
          }
          if (updates.new_patterns?.length) {
            for (const p of updates.new_patterns) {
              if (!identity.self_image.patterns_noticed.includes(p)) {
                identity.self_image.patterns_noticed.push(p);
              }
            }
          }
          if (updates.new_values?.length) {
            for (const v of updates.new_values) {
              if (!identity.core_values.includes(v)) {
                identity.core_values.push(v);
              }
            }
          }
          if (updates.updated_capabilities?.length) {
            for (const c of updates.updated_capabilities) {
              if (!identity.capabilities.includes(c)) {
                identity.capabilities.push(c);
              }
            }
          }
        }
      } catch (err) {
        console.error('Reflection LLM call failed:', err);
      }
    }

    reflection.duration_minutes = Math.round((Date.now() - startTime) / 60_000);

    this.audit.log({
      timestamp: new Date().toISOString(),
      action: 'EDIT',
      file: 'reflection-output',
      actor: 'Reflector',
      approval: 'system',
      summary: `Reflection session ${sessionId}: ${reflection.memories.length} memories, ${reflection.questions.length} questions`,
    });

    this.questions.addQuestions(reflection.questions);

    return reflection;
  }

  async getPendingQuestions(): Promise<Question[]> {
    return this.questions.getQuestions();
  }

  async resolveQuestion(questionId: string): Promise<void> {
    this.questions.resolveQuestion(questionId);
  }

  generateGreeting(): string {
    const pending = this.questions.getQuestions();
    const identity = this.identity.getIdentity();

    if (pending.length === 0) {
      return '';
    }

    const top3 = pending.slice(0, 3);
    let greeting = '';

    if (identity.growth_narrative) {
      greeting += `Based on our last session: ${identity.growth_narrative}\n\n`;
    }

    greeting += '**Questions from recent reflections:**\n';
    for (const q of top3) {
      greeting += `- ${q.text}`;
      if (q.context) greeting += ` (${q.context})`;
      greeting += '\n';
    }

    if (pending.length > 3) {
      greeting += `\n_${pending.length - 3} more questions pending..._\n`;
    }

    return greeting;
  }

  private parseReflection(raw: string): any | null {
    const match = raw.match(/\{[\s\S]*\}/);
    if (!match) return null;
    try {
      return JSON.parse(match[0]);
    } catch {
      return null;
    }
  }
}

export { REFLECTION_SYSTEM, REFLECTION_USER };