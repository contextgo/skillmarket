import * as fs from 'node:fs';
import * as path from 'node:path';
import { homedir } from 'node:os';
import {
  MemoryChunk,
  MemoryTier,
  QuantifierData,
  Identity,
  Question,
  AuditEntry,
  JiyixitongWanConfig,
} from './types.js';

const DEFAULT_CONFIG: JiyixitongWanConfig = {
  memorySearch: {
    enabled: true,
    provider: 'openai',
    sources: ['memory'],
    minScore: 0.1,
    maxResults: 20,
  },
  extraction: {
    autoExtract: true,
    threshold: 5,
  },
  decay: {
    rate: 0.03,
    halfLifeDays: 23,
    archiveThreshold: 0.05,
  },
  reflection: {
    schedule: '0 4 * * *',
    tokenBudget: 8000,
  },
  quantification: {
    autoTrack: true,
    retentionDays: 90,
  },
  dataDir: path.join(homedir(), '.jiyixitong-wan'),
};

export class IdentityStorage {
  private identityPath: string;

  constructor(dataDir: string) {
    this.identityPath = path.join(dataDir, 'identity.md');
  }

  getIdentity(): Identity {
    if (fs.existsSync(this.identityPath)) {
      const content = fs.readFileSync(this.identityPath, 'utf-8');
      try {
        const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/);
        if (jsonMatch) {
          return JSON.parse(jsonMatch[1]);
        }
      } catch {
        // Fallback
      }
    }

    return {
      core_values: ['helpful', 'honest', 'harmless'],
      growth_narrative: '',
      self_image: {
        who_i_think_i_am: [],
        patterns_noticed: [],
        quirks: [],
        edges_limitations: [],
        what_i_value: [],
        open_questions: [],
      },
      capabilities: [],
      relationships: {},
      last_updated: new Date().toISOString(),
    };
  }

  updateIdentity(updates: Partial<Identity>): void {
    const current = this.getIdentity();
    const updated = { ...current, ...updates };
    
    const content = `# AI Identity\n\n\`\`\`json\n${JSON.stringify(updated, null, 2)}\n\`\`\``;
    
    fs.mkdirSync(path.dirname(this.identityPath), { recursive: true });
    fs.writeFileSync(this.identityPath, content);
  }
}

export class QuantifierStorage {
  private dataPath: string;

  constructor(dataDir: string) {
    this.dataPath = path.join(dataDir, 'quantified_self.json');
  }

  getData(): QuantifierData {
    if (fs.existsSync(this.dataPath)) {
      try {
        return JSON.parse(fs.readFileSync(this.dataPath, 'utf-8'));
      } catch {
        // Fallback
      }
    }

    return {
      meta: {
        version: 'quantified-1.0',
        initialized_at: new Date().toISOString(),
        last_update: new Date().toISOString(),
        conversation_id: '',
      },
      growth: {
        baseline: {
          overall: 50,
          knowledge_coverage: 50,
          capability_depth: 50,
          response_quality: 50,
          task_efficiency: 50,
        },
        current: {
          overall: 50,
          knowledge_coverage: 50,
          capability_depth: 50,
          response_quality: 50,
          task_efficiency: 50,
        },
        growth_percent: {
          overall: 0,
          knowledge_coverage: 0,
          capability_depth: 0,
          response_quality: 0,
          task_efficiency: 0,
        },
        history: [],
      },
      tasks: {
        total: 0,
        completed: 0,
        in_progress: 0,
        failed: 0,
        completion_rate: 0,
        average_quality: 0,
        average_duration_minutes: 0,
        by_type: {},
        recent: [],
      },
      learning: {
        new_concepts: [],
        total_concepts: 0,
        by_category: {},
      },
      efficiency: {
        avg_response_time_seconds: 0,
        first_try_success_rate: 0,
        avg_iterations_per_task: 0,
        time_distribution: {
          thinking_percent: 0,
          tool_execution_percent: 0,
          output_preparation_percent: 0,
        },
        tool_usage_stats: {
          total_calls: 0,
          by_tool: {},
        },
      },
      achievements: {
        milestones: [],
        highlights: [],
        breakthroughs: [],
        total_count: 0,
      },
      goals: {
          active: [],
          completed: [],
          abandoned: [],
        },
        daily_stats: {},
        weekly_summary: {
          week_start: new Date().toISOString(),
          total_conversations: 0,
          total_tasks: 0,
          total_concepts: 0,
          total_achievements: 0,
          avg_daily_growth: 0,
          best_day: null,
          trend: 'stable',
        },
        preferences: {
          report_detail: 'summary',
          auto_track: true,
          show_trends: true,
          show_progress_bars: true,
          retention_days: 90,
        },
      };
  }

  saveData(data: QuantifierData): void {
    data.meta.last_update = new Date().toISOString();
    fs.mkdirSync(path.dirname(this.dataPath), { recursive: true });
    fs.writeFileSync(this.dataPath, JSON.stringify(data, null, 2));
  }
}

export class QuestionStorage {
  private questionsPath: string;

  constructor(dataDir: string) {
    this.questionsPath = path.join(dataDir, 'questions.md');
  }

  getQuestions(): Question[] {
    if (fs.existsSync(this.questionsPath)) {
      const content = fs.readFileSync(this.questionsPath, 'utf-8');
      try {
        const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/);
        if (jsonMatch) {
          return JSON.parse(jsonMatch[1]);
        }
      } catch {
        // Fallback
      }
    }
    return [];
  }

  addQuestion(question: Question): void {
    const questions = this.getQuestions();
    questions.push(question);
    this.saveQuestions(questions);
  }

  addQuestions(questions: Question[]): void {
    const existing = this.getQuestions();
    const updated = [...existing, ...questions];
    this.saveQuestions(updated);
  }

  resolveQuestion(id: string): void {
    const questions = this.getQuestions();
    const updated = questions.map(q => 
      q.id === id ? { ...q, resolved: true } : q
    );
    this.saveQuestions(updated);
  }

  private saveQuestions(questions: Question[]): void {
    const content = `# Pending Questions\n\n\`\`\`json\n${JSON.stringify(questions, null, 2)}\n\`\`\``;
    fs.mkdirSync(path.dirname(this.questionsPath), { recursive: true });
    fs.writeFileSync(this.questionsPath, content);
  }
}

export class AuditLog {
  private logPath: string;

  constructor(dataDir: string) {
    this.logPath = path.join(dataDir, 'audit.log');
  }

  log(entry: AuditEntry): void {
    const logEntry = JSON.stringify({
      ...entry,
      timestamp: new Date().toISOString(),
    });
    
    fs.mkdirSync(path.dirname(this.logPath), { recursive: true });
    fs.appendFileSync(this.logPath, logEntry + '\n');
  }

  getLogs(limit: number = 100): AuditEntry[] {
    if (!fs.existsSync(this.logPath)) return [];
    
    const lines = fs.readFileSync(this.logPath, 'utf-8').split('\n').filter(Boolean);
    return lines.slice(-limit).map(line => JSON.parse(line));
  }
}

export { DEFAULT_CONFIG };
