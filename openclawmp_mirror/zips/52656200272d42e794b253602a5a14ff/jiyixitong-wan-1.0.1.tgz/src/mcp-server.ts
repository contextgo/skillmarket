import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
  Tool,
} from '@modelcontextprotocol/sdk/types.js';
import { JiyixitongWan } from './index.js';
import { JiyixitongWanConfig } from './types.js';
import * as path from 'node:path';
import { homedir } from 'node:os';

export interface AgentContext {
  agentId: string;
  agentName: string;
  sessionId: string;
  permissions: string[];
  metadata: Record<string, any>;
}

export interface IsolatedMemorySystem {
  agentId: string;
  memorySystem: JiyixitongWan;
  context: AgentContext;
  createdAt: Date;
  lastAccessedAt: Date;
}

export class JiyixitongMcpServer {
  private server: Server;
  private agentSystems: Map<string, IsolatedMemorySystem> = new Map();
  private globalConfig: Partial<JiyixitongWanConfig>;
  private baseDataDir: string;

  constructor(config?: Partial<JiyixitongWanConfig>) {
    this.globalConfig = config || {};
    this.baseDataDir = config?.dataDir || path.join(homedir(), '.jiyixitong-wan');

    this.server = new Server(
      {
        name: 'jiyixitong-wan-mcp',
        version: '1.0.0',
      },
      {
        capabilities: {
          tools: {},
        },
      }
    );

    this.setupToolHandlers();
  }

  private setupToolHandlers(): void {
    this.server.setRequestHandler(ListToolsRequestSchema, async () => {
      return {
        tools: [
          {
            name: 'memory_save',
            description: '保存记忆到智能体记忆系统',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
                content: {
                  type: 'string',
                  description: '记忆内容',
                },
                type: {
                  type: 'string',
                  enum: ['fact', 'preference', 'decision', 'context', 'correction', 'commitment', 'moment', 'skill', 'question'],
                  description: '记忆类型',
                },
                cognitive_layer: {
                  type: 'string',
                  enum: ['episodic', 'semantic', 'procedural', 'core'],
                  description: '认知层',
                },
                importance: {
                  type: 'number',
                  minimum: 0,
                  maximum: 1,
                  description: '重要性评分 (0-1)',
                },
                tags: {
                  type: 'array',
                  items: { type: 'string' },
                  description: '标签列表',
                },
              },
              required: ['agent_id', 'content'],
            },
          },
          {
            name: 'memory_search',
            description: '搜索智能体的记忆',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
                query: {
                  type: 'string',
                  description: '搜索查询',
                },
                max_results: {
                  type: 'number',
                  default: 10,
                  description: '最大结果数',
                },
                min_score: {
                  type: 'number',
                  default: 0.3,
                  description: '最小匹配分数',
                },
              },
              required: ['agent_id', 'query'],
            },
          },
          {
            name: 'memory_extract',
            description: '从对话中提取记忆',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
                messages: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      role: { type: 'string' },
                      content: { type: 'string' },
                    },
                  },
                  description: '对话消息列表',
                },
                conversation_id: {
                  type: 'string',
                  description: '对话ID',
                },
              },
              required: ['agent_id', 'messages', 'conversation_id'],
            },
          },
          {
            name: 'memory_reflect',
            description: '触发反思过程',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
                conversation_history: {
                  type: 'array',
                  items: {
                    type: 'object',
                    properties: {
                      role: { type: 'string' },
                      content: { type: 'string' },
                    },
                  },
                  description: '对话历史',
                },
              },
              required: ['agent_id'],
            },
          },
          {
            name: 'memory_get_questions',
            description: '获取待处理的问题',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
              },
              required: ['agent_id'],
            },
          },
          {
            name: 'memory_get_growth_report',
            description: '获取成长报告',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
              },
              required: ['agent_id'],
            },
          },
          {
            name: 'memory_record_task',
            description: '记录任务完成情况',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
                task: {
                  type: 'object',
                  properties: {
                    type: { type: 'string' },
                    title: { type: 'string' },
                    status: { type: 'string', enum: ['completed', 'in_progress', 'failed'] },
                    quality_score: { type: 'number' },
                  },
                  description: '任务信息',
                },
              },
              required: ['agent_id', 'task'],
            },
          },
          {
            name: 'agent_initialize',
            description: '初始化智能体记忆系统（隔离）',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
                agent_name: {
                  type: 'string',
                  description: '智能体名称',
                },
                permissions: {
                  type: 'array',
                  items: { type: 'string' },
                  description: '权限列表',
                },
                metadata: {
                  type: 'object',
                  description: '元数据',
                },
              },
              required: ['agent_id', 'agent_name'],
            },
          },
          {
            name: 'agent_list',
            description: '列出所有已初始化的智能体',
            inputSchema: {
              type: 'object',
              properties: {},
            },
          },
          {
            name: 'agent_cleanup',
            description: '清理智能体记忆系统',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
              },
              required: ['agent_id'],
            },
          },
          {
            name: 'system_health',
            description: '获取系统健康状态',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识（可选）',
                },
              },
            },
          },
          {
            name: 'system_maintain',
            description: '运行系统维护',
            inputSchema: {
              type: 'object',
              properties: {
                agent_id: {
                  type: 'string',
                  description: '智能体唯一标识',
                },
              },
              required: ['agent_id'],
            },
          },
        ] as Tool[],
      };
    });

    this.server.setRequestHandler(CallToolRequestSchema, async (request) => {
      const { name, arguments: args } = request.params;

      try {
        switch (name) {
          case 'agent_initialize':
            return await this.handleAgentInitialize(args as any);
          case 'agent_list':
            return await this.handleAgentList();
          case 'agent_cleanup':
            return await this.handleAgentCleanup(args as any);
          case 'memory_save':
            return await this.handleMemorySave(args as any);
          case 'memory_search':
            return await this.handleMemorySearch(args as any);
          case 'memory_extract':
            return await this.handleMemoryExtract(args as any);
          case 'memory_reflect':
            return await this.handleMemoryReflect(args as any);
          case 'memory_get_questions':
            return await this.handleMemoryGetQuestions(args as any);
          case 'memory_get_growth_report':
            return await this.handleMemoryGetGrowthReport(args as any);
          case 'memory_record_task':
            return await this.handleMemoryRecordTask(args as any);
          case 'system_health':
            return await this.handleSystemHealth(args as any);
          case 'system_maintain':
            return await this.handleSystemMaintain(args as any);
          default:
            throw new Error(`Unknown tool: ${name}`);
        }
      } catch (error) {
        return {
          content: [
            {
              type: 'text',
              text: `Error: ${error instanceof Error ? error.message : String(error)}`,
            },
          ],
          isError: true,
        };
      }
    });
  }

  private async handleAgentInitialize(args: {
    agent_id: string;
    agent_name: string;
    permissions?: string[];
    metadata?: Record<string, any>;
  }) {
    const { agent_id, agent_name, permissions = [], metadata = {} } = args;

    if (this.agentSystems.has(agent_id)) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              success: true,
              message: `Agent ${agent_id} already initialized`,
              agent_id,
            }, null, 2),
          },
        ],
      };
    }

    // Each MCP server instance already has its own isolated dataDir via JIYIXITONG_DATA_DIR.
    // Don't nest under agents/<agent_id>/ — use baseDataDir directly.
    const agentDataDir = this.baseDataDir;
    const config: Partial<JiyixitongWanConfig> = {
      ...this.globalConfig,
      dataDir: agentDataDir,
    };

    const memorySystem = new JiyixitongWan(config);
    await memorySystem.ensureReady();

    const context: AgentContext = {
      agentId: agent_id,
      agentName: agent_name,
      sessionId: `${agent_id}-${Date.now()}`,
      permissions,
      metadata,
    };

    const isolatedSystem: IsolatedMemorySystem = {
      agentId: agent_id,
      memorySystem,
      context,
      createdAt: new Date(),
      lastAccessedAt: new Date(),
    };

    this.agentSystems.set(agent_id, isolatedSystem);

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Agent ${agent_name} initialized successfully`,
            agent_id,
            data_dir: agentDataDir,
          }, null, 2),
        },
      ],
    };
  }

  private async handleAgentList() {
    const agents = Array.from(this.agentSystems.entries()).map(([id, system]) => ({
      agent_id: id,
      agent_name: system.context.agentName,
      created_at: system.createdAt.toISOString(),
      last_accessed_at: system.lastAccessedAt.toISOString(),
      permissions: system.context.permissions,
    }));

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({ agents }, null, 2),
        },
      ],
    };
  }

  private async handleAgentCleanup(args: { agent_id: string }) {
    const { agent_id } = args;
    const system = this.agentSystems.get(agent_id);

    if (!system) {
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({ error: `Agent ${agent_id} not found` }, null, 2),
          },
        ],
        isError: true,
      };
    }

    await system.memorySystem.close();
    this.agentSystems.delete(agent_id);

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: `Agent ${agent_id} cleaned up successfully`,
          }, null, 2),
        },
      ],
    };
  }

  private getAgentSystem(agentId: string): IsolatedMemorySystem {
    const system = this.agentSystems.get(agentId);
    if (!system) {
      throw new Error(`Agent ${agentId} not initialized. Call agent_initialize first.`);
    }
    system.lastAccessedAt = new Date();
    return system;
  }

  private async handleMemorySave(args: {
    agent_id: string;
    content: string;
    type?: string;
    cognitive_layer?: string;
    importance?: number;
    tags?: string[];
  }) {
    const { agent_id, content, type, cognitive_layer, importance, tags } = args;
    const system = this.getAgentSystem(agent_id);

    const chunk = await system.memorySystem.save(content, {
      type,
      cognitiveLayer: cognitive_layer,
      importance,
      tags,
    });

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            memory_id: chunk.id,
            content: chunk.content,
            type: chunk.type,
            cognitive_layer: chunk.cognitiveLayer,
          }, null, 2),
        },
      ],
    };
  }

  private async handleMemorySearch(args: {
    agent_id: string;
    query: string;
    max_results?: number;
    min_score?: number;
  }) {
    const { agent_id, query, max_results = 10, min_score = 0.3 } = args;
    const system = this.getAgentSystem(agent_id);

    const results = await system.memorySystem.search_memories(query, {
      maxResults: max_results,
      minScore: min_score,
    });

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            query,
            results_count: results.length,
            results: results.map(r => ({
              id: r.chunk.id,
              content: r.chunk.content,
              type: r.chunk.type,
              score: r.score,
              importance: r.chunk.importance,
            })),
          }, null, 2),
        },
      ],
    };
  }

  private async handleMemoryExtract(args: {
    agent_id: string;
    messages: Array<{ role: string; content: string }>;
    conversation_id: string;
  }) {
    const { agent_id, messages, conversation_id } = args;
    const system = this.getAgentSystem(agent_id);

    const memories = await system.memorySystem.extract(messages, conversation_id);

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            conversation_id,
            extracted_count: memories.length,
            memories: memories.map(m => ({
              id: m.id,
              content: m.content,
              type: m.type,
              cognitive_layer: m.cognitiveLayer,
            })),
          }, null, 2),
        },
      ],
    };
  }

  private async handleMemoryReflect(args: {
    agent_id: string;
    conversation_history?: Array<{ role: string; content: string }>;
  }) {
    const { agent_id, conversation_history = [] } = args;
    const system = this.getAgentSystem(agent_id);

    const reflection = await system.memorySystem.reflect(conversation_history);

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            session_id: reflection.session_id,
            duration_minutes: reflection.duration_minutes,
            memories_consolidated: reflection.memories.length,
            questions_generated: reflection.questions.length,
            identity_update: reflection.identity_update,
          }, null, 2),
        },
      ],
    };
  }

  private async handleMemoryGetQuestions(args: { agent_id: string }) {
    const { agent_id } = args;
    const system = this.getAgentSystem(agent_id);

    const questions = await system.memorySystem.getPendingQuestions();

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            count: questions.length,
            questions: questions.map(q => ({
              id: q.id,
              text: q.text,
              source: q.source,
              date: q.date,
            })),
          }, null, 2),
        },
      ],
    };
  }

  private async handleMemoryGetGrowthReport(args: { agent_id: string }) {
    const { agent_id } = args;
    const system = this.getAgentSystem(agent_id);

    const report = system.memorySystem.getGrowthReport();

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify(report, null, 2),
        },
      ],
    };
  }

  private async handleMemoryRecordTask(args: { agent_id: string; task: any }) {
    const { agent_id, task } = args;
    const system = this.getAgentSystem(agent_id);

    system.memorySystem.recordTask(task);

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            success: true,
            message: 'Task recorded successfully',
            task_id: task.id || 'unknown',
          }, null, 2),
        },
      ],
    };
  }

  private async handleSystemHealth(args: { agent_id?: string }) {
    if (args.agent_id) {
      const system = this.getAgentSystem(args.agent_id);
      const health = await system.memorySystem.getHealth();

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({
              agent_id: args.agent_id,
              ...health,
            }, null, 2),
          },
        ],
      };
    }

    const allHealth = await Promise.all(
      Array.from(this.agentSystems.entries()).map(async ([id, system]) => {
        const health = await system.memorySystem.getHealth();
        return {
          agent_id: id,
          ...health,
        };
      })
    );

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            total_agents: this.agentSystems.size,
            agents: allHealth,
          }, null, 2),
        },
      ],
    };
  }

  private async handleSystemMaintain(args: { agent_id: string }) {
    const { agent_id } = args;
    const system = this.getAgentSystem(agent_id);

    const result = await system.memorySystem.maintain();

    return {
      content: [
        {
          type: 'text',
          text: JSON.stringify({
            agent_id,
            result,
          }, null, 2),
        },
      ],
    };
  }

  async run(): Promise<void> {
    const transport = new StdioServerTransport();

    // StdioServerTransport does NOT emit events on stdin close.
    // Add handlers so the process exits cleanly when the client disconnects.
    process.stdin.on('end', () => {
      console.error('stdin ended, shutting down...');
      this.close();
      process.exit(0);
    });
    process.stdin.on('close', () => {
      console.error('stdin closed, shutting down...');
      this.close();
      process.exit(0);
    });

    await this.server.connect(transport);
    console.error('Jiyixitong MCP Server running on stdio');
  }

  async close(): Promise<void> {
    for (const system of this.agentSystems.values()) {
      await system.memorySystem.close();
    }
    this.agentSystems.clear();
  }
}

export default JiyixitongMcpServer;
