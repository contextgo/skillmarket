import { randomUUID } from 'node:crypto';
import {
  MemoryChunk,
  MemoryType,
  CognitiveLayer,
  Sentiment,
  JiyixitongWanConfig,
} from './types.js';
import { JiyixitongDatabase } from './database.js';

const EXTRACTION_PROMPT = `You extract durable memories from conversations between a user and an AI assistant.

You will receive a condensed version of the conversation (messages may be truncated). Extract what you can from the available text.

CLASSIFY each memory into a cognitive layer:

EPISODIC -- Events tied to a specific moment. Include temporal context when available.
  "User debugged a schema migration and it took most of the session"
  "User was frustrated when the API kept returning 429 errors"

SEMANTIC -- Enduring facts that persist across conversations.
  "User prefers TypeScript over Python"
  "User's dog is named Ellie"
  "User is building a SaaS for trades businesses"

PROCEDURAL -- Rules about how the user wants things done. Patterns, preferences, corrections.
  "Always include error handling in code without being asked"
  "Show the code fix first, then explain the cause"
  "Never use em-dashes in writing"

ASSESS emotional tone of the conversation:
  frustrated -- correcting, re-asking, annoyed
  curious -- exploring, asking follow-ups
  satisfied -- approved, thanked, moved on
  neutral -- standard exchange
  excited -- enthusiastic, building something new
  confused -- needed clarification

RATE importance from 0.0 to 1.0. Be conservative:
  0.9-1.0 -- Core identity (name, primary role, major project)
  0.6-0.8 -- Strong preference or important decision
  0.4-0.5 -- Standard fact or minor preference
  0.2-0.3 -- Situational detail, might not matter later
  0.1 -- Barely worth storing
  Most memories should be 0.3-0.6. Reserve 0.8+ for things that define who the user is.

DO NOT extract:
- Temporary debugging steps or transient state
- File paths or git output (obvious from code context)
- General knowledge the user looked up
- Greetings or small talk
- Things the assistant said (only extract user-provided information)

Return a JSON array. Each item:
{
  "content": "...",
  "type": "fact"|"preference"|"decision"|"context"|"correction"|"commitment"|"moment"|"skill"|"question",
  "cognitiveLayer": "episodic"|"semantic"|"procedural",
  "tags": ["topic1", "topic2"],
  "sentiment": "frustrated"|"curious"|"satisfied"|"neutral"|"excited"|"confused",
  "importance": 0.0-1.0
}

Return [] if nothing worth remembering. Return ONLY valid JSON. No markdown fences.`;

const RECONSOLIDATION_PROMPT = `You are updating a memory based on new context. The original memory was formed earlier. It has just been recalled during a conversation and was useful.

ORIGINAL MEMORY:
{{MEMORY_CONTENT}}

MEMORY TYPE: {{TYPE}} | LAYER: {{COGNITIVE_LAYER}}

CURRENT CONVERSATION CONTEXT (last few messages):
{{RECENT_MESSAGES}}

Rewrite the memory to be more accurate, specific, and useful given this new context. Rules:
- Keep the core fact/preference/rule intact
- Add specificity or nuance from the current context if relevant
- If the current context reveals the memory is partially outdated, update it
- If nothing meaningful can be added, return the original text unchanged
- Keep it concise -- one to two sentences max
- Do NOT add information the user didn't provide
- Do NOT change the cognitive layer or fundamental nature of the memory

Return ONLY the updated memory text. No JSON, no explanation.`;

/**
 * LLM 调用统计和错误处理
 */
interface LLMCallStats {
  totalCalls: number;
  successfulCalls: number;
  failedCalls: number;
  lastError?: string;
  lastErrorTime?: Date;
  averageLatencyMs: number;
}

/**
 * 重试配置
 */
interface RetryConfig {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  backoffMultiplier: number;
}

const DEFAULT_RETRY_CONFIG: RetryConfig = {
  maxRetries: 3,
  baseDelayMs: 1000,
  maxDelayMs: 10000,
  backoffMultiplier: 2,
};

export class MemoryExtractor {
  private storage: JiyixitongDatabase;
  private config: JiyixitongWanConfig;
  private llmProvider?: LLMProvider;
  private callStats: LLMCallStats = {
    totalCalls: 0,
    successfulCalls: 0,
    failedCalls: 0,
    averageLatencyMs: 0,
  };
  private retryConfig: RetryConfig;
  private consecutiveFailures = 0;
  private lastSuccessfulCall: Date | null = null;

  constructor(
    storage: JiyixitongDatabase,
    config: JiyixitongWanConfig,
    llmProvider?: LLMProvider,
    retryConfig?: Partial<RetryConfig>
  ) {
    this.storage = storage;
    this.config = config;
    this.llmProvider = llmProvider;
    this.retryConfig = { ...DEFAULT_RETRY_CONFIG, ...retryConfig };
  }

  setLLMProvider(provider: LLMProvider): void {
    this.llmProvider = provider;
    // 重置失败计数
    this.consecutiveFailures = 0;
  }

  /**
   * 检查 LLM 是否可用
   */
  isLLMAvailable(): boolean {
    if (!this.llmProvider) return false;
    // 如果连续失败超过5次，认为不可用
    if (this.consecutiveFailures >= 5) return false;
    // 如果最后一次成功调用在5分钟前，尝试恢复
    if (this.lastSuccessfulCall) {
      const elapsed = Date.now() - this.lastSuccessfulCall.getTime();
      if (elapsed > 5 * 60 * 1000 && this.consecutiveFailures > 0) {
        // 重置失败计数，允许重试
        this.consecutiveFailures = 0;
      }
    }
    return true;
  }

  async extract(
    messages: Array<{ role: string; content: string }>,
    conversationId: string,
    opts?: { forceExtract?: boolean }
  ): Promise<MemoryChunk[]> {
    const userAssistant = messages.filter((m) => m.role === 'user' || m.role === 'assistant');

    if (!opts?.forceExtract && userAssistant.length < this.config.extraction.threshold) {
      return [];
    }
    if (userAssistant.length === 0) return [];

    const condensed = userAssistant.map((m) => `${m.role}: ${m.content.slice(0, 500)}`).join('\n\n');

    if (condensed.length < 50) return [];

    // 如果 LLM 不可用，使用规则提取
    if (!this.isLLMAvailable()) {
      console.log('[MemoryExtractor] LLM unavailable, using rule-based extraction');
      return this.ruleBasedExtract(condensed, conversationId);
    }

    try {
      const text = await this.callLLMWithRetry(EXTRACTION_PROMPT, condensed, {
        maxTokens: 1000,
        temperature: 0,
      });
      const raw = parseJsonArray(text);
      const validTypes: MemoryType[] = [
        'fact',
        'preference',
        'decision',
        'context',
        'correction',
        'commitment',
        'moment',
        'skill',
        'question',
      ];
      const validLayers: CognitiveLayer[] = ['episodic', 'semantic', 'procedural'];
      const existing = await this.storage.listChunks({ excludeTiers: ['archive'] });
      const chunks: MemoryChunk[] = [];

      for (const r of raw) {
        if (!r.content || !validTypes.includes(r.type)) continue;

        if (this.isDuplicate(r.content, existing)) continue;

        const chunk: MemoryChunk = {
          id: randomUUID(),
          tier: 'short-term',
          content: r.content,
          type: r.type as MemoryType,
          cognitiveLayer: validLayers.includes(r.cognitiveLayer)
            ? (r.cognitiveLayer as CognitiveLayer)
            : 'semantic',
          tags: Array.isArray(r.tags) ? r.tags : [],
          source: conversationId,
          importance: typeof r.importance === 'number' ? Math.min(1, Math.max(0, r.importance)) : 0.5,
          sentiment: (r.sentiment ?? 'neutral') as Sentiment,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          accessedAt: new Date().toISOString(),
          accessCount: 0,
          decayScore: 1.0,
        };

        const savedChunk = await this.storage.save(chunk);
        chunks.push(savedChunk);
      }

      return chunks;
    } catch (error) {
      console.error('[MemoryExtractor] LLM extraction failed:', error);
      // 降级到规则提取
      return this.ruleBasedExtract(condensed, conversationId);
    }
  }

  /**
   * 基于规则的提取（LLM 不可用时的降级方案）
   */
  private async ruleBasedExtract(condensed: string, conversationId: string): Promise<MemoryChunk[]> {
    const chunks: MemoryChunk[] = [];
    const lines = condensed.split('\n');

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.length < 20) continue;

      // 检测记忆触发词
      const memoryTriggers = [
        'remember',
        'important',
        'preference',
        'like',
        'prefer',
        'always',
        'never',
        'decided',
        'choice',
      ];

      const hasTrigger = memoryTriggers.some((trigger) => trimmed.toLowerCase().includes(trigger));

      if (hasTrigger) {
        // 提取用户说的内容
        const userMatch = trimmed.match(/user:\s*(.+)/i);
        if (userMatch) {
          const content = userMatch[1].slice(0, 200);

          // 推断类型
          let type: MemoryType = 'fact';
          if (trimmed.toLowerCase().includes('prefer') || trimmed.toLowerCase().includes('like')) {
            type = 'preference';
          } else if (trimmed.toLowerCase().includes('decided') || trimmed.toLowerCase().includes('choice')) {
            type = 'decision';
          }

          const chunk: MemoryChunk = {
            id: randomUUID(),
            tier: 'short-term',
            content,
            type,
            cognitiveLayer: 'semantic',
            tags: ['rule-based', 'auto-extracted'],
            source: conversationId,
            importance: 0.4,
            sentiment: 'neutral',
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            accessedAt: new Date().toISOString(),
            accessCount: 0,
            decayScore: 1.0,
          };

          chunks.push(chunk);
        }
      }
    }

    // 保存提取的记忆
    const savedChunks: MemoryChunk[] = [];
    for (const chunk of chunks.slice(0, 3)) {
      // 限制数量
      const saved = await this.storage.save(chunk);
      savedChunks.push(saved);
    }

    return Promise.resolve(savedChunks);
  }

  async ingest(
    content: string,
    opts?: {
      type?: MemoryType;
      cognitiveLayer?: CognitiveLayer;
      importance?: number;
      tags?: string[];
      sentiment?: Sentiment;
    }
  ): Promise<MemoryChunk> {
    const chunk: MemoryChunk = {
      id: randomUUID(),
      tier: 'short-term',
      content,
      type: opts?.type ?? 'fact',
      cognitiveLayer: opts?.cognitiveLayer ?? 'semantic',
      tags: opts?.tags ?? [],
      source: 'direct-ingest',
      importance: opts?.importance ?? 0.5,
      sentiment: opts?.sentiment ?? 'neutral',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      accessedAt: new Date().toISOString(),
      accessCount: 0,
      decayScore: 1.0,
    };

    return await this.storage.save(chunk);
  }

  async reconsolidate(
    chunk: MemoryChunk,
    recentMessages: Array<{ role: string; content: string }>
  ): Promise<void> {
    if (chunk.lastRecalledAt) {
      const elapsed = Date.now() - new Date(chunk.lastRecalledAt).getTime();
      if (elapsed < 24 * 60 * 60 * 1000) return;
    }

    const context = recentMessages
      .filter((m) => m.role === 'user' || m.role === 'assistant')
      .slice(-3)
      .map((m) => `${m.role}: ${m.content.slice(0, 400)}`)
      .join('\n');

    if (context.length < 20) return;

    // 如果 LLM 不可用，跳过重新整合
    if (!this.isLLMAvailable()) {
      console.log('[MemoryExtractor] LLM unavailable, skipping reconsolidation');
      return;
    }

    const prompt = RECONSOLIDATION_PROMPT.replace('{{MEMORY_CONTENT}}', chunk.content)
      .replace('{{TYPE}}', chunk.type)
      .replace('{{COGNITIVE_LAYER}}', chunk.cognitiveLayer)
      .replace('{{RECENT_MESSAGES}}', context);

    try {
      const updated = await this.callLLMWithRetry(
        prompt,
        'Update the memory based on the context above.',
        {
          maxTokens: 200,
          temperature: 0,
        }
      );

      const trimmed = updated.trim();
      if (trimmed.length > 0 && trimmed !== chunk.content && trimmed.length < chunk.content.length * 3) {
        await this.storage.updateChunk(chunk.id, {
          content: trimmed,
          updatedAt: new Date().toISOString(),
        });
      }
    } catch (error) {
      console.error('[MemoryExtractor] Reconsolidation failed:', error);
      // 不抛出错误，允许继续
    }
  }

  /**
   * 带重试机制的 LLM 调用
   */
  private async callLLMWithRetry(
    systemPrompt: string,
    userMessage: string,
    opts?: { maxTokens?: number; temperature?: number }
  ): Promise<string> {
    if (!this.llmProvider) {
      throw new Error('LLM provider not set');
    }

    let lastError: Error | undefined;
    let delay = this.retryConfig.baseDelayMs;

    for (let attempt = 0; attempt <= this.retryConfig.maxRetries; attempt++) {
      const startTime = Date.now();

      try {
        const result = await this.llmProvider.complete(systemPrompt, userMessage, opts);

        // 更新统计
        const latency = Date.now() - startTime;
        this.updateStats(true, latency);
        this.consecutiveFailures = 0;
        this.lastSuccessfulCall = new Date();

        return result;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        const latency = Date.now() - startTime;
        this.updateStats(false, latency);

        // 更新连续失败计数
        this.consecutiveFailures++;

        // 如果是最后一次尝试，抛出错误
        if (attempt === this.retryConfig.maxRetries) {
          break;
        }

        // 计算退避延迟
        const jitter = Math.random() * 1000;
        const waitTime = Math.min(delay + jitter, this.retryConfig.maxDelayMs);

        console.log(`[MemoryExtractor] LLM call failed (attempt ${attempt + 1}), retrying in ${waitTime}ms...`);
        await this.sleep(waitTime);

        // 增加延迟
        delay *= this.retryConfig.backoffMultiplier;
      }
    }

    throw lastError || new Error('LLM call failed after retries');
  }

  /**
   * 更新调用统计
   */
  private updateStats(success: boolean, latencyMs: number): void {
    this.callStats.totalCalls++;

    if (success) {
      this.callStats.successfulCalls++;
    } else {
      this.callStats.failedCalls++;
    }

    // 更新平均延迟
    const oldAvg = this.callStats.averageLatencyMs;
    const newAvg = oldAvg + (latencyMs - oldAvg) / this.callStats.totalCalls;
    this.callStats.averageLatencyMs = Math.round(newAvg);
  }

  /**
   * 获取调用统计
   */
  getStats(): LLMCallStats {
    return { ...this.callStats };
  }

  /**
   * 重置统计
   */
  resetStats(): void {
    this.callStats = {
      totalCalls: 0,
      successfulCalls: 0,
      failedCalls: 0,
      averageLatencyMs: 0,
    };
    this.consecutiveFailures = 0;
  }

  private sleep(ms: number): Promise<void> {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  private isDuplicate(content: string, existing: MemoryChunk[]): boolean {
    const normalizedContent = content.toLowerCase().trim();
    for (const chunk of existing) {
      const normalizedChunk = chunk.content.toLowerCase().trim();
      if (normalizedContent === normalizedChunk) return true;
      if (this.cosineSimilarity(normalizedContent, normalizedChunk) > 0.9) return true;
    }
    return false;
  }

  private cosineSimilarity(a: string, b: string): number {
    const aWords = a.split(/\s+/).filter((w) => w.length > 2);
    const bWords = b.split(/\s+/).filter((w) => w.length > 2);
    const intersection = aWords.filter((w) => bWords.includes(w));
    if (intersection.length === 0) return 0;
    return intersection.length / Math.sqrt(aWords.length * bWords.length);
  }
}

export interface LLMProvider {
  complete(
    systemPrompt: string,
    userMessage: string,
    opts?: { maxTokens?: number; temperature?: number }
  ): Promise<string>;
  embed?(text: string): Promise<number[]>;
}

function parseJsonArray(text: string): Array<Record<string, any>> {
  const match = text.match(/\[[\s\S]*?\]/) ?? text.match(/\[[\s\S]*\]/);
  if (!match) return [];
  try {
    return JSON.parse(match[0]);
  } catch {
    const greedy = text.match(/\[[\s\S]*\]/);
    if (greedy) {
      try {
        return JSON.parse(greedy[0]);
      } catch {
        /* noop */
      }
    }
    return [];
  }
}

export { EXTRACTION_PROMPT, RECONSOLIDATION_PROMPT };
