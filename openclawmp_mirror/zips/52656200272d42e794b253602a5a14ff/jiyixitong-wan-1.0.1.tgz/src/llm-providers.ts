import { LLMProvider } from './extractor.js';

/**
 * Ollama LLM Provider
 * 本地运行的免费LLM服务
 * 安装: https://ollama.com/download
 * 默认端口: 11434
 */
export class OllamaProvider implements LLMProvider {
  private baseUrl: string;
  private model: string;
  private embeddingModel: string;

  constructor(options?: {
    baseUrl?: string;
    model?: string;
    embeddingModel?: string;
  }) {
    this.baseUrl = options?.baseUrl ?? 'http://localhost:11434';
    this.model = options?.model ?? 'llama3.2';
    this.embeddingModel = options?.embeddingModel ?? 'shaw/dmeta-embedding-zh:latest';
  }

  async complete(
    systemPrompt: string,
    userMessage: string,
    opts?: { maxTokens?: number; temperature?: number }
  ): Promise<string> {
    const response = await fetch(`${this.baseUrl}/api/generate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.model,
        prompt: `${systemPrompt}\n\n${userMessage}`,
        stream: false,
        options: {
          temperature: opts?.temperature ?? 0.7,
          num_predict: opts?.maxTokens ?? 2048,
        },
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as { response: string };
    return data.response;
  }

  async embed(text: string): Promise<number[]> {
    const response = await fetch(`${this.baseUrl}/api/embeddings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: this.embeddingModel,
        prompt: text,
      }),
    });

    if (!response.ok) {
      throw new Error(`Ollama embedding error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as { embedding: number[] };
    return data.embedding;
  }

  /**
   * 检查Ollama服务是否可用
   */
  async isAvailable(): Promise<boolean> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`, {
        method: 'GET',
        signal: AbortSignal.timeout(5000),
      });
      return response.ok;
    } catch {
      return false;
    }
  }

  /**
   * 获取已安装的模型列表
   */
  async listModels(): Promise<string[]> {
    try {
      const response = await fetch(`${this.baseUrl}/api/tags`);
      if (!response.ok) return [];
      const data = await response.json() as { models?: Array<{ name: string }> };
      return data.models?.map((m) => m.name) ?? [];
    } catch {
      return [];
    }
  }
}

/**
 * OpenAI Compatible Provider
 * 支持OpenAI API格式的服务（如Groq、Together等）
 */
export class OpenAICompatibleProvider implements LLMProvider {
  private baseUrl: string;
  private apiKey: string;
  private model: string;
  private embeddingModel?: string;

  constructor(options: {
    baseUrl: string;
    apiKey: string;
    model: string;
    embeddingModel?: string;
  }) {
    this.baseUrl = options.baseUrl;
    this.apiKey = options.apiKey;
    this.model = options.model;
    this.embeddingModel = options.embeddingModel;
  }

  async complete(
    systemPrompt: string,
    userMessage: string,
    opts?: { maxTokens?: number; temperature?: number }
  ): Promise<string> {
    const response = await fetch(`${this.baseUrl}/chat/completions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        model: this.model,
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: userMessage },
        ],
        max_tokens: opts?.maxTokens ?? 2048,
        temperature: opts?.temperature ?? 0.7,
      }),
    });

    if (!response.ok) {
      throw new Error(`API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as { choices: Array<{ message?: { content?: string } }> };
    return data.choices[0]?.message?.content ?? '';
  }

  async embed(text: string): Promise<number[]> {
    if (!this.embeddingModel) {
      throw new Error('Embedding model not configured');
    }

    const response = await fetch(`${this.baseUrl}/embeddings`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.apiKey}`,
      },
      body: JSON.stringify({
        model: this.embeddingModel,
        input: text,
      }),
    });

    if (!response.ok) {
      throw new Error(`Embedding error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json() as { data: Array<{ embedding?: number[] }> };
    return data.data[0]?.embedding ?? [];
  }
}

/**
 * 预配置的免费服务提供者
 */
export const FreeProviders = {
  /**
   * Groq - 免费高速API（需注册获取API Key）
   * https://console.groq.com
   */
  groq: (apiKey: string) => new OpenAICompatibleProvider({
    baseUrl: 'https://api.groq.com/openai/v1',
    apiKey,
    model: 'llama-3.2-90b-vision-preview',
    embeddingModel: undefined, // Groq暂不支持嵌入
  }),

  /**
   * Together AI - 免费额度（需注册）
   * https://api.together.xyz
   */
  together: (apiKey: string) => new OpenAICompatibleProvider({
    baseUrl: 'https://api.together.xyz/v1',
    apiKey,
    model: 'meta-llama/Llama-3.2-90B-Vision-Instruct-Turbo',
    embeddingModel: 'togethercomputer/m2-bert-80M-8k-retrieval',
  }),

  /**
   * 本地Ollama（无需API Key）
   */
  ollama: (options?: { model?: string; embeddingModel?: string }) => new OllamaProvider({
    model: options?.model ?? 'llama3.2',
    embeddingModel: options?.embeddingModel ?? 'nomic-embed-text',
  }),
};

/**
 * 创建LLM提供者的工厂函数
 * 根据配置自动选择合适的提供者
 */
export function createLLMProvider(config: {
  provider: 'ollama' | 'groq' | 'together' | 'custom';
  apiKey?: string;
  baseUrl?: string;
  model?: string;
  embeddingModel?: string;
}): LLMProvider {
  switch (config.provider) {
    case 'ollama':
      return FreeProviders.ollama({
        model: config.model,
        embeddingModel: config.embeddingModel,
      });

    case 'groq':
      if (!config.apiKey) throw new Error('Groq requires an API key');
      return FreeProviders.groq(config.apiKey);

    case 'together':
      if (!config.apiKey) throw new Error('Together AI requires an API key');
      return FreeProviders.together(config.apiKey);

    case 'custom':
      if (!config.baseUrl || !config.apiKey) {
        throw new Error('Custom provider requires baseUrl and apiKey');
      }
      return new OpenAICompatibleProvider({
        baseUrl: config.baseUrl,
        apiKey: config.apiKey,
        model: config.model ?? 'gpt-4',
        embeddingModel: config.embeddingModel,
      });

    default:
      throw new Error(`Unknown provider: ${config.provider}`);
  }
}