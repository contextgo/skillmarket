import { homedir } from 'node:os';
import * as path from 'node:path';
import {
  JiyixitongWanConfig,
  MemoryChunk,
  SearchResult,
  Reflection,
  Question,
} from './types.js';
import {
  QuantifierStorage,
  IdentityStorage,
  QuestionStorage,
  AuditLog,
  DEFAULT_CONFIG,
} from './storage.js';
import { JiyixitongDatabase } from './database.js';
import { MemoryExtractor, LLMProvider } from './extractor.js';
import { MemorySearch, EnhancedSearchOptions } from './search.js';
import { Reflector } from './reflection.js';
import { Quantifier } from './quantification.js';
import { MaintenanceManager } from './scheduler.js';
import { MemoryMigrator, MigrationReport } from './migration.js';
import { VectorStore } from './vector-store.js';
import { BackupManager, BackupConfig, BackupMetadata } from './backup.js';

// Re-exports
export { OllamaProvider, OpenAICompatibleProvider, FreeProviders, createLLMProvider } from './llm-providers.js';
export { MemoryMigrator } from './migration.js';
export type { MigrationReport } from './migration.js';
export { JiyixitongMcpServer } from './mcp-server.js';
export type { AgentContext, IsolatedMemorySystem } from './mcp-server.js';
export type { LLMProvider } from './extractor.js';
export { VectorStore, SimpleEmbedding } from './vector-store.js';
export { BackupManager } from './backup.js';
export type { BackupConfig, BackupMetadata } from './backup.js';
export type { EnhancedSearchOptions } from './search.js';

/**
 * 增强版记忆系统配置
 */
export interface EnhancedConfig extends Partial<JiyixitongWanConfig> {
  vectorSearch?: {
    enabled: boolean;
    dimension?: number;
  };
  backup?: Partial<BackupConfig>;
  performance?: {
    metricsEnabled: boolean;
    cacheEnabled: boolean;
    cacheTtlSeconds?: number;
  };
}

/**
 * 系统统计信息
 */
export interface SystemStats {
  memories: {
    total: number;
    byType: Record<string, number>;
    byTier: Record<string, number>;
  };
  vectors: {
    totalVectors: number;
    cacheSize: number;
  };
  llm: {
    totalCalls: number;
    successfulCalls: number;
    failedCalls: number;
    averageLatencyMs: number;
    isAvailable: boolean;
  };
  backups: {
    totalBackups: number;
    totalSizeBytes: number;
  };
}

export class JiyixitongWan {
  private storage: JiyixitongDatabase;
  private quantifierStorage: QuantifierStorage;
  private extractor: MemoryExtractor;
  private search: MemorySearch;
  private reflector: Reflector;
  private quantifier: Quantifier;
  private maintenance: MaintenanceManager;
  private vectorStore: VectorStore;
  private backupManager?: BackupManager;
  private config: JiyixitongWanConfig;
  private ready: Promise<void>;
  private performanceMetrics = {
    searchCount: 0,
    extractCount: 0,
    totalSearchLatency: 0,
    totalExtractLatency: 0,
  };

  constructor(config?: EnhancedConfig) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    const dataDir = this.config.dataDir;

    this.storage = new JiyixitongDatabase(this.config);
    this.quantifierStorage = new QuantifierStorage(dataDir);
    this.vectorStore = new VectorStore(dataDir);

    const identity = new IdentityStorage(dataDir);
    const questions = new QuestionStorage(dataDir);
    const audit = new AuditLog(dataDir);

    this.extractor = new MemoryExtractor(this.storage, this.config);
    this.search = new MemorySearch(this.storage, this.config);
    this.reflector = new Reflector(this.storage, identity, questions, audit, this.config);
    this.quantifier = new Quantifier(this.quantifierStorage, identity, audit);
    this.maintenance = new MaintenanceManager(this.storage, dataDir);

    // 初始化备份管理器（如果启用）
    if (config?.backup?.enabled !== false) {
      this.backupManager = new BackupManager(
        dataDir,
        this.storage,
        this.vectorStore,
        config?.backup
      );
    }

    this.ready = this.initialize();
  }

  private async initialize(): Promise<void> {
    await this.storage.initialize();
    
    // 检查是否需要重建向量索引
    const vectorStats = this.vectorStore.getStats();
    const memoryStats = await this.storage.getStats();
    
    if (vectorStats.totalVectors === 0 && memoryStats.total > 0) {
      console.log('[JiyixitongWan] Rebuilding vector index...');
      await this.search.rebuildIndex();
    }
  }

  async ensureReady(): Promise<void> {
    await this.ready;
  }

  async save(content: string, opts?: {
    type?: string;
    cognitiveLayer?: string;
    importance?: number;
    tags?: string[];
  }): Promise<MemoryChunk> {
    await this.ensureReady();
    const chunk = await this.extractor.ingest(content, opts as any);
    
    // 自动索引向量
    await this.search.indexMemory(chunk);
    
    return chunk;
  }

  async search_memories(query: string, opts?: EnhancedSearchOptions): Promise<SearchResult[]> {
    await this.ensureReady();
    const startTime = Date.now();
    
    const results = await this.search.search(query, opts);
    
    // 记录性能指标
    this.performanceMetrics.searchCount++;
    this.performanceMetrics.totalSearchLatency += Date.now() - startTime;
    
    return results;
  }

  async extract(messages: Array<{ role: string; content: string }>, convId: string): Promise<MemoryChunk[]> {
    await this.ensureReady();
    const startTime = Date.now();
    
    const chunks = await this.extractor.extract(messages, convId);
    
    // 自动索引新记忆的向量
    for (const chunk of chunks) {
      await this.search.indexMemory(chunk);
    }
    
    // 记录性能指标
    this.performanceMetrics.extractCount++;
    this.performanceMetrics.totalExtractLatency += Date.now() - startTime;
    
    return chunks;
  }

  async reflect(conversationHistory: Array<{ role: string; content: string }>): Promise<Reflection> {
    await this.ensureReady();
    return this.reflector.reflect(conversationHistory);
  }

  getGrowthReport(): string {
    return this.quantifier.getGrowthReport();
  }

  recordTask(task: any): void {
    this.quantifier.recordTask(task);
  }

  recordLearning(concept: any): void {
    this.quantifier.recordLearning(concept);
  }

  async getPendingQuestions(): Promise<Question[]> {
    return await this.reflector.getPendingQuestions();
  }

  getGreeting(): string {
    return this.reflector.generateGreeting();
  }

  async audit(): Promise<string> {
    await this.ensureReady();
    return this.maintenance.audit();
  }

  async clean(): Promise<{ deleted: number; archived: number }> {
    await this.ensureReady();
    return this.maintenance.clean();
  }

  async maintain(): Promise<string> {
    await this.ensureReady();
    const result = await this.clean();
    
    // 持久化向量
    await this.search['vectorStore'].persistVectors();
    
    return `Maintenance complete: ${result.deleted} deleted, ${result.archived} archived`;
  }

  getHealth(): Promise<{ status: string; score: number; issues: string[]; recommendations: string[] }> {
    return this.maintenance.getHealth();
  }

  getConfig(): JiyixitongWanConfig {
    return this.config;
  }

  /**
   * 设置LLM提供者
   */
  setLLMProvider(provider: LLMProvider): void {
    this.extractor.setLLMProvider(provider);
    this.search.setLLMProvider(provider);
    this.reflector.setLLMProvider(provider);
  }

  /**
   * 迁移原有记忆
   */
  async migrateMemories(sourceDirs: string[]): Promise<MigrationReport> {
    await this.ensureReady();
    
    const dataDir = this.config.dataDir;
    const identity = new IdentityStorage(dataDir);
    const audit = new AuditLog(dataDir);
    
    const migrator = new MemoryMigrator(
      this.storage,
      identity,
      this.quantifierStorage,
      audit,
      dataDir
    );
    
    const result = await migrator.migrateAll(sourceDirs);
    
    // 迁移后重建向量索引
    if (result.migrated > 0) {
      console.log('[JiyixitongWan] Rebuilding index after migration...');
      await this.search.rebuildIndex();
    }
    
    return result;
  }

  /**
   * 创建备份
   */
  async createBackup(): Promise<BackupMetadata> {
    if (!this.backupManager) {
      throw new Error('Backup manager not initialized');
    }
    return this.backupManager.createBackup();
  }

  /**
   * 恢复备份
   */
  async restoreBackup(backupId: string): Promise<void> {
    if (!this.backupManager) {
      throw new Error('Backup manager not initialized');
    }
    await this.backupManager.restoreBackup(backupId);
    // 重新初始化
    this.ready = this.initialize();
    await this.ready;
  }

  /**
   * 列出备份
   */
  async listBackups(): Promise<BackupMetadata[]> {
    if (!this.backupManager) {
      return [];
    }
    return this.backupManager.listBackups();
  }

  /**
   * 导出为JSON
   */
  async exportToJSON(): Promise<string> {
    if (!this.backupManager) {
      throw new Error('Backup manager not initialized');
    }
    return this.backupManager.exportToJSON();
  }

  /**
   * 从JSON导入
   */
  async importFromJSON(filePath: string): Promise<{ imported: number; errors: number }> {
    if (!this.backupManager) {
      throw new Error('Backup manager not initialized');
    }
    const result = await this.backupManager.importFromJSON(filePath);
    // 导入后重建索引
    await this.search.rebuildIndex();
    return result;
  }

  /**
   * 重建向量索引
   */
  async rebuildVectorIndex(): Promise<{ indexed: number; failed: number }> {
    await this.ensureReady();
    return this.search.rebuildIndex();
  }

  /**
   * 获取系统统计信息
   */
  async getStats(): Promise<SystemStats> {
    await this.ensureReady();
    
    const memoryStats = await this.storage.getStats();
    const vectorStats = this.vectorStore.getStats();
    const llmStats = this.extractor.getStats();
    const backupStats = this.backupManager?.getStats();

    return {
      memories: memoryStats,
      vectors: vectorStats,
      llm: {
        ...llmStats,
        isAvailable: this.extractor.isLLMAvailable(),
      },
      backups: backupStats || { totalBackups: 0, totalSizeBytes: 0 },
    };
  }

  /**
   * 获取性能指标
   */
  getPerformanceMetrics(): {
    search: { count: number; averageLatencyMs: number };
    extract: { count: number; averageLatencyMs: number };
  } {
    return {
      search: {
        count: this.performanceMetrics.searchCount,
        averageLatencyMs: this.performanceMetrics.searchCount > 0
          ? Math.round(this.performanceMetrics.totalSearchLatency / this.performanceMetrics.searchCount)
          : 0,
      },
      extract: {
        count: this.performanceMetrics.extractCount,
        averageLatencyMs: this.performanceMetrics.extractCount > 0
          ? Math.round(this.performanceMetrics.totalExtractLatency / this.performanceMetrics.extractCount)
          : 0,
      },
    };
  }

  /**
   * 重置性能指标
   */
  resetPerformanceMetrics(): void {
    this.performanceMetrics = {
      searchCount: 0,
      extractCount: 0,
      totalSearchLatency: 0,
      totalExtractLatency: 0,
    };
    this.extractor.resetStats();
  }

  async close(): Promise<void> {
    // 持久化向量
    await this.search['vectorStore'].persistVectors();
    await this.storage.close();
  }
}

export default JiyixitongWan;
