import * as fs from 'node:fs';
import * as path from 'node:path';
import { JiyixitongDatabase } from './database.js';
import { IdentityStorage, QuantifierStorage, AuditLog } from './storage.js';
import { MemoryChunk, MemoryType, CognitiveLayer, Sentiment, ConfidenceLevel } from './types.js';

/**
 * 记忆迁移器
 * 用于扫描和迁移智能体原有的记忆文件
 */
export class MemoryMigrator {
  private storage: JiyixitongDatabase;
  private identity: IdentityStorage;
  private quantifier: QuantifierStorage;
  private audit: AuditLog;
  private dataDir: string;

  constructor(
    storage: JiyixitongDatabase,
    identity: IdentityStorage,
    quantifier: QuantifierStorage,
    audit: AuditLog,
    dataDir: string
  ) {
    this.storage = storage;
    this.identity = identity;
    this.quantifier = quantifier;
    this.audit = audit;
    this.dataDir = dataDir;
  }

  /**
   * 扫描并迁移所有发现的记忆
   */
  async migrateAll(sourceDirs: string[]): Promise<MigrationReport> {
    const report: MigrationReport = {
      scanned: 0,
      migrated: 0,
      skipped: 0,
      errors: [],
      details: []
    };

    for (const dir of sourceDirs) {
      if (!fs.existsSync(dir)) continue;

      const dirReport = await this.migrateFromDirectory(dir);
      report.scanned += dirReport.scanned;
      report.migrated += dirReport.migrated;
      report.skipped += dirReport.skipped;
      report.errors.push(...dirReport.errors);
      report.details.push(...dirReport.details);
    }

    // 记录审计日志
    this.audit.log({
      timestamp: new Date().toISOString(),
      action: 'CREATE',
      file: 'memory-migration',
      actor: 'MemoryMigrator',
      approval: 'system',
      summary: `Migrated ${report.migrated} memories from ${report.scanned} scanned`
    });

    return report;
  }

  /**
   * 从指定目录迁移记忆
   */
  private async migrateFromDirectory(dir: string): Promise<MigrationReport> {
    const report: MigrationReport = {
      scanned: 0,
      migrated: 0,
      skipped: 0,
      errors: [],
      details: []
    };

    const files = this.scanDirectory(dir);

    for (const file of files) {
      report.scanned++;

      try {
        const result = await this.processFile(file, dir);
        
        if (result.migrated) {
          report.migrated++;
          report.details.push({
            file: file,
            status: 'migrated',
            type: result.type,
            count: result.count
          });
        } else {
          report.skipped++;
          report.details.push({
            file: file,
            status: 'skipped',
            reason: result.reason
          });
        }
      } catch (error) {
        report.errors.push({
          file: file,
          error: error instanceof Error ? error.message : String(error)
        });
      }
    }

    return report;
  }

  /**
   * 扫描目录中的所有记忆文件
   */
  private scanDirectory(dir: string): string[] {
    const files: string[] = [];
    const patterns = [
      '**/*.md',
      '**/*.json',
      '**/*.txt',
      '**/memory*',
      '**/MEMORY*',
      '**/memories*'
    ];

    const scan = (currentDir: string) => {
      try {
        const entries = fs.readdirSync(currentDir, { withFileTypes: true });

        for (const entry of entries) {
          const fullPath = path.join(currentDir, entry.name);

          if (entry.isDirectory()) {
            // 递归扫描子目录，但排除某些目录
            if (!this.shouldSkipDirectory(entry.name)) {
              scan(fullPath);
            }
          } else if (this.isMemoryFile(entry.name)) {
            files.push(fullPath);
          }
        }
      } catch (error) {
        // 忽略无法访问的目录
      }
    };

    scan(dir);
    return files;
  }

  /**
   * 判断是否应该跳过某个目录
   */
  private shouldSkipDirectory(name: string): boolean {
    const skipList = [
      'node_modules',
      '.git',
      '.svn',
      'dist',
      'build',
      'coverage',
      '.cache',
      'temp',
      'tmp'
    ];
    return skipList.includes(name.toLowerCase());
  }

  /**
   * 判断文件是否为记忆文件
   */
  private isMemoryFile(filename: string): boolean {
    const memoryPatterns = [
      /memory/i,
      /memories/i,
      /mem0/i,
      /remember/i,
      /recall/i,
      /context/i,
      /identity/i,
      /soul/i,
      /reflection/i,
      /continuity/i,
      /growth/i,
      /quantified/i,
      /episode/i,
      /semantic/i,
      /procedural/i,
      /core/i,
      /audit/i,
      /decay/i
    ];

    return memoryPatterns.some(pattern => pattern.test(filename));
  }

  /**
   * 处理单个文件
   */
  private async processFile(filePath: string, baseDir: string): Promise<ProcessResult> {
    const content = fs.readFileSync(filePath, 'utf-8');
    const filename = path.basename(filePath);

    // 根据文件类型选择处理方式
    if (filename.endsWith('.json')) {
      return this.processJsonFile(filePath, content);
    } else if (filename.endsWith('.md')) {
      return this.processMarkdownFile(filePath, content);
    } else {
      return this.processTextFile(filePath, content);
    }
  }

  /**
   * 处理 JSON 文件
   */
  private async processJsonFile(filePath: string, content: string): Promise<ProcessResult> {
    try {
      const data = JSON.parse(content);
      const filename = path.basename(filePath);

      // 检测文件类型并迁移
      if (this.isQuantifiedData(data)) {
        await this.migrateQuantifiedData(data);
        return { migrated: true, type: 'quantified', count: 1 };
      } else if (this.isMemoryData(data)) {
        const count = await this.migrateMemoryData(data);
        return { migrated: true, type: 'memory', count };
      } else if (this.isIdentityData(data)) {
        await this.migrateIdentityData(data);
        return { migrated: true, type: 'identity', count: 1 };
      }

      return { migrated: false, reason: 'Unknown JSON structure' };
    } catch {
      return { migrated: false, reason: 'Invalid JSON' };
    }
  }

  /**
   * 处理 Markdown 文件
   */
  private async processMarkdownFile(filePath: string, content: string): Promise<ProcessResult> {
    const filename = path.basename(filePath).toLowerCase();
    let count = 0;

    // 根据文件名判断类型
    if (filename.includes('memory') || filename.includes('memories')) {
      count = await this.extractMemoriesFromMarkdown(content, 'semantic');
    } else if (filename.includes('identity')) {
      await this.extractIdentityFromMarkdown(content);
      count = 1;
    } else if (filename.includes('soul')) {
      await this.extractSoulFromMarkdown(content);
      count = 1;
    } else if (filename.includes('episode')) {
      count = await this.extractMemoriesFromMarkdown(content, 'episodic');
    } else if (filename.includes('procedure')) {
      count = await this.extractMemoriesFromMarkdown(content, 'procedural');
    } else if (filename.includes('reflection')) {
      count = await this.extractReflectionFromMarkdown(content);
    } else {
      // 通用处理：尝试提取所有可能的记忆
      count = await this.extractMemoriesFromMarkdown(content, 'semantic');
    }

    if (count > 0) {
      return { migrated: true, type: 'markdown', count };
    }

    return { migrated: false, reason: 'No extractable content' };
  }

  /**
   * 处理纯文本文件
   */
  private async processTextFile(filePath: string, content: string): Promise<ProcessResult> {
    // 尝试将文本内容作为记忆提取
    const lines = content.split('\n').filter(line => line.trim().length > 10);
    let count = 0;

    for (const line of lines.slice(0, 50)) { // 限制处理前50行
      const chunk: MemoryChunk = {
        id: `migrated-${Date.now()}-${Math.random().toString(36).slice(2)}`,
        tier: 'long-term',
        content: line.trim(),
        type: 'fact',
        cognitiveLayer: 'semantic',
        tags: ['migrated', 'text'],
        source: `migrated:${path.basename(filePath)}`,
        importance: 0.5,
        sentiment: 'neutral',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        accessedAt: new Date().toISOString(),
        accessCount: 0,
        decayScore: 1.0
      };

      await this.storage.save(chunk);
      count++;
    }

    return { migrated: true, type: 'text', count };
  }

  /**
   * 从 Markdown 提取记忆
   */
  private async extractMemoriesFromMarkdown(content: string, layer: CognitiveLayer): Promise<number> {
    const lines = content.split('\n');
    let count = 0;

    for (const line of lines) {
      // 提取列表项作为记忆
      const match = line.match(/^[-*]\s+(.+)$/);
      if (match && match[1].length > 10) {
        const chunk: MemoryChunk = {
          id: `migrated-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          tier: 'long-term',
          content: match[1].trim(),
          type: this.inferMemoryType(match[1]),
          cognitiveLayer: layer,
          tags: ['migrated', 'markdown'],
          source: 'migration',
          importance: this.inferImportance(match[1]),
          sentiment: 'neutral',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          accessedAt: new Date().toISOString(),
          accessCount: 0,
          decayScore: 1.0
        };

        await this.storage.save(chunk);
        count++;
      }
    }

    return count;
  }

  /**
   * 推断记忆类型
   */
  private inferMemoryType(content: string): MemoryType {
    const lower = content.toLowerCase();
    
    if (lower.includes('喜欢') || lower.includes('prefer') || lower.includes('喜爱')) {
      return 'preference';
    } else if (lower.includes('决定') || lower.includes('decided') || lower.includes('选择')) {
      return 'decision';
    } else if (lower.includes('纠正') || lower.includes('correction') || lower.includes('修正')) {
      return 'correction';
    } else if (lower.includes('承诺') || lower.includes('commit') || lower.includes('答应')) {
      return 'commitment';
    } else if (lower.includes('技能') || lower.includes('skill') || lower.includes('学会')) {
      return 'skill';
    } else if (lower.includes('问题') || lower.includes('question') || lower.includes('疑问')) {
      return 'question';
    }

    return 'fact';
  }

  /**
   * 推断重要性
   */
  private inferImportance(content: string): number {
    const lower = content.toLowerCase();
    let importance = 0.5;

    // 关键词提升重要性
    const highImportanceWords = ['重要', '关键', '核心', '永远', '必须', 'critical', 'important', 'key'];
    const lowImportanceWords = ['可能', '也许', '临时', '测试', 'maybe', 'temporary'];

    if (highImportanceWords.some(w => lower.includes(w))) {
      importance = 0.8;
    } else if (lowImportanceWords.some(w => lower.includes(w))) {
      importance = 0.3;
    }

    // 长度也影响重要性
    if (content.length > 100) {
      importance += 0.1;
    }

    return Math.min(1.0, importance);
  }

  /**
   * 检测是否为量化数据
   */
  private isQuantifiedData(data: any): boolean {
    return data && (
      data.growth ||
      data.tasks ||
      data.learning ||
      data.achievements ||
      data.meta?.version?.includes('quantified')
    );
  }

  /**
   * 检测是否为记忆数据
   */
  private isMemoryData(data: any): boolean {
    return data && (
      Array.isArray(data.memories) ||
      Array.isArray(data.chunks) ||
      data.embedding ||
      data.cognitiveLayer
    );
  }

  /**
   * 检测是否为身份数据
   */
  private isIdentityData(data: any): boolean {
    return data && (
      data.core_values ||
      data.self_image ||
      data.capabilities ||
      data.identity
    );
  }

  /**
   * 迁移量化数据
   */
  private async migrateQuantifiedData(data: any): Promise<void> {
    const currentData = this.quantifier.getData();
    
    // 合并数据而不是覆盖
    if (data.growth?.history) {
      currentData.growth.history.push(...data.growth.history);
    }
    
    if (data.tasks?.recent) {
      currentData.tasks.recent.push(...data.tasks.recent);
    }
    
    if (data.learning?.new_concepts) {
      currentData.learning.new_concepts.push(...data.learning.new_concepts);
    }
    
    if (data.achievements?.milestones) {
      currentData.achievements.milestones.push(...data.achievements.milestones);
    }

    this.quantifier.saveData(currentData);
  }

  /**
   * 迁移记忆数据
   */
  private async migrateMemoryData(data: any): Promise<number> {
    let count = 0;
    const memories = data.memories || data.chunks || [data];

    for (const mem of memories) {
      if (mem.content || mem.text || mem.value) {
        const chunk: MemoryChunk = {
          id: mem.id || `migrated-${Date.now()}-${Math.random().toString(36).slice(2)}`,
          tier: mem.tier || 'long-term',
          content: mem.content || mem.text || mem.value || '',
          type: mem.type || 'fact',
          cognitiveLayer: mem.cognitiveLayer || 'semantic',
          tags: [...(mem.tags || []), 'migrated'],
          source: mem.source || 'migration',
          importance: mem.importance || 0.5,
          sentiment: mem.sentiment || 'neutral',
          createdAt: mem.createdAt || new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          accessedAt: new Date().toISOString(),
          accessCount: 0,
          lastRecalledAt: mem.lastRecalledAt || null,
          recallCount: mem.recallCount || 0,
          relatedMemories: mem.relatedMemories || [],
          recallOutcomes: mem.recallOutcomes || [],
          decayScore: mem.decayScore || 1.0
        };

        await this.storage.save(chunk);
        count++;
      }
    }

    return count;
  }

  /**
   * 迁移身份数据
   */
  private async migrateIdentityData(data: any): Promise<void> {
    const currentIdentity = this.identity.getIdentity();
    
    // 合并而不是覆盖
    if (data.core_values) {
      currentIdentity.core_values = [
        ...new Set([...currentIdentity.core_values, ...data.core_values])
      ];
    }
    
    if (data.capabilities) {
      currentIdentity.capabilities = [
        ...new Set([...currentIdentity.capabilities, ...data.capabilities])
      ];
    }
    
    if (data.self_image) {
      for (const [key, values] of Object.entries(data.self_image)) {
        if (Array.isArray(values)) {
          const current = currentIdentity.self_image[key as keyof typeof currentIdentity.self_image] as string[];
          currentIdentity.self_image[key as keyof typeof currentIdentity.self_image] = [
            ...new Set([...current, ...values])
          ] as any;
        }
      }
    }

    this.identity.updateIdentity(currentIdentity);
  }

  /**
   * 从 Markdown 提取身份
   */
  private async extractIdentityFromMarkdown(content: string): Promise<void> {
    // 解析 Markdown 中的身份相关信息
    const lines = content.split('\n');
    const currentIdentity = this.identity.getIdentity();

    for (const line of lines) {
      if (line.startsWith('- ') || line.startsWith('* ')) {
        const value = line.slice(2).trim();
        
        if (value.length > 5) {
          // 根据内容推断类型
          if (value.includes('重视') || value.includes('value') || value.includes('重要')) {
            if (!currentIdentity.core_values.includes(value)) {
              currentIdentity.core_values.push(value);
            }
          } else if (value.includes('能') || value.includes('会') || value.includes('skill')) {
            if (!currentIdentity.capabilities.includes(value)) {
              currentIdentity.capabilities.push(value);
            }
          }
        }
      }
    }

    this.identity.updateIdentity(currentIdentity);
  }

  /**
   * 从 Markdown 提取 Soul/价值观
   */
  private async extractSoulFromMarkdown(content: string): Promise<void> {
    // Soul 通常包含核心价值观，合并到 identity
    await this.extractIdentityFromMarkdown(content);
  }

  /**
   * 从 Markdown 提取反思
   */
  private async extractReflectionFromMarkdown(content: string): Promise<number> {
    // 提取反思中的洞察作为记忆
    return this.extractMemoriesFromMarkdown(content, 'semantic');
  }
}

/**
 * 迁移报告
 */
export interface MigrationReport {
  scanned: number;
  migrated: number;
  skipped: number;
  errors: Array<{ file: string; error: string }>;
  details: Array<{
    file: string;
    status: 'migrated' | 'skipped';
    type?: string;
    count?: number;
    reason?: string;
  }>;
}

/**
 * 处理结果
 */
interface ProcessResult {
  migrated: boolean;
  type?: string;
  count?: number;
  reason?: string;
}
