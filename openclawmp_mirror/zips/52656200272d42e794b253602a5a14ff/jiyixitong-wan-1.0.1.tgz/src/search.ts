import {
  MemoryChunk,
  SearchResult,
  JiyixitongWanConfig,
} from './types.js';
import { JiyixitongDatabase } from './database.js';
import { LLMProvider } from './extractor.js';
import { VectorStore, SimpleEmbedding } from './vector-store.js';

export interface EnhancedSearchOptions {
  maxResults?: number;
  minScore?: number;
  filter?: string;
  useSemantic?: boolean;
  useHybrid?: boolean;
  keywordWeight?: number;
  semanticWeight?: number;
}

export class MemorySearch {
  private storage: JiyixitongDatabase;
  private config: JiyixitongWanConfig;
  private llmProvider?: LLMProvider;
  private vectorStore: VectorStore;
  private simpleEmbedding: SimpleEmbedding;

  constructor(storage: JiyixitongDatabase, config: JiyixitongWanConfig, llmProvider?: LLMProvider) {
    this.storage = storage;
    this.config = config;
    this.llmProvider = llmProvider;
    this.vectorStore = new VectorStore(config.dataDir);
    this.simpleEmbedding = new SimpleEmbedding();
  }

  setLLMProvider(provider: LLMProvider): void {
    this.llmProvider = provider;
  }

  /**
   * 增强搜索：支持关键词、语义和混合搜索
   */
  async search(
    query: string,
    opts?: EnhancedSearchOptions
  ): Promise<SearchResult[]> {
    const options = {
      maxResults: opts?.maxResults ?? this.config.memorySearch.maxResults,
      minScore: opts?.minScore ?? 0.1,
      useSemantic: opts?.useSemantic ?? true,
      useHybrid: opts?.useHybrid ?? true,
      keywordWeight: opts?.keywordWeight ?? 0.3,
      semanticWeight: opts?.semanticWeight ?? 0.7,
    };

    // 1. 关键词搜索
    const keywordResults = await this.keywordSearch(query, options.maxResults);

    // 2. 语义搜索（如果启用）
    let semanticResults: Array<{ memoryId: string; score: number }> = [];
    if (options.useSemantic) {
      semanticResults = await this.semanticSearch(query, options.maxResults);
    }

    // 3. 混合搜索结果
    let finalResults: SearchResult[];
    if (options.useHybrid && options.useSemantic) {
      finalResults = await this.hybridMerge(
        keywordResults,
        semanticResults,
        options.keywordWeight,
        options.semanticWeight,
        options.maxResults
      );
    } else if (semanticResults.length > 0) {
      // 仅语义搜索
      finalResults = await this.semanticToResults(semanticResults);
    } else {
      // 仅关键词搜索
      finalResults = keywordResults;
    }

    // 4. 更新访问统计
    for (const result of finalResults) {
      await this.storage.updateAccess(result.chunk.id);
    }

    // 5. 过滤低分结果
    return finalResults.filter(r => r.score >= options.minScore);
  }

  /**
   * 关键词搜索
   */
  private async keywordSearch(query: string, maxResults: number): Promise<SearchResult[]> {
    const searchTerm = `%${query}%`;
    const rows = await this.storage['db'].all(
      `SELECT * FROM memories 
       WHERE content LIKE ? OR tags LIKE ?
       ORDER BY importance DESC, created_at DESC
       LIMIT ?`,
      [searchTerm, searchTerm, maxResults * 2]
    );

    return rows.map((row: any) => ({
      chunk: this.rowToChunk(row),
      score: row.importance * 0.8 + 0.2,
      matchedTerms: this.extractMatchedTerms(query, row.content),
    }));
  }

  /**
   * 语义搜索
   */
  private async semanticSearch(
    query: string,
    maxResults: number
  ): Promise<Array<{ memoryId: string; score: number }>> {
    try {
      // 获取查询向量
      const queryEmbedding = await this.getQueryEmbedding(query);
      if (!queryEmbedding) return [];

      // 搜索相似向量
      return await this.vectorStore.searchSimilar(queryEmbedding, {
        topK: maxResults,
        minScore: 0.6,
      });
    } catch (error) {
      console.error('Semantic search failed:', error);
      return [];
    }
  }

  /**
   * 混合合并搜索结果
   */
  private async hybridMerge(
    keywordResults: SearchResult[],
    semanticResults: Array<{ memoryId: string; score: number }>,
    keywordWeight: number,
    semanticWeight: number,
    maxResults: number
  ): Promise<SearchResult[]> {
    // 使用向量存储的混合搜索
    const combinedScores = await this.vectorStore.hybridSearch(
      keywordResults,
      semanticResults,
      keywordWeight,
      semanticWeight
    );

    // 获取所有相关记忆的完整数据
    const allIds = Array.from(combinedScores.keys());
    const chunks: MemoryChunk[] = [];
    
    for (const id of allIds) {
      const chunk = await this.storage.getById(id);
      if (chunk) chunks.push(chunk);
    }

    // 按合并分数排序
    const sortedResults = chunks
      .map(chunk => ({
        chunk,
        score: combinedScores.get(chunk.id) || 0,
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, maxResults);

    return sortedResults;
  }

  /**
   * 将语义搜索结果转为 SearchResult
   */
  private async semanticToResults(
    semanticResults: Array<{ memoryId: string; score: number }>
  ): Promise<SearchResult[]> {
    const results: SearchResult[] = [];
    
    for (const { memoryId, score } of semanticResults) {
      const chunk = await this.storage.getById(memoryId);
      if (chunk) {
        results.push({ chunk, score });
      }
    }

    return results;
  }

  /**
   * 获取查询的向量表示
   */
  private async getQueryEmbedding(query: string): Promise<number[] | null> {
    // 优先使用 LLM 提供者
    if (this.llmProvider?.embed) {
      try {
        return await this.llmProvider.embed(query);
      } catch (error) {
        console.warn('LLM embedding failed, falling back to simple embedding:', error);
      }
    }

    // 降级使用简单嵌入
    return this.simpleEmbedding.embed(query);
  }

  /**
   * 为记忆生成并保存向量
   */
  async indexMemory(chunk: MemoryChunk): Promise<void> {
    try {
      const embedding = await this.getQueryEmbedding(chunk.content);
      if (embedding) {
        await this.vectorStore.saveVector(chunk.id, embedding);
      }
    } catch (error) {
      console.error('Failed to index memory:', error);
    }
  }

  /**
   * 批量索引记忆
   */
  async batchIndexMemories(chunks: MemoryChunk[]): Promise<void> {
    for (const chunk of chunks) {
      await this.indexMemory(chunk);
    }
    // 批量保存
    await this.vectorStore.persistVectors();
  }

  /**
   * 提取匹配的关键词
   */
  private extractMatchedTerms(query: string, content: string): string[] {
    const terms = query.toLowerCase().split(/\s+/);
    const contentLower = content.toLowerCase();
    return terms.filter(term => contentLower.includes(term));
  }

  /**
   * 选择最相关的记忆（用于上下文压缩）
   */
  async selectRelevant(query: string, candidates: SearchResult[]): Promise<SearchResult[]> {
    if (candidates.length <= 5) return candidates;

    const manifest = candidates.map((r, i) =>
      `[${i}] (${r.chunk.cognitiveLayer}) ${r.chunk.content.slice(0, 150)}`
    ).join('\n');

    if (this.llmProvider) {
      try {
        const response = await this.llmProvider.complete(
          'You select which memories are most relevant for the user\'s current message. Return ONLY a JSON array of indices, e.g. [0, 2, 4]. Select up to 5 memories. Prefer procedural rules and recent corrections. Skip redundant or tangential memories.',
          `User message: "${query.slice(0, 200)}"\n\nAvailable memories:\n${manifest}`,
          { maxTokens: 50, temperature: 0 }
        );

        const match = response.match(/\[[\d,\s]*\]/);
        if (match) {
          const indices: number[] = JSON.parse(match[0]);
          const selected = indices
            .filter(i => i >= 0 && i < candidates.length)
            .slice(0, 5)
            .map(i => candidates[i]);
          if (selected.length > 0) return selected;
        }
      } catch { /* fall through */ }
    }

    return candidates.slice(0, 5);
  }

  /**
   * 格式化回忆的记忆用于提示词
   */
  formatRecalledMemories(results: SearchResult[]): string {
    if (results.length === 0) return '';

    const procedural = results.filter(r => r.chunk.cognitiveLayer === 'procedural');
    const semantic = results.filter(r => r.chunk.cognitiveLayer === 'semantic');
    const episodic = results.filter(r => r.chunk.cognitiveLayer === 'episodic');

    const sections: string[] = [];

    if (procedural.length > 0) {
      sections.push('## How this user works');
      sections.push(procedural.map(r => `- ${r.chunk.content}`).join('\n'));
    }
    if (semantic.length > 0) {
      sections.push('## Known facts');
      sections.push(semantic.map(r => `- [${r.chunk.type}] ${r.chunk.content}`).join('\n'));
    }
    if (episodic.length > 0) {
      sections.push('## Recent context');
      sections.push(episodic.map(r => `- ${r.chunk.content}`).join('\n'));
    }

    return `\n--- RECALLED MEMORIES ---\n${sections.join('\n\n')}\n`;
  }

  /**
   * 获取搜索统计
   */
  getStats(): { vectorStats: { totalVectors: number; cacheSize: number } } {
    return {
      vectorStats: this.vectorStore.getStats(),
    };
  }

  /**
   * 重建所有向量索引
   */
  async rebuildIndex(): Promise<{ indexed: number; failed: number }> {
    let indexed = 0;
    let failed = 0;

    // 清空现有索引
    await this.vectorStore.clear();

    // 获取所有记忆
    const chunks = await this.storage.listChunks({});

    // 批量索引
    for (const chunk of chunks) {
      try {
        await this.indexMemory(chunk);
        indexed++;
      } catch {
        failed++;
      }
    }

    // 持久化
    await this.vectorStore.persistVectors();

    return { indexed, failed };
  }

  private rowToChunk(row: any): MemoryChunk {
    return {
      id: row.id,
      content: row.content,
      type: row.type,
      cognitiveLayer: row.cognitive_layer,
      importance: row.importance,
      tags: row.tags ? JSON.parse(row.tags) : [],
      source: row.source,
      sentiment: 'neutral',
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      accessedAt: row.accessed_at,
      accessCount: row.access_count,
      tier: row.tier,
      decayScore: row.decay_score,
    };
  }

  private estimateTokens(text: string): number {
    return Math.ceil(text.length / 4);
  }
}

export default MemorySearch;
