import * as fs from 'node:fs';
import * as path from 'node:path';
import { createReadStream, createWriteStream } from 'node:fs';
import { pipeline } from 'node:stream/promises';
import { createGzip, createGunzip } from 'node:zlib';
import { JiyixitongDatabase } from './database.js';
import { VectorStore } from './vector-store.js';

/**
 * 备份配置
 */
export interface BackupConfig {
  enabled: boolean;
  maxBackups: number;
  compression: boolean;
  destination: string;
  includeVectors: boolean;
  includeAuditLog: boolean;
}

/**
 * 备份元数据
 */
export interface BackupMetadata {
  id: string;
  createdAt: string;
  version: string;
  memoryCount: number;
  vectorCount: number;
  compressed: boolean;
  sizeBytes: number;
  checksum: string;
}

/**
 * 备份管理器
 */
export class BackupManager {
  private dataDir: string;
  private config: BackupConfig;
  private db: JiyixitongDatabase;
  private vectorStore: VectorStore;

  constructor(
    dataDir: string,
    db: JiyixitongDatabase,
    vectorStore: VectorStore,
    config?: Partial<BackupConfig>
  ) {
    this.dataDir = dataDir;
    this.db = db;
    this.vectorStore = vectorStore;
    this.config = {
      enabled: true,
      maxBackups: 7,
      compression: true,
      destination: path.join(dataDir, 'backups'),
      includeVectors: true,
      includeAuditLog: true,
      ...config,
    };

    // 确保备份目录存在
    fs.mkdirSync(this.config.destination, { recursive: true });
  }

  /**
   * 创建备份
   */
  async createBackup(): Promise<BackupMetadata> {
    if (!this.config.enabled) {
      throw new Error('Backup is disabled');
    }

    const backupId = `backup-${Date.now()}`;
    const backupDir = path.join(this.config.destination, backupId);
    const timestamp = new Date().toISOString();

    try {
      // 创建备份目录
      fs.mkdirSync(backupDir, { recursive: true });

      // 1. 备份数据库
      const dbBackupPath = path.join(backupDir, 'memory.db');
      await this.copyFile(
        path.join(this.dataDir, 'memory.db'),
        dbBackupPath
      );

      // 2. 备份向量（如果启用）
      let vectorCount = 0;
      if (this.config.includeVectors) {
        const vectorBackupPath = path.join(backupDir, 'vectors.json');
        await this.copyFile(
          path.join(this.dataDir, 'vectors.json'),
          vectorBackupPath
        );
        const stats = this.vectorStore.getStats();
        vectorCount = stats.totalVectors;
      }

      // 3. 备份其他数据文件
      const dataFiles = [
        'identity.md',
        'questions.md',
        'quantified_self.json',
        'audit.log',
      ];

      for (const file of dataFiles) {
        const sourcePath = path.join(this.dataDir, file);
        if (fs.existsSync(sourcePath)) {
          await this.copyFile(sourcePath, path.join(backupDir, file));
        }
      }

      // 4. 创建元数据
      const memoryStats = await this.db.getStats();
      const metadata: BackupMetadata = {
        id: backupId,
        createdAt: timestamp,
        version: '2.0.0',
        memoryCount: memoryStats.total,
        vectorCount,
        compressed: false,
        sizeBytes: this.calculateDirSize(backupDir),
        checksum: await this.calculateChecksum(backupDir),
      };

      fs.writeFileSync(
        path.join(backupDir, 'metadata.json'),
        JSON.stringify(metadata, null, 2)
      );

      // 5. 压缩（如果启用）
      let finalPath = backupDir;
      if (this.config.compression) {
        finalPath = await this.compressBackup(backupDir);
        metadata.compressed = true;
        metadata.sizeBytes = fs.statSync(finalPath).size;

        // 更新元数据
        fs.writeFileSync(
          path.join(backupDir, 'metadata.json'),
          JSON.stringify(metadata, null, 2)
        );

        // 删除未压缩的目录
        fs.rmSync(backupDir, { recursive: true });
      }

      // 6. 清理旧备份
      await this.cleanupOldBackups();

      console.log(`[BackupManager] Backup created: ${backupId}`);
      return metadata;
    } catch (error) {
      // 清理失败的备份
      if (fs.existsSync(backupDir)) {
        fs.rmSync(backupDir, { recursive: true });
      }
      throw error;
    }
  }

  /**
   * 恢复备份
   */
  async restoreBackup(backupId: string): Promise<void> {
    const backupPath = path.join(this.config.destination, backupId);
    const compressedPath = `${backupPath}.gz`;

    let restoreDir = backupPath;

    try {
      // 检查备份是否存在
      if (!fs.existsSync(backupPath) && !fs.existsSync(compressedPath)) {
        throw new Error(`Backup not found: ${backupId}`);
      }

      // 如果是压缩的，先解压
      if (fs.existsSync(compressedPath)) {
        restoreDir = await this.decompressBackup(compressedPath);
      }

      // 验证元数据
      const metadataPath = path.join(restoreDir, 'metadata.json');
      if (!fs.existsSync(metadataPath)) {
        throw new Error('Backup metadata not found');
      }

      const metadata: BackupMetadata = JSON.parse(
        fs.readFileSync(metadataPath, 'utf-8')
      );

      // 验证校验和
      const currentChecksum = await this.calculateChecksum(restoreDir);
      if (currentChecksum !== metadata.checksum) {
        throw new Error('Backup checksum mismatch - data may be corrupted');
      }

      // 关闭当前数据库连接
      await this.db.close();

      // 恢复数据库
      const dbBackupPath = path.join(restoreDir, 'memory.db');
      if (fs.existsSync(dbBackupPath)) {
        fs.copyFileSync(dbBackupPath, path.join(this.dataDir, 'memory.db'));
      }

      // 恢复向量
      const vectorBackupPath = path.join(restoreDir, 'vectors.json');
      if (fs.existsSync(vectorBackupPath)) {
        fs.copyFileSync(vectorBackupPath, path.join(this.dataDir, 'vectors.json'));
      }

      // 恢复其他文件
      const dataFiles = [
        'identity.md',
        'questions.md',
        'quantified_self.json',
        'audit.log',
      ];

      for (const file of dataFiles) {
        const sourcePath = path.join(restoreDir, file);
        if (fs.existsSync(sourcePath)) {
          fs.copyFileSync(sourcePath, path.join(this.dataDir, file));
        }
      }

      console.log(`[BackupManager] Backup restored: ${backupId}`);

      // 如果是临时解压的目录，清理
      if (restoreDir !== backupPath) {
        fs.rmSync(restoreDir, { recursive: true });
      }
    } catch (error) {
      // 清理临时目录
      if (restoreDir !== backupPath && fs.existsSync(restoreDir)) {
        fs.rmSync(restoreDir, { recursive: true });
      }
      throw error;
    }
  }

  /**
   * 列出所有备份
   */
  async listBackups(): Promise<BackupMetadata[]> {
    const backups: BackupMetadata[] = [];

    if (!fs.existsSync(this.config.destination)) {
      return backups;
    }

    const entries = fs.readdirSync(this.config.destination);

    for (const entry of entries) {
      const metadataPath = path.join(
        this.config.destination,
        entry,
        'metadata.json'
      );

      if (fs.existsSync(metadataPath)) {
        try {
          const metadata: BackupMetadata = JSON.parse(
            fs.readFileSync(metadataPath, 'utf-8')
          );
          backups.push(metadata);
        } catch {
          // 跳过损坏的元数据
        }
      }
    }

    // 按时间排序
    return backups.sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  /**
   * 删除备份
   */
  async deleteBackup(backupId: string): Promise<void> {
    const backupPath = path.join(this.config.destination, backupId);
    const compressedPath = `${backupPath}.gz`;

    if (fs.existsSync(backupPath)) {
      fs.rmSync(backupPath, { recursive: true });
    }

    if (fs.existsSync(compressedPath)) {
      fs.unlinkSync(compressedPath);
    }

    console.log(`[BackupManager] Backup deleted: ${backupId}`);
  }

  /**
   * 导出为 JSON 格式
   */
  async exportToJSON(): Promise<string> {
    const chunks = await this.db.listChunks({});
    const exportData = {
      version: '2.0.0',
      exportedAt: new Date().toISOString(),
      memories: chunks,
      vectorStats: this.vectorStore.getStats(),
    };

    const exportPath = path.join(
      this.dataDir,
      `export-${Date.now()}.json`
    );

    fs.writeFileSync(exportPath, JSON.stringify(exportData, null, 2));
    console.log(`[BackupManager] Exported to: ${exportPath}`);

    return exportPath;
  }

  /**
   * 从 JSON 导入
   */
  async importFromJSON(filePath: string): Promise<{ imported: number; errors: number }> {
    if (!fs.existsSync(filePath)) {
      throw new Error(`Import file not found: ${filePath}`);
    }

    const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
    let imported = 0;
    let errors = 0;

    if (data.memories && Array.isArray(data.memories)) {
      for (const memory of data.memories) {
        try {
          await this.db.save(memory);
          imported++;
        } catch {
          errors++;
        }
      }
    }

    console.log(`[BackupManager] Imported ${imported} memories, ${errors} errors`);
    return { imported, errors };
  }

  /**
   * 压缩备份
   */
  private async compressBackup(backupDir: string): Promise<string> {
    const outputPath = `${backupDir}.gz`;
    const archive = archiver('zip', { zlib: { level: 9 } });

    const output = createWriteStream(outputPath);

    await new Promise<void>((resolve, reject) => {
      output.on('close', resolve);
      archive.on('error', reject);
      archive.on('warning', (err: any) => {
        if (err.code === 'ENOENT') {
          console.warn('Archive warning:', err);
        } else {
          reject(err);
        }
      });

      archive.pipe(output);
      archive.directory(backupDir, false);
      archive.finalize();
    });

    return outputPath;
  }

  /**
   * 解压备份
   */
  private async decompressBackup(compressedPath: string): Promise<string> {
    const extract = require('extract-zip');
    const outputDir = compressedPath.replace('.gz', '');

    await extract(compressedPath, { dir: outputDir });

    return outputDir;
  }

  /**
   * 清理旧备份
   */
  private async cleanupOldBackups(): Promise<void> {
    const backups = await this.listBackups();

    if (backups.length > this.config.maxBackups) {
      const toDelete = backups.slice(this.config.maxBackups);

      for (const backup of toDelete) {
        await this.deleteBackup(backup.id);
      }

      console.log(`[BackupManager] Cleaned up ${toDelete.length} old backups`);
    }
  }

  /**
   * 复制文件
   */
  private async copyFile(source: string, destination: string): Promise<void> {
    if (!fs.existsSync(source)) {
      throw new Error(`Source file not found: ${source}`);
    }

    fs.mkdirSync(path.dirname(destination), { recursive: true });
    fs.copyFileSync(source, destination);
  }

  /**
   * 计算目录大小
   */
  private calculateDirSize(dir: string): number {
    let size = 0;
    const entries = fs.readdirSync(dir, { withFileTypes: true });

    for (const entry of entries) {
      const fullPath = path.join(dir, entry.name);
      if (entry.isDirectory()) {
        size += this.calculateDirSize(fullPath);
      } else {
        size += fs.statSync(fullPath).size;
      }
    }

    return size;
  }

  /**
   * 计算校验和
   */
  private async calculateChecksum(dir: string): Promise<string> {
    const crypto = require('crypto');
    const hash = crypto.createHash('md5');

    const entries = fs.readdirSync(dir).sort();

    for (const entry of entries) {
      const fullPath = path.join(dir, entry);
      const stat = fs.statSync(fullPath);

      if (stat.isFile()) {
        const content = fs.readFileSync(fullPath);
        hash.update(content);
      }
    }

    return hash.digest('hex');
  }

  /**
   * 获取备份统计
   */
  getStats(): {
    totalBackups: number;
    totalSizeBytes: number;
    oldestBackup?: string;
    newestBackup?: string;
  } {
    const backups = fs.existsSync(this.config.destination)
      ? fs.readdirSync(this.config.destination)
      : [];

    let totalSize = 0;
    let oldest: Date | undefined;
    let newest: Date | undefined;

    for (const backup of backups) {
      const backupPath = path.join(this.config.destination, backup);
      const stat = fs.statSync(backupPath);
      totalSize += stat.size;

      const date = stat.mtime;
      if (!oldest || date < oldest) oldest = date;
      if (!newest || date > newest) newest = date;
    }

    return {
      totalBackups: backups.length,
      totalSizeBytes: totalSize,
      oldestBackup: oldest?.toISOString(),
      newestBackup: newest?.toISOString(),
    };
  }
}

// 添加 archiver 的导入声明
declare const archiver: any;

export default BackupManager;
