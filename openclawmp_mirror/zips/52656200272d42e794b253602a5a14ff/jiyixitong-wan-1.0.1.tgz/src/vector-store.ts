import * as fs from 'node:fs';
import * as path from 'node:path';
import { MemoryChunk, SearchResult } from './types.js';

/**
 * 向量存储管理器
 * 使用简单的余弦相似度计算实现本地向量搜索
 * 未来可迁移到 sqlite-vss 或专用向量数据库
 */
export class VectorStore {
  private dataDir: string;
  private vectorCache: Map<string, number[]> = new Map();
  private cacheDirty = false;
  private readonly vectorFile = 'vectors.json';

  constructor(dataDir: string) {
    this.dataDir = dataDir;
    this.loadVectors();
  }

  /**
   * 保存向量到缓存
   */
  async saveVector(memoryId: string, embedding: number[]): Promise<void> {
    this.vectorCache.set(memoryId, embedding);
    this.cacheDirty = true;
    
    // 批量保存，每10次写入一次
    if (this.vectorCache.size % 10 === 0) {
      await this.persistVectors();
    }
  }

  /**
   * 获取向量
   */
  getVector(memoryId: string): number[] | undefined {
    return this.vectorCache.get(memoryId);
  }

  /**
   * 删除向量
   */
  async deleteVector(memoryId: string): Promise<void> {
    this.vectorCache.delete(memoryId);
    this.cacheDirty = true;
  }

  /**
   * 语义搜索 - 使用余弦相似度
   */
  async searchSimilar(
    queryEmbedding: number[],
    options?: {
      topK?: number;
      minScore?: number;
      filter?: (memoryId: string) => boolean;
    }
  ): Promise<Array<{ memoryId: string; score: number }>> {
    const topK = options?.topK || 10;
    const minScore = options?.minScore || 0.7;
    const filter = options?.filter;

    const scores: Array<{ memoryId: string; score: number }> = [];

    for (const [memoryId, embedding] of this.vectorCache.entries()) {
      // 应用过滤器
      if (filter && !filter(memoryId)) continue;

      // 计算余弦相似度
      const score = this.cosineSimilarity(queryEmbedding, embedding);
      
      if (score >= minScore) {
        scores.push({ memoryId, score });
      }
    }

    // 按相似度排序并返回前K个
    return scores
      .sort((a, b) => b.score - a.score)
      .slice(0, topK);
  }

  /**
   * 混合搜索：结合关键词和语义搜索
   */
  async hybridSearch(
    keywordResults: SearchResult[],
    semanticResults: Array<{ memoryId: string; score: number }>,
    keywordWeight = 0.3,
    semanticWeight = 0.7
  ): Promise<Map<string, number>> {
    const combinedScores = new Map<string, number>();

    // 归一化关键词搜索分数
    const maxKeywordScore = Math.max(...keywordResults.map(r => r.score), 1);
    for (const result of keywordResults) {
      const normalizedScore = result.score / maxKeywordScore;
      combinedScores.set(
        result.chunk.id,
        (combinedScores.get(result.chunk.id) || 0) + normalizedScore * keywordWeight
      );
    }

    // 添加语义搜索分数
    for (const result of semanticResults) {
      combinedScores.set(
        result.memoryId,
        (combinedScores.get(result.memoryId) || 0) + result.score * semanticWeight
      );
    }

    return combinedScores;
  }

  /**
   * 获取统计信息
   */
  getStats(): { totalVectors: number; cacheSize: number } {
    return {
      totalVectors: this.vectorCache.size,
      cacheSize: this.estimateCacheSize(),
    };
  }

  /**
   * 清空所有向量
   */
  async clear(): Promise<void> {
    this.vectorCache.clear();
    this.cacheDirty = true;
    await this.persistVectors();
  }

  /**
   * 持久化向量到磁盘
   */
  async persistVectors(): Promise<void> {
    if (!this.cacheDirty) return;

    const vectorPath = path.join(this.dataDir, this.vectorFile);
    const data = Object.fromEntries(this.vectorCache);
    
    fs.mkdirSync(this.dataDir, { recursive: true });
    fs.writeFileSync(vectorPath, JSON.stringify(data, null, 2));
    
    this.cacheDirty = false;
  }

  /**
   * 从磁盘加载向量
   */
  private loadVectors(): void {
    const vectorPath = path.join(this.dataDir, this.vectorFile);
    
    if (fs.existsSync(vectorPath)) {
      try {
        const data = JSON.parse(fs.readFileSync(vectorPath, 'utf-8'));
        this.vectorCache = new Map(Object.entries(data));
      } catch (error) {
        console.error('Failed to load vectors:', error);
        this.vectorCache = new Map();
      }
    }
  }

  /**
   * 计算余弦相似度
   */
  private cosineSimilarity(a: number[], b: number[]): number {
    if (a.length !== b.length) {
      throw new Error('Vectors must have the same dimension');
    }

    let dotProduct = 0;
    let normA = 0;
    let normB = 0;

    for (let i = 0; i < a.length; i++) {
      dotProduct += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }

    if (normA === 0 || normB === 0) return 0;

    return dotProduct / (Math.sqrt(normA) * Math.sqrt(normB));
  }

  /**
   * 估算缓存大小（MB）
   */
  private estimateCacheSize(): number {
    let total = 0;
    for (const [key, value] of this.vectorCache.entries()) {
      total += key.length * 2; // 字符串大致大小
      total += value.length * 8; // float64 大小
    }
    return Math.round((total / 1024 / 1024) * 100) / 100;
  }
}

/**
 * 简单的文本向量化（基于词频）
 * 用于 LLM 不可用时降级使用
 */
export class SimpleEmbedding {
  private vocabulary: Map<string, number> = new Map();
  private readonly dimension = 128;

  /**
   * 生成简单文本向量
   * 基于字符 n-gram 的哈希
   */
  embed(text: string): number[] {
    const vector = new Array(this.dimension).fill(0);
    const normalized = text.toLowerCase().trim();
    
    // 使用 3-gram
    for (let i = 0; i < normalized.length - 2; i++) {
      const trigram = normalized.slice(i, i + 3);
      const hash = this.hashString(trigram);
      const index = hash % this.dimension;
      vector[index] += 1;
    }

    // 归一化
    const norm = Math.sqrt(vector.reduce((sum, val) => sum + val * val, 0));
    if (norm > 0) {
      return vector.map(v => v / norm);
    }

    return vector;
  }

  /**
   * 批量生成向量
   */
  embedBatch(texts: string[]): number[][] {
    return texts.map(t => this.embed(t));
  }

  /**
   * 简单的字符串哈希
   */
  private hashString(str: string): number {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      const char = str.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash; // 转为 32bit
    }
    return Math.abs(hash);
  }
}

export default VectorStore;
