import { QuantifierStorage, IdentityStorage, AuditLog } from './storage.js';
import { ConceptRecord, TaskRecord, AchievementRecord, GoalRecord } from './types.js';

export class Quantifier {
  private storage: QuantifierStorage;
  private identity: IdentityStorage;
  private audit: AuditLog;

  constructor(storage: QuantifierStorage, identity: IdentityStorage, audit: AuditLog) {
    this.storage = storage;
    this.identity = identity;
    this.audit = audit;
  }

  recordTask(task: TaskRecord): void {
    const data = this.storage.getData();
    
    data.tasks.total++;
    if (task.status === 'completed') {
      data.tasks.completed++;
    } else if (task.status === 'in_progress') {
      data.tasks.in_progress++;
    } else if (task.status === 'failed') {
      data.tasks.failed++;
    }
    
    data.tasks.by_type[task.type] = (data.tasks.by_type[task.type] || 0) + 1;
    data.tasks.recent.push(task);
    
    if (data.tasks.recent.length > 50) {
      data.tasks.recent.shift();
    }
    
    this.storage.saveData(data);

    if (task.status === 'completed' && task.quality_score >= 8) {
      this.recordAchievement({
        id: `task-${Date.now()}`,
        type: 'highlight',
        title: `Completed: ${task.title}`,
        description: `Finished with quality score ${task.quality_score}`,
        timestamp: new Date().toISOString(),
        icon: '✨',
        related_tasks: [task.id],
        impact: task.quality_score >= 9 ? 'high' : 'medium',
      });
    }

    this.audit.log({
      timestamp: new Date().toISOString(),
      action: 'EDIT',
      file: 'quantified_self.json',
      actor: 'Quantifier',
      approval: 'system',
      summary: `Task recorded: ${task.type} - ${task.status}`,
    });
  }

  recordLearning(concept: ConceptRecord): void {
    const data = this.storage.getData();
    
    data.learning.new_concepts.push(concept);
    data.learning.total_concepts++;
    data.learning.by_category[concept.category] = (data.learning.by_category[concept.category] || 0) + 1;
    
    this.storage.saveData(data);

    this.audit.log({
      timestamp: new Date().toISOString(),
      action: 'EDIT',
      file: 'quantified_self.json',
      actor: 'Quantifier',
      approval: 'system',
      summary: `Learning recorded: ${concept.name} (${concept.category})`,
    });
  }

  recordAchievement(achievement: AchievementRecord): void {
    const data = this.storage.getData();
    
    if (achievement.type === 'milestone') {
      data.achievements.milestones.push(achievement);
    } else if (achievement.type === 'highlight') {
      data.achievements.highlights.push(achievement);
    } else if (achievement.type === 'breakthrough') {
      data.achievements.breakthroughs.push(achievement);
    }
    
    data.achievements.total_count++;
    
    this.storage.saveData(data);
    this.updateGrowth({ knowledge_coverage: 1 });

    this.audit.log({
      timestamp: new Date().toISOString(),
      action: 'EDIT',
      file: 'quantified_self.json',
      actor: 'Quantifier',
      approval: 'system',
      summary: `Achievement: ${achievement.title}`,
    });
  }

  updateGrowth(metrics: Partial<{
    overall: number;
    knowledge_coverage: number;
    capability_depth: number;
    response_quality: number;
    task_efficiency: number;
  }>): void {
    const data = this.storage.getData();
    const current = data.growth.current;
    const prevOverall = current.overall;

    Object.assign(current, metrics);

    current.knowledge_coverage = Math.min(100, Math.max(0, current.knowledge_coverage));
    current.capability_depth = Math.min(100, Math.max(0, current.capability_depth));
    current.response_quality = Math.min(100, Math.max(0, current.response_quality));
    current.task_efficiency = Math.min(100, Math.max(0, current.task_efficiency));
    current.overall = (
      current.knowledge_coverage * 0.3 +
      current.capability_depth * 0.3 +
      current.response_quality * 0.2 +
      current.task_efficiency * 0.2
    );

    const baseline = data.growth.baseline;
    const growth = data.growth.growth_percent;

    growth.overall = ((current.overall - baseline.overall) / baseline.overall) * 100;
    growth.knowledge_coverage = ((current.knowledge_coverage - baseline.knowledge_coverage) / baseline.knowledge_coverage) * 100;
    growth.capability_depth = ((current.capability_depth - baseline.capability_depth) / baseline.capability_depth) * 100;
    growth.response_quality = ((current.response_quality - baseline.response_quality) / baseline.response_quality) * 100;
    growth.task_efficiency = ((current.task_efficiency - baseline.task_efficiency) / baseline.task_efficiency) * 100;

    if (Math.abs(current.overall - prevOverall) >= 1) {
      data.growth.history.push({
        timestamp: new Date().toISOString(),
        overall: current.overall,
        conversation_count: data.tasks.total,
        notes: 'Regular growth update',
      });
    }

    this.storage.saveData(data);
  }

  getGrowthReport(): string {
    const data = this.storage.getData();
    const growth = data.growth;
    
    let report = '# Growth Report\n\n';
    report += `_Generated: ${new Date().toISOString()}_\n\n`;
    
    report += '## Overall Growth\n';
    report += `- Current: **${growth.current.overall.toFixed(1)}**%\n`;
    report += `- Baseline: **${growth.baseline.overall.toFixed(1)}**%\n`;
    report += `- Growth: **${growth.growth_percent.overall.toFixed(1)}**%\n\n`;
    
    report += '## Key Metrics\n';
    report += `- Knowledge Coverage: ${growth.current.knowledge_coverage.toFixed(1)}% (${growth.growth_percent.knowledge_coverage.toFixed(1)}%)\n`;
    report += `- Capability Depth: ${growth.current.capability_depth.toFixed(1)}% (${growth.growth_percent.capability_depth.toFixed(1)}%)\n`;
    report += `- Response Quality: ${growth.current.response_quality.toFixed(1)}% (${growth.growth_percent.response_quality.toFixed(1)}%)\n`;
    report += `- Task Efficiency: ${growth.current.task_efficiency.toFixed(1)}% (${growth.growth_percent.task_efficiency.toFixed(1)}%)\n\n`;
    
    report += `## Activity Stats\n`;
    report += `- Total Tasks: ${data.tasks.total}\n`;
    report += `- Completed: ${data.tasks.completed}\n`;
    report += `- In Progress: ${data.tasks.in_progress}\n`;
    report += `- Failed: ${data.tasks.failed}\n`;
    report += `- Learning Concepts: ${data.learning.total_concepts}\n`;
    report += `- Achievements: ${data.achievements.total_count}\n`;
    
    return report;
  }

  calculateCompletionRate(): number {
    const data = this.storage.getData();
    const { total, completed } = data.tasks;
    return total > 0 ? (completed / total) * 100 : 0;
  }

  getRecentActivity(days: number = 7): { tasks: TaskRecord[]; learning: ConceptRecord[] } {
    const data = this.storage.getData();
    const cutoff = new Date(Date.now() - days * 24 * 60 * 60 * 1000).toISOString();
    
    return {
      tasks: data.tasks.recent.filter(t => t.started_at >= cutoff),
      learning: data.learning.new_concepts.filter(c => c.first_learned_at >= cutoff),
    };
  }

  exportData(): any {
    return this.storage.getData();
  }

  importData(data: any): void {
    this.storage.saveData(data);
  }
}

export default Quantifier;
