import { open } from 'sqlite';
import sqlite3 from 'sqlite3';
import * as fs from 'node:fs';
import * as path from 'node:path';
import { JiyixitongWanConfig, MemoryChunk, MemoryType, CognitiveLayer, SearchOptions, SearchResult } from './types.js';

export class JiyixitongDatabase {
  private db: any = null;
  private config: JiyixitongWanConfig;
  private dbPath: string;

  constructor(config: JiyixitongWanConfig) {
    this.config = config;
    this.dbPath = path.join(config.dataDir, 'memory.db');
  }

  async initialize(): Promise<void> {
    if (!fs.existsSync(this.config.dataDir)) {
      fs.mkdirSync(this.config.dataDir, { recursive: true });
    }

    this.db = await open({
      filename: this.dbPath,
      driver: sqlite3.Database
    });

    await this.createTables();
  }

  private async createTables(): Promise<void> {
    await this.db!.run(`
      CREATE TABLE IF NOT EXISTS memories (
        id TEXT PRIMARY KEY,
        content TEXT NOT NULL,
        type TEXT NOT NULL,
        cognitive_layer TEXT NOT NULL,
        importance REAL DEFAULT 0.5,
        tags TEXT DEFAULT '[]',
        source TEXT DEFAULT '',
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        accessed_at TEXT NOT NULL,
        access_count INTEGER DEFAULT 0,
        tier TEXT DEFAULT 'short-term',
        decay_score REAL DEFAULT 1.0
      )
    `);

    await this.db!.run(`
      CREATE INDEX IF NOT EXISTS idx_memories_type ON memories(type)
    `);

    await this.db!.run(`
      CREATE INDEX IF NOT EXISTS idx_memories_cognitive_layer ON memories(cognitive_layer)
    `);

    await this.db!.run(`
      CREATE INDEX IF NOT EXISTS idx_memories_tier ON memories(tier)
    `);

    await this.db!.run(`
      CREATE INDEX IF NOT EXISTS idx_memories_created_at ON memories(created_at)
    `);
  }

  async save(chunk: MemoryChunk): Promise<MemoryChunk> {
    const now = new Date().toISOString();
    const id = chunk.id || `memory-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    
    await this.db!.run(
      `INSERT INTO memories (id, content, type, cognitive_layer, importance, tags, source, created_at, updated_at, accessed_at, access_count, tier, decay_score)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        chunk.content,
        chunk.type,
        chunk.cognitiveLayer,
        chunk.importance || 0.5,
        JSON.stringify(chunk.tags || []),
        chunk.source || '',
        now,
        now,
        now,
        0,
        chunk.tier || 'short-term',
        1.0
      ]
    );

    return {
      ...chunk,
      id,
      createdAt: now,
      updatedAt: now,
      accessedAt: now,
      accessCount: 0,
      tier: chunk.tier || 'short-term',
      decayScore: 1.0
    };
  }

  async getById(id: string): Promise<MemoryChunk | null> {
    const row = await this.db!.get(`SELECT * FROM memories WHERE id = ?`, [id]);
    if (!row) return null;

    return this.rowToChunk(row);
  }

  async listChunks(options?: { limit?: number; offset?: number; excludeTiers?: string[] }): Promise<MemoryChunk[]> {
    const limit = options?.limit || 100;
    const offset = options?.offset || 0;
    const excludeTiers = options?.excludeTiers || [];

    let query = `SELECT * FROM memories WHERE 1=1`;
    const params: any[] = [];

    if (excludeTiers.length > 0) {
      query += ` AND tier NOT IN (${excludeTiers.map(() => '?').join(',')})`;
      params.push(...excludeTiers);
    }

    query += ` ORDER BY created_at DESC LIMIT ? OFFSET ?`;
    params.push(limit, offset);

    const rows = await this.db!.all(query, params);
    return rows.map((row: any) => this.rowToChunk(row));
  }

  async updateChunk(id: string, updates: Partial<MemoryChunk>): Promise<void> {
    const fields: string[] = [];
    const values: any[] = [];

    if (updates.content !== undefined) {
      fields.push('content = ?');
      values.push(updates.content);
    }
    if (updates.type !== undefined) {
      fields.push('type = ?');
      values.push(updates.type);
    }
    if (updates.cognitiveLayer !== undefined) {
      fields.push('cognitive_layer = ?');
      values.push(updates.cognitiveLayer);
    }
    if (updates.importance !== undefined) {
      fields.push('importance = ?');
      values.push(updates.importance);
    }
    if (updates.tags !== undefined) {
      fields.push('tags = ?');
      values.push(JSON.stringify(updates.tags));
    }
    if (updates.source !== undefined) {
      fields.push('source = ?');
      values.push(updates.source);
    }
    if (updates.tier !== undefined) {
      fields.push('tier = ?');
      values.push(updates.tier);
    }
    if (updates.decayScore !== undefined) {
      fields.push('decay_score = ?');
      values.push(updates.decayScore);
    }

    fields.push('updated_at = ?');
    values.push(new Date().toISOString());

    if (updates.accessCount !== undefined) {
      fields.push('access_count = ?');
      values.push(updates.accessCount);
    }
    if (updates.accessedAt !== undefined) {
      fields.push('accessed_at = ?');
      values.push(updates.accessedAt);
    }

    values.push(id);

    await this.db!.run(
      `UPDATE memories SET ${fields.join(', ')} WHERE id = ?`,
      values
    );
  }

  async deleteChunk(id: string): Promise<void> {
    await this.db!.run(`DELETE FROM memories WHERE id = ?`, [id]);
  }

  async search(query: string, embedding?: number[], options?: SearchOptions): Promise<SearchResult[]> {
    const maxResults = options?.maxResults || 20;
    const minScore = options?.minScore || 0.3;

    const searchTerm = `%${query}%`;
    const rows = await this.db!.all(
      `SELECT * FROM memories 
       WHERE content LIKE ? OR tags LIKE ?
       ORDER BY importance DESC, created_at DESC
       LIMIT ?`,
      [searchTerm, searchTerm, maxResults]
    );

    const results = rows.map((row: any) => ({
      chunk: this.rowToChunk(row),
      score: row.importance * 0.8 + 0.2
    }));

    return results.filter((r: SearchResult) => r.score >= minScore);
  }

  async updateAccess(id: string): Promise<void> {
    const now = new Date().toISOString();
    await this.db!.run(
      `UPDATE memories SET access_count = access_count + 1, accessed_at = ? WHERE id = ?`,
      [now, id]
    );
  }

  async getStats(): Promise<{ total: number; byType: Record<string, number>; byTier: Record<string, number> }> {
    const total = await this.db!.get(`SELECT COUNT(*) as count FROM memories`);
    
    const byType = await this.db!.all(`SELECT type, COUNT(*) as count FROM memories GROUP BY type`);
    const byTier = await this.db!.all(`SELECT tier, COUNT(*) as count FROM memories GROUP BY tier`);

    return {
      total: (total as any).count as number,
      byType: byType.reduce((acc: Record<string, number>, row: any) => ({ ...acc, [row.type]: row.count }), {}),
      byTier: byTier.reduce((acc: Record<string, number>, row: any) => ({ ...acc, [row.tier]: row.count }), {})
    };
  }

  async close(): Promise<void> {
    if (this.db) {
      await this.db.close();
      this.db = null;
    }
  }

  private rowToChunk(row: any): MemoryChunk {
    return {
      id: row.id,
      content: row.content,
      type: row.type as MemoryType,
      cognitiveLayer: row.cognitive_layer as CognitiveLayer,
      importance: row.importance,
      tags: row.tags ? JSON.parse(row.tags) : [],
      source: row.source,
      sentiment: 'neutral', // 默认值
      createdAt: row.created_at,
      updatedAt: row.updated_at,
      accessedAt: row.accessed_at,
      accessCount: row.access_count,
      tier: row.tier,
      decayScore: row.decay_score
    };
  }
}

export default JiyixitongDatabase;
