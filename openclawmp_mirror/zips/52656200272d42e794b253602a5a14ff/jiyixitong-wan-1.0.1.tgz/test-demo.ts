import { JiyixitongWan } from './dist/index.js';

async function test() {
  const jyx = new JiyixitongWan();
  await jyx.ensureReady();

  console.log('\n=== 测试1: 保存记忆 ===\n');
  
  // 保存几条记忆
  await jyx.save('用户叫lujane，是老板', { type: 'fact', importance: 0.9 });
  await jyx.save('用户偏好早报需要多搜索引擎交叉验证', { type: 'preference', importance: 0.95 });
  await jyx.save('用户时区是Asia/Shanghai', { type: 'context', importance: 0.7 });
  await jyx.save('2026-04-07 配置了24个定时任务', { type: 'decision', importance: 0.8 });
  
  console.log('✅ 已保存4条记忆');

  console.log('\n=== 测试2: 搜索记忆 ===\n');
  
  const results = await jyx.search_memories('用户偏好', { maxResults: 5 });
  console.log(`搜索"用户偏好"找到 ${results.length} 条记忆:`);
  results.forEach((r, i) => {
    console.log(`  ${i+1}. [${r.chunk.type}] ${r.chunk.content} (分数: ${r.score.toFixed(2)})`);
  });

  console.log('\n=== 测试3: 成长报告 ===\n');
  console.log(jyx.getGrowthReport());

  console.log('\n=== 测试4: 系统健康状态 ===\n');
  const health = await jyx.getHealth();
  console.log(`状态: ${health.status} (${health.score}/100)`);

  jyx.close();
  console.log('\n✅ 所有测试完成！\n');
}

test().catch(console.error);