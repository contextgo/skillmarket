---
name: doc-to-speech
description: 将电脑里的Word、PDF、TXT等文档转换为MP3语音文件，让用户可以听文档内容，缓解视觉疲劳。支持批量转换、语音选择、语速调节。当用户需要听文档、将文章转为音频、批量转换文档为声音文件时启用。
---

# 文档转语音 (Doc to Speech)

将Word、PDF、TXT等文档转换为MP3音频文件，让用户可以"听"文档内容，缓解视觉疲劳。

## 功能特性

- **多格式支持**: Word (.docx)、PDF (.pdf)、TXT (.txt)、Markdown (.md) 等
- **批量转换**: 支持同时转换多个文件或整个文件夹
- **语音选择**: 可选择不同的语音和语速
- **离线/在线**: 支持离线TTS (pyttsx3) 和在线TTS (Google TTS)
- **中文支持**: 完整支持中文文档朗读

## 使用场景

- 长时间阅读导致眼睛疲劳，想听文档内容
- 通勤路上想"听"文章或报告
- 需要批量将文档转为有声书
- 视力不便的用户需要语音辅助阅读

## 快速开始

### 1. 安装依赖

首次使用前，安装必要的依赖库：

```bash
python scripts/install_dependencies.py
```

或手动安装：
```bash
pip install docx2txt pdfplumber PyPDF2 pyttsx3 gtts
```

### 2. 转换单个文件

```bash
# 基本用法
python scripts/doc_to_speech.py 文档.docx

# 指定输出路径
python scripts/doc_to_speech.py 文档.docx -o 输出.mp3

# 调整语速
python scripts/doc_to_speech.py 文档.pdf -r 120

# 使用Google TTS（在线，质量更好）
python scripts/doc_to_speech.py 文档.txt -e gtts
```

### 3. 批量转换

```bash
# 转换多个文件
python scripts/doc_to_speech.py 文件1.docx 文件2.pdf 文件3.txt

# 转换整个文件夹
python scripts/doc_to_speech.py ./文档文件夹/ -o ./输出音频/
```

### 4. 查看可用语音

```bash
python scripts/doc_to_speech.py --list-voices
```

## 参数说明

| 参数 | 说明 | 示例 |
|------|------|------|
| `input` | 输入文件或文件夹路径 | `文档.docx` |
| `-o, --output` | 输出路径 | `-o 音频.mp3` |
| `-e, --engine` | TTS引擎 (`pyttsx3` 或 `gtts`) | `-e pyttsx3` |
| `-v, --voice` | 语音ID | `-v 0` |
| `-r, --rate` | 语速 (默认150) | `-r 120` |
| `-l, --lang` | 语言代码 (gtts用) | `-l zh-cn` |
| `--list-voices` | 列出可用语音 | `--list-voices` |

## 工作流程

当用户需要将文档转为语音时：

1. **确认需求**: 了解用户要转换的文件、输出要求
2. **检查依赖**: 确保必要库已安装
3. **执行转换**: 运行转换脚本
4. **验证结果**: 确认MP3文件生成成功

## 技术说明

### 支持的文档格式

- **Word (.docx)**: 使用 `docx2txt` 提取文本
- **PDF (.pdf)**: 使用 `pdfplumber` 或 `PyPDF2` 提取文本
- **文本 (.txt, .md)**: 直接读取，自动检测编码

### TTS引擎对比

| 引擎 | 类型 | 优点 | 缺点 |
|------|------|------|------|
| pyttsx3 | 离线 | 无需网络，响应快，免费 | 语音质量一般 |
| gTTS | 在线 | 语音质量高，自然流畅 | 需要网络，有请求限制 |

### 注意事项

- 长文档会自动分段处理
- PDF扫描件（图片）无法直接转换，需要先OCR
- 部分PDF格式复杂可能提取文本不完整
- Windows系统建议安装中文语音包以获得更好效果

## 示例

### 示例1：转换Word文档

```bash
python scripts/doc_to_speech.py 报告.docx -o 报告音频.mp3 -r 130
```

### 示例2：批量转换文件夹

```bash
python scripts/doc_to_speech.py ./我的文档/ -o ./有声书/ -e gtts
```

### 示例3：Python代码调用

```python
from scripts.doc_to_speech import convert_file

# 转换单个文件
convert_file(
    input_path="文章.pdf",
    output_path="文章.mp3",
    engine="pyttsx3",
    rate=140
)
```

## 故障排除

### 问题：无法提取PDF文本

**解决**: 安装pdfplumber
```bash
pip install pdfplumber
```

### 问题：中文朗读效果差

**解决**: 
1. Windows用户安装Microsoft Speech Platform
2. 或使用在线引擎: `-e gtts`

### 问题：转换速度慢

**解决**: 
- 使用离线引擎 `pyttsx3` 代替 `gtts`
- 减少单次转换的文本量

### 问题：语音断断续续

**解决**: 调整语速参数 `-r`，建议范围 120-180
