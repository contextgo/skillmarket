#!/usr/bin/env python3
"""
文档转语音工具 - 将Word、PDF、TXT等文档转换为MP3音频
支持批量转换、语音选择、语速调节
"""

import os
import sys
import argparse
from pathlib import Path
import tempfile

# 文档解析库
try:
    import docx2txt
except ImportError:
    docx2txt = None

try:
    import PyPDF2
except ImportError:
    PyPDF2 = None

try:
    import pdfplumber
except ImportError:
    pdfplumber = None

# 语音合成库
try:
    import pyttsx3
except ImportError:
    pyttsx3 = None

try:
    from gtts import gTTS
except ImportError:
    gTTS = None


def extract_text_from_docx(file_path):
    """从Word文档提取文本"""
    if docx2txt is None:
        raise ImportError("请安装 docx2txt: pip install docx2txt")
    return docx2txt.process(file_path)


def extract_text_from_pdf(file_path):
    """从PDF文档提取文本"""
    text = ""
    
    # 优先使用pdfplumber（效果更好）
    if pdfplumber:
        try:
            with pdfplumber.open(file_path) as pdf:
                for page in pdf.pages:
                    page_text = page.extract_text()
                    if page_text:
                        text += page_text + "\n"
            return text
        except Exception as e:
            print(f"pdfplumber解析失败，尝试PyPDF2: {e}")
    
    # 备选PyPDF2
    if PyPDF2:
        try:
            with open(file_path, 'rb') as file:
                pdf_reader = PyPDF2.PdfReader(file)
                for page in pdf_reader.pages:
                    text += page.extract_text() + "\n"
            return text
        except Exception as e:
            raise ImportError(f"PDF解析失败: {e}")
    
    raise ImportError("请安装 pdfplumber 或 PyPDF2: pip install pdfplumber")


def extract_text_from_txt(file_path):
    """从TXT文件提取文本"""
    encodings = ['utf-8', 'gbk', 'gb2312', 'utf-16', 'ascii']
    
    for encoding in encodings:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    
    raise ValueError(f"无法解码文件: {file_path}")


def extract_text(file_path):
    """根据文件类型提取文本"""
    file_path = Path(file_path)
    suffix = file_path.suffix.lower()
    
    if suffix == '.docx':
        return extract_text_from_docx(file_path)
    elif suffix == '.pdf':
        return extract_text_from_pdf(file_path)
    elif suffix in ['.txt', '.md', '.py', '.js', '.html', '.css', '.json', '.xml']:
        return extract_text_from_txt(file_path)
    else:
        raise ValueError(f"不支持的文件格式: {suffix}")


def text_to_speech_pyttsx3(text, output_path, voice_id=None, rate=150):
    """使用pyttsx3进行语音合成（离线，支持中文）"""
    if pyttsx3 is None:
        raise ImportError("请安装 pyttsx3: pip install pyttsx3")
    
    engine = pyttsx3.init()
    
    # 设置语速
    engine.setProperty('rate', rate)
    
    # 设置音量
    engine.setProperty('volume', 0.9)
    
    # 选择语音
    voices = engine.getProperty('voices')
    if voice_id and voice_id < len(voices):
        engine.setProperty('voice', voices[voice_id].id)
    else:
        # 尝试找到中文语音
        for voice in voices:
            if 'chinese' in voice.name.lower() or 'zh' in voice.id.lower():
                engine.setProperty('voice', voice.id)
                break
    
    # 保存为MP3
    engine.save_to_file(text, output_path)
    engine.runAndWait()
    
    return output_path


def text_to_speech_gtts(text, output_path, lang='zh-cn', slow=False):
    """使用gTTS进行语音合成（在线，Google TTS）"""
    if gTTS is None:
        raise ImportError("请安装 gTTS: pip install gtts")
    
    tts = gTTS(text=text, lang=lang, slow=slow)
    tts.save(output_path)
    
    return output_path


def split_text(text, max_length=5000):
    """将长文本分割成小块（避免TTS限制）"""
    if len(text) <= max_length:
        return [text]
    
    chunks = []
    current_chunk = ""
    
    for paragraph in text.split('\n'):
        if len(current_chunk) + len(paragraph) < max_length:
            current_chunk += paragraph + "\n"
        else:
            if current_chunk:
                chunks.append(current_chunk)
            current_chunk = paragraph + "\n"
    
    if current_chunk:
        chunks.append(current_chunk)
    
    return chunks


def convert_file(input_path, output_path=None, engine='pyttsx3', voice_id=None, rate=150, lang='zh-cn'):
    """转换单个文件"""
    input_path = Path(input_path)
    
    if not input_path.exists():
        raise FileNotFoundError(f"文件不存在: {input_path}")
    
    # 确定输出路径
    if output_path is None:
        output_path = input_path.with_suffix('.mp3')
    else:
        output_path = Path(output_path)
    
    print(f"正在提取文本: {input_path}")
    text = extract_text(input_path)
    
    if not text or not text.strip():
        raise ValueError(f"无法从文件提取文本或文本为空: {input_path}")
    
    # 清理文本
    text = text.strip()
    
    print(f"文本长度: {len(text)} 字符")
    print(f"正在转换为语音: {output_path}")
    
    # 根据引擎选择TTS方法
    if engine == 'pyttsx3':
        text_to_speech_pyttsx3(text, str(output_path), voice_id, rate)
    elif engine == 'gtts':
        text_to_speech_gtts(text, str(output_path), lang)
    else:
        raise ValueError(f"不支持的引擎: {engine}")
    
    print(f"✅ 转换完成: {output_path}")
    return output_path


def batch_convert(input_paths, output_dir=None, engine='pyttsx3', voice_id=None, rate=150, lang='zh-cn'):
    """批量转换文件"""
    results = []
    
    for input_path in input_paths:
        try:
            if output_dir:
                output_path = Path(output_dir) / (Path(input_path).stem + '.mp3')
                output_path.parent.mkdir(parents=True, exist_ok=True)
            else:
                output_path = None
            
            result = convert_file(input_path, output_path, engine, voice_id, rate, lang)
            results.append({'input': input_path, 'output': result, 'success': True})
        except Exception as e:
            print(f"❌ 转换失败 {input_path}: {e}")
            results.append({'input': input_path, 'error': str(e), 'success': False})
    
    return results


def list_voices():
    """列出可用的语音"""
    if pyttsx3 is None:
        print("pyttsx3 未安装")
        return
    
    engine = pyttsx3.init()
    voices = engine.getProperty('voices')
    
    print("\n可用语音列表:")
    print("-" * 60)
    for i, voice in enumerate(voices):
        print(f"ID: {i}")
        print(f"  名称: {voice.name}")
        print(f"  ID: {voice.id}")
        print(f"  语言: {voice.languages if hasattr(voice, 'languages') else 'N/A'}")
        print("-" * 60)


def main():
    parser = argparse.ArgumentParser(description='文档转语音工具')
    parser.add_argument('input', nargs='+', help='输入文件路径（支持多个）')
    parser.add_argument('-o', '--output', help='输出文件路径或目录')
    parser.add_argument('-e', '--engine', default='pyttsx3', choices=['pyttsx3', 'gtts'],
                        help='语音合成引擎 (默认: pyttsx3)')
    parser.add_argument('-v', '--voice', type=int, default=None,
                        help='语音ID (使用 --list-voices 查看可用语音)')
    parser.add_argument('-r', '--rate', type=int, default=150,
                        help='语速 (默认: 150, 仅pyttsx3)')
    parser.add_argument('-l', '--lang', default='zh-cn',
                        help='语言代码 (默认: zh-cn, 仅gtts)')
    parser.add_argument('--list-voices', action='store_true',
                        help='列出可用语音')
    
    args = parser.parse_args()
    
    # 列出语音
    if args.list_voices:
        list_voices()
        return
    
    # 批量转换
    if len(args.input) > 1 or Path(args.input[0]).is_dir():
        # 如果是目录，获取所有支持的文件
        input_files = []
        for path in args.input:
            p = Path(path)
            if p.is_dir():
                input_files.extend(p.glob('*.docx'))
                input_files.extend(p.glob('*.pdf'))
                input_files.extend(p.glob('*.txt'))
                input_files.extend(p.glob('*.md'))
            else:
                input_files.append(p)
        
        print(f"找到 {len(input_files)} 个文件待转换")
        results = batch_convert([str(f) for f in input_files], args.output, 
                               args.engine, args.voice, args.rate, args.lang)
        
        # 统计结果
        success_count = sum(1 for r in results if r['success'])
        print(f"\n转换完成: {success_count}/{len(results)} 成功")
    else:
        # 单个文件转换
        convert_file(args.input[0], args.output, args.engine, args.voice, args.rate, args.lang)


if __name__ == '__main__':
    main()
