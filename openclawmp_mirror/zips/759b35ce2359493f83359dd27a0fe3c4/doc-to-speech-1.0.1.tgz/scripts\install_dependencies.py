#!/usr/bin/env python3
"""
安装文档转语音所需的依赖库
"""

import subprocess
import sys

def install_package(package):
    """安装单个包"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        print(f"✅ 已安装: {package}")
        return True
    except subprocess.CalledProcessError as e:
        print(f"❌ 安装失败: {package} - {e}")
        return False

def main():
    """安装所有依赖"""
    packages = [
        # 文档解析
        "docx2txt",           # Word文档解析
        "pdfplumber",         # PDF解析（推荐）
        "PyPDF2",             # PDF解析（备选）
        
        # 语音合成
        "pyttsx3",            # 离线TTS（支持中文）
        "gtts",               # Google TTS（在线）
        
        # 音频处理（可选）
        "pydub",              # 音频处理
    ]
    
    print("正在安装文档转语音依赖...")
    print("-" * 50)
    
    success_count = 0
    for package in packages:
        if install_package(package):
            success_count += 1
    
    print("-" * 50)
    print(f"安装完成: {success_count}/{len(packages)} 成功")
    
    # 检查pyttsx3的语音支持
    print("\n检查语音支持...")
    try:
        import pyttsx3
        engine = pyttsx3.init()
        voices = engine.getProperty('voices')
        print(f"系统可用语音数量: {len(voices)}")
        
        # 查找中文语音
        chinese_voices = [v for v in voices if 'chinese' in v.name.lower() or 'zh' in v.id.lower()]
        if chinese_voices:
            print(f"中文语音数量: {len(chinese_voices)}")
        else:
            print("提示: 未找到中文语音，系统将使用默认语音")
            print("Windows用户可安装: Microsoft Speech Platform 或 启用Windows中文语音")
    except Exception as e:
        print(f"检查语音支持时出错: {e}")

if __name__ == '__main__':
    main()
