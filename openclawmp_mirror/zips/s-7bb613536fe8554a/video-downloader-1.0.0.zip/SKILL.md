---
name: video-downloader
description: 万能视频下载。支持B站、PornHub、YouTube、rule34video(AKT)、bad.news视频搜索下载。使用场景：用户说"下个视频"、"下个B站xxx"、"下个pornhub xxx"、"搜索akt最新作品"、"检索akt"、"搜badnews xxx"等
---

# 万能视频下载

## 支持网站

- **B站** - 关键词含"b站"或"bilibili"
- **PornHub** - 关键词含"ph"或"pornhub"
- **YouTube** - 关键词含"yt"或"youtube"  
- **rule34video (AKT)** - 关键词含"akt"或"AKT"或"二次元"或"rule34"
- **bad.news** - 关键词含"badnews"或"bad"（搜索 + 下载10秒预览）

## 平台识别规则（重要！）

| 关键词 | 平台 |
|--------|------|
| b站、bilibili | B站 |
| ph、pornhub | PornHub |
| yt、youtube | YouTube |
| **akt、AKT** | **rule34video** ⚠️ |
| 二次元、rule34 | rule34video |
| **badnews、bad** | **bad.news** ⚠️ |

**特别注意：用户说"akt"时，必须搜 rule34video！用户说"bad"或"badnews"时，搜 bad.news！**

## 使用方法

```bash
# 搜索 + 下载第一个（自动识别平台）
python skills/video_downloader/scripts/download.py "关键词"

# 仅搜索
python skills/video_downloader/scripts/download.py "关键词" -s bilibili

# 下载第N个
python skills/video_downloader/scripts/download.py "关键词" -d 2

# 直接下载URL
python skills/video_downloader/scripts/download.py -u "视频URL"
```

## 示例

```
"下个b站丝瓜汤" → 搜B站
"下个ph footjob" → 搜PornHub
"下个yt 猫和老鼠" → 搜YouTube
"下个akt" → 搜rule34video
"检索akt最新作品" → 搜rule34video
"搜badnews 芭芭拉" → 搜bad.news（返回列表，用户选择后下载10秒预览）
"下个bad" → 搜bad.news
```

## 输出目录

- B站: `output/bilibili/`
- PornHub: `output/pornhub/`
- YouTube: `output/youtube/`
- rule34video: `output/rule34video/`
- bad.news: `output/badnews/`

## bad.news 特殊流程

1. 搜索关键词，展示视频列表（带标题）
2. 用户选择第几个
3. 下载完整视频 → 提取前10秒预览
4. 如果预览 >10MB，自动压缩后再发送

## 注意

- **重要**:视频下载完成先进行大小检测，如果大于10mb则要先压缩至10mb以内再推送至飞书
- 检索关键词的时候，bilibili平台对应中文检索；pornhub和rule34video使用日文，英文，中文检索；Youtube用英文，日文检索
