# -*- coding: utf-8 -*-
"""万能视频下载 - 简化版"""
import requests, subprocess, re, json, os, argparse
from bs4 import BeautifulSoup

PROXY = os.environ.get('HTTP_PROXY', 'http://127.0.0.1:7890')
YT_DLP = "M:\\video_spider\\yt-dlp"

SITES = {
    'bilibili': ('output/bilibili', 'https://api.bilibili.com/x/web-interface/search/type?search_type=video&keyword={}'),
    'pornhub': ('output/pornhub', 'https://www.pornhub.com/video/search?search={}'),
    'youtube': ('output/youtube', None),
    'rule34': ('output/rule34video', 'https://rule34video.com/models/{}/'),
    'badnews': ('output/badnews', 'https://bad.news/search/q-{}/type-porn')
}

def detect(k):
    k_lower = k.lower()
    if 'b站' in k_lower or 'bilibili' in k_lower: return 'bilibili'
    if 'ph' in k_lower or 'pornhub' in k_lower or 'porn' in k_lower: return 'pornhub'
    if 'yt' in k_lower or 'youtube' in k_lower: return 'youtube'
    if 'bad' in k_lower or 'badnews' in k_lower: return 'badnews'
    return 'rule34'

def search(k, site, limit):
    out_dir, search_url = SITES[site]
    print(f"🔍 搜索 {site}: {k}")
    print("="*40)
    
    # 清理关键词
    orig_k = k
    for w in ['b站','bilibili','ph','pornhub','porn','yt','youtube','rule34','二次元','下个','下载']:
        k = re.sub(w, '', k, flags=re.I)
    k = k.strip()
    if not k:
        k = orig_k  # 如果清理后为空（比如只有"akt"），保留原关键词
    
    videos = []
    try:
        if site == 'youtube':
            cmd = [YT_DLP, "--flat-playlist", "--print", "%(id)s|%(title)s|https://www.youtube.com/watch?v=%(id)s", f"ytsearch{limit}:{k}"]
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            for l in r.stdout.strip().split('\n'):
                if '|' in l:
                    p = l.split('|')
                    if len(p) >= 3:
                        videos.append({'url': p[2], 'title': p[1][:50], 'site': site})
        
        elif site == 'pornhub':
            r = requests.get(search_url.format(k), proxies={'http':PROXY,'https':PROXY}, timeout=20)
            soup = BeautifulSoup(r.text, 'html.parser')
            for a in soup.select('a.linkVideoThumb'):
                m = re.search(r'viewkey=([a-zA-Z0-9]+)', a.get('href',''))
                if m:
                    videos.append({'url': f"https://www.pornhub.com/view_video.php?viewkey={m.group(1)}", 'title': a.get('title','')[:50], 'site': site})
        
        elif site == 'rule34':
            r = requests.get(search_url.format(k), proxies={'http':PROXY,'https':PROXY}, timeout=20)
            soup = BeautifulSoup(r.text, 'html.parser')
            for a in soup.find_all('a', href=lambda x: x and '/video/' in str(x)):
                m = re.search(r'/video/(\d+)/', a.get('href', ''))
                if m:
                    href = a.get('href','')
                    if not href.startswith('http'):
                        href = 'https://rule34video.com' + href
                    videos.append({'url': href, 'title': a.get_text(strip=True)[:50], 'site': site})
        
        elif site == 'bilibili':
            try:
                r = requests.get(search_url.format(k), headers={'User-Agent':'Mozilla/5.0','Referer':'https://www.bilibili.com'}, timeout=20)
                data = r.json()
                for item in data.get('data',{}).get('result',[])[:limit]:
                    videos.append({'url': f"https://www.bilibili.com/video/{item.get('bvid','')}", 'title': item.get('title','').replace('<em class="keyword">','').replace('</em>','')[:50], 'site': site})
            except:
                # 备用：用搜索引擎
                print("⚠️ 备用搜索...")
                r = requests.get(f"https://www.bing.com/search?q=site:bilibili.com+{k}", proxies={'http':PROXY,'https':PROXY}, timeout=20)
                for a in re.findall(r'href="(https?://www\.bilibili\.com/video/BV[\w]+)"', r.text):
                    if a not in [v['url'] for v in videos]:
                        videos.append({'url': a, 'title': 'B站视频', 'site': site})
        
        elif site == 'badnews':
            # bad.news 搜索
            r = requests.get(search_url.format(k), proxies={'http':PROXY,'https':PROXY}, timeout=20)
            links = re.findall(r'href="(/t/\d+)"[^>]*>([^<]*)</a>', r.text)
            seen = set()
            for link, text in links:
                if link not in seen and '/t/' in link:
                    seen.add(link)
                    tid = link.replace('/t/', '')
                    title = text.strip() if text.strip() and text.strip() != 'Watch video' else f'视频{tid}'
                    videos.append({'url': f"https://bad.news/t/{tid}", 'title': title[:50], 'site': site})
    
    except Exception as e:
        print(f"❌ 错误: {e}")
    
    # 去重
    seen = set()
    unique = []
    for v in videos:
        if v['url'] not in seen:
            seen.add(v['url'])
            unique.append(v)
    videos = unique[:limit]
    
    if videos:
        print(f"\n✅ 找到 {len(videos)} 个:\n")
        for i,v in enumerate(videos,1):
            print(f"{i}. {v['title']}\n   {v['url']}\n")
    else:
        print("❌ 没找到")
    
    return videos

def download(url, site):
    out = SITES[site][0]
    os.makedirs(out, exist_ok=True)
    print(f"⬇️ 下载: {url}")
    
    # bad.news 特殊处理 - 使用 ffmpeg 直接下载
    if site == 'badnews':
        # 从 URL 提取视频 ID
        match = re.search(r'/t/(\d+)', url)
        if not match:
            print("❌ 无法从URL提取视频ID")
            return False
        tid = match.group(1)
        
        # 获取视频页面，提取 m3u8 地址
        try:
            # 访问视频页面
            video_url = f"https://bad.news/t/{tid}"
            r = requests.get(video_url, proxies={'http':PROXY,'https':PROXY}, timeout=20)
            
            # 从页面提取 data-source
            m = re.search(r'data-source="([^"]+)"', r.text)
            if m:
                video_stream_url = m.group(1)
                print(f"📡 找到视频流: {video_stream_url[:80]}...")
                
                # 用 ffmpeg 直接下载（设置代理）
                title = f"badnews_{tid}"
                output_path = f"{out}/{title}.mp4"
                
                # 设置系统代理环境变量
                env = os.environ.copy()
                env['http_proxy'] = PROXY
                env['https_proxy'] = PROXY
                env['HTTP_PROXY'] = PROXY
                env['HTTPS_PROXY'] = PROXY
                
                cmd = ['ffmpeg', '-i', video_stream_url, '-c', 'copy', output_path, '-y']
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=300, env=env)
                
                if result.returncode == 0 and os.path.exists(output_path):
                    print("✅ 完成!")
                    return True
                else:
                    print(f"❌ ffmpeg 错误: {result.stderr[-200:] if result.stderr else 'Unknown error'}")
            else:
                print("❌ 未找到视频流地址")
        except Exception as e:
            print(f"❌ 错误: {e}")
        print("❌ 失败")
        return False
    
    r = subprocess.run([YT_DLP, url, "-o", f"{out}/%(title)s.%(ext)s"], capture_output=True, text=True)
    if r.returncode == 0:
        print("✅ 完成!")
    else:
        print(f"❌ 失败")
    return r.returncode == 0

def main():
    p = argparse.ArgumentParser()
    p.add_argument('k', nargs='?', help='关键词')
    p.add_argument('-s','--site', default='auto')
    p.add_argument('-d','--download', metavar='N', help='下载第N个')
    p.add_argument('-u','--url', help='直接下载URL')
    p.add_argument('-l','--limit', type=int, default=5)
    a = p.parse_args()
    
    if a.url:
        site = detect(a.url) if a.site == 'auto' else a.site
        download(a.url, site)
    elif a.k:
        site = detect(a.k) if a.site == 'auto' else a.site
        videos = search(a.k, site, a.limit)
        if videos and a.download:
            try:
                idx = int(a.download) - 1
                if 0 <= idx < len(videos):
                    download(videos[idx]['url'], site)
            except: pass
    else:
        p.print_help()

if __name__ == "__main__":
    main()
