# LEAM Layer 2 - 情境构建层
# 历史关联、向量检索、时间序列分析

param(
    [string]$Query,
    [int]$LookbackDays = 7,
    [int]$TopK = 5
)

$DataDir = "$env:USERPROFILE\.leam"
$LogDir = "$DataDir\logs"
$VectorDir = "$DataDir\vectors"

# 确保目录
New-Item -ItemType Directory -Path $VectorDir -Force | Out-Null

function Get-SimilarEvents {
    param([string]$Query, [int]$TopK)
    
    $allEvents = @()
    $logFiles = Get-ChildItem $LogDir -Filter "leam-*.log" | Select-Object -Last $LookbackDays
    
    foreach ($file in $logFiles) {
        $events = Get-Content $file.FullName | Where-Object { $_ -match $Query }
        $allEvents += $events
    }
    
    # 简单的相似度排序（基于关键词匹配数）
    $scored = $allEvents | ForEach-Object {
        $score = 0
        $keywords = $Query -split '\s+'
        foreach ($kw in $keywords) {
            if ($_ -match $kw) { $score++ }
        }
        [PSCustomObject]@{ Event = $_; Score = $score }
    } | Sort-Object Score -Descending | Select-Object -First $TopK
    
    return $scored
}

function Get-TemporalPattern {
    param([string]$EventType, [int]$Hours = 24)
    
    $cutoff = (Get-Date).AddHours(-$Hours)
    $events = @()
    
    $logFiles = Get-ChildItem $LogDir -Filter "leam-*.log"
    foreach ($file in $logFiles) {
        $content = Get-Content $file.FullName
        foreach ($line in $content) {
            if ($line -match "\[(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})\].*$EventType") {
                $time = [DateTime]::Parse($matches[1])
                if ($time -gt $cutoff) {
                    $events += $time
                }
            }
        }
    }
    
    # 分析时间模式
    $pattern = @{
        count = $events.Count
        frequency = if ($events.Count -gt 0) { $events.Count / $Hours } else { 0 }
        intervals = @()
        trend = "stable"
    }
    
    if ($events.Count -gt 1) {
        $sorted = $events | Sort-Object
        for ($i = 1; $i -lt $sorted.Count; $i++) {
            $interval = ($sorted[$i] - $sorted[$i-1]).TotalMinutes
            $pattern.intervals += $interval
        }
        
        $avgInterval = ($pattern.intervals | Measure-Object -Average).Average
        if ($avgInterval -lt 10) { $pattern.trend = "frequent" }
        elseif ($avgInterval -gt 60) { $pattern.trend = "sparse" }
    }
    
    return $pattern
}

function Build-Context {
    param([string]$CurrentEvent)
    
    Write-Host "========== LEAM Layer 2: 情境构建 ==========" -ForegroundColor Cyan
    
    # 1. 检索相似历史事件
    Write-Host "[L2] 检索相似历史事件..." -ForegroundColor Gray
    $similar = Get-SimilarEvents -Query $CurrentEvent -TopK $TopK
    Write-Host "  找到 $($similar.Count) 个相似事件" -ForegroundColor Gray
    
    # 2. 分析时间模式
    Write-Host "[L2] 分析时间模式..." -ForegroundColor Gray
    $pattern = Get-TemporalPattern -EventType "error" -Hours 24
    Write-Host "  24小时内错误频率: $($pattern.frequency.ToString('F2'))/小时" -ForegroundColor Gray
    Write-Host "  趋势: $($pattern.trend)" -ForegroundColor Gray
    
    # 3. 构建上下文
    $context = @{
        current_event = $CurrentEvent
        similar_events = $similar
        temporal_pattern = $pattern
        recommendation = ""
    }
    
    # 4. 生成建议
    if ($pattern.frequency -gt 5) {
        $context.recommendation = "频繁错误，建议深度分析(L3)"
    } elseif ($similar.Count -gt 0) {
        $context.recommendation = "发现相似历史事件，可参考处理"
    } else {
        $context.recommendation = "新类型事件，需要关注"
    }
    
    Write-Host "[L2] 建议: $($context.recommendation)" -ForegroundColor Yellow
    
    return $context
}

# 主入口
if ($Query) {
    $result = Build-Context -CurrentEvent $Query
    $result | ConvertTo-Json -Depth 3
} else {
    Write-Host "用法: leam-l2-context.ps1 -Query '错误描述'" -ForegroundColor Cyan
}
