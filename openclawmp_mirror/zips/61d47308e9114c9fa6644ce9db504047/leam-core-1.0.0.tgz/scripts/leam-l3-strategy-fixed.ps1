# LEAM Layer 3 - 策略决策层 (修复版)

param(
    [string]$ContextJson = "",
    [string]$Goal = "解决问题",
    [string]$Constraints = ""
)

function Select-Strategy {
    param([hashtable]$Context, [string]$Goal, [array]$ConstraintList)
    
    Write-Host "========== LEAM Layer 3: 策略决策 ==========" -ForegroundColor Cyan
    
    $strategies = @(
        @{ name = "quick_fix"; description = "快速修复"; ai_call = 10; time_cost = "1-5分钟" }
        @{ name = "deep_analysis"; description = "深度分析"; ai_call = 50; time_cost = "10-30分钟" }
        @{ name = "batch_process"; description = "批量处理"; ai_call = 30; time_cost = "5-15分钟" }
        @{ name = "human_confirm"; description = "人工确认"; ai_call = 20; time_cost = "等待响应" }
    )
    
    Write-Host "[L3] 评估策略选项..." -ForegroundColor Gray
    
    # 基于上下文选择策略
    $frequency = if ($Context.temporal_pattern) { $Context.temporal_pattern.frequency } else { 0 }
    $similarCount = if ($Context.similar_events) { $Context.similar_events.Count } else { 0 }
    
    # 评分逻辑
    $bestStrategy = $strategies[0]  # 默认 quick_fix
    
    if ($frequency -gt 5) {
        $bestStrategy = $strategies[1]  # deep_analysis
        Write-Host "  理由: 频繁发生($frequency次/小时)，需要深度分析" -ForegroundColor Gray
    }
    elseif ($similarCount -gt 2) {
        $bestStrategy = $strategies[2]  # batch_process
        Write-Host "  理由: 发现相似历史事件($similarCount个)，可批量处理" -ForegroundColor Gray
    }
    elseif ($ConstraintList -contains "urgent") {
        $bestStrategy = $strategies[0]  # quick_fix
        Write-Host "  理由: 紧急，优先快速修复" -ForegroundColor Gray
    }
    elseif ($ConstraintList -contains "high_risk") {
        $bestStrategy = $strategies[3]  # human_confirm
        Write-Host "  理由: 高风险，需要人工确认" -ForegroundColor Gray
    }
    else {
        Write-Host "  理由: 标准问题，快速修复" -ForegroundColor Gray
    }
    
    Write-Host "[L3] 推荐策略: $($bestStrategy.description)" -ForegroundColor Green
    Write-Host "  AI调用: $($bestStrategy.ai_call)%" -ForegroundColor Gray
    Write-Host "  预计时间: $($bestStrategy.time_cost)" -ForegroundColor Gray
    
    return @{
        selected_strategy = $bestStrategy.name
        description = $bestStrategy.description
        ai_call = $bestStrategy.ai_call
        time_cost = $bestStrategy.time_cost
        context = @{ frequency = $frequency; similar_count = $similarCount }
    }
}

# 主入口
if ($ContextJson) {
    try {
        $ctx = $ContextJson | ConvertFrom-Json -ErrorAction Stop
        # 转换为hashtable
        $ctxHash = @{
            temporal_pattern = @{ frequency = $ctx.temporal_pattern.frequency }
            similar_events = $ctx.similar_events
        }
    }
    catch {
        Write-Host "[L3] 警告: JSON解析失败，使用默认上下文" -ForegroundColor Yellow
        $ctxHash = @{ temporal_pattern = @{ frequency = 0 }; similar_events = @() }
    }
} else {
    $ctxHash = @{ temporal_pattern = @{ frequency = 0 }; similar_events = @() }
}

$constraintsList = if ($Constraints) { $Constraints -split ',' } else { @() }

$result = Select-Strategy -Context $ctxHash -Goal $Goal -ConstraintList $constraintsList
$result | ConvertTo-Json -Compress
