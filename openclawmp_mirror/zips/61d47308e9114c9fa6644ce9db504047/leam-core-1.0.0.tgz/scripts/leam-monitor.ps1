# LEAM Layer 0 - 场域感知层
# 零成本环境监控

param(
    [string]$ConfigPath = "$PSScriptRoot\..\config\leam.json",
    [string]$LogPath = "$env:USERPROFILE\.leam\logs"
)

# 确保日志目录
New-Item -ItemType Directory -Path $LogPath -Force | Out-Null

# 加载配置
$Config = Get-Content $ConfigPath | ConvertFrom-Json
$L0Config = $Config.layers.L0

# 状态文件
$StateFile = "$env:USERPROFILE\.leam\state.json"
$BaselineFile = "$env:USERPROFILE\.leam\baseline.json"

function Write-LeamLog {
    param([string]$Layer, [string]$Event, [string]$Data)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Layer] $Event | $Data"
    $logFile = Join-Path $LogPath "leam-$(Get-Date -Format 'yyyyMMdd').log"
    Add-Content -Path $logFile -Value $logEntry
}

function Get-SystemMetrics {
    $cpu = (Get-Counter '\Processor(_Total)\% Processor Time' -SampleInterval 1 -MaxSamples 1).CounterSamples.CookedValue
    $memory = Get-WmiObject -Class Win32_OperatingSystem
    $memoryUsed = [math]::Round((($memory.TotalVisibleMemorySize - $memory.FreePhysicalMemory) / $memory.TotalVisibleMemorySize) * 100, 2)
    $disk = Get-WmiObject -Class Win32_LogicalDisk -Filter "DeviceID='C:'"
    $diskUsed = [math]::Round((($disk.Size - $disk.FreeSpace) / $disk.Size) * 100, 2)
    
    return @{
        cpu = [math]::Round($cpu, 2)
        memory = $memoryUsed
        disk = $diskUsed
        timestamp = Get-Date -Format "o"
    }
}

function Test-Threshold {
    param([hashtable]$Metrics, [hashtable]$Thresholds)
    $alerts = @()
    if ($Metrics.cpu -gt $Thresholds.cpu) { $alerts += "cpu:$($Metrics.cpu)" }
    if ($Metrics.memory -gt $Thresholds.memory) { $alerts += "memory:$($Metrics.memory)" }
    if ($Metrics.disk -gt $Thresholds.disk) { $alerts += "disk:$($Metrics.disk)" }
    return $alerts
}

function Invoke-L1Classifier {
    param([string]$EventType, [string]$Data)
    
    $L1Config = $Config.layers.L1
    $classification = "unknown"
    $priority = 0
    
    # 关键词匹配
    foreach ($category in $L1Config.keywords.PSObject.Properties) {
        foreach ($keyword in $category.Value) {
            if ($Data -match $keyword) {
                $classification = $category.Name
                $priority = switch ($category.Name) {
                    "urgent" { 3 }
                    "insight" { 2 }
                    "routine" { 1 }
                    "ignore" { 0 }
                    default { 1 }
                }
                break
            }
        }
        if ($priority -gt 0) { break }
    }
    
    return @{
        classification = $classification
        priority = $priority
        should_trigger = ($priority -ge 1 -and $classification -ne "ignore")
    }
}

function Start-LeamMonitor {
    Write-Host "========== LEAM Layer 0 启动 ==========" -ForegroundColor Cyan
    Write-Host "监控模式: $($L0Config.triggers -join ', ')" -ForegroundColor Gray
    Write-Host "日志路径: $LogPath" -ForegroundColor Gray
    Write-Host "按 Ctrl+C 停止监控" -ForegroundColor Yellow
    Write-Host ""
    
    # 建立基线
    $baseline = Get-SystemMetrics
    $baseline | ConvertTo-Json | Set-Content $BaselineFile
    
    # 文件监控
    $watchers = @()
    foreach ($pattern in $L0Config.filters.file_patterns) {
        $watcher = New-Object System.IO.FileSystemWatcher
        $watcher.Path = "G:\OpenClaw\Workspace"
        $watcher.Filter = $pattern
        $watcher.IncludeSubdirectories = $true
        
        Register-ObjectEvent -InputObject $watcher -EventName "Created" -Action {
            $result = Invoke-L1Classifier -EventType "file" -Data $Event.SourceEventArgs.FullPath
            if ($result.should_trigger) {
                Write-LeamLog -Layer "L0-L1" -Event "file_created" -Data "$($Event.SourceEventArgs.FullPath) | class:$($result.classification) | priority:$($result.priority)"
                Write-Host "[L0-L1] 文件创建: $($Event.SourceEventArgs.Name) [$($result.classification)]" -ForegroundColor $(if($result.priority -eq 3){"Red"}elseif($result.priority -eq 2){"Yellow"}else{"Gray"})
            }
        } | Out-Null
        
        Register-ObjectEvent -InputObject $watcher -EventName "Changed" -Action {
            $result = Invoke-L1Classifier -EventType "file" -Data $Event.SourceEventArgs.FullPath
            if ($result.should_trigger) {
                Write-LeamLog -Layer "L0-L1" -Event "file_changed" -Data "$($Event.SourceEventArgs.FullPath) | class:$($result.classification) | priority:$($result.priority)"
                Write-Host "[L0-L1] 文件修改: $($Event.SourceEventArgs.Name) [$($result.classification)]" -ForegroundColor $(if($result.priority -eq 3){"Red"}elseif($result.priority -eq 2){"Yellow"}else{"Gray"})
            }
        } | Out-Null
        
        $watcher.EnableRaisingEvents = $true
        $watchers += $watcher
    }
    
    # 系统监控循环
    while ($true) {
        Start-Sleep -Seconds 60
        
        $metrics = Get-SystemMetrics
        $alerts = Test-Threshold -Metrics $metrics -Thresholds $L1Config.thresholds
        
        if ($alerts.Count -gt 0) {
            Write-LeamLog -Layer "L0" -Event "threshold_alert" -Data ($alerts -join ',')
            Write-Host "[L0] 阈值告警: $($alerts -join ', ')" -ForegroundColor Red
            
            # 触发L1分类
            foreach ($alert in $alerts) {
                $result = Invoke-L1Classifier -EventType "system" -Data $alert
                if ($result.should_trigger) {
                    Write-Host "[L0-L1] 系统告警分类: $alert [$($result.classification)]" -ForegroundColor Yellow
                }
            }
        }
        
        # 保存状态
        $state = @{
            last_check = Get-Date -Format "o"
            metrics = $metrics
            alerts = $alerts
        }
        $state | ConvertTo-Json | Set-Content $StateFile
    }
}

# 主入口
Start-LeamMonitor
