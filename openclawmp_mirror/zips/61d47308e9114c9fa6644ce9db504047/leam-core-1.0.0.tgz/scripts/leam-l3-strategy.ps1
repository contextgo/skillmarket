# LEAM Layer 3 - 策略决策层
# 方案生成、选项评估、策略选择

param(
    [string]$Context,
    [string]$Goal = "解决问题",
    [array]$Constraints = @()
)

function Select-Strategy {
    param([hashtable]$Context, [string]$Goal, [array]$Constraints)
    
    Write-Host "========== LEAM Layer 3: 策略决策 ==========" -ForegroundColor Cyan
    
    $strategies = @(
        @{
            name = "quick_fix"
            description = "快速修复"
            conditions = @("简单错误", "已知解决方案", "低风险")
            ai_call = 10
            time_cost = "1-5分钟"
        },
        @{
            name = "deep_analysis"
            description = "深度分析"
            conditions = @("复杂问题", "频繁发生", "需要诊断")
            ai_call = 50
            time_cost = "10-30分钟"
        },
        @{
            name = "batch_process"
            description = "批量处理"
            conditions = @("重复性问题", "多实例", "可自动化")
            ai_call = 30
            time_cost = "5-15分钟"
        },
        @{
            name = "human_confirm"
            description = "人工确认"
            conditions = @("高风险", "不可逆操作", "超出权限")
            ai_call = 20
            time_cost = "等待响应"
        }
    )
    
    Write-Host "[L3] 评估策略选项..." -ForegroundColor Gray
    
    # 评分
    $scored = foreach ($s in $strategies) {
        $score = 0
        $reasons = @()
        
        # 基于上下文评分
        if ($Context.temporal_pattern.frequency -gt 5 -and $s.name -eq "deep_analysis") {
            $score += 3
            $reasons += "频繁发生，需要深度分析"
        }
        
        if ($Context.similar_events.Count -gt 0 -and $s.name -eq "quick_fix") {
            $score += 2
            $reasons += "有历史相似事件可参考"
        }
        
        if ($Constraints -contains "urgent" -and $s.name -eq "quick_fix") {
            $score += 3
            $reasons += "紧急，优先快速修复"
        }
        
        if ($Constraints -contains "high_risk" -and $s.name -eq "human_confirm") {
            $score += 5
            $reasons += "高风险，需要人工确认"
        }
        
        [PSCustomObject]@{
            Strategy = $s
            Score = $score
            Reasons = $reasons
        }
    }
    
    $best = $scored | Sort-Object Score -Descending | Select-Object -First 1
    
    Write-Host "[L3] 推荐策略: $($best.Strategy.description)" -ForegroundColor Green
    Write-Host "  AI调用: $($best.Strategy.ai_call)%" -ForegroundColor Gray
    Write-Host "  预计时间: $($best.Strategy.time_cost)" -ForegroundColor Gray
    if ($best.Reasons.Count -gt 0) {
        Write-Host "  理由:" -ForegroundColor Gray
        foreach ($r in $best.Reasons) {
            Write-Host "    - $r" -ForegroundColor Gray
        }
    }
    
    return @{
        selected_strategy = $best.Strategy.name
        description = $best.Strategy.description
        ai_call = $best.Strategy.ai_call
        time_cost = $best.Strategy.time_cost
        reasons = $best.Reasons
        alternatives = ($scored | Where-Object { $_.Strategy.name -ne $best.Strategy.name } | Select-Object -First 2).Strategy.name
    }
}

# 主入口
if ($Context) {
    $ctx = $Context | ConvertFrom-Json -ErrorAction SilentlyContinue
    if (-not $ctx) { $ctx = @{ temporal_pattern = @{ frequency = 0 }; similar_events = @() } }
    
    $result = Select-Strategy -Context $ctx -Goal $Goal -Constraints $Constraints
    $result | ConvertTo-Json
} else {
    Write-Host "用法: leam-l3-strategy.ps1 -Context '{...}' -Goal '目标'" -ForegroundColor Cyan
}
