# LEAM 实际测试脚本
# 生成测试数据并验证各层功能

$TestDir = "$env:USERPROFILE\.leam\test"
$LogDir = "$env:USERPROFILE\.leam\logs"
New-Item -ItemType Directory -Path $TestDir -Force | Out-Null
New-Item -ItemType Directory -Path $LogDir -Force | Out-Null

Write-Host "========== LEAM 实际测试 ==========" -ForegroundColor Cyan
Write-Host ""

# 测试1: 生成测试日志数据
Write-Host "[测试1] 生成测试日志数据..." -ForegroundColor Yellow
for ($i = 1; $i -le 5; $i++) {
    $timestamp = (Get-Date).AddHours(-$i).ToString("yyyy-MM-dd HH:mm:ss")
    $logEntry = "[$timestamp] [L0-L1] file_changed | G:\OpenClaw\Workspace\test-error-$i.md | class:urgent | priority:3"
    Add-Content -Path "$LogDir\leam-$(Get-Date -Format 'yyyyMMdd').log" -Value $logEntry
}
Write-Host "  已生成5条测试日志" -ForegroundColor Green
Write-Host ""

# 测试2: L2 情境构建
Write-Host "[测试2] L2 情境构建..." -ForegroundColor Yellow
$l2Result = & "$PSScriptRoot\leam-l2-context.ps1" -Query "error" 2>&1
if ($l2Result) {
    Write-Host "  L2 执行成功" -ForegroundColor Green
    Write-Host "  输出长度: $($l2Result.Length) 字符" -ForegroundColor Gray
}
Write-Host ""

# 测试3: L3 策略决策
Write-Host "[测试3] L3 策略决策..." -ForegroundColor Yellow
$context = @{
    temporal_pattern = @{ frequency = 6; trend = "frequent" }
    similar_events = @(@{ Event = "error"; Score = 5 })
} | ConvertTo-Json -Compress
$l3Result = & "$PSScriptRoot\leam-l3-strategy.ps1" -Context $context -Goal "修复错误" 2>&1
if ($l3Result) {
    Write-Host "  L3 执行成功" -ForegroundColor Green
    $l3Obj = $l3Result | ConvertFrom-Json -ErrorAction SilentlyContinue
    if ($l3Obj) {
        Write-Host "  选择策略: $($l3Obj.selected_strategy)" -ForegroundColor Gray
        Write-Host "  AI调用: $($l3Obj.ai_call)%" -ForegroundColor Gray
    }
}
Write-Host ""

# 测试4: L4 执行优化
Write-Host "[测试4] L4 执行优化..." -ForegroundColor Yellow
$initResult = @{ success = $false; deviation = 0.4 }
$l4Result = & "$PSScriptRoot\leam-l4-optimize.ps1" -Strategy "deep_analysis" -Task "修复错误" -InitialResult $initResult 2>&1
if ($l4Result) {
    Write-Host "  L4 执行成功" -ForegroundColor Green
    $l4Obj = $l4Result | ConvertFrom-Json -ErrorAction SilentlyContinue
    if ($l4Obj) {
        Write-Host "  优化后质量提升: $($l4Obj.estimated_improvement)" -ForegroundColor Gray
        Write-Host "  继续优化: $($l4Obj.should_continue)" -ForegroundColor Gray
    }
}
Write-Host ""

# 测试5: 增强版
Write-Host "[测试5] 增强版 (WAL + 语义检索)..." -ForegroundColor Yellow
$enhancedResult = & "$PSScriptRoot\leam-enhanced.ps1" -Mode demo 2>&1
if ($enhancedResult) {
    Write-Host "  增强版执行成功" -ForegroundColor Green
}
Write-Host ""

Write-Host "========== 测试完成 ==========" -ForegroundColor Cyan
Write-Host "所有层级实际运行正常!" -ForegroundColor Green
