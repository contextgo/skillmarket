# LEAM Enhanced - 增强版分层涌现架构
# 整合分层架构和五层记忆系统

param(
    [string]$Mode = "demo"
)

$DataDir = "$env:USERPROFILE\.leam"
$WalDir = "$DataDir\wal"
$VectorDir = "$DataDir\vectors"

# 确保目录
New-Item -ItemType Directory -Path $WalDir -Force | Out-Null
New-Item -ItemType Directory -Path $VectorDir -Force | Out-Null

# 配置
$Config = @{
    budget = @{ hourly_token_limit = 10000; used = 0 }
    layers = @(
        @{ name = "L0"; enabled = $true; fallback = $null }
        @{ name = "L1"; enabled = $true; fallback = "L0" }
        @{ name = "L2"; enabled = $true; fallback = "L1" }
        @{ name = "L3"; enabled = $true; fallback = "L2" }
        @{ name = "L4"; enabled = $true; fallback = "L3" }
    )
}

# WAL - 预写日志
function Write-WAL {
    param([hashtable]$Event)
    $walFile = Join-Path $WalDir "wal-$(Get-Date -Format 'yyyyMMdd-HHmmss').json"
    $Event | ConvertTo-Json | Set-Content $walFile
    return $walFile
}

function Read-WAL {
    param([int]$LastN = 100)
    Get-ChildItem $WalDir -Filter "wal-*.json" | 
        Sort-Object Name -Descending | 
        Select-Object -First $LastN |
        ForEach-Object { Get-Content $_.FullName | ConvertFrom-Json }
}

# 语义检索（简化版）
function Search-Semantic {
    param([string]$Query, [int]$TopK = 5)
    $events = Read-WAL -LastN 1000
    
    # 基于关键词匹配的简化语义检索
    $keywords = $Query -split '\s+'
    $scored = $events | ForEach-Object {
        $score = 0
        $eventText = $_ | ConvertTo-Json -Compress
        foreach ($kw in $keywords) {
            if ($eventText -match $kw) { $score += 1 }
        }
        [PSCustomObject]@{ Event = $_; Score = $score }
    } | Sort-Object Score -Descending | Select-Object -First $TopK
    
    return $scored
}

# 预算检查
function Check-Budget {
    param([int]$RequiredTokens)
    $remaining = $Config.budget.hourly_token_limit - $Config.budget.used
    return ($RequiredTokens -le $remaining)
}

# 降级策略
function Invoke-WithFallback {
    param([string]$Layer, [scriptblock]$Action)
    
    $layerConfig = $Config.layers | Where-Object { $_.name -eq $Layer }
    
    try {
        $result = & $Action
        return @{ Success = $true; Result = $result; Layer = $Layer }
    }
    catch {
        if ($layerConfig.fallback) {
            Write-Host "[$Layer] 失败，降级到 $($layerConfig.fallback)..." -ForegroundColor Yellow
            return Invoke-WithFallback -Layer $layerConfig.fallback -Action $Action
        }
        return @{ Success = $false; Error = $_.Exception.Message }
    }
}

# 增强版演示
function Start-EnhancedDemo {
    Write-Host "========== LEAM Enhanced 演示 ==========" -ForegroundColor Cyan
    Write-Host "整合: 分层架构 + 五层记忆系统" -ForegroundColor Gray
    Write-Host ""
    
    # 模拟事件
    $event = @{
        timestamp = Get-Date -Format "o"
        type = "error"
        message = "磁盘空间不足"
        severity = "high"
        source = "system"
    }
    
    Write-Host "[1/6] L0: 场域感知" -ForegroundColor Green
    Write-Host "  检测到事件: $($event.message)" -ForegroundColor Gray
    
    Write-Host "[2/6] WAL: 预写日志" -ForegroundColor Green
    $walPath = Write-WAL -Event $event
    Write-Host "  已记录: $walPath" -ForegroundColor Gray
    
    Write-Host "[3/6] L1: 模式识别" -ForegroundColor Green
    $classification = if ($event.severity -eq "high") { "urgent" } else { "normal" }
    Write-Host "  分类: $classification" -ForegroundColor Gray
    
    Write-Host "[4/6] L2: 语义检索" -ForegroundColor Green
    $similar = Search-Semantic -Query $event.message -TopK 3
    Write-Host "  找到 $($similar.Count) 个相似历史事件" -ForegroundColor Gray
    
    Write-Host "[5/6] 预算检查" -ForegroundColor Green
    $requiredTokens = 500
    $canProceed = Check-Budget -RequiredTokens $requiredTokens
    if ($canProceed) {
        Write-Host "  预算充足，继续执行" -ForegroundColor Gray
        $Config.budget.used += $requiredTokens
    }
    else {
        Write-Host "  预算不足，降级处理" -ForegroundColor Yellow
    }
    
    Write-Host "[6/6] L3-L4: 策略决策 + 执行优化" -ForegroundColor Green
    $strategy = if ($similar.Count -gt 2) { "batch_process" } else { "quick_fix" }
    Write-Host "  选择策略: $strategy" -ForegroundColor Gray
    Write-Host "  执行优化: temperature=0.3, detail=precise" -ForegroundColor Gray
    
    Write-Host ""
    Write-Host "========== 演示完成 ==========" -ForegroundColor Cyan
    Write-Host "增强功能:" -ForegroundColor Yellow
    Write-Host "  ✓ WAL预写日志 - 确保事件不丢失" -ForegroundColor Gray
    Write-Host "  ✓ 语义检索 - 基于内容相似度匹配" -ForegroundColor Gray
    Write-Host "  ✓ 预算管理 - 控制token消耗" -ForegroundColor Gray
    Write-Host "  ✓ 降级策略 - 高层失败自动回退" -ForegroundColor Gray
    Write-Host ""
    Write-Host "当前预算使用: $($Config.budget.used) / $($Config.budget.hourly_token_limit) tokens" -ForegroundColor Cyan
}

# 主入口
if ($Mode -eq "demo") {
    Start-EnhancedDemo
}
else {
    Write-Host "用法: leam-enhanced.ps1 -Mode demo" -ForegroundColor Cyan
}
