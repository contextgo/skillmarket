# LEAM 状态查看

param(
    [string]$ConfigPath = "$PSScriptRoot\..\config\leam.json"
)

$Config = Get-Content $ConfigPath | ConvertFrom-Json

Write-Host "========== LEAM 架构状态 ==========" -ForegroundColor Cyan
Write-Host ""

foreach ($layer in $Config.layers.PSObject.Properties) {
    $l = $layer.Value
    $status = if ($l.enabled) { "✅ 启用" } else { "❌ 禁用" }
    $color = if ($l.enabled) { "Green" } else { "Red" }
    
    Write-Host "$($layer.Name): $($l.name)" -ForegroundColor $color
    Write-Host "  状态: $status" -ForegroundColor $color
    Write-Host "  AI调用率: $($l.ai_call)%" -ForegroundColor Gray
    Write-Host "  触发器: $($l.triggers -join ', ')" -ForegroundColor Gray
    Write-Host ""
}

Write-Host "========== 全局配置 ==========" -ForegroundColor Cyan
Write-Host "日志级别: $($Config.global.log_level)" -ForegroundColor Gray
Write-Host "最大事件/小时: $($Config.global.max_events_per_hour)" -ForegroundColor Gray
Write-Host "冷却时间: $($Config.global.cooldown_minutes) 分钟" -ForegroundColor Gray

# 检查状态文件
$StateFile = "$env:USERPROFILE\.leam\state.json"
if (Test-Path $StateFile) {
    $state = Get-Content $StateFile | ConvertFrom-Json
    Write-Host ""
    Write-Host "========== 当前状态 ==========" -ForegroundColor Cyan
    Write-Host "最后检查: $($state.last_check)" -ForegroundColor Gray
    Write-Host "CPU: $($state.metrics.cpu)%" -ForegroundColor $(if($state.metrics.cpu -gt 80){"Red"}else{"Gray"})
    Write-Host "内存: $($state.metrics.memory)%" -ForegroundColor $(if($state.metrics.memory -gt 85){"Red"}else{"Gray"})
    Write-Host "磁盘: $($state.metrics.disk)%" -ForegroundColor $(if($state.metrics.disk -gt 90){"Red"}else{"Gray"})
    if ($state.alerts.Count -gt 0) {
        Write-Host "活跃告警: $($state.alerts -join ', ')" -ForegroundColor Red
    }
}
