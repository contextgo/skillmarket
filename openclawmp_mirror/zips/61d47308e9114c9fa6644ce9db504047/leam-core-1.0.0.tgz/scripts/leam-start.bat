@echo off
echo ========== LEAM 启动 ==========
echo.
echo 正在启动分层涌现架构监控...
echo.

:: 检查 PowerShell
where powershell >nul 2>&1
if %errorLevel% neq 0 (
    echo 错误: 未找到 PowerShell
    pause
    exit /b 1
)

:: 创建数据目录
if not exist "%USERPROFILE%\.leam" mkdir "%USERPROFILE%\.leam"
if not exist "%USERPROFILE%\.leam\logs" mkdir "%USERPROFILE%\.leam\logs"

:: 启动监控
echo 启动 Layer 0-1 监控...
echo 按 Ctrl+C 停止
echo.

powershell -ExecutionPolicy Bypass -File "%~dp0leam-monitor.ps1"

pause
