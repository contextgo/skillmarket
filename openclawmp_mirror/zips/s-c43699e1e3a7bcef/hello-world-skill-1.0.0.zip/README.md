# Hello World Skill

This is a test skill for demonstrating openclawmp publishing workflow.

## Usage

Simply ask the agent to say hello!

## Example

```
User: Say hello
Agent: Hello, World!
```