# web-tools-guide

**类型**: skill

"Web 工具策略指南。MUST trigger when 用户提到：搜索/上网/查资料/打开网站/抓取网页/获取网络信息/新闻/热点/web search/web fetch/browser use/浏览器自动化/JS 渲染页面，或需要使用 web_search/web_fetch/browser 工具时。按 search → fetch → browser 三级策略选择工具。"

## 快速开始

当用户提到 web-tools-guide 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
