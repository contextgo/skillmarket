---
name: clawgo-clone
description: Download a zip from clawgo.me by key, back up current workspace Markdown, then copy zip contents into the local OpenClaw workspace. Use when the user gives a 12-character ClawGo key (e.g. OCVG7H4AAVR2) and wants workspace content aligned with that key. Triggers — "sync workspace with this key", "pull workspace from clawgo", "restore my workspace notes", "clawgo clone", "workspace sync".
---

# ClawGo Clone — 一键克隆你的或别人的龙虾（完全免费）

直接发送克隆链接给龙虾，一键克隆你的或者别人的龙虾的灵魂文件。

详情请见：https://www.clawgo.me/ ，这里有很多名人虾模版，快来试试吧。

## 🦞 挖到宝！这个能一键克隆名人虾的 skill 太疯了！

### 🎯 到底能克隆些什么？

✅ **企业虾**：乔布斯/马斯克/马云…学他们的创业魄力和商业格局
✅ **投资虾**：沈南鹏/徐新/张磊…get顶级投资人的选股逻辑和眼光
✅ **产品虾**：老罗/张小龙…拿捏产品经理的用户思维和产品直觉
✅ **创作虾**：李诞/雪峰…解锁脱口秀演员的幽默解构力，把日常玩成段子
✅ 还有明星虾、次元虾…简直是人格版「万物皆可克隆」！

### 🧠 克隆的不只是人设，是完整的数字灵魂

每只「名虾」都藏着一整套人格文件：
- 📝 `SOUL.md`：核心价值观&底层信念
- 🧠 `MEMORY.md`：经历故事&知识储备
- 💓 `HEARTBEAT.md`：行为模式&语言风格
- 🛠️ `TOOLS.md`：专属技能&工具集

复制链接就能分享给 OpenClaw，相当于把一个「活的」名人AI虾🦞 揣进兜里，随时聊天、请教、共创！

### 💡 谁用谁香！

### 📌 碎碎念

界面干净得像一本杂志，没有花里胡哨的广告，操作简单到小白也能秒会。现在已经有26只名虾了，克隆次数还在疯涨，感觉很快就能凑齐一整个「名人天团」🤣

👉 快去试试克隆你最想成为的那只虾，看看和大佬对话是什么感觉！

---

## 技术说明

Download a zip from clawgo.me, back up existing files, and copy Markdown from the archive into the local OpenClaw workspace.

## Service limits

- Base URL: `https://clawgo.me`
- Key: 12 alphanumeric characters (server normalizes to uppercase)
- Only `.zip` payloads; require `status: ready` before download
- Target folder: `~/.openclaw/workspace/`

## Workflow

### Step 1 — Check key readiness

```bash
curl -s https://clawgo.me/api/clones/{key}/availability
```

- `available: true` and `status: ready` → continue
- `status: pending` → stop with error: "No zip uploaded for this key yet"
- Missing key (404) → stop with error: "Key not found"

### Step 2 — Download zip to a temp path

```bash
curl -s -L -o /tmp/clone-{key}.zip \
  https://clawgo.me/api/clones/{key}/download
```

Verify: file size must be greater than zero.

### Step 3 — Extract and inspect

```bash
mkdir -p /tmp/clone-{key}
unzip -o /tmp/clone-{key}.zip -d /tmp/clone-{key}/
```

Run these safety checks after extraction. If anything looks wrong, warn the user clearly and ask whether to proceed:

- List archive contents
- Require at least one of: `SOUL.md`, `AGENTS.md`, `TOOLS.md`
- If empty or none of the expected Markdown files → stop with error

### Step 4 — Back up current workspace files

```bash
BACKUP_DIR="/tmp/backup-before-clone-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_DIR"
WORKSPACE="$HOME/.openclaw/workspace"

for f in SOUL.md AGENTS.md TOOLS.md IDENTITY.md USER.md HEARTBEAT.md; do
    [ -f "$WORKSPACE/$f" ] && cp "$WORKSPACE/$f" "$BACKUP_DIR/$f"
done
```

Tell the user the backup path so they can roll back manually if needed.

### Step 5 — Write archive files into the workspace

```bash
WORKSPACE="$HOME/.openclaw/workspace"
SRC="/tmp/clone-{key}"

for f in SOUL.md AGENTS.md TOOLS.md IDENTITY.md USER.md HEARTBEAT.md; do
    [ -f "$SRC/$f" ] && cp "$SRC/$f" "$WORKSPACE/$f"
done
```

Only files present in the zip are copied; local files missing from the zip are left unchanged (not removed).

### Step 6 — Report results

Tell the user:

- Files successfully written from the zip
- Files skipped because they were absent from the zip
- Backup directory path
- Suggestion: run `/reset` to restart the session so new workspace content loads

## Workspace file reference

| File | Role |
|------|------|
| `SOUL.md` | Primary identity, reasoning style, behavioral guardrails |
| `AGENTS.md` | Session bootstrap, tool policy, hard limits |
| `TOOLS.md` | Local tooling notes and proxy routing |
| `IDENTITY.md` | Display name, role, emoji metadata |
| `USER.md` | User profile and session context |
| `HEARTBEAT.md` | Scheduled task notes |

## Errors

| Situation | Action |
|-----------|--------|
| `status: pending` | Stop; ask the user to upload a zip first |
| Key missing (404) | Stop; invalid key |
| No expected Markdown in zip | Stop; archive content does not match expectations |
| Downloaded file size is 0 | Stop; retry or report failure |
| Copy failed (permissions, etc.) | Report error; backup remains available |
