# System Design Interview Patterns

## Overview
系统设计面试的高频模式和解法框架。掌握这些模式可以应对 90% 的系统设计问题。

## Core Framework: CREATE

**C** - Clarify requirements (functional + non-functional)
**R** - Right high-level design (draw architecture)
**E** - Estimate scale (QPS, storage, bandwidth)
**A** - Analyze deep dive (pick 2-3 components)
**T** - Trade-offs discussion
**E** - Edge cases and evolution

## Pattern 1: URL Shortener
```
Client → Load Balancer → API Servers → Database (NoSQL)
                              ↓
                      Cache (Redis)
                      Key Generation: Base62 encoding
```
Key decisions:
- Hash + counter vs UUID (prefer hash for shorter URLs)
- SQL vs NoSQL (NoSQL for write-heavy)
- Cache strategy: write-through for new URLs

## Pattern 2: Chat System
```
Client ↔ WebSocket Server ↔ Message Queue ↔ DB
              ↓                    ↓
         Presence Service    Search Index
```
Key decisions:
- WebSocket vs long polling (WebSocket for real-time)
- Message ordering: per-chat sequence number
- Online status: heartbeat + pub/sub
- Storage: time-series DB (Cassandra/ScyllaDB)

## Pattern 3: News Feed
```
User → API → Feed Service
              ↓
         Fan-out on Write (celebrity) or Read (regular user)
              ↓
         Cache + Timeline DB
```
Key decisions:
- Fan-out on Write vs Read (hybrid based on follower count)
- Ranking: chronological + engagement score
- Pagination: cursor-based (not offset)

## Pattern 4: Rate Limiter
```
Client → API Gateway → Rate Limiter → Backend
                         ↓
                    Redis (sliding window)
```
Algorithms:
- **Fixed Window**: Simple but has burst issues
- **Sliding Window**: Better distribution
- **Token Bucket**: Allows controlled bursts
- **Leaky Bucket**: Constant rate output

## Pattern 5: Notification System
```
Event → Queue → Router → Push/SMS/Email
                     ↓
                 Template Engine
                     ↓
                 Rate Limiter
```
Key decisions:
- Critical vs non-critical (different delivery guarantees)
- Consolidation: batch similar notifications
- Retry strategy: exponential backoff with max attempts

## Scale Estimation Quick Reference
| System | QPS | Storage | Bandwidth |
|--------|-----|---------|-----------|
| URL Shortener | 100K write, 10M read | 10TB/year | 5Gbps |
| Chat System | 1M concurrent | 100TB/year | 10Gbps |
| News Feed | 50K write, 500K read | 500TB/year | 20Gbps |
| Notification | 100K event/s | 10TB/year | 1Gbps |