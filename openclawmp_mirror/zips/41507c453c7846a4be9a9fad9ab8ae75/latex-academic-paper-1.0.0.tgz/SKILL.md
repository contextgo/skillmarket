---
name: latex-academic-paper
description: LaTeX学术论文写作工具 - 支持IEEE/ACM/Springer/Nature等主流期刊模板、BibTeX文献管理、数学公式排版、图表格式化、算法伪代码、定理证明环境、中文论文支持(ctex/xeCJK)、TikZ绘图、学术写作风格指南和同行评审回复模板。
---

# LaTeX 学术论文写作工具

## 概述

本技能提供全面的 LaTeX 学术论文写作支持，覆盖从论文结构搭建、期刊模板适配、数学公式排版、图表管理、文献引用到同行评审回复的完整写作流程。支持 IEEE、ACM、Springer、Nature 等主流学术出版格式，以及中文学术论文的 ctex/xeCJK 支持和 TikZ 科技绘图。

---

## 一、论文整体结构

### 1.1 标准学术论文结构

```latex
% ==================== 文档类与基本配置 ====================
\documentclass[conference]{IEEEtran}

% ==================== 宏包加载 ====================
\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}          % 三线表
\usepackage{algorithmic}       % 伪代码
\usepackage{algorithm}         % 算法浮动体
\usepackage{hyperref}
\usepackage{cite}
\usepackage{url}

% ==================== 文档信息 ====================
\title{基于深度学习的多模态情感分析方法研究}

\author{
  \IEEEauthorblockN{张三\IEEEauthorrefmark{1}，李四\IEEEauthorrefmark{2}}
  \IEEEauthorblockA{\IEEEauthorrefmark{1}清华大学计算机科学与技术系，北京 100084 \\
  \IEEEauthorrefmark{2}北京大学信息科学技术学院，北京 100871 \\
  Email: zhangsan@tsinghua.edu.cn}
}

\markboth{Journal of Computational Intelligence, 2025}%
{Zhang \MakeLowercase{et al.}: Deep Multimodal Sentiment Analysis}

% ==================== 正文 ====================
\begin{document}

\maketitle

\begin{abstract}
本文提出了一种基于深度学习的多模态情感分析方法，融合文本、语音和视觉三种模态信息，
通过跨模态注意力机制实现模态间的有效交互。实验表明，所提方法在 CMU-MOSI 和
CMU-MOSEI 数据集上分别取得了 84.3\% 和 86.7\% 的准确率，显著优于现有基线方法。
\end{abstract}

\begin{IEEEkeywords}
多模态情感分析，深度学习，注意力机制，跨模态融合
\end{IEEEkeywords}

% --- 正文章节 ---
\section{引言}
\label{sec:introduction}
...

\section{相关工作}
\label{sec:related_work}
...

\section{方法}
\label{sec:method}
...

\section{实验}
\label{sec:experiments}
...

\section{结论}
\label{sec:conclusion}
...

\section*{致谢}
...

% --- 参考文献 ---
\bibliographystyle{IEEEtran}
\bibliography{references}

\end{document}
```

### 1.2 论文写作顺序建议

1. **方法（Method）** → 最核心部分，先确定技术方案
2. **实验（Experiments）** → 设计实验验证方法有效性
3. **引言（Introduction）** → 根据方法和结果提炼贡献点
4. **相关工作（Related Work）** → 建立与现有工作的联系
5. **摘要（Abstract）** → 最后撰写，浓缩全文精华
6. **结论（Conclusion）** → 总结贡献，指出未来方向

---

## 二、IEEE 期刊/会议模板

### 2.1 IEEE Conference（会议论文）

```latex
\documentclass[conference]{IEEEtran}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{cite}

% 双栏模式，会议论文标准
\IEEEoverridecommandlockouts
\pubadid{0000--0000/00\$00.00 \copyright 2025 IEEE}

\title{Efficient Transformer Architectures for Low-Resource NLP}

\author{\IEEEauthorblockN{1\textsuperscript{st} Given Name Surname}
\IEEEauthorblockA{\textit{Dept. of Computer Science} \\
\textit{University Name}\\
City, Country \\
email@university.edu}
\and
\IEEEauthorblockN{2\textsuperscript{nd} Given Name Surname}
\IEEEauthorblockA{\textit{Dept. of Electrical Engineering} \\
\textit{University Name}\\
City, Country \\
email@university.edu}
}

\begin{document}
\maketitle

\begin{abstract}
This paper proposes an efficient transformer architecture ...
\end{abstract}

\begin{IEEEkeywords}
transformer, natural language processing, efficiency
\end{IEEEkeywords}

\section{Introduction}
\IEEEPARstart{T}{ransformer} models have revolutionized ...
\lipsum[1]

\section{Related Work}

\subsection{Transformer Variants}
Several works have explored efficient ...

\section{Proposed Method}
...

\section{Experiments}

\subsection{Datasets}
We evaluate on the following benchmarks:

\subsection{Implementation Details}
All experiments are conducted on ...

\subsection{Main Results}
Results are shown in Table~\ref{tab:main_results}.

\begin{table}[!t]
\renewcommand{\arraystretch}{1.3}
\caption{Main Results on Benchmark Datasets}
\label{tab:main_results}
\centering
\begin{tabular}{lccc}
\toprule
\textbf{Method} & \textbf{GLUE} & \textbf{SQuAD} & \textbf{Params (M)} \\
\midrule
BERT-base        & 79.6 & 88.5 & 110 \\
ALBERT-base      & 80.0 & 89.2 & 12  \\
TinyBERT         & 78.8 & 87.4 & 14  \\
\textbf{Ours}    & \textbf{81.2} & \textbf{90.1} & \textbf{15} \\
\bottomrule
\end{tabular}
\end{table}

\section{Conclusion}
...

\begin{thebibliography}{00}
\bibitem{ref1} A. Vaswani et al., ``Attention is All You Need,'' in \textit{Proc. NeurIPS}, 2017.
\bibitem{ref2} J. Devlin et al., ``BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding,'' in \textit{Proc. NAACL-HLT}, 2019.
\bibitem{ref3} L. Lan et al., ``ALBERT: A Lite BERT for Self-supervised Learning of Language Representations,'' in \textit{Proc. ICLR}, 2020.
\end{thebibliography}

\end{document}
```

### 2.2 IEEE Transaction（期刊论文）

```latex
\documentclass[journal]{IEEEtran}
\usepackage{amsmath,amssymb,amsfonts}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{cite}
\usepackage{balance}   % 最后页双栏平衡

% 期刊论文通常为双栏，使用 balance 宏包使最后一页两列等高
\title{A Comprehensive Survey on Graph Neural Networks for Recommendation Systems}

\author{First~Author,~Second~Author,~and~Third~Author}

\begin{document}
\maketitle
% 同 conference 格式，但可以使用更多页面
% Transaction 论文通常 8-14 页
\end{document}
```

---

## 三、ACM 期刊/会议模板

### 3.1 ACM Conference

```latex
\documentclass[sigconf,nonacm]{acmart}

% ACM 模板设置
\setcopyright{none}
\doi{10.1145/0000000.0000000}

\title{Reinforcement Learning for Adaptive User Interface Design}

\author{Author Name}
\affiliation{
  \department{Department of Computer Science}
  \institution{University Name}
  \city{City}
  \country{Country}
}
\email{author@university.edu}

\begin{document}

\begin{abstract}
This paper explores the application of reinforcement learning ...
\end{abstract}

\begin{CCSXML}
<ccs2012>
<concept>
<concept_id>10010147.10010178.10010224</concept_id>
<concept_desc>Computing methodologies~Artificial intelligence</concept_desc>
<concept_significance>500</concept_significance>
</concept>
</ccs2012>
\end{CCSXML}

\ccsdesc[500]{Computing methodologies~Artificial intelligence}

\keywords{reinforcement learning, user interface, adaptive design}

\maketitle

\section{Introduction}
...

\end{document}
```

---

## 四、Springer 期刊模板

```latex
% 使用 svjour3 宏包（Springer 标准模板）
\documentclass[twocolumn]{svjour3}

\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{hyperref}
\usepackage{natbib}
\usepackage{cleveref}

% Springer 期刊信息
\journal{Machine Learning}
\date{Received: / Accepted:}

\title{Self-Supervised Pre-training for Visual Recognition}

\subtitle{A Unified Framework}

\titlerunning{Self-Supervised Pre-training}

\author{Author Name \and Second Author}

\institute{Author Name \at Department, University \\
\email{author@university.edu}
}

\date{}

\abstract{This paper presents a unified framework for self-supervised
pre-training in visual recognition tasks...}

\keywords{self-supervised learning \and visual recognition \and pre-training}

\maketitle

\section{Introduction}
\label{intro}
...

\section{Methodology}
\label{method}
...

\section{Experiments}
\label{exp}
...

\section{Conclusion}
\label{conclusion}
...

% Springer 使用 natbib 引用格式
\bibliographystyle{spbasic}
\bibliography{references}

\end{document}
```

---

## 五、Nature 风格论文模板

```latex
\documentclass[11pt]{article}
\usepackage[a4paper,margin=2.5cm]{geometry}
\usepackage{natbib}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage[colorlinks=true,linkcolor=blue,citecolor=blue,urlcolor=blue]{hyperref}

% Nature 风格配置
\usepackage{times}
\usepackage[mathletters]{ucs}
\usepackage[utf8x]{inputenc}

% Nature 式标题格式
\renewcommand{\abstractname}{\textbf{Abstract}}

\begin{document}

% Nature 使用无编号章节标题
\title{\textbf{\LARGE Title of the Paper}\\[6pt]
\large Author Names$^{1,*}$, Second Author$^{2}$\\[4pt]
\small $^{1}$Affiliation 1, $^{2}$Affiliation 2\\
\small *Corresponding author. Email: author@university.edu}

\date{}

\maketitle

\section*{Abstract}
Text here...

\vspace{1em}
\noindent\textbf{Main findings:} ...

\section*{Introduction}
...

\section*{Results}
...

\section*{Discussion}
...

\section*{Methods}
...

\section*{Data Availability}
...

\section*{Code Availability}
...

\section*{Acknowledgements}
...

\section*{Author Contributions}
...

\section*{Competing Interests}
...

\bibliographystyle{naturemag}
\bibliography{references}

\end{document}
```

---

## 六、BibTeX 文献管理

### 6.1 references.bib 文件示例

```bibtex
@article{vaswani2017attention,
  title   = {Attention is All You Need},
  author  = {Vaswani, Ashish and Shazeer, Noam and Parmar, Niki and Uszkoreit, Jakob and Jones, Llion and Gomez, Aidan N and Kaiser, {\L}ukasz and Polosukhin, Illia},
  journal = {Advances in Neural Information Processing Systems},
  volume  = {30},
  year    = {2017}
}

@inproceedings{devlin2019bert,
  title     = {{BERT}: Pre-training of Deep Bidirectional Transformers for Language Understanding},
  author    = {Devlin, Jacob and Chang, Ming-Wei and Lee, Kenton and Toutanova, Kristina},
  booktitle = {Proceedings of the 2019 Conference of the North American Chapter of the Association for Computational Linguistics},
  pages     = {4171--4186},
  year      = {2019}
}

@book{goodfellow2016deep,
  title     = {Deep Learning},
  author    = {Goodfellow, Ian and Bengio, Yoshua and Courville, Aaron},
  publisher = {MIT Press},
  year      = {2016}
}

@misc{wolf2020huggingface,
  title         = {{Transformers}: State-of-the-art Natural Language Processing},
  author        = {Wolf, Thomas and Debut, Lysandre and Sanh, Victor and Chaumond, Julien and Delangue, Clement and Moi, Anthony and Cistac, Pierric and Rault, Tim and Louf, R{\'e}mi and Funtowicz, Morgan and others},
  year          = {2020},
  eprint        = {1910.03771},
  archiveprefix = {arXiv},
  primaryclass  = {cs.CL}
}

@article{he2016deep,
  title   = {Deep Residual Learning for Image Recognition},
  author  = {He, Kaiming and Zhang, Xiangyu and Ren, Shaoqing and Sun, Jian},
  journal = {IEEE Conference on Computer Vision and Pattern Recognition},
  pages   = {770--778},
  year    = {2016}
}

@inproceedings{brown2020language,
  title     = {Language Models are Few-Shot Learners},
  author    = {Brown, Tom and Mann, Benjamin and Ryder, Nick and Subbiah, Melanie and Kaplan, Jared D and Dhariwal, Prafulla and Neelakantan, Arvind and Shyam, Pranav and Sastry, Girish and Askell, Amanda and others},
  booktitle = {Advances in Neural Information Processing Systems},
  volume    = {33},
  pages     = {1877--1901},
  year      = {2020}
}
```

### 6.2 BibTeX 条目类型

| 类型 | 用途 | 必填字段 |
|------|------|---------|
| `@article` | 期刊论文 | author, title, journal, year |
| `@inproceedings` | 会议论文 | author, title, booktitle, year |
| `@book` | 书籍 | author/title, publisher, year |
| `@incollection` | 书中章节 | author, title, booktitle, publisher, year |
| `@phdthesis` | 博士论文 | author, title, school, year |
| `@misc` | 其他 | author, title, year |
| `@techreport` | 技术报告 | author, title, institution, year |

### 6.3 引用样式对比

```latex
% IEEE 引用样式（数字编号）
\bibliographystyle{IEEEtran}
% [1], [2], [3]...

% ACM 引用样式
\bibliographystyle{ACM-Reference-Format}
% [Author 2020], [Author et al. 2021]...

% Nature 引用样式
\bibliographystyle{naturemag}
% 上标数字引用

% APA 引用样式（使用 natbib）
\bibliographystyle{apalike}
% (Author, Year), Author (Year)...

% Springer 引用样式
\bibliographystyle{spbasic}
% [1] Author, A.: Title. Journal Vol, Pages (Year)

% Chicago 引用样式
\bibliographystyle{chicagoa}
% 脚注式引用
```

### 6.4 文献管理工具

```latex
% LaTeX 中直接使用 DOI 自动生成引用
% 先访问 https://doi.org/10.xxx/xxx 获取 BibTeX
% 或使用以下工具：
% - JabRef（开源桌面端）
% - Zotero + Better BibTeX 插件
% - Mendeley
% - BibTeX Online（https://www.bibtex.org/）
```

---

## 七、数学公式排版

### 7.1 行内公式与行间公式

```latex
% 行内公式
模型参数 $\theta$ 通过最小化损失函数 $\mathcal{L}(\theta)$ 进行优化。

% 行间公式（无编号）
\[
\hat{y} = \sigma(Wx + b)
\]

% 行间公式（有编号）
\begin{equation}
\mathcal{L}_{\text{CE}} = -\frac{1}{N}\sum_{i=1}^{N} y_i \log(\hat{y}_i)
\label{eq:cross_entropy}
\end{equation}
```

### 7.2 常用数学环境

```latex
% align 环境（多行对齐，每行编号）
\begin{align}
\text{Attention}(Q, K, V) &= \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V
\label{eq:attention}\\
Q &= XW^Q, \quad K = XW^K, \quad V = XW^V
\label{eq:qkv}
\end{align}

% align* 环境（无编号）
\begin{align*}
\text{MultiHead}(Q, K, V) &= \text{Concat}(\text{head}_1, \ldots, \text{head}_h)W^O \\
\text{head}_i &= \text{Attention}(QW_i^Q, KW_i^K, VW_i^V)
\end{align*}

% split 环境（单公式内换行）
\begin{equation}
\begin{split}
\mathcal{L}_{\text{total}} &= \lambda_1 \mathcal{L}_{\text{cls}} + \lambda_2 \mathcal{L}_{\text{reg}} \\
&\quad + \lambda_3 \mathcal{L}_{\text{triplet}}
\end{split}
\label{eq:total_loss}
\end{equation}

% cases 环境
\begin{equation}
f(x) =
\begin{cases}
1 & \text{if } x > 0 \\
0 & \text{if } x = 0 \\
-1 & \text{if } x < 0
\end{cases}
\end{equation}
```

### 7.3 常用数学符号速查

```latex
% 集合与逻辑
\emptyset \quad \cup \quad \cap \quad \subset \quad \supset \quad \in \quad \notin
\forall \quad \exists \quad \neg \quad \Rightarrow \quad \Leftrightarrow

% 希腊字母（小写）
\alpha \quad \beta \quad \gamma \quad \delta \quad \epsilon \quad \zeta \quad \eta \quad \theta
\iota \quad \kappa \quad \lambda \quad \mu \quad \nu \quad \xi \quad \pi \quad \rho
\sigma \quad \tau \quad \upsilon \quad \phi \quad \chi \quad \psi \quad \omega

% 希腊字母（大写）
\Gamma \quad \Delta \quad \Theta \quad \Lambda \quad \Xi \quad \Pi \quad \Sigma \quad \Phi \quad \Psi \quad \Omega

% 运算符
\sum_{i=1}^{N} \quad \prod_{i=1}^{N} \quad \int_{a}^{b} \quad \oint
\nabla \quad \partial \quad \nabla^2 \quad \nabla \times

% 箭头与关系
\rightarrow \quad \leftarrow \quad \leftrightarrow \quad \Rightarrow \quad \Leftarrow
\mapsto \quad \hookrightarrow
\leq \quad \geq \quad \approx \quad \sim \quad \equiv \quad \cong

% 矩阵
A = \begin{bmatrix}
a_{11} & a_{12} & \cdots & a_{1n} \\
a_{21} & a_{22} & \cdots & a_{2n} \\
\vdots & \vdots & \ddots & \vdots \\
a_{m1} & a_{m2} & \cdots & a_{mn}
\end{bmatrix}

% 常用函数
\max \quad \min \quad \sup \quad \inf \quad \arg\max \quad \arg\min
\log \quad \exp \quad \sin \quad \cos \quad \tanh
\text{softmax} \quad \text{sigmoid}
```

### 7.4 深度学习常用公式

```latex
% 损失函数
\begin{equation}
\mathcal{L}_{\text{CE}} = -\sum_{c=1}^{C} y_c \log \hat{y}_c
\end{equation}

% Batch Normalization
\begin{equation}
\hat{x}_i = \frac{x_i - \mu_B}{\sqrt{\sigma_B^2 + \epsilon}}, \quad y_i = \gamma \hat{x}_i + \beta
\end{equation}

% Layer Normalization
\begin{equation}
\hat{x}_i = \frac{x_i - \mu_L}{\sqrt{\sigma_L^2 + \epsilon}}, \quad y_i = \gamma \hat{x}_i + \beta
\end{equation}

% Adam Optimizer
\begin{align}
m_t &= \beta_1 m_{t-1} + (1 - \beta_1) g_t \\
v_t &= \beta_2 v_{t-1} + (1 - \beta_2) g_t^2 \\
\theta_t &= \theta_{t-1} - \frac{\eta}{\sqrt{\hat{v}_t} + \epsilon} \hat{m}_t
\end{align}

% 交叉注意力
\begin{equation}
\text{CrossAttn}(Q, K, V) = \text{softmax}\left(\frac{QK^T}{\sqrt{d_k}}\right)V
\end{equation}

% Focal Loss
\begin{equation}
\mathcal{L}_{\text{FL}} = -\alpha_t (1 - p_t)^\gamma \log(p_t)
\end{equation}

% KL 散度
\begin{equation}
D_{\text{KL}}(P \| Q) = \sum_{i} P(i) \log \frac{P(i)}{Q(i)}
\end{equation}
```

---

## 八、图表格式化

### 8.1 三线表

```latex
\begin{table}[!t]
\caption{Performance Comparison on Benchmark Datasets}
\label{tab:performance}
\centering
\renewcommand{\arraystretch}{1.2}
\begin{tabular}{lcccc}
\toprule
\textbf{Model} & \textbf{Accuracy (\%)} & \textbf{F1 (\%)} & \textbf{AUC} & \textbf{Params (M)} \\
\midrule
Baseline A       & 78.2 & 76.5 & 0.843 & 12.4 \\
Baseline B       & 80.1 & 78.3 & 0.861 & 23.1 \\
Baseline C       & 81.5 & 80.2 & 0.874 & 45.6 \\
\midrule
\textbf{Ours-S}  & 83.7 & 82.4 & 0.891 & 14.2 \\
\textbf{Ours-B}  & 85.3 & 84.1 & 0.908 & 28.5 \\
\textbf{Ours-L}  & \textbf{87.1} & \textbf{85.9} & \textbf{0.923} & 52.3 \\
\bottomrule
\end{tabular}
\end{table}
```

### 8.2 双栏表格（横跨两栏）

```latex
\begin{table*}[!t]
\caption{Detailed Ablation Study Results}
\label{tab:ablation}
\centering
\renewcommand{\arraystretch}{1.2}
\begin{tabular}{lcccccc}
\toprule
& \multicolumn{2}{c}{\textbf{Dataset A}} & \multicolumn{2}{c}{\textbf{Dataset B}} & \multicolumn{2}{c}{\textbf{Dataset C}} \\
\cmidrule(lr){2-3} \cmidrule(lr){4-5} \cmidrule(lr){6-7}
\textbf{Configuration} & Acc & F1 & Acc & F1 & Acc & F1 \\
\midrule
w/o Cross-Attention  & 82.1 & 80.3 & 79.4 & 77.8 & 81.2 & 79.5 \\
w/o Pre-training     & 80.5 & 78.9 & 77.8 & 76.1 & 79.6 & 77.8 \\
w/o Augmentation     & 83.0 & 81.2 & 80.1 & 78.5 & 82.0 & 80.3 \\
\midrule
Full Model           & \textbf{85.3} & \textbf{84.1} & \textbf{82.7} & \textbf{81.0} & \textbf{84.5} & \textbf{82.8} \\
\bottomrule
\end{tabular}
\end{table*}
```

### 8.3 图片插入

```latex
% 单图
\begin{figure}[!t]
\centering
\includegraphics[width=0.45\textwidth]{figures/model_architecture.pdf}
\caption{Overall architecture of the proposed method. The model consists of
three modality-specific encoders and a cross-modal fusion module.}
\label{fig:architecture}
\end{figure}

% 并排图
\begin{figure}[!t]
\centering
\begin{subfigure}{0.24\textwidth}
  \centering
  \includegraphics[width=\textwidth]{figures/sample1.pdf}
  \caption{Input image}
  \label{fig:input}
\end{subfigure}
\hfill
\begin{subfigure}{0.24\textwidth}
  \centering
  \includegraphics[width=\textwidth]{figures/attention_map.pdf}
  \caption{Attention map}
  \label{fig:attention}
\end{subfigure}
\hfill
\begin{subfigure}{0.24\textwidth}
  \centering
  \includegraphics[width=\textwidth]{figures/feature_map.pdf}
  \caption{Feature map}
  \label{fig:feature}
\end{subfigure}
\hfill
\begin{subfigure}{0.24\textwidth}
  \centering
  \includegraphics[width=\textwidth]{figures/output.pdf}
  \caption{Output result}
  \label{fig:output}
\end{subfigure}
\caption{Visualization of intermediate results at different stages.}
\label{fig:visualization}
\end{figure}
```

### 8.4 图片格式要求

| 格式 | 适用场景 | 说明 |
|------|---------|------|
| PDF (矢量) | 架构图、流程图 | 推荐首选，无损缩放 |
| EPS | 兼容旧版 LaTeX | IEEE 推荐 |
| PNG | 截图、照片 | 位图，注意分辨率（≥300 DPI） |
| TIFF | 高质量位图 | 部分期刊要求 |
| JPG | 不推荐 | 有损压缩，可能模糊 |

---

## 九、算法伪代码

### 9.1 标准算法环境

```latex
\usepackage{algorithm}
\usepackage{algorithmic}

\begin{algorithm}[!t]
\caption{Cross-Modal Attention Fusion}
\label{alg:attention_fusion}
\begin{algorithmic}[1]
\REQUIRE Text features $F_t$, Visual features $F_v$, Number of heads $H$
\ENSURE Fused representation $F_{fused}$
\STATE Initialize $Q_t, K_t, V_t \leftarrow F_t$
\STATE Initialize $Q_v, K_v, V_v \leftarrow F_v$
\FOR{$h = 1$ to $H$}
  \STATE $A^{(h)}_{tv} \leftarrow \text{softmax}(Q_t^{(h)} {K_v^{(h)}}^T / \sqrt{d_k})$
  \STATE $A^{(h)}_{vt} \leftarrow \text{softmax}(Q_v^{(h)} {K_t^{(h)}}^T / \sqrt{d_k})$
  \STATE $C_t^{(h)} \leftarrow A^{(h)}_{tv} V_v^{(h)}$
  \STATE $C_v^{(h)} \leftarrow A^{(h)}_{vt} V_t^{(h)}$
\ENDFOR
\STATE $F_{fused} \leftarrow \text{Concat}(C_t, C_v) W^O$
\RETURN $F_{fused}$
\end{algorithmic}
\end{algorithm}
```

### 9.2 现代算法环境（algpseudocode）

```latex
\usepackage{algorithm}
\usepackage{algpseudocode}

\algrenewcommand\algorithmicrequire{\textbf{Input:}}
\algrenewcommand\algorithmicensure{\textbf{Output:}}

\begin{algorithm}[!t]
\caption{Multi-Modal Contrastive Learning}
\label{alg:contrastive}
\begin{algorithmic}[1]
\Require Mini-batch $\mathcal{B} = \{(t_i, v_i)\}_{i=1}^{N}$
\Ensure Updated encoders $f_t$, $f_v$
\State Sample positive pairs and negative pairs
\For{each training step}
    \State Compute text embeddings: $z_t^i = f_t(t_i)$
    \State Compute visual embeddings: $z_v^i = f_v(v_i)$
    \State Normalize: $\hat{z}_t^i \leftarrow z_t^i / \|z_t^i\|_2$
    \State Normalize: $\hat{z}_v^i \leftarrow z_v^i / \|z_v^i\|_2$
    \State Compute InfoNCE loss (Eq.~\ref{eq:infonce})
    \State Update $f_t, f_v$ via gradient descent
\EndFor
\end{algorithmic}
\end{algorithm}
```

---

## 十、定理与证明环境

```latex
\usepackage{amsthm}

% 定义定理环境（中文支持）
\newtheorem{theorem}{定理}[section]
\newtheorem{lemma}[theorem]{引理}
\newtheorem{proposition}[theorem]{命题}
\newtheorem{corollary}[theorem]{推论}
\newtheorem{definition}{定义}[section]
\newtheorem{example}{例}
\newtheorem{remark}{注}

% 使用示例
\begin{definition}[Cross-Modal Attention]
\label{def:cross_attention}
给定查询矩阵 $Q \in \mathbb{R}^{n \times d}$，键矩阵 $K \in \mathbb{R}^{m \times d}$，
和值矩阵 $V \in \mathbb{R}^{m \times d_v}$，交叉注意力定义如下：
\[
\text{CrossAttn}(Q, K, V) = \text{softmax}\left(\frac{QK^\top}{\sqrt{d}}\right)V
\]
其中 $d$ 为键向量的维度，用于缩放点积以防止梯度消失。
\end{definition}

\begin{theorem}[表示能力上界]
\label{thm:upper_bound}
对于任意的 $n$ 层交叉注意力网络 $f$，其逼近误差满足：
\begin{equation}
\|f(x) - f^*(x)\|_2 \leq \mathcal{O}\left(\frac{1}{\sqrt{n}}\right)
\end{equation}
其中 $f^*$ 为目标函数。
\end{theorem}

\begin{proof}
根据万能逼近定理和交叉注意力的性质，
对于任意 $\epsilon > 0$，存在 $n$ 使得...
因此命题得证。
\end{proof}

\begin{lemma}[收敛性]
\label{lem:convergence}
若学习率 $\eta_t$ 满足 $\sum_{t=1}^{\infty} \eta_t = \infty$ 且
$\sum_{t=1}^{\infty} \eta_t^2 < \infty$，则梯度下降算法以概率 1 收敛到局部最优解。
\end{lemma}
```

---

## 十一、中文论文支持

### 11.1 ctex 方案（推荐）

```latex
\documentclass[UTF8,a4paper,12pt]{ctexart}
\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{hyperref}
\usepackage[style=gb7714-2015]{biblatex}
\addbibresource{references.bib}

% 中文字体设置
\setCJKmainfont{Source Han Serif SC}      % 宋体
\setCJKsansfont{Source Han Sans SC}       % 黑体
\setCJKmonofont{Source Han Mono SC}       % 等宽

\title{基于图神经网络的社交网络推荐算法研究}
\author{张三 \\ 指导教师：李四教授}
\institute{清华大学计算机科学与技术系}

\begin{document}
\maketitle
\tableofcontents
\newpage

\begin{abstract}
本文研究了基于图神经网络的社交网络推荐算法。通过将用户-物品交互建模为异质图，
利用图注意力网络捕获高阶协同信号。实验表明...
\end{abstract}

\section{引言}
\label{sec:intro}

随着社交网络的快速发展...

\section{相关工作}
\label{sec:related}

\subsection{图神经网络}

图神经网络（Graph Neural Network, GNN）...

\section{方法}
\label{sec:method}

\section{实验}
\label{sec:exp}

\section{结论}
\label{sec:conclusion}

\printbibliography

\end{document}
```

### 11.2 xeCJK 方案

```latex
\documentclass[a4paper,12pt]{article}
\usepackage{xeCJK}

\setCJKmainfont{SimSun}        % Windows 宋体
\setCJKsansfont{SimHei}        % Windows 黑体
% macOS 用户使用：
% \setCJKmainfont{Songti SC}
% \setCJKsansfont{PingFang SC}

\usepackage{amsmath,amssymb}
\usepackage{graphicx}
\usepackage{booktabs}
\usepackage{geometry}
\geometry{left=3cm,right=3cm,top=3cm,bottom=3cm}

\title{中文论文标题}
\author{作者姓名}
\date{\today}

\begin{document}
\maketitle
...
\end{document}
```

### 11.3 中文参考文献格式（GB/T 7714）

```latex
% 使用 biblatex + gb7714-2015 样式
\usepackage[style=gb7714-2015,backend=biber]{biblatex}
\addbibresource{references.bib}

% 引用示例
根据张三等人的研究\cite{zhang2020gnn}...

% 对应的 bib 条目
@article{zhang2020gnn,
  author  = {张三 and 李四},
  title   = {基于图神经网络的推荐系统研究},
  journal = {计算机学报},
  volume  = {43},
  number  = {5},
  pages   = {876--890},
  year    = {2020}
}
```

---

## 十二、TikZ 绘图

### 12.1 神经网络架构图

```latex
\usepackage{tikz}
\usetikzlibrary{positioning, arrows.meta, shapes.geometric, fit, calc}

\begin{figure}[!t]
\centering
\begin{tikzpicture}[
    node distance=1.2cm,
    block/.style={rectangle, draw, rounded corners, minimum height=1cm,
                  minimum width=2cm, text centered, font=\small},
    arrow/.style={-Stealth, thick},
    dashed_arrow/.style={-Stealth, thick, dashed}
]

% 输入
\node[block, fill=blue!15] (input_t) {Text Input};
\node[block, fill=green!15, right=2cm of input_t] (input_v) {Visual Input};
\node[block, fill=orange!15, right=2cm of input_v] (input_a) {Audio Input};

% 编码器
\node[block, fill=blue!25, below=of input_t] (enc_t) {Text Encoder};
\node[block, fill=green!25, below=of input_v] (enc_v) {Visual Encoder};
\node[block, fill=orange!25, below=of input_a] (enc_a) {Audio Encoder};

% 融合模块
\node[block, fill=purple!25, below=1.5cm of enc_v, minimum width=6cm] (fusion) {Cross-Modal Fusion Module};

% 输出
\node[block, fill=red!25, below=of fusion] (classifier) {Sentiment Classifier};

% 连接
\draw[arrow] (input_t) -- (enc_t);
\draw[arrow] (input_v) -- (enc_v);
\draw[arrow] (input_a) -- (enc_a);
\draw[arrow] (enc_t) -- (fusion);
\draw[arrow] (enc_v) -- (fusion);
\draw[arrow] (enc_a) -- (fusion);
\draw[arrow] (fusion) -- (classifier);

% 残差连接
\draw[dashed_arrow] (enc_v.east) to[bend left=60] node[right, font=\scriptsize] {residual} (fusion.east);

\end{tikzpicture}
\caption{Architecture of the proposed cross-modal sentiment analysis framework.}
\label{fig:architecture}
\end{figure}
```

### 12.2 注意力热力图示意

```latex
\begin{figure}[!t]
\centering
\begin{tikzpicture}[font=\small]
  \matrix (m) [matrix of nodes, nodes in empty cells,
    column sep=2pt, row sep=2pt,
    row 1/.style={nodes={fill=gray!20, minimum width=1cm, minimum height=0.5cm}},
    column 1/.style={nodes={fill=gray!20, minimum width=1.5cm, minimum height=0.5cm}}]{
    & love & this & movie & very & much \\
    Text   & 0.8  & 0.3   & 0.9   & 0.4   & 0.6   \\
    Visual & 0.2  & 0.7   & 0.1   & 0.5   & 0.3   \\
    Audio  & 0.5  & 0.4   & 0.3   & 0.8   & 0.7   \\
  };
\end{tikzpicture}
\caption{Cross-modal attention weights visualization.}
\label{fig:attention_weights}
\end{figure}
```

### 12.3 流程图

```latex
\begin{figure}[!t]
\centering
\begin{tikzpicture}[
    node distance=1.5cm,
    process/.style={rectangle, draw, rounded corners, minimum width=3cm,
                    minimum height=1cm, text centered, fill=blue!10},
    decision/.style={diamond, draw, minimum width=2cm, aspect=2,
                     text centered, fill=yellow!20},
    arrow/.style={-Stealth, thick}
]

\node[process] (init) {初始化模型参数};
\node[process, below=of init] (forward) {前向传播计算损失};
\node[decision, below=of forward] (check) {收敛？};
\node[process, below=of check] (output) {输出最优模型};
\node[process, right=2cm of check] (update) {反向传播更新参数};

\draw[arrow] (init) -- (forward);
\draw[arrow] (forward) -- (check);
\draw[arrow] (check) -- node[above] {是} (output);
\draw[arrow] (check) -- node[above] {否} (update);
\draw[arrow] (update) |- (forward);

\end{tikzpicture}
\caption{Training procedure of the proposed model.}
\label{fig:training_flow}
\end{figure}
```

---

## 十三、常见 LaTeX 错误修复

| 错误信息 | 原因 | 解决方案 |
|---------|------|---------|
| `Undefined control sequence` | 宏包未加载或命令拼写错误 | 检查 `\usepackage` 和命令名称 |
| `Missing $ inserted` | 数学模式外使用了数学符号 | 用 `$...$` 或 `\[...\]` 包裹 |
| `Too many }'s` / `Missing } inserted` | 大括号不匹配 | 使用编辑器括号匹配功能检查 |
| `File not found` | 图片/文件路径错误 | 检查文件名和路径，使用相对路径 |
| `Overfull \hbox` | 行溢出 | 调整文本、使用 `\sloppy` 或换行 |
| `Citation undefined` | BibTeX 条目未找到 | 检查 `\cite` key 与 bib 条目匹配 |
| `Float too large` | 图表超过页面范围 | 调整 width 参数或使用 `[!p]` |
| `Font substitution` | 字体缺失 | 安装缺失字体或更换字体 |
| `Input encoding error` | 编码问题 | 使用 UTF-8 编码，加载 `inputenc` |
| `Table/Figure float lost` | 浮动体无法放置 | 使用 `[!htbp]` 或调整位置 |

---

## 十四、学术写作风格指南

### 14.1 IEEE 写作规范

- **人称**：使用第三人称或被动语态，避免 "we"（除非表示作者）
- **时态**：相关工作用过去时，方法描述用现在时
- **缩写**：首次出现时给出全称，如 "Graph Neural Network (GNN)"
- **公式**：每个公式都要引用和解释
- **图表**：每个图表都要有 Caption 和引用

### 14.2 APA 写作规范

- **人称**：鼓励使用主动语态，"we" 可接受
- **引用**：作者-年份体系 (Smith, 2020)
- **段落**：首行缩进，双倍行距
- **标题层级**：五级标题层次

### 14.3 中文论文写作规范

- **标题**：简洁明了，不超过 20 个汉字
- **摘要**：200-500 字，包含目的、方法、结果、结论
- **关键词**：3-8 个，用分号分隔
- **参考文献**：遵循 GB/T 7714 格式
- **图表**：中文标题，表在上图在下
- **编号**：章节编号如 "1"、"1.1"、"1.1.1"

---

## 十五、同行评审回复模板

```latex
% review_response.tex
\documentclass[11pt]{article}
\usepackage[a4paper,margin=2.5cm]{geometry}
\usepackage{hyperref}
\usepackage{xcolor}
\usepackage{enumitem}

\title{Response to Reviewers\\[6pt]
\normalsize Paper Title: ``基于深度学习的多模态情感分析''\\
Submission ID: XXX-2025-0123}

\author{Authors}

\begin{document}
\maketitle

\section*{General Comments}

We sincerely thank all reviewers for their constructive feedback.
Below we address each comment in detail.

\section*{Response to Reviewer 1}

\noindent\textbf{Comment 1:} The authors should provide more ablation studies to validate the contribution of each component.

\noindent\textbf{Response:} Thank you for this valuable suggestion. We have added a comprehensive ablation study in Section 4.4 (revised manuscript), which evaluates the contribution of each module:
\begin{itemize}[leftmargin=*]
    \item Cross-modal attention module: +3.2\% accuracy improvement
    \item Pre-training strategy: +2.1\% accuracy improvement
    \item Data augmentation: +1.5\% accuracy improvement
\end{itemize}
Please refer to Table~5 in the revised manuscript for detailed results.

\vspace{1em}
\noindent\textbf{Comment 2:} The comparison with recent SOTA methods is insufficient.

\noindent\textbf{Response:} We have updated the comparison to include three recent methods published in 2024:
\begin{itemize}[leftmargin=*]
    \item MISA++ (ACL 2024)
    \item UniMSE (EMNLP 2024)
    \item MulT-Large (NeurIPS 2024)
\end{itemize}
Our method still achieves the best performance. Please refer to Table~3 in the revised manuscript.

\section*{Response to Reviewer 2}

\noindent\textbf{Comment 1:} The writing quality needs improvement.

\noindent\textbf{Response:} We have thoroughly revised the manuscript for clarity and correctness:
\begin{itemize}[leftmargin=*]
    \item Rewrote Section 3.2 for clearer explanation of the fusion mechanism
    \item Added more transition sentences between sections
    \item Fixed grammatical errors and improved sentence structures
    \item The manuscript has been proofread by a native English speaker
\end{itemize}

\vspace{1em}
\noindent\textbf{Comment 2:} Please clarify the computational cost.

\noindent\textbf{Response:} We have added computational cost analysis in Section 4.5:
\begin{itemize}[leftmargin=*]
    \item Training time: 4.2 hours on a single NVIDIA A100 GPU
    \item Inference speed: 128 samples/second
    \item Memory footprint: 2.1 GB during inference
\end{itemize}

\end{document}
```

---

## 快速参考

| 需求 | 推荐命令/宏包 |
|------|-------------|
| **期刊论文** | IEEEtran / svjour3 / acmart |
| **数学公式** | amsmath, amssymb, amsthm |
| **三线表** | booktabs (`\toprule`, `\midrule`, `\bottomrule`) |
| **算法伪代码** | algorithm + algpseudocode |
| **绘图** | tikz + 相关 library |
| **中文支持** | ctex 或 xeCJK |
| **文献管理** | biblatex + biber 或 natbib + bibtex |
| **交叉引用** | hyperref + cleveref |
| **代码高亮** | listings 或 minted |
| **Unicode** | inputenc (pdfLaTeX) 或直接使用 XeLaTeX/LuaLaTeX |
