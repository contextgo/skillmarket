# LaTeX 学术论文写作工具

> 全面的 LaTeX 学术写作辅助工具，支持主流期刊模板、数学公式排版、文献管理、TikZ 绘图和中文论文写作。

## 简介

LaTeX 学术论文写作工具为科研人员和学生提供一站式的 LaTeX 论文写作支持。从论文结构搭建到期刊模板适配，从数学公式到科技绘图，从文献管理到同行评审回复，覆盖学术论文写作的完整生命周期。

## 核心功能

### 📄 期刊模板
- **IEEE**：会议论文（conference）和期刊论文（journal）模板
- **ACM**：acmart 宏包的会议和期刊模板
- **Springer**：svjour3 标准期刊模板
- **Nature**：Nature 风格论文格式

### 📚 文献管理
- BibTeX 条目编写（@article, @inproceedings, @book 等）
- 多种引用样式对比（IEEE、ACM、APA、Chicago、Springer）
- GB/T 7714 中文参考文献格式（biblatex + biber）
- 文献管理工具推荐（JabRef、Zotero、Mendeley）

### 🔢 数学公式
- 行内公式与行间公式
- align / split / cases 等多行公式环境
- 希腊字母、集合符号、运算符速查表
- 深度学习常用公式模板（损失函数、注意力、优化器等）

### 📊 图表格式化
- 三线表（booktabs）和双栏跨表
- 单图、并排图（subfigure）插入
- 图片格式要求与推荐

### ⚙️ 算法伪代码
- algorithm + algorithmic 标准环境
- algorithm + algpseudocode 现代环境
- 自定义 Input/Output 标签

### 📐 TikZ 科技绘图
- 神经网络架构图
- 注意力热力图可视化
- 流程图（决策节点、循环）

### 🇨🇳 中文论文支持
- ctex 宏包方案（推荐）
- xeCJK 方案
- 中文参考文献 GB/T 7714 格式

### 📝 定理与证明
- 自定义中文定理环境（定理、引理、推论、定义等）
- proof 环境

### 🛠️ 错误修复
- 常见 LaTeX 编译错误速查表
- 精确的问题诊断和解决方案

### ✍️ 写作风格指南
- IEEE、APA、Chicago 写作规范对比
- 中文论文写作规范（标题、摘要、关键词、参考文献）

### 📮 同行评审回复
- 标准化的 Reviewer Response 模板
- 逐条回复格式与措辞建议

## 使用场景

1. **撰写期刊论文**：选择对应期刊模板，快速搭建论文框架
2. **数学公式排版**：查阅公式模板和符号速查表，高效排版复杂公式
3. **中文毕业论文**：使用 ctex 宏包配合 GB/T 7714 文献格式
4. **会议投稿**：IEEE/ACM 会议模板一键适配
5. **回复审稿人**：使用标准化模板组织回复内容
6. **绘制论文插图**：TikZ 架构图、流程图和可视化

## 配置说明

### 推荐编译引擎

| 引擎 | 适用场景 |
|------|---------|
| **XeLaTeX** | 中文论文、系统字体支持（推荐） |
| **LuaLaTeX** | 复杂脚本、Unicode 支持 |
| **pdfLaTeX** | 纯英文论文、编译速度快 |

### 必要宏包

```bash
# TeX Live 完整安装
sudo apt-get install texlive-full

# 最小安装（推荐常用宏包）
sudo apt-get install texlive-latex-extra texlive-science texlive-fonts-extra texlive-lang-chinese
```

### 编辑器推荐

- **VS Code** + LaTeX Workshop 插件
- **Overleaf**（在线协作，零配置）
- **TeXstudio**（桌面端，功能丰富）
- **Typst**（新一代排版系统，可参考）

## 作者

知白守黑1024
