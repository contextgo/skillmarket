# PinchTab 浏览器自动化技能

> **专为 AI Agent 设计的浏览器控制 API**

---

## 📖 概述

PinchTab 是一个独立的 HTTP 服务器，让 AI Agent 直接控制 Chrome 浏览器。

### 核心特性

- ✅ **12MB Go 二进制** - 轻量级，高性能
- ✅ **HTTP API** - RESTful 接口，易于调用
- ✅ **Token 高效** - 优化 token 使用（800 tokens vs 10,000）