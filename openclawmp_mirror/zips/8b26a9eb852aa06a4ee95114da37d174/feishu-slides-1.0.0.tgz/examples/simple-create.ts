---
name: feishu-slides
description: "飞书幻灯片技能：用API创建、编辑和管理飞书演示文稿"
version: "1.0.0"
allowed-tools: Read, Write, Edit
---

# 示例：创建三年级英语PPT

import { createFeishuSlides } from 'feishu-slides';

const slides = createFeishuSlides();

// 1. 创建演示文稿
const pid = await slides.create({
  title: '三年级英语上册',
  folderToken: 'fld_xxx' // 可选
});

// 2. 添加封面页
await slides.addText(pid, await slides.addPage(pid, { title: 'Cover' }), '三年级英语上册\nUnit 1 Hello!');

// 3. 添加单词表格页
const wordsPageId = await slides.addPage(pid, { title: '学习用品' });
await slides.addTable(pid, wordsPageId, {
  rows: 6,
  cols: 3,
  data: [
    ['中文', '英文', '音标'],
    ['铅笔', 'pencil', '/ˈpensl/'],
    ['钢笔', 'pen', '/pen/'],
    ['橡皮', 'eraser', '/ɪˈreɪsər/'],
    ['尺子', 'ruler', '/ˈruːlər/'],
    ['书包', 'bag', '/bæɡ/']
  ]
});

// 4. 导出
const result = await slides.export(pid, { format: 'pptx' });
console.log('下载:', result.downloadUrl);
