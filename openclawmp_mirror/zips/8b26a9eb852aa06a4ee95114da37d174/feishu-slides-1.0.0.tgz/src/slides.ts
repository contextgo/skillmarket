/**
 * Feishu Slides Manager
 *
 * 飞书幻灯片操作核心类
 */

import type {
  SlidesConfig,
  SlidePage,
  TextBlock,
  TableBlock,
  SlidesCreateOptions,
  SlidesExportOptions,
  SlidesExportResult,
  SlidesManagerConfig
} from './types';

export class SlidesError extends Error {
  constructor(
    message: string,
    public code?: string,
    public details?: any
  ) {
    super(message);
    this.name = 'SlidesError';
  }
}

export class SlidesManager {
  private config: SlidesManagerConfig;
  private token?: string;
  private tokenExpire?: number;

  constructor(config: SlidesManagerConfig = {}) {
    this.config = {
      apiBase: 'https://open.feishu.cn',
      debug: false,
      ...config
    };
  }

  /**
   * 获取 tenant access token
   */
  private async getToken(): Promise<string> {
    if (this.token && this.tokenExpire && Date.now() < this.tokenExpire) {
      return this.token;
    }

    const { appId, appSecret } = this.config;
    if (!appId || !appSecret) {
      throw new SlidesError('需要配置 appId 和 appSecret');
    }

    const resp = await fetch(`${this.config.apiBase}/open-apis/auth/v3/tenant_access_token/internal`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ app_id: appId, app_secret: appSecret })
    });

    const data = await resp.json();
    if (data.code !== 0) {
      throw new SlidesError('获取 token 失败', data.code, data);
    }

    this.token = data.tenant_access_token;
    this.tokenExpire = Date.now() + (data.expire - 60) * 1000;
    return this.token!;
  }

  /**
   * 请求封装
   */
  private async request(path: string, options: RequestInit = {}): Promise<any> {
    const token = await this.getToken();
    const url = `${this.config.apiBase}${path}`;

    const headers: Record<string, string> = {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json',
      ...(options.headers as Record<string, string>)
    };

    const resp = await fetch(url, {
      ...options,
      headers
    });

    const data = await resp.json();
    if (data.code !== 0) {
      throw new SlidesError(data.msg || '请求失败', data.code, data);
    }

    return data.data;
  }

  /**
   * 创建演示文稿
   */
  async create(options: SlidesCreateOptions): Promise<string> {
    const { title, templateToken, folderToken } = options;

    const body: any = {
      title,
      folder_token: folderToken || this.config.folderToken
    };

    if (templateToken) {
      body.template_token = templateToken;
    }

    const data = await this.request('/open-apis/slides/v1/presentations/create', {
      method: 'POST',
      body: JSON.stringify(body)
    });

    return data.presentation_token; // 或 presentation_id
  }

  /**
   * 添加页面
   */
  async addPage(presentationId: string, page: SlidePage): Promise<string> {
    const body: any = {};

    if (page.title) {
      body.title = page.title;
    }

    if (page.layout) {
      body.slide_layout = page.layout;
    }

    const data = await this.request(`/open-apis/slides/v1/presentations/${presentationId}/pages/create`, {
      method: 'POST',
      body: JSON.stringify(body)
    });

    return data.page_token;
  }

  /**
   * 添加文本元素
   */
  async addText(presentationId: string, pageId: string, text: string, options: Partial<TextBlock> = {}): Promise<string> {
    const body: any = {
      element_type: 'text',
      text_content: text
    };

    if (options.x !== undefined && options.y !== undefined) {
      body.bbox = {
        x: options.x,
        y: options.y,
        width: options.width || 5,
        height: options.height || 1
      };
    }

    const data = await this.request(`/open-apis/slides/v1/presentations/${presentationId}/pages/${pageId}/elements/create`, {
      method: 'POST',
      body: JSON.stringify(body)
    });

    return data.element_token;
  }

  /**
   * 添加表格元素
   */
  async addTable(presentationId: string, pageId: string, table: TableBlock): Promise<string> {
    const body: any = {
      element_type: 'table',
      rows: table.rows,
      columns: table.cols
    };

    if (table.x !== undefined && table.y !== undefined) {
      body.bbox = {
        x: table.x,
        y: table.y,
        width: table.width || 6,
        height: table.height || 3
      };
    }

    // 填充单元格数据（需要在创建后调用更新接口）
    const data = await this.request(`/open-apis/slides/v1/presentations/${presentationId}/pages/${pageId}/elements/create`, {
      method: 'POST',
      body: JSON.stringify(body)
    });

    // 如果有数据，填充表格
    if (table.data.length > 0) {
      await this.updateTableContent(presentationId, pageId, data.element_token, table.data);
    }

    return data.element_token;
  }

  /**
   * 更新表格内容
   */
  private async updateTableContent(presentationId: string, pageId: string, elementToken: string, data: string[][]): Promise<void> {
    await this.request(`/open-apis/slides/v1/presentations/${presentationId}/pages/${pageId}/elements/${elementToken}/table/content/update`, {
      method: 'POST',
      body: JSON.stringify({ table_data: data })
    });
  }

  /**
   * 导出演示文稿
   */
  async export(presentationId: string, options: SlidesExportOptions): Promise<SlidesExportResult> {
    const body: any = {
      file_type: options.format === 'pdf' ? 'pdf' : 'pptx'
    };

    if (options.pageRange) {
      body.page_range = options.pageRange;
    }

    const data = await this.request(`/open-apis/slides/v1/presentations/${presentationId}/export`, {
      method: 'POST',
      body: JSON.stringify(body)
    });

    return {
      fileToken: data.file_token,
      downloadUrl: data.download_url,
      size: data.size
    };
  }

  /**
   * 分享演示文稿（设置权限）
   */
  async share(presentationId: string, userIds: string[], perm: 'view' | 'edit' = 'view'): Promise<void> {
    await this.request(`/open-apis/slides/v1/presentations/${presentationId}/permission/members/batch_create`, {
      method: 'POST',
      body: JSON.stringify({
        member_ids: userIds,
        permission: perm
      })
    });
  }
}

/**
 * 快速创建函数
 */
export async function createSlides(options: SlidesCreateOptions, config?: SlidesConfig): Promise<string> {
  const manager = new SlidesManager(config);
  return manager.create(options);
}

export async function addTextSlide(presentationId: string, title: string, content: string, config?: SlidesConfig): Promise<void> {
  const manager = new SlidesManager(config);
  const pageId = await manager.addPage(presentationId, { title, layout: 'text' });
  await manager.addText(presentationId, pageId, content);
}

export async function addTableSlide(presentationId: string, title: string, tableData: string[][], config?: SlidesConfig): Promise<void> {
  const manager = new SlidesManager(config);
  const pageId = await manager.addPage(presentationId, { title, layout: 'table' });
  await manager.addTable(presentationId, pageId, { rows: tableData.length, cols: tableData[0].length, data: tableData });
}

export async function exportSlides(presentationId: string, format: 'pptx' | 'pdf', config?: SlidesConfig): Promise<SlidesExportResult> {
  const manager = new SlidesManager(config);
  return manager.export(presentationId, { format });
}
