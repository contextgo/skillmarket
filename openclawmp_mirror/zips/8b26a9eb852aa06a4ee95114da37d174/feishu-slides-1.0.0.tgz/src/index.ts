/**
 * Feishu Slides Skill
 *
 * 飞书幻灯片操作技能
 * 支持创建、编辑、导出演示文稿
 *
 * @author GOGO AI Assistant
 * @version 1.0.0
 */

export type {
  SlidesConfig,
  SlidePage,
  TextBlock,
  TableBlock,
  ImageBlock,
  SlidesCreateOptions,
  SlidesExportOptions
} from './types';

export {
  SlidesManager,
  SlidesError,
  createSlides,
  addTextSlide,
  addTableSlide,
  exportSlides
} from './slides';

// 主入口
import { SlidesManager } from './slides';

/**
 * 创建飞书幻灯片技能实例
 *
 * @param config - 配置（appId, appSecret, folderToken 可选）
 * @returns SlidesManager 实例
 */
export function createFeishuSlides(config: any = {}): SlidesManager {
  return new SlidesManager(config);
}

export default {
  createFeishuSlides,
  SlidesManager
};
