/**
 * 飞书幻灯片技能类型定义
 */

export interface SlidesConfig {
  /** 飞书应用 App ID */
  appId?: string;
  /** 飞书应用 App Secret */
  appSecret?: string;
  /** 默认保存文件夹 token */
  folderToken?: string;
  /** API 基础 URL */
  apiBase?: string;
}

export interface SlidePage {
  /** 页面 ID */
  pageId?: string;
  /** 页面标题 */
  title?: string;
  /** 页面元素列表 */
  elements: SlideElement[];
  /** 页面布局 */
  layout?: 'blank' | 'title' | 'text' | 'two-column' | 'picture';
}

export type SlideElement =
  | TextBlock
  | TableBlock
  | ImageBlock;

export interface TextBlock {
  type: 'text';
  content: string;
  /** 字体大小（pt） */
  fontSize?: number;
  /** 对齐方式 */
  align?: 'left' | 'center' | 'right';
  /** 是否加粗 */
  bold?: boolean;
  /** x 坐标（英寸） */
  x?: number;
  /** y 坐标（英寸） */
  y?: number;
  /** 宽度 */
  width?: number;
  /** 高度 */
  height?: number;
}

export interface TableBlock {
  type: 'table';
  rows: number;
  cols: number;
  data: string[][];
  /** x 坐标 */
  x?: number;
  /** y 坐标 */
  y?: number;
  /** 表格宽度 */
  width?: number;
  /** 表格高度 */
  height?: number;
}

export interface ImageBlock {
  type: 'image';
  /** 图片 URL 或 key */
  src: string;
  /** x 坐标 */
  x?: number;
  /** y 坐标 */
  y?: number;
  /** 宽度 */
  width?: number;
  /** 高度 */
  height?: number;
}

export interface SlidesCreateOptions {
  /** 演示文稿标题 */
  title: string;
  /** 初始页面列表 */
  pages?: SlidePage[];
  /** 模板 token（可选） */
  templateToken?: string;
  /** 保存到文件夹 */
  folderToken?: string;
}

export interface SlidesExportOptions {
  /** 导出格式 */
  format: 'pptx' | 'pdf';
  /** 页面范围（默认全部） */
  pageRange?: string;
}

export interface SlidesExportResult {
  /** 文件 token */
  fileToken: string;
  /** 下载链接 */
  downloadUrl: string;
  /** 文件大小 */
  size?: number;
}

export interface SlidesManagerConfig extends SlidesConfig {
  /** 是否启用调试日志 */
  debug?: boolean;
}
