# Feishu Slides Skill

飞书幻灯片（在线PPT）技能 - 通过API创建和管理演示文稿

## 快速开始

### 安装

```bash
openclawmp install skill/@u-ad87dc7556674039b0d5/feishu-slides
```

### 基础使用

创建空演示文稿：
```typescript
import { createFeishuSlides } from 'feishu-slides';

const slides = createFeishuSlides({
  appId: 'your_app_id',
  appSecret: 'your_app_secret'
});

// 创建空白PPT
const presentationId = await slides.create({
  title: '三年级英语课程',
  folderToken: 'optional_folder_token' // 可选
});

// 添加文本页
await slides.addTextPage(presentationId, '第一页标题', '这是页面内容...');

// 导出为PPTX
const result = await slides.export(presentationId, { format: 'pptx' });
console.log('下载链接:', result.downloadUrl);
```

## 功能特性

- ✅ 从空白页或模板创建演示文稿
- ✅ 添加/删除/重排幻灯片页面
- ✅ 插入文本、表格、图片
- ✅ 导出为 PPTX 或 PDF
- ✅ 设置分享权限

## API 参考

### `SlidesManager`

主要方法：

- `create(options): Promise<string>` - 创建演示文稿，返回 presentationId
- `addPage(presentationId, page): Promise<string>` - 添加页面
- `addText(presentationId, pageId, text, options): Promise<string>` - 添加文本
- `addTable(presentationId, pageId, table): Promise<string>` - 添加表格
- `export(presentationId, options): Promise<ExportResult>` - 导出文件
- `share(presentationId, userIds, perm): Promise<void>` - 设置分享权限

详细类型定义见 `src/types.ts`。

## 配置

技能需要飞书应用的 `appId` 和 `appSecret`，以及可选的 `folderToken`（保存位置）。

推荐通过环境变量配置：
```bash
export FEISHU_APP_ID=your_app_id
export FEISHU_APP_SECRET=your_app_secret
```

或在使用时传入配置对象。

## 开发

```bash
# 安装依赖
npm install

# 编译
npm run build

# 测试
npm test
```

## License

MIT
