---
name: feishu-slides
description: "飞书幻灯片（在线PPT）技能：用API创建、编辑和管理飞书演示文稿。支持从模板新建、添加页面、插入文本/表格/图片、导出为PPTX/PDF。"
version: "1.0.0"
allowed-tools:
  - Read
  - Write
  - Edit
metadata:
  trigger: "用户需要创建飞书幻灯片、在线PPT、演示文稿"
  source: "基于飞书 OpenAPI v3 开发"
  examples:
    - "创建一个关于三年级英语的飞书PPT"
    - "帮我生成产品介绍幻灯片"
    - "把这个数据做成在线演示文稿"
    - "导出PPT为PDF"
---

# Feishu Slides Skill

通过API操作飞书在线幻灯片（Slides），支持创建、编辑、导出完整工作流。

## 核心功能

- 🆕 **创建演示文稿**：从模板或空白页新建
- 📄 **页面管理**：添加/删除/重排页面
- 📝 **内容编辑**：插入文本、表格、图片、形状
- 🎨 **样式控制**：字体、颜色、对齐、背景
- 📤 **导出**：下载为 PPTX 或 PDF
- 🔗 **分享权限**：设置可见范围

## 快速开始

```bash
# 安装技能
openclawmp install skill/@u-ad87dc7556674039b0d5/feishu-slides

# 创建空PPT
@GOGO 使用 feishu-slides 创建幻灯片 "我的演示" 模板 blank
```

详细文档见 `docs/` 目录。

## 技术栈

- 飞书 OpenAPI v3 (Slides)
- OpenClaw Skill SDK
- TypeScript
