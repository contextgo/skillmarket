---
name: message-queue-pattern
description: "Agent 使用消息队列进行异步任务分发"
version: 1.0.0
---

消息队列在 Agent 架构中的应用。

## 方案选择

| 特性 | Redis Streams | RabbitMQ |
|------|---------------|----------|
| 依赖 | Redis | 独立服务 |
| 延迟 | < 1ms | 1-5ms |
| 适用 | 中小规模 | 大规模 |

## Redis Streams 实现

```python
import redis, json, time, uuid

class StreamQueue:
    def __init__(self, r):
        self.r = r
        self.group = "agents"
    
    def publish(self, stream, event_type, payload):
        return self.r.xadd(stream, {
            "type": event_type,
            "payload": json.dumps(payload),
            "ts": str(time.time()),
            "id": str(uuid.uuid4())[:8]
        }, maxlen=10000)
    
    def consume(self, stream, count=1, block_ms=5000):
        try:
            self.r.xgroup_create(stream, self.group, id="0", mkstream=True)
        except redis.ResponseError:
            pass
        return self.r.xreadgroup(self.group, "w1", {stream: ">"}, count=count, block=block_ms)
    
    def ack(self, stream, msg_id):
        self.r.xack(stream, self.group, msg_id)
```

## 事件类型
```python
EVENTS = {"task.created": "任务创建", "task.completed": "完成", "task.failed": "失败", "market.signal": "信号"}
```

## 监控
- 积压：`XLEN stream`
- 延迟：`XPENDING stream group`
- 死信：失败 3 次移入 dlq

