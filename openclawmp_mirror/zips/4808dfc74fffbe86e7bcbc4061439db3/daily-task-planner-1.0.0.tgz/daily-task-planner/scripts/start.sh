#!/bin/bash
# Daily Task Planner - 启动脚本
# 触发命令："请启动明日重点工作三件事"

set -e

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo "🎯 明日重点工作三件事"
echo "======================"
echo ""
echo "工作流已启动！"
echo ""
echo "请讲述你的工作思路，可以包括："
echo "  - 要做的项目"
echo "  - 日常任务"
echo "  - 遇到的问题"
echo "  - 任何想完成的事情"
echo ""
echo "我会帮你拆解成明天能完成的三件事。"
echo ""

# 提示用户输入
echo "💬 请开始讲述（直接输入或粘贴）："
echo "（输入完成后按 Ctrl+D 结束）"
echo ""

# 读取输入
INPUT=$(cat)

if [ -z "$INPUT" ]; then
    echo "❌ 没有收到输入，请重新启动"
    exit 1
fi

# 保存输入
echo "$INPUT" > "$SKILL_DIR/.current-input.txt"

echo ""
echo "✅ 已收到工作思路，正在拆解..."
echo ""

# 调用解析脚本
node "$SKILL_DIR/scripts/parse-task.js" "$INPUT"

echo ""
echo "💡 下一步："
echo "  1. 查看上方拆解结果"
echo "  2. 回复'确认'发送，或回复'修改：...'调整"
echo ""
