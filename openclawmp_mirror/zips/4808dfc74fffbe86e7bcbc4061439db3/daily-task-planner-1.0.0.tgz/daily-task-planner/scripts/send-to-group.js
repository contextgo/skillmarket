#!/usr/bin/env node
/**
 * Daily Task Planner - 发送到规划群脚本 v1.3.1
 * 支持自动获取确认人昵称
 */

const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const SKILL_DIR = path.dirname(__dirname);
const CONFIG_FILE = path.join(SKILL_DIR, 'config', 'config.yaml');
const LAST_PARSED = path.join(SKILL_DIR, '.last-parsed.json');
const CONFIRM_RECORD = path.join(SKILL_DIR, '.confirm-record.json');

// 加载配置
function loadConfig() {
  try {
    const configContent = fs.readFileSync(CONFIG_FILE, 'utf-8');
    const config = {};
    const lines = configContent.split('\n');
    let currentSection = '';
    
    lines.forEach(line => {
      if (line.includes('planning_group:')) currentSection = 'planning_group';
      if (line.includes('id:')) {
        const match = line.match(/id:\s*"([^"]+)"/);
        if (match && currentSection === 'planning_group') {
          config.planning_group = { id: match[1] };
        }
      }
    });
    
    return config;
  } catch (e) {
    return { planning_group: { id: '' } };
  }
}

// 加载上次解析的任务
function loadLastParsed() {
  if (!fs.existsSync(LAST_PARSED)) {
    console.error('❌ 没有找到已解析的任务，请先运行 parse-task.js');
    process.exit(1);
  }
  return JSON.parse(fs.readFileSync(LAST_PARSED, 'utf-8'));
}

// 记录确认信息（在确认时调用）
function recordConfirmation(userName, userId) {
  const record = {
    confirmedBy: userName,
    confirmedById: userId,
    confirmedAt: new Date().toISOString()
  };
  fs.writeFileSync(CONFIRM_RECORD, JSON.stringify(record, null, 2));
  console.log('✅ 已记录确认人:', userName);
}

// 获取确认人信息
function getConfirmInfo() {
  // 1. 优先从确认记录文件读取
  if (fs.existsSync(CONFIRM_RECORD)) {
    const record = JSON.parse(fs.readFileSync(CONFIRM_RECORD, 'utf-8'));
    return {
      name: record.confirmedBy || '八总',
      id: record.confirmedById || ''
    };
  }
  
  // 2. 默认返回八总
  return { name: '八总', id: '' };
}

// 生成群消息
function generateGroupMessage(data, confirmInfo) {
  const { top3 } = data;
  const confirmedBy = confirmInfo.name;
  const atUser = confirmInfo.id ? `<at id="${confirmInfo.id}"></at>` : '';
  
  let message = '';
  
  message += `📋 ${confirmedBy}明日任务（已确认）\n\n`;
  message += '🔴 今日重点三件事：\n';
  
  top3.forEach(task => {
    message += `${task.order}. ${task.title}（截止：${task.deadline}）\n`;
  });
  
  message += '\n📊 四象限分布：\n';
  message += '- 重要且紧急：' + (data.tasks?.quadrant?.urgent_important?.length || 0) + '\n';
  message += '- 重要不紧急：' + (data.tasks?.quadrant?.important?.length || 0) + '\n';
  
  message += '\n⏰ 下次提醒：12:00';
  message += `\n\n---\n✅ 已由${confirmedBy}确认 | 🎱 小八生成`;
  
  return message;
}

// 发送到飞书群
function sendToFeishu(groupId, message) {
  try {
    const cmd = `openclaw message send --target "${groupId}" "${message.replace(/"/g, '\\"')}"`;
    execSync(cmd, { stdio: 'inherit' });
    return true;
  } catch (e) {
    console.error('❌ 发送失败:', e.message);
    return false;
  }
}

// 主函数
function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  // 如果是记录确认人
  if (command === '--record') {
    const userName = args[1] || '八总';
    const userId = args[2] || '';
    recordConfirmation(userName, userId);
    return;
  }
  
  // 正常发送流程
  let confirmedBy = args[0];
  let atUser = '';
  
  // 解析参数
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--by' && i + 1 < args.length) {
      confirmedBy = args[i + 1];
      i++;
    } else if (args[i] === '--at' && i + 1 < args.length) {
      atUser = args[i + 1];
      i++;
    }
  }
  
  // 获取确认人信息
  let confirmInfo;
  if (confirmedBy) {
    confirmInfo = { name: confirmedBy, id: atUser };
  } else {
    confirmInfo = getConfirmInfo();
  }
  
  const config = loadConfig();
  const data = loadLastParsed();
  
  const groupId = config.planning_group?.id;
  if (!groupId) {
    console.error('❌ 未配置规划群ID');
    process.exit(1);
  }
  
  const message = generateGroupMessage(data, confirmInfo);
  
  console.log('📤 准备发送...');
  console.log('确认人:', confirmInfo.name);
  console.log('');
  console.log('消息预览：');
  console.log('---');
  console.log(message);
  console.log('---');
  
  if (sendToFeishu(groupId, message)) {
    console.log('✅ 发送成功！');
  }
}

main();
