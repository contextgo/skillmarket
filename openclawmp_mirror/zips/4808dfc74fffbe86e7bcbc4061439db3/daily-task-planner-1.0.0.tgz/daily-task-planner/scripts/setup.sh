#!/bin/bash
# Daily Task Planner - 初始化配置脚本

set -e

SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
CONFIG_FILE="$SKILL_DIR/config/config.yaml"

echo "🎯 Daily Task Planner - 初始化配置"
echo "===================================="
echo ""

# 解析参数
while [[ $# -gt 0 ]]; do
  case $1 in
    --group-id)
      GROUP_ID="$2"
      shift 2
      ;;
    --check-times)
      CHECK_TIMES="$2"
      shift 2
      ;;
    --calendar-enabled)
      CALENDAR_ENABLED=true
      shift
      ;;
    --bitable-enabled)
      BITABLE_ENABLED=true
      shift
      ;;
    *)
      echo "❌ 未知参数: $1"
      exit 1
      ;;
  esac
done

# 创建配置文件
mkdir -p "$SKILL_DIR/config"

echo "# Daily Task Planner 配置文件" > "$CONFIG_FILE"
echo "# 生成时间: $(date '+%Y-%m-%d %H:%M:%S')" >> "$CONFIG_FILE"
echo "" >> "$CONFIG_FILE"

# 规划群配置
echo "# 规划群配置" >> "$CONFIG_FILE"
echo "planning_group:" >> "$CONFIG_FILE"
if [ -n "$GROUP_ID" ]; then
  echo "  id: \"$GROUP_ID\"" >> "$CONFIG_FILE"
else
  echo "  id: \"\"  # 请填写飞书群ID" >> "$CONFIG_FILE"
fi
echo "  name: \"规划确认群\"" >> "$CONFIG_FILE"
echo "" >> "$CONFIG_FILE"

# 拆解群配置
echo "# 拆解群配置（多人协作时用，可选）" >> "$CONFIG_FILE"
echo "discussion_group:" >> "$CONFIG_FILE"
echo "  id: \"\"  # 可选，为空时不用双群模式" >> "$CONFIG_FILE"
echo "  name: \"拆解讨论群\"" >> "$CONFIG_FILE"
echo "" >> "$CONFIG_FILE"

# 提醒时间
echo "# 提醒时间" >> "$CONFIG_FILE"
echo "check_times:" >> "$CONFIG_FILE"
if [ -n "$CHECK_TIMES" ]; then
  IFS=',' read -ra TIMES <<< "$CHECK_TIMES"
  for time in "${TIMES[@]}"; do
    echo "  - \"$time\"" >> "$CONFIG_FILE"
  done
else
  echo "  - \"12:00\"  # 午间检查" >> "$CONFIG_FILE"
  echo "  - \"15:00\"  # 下午检查" >> "$CONFIG_FILE"
  echo "  - \"21:00\"  # 晚间复盘" >> "$CONFIG_FILE"
fi
echo "" >> "$CONFIG_FILE"

# 默认值
echo "# 任务默认值" >> "$CONFIG_FILE"
echo "defaults:" >> "$CONFIG_FILE"
echo "  daily_task_limit: 3        # 每天最多三件事" >> "$CONFIG_FILE"
echo "  max_task_duration: \"8h\"    # 单个任务最长不超过8小时" >> "$CONFIG_FILE"
echo "  buffer_time: \"30m\"         # 任务间隔缓冲时间" >> "$CONFIG_FILE"
echo "" >> "$CONFIG_FILE"

# 集成配置
echo "# 集成配置" >> "$CONFIG_FILE"
echo "integrations:" >> "$CONFIG_FILE"
echo "  calendar: ${CALENDAR_ENABLED:-false}    # 日历集成" >> "$CONFIG_FILE"
echo "  bitable: ${BITABLE_ENABLED:-false}      # 飞书多维表格集成" >> "$CONFIG_FILE"

echo "✅ 配置文件已创建: $CONFIG_FILE"
echo ""
echo "📋 配置内容预览："
cat "$CONFIG_FILE"
echo ""
echo "💡 下一步："
echo "   1. 编辑 config/config.yaml 完善配置"
echo "   2. 运行 ./scripts/parse-task.js 开始拆解任务"
