#!/usr/bin/env node
/**
 * Daily Task Planner - 任务拆解核心脚本 v1.2.0
 * 
 * 输入：主人的工作思路（文本/文件/URL）
 * 输出：当天可完成的三件事 + 建议截止时间 + 选择理由
 */

const fs = require('fs');
const path = require('path');

const SKILL_DIR = path.dirname(__dirname);
const CONFIG_FILE = path.join(SKILL_DIR, 'config', 'config.yaml');

// 加载配置（简化版，不依赖外部模块）
function loadConfig() {
  try {
    const configContent = fs.readFileSync(CONFIG_FILE, 'utf-8');
    // 简单解析 YAML 关键配置
    const config = {};
    const lines = configContent.split('\n');
    let currentSection = '';
    
    lines.forEach(line => {
      if (line.includes('planning_group:')) currentSection = 'planning_group';
      if (line.includes('id:')) {
        const match = line.match(/id:\s*"([^"]+)"/);
        if (match && currentSection === 'planning_group') {
          config.planning_group = { id: match[1] };
        }
      }
    });
    
    return config;
  } catch (e) {
    // 配置可选，使用默认值
    return { planning_group: { id: '' } };
  }
}

// 解析任务输入
function parseInput(input) {
  if (fs.existsSync(input)) {
    return fs.readFileSync(input, 'utf-8');
  }
  return input;
}

// 生成选择理由
function generateReason(task, index, allTasks) {
  const reasons = {
    first: [
      '这是所有后续动作的**前置依赖**。没有这一步，后面的事情都无法开展。',
      '这是项目的**第一步关键动作**，必须先解决才能推进。',
      '这是**基础工作**，今天做好，明天才能批量复制。',
      '这是**信息收集阶段**，必须先有输入才能有输出。'
    ],
    second: [
      '这是找到方法后的**即时验证**，必须趁热打铁。',
      '这是**最小验证集**，用小成本测试大方向。',
      '这是**闭环动作**，没有验证，前期工作等于白做。',
      '这是**快速迭代**的关键，发现问题立即调整。'
    ],
    third: [
      '这是**日常基本盘**，必须每天完成，不能停。',
      '这是**确定性收入**，稳住基本盘才能探索新机会。',
      '这是**习惯养成**，日积月累的复利效应。',
      '这是**防守动作**，守好后方才能安心进攻。'
    ]
  };
  
  const position = index === 0 ? 'first' : index === 1 ? 'second' : 'third';
  const positionReasons = reasons[position];
  
  // 根据任务类型选择最合适的理由
  if (task.type === 'project' && index === 0) {
    return positionReasons[0]; // 前置依赖
  } else if (task.type === 'project' && index === 1) {
    return positionReasons[1]; // 最小验证集
  } else if (task.type === 'daily') {
    return positionReasons[0]; // 日常基本盘
  }
  
  return positionReasons[Math.floor(Math.random() * positionReasons.length)];
}

// 生成整体策略理由
function generateOverallStrategy(tasks) {
  return {
    urgency: '日常产出每天都有deadline，最紧急；项目启动依赖次之。',
    importance: '第1件事是"一次投入，长期受益"；第2、3件是"日常必须"。',
    feasibility: '三件事都是"当天可完成"的粒度，总计时间在一天工作范围内。',
    dependency: '第1件事是第2件事的前置，必须先完成才能推进。'
  };
}

// 主生成函数
function generateOutput(rawInput) {
  // 简单解析输入
  const lines = rawInput.split('\n').filter(l => l.trim());
  
  // 识别任务类型
  const tasks = lines.map((line, index) => {
    const content = line.trim();
    let type = 'normal';
    
    if (content.includes('每天') || content.includes('每日') || content.includes('早上')) {
      type = 'daily';
    } else if (content.includes('项目') || content.includes('第一步') || content.includes('铁皮石斛')) {
      type = 'project';
    }
    
    return {
      content: content,
      type: type,
      title: content.length > 20 ? content.substring(0, 20) + '...' : content,
      deadline: ['16:00', '18:00', '19:00'][index] || '18:00'
    };
  });
  
  // 取前三件事
  const top3 = tasks.slice(0, 3).map((task, index) => ({
    order: index + 1,
    title: task.title,
    source: task.content.substring(0, 50) + (task.content.length > 50 ? '...' : ''),
    breakdown: generateBreakdown(task),
    deliverable: generateDeliverable(task),
    estimated_time: generateEstimatedTime(task),
    deadline: task.deadline,
    reason: generateReason(task, index, tasks)
  }));
  
  // 生成整体策略
  const strategy = generateOverallStrategy(tasks);
  
  // 构建输出
  let output = '\n📋 明天最重点的三件事（当天可完成）：\n\n';
  
  top3.forEach(task => {
    output += `${task.order}. ${task.title}（建议截止：${task.deadline}）\n\n`;
    output += `**来源**：${task.source}\n\n`;
    output += `**拆解**：${task.breakdown}\n\n`;
    output += `**产出物**：${task.deliverable}\n\n`;
    output += `**预估时间**：${task.estimated_time}\n\n`;
    output += `**为什么选这件事？**\n${task.reason}\n\n`;
    output += '---\n\n';
  });
  
  output += '\n🤔 为什么选这三件事？（整体策略）\n\n';
  output += '| 维度 | 说明 |\n';
  output += '|------|------|\n';
  output += `| **紧急性** | ${strategy.urgency} |\n`;
  output += `| **重要性** | ${strategy.importance} |\n`;
  output += `| **可行性** | ${strategy.feasibility} |\n`;
  output += `| **依赖关系** | ${strategy.dependency} |\n`;
  
  output += '\n\n## ❓ 请确认或修改\n\n';
  output += '1. 这三件事是否准确？\n';
  output += '2. 截止时间是否合理？\n';
  output += '3. 优先级是否需要调整？\n';
  output += '4. 每件事的产出物是否明确？\n';
  output += '5. **选择理由是否充分？**\n\n';
  output += '**回复格式：**\n';
  output += '- "确认" → 直接发送\n';
  output += '- "修改：第X条改成..." → 更新后发送\n';
  
  return output;
}

function generateBreakdown(task) {
  if (task.type === 'project') {
    return '找到关键第一步 → 拆解为当天可完成的子任务 → 明确产出物';
  } else if (task.type === 'daily') {
    return '确定具体内容 → 分配时间块 → 确认完成标准';
  }
  return '执行 → 检查 → 完成';
}

function generateDeliverable(task) {
  if (task.type === 'project') {
    return '1份可落地的执行方案或文档';
  } else if (task.type === 'daily') {
    return '完成当日固定产出任务';
  }
  return '明确的完成成果';
}

function generateEstimatedTime(task) {
  if (task.type === 'project') {
    return '3-4小时';
  } else if (task.type === 'daily') {
    return '6-8小时';
  }
  return '2-3小时';
}

// 主函数
function main() {
  const input = process.argv.slice(2).join(' ') || process.stdin.read() || '';
  
  if (!input.trim()) {
    console.log('❌ 请输入工作思路');
    console.log('用法: node parse-task.js "你的工作思路..."');
    process.exit(1);
  }

  loadConfig();
  const rawInput = parseInput(input);
  const output = generateOutput(rawInput);
  
  console.log(output);
  
  // 保存结果
  const outputFile = path.join(SKILL_DIR, '.last-parsed.json');
  fs.writeFileSync(outputFile, JSON.stringify({ input: rawInput, output }, null, 2));
}

main();
