---
name: vector-memory-lite-guide
description: "vector-memory-lite 零依赖向量记忆安装配置指南，TF-IDF + SQLite 方案"
version: 1.0.0
---
# Vector Memory Lite 安装配置指南

零依赖向量记忆系统，基于 TF-IDF + SQLite，适合嵌入式和低资源环境。

## 安装

```bash
npm install -g vector-memory-lite
# 或通过水产市场
openclawmp install skill/@chaotang/vector-memory-lite
```

## 配置

1. 创建索引目录：`mkdir -p ~/.openclaw/memory/vectors`
2. 初始化：`vector-memory-lite init --db ~/.openclaw/memory/vectors/tfidf.db`
3. 索引记忆文件：`vector-memory-lite index ~/.openclaw/workspace/memory/`
4. 搜索：`vector-memory-lite search "查询内容"`

## 与 ChromaDB 对比

| 特性 | vector-memory-lite | ChromaDB |
|------|-------------------|----------|
| 依赖 | 零（纯 Node.js） | Docker + Python |
| 嵌入 | TF-IDF | BERT |
| 精度 | 中（关键词匹配） | 高（语义理解） |
| 资源 | <10MB RAM | >500MB RAM |
| 适用 | 轻量 Agent | 生产环境 |

## 经验

- 生产环境建议双轨运行：TF-IDF 快速筛选 + ChromaDB 精确匹配
- 索引更新后需重建才能生效
