---
name: get-accurate-time
description: "从网络API获取准确的当前时间，解决AI系统时间错误问题。支持多时区、自动故障转移、无需API密钥。"
version: 1.0.0
type: skill
tags:
  - time
  - datetime
  - api
  - utility
  - timezone
---

# 🕐 Get Accurate Time

从网络API获取准确的当前时间，解决AI系统经常报告错误时间的问题。

## 问题背景

AI系统经常会搞错系统时间，这会导致：
- 日程安排混乱
- 日志记录时间戳错误
- 定时任务执行时机不对

本技能通过调用网络时间API获取准确的当前时间，确保时间信息正确。

## 核心能力

- 从网络API获取准确的当前时间
- 支持自定义时区（默认Asia/Shanghai CST）
- 自动故障转移到备用API
- 返回日期、时间、星期等完整信息
- 支持JSON格式输出供程序调用
- 无需API密钥，完全免费

## 使用方法

### 方法1: 直接API调用（推荐）

```bash
curl -s "https://timeapi.io/api/time/current/zone?timeZone=Asia/Shanghai"
```

返回：
```json
{
  "year": 2026,
  "month": 4,
  "day": 2,
  "hour": 20,
  "minute": 15,
  "seconds": 0,
  "date": "04/02/2026",
  "time": "20:15",
  "dayOfWeek": "Thursday"
}
```

### 方法2: Python脚本

```python
import urllib.request
import json

url = "https://timeapi.io/api/time/current/zone?timeZone=Asia/Shanghai"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req, timeout=5) as response:
    data = json.loads(response.read().decode())
    print(f"当前时间: {data['date']} {data['time']} ({data['dayOfWeek']})")
```

## 支持的时区

修改URL中的 `timeZone` 参数即可：

| 时区 | 参数值 |
|------|--------|
| 中国 (CST) | Asia/Shanghai |
| 美国东部 | America/New_York |
| 日本 | Asia/Tokyo |
| 欧洲 | Europe/Paris |

## 时间API列表

| API | URL | 特点 |
|-----|-----|------|
| timeapi.io | https://timeapi.io/api/time/current/zone?timeZone=Asia/Shanghai | 推荐，免费 |
| worldtimeapi.org | http://worldtimeapi.org/api/timezone/Asia/Shanghai | 备用 |

## 系统要求

- Python 3.6+ 或 curl
- 网络连接

## 限制

- 需要网络连接
- 依赖第三方时间API服务

## 配合使用

- 日历管理 (calendar)
- 日程安排 (scheduling)
- 提醒事项 (reminders)
- 日志记录 (logging)