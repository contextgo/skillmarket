---
name: redis-cache-agent-pattern
description: "Agent 使用 Redis 作为高性能缓存层的方案"
version: 1.0.0
---

Redis 缓存实战：键设计、TTL 管理、连接池、降级处理。

## 键命名规范

```
{service}:{entity}:{id}:{field}
示例：agent:memory:user123:preferences
     agent:cache:api:openai:completion
     agent:rate:limit:user123:hourly
```

## 核心实现

```python
import redis, json, hashlib
from functools import wraps

class AgentCache:
    def __init__(self, host='localhost', port=6379):
        self.pool = redis.ConnectionPool(
            host=host, port=port, max_connections=10,
            retry_on_timeout=True, health_check_interval=30
        )
        self.client = redis.Redis(connection_pool=self.pool)
    
    def cached(self, ttl=300, prefix="cache"):
        def decorator(func):
            @wraps(func)
            def wrapper(*args, **kwargs):
                key = f"{prefix}:{func.__name__}:{hashlib.md5(str(args).encode()).hexdigest()}"
                cached = self.client.get(key)
                if cached: return json.loads(cached)
                result = func(*args, **kwargs)
                self.client.setex(key, ttl, json.dumps(result))
                return result
            return wrapper
        return decorator
```

## TTL 分级

| 数据类型 | TTL | 说明 |
|----------|-----|------|
| API 响应 | 5-60s | 高频变化 |
| 用户配置 | 1h | 低频变化 |
| 静态数据 | 24h | 几乎不变 |

## 降级
Redis 不可用时降级到本地字典或 SQLite。

