---
name: douyin-hot-trend
description: 获取抖音热榜/热搜榜数据，包含热门视频、挑战赛、音乐等多领域热门内容，并输出标题、热度值、跳转链接及封面图（如有）。
version: 1.1.0
allowed-tools:
  - Read
  - Write
  - Edit
  - RunTerminalCommand
---

# 抖音热榜

## 技能概述

此技能用于抓取抖音热榜数据，包括：
- 热点标题
- 热度值（万为单位，易读格式）
- 详情跳转链接
- **封面图（如有）**
- 热门标签（爆 / 热 / 新 / 荐）
- 内容类型

## 触发方式示例

你可以用以下自然语言触发此技能：

- "帮我看看抖音今天热搜"
- "抖音热榜前10是什么"
- "现在抖音在热什么"
- "给我抖音热点"

## 命令行用法

**重要：** 所有脚本位于此 SKILL.md 所在目录的 `scripts/` 子目录。

**Agent 执行说明：**
1. 确定此 SKILL.md 文件所在目录为 `SKILL_DIR`
2. 脚本完整路径 = `${SKILL_DIR}/scripts/douyin.js`

获取热榜（默认 50 条，按榜单顺序返回）：

```bash
node ${SKILL_DIR}/scripts/douyin.js hot
```

获取热榜前 N 条：

```bash
node ${SKILL_DIR}/scripts/douyin.js hot 10
```

## 输出格式示例

```
🔥 抖音热榜 TOP 5
======================================================================

 1. 国防部正告日方 [爆]
    🔥 热度: 1185万
    🔗 链接: https://www.douyin.com/search/%E5%9B%BD%E9%98%B2%E9%83%A8%E6%AD%A3%E5%91%8A%E6%97%A5%E6%96%B9

 2. 中国女篮81:68马里女篮 [新]
    🔥 热度: 1177万
    🔗 链接: https://www.douyin.com/search/%E4%B8%AD%E5%9B%BD%E5%A5%B3%E7%AF%AE81%3A68%E9%A9%AC%E9%87%8C%E5%A5%B3%E7%AF%AE
```

**注意：** 链接为纯文本 URL，可直接复制使用，无 HTML 标签包装。

## 返回数据字段

| 字段 | 类型 | 说明 |
|------|------|------|
| rank | number | 榜单排名（从 1 开始） |
| title | string | 热点标题 |
| popularity | number | 热度值（HotValue，已转为数字；解析失败时为 0） |
| link | string | 热点详情链接 |
| **cover** | **string \| null** | **封面图 URL（新增）** |
| label | string \| null | 标签/标识 |
| type | string | 内容类型（视频、音乐、挑战赛等） |

## 版本更新日志

### v1.1.0 (2025-02-27)

- ✨ **新增封面图字段**
- ✨ 优化数据输出格式
- ✨ 改进错误处理机制

### v1.0.0

- 初始版本
- 支持基本热榜获取

## 数据来源

抖音网页端公开接口

## 注意事项

- 该接口为网页端公开接口，返回结构可能变动
- 访问频繁可能触发风控
- **封面图：** 并非所有热点都有封面图，部分条目可能为空
- **Windows 兼容：** 脚本已移除 shebang 行，使用 `node <path>` 直接调用，勿用 `./` 方式执行
