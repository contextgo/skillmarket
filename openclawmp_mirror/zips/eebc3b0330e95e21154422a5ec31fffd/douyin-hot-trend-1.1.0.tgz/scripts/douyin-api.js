﻿'use strict';

/**
 * 抖音热榜公共模块
 * 供 douyin.js / get-hot-trend.js / cron-job.js 共享调用
 */

const https = require('https');

const USER_AGENTS = [
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0'
];

// 抖音 label 编号 → 可读文字
const LABEL_MAP = {
  '1': '新',
  '2': '热',
  '3': '爆',
  '4': '荐'
};

function getRandomUserAgent() {
  return USER_AGENTS[Math.floor(Math.random() * USER_AGENTS.length)];
}

/**
 * 热度值转"万"单位可读字符串
 * 例: 11849702 → "1185万"，98000 → "9.8万"，800 → "800"
 * @param {number} val
 * @returns {string}
 */
function formatPopularity(val) {
  if (val >= 10000) {
    const wan = val / 10000;
    return (wan >= 100 ? Math.round(wan) : Math.round(wan * 10) / 10) + '万';
  }
  return String(val);
}

/**
 * 请求抖音热榜原始数据
 * @returns {Promise<Object>}
 */
function fetchDouyinHotBoard() {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'www.douyin.com',
      path: '/aweme/v1/hot/search/list/',
      method: 'GET',
      headers: {
        'User-Agent': getRandomUserAgent(),
        'Accept': 'application/json',
        'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
        'Referer': 'https://www.douyin.com/'
      }
    };

    const req = https.request(options, (res) => {
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(
          `HTTP ${res.statusCode}，可能触发风控或接口变动。请稍后重试，或检查网络连接。`
        ));
      }

      let raw = '';
      res.on('data', (chunk) => { raw += chunk; });
      res.on('end', () => {
        try {
          resolve(JSON.parse(raw));
        } catch (e) {
          const preview = raw.slice(0, 200).replace(/\n/g, ' ');
          reject(new Error(
            `数据解析失败，接口返回内容异常。请稍后重试。\n详情: ${e.message}\n响应预览: ${preview}`
          ));
        }
      });
    });

    req.on('error', (err) => {
      reject(new Error(`网络请求失败，请检查网络连接后重试。\n详情: ${err.message}`));
    });

    req.setTimeout(10000, () => {
      req.destroy();
      reject(new Error('请求超时（10s），请检查网络后重试。'));
    });

    req.end();
  });
}

/**
 * 将原始响应格式化为结构化列表
 * @param {Object} data
 * @param {number} [limit=50]
 * @returns {Array<{rank,title,popularity,popularityText,link,cover,label,labelText,type}>}
 */
function formatHotBoard(data, limit = 50) {
  if (!data || !data.data || !Array.isArray(data.data.word_list)) {
    return [];
  }
  return data.data.word_list.slice(0, limit).map((item, index) => {
    const popularity = Number(item.hot_value) || 0;
    const rawLabel = item.label != null ? String(item.label) : null;
    return {
      rank: index + 1,
      title: item.word || '无标题',
      popularity,
      popularityText: formatPopularity(popularity),  // 人类可读热度
      link: item.url || `https://www.douyin.com/search/${encodeURIComponent(item.word || '')}`,
      cover: item.cover || null,
      label: rawLabel,
      labelText: rawLabel ? (LABEL_MAP[rawLabel] || null) : null,  // 可读标签
      type: item.type || '未知'
    };
  });
}

/**
 * 一步获取并格式化热榜
 * @param {number} [limit=50]
 * @returns {Promise<Array>}
 */
async function getHotList(limit = 50) {
  const data = await fetchDouyinHotBoard();
  return formatHotBoard(data, limit);
}

module.exports = { fetchDouyinHotBoard, formatHotBoard, getHotList, formatPopularity };
