﻿'use strict';

/**
 * 抖音热榜 CLI 入口
 * 用法: node scripts/douyin.js hot [数量]
 */

const { getHotList } = require('./douyin-api');

function printHotBoard(hotList) {
  console.log('🔥 抖音热榜 TOP ' + hotList.length);
  console.log('='.repeat(70));
  console.log();

  hotList.forEach((item) => {
    // 标签文字（爆/热/新/荐），有则展示，无则不显示
    const labelStr = item.labelText ? ` [${item.labelText}]` : '';
    console.log(`${item.rank.toString().padStart(2, ' ')}. ${item.title}${labelStr}`);
    console.log(`    🔥 热度: ${item.popularityText}`);
    if (item.cover) {
      console.log(`    🖼️  封面: ${item.cover}`);
    }
    console.log(`    🔗 链接: ${item.link}`);
    console.log();
  });
}

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'hot';
  const limit = Math.max(1, parseInt(args[1]) || 50);

  if (command !== 'hot') {
    console.log('用法:');
    console.log('  node scripts/douyin.js hot [数量]');
    console.log('');
    console.log('示例:');
    console.log('  node scripts/douyin.js hot      # 获取热榜（默认50条）');
    console.log('  node scripts/douyin.js hot 20   # 获取热榜前20条');
    process.exit(1);
  }

  try {
    console.log('正在获取抖音热榜...\n');
    const hotList = await getHotList(limit);

    if (hotList.length === 0) {
      console.error('❌ 未获取到热榜数据，接口可能已变动，请稍后重试。');
      process.exit(1);
    }

    printHotBoard(hotList);
  } catch (error) {
    console.error(`❌ ${error.message}`);
    process.exit(1);
  }
}

main();
