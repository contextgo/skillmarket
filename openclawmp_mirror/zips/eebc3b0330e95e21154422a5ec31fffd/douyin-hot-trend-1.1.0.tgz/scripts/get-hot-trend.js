﻿'use strict';

/**
 * 抖音热榜定时任务脚本
 * 直接调用 douyin-api 模块，无需解析文本输出
 */

const fs = require('fs');
const path = require('path');
const { getHotList } = require('./douyin-api');

function formatMessage(items) {
  let message = '🔥 **抖音热榜 TOP ' + items.length + '**\n';
  message += '='.repeat(50) + '\n\n';

  items.forEach((item) => {
    const labelStr = item.labelText ? ` [${item.labelText}]` : '';
    message += `${item.rank}. ${item.title}${labelStr}\n`;
    message += `   🔥 ${item.popularityText}\n`;
    message += `   🔗 ${item.link}\n\n`;
  });

  message += '\n📱 数据来源：抖音网页端公开接口';
  message += '\n⏰ 更新时间：' + new Date().toLocaleString('zh-CN', { timeZone: 'Asia/Shanghai' });
  return message;
}

async function main() {
  const limit = Math.max(1, parseInt(process.argv[2]) || 10);

  console.log('开始获取抖音热榜...');

  let items;
  try {
    items = await getHotList(limit);
  } catch (error) {
    console.error(`❌ ${error.message}`);
    process.exit(1);
  }

  if (items.length === 0) {
    console.error('❌ 返回数据为空，接口可能已变动，请稍后重试。');
    process.exit(1);
  }

  const message = formatMessage(items);
  const dir = __dirname;

  const txtFile = path.join(dir, 'latest-hot-trend.txt');
  fs.writeFileSync(txtFile, message, 'utf-8');

  const jsonOutput = {
    success: true,
    timestamp: new Date().toISOString(),
    timezone: 'Asia/Shanghai',
    message,
    items
  };
  const jsonFile = path.join(dir, 'latest-hot-trend.json');
  fs.writeFileSync(jsonFile, JSON.stringify(jsonOutput, null, 2), 'utf-8');

  console.log('\n=== 抖音热榜报告 ===\n');
  console.log(message);
  console.log('\n✅ 热榜数据已保存到:');
  console.log(`  - ${txtFile}`);
  console.log(`  - ${jsonFile}`);
}

main().catch((error) => {
  console.error('执行出错:', error.message);
  process.exit(1);
});
