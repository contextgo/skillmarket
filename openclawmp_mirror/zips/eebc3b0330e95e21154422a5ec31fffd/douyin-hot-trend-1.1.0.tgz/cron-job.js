﻿#!/usr/bin/env node
'use strict';

/**
 * 抖音热榜定时任务 - OpenClaw 集成版本
 * 直接调用 douyin-api 模块，输出供 Telegram 推送的 JSON
 */

const fs = require('fs');
const path = require('path');
const { getHotList } = require('./scripts/douyin-api');

const RANK_EMOJIS = ['🥇', '🥈', '🥉'];
const LINK_LIMIT = 5; // 前 N 名显示链接

function formatTelegramMessage(items) {
  let message = '🔥 **抖音热榜 TOP ' + items.length + '**\n';
  message += '_数据实时获取_\n\n';

  items.forEach((item) => {
    const emoji = RANK_EMOJIS[item.rank - 1] || '🎯';
    message += `${emoji} *${item.rank}.* ${item.title}\n`;
    message += `   🔥 ${item.popularityText}\n`;

    if (item.rank <= LINK_LIMIT) {
      message += `   [查看详情](${item.link})\n`;
    }

    message += '\n';
  });

  message += '📱 _数据来源：抖音网页端_';
  message += '\n⏰ ' + new Date().toLocaleString('zh-CN', {
    timeZone: 'Asia/Shanghai',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit'
  });

  return message;
}

async function main() {
  const limit = 10;
  console.log('🎬 开始执行抖音热榜定时任务...');

  let items;
  try {
    items = await getHotList(limit);
  } catch (error) {
    console.error('❌ 获取热榜数据失败:', error.message);
    process.exit(1);
  }

  if (items.length === 0) {
    console.error('❌ 返回数据为空，接口可能已变动');
    process.exit(1);
  }

  console.log(`✅ 成功获取 ${items.length} 条热榜数据`);

  const message = formatTelegramMessage(items);

  const msgFile = path.join(__dirname, 'daily-hot-trend-message.txt');
  fs.writeFileSync(msgFile, message, 'utf-8');

  const jsonOutput = {
    success: true,
    timestamp: new Date().toISOString(),
    timezone: 'Asia/Shanghai',
    chat_id: '8428610733',
    channel: 'telegram',
    message,
    items,
    format: 'markdown'
  };

  const jsonFile = path.join(__dirname, 'daily-hot-trend-output.json');
  fs.writeFileSync(jsonFile, JSON.stringify(jsonOutput, null, 2), 'utf-8');

  console.log('📤 消息已准备发送到 Telegram');
  console.log(`💾 保存位置: ${jsonFile}`);
  console.log('\n=== 消息预览 ===\n');
  console.log(message);

  return jsonOutput;
}

main().catch((error) => {
  console.error('执行出错:', error);
  process.exit(1);
});
