---
name: jianying-auto-edit
description: 剪映自动剪辑技能。用户提供主题和内容，自动生成完整的剪映工程文件（含配图、字幕、特效、转场、动画、滤镜、音频、配音音效）。当用户说"帮我剪一个视频"、"生成剪映工程"、"自动剪辑"、"做一个短视频"等时使用此技能。
---

# 剪映自动剪辑 Skill

基于 `pyJianYingDraft` + `edge-tts` + `Pillow`，自动生成可直接在剪映中打开的完整工程文件。

## 前置依赖

```bash
python -m pip install pyJianYingDraft edge-tts mutagen Pillow
```

## 参考视频风格（逐帧分析用户实际发布视频）

### 视觉风格
- 16:9横屏（1920×1080）
- 深色条纹纹理背景，科技感
- 黑色背景 + 白色主文字 + 绿色/黄色/红色强调色
- 左上角固定品牌水印，右上角段落标签（带彩色背景）
- 底部字幕：白色粗体 + 黑色描边，固定在画面底部

### 画面类型
图文卡片（深色背景+居中标题+图标）、数据对比图、实景素材、纯文字页交替使用

### 时间线
12-15段，总时长3分钟左右。每段时长由配音自动决定。

## pyJianYingDraft 核心API速查（已验证）

### 时间工具
```python
from pyJianYingDraft import trange, tim, SEC
# SEC = 1_000_000 (1秒)
# tim("3.5s") = 3500000
# trange("0s", "5s") = Timerange(0, 5000000)  注意第二个参数是持续时长
```

### ClipSettings（画面变换，极其重要）
```python
ClipSettings(
    alpha=1.0,           # 不透明度 0-1
    flip_horizontal=False,
    flip_vertical=False,
    rotation=0.0,        # 顺时针旋转角度
    scale_x=1.0,         # 水平缩放
    scale_y=1.0,         # 垂直缩放
    transform_x=0.0,     # 水平位移（单位：半个画布宽，-1到1）
    transform_y=0.0,     # 垂直位移（单位：半个画布高，-1到1）
)
# transform_y=-0.8 → 偏上方（剪映字幕默认值）
# transform_y=0.75 → 偏下方（底部字幕）
# transform_x=-0.78 → 偏左（左上角水印）
```

### 关键帧动画（Ken Burns效果等）
```python
from pyJianYingDraft import KeyframeProperty
# 可用属性：position_x, position_y, scale_x, scale_y, rotation, alpha
seg.add_keyframe(KeyframeProperty.scale_x, 0, 1.02)        # 起始缩放
seg.add_keyframe(KeyframeProperty.scale_x, duration, 1.06)  # 结束缩放
```

### VideoSegment
```python
VideoSegment(
    material,              # 路径字符串或VideoMaterial实例
    target_timerange,      # Timerange
    source_timerange=None, # 截取素材的时间范围
    speed=None,            # 播放速度
    volume=1.0,
    clip_settings=None,    # ClipSettings实例
)
seg.add_animation(IntroType.渐显)
seg.add_animation(OutroType.渐隐)
seg.add_transition(TransitionType.叠化, duration=tim("0.5s"))
seg.add_mask(MaskType.圆形, ...)
seg.add_keyframe(KeyframeProperty.xxx, time_offset, value)
```

### TextSegment
```python
TextSegment(
    text,
    timerange,             # 注意是timerange不是target_timerange
    font=FontType.抖音美好体,
    style=TextStyle(
        size=5.0, bold=True,
        color=(1.0, 1.0, 1.0), alpha=1.0,
        align=1,           # 0左 1中 2右
        line_spacing=12,
        auto_wrapping=True, max_line_width=0.85,
    ),
    clip_settings=ClipSettings(transform_x=0, transform_y=0.75),  # 控制文字位置！
    border=TextBorder(color=(0,0,0), width=30.0),
    background=TextBackground(color=(r,g,b), alpha=0.9),  # 文字背景色块
    shadow=TextShadow(...),
)
```

### AudioSegment
```python
AudioSegment(
    material,              # 路径或AudioMaterial
    target_timerange,
    volume=1.0,
    fade_in_duration=tim("0.5s"),
    fade_out_duration=tim("1s"),
)
```

### 轨道与片段
```python
script.add_track(TrackType.video)
script.add_track(TrackType.text, "字幕轨")
script.add_track(TrackType.audio, "配音轨")
script.add_track(TrackType.filter, "滤镜轨")
script.add_track(TrackType.effect, "特效轨")
script.add_segment(seg, track_name="字幕轨")
script.add_filter(FilterType.xxx, timerange, track_name="滤镜轨", intensity=80)
script.add_effect(VideoSceneEffectType.xxx, timerange, track_name="特效轨")
```

### 草稿管理
```python
folder = DraftFolder(r"E:\剪映缓存\草稿缓存\JianyingPro Drafts")
script = folder.create_draft("项目名", width=1920, height=1080, allow_replace=True)
script.save()
```

## 多轨道布局模板（参考视频结构）

```
视频轨:    [卡片1][卡片2][卡片3]...  （主画面+关键帧缩放+转场）
底部字幕:  [字幕1][字幕2][字幕3]...  （transform_y=0.75，白色粗体+黑色描边）
左上水印:  [水印1][水印2][水印3]...  （transform_x=-0.78, transform_y=-0.82，品牌名）
右上标签:  [标签1][标签2][标签3]...  （transform_x=0.78, transform_y=-0.82，带彩色背景）
配音轨:    [TTS1][TTS2][TTS3]...    （edge-tts生成）
BGM轨:     [BGM全程铺底]            （音量0.15，淡入淡出）
```

## 完整代码模板

```python
# -*- coding: utf-8 -*-
import pyJianYingDraft as d
from pyJianYingDraft import (
    Timerange, TrackType, TransitionType,
    IntroType, OutroType, FontType, TextStyle, TextBorder, TextBackground,
    VideoSegment, TextSegment, AudioSegment,
    ClipSettings, KeyframeProperty, trange, tim, SEC,
)
from PIL import Image, ImageDraw, ImageFont
import edge_tts, asyncio, os
from mutagen.mp3 import MP3

DRAFT_FOLDER = r"E:\剪映缓存\草稿缓存\JianyingPro Drafts"
PROJECT_NAME = "自动生成的视频"
W, H = 1920, 1080
TTS_VOICE = "zh-CN-YunxiNeural"

# 分段: [(配音文案, 卡片标题, 段落标签, 背景色, 强调色), ...]
SEGMENTS = []
BGM_PATH = None

def create_card(out_dir, idx, w, h, bg, accent, title, total):
    os.makedirs(out_dir, exist_ok=True)
    img = Image.new("RGB", (w, h), bg)
    draw = ImageDraw.Draw(img)
    for y in range(0, h, 4):
        b = 6 + (y % 12) // 2
        r0 = min(int(bg[1:3],16)+b, 255)
        g0 = min(int(bg[3:5],16)+b, 255)
        b0 = min(int(bg[5:7],16)+b, 255)
        draw.rectangle([(0,y),(w,y+2)], fill=(r0,g0,b0))
    for y in range(6): draw.rectangle([(0,y),(w,y+1)], fill=accent)
    try: font = ImageFont.truetype("msyhbd.ttc", 72)
    except:
        try: font = ImageFont.truetype("msyh.ttc", 72)
        except: font = ImageFont.load_default()
    lines = title.split("\n")
    th = len(lines)*95
    sy = (h-th)//2-20
    for li, line in enumerate(lines):
        bbox = draw.textbbox((0,0), line, font=font)
        tw = bbox[2]-bbox[0]; x = (w-tw)//2; y = sy+li*95
        draw.text((x+3,y+3), line, fill="#000000", font=font)
        draw.text((x,y), line, fill=accent, font=font)
    path = os.path.join(out_dir, f"card_{idx:02d}.png")
    img.save(path, quality=95)
    return path

async def gen_all_tts(segments, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    paths, durs = [], []
    for i, (text, *_) in enumerate(segments):
        p = os.path.join(out_dir, f"tts_{i:02d}.mp3")
        await edge_tts.Communicate(text, TTS_VOICE).save(p)
        durs.append(MP3(p).info.length); paths.append(p)
    return paths, durs

def main():
    card_dir = os.path.join(DRAFT_FOLDER, "_temp_cards")
    tts_dir = os.path.join(DRAFT_FOLDER, "_temp_tts")
    n = len(SEGMENTS)

    images = [create_card(card_dir, i, W, H, bg, ac, title, n)
              for i, (_, title, _, bg, ac) in enumerate(SEGMENTS)]
    tts_paths, tts_durs = asyncio.run(gen_all_tts(SEGMENTS, tts_dir))

    folder = d.DraftFolder(DRAFT_FOLDER)
    script = folder.create_draft(PROJECT_NAME, width=W, height=H, allow_replace=True)

    script.add_track(TrackType.video)
    script.add_track(TrackType.text, "底部字幕")
    script.add_track(TrackType.text, "左上水印")
    script.add_track(TrackType.text, "右上标签")
    script.add_track(TrackType.audio, "配音轨")
    if BGM_PATH: script.add_track(TrackType.audio, "BGM轨")

    transitions = [TransitionType.滑动, TransitionType.叠化, TransitionType.模糊,
                   TransitionType.百叶窗, TransitionType.快速缩放, TransitionType.闪白]
    cur = 0; prev = None

    for i, (subtitle, title, label, bg, accent) in enumerate(SEGMENTS):
        dur = int((tts_durs[i] + 0.5) * SEC)
        tr = Timerange(cur, dur)

        # 视频 + 关键帧缩放
        vs = VideoSegment(images[i], target_timerange=tr,
                          clip_settings=ClipSettings(scale_x=1.02, scale_y=1.02))
        if i == 0: vs.add_animation(IntroType.渐显)
        if i == n-1: vs.add_animation(OutroType.渐隐)
        vs.add_keyframe(KeyframeProperty.scale_x, 0, 1.02)
        vs.add_keyframe(KeyframeProperty.scale_x, dur, 1.06)
        vs.add_keyframe(KeyframeProperty.scale_y, 0, 1.02)
        vs.add_keyframe(KeyframeProperty.scale_y, dur, 1.06)
        if i > 0 and prev: prev.add_transition(transitions[(i-1)%len(transitions)])
        script.add_segment(vs)

        # 底部字幕
        ts = TextSegment(subtitle, timerange=tr, font=FontType.抖音美好体,
            style=TextStyle(size=5.0, bold=True, color=(1.0,1.0,1.0), align=1,
                            line_spacing=12, auto_wrapping=True, max_line_width=0.85),
            clip_settings=ClipSettings(transform_y=0.75),
            border=TextBorder(color=(0.0,0.0,0.0), width=30.0))
        script.add_segment(ts, track_name="底部字幕")

        # 左上水印
        wm = TextSegment("品牌名称", timerange=tr, font=FontType.抖音美好体,
            style=TextStyle(size=3.0, bold=True, color=(1.0,1.0,1.0), alpha=0.9),
            clip_settings=ClipSettings(transform_x=-0.78, transform_y=-0.82))
        script.add_segment(wm, track_name="左上水印")

        # 右上标签（带彩色背景）
        ar, ag, ab = int(accent[1:3],16)/255, int(accent[3:5],16)/255, int(accent[5:7],16)/255
        lb = TextSegment(label, timerange=tr, font=FontType.抖音美好体,
            style=TextStyle(size=2.5, bold=True, color=(1.0,1.0,1.0), align=2),
            clip_settings=ClipSettings(transform_x=0.78, transform_y=-0.82),
            background=TextBackground(color=(ar,ag,ab), alpha=0.9))
        script.add_segment(lb, track_name="右上标签")

        # 配音
        audio_seg = AudioSegment(tts_paths[i],
            target_timerange=Timerange(cur, int(tts_durs[i]*SEC)), volume=1.0)
        script.add_segment(audio_seg, track_name="配音轨")

        prev = vs; cur += dur

    if BGM_PATH and os.path.exists(BGM_PATH):
        bgm = AudioSegment(BGM_PATH, target_timerange=Timerange(0, cur), volume=0.15,
                           fade_in_duration=tim("0.5s"), fade_out_duration=tim("1s"))
        script.add_segment(bgm, track_name="BGM轨")

    script.save()
    print(f"剪映工程已生成: {os.path.join(DRAFT_FOLDER, PROJECT_NAME)}")

if __name__ == "__main__":
    main()
```

## 效果速查
- **转场**: 叠化, 闪白, 滑动, 百叶窗, 快速缩放, 模糊, 闪黑 (共362种)
- **字体**: 抖音美好体, 思源黑体, 思源宋体 (共335种)
- **入场**: 渐显, 向左滑入, 向上滑入, 缩放
- **出场**: 渐隐, 向左滑出, 向上滑出, 缩放
- **蒙版**: 线性, 镜面, 圆形, 矩形, 爱心, 星形
- **关键帧**: position_x/y, scale_x/y, rotation, alpha

## 注意事项
1. 素材路径必须真实存在
2. TextSegment参数名是`timerange`不是`target_timerange`
3. 转场在**前一个**VideoSegment上调用`add_transition()`
4. ClipSettings的transform单位是"半个画布宽/高"
5. 音效建议在剪映中手动添加（内置音效库更丰富）
6. 用户草稿目录：`E:\剪映缓存\草稿缓存\JianyingPro Drafts`
