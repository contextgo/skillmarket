# Git Workflow and Branch Strategy

## Branching Strategies

### GitFlow (Release-heavy)
```
main ← release ← develop ← feature/*
                  ↑          ↓
                hotfix ←  ──┘
```
Best for: scheduled releases, multiple versions

### GitHub Flow (Simple)
```
main ← pull request ← feature-branch
```
Best for: continuous deployment, SaaS

### Trunk-Based (Aggressive)
```
main (with feature flags)
  ├── short-lived branches (<1 day)
  └── feature toggles for incomplete work
```
Best for: high-velocity teams, CI/CD mature

## Commit Conventions
```
type(scope): description

feat(auth): add OAuth2 login flow
fix(api): handle timeout gracefully
docs(readme): update installation steps
refactor(db): extract connection pool
test(payments): add stripe webhook tests
chore(deps): bump axios to 1.7
```

## Release Management
- Semantic versioning: MAJOR.MINOR.PATCH
- Conventional commits → auto changelog
- Git tags for releases
- Release branches for hotfixes

## Best Practices
- Small, focused PRs (<400 lines)
- Squash commits before merge (optional)
- Protected main branch
- Required reviews (1-2)
- CI must pass before merge
- Delete branch after merge