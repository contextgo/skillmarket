# 代码安全审计工具包

> 作者：知白守黑1024

## 简介

一套全面的代码安全审计工具集，能够对代码仓库进行多维度安全扫描。覆盖 OWASP Top 10 安全漏洞检测、敏感信息泄露检测、依赖漏洞扫描、容器安全审计、基础设施即代码（IaC）安全检查等，自动生成专业的安全审计报告。

## 核心功能

- 🔍 **SQL 注入检测**：多语言正则匹配 + Python 脚本扫描，检测字符串拼接、格式化注入、原始查询等模式
- 🛡️ **XSS 漏洞检测**：覆盖 React dangerouslySetInnerHTML、Vue v-html、Angular innerHTML、jQuery 不安全方法等
- 📁 **路径遍历检测**：识别用户输入直接用于文件操作的危险模式
- 🔑 **敏感信息检测**：AWS/GitHub/Google/Slack/Stripe 密钥、数据库连接串、私钥、JWT Token 等
- 📦 **依赖漏洞扫描**：npm audit、pip-audit、cargo audit 等工具集成
- 🐳 **容器安全审计**：Dockerfile 安全最佳实践检查（特权模式、latest 标签、硬编码密钥等）
- 🏗️ **IaC 安全扫描**：Terraform、CloudFormation、Kubernetes 清单安全检查
- 🔄 **反序列化检测**：pickle、ObjectInputStream、unserialize 等危险反序列化操作
- 🔒 **安全头部验证**：HSTS、CSP、X-Frame-Options 等安全响应头检查
- 📊 **报告生成**：Markdown 和 JSON 格式的专业审计报告，含修复建议

## 适用场景

| 场景 | 描述 |
|------|------|
| 代码审查 | CI/CD 流水线中集成安全扫描门禁 |
| 安全审计 | 定期对代码仓库进行安全合规检查 |
| 敏感信息排查 | 检查是否意外提交了 API Key、密码等 |
| 容器安全 | Dockerfile 和 Kubernetes 安全配置审计 |
| 依赖治理 | 检测第三方依赖中的已知安全漏洞 |
| DevSecOps | 将安全左移，在开发阶段发现安全问题 |

## 技术栈

- Python 3.x（扫描脚本）
- ripgrep（快速正则搜索）
- npm audit / pip-audit / cargo audit（依赖扫描）
- tfsec / cfn-guard（IaC 扫描）
- bandit（Python 安全扫描）
- trivy（容器/K8s 扫描）

## 快速开始

```
请扫描 ./src 目录的安全问题，检测 SQL 注入、XSS 和敏感信息泄露。
```

```
审查我的 Dockerfile 安全性。
```

```
对项目进行完整安全审计，生成 Markdown 报告。
```
