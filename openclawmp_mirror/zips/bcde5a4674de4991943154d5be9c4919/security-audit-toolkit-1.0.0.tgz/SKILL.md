---
name: security-audit-toolkit
description: 代码安全审计工具包 — 对代码仓库进行全方位安全扫描，检测 OWASP Top 10 漏洞、敏感信息泄露、依赖风险等安全问题
---

# 代码安全审计工具包

## 概述

本技能提供全面的代码安全审计能力，涵盖静态代码分析、依赖漏洞扫描、敏感信息检测、容器安全检查等多个维度。能够自动识别 OWASP Top 10 安全漏洞，生成详细的审计报告，帮助开发团队在早期发现并修复安全问题。

---

## 核心能力

### 1. OWASP Top 10 漏洞检测

#### 1.1 SQL 注入检测

SQL 注入是最常见且最危险的安全漏洞之一。以下是检测模式：

```bash
# === SQL 注入检测正则表达式 ===

# 直接字符串拼接 SQL（高危）
rg --type-add 'sql:r|py|js|ts|java|go|php' -t sql \
  -e '(SELECT|INSERT|UPDATE|DELETE|DROP|CREATE|ALTER|EXECUTE|EXEC)\s+.*(\+|\%|\$|f["\x27]|format|concat|interpolate)' \
  --glob '!node_modules/*' --glob '!vendor/*' --glob '!*.min.js'

# Python 格式化字符串构建 SQL
rg -t py \
  -e '(cursor\.execute|db\.execute|session\.execute|conn\.execute)\s*\(\s*(f["\x27]|.*\%s|.*\.format|.*\+.*SELECT)' \
  --glob '!**/test*/**'

# JavaScript 模板字符串 SQL
rg -t js -t ts \
  -e '(query|sql|Query|SQL)\s*[\+=]\s*`.*\$\{' \
  --glob '!node_modules/*'

# ORM 原始查询检测
rg --type-add 'code:r|py|js|ts|java|go' -t code \
  -e '(rawQuery|raw\(|raw_sql|executeSql|\.query\s*\(\s*["\x27])' \
  --glob '!node_modules/*' --glob '!vendor/*'

# Java PreparedStatement 缺失参数化
rg -t java \
  -e 'Statement\s+stmt\s*=.*createStatement' \
  --glob '!**/test*/**'
```

```python
# === SQL 注入检测脚本 ===

import re
import os
from pathlib import Path

SQL_INJECTION_PATTERNS = [
    # 直接拼接 SQL
    (r'(SELECT|INSERT|UPDATE|DELETE|DROP)\s+.*?(\+|\%)', 'HIGH',
     'SQL 字符串拼接 - 存在 SQL 注入风险'),
    
    # Python format/string interpolation in SQL
    (r'(execute|query)\s*\(\s*f["\']', 'HIGH',
     'Python f-string 用于 SQL 查询'),
    
    (r'(execute|query)\s*\(\s*["\'].*%s', 'MEDIUM',
     'Python % 格式化用于 SQL 查询'),
    
    # JavaScript template literals in SQL
    (r'query\s*[\+=]\s*`[^`]*\$\{', 'HIGH',
     'JavaScript 模板字符串用于 SQL 查询'),
    
    # Raw SQL execution
    (r'\.(raw|rawQuery|executeSql)\s*\(', 'MEDIUM',
     '原始 SQL 执行 - 确保已参数化'),
    
    # String concatenation with SQL keywords
    (r'(\+|concat)\s*["\'].*?(SELECT|INSERT|UPDATE|DELETE)', 'HIGH',
     '字符串拼接包含 SQL 关键字'),
    
    # Unsafe SQL in ORM
    (r'Model\.objects\.extra\s*\(', 'MEDIUM',
     'Django extra() 方法可能存在 SQL 注入'),
    
    (r'\.filter\(.*__.*=\s*f["\']', 'MEDIUM',
     'Django filter 中使用 f-string'),
]

def scan_sql_injection(directory, exclude_dirs=None):
    """扫描目录中的 SQL 注入漏洞"""
    exclude_dirs = exclude_dirs or ['node_modules', 'vendor', '.git', '__pycache__']
    results = []
    
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if not any(file.endswith(ext) for ext in ['.py', '.js', '.ts', '.java', '.go', '.php']):
                continue
            
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                
                for line_num, line in enumerate(lines, 1):
                    for pattern, severity, description in SQL_INJECTION_PATTERNS:
                        if re.search(pattern, line, re.IGNORECASE):
                            results.append({
                                'file': filepath,
                                'line': line_num,
                                'severity': severity,
                                'pattern': description,
                                'code': line.strip()
                            })
            except Exception as e:
                continue
    
    return sorted(results, key=lambda x: {'HIGH': 0, 'MEDIUM': 1, 'LOW': 2}[x['severity']])

# 使用示例
results = scan_sql_injection('./src')
for r in results:
    print(f"[{r['severity']}] {r['file']}:{r['line']} - {r['pattern']}")
    print(f"  Code: {r['code']}")
```

#### 1.2 XSS（跨站脚本）检测

```bash
# === XSS 漏洞检测 ===

# React dangerouslySetInnerHTML
rg -t js -t ts -t jsx -t tsx \
  -e 'dangerouslySetInnerHTML' \
  --glob '!node_modules/*'

# document.write / innerHTML 赋值
rg -t js -t ts \
  -e '(document\.write|\.innerHTML\s*=|\.outerHTML\s*=)\s*(' \
  --glob '!node_modules/*'

# eval() 和 Function() 构造器
rg --type-add 'code:r|py|js|ts|java|go|php|rb' -t code \
  -e '(eval\s*\(|new\s+Function\s*\(|setTimeout\s*\(\s*["\x27])' \
  --glob '!node_modules/*' --glob '!vendor/*'

# JavaScript URL 注入
rg -t js -t ts \
  -e '(location\.href|location\.assign|window\.open)\s*=.*\$\{' \
  --glob '!node_modules/*'

# Vue v-html 指令
rg -t vue -t js -t ts \
  -e 'v-html\s*=' \
  --glob '!node_modules/*'

# Angular innerHTML 绑定
rg -t ts \
  -e '\[innerHTML\]\s*=' \
  --glob '!node_modules/*'

# 不安全的 jQuery 方法
rg -t js \
  -e '\.(html|append|prepend|after|before|wrap|replaceWith)\s*\(\s*[^)]*\$\{' \
  --glob '!node_modules/*'
```

```python
# === XSS 检测脚本 ===

XSS_PATTERNS = [
    (r'dangerouslySetInnerHTML', 'HIGH',
     'React dangerouslySetInnerHTML 使用 - 确保 HTML 已消毒'),
    
    (r'document\.write\s*\(', 'HIGH',
     'document.write() - 可能导致 XSS'),
    
    (r'\.innerHTML\s*=', 'MEDIUM',
     'innerHTML 赋值 - 确保 DOM 已消毒'),
    
    (r'\.outerHTML\s*=', 'MEDIUM',
     'outerHTML 赋值 - 确保 DOM 已消毒'),
    
    (r'eval\s*\(', 'HIGH',
     'eval() 调用 - 代码注入风险'),
    
    (r'new\s+Function\s*\(', 'HIGH',
     'Function 构造器 - 代码注入风险'),
    
    (r'setTimeout\s*\(\s*["\x27]', 'MEDIUM',
     'setTimeout 字符串参数 - 可能执行任意代码'),
    
    (r'setInterval\s*\(\s*["\x27]', 'MEDIUM',
     'setInterval 字符串参数 - 可能执行任意代码'),
    
    (r'v-html\s*=', 'MEDIUM',
     'Vue v-html 指令 - 确保 HTML 内容可信'),
    
    (r'\[innerHTML\]\s*=', 'MEDIUM',
     'Angular innerHTML 绑定 - 确保 DOM 已消毒'),
    
    (r'location\.href\s*=', 'MEDIUM',
     'location.href 赋值 - 可能导致开放重定向'),
    
    (r'\.html\s*\(\s*(?!["\x27])[^)]*\$', 'MEDIUM',
     'jQuery .html() 带变量 - XSS 风险'),
]

def scan_xss(directory, exclude_dirs=None):
    """扫描目录中的 XSS 漏洞"""
    exclude_dirs = exclude_dirs or ['node_modules', 'vendor', '.git', '__pycache__', 'dist']
    results = []
    
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if not any(file.endswith(ext) for ext in ['.js', '.ts', '.jsx', '.tsx', '.vue', '.html']):
                continue
            
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                
                for line_num, line in enumerate(lines, 1):
                    for pattern, severity, description in XSS_PATTERNS:
                        if re.search(pattern, line, re.IGNORECASE):
                            results.append({
                                'file': filepath,
                                'line': line_num,
                                'severity': severity,
                                'pattern': description,
                                'code': line.strip()
                            })
            except Exception:
                continue
    
    return sorted(results, key=lambda x: {'HIGH': 0, 'MEDIUM': 1, 'LOW': 2}[x['severity']])
```

#### 1.3 路径遍历检测

```bash
# === 路径遍历检测 ===

# 直接文件路径拼接用户输入
rg --type-add 'code:r|py|js|ts|java|go|php|rb' -t code \
  -e '(open|readFile|readFileSync|fs\.read|FileReader|FileInputStream)\s*\(\s*.*(req\.|params\.|query\.|request\.|input\.|user_)' \
  --glob '!node_modules/*' --glob '!vendor/*'

# Python path 操作
rg -t py \
  -e '(os\.path\.join|Path)\s*\(\s*.*(request|req|params|args|form|query|input)' \
  --glob '!**/test*/**'

# send_file / send_from_directory 无路径校验
rg -t py \
  -e 'send_file\s*\(\s*.*(request|req|params|args)' \
  --glob '!**/test*/**'

# Express 静态文件服务
rg -t js -t ts \
  -e 'express\.static\s*\(\s*.*(req|params|query)' \
  --glob '!node_modules/*'

# 路径遍历特征字符串
rg --type-add 'code:r|py|js|ts|java|go|php' -t code \
  -e '(\.\./|\.\.\\\\|\.\.%2[fF]|%2e%2e)' \
  --glob '!node_modules/*'
```

```python
# === 路径遍历检测脚本 ===

PATH_TRAVERSAL_PATTERNS = [
    (r'(open|readFile|readFileSync|createReadStream)\s*\(\s*.*(req\.|params\.|query\.|request\.|input\.)',
     'HIGH', '文件操作使用用户输入 - 路径遍历风险'),
    
    (r'os\.path\.join\s*\(\s*.*(request|req|params|args|form|query)',
     'HIGH', 'os.path.join 使用用户输入 - 需验证路径'),
    
    (r'Path\s*\(\s*.*(request|req|params|args)',
     'HIGH', 'Path 使用用户输入 - 需验证路径'),
    
    (r'send_file\s*\(\s*.*(request|req|params)',
     'MEDIUM', 'send_file 使用用户输入 - 需路径验证'),
    
    (r'send_from_directory\s*\(\s*.*(request|req|params)',
     'LOW', 'send_from_directory - 确保使用相对路径'),
    
    (r'express\.static\s*\(',
     'LOW', '静态文件服务 - 确保目录安全'),
]

def is_path_safe(filepath):
    """检查路径是否安全（防止路径遍历）"""
    normalized = os.path.normpath(filepath)
    return not normalized.startswith('..') and not normalized.startswith('/')
```

---

### 2. 敏感信息与凭证检测

#### 2.1 密钥、密码、Token 检测

```bash
# === 敏感信息检测正则表达式 ===

# AWS Access Key
rg -e 'AKIA[0-9A-Z]{16}' --glob '!node_modules/*'

# AWS Secret Key
rg -e '(?i)aws(.{0,20})?(?-i)["\x27]?[A-Za-z0-9/+=]{40}["\x27]?' --glob '!node_modules/*'

# GitHub Token
rg -e 'gh[pousr]_[A-Za-z0-9_]{36,}' --glob '!node_modules/*'

# Google API Key
rg -e 'AIza[0-9A-Za-z\-_]{35}' --glob '!node_modules/*'

# Slack Token
rg -e 'xox[baprs]-[0-9]{10,13}-[0-9A-Za-z]{24,}' --glob '!node_modules/*'

# Stripe API Key
rg -e '(?i)(sk|pk)_(test|live)_[0-9a-z]{24,}' --glob '!node_modules/*'

# Private Key (RSA, DSA, EC)
rg -e '-----BEGIN (RSA |DSA |EC )?PRIVATE KEY-----' --glob '!node_modules/*'

# JWT Token (硬编码)
rg -e 'eyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]+' --glob '!node_modules/*'

# 数据库连接字符串
rg -e '(?i)(mongodb|mysql|postgres|redis|amqp)://[^:]+:[^@]+@[^\s"\x27]+' --glob '!node_modules/*'

# 通用密码/密钥模式
rg -e '(?i)(password|passwd|pwd|secret|token|api_key|apikey|access_key|secret_key)\s*[:=]\s*["\x27]?[^\s"\x27,}{]{8,}' --glob '!node_modules/*' --glob '!**/*.md'

# 硬编码 IP 地址（可能的内部服务暴露）
rg -e '\b(10|172\.(1[6-9]|2[0-9]|3[01])|192\.168)\.\d{1,3}\.\d{1,3}\b' --glob '!node_modules/*' --type-add 'code:r|py|js|ts|java|go|yaml|yml|json|toml|cfg|ini|env' -t code
```

```python
# === 敏感信息检测脚本 ===

import re
import os

SECRET_PATTERNS = [
    # API Keys
    (r'AKIA[0-9A-Z]{16}', 'CRITICAL', 'AWS Access Key ID'),
    (r'(?:A3T[A-Z0-9]|ABIA|ACCA|AGPA|AIDA|AIPA|ANPA|ANVA|APKA|AROA|ASCA|ASIA)[A-Z0-9]{16}',
     'CRITICAL', 'AWS 签名密钥标识'),
    (r'gh[pousr]_[A-Za-z0-9_]{36,}', 'CRITICAL', 'GitHub Token'),
    (r'AIza[0-9A-Za-z\-_]{35}', 'CRITICAL', 'Google API Key'),
    (r'xox[baprs]-[0-9]{10,13}-[0-9A-Za-z]{24,}', 'CRITICAL', 'Slack Token'),
    (r'(?:sk|pk)_(?:test|live)_[0-9a-z]{24,}', 'CRITICAL', 'Stripe API Key'),
    
    # Private Keys
    (r'-----BEGIN\s+(?:RSA\s+|DSA\s+|EC\s+)?PRIVATE\s+KEY-----', 'CRITICAL', '私钥文件'),
    
    # Database Connection Strings
    (r'(?:mongodb(?:\+srv)?|mysql|postgres(?:ql)?|redis|amqp)://[^\s"\x27]+:[^\s"\x27]+@[^\s"\x27]+',
     'HIGH', '数据库连接字符串（含密码）'),
    
    # JWT Tokens
    (r'eyJ[A-Za-z0-9-_]+\.eyJ[A-Za-z0-9-_]+\.[A-Za-z0-9-_]{20,}', 'HIGH', '硬编码 JWT Token'),
    
    # Generic Secrets
    (r'(?:password|passwd|pwd)\s*[:=]\s*["\x27]?[^\s"\x27,}{]{6,}', 'HIGH', '密码字段'),
    (r'(?:secret[_-]?key|api[_-]?key|access[_-]?key|private[_-]?key)\s*[:=]\s*["\x27]?[^\s"\x27,}{]{8,}',
     'HIGH', 'API 密钥字段'),
    (r'(?:auth[_-]?token|bearer|session[_-]?token)\s*[:=]\s*["\x27]?[^\s"\x27,}{]{8,}',
     'MEDIUM', '认证令牌字段'),
    
    # Internal IP Addresses
    (r'\b(10|172\.(?:1[6-9]|2[0-9]|3[01])|192\.168)\.\d{1,3}\.\d{1,3}\b',
     'LOW', '内网 IP 地址（可能是硬编码服务地址）'),
]

def scan_secrets(directory, exclude_dirs=None, exclude_files=None):
    """扫描目录中的敏感信息"""
    exclude_dirs = set(exclude_dirs or ['node_modules', 'vendor', '.git', '__pycache__', 'dist', 'build'])
    exclude_files = set(exclude_files or ['package-lock.json', 'yarn.lock', '.env.example'])
    results = []
    
    # 文件扩展名白名单
    code_extensions = {'.py', '.js', '.ts', '.jsx', '.tsx', '.java', '.go', '.php', '.rb',
                       '.yml', '.yaml', '.json', '.toml', '.cfg', '.ini', '.env', '.conf',
                       '.sh', '.bash', '.zsh', '.ps1', '.cmd', '.bat'}
    
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in exclude_dirs]
        
        for file in files:
            if file in exclude_files:
                continue
            
            ext = os.path.splitext(file)[1]
            if ext not in code_extensions:
                continue
            
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
                
                for line_num, line in enumerate(lines, 1):
                    # 跳过注释行
                    stripped = line.strip()
                    if stripped.startswith('#') or stripped.startswith('//') or stripped.startswith('*'):
                        continue
                    
                    for pattern, severity, description in SECRET_PATTERNS:
                        if re.search(pattern, line, re.IGNORECASE):
                            # 脱敏处理
                            masked = re.sub(r'[A-Za-z0-9]{4}', '****', stripped[:80])
                            results.append({
                                'file': filepath,
                                'line': line_num,
                                'severity': severity,
                                'pattern': description,
                                'masked_code': masked
                            })
            except Exception:
                continue
    
    return sorted(results, key=lambda x: {
        'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3
    }[x['severity']])
```

---

### 3. 依赖漏洞扫描

#### 3.1 npm 依赖审计

```bash
# === npm 依赖安全审计 ===

# 基础审计
npm audit --json > npm_audit_report.json

# 仅检查高危漏洞
npm audit --audit-level=high

# 检查生产依赖
npm audit --omit=dev

# 自动修复
npm audit fix

# 自动修复（含破坏性更新）
npm audit fix --force

# 检查过时依赖
npm outdated --json > npm_outdated.json

# 检查许可证合规
npx license-checker --summary --production

# 检查依赖中的已知漏洞（使用 snyk 替代方案）
npx snyk test --json > snyk_report.json
```

#### 3.2 Python 依赖审计

```bash
# === Python 依赖安全审计 ===

# 使用 pip-audit
pip install pip-audit
pip-audit -r requirements.txt --format json > pip_audit_report.json
pip-audit -r requirements.txt --format html > pip_audit_report.html
pip-audit --desc --format columns

# 使用 safety
pip install safety
safety check -r requirements.txt --json > safety_report.json
safety check --full-report

# 检查 pip 过时包
pip list --outdated --format=json > pip_outdated.json

# 使用 bandit 扫描 Python 代码安全
pip install bandit
bandit -r ./src -f json -o bandit_report.json
bandit -r ./src -f html -o bandit_report.html
bandit -r ./src -ll  # 仅显示低及以上级别
```

#### 3.3 Rust/Cargo 依赖审计

```bash
# === Rust Cargo 依赖审计 ===

cargo install cargo-audit
cargo audit  # 基础审计
cargo audit --json > cargo_audit_report.json

# 检查过时依赖
cargo install cargo-outdated
cargo outdated

# 检查许可证
cargo install cargo-lichking
cargo lichking check
```

---

### 4. 反序列化漏洞检测

```python
# === 不安全反序列化检测 ===

DESERIALIZATION_PATTERNS = [
    # Python pickle（高危）
    (r'pickle\.(load|loads)\s*\(', 'CRITICAL',
     'pickle.load/loads - 反序列化任意代码执行风险，使用 json 或 safer alternatives'),
    
    (r'pickle\.dump\s*\(', 'MEDIUM',
     'pickle.dump - 仅序列化可信数据'),
    
    # Python yaml.load (不安全)
    (r'yaml\.load\s*\(\s*[^,)]*\)', 'HIGH',
     'yaml.load() 未指定 Loader - 使用 yaml.safe_load()'),
    
    # Python shelve
    (r'shelve\.open\s*\(', 'MEDIUM',
     'shelve 使用 pickle - 需确保数据来源可信'),
    
    # Java ObjectInputStream
    (r'ObjectInputStream\s*\(', 'CRITICAL',
     'Java ObjectInputStream - 反序列化漏洞风险'),
    
    # Java readObject
    (r'\.readObject\s*\(\s*\)', 'HIGH',
     'Java readObject - 反序列化漏洞风险'),
    
    # JSON.parse (相对安全，但需注意 prototype pollution)
    (r'JSON\.parse\s*\(\s*[^)]*\breq\b', 'LOW',
     'JSON.parse 解析用户输入 - 注意原型污染'),
    
    # eval + JSON
    (r'eval\s*\(\s*["\x27]\s*\(', 'CRITICAL',
     'eval 解析 JSON - 使用 JSON.parse 替代'),
    
    # PHP unserialize
    (r'unserialize\s*\(', 'CRITICAL',
     'PHP unserialize - 严重的反序列化漏洞'),
]

def scan_deserialization(directory):
    """扫描不安全的反序列化操作"""
    results = []
    for root, dirs, files in os.walk(directory):
        dirs[:] = [d for d in dirs if d not in ['node_modules', 'vendor', '.git', '__pycache__']]
        
        for file in files:
            ext = os.path.splitext(file)[1]
            if ext not in ['.py', '.java', '.php', '.js', '.ts']:
                continue
            
            filepath = os.path.join(root, file)
            try:
                with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                    lines = f.readlines()
                
                for line_num, line in enumerate(lines, 1):
                    for pattern, severity, description in DESERIALIZATION_PATTERNS:
                        if re.search(pattern, line):
                            results.append({
                                'file': filepath,
                                'line': line_num,
                                'severity': severity,
                                'pattern': description,
                                'code': line.strip()
                            })
            except Exception:
                continue
    
    return sorted(results, key=lambda x: {
        'CRITICAL': 0, 'HIGH': 1, 'MEDIUM': 2, 'LOW': 3
    }[x['severity']])
```

---

### 5. 安全头部验证

```python
# === HTTP 安全头部检测脚本 ===

SECURITY_HEADERS = {
    'Strict-Transport-Security': {
        'description': 'HSTS - 强制 HTTPS 连接',
        'recommended': 'max-age=31536000; includeSubDomains; preload',
        'severity': 'HIGH',
        'check': lambda v: v and 'max-age' in v and int(v.split('max-age=')[1].split(';')[0]) >= 31536000
    },
    'Content-Security-Policy': {
        'description': 'CSP - 内容安全策略，防止 XSS',
        'recommended': "default-src 'self'",
        'severity': 'HIGH',
        'check': lambda v: v and ("'self'" in v or 'default-src' in v)
    },
    'X-Content-Type-Options': {
        'description': '防止 MIME 类型嗅探',
        'recommended': 'nosniff',
        'severity': 'MEDIUM',
        'check': lambda v: v == 'nosniff'
    },
    'X-Frame-Options': {
        'description': '防止点击劫持',
        'recommended': 'DENY',
        'severity': 'MEDIUM',
        'check': lambda v: v in ('DENY', 'SAMEORIGIN')
    },
    'X-XSS-Protection': {
        'description': 'XSS 过滤器（已弃用但仍建议设置）',
        'recommended': '0',
        'severity': 'LOW',
        'check': lambda v: True
    },
    'Referrer-Policy': {
        'description': '引用策略控制',
        'recommended': 'strict-origin-when-cross-origin',
        'severity': 'LOW',
        'check': lambda v: v and 'strict' in v
    },
    'Permissions-Policy': {
        'description': '权限策略控制',
        'recommended': 'camera=(), microphone=(), geolocation=()',
        'severity': 'LOW',
        'check': lambda v: v is not None
    },
}

def check_security_headers(url):
    """检查 URL 的安全头部配置"""
    import urllib.request
    
    results = []
    try:
        request = urllib.request.Request(url, method='HEAD')
        response = urllib.request.urlopen(request, timeout=10)
        headers = dict(response.headers)
    except Exception as e:
        return [{'header': 'CONNECTION', 'status': 'ERROR', 'message': str(e)}]
    
    for header, config in SECURITY_HEADERS.items():
        value = headers.get(header.lower(), headers.get(header, None))
        
        if value is None:
            status = 'MISSING'
            message = f"缺少 {header} 头部"
        elif config['check'](value):
            status = 'OK'
            message = f"{header}: {value}"
        else:
            status = 'WARNING'
            message = f"{header} 值不安全: {value} (推荐: {config['recommended']})"
        
        results.append({
            'header': header,
            'status': status,
            'severity': config['severity'],
            'description': config['description'],
            'message': message,
            'current_value': value,
            'recommended': config['recommended']
        })
    
    return results
```

---

### 6. 容器安全扫描

#### 6.1 Dockerfile 安全最佳实践检查

```bash
# === Dockerfile 安全检查 ===

# 检查是否以 root 运行
rg -t dockerfile -e '(USER\s+root|^(?!.*USER\s))' Dockerfile

# 检查是否使用 latest 标签
rg -t dockerfile -e 'FROM.*:latest' Dockerfile

# 检查是否包含敏感信息
rg -t dockerfile -e '(ENV\s+.*(PASSWORD|SECRET|TOKEN|KEY)|COPY\s+.*\.env)' Dockerfile

# 检查 ADD vs COPY
rg -t dockerfile -e 'ADD\s+(?!https://)' Dockerfile

# 检查是否暴露过多端口
rg -t dockerfile -e 'EXPOSE\s+(.*\s){3,}' Dockerfile
```

```python
# === Dockerfile 安全审计脚本 ===

DOCKERFILE_RULES = [
    # 高危规则
    (r'FROM\s+.*:latest', 'HIGH',
     '使用 :latest 标签 — 镜像不可复现，应指定明确版本号'),
    
    (r'^(?!.*\bUSER\b).*CMD', 'HIGH',
     '未指定 USER — 容器默认以 root 运行'),
    
    (r'ENV\s+.*(PASSWORD|SECRET|TOKEN|API_KEY|PRIVATE_KEY)\s*=', 'CRITICAL',
     'Dockerfile 中硬编码敏感环境变量'),
    
    (r'COPY\s+.*\.(env|pem|key|p12|jks)', 'CRITICAL',
     '复制敏感文件到镜像'),
    
    (r'RUN\s+.*curl\s+.*\|\s*(bash|sh)', 'CRITICAL',
     '管道 curl 到 shell — 供应链攻击风险'),
    
    (r'RUN\s+.*wget\s+.*\|\s*(bash|sh)', 'CRITICAL',
     '管道 wget 到 shell — 供应链攻击风险'),
    
    # 中危规则
    (r'EXPOSE\s+22', 'MEDIUM',
     '暴露 SSH 端口 — 容器通常不应运行 SSH'),
    
    (r'ADD\s+(?!https?://)', 'MEDIUM',
     '使用 ADD 替代 COPY — ADD 可能解压远程文件'),
    
    (r'--privileged', 'CRITICAL',
     '使用特权模式 — 授予容器完整主机权限'),
    
    (r'--cap-add\s+ALL', 'CRITICAL',
     '添加所有 Linux 能力 — 权限过大'),
    
    # 低危规则
    (r'RUN\s+apt-get\s+install(?!.*--no-install-recommends)', 'LOW',
     'apt-get install 未使用 --no-install-recommends — 增加镜像体积'),
    
    (r'RUN\s+apt-get\s+update(?!.*rm\s+-rf\s+/var/lib/apt)', 'LOW',
     'apt-get update 后未清理缓存 — 增加镜像体积'),
]

def audit_dockerfile(filepath):
    """审计 Dockerfile 安全性"""
    results = []
    try:
        with open(filepath, 'r') as f:
            lines = f.readlines()
        
        for line_num, line in enumerate(lines, 1):
            for pattern, severity, description in DOCKERFILE_RULES:
                if re.search(pattern, line, re.IGNORECASE):
                    results.append({
                        'line': line_num,
                        'severity': severity,
                        'rule': description,
                        'code': line.strip()
                    })
    except Exception as e:
        results.append({'line': 0, 'severity': 'ERROR', 'rule': str(e), 'code': ''})
    
    return results
```

---

### 7. 基础设施即代码（IaC）安全扫描

```bash
# === Terraform 安全扫描 ===

# 检查安全组规则过于宽松
rg -t hcl -t tf \
  -e '(cidr_blocks\s*=\s*\["0\.0\.0\.0/0"\]|ingress.*from_port.*to_port)' \
  --glob '!.terraform/*'

# 检查未加密的资源
rg -t hcl -t tf \
  -e '(encryption\s*=\s*false|encrypt\s*=\s*false)' \
  --glob '!.terraform/*'

# 检查公开的 S3 存储桶
rg -t hcl -t tf \
  -e 'acl\s*=\s*"public-read"' \
  --glob '!.terraform/*'

# 检查未启用日志
rg -t hcl -t tf \
  -e 'enable_logging\s*=\s*false' \
  --glob '!.terraform/*'

# 检查 IAM 策略中的通配符
rg -t hcl -t tf \
  -e '(Resource\s*=\s*"\*"|Action\s*=\s*"\*")' \
  --glob '!.terraform/*'

# 使用 tfsec 进行全面扫描
# brew install tfsec  (macOS)
# apt install tfsec   (Linux)
tfsec ./terraform --format json > tfsec_report.json
tfsec ./terraform --format table
```

```python
# === Terraform 安全规则 ===

TERRAFORM_RULES = [
    (r'cidr_blocks\s*=\s*\["0\.0\.0\.0/0"\]', 'HIGH',
     '安全组允许所有 IP 访问（0.0.0.0/0）'),
    
    (r'acl\s*=\s*"public-read"', 'HIGH',
     'S3 存储桶设为公开读'),
    
    (r'acl\s*=\s*"public-read-write"', 'CRITICAL',
     'S3 存储桶设为公开读写'),
    
    (r'encryption\s*=\s*false', 'MEDIUM',
     '资源未启用加密'),
    
    (r'enable_logging\s*=\s*false', 'MEDIUM',
     '未启用日志记录'),
    
    (r'Resource\s*=\s*"\*"', 'HIGH',
     'IAM 策略使用通配符资源'),
    
    (r'Action\s*=\s*"\*"', 'HIGH',
     'IAM 策略使用通配符动作'),
    
    (r'publicly_accessible\s*=\s*true', 'HIGH',
     '资源设为公开可访问'),
    
    (r'skip_final_snapshot\s*=\s*true', 'MEDIUM',
     '数据库跳过最终快照'),
    
    (r'multi_az\s*=\s*false', 'LOW',
     '数据库未启用多可用区'),
]
```

---

### 8. 综合审计报告生成

```python
# === 安全审计报告生成 ===

from datetime import datetime
import json

class SecurityAuditReport:
    """安全审计报告生成器"""
    
    def __init__(self, project_name, scan_directory):
        self.project_name = project_name
        self.scan_directory = scan_directory
        self.scan_time = datetime.now().isoformat()
        self.findings = {
            'CRITICAL': [],
            'HIGH': [],
            'MEDIUM': [],
            'LOW': [],
        }
    
    def add_finding(self, severity, category, file_path, line_num, description, code_snippet=''):
        """添加安全发现"""
        self.findings[severity].append({
            'category': category,
            'file': file_path,
            'line': line_num,
            'description': description,
            'code': code_snippet,
        })
    
    def run_full_audit(self):
        """执行完整安全审计"""
        print(f"🔍 开始安全审计: {self.project_name}")
        print(f"📁 扫描目录: {self.scan_directory}")
        
        # 1. SQL 注入检测
        print("\n  [1/7] 扫描 SQL 注入漏洞...")
        sql_results = scan_sql_injection(self.scan_directory)
        for r in sql_results:
            self.add_finding(r['severity'], 'SQL注入', r['file'], r['line'],
                           r['pattern'], r['code'])
        print(f"  ✅ 发现 {len(sql_results)} 个 SQL 注入风险")
        
        # 2. XSS 检测
        print("  [2/7] 扫描 XSS 漏洞...")
        xss_results = scan_xss(self.scan_directory)
        for r in xss_results:
            self.add_finding(r['severity'], 'XSS', r['file'], r['line'],
                           r['pattern'], r['code'])
        print(f"  ✅ 发现 {len(xss_results)} 个 XSS 风险")
        
        # 3. 敏感信息检测
        print("  [3/7] 扫描敏感信息泄露...")
        secret_results = scan_secrets(self.scan_directory)
        for r in secret_results:
            self.add_finding(r['severity'], '敏感信息', r['file'], r['line'],
                           r['pattern'], r.get('masked_code', ''))
        print(f"  ✅ 发现 {len(secret_results)} 个敏感信息泄露")
        
        # 4. 反序列化检测
        print("  [4/7] 扫描不安全反序列化...")
        deser_results = scan_deserialization(self.scan_directory)
        for r in deser_results:
            self.add_finding(r['severity'], '反序列化', r['file'], r['line'],
                           r['pattern'], r['code'])
        print(f"  ✅ 发现 {len(deser_results)} 个反序列化风险")
        
        # 5. Dockerfile 审计
        print("  [5/7] 扫描容器安全...")
        dockerfile_path = os.path.join(self.scan_directory, 'Dockerfile')
        if os.path.exists(dockerfile_path):
            docker_results = audit_dockerfile(dockerfile_path)
            for r in docker_results:
                self.add_finding(r['severity'], '容器安全', 'Dockerfile',
                               r['line'], r['rule'], r['code'])
            print(f"  ✅ 发现 {len(docker_results)} 个容器安全问题")
        else:
            print("  ⏭️ 未找到 Dockerfile，跳过")
        
        # 6. IaC 安全扫描
        print("  [6/7] 扫描基础设施即代码...")
        tf_dir = os.path.join(self.scan_directory, 'terraform')
        if os.path.exists(tf_dir):
            # 简化的 Terraform 扫描
            print("  ✅ Terraform 目录已找到")
        else:
            print("  ⏭️ 未找到 Terraform 配置，跳过")
        
        # 7. 安全头部检查
        print("  [7/7] 安全头部检查...")
        print("  ℹ️ 需要指定目标 URL 进行检测")
        
        return self
    
    def generate_markdown(self, output_path='security_report.md'):
        """生成 Markdown 格式报告"""
        total = sum(len(v) for v in self.findings.values())
        
        report = f"""# 安全审计报告：{self.project_name}

## 概要

| 项目 | 值 |
|------|-----|
| 项目名称 | {self.project_name} |
| 扫描目录 | {self.scan_directory} |
| 扫描时间 | {self.scan_time} |
| 总发现问题 | {total} |

## 严重程度统计

| 严重程度 | 数量 |
|---------|------|
| 🔴 CRITICAL | {len(self.findings['CRITICAL'])} |
| 🟠 HIGH | {len(self.findings['HIGH'])} |
| 🟡 MEDIUM | {len(self.findings['MEDIUM'])} |
| 🔵 LOW | {len(self.findings['LOW'])} |

"""
        
        for severity in ['CRITICAL', 'HIGH', 'MEDIUM', 'LOW']:
            findings = self.findings[severity]
            if not findings:
                continue
            
            report += f"## {severity} 级别问题\n\n"
            
            for i, finding in enumerate(findings, 1):
                report += f"""### {i}. {finding['category']}

- **文件**: `{finding['file']}:{finding['line']}`
- **描述**: {finding['description']}
"""
                if finding['code']:
                    report += f"- **代码**: `{finding['code']}`\n"
                report += "\n"
        
        report += """## 修复建议

### CRITICAL 级别（立即修复）
1. 移除所有硬编码的密钥和密码，使用环境变量或密钥管理服务
2. 替换所有不安全的反序列化操作（pickle → json）
3. 修复所有 SQL 注入漏洞，使用参数化查询
4. 移除容器特权模式

### HIGH 级别（尽快修复）
1. 修复 XSS 漏洞，对用户输入进行 HTML 转义
2. 配置安全 HTTP 头部
3. 修复路径遍历漏洞，验证文件路径
4. 更新已知漏洞的依赖

### MEDIUM 级别（计划修复）
1. 启用资源加密
2. 配置安全组规则，限制 IP 访问
3. 启用日志记录
4. 优化 Dockerfile 构建过程

---
*本报告由安全审计工具包自动生成*
"""
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(report)
        
        print(f"\n📊 报告已生成: {output_path}")
        return output_path
    
    def generate_json(self, output_path='security_report.json'):
        """生成 JSON 格式报告"""
        report_data = {
            'project': self.project_name,
            'scan_time': self.scan_time,
            'directory': self.scan_directory,
            'summary': {
                severity: len(findings)
                for severity, findings in self.findings.items()
            },
            'findings': self.findings
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(report_data, f, ensure_ascii=False, indent=2)
        
        print(f"📊 JSON 报告已生成: {output_path}")
        return output_path


# === 使用示例 ===
# report = SecurityAuditReport('my-project', './src')
# report.run_full_audit()
# report.generate_markdown()
# report.generate_json()
```

---

### 9. CloudFormation 安全扫描

```bash
# === CloudFormation 安全检查 ===

# 检查公开安全组
rg -t yaml -t yml \
  -e 'CidrIp:\s*!Ref\s|CidrIp:\s*0\.0\.0\.0/0' \
  --glob '!node_modules/*'

# 检查未加密 EBS 卷
rg -t yaml -t yml \
  -e 'Encrypted:\s*false' \
  --glob '!node_modules/*'

# 检查 IAM 管理员策略
rg -t yaml -t yml \
  -e 'arn:aws:iam::aws:policy/AdministratorAccess' \
  --glob '!node_modules/*'

# 使用 cfn-guard 进行策略检查
# pip install cfn-guard
cfn-guard validate ./cloudformation/template.yaml
```

---

### 10. Kubernetes 安全扫描

```bash
# === Kubernetes 清单安全检查 ===

# 检查特权容器
rg -t yaml -e 'privileged:\s*true' --glob '!node_modules/*'

# 检查 hostNetwork/hostPID/hostIPC
rg -t yaml -e 'host(Network|PID|IPC):\s*true' --glob '!node_modules/*'

# 检查 ServiceAccount token 自动挂载
rg -t yaml -e 'automountServiceAccountToken:\s*true' --glob '!node_modules/*'

# 检查未限制的 capabilities
rg -t yaml -e 'add:\s*\["ALL"\]' --glob '!node_modules/*'

# 检查允许提权的容器
rg -t yaml -e 'allowPrivilegeEscalation:\s*true' --glob '!node_modules/*'

# 使用 Trivy 扫描
# trivy config ./k8s/
```

---

### 11. 代码安全最佳实践清单

#### 11.1 输入验证

```python
# ✅ 安全：使用白名单验证
import re

def validate_username(username):
    if not isinstance(username, str):
        return False
    return bool(re.match(r'^[a-zA-Z0-9_]{3,32}$', username))

def validate_id(user_id):
    """验证 ID 是否为正整数"""
    try:
        return int(user_id) > 0
    except (ValueError, TypeError):
        return False

# ❌ 不安全：直接使用用户输入
# def unsafe_handler(request):
#     query = f"SELECT * FROM users WHERE id = {request.args.get('id')}"
```

#### 11.2 输出编码

```python
# ✅ 安全：HTML 转义输出
import html

def render_template(user_input):
    escaped = html.escape(user_input)
    return f"<div>{escaped}</div>"

# ✅ 安全：JSON 输出
import json

def json_response(data):
    return json.dumps(data, ensure_ascii=False)

# ❌ 不安全：直接拼接 HTML
# def unsafe_render(user_input):
#     return f"<div>{user_input}</div>"
```

#### 11.3 认证与授权

```python
# ✅ 安全：使用标准库处理密码
import hashlib
import secrets
import os

def hash_password(password):
    """使用 PBKDF2 哈希密码"""
    salt = os.urandom(32)
    key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 600000)
    return salt + key

def verify_password(password, stored_hash):
    """验证密码"""
    salt = stored_hash[:32]
    key = stored_hash[32:]
    new_key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 600000)
    return secrets.compare_digest(key, new_key)

# 生成安全随机令牌
def generate_token(length=32):
    return secrets.token_urlsafe(length)
```

---

## 使用指南

当用户请求安全审计时，按以下步骤操作：

1. **确认范围**：确定要扫描的目录和文件类型。
2. **选择扫描模式**：
   - 快速扫描：仅敏感信息和 SQL 注入检测
   - 标准扫描：OWASP Top 10 全项检测
   - 全面审计：包含依赖扫描、容器安全、IaC 安全
3. **执行扫描**：运行相应的检测脚本和命令。
4. **生成报告**：输出 Markdown 或 JSON 格式的审计报告。
5. **提供修复建议**：针对每个发现提供具体的修复方案。

---

## 常见场景示例

### 场景 1：代码仓库安全扫描
```
请对我的项目 ./src 目录进行全面安全审计，生成 Markdown 格式报告。
```

### 场景 2：敏感信息检测
```
检查这个代码仓库中是否泄露了 API Key、密码或私钥。
```

### 场景 3：Docker 镜像安全
```
审查我的 Dockerfile 是否存在安全问题。
```

### 场景 4：依赖漏洞检查
```
检查项目的依赖包是否存在已知安全漏洞。
```
