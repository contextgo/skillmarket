#!/bin/bash
# 贵金属价格查询测试脚本
# 测试增强版API的各种功能

echo "=========================================="
echo "贵金属价格查询增强版 - 功能测试"
echo "=========================================="
echo ""

# 设置脚本路径
SCRIPT_PATH="$HOME/.openclaw/workspace/skills/precious-metals/scripts/enhanced_metals_api.py"

# 测试1: 查询所有贵金属
echo "📝 测试1: 查询所有贵金属价格"
echo "----------------------------------------"
python "$SCRIPT_PATH" --table
echo ""

# 测试2: 查询黄金详情
echo "📝 测试2: 查询黄金详情（含技术分析）"
echo "----------------------------------------"
python "$SCRIPT_PATH" --metal gold --analysis
echo ""

# 测试3: 价格趋势图
echo "📝 测试3: 黄金7日价格趋势图"
echo "----------------------------------------"
python "$SCRIPT_PATH" --metal gold --trend --days 7
echo ""

# 测试4: 价格趋势表格
echo "📝 测试4: 黄金30日价格趋势表格"
echo "----------------------------------------"
python "$SCRIPT_PATH" --metal gold --trend --days 30 --chart-type table
echo ""

# 测试5: 设置价格预警
echo "📝 测试5: 设置价格预警"
echo "----------------------------------------"
python "$SCRIPT_PATH" --alert add gold above 2200 "测试预警-突破2200"
echo ""

# 测试6: 列出价格预警
echo "📝 测试6: 列出价格预警"
echo "----------------------------------------"
python "$SCRIPT_PATH" --alert list
echo ""

# 测试7: 删除价格预警（需要先获取alert_id）
echo "📝 测试7: 删除价格预警"
echo "----------------------------------------"
# 获取第一个预警的ID并删除
ALERT_ID=$(python "$SCRIPT_PATH" --alert list 2>/dev/null | grep -E "^[a-f0-9]{8}" | head -1 | awk '{print $1}')
if [ -n "$ALERT_ID" ]; then
    python "$SCRIPT_PATH" --alert remove "$ALERT_ID"
else
    echo "没有可删除的预警"
fi
echo ""

echo "=========================================="
echo "✅ 所有测试完成"
echo "=========================================="
echo ""
echo "⚠️ 注意: 部分测试可能因网络问题返回模拟数据"
echo "⚠️ 所有价格数据仅供参考，不构成投资建议"