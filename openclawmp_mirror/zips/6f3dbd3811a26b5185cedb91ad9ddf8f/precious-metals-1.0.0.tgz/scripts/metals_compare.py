#!/usr/bin/env python3
"""
贵金属数据源对比工具
用于验证不同数据源的价格准确性
"""

import requests
import json
from datetime import datetime

HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
}

def fetch_gold_api():
    """Gold-API.com"""
    try:
        data = {}
        for symbol in ['XAU', 'XAG', 'XPT', 'XPD']:
            resp = requests.get(f"https://api.gold-api.com/price/{symbol}", 
                              headers=HEADERS, timeout=10)
            if resp.status_code == 200:
                item = resp.json()
                data[symbol] = {
                    'price': item.get('price', 0),
                    'time': item.get('updatedAt', ''),
                    'source': 'Gold-API.com'
                }
        return data
    except Exception as e:
        print(f"Gold-API 错误：{e}")
        return {}

def fetch_sina():
    """新浪财经"""
    try:
        codes = 'hf_XAU,hf_XAG,hf_XPT,hf_XPD'
        url = f"https://hq.sinajs.cn/list={codes}"
        resp = requests.get(url, headers=HEADERS, timeout=10)
        resp.encoding = 'gbk'
        
        if resp.status_code != 200 or 'Forbidden' in resp.text:
            return {}
        
        data = {}
        mapping = {'hf_XAU': 'XAU', 'hf_XAG': 'XAG', 'hf_XPT': 'XPT', 'hf_XPD': 'XPD'}
        
        for line in resp.text.split('\n'):
            if '=' not in line:
                continue
            code = line.split('=')[0].split('_')[-2] + '_' + line.split('=')[0].split('_')[-1]
            if code in mapping:
                fields = line.split('"')[1].split(',') if '"' in line else []
                if len(fields) >= 6:
                    symbol = mapping[code]
                    price = float(fields[0]) if fields[0] else 0
                    # 检查是否需要除以 100
                    if price > 3000:  # 黄金超过$3000 可能是合约价格
                        price = price / 100
                    data[symbol] = {
                        'price': round(price, 2),
                        'time': fields[6] if len(fields) > 6 else '',
                        'source': '新浪财经'
                    }
        return data
    except Exception as e:
        print(f"新浪财经错误：{e}")
        return {}

def fetch_metals_api():
    """Metals-API.com (备用)"""
    try:
        # 免费接口，无需 API key
        resp = requests.get("https://metals-api.com/api/latest?access_key=demo", 
                          headers=HEADERS, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            rates = data.get('rates', {})
            # 转换为每盎司价格（demo 数据可能有限）
            return {'XAU': {'price': rates.get('XAU', 0), 'source': 'Metals-API'}}
    except:
        pass
    return {}

def main():
    print("=" * 70)
    print("贵金属数据源对比")
    print("=" * 70)
    print(f"查询时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    # 获取各数据源
    gold_api = fetch_gold_api()
    sina = fetch_sina()
    
    symbols = {
        'XAU': '黄金',
        'XAG': '白银',
        'XPT': '铂金',
        'XPD': '钯金'
    }
    
    print(f"{'品种':<8} {'Gold-API':<15} {'新浪财经':<15} {'差异':<10}")
    print("-" * 70)
    
    for symbol, name in symbols.items():
        gold_price = gold_api.get(symbol, {}).get('price', 0)
        sina_price = sina.get(symbol, {}).get('price', 0)
        
        gold_str = f"${gold_price:.2f}" if gold_price else "N/A"
        sina_str = f"${sina_price:.2f}" if sina_price else "N/A"
        
        diff = ""
        if gold_price and sina_price:
            diff_pct = abs(gold_price - sina_price) / gold_price * 100
            diff = f"{diff_pct:.2f}%"
        
        print(f"{name}({symbol}) {gold_str:<15} {sina_str:<15} {diff:<10}")
    
    print("-" * 70)
    print()
    print("数据来源说明:")
    print("  - Gold-API.com: 国际贵金属 API，免费无需密钥")
    print("  - 新浪财经：国内财经数据，可能有限制")
    print()
    print("⚠️ 如果数据源差异超过 3%，建议交叉验证多个来源")
    print("⚠️ 所有数据仅供参考，不构成投资建议")

if __name__ == '__main__':
    main()
