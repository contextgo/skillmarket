# 贵金属价格API技术参考文档

本文档提供贵金属价格API的详细技术信息。

## API数据源

### 主要数据源

1. **新浪财经贵金属API** - 国际现货价格
2. **东方财富网API** - 国内期货价格
3. **金十数据API** - 实时行情数据

### 数据源特点

| 数据源 | 更新频率 | 覆盖品种 | 延迟 |
|--------|---------|---------|------|
| 新浪财经 | 3秒 | 国际现货 | 实时 |
| 东方财富网 | 5秒 | 国内期货 | 实时 |
| 金十数据 | 1秒 | 全品种 | 实时 |

## API端点

### 新浪财经贵金属API

**国际现货黄金：**
```
https://finance.sina.com.cn/realstock/company/hf_XAU/nc.shtml
```

**API接口：**
```
https://hq.sinajs.cn/list=hf_XAU,hf_XAG,hf_XPT,hf_XPD
```

**响应示例：**
```
var hq_str_hf_XAU="黄金,1825.50,1826.30,1824.80,1825.60,1823.40,1827.80,12345,2024-03-18,15:30:00";
```

### 东方财富网期货API

**国内期货合约：**
```
https://push2.eastmoney.com/api/qt/clist/get
```

**请求参数：**
```json
{
  "pn": 1,
  "pz": 20,
  "fs": "m:113,m:114,m:115,m:8",
  "fields": "f1,f2,f3,f4,f5,f6,f7,f8,f9,f10,f12,f13,f14,f15,f16,f17,f18"
}
```

### 金十数据API

**贵金属实时行情：**
```
https://www.jin10.com/data.json
```

## 数据格式

### 国际现货贵金属数据结构

```json
{
  "symbol": "XAU",
  "name": "黄金",
  "price": 1825.50,
  "change": 2.30,
  "change_percent": 0.13,
  "high": 1827.80,
  "low": 1823.40,
  "open": 1826.30,
  "last_close": 1823.20,
  "volume": 12345,
  "time": "2024-03-18 15:30:00",
  "currency": "USD",
  "unit": "oz"
}
```

### 国内期货数据结构

```json
{
  "symbol": "AU2404",
  "name": "沪金2404",
  "price": 465.32,
  "change": 1.25,
  "change_percent": 0.27,
  "high": 466.80,
  "low": 464.50,
  "open": 465.80,
  "last_close": 464.07,
  "volume": 123456,
  "amount": 5745678900,
  "time": "2024-03-18 15:00:00",
  "currency": "CNY",
  "unit": "g"
}
```

## 字段说明

### 价格字段

| 字段 | 类型 | 说明 | 示例 |
|------|------|------|------|
| symbol | string | 交易品种代码 | XAU, AU2404 |
| name | string | 品种名称 | 黄金, 沪金2404 |
| price | float | 当前价格 | 1825.50 |
| change | float | 涨跌额 | 2.30 |
| change_percent | float | 涨跌幅(%) | 0.13 |
| high | float | 最高价 | 1827.80 |
| low | float | 最低价 | 1823.40 |
| open | float | 开盘价 | 1826.30 |
| last_close | float | 昨收价 | 1823.20 |

### 交易量字段

| 字段 | 类型 | 说明 | 单位 |
|------|------|------|------|
| volume | int | 成交量 | 手/盎司 |
| amount | float | 成交额 | 元/美元 |

## 数据解析实现

### 新浪财经数据解析

```python
import requests

def fetch_precious_metals_sina():
    """获取新浪财经贵金属数据"""
    url = "https://hq.sinajs.cn/list=hf_XAU,hf_XAG,hf_XPT,hf_XPD"
    headers = {
        'Referer': 'https://finance.sina.com.cn/',
        'User-Agent': 'Mozilla/5.0'
    }

    try:
        response = requests.get(url, headers=headers, timeout=10)
        response.encoding = 'gbk'

        if response.status_code == 200:
            metals_data = []

            for line in response.text.split('\n'):
                if not line or '=' not in line:
                    continue

                # 提取品种代码
                symbol = line.split('_')[-1].split('=')[0]

                # 提取数据
                data_str = line.split('"')[1]
                fields = data_str.split(',')

                if len(fields) >= 10:
                    metal = {
                        'symbol': symbol,
                        'name': fields[0],
                        'open': float(fields[1]),
                        'last_close': float(fields[2]),
                        'price': float(fields[3]),
                        'high': float(fields[4]),
                        'low': float(fields[5]),
                        'volume': int(fields[6]),
                        'time': f"{fields[7]} {fields[8]}"
                    }

                    # 计算涨跌
                    metal['change'] = metal['price'] - metal['last_close']
                    metal['change_percent'] = (metal['change'] / metal['last_close']) * 100

                    metals_data.append(metal)

            return metals_data

    except Exception as e:
        print(f"获取数据失败: {e}")
        return []

    return []
```

### 东方财富期货数据解析

```python
def fetch_domestic_futures():
    """获取国内期货数据"""
    url = "https://push2.eastmoney.com/api/qt/clist/get"
    params = {
        'pn': 1,
        'pz': 50,
        'fs': 'm:113,m:114',  # 黄金和白银期货
        'fields': 'f12,f14,f2,f3,f4,f5,f6,f15,f16,f17,f18'
    }

    try:
        response = requests.get(url, params=params, timeout=10)

        if response.status_code == 200:
            data = response.json()
            futures_data = []

            for item in data.get('data', {}).get('diff', []):
                future = {
                    'symbol': item.get('f12', ''),
                    'name': item.get('f14', ''),
                    'price': float(item.get('f2', 0)) / 100,
                    'change_percent': float(item.get('f3', 0)) / 100,
                    'change': float(item.get('f4', 0)) / 100,
                    'volume': int(item.get('f5', 0)),
                    'amount': float(item.get('f6', 0)),
                    'high': float(item.get('f15', 0)) / 100,
                    'low': float(item.get('f16', 0)) / 100,
                    'open': float(item.get('f17', 0)) / 100,
                    'last_close': float(item.get('f18', 0)) / 100
                }

                futures_data.append(future)

            return futures_data

    except Exception as e:
        print(f"获取期货数据失败: {e}")
        return []

    return []
```

## 价格计算

### 涨跌幅计算

```python
def calculate_change_percent(current_price, last_close):
    """计算涨跌幅"""
    if last_close == 0:
        return 0.0

    change = current_price - last_close
    change_percent = (change / last_close) * 100

    return round(change_percent, 2)
```

### 单位转换

```python
# 盎司到克的转换
OUNCE_TO_GRAM = 31.1035

def convert_oz_to_gram(price_per_oz):
    """将盎司价格转换为克价格"""
    return price_per_oz / OUNCE_TO_GRAM

def convert_gram_to_oz(price_per_gram):
    """将克价格转换为盎司价格"""
    return price_per_gram * OUNCE_TO_GRAM
```

### 汇率影响

```python
def calculate_domestic_price(international_price, usd_cny_rate):
    """计算国内价格（考虑汇率）"""
    # 国际价格（美元/盎司）转换为国内价格（元/克）
    price_per_gram_usd = international_price / OUNCE_TO_GRAM
    price_per_gram_cny = price_per_gram_usd * usd_cny_rate

    return round(price_per_gram_cny, 2)
```

## 错误处理

### 网络请求重试

```python
import time

def fetch_with_retry(url, max_retries=3, timeout=10):
    """带重试的网络请求"""
    for attempt in range(max_retries):
        try:
            response = requests.get(url, headers=headers, timeout=timeout)
            if response.status_code == 200:
                return response
            elif response.status_code == 429:  # 请求频率限制
                wait_time = 60
                print(f"请求频率限制，等待{wait_time}秒...")
                time.sleep(wait_time)
                continue
            else:
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # 指数退避
                    continue
                else:
                    return None
        except requests.exceptions.Timeout:
            print(f"请求超时，尝试 {attempt + 1}/{max_retries}")
            if attempt < max_retries - 1:
                time.sleep(1)
                continue
        except requests.exceptions.RequestException as e:
            print(f"请求异常: {e}")
            if attempt < max_retries - 1:
                time.sleep(1)
                continue

    return None
```

### 数据验证

```python
def validate_metal_data(data):
    """验证贵金属数据完整性"""
    required_fields = ['symbol', 'name', 'price', 'time']

    for field in required_fields:
        if field not in data or data[field] is None:
            return False

    # 验证价格合理性
    if data['price'] <= 0:
        return False

    # 验证价格范围
    if data['symbol'] == 'XAU' and (data['price'] < 1000 or data['price'] > 3000):
        return False  # 黄金价格应在1000-3000美元/盎司

    return True
```

## 缓存策略

### 实现缓存机制

```python
import json
import os
from datetime import datetime, timedelta

class MetalsPriceCache:
    """贵金属价格缓存"""

    def __init__(self, cache_dir='/tmp/metals_cache', expire_seconds=30):
        self.cache_dir = cache_dir
        self.expire_seconds = expire_seconds
        os.makedirs(cache_dir, exist_ok=True)

    def get_cache_key(self, metal):
        """生成缓存键"""
        return os.path.join(self.cache_dir, f"{metal}.json")

    def get(self, metal):
        """获取缓存"""
        cache_file = self.get_cache_key(metal)

        if not os.path.exists(cache_file):
            return None

        # 检查缓存是否过期
        modify_time = datetime.fromtimestamp(os.path.getmtime(cache_file))
        if datetime.now() - modify_time > timedelta(seconds=self.expire_seconds):
            return None

        try:
            with open(cache_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except:
            return None

    def set(self, metal, data):
        """设置缓存"""
        cache_file = self.get_cache_key(metal)
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except:
            pass
```

## 市场时间判断

### 交易时间检查

```python
from datetime import datetime, time

def is_market_open(market='international'):
    """判断市场是否开盘"""
    now = datetime.now()
    current_time = now.time()
    weekday = now.weekday()

    if market == 'international':
        # 国际贵金属市场：周一早上6点到周六凌晨5点（北京时间）
        if weekday == 6:  # 周日
            return False
        elif weekday == 5:  # 周六
            return current_time < time(5, 0)
        elif weekday == 0:  # 周一
            return current_time >= time(6, 0)
        else:  # 周二到周五
            return True

    elif market == 'domestic':
        # 国内期货市场：工作日
        if weekday >= 5:  # 周末
            return False

        # 日盘：9:00-11:30, 13:30-15:00
        # 夜盘：21:00-次日2:30
        morning = time(9, 0) <= current_time <= time(11, 30)
        afternoon = time(13, 30) <= current_time <= time(15, 0)
        night = time(21, 0) <= current_time <= time(23, 59) or time(0, 0) <= current_time <= time(2, 30)

        return morning or afternoon or night

    return False
```

## 性能优化

### 批量查询

```python
def fetch_all_metals_parallel():
    """并发查询所有贵金属"""
    import concurrent.futures

    metals = ['XAU', 'XAG', 'XPT', 'XPD']
    results = {}

    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        future_to_metal = {executor.submit(fetch_metal_price, metal): metal for metal in metals}

        for future in concurrent.futures.as_completed(future_to_metal):
            metal = future_to_metal[future]
            try:
                data = future.result()
                results[metal] = data
            except Exception as e:
                print(f"{metal} 查询失败: {e}")

    return results
```

## 数据质量保证

### 异常价格检测

```python
# 正常价格范围
PRICE_RANGES = {
    'XAU': (1000, 3000),   # 黄金：1000-3000美元/盎司
    'XAG': (10, 50),       # 白银：10-50美元/盎司
    'XPT': (500, 1500),    # 铂金：500-1500美元/盎司
    'XPD': (1000, 4000),   # 钯金：1000-4000美元/盎司
}

def detect_abnormal_price(symbol, price):
    """检测异常价格"""
    if symbol not in PRICE_RANGES:
        return False

    min_price, max_price = PRICE_RANGES[symbol]

    if price < min_price or price > max_price:
        print(f"警告: {symbol} 价格 {price} 超出正常范围 [{min_price}, {max_price}]")
        return True

    return False
```

## 使用建议

### 查询频率

- **实时监控**：建议每30秒查询一次
- **一般查询**：建议每5-10分钟查询一次
- **历史数据**：可降低查询频率

### 数据源切换

```python
def fetch_metal_price_with_fallback(metal):
    """带降级策略的价格查询"""
    sources = [
        fetch_from_sina,
        fetch_from_eastmoney,
        fetch_from_jin10
    ]

    for source in sources:
        try:
            data = source(metal)
            if data and validate_metal_data(data):
                return data
        except Exception as e:
            print(f"{source.__name__} 失败: {e}")
            continue

    return None
```

## 法律声明

- 所有数据版权归原数据提供商所有
- 本工具仅供个人学习和研究使用
- 不得用于商业用途或大规模分发
- 价格数据仅供参考，不构成投资建议