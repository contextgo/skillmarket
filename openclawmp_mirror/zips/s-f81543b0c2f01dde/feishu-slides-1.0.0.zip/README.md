# Feishu Slides Skill

通过API操作飞书在线幻灯片（Slides），支持创建、编辑、导出完整工作流。

## 核心功能

- 🆕 **创建演示文稿**：从模板或空白页新建
- 📄 **页面管理**：添加/删除/重排页面
- 📝 **内容编辑**：插入文本、表格、图片、形状
- 🎨 **样式控制**：字体、颜色、对齐、背景
- 📤 **导出**：下载为 PPTX 或 PDF
- 🔗 **分享权限**：设置可见范围

## 快速开始

```bash
# 安装技能
openclawmp install skill/@u-ad87dc7556674039b0d5/feishu-slides

# 创建空PPT
@GOGO 使用 feishu-slides 创建幻灯片 "我的演示" 模板 blank
```

详细文档见 `docs/` 目录。

## 技术栈

- 飞书 OpenAPI v3 (Slides)
- OpenClaw Skill SDK
- TypeScript