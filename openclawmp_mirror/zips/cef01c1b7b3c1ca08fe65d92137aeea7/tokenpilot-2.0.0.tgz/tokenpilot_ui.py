#!/usr/bin/env python3
"""
TokenPilot 交互式界面
用户友好的命令行交互界面
"""

import sys
import os
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from TokenPilot import (
    token_select, get_ranking, get_stats, 
    set_my_models, learn_preference, batch_select,
    record_response, get_model_stats
)

# 颜色代码
class Colors:
    HEADER = '\033[95m'
    BLUE = '\033[94m'
    CYAN = '\033[96m'
    GREEN = '\033[92m'
    YELLOW = '\033[93m'
    RED = '\033[91m'
    BOLD = '\033[1m'
    UNDERLINE = '\033[4m'
    END = '\033[0m'

def clear():
    """清屏"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_header():
    """打印头部"""
    print()
    print(f"{Colors.CYAN}{'═' * 50}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.CYAN}      TokenPilot - Token 性价比智能选择器{Colors.END}")
    print(f"{Colors.CYAN}{'═' * 50}{Colors.END}")
    print()

def print_menu():
    """打印菜单"""
    print(f"{Colors.BOLD}📋 主菜单{Colors.END}")
    print()
    print("  1️⃣  智能选择模型")
    print("  2️⃣  查看排行榜")
    print("  3️⃣  查看使用统计")
    print("  4️⃣  切换默认模式")
    print("  5️⃣  设置可用模型")
    print("  6️⃣  学习我的偏好")
    print("  7️⃣  批量任务")
    print("  0️⃣  退出")
    print()

def select_model_ui():
    """智能选择模型界面"""
    clear()
    print_header()
    
    print(f"{Colors.BOLD}🎯 智能选择模型{Colors.END}")
    print("-" * 40)
    print()
    
    # 输入任务
    task = input("📝 请输入任务描述: ").strip()
    if not task:
        print(f"{Colors.YELLOW}任务不能为空{Colors.END}")
        input("\n按回车返回...")
        return
    
    # 选择任务类型
    print()
    print("📂 任务类型:")
    print("  1.chat    2.code    3.analysis")
    print("  4.finance 5.writing 6.translation")
    
    type_choice = input("选择 [1-6, 默认1]: ").strip()
    type_map = {
        '1': 'chat', '2': 'code', '3': 'analysis',
        '4': 'finance', '5': 'writing', '6': 'translation'
    }
    task_type = type_map.get(type_choice, 'chat')
    
    # 选择难度
    print()
    print("📊 任务难度:")
    print("  1.simple  2.medium  3.complex  4.extreme")
    
    diff_choice = input("选择 [1-4, 默认2]: ").strip()
    diff_map = {'1': 'simple', '2': 'medium', '3': 'complex', '4': 'extreme'}
    difficulty = diff_map.get(diff_choice, 'medium')
    
    # 选择模式
    print()
    print("⚙️  选择模式:")
    print("  1.省钱     2.平衡     3.性能")
    print("  4.质量优先  5.速度优先")
    
    mode_choice = input("选择 [1-5, 默认2]: ").strip()
    mode_map = {
        '1': '省钱', '2': '平衡', '3': '性能',
        '4': '质量优先', '5': '速度优先'
    }
    mode = mode_map.get(mode_choice, '平衡')
    
    # 执行选择
    print()
    print(f"{Colors.CYAN}正在分析...{Colors.END}")
    
    result = token_select(task, difficulty, 'normal', task_type, mode)
    
    # 显示结果
    print()
    print(f"{Colors.GREEN}{'─' * 40}{Colors.END}")
    print(f"{Colors.BOLD}{Colors.GREEN}✅ 推荐模型: {result['推荐模型']}{Colors.END}")
    print(f"{Colors.GREEN}{'─' * 40}{Colors.END}")
    print(f"  💰 成本: {result['预估成本']}")
    print(f"  ⭐ 性能: {result['性能评分']}/5")
    print(f"  ⚡ 速度: {result['速度评分']}/5")
    print(f"  📊 性价比: {result['性价比']}")
    print(f"  📝 理由: {result['选择理由']}")
    
    # 显示Top3
    if result.get('Top3对比'):
        print()
        print(f"{Colors.BOLD}📊 Top3 对比:{Colors.END}")
        for item in result['Top3对比']:
            marker = "  ✅" if item['是否选中'] else "    "
            print(f"{marker} {item['排名']}. {item['模型']}: {item['成本']}")
    
    print()
    input("按回车返回...")

def show_ranking_ui():
    """显示排行榜"""
    clear()
    print_header()
    
    print(f"{Colors.BOLD}🏆 性价比排行榜{Colors.END}")
    print("-" * 50)
    print()
    
    ranking = get_ranking()
    
    for r in ranking:
        # 标记免费模型
        is_free = r['输入价格'] == '$0.0/1M'
        
        if r['排名'] == 1:
            prefix = f"{Colors.YELLOW}🥇{Colors.END}"
        elif r['排名'] == 2:
            prefix = f"{Colors.WHITE}🥈{Colors.END}"
        elif r['排名'] == 3:
            prefix = f"{Colors.RED}🥉{Colors.END}"
        else:
            prefix = f"  "
        
        free_tag = f"{Colors.GREEN}[免费]{Colors.END}" if is_free else ""
        
        print(f"{prefix} {r['排名']:2d}. {r['模型']:18s} | 性价比: {r['性价比']:6.1f} {free_tag}")
    
    print()
    input("按回车返回...")

def show_stats_ui():
    """显示统计"""
    clear()
    print_header()
    
    print(f"{Colors.BOLD}📊 使用统计{Colors.END}")
    print("-" * 40)
    print()
    
    stats = get_stats()
    
    print(f"  📈 总调用次数: {stats['总调用']}")
    print(f"  💰 累计节省: {stats['累计节省']}")
    print(f"  🤖 可用模型: {stats['可用模型']} 个")
    print(f"  📁 配置文件: {stats['配置文件']}")
    
    print()
    input("按回车返回...")

def change_mode_ui():
    """切换默认模式"""
    clear()
    print_header()
    
    print(f"{Colors.BOLD}⚙️  切换默认模式{Colors.END}")
    print("-" * 40)
    print()
    
    modes = [
        ('省钱', '选择最便宜的模型，最高节省 99%'),
        ('平衡', '综合考虑性价比和性能（推荐）'),
        ('性能', '优先选择高性能模型'),
        ('质量优先', '始终选择性能最强的模型'),
        ('速度优先', '始终选择响应最快的模型'),
    ]
    
    for i, (name, desc) in enumerate(modes, 1):
        print(f"  {i}. {name:8s} - {desc}")
    
    print()
    choice = input("选择 [1-5]: ").strip()
    
    mode_map = {'1': '省钱', '2': '平衡', '3': '性能', '4': '质量优先', '5': '速度优先'}
    
    if choice in mode_map:
        # 更新配置
        import json
        config_path = Path.home() / ".openclaw" / "workspace" / "tokenpilot_config.json"
        
        try:
            with open(config_path, 'r') as f:
                config = json.load(f)
            
            config['default_mode'] = mode_map[choice]
            
            with open(config_path, 'w') as f:
                json.dump(config, f, indent=2, ensure_ascii=False)
            
            print()
            print(f"{Colors.GREEN}✅ 已切换到【{mode_map[choice]}】模式{Colors.END}")
        except Exception as e:
            print(f"{Colors.RED}❌ 切换失败: {e}{Colors.END}")
    else:
        print(f"{Colors.YELLOW}无效选择{Colors.END}")
    
    print()
    input("按回车返回...")

def set_models_ui():
    """设置可用模型"""
    clear()
    print_header()
    
    print(f"{Colors.BOLD}🔧 设置可用模型{Colors.END}")
    print("-" * 40)
    print()
    print("只设置你接了 API 的模型，系统只从这些模型中选择")
    print()
    
    # 显示所有模型
    ranking = get_ranking()
    print("可用模型列表:")
    for r in ranking:
        is_free = r['输入价格'] == '$0.0/1M'
        free_tag = "[免费]" if is_free else ""
        print(f"  - {r['模型ID']:20s} {free_tag}")
    
    print()
    print("输入模型ID，用逗号分隔（如: glm-5,qwen3-max,deepseek-v3）")
    print("或输入 'all' 使用全部模型")
    
    choice = input("\n选择: ").strip()
    
    if choice.lower() == 'all':
        set_my_models(None)
        print(f"{Colors.GREEN}✅ 已设置为使用全部模型{Colors.END}")
    elif choice:
        models = [m.strip() for m in choice.split(',')]
        set_my_models(models)
        print(f"{Colors.GREEN}✅ 已设置 {len(models)} 个可用模型{Colors.END}")
    
    print()
    input("按回车返回...")

def learn_preference_ui():
    """学习偏好"""
    clear()
    print_header()
    
    print(f"{Colors.BOLD}🧠 学习我的偏好{Colors.END}")
    print("-" * 40)
    print()
    print("告诉系统你在特定任务类型中偏好哪个模型")
    print()
    
    print("任务类型:")
    print("  1.chat    2.code    3.analysis")
    print("  4.finance 5.writing 6.translation")
    
    type_choice = input("\n选择任务类型 [1-6]: ").strip()
    type_map = {
        '1': 'chat', '2': 'code', '3': 'analysis',
        '4': 'finance', '5': 'writing', '6': 'translation'
    }
    
    if type_choice not in type_map:
        print(f"{Colors.YELLOW}无效选择{Colors.END}")
        input("按回车返回...")
        return
    
    task_type = type_map[type_choice]
    
    # 显示推荐模型
    print()
    print("推荐模型:")
    ranking = get_ranking()
    for i, r in enumerate(ranking[:5], 1):
        print(f"  {i}. {r['模型ID']}")
    
    model_id = input("\n输入模型ID: ").strip()
    
    if model_id:
        learn_preference(task_type, model_id)
        print(f"{Colors.GREEN}✅ 已记住: {task_type} 任务偏好使用 {model_id}{Colors.END}")
    
    print()
    input("按回车返回...")

def batch_tasks_ui():
    """批量任务"""
    clear()
    print_header()
    
    print(f"{Colors.BOLD}📦 批量任务{Colors.END}")
    print("-" * 40)
    print()
    print("输入多个任务，系统会为每个任务推荐最优模型")
    print("输入 'done' 结束输入")
    print()
    
    tasks = []
    type_map = {
        '1': 'chat', '2': 'code', '3': 'analysis',
        '4': 'finance', '5': 'writing', '6': 'translation'
    }
    
    while True:
        task = input("任务描述 (或 'done'): ").strip()
        if task.lower() == 'done' or not task:
            break
        
        print("类型: 1.chat 2.code 3.analysis 4.finance 5.writing 6.translation")
        type_choice = input("选择 [1-6]: ").strip()
        task_type = type_map.get(type_choice, 'chat')
        
        tasks.append({'task': task, 'task_type': task_type})
        print(f"  ✅ 已添加: {task}\n")
    
    if tasks:
        print(f"\n{Colors.CYAN}正在分析 {len(tasks)} 个任务...{Colors.END}\n")
        
        result = batch_select(tasks)
        
        print(f"{Colors.GREEN}✅ 批量选择完成{Colors.END}")
        print("-" * 40)
        print(f"  任务数量: {result['任务数量']}")
        print(f"  总成本: {result['总成本']}")
        print(f"  总节省: {result['总节省']}")
        
        print()
        for i, r in enumerate(result['批量结果'], 1):
            print(f"  {i}. {r['推荐模型']}: {r['预估成本']}")
    
    print()
    input("按回车返回...")

def main():
    """主函数"""
    while True:
        clear()
        print_header()
        print_menu()
        
        choice = input("请选择 [0-7]: ").strip()
        
        if choice == '0':
            print()
            print(f"{Colors.CYAN}👋 再见！{Colors.END}")
            print()
            break
        elif choice == '1':
            select_model_ui()
        elif choice == '2':
            show_ranking_ui()
        elif choice == '3':
            show_stats_ui()
        elif choice == '4':
            change_mode_ui()
        elif choice == '5':
            set_models_ui()
        elif choice == '6':
            learn_preference_ui()
        elif choice == '7':
            batch_tasks_ui()

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print(f"\n\n{Colors.CYAN}👋 再见！{Colors.END}\n")