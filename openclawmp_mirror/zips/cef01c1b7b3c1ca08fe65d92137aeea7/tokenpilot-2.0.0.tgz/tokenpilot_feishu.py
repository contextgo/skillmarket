#!/usr/bin/env python3
"""
TokenPilot 飞书远程控制接口
在飞书聊天中直接使用 TokenPilot

命令格式：
  /token 选择 分析财报 finance complex
  /token 排行
  /token 统计
  /token 模式 省钱
  /token 帮助
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from TokenPilot import (
    token_select, get_ranking, get_stats,
    set_my_models, learn_preference, batch_select
)

def handle_command(text: str) -> str:
    """
    处理飞书命令
    
    Args:
        text: 用户输入的命令文本
    
    Returns:
        响应文本
    """
    text = text.strip()
    
    # 支持多种前缀
    if text.startswith('/token '):
        text = text[7:]
    elif text.startswith('token '):
        text = text[6:]
    elif text.startswith('/tp '):
        text = text[4:]
    else:
        # 不是命令，尝试智能选择
        return smart_select(text)
    
    parts = text.split()
    
    if not parts:
        return get_help()
    
    cmd = parts[0].lower()
    
    # 帮助
    if cmd in ['帮助', 'help', 'h', '?']:
        return get_help()
    
    # 选择模型
    if cmd in ['选择', 'select', 's', '选']:
        return cmd_select(parts[1:])
    
    # 排行榜
    if cmd in ['排行', 'ranking', 'rank', 'r', '排']:
        return cmd_ranking()
    
    # 统计
    if cmd in ['统计', 'stats', 'stat', 't', '统']:
        return cmd_stats()
    
    # 切换模式
    if cmd in ['模式', 'mode', 'm', '模']:
        return cmd_mode(parts[1:])
    
    # 设置模型
    if cmd in ['设置', 'set', '配置']:
        return cmd_set_models(parts[1:])
    
    # 学习偏好
    if cmd in ['学习', 'learn', 'l', '学']:
        return cmd_learn(parts[1:])
    
    # 未知命令
    return f"❌ 未知命令: {cmd}\n\n{get_help()}"

def smart_select(task: str) -> str:
    """智能选择（无需命令前缀）"""
    if len(task) < 2:
        return "请输入更详细的任务描述"
    
    result = token_select(task)
    
    return f"""✅ 推荐: {result['推荐模型']}
💰 成本: {result['预估成本']}
⭐ 性能: {result['性能评分']}/5
📝 理由: {result['选择理由']}"""

def cmd_select(args: list) -> str:
    """选择命令"""
    if not args:
        return "用法: /token 选择 <任务> [类型] [难度] [模式]\n示例: /token 选择 分析财报 finance complex 性能"
    
    task = args[0]
    task_type = args[1] if len(args) > 1 else 'chat'
    difficulty = args[2] if len(args) > 2 else 'medium'
    mode = args[3] if len(args) > 3 else '平衡'
    
    result = token_select(task, difficulty, 'normal', task_type, mode)
    
    response = f"""✅ 推荐: {result['推荐模型']}
💰 成本: {result['预估成本']}
⭐ 性能: {result['性能评分']}/5
⚡ 速度: {result['速度评分']}/5
📊 性价比: {result['性价比']}
📝 理由: {result['选择理由']}"""
    
    if result.get('Top3对比'):
        response += "\n\n📊 Top3 对比:"
        for item in result['Top3对比']:
            marker = "✅" if item['是否选中'] else "  "
            response += f"\n{marker} {item['排名']}. {item['模型']}: {item['成本']}"
    
    return response

def cmd_ranking() -> str:
    """排行榜命令"""
    ranking = get_ranking()
    
    response = "🏆 性价比排行榜 Top 10\n"
    response += "─" * 30 + "\n"
    
    for r in ranking[:10]:
        is_free = r['输入价格'] == '$0.0/1M'
        free_tag = " [免费]" if is_free else ""
        
        if r['排名'] == 1:
            prefix = "🥇"
        elif r['排名'] == 2:
            prefix = "🥈"
        elif r['排名'] == 3:
            prefix = "🥉"
        else:
            prefix = f"{r['排名']:2d}."
        
        response += f"{prefix} {r['模型']}{free_tag}\n"
        response += f"    性价比: {r['性价比']:.0f} | 价格: {r['输入价格']}\n"
    
    return response

def cmd_stats() -> str:
    """统计命令"""
    stats = get_stats()
    
    return f"""📊 TokenPilot 使用统计
─" + "-" * 30 + "
📈 总调用次数: {stats['总调用']}
💰 累计节省: {stats['累计节省']}
🤖 可用模型: {stats['可用模型']} 个
🎯 用户偏好: {stats['用户偏好']}"""

def cmd_mode(args: list) -> str:
    """切换模式命令"""
    if not args:
        return """当前可用模式:
1. 省钱 - 选择最便宜的模型
2. 平衡 - 性价比最优（默认）
3. 性能 - 优先高性能
4. 质量优先 - 选最强的
5. 速度优先 - 选最快的

用法: /token 模式 <模式名>"""
    
    mode_name = args[0]
    
    mode_map = {
        '省钱': '省钱', '省钱模式': '省钱', '1': '省钱',
        '平衡': '平衡', '平衡模式': '平衡', '2': '平衡',
        '性能': '性能', '性能模式': '性能', '3': '性能',
        '质量优先': '质量优先', '质量': '质量优先', '4': '质量优先',
        '速度优先': '速度优先', '速度': '速度优先', '5': '速度优先',
    }
    
    if mode_name not in mode_map:
        return f"❌ 未知模式: {mode_name}"
    
    import json
    config_path = Path.home() / ".openclaw" / "workspace" / "tokenpilot_config.json"
    
    try:
        with open(config_path, 'r') as f:
            config = json.load(f)
        
        config['default_mode'] = mode_map[mode_name]
        
        with open(config_path, 'w') as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
        
        return f"✅ 已切换到【{mode_map[mode_name]}】模式"
    except Exception as e:
        return f"❌ 切换失败: {e}"

def cmd_set_models(args: list) -> str:
    """设置模型命令"""
    if not args:
        ranking = get_ranking()
        response = "可用模型:\n"
        for r in ranking[:10]:
            is_free = r['输入价格'] == '$0.0/1M'
            free_tag = " [免费]" if is_free else ""
            response += f"  - {r['模型ID']}{free_tag}\n"
        response += "\n用法: /token 设置 <模型1,模型2,...>"
        return response
    
    models = args[0].split(',')
    models = [m.strip() for m in models]
    
    if models[0].lower() == 'all':
        set_my_models(None)
        return "✅ 已设置为使用全部模型"
    
    set_my_models(models)
    return f"✅ 已设置 {len(models)} 个可用模型:\n  " + "\n  ".join(models)

def cmd_learn(args: list) -> str:
    """学习偏好命令"""
    if len(args) < 2:
        return """用法: /token 学习 <任务类型> <模型ID>

任务类型: chat, code, analysis, finance, writing, translation

示例: /token 学习 finance glm-5"""
    
    task_type = args[0]
    model_id = args[1]
    
    valid_types = ['chat', 'code', 'analysis', 'finance', 'writing', 'translation']
    if task_type not in valid_types:
        return f"❌ 无效任务类型: {task_type}\n有效类型: {', '.join(valid_types)}"
    
    learn_preference(task_type, model_id)
    return f"✅ 已记住: {task_type} 任务偏好使用 {model_id}"

def get_help() -> str:
    """获取帮助"""
    return """🤖 TokenPilot 飞书远程控制

📝 命令列表:

  /token 选择 <任务> [类型] [难度] [模式]
    智能选择最优模型
    
  /token 排行
    查看性价比排行榜
    
  /token 统计
    查看使用统计
    
  /token 模式 <模式名>
    切换默认模式
    
  /token 设置 <模型1,模型2,...>
    设置可用模型
    
  /token 学习 <类型> <模型>
    学习你的偏好

💡 快捷方式:
  直接发送任务描述，系统自动选择

📚 示例:
  分析财报找出风险点
  /token 选择 分析财报 finance complex 性能
  /token 排行
  /token 模式 省钱
  /token 学习 finance glm-5"""


# 便捷函数供外部调用
def feishu_handler(text: str) -> str:
    """
    飞书消息处理器
    
    在飞书消息处理中调用此函数
    """
    try:
        return handle_command(text)
    except Exception as e:
        return f"❌ 处理失败: {e}"


if __name__ == "__main__":
    # 测试
    print("测试飞书远程控制接口")
    print("=" * 40)
    
    test_commands = [
        "分析财报找出风险点",
        "/token 排行",
        "/token 统计",
        "/token 模式",
        "/token 选择 写代码 code medium",
    ]
    
    for cmd in test_commands:
        print(f"\n输入: {cmd}")
        print("-" * 40)
        print(handle_command(cmd))