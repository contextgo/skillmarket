---
name: tokenpilot
description: "Token 性价比智能选择器 - 根据任务需求智能选择最优 AI 模型，支持百炼免费模型，最高节省 100% 成本"
version: 2.0.0
displayName: TokenPilot
tags:
  - token
  - cost
  - optimization
  - model-selection
  - ai
---

# TokenPilot - Token 性价比智能选择器

> 精打细算，每一分钱都花在刀刃上

## 简介

TokenPilot 是一个智能模型选择器，帮助你根据任务需求自动选择最优的 AI 模型，实现成本最优化。

**核心功能：**
- 🎯 智能选择最优模型
- 💰 支持百炼免费模型（GLM-5, Qwen3 等）
- 📊 Top3 对比展示
- 🧠 学习用户偏好
- 📈 实际性能追踪
- 🤖 飞书远程控制

**性价比提升：**
- 百炼免费模型：100% 节省
- 其他模型：最高节省 99.8%

## 快速开始

### 基本使用

```python
from TokenPilot import token_select

# 智能选择
result = token_select(
    task="分析财报找出风险点",
    difficulty="complex",      # simple/medium/complex/extreme
    importance="high",         # low/normal/high/critical
    task_type="finance",       # chat/code/analysis/finance/writing/translation
    mode="平衡"                # 省钱/平衡/性能/质量优先/速度优先
)

print(result["推荐模型"])     # Qwen3 Max
print(result["预估成本"])     # $0.0000/1k tokens (免费!)
print(result["Top3对比"])     # Top3 对比列表
```

### 五种选择模式

| 模式 | 说明 |
|------|------|
| 省钱 | 选择最便宜的模型 |
| 平衡 | 性价比最优（默认） |
| 性能 | 优先高性能 |
| 质量优先 | 选择性能最强的模型 |
| 速度优先 | 选择响应最快的模型 |

### 批量选择

```python
from TokenPilot import batch_select

tasks = [
    {"task": "写代码", "task_type": "code"},
    {"task": "翻译文档", "task_type": "translation"},
]

result = batch_select(tasks)
print(result["总成本"])
```

### 飞书远程控制

在飞书中直接发送命令：

```
分析财报找出风险点        # 直接发送任务
/token 排行              # 查看排行榜
/token 统计              # 查看统计
/token 模式 省钱         # 切换模式
```

## 支持的模型

### 百炼免费模型 ⭐

| 模型 | 性能 | 适用场景 |
|------|------|---------|
| GLM-5 | 4.2/5 | 通用、推理 |
| GLM-4.7 | 4.0/5 | 通用 |
| Qwen3.5 Plus | 4.3/5 | 通用、代码 |
| Qwen3 Max | 4.5/5 | 复杂任务、推理 |
| Qwen3 Coder+ | 4.4/5 | 代码、编程 |
| Kimi K2.5 | 4.0/5 | 长文本、文档 |

### 其他模型

- DeepSeek V3/R1
- GPT-4.1/5.2 系列
- Claude 3.5 Sonnet
- Qwen Turbo

## 安装

```bash
# 复制到工作区
cp -r tokenpilot-skill ~/.openclaw/workspace/

# 或者直接使用
python TokenPilot.py
```

## CLI 使用

```bash
# 选择模型
python tokenpilot_cli.py select "分析财报" --type finance --difficulty complex

# 查看排行榜
python tokenpilot_cli.py ranking

# 交互模式
python tokenpilot_cli.py interactive
```

## 配置文件

`tokenpilot_config.json`:

```json
{
  "default_mode": "平衡",
  "auto_detect_from_openclaw": true,
  "enable_learning": true,
  "user_preferences": {}
}
```

## API 参考

### 核心函数

| 函数 | 说明 |
|------|------|
| `token_select()` | 智能选择最优模型 |
| `batch_select()` | 批量任务选择 |
| `get_ranking()` | 获取性价比排行榜 |
| `get_stats()` | 获取使用统计 |

### 配置函数

| 函数 | 说明 |
|------|------|
| `set_my_models()` | 设置可用模型 |
| `learn_preference()` | 学习用户偏好 |
| `record_response()` | 记录模型响应 |

## 文件说明

| 文件 | 说明 |
|------|------|
| `TokenPilot.py` | 主程序 |
| `tokenpilot_config.json` | 配置文件 |
| `tokenpilot_init.py` | 首次运行引导 |
| `tokenpilot_tutorial.py` | 新手教程 |
| `tokenpilot_cli.py` | CLI 工具 |
| `tokenpilot_ui.py` | 交互界面 |
| `tokenpilot_feishu.py` | 飞书接口 |
| `test_tokenpilot.py` | 单元测试 |

## 成本节省示例

| 场景 | 默认选择 | TokenPilot | 节省 |
|------|----------|------------|------|
| 日常对话 | $7.88 | $0.00 | **100%** |
| 代码生成 | $7.88 | $0.00 | **100%** |
| 复杂分析 | $94.50 | $0.00 | **100%** |

*使用百炼免费模型可实现 100% 节省*

## 版本历史

- **v2.0.0** - 添加百炼免费模型、飞书远程控制、交互界面、回测系统
- **v1.0.0** - 初始版本，基础选择功能

---

*TokenPilot - 让每一分钱都花在刀刃上*