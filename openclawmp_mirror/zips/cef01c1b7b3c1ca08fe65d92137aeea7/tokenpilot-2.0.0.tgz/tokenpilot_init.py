#!/usr/bin/env python3
"""
TokenPilot 初始化引导
首次运行时帮助用户选择合适的模式
"""

import sys
import os
import json
from pathlib import Path

def clear_screen():
    """清屏"""
    os.system('cls' if os.name == 'nt' else 'clear')

def print_banner():
    """打印横幅"""
    print()
    print("╔" + "═" * 56 + "╗")
    print("║" + " TokenPilot - Token 性价比智能选择器 ".center(52) + "║")
    print("║" + " 首次运行设置 ".center(52) + "║")
    print("╚" + "═" * 56 + "╝")
    print()

def print_modes():
    """打印模式介绍"""
    print(f"{Colors.CYAN}🎯 请选择默认运行模式：{Colors.END}")
    print()
    
    modes_info = [
        ("省钱", "推荐新手", "选择最便宜的模型，适合日常简单任务", "最高可节省 99% 成本"),
        ("平衡", "默认推荐 ⭐", "综合考虑性价比和性能，适合大多数场景", "自动为不同任务选择最合适的模型"),
        ("性能", "", "优先选择高性能模型，兼顾性价比", "适合需要一定质量的任务"),
        ("质量优先", "", "始终选择性能最强的模型，不考虑成本", "适合关键任务、重要决策"),
        ("速度优先", "", "始终选择响应最快的模型", "适合需要快速响应的场景"),
    ]
    
    for i, (name, badge, desc, tip) in enumerate(modes_info, 1):
        badge_str = f"{Colors.YELLOW}[{badge}]{Colors.END} " if badge else ""
        print(f"{Colors.BOLD}{i}️⃣  {name}模式 {badge_str}{Colors.END}")
        print(f"    → {desc}")
        print(f"    → {Colors.CYAN}{tip}{Colors.END}")
        print()

def get_user_choice():
    """获取用户选择"""
    while True:
        try:
            choice = input("请输入选择 (1-5) [默认: 2]: ").strip()
            
            if not choice:
                choice = "2"
            
            if choice in ["1", "2", "3", "4", "5"]:
                return int(choice)
            
            print("❌ 请输入 1-5 之间的数字")
        except KeyboardInterrupt:
            print("\n\n👋 已取消设置，使用默认模式（平衡）")
            return 2

def mode_num_to_name(num):
    """数字转模式名"""
    modes = {
        1: "省钱",
        2: "平衡",
        3: "性能",
        4: "质量优先",
        5: "速度优先"
    }
    return modes.get(num, "平衡")

def print_mode_detail(mode_num):
    """打印模式详情"""
    mode_name = mode_num_to_name(mode_num)
    
    print()
    print(f"✅ 你选择了: {mode_name}模式")
    print()
    
    descriptions = {
        1: """
💡 省钱模式说明：
  • 系统会优先选择最便宜的模型
  • 适合日常对话、简单任务
  • 推荐模型: GLM-4-Flash ($0.014/1M tokens)
  • 预估节省: 每次调用可节省 90%+ 成本
""",
        2: """
💡 平衡模式说明：
  • 系统会综合考虑性价比和性能
  • 自动为不同类型任务选择最合适的模型
  • 简单任务用便宜模型，复杂任务用强模型
  • 推荐给大多数用户
""",
        3: """
💡 性能模式说明：
  • 系统会优先选择高性能模型
  • 但也会考虑性价比
  • 适合需要一定质量的任务
  • 推荐模型: DeepSeek V3, GPT-5 Mini
""",
        4: """
💡 质量优先模式说明：
  • 系统会始终选择性能最强的模型
  • 不考虑成本，只追求最佳效果
  • 适合关键任务、重要决策
  • 推荐模型: GPT-5.2 Pro (性能 5.0/5)
""",
        5: """
💡 速度优先模式说明：
  • 系统会始终选择响应最快的模型
  • 适合需要快速响应的场景
  • 推荐模型: GLM-4-Flash (速度 5.0/5)
"""
    }
    
    print(descriptions.get(mode_num, ""))

def confirm_choice(mode_num):
    """确认选择"""
    mode_name = mode_num_to_name(mode_num)
    
    print()
    print(f"确认选择 [{mode_name}模式] 吗？")
    print()
    print("  y - 确认，保存设置")
    print("  n - 重新选择")
    print("  q - 退出，使用默认设置")
    print()
    
    while True:
        choice = input("请输入 (y/n/q) [y]: ").strip().lower()
        
        if not choice or choice == "y":
            return True
        elif choice == "n":
            return False
        elif choice == "q":
            print("\n👋 已取消，使用默认模式（平衡）")
            sys.exit(0)
        else:
            print("❌ 请输入 y/n/q")

def save_config(mode_num):
    """保存配置"""
    mode_name = mode_num_to_name(mode_num)
    
    workspace = Path.home() / ".openclaw" / "workspace"
    config_path = workspace / "tokenpilot_config.json"
    
    # 读取现有配置或创建新配置
    if config_path.exists():
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
    else:
        config = {}
    
    # 更新默认模式
    config["default_mode"] = mode_name
    
    # 标记已完成首次设置
    config["first_run_completed"] = True
    
    # 保存
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, ensure_ascii=False)
    
    return config_path

def print_success(mode_num, config_path):
    """打印成功信息"""
    mode_name = mode_num_to_name(mode_num)
    
    print()
    print("╔" + "═" * 56 + "╗")
    print("║" + " 设置完成！".center(52) + "║")
    print("╚" + "═" * 56 + "╝")
    print()
    print(f"✅ 默认模式已设置为: {mode_name}模式")
    print(f"📁 配置已保存到: {config_path}")
    print()
    print("🚀 快速开始：")
    print()
    print("    from TokenPilot import token_select")
    print()
    print("    result = token_select('你的任务')")
    print("    print(result['推荐模型'])")
    print()
    print("📚 更多功能：")
    print("    python tokenpilot_tutorial.py  # 新手教程")
    print("    python tokenpilot_cli.py --help  # CLI 帮助")
    print()
    print("💡 随时可以修改配置文件切换模式")
    print()

def check_first_run():
    """检查是否首次运行"""
    workspace = Path.home() / ".openclaw" / "workspace"
    config_path = workspace / "tokenpilot_config.json"
    
    if config_path.exists():
        with open(config_path, 'r', encoding='utf-8') as f:
            config = json.load(f)
        return not config.get("first_run_completed", False)
    
    return True

def main():
    """主函数"""
    # 检查是否需要运行引导
    if not check_first_run():
        # 已完成首次设置，直接退出
        return
    
    clear_screen()
    print_banner()
    print_modes()
    
    while True:
        choice = get_user_choice()
        print_mode_detail(choice)
        
        if confirm_choice(choice):
            config_path = save_config(choice)
            print_success(choice, config_path)
            break
        else:
            print()
            print("🔄 请重新选择...")
            print()

if __name__ == "__main__":
    main()