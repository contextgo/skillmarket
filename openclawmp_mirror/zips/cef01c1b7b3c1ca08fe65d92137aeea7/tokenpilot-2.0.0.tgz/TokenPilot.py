#!/usr/bin/env python3
"""
TokenPilot v2.0 - Token 性价比智能选择器
精打细算，每一分钱都花在刀刃上

新增功能：
- 配置文件支持 (tokenpilot_config.json)
- 持久化历史 (tokenpilot_history.json)
- Top3 对比展示
- 自动检测 openclaw.json 中的模型
- 学习用户偏好
- 批量任务优化
"""

from enum import Enum
from dataclasses import dataclass, field
from typing import Optional, List, Dict, Any
import json
import os
from pathlib import Path
from datetime import datetime
import logging

# ============================================================
# 日志配置
# ============================================================

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [TokenPilot] %(levelname)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger('TokenPilot')

# ============================================================
# 枚举定义
# ============================================================

class Difficulty(Enum):
    """任务难度"""
    SIMPLE = 1
    MEDIUM = 2
    COMPLEX = 3
    EXTREME = 4

class Mode(Enum):
    """选择模式"""
    SAVE_MONEY = "省钱"
    BALANCED = "平衡"
    PERFORMANCE = "性能"
    QUALITY_FIRST = "质量优先"
    SPEED_FIRST = "速度优先"

class Importance(Enum):
    """任务重要性"""
    LOW = 1
    NORMAL = 2
    HIGH = 3
    CRITICAL = 4

class TaskType(Enum):
    """任务类型"""
    CHAT = "chat"
    CODE = "code"
    ANALYSIS = "analysis"
    FINANCE = "finance"
    WRITING = "writing"
    TRANSLATION = "translation"

# ============================================================
# 模型性能追踪器
# ============================================================

class PerformanceTracker:
    """追踪模型实际性能"""
    
    def __init__(self, history_path: Path):
        self.history_path = history_path
        self.response_times: Dict[str, List[float]] = {}  # model_id -> [times]
        self.success_rates: Dict[str, Dict[str, int]] = {}  # model_id -> {success, total}
        self.load()
    
    def load(self):
        """从历史加载"""
        perf_path = self.history_path.parent / "tokenpilot_performance.json"
        if perf_path.exists():
            try:
                with open(perf_path, 'r') as f:
                    data = json.load(f)
                    self.response_times = data.get("response_times", {})
                    self.success_rates = data.get("success_rates", {})
            except:
                pass
    
    def save(self):
        """保存到文件"""
        perf_path = self.history_path.parent / "tokenpilot_performance.json"
        try:
            with open(perf_path, 'w') as f:
                json.dump({
                    "response_times": self.response_times,
                    "success_rates": self.success_rates
                }, f, indent=2)
        except Exception as e:
            logger.error(f"性能数据保存失败: {e}")
    
    def record_response(self, model_id: str, response_time: float, success: bool):
        """记录响应时间和成功率"""
        # 响应时间
        if model_id not in self.response_times:
            self.response_times[model_id] = []
        self.response_times[model_id].append(response_time)
        # 只保留最近 100 次
        self.response_times[model_id] = self.response_times[model_id][-100:]
        
        # 成功率
        if model_id not in self.success_rates:
            self.success_rates[model_id] = {"success": 0, "total": 0}
        self.success_rates[model_id]["total"] += 1
        if success:
            self.success_rates[model_id]["success"] += 1
        
        self.save()
    
    def get_avg_response_time(self, model_id: str) -> Optional[float]:
        """获取平均响应时间"""
        times = self.response_times.get(model_id, [])
        if times:
            return sum(times) / len(times)
        return None
    
    def get_success_rate(self, model_id: str) -> Optional[float]:
        """获取成功率"""
        stats = self.success_rates.get(model_id)
        if stats and stats["total"] > 0:
            return stats["success"] / stats["total"]
        return None
    
    def get_calculated_speed_score(self, model_id: str, default_speed: float) -> float:
        """根据实际响应时间计算速度评分"""
        avg_time = self.get_avg_response_time(model_id)
        if avg_time is None:
            return default_speed
        
        # 响应时间 -> 速度评分 (5=最快, 1=最慢)
        # 假设: <2s=5, 2-5s=4, 5-10s=3, 10-20s=2, >20s=1
        if avg_time < 2:
            return 5.0
        elif avg_time < 5:
            return 4.0
        elif avg_time < 10:
            return 3.0
        elif avg_time < 20:
            return 2.0
        else:
            return 1.0
    
    def get_calculated_performance_score(self, model_id: str, default_perf: float) -> float:
        """根据成功率调整性能评分"""
        success_rate = self.get_success_rate(model_id)
        if success_rate is None:
            return default_perf
        
        # 成功率影响性能评分
        # 成功率 > 95%: 不变
        # 成功率 90-95%: -0.2
        # 成功率 80-90%: -0.5
        # 成功率 < 80%: -1.0
        if success_rate > 0.95:
            return default_perf
        elif success_rate > 0.90:
            return max(1.0, default_perf - 0.2)
        elif success_rate > 0.80:
            return max(1.0, default_perf - 0.5)
        else:
            return max(1.0, default_perf - 1.0)

# ============================================================
# 模型数据
# ============================================================

@dataclass
class Model:
    """模型信息"""
    id: str
    name: str
    provider: str
    input_price: float
    output_price: float
    cache_price: float
    performance: float
    speed: float
    strengths: List[str]
    
    def cost_per_1k(self, in_tokens: int = 500, out_tokens: int = 500) -> float:
        return (self.input_price * in_tokens + self.output_price * out_tokens) / 1000
    
    def value_score(self) -> float:
        """性价比分数"""
        avg_price = (self.input_price + self.output_price) / 2
        if avg_price == 0:
            return 9999  # 免费模型最高优先级
        return self.performance / avg_price * 10

# 默认模型库
DEFAULT_MODELS = {
    # ===== 百炼免费梯队（性价比之王）=====
    "glm-5": Model(
        id="glm-5", name="GLM-5", provider="百炼",
        input_price=0.0, output_price=0.0, cache_price=0,
        performance=4.2, speed=4.5,
        strengths=["chat", "translation", "中文", "通用", "推理"]
    ),
    "glm-4.7": Model(
        id="glm-4.7", name="GLM-4.7", provider="百炼",
        input_price=0.0, output_price=0.0, cache_price=0,
        performance=4.0, speed=4.5,
        strengths=["chat", "translation", "中文", "通用"]
    ),
    "qwen3.5-plus": Model(
        id="qwen3.5-plus", name="Qwen3.5 Plus", provider="百炼",
        input_price=0.0, output_price=0.0, cache_price=0,
        performance=4.3, speed=4.0,
        strengths=["chat", "code", "analysis", "中文", "通用"]
    ),
    "qwen3-max": Model(
        id="qwen3-max", name="Qwen3 Max", provider="百炼",
        input_price=0.0, output_price=0.0, cache_price=0,
        performance=4.5, speed=3.5,
        strengths=["chat", "code", "analysis", "推理", "复杂任务"]
    ),
    "qwen3-coder-plus": Model(
        id="qwen3-coder-plus", name="Qwen3 Coder+", provider="百炼",
        input_price=0.0, output_price=0.0, cache_price=0,
        performance=4.4, speed=4.0,
        strengths=["code", "编程", "debug", "代码生成"]
    ),
    "kimi-k2.5": Model(
        id="kimi-k2.5", name="Kimi K2.5", provider="百炼",
        input_price=0.0, output_price=0.0, cache_price=0,
        performance=4.0, speed=4.0,
        strengths=["chat", "长文本", "文档理解"]
    ),
    # ===== 其他模型 =====
    "glm-4-flash": Model(
        id="glm-4-flash", name="GLM-4-Flash", provider="智谱",
        input_price=0.014, output_price=0.014, cache_price=0,
        performance=3.0, speed=5.0,
        strengths=["chat", "translation", "中文", "日常对话"]
    ),
    "qwen-turbo": Model(
        id="qwen-turbo", name="Qwen Turbo", provider="阿里",
        input_price=0.04, output_price=0.08, cache_price=0,
        performance=3.5, speed=4.5,
        strengths=["chat", "translation", "中文", "代码"]
    ),
    "deepseek-v3": Model(
        id="deepseek-v3", name="DeepSeek V3", provider="DeepSeek",
        input_price=0.07, output_price=0.28, cache_price=0,
        performance=4.0, speed=4.0,
        strengths=["code", "analysis", "math", "通用"]
    ),
    "gpt-4.1-nano": Model(
        id="gpt-4.1-nano", name="GPT-4.1 Nano", provider="OpenAI",
        input_price=0.20, output_price=0.80, cache_price=0.05,
        performance=3.0, speed=4.5,
        strengths=["classification", "extraction", "简单任务"]
    ),
    "gpt-5-mini": Model(
        id="gpt-5-mini", name="GPT-5 Mini", provider="OpenAI",
        input_price=0.25, output_price=2.00, cache_price=0.025,
        performance=4.0, speed=4.0,
        strengths=["chat", "code", "中等任务"]
    ),
    "deepseek-r1": Model(
        id="deepseek-r1", name="DeepSeek R1", provider="DeepSeek",
        input_price=0.55, output_price=2.19, cache_price=0,
        performance=4.5, speed=3.0,
        strengths=["reasoning", "analysis", "复杂推理"]
    ),
    "gpt-5.2": Model(
        id="gpt-5.2", name="GPT-5.2", provider="OpenAI",
        input_price=1.75, output_price=14.00, cache_price=0.175,
        performance=4.9, speed=3.5,
        strengths=["code", "agent", "复杂任务", "推理"]
    ),
    "gpt-4.1": Model(
        id="gpt-4.1", name="GPT-4.1", provider="OpenAI",
        input_price=3.00, output_price=12.00, cache_price=0.75,
        performance=4.8, speed=3.0,
        strengths=["复杂任务", "专业", "代码"]
    ),
    "claude-3.5-sonnet": Model(
        id="claude-3.5-sonnet", name="Claude 3.5 Sonnet", provider="Anthropic",
        input_price=3.00, output_price=15.00, cache_price=0,
        performance=4.8, speed=3.0,
        strengths=["writing", "analysis", "代码", "创作"]
    ),
    "gpt-5.2-pro": Model(
        id="gpt-5.2-pro", name="GPT-5.2 Pro", provider="OpenAI",
        input_price=21.00, output_price=168.00, cache_price=0,
        performance=5.0, speed=2.0,
        strengths=["最复杂任务", "研究", "创作", "决策"]
    ),
}

# ============================================================
# 核心类
# ============================================================

class TokenPilot:
    """TokenPilot v2.0 - Token 性价比智能选择器"""
    
    def __init__(self, config_path: Optional[str] = None):
        self.workspace = Path.home() / ".openclaw" / "workspace"
        self.config_path = config_path or (self.workspace / "tokenpilot_config.json")
        self.history_path = self.workspace / "tokenpilot_history.json"
        
        # 加载配置
        self.config = self._load_config()
        
        # 性能追踪器（需要在加载模型之前初始化）
        self.perf_tracker = PerformanceTracker(self.history_path)
        
        # 加载模型库（应用价格覆盖和实际性能）
        self.models = self._load_models()
        
        # 加载历史
        self.history = self._load_history()
        
        # 统计
        self.total_saved = self.history.get("total_saved", 0.0)
        self.total_calls = self.history.get("total_calls", 0)
        
        logger.info(f"TokenPilot v2.0 初始化完成，可用模型: {len(self.models)} 个")
    
    def _load_config(self) -> Dict:
        """加载配置文件"""
        default_config = {
            "version": "2.0.0",
            "available_models": None,
            "default_mode": "平衡",
            "budget_limit": None,
            "auto_detect_from_openclaw": True,
            "enable_learning": True,
            "enable_persistence": True,
            "price_overrides": {},
            "performance_overrides": {},
            "user_preferences": {}
        }
        
        if os.path.exists(self.config_path):
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    logger.info(f"已加载配置文件: {self.config_path}")
                    return {**default_config, **config}
            except Exception as e:
                logger.warning(f"配置文件加载失败: {e}，使用默认配置")
        
        return default_config
    
    def _save_config(self):
        """保存配置文件"""
        try:
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config, f, indent=2, ensure_ascii=False)
            logger.info(f"配置已保存: {self.config_path}")
        except Exception as e:
            logger.error(f"配置保存失败: {e}")
    
    def _load_models(self) -> Dict[str, Model]:
        """加载模型库"""
        models = {}
        
        # 确定可用模型
        available = self.config.get("available_models")
        
        if available is None and self.config.get("auto_detect_from_openclaw"):
            # 自动检测 openclaw.json
            available = self._detect_openclaw_models()
        
        if available is None:
            available = list(DEFAULT_MODELS.keys())
        
        # 复制模型并应用覆盖
        for model_id in available:
            if model_id in DEFAULT_MODELS:
                model = DEFAULT_MODELS[model_id]
                
                # 应用价格覆盖
                price_overrides = self.config.get("price_overrides", {}).get(model_id, {})
                
                # 计算实际性能评分（基于成功率）
                actual_perf = self.perf_tracker.get_calculated_performance_score(
                    model_id, model.performance
                )
                
                # 计算实际速度评分（基于响应时间）
                actual_speed = self.perf_tracker.get_calculated_speed_score(
                    model_id, model.speed
                )
                
                # 应用性能覆盖（如果有）
                perf_override = self.config.get("performance_overrides", {}).get(model_id, {})
                if perf_override:
                    actual_perf = perf_override.get("performance", actual_perf)
                    actual_speed = perf_override.get("speed", actual_speed)
                
                model = Model(
                    id=model.id,
                    name=model.name,
                    provider=model.provider,
                    input_price=price_overrides.get("input", model.input_price),
                    output_price=price_overrides.get("output", model.output_price),
                    cache_price=price_overrides.get("cache", model.cache_price),
                    performance=actual_perf,
                    speed=actual_speed,
                    strengths=model.strengths
                )
                
                models[model_id] = model
            else:
                logger.warning(f"未知模型ID，已跳过: {model_id}")
        
        # 如果没有有效模型，使用默认模型
        if not models:
            logger.warning("没有有效的可用模型，使用默认模型")
            models = {k: v for k, v in DEFAULT_MODELS.items()}
        
        return models
    
    def _detect_openclaw_models(self) -> Optional[List[str]]:
        """从 openclaw.json 检测可用模型"""
        openclaw_config_path = Path.home() / ".openclaw" / "openclaw.json"
        
        if not os.path.exists(openclaw_config_path):
            return None
        
        try:
            with open(openclaw_config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            
            # 提取模型列表
            models = []
            
            # 从 models 配置提取
            if "models" in config:
                models_config = config["models"]
                if "default" in models_config:
                    models.append(models_config["default"])
                if "fallbacks" in models_config:
                    models.extend(models_config["fallbacks"])
            
            # 从 providers 提取
            if "providers" in config:
                for provider_name, provider_config in config["providers"].items():
                    if "models" in provider_config:
                        models.extend(provider_config["models"])
            
            # 过滤已知模型
            known_models = [m for m in models if m in DEFAULT_MODELS]
            
            if known_models:
                logger.info(f"从 openclaw.json 检测到 {len(known_models)} 个已知模型")
                return known_models
            
        except Exception as e:
            logger.warning(f"检测 openclaw.json 失败: {e}")
        
        return None
    
    def _load_history(self) -> Dict:
        """加载历史记录"""
        if os.path.exists(self.history_path):
            try:
                with open(self.history_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                pass
        
        return {"calls": [], "total_saved": 0.0, "total_calls": 0, "preferences": {}}
    
    def _save_history(self):
        """保存历史记录"""
        if not self.config.get("enable_persistence", True):
            return
        
        try:
            self.history["total_saved"] = self.total_saved
            self.history["total_calls"] = self.total_calls
            
            with open(self.history_path, 'w', encoding='utf-8') as f:
                json.dump(self.history, f, indent=2, ensure_ascii=False)
        except Exception as e:
            logger.error(f"历史保存失败: {e}")
    
    def select(
        self,
        task: str,
        task_type: TaskType = TaskType.CHAT,
        difficulty: Difficulty = Difficulty.MEDIUM,
        importance: Importance = Importance.NORMAL,
        mode: Optional[Mode] = None,
        budget_limit: Optional[float] = None
    ) -> Dict[str, Any]:
        """智能选择最优模型"""
        
        # 使用配置默认值
        if mode is None:
            mode_str = self.config.get("default_mode", "平衡")
            mode = self._str_to_mode(mode_str)
        
        if budget_limit is None:
            budget_limit = self.config.get("budget_limit")
        
        candidates = list(self.models.values())
        
        if not candidates:
            return {"error": "没有可用的模型，请检查配置"}
        
        # 检查用户偏好（学习功能）
        user_pref = self.config.get("user_preferences", {}).get(task_type.value)
        if user_pref and user_pref in self.models:
            logger.info(f"应用用户偏好: {task_type.value} -> {user_pref}")
        
        # 预算筛选
        if budget_limit:
            candidates = [m for m in candidates if m.cost_per_1k() <= budget_limit]
        
        # 根据模式选择
        if mode == Mode.SAVE_MONEY:
            candidates.sort(key=lambda m: m.input_price)
            best_model = candidates[0]
            reason = "省钱模式：选择最便宜的模型"
            
        elif mode == Mode.QUALITY_FIRST:
            candidates.sort(key=lambda m: m.performance, reverse=True)
            best_model = candidates[0]
            reason = "质量优先：选择性能最强的模型"
            
        elif mode == Mode.SPEED_FIRST:
            candidates.sort(key=lambda m: m.speed, reverse=True)
            best_model = candidates[0]
            reason = "速度优先：选择响应最快的模型"
            
        elif mode == Mode.PERFORMANCE:
            scored = []
            for model in candidates:
                score = model.performance * 0.7 + model.value_score() * 0.3
                scored.append({"model": model, "score": score})
            scored.sort(key=lambda x: x["score"], reverse=True)
            best_model = scored[0]["model"]
            reason = "性能模式：平衡性能与性价比"
            
        else:  # BALANCED
            scored = []
            for model in candidates:
                score = self._calculate_score(model, task_type, difficulty, importance)
                scored.append({"model": model, "score": score})
            scored.sort(key=lambda x: x["score"], reverse=True)
            best_model = scored[0]["model"]
            reason = self._generate_reason(best_model, task_type, difficulty, importance)
        
        # 计算成本
        cost = best_model.cost_per_1k()
        
        # 计算节省
        if len(candidates) > 1:
            max_cost = max(m.cost_per_1k() for m in candidates)
            saved = max_cost - cost
        else:
            saved = 0
        
        self.total_saved += max(0, saved)
        self.total_calls += 1
        
        # 获取 Top3 对比
        top3 = self._get_top3_comparison(candidates, best_model, task_type)
        
        # 记录历史
        self.history["calls"].append({
            "timestamp": datetime.now().isoformat(),
            "task": task[:100],  # 截断
            "task_type": task_type.value,
            "difficulty": difficulty.name,
            "importance": importance.name,
            "mode": mode.value,
            "selected": best_model.id,
            "cost": cost,
            "saved": saved
        })
        
        # 保存历史
        self._save_history()
        
        return {
            "推荐模型": best_model.name,
            "模型ID": best_model.id,
            "提供商": best_model.provider,
            "选择模式": mode.value,
            "性能评分": best_model.performance,
            "速度评分": best_model.speed,
            "性价比": round(best_model.value_score(), 1),
            "预估成本": f"${cost:.4f}/1k tokens",
            "选择理由": reason,
            "本次节省": f"${max(0, saved):.4f}",
            "累计节省": f"${self.total_saved:.4f}",
            "总调用次数": self.total_calls,
            "Top3对比": top3
        }
    
    def _calculate_score(self, model: Model, task_type: TaskType, 
                         difficulty: Difficulty, importance: Importance) -> float:
        """计算综合得分"""
        score = model.value_score() * 0.35
        
        # 难度匹配
        if difficulty == Difficulty.EXTREME:
            score += (model.performance / 5.0 if model.performance >= 4.5 else 0.2) * 25
        elif difficulty == Difficulty.COMPLEX:
            score += ((model.performance + 1) / 5.0 if model.performance >= 4.0 else 0.5) * 25
        else:
            score += (1.0 + model.speed / 10) * 25
        
        # 重要性匹配
        if importance == Importance.CRITICAL:
            score += (model.performance / 5.0 if model.performance >= 4.5 else 0.3) * 25
        elif importance == Importance.HIGH:
            score += ((model.performance + 1) / 6.0 if model.performance >= 4.0 else 0.5) * 25
        else:
            score += 25
        
        # 类型匹配
        keywords = {
            TaskType.CHAT: ["chat", "对话", "中文"],
            TaskType.CODE: ["code", "代码", "编程"],
            TaskType.ANALYSIS: ["analysis", "分析", "推理"],
            TaskType.FINANCE: ["finance", "金融", "分析", "math"],
            TaskType.WRITING: ["writing", "创作", "写作"],
            TaskType.TRANSLATION: ["translation", "翻译", "中文"]
        }
        matches = sum(1 for k in keywords.get(task_type, []) if k in model.strengths)
        score += min(matches / 2.0, 1.0) * 15
        
        return score
    
    def _generate_reason(self, model: Model, task_type: TaskType,
                        difficulty: Difficulty, importance: Importance) -> str:
        """生成选择理由"""
        reasons = []
        
        if model.input_price < 0.1:
            reasons.append("💰 超高性价比")
        elif model.input_price < 1:
            reasons.append("💵 高性价比")
        
        if model.performance >= 4.5:
            reasons.append("⭐ 顶级性能")
        elif model.performance >= 4:
            reasons.append("✨ 优秀性能")
        
        keywords = {
            TaskType.CHAT: ["chat", "对话", "中文"],
            TaskType.CODE: ["code", "代码"],
            TaskType.ANALYSIS: ["analysis", "分析", "推理"],
            TaskType.FINANCE: ["analysis", "math"],
            TaskType.WRITING: ["writing", "创作"],
            TaskType.TRANSLATION: ["translation", "翻译"]
        }
        matches = sum(1 for k in keywords.get(task_type, []) if k in model.strengths)
        if matches > 0:
            reasons.append(f"🎯 擅长{task_type.value}任务")
        
        if difficulty.value >= 3 and model.performance >= 4:
            reasons.append("🧠 适合复杂任务")
        elif difficulty.value <= 2 and model.speed >= 4:
            reasons.append("⚡ 响应快速")
        
        return " | ".join(reasons) if reasons else "综合评估最优"
    
    def _get_top3_comparison(self, candidates: List[Model], best: Model, 
                            task_type: TaskType) -> List[Dict]:
        """获取 Top3 对比"""
        scored = []
        for model in candidates:
            score = self._calculate_score(model, task_type, Difficulty.MEDIUM, Importance.NORMAL)
            scored.append({"model": model, "score": score})
        
        scored.sort(key=lambda x: x["score"], reverse=True)
        top3 = scored[:3]
        
        result = []
        for i, item in enumerate(top3):
            model = item["model"]
            is_selected = model.id == best.id
            
            # 生成对比说明
            if is_selected:
                comparison = "✅ 当前选择"
            elif model.input_price < best.input_price:
                comparison = f"更便宜但{'性能较低' if model.performance < best.performance else '性价比较高'}"
            elif model.performance > best.performance:
                comparison = f"性能更强但价格更高"
            else:
                comparison = "备选方案"
            
            result.append({
                "排名": i + 1,
                "模型": model.name,
                "模型ID": model.id,
                "性价比": round(model.value_score(), 1),
                "成本": f"${model.cost_per_1k():.4f}/1k",
                "性能": model.performance,
                "对比说明": comparison,
                "是否选中": is_selected
            })
        
        return result
    
    def _str_to_mode(self, mode_str: str) -> Mode:
        """字符串转模式"""
        mode_map = {
            "省钱": Mode.SAVE_MONEY,
            "平衡": Mode.BALANCED,
            "性能": Mode.PERFORMANCE,
            "质量优先": Mode.QUALITY_FIRST,
            "速度优先": Mode.SPEED_FIRST,
        }
        return mode_map.get(mode_str, Mode.BALANCED)
    
    def learn_preference(self, task_type: TaskType, preferred_model: str):
        """学习用户偏好"""
        if not self.config.get("enable_learning", True):
            return
        
        if "user_preferences" not in self.config:
            self.config["user_preferences"] = {}
        
        self.config["user_preferences"][task_type.value] = preferred_model
        self._save_config()
        logger.info(f"已学习偏好: {task_type.value} -> {preferred_model}")
    
    def batch_select(self, tasks: List[Dict]) -> Dict[str, Any]:
        """批量任务优化"""
        results = []
        total_cost = 0
        total_saved = 0
        
        for task_info in tasks:
            result = self.select(
                task=task_info.get("task", ""),
                task_type=TaskType(task_info.get("task_type", "chat")),
                difficulty=Difficulty(task_info.get("difficulty", 2)),
                importance=Importance(task_info.get("importance", 2)),
                mode=self._str_to_mode(task_info.get("mode", "平衡"))
            )
            results.append(result)
            total_cost += float(result["预估成本"].replace("$", "").replace("/1k tokens", ""))
            total_saved += float(result["本次节省"].replace("$", ""))
        
        return {
            "批量结果": results,
            "任务数量": len(tasks),
            "总成本": f"${total_cost:.4f}",
            "总节省": f"${total_saved:.4f}",
            "平均成本": f"${total_cost/len(tasks):.4f}/任务"
        }
    
    def get_ranking(self, by: str = "value") -> List[Dict]:
        """获取排行榜"""
        models = list(self.models.values())
        
        if by == "value":
            models.sort(key=lambda m: m.value_score(), reverse=True)
        elif by == "price":
            models.sort(key=lambda m: m.input_price)
        elif by == "performance":
            models.sort(key=lambda m: m.performance, reverse=True)
        
        return [
            {
                "排名": i + 1,
                "模型": m.name,
                "模型ID": m.id,
                "性价比": round(m.value_score(), 1),
                "性能": m.performance,
                "输入价格": f"${m.input_price}/1M",
                "输出价格": f"${m.output_price}/1M"
            }
            for i, m in enumerate(models)
        ]
    
    def get_stats(self) -> Dict:
        """获取统计"""
        return {
            "总调用": self.total_calls,
            "累计节省": f"${self.total_saved:.4f}",
            "可用模型": len(self.models),
            "用户偏好": self.config.get("user_preferences", {}),
            "配置文件": str(self.config_path),
            "历史文件": str(self.history_path)
        }
    
    def set_available_models(self, model_ids: List[str]):
        """设置可用模型"""
        self.config["available_models"] = model_ids
        self._save_config()
        self.models = self._load_models()
        logger.info(f"已更新可用模型: {model_ids}")
    
    def set_price_override(self, model_id: str, input_price: float, output_price: float):
        """设置价格覆盖"""
        if "price_overrides" not in self.config:
            self.config["price_overrides"] = {}
        self.config["price_overrides"][model_id] = {
            "input": input_price,
            "output": output_price
        }
        self._save_config()
        self.models = self._load_models()
        logger.info(f"已更新价格: {model_id} -> ${input_price}/${output_price}")
    
    def record_response(self, model_id: str, response_time: float, success: bool = True):
        """
        记录模型响应（用于计算实际性能/速度评分）
        
        Args:
            model_id: 模型ID
            response_time: 响应时间（秒）
            success: 是否成功
        """
        self.perf_tracker.record_response(model_id, response_time, success)
        
        # 重新加载模型以更新评分
        self.models = self._load_models()
        
        # 记录日志
        avg_time = self.perf_tracker.get_avg_response_time(model_id)
        success_rate = self.perf_tracker.get_success_rate(model_id)
        logger.info(f"记录响应: {model_id} | 时间: {response_time:.2f}s | 平均: {avg_time:.2f}s | 成功率: {success_rate:.1%}" if success_rate else f"记录响应: {model_id} | 时间: {response_time:.2f}s")
    
    def get_model_stats(self, model_id: str) -> Dict:
        """获取模型实际统计"""
        return {
            "模型": model_id,
            "平均响应时间": f"{self.perf_tracker.get_avg_response_time(model_id):.2f}s" if self.perf_tracker.get_avg_response_time(model_id) else "无数据",
            "成功率": f"{self.perf_tracker.get_success_rate(model_id):.1%}" if self.perf_tracker.get_success_rate(model_id) else "无数据",
            "计算速度评分": self.perf_tracker.get_calculated_speed_score(model_id, DEFAULT_MODELS.get(model_id, Model("", "", "", 0, 0, 0, 3, 3, [])).speed),
            "计算性能评分": self.perf_tracker.get_calculated_performance_score(model_id, DEFAULT_MODELS.get(model_id, Model("", "", "", 0, 0, 0, 3, 3, [])).performance)
        }


# ============================================================
# 便捷函数
# ============================================================

_tokenpilot = None
_first_run_checked = False

def _check_first_run():
    """检查首次运行，显示模式选择引导"""
    global _first_run_checked
    if _first_run_checked:
        return
    
    workspace = Path.home() / ".openclaw" / "workspace"
    config_path = workspace / "tokenpilot_config.json"
    
    # 检查是否已完成首次设置
    if config_path.exists():
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                config = json.load(f)
            if config.get("first_run_completed", False):
                _first_run_checked = True
                return
        except:
            pass
    
    # 首次运行，显示引导
    print()
    print("╔" + "═" * 56 + "╗")
    print("║" + " TokenPilot - 首次运行 ".center(52) + "║")
    print("╚" + "═" * 56 + "╝")
    print()
    print("🎉 欢迎使用 TokenPilot！")
    print()
    print("请先运行初始化设置：")
    print()
    print("    python tokenpilot_init.py")
    print()
    print("或者直接使用（将使用默认平衡模式）：")
    print()
    print("    from TokenPilot import token_select")
    print("    result = token_select('你的任务')")
    print()
    
    # 自动标记为已完成（使用默认设置）
    _first_run_checked = True
    
    # 创建默认配置
    try:
        default_config = {
            "version": "2.0.0",
            "available_models": None,
            "default_mode": "平衡",
            "budget_limit": None,
            "auto_detect_from_openclaw": True,
            "enable_learning": True,
            "enable_persistence": True,
            "first_run_completed": True,
            "price_overrides": {},
            "performance_overrides": {},
            "user_preferences": {}
        }
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(default_config, f, indent=2, ensure_ascii=False)
    except:
        pass

def _get_tokenpilot() -> TokenPilot:
    global _tokenpilot
    if _tokenpilot is None:
        _check_first_run()
        _tokenpilot = TokenPilot()
    return _tokenpilot

def token_select(
    task: str,
    difficulty: str = "medium",
    importance: str = "normal",
    task_type: str = "chat",
    mode: str = "平衡"
) -> Dict[str, Any]:
    """快速选择最优模型"""
    tp = _get_tokenpilot()
    
    diff_map = {"simple": 1, "medium": 2, "complex": 3, "extreme": 4}
    imp_map = {"low": 1, "normal": 2, "high": 3, "critical": 4}
    
    return tp.select(
        task=task,
        task_type=TaskType(task_type),
        difficulty=Difficulty(diff_map.get(difficulty, 2)),
        importance=Importance(imp_map.get(importance, 2)),
        mode=tp._str_to_mode(mode)
    )

def set_my_models(model_ids: List[str]):
    """设置可用模型"""
    _get_tokenpilot().set_available_models(model_ids)

def get_ranking(by: str = "value") -> List[Dict]:
    """获取排行榜"""
    return _get_tokenpilot().get_ranking(by)

def get_stats() -> Dict:
    """获取统计"""
    return _get_tokenpilot().get_stats()

def learn_preference(task_type: str, model_id: str):
    """学习用户偏好"""
    _get_tokenpilot().learn_preference(TaskType(task_type), model_id)

def batch_select(tasks: List[Dict]) -> Dict:
    """批量选择"""
    return _get_tokenpilot().batch_select(tasks)

def record_response(model_id: str, response_time: float, success: bool = True):
    """
    记录模型响应（用于计算实际性能/速度评分）
    
    在你实际调用模型后，记录响应时间和成功/失败
    系统会自动计算平均响应时间和成功率
    """
    _get_tokenpilot().record_response(model_id, response_time, success)

def get_model_stats(model_id: str) -> Dict:
    """获取模型实际统计（响应时间、成功率）"""
    return _get_tokenpilot().get_model_stats(model_id)

def record_response(model_id: str, response_time: float, success: bool = True):
    """记录模型响应（用于计算实际性能）"""
    _get_tokenpilot().record_response(model_id, response_time, success)

def get_model_stats(model_id: str) -> Dict:
    """获取模型实际统计"""
    return _get_tokenpilot().get_model_stats(model_id)


# ============================================================
# 演示
# ============================================================

def demo():
    """演示 TokenPilot v2.0"""
    
    print("╔" + "═" * 60 + "╗")
    print("║" + " TokenPilot v2.0 - Token 性价比智能选择器 ".center(56) + "║")
    print("╚" + "═" * 60 + "╝")
    
    print("\n📊 性价比排行榜")
    print("-" * 62)
    
    ranking = get_ranking()
    for r in ranking:
        marker = "🏆" if r["排名"] == 1 else "  "
        print(f"{marker} {r['排名']:2d}. {r['模型']:18s} | 性价比: {r['性价比']:6.1f} | 价格: {r['输入价格']:>12s}")
    
    print("\n" + "=" * 62)
    print("🎯 智能选择示例（带 Top3 对比）")
    print("=" * 62)
    
    result = token_select(
        task="分析财报找出风险点",
        difficulty="complex",
        importance="high",
        task_type="finance",
        mode="性能"
    )
    
    print(f"\n✅ 推荐: {result['推荐模型']}")
    print(f"💰 成本: {result['预估成本']}")
    print(f"📝 理由: {result['选择理由']}")
    print(f"💵 节省: {result['本次节省']}")
    
    print("\n📊 Top3 对比:")
    print("-" * 62)
    for item in result["Top3对比"]:
        marker = "✅" if item["是否选中"] else "  "
        print(f"{marker} {item['排名']}. {item['模型']:18s} | {item['成本']:>15s} | {item['对比说明']}")
    
    print("\n" + "=" * 62)
    print("📚 统计信息")
    print("-" * 62)
    stats = get_stats()
    for k, v in stats.items():
        print(f"  {k}: {v}")
    
    print("\n" + "=" * 62)
    print("🔧 新功能演示")
    print("-" * 62)
    print("""
# 1. 设置可用模型（自动从 openclaw.json 检测）
set_my_models(["glm-4-flash", "deepseek-v3", "gpt-5.2"])

# 2. 学习用户偏好
learn_preference("finance", "deepseek-r1")  # 记住你偏好用 deepseek-r1 做金融任务

# 3. 批量选择
tasks = [
    {"task": "写代码", "task_type": "code"},
    {"task": "分析数据", "task_type": "analysis"},
    {"task": "翻译文档", "task_type": "translation"}
]
batch_select(tasks)

# 4. 查看统计
get_stats()
""")
    
    print("✨ TokenPilot v2.0 演示完成！")


if __name__ == "__main__":
    demo()