# TokenPilot 安全规则

## 敏感信息扫描规则

发布前自动扫描以下模式：

### API Key

```regex
sk-[a-zA-Z0-9]{20,}
ak-[a-zA-Z0-9]{16,}
AKIA[A-Z0-9]{16}
xox[baprs]-[a-zA-Z0-9-]+
ghp_[a-zA-Z0-9]{36}
```

### Token

```regex
bearer\s+[a-zA-Z0-9-._~+/]+=*
token\s*[:=]\s*['""][a-zA-Z0-9-._~+/]+['""]
```

### 密码/Secret

```regex
password\s*[:=]\s*['""][^'""]+['""]
SECRET_KEY\s*[:=]\s*['""][^'""]+['""]
API_KEY\s*[:=]\s*['""][^'""]+['""]
```

### 私钥

```regex
-----BEGIN.*PRIVATE KEY-----
-----BEGIN.*RSA PRIVATE KEY-----
```

### 个人信息

```regex
[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}
1[3-9]\d{9}
ou_[a-f0-9]{32}
chat_[a-f0-9]{32}
```

### 环境变量

```regex
export\s+[A-Z_]+=\s*['""][^'""]+['""]
\.env
```

### 路径泄露

```regex
/Users/[a-zA-Z]+/
/home/[a-zA-Z]+/
C:\\Users\\[a-zA-Z]+\\
```

## 扫描结果处理

- ⚠️ 发现敏感信息：标注但不阻止发布
- 🔴 高危信息：建议用户确认后再发布
- ✅ 无敏感信息：正常发布