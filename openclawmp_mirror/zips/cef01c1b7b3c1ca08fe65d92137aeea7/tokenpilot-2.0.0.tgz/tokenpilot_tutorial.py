#!/usr/bin/env python3
"""
TokenPilot 新手教程
交互式学习如何使用 TokenPilot
"""

import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from TokenPilot import token_select, get_ranking, get_stats, set_my_models, learn_preference

def slow_print(text, delay=0.03):
    """缓慢打印文字"""
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def wait_enter(prompt="按回车继续..."):
    """等待用户按回车"""
    input(f"\n{prompt}")

def clear_screen():
    """清屏"""
    print("\n" * 2)

def tutorial_intro():
    """教程介绍"""
    print("╔" + "═" * 56 + "╗")
    print("║" + " TokenPilot 新手教程 ".center(52) + "║")
    print("╚" + "═" * 56 + "╝")
    
    print("""
🎯 欢迎使用 TokenPilot！

TokenPilot 是一个 Token 性价比智能选择器
帮助你在使用 AI 模型时节省成本

本教程将带你快速上手，预计 5 分钟完成
""")
    wait_enter()

def lesson_1():
    """第1课：基本选择"""
    clear_screen()
    print("📚 第 1 课：基本选择")
    print("-" * 50)
    print("""
TokenPilot 的核心功能是帮你选择最优模型

你只需要告诉它：
  • 任务描述（做什么）
  • 任务难度（有多难）
  • 任务类型（什么类型）
  • 选择模式（省钱还是质量优先）

然后它会自动推荐最合适的模型！
""")
    wait_enter()
    
    print("\n💡 让我们试一个例子：")
    print("任务：帮我写一个简单的问候语\n")
    
    result = token_select(
        task="帮我写一个简单的问候语",
        difficulty="simple",
        task_type="chat",
        mode="省钱"
    )
    
    print(f"✅ 推荐: {result['推荐模型']}")
    print(f"💰 成本: {result['预估成本']}")
    print(f"📝 理由: {result['选择理由']}")
    
    print("""
看到没有？系统推荐了 GLM-4-Flash
因为它最便宜，适合简单任务！

如果是复杂任务，系统会推荐更强大的模型。
""")
    wait_enter()

def lesson_2():
    """第2课：五种模式"""
    clear_screen()
    print("📚 第 2 课：五种选择模式")
    print("-" * 50)
    print("""
TokenPilot 有 5 种选择模式：

1️⃣  省钱模式     - 选择最便宜的模型
2️⃣  平衡模式     - 性价比最优（默认）
3️⃣  性能模式     - 优先高性能
4️⃣  质量优先  - 选择性能最强的
5️⃣  速度优先  - 选择响应最快的
""")
    wait_enter()
    
    print("\n💡 同一个任务，不同模式的结果：\n")
    
    task = "分析财报找出风险点"
    modes = ["省钱", "平衡", "质量优先"]
    
    for mode in modes:
        result = token_select(task, difficulty="complex", task_type="finance", mode=mode)
        print(f"【{mode}模式】")
        print(f"  推荐: {result['推荐模型']}")
        print(f"  成本: {result['预估成本']}")
        print()
    
    print("看到了吗？不同模式会选择不同的模型！")
    wait_enter()

def lesson_3():
    """第3课：性价比排行榜"""
    clear_screen()
    print("📚 第 3 课：性价比排行榜")
    print("-" * 50)
    print("""
想知道哪个模型最划算？查看排行榜！
""")
    
    ranking = get_ranking()
    
    print("🏆 模型性价比 Top 5：\n")
    for r in ranking[:5]:
        print(f"  {r['排名']}. {r['模型']:18s} | 性价比: {r['性价比']:6.1f}")
    
    print("""
💡 小贴士：
  • GLM-4-Flash 性价比最高，适合日常任务
  • DeepSeek V3 性能好，性价比也不错
  • GPT-5.2 Pro 性能最强，但价格很贵
""")
    wait_enter()

def lesson_4():
    """第4课：设置可用模型"""
    clear_screen()
    print("📚 第 4 课：设置可用模型")
    print("-" * 50)
    print("""
你可能只接了部分模型的 API
告诉 TokenPilot 你有哪些模型可用
""")
    
    print("💡 示例：设置可用模型\n")
    print('  set_my_models(["glm-4-flash", "deepseek-v3", "gpt-5.2"])')
    
    print("""
设置后，系统只会从这些模型中选择
避免推荐你无法使用的模型

你可以编辑配置文件：
  ~/.openclaw/workspace/tokenpilot_config.json
""")
    wait_enter()

def lesson_5():
    """第5课：学习偏好"""
    clear_screen()
    print("📚 第 5 课：让系统学习你的偏好")
    print("-" * 50)
    print("""
TokenPilot 可以记住你的偏好！
比如你做金融任务时偏好用 DeepSeek R1
""")
    
    print("\n💡 示例：\n")
    print('  learn_preference("finance", "deepseek-r1")')
    print("""
设置后，每次金融任务都会优先考虑 deepseek-r1

系统会记住你的选择，越用越智能！
""")
    wait_enter()

def lesson_6():
    """第6课：实战练习"""
    clear_screen()
    print("📚 第 6 课：实战练习")
    print("-" * 50)
    print("""
现在轮到你来试试了！

输入一个任务描述，系统会为你推荐模型
输入 'quit' 退出练习
""")
    
    while True:
        print()
        task = input("📝 请输入任务描述: ").strip()
        
        if task.lower() in ['quit', 'exit', '退出', 'q']:
            break
        
        if not task:
            continue
        
        result = token_select(task)
        
        print(f"\n✅ 推荐: {result['推荐模型']}")
        print(f"💰 成本: {result['预估成本']}")
        print(f"📝 理由: {result['选择理由']}")
        
        print("\n" + "-" * 50)

def tutorial_summary():
    """教程总结"""
    clear_screen()
    print("🎓 教程完成！")
    print("=" * 50)
    print("""
恭喜你完成了 TokenPilot 新手教程！

📚 你学会了：
  ✅ 基本选择 - 让系统推荐最优模型
  ✅ 五种模式 - 根据需求切换模式
  ✅ 排行榜   - 查看模型性价比
  ✅ 设置模型 - 限制可用模型
  ✅ 学习偏好 - 让系统记住你的选择

🚀 快速参考：

  from TokenPilot import token_select
  
  result = token_select(
      task="你的任务",
      difficulty="medium",    # simple/medium/complex/extreme
      task_type="chat",       # chat/code/analysis/finance/writing
      mode="平衡"             # 省钱/平衡/性能/质量优先/速度优先
  )

💡 更多帮助：
  查看 TOKENPILOT_REPORT.md 获取详细文档
""")
    
    stats = get_stats()
    print("\n📊 你的使用统计：")
    print(f"  总调用: {stats['总调用']} 次")
    print(f"  累计节省: {stats['累计节省']}")

def main():
    """主函数"""
    try:
        tutorial_intro()
        lesson_1()
        lesson_2()
        lesson_3()
        lesson_4()
        lesson_5()
        lesson_6()
        tutorial_summary()
        
        print("\n👋 感谢使用 TokenPilot！再见！\n")
        
    except KeyboardInterrupt:
        print("\n\n👋 教程已中断，再见！\n")

if __name__ == "__main__":
    main()