#!/usr/bin/env python3
"""
TokenPilot 回测测试套件
测试各种用户场景和边缘情况
"""

import sys
import time
import json
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

print("=" * 60)
print("🧪 TokenPilot 回测测试套件")
print("=" * 60)

test_results = {
    "passed": 0,
    "failed": 0,
    "warnings": 0,
    "tests": []
}

def test(name: str, func):
    """运行测试"""
    global test_results
    print(f"\n📋 {name}")
    print("-" * 40)
    
    try:
        result = func()
        if result.get("warning"):
            test_results["warnings"] += 1
            print(f"  ⚠️  {result['warning']}")
            test_results["tests"].append({"name": name, "status": "warning", "detail": result['warning']})
        elif result.get("failed"):
            test_results["failed"] += 1
            print(f"  ❌ {result['failed']}")
            test_results["tests"].append({"name": name, "status": "failed", "detail": result['failed']})
        else:
            test_results["passed"] += 1
            print(f"  ✅ {result.get('ok', '通过')}")
            test_results["tests"].append({"name": name, "status": "passed"})
    except Exception as e:
        test_results["failed"] += 1
        print(f"  ❌ 异常: {e}")
        test_results["tests"].append({"name": name, "status": "error", "detail": str(e)})

# ==================== 回测场景 ====================

def test_basic_selection():
    """基本选择测试"""
    from TokenPilot import token_select
    result = token_select("测试任务")
    if result.get("推荐模型"):
        return {"ok": f"推荐: {result['推荐模型']}"}
    return {"failed": "无推荐模型"}

def test_free_models_priority():
    """免费模型优先测试"""
    from TokenPilot import get_ranking
    ranking = get_ranking()
    top = ranking[0]
    if top['输入价格'] == '$0.0/1M':
        return {"ok": f"榜首免费: {top['模型']}"}
    return {"warning": "免费模型未优先"}

def test_all_task_types():
    """所有任务类型测试"""
    from TokenPilot import token_select
    types = ['chat', 'code', 'analysis', 'finance', 'writing', 'translation']
    for t in types:
        r = token_select(f"测试{t}", task_type=t)
        if not r.get("推荐模型"):
            return {"failed": f"{t} 类型失败"}
    return {"ok": "所有类型通过"}

def test_all_modes():
    """所有模式测试"""
    from TokenPilot import token_select
    modes = ['省钱', '平衡', '性能', '质量优先', '速度优先']
    for m in modes:
        r = token_select("测试", mode=m)
        if not r.get("推荐模型"):
            return {"failed": f"{m} 模式失败"}
    return {"ok": "所有模式通过"}

def test_empty_input():
    """空输入测试"""
    from TokenPilot import token_select
    r = token_select("")
    if r.get("推荐模型"):
        return {"ok": "空输入有默认处理"}
    return {"warning": "空输入无推荐"}

def test_long_input():
    """超长输入测试"""
    from TokenPilot import token_select
    long_text = "测试" * 10000
    r = token_select(long_text)
    if r.get("推荐模型"):
        return {"ok": "超长输入正常处理"}
    return {"failed": "超长输入失败"}

def test_special_chars():
    """特殊字符测试"""
    from TokenPilot import token_select
    special = "测试<script>alert(1)</script>日本語中文English🎉🔥"
    r = token_select(special)
    if r.get("推荐模型"):
        return {"ok": "特殊字符正常处理"}
    return {"failed": "特殊字符失败"}

def test_invalid_models():
    """无效模型配置测试"""
    from TokenPilot import set_my_models, _get_tokenpilot
    set_my_models(["invalid-model-123", "not-exist"])
    tp = _get_tokenpilot()
    if len(tp.models) > 0:
        set_my_models(None)  # 恢复
        return {"ok": "无效模型被正确处理"}
    set_my_models(None)
    return {"failed": "无效模型导致空列表"}

def test_mixed_valid_invalid_models():
    """混合有效无效模型测试"""
    from TokenPilot import set_my_models, _get_tokenpilot
    set_my_models(["glm-5", "invalid-model", "qwen3-max"])
    tp = _get_tokenpilot()
    count = len(tp.models)
    set_my_models(None)
    if count >= 2:
        return {"ok": f"有效模型被保留: {count} 个"}
    return {"warning": f"仅保留 {count} 个模型"}

def test_batch_tasks():
    """批量任务测试"""
    from TokenPilot import batch_select
    tasks = [
        {"task": "写代码", "task_type": "code"},
        {"task": "翻译", "task_type": "translation"},
        {"task": "分析", "task_type": "analysis"},
    ]
    r = batch_select(tasks)
    if r.get("任务数量") == 3:
        return {"ok": f"批量任务: {r['任务数量']} 个"}
    return {"failed": "批量任务失败"}

def test_performance_100():
    """性能测试 (100次)"""
    from TokenPilot import token_select
    start = time.time()
    for _ in range(100):
        token_select("性能测试")
    elapsed = time.time() - start
    if elapsed < 1:
        return {"ok": f"100次调用: {elapsed:.2f}s"}
    return {"warning": f"性能较慢: {elapsed:.2f}s"}

def test_ranking_order():
    """排行榜排序测试"""
    from TokenPilot import get_ranking
    ranking = get_ranking()
    prev = float('inf')
    for r in ranking:
        if r['性价比'] > prev:
            return {"failed": "排行榜未正确排序"}
        prev = r['性价比']
    return {"ok": "排序正确"}

def test_stats_consistency():
    """统计一致性测试"""
    from TokenPilot import get_stats, get_ranking
    stats = get_stats()
    ranking = get_ranking()
    if stats['可用模型'] == len(ranking):
        return {"ok": f"统计一致: {stats['可用模型']} 个模型"}
    return {"warning": "统计不一致"}

def test_config_persistence():
    """配置持久化测试"""
    from TokenPilot import set_my_models, _get_tokenpilot
    import json
    
    # 设置特定模型
    set_my_models(["glm-5", "qwen3-max"])
    
    # 检查配置文件
    config_path = Path.home() / ".openclaw" / "workspace" / "tokenpilot_config.json"
    with open(config_path) as f:
        config = json.load(f)
    
    set_my_models(None)  # 恢复
    
    if config.get("available_models") == ["glm-5", "qwen3-max"]:
        return {"ok": "配置持久化正常"}
    return {"warning": "配置未正确保存"}

def test_user_preference():
    """用户偏好学习测试"""
    from TokenPilot import learn_preference, get_stats, token_select
    learn_preference("finance", "qwen3-max")
    
    # 选择金融任务
    r = token_select("分析财报", task_type="finance")
    
    stats = get_stats()
    prefs = stats.get("用户偏好", {})
    
    if prefs.get("finance") == "qwen3-max":
        return {"ok": "偏好学习成功"}
    return {"warning": "偏好未保存"}

def test_difficulty_levels():
    """所有难度级别测试"""
    from TokenPilot import token_select
    levels = ['simple', 'medium', 'complex', 'extreme']
    for d in levels:
        r = token_select("测试", difficulty=d)
        if not r.get("推荐模型"):
            return {"failed": f"难度 {d} 失败"}
    return {"ok": "所有难度通过"}

def test_importance_levels():
    """所有重要性级别测试"""
    from TokenPilot import token_select
    levels = ['low', 'normal', 'high', 'critical']
    for i in levels:
        r = token_select("测试", importance=i)
        if not r.get("推荐模型"):
            return {"failed": f"重要性 {i} 失败"}
    return {"ok": "所有重要性通过"}

# ==================== 运行测试 ====================

print("\n" + "=" * 60)
print("🏃 开始回测...")
print("=" * 60)

# 基础测试
test("1. 基本选择", test_basic_selection)
test("2. 免费模型优先", test_free_models_priority)
test("3. 所有任务类型", test_all_task_types)
test("4. 所有选择模式", test_all_modes)

# 边缘情况
test("5. 空输入处理", test_empty_input)
test("6. 超长输入处理", test_long_input)
test("7. 特殊字符处理", test_special_chars)

# 配置测试
test("8. 无效模型配置", test_invalid_models)
test("9. 混合有效无效模型", test_mixed_valid_invalid_models)
test("10. 配置持久化", test_config_persistence)

# 功能测试
test("11. 批量任务", test_batch_tasks)
test("12. 用户偏好学习", test_user_preference)
test("13. 所有难度级别", test_difficulty_levels)
test("14. 所有重要性级别", test_importance_levels)

# 质量测试
test("15. 性能测试 (100次)", test_performance_100)
test("16. 排行榜排序", test_ranking_order)
test("17. 统计一致性", test_stats_consistency)

# ==================== 总结 ====================

print("\n" + "=" * 60)
print("📊 回测总结")
print("=" * 60)

total = test_results["passed"] + test_results["failed"] + test_results["warnings"]
print(f"\n  总测试数: {total}")
print(f"  ✅ 通过: {test_results['passed']}")
print(f"  ❌ 失败: {test_results['failed']}")
print(f"  ⚠️  警告: {test_results['warnings']}")

if test_results["failed"] == 0:
    print("\n  🎉 所有关键测试通过！")
else:
    print(f"\n  ⚠️  发现 {test_results['failed']} 个失败项，需要修复")
    for t in test_results["tests"]:
        if t["status"] == "failed":
            print(f"     - {t['name']}: {t.get('detail', '')}")

print("\n" + "=" * 60)