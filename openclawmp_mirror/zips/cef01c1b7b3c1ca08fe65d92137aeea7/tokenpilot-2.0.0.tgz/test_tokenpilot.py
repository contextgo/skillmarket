#!/usr/bin/env python3
"""
TokenPilot 单元测试
"""

import unittest
import sys
import os
import tempfile
import json
from pathlib import Path

# 添加工作区到路径
sys.path.insert(0, str(Path(__file__).parent))

from TokenPilot import (
    TokenPilot, token_select, set_my_models, get_ranking, 
    get_stats, learn_preference, record_response, get_model_stats,
    batch_select,
    Difficulty, Mode, Importance, TaskType, Model, DEFAULT_MODELS
)


class TestModel(unittest.TestCase):
    """测试 Model 数据类"""
    
    def test_cost_calculation(self):
        """测试成本计算"""
        model = Model(
            id="test-model", name="Test Model", provider="Test",
            input_price=1.0, output_price=2.0, cache_price=0.5,
            performance=4.0, speed=4.0, strengths=["test"]
        )
        
        # 默认 500+500 tokens
        cost = model.cost_per_1k()
        self.assertAlmostEqual(cost, 1.5)  # (1.0*500 + 2.0*500) / 1000
        
        # 自定义 tokens
        cost = model.cost_per_1k(1000, 1000)
        self.assertAlmostEqual(cost, 3.0)  # (1.0*1000 + 2.0*1000) / 1000
    
    def test_value_score(self):
        """测试性价比计算"""
        # 便宜高性能
        model1 = Model(
            id="cheap", name="Cheap", provider="Test",
            input_price=0.01, output_price=0.01, cache_price=0,
            performance=4.0, speed=4.0, strengths=["test"]
        )
        
        # 贵低性能
        model2 = Model(
            id="expensive", name="Expensive", provider="Test",
            input_price=10.0, output_price=10.0, cache_price=0,
            performance=4.0, speed=4.0, strengths=["test"]
        )
        
        # 便宜的性价比应该更高
        self.assertGreater(model1.value_score(), model2.value_score())


class TestTokenPilotCore(unittest.TestCase):
    """测试 TokenPilot 核心功能"""
    
    def setUp(self):
        """使用临时目录"""
        self.temp_dir = tempfile.mkdtemp()
        self.config_path = os.path.join(self.temp_dir, "config.json")
        self.history_path = os.path.join(self.temp_dir, "history.json")
        
    def tearDown(self):
        """清理临时目录"""
        import shutil
        shutil.rmtree(self.temp_dir)
    
    def test_initialization(self):
        """测试初始化"""
        tp = TokenPilot(self.config_path)
        self.assertIsNotNone(tp.config)
        self.assertIsNotNone(tp.models)
        self.assertGreater(len(tp.models), 0)
    
    def test_select_simple_task(self):
        """测试简单任务选择"""
        tp = TokenPilot(self.config_path)
        result = tp.select(
            task="你好",
            task_type=TaskType.CHAT,
            difficulty=Difficulty.SIMPLE,
            importance=Importance.LOW,
            mode=Mode.SAVE_MONEY
        )
        
        self.assertIn("推荐模型", result)
        self.assertIn("预估成本", result)
        self.assertIn("选择理由", result)
    
    def test_select_complex_task(self):
        """测试复杂任务选择"""
        tp = TokenPilot(self.config_path)
        result = tp.select(
            task="分析财报找出风险点",
            task_type=TaskType.FINANCE,
            difficulty=Difficulty.COMPLEX,
            importance=Importance.HIGH,
            mode=Mode.PERFORMANCE
        )
        
        self.assertIn("推荐模型", result)
        self.assertIn("Top3对比", result)
    
    def test_save_money_mode(self):
        """测试省钱模式"""
        tp = TokenPilot(self.config_path)
        result = tp.select(
            task="简单问题",
            mode=Mode.SAVE_MONEY
        )
        
        # 省钱模式应该选最便宜的
        cheapest_model = min(tp.models.values(), key=lambda m: m.input_price)
        self.assertEqual(result["模型ID"], cheapest_model.id)
    
    def test_quality_first_mode(self):
        """测试质量优先模式"""
        tp = TokenPilot(self.config_path)
        result = tp.select(
            task="关键决策",
            mode=Mode.QUALITY_FIRST
        )
        
        # 质量优先应该选性能最强的
        best_model = max(tp.models.values(), key=lambda m: m.performance)
        self.assertEqual(result["模型ID"], best_model.id)
    
    def test_ranking(self):
        """测试排行榜"""
        tp = TokenPilot(self.config_path)
        ranking = tp.get_ranking("value")
        
        self.assertGreater(len(ranking), 0)
        self.assertIn("排名", ranking[0])
        self.assertIn("模型", ranking[0])
        self.assertIn("性价比", ranking[0])
    
    def test_set_available_models(self):
        """测试设置可用模型"""
        tp = TokenPilot(self.config_path)
        
        # 设置可用模型
        tp.set_available_models(["glm-4-flash", "deepseek-v3"])
        
        # 应该只有 2 个模型
        self.assertEqual(len(tp.models), 2)
        self.assertIn("glm-4-flash", tp.models)
        self.assertIn("deepseek-v3", tp.models)
    
    def test_persistence(self):
        """测试持久化"""
        tp1 = TokenPilot(self.config_path)
        
        # 执行选择
        tp1.select("测试任务")
        
        # 创建新实例，应该加载历史
        tp2 = TokenPilot(self.config_path)
        
        self.assertGreater(tp2.total_calls, 0)


class TestConvenienceFunctions(unittest.TestCase):
    """测试便捷函数"""
    
    def test_token_select(self):
        """测试 token_select 函数"""
        result = token_select("测试任务")
        
        self.assertIn("推荐模型", result)
        self.assertIn("预估成本", result)
    
    def test_get_ranking(self):
        """测试 get_ranking 函数"""
        ranking = get_ranking()
        
        self.assertGreater(len(ranking), 0)
    
    def test_get_stats(self):
        """测试 get_stats 函数"""
        stats = get_stats()
        
        self.assertIn("总调用", stats)
        self.assertIn("可用模型", stats)


class TestPerformanceTracker(unittest.TestCase):
    """测试性能追踪器"""
    
    def test_record_response(self):
        """测试记录响应"""
        result = token_select("测试")
        
        # 记录响应
        record_response("glm-4-flash", 2.5, success=True)
        
        # 获取统计
        stats = get_model_stats("glm-4-flash")
        
        self.assertIn("平均响应时间", stats)
        self.assertIn("成功率", stats)


class TestBatchSelect(unittest.TestCase):
    """测试批量选择"""
    
    def test_batch_select(self):
        """测试批量选择功能"""
        tasks = [
            {"task": "写代码", "task_type": "code"},
            {"task": "翻译文档", "task_type": "translation"},
            {"task": "分析数据", "task_type": "analysis"}
        ]
        
        result = batch_select(tasks)
        
        self.assertIn("批量结果", result)
        self.assertIn("任务数量", result)
        self.assertEqual(result["任务数量"], 3)


class TestUserPreferences(unittest.TestCase):
    """测试用户偏好学习"""
    
    def test_learn_preference(self):
        """测试学习用户偏好"""
        # 学习偏好
        learn_preference("finance", "deepseek-r1")
        
        # 获取统计
        stats = get_stats()
        
        self.assertIn("用户偏好", stats)


if __name__ == '__main__':
    # 运行测试
    unittest.main(verbosity=2)