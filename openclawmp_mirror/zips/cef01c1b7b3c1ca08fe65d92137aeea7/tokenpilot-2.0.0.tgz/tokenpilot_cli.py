#!/usr/bin/env python3
"""
TokenPilot CLI - 命令行工具
Token 性价比智能选择器

用法:
    python TokenPilot.py select "分析财报" --type finance --difficulty complex
    python TokenPilot.py ranking
    python TokenPilot.py stats
    python TokenPilot.py record deepseek-v3 2.5 --success
"""

import argparse
import sys
from TokenPilot import (
    token_select, set_my_models, get_ranking, get_stats,
    learn_preference, batch_select, record_response, get_model_stats
)

def cmd_select(args):
    """选择模型"""
    result = token_select(
        task=args.task,
        difficulty=args.difficulty,
        importance=args.importance,
        task_type=args.type,
        mode=args.mode
    )
    
    if "error" in result:
        print(f"❌ 错误: {result['error']}")
        return 1
    
    print(f"\n✅ 推荐: {result['推荐模型']}")
    print(f"💰 成本: {result['预估成本']}")
    print(f"📝 理由: {result['选择理由']}")
    print(f"💵 节省: {result['本次节省']}")
    
    if result.get('Top3对比'):
        print(f"\n📊 Top3 对比:")
        for item in result['Top3对比']:
            marker = "✅" if item['是否选中'] else "  "
            print(f"  {marker} {item['排名']}. {item['模型']:18s} | {item['成本']:>15s}")
    
    return 0

def cmd_ranking(args):
    """显示排行榜"""
    ranking = get_ranking(args.by)
    
    print(f"\n📊 {'性价比' if args.by == 'value' else '价格' if args.by == 'price' else '性能'}排行榜")
    print("-" * 62)
    
    for r in ranking:
        marker = "🏆" if r["排名"] == 1 else "  "
        print(f"{marker} {r['排名']:2d}. {r['模型']:18s} | 性价比: {r['性价比']:6.1f} | 价格: {r['输入价格']:>12s}")
    
    return 0

def cmd_stats(args):
    """显示统计"""
    stats = get_stats()
    
    print("\n📊 TokenPilot 统计")
    print("-" * 40)
    for k, v in stats.items():
        print(f"  {k}: {v}")
    
    return 0

def cmd_record(args):
    """记录响应"""
    record_response(args.model, args.time, args.success)
    
    stats = get_model_stats(args.model)
    print(f"\n📊 {args.model} 统计:")
    print("-" * 40)
    for k, v in stats.items():
        print(f"  {k}: {v}")
    
    return 0

def cmd_learn(args):
    """学习偏好"""
    learn_preference(args.type, args.model)
    print(f"✅ 已学习偏好: {args.type} -> {args.model}")
    return 0

def cmd_set_models(args):
    """设置可用模型"""
    set_my_models(args.models)
    print(f"✅ 已设置可用模型: {args.models}")
    return 0

def cmd_interactive(args):
    """交互模式"""
    print("\n🎯 TokenPilot 交互模式")
    print("输入任务描述，系统自动推荐最优模型")
    print("输入 'quit' 退出, 'stats' 查看统计, 'ranking' 查看排行\n")
    
    while True:
        try:
            task = input("📝 任务: ").strip()
            
            if task.lower() == 'quit':
                print("👋 再见!")
                break
            
            if task.lower() == 'stats':
                cmd_stats(argparse.Namespace())
                continue
            
            if task.lower() == 'ranking':
                cmd_ranking(argparse.Namespace(by='value'))
                continue
            
            if not task:
                continue
            
            result = token_select(task)
            
            print(f"\n✅ 推荐: {result['推荐模型']}")
            print(f"💰 成本: {result['预估成本']}")
            print(f"📝 理由: {result['选择理由']}\n")
            
        except KeyboardInterrupt:
            print("\n👋 再见!")
            break
    
    return 0

def main():
    parser = argparse.ArgumentParser(
        description="TokenPilot - Token 性价比智能选择器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  %(prog)s select "分析财报" --type finance --difficulty complex
  %(prog)s ranking --by value
  %(prog)s stats
  %(prog)s record deepseek-v3 2.5 --success
  %(prog)s learn finance deepseek-r1
  %(prog)s interactive
        """
    )
    
    subparsers = parser.add_subparsers(dest='command', help='命令')
    
    # select 命令
    p_select = subparsers.add_parser('select', help='选择最优模型')
    p_select.add_argument('task', help='任务描述')
    p_select.add_argument('--type', '-t', default='chat', 
                         choices=['chat', 'code', 'analysis', 'finance', 'writing', 'translation'],
                         help='任务类型')
    p_select.add_argument('--difficulty', '-d', default='medium',
                         choices=['simple', 'medium', 'complex', 'extreme'],
                         help='任务难度')
    p_select.add_argument('--importance', '-i', default='normal',
                         choices=['low', 'normal', 'high', 'critical'],
                         help='任务重要性')
    p_select.add_argument('--mode', '-m', default='平衡',
                         choices=['省钱', '平衡', '性能', '质量优先', '速度优先'],
                         help='选择模式')
    p_select.set_defaults(func=cmd_select)
    
    # ranking 命令
    p_ranking = subparsers.add_parser('ranking', help='显示排行榜')
    p_ranking.add_argument('--by', '-b', default='value',
                          choices=['value', 'price', 'performance'],
                          help='排序依据')
    p_ranking.set_defaults(func=cmd_ranking)
    
    # stats 命令
    p_stats = subparsers.add_parser('stats', help='显示统计')
    p_stats.set_defaults(func=cmd_stats)
    
    # record 命令
    p_record = subparsers.add_parser('record', help='记录模型响应')
    p_record.add_argument('model', help='模型ID')
    p_record.add_argument('time', type=float, help='响应时间(秒)')
    p_record.add_argument('--success', action='store_true', default=True, help='是否成功')
    p_record.set_defaults(func=cmd_record)
    
    # learn 命令
    p_learn = subparsers.add_parser('learn', help='学习用户偏好')
    p_learn.add_argument('type', choices=['chat', 'code', 'analysis', 'finance', 'writing', 'translation'],
                        help='任务类型')
    p_learn.add_argument('model', help='偏好的模型ID')
    p_learn.set_defaults(func=cmd_learn)
    
    # set-models 命令
    p_set = subparsers.add_parser('set-models', help='设置可用模型')
    p_set.add_argument('models', nargs='+', help='模型ID列表')
    p_set.set_defaults(func=cmd_set_models)
    
    # interactive 命令
    p_interactive = subparsers.add_parser('interactive', help='交互模式')
    p_interactive.set_defaults(func=cmd_interactive)
    
    args = parser.parse_args()
    
    if args.command is None:
        parser.print_help()
        return 0
    
    return args.func(args)

if __name__ == '__main__':
    sys.exit(main())