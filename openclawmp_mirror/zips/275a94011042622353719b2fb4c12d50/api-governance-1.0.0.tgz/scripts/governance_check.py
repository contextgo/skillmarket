#!/usr/bin/env python3
"""
API治理检查工具
生成治理健康度报告
"""
import json
import sys
from pathlib import Path

class APIGovernanceChecker:
    """API治理检查器"""
    
    def __init__(self, audit_dir):
        self.audit_dir = Path(audit_dir)
        self.export_index = None
        self.export_tables = None
        self.issues = []
        
    def load_audit_data(self):
        """加载audit数据"""
        index_file = self.audit_dir / "export_index.runtime.json"
        tables_file = self.audit_dir / "export_tables.runtime.json"
        
        if index_file.exists():
            with open(index_file) as f:
                self.export_index = json.load(f)
        
        if tables_file.exists():
            with open(tables_file) as f:
                self.export_tables = json.load(f)
        
        return self.export_index is not None
    
    def check_layer_a(self):
        """检查Layer A（连接层）"""
        issues = []
        stats = {"total": 0, "real": 0, "stub": 0, "unimplemented": 0}
        
        if not self.export_index:
            return {"status": "error", "message": "No export index data"}
        
        functions = self.export_index.get("functions", [])
        stats["total"] = len(functions)
        
        for func in functions:
            impl_type = func.get("impl_type", "UNKNOWN")
            stats[impl_type.lower()] = stats.get(impl_type.lower(), 0) + 1
            
            # 检查REAL被STUB遮挡
            if impl_type == "SUCCESS_STUB":
                # 检查是否有同名REAL
                name = func.get("name", "")
                dll = func.get("dll", "")
                for other in functions:
                    if other.get("name") == name and other.get("dll") == dll:
                        if other.get("impl_type") == "REAL" and other != func:
                            issues.append({
                                "type": "STUB遮挡REAL",
                                "symbol": f"{dll}!{name}",
                                "severity": "high"
                            })
        
        # 计算健康度
        if stats["total"] > 0:
            real_ratio = stats["real"] / stats["total"]
            health = "good" if real_ratio > 0.8 else "warning" if real_ratio > 0.5 else "critical"
        else:
            health = "unknown"
        
        return {
            "status": health,
            "stats": stats,
            "issues": issues[:10]  # 只显示前10个
        }
    
    def check_duplicates(self):
        """检查重复注册"""
        issues = []
        
        if not self.export_index:
            return issues
        
        functions = self.export_index.get("functions", [])
        seen = {}
        
        for func in functions:
            key = (func.get("dll", ""), func.get("name", ""))
            if key in seen:
                issues.append({
                    "type": "重复导出",
                    "symbol": f"{key[0]}!{key[1]}",
                    "locations": [seen[key], func.get("location", "")]
                })
            else:
                seen[key] = func.get("location", "")
        
        return issues
    
    def generate_report(self):
        """生成治理报告"""
        if not self.load_audit_data():
            return "Error: Cannot load audit data"
        
        layer_a = self.check_layer_a()
        duplicates = self.check_duplicates()
        
        report = []
        report.append("# API治理健康度报告")
        report.append(f"\n生成时间: {json.dumps(None)}")
        report.append(f"数据来源: {self.audit_dir}")
        
        # Layer A 报告
        report.append("\n## Layer A (连接层) 健康度")
        report.append(f"\n状态: {layer_a['status'].upper()}")
        
        if "stats" in layer_a:
            stats = layer_a["stats"]
            report.append(f"\n统计:")
            report.append(f"- 总计: {stats['total']}")
            report.append(f"- REAL: {stats['real']} ({stats['real']/stats['total']*100:.1f}%)")
            report.append(f"- SUCCESS_STUB: {stats['stub']}")
            report.append(f"- UNIMPLEMENTED: {stats['unimplemented']}")
        
        if layer_a.get("issues"):
            report.append(f"\n问题 ({len(layer_a['issues'])}):")
            for issue in layer_a["issues"][:5]:
                report.append(f"- [{issue['severity'].upper()}] {issue['type']}: {issue['symbol']}")
        
        # 重复检测
        report.append("\n## 重复注册检测")
        if duplicates:
            report.append(f"\n发现 {len(duplicates)} 个重复:")
            for dup in duplicates[:5]:
                report.append(f"- {dup['symbol']}")
        else:
            report.append("\n未发现重复注册")
        
        # 建议
        report.append("\n## 治理建议")
        if layer_a['status'] == 'critical':
            report.append("- [紧急] REAL覆盖率低于50%，需要大规模接入主链")
        elif layer_a['status'] == 'warning':
            report.append("- [重要] REAL覆盖率50-80%，需要持续迁移")
        
        if duplicates:
            report.append("- [重要] 存在重复注册，需要清理VirtualDLL registry")
        
        if layer_a.get("issues"):
            report.append("- [重要] 存在STUB遮挡REAL，需要调整注册顺序")
        
        return '\n'.join(report)


def main():
    if len(sys.argv) < 2:
        print("Usage: python governance_check.py <audit-dir>")
        return
    
    audit_dir = sys.argv[1]
    checker = APIGovernanceChecker(audit_dir)
    print(checker.generate_report())


if __name__ == '__main__':
    main()
