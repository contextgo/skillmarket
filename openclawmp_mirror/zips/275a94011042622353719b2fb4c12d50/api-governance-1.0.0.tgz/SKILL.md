---
name: api-governance
description: >
  API治理与接口契约管理Skill。提供分层治理检查、接口契约验证、重复实现检测、Runtime Audit生成等能力。适用于API版本管理、兼容性审计、接口治理。触发场景：(1)新增API需要验证契约；(2)检查接口版本兼容性；(3)检测重复实现；(4)生成Runtime Audit报告；(5)评估API治理健康度。触发词：API治理、接口审计、契约检查、重复检测、版本管理、兼容性、runtime audit、治理健康度。
---

# API Governance（API治理）

## 概述

本Skill基于MNQVM的API治理方法论，提供一套系统化的接口契约管理与审计框架。

核心思想：**对外ABI/符号是资产，必须稳定、可审计、唯一**。

## 核心概念

### 1. 分层治理（Layer A/B/C）

| 层级 | 名称 | 职责 | 关注点 |
|------|------|------|--------|
| **Layer A** | 连接层 | 符号→可调用入口 | IAT、GPA、Export、FNID Gate |
| **Layer B** | 语义层 | 最小可持续语义 | API返回值、副作用、ABI |
| **Layer C** | 策略层 | 预算/限频/退场 | 节奏、治理、兼容性策略 |

**治理原则**：
- 连接不通时，不修业务语义（Layer B不得绕过Layer A）
- 语义不正确时，不用策略掩盖（Layer C不得掩盖Layer B缺口）
- 策略层只管理"如何推进/何时停"，不定义"是什么"

### 2. 对外语义资产三件套

| 资产 | 定义 | 示例 |
|------|------|------|
| **符号名** | `DLL!ExportName`（+Ordinal） | `kernel32!CreateFileA` |
| **ABI** | 调用约定+参数/栈/寄存器布局 | x64: RCX/RDX/R8/R9+shadow space |
| **返回值语义** | 返回值+out-params+错误状态组合 | 成功+句柄 / 失败+NULL+GetLastError |

**红线**：同一符号的返回值语义不得因内部路径不同而分叉。

### 3. 函数数据库四类对象

| 类型 | 定义 | 约束 | 典型位置 |
|------|------|------|---------|
| **handler** | 对外语义事实源 | 同一语义只能有一个 | `windows/<dll>/*` |
| **helper** | 内部复用实现 | 可多点复用，不直接对外 | `win32sem/*`, `mnq_fs/*` |
| **wrapper** | ABI/上下文粘合 | 只解决"怎么调"，不解决"做什么" | `win32fnmap/win32_wrappers.c` |
| **stub** | 过渡占位 | 不得遮蔽已存在handler | `vdll_register/register_win32_stubs.c` |

### 4. 唯一事实源原则

**核心规则**：
- 对外语义：只能有一个handler（唯一事实源）
- 对内实现：helper可以多点复用（合法）
- **禁止**：因为路径不同写两份实现；为了快copy一份；以stub遮挡真实实现

### 5. Runtime Audit产物

**标准产物**：
- `export_index.runtime.json` — export-index（flattened）
- `export_tables.runtime.json` — export tables全量快照
- `audit_report.runtime.txt` — 简易文本审计（数量/重复）

**impl_type判定**：
- `is_fnid==1 && fnid!=0` → `REAL`
- `stub != NULL` → `SUCCESS_STUB`
- 否则 → `UNIMPLEMENTED`

## 治理流程

### Phase 1: 连接层检查（Layer A）

**检查项**：
1. **符号解析**
   - [ ] IAT修复是否成功
   - [ ] GetProcAddress返回值是否有效
   - [ ] Export表是否存在目标符号

2. **入口一致性**
   - [ ] Virtual DLL Export是否正确标记`is_fnid+fnid`
   - [ ] 主链dispatch是否可达
   - [ ] 是否存在多路由（FNID/legacy/stub混用）

3. **重复注册检测**
   - [ ] 同名DLL是否在不同base_va重复注册
   - [ ] 同名符号是否重复导出

**输出**：Layer A健康度报告

### Phase 2: 语义层检查（Layer B）

**检查项**：
1. **ABI一致性**
   - [ ] 参数传递是否符合约定
   - [ ] 栈平衡是否正确
   - [ ] 返回值写回是否规范

2. **返回值语义**
   - [ ] 成功/失败约定是否一致
   - [ ] GetLastError设置是否正确
   - [ ] out参数写入是否完整

3. **副作用**
   - [ ] 资源分配/释放是否配对
   - [ ] 全局状态修改是否可预期

**输出**：Layer B语义合规报告

### Phase 3: 策略层检查（Layer C）

**检查项**：
1. **预算管理**
   - [ ] 是否有调用次数限制
   - [ ] 是否有限频机制
   - [ ] 是否有退场策略

2. **兼容性策略**
   - [ ] 版本升级是否向后兼容
   - [ ] 废弃API是否有迁移路径
   - [ ] 是否有兼容性开关

**输出**：Layer C策略健康度报告

### Phase 4: 闲置实现治理

**三类状态**：

| 状态 | 定义 | 处理策略 |
|------|------|---------|
| **IDLE-1** | 定义存在，无外部引用 | 高风险，考虑删除或接入主链 |
| **IDLE-2** | 有引用，不进入主链 | 结构性闲置，评估迁移必要性 |
| **ACTIVE** | 已进入主链或被使用 | 正常状态，持续维护 |

**治理动作**：
1. 扫描闲置实现索引
2. 分类：ACTIVE/IDLE-2/IDLE-1
3. IDLE-1评估删除或接入
4. IDLE-2评估迁移到主链

### Phase 5: Runtime Audit生成

**生成步骤**：
1. 遍历所有导出符号
2. 判定impl_type（REAL/SUCCESS_STUB/UNIMPLEMENTED）
3. 统计覆盖率
4. 检测重复/遮挡
5. 输出JSON/TXT报告

## 治理检查清单

### 新增API前检查

- [ ] 是否已有handler/helper？（避免重复写）
- [ ] 是否进入FNID主链？
- [ ] 是否双路由？
- [ ] 是否只是helper？

### 导出层检查

- [ ] 是否存在同名导出被重复注册？
- [ ] 是否存在"REAL被STUB遮挡"？
- [ ] 是否存在"FNID已存在但export未is_fnid化"？
- [ ] 是否存在"同一DLL名在不同地址范围重复注册"？

### PR/变更检查

- [ ] 是否有明确bug证据？
- [ ] 是否最小修复？
- [ ] 是否回归验证？
- [ ] 是否对齐audit产物？

## 治理规则库

### 规则1: 禁止多套name→语义映射并行增长

**触发条件**：新增API时同时修改FNID表与loader层的get_*_func_id

**诊断信号**：存在`get_user32_func_id/get_kernel32_func_id`等硬编码映射函数

**根因**：索引事实源不唯一，导致"同名API的ID在两处漂移"

**修复规范**：
- name→FNID必须唯一来源于`win32fnmap/win32_fnid_table.*`
- loader不再扩展硬编码映射（仅允许作为过渡保留）

**验真信号**：新增/变更API时，只需更新FNID体系与导出接线；不需要再修改loader映射

### 规则2: 禁止解释型值作为长期对外导出资产

**触发条件**：对外导出返回`(void*)(uintptr_t)MNQ_*`等编码值

**诊断信号**：`exec_call.c`需要识别`0xFFFFFFFF00000000 | func_id`并解释执行

**根因**：把"迁移策略问题"当成"执行器实现问题"

**修复规范**：
- 对外默认导出应逐步迁移到主链（模式A：is_fnid+fnid）
- 旧链只作为兜底，且必须可被开关控制与审计识别

**验真信号**：默认路径下，runtime export-index中已实现API均为REAL

### 规则3: 禁止stub遮挡真实实现

**触发条件**：同名导出先注册为stub，后续真实实现不生效

**诊断信号**：runtime export-index显示`impl_type=="SUCCESS_STUB"`但存在handler/FNID

**根因**：注册顺序/去重逻辑导致REAL未能覆盖stub

**修复规范**：
- 以"SUCCESS_STUB→REAL允许覆盖"为裁决
- 在导出层把stub改为is_fnid+fnid，不在业务侧补逻辑

**验真信号**：export-index中该API从SUCCESS_STUB变为REAL

### 规则4: 禁止入口识别路径过多

**触发条件**：`exec_call.c`同时包含legacy、stub、sim func、FNID等多分支

**诊断信号**：新增兼容性需求时倾向继续堆叠分支

**根因**：把"迁移策略"当成"执行器实现"

**修复规范**：
- 新增入口识别必须先落入三种迁移模式（A/B/C）
- 程序特征补丁归档到`game_profiles/*`，不写RIP魔数

**验真信号**：audit产物反映为导出接线变化，而非exec_call分支数增加

## 迁移模式

### 模式A: 直连主链（推荐/终态）

**定义**：对外导出直接变为`is_fnid=1 + fnid=FNID_*`，并保证dispatch可达

**适用条件**：
- 已存在handler/helper
- 已存在FNID
- 已存在dispatch可达

**验收**：runtime export-index中`impl_type == "REAL"`

### 模式B: legacy内部转发主链（过渡）

**定义**：旧链入口保留，但内部最终转发到`win32_fn_dispatch(FNID_*)`

**目的**：降低"一刀切"风险，先汇聚语义，再切对外导出

**限制**：
- 只能用于"已存在实现"的汇聚
- 禁止借此新增API行为
- 旧链对外仍视为过渡

### 模式C: 真实缺口（只登记/不实现）

**定义**：缺少实现或缺少FNID/dispatch/wrapper，只能进入缺口清单

**产物**：缺口必须进入"gap"文档（A/B/C三类）

**禁止**：不得因为迁移KPI而把C类伪装为SUCCESS_STUB

## 工具使用

### 生成Runtime Audit

```bash
# 生成标准audit产物
python3 scripts/generate_audit.py \
  --output-dir ./audit \
  --format json,txt

# 输出：
# - export_index.runtime.json
# - export_tables.runtime.json
# - audit_report.runtime.txt
```

### 检查治理健康度

```bash
# 生成治理健康度报告
python3 scripts/governance_check.py \
  --audit-dir ./audit \
  --output report.md

# 检查项：
# - Layer A/B/C健康度
# - IDLE实现统计
# - 重复/遮挡检测
# - 覆盖率分析
```

### 闲置实现扫描

```bash
# 扫描闲置实现
python3 scripts/idle_scanner.py \
  --source-dir ./src \
  --audit-file ./audit/export_index.runtime.json \
  --output idle_report.md

# 输出IDLE-1/IDLE-2/ACTIVE分类
```

## 参考

- MNQVM API治理方法论
- 分层治理规范（Layer A/B/C）
- 唯一事实源原则
- Runtime Audit标准
- 函数数据库治理规范
