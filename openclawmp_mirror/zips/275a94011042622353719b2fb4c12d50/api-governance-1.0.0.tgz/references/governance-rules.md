# API治理规则库

## 规则1: 禁止多套name→语义映射并行增长

**触发条件**：新增API时同时修改FNID表与loader层的get_*_func_id

**诊断信号**：存在`get_user32_func_id/get_kernel32_func_id`等硬编码映射函数

**根因**：索引事实源不唯一，导致"同名API的ID在两处漂移"

**修复规范**：
- name→FNID必须唯一来源于`win32fnmap/win32_fnid_table.*`
- loader不再扩展硬编码映射（仅允许作为过渡保留）

**验真信号**：新增/变更API时，只需更新FNID体系与导出接线；不需要再修改loader映射

---

## 规则2: 禁止解释型值作为长期对外导出资产

**触发条件**：对外导出返回`(void*)(uintptr_t)MNQ_*`等编码值

**诊断信号**：`exec_call.c`需要识别`0xFFFFFFFF00000000 | func_id`并解释执行

**根因**：把"迁移策略问题"当成"执行器实现问题"

**修复规范**：
- 对外默认导出应逐步迁移到主链（模式A：is_fnid+fnid）
- 旧链只作为兜底，且必须可被开关控制与审计识别

**验真信号**：默认路径下，runtime export-index中已实现API均为REAL

---

## 规则3: 禁止stub遮挡真实实现

**触发条件**：同名导出先注册为stub，后续真实实现不生效

**诊断信号**：runtime export-index显示`impl_type=="SUCCESS_STUB"`但存在handler/FNID

**根因**：注册顺序/去重逻辑导致REAL未能覆盖stub

**修复规范**：
- 以"SUCCESS_STUB→REAL允许覆盖"为裁决
- 在导出层把stub改为is_fnid+fnid，不在业务侧补逻辑

**验真信号**：export-index中该API从SUCCESS_STUB变为REAL

---

## 规则4: 禁止入口识别路径过多

**触发条件**：`exec_call.c`同时包含legacy、stub、sim func、FNID等多分支

**诊断信号**：新增兼容性需求时倾向继续堆叠分支

**根因**：把"迁移策略"当成"执行器实现"

**修复规范**：
- 新增入口识别必须先落入三种迁移模式（A/B/C）
- 程序特征补丁归档到`game_profiles/*`，不写RIP魔数

**验真信号**：audit产物反映为导出接线变化，而非exec_call分支数增加

---

## 规则5: 禁止同一DLL在不同地址范围重复注册

**触发条件**：VirtualDLL registry中同名DLL出现多处不同base_va

**诊断信号**：`g_virtual_dlls`中同时出现多处`SHELL32.DLL`、`VERSION.DLL`

**根因**：历史演进中未统一canonical base

**修复规范**：
- 同名DLL只能有一个canonical base
- 历史地址必须迁移并提供兼容层映射

**验真信号**：GetProcAddress/IAT/模块识别结果一致

---

## 规则6: 禁止loader维护第二套name→ID映射

**触发条件**：loader层存在`get_user32_func_id/get_kernel32_func_id`

**诊断信号**：name→MNQ_ID的硬编码映射函数

**根因**：索引事实源不唯一

**修复规范**：
- name→FNID唯一来源于`win32fnmap/win32_fnid_table.*`
- loader不再扩展硬编码映射

**验真信号**：新增API只需更新FNID体系

---

## 规则7: 禁止把"为某程序"的patch固化进Core语义

**触发条件**：EA规则中使用`ctx->base_vaddr == 0x00400000ULL`等程序特征兜底

**诊断信号**：Core层存在程序特定的硬编码地址

**根因**：把"某个程序的经验修复"固化进通用规则

**修复规范**：
- 把兜底从"语义规则"下沉为"profile/启动期判定"
- 文档明确：何时允许、如何验收、何时移除

**验真信号**：Core层无程序特定硬编码

---

## 规则8: 禁止新增"仅通过legacy链对外暴露"的API

**触发条件**：新增Win32 API只走legacy链，不进FNID主链

**诊断信号**：新API只能通过MNQ_* syscall ID访问

**根因**：绕过主链治理

**修复规范**：
- 新增必须走FNID主链
- legacy链只保留为历史兼容

**验真信号**：新增API在export-index中为REAL
