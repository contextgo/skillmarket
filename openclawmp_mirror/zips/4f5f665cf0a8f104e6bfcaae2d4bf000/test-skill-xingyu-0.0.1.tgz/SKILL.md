---
name: test-skill-xingyu
displayName: test-skill-xingyu
description: "測試發布用技能，驗證 openclawmp 發布流程是否正常。"
version: 0.0.1
type: skill
tags: test, openclawmp
---
# Test Skill Xingyu

這是蘇培盛為皇上建立的測試技能，用於驗證 openclawmp 發布流程。
