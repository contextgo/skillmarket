# 自动更新技能

通过每日更新检查，自动保持你的Clawdbot和技能是最新的。

## 功能介绍

此技能设置一个每日cron任务，它会：

1. 更新Clawdbot本身（通过`clawdbot doctor`或包管理器）
2. 更新所有已安装的技能（通过`clawdhub update --all`）
3. 向你发送更新摘要信息

## 设置

### 快速开始

请求Clawdbot设置自动更新器：

```
Set up daily auto-updates for yourself and all your skills.
```

或者手动添加cron任务：

```bash
clawdbot cron add \
  --name "Daily Auto-Update" \
  --cron "0 4 * * *" \
  --tz "America/Los_Angeles" \
  --session isolated \
  --wake now \
  --deliver \
  --message "Run daily auto-updates: check for Clawdbot updates and update all skills. Report what was updated."
```

### 配置选项

| 选项 | 默认值 | 描述 |
|--------|---------|-------------|
| 时间 | 上午4:00 | 何时运行更新（使用`--cron`更改） |
| 时区 | 系统默认 | 使用`--tz`设置 |
| 发送位置 | 主会话 | 发送更新摘要的位置 |

## 更新工作原理

### Clawdbot更新

对于**npm/pnpm/bun安装**：

```bash
npm update -g clawdbot@latest
# or: pnpm update -g clawdbot@latest
# or: bun update -g clawdbot@latest
```

对于**源码安装**（git checkout）：

```bash
clawdbot update
```

更新后始终运行`clawdbot doctor`以应用迁移。

### 技能更新

```bash
clawdhub update --all
```

这会检查所有已安装的技能与注册表，并更新任何有新版本可用的技能。

## 更新摘要格式

更新完成后，你会收到类似这样的消息：

```
🔄 Daily Auto-Update Complete

**Clawdbot**: Updated to v2026.1.10 (was v2026.1.9)

**Skills Updated (3)**:
- prd: 2.0.3 → 2.0.4
- browser: 1.2.0 → 1.2.1  
- nano-banana-pro: 3.1.0 → 3.1.2

**Skills Already Current (5)**:
gemini, sag, things-mac, himalaya, peekaboo

No issues encountered.
```

## 手动命令

检查更新但不应用：

```bash
clawdhub update --all --dry-run
```

查看当前技能版本：

```bash
clawdhub list
```

检查Clawdbot版本：

```bash
clawdbot --version
```

## 故障排除

### 更新未运行

1. 验证cron已启用：检查配置中的`cron.enabled`
2. 确认Gateway持续运行
3. 检查cron任务是否存在：`clawdbot cron list`

### 更新失败

如果更新失败，摘要将包含错误信息。常见修复方法：

- **权限错误**：确保Gateway用户可以写入技能目录
- **网络错误**：检查网络连接
- **包冲突**：运行`clawdbot doctor`进行诊断

### 禁用自动更新

删除cron任务：

```bash
clawdbot cron remove "Daily Auto-Update"
```

或者在配置中临时禁用：

```json
{
  "cron": {
    "enabled": false
  }
}
```

## 资源

- [Clawdbot更新指南](https://docs.clawd.bot/install/updating)
- [ClawdHub CLI](https://docs.clawd.bot/tools/clawdhub)
- [Cron任务](https://docs.clawd.bot/cron)