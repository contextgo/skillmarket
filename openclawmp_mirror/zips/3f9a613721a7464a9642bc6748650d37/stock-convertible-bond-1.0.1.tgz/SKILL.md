# stock-convertible-bond Skill

## Description

可转债分析 Skill，基于集思录数据的可转债筛选、分析和监控。

## Capabilities

- 获取可转债实时数据
- 双低策略筛选
- 强赎提醒
- 下修提醒
- 溢价率分析

## Usage

```bash
# 获取可转债列表
python main.py list

# 双低排名（低价+低溢价）
python main.py double-low --top 20

# 筛选可转债
python main.py filter --price-max 130 --premium-max 30

# 强赎提醒
python main.py redemption

# 下修提醒
python main.py revise
```

## Configuration

```json
{
  "jisilu_cookie": "your_jisilu_cookie",
  "notify_enabled": false,
  "notify_webhook": ""
}
```

## Dependencies

- requests
- pandas
- beautifulsoup4

## License

MIT
