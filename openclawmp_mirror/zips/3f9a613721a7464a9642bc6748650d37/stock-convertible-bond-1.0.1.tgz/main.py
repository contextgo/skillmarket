#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
可转债分析工具
基于集思录数据的可转债筛选和分析
"""

import json
import os
from pathlib import Path

import pandas as pd
import requests
from bs4 import BeautifulSoup


class ConvertibleBondAnalyzer:
    """可转债分析器"""
    
    def __init__(self, config_path=None):
        """初始化分析器"""
        self.config = self._load_config(config_path)
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
        
    def _load_config(self, config_path):
        """加载配置"""
        if config_path is None:
            config_path = Path(__file__).parent / "config" / "config.json"
        
        if not os.path.exists(config_path):
            config_path = Path(__file__).parent / "config" / "sample.json"
        
        try:
            with open(config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    
    def get_bond_list(self):
        """
        获取可转债列表
        
        Returns:
            DataFrame: 可转债数据
        """
        try:
            # 使用 akshare 获取可转债数据
            import akshare as ak
            df = ak.bond_cb_jsl()
            return df
        except Exception as e:
            print(f"获取可转债数据失败: {e}")
            return None
    
    def double_low_rank(self, top=20):
        """
        双低排名（低价 + 低溢价）
        
        Args:
            top: 返回前N名
            
        Returns:
            DataFrame: 双低排名
        """
        df = self.get_bond_list()
        if df is None:
            return None
        
        try:
            # 计算双低值 = 价格 + 溢价率
            df['双低值'] = df['价格'] + df['溢价率']
            df_sorted = df.sort_values('双低值', ascending=True)
            
            columns = ['代码', '名称', '价格', '溢价率', '双低值', '到期收益率', '剩余年限']
            available_cols = [c for c in columns if c in df_sorted.columns]
            return df_sorted[available_cols].head(top)
        except Exception as e:
            print(f"双低排名计算失败: {e}")
            return None
    
    def filter_bonds(self, price_max=None, premium_max=None, yield_min=None):
        """
        筛选可转债
        
        Args:
            price_max: 最高价格
            premium_max: 最高溢价率
            yield_min: 最低到期收益率
            
        Returns:
            DataFrame: 筛选结果
        """
        df = self.get_bond_list()
        if df is None:
            return None
        
        try:
            filtered = df.copy()
            
            if price_max is not None:
                filtered = filtered[filtered['价格'] <= price_max]
            
            if premium_max is not None:
                filtered = filtered[filtered['溢价率'] <= premium_max]
            
            if yield_min is not None:
                filtered = filtered[filtered['到期收益率'] >= yield_min]
            
            columns = ['代码', '名称', '价格', '溢价率', '到期收益率', '剩余年限', '转股价值']
            available_cols = [c for c in columns if c in filtered.columns]
            return filtered[available_cols]
        except Exception as e:
            print(f"筛选失败: {e}")
            return None
    
    def check_redemption(self):
        """
        检查强赎提醒
        
        Returns:
            DataFrame: 强赎相关转债
        """
        df = self.get_bond_list()
        if df is None:
            return None
        
        try:
            # 筛选即将强赎或已公告强赎的转债
            # 通常转股价值 > 130 且满足强赎条件
            if '转股价值' in df.columns:
                redemption = df[df['转股价值'] > 130]
                columns = ['代码', '名称', '价格', '转股价值', '溢价率', '强赎状态']
                available_cols = [c for c in columns if c in redemption.columns]
                return redemption[available_cols]
        except Exception as e:
            print(f"强赎检查失败: {e}")
        return None
    
    def check_revise(self):
        """
        检查下修提醒
        
        Returns:
            DataFrame: 下修相关转债
        """
        df = self.get_bond_list()
        if df is None:
            return None
        
        try:
            # 筛选可能下修的转债（通常价格较低、溢价率较高）
            if '价格' in df.columns and '溢价率' in df.columns:
                revise_candidates = df[(df['价格'] < 110) & (df['溢价率'] > 50)]
                columns = ['代码', '名称', '价格', '溢价率', '到期收益率', '剩余年限']
                available_cols = [c for c in columns if c in revise_candidates.columns]
                return revise_candidates[available_cols]
        except Exception as e:
            print(f"下修检查失败: {e}")
        return None


def main():
    """CLI 入口"""
    import fire
    
    analyzer = ConvertibleBondAnalyzer()
    
    def list():
        """获取可转债列表"""
        result = analyzer.get_bond_list()
        if result is not None:
            print(result.head(20).to_string(index=False))
            print(f"\n共 {len(result)} 只可转债")
        else:
            print("获取可转债列表失败")
    
    def double_low(top=20):
        """双低排名"""
        result = analyzer.double_low_rank(top)
        if result is not None:
            print(result.to_string(index=False))
        else:
            print("双低排名计算失败")
    
    def filter(price_max=None, premium_max=None, yield_min=None):
        """筛选可转债"""
        result = analyzer.filter_bonds(price_max, premium_max, yield_min)
        if result is not None:
            print(result.to_string(index=False))
            print(f"\n共 {len(result)} 只符合条件的可转债")
        else:
            print("筛选失败")
    
    def redemption():
        """强赎提醒"""
        result = analyzer.check_redemption()
        if result is not None and not result.empty:
            print("=== 强赎提醒 ===")
            print(result.to_string(index=False))
        else:
            print("暂无强赎相关转债")
    
    def revise():
        """下修提醒"""
        result = analyzer.check_revise()
        if result is not None and not result.empty:
            print("=== 下修候选 ===")
            print(result.to_string(index=False))
        else:
            print("暂无下修候选转债")
    
    fire.Fire({
        "list": list,
        "double-low": double_low,
        "filter": filter,
        "redemption": redemption,
        "revise": revise,
    })


if __name__ == "__main__":
    main()
