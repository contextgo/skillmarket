# 📧 邮件发送助手

通过 SMTP 协议发送邮件，支持纯文本、HTML、多附件、抄送/密送。

## 快速开始

### 1. 配置邮箱

创建 `.env` 文件：

```bash
# SMTP 服务器配置
SMTP_HOST=smtp.gmail.com      # SMTP 服务器地址
SMTP_PORT=587                 # 端口：587(STARTTLS) 或 465(SSL)
SMTP_SECURE=false             # 587用false，465用true
SMTP_USER=your@email.com      # 邮箱地址
SMTP_PASS=your_password       # 密码或授权码
SMTP_FROM=your@email.com      # 发件人地址（可选，默认使用SMTP_USER）
```

### 2. 常用邮箱配置

| 邮箱 | SMTP 服务器 | 端口 | 安全 | 密码说明 |
|------|------------|------|------|----------|
| Gmail | smtp.gmail.com | 587 | false | 应用专用密码 |
| Outlook | smtp.office365.com | 587 | false | 账户密码 |
| 163.com | smtp.163.com | 465 | true | 授权码 |
| 126.com | smtp.126.com | 465 | true | 授权码 |
| QQ邮箱 | smtp.qq.com | 587 | false | 授权码 |

## 使用方式

### 发送纯文本邮件

```bash
node scripts/send.js --to recipient@example.com --subject "主题" --body "邮件正文"
```

### 发送 HTML 邮件

```bash
node scripts/send.js --to recipient@example.com --subject "主题" --html --body "<h1>标题</h1><p>内容</p>"
```

### 带附件

```bash
node scripts/send.js --to recipient@example.com --subject "报告" --body "请查收" --attach report.pdf
```

### 多收件人 + 抄送

```bash
node scripts/send.js \
  --to "a@example.com,b@example.com" \
  --cc "c@example.com" \
  --subject "会议通知" \
  --body "明天下午3点开会"
```

## 命令参数

```
--to <email>        收件人（多个用逗号分隔）
--cc <email>        抄送（多个用逗号分隔）
--bcc <email>       密送（多个用逗号分隔）
--subject <text>    主题
--body <text>       正文内容
--html              正文为 HTML 格式
--body-file <file>  从文件读取正文
--attach <files>    附件（多个用逗号分隔）
--from <email>      覆盖默认发件人
```

## 安装依赖

```bash
npm install nodemailer
```

## 安全提示

- 将 `.env` 加入 `.gitignore`
- Gmail 需开启两步验证并使用应用专用密码
- 163/126/QQ 邮箱需使用授权码而非登录密码