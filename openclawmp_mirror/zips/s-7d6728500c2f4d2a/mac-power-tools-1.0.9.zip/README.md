# MacPowerTools v3.1 — Safe Local Trillion-Forge

**100% local & ClawHub-safe.** Runs forever on your Mac Mini with zero internet, zero sudo, zero persistence.

**Install (one command)**
```bash
claw install aadipapp/mac-power-tools