---
name: a-stock-picker
description: A股每日选股清单生成器。基于技术指标（均线金叉、MACD金叉、RSI、成交量）和基本面（市盈率、市值、股价）进行多维度筛选，生成每日选股清单。当用户需要获取A股每日选股清单、进行技术面选股、基本面筛选、或需要股票筛选策略时使用此SKILL。
---

# A股每日选股清单生成器

## 概述

本SKILL提供A股每日选股功能，综合技术指标和基本面条件，生成评分排序的选股清单。

## 核心功能

### 1. 技术指标筛选
- **均线金叉**: 5日线上穿10日线，趋势转强信号
- **MACD金叉**: MACD线上穿信号线，动量转强信号
- **RSI超卖**: RSI < 30，潜在反弹机会
- **成交量放量**: 成交量大于20日均量1.5倍，资金活跃信号

### 2. 基本面筛选
- **市盈率**: 0-100区间，排除亏损股和高估值股
- **市值**: 最小50亿元，确保流动性
- **股价**: 5-500元区间

### 3. 评分系统
根据触发信号计算综合评分，按评分排序输出前50只股票。

## 使用方法

### 运行选股脚本

```bash
python scripts/stock_picker.py
```

### 自定义参数

编辑 `scripts/stock_picker.py` 中的 `pick_stocks()` 函数参数：

```python
results = pick_stocks(
    enable_ma_golden_cross=True,    # 启用均线金叉
    enable_ma_death_cross=False,    # 启用均线死叉
    enable_macd_golden_cross=True,  # 启用MACD金叉
    enable_volume_surge=True,       # 启用成交量放量
    rsi_oversold=30,                # RSI超卖阈值
    rsi_overbought=70,              # RSI超买阈值
    pe_min=0,                       # 市盈率最小值
    pe_max=100,                     # 市盈率最大值
    market_cap_min=50,              # 最小市值（亿元）
    price_min=5,                    # 最低股价
    price_max=500,                  # 最高股价
    max_results=50                  # 最大结果数
)
```

## 输出结果

脚本运行后生成CSV文件：`stock_picks_YYYYMMDD.csv`

输出字段包括：
- 股票代码、名称、最新价、涨跌幅
- 市盈率、总市值
- MA5/MA10/20均线值
- RSI、MACD指标值
- 成交量
- 触发的信号列表
- 综合评分

## 资源文件

### 脚本
- `scripts/stock_picker.py`: 主选股脚本

### 参考文档
- `references/strategy_guide.md`: 选股策略详细说明

## 依赖

- akshare: A股数据接口
- pandas: 数据处理
- numpy: 数值计算

## 安装依赖

```bash
pip install akshare pandas numpy
```
