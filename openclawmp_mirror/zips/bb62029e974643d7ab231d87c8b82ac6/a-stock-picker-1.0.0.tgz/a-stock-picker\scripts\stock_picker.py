#!/usr/bin/env python3
"""
A股每日选股清单生成器
基于技术指标和基本面筛选
"""

import akshare as ak
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json

def get_stock_list():
    """获取A股股票列表"""
    try:
        stock_df = ak.stock_zh_a_spot_em()
        return stock_df
    except Exception as e:
        print(f"获取股票列表失败: {e}")
        return pd.DataFrame()

def get_stock_history(code, days=60):
    """获取股票历史数据"""
    try:
        # 转换股票代码格式
        if code.startswith('6'):
            code = f"sh{code}"
        else:
            code = f"sz{code}"
        
        df = ak.stock_zh_a_hist(symbol=code, period="daily", start_date=(datetime.now() - timedelta(days=days)).strftime("%Y%m%d"), end_date=datetime.now().strftime("%Y%m%d"), adjust="qfq")
        return df
    except Exception as e:
        return pd.DataFrame()

def calculate_ma(df, periods=[5, 10, 20, 60]):
    """计算移动平均线"""
    for period in periods:
        df[f'MA{period}'] = df['收盘'].rolling(window=period).mean()
    return df

def calculate_macd(df, fast=12, slow=26, signal=9):
    """计算MACD指标"""
    ema_fast = df['收盘'].ewm(span=fast, adjust=False).mean()
    ema_slow = df['收盘'].ewm(span=slow, adjust=False).mean()
    df['MACD'] = ema_fast - ema_slow
    df['MACD_Signal'] = df['MACD'].ewm(span=signal, adjust=False).mean()
    df['MACD_Hist'] = df['MACD'] - df['MACD_Signal']
    return df

def calculate_rsi(df, period=14):
    """计算RSI指标"""
    delta = df['收盘'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
    rs = gain / loss
    df['RSI'] = 100 - (100 / (1 + rs))
    return df

def check_ma_golden_cross(df):
    """检查均线金叉"""
    if len(df) < 2:
        return False
    # 5日线上穿10日线
    return df['MA5'].iloc[-2] <= df['MA10'].iloc[-2] and df['MA5'].iloc[-1] > df['MA10'].iloc[-1]

def check_ma_death_cross(df):
    """检查均线死叉"""
    if len(df) < 2:
        return False
    return df['MA5'].iloc[-2] >= df['MA10'].iloc[-2] and df['MA5'].iloc[-1] < df['MA10'].iloc[-1]

def check_macd_golden_cross(df):
    """检查MACD金叉"""
    if len(df) < 2:
        return False
    return df['MACD'].iloc[-2] <= df['MACD_Signal'].iloc[-2] and df['MACD'].iloc[-1] > df['MACD_Signal'].iloc[-1]

def check_volume_surge(df, threshold=1.5):
    """检查成交量放量"""
    if len(df) < 20:
        return False
    avg_volume = df['成交量'].iloc[-20:-1].mean()
    return df['成交量'].iloc[-1] > avg_volume * threshold

def check_rsi_condition(df, oversold=30, overbought=70):
    """检查RSI条件"""
    if 'RSI' not in df.columns or len(df) < 1:
        return None
    rsi = df['RSI'].iloc[-1]
    if rsi < oversold:
        return "超卖"
    elif rsi > overbought:
        return "超买"
    return None

def filter_by_fundamentals(df, pe_min=0, pe_max=100, roe_min=5, market_cap_min=50):
    """基本面筛选"""
    # 市盈率筛选
    if '市盈率-动态' in df.columns:
        df = df[(df['市盈率-动态'] >= pe_min) & (df['市盈率-动态'] <= pe_max)]
    
    # 市值筛选（亿元）
    if '总市值' in df.columns:
        df = df[df['总市值'] >= market_cap_min * 100000000]
    
    return df

def pick_stocks(
    enable_ma_golden_cross=True,
    enable_ma_death_cross=False,
    enable_macd_golden_cross=True,
    enable_volume_surge=True,
    rsi_oversold=30,
    rsi_overbought=70,
    pe_min=0,
    pe_max=100,
    roe_min=5,
    market_cap_min=50,
    price_min=5,
    price_max=500,
    max_results=50
):
    """
    选股主函数
    
    参数:
    - enable_ma_golden_cross: 启用均线金叉筛选
    - enable_ma_death_cross: 启用均线死叉筛选
    - enable_macd_golden_cross: 启用MACD金叉筛选
    - enable_volume_surge: 启用成交量放量筛选
    - rsi_oversold: RSI超卖阈值
    - rsi_overbought: RSI超买阈值
    - pe_min: 市盈率最小值
    - pe_max: 市盈率最大值
    - roe_min: ROE最低要求
    - market_cap_min: 最小市值（亿元）
    - price_min: 最低股价
    - price_max: 最高股价
    - max_results: 最大返回结果数
    """
    
    print("正在获取A股股票列表...")
    stock_list = get_stock_list()
    
    if stock_list.empty:
        return pd.DataFrame()
    
    # 基本面筛选
    print("正在进行基本面筛选...")
    if '最新价' in stock_list.columns:
        stock_list = stock_list[(stock_list['最新价'] >= price_min) & (stock_list['最新价'] <= price_max)]
    
    stock_list = filter_by_fundamentals(stock_list, pe_min, pe_max, roe_min, market_cap_min)
    
    results = []
    total = len(stock_list)
    
    print(f"共有 {total} 只股票待分析...")
    
    for idx, row in stock_list.iterrows():
        code = row['代码']
        name = row['名称']
        
        if idx % 100 == 0:
            print(f"进度: {idx}/{total}")
        
        # 获取历史数据
        hist_df = get_stock_history(code)
        if hist_df.empty or len(hist_df) < 30:
            continue
        
        # 计算技术指标
        hist_df = calculate_ma(hist_df)
        hist_df = calculate_macd(hist_df)
        hist_df = calculate_rsi(hist_df)
        
        # 信号检测
        signals = []
        score = 0
        
        if enable_ma_golden_cross and check_ma_golden_cross(hist_df):
            signals.append("均线金叉")
            score += 25
        
        if enable_ma_death_cross and check_ma_death_cross(hist_df):
            signals.append("均线死叉")
            score += 10
        
        if enable_macd_golden_cross and check_macd_golden_cross(hist_df):
            signals.append("MACD金叉")
            score += 30
        
        if enable_volume_surge and check_volume_surge(hist_df):
            signals.append("成交量放量")
            score += 20
        
        rsi_status = check_rsi_condition(hist_df, rsi_oversold, rsi_overbought)
        if rsi_status == "超卖":
            signals.append("RSI超卖")
            score += 25
        elif rsi_status == "超买":
            signals.append("RSI超买")
            score -= 10
        
        # 只保留有信号的股票
        if len(signals) > 0:
            latest = hist_df.iloc[-1]
            result = {
                '代码': code,
                '名称': name,
                '最新价': round(latest['收盘'], 2),
                '涨跌幅': round(row.get('涨跌幅', 0), 2),
                '市盈率': round(row.get('市盈率-动态', 0), 2),
                '总市值': round(row.get('总市值', 0) / 100000000, 2),
                'MA5': round(latest['MA5'], 2),
                'MA10': round(latest['MA10'], 2),
                'MA20': round(latest['MA20'], 2),
                'RSI': round(latest['RSI'], 2),
                'MACD': round(latest['MACD'], 4),
                '成交量': int(latest['成交量']),
                '信号': '、'.join(signals),
                '评分': score
            }
            results.append(result)
    
    # 按评分排序
    results_df = pd.DataFrame(results)
    if not results_df.empty:
        results_df = results_df.sort_values('评分', ascending=False).head(max_results)
    
    return results_df

def main():
    """主函数 - 默认配置"""
    print("=" * 60)
    print("A股每日选股清单生成器")
    print("=" * 60)
    
    results = pick_stocks(
        enable_ma_golden_cross=True,
        enable_ma_death_cross=False,
        enable_macd_golden_cross=True,
        enable_volume_surge=True,
        rsi_oversold=30,
        rsi_overbought=70,
        pe_min=0,
        pe_max=100,
        roe_min=5,
        market_cap_min=50,
        price_min=5,
        price_max=500,
        max_results=50
    )
    
    if results.empty:
        print("未找到符合条件的股票")
    else:
        print(f"\n共选出 {len(results)} 只股票:")
        print("-" * 60)
        print(results.to_string(index=False))
        
        # 保存结果
        output_file = f"stock_picks_{datetime.now().strftime('%Y%m%d')}.csv"
        results.to_csv(output_file, index=False, encoding='utf-8-sig')
        print(f"\n结果已保存至: {output_file}")

if __name__ == "__main__":
    main()
