---
name: hello-world-skill
description: 'A simple hello world skill for testing openclawmp publishing'
version: 1.0.0
---

# Hello World Skill

This is a test skill for demonstrating openclawmp publishing workflow.

## Usage

Simply ask the agent to say hello!

## Example

```
User: Say hello
Agent: Hello, World!
```


Published by device auth.
