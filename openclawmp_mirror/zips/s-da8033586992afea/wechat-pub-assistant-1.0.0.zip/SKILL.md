---
name: wechat-pub-assistant
description: 微信公众号运营助手 - 选题推荐、AI写作、排版美化、定时发布、数据分析
metadata:
  {
    "openclaw": {
      "requires": {
        "apis": ["wechat-mp-api"],
        "bins": []
      },
      "install": [
        {
          "id": "manual",
          "kind": "manual",
          "label": "手动安装"
        }
      ]
    }
  }
---

# 微信公众号运营助手

帮你高效运营微信公众号，从选题到发布全流程自动化。

## 功能一览

| 功能 | 说明 |
|------|------|
| 🎯 选题推荐 | 根据热点/领域/竞品推荐选题 |
| ✍️ AI 写作 | 根据主题生成文章（支持多种风格） |
| 🎨 智能排版 | 一键排版，生成封面图 |
| ⏰ 定时发布 | 预约发布时间 |
| 📊 数据分析 | 阅读量、点赞、留言分析 |

---

## 快速开始

### 1. 配置微信公众平台 API

在微信公众平台获取 AppID 和 AppSecret：

1. 登录 https://mp.weixin.qq.com/
2. 设置 → 开发设置 → 公众号开发者ID
3. 获取 AppID 和 AppSecret

```bash
# 设置环境变量
export WECHAT_APP_ID=your_appid
export WECHAT_APP_SECRET=your_secret
```

### 2. 基本命令

```bash
# 选题推荐
wechat-pub topic --field 科技

# AI 写作
wechat-pub write --title "AI 时代的机遇与挑战" --style 深度分析

# 智能排版
wechat-pub format --content "文章内容..." --theme 简约

# 生成封面
wechat-pub cover --title "AI 时代" --style 科技

# 发布文章
wechat-pub publish --title "标题" --content "正文" --cover "封面图URL"

# 定时发布
wechat-pub schedule --title "标题" --content "正文" --time "2024-01-15 10:00"

# 数据分析
wechat-pub stats --days 7
```

---

## 详细功能

### 🎯 选题推荐

```bash
# 根据领域推荐选题
wechat-pub topic --field 美食 --count 10

# 根据热点话题推荐
wechat-pub topic --hot --count 5

# 竞品分析推荐
wechat-pub topic --competitor 科技类大号 --count 5
```

**输出示例：**
```
📋 推荐选题：
1. 2024年最值得关注的科技趋势
2. AI 如何改变我们的工作方式
3. 5个提高效率的 AI 工具推荐
4. ...
```

### ✍️ AI 写作

```bash
# 深度分析风格
wechat-pub write --title "AI 时代的机遇" --style 深度分析 --length 2000

# 轻松幽默风格
wechat-pub write --title "996 的正确打开方式" --style 幽默 --length 1500

# 教程干货风格
wechat-pub write --title "3步学会 AI 写作" --style 教程 --length 1800

# 情感故事风格
wechat-pub write --title "北漂 5 年的感悟" --style 情感 --length 1200
```

**支持风格：**
- 深度分析 - 专业、详实、有数据
- 轻松幽默 - 口语化、有趣、接地气
- 教程干货 - 结构化、步骤清晰
- 情感故事 - 故事性强、有共鸣
- 新闻资讯 - 客观、快速、简洁

### 🎨 智能排版

```bash
# 简约主题
wechat-pub format --content "文章内容..." --theme 简约

# 科技主题
wechat-pub format --content "文章内容..." --theme 科技

# 文艺主题
wechat-pub format --content "文章内容..." --theme 文艺

# 节日主题
wechat-pub format --content "文章内容..." --theme 春节
```

**排版效果：**
- 标题样式美化
- 首行缩进
- 段落间距优化
- 重点内容高亮
- 插入分隔线
- 二维码/关注语

### 🎬 生成封面

```bash
# 文字封面
wechat-pub cover --title "AI 时代" --style 科技

# AI 生成图片封面
wechat-pub cover --title "AI 时代" --style 科技 --image --prompt "未来科技感"

# 从模板选择
wechat-pub cover --title "AI 时代" --template 3
```

### 📤 发布文章

```bash
# 直接发布
wechat-pub publish \
  --title "AI 时代的机遇与挑战" \
  --content "正文内容..." \
  --cover "https://example.com/cover.jpg" \
  --digest "摘要..."

# 仅生成 HTML（用于预览）
wechat-pub preview --content "正文..."
```

### ⏰ 定时发布

```bash
# 预约发布
wechat-pub schedule \
  --title "标题" \
  --content "正文" \
  --time "2024-01-15 10:00:00"

# 查看定时任务
wechat-pub schedule --list

# 取消定时
wechat-pub schedule --cancel task-id
```

### 📊 数据分析

```bash
# 7天数据概览
wechat-pub stats --days 7

# 单篇文章数据
wechat-pub stats --article-id xxx

# 粉丝分析
wechat-pub stats --fans

# 导出报表
wechat-pub stats --export --format csv
```

**输出示例：**
```
📊 数据概览（近7天）
├── 📖 总阅读量：12,345
│   ├── 昨日：1,890
│   └── 环比：+15.2%
├── ❤️ 点赞数：567
├── 💬 留言数：89
├── 👥 新增粉丝：234
└── 🔄 分享数：123
```

---

## 配置项

### 环境变量

| 变量 | 必填 | 说明 |
|------|------|------|
| WECHAT_APP_ID | ✅ | 公众号 AppID |
| WECHAT_APP_SECRET | ✅ | 公众号 AppSecret |
| WECHAT_ACCESS_TOKEN | ❌ | 缓存的 access_token |
| WECHAT_TEMPLATE_ID | ❌ | 通知模板 ID |

### 配置文件

`~/.wechat-pub/config.json`：

```json
{
  "app_id": "your_appid",
  "app_secret": "your_secret",
  "default_style": "简约",
  "auto_publish": false,
  "notification": {
    "template_id": "xxx",
    "user": "your_openid"
  },
  "ai": {
    "provider": "openai",
    "model": "gpt-4",
    "api_key": "sk-xxx"
  }
}
```

---

## 工作流示例

### 完整发布流程

```bash
# 1. 获取选题推荐
wechat-pub topic --field 科技 --count 5

# 2. 选择选题开始写作
wechat-pub write --title "AI 如何改变我们的生活" --style 深度分析

# 3. 智能排版
wechat-pub format --content "$(cat article.md)" --theme 科技

# 4. 生成封面
wechat-pub cover --title "AI 如何改变我们的生活" --style 科技

# 5. 发布
wechat-pub publish --title "AI 如何改变我们的生活" --content "$(cat formatted.md)"
```

### 批量运营流程

```bash
# 每天早上：获取热点选题
wechat-pub topic --hot --count 10

# 下午：批量生成文章
for topic in $(wechat-pub topic --hot --count 5); do
  wechat-pub write --title "$topic" --style 教程
done

# 晚上：数据分析
wechat-pub stats --days 7
```

---

## 注意事项

1. **微信 API 限制**：每天群发次数有限，注意配额
2. **内容合规**：避免违规关键词，遵守平台规则
3. **access_token 缓存**：有效期 2 小时，工具会自动刷新
4. **图片上传**：需要先上传到微信图床获取 URL

---

## 依赖

- Python 3.8+
- openai SDK（AI 写作）
- wechatpy（微信 API）
- pillow（封面生成）

## 后续规划

- [ ] 视频号联动
- [ ] 多平台同步（知乎、B站）
- [ ] SEO 优化建议
- [ ] AI 对话式写作（续写、改写）
