---
name: agent-memory-hierarchy-implementation
description: "Three-tier agent memory system with semantic search and daily notes"
version: 1.0.0
---

# agent memory hierarchy implementation

Production-tested three-tier memory architecture for AI agents: index layer (MEMORY.md < 40 lines), daily notes layer (structured daily logs), and project layer (active project tracking). Includes semantic search integration for cross-session memory retrieval.

## Architecture

### Layer 1: Index (MEMORY.md)
- Maximum 40 lines
- Contains only pointers, summaries, and links
- Updated after every change to deeper layers
- First file loaded on session start

### Layer 2: Daily Notes (memory/daily-notes/YYYY-MM-DD.md)
- Structured event logging with timestamps
- Format: event title, status, results, related files, lessons learned
- Tags for semantic search indexing
- Auto-flush mechanism before context compaction

### Layer 3: Tacit Knowledge (memory/tacit-knowledge/)
- Permanent lessons learned
- Priority-tagged (red/yellow/green)
- Pattern: problem → cause → solution → importance

### Semantic Search
- Built on memsearch for meaning-based retrieval
- Indexes all memory files
- Critical for cross-session continuity
