# Memory System

统一记忆管理技能。五层架构，一个入口，替代(task-priority-zero+5个冗余记忆技能)。

## 五层架构

### L1 — MEMORY.md
精选长期记忆，跨 session 唯一可信来源。五节：身份 / 技术栈 / 已安装资产 / 关键决策 / 偏好。

### L2 — Daily Memory
`memory/YYYY-MM-DD.md` 每日流水，不做过滤。500 行上限，归档到 `memory/archive/YYYY-MM/`。

### L3 — Reference
`reference/*.md` 事实性知识（联系人、仓库、基础设施、产品），不含主观意见。

### L4 — Vector Search（可选）
基于 ChromaDB + MiniLM-L6-v2 的语义检索，覆盖 L1-L3。重建与索引命令直接从 persistent-memory 继承。

### L5 — Knowledge Graph（可选）
NetworkX 有向图 + WAL 追加日志。节点：实体；边：关系与置信度；时间维度支持回溯/前瞻。

## Item Anchors

```markdown
## LRN-YYYYMMDD-NNN: 简短标题
## ERR-YYYYMMDD-NNN: 错误+修复
## DEC-YYYYMMDD-NNN: 决策
## OBS-YYYYMMDD-NNN: 观察
```

经过 2+ session 验证的锚点晋升 MEMORY.md。

## Session Startup Protocol

`SOUL.md → USER.md → MEMORY.md → 今日 → 昨日`

上下文窗口收紧时优先 `memory_search` 而非全文加载。

## 与 task-priority-zero 的关系

- task-priority-zero 管执行 → memory-system 管记忆
- 冲突时 task-priority-zero 赢执行，memory-system 赢记忆
