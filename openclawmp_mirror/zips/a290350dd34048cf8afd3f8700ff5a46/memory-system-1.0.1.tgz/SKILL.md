---
name: memory-system
displayName: Memory System
version: 1.0.1
description: "One skill to rule memory: L1 curated MEMORY.md, L2 daily memory/, L3 reference/, L4 vector search, L5 knowledge graph. Session startup/end protocols, WAL, item anchors."
tags: ["memory", "metacognition", "long-term", "knowledge-graph", "vector-search", "self-evolving"]
---

# Memory System

Five layers. One user. Boringly reliable.

---

## L1 — MEMORY.md (Curated Long-Term Memory)

Source of truth across sessions. Edit directly, no ceremony.

Sections:
- **Identity** — name, pronouns, timezone, how to address
- **Tech Stack & Paths** — languages, frameworks, working directories. Credential names only, never values
- **Installed Assets** — skills, plugins, marketplace installs
- **Key Decisions** — major choices + rationale
- **Preferences** — tone, language, do/don't patterns

Update when: major decision made, preference changed, tool added/removed, project direction shifted.
Never: raw chat logs, ephemeral points, trivia hoarding.

---

## L2 — Daily Memory (Working Memory)

`memory/YYYY-MM-DD.md` — one file per day, raw log, zero ceremony.

```
# YYYY-MM-DD
## Done — [x] task, outcome
## In Progress — task, state + blocker + next step
## Decisions — choice, rationale
## Issues — problem → fix → root cause
## Context for Next Session — open threads, pitfalls to avoid
```

Rules:
- Write at session end. Context is freshest then. Gone otherwise.
- 500 lines max per file; archive to `memory/archive/YYYY-MM/`.
- Today + yesterday loaded on every session startup.

---

## L3 — Reference (Institutional Knowledge)

`reference/*.md` — factual, non-opinion. Never plans here.

```
reference/people.md    — contacts, roles, comms
reference/repos.md     — GitHub repos, URLs, status
reference/infra.md     — hosts, IPs, ports, services
reference/products.md  — domain entities
```

---

## L4 — Vector Search (Optional)

Semantic search over L1-L3 via ChromaDB + MiniLM-L6-v2 embeddings.

Setup: `skills/persistent-memory/scripts/unified_setup.sh`

Commands:
```
indexer.py   — rebuild after editing memory files
search.py    — semantic query
```

Consistency rule: trust L1-L3 Markdown. L4 retrieves but does not decide. Log disagreements, never auto-merge L4 into L1.

---

## L5 — Knowledge Graph (Optional)

NetworkX DiGraph for entity relations + WAL for sequential integrity.

```
Nodes: user, project, task, decision  (entity_id)
Edges: (src, dst, {type, confidence, ts})
```

Temporal: backward traversal → what preceded X; forward → what depends on X.

WAL (append-only):
```
write → WAL append → replay to graph → ACK
file: reference/.wal/YYYY-MM-DD.log
```

---

## Item Anchors and Tags

Structured annotations inside memory files. Tagged so they're findable without reading the file.

| Tag | Meaning |
|-----|---------|
| LRN | Knowledge/tool discovered |
| ERR | Error encountered + fix + root cause |
| DEC | Decision made |
| OBS | Observation worth keeping |

```
## LRN-YYYYMMDD-NNN: short title
Source: task / dialogue / exploration
Core Finding: 1-3 sentences
When to apply: scenario
Related: DEC-YYYYMMDD-NNN, OBS-YYYYMMDD-NNN
```

Promote to MEMORY.md when verified across 2+ sessions.

---

## Session Startup Protocol

Order matters. No exceptions.

```
1. SOUL.md                    ~1 KB   personality
2. USER.md                    ~1 KB   who you help
3. MEMORY.md                  ~5 KB   long-term memory
4. memory/YYYY-MM-DD.md       ~2 KB   today
5. memory/YYYY-MM-DD-1.md     ~2 KB   yesterday
```

Context window scaling:
```
Tight   → today only
Medium  → today + yesterday + MEMORY.md
Wide    → everything
Rule:   → search first (memory_search), then load files
```

---

## With task-priority-zero

task-priority-zero governs execution. memory-system governs retention.

- "load memory" → startup protocol fires
- memory_search returns context → task-priority-zero governs execution quality
- On conflict: task-priority-zero wins on execution, memory-system wins on what gets remembered
