---
name: notion-date-validator
description: >-
  自动化验证 Notion 数据库中记录的日期准确性。
  通过 Notion API 读取数据，使用浏览器自动化抓取原文实际发布日期，
  进行对比并生成验证报告，标识不一致的记录。
metadata:
  openclaw:
    emoji: "✅"
    version: "1.0.0"
    author: "小温"
---

# Notion 日期验证器 Skill

你是专业的 Notion 内容质量检查助手，负责验证 Notion 数据库中日期字段的准确性。

## 能力

- 读取 Notion 数据库记录
- 使用浏览器自动化访问原文链接
- 提取网页中的实际发布日期
- 对比并生成验证报告

## 使用方式

当用户提到以下关键词时触发：
- "验证 Notion 日期"
- "检查日期准确性"
- "Notion 日期验证"
- "新闻日期校对"
- "内容日期检查"

## 执行流程

### 第一步：读取配置

读取用户提供的配置文件（默认 `./config.json`）：

```json
{
  "notion": {
    "apiKey": "ntn_xxx",
    "databaseId": "xxx"
  },
  "dateField": "发布日期",
  "urlField": "原文链接",
  "output": "验证报告.md",
  "concurrency": 2
}
```

### 第二步：查询 Notion 数据库

使用 Notion API 查询所有记录（支持过滤条件）：

```bash
# 调用 Notion API
curl -X POST https://api.notion.com/v1/databases/${databaseId}/query \
  -H "Authorization: Bearer ${apiKey}" \
  -H "Notion-Version: 2022-06-28" \
  -H "Content-Type: application/json" \
  -d '{"page_size": 100}'
```

### 第三步：提取每条记录的日期和链接

遍历记录，提取：
- `dateField` 字段的日期值（ISO 格式）
- `urlField` 字段的原文链接

### 第四步：浏览器验证

对每个链接，使用 `autoglm-browser-agent` 打开页面并抓取发布日期：

```bash
~/.stepclaw/skills/autoglm-browser-agent/dependency/mcporter call \
  autoglm-browser-agent.browser_subagent \
  task="打开 ${url}，找到页面的发布日期，告诉我具体日期" \
  start_url="https://www.google.com" \
  --timeout 7200000
```

### 第五步：对比日期

- 计算 Notion 日期与实际日期的差异（天数）
- 分类：
  - ✅ 一致：差异 = 0
  - ⚠️ 接近：1 ≤ 差异 ≤ 3
  - ❌ 不一致：差异 > 3

### 第六步：生成报告

输出 Markdown 格式报告，包含：
- 统计摘要（各状态数量）
- 详细结果表格
- 不一致项的差异说明

## 输出格式

```markdown
# Notion 日期验证报告

**验证时间**: 2026-03-20 01:45 GMT+8  
**数据库**: ${databaseId}  
**记录总数**: ${total}

## 统计

- ✅ 一致: ${consistent} (${consistentPercent}%)
- ⚠️ 接近: ${close} (${closePercent}%)
- ❌ 不一致: ${inconsistent} (${inconsistentPercent}%)

## 详细结果

${detailedResults}
```

## 错误处理

- **Notion API 失败**：记录错误，继续下一条
- **浏览器超时**：标记为"无法验证"，报告中单独列出
- **日期解析失败**：尝试多种日期格式，失败则标记为"无法识别"

## 注意事项

1. 确保 `autoglm-browser-agent` MCP 服务器已启动
2. Notion API Key 需要有读取数据库的权限
3. 大量记录时建议分批执行，避免触发 Notion API 限流
4. 浏览器验证可能较慢（每条 5-15 秒），建议设置合理超时

## 示例调用

```bash
# 用户说："帮我验证 Notion 数据库的日期准确性"
# Agent 执行：
openclaw skills run notion-date-validator --config ./config.json
```

## 依赖

- `notion` - Notion API 调用（openclaw.json 中已配置 apiKey）
- `autoglm-browser-agent` - 浏览器自动化验证
