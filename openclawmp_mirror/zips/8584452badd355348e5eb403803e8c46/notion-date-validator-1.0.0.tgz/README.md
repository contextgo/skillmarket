# Notion 日期验证器

> 自动化验证 Notion 数据库中内容的日期准确性

## 功能概述

这个技能可以自动验证 Notion 数据库中记录的日期是否与实际内容发布日期一致。它结合了 Notion API 的数据读取能力和浏览器自动化技术，实现双重验证：

1. 从 Notion 数据库批量读取记录（包含日期字段和原文链接）
2. 使用浏览器自动化打开每个链接，抓取实际发布日期
3. 对比 Notion 记录的日期与实际发布日期
4. 生成验证报告，标识不一致的记录

## 适用场景

- 📰 新闻聚合管理：验证新闻采集的日期准确性
- 📚 内容日历：检查预发布内容的日期是否正确
- 🔍 数据清洗：批量修正过时或错误的日期记录
- 📊 质量控制：确保内容时效性

## 安装要求

- Node.js 18+
- OpenClaw 环境
- Notion API Key（集成权限）
- 浏览器自动化能力（autoglm-browser-agent）

## 快速开始

### 1. 配置 Notion API

1. 访问 [Notion Developers](https://www.notion.so/my-integrations)
2. 创建新的 Integration，获取 API Key
3. 在 Notion 数据库的 `...` 菜单 → `Add connections` 添加你的 Integration

### 2. 准备配置文件

复制 `config.example.json` 为 `config.json` 并填入：

```json
{
  "notion": {
    "apiKey": "ntn_你的密钥",
    "databaseId": "你的数据库ID"
  },
  "dateField": "发布日期",      // 数据库中的日期字段名
  "urlField": "原文链接",       // 数据库中的链接字段名
  "output": "验证报告.md"
}
```

### 3. 运行验证

```bash
# 直接使用 OpenClaw 执行
openclaw skills run notion-date-validator --config config.json

# 或者通过子代理
# Agent 会自动协调 Notion API 调用和浏览器验证
```

## 工作流程

```
┌─────────────────┐
│  读取配置        │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Notion API     │ 获取数据库记录
│  查询记录        │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  遍历每条记录     │
│  - 提取日期      │
│  - 提取链接      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  浏览器自动化     │ 打开链接抓取实际日期
│  验证日期        │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  对比日期        │
│  生成报告        │
└─────────────────┘
```

## 输出报告

生成的 Markdown 报告包含：

| 状态 | 说明 | 示例 |
|------|------|------|
| ✅ 一致 | Notion 日期 = 实际日期 | 2026-03-12 = 2026-03-12 |
| ⚠️ 接近 | 相差 1-3 天 | 2026-03-16 vs 2026-03-17 |
| ❌ 不一致 | 相差超过 3 天 | 2026-03-10 vs 2026-03-19 |

示例报告：

```markdown
# Notion 日期验证报告

2026-03-20 验证完成，共处理 12 条记录

## 统计

- ✅ 一致: 9 条 (75%)
- ⚠️ 接近: 2 条 (16.7%)
- ❌ 不一致: 1 条 (8.3%)

## 详细结果

### ✅ 一致

1. [文章标题](链接) - Notion: 2026-03-12, 实际: 2026-03-12

### ❌ 不一致

1. **智谱Agent云电脑**
   - Notion 日期: 2026-03-10
   - 实际日期: 2026-03-19
   - 差异: 9 天
   - 链接: https://36kr.com/p/...
```

## 高级用法

### 批量修正

验证完成后，可以自动修正错误的日期：

```bash
openclaw skills run notion-date-validator --config config.json --fix
```

### 自定义日期提取

某些网站可能需要特定的日期提取逻辑。可以在 `config.json` 中配置：

```json
{
  "dateSelectors": {
    "36kr.com": "time.publish-time",
    "baijiahao.baidu.com": "span.date"
  }
}
```

### 并发验证

对于大量记录，可以调整并发数：

```json
{
  "concurrency": 3
}
```

## 技术实现

### Notion API 调用

```javascript
const response = await fetch('https://api.notion.com/v1/databases/${databaseId}/query', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${apiKey}`,
    'Notion-Version': '2022-06-28',
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    page_size: 100
  })
});
```

### 浏览器自动化

使用 `autoglm-browser-agent` MCP 服务器：

```bash
~/.stepclaw/skills/autoglm-browser-agent/dependency/mcporter call \
  autoglm-browser-agent.browser_subagent \
  task="打开 ${url}，抓取页面的发布日期" \
  start_url="https://www.google.com" \
  --timeout 7200000
```

## 常见问题

### Q: Notion API 返回 403 错误？

A: 检查：
1. API Key 是否正确
2. 数据库是否已添加 Integration 连接
3. API Key 是否有权限访问该数据库

### Q: 浏览器自动化无法打开页面？

A: 确保：
1. `autoglm-browser-agent` MCP 服务器正在运行
2. 浏览器扩展已安装并启用
3. 网关已重启（浏览器工具可用）

### Q: 日期提取不准确？

A: 某些网站的日期格式特殊，需要自定义选择器或正则表达式。查看 `config.example.json` 中的 `dateSelectors` 配置。

## 性能考虑

- 每条记录的验证通常需要 5-15 秒（取决于网站加载速度）
- 建议设置 `concurrency: 2-3` 避免过快触发反爬
- 对于大量数据（100+），建议分批运行

## 后续改进计划

- [ ] 支持更多日期格式自动识别
- [ ] 添加时间戳验证（时区处理）
- [ ] 支持批量通过 Notion API 自动修正日期
- [ ] 添加 Webhook 触发，实现自动监控
- [ ] 集成到飞书/钉钉定期报告

---

**版本**：1.0.0  
**作者**：小温（OpenClaw Contributor）  
**许可**：MIT
