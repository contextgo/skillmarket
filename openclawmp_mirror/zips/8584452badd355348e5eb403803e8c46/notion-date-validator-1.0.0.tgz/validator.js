#!/usr/bin/env node

/**
 * Notion 日期验证器
 *
 * 用法：
 *   node validator.js --config config.json
 *
 * 功能：
 *  1. 从 Notion 数据库读取记录（包含日期和链接）
 *  2. 使用浏览器自动化抓取实际发布日期
 *  3. 对比日期并生成报告
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const util = require('util');
const execPromise = util.promisify(exec);

// 配置
let configPath = './config.json';
const args = process.argv.slice(2);
if (args.includes('--config')) {
  configPath = args[args.indexOf('--config') + 1];
}

// 加载配置
function loadConfig() {
  try {
    const raw = fs.readFileSync(configPath, 'utf-8');
    return JSON.parse(raw);
  } catch (err) {
    console.error(`❌ 无法加载配置文件 ${configPath}:`, err.message);
    process.exit(1);
  }
}

// 调用 Notion API
async function queryNotionDatabase(config) {
  const { apiKey, databaseId } = config.notion;

  const response = await fetch(
    `https://api.notion.com/v1/databases/${databaseId}/query`,
    {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Notion-Version': '2022-06-28',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        page_size: 100
      })
    }
  );

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Notion API 错误: ${response.status} - ${error}`);
  }

  const data = await response.json();
  return data.results;
}

// 从 Notion 属性中提取日期和链接
function extractRecordData(record, dateField, urlField) {
  try {
    const props = record.properties;

    // 提取日期
    const dateProp = props[dateField];
    if (!dateProp || dateProp.type !== 'date') {
      throw new Error(`字段 "${dateField}" 不是日期类型或不存在`);
    }
    const notionDate = dateProp.date?.start || dateProp.date?.end;

    // 提取 URL
    const urlProp = props[urlField];
    let url = null;
    if (urlProp) {
      if (urlProp.type === 'url' && urlProp.url) {
        url = urlProp.url;
      } else if (urlProp.type === 'rich_text' && urlProp.rich_text?.[0]?.href) {
        url = urlProp.rich_text[0].href;
      }
    }

    return {
      id: record.id,
      title: getRecordTitle(record),
      notionDate,
      url,
      valid: !!(notionDate && url)
    };
  } catch (err) {
    return {
      id: record.id,
      error: err.message,
      valid: false
    };
  }
}

// 获取记录标题
function getRecordTitle(record) {
  const titleProp = Object.values(record.properties).find(p => p.type === 'title');
  if (!titleProp) return 'Untitled';
  return titleProp.title?.plain_text || 'Untitled';
}

// 使用浏览器自动化抓取实际发布日期
async function fetchActualDate(url, config) {
  const task = `打开 ${url}，找到页面的发布日期（publish date 或发布时间），告诉我具体的日期（格式：YYYY-MM-DD）。如果找不到，返回 "未找到"。`;

  try {
    const { stdout } = await execPromise(
      `~/.stepclaw/skills/autoglm-browser-agent/dependency/mcporter call ` +
      `autoglm-browser-agent.browser_subagent ` +
      `task="${task.replace(/"/g, '\\"')}" ` +
      `start_url="https://www.google.com" ` +
      `--timeout 7200000`,
      { timeout: 7300 }
    );

    // 从输出中提取日期
    const dateMatch = stdout.match(/(\d{4})-(\d{2})-(\d{2})/);
    if (dateMatch) {
      return dateMatch[0];
    }

    // 检查是否"未找到"
    if (stdout.includes('未找到') || stdout.includes('not found')) {
      return null;
    }

    return null; // 无法解析
  } catch (err) {
    console.error(`  ⚠️  浏览器验证失败: ${url}`, err.message);
    return null;
  }
}

// 计算日期差异（天数）
function dateDiff(d1, d2) {
  const day1 = new Date(d1);
  const day2 = new Date(d2);
  const diff = Math.abs((day2 - day1) / (1000 * 60 * 60 * 24));
  return Math.round(diff);
}

// 验证单条记录
async function validateRecord(record, config) {
  if (!record.valid) {
    return {
      ...record,
      status: 'error',
      actualDate: null,
      diff: null
    };
  }

  console.log(`  🔍 ${record.title.substring(0, 30)}...`);

  const actualDate = await fetchActualDate(record.url, config);

  if (!actualDate) {
    return {
      ...record,
      status: 'unverified',
      actualDate: null,
      diff: null
    };
  }

  const diff = dateDiff(record.notionDate, actualDate);
  let status;
  if (diff === 0) {
    status = 'consistent';
  } else if (diff <= 3) {
    status = 'close';
  } else {
    status = 'inconsistent';
  }

  return {
    ...record,
    actualDate,
    diff,
    status
  };
}

// 生成报告
function generateReport(results, config) {
  const total = results.length;
  const consistent = results.filter(r => r.status === 'consistent');
  const close = results.filter(r => r.status === 'close');
  const inconsistent = results.filter(r => r.status === 'inconsistent');
  const unverified = results.filter(r => r.status === 'unverified' || r.status === 'error');

  const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

  let report = `# Notion 日期验证报告\n\n`;
  report += `**验证时间**: ${now}\n`;
  report += `**数据库**: ${config.notion.databaseId}\n`;
  report += `**记录总数**: ${total}\n\n`;

  report += `## 统计\n\n`;
  report += `- ✅ 一致: ${consistent.length} (${(consistent.length / total * 100).toFixed(1)}%)\n`;
  report += `- ⚠️ 接近: ${close.length} (${(close.length / total * 100).toFixed(1)}%)\n`;
  report += `- ❌ 不一致: ${inconsistent.length} (${(inconsistent.length / total * 100).toFixed(1)}%)\n`;
  if (unverified.length > 0) {
    report += `- ⏳ 无法验证: ${unverified.length} (${(unverified.length / total * 100).toFixed(1)}%)\n`;
  }
  report += `\n`;

  if (inconsistent.length > 0) {
    report += `## ❌ 不一致项\n\n`;
    inconsistent.forEach(r => {
      report += `### ${r.title}\n\n`;
      report += `- Notion 日期: \`${r.notionDate}\`\n`;
      report += `- 实际日期: \`${r.actualDate}\`\n`;
      report += `- 差异: ${r.diff} 天\n`;
      if (r.url) {
        report += `- 链接: ${r.url}\n`;
      }
      report += `\n`;
    });
  }

  if (close.length > 0) {
    report += `## ⚠️ 接近项（建议人工复核）\n\n`;
    close.forEach(r => {
      report += `- ${r.title}：${r.notionDate} vs ${r.actualDate}（相差 ${r.diff} 天）\n`;
    });
    report += `\n`;
  }

  if (unverified.length > 0) {
    report += `## ⏳ 无法验证\n\n`;
    unverified.forEach(r => {
      report += `- ${r.title}${r.error ? `: ${r.error}` : ''}\n`;
    });
    report += `\n`;
  }

  if (consistent.length > 0) {
    report += `## ✅ 一致项\n\n`;
    consistent.forEach(r => {
      report += `- ${r.title}\n`;
    });
    report += `\n`;
  }

  return report;
}

// 主函数
async function main() {
  console.log('🚀 开始验证 Notion 数据库日期...\n');

  try {
    // 1. 加载配置
    const config = loadConfig();
    console.log(`📋 配置已加载`);
    console.log(`   数据库: ${config.notion.databaseId}`);
    console.log(`   日期字段: ${config.dateField}`);
    console.log(`   链接字段: ${config.urlField}\n`);

    // 2. 查询 Notion
    console.log(`📡 查询 Notion 数据库...`);
    const records = await queryNotionDatabase(config);
    console.log(`   找到 ${records.length} 条记录\n`);

    // 3. 提取数据
    console.log(`📦 提取记录数据...`);
    const extracted = records.map(r => extractRecordData(r, config.dateField, config.urlField));
    const validRecords = extracted.filter(r => r.valid);
    console.log(`   有效记录: ${validRecords.length} 条\n`);

    if (validRecords.length === 0) {
      console.error('❌ 没有找到有效的记录（请检查字段名配置）');
      process.exit(1);
    }

    // 4. 验证日期
    console.log(`🔍 开始浏览器验证（并发 ${config.concurrency}）...\n`);
    const results = [];

    // 简单串行（避免并发过于复杂）
    for (let i = 0; i < validRecords.length; i++) {
      console.log(`[${i + 1}/${validRecords.length}]`);
      const result = await validateRecord(validRecords[i], config);
      results.push(result);
    }

    // 5. 生成报告
    console.log(`\n📊 生成报告...`);
    const report = generateReport(results, config);
    const outputPath = config.output || '验证报告.md';
    fs.writeFileSync(outputPath, report, 'utf-8');
    console.log(`✅ 报告已保存: ${outputPath}`);

    // 统计摘要
    const consistent = results.filter(r => r.status === 'consistent').length;
    const close = results.filter(r => r.status === 'close').length;
    const inconsistent = results.filter(r => r.status === 'inconsistent').length;

    console.log(`\n✨ 验证完成！`);
    console.log(`   一致: ${consistent} | 接近: ${close} | 不一致: ${inconsistent}`);

  } catch (err) {
    console.error('\n❌ 执行失败:', err.message);
    process.exit(1);
  }
}

main();
