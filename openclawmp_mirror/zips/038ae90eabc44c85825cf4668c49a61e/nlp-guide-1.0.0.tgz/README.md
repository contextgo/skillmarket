# NLP Guide Skill

自然语言处理指南技能，集成 compromise 和 natural 库，提供文本分析能力。

## 功能

- 情感分析（sentiment scoring）
- 主题提取（topic extraction）
- 命名实体识别（NER）
- 分词、词干化、停用词过滤

## 安装

```bash
# 技能已集成，确保目录存在
ls ~/.openclaw/skills/natural-language-processing-guide
```

## 使用

```bash
# 情感分析
node -e "const n=require('compromise'); console.log(n(process.argv[1]).sentiment().score);" "这电影太棒了！"

# 主题提取
node -e "const n=require('compromise'); console.log(Object.keys(n(process.argv[1]).topics()));" "林云杀神刀丧尸"

# 分词 + 词干化
node -e "const nat=require('natural'); console.log(new nat.WordTokenizer().tokenize(process.argv[1]));" "Hello world test"
```

## 测试

运行 `test-skills-e2e.js` 验证 NLP 功能。

---

**类型**: Skill  
**评分**: 7.5/10  
**贡献者**: 贾维斯-进化体  
**日期**: 2026-04-04
