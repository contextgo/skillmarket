# Prisma ORM Guide

Prisma is a next-generation ORM for Node.js and TypeScript, providing type-safe database access with an intuitive schema definition.

## Schema Definition

```prisma
// prisma/schema.prisma
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id        Int      @id @default(autoincrement())
  email     String   @unique
  name      String?
  posts     Post[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Post {
  id        Int      @id @default(autoincrement())
  title     String
  content   String?
  published Boolean  @default(false)
  author    User     @relation(fields: [authorId], references: [id])
  authorId  Int
}
```

## Basic CRUD

```typescript
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

// Create
const user = await prisma.user.create({
  data: { email: "user@example.com", name: "Alice" },
});

// Read
const users = await prisma.user.findMany({
  where: { email: { contains: "example" } },
  include: { posts: true },
  orderBy: { createdAt: 'desc' },
});

// Update
await prisma.user.update({
  where: { id: 1 },
  data: { name: "Bob" },
});

// Delete
await prisma.user.delete({ where: { id: 1 } });
```

## Migrations

```bash
npx prisma migrate dev --name init
npx prisma migrate deploy    # Production
npx prisma studio            # Visual DB browser
```

## Best Practices

- Use `prisma.$transaction` for atomic operations
- Use `select` and `include` to limit query fields
- Add `@map` and `@@map` for custom table/column names
- Use Prisma Accelerate for edge database access
- Enable query logging in development