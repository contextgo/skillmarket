#!/usr/bin/env python3
"""
extract-daily-digest.py
从 OpenClaw session transcript 中提取当日用户消息摘要。
输出：memory/daily-digest/YYYY-MM-DD.md

用法：
  python3 extract-daily-digest.py [--date YYYY-MM-DD] [--sessions-dir PATH]

默认提取今天的消息。
"""

import json
import os
import sys
import glob
from datetime import datetime, timedelta, timezone
from pathlib import Path

# 配置
DEFAULT_AGENT = "main"
SESSIONS_DIR = os.path.expanduser(
    os.environ.get("OPENCLAW_SESSIONS_DIR", f"~/.openclaw/agents/{DEFAULT_AGENT}/sessions")
)
OUTPUT_DIR = os.path.expanduser(
    os.environ.get("OPENCLAW_DIGEST_DIR", "~/.openclaw/workspace/memory/daily-digest")
)
TZ = timezone(timedelta(hours=8))  # Asia/Shanghai


def parse_args():
    date_str = None
    sessions_dir = SESSIONS_DIR

    args = sys.argv[1:]
    i = 0
    while i < len(args):
        if args[i] == "--date" and i + 1 < len(args):
            date_str = args[i + 1]
            i += 2
        elif args[i] == "--sessions-dir" and i + 1 < len(args):
            sessions_dir = args[i + 1]
            i += 2
        else:
            i += 1

    if date_str:
        target_date = datetime.strptime(date_str, "%Y-%m-%d").date()
    else:
        target_date = datetime.now(TZ).date()

    return target_date, sessions_dir


def extract_user_text(content):
    """从 message content 中提取纯用户文本（去掉 metadata wrapper）"""
    raw = ""
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                raw = item.get("text", "")
                break
    elif isinstance(content, str):
        raw = content

    if not raw:
        return None

    lines = raw.split("\n")
    
    # 策略1：标准格式 "ou_xxx: 消息"
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("ou_") and ": " in stripped:
            return stripped.split(": ", 1)[1].strip()

    # 策略2：过滤系统元数据块
    cleaned = []
    skip_mode = False
    backtick_count = 0
    
    for line in lines:
        stripped = line.strip()
        
        if stripped.startswith("System:") or stripped.startswith("Replied message"):
            continue
        
        if stripped.startswith("Conversation info"):
            skip_mode = True
            backtick_count = 0
            continue
        
        if skip_mode:
            if stripped.startswith("```"):
                backtick_count += 1
                if backtick_count >= 2:
                    skip_mode = False
                continue
            continue
        
        if not stripped:
            continue
        
        cleaned.append(stripped)
    
    if cleaned:
        return " ".join(cleaned)
    
    # 策略3：兜底，取最后非空非系统行
    for line in reversed(lines):
        stripped = line.strip()
        if stripped and not stripped.startswith("System:") and not stripped.startswith("Conversation info"):
            return stripped
    
    return None


def extract_assistant_summary(content):
    """严格过滤：只保留看起来像给用户的实际回复"""
    raw = ""
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                raw = item.get("text", "")
                break
    elif isinstance(content, str):
        raw = content
    if not raw:
        return None

    # 如果包含明显的执行日志/思考过程，直接丢弃
    noise_patterns = [
        "我来", "让我", "我先", "检查", "看看", "读取", "执行", "开始", "确认",
        "找到", "理解", "已", "正在", "等待", "触发", "生成", "创建", "更新",
        "删除", "复制", "发布", "我需要", "我决定", "我计划", "我将", "我尝试",
        "先看", "先查", "先检查", "先获取", "让我先", "我需要先",
        "```json", "```", "###", "|", "---", "===",
        "job_id", "WORKER_EXECUTE", "origin_agent", "exec_agent",
        "扫描情况", "扫描范围", "统计区间", "执行结果", "任务完成", "建议", "没有", "无需",
        "System:", "HEARTBEAT", "NO_REPLY"
    ]
    
    lines = raw.split("\n")
    kept = []
    
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
            
        # 跳过任何含有噪音关键词的行
        if any(pat in stripped for pat in noise_patterns):
            continue
            
        # 跳过过短行
        if len(stripped) < 30:
            continue
            
        # 跳过以字母/数字开头的长行（可能是配置、日志）
        if stripped.startswith(('"', "'", '`', '|', '-', '*', '#')):
            continue
            
        kept.append(stripped)
    
    if not kept:
        return None
    
    text = " ".join(kept)
    if len(text) <= 60:
        return text
    end = text.rfind('.', 0, 60)
    if end == -1:
        end = 60
    return text[:end].strip() + "..."


def main():
    target_date, sessions_dir = parse_args()
    pattern = os.path.join(sessions_dir, "*.jsonl")
    session_files = glob.glob(pattern)
    
    user_msgs = []
    assistant_msgs = []
    
    for sf in session_files:
        basename = os.path.basename(sf)
        if ".lock" in basename or ".deleted" in basename or ".reset" in basename:
            continue
        try:
            with open(sf, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if obj.get("type") != "message":
                        continue
                    msg = obj.get("message", {})
                    role = msg.get("role")
                    ts_str = obj.get("timestamp", "")
                    if not ts_str:
                        continue
                    try:
                        ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                        ts_local = ts.astimezone(TZ)
                    except (ValueError, TypeError):
                        continue
                    if ts_local.date() != target_date:
                        continue
                    
                    if role == "user":
                        user_text = extract_user_text(msg.get("content", ""))
                        if user_text and len(user_text) > 2:
                            skip_patterns = [
                                "HEARTBEAT", "heartbeat", "[cron:",
                                "memsearch 自动索引", "Self-Evolution",
                                "A new session was started", "Execute your Session Startup",
                                "Read HEARTBEAT.md", "NO_REPLY"
                            ]
                            if not any(skip in user_text for skip in skip_patterns):
                                user_msgs.append({
                                    "time": ts_local.strftime("%H:%M"),
                                    "text": user_text
                                })
                    elif role == "assistant":
                        summary = extract_assistant_summary(msg.get("content", ""))
                        if summary:
                            assistant_msgs.append({
                                "time": ts_local.strftime("%H:%M"),
                                "summary": summary
                            })
        except (IOError, PermissionError):
            continue

    # 生成摘要
    lines = [f"# Daily Digest — {target_date.isoformat()}", ""]
    
    if user_msgs:
        lines.append("## 用户输入摘要")
        for m in user_msgs:
            lines.append(f"- [{m['time']}] {m['text']}")
        lines.append("")
    
    if assistant_msgs:
        lines.append("## 助手回复摘要")
        for m in assistant_msgs:
            lines.append(f"- [{m['time']}] {m['summary']}")
        lines.append("")
    
    if not user_msgs and not assistant_msgs:
        lines.append("今日无有效对话记录。")
    else:
        lines.append(f"*共处理 {len(user_msgs)} 条用户输入，{len(assistant_msgs)} 条助手回复*")

    content = "\n".join(lines)
    
    out_dir = os.path.expanduser(OUTPUT_DIR)
    os.makedirs(out_dir, exist_ok=True)
    out_path = os.path.join(out_dir, f"digest-{target_date.isoformat()}.md")
    with open(out_path, "w", encoding="utf-8") as f:
        f.write(content)
    
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
