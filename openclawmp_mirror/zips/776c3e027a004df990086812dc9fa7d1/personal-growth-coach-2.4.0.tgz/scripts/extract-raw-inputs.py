#!/usr/bin/env python3
"""
extract-raw-inputs.py
从 session transcript 中提取当日用户原始输入（去噪）。
输出纯文本，供 LLM 进一步总结。

用法：
  python3 extract-raw-inputs.py [--date YYYY-MM-DD]
  
输出到 stdout，供 cron 任务中 LLM 读取。
"""

import json
import os
import sys
import glob
from datetime import datetime, timedelta, timezone

DEFAULT_AGENT = "main"
SESSIONS_DIR = os.path.expanduser(
    os.environ.get("OPENCLAW_SESSIONS_DIR", f"~/.openclaw/agents/{DEFAULT_AGENT}/sessions")
)
TZ = timezone(timedelta(hours=8))


def parse_args():
    date_str = None
    args = sys.argv[1:]
    i = 0
    while i < len(args):
        if args[i] == "--date" and i + 1 < len(args):
            date_str = args[i + 1]
            i += 2
        else:
            i += 1
    if date_str:
        return datetime.strptime(date_str, "%Y-%m-%d").date()
    return datetime.now(TZ).date()


def extract_user_text(content):
    """提取用户实际输入文本（支持 OpenClaw 标准消息格式）"""
    raw = ""
    if isinstance(content, list):
        for item in content:
            if isinstance(item, dict) and item.get("type") == "text":
                raw = item.get("text", "")
                break
    elif isinstance(content, str):
        raw = content
    if not raw:
        return None

    lines = raw.split("\n")
    
    # 策略1：标准格式 "ou_xxx: 消息"
    for line in lines:
        stripped = line.strip()
        if stripped.startswith("ou_") and ": " in stripped:
            return stripped.split(": ", 1)[1].strip()

    # 策略2：过滤系统元数据（System, Conversation info + code block, Replied message）
    cleaned = []
    skip_mode = False
    backtick_count = 0  # 用于跳过 Conversation info 后的代码块（需要遇到两个 ``` 才退出）
    
    for line in lines:
        stripped = line.strip()
        
        # 跳过 System 行
        if stripped.startswith("System:"):
            continue
        
        # 跳过 Replied message 行
        if stripped.startswith("Replied message"):
            continue
        
        # 检测 Conversation info 开始
        if stripped.startswith("Conversation info"):
            skip_mode = True
            backtick_count = 0
            continue
        
        if skip_mode:
            if stripped.startswith("```"):
                backtick_count += 1
                if backtick_count >= 2:  # 遇到第二个 ```，代码块结束
                    skip_mode = False
                continue
            # skip_mode 下跳过所有非 ``` 行
            continue
        
        if not stripped:  # 空行
            continue
        
        cleaned.append(stripped)
    
    if cleaned:
        return " ".join(cleaned)
    
    # 策略3：兜底，取最后非空且非系统行
    for line in reversed(lines):
        stripped = line.strip()
        if stripped and not stripped.startswith("System:") and not stripped.startswith("Conversation info"):
            return stripped
    
    return None


def main():
    target_date = parse_args()
    events = []

    session_files = glob.glob(os.path.join(SESSIONS_DIR, "*.jsonl"))
    for sf in session_files:
        basename = os.path.basename(sf)
        if ".lock" in basename or ".deleted" in basename or ".reset" in basename:
            continue
        try:
            with open(sf, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        obj = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if obj.get("type") != "message":
                        continue
                    msg = obj.get("message", {})
                    if msg.get("role") != "user":
                        continue
                    ts_str = obj.get("timestamp", "")
                    if not ts_str:
                        continue
                    try:
                        ts = datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
                        ts_local = ts.astimezone(TZ)
                    except (ValueError, TypeError):
                        continue
                    if ts_local.date() != target_date:
                        continue
                    user_text = extract_user_text(msg.get("content", ""))
                    if user_text and len(user_text) > 2:
                        # 过滤 cron/heartbeat/system/session-startup 消息
                        skip_patterns = [
                            "HEARTBEAT", "heartbeat", "[cron:", 
                            "memsearch 自动索引", "Self-Evolution",
                            "A new session was started", "Execute your Session Startup",
                            "Read HEARTBEAT.md"
                        ]
                        if any(skip in user_text for skip in skip_patterns):
                            continue
                        events.append({
                            "time": ts_local.strftime("%H:%M"),
                            "text": user_text,
                            "ts": ts_local,
                        })
        except (IOError, PermissionError):
            continue

    events.sort(key=lambda x: x["ts"])

    # 输出纯文本时间线
    print(f"# {target_date} 用户交互原始记录")
    print(f"# 共 {len(events)} 条有效输入")
    print()
    for e in events:
        print(f"[{e['time']}] {e['text']}")
        print()


if __name__ == "__main__":
    main()
