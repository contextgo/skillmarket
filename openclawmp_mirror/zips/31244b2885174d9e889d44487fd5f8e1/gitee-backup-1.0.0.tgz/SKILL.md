---
name: gitee-backup
description: 小虾米 workspace Gitee 备份技能。智能检测变更 + 定时自动推送 + 手动命令。
commands:
  - /backup push - 手动推送备份
  - /backup restore - 从 Gitee 恢复
  - /backup status - 查看备份状态
  - /backup dry - 预览会备份哪些文件
---
# Gitee Backup

## 自动化机制
每4小时自动运行，智能检测有意义变更后推送。
只备份：人格模板、记忆、配置、脚本、技能配置。
自动跳过：媒体文件、临时文件。

## 手动命令
- /backup push - 立即推送（有变更才推）
- /backup restore - 从 Gitee 恢复
- /backup status - 查看状态
- /backup dry - 预览要备份的文件
