# Gitee 备份技能

小虾米 workspace Gitee 备份技能。智能检测变更 + 定时自动推送 + 手动命令。

## 功能

- 智能检测 workspace 文件变更
- 定时自动推送到 Gitee 仓库
- 支持手动触发备份：`/backup push`
- 增量推送，只上传有变化的文件

## 适用场景

每天自动将 workspace 备份到 Gitee，无需人工干预。
