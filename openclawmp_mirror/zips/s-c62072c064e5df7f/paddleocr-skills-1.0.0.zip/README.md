# PaddleOCR-Skills

<p align="center">
  <strong>Claude Code 的 OCR 技能套件</strong>
</p>

<p align="center">
  由 PaddleOCR API 驱动的文本识别和文档解析
</p>

<p align="center">
  <img src="https://img.shields.io/badge/python-3.8+-blue.svg" alt="Python">
  <img src="https://img.shields.io/badge/license-MIT-green.svg" alt="License">
  <img src="https://img.shields.io/badge/Claude%20Code-Skills-purple.svg" alt="Claude Code Skills">
</p>

<p align="center">
  <a href="./README-cn.md">简体中文</a> | <strong>English</strong>
</p>

---

## 概述

此仓库提供两个互补的技能：

1. `paddleocr-text-recognition`
- 图像和 PDF 的快速 OCR
- 返回统一的 JSON：`ok`、`text`、`result`、`error`

2. `paddleocr-doc-parsing`
- 复杂文档的高级布局解析
- 提取完整文本和原始结构化解析结果

---

## 功能比较

| 维度 | paddleocr-text-recognition | paddleocr-doc-parsing |
|-----------|----------------------------|-----------------------|
| 最适合 | 纯文本提取 | 复杂布局文档 |
| 提取的 `text` 来源 | `prunedResult.rec_texts` 按行/页连接 | `layoutParsingResults[].markdown.text`（后备：连接的块） |
| 原始 `result` 细粒度 | 行级 OCR（`rec_texts`、`rec_scores`、`rec_boxes`、`rec_polys`） | 页/块级解析（`prunedResult.parsing_res_list`、`markdown`） |
| CLI 输入 | `--file-url` 或 `--file-path` | `--file-url` 或 `--file-path`，加上 `--file-type {0,1}` |
| 默认超时 | `PADDLEOCR_TIMEOUT=120` | `PADDLEOCR_DOC_PARSING_TIMEOUT=600` |
| 大文件辅助脚本 | 无 | 是（`skills/paddleocr-doc-parsing/scripts/optimize_file.py`，图像优化） |

---

## 安装

> 先决条件：Node.js >= 14，Python 3.8+，[Claude Code CLI](https://claude.ai/code)

安装所有技能：

```bash
npx skills add Aidenwu0209/PaddleOCR-Skills
```

仅安装一个技能：

```bash
npx skills add Aidenwu0209/PaddleOCR-Skills --skill paddleocr-text-recognition
npx skills add Aidenwu0209/PaddleOCR-Skills --skill paddleocr-doc-parsing
```

手动安装：

```bash
git clone https://github.com/Aidenwu0209/PaddleOCR-Skills.git
cd PaddleOCR-Skills

pip install -r skills/paddleocr-text-recognition/scripts/requirements.txt
pip install -r skills/paddleocr-doc-parsing/scripts/requirements.txt
```

---

## 配置

在 [Paddle AI Studio](https://paddleocr.com) 获取 API 凭据，然后运行：

```bash
python skills/paddleocr-text-recognition/scripts/configure.py
python skills/paddleocr-doc-parsing/scripts/configure.py
```

核心环境变量：

```bash
PADDLEOCR_OCR_API_URL=
PADDLEOCR_DOC_PARSING_API_URL=
PADDLEOCR_ACCESS_TOKEN=
```

当前代码使用的可选超时：

```bash
PADDLEOCR_TIMEOUT=120
PADDLEOCR_DOC_PARSING_TIMEOUT=600
```

---

## 快速开始

文本识别：

```bash
python skills/paddleocr-text-recognition/scripts/ocr_caller.py \
  --file-path "./doc.png" \
  --pretty
```

文档解析：

```bash
python skills/paddleocr-doc-parsing/scripts/vl_caller.py \
  --file-path "./invoice.pdf" \
  --pretty
```

将输出保存到文件：

```bash
python skills/paddleocr-text-recognition/scripts/ocr_caller.py \
  --file-url "https://example.com/image.jpg" \
  --output result.json \
  --pretty

python skills/paddleocr-doc-parsing/scripts/vl_caller.py \
  --file-url "https://example.com/document.pdf" \
  --output result.json \
  --pretty
```

---

## 输出契约

两个CLI返回相同的信封：

```json
{
  "ok": true,
  "text": "...",
  "result": { "...": "raw provider response" },
  "error": null
}
```

出错时：

```json
{
  "ok": false,
  "text": "",
  "result": null,
  "error": { "code": "API_ERROR", "message": "..." }
}
```

---

## 大文件

对于文档解析的大文件：
- 优先使用 `--file-url` 以避免本地base64开销。
- 对于大图像，使用 `skills/paddleocr-doc-parsing/scripts/optimize_file.py`。
- 对于大PDF文件，先提取需要的页面，然后再进行解析。

参见：
- [快速参考](./docs/QUICK_REFERENCE.md)
- [大文件指南](./docs/LARGE_FILES.md)

---

## 测试

```bash
python skills/paddleocr-text-recognition/scripts/smoke_test.py --skip-api-test
python skills/paddleocr-doc-parsing/scripts/smoke_test.py --skip-api-test
```

---

## 文档

- [文本识别技能指南](./skills/paddleocr-text-recognition/SKILL.md)
- [文本识别输出模式](./skills/paddleocr-text-recognition/references/output_schema.md)
- [文档解析技能指南](./skills/paddleocr-doc-parsing/SKILL.md)
- [文档解析输出模式](./skills/paddleocr-doc-parsing/references/output_schema.md)

---

## 许可证

[MIT许可证](./LICENSE)

---

## 支持

- 问题：[GitHub问题](https://github.com/Aidenwu0209/PaddleOCR-Skills/issues)
- API服务：[Paddle AI Studio](https://paddleocr.com)