---
name: 沟通话术生成器
displayName: 沟通话术生成器
description: 将教案转换为家长沟通话术，生成微信/电话版本，亲切专业。
version: 1.0.0
author: OpenClaw Edu
tags: [education, communication, parent, message, teaching]
category: education
---

# 沟通话术生成器

教案转家长沟通话术。

## 功能

- 教案内容分析
- 生成微信话术
- 生成电话话术
- 多场景适配（表扬/提醒/沟通）

## 使用

```
@沟通话术生成器 将这份教案转换为家长微信群发话术
```
