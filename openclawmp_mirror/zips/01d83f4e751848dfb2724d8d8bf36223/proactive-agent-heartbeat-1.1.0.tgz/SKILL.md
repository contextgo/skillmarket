---
name: proactive-agent-heartbeat
description: "主动心跳引擎 - 4级心跳分级 + 轮换检查 + 智能静默，让 AI Agent 在心跳时真正主动起来"
version: 1.1.0
tags: ["heartbeat", "proactive", "automation", "cron", "agent", "self-management"]
author: audrey
---

# Proactive Agent Heartbeat - 主动心跳引擎

## 我能做什么

当用户没有主动发消息时，我可以在后台主动发现问题、推进任务、整理记忆——而不是只回复 `HEARTBEAT_OK`。

**典型场景：**

- 「你平时都在干什么」→ 我可以汇报最近的心跳主动行动
- 「帮我看看系统状态」→ 我调 `heartbeat_decider.py status` 输出检查项全景
- 「现在几点了，做了什么」→ 查看 `heartbeat_log.json` 了解最近活动

## 核心机制

### 4级心跳分级

| 级别 | 时间段 | 行为 |
|------|--------|------|
| L1 静默 | 23:00-07:00 / 频繁心跳 | 直接回复 HEARTBEAT_OK |
| L2 轻量检查 | 08:00-12:00 / 14:00-19:00 | 项目进度、待办事项、Cron健康 |
| L3 主动行动 | 19:00-23:00 | 知识整理、机会发现 |
| L4 紧急响应 | 任何时间 | 系统故障立即处理 |

### 轮换检查清单

每次心跳轮换检查 2-4 项，避免重复劳动：

| 检查项 | ID | 级别 | 建议间隔 |
|--------|-----|------|---------|
| 系统健康 | `system_health` | L1 | 30分钟 |
| 项目进度 | `project_progress` | L2 | 2小时 |
| 待办事项 | `daily_todos` | L2 | 1小时 |
| Cron健康 | `cron_health` | L2 | 3小时 |
| 知识整理 | `memory_update` | L3 | 4小时 |
| 机会发现 | `opportunity` | L3 | 5小时 |

### 静默规则

满足以下任一条件 → 直接回复 HEARTBEAT_OK，不打扰用户：
1. 深夜 23:00-08:00
2. 30 分钟内刚检查过
3. 连续 3 次无新发现（自动降频）

## 工作方式

调用 `heartbeat_decider.py` 脚本：

```
decide   → 主入口，决策本次心跳行为（L? + 检查哪些项）
status   → 查看各检查项状态和最后检查时间
check    → 执行单项检查（调试用）
record   → 记录一个主动发现
```

## 与原版的区别（v1.0.0 → v1.1.0）

原版：80行纯描述，无代码，无轮换逻辑，无量化规则
本版：完整可运行脚本 + 状态持久化 + 6项轮换 + 4级分级

| 功能 | 原版 | 增强版 |
|------|------|--------|
| 心跳分级 | 概念描述 | 时间驱动量化分级 |
| 轮换检查 | 无 | 自动轮换，每次 2-4 项 |
| 静默规则 | 概念描述 | 三条件量化触发 |
| 状态持久化 | 无 | JSON 文件保存检查状态 |
| 系统健康检查 | 无 | 进程+端口+磁盘实时检查 |
| 主动汇报 | 无 | findings 记录 + HEARTBEAT.md 摘要 |

## 状态文件

- `~/.openclaw/workspace/heartbeat_state.json` — 检查状态持久化
- `~/.openclaw/workspace/heartbeat_log.json` — 行动日志（最近500条）
