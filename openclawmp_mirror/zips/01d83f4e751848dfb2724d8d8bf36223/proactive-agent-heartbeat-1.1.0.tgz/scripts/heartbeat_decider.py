#!/usr/bin/env python3
"""
Proactive Heartbeat - 主动心跳引擎
=====================================
增强版 heartbeat 决策脚本

Usage:
    python proactive_heartbeat.py decide              # 决定本次心跳行为
    python proactive_heartbeat.py check <item>        # 执行单项检查
    python proactive_heartbeat.py status              # 查看当前状态
    python proactive_heartbeat.py rotate              # 轮换检查项
    python proactive_heartbeat.py record <finding>    # 记录发现
"""

import argparse
import json
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", Path.home() / ".openclaw" / "workspace"))
STATE_FILE = WORKSPACE / "heartbeat_state.json"
LOG_FILE = WORKSPACE / "heartbeat_log.json"
MEMORY_FILE = WORKSPACE / "MEMORY.md"

# ─── 检查项定义 ───────────────────────────────────────────────────────

CHECK_ITEMS = [
    {
        "id": "project_progress",
        "name": "项目进度",
        "desc": "检查 STATE.yaml 和 active-projects 中的任务进度",
        "level": 2,
        "interval_min": 120
    },
    {
        "id": "daily_todos",
        "name": "待办事项",
        "desc": "检查 daily-notes 中的 In Progress 项",
        "level": 2,
        "interval_min": 60
    },
    {
        "id": "cron_health",
        "name": "Cron 任务健康",
        "desc": "检查 cron 任务状态和最近错误日志",
        "level": 2,
        "interval_min": 180
    },
    {
        "id": "memory_update",
        "name": "知识整理",
        "desc": "整理记忆文件，记录新发现和重要决策",
        "level": 3,
        "interval_min": 240
    },
    {
        "id": "opportunity",
        "name": "机会发现",
        "desc": "检查是否有新的自动化机会和改进空间",
        "level": 3,
        "interval_min": 300
    },
    {
        "id": "system_health",
        "name": "系统健康",
        "desc": "检查进程状态、磁盘空间、关键服务端口",
        "level": 1,
        "interval_min": 30
    },
]

# ─── 状态管理 ─────────────────────────────────────────────────────────

def load_state() -> Dict:
    if STATE_FILE.exists():
        return json.loads(STATE_FILE.read_text())
    return {
        "last_check": {},
        "consecutive_quiet": 0,
        "current_level": 1,
        "findings": [],
        "rotation_index": 0,
        "last_heartbeat": None
    }


def save_state(state: Dict):
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(json.dumps(state, ensure_ascii=False, indent=2))


def load_log() -> List[Dict]:
    if LOG_FILE.exists():
        return json.loads(LOG_FILE.read_text())
    return []


def save_log(log: List[Dict]):
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    LOG_FILE.write_text(json.dumps(log[-500:], ensure_ascii=False, indent=2))


# ─── 核心逻辑 ─────────────────────────────────────────────────────────

def get_current_level() -> int:
    """根据时间和上下文确定当前心跳级别"""
    now = datetime.now()
    hour = now.hour

    # 深夜 紧急响应
    if 23 <= hour or hour < 7:
        return 1
    # 上午 工作推进
    if 8 <= hour < 12:
        return 2
    # 中午 轻量
    if 12 <= hour < 14:
        return 1
    # 下午 待办推进
    if 14 <= hour < 19:
        return 2
    # 晚间 知识整理
    if 19 <= hour < 23:
        return 3

    return 1


def should_be_quiet(state: Dict) -> bool:
    """判断是否应该静默"""
    now = datetime.now()

    # 深夜不打扰
    if 23 <= now.hour or now.hour < 8:
        return True

    # 30 分钟内刚检查过
    last = state.get("last_heartbeat")
    if last:
        last_time = datetime.fromisoformat(last)
        if (now - last_time).total_seconds() < 1800:
            return True

    # 连续3次静默 → 降低频率
    if state.get("consecutive_quiet", 0) >= 3:
        return True

    return False


def get_items_to_check(state: Dict, level: int) -> List[Dict]:
    """根据级别和轮换规则确定本次要检查的项"""
    last_check = state.get("last_check", {})
    now = datetime.now()
    items = []

    for item in CHECK_ITEMS:
        if item["level"] > level:
            continue

        item_id = item["id"]
        last = last_check.get(item_id)
        interval = timedelta(minutes=item["interval_min"])

        if last:
            last_time = datetime.fromisoformat(last)
            if now - last_time < interval:
                continue

        items.append(item)

    # 轮换选取（每次 2-4 项，根据级别）
    max_items = 2 if level == 2 else 4 if level >= 3 else 99
    rotation_idx = state.get("rotation_index", 0)

    # 优先选最久未检查的
    items.sort(key=lambda x: last_check.get(x["id"], "1970-01-01"))
    selected = items[:max_items]

    return selected


def execute_check(item: Dict) -> Dict:
    """执行单项检查，返回结果"""
    item_id = item["id"]
    result = {
        "id": item_id,
        "name": item["name"],
        "timestamp": datetime.now().isoformat(),
        "status": "ok",
        "findings": [],
        "actions": []
    }

    try:
        if item_id == "system_health":
            import socket

            checks = []

            # 进程
            import subprocess
            try:
                count = subprocess.run(["pgrep", "-c", "-f", "openclaw"],
                                      capture_output=True, text=True).stdout.strip()
                count = int(count) if count.isdigit() else 0
                checks.append(("openclaw进程", count if count > 0 else None))
            except:
                checks.append(("openclaw进程", None))

            # 端口
            ports = {3001: "Playwright MCP", 3002: "DevTools MCP", 18800: "Edge CDP"}
            for port, name in ports.items():
                try:
                    sock = socket.socket()
                    sock.settimeout(1)
                    r = sock.connect_ex(("127.0.0.1", port))
                    checks.append((name, "up" if r == 0 else "down"))
                    sock.close()
                except:
                    checks.append((name, "error"))

            # 磁盘
            import shutil
            disk = shutil.disk_usage(Path.home())
            usage = disk.used / disk.total * 100
            checks.append(("磁盘使用率", f"{usage:.0f}%"))

            result["data"] = checks

            # 判断异常
            critical = [c for c in checks if c[1] is None or c[1] == "down" or
                       (isinstance(c[1], str) and "%" in c[1] and int(c[1].replace("%","")) > 90)]
            if critical:
                result["status"] = "critical" if len(critical) > 1 else "warning"
                result["findings"] = [f"{c[0]}: {c[1]}" for c in critical]

        elif item_id == "cron_health":
            import subprocess
            try:
                out = subprocess.run(["openclaw", "tasks", "--status"],
                                    capture_output=True, text=True, timeout=10)
                result["data"] = out.stdout[:200] if out.stdout else "无输出"
            except Exception as e:
                result["status"] = "warning"
                result["findings"] = [f"无法获取 cron 状态: {str(e)[:50]}"]

        elif item_id == "memory_update":
            # 检查 MEMORY.md 最后更新时间
            if MEMORY_FILE.exists():
                mtime = datetime.fromtimestamp(MEMORY_FILE.stat().st_mtime)
                age = (datetime.now() - mtime).total_seconds() / 3600
                result["data"] = {"last_modified_hours": round(age, 1)}
                if age > 48:
                    result["status"] = "suggestion"
                    result["findings"] = ["MEMORY.md 超过48小时未更新"]
            else:
                result["status"] = "suggestion"
                result["findings"] = ["MEMORY.md 不存在"]

        elif item_id == "project_progress":
            state_file = WORKSPACE / "STATE.yaml"
            if state_file.exists():
                content = state_file.read_text()[:200]
                result["data"] = {"preview": content[:100]}
            else:
                result["data"] = "无项目状态文件"

        elif item_id == "daily_todos":
            # 检查最近的 daily note
            today = datetime.now().strftime("%Y-%m-%d")
            daily = WORKSPACE / "memory" / f"{today}.md"
            if daily.exists():
                content = daily.read_text()
                in_progress = [l for l in content.split("\n") if "In Progress" in l or "进行中" in l]
                result["data"] = {"in_progress_count": len(in_progress)}
                if not in_progress:
                    result["status"] = "suggestion"
                    result["findings"] = ["今日无进行中的任务"]
            else:
                result["data"] = "今日笔记不存在"

        elif item_id == "opportunity":
            # 检查 skills 目录，看是否有待更新的 skill
            skills_dir = WORKSPACE / "skills"
            if skills_dir.exists():
                skill_count = len(list(skills_dir.iterdir()))
                result["data"] = {"local_skills": skill_count}

    except Exception as e:
        result["status"] = "error"
        result["findings"] = [str(e)[:80]]

    return result


def decide_action() -> Dict:
    """主决策函数：判断本次心跳应该做什么"""
    state = load_state()
    now = datetime.now()
    level = get_current_level()

    # 更新心跳时间
    state["last_heartbeat"] = now.isoformat()
    state["current_level"] = level

    # 静默检查
    if should_be_quiet(state):
        state["consecutive_quiet"] = state.get("consecutive_quiet", 0) + 1
        save_state(state)
        return {
            "action": "quiet",
            "level": level,
            "reason": "静默规则触发",
            "consecutive_quiet": state["consecutive_quiet"]
        }

    # 正常检查
    state["consecutive_quiet"] = 0
    items = get_items_to_check(state, level)

    if not items:
        return {
            "action": "quiet",
            "level": level,
            "reason": "本次无可检查项（都在间隔内）",
            "consecutive_quiet": 0
        }

    # 更新最后检查时间
    for item in items:
        state["last_check"][item["id"]] = now.isoformat()

    # 轮换索引
    state["rotation_index"] = (state.get("rotation_index", 0) + len(items)) % len(CHECK_ITEMS)

    save_state(state)

    return {
        "action": "check",
        "level": level,
        "items": [{"id": i["id"], "name": i["name"]} for i in items],
        "reason": f"L{level} 主动检查 ({len(items)} 项)",
        "timestamp": now.isoformat()
    }


# ─── CLI 命令 ─────────────────────────────────────────────────────────

def cmd_decide(args):
    result = decide_action()
    action = result["action"]

    if action == "quiet":
        print(f"😌 {result['reason']}")
        print(f"   心跳级别: L{result['level']}")
        print(f"   连续静默: {result['consecutive_quiet']} 次")
    else:
        print(f"🔍 {result['reason']}")
        print(f"   心跳级别: L{result['level']}")
        print(f"   本次检查:")
        for item in result["items"]:
            print(f"   • {item['name']} ({item['id']})")

    return result


def cmd_check(args):
    item = next((i for i in CHECK_ITEMS if i["id"] == args.item), None)
    if not item:
        print(f"未知检查项: {args.item}")
        print(f"可用项: {', '.join(i['id'] for i in CHECK_ITEMS)}")
        return

    print(f"🔍 执行: {item['name']}")
    result = execute_check(item)

    print(f"状态: {result['status']}")
    if result.get("data"):
        print(f"数据: {result['data']}")
    if result.get("findings"):
        print("发现:")
        for f in result["findings"]:
            print(f"  ⚠️  {f}")

    return result


def cmd_status(args):
    state = load_state()
    now = datetime.now()

    print("📊 Proactive Heartbeat 状态")
    print("─" * 40)
    print(f"当前心跳级别: L{get_current_level()}")

    last_hb = state.get("last_heartbeat")
    if last_hb:
        ago = (now - datetime.fromisoformat(last_hb)).total_seconds() / 60
        print(f"上次心跳: {last_hb[:19]} ({ago:.0f} 分钟前)")
    else:
        print("上次心跳: 无记录")

    print(f"连续静默: {state.get('consecutive_quiet', 0)} 次")
    print(f"轮换索引: {state.get('rotation_index', 0)}")
    print()
    print("检查项状态:")
    last_check = state.get("last_check", {})
    for item in CHECK_ITEMS:
        last = last_check.get(item["id"])
        if last:
            ago = (now - datetime.fromisoformat(last)).total_seconds() / 60
            print(f"  {item['name']:20s} {last[:10]} ({ago:.0f}分钟前) L{item['level']}")
        else:
            print(f"  {item['name']:20s} 从未检查          L{item['level']}")


def cmd_rotate(args):
    state = load_state()
    state["rotation_index"] = (state.get("rotation_index", 0) + 1) % len(CHECK_ITEMS)
    next_item = CHECK_ITEMS[state["rotation_index"]]
    save_state(state)
    print(f"🔄 轮换索引 → {state['rotation_index']}")
    print(f"   下次优先检查: {next_item['name']} ({next_item['id']})")


def cmd_record(args):
    state = load_state()
    finding = {
        "timestamp": datetime.now().isoformat(),
        "text": args.text,
        "level": state.get("current_level", 1)
    }
    state.setdefault("findings", []).append(finding)
    save_state(state)
    print(f"✅ 已记录 ({len(state['findings'])} 条总记录)")


def main():
    parser = argparse.ArgumentParser(description="🦞 Proactive Heartbeat 主动心跳引擎")
    sub = parser.add_subparsers(dest="cmd", required=True)

    sub.add_parser("decide", help="决策本次心跳行为（主入口）")
    sub.add_parser("status", help="查看当前状态和检查项状态")
    sub.add_parser("rotate", help="手动轮换检查项")

    check = sub.add_parser("check", help="执行单项检查")
    check.add_argument("item", help="检查项 ID")

    record = sub.add_parser("record", help="记录一个发现")
    record.add_argument("text", nargs="+", help="发现内容")

    args = parser.parse_args()

    if args.cmd == "decide":
        cmd_decide(args)
    elif args.cmd == "check":
        cmd_check(args)
    elif args.cmd == "status":
        cmd_status(args)
    elif args.cmd == "rotate":
        cmd_rotate(args)
    elif args.cmd == "record":
        cmd_record(args)


if __name__ == "__main__":
    main()
