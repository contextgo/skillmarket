# PWA Offline-First Development

## Service Worker Lifecycle
register → install → activate → fetch → update

## Cache Strategies

### Cache First (Assets)
Check cache → hit returns → miss fetches network → write to cache

### Network First (API)
Fetch network → fail fallback to cache

### Stale While Revalidate
Return cache + background update for config data

### Offline Fallback
Navigation + offline → return /offline.html

## Background Sync
```js
navigator.serviceWorker.ready.then(reg => {
  reg.sync.register('sync-data');
});
```

## Push Notifications
Server → Web Push API → Service Worker → Show notification → User click → Open page

Best Practices:
- Explain value before requesting permission
- Support silent vs interactive notifications
- Respect user preferences
- Clean up expired notifications

## Performance Targets
- FCP < 1.8s
- LCP < 2.5s
- CLS < 0.1
- TTI < 3.8s
- Lighthouse score ≥ 90