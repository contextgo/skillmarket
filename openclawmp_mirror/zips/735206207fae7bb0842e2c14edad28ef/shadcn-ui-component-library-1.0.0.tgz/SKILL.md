---
name: shadcn-ui-component-library
description: shadcn/ui component patterns: form handling, data tables, dialogs, command palette, dark mode
---

# shadcn/ui Component Patterns

## Overview
Build polished UIs with shadcn/ui + Tailwind CSS + Radix primitives.

## Form Patterns
- react-hook-form + zod validation
- Form fields with error states
- Multi-step form with state management
- Auto-save with debounce

## Data Table
- @tanstack/react-table integration
- Sorting, filtering, pagination
- Row selection with checkboxes
- Column visibility toggle
- Export to CSV/Excel

## Dialog & Sheet
- Dialog for confirmations and forms
- Sheet for side panels and mobile
- Nested dialogs for complex flows
- Keyboard navigation (Escape to close)

## Command Palette
- cmdk integration
- Global keyboard shortcut (Cmd+K)
- Search across pages, actions, settings
- Recent items and quick actions

## Toast Notifications
- Promise-based toasts for async actions
- Action buttons in toast
- Stacking and auto-dismiss
- Custom variants (success, error, warning)

## Dark Mode
- next-themes integration
- System preference detection
- User preference override
- Smooth transition animation
