---
name: message-queue-patterns
description: Message queue patterns: pub/sub, work queue, fan-out, saga orchestration with Kafka & RabbitMQ
---

# Message Queue Architecture Patterns

## Core Patterns

### 1. Work Queue
Producer sends tasks, multiple consumers compete. Use prefetch_count=1 for load balancing.

### 2. Pub/Sub
One message broadcast to multiple consumers. Kafka Topic vs RabbitMQ Exchange.

### 3. Fan-Out
Message replicated to multiple queues. Order created → email + inventory + logging.

### 4. Request/Reply
Async RPC with unique message ID per request.

### 5. Saga Orchestration
Distributed transactions across services.
- Orchestration: central coordinator
- Choreography: each service decides next step

## Kafka vs RabbitMQ

| Feature | Kafka | RabbitMQ |
|---------|-------|----------|
| Throughput | 1M+/sec | 10K+/sec |
| Latency | Medium | Low |
| Retention | Persistent | Delete after consume |
| Protocol | Custom binary | AMQP |
| Best for | Logs/streaming | Task queues/routing |

## Reliability
- ACK: manual mode to prevent loss
- DLQ (Dead Letter Queue): handle failures
- Idempotent consumption: message ID dedup
- Persistence: disk write before confirm

