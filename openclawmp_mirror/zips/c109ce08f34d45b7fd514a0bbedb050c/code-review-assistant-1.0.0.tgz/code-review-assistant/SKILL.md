---
name: code-review-assistant
description: '自动化代码审查助手，检查代码规范、潜在bug、性能问题'
version: 1.0.0
type: skill
tags: ['code-review', 'development', 'quality', 'automation', 'git']
---

# 代码审查助手

> 自动化代码审查助手，检查代码规范、潜在bug、性能问题

## 功能

- 自动检查代码规范（命名、格式、注释）
- 识别潜在bug和安全隐患
- 性能优化建议
- 设计模式检查
- 生成审查报告

## 使用方法

```bash
# 审查单个文件
openclaw skill run code-review --file "src/main.js"

# 审查整个项目
openclaw skill run code-review --path "./src"

# 审查Git提交
openclaw skill run code-review --commit "HEAD~1"
```

## 检查项

### 代码规范
- 命名规范（camelCase、PascalCase）
- 代码格式（缩进、空格、换行）
- 注释完整性
- 文件组织

### 潜在问题
- 空指针引用
- 内存泄漏
- 死代码
- 硬编码
- SQL注入风险

### 性能优化
- 循环优化
- 异步处理
- 资源释放
- 算法复杂度

## 输出示例

```markdown
## 代码审查报告

### 文件：src/utils.js

#### 🔴 严重问题
- 第23行：潜在空指针引用
- 第45行：SQL注入风险

#### 🟡 警告
- 第12行：变量名不规范（应使用camelCase）
- 第34行：缺少注释

#### 🟢 建议
- 第56行：可使用解构赋值优化
- 第78行：考虑使用缓存

### 评分：72/100
```

## 安装

```bash
openclaw skill install code-review-assistant
```
