const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, '..', '..', 'workspace', 'scripts', 'daily-brief.js');
const lines = fs.readFileSync(file, 'utf8').split('\n');
console.log('Function generateBriefV2 at line:', lines.findIndex(l => l.includes('function generateBriefV2')) + 1);
console.log('\nLines 280-340:');
for (let i = 279; i < 340 && i < lines.length; i++) {
  console.log(`${i+1}: ${lines[i]}`);
}