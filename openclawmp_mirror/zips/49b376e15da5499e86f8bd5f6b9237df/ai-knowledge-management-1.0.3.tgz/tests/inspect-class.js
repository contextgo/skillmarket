/**
 * 查看 LocalJSONStorage 类的完整内容
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const code = fs.readFileSync(filePath, 'utf8');

const lines = code.split('\n');

// 找到类开始
const classStart = lines.findIndex(l => l.includes('class LocalJSONStorage'));
console.log(`Class starts at line ${classStart + 1}`);

// 找到 module.exports
const exportIndex = lines.findIndex(l => l.includes('module.exports'));
console.log(`module.exports at line ${exportIndex + 1}`);

// 提取类体（从 class 行到 export 前）
const classBody = lines.slice(classStart, exportIndex);
console.log(`\nClass body (first 20 lines):`);
for (let i = 0; i < 20 && i < classBody.length; i++) {
  console.log(`  ${classStart + i + 1}: ${classBody[i]}`);
}

console.log(`\n... (total ${classBody.length} lines)`);

// 检查每个方法的位置
console.log('\nMethod locations:');
const methodPattern = /^\s*async?\s+(\w+)\s*\(/;
classBody.forEach((line, idx) => {
  const match = line.match(methodPattern);
  if (match) {
    console.log(`  Line ${classStart + idx + 1}: ${match[1]}`);
  }
});

// 检查闭合括号数量
let braceCount = 0;
let lineWithClose = [];
classBody.forEach((line, idx) => {
  for (const ch of line) {
    if (ch === '{') braceCount++;
    if (ch === '}') {
      braceCount--;
      lineWithClose.push({ line: classStart + idx + 1, braces: braceCount });
    }
  }
});
console.log('\nBrace balance at closing braces:');
lineWithClose.forEach(({line, braces}) => {
  console.log(`  Line ${line}: braces = ${braces}`);
});
