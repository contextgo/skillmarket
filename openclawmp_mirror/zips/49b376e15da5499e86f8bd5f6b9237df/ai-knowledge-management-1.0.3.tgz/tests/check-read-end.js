/**
 * 检查 431-454 行之间的内容
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const lines = fs.readFileSync(filePath, 'utf8').split('\n');

console.log('Lines 431-454 (read method end to class end):');
for (let i = 430; i < 454; i++) {
  console.log(`${i+1}: ${lines[i]}`);
}
