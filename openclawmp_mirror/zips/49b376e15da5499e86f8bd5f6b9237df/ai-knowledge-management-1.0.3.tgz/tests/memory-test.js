/**
 * MemoryCore 单元测试（MVP）
 */

const assert = require('assert');
const path = require('path');
const fs = require('fs');

// 清理测试环境
const testDir = path.join(__dirname, '..', 'workspace', 'memory_test');
if (fs.existsSync(testDir)) {
  fs.rmSync(testDir, { recursive: true, force: true });
}

// 加载模块（使用绝对路径）
const skillDir = path.join(__dirname, '..');
const {
  MemoryWriter,
  MemoryRetriever,
  LocalJSONStorage,
  BackgroundMemory,
  EventMemory
} = require(path.join(skillDir, 'src', 'memory-core'));

async function runTests() {
  console.log('🧪 Starting MemoryCore MVP Tests...\n');
  
  // 测试1: 本地存储初始化
  console.log('Test 1: LocalJSONStorage initialization');
  const storage = new LocalJSONStorage(testDir);
  // 构造函数已自动创建目录，无需额外调用
  const stats = await storage.stats();
  assert(Object.keys(stats).length === 6, 'Should create 6 layer directories');
  console.log('✅ Pass: Directories created\n');

  // 测试2: 写入背景记忆
  console.log('Test 2: Write background memory');
  const bgMemory = new BackgroundMemory(storage);
  await bgMemory.set('investment_style', '技术壁垒优先', {
    description: '用户偏好技术壁垒高的项目'
  });
  const style = await bgMemory.get('investment_style');
  assert(style === '技术壁垒优先', 'Should retrieve correct style');
  console.log('✅ Pass: Background memory written and retrieved\n');

  // 测试3: 写入事件记忆
  console.log('Test 3: Write event memory');
  const eventMemory = new EventMemory(storage);
  const event = await eventMemory.add({
    事件标题: '测试事件',
    强度: 4,
    板块: '铝业',
    操作建议: '买入',
    股票代码: '600519'
  });
  assert(event.id.startsWith('evt_'), 'Should generate event ID');
  console.log('✅ Pass: Event memory written\n');

  // 测试4: MemoryWriter 综合测试
  console.log('Test 4: MemoryWriter integration');
  const writer = new MemoryWriter({ storage });
  const record = await writer.write({
    type: 'reflection',
    content: '测试反思：避免重复错误',
    error_type: 'test_error'
  }, {
    source: 'unit_test',
    confidence: 0.9
  });
  assert(record.id.startsWith('reflection_'), 'Should generate reflection ID');
  console.log('✅ Pass: MemoryWriter integration\n');

  // 测试5: MemoryRetriever 检索
  console.log('Test 5: MemoryRetriever');
  const retriever = new MemoryRetriever({ storage });
  const result = await retriever.retrieve('投资偏好');
  assert(result.memories.length >= 1, 'Should find at least 1 memory');
  assert(result.context.includes('背景记忆'), 'Should format with type label');
  console.log('✅ Pass: Memory retrieval works\n');

  // 输出统计
  console.log('📊 Final memory stats:');
  const finalStats = await storage.stats();
  for (const [layer, count] of Object.entries(finalStats)) {
    console.log(`   ${layer}: ${count} records`);
  }

  console.log('\n✅ All MVP tests passed!');
}

runTests().catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
