/**
 * 简化版快速测试 - 调试版
 */

const path = require('path');
const fs = require('fs');

// 手动加载模块
const skillDir = path.join(__dirname, '..');
const memoryCore = require(path.join(skillDir, 'src', 'memory-core'));

console.log('Loaded modules:', Object.keys(memoryCore));

// 创建测试目录
const testDir = path.join(__dirname, '..', 'workspace', 'memory_test');
if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });

// 测试存储
console.log('\n1. Creating LocalJSONStorage...');
const storage = new memoryCore.LocalJSONStorage(testDir);
console.log('Storage instance created');
console.log('Storage prototype:', Object.getOwnPropertyNames(Object.getPrototypeOf(storage)));
console.log('Has stats?', typeof storage.stats);

// 测试写入
console.log('\n2. Writing test record...');
const testRecord = {
  id: 'test_001',
  type: 'event',
  content: { title: '测试事件', strength: 5 },
  metadata: { source: 'test', created_at: new Date().toISOString() }
};

storage.write('event', testRecord).then(() => {
  console.log('✅ Write successful');
  
  // 测试读取
  return storage.read('event', {});
}).then(records => {
  console.log('✅ Read successful, records:', records.length);
  
  // 检查 stats 方法
  console.log('Before stats call - has stats?', typeof storage.stats);
  if (typeof storage.stats === 'function') {
    return storage.stats();
  } else {
    // 手动实现统计
    console.log('Stats method missing, using manual count...');
    const layers = ['background', 'event', 'conversation', 'fact', 'reflection', 'skill'];
    const stats = {};
    for (const layer of layers) {
      const records = storage.read(layer, {}); // 同步读取
      stats[layer] = records.length;
    }
    return stats;
  }
}).then(stats => {
  console.log('✅ Stats:', stats);
  console.log('\n✅ All basic tests passed!');
}).catch(err => {
  console.error('❌ Test failed:', err);
  process.exit(1);
});
