const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, '..', 'src', 'memory-core.js');
const lines = fs.readFileSync(file, 'utf8').split('\n');
console.log('Lines 390-467:');
for (let i = 389; i < lines.length; i++) {
  console.log(`${i+1}: ${lines[i]}`);
}