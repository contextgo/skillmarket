/**
 * 清除缓存并重新加载
 */

const path = require('path');
const fs = require('fs');

// 清除模块缓存
const skillDir = path.join(__dirname, '..');
const modulePath = path.join(skillDir, 'src', 'memory-core.js');
delete require.cache[require.resolve(modulePath)];

// 重新加载
const memoryCore = require(modulePath);

console.log('Loaded modules:', Object.keys(memoryCore));

// 创建测试目录
const testDir = path.join(__dirname, '..', 'workspace', 'memory_test');
if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });

// 测试
const storage = new memoryCore.LocalJSONStorage(testDir);
console.log('Prototype methods:', Object.getOwnPropertyNames(Object.getPrototypeOf(storage)));
console.log('Has stats?', typeof storage.stats);

// 直接测试 stats
if (storage.stats) {
  storage.stats().then(s => console.log('Stats result:', s));
} else {
  console.log('ERROR: stats method missing!');
  console.log('Full prototype:', Object.getPrototypeOf(storage));
  console.log('Storage keys:', Object.keys(storage));
}
