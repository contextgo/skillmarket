/**
 * 搜索 update, stats 等关键字的位置
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const lines = fs.readFileSync(filePath, 'utf8').split('\n');

const keywords = ['async update', 'async delete', 'getFilePath', 'async stats', 'async cleanup', 'ensureDirectories'];

keywords.forEach(kw => {
  for (let i = 0; i < lines.length; i++) {
    if (lines[i].includes(kw)) {
      console.log(`${kw} found at line ${i+1}: ${lines[i].trim()}`);
      break;
    }
  }
});

// 输出 440-460 行的完整内容
console.log('\nLines 440-460:');
for (let i = 439; i < 460 && i < lines.length; i++) {
  console.log(`${i+1}: ${lines[i]}`);
}
