/**
 * 分析 memory-core.js 中的 LocalJSONStorage
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const code = fs.readFileSync(filePath, 'utf8');

console.log('File length:', code.length);

// 找到 LocalJSONStorage 类
const classMatch = code.match(/class LocalJSONStorage\s*{([\s\S]*?)}\s*module\.exports/);
if (classMatch) {
  const classBody = classMatch[1];
  console.log('Class body length:', classBody.length);
  
  // 提取方法
  const methods = classBody.match(/async\s+(\w+)\s*\(/g) || [];
  console.log('Async methods found:', methods.length, methods);
  
  const syncMethods = classBody.match(/(\w+)\s*\([^)]*\)\s*{/g) || [];
  console.log('Sync methods found:', syncMethods.length, syncMethods);
  
  // 检查是否有 stats
  console.log('Has stats?', classBody.includes('stats()'));
} else {
  console.log('Could not find class');
}

// 直接 require 测试
const mod = require(filePath);
console.log('\nExported keys:', Object.keys(mod));

const storage = new mod.LocalJSONStorage('test_dir');
const proto = Object.getPrototypeOf(storage);
console.log('Prototype methods:', Object.getOwnPropertyNames(proto));
console.log('Has stats on proto?', typeof proto.stats);
console.log('storage.stats:', typeof storage.stats);
