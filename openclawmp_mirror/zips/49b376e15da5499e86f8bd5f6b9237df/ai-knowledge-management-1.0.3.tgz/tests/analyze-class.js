/**
 * 分析 LocalJSONStorage 类定义
 */

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const filePath = path.join(__dirname, '..', 'src', 'storage', 'local-json.js');
const code = fs.readFileSync(filePath, 'utf8');

console.log('File loaded, length:', code.length);
console.log('Contains "class LocalJSONStorage":', code.includes('class LocalJSONStorage'));

// 尝试提取类定义部分
const classMatch = code.match(/class LocalJSONStorage\s*{([\s\S]*?)}/);
if (classMatch) {
  const classBody = classMatch[1];
  console.log('Class body length:', classBody.length);
  
  // 提取所有方法名
  const methods = classBody.match(/async\s+(\w+)\s*\(/g) || [];
  console.log('Methods found:', methods);
  
  // 统计方法数
  const methodNames = methods.map(m => m.replace('async', '').trim().split(' ')[0]);
  console.log('Method names:', methodNames);
} else {
  console.log('ERROR: Could not extract class body');
}

// 尝试直接 require
try {
  const mod = require(filePath);
  console.log('Module exports:', Object.keys(mod));
  const storage = new mod.LocalJSONStorage('test');
  console.log('Instance prototype:', Object.getOwnPropertyNames(Object.getPrototypeOf(storage)));
} catch (e) {
  console.error('Require error:', e);
}
