/**
 * 调试：打印 storage 对象
 */

const path = require('path');
const fs = require('fs');

const skillDir = path.join(__dirname, '..');
const memoryCore = require(path.join(skillDir, 'src', 'memory-core'));

const testDir = path.join(__dirname, '..', 'workspace', 'memory_test');
if (fs.existsSync(testDir)) fs.rmSync(testDir, { recursive: true, force: true });

const storage = new memoryCore.LocalJSONStorage(testDir);

console.log('Storage object keys:', Object.keys(storage));
console.log('Storage prototype keys:', Object.getOwnPropertyNames(Object.getPrototypeOf(storage)));
console.log('Full storage prototype:', Object.getPrototypeOf(storage));

// 检查是否有 stats 属性（包括不可枚举）
console.log('stats in prototype?', Object.getPrototypeOf(storage).hasOwnProperty('stats'));
console.log('storage.stats type:', typeof storage.stats);

// 尝试直接调用
if (storage.stats) {
  storage.stats().then(console.log).catch(console.error);
} else {
  console.log('stats method not found on instance');
  
  // 查看 prototype 所有属性（包括继承）
  console.log('All prototype properties:', Object.getPrototypeOf(storage));
}
