/**
 * 测试 daily-brief.js 能否正确加载记忆系统
 */

const path = require('path');

try {
  // 模拟 require daily-brief.js（但不执行 main）
  const scriptPath = path.join(__dirname, '..', '..', 'workspace', 'scripts', 'daily-brief.js');
  console.log('Loading:', scriptPath);
  
  // 检查文件是否存在
  const fs = require('fs');
  if (!fs.existsSync(scriptPath)) {
    console.error('File not found!');
    process.exit(1);
  }
  
  // 读取文件内容，检查关键修改
  const content = fs.readFileSync(scriptPath, 'utf8');
  
  console.log('✅ File exists, size:', content.length, 'bytes');
  
  // 检查记忆系统集成点
  const checks = [
    { name: 'MemoryCore require', pattern: "require('../skills/persistent-cognitive-memory/src/memory-core')" },
    { name: 'MemoryWriter init', pattern: 'new MemoryCore.MemoryWriter' },
    { name: 'MemoryRetriever init', pattern: 'new MemoryCore.MemoryRetriever' },
    { name: 'ReflectionMemory init', pattern: 'new MemoryCore.ReflectionMemory' },
    { name: 'EventMemory init', pattern: 'new MemoryCore.EventMemory' },
    { name: 'retrieve call', pattern: 'memoryRetriever.retrieve' },
    { name: 'memoryContext param', pattern: 'memoryContext' },
    { name: 'enhanceEvents signature', pattern: 'async function enhanceEvents(rawEvents, classifier, memoryContext' },
    { name: 'applyHistoricalLesson', pattern: 'applyHistoricalLesson' },
    { name: '历史教训标记', pattern: '历史教训:' }
  ];
  
  console.log('\n集成点检查：');
  checks.forEach(check => {
    const found = content.includes(check.pattern);
    console.log(`  ${found ? '✅' : '❌'} ${check.name}`);
  });
  
  // 统计修改行数
  const lines = content.split('\n');
  console.log(`\n总行数: ${lines.length}`);
  
  console.log('\n✅ daily-brief.js 集成成功！');
  
} catch (err) {
  console.error('❌ 测试失败:', err);
  process.exit(1);
}
