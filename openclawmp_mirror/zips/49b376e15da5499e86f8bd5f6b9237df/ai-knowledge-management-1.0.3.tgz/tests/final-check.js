/**
 * 测试 daily-brief.js 集成
 */

const fs = require('fs');
const path = require('path');

// 绝对路径
const scriptPath = 'C:\\Users\\22812\\.openclaw-autoclaw\\workspace\\scripts\\daily-brief.js';

console.log('Checking:', scriptPath);

if (!fs.existsSync(scriptPath)) {
  console.error('❌ File not found!');
  process.exit(1);
}

const content = fs.readFileSync(scriptPath, 'utf8');
console.log('✅ File exists, size:', content.length, 'bytes\n');

// 集成点检查
const checks = [
  { name: 'MemoryCore require', pattern: "require('../skills/persistent-cognitive-memory/src/memory-core')" },
  { name: 'MemoryWriter init', pattern: 'new MemoryCore.MemoryWriter' },
  { name: 'MemoryRetriever init', pattern: 'new MemoryCore.MemoryRetriever' },
  { name: 'ReflectionMemory init', pattern: 'new MemoryCore.ReflectionMemory' },
  { name: 'EventMemory init', pattern: 'new MemoryCore.EventMemory' },
  { name: 'retrieve call', pattern: 'memoryRetriever.retrieve' },
  { name: 'memoryContext variable', pattern: 'memoryContext' },
  { name: 'enhanceEvents with memoryContext', pattern: 'enhanceEvents(rawEvents, classifier, memoryContext)' },
  { name: 'applyHistoricalLesson function', pattern: 'applyHistoricalLesson' },
  { name: '历史教训字段', pattern: '历史教训:' }
];

console.log('集成点检查：');
let passed = 0;
checks.forEach(check => {
  const found = content.includes(check.pattern);
  console.log(`  ${found ? '✅' : '❌'} ${check.name}`);
  if (found) passed++;
});

console.log(`\n通过: ${passed}/${checks.length}`);

if (passed === checks.length) {
  console.log('\n✅ daily-brief.js 强记忆系统集成完成！');
} else {
  console.log('\n⚠️ 部分集成点未检测到');
}
