/**
 * 查看 454 行之后的内容
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const lines = fs.readFileSync(filePath, 'utf8').split('\n');

console.log('Lines 454-470:');
for (let i = 453; i < Math.min(470, lines.length); i++) {
  console.log(`${i+1}: ${lines[i]}`);
}
