const fs = require('fs');
const path = require('path');
const file = path.join(__dirname, '..', 'scripts', 'daily-brief.js');
const lines = fs.readFileSync(file, 'utf8').split('\n');
console.log('Lines containing "function generateBriefV2":');
lines.forEach((l, i) => {
  if (l.includes('function generateBriefV2')) console.log(`${i+1}: ${l}`);
});
console.log('\nLines 280-320:');
for (let i = 279; i < 320 && i < lines.length; i++) {
  console.log(`${i+1}: ${lines[i]}`);
}