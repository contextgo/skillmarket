/**
 * 生成补丁：在 LocalJSONStorage 类的 read 方法后插入缺失的方法
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
let content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

// 找到 read 方法结束的位置（第453行 "  }"）
// 在该位置后插入新方法

const insertIndex = 453; // 0-based is 452

const newMethods = `
  /**
   * 更新记录
   */
  async update(layer, recordId, updates) {
    const all = await this.read(layer, {});
    const idx = all.findIndex(r => r.id === recordId);
    if (idx === -1) throw new Error(\`Record not found: \${recordId}\`);
    all[idx] = { ...all[idx], ...updates };
    const filePath = this.getFilePathByRecord(layer, all[idx]);
    fs.writeFileSync(filePath, JSON.stringify(all, null, 2));
    return all[idx];
  }

  /**
   * 删除（标记）
   */
  async delete(layer, recordId) {
    const all = await this.read(layer, {});
    const rec = all.find(r => r.id === recordId);
    if (rec) {
      rec.metadata.deleted = true;
      rec.metadata.deleted_at = new Date().toISOString();
      await this.update(layer, recordId, rec);
    }
    return true;
  }

  /**
   * 文件路径（按日期）
   */
  getFilePath(layer, record) {
    const date = record.metadata?.created_at 
      ? new Date(record.metadata.created_at).toISOString().split('T')[0]
      : new Date().toISOString().split('T')[0];
    return path.join(this.basePath, layer, \`\${date}.json\`);
  }

  getFilePathByRecord(layer, record) {
    return this.getFilePath(layer, record);
  }

  /**
   * 统计各层记录数
   */
  async stats() {
    const layers = ['background', 'event', 'conversation', 'fact', 'reflection', 'skill'];
    const stats = {};
    for (const layer of layers) {
      const records = await this.read(layer, {});
      stats[layer] = records.length;
    }
    return stats;
  }

  /**
   * 清理（占位）
   */
  async cleanup(retentionDays = 90) {
    console.log('[LocalJSONStorage] Cleanup not implemented in MVP');
  }
`;

// 在 insertIndex 行后插入（0-based -> 1-based line 454）
lines.splice(insertIndex, 0, newMethods);

// 写回文件
const newContent = lines.join('\n');
fs.writeFileSync(filePath, newContent);

console.log('✅ Inserted missing methods after line', insertIndex + 1);
console.log('New total lines:', lines.length);
