/**
 * 强制清除缓存并重新加载
 */

const path = require('path');
const fs = require('fs');

// 1. 清除所有相关缓存
const modulesToClear = [];
for (const key in require.cache) {
  if (key.includes('persistent-cognitive-memory')) {
    modulesToClear.push(key);
    delete require.cache[key];
  }
}
console.log('Cleared modules:', modulesToClear.length);

// 2. 直接读取文件内容并 eval（绕过 require 缓存）
const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const code = fs.readFileSync(filePath, 'utf8');

// 3. 使用 vm 运行代码
const vm = require('vm');
const context = { module: {}, exports: {}, require: require };
vm.createContext(context);
vm.runInContext(code, context);

// 4. 从 context 中获取 LocalJSONStorage
const LocalJSONStorage = context.module.exports.LocalJSONStorage || context.exports.LocalJSONStorage;

console.log('Got LocalJSONStorage:', typeof LocalJSONStorage);

if (LocalJSONStorage) {
  const storage = new LocalJSONStorage('test_vm');
  const proto = Object.getPrototypeOf(storage);
  console.log('Prototype methods:', Object.getOwnPropertyNames(proto));
  console.log('Has stats?', typeof storage.stats);
  
  // 测试调用
  if (storage.stats) {
    storage.stats().then(s => console.log('Stats:', s));
  }
} else {
  console.log('Failed to load LocalJSONStorage');
  console.log('Context module.exports:', context.module.exports);
}
