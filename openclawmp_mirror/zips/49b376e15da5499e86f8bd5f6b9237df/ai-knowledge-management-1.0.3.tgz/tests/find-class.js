/**
 * 找到 LocalJSONStorage 类在文件中的位置
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const code = fs.readFileSync(filePath, 'utf8');

const lines = code.split('\n');
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('class LocalJSONStorage')) {
    console.log(`Line ${i+1}: ${lines[i]}`);
    console.log('Next 5 lines:');
    for (let j = i; j < Math.min(i+6, lines.length); j++) {
      console.log(`  ${j+1}: ${lines[j]}`);
    }
    break;
  }
}

// 检查类结束位置
for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('module.exports')) {
    console.log(`\nmodule.exports at line ${i+1}`);
    console.log('Previous 10 lines:');
    for (let j = i-10; j < i; j++) {
      if (j >= 0) console.log(`  ${j+1}: ${lines[j]}`);
    }
    break;
  }
}
