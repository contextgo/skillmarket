/**
 * 在 memory-core.js 中搜索 LocalJSONStorage 类定义
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const content = fs.readFileSync(filePath, 'utf8');
const lines = content.split('\n');

// 找到所有 "class LocalJSONStorage" 出现的位置
const indices = [];
lines.forEach((line, idx) => {
  if (line.includes('class LocalJSONStorage')) {
    indices.push(idx + 1);
  }
});

console.log('"class LocalJSONStorage" appears at lines:', indices);

// 找到所有 "module.exports" 行
const exportLines = [];
lines.forEach((line, idx) => {
  if (line.includes('module.exports')) {
    exportLines.push(idx + 1);
  }
});
console.log('"module.exports" at lines:', exportLines);

// 检查文件末尾
console.log('\nLast 20 lines:');
for (let i = Math.max(0, lines.length - 20); i < lines.length; i++) {
  console.log(`${i+1}: ${lines[i]}`);
}

// 检查文件是否被截断
console.log('\nTotal lines:', lines.length);
console.log('Last line:', lines[lines.length - 1]);
