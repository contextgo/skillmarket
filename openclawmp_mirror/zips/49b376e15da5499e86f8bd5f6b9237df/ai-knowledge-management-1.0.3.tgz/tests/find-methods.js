/**
 * 找到所有方法定义的行号
 */

const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '..', 'src', 'memory-core.js');
const lines = fs.readFileSync(filePath, 'utf8').split('\n');

console.log('Searching for method definitions in LocalJSONStorage class...\n');

let inClass = false;
const methods = [];

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  
  if (line.includes('class LocalJSONStorage')) {
    inClass = true;
    console.log(`Class starts at line ${i+1}`);
  }
  
  if (inClass) {
    // 检测方法定义
    const match = line.match(/^\s*async?\s+(\w+)\s*\(/);
    if (match) {
      methods.push({ name: match[1], line: i+1 });
      console.log(`Method ${match[1]} at line ${i+1}`);
    }
    
    // 检测类结束
    if (line === '}' && i > 0) {
      // 检查上一行是否是方法结束
      const prevLine = lines[i-1];
      if (prevLine.trim() === '}' || prevLine.includes('}')) {
        // 可能是类结束
        console.log(`Possible class end at line ${i+1}`);
      }
    }
    
    if (line.includes('module.exports')) {
      console.log(`\nmodule.exports at line ${i+1}`);
      break;
    }
  }
}

console.log('\nTotal methods found:', methods.length);
console.log('Method list:', methods.map(m => m.name).join(', '));
