/**
 * LocalJSONStorage - 本地JSON存储（MVP）
 * 
 * 文件结构：
 * workspace/memory/
 *   ├── background.json          # 背景记忆
 *   ├── event/2026-04-07.json   # 事件记忆（按日分片）
 *   ├── conversation/           # 对话摘要
 *   ├── fact/                   # 事实库
 *   ├── reflection/             # 反思日志
 *   └── skill/                  # 技能记录
 */

const fs = require('fs');
const path = require('path');

class LocalJSONStorage {
  constructor(basePath = 'workspace/memory') {
    this.basePath = basePath;
    this.ensureDirectories();
  }

  /**
   * 创建目录结构
   */
  ensureDirectories() {
    const layers = ['background', 'event', 'conversation', 'fact', 'reflection', 'skill'];
    if (!fs.existsSync(this.basePath)) {
      fs.mkdirSync(this.basePath, { recursive: true });
    }
    layers.forEach(layer => {
      const dir = path.join(this.basePath, layer);
      if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    });
  }

  /**
   * 写入记录
   */
  async write(layer, record) {
    const filePath = this.getFilePath(layer, record);
    let data = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath, 'utf8')) : [];
    data.push(record);
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
    return record;
  }

  /**
   * 读取记录
   */
  async read(layer, query = {}) {
    const dirPath = path.join(this.basePath, layer);
    if (!fs.existsSync(dirPath)) return [];
    const files = fs.readdirSync(dirPath).filter(f => f.endsWith('.json'));
    let all = [];
    for (const file of files) {
      try {
        const data = JSON.parse(fs.readFileSync(path.join(dirPath, file), 'utf8'));
        all.push(...data);
      } catch (e) { /* 跳过损坏文件 */ }
    }
    // 简单过滤
    if (query.id) all = all.filter(r => r.id === query.id);
    if (query.startDate) {
      const start = new Date(query.startDate);
      all = all.filter(r => new Date(r.metadata?.created_at) >= start);
    }
    return all;
  }

  /**
   * 更新记录
   */
  async update(layer, recordId, updates) {
    const all = await this.read(layer, {});
    const idx = all.findIndex(r => r.id === recordId);
    if (idx === -1) throw new Error(`Record not found: ${recordId}`);
    all[idx] = { ...all[idx], ...updates };
    const filePath = this.getFilePathByRecord(layer, all[idx]);
    fs.writeFileSync(filePath, JSON.stringify(all, null, 2));
    return all[idx];
  }

  /**
   * 删除（标记）
   */
  async delete(layer, recordId) {
    const all = await this.read(layer, {});
    const rec = all.find(r => r.id === recordId);
    if (rec) {
      rec.metadata.deleted = true;
      rec.metadata.deleted_at = new Date().toISOString();
      await this.update(layer, recordId, rec);
    }
    return true;
  }

  /**
   * 文件路径（按日期）
   */
  getFilePath(layer, record) {
    const date = record.metadata?.created_at 
      ? new Date(record.metadata.created_at).toISOString().split('T')[0]
      : new Date().toISOString().split('T')[0];
    return path.join(this.basePath, layer, `${date}.json`);
  }

  getFilePathByRecord(layer, record) {
    return this.getFilePath(layer, record);
  }

  /**
   * 统计各层记录数
   */
  async stats() {
    const layers = ['background', 'event', 'conversation', 'fact', 'reflection', 'skill'];
    const stats = {};
    for (const layer of layers) {
      const records = await this.read(layer, {});
      stats[layer] = records.length;
    }
    return stats;
  }

  /**
   * 清理（占位）
   */
  async cleanup(retentionDays = 90) {
    console.log('[LocalJSONStorage] Cleanup not implemented in MVP');
  }
}

module.exports = { LocalJSONStorage };
