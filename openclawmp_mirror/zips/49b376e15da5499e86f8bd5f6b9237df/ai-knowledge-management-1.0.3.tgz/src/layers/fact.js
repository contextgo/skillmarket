/**
 * FactMemory - 事实记忆层
 * 存储：结构化、可验证的数据
 * 特性：版本控制、来源溯源、冲突检测
 */

class FactMemory {
  constructor(storage) {
    this.storage = storage;
    this.layer = 'fact';
  }

  /**
   * 写入事实（带版本控制）
   */
  async set(content, source, options = {}) {
    // 1. 检测是否已存在（冲突检测）
    const existing = await this.findSimilar(content);
    
    let record = {
      id: this.generateFactId(content),
      type: 'fact',
      content,
      metadata: {
        source,
        source_weight: options.sourceWeight || this.getSourceWeight(source),
        confidence: options.confidence || 1.0,
        created_at: new Date().toISOString(),
        version: 1
      }
    };

    // 2. 如果存在相似事实，处理冲突
    if (existing.length > 0) {
      console.log(`[FactMemory] Found ${existing.length} similar facts, checking conflicts...`);
      record = await this.handleConflict(record, existing);
    }

    // 3. 存储
    await this.storage.write(this.layer, record);
    return record;
  }

  /**
   * 生成事实ID（基于内容哈希）
   */
  generateFactId(content) {
    const crypto = require('crypto');
    const hash = crypto.createHash('sha256');
    hash.update(JSON.stringify(content));
    return `fact_${hash.digest('hex').substring(0, 16)}`;
  }

  /**
   * 查找相似事实
   */
  async findSimilar(content) {
    const all = await this.storage.read(this.layer, {});
    const key = Object.values(content)[0];  // 简化：匹配第一个值
    
    return all.filter(r => 
      JSON.stringify(r.content).includes(key)
    );
  }

  /**
   * 处理冲突（MVP：简单标记）
   */
  async handleConflict(newFact, existingFacts) {
    // 标记冲突，不自动解决（MVP）
    console.warn(`[FactMemory] Conflict detected but not auto-resolved in MVP`);
    
    return {
      ...newFact,
      metadata: {
        ...newFact.metadata,
        conflicts: existingFacts.map(e => e.id),
        needs_review: true
      }
    };
  }

  /**
   * 获取来源权重
   */
  getSourceWeight(source) {
    const weights = {
      '巨潮资讯公告': 1.0,
      '政策文件': 1.0,
      '券商研报': 0.8,
      '行业会议': 0.9,
      '新闻媒体': 0.6,
      '用户分析': 0.5,
      '群聊讨论': 0.3
    };
    return weights[source] || 0.5;
  }

  /**
   * 查询事实
   */
  async query(keyword) {
    const all = await this.storage.read(this.layer, {});
    return all.filter(r => 
      JSON.stringify(r.content).includes(keyword)
    );
  }

  /**
   * 更新事实（版本控制）
   */
  async update(factId, newContent, source) {
    const all = await this.storage.read(this.layer, {});
    const index = all.findIndex(r => r.id === factId);
    
    if (index === -1) throw new Error(`Fact not found: ${factId}`);

    const current = all[index];
    const newVersion = current.metadata.version + 1;

    // 创建新版本
    const updated = {
      ...current,
      content: { ...current.content, ...newContent },
      metadata: {
        ...current.metadata,
        version: newVersion,
        last_updated: new Date().toISOString(),
        update_source: source
      }
    };

    await this.storage.update(this.layer, factId, updated);
    return updated;
  }
}

module.exports = { FactMemory };
