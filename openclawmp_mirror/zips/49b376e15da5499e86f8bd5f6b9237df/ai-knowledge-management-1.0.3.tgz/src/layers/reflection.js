/**
 * ReflectionMemory - 反思记忆层
 * 存储：错误教训、策略改进、认知迭代
 * 
 * 核心价值：将每次失误转化为系统优势
 */

class ReflectionMemory {
  constructor(storage) {
    this.storage = storage;
    this.layer = 'reflection';
  }

  /**
   * 记录误判/教训
   */
  async record(reflectionData, metadata = {}) {
    const record = {
      id: `ref_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      type: 'reflection',
      content: {
        title: reflectionData.title,
        event_id: reflectionData.eventId,
        error_type: reflectionData.errorType,
        initial_judgment: reflectionData.initialJudgment,
        ground_truth: reflectionData.groundTruth,
        root_causes: reflectionData.rootCauses || [],
        corrective_actions: reflectionData.correctiveActions || [],
        validation: reflectionData.validation || ""
      },
      metadata: {
        ...metadata,
        layer: this.layer,
        severity: reflectionData.severity || 'medium',
        status: 'open',  // open / resolved / verified
        created_at: new Date().toISOString(),
        related_events: reflectionData.relatedEvents || []
      }
    };

    await this.storage.write(this.layer, record);
    console.log(`[ReflectionMemory] Recorded: ${record.content.title}`);
    return record;
  }

  /**
   * 快速记录模板：量化系统误判
   */
  async recordQuantError(eventData, mistake, fix, validation) {
    return await this.record({
      title: `${eventData.事件标题} - 误判复盘`,
      eventId: eventData.id,
      errorType: mistake.type,
      initialJudgment: mistake.initial,
      groundTruth: fix.correct,
      rootCauses: mistake.causes,
      correctiveActions: fix.actions,
      validation: validation
    }, { source: 'quant-system' });
  }

  /**
   * 查询教训（按错误类型）
   */
  async getByErrorType(errorType) {
    const all = await this.storage.read(this.layer, {});
    return all.filter(r => r.content.error_type === errorType);
  }

  /**
   * 查询相关教训（按事件）
   */
  async getRelatedToEvent(eventId) {
    const all = await this.storage.read(this.layer, {});
    return all.filter(r => 
      r.content.event_id === eventId || 
      r.metadata.related_events?.includes(eventId)
    );
  }

  /**
   * 验证改进效果
   */
  async verify(recordId, result) {
    const all = await this.storage.read(this.layer, {});
    const record = all.find(r => r.id === recordId);
    
    if (record) {
      record.metadata.status = 'verified';
      record.content.validation = result;
      await this.storage.update(this.layer, recordId, record);
    }
    
    return record;
  }

  /**
   * 获取统计（错误类型分布）
   */
  async getStats() {
    const all = await this.storage.read(this.layer, {});
    const stats = {};
    
    all.forEach(r => {
      const type = r.content.error_type || 'unknown';
      stats[type] = (stats[type] || 0) + 1;
    });
    
    return stats;
  }
}

module.exports = { ReflectionMemory };
