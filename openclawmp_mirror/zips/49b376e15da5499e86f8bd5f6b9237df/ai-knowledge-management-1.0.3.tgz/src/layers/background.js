/**
 * BackgroundMemory - 背景记忆层
 * 存储：价值观、投资哲学、风险偏好（只读，手动更新）
 */

class BackgroundMemory {
  constructor(storage) {
    this.storage = storage;
    this.layer = 'background';
    this.cache = null;
  }

  /**
   * 写入背景记忆（通常由用户手动设置）
   */
  async set(category, content, metadata = {}) {
    const record = {
      id: `bg_${category}_${Date.now()}`,
      type: 'background',
      content: {
        category,
        value: content,
        description: metadata.description || ''
      },
      metadata: {
        ...metadata,
        layer: this.layer,
        is_manual: true,
        created_at: new Date().toISOString()
      }
    };

    await this.storage.write(this.layer, record);
    this.invalidateCache();
    return record;
  }

  /**
   * 获取所有背景记忆
   */
  async getAll() {
    if (this.cache) return this.cache;

    const records = await this.storage.read(this.layer, {});
    this.cache = records.reduce((acc, r) => {
      acc[r.content.category] = r.content.value;
      return acc;
    }, {});

    return this.cache;
  }

  /**
   * 获取特定类别
   */
  async get(category) {
    const all = await this.getAll();
    return all[category];
  }

  invalidateCache() {
    this.cache = null;
  }
}

module.exports = { BackgroundMemory };
