/**
 * EventMemory - 事件记忆层
 * 存储：投资事件时间线
 * 与飞书多维表格"事件列表"双向同步
 */

class EventMemory {
  constructor(storage) {
    this.storage = storage;
    this.layer = 'event';
  }

  /**
   * 写入事件（从量化系统导入）
   */
  async add(eventData, metadata = {}) {
    const record = {
      id: `evt_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`,
      type: 'event',
      content: {
        title: eventData.事件标题,
        strength: eventData.强度,
        sector: eventData.板块,
        action: eventData.操作建议,
        stock_code: eventData.股票代码,
        catalyst_date: eventData.催化剂时间,
        source: eventData.来源,
        description: eventData.备注 || ''
      },
      metadata: {
        ...metadata,
        layer: this.layer,
        bitable_table_id: 'HuDGbljblaFt40s0sW2crop2nqh',  // 关联多维表格
        imported_at: new Date().toISOString()
      }
    };

    // 同时写入本地缓存
    await this.storage.write(this.layer, record);

    // TODO: 同步到飞书多维表格（未来）
    // await this.syncToBitable(record);

    return record;
  }

  /**
   * 查询事件（支持多种维度）
   */
  async query(options = {}) {
    const all = await this.storage.read(this.layer, {});
    
    let results = all;

    // 按板块过滤
    if (options.sector) {
      results = results.filter(r => r.content.sector === options.sector);
    }

    // 按强度过滤
    if (options.minStrength) {
      results = results.filter(r => r.content.strength >= options.minStrength);
    }

    // 按时间范围
    if (options.startDate) {
      results = results.filter(r => 
        r.metadata.created_at >= options.startDate
      );
    }

    // 按股票代码
    if (options.stockCode) {
      results = results.filter(r => 
        r.content.stock_code === options.stockCode
      );
    }

    // 排序（默认时间倒序）
    results.sort((a, b) => 
      new Date(b.metadata.created_at) - new Date(a.metadata.created_at)
    );

    return results;
  }

  /**
   * 获取相关事件（用于多跳推理）
   */
  async getRelated(eventId, limit = 5) {
    const event = await this.storage.read(this.layer, { id: eventId });
    if (!event || event.length === 0) return [];

    const target = event[0];
    const all = await this.storage.read(this.layer, {});
    
    // 按相同板块 + 相同类型排序
    return all
      .filter(e => e.id !== eventId && e.content.sector === target.content.sector)
      .slice(0, limit);
  }

  /**
   * 同步到多维表格（TODO）
   */
  async syncToBitable(record) {
    // 未来实现：将事件记忆同步回飞书多维表格
    // 这样多维表格既是数据源，也是记忆存储
    console.log(`[EventMemory] Sync to bitable not implemented yet`);
  }
}

module.exports = { EventMemory };
