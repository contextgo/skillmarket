/**
 * ConversationMemory - 对话记忆层
 * 存储：会话摘要（压缩后）
 * 
 * 压缩目标：原始对话 1000 tokens → 摘要 150 tokens
 */

class ConversationMemory {
  constructor(storage) {
    this.storage = storage;
    this.layer = 'conversation';
  }

  /**
   * 写入对话摘要
   */
  async summarize(sessionId, dialogue, metadata = {}) {
    // MVP：简单截断
    // V2：调用LLM提取摘要
    const summary = this.compress(dialogue);
    
    const record = {
      id: `conv_${sessionId}_${Date.now()}`,
      type: 'conversation',
      content: {
        summary,
        key_entities: this.extractEntities(dialogue),
        decisions: this.extractDecisions(dialogue),
        full_text: dialogue.length < 500 ? dialogue : null  // 短对话保留原文
      },
      metadata: {
        ...metadata,
        layer: this.layer,
        session_id: sessionId,
        original_length: dialogue.length,
        compressed_length: summary.length,
        compression_ratio: ((dialogue.length - summary.length) / dialogue.length * 100).toFixed(1) + '%'
      }
    };

    await this.storage.write(this.layer, record);
    return record;
  }

  /**
   * 压缩算法（MVP）
   */
  compress(text) {
    if (text.length < 300) return text;
    
    // 保留首尾，中间截断
    const head = text.substring(0, 150);
    const tail = text.substring(text.length - 150);
    return `${head}...[省略${text.length - 300}字]...${tail}`;
  }

  extractEntities(text) {
    // TODO: 提取人名、股票代码、日期等实体
    return [];
  }

  extractDecisions(text) {
    // TODO: 提取决策点（买入/卖出/观望）
    return [];
  }

  /**
   * 按会话查询
   */
  async getBySession(sessionId) {
    const all = await this.storage.read(this.layer, {});
    return all.filter(r => r.metadata.session_id === sessionId);
  }
}

module.exports = { ConversationMemory };
