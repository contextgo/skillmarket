/**
 * SkillMemory - 技能记忆层
 * 存储：工具使用模式、成功率、优化历史
 */

class SkillMemory {
  constructor(storage) {
    this.storage = storage;
    this.layer = 'skill';
  }

  /**
   * 记录技能使用
   */
  async recordUsage(skillId, context, success, metadata = {}) {
    const record = {
      id: `skill_${skillId}_${Date.now()}`,
      type: 'skill',
      content: {
        skill_id: skillId,
        scenario: context.scenario,
        parameters: context.parameters || {},
        outcome: success ? 'success' : 'failure',
        notes: context.notes || ''
      },
      metadata: {
        ...metadata,
        layer: this.layer,
        success: success,
        used_at: new Date().toISOString()
      }
    };

    await this.storage.write(this.layer, record);
    return record;
  }

  /**
   * 获取技能使用统计
   */
  async getStats(skillId) {
    const all = await this.storage.read(this.layer, {});
    const skillUsages = all.filter(r => r.content.skill_id === skillId);
    
    const total = skillUsages.length;
    const successes = skillUsages.filter(r => r.metadata.success).length;
    const successRate = total > 0 ? (successes / total * 100).toFixed(1) + '%' : 'N/A';

    return {
      skillId,
      total_uses: total,
      success_rate: successRate,
      last_used: skillUsages.length > 0 
        ? skillUsages[skillUsages.length - 1].metadata.used_at 
        : null
    };
  }

  /**
   * 获取最佳实践
   */
  async getBestPractices(skillId) {
    const all = await this.storage.read(this.layer, {});
    return all
      .filter(r => 
        r.content.skill_id === skillId && 
        r.metadata.success
      )
      .sort((a, b) => new Date(b.metadata.used_at) - new Date(a.metadata.used_at))
      .slice(0, 10);
  }
}

module.exports = { SkillMemory };
