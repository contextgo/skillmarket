/**
 * ConflictDetector - 冲突检测器（MVP占位）
 * 未来：实现相似事实检索与仲裁
 */

class ConflictDetector {
  async detect(newFact) {
    // MVP：返回空数组（不检测）
    // V2：实现相似事实检索 + 矛盾判断
    return [];
  }

  async resolve(newFact, conflicts) {
    // MVP：不自动解决
    return newFact;
  }
}

module.exports = { ConflictDetector };
