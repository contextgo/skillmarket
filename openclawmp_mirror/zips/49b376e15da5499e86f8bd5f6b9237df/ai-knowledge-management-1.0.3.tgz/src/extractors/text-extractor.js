/**
 * TextExtractor - 文本提取器（MVP占位）
 * 未来：集成LLM提取关键信息
 */

class TextExtractor {
  async extract(text) {
    // MVP：直接返回
    // V2：调用LLM提取实体、关系、摘要
    return {
      entities: [],
      relations: [],
      summary: text.substring(0, 200)
    };
  }
}

module.exports = { TextExtractor };
