# 强记忆技能使用示例

## 示例1：记录用户投资偏好

```javascript
const memory = require('skills/persistent-cognitive-memory/src/memory-core');
const writer = new memory.MemoryWriter();

// 用户表达偏好
await writer.write({
  type: "background",
  category: "investment_style",
  content: "只看技术壁垒强的项目，对监管风险敏感"
}, {
  source: "user_explicit",
  confidence: 1.0
});

console.log("✅ 投资偏好已记录");
```

---

## 示例2：量化日报集成（完整流程）

```javascript
const memory = require('skills/persistent-cognitive-memory/src/memory-core');
const storage = new memory.LocalJSONStorage('workspace/memory');
const writer = new memory.MemoryWriter({ storage });
const retriever = new memory.MemoryRetriever({ storage });
const eventMemory = new memory.EventMemory(storage);

// 1. 检索历史教训
const lessons = await retriever.retrieve("生成投资早报", {
  layers: ["reflection", "event"],
  limit: 5
});
console.log("检索到记忆:", lessons.memories.length, "条");

// 2. 生成日报（注入记忆）
const brief = generateDailyBrief({
  memoryContext: lessons.context
});

// 3. 记录本次生成
await writer.write({
  type: "event",
  content: {
    title: "投资早报生成",
    strength: 5,
    sector: "系统事件"
  }
}, { source: "daily-brief.js" });
```

---

## 示例3：误判教训记录

```javascript
// 当发现隆基绿能误判时
await writer.write({
  type: "reflection",
  content: {
    title: "隆基绿能战略误判",
    eventId: "evt_隆基20260403",
    errorType: "战略分类错误",
    initialJudgment: "被动风险（供应链中断，强度4利空）",
    groundTruth: "主动战略（轻资产模式，强度3中性）",
    rootCauses: [
      "信源单一（仅依赖群聊快讯）",
      "分类器无法区分主动/被动",
      "缺乏储能产业链知识"
    ],
    correctiveActions: [
      "实施三层模型V2.0",
      "强制多源验证（≥2个高质量信源）"
    ],
    validation: "后续12条事件误判率降低60%"
  }
}, {
  severity: "high",
  relatedEvents: ["evt_隆基绿能"]
});
```

---

## 示例4：查询相关历史

```javascript
// 用户问："上次那个医疗AI项目怎么样了？"
const result = await retriever.retrieve("医疗AI项目", {
  layers: ["event"],
  limit: 3
});

result.memories.forEach(mem => {
  console.log(`[${mem.type}] ${mem.content.title}`);
  // 输出: [event] 斯坦福团队医疗AI项目，2026-04-07
});
```

---

## 示例5：记忆系统监控

```javascript
// 查看记忆统计
const stats = await storage.stats();
console.log("记忆分布:", stats);
// { background: 5, event: 117, reflection: 3, ... }

// 查看所有反思记忆
const reflections = await storage.read('reflection', {});
console.log("教训数量:", reflections.length);
```

---

## 示例6：跨会话连续性

```javascript
// 会话1
用户: "我偏好技术壁垒高的公司"
→ writer.write({type:"background", ...});

// 会话2（几天后）
用户: "分析这个医疗AI项目"
const memories = await retriever.retrieve("分析项目");
// 自动注入: "用户偏好技术壁垒优先..."
```

---

## 示例7：事件记忆双向同步

```javascript
// 从多维表格导入事件时，同时写入记忆
const bitableRecords = await feishuBitable.listRecords();
for (const record of bitableRecords) {
  await eventMemory.add(record.fields);
  await writer.write({
    type: "event",
    content: record.fields
  }, { source: "bitable_sync" });
}
```

---

## 示例8：自定义压缩策略

```javascript
// 对话记忆压缩（V2）
const compressor = new memory.MemoryCompressor();
const summary = await compressor.compress(longDialogue, {
  strategy: "extractive", // 提取式
  keepEntities: true,     // 保留实体
  maxLength: 200
});
```

---

**更多信息**：参考 `SKILL.md` 和 `QUICK-REFERENCE.md`
