# 强记忆技能 - 速查卡

## 一秒钟找到你需要的方法

---

## 📋 初始化

```javascript
// 1. 引入模块
const memory = require('skills/persistent-cognitive-memory/src/memory-core.js');

// 2. 创建实例
const writer = new memory.MemoryWriter();
const retriever = new memory.MemoryRetriever();
const background = new memory.BackgroundMemory(new memory.LocalJSONStorage());
const events = new memory.EventMemory(new memory.LocalJSONStorage());

// 3. 验证
console.log('✅ 记忆系统就绪');
```

---

## 🎯 核心操作速查

### **写入记忆**（5种类型）

| 类型 | 方法 | 示例 |
|------|------|------|
| 背景记忆 | `writer.write({type:"background",...})` | 投资偏好、价值观 |
| 对话记忆 | `writer.write({type:"conversation",...})` | 会话摘要 |
| 事件记忆 | `writer.write({type:"event",...})` | 投资事件 |
| 事实记忆 | `writer.write({type:"fact",...})` | 股票代码、财务数据 |
| 反思记忆 | `writer.write({type:"reflection",...})` | 错误教训 |
| 技能记忆 | `writer.write({type:"skill",...})` | 工具使用模式 |

**通用模板**：
```javascript
await writer.write({
  type: "event",           // 必填: one of 6 types
  content: {               // 必填: 实际内容
    // 根据type不同结构不同
  },
  metadata: {              // 可选: 元数据
    source: "daily-brief.js",
    confidence: 0.95
  }
});
```

---

### **检索记忆**（按场景）

| 场景 | 方法 | 返回 |
|------|------|------|
| 用户偏好 | `retriever.retrieve("我偏好什么？")` | 背景记忆 |
| 历史事件 | `retriever.retrieve("上次讨论")` | 事件+对话 |
| 事实查询 | `retriever.retrieve("股票代码")` | 事实记忆 |
| 错误复盘 | `retriever.retrieve("教训")` | 反思记忆 |
| 综合分析 | `retriever.retrieve("分析项目")` | 多层融合 |

**模板**：
```javascript
const result = await retriever.retrieve(
  "用户问题",              // query string
  { context: {...} },     // 可选: 上下文
  { layers: ["event","fact"], limit: 5 }  // 可选: 选项
);

// 使用记忆增强回答
const enhancedPrompt = `
  ${result.context}
  
  用户问题：${userQuery}
`;
```

---

### **特定层快捷方法**

```javascript
// 背景记忆
await background.set("investment_style", "技术壁垒优先");
const style = await background.get("investment_style");

// 事件记忆
await events.add({事件标题: "XXX", 强度: 5, ...});
const recentEvents = await events.query({ minStrength: 4, sector: "铝业" });
const related = await events.getRelated("evt_xxx");
```

---

## 🔍 记忆类型速查表

| 类型 | 存储内容 | 典型场景 | 更新频率 |
|------|---------|---------|---------|
| **background** | 价值观、偏好 | "我喜欢..." | 手动，很少 |
| **conversation** | 会话摘要 | 每次对话后 | 每次会话 |
| **event** | 投资事件时间线 | 日报事件、导入事件 | 每日 |
| **fact** | 结构化数据 | 股票代码、财务指标 | 实时 |
| **reflection** | 错误教训 | 误判复盘、策略改进 | 错误后 |
| **skill** | 工具使用模式 | classify工具使用记录 | 自动统计 |

---

## 🚀 常见任务

### **任务1：记录用户偏好**
```javascript
await writer.write({
  type: "background",
  content: "只看技术壁垒强的项目，对监管敏感",
  category: "investment_style"
}, { source: "user_explicit" });
```

### **任务2：日报生成增强**
```javascript
// 在 daily-brief.js 中添加：
const memoryCtx = await retriever.retrieve(
  "生成投资早报",
  { layers: ["reflection", "event"], limit: 5 }
);
// 将 memoryCtx.context 注入prompt
```

### **任务3：误判教训记录**
```javascript
await writer.write({
  type: "reflection",
  content: "隆基事件误判：将战略聚焦误读为风险",
  error_type: "战略分类错误",
  corrective: "实施三层模型V2.0"
}, { related_event: "evt_隆基" });
```

### **任务4：查询相关历史**
```javascript
const related = await events.getRelated("evt_当前事件ID");
// 返回类似板块的历史事件
```

---

## 🐛 调试

### **查看所有记忆**
```javascript
// 直接查看文件
cat workspace/memory/background.json
cat workspace/memory/event/*.json

// 或通过API
const allEvents = await retriever.storage.read('event', {});
console.log(allEvents);
```

### **清空记忆**
```javascript
// 清空某层
const fs = require('fs');
fs.rmSync('workspace/memory/event', { recursive: true, force: true });
fs.mkdirSync('workspace/memory/event');

// 清空全部
fs.rmSync('workspace/memory', { recursive: true, force: true });
```

### **查看统计**
```javascript
const stats = await retriever.storage.stats();
console.log(stats);
// { background: 5, event: 117, reflection: 3, ... }
```

---

## ⚡ 性能提示

| 场景 | 推荐设置 | 原因 |
|------|---------|------|
| 实时对话 | `limit: 3, layers: ["background"]` | 快速响应 |
| 日报生成 | `limit: 10, layers: ["event","reflection"]` | 深度分析 |
| 复盘分析 | `limit: 20, layers: ["reflection","event"]` | 全面回顾 |

---

## 📊 六层记忆对比

```
Layer 1: 背景记忆      → 价值观（只读，手动）
Layer 2: 对话记忆      → 会话摘要（自动压缩）
Layer 3: 事件记忆      → 投资时间线（与多维表同步）
Layer 4: 事实记忆      → 结构化数据（版本控制）
Layer 5: 反思记忆      → 错误教训（系统优化）
Layer 6: 技能记忆      → 工具使用（自动学习）
```

---

## 🔄 与现有系统集成点

| 组件 | 集成方式 |
|------|---------|
| `daily-brief.js` | 调用 `retriever.retrieve()` 注入记忆 |
| `classify-event-type.js` | 调用 `retriever` 获取类似历史 |
| 多维表格 | `EventMemory.add()` 双向同步 |
| 用户对话 | 中间件自动检索注入 |

---

## 📈 监控指标

```javascript
// 记录性能
const start = Date.now();
const result = await retriever.retrieve(query);
const latency = Date.now() - start;

console.log({
  query,
  memories_found: result.memories.length,
  latency_ms: latency
});
// 目标：<500ms
```

---

## 🆘 故障排除

| 问题 | 检查 | 解决 |
|------|------|------|
| 未写入 | 检查 `workspace/memory/` 文件 | 确保路径正确 |
| 检索为空 | 检查 query 关键词 | 降低相关性阈值 |
| 重复记录 | 检查 ID 生成 | 确保 `writer.write` 幂等 |
| 性能慢 | 检查文件大小 | 按日分片，限制检索数 |

---

## 📚 更多信息

- **完整文档**：`SKILL.md`
- **架构设计**：`ARCHITECTURE.md`
- **示例代码**：`examples/`
- **单元测试**：`tests/`

---

**版本**：v0.1.0-MVP  
**最后更新**：2026-04-07  

🦞 快速开始，持续记忆
