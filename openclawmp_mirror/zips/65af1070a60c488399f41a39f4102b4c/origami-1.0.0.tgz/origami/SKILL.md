---
name: origami
description: Help users learn origami (paper folding) including basic techniques (mountain fold, valley fold, reverse fold), tutorials for common origami models (crane, boat, airplane, box), step-by-step diagrams, and paper/tool recommendations. Use when users want to learn origami, need folding instructions, want to create paper crafts, or ask about paper folding techniques and models.
---

# Origami - 折纸技能

## Overview

This skill helps users learn the art of origami (paper folding). It provides comprehensive guidance on basic folding techniques, step-by-step tutorials for popular origami models, and advice on paper selection and tools.

## When to Use This Skill

- User wants to learn origami basics or specific models
- User asks about folding techniques (mountain fold, valley fold, etc.)
- User needs instructions for paper crafts
- User wants recommendations for origami paper and tools
- User asks about traditional or modern origami designs

## Basic Folding Techniques

### 1. Valley Fold (谷折)
The most basic fold - paper folds toward you, creating a valley shape.
- **Symbol**: Dashed line (--- --- ---)
- **How to**: Fold the paper so the crease forms a "V" shape pointing toward you
- **Tip**: Use a fingernail or bone folder to make sharp creases

### 2. Mountain Fold (山折)
Paper folds away from you, creating a mountain shape.
- **Symbol**: Dash-dot line (-.-.-.-)
- **How to**: Fold the paper so the crease forms a "Λ" shape pointing away from you
- **Tip**: Pre-crease by folding as a valley fold first, then reverse

### 3. Reverse Fold (反向折)
A fold that reverses the direction of a flap.
- **Types**: Inside reverse fold, Outside reverse fold
- **Used in**: Creating heads, tails, and pointed features
- **See**: [references/reverse_fold.md](references/reverse_fold.md) for detailed steps

### 4. Squash Fold (压平折)
Opens a pocket and flattens it symmetrically.
- **Used in**: Creating petals, leaves, and flat surfaces
- **Common in**: Flowers and complex models

### 5. Petal Fold (花瓣折)
A combination fold that creates petal-like shapes.
- **Used in**: Traditional crane, flowers
- **Complexity**: Intermediate

### 6. Rabbit Ear Fold (兔耳折)
Creates a triangular flap resembling rabbit ears.
- **Used in**: Animal models, pointed features
- **Technique**: Two simultaneous valley folds meeting at a point

## Common Origami Models

### Beginner Level

#### Paper Airplane (纸飞机)
Simple flying model, great for beginners.
**Steps**:
1. Start with rectangular paper
2. Fold in half lengthwise (mountain fold)
3. Fold top corners to center line
4. Fold the pointed tip down
5. Fold wings down on each side
6. Adjust wing angles for flight

#### Paper Boat (纸船)
Classic floating model, easy and fun.
**Steps**:
1. Start with square paper, white side up
2. Fold in half both ways, unfold
3. Fold corners to center
4. Fold bottom edges up
5. Fold corners out to form triangles
6. Fold bottom points up
7. Open from bottom to form boat

See [references/boat_diagram.md](references/boat_diagram.md) for detailed diagrams.

#### Paper Hat (纸帽子)
Simple wearable origami.
**Steps**:
1. Start with rectangular newspaper or A4 paper
2. Fold in half lengthwise
3. Fold top corners to center
4. Fold bottom edge up (both layers)
5. Fold bottom corners in
6. Open and wear!

### Intermediate Level

#### Traditional Crane (千纸鹤)
The most iconic origami model, symbol of peace.
**Steps**:
1. Start with square paper, colored side up
2. Fold diagonal both ways, unfold
3. Fold in half both ways, unfold
4. Collapse into preliminary fold (square base)
5. Fold top flaps to center (bird base)
6. Perform petal fold on both sides
7. Fold top layers up to form wings
8. Inside reverse fold to create head and tail
9. Fold head, spread wings

See [references/crane_diagram.md](references/crane_diagram.md) for detailed step-by-step diagrams.

#### Masu Box (升斗盒)
Traditional Japanese square box, practical and elegant.
**Steps**:
1. Start with square paper
2. Fold in half both ways, unfold
3. Fold all corners to center
4. Fold two opposite sides to center
5. Fold top and bottom edges to center
6. Open corners and form walls
7. Fold flaps in to secure

See [references/box_diagram.md](references/box_diagram.md) for detailed diagrams.

#### Jumping Frog (跳蛙)
Action origami that actually jumps!
**Steps**:
1. Start with rectangular paper
2. Fold in half both ways
3. Fold corners to center
4. Fold edges to center line
5. Fold bottom up, then accordion fold legs
6. Fold front legs, shape body
7. Press down on back to make it jump

### Advanced Level

#### Lotus Flower (莲花)
Beautiful multi-layer flower, often used for decoration.
**Steps**:
1. Start with square paper
2. Fold diagonal both ways
3. Fold corners to center (blintz base)
4. Repeat blintz fold 2-3 times
5. Fold corners back partially
6. Curl petals outward
7. Shape and arrange layers

See [references/lotus_diagram.md](references/lotus_diagram.md) for detailed diagrams.

#### Dragon (龙)
Complex model requiring patience and precision.
- **Base**: Bird base with extended points
- **Features**: Head with horns, wings, tail, legs
- **Paper recommendation**: Large (20cm+) thin paper

## Paper and Tools Guide

### Paper Types

#### Kami (和纸)
- **Description**: Traditional origami paper, colored on one side, white on other
- **Thickness**: Thin, easy to fold
- **Best for**: Most models, especially beginners
- **Sizes**: 15cm x 15cm standard, various sizes available

#### Tant Paper
- **Description**: Textured paper, same color both sides
- **Thickness**: Medium
- **Best for**: Complex models, geometric designs
- **Features**: Holds creases well, elegant texture

#### Washi (和紙)
- **Description**: Traditional Japanese handmade paper
- **Thickness**: Varies
- **Best for**: Display pieces, artistic origami
- **Features**: Beautiful patterns, fiber texture

#### Foil Paper
- **Description**: Paper with metallic foil backing
- **Thickness**: Thin
- **Best for**: Decorative models, holiday ornaments
- **Features**: Shiny finish, holds shape well

#### Kraft Paper
- **Description**: Brown wrapping paper
- **Thickness**: Medium to thick
- **Best for**: Large models, practice folding
- **Features**: Inexpensive, strong

### Paper Size Recommendations

| Model Type | Recommended Size | Notes |
|------------|------------------|-------|
| Simple models | 15cm x 15cm | Standard size for beginners |
| Cranes | 15cm x 15cm | Traditional size |
| Boxes | 20cm x 20cm | Larger for practical use |
| Flowers | 10-15cm x 10-15cm | Smaller for delicate work |
| Complex models | 20cm+ x 20cm+ | Larger for intricate folds |

### Essential Tools

#### Must-Have
- **Bone Folder**: Creates sharp, clean creases
- **Ruler**: For precise measurements and straight folds
- **Cutting Mat**: Protects surfaces when cutting paper

#### Helpful Additions
- **Paper Cutter/Trimmer**: For cutting square paper from rectangles
- **Tweezers**: For small, intricate folds
- **Clips**: To hold layers together while working
- **Paper Clips**: Temporary holds during complex sequences

### Paper Preparation

#### Cutting Square Paper from Rectangles
1. Fold one corner to align with opposite edge
2. Cut off excess rectangle strip
3. Unfold to reveal perfect square

#### Pre-Creasing Tips
- Always crease firmly but don't tear
- Use bone folder for crisp lines
- Fold away from body for better control
- Unfold completely before next fold

## Troubleshooting Common Issues

### Paper Tears
- **Cause**: Paper too thin or dry, creasing too hard
- **Solution**: Use slightly thicker paper, crease gently

### Creases Won't Hold
- **Cause**: Paper too thick or slick
- **Solution**: Use paper with better "memory," score creases with bone folder

### Model Won't Stay Together
- **Cause**: Incomplete folds, wrong paper type
- **Solution**: Check all creases are sharp, use crisper paper

### Can't See Diagrams Clearly
- **Solution**: See [references/](references/) folder for detailed diagrams with explanations

## Learning Resources

### Diagram Symbols Reference
See [references/symbols.md](references/symbols.md) for complete origami diagram notation.

### Model Database
See [references/models.md](references/models.md) for categorized list of models with difficulty ratings.

### Practice Recommendations
1. Start with simple models (boat, airplane)
2. Master basic folds before complex ones
3. Use larger paper when learning new models
4. Practice the same model multiple times
5. Progress gradually: Simple → Intermediate → Advanced

## Resources

### references/
Detailed reference materials for specific techniques and models:
- `crane_diagram.md` - Step-by-step crane folding guide
- `boat_diagram.md` - Paper boat instructions
- `box_diagram.md` - Masu box folding guide
- `lotus_diagram.md` - Lotus flower instructions
- `reverse_fold.md` - Detailed reverse fold tutorial
- `symbols.md` - Origami diagram notation reference
- `models.md` - Categorized model database

### assets/
Visual resources for origami instruction:
- `diagrams/` - ASCII art diagrams for common folds
- `templates/` - Printable folding templates
