#!/usr/bin/env python3
"""
折纸纸张尺寸计算器
帮助计算不同模型所需的纸张尺寸
"""

import sys

def calculate_box_paper_size(target_width_cm):
    """
    计算制作盒子所需的纸张尺寸
    盒子成品宽度 ≈ 纸张边长 / 3
    """
    paper_size = target_width_cm * 3
    return paper_size

def calculate_crane_paper_size(wingspan_cm):
    """
    计算制作千纸鹤所需的纸张尺寸
    鹤的翅膀展开宽度 ≈ 纸张边长 * 1.2
    """
    paper_size = wingspan_cm / 1.2
    return paper_size

def calculate_lotus_paper_size(diameter_cm):
    """
    计算制作莲花所需的纸张尺寸
    莲花直径 ≈ 纸张边长 * 0.8
    """
    paper_size = diameter_cm / 0.8
    return paper_size

def print_paper_recommendation(model_name, target_size_cm):
    """打印纸张推荐"""
    recommendations = {
        'box': {
            'calculator': calculate_box_paper_size,
            'unit': '边长',
            'note': '需要2张相同大小的纸（盒身+盒盖）'
        },
        'crane': {
            'calculator': calculate_crane_paper_size,
            'unit': '边长',
            'note': '标准正方形纸'
        },
        'lotus': {
            'calculator': calculate_lotus_paper_size,
            'unit': '边长',
            'note': '薄而韧的纸效果更好'
        }
    }
    
    if model_name not in recommendations:
        print(f"未知模型: {model_name}")
        print(f"支持的模型: {', '.join(recommendations.keys())}")
        return
    
    calc_info = recommendations[model_name]
    paper_size = calc_info['calculator'](target_size_cm)
    
    print(f"\n{'='*50}")
    print(f"模型: {model_name.upper()}")
    print(f"目标尺寸: {target_size_cm}cm")
    print(f"{'='*50}")
    print(f"推荐纸张尺寸: {paper_size:.1f}cm {calc_info['unit']}")
    print(f"实用尺寸: {round(paper_size)}cm (四舍五入)")
    print(f"备注: {calc_info['note']}")
    print(f"{'='*50}\n")

def main():
    """主函数"""
    if len(sys.argv) < 3:
        print("用法: python paper_calculator.py <模型> <目标尺寸(cm)>")
        print("\n支持的模型:")
        print("  box   - 升斗盒")
        print("  crane - 千纸鹤")
        print("  lotus - 莲花")
        print("\n示例:")
        print("  python paper_calculator.py box 7")
        print("  python paper_calculator.py crane 15")
        sys.exit(1)
    
    model = sys.argv[1].lower()
    try:
        size = float(sys.argv[2])
    except ValueError:
        print("错误: 目标尺寸必须是数字")
        sys.exit(1)
    
    print_paper_recommendation(model, size)

if __name__ == "__main__":
    main()
