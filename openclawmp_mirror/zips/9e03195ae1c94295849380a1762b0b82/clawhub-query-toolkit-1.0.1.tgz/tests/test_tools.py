"""Unit tests for clawhub_query tools (live smoke tests against ClawHub)."""
import unittest

from clawhub_query.tools import (
    query_rank,
    query_top,
    query_slice,
    semantic_search,
    query_author_skills,
    query_skill_detail,
    query_catalog,
    query_trending,
)


class TestClawHubToolsLive(unittest.TestCase):
    """Lightweight live tests against the real ClawHub API.

    These tests make real network calls and verify that the toolkit
    correctly parses responses. They are safe (read-only) and respect
    rate limits via built-in jitter.
    """

    def test_query_rank_top_skill(self):
        result = query_rank("self-improving-agent", sort="downloads", dir="desc")
        self.assertTrue(result.get("found"))
        self.assertEqual(result.get("rank"), 1)
        self.assertIn("downloads", result)

    def test_query_top_defaults(self):
        results = query_top(n=5, sort="stars", dir="desc")
        self.assertEqual(len(results), 5)
        self.assertEqual(results[0]["rank"], 1)
        self.assertIn("slug", results[0])

    def test_query_slice_small(self):
        results = query_slice(start_rank=10, end_rank=12, sort="downloads")
        self.assertEqual(len(results), 3)
        self.assertEqual(results[0]["rank"], 10)
        self.assertEqual(results[1]["rank"], 11)
        self.assertEqual(results[2]["rank"], 12)

    def test_semantic_search(self):
        results = semantic_search("github", limit=3)
        self.assertIsInstance(results, list)
        # Vector search may return 0-3 results depending on index state
        if results:
            self.assertIn("slug", results[0])
            self.assertIn("score", results[0])

    def test_query_author_skills(self):
        results = query_author_skills("steipete", sort="downloads", n=5)
        self.assertIsInstance(results, list)
        if results:
            self.assertIn("slug", results[0])

    def test_query_skill_detail(self):
        result = query_skill_detail("github", include_versions=False, include_moderation=False)
        self.assertEqual(result.get("slug"), "github")
        self.assertIn("displayName", result)
        self.assertIn("stats", result)

    def test_query_catalog_skills(self):
        results = query_catalog("skills", n=5, sort="downloads")
        self.assertEqual(len(results), 5)

    def test_query_trending(self):
        results = query_trending(time_window="30d", n=5)
        self.assertIsInstance(results, list)
        # Results may be empty if no skills updated recently


if __name__ == "__main__":
    unittest.main()
