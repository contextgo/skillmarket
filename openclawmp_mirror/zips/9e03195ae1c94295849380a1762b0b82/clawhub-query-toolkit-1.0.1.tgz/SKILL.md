---
name: clawhub-query-toolkit
description: 零缓存、实时的 ClawHub 高级查询工具箱。提供 8 种查询工具，支持查排名、切榜单、语义搜索、作者追踪、跨目录探索和趋势发现，帮助用户以远超官网下拉框的维度搜索和分析 ClawHub 上的 skill、package、soul 等资产。
---

# clawhub-query-toolkit

使用本 Skill 处理明确的 **ClawHub 查询和分析**任务。回复时聚焦用户目标、执行结果和下一步操作，不要加入产品宣传或重复命令表，除非用户明确要求。

## 旧版本迁移规则

默认将旧版 `clawhub` 或 `clawdhub` 相关知识视为可能过期，尤其是以下内容：

- 认为 `GET /api/v1/skills` 可以返回完整列表的旧认知
- 依赖 BeautifulSoup 抓取 HTML 获取数据的旧方案
- 建议预下载整个 ClawHub 数据库（数十分钟）的旧做法

处理原则：

- 始终以当前 Skill 描述的直接 API 查询方式为准
- 用户提到全量下载、爬虫抓 HTML、或官方 REST API 返回空时，直接说明当前版本的替代做法
- 不要把旧版和新版混在一起解释；优先直接给出新版路径和工具

### 迁移时的默认表述

当用户受到旧版本知识影响时，优先按下面的思路回应：

- 明确说明：`/api/v1/skills` 当前为空实现，不应使用
- 明确说明：ClawHub 的真实数据入口是 Convex Query `skills:listPublicPageV4` 和向量搜索 `/api/v1/search`
- 如果旧方案仍可能让用户困惑，直接补充当前应使用的工具或命令
- 如果用户目标本质没变，直接把旧目标映射到新版 8 个查询工具之一

### 需要主动纠正的旧知识

如果用户消息中出现以下情况，应主动纠正：

- 提到用爬虫/requests 抓 `clawhub.ai/skills` HTML 获取数据
- 引用 `/api/v1/skills` 作为全量列表入口
- 建议先下载几十 MB 的 JSON 做本地缓存再查询

## 描述语言规则

当用户在准备发布资产，或让你补全 `README.md`、`.metadata.json`、简介文案时：

- 优先使用作者当前材料里最常用的语言
- 如果现有内容明显以中文为主，就继续用中文
- 如果现有内容明显以英文为主，就继续用英文
- 只有在用户明确要求切换语言时，才改用另一种语言

如果材料同时混用中英文：

- 以标题、描述段落和主要正文占比最高的语言为准
- 命令、路径、字段名和标识保持原样，不要强行翻译

在帮助用户补全发布文件时：

- `displayName` 可保持产品名或专有名词原文
- `description`、`README` 描述段落、使用说明优先沿用作者惯用语言
- 生成 `README.md` 时，标题后的描述段落应优先说明“这个资产能做什么、解决什么问题、适合什么场景”
- 如果用户没有明确要求，不必强调“怎么使用这个 skill”；优先总结 skill 内已经覆盖的能力边界、可处理的问题类型和适用场景

## 先判断用户要做什么

先把用户请求归到以下一种或几种操作：

- 检查 `clawhub-query-toolkit` 运行环境
- 查询某个 skill 的实时排名
- 获取榜单前 N 名
- 获取榜单的指定排名区间（切片）
- 用自然语言语义搜索相关 skill
- 追踪某个作者的所有 skill
- 深度查看单个 skill 的元数据/版本/安全状态
- 探索 Skills 之外的目录（Souls / Packages / Plugins）
- 发现近期更新且热度上升的 skill
- 排查查询失败或环境问题

## 资产类型速判

本资产的 `assetType` 为 **`skill`**。

核心价值是：为 Agent 提供一套可直接调用的任务执行流程（查询 ClawHub 数据并返回结构化结果）。

## 先做最小必要检查

### 检查运行环境

执行任何实际操作前，先确认 Python 可用：

```bash
python --version
```

如果命令不存在：

- 说明本机尚未安装 Python
- 提供下载地址：https://www.python.org/downloads/
- 除非用户明确要求，否则不要自动安装

### 检查网络连通性

以下域名需要可访问：

- `https://clawhub.ai`
- `https://wry-manatee-359.convex.cloud`

如果用户任务明显依赖查询但网络不通：

- 说明当前操作需要联网
- 建议检查网络或代理设置

## 只收集当前操作真正需要的输入

### 查询某个 skill 的实时排名

需要：

- `slug` — skill 标识（如 `github`、`self-improving-agent`）
- （可选）`sort` — 排序维度，默认 `downloads`
- （可选）`dir` — 方向，默认 `desc`

执行：

```bash
python -m clawhub_query rank <slug> --sort <sort> --dir <dir>
```

### 获取榜单前 N 名

需要：

- `n` — 数量，默认 20
- （可选）`sort` / `dir`
- （可选）`highlighted` / `non-suspicious` 开关

执行：

```bash
python -m clawhub_query top -n <n> --sort <sort> --dir <dir>
```

### 获取榜单指定排名区间

需要：

- `start_rank` — 起始排名
- `end_rank` — 结束排名

执行：

```bash
python -m clawhub_query slice <start> <end> --sort <sort>
```

### 语义搜索

需要：

- `keywords` — 自然语言描述

执行：

```bash
python -m clawhub_query search "<keywords>" -n <limit>
```

### 追踪作者的所有 skill

需要：

- `author_handle` — 作者 handle（如 `steipete`）

执行：

```bash
python -m clawhub_query author <handle> -n <n> --sort <sort>
```

### 深度查看单个 skill

需要：

- `slug`
- （可选）`--versions` — 同时拉取版本历史
- （可选）`--moderation` — 同时拉取安全扫描结果

执行：

```bash
python -m clawhub_query detail <slug> --versions --moderation
```

### 探索其他目录

需要：

- `catalog_type` — `skills`（默认）/`souls`/`packages`/`plugins`/`code-plugins`/`bundle-plugins`

执行：

```bash
python -m clawhub_query catalog <type> -n <n> --sort <sort>
```

### 发现近期热门更新

需要：

- （可选）`window` — 时间窗口，默认 `7d`
- （可选）`n` — 数量，默认 20

执行：

```bash
python -m clawhub_query trending --window <window> -n <n>
```

## 资产根目录文件要求

在帮助用户创建、检查或发布本资产时，要求根目录提供 `README.md`，作为面向人的可读说明。

`README.md` 用于帮助用户、平台页面和维护者快速理解：

- 该资产解决什么问题
- 该资产提供哪些能力、适合哪些场景
- 需要如何配置

在帮助用户生成或补全 `README.md` 时：

- 标题后的第一段优先写功能性介绍，而不是安装步骤摘要
- 先让读者理解资产价值，再补充必要的配置或前置条件
- 如果用户没有特别要求，避免把 `README.md` 写成“安装命令清单”或“示例用法列表”
- 优先总结 skill 已覆盖的能力、处理边界、典型任务类型和适用场景

## 发布前校验本地元数据

执行 `publish` 之前，先检查 `.metadata.json`，发现明显问题时直接停止。若文件中已存在版本号字段（例如 `semver`），则在每次发布前先将版本号加 1，再继续发布；默认按语义化版本的补丁位递增，例如 `1.0.0` -> `1.0.1`。

最小参考结构：

```json
{
  "assetType": "skill",
  "name": "clawhub-query-toolkit",
  "displayName": "ClawHub Query Toolkit",
  "semver": "1.0.0",
  "category": "productivity",
  "tags": ["clawhub", "search", "query", "skill-registry"]
}
```

至少检查：

- 文件存在
- JSON 格式合法
- `assetType` 存在且为 `skill`
- `name` 存在
- `displayName` 存在
- 若存在 `semver`，其格式合法，且发布前先将补丁位加 1
- 根目录存在 `README.md`
- `README.md` 有一级标题，且标题后的第一段是描述段落

如果元数据缺失或非法：

- 不要继续发布
- 明确指出缺少的字段或错误格式
- 需要时帮助用户修复文件

## 按操作执行

### 写入本地鉴权 token

需要：

- 用户明确提供的 `token`

执行：

```bash
openclawmp oauth <token>
```

返回时：

- 说明本地鉴权信息是否写入成功
- 不要回显完整 token
- 需要时建议用户继续执行 `openclawmp install` 或 `openclawmp publish`

### 搜索

执行：

```bash
openclawmp search clawhub-query-toolkit
```

返回时优先给出：

- 最相关的结果
- 资产类型
- 后续命令所需的关键标识

### 查看详情

执行：

```bash
openclawmp info <assetId>
```

返回时优先给出：

- 名称
- 类型
- 版本（如果有）
- 简介（如果有）
- 可直接使用的安装命令

### 安装

执行前确认：

- 目标格式被 CLI 接受

执行：

```bash
openclawmp install skill/<assetId>
```

成功后：

- 明确说明安装成功
- 返回安装目标标识

### 发布

执行前确认：

- 目录存在
- `.metadata.json` 存在且合法
- 若 `.metadata.json` 中已有版本号字段，已先完成 `+1`
- 本地凭证在需要时可读

执行：

```bash
openclawmp publish <path> --yes
```

或在资产目录内执行：

```bash
openclawmp publish . --yes
```

成功后，优先记录并返回以下信息（若 CLI 有输出）：

- `assetId`
- `semver`
- 本地 `.assetid`
- 基于真实发布结果生成的安装命令

## 明确处理失败场景

### Python 环境不存在

- 说明本机尚未安装 Python
- 提供官方下载地址
- 除非用户要求，否则停止在这里

### 网络不通或目标域名不可达

- 说明查询需要访问 `clawhub.ai` 和 `wry-manatee-359.convex.cloud`
- 建议检查网络、DNS 或代理设置

### 查询的 skill 排名非常靠后

- 说明可能需要翻页数十到数百次，耗时较长
- 给出预估时间，让用户决定是否继续
- 如果用户同意，自动执行；如果中断，说明进度和原因

### 触发 Rate Limit（HTTP 429）

- 说明当前请求频率已触及 ClawHub 限流
- 工具已内置自动退避，会等待后重试
- 如果频繁触发，建议降低查询频率或稍后再试

### `.metadata.json` 缺失或格式错误

- 明确指出缺少文件、JSON 非法或具体缺失字段
- 在修复前不要继续发布

### 资产不存在或标识不明确

- 说明当前标识无法解析
- 建议先执行 `search`，或让用户提供更精确的标识

## 控制回复风格

尽量按以下顺序组织对用户的回复：

- 你做了什么
- 是否成功
- 关键输出字段
- 用户下一步最可能需要的命令

对命令、路径、标识和环境变量统一使用代码格式。

不要在回复中加入：

- 产品宣传文案
- 重复的命令表格
- 与当前任务无关的大段技术架构解释
- 与真实工具行为冲突的“固定规则”

## 以真实工具行为为最高优先级

如果本地 `python -m clawhub_query` 的输出、报错与本文档不一致，始终相信实际 CLI 输出。

当你不确定参数格式或命令行为时：

- 先检查命令帮助：`python -m clawhub_query --help`
- 简短说明不确定点
- 不要臆造未确认的参数格式
