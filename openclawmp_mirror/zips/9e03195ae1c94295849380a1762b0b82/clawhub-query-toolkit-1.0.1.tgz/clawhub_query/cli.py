"""Command-line interface for clawhub-query-toolkit."""
import argparse
import json
import sys

from .tools import (
    query_rank,
    query_top,
    query_slice,
    semantic_search,
    query_author_skills,
    query_skill_detail,
    query_catalog,
    query_trending,
)


def _print_json(data):
    print(json.dumps(data, indent=2, ensure_ascii=False))


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="clawhub-query",
        description="Zero-cache, real-time query toolkit for ClawHub.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # ------------------------------------------------------------------
    # rank
    # ------------------------------------------------------------------
    p_rank = subparsers.add_parser("rank", help="Find the rank of a skill")
    p_rank.add_argument("slug", help="Skill slug")
    p_rank.add_argument("--sort", default="downloads", help="Sort dimension")
    p_rank.add_argument("--dir", default="desc", choices=["asc", "desc"], help="Sort direction")

    # ------------------------------------------------------------------
    # top
    # ------------------------------------------------------------------
    p_top = subparsers.add_parser("top", help="Fetch top N skills")
    p_top.add_argument("-n", type=int, default=20, help="Number of results")
    p_top.add_argument("--sort", default="downloads", help="Sort dimension")
    p_top.add_argument("--dir", default="desc", choices=["asc", "desc"], help="Sort direction")
    p_top.add_argument("--highlighted", action="store_true", help="Only highlighted")
    p_top.add_argument("--non-suspicious", action="store_true", help="Only non-suspicious")

    # ------------------------------------------------------------------
    # slice
    # ------------------------------------------------------------------
    p_slice = subparsers.add_parser("slice", help="Fetch a slice of the leaderboard")
    p_slice.add_argument("start", type=int, help="Start rank (inclusive)")
    p_slice.add_argument("end", type=int, help="End rank (inclusive)")
    p_slice.add_argument("--sort", default="downloads", help="Sort dimension")
    p_slice.add_argument("--dir", default="desc", choices=["asc", "desc"], help="Sort direction")

    # ------------------------------------------------------------------
    # search
    # ------------------------------------------------------------------
    p_search = subparsers.add_parser("search", help="Semantic vector search")
    p_search.add_argument("keywords", help="Search keywords")
    p_search.add_argument("-n", type=int, default=20, help="Number of results")
    p_search.add_argument("--highlighted", action="store_true", help="Only highlighted")
    p_search.add_argument("--non-suspicious", action="store_true", help="Only non-suspicious")

    # ------------------------------------------------------------------
    # author
    # ------------------------------------------------------------------
    p_author = subparsers.add_parser("author", help="Find skills by an author")
    p_author.add_argument("handle", help="Author handle")
    p_author.add_argument("--sort", default="downloads", help="Sort dimension")
    p_author.add_argument("-n", type=int, default=100, help="Max results")

    # ------------------------------------------------------------------
    # detail
    # ------------------------------------------------------------------
    p_detail = subparsers.add_parser("detail", help="Deep-dive into a single skill")
    p_detail.add_argument("slug", help="Skill slug")
    p_detail.add_argument("--versions", action="store_true", help="Include version history")
    p_detail.add_argument("--moderation", action="store_true", help="Include moderation info")

    # ------------------------------------------------------------------
    # catalog
    # ------------------------------------------------------------------
    p_catalog = subparsers.add_parser("catalog", help="Explore other catalogs (souls, packages, plugins)")
    p_catalog.add_argument("type", default="skills", help="Catalog type: skills, souls, packages, plugins, code-plugins, bundle-plugins")
    p_catalog.add_argument("-n", type=int, default=50, help="Number of results")
    p_catalog.add_argument("--sort", default="newest", help="Sort dimension")
    p_catalog.add_argument("--dir", default="desc", choices=["asc", "desc"], help="Sort direction")

    # ------------------------------------------------------------------
    # trending
    # ------------------------------------------------------------------
    p_trending = subparsers.add_parser("trending", help="Find recently updated skills gaining traction")
    p_trending.add_argument("--window", default="7d", help="Time window: e.g. 7d, 24h")
    p_trending.add_argument("-n", type=int, default=20, help="Number of results")

    # ------------------------------------------------------------------
    args = parser.parse_args(argv)

    if args.command == "rank":
        _print_json(query_rank(args.slug, sort=args.sort, dir=args.dir))

    elif args.command == "top":
        _print_json(
            query_top(
                n=args.n,
                sort=args.sort,
                dir=args.dir,
                highlighted_only=args.highlighted,
                non_suspicious_only=args.non_suspicious,
            )
        )

    elif args.command == "slice":
        _print_json(query_slice(start_rank=args.start, end_rank=args.end, sort=args.sort, dir=args.dir))

    elif args.command == "search":
        _print_json(
            semantic_search(
                args.keywords,
                limit=args.n,
                highlighted_only=args.highlighted,
                non_suspicious_only=args.non_suspicious,
            )
        )

    elif args.command == "author":
        _print_json(query_author_skills(args.handle, sort=args.sort, n=args.n))

    elif args.command == "detail":
        _print_json(query_skill_detail(args.slug, include_versions=args.versions, include_moderation=args.moderation))

    elif args.command == "catalog":
        _print_json(query_catalog(catalog_type=args.type, n=args.n, sort=args.sort, dir=args.dir))

    elif args.command == "trending":
        _print_json(query_trending(time_window=args.window, n=args.n))


if __name__ == "__main__":
    main()
