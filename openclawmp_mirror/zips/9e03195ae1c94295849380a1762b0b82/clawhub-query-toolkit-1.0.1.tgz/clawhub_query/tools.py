"""High-level query tools for ClawHub."""
import time
from typing import Optional

from .client import convex_query, api_v1_search, api_v1_skill, api_v1_skill_versions, api_v1_list

# Pagination defaults
_PAGE_SIZE = 160
_MIN_DELAY = 5.0
_MAX_DELAY = 8.0


def _fetch_skills_page(
    sort: str = "downloads",
    dir: str = "desc",
    cursor: Optional[str] = None,
    num_items: int = _PAGE_SIZE,
    highlighted_only: bool = False,
    non_suspicious_only: bool = False,
) -> dict:
    """Fetch one page via listPublicPageV4."""
    args: dict = {
        "sort": sort,
        "dir": dir,
        "numItems": num_items,
    }
    if cursor is not None:
        args["cursor"] = cursor
    if highlighted_only:
        args["highlightedOnly"] = True
    if non_suspicious_only:
        args["nonSuspiciousOnly"] = True
    return convex_query("skills:listPublicPageV4", args)


def _sleep_jitter() -> None:
    import random
    time.sleep(random.uniform(_MIN_DELAY, _MAX_DELAY))


# ---------------------------------------------------------------------------
# Tool 1: query_rank
# ---------------------------------------------------------------------------

def query_rank(slug: str, sort: str = "downloads", dir: str = "desc") -> dict:
    """Find the real-time rank of a skill on any leaderboard.

    Returns a dict with rank, skill metadata, and stats.
    If the skill is not found, rank is None.
    """
    target = slug.lower().strip()
    cursor = None
    rank = 0

    while True:
        result = _fetch_skills_page(sort=sort, dir=dir, cursor=cursor)
        page = result.get("page", [])
        has_more = result.get("hasMore", False)
        next_cursor = result.get("nextCursor")

        if not page and not has_more:
            break

        for entry in page:
            rank += 1
            skill = entry.get("skill", {})
            if skill.get("slug", "").lower() == target:
                stats = skill.get("stats", {})
                owner = entry.get("owner", {})
                return {
                    "found": True,
                    "rank": rank,
                    "slug": skill.get("slug"),
                    "displayName": skill.get("displayName"),
                    "summary": skill.get("summary"),
                    "ownerHandle": owner.get("handle") or entry.get("ownerHandle"),
                    "downloads": int(stats.get("downloads", 0)),
                    "stars": int(stats.get("stars", 0)),
                    "installsAllTime": int(stats.get("installsAllTime", 0)),
                    "installsCurrent": int(stats.get("installsCurrent", 0)),
                    "versions": int(stats.get("versions", 0)),
                    "updatedAt": skill.get("updatedAt"),
                    "createdAt": skill.get("createdAt"),
                }

        if not has_more or not next_cursor:
            break

        cursor = next_cursor
        _sleep_jitter()

    return {"found": False, "rank": None, "slug": target}


# ---------------------------------------------------------------------------
# Tool 2: query_top
# ---------------------------------------------------------------------------

def query_top(
    n: int = 20,
    sort: str = "downloads",
    dir: str = "desc",
    highlighted_only: bool = False,
    non_suspicious_only: bool = False,
) -> list[dict]:
    """Fetch the top N skills from any leaderboard in real time."""
    cursor = None
    collected: list[dict] = []

    while len(collected) < n:
        result = _fetch_skills_page(
            sort=sort,
            dir=dir,
            cursor=cursor,
            highlighted_only=highlighted_only,
            non_suspicious_only=non_suspicious_only,
        )
        page = result.get("page", [])
        has_more = result.get("hasMore", False)
        next_cursor = result.get("nextCursor")

        for entry in page:
            if len(collected) >= n:
                break
            skill = entry.get("skill", {})
            stats = skill.get("stats", {})
            owner = entry.get("owner", {})
            collected.append(
                {
                    "rank": len(collected) + 1,
                    "slug": skill.get("slug"),
                    "displayName": skill.get("displayName"),
                    "summary": skill.get("summary"),
                    "ownerHandle": owner.get("handle") or entry.get("ownerHandle"),
                    "downloads": int(stats.get("downloads", 0)),
                    "stars": int(stats.get("stars", 0)),
                    "installsAllTime": int(stats.get("installsAllTime", 0)),
                    "installsCurrent": int(stats.get("installsCurrent", 0)),
                    "versions": int(stats.get("versions", 0)),
                    "updatedAt": skill.get("updatedAt"),
                    "createdAt": skill.get("createdAt"),
                }
            )

        if not has_more or not next_cursor:
            break
        cursor = next_cursor
        _sleep_jitter()

    return collected


# ---------------------------------------------------------------------------
# Tool 3: query_slice
# ---------------------------------------------------------------------------

def query_slice(
    start_rank: int = 1,
    end_rank: int = 100,
    sort: str = "downloads",
    dir: str = "desc",
) -> list[dict]:
    """Fetch an arbitrary slice of the leaderboard (e.g. ranks 1001-1020).

    This is impossible to do on the ClawHub website UI.
    """
    if start_rank < 1:
        raise ValueError("start_rank must be >= 1")
    if end_rank < start_rank:
        raise ValueError("end_rank must be >= start_rank")

    cursor = None
    rank = 0
    collected: list[dict] = []

    while True:
        result = _fetch_skills_page(sort=sort, dir=dir, cursor=cursor)
        page = result.get("page", [])
        has_more = result.get("hasMore", False)
        next_cursor = result.get("nextCursor")

        for entry in page:
            rank += 1
            if rank < start_rank:
                continue
            if rank > end_rank:
                break

            skill = entry.get("skill", {})
            stats = skill.get("stats", {})
            owner = entry.get("owner", {})
            collected.append(
                {
                    "rank": rank,
                    "slug": skill.get("slug"),
                    "displayName": skill.get("displayName"),
                    "summary": skill.get("summary"),
                    "ownerHandle": owner.get("handle") or entry.get("ownerHandle"),
                    "downloads": int(stats.get("downloads", 0)),
                    "stars": int(stats.get("stars", 0)),
                    "installsAllTime": int(stats.get("installsAllTime", 0)),
                    "installsCurrent": int(stats.get("installsCurrent", 0)),
                    "versions": int(stats.get("versions", 0)),
                    "updatedAt": skill.get("updatedAt"),
                    "createdAt": skill.get("createdAt"),
                }
            )

        if rank >= end_rank:
            break
        if not has_more or not next_cursor:
            break

        cursor = next_cursor
        _sleep_jitter()

    return collected


# ---------------------------------------------------------------------------
# Tool 4: semantic_search
# ---------------------------------------------------------------------------

def semantic_search(
    keywords: str,
    limit: int = 20,
    highlighted_only: bool = False,
    non_suspicious_only: bool = False,
) -> list[dict]:
    """Search skills by natural-language meaning using OpenAI embeddings."""
    resp = api_v1_search(
        q=keywords.strip(),
        limit=limit,
        highlighted_only=highlighted_only,
        non_suspicious_only=non_suspicious_only,
    )
    results = resp.get("results", [])
    out: list[dict] = []
    for idx, r in enumerate(results, 1):
        out.append(
            {
                "rank": idx,
                "slug": r.get("slug"),
                "displayName": r.get("displayName"),
                "summary": r.get("summary"),
                "version": r.get("version"),
                "updatedAt": r.get("updatedAt"),
                "score": r.get("score"),  # vector similarity score
            }
        )
    return out


# ---------------------------------------------------------------------------
# Tool 5: query_author_skills
# ---------------------------------------------------------------------------

def query_author_skills(
    author_handle: str,
    sort: str = "downloads",
    n: int = 100,
) -> list[dict]:
    """Find all skills published by a specific author.

    Because there is no author filter in the API, this tool paginates through
    the list and filters locally in real time.
    """
    target = author_handle.lower().strip()
    cursor = None
    collected: list[dict] = []

    while len(collected) < n:
        result = _fetch_skills_page(sort=sort, dir="desc", cursor=cursor)
        page = result.get("page", [])
        has_more = result.get("hasMore", False)
        next_cursor = result.get("nextCursor")

        for entry in page:
            if len(collected) >= n:
                break
            skill = entry.get("skill", {})
            owner = entry.get("owner", {})
            handle = (owner.get("handle") or entry.get("ownerHandle") or "").lower()
            if handle == target:
                stats = skill.get("stats", {})
                collected.append(
                    {
                        "rank": len(collected) + 1,
                        "slug": skill.get("slug"),
                        "displayName": skill.get("displayName"),
                        "summary": skill.get("summary"),
                        "downloads": int(stats.get("downloads", 0)),
                        "stars": int(stats.get("stars", 0)),
                        "installsAllTime": int(stats.get("installsAllTime", 0)),
                        "installsCurrent": int(stats.get("installsCurrent", 0)),
                        "versions": int(stats.get("versions", 0)),
                        "updatedAt": skill.get("updatedAt"),
                        "createdAt": skill.get("createdAt"),
                    }
                )

        if not has_more or not next_cursor:
            break
        cursor = next_cursor
        _sleep_jitter()

    return collected


# ---------------------------------------------------------------------------
# Tool 6: query_skill_detail
# ---------------------------------------------------------------------------

def query_skill_detail(
    slug: str,
    include_versions: bool = False,
    include_moderation: bool = False,
) -> dict:
    """Deep-dive into a single skill."""
    detail = api_v1_skill(slug)
    skill = detail.get("skill", {})
    latest = detail.get("latestVersion", {})
    owner = detail.get("owner", {})
    moderation = detail.get("moderation", {})
    metadata = detail.get("metadata", {})

    result = {
        "slug": skill.get("slug"),
        "displayName": skill.get("displayName"),
        "summary": skill.get("summary"),
        "stats": skill.get("stats", {}),
        "owner": {
            "handle": owner.get("handle"),
            "userId": owner.get("userId"),
            "displayName": owner.get("displayName"),
            "image": owner.get("image"),
        },
        "latestVersion": {
            "version": latest.get("version"),
            "createdAt": latest.get("createdAt"),
            "changelog": latest.get("changelog"),
            "license": latest.get("license"),
        },
        "metadata": metadata,
        "tags": skill.get("tags", {}),
        "createdAt": skill.get("createdAt"),
        "updatedAt": skill.get("updatedAt"),
    }

    if include_versions:
        try:
            versions_resp = api_v1_skill_versions(slug)
            result["versions"] = versions_resp.get("items", [])
        except Exception as e:
            result["versions_error"] = str(e)

    if include_moderation:
        result["moderation"] = moderation

    return result


# ---------------------------------------------------------------------------
# Tool 7: query_catalog
# ---------------------------------------------------------------------------

def query_catalog(
    catalog_type: str = "skills",
    n: int = 50,
    sort: str = "newest",
    dir: str = "desc",
) -> list[dict]:
    """Explore other ClawHub catalogs: souls, packages, plugins, etc.

    For 'skills', we use the reliable Convex query path.
    For others, we fall back to the REST API.
    """
    if catalog_type == "skills":
        return query_top(n=n, sort=sort, dir=dir)

    # For non-skills, try REST API (may vary in availability)
    cursor = None
    collected: list[dict] = []

    while len(collected) < n:
        resp = api_v1_list(
            catalog=catalog_type,
            sort=sort,
            dir=dir,
            cursor=cursor,
            limit=160,
        )
        items = resp.get("items", [])
        next_cursor = resp.get("nextCursor")

        for item in items:
            if len(collected) >= n:
                break
            collected.append(item)

        if not items or not next_cursor:
            break
        cursor = next_cursor
        _sleep_jitter()

    return collected


# ---------------------------------------------------------------------------
# Tool 8: query_trending
# ---------------------------------------------------------------------------

def query_trending(time_window: str = "7d", n: int = 20) -> list[dict]:
    """Discover recently updated skills that are gaining traction.

    This tool combines the 'newest' and 'updated' leaderboards and filters
    for skills whose updatedAt falls within the requested window.
    """
    now_ms = time.time() * 1000
    window_seconds = _parse_time_window(time_window)
    cutoff_ms = now_ms - (window_seconds * 1000)

    # Fetch both newest and updated top pages
    newest = query_top(n=n * 2, sort="newest", dir="desc")
    updated = query_top(n=n * 3, sort="updated", dir="desc")

    seen = set()
    candidates: list[dict] = []

    for entry in updated + newest:
        slug = entry.get("slug")
        if not slug or slug in seen:
            continue
        seen.add(slug)
        updated_at = entry.get("updatedAt", 0)
        if updated_at >= cutoff_ms:
            candidates.append(entry)

    # Sort by downloads descending as a proxy for traction
    candidates.sort(key=lambda x: x.get("downloads", 0), reverse=True)
    return candidates[:n]


def _parse_time_window(window: str) -> int:
    """Convert '7d', '24h', '30m' to seconds."""
    window = window.strip().lower()
    if window.endswith("d"):
        return int(window[:-1]) * 86400
    if window.endswith("h"):
        return int(window[:-1]) * 3600
    if window.endswith("m"):
        return int(window[:-1]) * 60
    if window.endswith("s"):
        return int(window[:-1])
    return int(window)
