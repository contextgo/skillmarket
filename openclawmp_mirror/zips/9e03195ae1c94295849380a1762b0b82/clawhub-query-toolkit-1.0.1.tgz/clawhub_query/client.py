"""Low-level HTTP client for ClawHub Convex and REST APIs."""
import json
import time
import urllib.error
import urllib.request
from typing import Any, Optional

CONVEX_URL = "https://wry-manatee-359.convex.cloud"
SITE_URL = "https://clawhub.ai"


def _request(
    url: str,
    method: str = "GET",
    data: Optional[bytes] = None,
    headers: Optional[dict] = None,
    timeout: int = 60,
) -> Any:
    """Send HTTP request with automatic 429 backoff."""
    req_headers = {
        "User-Agent": "clawhub-query-toolkit/1.0 (agent skill)",
        "Accept": "application/json",
    }
    if headers:
        req_headers.update(headers)

    while True:
        try:
            req = urllib.request.Request(
                url, data=data, headers=req_headers, method=method
            )
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return json.load(resp)
        except urllib.error.HTTPError as e:
            if e.code == 429:
                retry_after = e.headers.get("Retry-After") or e.headers.get("retry-after") or "60"
                wait = max(1, int(retry_after))
                print(f"[RATE LIMITED] waiting {wait}s before retry...")
                time.sleep(wait)
                continue
            body = e.read().decode("utf-8", errors="ignore")
            raise RuntimeError(f"HTTP {e.code}: {body}") from e


def convex_query(path: str, args: dict) -> dict:
    """Call a Convex query endpoint."""
    payload = {"path": path, "args": args, "format": "json"}
    resp = _request(
        f"{CONVEX_URL}/api/query",
        method="POST",
        data=json.dumps(payload).encode("utf-8"),
        headers={"Content-Type": "application/json"},
    )
    if resp.get("status") != "success":
        raise RuntimeError(f"Convex query failed: {resp}")
    return resp["value"]


def api_v1_search(
    q: str,
    limit: Optional[int] = None,
    highlighted_only: bool = False,
    non_suspicious_only: bool = False,
) -> dict:
    """Call /api/v1/search."""
    params = {"q": q}
    if limit is not None:
        params["limit"] = str(limit)
    if highlighted_only:
        params["highlightedOnly"] = "true"
    if non_suspicious_only:
        params["nonSuspiciousOnly"] = "true"
    query_string = "&".join(f"{k}={urllib.request.quote(str(v))}" for k, v in params.items())
    url = f"{SITE_URL}/api/v1/search?{query_string}"
    return _request(url)


def api_v1_skill(slug: str) -> dict:
    """Call /api/v1/skills/<slug>."""
    url = f"{SITE_URL}/api/v1/skills/{urllib.request.quote(slug)}"
    return _request(url)


def api_v1_skill_versions(slug: str, limit: Optional[int] = None) -> dict:
    """Call /api/v1/skills/<slug>/versions."""
    url = f"{SITE_URL}/api/v1/skills/{urllib.request.quote(slug)}/versions"
    if limit is not None:
        url += f"?limit={limit}"
    return _request(url)


def api_v1_list(
    catalog: str = "skills",
    sort: str = "downloads",
    dir: str = "desc",
    cursor: Optional[str] = None,
    limit: int = 160,
    highlighted_only: bool = False,
    non_suspicious_only: bool = False,
) -> dict:
    """Call /api/v1/<catalog> (skills, souls, packages, etc.).

    Note: the public REST endpoint may return empty due to listPublicPage stub.
    This is a fallback; we prefer convex_query for skills.
    """
    params: dict[str, str] = {
        "sort": sort,
        "dir": dir,
        "limit": str(limit),
    }
    if cursor:
        params["cursor"] = cursor
    if highlighted_only:
        params["highlightedOnly"] = "true"
    if non_suspicious_only:
        params["nonSuspiciousOnly"] = "true"
    query_string = "&".join(f"{k}={urllib.request.quote(v)}" for k, v in params.items())
    url = f"{SITE_URL}/api/v1/{catalog}?{query_string}"
    return _request(url)
