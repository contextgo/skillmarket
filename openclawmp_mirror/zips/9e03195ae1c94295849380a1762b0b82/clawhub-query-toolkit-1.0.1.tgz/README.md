# ClawHub Query Toolkit

一个零缓存、实时查询的 ClawHub 高级搜索工具箱。ClawHub 官网只提供 6 种基础排序，而这个工具箱让你可以通过 8 种不同的查询维度来搜索、分析和发现 skill、package、soul 等资产——包括查实时排名、切榜单区间、语义向量搜索、作者追踪、跨目录探索和趋势发现。

## 适用场景

- 你想知道某个 skill 在当前榜单上的**实时排名**
- 你想查看榜单的**任意切片**（比如第 1000~1020 名），官网不支持这个功能
- 你想用**自然语言语义搜索**找相关 skill，而不是简单的关键词匹配
- 你想追踪某个作者发布的**所有作品**
- 你想深入分析某个 skill 的**版本历史、安全扫描结果、平台兼容性**
- 你想探索 ClawHub 上的 **Souls、Packages、Plugins** 等其他目录
- 你想发现**最近更新且热度上升**的新 skill

## 核心能力

本工具箱通过直接调用 ClawHub 后端 API 实现实时查询，不需要预先下载任何本地缓存数据。安装后即可使用，所有查询结果均与官网保持同步。

## 8 个查询工具

| 工具 | 能力 | 示例 |
|------|------|------|
| `rank` | 查询任意 skill 的实时排名 | `python -m clawhub_query rank github --sort stars` |
| `top` | 获取榜单前 N 名 | `python -m clawhub_query top -n 10 --sort downloads` |
| `slice` | 获取榜单指定排名区间 | `python -m clawhub_query slice 1000 1020 --sort downloads` |
| `search` | 自然语言语义搜索 | `python -m clawhub_query search "pdf editor" -n 5` |
| `author` | 追踪某个作者的所有 skill | `python -m clawhub_query author steipete -n 20` |
| `detail` | 深度查看单个 skill 详情 | `python -m clawhub_query detail skill-vetter --versions` |
| `catalog` | 探索 Souls / Packages / Plugins | `python -m clawhub_query catalog souls -n 10` |
| `trending` | 发现近期更新且热门的 skill | `python -m clawhub_query trending --window 7d -n 10` |

## 安装

通过水产市场安装：

```bash
openclawmp install skill/<assetId>
```

或者从源码直接运行：

```bash
cd clawhub-query-toolkit
python -m clawhub_query --help
```

## 使用示例

### 查排名

```bash
python -m clawhub_query rank self-improving-agent --sort downloads
# 输出：{"rank": 1, "slug": "self-improving-agent", "downloads": 350632, ...}
```

### 查星星榜前 5

```bash
python -m clawhub_query top -n 5 --sort stars
```

### 语义搜索

```bash
python -m clawhub_query search "memory and knowledge graph" -n 10
```

### 榜单切片（第 500~520 名）

```bash
python -m clawhub_query slice 500 520 --sort downloads
```

## 技术说明

- **零缓存**：不预先下载 ClawHub 全量数据库，即装即用
- **实时数据**：直接调用 Convex Query `listPublicPageV4` 和 `/api/v1/search`
- **自动限流保护**：内置 5~8 秒随机请求间隔，触发 429 时自动等待重试
- **纯标准库**：仅依赖 Python 内置库（urllib、json、csv 等），无需额外安装包

## 注意事项

1. **排名靠后的查询较慢**：查询第 3 万名左右的 skill 可能需要翻页 180+ 次，耗时约 15~20 分钟。此类操作前会给出时间预估，由你决定是否继续。
2. **需要联网**：所有查询均需访问 `clawhub.ai` 和 `wry-manatee-359.convex.cloud`。
3. **作者过滤为客户端实现**：ClawHub 后端没有原生作者过滤，此功能通过实时翻页+本地过滤实现，冷门作者可能需要较长时间定位。

## 环境要求

- Python 3.8+
- 可访问互联网
