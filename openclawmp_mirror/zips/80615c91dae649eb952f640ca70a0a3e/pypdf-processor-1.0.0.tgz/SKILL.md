# /pdf — PyPDF Processor Skill Definition

把 PDF 处理的全套原语（提取、合并、拆分、旋转、加密、表单）封装成一个斜杠路由技能。底层调用 [pypdf](https://github.com/py-pdf/pypdf) v6.10.2+。所有操作均为显式触发，源文件永不被原地覆盖。

---

## 一、触发方式

**仅手动触发** — 用户显式调用，无自动扫描 PDF 附件、无静默处理。

### 斜杠命令

```
/pdf                                    # 默认 = extract，作用于最近一个 PDF 附件
/pdf extract [pages:1-5,8]              # 提取指定页文字；省略 pages 则全文
/pdf meta                               # 元数据（author, title, created, producer…）
/pdf pages                              # 仅返回页数
/pdf merge                              # 合并所有附件 PDF（顺序 = 附件顺序）
/pdf split pages:1-5,6-10               # 按页区间拆成多个 PDF
/pdf rotate pages:1-3 deg:90            # 旋转指定页（deg ∈ {90, 180, 270}）
/pdf encrypt pw:<password> [algo:AES-256]  # 加密（默认 AES-256）
/pdf decrypt pw:<password>              # 解密
/pdf forms                              # 列出 AcroForm 字段
/pdf forms fill:name=张三,age=20        # 填充字段
```

### 中文别名
- `/处理PDF`、`/读PDF`、`/pypdf` 均等价于 `/pdf`

### 自然语言触发

**中文（口语优先）：**
- 把这个 PDF 的文字抠出来 · 提取这份 PDF · 帮我读一下这个 PDF 说了啥
- 这个 PDF 谁写的？ · 看下这份文件的元数据
- 这份 PDF 多少页
- 把这几个 PDF 合成一个 · 合并这几份
- 把这个 PDF 按 1-5 和 6-10 拆开 · 拆一下这个 PDF
- 把前三页转一下方向 · 前两页歪了帮我转正
- 给这个 PDF 上个密码 xxx · 帮我加密，密码设成 xxx
- 解开这个 PDF，密码是 xxx · 这个加密的帮我解一下
- 这表单里有哪些字段 · 把姓名填成张三，年龄填 20

**English:**
- extract text from this pdf · read this pdf for me · pull out the text
- who wrote this pdf? · show metadata
- how many pages?
- merge these pdfs · combine all of these
- split this into 1-5 and 6-10
- rotate page 1-3 by 90 degrees
- encrypt this with password xxx · password-protect this
- unlock this pdf, password is xxx
- what fields does this form have · fill in name=张三, age=20

### 参数语法

- **键值对格式**：`key:value`，多值用逗号分隔
- `pages:1-5,8-12,15` — 区间 + 单页混合
- `deg:90` — 必须是 90/180/270
- `pw:xxx` — 密码原文（不记录到日志）
- `fill:field1=val1,field2=val2` — 表单字段赋值
- `algo:AES-128|AES-256|RC4-128` — 加密算法

### 软提示

当用户上传 PDF 但未发出指令时，代理**可以**回复一行建议："检测到 PDF 附件，输入 `/pdf` 提取文字或 `/pdf meta` 查看元数据。" 但**不得**未经指令执行。

---

## 运行时行为

调用时执行 **router → dispatcher → pypdf → formatter** 四阶段：

1. **Router（解析）**
   - 从斜杠命令解析 `op`（默认 `extract`）和 `key:value` 参数
   - 定位目标 PDF：优先使用命令所在消息的附件，否则回溯到线程中最近一个 PDF
   - 校验参数（页码在范围内、`deg` 合法、密码非空等），失败即返回错误 JSON，不下发到 pypdf

2. **Dispatcher（分发）** — 按 `op` 路由到对应 pypdf 原语：
   | op | pypdf 调用 |
   |---|---|
   | `extract` | `PdfReader(src).pages[i].extract_text()` per page |
   | `meta` | `PdfReader(src).metadata` → dict |
   | `pages` | `len(PdfReader(src).pages)` |
   | `merge` | `w = PdfWriter(); for f in srcs: w.append(f); w.write(out)` |
   | `split` | 每个页区间一个 `PdfWriter`，各自 `write()` |
   | `rotate` | `page.rotate(deg)` in-place on a `PdfWriter` copy |
   | `encrypt` | `PdfWriter(src).encrypt(pw, algorithm=algo)` |
   | `decrypt` | `reader.decrypt(pw)`；成功后复制到新 writer |
   | `forms` | `reader.get_fields()` 或 `writer.update_page_form_field_values()` |

3. **pypdf 执行** — 所有写操作输出到临时文件，仅在 4 步成功后移动到最终位置

4. **Formatter（格式化）**
   - 产出符合 `references/schema.json` 的 JSON（见第三节）
   - 生成人类可读 recap（见第六节的系统提示词）
   - 产出物（生成的 PDF）上传到频道的文件存储，URL 写入 JSON 的 `output_file` 字段

### 跳过条件
- 无可寻址的 PDF 附件 → "未找到 PDF 附件，请先上传。"
- 参数非法 → "参数错误：`<具体说明>`"
- 线程中多个候选 PDF 且未指定 → 列出候选文件名让用户选择

### 原子性
任何步骤失败，源文件不变；临时文件自动清理；失败遥测上报至 SkillHub。

---

## 三、输出字段（按 operation 区分）

所有输出共享**基础信封**：

| 字段 | 类型 | 说明 |
|---|---|---|
| `processed_at` | string (ISO 8601) | 处理时间，默认 +08:00 |
| `operation` | string (enum) | `extract` / `meta` / `pages` / `merge` / `split` / `rotate` / `encrypt` / `decrypt` / `forms` |
| `status` | string (enum) | `success` / `partial` / `failed` |
| `source_file` 或 `source_files` | string / array | 输入文件名 |
| `warnings` | array\<string\> | 非致命警告（扫描 PDF、CJK 字体缺失、页码被夹逼等） |

各操作的**特有字段**参见 `references/schema.json` 的 `oneOf` 分支。

---

## 四、输出格式（因频道而异）

| 频道 | 显示 |
|---|---|
| 飞书 / WeCom / Slack / Discord | 折叠互动卡片：标题 `📄 PDF 已处理 · <op>`；若有产出文件则附「下载」按钮；底部「查看原始 JSON」按钮 |
| 微信 / Telegram / WhatsApp / iMessage / DingTalk | 纯文本 + 文件下载链接。提取类操作附 `preview_chars` 字数的文字预览，回复 `/recall` 取全文 |

无论哪种频道，**JSON 始终写入代理记忆层**作为权威状态。

---

## 五、边界情况

| 情况 | 行为 |
|---|---|
| 文件非 PDF / 损坏 | pypdf 抛 `PdfReadError` → 返回 `status: failed, warnings: ["not a valid PDF"]` |
| 加密 PDF 无密码 | `warnings: ["encrypted — provide pw:<password>"]`，不消耗配额，等用户补充 |
| 扫描 PDF（无文字层） | 提取操作：`text: null, warnings: ["scanned PDF — OCR not supported in v1"]` |
| 文件 > 50 MB | **硬拒绝**，回复"文件超过 50 MB 上限。如需强制处理请加 `force:true` 参数（慢，占用内存）" |
| 页数 > 500 | **截断到前 500 页** + `warnings: ["truncated to first 500 pages — use pages:N-M to target specific ranges"]` |
| 页码越界（如 `pages:1-999` 但只有 10 页） | 夹逼到有效区间，记录 `warnings` |
| `split` 区间重叠 | 允许（同一页可出现在多个输出），记录 `warnings` |
| `merge` 页面尺寸不一致 | 按第一个文件的尺寸保留，其余按需缩放；记录 `warnings` |
| 表单填充类型不匹配（数字字段塞字符串） | 返回 `status: partial`，`warnings` 列出被拒绝的字段 |
| CJK 字体缺失导致乱码 | `warnings: ["CJK font subset missing — some chars may be �"]` |
| AES 加密但未装 `pypdf[crypto]` | 硬失败 + 清晰错误："加密 PDF 需要安装 pypdf[crypto]" |
| `/pdf encrypt` 作用于群聊共享 PDF | **仅上传者可调用**（与 §八 `forms_fill_permission: uploader_only` 保持一致） |
| 处理中被中断（代理重启） | 临时文件清理，无副作用；线程回复"处理中断，请重试。" |

---

## 系统提示词

运行时注入变量：`{{OPERATION}}` · `{{RAW_TEXT}}` · `{{METADATA}}` · `{{PAGE_COUNT}}` · `{{LANG_HINT}}` · `{{ARTIFACT_URL}}` · `{{WARNINGS}}` · `{{CHANNEL}}`

```
You are the StepClaw /pdf skill (pypdf-processor). You have just completed a pypdf
operation and must emit a structured response.

## Inputs
- {{OPERATION}} — one of: extract, meta, pages, merge, split, rotate, encrypt, decrypt, forms
- {{RAW_TEXT}} — extracted text (only for extract; else null)
- {{METADATA}} — PDF metadata dict (only for meta; else null)
- {{PAGE_COUNT}} — page count of the primary input
- {{LANG_HINT}} — detected language of extracted text (zh / en / mixed / unknown)
- {{ARTIFACT_URL}} — URL of the output PDF (for merge/split/rotate/encrypt/decrypt/forms fill; else null)
- {{WARNINGS}} — array of warning strings from the dispatcher
- {{CHANNEL}} — channel family: "card" (feishu/slack/discord/wecom) or "plain" (wechat/tg/…)

## Output (emit in this exact order; nothing else)

1. A fenced ```json``` block matching references/schema.json EXACTLY for the given
   operation. Use null for absent-but-applicable values; never omit required keys.

2. A fenced ```recap``` block with a human-readable summary in the dominant language
   (Chinese if {{LANG_HINT}}=="zh" or user's last 3 turns are mostly zh, else English).
```

```
## Recap templates (one line each, per operation — 口语化, 1 emoji 上限, 避免 AI 腔)

- extract  → 📄 {{PAGE_COUNT}} 页 {{LANG_HINT}} 文字，{{CHAR_COUNT}} 字。预览：{{PREVIEW}}
- meta     → 📋 {{METADATA.author}}·「{{METADATA.title}}」·{{PAGE_COUNT}} 页·{{METADATA.created}}
- pages    → 📄 {{PAGE_COUNT}} 页
- merge    → 📎 合了 {{N_INPUTS}} 个 → {{OUTPUT_NAME}}（{{PAGE_COUNT}} 页）
- split    → ✂️ 拆成 {{N_OUTPUTS}} 个文件（按 {{N_RANGES}} 个区间）
- rotate   → 🔄 {{N_PAGES}} 页转了 {{DEG}}°
- encrypt  → 🔒 加密好了（{{ALGO}}）：{{ARTIFACT_URL}}
- decrypt  → 🔓 解了：{{ARTIFACT_URL}}
- forms    → 📝 {{N_FIELDS}} 个字段 / 填了 {{N_FILLED}} 个
```

```
## Rules
- Be faithful. Never invent facts; if pypdf returned null/empty, say so.
- Never echo passwords in JSON or recap — redact to "***" even if user typed them visibly.
- Reference attachments by filename only; never re-describe binary content.
- Token estimates: char count × 0.4 ≈ tokens for Chinese, × 0.25 for English.
- Timestamps: ISO 8601, default +08:00 unless channel metadata says otherwise.
- No extra prose before the JSON block or after the recap block.
- If {{WARNINGS}} is non-empty, surface the most critical one in the recap's first line.
```

---

## 七、兼容性

- **StepClaw 版本**：≥ 0.3.0
- **Python**：≥ 3.8（pypdf 要求）
- **pypdf**：≥ 6.10.2（`pypdf[crypto]` 用于 AES）
- **模型**：继承代理默认模型（推荐 step-3.5-flash 足矣 —— recap 生成不需要大模型）
- **频道**：所有 StepClaw 频道；文件产出需支持文件附件的频道（飞书/Slack/Discord/WeCom/Telegram）；纯文本频道降级为 base64（≤ 5 MB）或下载链接
- **OpenClaw ClawHub 可移植性**：底层 pypdf 跨平台；仅需调整频道 UX 即可镜像到 ClawHub

---

## 八、权限

- **私聊**：任何人可调用全部操作
- **群聊**（默认）：
  - `extract` / `meta` / `pages` / `merge` / `split` / `rotate` / `decrypt`（读/只读变换）：任何人可调用
  - `encrypt` / `forms fill`（写入/安全变更）：**默认仅上传者可调用**（`forms_fill_permission: uploader_only`）
  - 管理员可通过配置改为 `anyone` 或 `admin_only`
- **读权限**：线程附件、线程历史
- **写权限**：代理记忆层、频道文件存储（用于生成的 PDF）、线程消息

---

## 安全注意

- 密码参数 `pw:xxx` 在斜杠命令中明文出现 —— 执行后立即从消息记忆中擦除，JSON/recap 永不回显
- AES-256 是默认，AES-128 / RC4-128 仅为兼容老系统提供
- 所有生成的文件都走代理自己的文件存储，不上传到第三方
- 扫描 PDF 不做 OCR —— 避免将内容经过第三方 OCR 服务（v2 可选本地 OCR 插件）

---

## 参考

- `references/schema.json` — 输出 JSON Schema
- `references/example-output.json` — 八种操作的示例输出
- [pypdf 官方文档](https://pypdf.readthedocs.io/)
做 OCR —— 避免将内容经过第三方 OCR 服务（v2 可选本地 OCR 插件）

---

*See also:* `references/schema.json` · `references/example-output.json` · [pypdf 官方文档](https://pypdf.readthedocs.io/)
