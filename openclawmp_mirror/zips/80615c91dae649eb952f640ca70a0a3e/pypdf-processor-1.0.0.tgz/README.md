# PyPDF 处理器 /pdf

把 PDF 处理的全套操作封装成 StepClaw 技能：文字/元数据/页数提取、合并、拆分、旋转、加密/解密、表单读取与填充。底层基于 [pypdf](https://github.com/py-pdf/pypdf)（纯 Python、无二进制依赖）。适用于需要在群聊或 DM 中快速处理 PDF 的场景 —— 课程资料、论文、销售报表、合同扫描件。仅在用户显式触发时运行。

## 功能特性

- **一个路由技能，八种操作**：`extract` · `meta` · `pages` · `merge` · `split` · `rotate` · `encrypt/decrypt` · `forms`
- **中英双语触发**：`/pdf`、`/pypdf`、`/处理PDF`、`/读PDF`，以及"提取这份 PDF 的文字"之类的自然语言
- **页面范围参数**：`pages:1-5,8-12` 的语法贯穿所有按页操作
- **扫描 PDF 检测**：文字层为空时提示"需要 OCR，尚未支持"而非返回空结果
- **加密 PDF 处理**：支持 AES-128/AES-256（需 `pypdf[crypto]`）
- **频道自适应输出**：飞书/Slack/Discord 富卡片 + 文件附件；微信/Telegram 纯文本降级
- **原子执行**：任一步失败全量回滚，源文件永不被覆盖

## 安装

```bash
openclawmp install skill/pypdf-processor --target-dir ~/.stepclaw/skills
```

## 使用方法

按操作各给一个示例：

| 操作       | 斜杠命令                                                  | 自然语言                      |
| -------- | ----------------------------------------------------- | ------------------------- |
| 提取文字（默认） | `/pdf` 或 `/pdf extract pages:1-5`                     | "提取这份 PDF 的文字"            |
| 读取元数据    | `/pdf meta`                                           | "这个 PDF 是谁写的？"            |
| 页数统计     | `/pdf pages`                                          | "这份 PDF 有多少页？"            |
| 合并       | `/pdf merge` + 多个附件                                   | "把这几份 PDF 合并成一个"          |
| 拆分       | `/pdf split pages:1-5,6-10`                           | "把这份 PDF 按 1-5 和 6-10 拆开" |
| 旋转       | `/pdf rotate pages:1-3 deg:90`                        | "把前三页顺时针旋转 90 度"          |
| 加密       | `/pdf encrypt pw:<密码>`                                | "给这份 PDF 加个密码 xxx"        |
| 解密       | `/pdf decrypt pw:<密码>`                                | "帮我解开这份 PDF，密码是 xxx"      |
| 表单       | `/pdf forms` 查看字段；`/pdf forms fill:name=张三,age=20` 填充 | "这份表单里有哪些字段？"             |

## 配置说明

| 配置项 | 说明 | 默认值 |
|--------|------|--------|
| `max_pages` | 单次处理的页数上限 | 500 |
| `max_file_size_mb` | 单文件大小上限（MB） | 50 |
| `output_format` | 输出 JSON 模式（`compact` / `pretty`） | `compact` |
| `language_hint` | 文字提取后的语言检测提示 | `auto` |
| `preview_chars` | 纯文本频道的预览字符数 | 200 |
| `default_encryption_algo` | 默认加密算法 | `AES-256` |
| `forms_fill_permission` | 群聊中谁可填充表单 | `uploader_only` |

## 依赖

- Python ≥ 3.8
- pypdf ≥ 6.10.2（纯 Python，无二进制依赖）
- pypdf[crypto] ≥ 6.10.2（AES 加密时需要）
- StepClaw ≥ 0.3.0

## 资产结构

```
pypdf/
├── .metadata.json           # 资产元数据
├── README.md                # 本文件
├── SKILL.md                 # Skill 完整定义（行为、触发、提示词）
└── references/
    ├── schema.json          # 输出 JSON Schema（oneOf by operation）
    └── example-output.json  # 八种操作的示例输出
```

## 反馈

按 StepClaw 用户 FAQ 手册流程反馈：

```
【阶跃号】<UID>
【设备ID】<DID>
【技能】/pdf (pypdf-processor v1.0.0)
【问题描述】...
```

---

## 作者

LiXuan@StepFun · 基于 [py-pdf/pypdf](https://github.com/py-pdf/pypdf) v6.10.2
