# 短视频五维拆解

给一段抖音/小红书的 mp4 视频，自动生成一份"爆款拆解报告"。适合做内容运营的同学——想拍同款、写脚本、做分镜时，用这份报告当参考弹药。

## 功能特性

报告会从 5 个角度拆解这条视频：

1. **节奏** — 视频分成几段？哪段是钩子（吸引人留下）？哪段是高潮？哪段一带而过？
2. **BGM 卡点** — 音乐在哪几秒卡上了画面？大概换了几次歌？情绪怎么起伏？（看画面推断，不是识曲软件）
3. **事件** — 视频里发生了什么？高潮在第几秒？
4. **主题** — 命中了哪些两性痛点标签（异地恋 / 吵架 / 初恋重逢 ...），目标受众是谁，复刻潜力多大
5. **评论区** — v1 暂时留空，v2 会接入

## 安装

```bash
openclawmp install skill/video-deconstruct --target-dir ./skills
```

## 使用方法

1. **配置 API Key**：去 [StepFun 平台](https://platform.stepfun.com) 注册 → 控制台 → API Keys → 新建一个 → 复制粘贴到 skill 目录下的 `.env` 文件里
2. **运行分析**：把视频路径丢给脚本
   ```bash
   python scripts/analyze.py /path/to/your-video.mp4
   ```
3. **看报告**：打开 `output/your-video-report.md`

遇到问题（报错、超时、不会装 Python），看 [`guides/01-quickstart.md`](guides/01-quickstart.md) 里的完整步骤和常见问题。

## 配置说明

| 项目 | 说明 |
|--------|------|
| 输入格式 | 只支持 mp4（其他格式需先用工具转一下） |
| 输入大小 | 10MB 以内直接跑；超过会自动压缩到 10MB 以下 |
| 输出位置 | `output/<视频名>-report.md` |
| 视频长度 | 没有硬性限制，但越长画质越糊（10MB 预算会被摊薄） |
| `--keep-upload` | 加这个参数，分析完不会自动删除云端视频（适合同一条视频想换不同提示词反复拆） |

## 依赖

- Python 3.10+
- StepFun API Key（免费注册，用于调用 step-1o-turbo-vision 模型）
- ffmpeg（可选，仅当视频超过 10MB 需要自动压缩时用到）

## 想调整输出风格？

- 改 `prompts/analysis_rubric.txt` 的"主题维度"部分，定义你所在赛道的痛点标签词典
- 改 `templates/report.md.j2` 调整报告版式
- 详见 [`guides/03-prompt-engineering.md`](guides/03-prompt-engineering.md)

## 反馈

按 StepClaw 用户 FAQ 手册流程反馈：

```
【阶跃号】<UID>
【设备ID】<DID>
【技能】video-deconstruct v1.0.3
【问题描述】...
```

---

*作者：立瑄@StepFun · 2026-04-21*
