---
name: video-deconstruct
version: 1.0.5
description: 用 step-1o-turbo-vision 把一段抖音/小红书短视频 mp4 拆解成 5 维爆款分析报告——节奏、BGM 卡点、事件、主题（两性痛点）、评论区（v2）。给运营拍同款、写脚本、做分镜时直接当弹药。当用户说"拆解视频""分析这条视频""帮我看这段抖音""短视频结构""卡点在哪""这条爆款怎么火的"时触发。输入：本地 mp4 文件路径。输出：output/ 目录下一份 markdown 报告。
author: 立瑄@StepFun
license: CC BY-SA 4.0
runtime: python3.10+
requires:
  - openai (Python SDK)
  - httpx
  - jinja2
  - python-dotenv
  - ffmpeg (system, ≥ 4.4) — 自动压到 StepClaw 10MB 上限用
env:
  - STEP_API_KEY
tags:
  - video
  - 短视频
  - 抖音
  - 小红书
  - 拆解
  - 爆款分析
  - 运营
  - vision
  - stepfun
---

# video-deconstruct

## 这个 skill 干啥

扔一段 mp4，吐一份"爆款拆解报告"。覆盖：

1. **节奏** — 视频被分成几段，哪段是钩子、哪段是高潮、哪段一带而过
2. **BGM** — 卡点位置、推测的换歌次数、情绪曲线（纯视觉推断，不识曲）
3. **事件** — 发生了什么、高潮时刻在第几秒
4. **主题** — 命中了哪些两性痛点标签（异地恋/吵架/初恋重逢/...），目标受众，复刻潜力
5. **评论区** — v1 暂跳过，v2 接入

## 快速开始

### 1. 运行分析（首次会提示输入 Key）

```bash
python scripts/analyze.py /path/to/your-video.mp4
```

首次使用时会提示你输入 StepFun API Key（从 [platform.stepfun.com](https://platform.stepfun.com) 拿），输入时不会回显。输入后会保存到：

```
~/.stepclaw/video-deconstruct/config.json   (权限 600，仅本人可读)
```

后续每次运行都会自动读取，不再需要输入。报告生成在 `./output/your-video-report.md`。

### 2. 管理已保存的 Key

```bash
python scripts/analyze.py --show-config   # 看 key 保存位置 / 状态（不会泄露 key 本身）
python scripts/analyze.py --save-key      # 换 key：重新输入并覆盖
python scripts/analyze.py --forget-key    # 删除保存的 key
```

### 3. 其他配置方式（可选）

如果你有 CI 或想临时 override，Key 的读取优先级是：

1. 环境变量 `STEP_API_KEY`（最高优先级）
2. `~/.stepclaw/video-deconstruct/config.json`（首次输入后自动写入）
3. skill 根目录的 `.env` 文件（向后兼容）

详细步骤见 [`guides/01-quickstart.md`](01-quickstart.md)。

### 安全说明

- 保存位置在你的家目录下，不在 skill 目录里 — 重装 / 更新 skill 不会覆盖
- 文件权限 `600`（只有你本人能读写）、父目录 `700`
- 文件不会随 skill 分发或上传；`.gitignore` 已排除 `.env`
- 不想留本地文件的话，用环境变量方式，并跑 `--forget-key` 清掉历史

## 想改输出风格？

- 改 `prompts/analysis_rubric.txt` 的"主题维度"部分定义你赛道的痛点标签词典
- 改 `templates/report.md.j2` 调整报告版式
- 详见 [`guides/03-prompt-engineering.md`](03-prompt-engineering.md)

## 限制

- 输入必须是 mp4。StepClaw 上传上限 **10MB** — 超过会自动两遍 ffmpeg 压缩（长视频降到 240p/低帧率，但 rubric 仍能分析节奏/卡点/事件；详见 `scripts/compress.py`）
- 没有对视频长度的硬限制，但 10MB 的比特率预算随时长线性下降：3 分钟内可保 480p+，≥30 分钟会退化到近似 240p 幻灯片
- 运行时会先把（必要时压缩后的）文件上传到 StepFun 云端（临时），分析完后自动删除（除非加 `--keep-upload`）；压缩产物也会在处理完后清理
- BGM 维度仍以视觉线索为主（详见 `guides/02-五维拆解说明.md`）
- 真识曲不做（要的话改成 ACRCloud / Audd.io，见 v2 路线）
