# 5 分钟跑通 video-deconstruct

## 1. 装 Python 依赖

```bash
cd video-deconstruct/
pip install -r requirements.txt
```

不需要装 ffmpeg 或任何系统依赖——这个 skill 是纯 Python + StepFun API。

## 2. 拿 StepFun API key

去 [https://platform.stepfun.com](https://platform.stepfun.com) 注册 → 控制台 → API Keys → 新建 → 复制

```bash
export STEP_API_KEY=sk-your-api-key-here
```

> 想永久生效就写到 `~/.zshrc` 里。

## 3. 跑你的第一段视频

```bash
python scripts/analyze.py /path/to/your-video.mp4
```

执行流程会打印：

```
📤 上传视频到 StepFun: your-video.mp4 (3.2MB)
   file_id = file-AbCdEfGh12
🤖 调 step-1o-turbo-vision 拆解中...
📝 渲染报告...
✅ 报告: ./output/your-video-report.md
🧹 已清理云端文件: file-AbCdEfGh12
```

## 5. 看报告

打开 `output/your-video-report.md`，5 个维度全部就位（评论区在 v1 里是占位）。

## 常见问题

**Q：报错 `STEP_API_KEY 未设置`**
A：见步骤 2。

**Q：文件超过 10MB 怎么办**
A：skill 会自动调用 `scripts/compress.py` 两遍 ffmpeg 压到 10MB 以下（StepClaw 上限）。如果本机没装 ffmpeg，自动压缩会失败——先手动压一下：`ffmpeg -i big.mp4 -vcodec libx264 -crf 28 -preset fast small.mp4`

**Q：报错 `只支持 mp4`**
A：先转一下：`ffmpeg -i in.mov out.mp4`。StepFun 的文件 API 只接受 mp4。

**Q：想保留云端文件不被自动删除**
A：加 `--keep-upload` 参数。适用于想重复分析同一段视频不同 prompt 的情况。

**Q：上传卡住**
A：默认上传超时 10 分钟。128MB 视频在一般网速下 1-3 分钟应该能传完。如果卡更久，检查网络或把文件压小一点。
