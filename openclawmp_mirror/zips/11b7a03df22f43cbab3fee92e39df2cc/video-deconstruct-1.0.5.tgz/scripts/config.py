"""持久化 StepFun API Key 到 ~/.stepclaw/video-deconstruct/config.json。

读取优先级（在 stepfun_client._api_key() 里实现）:
    1. STEP_API_KEY 环境变量（CI / 临时 override）
    2. ~/.stepclaw/video-deconstruct/config.json （本模块负责）
    3. skill 根目录的 .env （向后兼容老用户）

文件权限: 目录 0700, 文件 0600（仅本人可读写）。
"""
from __future__ import annotations

import json
import os
import stat
from datetime import datetime
from pathlib import Path

CONFIG_DIR = Path.home() / ".stepclaw" / "video-deconstruct"
CONFIG_PATH = CONFIG_DIR / "config.json"


def load_saved_key() -> str | None:
    if not CONFIG_PATH.exists():
        return None
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None
    key = data.get("api_key")
    return key if isinstance(key, str) and key else None


def has_any_key() -> bool:
    """env var / 保存的 config / skill 根目录 .env 任一有 key 就返回 True。"""
    if os.environ.get("STEP_API_KEY"):
        return True
    if load_saved_key():
        return True
    # .env 的兜底在 stepfun_client 里已经 load_dotenv 过了，会反映到 env var，
    # 但 _preflight 里导入 config 时 load_dotenv 可能还没执行，所以直接读文件。
    env_file = Path(__file__).resolve().parent.parent / ".env"
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line.startswith("STEP_API_KEY=") and line.split("=", 1)[1].strip():
                return True
    return False


def save_key(api_key: str) -> None:
    """写入 api_key 到 CONFIG_PATH，先建目录 0700，再写文件并 chmod 0600。"""
    CONFIG_DIR.mkdir(mode=0o700, parents=True, exist_ok=True)
    os.chmod(CONFIG_DIR, 0o700)
    # 用 open + O_CREAT | O_WRONLY | O_TRUNC 并预设 mode，避免 create→chmod 之间的窗口。
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(CONFIG_PATH, flags, 0o600)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(
                {"api_key": api_key, "saved_at": datetime.now().isoformat(timespec="seconds")},
                f,
                ensure_ascii=False,
                indent=2,
            )
    except Exception:
        try:
            os.close(fd)
        except OSError:
            pass
        raise
    os.chmod(CONFIG_PATH, 0o600)


def forget_key() -> bool:
    """删除保存的 config 文件。返回是否真的删了东西。"""
    if not CONFIG_PATH.exists():
        return False
    CONFIG_PATH.unlink()
    return True


def describe_status() -> str:
    """给 --show-config 用的人读字符串。不打印 key 本身。"""
    lines = [f"配置文件路径: {CONFIG_PATH}"]
    if CONFIG_PATH.exists():
        st = CONFIG_PATH.stat()
        mode = stat.filemode(st.st_mode)
        data = {}
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
        lines.append(f"文件存在: 是 ({mode})")
        lines.append(f"保存时间: {data.get('saved_at', '未知')}")
        key = data.get("api_key", "")
        masked = f"{key[:6]}...{key[-4:]}" if len(key) > 12 else "(格式异常)"
        lines.append(f"Key 预览: {masked}")
    else:
        lines.append("文件存在: 否（尚未保存）")
    env_key = os.environ.get("STEP_API_KEY")
    lines.append(f"环境变量 STEP_API_KEY: {'已设置（优先级最高）' if env_key else '未设置'}")
    return "\n".join(lines)
