"""video-deconstruct 主入口（原生视频路径版）。

用法:
    python scripts/analyze.py /path/to/video.mp4
    python scripts/analyze.py video.mp4 --output-dir ./reports
    python scripts/analyze.py video.mp4 --comments-file comments.txt   # v2 占位
    python scripts/analyze.py video.mp4 --keep-upload                  # 保留云端文件
    python scripts/analyze.py --save-key                               # 重新输入并保存 API Key
    python scripts/analyze.py --forget-key                             # 删除已保存的 API Key
    python scripts/analyze.py --show-config                            # 显示 key 保存位置 / 状态
"""
from __future__ import annotations

import argparse
import getpass
import json
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
sys.path.insert(0, str(SCRIPT_DIR))

import compress  # noqa: E402
import config  # noqa: E402
import render_report  # noqa: E402
import stepfun_client  # noqa: E402

STEPCLAW_MAX_BYTES = 10 * 1024 * 1024  # StepClaw 上传上限
MAX_RETRIES = 2  # 一致性自检失败后最多重试次数（0 = 关闭重试）


def _load_text(path: Path) -> str:
    return path.read_text(encoding="utf-8")


def _extract_failures(analysis: dict) -> list[tuple[str, dict]]:
    qc = analysis.get("一致性自检") or {}
    return [
        (name, data)
        for name, data in qc.items()
        if isinstance(data, dict) and data.get("通过") is False
    ]


def _build_correction_prompt(failures: list[tuple[str, dict]], prior: dict) -> str:
    """
    把上一次失败的一致性自检喂回 rubric，让模型二次生成。

    ⚠️ 立瑄 TODO — 这一段是重试循环里最值得你亲自调的 prompt。当前采用"硬锚定"
    策略：把真实总时长塞给模型当硬约束。可尝试的其他风格：
      · 苏格拉底式："看一下你自己的自检，是哪一步算错了？"
      · 回放式："你上次段落[-1].end=XX:XX 超过了总时长 YY:YY，重写段落。"
      · 冻结式："主题/事件 保留原答案，只重做 节奏.段落。"
    改完一版就跑一次 analyze.py 看它能不能收敛，比光读 prompt 有效。
    """
    duration = prior.get("节奏", {}).get("总时长秒", 0) or 0
    mm, ss = int(duration // 60), int(duration % 60)
    lines = [
        "",
        "==================================================",
        "⚠️ 重试：上一次输出的一致性自检未通过，请修正后重新生成完整 JSON。",
        "==================================================",
        f"视频实际总时长 = {duration:.1f}s（即 {mm:02d}:{ss:02d}）。",
        f"所有段落 start/end 以及事件.高潮时刻秒 必须落在 [00:00, {mm:02d}:{ss:02d}] 内。",
        "",
        "上次失败的规则：",
    ]
    for name, data in failures:
        lines.append(f"  - {name}：{data.get('规则', '')}")
        for k, v in data.items():
            if k in ("规则", "通过"):
                continue
            lines.append(f"      · {k} = {v}")
    lines.append("")
    lines.append("请重新生成整个 JSON（不是只改 一致性自检），确保所有 通过=true。")
    return "\n".join(lines)


def _validate(video_path: Path) -> None:
    if not video_path.exists():
        raise SystemExit(f"❌ 文件不存在: {video_path}")
    if video_path.suffix.lower() != ".mp4":
        raise SystemExit(
            f"❌ 只支持 mp4，当前是 {video_path.suffix}。\n"
            f"   先转一下: ffmpeg -i {video_path.name} {video_path.stem}.mp4"
        )


def run(video_path: Path, output_dir: Path, comments_file: Path | None, keep_upload: bool) -> Path:
    _validate(video_path)

    if comments_file is not None:
        print(f"⚠️  --comments-file 在 v1 暂未启用（已忽略 {comments_file}），v2 会接入评论分析。")

    upload_path = video_path
    compressed_tmp: Path | None = None
    size_mb = video_path.stat().st_size / 1024 / 1024
    if video_path.stat().st_size > STEPCLAW_MAX_BYTES:
        print(f"🗜  输入 {size_mb:.1f}MB > 10MB（StepClaw 上限），自动压缩中...")
        compressed_tmp = compress.compress_to_target(video_path, target_mb=10)
        upload_path = compressed_tmp
        size_mb = compressed_tmp.stat().st_size / 1024 / 1024
        print(f"   ✅ 压缩后 {size_mb:.2f}MB")

    print(f"📤 上传视频到 StepFun: {upload_path.name} ({size_mb:.1f}MB)")
    file_id = stepfun_client.upload_video(upload_path)
    print(f"   file_id = {file_id}")

    try:
        print(f"🤖 调 step-1o-turbo-vision 拆解中...")
        system_prompt = _load_text(SKILL_ROOT / "prompts" / "system.txt")
        base_rubric = _load_text(SKILL_ROOT / "prompts" / "analysis_rubric.txt")

        rubric_prompt = base_rubric
        analysis: dict = {}
        for attempt in range(MAX_RETRIES + 1):
            analysis = stepfun_client.analyze_video(
                file_id=file_id,
                system_prompt=system_prompt,
                rubric_prompt=rubric_prompt,
            )
            failures = _extract_failures(analysis)
            if not failures:
                if attempt > 0:
                    print(f"   ✅ 第 {attempt + 1} 次尝试通过一致性自检")
                break
            if attempt < MAX_RETRIES:
                names = ", ".join(n for n, _ in failures)
                print(f"   ⚠️ 第 {attempt + 1} 次尝试 {len(failures)} 条自检失败（{names}），重试中...")
                rubric_prompt = base_rubric + _build_correction_prompt(failures, analysis)
            else:
                print(f"   ⚠️ 重试 {MAX_RETRIES} 次后仍有 {len(failures)} 条失败；报告会带告警发出")

        print("📝 渲染报告...")
        report_md = render_report.render(
            analysis=analysis,
            video_name=video_path.name,
        )

        output_dir.mkdir(parents=True, exist_ok=True)
        report_path = output_dir / f"{video_path.stem}-report.md"
        report_path.write_text(report_md, encoding="utf-8")
        json_path = output_dir / f"{video_path.stem}-analysis.json"
        json_path.write_text(json.dumps(analysis, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"✅ 报告: {report_path}")
        print(f"🔍 原始 JSON: {json_path}")
        return report_path

    finally:
        if keep_upload:
            print(f"📎 保留云端文件: {file_id}（--keep-upload）")
        else:
            stepfun_client.delete_file(file_id)
            print(f"🧹 已清理云端文件: {file_id}")
        if compressed_tmp is not None:
            compressed_tmp.unlink(missing_ok=True)


def _prompt_and_save_key() -> None:
    """交互式提示用户输入 key，校验格式后存到 ~/.stepclaw/...（chmod 600）。"""
    if not sys.stdin.isatty():
        raise SystemExit(
            f"❌ 未找到 STEP_API_KEY 且当前非交互终端，无法弹出输入框。\n"
            f"   选一：`export STEP_API_KEY=sk-xxx`，或手写文件 {config.CONFIG_PATH}（JSON: {{\"api_key\": \"sk-...\"}})"
        )
    key = getpass.getpass("🔑 首次使用，请输入 StepFun API Key (sk-..., 输入不回显): ").strip()
    if not key:
        raise SystemExit("❌ 没输入任何内容，退出。")
    if not key.startswith("sk-"):
        raise SystemExit("❌ Key 格式不对（应以 sk- 开头）。从 https://platform.stepfun.com 拿一个。")
    config.save_key(key)
    print(f"✅ 已保存到 {config.CONFIG_PATH}（仅本人可读，chmod 600）")
    print("   下次运行无需再输入。换 key 用 `--save-key`，删除用 `--forget-key`。")


def _preflight() -> None:
    """首次跑提示输入 key 并落盘，之后直接放行。"""
    if config.has_any_key():
        return
    _prompt_and_save_key()


def main() -> None:
    ap = argparse.ArgumentParser(description="短视频五维拆解 (step-1o-turbo-vision · 原生视频路径)")
    ap.add_argument("video", type=Path, nargs="?", help="本地 mp4 文件路径")
    ap.add_argument("--output-dir", type=Path, default=SKILL_ROOT / "output", help="报告输出目录")
    ap.add_argument("--comments-file", type=Path, default=None, help="(v2 占位) 评论 txt 文件")
    ap.add_argument("--keep-upload", action="store_true", help="分析完后保留云端文件，默认自动删除")
    ap.add_argument("--save-key", action="store_true", help="（重新）输入并保存 API Key 后退出")
    ap.add_argument("--forget-key", action="store_true", help="删除已保存的 API Key 后退出")
    ap.add_argument("--show-config", action="store_true", help="显示 API Key 保存状态（不泄露 key）后退出")
    args = ap.parse_args()

    if args.show_config:
        print(config.describe_status())
        return
    if args.forget_key:
        deleted = config.forget_key()
        print("🧹 已删除保存的 API Key。" if deleted else "（无已保存的 API Key，没什么可删。）")
        return
    if args.save_key:
        _prompt_and_save_key()
        return

    if args.video is None:
        ap.error("缺少参数 video（本地 mp4 路径）。用 --help 看用法。")

    _preflight()
    run(args.video.resolve(), args.output_dir.resolve(), args.comments_file, args.keep_upload)


if __name__ == "__main__":
    main()
