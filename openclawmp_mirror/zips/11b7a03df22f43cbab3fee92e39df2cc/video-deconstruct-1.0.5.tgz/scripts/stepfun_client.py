"""StepFun chat completions 封装：原生视频路径（upload → stepfile:// → chat）。"""
from __future__ import annotations

import json
import os
from pathlib import Path

import httpx
from dotenv import load_dotenv
from openai import OpenAI

import config

MODEL = "step-1o-turbo-vision"
BASE_URL = "https://api.stepfun.com/v1"
UPLOAD_TIMEOUT_SEC = 600.0
ANALYZE_TIMEOUT_SEC = 420.0

load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def _api_key() -> str:
    key = os.environ.get("STEP_API_KEY")
    if key:
        return key
    saved = config.load_saved_key()
    if saved:
        return saved
    raise RuntimeError(
        "STEP_API_KEY 未设置。直接跑 `python scripts/analyze.py <video.mp4>` 会在首次启动时"
        f"提示你输入并保存到 {config.CONFIG_PATH}。"
        "或手动 `export STEP_API_KEY=sk-xxx` / 写到 skill 根目录的 .env；"
        "key 从 https://platform.stepfun.com 拿。"
    )


def _client() -> OpenAI:
    return OpenAI(api_key=_api_key(), base_url=BASE_URL)


def upload_video(video_path: Path) -> str:
    """上传 mp4 到 StepFun 文件 API (purpose=storage)，返回 file_id。"""
    with video_path.open("rb") as f:
        resp = httpx.post(
            f"{BASE_URL}/files",
            headers={"Authorization": f"Bearer {_api_key()}"},
            files={"file": (video_path.name, f, "video/mp4")},
            data={"purpose": "storage"},
            timeout=UPLOAD_TIMEOUT_SEC,
        )
    if resp.status_code != 200:
        raise RuntimeError(f"文件上传失败 (HTTP {resp.status_code}): {resp.text}")
    return resp.json()["id"]


def delete_file(file_id: str) -> None:
    """用完后删除云端文件，避免占用配额。失败不抛。"""
    try:
        httpx.delete(
            f"{BASE_URL}/files/{file_id}",
            headers={"Authorization": f"Bearer {_api_key()}"},
            timeout=30.0,
        )
    except Exception as e:
        print(f"⚠️  清理云端文件 {file_id} 失败（可忽略）: {e}")


def analyze_video(file_id: str, system_prompt: str, rubric_prompt: str) -> dict:
    """调用 step-1o-turbo-vision，传 stepfile:// URL，返回解析后的 JSON dict。"""
    client = _client()
    user_content = [
        {"type": "video_url", "video_url": {"url": f"stepfile://{file_id}"}},
        {"type": "text", "text": rubric_prompt + "\n\n严格输出 JSON，禁止任何 markdown 包裹。"},
    ]
    resp = client.with_options(timeout=ANALYZE_TIMEOUT_SEC).chat.completions.create(
        model=MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        response_format={"type": "json_object"},
        max_tokens=4096,
        temperature=0.3,
    )
    raw = resp.choices[0].message.content
    return json.loads(raw)
