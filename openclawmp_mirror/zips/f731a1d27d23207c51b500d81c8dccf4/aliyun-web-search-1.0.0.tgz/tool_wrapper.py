#!/usr/bin/env python3
"""
OpenClaw 工具包装器
将 aliyun_search 封装为 OpenClaw 可调用的工具
"""

import os
import sys
import json

# 添加当前目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from aliyun_search import aliyun_search, format_results_for_llm

def main():
    """OpenClaw 工具入口"""
    # 读取标准输入的 JSON 参数
    try:
        params = json.load(sys.stdin)
    except json.JSONDecodeError:
        # 如果没有标准输入，从命令行参数读取
        if len(sys.argv) >= 2:
            params = {"query": sys.argv[1]}
            if len(sys.argv) >= 3:
                params["count"] = int(sys.argv[2])
        else:
            print(json.dumps({"error": "需要提供搜索参数"}), file=sys.stderr)
            sys.exit(1)
    
    query = params.get("query", "")
    count = params.get("count", 5)
    
    if not query:
        print(json.dumps({"error": "query 参数不能为空"}), file=sys.stderr)
        sys.exit(1)
    
    try:
        result = aliyun_search(query, count)
        
        if "error" in result:
            print(json.dumps({"error": result["error"]}), file=sys.stderr)
            sys.exit(1)
        
        # 输出格式化结果
        formatted = format_results_for_llm(result)
        
        # 返回结构化结果
        output = {
            "query": result.get("query", query),
            "results": result.get("results", []),
            "tools": result.get("tools", []),
            "formatted": formatted
        }
        
        print(json.dumps(output, ensure_ascii=False))
        
    except Exception as e:
        print(json.dumps({"error": str(e)}), file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
