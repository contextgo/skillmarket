---
name: aliyun-web-search
version: 1.0.0
description: 阿里云百炼通义Web-Search服务，提供实时互联网全栈信息检索。与内置web_search不同，此工具使用阿里云API，无需Brave API Key。
homepage: https://dashscope.aliyuncs.com/api/v1/mcps/WebSearch/mcp
metadata:
  {
    "openclaw":
      {
        "emoji": "🔍",
        "requires": { "env": ["DASHSCOPE_API_KEY"] },
        "install": [
          {
            "id": "configure",
            "kind": "manual",
            "label": "配置API密钥",
            "description": "设置DASHSCOPE_API_KEY环境变量"
          }
        ]
      },
  }
---

# Aliyun Web Search Skill

阿里云百炼通义Web-Search服务，提供实时互联网全栈信息检索。

## 与内置 web_search 的区别

| 特性 | aliyun_search (本工具) | web_search (内置) |
|------|------------------------|-------------------|
| API提供商 | 阿里云百炼 | Brave Search |
| 需要API Key | DASHSCOPE_API_KEY | BRAVE_API_KEY |
| 中文支持 | 优秀 | 一般 |
| 实时性 | 实时同步互联网 | 实时同步互联网 |
| 免费额度 | 每月2000次 | 需要付费订阅 |

## 使用方法

### 执行阿里云搜索

当用户需要搜索实时信息时，直接调用脚本即可：

```powershell
$env:DASHSCOPE_API_KEY="sk-xxx...xxx"; python "C:\Users\39795\.openclaw\workspace\skills\aliyun-web-search\aliyun_search.py" "搜索关键词" 结果数量
```

脚本会直接输出搜索结果到 stdout，无需临时文件，OpenClaw 可直接捕获输出。

**参数说明：**
- `搜索关键词`：要搜索的内容（必填）
- `结果数量`：返回的搜索结果数量，默认5条（可选）

**使用示例：**
```powershell
$env:DASHSCOPE_API_KEY="sk-xxx...xxx"; python "C:\Users\39795\.openclaw\workspace\skills\aliyun-web-search\aliyun_search.py" "深圳今天天气" 3
```

**参数说明：**
- `搜索关键词`：要搜索的内容（必填）
- `结果数量`：返回的搜索结果数量，默认5条（可选）
- `输出文件路径`：结果保存的txt文件路径（可选，如果不提供则直接输出）

### 使用示例

**示例：搜索深圳天气**
```powershell
# 步骤1：执行搜索
$env:DASHSCOPE_API_KEY="sk-xxx...xxx"; python "C:\Users\39795\.openclaw\workspace\skills\aliyun-web-search\aliyun_search.py" "深圳今天天气" 3 "C:\Users\39795\.openclaw\workspace\temp_search_result.txt"

# 步骤2：读取结果（使用read工具）
read "C:\Users\39795\.openclaw\workspace\temp_search_result.txt"

# 步骤3：删除临时文件
Remove-Item "C:\Users\39795\.openclaw\workspace\temp_search_result.txt"
```

## 何时使用 aliyun_search 而非内置 web_search

✅ **使用 aliyun_search 当：**
- 需要中文搜索（效果更好）
- 需要查询天气、股票、金价等实时数据
- 内置 `web_search` 无法使用（没有 Brave API Key）
- 需要每月2000次免费搜索额度

❌ **使用内置 `web_search` 当：**
- 你有 Brave API Key
- 需要英文搜索
- 需要特定 Brave 搜索功能

## 配置要求

环境变量 `DASHSCOPE_API_KEY` 已配置（值已脱敏）

## 计费说明

- **免费额度**：每月2000次免费额度
- **限流**：单用户5qps
- **付费方式**：免费额度用完后自动转为按量付费

## 技术支持

- **服务提供商**：通义实验室
- **平台**：阿里云百炼
- **文档**：https://dashscope.aliyuncs.com/api/v1/mcps/WebSearch/mcp
