#!/usr/bin/env python3
"""
阿里云百炼通义Web-Search MCP服务工具
OpenClaw 工具封装版本

提供 aliyun_search 工具，与内置 web_search 区分
"""

import os
import sys
import json
import requests
from typing import Dict, Any, List, Optional

# MCP服务配置
MCP_BASE_URL = "https://dashscope.aliyuncs.com/api/v1/mcps/WebSearch/mcp"
API_KEY_ENV = "DASHSCOPE_API_KEY"

def get_api_key() -> str:
    """获取API密钥"""
    api_key = os.environ.get(API_KEY_ENV)
    if not api_key:
        raise ValueError(f"请设置环境变量 {API_KEY_ENV}")
    return api_key

def aliyun_search(query: str, count: int = 5) -> Dict[str, Any]:
    """
    执行阿里云联网搜索
    
    Args:
        query: 搜索查询词
        count: 最大返回结果数 (1-10)
    
    Returns:
        搜索结果字典，包含 titles, snippets, urls 等
    """
    api_key = get_api_key()
    
    # 限制结果数量
    count = max(1, min(count, 10))
    
    # 构建请求头
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    # 构建请求体
    payload = {
        "method": "tools/call",
        "params": {
            "name": "bailian_web_search",
            "arguments": {
                "query": query,
                "max_results": count
            }
        },
        "jsonrpc": "2.0",
        "id": 1
    }
    
    try:
        response = requests.post(
            MCP_BASE_URL,
            headers=headers,
            json=payload,
            timeout=30
        )
        response.raise_for_status()
        
        # 处理编码
        response.encoding = 'utf-8'
        result = response.json()
        
        # 解析MCP响应
        if "result" in result:
            return _parse_search_result(result["result"])
        elif "error" in result:
            return {"error": result["error"]}
        else:
            return {"error": "未知响应格式", "raw_response": result}
            
    except requests.exceptions.RequestException as e:
        return {"error": f"请求失败: {str(e)}"}
    except json.JSONDecodeError as e:
        return {"error": f"JSON解析失败: {str(e)}"}

def _parse_search_result(result: Dict[str, Any]) -> Dict[str, Any]:
    """解析搜索结果为标准格式"""
    output = {
        "query": "",
        "results": [],
        "tools": []
    }
    
    content_list = result.get("content", [])
    
    if not content_list:
        return output
    
    # 获取第一个content项
    first_item = content_list[0]
    if isinstance(first_item, dict) and "text" in first_item:
        try:
            # 解析text字段中的JSON
            text_data = json.loads(first_item["text"])
            
            # 获取查询词
            output["query"] = text_data.get("query", "")
            
            # 获取pages数组
            pages = text_data.get("pages", [])
            
            # 格式化每个页面
            for page in pages:
                output["results"].append({
                    "title": page.get("title", ""),
                    "snippet": page.get("snippet", ""),
                    "url": page.get("url", "")
                })
            
            # 获取工具结果（如天气）
            tools = text_data.get("tools", [])
            for tool in tools:
                if tool.get("result"):
                    output["tools"].append({
                        "type": tool.get("type", ""),
                        "result": tool.get("result", "")
                    })
                    
        except json.JSONDecodeError:
            output["results"].append({
                "title": "解析结果",
                "snippet": first_item.get("text", ""),
                "url": ""
            })
    
    return output

def format_results_for_llm(result: Dict[str, Any]) -> str:
    """将结果格式化为适合LLM阅读的文本"""
    if "error" in result:
        return f"搜索失败: {result['error']}"
    
    results = result.get("results", [])
    if not results:
        return "未找到相关结果"
    
    formatted = f"搜索: {result.get('query', '')}\n\n"
    
    for i, item in enumerate(results, 1):
        title = item.get("title", f"结果 {i}")
        snippet = item.get("snippet", "")
        url = item.get("url", "")
        
        formatted += f"{i}. {title}\n"
        if snippet:
            formatted += f"   {snippet}\n"
        if url:
            formatted += f"   来源: {url}\n"
        formatted += "\n"
    
    # 添加工具结果
    tools = result.get("tools", [])
    for tool in tools:
        if tool.get("type") == "weather":
            formatted += f"天气信息: {tool.get('result', '')}\n"
    
    return formatted

# OpenClaw 工具接口
def main():
    """命令行入口点 - 供OpenClaw调用"""
    if len(sys.argv) < 2:
        print("用法: python aliyun_search.py <搜索查询> [结果数量]", file=sys.stderr)
        sys.exit(1)
    
    query = sys.argv[1]
    count = int(sys.argv[2]) if len(sys.argv) > 2 else 5
    
    try:
        result = aliyun_search(query, count)
        formatted = format_results_for_llm(result)
        
        # 直接输出到 stdout，OpenClaw 通过 exec 捕获输出
        # 无需临时文件，避免文件堆积问题
        # 使用 UTF-8 编码输出，避免中文乱码
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
        print(formatted)
    except Exception as e:
        print(f"错误: {str(e)}", file=sys.stderr)
        sys.exit(1)

if __name__ == "__main__":
    main()
