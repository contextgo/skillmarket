# Next.js App Router Guide

## Core Concepts

### File-Based Routing
- page.tsx → route handler
- layout.tsx → shared UI wrapper
- loading.tsx → Suspense fallback
- error.tsx → error boundary
- not-found.tsx → 404 handler

### Server Actions
```tsx
async function createOrder(formData: FormData) {
  'use server'
  const item = formData.get('item')
  await db.insertOrder(item)
  revalidatePath('/orders')
}
```

### Route Groups
Use (folder) for organization without URL impact: (marketing)/about, (dashboard)/stats

## Performance
- Static generation by default (no loading.tsx = static)
- Dynamic rendering with cookies(), headers()
- Streaming with Suspense boundaries
- Image optimization with next/image

## Middleware
- Authentication checks
- Redirect logic
- Internationalization
- A/B testing

## Best Practices
- Keep server components as the default
- Use route handlers for APIs
- Implement proper error boundaries
- Use parallel routes for dashboards
- Optimize with dynamic = 'force-static' where possible