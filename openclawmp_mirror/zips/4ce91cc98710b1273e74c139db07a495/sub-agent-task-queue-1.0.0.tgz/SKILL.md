---
name: sub-agent-task-queue
description: "子 Agent 任务队列管理，支持并行调度、优先级和依赖关系"
version: 1.0.0
tags: [agent, sub-agent, orchestration, parallel, task-queue]
---

# 子 Agent 任务队列管理

## 核心模式：STATE.yaml 黑板

所有 Agent 共享进度文件，主 Agent 只调度不执行：

```yaml
# STATE.yaml
tasks:
  - id: research-market
    status: done
    assignee: pm-report-researcher
    output: temp/market-research.md

  - id: write-report
    status: in_progress
    depends_on: [research-market]

  - id: publish-report
    status: pending
    depends_on: [write-report]
```

## 并行调度规则

独立任务必须并行 spawn，有依赖才串行：

```python
# 3 个独立任务同时 spawn
sessions_spawn(task="研究竞品", label="research")
sessions_spawn(task="分析数据", label="analysis")
sessions_spawn(task="检查安全", label="security")
sessions_yield()  # 等待所有结果
```

## 优先级

| 级别 | 动作 | 说明 |
|------|------|------|
| P0 | 立即执行 | 安全问题、用户要求 |
| P1 | 当批执行 | 当前周期 |
| P2 | 排队执行 | 下个周期 |
| P3 | 记录待做 | 空闲时处理 |

## 进度追踪

```python
sessions = sessions_list(kinds=["subagent"], activeMinutes=60)
for s in sessions:
    if s.status == "completed":
        # 读取输出，更新 STATE.yaml
    elif s.status == "stuck":
        # steering 或重新 spawn
```

## 经验教训

1. 子 Agent 继承 workspace → 用不同输出路径避免冲突
2. 每个 session 要有明确 label
3. 完成通知是 push-based → 不要轮询
4. 设 runTimeoutSeconds 防卡死
5. STATE.yaml 变更要 git commit
