#!/usr/bin/env python3
"""
自动清理workspace下的临时文件
"""

import os
import sys
import argparse
from pathlib import Path
from datetime import datetime, timedelta

# 配置
WORKSPACE = Path("/root/.openclaw/workspace")

# 保留的文件/文件夹
KEEP_FILES = {
    'AGENTS.md', 'SOUL.md', 'USER.md', 'TOOLS.md', 'IDENTITY.md', 
    'HEARTBEAT.md', 'BOOTSTRAP.md', 'MEMORY.md', 'MEMORY.md',
    '.git', '.openclaw', 'memory', 'skills', '.clawhub'
}

# 保留的扩展名
KEEP_EXTENSIONS = {'.py', '.sh', '.yaml', '.yml'}


def get_files_to_cleanup(days=7, dry_run=True):
    """获取需要清理的文件"""
    cutoff = datetime.now() - timedelta(days=days)
    to_cleanup = []
    
    for item in WORKSPACE.iterdir():
        # 跳过保留项
        if item.name in KEEP_FILES:
            continue
            
        # 检查修改时间
        mtime = datetime.fromtimestamp(item.stat().st_mtime)
        if mtime > cutoff:
            continue
            
        to_cleanup.append(item)
    
    return to_cleanup


def cleanup_files(days=7, dry_run=True, yes=False):
    """清理文件"""
    to_cleanup = get_files_to_cleanup(days, dry_run)
    
    if not to_cleanup:
        print("没有需要清理的文件")
        return
        
    print(f"将{'预览' if dry_run else '清理'} {len(to_cleanup)} 个文件/文件夹:")
    for item in to_cleanup:
        print(f"  - {item.name}")
    
    if dry_run:
        print("\n这是预览模式，不会实际删除。")
        print("使用 --days 7 --yes 执行实际清理")
        return
        
    if not yes:
        response = input("\n确认删除? (y/n): ")
        if response.lower() != 'y':
            print("已取消")
            return
            
    # 执行删除
    for item in to_cleanup:
        try:
            if item.is_dir():
                import shutil
                shutil.rmtree(item)
            else:
                item.unlink()
            print(f"已删除: {item.name}")
        except Exception as e:
            print(f"删除失败 {item.name}: {e}")
    
    print(f"\n清理完成，共删除 {len(to_cleanup)} 项")


def main():
    parser = argparse.ArgumentParser(description="自动清理workspace临时文件")
    parser.add_argument('--days', type=int, default=7, help="保留天数（默认7天）")
    parser.add_argument('--dry-run', action='store_true', help="预览模式，不实际删除")
    parser.add_argument('--yes', action='store_true', help="直接执行，不确认")
    
    args = parser.parse_args()
    cleanup_files(args.days, args.dry_run, args.yes)


if __name__ == '__main__':
    main()
