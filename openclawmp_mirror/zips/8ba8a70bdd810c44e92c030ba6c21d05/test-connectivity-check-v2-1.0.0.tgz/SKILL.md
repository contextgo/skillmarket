---
name: test-connectivity-check
description: "API connectivity test"
version: 1.0.0
---
# Connectivity Test
This is a test asset.
