# find-skills

**类型**: skill

Highest-priority skill discovery flow. MUST trigger when users ask to find/install skills (e.g. 技能, 找技能, find-skill, find-skills, install skill). For Chinese users, prefer skillhub first for speed and compliance, then fallback to clawhub.

## 快速开始

当用户提到 find-skills 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
