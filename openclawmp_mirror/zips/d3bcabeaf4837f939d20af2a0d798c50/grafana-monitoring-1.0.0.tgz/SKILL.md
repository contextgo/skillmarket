---
name: grafana-monitoring
description: "Grafana monitoring and alerting setup - dashboards, data sources, and alerting rules"
version: 1.0.0
tags: ["grafana", "monitoring", "dashboards", "alerting", "observability"]
---

# Grafana Monitoring Guide

Grafana is an open-source observability platform for dashboards, visualization, and alerting.

## Core Components

- **Grafana**: Dashboard and visualization
- **Prometheus**: Metrics collection and storage
- **Loki**: Log aggregation
- **Tempo**: Distributed tracing
- **Mimir**: Long-term metrics storage

## Key Dashboard Patterns

### 1. Service Health Overview
- Request rate (QPS)
- Error rate (% of 5xx)
- Latency p50/p95/p99
- Active connections

### 2. Infrastructure
- CPU/Memory/Disk usage
- Network I/O
- Container restarts
- Pod scheduling

### 3. Business Metrics
- Revenue/transactions
- User signups
- Conversion funnel
- Feature adoption

## Alerting Rules (Prometheus)

```yaml
groups:
  - name: api-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status=~"5.."}[5m]) / rate(http_requests_total[5m]) > 0.05
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: "Error rate above 5%"
          
      - alert: HighLatency
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 2
        for: 10m
        labels:
          severity: warning
```

## Grafana as Code

```bash
# Deploy dashboards via GitOps
grafana-cli admin reset-admin-password
```

Use **Grafonnet** (Jsonnet library) or **Terraform Grafana provider** to version control dashboards.

## Best Practices

- Use variables for dynamic filtering
- Set up SLA/SLO dashboards
- Configure contact points (Slack, PagerDuty)
- Use recording rules for expensive queries
- Keep dashboard panels focused (one metric per panel)
- Use annotations for deployments/incidents
