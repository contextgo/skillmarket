---
name: session-recovery-pattern
description: "AI Agent 会话恢复模式，Gateway 重启后的状态恢复和任务续接"
version: 1.0.0
tags: [agent, session, recovery, gateway, state, resilience]
---

# 会话恢复模式

## 问题

AI Agent 系统不可避免会遭遇 Gateway 重启、context 压缩、进程崩溃等中断。如何在中断后快速恢复状态并继续任务？

## 三层恢复机制

### 第一层：文件状态（最可靠）

所有重要状态必须写入文件，不依赖内存：

```
workspace/
├── temp/
│   ├── recovery-{timestamp}.json   ← 恢复清单
│   └── {task}-plan.md              ← 任务计划
├── memory/
│   ├── daily-notes/YYYY-MM-DD.md   ← 每日日志
│   └── active-projects/{name}.md   ← 项目状态
└── STATE.yaml                      ← 多Agent共享进度
```

### 第二层：Checkpoint

复杂任务每完成一个阶段就提交 git：

```bash
cd ~/.openclaw/workspace
git add -A
git commit -m "checkpoint: [任务名] Phase X 完成"
```

### 第三层：Session 检查

Gateway 重启后：

```python
# 恢复流程
1. 读取 recovery-*.json → 找到卡住的 session
2. 用 sessions_send 发送恢复消息
3. 读取 daily-notes → 找到 In Progress 任务
4. sessions_list 检查所有 session 的最后消息
5. 主动续接未完成任务
```

## Recovery 文件格式

```json
{
  "timestamp": "2026-03-14T03:00:00Z",
  "stuck_sessions": ["session-key-1", "session-key-2"],
  "in_progress_tasks": [
    {"name": "被动收入构建", "status": "Batch6 发布中"}
  ],
  "last_known_state": {
    "polymarket_round": 31,
    "assets_published": 52,
    "evomap_bundles": 69
  }
}
```

## 最佳实践

1. **写再读** — 任何重要状态变更都立即写文件
2. **幂等操作** — 恢复后的操作不因重复执行而出问题
3. **进度标记** — 用 "## In Progress" / "### ✅ 已完成" 标记
4. **摘要先行** — 日志记录结论而非过程
5. **标签索引** — 用 #tag 方便后续检索
SKILL.md_EOF

# Asset 9: Checkpoint Git Strategy
cat > /tmp/openclawmp-batch7/checkpoint-git-strategy/README.md << 'EXPERIENCE_EOF'
# Git Checkpoint 工作流最佳实践

## 核心原则

在长时间运行的 AI Agent 任务中，Git checkpoint 是防止 context 压缩导致状态丢失的最有效手段。

## 什么时候创建 Checkpoint

| 场景 | 触发条件 | Commit Message 格式 |
|------|---------|-------------------|
| 任务阶段完成 | 每个 Phase 完成 | `checkpoint: [任务名] Phase N 完成` |
| 重要决策 | 做出不可逆决定 | `decision: [决策摘要]` |
| 配置变更 | 修改系统配置 | `config: [变更说明]` |
| 错误修复 | 修复 bug | `fix: [问题描述]` |
| 日轮结束 | 一天工作结束 | `eod: YYYY-MM-DD summary` |

## 实战经验

### 正确做法
```bash
# 阶段性 checkpoint
git add -A && git commit -m "checkpoint: Polymarket Batch5 完成 6/6 成功"

# 紧急保存（context 快满时）
git add -A && git commit -m "emergency: context 85% 内存溢出前保存"

# 计划文件 + checkpoint 配合
# 先更新 plan.md 的进度，再 commit
```

### 错误做法
```bash
# ❌ 不写计划文件就 commit（没有上下文）
git add -A && git commit -m "update"

# ❌ 只 commit 部分文件（状态不完整）
git add main.py && git commit -m "checkpoint"

# ❌ 几个小时才 commit 一次（中间状态丢失）
```

## 计划文件 + Git = 完整恢复

```
temp/
└── [任务名]-plan.md      ← 人类可读的任务进度
    ├── [x] 步骤1 ✅
    ├── [x] 步骤2 ✅
    ├── [ ] 步骤3 ← 当前
    └── [ ] 步骤4

Git History:
  checkpoint: Phase 1 done
  checkpoint: Phase 2 done
  ← 如果这里 session 崩溃
  → 新 session 读取 plan.md → 从步骤3 继续
```

## 恢复流程

1. `git log --oneline -10` 查看最近 checkpoint
2. 读取 `temp/{任务名}-plan.md` 了解进度
3. 从最后一个未完成步骤继续

## .gitignore 建议

```
# 大文件和临时数据
*.pyc
__pycache__/
.env
credentials/
node_modules/

# 但不要 ignore 计划文件和日志！
# !temp/*-plan.md
# !memory/daily-notes/
```
EXPERIENCE_EOF

# Asset 10: Sub-agent Task Queue
cat > /tmp/openclawmp-batch7/sub-agent-task-queue/SKILL.md << 'SKILL_EOF'
---
name: sub-agent-task-queue
description: "子 Agent 任务队列管理，支持并行调度、优先级和依赖关系"
version: 1.0.0
tags: [agent, sub-agent, orchestration, parallel, task-queue]
---

# 子 Agent 任务队列管理

## 核心模式：STATE.yaml 黑板

所有 Agent 共享一个进度文件，主 Agent 不亲自执行，只做调度：

```yaml
# STATE.yaml
tasks:
  - id: research-market
    status: done
    assignee: pm-report-researcher
    output: temp/market-research.md
    
  - id: write-report
    status: in_progress
    assignee: pm-report-writer
    depends_on: [research-market]
    output: temp/final-report.md
    
  - id: publish-report
    status: pending
    depends_on: [write-report]
```

## 并行调度规则

**独立任务必须并行，有依赖才串行：**

```
# ✅ 正确：3 个独立任务并行 spawn
Agent A: 研究竞品
Agent B: 分析数据  
Agent C: 检查安全

# ❌ 错误：串行执行独立任务
先 A，等完成，再 B，等完成，再 C
```

## Sessions_spawn 用法

```python
# 并行 spawn 3 个子 Agent
tasks = [
    {"task": "分析认证模块安全性", "label": "security-audit"},
    {"task": "分析缓存性能", "label": "perf-analysis"},
    {"task": "验证 API 兼容性", "label": "api-compat"},
]

for t in tasks:
    sessions_spawn(task=t["task"], label=t["label"], runtime="subagent")

# 等待所有结果（push-based，会自动通知完成）
sessions_yield(message="等待所有子 Agent 完成")
```

## 优先级管理

| 优先级 | 动作 | 说明 |
|--------|------|------|
| P0 | 立即执行 | 安全问题、用户明确要求 |
| P1 | 当批执行 | 当前 cron 周期 |
| P2 | 排队执行 | 下个周期 |
| P3 | 记录待做 | 空闲时处理 |

## 进度追踪

```python
# 主 Agent 定期检查
sessions = sessions_list(kinds=["subagent"], activeMinutes=60)
for s in sessions:
    if s.status == "completed":
        # 读取输出，更新 STATE.yaml
    elif s.status == "stuck":
        # 发送 steering 消息或重新 spawn
```

## 经验教训

1. 子 Agent 继承主 workspace → 文件冲突用不同输出路径
2. 每个 sub-agent session 要有明确 label → 便于追踪
3. 完成通知是 push-based → 不要轮询 sessions_list
4. 超时保护：设 runTimeoutSeconds 防止卡死
5. STATE.yaml 每次变更都 git commit → 变更历史 = 审计日志
SKILL.md_EOF

echo "Assets 7-10 done"
ls -la /tmp/openclawmp-batch7/
