# OpenClaw 安检门（安装前安全扫描）

使用安装前静态扫描替代“直接安装”。

## 执行流程

1. 解析资产引用（`skill/@author/slug` 或 `s-xxxx`）。
2. 拉取资产文件清单与文本文件内容。
3. 扫描以下风险信号：
   - 网络请求调用与可疑外传域名
   - 命令执行与危险 shell 片段
   - 文件写入/删除与敏感路径访问
   - 环境变量访问与密钥字段
4. 输出三档评级：`SAFE` / `CAUTION` / `DANGEROUS`。
5. 在 `install` 模式下执行门禁策略：
   - `SAFE`（绿灯）：允许安装
   - `CAUTION`（黄灯）：默认不装，人工复核后可 `--allow-caution`
   - `DANGEROUS`（红灯）：直接阻止安装；若本地已安装则自动卸载

## 命令

### 仅扫描（推荐默认）

```bash
python3 market-assets/openclaw-install-security-gate/scripts/skill_gate.py scan skill/@u-xxxx/slug --json-out reports/skill-gate-latest.json
```

### 扫描后安装（门禁）

```bash
python3 market-assets/openclaw-install-security-gate/scripts/skill_gate.py install skill/@u-xxxx/slug
```

可选参数：

- `--allow-caution`：CAUTION（黄灯）也继续安装
- `--force`：忽略评级强装（高风险，不建议）
- `--max-size`：限制单文件扫描大小
- `--max-files`：限制单资产扫描文件数

## 评级说明

- `SAFE`（GREEN）：未命中明显高风险，允许安装
- `CAUTION`（YELLOW）：存在可疑点，默认人工复核
- `DANGEROUS`（RED）：命中高危规则，直接阻止安装或卸载

## 人工复核清单（黄灯）

1. 是否存在 `curl|bash` / `iwr|iex` / 编码命令执行
2. 是否在同一文件出现“敏感信息访问 + 网络请求”
3. 是否出现破坏性文件系统操作
4. 失败拉取文件是否为关键脚本

## 边界

- 将该技能视为“静态安检门”，不是动态沙箱。
- 不将“未命中”解释为绝对安全。
- 对高权限资产继续执行最小权限安装与人工审批。

## 参考

规则明细见 `references/rules.md`。