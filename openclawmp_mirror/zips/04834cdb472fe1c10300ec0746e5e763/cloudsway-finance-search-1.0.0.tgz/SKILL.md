---
name: cloudsway-finance-search
description: "Financial web search via Cloudsway API. Use when: user asks about stocks, markets, crypto, investment news, earnings reports, economic data, or financial analysis. Returns real-time financial news and data. NOT for: historical price charts, live trading, or portfolio management."
homepage: https://aisearch.cloudsway.net
metadata: { "openclaw": { "emoji": "📈", "requires": { "env": ["CLOUDSWAYS_AK"], "bins": ["curl", "jq"] } } }
---

# Cloudsway Finance Search

Real-time financial news and market intelligence search for AI agents.

## When to Use

✅ **USE this skill when:**
- "查一下 xxx 股票" / "look up xxx stock"
- "最近市场行情怎么样" / "how's the market doing"
- "xxx 公司财报" / "xxx earnings report"
- "加密货币新闻" / "crypto news"
- "经济数据" / "economic indicators"
- Investment research
- Market sentiment analysis
- Company news and announcements

❌ **DON'T use this skill when:**
- Need historical price charts (use trading platforms)
- Execute trades (use broker APIs)
- Portfolio tracking (use finance apps)
- Tax calculations

## Setup

1. Get API key: https://aisearch.cloudsway.net
2. Set env: `export CLOUDSWAYS_AK="your-key"`

## Usage

**Quick market news:**
```bash
./scripts/search.sh '{"q": "stock market news today", "freshness": "Day", "count": 10}'
```

**Company research:**
```bash
./scripts/search.sh '{"q": "Tesla Q4 earnings 2026", "freshness": "Week", "count": 20, "enableContent": true, "mainText": true}'
```

**Crypto updates:**
```bash
./scripts/search.sh '{"q": "Bitcoin ETF latest news", "freshness": "Day", "count": 20}'
```

**Economic analysis:**
```bash
./scripts/search.sh '{"q": "Federal Reserve interest rate decision", "freshness": "Week", "enableContent": true, "mainText": true}'
```

## Recommended Queries

| Use Case | Query Template |
|----------|----------------|
| Stock news | `"{ticker} stock news"` |
| Earnings | `"{company} earnings report Q{n} {year}"` |
| Sector trends | `"{sector} sector outlook"` |
| Crypto | `"{coin} price analysis"` |
| Macro | `"Fed rate decision" / "inflation data"` |

## Parameters

| Param | Recommended | Notes |
|-------|-------------|-------|
| freshness | `Day` or `Week` | Financial news moves fast |
| count | 20 | Balance coverage vs noise |
| enableContent | true | For detailed analysis |
| mainText | true | Get key excerpts |

## Examples

**"帮我查一下苹果公司最近的新闻"**
```bash
./scripts/search.sh '{"q": "Apple AAPL news 2026", "freshness": "Week", "count": 20}'
```

**"What's happening with NVIDIA stock?"**
```bash
./scripts/search.sh '{"q": "NVIDIA NVDA stock analysis", "freshness": "Day", "count": 20, "enableContent": true, "mainText": true}'
```

**"比特币最新行情分析"**
```bash
./scripts/search.sh '{"q": "Bitcoin BTC market analysis", "freshness": "Day", "count": 20}'
```

## Links

- Docs: https://aisearch.cloudsway.net/docs
- Get API Key: https://aisearch.cloudsway.net
