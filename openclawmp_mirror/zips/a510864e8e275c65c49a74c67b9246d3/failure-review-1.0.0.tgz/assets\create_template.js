const { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell, 
        AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType, 
        LevelFormat, Header, Footer, PageNumber } = require('docx');
const fs = require('fs');

// 创建失败复盘报告模板
const doc = new Document({
  styles: {
    default: { 
      document: { 
        run: { font: "Microsoft YaHei", size: 24 } 
      } 
    },
    paragraphStyles: [
      { 
        id: "Title", 
        name: "Title", 
        basedOn: "Normal",
        run: { size: 56, bold: true, color: "2C3E50", font: "Microsoft YaHei" },
        paragraph: { spacing: { before: 480, after: 240 }, alignment: AlignmentType.CENTER } 
      },
      { 
        id: "Heading1", 
        name: "Heading 1", 
        basedOn: "Normal", 
        next: "Normal", 
        quickFormat: true,
        run: { size: 36, bold: true, color: "34495E", font: "Microsoft YaHei" },
        paragraph: { spacing: { before: 360, after: 180 }, outlineLevel: 0 } 
      },
      { 
        id: "Heading2", 
        name: "Heading 2", 
        basedOn: "Normal", 
        next: "Normal", 
        quickFormat: true,
        run: { size: 28, bold: true, color: "5D6D7E", font: "Microsoft YaHei" },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 } 
      },
      {
        id: "Heading3",
        name: "Heading 3",
        basedOn: "Normal",
        next: "Normal",
        quickFormat: true,
        run: { size: 24, bold: true, color: "7F8C8D", font: "Microsoft YaHei" },
        paragraph: { spacing: { before: 180, after: 90 }, outlineLevel: 2 }
      }
    ]
  },
  numbering: {
    config: [
      {
        reference: "bullet-list",
        levels: [
          { 
            level: 0, 
            format: LevelFormat.BULLET, 
            text: "•", 
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } } 
          }
        ]
      },
      {
        reference: "numbered-list",
        levels: [
          { 
            level: 0, 
            format: LevelFormat.DECIMAL, 
            text: "%1.", 
            alignment: AlignmentType.LEFT,
            style: { paragraph: { indent: { left: 720, hanging: 360 } } } 
          }
        ]
      }
    ]
  },
  sections: [{
    properties: { 
      page: { 
        margin: { top: 1440, right: 1440, bottom: 1440, left: 1440 } 
      } 
    },
    headers: {
      default: new Header({ 
        children: [new Paragraph({ 
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: "失败复盘报告", size: 20, color: "95A5A6" })]
        })] 
      })
    },
    footers: {
      default: new Footer({ 
        children: [new Paragraph({ 
          alignment: AlignmentType.CENTER,
          children: [
            new TextRun({ text: "第 ", size: 20, color: "95A5A6" }), 
            new TextRun({ children: [PageNumber.CURRENT], size: 20, color: "95A5A6" }), 
            new TextRun({ text: " 页", size: 20, color: "95A5A6" })
          ]
        })] 
      })
    },
    children: [
      // 封面标题
      new Paragraph({ 
        heading: HeadingLevel.TITLE, 
        children: [new TextRun("失败复盘报告")] 
      }),
      
      // 副标题
      new Paragraph({
        alignment: AlignmentType.CENTER,
        spacing: { after: 480 },
        children: [new TextRun({ text: "从失败中汲取力量，在复盘中获得新生", size: 28, color: "7F8C8D", italics: true })]
      }),

      // 基本信息表格
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("复盘基本信息")] 
      }),
      
      createInfoTable(),

      // 第一步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第一步：重新看待失败")] 
      }),
      new Paragraph({
        spacing: { before: 120, after: 120 },
        children: [new TextRun({ text: "核心思想：", bold: true, color: "E74C3C" })]
      }),
      new Paragraph({
        numbering: { reference: "bullet-list", level: 0 },
        children: [new TextRun('放下"我输了"的对抗心态，用万物一体的视角看待失败')]
      }),
      new Paragraph({
        numbering: { reference: "bullet-list", level: 0 },
        children: [new TextRun('失败是"我"与世界互动的失衡，而非"我"对世界的失败')]
      }),
      new Paragraph({
        numbering: { reference: "bullet-list", level: 0 },
        children: [new TextRun('接纳失败的意义不唯一，将复盘定位为循环再生的起点')]
      }),
      createInputArea("我的反思与重新定义："),

      // 第二步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第二步：追问本源")] 
      }),
      new Paragraph({
        spacing: { before: 120, after: 120 },
        children: [new TextRun({ text: "核心问题：", bold: true, color: "E74C3C" })]
      }),
      createQuestionTable(),

      // 第三步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第三步：提炼底层规律")] 
      }),
      new Paragraph({
        spacing: { before: 120, after: 120 },
        children: [new TextRun({ text: "分析维度：", bold: true, color: "E74C3C" })]
      }),
      createAnalysisTable(),

      // 第四步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第四步：理解矛盾的统一")] 
      }),
      new Paragraph({
        spacing: { before: 120, after: 120 },
        children: [new TextRun('失败的原因在于"不匹配"——欲望与行动的不匹配')]
      }),
      createInputArea('我对"不匹配"的理解：'),

      // 第五步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第五步：识别系统结果")] 
      }),
      createSystemTable(),

      // 第六步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第六步：认清隐性收获")] 
      }),
      new Paragraph({
        spacing: { before: 120, after: 120 },
        children: [new TextRun({ text: "失败是失中有得", bold: true, color: "27AE60" })]
      }),
      createGainTable(),

      // 第七步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第七步：四问分析法")] 
      }),
      createFourQuestionsTable(),

      // 第八步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第八步：聚焦个人短期目标")] 
      }),
      new Paragraph({
        spacing: { before: 120, after: 120 },
        children: [new TextRun({ text: "转化路径：", bold: true, color: "E74C3C" })]
      }),
      createPathTable(),

      // 第九步
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("第九步：将失败转化为本能")] 
      }),
      new Paragraph({
        spacing: { before: 120, after: 120 },
        children: [new TextRun("不因失败而恐惧逃避，在认清本质的基础上优化可控因素，开启新的成功循环")]
      }),
      createInputArea("我的行动承诺："),

      // 总结
      new Paragraph({ 
        heading: HeadingLevel.HEADING_1, 
        children: [new TextRun("复盘总结")] 
      }),
      createInputArea("核心发现："),
      createInputArea("下一步行动计划："),
      createInputArea("持续改进机制：")
    ]
  }]
});

// 辅助函数：创建信息表格
function createInfoTable() {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [2800, 6560],
    rows: [
      createInfoRow("复盘主题", "", cellBorders),
      createInfoRow("复盘日期", "", cellBorders),
      createInfoRow("复盘人", "", cellBorders),
      createInfoRow("失败事件简述", "", cellBorders)
    ]
  });
}

function createInfoRow(label, value, borders) {
  return new TableRow({
    children: [
      new TableCell({
        borders: borders,
        width: { size: 2800, type: WidthType.DXA },
        shading: { fill: "ECF0F1", type: ShadingType.CLEAR },
        children: [new Paragraph({ 
          children: [new TextRun({ text: label, bold: true })] 
        })]
      }),
      new TableCell({
        borders: borders,
        width: { size: 6560, type: WidthType.DXA },
        children: [new Paragraph({ children: [new TextRun(value)] })]
      })
    ]
  });
}

// 辅助函数：创建问题表格
function createQuestionTable() {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [2800, 6560],
    rows: [
      createInfoRow("目标是什么？", "", cellBorders),
      createInfoRow("结果是什么？", "", cellBorders),
      createInfoRow("我在失败中的核心角色是什么？", "", cellBorders)
    ]
  });
}

// 辅助函数：创建分析表格
function createAnalysisTable() {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [2800, 6560],
    rows: [
      createInfoRow("显性结果分析", "用规律量化结果，看是否符合规律预期", cellBorders),
      createInfoRow("隐性原因分析", "用规律分析内因", cellBorders),
      createInfoRow("规律层面的认知", "", cellBorders)
    ]
  });
}

// 辅助函数：创建系统表格
function createSystemTable() {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [2800, 6560],
    rows: [
      createInfoRow("可控因素", "准备不足、方法错误、执行变形、心态急躁、判断失误等", cellBorders),
      createInfoRow("不可控因素", "环境、时机、他人、规则等", cellBorders),
      createInfoRow("我的聚焦点", "只在可控方面下功夫", cellBorders)
    ]
  });
}

// 辅助函数：创建收获表格
function createGainTable() {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [2800, 6560],
    rows: [
      createInfoRow("显性表现", "目标未达成、损失、负面评价等", cellBorders),
      createInfoRow("试错价值", "", cellBorders),
      createInfoRow("看清自身短板", "", cellBorders),
      createInfoRow("认清他人", "", cellBorders),
      createInfoRow("经验免疫", "", cellBorders)
    ]
  });
}

// 辅助函数：创建四问表格
function createFourQuestionsTable() {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [2800, 6560],
    rows: [
      createInfoRow("问题1", "哪些内因不足导致结果塌陷？", cellBorders),
      createInfoRow("问题2", "哪些外因太强，超出承受？", cellBorders),
      createInfoRow("问题3", "哪些预期太高，与能力不匹配？", cellBorders),
      createInfoRow("问题4", "哪些环节发生了错位？", cellBorders)
    ]
  });
}

// 辅助函数：创建转化路径表格
function createPathTable() {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [2800, 6560],
    rows: [
      createInfoRow("从失到识", "看清边界", cellBorders),
      createInfoRow("从败到备", "准备充分", cellBorders),
      createInfoRow("从短到长", "补齐能力", cellBorders),
      createInfoRow("从弱到强", "锻炼心态", cellBorders)
    ]
  });
}

// 辅助函数：创建输入区域
function createInputArea(label) {
  const tableBorder = { style: BorderStyle.SINGLE, size: 1, color: "BDC3C7" };
  const cellBorders = { top: tableBorder, bottom: tableBorder, left: tableBorder, right: tableBorder };
  
  return new Table({
    columnWidths: [9360],
    rows: [
      new TableRow({
        children: [
          new TableCell({
            borders: cellBorders,
            width: { size: 9360, type: WidthType.DXA },
            children: [
              new Paragraph({ 
                spacing: { after: 60 },
                children: [new TextRun({ text: label, bold: true, color: "3498DB" })] 
              }),
              new Paragraph({ children: [new TextRun("")] }),
              new Paragraph({ children: [new TextRun("")] }),
              new Paragraph({ children: [new TextRun("")] })
            ]
          })
        ]
      })
    ]
  });
}

// 保存文档
Packer.toBuffer(doc).then(buffer => {
  fs.writeFileSync("E:\\阶跃星辰\\failure-review\\assets\\review_template.docx", buffer);
  console.log("复盘报告模板已创建！");
});
