---
name: sqlite-agent-database-pattern
description: "Agent 使用 SQLite 进行本地数据持久化的最佳实践"
version: 1.0.0
---

SQLite 是 Agent 本地数据持久化的最佳选择。本文档覆盖 schema 设计、WAL 并发模式和性能优化。

## 适用场景
- Agent 记忆存储（对话历史、用户偏好）
- 任务状态追踪（待办列表、执行结果）
- 配置管理（持久化设置）
- 缓存层（API 响应缓存）

## 核心配置

```python
import sqlite3

def get_connection(db_path="agent_data.db"):
    conn = sqlite3.connect(db_path)
    conn.execute("PRAGMA journal_mode=WAL")  # 并发读写
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute("PRAGMA cache_size=-64000")  # 64MB 缓存
    conn.execute("PRAGMA temp_store=MEMORY")
    conn.row_factory = sqlite3.Row
    return conn
```

## Schema 设计原则
1. 每张表必须有 `created_at` 和 `updated_at`
2. 使用 `deleted_at` 软删除
3. 灵活数据用 TEXT 存储 JSON
4. 高频查询字段建索引

```sql
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    category TEXT NOT NULL,
    content TEXT NOT NULL,
    metadata TEXT DEFAULT '{}',
    importance REAL DEFAULT 0.5,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now')),
    deleted_at TEXT
);
CREATE INDEX idx_memories_category ON memories(category);
CREATE INDEX idx_memories_importance ON memories(importance DESC);
```

## 并发处理
WAL 模式支持并发读、单写。线程安全：每个线程独立连接。跨进程需文件锁。

## 性能优化
- 批量写入 `executemany()`
- 定期 `VACUUM` 压缩
- `LIMIT` + `OFFSET` 分页
- 内存映射：`PRAGMA mmap_size=268435456`

## 备份
```bash
sqlite3 agent_data.db ".backup backup_$(date +%Y%m%d).db"
```

