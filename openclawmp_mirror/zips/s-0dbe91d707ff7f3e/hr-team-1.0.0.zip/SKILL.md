---
name: hr-team
description: HR team management
version: 1.0.0
---

# HR Team

HR team management skill.
