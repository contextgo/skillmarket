# 📰 新闻聚合简报生成器

自动抓取多源新闻，生成结构化的每日简报，支持中英文输出，可定时推送到飞书。

## 功能特性

- **多源聚合**：支持国内外多个权威新闻源
- **双语支持**：中文简报 + 英文原文存档
- **定时推送**：支持 cron 定时任务自动发送
- **结构化输出**：分类整理，热点聚焦
- **详情查询**：支持查看单条新闻的完整内容

## 支持的新闻源

### 🇨🇳 国内新闻
| 来源 | 类型 | 条数 |
|------|------|------|
| 新华网 | 官方通讯社 | 5 |
| 人民网 | 党报 | 3 |
| 央视网 | 国家电视台 | 3 |

### 🌍 国际新闻
| 来源 | 地区 | 条数 |
|------|------|------|
| BBC News | 🇬🇧 英国 | 8 |
| CNN | 🇺🇸 美国 | 8 |
| Reuters | 🇬🇧 英国 | 6 |
| The Guardian | 🇬🇧 英国 | 5 |

## 使用方法

### 1. 手动生成简报

```javascript
const { generateDailyBriefing } = require('./news_briefing_bilingual');

// 生成简报
const briefing = generateDailyBriefing();
console.log(briefing.chinese);  // 中文版
console.log(briefing.english);  // 英文版
```

### 2. 定时自动推送（Cron）

配置每天 12:00 自动发送：

```bash
# 添加定时任务
openclaw cron add \
  --name daily-news-briefing \
  --schedule "0 12 * * *" \
  --message "执行每日新闻简报任务"
```

### 3. 查看新闻详情

回复格式：`[来源] news [编号]`

示例：
- `BBC news 1` - 查看 BBC 第1条新闻详情
- `CNN news 5` - 查看 CNN 第5条新闻详情

## 输出格式

### 简报结构

```
📰 每日新闻简报
📅 2026年3月9日

## 🇨🇳 国内要闻
[来源]
1. 新闻标题
   摘要

## 🌍 国际要闻
[来源]
1. 英文标题 (保持原文)

## 🔥 热点聚焦
- 关键事件1
- 关键事件2
```

### 存档文件

| 文件 | 用途 |
|------|------|
| `daily_briefing_YYYY-MM-DD_zh.txt` | 中文版 |
| `daily_briefing_YYYY-MM-DD_en.txt` | 英文版 |
| `daily_briefing_YYYY-MM-DD.json` | 原始数据 |

## 配置说明

在 `news_briefing_bilingual.js` 中修改：

```javascript
const CONFIG = {
  sources: {
    domestic: [
      { key: 'xinhua', name: '新华网', nameEn: 'Xinhua' },
      // 添加更多国内源...
    ],
    international: [
      { key: 'bbc', name: 'BBC News', nameEn: 'BBC News' },
      // 添加更多国际源...
    ]
  },
  itemsPerSource: 8,  // 每源条数
  languages: ['zh', 'en']
};
```

## 依赖

- Node.js >= 16
- `kimi_fetch` 或 `web_fetch` 工具（用于获取网页内容）

## 工作流程

```
定时触发 / 手动执行
    ↓
抓取各新闻源 → 解析标题
    ↓
生成结构化简报
    ↓
保存本地文件
    ↓
推送到飞书（如配置）
```

## 使用场景

1. **个人日常阅读**：每天早上/中午自动接收新闻简报
2. **团队信息共享**：推送到飞书群组，全员同步
3. **资讯监控**：跟踪特定话题的发展
4. **多语言学习**：中英文对照阅读

## 注意事项

- 国际新闻标题保持英文原文，便于需要时查看英文详情
- 国内新闻使用中文原文
- 简报生成后保存本地，支持历史查询
- 新闻源 URL 可能变更，需定期更新

## 扩展建议

- 添加更多国内源：财新、澎湃新闻等
- 增加关键词过滤功能
- 支持 RSS 订阅源
- 添加 AI 摘要生成功能