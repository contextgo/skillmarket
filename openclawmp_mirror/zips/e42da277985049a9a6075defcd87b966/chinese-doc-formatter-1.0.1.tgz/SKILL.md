---
name: chinese-doc-formatter
name_en: chinese-doc-formatter
displayName: 【爆款】中文文档一键格式化 | 标点/缩进/标题全搞定
version: 1.0.1
description: "写完文档还在手动调格式？标点乱飞、标题混乱、段落缩进不一？这款工具专治文档格式混乱！政府公文/工作邮件/报告方案，一键自动规范化。告别手动排版，省时省力！"
description_en: "Format Chinese documents with AI - government documents, emails, reports, proposals. One-click standardization! Automatically handles punctuation, heading levels, paragraph indents, and list formatting. Essential tool for Chinese document writing."
type: skill
tags:
  - chinese
  - document
  - formatter
  - writing
  - automation
  - productivity
  - 中文
  - 文档格式化
  - 公文
  - 写作
  - 文案
  - 排版
  - 格式化
  - 标点
  - office
  - 办公
  - 文档规范
  - 国标格式
author: ruiyongwang
author_en: ruiyongwang
license: MIT
category: productivity
category_en: Productivity
---

# 中文文档格式化助手

## 🔥 痛点场景

- ❌ 写完报告发现标点全是英文的，被领导批评"不专业"
- ❌ 标题层级混乱，一会"一、"一会"1.1"，格式不统一
- ❌ 段落缩进参差不齐，看起来乱七八糟
- ❌ 公文格式要求严格，自己调半天还是不符合国标

## 💡 一句话介绍

输入任意中文文档（政府公文、邮件、报告、方案），自动完成：
- 标点符号规范化（全角/半角）
- 标题层级自动编号（一、二、三 / 1.1.1）
- 段落缩进统一
- 列表格式标准化
- 敏感词检测与替换建议

---

## 核心功能

### 1. 标点规范化

**处理规则：**
- 英文标点 → 中文标点（,. → ，。）
- 连续空格 → 单空格
- 行首行尾空格 → 去除
- 引号规范化（"" → ""）

**示例：**
```
输入：这是"测试"文档,包含,多个问题。
输出：这是"测试"文档，包含多个问题。
```

### 2. 标题层级编号

**自动识别标题并添加层级编号：**
```
输入：
标题一：概述
标题二：详细内容
标题三：细节说明

输出：
一、概述
（一）详细内容
1.1.1 细节说明
```

### 3. 文档结构检查

**自动检测：**
- 标题层级是否混乱
- 列表格式是否统一
- 段落长度是否过长
- 是否有缺失的结束语

---

## 使用方式

```
> 帮我格式化这份文档：[粘贴文档内容]

> 这份报告需要规范化处理

> 检查一下这份公文的格式问题
```

---

## 适用场景

| 场景 | 说明 |
|------|------|
| 政府公文 | 符合GB/T 9704-2012格式要求 |
| 工作邮件 | 专业得体的商务邮件格式 |
| 项目报告 | 规范的结构化报告格式 |
| 招标方案 | 专业的商务文档格式 |
| 学术论文 | 符合学校要求的论文格式 |

---

## 格式化标准参考

- GB/T 9704-2012《党政机关公文格式》
- 中文排版规范（标点、字距、行距）
- 商务文书写作规范

---

## 注意事项

1. **保留原文意思**：格式化不会改变文档内容
2. **敏感词检测**：自动标记可能的不当用词
3. **格式预览**：处理前显示修改预览
4. **选择性应用**：用户可选择接受或拒绝某些修改

---

**让你的中文文档从此告别格式混乱！**