# 喜马拉雅邮件CLI

喜马拉雅是一个CLI邮件客户端，允许您使用终端通过IMAP、SMTP、Notmuch或Sendmail后端管理邮件。

## 参考资料

- `references/configuration.md`（配置文件设置 + IMAP/SMTP认证）
- `references/message-composition.md`（用于撰写邮件的MML语法）

## 先决条件

1. 已安装Himalaya CLI（使用`himalaya --version`验证）
2. 在`~/.config/himalaya/config.toml`位置的配置文件
3. 已配置IMAP/SMTP凭据（密码安全存储）

## 配置设置

运行交互式向导来设置账户：
```bash
himalaya account configure
```

或手动创建`~/.config/himalaya/config.toml`：
```toml
[accounts.personal]
email = "you@example.com"
display-name = "Your Name"
default = true

backend.type = "imap"
backend.host = "imap.example.com"
backend.port = 993
backend.encryption.type = "tls"
backend.login = "you@example.com"
backend.auth.type = "password"
backend.auth.cmd = "pass show email/imap"  # or use keyring

message.send.backend.type = "smtp"
message.send.backend.host = "smtp.example.com"
message.send.backend.port = 587
message.send.backend.encryption.type = "start-tls"
message.send.backend.login = "you@example.com"
message.send.backend.auth.type = "password"
message.send.backend.auth.cmd = "pass show email/smtp"
```

## 常用操作

### 列出文件夹

```bash
himalaya folder list
```

### 列出邮件

列出INBOX中的邮件（默认）：
```bash
himalaya envelope list
```

列出特定文件夹中的邮件：
```bash
himalaya envelope list --folder "Sent"
```

分页列出：
```bash
himalaya envelope list --page 1 --page-size 20
```

### 搜索邮件

```bash
himalaya envelope list from john@example.com subject meeting
```

### 阅读邮件

通过ID阅读邮件（显示纯文本）：
```bash
himalaya message read 42
```

导出原始MIME：
```bash
himalaya message export 42 --full
```

### 回复邮件

交互式回复（打开$EDITOR）：
```bash
himalaya message reply 42
```

回复所有人：
```bash
himalaya message reply 42 --all
```

### 转发邮件

```bash
himalaya message forward 42
```

### 撰写新邮件

交互式撰写（打开$EDITOR）：
```bash
himalaya message write
```

直接使用模板发送：
```bash
cat << 'EOF' | himalaya template send
From: you@example.com
To: recipient@example.com
Subject: Test Message

Hello from Himalaya!
EOF
```

或使用headers标志：
```bash
himalaya message write -H "To:recipient@example.com" -H "Subject:Test" "Message body here"
```

### 移动/复制邮件

移动到文件夹：
```bash
himalaya message move 42 "Archive"
```

复制到文件夹：
```bash
himalaya message copy 42 "Important"
```

### 删除邮件

```bash
himalaya message delete 42
```

### 管理标志

添加标志：
```bash
himalaya flag add 42 --flag seen
```

移除标志：
```bash
himalaya flag remove 42 --flag seen
```

## 多账户

列出账户：
```bash
himalaya account list
```

使用特定账户：
```bash
himalaya --account work envelope list
```

## 附件

从消息中保存附件：
```bash
himalaya attachment download 42
```

保存到特定目录：
```bash
himalaya attachment download 42 --dir ~/Downloads
```

## 输出格式

大多数命令支持 `--output` 进行结构化输出：
```bash
himalaya envelope list --output json
himalaya envelope list --output plain
```

## 调试

启用调试日志：
```bash
RUST_LOG=debug himalaya envelope list
```

完整跟踪与回溯：
```bash
RUST_LOG=trace RUST_BACKTRACE=1 himalaya envelope list
```

## 提示

- 使用 `himalaya --help` 或 `himalaya <command> --help` 获取详细使用说明。
- 消息ID相对于当前文件夹；文件夹更改后需要重新列出。
- 要编写带附件的丰富电子邮件，请使用MML语法（参见 `references/message-composition.md`）。
- 使用 `pass`、系统密钥环或输出密码的命令安全存储密码。