---
name: excel-batch-processor
description: Batch process Excel files (.xlsx, .xls, .csv) for data cleaning, multi-file merging, statistical summarization, and format conversion. Use when: (1) cleaning dirty Excel data (duplicates, missing values, inconsistent formats), (2) merging multiple Excel files or sheets into one, (3) generating summary statistics or pivot reports across files, (4) converting Excel to CSV/JSON/Markdown in bulk, (5) processing a folder of Excel files with the same operation. NOT for: creating new Excel reports from scratch, single-row edits, or complex data analysis requiring domain-specific logic.
---

# Excel Batch Processor

## Quick Reference

```bash
# Run the batch processor
python3 <skill_dir>/scripts/excel_batch.py <input_path> -o <output_dir> --op <operation>
```

## Operations (`--op`)

| Operation | Description |
|-----------|-------------|
| `clean` | Remove duplicates, fill missing values, trim strings, normalize dates |
| `merge` | Combine multiple files/sheets into one (concat or key-based join) |
| `stats` | Generate descriptive statistics, group-by summaries, pivot reports |
| `convert` | Batch convert Excel ↔ CSV ↔ JSON ↔ Markdown |
| `report` | Generate a summary report of all files in a directory |

## Required Input

- **Input path**: single file, sheet, or directory (auto-recurses)
- **Output directory**: use `-o` flag; defaults to `<input>_output` if not specified
- **Operation**: required via `--op`

## Optional Flags

| Flag | Default | Description |
|------|---------|-------------|
| `--op` | (required) | Operation type (clean/merge/stats/convert/report) |
| `-o` | auto | Output directory |
| `--format` | csv | Output format for convert ops (csv/json/markdown) |
| `--key` | none | Column name for merge (join key) |
| `--group-by` | none | Column(s) for group-by in stats |
| `--fill-strategy` | mean | Missing value strategy (mean/median/mode/forward/drop) |
| `--encoding` | utf-8 | File encoding for CSV/JSON |
| `--verbose` | false | Print detailed processing log |

## Common Workflows

### Clean dirty data in a folder
```bash
python3 <skill_dir>/scripts/excel_batch.py ./reports/ -o ./cleaned/ --op clean --verbose
```

### Merge multiple monthly reports by key
```bash
python3 <skill_dir>/scripts/excel_batch.py ./monthly/ -o ./merged/ --op merge --key "订单号"
```

### Generate stats report grouped by category
```bash
python3 <skill_dir>/scripts/excel_batch.py ./data/ -o ./stats/ --op stats --group-by "部门"
```

### Convert all Excel to CSV
```bash
python3 <skill_dir>/scripts/excel_batch.py ./data/ -o ./csv_output/ --op convert --format csv
```

## Output Format

All operations produce:
1. **Processed files** in output directory (suffixed with `_processed`, `_merged`, etc.)
2. **`summary.json`** — per-file operation results, row counts, warnings
3. **`report.md`** — human-readable summary (for `report` and `stats` ops)

## Notes

- Requires `pandas` and `openpyxl` Python packages
- Handles `.xlsx`, `.xls`, `.csv` files automatically
- Auto-detects sheet names; processes first sheet if not specified
- Large files (>10MB) are processed in chunks with progress logging
- Chinese column names and values fully supported
