# Excel 批量处理器

一个面向 Agent 的 Excel 批量处理技能，支持数据清洗、多文件合并、统计汇总、格式转换和目录报告五种操作。

## 能做什么

**数据清洗** — 自动去重、填充缺失值、清理前后空格、标准化日期格式。适合处理从各种来源导出的脏数据。

**多文件合并** — 把同一目录下多个 Excel 文件或 sheet 纵向拼接成一个，支持按指定列做 key-based join。

**统计汇总** — 对数值列自动计算描述性统计，支持按指定列做分组聚合，输出 Markdown 报告 + JSON 汇总。

**格式转换** — 批量将 Excel 转为 CSV / JSON / Markdown 表格，或反向转换。

**目录报告** — 扫描整个目录，生成每个文件的结构报告（行数、列数、列名、数据类型），快速了解数据全貌。

## 适用场景

- 每天收到多个格式相同的报表，需要合并处理
- 从系统导出的数据有缺失值和重复行，需要清洗后再分析
- 拿到一批 Excel 文件但不清楚内容，想先看看整体情况
- 需要把 Excel 批量转成 CSV 给其他系统使用
- 按部门、地区等维度做分组统计，快速出报告

## 典型用法

```bash
# 清洗一个目录下的所有 Excel 文件
python3 <skill_path>/scripts/excel_batch.py ./data/ -o ./cleaned/ --op clean --verbose

# 合并多个月度报表
python3 <skill_path>/scripts/excel_batch.py ./monthly/ -o ./merged/ --op merge --key "订单号"

# 按部门生成分组统计
python3 <skill_path>/scripts/excel_batch.py ./data/ -o ./stats/ --op stats --group-by "部门"

# 全部转 CSV
python3 <skill_path>/scripts/excel_batch.py ./data/ -o ./csv/ --op convert --format csv

# 生成目录结构报告
python3 <skill_path>/scripts/excel_batch.py ./reports/ -o ./report/ --op report --verbose
```

## 环境要求

- Python 3.8+
- `pandas`, `numpy`, `openpyxl`, `tabulate`

## 处理边界

- 支持 `.xlsx` / `.xls` / `.csv` 格式自动识别
- 中文列名和中文值完全支持
- 单文件 > 10MB 自动分块处理并输出进度日志
- 不修改原始文件，所有输出写入指定目录
- 每次操作自动生成 `summary.json` 和可选的 `report.md`
