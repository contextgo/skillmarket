#!/usr/bin/env python3
"""
excel_batch.py — Batch Excel file processor

Operations: clean, merge, stats, convert, report
Usage:
    python3 excel_batch.py <input_path> -o <output_dir> --op <operation> [flags]
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

try:
    import pandas as pd
    import numpy as np
except ImportError:
    print("错误: 需要 pandas 和 numpy，请运行: pip3 install pandas openpyxl numpy")
    sys.exit(1)

try:
    import openpyxl
except ImportError:
    print("警告: openpyxl 未安装，.xlsx 文件可能无法正常读写")


# ─── Helpers ──────────────────────────────────────────────────────────────

def find_excel_files(path: str) -> list[str]:
    """递归查找所有 Excel/CSV 文件"""
    p = Path(path)
    if p.is_file():
        return [str(p)]
    patterns = ["*.xlsx", "*.xls", "*.csv"]
    files = []
    for pat in patterns:
        files.extend(str(f) for f in p.rglob(pat))
    return sorted(set(files))


def read_sheet(filepath: str, sheet_name=None) -> dict:
    """读取 Excel/CSV 文件，返回 {sheet_name: DataFrame}"""
    ext = Path(filepath).suffix.lower()
    if ext == ".csv":
        name = Path(filepath).stem
        try:
            df = pd.read_csv(filepath)
        except Exception:
            df = pd.read_csv(filepath, encoding="gbk")
        return {name: df}

    sheets = {}
    xls = pd.ExcelFile(filepath, engine="openpyxl" if ext == ".xlsx" else None)
    sheet_names = [sheet_name] if sheet_name else xls.sheet_names
    for sn in sheet_names:
        if sn in xls.sheet_names:
            sheets[sn] = pd.read_excel(xls, sheet_name=sn)
    return sheets


def write_output(df: pd.DataFrame, filepath: str, fmt: str = None):
    """写入输出文件"""
    fmt = fmt or Path(filepath).suffix.lower().lstrip(".")
    out_path = str(filepath)

    if fmt in ("csv",):
        df.to_csv(out_path, index=False, encoding="utf-8-sig")
    elif fmt in ("xlsx",):
        df.to_excel(out_path, index=False, engine="openpyxl")
    elif fmt in ("json",):
        df.to_json(out_path, orient="records", force_ascii=False, indent=2)
    elif fmt in ("md", "markdown"):
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(df.to_markdown(index=False))
    else:
        df.to_excel(out_path, index=False, engine="openpyxl")


def safe_filename(filepath: str, suffix: str = "_processed") -> str:
    """生成带后缀的输出文件名"""
    p = Path(filepath)
    return str(p.parent / f"{p.stem}{suffix}{p.suffix}")


# ─── Operations ───────────────────────────────────────────────────────────

def op_clean(files: list[str], output_dir: str, verbose: bool = False,
             fill_strategy: str = "mean") -> dict:
    """数据清洗：去重、填缺失值、格式化字符串、标准化日期"""
    results = {}
    os.makedirs(output_dir, exist_ok=True)

    for f in files:
        file_results = {}
        sheets = read_sheet(f)
        out_path = safe_filename(f, "_cleaned")

        for sheet_name, df in sheets.items():
            before_rows = len(df)
            ops_log = []

            # 1. 去除全空列
            empty_cols = df.columns[df.isnull().all()].tolist()
            if empty_cols:
                df = df.drop(columns=empty_cols)
                ops_log.append(f"删除全空列 {len(empty_cols)} 个")

            # 2. 去除完全重复行
            dup_count = df.duplicated().sum()
            if dup_count > 0:
                df = df.drop_duplicates()
                ops_log.append(f"去重 {dup_count} 行")

            # 3. 字符串列：去除首尾空格
            str_cols = df.select_dtypes(include=["object"]).columns
            for col in str_cols:
                if df[col].dtype == "object":
                    before_na = df[col].isnull().sum()
                    df[col] = df[col].apply(
                        lambda x: x.strip() if isinstance(x, str) else x
                    )
                    ops_log.append(f"清理列 '{col}' 前后空格")

            # 4. 缺失值填充
            num_cols = df.select_dtypes(include=[np.number]).columns
            non_num_cols = df.select_dtypes(exclude=[np.number]).columns

            if fill_strategy == "drop":
                before_count = len(df)
                df = df.dropna()
                ops_log.append(f"删除缺失值，剩余 {len(df)} 行")
            else:
                for col in num_cols:
                    if df[col].isnull().any():
                        na_count = df[col].isnull().sum()
                        if fill_strategy == "mean":
                            val = df[col].mean()
                        elif fill_strategy == "median":
                            val = df[col].median()
                        else:
                            val = df[col].mode().iloc[0] if not df[col].mode().empty else 0
                        df[col] = df[col].fillna(val)
                        ops_log.append(f"列 '{col}' 填充 {na_count} 个缺失值({fill_strategy})")

                for col in non_num_cols:
                    if df[col].isnull().any() and df[col].dtype == "object":
                        na_count = df[col].isnull().sum()
                        mode_val = df[col].mode()
                        val = mode_val.iloc[0] if not mode_val.empty else "未知"
                        df[col] = df[col].fillna(val)
                        ops_log.append(f"列 '{col}' 填充 {na_count} 个缺失值(mode)")

            # 5. 日期列标准化
            for col in df.columns:
                if df[col].dtype == "object":
                    sample = df[col].dropna().head(10)
                    if sample.apply(lambda x: isinstance(x, str) and len(x) >= 6).all() and len(sample) > 0:
                        try:
                            converted = pd.to_datetime(sample, errors="coerce")
                            if converted.notna().sum() / len(converted) > 0.5:
                                df[col] = pd.to_datetime(df[col], errors="coerce")
                                ops_log.append(f"列 '{col}' 转换为日期格式")
                        except Exception:
                            pass

            after_rows = len(df)
            summary = f"清洗完成: {before_rows} → {after_rows} 行"
            if verbose:
                for msg in ops_log:
                    print(f"  [{Path(f).name}/{sheet_name}] {msg}")
                print(f"  [{Path(f).name}/{sheet_name}] {summary}")

            file_results[sheet_name] = {
                "rows_before": before_rows,
                "rows_after": after_rows,
                "columns": list(df.columns),
                "operations": ops_log,
            }

            # 写入输出
            ext = Path(f).suffix.lower()
            if ext == ".csv":
                write_output(df, safe_filename(f, "_cleaned").replace(ext, ".csv"), "csv")
            else:
                write_output(df, safe_filename(f, "_cleaned").replace(ext, ".xlsx"), "xlsx")

        results[f] = file_results

    return results


def op_merge(files: list[str], output_dir: str, key: str = None,
             verbose: bool = False) -> dict:
    """合并多个文件/sheet"""
    os.makedirs(output_dir, exist_ok=True)
    all_dfs = []
    results = {"files": [], "total_rows": 0, "total_cols": 0}

    for f in files:
        sheets = read_sheet(f)
        for sheet_name, df in sheets.items():
            df["_source_file"] = Path(f).name
            df["_source_sheet"] = sheet_name
            all_dfs.append(df)
            results["files"].append(f"{Path(f).name}/{sheet_name}: {len(df)} 行")

    if not all_dfs:
        print("错误: 没有找到可合并的数据")
        return results

    if key and key in all_dfs[0].columns:
        # 基于 key 合并（reduce merge）
        merged = all_dfs[0]
        for df in all_dfs[1:]:
            if key in df.columns:
                merged = pd.merge(merged, df, on=key, how="outer", suffixes=("", "_dup"))
    else:
        # 纵向拼接
        merged = pd.concat(all_dfs, ignore_index=True)

    results["total_rows"] = len(merged)
    results["total_cols"] = len(merged.columns)
    results["columns"] = list(merged.columns)

    out_file = os.path.join(output_dir, "merged.xlsx")
    write_output(merged, out_file, "xlsx")
    if verbose:
        print(f"合并完成: {len(all_dfs)} 个sheet → {len(merged)} 行, {len(merged.columns)} 列 → {out_file}")

    return results


def op_stats(files: list[str], output_dir: str, group_by: str = None,
             verbose: bool = False) -> dict:
    """统计分析：描述性统计 + 分组汇总"""
    os.makedirs(output_dir, exist_ok=True)
    report_lines = ["# 数据统计报告\n", f"生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"]
    results = {}

    for f in files:
        sheets = read_sheet(f)
        file_results = {}

        for sheet_name, df in sheets.items():
            section = [f"## {Path(f).name} / {sheet_name}\n"]

            # 描述性统计
            num_df = df.select_dtypes(include=[np.number])
            if not num_df.empty:
                section.append("### 数值列统计\n")
                desc = num_df.describe()
                section.append(desc.to_markdown())
                section.append("")

            # 分组统计
            if group_by and group_by in df.columns:
                section.append(f"### 按 '{group_by}' 分组\n")
                if not num_df.empty:
                    grouped = df.groupby(group_by).agg(
                        计数=(group_by, "count"),
                        **{col: ("mean") for col in num_df.columns[:5]}
                    )
                    section.append(grouped.to_markdown())
                else:
                    vc = df[group_by].value_counts().head(20)
                    section.append(vc.to_markdown())
                section.append("")

            file_results[sheet_name] = {
                "total_rows": len(df),
                "total_cols": len(df.columns),
                "numeric_cols": list(num_df.columns),
                "categorical_cols": list(df.select_dtypes(exclude=[np.number]).columns),
            }

            report_lines.extend(section)

        results[f] = file_results

    # 写入报告
    report_path = os.path.join(output_dir, "report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))

    # 写入 JSON 汇总
    json_path = os.path.join(output_dir, "summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)

    if verbose:
        print(f"统计报告: {report_path}")
        print(f"JSON 汇总: {json_path}")

    return results


def op_convert(files: list[str], output_dir: str, fmt: str = "csv",
               verbose: bool = False) -> dict:
    """格式转换：Excel ↔ CSV ↔ JSON ↔ Markdown"""
    os.makedirs(output_dir, exist_ok=True)
    results = {"converted": []}

    for f in files:
        sheets = read_sheet(f)
        for sheet_name, df in sheets.items():
            base = Path(f).stem
            if len(sheets) > 1:
                out_name = f"{base}_{sheet_name}.{fmt}"
            else:
                out_name = f"{base}.{fmt}"
            out_path = os.path.join(output_dir, out_name)

            write_output(df, out_path, fmt)
            results["converted"].append({
                "source": f"{Path(f).name}/{sheet_name}",
                "output": out_name,
                "rows": len(df),
                "cols": len(df.columns),
            })
            if verbose:
                print(f"  {Path(f).name}/{sheet_name} → {out_name} ({len(df)} 行)")

    return results


def op_report(files: list[str], output_dir: str, verbose: bool = False) -> dict:
    """生成目录内所有文件的摘要报告"""
    os.makedirs(output_dir, exist_ok=True)
    results = {"files": []}
    report_lines = [
        "# Excel 文件目录报告\n",
        f"扫描时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n",
        f"文件总数: {len(files)}\n",
    ]

    total_rows = 0
    total_sheets = 0

    for f in files:
        try:
            sheets = read_sheet(f)
            file_info = {"file": Path(f).name, "sheets": []}
            report_lines.append(f"\n## {Path(f).name}\n")

            for sn, df in sheets.items():
                info = {
                    "sheet": sn,
                    "rows": len(df),
                    "cols": len(df.columns),
                    "columns": list(df.columns),
                    "dtypes": {str(k): str(v) for k, v in df.dtypes.items()},
                }
                file_info["sheets"].append(info)
                total_rows += len(df)
                total_sheets += 1

                report_lines.append(f"### Sheet: {sn}")
                report_lines.append(f"- 行数: {len(df)}")
                report_lines.append(f"- 列数: {len(df.columns)}")
                report_lines.append(f"- 列: {', '.join(df.columns)}")
                report_lines.append("")
        except Exception as e:
            file_info = {"file": Path(f).name, "error": str(e)}
            report_lines.append(f"\n## {Path(f).name} — 读取失败: {e}\n")

        results["files"].append(file_info)

    report_lines.insert(2, f"Sheet 总数: {total_sheets}\n")
    report_lines.insert(3, f"总数据行数: {total_rows}\n")

    # 写入
    report_path = os.path.join(output_dir, "directory_report.md")
    with open(report_path, "w", encoding="utf-8") as f:
        f.write("\n".join(report_lines))

    summary_path = os.path.join(output_dir, "summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2, default=str)

    if verbose:
        print(f"目录报告: {report_path}")
        print(f"共 {len(files)} 个文件, {total_sheets} 个sheet, {total_rows} 行数据")

    return results


# ─── Main ─────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="批量处理 Excel 文件")
    parser.add_argument("input", help="输入路径（文件或目录）")
    parser.add_argument("-o", "--output", default=None, help="输出目录")
    parser.add_argument("--op", required=True, choices=["clean", "merge", "stats", "convert", "report"],
                        help="操作类型")
    parser.add_argument("--format", default="csv", help="转换格式 (csv/json/markdown)")
    parser.add_argument("--key", default=None, help="合并键列名")
    parser.add_argument("--group-by", default=None, help="分组列名")
    parser.add_argument("--fill-strategy", default="mean",
                        choices=["mean", "median", "mode", "forward", "drop"],
                        help="缺失值填充策略")
    parser.add_argument("--encoding", default="utf-8", help="文件编码")
    parser.add_argument("--verbose", action="store_true", help="详细输出")

    args = parser.parse_args()

    # 查找文件
    files = find_excel_files(args.input)
    if not files:
        print(f"错误: 在 '{args.input}' 中未找到 Excel/CSV 文件")
        sys.exit(1)

    if args.verbose:
        print(f"找到 {len(files)} 个文件:")
        for f in files:
            print(f"  - {f}")
        print()

    # 输出目录
    output_dir = args.output or os.path.join(os.path.dirname(args.input) or ".", f"{args.op}_output")

    # 执行操作
    ops = {
        "clean": lambda: op_clean(files, output_dir, args.verbose, args.fill_strategy),
        "merge": lambda: op_merge(files, output_dir, args.key, args.verbose),
        "stats": lambda: op_stats(files, output_dir, args.group_by, args.verbose),
        "convert": lambda: op_convert(files, output_dir, args.format, args.verbose),
        "report": lambda: op_report(files, output_dir, args.verbose),
    }

    result = ops[args.op]()

    # 写入 summary.json
    summary_path = os.path.join(output_dir, "summary.json")
    with open(summary_path, "w", encoding="utf-8") as f:
        json.dump({"operation": args.op, "timestamp": datetime.now().isoformat(), "results": result},
                   f, ensure_ascii=False, indent=2, default=str)

    print(f"\n✅ 操作完成: {args.op}")
    print(f"📁 输出目录: {output_dir}")
    print(f"📊 摘要: {summary_path}")


if __name__ == "__main__":
    main()
