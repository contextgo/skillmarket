#!/bin/bash
# 即梦AI图片下载脚本

# 用法: ./download.sh <image_url> <output_name>
# 示例: ./download.sh "https://..." lobster1

URL=$1
NAME=$2

if [ -z "$URL" ] || [ -z "$NAME" ]; then
    echo "用法: $0 <image_url> <output_name>"
    exit 1
fi

# 下载webp图片
echo "下载图片..."
curl -s "$URL" -o /tmp/${NAME}.webp

if [ $? -ne 0 ]; then
    echo "下载失败"
    exit 1
fi

# 转换为jpg
echo "转换为JPG..."
python3 -c "
from PIL import Image
img = Image.open('/tmp/${NAME}.webp')
rgb = img.convert('RGB')
rgb.save('/tmp/${NAME}.jpg', 'JPEG')
"

# 复制到上传目录
cp /tmp/${NAME}.jpg /tmp/openclaw/uploads/

echo "完成！图片保存在: /tmp/openclaw/uploads/${NAME}.jpg"
