# 即梦生图 (jimeng-image)

使用即梦AI（jimeng.jianying.com）生成图片的完整工作流。

## 能力概览
- ✅ 浏览器自动化生成图片（通过 browser 工具）
- ✅ Cookie 过期检测 + 提示更新
- ✅ 图片下载 + WebP→JPG 转换
- ✅ 主动推送图片到飞书

## 使用流程（Agent 标准调用方式）

### Step 0: 检查 Cookie 是否有效
```bash
node ~/.agents/skills/jimeng-image/scripts/check_cookie.mjs
```
- 返回 `0` = 有效
- 返回 `1` + 提示 = 已过期，需要用户更新 cookie

**Cookie 过期更新方式：**
1. 浏览器登录 jimeng.jianying.com
2. F12 → Application → Cookies → 复制完整 cookie 值
3. 更新到 `config/jimeng.conf` 的 `JIMENG_COOKIE`

### Step 1: 生成图片（浏览器自动化）

**浏览器操作流程：**
1. 打开：`https://jimeng.jianying.com/ai-tool/generate/?type=image&workspace=0`
2. 等待页面加载完成（约3-4秒）
3. 点击输入框（contenteditable 的 tiptap 元素）
4. 输入提示词（使用 `document.execCommand('insertText', false, '提示词')` 或直接设置 textContent）
5. 找到并点击提交按钮（class 包含 `submit-button` 的 button）
6. 等待 35-40 秒生成完成

**提交按钮 XPath 或 class：** `.submit-button-s4a7XV` 或 `.submit-button-xdhu0e`

**输入框查找方式：**
```javascript
// 方法1：找 tiptap 编辑器
const textbox = document.querySelector('.tiptap.ProseMirror, [contenteditable="true"]');
if (textbox) {
  textbox.innerHTML = '';
  textbox.textContent = '你的提示词';
  textbox.dispatchEvent(new Event('input', { bubbles: true }));
}

// 方法2：用 evaluate 点击后输入
document.execCommand('insertText', false, '你的提示词');
```

**提交按钮点击：**
```javascript
const btn = document.querySelector('.submit-button-s4a7XV, .lv-btn-primary');
if (btn && !btn.disabled) btn.click();
```

### Step 2: 提取图片 URL

生成完成后，从页面 DOM 提取图片 URL：
```javascript
const urls = [];
document.querySelectorAll('img').forEach(img => {
  if (img.src && img.src.includes('dreamina') && img.naturalWidth > 300) {
    urls.push(img.src);
  }
});
return urls.slice(0, 3); // 返回最多3张
```

### Step 3: 下载图片

```bash
node ~/.agents/skills/jimeng-image/scripts/download.mjs "<image_url>" "<输出名>" [输出目录]
```

**示例：**
```bash
node ~/.agents/skills/jimeng-image/scripts/download.mjs \
  "https://p3-dreamina-sign.byteimg.com/xxx.webp?lk3s=xxx" \
  "saturn_lobster_1" \
  "/tmp/openclaw"
```

**输出：** `/tmp/openclaw/saturn_lobster_1.jpg`

### Step 4: 推送图片到飞书

使用 `message` 工具发送图片：
```javascript
message({
  action: 'send',
  channel: 'feishu',
  target: 'user:ou_xxxxxxxx', // 用户的 open_id
  media: '/tmp/openclaw/saturn_lobster_1.jpg'
})
```

## 完整调用示例

```javascript
// 1. 检查 cookie
const { execSync } = require('child_process');
const cookieCheck = execSync('node ~/.agents/skills/jimeng-image/scripts/check_cookie.mjs').toString();
// 如果包含 "过期" → 提示用户更新 cookie

// 2. 浏览器生成（使用 browser 工具）
// - navigate to jimeng
// - evaluate: 输入提示词
// - evaluate: 点击生成按钮
// - wait 40s
// - evaluate: 提取图片 URLs

// 3. 下载
execSync('node ~/.agents/skills/jimeng-image/scripts/download.mjs "<url>" "output_name" "/tmp/openclaw"');

// 4. 推送
message({ action: 'send', channel: 'feishu', target: 'user:ou_xxx', media: '/tmp/openclaw/output_name.jpg' });
```

## 提示词模板

天文科普类：
- `"一只可爱的小龙虾站在土星环上仰望星空，动漫风格，宇宙深空背景"`
- `"哈勃望远镜观测到的蟹状星云，真实天文照片风格，星空璀璨"`

治愈插画类：
- `"一只小龙虾在海边看日落，动漫风格，温暖色调，治愈系"`
- `"深圳夜空，流星划过天文台，梦幻插画风格"`

## ⚠️ 安全警告
- **Cookie 存储在 `config/jimeng.conf`，包含账号凭据，严禁提交到公开仓库！**
- 本 skill 依赖本地配置文件，不含真实 cookie
- 安装后用户需要自行填入自己的 cookie
- 下载的图片保存在 `/tmp/openclaw/uploads/`

## 目录结构
```
jimeng-image/
├── config/
│   ├── jimeng.conf      # Cookie 和默认参数
│   └── settings.yaml    # 设置
├── scripts/
│   ├── generate.mjs    # ⚠️ 预留（浏览器控制待实现）
│   ├── check_cookie.mjs # ✅ Cookie 验证
│   └── download.mjs      # ✅ 图片下载+转换
└── SKILL.md
```

## 依赖
- Node.js (mjs 脚本)
- Python3 + Pillow（图片转换）
- curl
- openclaw browser 工具（浏览器自动化）