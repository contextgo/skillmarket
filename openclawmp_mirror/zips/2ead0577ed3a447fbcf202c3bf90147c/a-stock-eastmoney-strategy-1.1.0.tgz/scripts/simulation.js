#!/usr/bin/env node
/**
 * 东财妙想模拟交易对接模块
 * 提供选股、模拟交易、回测等功能
 */

const fs = require('fs');
const path = require('path');

// 配置文件路径
const CONFIG_PATH = process.env.USERPROFILE
  ? path.join(process.env.USERPROFILE, '.stepclaw', 'dongcai-sim-config.json')
  : path.join(process.env.HOME, '.stepclaw', 'dongcai-sim-config.json');

// 交易记录路径
const TRADE_RECORD_PATH = process.env.USERPROFILE
  ? path.join(process.env.USERPROFILE, '.stepclaw', 'dongcai-trade-record.json')
  : path.join(process.env.HOME, '.stepclaw', 'dongcai-trade-record.json');

// 默认配置
const DEFAULT_CONFIG = {
  // 模拟账户设置
  initialCapital: 100000,
  commissionRate: 0.00025,  // 佣金万2.5
  stampTaxRate: 0.001,      // 印花税千1（卖出时）
  transferFeeRate: 0.00002, // 过户费（沪市）
  
  // 风险控制
  maxPositionPerStock: 0.10,  // 单票最大10%
  maxTotalPosition: 0.80,      // 总仓位最大80%
  stopLoss: -0.08,             // 止损-8%
  takeProfit: [0.15, 0.25],    // 止盈15%/25%
  
  // 选股参数
  selection: {
    ban: {
      minSealRatio: 0.01,      // 最小封单强度1%
      maxBuyTime: '10:30',     // 最晚买入时间
      maxPosition: 0.10
    },
    dip: {
      pullbackRange: [0.15, 0.25],
      volumeShrink: 0.33,
      maxPosition: 0.10
    }
  }
};

// 东财妙想API模拟（实际接入时需要替换为真实API）
const DongCaiAPI = {
  // 登录
  async login(credentials) {
    // TODO: 接入东财妙想登录API
    console.log('登录东财妙想...');
    return { success: true, token: 'mock_token' };
  },
  
  // 获取账户信息
  async getAccount() {
    // TODO: 接入东财API
    return {
      totalCapital: 100000,
      available: 80000,
      marketValue: 20000,
      positions: []
    };
  },
  
  // 买入
  async buy(order) {
    // TODO: 接入东财买入API
    const cost = order.price * order.quantity;
    const commission = Math.max(5, cost * DEFAULT_CONFIG.commissionRate);
    const totalCost = cost + commission;
    
    return {
      success: true,
      orderId: 'B' + Date.now(),
      code: order.code,
      name: order.name,
      price: order.price,
      quantity: order.quantity,
      cost: cost,
      commission: commission,
      totalCost: totalCost,
      time: new Date().toISOString()
    };
  },
  
  // 卖出
  async sell(order) {
    // TODO: 接入东财卖出API
    const revenue = order.price * order.quantity;
    const commission = Math.max(5, revenue * DEFAULT_CONFIG.commissionRate);
    const stampTax = revenue * DEFAULT_CONFIG.stampTaxRate;
    const netRevenue = revenue - commission - stampTax;
    
    return {
      success: true,
      orderId: 'S' + Date.now(),
      code: order.code,
      price: order.price,
      quantity: order.quantity,
      revenue: revenue,
      commission: commission,
      stampTax: stampTax,
      netRevenue: netRevenue,
      time: new Date().toISOString()
    };
  },
  
  // 获取持仓
  async getPositions() {
    // TODO: 接入东财持仓API
    return [];
  },
  
  // 获取当日成交
  async getTodayTrades() {
    // TODO: 接入东财成交API
    return [];
  }
};

// 加载配置
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return { ...DEFAULT_CONFIG, ...JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8')) };
    }
  } catch (e) {
    console.error('加载配置失败:', e.message);
  }
  return { ...DEFAULT_CONFIG };
}

// 保存配置
function saveConfig(config) {
  try {
    const dir = path.dirname(CONFIG_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf-8');
    return true;
  } catch (e) {
    console.error('保存配置失败:', e.message);
    return false;
  }
}

// 加载交易记录
function loadTradeRecord() {
  try {
    if (fs.existsSync(TRADE_RECORD_PATH)) {
      return JSON.parse(fs.readFileSync(TRADE_RECORD_PATH, 'utf-8'));
    }
  } catch (e) {
    console.error('加载交易记录失败:', e.message);
  }
  return {
    initialCapital: DEFAULT_CONFIG.initialCapital,
    currentCapital: DEFAULT_CONFIG.initialCapital,
    positions: {},
    trades: [],
    dailyReports: []
  };
}

// 保存交易记录
function saveTradeRecord(record) {
  try {
    const dir = path.dirname(TRADE_RECORD_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(TRADE_RECORD_PATH, JSON.stringify(record, null, 2), 'utf-8');
    return true;
  } catch (e) {
    console.error('保存交易记录失败:', e.message);
    return false;
  }
}

// 选股引擎
const StockSelector = {
  // 首板选股
  async selectBanStocks() {
    // TODO: 接入东财数据，筛选首板股票
    console.log('正在筛选首板股票...');
    return [
      { code: '000066', name: '中国长城', sealRatio: 0.018, theme: '信创' },
      { code: '603019', name: '中科曙光', sealRatio: 0.009, theme: '算力' }
    ].filter(s => s.sealRatio >= DEFAULT_CONFIG.selection.ban.minSealRatio);
  },
  
  // 低吸选股
  async selectDipStocks() {
    // TODO: 接入东财数据，筛选回调股票
    console.log('正在筛选低吸标的...');
    return [
      { code: '000001', name: '平安银行', pullback: 0.18, volumeRatio: 0.3 }
    ].filter(s => {
      const [min, max] = DEFAULT_CONFIG.selection.dip.pullbackRange;
      return s.pullback >= min && s.pullback <= max && s.volumeRatio <= DEFAULT_CONFIG.selection.dip.volumeShrink;
    });
  },
  
  // 趋势选股
  async selectTrendStocks() {
    // TODO: 接入东财数据，筛选趋势股
    console.log('正在筛选趋势股票...');
    return [];
  }
};

// 模拟买入
async function simulateBuy(code, name, price, quantity) {
  const record = loadTradeRecord();
  const config = loadConfig();
  
  const cost = price * quantity;
  const commission = Math.max(5, cost * config.commissionRate);
  const totalCost = cost + commission;
  
  // 检查资金
  if (totalCost > record.currentCapital) {
    return { error: '资金不足' };
  }
  
  // 检查仓位
  const positionValue = Object.values(record.positions).reduce((s, p) => s + p.cost * p.quantity, 0);
  const newPositionRatio = (positionValue + totalCost) / record.initialCapital;
  if (newPositionRatio > config.maxTotalPosition) {
    return { error: '超过总仓位限制' };
  }
  
  // 执行买入
  const trade = {
    id: 'B' + Date.now(),
    type: 'buy',
    code,
    name,
    price,
    quantity,
    cost,
    commission,
    totalCost,
    time: new Date().toISOString()
  };
  
  record.trades.push(trade);
  record.currentCapital -= totalCost;
  
  // 更新持仓
  if (!record.positions[code]) {
    record.positions[code] = { name, quantity: 0, cost: 0 };
  }
  const pos = record.positions[code];
  const totalQuantity = pos.quantity + quantity;
  pos.cost = (pos.cost * pos.quantity + totalCost) / totalQuantity;
  pos.quantity = totalQuantity;
  
  saveTradeRecord(record);
  return trade;
}

// 模拟卖出
async function simulateSell(code, price, quantity) {
  const record = loadTradeRecord();
  const config = loadConfig();
  
  const pos = record.positions[code];
  if (!pos || pos.quantity < quantity) {
    return { error: '持仓不足' };
  }
  
  const revenue = price * quantity;
  const commission = Math.max(5, revenue * config.commissionRate);
  const stampTax = revenue * config.stampTaxRate;
  const netRevenue = revenue - commission - stampTax;
  const cost = pos.cost * quantity;
  const profit = netRevenue - cost;
  const profitRate = (profit / cost * 100).toFixed(2);
  
  const trade = {
    id: 'S' + Date.now(),
    type: 'sell',
    code,
    name: pos.name,
    price,
    quantity,
    revenue,
    commission,
    stampTax,
    netRevenue,
    cost,
    profit,
    profitRate,
    time: new Date().toISOString()
  };
  
  record.trades.push(trade);
  record.currentCapital += netRevenue;
  
  // 更新持仓
  pos.quantity -= quantity;
  if (pos.quantity === 0) {
    delete record.positions[code];
  }
  
  saveTradeRecord(record);
  return trade;
}

// 生成日报
function generateDailyReport() {
  const record = loadTradeRecord();
  const today = new Date().toISOString().split('T')[0];
  
  const todayTrades = record.trades.filter(t => t.time.startsWith(today));
  const buyTrades = todayTrades.filter(t => t.type === 'buy');
  const sellTrades = todayTrades.filter(t => t.type === 'sell');
  
  const totalProfit = sellTrades.reduce((s, t) => s + t.profit, 0);
  const totalCost = buyTrades.reduce((s, t) => s + t.totalCost, 0);
  
  return {
    date: today,
    buyCount: buyTrades.length,
    sellCount: sellTrades.length,
    totalProfit: totalProfit.toFixed(2),
    totalCost: totalCost.toFixed(2),
    returnRate: totalCost > 0 ? (totalProfit / totalCost * 100).toFixed(2) + '%' : '0%',
    currentCapital: record.currentCapital.toFixed(2),
    positions: record.positions
  };
}

// 命令行接口
async function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  switch (command) {
    case 'init':
      const capital = args[1] || 100000;
      const cfg = loadConfig();
      cfg.initialCapital = parseInt(capital);
      saveConfig(cfg);
      
      const record = loadTradeRecord();
      record.initialCapital = cfg.initialCapital;
      record.currentCapital = cfg.initialCapital;
      saveTradeRecord(record);
      
      console.log('✅ 模拟交易账户已初始化');
      console.log(`初始资金：${cfg.initialCapital}元`);
      break;
      
    case '选股':
      const strategy = args[1] || 'ban';
      let stocks;
      if (strategy === 'ban') {
        stocks = await StockSelector.selectBanStocks();
      } else if (strategy === 'dip') {
        stocks = await StockSelector.selectDipStocks();
      } else {
        stocks = await StockSelector.selectTrendStocks();
      }
      console.log(`🎯 ${strategy === 'ban' ? '首板' : strategy === 'dip' ? '低吸' : '趋势'}选股结果：`);
      console.log(JSON.stringify(stocks, null, 2));
      break;
      
    case '买入':
      if (args.length < 5) {
        console.log('用法: 买入 [代码] [名称] [价格] [数量]');
        break;
      }
      const buyResult = await simulateBuy(args[1], args[2], parseFloat(args[3]), parseInt(args[4]));
      console.log('买入结果：', buyResult.error || buyResult);
      break;
      
    case '卖出':
      if (args.length < 4) {
        console.log('用法: 卖出 [代码] [价格] [数量]');
        break;
      }
      const sellResult = await simulateSell(args[1], parseFloat(args[2]), parseInt(args[3]));
      console.log('卖出结果：', sellResult.error || sellResult);
      break;
      
    case '持仓':
      const rec = loadTradeRecord();
      console.log('📊 当前持仓：');
      console.log(JSON.stringify(rec.positions, null, 2));
      console.log(`可用资金：${rec.currentCapital.toFixed(2)}元`);
      break;
      
    case '日报':
      const report = generateDailyReport();
      console.log('📈 今日交易日报：');
      console.log(JSON.stringify(report, null, 2));
      break;
      
    default:
      console.log('A股选股+东财模拟交易');
      console.log('命令列表:');
      console.log('  init [本金]           - 初始化模拟账户');
      console.log('  选股 [ban/dip/trend]  - 执行选股策略');
      console.log('  买入 [代码] [名称] [价格] [数量]');
      console.log('  卖出 [代码] [价格] [数量]');
      console.log('  持仓                 - 查看持仓');
      console.log('  日报                 - 生成交易日报');
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  DongCaiAPI,
  StockSelector,
  simulateBuy,
  simulateSell,
  generateDailyReport,
  loadConfig,
  saveConfig,
  loadTradeRecord,
  saveTradeRecord
};
