#!/usr/bin/env node
/**
 * 智能炒股策略 Skill - 核心脚本
 * 提供股票分析、策略生成、盯盘提醒等功能
 */

const fs = require('fs');
const path = require('path');

// 配置文件路径
const CONFIG_PATH = process.env.USERPROFILE
  ? path.join(process.env.USERPROFILE, '.stepclaw', 'stock-strategy-config.json')
  : path.join(process.env.HOME, '.stepclaw', 'stock-strategy-config.json');

// 交易记录路径
const TRADE_LOG_PATH = process.env.USERPROFILE
  ? path.join(process.env.USERPROFILE, '.stepclaw', 'stock-trade-log.json')
  : path.join(process.env.HOME, '.stepclaw', 'stock-trade-log.json');

// 默认配置
const DEFAULT_CONFIG = {
  totalCapital: 100000,
  riskLevel: 'medium', // low, medium, high
  maxPosition: 0.2,    // 单票最大仓位 20%
  maxTotalPosition: 0.8, // 总仓位上限 80%
  stopLoss: -0.08,     // 止损 -8%
  takeProfit: [0.15, 0.25, 0.35], // 分批止盈
  watchlist: [],       // 自选股
  alerts: []           // 盯盘提醒
};

// 加载配置
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    }
  } catch (e) {
    console.error('加载配置失败:', e.message);
  }
  return { ...DEFAULT_CONFIG };
}

// 保存配置
function saveConfig(config) {
  try {
    const dir = path.dirname(CONFIG_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf-8');
    return true;
  } catch (e) {
    console.error('保存配置失败:', e.message);
    return false;
  }
}

// 加载交易记录
function loadTradeLog() {
  try {
    if (fs.existsSync(TRADE_LOG_PATH)) {
      return JSON.parse(fs.readFileSync(TRADE_LOG_PATH, 'utf-8'));
    }
  } catch (e) {
    console.error('加载交易记录失败:', e.message);
  }
  return { trades: [], positions: {} };
}

// 保存交易记录
function saveTradeLog(log) {
  try {
    const dir = path.dirname(TRADE_LOG_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(TRADE_LOG_PATH, JSON.stringify(log, null, 2), 'utf-8');
    return true;
  } catch (e) {
    console.error('保存交易记录失败:', e.message);
    return false;
  }
}

// 初始化配置
function initConfig(capital, riskLevel) {
  const config = {
    ...DEFAULT_CONFIG,
    totalCapital: parseInt(capital) || 100000,
    riskLevel: riskLevel || 'medium'
  };
  
  // 根据风险偏好调整参数
  if (config.riskLevel === 'low') {
    config.maxPosition = 0.15;
    config.maxTotalPosition = 0.6;
    config.stopLoss = -0.05;
    config.takeProfit = [0.10, 0.20];
  } else if (config.riskLevel === 'high') {
    config.maxPosition = 0.30;
    config.maxTotalPosition = 0.90;
    config.stopLoss = -0.10;
    config.takeProfit = [0.20, 0.35, 0.50];
  }
  
  saveConfig(config);
  return config;
}

// 生成技术分析报告（模拟）
function generateTechAnalysis(stockCode, stockName) {
  // 实际应用中这里应该调用行情API获取实时数据
  // 这里返回模板结构
  return {
    code: stockCode,
    name: stockName || stockCode,
    price: null, // 需要实时获取
    ma5: null,
    ma10: null,
    ma20: null,
    macd: null,
    kdj: null,
    volume: null,
    analysis: '需要接入实时行情API'
  };
}

// 生成交易策略
function generateStrategy(config) {
  const { totalCapital, riskLevel, maxPosition, takeProfit, stopLoss } = config;
  
  const singlePosition = Math.floor(totalCapital * maxPosition);
  const maxStocks = Math.floor(totalCapital * config.maxTotalPosition / singlePosition);
  
  let strategyType, holdingPeriod, stockCriteria;
  
  if (riskLevel === 'low') {
    strategyType = '价值投资型';
    holdingPeriod = '1~6个月';
    stockCriteria = ['PE<30', 'ROE>15%', '行业龙头', '业绩稳定'];
  } else if (riskLevel === 'medium') {
    strategyType = '波段操作型';
    holdingPeriod = '2~4周';
    stockCriteria = ['趋势向上', '成交量活跃', '热点题材', '估值合理'];
  } else {
    strategyType = '短线交易型';
    holdingPeriod = '3~10天';
    stockCriteria = ['强势股', '高换手', '热点龙头', '技术突破'];
  }
  
  return {
    strategyType,
    capital: totalCapital,
    singlePosition,
    maxStocks,
    holdingPeriod,
    stockCriteria,
    stopLoss: `${(stopLoss * 100).toFixed(0)}%`,
    takeProfit: takeProfit.map(p => `${(p * 100).toFixed(0)}%`).join(' / '),
    cashReserve: `${((1 - config.maxTotalPosition) * 100).toFixed(0)}%`
  };
}

// 计算仓位建议
function calculatePosition(currentPrice, supportPrice, resistancePrice, riskLevel) {
  // 风险收益比计算
  const upside = resistancePrice - currentPrice;
  const downside = currentPrice - supportPrice;
  const riskRewardRatio = upside / downside;
  
  let positionRatio;
  if (riskRewardRatio >= 3) {
    positionRatio = riskLevel === 'high' ? 0.30 : riskLevel === 'medium' ? 0.20 : 0.15;
  } else if (riskRewardRatio >= 2) {
    positionRatio = riskLevel === 'high' ? 0.20 : riskLevel === 'medium' ? 0.15 : 0.10;
  } else {
    positionRatio = riskLevel === 'high' ? 0.10 : 0.05;
  }
  
  return {
    riskRewardRatio: riskRewardRatio.toFixed(2),
    positionRatio: `${(positionRatio * 100).toFixed(0)}%`,
    suggestion: riskRewardRatio >= 2 ? '风险收益比良好，可考虑建仓' : '风险收益比一般，谨慎参与'
  };
}

// 设置盯盘提醒
function setAlert(stockCode, condition, targetPrice) {
  const config = loadConfig();
  const alert = {
    id: Date.now().toString(),
    code: stockCode,
    condition, // 'above' 或 'below'
    targetPrice: parseFloat(targetPrice),
    createdAt: new Date().toISOString(),
    active: true
  };
  
  config.alerts.push(alert);
  saveConfig(config);
  return alert;
}

// 取消盯盘提醒
function cancelAlert(stockCode) {
  const config = loadConfig();
  const beforeCount = config.alerts.length;
  config.alerts = config.alerts.filter(a => a.code !== stockCode);
  saveConfig(config);
  return beforeCount - config.alerts.length;
}

// 记录买入
function recordBuy(stockCode, stockName, price, quantity) {
  const log = loadTradeLog();
  const trade = {
    id: Date.now().toString(),
    type: 'buy',
    code: stockCode,
    name: stockName,
    price: parseFloat(price),
    quantity: parseInt(quantity),
    amount: parseFloat(price) * parseInt(quantity),
    date: new Date().toISOString()
  };
  
  log.trades.push(trade);
  
  // 更新持仓
  if (!log.positions[stockCode]) {
    log.positions[stockCode] = { name: stockName, quantity: 0, cost: 0 };
  }
  const pos = log.positions[stockCode];
  const totalCost = pos.cost * pos.quantity + trade.amount;
  pos.quantity += trade.quantity;
  pos.cost = totalCost / pos.quantity;
  
  saveTradeLog(log);
  return trade;
}

// 记录卖出
function recordSell(stockCode, price, quantity) {
  const log = loadTradeLog();
  const pos = log.positions[stockCode];
  
  if (!pos || pos.quantity < quantity) {
    return { error: '持仓不足' };
  }
  
  const trade = {
    id: Date.now().toString(),
    type: 'sell',
    code: stockCode,
    name: pos.name,
    price: parseFloat(price),
    quantity: parseInt(quantity),
    amount: parseFloat(price) * parseInt(quantity),
    cost: pos.cost * parseInt(quantity),
    profit: (parseFloat(price) - pos.cost) * parseInt(quantity),
    profitRate: ((parseFloat(price) - pos.cost) / pos.cost * 100).toFixed(2),
    date: new Date().toISOString()
  };
  
  log.trades.push(trade);
  
  // 更新持仓
  pos.quantity -= trade.quantity;
  if (pos.quantity === 0) {
    delete log.positions[stockCode];
  }
  
  saveTradeLog(log);
  return trade;
}

// 查看持仓
function getPositions() {
  const log = loadTradeLog();
  return log.positions;
}

// 生成盈亏报表
function generateReport() {
  const log = loadTradeLog();
  const trades = log.trades;
  
  let totalBuy = 0, totalSell = 0, totalProfit = 0;
  const stockStats = {};
  
  trades.forEach(t => {
    if (t.type === 'buy') {
      totalBuy += t.amount;
    } else {
      totalSell += t.amount;
      totalProfit += t.profit;
      if (!stockStats[t.code]) {
        stockStats[t.code] = { name: t.name, profit: 0, trades: 0 };
      }
      stockStats[t.code].profit += t.profit;
      stockStats[t.code].trades++;
    }
  });
  
  return {
    totalTrades: trades.length,
    totalBuy: totalBuy.toFixed(2),
    totalSell: totalSell.toFixed(2),
    totalProfit: totalProfit.toFixed(2),
    returnRate: totalBuy > 0 ? ((totalProfit / totalBuy) * 100).toFixed(2) + '%' : '0%',
    stockStats,
    currentPositions: log.positions
  };
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  switch (command) {
    case 'init':
      const capital = args[1] || 100000;
      const risk = args[2] || 'medium';
      const cfg = initConfig(capital, risk);
      console.log('✅ 配置已初始化');
      console.log(JSON.stringify(cfg, null, 2));
      break;
      
    case 'strategy':
      const config = loadConfig();
      const strategy = generateStrategy(config);
      console.log('🎯 交易策略');
      console.log(JSON.stringify(strategy, null, 2));
      break;
      
    case 'alert':
      if (args.length < 4) {
        console.log('用法: alert [股票代码] [above/below] [价格]');
        break;
      }
      const alert = setAlert(args[1], args[2], args[3]);
      console.log('⏰ 提醒已设置:', alert);
      break;
      
    case 'buy':
      if (args.length < 5) {
        console.log('用法: buy [代码] [名称] [价格] [数量]');
        break;
      }
      const buyTrade = recordBuy(args[1], args[2], args[3], args[4]);
      console.log('✅ 买入记录:', buyTrade);
      break;
      
    case 'sell':
      if (args.length < 4) {
        console.log('用法: sell [代码] [价格] [数量]');
        break;
      }
      const sellTrade = recordSell(args[1], args[2], args[3]);
      console.log('✅ 卖出记录:', sellTrade);
      break;
      
    case 'positions':
      const positions = getPositions();
      console.log('📊 当前持仓:', positions);
      break;
      
    case 'report':
      const report = generateReport();
      console.log('📈 盈亏报表:', report);
      break;
      
    default:
      console.log('智能炒股策略 Skill');
      console.log('命令列表:');
      console.log('  init [本金] [风险偏好]  - 初始化配置');
      console.log('  strategy                - 生成交易策略');
      console.log('  alert [代码] [条件] [价格] - 设置提醒');
      console.log('  buy [代码] [名称] [价格] [数量] - 记录买入');
      console.log('  sell [代码] [价格] [数量] - 记录卖出');
      console.log('  positions               - 查看持仓');
      console.log('  report                  - 生成盈亏报表');
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  loadConfig,
  saveConfig,
  initConfig,
  generateStrategy,
  calculatePosition,
  setAlert,
  cancelAlert,
  recordBuy,
  recordSell,
  getPositions,
  generateReport
};
