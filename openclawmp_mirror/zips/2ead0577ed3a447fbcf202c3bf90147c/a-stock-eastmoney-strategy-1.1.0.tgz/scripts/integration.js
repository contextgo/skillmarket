#!/usr/bin/env node
/**
 * A股策略 + 东财数据 整合模块
 * 提供数据驱动的交易决策
 */

const aStock = require('./a-stock-strategy');

// 东财数据API接口
// 注意：实际使用时需要在本地配置API密钥，不会随Skill发布
// 配置路径：~/.stepclaw/eastmoney-config.json
const EastMoneyAPI = {
  // 获取实时行情
  async getQuote(stockCode) {
    // TODO: 接入东财实时行情API
    return {
      code: stockCode,
      price: null,
      change: null,
      volume: null,
      turnover: null,
      bid: [],
      ask: []
    };
  },
  
  // 获取K线数据
  async getKLine(stockCode, period, count) {
    // TODO: 接入东财K线API
    return [];
  },
  
  // 获取资金流向
  async getCapitalFlow(stockCode) {
    // TODO: 接入东财资金流向API
    return {
      mainIn: 0,
      mainOut: 0,
      retailIn: 0,
      retailOut: 0,
      northBound: 0
    };
  },
  
  // 获取龙虎榜
  async getDragonTiger(stockCode, date) {
    // TODO: 接入东财龙虎榜API
    return {
      buyList: [],
      sellList: [],
      netBuy: 0
    };
  },
  
  // 获取财务数据
  async getFinancial(stockCode) {
    // TODO: 接入东财财务API
    return {
      pe: null,
      pb: null,
      roe: null,
      revenue: null,
      profit: null
    };
  }
};

/**
 * 深度分析一只股票（整合数据和策略）
 * @param {string} stockCode - 股票代码
 * @param {string} stockName - 股票名称
 */
async function deepAnalysis(stockCode, stockName) {
  console.log(`🔍 深度分析：${stockName}（${stockCode}）`);
  console.log('正在获取东财数据...');
  
  // 获取各类数据
  const quote = await EastMoneyAPI.getQuote(stockCode);
  const flow = await EastMoneyAPI.getCapitalFlow(stockCode);
  const dragon = await EastMoneyAPI.getDragonTiger(stockCode);
  const financial = await EastMoneyAPI.getFinancial(stockCode);
  
  // 数据验证和策略匹配
  const config = aStock.loadConfig();
  
  // 构建分析报告
  const report = {
    basic: { code: stockCode, name: stockName },
    quote,
    flow,
    dragon,
    financial,
    strategy: null,
    score: 0,
    suggestion: ''
  };
  
  // 根据数据选择策略
  if (quote.change >= 9.5) {
    // 涨停，使用打板策略
    report.strategy = 'ban';
    const banStrength = aStock.analyzeBanStrength(
      dragon.buyList?.reduce((s, i) => s + i.amount, 0) || 0,
      quote.turnover * 100 || 1000000000
    );
    report.banAnalysis = banStrength;
    report.score = banStrength.canBuy ? 75 : 40;
  } else if (quote.change <= -5) {
    // 大跌，考虑低吸
    report.strategy = 'dip';
    report.score = 50;
  } else {
    // 正常波动，趋势策略
    report.strategy = 'trend';
    report.score = 60;
  }
  
  // 资金加分
  if (flow.mainIn > flow.mainOut) {
    report.score += 10;
  }
  
  // 龙虎榜加分
  if (dragon.buyList?.length > 0) {
    report.score += 5;
  }
  
  // 生成建议
  if (report.score >= 80) {
    report.suggestion = '强烈推荐，可积极参与';
  } else if (report.score >= 60) {
    report.suggestion = '建议参与，控制仓位';
  } else if (report.score >= 40) {
    report.suggestion = '谨慎参与，小仓位试水';
  } else {
    report.suggestion = '不建议参与';
  }
  
  return report;
}

/**
 * 实时监控持仓
 * @param {array} positions - 持仓列表 [{code, name, cost, quantity}]
 */
async function monitorPositions(positions) {
  const alerts = [];
  
  for (const pos of positions) {
    const quote = await EastMoneyAPI.getQuote(pos.code);
    const currentPrice = quote.price;
    const profitRate = ((currentPrice - pos.cost) / pos.cost * 100).toFixed(2);
    
    // 止损检查
    if (profitRate < -8) {
      alerts.push({
        type: 'stopLoss',
        code: pos.code,
        name: pos.name,
        message: `跌破止损线-8%，当前盈亏${profitRate}%，建议卖出`
      });
    }
    
    // 止盈检查
    if (profitRate > 15) {
      alerts.push({
        type: 'takeProfit',
        code: pos.code,
        name: pos.name,
        message: `达到第一止盈位+15%，当前盈亏${profitRate}%，建议减仓`
      });
    }
    
    // 主力资金大幅流出预警
    const flow = await EastMoneyAPI.getCapitalFlow(pos.code);
    if (flow.mainOut - flow.mainIn > 100000000) {
      alerts.push({
        type: 'capitalOut',
        code: pos.code,
        name: pos.name,
        message: '主力资金大幅流出超1亿，建议警惕'
      });
    }
  }
  
  return alerts;
}

/**
 * 扫描打板机会
 * 筛选当日涨停股票，分析打板可行性
 */
async function scanBanOpportunities() {
  // TODO: 获取当日所有涨停股票
  const banStocks = []; // 从东财获取
  
  const opportunities = [];
  
  for (const stock of banStocks) {
    const dragon = await EastMoneyAPI.getDragonTiger(stock.code);
    const flow = await EastMoneyAPI.getCapitalFlow(stock.code);
    
    const analysis = aStock.analyzeBanStrength(
      dragon.buyList?.reduce((s, i) => s + i.amount, 0) || 0,
      stock.marketCap
    );
    
    if (analysis.canBuy) {
      opportunities.push({
        code: stock.code,
        name: stock.name,
        strength: analysis,
        flow,
        dragon
      });
    }
  }
  
  // 按强度排序
  opportunities.sort((a, b) => b.strength.ratio - a.strength.ratio);
  
  return opportunities.slice(0, 10); // 返回前10
}

/**
 * 扫描低吸机会
 * 筛选回调到位的股票
 */
async function scanDipOpportunities() {
  // TODO: 获取近期强势股回调数据
  const candidates = [];
  
  const opportunities = [];
  
  for (const stock of candidates) {
    const kline = await EastMoneyAPI.getKLine(stock.code, 'day', 30);
    const flow = await EastMoneyAPI.getCapitalFlow(stock.code);
    
    // 计算回调幅度
    const high = Math.max(...kline.map(k => k.high));
    const current = kline[kline.length - 1].close;
    const pullback = (high - current) / high;
    
    // 计算量能
    const avgVolume = kline.slice(-10).reduce((s, k) => s + k.volume, 0) / 10;
    const currentVolume = kline[kline.length - 1].volume;
    const volumeRatio = currentVolume / avgVolume;
    
    if (pullback >= 0.15 && pullback <= 0.25 && volumeRatio < 0.5) {
      opportunities.push({
        code: stock.code,
        name: stock.name,
        pullback: (pullback * 100).toFixed(1) + '%',
        volumeRatio: volumeRatio.toFixed(2),
        flow
      });
    }
  }
  
  return opportunities;
}

// 命令行接口
function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  switch (command) {
    case 'analyze':
      if (args.length < 3) {
        console.log('用法: analyze [代码] [名称]');
        break;
      }
      deepAnalysis(args[1], args[2]).then(report => {
        console.log(JSON.stringify(report, null, 2));
      });
      break;
      
    case 'monitor':
      // 监控持仓（需要传入持仓数据）
      console.log('监控持仓功能需要配置持仓数据');
      break;
      
    case 'scan-ban':
      scanBanOpportunities().then(list => {
        console.log('🔥 打板机会：');
        console.log(JSON.stringify(list, null, 2));
      });
      break;
      
    case 'scan-dip':
      scanDipOpportunities().then(list => {
        console.log('📉 低吸机会：');
        console.log(JSON.stringify(list, null, 2));
      });
      break;
      
    default:
      console.log('A股策略+东财数据 整合模块');
      console.log('命令列表:');
      console.log('  analyze [代码] [名称]  - 深度分析');
      console.log('  monitor               - 监控持仓');
      console.log('  scan-ban              - 扫描打板机会');
      console.log('  scan-dip              - 扫描低吸机会');
      console.log('');
      console.log('注意：需要接入东财API才能获取真实数据');
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  deepAnalysis,
  monitorPositions,
  scanBanOpportunities,
  scanDipOpportunities,
  EastMoneyAPI
};
