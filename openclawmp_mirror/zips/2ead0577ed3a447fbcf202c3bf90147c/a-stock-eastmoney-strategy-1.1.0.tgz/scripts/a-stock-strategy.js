#!/usr/bin/env node
/**
 * A股智能策略 - 核心脚本
 * 针对A股特点优化：T+1、涨跌停、游资、题材炒作
 */

const fs = require('fs');
const path = require('path');

const CONFIG_PATH = process.env.USERPROFILE
  ? path.join(process.env.USERPROFILE, '.stepclaw', 'a-stock-config.json')
  : path.join(process.env.HOME, '.stepclaw', 'a-stock-config.json');

// A股默认配置
const DEFAULT_CONFIG = {
  totalCapital: 100000,
  riskLevel: 'medium',
  // A股特化参数
  maxPositionPerStock: 0.15,  // 单票最大15%（T+1风险）
  maxPositionTotal: 0.70,      // 总仓位最大70%（留30%现金）
  
  // 打板策略参数
  banStrategy: {
    maxPosition: 0.10,         // 打板单票最大10%
    totalBanPosition: 0.30,    // 打板总仓位最大30%
    minSealAmount: 100000000,  // 最小封单金额1亿
    maxBuyTime: '10:30',       // 最晚买入时间
    stopLossNextDay: -0.05     // 次日止损-5%
  },
  
  // 低吸策略参数
  dipStrategy: {
    maxPosition: 0.15,
    pullbackRange: [0.15, 0.25],  // 回调15%~25%
    volumeShrink: 0.33,            // 缩量至1/3
    stopLoss: -0.05
  },
  
  // 趋势策略参数
  trendStrategy: {
    maxPosition: 0.20,
    maLong: 60,    // 60日线
    maShort: 20,   // 20日线
    stopLoss: -0.08
  },
  
  // 潜伏策略参数
 潜伏Strategy: {
    maxPosition: 0.10,
    maxHoldDays: 20,
    stopLoss: -0.08
  },
  
  watchlist: [],
  alerts: [],
  trades: []
};

// 加载配置
function loadConfig() {
  try {
    if (fs.existsSync(CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(CONFIG_PATH, 'utf-8'));
    }
  } catch (e) {
    console.error('加载配置失败:', e.message);
  }
  return { ...DEFAULT_CONFIG };
}

// 保存配置
function saveConfig(config) {
  try {
    const dir = path.dirname(CONFIG_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2), 'utf-8');
    return true;
  } catch (e) {
    console.error('保存配置失败:', e.message);
    return false;
  }
}

// ==================== A股特化分析函数 ====================

/**
 * 涨停板强度分析
 * @param {number} sealAmount - 封单金额（元）
 * {number} marketCap - 流通市值（元）
 * @returns {object} 分析结果
 */
function analyzeBanStrength(sealAmount, marketCap) {
  const ratio = (sealAmount / marketCap * 100).toFixed(2);
  let strength, suggestion;
  
  if (ratio > 5) {
    strength = '超强';
    suggestion = '次日高开概率>80%，可积极参与';
  } else if (ratio > 2) {
    strength = '较强';
    suggestion = '次日高开概率60~80%，可参与';
  } else if (ratio > 1) {
    strength = '中等';
    suggestion = '次日高开概率50%，谨慎参与';
  } else {
    strength = '较弱';
    suggestion = '次日可能低开，不建议打板';
  }
  
  return {
    ratio: ratio + '%',
    strength,
    suggestion,
    canBuy: ratio > 1
  };
}

/**
 * 龙虎榜分析
 * @param {array} buyList - 买入席位 [{name, amount}]
 * @param {array} sellList - 卖出席位 [{name, amount}]
 * @returns {object} 分析结果
 */
function analyzeDragonTiger(buyList, sellList) {
  const topYouzi = ['章盟主', '方新侠', '赵老哥', '炒股养家', '作手新一'];
  const retailSeat = '东财拉萨';
  
  let buyTotal = buyList.reduce((sum, item) => sum + item.amount, 0);
  let sellTotal = sellList.reduce((sum, item) => sum + item.amount, 0);
  let netBuy = buyTotal - sellTotal;
  
  // 分析游资
  let youziBuy = buyList.filter(item => 
    topYouzi.some(yz => item.name.includes(yz))
  );
  
  // 分析散户
  let retailSell = sellList.filter(item => 
    item.name.includes(retailSeat)
  );
  
  // 分析机构
  let institutionBuy = buyList.filter(item => 
    item.name.includes('机构专用')
  );
  
  return {
    buyTotal: (buyTotal / 100000000).toFixed(2) + '亿',
    sellTotal: (sellTotal / 100000000).toFixed(2) + '亿',
    netBuy: (netBuy / 100000000).toFixed(2) + '亿',
    hasYouzi: youziBuy.length > 0,
    hasInstitution: institutionBuy.length > 0,
    retailPressure: retailSell.length > 0,
    sentiment: netBuy > 0 ? '看多' : '看空'
  };
}

/**
 * 题材热度分析
 * @param {string} theme - 题材名称
 * @param {number} banCount - 涨停家数
 * @returns {object} 热度分析
 */
function analyzeThemeHeat(theme, banCount) {
  let heat, level;
  
  if (banCount >= 20) {
    heat = '🔥🔥🔥🔥🔥';
    level = '超级热点';
  } else if (banCount >= 10) {
    heat = '🔥🔥🔥🔥';
    level = '强势热点';
  } else if (banCount >= 5) {
    heat = '🔥🔥🔥';
    level = '一般热点';
  } else if (banCount >= 3) {
    heat = '🔥🔥';
    level = '弱势热点';
  } else {
    heat = '🔥';
    level = '冷门题材';
  }
  
  return {
    theme,
    banCount,
    heat,
    level,
    suggestion: banCount >= 10 ? '积极参与龙头' : banCount >= 5 ? '谨慎参与' : '观望'
  };
}

/**
 * 低吸可行性分析
 * @param {number} currentPrice - 当前价格
 * @param {number} highPrice - 前期高点
 * @param {number} ma20 - 20日线价格
 * @param {number} volumeRatio - 量能比例（当前/前期）
 * @returns {object} 分析结果
 */
function analyzeDipBuy(currentPrice, highPrice, ma20, volumeRatio) {
  const pullback = ((highPrice - currentPrice) / highPrice * 100).toFixed(1);
  const belowMa20 = currentPrice < ma20;
  const volumeShrink = volumeRatio < 0.4;
  
  let suitable = false;
  let reason = [];
  
  if (pullback >= 15 && pullback <= 25) {
    reason.push(`回调幅度${pullback}%，符合15~25%区间`);
    suitable = true;
  } else if (pullback < 15) {
    reason.push(`回调仅${pullback}%，幅度不够`);
    suitable = false;
  } else {
    reason.push(`回调${pullback}%，超跌需警惕`);
  }
  
  if (volumeShrink) {
    reason.push('成交量萎缩，抛压减轻');
  } else {
    reason.push('成交量仍大，抛压未释放');
    suitable = false;
  }
  
  if (belowMa20) {
    reason.push('已跌破20日线，趋势转弱');
    suitable = false;
  }
  
  return {
    pullback: pullback + '%',
    belowMa20,
    volumeShrink,
    suitable,
    reason: reason.join('；'),
    suggestion: suitable 
      ? '适合低吸，建议仓位≤15%，止损-5%'
      : '暂不适合，等待更好的买点'
  };
}

/**
 * 生成A股策略
 * @param {string} strategyType - 策略类型（ban/dip/trend/lurk）
 * @param {object} config - 配置
 * @returns {object} 策略详情
 */
function generateAShareStrategy(strategyType, config) {
  const strategies = {
    ban: {
      name: '涨停板战法（打板）',
      desc: '追击强势股，博取次日溢价',
      position: config.banStrategy.maxPosition * 100 + '%',
      totalPosition: config.banStrategy.totalBanPosition * 100 + '%',
      buyConditions: [
        '首板：早盘10:30前涨停',
        '封单金额 > 1亿',
        '缩量涨停（成交量 < 昨日70%）',
        '当前热点题材'
      ],
      sellConditions: [
        '次日高开5%以上：开盘即卖',
        '次日低开：-3%止损或等反弹',
        '断板（不涨停）即卖'
      ],
      stopLoss: config.banStrategy.stopLossNextDay * 100 + '%',
      risk: '高'
    },
    dip: {
      name: '龙头股低吸',
      desc: '龙头回调后的反弹机会',
      position: config.dipStrategy.maxPosition * 100 + '%',
      buyConditions: [
        '龙头地位确认（板块涨幅前3）',
        '回调15%~25%',
        '成交量萎缩至前期1/3',
        '20日线或平台支撑'
      ],
      sellConditions: [
        '反弹10%~15%减仓',
        '反弹至前高附近清仓',
        '跌破支撑位-5%止损'
      ],
      stopLoss: config.dipStrategy.stopLoss * 100 + '%',
      risk: '中'
    },
    trend: {
      name: '趋势波段',
      desc: '机构票的中线持有',
      position: config.trendStrategy.maxPosition * 100 + '%',
      buyConditions: [
        '均线多头排列（5>10>20>60）',
        '成交量稳步放大',
        '业绩持续增长',
        '北向资金持续流入'
      ],
      sellConditions: [
        '跌破20日线减仓',
        '跌破60日线清仓',
        '业绩不及预期立即卖出'
      ],
      stopLoss: config.trendStrategy.stopLoss * 100 + '%',
      risk: '中低'
    },
    lurk: {
      name: '题材潜伏',
      desc: '预判热点提前布局',
      position: config.潜伏Strategy.maxPosition * 100 + '%',
      buyConditions: [
        '题材尚未启动',
        '个股低位横盘',
        '成交量温和放大',
        '技术形态良好'
      ],
      sellConditions: [
        '题材启动后加速即卖',
        '利好兑现立即清仓',
        '不达预期-8%止损'
      ],
      maxHoldDays: config.潜伏Strategy.maxHoldDays,
      risk: '中'
    }
  };
  
  return strategies[strategyType] || strategies.trend;
}

/**
 * A股仓位分配建议
 * @param {string} marketCondition - 市场环境（bull/shock/bear）
 * @param {object} config - 配置
 * @returns {object} 仓位建议
 */
function suggestPositionAllocation(marketCondition, config) {
  const allocations = {
    bull: {
      ban: 30,
      dip: 20,
      trend: 40,
      cash: 10,
      total: 90
    },
    shock: {
      ban: 20,
      dip: 30,
      trend: 20,
      cash: 30,
      total: 70
    },
    bear: {
      ban: 10,
      dip: 10,
      trend: 20,
      cash: 60,
      total: 40
    }
  };
  
  return allocations[marketCondition] || allocations.shock;
}

// ==================== 命令行接口 ====================

function main() {
  const args = process.argv.slice(2);
  const command = args[0];
  
  switch (command) {
    case 'init':
      const capital = args[1] || 100000;
      const risk = args[2] || 'medium';
      const cfg = loadConfig();
      cfg.totalCapital = parseInt(capital);
      cfg.riskLevel = risk;
      saveConfig(cfg);
      console.log('✅ A股策略配置已初始化');
      console.log(`本金：${cfg.totalCapital}，风险偏好：${cfg.riskLevel}`);
      break;
      
    case 'ban':  // 打板分析
      if (args.length < 3) {
        console.log('用法: ban [代码] [封单金额(亿)] [流通市值(亿)]');
        break;
      }
      const sealAmount = parseFloat(args[2]) * 100000000;
      const marketCap = parseFloat(args[3]) * 100000000;
      const banResult = analyzeBanStrength(sealAmount, marketCap);
      console.log(`🔥 打板分析：${args[1]}`);
      console.log(JSON.stringify(banResult, null, 2));
      break;
      
    case 'dip':  // 低吸分析
      if (args.length < 6) {
        console.log('用法: dip [代码] [现价] [前高] [20日线] [量比]');
        break;
      }
      const dipResult = analyzeDipBuy(
        parseFloat(args[2]),
        parseFloat(args[3]),
        parseFloat(args[4]),
        parseFloat(args[5])
      );
      console.log(`📉 低吸分析：${args[1]}`);
      console.log(JSON.stringify(dipResult, null, 2));
      break;
      
    case 'strategy':  // 生成策略
      const strategyType = args[1] || 'trend';
      const strategy = generateAShareStrategy(strategyType, loadConfig());
      console.log(`🎯 ${strategy.name}`);
      console.log(JSON.stringify(strategy, null, 2));
      break;
      
    case 'position':  // 仓位建议
      const market = args[1] || 'shock';
      const pos = suggestPositionAllocation(market, loadConfig());
      console.log(`📊 ${market === 'bull' ? '牛市' : market === 'bear' ? '熊市' : '震荡市'}仓位建议：`);
      console.log(JSON.stringify(pos, null, 2));
      break;
      
    default:
      console.log('A股智能策略 Skill');
      console.log('命令列表:');
      console.log('  init [本金] [风险偏好]  - 初始化配置');
      console.log('  ban [代码] [封单亿] [市值亿] - 打板分析');
      console.log('  dip [代码] [现价] [前高] [20日线] [量比] - 低吸分析');
      console.log('  strategy [ban/dip/trend/lurk] - 生成策略');
      console.log('  position [bull/shock/bear] - 仓位建议');
  }
}

if (require.main === module) {
  main();
}

module.exports = {
  analyzeBanStrength,
  analyzeDragonTiger,
  analyzeThemeHeat,
  analyzeDipBuy,
  generateAShareStrategy,
  suggestPositionAllocation,
  loadConfig,
  saveConfig
};
