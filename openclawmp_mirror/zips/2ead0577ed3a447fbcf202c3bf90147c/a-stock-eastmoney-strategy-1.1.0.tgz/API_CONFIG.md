# API配置说明

## 东财数据API配置

本Skill需要接入东方财富数据API才能获取实时行情、资金流向等数据。

### 配置方法

1. 在用户目录创建配置文件：
   - Windows: `%USERPROFILE%\.stepclaw\eastmoney-config.json`
   - Mac/Linux: `~/.stepclaw/eastmoney-config.json`

2. 配置文件内容：
```json
{
  "eastmoney": {
    "apiKey": "你的API密钥",
    "apiSecret": "你的API密钥",
    "baseUrl": "https://api.eastmoney.com"
  }
}
```

3. 获取API密钥：
   - 访问东方财富开放平台
   - 注册开发者账号
   - 申请API权限

### 隐私保护

- API密钥存储在本地，不会随Skill发布
- Skill代码中只包含API接口定义，不包含实际密钥
- 请勿将包含密钥的配置文件上传到公共仓库

### 替代方案

如果没有东财API，可以使用以下免费数据源：
- 新浪财经API
- 腾讯财经API
- 同花顺iFinD
- 聚宽、Tushare等量化平台
