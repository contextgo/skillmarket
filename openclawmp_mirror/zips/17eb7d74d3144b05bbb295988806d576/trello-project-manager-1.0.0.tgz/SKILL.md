---
name: trello-project-manager
description: Trello项目管理集成 - 通过REST API全面管理Trello看板、列表、卡片，支持Scrum/Kanban/GTD工作流模板、燃尽图生成、Sprint规划、自动化规则和数据导出。
---

# Trello 项目管理集成工具

## 概述

本技能提供完整的 Trello API 集成能力，允许用户通过命令行和 API 调用全面管理 Trello 项目看板。支持看板创建与管理、列表和卡片的 CRUD 操作、标签与清单管理、到期日跟踪、成员分配、附件处理、看板自动化规则、数据导出以及多种敏捷工作流模板。

---

## 前置条件

### 获取 Trello API 凭证

1. 访问 https://trello.com/app-key 获取 API Key
2. 生成一个永久的 Token：https://trello.com/1/authorize?name=ProjectManager&expiration=never&scope=read,write&response_type=token&key=YOUR_API_KEY
3. 将 Key 和 Token 保存为环境变量：

```bash
export TRELLO_API_KEY="your_api_key_here"
export TRELLO_TOKEN="your_token_here"
```

### 环境验证

在开始使用前，验证凭证是否有效：

```bash
curl -s "https://api.trello.com/1/members/me?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN" | jq '.username'
```

---

## 一、看板（Board）管理

### 1.1 获取所有看板

```bash
curl -s -X GET "https://api.trello.com/1/members/me/boards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,id,url,dateLastActivity" | jq '.[] | {id, name, url, lastActivity: .dateLastActivity}'
```

### 1.2 创建新看板

```bash
curl -s -X POST "https://api.trello.com/1/boards" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=项目名称" \
  -d "desc=项目描述信息" \
  -d "prefs_background=purple" \
  -d "prefs_cardAging=regular" \
  -d "defaultLists=true" | jq '{id, name, url}'
```

### 1.3 更新看板信息

```bash
curl -s -X PUT "https://api.trello.com/1/boards/{board_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=新项目名称" \
  -d "desc=更新的项目描述"
```

### 1.4 复制看板

```bash
curl -s -X POST "https://api.trello.com/1/boards" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "idBoardSource={source_board_id}" \
  -d "name=复制的项目看板"
```

### 1.5 删除/关闭看板

```bash
# 关闭看板（软删除，可恢复）
curl -s -X PUT "https://api.trello.com/1/boards/{board_id}/closed" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "value=true"
```

### 1.6 获取看板成员

```bash
curl -s -X GET "https://api.trello.com/1/boards/{board_id}/members?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=fullName,username,avatarUrl" | jq '.[] | {username, fullName, avatar: .avatarUrl}'
```

---

## 二、列表（List）管理

### 2.1 获取看板的所有列表

```bash
curl -s -X GET "https://api.trello.com/1/boards/{board_id}/lists?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,id,pos" | jq '.[] | {id, name, position: .pos}'
```

### 2.2 创建列表

```bash
curl -s -X POST "https://api.trello.com/1/lists" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=待办事项" \
  -d "idBoard={board_id}" \
  -d "pos=top"
```

### 2.3 更新列表

```bash
curl -s -X PUT "https://api.trello.com/1/lists/{list_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=进行中" \
  -d "pos=2"
```

### 2.4 归档列表

```bash
curl -s -X PUT "https://api.trello.com/1/lists/{list_id}/closed" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "value=true"
```

### 2.5 移动列表中的所有卡片

```bash
curl -s -X POST "https://api.trello.com/1/lists/{list_id}/moveAllCards" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "idBoard={target_board_id}" \
  -d "idList={target_list_id}"
```

---

## 三、卡片（Card）管理

### 3.1 获取列表中的所有卡片

```bash
curl -s -X GET "https://api.trello.com/1/lists/{list_id}/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,id,desc,due,idLabels,idMembers,pos" | jq '.[] | {id, name, desc, due, labels: .idLabels, members: .idMembers}'
```

### 3.2 创建卡片

```bash
curl -s -X POST "https://api.trello.com/1/cards" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=实现用户登录功能" \
  -d "idList={list_id}" \
  -d "desc=As a user, I want to login with email and password so that I can access my account." \
  -d "pos=top" \
  -d "due=2025-02-15T18:00:00.000Z" \
  -d "dueComplete=false" \
  -d "idLabels={label_id_1},{label_id_2}" \
  -d "idMembers={member_id_1}" | jq '{id, name, url}'
```

### 3.3 更新卡片

```bash
curl -s -X PUT "https://api.trello.com/1/cards/{card_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=更新后的卡片名称" \
  -d "desc=更新后的描述信息" \
  -d "due=2025-03-01T09:00:00.000Z"
```

### 3.4 移动卡片到另一个列表

```bash
curl -s -X PUT "https://api.trello.com/1/cards/{card_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "idList={target_list_id}"
```

### 3.5 复制卡片

```bash
curl -s -X POST "https://api.trello.com/1/cards" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "idCardSource={card_id}" \
  -d "idList={list_id}" \
  -d "name=复制的卡片"
```

### 3.6 删除卡片

```bash
curl -s -X DELETE "https://api.trello.com/1/cards/{card_id}?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN"
```

### 3.7 搜索卡片

```bash
curl -s -X GET "https://api.trello.com/1/search?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&query=login+board:{board_name}&card_fields=name,id,desc,url&cards_limit=20" | jq '.cards'
```

---

## 四、标签（Label）管理

### 4.1 获取看板的所有标签

```bash
curl -s -X GET "https://api.trello.com/1/boards/{board_id}/labels?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,color,id" | jq '.[] | {id, name, color}'
```

### 4.2 创建标签

```bash
curl -s -X POST "https://api.trello.com/1/labels" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=高优先级" \
  -d "idBoard={board_id}" \
  -d "color=red"
```

### 4.3 为卡片添加标签

```bash
curl -s -X POST "https://api.trello.com/1/cards/{card_id}/idLabels" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "value={label_id}"
```

### 4.4 移除卡片标签

```bash
curl -s -X DELETE "https://api.trello.com/1/cards/{card_id}/idLabels/{label_id}?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN"
```

### 4.5 推荐标签颜色方案

以下是推荐的团队标签颜色方案：

```
🔴 red    - Bug / 紧急修复
🟠 orange - 功能需求
🟡 yellow - 优化改进
🟢 green  - 已完成
🔵 blue   - 文档
🟣 purple - 技术债务
⚫ black  - 架构变更
⚪ sky    - 用户体验
🩷 pink   - 设计
```

---

## 五、清单（Checklist）管理

### 5.1 在卡片上创建清单

```bash
curl -s -X POST "https://api.trello.com/1/checklists" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "idCard={card_id}" \
  -d "name=开发任务清单" \
  -d "pos=1"
```

### 5.2 添加清单项

```bash
curl -s -X POST "https://api.trello.com/1/checklists/{checklist_id}/checkItems" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=设计数据库模型" \
  -d "pos=1" \
  -d "checked=false"
```

### 5.3 更新清单项状态

```bash
curl -s -X PUT "https://api.trello.com/1/cards/{card_id}/checkItem/{checkitem_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "state=complete"
```

### 5.4 获取卡片的所有清单

```bash
curl -s -X GET "https://api.trello.com/1/cards/{card_id}/checklists?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&checkItems=all&checkItem_fields=name,state" | jq '.'
```

### 5.5 删除清单

```bash
curl -s -X DELETE "https://api.trello.com/1/checklists/{checklist_id}?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN"
```

---

## 六、到期日跟踪与逾期提醒

### 6.1 设置卡片到期日

```bash
curl -s -X PUT "https://api.trello.com/1/cards/{card_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "due=2025-02-20T17:00:00.000Z" \
  -d "dueReminder=1440"
```

> `dueReminder` 参数单位为分钟，1440 = 提前一天提醒。

### 6.2 标记到期日完成

```bash
curl -s -X PUT "https://api.trello.com/1/cards/{card_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "dueComplete=true"
```

### 6.3 查找所有逾期卡片

```bash
#!/bin/bash
# overdue-cards.sh - 查找看板中所有逾期未完成的卡片
BOARD_ID="{board_id}"
NOW=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")

curl -s "https://api.trello.com/1/boards/$BOARD_ID/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,due,dueComplete,idMembers,idLabels&filter=open" \
  | jq --arg now "$NOW" '[.[] | select(.due != null and .dueComplete == false and .due < $now)]'
```

### 6.4 生成本周到期报告

```bash
#!/bin/bash
# weekly-due-report.sh
BOARD_ID="{board_id}"
START=$(date -u -d "monday" +"%Y-%m-%dT00:00:00.000Z" 2>/dev/null || date -u -v+1d -v-$(date +%u)d +"%Y-%m-%dT00:00:00.000Z")
END=$(date -u -d "next monday" +"%Y-%m-%dT00:00:00.000Z" 2>/dev/null || date -u -v+8d -v-$(date +%u)d +"%Y-%m-%dT00:00:00.000Z")

echo "📅 本周到期任务报告"
echo "========================"
curl -s "https://api.trello.com/1/boards/$BOARD_ID/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,due,dueComplete&filter=open" \
  | jq --arg start "$START" --arg end "$END" '[.[] | select(.due != null and .due >= $start and .due < $end)] | .[] | "⏰ \(.name) - 截止: \(.due)"'
```

---

## 七、成员分配与管理

### 7.1 邀请成员到看板

```bash
curl -s -X PUT "https://api.trello.com/1/boards/{board_id}/members/{member_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "type=normal" \
  -d "role=member"
```

### 7.2 为卡片分配成员

```bash
curl -s -X POST "https://api.trello.com/1/cards/{card_id}/idMembers" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "value={member_id}"
```

### 7.3 移除卡片成员

```bash
curl -s -X DELETE "https://api.trello.com/1/cards/{card_id}/idMembers/{member_id}?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN"
```

### 7.4 查看成员工作负载

```bash
#!/bin/bash
# member-workload.sh - 统计每个成员的任务数量和分布
BOARD_ID="{board_id}"

curl -s "https://api.trello.com/1/boards/$BOARD_ID/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,idMembers,idLabels,due&filter=open" \
  | jq 'group_by(.idMembers[]) | map({
       member: .[0].idMembers[0],
       total: length,
       tasks: map(.name)
     })'
```

### 7.5 通过邮箱邀请

```bash
curl -s -X PUT "https://api.trello.com/1/boards/{board_id}" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "email=user@example.com" \
  -d "type=normal"
```

---

## 八、附件处理

### 8.1 为卡片添加URL附件

```bash
curl -s -X POST "https://api.trello.com/1/cards/{card_id}/attachments" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=设计稿链接" \
  -d "url=https://example.com/design-file"
```

### 8.2 上传文件附件

```bash
curl -s -X POST "https://api.trello.com/1/cards/{card_id}/attachments" \
  -F "key=$TRELLO_API_KEY" \
  -F "token=$TRELLO_TOKEN" \
  -F "file=@/path/to/document.pdf" \
  -F "name=需求文档v1.2.pdf"
```

### 8.3 获取卡片所有附件

```bash
curl -s -X GET "https://api.trello.com/1/cards/{card_id}/attachments?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,url,date,idMember" | jq '.[] | {id, name, url, date, uploadedBy: .idMember}'
```

### 8.4 删除附件

```bash
curl -s -X DELETE "https://api.trello.com/1/cards/{card_id}/attachments/{attachment_id}?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN"
```

---

## 九、看板自动化规则

### 9.1 自动化规则设计原则

看板自动化规则基于以下事件触发机制实现：

- **卡片创建时**：自动分配标签、设置到期日、添加清单模板
- **卡片移动时**：更新状态标签、通知相关成员、记录时间戳
- **到期日临近时**：发送提醒、升级优先级标签
- **清单完成时**：自动移动卡片到下一阶段

### 9.2 自动化脚本示例：卡片移动时自动更新标签

```bash
#!/bin/bash
# auto-label-on-move.sh
# 用法：./auto-label-on-move.sh {card_id} {target_list_id}

CARD_ID=$1
TARGET_LIST_ID=$2
TRELLO_API_KEY=${TRELLO_API_KEY}
TRELLO_TOKEN=${TRELLO_TOKEN}

# 获取目标列表名称
LIST_NAME=$(curl -s "https://api.trello.com/1/lists/$TARGET_LIST_ID?fields=name&key=$TRELLO_API_KEY&token=$TRELLO_TOKEN" | jq -r '.name')

# 根据列表名称设置对应标签
case "$LIST_NAME" in
  "进行中")
    LABEL_ID="{blue_label_id}"
    ;;
  "代码审查")
    LABEL_ID="{purple_label_id}"
    ;;
  "已完成")
    LABEL_ID="{green_label_id}"
    ;;
  *)
    echo "未匹配的列表: $LIST_NAME"
    exit 0
    ;;
esac

# 清除所有现有标签并添加新标签
CURRENT_LABELS=$(curl -s "https://api.trello.com/1/cards/$CARD_ID?fields=idLabels&key=$TRELLO_API_KEY&token=$TRELLO_TOKEN" | jq -r '.idLabels[]')

for label_id in $CURRENT_LABELS; do
  curl -s -X DELETE "https://api.trello.com/1/cards/$CARD_ID/idLabels/$label_id?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN" > /dev/null
done

curl -s -X POST "https://api.trello.com/1/cards/$CARD_ID/idLabels" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "value=$LABEL_ID" > /dev/null

echo "✅ 卡片 $CARD_ID 已移动到 '$LIST_NAME' 并更新标签"
```

### 9.3 自动化脚本：每日逾期检查

```bash
#!/bin/bash
# daily-overdue-check.sh
# 建议通过 cron 每日 9:00 执行
# 0 9 * * * /path/to/daily-overdue-check.sh

BOARD_ID="{board_id}"
NOW=$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")

OVERDUE_CARDS=$(curl -s "https://api.trello.com/1/boards/$BOARD_ID/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,due,idMembers,idLabels&filter=open" \
  | jq --arg now "$NOW" '[.[] | select(.due != null and .dueComplete == false and .due < $now)]')

COUNT=$(echo $OVERDUE_CARDS | jq 'length')

if [ "$COUNT" -gt 0 ]; then
  echo "🚨 逾期任务提醒 - 共 $COUNT 个任务逾期"
  echo "======================================"
  echo $OVERDUE_CARDS | jq -r '.[] | "  ❌ \(.name) | 截止: \(.due)"'
  echo ""
  echo "请及时处理以上逾期任务。"
else
  echo "✅ 没有逾期任务，一切正常。"
fi
```

---

## 十、数据导出

### 10.1 导出看板数据为 Markdown

```bash
#!/bin/bash
# export-to-markdown.sh
BOARD_ID="{board_id}"

echo "# 项目看板报告"
echo ""
echo "> 导出时间：$(date '+%Y-%m-%d %H:%M:%S')"
echo ""

# 获取看板信息
BOARD_INFO=$(curl -s "https://api.trello.com/1/boards/$BOARD_ID?fields=name,desc&key=$TRELLO_API_KEY&token=$TRELLO_TOKEN")
BOARD_NAME=$(echo $BOARD_INFO | jq -r '.name')
BOARD_DESC=$(echo $BOARD_INFO | jq -r '.desc')

echo "## $BOARD_NAME"
echo ""
[ "$BOARD_DESC" != "null" ] && echo "$BOARD_DESC"
echo ""

# 获取列表和卡片
LISTS=$(curl -s "https://api.trello.com/1/boards/$BOARD_ID/lists?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,pos&cards=open&card_fields=name,desc,due,dueComplete,idMembers,labels&members=all")

echo "$LISTS" | jq -r '.[] | "## \(.name)\n" + (.cards | map("- [ ] \(.name)" + (if .due != null then " ⏰ \(.due)" else "" end)) | join("\n")) + "\n"'
```

### 10.2 导出看板数据为 CSV

```bash
#!/bin/bash
# export-to-csv.sh
BOARD_ID="{board_id}"

echo "Card Name,List,Due Date,Due Complete,Labels,Members"

curl -s "https://api.trello.com/1/boards/$BOARD_ID/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,due,dueComplete&filter=open&list=true&members=true&labels=true" \
  | jq -r '.[] | [
      .name,
      .list.name,
      (.due // "无"),
      (.dueComplete | tostring),
      (.labels | map(.name) | join(";")),
      (.members | map(.fullName) | join(";"))
    ] | @csv'
```

---

## 十一、Kanban 工作流模板

### 11.1 Scrum 模板

Scrum 看板包含以下列表结构：

```
📋 Backlog（产品待办）
  └── 按优先级排序的 User Stories

🎯 Sprint Backlog（当前冲刺）
  └── 本 Sprint 选定的 Stories

🔄 In Progress（开发中）
  └── 正在开发的任务

👀 Code Review（代码审查）
  └── 等待 PR Review

🧪 Testing（测试中）
  └── QA 测试阶段

✅ Done（已完成）
  └── 本 Sprint 完成的任务
```

创建 Scrum 看板脚本：

```bash
#!/bin/bash
# create-scrum-board.sh
create_scrum_board() {
  local BOARD_NAME=$1
  local DESC=$2

  # 创建看板（不使用默认列表）
  BOARD_ID=$(curl -s -X POST "https://api.trello.com/1/boards" \
    -d "key=$TRELLO_API_KEY" \
    -d "token=$TRELLO_TOKEN" \
    -d "name=$BOARD_NAME" \
    -d "desc=$DESC" \
    -d "defaultLists=false" | jq -r '.id')

  # 创建标准 Scrum 列表
  LISTS=("📋 Backlog" "🎯 Sprint Backlog" "🔄 In Progress" "👀 Code Review" "🧪 Testing" "✅ Done")

  for i in "${!LISTS[@]}"; do
    curl -s -X POST "https://api.trello.com/1/lists" \
      -d "key=$TRELLO_API_KEY" \
      -d "token=$TRELLO_TOKEN" \
      -d "name=${LISTS[$i]}" \
      -d "idBoard=$BOARD_ID" \
      -d "pos=$((i + 65536))" > /dev/null
  done

  # 创建标准标签
  LABELS=("Story:blue" "Task:green" "Bug:red" "Improvement:orange" "Tech Debt:purple")

  for label_info in "${LABELS[@]}"; do
    local LABEL_NAME="${label_info%%:*}"
    local LABEL_COLOR="${label_info##*:}"
    curl -s -X POST "https://api.trello.com/1/labels" \
      -d "key=$TRELLO_API_KEY" \
      -d "token=$TRELLO_TOKEN" \
      -d "name=$LABEL_NAME" \
      -d "color=$LABEL_COLOR" \
      -d "idBoard=$BOARD_ID" > /dev/null
  done

  echo "✅ Scrum 看板 '$BOARD_NAME' 创建成功！Board ID: $BOARD_ID"
}

create_scrum_board "Sprint 1 - 产品开发" "敏捷Scrum开发看板"
```

### 11.2 Kanban 模板

```
📥 Inbox（收件箱）
  ── 快速收集新想法和任务

🔜 To Do（待办）
  ── 已确认但尚未开始的任务

⏳ In Progress（进行中）
  ── 当前正在处理的任务（限制 WIP: 3）

👀 Blocked（阻塞）
  ── 等待外部依赖的任务

🔍 Review（审查）
  ── 需要审查或确认的任务

📤 Done（完成）
  ── 已完成的任务
```

### 11.3 GTD（Getting Things Done）模板

```
📥 收件箱（Inbox）
  ── 快速捕获所有想法和待办事项

🔥 下一步行动（Next Actions）
  ── 可以立即执行的具体行动

📅 等待中（Waiting For）
  ── 等待他人完成的事项

📅 日历（Calendar）
  ── 有明确截止时间的事项

📋 将来/也许（Someday/Maybe）
  ── 未来可能要做的事

🗂️ 参考资料（Reference）
  ── 需要保留的参考信息

🏁 已完成（Done）
  ── 已完成的任务存档
```

---

## 十二、燃尽图生成

### 12.1 从卡片数据生成燃尽图数据

```bash
#!/bin/bash
# burndown-data.sh - 导出Sprint燃尽图数据
BOARD_ID="{board_id}"
SPRINT_START="2025-02-03"
SPRINT_END="2025-02-14"
SPRINT_LENGTH=$(( ($(date -d "$SPRINT_END" +%s) - $(date -d "$SPRINT_START" +%s)) / 86400 + 1 ))

echo "日期,剩余故事点,理想线"

# 获取所有卡片的故事点（通过清单完成比例估算）
TOTAL_POINTS=$(curl -s "https://api.trello.com/1/boards/$BOARD_ID/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,labels,checklists&filter=closed" \
  | jq '[.[] | .checklists[].checkItems | length] | add // 0')

IDEAL_PER_DAY=$(echo "scale=2; $TOTAL_POINTS / $SPRINT_LENGTH" | bc)

for ((d=0; d<SPRINT_LENGTH; d++)); do
  CURRENT_DATE=$(date -d "$SPRINT_START +$d days" +"%Y-%m-%d")
  CURRENT_TS=$(date -d "$SPRINT_START +$d days" -u +"%Y-%m-%dT%H:%M:%S.000Z")

  # 简化：按天统计已完成的故事点
  COMPLETED=$(curl -s "https://api.trello.com/1/boards/$BOARD_ID/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,dateLastActivity&filter=closed" \
    | jq --arg date "$CURRENT_DATE" '[.[] | select(.dateLastActivity | startswith($date))] | length')

  REMAINING=$((TOTAL_POINTS - COMPLETED * 2))
  IDEAL=$(echo "scale=2; $TOTAL_POINTS - $IDEAL_PER_DAY * $d" | bc)

  echo "$CURRENT_DATE,$REMAINING,$IDEAL"
done
```

### 12.2 生成可视化燃尽图描述

基于导出的数据，可以生成 SVG 或使用在线工具生成图表：

```
数据格式说明：
- 每行包含：日期, 剩余故事点, 理想剩余值
- 第一行为 Sprint 第一天，最后一行为 Sprint 最后一天
- 剩余故事点应逐步递减到0
- 理想线为从总故事点到0的直线

推荐图表工具：
1. 将CSV数据粘贴到 Google Sheets / Excel
2. 生成折线图，X轴为日期，Y轴为故事点
3. 添加理想线作为基准线
```

---

## 十三、Sprint 规划与回顾

### 13.1 Sprint 规划看板创建

```bash
#!/bin/bash
# sprint-planning.sh
# 创建新的 Sprint 看板并从 Backlog 拉取任务

SPRINT_NUMBER=$1
SPRINT_NAME="Sprint $SPRINT_NUMBER"
BACKLOG_BOARD_ID="{backlog_board_id}"

# 创建新 Sprint 看板
SPRINT_BOARD_ID=$(curl -s -X POST "https://api.trello.com/1/boards" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=$SPRINT_NAME" \
  -d "defaultLists=false" | jq -r '.id')

# 创建 Sprint 列表
for list in "🎯 Sprint Goal" "📋 User Stories" "🔄 In Progress" "👀 Review" "✅ Done"; do
  curl -s -X POST "https://api.trello.com/1/lists" \
    -d "key=$TRELLO_API_KEY" \
    -d "token=$TRELLO_TOKEN" \
    -d "name=$list" \
    -d "idBoard=$SPRINT_BOARD_ID" > /dev/null
done

# 创建 Sprint Goal 卡片
SPRINT_GOAL_LIST_ID=$(curl -s "https://api.trello.com/1/boards/$SPRINT_BOARD_ID/lists?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN" | jq -r '.[0].id')

curl -s -X POST "https://api.trello.com/1/cards" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "name=🎯 Sprint $SPRINT_NUMBER 目标" \
  -d "idList=$SPRINT_GOAL_LIST_ID" \
  -d "desc=在此描述本 Sprint 的主要目标和预期交付物" > /dev/null

echo "✅ Sprint $SPRINT_NUMBER 看板创建成功！Board ID: $SPRINT_BOARD_ID"
```

### 13.2 Sprint 回顾模板

在 Sprint 结束后，创建回顾会卡片模板：

```bash
#!/bin/bash
# create-retro-cards.sh
BOARD_ID="{sprint_board_id}"
RETRO_LIST_ID=$(curl -s "https://api.trello.com/1/boards/$BOARD_ID/lists?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&filter=open" | jq -r '.[-1].id')

# 创建回顾卡片
RETRO_ITEMS=(
  "👍 What went well?|团队协作顺畅，代码质量提高"
  "🔨 What could be improved?|需求变更导致进度延迟"
  "💡 Action Items|1. 加强需求评审 | 2. 建立代码审查规范"
  "📊 Sprint Metrics|Velocity: X points | 完成率: X%"
)

for item in "${RETRO_ITEMS[@]}"; do
  NAME="${item%%|*}"
  DESC="${item##*|}"

  curl -s -X POST "https://api.trello.com/1/cards" \
    -d "key=$TRELLO_API_KEY" \
    -d "token=$TRELLO_TOKEN" \
    -d "name=$NAME" \
    -d "idList=$RETRO_LIST_ID" \
    -d "desc=$DESC" > /dev/null
done

echo "✅ Sprint 回顾卡片已创建"
```

---

## 十四、评论与活动日志

### 14.1 添加卡片评论

```bash
curl -s -X POST "https://api.trello.com/1/cards/{card_id}/actions/comments" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "text=已完成初步代码审查，请查看 PR #42"
```

### 14.2 获取卡片活动日志

```bash
curl -s -X GET "https://api.trello.com/1/cards/{card_id}/actions?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&filter=createCard,updateCard,commentCard,moveCardToBoard,moveCardFromBoard&limit=20" | jq '.[] | {type: .type, date: .date, member: .memberCreator.fullName, data: .data}'
```

### 14.3 @提及成员

```bash
curl -s -X POST "https://api.trello.com/1/cards/{card_id}/actions/comments" \
  -d "key=$TRELLO_API_KEY" \
  -d "token=$TRELLO_TOKEN" \
  -d "text=@username 请审阅这个设计方案，截止日期是本周五。"
```

---

## 十五、高级查询与过滤

### 15.1 按标签过滤卡片

```bash
curl -s "https://api.trello.com/1/boards/{board_id}/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,id,due,idLabels&filter=open" \
  | jq '[.[] | select(.idLabels | contains(["{label_id}"]))]'
```

### 15.2 按成员过滤卡片

```bash
curl -s "https://api.trello.com/1/boards/{board_id}/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,id,idMembers,due&filter=open" \
  | jq '[.[] | select(.idMembers | contains(["{member_id}"]))]'
```

### 15.3 按日期范围过滤

```bash
curl -s "https://api.trello.com/1/boards/{board_id}/cards?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN&fields=name,id,due&filter=open" \
  | jq --arg start "2025-02-01T00:00:00.000Z" --arg end "2025-02-28T23:59:59.000Z" \
    '[.[] | select(.due != null and .due >= $start and .due <= $end)]'
```

---

## 十六、最佳实践与注意事项

### API 使用限制
- Trello API 限制：每10秒100个请求
- 对于批量操作，建议在请求之间添加适当延迟
- 使用 `?fields=` 参数减少不必要的数据传输

### 安全建议
- 不要将 API Key 和 Token 硬编码在脚本中
- 使用环境变量或配置文件管理凭证
- Token 应设置为适当的权限范围（最小权限原则）
- 定期轮换 API Token

### 数据管理
- 定期导出看板数据作为备份
- 归档已完成的项目看板而不是删除
- 使用一致的命名规范提高可搜索性

### 错误处理

所有 API 调用应检查 HTTP 状态码：

```bash
response=$(curl -s -w "\n%{http_code}" -X GET "https://api.trello.com/1/boards/{board_id}?key=$TRELLO_API_KEY&token=$TRELLO_TOKEN")
http_code=$(echo "$response" | tail -1)
body=$(echo "$response" | head -n -1)

if [ "$http_code" -ne 200 ]; then
  echo "❌ API 请求失败 (HTTP $http_code): $body"
  exit 1
fi

echo "$body" | jq '.'
```

---

## 快速参考表

| 操作 | HTTP 方法 | 端点 |
|------|-----------|------|
| 获取看板 | GET | `/1/members/me/boards` |
| 创建看板 | POST | `/1/boards` |
| 获取列表 | GET | `/1/boards/{id}/lists` |
| 创建列表 | POST | `/1/lists` |
| 获取卡片 | GET | `/1/lists/{id}/cards` |
| 创建卡片 | POST | `/1/cards` |
| 更新卡片 | PUT | `/1/cards/{id}` |
| 删除卡片 | DELETE | `/1/cards/{id}` |
| 创建标签 | POST | `/1/labels` |
| 创建清单 | POST | `/1/checklists` |
| 添加评论 | POST | `/1/cards/{id}/actions/comments` |
| 上传附件 | POST | `/1/cards/{id}/attachments` |
| 搜索 | GET | `/1/search` |
