/**
 * Lightweight Memory Bridge - 使用示例
 * 展示如何在Agent中集成记忆功能
 */

const { MemoryBridge } = require('./memory-core');

// 示例1：基础使用
async function basicExample() {
  console.log('=== 示例1: 基础使用 ===\n');

  const memory = new MemoryBridge({
    memory_dir: './example_memories',
    auto_save: true
  });

  // 保存用户偏好
  await memory.save({
    content: "用户偏好使用Python进行数据分析",
    tags: ["preference", "python", "data-analysis"],
    importance: "high"
  });

  // 保存项目信息
  await memory.save({
    content: "正在开发项目：ShopMaster电商平台",
    tags: ["project", "ShopMaster", "ecommerce"],
    importance: "high",
    context: {
      project_name: "ShopMaster",
      tech_stack: ["React", "Node.js", "PostgreSQL"]
    }
  });

  // 保存待办事项
  await memory.save({
    content: "待办：完成用户认证模块的API文档",
    tags: ["todo", "documentation", "ShopMaster"],
    importance: "medium",
    context: { due_date: "2024-02-01" }
  });

  console.log('✅ 已保存3条记忆\n');

  // 搜索记忆
  const results = await memory.search("Python");
  console.log(`🔍 搜索 "Python" 找到 ${results.length} 条结果:`);
  results.forEach(mem => console.log(`  - ${mem.content}`));

  // 获取最近记忆
  const recent = await memory.getRecent(5);
  console.log(`\n📚 最近 ${recent.length} 条记忆:`);
  recent.forEach(mem => console.log(`  - [${mem.importance}] ${mem.content}`));
}

// 示例2：标签管理
async function tagsExample() {
  console.log('\n\n=== 示例2: 标签管理 ===\n');

  const memory = new MemoryBridge({
    memory_dir: './example_memories'
  });

  // 保存不同标签的记忆
  await memory.save({
    content: "用户喜欢暗色主题",
    tags: ["preference", "ui", "theme"],
    importance: "medium"
  });

  await memory.save({
    content: "用户偏好使用VS Code",
    tags: ["preference", "editor"],
    importance: "low"
  });

  await memory.save({
    content: "项目使用Git进行版本控制",
    tags: ["decision", "tool"],
    importance: "medium"
  });

  // 按标签获取
  const preferences = await memory.getByTags(["preference"]);
  console.log('🏷️ 所有偏好设置:');
  preferences.forEach(mem => console.log(`  - ${mem.content}`));

  // 多标签匹配（any）
  const anyMatch = await memory.getByTags(["preference", "decision"], { match: 'any' });
  console.log(`\n🏷️ 偏好或决策 (${anyMatch.length}条):`);
  anyMatch.forEach(mem => console.log(`  - ${mem.content}`));
}

// 示例3：会话上下文恢复
async function sessionContextExample() {
  console.log('\n\n=== 示例3: 会话上下文恢复 ===\n');

  const memory = new MemoryBridge({
    memory_dir: './example_memories'
  });

  // 模拟：新会话开始时恢复上下文
  console.log('🔄 新会话开始，恢复相关上下文...\n');

  // 获取高优先级记忆
  const highPriority = await memory.getByTags(["high"], { limit: 5 });
  console.log('🔴 高优先级记忆:');
  highPriority.forEach(mem => console.log(`  - ${mem.content}`));

  // 搜索项目相关
  const projectMemories = await memory.search("ShopMaster", { limit: 5 });
  console.log('\n📁 项目相关记忆:');
  projectMemories.forEach(mem => console.log(`  - ${mem.content}`));

  // 获取待办事项
  const todos = await memory.getByTags(["todo"]);
  console.log('\n✅ 待办事项:');
  todos.forEach(mem => console.log(`  - ${mem.content}`));
}

// 示例4：智能保存策略
async function smartSaveExample() {
  console.log('\n\n=== 示例4: 智能保存策略 ===\n');

  // 配置：只自动保存high重要性的记忆
  const memory = new MemoryBridge({
    memory_dir: './example_memories',
    importance_threshold: 'high'
  });

  // 这条不会被自动保存（medium < high）
  const mem1 = await memory.save({
    content: "临时想法：可以尝试使用新库",
    tags: ["idea"],
    importance: "medium"
  });
  console.log(mem1 ? '✅ 已保存' : '⏭️ 跳过（重要性不足）', '- 临时想法');

  // 这条会被保存（high >= high）
  const mem2 = await memory.save({
    content: "重要决策：选择PostgreSQL作为数据库",
    tags: ["decision", "database"],
    importance: "high"
  });
  console.log(mem2 ? '✅ 已保存' : '⏭️ 跳过（重要性不足）', '- 数据库决策');
}

// 示例5：记忆管理
async function managementExample() {
  console.log('\n\n=== 示例5: 记忆管理 ===\n');

  const memory = new MemoryBridge({
    memory_dir: './example_memories'
  });

  // 显示统计
  const stats = await memory.getStats();
  console.log('📊 记忆统计:');
  console.log(`  总记忆数: ${stats.total_memories}`);
  console.log('  重要性分布:', stats.importance_distribution);
  console.log('  标签分布:', stats.tag_distribution);

  // 导出备份
  await memory.export('./memory_backup.json');
  console.log('\n💾 已导出备份到 memory_backup.json');

  // 清理旧记忆（演示，实际不执行）
  console.log('\n🧹 清理策略:');
  console.log('  使用 memory.cleanup(30) 清理30天前的记忆');
}

// 示例6：在Agent中的集成模式
async function agentIntegrationExample() {
  console.log('\n\n=== 示例6: Agent集成模式 ===\n');

  const memory = new MemoryBridge({
    memory_dir: './example_memories',
    auto_save: true,
    max_memories_per_session: 5
  });

  // 模拟Agent处理用户输入
  async function processUserInput(input) {
    console.log(`👤 用户: ${input}`);

    // 1. 搜索相关历史记忆
    const relevant = await memory.search(input, { limit: 3 });
    if (relevant.length > 0) {
      console.log('🧠 相关记忆:');
      relevant.forEach(m => console.log(`   - ${m.content}`));
    }

    // 2. 智能识别关键信息并保存
    if (input.includes('喜欢') || input.includes('偏好')) {
      await memory.save({
        content: input,
        tags: ["preference"],
        importance: "high"
      });
      console.log('💾 已保存偏好');
    }

    if (input.includes('项目') || input.includes('开发')) {
      await memory.save({
        content: input,
        tags: ["project"],
        importance: "high"
      });
      console.log('💾 已保存项目信息');
    }

    console.log('🤖 Agent: 处理完成\n');
  }

  // 模拟对话
  await processUserInput("我喜欢用React开发前端");
  await processUserInput("我正在做一个人工智能项目");
  await processUserInput("帮我写个Python脚本");
}

// 运行所有示例
async function runAllExamples() {
  console.log('🚀 Lightweight Memory Bridge - 使用示例\n');
  console.log('═'.repeat(60));

  try {
    await basicExample();
    await tagsExample();
    await sessionContextExample();
    await smartSaveExample();
    await managementExample();
    await agentIntegrationExample();

    console.log('\n' + '═'.repeat(60));
    console.log('\n✨ 所有示例运行完成!');
    console.log('\n提示: 查看 ./example_memories 目录中的记忆文件');
  } catch (err) {
    console.error('❌ 错误:', err.message);
  }
}

// 如果直接运行此文件
if (require.main === module) {
  runAllExamples();
}

module.exports = {
  basicExample,
  tagsExample,
  sessionContextExample,
  smartSaveExample,
  managementExample,
  agentIntegrationExample,
  runAllExamples
};
