# Lightweight Memory Bridge

轻量级跨会话记忆桥接技能 - 让Agent拥有跨会话记忆能力

## 快速开始

### 安装

1. 将技能文件复制到技能目录
2. 在 `openclaw.json` 中添加配置（参考 `openclaw.json.example`）

### 基础使用

```javascript
const { memory } = require('./scripts/memory-core');

// 保存记忆
await memory.save({
  content: "用户偏好使用Python",
  tags: ["preference", "python"],
  importance: "high"
});

// 搜索记忆
const results = await memory.search("Python");

// 获取最近记忆
const recent = await memory.getRecent(5);
```

### 命令行工具

```bash
# 列出记忆
node scripts/memory-manager.js list

# 搜索记忆
node scripts/memory-manager.js search "关键词"

# 添加记忆
node scripts/memory-manager.js add "记忆内容" --tags tag1,tag2

# 查看统计
node scripts/memory-manager.js stats
```

## 文件结构

```
lightweight-memory-bridge/
├── SKILL.md                    # 技能文档（主入口）
├── README.md                   # 本文件
├── openclaw.json.example       # 配置示例
└── scripts/
    ├── memory-core.js          # 核心API模块
    ├── memory-manager.js       # 命令行管理工具
    └── example-usage.js        # 使用示例
```

## 核心特性

- ✅ 自动保存关键对话
- ✅ 新会话自动恢复记忆
- ✅ 关键词搜索历史记忆
- ✅ 标签分类管理
- ✅ 重要性分级
- ✅ 命令行管理工具
- ✅ 配置简单，开箱即用

## 许可证

MIT
