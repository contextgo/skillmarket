/**
 * Lightweight Memory Bridge - Core Module
 * 轻量级跨会话记忆桥接核心模块
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

class MemoryBridge {
  constructor(config = {}) {
    this.config = {
      memory_dir: config.memory_dir || path.join(os.homedir(), '.stepclaw', 'memory_bridge'),
      auto_save: config.auto_save !== false,
      auto_load: config.auto_load !== false,
      max_memories_per_session: config.max_memories_per_session || 10,
      search_depth: config.search_depth || 30,
      importance_threshold: config.importance_threshold || 'medium',
      cleanup_after_days: config.cleanup_after_days || 90,
      ...config
    };
    
    this.memories = [];
    this.initialized = false;
  }

  /**
   * 初始化记忆系统
   */
  async init() {
    if (this.initialized) return;
    
    // 确保目录存在
    if (!fs.existsSync(this.config.memory_dir)) {
      fs.mkdirSync(this.config.memory_dir, { recursive: true });
    }
    
    // 加载现有记忆
    await this.loadAllMemories();
    
    this.initialized = true;
  }

  /**
   * 生成唯一ID
   */
  generateId(prefix = 'mem') {
    return `${prefix}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  /**
   * 获取记忆文件路径
   */
  getMemoryFilePath(date = new Date()) {
    const dateStr = date.toISOString().split('T')[0];
    return path.join(this.config.memory_dir, `memories_${dateStr}.json`);
  }

  /**
   * 加载所有记忆
   */
  async loadAllMemories() {
    this.memories = [];
    
    if (!fs.existsSync(this.config.memory_dir)) {
      return;
    }

    const files = fs.readdirSync(this.config.memory_dir)
      .filter(f => f.startsWith('memories_') && f.endsWith('.json'))
      .sort().reverse();

    // 只加载最近 search_depth 天的记忆
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - this.config.search_depth);

    for (const file of files) {
      const filePath = path.join(this.config.memory_dir, file);
      const fileDate = new Date(file.replace('memories_', '').replace('.json', ''));
      
      if (fileDate < cutoffDate) continue;
      
      try {
        const data = fs.readFileSync(filePath, 'utf8');
        const parsed = JSON.parse(data);
        if (parsed.memories && Array.isArray(parsed.memories)) {
          this.memories.push(...parsed.memories);
        }
      } catch (e) {
        console.error(`Error loading memory file ${file}:`, e.message);
      }
    }

    // 按时间倒序排列
    this.memories.sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
  }

  /**
   * 保存记忆到文件
   */
  async saveToFile(memory) {
    const filePath = this.getMemoryFilePath();
    let data = { memories: [] };

    if (fs.existsSync(filePath)) {
      try {
        const existing = fs.readFileSync(filePath, 'utf8');
        data = JSON.parse(existing);
      } catch (e) {
        console.error('Error reading existing memories:', e.message);
      }
    }

    data.memories.push(memory);
    
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2), 'utf8');
  }

  /**
   * 保存一条记忆
   */
  async save(data) {
    await this.init();

    const importanceLevels = { high: 3, medium: 2, low: 1 };
    const thresholdLevel = importanceLevels[this.config.importance_threshold] || 2;
    const dataLevel = importanceLevels[data.importance] || 2;

    // 如果重要性低于阈值，不自动保存
    if (dataLevel < thresholdLevel && this.config.auto_save) {
      return null;
    }

    const memory = {
      id: this.generateId(),
      content: data.content,
      tags: data.tags || [],
      importance: data.importance || 'medium',
      context: data.context || {},
      created_at: new Date().toISOString(),
      session_id: data.session_id || this.generateId('sess')
    };

    await this.saveToFile(memory);
    this.memories.unshift(memory);
    
    // 限制内存中的记忆数量
    if (this.memories.length > this.config.max_memories_per_session * 10) {
      this.memories = this.memories.slice(0, this.config.max_memories_per_session * 10);
    }

    return memory;
  }

  /**
   * 搜索记忆
   */
  async search(query, options = {}) {
    await this.init();

    const limit = options.limit || 10;
    const queryLower = query.toLowerCase();

    let results = this.memories.filter(mem => {
      // 内容匹配
      const contentMatch = mem.content.toLowerCase().includes(queryLower);
      
      // 标签匹配
      const tagMatch = mem.tags.some(tag => 
        tag.toLowerCase().includes(queryLower)
      );
      
      // 上下文匹配
      const contextMatch = JSON.stringify(mem.context)
        .toLowerCase()
        .includes(queryLower);

      return contentMatch || tagMatch || contextMatch;
    });

    // 按标签过滤
    if (options.tags && options.tags.length > 0) {
      results = results.filter(mem => 
        options.tags.some(tag => mem.tags.includes(tag))
      );
    }

    return results.slice(0, limit);
  }

  /**
   * 获取最近记忆
   */
  async getRecent(count, options = {}) {
    await this.init();

    let results = this.memories.slice(0, count);

    if (options.tags && options.tags.length > 0) {
      results = results.filter(mem => 
        options.tags.some(tag => mem.tags.includes(tag))
      );
    }

    return results;
  }

  /**
   * 按标签获取记忆
   */
  async getByTags(tags, options = {}) {
    await this.init();

    const match = options.match || 'any'; // 'all' 或 'any'
    const limit = options.limit || 10;

    let results = this.memories.filter(mem => {
      if (match === 'all') {
        return tags.every(tag => mem.tags.includes(tag));
      } else {
        return tags.some(tag => mem.tags.includes(tag));
      }
    });

    return results.slice(0, limit);
  }

  /**
   * 删除记忆
   */
  async delete(id) {
    await this.init();

    // 从内存中删除
    this.memories = this.memories.filter(mem => mem.id !== id);

    // 从文件中删除
    const filePath = this.getMemoryFilePath();
    if (fs.existsSync(filePath)) {
      try {
        const data = fs.readFileSync(filePath, 'utf8');
        const parsed = JSON.parse(data);
        parsed.memories = parsed.memories.filter(mem => mem.id !== id);
        fs.writeFileSync(filePath, JSON.stringify(parsed, null, 2), 'utf8');
        return true;
      } catch (e) {
        console.error('Error deleting memory:', e.message);
        return false;
      }
    }
    return false;
  }

  /**
   * 清空所有记忆
   */
  async clear() {
    this.memories = [];
    
    if (fs.existsSync(this.config.memory_dir)) {
      const files = fs.readdirSync(this.config.memory_dir)
        .filter(f => f.startsWith('memories_') && f.endsWith('.json'));
      
      for (const file of files) {
        fs.unlinkSync(path.join(this.config.memory_dir, file));
      }
    }
  }

  /**
   * 清理旧记忆
   */
  async cleanup(days = this.config.cleanup_after_days) {
    const cutoffDate = new Date();
    cutoffDate.setDate(cutoffDate.getDate() - days);

    if (!fs.existsSync(this.config.memory_dir)) return 0;

    const files = fs.readdirSync(this.config.memory_dir)
      .filter(f => f.startsWith('memories_') && f.endsWith('.json'));

    let deletedCount = 0;
    for (const file of files) {
      const fileDate = new Date(file.replace('memories_', '').replace('.json', ''));
      if (fileDate < cutoffDate) {
        fs.unlinkSync(path.join(this.config.memory_dir, file));
        deletedCount++;
      }
    }

    // 重新加载记忆
    await this.loadAllMemories();
    
    return deletedCount;
  }

  /**
   * 导出所有记忆
   */
  async export(outputPath) {
    await this.init();

    const exportData = {
      export_date: new Date().toISOString(),
      total_memories: this.memories.length,
      memories: this.memories
    };

    fs.writeFileSync(outputPath, JSON.stringify(exportData, null, 2), 'utf8');
    return exportData;
  }

  /**
   * 获取统计信息
   */
  async getStats() {
    await this.init();

    const tagCounts = {};
    const importanceCounts = { high: 0, medium: 0, low: 0 };

    this.memories.forEach(mem => {
      mem.tags.forEach(tag => {
        tagCounts[tag] = (tagCounts[tag] || 0) + 1;
      });
      importanceCounts[mem.importance] = (importanceCounts[mem.importance] || 0) + 1;
    });

    return {
      total_memories: this.memories.length,
      tag_distribution: tagCounts,
      importance_distribution: importanceCounts,
      date_range: this.memories.length > 0 ? {
        oldest: this.memories[this.memories.length - 1]?.created_at,
        newest: this.memories[0]?.created_at
      } : null
    };
  }
}

// 导出单例实例
let instance = null;

function getMemoryBridge(config) {
  if (!instance) {
    instance = new MemoryBridge(config);
  }
  return instance;
}

module.exports = {
  MemoryBridge,
  getMemoryBridge,
  memory: getMemoryBridge()
};
