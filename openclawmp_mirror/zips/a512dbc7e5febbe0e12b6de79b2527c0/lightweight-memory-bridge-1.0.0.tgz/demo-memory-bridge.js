/**
 * Lightweight Memory Bridge - 使用演示
 * 
 * 这个脚本演示了如何使用轻量级跨会话记忆桥
 */

const { memory } = require('./memory-core');

async function demo() {
  console.log('🚀 Lightweight Memory Bridge 演示\n');

  // 1. 保存用户偏好
  console.log('1️⃣ 保存用户偏好');
  await memory.save({
    content: "用户偏好使用Python进行数据分析",
    tags: ["preference", "python", "data-analysis"],
    importance: "high"
  });
  console.log('✅ 已保存：Python偏好\n');

  // 2. 保存项目信息
  console.log('2️⃣ 保存项目信息');
  await memory.save({
    content: "正在开发电商网站，使用React+Node.js",
    tags: ["project", "ecommerce", "react", "nodejs"],
    importance: "high",
    context: { project_name: "my-shop", deadline: "2026-04-30" }
  });
  console.log('✅ 已保存：项目信息\n');

  // 3. 保存待办事项
  console.log('3️⃣ 保存待办事项');
  await memory.save({
    content: "记得优化数据库查询性能",
    tags: ["todo", "database", "optimization"],
    importance: "medium"
  });
  console.log('✅ 已保存：待办事项\n');

  // 4. 搜索记忆
  console.log('4️⃣ 搜索记忆 - 关键词：Python');
  const pythonResults = await memory.search("Python");
  console.log(`找到 ${pythonResults.length} 条相关记忆：`);
  pythonResults.forEach((m, i) => {
    console.log(`  ${i + 1}. ${m.content}`);
  });
  console.log();

  // 5. 按标签搜索
  console.log('5️⃣ 按标签搜索 - 标签：project');
  const projectResults = await memory.getByTags(["project"]);
  console.log(`找到 ${projectResults.length} 条项目相关记忆：`);
  projectResults.forEach((m, i) => {
    console.log(`  ${i + 1}. ${m.content}`);
  });
  console.log();

  // 6. 获取最近记忆
  console.log('6️⃣ 获取最近3条记忆');
  const recent = await memory.getRecent(3);
  console.log('最近记忆：');
  recent.forEach((m, i) => {
    console.log(`  ${i + 1}. [${m.tags.join(', ')}] ${m.content}`);
  });
  console.log();

  // 7. 搜索待办
  console.log('7️⃣ 搜索待办事项');
  const todos = await memory.getByTags(["todo"]);
  console.log(`找到 ${todos.length} 条待办：`);
  todos.forEach((m, i) => {
    console.log(`  ☐ ${m.content}`);
  });

  console.log('\n✨ 演示完成！');
  console.log('💡 下次对话时，这些记忆会自动恢复');
}

// 运行演示
demo().catch(console.error);
