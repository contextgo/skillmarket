---
name: lightweight-memory-bridge
description: 轻量级跨会话记忆桥接技能，解决Agent跨会话记忆连续性问题。自动保存关键对话内容到本地memory文件，新会话自动读取相关记忆，支持关键词搜索历史记忆。配置简单，开箱即用。当用户需要记忆跨会话信息、恢复对话上下文、搜索历史记忆或管理长期记忆时使用此技能。
---

# Lightweight Memory Bridge - 轻量级跨会话记忆桥接

一个简单、轻量、开箱即用的跨会话记忆解决方案，让Agent能够记住跨会话的重要信息。

## 核心特性

- **自动保存**：智能识别并保存关键对话内容
- **自动恢复**：新会话自动加载相关记忆
- **关键词搜索**：快速检索历史记忆
- **轻量配置**：最少配置，最大效用
- **本地存储**：数据完全本地，隐私安全

## 快速开始

### 1. 配置记忆目录

在 `openclaw.json` 中添加配置：

```json
{
  "memory_bridge": {
    "memory_dir": "~/.stepclaw/memory_bridge",
    "auto_save": true,
    "max_memories_per_session": 10,
    "search_depth": 30
  }
}
```

### 2. 使用记忆功能

```javascript
// 保存记忆
await memory.save({
  content: "用户偏好使用Python进行数据分析",
  tags: ["preference", "python"],
  importance: "high"
});

// 搜索记忆
const memories = await memory.search("Python");

// 获取最近记忆
const recent = await memory.getRecent(5);
```

## API 参考

### memory.save(data)

保存一条记忆。

**参数：**
- `content` (string): 记忆内容
- `tags` (string[]): 标签数组，用于分类和搜索
- `importance` (string): 重要性级别 - "high" | "medium" | "low"
- `context` (object): 可选的上下文信息

**示例：**
```javascript
await memory.save({
  content: "用户正在开发一个电商网站",
  tags: ["project", "ecommerce"],
  importance: "high",
  context: { project_name: "my-shop" }
});
```

### memory.search(query, options)

搜索历史记忆。

**参数：**
- `query` (string): 搜索关键词
- `options.limit` (number): 返回结果数量限制，默认10
- `options.tags` (string[]): 按标签过滤

**返回：**
匹配的记忆数组，按相关性和时间排序。

**示例：**
```javascript
const results = await memory.search("电商", { limit: 5 });
```

### memory.getRecent(count, options)

获取最近的记忆。

**参数：**
- `count` (number): 获取数量
- `options.tags` (string[]): 按标签过滤

**示例：**
```javascript
const recent = await memory.getRecent(10, { tags: ["preference"] });
```

### memory.getByTags(tags, options)

按标签获取记忆。

**参数：**
- `tags` (string[]): 标签数组
- `options.match` (string): 匹配模式 - "all" | "any"，默认"any"
- `options.limit` (number): 返回数量限制

**示例：**
```javascript
const prefs = await memory.getByTags(["preference", "setting"]);
```

### memory.delete(id)

删除指定记忆。

**参数：**
- `id` (string): 记忆ID

### memory.clear()

清空所有记忆（谨慎使用）。

## 自动保存策略

技能会自动识别以下类型的关键信息并保存：

1. **用户偏好**：编程语言、工具偏好、风格选择
2. **项目信息**：项目名称、技术栈、架构决策
3. **重要决策**：方案选择、配置决定
4. **待办事项**：明确的任务和截止日期
5. **关键上下文**：会话中明确标记为"记住"的信息

## 配置选项

在 `openclaw.json` 中配置：

```json
{
  "memory_bridge": {
    "memory_dir": "~/.stepclaw/memory_bridge",
    "auto_save": true,
    "auto_load": true,
    "max_memories_per_session": 10,
    "search_depth": 30,
    "importance_threshold": "medium",
    "cleanup_after_days": 90
  }
}
```

**配置说明：**

| 选项 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `memory_dir` | string | `~/.stepclaw/memory_bridge` | 记忆文件存储目录 |
| `auto_save` | boolean | true | 是否自动保存关键信息 |
| `auto_load` | boolean | true | 新会话是否自动加载相关记忆 |
| `max_memories_per_session` | number | 10 | 每会话自动加载的最大记忆数 |
| `search_depth` | number | 30 | 搜索时检查的记忆天数 |
| `importance_threshold` | string | "medium" | 自动保存的重要性阈值 |
| `cleanup_after_days` | number | 90 | 自动清理多少天前的旧记忆 |

## 存储格式

记忆以JSON格式存储，每个会话一个文件：

```json
{
  "memories": [
    {
      "id": "mem_1234567890",
      "content": "用户偏好使用Python",
      "tags": ["preference", "python"],
      "importance": "high",
      "created_at": "2024-01-15T10:30:00Z",
      "session_id": "sess_abc123",
      "context": {}
    }
  ]
}
```

## 使用场景示例

### 场景1：记住用户偏好

```javascript
// 用户说："我喜欢用Python做数据分析"
await memory.save({
  content: "用户偏好使用Python进行数据分析",
  tags: ["preference", "python", "data-analysis"],
  importance: "high"
});

// 下次会话自动加载，Agent知道用户喜欢Python
```

### 场景2：项目上下文保持

```javascript
// 用户说："我正在开发一个叫ShopMaster的电商项目"
await memory.save({
  content: "用户正在开发项目：ShopMaster（电商平台）",
  tags: ["project", "ShopMaster", "ecommerce"],
  importance: "high",
  context: { project_name: "ShopMaster", type: "ecommerce" }
});

// 下次会话搜索"ShopMaster"即可恢复上下文
const context = await memory.search("ShopMaster");
```

### 场景3：待办事项追踪

```javascript
// 用户说："记得提醒我下周完成API文档"
await memory.save({
  content: "待办：完成API文档",
  tags: ["todo", "documentation"],
  importance: "high",
  context: { due_date: "2024-01-22", task: "完成API文档" }
});

// 搜索待办
const todos = await memory.getByTags(["todo"]);
```

### 场景4：技术决策记录

```javascript
// 用户说："我们决定用PostgreSQL而不是MySQL"
await memory.save({
  content: "技术决策：使用PostgreSQL作为数据库（而非MySQL）",
  tags: ["decision", "database", "postgresql"],
  importance: "high",
  context: { 
    decision: "选择PostgreSQL",
    alternatives: ["MySQL"],
    reason: "更好的JSON支持和扩展性"
  }
});
```

## 最佳实践

1. **标签规范化**：使用一致的标签命名，如 `preference`, `project`, `todo`, `decision`
2. **重要性分级**：
   - `high`: 关键偏好、重要决策、项目信息
   - `medium`: 一般上下文、临时信息
   - `low`: 可丢弃的临时记忆
3. **定期清理**：设置 `cleanup_after_days` 自动清理旧记忆
4. **上下文完整**：保存时提供足够的上下文信息，便于后续检索

## 故障排除

### 记忆未自动加载
- 检查 `auto_load` 配置是否为 `true`
- 确认记忆文件存在于配置的目录中
- 检查 `importance_threshold` 设置

### 搜索无结果
- 扩大 `search_depth` 配置
- 检查标签是否匹配
- 使用更通用的关键词

### 存储空间问题
- 减小 `cleanup_after_days` 自动清理旧记忆
- 手动调用 `memory.clear()` 清理（谨慎）
- 检查 `max_memories_per_session` 设置

## 脚本工具

技能包含以下辅助脚本：

### scripts/memory-manager.js

记忆管理工具，提供命令行操作：

```bash
# 列出所有记忆
node scripts/memory-manager.js list

# 搜索记忆
node scripts/memory-manager.js search "关键词"

# 按标签过滤
node scripts/memory-manager.js tags preference

# 清理旧记忆
node scripts/memory-manager.js cleanup --days 30

# 导出记忆
node scripts/memory-manager.js export --output backup.json
```

## 与其他记忆方案对比

| 特性 | 本方案 | 三层记忆系统 | 语义记忆搜索 |
|------|--------|--------------|--------------|
| 配置复杂度 | ⭐ 极简 | ⭐⭐⭐ 复杂 | ⭐⭐⭐ 复杂 |
| 学习成本 | ⭐ 低 | ⭐⭐⭐ 高 | ⭐⭐⭐ 高 |
| 自动保存 | ✅ 支持 | ✅ 支持 | ✅ 支持 |
| 语义搜索 | ❌ 关键词 | ✅ 向量搜索 | ✅ 向量搜索 |
| 存储位置 | 本地文件 | 本地/云端 | 本地/云端 |
| 适用场景 | 日常助手 | 复杂Agent | 知识库 |

**本方案优势**：简单、轻量、开箱即用，适合大多数日常场景。
