#!/usr/bin/env node
/**
 * Lightweight Memory Bridge - CLI Manager
 * 命令行记忆管理工具
 */

const fs = require('fs');
const path = require('path');
const os = require('os');

// 加载核心模块
const { MemoryBridge } = require('./memory-core');

// 读取配置
function loadConfig() {
  const configPaths = [
    path.join(os.homedir(), '.stepclaw', 'openclaw.json'),
    path.join(process.cwd(), 'openclaw.json'),
  ];

  for (const configPath of configPaths) {
    if (fs.existsSync(configPath)) {
      try {
        const config = JSON.parse(fs.readFileSync(configPath, 'utf8'));
        if (config.memory_bridge) {
          return config.memory_bridge;
        }
      } catch (e) {
        // 继续尝试下一个配置
      }
    }
  }

  return {};
}

// 格式化日期
function formatDate(isoString) {
  const date = new Date(isoString);
  return date.toLocaleString('zh-CN');
}

// 格式化重要性
function formatImportance(level) {
  const colors = {
    high: '\x1b[31m',    // 红色
    medium: '\x1b[33m',  // 黄色
    low: '\x1b[32m',     // 绿色
    reset: '\x1b[0m'
  };
  const symbols = { high: '🔴', medium: '🟡', low: '🟢' };
  return `${colors[level]}${symbols[level]} ${level}${colors.reset}`;
}

// 命令：列出记忆
async function listMemories(memory, args) {
  const limit = parseInt(args.limit) || 20;
  const memories = await memory.getRecent(limit);

  if (memories.length === 0) {
    console.log('📭 没有找到记忆');
    return;
  }

  console.log(`\n📚 最近 ${memories.length} 条记忆:\n`);
  console.log('─'.repeat(80));

  memories.forEach((mem, index) => {
    console.log(`\n[${index + 1}] ${formatImportance(mem.importance)} | ${formatDate(mem.created_at)}`);
    console.log(`    📝 ${mem.content}`);
    if (mem.tags.length > 0) {
      console.log(`    🏷️  ${mem.tags.join(', ')}`);
    }
    console.log(`    🆔 ${mem.id}`);
  });

  console.log('\n' + '─'.repeat(80));
}

// 命令：搜索记忆
async function searchMemories(memory, args) {
  const query = args._[1];
  if (!query) {
    console.error('❌ 请提供搜索关键词');
    console.log('用法: memory-manager.js search <关键词> [--limit 10]');
    process.exit(1);
  }

  const limit = parseInt(args.limit) || 10;
  const results = await memory.search(query, { limit });

  if (results.length === 0) {
    console.log(`🔍 没有找到包含 "${query}" 的记忆`);
    return;
  }

  console.log(`\n🔍 找到 ${results.length} 条包含 "${query}" 的记忆:\n`);
  console.log('─'.repeat(80));

  results.forEach((mem, index) => {
    console.log(`\n[${index + 1}] ${formatImportance(mem.importance)} | ${formatDate(mem.created_at)}`);
    console.log(`    📝 ${mem.content}`);
    if (mem.tags.length > 0) {
      console.log(`    🏷️  ${mem.tags.join(', ')}`);
    }
  });

  console.log('\n' + '─'.repeat(80));
}

// 命令：按标签查看
async function listByTags(memory, args) {
  const tags = args._[1];
  if (!tags) {
    console.error('❌ 请提供标签');
    console.log('用法: memory-manager.js tags <标签1,标签2,...> [--match all|any]');
    process.exit(1);
  }

  const tagList = tags.split(',').map(t => t.trim());
  const match = args.match || 'any';
  const results = await memory.getByTags(tagList, { match });

  if (results.length === 0) {
    console.log(`🏷️ 没有找到标签为 "${tags}" 的记忆`);
    return;
  }

  console.log(`\n🏷️ 标签 "${tags}" (${match} 匹配) 的 ${results.length} 条记忆:\n`);
  console.log('─'.repeat(80));

  results.forEach((mem, index) => {
    console.log(`\n[${index + 1}] ${formatImportance(mem.importance)} | ${formatDate(mem.created_at)}`);
    console.log(`    📝 ${mem.content}`);
    console.log(`    🏷️  ${mem.tags.join(', ')}`);
  });

  console.log('\n' + '─'.repeat(80));
}

// 命令：添加记忆
async function addMemory(memory, args) {
  const content = args._[1];
  if (!content) {
    console.error('❌ 请提供记忆内容');
    console.log('用法: memory-manager.js add "记忆内容" [--tags tag1,tag2] [--importance high|medium|low]');
    process.exit(1);
  }

  const tags = args.tags ? args.tags.split(',').map(t => t.trim()) : [];
  const importance = args.importance || 'medium';

  const mem = await memory.save({
    content,
    tags,
    importance
  });

  if (mem) {
    console.log('✅ 记忆已保存');
    console.log(`   📝 ${mem.content}`);
    console.log(`   🏷️  ${mem.tags.join(', ')}`);
    console.log(`   🆔 ${mem.id}`);
  } else {
    console.log('⚠️ 记忆未保存（重要性低于阈值）');
  }
}

// 命令：删除记忆
async function deleteMemory(memory, args) {
  const id = args._[1];
  if (!id) {
    console.error('❌ 请提供记忆ID');
    console.log('用法: memory-manager.js delete <记忆ID>');
    process.exit(1);
  }

  const success = await memory.delete(id);
  if (success) {
    console.log('✅ 记忆已删除');
  } else {
    console.log('❌ 删除失败，请检查ID是否正确');
  }
}

// 命令：清理旧记忆
async function cleanupMemories(memory, args) {
  const days = parseInt(args.days) || 30;
  const deletedCount = await memory.cleanup(days);
  console.log(`🧹 已清理 ${deletedCount} 个旧记忆文件（${days}天前）`);
}

// 命令：导出记忆
async function exportMemories(memory, args) {
  const output = args.output || `memory_backup_${new Date().toISOString().split('T')[0]}.json`;
  const data = await memory.export(output);
  console.log(`💾 已导出 ${data.total_memories} 条记忆到: ${output}`);
}

// 命令：显示统计
async function showStats(memory) {
  const stats = await memory.getStats();

  console.log('\n📊 记忆统计\n');
  console.log('═'.repeat(50));
  console.log(`总记忆数: ${stats.total_memories}`);
  
  if (stats.date_range) {
    console.log(`\n时间范围:`);
    console.log(`  最早: ${formatDate(stats.date_range.oldest)}`);
    console.log(`  最新: ${formatDate(stats.date_range.newest)}`);
  }

  console.log(`\n重要性分布:`);
  Object.entries(stats.importance_distribution).forEach(([level, count]) => {
    const bar = '█'.repeat(Math.min(count, 20));
    console.log(`  ${level.padEnd(6)}: ${bar} ${count}`);
  });

  if (Object.keys(stats.tag_distribution).length > 0) {
    console.log(`\n标签分布:`);
    const sortedTags = Object.entries(stats.tag_distribution)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10);
    sortedTags.forEach(([tag, count]) => {
      console.log(`  ${tag}: ${count}`);
    });
  }

  console.log('═'.repeat(50));
}

// 命令：显示帮助
function showHelp() {
  console.log(`
📚 Lightweight Memory Bridge - 命令行管理工具

用法: memory-manager.js <命令> [选项]

命令:
  list              列出最近记忆
  search <关键词>   搜索记忆
  tags <标签>       按标签查看记忆
  add <内容>        添加新记忆
  delete <ID>       删除指定记忆
  cleanup           清理旧记忆
  export            导出记忆到文件
  stats             显示统计信息
  help              显示帮助

选项:
  --limit <n>       限制结果数量 (默认: 10/20)
  --tags <t1,t2>    指定标签 (用于add命令)
  --importance <l>  重要性级别: high/medium/low (默认: medium)
  --match <mode>    标签匹配模式: all/any (默认: any)
  --days <n>        清理/搜索天数 (默认: 30)
  --output <path>   导出文件路径

示例:
  memory-manager.js list --limit 10
  memory-manager.js search "Python" --limit 5
  memory-manager.js tags preference --match any
  memory-manager.js add "用户喜欢Vue" --tags preference,frontend --importance high
  memory-manager.js cleanup --days 30
  memory-manager.js export --output backup.json
`);
}

// 解析参数
function parseArgs() {
  const args = { _: [] };
  for (let i = 2; i < process.argv.length; i++) {
    const arg = process.argv[i];
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const value = process.argv[i + 1] && !process.argv[i + 1].startsWith('--') 
        ? process.argv[++i] 
        : true;
      args[key] = value;
    } else {
      args._.push(arg);
    }
  }
  return args;
}

// 主函数
async function main() {
  const args = parseArgs();
  const command = args._[0] || 'help';

  // 加载配置
  const config = loadConfig();
  const memory = new MemoryBridge(config);
  await memory.init();

  switch (command) {
    case 'list':
    case 'ls':
      await listMemories(memory, args);
      break;
    case 'search':
    case 'find':
      await searchMemories(memory, args);
      break;
    case 'tags':
    case 'tag':
      await listByTags(memory, args);
      break;
    case 'add':
    case 'create':
      await addMemory(memory, args);
      break;
    case 'delete':
    case 'del':
    case 'rm':
      await deleteMemory(memory, args);
      break;
    case 'cleanup':
    case 'clean':
      await cleanupMemories(memory, args);
      break;
    case 'export':
    case 'backup':
      await exportMemories(memory, args);
      break;
    case 'stats':
    case 'stat':
      await showStats(memory);
      break;
    case 'help':
    case '-h':
    case '--help':
    default:
      showHelp();
      break;
  }
}

main().catch(err => {
  console.error('❌ 错误:', err.message);
  process.exit(1);
});
