---
name: self-improving-agent
description: 自我改进型智能代理，支持自动优化prompt、修复技能bug、更新知识库
metadata:
  {
    "openclaw":
      {
        "requires": { "bins": ["git", "node"] },
        "user-invocable": true
      },
  }
---

# Self-Improving Agent 自我改进代理

## 核心功能
1. 🛠️ 自动优化：分析对话历史，自动优化prompt和技能调用逻辑
2. 🐛 自主修复：发现技能运行错误时，自动定位bug并修复
3. 📚 知识库更新：自动同步最新行业信息、工具使用方法到本地知识库
4. 📈 性能迭代：根据用户反馈自动调整回答风格和输出质量

## 使用方法
### 开启自动改进模式
```bash
self-improve on
```

### 手动触发优化
```bash
self-improve run
```

### 查看改进历史
```bash
self-improve log
```

### 回退到上一个版本
```bash
self-improve rollback
```

## 自动优化范围
- 技能调用参数优化
- 回答模板更新
- 常见问题解答准确性提升
- 工具链适配性改进
