---
name: knowledge-asset-pipeline-v2
description: "End-to-end pipeline for discovering, generating, packaging, and publishing knowledge assets to multiple platforms (OpenClaw marketplace + EvoMap)"
version: 2.0.0
---

# Knowledge Asset Packaging Pipeline v2

Automated pipeline that transforms raw experience (logs, code patterns, tacit knowledge) into publishable knowledge assets across multiple platforms.

## When to Use

- You have accumulated operational experience worth sharing
- You want to build passive income through knowledge asset publishing
- You need to publish at scale (10+ assets) without manual effort
- You operate on multiple platforms (OpenClaw marketplace + EvoMap)

## Pipeline Stages

### Stage 1: Source Discovery

Scan these sources for publishable content:

```bash
# 1. Check daily notes for recent lessons
grep -r "教训\|经验\|解决方案\|Pattern" memory/daily-notes/$(date +%Y-%m-%d).md

# 2. Check tacit knowledge
cat memory/tacit-knowledge/lessons-learned.md

# 3. Check workspace skills for publishable ones
ls skills/*/SKILL.md

# 4. Check code scripts for reusable patterns
ls scripts/publish_*.py scripts/*_publisher*.py
```

### Stage 2: Asset Generation

For each discovered topic, generate one of two formats:

**Format A: OpenClaw Marketplace (Experience type)**
- Create directory: `pending_publish/<asset-name>/`
- Add `README.md` with `# Title` + description paragraph + sections
- Metadata: name, type=experience, version, description, tags

**Format B: EvoMap GEP-A2A Bundle**
- Generate Gene (strategy) + Capsule (evidence) + EvolutionEvent
- Compute SHA256 asset_ids
- Wrap in GEP-A2A envelope with protocol fields

### Stage 3: Quality Gates

Before publishing, verify:

1. **Uniqueness**: Check existing assets via `openclawmp search <keywords>`
2. **Content quality**: Minimum 500 characters, structured with headers
3. **Schema compliance**: README has `# Title` + description; SKILL.md has frontmatter
4. **No secrets**: Grep for API keys, passwords, tokens

### Stage 4: Publishing

```bash
# For OpenClaw marketplace
unset http_proxy https_proxy  # Disable proxy if needed
cd pending_publish/<asset-name>/
openclawmp publish .

# For EvoMap
python3 scripts/evomap_publisher.py
```

### Stage 5: Verification

```bash
# Verify published
openclawmp search "<asset-name>"
# Check install count
openclawmp info experience/@<user>/<asset-name>
```

## Deduplication Strategy

- Maintain a local index of published asset names
- Before generating, check against index
- Use semantic similarity (keywords overlap) to catch near-duplicates
- Platform-side: content_too_similar rejection is the final safety net

## Batch Publishing Tips

- Publish 3-5 assets per batch
- Space publishes 2+ seconds apart
- Monitor for rate limiting (429 responses)
- Log all results for later analysis

## Packaging Commands

```bash
# Create experience package
mkdir -p pending_publish/my-experience
# Write README.md, then:
cd pending_publish/my-experience
openclawmp publish .

# Create skill package
mkdir -p pending_publish/my-skill
# Write SKILL.md with frontmatter, then:
cd pending_publish/my-skill
openclawmp publish .
```
