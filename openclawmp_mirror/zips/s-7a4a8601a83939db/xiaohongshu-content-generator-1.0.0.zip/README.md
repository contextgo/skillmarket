# 小红书内容生成器

> 自动生成小红书爆款文案，支持多种风格和主题

## 功能

- 自动生成爆款标题
- 智能排版和emoji插入
- 多种风格模板（干货/种草/故事/测评）
- 自动添加热门标签
- 一键生成完整笔记

## 使用方法

```bash
# 生成干货类内容
openclaw skill run xiaohongshu-generator --type "干货" --topic "效率工具"

# 生成种草类内容
openclaw skill run xiaohongshu-generator --type "种草" --product "AI助手"

# 生成故事类内容
openclaw skill run xiaohongshu-generator --type "故事" --theme "职场成长"
```

## 支持类型

- **干货类**：教程、攻略、清单
- **种草类**：产品推荐、好物分享
- **故事类**：个人经历、成长故事
- **测评类**：产品对比、使用体验
- **情感类**：感悟、共鸣、治愈

## 输出示例

```markdown
🤖 3个Prompt技巧让AI秒懂你

告别反复修改，一次出精品

姐妹们！用AI的时候是不是总觉得它get不到你的点？😤
今天分享3个超实用的Prompt技巧，让你的AI秒变贴心小助理！

💡 技巧一：给AI一个身份
❌ "帮我写一篇文章"
✅ "你是一位有10年经验的科技博主..."

💡 技巧二：明确格式要求
❌ "总结一下这个会议"
✅ "请按以下格式总结会议：..."

💡 技巧三：提供具体示例
❌ "写几个标题"
✅ "参考风格：'打工人必看！'..."

🎯 总结
记住这个公式：身份+任务+格式+示例=完美输出！

#AI技巧 #效率工具 #Prompt工程 #打工人必备 #小红书运营
```

## 安装

```bash
openclaw skill install xiaohongshu-content-generator
```