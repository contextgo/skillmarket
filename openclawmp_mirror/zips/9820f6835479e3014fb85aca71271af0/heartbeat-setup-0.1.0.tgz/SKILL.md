---
name: heartbeat-setup
description: OpenClaw 心跳配置与故障排查。当用户说"心跳没反应"、"heartbeat不工作"、"设置心跳"时使用。
version: 0.1.0
tags: [heartbeat, gateway, cron, telegram, 自动化]
---

# Heartbeat Setup & Troubleshooting

OpenClaw 心跳（Heartbeat）配置指南，基于实际踩坑经验整理。

## 快速配置

编辑 `~/.openclaw/openclaw.json`：

```json5
{
  agents: {
    defaults: {
      heartbeat: {
        every: "30m",                    // 间隔
        target: "telegram",              // 投递频道
        to: "TELEGRAM_USER_ID",          // ⚠️ 必须！不写不投递
        directPolicy: "allow",           // 允许私聊投递
        lightContext: true,              // 轻量上下文，省 token
        activeHours: {
          start: "08:00",
          end: "23:30",
          timezone: "Asia/Shanghai"
        }
      }
    }
  },
  channels: {
    telegram: {
      heartbeat: {
        showOk: true,      // 显示 HEARTBEAT_OK 确认
        showAlerts: true,  // 显示警报内容
        useIndicator: true // 发送状态指示
      }
    }
  }
}
```

## ⚠️ 关键踩坑点

### 1. `to` 字段必须填写
- `target: "telegram"` 只指定了频道，**没指定收件人不会投递**
- 必须加上 `to: "YOUR_CHAT_ID"`（纯数字）
- 获取方式：`openclaw status` 或查看 `~/.openclaw/agents/main/sessions/sessions.json`

### 2. `target` 的正确值
- `"last"` → 投递到最后使用的频道（可能不是你要的）
- `"telegram"` → 投递到 Telegram（需要 `to` 指定收件人）
- `"none"` → 只运行不投递（默认值！）

### 3. `showOk` 默认为 false
- Telegram 频道的 `showOk` 默认关闭
- HEARTBEAT_OK 回复会被静默丢弃
- 想看到确认信息必须设为 `true`

### 4. 心跳不会 tick 的常见原因
- **活跃时段外**：`activeHours` 限制了运行时间
- **session 繁忙**：主会话正在处理其他消息时跳过
- **target=none**：默认值，运行但不投递
- **HEARTBEAT.md 为空**：只有标题会被跳过

### 5. 热加载 vs 重启
- 修改 `openclaw.json` 后 gateway 自动热加载大部分配置
- 但 `agents.list[].heartbeat` 可能需要重启
- 确认方式：`grep "hot reload" /tmp/openclaw/openclaw-*.log`

## 验证步骤

```bash
# 1. 确认心跳已启动
openclaw status | grep heartbeat
# 应显示：Heartbeat: 30m (main)

# 2. 检查日志
grep "heartbeat" /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | \
  python3 -c "
import sys, json
for line in sys.stdin:
    try:
        d = json.loads(line.strip())
        msg = str(d.get('1','')) + ' ' + str(d.get('2',''))
        if 'heartbeat' in msg.lower() and 'feishu' not in msg:
            print(d.get('time','')[:19], msg[:100])
    except: pass
"

# 3. 确认配置已热加载
openclaw logs 2>&1 | grep "hot reload"

# 4. 手动触发测试（可能不生效，仅供参考）
openclaw system event --text "测试心跳" --mode now
```

## 常见问题

| 现象 | 原因 | 解决 |
|------|------|------|
| 有 started 无 tick | session 繁忙 / 活跃时段外 | 等待空闲 / 调整 activeHours |
| 有 tick 无 Telegram | 缺 `to` 字段 / `showOk=false` | 添加 `to` / 设置 `showOk: true` |
| 有 tick 无内容 | HEARTBEAT.md 为空 | 添加实际内容 |
| 配置不生效 | 需要重启 | `openclaw gateway restart` |

## HEARTBEAT.md 示例

```markdown
# HEARTBEAT.md

- 检查邮箱是否有重要邮件
- 检查日历是否有即将到期的事项（2小时内）
- 检查待办任务列表临近截止日期的任务
- 如有重要事项，汇报给用户
- 如无，回复 HEARTBEAT_OK
```

---
*Created: 2026-03-17 | 基于实际调试经验*
