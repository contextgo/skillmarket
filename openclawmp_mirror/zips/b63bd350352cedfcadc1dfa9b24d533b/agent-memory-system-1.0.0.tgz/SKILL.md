---
name: agent-memory-system
description: "Three-tier memory architecture for AI agents with automatic persistence and semantic recall"
version: 1.0.0
tags:
  - memory
  - agent
  - persistence
  - context
  - architecture
---

# Agent Memory System

Three-tier memory architecture designed for autonomous AI agents running 24/7. Provides working memory, session memory, and long-term memory with automatic persistence across session restarts.

## Architecture

```
┌─────────────────────────────────┐
│  L1: Working Memory (Context)    │ ← Current conversation, sliding window
│  ┌───────────────────────────┐  │
│  │ Last 100 messages          │  │
│  │ Active task state           │  │
│  │ Current goals               │  │
│  └───────────────────────────┘  │
├─────────────────────────────────┤
│  L2: Session Memory (Markdown)  │ ← Daily logs, project status
│  ┌───────────────────────────┐  │
│  │ daily-notes/YYYY-MM-DD.md │  │
│  │ active-projects/*.md       │  │
│  │ STATE.yaml                 │  │
│  └───────────────────────────┘  │
├─────────────────────────────────┤
│  L3: Long-term Memory (Index)   │ ← Persistent knowledge, lessons learned
│  ┌───────────────────────────┐  │
│  │ MEMORY.md (index < 40 lines)│ │
│  │ tacit-knowledge/*.md       │  │
│  │ heartbeat-state.json       │  │
│  └───────────────────────────┘  │
└─────────────────────────────────┘
```

## When to Use

- Building autonomous agents that need to remember across sessions
- Implementing cron-based monitoring systems
- Multi-agent coordination with shared state

## Layer Details

### L1: Working Memory
- **Scope**: Current conversation only
- **Capacity**: ~100 messages (sliding window)
- **Auto-flush**: When context reaches 85% capacity
- **Format**: Direct conversation context

### L2: Session Memory
- **Scope**: Current deployment period
- **Storage**: Markdown files in workspace/memory/
- **Auto-write**: After each task completion
- **Format**: Structured markdown with tags

**Daily Notes Format:**
```markdown
### [Project] Task Name (HH:MM) ✅/⚠️/❌
- **Event**: One-line description
- **Result**: One-line summary
- **Files**: Relevant file paths
- **Lessons**: Key takeaways
- **Tags**: #tag1 #tag2
```

### L3: Long-term Memory
- **Scope**: Persistent across all sessions
- **Entry point**: MEMORY.md (index, must be < 40 lines)
- **Knowledge**: tacit-knowledge/lessons-learned.md
- **Search**: Semantic search via memsearch

## Memory Flush Protocol

| Context Usage | Action |
|---------------|--------|
| < 50% | Normal operation |
| 50-70% | Increased vigilance, write after exchanges |
| 70-85% | Active flushing, write everything important NOW |
| > 85% | Emergency flush, stop and write full summary |

## Best Practices

1. **Index layer must stay lean**: MEMORY.md < 40 lines, only pointers
2. **Write conclusions, not process**: Daily notes capture outcomes
3. **Tags enable semantic search**: Always include relevant hashtags
4. **Checkpoint complex tasks**: Git commits at phase boundaries
5. **State files over memory**: File-based state survives context compression
