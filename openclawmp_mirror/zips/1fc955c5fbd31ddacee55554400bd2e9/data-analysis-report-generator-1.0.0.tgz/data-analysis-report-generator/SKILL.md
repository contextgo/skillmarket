---
name: data-analysis-report-generator
description: '智能数据分析报告生成器 - 自动将数据转化为专业商业洞察报告'
version: 1.0.0
type: skill
tags: ['data-analysis', 'report', 'business', 'visualization', 'automation']
---

# 智能数据分析报告生成器

> 自动将数据转化为专业商业洞察报告

## 核心功能

- 📊 自动数据清洗和预处理
- 📈 智能图表生成（趋势/对比/分布）
- 🎯 关键指标自动识别
- 💡 AI驱动的商业洞察
- 📄 专业报告格式输出

## 使用方法

```bash
# 分析CSV数据
openclaw skill run data-report --file "sales.csv" --type "sales"

# 分析JSON数据
openclaw skill run data-report --file "users.json" --type "user-behavior"

# 分析数据库
openclaw skill run data-report --db "mysql://localhost/db" --query "SELECT * FROM orders"
```

## 支持的数据类型

| 类型 | 说明 | 输出 |
|------|------|------|
| 销售分析 | 销售额、增长率、趋势 | 销售报告 |
| 用户行为 | 留存、活跃、转化 | 用户报告 |
| 财务分析 | 收入、成本、利润 | 财务报告 |
| 运营分析 | KPI、效率、瓶颈 | 运营报告 |
| 市场分析 | 竞品、份额、趋势 | 市场报告 |

## 报告包含内容

### 1. 执行摘要
- 核心发现（3-5条）
- 关键指标概览
- 行动建议

### 2. 数据概览
- 数据规模统计
- 质量评估
- 分布特征

### 3. 深度分析
- 趋势分析（时间序列）
- 对比分析（多维度）
- 相关性分析
- 异常检测

### 4. 可视化图表
- 趋势图（折线图）
- 对比图（柱状图）
- 分布图（饼图/箱线图）
- 热力图（相关性）

### 5. 洞察与建议
- 数据驱动的洞察
- 可执行的建议
- 风险提示

## 输出示例

```markdown
# 销售数据分析报告

## 执行摘要

### 核心发现
1. Q3销售额同比增长 35%，主要 driven by 新产品线
2. 客户留存率下降至 68%，需关注客户成功
3. 华东区域贡献 45% 营收，为最大市场

### 关键指标
| 指标 | 数值 | 同比 | 目标 |
|------|------|------|------|
| 总销售额 | ¥2.3M | +35% | ¥2.0M ✅ |
| 新客户 | 450 | +20% | 400 ✅ |
| 留存率 | 68% | -5% | 75% ❌ |

## 趋势分析

### 月度销售趋势
[图表：折线图显示12个月销售趋势]

**洞察**：
- 7-9月为销售旺季
- 11月出现下滑，需调查原因

## 建议

1. **短期**：加强客户成功团队，提升留存率
2. **中期**：复制华东模式到其他区域
3. **长期**：开发新产品线，保持增长
```

## 安装

```bash
openclaw skill install data-analysis-report-generator
```

## 配置

```json
{
  "skills": {
    "data-analysis-report-generator": {
      "outputFormat": "markdown",
      "chartStyle": "modern",
      "language": "zh",
      "includeRawData": false
    }
  }
}
```

## 高级功能

- 🤖 AI自动洞察生成
- 📊 交互式图表（HTML输出）
- 🔄 定时自动生成报告
- 📧 自动邮件发送
- 🌐 多语言支持

---

**专业级数据分析，让数据说话！**
