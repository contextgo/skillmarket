# YouTube 观看器

从 YouTube 视频中提取文本字幕，以实现摘要、问答和内容提取。

## 使用方法

### 获取字幕

检索视频的文本字幕。

```bash
python3 {baseDir}/scripts/get_transcript.py "https://www.youtube.com/watch?v=VIDEO_ID"
```

## 示例

**摘要视频：**

1. 获取字幕：
   ```bash
   python3 {baseDir}/scripts/get_transcript.py "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
   ```
2. 读取输出并总结给用户。

**查找特定信息：**

1. 获取字幕。
2. 在文本中搜索关键词或根据内容回答用户的问题。

## 注意事项

- 需要 `yt-dlp` 已安装并可在 PATH 中访问。
- 支持具有关闭字幕（CC）或自动生成字幕的视频。
- 如果视频没有字幕，脚本将报错并显示错误信息。