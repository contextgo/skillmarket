---
name: resume-optimizor
description: 简历优化助手 - 简历分析、关键词优化、面试问题预测、求职信生成
version: 1.0.0
tags: ["resume", "job", "career", "简历", "求职", "面试"]
---

# 简历优化助手

帮你优化简历，提升求职成功率。

## 功能一览

| 功能 | 说明 |
|------|------|
| 🔍 简历分析 | 诊断简历问题，给出改进建议 |
| 🎯 关键词优化 | 根据JD提取关键词，优化简历 |
| 📝 求职信生成 | 根据简历和JD生成求职信 |
| ❓ 面试问题预测 | 根据简历预测可能被问的问题 |
| 📊 竞争力评估 | 对比JD评估匹配度 |

---

## 快速开始

```bash
# 分析简历
resume analyze --file /path/to/resume.pdf

# 根据JD优化
resume optimize --resume /path/to/resume.pdf --jd "要求：3年Java经验"

# 生成求职信
resume coverletter --resume /path/to/resume.pdf --jd "要求：Python开发"

# 预测面试问题
resume interview --resume /path/to/resume.pdf

# 竞争力评估
resume score --resume /path/to/resume.pdf --jd "要求：..."
```

---

## 详细功能

### 🔍 简历分析

```bash
resume analyze --file resume.pdf
```

**分析维度：**
- 格式规范度
- 内容完整度
- 关键词匹配
- 成就量化
- 职业发展逻辑

**输出示例：**
```
📋 简历诊断报告
│
├── ✅ 优点
│   ├── 格式规范，结构清晰
│   ├── 工作经历描述详细
│   └── 技能列表完整
│
├── ⚠️ 改进建议
│   ├── 缺少个人总结
│   ├── 成就缺少量化数据
│   └── 项目描述过于简洁
│
└── 📝 具体建议
    ├── 建议在开头添加2-3行个人总结
    ├── 将"负责XX系统开发"改为"主导XX系统开发，效率提升30%"
    └── 项目经历建议补充技术栈说明
```

### 🎯 关键词优化

```bash
resume optimize --resume resume.pdf --jd "JD内容..."
```

根据目标岗位的JD，自动：
1. 提取JD中的关键词
2. 对比简历现有关键词
3. 给出补充建议
4. 提供优化后的描述

### 📝 求职信生成

```bash
resume coverletter \
  --resume resume.pdf \
  --jd "要求：3年Python经验" \
  --output coverletter.md
```

**生成的求职信包含：**
- 个人亮点总结
- 为什么适合这个岗位
- 期待进一步沟通

### ❓ 面试问题预测

```bash
resume interview --resume resume.pdf
```

**预测问题类型：**
- 行为面试题（宝洁八大问）
- 专业技能题
- 项目深挖题
- 职业规划题

**输出示例：**
```
🎤 预计面试问题

│
├── 📌 必问项目深挖
│   ├── 请详细介绍XX项目的技术架构？
│   ├── 项目中遇到的最大挑战是什么？如何解决的？
│   └── 如果让你重新做这个项目，会做什么改进？
│
├── 💼 行为面试
│   ├── 请举一个团队合作的例子？
│   ├── 请举一个解决复杂问题的例子？
│   └── 你的职业规划是什么？
│
└── 🔧 专业技能
    ├── 熟练使用Python，具体用在哪些场景？
    ├── 如何保证代码质量？
    └── 有哪些性能优化的经验？
```

### 📊 竞争力评估

```bash
resume score --resume resume.pdf --jd "JD内容..."
```

**评估维度：**
- 技能匹配度
- 经验年限匹配
- 学历匹配
- 整体竞争力评分

**输出示例：**
```
📊 竞争力评估

岗位：高级Python开发工程师

├── 🎯 技能匹配度：85%
│   ├── Python：✅ 精通
│   ├── Django：✅ 熟练
│   ├──SQL：✅ 熟练
│   ├── Redis： My⚠️ 了解
│   └── Docker：❌ 缺失
│
├── 📅 经验匹配：90%
│   └── 要求5年，实际6年
│
├── 🎓 学历匹配：100%
│   └── 要求本科，实际本科
│
└── ⭐ 综合评分：88/100

💡 建议：建议补充Redis和Docker经验
```

---

## 配置

### 环境变量

| 变量 | 说明 |
|------|------|
| OPENAI_API_KEY | OpenAI API Key（用于AI分析） |
| ANTHROPIC_API_KEY | Anthropic API Key |

### 配置文件

`~/.resume/config.json`：

```json
{
  "default_language": "中文",
  "resume_format": "pdf",
  "analysis_depth": "detailed",
  "api_provider": "openai"
}
```

---

## 支持格式

- PDF
- Word (.docx)
- Markdown (.md)
- 纯文本 (.txt)

---

## 使用场景

### 场景1：海投优化

```bash
# 批量根据不同JD优化简历
for jd in job1.txt job2.txt job3.txt; do
  resume optimize --resume resume.pdf --jd "$(cat $jd)" --output "optimized-$jd"
done
```

### 场景2：面试准备

```bash
# 先分析简历
resume analyze --resume resume.pdf

# 预测面试问题
resume interview --resume resume.pdf > interview_questions.md

# 针对每个问题准备答案
```

### 场景3：竞争力对比

```bash
# 对比多个岗位
resume score --resume resume.pdf --jd "$(cat job1.txt)"
resume score --resume resume.pdf --jd "$(cat job2.txt)"
```

---

## 后续规划

- [ ] 一键投递多个平台
- [ ] 薪资谈判建议
- [ ] 模拟面试功能
- [ ] 简历模板推荐
