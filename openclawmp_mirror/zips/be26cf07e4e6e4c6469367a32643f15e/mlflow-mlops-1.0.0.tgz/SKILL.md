---
name: mlflow-mlops
description: "MLflow MLOps guide - experiment tracking, model registry, and ML lifecycle management"
version: 1.0.0
tags: ["mlflow", "mlops", "machine-learning", "experiment-tracking", "model-management"]
---

# MLflow MLOps Guide

MLflow is an open-source platform for managing the ML lifecycle, including experimentation, reproducibility, deployment, and model registry.

## Four Components

1. **MLflow Tracking**: Log parameters, metrics, artifacts
2. **MLflow Projects**: Package code for reproducible runs
3. **MLflow Models**: Standard format for deployment
4. **MLflow Registry**: Model versioning and lifecycle

## Experiment Tracking

```python
import mlflow

mlflow.set_experiment("sentiment-analysis")

with mlflow.start_run():
    mlflow.log_param("model", "bert-base")
    mlflow.log_param("learning_rate", 2e-5)
    mlflow.log_metric("accuracy", 0.92)
    mlflow.log_metric("f1", 0.89)
    mlflow.sklearn.log_model(model, "model")
```

## Model Registry

```python
# Register a model
mlflow.register_model(
    "runs:/<run-id>/model",
    "sentiment-model"
)

# Transition stages: None → Staging → Production → Archived
client = mlflow.tracking.MlflowClient()
client.transition_model_version_stage(
    "sentiment-model", version=1, stage="Production"
)
```

## Model Serving

```bash
# Serve model locally
mlflow models serve -m "models:/sentiment-model/Production" -p 5000

# Deploy to cloud
mlflow models build-docker -m "models:/sentiment-model/1" -n sentiment-api
```

## MLflow UI

```bash
mlflow ui --port 5000
# Compare runs, plot metrics, browse artifacts
```

## Best Practices

- Log all hyperparameters with `mlflow.log_param`
- Use tags for run categorization (`mlflow.set_tag`)
- Store artifacts (plots, datasets) with `mlflow.log_artifact`
- Use `autolog` for frameworks: `mlflow.sklearn.autolog()`
- Set up model aliases for production routing
