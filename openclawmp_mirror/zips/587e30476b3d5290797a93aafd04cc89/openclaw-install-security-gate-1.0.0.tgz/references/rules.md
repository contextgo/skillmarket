# 扫描规则说明

## 风险类别

1. `command_exec`：命令执行、下载后执行、编码命令
2. `network`：网络请求调用
3. `file_ops`：写入、删除、破坏性操作
4. `env_access`：环境变量访问/密钥字段
5. `data_access`：敏感路径访问
6. `exfiltration`：可疑外传域名、组合外传风险

## 典型高风险信号

- `curl ... | bash`
- `Invoke-WebRequest ... | iex`
- `rm -rf /`
- 混淆解码后执行（如 `base64 + eval/exec`）
- 同文件同时出现：`network_call + sensitive_path`

## 误报控制

- 对 Markdown 文档仅应用少量“危险命令类”规则
- 忽略注释行中的关键字命中（`#`/`//`/`/*`）
- 不将普通 API URL 文档说明直接判为恶意
- 将“文件拉取失败比例”单独计入 `CAUTION`（而非直接 `DANGEROUS`）
- 低风险命中使用上限裁剪，避免正常资产被低风险堆叠误伤

## 判定阈值（默认）

- `DANGEROUS`（RED）：命中关键高危规则，或高风险信号密集（例如高危>=2）
- `CAUTION`（YELLOW）：存在可疑项、或文件拉取失败比例较高
- `SAFE`（GREEN）：其余情况

安装策略建议：
- RED：不安装；若已安装则卸载
- YELLOW：人工复核后决定（默认不自动安装）
- GREEN：允许安装

## 输出结构（摘要）

```json
{
  "asset": {"id": "s-xxx", "name": "..."},
  "summary": {
    "rating": "SAFE|CAUTION|DANGEROUS",
    "trafficLight": "GREEN|YELLOW|RED",
    "verdict": "ALLOW|REVIEW|BLOCK",
    "totalScore": 0,
    "severityCount": {"high": 0, "medium": 0, "low": 0}
  },
  "findings": []
}
```
