#!/usr/bin/env python3
"""
OpenClaw Skill Security Gate

在安装 Skill/Plugin/Trigger/Channel/Experience 前做静态安检：
- 可疑网络请求
- 可疑文件读写/删除
- 环境变量与敏感路径访问
- 典型危险命令（pipe-to-shell / 编码命令 / 高危删除）

默认只扫描；安装需显式使用 install 子命令。
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional
from urllib.parse import quote

import requests

DEFAULT_API = os.environ.get("OPENCLAWMP_API", "https://openclawmp.cc").rstrip("/")
REF_RE = re.compile(r"^(skill|plugin|trigger|channel|experience)/@([^/]+)/([^\s/]+)$", re.I)
ID_RE = re.compile(r"^[a-z]{1,3}-[0-9a-f]{8,}$", re.I)

SCAN_EXT = {
    ".py",
    ".js",
    ".ts",
    ".mjs",
    ".cjs",
    ".sh",
    ".ps1",
    ".bat",
    ".cmd",
    ".go",
    ".rs",
    ".java",
    ".php",
    ".rb",
    ".json",
    ".yaml",
    ".yml",
    ".txt",
    ".md",
    ".rst",
    ".html",
    ".css",
    ".xml",
    ".plist",
    ".env",
    ".example",
}
DOC_EXT = {".md", ".txt", ".rst"}


@dataclass(frozen=True)
class Rule:
    key: str
    category: str
    severity: str
    score: int
    pattern: re.Pattern
    description: str
    apply_to_docs: bool = False


RULES: List[Rule] = [
    Rule(
        key="pipe_to_shell",
        category="command_exec",
        severity="high",
        score=9,
        pattern=re.compile(r"(?:curl|wget)[^\n]{0,240}\|\s*(?:bash|sh)\b", re.I),
        description="检测到远程下载后直接管道执行（pipe-to-shell）",
        apply_to_docs=True,
    ),
    Rule(
        key="powershell_iex",
        category="command_exec",
        severity="high",
        score=9,
        pattern=re.compile(
            r"(?:Invoke-WebRequest|iwr)[^\n]{0,200}\|\s*(?:iex|Invoke-Expression)\b", re.I
        ),
        description="检测到 PowerShell 远程内容直接执行",
        apply_to_docs=True,
    ),
    Rule(
        key="powershell_encoded",
        category="command_exec",
        severity="medium",
        score=7,
        pattern=re.compile(r"powershell[^\n]{0,120}(?:-enc|-encodedcommand)\b", re.I),
        description="检测到编码 PowerShell 命令",
        apply_to_docs=True,
    ),
    Rule(
        key="dangerous_rm_root",
        category="file_ops",
        severity="high",
        score=10,
        pattern=re.compile(r"\brm\s+-rf\s+/(?:\s|$)", re.I),
        description="检测到高危删除命令 rm -rf /",
        apply_to_docs=True,
    ),
    Rule(
        key="destructive_fs",
        category="file_ops",
        severity="high",
        score=8,
        pattern=re.compile(r"\b(?:mkfs\.|format\s+[A-Za-z]:|del\s+/f\s+/q)\b", re.I),
        description="检测到高危文件系统操作",
        apply_to_docs=True,
    ),
    Rule(
        key="exec_api",
        category="command_exec",
        severity="medium",
        score=6,
        pattern=re.compile(
            r"\b(?:os\.system|subprocess\.(?:run|Popen|call)|child_process\.(?:exec|spawn|execSync)|Runtime\.getRuntime\(\)\.exec)\b"
        ),
        description="检测到命令执行 API",
    ),
    Rule(
        key="obfuscated_exec",
        category="command_exec",
        severity="high",
        score=8,
        pattern=re.compile(
            r"(?:base64\.(?:b64decode|decode64)|atob\(|fromCharCode\().{0,140}(?:eval\(|exec\(|Function\()",
            re.I | re.S,
        ),
        description="检测到疑似混淆解码后执行",
    ),
    Rule(
        key="network_call",
        category="network",
        severity="low",
        score=1,
        pattern=re.compile(
            r"\b(?:requests\.(?:get|post|put|delete|request)|httpx\.(?:get|post|put|delete|request)|axios\.(?:get|post|request)|fetch\(|urllib\.request|curl\s+https?://|wget\s+https?://)"
        ),
        description="检测到网络请求调用（普通行为，需结合上下文判断）",
    ),
    Rule(
        key="suspicious_domain",
        category="exfiltration",
        severity="high",
        score=8,
        pattern=re.compile(
            r"(?:discord(?:app)?\.com/api/webhooks|pastebin\.com|transfer\.sh|ngrok\.io|webhook\.site)",
            re.I,
        ),
        description="检测到常见外传/隧道域名",
        apply_to_docs=True,
    ),
    Rule(
        key="file_write",
        category="file_ops",
        severity="low",
        score=2,
        pattern=re.compile(
            r"\b(?:open\([^\)]*['\"](?:w|a|x|wb|ab)['\"]|fs\.(?:writeFile|appendFile|createWriteStream)|Path\([^\)]*\)\.write_text)"
        ),
        description="检测到文件写入操作",
    ),
    Rule(
        key="file_delete",
        category="file_ops",
        severity="medium",
        score=4,
        pattern=re.compile(r"\b(?:os\.remove|os\.unlink|shutil\.rmtree|fs\.(?:unlink|rm|rmdir))\b"),
        description="检测到文件删除操作",
    ),
    Rule(
        key="sensitive_path",
        category="data_access",
        severity="high",
        score=7,
        pattern=re.compile(
            r"(?:~/.openclawmp/credentials\.json|~/.openclaw/identity/device\.json|\.ssh/id_rsa|/etc/passwd|/etc/shadow)",
            re.I,
        ),
        description="检测到敏感路径访问",
    ),
    Rule(
        key="env_access",
        category="env_access",
        severity="low",
        score=2,
        pattern=re.compile(r"\b(?:process\.env|os\.getenv\(|os\.environ\[|dotenv|load_dotenv\()", re.I),
        description="检测到环境变量访问",
    ),
    Rule(
        key="secret_env",
        category="env_access",
        severity="medium",
        score=4,
        pattern=re.compile(
            r"(?:process\.env\.[A-Z0-9_]*(?:TOKEN|API[_-]?KEY|SECRET|PASSWORD|PRIVATE[_-]?KEY)|os\.getenv\(['\"][A-Z0-9_]*(?:TOKEN|API[_-]?KEY|SECRET|PASSWORD|PRIVATE[_-]?KEY)['\"]\)|os\.environ\[['\"][A-Z0-9_]*(?:TOKEN|API[_-]?KEY|SECRET|PASSWORD|PRIVATE[_-]?KEY)['\"]\])",
            re.I,
        ),
        description="检测到疑似敏感环境变量读取",
    ),
]


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def ext_of(path: str) -> str:
    ext = Path(path).suffix.lower()
    if not ext and "." not in Path(path).name:
        return ".noext"
    return ext


def normalize_ref(raw: str) -> str:
    raw = raw.strip()
    if raw.startswith("openclawmp install "):
        parts = raw.split()
        if len(parts) >= 3:
            return parts[2]
    return raw


class GateError(RuntimeError):
    pass


def req_json(session: requests.Session, url: str, **kwargs) -> dict:
    r = session.get(url, timeout=20, **kwargs)
    if r.status_code != 200:
        raise GateError(f"请求失败: {r.status_code} {url}")
    return r.json()


def resolve_asset(session: requests.Session, api: str, asset_ref: str) -> dict:
    ref = normalize_ref(asset_ref)

    if ID_RE.match(ref):
        return req_json(session, f"{api}/api/v1/assets/{ref}")

    m = REF_RE.match(ref)
    if not m:
        search = req_json(session, f"{api}/api/v1/search", params={"q": ref, "limit": 10})
        items = search.get("items") or []
        if not items:
            raise GateError(f"找不到资产: {ref}")
        if len(items) > 1:
            cands = [f"{i.get('type')}/@{i.get('authorId')}/{i.get('name')} ({i.get('id')})" for i in items[:5]]
            raise GateError("资产不唯一，请使用完整引用。候选:\n- " + "\n- ".join(cands))
        return req_json(session, f"{api}/api/v1/assets/{items[0]['id']}")

    typ, author, slug = m.group(1).lower(), m.group(2), m.group(3)
    search = req_json(session, f"{api}/api/v1/search", params={"q": slug, "limit": 30})
    items = search.get("items") or []
    candidates = [
        i
        for i in items
        if (i.get("type") or "").lower() == typ
        and (i.get("authorId") or "") == author
        and (i.get("name") or "") == slug
    ]

    if not candidates:
        candidates = [
            i
            for i in items
            if (i.get("type") or "").lower() == typ and (i.get("authorId") or "") == author
        ]

    if not candidates:
        raise GateError(f"找不到匹配资产: {ref}")

    candidates.sort(key=lambda x: (x.get("installs", 0), x.get("updatedAt", "")), reverse=True)
    return req_json(session, f"{api}/api/v1/assets/{candidates[0]['id']}")


def scan_text(path: str, text: str, ext: str) -> List[dict]:
    findings: List[dict] = []
    lines = text.splitlines() or [text]

    for rule in RULES:
        if ext in DOC_EXT and not rule.apply_to_docs:
            continue

        # 行扫描，避免输出过多噪音；忽略注释行
        for idx, line in enumerate(lines, start=1):
            stripped = line.strip()
            if not stripped:
                continue
            if stripped.startswith("#") or stripped.startswith("//") or stripped.startswith("/*") or stripped.startswith("*"):
                continue

            if rule.pattern.search(line):
                findings.append(
                    {
                        "rule": rule.key,
                        "category": rule.category,
                        "severity": rule.severity,
                        "score": rule.score,
                        "description": rule.description,
                        "file": path,
                        "line": idx,
                        "snippet": stripped[:220],
                    }
                )
                break

    # 组合风险：同文件既访问敏感路径又发起网络请求
    keys = {f["rule"] for f in findings}
    if "network_call" in keys and "sensitive_path" in keys:
        findings.append(
            {
                "rule": "possible_credential_theft",
                "category": "exfiltration",
                "severity": "high",
                "score": 9,
                "description": "同文件同时出现网络调用和敏感路径访问，疑似凭证外传风险",
                "file": path,
                "line": None,
                "snippet": "network_call + sensitive_path",
            }
        )

    return findings


def summarize(findings: List[dict], failed_files: int, total_files: int) -> dict:
    sev_count = {"high": 0, "medium": 0, "low": 0}
    raw_score = 0
    by_rule: Dict[str, int] = {}

    for f in findings:
        sev_count[f["severity"]] = sev_count.get(f["severity"], 0) + 1
        raw_score += int(f["score"])
        by_rule[f["rule"]] = by_rule.get(f["rule"], 0) + 1

    # 加权风险分：避免大量低风险命中误伤正常资产
    risk_score = sev_count["high"] * 8 + sev_count["medium"] * 3 + min(sev_count["low"], 5)

    fail_ratio = (failed_files / total_files) if total_files else 0.0

    critical_rules = {
        "pipe_to_shell",
        "powershell_iex",
        "dangerous_rm_root",
        "destructive_fs",
        "obfuscated_exec",
        "possible_credential_theft",
    }
    hit_critical = any(f.get("rule") in critical_rules for f in findings)

    rating = "SAFE"
    if hit_critical or sev_count["high"] >= 2 or risk_score >= 16:
        rating = "DANGEROUS"
    elif sev_count["high"] >= 1 or sev_count["medium"] >= 2 or risk_score >= 9 or fail_ratio > 0.4:
        rating = "CAUTION"

    verdict_map = {
        "SAFE": "ALLOW",
        "CAUTION": "REVIEW",
        "DANGEROUS": "BLOCK",
    }
    light_map = {
        "SAFE": "GREEN",
        "CAUTION": "YELLOW",
        "DANGEROUS": "RED",
    }

    return {
        "rating": rating,
        "trafficLight": light_map[rating],
        "verdict": verdict_map[rating],
        "totalScore": risk_score,
        "rawScore": raw_score,
        "severityCount": sev_count,
        "ruleHits": by_rule,
        "failedFileRatio": round(fail_ratio, 3),
    }


def run_scan(
    session: requests.Session,
    api: str,
    ref: str,
    max_size: int = 220_000,
    max_files: int = 240,
) -> dict:
    asset = resolve_asset(session, api, ref)
    files = asset.get("files") or []

    findings: List[dict] = []
    scanned_files = 0
    skipped_files = 0
    failed_files = 0

    scan_candidates = []
    for f in files:
        path = f.get("path") or f.get("name") or ""
        inline_content = f.get("content") if isinstance(f.get("content"), str) else None
        size = int(f.get("size") or (len(inline_content) if inline_content is not None else 0))
        ext = ext_of(path)
        if ext not in SCAN_EXT and ext != ".noext":
            skipped_files += 1
            continue
        if size > max_size:
            skipped_files += 1
            continue
        scan_candidates.append({"path": path, "ext": ext, "size": size, "inline": inline_content})

    if len(scan_candidates) > max_files:
        scan_candidates = scan_candidates[:max_files]

    for item in scan_candidates:
        path = item["path"]
        ext = item["ext"]
        inline_content = item["inline"]

        # 某些资产 API 直接返回内联文件内容（name/content），优先使用内联内容扫描
        if inline_content is not None:
            scanned_files += 1
            findings.extend(scan_text(path or "(inline)", inline_content, ext))
            continue

        if not path:
            failed_files += 1
            continue

        url = f"{api}/api/v1/assets/{asset['id']}/files/{quote(path, safe='')}"
        try:
            r = session.get(url, timeout=20)
            if r.status_code != 200:
                failed_files += 1
                continue
            text = r.text
        except Exception:
            failed_files += 1
            continue

        scanned_files += 1
        findings.extend(scan_text(path, text, ext))

    summary = summarize(findings, failed_files=failed_files, total_files=max(len(scan_candidates), 1))

    return {
        "timestamp": now_iso(),
        "asset": {
            "id": asset.get("id"),
            "name": asset.get("name"),
            "displayName": asset.get("displayName"),
            "type": asset.get("type"),
            "authorId": asset.get("authorId") or (asset.get("author") or {}).get("id"),
            "installs": asset.get("installs", 0),
            "installCommand": asset.get("installCommand"),
            "updatedAt": asset.get("updatedAt"),
        },
        "summary": {
            **summary,
            "filesTotal": len(files),
            "filesCandidate": len(scan_candidates),
            "filesScanned": scanned_files,
            "filesFailed": failed_files,
            "filesSkipped": skipped_files,
        },
        "findings": findings,
        "notes": [
            "该扫描为静态启发式检测，不能替代动态沙箱执行。",
            "如 filesFailed 比例高，请人工复核该资产或延迟安装。",
        ],
    }


def print_human_report(report: dict) -> None:
    asset = report["asset"]
    sm = report["summary"]
    light_icon = {
        "GREEN": "🟢",
        "YELLOW": "🟡",
        "RED": "🔴",
    }.get(sm.get("trafficLight", "GREEN"), "⚪")

    print("=== OpenClaw Skill 安检门 ===")
    print(f"资产: {asset['displayName']} ({asset['id']})")
    print(f"类型: {asset['type']} | 安装量: {asset['installs']} | 更新: {asset['updatedAt']}")
    raw = sm.get("rawScore", sm["totalScore"])
    print(
        f"评级: {sm.get('rating', 'SAFE')} {light_icon} | 判定: {sm['verdict']} | 风险分: {sm['totalScore']} | 原始分: {raw}"
    )
    print(
        f"文件: total={sm['filesTotal']} candidate={sm['filesCandidate']} scanned={sm['filesScanned']} failed={sm['filesFailed']} skipped={sm['filesSkipped']}"
    )
    print(
        f"严重级别: high={sm['severityCount']['high']} medium={sm['severityCount']['medium']} low={sm['severityCount']['low']}"
    )

    findings = report.get("findings") or []
    if not findings:
        print("未发现命中规则。")
        return

    print("\nTop findings:")
    for f in findings[:12]:
        loc = f"{f['file']}:{f['line']}" if f.get("line") else f["file"]
        print(f"- [{f['severity']}] {f['rule']} @ {loc}")
        print(f"  {f['snippet']}")


def maybe_write_json(report: dict, path: Optional[str]) -> None:
    if not path:
        return
    out = Path(path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")


def run_install(install_ref: str) -> int:
    cmd = ["openclawmp", "install", install_ref]
    p = subprocess.run(cmd)
    return p.returncode


def local_asset_path(asset_type: str, asset_name: str) -> Path:
    state_root = Path(os.environ.get("OPENCLAW_STATE_DIR", str(Path.home() / ".openclaw")))
    dir_map = {
        "skill": "skills",
        "plugin": "plugins",
        "trigger": "triggers",
        "channel": "channels",
        "experience": "experiences",
    }
    folder = dir_map.get(asset_type.lower(), f"{asset_type.lower()}s")
    return state_root / folder / asset_name


def is_installed(asset_type: str, asset_name: str) -> bool:
    return local_asset_path(asset_type, asset_name).exists()


def run_uninstall(asset_type: str, asset_name: str) -> int:
    uninstall_ref = f"{asset_type}/{asset_name}"
    p = subprocess.run(["openclawmp", "uninstall", uninstall_ref])
    return p.returncode


def resolve_install_ref(report: dict, fallback_ref: str) -> str:
    install_cmd = report["asset"].get("installCommand") or ""
    if install_cmd:
        parts = normalize_ref(install_cmd).split()
        if parts:
            return parts[-1]
    return normalize_ref(fallback_ref)


def main() -> int:
    parser = argparse.ArgumentParser(description="OpenClaw Skill 安检门（安装前静态扫描）")
    parser.add_argument("mode", choices=["scan", "install"], help="scan=仅扫描, install=扫描后尝试安装")
    parser.add_argument("asset_ref", help="资产引用，例如 skill/@u-xxxx/slug 或 s-xxxx")
    parser.add_argument("--api", default=DEFAULT_API, help=f"API 地址，默认 {DEFAULT_API}")
    parser.add_argument("--json-out", default="", help="输出 JSON 报告路径")
    parser.add_argument("--max-size", type=int, default=220000, help="单文件最大扫描大小（字节）")
    parser.add_argument("--max-files", type=int, default=240, help="单资产最大扫描文件数")
    parser.add_argument("--allow-caution", action="store_true", help="install 模式下，CAUTION 也继续安装")
    parser.add_argument("--allow-review", action="store_true", help=argparse.SUPPRESS)
    parser.add_argument("--force", action="store_true", help="install 模式下忽略评级强制继续（慎用）")

    args = parser.parse_args()

    session = requests.Session()
    session.headers.update({"User-Agent": "OpenClaw-SkillGate/0.2"})

    try:
        report = run_scan(
            session=session,
            api=args.api.rstrip("/"),
            ref=args.asset_ref,
            max_size=args.max_size,
            max_files=args.max_files,
        )
    except GateError as e:
        print(f"[ERROR] {e}", file=sys.stderr)
        return 2

    print_human_report(report)
    maybe_write_json(report, args.json_out or None)

    if args.mode == "scan":
        return 0

    rating = report["summary"].get("rating", "SAFE")
    allow_caution = args.allow_caution or args.allow_review
    install_ref = resolve_install_ref(report, args.asset_ref)

    asset_type = (report["asset"].get("type") or "skill").lower()
    asset_name = report["asset"].get("name") or ""

    # 红灯：直接卸载/不安装
    if rating == "DANGEROUS" and not args.force:
        print("\n[DANGEROUS/RED] 命中红灯，默认禁止安装。")
        if asset_name and is_installed(asset_type, asset_name):
            print(f"[RED] 检测到本地已安装，执行卸载: {asset_type}/{asset_name}")
            code = run_uninstall(asset_type, asset_name)
            if code == 0:
                print("[RED] 卸载完成。")
            else:
                print("[RED] 卸载失败，请人工执行 uninstall。", file=sys.stderr)
                return 5
        else:
            print("[RED] 本地未安装，已阻止安装。")
        return 3

    # 黄灯：默认不自动安装，需显式放行
    if rating == "CAUTION" and not allow_caution and not args.force:
        print("\n[CAUTION/YELLOW] 黄灯资产，默认不自动安装。请复核后使用 --allow-caution。")
        return 4

    if rating == "CAUTION":
        print("\n[CAUTION/YELLOW] 已显式放行，继续安装。")
    elif rating == "SAFE":
        print("\n[SAFE/GREEN] 绿灯通过，继续安装。")
    else:
        print("\n[FORCE] 已启用 --force，忽略红灯继续安装（高风险）。")

    print(f"[INSTALL] 执行安装: openclawmp install {install_ref}")
    return run_install(install_ref)


if __name__ == "__main__":
    sys.exit(main())
