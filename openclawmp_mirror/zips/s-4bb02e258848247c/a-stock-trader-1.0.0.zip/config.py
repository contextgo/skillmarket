#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - 配置文件
"""

# 腾讯财经API基础URL
TENCENT_QUOTE_URL = "https://qt.gtimg.cn/q="

# 支持的股票类型前缀
STOCK_PREFIXES = {
    'sh': '上海A股',  # 600, 601, 603, 688
    'sz': '深圳A股',  # 000, 001, 002, 003, 300
    'hk': '港股',     # 港股代码
}

# 默认请求超时（秒）
REQUEST_TIMEOUT = 10

# 重试次数
MAX_RETRIES = 3

# 缓存过期时间（秒）
CACHE_EXPIRE_TIME = 60