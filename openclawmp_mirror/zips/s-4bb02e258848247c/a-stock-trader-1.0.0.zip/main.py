#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - 主模块
整合实时行情、技术指标、风险管理和持仓分析功能
"""

import sys
import os
import numpy as np
from typing import List, Dict, Optional
import pandas as pd

# 添加模块路径
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from modules.market_data import get_stock_data, get_batch_stock_data, MarketData
from modules.technical_indicators import TechnicalIndicators, get_technical_indicators
from modules.risk_management import RiskManager, StopLossConfig, TakeProfitConfig, Position
from modules.hot_scanner import HotScanner
from modules.historical_data import get_historical_data

class AStockTrader:
    """A股操盘手主类"""
    
    def __init__(self):
        self.risk_manager = RiskManager()
        self.hot_scanner = HotScanner()
    
    def analyze_single_stock(self, symbol: str) -> Dict:
        """
        分析单个股票
        
        Args:
            symbol: 股票代码
            
        Returns:
            完整分析结果
        """
        # 获取实时行情
        market_data = get_stock_data(symbol)
        if not market_data:
            return {"error": f"无法获取 {symbol} 的行情数据"}
        
        # 获取历史数据用于技术分析
        historical_data = get_historical_data(symbol, days=100)
        
        if historical_data is None or historical_data.empty:
            technical_analysis = {"error": "无法获取历史数据进行技术分析"}
            signals = {"error": "无法生成技术信号"}
        else:
            # 技术指标分析
            tech_result = get_technical_indicators(symbol, historical_data)
            technical_analysis = {
                'latest_indicators': tech_result['indicators'].iloc[-1].to_dict(),
                'signals': tech_result['signals']
            }
            signals = tech_result['signals']
        
        # 风险评估
        position = Position(
            symbol=symbol,
            name=market_data['name'],
            quantity=100,  # 默认100股用于测试
            cost_price=market_data['price'],  # 使用当前价格作为成本价
            current_price=market_data['price'],
            market_value=market_data['price'] * 100,
            unrealized_pnl=0.0,
            unrealized_pnl_pct=0.0
        )
        risk_info = self.risk_manager.calculate_position_risk(position)
        risk_assessment = {
            'risk_level': risk_info['risk_level'].value,
            'stop_loss_price': risk_info['stop_loss_price'],
            'pnl_pct': risk_info['pnl_pct']
        }
        
        return {
            'symbol': symbol,
            'market_data': market_data,
            'technical_analysis': technical_analysis,
            'risk_assessment': risk_assessment,
            'recommendation': self._generate_recommendation(market_data, signals, risk_assessment)
        }
    
    def analyze_portfolio(self, holdings: List[Dict]) -> Dict:
        """
        分析投资组合
        
        Args:
            holdings: 持仓列表，每个元素包含 {'code': str, 'name': str, 'cost': float}
            
        Returns:
            组合分析结果
        """
        portfolio_analysis = {
            'total_holdings': len(holdings),
            'stocks': [],
            'overall_risk': 'medium',
            'suggested_actions': []
        }
        
        total_value = 0
        total_cost = 0
        
        for holding in holdings:
            symbol = holding['code']
            cost_price = holding['cost']
            
            # 获取当前价格
            market_data = get_stock_data(symbol)
            if not market_data:
                continue
            
            current_price = market_data['price']
            current_value = current_price  # 这里假设持有1股，实际应该乘以持股数量
            cost = cost_price
            
            total_value += current_value
            total_cost += cost
            
            # 计算盈亏
            profit_loss = current_value - cost
            profit_loss_pct = (profit_loss / cost) * 100 if cost > 0 else 0
            
            # 风险管理检查
            position = Position(
                symbol=symbol,
                name=holding.get('name', symbol),
                quantity=100,  # 默认100股
                cost_price=cost_price,
                current_price=current_price,
                market_value=current_price * 100,
                unrealized_pnl=(current_price - cost_price) * 100,
                unrealized_pnl_pct=((current_price - cost_price) / cost_price) * 100 if cost_price > 0 else 0
            )
            stop_loss_hit, _ = self.risk_manager.check_stop_loss_trigger(position)
            take_profit_hit, _, _ = self.risk_manager.check_take_profit_trigger(position)
            
            # 简单的风险评估逻辑
            if profit_loss_pct < -8:
                risk_level = 'high'
            elif profit_loss_pct < -3:
                risk_level = 'medium'
            elif profit_loss_pct > 15:
                risk_level = 'low'
            else:
                risk_level = 'medium'
                
            stock_analysis = {
                'symbol': symbol,
                'name': holding.get('name', symbol),
                'cost_price': cost_price,
                'current_price': current_price,
                'profit_loss': profit_loss,
                'profit_loss_pct': profit_loss_pct,
                'stop_loss_hit': stop_loss_hit,
                'take_profit_hit': take_profit_hit,
                'risk_level': risk_level
            }
            
            portfolio_analysis['stocks'].append(stock_analysis)
            
            # 生成建议
            if stop_loss_hit:
                portfolio_analysis['suggested_actions'].append(f"建议卖出 {symbol} ({holding.get('name', symbol)}) - 触发止损")
            elif take_profit_hit:
                portfolio_analysis['suggested_actions'].append(f"建议部分止盈 {symbol} ({holding.get('name', symbol)}) - 触发止盈")
        
        # 计算整体盈亏
        if total_cost > 0:
            overall_profit_loss = total_value - total_cost
            overall_profit_loss_pct = (overall_profit_loss / total_cost) * 100
            portfolio_analysis['overall_profit_loss'] = overall_profit_loss
            portfolio_analysis['overall_profit_loss_pct'] = overall_profit_loss_pct
        
        # 评估整体风险
        portfolio_analysis['overall_risk'] = self.risk_manager.assess_portfolio_risk(portfolio_analysis['stocks'])
        
        return portfolio_analysis
    
    def scan_hot_stocks(self, top_n: int = 10) -> List[Dict]:
        """
        扫描热门股票
        
        Args:
            top_n: 返回前N只热门股票
            
        Returns:
            热门股票列表
        """
        return self.hot_scanner.scan_hot_stocks(top_n)
    
    def _get_market_trend(self, signals: Dict) -> str:
        """根据技术信号判断市场趋势"""
        buy_signals = 0
        sell_signals = 0
        
        for signal_type, signal in signals.items():
            if '买入' in str(signal):
                buy_signals += 1
            elif '卖出' in str(signal):
                sell_signals += 1
        
        if buy_signals > sell_signals:
            return 'bullish'
        elif sell_signals > buy_signals:
            return 'bearish'
        else:
            return 'neutral'
    
    def _generate_recommendation(self, market_data: Dict, signals: Dict, risk_assessment: Dict) -> str:
        """生成交易建议"""
        risk_level = risk_assessment.get('risk_level', 'medium')
        
        if risk_level == 'high':
            return '高风险，建议观望或减仓'
        
        buy_signals = sum(1 for signal in signals.values() if '买入' in str(signal))
        sell_signals = sum(1 for signal in signals.values() if '卖出' in str(signal))
        
        if buy_signals >= 2 and risk_level != 'high':
            return '技术面良好，可考虑买入'
        elif sell_signals >= 2:
            return '技术面转弱，建议卖出'
        else:
            return '技术面中性，观望为主'

# 便捷函数
def analyze_stock(symbol: str) -> Dict:
    """分析单个股票的便捷函数"""
    trader = AStockTrader()
    return trader.analyze_single_stock(symbol)

def analyze_portfolio(holdings: List[Dict]) -> Dict:
    """分析投资组合的便捷函数"""
    trader = AStockTrader()
    return trader.analyze_portfolio(holdings)

def scan_hot_stocks(top_n: int = 10) -> List[Dict]:
    """扫描热门股票的便捷函数"""
    trader = AStockTrader()
    return trader.scan_hot_stocks(top_n)

if __name__ == "__main__":
    # 示例使用
    trader = AStockTrader()
    
    # 分析单个股票
    print("=== 单个股票分析 ===")
    result = trader.analyze_single_stock("600000")
    if 'error' not in result:
        print(f"股票: {result['market_data']['name']} ({result['symbol']})")
        print(f"当前价格: {result['market_data']['price']:.2f}")
        print(f"建议: {result['recommendation']}")
        print(f"风险等级: {result['risk_assessment']['risk_level']}")
    else:
        print(f"分析失败: {result['error']}")
    
    print("\n=== 投资组合分析 ===")
    holdings = [
        {"code": "301236", "name": "软通动力", "cost": 72.451},
        {"code": "600036", "name": "招商银行", "cost": 38.98}
    ]
    portfolio_result = trader.analyze_portfolio(holdings)
    print(f"持仓数量: {portfolio_result['total_holdings']}")
    print(f"整体风险: {portfolio_result['overall_risk']}")
    if 'suggested_actions' in portfolio_result:
        for action in portfolio_result['suggested_actions']:
            print(f"建议: {action}")
    
    print("\n=== 热门股票扫描 ===")
    hot_stocks = trader.scan_hot_stocks(5)
    for i, stock in enumerate(hot_stocks, 1):
        print(f"{i}. {stock['name']} ({stock['symbol']}) - 热度: {stock['hot_score']:.2f}")