#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股技术分析示例
演示MACD、KDJ、布林带等指标的使用
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from a_stock_trader.analysis.indicators import TechnicalIndicators
from a_stock_trader.data.quote import AStockQuote

def demo_technical_analysis():
    """技术分析演示"""
    print("=== A股技术分析演示 ===\n")
    
    # 初始化技术指标分析器
    ta = TechnicalIndicators()
    quote_service = AStockQuote()
    
    # 测试股票列表
    test_stocks = ["301236", "600036", "000858"]  # 软通动力、招商银行、五粮液
    
    for stock_code in test_stocks:
        try:
            print(f"分析股票: {stock_code}")
            
            # 获取实时行情
            quote = quote_service.get_quote(stock_code)
            if not quote:
                print(f"  获取行情失败\n")
                continue
                
            print(f"  当前价格: ¥{quote['price']:.2f} ({quote['change_pct']:+.2f}%)")
            
            # 计算MACD指标
            macd_data = ta.calculate_macd(stock_code)
            if macd_data:
                print(f"  MACD: DIF={macd_data['dif']:.3f}, DEA={macd_data['dea']:.3f}, MACD={macd_data['macd']:.3f}")
                if macd_data['signal'] == 'buy':
                    print("  🟢 MACD金叉信号 (买入)")
                elif macd_data['signal'] == 'sell':
                    print("  🔴 MACD死叉信号 (卖出)")
                else:
                    print("  ⚪ MACD无明确信号")
            
            # 计算KDJ指标
            kdj_data = ta.calculate_kdj(stock_code)
            if kdj_data:
                print(f"  KDJ: K={kdj_data['k']:.2f}, D={kdj_data['d']:.2f}, J={kdj_data['j']:.2f}")
                if kdj_data['k'] < 20:
                    print("  🟢 KDJ超卖区域 (潜在买入机会)")
                elif kdj_data['k'] > 80:
                    print("  🔴 KDJ超买区域 (潜在卖出机会)")
                else:
                    print("  ⚪ KDJ正常区域")
            
            # 计算布林带
            bollinger_data = ta.calculate_bollinger_bands(stock_code)
            if bollinger_data:
                print(f"  布林带: 上轨={bollinger_data['upper']:.2f}, 中轨={bollinger_data['middle']:.2f}, 下轨={bollinger_data['lower']:.2f}")
                current_price = quote['price']
                if current_price > bollinger_data['upper']:
                    print("  🔴 价格突破上轨 (超买)")
                elif current_price < bollinger_data['lower']:
                    print("  🟢 价格跌破下轨 (超卖)")
                else:
                    print("  ⚪ 价格在布林带内")
            
            # 综合信号
            signals = ta.get_comprehensive_signals(stock_code)
            if signals:
                print(f"  综合评级: {signals['rating']}")
                print(f"  建议操作: {signals['recommendation']}")
                print(f"  风险等级: {signals['risk_level']}")
            
            print()
            
        except Exception as e:
            print(f"  分析失败: {e}\n")
            continue

def demo_batch_analysis():
    """批量分析演示"""
    print("=== 批量技术分析演示 ===\n")
    
    ta = TechnicalIndicators()
    stocks = ["301236", "600036", "000858", "601318", "000333"]  # 软通动力、招商银行、五粮液、中国平安、美的集团
    
    analysis_results = ta.batch_analyze(stocks)
    
    print("股票代码\t名称\t\t综合评级\t建议操作\t风险等级")
    print("-" * 70)
    
    for stock_code, result in analysis_results.items():
        if result and 'name' in result:
            name = result['name'][:8]  # 截断长名称
            rating = result.get('rating', 'N/A')
            recommendation = result.get('recommendation', 'N/A')
            risk_level = result.get('risk_level', 'N/A')
            print(f"{stock_code}\t{name}\t\t{rating}\t\t{recommendation}\t{risk_level}")
    
    print()

if __name__ == "__main__":
    demo_technical_analysis()
    demo_batch_analysis()