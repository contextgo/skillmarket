#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
独立测试技术指标计算逻辑
"""

import pandas as pd
import numpy as np

def calculate_macd(prices, fast_period=12, slow_period=26, signal_period=9):
    """计算MACD指标"""
    prices = pd.Series(prices)
    ema_fast = prices.ewm(span=fast_period, adjust=False).mean()
    ema_slow = prices.ewm(span=slow_period, adjust=False).mean()
    macd_line = ema_fast - ema_slow
    signal_line = macd_line.ewm(span=signal_period, adjust=False).mean()
    histogram = macd_line - signal_line
    
    return {
        'macd': macd_line.iloc[-1],
        'signal': signal_line.iloc[-1],
        'histogram': histogram.iloc[-1]
    }

def calculate_kdj(high, low, close, n=9, m1=3, m2=3):
    """计算KDJ指标"""
    high = pd.Series(high)
    low = pd.Series(low)
    close = pd.Series(close)
    
    rsv = (close - low.rolling(n).min()) / (high.rolling(n).max() - low.rolling(n).min()) * 100
    k = rsv.ewm(alpha=1/m1, adjust=False).mean()
    d = k.ewm(alpha=1/m2, adjust=False).mean()
    j = 3 * k - 2 * d
    
    return {
        'k': k.iloc[-1],
        'd': d.iloc[-1],
        'j': j.iloc[-1]
    }

def calculate_bollinger_bands(prices, window=20, num_std=2):
    """计算布林带"""
    prices = pd.Series(prices)
    ma = prices.rolling(window=window).mean()
    std = prices.rolling(window=window).std()
    upper_band = ma + (std * num_std)
    lower_band = ma - (std * num_std)
    
    return {
        'ma': ma.iloc[-1],
        'upper': upper_band.iloc[-1],
        'lower': lower_band.iloc[-1],
        'width': (upper_band.iloc[-1] - lower_band.iloc[-1]) / ma.iloc[-1]
    }

# 模拟测试数据（软通动力最近价格）
test_prices = [45.2, 46.1, 47.3, 46.8, 47.1, 46.5, 45.9, 46.2, 47.0, 46.99]
test_high = [45.5, 46.3, 47.5, 47.0, 47.3, 46.8, 46.1, 46.4, 47.2, 47.1]
test_low = [44.8, 45.7, 46.9, 46.5, 46.8, 46.2, 45.6, 45.9, 46.7, 46.8]

print("=== 技术指标计算演示 ===")
print(f"测试股票价格序列: {test_prices}")

# MACD计算
macd_result = calculate_macd(test_prices)
print(f"\nMACD指标:")
print(f"  MACD线: {macd_result['macd']:.4f}")
print(f"  信号线: {macd_result['signal']:.4f}")
print(f"  柱状图: {macd_result['histogram']:.4f}")

# KDJ计算  
kdj_result = calculate_kdj(test_high, test_low, test_prices)
print(f"\nKDJ指标:")
print(f"  K值: {kdj_result['k']:.2f}")
print(f"  D值: {kdj_result['d']:.2f}")
print(f"  J值: {kdj_result['j']:.2f}")

# 布林带计算
boll_result = calculate_bollinger_bands(test_prices)
print(f"\n布林带:")
print(f"  中轨(MA20): {boll_result['ma']:.2f}")
print(f"  上轨: {boll_result['upper']:.2f}")
print(f"  下轨: {boll_result['lower']:.2f}")
print(f"  带宽: {boll_result['width']:.4f}")

# 交易信号分析
current_price = test_prices[-1]
print(f"\n=== 交易信号分析 ===")
print(f"当前价格: {current_price:.2f}")

# MACD信号
if macd_result['histogram'] > 0 and macd_result['macd'] > macd_result['signal']:
    print("📈 MACD: 买入信号 (金叉)")
elif macd_result['histogram'] < 0 and macd_result['macd'] < macd_result['signal']:
    print("📉 MACD: 卖出信号 (死叉)")
else:
    print("📊 MACD: 观望")

# KDJ信号
if kdj_result['k'] < 20 and kdj_result['d'] < 20:
    print("📈 KDJ: 超卖区域，潜在买入机会")
elif kdj_result['k'] > 80 and kdj_result['d'] > 80:
    print("📉 KDJ: 超买区域，潜在卖出机会")
else:
    print("📊 KDJ: 正常区间")

# 布林带信号
if current_price < boll_result['lower']:
    print("📈 布林带: 价格触及下轨，超卖信号")
elif current_price > boll_result['upper']:
    print("📉 布林带: 价格触及上轨，超买信号")
else:
    print("📊 布林带: 价格在通道内运行")