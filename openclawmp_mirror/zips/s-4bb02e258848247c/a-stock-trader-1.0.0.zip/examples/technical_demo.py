#!/usr/bin/env python3
"""
A股操盘手 - 技术指标模块使用示例
"""

from a_stock_trader.technical_indicators import (
    calculate_macd, calculate_kdj, calculate_bollinger_bands, 
    calculate_ma, get_all_indicators
)
from a_stock_trader.realtime_quotes import get_realtime_quotes

def demo_single_stock():
    """单股票技术指标分析示例"""
    stock_code = "301236"  # 软通动力
    
    # 获取实时行情数据
    quote_data = get_realtime_quotes(stock_code)
    if not quote_data:
        print(f"无法获取 {stock_code} 的行情数据")
        return
    
    # 计算所有技术指标
    indicators = get_all_indicators(stock_code)
    
    print(f"=== {stock_code} - {quote_data.get('name', 'Unknown')} ===")
    print(f"当前价格: {quote_data.get('price', 'N/A')}")
    print(f"涨跌幅: {quote_data.get('change_pct', 'N/A')}%")
    print()
    
    # MACD指标
    macd_data = indicators.get('macd', {})
    if macd_data:
        print("MACD指标:")
        print(f"  DIF: {macd_data.get('dif', 'N/A'):.3f}")
        print(f"  DEA: {macd_data.get('dea', 'N/A'):.3f}")
        print(f"  MACD: {macd_data.get('macd', 'N/A'):.3f}")
        print(f"  信号: {macd_data.get('signal', 'N/A')}")
        print()
    
    # KDJ指标
    kdj_data = indicators.get('kdj', {})
    if kdj_data:
        print("KDJ指标:")
        print(f"  K: {kdj_data.get('k', 'N/A'):.2f}")
        print(f"  D: {kdj_data.get('d', 'N/A'):.2f}")
        print(f"  J: {kdj_data.get('j', 'N/A'):.2f}")
        print(f"  信号: {kdj_data.get('signal', 'N/A')}")
        print()
    
    # 布林带
    boll_data = indicators.get('bollinger', {})
    if boll_data:
        print("布林带:")
        print(f"  上轨: {boll_data.get('upper', 'N/A'):.2f}")
        print(f"  中轨: {boll_data.get('middle', 'N/A'):.2f}")
        print(f"  下轨: {boll_data.get('lower', 'N/A'):.2f}")
        print(f"  位置: {boll_data.get('position', 'N/A')}")
        print()
    
    # 均线系统
    ma_data = indicators.get('ma', {})
    if ma_data:
        print("均线系统:")
        print(f"  MA5: {ma_data.get('ma5', 'N/A'):.2f}")
        print(f"  MA10: {ma_data.get('ma10', 'N/A'):.2f}")
        print(f"  MA20: {ma_data.get('ma20', 'N/A'):.2f}")
        print(f"  MA60: {ma_data.get('ma60', 'N/A'):.2f}")
        print()

def demo_multiple_stocks():
    """多股票技术指标批量分析示例"""
    stocks = ["301236", "600036", "000001"]
    
    print("=== 多股票技术指标批量分析 ===")
    for stock in stocks:
        try:
            indicators = get_all_indicators(stock)
            quote = get_realtime_quotes(stock)
            
            if quote and indicators:
                price = quote.get('price', 'N/A')
                macd_signal = indicators.get('macd', {}).get('signal', 'N/A')
                kdj_signal = indicators.get('kdj', {}).get('signal', 'N/A')
                
                print(f"{stock}: 价格={price}, MACD={macd_signal}, KDJ={kdj_signal}")
        except Exception as e:
            print(f"{stock}: 分析失败 - {e}")

if __name__ == "__main__":
    print("A股操盘手 - 技术指标模块演示")
    print("=" * 50)
    
    # 单股票分析
    demo_single_stock()
    
    print("-" * 50)
    
    # 多股票批量分析
    demo_multiple_stocks()