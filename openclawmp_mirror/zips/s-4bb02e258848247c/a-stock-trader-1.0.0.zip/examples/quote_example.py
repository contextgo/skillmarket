#!/usr/bin/env python3
"""
A股实时行情数据接口使用示例
"""

from a_stock_trader.data.quote import AStockQuote

def main():
    # 初始化行情获取器
    quote = AStockQuote()
    
    # 获取单个股票实时行情
    print("=== 单个股票行情 ===")
    try:
        stock_data = quote.get_realtime_quote("301236")  # 软通动力
        print(f"股票代码: {stock_data['code']}")
        print(f"股票名称: {stock_data['name']}")
        print(f"当前价格: {stock_data['price']}")
        print(f"涨跌幅: {stock_data['change_pct']}%")
        print(f"成交量: {stock_data['volume']}")
        print(f"成交额: {stock_data['amount']}")
        print(f"最高价: {stock_data['high']}")
        print(f"最低价: {stock_data['low']}")
        print(f"开盘价: {stock_data['open']}")
        print(f"昨收价: {stock_data['prev_close']}")
    except Exception as e:
        print(f"获取单个股票行情失败: {e}")
    
    print("\n=== 多个股票行情 ===")
    try:
        # 获取多个股票实时行情
        stock_codes = ["301236", "600036", "000001"]
        multi_data = quote.get_batch_quotes(stock_codes)
        for code, data in multi_data.items():
            print(f"{code}: {data['name']} - {data['price']}元 ({data['change_pct']}%)")
    except Exception as e:
        print(f"获取多个股票行情失败: {e}")
    
    print("\n=== ETF行情 ===")
    try:
        # 获取ETF行情
        etf_data = quote.get_realtime_quote("510300")  # 沪深300ETF
        print(f"ETF代码: {etf_data['code']}")
        print(f"ETF名称: {etf_data['name']}")
        print(f"当前价格: {etf_data['price']}")
        print(f"涨跌幅: {etf_data['change_pct']}%")
    except Exception as e:
        print(f"获取ETF行情失败: {e}")

if __name__ == "__main__":
    main()