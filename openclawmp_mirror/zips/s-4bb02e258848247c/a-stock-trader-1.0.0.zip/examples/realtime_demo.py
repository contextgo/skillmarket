#!/usr/bin/env python3
"""
A股操盘手 - 实时行情模块使用示例
"""

from a_stock_trader.realtime_quotes import get_realtime_quotes, get_stock_info

def main():
    # 获取单只股票实时行情
    stock_code = "301236"  # 软通动力
    quote = get_realtime_quotes(stock_code)
    print(f"股票: {quote['name']} ({quote['code']})")
    print(f"当前价格: {quote['price']}")
    print(f"涨跌幅: {quote['change_pct']}%")
    print(f"成交量: {quote['volume']}")
    print(f"成交额: {quote['amount']}")
    print("-" * 40)
    
    # 获取多只股票实时行情
    stock_codes = ["301236", "600036", "000001"]
    quotes = get_realtime_quotes(stock_codes)
    for quote in quotes:
        print(f"{quote['name']}: {quote['price']} ({quote['change_pct']}%)")

if __name__ == "__main__":
    main()