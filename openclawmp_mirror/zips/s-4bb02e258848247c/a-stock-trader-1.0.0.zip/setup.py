from setuptools import setup, find_packages

setup(
    name="a-stock-trader",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "requests>=2.25.0",
        "pandas>=1.3.0",
    ],
    python_requires=">=3.8",
)