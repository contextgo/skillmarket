#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
实时行情模块测试脚本
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from realtime_quote import get_realtime_quote, get_realtime_quotes, RealtimeQuoteError

def test_single_stock():
    """测试单个股票获取"""
    print("=== 测试单个股票 ===")
    try:
        # 测试A股股票
        quote = get_realtime_quote("000001")
        print(f"✓ 成功获取 {quote['stock_name']} ({quote['stock_code']})")
        print(f"  当前价格: {quote['current_price']}")
        print(f"  涨跌幅: {quote['change_percent']:.2f}%")
        print(f"  成交量: {quote['volume']:,}")
        return True
    except Exception as e:
        print(f"✗ 获取失败: {e}")
        return False

def test_etf():
    """测试ETF获取"""
    print("\n=== 测试ETF ===")
    try:
        # 测试ETF
        quote = get_realtime_quote("510050")
        print(f"✓ 成功获取 {quote['stock_name']} ({quote['stock_code']})")
        print(f"  当前价格: {quote['current_price']}")
        print(f"  涨跌幅: {quote['change_percent']:.2f}%")
        return True
    except Exception as e:
        print(f"✗ 获取失败: {e}")
        return False

def test_fund():
    """测试基金获取"""
    print("\n=== 测试基金 ===")
    try:
        # 测试基金（创业板ETF）
        quote = get_realtime_quote("159915")
        print(f"✓ 成功获取 {quote['stock_name']} ({quote['stock_code']})")
        print(f"  当前价格: {quote['current_price']}")
        print(f"  涨跌幅: {quote['change_percent']:.2f}%")
        return True
    except Exception as e:
        print(f"✗ 获取失败: {e}")
        return False

def test_batch():
    """测试批量获取"""
    print("\n=== 测试批量获取 ===")
    try:
        stock_codes = ["000001", "600519", "510050"]
        quotes = get_realtime_quotes(stock_codes)
        
        for code, quote in quotes.items():
            if quote['status'] == 'success':
                print(f"✓ {code}: {quote['stock_name']} - {quote['current_price']}")
            else:
                print(f"✗ {code}: {quote.get('error', 'Unknown error')}")
        return True
    except Exception as e:
        print(f"✗ 批量获取失败: {e}")
        return False

def test_error_handling():
    """测试错误处理"""
    print("\n=== 测试错误处理 ===")
    try:
        # 测试无效代码
        get_realtime_quote("INVALID123")
        print("✗ 应该抛出异常但没有")
        return False
    except RealtimeQuoteError as e:
        print(f"✓ 正确捕获异常: {e}")
        return True
    except Exception as e:
        print(f"✗ 捕获了意外异常: {e}")
        return False

def main():
    """主测试函数"""
    print("A股实时行情模块测试\n")
    
    tests = [
        test_single_stock,
        test_etf,
        test_fund,
        test_batch,
        test_error_handling
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n=== 测试结果 ===")
    print(f"通过: {passed}/{total}")
    
    if passed == total:
        print("🎉 所有测试通过！")
        return 0
    else:
        print("❌ 部分测试失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())