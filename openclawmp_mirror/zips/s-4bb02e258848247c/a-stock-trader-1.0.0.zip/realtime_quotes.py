#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股实时行情模块
支持股票、ETF、基金的实时价格、涨跌幅、成交量等数据获取
使用腾讯财经API
"""

import requests
import json
import time
from typing import Dict, List, Optional

class RealtimeQuotes:
    """A股实时行情获取类"""
    
    def __init__(self):
        self.base_url = "http://qt.gtimg.cn/q="
        self.timeout = 10
        
    def _parse_tencent_data(self, data: str) -> Dict:
        """
        解析腾讯财经返回的数据
        v_s_z301236="51~软通动力~301236~74.50~72.45~74.88~73.50~73.99~74.50~
        74.49~62262~462736212~74.50~175~74.49~148~74.48~127~74.47~89~74.46~115~
        ~2024-03-02 15:00:03~0~0~38.25~74.50~74.50~123456789~12345678~0~0~0~
        ~74.50~74.50~74.50~74.50~74.50~74.50~74.50~74.50~74.50~74.50"
        """
        if not data or '="' not in data:
            return {}
            
        try:
            # 提取等号后面的内容
            content = data.split('="')[1].rstrip('"')
            fields = content.split('~')
            
            if len(fields) < 10:
                return {}
                
            stock_info = {
                'code': fields[2] if len(fields) > 2 else '',
                'name': fields[1] if len(fields) > 1 else '',
                'current_price': float(fields[3]) if len(fields) > 3 and fields[3] else 0.0,
                'yesterday_close': float(fields[4]) if len(fields) > 4 and fields[4] else 0.0,
                'open_price': float(fields[5]) if len(fields) > 5 and fields[5] else 0.0,
                'high_price': float(fields[6]) if len(fields) > 6 and fields[6] else 0.0,
                'low_price': float(fields[7]) if len(fields) > 7 and fields[7] else 0.0,
                'volume': int(fields[9]) if len(fields) > 9 and fields[9] else 0,
                'amount': int(fields[10]) if len(fields) > 10 and fields[10] else 0,
                'update_time': fields[30] if len(fields) > 30 else ''
            }
            
            # 计算涨跌幅
            if stock_info['yesterday_close'] > 0:
                stock_info['change_pct'] = round(
                    (stock_info['current_price'] - stock_info['yesterday_close']) / 
                    stock_info['yesterday_close'] * 100, 2
                )
            else:
                stock_info['change_pct'] = 0.0
                
            return stock_info
            
        except (ValueError, IndexError) as e:
            print(f"解析数据错误: {e}")
            return {}
    
    def get_stock_quote(self, stock_code: str) -> Dict:
        """
        获取单个股票的实时行情
        Args:
            stock_code: 股票代码，如 '301236' 或 'sh600036'
        Returns:
            股票行情字典
        """
        # 格式化股票代码
        if stock_code.startswith(('sh', 'sz')):
            formatted_code = stock_code
        else:
            if stock_code.startswith('6'):
                formatted_code = f'sh{stock_code}'
            elif stock_code.startswith(('0', '3')):
                formatted_code = f'sz{stock_code}'
            else:
                formatted_code = stock_code
                
        url = f"{self.base_url}{formatted_code}"
        
        try:
            response = requests.get(url, timeout=self.timeout)
            response.encoding = 'gbk'
            data = response.text.strip()
            return self._parse_tencent_data(data)
            
        except Exception as e:
            print(f"获取行情失败 {stock_code}: {e}")
            return {}
    
    def get_multiple_quotes(self, stock_codes: List[str]) -> Dict[str, Dict]:
        """
        批量获取多个股票的实时行情
        Args:
            stock_codes: 股票代码列表
        Returns:
            {股票代码: 行情数据} 的字典
        """
        results = {}
        
        # 腾讯财经支持批量查询，用逗号分隔
        batch_size = 20  # 每次最多查询20个
        for i in range(0, len(stock_codes), batch_size):
            batch = stock_codes[i:i+batch_size]
            
            # 格式化代码
            formatted_batch = []
            for code in batch:
                if code.startswith(('sh', 'sz')):
                    formatted_batch.append(code)
                else:
                    if code.startswith('6'):
                        formatted_batch.append(f'sh{code}')
                    elif code.startswith(('0', '3')):
                        formatted_batch.append(f'sz{code}')
                    else:
                        formatted_batch.append(code)
            
            url = f"{self.base_url}{','.join(formatted_batch)}"
            
            try:
                response = requests.get(url, timeout=self.timeout)
                response.encoding = 'gbk'
                lines = response.text.strip().split('\n')
                
                for line in lines:
                    if line.strip():
                        quote = self._parse_tencent_data(line.strip())
                        if quote and 'code' in quote:
                            results[quote['code']] = quote
                            
            except Exception as e:
                print(f"批量获取行情失败: {e}")
                # 单个重试
                for code in batch:
                    results[code] = self.get_stock_quote(code)
                    
            # 避免请求过于频繁
            time.sleep(0.1)
            
        return results

def main():
    """测试函数"""
    quotes = RealtimeQuotes()
    
    # 测试单个股票
    print("=== 单个股票测试 ===")
    single_quote = quotes.get_stock_quote("301236")
    print(json.dumps(single_quote, indent=2, ensure_ascii=False))
    
    print("\n=== 批量股票测试 ===")
    # 测试多个股票
    test_codes = ["301236", "600036", "000001"]
    multi_quotes = quotes.get_multiple_quotes(test_codes)
    print(json.dumps(multi_quotes, indent=2, ensure_ascii=False))

if __name__ == "__main__":
    main()