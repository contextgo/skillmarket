# A股操盘手 - 纯国内数据源架构

## 🎯 设计原则
- **完全移除国际API依赖**（Yahoo Finance, CoinGecko, Google News等）
- **专注A股市场**，使用国内合规数据源
- **高可靠性**，每个功能至少2个备用数据源
- **实时性优先**，满足交易决策需求

## 📊 核心数据源

### 1. 腾讯财经（主力）
- **接口**: `http://qt.gtimg.cn/q=sz300059`
- **数据**: 实时价格、涨跌幅、成交量、成交额
- **优势**: 免费、稳定、低延迟
- **格式**: `v_sz300059="1~东方财富~300059~15.88~15.76~15.70~...`

### 2. 东方财富（备用）
- **接口**: `https://push2.eastmoney.com/api/qt/stock/get`
- **数据**: 行情、资金流、技术指标
- **优势**: 数据全面，包含主力资金流向
- **参数**: `invt=2&fltt=2&fields=f43,f44,f45,f46...`

### 3. 同花顺（热点数据）
- **接口**: `http://stockpage.10jqka.com.cn/spService/stockhot`
- **数据**: 热门股票、概念板块、资金热度
- **优势**: A股特色热点分析

### 4. 财联社（新闻数据）
- **接口**: `https://www.cailianpress.com/roll.html`
- **数据**: 实时财经新闻、重大公告
- **优势**: 专业财经媒体，信息权威

## 🔧 功能模块调整

### 1. 实时行情模块
**移除**: Yahoo Finance 依赖  
**保留**: 腾讯财经主力 + 东方财富备用
```python
def get_realtime_data(stock_code):
    # 优先腾讯财经
    data = fetch_tencent_data(stock_code)
    if data is None:
        # 备用东方财富
        data = fetch_eastmoney_data(stock_code)
    return data
```

### 2. 风险管理模块
**移除**: 国际恐慌贪婪指数  
**替换**: A股情绪指标（基于涨停板数量、成交量变化率）
```python
def calculate_a_share_sentiment():
    # 基于涨停板数量和跌停板数量
    limit_up_count = get_limit_up_stocks()
    limit_down_count = get_limit_down_stocks()
    sentiment_score = (limit_up_count - limit_down_count) / (limit_up_count + limit_down_count + 1)
    return sentiment_score
```

### 3. 热点扫描器模块
**移除**: CoinGecko/Google News 依赖  
**保留**: 同花顺热点 + 财联社新闻 + 涨停板监控
```python
def scan_a_share_hot_trends():
    # 同花顺热点股票
    hot_stocks = fetch_ths_hot_stocks()
    # 财联社重大新闻
    breaking_news = fetch_cailianpress_news()
    # 涨停板监控
    limit_up_stocks = monitor_limit_up()
    return combine_hot_trends(hot_stocks, breaking_news, limit_up_stocks)
```

### 4. 投资组合管理
**移除**: 国际资产支持  
**专注**: A股股票、ETF、基金
```python
def analyze_portfolio(portfolio):
    # 只处理A股相关资产
    a_share_holdings = [h for h in portfolio if is_a_share(h['code'])]
    return calculate_pnl(a_share_holdings)
```

## 🛡️ 错误处理机制

### 1. 数据源故障处理
```python
def robust_data_fetch(primary_source, backup_sources):
    try:
        return primary_source()
    except Exception as e:
        log_error(f"Primary source failed: {e}")
        for backup in backup_sources:
            try:
                return backup()
            except Exception as be:
                log_error(f"Backup source failed: {be}")
        raise DataFetchError("All data sources failed")
```

### 2. 网络超时设置
- **腾讯财经**: 3秒超时
- **东方财富**: 5秒超时  
- **同花顺**: 5秒超时
- **财联社**: 10秒超时

## 📈 性能优化

### 1. 批量请求
- 单次请求最多获取50只股票数据
- 减少API调用次数

### 2. 本地缓存
- 行情数据缓存5秒（避免重复请求）
- 新闻数据缓存30秒
- 热点数据缓存1分钟

### 3. 异步处理
- 数据获取采用异步并发
- 不阻塞主交易逻辑

## ✅ 验证测试

### 1. 数据源可用性测试
```bash
# 测试腾讯财经
curl "http://qt.gtimg.cn/q=sz300059"

# 测试东方财富  
curl "https://push2.eastmoney.com/api/qt/stock/get?invt=2&fltt=2&secid=0.300059"

# 测试同花顺
curl "http://stockpage.10jqka.com.cn/spService/stockhot"
```

### 2. 功能完整性测试
- [ ] 实时行情获取
- [ ] 技术指标计算  
- [ ] 风险管理逻辑
- [ ] 热点扫描功能
- [ ] 投资组合分析

## 🚀 实施计划

### 第一阶段（今日完成）
1. **移除所有国际API调用**
2. **集成腾讯财经 + 东方财富双数据源**
3. **实现基础错误处理**

### 第二阶段（明天完成）
4. **集成同花顺热点 + 财联社新闻**
5. **实现A股情绪指标**
6. **完整功能测试**

### 第三阶段（后天完成）
7. **性能优化和缓存机制**
8. **集成测试和稳定性验证**
9. **准备Moltbook发布**

## ⚠️ 注意事项

- **合规性**: 所有数据源均为公开免费接口，符合国内法规
- **稳定性**: 国内数据源比国际API更稳定，响应更快
- **本土化**: 完全适配A股交易特点和用户习惯
- **可维护**: 代码结构清晰，便于后续扩展

**目标**: 构建完全自主可控的A股智能交易系统，摆脱对国际API的依赖，确保系统稳定性和实时性。