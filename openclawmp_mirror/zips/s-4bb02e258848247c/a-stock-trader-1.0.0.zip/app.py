#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - 主应用入口
整合行情数据接口、技术指标分析和Web服务
"""

import sys
import os
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.resolve()
sys.path.insert(0, str(project_root))

from flask import Flask, jsonify
from flask_cors import CORS
from api.routes import init_routes
from api.indicators import init_indicators_routes

def create_app():
    """创建Flask应用实例"""
    app = Flask(__name__)
    
    # 启用CORS（允许跨域请求）
    CORS(app)
    
    # 初始化路由
    init_routes(app)
    init_indicators_routes(app)
    
    # 健康检查端点
    @app.route('/health')
    def health_check():
        return jsonify({
            'status': 'healthy',
            'service': 'a-stock-trader',
            'port': 8080
        })
    
    return app

if __name__ == '__main__':
    app = create_app()
    print("🚀 A股操盘手Web服务启动中...")
    print(f"📍 监听地址: http://0.0.0.0:8080")
    print(f"📊 健康检查: http://localhost:8080/health")
    print(f"📈 行情API: http://localhost:8080/api/quote/<stock_code>")
    print(f"🔧 技术指标API: http://localhost:8080/api/indicators/<stock_code>")
    app.run(host='0.0.0.0', port=8080, debug=True)