"""
A股操盘手 - 行情数据API路由
提供实时行情数据接口
"""

from flask import Blueprint, request, jsonify
from flask_cors import cross_origin
import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from realtime_quote import get_realtime_quote, get_realtime_quotes, RealtimeQuoteError

# 创建蓝图
market_data_bp = Blueprint('market_data', __name__, url_prefix='/api/market')

@market_data_bp.route('/quote/<stock_code>', methods=['GET'])
@cross_origin()
def get_stock_quote(stock_code):
    """
    获取单个股票的实时行情
    
    Args:
        stock_code: 股票代码 (如 '000001', '600519', '510050')
        
    Returns:
        JSON格式的行情数据
    """
    try:
        # 获取查询参数
        timeout = request.args.get('timeout', 10, type=int)
        
        # 获取实时行情
        quote_data = get_realtime_quote(stock_code, timeout=timeout)
        
        return jsonify({
            'status': 'success',
            'data': quote_data
        })
        
    except RealtimeQuoteError as e:
        return jsonify({
            'status': 'error',
            'message': str(e)
        }), 400
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'服务器内部错误: {str(e)}'
        }), 500

@market_data_bp.route('/quotes', methods=['POST'])
@cross_origin()
def get_multiple_quotes():
    """
    批量获取多个股票的实时行情
    
    Request Body:
        {
            "stock_codes": ["000001", "600519", "510050"],
            "timeout": 10
        }
        
    Returns:
        JSON格式的批量行情数据
    """
    try:
        # 解析请求体
        data = request.get_json()
        if not data or 'stock_codes' not in data:
            return jsonify({
                'status': 'error',
                'message': '请求体必须包含stock_codes字段'
            }), 400
        
        stock_codes = data['stock_codes']
        if not isinstance(stock_codes, list):
            return jsonify({
                'status': 'error',
                'message': 'stock_codes必须是数组'
            }), 400
        
        timeout = data.get('timeout', 10)
        
        # 批量获取行情
        quotes_data = get_realtime_quotes(stock_codes, timeout=timeout)
        
        return jsonify({
            'status': 'success',
            'data': quotes_data
        })
        
    except Exception as e:
        return jsonify({
            'status': 'error',
            'message': f'服务器内部错误: {str(e)}'
        }), 500

@market_data_bp.route('/health', methods=['GET'])
@cross_origin()
def health_check():
    """
    健康检查接口
    """
    return jsonify({
        'status': 'healthy',
        'service': 'a-stock-trader-market-data',
        'timestamp': __import__('datetime').datetime.now().isoformat()
    })

def init_routes(app):
    """初始化路由"""
    app.register_blueprint(market_data_bp)