"""
A股操盘手 - 技术指标API接口
提供MACD、KDJ、布林带、均线等技术指标的REST API
"""

from flask import Blueprint, request, jsonify
import pandas as pd
import numpy as np
import logging
import sys
import os

# 添加项目根目录到Python路径
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 导入技术指标模块
try:
    from modules.technical_indicators import TechnicalIndicators, get_technical_indicators
except ImportError as e:
    print(f"导入技术指标模块失败: {e}")
    # 如果导入失败，创建一个简单的模拟函数
    def get_technical_indicators(stock_code, data):
        return {
            'indicators': data,
            'signals': {'error': '技术指标模块未正确加载'}
        }

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 创建蓝图
indicators_bp = Blueprint('indicators', __name__)

def create_sample_data(days=100):
    """创建示例股票数据用于测试"""
    dates = pd.date_range('2024-01-01', periods=days, freq='D')
    np.random.seed(42)
    base_price = 50.0
    prices = [base_price]
    
    for i in range(1, days):
        change = np.random.normal(0, 0.02)  # 2%的日波动
        new_price = prices[-1] * (1 + change)
        prices.append(new_price)
    
    prices = np.array(prices)
    
    sample_data = pd.DataFrame({
        'date': dates,
        'open': prices + np.random.randn(days) * 0.5,
        'high': prices + np.abs(np.random.randn(days)) * 0.8,
        'low': prices - np.abs(np.random.randn(days)) * 0.8,
        'close': prices,
        'volume': np.random.randint(1000000, 10000000, days)
    })
    
    # 确保high >= close >= low
    sample_data['high'] = np.maximum(sample_data['high'], sample_data['close'])
    sample_data['low'] = np.minimum(sample_data['low'], sample_data['close'])
    
    return sample_data

@indicators_bp.route('/api/indicators/<stock_code>', methods=['GET'])
def get_stock_indicators(stock_code):
    """
    获取指定股票的技术指标
    
    Args:
        stock_code: 股票代码 (如 '000001', '600519')
        
    Query Parameters:
        days: 获取多少天的历史数据 (默认100天)
        
    Returns:
        JSON格式的技术指标数据和信号分析
    """
    try:
        days = int(request.args.get('days', 100))
        if days < 10 or days > 365:
            days = 100
            
        # 创建示例数据（在实际应用中，这里应该从数据库或API获取真实历史数据）
        sample_data = create_sample_data(days)
        
        # 计算技术指标
        result = get_technical_indicators(stock_code, sample_data)
        
        # 准备响应数据
        response_data = {
            'stock_code': stock_code,
            'days': days,
            'signals': result['signals'],
            'indicators': {
                'dates': result['indicators']['date'].dt.strftime('%Y-%m-%d').tolist(),
                'close': result['indicators']['close'].round(2).tolist(),
                'MA5': result['indicators']['MA5'].round(2).tolist() if 'MA5' in result['indicators'] else [],
                'MA10': result['indicators']['MA10'].round(2).tolist() if 'MA10' in result['indicators'] else [],
                'MA20': result['indicators']['MA20'].round(2).tolist() if 'MA20' in result['indicators'] else [],
                'DIF': result['indicators']['DIF'].round(4).tolist() if 'DIF' in result['indicators'] else [],
                'DEA': result['indicators']['DEA'].round(4).tolist() if 'DEA' in result['indicators'] else [],
                'MACD_Hist': result['indicators']['MACD_Hist'].round(4).tolist() if 'MACD_Hist' in result['indicators'] else [],
                'K': result['indicators']['K'].round(2).tolist() if 'K' in result['indicators'] else [],
                'D': result['indicators']['D'].round(2).tolist() if 'D' in result['indicators'] else [],
                'J': result['indicators']['J'].round(2).tolist() if 'J' in result['indicators'] else [],
                'Upper_Band': result['indicators']['Upper_Band'].round(2).tolist() if 'Upper_Band' in result['indicators'] else [],
                'Middle_Band': result['indicators']['Middle_Band'].round(2).tolist() if 'Middle_Band' in result['indicators'] else [],
                'Lower_Band': result['indicators']['Lower_Band'].round(2).tolist() if 'Lower_Band' in result['indicators'] else []
            }
        }
        
        logger.info(f"成功获取 {stock_code} 的技术指标数据")
        return jsonify(response_data)
        
    except Exception as e:
        logger.error(f"获取技术指标时出错: {str(e)}")
        return jsonify({
            'error': str(e),
            'stock_code': stock_code
        }), 500

@indicators_bp.route('/api/indicators/batch', methods=['POST'])
def get_batch_indicators():
    """
    批量获取多个股票的技术指标
    
    Request Body:
        {
            "stock_codes": ["000001", "600519", "300750"],
            "days": 100
        }
        
    Returns:
        JSON格式的批量技术指标数据
    """
    try:
        data = request.get_json()
        if not data or 'stock_codes' not in data:
            return jsonify({'error': '缺少stock_codes参数'}), 400
            
        stock_codes = data['stock_codes']
        days = data.get('days', 100)
        
        if not isinstance(stock_codes, list) or len(stock_codes) == 0:
            return jsonify({'error': 'stock_codes必须是非空数组'}), 400
            
        if len(stock_codes) > 10:
            return jsonify({'error': '一次最多请求10个股票'}), 400
            
        results = {}
        for stock_code in stock_codes:
            try:
                sample_data = create_sample_data(days)
                result = get_technical_indicators(stock_code, sample_data)
                results[stock_code] = {
                    'signals': result['signals'],
                    'success': True
                }
            except Exception as e:
                results[stock_code] = {
                    'error': str(e),
                    'success': False
                }
                
        return jsonify(results)
        
    except Exception as e:
        logger.error(f"批量获取技术指标时出错: {str(e)}")
        return jsonify({'error': str(e)}), 500

def init_indicators_routes(app):
    """初始化技术指标路由"""
    app.register_blueprint(indicators_bp)