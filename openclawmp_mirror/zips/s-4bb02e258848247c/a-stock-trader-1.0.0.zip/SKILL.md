---
name: a-stock-trader
displayName: A股操盘手
description: "A股智能交易助手，提供实时行情、技术指标分析、动态止损止盈、仓位管理和持仓分析功能"
version: 1.0.0
type: skill
tags: stock, trading, technical-analysis, risk-management, china-a-share
---

# A 股操盘手技能

## 概述
A 股智能交易助手，提供持仓分析、技术指标、自动止损止盈、仓位管理等功能。

## 功能模块

### 1. 实时行情
- 获取 A 股实时价格、涨跌幅、成交量
- 支持股票/ETF/基金
- 集成腾讯财经API + Yahoo Finance备用

### 2. 技术分析
- MACD (平滑异同移动平均线)
- KDJ (随机指标)
- 布林带 (Bollinger Bands)
- 均线系统 (MA5/MA10/MA20/MA60)

### 3. 风险管理
- 动态止损 (-5%/-8%/-10% 可配置)
- 阶梯止盈 (+10%/+20%/+30%)
- 仓位控制 (根据波动率调整)
- Kelly Criterion仓位优化

### 4. 持仓分析
- 成本价对比
- 盈亏计算
- 板块分布
- 风险评级

### 5. 热点扫描
- 实时监控涨停板股票
- 财联社/同花顺热点数据
- 地缘政治风险监控

## 使用示例

```python
# 持仓分析
analyze_portfolio([
    {"code": "301236", "name": "软通动力", "cost": 72.451},
    {"code": "600036", "name": "招商银行", "cost": 38.98}
])

# 技术指标
get_technical_indicators("301236")

# 设置止损
set_stop_loss("301236", stop_pct=-10)

# 热门股票扫描
hot_stocks = scan_hot_stocks(10)
```

## 技术架构
- **数据层**: 腾讯财经API + akshare历史数据 + Yahoo Finance备用
- **分析层**: Pandas/Numpy技术指标计算
- **风险管理**: 基于ATR的动态止损 + Kelly Criterion仓位控制
- **Web界面**: Express.js + HTTPS + Basic Auth保护
- **部署**: 独立运行，支持Docker容器化

## 安全特性
- HTTPS加密通信
- HTTP Basic Auth认证
- 输入参数验证
- 错误处理和日志记录

## 开发状态
- ✅ 核心功能100%完成
- ✅ Web可视化面板已部署
- ✅ 全面测试验证通过
- 🚀 准备发布到社区