"""
A股技术指标计算模块
支持MACD、KDJ、布林带、均线系统等核心指标
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Union, Optional
from datetime import datetime, timedelta


class TechnicalIndicators:
    """技术指标计算引擎"""
    
    def __init__(self):
        self.data_cache = {}
    
    def _get_historical_data(self, stock_code: str, days: int = 60) -> pd.DataFrame:
        """
        获取历史K线数据（模拟实现，实际应对接行情API）
        返回: DataFrame with columns ['date', 'open', 'high', 'low', 'close', 'volume']
        """
        # TODO: 实际项目中这里应该调用真实的K线数据API
        # 目前使用模拟数据进行指标逻辑验证
        dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
        np.random.seed(hash(stock_code) % 1000000)
        base_price = 50.0
        prices = [base_price]
        
        for i in range(1, days):
            change = np.random.normal(0, 0.02)  # 2% daily volatility
            new_price = prices[-1] * (1 + change)
            prices.append(max(new_price, 1.0))  # 防止价格为负
        
        closes = prices
        opens = [p * (1 + np.random.normal(0, 0.005)) for p in closes]
        highs = [max(o, c) * (1 + abs(np.random.normal(0, 0.01))) for o, c in zip(opens, closes)]
        lows = [min(o, c) * (1 - abs(np.random.normal(0, 0.01))) for o, c in zip(opens, closes)]
        volumes = np.random.randint(1000000, 10000000, days)
        
        df = pd.DataFrame({
            'date': dates,
            'open': opens,
            'high': highs,
            'low': lows,
            'close': closes,
            'volume': volumes
        })
        return df.sort_values('date').reset_index(drop=True)
    
    def calculate_macd(self, stock_code: str, fast_period: int = 12, 
                      slow_period: int = 26, signal_period: int = 9) -> Dict:
        """
        计算MACD指标
        返回: {'macd': float, 'signal': float, 'histogram': float, 'trend': str}
        """
        df = self._get_historical_data(stock_code, 100)
        close_prices = df['close'].values
        
        # 计算EMA
        ema_fast = pd.Series(close_prices).ewm(span=fast_period, adjust=False).mean().iloc[-1]
        ema_slow = pd.Series(close_prices).ewm(span=slow_period, adjust=False).mean().iloc[-1]
        
        # MACD线
        macd_line = ema_fast - ema_slow
        
        # 信号线（MACD的EMA）
        macd_series = pd.Series(close_prices).ewm(span=fast_period, adjust=False).mean() - \
                     pd.Series(close_prices).ewm(span=slow_period, adjust=False).mean()
        signal_line = macd_series.ewm(span=signal_period, adjust=False).mean().iloc[-1]
        
        # 柱状图
        histogram = macd_line - signal_line
        
        # 趋势判断
        if macd_line > signal_line and histogram > 0:
            trend = "强势上涨"
        elif macd_line > signal_line and histogram < 0:
            trend = "温和上涨"
        elif macd_line < signal_line and histogram < 0:
            trend = "弱势下跌"
        else:
            trend = "震荡整理"
        
        return {
            'macd': round(macd_line, 4),
            'signal': round(signal_line, 4),
            'histogram': round(histogram, 4),
            'trend': trend
        }
    
    def calculate_kdj(self, stock_code: str, n: int = 9, m1: int = 3, m2: int = 3) -> Dict:
        """
        计算KDJ指标
        返回: {'k': float, 'd': float, 'j': float, 'signal': str}
        """
        df = self._get_historical_data(stock_code, 30)
        
        # 计算RSV (Raw Stochastic Value)
        low_n = df['low'].rolling(window=n).min()
        high_n = df['high'].rolling(window=n).max()
        rsv = (df['close'] - low_n) / (high_n - low_n) * 100
        
        # K值和D值
        k = rsv.ewm(alpha=1/m1, adjust=False).mean()
        d = k.ewm(alpha=1/m2, adjust=False).mean()
        j = 3 * k - 2 * d
        
        k_val = round(k.iloc[-1], 2)
        d_val = round(d.iloc[-1], 2)
        j_val = round(j.iloc[-1], 2)
        
        # 信号判断
        if k_val > 80 or d_val > 80:
            signal = "超买区域"
        elif k_val < 20 or d_val < 20:
            signal = "超卖区域"
        elif k_val > d_val and k_val < 50:
            signal = "买入信号"
        elif k_val < d_val and k_val > 50:
            signal = "卖出信号"
        else:
            signal = "中性区域"
        
        return {
            'k': k_val,
            'd': d_val,
            'j': j_val,
            'signal': signal
        }
    
    def calculate_bollinger_bands(self, stock_code: str, period: int = 20, std_dev: int = 2) -> Dict:
        """
        计算布林带指标
        返回: {'upper': float, 'middle': float, 'lower': float, 'bandwidth': float, 'position': str}
        """
        df = self._get_historical_data(stock_code, 50)
        close_prices = df['close']
        
        # 中轨（移动平均线）
        middle_band = close_prices.rolling(window=period).mean().iloc[-1]
        
        # 标准差
        std = close_prices.rolling(window=period).std().iloc[-1]
        
        # 上轨和下轨
        upper_band = middle_band + (std_dev * std)
        lower_band = middle_band - (std_dev * std)
        
        current_price = close_prices.iloc[-1]
        bandwidth = (upper_band - lower_band) / middle_band
        
        # 位置判断
        if current_price > upper_band:
            position = "突破上轨"
        elif current_price < lower_band:
            position = "跌破下轨"
        elif current_price > middle_band:
            position = "中轨上方"
        else:
            position = "中轨下方"
        
        return {
            'upper': round(upper_band, 2),
            'middle': round(middle_band, 2),
            'lower': round(lower_band, 2),
            'bandwidth': round(bandwidth, 4),
            'position': position
        }
    
    def calculate_ma_system(self, stock_code: str, periods: List[int] = [5, 10, 20, 60]) -> Dict:
        """
        计算多周期均线系统
        返回: {'ma5': float, 'ma10': float, 'ma20': float, 'ma60': float, 'trend': str}
        """
        df = self._get_historical_data(stock_code, max(periods) + 10)
        close_prices = df['close']
        
        ma_values = {}
        for period in periods:
            ma_key = f'ma{period}'
            ma_values[ma_key] = round(close_prices.rolling(window=period).mean().iloc[-1], 2)
        
        # 趋势判断（基于短期均线上穿长期均线）
        ma5, ma10, ma20, ma60 = ma_values['ma5'], ma_values['ma10'], ma_values['ma20'], ma_values['ma60']
        
        if ma5 > ma10 > ma20 > ma60:
            trend = "强势多头"
        elif ma5 > ma10 > ma20 and ma20 < ma60:
            trend = "中期多头"
        elif ma5 < ma10 < ma20 < ma60:
            trend = "强势空头"
        elif ma5 < ma10 < ma20 and ma20 > ma60:
            trend = "中期空头"
        else:
            trend = "震荡整理"
        
        ma_values['trend'] = trend
        return ma_values
    
    def get_all_indicators(self, stock_code: str) -> Dict:
        """
        获取所有技术指标的综合分析
        """
        try:
            macd = self.calculate_macd(stock_code)
            kdj = self.calculate_kdj(stock_code)
            bollinger = self.calculate_bollinger_bands(stock_code)
            ma_system = self.calculate_ma_system(stock_code)
            
            return {
                'stock_code': stock_code,
                'macd': macd,
                'kdj': kdj,
                'bollinger': bollinger,
                'ma_system': ma_system,
                'analysis_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        except Exception as e:
            return {
                'stock_code': stock_code,
                'error': str(e),
                'analysis_time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }