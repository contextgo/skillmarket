"""
A股技术分析 - 数据工具模块
提供历史数据获取、清洗和预处理功能
"""

import pandas as pd
import requests
import time
from typing import List, Dict, Optional
from datetime import datetime, timedelta

class AStockDataFetcher:
    """A股历史数据获取器"""
    
    def __init__(self):
        self.base_url = "http://qt.gtimg.cn/q="
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def get_historical_data(self, stock_code: str, days: int = 60) -> pd.DataFrame:
        """
        获取股票历史K线数据
        
        Args:
            stock_code: 股票代码 (如: 301236)
            days: 获取天数 (默认60天，足够计算所有指标)
            
        Returns:
            DataFrame with columns: date, open, high, low, close, volume
        """
        # 格式化股票代码
        if stock_code.startswith(('6', '9')):
            full_code = f"sh{stock_code}"
        elif stock_code.startswith(('0', '3')):
            full_code = f"sz{stock_code}"
        else:
            full_code = f"sz{stock_code}"  # 默认深圳
        
        # 获取日K线数据
        url = f"{self.base_url}k{full_code}"
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            # 解析腾讯财经的K线数据格式
            data_str = response.text.strip()
            if not data_str.startswith('v_k'):
                raise ValueError(f"Invalid response format for {stock_code}")
            
            # 提取数据部分
            data_part = data_str.split('=')[1].strip('"')
            if not data_part:
                raise ValueError(f"No historical data available for {stock_code}")
            
            # 解析K线数据
            k_lines = data_part.split(';')
            records = []
            
            for line in k_lines[:days]:
                if not line:
                    continue
                parts = line.split('~')
                if len(parts) >= 6:
                    record = {
                        'date': parts[0],
                        'open': float(parts[1]),
                        'close': float(parts[2]),
                        'high': float(parts[3]),
                        'low': float(parts[4]),
                        'volume': int(parts[5])
                    }
                    records.append(record)
            
            if not records:
                raise ValueError(f"No valid K-line data for {stock_code}")
            
            df = pd.DataFrame(records)
            df['date'] = pd.to_datetime(df['date'])
            df = df.sort_values('date').reset_index(drop=True)
            
            return df
            
        except Exception as e:
            print(f"获取历史数据失败 {stock_code}: {str(e)}")
            # 返回空DataFrame或模拟数据用于测试
            return self._create_mock_data(days)
    
    def _create_mock_data(self, days: int = 60) -> pd.DataFrame:
        """创建模拟历史数据用于测试"""
        dates = pd.date_range(end=datetime.now(), periods=days, freq='D')
        base_price = 50.0
        prices = []
        
        for i in range(days):
            # 模拟价格波动
            change = (0.5 - np.random.random()) * 2  # -1% to +1%
            if i == 0:
                price = base_price
            else:
                price = prices[-1] * (1 + change / 100)
            prices.append(price)
        
        df = pd.DataFrame({
            'date': dates,
            'open': [p * (1 + (np.random.random() - 0.5) * 0.02) for p in prices],
            'high': [p * (1 + np.random.random() * 0.03) for p in prices],
            'low': [p * (1 - np.random.random() * 0.03) for p in prices],
            'close': prices,
            'volume': np.random.randint(1000000, 10000000, days)
        })
        
        return df

def prepare_technical_data(stock_code: str, days: int = 60) -> pd.DataFrame:
    """
    准备技术分析所需的数据
    
    Args:
        stock_code: 股票代码
        days: 历史数据天数
        
    Returns:
        包含价格和成交量数据的DataFrame
    """
    fetcher = AStockDataFetcher()
    df = fetcher.get_historical_data(stock_code, days)
    return df

# 全局数据缓存（简单实现）
_DATA_CACHE = {}

def get_cached_data(stock_code: str, days: int = 60) -> pd.DataFrame:
    """带缓存的数据获取函数"""
    cache_key = f"{stock_code}_{days}"
    if cache_key not in _DATA_CACHE:
        _DATA_CACHE[cache_key] = prepare_technical_data(stock_code, days)
    return _DATA_CACHE[cache_key]