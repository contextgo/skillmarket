#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - Web服务框架
集成行情数据接口和技术指标模块
监听8080端口提供RESTful API服务
"""

import os
import sys
import json
import logging
from datetime import datetime
from typing import Dict, List, Any

# 添加项目根目录到Python路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from realtime_quote import get_realtime_quote, get_realtime_quotes, RealtimeQuoteError
from modules.technical_indicators import TechnicalIndicators, get_technical_indicators
import pandas as pd

# Flask Web框架
try:
    from flask import Flask, jsonify, request, abort
    from flask_cors import CORS
except ImportError:
    print("错误: 请先安装Flask和flask-cors")
    print("运行: pip install flask flask-cors pandas numpy")
    sys.exit(1)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 创建Flask应用
app = Flask(__name__)
CORS(app)  # 允许跨域请求

# 健康检查端点
@app.route('/health', methods=['GET'])
def health_check():
    """健康检查端点"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat(),
        'service': 'a-stock-trader-web-service'
    })

# 获取单个股票实时行情
@app.route('/api/quote/<stock_code>', methods=['GET'])
def get_stock_quote(stock_code):
    """
    获取单个股票实时行情
    
    URL参数:
        stock_code: 股票代码 (如 000001, 600519, 510050)
    
    返回:
        JSON格式的股票行情数据
    """
    try:
        quote_data = get_realtime_quote(stock_code)
        return jsonify({
            'success': True,
            'data': quote_data,
            'timestamp': datetime.now().isoformat()
        })
    except RealtimeQuoteError as e:
        logger.error(f"获取股票 {stock_code} 行情失败: {e}")
        return jsonify({
            'success': False,
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }), 400
    except Exception as e:
        logger.error(f"获取股票 {stock_code} 行情时发生未知错误: {e}")
        return jsonify({
            'success': False,
            'error': '服务器内部错误',
            'timestamp': datetime.now().isoformat()
        }), 500

# 批量获取多个股票实时行情
@app.route('/api/quotes', methods=['POST'])
def get_multiple_quotes():
    """
    批量获取多个股票实时行情
    
    请求体 (JSON):
        {
            "stock_codes": ["000001", "600519", "510050"]
        }
    
    返回:
        JSON格式的批量行情数据
    """
    try:
        data = request.get_json()
        if not data or 'stock_codes' not in data:
            return jsonify({
                'success': False,
                'error': '请求体必须包含stock_codes字段'
            }), 400
        
        stock_codes = data['stock_codes']
        if not isinstance(stock_codes, list) or len(stock_codes) == 0:
            return jsonify({
                'success': False,
                'error': 'stock_codes必须是非空数组'
            }), 400
        
        if len(stock_codes) > 50:  # 限制批量请求数量
            return jsonify({
                'success': False,
                'error': '单次请求最多支持50个股票代码'
            }), 400
        
        quotes_data = get_realtime_quotes(stock_codes)
        return jsonify({
            'success': True,
            'data': quotes_data,
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"批量获取行情时发生错误: {e}")
        return jsonify({
            'success': False,
            'error': '服务器内部错误',
            'timestamp': datetime.now().isoformat()
        }), 500

# 获取技术指标（需要历史数据）
@app.route('/api/indicators/<stock_code>', methods=['POST'])
def get_technical_indicators_api(stock_code):
    """
    获取股票技术指标
    
    URL参数:
        stock_code: 股票代码
    
    请求体 (JSON):
        {
            "historical_data": [
                {"date": "2024-01-01", "open": 10.0, "high": 11.0, "low": 9.5, "close": 10.5, "volume": 1000000},
                ...
            ]
        }
    
    返回:
        JSON格式的技术指标数据和信号分析
    """
    try:
        data = request.get_json()
        if not data or 'historical_data' not in data:
            return jsonify({
                'success': False,
                'error': '请求体必须包含historical_data字段'
            }), 400
        
        historical_data = data['historical_data']
        if not isinstance(historical_data, list) or len(historical_data) < 20:
            return jsonify({
                'success': False,
                'error': 'historical_data必须是包含至少20条记录的数组'
            }), 400
        
        # 转换为DataFrame
        df = pd.DataFrame(historical_data)
        required_columns = ['date', 'open', 'high', 'low', 'close', 'volume']
        if not all(col in df.columns for col in required_columns):
            return jsonify({
                'success': False,
                'error': f'historical_data必须包含以下列: {required_columns}'
            }), 400
        
        # 计算技术指标
        result = get_technical_indicators(stock_code, df)
        
        # 转换DataFrame为字典列表以便JSON序列化
        indicators_list = result['indicators'].to_dict('records')
        
        return jsonify({
            'success': True,
            'data': {
                'indicators': indicators_list,
                'signals': result['signals']
            },
            'timestamp': datetime.now().isoformat()
        })
        
    except Exception as e:
        logger.error(f"计算技术指标时发生错误: {e}")
        return jsonify({
            'success': False,
            'error': f'计算技术指标失败: {str(e)}',
            'timestamp': datetime.now().isoformat()
        }), 500

# 主页
@app.route('/', methods=['GET'])
def home():
    """主页"""
    return jsonify({
        'message': 'A股操盘手Web服务已启动',
        'version': '1.0.0',
        'endpoints': {
            'health': '/health',
            'single_quote': '/api/quote/<stock_code>',
            'batch_quotes': '/api/quotes (POST)',
            'technical_indicators': '/api/indicators/<stock_code> (POST)'
        },
        'documentation': '请查看API文档了解详细用法'
    })

# 错误处理
@app.errorhandler(404)
def not_found(error):
    return jsonify({
        'success': False,
        'error': 'API端点不存在'
    }), 404

@app.errorhandler(500)
def internal_error(error):
    logger.error(f"服务器内部错误: {error}")
    return jsonify({
        'success': False,
        'error': '服务器内部错误'
    }), 500

def main():
    """启动Web服务"""
    port = int(os.environ.get('PORT', 8080))
    host = os.environ.get('HOST', '0.0.0.0')
    
    logger.info(f"启动A股操盘手Web服务，监听 {host}:{port}")
    logger.info("支持的API端点:")
    logger.info("  GET  /health                    - 健康检查")
    logger.info("  GET  /api/quote/<stock_code>    - 获取单个股票行情")
    logger.info("  POST /api/quotes               - 批量获取股票行情")
    logger.info("  POST /api/indicators/<code>    - 获取技术指标")
    
    try:
        app.run(host=host, port=port, debug=False)
    except KeyboardInterrupt:
        logger.info("Web服务已停止")
    except Exception as e:
        logger.error(f"启动Web服务失败: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()