#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
技术指标模块测试用例
"""

import unittest
import numpy as np
from src.indicators.macd import calculate_macd
from src.indicators.kdj import calculate_kdj
from src.indicators.bollinger import calculate_bollinger_bands
from src.indicators.ma import calculate_moving_averages

class TestIndicators(unittest.TestCase):
    
    def setUp(self):
        """测试数据准备"""
        # 创建测试价格数据
        self.prices = [100 + i * 0.5 for i in range(100)]  # 上涨趋势
        self.highs = [price + 2 for price in self.prices]
        self.lows = [price - 2 for price in self.prices]
        
        # 创建震荡价格数据
        self.oscillating_prices = [100 + np.sin(i * 0.1) * 5 for i in range(100)]
    
    def test_macd_calculation(self):
        """测试MACD计算"""
        result = calculate_macd(self.prices)
        
        self.assertIn('macd_line', result)
        self.assertIn('signal_line', result)
        self.assertIn('histogram', result)
        self.assertIn('trend', result)
        self.assertIn('signal', result)
        
        # 验证长度
        self.assertEqual(len(result['macd_line']), len(self.prices))
        self.assertEqual(len(result['signal_line']), len(self.prices))
        self.assertEqual(len(result['histogram']), len(self.prices))
        
        # 验证趋势（上涨趋势应为bullish）
        self.assertEqual(result['trend'], 'bullish')
    
    def test_kdj_calculation(self):
        """测试KDJ计算"""
        result = calculate_kdj(self.prices, self.highs, self.lows)
        
        self.assertIn('k', result)
        self.assertIn('d', result)
        self.assertIn('j', result)
        self.assertIn('signal', result)
        
        # 验证长度
        self.assertEqual(len(result['k']), len(self.prices))
        self.assertEqual(len(result['d']), len(self.prices))
        self.assertEqual(len(result['j']), len(self.prices))
        
        # 验证K、D、J值范围
        last_k = result['last_k']
        last_d = result['last_d']
        last_j = result['last_j']
        
        self.assertIsNotNone(last_k)
        self.assertIsNotNone(last_d)
        self.assertIsNotNone(last_j)
    
    def test_bollinger_bands_calculation(self):
        """测试布林带计算"""
        result = calculate_bollinger_bands(self.oscillating_prices)
        
        self.assertIn('upper_band', result)
        self.assertIn('middle_band', result)
        self.assertIn('lower_band', result)
        self.assertIn('bandwidth', result)
        self.assertIn('position', result)
        self.assertIn('signal', result)
        
        # 验证长度
        self.assertEqual(len(result['upper_band']), len(self.oscillating_prices))
        self.assertEqual(len(result['middle_band']), len(self.oscillating_prices))
        self.assertEqual(len(result['lower_band']), len(self.oscillating_prices))
        
        # 验证上下轨关系
        if result['last_upper'] and result['last_lower']:
            self.assertGreater(result['last_upper'], result['last_lower'])
    
    def test_moving_averages_calculation(self):
        """测试移动平均线计算"""
        result = calculate_moving_averages(self.prices)
        
        self.assertIn('ma5', result)
        self.assertIn('ma10', result)
        self.assertIn('ma20', result)
        self.assertIn('ma60', result)
        self.assertIn('trend', result)
        self.assertIn('signal', result)
        
        # 验证趋势（上涨趋势应为bullish）
        self.assertEqual(result['trend'], 'bullish')
        
        # 验证均线值
        self.assertIsNotNone(result['last_ma5'])
        self.assertIsNotNone(result['last_ma10'])
        self.assertIsNotNone(result['last_ma20'])
        self.assertIsNotNone(result['last_ma60'])

if __name__ == '__main__':
    unittest.main()