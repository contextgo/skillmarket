#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
行情数据API处理器
用于Express服务调用的独立脚本
"""

import sys
import json
import os
from datetime import datetime

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

try:
    from realtime_quote import get_realtime_quote, get_realtime_quotes, RealtimeQuoteError
except ImportError as e:
    print(json.dumps({
        "success": False,
        "error": f"导入模块失败: {str(e)}",
        "timestamp": datetime.now().isoformat()
    }))
    sys.exit(1)

def handle_quote_request(stock_code):
    """处理单个股票行情请求"""
    try:
        quote_data = get_realtime_quote(stock_code)
        result = {
            "success": True,
            "data": quote_data,
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
    except RealtimeQuoteError as e:
        result = {
            "success": False,
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)
    except Exception as e:
        result = {
            "success": False,
            "error": f"服务器内部错误: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)

def handle_quotes_request(stock_codes):
    """处理批量股票行情请求"""
    try:
        if not isinstance(stock_codes, list):
            raise ValueError("stock_codes必须是数组")
        
        if len(stock_codes) == 0:
            raise ValueError("stock_codes不能为空")
        
        if len(stock_codes) > 50:
            raise ValueError("单次请求最多支持50个股票代码")
        
        quotes_data = get_realtime_quotes(stock_codes)
        result = {
            "success": True,
            "data": quotes_data,
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
    except Exception as e:
        result = {
            "success": False,
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)

def handle_portfolio_analysis(portfolio_data):
    """处理投资组合分析请求"""
    try:
        # 验证输入数据
        if not isinstance(portfolio_data, dict):
            raise ValueError("投资组合数据必须是对象")
        
        if 'positions' not in portfolio_data:
            raise ValueError("投资组合数据必须包含positions字段")
        
        positions = portfolio_data['positions']
        if not isinstance(positions, list):
            raise ValueError("positions必须是数组")
        
        if len(positions) == 0:
            # 空投资组合
            result = {
                "success": True,
                "data": {
                    "total_value": 0,
                    "total_cost": 0,
                    "total_profit": 0,
                    "profit_rate": 0,
                    "positions": [],
                    "sector_allocation": {},
                    "risk_metrics": {
                        "volatility": 0,
                        "sharpe_ratio": 0,
                        "max_drawdown": 0
                    }
                },
                "timestamp": datetime.now().isoformat()
            }
            print(json.dumps(result, ensure_ascii=False))
            return
        
        # 获取所有股票的实时行情
        stock_codes = []
        position_map = {}
        
        for pos in positions:
            if 'stock_code' not in pos or 'shares' not in pos or 'cost_price' not in pos:
                continue
            
            stock_code = pos['stock_code']
            shares = float(pos['shares'])
            cost_price = float(pos['cost_price'])
            
            stock_codes.append(stock_code)
            position_map[stock_code] = {
                'shares': shares,
                'cost_price': cost_price,
                'cost_value': shares * cost_price
            }
        
        if not stock_codes:
            raise ValueError("投资组合中没有有效的股票持仓")
        
        # 获取实时行情
        quotes_data = get_realtime_quotes(stock_codes)
        
        # 计算投资组合指标
        total_value = 0
        total_cost = 0
        positions_result = []
        
        for stock_code, quote in quotes_data.items():
            if quote.get('status') != 'success':
                continue
            
            if stock_code not in position_map:
                continue
            
            pos_info = position_map[stock_code]
            current_price = quote.get('current_price', 0)
            market_value = pos_info['shares'] * current_price
            cost_value = pos_info['cost_value']
            profit = market_value - cost_value
            profit_rate = (profit / cost_value * 100) if cost_value > 0 else 0
            
            total_value += market_value
            total_cost += cost_value
            
            positions_result.append({
                'stock_code': stock_code,
                'stock_name': quote.get('stock_name', ''),
                'shares': pos_info['shares'],
                'cost_price': pos_info['cost_price'],
                'current_price': current_price,
                'market_value': market_value,
                'cost_value': cost_value,
                'profit': profit,
                'profit_rate': profit_rate,
                'weight': (market_value / total_value * 100) if total_value > 0 else 0
            })
        
        # 计算整体指标
        total_profit = total_value - total_cost
        overall_profit_rate = (total_profit / total_cost * 100) if total_cost > 0 else 0
        
        # 简单的风险指标（这里可以扩展）
        risk_metrics = {
            "volatility": 0,  # 需要历史数据计算
            "sharpe_ratio": 0,  # 需要历史数据和无风险利率
            "max_drawdown": 0   # 需要历史数据
        }
        
        # 行业配置（简化版，实际需要行业分类数据）
        sector_allocation = {
            "金融": 0,
            "科技": 0,
            "消费": 0,
            "医药": 0,
            "制造": 0,
            "其他": 0
        }
        
        result = {
            "success": True,
            "data": {
                "total_value": total_value,
                "total_cost": total_cost,
                "total_profit": total_profit,
                "profit_rate": overall_profit_rate,
                "positions": positions_result,
                "sector_allocation": sector_allocation,
                "risk_metrics": risk_metrics
            },
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
        
    except Exception as e:
        result = {
            "success": False,
            "error": str(e),
            "timestamp": datetime.now().isoformat()
        }
        print(json.dumps(result, ensure_ascii=False))
        sys.exit(1)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "缺少操作类型参数",
            "timestamp": datetime.now().isoformat()
        }))
        sys.exit(1)
    
    operation = sys.argv[1]
    
    if operation == "quote":
        if len(sys.argv) < 3:
            print(json.dumps({
                "success": False,
                "error": "缺少股票代码参数",
                "timestamp": datetime.now().isoformat()
            }))
            sys.exit(1)
        stock_code = sys.argv[2]
        handle_quote_request(stock_code)
        
    elif operation == "quotes":
        if len(sys.argv) < 3:
            print(json.dumps({
                "success": False,
                "error": "缺少股票代码列表参数",
                "timestamp": datetime.now().isoformat()
            }))
            sys.exit(1)
        try:
            stock_codes = json.loads(sys.argv[2])
            handle_quotes_request(stock_codes)
        except json.JSONDecodeError:
            print(json.dumps({
                "success": False,
                "error": "股票代码列表格式无效",
                "timestamp": datetime.now().isoformat()
            }))
            sys.exit(1)
            
    elif operation == "portfolio":
        if len(sys.argv) < 3:
            print(json.dumps({
                "success": False,
                "error": "缺少投资组合数据参数",
                "timestamp": datetime.now().isoformat()
            }))
            sys.exit(1)
        try:
            portfolio_data = json.loads(sys.argv[2])
            handle_portfolio_analysis(portfolio_data)
        except json.JSONDecodeError:
            print(json.dumps({
                "success": False,
                "error": "投资组合数据格式无效",
                "timestamp": datetime.now().isoformat()
            }))
            sys.exit(1)
            
    else:
        print(json.dumps({
            "success": False,
            "error": f"不支持的操作类型: {operation}",
            "timestamp": datetime.now().isoformat()
        }))
        sys.exit(1)