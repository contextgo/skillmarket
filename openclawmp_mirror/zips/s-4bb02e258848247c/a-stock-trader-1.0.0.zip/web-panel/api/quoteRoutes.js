/**
 * A股操盘手 - 行情数据API路由
 * 集成Python行情数据获取模块
 */

const express = require('express');
const { spawn } = require('child_process');
const path = require('path');
const router = express.Router();

/**
 * 执行Python脚本并返回Promise
 * @param {string} scriptPath - Python脚本路径
 * @param {string[]} args - 脚本参数
 * @returns {Promise} - 脚本执行结果
 */
function executePythonScript(scriptPath, args = []) {
    return new Promise((resolve, reject) => {
        const pythonPath = process.env.PYTHON_PATH || 'python3';
        const child = spawn(pythonPath, [scriptPath, ...args], {
            cwd: path.dirname(scriptPath),
            env: {
                ...process.env,
                PYTHONPATH: path.join(__dirname, '../../')
            }
        });

        let stdout = '';
        let stderr = '';

        child.stdout.on('data', (data) => {
            stdout += data.toString();
        });

        child.stderr.on('data', (data) => {
            stderr += data.toString();
        });

        child.on('close', (code) => {
            if (code === 0) {
                try {
                    const result = JSON.parse(stdout.trim());
                    resolve(result);
                } catch (error) {
                    reject(new Error(`Invalid JSON response: ${stdout}`));
                }
            } else {
                reject(new Error(`Python script failed with code ${code}: ${stderr}`));
            }
        });

        child.on('error', (error) => {
            reject(error);
        });
    });
}

/**
 * 获取单个股票实时行情
 * GET /api/quote/:stockCode
 */
router.get('/quote/:stockCode', async (req, res) => {
    try {
        const { stockCode } = req.params;
        const timeout = parseInt(req.query.timeout) || 10;

        // 验证股票代码格式
        if (!stockCode || !/^[a-zA-Z0-9]{1,10}$/.test(stockCode)) {
            return res.status(400).json({
                success: false,
                error: '无效的股票代码格式'
            });
        }

        // 调用Python脚本获取行情数据
        const scriptPath = path.join(__dirname, 'quote_handler.py');
        const result = await executePythonScript(scriptPath, ['single', stockCode, timeout.toString()]);

        res.json({
            success: true,
            data: result.data,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('获取股票行情失败:', error.message);
        res.status(500).json({
            success: false,
            error: '服务器内部错误',
            message: error.message
        });
    }
});

/**
 * 批量获取多个股票实时行情
 * POST /api/quotes
 */
router.post('/quotes', async (req, res) => {
    try {
        const { stock_codes } = req.body;
        const timeout = parseInt(req.query.timeout) || 10;

        // 验证请求体
        if (!Array.isArray(stock_codes) || stock_codes.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'stock_codes必须是非空数组'
            });
        }

        if (stock_codes.length > 50) {
            return res.status(400).json({
                success: false,
                error: '单次请求最多支持50个股票代码'
            });
        }

        // 验证股票代码格式
        for (const code of stock_codes) {
            if (!code || !/^[a-zA-Z0-9]{1,10}$/.test(code)) {
                return res.status(400).json({
                    success: false,
                    error: `无效的股票代码格式: ${code}`
                });
            }
        }

        // 调用Python脚本获取批量行情数据
        const scriptPath = path.join(__dirname, 'quote_handler.py');
        const result = await executePythonScript(scriptPath, ['batch', JSON.stringify(stock_codes), timeout.toString()]);

        res.json({
            success: true,
            data: result.data,
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('批量获取股票行情失败:', error.message);
        res.status(500).json({
            success: false,
            error: '服务器内部错误',
            message: error.message
        });
    }
});

/**
 * 投资组合分析
 * POST /api/portfolio/analysis
 */
router.post('/portfolio/analysis', async (req, res) => {
    try {
        const { portfolio } = req.body;

        // 验证投资组合数据
        if (!portfolio || !Array.isArray(portfolio) || portfolio.length === 0) {
            return res.status(400).json({
                success: false,
                error: 'portfolio必须是非空数组'
            });
        }

        // 验证每个持仓项
        for (const position of portfolio) {
            if (!position.stock_code || !position.quantity || position.quantity <= 0) {
                return res.status(400).json({
                    success: false,
                    error: '每个持仓项必须包含有效的stock_code和quantity'
                });
            }
        }

        // 提取股票代码列表
        const stockCodes = portfolio.map(pos => pos.stock_code);

        // 获取所有股票的实时行情
        const scriptPath = path.join(__dirname, 'quote_handler.py');
        const quotesResult = await executePythonScript(scriptPath, ['batch', JSON.stringify(stockCodes), '10']);

        // 计算投资组合分析
        let totalValue = 0;
        let totalCost = 0;
        const analyzedPortfolio = [];

        for (const position of portfolio) {
            const quote = quotesResult.data[position.stock_code];
            if (quote && quote.status === 'success') {
                const currentValue = quote.current_price * position.quantity;
                const cost = position.cost_basis ? position.cost_basis * position.quantity : 0;
                const profitLoss = currentValue - cost;
                const profitLossPercent = cost > 0 ? (profitLoss / cost) * 100 : 0;

                analyzedPortfolio.push({
                    stock_code: position.stock_code,
                    stock_name: quote.stock_name,
                    quantity: position.quantity,
                    current_price: quote.current_price,
                    cost_basis: position.cost_basis || 0,
                    current_value: currentValue,
                    profit_loss: profitLoss,
                    profit_loss_percent: profitLossPercent
                });

                totalValue += currentValue;
                totalCost += cost;
            } else {
                analyzedPortfolio.push({
                    stock_code: position.stock_code,
                    stock_name: '未知',
                    quantity: position.quantity,
                    current_price: 0,
                    cost_basis: position.cost_basis || 0,
                    current_value: 0,
                    profit_loss: 0,
                    profit_loss_percent: 0,
                    error: quote ? quote.error : '无法获取行情数据'
                });
            }
        }

        const totalProfitLoss = totalValue - totalCost;
        const totalProfitLossPercent = totalCost > 0 ? (totalProfitLoss / totalCost) * 100 : 0;

        res.json({
            success: true,
            data: {
                portfolio: analyzedPortfolio,
                summary: {
                    total_value: totalValue,
                    total_cost: totalCost,
                    total_profit_loss: totalProfitLoss,
                    total_profit_loss_percent: totalProfitLossPercent,
                    positions_count: analyzedPortfolio.length
                }
            },
            timestamp: new Date().toISOString()
        });

    } catch (error) {
        console.error('投资组合分析失败:', error.message);
        res.status(500).json({
            success: false,
            error: '服务器内部错误',
            message: error.message
        });
    }
});

module.exports = router;