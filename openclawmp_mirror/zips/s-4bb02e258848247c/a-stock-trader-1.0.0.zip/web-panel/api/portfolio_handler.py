#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - 投资组合分析处理脚本
用于Node.js Express服务调用
"""

import sys
import json
import os
import logging
from datetime import datetime

# 添加项目根目录到Python路径
project_root = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, project_root)

try:
    from realtime_quote import get_realtime_quotes, RealtimeQuoteError
    from modules.technical_indicators import TechnicalIndicators, get_technical_indicators
    import pandas as pd
    import numpy as np
except ImportError as e:
    print(json.dumps({
        "success": False,
        "error": f"导入模块失败: {e}",
        "timestamp": datetime.now().isoformat()
    }))
    sys.exit(1)

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def analyze_portfolio(portfolio_data):
    """
    分析投资组合
    
    Args:
        portfolio_data (dict): 投资组合数据
            {
                "positions": [
                    {
                        "stock_code": "000001",
                        "shares": 1000,
                        "cost_price": 10.50,
                        "weight": 0.3
                    },
                    ...
                ],
                "total_value": 100000.0,
                "risk_tolerance": "medium"
            }
    
    Returns:
        dict: 分析结果
    """
    try:
        positions = portfolio_data.get('positions', [])
        if not positions:
            return {
                "success": False,
                "error": "投资组合不能为空"
            }
        
        # 获取所有股票的实时行情
        stock_codes = [pos['stock_code'] for pos in positions]
        quotes_data = get_realtime_quotes(stock_codes)
        
        # 计算投资组合指标
        total_current_value = 0
        total_cost_value = 0
        position_details = []
        
        for position in positions:
            stock_code = position['stock_code']
            shares = position['shares']
            cost_price = position['cost_price']
            
            quote = quotes_data.get(stock_code, {})
            current_price = quote.get('current_price', 0) if isinstance(quote, dict) else 0
            
            current_value = shares * current_price
            cost_value = shares * cost_price
            profit_loss = current_value - cost_value
            profit_loss_percent = (profit_loss / cost_value * 100) if cost_value > 0 else 0
            
            position_details.append({
                "stock_code": stock_code,
                "stock_name": quote.get('stock_name', '未知') if isinstance(quote, dict) else '未知',
                "shares": shares,
                "cost_price": cost_price,
                "current_price": current_price,
                "current_value": current_value,
                "cost_value": cost_value,
                "profit_loss": profit_loss,
                "profit_loss_percent": profit_loss_percent,
                "weight": position.get('weight', 0)
            })
            
            total_current_value += current_value
            total_cost_value += cost_value
        
        # 计算整体指标
        total_profit_loss = total_current_value - total_cost_value
        total_profit_loss_percent = (total_profit_loss / total_cost_value * 100) if total_cost_value > 0 else 0
        
        # 风险分析（简化版）
        risk_tolerance = portfolio_data.get('risk_tolerance', 'medium')
        risk_score = calculate_risk_score(position_details, risk_tolerance)
        
        # 行业分散度分析（简化版，需要更多数据）
        diversification_score = calculate_diversification_score(position_details)
        
        result = {
            "success": True,
            "data": {
                "portfolio_summary": {
                    "total_current_value": total_current_value,
                    "total_cost_value": total_cost_value,
                    "total_profit_loss": total_profit_loss,
                    "total_profit_loss_percent": total_profit_loss_percent,
                    "risk_score": risk_score,
                    "diversification_score": diversification_score,
                    "position_count": len(positions)
                },
                "positions": position_details,
                "recommendations": generate_recommendations(position_details, risk_tolerance)
            },
            "timestamp": datetime.now().isoformat()
        }
        
        return result
        
    except Exception as e:
        logger.error(f"投资组合分析失败: {e}")
        return {
            "success": False,
            "error": f"分析失败: {str(e)}",
            "timestamp": datetime.now().isoformat()
        }

def calculate_risk_score(positions, risk_tolerance):
    """计算风险评分（简化版）"""
    # 这里可以添加更复杂的风控逻辑
    if risk_tolerance == 'low':
        return 20
    elif risk_tolerance == 'high':
        return 80
    else:
        return 50

def calculate_diversification_score(positions):
    """计算分散度评分（简化版）"""
    # 简单的分散度计算：基于持仓数量
    position_count = len(positions)
    if position_count >= 10:
        return 90
    elif position_count >= 5:
        return 70
    elif position_count >= 3:
        return 50
    else:
        return 30

def generate_recommendations(positions, risk_tolerance):
    """生成投资建议"""
    recommendations = []
    
    # 亏损超过10%的股票建议
    for pos in positions:
        if pos['profit_loss_percent'] < -10:
            recommendations.append({
                "type": "warning",
                "message": f"{pos['stock_name']}({pos['stock_code']})亏损超过10%，建议关注"
            })
    
    # 根据风险偏好给出建议
    if risk_tolerance == 'low' and len(positions) < 3:
        recommendations.append({
            "type": "info",
            "message": "建议增加持仓分散度，降低单一股票风险"
        })
    
    if risk_tolerance == 'high' and len(positions) > 10:
        recommendations.append({
            "type": "info",
            "message": "持仓过于分散，可能影响收益，建议集中投资"
        })
    
    if not recommendations:
        recommendations.append({
            "type": "success",
            "message": "投资组合表现良好，继续保持"
        })
    
    return recommendations

def main():
    """主函数 - 从stdin读取JSON数据并输出分析结果"""
    try:
        # 从stdin读取输入
        input_data = sys.stdin.read()
        if not input_data.strip():
            print(json.dumps({
                "success": False,
                "error": "输入数据为空",
                "timestamp": datetime.now().isoformat()
            }))
            return
        
        portfolio_data = json.loads(input_data)
        result = analyze_portfolio(portfolio_data)
        print(json.dumps(result, ensure_ascii=False))
        
    except json.JSONDecodeError as e:
        print(json.dumps({
            "success": False,
            "error": f"JSON解析错误: {e}",
            "timestamp": datetime.now().isoformat()
        }))
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": f"处理失败: {e}",
            "timestamp": datetime.now().isoformat()
        }))

if __name__ == "__main__":
    main()