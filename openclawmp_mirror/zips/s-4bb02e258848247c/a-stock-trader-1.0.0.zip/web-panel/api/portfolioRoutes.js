const express = require('express');
const { exec } = require('child_process');
const path = require('path');
const fs = require('fs').promises;

const router = express.Router();

/**
 * 执行Python脚本的辅助函数
 * @param {string} scriptPath - Python脚本路径
 * @param {string[]} args - 命令行参数
 * @returns {Promise<Object>} - 解析后的JSON结果
 */
function executePythonScript(scriptPath, args = []) {
    return new Promise((resolve, reject) => {
        const fullPath = path.join(__dirname, scriptPath);
        const command = `python3 ${fullPath} ${args.join(' ')}`;
        
        exec(command, { timeout: 30000 }, (error, stdout, stderr) => {
            if (error) {
                console.error(`Python脚本执行错误: ${error.message}`);
                console.error(`stderr: ${stderr}`);
                reject(new Error(`行情数据获取失败: ${error.message}`));
                return;
            }
            
            try {
                const result = JSON.parse(stdout.trim());
                resolve(result);
            } catch (parseError) {
                console.error(`JSON解析错误: ${parseError.message}`);
                console.error(`原始输出: ${stdout}`);
                reject(new Error('服务器返回格式错误'));
            }
        });
    });
}

/**
 * 投资组合分析API
 * POST /api/portfolio/analysis
 * 请求体: {
 *   "portfolio": [
 *     { "stock_code": "000001", "shares": 100, "cost_price": 10.5 },
 *     { "stock_code": "600519", "shares": 50, "cost_price": 1800.0 }
 *   ],
 *   "benchmark": "000001" // 可选基准指数
 * }
 */
router.post('/analysis', async (req, res) => {
    try {
        const { portfolio, benchmark = '000001' } = req.body;
        
        // 验证请求体
        if (!portfolio || !Array.isArray(portfolio) || portfolio.length === 0) {
            return res.status(400).json({
                success: false,
                error: '请求体必须包含非空的portfolio数组'
            });
        }
        
        // 验证投资组合格式
        for (const position of portfolio) {
            if (!position.stock_code || !position.shares || !position.cost_price) {
                return res.status(400).json({
                    success: false,
                    error: '投资组合中的每个持仓必须包含stock_code、shares和cost_price字段'
                });
            }
            if (typeof position.shares !== 'number' || typeof position.cost_price !== 'number') {
                return res.status(400).json({
                    success: false,
                    error: 'shares和cost_price必须是数字'
                });
            }
        }
        
        // 将投资组合数据写入临时文件
        const tempData = {
            portfolio: portfolio,
            benchmark: benchmark
        };
        
        const tempFilePath = path.join(__dirname, 'temp_portfolio.json');
        await fs.writeFile(tempFilePath, JSON.stringify(tempData, null, 2));
        
        try {
            // 调用Python脚本进行投资组合分析
            const result = await executePythonScript(
                './portfolio_handler.py',
                [tempFilePath]
            );
            
            // 删除临时文件
            await fs.unlink(tempFilePath).catch(() => {});
            
            res.json({
                success: true,
                data: result,
                timestamp: new Date().toISOString()
            });
            
        } catch (scriptError) {
            // 确保临时文件被清理
            await fs.unlink(tempFilePath).catch(() => {});
            throw scriptError;
        }
        
    } catch (error) {
        console.error('投资组合分析API错误:', error);
        res.status(500).json({
            success: false,
            error: error.message || '服务器内部错误'
        });
    }
});

/**
 * 获取投资组合实时行情
 * POST /api/portfolio/quotes
 * 请求体: {
 *   "stock_codes": ["000001", "600519", "510050"]
 * }
 */
router.post('/quotes', async (req, res) => {
    try {
        const { stock_codes } = req.body;
        
        if (!stock_codes || !Array.isArray(stock_codes) || stock_codes.length === 0) {
            return res.status(400).json({
                success: false,
                error: '请求体必须包含非空的stock_codes数组'
            });
        }
        
        if (stock_codes.length > 50) {
            return res.status(400).json({
                success: false,
                error: '单次请求最多支持50个股票代码'
            });
        }
        
        // 调用Python脚本获取批量行情
        const result = await executePythonScript(
            './quote_handler.py',
            ['--batch', JSON.stringify(stock_codes)]
        );
        
        res.json({
            success: true,
            data: result,
            timestamp: new Date().toISOString()
        });
        
    } catch (error) {
        console.error('批量行情API错误:', error);
        res.status(500).json({
            success: false,
            error: error.message || '服务器内部错误'
        });
    }
});

module.exports = router;