# A股操盘手独立Web服务

## 🔐 访问凭证
- **用户名**: `kollittle`
- **密码**: `RqymtJ8DGpyAtYil`

## 🚀 服务配置
- **端口**: 8080
- **协议**: HTTPS (自签名证书)
- **认证**: HTTP Basic Auth
- **访问地址**: https://[服务器IP]:8080

## 📁 目录结构
```
web-panel/
├── server.js          # Express服务器主程序
├── auth.js           # 认证中间件
├── ssl/             # SSL证书目录
│   ├── key.pem      # 私钥
│   └── cert.pem     # 证书
├── public/          # 静态文件
│   └── index.html   # Web面板
└── package.json     # 依赖配置
```

## 🛡️ 安全特性
- **HTTPS加密**: 自签名SSL证书
- **HTTP Basic Auth**: 用户名密码保护
- **CORS限制**: 仅允许同源请求
- **速率限制**: 防止暴力破解

## 📋 部署命令
```bash
# 安装依赖
npm install express helmet rate-limit basic-auth

# 生成SSL证书
mkdir -p ssl && cd ssl
openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout key.pem -out cert.pem -subj "/C=CN/ST=Shanghai/L=Shanghai/O=AStockTrader/CN=localhost"

# 启动服务
node server.js
```

## ⚠️ 注意事项
- 首次访问浏览器会提示证书不安全，点击"继续访问"
- 建议在生产环境使用正式SSL证书
- 密码请妥善保管，建议定期更换