/**
 * A股操盘手独立Web服务 (HTTP版本)
 * 端口: 8080
 * 协议: HTTP
 * 认证: HTTP Basic Auth
 */

const express = require('express');
const path = require('path');
const helmet = require('helmet');
const authMiddleware = require('./auth');

// 导入API路由
const quoteRoutes = require('./api/quoteRoutes');
const portfolioRoutes = require('./api/portfolioRoutes');

const app = express();
const PORT = 8080;

// 安全头设置
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'", "'unsafe-inline'"],
            imgSrc: ["'self'", "data:"],
            connectSrc: ["'self'"]
        }
    }
}));

// 解析JSON请求体
app.use(express.json({ limit: '10mb' }));

// 静态文件服务
app.use(express.static(path.join(__dirname, 'public')));

// 应用认证中间件（保护所有路由）
app.use(authMiddleware);

// 主页路由
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// API健康检查
app.get('/api/status', (req, res) => {
    res.json({
        status: 'running',
        timestamp: new Date().toISOString(),
        mode: 'simulation'
    });
});

// 注册行情数据API路由
app.use('/api/quote', quoteRoutes);

// 注册投资组合分析API路由
app.use('/api/portfolio', portfolioRoutes);

// 错误处理
app.use((err, req, res, next) => {
    if (err.status === 401) {
        res.set('WWW-Authenticate', 'Basic realm="A股操盘手 - 请登录"');
        return res.status(401).send('需要身份验证');
    }
    next(err);
});

// 启动HTTP服务器
app.listen(PORT, '0.0.0.0', () => {
    console.log(`✅ A股操盘手Web面板已启动`);
    console.log(`🌐 访问地址: http://[服务器IP]:${PORT}`);
    console.log(`👤 用户名: kollittle`);
    console.log(`🔑 密码: RqymtJ8DGpyAtYil`);
    console.log(`📊 API端点:`);
    console.log(`   GET  /api/quote/{stock_code}     - 获取单个股票实时行情`);
    console.log(`   POST /api/portfolio/analysis    - 投资组合分析`);
});

// 健康检查
process.on('SIGTERM', () => {
    console.log('正在关闭A股操盘手Web服务...');
    process.exit(0);
});