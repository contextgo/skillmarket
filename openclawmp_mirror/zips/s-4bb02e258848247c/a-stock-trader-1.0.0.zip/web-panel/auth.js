/**
 * A股操盘手Web面板认证中间件
 */

const basicAuth = require('express-basic-auth');

// 用户凭证配置
const users = {
    'kollittle': 'RqymtJ8DGpyAtYil'
};

// 基本身份验证中间件
const authMiddleware = basicAuth({
    users: users,
    challenge: true,
    realm: 'A股操盘手 - 请登录',
    unauthorizedResponse: (req) => {
        return req.auth ? '用户名或密码错误' : '需要身份验证';
    }
});

module.exports = authMiddleware;