"""
行情数据获取异常处理
"""
from typing import Optional


class QuoteError(Exception):
    """行情数据基础异常"""
    pass


class StockNotFoundError(QuoteError):
    """股票未找到异常"""
    def __init__(self, code: str, message: Optional[str] = None):
        self.code = code
        super().__init__(message or f"股票代码 {code} 未找到")