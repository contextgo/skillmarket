#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股实时行情数据接口
支持股票、ETF、基金等证券品种
使用腾讯财经API作为数据源
"""

import requests
import json
import time
from typing import Dict, List, Optional, Union


class QuoteFetcher:
    """A股实时行情获取器"""
    
    def __init__(self):
        self.base_url = "http://qt.gtimg.cn/q="
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        })
    
    def _format_stock_code(self, code: str) -> str:
        """格式化股票代码为腾讯财经格式"""
        if code.startswith(('6', '9')):
            # 沪市股票
            return f"sh{code}"
        elif code.startswith(('0', '3', '15', '16')):
            # 深市股票、创业板、ETF
            return f"sz{code}"
        else:
            # 默认按深市处理
            return f"sz{code}"
    
    def _parse_tencent_response(self, response_text: str) -> Dict:
        """解析腾讯财经API响应"""
        try:
            # 腾讯财经返回格式: v_s_sz000001="~股票名称~当前价~涨跌~涨跌幅~..."
            if not response_text.startswith('v_'):
                return {}
            
            # 提取数据部分
            data_str = response_text.split('"')[1]
            data_parts = data_str.split('~')
            
            if len(data_parts) < 40:
                return {}
            
            # 解析关键字段
            quote_data = {
                'code': data_parts[2],  # 股票代码
                'name': data_parts[1],  # 股票名称
                'price': float(data_parts[3]),  # 当前价格
                'change': float(data_parts[4]),  # 涨跌额
                'change_pct': float(data_parts[5]),  # 涨跌幅(%)
                'open': float(data_parts[6]),  # 开盘价
                'high': float(data_parts[33]),  # 最高价
                'low': float(data_parts[34]),  # 最低价
                'close_prev': float(data_parts[30]),  # 昨收价
                'volume': int(data_parts[36]),  # 成交量(手)
                'amount': float(data_parts[37]),  # 成交额(万元)
                'bid_price': float(data_parts[9]),  # 买一价
                'ask_price': float(data_parts[19]),  # 卖一价
                'bid_volume': int(data_parts[10]),  # 买一量
                'ask_volume': int(data_parts[20]),  # 卖一量
                'timestamp': int(time.time())  # 获取时间戳
            }
            
            return quote_data
            
        except (IndexError, ValueError, KeyError) as e:
            print(f"解析行情数据失败: {e}")
            return {}
    
    def get_quote(self, code: str) -> Optional[Dict]:
        """获取单个股票的实时行情"""
        formatted_code = self._format_stock_code(code)
        url = f"{self.base_url}{formatted_code}"
        
        try:
            response = self.session.get(url, timeout=5)
            response.encoding = 'gbk'
            return self._parse_tencent_response(response.text)
        except Exception as e:
            print(f"获取行情失败 {code}: {e}")
            return None
    
    def get_quotes(self, codes: List[str]) -> Dict[str, Dict]:
        """批量获取多个股票的实时行情"""
        if not codes:
            return {}
        
        # 腾讯财经支持批量查询，用逗号分隔
        formatted_codes = [self._format_stock_code(code) for code in codes]
        url = f"{self.base_url}{','.join(formatted_codes)}"
        
        try:
            response = self.session.get(url, timeout=10)
            response.encoding = 'gbk'
            
            results = {}
            lines = response.text.strip().split('\n')
            
            for line in lines:
                if line.startswith('v_'):
                    quote_data = self._parse_tencent_response(line)
                    if quote_data and 'code' in quote_data:
                        results[quote_data['code']] = quote_data
            
            return results
            
        except Exception as e:
            print(f"批量获取行情失败: {e}")
            return {}


# 全局行情获取器实例
quote_fetcher = QuoteFetcher()


def get_realtime_quote(code: str) -> Optional[Dict]:
    """获取单个股票实时行情的便捷函数"""
    return quote_fetcher.get_quote(code)


def get_realtime_quotes(codes: List[str]) -> Dict[str, Dict]:
    """批量获取股票实时行情的便捷函数"""
    return quote_fetcher.get_quotes(codes)


if __name__ == "__main__":
    # 测试代码
    fetcher = QuoteFetcher()
    
    # 测试单个股票
    print("=== 单个股票测试 ===")
    quote = fetcher.get_quote("301236")
    if quote:
        print(f"股票: {quote['name']}({quote['code']})")
        print(f"当前价: {quote['price']:.2f}")
        print(f"涨跌幅: {quote['change_pct']:.2f}%")
        print(f"成交量: {quote['volume']:,}手")
    
    # 测试批量获取
    print("\n=== 批量获取测试 ===")
    quotes = fetcher.get_quotes(["301236", "600036", "000001"])
    for code, quote in quotes.items():
        print(f"{quote['name']}: {quote['price']:.2f} ({quote['change_pct']:.2f}%)")