#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手实时行情模块
高可靠性、低延迟的股票/ETF/基金统一数据接口
"""

import requests
import json
import time
import logging
from typing import Dict, List, Optional, Union
from dataclasses import dataclass
from enum import Enum

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class SecurityType(Enum):
    """证券类型枚举"""
    STOCK = "stock"      # 股票
    ETF = "etf"          # ETF
    FUND = "fund"        # 基金

@dataclass
class MarketData:
    """市场数据结构"""
    symbol: str          # 股票代码 (如: 600000)
    name: str            # 股票名称
    price: float         # 当前价格
    change: float        # 涨跌额
    change_percent: float  # 涨跌幅 (%)
    volume: int          # 成交量
    amount: float        # 成交额
    open_price: float    # 开盘价
    high_price: float    # 最高价
    low_price: float     # 最低价
    prev_close: float    # 昨收价
    timestamp: str       # 数据时间戳
    security_type: SecurityType  # 证券类型
    
    def to_dict(self) -> Dict:
        """转换为字典格式"""
        return {
            'symbol': self.symbol,
            'name': self.name,
            'price': self.price,
            'change': self.change,
            'change_percent': self.change_percent,
            'volume': self.volume,
            'amount': self.amount,
            'open_price': self.open_price,
            'high_price': self.high_price,
            'low_price': self.low_price,
            'prev_close': self.prev_close,
            'timestamp': self.timestamp,
            'security_type': self.security_type.value
        }

class MarketDataProvider:
    """市场数据提供者基类"""
    
    def get_data(self, symbol: str, security_type: SecurityType = SecurityType.STOCK) -> Optional[MarketData]:
        """获取单个证券的市场数据"""
        raise NotImplementedError
    
    def get_batch_data(self, symbols: List[str], security_type: SecurityType = SecurityType.STOCK) -> Dict[str, MarketData]:
        """批量获取市场数据"""
        raise NotImplementedError

class TencentFinanceProvider(MarketDataProvider):
    """腾讯财经数据提供者"""
    
    def __init__(self):
        self.base_url = "https://qt.gtimg.cn/q="
        self.timeout = 5  # 请求超时时间（秒）
    
    def _parse_tencent_data(self, raw_data: str, symbol: str) -> Optional[MarketData]:
        """解析腾讯财经返回的原始数据"""
        try:
            # 移除 v_sh600000=" 和末尾的 "; 
            if raw_data.startswith('v_'):
                start_idx = raw_data.find('"') + 1
                end_idx = raw_data.rfind('"')
                if start_idx > 0 and end_idx > start_idx:
                    data_str = raw_data[start_idx:end_idx]
                else:
                    return None
            else:
                data_str = raw_data.strip()
            
            fields = data_str.split('~')
            if len(fields) < 33:
                logger.warning(f"腾讯财经数据字段不足，symbol: {symbol}, fields: {len(fields)}")
                return None
            
            # 解析关键字段（基于腾讯财经API文档和实际测试）
            # 字段索引说明（从0开始）：
            # 0: 未知
            # 1: 股票名称
            # 2: 股票代码
            # 3: 当前价格
            # 4: 昨收价
            # 5: 今开价
            # 6: 成交量（手）
            # 7: 外盘（手）
            # 8: 内盘（手）
            # 9: 买一价
            # 10: 买一量
            # ... 更多档位数据
            # 30: 时间戳 (YYYYMMDDHHMMSS)
            # 31: 涨跌额
            # 32: 涨跌幅 (%)
            # 33: 最高价
            # 34: 最低价
            # 35: 成交量（手）- 重复
            # 36: 成交额（千元）
            
            name = fields[1] if len(fields) > 1 else symbol
            current_price = float(fields[3]) if fields[3] and fields[3] != '' else 0.0
            prev_close = float(fields[4]) if fields[4] and fields[4] != '' else current_price
            open_price = float(fields[5]) if fields[5] and fields[5] != '' else current_price
            volume_hands = int(fields[6]) if fields[6] and fields[6] != '' else 0
            volume = volume_hands * 100  # 腾讯财经成交量单位是"手"，1手=100股
            timestamp = fields[30] if len(fields) > 30 else ""
            change = float(fields[31]) if fields[31] and fields[31] != '' else 0.0
            change_percent = float(fields[32]) if fields[32] and fields[32] != '' else 0.0
            high_price = float(fields[33]) if fields[33] and fields[33] != '' else current_price
            low_price = float(fields[34]) if fields[34] and fields[34] != '' else current_price
            amount_ten_thousand = float(fields[36]) if len(fields) > 36 and fields[36] and fields[36] != '' else 0.0
            amount = amount_ten_thousand * 10000  # 成交额单位是万元
            
            # 计算成交额：使用价格 * 成交量（更准确）
            calculated_amount = current_price * volume if volume > 0 else 0.0
            
            # 如果API提供了成交额数据且合理，则使用API数据
            if amount > 0 and abs(amount - calculated_amount) / calculated_amount < 0.1 if calculated_amount > 0 else False:
                final_amount = amount
            else:
                final_amount = calculated_amount
            
            # 格式化时间戳
            formatted_timestamp = ""
            if timestamp and len(timestamp) == 14:
                formatted_timestamp = f"{timestamp[:4]}-{timestamp[4:6]}-{timestamp[6:8]} {timestamp[8:10]}:{timestamp[10:12]}:{timestamp[12:14]}"
            
            return MarketData(
                symbol=symbol,
                name=name,
                price=current_price,
                change=change,
                change_percent=change_percent,
                volume=volume,
                amount=final_amount,
                open_price=open_price,
                high_price=high_price,
                low_price=low_price,
                prev_close=prev_close,
                timestamp=formatted_timestamp,
                security_type=SecurityType.STOCK
            )
            
        except (ValueError, IndexError, TypeError) as e:
            logger.error(f"解析腾讯财经数据失败，symbol: {symbol}, error: {e}")
            return None
    
    def get_data(self, symbol: str, security_type: SecurityType = SecurityType.STOCK) -> Optional[MarketData]:
        """获取单个证券的市场数据"""
        try:
            # 构建请求URL
            # 股票代码格式：sh600000, sz000001
            if symbol.startswith(('6', '9')):  # 上海股票
                ticker = f"sh{symbol}"
            elif symbol.startswith(('0', '3')):  # 深圳股票
                ticker = f"sz{symbol}"
            else:
                ticker = symbol  # 可能已经是完整格式
            
            url = f"{self.base_url}{ticker}"
            logger.debug(f"请求腾讯财经API: {url}")
            
            response = requests.get(url, timeout=self.timeout)
            response.raise_for_status()
            
            raw_data = response.text.strip()
            if not raw_data:
                logger.warning(f"腾讯财经返回空数据，symbol: {symbol}")
                return None
            
            return self._parse_tencent_data(raw_data, symbol)
            
        except requests.RequestException as e:
            logger.error(f"腾讯财经API请求失败，symbol: {symbol}, error: {e}")
            return None
        except Exception as e:
            logger.error(f"腾讯财经数据处理异常，symbol: {symbol}, error: {e}")
            return None
    
    def get_batch_data(self, symbols: List[str], security_type: SecurityType = SecurityType.STOCK) -> Dict[str, MarketData]:
        """批量获取市场数据（腾讯财经支持批量查询）"""
        if not symbols:
            return {}
        
        try:
            # 构建批量查询URL
            tickers = []
            for symbol in symbols:
                if symbol.startswith(('6', '9')):
                    tickers.append(f"sh{symbol}")
                elif symbol.startswith(('0', '3')):
                    tickers.append(f"sz{symbol}")
                else:
                    tickers.append(symbol)
            
            ticker_str = ",".join(tickers)
            url = f"{self.base_url}{ticker_str}"
            logger.debug(f"批量请求腾讯财经API: {url}")
            
            response = requests.get(url, timeout=self.timeout * 2)  # 批量请求增加超时时间
            response.raise_for_status()
            
            raw_data = response.text.strip()
            if not raw_data:
                logger.warning("腾讯财经批量返回空数据")
                return {}
            
            # 分割多个股票的数据
            stock_data_list = raw_data.split(';')
            result = {}
            
            for i, stock_data in enumerate(stock_data_list):
                if not stock_data.strip():
                    continue
                if i < len(symbols):
                    market_data = self._parse_tencent_data(stock_data, symbols[i])
                    if market_data:
                        result[symbols[i]] = market_data
            
            return result
            
        except requests.RequestException as e:
            logger.error(f"腾讯财经批量API请求失败，error: {e}")
            return {}
        except Exception as e:
            logger.error(f"腾讯财经批量数据处理异常，error: {e}")
            return {}

class YahooFinanceProvider(MarketDataProvider):
    """Yahoo Finance数据提供者（备用）"""
    
    def __init__(self):
        self.base_url = "https://query1.finance.yahoo.com/v8/finance/chart/"
        self.timeout = 10
    
    def get_data(self, symbol: str, security_type: SecurityType = SecurityType.STOCK) -> Optional[MarketData]:
        """获取单个证券的市场数据"""
        try:
            # 转换A股代码到Yahoo格式
            yahoo_symbol = self._convert_to_yahoo_symbol(symbol)
            if not yahoo_symbol:
                return None
            
            url = f"{self.base_url}{yahoo_symbol}?interval=1m&range=1d"
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
            
            response = requests.get(url, headers=headers, timeout=self.timeout)
            response.raise_for_status()
            
            data = response.json()
            if 'chart' not in data or 'result' not in data['chart'] or not data['chart']['result']:
                logger.warning(f"Yahoo Finance返回无效数据，symbol: {symbol}")
                return None
            
            result = data['chart']['result'][0]
            quote = result['meta']
            
            # 提取市场数据
            current_price = quote.get('regularMarketPrice', 0.0)
            prev_close = quote.get('previousClose', current_price)
            change = current_price - prev_close
            change_percent = (change / prev_close * 100) if prev_close != 0 else 0.0
            volume = quote.get('regularMarketVolume', 0)
            high_price = quote.get('regularMarketDayHigh', current_price)
            low_price = quote.get('regularMarketDayLow', current_price)
            open_price = quote.get('regularMarketOpen', current_price)
            amount = current_price * volume if volume > 0 else 0.0
            
            # 时间戳
            timestamp = ""
            if 'regularMarketTime' in quote:
                import datetime
                ts = quote['regularMarketTime']
                dt = datetime.datetime.fromtimestamp(ts)
                timestamp = dt.strftime("%Y-%m-%d %H:%M:%S")
            
            return MarketData(
                symbol=symbol,
                name=quote.get('symbol', symbol),
                price=current_price,
                change=change,
                change_percent=change_percent,
                volume=volume,
                amount=amount,
                open_price=open_price,
                high_price=high_price,
                low_price=low_price,
                prev_close=prev_close,
                timestamp=timestamp,
                security_type=security_type
            )
            
        except requests.RequestException as e:
            logger.error(f"Yahoo Finance API请求失败，symbol: {symbol}, error: {e}")
            return None
        except Exception as e:
            logger.error(f"Yahoo Finance数据处理异常，symbol: {symbol}, error: {e}")
            return None
    
    def _convert_to_yahoo_symbol(self, symbol: str) -> Optional[str]:
        """转换A股代码到Yahoo Finance格式"""
        try:
            if symbol.startswith(('6', '9')):  # 上海
                return f"{symbol}.SS"
            elif symbol.startswith(('0', '3')):  # 深圳
                return f"{symbol}.SZ"
            else:
                # 尝试识别完整代码
                if '.SS' in symbol or '.SZ' in symbol:
                    return symbol
                return None
        except Exception:
            return None
    
    def get_batch_data(self, symbols: List[str], security_type: SecurityType = SecurityType.STOCK) -> Dict[str, MarketData]:
        """批量获取市场数据（Yahoo Finance不支持真正的批量，需要逐个请求）"""
        result = {}
        for symbol in symbols:
            data = self.get_data(symbol, security_type)
            if data:
                result[symbol] = data
            # 添加小延迟避免被限流
            time.sleep(0.1)
        return result

class UnifiedMarketDataClient:
    """统一市场数据客户端"""
    
    def __init__(self):
        self.primary_provider = TencentFinanceProvider()
        self.backup_provider = YahooFinanceProvider()
        self.max_retries = 3
        self.retry_delay = 0.5
    
    def get_market_data(self, symbol: str, security_type: SecurityType = SecurityType.STOCK) -> Optional[MarketData]:
        """
        获取市场数据，优先使用腾讯财经，失败时使用Yahoo Finance
        
        Args:
            symbol: 股票代码（如: 600000）
            security_type: 证券类型
            
        Returns:
            MarketData对象或None
        """
        # 首先尝试主数据源（腾讯财经）
        for attempt in range(self.max_retries):
            try:
                data = self.primary_provider.get_data(symbol, security_type)
                if data and data.price > 0:
                    logger.info(f"成功从腾讯财经获取数据: {symbol}")
                    return data
            except Exception as e:
                logger.warning(f"腾讯财经第{attempt + 1}次尝试失败: {e}")
            
            if attempt < self.max_retries - 1:
                time.sleep(self.retry_delay * (attempt + 1))
        
        # 主数据源失败，尝试备用数据源
        logger.warning(f"腾讯财经获取数据失败，尝试Yahoo Finance: {symbol}")
        try:
            data = self.backup_provider.get_data(symbol, security_type)
            if data and data.price > 0:
                logger.info(f"成功从Yahoo Finance获取数据: {symbol}")
                return data
        except Exception as e:
            logger.error(f"Yahoo Finance也失败: {e}")
        
        logger.error(f"所有数据源都失败，无法获取 {symbol} 的数据")
        return None
    
    def get_batch_market_data(self, symbols: List[str], security_type: SecurityType = SecurityType.STOCK) -> Dict[str, MarketData]:
        """
        批量获取市场数据
        
        Args:
            symbols: 股票代码列表
            security_type: 证券类型
            
        Returns:
            {symbol: MarketData} 字典
        """
        if not symbols:
            return {}
        
        # 首先尝试主数据源批量获取
        result = {}
        failed_symbols = []
        
        try:
            primary_result = self.primary_provider.get_batch_data(symbols, security_type)
            for symbol in symbols:
                if symbol in primary_result and primary_result[symbol].price > 0:
                    result[symbol] = primary_result[symbol]
                else:
                    failed_symbols.append(symbol)
        except Exception as e:
            logger.error(f"腾讯财经批量获取失败: {e}")
            failed_symbols = symbols[:]
        
        # 对失败的符号使用备用数据源
        if failed_symbols:
            logger.warning(f"批量获取中 {len(failed_symbols)} 个符号失败，使用备用数据源")
            for symbol in failed_symbols:
                backup_data = self.get_market_data(symbol, security_type)
                if backup_data:
                    result[symbol] = backup_data
        
        return result

# 全局客户端实例
market_data_client = UnifiedMarketDataClient()

def get_stock_data(symbol: str) -> Optional[Dict]:
    """便捷函数：获取单个股票数据"""
    data = market_data_client.get_market_data(symbol, SecurityType.STOCK)
    return data.to_dict() if data else None

def get_batch_stock_data(symbols: List[str]) -> Dict[str, Dict]:
    """便捷函数：批量获取股票数据"""
    data_dict = market_data_client.get_batch_market_data(symbols, SecurityType.STOCK)
    return {symbol: data.to_dict() for symbol, data in data_dict.items()}

if __name__ == "__main__":
    # 简单测试
    client = UnifiedMarketDataClient()
    
    # 测试单个股票
    print("测试单个股票数据:")
    data = client.get_market_data("600000")
    if data:
        print(f"股票: {data.name} ({data.symbol})")
        print(f"价格: {data.price:.2f}, 涨跌幅: {data.change_percent:.2f}%")
        print(f"成交量: {data.volume:,}")
    else:
        print("获取数据失败")
    
    print("\n测试批量股票数据:")
    batch_data = client.get_batch_market_data(["600000", "000001"])
    for symbol, data in batch_data.items():
        print(f"{symbol}: {data.price:.2f} ({data.change_percent:.2f}%)")