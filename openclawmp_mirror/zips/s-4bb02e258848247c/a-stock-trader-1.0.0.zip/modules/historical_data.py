#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - 历史数据获取模块
集成akshare获取高质量的历史行情数据
"""

import akshare as ak
import pandas as pd
import logging
from typing import Optional, Dict, List
from datetime import datetime, timedelta

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class HistoricalDataProvider:
    """历史数据提供者"""
    
    def __init__(self):
        self.cache = {}  # 简单的内存缓存
    
    def get_stock_history(self, symbol: str, days: int = 100) -> Optional[pd.DataFrame]:
        """
        获取股票历史数据
        
        Args:
            symbol: 股票代码 (如: '600000')
            days: 获取多少天的历史数据
            
        Returns:
            包含OHLCV数据的DataFrame，列: date, open, high, low, close, volume
        """
        cache_key = f"{symbol}_{days}"
        if cache_key in self.cache:
            return self.cache[cache_key]
        
        try:
            # 转换股票代码格式（akshare需要带交易所后缀）
            if symbol.startswith(('6', '9')):
                stock_code = f"sh{symbol}"
            elif symbol.startswith(('0', '3')):
                stock_code = f"sz{symbol}"
            else:
                stock_code = symbol
            
            # 计算日期范围
            end_date = datetime.now().strftime("%Y%m%d")
            start_date = (datetime.now() - timedelta(days=days+30)).strftime("%Y%m%d")  # 多获取一些以防节假日
            
            logger.info(f"获取 {symbol} 历史数据，从 {start_date} 到 {end_date}")
            
            # 使用akshare获取历史数据
            df = ak.stock_zh_a_hist(
                symbol=symbol,
                period="daily",
                start_date=start_date,
                end_date=end_date,
                adjust="qfq"  # 前复权
            )
            
            if df.empty:
                logger.warning(f"akshare返回空数据: {symbol}")
                return None
            
            # 重命名列以匹配技术指标模块的期望格式
            column_mapping = {
                '日期': 'date',
                '开盘': 'open', 
                '最高': 'high',
                '最低': 'low',
                '收盘': 'close',
                '成交量': 'volume'
            }
            
            # 只保留需要的列并重命名
            needed_columns = ['日期', '开盘', '最高', '最低', '收盘', '成交量']
            available_columns = [col for col in needed_columns if col in df.columns]
            
            if not available_columns:
                logger.error(f"akshare返回的数据格式不匹配: {df.columns.tolist()}")
                return None
            
            df_filtered = df[available_columns].copy()
            df_filtered.rename(columns=column_mapping, inplace=True)
            
            # 转换日期格式
            df_filtered['date'] = pd.to_datetime(df_filtered['date'])
            
            # 按日期排序
            df_filtered = df_filtered.sort_values('date').reset_index(drop=True)
            
            # 只返回最近days天的数据
            if len(df_filtered) > days:
                df_filtered = df_filtered.tail(days).reset_index(drop=True)
            
            # 缓存结果
            self.cache[cache_key] = df_filtered
            
            logger.info(f"成功获取 {symbol} 历史数据，共 {len(df_filtered)} 条记录")
            return df_filtered
            
        except Exception as e:
            logger.error(f"获取历史数据失败 {symbol}: {e}")
            return None
    
    def get_batch_history(self, symbols: List[str], days: int = 100) -> Dict[str, pd.DataFrame]:
        """
        批量获取历史数据
        
        Args:
            symbols: 股票代码列表
            days: 获取多少天的历史数据
            
        Returns:
            {symbol: DataFrame} 字典
        """
        result = {}
        for symbol in symbols:
            df = self.get_stock_history(symbol, days)
            if df is not None:
                result[symbol] = df
        return result

# 全局历史数据提供者实例
historical_data_provider = HistoricalDataProvider()

def get_historical_data(symbol: str, days: int = 100) -> Optional[pd.DataFrame]:
    """便捷函数：获取单个股票历史数据"""
    return historical_data_provider.get_stock_history(symbol, days)

def get_batch_historical_data(symbols: List[str], days: int = 100) -> Dict[str, pd.DataFrame]:
    """便捷函数：批量获取历史数据"""
    return historical_data_provider.get_batch_history(symbols, days)

if __name__ == "__main__":
    # 测试历史数据获取
    print("测试历史数据获取...")
    df = get_historical_data("600000", 30)
    if df is not None:
        print(f"获取到 {len(df)} 条历史数据")
        print(df.tail())
    else:
        print("获取历史数据失败")