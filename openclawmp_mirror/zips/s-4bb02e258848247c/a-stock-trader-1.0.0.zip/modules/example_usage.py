#!/usr/bin/env python3
"""
A股热点扫描器使用示例
"""

import asyncio
from hot_scanner import HotScanner

async def main():
    # 创建热点扫描器实例
    scanner = HotScanner()
    
    # 配置数据源（示例URL，实际使用时需要替换为真实API）
    config = {
        'cailian': {
            'api_url': 'https://example.com/cailian/api',
            'api_key': 'your_api_key_here'
        },
        'ths': {
            'api_url': 'https://example.com/ths/api', 
            'api_key': 'your_api_key_here'
        }
    }
    
    # 设置配置
    scanner.set_config(config)
    
    # 执行热点扫描
    trending_stocks = await scanner.scan_hot_spots()
    
    # 输出结果
    print("📈 TOP TRENDING:")
    for i, stock in enumerate(trending_stocks[:5], 1):
        print(f"{i}. {stock['code']} {stock['name']} ({stock['reason']})")
        print(f"   涨停: {'是' if stock['limit_up'] else '否'}")
        print(f"   成交量突增: {'是' if stock['volume_spike'] else '否'}")
        print(f"   地缘政治相关: {'是' if stock['geopolitical'] else '否'}")
        print()

if __name__ == "__main__":
    asyncio.run(main())