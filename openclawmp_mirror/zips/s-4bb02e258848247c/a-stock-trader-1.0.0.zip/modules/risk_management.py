#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - 风险管理模块
实现动态止损、阶梯止盈、仓位控制等核心风险管理功能
"""

import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from enum import Enum

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RiskLevel(Enum):
    """风险等级"""
    LOW = "low"
    MEDIUM = "medium" 
    HIGH = "high"
    CRITICAL = "critical"

@dataclass
class Position:
    """持仓信息"""
    symbol: str          # 股票代码
    name: str            # 股票名称  
    quantity: int        # 持仓数量
    cost_price: float    # 成本价
    current_price: float # 当前价格
    market_value: float  # 市值
    unrealized_pnl: float # 未实现盈亏
    unrealized_pnl_pct: float # 未实现盈亏百分比

@dataclass
class StopLossConfig:
    """止损配置"""
    stop_loss_pct: float = -10.0    # 止损百分比 (-10%)
    trailing_stop_pct: float = -5.0 # 移动止损百分比 (-5%)
    hard_stop_enabled: bool = True  # 硬止损开关
    soft_stop_enabled: bool = False # 软止损开关

@dataclass
class TakeProfitConfig:
    """止盈配置"""
    take_profit_levels: List[Tuple[float, float]] = None  # [(目标价, 卖出比例), ...]
    trailing_profit_pct: float = 10.0  # 移动止盈百分比 (10%)

class RiskManager:
    """风险管理器"""
    
    def __init__(self):
        self.stop_loss_config = StopLossConfig()
        self.take_profit_config = TakeProfitConfig(
            take_profit_levels=[(1.1, 0.3), (1.2, 0.3), (1.3, 0.4)]  # +10%, +20%, +30%
        )
        self.max_position_size = 0.3  # 单只股票最大仓位30%
        self.max_total_risk = 0.02    # 总风险不超过2%
    
    def calculate_position_risk(self, position: Position) -> Dict:
        """计算单个持仓的风险指标"""
        # 当前盈亏百分比
        pnl_pct = (position.current_price - position.cost_price) / position.cost_price * 100
        
        # 止损距离
        stop_loss_price = position.cost_price * (1 + self.stop_loss_config.stop_loss_pct / 100)
        stop_distance_pct = (position.current_price - stop_loss_price) / position.current_price * 100
        
        # 止盈距离（第一档）
        first_tp_level = self.take_profit_config.take_profit_levels[0][0] if self.take_profit_config.take_profit_levels else 1.1
        take_profit_price = position.cost_price * first_tp_level
        tp_distance_pct = (take_profit_price - position.current_price) / position.current_price * 100
        
        # 风险等级评估
        risk_level = self._assess_risk_level(pnl_pct, stop_distance_pct)
        
        return {
            'pnl_pct': pnl_pct,
            'stop_loss_price': stop_loss_price,
            'stop_distance_pct': stop_distance_pct,
            'take_profit_price': take_profit_price,
            'tp_distance_pct': tp_distance_pct,
            'risk_level': risk_level,
            'risk_amount': abs(position.unrealized_pnl) if pnl_pct < 0 else 0
        }
    
    def _assess_risk_level(self, pnl_pct: float, stop_distance_pct: float) -> RiskLevel:
        """评估风险等级"""
        if pnl_pct >= 20:
            return RiskLevel.LOW
        elif pnl_pct >= 10:
            return RiskLevel.MEDIUM
        elif pnl_pct >= -5:
            return RiskLevel.HIGH
        else:
            return RiskLevel.CRITICAL
    
    def check_stop_loss_trigger(self, position: Position) -> Tuple[bool, str]:
        """检查是否触发止损"""
        risk_info = self.calculate_position_risk(position)
        
        # 硬止损检查
        if self.stop_loss_config.hard_stop_enabled:
            if risk_info['pnl_pct'] <= self.stop_loss_config.stop_loss_pct:
                return True, f"硬止损触发: 亏损{risk_info['pnl_pct']:.2f}%"
        
        # 移动止损检查
        if self.stop_loss_config.trailing_stop_pct != 0:
            highest_price = self._get_highest_price_since_entry(position.symbol)
            if highest_price > position.cost_price:
                trailing_stop_price = highest_price * (1 + self.stop_loss_config.trailing_stop_pct / 100)
                if position.current_price <= trailing_stop_price:
                    return True, f"移动止损触发: 最高{highest_price:.2f}, 当前{position.current_price:.2f}"
        
        return False, "未触发止损"
    
    def check_take_profit_trigger(self, position: Position) -> Tuple[bool, float, str]:
        """检查是否触发止盈"""
        if not self.take_profit_config.take_profit_levels:
            return False, 0.0, "无止盈配置"
        
        current_price = position.current_price
        cost_price = position.cost_price
        
        # 检查各档止盈
        for i, (multiplier, sell_ratio) in enumerate(self.take_profit_config.take_profit_levels):
            target_price = cost_price * multiplier
            if current_price >= target_price:
                # 检查是否已经部分止盈
                remaining_quantity = self._get_remaining_quantity(position.symbol, i)
                if remaining_quantity > 0:
                    sell_quantity = int(remaining_quantity * sell_ratio)
                    if sell_quantity > 0:
                        return True, sell_quantity, f"第{i+1}档止盈触发: 目标{target_price:.2f}, 当前{current_price:.2f}"
        
        # 移动止盈检查
        if self.take_profit_config.trailing_profit_pct > 0:
            highest_price = self._get_highest_price_since_entry(position.symbol)
            if highest_price > cost_price:
                trailing_profit_price = highest_price * (1 - self.take_profit_config.trailing_profit_pct / 100)
                if current_price <= trailing_profit_price and current_price > cost_price:
                    return True, position.quantity, f"移动止盈触发: 最高{highest_price:.2f}, 当前{current_price:.2f}"
        
        return False, 0.0, "未触发止盈"
    
    def calculate_optimal_position_size(self, symbol: str, account_value: float, volatility: float) -> int:
        """计算最优仓位大小"""
        # 基于波动率调整仓位
        base_position_size = account_value * self.max_position_size
        adjusted_position_size = base_position_size * (1 - min(volatility, 0.5))  # 波动率越高，仓位越小
        
        # 获取当前价格
        current_price = self._get_current_price(symbol)
        if current_price <= 0:
            return 0
        
        # 计算股数
        shares = int(adjusted_position_size / current_price)
        
        # 确保不超过总风险限制
        max_risk_amount = account_value * self.max_total_risk
        stop_loss_distance = abs(self.stop_loss_config.stop_loss_pct) / 100
        max_shares_by_risk = int(max_risk_amount / (current_price * stop_loss_distance))
        
        return min(shares, max_shares_by_risk)
    
    def _get_highest_price_since_entry(self, symbol: str) -> float:
        """获取持仓以来的最高价格"""
        try:
            from .market_data import get_stock_data
            current_data = get_stock_data(symbol)
            if current_data and 'high_price' in current_data:
                return current_data['high_price']
            else:
                # 如果无法获取当日最高价，使用当前价格
                current_price = self._get_current_price(symbol)
                return current_price * 1.05  # 假设最高价比当前价高5%
        except Exception as e:
            logger.warning(f"获取最高价失败 {symbol}: {e}")
            current_price = self._get_current_price(symbol)
            return current_price * 1.05
    
    def _get_current_price(self, symbol: str) -> float:
        """获取当前价格"""
        try:
            from .market_data import get_stock_data
            current_data = get_stock_data(symbol)
            if current_data and 'price' in current_data:
                return current_data['price']
            else:
                logger.warning(f"无法获取当前价格 {symbol}，使用默认值50.0")
                return 50.0
        except Exception as e:
            logger.error(f"获取当前价格失败 {symbol}: {e}")
            return 50.0
    
    def _get_remaining_quantity(self, symbol: str, level: int) -> int:
        """获取剩余可交易数量"""
        # 在实际应用中，这里应该查询交易记录或持仓记录
        # 目前返回一个合理的默认值
        return 100
    
    def assess_portfolio_risk(self, stocks: List[Dict]) -> str:
        """评估投资组合整体风险"""
        if not stocks:
            return "low"
        
        # 计算高风险股票比例
        high_risk_count = sum(1 for stock in stocks if stock.get('risk_level') == 'high' or stock.get('risk_level') == 'critical')
        total_stocks = len(stocks)
        high_risk_ratio = high_risk_count / total_stocks
        
        # 计算整体盈亏
        total_pnl_pct = sum(stock.get('profit_loss_pct', 0) for stock in stocks) / total_stocks
        
        # 综合评估
        if high_risk_ratio > 0.5 or total_pnl_pct < -10:
            return "high"
        elif high_risk_ratio > 0.3 or total_pnl_pct < -5:
            return "medium"
        else:
            return "low"

# 全局风险管理实例
risk_manager = RiskManager()

def set_stop_loss(symbol: str, stop_pct: float = -10.0) -> Dict:
    """设置止损的便捷函数"""
    risk_manager.stop_loss_config.stop_loss_pct = stop_pct
    return {"status": "success", "message": f"止损设置为 {stop_pct}%", "symbol": symbol}

def set_take_profit(symbol: str, levels: List[Tuple[float, float]]) -> Dict:
    """设置止盈的便捷函数"""
    risk_manager.take_profit_config.take_profit_levels = levels
    return {"status": "success", "message": f"止盈级别设置完成", "symbol": symbol, "levels": levels}

def analyze_portfolio_risk(positions: List[Dict]) -> Dict:
    """分析投资组合风险"""
    portfolio_risk = {
        'total_value': 0.0,
        'total_unrealized_pnl': 0.0,
        'positions': [],
        'risk_summary': {}
    }
    
    for pos_data in positions:
        position = Position(**pos_data)
        risk_info = risk_manager.calculate_position_risk(position)
        
        portfolio_risk['total_value'] += position.market_value
        portfolio_risk['total_unrealized_pnl'] += position.unrealized_pnl
        portfolio_risk['positions'].append({
            'symbol': position.symbol,
            'name': position.name,
            'risk_info': risk_info
        })
    
    # 计算整体风险指标
    if portfolio_risk['total_value'] > 0:
        total_pnl_pct = portfolio_risk['total_unrealized_pnl'] / portfolio_risk['total_value'] * 100
        portfolio_risk['risk_summary'] = {
            'total_pnl_pct': total_pnl_pct,
            'portfolio_value': portfolio_risk['total_value'],
            'risk_level': risk_manager._assess_risk_level(total_pnl_pct, 0)
        }
    
    return portfolio_risk

if __name__ == "__main__":
    # 测试风险管理
    test_positions = [
        {
            'symbol': '301236',
            'name': '软通动力', 
            'quantity': 100,
            'cost_price': 72.451,
            'current_price': 68.0,
            'market_value': 6800.0,
            'unrealized_pnl': -445.1,
            'unrealized_pnl_pct': -6.14
        },
        {
            'symbol': '600036',
            'name': '招商银行',
            'quantity': 200,
            'cost_price': 38.98,
            'current_price': 42.5,
            'market_value': 8500.0,
            'unrealized_pnl': 704.0,
            'unrealized_pnl_pct': 9.03
        }
    ]
    
    risk_analysis = analyze_portfolio_risk(test_positions)
    print("投资组合风险分析:")
    print(f"总市值: {risk_analysis['risk_summary']['portfolio_value']:,.2f}")
    print(f"总盈亏: {risk_analysis['risk_summary']['total_pnl_pct']:.2f}%")
    print(f"风险等级: {risk_analysis['risk_summary']['risk_level'].value}")
    
    for pos in risk_analysis['positions']:
        print(f"\n{pos['symbol']} ({pos['name']}):")
        print(f"  盈亏: {pos['risk_info']['pnl_pct']:.2f}%")
        print(f"  止损价: {pos['risk_info']['stop_loss_price']:.2f}")
        print(f"  风险等级: {pos['risk_info']['risk_level'].value}")