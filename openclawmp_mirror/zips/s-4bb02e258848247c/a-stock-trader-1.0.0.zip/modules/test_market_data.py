#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手实时行情模块测试用例
"""

import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import unittest
from unittest.mock import patch, MagicMock
import json
from market_data import (
    MarketData, SecurityType, UnifiedMarketDataClient,
    TencentFinanceProvider, YahooFinanceProvider
)

class TestMarketDataStructures(unittest.TestCase):
    """测试市场数据结构"""
    
    def test_market_data_creation(self):
        """测试MarketData对象创建"""
        data = MarketData(
            symbol="600000",
            name="浦发银行",
            price=9.89,
            change=0.11,
            change_percent=1.12,
            volume=72726000,
            amount=71477814.0,
            open_price=9.78,
            high_price=9.93,
            low_price=9.71,
            prev_close=9.78,
            timestamp="2026-03-08 16:14:02",
            security_type=SecurityType.STOCK
        )
        
        self.assertEqual(data.symbol, "600000")
        self.assertEqual(data.name, "浦发银行")
        self.assertAlmostEqual(data.price, 9.89)
        self.assertAlmostEqual(data.change_percent, 1.12)
        self.assertEqual(data.security_type, SecurityType.STOCK)
    
    def test_market_data_to_dict(self):
        """测试MarketData转字典"""
        data = MarketData(
            symbol="600000",
            name="浦发银行",
            price=9.89,
            change=0.11,
            change_percent=1.12,
            volume=72726000,
            amount=71477814.0,
            open_price=9.78,
            high_price=9.93,
            low_price=9.71,
            prev_close=9.78,
            timestamp="2026-03-08 16:14:02",
            security_type=SecurityType.STOCK
        )
        
        data_dict = data.to_dict()
        self.assertEqual(data_dict['symbol'], "600000")
        self.assertEqual(data_dict['security_type'], "stock")

class TestTencentFinanceProvider(unittest.TestCase):
    """测试腾讯财经数据提供者"""
    
    def setUp(self):
        self.provider = TencentFinanceProvider()
    
    def test_parse_tencent_data_valid(self):
        """测试解析有效的腾讯财经数据"""
        # 模拟腾讯财经返回的数据
        raw_data = 'v_sh600000="1~浦发银行~600000~9.89~9.78~9.74~727260~419722~307538~9.88~2564~9.87~3033~9.86~1612~9.85~1166~9.84~711~9.89~543~9.90~7910~9.91~8068~9.92~4940~9.93~7532~~20260306161402~0.11~1.12~9.90~9.71~9.89/727260/714778140~727260~71478~0.22~6.59~~9.90~9.71~1.94~3293.95~3293.95~0.45~10.76~8.80~0.66~-19907~9.83~6.59~6.59~~~0.55~71477.8140~0.0000~0~ ~GP-A~-20.50~1.75~3.77~5.87~0.50~14.39~9.05~-0.90~-2.56~-13.62~33305838300~33305838300~-52.28~-16.89~33305838300~~~1.75~0.00~~CNY~0~___D__F__N~9.95~-4852~";'
        
        result = self.provider._parse_tencent_data(raw_data, "600000")
        
        self.assertIsNotNone(result)
        self.assertEqual(result.symbol, "600000")
        self.assertEqual(result.name, "浦发银行")
        self.assertAlmostEqual(result.price, 9.89)
        self.assertAlmostEqual(result.change, 0.11)
        self.assertAlmostEqual(result.change_percent, 1.12)
        self.assertEqual(result.volume, 72726000)  # 727260手 * 100
        self.assertAlmostEqual(result.amount, 714778140.0)  # 71477.8140万元 * 10000 = 元
    
    def test_parse_tencent_data_invalid(self):
        """测试解析无效的腾讯财经数据"""
        raw_data = 'invalid_data'
        result = self.provider._parse_tencent_data(raw_data, "600000")
        self.assertIsNone(result)
    
    @patch('market_data.requests.get')
    def test_get_data_success(self, mock_get):
        """测试成功获取数据"""
        mock_response = MagicMock()
        mock_response.text = 'v_sh600000="1~浦发银行~600000~9.89~9.78~9.74~727260~419722~307538~9.88~2564~9.87~3033~9.86~1612~9.85~1166~9.84~711~9.89~543~9.90~7910~9.91~8068~9.92~4940~9.93~7532~~20260306161402~0.11~1.12~9.90~9.71~9.89/727260/714778140~727260~71478~0.22~6.59~~9.90~9.71~1.94~3293.95~3293.95~0.45~10.76~8.80~0.66~-19907~9.83~6.59~6.59~~~0.55~71477.8140~0.0000~0~ ~GP-A~-20.50~1.75~3.77~5.87~0.50~14.39~9.05~-0.90~-2.56~-13.62~33305838300~33305838300~-52.28~-16.89~33305838300~~~1.75~0.00~~CNY~0~___D__F__N~9.95~-4852~";'
        mock_get.return_value = mock_response
        
        result = self.provider.get_data("600000")
        
        self.assertIsNotNone(result)
        self.assertEqual(result.symbol, "600000")
        mock_get.assert_called_once()

class TestYahooFinanceProvider(unittest.TestCase):
    """测试Yahoo Finance数据提供者"""
    
    def setUp(self):
        self.provider = YahooFinanceProvider()
    
    def test_convert_to_yahoo_symbol(self):
        """测试A股代码转换到Yahoo格式"""
        self.assertEqual(self.provider._convert_to_yahoo_symbol("600000"), "600000.SS")
        self.assertEqual(self.provider._convert_to_yahoo_symbol("000001"), "000001.SZ")
        self.assertEqual(self.provider._convert_to_yahoo_symbol("300001"), "300001.SZ")
        self.assertIsNone(self.provider._convert_to_yahoo_symbol("invalid"))

class TestUnifiedMarketDataClient(unittest.TestCase):
    """测试统一市场数据客户端"""
    
    def setUp(self):
        self.client = UnifiedMarketDataClient()
    
    @patch.object(TencentFinanceProvider, 'get_data')
    @patch.object(YahooFinanceProvider, 'get_data')
    def test_get_market_data_primary_success(self, mock_yahoo, mock_tencent):
        """测试主数据源成功的情况"""
        mock_data = MarketData(
            symbol="600000", name="浦发银行", price=9.89, change=0.11,
            change_percent=1.12, volume=72726000, amount=71477814000.0,
            open_price=9.78, high_price=9.93, low_price=9.71, prev_close=9.78,
            timestamp="2026-03-08 16:14:02", security_type=SecurityType.STOCK
        )
        mock_tencent.return_value = mock_data
        
        result = self.client.get_market_data("600000")
        
        self.assertEqual(result, mock_data)
        mock_tencent.assert_called_once()
        mock_yahoo.assert_not_called()
    
    @patch.object(TencentFinanceProvider, 'get_data')
    @patch.object(YahooFinanceProvider, 'get_data')
    def test_get_market_data_fallback(self, mock_yahoo, mock_tencent):
        """测试主数据源失败，使用备用数据源"""
        mock_tencent.return_value = None
        mock_yahoo_data = MarketData(
            symbol="600000", name="浦发银行", price=9.89, change=0.11,
            change_percent=1.12, volume=72726000, amount=71477814000.0,
            open_price=9.78, high_price=9.93, low_price=9.71, prev_close=9.78,
            timestamp="2026-03-08 16:14:02", security_type=SecurityType.STOCK
        )
        mock_yahoo.return_value = mock_yahoo_data
        
        result = self.client.get_market_data("600000")
        
        self.assertEqual(result, mock_yahoo_data)
        self.assertEqual(mock_tencent.call_count, 3)  # 重试3次
        mock_yahoo.assert_called_once()

class TestIntegration(unittest.TestCase):
    """集成测试 - 实际API调用（可选运行）"""
    
    @unittest.skip("跳过实际API调用测试以避免网络依赖")
    def test_real_api_call(self):
        """测试实际API调用"""
        client = UnifiedMarketDataClient()
        
        # 测试单个股票
        data = client.get_market_data("600000")
        self.assertIsNotNone(data)
        self.assertGreater(data.price, 0)
        self.assertIsNotNone(data.name)
        
        # 测试批量获取
        batch_data = client.get_batch_market_data(["600000", "000001"])
        self.assertIn("600000", batch_data)
        self.assertGreater(batch_data["600000"].price, 0)

if __name__ == "__main__":
    # 运行单元测试
    unittest.main(verbosity=2)