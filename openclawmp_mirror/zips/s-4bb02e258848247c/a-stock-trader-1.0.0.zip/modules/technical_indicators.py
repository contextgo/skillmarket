#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手 - 技术指标分析模块
实现MACD、KDJ、布林带、均线系统等核心技术指标
"""

import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional

class TechnicalIndicators:
    """技术指标计算类"""
    
    def __init__(self):
        self.data = None
    
    def load_stock_data(self, stock_code: str, data: pd.DataFrame):
        """
        加载股票数据
        
        Args:
            stock_code: 股票代码 (如 '301236')
            data: 包含 OHLCV 数据的 DataFrame (columns: date, open, high, low, close, volume)
        """
        self.stock_code = stock_code
        self.data = data.copy()
        self.data['date'] = pd.to_datetime(self.data['date'])
        self.data = self.data.sort_values('date').reset_index(drop=True)
    
    def calculate_ma(self, periods: List[int] = [5, 10, 20, 60]) -> Dict[str, pd.Series]:
        """
        计算移动平均线
        
        Args:
            periods: 均线周期列表
            
        Returns:
            字典，键为 'MA{period}'，值为对应的均线序列
        """
        if self.data is None:
            raise ValueError("请先加载股票数据")
        
        ma_dict = {}
        for period in periods:
            ma_dict[f'MA{period}'] = self.data['close'].rolling(window=period).mean()
        
        return ma_dict
    
    def calculate_macd(self, fast_period: int = 12, slow_period: int = 26, signal_period: int = 9) -> Dict[str, pd.Series]:
        """
        计算MACD指标
        
        Args:
            fast_period: 快线周期 (默认12)
            slow_period: 慢线周期 (默认26)  
            signal_period: 信号线周期 (默认9)
            
        Returns:
            包含DIF、DEA、MACD柱的字典
        """
        if self.data is None:
            raise ValueError("请先加载股票数据")
        
        # 计算快慢EMA
        ema_fast = self.data['close'].ewm(span=fast_period, adjust=False).mean()
        ema_slow = self.data['close'].ewm(span=slow_period, adjust=False).mean()
        
        # DIF = EMA(12) - EMA(26)
        dif = ema_fast - ema_slow
        
        # DEA = DIF的9日EMA
        dea = dif.ewm(span=signal_period, adjust=False).mean()
        
        # MACD柱 = (DIF - DEA) * 2
        macd_hist = (dif - dea) * 2
        
        return {
            'DIF': dif,
            'DEA': dea,
            'MACD_Hist': macd_hist
        }
    
    def calculate_kdj(self, n: int = 9, m1: int = 3, m2: int = 3) -> Dict[str, pd.Series]:
        """
        计算KDJ指标
        
        Args:
            n: RSV周期 (默认9)
            m1: K值平滑周期 (默认3)
            m2: D值平滑周期 (默认3)
            
        Returns:
            包含K、D、J值的字典
        """
        if self.data is None:
            raise ValueError("请先加载股票数据")
        
        # 计算RSV (Raw Stochastic Value)
        lowest_low = self.data['low'].rolling(window=n).min()
        highest_high = self.data['high'].rolling(window=n).max()
        rsv = (self.data['close'] - lowest_low) / (highest_high - lowest_low) * 100
        
        # 处理除零情况
        rsv = rsv.replace([np.inf, -np.inf], np.nan).fillna(50)
        
        # K值 = RSV的M1日指数移动平均
        k = rsv.ewm(span=m1, adjust=False).mean()
        
        # D值 = K值的M2日指数移动平均  
        d = k.ewm(span=m2, adjust=False).mean()
        
        # J值 = 3*K - 2*D
        j = 3 * k - 2 * d
        
        return {
            'K': k,
            'D': d,
            'J': j
        }
    
    def calculate_bollinger_bands(self, period: int = 20, std_dev: float = 2.0) -> Dict[str, pd.Series]:
        """
        计算布林带
        
        Args:
            period: 布林带周期 (默认20)
            std_dev: 标准差倍数 (默认2.0)
            
        Returns:
            包含中轨、上轨、下轨的字典
        """
        if self.data is None:
            raise ValueError("请先加载股票数据")
        
        # 中轨 = MA20
        middle_band = self.data['close'].rolling(window=period).mean()
        
        # 标准差
        std = self.data['close'].rolling(window=period).std()
        
        # 上轨 = 中轨 + 2*标准差
        upper_band = middle_band + (std * std_dev)
        
        # 下轨 = 中轨 - 2*标准差  
        lower_band = middle_band - (std * std_dev)
        
        return {
            'Middle_Band': middle_band,
            'Upper_Band': upper_band,
            'Lower_Band': lower_band
        }
    
    def get_all_indicators(self) -> pd.DataFrame:
        """
        获取所有技术指标
        
        Returns:
            包含所有指标的DataFrame
        """
        if self.data is None:
            raise ValueError("请先加载股票数据")
        
        result_df = self.data.copy()
        
        # 计算均线
        ma_dict = self.calculate_ma()
        for key, value in ma_dict.items():
            result_df[key] = value
        
        # 计算MACD
        macd_dict = self.calculate_macd()
        for key, value in macd_dict.items():
            result_df[key] = value
        
        # 计算KDJ
        kdj_dict = self.calculate_kdj()
        for key, value in kdj_dict.items():
            result_df[key] = value
        
        # 计算布林带
        boll_dict = self.calculate_bollinger_bands()
        for key, value in boll_dict.items():
            result_df[key] = value
        
        return result_df
    
    def analyze_signals(self) -> Dict[str, str]:
        """
        分析技术信号
        
        Returns:
            信号分析结果字典
        """
        if self.data is None:
            raise ValueError("请先加载股票数据")
        
        latest = self.get_all_indicators().iloc[-1]
        signals = {}
        
        # MACD信号
        if latest['DIF'] > latest['DEA']:
            signals['MACD'] = '金叉买入'
        else:
            signals['MACD'] = '死叉卖出'
        
        # KDJ信号
        if latest['K'] > latest['D'] and latest['K'] < 80:
            signals['KDJ'] = '金叉买入'
        elif latest['K'] < latest['D'] and latest['K'] > 20:
            signals['KDJ'] = '死叉卖出'
        else:
            signals['KDJ'] = '观望'
        
        # 布林带信号
        if latest['close'] < latest['Lower_Band']:
            signals['Bollinger'] = '超卖买入'
        elif latest['close'] > latest['Upper_Band']:
            signals['Bollinger'] = '超买卖出'
        else:
            signals['Bollinger'] = '中轨震荡'
        
        # 均线信号
        ma_signals = []
        if latest['close'] > latest['MA5'] > latest['MA10'] > latest['MA20']:
            ma_signals.append('多头排列')
        elif latest['close'] < latest['MA5'] < latest['MA10'] < latest['MA20']:
            ma_signals.append('空头排列')
        
        signals['MA'] = ', '.join(ma_signals) if ma_signals else '无明显趋势'
        
        return signals

# 使用示例函数
def get_technical_indicators(stock_code: str, data: pd.DataFrame) -> Dict:
    """
    获取股票技术指标的便捷函数
    
    Args:
        stock_code: 股票代码
        data: 股票数据DataFrame
        
    Returns:
        包含指标数据和信号分析的字典
    """
    indicator = TechnicalIndicators()
    indicator.load_stock_data(stock_code, data)
    
    indicators_df = indicator.get_all_indicators()
    signals = indicator.analyze_signals()
    
    return {
        'indicators': indicators_df,
        'signals': signals
    }

if __name__ == "__main__":
    # 示例数据
    dates = pd.date_range('2024-01-01', periods=100, freq='D')
    np.random.seed(42)
    prices = np.cumsum(np.random.randn(100) * 0.1) + 50
    
    sample_data = pd.DataFrame({
        'date': dates,
        'open': prices + np.random.randn(100) * 0.5,
        'high': prices + np.abs(np.random.randn(100)) * 0.8,
        'low': prices - np.abs(np.random.randn(100)) * 0.8,
        'close': prices,
        'volume': np.random.randint(1000000, 10000000, 100)
    })
    
    # 测试技术指标
    result = get_technical_indicators('301236', sample_data)
    print("技术指标计算完成!")
    print("最新信号:", result['signals'])