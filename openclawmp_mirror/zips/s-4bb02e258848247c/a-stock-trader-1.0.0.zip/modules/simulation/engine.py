"""
A股操盘手模拟交易引擎
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from dataclasses import dataclass

from .config import *

@dataclass
class Position:
    """持仓信息"""
    symbol: str
    shares: int
    cost_basis: float
    entry_date: str
    sector: str = ""

@dataclass  
class Order:
    """订单信息"""
    symbol: str
    order_type: str  # buy, sell, stop_loss, take_profit
    shares: int
    price: float
    date: str
    status: str = "pending"  # pending, filled, cancelled

class SimulationEngine:
    """模拟交易核心引擎"""
    
    def __init__(self, initial_capital: float = INITIAL_CAPITAL):
        self.cash = initial_capital
        self.positions: Dict[str, Position] = {}
        self.orders: List[Order] = []
        self.trade_history = []
        self.equity_curve = []
        self.max_equity = initial_capital
        self.current_date = None
        
    def calculate_commission(self, amount: float) -> float:
        """计算手续费"""
        return max(amount * COMMISSION_RATE, 5.0)  # 最低5元
        
    def calculate_slippage(self, price: float) -> float:
        """计算滑点"""
        return price * (1 + np.random.normal(0, SLIPPAGE_RATE))
        
    def can_buy(self, symbol: str, price: float, shares: int) -> bool:
        """检查是否可以买入"""
        if shares < MIN_TRADE_AMOUNT:
            return False
            
        total_cost = price * shares
        commission = self.calculate_commission(total_cost)
        total_required = total_cost + commission
        
        if self.cash < total_required:
            return False
            
        # 检查涨跌停限制
        if self._is_price_limit_up(symbol, price):
            return False
            
        # 检查仓位限制
        if not self._check_position_limit(symbol, shares):
            return False
            
        return True
        
    def can_sell(self, symbol: str, shares: int) -> bool:
        """检查是否可以卖出"""
        if symbol not in self.positions:
            return False
            
        position = self.positions[symbol]
        if shares > position.shares:
            return False
            
        # 检查T+1限制
        if T_PLUS_1 and not self._can_sell_t_plus_1(symbol):
            return False
            
        # 检查涨跌停限制  
        if self._is_price_limit_down(symbol):
            return False
            
        return True
        
    def execute_buy(self, symbol: str, price: float, shares: int, date: str) -> bool:
        """执行买入"""
        if not self.can_buy(symbol, price, shares):
            return False
            
        actual_price = self.calculate_slippage(price)
        total_cost = actual_price * shares
        commission = self.calculate_commission(total_cost)
        
        self.cash -= (total_cost + commission)
        
        if symbol in self.positions:
            # 加仓
            old_position = self.positions[symbol]
            new_shares = old_position.shares + shares
            new_cost_basis = (old_position.cost_basis * old_position.shares + total_cost) / new_shares
            self.positions[symbol] = Position(
                symbol=symbol,
                shares=new_shares, 
                cost_basis=new_cost_basis,
                entry_date=date,
                sector=old_position.sector
            )
        else:
            # 新建仓位
            self.positions[symbol] = Position(
                symbol=symbol,
                shares=shares,
                cost_basis=actual_price,
                entry_date=date,
                sector=self._get_sector(symbol)
            )
            
        self.trade_history.append({
            'date': date,
            'symbol': symbol, 
            'action': 'buy',
            'shares': shares,
            'price': actual_price,
            'commission': commission,
            'cash_after': self.cash
        })
        
        return True
        
    def execute_sell(self, symbol: str, price: float, shares: int, date: str) -> bool:
        """执行卖出"""
        if not self.can_sell(symbol, shares):
            return False
            
        actual_price = self.calculate_slippage(price)
        position = self.positions[symbol]
        total_value = actual_price * shares
        commission = self.calculate_commission(total_value)
        transfer_tax = total_value * STOCK_TRANSFER_TAX  # 印花税
        
        self.cash += (total_value - commission - transfer_tax)
        
        # 更新仓位
        if shares == position.shares:
            # 清仓
            del self.positions[symbol]
        else:
            # 减仓
            self.positions[symbol] = Position(
                symbol=symbol,
                shares=position.shares - shares,
                cost_basis=position.cost_basis,
                entry_date=position.entry_date,
                sector=position.sector
            )
            
        self.trade_history.append({
            'date': date,
            'symbol': symbol,
            'action': 'sell',
            'shares': shares,
            'price': actual_price,
            'commission': commission + transfer_tax,
            'cash_after': self.cash
        })
        
        return True
        
    def get_portfolio_value(self, market_data: Dict[str, float]) -> float:
        """获取当前投资组合价值"""
        position_value = 0
        for symbol, position in self.positions.items():
            if symbol in market_data:
                position_value += market_data[symbol] * position.shares
                
        total_value = self.cash + position_value
        self.equity_curve.append({
            'date': self.current_date,
            'equity': total_value,
            'cash': self.cash,
            'positions_value': position_value
        })
        
        # 更新最大权益
        if total_value > self.max_equity:
            self.max_equity = total_value
            
        return total_value
        
    def check_risk_limits(self) -> bool:
        """检查风险限制"""
        current_equity = self.equity_curve[-1]['equity'] if self.equity_curve else self.cash
        drawdown = (self.max_equity - current_equity) / self.max_equity
        
        if drawdown > MAX_DRAWDOWN_LIMIT:
            return False
            
        return True
        
    def _is_price_limit_up(self, symbol: str, price: float) -> bool:
        """检查是否涨停（简化实现）"""
        # TODO: 需要前一日收盘价来准确判断
        return False
        
    def _is_price_limit_down(self, symbol: str) -> bool:
        """检查是否跌停（简化实现）"""
        # TODO: 需要前一日收盘价来准确判断  
        return False
        
    def _can_sell_t_plus_1(self, symbol: str) -> bool:
        """检查T+1限制"""
        if symbol not in self.positions:
            return True
            
        position = self.positions[symbol]
        entry_date = datetime.strptime(position.entry_date, '%Y-%m-%d')
        current_date = datetime.strptime(self.current_date, '%Y-%m-%d')
        
        return (current_date - entry_date).days >= 1
        
    def _check_position_limit(self, symbol: str, shares: int) -> bool:
        """检查仓位限制"""
        # 单一个股限制
        if symbol in self.positions:
            total_shares = self.positions[symbol].shares + shares
        else:
            total_shares = shares
            
        # 这里需要市场价格来计算市值，简化处理
        return True
        
    def _get_sector(self, symbol: str) -> str:
        """获取股票所属行业（简化实现）"""
        # TODO: 实际实现需要行业分类数据
        return "unknown"
        
    def reset(self):
        """重置引擎状态"""
        self.cash = INITIAL_CAPITAL
        self.positions = {}
        self.orders = []
        self.trade_history = []
        self.equity_curve = []
        self.max_equity = INITIAL_CAPITAL
        self.current_date = None