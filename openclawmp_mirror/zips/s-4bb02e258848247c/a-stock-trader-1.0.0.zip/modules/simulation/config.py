"""
A股操盘手模拟交易配置文件
"""

# 基础配置
INITIAL_CAPITAL = 100000  # 初始资金 10万元
COMMISSION_RATE = 0.0003  # 手续费 0.03%
SLIPPAGE_RATE = 0.002     # 滑点 0.2%
MIN_TRADE_AMOUNT = 100    # 最小交易单位（股）

# 交易规则
T_PLUS_1 = True           # T+1交易限制
PRICE_LIMIT = 0.1         # 涨跌停限制 10%
STOCK_TRANSFER_TAX = 0.001  # 印花税 0.1% (卖出时收取)

# 风控参数
MAX_POSITION_PER_STOCK = 0.20  # 单一个股最大仓位 20%
MAX_POSITION_PER_SECTOR = 0.40  # 单一行业最大仓位 40%
MAX_DRAWDOWN_LIMIT = 0.15     # 最大回撤限制 15%
STOP_LOSS_LEVELS = [-0.05, -0.08, -0.10]  # 止损级别
TAKE_PROFIT_LEVELS = [0.10, 0.20, 0.30]   # 止盈级别

# 回测参数
BACKTEST_START_DATE = "2026-01-01"
BACKTEST_END_DATE = "2026-03-08"
DATA_FREQUENCY = "daily"  # daily, hourly, minute

# 策略参数
HOT_STOCK_THRESHOLD = 0.5  # 热点股票评分阈值
VOLUME_SURGE_RATIO = 1.5   # 成交量突增倍数
RSI_OVERBOUGHT = 70       # RSI超买阈值
RSI_OVERSOLD = 30         # RSI超卖阈值

# 输出配置
GENERATE_REPORT = True
SAVE_TRADE_LOGS = True
PLOT_EQUITY_CURVE = True