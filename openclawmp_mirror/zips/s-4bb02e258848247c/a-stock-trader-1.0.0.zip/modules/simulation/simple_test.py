"""
A股操盘手模拟交易系统 - 简单测试
"""

# 配置参数
INITIAL_CAPITAL = 100000
COMMISSION_RATE = 0.0003
SLIPPAGE_RATE = 0.002
MIN_TRADE_AMOUNT = 100

class SimpleSimulationEngine:
    """简化版模拟引擎用于测试"""
    
    def __init__(self, initial_capital=INITIAL_CAPITAL):
        self.cash = initial_capital
        self.positions = {}
        self.trade_history = []
        
    def execute_buy(self, symbol, price, shares, date):
        """执行买入"""
        total_cost = price * shares
        commission = max(total_cost * COMMISSION_RATE, 5.0)
        actual_cost = total_cost + commission
        
        if self.cash >= actual_cost and shares >= MIN_TRADE_AMOUNT:
            self.cash -= actual_cost
            if symbol in self.positions:
                old_pos = self.positions[symbol]
                new_shares = old_pos['shares'] + shares
                new_cost = (old_pos['cost_basis'] * old_pos['shares'] + total_cost) / new_shares
                self.positions[symbol] = {'shares': new_shares, 'cost_basis': new_cost}
            else:
                self.positions[symbol] = {'shares': shares, 'cost_basis': price}
                
            self.trade_history.append({
                'date': date, 'symbol': symbol, 'action': 'buy',
                'shares': shares, 'price': price, 'commission': commission
            })
            return True
        return False
        
    def execute_sell(self, symbol, price, shares, date):
        """执行卖出"""
        if symbol not in self.positions or shares > self.positions[symbol]['shares']:
            return False
            
        total_value = price * shares
        commission = max(total_value * COMMISSION_RATE, 5.0)
        transfer_tax = total_value * 0.001  # 印花税
        actual_value = total_value - commission - transfer_tax
        
        self.cash += actual_value
        self.positions[symbol]['shares'] -= shares
        
        if self.positions[symbol]['shares'] == 0:
            del self.positions[symbol]
            
        self.trade_history.append({
            'date': date, 'symbol': symbol, 'action': 'sell',
            'shares': shares, 'price': price, 'commission': commission + transfer_tax
        })
        return True
        
    def get_portfolio_value(self, market_prices):
        """获取投资组合价值"""
        position_value = sum(
            self.positions[sym]['shares'] * market_prices.get(sym, 0)
            for sym in self.positions
        )
        return self.cash + position_value

def test_basic_functionality():
    """测试基本功能"""
    print("🧪 测试A股操盘手模拟交易系统...")
    
    engine = SimpleSimulationEngine()
    print(f"初始资金: {engine.cash:,.2f} 元")
    
    # 测试买入
    success = engine.execute_buy("600036", 38.98, 1000, "2026-03-08")
    print(f"买入测试: {'✅ 成功' if success else '❌ 失败'}")
    print(f"当前现金: {engine.cash:,.2f} 元")
    print(f"持仓: {engine.positions}")
    
    # 测试卖出
    if success:
        success = engine.execute_sell("600036", 40.00, 500, "2026-03-09")
        print(f"卖出测试: {'✅ 成功' if success else '❌ 失败'}")
        print(f"当前现金: {engine.cash:,.2f} 元")
        print(f"持仓: {engine.positions}")
    
    # 测试投资组合价值
    portfolio_value = engine.get_portfolio_value({"600036": 40.00})
    print(f"投资组合总价值: {portfolio_value:,.2f} 元")
    
    print("\n✅ 基本功能测试完成!")

if __name__ == "__main__":
    test_basic_functionality()