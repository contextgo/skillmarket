"""
A股操盘手回测执行器
"""

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict

from .engine import SimulationEngine
from .config import *
from .strategy import AShareStrategy
from .performance import PerformanceAnalyzer

class BacktestRunner:
    """回测执行器"""
    
    def __init__(self, symbols: List[str], start_date: str, end_date: str):
        self.symbols = symbols
        self.start_date = start_date
        self.end_date = end_date
        self.engine = SimulationEngine()
        self.strategy = AShareStrategy()
        self.analyzer = PerformanceAnalyzer()
        
    def run_backtest(self) -> Dict:
        """执行回测"""
        print(f"🚀 开始回测: {self.start_date} 到 {self.end_date}")
        print(f"📊 股票池: {len(self.symbols)} 只股票")
        print(f"💰 初始资金: {INITIAL_CAPITAL:,} 元")
        
        # 获取历史数据
        historical_data = self._load_historical_data()
        if historical_data.empty:
            print("❌ 历史数据加载失败")
            return {}
            
        # 按日期排序
        dates = sorted(historical_data.index.unique())
        trading_days = [d for d in dates if self.start_date <= d <= self.end_date]
        
        print(f"📈 回测天数: {len(trading_days)} 天")
        
        # 初始化
        self.engine.reset()
        portfolio_values = []
        
        for i, date in enumerate(trading_days):
            self.engine.current_date = date
            print(f"\r🔄 进度: {i+1}/{len(trading_days)} ({date})", end="", flush=True)
            
            # 获取当日市场数据
            market_data = historical_data.loc[date].to_dict()
            
            # 执行交易策略
            signals = self.strategy.generate_signals(date, market_data, self.engine.positions)
            
            # 执行买入信号
            for symbol, signal in signals.get('buy', {}).items():
                if symbol in market_data:
                    price = market_data[symbol]
                    shares = self._calculate_position_size(price, signal['confidence'])
                    self.engine.execute_buy(symbol, price, shares, date)
                    
            # 执行卖出信号（包括止损止盈）
            for symbol, signal in signals.get('sell', {}).items():
                if symbol in self.engine.positions:
                    position = self.engine.positions[symbol]
                    price = market_data.get(symbol, position.cost_basis)
                    shares_to_sell = self._calculate_sell_shares(position.shares, signal['type'])
                    self.engine.execute_sell(symbol, price, shares_to_sell, date)
                    
            # 计算当日投资组合价值
            portfolio_value = self.engine.get_portfolio_value(market_data)
            portfolio_values.append(portfolio_value)
            
            # 检查风险限制
            if not self.engine.check_risk_limits():
                print(f"\n⚠️  触发最大回撤限制，停止交易")
                break
                
        print(f"\n✅ 回测完成!")
        
        # 生成绩效报告
        performance_report = self.analyzer.generate_report(
            self.engine.trade_history,
            self.engine.equity_curve,
            INITIAL_CAPITAL
        )
        
        return performance_report
        
    def _load_historical_data(self) -> pd.DataFrame:
        """加载历史数据（简化实现）"""
        # TODO: 实际实现需要从腾讯财经或东方财富获取历史K线数据
        # 这里返回模拟数据用于测试
        dates = pd.date_range(start=self.start_date, end=self.end_date, freq='D')
        data = {}
        
        for symbol in self.symbols:
            # 生成模拟价格数据
            prices = np.random.normal(20, 2, len(dates))
            prices = np.maximum(prices, 1)  # 确保价格为正
            data[symbol] = prices
            
        df = pd.DataFrame(data, index=dates)
        df.index = df.index.strftime('%Y-%m-%d')
        return df
        
    def _calculate_position_size(self, price: float, confidence: float) -> int:
        """计算仓位大小"""
        # 基于信心度和可用资金计算
        risk_per_trade = self.engine.cash * 0.1  # 单笔交易风险10%
        position_value = risk_per_trade / (price * 0.1)  # 假设10%止损
        shares = int(position_value / price)
        return max(shares, MIN_TRADE_AMOUNT)
        
    def _calculate_sell_shares(self, total_shares: int, sell_type: str) -> int:
        """计算卖出数量"""
        if sell_type == 'take_profit_1':
            return int(total_shares * 0.3)  # 卖出30%
        elif sell_type == 'take_profit_2':
            return int(total_shares * 0.5)  # 卖出50%
        elif sell_type == 'stop_loss':
            return total_shares  # 全部卖出
        else:
            return total_shares  # 默认全部卖出

# 测试函数
def test_simulation():
    """测试模拟交易系统"""
    print("🧪 测试模拟交易系统...")
    
    # 创建测试股票池
    test_symbols = ["600036", "000001", "300059", "600519", "000858"]
    
    # 创建回测器
    runner = BacktestRunner(
        symbols=test_symbols,
        start_date=BACKTEST_START_DATE,
        end_date=BACKTEST_END_DATE
    )
    
    # 执行回测
    report = runner.run_backtest()
    
    if report:
        print("\n📊 测试结果:")
        print(f"   最终净值: {report['final_value']:,.2f}")
        print(f"   总收益率: {report['total_return']:.2%}")
        print(f"   最大回撤: {report['max_drawdown']:.2%}")
        print(f"   交易次数: {report['total_trades']}")
    else:
        print("❌ 回测失败")

if __name__ == "__main__":
    test_simulation()