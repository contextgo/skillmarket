#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KDJ (随机指标) 计算
"""

import pandas as pd
from typing import List, Dict, Union

def calculate_rsv(closes: List[float], highs: List[float], lows: List[float], period: int = 9) -> List[float]:
    """计算RSV (Raw Stochastic Value)"""
    if len(closes) != len(highs) or len(closes) != len(lows):
        raise ValueError("价格列表长度必须一致")
    
    if len(closes) < period:
        raise ValueError(f"需要至少{period}个数据点")
    
    rsv_values = []
    for i in range(len(closes)):
        if i < period - 1:
            rsv_values.append(50.0)  # 初始值
        else:
            high_n = max(highs[i-period+1:i+1])
            low_n = min(lows[i-period+1:i+1])
            close = closes[i]
            
            if high_n == low_n:
                rsv = 50.0
            else:
                rsv = (close - low_n) / (high_n - low_n) * 100
            
            rsv_values.append(rsv)
    
    return rsv_values

def calculate_sma(values: List[float], period: int, weight: int = 1) -> List[float]:
    """计算平滑移动平均(SMA)"""
    if len(values) < period:
        raise ValueError(f"需要至少{period}个数据点")
    
    sma_values = [values[0]]  # 初始值
    for i in range(1, len(values)):
        sma = (weight * values[i] + (period - weight) * sma_values[-1]) / period
        sma_values.append(sma)
    
    return sma_values

def calculate_kdj(closes: List[float], highs: List[float], lows: List[float]) -> Dict[str, Union[List[float], str]]:
    """
    计算KDJ指标
    RSV = (Close - Low9) / (High9 - Low9) * 100
    K = SMA(RSV, 3, 1)
    D = SMA(K, 3, 1)
    J = 3*K - 2*D
    
    Args:
        closes: 收盘价列表
        highs: 最高价列表  
        lows: 最低价列表
        
    Returns:
        包含K、D、J值和交易信号的字典
    """
    if len(closes) < 9:
        raise ValueError("需要至少9个数据点计算KDJ")
    
    # 计算RSV
    rsv = calculate_rsv(closes, highs, lows, 9)
    
    # 计算K值 (SMA of RSV with period=3, weight=1)
    k_values = [50.0]  # 初始K值
    for i in range(1, len(rsv)):
        k = (2 * k_values[-1] + rsv[i]) / 3
        k_values.append(k)
    
    # 计算D值 (SMA of K with period=3, weight=1)
    d_values = [50.0]  # 初始D值
    for i in range(1, len(k_values)):
        d = (2 * d_values[-1] + k_values[i]) / 3
        d_values.append(d)
    
    # 计算J值
    j_values = [3 * k_values[i] - 2 * d_values[i] for i in range(len(k_values))]
    
    # 交易信号判断
    last_k = k_values[-1]
    last_d = d_values[-1]
    
    if last_k > last_d and last_k < 20:
        signal = 'buy'  # 超卖区金叉
    elif last_k < last_d and last_k > 80:
        signal = 'sell'  # 超买区死叉
    elif last_k > 80:
        signal = 'overbought'  # 超买
    elif last_k < 20:
        signal = 'oversold'  # 超卖
    else:
        signal = 'hold'
    
    return {
        'k': k_values,
        'd': d_values,
        'j': j_values,
        'signal': signal,
        'last_k': last_k,
        'last_d': last_d,
        'last_j': j_values[-1] if j_values else None
    }

if __name__ == "__main__":
    # 测试示例
    test_closes = [100 + i * 0.5 for i in range(20)]
    test_highs = [price + 2 for price in test_closes]
    test_lows = [price - 2 for price in test_closes]
    
    result = calculate_kdj(test_closes, test_highs, test_lows)
    print(f"KDJ结果: K={result['last_k']:.2f}, D={result['last_d']:.2f}, J={result['last_j']:.2f}, 信号={result['signal']}")