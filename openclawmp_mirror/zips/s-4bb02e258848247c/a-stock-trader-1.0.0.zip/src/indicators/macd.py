#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MACD (Moving Average Convergence Divergence) 指标计算
"""

import pandas as pd
from typing import List, Dict, Union

def calculate_ema(prices: List[float], period: int) -> List[float]:
    """计算指数移动平均线(EMA)"""
    if len(prices) < period:
        raise ValueError(f"需要至少{period}个价格数据点")
    
    series = pd.Series(prices)
    ema = series.ewm(span=period, adjust=False).mean()
    return ema.tolist()

def calculate_macd(prices: List[float]) -> Dict[str, Union[List[float], str]]:
    """
    计算MACD指标
    MACD = EMA(12) - EMA(26)
    Signal = EMA(MACD, 9)
    Histogram = MACD - Signal
    
    Args:
        prices: 收盘价列表
        
    Returns:
        包含MACD线、信号线、柱状图和趋势的字典
    """
    if len(prices) < 26:
        raise ValueError("需要至少26个价格数据点计算MACD")
    
    # 计算EMA12和EMA26
    ema12 = calculate_ema(prices, 12)
    ema26 = calculate_ema(prices, 26)
    
    # 计算MACD线
    macd_line = [ema12[i] - ema26[i] for i in range(len(ema12))]
    
    # 计算信号线 (EMA9 of MACD)
    signal_line = calculate_ema(macd_line, 9)
    
    # 计算柱状图
    histogram = [macd_line[i] - signal_line[i] for i in range(len(signal_line))]
    
    # 趋势判断 (基于最后两个点)
    if len(macd_line) >= 2 and len(signal_line) >= 2:
        current_trend = 'bullish' if macd_line[-1] > signal_line[-1] else 'bearish'
        previous_trend = 'bullish' if macd_line[-2] > signal_line[-2] else 'bearish'
        
        # 金叉/死叉信号
        if previous_trend == 'bearish' and current_trend == 'bullish':
            signal = 'golden_cross'
        elif previous_trend == 'bullish' and current_trend == 'bearish':
            signal = 'death_cross'
        else:
            signal = 'no_cross'
    else:
        current_trend = 'unknown'
        signal = 'insufficient_data'
    
    return {
        'macd_line': macd_line,
        'signal_line': signal_line,
        'histogram': histogram,
        'trend': current_trend,
        'signal': signal,
        'last_macd': macd_line[-1] if macd_line else None,
        'last_signal': signal_line[-1] if signal_line else None,
        'last_histogram': histogram[-1] if histogram else None
    }

if __name__ == "__main__":
    # 测试示例
    test_prices = [100 + i * 0.5 for i in range(50)]  # 模拟上涨价格
    result = calculate_macd(test_prices)
    print(f"MACD结果: 趋势={result['trend']}, 信号={result['signal']}")