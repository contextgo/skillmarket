#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
布林带 (Bollinger Bands) 计算
"""

import pandas as pd
import numpy as np
from typing import List, Dict, Union

def calculate_bollinger_bands(prices: List[float], period: int = 20, std_multiplier: float = 2.0) -> Dict[str, Union[List[float], str]]:
    """
    计算布林带
    Middle = MA(period)
    Upper = Middle + std_multiplier * STD(period)
    Lower = Middle - std_multiplier * STD(period)
    
    Args:
        prices: 价格列表
        period: 移动平均周期，默认20
        std_multiplier: 标准差倍数，默认2.0
        
    Returns:
        包含上轨、中轨、下轨、带宽和交易信号的字典
    """
    if len(prices) < period:
        raise ValueError(f"需要至少{period}个价格数据点")
    
    series = pd.Series(prices)
    
    # 计算中轨（移动平均线）
    middle_band = series.rolling(window=period).mean()
    
    # 计算标准差
    std_dev = series.rolling(window=period).std()
    
    # 计算上轨和下轨
    upper_band = middle_band + std_multiplier * std_dev
    lower_band = middle_band - std_multiplier * std_dev
    
    # 计算带宽
    bandwidth = (upper_band - lower_band) / middle_band * 100
    
    # 当前价格位置判断
    current_price = prices[-1]
    current_middle = middle_band.iloc[-1]
    current_upper = upper_band.iloc[-1]
    current_lower = lower_band.iloc[-1]
    
    if pd.isna(current_upper) or pd.isna(current_lower):
        position = 'insufficient_data'
        signal = 'hold'
    elif current_price > current_upper:
        position = 'above_upper'
        signal = 'sell'  # 价格突破上轨，超买信号
    elif current_price < current_lower:
        position = 'below_lower'
        signal = 'buy'   # 价格跌破下轨，超卖信号
    else:
        position = 'within_bands'
        signal = 'hold'
    
    return {
        'upper_band': upper_band.tolist(),
        'middle_band': middle_band.tolist(),
        'lower_band': lower_band.tolist(),
        'bandwidth': bandwidth.tolist(),
        'position': position,
        'signal': signal,
        'last_upper': current_upper if not pd.isna(current_upper) else None,
        'last_middle': current_middle if not pd.isna(current_middle) else None,
        'last_lower': current_lower if not pd.isna(current_lower) else None,
        'last_bandwidth': bandwidth.iloc[-1] if not pd.isna(bandwidth.iloc[-1]) else None
    }

if __name__ == "__main__":
    # 测试示例
    test_prices = [100 + np.sin(i * 0.1) * 5 for i in range(50)]
    result = calculate_bollinger_bands(test_prices)
    print(f"布林带结果: 位置={result['position']}, 信号={result['signal']}")
    print(f"上轨={result['last_upper']:.2f}, 中轨={result['last_middle']:.2f}, 下轨={result['last_lower']:.2f}")