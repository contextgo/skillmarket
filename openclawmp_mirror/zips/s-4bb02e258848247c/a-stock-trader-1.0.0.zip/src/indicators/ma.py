#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
移动平均线 (Moving Average) 计算
"""

import pandas as pd
from typing import List, Dict, Union

def calculate_ma(prices: List[float], period: int) -> List[float]:
    """计算简单移动平均线(SMA)"""
    if len(prices) < period:
        raise ValueError(f"需要至少{period}个价格数据点")
    
    series = pd.Series(prices)
    ma = series.rolling(window=period).mean()
    return ma.tolist()

def calculate_moving_averages(prices: List[float]) -> Dict[str, Union[List[float], str]]:
    """
    计算多周期移动平均线
    MA5, MA10, MA20, MA60
    
    Args:
        prices: 价格列表
        
    Returns:
        包含各周期均线和趋势分析的字典
    """
    ma_results = {}
    
    # 计算各周期均线
    periods = [5, 10, 20, 60]
    for period in periods:
        try:
            ma_values = calculate_ma(prices, period)
            ma_results[f'ma{period}'] = ma_values
            ma_results[f'last_ma{period}'] = ma_values[-1] if ma_values else None
        except ValueError:
            ma_results[f'ma{period}'] = []
            ma_results[f'last_ma{period}'] = None
    
    # 趋势分析
    valid_mas = []
    for period in periods:
        last_ma = ma_results[f'last_ma{period}']
        if last_ma is not None:
            valid_mas.append(last_ma)
    
    if len(valid_mas) >= 2:
        # 检查短期均线是否在长期均线上方（多头排列）
        ma_trend_values = [ma_results[f'last_ma{p}'] for p in periods if ma_results[f'last_ma{p}'] is not None]
        if len(ma_trend_values) >= 2:
            # 检查是否呈现上升趋势（短期 > 长期）
            is_bullish = all(ma_trend_values[i] >= ma_trend_values[i+1] 
                           for i in range(len(ma_trend_values)-1))
            # 检查是否呈现下降趋势（短期 < 长期）  
            is_bearish = all(ma_trend_values[i] <= ma_trend_values[i+1] 
                           for i in range(len(ma_trend_values)-1))
            
            if is_bullish:
                trend = 'bullish'
            elif is_bearish:
                trend = 'bearish'
            else:
                trend = 'sideways'
        else:
            trend = 'unknown'
    else:
        trend = 'insufficient_data'
    
    ma_results['trend'] = trend
    
    # 交叉信号检测
    signal = 'hold'
    if ma_results['last_ma5'] and ma_results['last_ma10']:
        # MA5与MA10交叉
        if len(ma_results['ma5']) >= 2 and len(ma_results['ma10']) >= 2:
            prev_ma5 = ma_results['ma5'][-2]
            prev_ma10 = ma_results['ma10'][-2]
            curr_ma5 = ma_results['ma5'][-1]
            curr_ma10 = ma_results['ma10'][-1]
            
            # 金叉
            if prev_ma5 <= prev_ma10 and curr_ma5 > curr_ma10:
                signal = 'golden_cross_ma5_10'
            # 死叉
            elif prev_ma5 >= prev_ma10 and curr_ma5 < curr_ma10:
                signal = 'death_cross_ma5_10'
    
    ma_results['signal'] = signal
    
    return ma_results

if __name__ == "__main__":
    # 测试示例
    test_prices = [100 + i * 0.5 for i in range(70)]  # 足够长的数据
    result = calculate_moving_averages(test_prices)
    print(f"均线结果: 趋势={result['trend']}, 信号={result['signal']}")
    print(f"MA5={result['last_ma5']:.2f}, MA10={result['last_ma10']:.2f}, MA20={result['last_ma20']:.2f}, MA60={result['last_ma60']:.2f}")