#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
A股操盘手实时行情获取模块
集成腾讯财经API获取A股、ETF、基金的实时数据
"""

import requests
import re
import logging
from typing import Dict, Optional, Union

# 配置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class RealtimeQuoteError(Exception):
    """实时行情获取异常"""
    pass

def _parse_stock_code(stock_code: str) -> str:
    """
    解析股票代码，自动添加市场前缀
    
    Args:
        stock_code (str): 股票代码，支持多种格式
            - 6位数字：000001, 600519
            - 带前缀：sz000001, sh600519
            - 基金代码：510050, 159915等
    
    Returns:
        str: 标准化的腾讯财经股票代码格式
        
    Raises:
        ValueError: 股票代码格式无效
    """
    if not stock_code:
        raise ValueError("股票代码不能为空")
    
    # 移除空格和特殊字符
    stock_code = re.sub(r'[^\d\w]', '', stock_code).lower()
    
    # 如果已经包含市场前缀，直接返回
    if stock_code.startswith(('sh', 'sz', 'hk', 'us')):
        return stock_code
    
    # 验证是否为6位数字
    if not stock_code.isdigit() or len(stock_code) != 6:
        raise ValueError(f"无效的股票代码格式: {stock_code}")
    
    # 根据股票代码前缀确定市场
    # 上海证券交易所代码规则:
    # 60开头：A股主板
    # 68开头：科创板
    # 51、58开头：ETF
    # 90开头：B股
    if (stock_code.startswith('60') or 
        stock_code.startswith('68') or 
        stock_code.startswith('51') or 
        stock_code.startswith('58') or 
        stock_code.startswith('90')):
        return f"sh{stock_code}"
    # 深圳证券交易所代码规则:
    # 00开头：A股主板/中小板
    # 30开头：创业板
    # 15开头：ETF
    # 20开头：B股
    elif (stock_code.startswith('00') or 
          stock_code.startswith('30') or 
          stock_code.startswith('15') or 
          stock_code.startswith('20')):
        return f"sz{stock_code}"
    else:
        # 默认尝试上海市场（很多ETF在上交所）
        return f"sh{stock_code}"

def _parse_tencent_response(response_text: str) -> Dict[str, Union[str, float, int]]:
    """
    解析腾讯财经API返回的数据
    
    腾讯财经返回格式示例:
    v_sz000001="51~平安银行~000001~10.82~10.81~10.78~476577~244185~232392~10.82~6320~10.81~6980~10.80~11800~..."
    
    字段说明:
    0: 类型代码 (51表示股票, 1表示ETF/基金)
    1: 股票名称
    2: 股票代码
    3: 当前价格
    4: 最高价
    5: 最低价
    6: 成交量 (手)
    7: 外盘 (手)
    8: 内盘 (手)
    9: 买一价
    10: 买一量 (手)
    11: 卖一价
    12: 卖一量 (手)
    ...
    
    Args:
        response_text (str): API返回的原始文本
        
    Returns:
        Dict: 结构化的股票数据字典
    """
    if not response_text.strip():
        raise RealtimeQuoteError("API返回空数据")
    
    # 检查是否为无匹配结果
    if 'v_pv_none_match="1"' in response_text:
        raise RealtimeQuoteError("未找到对应的股票代码，请检查代码是否正确")
    
    # 腾讯财经返回格式: v_xxxx="字段1~字段2~字段3~..."
    # 处理多种可能的变量名格式
    match = re.search(r'v_[a-zA-Z0-9_]+="([^"]*)"', response_text)
    if not match:
        # 如果标准格式不匹配，尝试更宽松的匹配
        match = re.search(r'="([^"]*)"', response_text)
        if not match:
            raise RealtimeQuoteError(f"无法解析API返回数据: {response_text[:100]}...")
    
    data_parts = match.group(1).split('~')
    
    if len(data_parts) < 7:
        raise RealtimeQuoteError(f"API返回数据字段不足: {len(data_parts)}个字段，内容: {data_parts}")
    
    try:
        # 提取关键字段
        stock_name = data_parts[1] if len(data_parts) > 1 and data_parts[1] else "未知"
        current_price = float(data_parts[3]) if len(data_parts) > 3 and data_parts[3] else 0.0
        high_price = float(data_parts[4]) if len(data_parts) > 4 and data_parts[4] else 0.0
        low_price = float(data_parts[5]) if len(data_parts) > 5 and data_parts[5] else 0.0
        volume = int(data_parts[6]) if len(data_parts) > 6 and data_parts[6] else 0
        
        # 由于腾讯接口不直接提供昨收、涨跌幅等信息，我们暂时设置为0
        # 在实际应用中，可能需要通过其他方式获取这些数据
        open_price = current_price  # 开盘价暂用当前价
        prev_close = current_price  # 昨收暂用当前价
        change_amount = 0.0  # 涨跌额
        change_percent = 0.0  # 涨跌幅
        amount = 0.0  # 成交额（需要从其他字段计算）
        
        # 尝试从后续字段获取更多信息
        if len(data_parts) > 25:
            # 第25个字段可能是成交额（单位：元）
            try:
                amount_str = data_parts[25]
                if amount_str and amount_str.replace('.', '').isdigit():
                    amount = float(amount_str)
            except (ValueError, IndexError):
                pass
        
        return {
            "stock_code": "",  # 将在外部设置
            "stock_name": stock_name,
            "current_price": current_price,
            "change_amount": change_amount,
            "change_percent": change_percent,
            "volume": volume,
            "amount": amount,
            "open_price": open_price,
            "high_price": high_price,
            "low_price": low_price,
            "prev_close": prev_close,
            "status": "success"
        }
    except (ValueError, IndexError) as e:
        raise RealtimeQuoteError(f"解析数据时出错: {e}, 数据长度: {len(data_parts)}")

def get_realtime_quote(stock_code: str, timeout: int = 10) -> Dict[str, Union[str, float, int]]:
    """
    获取A股、ETF、基金的实时行情数据
    
    Args:
        stock_code (str): 股票代码，支持以下格式：
            - 6位数字：000001, 600519, 510050, 159915
            - 带前缀：sz000001, sh600519
        timeout (int): 请求超时时间（秒），默认10秒
        
    Returns:
        Dict: 包含以下字段的结构化数据字典：
            - stock_code: 标准化后的股票代码
            - stock_name: 股票名称
            - current_price: 当前价格
            - change_amount: 涨跌额（由于腾讯接口限制，此字段可能为0）
            - change_percent: 涨跌幅（百分比）（由于腾讯接口限制，此字段可能为0）
            - volume: 成交量（手）
            - amount: 成交额（元）
            - open_price: 开盘价
            - high_price: 最高价
            - low_price: 最低价
            - prev_close: 昨日收盘价
            - status: 状态（success/error）
            
    Raises:
        RealtimeQuoteError: API调用失败或数据解析错误
        ValueError: 股票代码格式无效
        requests.RequestException: 网络请求异常
    """
    try:
        # 解析和标准化股票代码
        normalized_code = _parse_stock_code(stock_code)
        
        # 构建API URL
        api_url = f"http://qt.gtimg.cn/q={normalized_code}"
        logger.info(f"请求腾讯财经API: {api_url}")
        
        # 发送HTTP请求
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        response = requests.get(api_url, headers=headers, timeout=timeout)
        response.raise_for_status()
        
        # 解析响应数据
        quote_data = _parse_tencent_response(response.text)
        quote_data["stock_code"] = normalized_code
        
        logger.info(f"成功获取 {normalized_code} 实时行情数据")
        return quote_data
        
    except requests.exceptions.Timeout:
        error_msg = f"请求超时（{timeout}秒）: {stock_code}"
        logger.error(error_msg)
        raise RealtimeQuoteError(error_msg)
    except requests.exceptions.ConnectionError:
        error_msg = f"网络连接错误: {stock_code}"
        logger.error(error_msg)
        raise RealtimeQuoteError(error_msg)
    except requests.exceptions.HTTPError as e:
        error_msg = f"HTTP错误 {e.response.status_code}: {stock_code}"
        logger.error(error_msg)
        raise RealtimeQuoteError(error_msg)
    except Exception as e:
        error_msg = f"获取实时行情时发生未知错误: {e}"
        logger.error(error_msg)
        raise RealtimeQuoteError(error_msg)

# 便捷函数：批量获取多个股票的实时行情
def get_realtime_quotes(stock_codes: list, timeout: int = 10) -> Dict[str, Dict]:
    """
    批量获取多个股票的实时行情数据
    
    Args:
        stock_codes (list): 股票代码列表
        timeout (int): 请求超时时间（秒）
        
    Returns:
        Dict: 以股票代码为键，行情数据为值的字典
    """
    results = {}
    for code in stock_codes:
        try:
            results[code] = get_realtime_quote(code, timeout)
        except Exception as e:
            results[code] = {
                "stock_code": code,
                "status": "error",
                "error": str(e)
            }
    return results

if __name__ == "__main__":
    # 测试示例
    try:
        # 测试股票
        print("=== 测试股票行情 ===")
        stock_quote = get_realtime_quote("000001")  # 平安银行
        print(f"股票: {stock_quote['stock_name']} ({stock_quote['stock_code']})")
        print(f"当前价格: {stock_quote['current_price']}")
        print(f"最高价: {stock_quote['high_price']}")
        print(f"最低价: {stock_quote['low_price']}")
        print(f"成交量: {stock_quote['volume']:,} 手")
        
        print("\n=== 测试ETF行情 ===")
        etf_quote = get_realtime_quote("510050")  # 上证50ETF
        print(f"ETF: {etf_quote['stock_name']} ({etf_quote['stock_code']})")
        print(f"当前价格: {etf_quote['current_price']}")
        print(f"最高价: {etf_quote['high_price']}")
        print(f"最低价: {etf_quote['low_price']}")
        
    except RealtimeQuoteError as e:
        print(f"错误: {e}")
    except Exception as e:
        print(f"未知错误: {e}")