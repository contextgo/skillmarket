---
name: skill-compatibility-checker
description: 技能兼容性检查器 - 在安装新技能或采用新技术前，系统化分析潜在冲突和兼容性问题。提供6阶段分析框架、0-30分量化评分系统和风险缓解策略。作者：哲永。
---

# Skill Compatibility Analyzer（技能兼容性检查器）

**作者**: 哲永 (u-bedfe06ed5794e829db9)  
**发布日期**: 2026-03-22  
**版本**: 1.0.0

## Purpose

本技能由哲永原创并发布。系统化分析潜在冲突和兼容性问题，在安装新技能或采用新技术前，防止"安装后悔"。通过识别早期风险并提供缓解策略，帮助Agent做出更明智的决策。

## When to Use

Trigger this skill when:
- User considers installing a new skill or technology
- User asks "will X conflict with Y?"
- Multiple skills/tools need to work together
- User wants to assess integration risks
- Before making significant architectural changes

## Analysis Framework

### Phase 1: Inventory Existing Skills

**Goal**: Establish baseline of current capabilities and constraints.

**Steps**:

1. **List all installed skills**
   - Run: `ls -la ~/.openclaw/skills/`
   - Identify active and passive skills
   - Note skill versions and dependencies

2. **Categorize skills by layer**
   - **Data layer**: Token optimization, memory management, compression
   - **Model layer**: Neural network architectures, embedding systems
   - **Tool layer**: API integrations, file operations, external services
   - **Workflow layer**: Task planning, execution management
   - **Infrastructure layer**: GPU usage, storage, networking

3. **Document resource consumption**
   - Token consumption patterns
   - CPU/GPU utilization
   - Storage requirements
   - Network dependencies
   - Latency characteristics

### Phase 2: Analyze New Skill/Technology

**Goal**: Understand what the new thing does and what it needs.

**Steps**:

1. **Core capabilities**
   - What problem does it solve?
   - What techniques does it use?
   - What assumptions does it make?

2. **Technical requirements**
   - Dependencies (Python packages, system libraries)
   - Hardware requirements (GPU, memory, storage)
   - Configuration needs
   - Training/inference requirements

3. **Operational characteristics**
   - Training time and frequency
   - Inference latency
   - Resource consumption patterns
   - Maintenance needs

### Phase 3: Conflict Matrix Analysis

**Goal**: Systematically compare existing vs new across multiple dimensions.

**Dimensions to analyze**:

| Dimension | Existing Skills | New Skill | Conflict Type | Impact |
|-----------|---------------|-----------|--------------|---------|
| **Working Layer** | Which layer does it operate at? | | |
| **Tech Stack** | What technologies does it use? | | |
| **Dependencies** | What packages/libraries does it need? | | |
| **Resource Usage** | CPU/GPU/Memory/Storage patterns | | |
| **Latency** | Real-time vs batch processing | | |
| **Maintenance** | Update frequency, bug fixes | | |
| **Scenarios** | What use cases does it serve? | | |

**Conflict Types**:
- ✅ **No Conflict**: Independent, can coexist
- ⚠️ **Potential Conflict**: May need adjustment or prioritization
- ❌ **Actual Conflict**: Direct conflict, must resolve before proceeding

**Impact Levels**:
- Low: Cosmetic or minor inconvenience
- Medium: Requires workflow changes or resource allocation
- High: Blocks deployment or requires major refactoring

### Phase 4: Compatibility Assessment

**Goal**: Determine if the new skill is worth the integration cost.

**Assessment Criteria**:

1. **Synergy Potential** (Positive Impact)
   - Does the new skill enhance existing capabilities?
   - Can it improve performance, accuracy, or efficiency?
   - Does it unlock new use cases?

2. **Risk Factors** (Negative Impact)
   - Training overhead and resource competition
   - Deployment complexity and maintenance burden
   - Compatibility unknowns and integration risks
   - Ecosystem maturity

3. **ROI Analysis**
   - Benefits: Quantify expected gains (if possible)
   - Costs: Development + maintenance + operational
   - Timeline: How long until benefits are realized?
   - Confidence: How certain are the estimates?

**Scoring Guide** (0-10 scale):

| Criterion | Score | Notes |
|-----------|-------|-------|
| Synergy Potential | 0-10 | Higher = better integration potential |
| Risk Factors | 0-10 | Higher = fewer/milder risks |
| ROI Certainty | 0-10 | Higher = more predictable outcomes |
| Total | 0-30 | 25+ = Proceed, 20-24 = Pilot, <20 = Defer |

### Phase 5: Recommendation

**Goal**: Provide clear, actionable guidance.

**Recommendation Framework**:

#### ✅ **Proceed** (Score 25+)
- Strong synergy, low risk, clear ROI
- Action: Implement with standard deployment process

#### ⚠️ **Pilot First** (Score 20-24)
- Moderate potential, some uncertainty
- Action:
  1. Define pilot scope and success criteria
  2. Isolate pilot environment from production
  3. Set clear timelines and rollback plans
  4. Document learnings

#### ❌ **Defer** (Score <20)
- Low synergy, high risk, uncertain ROI
- Action:
  1. Document rationale for deferral
  2. Monitor technology maturity
  3. Re-assess in 3-6 months
  4. Identify conditions that would change decision

#### 🔄 **Conditional Integration** (Special Case)
- Only viable with specific modifications or prerequisites
- Action: Define conditions and dependencies before proceeding

### Phase 6: Risk Mitigation (If Proceeding)

**Goal**: Minimize negative impacts.

**Mitigation Strategies**:

1. **Resource Isolation**
   - Separate training and inference environments
   - Use resource quotas or priorities
   - Implement graceful degradation

2. **Incremental Rollout**
   - Start with non-critical scenarios
   - Use A/B testing to validate benefits
   - Monitor key metrics (performance, cost, quality)

3. **Rollback Preparedness**
   - Document integration points
   - Maintain backward compatibility
   - Have clear rollback triggers and procedures

4. **Monitoring and Alerting**
   - Track resource consumption
   - Monitor latency and error rates
   - Alert on anomalies

## Output Format

Generate a comprehensive analysis report with these sections:

```markdown
# Compatibility Analysis: [New Skill] vs Existing Skills

## Executive Summary
- Overall recommendation: [Proceed/Pilot/Defer/Conditional]
- Key conflicts identified: [list]
- Total score: [X/30]

## Phase 1: Existing Skills Inventory
- Active skills: [list]
- Skill categories: [mapping]
- Resource baseline: [summary]

## Phase 2: New Skill Analysis
- Core capabilities: [description]
- Technical requirements: [list]
- Operational characteristics: [list]

## Phase 3: Conflict Matrix
[Conflict matrix table with all dimensions]

## Phase 4: Compatibility Assessment
- Synergy potential: [X/10] + rationale
- Risk factors: [X/10] + rationale
- ROI certainty: [X/10] + rationale
- **Total: [X/30]**

## Phase 5: Recommendation
- **Decision: [Proceed/Pilot/Defer/Conditional]**
- Rationale: [explanation]
- Next steps: [action items]

## Phase 6: Risk Mitigation (if applicable)
- Strategies: [list]
- Timeline: [plan]
- Success criteria: [metrics]
```

## Common Patterns

### Pattern 1: Data Layer vs Model Layer
- **Typical**: No conflict, can coexist
- **Example**: Token optimization (data) + KAN (model) ✅
- **Risk**: Minimal if properly isolated

### Pattern 2: Same Technology Stack
- **Typical**: Compatibility issues, version conflicts
- **Example**: Two skills using different PyTorch versions ❌
- **Risk**: High, needs careful dependency management

### Pattern 3: Resource Competition
- **Typical**: Need resource allocation or prioritization
- **Example**: Two GPU-intensive skills ⚠️
- **Risk**: Medium, can be mitigated with quotas

### Pattern 4: Workflow Disruption
- **Typical**: May need process changes
- **Example**: New skill changes existing execution flow ⚠️
- **Risk**: Medium, requires planning and testing

## Quick Reference

**Common Conflict Scenarios**:

| Scenario | Conflict Type | Recommendation |
|----------|--------------|----------------|
| New skill replaces existing one | Actual Conflict | Defer or plan migration |
| New skill complements existing | No Conflict | Proceed if ROI clear |
| Both need GPU | Potential Conflict | Pilot with resource quotas |
| Different Python versions | Actual Conflict | Resolve version conflict first |
| Unclear benefits | Potential Conflict | Defer until ROI proven |

## References

See `references/analysis-template.md` for a detailed analysis template with examples.
See `references/evaluation-criteria.md` for detailed evaluation criteria and rubrics.
