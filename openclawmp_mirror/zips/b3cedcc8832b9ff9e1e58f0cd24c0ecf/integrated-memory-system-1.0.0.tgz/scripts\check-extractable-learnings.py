#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
检查可提炼为技能的学习条目
符合以下条件之一即可提炼：
1. 重复出现 ≥3 次（See Also 链接≥2）
2. 高优先级 + resolved 状态
3. 用户明确要求"保存为技能"
"""

import os
import sys
import re
from pathlib import Path
from datetime import datetime

# 设置 UTF-8 编码（Windows 必需）
sys.stdout.reconfigure(encoding='utf-8')

def get_workspace_root():
    """获取工作区根目录"""
    return Path.home() / ".openclaw" / "workspace"

def parse_learning_entry(content, entry_start):
    """解析单个学习条目"""
    lines = content[entry_start:].split('\n')
    entry_lines = []
    next_entry_start = 0
    
    for i, line in enumerate(lines):
        if line.startswith('## [LRN-') and i > 0:
            next_entry_start = entry_start + i
            break
        entry_lines.append(line)
    
    entry_text = '\n'.join(entry_lines)
    
    # 提取关键信息
    id_match = re.search(r'\[LRN-(\d{8}-\d{3})\]\s*(\w+)?', entry_text)
    priority_match = re.search(r'\*\*Priority\*\*:\s*(\w+)', entry_text)
    status_match = re.search(r'\*\*Status\*\*:\s*(\w+)', entry_text)
    see_also_matches = re.findall(r'See Also:\s*([\w-]+)', entry_text)
    user_flag = '保存为技能' in entry_text or 'skill' in entry_text.lower()
    
    return {
        'id': id_match.group(1) if id_match else None,
        'category': id_match.group(2) if id_match else None,
        'priority': priority_match.group(1) if priority_match else 'medium',
        'status': status_match.group(1) if status_match else 'pending',
        'see_also_count': len(see_also_matches),
        'see_also_ids': see_also_matches,
        'user_flagged': user_flag,
        'content': entry_text,
        'start_pos': entry_start,
        'end_pos': next_entry_start if next_entry_start > 0 else len(content)
    }

def load_learnings():
    """加载 LEARNINGS.md 文件"""
    workspace = get_workspace_root()
    learnings_path = workspace / ".learnings" / "LEARNINGS.md"
    
    if not learnings_path.exists():
        print(f"❌ 未找到 LEARNINGS.md 文件：{learnings_path}")
        return None
    
    with open(learnings_path, 'r', encoding='utf-8') as f:
        return learnings_path.read_text(encoding='utf-8')

def extract_candidates(content):
    """提取可提炼的学习候选"""
    candidates = []
    
    # 分割条目
    entries = re.split(r'(?=^## \[LRN-)', content, flags=re.MULTILINE)
    
    for entry in entries:
        if not entry.strip():
            continue
        
        # 解析条目
        lines = entry.split('\n')
        entry_text = '\n'.join(lines)
        
        id_match = re.search(r'\[LRN-(\d{8}-\d{3})\]\s*(\w+)?', entry_text)
        priority_match = re.search(r'\*\*Priority\*\*:\s*(\w+)', entry_text)
        status_match = re.search(r'\*\*Status\*\*:\s*(\w+)', entry_text)
        see_also_matches = re.findall(r'See Also:\s*([\w-]+)', entry_text)
        user_flag = '保存为技能' in entry_text or 'skill' in entry_text.lower()
        
        if not id_match:
            continue
        
        candidate = {
            'id': id_match.group(1),
            'category': id_match.group(2) if id_match.group(2) else 'unknown',
            'priority': priority_match.group(1) if priority_match else 'medium',
            'status': status_match.group(1) if status_match else 'pending',
            'see_also_count': len(see_also_matches),
            'see_also_ids': see_also_matches,
            'user_flagged': user_flag,
            'content': entry_text,
            'summary': lines[2] if len(lines) > 2 else 'No summary'
        }
        
        # 判断是否符合提炼条件
        reasons = []
        
        if candidate['see_also_count'] >= 2:
            reasons.append(f"重复出现 ({candidate['see_also_count']} 次关联)")
        
        if candidate['priority'] in ['high', 'critical'] and candidate['status'] == 'resolved':
            reasons.append(f"高优先级已解决 ({candidate['priority']})")
        
        if candidate['user_flagged']:
            reasons.append("用户明确要求")
        
        if reasons:
            candidate['reasons'] = reasons
            candidates.append(candidate)
    
    return candidates

def print_candidates(candidates):
    """打印候选列表"""
    if not candidates:
        print("\n💡 暂无可提炼的学习条目")
        print("\n提示：")
        print("1. 在 LEARNINGS.md 中添加 See Also 链接关联相似条目")
        print("2. 将高优先级问题解决后标记为 resolved")
        print("3. 遇到想保存为技能的学习，添加'保存为技能'标注")
        return
    
    print(f"\n🎯 发现 {len(candidates)} 个可提炼的学习条目：\n")
    
    for i, candidate in enumerate(candidates, 1):
        print(f"{i}. [LRN-{candidate['id']}] {candidate['category']}")
        print(f"   📝 {candidate['summary']}")
        print(f"   ✅ 提炼理由：{', '.join(candidate['reasons'])}")
        if candidate['see_also_ids']:
            print(f"   🔗 关联条目：{', '.join(candidate['see_also_ids'])}")
        print()

def generate_extraction_report(candidates):
    """生成提炼报告"""
    workspace = get_workspace_root()
    report_path = workspace / "memory" / "notes" / "skill_extraction_candidates.md"
    
    report_path.parent.mkdir(parents=True, exist_ok=True)
    
    report = f"""# 技能提炼候选报告

**生成时间**: {datetime.now().strftime("%Y-%m-%d %H:%M")}  
**候选数量**: {len(candidates)}

---

## 候选列表

"""
    
    for i, candidate in enumerate(candidates, 1):
        report += f"""### {i}. [LRN-{candidate['id']}] {candidate['category']}

**摘要**: {candidate['summary']}  
**优先级**: {candidate['priority']}  
**状态**: {candidate['status']}  
**提炼理由**: {', '.join(candidate['reasons'])}  
**关联条目**: {', '.join(candidate['see_also_ids']) if candidate['see_also_ids'] else '无'}

**建议技能名称**: `{candidate['category']}-helper`  
**建议技能类型**: Skill / Experience

---

"""
    
    report += """## 下一步

1. 审查候选条目，确认是否值得提炼
2. 运行提取脚本：
   ```bash
   python scripts/extract-skill-from-learning.py LRN-YYYYMMDD-XXX
   ```
3. 完善生成的 SKILL.md
4. 打包发布到水产市场

---

*报告生成：集成记忆系统 v1.0*
"""
    
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"📄 详细报告已保存到：{report_path}")

def main():
    """主函数"""
    print("=" * 60)
    print("🔍 检查可提炼为技能的学习条目")
    print("=" * 60)
    
    # 加载学习记录
    content = load_learnings()
    if not content:
        return
    
    # 提取候选
    candidates = extract_candidates(content)
    
    # 打印结果
    print_candidates(candidates)
    
    # 生成报告
    if candidates:
        generate_extraction_report(candidates)
    
    print("\n" + "=" * 60)
    print("✅ 检查完成！")
    print("=" * 60)

if __name__ == "__main__":
    main()
