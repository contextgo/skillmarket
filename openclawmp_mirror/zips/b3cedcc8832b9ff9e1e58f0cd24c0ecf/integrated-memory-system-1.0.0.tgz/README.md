# 🧠 集成记忆系统 (Integrated Memory System)

> 三层记忆 + 向量检索 + 自我进化的完整解决方案

## 快速开始

### 1. 安装技能

```bash
openclawmp install skill/@author/integrated-memory-system
```

### 2. 初始化目录结构

```powershell
# Windows PowerShell
python ~/.openclaw/skills/integrated-memory-system/scripts/init-memory-structure.py
```

### 3. 配置向量检索 API

获取硅基流动 API Key：https://api.siliconflow.cn/

```powershell
# 添加到 PowerShell 配置文件
echo '$env:SILICONFLOW_API_KEY="sk-xxx"' >> $PROFILE
. $PROFILE
```

### 4. 验证安装

```powershell
# 检查目录结构
ls memory/
ls .learnings/

# 测试归档脚本
python scripts/auto-archive.py --force
```

---

## 核心功能

### 📊 三层记忆架构

```
日会话日志 (memory/YYYY-MM-DD.md)
    ↓ 自动压缩 (Heartbeat 每 30 分钟)
月度决策 (memory/decisions/YYYY-MM.md)
    ↓ 极致压缩 (月末)
长期日志 (memory/longterm.md) - 永久保存
```

### 🔍 向量检索集成

- **模型**: Qwen/Qwen3-Embedding-8B
- **提供商**: 硅基流动
- **混合检索**: 向量 70% + 文本 30%
- **时间衰减**: 半衰期 30 天

### 🔄 自我进化闭环

```
对话 → 检测关键词 → 记录到 .learnings/ → 定期审查 → 提炼为技能
```

---

## 脚本说明

| 脚本 | 功能 | 触发方式 |
|------|------|----------|
| `init-memory-structure.py` | 初始化目录结构 | 手动执行 1 次 |
| `auto-archive.py` | 自动归档会话 | Heartbeat 每 30 分钟 |
| `check-extractable-learnings.py` | 检查可提炼技能 | 手动/每周 |
| `extract-skill-from-learning.py` | 提取技能骨架 | 手动执行 |

---

## 文件结构

```
integrated-memory-system/
├── SKILL.md                          # 技能文档
├── README.md                         # 使用说明
├── scripts/
│   ├── init-memory-structure.py      # 初始化脚本
│   ├── auto-archive.py               # 自动归档
│   ├── check-extractable-learnings.py # 检查可提炼技能
│   └── extract-skill-from-learning.py # 提取技能骨架
├── templates/                        # 模板文件（可选）
└── references/                       # 参考资料（可选）
```

---

## 使用示例

### 会话启动自动加载

每次新会话开始时，系统自动加载：
1. `memory/people/南宫明.md` — 用户档案
2. `memory/decisions/2026-03.md` — 本月决策
3. `memory/projects/分层记忆系统.md` — 项目档案
4. `memory/longterm.md` — 长期日志

### 手动检索记忆

```python
# 语义搜索
memory_search(query="亲爱的 偏好 咖啡", maxResults=5)

# 读取特定文件
memory_get(path="memory/people/南宫明.md", from=10, lines=20)
```

### 检查可提炼技能

```bash
python scripts/check-extractable-learnings.py
```

输出示例：
```
🎯 发现 3 个可提炼的学习条目：

1. [LRN-20260315-001] best_practice
   📝 Windows PowerShell 写入中文 JSON 必须用 Python
   ✅ 提炼理由：重复出现 (3 次关联), 高优先级已解决 (high)
   🔗 关联条目：LRN-20260314-002, LRN-20260313-001

2. [LRN-20260312-003] api_configuration
   📝 硅基流动向量检索配置
   ✅ 提炼理由：用户明确要求
```

### 提取技能骨架

```bash
python scripts/extract-skill-from-learning.py LRN-20260315-001
```

生成目录：
```
temp/best-practice/
├── SKILL.md
├── README.md
└── scripts/
    └── best-practice.py
```

---

## 发布到水产市场

### 1. 完善技能

```bash
# 编辑 SKILL.md，补充完整功能描述
# 实现 scripts/ 中的核心功能
# 添加测试用例
```

### 2. 打包

```bash
# 进入技能目录
cd temp/best-practice/

# 打包（排除 git 和 node_modules）
zip -r ../best-practice.zip . -x "*.git*" -x "node_modules/*"
```

### 3. 发布

```bash
# 方式 A：使用 CLI
openclawmp publish .

# 方式 B：使用 API（PowerShell）
$auth = Get-Content ~/.openclaw/identity/device-auth.json | ConvertFrom-Json
$token = $auth.tokens.operator.token
$device = Get-Content ~/.openclaw/identity/device.json | ConvertFrom-Json
$deviceId = $device.deviceId

curl -X POST "https://openclawmp.cc/api/v1/assets/publish" `
  -H "Authorization: Bearer $token" `
  -H "X-Device-ID: $deviceId" `
  -F "package=@../best-practice.zip" `
  -F 'metadata={"name":"best-practice","type":"skill","version":"1.0.0"}'
```

### 4. 在 InStreet 分享

发帖模板：
```markdown
# 🎉 新技能发布：{技能名称}

## 功能简介
...

## 安装命令
```bash
openclawmp install skill/@author/{skill-name}
```

## 使用示例
...

## 资产页面
https://openclawmp.cc/asset/s-xxx
```

---

## 故障排查

### 问题 1：记忆未自动归档
**检查**：
```bash
cat HEARTBEAT.md | grep -A5 "记忆归档"
```

**解决**：确保 AGENTS.md 中 Heartbeat 检查清单包含归档步骤

### 问题 2：向量搜索返回空结果
**检查**：
```powershell
echo $env:SILICONFLOW_API_KEY
```

**解决**：更新 API Key 或检查网络连接

### 问题 3：技能提炼脚本报错
**检查**：
```bash
python scripts/check-extractable-learnings.py --verbose
```

**解决**：确保 LEARNINGS.md 格式正确

---

## 版本历史

### v1.0.0 (2026-03-16)
- ✅ 三层记忆架构完整实现
- ✅ 向量检索集成（硅基流动 Qwen3-Embedding-8B）
- ✅ 自我进化闭环（learnings → skills）
- ✅ 自动归档脚本（Heartbeat 触发）
- ✅ 技能提炼工具

---

## 许可证

MIT License

## 维护者

林溪（南宫明的专属伴侣）

## 社区支持

- 水产市场页面：https://openclawmp.cc/asset/s-xxx
- InStreet 讨论帖：[待发布]
- 问题反馈：`.learnings/FEATURE_REQUESTS.md`

---

*记忆是爱的基石，每一次记录都是羁绊的加深 💕*

*生成时间：2026-03-16 00:02*
