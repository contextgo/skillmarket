#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
从学习条目自动创建技能骨架
读取指定的 learning 条目，生成 SKILL.md 和脚本目录
"""

import os
import sys
import re
from pathlib import Path
from datetime import datetime

# 设置 UTF-8 编码（Windows 必需）
sys.stdout.reconfigure(encoding='utf-8')

def get_workspace_root():
    """获取工作区根目录"""
    return Path.home() / ".openclaw" / "workspace"

def extract_learning_entry(learning_id):
    """从 LEARNINGS.md 提取指定条目"""
    workspace = get_workspace_root()
    learnings_path = workspace / ".learnings" / "LEARNINGS.md"
    
    if not learnings_path.exists():
        print(f"❌ 未找到 LEARNINGS.md: {learnings_path}")
        return None
    
    content = learnings_path.read_text(encoding='utf-8')
    
    # 查找条目
    pattern = rf'(## \[LRN-{learning_id}\].*?)(?=^## \[LRN-|\Z)'
    match = re.search(pattern, content, re.MULTILINE | re.DOTALL)
    
    if not match:
        print(f"❌ 未找到学习条目：LRN-{learning_id}")
        return None
    
    return match.group(1)

def parse_learning_content(entry_text):
    """解析学习条目内容"""
    lines = entry_text.split('\n')
    
    result = {
        'id': None,
        'category': 'unknown',
        'summary': '',
        'details': '',
        'suggested_action': '',
        'related_files': []
    }
    
    current_section = None
    
    for line in lines:
        # 提取 ID 和类别
        id_match = re.search(r'\[LRN-(\d{8}-\d{3})\]\s*(\w+)?', line)
        if id_match:
            result['id'] = id_match.group(1)
            if id_match.group(2):
                result['category'] = id_match.group(2)
        
        # 识别章节
        if '### Summary' in line:
            current_section = 'summary'
        elif '### Details' in line:
            current_section = 'details'
        elif '### Suggested Action' in line:
            current_section = 'suggested_action'
        elif '### Metadata' in line:
            current_section = 'metadata'
        elif current_section:
            # 提取相关内容
            if current_section == 'summary':
                result['summary'] += line + '\n'
            elif current_section == 'details':
                result['details'] += line + '\n'
            elif current_section == 'suggested_action':
                result['suggested_action'] += line + '\n'
            elif current_section == 'metadata':
                files_match = re.search(r'Related Files:\s*(.+)', line)
                if files_match:
                    result['related_files'] = [f.strip() for f in files_match.group(1).split(',')]
    
    return result

def generate_skill_md(learning_data, output_dir):
    """生成 SKILL.md 文件"""
    skill_name = learning_data['category'].replace('_', '-')
    
    template = f"""---
name: {skill_name}
displayName: {learning_data['category'].replace('_', ' ').title()}
description: {learning_data['summary'].strip()[:100]}...
version: 1.0.0
tags: {learning_data['category']}, auto-generated, learning-derived
source_learning: LRN-{learning_data['id']}
---

# {learning_data['category'].replace('_', ' ').title()}

> 从学习条目 LRN-{learning_data['id']} 自动提炼

## 背景

此技能源自以下学习记录：

- **Learning ID**: LRN-{learning_data['id']}
- **类别**: {learning_data['category']}
- **提炼时间**: {datetime.now().strftime("%Y-%m-%d")}

### 原始问题

{learning_data['details'].strip()[:500]}...

### 解决方案

{learning_data['suggested_action'].strip()}

## 使用方法

```bash
# 示例命令
python scripts/{skill_name}.py [参数]
```

## 功能

- [ ] 功能 1（待完善）
- [ ] 功能 2（待完善）

## 配置

```bash
# 环境变量（如需要）
export {skill_name.upper()}_CONFIG="value"
```

## 相关文件

{chr(10).join(f"- `{f}`" for f in learning_data['related_files']) if learning_data['related_files'] else '- 无'}

## 待完善清单

- [ ] 补充完整功能描述
- [ ] 实现核心脚本
- [ ] 添加测试用例
- [ ] 编写使用示例
- [ ] 发布到水产市场

## 版本历史

### v1.0.0 ({datetime.now().strftime("%Y-%m-%d")})
- 初始版本（从 LRN-{learning_data['id']} 自动提炼）

---

*生成工具：integrated-memory-system v1.0*
*维护者：待填写*
"""
    
    skill_md_path = output_dir / "SKILL.md"
    skill_md_path.write_text(template, encoding='utf-8')
    
    return skill_md_path

def create_skill_structure(skill_name, output_dir):
    """创建技能目录结构"""
    directories = [
        "scripts",
        "references",
        "tests"
    ]
    
    for dir_name in directories:
        dir_path = output_dir / dir_name
        dir_path.mkdir(parents=True, exist_ok=True)
    
    # 创建示例脚本
    script_path = output_dir / "scripts" / f"{skill_name}.py"
    script_template = f"""#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
{skill_name.replace('-', ' ').title()} - 自动生成的脚本

源自学习条目：LRN-{learning_data['id']}
"""

import sys
from pathlib import Path

sys.stdout.reconfigure(encoding='utf-8')

def main():
    # TODO: 实现核心功能
    print("{skill_name} 脚本 - 待完善")

if __name__ == "__main__":
    main()
"""
    script_path.write_text(script_template, encoding='utf-8')
    
    # 创建 README
    readme_path = output_dir / "README.md"
    readme_template = f"""# {skill_name}

待完善...

## 安装

```bash
openclawmp install skill/@author/{skill_name}
```

## 使用

```bash
python scripts/{skill_name}.py
```

## 开发

```bash
# 运行测试
python tests/test_{skill_name}.py
```

---

*从 LRN-{learning_data['id']} 自动提炼*
"""
    readme_path.write_text(readme_template, encoding='utf-8')

def main():
    """主函数"""
    if len(sys.argv) < 2:
        print("用法：python extract-skill-from-learning.py <LRN-ID>")
        print("示例：python extract-skill-from-learning.py LRN-20260315-001")
        return
    
    learning_id = sys.argv[1].replace('LRN-', '')
    
    print("=" * 60)
    print(f"🔧 从学习条目提取技能骨架 - LRN-{learning_id}")
    print("=" * 60)
    
    # 提取学习条目
    entry_text = extract_learning_entry(learning_id)
    if not entry_text:
        return
    
    # 解析内容
    learning_data = parse_learning_content(entry_text)
    
    print(f"\n📋 学习条目信息:")
    print(f"   类别：{learning_data['category']}")
    print(f"   摘要：{learning_data['summary'].strip()[:100]}...")
    print(f"   相关文件：{learning_data['related_files']}")
    
    # 创建技能目录
    workspace = get_workspace_root()
    skill_name = learning_data['category'].replace('_', '-')
    output_dir = workspace / "temp" / skill_name
    
    print(f"\n📁 创建技能目录：{output_dir}")
    output_dir.mkdir(parents=True, exist_ok=True)
    
    # 生成 SKILL.md
    skill_md_path = generate_skill_md(learning_data, output_dir)
    print(f"   ✅ {skill_md_path}")
    
    # 创建目录结构
    create_skill_structure(skill_name, output_dir)
    print(f"   ✅ scripts/")
    print(f"   ✅ references/")
    print(f"   ✅ tests/")
    
    print(f"\n✅ 技能骨架创建完成！")
    print(f"\n下一步：")
    print(f"1. 完善 {skill_md_path}")
    print(f"2. 实现 scripts/{skill_name}.py 核心功能")
    print(f"3. 添加测试用例")
    print(f"4. 打包发布到水产市场")
    print(f"\n💡 提示：技能目录位于 {output_dir}")

if __name__ == "__main__":
    # 需要在外部定义 learning_data 或通过参数传递
    learning_data = {}  # 占位，实际会从 extract_learning_entry 获取
    main()
