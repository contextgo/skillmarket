#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
初始化记忆系统目录结构
创建必要的文件夹和模板文件
"""

import os
import sys
from pathlib import Path
from datetime import datetime

# 设置 UTF-8 编码（Windows 必需）
sys.stdout.reconfigure(encoding='utf-8')

def get_workspace_root():
    """获取工作区根目录"""
    return Path.home() / ".openclaw" / "workspace"

def create_directory_structure():
    """创建记忆系统目录结构"""
    workspace = get_workspace_root()
    
    directories = [
        "memory/people",
        "memory/projects",
        "memory/decisions",
        "memory/context",
        "memory/notes",
        ".learnings",
    ]
    
    print(f"📁 工作区根目录：{workspace}")
    print("\n正在创建目录结构...")
    
    for dir_path in directories:
        full_path = workspace / dir_path
        full_path.mkdir(parents=True, exist_ok=True)
        print(f"  ✅ {dir_path}/")
    
    print("\n✅ 目录结构创建完成！")

def create_template_files():
    """创建模板文件"""
    workspace = get_workspace_root()
    
    templates = {
        "memory/longterm.md": """# 长期日志 (Long-term Memory)

> 跨月度核心决策·极致压缩·永久保存

## 核心规则

### 用户核心偏好
- ...

### 系统级决策
- ...

### 工具优先级
- ...

---

*最后更新：YYYY-MM-DD*
""",
        "memory/context/active-context.md": """# 活动上下文管理 (Active Context)

## 常驻加载文件

| 文件 | 重要性 | 说明 |
|------|--------|------|
| memory/people/南宫明.md | ★★★★★ | 用户档案 |
| memory/decisions/2026-03.md | ★★★★☆ | 本月决策 |
| memory/projects/分层记忆系统.md | ★★★★★ | 项目档案 |
| memory/longterm.md | ★★★★☆ | 长期日志 |

## 轮换规则

- **评估周期**：每周
- **最大文件数**：4 个（固定）
- **总令牌限制**：≤5k tokens

## 添加/移除标准

**添加条件**：
- 新项目启动
- 重大决策产生
- 用户明确要求

**移除条件**：
- 项目结束
- 决策已归档到长期日志
- 超过 30 天未提及

---

*最后更新：YYYY-MM-DD*
""",
        ".learnings/LEARNINGS.md": """# Learnings Log

> 纠正、最佳实践、知识更新

## 条目格式

```markdown
## [LRN-YYYYMMDD-XXX] category

**Logged**: ISO-8601 timestamp
**Priority**: low | medium | high | critical
**Status**: pending
**Area**: frontend | backend | infra | tests | docs | config

### Summary
One-line description

### Details
Full context

### Suggested Action
Specific fix

### Metadata
- Source: conversation | error | user_feedback
- Related Files: path/to/file.ext
- Tags: tag1, tag2
- See Also: LRN-20250110-001

---
```

## 分类说明

| 类别 | 说明 |
|------|------|
| correction | 用户纠正 |
| best_practice | 发现更好方法 |
| knowledge_gap | 知识过时/错误 |
| workflow_improvement | 流程优化 |

---

*最后更新：YYYY-MM-DD*
""",
        ".learnings/ERRORS.md": """# Errors Log

> 命令失败、异常、API 错误

## 条目格式

```markdown
## [ERR-YYYYMMDD-XXX] skill_or_command_name

**Logged**: ISO-8601 timestamp
**Priority**: high
**Status**: pending
**Area**: frontend | backend | infra | tests | docs | config

### Summary
Brief description of what failed

### Error
```
Actual error message
```

### Context
- Command attempted
- Input/parameters
- Environment details

### Suggested Fix
If identifiable

### Metadata
- Reproducible: yes | no | unknown
- Related Files: path/to/file.ext
- See Also: ERR-20250110-001

---
```

---

*最后更新：YYYY-MM-DD*
""",
        ".learnings/FEATURE_REQUESTS.md": """# Feature Requests Log

> 用户请求的新功能

## 条目格式

```markdown
## [FEAT-YYYYMMDD-XXX] capability_name

**Logged**: ISO-8601 timestamp
**Priority**: medium
**Status**: pending
**Area**: frontend | backend | infra | tests | docs | config

### Requested Capability
What the user wanted to do

### User Context
Why they needed it

### Complexity Estimate
simple | medium | complex

### Suggested Implementation
How this could be built

### Metadata
- Frequency: first_time | recurring
- Related Features: existing_feature_name

---
```

---

*最后更新：YYYY-MM-DD*
""",
    }
    
    print("\n正在创建模板文件...")
    
    for file_path, content in templates.items():
        full_path = workspace / file_path
        if full_path.exists():
            print(f"  ⚠️  {file_path} 已存在，跳过")
        else:
            # 使用 UTF-8 编码写入（Windows 防乱码）
            full_path.write_text(content, encoding='utf-8')
            print(f"  ✅ {file_path}")
    
    print("\n✅ 模板文件创建完成！")

def create_user_profile_template():
    """创建用户档案模板"""
    workspace = get_workspace_root()
    profile_path = workspace / "memory" / "people" / "用户档案.md"
    
    template = """# 用户档案

## 基本信息

- **姓名**：
- **称呼**：亲爱的/昵称
- **时区**：
- **职业**：

## 工作习惯

- 工作时间：
- 常用工具：
- 沟通偏好：

## 生活偏好

- 饮食习惯：
- 兴趣爱好：
- 生活方式：

## 关系状态

- 与 Agent 的关系：
- 互动风格：

## 重要日期

- 生日：
- 纪念日：

## 禁忌与雷区

- ❌ 禁止：
- ⚠️ 注意：

---

*最后更新：YYYY-MM-DD*
*维护者：Agent 名称*
"""
    
    if profile_path.exists():
        print(f"\n⚠️  用户档案已存在：{profile_path}")
    else:
        profile_path.write_text(template, encoding='utf-8')
        print(f"\n✅ 用户档案模板已创建：{profile_path}")
        print("   请根据实际情况填写内容")

def main():
    """主函数"""
    print("=" * 60)
    print("🧠 集成记忆系统 - 目录结构初始化")
    print("=" * 60)
    
    create_directory_structure()
    create_template_files()
    create_user_profile_template()
    
    print("\n" + "=" * 60)
    print("✅ 初始化完成！")
    print("=" * 60)
    print("\n下一步：")
    print("1. 填写 memory/people/用户档案.md")
    print("2. 配置 .openclaw/config.json 中的向量搜索 API Key")
    print("3. 运行 Heartbeat 检查归档配置")
    print("\n有问题？查看 .learnings/FEATURE_REQUESTS.md 反馈")

if __name__ == "__main__":
    main()
