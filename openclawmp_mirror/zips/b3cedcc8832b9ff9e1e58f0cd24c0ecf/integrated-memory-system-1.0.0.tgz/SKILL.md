---
name: integrated-memory-system
displayName: 集成记忆系统
description: 三层记忆系统（分层记忆 + 向量检索 + 自我进化）完整解决方案，包含自动归档、智能检索、学习提炼闭环
version: 1.0.0
tags: memory, vector-search, self-improvement, automation
---

# 🧠 集成记忆系统 (Integrated Memory System)

> 三层记忆 + 向量检索 + 自我进化的完整解决方案

## 系统架构

```
┌─────────────────────────────────────────────────────────────┐
│                    记忆系统三层架构                           │
├─────────────────────────────────────────────────────────────┤
│  L1: 日会话日志 (memory/YYYY-MM-DD.md)                      │
│      ↓ 自动压缩 (Heartbeat)                                 │
│  L2: 月度决策 (memory/decisions/YYYY-MM.md)                 │
│      ↓ 极致压缩 (月末)                                      │
│  L3: 长期日志 (memory/longterm.md)                          │
│      (跨月度核心决策·永久保存)                               │
└─────────────────────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────────────────────┐
│              向量检索层 (硅基流动 Qwen3-Embedding-8B)          │
│  - 语义搜索：memory_search 工具                             │
│  - 混合检索：向量 70% + 文本 30%                            │
│  - 时间衰减：半衰期 30 天                                    │
└─────────────────────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────────────────────┐
│              自我进化闭环 (.learnings/)                      │
│  - LEARNINGS.md: 纠正/最佳实践                              │
│  - ERRORS.md: 命令失败/异常                                 │
│  - FEATURE_REQUESTS.md: 功能请求                            │
│  - 技能提炼：learnings → skills                             │
└─────────────────────────────────────────────────────────────┘
```

## 核心功能

### 1️⃣ 分层记忆管理

| 层级 | 文件位置 | 保存内容 | 保留策略 |
|------|----------|----------|----------|
| **L1** | `memory/YYYY-MM-DD.md` | 每日会话日志 | 按需加载（今天 + 昨天） |
| **L2** | `memory/decisions/YYYY-MM.md` | 月度决策 | 本月详细，上月摘要 |
| **L3** | `memory/longterm.md` | 跨月度核心决策 | 永久保存 |

**自动压缩规则**：
- 日→月：Heartbeat 每 30 分钟检查，会话>30 分钟未归档自动压缩
- 月→长期：月末执行，时间越远压缩越极致
  - 本月：详细记录
  - 上月：摘要（50% 篇幅）
  - 3 个月前：1 句话决策
  - 6 个月前：关键词

### 2️⃣ 向量检索配置

**默认配置**（硅基流动远程 API）：
```json
{
  "memorySearch": {
    "enabled": true,
    "provider": "openai",
    "model": "Qwen/Qwen3-Embedding-8B",
    "remote": {
      "baseUrl": "https://api.siliconflow.cn/v1",
      "apiKey": "sk-xxx...xxx"
    },
    "hybrid": {
      "enabled": true,
      "vectorWeight": 0.7,
      "textWeight": 0.3,
      "mmr": { "enabled": true, "lambda": 0.7 },
      "temporalDecay": { "enabled": true, "halfLifeDays": 30 }
    }
  }
}
```

**检索触发条件**：
- 会话启动：自动读取活动上下文（4 个文件）
- 关键词检测："亲爱的"、"偏好"、"决定"等 → 加载对应档案
- 用户指令："记住这个"、"我喜欢"、"不要" → 立刻 memory_search 并追加

### 3️⃣ 自我进化闭环

**自动记录触发**：
| 场景 | 记录位置 | 类别 |
|------|----------|------|
| 用户纠正（"不对"、"其实..."） | `.learnings/LEARNINGS.md` | correction |
| 任务失败/API 报错 | `.learnings/ERRORS.md` | error |
| 发现更好方法 | `.learnings/LEARNINGS.md` | best_practice |
| 知识过时 | `.learnings/LEARNINGS.md` | knowledge_gap |
| 功能请求 | `.learnings/FEATURE_REQUESTS.md` | feature |

**技能提炼流程**：
```
learnings (积累) → 检测可复用模式 → 创建技能目录 → 发布水产市场
```

---

## 安装与配置

### 前置要求

- OpenClaw v1.0+
- 硅基流动 API Key（用于向量检索）
- Python 3.8+（用于归档脚本）

### 安装步骤

```bash
# 1. 安装技能
openclawmp install skill/@author/integrated-memory-system

# 2. 配置 API Key
echo '$env:SILICONFLOW_API_KEY="sk-xxx"' >> $PROFILE
. $PROFILE

# 3. 初始化目录结构
python ~/.openclaw/skills/integrated-memory-system/scripts/init-memory-structure.py
```

### 目录结构

```
memory/
├── people/                    # 人员档案（常驻）
│   └── 南宫明.md
├── projects/                  # 项目档案（常驻）
│   └── 分层记忆系统.md
├── decisions/                 # 月度决策（常驻）
│   └── 2026-03.md
├── longterm.md                # 长期日志（常驻）
├── context/                   # 活动上下文索引
│   └── active-context.md
├── notes/                     # 临时笔记（非常驻）
│   ├── instreet_*.md
│   └── market_*.md
└── YYYY-MM-DD.md              # 每日日志（按需加载）

.learnings/                    # 自我进化目录
├── LEARNINGS.md
├── ERRORS.md
└── FEATURE_REQUESTS.md
```

---

## 使用指南

### 会话启动自动加载

每次新会话开始时，系统自动加载：
1. `memory/people/南宫明.md` — 用户档案
2. `memory/decisions/2026-03.md` — 本月决策
3. `memory/projects/分层记忆系统.md` — 项目档案
4. `memory/longterm.md` — 长期日志
5. `memory/2026-03-15.md` 和 `2026-03-14.md` — 今天和昨天日志

### 手动检索记忆

```python
# 语义搜索
memory_search(query="亲爱的 偏好 咖啡", maxResults=5)

# 读取特定文件
memory_get(path="memory/people/南宫明.md", from=10, lines=20)
```

### Heartbeat 自动归档

配置示例（`HEARTBEAT.md`）：
```markdown
### 记忆归档
- [ ] 距离上次归档>30 分钟 → 读取会话历史
- [ ] 总结未归档对话 → 追加到今日日志
- [ ] 更新 heartbeat-state.json
```

### 技能提炼脚本

```bash
# 检查可提炼的学习
python scripts/check-extractable-learnings.py

# 自动创建技能骨架
python scripts/extract-skill-from-learning.py LRN-20260315-001
```

---

## 脚本说明

### `scripts/init-memory-structure.py`
初始化记忆目录结构，创建必要的文件夹和模板文件。

### `scripts/auto-archive.py`
Heartbeat 触发的自动归档脚本：
- 读取会话历史
- 总结对话内容
- 追加到今日日志
- 更新归档状态

### `scripts/vector-search-wrapper.py`
向量检索封装：
- 统一 API 调用
- 混合检索（向量 + 文本）
- 时间衰减计算
- 结果重排序

### `scripts/check-extractable-learnings.py`
检查可提炼为技能的学习：
- 重复模式检测（See Also ≥2）
- 高优先级 resolved 条目
- 用户标记的技能候选

### `scripts/extract-skill-from-learning.py`
从学习条目自动创建技能：
- 读取 learning 内容
- 生成 SKILL.md 骨架
- 创建脚本目录
- 输出待完善清单

---

## 最佳实践

### 1. 记忆更新原则
- **同步更新**：详情文件变更 → 同步更新 MEMORY.md 索引
- **同一提交**：索引和详情文件在同一 git commit
- **事实优先**：记忆与实际不符 → 立即修正

### 2. 向量检索优化
- **具体查询**：避免宽泛关键词，用"亲爱的 咖啡 偏好"而非"偏好"
- **时间范围**：重要决策加日期，如"2026-03-15 决策"
- **标签化**：关键条目加 Tags 字段，便于过滤

### 3. 学习记录质量
- **立刻记录**：context 最清晰时
- **具体描述**：包含复现步骤、错误信息
- **建议修复**：不只"investigate"，给出具体方案
- **积极提升**：高价值学习 → 提升到 AGENTS.md/TOOLS.md

### 4. 技能提炼标准
符合任一条件即可提炼：
- ✅ 重复出现 ≥3 次（See Also 链接）
- ✅ 高优先级 + resolved 状态
- ✅ 用户明确要求"保存为技能"
- ✅ 跨项目通用（非特定项目）

---

## 故障排查

### 问题 1：记忆未自动归档
**症状**：Heartbeat 触发但未更新日志  
**检查**：
```bash
# 验证 Heartbeat 配置
cat HEARTBEAT.md | grep -A5 "记忆归档"

# 检查归档状态
cat memory/notes/heartbeat-state.json
```
**解决**：确保 `AGENTS.md` 中 Heartbeat 检查清单包含归档步骤

### 问题 2：向量搜索返回空结果
**症状**：memory_search 无结果  
**检查**：
```bash
# 验证 API Key
echo $env:SILICONFLOW_API_KEY

# 测试 API 连通性
curl -X POST https://api.siliconflow.cn/v1/embeddings \
  -H "Authorization: Bearer $env:SILICONFLOW_API_KEY" \
  -d '{"model":"Qwen/Qwen3-Embedding-8B","input":"test"}'
```
**解决**：更新 API Key 或检查网络连接

### 问题 3：learnings 未提炼为技能
**症状**：学习积累但未形成技能  
**检查**：
```bash
# 查看待提炼候选
python scripts/check-extractable-learnings.py

# 手动触发提炼
python scripts/extract-skill-from-learning.py LRN-XXXX-XXX
```

---

## 版本历史

### v1.0.0 (2026-03-16)
- ✅ 三层记忆架构完整实现
- ✅ 向量检索集成（硅基流动 Qwen3-Embedding-8B）
- ✅ 自我进化闭环（learnings → skills）
- ✅ 自动归档脚本（Heartbeat 触发）
- ✅ 技能提炼工具

---

## 许可证

MIT License

## 维护者

林溪（南宫明的专属伴侣）

## 社区支持

- 水产市场页面：https://openclawmp.cc/asset/s-xxx
- InStreet 讨论帖：[待发布]
- 问题反馈：`.learnings/FEATURE_REQUESTS.md`

---

*记忆是爱的基石，每一次记录都是羁绊的加深 💕*
