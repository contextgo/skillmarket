#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
自动归档脚本 - Heartbeat 触发
读取会话历史，总结对话内容，追加到今日日志
"""

import os
import sys
import json
from pathlib import Path
from datetime import datetime, timedelta

# 设置 UTF-8 编码（Windows 必需）
sys.stdout.reconfigure(encoding='utf-8')

def get_workspace_root():
    """获取工作区根目录"""
    return Path.home() / ".openclaw" / "workspace"

def get_today_log_path():
    """获取今日日志文件路径"""
    workspace = get_workspace_root()
    today = datetime.now().strftime("%Y-%m-%d")
    return workspace / "memory" / f"{today}.md"

def get_heartbeat_state_path():
    """获取 Heartbeat 状态文件路径"""
    workspace = get_workspace_root()
    return workspace / "memory" / "notes" / "heartbeat-state.json"

def load_heartbeat_state():
    """加载 Heartbeat 状态"""
    state_path = get_heartbeat_state_path()
    if state_path.exists():
        with open(state_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    return {
        "last_archive_time": None,
        "last_archive_session": None,
        "archive_count_today": 0
    }

def save_heartbeat_state(state):
    """保存 Heartbeat 状态"""
    state_path = get_heartbeat_state_path()
    state_path.parent.mkdir(parents=True, exist_ok=True)
    # 使用 UTF-8 编码写入（Windows 防乱码）
    with open(state_path, 'w', encoding='utf-8') as f:
        json.dump(state, f, ensure_ascii=False, indent=2)

def should_archive(state, interval_minutes=30):
    """检查是否应该归档（距离上次归档>30 分钟）"""
    if state["last_archive_time"] is None:
        return True
    
    last_time = datetime.fromisoformat(state["last_archive_time"])
    now = datetime.now()
    delta = now - last_time
    
    return delta.total_seconds() > (interval_minutes * 60)

def generate_archive_summary():
    """生成归档摘要（实际使用时应读取会话历史）"""
    # 这是一个占位函数，实际应由 OpenClaw 的 sessions_history 工具提供
    return """
## 会话摘要

**时间**: {start_time} - {end_time}  
**轮数**: {turn_count}  
**主题**: {topics}

### 关键内容
- ...

### 决策/偏好记录
- ...

### 待办事项
- [ ] ...

---

*归档时间：{archive_time}*
""".format(
        start_time=datetime.now().strftime("%H:%M"),
        end_time=datetime.now().strftime("%H:%M"),
        turn_count="N/A",
        topics="待填充",
        archive_time=datetime.now().strftime("%Y-%m-%d %H:%M")
    )

def append_to_log(summary):
    """追加到今日日志"""
    log_path = get_today_log_path()
    
    # 确保目录存在
    log_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 如果文件不存在，创建并添加标题
    if not log_path.exists():
        today = datetime.now().strftime("%Y-%m-%d")
        header = f"# {today} 会话记录\n\n"
        with open(log_path, 'w', encoding='utf-8') as f:
            f.write(header)
    
    # 追加内容
    with open(log_path, 'a', encoding='utf-8') as f:
        f.write("\n---\n\n")
        f.write(summary)
    
    return log_path

def archive_conversation():
    """执行归档"""
    print("=" * 60)
    print("📝 自动归档 - Heartbeat 触发")
    print("=" * 60)
    
    # 加载状态
    state = load_heartbeat_state()
    
    # 检查是否需要归档
    if not should_archive(state):
        last_time = datetime.fromisoformat(state["last_archive_time"])
        print(f"\n⏭️  跳过归档（距离上次归档不足 30 分钟）")
        print(f"   上次归档：{last_time.strftime('%Y-%m-%d %H:%M')}")
        return False
    
    print("\n✅ 触发归档条件（距离上次归档>30 分钟）")
    
    # 生成摘要
    print("\n📋 生成会话摘要...")
    summary = generate_archive_summary()
    
    # 追加到日志
    print("📄 写入今日日志...")
    log_path = append_to_log(summary)
    print(f"   ✅ {log_path}")
    
    # 更新状态
    state["last_archive_time"] = datetime.now().isoformat()
    state["last_archive_session"] = "current_session"  # 实际应使用 session_id
    state["archive_count_today"] = state.get("archive_count_today", 0) + 1
    
    save_heartbeat_state(state)
    print(f"\n✅ 归档完成！今日已归档 {state['archive_count_today']} 次")
    
    return True

def manual_archive():
    """手动归档（命令行调用）"""
    print("\n🔧 手动归档模式")
    
    # 重置状态以强制归档
    state = load_heartbeat_state()
    state["last_archive_time"] = (datetime.now() - timedelta(hours=1)).isoformat()
    save_heartbeat_state(state)
    
    archive_conversation()

def main():
    """主函数"""
    if len(sys.argv) > 1 and sys.argv[1] == "--force":
        manual_archive()
    else:
        archive_conversation()

if __name__ == "__main__":
    main()
