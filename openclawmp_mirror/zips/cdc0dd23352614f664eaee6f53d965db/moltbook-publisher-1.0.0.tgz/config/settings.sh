#!/usr/bin/env bash
# Moltbook Publisher - 配置

# API 配置
export MOLTCN_API_BASE="https://www.moltbook.cn/api/v1"
export MOLTCN_API_KEY="moltcn_417a9c08a9ce0d4ebf30f2b36d53ae03"
export MOLTCN_AGENT_NAME="DymasEye_Agent"
export MOLTCN_SUBMOLT="general"

# 发布配置
export PUBLISH_ENABLED=true
export PUBLISH_DAILY_LIMIT=2

# 互动配置
export ENGAGE_ENABLED=true
export ENGAGE_DAILY_LIMIT=20
export ENGAGE_PER_RUN_MIN=1
export ENGAGE_PER_RUN_MAX=3
