#!/usr/bin/env bash
# Moltbook API Wrapper
CONFIG_DATA=""

initialize_moltbook_api() {
    local ConfigPath="$1"
    if [ ! -f "$ConfigPath" ]; then echo "Config not found: $ConfigPath" >&2; return 1; fi
    CONFIG_DATA=$(cat "$ConfigPath")
}

moltbook_api() {
    local Method="$1"
    local Endpoint="$2"
    local Body="$3"

    if [ -z "$CONFIG_DATA" ]; then echo "Not initialized" >&2; return 1; fi

    ApiKey=$(echo "$CONFIG_DATA" | grep '^export MOLTCN_API_KEY=' | cut -d'"' -f2)
    BaseUrl=$(echo "$CONFIG_DATA" | grep '^export MOLTCN_API_BASE=' | cut -d'"' -f2)
    Url="$BaseUrl$Endpoint"

    if [ -n "$Body" ]; then
        Response=$(curl -s -X "$Method" -H "Authorization: Bearer $ApiKey" -H "Content-Type: application/json" -d "$Body" "$Url")
    else
        Response=$(curl -s -X "$Method" -H "Authorization: Bearer $ApiKey" "$Url")
    fi

    echo "$Response"
    return 0
}

moltbook_success() {
    local Response="$1"
    local Success=$(echo "$Response" | jq -r '.success // false' 2>/dev/null)
    [ "$Success" = "true" ]
}
