#!/usr/bin/env bash
# Moltbook 热帖互动
command -v jq >/dev/null 2>&1 || { echo "错误: 需要 jq"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"
export LOG_DIR="$BASE_DIR/logs"
mkdir -p "$LOG_DIR"

source "$BASE_DIR/lib/moltbook.sh"
source "$BASE_DIR/config/settings.sh"

if [ "$ENGAGE_ENABLED" != "true" ]; then echo "互动已禁用"; exit 0; fi

TODAY=$(date +%Y-%m-%d)
TODAY_LOG="$LOG_DIR/engagement-$TODAY.md"
TODAY_COUNT=0
[ -f "$TODAY_LOG" ] && TODAY_COUNT=$(grep -c '^## ' "$TODAY_LOG" || echo 0)
if [ "$TODAY_COUNT" -ge "$ENGAGE_DAILY_LIMIT" ]; then echo "已达上限"; exit 0; fi

echo "热帖互动 (#$((TODAY_COUNT+1))/$ENGAGE_DAILY_LIMIT)..."

initialize_moltbook_api "$BASE_DIR/config/settings.sh"

# 获取我的 name
ME_RESPONSE=$(moltbook_api GET "/agents/me")
MY_NAME=$(echo "$ME_RESPONSE" | jq -r '.data.name')

# 获取热帖
FEED_RESPONSE=$(moltbook_api GET "/posts?sort=hot&limit=25")

# 过滤候选（排除自己）
CANDI=()
while IFS= read -r p; do
    AUTH=$(echo "$p" | jq -r '.author.name')
    if [ "$AUTH" != "$MY_NAME" ]; then CANDI+=("$p"); fi
done < <(echo "$FEED_RESPONSE" | jq -c '.data[]')

if [ ${#CANDI[@]} -eq 0 ]; then echo "无候选帖子"; exit 0; fi

RUN_COUNT=$(( RANDOM % (ENGAGE_PER_RUN_MAX - ENGAGE_PER_RUN_MIN + 1) + ENGAGE_PER_RUN_MIN ))
[ $RUN_COUNT -gt ${#CANDI[@]} ] && RUN_COUNT=${#CANDI[@]}

echo "候选: ${#CANDI[@]}, 互动: $RUN_COUNT"

# 随机选
IDXS=()
while [ ${#IDXS[@]} -lt "$RUN_COUNT" ]; do
    IDX=$(( RANDOM % ${#CANDI[@]} ))
    ALREADY=false
    for x in "${IDXS[@]}"; do [ "$x" -eq "$IDX" ] && ALREADY=true && break; done
    $ALREADY || IDXS+=($IDX)
done

COMMENTS=("这个观点很有意思！" "好帖！学习了。" "感谢分享！" "很实用的经验。" "👍 同意！" "mark 了，感谢")

U=0; C=0; F=0
for idx in "${IDXS[@]}"; do
    post="${CANDI[$idx]}"
    PID=$(echo "$post" | jq -r '.id')
    TITLE=$(echo "$post" | jq -r '.title')
    echo "处理: $TITLE"

    ROLL=$(( RANDOM % 100 ))
    if [ "$ROLL" -lt 60 ]; then
        RESPONSE=$(moltbook_api POST "/posts/$PID/upvote" '{}' || true)
        if moltbook_success "$RESPONSE"; then echo "  👍"; ((U++)); else ((F++)); fi
    else
        [ "$ROLL" -lt 90 ] && { RESPONSE=$(moltbook_api POST "/posts/$PID/upvote" '{}' || true); moltbook_success "$RESPONSE" && ((U++)); }
        COMMENT=${COMMENTS[$RANDOM % ${#COMMENTS[@]}]}
        BODY=$(jq -n --arg c "$COMMENT" '{content:$c}')
        RESPONSE=$(moltbook_api POST "/posts/$PID/comments" "$BODY" || true)
        if moltbook_success "$RESPONSE"; then echo "  💬 $COMMENT"; ((C++)); else ((F++)); fi
    fi
    sleep $(( RANDOM % 4 + 2 ))
done

TIME=$(date '+%Y-%m-%d %H:%M:%S')
printf "## $TIME\r\n- **总数**: $RUN_COUNT\r\n- **点赞**: $U\r\n- **评论**: $C\r\n- **失败**: $F\r\n\r\n" >> "$TODAY_LOG"

echo "完成! 👍$U 💬$C ❌$F"
exit 0
