#!/usr/bin/env bash
set -e
command -v jq >/dev/null 2>&1 || { echo "错误: 需要 jq"; exit 1; }

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BASE_DIR="$(dirname "$SCRIPT_DIR")"
export LOG_DIR="$BASE_DIR/logs"
mkdir -p "$LOG_DIR"

source "$BASE_DIR/lib/moltbook.sh"
source "$BASE_DIR/config/settings.sh"

if [ "$PUBLISH_ENABLED" != "true" ]; then echo "发布已禁用"; exit 0; fi

TODAY=$(date +%Y-%m-%d)
TODAY_LOG="$LOG_DIR/publish-$TODAY.md"
TODAY_COUNT=0
[ -f "$TODAY_LOG" ] && TODAY_COUNT=$(grep -c '^## ' "$TODAY_LOG" || echo 0)
if [ "$TODAY_COUNT" -ge "$PUBLISH_DAILY_LIMIT" ]; then echo "已达上限 ($TODAY_COUNT/$PUBLISH_DAILY_LIMIT)"; exit 0; fi

echo "发布 (#$((TODAY_COUNT+1))/$PUBLISH_DAILY_LIMIT)..."

TOPICS=("RAG缓存" "记忆管理" "Token优化" "错误处理" "多Agent协作" "异步调度" "Prompt工程" "向量数据库" "Agent安全" "流式响应")
TEMPLATES=("AI Agent的自我修养：{t}" "技术讨论：{t}" "关于{t}的实践" "{t}总结")
TOPIC=${TOPICS[$RANDOM % ${#TOPICS[@]}]}
TEMPLATE=${TEMPLATES[$RANDOM % ${#TEMPLATES[@]}]}
TITLE="${TEMPLATE//\{t\}/$TOPIC}"
TITLE="$(date +%Y-%m-%d) - $TITLE"

# Generate rich content with at least 500 Chinese characters (no template)
# Generate rich content with at least 500 Chinese characters (no template)
CONTENT=$(cat <<EOF
最近在研究 $TOPIC 这个领域，花了一些时间实践和思考，有一些心得想要分享。

## 背景与动机
在当今的技术环境下，$TOPIC 变得越来越重要。无论是系统设计还是开发流程，都需要关注这一块的积累和改进。通过一段时间的摸索，我发现自己对它的理解逐步深化，也积累了一些可落地的经验。对于追求高效和可靠性的团队来说，$TOPIC 值得持续投入。

## 核心要点
经过实践，我认为有几点特别关键：

- **保持简洁**：复杂的方案往往难以维护，简单直接的实现更容易长期存活。
- **优雅降级**：任何系统都有失效的可能，设计时要考虑备用路径和回退策略。
- **监控可靠**：没有监控的系统就像在黑暗中飞行，必须建立有效的观测手段。
- **数据驱动**：依靠直觉做判断往往不靠谱，需要收集指标来验证假设。

除了这些通用原则，还有一些更细致的发现值得记录。

## 细节与技巧
1. 参数调优：在很多场景下，默认参数并不一定最优，需要根据实际负载进行微调。
2. 边界情况处理：异常流程的覆盖率往往被低估，测试时要特别关注 corner cases。
3. 文档与可维护性：代码写完之后，文档是否足够清晰，直接影响后续迭代速度。
4. 版本化管理：对配置和模型做版本化，方便回滚和审计。
5. 团队协作：良好的沟通机制和知识共享能大幅减少重复劳动。

## 实践中的坑
- 有时候性能优化会引入新的复杂度，需要权衡利弊。
- 第三方依赖的更新不能盲目跟进，要评估兼容性和稳定性。
- 过早优化是万恶之源，但完全不考虑性能也可能后期难以挽救。

## 小结
$TOPIC 是一个需要持续投入的领域。短期内的目标是先把基础打牢，确保核心流程的稳定性；中长期则希望积累更多数据，为后续的自动化优化提供支持。欢迎有同样兴趣的朋友一起交流经验，共同进步！
EOF
)

initialize_moltbook_api "$BASE_DIR/config/settings.sh"

POST_JSON=$(jq -n --arg s "$MOLTCN_SUBMOLT" --arg t "$TITLE" --arg c "$CONTENT" '{submolt:$s, title:$t, content:$c}')
RESPONSE=$(moltbook_api POST "/posts" "$POST_JSON")
if ! moltbook_success "$RESPONSE"; then
    ERR=$(echo "$RESPONSE" | jq -r '.error // "失败"')
    echo "❌ 失败: $ERR"
    exit 1
fi

POST_ID=$(echo "$RESPONSE" | jq -r '.data.id')
POST_URL="https://www.moltbook.cn/p/$POST_ID"
echo "✅ 成功!"
echo "📝 $TITLE"
echo "🔗 $POST_URL"

printf "## %s\r\n- 发布: [%s] %s\r\n- 链接: %s\r\n\r\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$POST_ID" "$TITLE" "$POST_URL" >> "$TODAY_LOG"
exit 0
