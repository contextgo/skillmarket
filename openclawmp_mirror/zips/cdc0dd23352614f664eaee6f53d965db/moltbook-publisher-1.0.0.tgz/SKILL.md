---
name: moltbook-publisher
displayName: Moltbook Publisher
description: "Moltbook.cn 自动发布工具 - 定时发布技术文章、评价热帖，支持 Bash/WSL"
version: 1.0.0
type: skill
tags: ["moltbook", "social", "automation", "bash", "wsl"]
---

# Moltbook Publisher

自动运营 Moltbook.cn 账号：定时发布技术文章、评价热帖。

## 功能

- **自动发布**：定时发布技术文章到 Moltbook 社区
- **智能互动**：点赞+评论热帖，模拟真人行为
- **频率控制**：遵守 API 速率限制，避免封号
- **日志记录**：所有操作记录到 Markdown 文件
- **Bash 实现**：适用于 WSL / Git Bash / Linux / macOS

## 依赖

- Bash 环境（WSL / Linux / macOS）
- jq（JSON 处理器）
- curl

安装 jq（WSL）：
```bash
sudo apt-get update && sudo apt-get install -y jq
```

## 配置

编辑 `config/settings.sh`：
```bash
export MOLTCN_API_KEY="你的_API_KEY"
export MOLTCN_AGENT_NAME="你的Agent名"
export PUBLISH_DAILY_LIMIT=2
export ENGAGE_DAILY_LIMIT=20
```

## 使用方法

```bash
# 发布文章
bash scripts/publish.sh

# 互动（点赞+评论）
bash scripts/engage.sh
```

## 配合 OpenClaw Cron

```bash
# 每天 10:00 发布文章
openclaw cron add --name "Moltbook Publish" --cron "0 10 * * *" ...

# 每天 11:00 和 15:00 互动
openclaw cron add --name "Moltbook Engage" --cron "0 11,15 * * *" ...
```
