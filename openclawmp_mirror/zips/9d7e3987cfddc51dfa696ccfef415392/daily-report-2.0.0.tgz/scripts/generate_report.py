#!/usr/bin/env python3
"""
日报生成脚本 v2.0
数据来源：Outlook 日历 + Microsoft To Do（通过 api-gateway）
"""

import json
import os
import sys
import subprocess
from datetime import datetime, timedelta

# 配置
REPORTS_DIR = os.path.expanduser("~/productivity/reports")
CHART_DIR = os.path.expanduser("~/productivity/reports/charts")
ENV_FILE = os.path.expanduser("~/.openclaw/.env")


def get_env_vars():
    """Load environment variables from .env file"""
    env_vars = {}
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE) as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith('#') and '=' in line:
                    key, val = line.split('=', 1)
                    env_vars[key.strip()] = val.strip().strip('"').strip("'")
    return env_vars


def get_api_key():
    """Get MATON_API_KEY from env"""
    key = os.environ.get('MATON_API_KEY')
    if not key:
        env = get_env_vars()
        key = env.get('MATON_API_KEY')
    if not key:
        print("[ERROR] MATON_API_KEY not found", file=sys.stderr)
    return key


def get_outlook_events(api_key, date_str):
    """获取 Outlook 日历日程"""
    try:
        start = f"{date_str}T00:00:00"
        end = f"{date_str}T23:59:59"
        url = f"https://gateway.maton.ai/outlook/v1.0/me/calendarView?startDateTime={start}&endDateTime={end}&$orderby=start/dateTime"
        
        result = subprocess.run(
            ["curl", "-s", url, "-H", f"Authorization: Bearer {api_key}"],
            capture_output=True, text=True, timeout=30
        )
        data = json.loads(result.stdout) if result.stdout else {}
        return data.get('value', [])
    except Exception as e:
        print(f"[WARN] Outlook API error: {e}", file=sys.stderr)
        return []


def get_todo_lists(api_key):
    """获取 Microsoft To Do 列表"""
    try:
        result = subprocess.run(
            ["curl", "-s", "https://gateway.maton.ai/microsoft-to-do/v1.0/me/todo/lists",
             "-H", f"Authorization: Bearer {api_key}"],
            capture_output=True, text=True, timeout=30
        )
        data = json.loads(result.stdout) if result.stdout else {}
        return data.get('value', [])
    except Exception as e:
        print(f"[WARN] To Do API error: {e}", file=sys.stderr)
        return []


def get_todo_tasks(api_key, list_id):
    """获取指定列表的任务"""
    try:
        url = f"https://gateway.maton.ai/microsoft-to-do/v1.0/me/todo/lists/{list_id}/tasks"
        result = subprocess.run(
            ["curl", "-s", url, "-H", f"Authorization: Bearer {api_key}"],
            capture_output=True, text=True, timeout=30
        )
        data = json.loads(result.stdout) if result.stdout else {}
        return data.get('value', [])
    except Exception as e:
        print(f"[WARN] To Do tasks error: {e}", file=sys.stderr)
        return []


def analyze_tasks(tasks, date_str):
    """统计任务完成情况"""
    stats = {
        "total": len(tasks),
        "completed": 0,
        "active": 0,
        "overdue": 0,
        "today_due": 0,
        "no_due": 0,
        "tasks_detail": []
    }
    
    today = datetime.strptime(date_str, "%Y-%m-%d").date()
    
    for task in tasks:
        status = task.get('status', 'notStarted')
        title = task.get('title', 'Untitled')
        due = task.get('dueDateTime')
        
        is_completed = status == 'completed'
        
        if is_completed:
            stats["completed"] += 1
        else:
            stats["active"] += 1
            
            if due:
                due_date_str = due.get('dateTime', '')[:10]
                if due_date_str:
                    due_date = datetime.strptime(due_date_str, "%Y-%m-%d").date()
                    if due_date < today:
                        stats["overdue"] += 1
                    elif due_date == today:
                        stats["today_due"] += 1
            else:
                stats["no_due"] += 1
        
        stats["tasks_detail"].append({
            "title": title,
            "completed": is_completed,
            "due": due.get('dateTime', '')[:10] if due else None,
            "importance": task.get('importance', 'normal')
        })
    
    return stats


def generate_chart(stats, date_str, output_dir):
    """生成统计图表"""
    try:
        import matplotlib
        matplotlib.use('Agg')
        import matplotlib.pyplot as plt
        import matplotlib.font_manager as fm
        
        # Try to find Chinese font
        plt.rcParams['font.sans-serif'] = ['WenQuanYi Micro Hei', 'SimHei', 'DejaVu Sans']
        plt.rcParams['axes.unicode_minus'] = False
        
        os.makedirs(output_dir, exist_ok=True)
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))
        
        # Bar chart - task status
        categories = ['活跃', '已完成', '逾期', '今日到期']
        values = [stats['active'], stats['completed'], stats['overdue'], stats['today_due']]
        colors = ['#4CAF50', '#2196F3', '#F44336', '#FF9800']
        
        ax1.bar(categories, values, color=colors)
        ax1.set_title('任务状态分布')
        for i, v in enumerate(values):
            ax1.text(i, v + 0.1, str(v), ha='center')
        
        # Pie chart - completion rate
        if stats['total'] > 0:
            completed = stats['completed']
            remaining = stats['total'] - completed
            ax2.pie([completed, remaining], 
                    labels=['已完成', '未完成'],
                    colors=['#4CAF50', '#E0E0E0'],
                    autopct='%1.1f%%',
                    startangle=90)
            ax2.set_title(f'完成率 (共{stats["total"]}项)')
        else:
            ax2.text(0.5, 0.5, '无任务数据', ha='center', va='center')
            ax2.set_title('任务统计')
        
        plt.tight_layout()
        chart_path = os.path.join(output_dir, f'task_stats_{date_str}.png')
        plt.savefig(chart_path, dpi=100, bbox_inches='tight')
        plt.close()
        
        return chart_path
    except ImportError:
        print("[WARN] matplotlib not available, skipping chart", file=sys.stderr)
        return None
    except Exception as e:
        print(f"[WARN] Chart generation error: {e}", file=sys.stderr)
        return None


def format_time(dt_str):
    """Format datetime string to HH:MM"""
    if not dt_str:
        return "??:??"
    try:
        return dt_str[11:16]
    except:
        return "??:??"

def read_today_memory(date_str):
    """读取今日记忆日志"""
    memory_file = os.path.expanduser(f"~/.openclaw/workspace/memory/{date_str}.md")
    if os.path.exists(memory_file):
        with open(memory_file, 'r') as f:
            return f.read()
    return None


def read_local_projects():
    """读取本地项目跟踪"""
    projects_file = os.path.expanduser("~/.openclaw/workspace/memory/projects.md")
    if os.path.exists(projects_file):
        with open(projects_file, 'r') as f:
            return f.read()
    return None


def generate_report(date_str=None):
    """生成日报"""
    if date_str is None:
        date_str = datetime.now().strftime("%Y-%m-%d")
    
    api_key = get_api_key()
    if not api_key:
        print("[ERROR] Cannot generate report without API key")
        return None
    
    print(f"📊 生成日报 — {date_str}")
    
    # 1. 获取日程
    print("  1️⃣ 获取 Outlook 日历...")
    events = get_outlook_events(api_key, date_str)
    print(f"     找到 {len(events)} 个日程")
    
    # 2. 获取任务
    print("  2️⃣ 获取 Microsoft To Do 任务...")
    todo_lists = get_todo_lists(api_key)
    all_tasks = []
    list_names = {}
    for tl in todo_lists:
        lid = tl.get('id')
        lname = tl.get('displayName', 'Unknown')
        list_names[lid] = lname
        tasks = get_todo_tasks(api_key, lid)
        for t in tasks:
            t['_list_name'] = lname
        all_tasks.extend(tasks)
    print(f"     找到 {len(all_tasks)} 个任务")
    
    # 3. 统计
    print("  3️⃣ 统计任务...")
    stats = analyze_tasks(all_tasks, date_str)
    
    # 4. 生成图表
    print("  4️⃣ 生成图表...")
    chart_path = generate_chart(stats, date_str, CHART_DIR)
    
    # 5. 读取本地项目
    projects = read_local_projects()
    memory = read_today_memory(date_str)
    
    # 6. 生成 Markdown 日报
    print("  5️⃣ 生成日报文档...")
    os.makedirs(REPORTS_DIR, exist_ok=True)
    
    lines = []
    lines.append(f"# 📊 日报 — {date_str}")
    lines.append(f"\n> 生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M')}")
    lines.append("")
    
    # 日程
    lines.append("## 📅 今日日程")
    if events:
        for e in events:
            start = format_time(e.get('start', {}).get('dateTime'))
            end = format_time(e.get('end', {}).get('dateTime'))
            subject = e.get('subject', '')
            location = e.get('location', {}).get('displayName', '')
            loc_str = f" 📍{location}" if location else ""
            lines.append(f"- **{start}-{end}** {subject}{loc_str}")
    else:
        lines.append("- 今日无日程 ✨")
    lines.append("")
    
    # 任务统计
    lines.append("## ✅ 任务完成情况")
    lines.append(f"- **活跃任务**: {stats['active']} 项")
    lines.append(f"- **今日完成**: {stats['completed']} 项")
    lines.append(f"- **逾期任务**: {stats['overdue']} 项 🔴")
    lines.append(f"- **今日到期**: {stats['today_due']} 项 🟡")
    lines.append(f"- **总任务数**: {stats['total']} 项")
    if stats['total'] > 0:
        rate = stats['completed'] / stats['total'] * 100
        lines.append(f"- **完成率**: {rate:.1f}%")
    lines.append("")
    
    # 未完成任务详情
    active_tasks = [t for t in stats['tasks_detail'] if not t['completed']]
    if active_tasks:
        lines.append("### 未完成任务")
        for t in active_tasks[:10]:
            due_str = f" (截止: {t['due']})" if t['due'] else ""
            importance = "🔴" if t['importance'] == 'high' else "🟡" if t['importance'] == 'normal' else ""
            lines.append(f"- {importance} {t['title']}{due_str}")
        if len(active_tasks) > 10:
            lines.append(f"- ... 及其他 {len(active_tasks)-10} 项")
        lines.append("")
    
    # 图表
    if chart_path:
        lines.append("## 📈 数据可视化")
        lines.append(f"![任务统计]({chart_path})")
        lines.append("")
    
    # 本地项目
    if projects:
        lines.append("## 📁 项目跟踪")
        # Extract key project info
        for line in projects.split('\n'):
            if line.startswith('###') or line.startswith('- **'):
                lines.append(line)
        lines.append("")
    
    # 今日总结（从 memory 提取）
    if memory:
        lines.append("## 📝 今日记录")
        # Extract session summaries
        for line in memory.split('\n'):
            if '已解决' in line or '完成' in line or '创建' in line or '安装' in line:
                lines.append(f"- {line.strip()}")
        lines.append("")
    
    lines.append("---")
    lines.append(f"*由 Daily Report v2.0 自动生成 | {datetime.now().strftime('%H:%M')}*")
    
    report_content = '\n'.join(lines)
    
    # Save report
    report_path = os.path.join(REPORTS_DIR, f"daily_report_{date_str}.md")
    with open(report_path, 'w') as f:
        f.write(report_content)
    
    print(f"\n✅ 日报已生成：{report_path}")
    if chart_path:
        print(f"📊 图表：{chart_path}")
    
    return report_path


if __name__ == "__main__":
    date = sys.argv[1] if len(sys.argv) > 1 else None
    generate_report(date)
