---
name: daily-report
description: "生成日报：读取Outlook日历、统计Microsoft To Do任务完成情况、生成数据可视化图表、输出格式化日报文档。触发词：'生成日报'、'日报'、'今日总结'"
version: 2.0.0
---

# Daily Report Generator v2.0

自动化日报生成系统，集成 Outlook 日历、Microsoft To Do、数据可视化。

## 触发条件

用户说以下关键词时自动触发：
- "生成日报"
- "日报"
- "今日总结"

## 数据来源

| 数据 | 来源 | API |
|------|------|-----|
| 日程 | Outlook 日历 | `gateway.maton.ai/outlook/v1.0/me/calendarView` |
| 任务 | Microsoft To Do | `gateway.maton.ai/microsoft-to-do/v1.0/me/todo/lists/{id}/tasks` |
| 图表 | matplotlib | Python 本地 |
| 项目 | memory/projects.md | 本地文件 |

## 执行方式

### 方式一：Python 脚本
```bash
python3 ~/.openclaw/workspace/skills/daily-report/scripts/generate_report.py [YYYY-MM-DD]
```

### 方式二：Agent 自动生成（推荐）
收到"生成日报"指令后，直接执行：
1. 调 Outlook 日历获取今日日程
2. 调 Microsoft To Do 获取所有任务并统计
3. 读取本地 memory/{date}.md 和 memory/projects.md
4. 生成格式化日报投递 Telegram

## 输出位置

- **日报**: `~/productivity/reports/daily_report_YYYY-MM-DD.md`
- **图表**: `~/productivity/reports/charts/task_stats_YYYY-MM-DD.png`

## 日报模板

```markdown
# 📊 日报 — YYYY-MM-DD

## 📅 今日日程
- 时间 - 事件 - 地点

## ✅ 任务完成情况
- 专家/完成/逾期/今日到期/完成率

## 📈 数据可视化
[图表]

## 笔记 今日记录
[从 memory 提取]

## 📄 项目跟踪
[从 projects.md 提取]
```

## 环境变量

需要 `MATON_API_KEY` 在 `~/.openclaw/.env` 或环境变量中。

## 投递规则

**默认投递到 Telegram**（用户 2026-03-17 设置）
- 渠道：telegram
- 接收人：[REDACTED]
- 格式：精简版（移除图片路径，适合手机阅读）

---
*Updated: 2026-03-17 | v2.0: Todoist → Microsoft To Do + Outlook*