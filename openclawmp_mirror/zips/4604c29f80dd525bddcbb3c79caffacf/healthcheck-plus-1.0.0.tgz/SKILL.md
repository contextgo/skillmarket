---
name: healthcheck-plus
description: OpenClaw健康检查增强包。用于深度检查OpenClaw系统状态、排查故障、监控性能、生成健康报告。当需要检查OpenClaw运行状态、排查问题、监控系统健康时触发。
---

# OpenClaw健康检查增强包

## 检查项目

### 1. 系统状态
- [ ] Gateway服务运行状态
- [ ] Node连接状态
- [ ] 插件加载状态
- [ ] 进程CPU/内存占用

### 2. 网络连通性
- [ ] 本地网关连接
- [ ] 外部网络访问
- [ ] WebSocket连接
- [ ] API端点可达性

### 3. 存储状态
- [ ] 工作空间磁盘空间
- [ ] 日志文件大小
- [ ] 缓存文件清理
- [ ] 备份状态

### 4. 配置检查
- [ ] 配置文件完整性
- [ ] API密钥有效性
- [ ] 插件配置正确性
- [ ] 环境变量设置

### 5. 日志分析
- [ ] 最近错误日志
- [ ] 警告信息统计
- [ ] 性能日志分析
- [ ] 异常模式识别

## 健康检查命令

### 基础检查
```bash
openclaw gateway status
openclaw gateway info
```

### 详细检查
```bash
openclaw healthcheck
```

### 日志查看
```bash
openclaw logs --lines 100 --level error
```

## 健康报告模板

```markdown
# OpenClaw 健康检查报告

检查时间：YYYY-MM-DD HH:mm
检查版本：vX.X.X

## 系统状态
| 项目 | 状态 | 详情 |
|------|------|------|
| Gateway | 运行中/停止 | PID: xxx |
| CPU使用 | XX% | 正常/偏高 |
| 内存使用 | XX% | 正常/偏高 |
| 磁盘空间 | XX% | 正常/不足 |

## 网络状态
| 检查项 | 状态 | 响应时间 |
|--------|------|----------|
| 本地连接 | ✓/✗ | XXms |
| 外部网络 | ✓/✗ | XXms |
| API服务 | ✓/✗ | XXms |

## 问题汇总

| 严重程度 | 问题 | 建议 |
|----------|------|------|
| 高 | xxx | 立即处理 |
| 中 | xxx | 尽快处理 |
| 低 | xxx | 常规维护 |

## 总体评分
███░░░░░░░ 70/100

## 建议
1. xxx
2. xxx
```

## 故障排查指南

### 问题1：Gateway无法启动
```
排查步骤：
1. 检查端口是否被占用：netstat -ano | findstr :8080
2. 查看日志：openclaw logs --lines 50
3. 检查配置文件：openclaw config validate
4. 重启服务：openclaw gateway restart
```

### 问题2：Node连接失败
```
排查步骤：
1. 检查网络连通性：ping <node-ip>
2. 检查端口开放：telnet <node-ip> <port>
3. 检查Token配置：openclaw node verify
4. 查看Node日志
```

### 问题3：性能下降
```
排查步骤：
1. 检查CPU/内存：top 或 任务管理器
2. 检查磁盘空间：df -h
3. 清理日志：openclaw logs clean
4. 重启服务：openclaw gateway restart
```

## 自动检查计划

建议定期执行：
- 每日：基础状态检查
- 每周：详细健康检查
- 每月：日志清理和备份
- 每季度：配置审查和更新
