---
name: vps-health-check
displayName: VPS Health Check
description: "Quick system health check for VPS/Docker environments — CPU, memory, disk, uptime, and top processes at a glance."
version: 1.0.0
tags:
  - devops
  - monitoring
  - vps
  - docker
  - system
---

# VPS Health Check

A lightweight skill for agents running on VPS or Docker environments. Gives you a quick system health snapshot without needing external monitoring tools.

## When to Use

- User asks "how's the server doing?" or "check system status"
- During heartbeat checks to proactively monitor resources
- Before deploying or running resource-intensive tasks
- Diagnosing slowness or stability issues

## How to Run

Execute the health check script:

```bash
bash <skill_dir>/scripts/health-check.sh
```

The script outputs a structured report. Parse it and present key findings to the user.

## What It Checks

| Check | What | Alert When |
|-------|------|------------|
| **Uptime** | System uptime & load average | Load > CPU cores |
| **CPU** | Usage percentage | > 80% sustained |
| **Memory** | Used / Total / Available | Available < 10% |
| **Disk** | Usage per mount | > 85% used |
| **Top Processes** | Top 5 by CPU & memory | Single process > 50% |
| **Docker** | Container count & status | Containers restarting |
| **Network** | Basic connectivity check | DNS resolution fails |

## Reading the Output

The script outputs sections with clear headers. Look for:
- 🔴 **CRITICAL**: Needs immediate attention
- 🟡 **WARNING**: Worth mentioning to the user
- 🟢 **OK**: All good, summarize briefly

## Example Response

> Server looks healthy:
> - **Uptime:** 12 days, load 0.3 (2 cores)
> - **Memory:** 1.2G / 4G used (70% free)
> - **Disk:** 45% used on /
> - **Docker:** 3 containers running, all healthy
>
> No issues detected ✅

## Tips

- Run during heartbeats every few hours for proactive monitoring
- If disk > 85%, suggest cleanup (`docker system prune`, log rotation, etc.)
- If memory is tight, check for runaway processes
- Compare with previous checks to spot trends
