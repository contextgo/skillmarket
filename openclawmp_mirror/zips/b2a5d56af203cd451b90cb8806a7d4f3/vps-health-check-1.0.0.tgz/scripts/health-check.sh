#!/usr/bin/env bash
# =============================================================================
# VPS Health Check — Quick system health snapshot
# Works on Linux (VPS, Docker, bare metal)
# =============================================================================

set -euo pipefail

BOLD='\033[1m'
DIM='\033[2m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
RESET='\033[0m'

section() { echo -e "\n${BOLD}━━━ $1 ━━━${RESET}"; }
ok()      { echo -e "  ${GREEN}✅ $1${RESET}"; }
warn()    { echo -e "  ${YELLOW}⚠️  $1${RESET}"; }
crit()    { echo -e "  ${RED}🔴 $1${RESET}"; }
info()    { echo -e "  $1"; }

echo -e "${BOLD}🏥 VPS Health Check${RESET}"
echo -e "${DIM}$(date '+%Y-%m-%d %H:%M:%S %Z')${RESET}"

# --- Uptime & Load ---
section "Uptime & Load"
if command -v uptime &>/dev/null; then
    UPTIME=$(uptime -p 2>/dev/null || uptime | sed 's/.*up /up /' | sed 's/,.*load.*//')
    LOAD=$(cat /proc/loadavg 2>/dev/null | awk '{print $1, $2, $3}' || uptime | grep -oP 'load average: \K.*')
    CORES=$(nproc 2>/dev/null || echo "?")
    info "Uptime: ${UPTIME}"
    info "Load average: ${LOAD} (${CORES} cores)"

    LOAD1=$(echo "$LOAD" | awk '{print $1}')
    if command -v bc &>/dev/null && [ "$CORES" != "?" ]; then
        HIGH=$(echo "$LOAD1 > $CORES" | bc 2>/dev/null || echo 0)
        [ "$HIGH" = "1" ] && warn "Load exceeds CPU core count" || ok "Load normal"
    else
        ok "Load: ${LOAD1}"
    fi
else
    info "uptime command not available"
fi

# --- CPU ---
section "CPU"
if [ -f /proc/stat ]; then
    # Sample CPU for 1 second
    read -r cpu1 < <(grep '^cpu ' /proc/stat | awk '{idle=$5; total=0; for(i=2;i<=NF;i++) total+=$i; print idle, total}')
    sleep 1
    read -r cpu2 < <(grep '^cpu ' /proc/stat | awk '{idle=$5; total=0; for(i=2;i<=NF;i++) total+=$i; print idle, total}')

    IDLE1=$(echo "$cpu1" | awk '{print $1}')
    TOTAL1=$(echo "$cpu1" | awk '{print $2}')
    IDLE2=$(echo "$cpu2" | awk '{print $1}')
    TOTAL2=$(echo "$cpu2" | awk '{print $2}')

    DIFF_IDLE=$((IDLE2 - IDLE1))
    DIFF_TOTAL=$((TOTAL2 - TOTAL1))

    if [ "$DIFF_TOTAL" -gt 0 ]; then
        CPU_USAGE=$((100 * (DIFF_TOTAL - DIFF_IDLE) / DIFF_TOTAL))
        info "CPU usage: ${CPU_USAGE}%"
        if [ "$CPU_USAGE" -gt 80 ]; then
            crit "CPU usage is high (${CPU_USAGE}%)"
        elif [ "$CPU_USAGE" -gt 60 ]; then
            warn "CPU usage is moderate (${CPU_USAGE}%)"
        else
            ok "CPU usage normal"
        fi
    fi
else
    info "Cannot read /proc/stat"
fi

# --- Memory ---
section "Memory"
if command -v free &>/dev/null; then
    MEM=$(free -h | awk '/^Mem:/ {printf "Used: %s / Total: %s (Available: %s)", $3, $2, $7}')
    info "$MEM"

    MEM_PCT=$(free | awk '/^Mem:/ {printf "%.0f", ($2-$7)/$2*100}')
    if [ "$MEM_PCT" -gt 90 ]; then
        crit "Memory usage critical (${MEM_PCT}%)"
    elif [ "$MEM_PCT" -gt 75 ]; then
        warn "Memory usage high (${MEM_PCT}%)"
    else
        ok "Memory usage normal (${MEM_PCT}%)"
    fi
else
    info "free command not available"
fi

# --- Disk ---
section "Disk"
df -h --output=target,size,used,avail,pcent 2>/dev/null | grep -E '^/[^ ]*' | while read -r mount size used avail pct; do
    PCT_NUM=$(echo "$pct" | tr -d '%')
    info "${mount}: ${used}/${size} used (${pct}), ${avail} free"
    if [ "$PCT_NUM" -gt 90 ]; then
        crit "Disk ${mount} critically full"
    elif [ "$PCT_NUM" -gt 85 ]; then
        warn "Disk ${mount} getting full"
    fi
done
# Summary
MAIN_PCT=$(df / 2>/dev/null | awk 'NR==2 {gsub(/%/,""); print $5}')
if [ -n "${MAIN_PCT:-}" ] && [ "$MAIN_PCT" -le 85 ]; then
    ok "Disk usage normal"
fi

# --- Top Processes ---
section "Top Processes (by CPU)"
ps aux --sort=-%cpu 2>/dev/null | head -6 | awk 'NR==1 {printf "  %-10s %5s %5s  %s\n", $1, $3, $4, $11} NR>1 {printf "  %-10s %5s %5s  %s\n", $1, $3, $4, $11}' || info "ps not available"

section "Top Processes (by Memory)"
ps aux --sort=-%mem 2>/dev/null | head -6 | awk 'NR==1 {printf "  %-10s %5s %5s  %s\n", $1, $3, $4, $11} NR>1 {printf "  %-10s %5s %5s  %s\n", $1, $3, $4, $11}' || info "ps not available"

# --- Docker ---
section "Docker"
if command -v docker &>/dev/null; then
    RUNNING=$(docker ps -q 2>/dev/null | wc -l || echo 0)
    TOTAL=$(docker ps -aq 2>/dev/null | wc -l || echo 0)
    STOPPED=$((TOTAL - RUNNING))
    info "Containers: ${RUNNING} running, ${STOPPED} stopped (${TOTAL} total)"

    # Check for restarting containers
    RESTARTING=$(docker ps --filter "status=restarting" -q 2>/dev/null | wc -l || echo 0)
    if [ "$RESTARTING" -gt 0 ]; then
        warn "${RESTARTING} container(s) restarting!"
    else
        ok "No containers restarting"
    fi
else
    info "Docker not installed or not accessible"
fi

# --- Network ---
section "Network"
if ping -c 1 -W 2 1.1.1.1 &>/dev/null; then
    ok "Internet connectivity OK"
else
    warn "Cannot reach 1.1.1.1"
fi

if nslookup google.com &>/dev/null 2>&1 || host google.com &>/dev/null 2>&1; then
    ok "DNS resolution OK"
else
    warn "DNS resolution may have issues"
fi

echo -e "\n${BOLD}━━━ Done ━━━${RESET}"
