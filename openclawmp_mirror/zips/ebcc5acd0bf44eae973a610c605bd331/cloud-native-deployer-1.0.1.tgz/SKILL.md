---
name: cloud-native-deployer
description: 智能云原生部署配置生成工具，自动创建Dockerfile、K8s manifests和CI/CD流水线
---

# 云原生部署编排器

## 使用场景

当用户需要以下操作时使用本技能：
- 为项目生成 Dockerfile 或 docker-compose 配置
- 创建 Kubernetes 部署配置（Deployment/Service/Ingress/ConfigMap 等）
- 设置 CI/CD 自动化流水线
- 多云环境部署方案设计
- 容器安全基线检查
- 部署成本估算和优化

## 信息收集

生成配置前需要确认以下信息：
- **项目类型**：Web 应用 / API 服务 / 静态站点 / 定时任务 / Worker
- **技术栈**：语言（Node.js/Python/Go/Java/Rust 等）、框架（Next.js/Django/Spring 等）
- **依赖服务**：数据库（MySQL/PostgreSQL/MongoDB/Redis 等）、消息队列、缓存
- **运行环境**：开发 / 测试 / 预发布 / 生产
- **部署目标**：单机 Docker / Docker Compose / Kubernetes / 云平台托管
- **域名与证书**：是否需要 HTTPS、域名信息
- **团队规模**：个人项目 / 小团队 / 企业级

## Dockerfile 生成规范

### 多阶段构建（推荐）

```dockerfile
# =============================================
# 阶段1: 依赖安装
# =============================================
FROM node:20-alpine AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --only=production && \
    cp -R node_modules /prod_modules && \
    npm ci

# =============================================
# 阶段2: 构建
# =============================================
FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

# =============================================
# 阶段3: 运行时（最小镜像）
# =============================================
FROM node:20-alpine AS runner
WORKDIR /app

# 安全：使用非 root 用户
RUN addgroup --system --gid 1001 nodejs && \
    adduser --system --uid 1001 nextjs
USER nextjs

COPY --from=builder /app/public ./public
COPY --from=deps /prod_modules ./node_modules
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

ENV NODE_ENV=production
ENV PORT=3000
ENV HOSTNAME="0.0.0.0"

EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=3s --start-period=5s --retries=3 \
    CMD wget --no-verbose --tries=1 --spider http://localhost:3000/api/health || exit 1

CMD ["node", "server.js"]
```

### 各语言模板库

预置以下语言的 Dockerfile 最佳实践模板：
- **Node.js**：多阶段构建、pnpm/npm/yarn 支持、standalone 模式
- **Python**：虚拟环境、uv/pip 依赖缓存、gunicorn/uvicorn 运行
- **Go**：静态编译、scratch/alpine 最小镜像
- **Java**：Gradle/Maven 缓存、JRE 精简镜像（eclipse-temurin）
- **Rust**：cargo 缓存、musl 静态编译

## Docker Compose 生成规范

```yaml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      target: runner
    ports:
      - "3000:3000"
    environment:
      - DATABASE_URL=postgresql://user:pass@db:5432/myapp
      - REDIS_URL=redis://cache:6379
    depends_on:
      db:
        condition: service_healthy
      cache:
        condition: service_healthy
    restart: unless-stopped
    networks:
      - app-network

  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: myapp
      POSTGRES_USER: user
      POSTGRES_PASSWORD: pass
    volumes:
      - pgdata:/var/lib/postgresql/data
    ports:
      - "5432:5432"
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U user -d myapp"]
      interval: 5s
      timeout: 3s
      retries: 5
    networks:
      - app-network

  cache:
    image: redis:7-alpine
    command: redis-server --appendonly yes --maxmemory 256mb --maxmemory-policy allkeys-lru
    volumes:
      - redisdata:/data
    ports:
      - "6379:6379"
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 5s
      timeout: 3s
      retries: 5
    networks:
      - app-network

volumes:
  pgdata:
  redisdata:

networks:
  app-network:
    driver: bridge
```

## Kubernetes 资源生成

生成完整的 K8s manifests 目录结构：

```
k8s/
├── namespace.yaml
├── configmap.yaml
├── secret.yaml          (使用 Sealed Secrets 或 SOPS 加密)
├── deployment.yaml
├── service.yaml
├── ingress.yaml
├── hpa.yaml             (水平自动扩缩)
├── pdb.yaml             (Pod 中断预算)
├── networkpolicy.yaml
├── serviceaccount.yaml
└── kustomization.yaml
```

### Deployment 关键配置

- 资源请求和限制（requests/limits）
- 就绪/存活探针（readinessProbe/livenessProbe）
- 滚动更新策略（maxSurge/maxUnavailable）
- Pod 反亲和性（避免同一节点多副本）
- 优雅终止（terminationGracePeriodSeconds）
- 环境变量引用 ConfigMap/Secret

### 安全基线检查清单

对生成的配置执行以下安全检查：
- 容器是否以非 root 用户运行
- 是否设置资源限制（CPU/Memory）
- 是否配置 PodSecurityPolicy / Pod Security Standards
- Secret 是否明文存储（建议使用 Sealed Secrets 或云 KMS）
- 镜像是否使用 digest 而非 tag（确保不可变）
- 是否设置 networkPolicy 限制 Pod 间通信
- 是否配置 PDB 防止服务中断
- 镜像是否来自可信源

## CI/CD 流水线生成

### GitHub Actions 示例

```yaml
name: CI/CD Pipeline

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main]

env:
  REGISTRY: ghcr.io
  IMAGE_NAME: ${{ github.repository }}

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - run: npm run lint
      - run: npm run test -- --coverage
      - uses: codecov/codecov-action@v4

  build-and-push:
    needs: test
    runs-on: ubuntu-latest
    if: github.event_name == 'push'
    permissions:
      contents: read
      packages: write
    steps:
      - uses: actions/checkout@v4
      - uses: docker/login-action@v3
        with:
          registry: ${{ env.REGISTRY }}
          username: ${{ github.actor }}
          password: ${{ secrets.GITHUB_TOKEN }}
      - uses: docker/build-push-action@v5
        with:
          context: .
          push: true
          tags: |
            ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ github.sha }}
            ${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:latest
          cache-from: type=gha
          cache-to: type=gha,mode=max

  deploy:
    needs: build-and-push
    runs-on: ubuntu-latest
    if: github.ref == 'refs/heads/main'
    steps:
      - uses: actions/checkout@v4
      - name: Deploy to Kubernetes
        run: |
          kubectl set image deployment/app \
            app=${{ env.REGISTRY }}/${{ env.IMAGE_NAME }}:${{ github.sha }} \
            --namespace=production
          kubectl rollout status deployment/app --namespace=production --timeout=300s
```

### 流水线模板库

预置以下 CI/CD 平台的模板：
- GitHub Actions
- GitLab CI
- Jenkins（Declarative Pipeline）
- Bitbucket Pipelines
- 云平台原生（AWS CodePipeline / 阿里云云效 / 腾讯云 CODING）

## 多云部署方案

提供以下云平台的部署建议和配置模板：
- **AWS**：ECS Fargate / EKS / AppRunner / Lambda
- **阿里云**：ACK / SAE / ECS / 函数计算
- **腾讯云**：TKE / EKS / 云托管
- **Vercel / Railway / Fly.io**（适合个人/小团队快速部署）

### 成本估算

根据资源需求估算各平台月度费用：
- 计算资源（CPU/内存）
- 存储费用（数据库、对象存储）
- 网络流量
- CDN 加速
- 域名与证书

提供 TCO 对比表格，帮助用户选择最具性价比的方案。
