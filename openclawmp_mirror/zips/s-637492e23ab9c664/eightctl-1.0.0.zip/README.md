# eightctl

使用 `eightctl` 控制 Eight Sleep pod。需要认证。

认证
- 配置: `~/.config/eightctl/config.yaml`
- 环境变量: `EIGHTCTL_EMAIL`, `EIGHTCTL_PASSWORD`

快速开始
- `eightctl status`
- `eightctl on|off`
- `eightctl temp 20`

常见任务
- 闹钟: `eightctl alarm list|create|dismiss`
- 日程: `eightctl schedule list|create|update`
- 音频: `eightctl audio state|play|pause`
- 底座: `eightctl base info|angle`

注意事项
- API 是非官方的且有限流；避免重复登录。
- 更改温度或闹钟前请确认。