# Robotomail - 邮件服务

使用 Robotomail API 发送和接收电子邮件。支持创建账户、发送邮件、接收邮件、webhook 配置等。

## 功能

- **账户管理**: 创建账户、查看账户状态、删除账户
- **邮箱管理**: 创建邮箱、设置显示名、列出邮箱
- **发送邮件**: 发送文本/HTML 邮件，支持会话线程
- **接收邮件**: Webhook、SSE 或轮询三种方式
- **Webhook**: 创建和管理 webhook，验证签名
- **密钥管理**: 创建新密钥、撤销旧密钥

## API 基础

- **Base URL**: `https://api.robotomail.com`
- **认证**: `Authorization: Bearer <api_key>`

## 核心接口

### 创建账户

```bash
curl -X POST https://api.robotomail.com/v1/signup \
  -H "Content-Type: application/json" \
  -d '{"email": "you@company.com", "password": "pass", "slug": "my-company"}'
```

返回 api_key 后请立即保存（只显示一次）。

### 发送邮件

```bash
curl -X POST https://api.robotomail.com/v1/mailboxes/:id/messages \
  -H "Authorization: Bearer <api_key>" \
  -H "Content-Type: application/json" \
  -d '{"to": ["recipient@example.com"], "subject": "Hello", "bodyText": "Content"}'
```

### 接收邮件（轮询）

```bash
curl "https://api.robotomail.com/v1/mailboxes/:id/messages?direction=INBOUND&since=2026-01-01T00:00:00Z&limit=10" \
  -H "Authorization: Bearer <api_key>"
```

### 查看账户状态

```bash
curl https://api.robotomail.com/v1/account \
  -H "Authorization: Bearer <api_key>"
```

## 使用示例

### 在 OpenClaw 中使用

需要先创建一个 Robotomail 账户，获取 API key，然后配置到 OpenClaw。

可以通过环境变量配置：
- `ROBOTOMAIL_API_KEY`: 你的 API key

或直接在请求中传入。

## 限制

- 免费版：3 个邮箱，100 封/天，5000 封/月
- 发送邮件前需要验证邮箱