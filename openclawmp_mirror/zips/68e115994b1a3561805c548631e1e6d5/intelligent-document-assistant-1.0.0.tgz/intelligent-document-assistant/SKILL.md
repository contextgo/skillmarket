---
name: intelligent-document-assistant
description: '智能文档助手 - 自动生成、审阅、优化各类专业文档'
version: 1.0.0
type: skill
tags: ['document', 'writing', 'review', 'optimization', 'productivity']
---

# 智能文档助手

> 自动生成、审阅、优化各类专业文档

## 核心功能

- 📝 智能文档生成
- 🔍 自动审阅检查
- ✨ 内容优化建议
- 🌐 多语言翻译
- 📄 格式自动转换

## 支持的文档类型

| 类型 | 说明 | 适用场景 |
|------|------|---------|
| 技术文档 | API文档、架构设计、开发规范 | 研发团队 |
| 产品文档 | PRD、用户手册、发布说明 | 产品团队 |
| 商业文档 | 商业计划书、合同、提案 | 商务团队 |
| 学术文档 | 论文、报告、文献综述 | 研究人员 |
| 营销文档 | 白皮书、案例研究、博客 | 市场团队 |

## 使用方法

```bash
# 生成技术文档
openclaw skill run doc-assistant --type "api-doc" --input "./api-spec.yaml"

# 审阅文档
openclaw skill run doc-assistant --action "review" --file "./document.md"

# 优化文档
openclaw skill run doc-assistant --action "optimize" --file "./document.md"

# 翻译文档
openclaw skill run doc-assistant --action "translate" --file "./document.md" --target "en"
```

## 文档生成功能

### 1. API文档生成
```markdown
# User API

## 获取用户信息

### Endpoint
`GET /api/v1/users/{id}`

### Parameters
| 参数 | 类型 | 必填 | 说明 |
|------|------|------|------|
| id | string | 是 | 用户ID |

### Response
```json
{
  "id": "123",
  "name": "张三",
  "email": "zhangsan@example.com"
}
```

### Error Codes
| 状态码 | 说明 |
|--------|------|
| 200 | 成功 |
| 404 | 用户不存在 |
| 500 | 服务器错误 |
```

### 2. PRD生成
```markdown
# 产品需求文档：智能推荐系统

## 背景
当前平台缺乏个性化推荐，用户发现内容困难...

## 目标
- 提升用户留存率 20%
- 增加内容消费时长 30%

## 功能需求

### 1. 用户画像
- 收集用户行为数据
- 构建兴趣标签

### 2. 推荐算法
- 协同过滤
- 内容相似度

## 验收标准
- [ ] 推荐准确率 > 80%
- [ ] 响应时间 < 100ms
```

## 文档审阅功能

### 检查项
- ✅ 语法和拼写
- ✅ 格式一致性
- ✅ 逻辑完整性
- ✅ 专业术语准确性
- ✅ 可读性评分

### 审阅报告示例
```markdown
## 文档审阅报告

### 总体评分：78/100

### 问题汇总
| 类型 | 数量 | 严重程度 |
|------|------|---------|
| 语法错误 | 3 | 低 |
| 格式问题 | 5 | 中 |
| 逻辑缺失 | 2 | 高 |

### 详细建议
1. **第3节**：缺少数据支撑，建议添加统计图表
2. **第5节**：术语使用不一致，统一为"用户"而非"客户"
3. **整体**：建议添加目录和页码
```

## 文档优化功能

### 优化维度
- 📖 可读性提升
- 🎯 重点突出
- 🔗 结构优化
- 📝 表达精炼
- 🌟 专业度提升

### 优化示例

**优化前**：
```
这个功能可以让用户更好地使用我们的产品，
提升他们的体验，让他们更喜欢我们的产品。
```

**优化后**：
```
本功能通过个性化推荐算法，将用户内容发现效率提升40%，
显著改善用户体验并提高平台留存率。
```

## 安装

```bash
openclaw skill install intelligent-document-assistant
```

## 配置

```json
{
  "skills": {
    "intelligent-document-assistant": {
      "defaultLanguage": "zh",
      "style": "professional",
      "tone": "formal",
      "industry": "technology"
    }
  }
}
```

## 高级功能

- 🤖 AI内容生成
- 📊 文档质量评分
- 🔄 版本对比
- 👥 协作审阅
- 🔒 敏感信息检测

---

**让文档工作更高效、更专业！**
