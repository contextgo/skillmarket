---
name: agent-team-orchestration
version: "1.1.0"
last_updated: "2026-04-15"
changelog: "- 强化流程、边界和验收"
description: "Orchestrate multi-agent teams with defined roles, task lifecycles, handoff protocols, and review workflows. Use when setting up a team of 2+ agents, defining task routing and lifecycle, creating handoff protocols, establishing review gates, or managing async artifact sharing. 触发词：multi-agent、orchestration、handoff、review workflow、task lifecycle、agent team、协作编排。"
---

# Agent Team Orchestration

## Goal
Run multi-agent work with clear roles, clear handoffs, and clear review gates.

## Workflow

### Phase 1: Define Roles
- Assign one owner for routing
- Assign builders for execution
- Assign reviewers for verification

### Phase 2: Define Task Flow
- Move work through Inbox → Assigned → In Progress → Review → Done / Failed
- Record every transition with who changed it and why

### Phase 3: Handoff
- Include what was done, where artifacts live, how to verify, and what is next
- If the handoff is vague, rewrite it before sending

### Phase 4: Review
- Check artifacts against the task goal
- Reject incomplete work instead of passing it forward

## Guardrails
- Do not skip review for multi-step work
- Do not spawn agents without a clear artifact path
- Do not let agents manage their own state silently

## Success Criteria
- Every task has an owner
- Every handoff is actionable
- Every outcome is either verified or clearly blocked
