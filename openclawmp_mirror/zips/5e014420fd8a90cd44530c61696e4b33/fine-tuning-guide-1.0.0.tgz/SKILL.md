---
name: fine-tuning-guide
description: "LLM fine-tuning guide - LoRA, QLoRA, and full fine-tuning patterns for large language models"
version: 1.0.0
tags: ["fine-tuning", "llm", "lora", "qlora", "machine-learning", "ai"]
---

# LLM Fine-Tuning Guide

Fine-tuning adapts pre-trained LLMs to specific tasks with domain-specific data, improving performance without training from scratch.

## Fine-Tuning Methods

| Method | VRAM | Speed | Quality |
|--------|------|-------|---------|
| Full fine-tune | High | Slow | Best |
| LoRA | Medium | Fast | Good |
| QLoRA | Low | Fast | Good |

## LoRA Fine-Tuning (Transformers)

```python
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

# Quantized model
bnb_config = BitsAndBytesConfig(
    load_in_4bit=True,
    bnb_4bit_quant_type="nf4",
)

model = AutoModelForCausalLM.from_pretrained(
    "meta-llama/Llama-2-7b",
    quantization_config=bnb_config,
    device_map="auto",
)

# LoRA config
lora_config = LoraConfig(
    r=16,
    lora_alpha=32,
    target_modules=["q_proj", "v_proj"],
    lora_dropout=0.05,
    bias="none",
)

model = get_peft_model(model, lora_config)
model.print_trainable_parameters()  # Shows 0.1% trainable
```

## Training with TRL

```python
from trl import SFTTrainer

trainer = SFTTrainer(
    model=model,
    train_dataset=dataset,
    dataset_text_field="text",
    max_seq_length=512,
    num_train_epochs=3,
    per_device_train_batch_size=4,
    learning_rate=2e-4,
    fp16=True,
)

trainer.train()
```

## Data Format (ChatML)

```json
{"messages": [
  {"role": "system", "content": "You are a helpful assistant."},
  {"role": "user", "content": "Explain quantum computing"},
  {"role": "assistant", "content": "Quantum computing uses qubits..."}
]}
```

## Best Practices

- Start with LoRA (r=16, alpha=32) before full fine-tuning
- Use a learning rate of 2e-4 to 5e-4
- Train for 1-3 epochs to avoid overfitting
- Use a small eval set (5-10%) to monitor loss
- Gradient checkpointing reduces memory by 60%
