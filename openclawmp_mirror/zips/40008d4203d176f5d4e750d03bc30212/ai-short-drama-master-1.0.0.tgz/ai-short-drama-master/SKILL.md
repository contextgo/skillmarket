---
name: ai-short-drama-master
description: 'AI短剧创作大师 - 从剧本到发布的完整短剧创作工作流，一站式解决所有创作需求'
version: 1.0.0
type: skill
tags: ['ai-video', 'short-drama', 'content-creation', 'workflow', 'master']
---

# AI短剧创作大师

> 从剧本到发布的完整短剧创作工作流，一站式解决所有创作需求

## 🎬 核心功能

### 1. 智能剧本创作
- 🤖 AI生成原创剧本
- 📚 100+行业模板库
- 🎭 多种风格（温情/搞笑/悬疑/科幻）
- ⏱️ 支持8秒/15秒/30秒/60秒时长

### 2. 自动分镜设计
- 🎨 AI生成分镜脚本
- 📐 专业镜头语言
- 🎞️ 时间轴规划
- 🖼️ 视觉参考图生成

### 3. AI视频提示词优化
- ✨ 一键生成专业提示词
- 🎬 支持Runway/可灵/即梦AI
- 📝 中英双语版本
- 🎯 针对平台优化（抖音/小红书/B站）

### 4. 音效与配乐
- 🎵 智能配乐推荐
- 🔊 音效库匹配
- 🎤 配音脚本生成
- 📻 背景音乐版权提示

### 5. 一键发布
- 📱 抖音发布助手
- 📕 小红书发布助手
- 📺 B站发布助手
- 📝 标题/标签/文案自动生成

## 🚀 使用方法

### 快速开始

```bash
# 创建完整短剧项目
openclaw skill run short-drama-master --create "我的第一个短剧"

# 选择模板快速创作
openclaw skill run short-drama-master --template "温情反转" --theme "亲情"

# 全流程自动创作
openclaw skill run short-drama-master --auto --duration 15 --platform douyin
```

### 分步创作

```bash
# 第1步：创作剧本
openclaw skill run short-drama-master --step script --type "温情" --emotion "感人"

# 第2步：设计分镜
openclaw skill run short-drama-master --step storyboard

# 第3步：生成提示词
openclaw skill run short-drama-master --step prompt --ai runway

# 第4步：推荐音效
openclaw skill run short-drama-master --step audio

# 第5步：发布准备
openclaw skill run short-drama-master --step publish --platform xiaohongshu
```

## 📋 完整输出示例

### 项目结构

```
我的第一个短剧/
├── 📄 剧本/
│   ├── 完整剧本.md
│   ├── 角色设定.md
│   └── 对白脚本.md
├── 🎨 分镜/
│   ├── 分镜脚本.md
│   ├── 镜头清单.md
│   └── 视觉参考/
├── 🎬 提示词/
│   ├── Runway版本.md
│   ├── 可灵AI版本.md
│   └── 即梦AI版本.md
├── 🎵 音效/
│   ├── 配乐推荐.md
│   ├── 音效清单.md
│   └── 配音脚本.md
└── 📱 发布/
    ├── 抖音文案.md
    ├── 小红书文案.md
    └── B站文案.md
```

### 剧本示例

```markdown
# 《最后一秒》

## 基本信息
- 时长：15秒
- 风格：温情/感人
- 主题：亲情/时光

## 剧情概要
老人在生命最后时刻，回忆与妻子的美好时光...

## 分镜脚本

### 镜头1（0-3秒）：老人眼睛特写
**画面**：老人布满皱纹的眼睛，眼神逐渐涣散
**提示词**：极特写：老人苍老眼睛，布满皱纹的眼角，眼神从清晰到模糊，暖黄色柔光，回忆感，电影级画质

### 镜头2（3-7秒）：时光倒流
**画面**：画面快速倒放，老人变年轻
**提示词**：快速剪辑：老人面容逐渐年轻，白发变黑发，皱纹消失，时光倒流特效，暖色调，梦幻感

### 镜头3（7-12秒）：年轻时代
**画面**：年轻夫妇在公园散步
**提示词**：全景：年轻夫妇手牵手走在春日公园，樱花飘落，阳光斑驳，笑容灿烂，浪漫温馨

### 镜头4（12-15秒）：回到现实
**画面**：老人安详离世，手中握着老照片
**提示词**：特写：老人安详面容，手中紧握泛黄老照片，照片上是年轻时的夫妻，暖光，平静而美好

## 音效建议
- 背景音乐：钢琴曲《River Flows in You》
- 音效：时钟滴答声、樱花飘落声
- 配音：温柔女声旁白

## 发布文案

### 抖音
```
15秒看完一生💔
#温情短剧 #感人故事 #亲情 #时光
```

### 小红书
```
用AI做了人生第一个短剧😭
从剧本到发布全流程
#AI视频 #短剧创作 #教程
```
```

## 🎨 模板库

### 温情类
- 《最后一秒》- 生命回忆
- 《妈妈的菜》- 亲情美食
- 《老照片》- 时光倒流

### 搞笑类
- 《倒霉的魔术师》- 表演翻车
- 《职场新人》- 社死现场
- 《相亲记》- 尴尬约会

### 悬疑类
- 《午夜电话》- 神秘来电
- 《消失的邻居》- 悬疑推理
- 《最后一班地铁》- 都市传说

### 科幻类
- 《2077》- 赛博朋克
- 《时间旅行者》- 穿越故事
- 《AI觉醒》- 人工智能

## ⚙️ 配置

```json
{
  "skills": {
    "ai-short-drama-master": {
      "defaultPlatform": "douyin",
      "defaultDuration": 15,
      "defaultStyle": "温情",
      "aiEngine": "runway",
      "language": "zh",
      "outputFormat": "markdown"
    }
  }
}
```

## 📊 创作统计

```bash
# 查看创作统计
openclaw skill run short-drama-master --stats

# 输出：
# 总创作数：12
# 总播放量：50K+
# 最受欢迎：温情类（60%）
# 最佳发布时间：晚8-10点
```

## 🎯 适用人群

- 🎬 短视频创作者
- 📱 自媒体运营者
- 🎨 AI艺术爱好者
- 💼 内容营销人员
- 🎓 影视专业学生

## 💡 高级功能

- 🤖 AI学习你的创作风格
- 📈 数据分析优化内容
- 🔄 批量生成系列内容
- 👥 团队协作创作
- 🌐 多语言版本生成

---

**从0到1，一站式创作你的第一个AI短剧！**
