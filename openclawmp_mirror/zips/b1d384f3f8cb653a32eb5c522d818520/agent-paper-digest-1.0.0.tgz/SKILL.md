---
name: agent-paper-digest
displayName: 【agent-paper-digest】Agent论文追踪：每天自动追踪arXiv上Agent、Multi-Agent、Skill相关的最新论文
description: 🚀 科研人必备！自动全网搜索Agent/Multi-Agent/Skill最新论文，智能分类（必读/选读/速览），生成精美日报，支持定时推送到飞书/元宝/企微。告别手动刷arXiv，让AI帮你追踪前沿！
version: 1.0.4
type: skill
category: research
tags:
  - arxiv
  - agent
  - multi-agent
  - skill
  - paper
  - research
  - automation
  - cron
author: MOMOZI
contributors:
  - MOMOZI
license: MIT
longDescription: |
  Agent论文追踪技能，帮助研究者和开发者快速了解Agent领域的最新进展。
  
  核心功能：
  1. 自动抓取arXiv CS.AI最新论文
  2. 智能筛选Agent/Multi-Agent/Skill相关论文
  3. 按主题自动分类（技能进化、多智能体、记忆、安全等）
  4. 生成Markdown表格报告
  5. 支持定时任务自动推送
  
  关键词覆盖：agent, multi-agent, agentic, skill, tool use, function calling, 
  agent memory, agent safety, chain-of-thought, reasoning等。
---

# 📚 Agent论文追踪

> 自动追踪arXiv上Agent、Multi-Agent、Skill相关的最新论文

## 功能特性

- 🔍 **自动抓取** - 从arXiv CS.AI抓取最新论文
- 🎯 **智能筛选** - 基于关键词识别Agent相关论文
- 📊 **自动分类** - 按主题分类（技能进化、多智能体、记忆、安全等）
- 📝 **结构化输出** - Markdown表格，包含标题、作者、链接、摘要
- ⏰ **定时推送** - 支持cron定时任务自动执行

## 论文分类

| 分类 | 关键词 | 说明 |
|------|--------|------|
| 🔥 技能自进化 | skill, evolve, self-improving | Agent自动学习新技能 |
| 🤝 多智能体系统 | multi-agent, collaboration | 多Agent协作与协调 |
| 🧠 记忆与认知 | memory, retrieval, cognitive | Agent记忆系统 |
| 🔒 安全与对齐 | safety, security, alignment | Agent安全研究 |
| 📊 评估与基准 | benchmark, evaluation | Agent评测方法 |
| 🏥 垂直应用 | medical, finance, coding | 领域应用 |
| 🧩 推理与思维 | reasoning, chain-of-thought | 推理能力 |

## 使用方法

### 手动执行

```bash
# 新版：使用全网搜索（推荐）
python3 ~/.stepclaw/skills/agent-paper-digest/digest_search.py

# 旧版：使用arXiv API（可能不稳定）
python3 ~/.stepclaw/skills/agent-paper-digest/digest_v2.py
```

### Agent调用

```
@老罗 帮我找一下近7天的Agent论文，找出20篇
```

### 定时任务

```
创建一个定时任务，每天早上9点推送Agent论文选读
```

## 输出示例

```markdown
# 📚 Agent论文选读 | 近7天

找到 **5** 篇Agent相关论文

## 🔥 技能自进化 (3篇)

| # | 标题 | 作者 | 时间 | 链接 | 一句话摘要 |
|---|------|------|------|------|-----------|
| 1 | Memento-Skills: Let Agents Design Agents | Huichi Zhou... | 2026-03-19 | [arXiv](...) | 让Agent自己设计Agent... |
```

## 文件结构

```
agent-paper-digest/
├── SKILL.md              # 技能说明（本文件）
├── digest_search.py      # 核心脚本：全网搜索论文
├── push_daily.py         # 日报推送脚本
├── digest_v2.py          # 旧版脚本（arXiv API，兼容保留）
└── run.sh                # 执行脚本
```

## 依赖

### 系统依赖
- Python 3.8+
- 标准库：re, json, datetime, typing, subprocess

### Skill 依赖
- **step-search** - 用于全网搜索论文（必须预先安装）

### 安装 step-search
```bash
# 如果尚未安装 step-search skill
openclawmp install skill/step-search
```

## 定时任务配置

### 配置每天自动推送

```bash
# 添加到 cron 定时任务（每天晚上9点推送）
openclaw cron add --name "Agent论文日报" \
  --schedule "0 21 * * *" \
  --command "python3 ~/.stepclaw/skills/agent-paper-digest/digest_search.py"
```

### 手动推送消息

```python
# 生成简报后推送到指定渠道
message.send(
    channel="yuanbao",  # 或 feishu, wecom 等
    target="group:YOUR_GROUP_ID",
    content=briefing
)
```

## 日报格式模板

### 标准输出格式

```
📚 **Agent论文选读** | 全网检索

⏰ {时间} 更新 · 🔍 找到{N}篇相关论文

━━━━━━━━━

🔴 **必读推荐 · {N}篇**

▸ **{论文标题}**
  {一句话摘要}
  🔗 {链接}

━━━━━━━━━

🟡 **选读推荐 · {N}篇**

...

━━━━━━━━━

🟢 **速览 · {N}篇**

• {论文标题}
...

━━━━━━━━━

🔨 由 Agent Paper Digest + StepFun Search 技能生成
🦞 老罗 · 每日自动检索推送
```

## 版本历史

- v1.0.4 (2026-03-28) - 优化展示
  - 优化 description，更吸引人
- v1.0.3 (2026-03-28) - 完善封装
  - 添加 push_daily.py 日报推送脚本
  - 完善依赖声明（step-search）
  - 添加日报格式模板
  - 添加定时任务配置示例
- v1.0.2 (2026-03-28) - 重大更新
  - 新增 digest_search.py：使用全网搜索替代arXiv API
  - 集成 StepFun Search 能力
  - 解决arXiv API不稳定问题
- v1.0.1 (2026-03-28) - 更新标题
  - 更新displayName
- v1.0.0 (2026-03-27) - 初始版本
  - 基础论文抓取与分类
  - Markdown表格输出
  - 定时任务支持

## 贡献者

- **MOMOZI** - 创建者与主要开发者

## 许可证

MIT License
