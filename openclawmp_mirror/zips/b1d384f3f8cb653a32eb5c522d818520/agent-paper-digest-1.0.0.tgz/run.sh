#!/bin/bash
# Agent Paper Digest - 执行脚本

# 默认参数
DAYS=${1:-7}
COUNT=${2:-20}

echo "🔍 Agent Paper Digest - 正在搜索近${DAYS}天的论文..."

# 执行Python脚本
python3 ~/.stepclaw/skills/agent-paper-digest/digest.py "$DAYS" "$COUNT"
