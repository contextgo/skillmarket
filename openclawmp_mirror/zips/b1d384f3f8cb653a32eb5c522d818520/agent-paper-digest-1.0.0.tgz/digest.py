#!/usr/bin/env python3
"""
Agent Paper Digest - 自动追踪Agent相关论文
"""

import re
import json
from datetime import datetime, timedelta
from typing import List, Dict, Optional
import subprocess
import sys

# Agent相关关键词
AGENT_KEYWORDS = [
    'agent', 'multi-agent', 'agentic', 'tool use', 'function calling',
    'skill', 'llm agent', 'ai agent', 'autonomous agent',
    'agent framework', 'agent memory', 'agent safety',
    'chain-of-thought', 'reasoning', 'planning'
]

# 论文主题分类
CATEGORIES = {
    'skill_evolution': ['skill', 'evolve', 'self-improving', 'autonomous'],
    'multi_agent': ['multi-agent', 'collaboration', 'coordination', 'distributed'],
    'memory': ['memory', 'retrieval', 'knowledge graph', 'cognitive'],
    'safety': ['safety', 'security', 'alignment', 'robustness'],
    'evaluation': ['benchmark', 'evaluation', 'assessment', 'metric'],
    'application': ['medical', 'healthcare', 'finance', 'coding', 'web']
}


def fetch_arxiv_papers(days: int = 7, max_results: int = 50) -> List[Dict]:
    """从arXiv抓取最近论文 - 使用web-fetch工具方式"""
    papers = []
    
    # 尝试从arXiv list页面获取
    try:
        import urllib.request
        import urllib.error
        
        # 获取CS.AI最新论文
        url = f"https://arxiv.org/list/cs.AI/recent?skip=0&show={max_results}"
        
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        )
        
        with urllib.request.urlopen(req, timeout=30) as response:
            html = response.read().decode('utf-8')
            papers = parse_arxiv_list_page(html)
            
    except Exception as e:
        print(f"Error fetching from arXiv list: {e}")
        # 备用：返回空列表，让调用者处理
        pass
    
    return papers


def parse_arxiv_list_page(html: str) -> List[Dict]:
    """解析arXiv列表页面HTML"""
    papers = []
    
    # 查找论文条目
    entry_pattern = r'<dt>.*?<a href="/abs/([\d\.]+)"[^>]*>arXiv:([\d\.]+)</a>.*?</dt>.*?<dd>(.*?)</dd>'
    entries = re.findall(entry_pattern, html, re.DOTALL)
    
    for arxiv_id, _, entry_html in entries[:30]:  # 最多30篇
        paper = {}
        paper['arxiv_id'] = arxiv_id
        paper['url'] = f"https://arxiv.org/abs/{arxiv_id}"
        
        # 提取标题
        title_match = re.search(r'<div class="list-title mathjax">.*?Title:\s*(.*?)</div>', entry_html, re.DOTALL)
        if title_match:
            paper['title'] = clean_text(title_match.group(1))
        else:
            paper['title'] = "N/A"
        
        # 提取作者
        author_match = re.search(r'<div class="list-authors">(.*?)</div>', entry_html, re.DOTALL)
        if author_match:
            authors_html = author_match.group(1)
            authors = re.findall(r'<a[^>]*>([^<]+)</a>', authors_html)
            paper['authors'] = authors[:3]  # 最多3个
        else:
            paper['authors'] = []
        
        # 提取摘要（列表页可能没有完整摘要）
        paper['summary'] = ""
        
        # 提取日期
        date_match = re.search(r'\d{1,2}\s+[A-Za-z]+\s+\d{4}', entry_html)
        if date_match:
            paper['published'] = date_match.group(0)
        else:
            paper['published'] = "N/A"
        
        papers.append(paper)
    
    return papers


def parse_arxiv_response(xml_content: str) -> List[Dict]:
    """解析arXiv XML响应"""
    papers = []
    
    # 使用正则提取条目
    entry_pattern = r'<entry>(.*?)</entry>'
    entries = re.findall(entry_pattern, xml_content, re.DOTALL)
    
    for entry in entries:
        paper = {}
        
        # 提取标题
        title_match = re.search(r'<title>(.*?)</title>', entry, re.DOTALL)
        paper['title'] = clean_text(title_match.group(1)) if title_match else "N/A"
        
        # 提取作者
        author_matches = re.findall(r'<name>(.*?)</name>', entry)
        paper['authors'] = author_matches[:3]  # 最多3个作者
        
        # 提取摘要
        summary_match = re.search(r'<summary>(.*?)</summary>', entry, re.DOTALL)
        paper['summary'] = clean_text(summary_match.group(1))[:300] if summary_match else "N/A"
        
        # 提取链接
        id_match = re.search(r'<id>(.*?)</id>', entry)
        paper['url'] = id_match.group(1) if id_match else "N/A"
        
        # 提取发布时间
        published_match = re.search(r'<published>(.*?)</published>', entry)
        paper['published'] = published_match.group(1)[:10] if published_match else "N/A"
        
        # 提取arXiv ID
        paper['arxiv_id'] = paper['url'].split('/')[-1] if paper['url'] != "N/A" else "N/A"
        
        papers.append(paper)
    
    return papers


def clean_text(text: str) -> str:
    """清理文本"""
    text = re.sub(r'\s+', ' ', text)
    text = text.replace('\n', ' ').strip()
    return text


def categorize_paper(paper: Dict) -> str:
    """对论文进行分类"""
    text = (paper['title'] + ' ' + paper.get('summary', '')).lower()
    
    scores = {}
    for category, keywords in CATEGORIES.items():
        score = sum(1 for kw in keywords if kw in text)
        scores[category] = score
    
    # 返回得分最高的分类
    if max(scores.values()) > 0:
        return max(scores, key=scores.get)
    return 'general'


def generate_one_liner(paper: Dict) -> str:
    """生成一句话摘要"""
    summary = paper.get('summary', '')
    if not summary or summary == "N/A":
        return "暂无摘要"
    
    # 取前100字符，尝试找到完整句子
    sentences = summary.split('. ')
    if sentences:
        first = sentences[0]
        if len(first) > 150:
            first = first[:150] + "..."
        return first + "."
    return summary[:150] + "..."


def format_papers_markdown(papers: List[Dict], days: int) -> str:
    """格式化为Markdown表格"""
    lines = []
    lines.append(f"# 📚 Agent论文选读 | 近{days}天")
    lines.append("")
    lines.append(f"*生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')}*")
    lines.append("")
    
    # 按分类分组
    categorized = {}
    for paper in papers:
        cat = categorize_paper(paper)
        if cat not in categorized:
            categorized[cat] = []
        categorized[cat].append(paper)
    
    # 分类标题映射
    cat_names = {
        'skill_evolution': '🔥 技能自进化',
        'multi_agent': '🤝 多智能体系统',
        'memory': '🧠 记忆与认知',
        'safety': '🔒 安全与对齐',
        'evaluation': '📊 评估与基准',
        'application': '🏥 垂直应用',
        'general': '📄 其他Agent研究'
    }
    
    for cat, cat_papers in categorized.items():
        if not cat_papers:
            continue
        
        lines.append(f"## {cat_names.get(cat, cat)}")
        lines.append("")
        lines.append("| # | 标题 | 作者 | 时间 | 链接 | 一句话摘要 |")
        lines.append("|---|------|------|------|------|-----------|")
        
        for i, paper in enumerate(cat_papers[:10], 1):  # 每类最多10篇
            title = paper['title'][:50] + "..." if len(paper['title']) > 50 else paper['title']
            authors = ', '.join(paper['authors'][:2]) if paper['authors'] else "N/A"
            if len(authors) > 30:
                authors = authors[:30] + "..."
            published = paper.get('published', 'N/A')
            url = f"[arXiv]({paper['url']})" if paper['url'] != "N/A" else "N/A"
            oneliner = generate_one_liner(paper)[:60] + "..."
            
            lines.append(f"| {i} | {title} | {authors} | {published} | {url} | {oneliner} |")
        
        lines.append("")
    
    lines.append("---")
    lines.append("*🔨 由 Agent Paper Digest 技能生成*")
    
    return '\n'.join(lines)


def main():
    """主函数"""
    # 解析参数
    days = 7
    max_results = 30
    
    if len(sys.argv) > 1:
        try:
            days = int(sys.argv[1])
        except ValueError:
            pass
    
    if len(sys.argv) > 2:
        try:
            max_results = int(sys.argv[2])
        except ValueError:
            pass
    
    print(f"正在抓取近{days}天的Agent相关论文...")
    
    papers = fetch_arxiv_papers(days, max_results)
    
    if not papers:
        print("未找到论文或获取失败")
        return
    
    # 过滤Agent相关论文
    filtered = []
    for paper in papers:
        text = (paper['title'] + ' ' + paper.get('summary', '')).lower()
        if any(kw in text for kw in AGENT_KEYWORDS):
            filtered.append(paper)
    
    # 生成报告
    report = format_papers_markdown(filtered[:max_results], days)
    
    # 输出到文件
    output_file = f"/Users/jyxc-dz-0100378/.stepclaw/workspace/agent_papers_{datetime.now().strftime('%Y%m%d')}.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(report)
    print(f"\n报告已保存至: {output_file}")


if __name__ == '__main__':
    main()
