#!/usr/bin/env python3
"""
Agent Paper Digest v2 - 论文追踪技能
支持手动输入论文列表和自动格式化输出
"""

import re
import json
from datetime import datetime, timedelta
from typing import List, Dict
import sys

# Agent相关关键词
AGENT_KEYWORDS = [
    'agent', 'multi-agent', 'agentic', 'tool use', 'function calling',
    'skill', 'llm agent', 'ai agent', 'autonomous agent',
    'agent framework', 'agent memory', 'agent safety',
    'chain-of-thought', 'reasoning', 'planning', 'tool'
]

# 论文主题分类
CATEGORIES = {
    'skill_evolution': ['skill', 'evolve', 'self-improving', 'autonomous', 'trace'],
    'multi_agent': ['multi-agent', 'collaboration', 'coordination', 'distributed', 'federated'],
    'memory': ['memory', 'retrieval', 'knowledge graph', 'cognitive', 'runtime'],
    'safety': ['safety', 'security', 'alignment', 'robustness', 'trust'],
    'evaluation': ['benchmark', 'evaluation', 'assessment', 'metric', 'test'],
    'application': ['medical', 'healthcare', 'finance', 'coding', 'web', 'diagnosis'],
    'reasoning': ['reasoning', 'chain-of-thought', 'cot', 'inference'],
    'general': []
}


def categorize_paper(paper: Dict) -> str:
    """对论文进行分类"""
    text = (paper.get('title', '') + ' ' + paper.get('summary', '')).lower()
    
    scores = {}
    for category, keywords in CATEGORIES.items():
        if category == 'general':
            continue
        score = sum(1 for kw in keywords if kw in text)
        scores[category] = score
    
    # 返回得分最高的分类
    if scores and max(scores.values()) > 0:
        return max(scores, key=scores.get)
    return 'general'


def generate_one_liner(paper: Dict) -> str:
    """生成一句话摘要"""
    summary = paper.get('summary', '')
    if not summary or summary == "N/A":
        # 从标题推断
        title = paper.get('title', '')
        if 'agent' in title.lower():
            return "Agent相关研究"
        return "暂无摘要"
    
    # 取前100字符，尝试找到完整句子
    sentences = summary.split('. ')
    if sentences:
        first = sentences[0]
        if len(first) > 100:
            first = first[:100] + "..."
        return first + "."
    return summary[:100] + "..."


def is_agent_paper(paper: Dict) -> bool:
    """判断是否为Agent相关论文"""
    text = (paper.get('title', '') + ' ' + paper.get('summary', '')).lower()
    return any(kw in text for kw in AGENT_KEYWORDS)


def format_papers_markdown(papers: List[Dict], days: int, source: str = "arXiv") -> str:
    """格式化为Markdown表格"""
    lines = []
    lines.append(f"# 📚 Agent论文选读 | 近{days}天")
    lines.append("")
    lines.append(f"*生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M')} | 来源: {source}*")
    lines.append("")
    
    # 过滤Agent相关论文
    agent_papers = [p for p in papers if is_agent_paper(p)]
    
    if not agent_papers:
        lines.append("*⚠️ 未找到Agent相关论文*")
        lines.append("")
    else:
        lines.append(f"找到 **{len(agent_papers)}** 篇Agent相关论文")
        lines.append("")
        
        # 按分类分组
        categorized = {}
        for paper in agent_papers:
            cat = categorize_paper(paper)
            if cat not in categorized:
                categorized[cat] = []
            categorized[cat].append(paper)
        
        # 分类标题映射
        cat_names = {
            'skill_evolution': '🔥 技能自进化',
            'multi_agent': '🤝 多智能体系统',
            'memory': '🧠 记忆与认知',
            'safety': '🔒 安全与对齐',
            'evaluation': '📊 评估与基准',
            'application': '🏥 垂直应用',
            'reasoning': '🧩 推理与思维',
            'general': '📄 其他Agent研究'
        }
        
        for cat, cat_papers in sorted(categorized.items(), key=lambda x: -len(x[1])):
            if not cat_papers:
                continue
            
            lines.append(f"## {cat_names.get(cat, cat)} ({len(cat_papers)}篇)")
            lines.append("")
            lines.append("| # | 标题 | 作者 | 时间 | 链接 | 一句话摘要 |")
            lines.append("|---|------|------|------|------|-----------|")
            
            for i, paper in enumerate(cat_papers[:15], 1):  # 每类最多15篇
                title = paper.get('title', 'N/A')
                if len(title) > 45:
                    title = title[:45] + "..."
                
                authors = paper.get('authors', [])
                if authors:
                    author_str = ', '.join(authors[:2])
                    if len(author_str) > 25:
                        author_str = author_str[:25] + "..."
                else:
                    author_str = "N/A"
                
                published = paper.get('published', 'N/A')
                if len(published) > 10:
                    published = published[:10]
                
                url = paper.get('url', 'N/A')
                if url != 'N/A' and 'arxiv.org' in url:
                    link = f"[arXiv]({url})"
                else:
                    link = url if url != 'N/A' else "-"
                
                oneliner = generate_one_liner(paper)
                if len(oneliner) > 50:
                    oneliner = oneliner[:50] + "..."
                
                lines.append(f"| {i} | {title} | {author_str} | {published} | {link} | {oneliner} |")
            
            lines.append("")
    
    lines.append("---")
    lines.append("*🔨 由 Agent Paper Digest 技能生成*")
    
    return '\n'.join(lines)


def parse_paper_from_text(text: str) -> List[Dict]:
    """从文本解析论文列表（支持多种格式）"""
    papers = []
    
    # 尝试匹配arXiv格式: [id] Title - Authors
    pattern = r'\[?(\d{4}\.\d{4,5})\]?\s*[-.\]]?\s*(.+?)(?:\n|$)'
    matches = re.findall(pattern, text)
    
    for arxiv_id, title in matches:
        papers.append({
            'arxiv_id': arxiv_id.strip(),
            'title': title.strip(),
            'url': f'https://arxiv.org/abs/{arxiv_id.strip()}',
            'authors': [],
            'published': datetime.now().strftime('%Y-%m-%d'),
            'summary': ''
        })
    
    return papers


def main():
    """主函数"""
    # 解析参数
    days = 7
    max_results = 30
    
    if len(sys.argv) > 1:
        try:
            days = int(sys.argv[1])
        except ValueError:
            pass
    
    if len(sys.argv) > 2:
        try:
            max_results = int(sys.argv[2])
        except ValueError:
            pass
    
    # 检查是否有标准输入
    import select
    if select.select([sys.stdin], [], [], 0.0)[0]:
        # 从标准输入读取论文列表
        input_text = sys.stdin.read()
        papers = parse_paper_from_text(input_text)
        source = "用户输入"
    else:
        # 使用示例数据（实际使用时替换为真实抓取）
        papers = get_sample_papers()
        source = "示例数据"
    
    # 生成报告
    report = format_papers_markdown(papers, days, source)
    
    # 输出
    print(report)
    
    # 保存到文件
    output_file = f"/Users/jyxc-dz-0100378/.stepclaw/workspace/agent_papers_{datetime.now().strftime('%Y%m%d_%H%M')}.md"
    with open(output_file, 'w', encoding='utf-8') as f:
        f.write(report)
    
    print(f"\n💾 报告已保存至: {output_file}")


def get_sample_papers() -> List[Dict]:
    """获取示例论文列表（用于测试）"""
    return [
        {
            'arxiv_id': '2603.18743',
            'title': 'Memento-Skills: Let Agents Design Agents',
            'authors': ['Huichi Zhou', 'Siyuan Guo', 'Anjie Liu'],
            'url': 'https://arxiv.org/abs/2603.18743',
            'published': '2026-03-19',
            'summary': 'We introduce Memento-Skills, a generalist agent system that autonomously constructs skills through experience.'
        },
        {
            'arxiv_id': '2603.02766',
            'title': 'EvoSkill: Automatic Discovery of Agent Skills',
            'authors': ['Salaheddin Alzubi'],
            'url': 'https://arxiv.org/abs/2603.02766',
            'published': '2026-03-03',
            'summary': 'A self-evolving framework that automatically discovers and refines agent skills through iterative failure analysis.'
        },
        {
            'arxiv_id': '2603.25158',
            'title': 'Trace2Skill: Distill Trajectory-Local Lessons into Transferable Agent Skills',
            'authors': ['Jingwei Ni', 'Yihao Liu', 'Xinpeng Liu'],
            'url': 'https://arxiv.org/abs/2603.25158',
            'published': '2026-03-26',
            'summary': 'A framework that mirrors how human experts author skills by holistically analyzing broad execution experience.'
        },
        {
            'arxiv_id': '2603.25334',
            'title': 'Agentic Trust Coordination for Federated Learning',
            'authors': ['Paul Shepherd'],
            'url': 'https://arxiv.org/abs/2603.25334',
            'published': '2026-03-26',
            'summary': 'A lightweight agentic trust coordination approach for federated learning in industrial networks.'
        },
        {
            'arxiv_id': '2603.25097',
            'title': 'ElephantBroker: Knowledge-Grounded Cognitive Runtime for Trustworthy AI Agents',
            'authors': ['Cristian Lupascu'],
            'url': 'https://arxiv.org/abs/2603.25097',
            'published': '2026-03-26',
            'summary': 'A cognitive runtime that unifies Neo4j knowledge graph with Qdrant vector store for verifiable agent memory.'
        }
    ]


if __name__ == '__main__':
    main()
