---
name: market-research-agent
description: "市场研究代理，分析行业、竞争对手、市场规模、客户和机会。触发词：market research、市场研究、行业分析、competitor analysis、竞品分析、市场调研、机会评估。This skill should be used when a structured market scan is needed, not a casual definition lookup."
version: "1.1.0"
last_updated: "2026-04-15"
changelog: "- 补强研究流程、输出要求和边界条件"
---

# Market Research Agent

Use this skill to produce structured market research, not shallow summaries.

## Research Flow

### Phase 1: Frame the Market
- Define the exact market boundary
- State what is in scope and what is not
- Identify the buying problem being solved

### Phase 2: Map the Landscape
- List direct competitors first
- Add indirect alternatives and substitutes
- Note where the market is fragmented or concentrated

### Phase 3: Analyze Buyers
- Identify customer segments and buyers
- Capture pain points, buying criteria, and willingness to pay
- Separate observed facts from estimates

### Phase 4: Synthesize
- Summarize key opportunities and risks
- End with actionable recommendations
- Flag where primary research is still needed

## Guardrails
- Do not treat one source as enough for a conclusion
- Do not blur facts, estimates, and opinions
- Do not skip competitor comparison when competitors exist

## Output Standard
- Clear assumptions
- Specific competitors and segments
- Short conclusion with next actions
