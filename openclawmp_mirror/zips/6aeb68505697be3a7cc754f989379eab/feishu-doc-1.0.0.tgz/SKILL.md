---
name: feishu-doc
description: "通过飞书开放平台API读写飞书文档（docx）。支持读取、全量写入、追加、创建文档，以及Block级别的列出、更新、删除操作。让 AI 助手可以直接阅读和编辑飞书文档、写周报、操作知识库。触发词：飞书文档、读飞书、写飞书、feishu doc、lark doc。"
---

# 飞书文档读写 (feishu-doc)

## 解决什么问题
AI 助手无法直接读写飞书文档——不能帮你查文档内容、不能帮你写周报、不能操作知识库。

## 工具名
`feishu_doc`，通过 `action` 参数区分动作。

## URL → Token
```
https://xxx.feishu.cn/docx/ABC123def → doc_token = ABC123def
```

## 核心操作

### 读文档
```json
{ "action": "read", "doc_token": "xxx" }
```
返回纯文本 + block 统计。如有表格/图片需进一步用 `list_blocks`。

### 写文档（全量替换）
```json
{ "action": "write", "doc_token": "xxx", "content": "# Markdown内容" }
```
支持 Markdown 标题/列表/代码块/引用/链接/图片。**不支持 Markdown 表格**。

### 追加内容
```json
{ "action": "append", "doc_token": "xxx", "content": "追加内容" }
```

### 创建文档
```json
{ "action": "create", "title": "新文档" }
```
可加 `folder_token` 指定目录。

### 列出所有 Block
```json
{ "action": "list_blocks", "doc_token": "xxx" }
```
获取完整结构化数据（表格、图片等）。

### 更新单个 Block
```json
{ "action": "update_block", "doc_token": "xxx", "block_id": "xxx", "content": "新文本" }
```

### 删除 Block
```json
{ "action": "delete_block", "doc_token": "xxx", "block_id": "xxx" }
```

## 读取流程
1. 先 `read` → 查看返回的 `block_types`
2. 如果有 Table/Image → 再 `list_blocks` 拿完整数据

## 前置条件
- 飞书应用已配置 `appId` + `appSecret`
- 所需权限：`docx:document`, `docx:document:readonly`, `docx:document.block:convert`, `drive:drive`
- 文档需授权给应用（或设为可阅读）
