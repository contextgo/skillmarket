# gog

使用 `gog` 处理 Gmail/日历/云端硬盘/联系人/表格/文档。需要设置 OAuth。

设置（一次性）
- `gog auth credentials /path/to/client_secret.json`
- `gog auth add you@gmail.com --services gmail,calendar,drive,contacts,sheets,docs`
- `gog auth list`

常用命令
- Gmail 搜索：`gog gmail search 'newer_than:7d' --max 10`
- Gmail 发送：`gog gmail send --to a@b.com --subject "Hi" --body "Hello"`
- 日历：`gog calendar events <calendarId> --from <iso> --to <iso>`
- 云端硬盘搜索：`gog drive search "query" --max 10`
- 联系人：`gog contacts list --max 20`
- 表格获取：`gog sheets get <sheetId> "Tab!A1:D10" --json`
- 表格更新：`gog sheets update <sheetId> "Tab!A1:B2" --values-json '[["A","B"],["1","2"]]' --input USER_ENTERED`
- 表格追加：`gog sheets append <sheetId> "Tab!A:C" --values-json '[["x","y","z"]]' --insert INSERT_ROWS`
- 表格清除：`gog sheets clear <sheetId> "Tab!A2:Z"`
- 表格元数据：`gog sheets metadata <sheetId> --json`
- 文档导出：`gog docs export <docId> --format txt --out /tmp/doc.txt`
- 文档显示：`gog docs cat <docId>`

注意事项
- 设置 `GOG_ACCOUNT=you@gmail.com` 以避免重复使用 `--account`。
- 对于脚本编写，优先使用 `--json` 加上 `--no-input`。
- 表格值可以通过 `--values-json`（推荐）或内联行的方式传递。
- 文档支持导出/显示/复制。就地编辑需要使用 Docs API 客户端（不在 gog 中）。
- 发送邮件或创建事件前请确认。