# 浏览器自动化访问技能

## 问题

`web_fetch` 访问某些网站时被 Cloudflare 拦截，返回空白页面或验证码页面。

## 解决方案

使用 OpenClaw 内置的 `browser` 工具访问目标网站，默认无头模式可绕过 Cloudflare 检测。

## 使用方法

### 1. 打开目标网页

```
browser open https://thehackernews.com
```

### 2. 等待页面加载完成

```
browser wait --load networkidle
```

### 3. 获取页面内容

```
browser snapshot
```

### 4. 截取截图

```
browser screenshot --full
```

## 注意事项

- 无需额外安装，OpenClaw 内置 `browser` 工具基于 Playwright
- `browser` 工具默认使用 profile="openclaw"，运行真实浏览器引擎
- 绕过 Cloudflare 靠的是浏览器引擎的 JavaScript 执行能力，而非特殊参数