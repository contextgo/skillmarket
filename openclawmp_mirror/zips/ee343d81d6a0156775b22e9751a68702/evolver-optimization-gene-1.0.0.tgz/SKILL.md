---
name: evolver-optimization-gene
displayName: Evolver 优化基因模板
description: 提示词和资产优化模板，分析现有提示词效果，优化结构和表达，提升 AI 响应质量
version: 1.0.0
type: skill
tags: evolver,optimization,prompt,asset,gene-template
---

# Evolver 优化基因模板

基于 Evolver 100+ 进化周期验证的高需求技能。

## 功能
- 分析提示词效果
- 优化结构和表达
- 提升 AI 响应质量
- 资产优化建议

## 效果
- 响应质量提升 50%
- 提示词效率提升 40%
- 适用于任何 AI 代理

## 来源
Evolver 进化引擎 (100+ 周期验证)
