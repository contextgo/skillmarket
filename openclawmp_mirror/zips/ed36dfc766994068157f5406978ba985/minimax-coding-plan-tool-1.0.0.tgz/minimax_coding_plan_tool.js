#!/usr/bin/env node

/**
 * MiniMax Coding Plan Tool - Multimodal API
 *
 * Provides tools:
 * - minimax_web_search: Web search using MiniMax Coding Plan API
 * - minimax_understand_image: Image understanding using MiniMax VLM API
 * - minimax_generate_image: Image generation using image-01 model
 * - minimax_text_to_speech: Speech synthesis using speech-2.8-hd model
 * - minimax_generate_video: Video generation using MiniMax-Hailuo-2.3 model
 *
 * ⚠️ IMPORTANT: This tool requires a special Coding Plan API Key.
 * Regular MiniMax API keys will NOT work.
 */

const https = require('https');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

// Get API key and host from environment
const API_KEY = process.env.MINIMAX_API_KEY;
// Use api.minimaxi.com (not api.minimax.chat) - this is the correct endpoint for OAuth tokens
const API_HOST = 'api.minimaxi.com';

if (!API_KEY) {
  console.error('⚠️ Note: You need a Coding Plan API Key, not a regular MiniMax API key');
  process.exit(1);
}

/**
 * Make request to MiniMax API
 */
function makeRequest(endpoint, data) {
  return new Promise((resolve, reject) => {
    const url = new URL(endpoint, `https://${API_HOST}`);

    const options = {
      hostname: API_HOST,
      path: url.pathname,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${API_KEY}`
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          const json = JSON.parse(body);
          resolve(json);
        } catch (e) {
          reject(new Error(`Failed to parse response: ${body}`));
        }
      });
    });

    req.on('error', reject);
    req.write(JSON.stringify(data));
    req.end();
  });
}

/**
 * Process image URL - convert local file to base64 if needed
 */
function processImageUrl(imageSource) {
  // If it's an HTTP URL, pass through
  if (imageSource.startsWith('http://') || imageSource.startsWith('https://')) {
    return imageSource;
  }

  // It's a local file - convert to base64
  // Strip @ prefix if present
  let filePath = imageSource.startsWith('@') ? imageSource.slice(1) : imageSource;

  if (!fs.existsSync(filePath)) {
    throw new Error(`File not found: ${filePath}`);
  }

  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.png': 'image/png',
    '.gif': 'image/gif',
    '.webp': 'image/webp'
  };
  const mimeType = mimeTypes[ext];
  if (!mimeType) {
    throw new Error(`Unsupported image type: ${ext || '(no extension)'}. Supported types: .jpg, .jpeg, .png, .gif, .webp`);
  }
  const fileContent = fs.readFileSync(filePath);
  const base64 = fileContent.toString('base64');

  return `data:${mimeType};base64,${base64}`;
}

/**
 * Web Search Tool using Coding Plan API
 */
async function webSearch(query) {
  if (!query || typeof query !== 'string') {
    return { error: 'Missing required parameter: query' };
  }

  try {
    const response = await makeRequest('/v1/coding_plan/search', { q: query });

    if (response.organic) {
      return {
        success: true,
        query: query,
        results: response.organic.map(item => ({
          title: item.title || '',
          link: item.link || item.url || '',
          snippet: item.snippet || item.content || '',
          date: item.date || ''
        })),
        related_searches: response.related_searches || []
      };
    }

    return { success: true, response };
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Understand Image Tool using Coding Plan VLM API
 */
async function understandImage(imageSource, prompt) {
  if (!prompt || typeof prompt !== 'string') {
    return { error: 'Missing required parameter: prompt' };
  }
  if (!imageSource || typeof imageSource !== 'string') {
    return { error: 'Missing required parameter: image_source' };
  }

  try {
    const processedImageUrl = processImageUrl(imageSource);
    const response = await makeRequest('/v1/coding_plan/vlm', {
      prompt: prompt,
      image_url: processedImageUrl
    });

    const content = response.content;
    if (!content) {
      return { error: 'No content returned from VLM API' };
    }

    return {
      success: true,
      prompt: prompt,
      image_source: imageSource,
      analysis: content
    };
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Generate Image using MiniMax image-01 model via Token Plan API
 */
async function generateImage(prompt) {
  if (!prompt || typeof prompt !== 'string') {
    return { error: 'Missing required parameter: prompt' };
  }

  try {
    const response = await makeRequest('/v1/image_generation', {
      model: 'image-01',
      prompt: prompt,
      num_images: 1
    });

    if (response.base_resp && response.base_resp.status_code !== 0) {
      return { error: response.base_resp.status_msg || 'Image generation failed' };
    }

    return {
      success: true,
      prompt: prompt,
      image_urls: response.data ? response.data.image_urls : [],
      job_id: response.id
    };
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Text to Speech using MiniMax speech-2.8-hd model via Token Plan API
 *
 * Requires: text, voice_setting (with voice_id)
 * Available voices: English_expressive_narrator, English_expressive, English_guy, English_woman, British_man, Chinese_CN_female
 */
async function textToSpeech(text, voiceId = 'English_expressive_narrator', speed = 1.0) {
  if (!text || typeof text !== 'string') {
    return { error: 'Missing required parameter: text' };
  }

  try {
    const response = await makeRequest('/v1/t2a_v2', {
      model: 'speech-2.8-hd',
      text: text,
      stream: false,
      voice_setting: {
        voice_id: voiceId,
        speed: speed,
        vol: 1,
        pitch: 0
      },
      audio_setting: {
        sample_rate: 32000,
        bitrate: 128000,
        format: 'mp3',
        channel: 1
      }
    });

    if (response.base_resp && response.base_resp.status_code !== 0) {
      return { error: response.base_resp.status_msg || 'Speech synthesis failed' };
    }

    return {
      success: true,
      text: text,
      audio: response.data ? response.data.audio : null,
      audio_format: response.extra_info ? response.extra_info.audio_format : 'mp3',
      audio_length_ms: response.extra_info ? response.extra_info.audio_length : null,
      job_id: response.trace_id
    };
  } catch (error) {
    return { error: error.message };
  }
}

/**
 * Generate Video using MiniMax-Hailuo-2.3 model via Token Plan API
 *
 * This is async - returns task_id for status polling
 */
async function generateVideo(prompt, duration = 6, resolution = '1080P') {
  if (!prompt || typeof prompt !== 'string') {
    return { error: 'Missing required parameter: prompt' };
  }

  if (!['6', '10'].includes(String(duration))) {
    return { error: 'Duration must be 6 or 10 seconds' };
  }

  if (!['720P', '1080P'].includes(String(resolution))) {
    return { error: 'Resolution must be 720P or 1080P' };
  }

  try {
    const response = await makeRequest('/v1/video_generation', {
      model: 'MiniMax-Hailuo-2.3',
      prompt: prompt,
      duration: parseInt(duration),
      resolution: resolution
    });

    if (response.base_resp && response.base_resp.status_code !== 0) {
      return { error: response.base_resp.status_msg || 'Video generation failed' };
    }

    return {
      success: true,
      prompt: prompt,
      task_id: response.task_id,
      status: 'pending'
    };
  } catch (error) {
    return { error: error.message };
  }
}

// CLI interface
const args = process.argv.slice(2);
const command = args[0];

async function main() {
  if (command === 'web_search') {
    const query = args[1];
    const result = await webSearch(query);
    console.log(JSON.stringify(result, null, 2));
  } else if (command === 'understand_image') {
    const imageSource = args[1];
    const prompt = args.slice(2).join(' ') || 'Describe this image';
    const result = await understandImage(imageSource, prompt);
    console.log(JSON.stringify(result, null, 2));
  } else if (command === 'generate_image') {
    const prompt = args.slice(1).join(' ');
    const result = await generateImage(prompt);
    console.log(JSON.stringify(result, null, 2));
  } else if (command === 'text_to_speech') {
    // Format: text_to_speech "text" [voice_id] [speed]
    const text = args[1];
    const voiceId = args[2] || 'English_expressive_narrator';
    const speed = parseFloat(args[3]) || 1.0;
    const result = await textToSpeech(text, voiceId, speed);
    console.log(JSON.stringify(result, null, 2));
  } else if (command === 'generate_video') {
    // Format: generate_video "prompt" [duration] [resolution]
    const prompt = args.slice(1).join(' ');
    const duration = args[1] && args[2] ? args[2] : 6;
    const resolution = args[1] && args[2] && args[3] ? args[3] : '1080P';
    // Re-parse: args are "prompt", duration, resolution
    const actualPrompt = args.slice(1, args.length - 2).join(' ') || args.slice(1).join(' ');
    const actualDuration = args.length > 2 ? args[args.length - 2] : 6;
    const actualResolution = args.length > 3 ? args[args.length - 1] : '1080P';
    const result = await generateVideo(actualPrompt, actualDuration, actualResolution);
    console.log(JSON.stringify(result, null, 2));
  } else if (command === 'tools') {
    console.log(JSON.stringify({
      tools: [
        {
          name: 'minimax_web_search',
          description: 'Web search using MiniMax Coding Plan API',
          inputSchema: {
            type: 'object',
            properties: {
              query: { type: 'string', description: 'Search query. 3-5 keywords work best' }
            },
            required: ['query']
          }
        },
        {
          name: 'minimax_understand_image',
          description: 'Image understanding using MiniMax Coding Plan VLM API',
          inputSchema: {
            type: 'object',
            properties: {
              image_source: { type: 'string', description: 'Image URL or local file path' },
              prompt: { type: 'string', description: 'Question or analysis request' }
            },
            required: ['image_source', 'prompt']
          }
        },
        {
          name: 'minimax_generate_image',
          description: 'Generate images using MiniMax image-01 model',
          inputSchema: {
            type: 'object',
            properties: {
              prompt: { type: 'string', description: 'Image description' }
            },
            required: ['prompt']
          }
        },
        {
          name: 'minimax_text_to_speech',
          description: 'Text-to-speech using MiniMax speech-2.8-hd model',
          inputSchema: {
            type: 'object',
            properties: {
              text: { type: 'string', description: 'Text to synthesize (English works best)' },
              voice_id: { type: 'string', description: 'Voice ID (default: English_expressive_narrator)' },
              speed: { type: 'number', description: 'Speech speed (default: 1.0)' }
            },
            required: ['text']
          }
        },
        {
          name: 'minimax_generate_video',
          description: 'Video generation using MiniMax-Hailuo-2.3 model (async)',
          inputSchema: {
            type: 'object',
            properties: {
              prompt: { type: 'string', description: 'Video description' },
              duration: { type: 'number', description: 'Duration: 6 or 10 seconds (default: 6)' },
              resolution: { type: 'string', description: 'Resolution: 720P or 1080P (default: 1080P)' }
            },
            required: ['prompt']
          }
        }
      ]
    }, null, 2));
  } else {
    console.error('Usage:');
    console.error('  minimax-coding-plan-tool.js web_search <query>');
    console.error('  minimax-coding-plan-tool.js understand_image <image_source> <prompt>');
    console.error('  minimax-coding-plan-tool.js generate_image <prompt>');
    console.error('  minimax-coding-plan-tool.js text_to_speech <text> [voice_id] [speed]');
    console.error('  minimax-coding-plan-tool.js generate_video <prompt> [duration] [resolution]');
    console.error('  minimax-coding-plan-tool.js tools');
    process.exit(1);
  }
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
