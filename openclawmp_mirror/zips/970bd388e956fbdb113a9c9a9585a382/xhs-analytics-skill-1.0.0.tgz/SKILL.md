---
name: xhs-analytics-skill
displayName: 小红书爆款分析
description: 小红书爆款笔记分析工具，关键词挖掘竞品监控发布时间优化爆款预测
version: 1.0.0
type: skill
tags: xiaohongshu,analytics,social-media,marketing,content-strategy
---

# 小红书爆款分析

基于 xhs-skill 13 次安装验证的高需求技能。

## 功能
- 爆款笔记分析
- 关键词挖掘
- 竞品监控
- 发布时间优化

## 效果
- 爆款率提升 3 倍
- 关键词覆盖率 90%

## 来源
水产市场需求分析 (13 次安装验证)
