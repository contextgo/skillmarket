---
name: weather-query
description: 查询天气信息，支持国内和国际城市。当用户询问天气时自动调用此技能。支持按城市名称查询、扩展气象字段、多天预报、逐小时预报、分钟级降水预报、18项生活指数等功能。
---

# 天气查询技能

查询天气信息，使用 uapis.cn 天气 API。

## 快速开始

### 查询天气

使用 curl 调用天气 API：

```bash
curl "https://uapis.cn/api/v1/misc/weather?city=北京"
```

### 查询参数

- **city**: 城市名称，支持中文（北京）和英文（Tokyo）
- **adcode**: 城市行政区划代码（优先级更高）
- **extended**: 返回扩展气象字段（体感温度、能见度、气压、紫外线、空气质量等）
- **forecast**: 返回多天预报（最多7天）
- **hourly**: 返回逐小时预报（24小时）
- **minutely**: 返回分钟级降水预报（仅国内城市）
- **indices**: 返回18项生活指数
- **lang**: 返回语言（zh 或 en，默认 zh）

### 响应字段

- **province**: 省份
- **city**: 城市名
- **weather**: 天气状况
- **temperature**: 当前温度 °C
- **wind_direction**: 风向
- **wind_power**: 风力等级
- **humidity**: 相对湿度 %
- **report_time**: 数据更新时间

## 使用示例

### 基本查询

查询北京天气：

```bash
curl "https://uapis.cn/api/v1/misc/weather?city=北京"
```

### 扩展查询

查询上海天气，包含扩展字段和7天预报：

```bash
curl "https://uapis.cn/api/v1/misc/weather?city=上海&extended=true&forecast=true"
```

### 生活指数

查询深圳天气，包含18项生活指数：

```bash
curl "https://uapis.cn/api/v1/misc/weather?city=深圳&indices=true"
```

## 常见天气现象

- 晴、多云、阴
- 小雨、中雨、大雨、雷阵雨
- 小雪、中雪、大雪、雨夹雪
- 雾、霾、沙尘

## 18项生活指数

当 `indices=true` 时返回：
- 穿衣指数
- 紫外线指数
- 洗车指数
- 晾晒指数
- 空调开启指数
- 感冒指数
- 运动指数
- 舒适度指数
- 出行指数
- 钓鱼指数
- 过敏指数
- 防晒指数
- 心情指数
- 啤酒指数
- 雨伞指数
- 交通指数
- 空气净化器指数
- 花粉扩散指数
