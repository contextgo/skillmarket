#!/usr/bin/env python3
"""
天气查询脚本
使用 uapis.cn 天气 API 查询天气信息
"""

import requests
import argparse
import json
import sys
from ratelimit import limits, sleep_and_retry
import backoff

BASE_URL = "https://uapis.cn/api/v1/misc/weather"
RATE_LIMIT = 40  # 每分钟最多请求次数
RATE_LIMIT_PERIOD = 60  # 限制周期（秒）

# 请求速率限制：每分钟最多 40 次
@limits(calls=RATE_LIMIT, period=RATE_LIMIT_PERIOD)
@sleep_and_retry
# 429 响应处理：指数退避重试
@backoff.on_exception(backoff.expo,
                      requests.exceptions.HTTPError,
                      giveup=lambda e: e.response is not None and e.response.status_code != 429,
                      max_tries=5)
def query_weather(city=None, adcode=None, extended=False, forecast=False, 
                  hourly=False, minutely=False, indices=False, lang='zh'):
    """
    查询天气信息
    
    Args:
        city: 城市名称
        adcode: 行政区划代码
        extended: 返回扩展气象字段
        forecast: 返回多天预报
        hourly: 返回逐小时预报
        minutely: 返回分钟级降水预报
        indices: 返回18项生活指数
        lang: 返回语言（zh 或 en）
    
    Returns:
        天气信息的 JSON 数据
    """
    params = {}
    
    if city:
        params['city'] = city
    if adcode:
        params['adcode'] = adcode
    if extended:
        params['extended'] = 'true'
    if forecast:
        params['forecast'] = 'true'
    if hourly:
        params['hourly'] = 'true'
    if minutely:
        params['minutely'] = 'true'
    if indices:
        params['indices'] = 'true'
    if lang:
        params['lang'] = lang
    
    try:
        response = requests.get(BASE_URL, params=params, timeout=10)
        # 对于 429 响应，抛出异常以便 backoff 处理
        if response.status_code == 429:
            print(f"请求频率过高，正在等待重试... (第 {sys.getdefaultexc_info()[2].tb_lineno} 行)", file=sys.stderr)
            response.raise_for_status()
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        print(f"查询天气失败: {e}", file=sys.stderr)
        sys.exit(1)

def format_weather(data):
    """
    格式化天气信息输出
    
    Args:
        data: 天气数据
    
    Returns:
        格式化的字符串
    """
    result = []
    
    # 基本信息
    if 'city' in data:
        result.append(f"📍 {data.get('province', '')} {data.get('city', '')}")
    if 'weather' in data:
        result.append(f"🌤️  天气: {data['weather']}")
    if 'temperature' in data:
        result.append(f"🌡️  温度: {data['temperature']}°C")
    if 'feels_like' in data:
        result.append(f"🤒 体感温度: {data['feels_like']}°C")
    if 'humidity' in data:
        result.append(f"💧 湿度: {data['humidity']}%")
    if 'wind_direction' in data and 'wind_power' in data:
        result.append(f"🍃 {data['wind_direction']} {data['wind_power']}")
    if 'report_time' in data:
        result.append(f"⏰ 更新时间: {data['report_time']}")
    
    # 空气质量
    if 'aqi' in data:
        result.append(f"🌬️  空气质量: AQI {data['aqi']} ({data.get('aqi_category', '')})")
    
    # 生活指数
    if 'life_indices' in data:
        indices = data['life_indices']
        if 'clothing' in indices:
            result.append(f"👕 穿衣: {indices['clothing'].get('level', '')} - {indices['clothing'].get('brief', '')}")
        if 'uv' in indices:
            result.append(f"☀️  紫外线: {indices['uv'].get('level', '')}")
        if 'car_wash' in indices:
            result.append(f"🚗 洗车: {indices['car_wash'].get('level', '')}")
        if 'exercise' in indices:
            result.append(f"🏃 运动: {indices['exercise'].get('level', '')}")
        if 'travel' in indices:
            result.append(f"✈️  出行: {indices['travel'].get('level', '')}")
    
    # 多天预报
    if 'forecast' in data and data['forecast']:
        result.append("\n📅 未来预报:")
        for i, day in enumerate(data['forecast'][:3]):  # 只显示前3天
            if 'weather' in day:
                result.append(f"  Day {i+1}: {day['weather']}")
            if 'temp_max' in day and 'temp_min' in day:
                result.append(f"        {day['temp_min']}°C ~ {day['temp_max']}°C")
    
    return '\n'.join(result)

def main():
    parser = argparse.ArgumentParser(description='查询天气信息')
    parser.add_argument('city', nargs='?', help='城市名称')
    parser.add_argument('--adcode', help='行政区划代码')
    parser.add_argument('--extended', action='store_true', help='返回扩展气象字段')
    parser.add_argument('--forecast', action='store_true', help='返回多天预报')
    parser.add_argument('--hourly', action='store_true', help='返回逐小时预报')
    parser.add_argument('--minutely', action='store_true', help='返回分钟级降水预报')
    parser.add_argument('--indices', action='store_true', help='返回18项生活指数')
    parser.add_argument('--lang', default='zh', choices=['zh', 'en'], help='返回语言')
    parser.add_argument('--raw', action='store_true', help='输出原始 JSON')
    
    args = parser.parse_args()
    
    if not args.city and not args.adcode:
        parser.print_help()
        sys.exit(1)
    
    # 查询天气
    data = query_weather(
        city=args.city,
        adcode=args.adcode,
        extended=args.extended,
        forecast=args.forecast,
        hourly=args.hourly,
        minutely=args.minutely,
        indices=args.indices,
        lang=args.lang
    )
    
    # 输出结果
    if args.raw:
        print(json.dumps(data, ensure_ascii=False, indent=2))
    else:
        print(format_weather(data))

if __name__ == '__main__':
    main()
