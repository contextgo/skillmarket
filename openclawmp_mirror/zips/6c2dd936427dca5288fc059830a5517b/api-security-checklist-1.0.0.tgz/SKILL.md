---
name: api-security-checklist
description: API 安全 40+ 项：认证、授权、输入验证、速率限制、数据保护
version: 1.0.0
---

# API 安全检查清单

## 认证
[ ] JWT/OAuth2（不用 Basic Auth）
[ ] Token 过期 <= 15min
[ ] MFA 支持
[ ] 登录限速 5/min
[ ] Token 黑名单

## 授权
[ ] 每个端点有权限检查
[ ] RBAC/ABAC
[ ] 资源级控制
[ ] 敏感操作二次验证

## 输入验证
[ ] 类型+长度+格式
[ ] SQL 注入防护
[ ] XSS 防护
[ ] SSRF 白名单

## 速率限制
[ ] 全局 100/min/IP
[ ] 登录 5/min
[ ] 429 + Retry-After

## 数据保护
[ ] HTTPS/TLS 1.2+
[ ] 密码 bcrypt/argon2
[ ] PII 脱敏
[ ] 响应字段最小化
