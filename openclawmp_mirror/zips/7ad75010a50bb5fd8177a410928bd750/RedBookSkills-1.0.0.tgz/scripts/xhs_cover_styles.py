# -*- coding: utf-8 -*-
"""
xhs_cover_styles.py  v2
------------------------
Generates XHS cover cards matching the user's reference style:
- Clean, flat design with large solid-color backgrounds
- Big bold centered title text, keywords in accent color
- Paper/note-card texture feel with subtle shadow
- Simple geometric illustrations as decoration
- Minimal, 1-2 accent colors, not cluttered

Each call randomly varies: palette, decoration pattern, layout variant.
"""

from PIL import Image, ImageDraw, ImageFont
import os, random, math

W, H = 1080, 1440

LQ = "\u201c"
RQ = "\u201d"

# ============================================================
# Color palettes
# ============================================================
PALETTES = [
    {"bg": "#E8F4FD", "card": "#FFFFFF", "accent": "#2E86DE", "accent2": "#E74C3C", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#FFF3E0", "card": "#FFFDE7", "accent": "#E74C3C", "accent2": "#2E86DE", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#E8F5E9", "card": "#FFFFFF", "accent": "#27AE60", "accent2": "#E67E22", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#F3E5F5", "card": "#FFFFFF", "accent": "#8E24AA", "accent2": "#FF7043", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#E3F2FD", "card": "#FFFFFF", "accent": "#1565C0", "accent2": "#C62828", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#FBE9E7", "card": "#FFFFFF", "accent": "#D84315", "accent2": "#1565C0", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#F1F8E9", "card": "#FFFDE7", "accent": "#558B2F", "accent2": "#E65100", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#FCE4EC", "card": "#FFFFFF", "accent": "#C2185B", "accent2": "#1976D2", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#E0F7FA", "card": "#FFFFFF", "accent": "#00838F", "accent2": "#AD1457", "text": "#1A1A1A", "subtext": "#666666"},
    {"bg": "#FFF8E1", "card": "#FFFFFF", "accent": "#F57F17", "accent2": "#283593", "text": "#1A1A1A", "subtext": "#666666"},
]

# ============================================================
# Helpers
# ============================================================
def get_font(size, bold=False):
    font_paths = [
        r"C:\Windows\Fonts\msyhbd.ttc" if bold else r"C:\Windows\Fonts\msyh.ttc",
        r"C:\Windows\Fonts\simhei.ttf",
    ]
    for fp in font_paths:
        if os.path.exists(fp):
            try:
                return ImageFont.truetype(fp, size)
            except:
                continue
    return ImageFont.load_default()


def hex_to_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


def draw_rounded_rect(draw, xy, radius, fill, outline=None, width=0):
    draw.rounded_rectangle(xy, radius=radius, fill=fill, outline=outline, width=width)


def text_center_x(draw, text, font, y, fill, canvas_w=W):
    """Draw text horizontally centered."""
    bbox = font.getbbox(text)
    tw = bbox[2] - bbox[0]
    x = (canvas_w - tw) // 2
    draw.text((x, y), text, font=font, fill=fill)
    return tw


def draw_shadow_card(img, draw, rect, radius, card_color, shadow_offset=6, shadow_blur_color="#00000018"):
    """Draw a card with subtle shadow underneath."""
    x1, y1, x2, y2 = rect
    # Shadow
    sr = (x1 + shadow_offset, y1 + shadow_offset, x2 + shadow_offset, y2 + shadow_offset)
    draw_rounded_rect(draw, sr, radius, fill=shadow_blur_color)
    # Card
    draw_rounded_rect(draw, rect, radius, fill=card_color)


# ============================================================
# Background decoration patterns (subtle, not overwhelming)
# ============================================================
def deco_dots(draw, bg_color, w, h):
    """Subtle polka dots pattern."""
    r, g, b = hex_to_rgb(bg_color)
    dot_color = f"#{max(r-20,0):02x}{max(g-20,0):02x}{max(b-20,0):02x}"
    spacing = random.choice([60, 80, 100])
    dot_r = random.choice([3, 4, 5])
    for x in range(spacing//2, w, spacing):
        for y in range(spacing//2, h, spacing):
            draw.ellipse((x-dot_r, y-dot_r, x+dot_r, y+dot_r), fill=dot_color)

def deco_grid(draw, bg_color, w, h):
    """Subtle grid lines like notebook paper."""
    r, g, b = hex_to_rgb(bg_color)
    line_color = f"#{max(r-15,0):02x}{max(g-15,0):02x}{max(b-15,0):02x}"
    spacing = random.choice([40, 50, 60])
    for x in range(0, w, spacing):
        draw.line((x, 0, x, h), fill=line_color, width=1)
    for y in range(0, h, spacing):
        draw.line((0, y, w, y), fill=line_color, width=1)

def deco_corner_blocks(draw, accent, accent2, w, h):
    """Small colored rectangles in corners like reference image 2."""
    block_w = random.randint(30, 60)
    block_h = random.randint(80, 150)
    # Top-left
    draw_rounded_rect(draw, (0, 30, block_w, 30+block_h), radius=0, fill=accent)
    draw_rounded_rect(draw, (block_w+8, 50, block_w+8+block_w//2, 50+block_h//2), radius=0, fill=accent2)
    # Bottom-right
    draw_rounded_rect(draw, (w-block_w, h-30-block_h, w, h-30), radius=0, fill=accent)

def deco_none(draw, *args):
    pass

DECO_FUNCS = [deco_dots, deco_grid, deco_corner_blocks, deco_none, deco_none]


# ============================================================
# Simple geometric illustrations (replace cartoon characters)
# ============================================================
def draw_illustration_books(draw, cx, cy, accent, accent2):
    """Simple stack of books illustration."""
    colors = [accent, accent2, "#FFD54F", "#81C784"]
    random.shuffle(colors)
    bw, bh = 180, 28
    for i, c in enumerate(colors[:4]):
        offset_x = random.randint(-15, 15)
        y = cy - i * (bh + 4)
        draw_rounded_rect(draw, (cx - bw//2 + offset_x, y, cx + bw//2 + offset_x, y + bh), radius=6, fill=c)
    # Pencil on top
    py = cy - 4 * (bh + 4) - 10
    draw.line((cx - 60, py, cx + 60, py - 15), fill="#FFB300", width=6)
    draw.polygon([(cx + 60, py - 15), (cx + 75, py - 18), (cx + 65, py - 8)], fill="#E53935")

def draw_illustration_people(draw, cx, cy, accent, accent2):
    """Simple stick-figure style people at desk."""
    # Desk
    draw_rounded_rect(draw, (cx - 140, cy, cx + 140, cy + 16), radius=6, fill="#8D6E63")
    # Desk legs
    draw.line((cx - 120, cy + 16, cx - 120, cy + 70), fill="#6D4C41", width=6)
    draw.line((cx + 120, cy + 16, cx + 120, cy + 70), fill="#6D4C41", width=6)
    # Person 1 (left)
    draw.ellipse((cx - 80, cy - 65, cx - 40, cy - 25), fill=accent)  # head
    draw.line((cx - 60, cy - 25, cx - 60, cy), fill=accent, width=5)  # body
    # Person 2 (right)
    draw.ellipse((cx + 40, cy - 65, cx + 80, cy - 25), fill=accent2)
    draw.line((cx + 60, cy - 25, cx + 60, cy), fill=accent2, width=5)
    # Book on desk
    draw_rounded_rect(draw, (cx - 30, cy - 12, cx + 30, cy), radius=3, fill="#FFF9C4")

def draw_illustration_lightbulb(draw, cx, cy, accent, accent2):
    """Simple lightbulb = idea."""
    # Bulb
    draw.ellipse((cx - 40, cy - 70, cx + 40, cy + 10), fill="#FFF9C4", outline="#FFD54F", width=3)
    # Base
    draw_rounded_rect(draw, (cx - 20, cy + 10, cx + 20, cy + 35), radius=4, fill="#BDBDBD")
    # Rays
    for angle in range(0, 360, 45):
        rad = math.radians(angle)
        x1 = cx + int(50 * math.cos(rad))
        y1 = (cy - 30) + int(50 * math.sin(rad))
        x2 = cx + int(65 * math.cos(rad))
        y2 = (cy - 30) + int(65 * math.sin(rad))
        draw.line((x1, y1, x2, y2), fill="#FFD54F", width=3)

def draw_illustration_star(draw, cx, cy, accent, accent2):
    """Simple star cluster."""
    def star(x, y, size, color):
        pts = []
        for i in range(5):
            a = math.radians(i * 72 - 90)
            pts.append((x + int(size * math.cos(a)), y + int(size * math.sin(a))))
            a2 = math.radians(i * 72 - 90 + 36)
            pts.append((x + int(size * 0.4 * math.cos(a2)), y + int(size * 0.4 * math.sin(a2))))
        draw.polygon(pts, fill=color)
    star(cx, cy, 45, accent)
    star(cx - 70, cy + 30, 25, accent2)
    star(cx + 65, cy - 20, 20, "#FFD54F")

ILLUST_FUNCS = [draw_illustration_books, draw_illustration_people,
                draw_illustration_lightbulb, draw_illustration_star]


# ============================================================
# Layout variants
# ============================================================

def _layout_A(img, draw, pal, title_lines, subtitle_lines, tag_left, tag_right, bottom_text):
    """
    Style A: Big centered title on colored bg + paper card in middle + illustration below.
    Like reference image 1 & 3.
    """
    accent = pal["accent"]
    accent2 = pal["accent2"]
    card_color = pal["card"]
    text_color = pal["text"]
    sub_color = pal["subtext"]

    # Tag at top center
    if tag_left:
        f_tag = get_font(26, bold=True)
        bbox = f_tag.getbbox(tag_left)
        tw = bbox[2] - bbox[0]
        tag_x = (W - tw - 40) // 2
        draw_rounded_rect(draw, (tag_x, 55, tag_x + tw + 40, 100), radius=20, fill=accent)
        draw.text((tag_x + 20, 62), tag_left, font=f_tag, fill="#FFFFFF")

    # Title lines - big, centered, keyword in accent color
    f_title = get_font(60, bold=True)
    y = 160
    for i, (text, is_accent) in enumerate(title_lines):
        color = accent if is_accent else text_color
        text_center_x(draw, text, f_title, y, color)
        y += 85

    # Paper card with subtitle
    card_top = y + 30
    card_bottom = card_top + len(subtitle_lines) * 55 + 50
    draw_shadow_card(img, draw, (100, card_top, W - 100, card_bottom), 20, card_color)

    f_sub = get_font(30)
    sy = card_top + 25
    for line in subtitle_lines:
        text_center_x(draw, line, f_sub, sy, sub_color)
        sy += 55

    # Illustration in lower area
    illust_func = random.choice(ILLUST_FUNCS)
    illust_cy = card_bottom + 200
    if illust_cy > H - 250:
        illust_cy = H - 250
    illust_func(draw, W // 2, illust_cy, accent, accent2)

    # Date tag (small, top right area)
    if tag_right:
        f_date = get_font(22, bold=True)
        bbox = f_date.getbbox(tag_right)
        tw = bbox[2] - bbox[0]
        draw_rounded_rect(draw, (W - tw - 60, 60, W - 20, 98), radius=16, fill=accent + "30")
        draw.text((W - tw - 40, 68), tag_right, font=f_date, fill=accent)

    # Bottom text
    if bottom_text:
        f_bot = get_font(24)
        text_center_x(draw, bottom_text, f_bot, H - 80, sub_color)


def _layout_B(img, draw, pal, title_lines, subtitle_lines, tag_left, tag_right, bottom_text):
    """
    Style B: Note-card / paper style with grid bg.
    Like reference image 2 (the "qingshu" one).
    """
    accent = pal["accent"]
    accent2 = pal["accent2"]
    card_color = pal["card"]
    text_color = pal["text"]
    sub_color = pal["subtext"]

    # Corner color blocks
    deco_corner_blocks(draw, accent, accent2, W, H)

    # Large centered paper card
    card_margin = 80
    card_rect = (card_margin, 120, W - card_margin, H - 120)
    draw_shadow_card(img, draw, card_rect, 24, card_color, shadow_offset=8)

    # Small colored line at top of card
    line_y = 155
    draw_rounded_rect(draw, (card_margin + 40, line_y, W - card_margin - 40, line_y + 4), radius=2, fill=accent)

    # Title inside card
    f_small = get_font(32)
    f_big = get_font(62, bold=True)

    y = 200
    for i, (text, is_accent) in enumerate(title_lines):
        font = f_big if is_accent else f_small
        color = accent if is_accent else text_color
        text_center_x(draw, text, font, y, color)
        y += 90 if is_accent else 55

    # Circle highlight on a keyword (like the red circle on "qingshu")
    # Draw a circle around approximate position
    circle_y = 200 + 55  # around second line
    draw.ellipse((W//2 - 100, circle_y - 10, W//2 + 100, circle_y + 75),
                 outline=accent2, width=3)

    # Subtitle
    f_sub = get_font(28)
    y += 30
    for line in subtitle_lines:
        text_center_x(draw, line, f_sub, y, sub_color)
        y += 50

    # Illustration
    illust_func = random.choice(ILLUST_FUNCS)
    illust_cy = min(y + 180, H - 280)
    illust_func(draw, W // 2, illust_cy, accent, accent2)

    # Tag at bottom of card
    if tag_left:
        f_tag = get_font(22, bold=True)
        bbox = f_tag.getbbox(tag_left)
        tw = bbox[2] - bbox[0]
        draw_rounded_rect(draw, (W//2 - tw//2 - 20, H - 200, W//2 + tw//2 + 20, H - 160),
                          radius=14, fill=accent)
        draw.text((W//2 - tw//2, H - 195), tag_left, font=f_tag, fill="#FFFFFF")

    if bottom_text:
        f_bot = get_font(22)
        text_center_x(draw, bottom_text, f_bot, H - 145, sub_color)


def _layout_C(img, draw, pal, title_lines, subtitle_lines, tag_left, tag_right, bottom_text):
    """
    Style C: Full-color top half + white bottom half.
    Title on colored area, details on white area.
    """
    accent = pal["accent"]
    accent2 = pal["accent2"]
    card_color = pal["card"]
    text_color = pal["text"]
    sub_color = pal["subtext"]

    # Top colored area
    split_y = random.randint(580, 680)
    draw_rounded_rect(draw, (0, 0, W, split_y), radius=0, fill=accent)

    # Tag
    if tag_left:
        f_tag = get_font(24, bold=True)
        bbox = f_tag.getbbox(tag_left)
        tw = bbox[2] - bbox[0]
        draw_rounded_rect(draw, (60, 55, 60 + tw + 36, 95), radius=18, fill="#FFFFFF30")
        draw.text((78, 62), tag_left, font=f_tag, fill="#FFFFFF")

    if tag_right:
        f_date = get_font(22, bold=True)
        draw.text((W - 180, 65), tag_right, font=f_date, fill="#FFFFFFCC")

    # Title on colored area (white text)
    f_title = get_font(58, bold=True)
    y = 150
    for text, is_accent in title_lines:
        color = "#FFFFFF" if not is_accent else accent2
        # For accent on dark bg, use lighter version
        if is_accent:
            r, g, b = hex_to_rgb(accent2)
            color = f"#{min(r+80,255):02x}{min(g+80,255):02x}{min(b+80,255):02x}"
        text_center_x(draw, text, f_title, y, color)
        y += 85

    # Subtitle on colored area
    f_sub = get_font(28)
    y += 20
    for line in subtitle_lines:
        text_center_x(draw, line, f_sub, y, "#FFFFFFBB")
        y += 48

    # White bottom area with illustration
    draw_rounded_rect(draw, (0, split_y - 30, W, H), radius=30, fill=card_color)

    illust_func = random.choice(ILLUST_FUNCS)
    illust_func(draw, W // 2, split_y + 180, accent, accent2)

    # Bottom text
    if bottom_text:
        f_bot = get_font(24)
        text_center_x(draw, bottom_text, f_bot, H - 80, sub_color)


LAYOUT_FUNCS = [_layout_A, _layout_B, _layout_C]


# ============================================================
# Main entry point
# ============================================================
def generate_cover(
    title_lines=None,
    subtitle_lines=None,
    tag_left="",
    tag_right="",
    bottom_text="",
    out_path="cover.png",
    force_palette=None,
    force_layout=None,
    force_deco=None,
):
    """
    Generate a cover card.

    title_lines: list of (text, is_accent_bool)
        e.g. [("3月了还没上岸?", False), ("重庆xsc家长", True), ("别慌! 看这篇", False)]
    subtitle_lines: list of str
    """
    if title_lines is None:
        title_lines = [("标题文字", False)]
    if subtitle_lines is None:
        subtitle_lines = []

    pal = force_palette if force_palette else random.choice(PALETTES)
    layout_func = force_layout if force_layout else random.choice(LAYOUT_FUNCS)
    deco_func = force_deco if force_deco else random.choice(DECO_FUNCS)

    img = Image.new("RGB", (W, H), pal["bg"])
    draw = ImageDraw.Draw(img)

    # Background decoration
    if deco_func in (deco_dots, deco_grid):
        deco_func(draw, pal["bg"], W, H)
    elif deco_func == deco_corner_blocks:
        deco_func(draw, pal["accent"], pal["accent2"], W, H)

    # Layout
    layout_func(img, draw, pal, title_lines, subtitle_lines, tag_left, tag_right, bottom_text)

    img.save(out_path, quality=95)
    layout_name = getattr(layout_func, '__name__', 'unknown')
    deco_name = getattr(deco_func, '__name__', 'unknown')
    print(f"Cover saved: {out_path}  [accent={pal['accent']}, layout={layout_name}, deco={deco_name}]")
    return out_path


# ============================================================
# Test: generate 6 variants
# ============================================================
if __name__ == "__main__":
    out_dir = r"G:\jieyueAI\文件存储\xhs_cover_test2"
    os.makedirs(out_dir, exist_ok=True)

    for i in range(6):
        generate_cover(
            title_lines=[
                ("3\u6708\u4e86\u8fd8\u6ca1\u4e0a\u5cb8?", False),
                ("\u91cd\u5e86xsc\u5bb6\u957f", True),
                ("\u522b\u6170! \u770b\u8fd9\u7bc7\u5c31\u591f\u4e86", False),
            ],
            subtitle_lines=[
                "\u5e02\u6559\u59d4\u6700\u65b0\u653f\u7b56\u89e3\u8bfb + \u5b9e\u64cd\u6307\u5357",
                "\u5e2e\u4f60\u7406\u6e053\u6708\u8be5\u505a\u4ec0\u4e48",
            ],
            tag_left="\u91cd\u5e86\u5c0f\u5347\u521d",
            tag_right="2026.03",
            bottom_text="\u5de6\u6ed1\u67e5\u770b\u8be6\u7ec6\u5185\u5bb9  |  \u8bc4\u8bba\u533a\u804a\u804a\u4f60\u5bb6\u60c5\u51b5",
            out_path=os.path.join(out_dir, f"cover_v{i+1}.png"),
        )

    print(f"\n6 variants saved to: {out_dir}")
