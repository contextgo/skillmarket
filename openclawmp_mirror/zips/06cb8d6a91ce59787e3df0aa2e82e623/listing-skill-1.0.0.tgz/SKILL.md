---
name: listing-skill
description: "基于 A9+COSMO+Rufus 三算法的亚马逊 Listing 生成工具，7步流程指导用户准备资料，生成高转化 Listing"
version: 1.0.0
type: skill
tags: amazon, listing, ecommerce, a9, cosmo, rufus, aeo
---

# Listing Skill - 亚马逊 Listing 智能生成

基于亚马逊 A9 + COSMO + Rufus 三算法优化的 Listing 生成工具。

## 核心能力

指导用户按流程准备 4 个关键文件，生成符合 AEO (Answer Engine Optimization) 逻辑的亚马逊 Listing。

## 使用流程

### 第一步：理解底层逻辑

向用户解释三个算法的作用：
- **A9/A10**：解决「搜得到」—— 关键词匹配
- **COSMO**：解决「搜的人是不是对的人」—— 场景+意图理解
- **Rufus**：解决「买不买你」—— 事实数据驱动

### 第二步：准备知识库（一次性）

询问用户是否有 `amazon_compliance_blacklist.txt` 文件：
- 如果没有，提供标准模板
- 指导用户上传到知识库

### 第三步：收集项目输入文件（每次生成）

引导用户提供以下 4 个文件：

| 文件 | 作用 | 获取方式 |
|-----|------|---------|
| **本品属性表.txt** | Rufus 事实源 | 1688/供应商产品参数 |
| **竞品意图分析.txt** | COSMO 场景源 | 2-3个头部竞品 Listing + Review |
| **ABA关键词数据.csv** | A9 流量源 | 亚马逊后台或卖家精灵/H10 |
| **竞品出单词报告.csv** | 流量补充 | 反查竞品流量词 |

### 第四步：生成 Listing

使用融合三智能体逻辑的 Prompt 生成：
- Title（标题）
- Bullet Points（五点描述）
- Product Description（产品描述）
- Search Terms（搜索词）

## 交互模式

采用「分阶段对话」方式，每完成一步再进入下一步，不一次性要求所有资料。

## 输出标准

生成的 Listing 必须同时满足：
- ✅ A9：关键词自然埋入
- ✅ COSMO：场景化描述，有人群词
- ✅ Rufus：事实数据，无空洞形容词
