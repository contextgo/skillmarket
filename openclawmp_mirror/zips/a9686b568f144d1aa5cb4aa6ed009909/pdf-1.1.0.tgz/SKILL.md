---
name: pdf
version: "1.1.0"
last_updated: "2026-04-10"
changelog: "- added MinerU for advanced document extraction"
description: Comprehensive PDF manipulation toolkit for extracting text and tables, creating new PDFs, merging/splitting documents, and handling forms. Includes MinerU integration for high-quality extraction of complex documents (books, papers with formulas/tables).
license: Proprietary. LICENSE.txt has complete terms
---

# PDF Processing Guide

## Overview

This guide covers essential PDF processing operations using Python libraries and command-line tools. For advanced features, JavaScript libraries, and detailed examples, see reference.md. If you need to fill out a PDF form, read forms.md and follow its instructions.

## 选择正确的提取方案

| 文档类型 | 推荐方案 |
|---------|---------|
| 简单文档（文本PDF） | pdfplumber（现有） |
| **复杂文档（书籍/论文/报告）** | **MinerU（新增）** |
| 扫描件 | MinerU（自动OCR） |

**何时使用MinerU**：
- 书籍、论文、报告需要结构化提取
- 包含公式、表格、多栏排版
- 需要保留文档结构（标题层级、段落）
- 扫描件或图片型PDF

## Quick Start

```python
from pypdf import PdfReader, PdfWriter

# Read a PDF
reader = PdfReader("document.pdf")
print(f"Pages: {len(reader.pages)}")

# Extract text
text = ""
for page in reader.pages:
    text += page.extract_text()
```

## Python Libraries

### pypdf - Basic Operations

#### Merge PDFs
```python
from pypdf import PdfWriter, PdfReader

writer = PdfWriter()
for pdf_file in ["doc1.pdf", "doc2.pdf", "doc3.pdf"]:
    reader = PdfReader(pdf_file)
    for page in reader.pages:
        writer.add_page(page)

with open("merged.pdf", "wb") as output:
    writer.write(output)
```

#### Split PDF
```python
reader = PdfReader("input.pdf")
for i, page in enumerate(reader.pages):
    writer = PdfWriter()
    writer.add_page(page)
    with open(f"page_{i+1}.pdf", "wb") as output:
        writer.write(output)
```

#### Extract Metadata
```python
reader = PdfReader("document.pdf")
meta = reader.metadata
print(f"Title: {meta.title}")
print(f"Author: {meta.author}")
print(f"Subject: {meta.subject}")
print(f"Creator: {meta.creator}")
```

#### Rotate Pages
```python
reader = PdfReader("input.pdf")
writer = PdfWriter()

page = reader.pages[0]
page.rotate(90)  # Rotate 90 degrees clockwise
writer.add_page(page)

with open("rotated.pdf", "wb") as output:
    writer.write(output)
```

### pdfplumber - Text and Table Extraction

#### Extract Text with Layout
```python
import pdfplumber

with pdfplumber.open("document.pdf") as pdf:
    for page in pdf.pages:
        text = page.extract_text()
        print(text)
```

#### Extract Tables
```python
with pdfplumber.open("document.pdf") as pdf:
    for i, page in enumerate(pdf.pages):
        tables = page.extract_tables()
        for j, table in enumerate(tables):
            print(f"Table {j+1} on page {i+1}:")
            for row in table:
                print(row)
```

#### Advanced Table Extraction
```python
import pandas as pd

with pdfplumber.open("document.pdf") as pdf:
    all_tables = []
    for page in pdf.pages:
        tables = page.extract_tables()
        for table in tables:
            if table:  # Check if table is not empty
                df = pd.DataFrame(table[1:], columns=table[0])
                all_tables.append(df)

# Combine all tables
if all_tables:
    combined_df = pd.concat(all_tables, ignore_index=True)
    combined_df.to_excel("extracted_tables.xlsx", index=False)
```

### reportlab - Create PDFs

#### Basic PDF Creation
```python
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas

c = canvas.Canvas("hello.pdf", pagesize=letter)
width, height = letter

# Add text
c.drawString(100, height - 100, "Hello World!")
c.drawString(100, height - 120, "This is a PDF created with reportlab")

# Add a line
c.line(100, height - 140, 400, height - 140)

# Save
c.save()
```

#### Create PDF with Multiple Pages
```python
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet

doc = SimpleDocTemplate("report.pdf", pagesize=letter)
styles = getSampleStyleSheet()
story = []

# Add content
title = Paragraph("Report Title", styles['Title'])
story.append(title)
story.append(Spacer(1, 12))

body = Paragraph("This is the body of the report. " * 20, styles['Normal'])
story.append(body)
story.append(PageBreak())

# Page 2
story.append(Paragraph("Page 2", styles['Heading1']))
story.append(Paragraph("Content for page 2", styles['Normal']))

# Build PDF
doc.build(story)
```

## Command-Line Tools

### pdftotext (poppler-utils)
```bash
# Extract text
pdftotext input.pdf output.txt

# Extract text preserving layout
pdftotext -layout input.pdf output.txt

# Extract specific pages
pdftotext -f 1 -l 5 input.pdf output.txt  # Pages 1-5
```

### qpdf
```bash
# Merge PDFs
qpdf --empty --pages file1.pdf file2.pdf -- merged.pdf

# Split pages
qpdf input.pdf --pages . 1-5 -- pages1-5.pdf
qpdf input.pdf --pages . 6-10 -- pages6-10.pdf

# Rotate pages
qpdf input.pdf output.pdf --rotate=+90:1  # Rotate page 1 by 90 degrees

# Remove password
qpdf --password=mypassword --decrypt encrypted.pdf decrypted.pdf
```

### pdftk (if available)
```bash
# Merge
pdftk file1.pdf file2.pdf cat output merged.pdf

# Split
pdftk input.pdf burst

# Rotate
pdftk input.pdf rotate 1east output rotated.pdf
```

## Common Tasks

### Extract Text from Scanned PDFs
```python
# Requires: pip install pytesseract pdf2image
import pytesseract
from pdf2image import convert_from_path

# Convert PDF to images
images = convert_from_path('scanned.pdf')

# OCR each page
text = ""
for i, image in enumerate(images):
    text += f"Page {i+1}:\n"
    text += pytesseract.image_to_string(image)
    text += "\n\n"

print(text)
```

### Add Watermark
```python
from pypdf import PdfReader, PdfWriter

# Create watermark (or load existing)
watermark = PdfReader("watermark.pdf").pages[0]

# Apply to all pages
reader = PdfReader("document.pdf")
writer = PdfWriter()

for page in reader.pages:
    page.merge_page(watermark)
    writer.add_page(page)

with open("watermarked.pdf", "wb") as output:
    writer.write(output)
```

### Extract Images
```bash
# Using pdfimages (poppler-utils)
pdfimages -j input.pdf output_prefix

# This extracts all images as output_prefix-000.jpg, output_prefix-001.jpg, etc.
```

### Password Protection
```python
from pypdf import PdfReader, PdfWriter

reader = PdfReader("input.pdf")
writer = PdfWriter()

for page in reader.pages:
    writer.add_page(page)

# Add password
writer.encrypt("userpassword", "ownerpassword")

with open("encrypted.pdf", "wb") as output:
    writer.write(output)
```

## MinerU - 高级文档提取

MinerU是上海人工智能实验室开源的文档解析工具，擅长从复杂PDF（书籍、论文、报告）中高质量提取内容。

### 安装 MinerU

```bash
# 创建Python 3.12环境
conda create -n mineru 'python=3.12' -y
conda activate mineru

# 安装magic-pdf
pip install -U "magic-pdf[full]" -i https://pypi.tuna.tsinghua.edu.cn/simple

# 安装modelscope用于下载模型
pip install modelscope

# 下载模型权重
wget https://gcore.jsdelivr.net/gh/opendatalab/MinerU@master/scripts/download_models.py -O download_models.py
python download_models.py
```

### 使用 MinerU 提取 PDF

```python
import os

from magic_pdf.data.data_reader_writer import FileBasedDataWriter, FileBasedDataReader
from magic_pdf.data.dataset import PymuDocDataset
from magic_pdf.model.doc_analyze_by_custom_model import doc_analyze
from magic_pdf.config.enums import SupportedPdfParseMethod

# PDF文件路径
pdf_file_path = "input.pdf"
pdf_name = os.path.splitext(os.path.basename(pdf_file_path))[0]

# 输出目录
output_dir = os.path.dirname(pdf_file_path)
image_dir = os.path.join(output_dir, f"{pdf_name}_images")

# 创建输出目录
os.makedirs(image_dir, exist_ok=True)

# 初始化读写器
reader_pdf = FileBasedDataReader("")
writer_image = FileBasedDataWriter(image_dir)

# 读取PDF
bytes_pdf = reader_pdf.read(pdf_file_path)
dataset_pdf = PymuDocDataset(bytes_pdf)

# 判断是否需要OCR并处理
if dataset_pdf.classify() == SupportedPdfParseMethod.OCR:
    # 扫描件或图片型PDF
    infer_result = dataset_pdf.apply(doc_analyze, ocr=True)
    pipe_result = infer_result.pipe_ocr_mode(writer_image)
else:
    # 文本型PDF
    infer_result = dataset_pdf.apply(doc_analyze, ocr=False)
    pipe_result = infer_result.pipe_txt_mode(writer_image)

# 获取Markdown内容
markdown_content = pipe_result.get_markdown(image_dir)
print(markdown_content[:1000])  # 打印前1000字符

# 保存Markdown文件
md_path = os.path.join(output_dir, f"{pdf_name}.md")
pipe_result.dump_md(FileBasedDataWriter(output_dir), f"{pdf_name}.md", image_dir)

# 保存内容列表（JSON）
pipe_result.dump_content_list(
    FileBasedDataWriter(output_dir), 
    f"{pdf_name}_content_list.json", 
    image_dir
)

# 保存中间格式（含位置信息）
pipe_result.dump_middle_json(
    FileBasedDataWriter(output_dir), 
    f"{pdf_name}_middle.json"
)

print(f"✅ 提取完成！")
print(f"  - Markdown: {md_path}")
print(f"  - 图片目录: {image_dir}")
```

### MinerU 输出格式

| 输出类型 | 说明 | 适用场景 |
|---------|------|---------|
| **Markdown** | 带结构（标题、段落、列表）+ 图片引用 | RAG、知识库 |
| **content_list.json** | 按阅读顺序的内容列表（含type/text/img_path） | 精细化处理 |
| **middle.json** | 包含位置信息的中间格式 | 需要坐标的场景 |

### MinerU 特色功能

```python
# 生成可视化文件（用于质检）
infer_result.draw_model(pdf_file_path)  # 布局可视化
pipe_result.draw_layout(f"{pdf_name}_layout.pdf")  # 布局标注PDF
pipe_result.draw_span(f"{pdf_name}_spans.pdf")    # 文本行标注PDF
```

- **公式 → LaTeX**：自动识别并转换为LaTeX格式
- **表格 → HTML**：保持表格结构
- **图片提取**：自动提取并保存，Markdown中用相对路径引用
- **OCR**：109种语言支持，自动检测扫描件

### 命令行使用（简化版）

```bash
# 方式1：使用在线API（需注册 https://mineru.net）
# 方式2：本地部署（推荐生产环境）

# 批量处理脚本示例
#!/bin/bash
for pdf in *.pdf; do
    python mineru_extract.py "$pdf"
done
```

## Quick Reference

| Task | Best Tool | Command/Code |
|------|-----------|--------------|
| Merge PDFs | pypdf | `writer.add_page(page)` |
| Split PDFs | pypdf | One page per file |
| Extract text (simple) | pdfplumber | `page.extract_text()` |
| Extract tables (simple) | pdfplumber | `page.extract_tables()` |
| **Extract complex PDF** | **MinerU** | `PymuDocDataset + pipe_xxx_mode()` |
| **PDF with formulas** | **MinerU** | Auto LaTeX conversion |
| **PDF with tables** | **MinerU** | Auto HTML conversion |
| **Scanned PDF OCR** | **MinerU** | Auto detect + OCR |
| Create PDFs | reportlab | Canvas or Platypus |
| Command line merge | qpdf | `qpdf --empty --pages ...` |
| OCR scanned PDFs | pytesseract | Convert to image first |
| Fill PDF forms | pdf-lib or pypdf (see forms.md) | See forms.md |

## Next Steps

- For advanced pypdfium2 usage, see reference.md
- For JavaScript libraries (pdf-lib), see reference.md
- If you need to fill out a PDF form, follow the instructions in forms.md
- For troubleshooting guides, see reference.md
