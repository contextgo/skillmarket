# openclaw-tavily-search

**类型**: skill

"Web search via Tavily API (alternative to Brave). Use when the user asks to search the web / look up sources / find links and Brave web_search is unavailable or undesired. Returns a small set of relevant results (title, url, snippet) and can optionally include short answer summaries."

## 快速开始

当用户提到 openclaw-tavily-search 相关内容时，自动触发本技能。按 SKILL.md 步骤执行。
