# 🦞 主虾统筹框架：一只主虾带一群分支虾

大任务一只虾扛不住。主虾负责拆活、派活、验收，分支虾各领一摊干到底。

---

## 角色定义

### 主虾（Orchestrator）

- 唯一与用户直接对话的 Agent
- 负责：任务拆解、分派、进度追踪、质量验收、结果汇总
- 不直接执行具体工作（除非子任务极其简单）
- 持有全局任务图和所有分支虾的状态

### 分支虾（Worker）

- 由主虾 spawn，接受单一明确任务
- 独立上下文，独立工作目录
- 完成后只回传结构化结果摘要
- 不与其他分支虾直接通信（一切通过主虾中转）
- 不接触主虾的 MEMORY.md 和 Skills

### 质检虾（Reviewer）— 可选角色

- 独立于执行链的验证 Agent
- 不看分支虾的推理过程，只看产出物
- 用于打断幻觉放大链
- 高风险任务必须启用

---

## 运作机制

### 完整生命周期

```
用户提需求
  ↓
主虾：需求分析
  ↓
主虾：任务拆解 → 生成任务图（task-graph.json）
  ↓
主虾：依赖分析 → 标记可并行任务
  ↓
主虾：分派第一批无依赖任务 → spawn 分支虾
  ↓
分支虾：独立执行 → 回传结果摘要
  ↓
主虾：验收结果
  ├─ 通过 → 更新任务图 → 检查是否解锁下游任务 → 继续分派
  ├─ 需修改 → steer 分支虾补充指令 / 重新 spawn
  └─ 失败 → 记录失败原因 → 决定重试或调整方案
  ↓
所有任务完成
  ↓
主虾：汇总结果 → 生成交付物 → 回复用户
  ↓
主虾：归档任务图和执行记录
```

---

## 第一章：任务拆解

### 1.1 拆解原则

```
好的拆解：
✅ 每个子任务有明确的输入和输出
✅ 子任务之间通过文件/数据传递，不靠口头约定
✅ 每个子任务可以独立验证（有测试或检查标准）
✅ 粒度适中：一个分支虾在 1 个 session 内能完成

坏的拆解：
❌ 子任务描述模糊："把这部分做好"
❌ 子任务之间循环依赖：A 等 B，B 等 A
❌ 粒度太细：协调消息比实际工作还多
❌ 粒度太粗：一个分支虾要跑好几个 session
```

### 1.2 任务图规范

主虾在开始工作前，必须先生成 `task-graph.json`：

```json
{
  "project": "电商后台重构",
  "created_at": "2026-03-25T17:00:00+08:00",
  "status": "in_progress",
  "tasks": [
    {
      "id": "T1",
      "title": "数据库 Schema 设计",
      "description": "根据需求文档设计新的数据库表结构，输出 SQL DDL 文件",
      "assignee": null,
      "deps": [],
      "status": "pending",
      "priority": "critical",
      "input": ["docs/requirements.md"],
      "output": ["db/schema.sql", "db/migration.sql"],
      "acceptance": "SQL 可执行，覆盖所有实体和关系，有索引设计",
      "max_retries": 2,
      "retries": 0
    },
    {
      "id": "T2",
      "title": "用户模块 API",
      "description": "实现用户注册、登录、权限管理的 RESTful API",
      "assignee": null,
      "deps": ["T1"],
      "status": "blocked",
      "priority": "high",
      "input": ["db/schema.sql", "docs/api-spec.md"],
      "output": ["src/api/user/", "tests/api/user/"],
      "acceptance": "所有接口有单元测试且通过，符合 API 规范文档",
      "max_retries": 2,
      "retries": 0
    },
    {
      "id": "T3",
      "title": "商品模块 API",
      "description": "实现商品 CRUD、分类管理、搜索的 RESTful API",
      "assignee": null,
      "deps": ["T1"],
      "status": "blocked",
      "priority": "high",
      "input": ["db/schema.sql", "docs/api-spec.md"],
      "output": ["src/api/product/", "tests/api/product/"],
      "acceptance": "所有接口有单元测试且通过，搜索支持分页",
      "max_retries": 2,
      "retries": 0
    },
    {
      "id": "T4",
      "title": "订单模块 API",
      "description": "实现下单、支付、退款流程的 API",
      "assignee": null,
      "deps": ["T2", "T3"],
      "status": "blocked",
      "priority": "high",
      "input": ["src/api/user/", "src/api/product/", "docs/api-spec.md"],
      "output": ["src/api/order/", "tests/api/order/"],
      "acceptance": "订单状态机正确，并发下单有锁，测试通过",
      "max_retries": 3,
      "retries": 0
    },
    {
      "id": "T5",
      "title": "集成测试",
      "description": "编写端到端集成测试，覆盖核心业务流程",
      "assignee": null,
      "deps": ["T2", "T3", "T4"],
      "status": "blocked",
      "priority": "critical",
      "input": ["src/api/"],
      "output": ["tests/integration/"],
      "acceptance": "覆盖注册→登录→浏览商品→下单→支付完整链路",
      "max_retries": 2,
      "retries": 0
    },
    {
      "id": "T6",
      "title": "API 文档生成",
      "description": "基于代码注释自动生成 OpenAPI 文档",
      "assignee": null,
      "deps": ["T2", "T3", "T4"],
      "status": "blocked",
      "priority": "medium",
      "input": ["src/api/"],
      "output": ["docs/openapi.yaml"],
      "acceptance": "Swagger UI 可正常渲染，所有接口有描述和示例",
      "max_retries": 1,
      "retries": 0
    }
  ],
  "execution_log": []
}
```

### 1.3 依赖分析与并行识别

```
任务依赖图（DAG）：

T1（Schema 设计）
├── T2（用户 API）──┐
├── T3（商品 API）──┼── T4（订单 API）──┬── T5（集成测试）
                    └──────────────────┴── T6（API 文档）

可并行批次：
  批次 1: [T1]           — 无依赖，立即开始
  批次 2: [T2, T3]       — T1 完成后，可并行
  批次 3: [T4]           — T2+T3 都完成后
  批次 4: [T5, T6]       — T4 完成后，可并行
```

---

## 第二章：分支虾分派

### 2.1 Spawn 指令模板

主虾分派分支虾时，必须包含以下完整信息：

```javascript
sessions_spawn({
  task: `
## 任务
${task.title}

## 任务描述
${task.description}

## 输入文件
${task.input.join('\n')}
请先读取以上文件了解上下文。

## 输出要求
${task.output.join('\n')}
所有输出文件必须写入以上路径。

## 验收标准
${task.acceptance}

## 约束
- 只修改输出路径内的文件，不要动其他目录
- 完成后运行测试，确认通过再报告
- 如果发现需求文档有歧义，列出你的假设，不要自行猜测
- 遇到无法解决的问题，明确说明卡在哪里
`,
  mode: "run",
  runtime: "subagent",
  label: `worker-${task.id.toLowerCase()}`
})
```

### 2.2 分支虾系统提示（最小化）

分支虾只收到三节内容：

```markdown
## 身份
你是一只分支虾（Worker Agent），负责执行主虾分派的单一任务。

## 行为约束
- 只做被分派的任务，不要主动扩展范围
- 输出文件写到指定路径
- 完成后提供结构化结果摘要
- 遇到阻塞及时报告，不要死循环重试

## 结果报告格式
完成后必须按以下格式回报：
{
  "task_id": "T2",
  "status": "completed" | "failed" | "blocked",
  "output_files": ["实际生成的文件列表"],
  "test_results": "X passed, Y failed",
  "issues": ["发现的问题或需要主虾决策的事项"],
  "summary": "一句话概括做了什么"
}
```

### 2.3 并发控制

```javascript
// 同一批次的任务可以并发 spawn
const batch = getNextBatch(taskGraph); // 获取所有无阻塞依赖的任务

for (const task of batch) {
  sessions_spawn({
    task: buildTaskPrompt(task),
    mode: "run",
    runtime: "subagent",
    label: `worker-${task.id.toLowerCase()}`
  });
}

// 让出当前轮次，等所有分支虾完成
sessions_yield({ message: `已分派 ${batch.length} 个任务，等待分支虾完成...` });
```

**并发上限：** 默认 maxConcurrent = 8，根据任务复杂度调整。简单任务可以开满，复杂任务建议 3-4 个。

---

## 第三章：进度追踪与状态管理

### 3.1 任务状态机

```
pending → in_progress → completed
                      → failed → retry → in_progress（重试）
                               → abandoned（超过最大重试次数）
blocked → pending（依赖解除后自动流转）
```

### 3.2 状态更新规则

主虾在以下时机更新 task-graph.json：

```
1. 分派任务时：
   status: pending → in_progress
   assignee: "worker-t2"

2. 收到分支虾结果时：
   status: in_progress → completed / failed
   追加 execution_log 条目

3. 依赖解除时：
   自动扫描所有 blocked 任务
   如果所有 deps 都是 completed → status: blocked → pending

4. 重试时：
   retries += 1
   status: failed → in_progress
   追加 retry 记录到 execution_log
```

### 3.3 执行日志

```json
{
  "execution_log": [
    {
      "timestamp": "2026-03-25T17:10:00+08:00",
      "task_id": "T1",
      "action": "dispatched",
      "worker": "worker-t1"
    },
    {
      "timestamp": "2026-03-25T17:25:00+08:00",
      "task_id": "T1",
      "action": "completed",
      "worker": "worker-t1",
      "summary": "生成 schema.sql 和 migration.sql，覆盖 users/products/orders 三张表",
      "output_files": ["db/schema.sql", "db/migration.sql"]
    },
    {
      "timestamp": "2026-03-25T17:26:00+08:00",
      "task_id": "T2",
      "action": "unblocked",
      "reason": "dependency T1 completed"
    },
    {
      "timestamp": "2026-03-25T17:26:00+08:00",
      "task_id": "T2",
      "action": "dispatched",
      "worker": "worker-t2"
    },
    {
      "timestamp": "2026-03-25T17:45:00+08:00",
      "task_id": "T2",
      "action": "failed",
      "worker": "worker-t2",
      "reason": "JWT 库版本冲突，测试未通过",
      "retry": 1
    },
    {
      "timestamp": "2026-03-25T17:46:00+08:00",
      "task_id": "T2",
      "action": "dispatched",
      "worker": "worker-t2-retry1",
      "note": "主虾补充指令：使用 jsonwebtoken@9.x，不要用 jose"
    }
  ]
}
```

---

## 第四章：质量验收

### 4.1 三级验收体系

```
第一级：分支虾自检（自动）
  → 分支虾完成后自行运行测试
  → 只有测试通过才报告 completed
  → 测试失败先自行修复，超过 3 次再报告 failed

第二级：主虾验收（必须）
  → 检查输出文件是否存在且非空
  → 检查测试结果是否真的通过
  → 检查是否符合验收标准中的具体要求
  → 抽查关键代码逻辑

第三级：质检虾交叉验证（高风险任务）
  → 独立 Agent，不看分支虾的推理过程
  → 只看产出物，独立判断质量
  → 用于打断幻觉放大链
```

### 4.2 主虾验收清单

主虾收到分支虾结果后，逐项检查：

```markdown
## 验收检查（任务 T2: 用户模块 API）

- [ ] 输出文件存在：src/api/user/、tests/api/user/
- [ ] 文件非空且有实质内容
- [ ] 测试结果：X passed, 0 failed
- [ ] API 接口覆盖：注册 ✅ 登录 ✅ 权限 ✅
- [ ] 符合 API 规范文档中的接口定义
- [ ] 无硬编码密钥或测试数据残留
- [ ] 错误处理完整（参数校验、异常捕获）

验收结论：✅ 通过 / ⚠️ 需修改 / ❌ 重做
```

### 4.3 启用质检虾

```javascript
// 对高风险任务启用独立质检
sessions_spawn({
  task: `
## 任务
你是质检虾，独立审查以下产出物的质量。

## 审查对象
文件路径：src/api/order/
测试文件：tests/api/order/

## 审查标准
1. 订单状态机是否完整（待支付→已支付→已发货→已完成→已退款）
2. 并发下单是否有锁保护
3. 金额计算是否使用整数/Decimal，不用浮点
4. 退款逻辑是否有幂等保护
5. 测试是否覆盖异常路径

## 输出
{
  "verdict": "pass" | "fail",
  "score": "1-10",
  "issues": ["发现的具体问题"],
  "suggestions": ["改进建议"]
}

重要：不要假设代码是正确的，以审查者视角独立判断。
`,
  mode: "run",
  runtime: "subagent",
  label: "reviewer-t4"
})
```

---

## 第五章：异常处理

### 5.1 分支虾失败

```
分支虾报告 failed
  ↓
主虾检查失败原因
  ├─ 可修复（依赖版本、配置错误）
  │   → steer 分支虾补充指令，或 spawn 新虾附带修复提示
  │   → retries += 1
  │
  ├─ 需求不清
  │   → 向用户澄清需求
  │   → 更新任务描述后重新分派
  │
  ├─ 能力超限（任务太难）
  │   → 进一步拆分子任务
  │   → 或升级为主虾亲自处理
  │
  └─ 超过最大重试次数
      → 标记 abandoned
      → 向用户报告，提供已完成的部分和失败原因
      → 询问是否调整方案
```

### 5.2 分支虾超时

```javascript
sessions_spawn({
  task: "...",
  mode: "run",
  runtime: "subagent",
  label: "worker-t3",
  runTimeoutSeconds: 600  // 10 分钟超时
})
```

超时处理：
1. 检查子 Agent 是否在循环中（常见于测试反复失败重试）
2. kill 超时的分支虾
3. 分析已有输出，决定是重试还是拆分

### 5.3 级联失败

当一个任务失败可能影响整条链路时：

```
T2 失败
  → T4 依赖 T2，无法开始
  → T5 依赖 T4，无法开始
  → T6 依赖 T4，无法开始

主虾决策：
  选项 A：修复 T2 后继续（阻塞时间可接受）
  选项 B：跳过 T2 的部分功能，用 mock 数据让 T4 先跑
  选项 C：向用户报告，重新评估方案
```

### 5.4 幻觉检测

主虾需要警惕以下信号：

| 信号 | 含义 | 应对 |
|---|---|---|
| 分支虾声称"全部测试通过"但未列出具体测试 | 可能没跑测试 | 要求提供完整测试输出 |
| 输出文件存在但内容是模板/占位符 | 没有真正实现 | 读取文件内容验证 |
| 多个分支虾返回雷同的结构和措辞 | 可能在互相抄 | 启用质检虾独立审查 |
| 声称修复了 bug 但没说改了哪里 | 可能没改 | 要求提供 diff |

---

## 第六章：结果汇总与交付

### 6.1 汇总模板

所有分支虾完成后，主虾生成最终报告：

```markdown
# 📋 项目执行报告：[项目名称]

## 概览
- 总任务数：6
- 已完成：5 ✅
- 失败：1 ❌（T2 第一次失败后重试成功）
- 总耗时：约 45 分钟
- 分支虾使用数：7（含 1 次重试 + 1 个质检虾）

## 各任务执行情况

| 任务 | 状态 | 执行者 | 耗时 | 备注 |
|---|---|---|---|---|
| T1 Schema 设计 | ✅ | worker-t1 | 15min | 一次通过 |
| T2 用户 API | ✅ | worker-t2-retry1 | 20min | 首次 JWT 库冲突，重试后通过 |
| T3 商品 API | ✅ | worker-t3 | 18min | 一次通过 |
| T4 订单 API | ✅ | worker-t4 | 22min | 质检虾审查通过 |
| T5 集成测试 | ✅ | worker-t5 | 15min | 覆盖完整链路 |
| T6 API 文档 | ✅ | worker-t6 | 8min | Swagger UI 正常渲染 |

## 产出物
- db/schema.sql — 数据库表结构
- db/migration.sql — 迁移脚本
- src/api/ — 全部 API 代码
- tests/ — 单元测试 + 集成测试
- docs/openapi.yaml — API 文档

## 已知问题
1. 商品搜索暂未实现全文检索，当前为 LIKE 模糊匹配
2. 退款回调暂用轮询，建议后续改为 Webhook

## 后续建议
1. 部署到 staging 环境做压测
2. 补充商品搜索的全文检索能力
3. 接入真实支付网关替换 mock
```

### 6.2 归档

```
.openclaw/projects/[project-name]/
├── task-graph.json          # 完整任务图（含最终状态）
├── execution-log.jsonl      # 全部执行记录
├── reviews/                 # 质检虾审查报告
│   └── review-t4.json
└── deliverables/            # 交付物清单和路径
    └── manifest.json
```

---

## 快速决策树

```
收到复杂任务
  ↓
能 1 个 session 搞定？ → 是 → 自己干，别折腾
  ↓ 否
能拆成独立子任务？ → 否 → 用提示链顺序执行
  ↓ 是
子任务超过 3 个？ → 否 → 手动管理就够了
  ↓ 是
生成 task-graph.json
  ↓
分析依赖 → 识别可并行批次
  ↓
按批次 spawn 分支虾
  ↓
验收 → 更新任务图 → 解锁下游 → 继续分派
  ↓
高风险任务？ → 是 → 启用质检虾
  ↓
全部完成 → 汇总报告 → 归档
```

---

## 参考

- OpenClaw sessions_spawn / subagents 文档：https://docs.openclaw.ai
- Anthropic 编排器-工作者模式：https://claude.com/blog/multi-agent
- Tw93《你不知道的 Agent》多 Agent 组织章节：https://tw93.fun/2026-03-21/agent.html