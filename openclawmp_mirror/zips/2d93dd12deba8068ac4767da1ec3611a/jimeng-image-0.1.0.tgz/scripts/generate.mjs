#!/usr/bin/env node
/**
 * jimeng-image skill - Image Generation Script
 * 用法: node generate.mjs "提示词" [数量] [输出目录]
 * 示例: node generate.mjs "一只可爱的小龙虾" 3 /tmp/openclaw
 */

import { readFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { execSync, spawn } from 'child_process';
import { setTimeout as sleep } from 'timers/promises';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = join(__dirname, '../config/jimeng.conf');
const UPLOAD_DIR = '/tmp/openclaw/uploads';

// 读取cookie
function loadCookie() {
  const conf = readFileSync(CONFIG_PATH, 'utf-8');
  const match = conf.match(/JIMENG_COOKIE="([^"]+)"/);
  if (!match || !match[1]) {
    throw new Error('❌ Cookie未配置！请更新 config/jimeng.conf 里的 JIMENG_COOKIE');
  }
  return match[1];
}

// 检查cookie是否有效
export function checkCookie() {
  const cookie = loadCookie();
  try {
    const resp = execSync(`curl -s -o /dev/null -w "%{http_code}" -H "Cookie: ${cookie}" "https://jimeng.jianying.com/ai-tool/home"`, { timeout: 10000 });
    const code = parseInt(resp.toString().trim());
    if (code === 200) return { ok: true };
    if (code === 401 || code === 403) return { ok: false, reason: 'cookie过期' };
    return { ok: false, reason: `HTTP ${code}` };
  } catch {
    return { ok: false, reason: '网络请求失败' };
  }
}

// 验证cookie（导出供外部调用）
export async function validateCookie() {
  const result = checkCookie();
  if (!result.ok) {
    console.error(`⚠️  Cookie已过期（${result.reason}），请重新扫码获取cookie并更新到 config/jimeng.conf`);
    console.error('   获取方式：浏览器登录 jimeng.jianying.com → F12 → Application → Cookies → 复制 cookie 值');
    process.exit(1);
  }
  console.log('✅ Cookie验证通过');
  return true;
}

// 下载单个图片
async function downloadImage(url, filename) {
  const cookie = loadCookie();
  const webpPath = `/tmp/${filename}.webp`;
  const jpgPath = `${UPLOAD_DIR}/${filename}.jpg`;
  
  execSync(`curl -s -L -o ${webpPath} -H "Cookie: ${cookie}" -H "User-Agent: Mozilla/5.0" -H "Referer: https://jimeng.jianying.com/" "${url}"`, { timeout: 15000 });
  
  // 检查是否是HTML（cookie过期或URL无效）
  const isHtml = execSync(`file ${webpPath} | grep -c HTML`).toString().trim();
  if (isHtml === '1') {
    throw new Error('cookie过期或URL无效');
  }
  
  // 转换JPG
  execSync(`python3 -c "
from PIL import Image
img = Image.open('${webpPath}')
rgb = img.convert('RGB')
rgb.save('${jpgPath}', 'JPEG', quality=90)
"`, { timeout: 10000 });
  
  return jpgPath;
}

// 主生成流程（通过浏览器自动化）
export async function generateImages(prompt, count = 3, outputPrefix = 'img') {
  console.log(`🎨 开始生成图片: "${prompt}" x${count}`);
  
  // 1. 验证cookie
  await validateCookie();
  
  // 2. 启动浏览器（如果未运行）
  try {
    execSync('openclaw browser status', { timeout: 5000 });
  } catch {
    console.log('🌐 启动浏览器...');
    execSync('openclaw browser start', { timeout: 15000 });
    await sleep(3000);
  }
  
  // 3. 打开即梦
  const tabId = execSync('curl -s "http://127.0.0.1:18789/api/browser/tabs" -X POST -H "Content-Type: application/json" -d \'{"url":"https://jimeng.jianying.com/ai-tool/generate/?type=image&workspace=0"}\'', { timeout: 10000 }).toString().trim();
  await sleep(5000);
  
  const results = [];
  
  for (let i = 0; i < count; i++) {
    try {
      // 输入提示词（通过CDP）
      const inputScript = `
        const boxes = document.querySelectorAll('[contenteditable="true"]');
        for (const b of boxes) {
          if (b.offsetHeight > 0 && b.classList.contains('tiptap')) {
            b.innerHTML = '';
            b.textContent = '${prompt.replace(/'/g, "\\'")}';
            b.dispatchEvent(new Event('input', {bubbles:true}));
            break;
          }
        }
      `;
      execSync(`curl -s "http://127.0.0.1:18789/api/browser/tabs/${tabId}/evaluate" -X POST -H "Content-Type: application/json" -d '{"script":"${inputScript.replace(/"/g, '\\"')}"}'`, { timeout: 10000 });
      await sleep(500);
      
      // 点击生成按钮
      const clickScript = `
        const btns = document.querySelectorAll('button');
        for (const b of btns) {
          if (b.className.includes('submit-button') && !b.disabled) {
            b.click(); break;
          }
        }
      `;
      execSync(`curl -s "http://127.0.0.1:18789/api/browser/tabs/${tabId}/evaluate" -X POST -H "Content-Type: application/json" -d '{"script":"${clickScript}"}'`, { timeout: 10000 });
      
      console.log(`  ⏳ 生成第 ${i+1}/${count} 张...`);
      await sleep(35000); // 等待生成
      
      // 提取图片URL
      const urlscript = `
        const imgs = document.querySelectorAll('img');
        for (const img of imgs) {
          if (img.src.includes('dreamina') && img.naturalWidth > 300) {
            return img.src;
          }
        }
      `;
      const imgUrl = execSync(`curl -s "http://127.0.0.1:18789/api/browser/tabs/${tabId}/evaluate" -X POST -H "Content-Type: application/json" -d '{"script":"${urlscript}"}'`, { timeout: 10000 }).toString().trim();
      
      if (imgUrl && imgUrl.startsWith('http')) {
        const filename = `${outputPrefix}_${i+1}`;
        const savedPath = await downloadImage(imgUrl, filename);
        results.push(savedPath);
        console.log(`  ✅ 第${i+1}张已保存: ${savedPath}`);
      }
    } catch (e) {
      console.error(`  ❌ 第${i+1}张失败: ${e.message}`);
    }
  }
  
  return results;
}

// 命令行入口
const prompt = process.argv[2];
const count = parseInt(process.argv[3]) || 3;
const outputPrefix = process.argv[4] || `jimeng_${Date.now()}`;

if (!prompt) {
  console.log('用法: node generate.mjs "提示词" [数量] [输出前缀]');
  process.exit(1);
}

generateImages(prompt, count, outputPrefix)
  .then(paths => {
    console.log('\n🎉 完成！生成图片:');
    paths.forEach(p => console.log('  -', p));
    process.exit(0);
  })
  .catch(e => {
    console.error('❌ 失败:', e.message);
    process.exit(1);
  });
