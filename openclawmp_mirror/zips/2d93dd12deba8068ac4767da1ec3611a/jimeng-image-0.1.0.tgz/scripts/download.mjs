#!/usr/bin/env node
/**
 * jimeng-image skill - 图片下载脚本
 * 用法: node download.mjs <url> <输出名> [输出目录]
 * 示例: node download.mjs "https://..." lobster_saturn /tmp/openclaw
 * 
 * 功能：
 * - 用cookie下载即梦图片
 * - WebP → JPG 自动转换
 * - cookie过期检测（过期则提示更新）
 */

import { readFileSync, existsSync, mkdirSync, writeFileSync } from 'fs';
import { mkdtempSync } from 'fs';
import { tmpdir } from 'os';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = join(__dirname, '../config/jimeng.conf');
const UPLOAD_DIR = process.argv[4] || '/tmp/openclaw/uploads';

function loadCookie() {
  const conf = readFileSync(CONFIG_PATH, 'utf-8');
  const match = conf.match(/JIMENG_COOKIE="([^"]+)"/);
  if (!match || !match[1]) return null;
  return match[1];
}

function isHtmlFile(path) {
  try {
    const head = readFileSync(path, { encoding: 'ascii', maxLength: 200 });
    return head.includes('<!DOCTYPE') || head.includes('<html');
  } catch { return false; }
}

function ensureDir(dir) {
  if (!existsSync(dir)) mkdirSync(dir, { recursive: true });
}

async function download(url, name) {
  const cookie = loadCookie();
  if (!cookie) throw new Error('Cookie未配置');

  // 写cookie到临时文件避免引号问题
  const tmpDir = mkdtempSync(`${tmpdir()}/jimeng_dl_`);
  const cookieFile = `${tmpDir}/cookie_${Date.now()}.txt`;
  writeFileSync(cookieFile, cookie, 'ascii');

  ensureDir(UPLOAD_DIR);
  const webpPath = `/tmp/${name}.webp`;
  const jpgPath = join(UPLOAD_DIR, `${name}.jpg`);

  console.log(`📥 下载: ${name}`);
  try {
    execSync(`curl -s -L -o "${webpPath}" --cookie "${cookieFile}" -H "User-Agent: Mozilla/5.0 (X11; Linux arm64) AppleWebKit/537.36" -H "Referer: https://jimeng.jianying.com/" "${url}" --max-time 20`, { timeout: 25000 });

    // 检测cookie过期
    if (isHtmlFile(webpPath)) {
      throw new Error('COOKIE_EXPIRED');
    }

    // 转换JPG
    execSync(`python3 -c "
from PIL import Image
img = Image.open('${webpPath}')
rgb = img.convert('RGB')
rgb.save('${jpgPath}', 'JPEG', quality=90)
print('转换成功:', img.size)
"`, { timeout: 10000 });

  } finally {
    try { execSync(`rm -f "${cookieFile}" "${webpPath}"`, { timeout: 5000 }) } catch {}
  }
  
  return jpgPath;
}

// 主程序
const url = process.argv[2];
const name = process.argv[3];

if (!url || !name) {
  console.log('用法: node download.mjs <url> <输出名> [输出目录]');
  process.exit(1);
}

download(url, name)
  .then(path => {
    console.log(`✅ 已保存: ${path}`);
    process.exit(0);
  })
  .catch(e => {
    if (e.message === 'COOKIE_EXPIRED') {
      console.error('❌ Cookie已过期！请重新扫码获取cookie并更新到 config/jimeng.conf');
      console.error('   获取方式：浏览器登录 jimeng.jianying.com → F12 → Application → Cookies → 复制完整cookie值');
    } else {
      console.error('❌ 下载失败:', e.message);
    }
    process.exit(1);
  });
