#!/usr/bin/env node
/**
 * jimeng-image skill - Cookie 验证脚本
 * 用法: node check_cookie.mjs
 * 返回: 0=有效, 1=过期
 */

import { readFileSync, writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { execSync } from 'child_process';
import { mkdtempSync, rmSync } from 'fs';
import { tmpdir } from 'os';

const __dirname = dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = join(__dirname, '../config/jimeng.conf');

function loadCookie() {
  const conf = readFileSync(CONFIG_PATH, 'utf-8');
  const match = conf.match(/JIMENG_COOKIE="([^"]+)"/);
  if (!match || !match[1]) return null;
  return match[1];
}

function checkCookie() {
  const cookie = loadCookie();
  if (!cookie) {
    console.log('❌ Cookie未配置');
    return false;
  }

  // 写cookie到临时文件，避免shell引号问题
  const tmpDir = mkdtempSync(`${tmpdir()}/jimeng_cookie_`);
  const cookieFile = `${tmpDir}/cookie.txt`;
  writeFileSync(cookieFile, cookie, 'ascii');

  try {
    const code = execSync(
      `curl -s -o /dev/null -w "%{http_code}" -L --cookie "${cookieFile}" -H "User-Agent: Mozilla/5.0 (X11; Linux arm64) AppleWebKit/537.36" "https://jimeng.jianying.com/ai-tool/home" --max-time 10`,
      { timeout: 15000 }
    ).toString().trim();

    if (code === '200') {
      console.log('✅ Cookie有效');
      return true;
    } else if (code === '401' || code === '403' || code === '302') {
      console.log('⚠️  Cookie已过期，请重新扫码获取并更新到 config/jimeng.conf');
      console.log('   获取方式：浏览器登录 jimeng.jianying.com → F12 → Application → Cookies → 复制完整cookie值');
      return false;
    } else {
      console.log(`⚠️  Cookie状态异常 (HTTP ${code})，建议重新验证`);
      return false;
    }
  } catch (e) {
    console.log(`⚠️  网络请求失败`);
    return false;
  } finally {
    rmSync(tmpDir, { recursive: true, force: true });
  }
}

const ok = checkCookie();
process.exit(ok ? 0 : 1);
