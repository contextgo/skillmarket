#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全球市场数据获取脚本
每日07:45执行，获取美股、大宗商品、汇率数据
"""

import json
import datetime
import os
import sys

# 禁用代理
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''

def fetch_global_market_data():
    """获取全球市场数据"""
    
    # 模拟数据（实际使用时可接入真实API）
    data = {
        "timestamp": datetime.datetime.now().isoformat(),
        "us_market": {
            "dow_jones": {"price": 34500.00, "change": 0.5, "change_pct": 0.5},
            "nasdaq": {"price": 14200.00, "change": 112.0, "change_pct": 0.8},
            "sp500": {"price": 4450.00, "change": 26.7, "change_pct": 0.6}
        },
        "commodities": {
            "crude_oil": {"price": 85.50, "change": 1.02, "change_pct": 1.2, "unit": "USD/barrel"},
            "gold": {"price": 2350.00, "change": 11.75, "change_pct": 0.5, "unit": "USD/oz"},
            "copper": {"price": 4.25, "change": 0.013, "change_pct": 0.3, "unit": "USD/lb"}
        },
        "fx": {
            "dxy": {"price": 103.5, "change": -0.21, "change_pct": -0.2, "name": "美元指数"},
            "usdcny": {"price": 7.25, "change": 0.007, "change_pct": 0.1, "name": "美元兑人民币"}
        },
        "sentiment": "看涨"
    }
    
    # 保存到文件
    output_file = f"global_market_data_{datetime.datetime.now().strftime('%Y%m%d')}.json"
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    
    # 打印结果
    print("=" * 60)
    print("全球市场数据获取完成")
    print("=" * 60)
    print(f"时间: {data['timestamp']}")
    print("-" * 60)
    print("美股:")
    print(f"  道琼斯: {data['us_market']['dow_jones']['price']:.2f} ({data['us_market']['dow_jones']['change_pct']:+.2f}%)")
    print(f"  纳斯达克: {data['us_market']['nasdaq']['price']:.2f} ({data['us_market']['nasdaq']['change_pct']:+.2f}%)")
    print(f"  标普500: {data['us_market']['sp500']['price']:.2f} ({data['us_market']['sp500']['change_pct']:+.2f}%)")
    print("-" * 60)
    print("大宗商品:")
    print(f"  原油: ${data['commodities']['crude_oil']['price']:.2f} ({data['commodities']['crude_oil']['change_pct']:+.2f}%)")
    print(f"  黄金: ${data['commodities']['gold']['price']:.2f} ({data['commodities']['gold']['change_pct']:+.2f}%)")
    print("-" * 60)
    print("汇率:")
    print(f"  美元指数: {data['fx']['dxy']['price']:.2f} ({data['fx']['dxy']['change_pct']:+.2f}%)")
    print(f"  人民币汇率: {data['fx']['usdcny']['price']:.4f}")
    print("-" * 60)
    print(f"市场情绪: {data['sentiment']}")
    print("=" * 60)
    print(f"数据已保存: {output_file}")
    
    return data

if __name__ == "__main__":
    fetch_global_market_data()
