#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
全球市场数据获取 - 使用示例
"""

import json
import datetime

def load_market_data(date=None):
    """加载指定日期的市场数据"""
    if date is None:
        date = datetime.datetime.now().strftime('%Y%m%d')
    
    filename = f"global_market_data_{date}.json"
    
    try:
        with open(filename, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data
    except FileNotFoundError:
        print(f"数据文件不存在: {filename}")
        return None

def analyze_market_sentiment(data):
    """分析市场情绪"""
    if data is None:
        return "无数据"
    
    sentiment = data.get('sentiment', '中性')
    us_market = data.get('us_market', {})
    
    # 计算美股平均涨跌幅
    dow_change = us_market.get('dow_jones', {}).get('change_pct', 0)
    nasdaq_change = us_market.get('nasdaq', {}).get('change_pct', 0)
    sp500_change = us_market.get('sp500', {}).get('change_pct', 0)
    
    avg_change = (dow_change + nasdaq_change + sp500_change) / 3
    
    print("=" * 60)
    print("市场情绪分析")
    print("=" * 60)
    print(f"日期: {data.get('timestamp', 'N/A')}")
    print(f"情绪判断: {sentiment}")
    print(f"美股平均涨幅: {avg_change:+.2f}%")
    print("-" * 60)
    
    # 分析建议
    if sentiment == "看涨":
        print("✅ 建议: 美股上涨，A股开盘可能高开")
        print("   操作策略: 持仓待涨，关注强势股")
    elif sentiment == "看跌":
        print("⚠️ 建议: 美股下跌，A股开盘可能低开")
        print("   操作策略: 控制仓位，关注防御板块")
    else:
        print("➖ 建议: 美股震荡，A股可能平开")
        print("   操作策略: 观望为主，等待方向明确")
    
    print("=" * 60)
    
    return sentiment

def check_commodities(data):
    """检查大宗商品"""
    if data is None:
        return
    
    commodities = data.get('commodities', {})
    
    print("\n" + "=" * 60)
    print("大宗商品监控")
    print("=" * 60)
    
    # 原油
    oil = commodities.get('crude_oil', {})
    oil_price = oil.get('price', 0)
    oil_change = oil.get('change_pct', 0)
    print(f"原油: ${oil_price:.2f} ({oil_change:+.2f}%)")
    
    # 黄金
    gold = commodities.get('gold', {})
    gold_price = gold.get('price', 0)
    gold_change = gold.get('change_pct', 0)
    print(f"黄金: ${gold_price:.2f} ({gold_change:+.2f}%)")
    
    # 影响分析
    print("-" * 60)
    if oil_change > 2:
        print("⚠️ 原油大涨，关注石油石化板块")
    elif oil_change < -2:
        print("✅ 原油大跌，航空物流板块受益")
    
    if gold_change > 1:
        print("⚠️ 黄金上涨，避险情绪升温")
    
    print("=" * 60)

if __name__ == "__main__":
    # 加载数据
    data = load_market_data()
    
    if data:
        # 分析情绪
        sentiment = analyze_market_sentiment(data)
        
        # 检查大宗商品
        check_commodities(data)
    else:
        print("请先运行 fetch_global_market.py 获取数据")
