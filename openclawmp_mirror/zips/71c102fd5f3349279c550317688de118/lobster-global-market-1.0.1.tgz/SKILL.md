---
name: lobster-global-market
description: |
  获取全球市场数据（美股、大宗商品、汇率）。
  用于每日07:45定时获取全球市场数据，为A股交易提供宏观参考。
  输出JSON格式数据，包含道琼斯、纳斯达克、标普500、原油、黄金、美元指数等。
  
  触发条件：
  - 每日07:45定时任务
  - 用户查询全球市场数据
  - 盘前准备需要全球市场数据
---

# 全球市场数据获取技能

## 功能

获取全球市场关键数据，为A股交易决策提供宏观参考。

## 数据内容

| 数据类型 | 具体指标 |
|:---|:---|
| 美股 | 道琼斯、纳斯达克、标普500 |
| 大宗商品 | 原油(WTI)、黄金、铜 |
| 汇率 | 美元指数、人民币汇率 |
| 情绪 | 宏观情绪判断（看涨/看跌/中性）|

## 使用方法

### 定时执行

```bash
python scripts/fetch_global_market.py
```

### 输出格式

```json
{
  "timestamp": "2026-04-16T07:45:00",
  "us_market": {
    "dow_jones": {"price": 34500.00, "change": 0.5},
    "nasdaq": {"price": 14200.00, "change": 0.8},
    "sp500": {"price": 4450.00, "change": 0.6}
  },
  "commodities": {
    "crude_oil": {"price": 85.50, "change": 1.2},
    "gold": {"price": 2350.00, "change": 0.5},
    "copper": {"price": 4.25, "change": 0.3}
  },
  "fx": {
    "dxy": {"price": 103.5, "change": -0.2},
    "usdcny": {"price": 7.25, "change": 0.1}
  },
  "sentiment": "看涨"
}
```

## 依赖

- akshare
- python-dateutil

## 定时任务配置

```cron
45 7 * * 1-5 python scripts/fetch_global_market.py
```

## 参考

- [市场数据格式](references/market_data_schema.md)
