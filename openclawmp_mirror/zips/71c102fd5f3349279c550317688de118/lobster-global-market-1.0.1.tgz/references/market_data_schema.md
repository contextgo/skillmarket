# 市场数据格式规范

## JSON Schema

```json
{
  "timestamp": "ISO8601格式时间戳",
  "us_market": {
    "dow_jones": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)"
    },
    "nasdaq": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)"
    },
    "sp500": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)"
    }
  },
  "commodities": {
    "crude_oil": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)",
      "unit": "单位 (string)"
    },
    "gold": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)",
      "unit": "单位 (string)"
    },
    "copper": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)",
      "unit": "单位 (string)"
    }
  },
  "fx": {
    "dxy": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)",
      "name": "中文名称 (string)"
    },
    "usdcny": {
      "price": "当前价格 (float)",
      "change": "涨跌额 (float)",
      "change_pct": "涨跌幅百分比 (float)",
      "name": "中文名称 (string)"
    }
  },
  "sentiment": "市场情绪 (string: 看涨/看跌/中性)"
}
```

## 数据字段说明

| 字段 | 类型 | 说明 |
|:---|:---|:---|
| timestamp | string | ISO8601格式时间戳 |
| us_market | object | 美股市场数据 |
| commodities | object | 大宗商品数据 |
| fx | object | 汇率数据 |
| sentiment | string | 市场情绪判断 |

## 情绪判断规则

| 条件 | 情绪 |
|:---|:---|
| 美股全部上涨且涨幅>0.5% | 看涨 |
| 美股全部下跌且跌幅>0.5% | 看跌 |
| 其他情况 | 中性 |
