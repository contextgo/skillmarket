# 全球市场数据获取技能

## 简介

本技能用于每日07:45定时获取全球市场数据，为A股交易提供宏观参考。

## 功能特性

- ✅ 美股数据：道琼斯、纳斯达克、标普500
- ✅ 大宗商品：原油、黄金、铜
- ✅ 汇率数据：美元指数、人民币汇率
- ✅ 情绪判断：自动判断市场情绪（看涨/看跌/中性）
- ✅ JSON输出：结构化数据，便于后续处理

## 安装

```bash
openclawmp install skill/71c102fd5f3349279c550317688de118
```

## 使用方法

### 1. 手动执行

```bash
python scripts/fetch_global_market.py
```

### 2. 定时任务配置

在Windows任务计划程序中添加：

```
任务名称：龙虾AI-全球市场数据-0745
执行时间：每天 07:45
执行命令：python scripts/fetch_global_market.py
工作目录：E:\BaiduSyncdisk\IDE\1\QMT 策略 5\AI 自动交易
```

或使用Cron：

```cron
45 7 * * 1-5 python scripts/fetch_global_market.py
```

## 输出示例

```json
{
  "timestamp": "2026-04-16T07:45:00",
  "us_market": {
    "dow_jones": {"price": 34500.00, "change": 172.5, "change_pct": 0.5},
    "nasdaq": {"price": 14200.00, "change": 112.0, "change_pct": 0.8},
    "sp500": {"price": 4450.00, "change": 26.7, "change_pct": 0.6}
  },
  "commodities": {
    "crude_oil": {"price": 85.50, "change": 1.02, "change_pct": 1.2, "unit": "USD/barrel"},
    "gold": {"price": 2350.00, "change": 11.75, "change_pct": 0.5, "unit": "USD/oz"},
    "copper": {"price": 4.25, "change": 0.013, "change_pct": 0.3, "unit": "USD/lb"}
  },
  "fx": {
    "dxy": {"price": 103.5, "change": -0.21, "change_pct": -0.2, "name": "美元指数"},
    "usdcny": {"price": 7.25, "change": 0.007, "change_pct": 0.1, "name": "美元兑人民币"}
  },
  "sentiment": "看涨"
}
```

## 数据字段说明

| 字段 | 类型 | 说明 |
|:---|:---|:---|
| timestamp | string | ISO8601格式时间戳 |
| us_market | object | 美股市场数据 |
| commodities | object | 大宗商品数据 |
| fx | object | 汇率数据 |
| sentiment | string | 市场情绪判断 |

## 情绪判断规则

| 条件 | 情绪 |
|:---|:---|
| 美股全部上涨且涨幅>0.5% | 看涨 |
| 美股全部下跌且跌幅>0.5% | 看跌 |
| 其他情况 | 中性 |

## 依赖

- Python 3.8+
- akshare
- python-dateutil

## 安装依赖

```bash
pip install akshare python-dateutil
```

## 适用场景

- 每日盘前全球市场分析
- A股开盘前宏观环境评估
- 量化交易策略的宏观因子输入
- 投资组合风险管理

## 作者

龙虾AI

## 许可证

MIT
