---
name: test-skill
displayName: Test Skill
description: Test skill for market functionality
version: 0.0.1
type: skill
tags: test, demo
---

# Test Skill
This is a test skill for market functionality.
