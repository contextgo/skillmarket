## When to Use

Use this skill when the gateway is **already installed and configured** but showing connection issues:
- `connect failed` or `Missing dependencies for SOCKS support` errors in logs
- Gateway appears running but not receiving messages
- Need to verify WebSocket connection status
- Suspect stale/zombie gateway processes
- Need to check if allowlist is blocking messages
- Validate end-to-end message flow

**Do NOT use for initial setup** (creating `.env`, installing dependencies) — see separate setup docs.

### Key Insights (from recent debugging)

1. **SOCKS errors ≠ WebSocket down** — The SOCKS dependency warning comes from `lark_oapi`'s HTTP client. WebSocket uses `websockets` library separately. If logs show `[Feishu] Connected in websocket mode`, the gateway is functional despite SOCKS errors.

2. **DM vs Group allowlist mismatch** — `FEISHU_ALLOWED_USERS` only filters **group @mentions** in code, despite `.env` comment claiming it restricts DMs. **Anyone can DM the bot** regardless of this setting. This is a documentation bug in the `.env` template.

3. **Multi-process conflict pattern** — Running `hermes gateway run` multiple times creates overlapping processes. Old processes output stale errors (like SOCKS warnings from before dependencies were fixed) while the new process connects fine. Always verify `pgrep -f "hermes gateway"` shows exactly 1 PID.

## Quick Diagnosis Flow

### Step 1: Check Gateway Status
```bash
hermes gateway status
```
Expected: `✓ Gateway is running (PID: XXXX)`

If not running: `hermes gateway start`

### Step 2: Check for Stale Processes (Multi-Process Conflict Pattern)

**Symptom:** Gateway reports "connected" but logs show repeated `connect failed` or SOCKS errors.

**Cause:** Multiple gateway processes running concurrently — old processes output stale errors while a new one connects successfully.

**Diagnose:**
```bash
pgrep -f "hermes gateway"  # Count PIDs
```
If >1 PID: you have conflicting processes.

**Fix:** Kill all and restart clean:
```bash
pkill -9 -f "hermes gateway"
sleep 2
hermes gateway start
```

**Verify:** Only 1 gateway PID should be running. Recent logs should show a single successful `Connected in websocket mode` without subsequent `connect failed` errors.

### Step 3: Check Recent Logs

```bash
tail -n 50 <hermes_home>/logs/agent.log | grep -E "gateway|Feishu|Lark|ERROR"
```

**Key patterns:**
- `[Feishu] Connected in websocket mode (feishu)` → ✅ Success
- `INFO Lark: connected to wss://...` → ✅ Transport up
- `connect failed, err:` → ❌ Connection failing
- `[Feishu] Disconnected` → ❌ Dropped
- `Missing dependencies for SOCKS support` → Old process or missing `socksio`

If you see `connect failed` but also `Connected in websocket mode` earlier: likely a **stale process** still outputting old errors. Kill all gateway processes and restart clean.

### Step 4: Verify Environment Variables

Gateway reads env at **startup only**. If you recently added `FEISHU_APP_ID`/`FEISHU_APP_SECRET`, you must restart.

Check what the running gateway process sees (if `/proc` available):
```bash
cat /proc/<gateway_pid>/environ | tr '\0' '\n' | grep FEISHU
```

Or check the config file directly:
```bash
grep -E "FEISHU_(APP_ID|APP_SECRET|ALLOWED_USERS)" <hermes_home>/.env
```

**Must have:**
- `FEISHU_APP_ID` — your bot's app ID
- `FEISHU_APP_SECRET` — your app secret
- `FEISHU_CONNECTION_MODE=websocket` (or `webhook`)

### Step 5: Test Message Receive (Manual Trigger)

Send yourself a test message from another account or via lark-cli:

```bash
lark-cli im +messages-send \
  --as user \
  --user-id ou_your_openid \
  --text "测试消息"
```

If you receive it in the Feishu app where Hermes is installed → inbound path works.

If you don't, check:
- `FEISHU_ALLOWED_USERS` contains your open_id (or is empty = allow all)
- Bot has permission to receive DMs (飞书应用权限设置)
- Gateway log shows the inbound event (search for your `message_id` or user open_id)

### Step 6: Test Outbound (Gateway → User)

From Hermes agent, trigger a notification to yourself via lark-cli:
```bash
lark-cli im +messages-send \
  --as user \
  --user-id <your_open_id> \
  --text "测试发送"
```

If message arrives → outbound path works.

If message arrives → outbound path works.

## Common Error Patterns

### "Missing dependencies for SOCKS support"

**Source:** This error comes from `lark_oapi`'s **HTTP client**, not the WebSocket transport.

**Key distinction:**
- **WebSocket mode** (default): Uses `websockets` — **not affected** by SOCKS errors
- **Webhook mode**: Uses `aiohttp` — **affected** by SOCKS dependencies

**If you see `[Feishu] Connected in websocket mode` in logs but still get SOCKS errors:**
The errors are from **old/stale gateway processes** still running, or from non-critical HTTP API calls. The message-receive path is fine. Kill all gateway processes and restart clean:

```bash
pkill -9 -f "hermes gateway"
sleep 2
hermes gateway restart
```

**If gateway fails to connect entirely:** Install `socksio` in the hermes virtualenv and restart the gateway.

**Verify:** Check logs — `connect failed` errors should stop.

### Allowlist Behavior: DM vs Group Messages (Version-sensitive)

Do **not** assume one fixed behavior across builds.

Observed in the field:
- Some versions/docs imply `FEISHU_ALLOWED_USERS` mainly gates group @mentions.
- Other deployments show DM messages being received but then blocked with `Unauthorized user: <open_id>` unless sender is in allowlist or `GATEWAY_ALLOW_ALL_USERS=true`.

Practical rule:
1. If DM shows ack/reaction but no text reply, check logs for `Unauthorized user`.
2. If present, treat allowlist as active for your inbound path and fix by either:
   - adding sender open_id to `FEISHU_ALLOWED_USERS`, or
   - setting `GATEWAY_ALLOW_ALL_USERS=true`.
3. Restart gateway and retest.

Diagnostic commands:
```bash
grep -E "FEISHU_ALLOWED_USERS|GATEWAY_ALLOW_ALL_USERS|FEISHU_APP_ID" <hermes_home>/.env
tail -n 120 <hermes_home>/logs/agent.log | grep -iE "Inbound dm|Unauthorized user|Feishu"
```

If `.env` is protected or managed and cannot be edited by automation, run gateway with runtime overrides for immediate validation, then persist manually:
```bash
GATEWAY_ALLOW_ALL_USERS=true FEISHU_ALLOWED_USERS= hermes gateway run
```

### "Permission denied" or "Unauthorized" on message send

Not a gateway issue — lark-cli user token lacks `im:message` scope.

**Fix:** Re-authorize lark-cli with correct scopes:
```bash
lark-cli auth login --no-wait --domain im
# After user approves:
lark-cli auth login --device-code <code>
```

See `lark-oauth-image-upload` skill for detailed OAuth flow.

## Config File Discovery

Where does gateway read Feishu config from?

| Source | What it controls | Typical path |
|--------|------------------|--------------|
| Env vars (read at startup) | `FEISHU_APP_ID`, `FEISHU_ALLOWED_USERS`, etc. | `<hermes_home>/.env` |
| Python module | Platform schema, defaults | `<hermes_home>/hermes-agent/gateway/config.py` |
| YAML config | Model, terminal, non-platform settings | `<hermes_home>/config/config.yaml` |

**Important:** Feishu settings are **NOT in `config.yaml`** — they're exclusively environment variables loaded at gateway startup.

If you change `<hermes_home>/.env`, you **must restart** the gateway for changes to take effect.

## Allowlist Verification

`FEISHU_ALLOWED_USERS` may gate inbound senders (including DM) depending on build/runtime path. Treat this section as **runtime verification**, not a hard-coded product rule.

**Check current gating config:**
```bash
grep -E "FEISHU_ALLOWED_USERS|GATEWAY_ALLOW_ALL_USERS" <hermes_home>/.env
```

**Correlate with live behavior:**
```bash
tail -n 120 <hermes_home>/logs/agent.log | grep -iE "Inbound dm|Unauthorized user"
```

If you see `Inbound dm ...` followed by `Unauthorized user ...`, sender is being blocked before reply generation.

**Fix options:**
```bash
# Option A: allow all users
GATEWAY_ALLOW_ALL_USERS=true

# Option B: maintain allowlist
FEISHU_ALLOWED_USERS=ou_xxx,ou_yyy
```

Restart gateway after changes.

## Verification Checklist

After troubleshooting, confirm:
- [ ] `hermes gateway status` → running (single PID)
- [ ] Log shows `[Feishu] Connected in websocket mode`
- [ ] No `connect failed` errors in last 30 seconds of log
- [ ] Test message from lark-cli arrives in Feishu app
- [ ] Test outbound message from Hermes arrives
- [ ] `FEISHU_ALLOWED_USERS` (if set) includes expected user open_ids for group @mentions

## Diagnosis Decision Tree

```
Gateway showing errors?
├─ Multiple PIDs from `pgrep -f "hermes gateway"`?
│  └─ ✅ Kill all, restart clean → should resolve stale-error output
├─ WebSocket connected but SOCKS errors persist?
│  └─ ✅ If messages flowing: ignore (non-critical HTTP calls)
│  └─ ❌ If gateway broken: install socksio in venv, restart
└─ No connection at all?
   ├─ Check .env exists with FEISHU_APP_ID/SECRET
   ├─ Verify venv has lark_oapi, websockets, aiohttp
   └─ Check network/firewall to wss://msg-frontier.feishu.cn
```
---

## OpenClaw Gateway Configuration (Advanced)

> **Note:** This section applies if you're using `openclaw gateway run` instead of `hermes gateway run`. OpenClaw Gateway uses a different configuration system and file layout.

### Required Configuration Steps

#### 0. Determine the real config source first (critical)

Different OpenClaw installs can read channel config from different stores. Do not assume `~/.openclaw/config.yaml` is active.

Always run:

```bash
openclaw config file
openclaw config get channels.feishu
```

If `channels.feishu` is missing, set it via CLI (writes to the active config store, commonly `~/.openclaw/openclaw.json`):

```bash
openclaw config set channels.feishu.enabled true --strict-json
openclaw config set channels.feishu.appId '"cli_xxx"' --strict-json
openclaw config set channels.feishu.appSecret '"your_secret"' --strict-json
openclaw config set channels.feishu.domain '"feishu"' --strict-json
openclaw config set channels.feishu.connectionMode '"websocket"' --strict-json
openclaw config set channels.feishu.allowFrom[0] '"ou_xxx"' --strict-json
```

Then restart and verify:

```bash
openclaw gateway restart
openclaw status --deep
```

Expected channel state:
- `Feishu ON / SETUP / not configured` → config missing/inactive
- `Feishu ON / OK / configured` → channel live

### Architecture Difference

| Aspect | Hermes Gateway | OpenClaw Gateway |
|--------|---------------|------------------|
| Config files | `<hermes_home>/.env` + `config/config.yaml` | `~/.openclaw/openclaw.json` + `~/.openclaw/config.yaml` |
| Feishu config location | Environment variables | `config.yaml` → `channels.feishu` block |
| Plugin system | Python modules | Built-in TypeScript + user extensions |
| Log location | `<hermes_home>/logs/agent.log` | `/tmp/openclaw/openclaw-*.log` (JSON lines) |
| Status command | `hermes gateway status` | `openclaw gateway status` |

### Required Configuration Steps

#### 1. Enable and Configure the Feishu Channel (authoritative source)

For current OpenClaw builds (verified on `2026.4.15`), treat `~/.openclaw/openclaw.json` as the **effective runtime source** for channel settings when using `openclaw config get/set`.

Use CLI writes (recommended) instead of editing YAML by hand:

```bash
openclaw config set channels.feishu.enabled true --strict-json
openclaw config set channels.feishu.appId '"cli_your_app_id"' --strict-json
openclaw config set channels.feishu.appSecret '"your_app_secret"' --strict-json
openclaw config set channels.feishu.domain '"feishu"' --strict-json
openclaw config set channels.feishu.connectionMode '"websocket"' --strict-json
openclaw config set channels.feishu.allowFrom[0] '"ou_your_openid"' --strict-json
```

Then verify:

```bash
openclaw config get channels.feishu
```

If this returns `Config path not found: channels.feishu`, channel config is not loaded in the active config file yet.

Important quoting pitfall with `--strict-json`:
- Strings must be valid JSON strings (include quotes), e.g. `'"cli_xxx"'`
- Raw `cli_xxx` will fail JSON parsing.

**Without `enabled: true` + app credentials, Feishu shows `SETUP/not configured` and cannot receive messages.**

#### 2. Resolve Plugin ID Conflicts

OpenClaw has a **built-in Feishu plugin** at `/opt/homebrew/lib/node_modules/openclaw/dist/extensions/feishu/`. If you've installed a user extension at `~/.openclaw/extensions/feishu/`, both have ID `"feishu"` causing the gateway to skip loading the channel.

**Symptom:** Gateway starts with `ready (0 plugins)` and no Feishu logs.

**Diagnose:**
```bash
ls ~/.openclaw/extensions/feishu/  # If exists, user extension present
```

**Fix:** Disable or remove the user extension (built-in plugin is sufficient):
```bash
mv ~/.openclaw/extensions/feishu ~/.openclaw/extensions/feishu.disabled
```

#### 3. Check Plugin Allowlist (openclaw.json)

OpenClaw's `openclaw.json` has a `plugins.allow` array that restricts which plugins can load. The Feishu channel plugin ID is `"feishu"` (not `"@openclaw/feishu"`).

```json
{
  "plugins": {
    "allow": ["stepfun", "memory-core", "feishu"],
    "entries": {
      "feishu": { "enabled": true }
    }
  }
}
```

Both are important in practice:
- `plugins.allow` should include `"feishu"`
- `plugins.entries.feishu.enabled` should be true

A reliable way is:

```bash
openclaw config set plugins.entries.feishu.enabled true --strict-json
```

If this section changes, status may show `config change requires gateway restart (...)` and a full restart is required.

#### 4. Restart and Verify

```bash
# Kill all gateway processes (avoid stale/zombie conflicts)
pkill -9 -f "openclaw"
sleep 2

# Start fresh
openclaw gateway run &

# Check logs for Feishu connection
tail -f /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log | grep -iE 'feishu|channel'
```

**Expected successful output:**
```
[gateway] starting channels and sidecars...
[feishu] Connected in websocket mode (feishu)
```

**If you see `ready (0 plugins)`** → channel configuration not loaded or plugin blocked by allowlist.

### Debugging OpenClaw Feishu Issues

#### Check What Gateway Actually Loaded

OpenClaw logs in JSON lines format. Filter for channel events:

```bash
tail -200 /tmp/openclaw/openclaw-$(date +%Y-%m-%d).log |   python3 -c "
import sys, json
for line in sys.stdin:
    try:
        obj = json.loads(line)
        msg = str(obj.get('0', ''))
        if 'feishu' in msg.lower() or 'channel' in msg.lower():
            print(f"{obj.get('time','')} {msg[:300]}")
    except: pass
"
```

#### Common Pitfalls

| Symptom | Likely Cause | Fix |
|---------|-------------|-----|
| No Feishu logs at all | `channels.feishu.enabled: true` missing from `config.yaml` | Add `enabled: true` under `channels.feishu:` |
| `ready (0 plugins)` | `feishu` not in `openclaw.json.plugins.allow` array | Add `"feishu"` to `plugins.allow` |
| `duplicate plugin id` warning | User extension conflicts with built-in plugin | Remove/rename `~/.openclaw/extensions/feishu/` |
| `Plugin "feishu" not found` | Wrong plugin ID in `plugins.allow` | Use `"feishu"` (exact) |
| Gateway starts then exits immediately | Port conflict (18789/8080 already in use) | `pkill -9 -f openclaw` then restart |
| `Unauthorized user` in logs | User OpenID not in `config.yaml.channels.feishu.allowFrom` | Add your OpenID to allowFrom array |

#### Config Precedence and Merging

OpenClaw merges two config files at startup:
- `openclaw.json` (core): plugins, agents, gateway port, auth
- `config.yaml` (user): channels, skills, display, tools

Changes to **either** file require a full gateway restart. The `plugins.allow` array in `openclaw.json` controls which plugin IDs are permitted to load; `channels.feishu.enabled` in `config.yaml` controls whether the Feishu channel starts.

### Verification Checklist (OpenClaw)

- [ ] `openclaw config get channels.feishu` returns a populated object (enabled/appId/domain/connectionMode)
- [ ] `openclaw config get plugins.entries.feishu` shows enabled=true
- [ ] `openclaw config get plugins.allow` contains `"feishu"`
- [ ] No user extension at `~/.openclaw/extensions/feishu/` (built-in plugin used)
- [ ] Gateway restarted after config writes (`openclaw gateway restart`)
- [ ] `openclaw status --deep` shows `Feishu | ON | OK | configured`
- [ ] Test message in Feishu DM reaches Hermes

### Migration: Hermes Gateway → OpenClaw Gateway

If you previously used `hermes gateway run` and switched to `openclaw gateway run`:

1. **Config files moved:** `~/.openclaw/` replaces `~/.hermes/`
2. **Env vars moved:** Feishu settings from `.env` → `config.yaml.channels.feishu`
3. **Restart required:** Both systems read config only at startup
4. **Log location changed:** `/tmp/openclaw/*.log` vs `~/.hermes/logs/*.log`

See `lark-cli-usage` for lark-cli command patterns.

---

## Related Skills

- `lark-cli-usage` — lark-cli command patterns, user search, message formatting
- `lark-oauth-image-upload` — Fixing `drive:file.upload` permission errors