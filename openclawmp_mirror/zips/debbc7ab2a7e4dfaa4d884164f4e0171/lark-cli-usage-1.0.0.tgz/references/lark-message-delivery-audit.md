# Lark Message Delivery Audit & Remediation

## Purpose

When a user claims "I sent a message to X" but you need to verify it actually happened (or discover it didn't), use this skill. Provides a systematic approach to audit message delivery history and execute补救 (remediation) actions.

## Core Principle

**Trust but verify**: User statements about message sending are treated as claims requiring evidence. Always validate via session records before proceeding with follow-up actions.

## When to Use

- User says "I sent a message to Y yesterday" but you need to confirm before planning next steps
- Investigating whether a critical notification actually reached the recipient
- Follow-up workflows where message delivery status affects next actions
- Auditing communication trails for compliance or handoff purposes

## Do NOT Use For

- Normal routine message sending (use `lark-cli im +messages-send` directly)
- Active conversation monitoring (use `lark-message-manager` skill instead)
- Bulk message campaigns (requires different audit strategy)

## Procedure

### Step 1: Gather Claim Details

Collect from user (or context):
- **Recipient name** and/or user ID (e.g., `ou_xxx`)
- **Claimed send date/time** (approximate)
- **Expected content summary** (topic, key points)
- **Purpose** (info, request, follow-up)

If any detail is missing, **do not proceed** — ask for clarification first.

### Step 2: Locate Relevant Sessions

Search session history for the claimed timeframe:

```bash
# Find all sessions on the claimed date
find ~/.hermes/sessions -name "session_YYYYMMDD*.json"

# Or search by recipient name/ID across all sessions
grep -r "ou_recipientid" ~/.hermes/sessions/  # user ID
grep -r " recipient_name" ~/.hermes/sessions/  # name
```

**Tip**: Session files are named `session_YYYYMMDD_HHMMSS_hash.json`. Use date to narrow search.

### Step 3: Audit Each Candidate Session

For each candidate session file:

1. **Parse JSON structure**:
   ```python
   import json
   with open(session_file) as f:
       session = json.load(f)
   ```

2. **Search for `im +messages-send` terminal calls**:
   - Look for `tool: "terminal"` messages with `function.name: "terminal"`
   - Check `arguments.command` for `lark-cli im +messages-send`
   - Extract `--user-id` or `--chat-id` and content

3. **Verify three match criteria**:
   - ✅ **Recipient matches**: `--user-id` equals claimed recipient OR `--chat-id` contains recipient
   - ✅ **Timing matches**: Session timestamp aligns with claimed send time (±2 hours buffer)
   - ✅ **Content matches**: Markdown/text contains expected topic/keywords

4. **Record findings**:
   - Message ID (`om_xxx`)
   - Chat ID (`oc_xxx`)
   - Exact send time
   - Full content (for reference)

### Step 4: Determine Delivery Status

| Finding | Action |
|---------|--------|
| **Matching send record found** | ✅ Confirmed — proceed with follow-up planning |
| **No matching record in any session** | ❌ Not sent — execute **Remediation** (Step 5) |
| **Multiple conflicting records** | ⚠️ Ambiguous — list all candidates, ask user to clarify |
| **Sent to wrong recipient** | ❌ Mis-delivered — execute **Remediation** (Step 5) |

### Step 5: Remediation (When Message Was Not Sent)

**Do NOT blame or highlight the error**. Focus on solution:

1. **Compose correct message** (use original content if available, or recreate based on claim)
2. **Send immediately** using verified lark-cli auth
3. **Log the remediation** for audit trail:
   ```json
   {
     "remediation": true,
     "original_claim": "...",
     "actual_status": "not_found",
     "action": "sent",
     "recipient": "...",
     "message_id": "...",
     "sent_at": "...",
     "note": "补发消息 — 原记录未找到"
   }
   ```
4. **Report to user**: Include both the problem finding and the fix, succinctly

### Step 6: Document Outcome

Update session memory or project notes with:
- **Delivery status** (confirmed / remediated / ambiguous)
- **Key timestamps** (claimed vs actual)
- **Message reference** (ID, chat ID)
- **Next steps agreed** (wait for reply, schedule call, etc.)

## Example Workflow

**User claim**: "I sent a message to 丁江涛 (ou_75c2...) yesterday about ClawPhone-Task"

**Audit**:
1. Find sessions from 2026-04-24 → `session_20260424_160315_*.json`
2. Parse and search for `im +messages-send` with `ou_75c2...`
3. **Discovery**: Found 4 sends, but all to `ou_333...` (张隆强 himself), not 丁江涛
4. **Status**: ❌ Not sent to claimed recipient

**Remediation**:
1. Recreate message with correct content
2. `lark-cli im +messages-send --as user --user-id ou_75c2... --markdown "..."`
3. Log result: `{"remediation": true, "original_recipient": "丁江涛", "actual_recipient": null, "action": "sent"}`
4. Report: "消息未实际发送给丁江涛，已补发（消息ID: om_x100...）"

## Pitfalls to Avoid

- 🚫 **Don't assume** user memory is accurate — always verify
- 🚫 **Don't skip** sessions that seem unrelated — message could be in any chat
- 🚫 **Don't blame** — focus on fix, not fault
- 🚫 **Don't proceed without** recipient ID — names are ambiguous, OpenID is required
- 🚫 **Don't forget** to log remediation for future audits

## Verification Checklist

- [ ] Recipient user ID confirmed (not just name)
- [ ] All sessions from claimed date searched
- [ ] All `im +messages-send` calls examined
- [ ] Three-match criteria (recipient, time, content) evaluated
- [ ] If not found: remediation message composed and sent
- [ ] Audit log entry created
- [ ] User notified of status and any follow-ups needed

## Related Skills

- `lark-cli-usage`: Basic lark-cli command reference (used for sending)
- `lark-message-manager`: Ongoing chat monitoring and automated responses (different scope)

## Changelog

- **2026-04-25**: Created after discovering message to 丁江涛 was never actually sent despite user claim