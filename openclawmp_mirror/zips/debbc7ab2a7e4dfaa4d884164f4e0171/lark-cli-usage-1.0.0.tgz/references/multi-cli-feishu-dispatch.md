# Multi CLI Feishu Dispatch

## 适用场景
当你需要把飞书相关工作拆分后并行分配给多个本机 Agent CLI（Codex / Kimi / Cursor）时使用。

典型任务：
- A 负责找人和确认 open_id
- B 负责起草消息
- C 负责执行发送与回执核验

## 强制约束（必须注入到每个子任务提示词）
每个子 Agent 必须遵守以下规则（来自 lark-cli-usage）：

1) 所有 `--as user` 发送消息，结尾必须附加：
`*（本条消息由张隆强的Hermes代发）*`

2) 群聊 @ 必须使用：
`<at user_id="ou_xxx">姓名</at>`

3) 多行消息优先 `--markdown`，关键内容使用 `**加粗**`

4) 测试消息只允许发到：
`ai bot test (oc_d2c64625eefd31cf8b6ad12cbb409b32)`

5) 严禁向生产监控群发送测试（尤其）：
`记忆小群沟通 (oc_fb3806910414fe4f7f0b4400b48a8dc6)`

6) 找人优先使用：
`lark-cli contact +search-user --query "姓名" --as user --format json`

## 预检查
先确认 CLI 可用：

```bash
codex --version
kimi --version
cursor agent --help
lark-cli --version
```

## 分工模板
把任务拆为独立子任务，每个子任务都带上“强制约束”。

- 子任务A（信息检索）：联系人、群聊、历史上下文
- 子任务B（内容产出）：草拟消息 markdown 文案
- 子任务C（执行核验）：发送、检查 message_id、汇总回执

## 并行执行命令模板

### Codex（非交互）
```bash
codex exec "<完整子任务提示词>"
```

### Kimi（非交互）
```bash
kimi --print --output-format text -p "<完整子任务提示词>"
```

### Cursor Agent（非交互）
```bash
cursor agent --print "<完整子任务提示词>"
# 或
agent --print "<完整子任务提示词>"
```

## Hermes 中推荐执行方式
使用 `terminal(background=true)` 并行启动三个进程，然后用 `process wait/poll` 收集输出。

顺序：
1. 同时启动 3 个子进程
2. 轮询输出，若任一出现安全违规关键词（如生产群 chat_id）立即终止该进程
3. 收敛结果，统一做格式合规检查
4. 仅在通过检查后执行最终发送

## 合规检查清单（发送前）
- [ ] 是否含 `--as user`
- [ ] 是否带末尾免责声明（斜体）
- [ ] 若群聊消息，是否使用 `<at user_id="...">`
- [ ] 是否使用 `--markdown` 保留换行
- [ ] 测试消息是否仅投递到 `oc_d2c64625eefd31cf8b6ad12cbb409b32`
- [ ] 是否绝对未触达 `oc_fb3806910414fe4f7f0b4400b48a8dc6`

## 失败回退策略
- 任一子 Agent 输出命令不合规：丢弃该结果，不直接执行
- 两个子 Agent 结论冲突：以“更保守 + 可验证”的方案为准
- 发送失败：保留完整命令、报错、message_id（若有）并重试一次

## 建议输出格式（给 Hermes 主代理）
每个子 Agent 返回：
1) 我做了什么
2) 我建议执行的 lark-cli 命令
3) 风险点
4) 我的置信度

主代理最终汇总：
- 采用方案
- 执行命令
- 回执与后续动作

## 状态可观测性（过去 / 现在 / 未来）
这是本 skill 的核心增强点：必须让用户随时看到每个 Agent 的历史、当前状态和下一步计划。

### 统一状态模型
每个 Agent（codex/kimi/cursor）都用同一结构记录：
- agent: `codex | kimi | cursor`
- task_id: 子任务ID
- status: `planned | queued | running | blocked | waiting_human | done | failed | cancelled`
- past: 已完成动作列表（时间戳+摘要）
- now: 当前正在做的事
- future: 下一步（最多3条）
- risk: 风险/阻塞
- updated_at: 最近更新时间

### 持久化文件
建议固定状态文件：
- `~/.hermes/state/agent-dispatch-status.json`
- `~/.hermes/state/agent-dispatch-events.jsonl`

说明：
- `status.json` 保存每个 Agent 的最新快照（用于“现在/未来”）
- `events.jsonl` 追加事件流（用于“过去”审计）

### 事件流规范（events.jsonl）
每条一行 JSON，最小字段：
```json
{"ts":"2026-04-24T16:20:00+08:00","agent":"codex","task_id":"T1","event":"started","detail":"开始检索联系人 open_id"}
```

推荐事件类型：
- `planned`
- `started`
- `progress`
- `blocked`
- `waiting_human`
- `completed`
- `failed`
- `cancelled`

### 调度执行时机要求
1) 分配子任务前：先写 `planned/queued`
2) 子进程启动后：立刻写 `running + now`
3) 轮询输出时：按阶段写 `progress`
4) 命中风险（如生产群ID）：写 `blocked` 或 `failed`
5) 完成后：写 `done + past`，并刷新 `future` 为空

### 用户可读视图（必须提供）
每次汇报时输出三段：

1. 过去（Past）
- 最近 N 条关键事件（按时间倒序）

2. 现在（Now）
- 三个 Agent 当前状态表：
  - Agent | 状态 | 正在做什么 | 阻塞

3. 未来（Next）
- 每个 Agent 的下一步动作（1~3条）
- 全局下一里程碑和 ETA

### 快捷口令（建议）
- “看状态”：展示 Past/Now/Next 总览
- “看阻塞”：仅列 blocked/waiting_human
- “看历史”：回放最近 20 条 events
- “看计划”：只看 future 和 ETA

### 最低交付标准
若用户问“现在到哪了”，主代理必须在一次回复里给出：
- 每个 Agent 的当前 status
- 最近一次动作（past 最后一条）
- 下一步（future 第一条）
- 是否需要用户介入（waiting_human）