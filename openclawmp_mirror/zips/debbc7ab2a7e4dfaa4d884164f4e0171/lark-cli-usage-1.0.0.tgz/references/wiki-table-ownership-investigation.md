## When to Use

Use this skill when tasked with finding who previously owned or handled a feature, but the wiki table shows unassigned or empty owner columns. Requires parsing complex table structures with rowspan attributes, extracting user mentions, mapping IDs to names, and cross-referencing chat history.

## Approach Overview

This is an **investigative multi-hop process**:

1. Fetch wiki documents and parse table structure (handling rowspan)
2. Extract <mention-user> IDs from owner-related columns
3. Map IDs to names via chat membership or message history
4. Search chat history for technical discussions about the feature
5. Cross-reference document metadata (author, change history)
6. Distinguish between document author, mentioned stakeholders, and actual owners

## Step-by-Step Workflow

### Step 1: Fetch Relevant Wiki Documents

```bash
lark-cli docs +fetch --doc "<WIKI_URL>" --as user --format json
```

Save markdown output for parsing.

### Step 2: Parse Complex Table Structure

Wiki tables use HTML-like `<lark-table>`, `<lark-tr>`, `<lark-td>` tags with `rowspan` attributes:

- Identify all row start positions (`<lark-tr>`)
- For each row, extract all cells (`<lark-td>`) in order
- **Track rowspan values**: if a cell has `rowspan="N"`, the next N-1 rows have that cell implicitly present (column index does not increment for those rows)
- Build a corrected column mapping that accounts for rowspans

**Python parsing pattern**:
```python
import re
with open("wiki.md") as f:
    md = f.read()
lines = md.split('\n')
row_starts = [i for i, line in enumerate(lines) if '<lark-tr>' in line]

for idx, start in enumerate(row_starts):
    row_text = '\n'.join(lines[start:min(start+20, len(lines))])
    cells = re.findall(r'<lark-td[^>]*>(.*?)</lark-td>', row_text, re.DOTALL)
    # Track rowspan from previous rows to know which column each cell belongs to
```

### Step 3: Extract User Mentions from Owner Columns

Identify owner columns by header text: **产品Owner**, **研发owner**, **项目管理 owner**.

Extract all `<mention-user id="ou_xxx">` tags:
```python
mentions = re.findall(r'<mention-user id="([^"]+)"', cell_content)
```

**Important**: Mentions in description columns ≠ ownership. Only consider mentions in designated owner columns.

### Step 4: Map User IDs to Names

Use chat membership or message history:

```bash
# Get group members (use --page-all for complete list)
lark-cli im chat.members get --as user --params '{"chat_id":"<CHAT_ID>"}' --format json

# Search messages from specific user
lark-cli im +user-messages-list --user-id "ou_xxx" --as user --page-size 50
```

If API returns empty, extract names from message history:
```python
for msg in messages:
    if msg["sender"]["open_id"] == target_id:
        print(msg["sender"]["name"])
```

### Step 5: Search Chat History for Technical Discussions

Search relevant潘多拉 groups for keywords:
- 排期, 交付, 上线, 联调, 落地
- owner, 负责人, 跟进
- Feature-specific terms

```bash
lark-cli im +chat-messages-list --chat-id "oc_xxx" --page-size 100 --as user --format json
```

Look for messages that:
- Explain procedures or technical details
- Coordinate handovers or assignments
- Mention specific versions, timelines, or blockers
- @mention relevant people

### Step 6: Cross-Reference Document Metadata

Check document change history:
```bash
lark-cli docs +info --doc "<WIKI_URL>" --as user --format json
```

Look for fields like:
- `change_history` or `revision`
- `created_by`, `last_editor`
- `变更人` in wiki content

**Note**: Document author ≠ feature owner. The person who wrote the RPD may not be implementing it.

### Step 7: Synthesize Findings

Report with clear categories:
1. **Document author/change person** — who last edited the RPD
2. **Mentioned stakeholders** — people referenced in owner columns (if any)
3. **Assigned owners** — explicit 产品Owner/研发owner/项目管理 (often empty)
4. **Active discussants** — people who talked about the feature in chat
5. **Inference** — best guess based on frequency of mention, role in discussions

## Common Pitfalls

### Pitfall 1: Rowspan Misalignment
**Symptom**: Cells appear in wrong columns when parsing.
**Cause**: Table uses `rowspan` to merge parent cells across multiple rows.
**Fix**: Track active rowspan cells in a queue; decrement counters as rows progress; assign implicit columns accordingly.

### Pitfall 2: Owner Columns Empty
**Symptom**: No mentions in owner columns despite P0 priority.
**Cause**: Ownership not formally assigned in wiki yet.
**Fix**: Look for mentions in description column as potential stakeholders; search chat for who discussed the feature.

### Pitfall 3: Contact API Returns Empty
**Symptom**: `lark-cli contact +get-user` returns empty for valid open_id.
**Cause**: User may be external, deactivated, or API permission limited.
**Fix**: Fall back to extracting name from chat message history where that user sent messages.

### Pitfall 4: Chat Member List Empty
**Symptom**: Member list API returns no data.
**Cause**: External group, pagination, or permission issues.
**Fix**: Search all messages in the chat; collect unique sender names/IDs directly.

### Pitfall 5: Multiple Related Groups
**Symptom**: Information scattered across different chats.
**Cause**: Different groups for different purposes (进度跟进, 专项沟通, 内测).
**Fix**: Search all潘多拉-related groups: 进度跟进, AIOS专项沟通, 内测, 特性-整体交互框架.

## Example: Task Module Investigation

From actual usage on 2026-04-23:

1. **Fetched** V2.0 requirements from https://zyql.feishu.cn/wiki/CMV7wcUrqix8nYka7bacgjiwnee
2. **Parsed** 潘多拉需求总览 wiki table (130 rows, 11 columns, with rowspan)
3. **Found** task rows: 桌面主空间支持任务卡片展示, 桌面主空间支持任务状态流转, 任务卡片与system UI同步, AI空间支持任务卡片展示
4. **Discovered**: Owner columns were **empty** for all task rows
5. **Identified** most-mentioned user: `ou_8f93bc828905a053bcc0b6c5c7ec17fd` (26 mentions)
6. **Found** 薛晶 (Xue Jing, `ou_3e8e86555516e57e218e885269703f03`) mentioned only once in wiki (新用户引导 section)
7. **Checked** chat history: 薛晶 had 0 messages in all潘多拉 groups
8. **Cross-referenced**: Task RPD V1.2 had 变更人: Water (薛晶), but this is document editor not feature owner
9. **Conclusion**: No clear owner assignment in wiki; need to clarify with 骆世琪 or 孙国恩

## Command Reference

```bash
# Fetch wiki document
lark-cli docs +fetch --doc "<URL>" --as user --format json

# Get user info (may fail)
lark-cli contact +get-user --open-id "ou_xxx" --as user --format json

# Search users by name
lark-cli contact +search-user --query "姓名" --as user --format json

# Get group members
lark-cli im chat.members get --as user --params '{"chat_id":"oc_xxx"}' --format json --page-all

# Get group messages
lark-cli im +chat-messages-list --chat-id "oc_xxx" --page-size 100 --as user --format json

# Get direct messages with user
lark-cli im +user-messages-list --user-id "ou_xxx" --as user --page-size 50 --format json
```

## Decision Logic

When determining who to recommend as the contact:

1. **Primary**: Person who **explained the procedure** in chat (demonstrates hands-on expertise)
2. **Secondary**: Person who **coordinates/schedules** the work (has authority)
3. **Tertiary**: Person who **created the group or set its purpose** (organizational responsibility)

If document change person ≠ feature owner, clarify the distinction in your response.