## When to Use

Use this skill when tasked with consolidating handover documentation from a departing colleague, but the documents are **not centrally organized** in a dedicated folder. Instead, they are scattered across:

- Multiple chat/meeting record folders (智能纪要助手, 文字记录, etc.)
- Wiki spaces and standalone documents
- Shared folder permissions (folder appears empty but documents exist elsewhere)
- Referenced indirectly through index documents

## Core Challenge

**Misleading folder structure**: A folder named "Rui's personal documents" may appear empty or belong to someone else, but the actual handover documents exist as:
- Files scattered in shared team folders (owner shows as recipient, not originator)
- Documents where the person is only mentioned as a participant (not author)
- Wiki pages and index documents that reference many sub-documents

## Approach Overview

This is a **multi-hop investigative process**:

1. **Discover document locations** - don't assume centralized storage
2. **Search by person's ID** across all documents (not just folder membership)
3. **Identify handover keywords** ("接手", "移交", "交接", "handoff", "transfer")
4. **Follow document references** from index documents
5. **Cross-validate** by reading content to confirm relevance
6. **Create structured index** with categorization, links, and key findings

## Step-by-Step Workflow

### Step 1: Initial Reconnaissance

```bash
# List all folders/drives to understand structure
lark-cli drive files list --format json --page-all

# Check suspicious "personal" folders (may be shared, not owned)
lark-cli drive files list --parent-token "<FOLDER_TOKEN>" --format json --page-all

# Search for user ID in document content (more reliable than folder ownership)
lark-cli drive files list --format json --page-all | jq '.files[] | select(.name | contains("Rui") or .name | contains("罗"))'
```

**Key insight**: Folder `owner` ≠ document author. A folder named "Rui's documents" may have you as owner (shared access), but documents inside may still be authored by Rui (identified by open_id in content).

### Step 2: Find Documents by User ID

```bash
# Search for documents containing the user's open_id in content
# Use iterative approach: fetch docs and grep for open_id
for token in $(lark-cli drive files list --format json | jq -r '.[].token'); do
  content=$(lark-cli docs +fetch --doc "$token" --as user --format json 2>/dev/null)
  if echo "$content" | grep -q "ou_1b4ff6350a48df5414f34385d0bc7c42"; then
    echo "Found: $token"
  fi
done
```

**Python approach** (batch processing):
```python
import subprocess, json, re

rui_open_id = "ou_1b4ff6350a48df5414f34385d0bc7c42"

# Get all document tokens
result = subprocess.run(
    ['lark-cli', 'drive', 'files', 'list', '--format', 'json', '--page-all',
     '--params', json.dumps({"page_size": 200})],
    capture_output=True, text=True
)
data = json.loads(result.stdout)
tokens = [f['token'] for f in data['data']['files']]

# Search each for Rui's ID
found = []
for token in tokens:
    result = subprocess.run(
        ['lark-cli', 'docs', '+fetch', '--doc', token, '--as', 'user', '--format', 'json'],
        capture_output=True, text=True
    )
    if result.returncode == 0 and rui_open_id in result.stdout:
        found.append(token)
        print(f"Found Rui in: {token}")
```

### Step 3: Identify Index Documents

Look for documents that reference many other documents:

```bash
# Fetch candidate index docs
lark-cli docs +fetch --doc "IolCdrWvNoHpprxV9nfcuoq9n9e" --as user --format pretty

# Extract docx links from index
grep -o 'https://zyql.feishu.cn/docx/[A-Za-z0-9]*' index.md
```

**Pattern**: Index documents often have titles like:
- "整理一个prd吧，毕竟之前的文档非常碎"
- "需求总览"
- "PRD索引"
- "文档清单"

### Step 4: Search for Handover Keywords

```bash
# Fetch all candidate docs and grep for handover terms
handover_terms="接手|移交|交接|handoff|transfer|接收|接收人"
for token in "${tokens[@]}"; do
  content=$(lark-cli docs +fetch --doc "$token" --as user --format json 2>/dev/null)
  if echo "$content" | grep -E "$handover_terms" > /dev/null; then
    echo "[HANDOVER] $token"
  fi
done
```

**Context extraction**: When keyword found, print surrounding lines:
```python
lines = content.split('\n')
for i, line in enumerate(lines):
    if '接手' in line or '移交' in line:
        # Print context: 2 lines before and after
        for j in range(max(0, i-2), min(len(lines), i+3)):
            print(f"  Line {j}: {lines[j]}")
```

### Step 5: Handle Different Document Types

**Wiki documents** (use `--format pretty` or `--format json`):
```bash
lark-cli docs +fetch --doc "<TOKEN>" --as user --format json
```

**Regular docs** (may fail with unsupported type error):
```bash
# If json format fails, try without format or with different approach
lark-cli docs +fetch --doc "<TOKEN>" --as user
```

**Smart meeting summaries** (智能纪要): Read full content; they contain structured meeting notes with participants, decisions, and action items.

**Text transcripts** (文字记录): May be longer but contain raw conversation; useful for verifying handover details.

### Step 6: Follow Reference Chains

Index documents often link to sub-documents. Build the full graph:

```python
# BFS traversal of document references
visited = set()
queue = [index_token]

while queue:
    token = queue.pop(0)
    if token in visited:
        continue
    visited.add(token)
    
    # Fetch and extract links
    content = fetch_doc(token)
    linked_tokens = extract_doc_links(content)
    
    for linked in linked_tokens:
        if linked not in visited:
            queue.append(linked)
```

### Step 7: Categorize Documents

Create taxonomy by:
- **Date**: 2026年1月, 2月, etc.
- **Type**: 智能纪要 vs 文字记录 vs Wiki vs 索引文档
- **Topic**: PRD讨论, 测试方案, 竞品分析, 技术对接
- **Handover status**: 接手, 移交, 交接, 讨论中

### Step 8: Extract Key Handover Details

From handover-tagged documents, extract:
1. **What was handed off**: memory evolution, frontend pages, evaluation fields
2. **To whom**: Eason (host agent), 前端团队, 张隆强
3. **When**: Meeting date and any deadlines
4. **Conditions**: Code handoff, test set co-building, documentation required
5. **Open todos**: Items marked `[ ]` or "待办"

### Step 9: Create Structured Summary

Output format:
```markdown
# [Name] 交接文档总览

## 📋 核心摘要
[1-2 sentence summary of what was handed over]

## 📁 文档索引
### By Category
| Type | Count | Documents |
|------|-------|-----------|

### By Timeline
| Date | Doc | Token | Link | Key Points |

## 🔍 Key Handover Points
[Quoted excerpts with context]

## 📊 Statistics
- Total documents scanned: X
- Handover documents found: Y
- Wiki spaces: Z

## 🔗 Quick Access (Reading Order)
1. [Index Doc]()
2. [Competitor Analysis]()
3. [Main PRD Wiki]()

## 🎯 Recommended Next Steps
- [ ] Contact X about Y
- [ ] Read Z document
- [ ] Verify A with B
```

## Common Pitfalls & Solutions

### Pitfall 1: Empty "Personal Documents" Folder
**Symptom**: "Rui's personal documents" folder shows 0 files but should contain handover docs.

**Cause**: Folder is shared with you (you're the owner), but Rui's actual documents are in a different shared location (e.g., "Content transferred from 智能纪要助手").

**Fix**:
1. Check folder owner: `lark-cli drive files get --token <FOLDER_TOKEN>`
2. Search ALL files for Rui's `open_id` in content
3. Look for folders with similar names but different owners
4. Search by Rui's name/ID across all document content

### Pitfall 2: Permission Denied / Unsupported Document Type
**Symptom**: `Unsupported document type: Unknown` or `MCP: [VALIDATION:1005]`

**Cause**: Some doc formats require specific permissions or aren't supported by current lark-cli version.

**Fix**:
1. Try `--format json` vs `--format pretty` vs no format flag
2. Check if `search:docs:read` scope is authorized: `lark-cli auth login --scope search:docs:read`
3. Fall back to fetching as text without format specifier
4. If truly inaccessible, note "requires permission" and move on

### Pitfall 3: User ID Mismatch
**Symptom**: Can't find Rui's documents even though they exist.

**Cause**: Using wrong open_id. User has multiple IDs across apps.

**Fix**:
1. Search by name: `lark-cli contact +search-user --query "罗"` or `"Rui"`
2. Find all occurrences of user mentions in documents: `grep -r "mention-user.*ou_" docs/`
3. Cross-reference with known participant lists from meeting summaries
4. Document both IDs: "Rui has open_id X in app A, Y in app B"

### Pitfall 4: Documents Too Large / Truncated
**Symptom**: Output truncated, missing key sections.

**Fix**:
1. Use `--format json` for full structured content
2. Save to file: `lark-cli docs +fetch ... > doc.json`
3. Parse JSON and extract specific sections by token/reference
4. For large meeting summaries, extract only `<quote-container>` or `总结` sections

### Pitfall 5: Index Document References Broken
**Symptom**: Index links to non-existent documents (404).

**Fix**:
1. Verify each token individually before including in final index
2. Note inaccessible docs clearly: `[ inaccessible - permission required ]`
3. Don't assume index is complete; supplement with independent search results

### Pitfall 6: Confusing Document Author vs Handoff Recipient
**Symptom**: All documents show your user ID as `owner`, leading to confusion about who authored them.

**Fix**:
1. Read document content for `<mention-user>` tags to see who participated
2. Check meeting participant lists (参会人)
3. Look for context: "Rui introduced...", "张隆强计划..."
4. Document author ≠ handoff recipient. Clarify roles in summary.

## Command Reference

```bash
# List all files (recursive)
lark-cli drive files list --format json --page-all

# Get file metadata
lark-cli drive files get --token <TOKEN> --format json

# Fetch document content
lark-cli docs +fetch --doc <TOKEN> --as user --format json

# Search users
lark-cli contact +search-user --query "姓名" --as user

# Get user by open_id
lark-cli contact +get-user --open-id "ou_xxx" --as user --format json

# Get chat members
lark-cli im chat.members get --chat-id "oc_xxx" --as user --format json --page-all

# Search chat messages
lark-cli im +chat-messages-list --chat-id "oc_xxx" --page-size 100 --as user --format json

# Authorize additional scopes if needed
lark-cli auth login --scope search:docs:read --no-wait
```

## Decision Logic

When categorizing documents:

1. **Primary category**: By **topic** (PRD, 测试, 竞品, 技术对接)
2. **Secondary sort**: By **date** (chronological)
3. **Tertiary**: By **type** (智能纪要 vs 文字记录)
4. **Highlight**: Documents with explicit handover keywords ("接手", "移交", "交接")

When uncertain about handoff status:
- Default to "讨论中" (under discussion) rather than "已交接"
- Quote exact text that indicates handoff
- Note uncertainty: "文档提到'需要找预算'但未明确交接对象"

## Example Output Structure

```
Rui（罗）交接文档总览

## 📋 核心摘要
Rui 从"记忆模块"产品岗向张隆强完成了完整的工作交接...

## 📁 文档索引
### Wiki 空间
| 文档名 | Token | 链接 |
| Memory System PRD | J0EwwfWuEi... | https://...

### PRD 子文档（按时间）
| 日期 | 文档名 | Token | 关键内容 |
| 1月26日 | 记忆模块与APEX工作会议 | VUPpdlbc... | **交接关键**：记忆演化由张隆强接手 |

## 🔍 Key Handover Points
### 1. 记忆演化接手 (1月26日)
> "记忆演化己方接手，Eason 表示赞同，会分享代码..."

## 📊 Statistics
- Scanned: 83 files
- Found: 6 with Rui's ID
- Handover docs: 3 confirmed

## 🎯 Recommended Next Steps
- [ ] Contact Eason for host agent code
- [ ] Verify frontend handoff with 胡博
```

## Success Criteria

A successful consolidation includes:
- ✅ **All relevant documents found** (by ID search, not just folder browsing)
- ✅ **Handover keywords identified** with quoted context
- ✅ **Document links verified** (each URL tested or clearly marked inaccessible)
- ✅ **Timeline clear** (chronological progression of handoff)
- ✅ **Responsibilities mapped** (who handed what to whom)
- ✅ **Next steps actionable** (specific contacts, documents to read, verifications needed)

## Required Environment

- `lark-cli` installed and authenticated (OAuth token valid)
- `search:docs:read` scope authorized (may need re-auth)
- `jq` for JSON processing (optional but helpful)
- Shell with ability to run iterative loops (bash/zsh)