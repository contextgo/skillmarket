# lark-cli User Authorization Troubleshooting

## When to Use
Use this skill when:
- `lark-cli` commands with `--as user` fail with `need_user_authorization` error
- User token exists but API calls still use bot identity
- `lark-cli auth list` shows no logged-in users
- You need to switch from bot-only to user operations

## Symptoms
```json
{
  "error": {
    "type": "api_error",
    "message": "API call failed: need_user_authorization (user: )"
  }
}
```

OR config shows:
```json
{
  "defaultAs": "bot",
  "strictMode": "bot"
}
```

## Diagnostic Steps

### Step 1: Check Current Auth Status
```bash
lark-cli auth list
```
Expected output for logged-in user:
```
user: <user_id> (ou_xxx)
  scopes: im:message drive:file.upload ...
  expires: <timestamp>
```
If empty → **no user token exists**

### Step 2: Check Config Mode
```bash
lark-cli config show
# or read ~/.lark-cli/hermes/config.json
```

Look for:
- `"defaultAs": "bot"` — forces bot identity
- `"strictMode": "bot"` — rejects all user calls
- `"defaultAs": "user", "strictMode": "user"` — correct for user ops

### Step 3: Check Proxy Interference
Gateway logs showing `protocol mismatch` or `socks5:` errors indicate proxy blocking:
```bash
# Check if proxy is set
echo $ALL_PROXY $HTTP_PROXY $HTTPS_PROXY

# Disable for lark-cli
export LARK_CLI_NO_PROXY=1
```

## Fix Procedure

### Fix 1: Switch Config to User Mode (if in bot-only)
```bash
# Set default identity to user
lark-cli config default-as user

# Set strict mode to user (allows user calls)
lark-cli config strict-mode user
```

**Note:** These are separate commands. `default-as` sets default, `strict-mode` controls enforcement.

Verify:
```bash
lark-cli config show
# Should show: "defaultAs": "user" and strictMode: user
```

### Fix 2: Complete Device Code OAuth Flow

**⚠️ CRITICAL AGENT BEHAVIOR RULE — DO NOT EXIT AFTER SHOWING URL**
After generating the device code and showing the verification URL, you MUST immediately call the blocking `--device-code` command below. Do NOT exit, return a summary, or wait for the user to message back — the `--device-code` command blocks until the user authorizes. If you exit prematurely, the device code is wasted and the user has to authorize again from scratch.

**Step 2.1: Generate device code** (with proxy disabled)
```bash
export LARK_CLI_NO_PROXY=1  # if proxy causes issues
lark-cli auth login --no-wait --domain drive,im
```

Output:
```json
{
  "device_code": "...",
  "verification_url": "https://accounts.feishu.cn/oauth/v1/device/verify?flow_id=...&user_code=XXXX-XXXX",
  "user_code": "XXXX-XXXX",
  "expires_in": 600
}
```

**Step 2.2: Get user approval**
Send `verification_url` to user. Tell them to:
1. Open URL in browser/Feishu app
2. Confirm user code matches
3. Click "同意" (Approve)

**Step 2.3: Block until user authorizes (MANDATORY — do not skip this step)**
```bash
lark-cli auth login --device-code "<device_code>" --domain drive,im
```
This command **blocks until the user authorizes or 10-minute timeout**. You MUST call this with a generous timeout (120s+). Do NOT skip this step — without it, the authorization is wasted and the user must start over.

**⚠️ KNOWN ISSUE: Device code flow may invalidate existing token**
After `lark-cli auth login --device-code <code>` shows "授权成功", `lark-cli auth list` may return "No logged-in users" even though the scopes were temporarily granted. This appears to be a lark-cli bug where the device code completion overwrites or clears the stored user token. Symptoms:
- `--image` or `--as user` commands work briefly after authorization
- Then fail with `need_user_authorization`
- `auth list` shows no users

**Workaround**: If this happens, run a fresh `lark-cli auth login --no-wait` (not `--device-code`) and have the user complete authorization through the browser URL. This creates a clean token. The `--device-code` flow should be used only when you need to add scopes to an existing token, and you should verify immediately afterward.

**Step 2.4: Verify scopes**
Use the correct scope name format (colons, not dots):
```bash
# ✅ Correct — colon-separated
lark-cli auth check --scope "drive:file:upload"

# ❌ Wrong — dot-separated (lark-cli's own suggestion is misleading!)
lark-cli auth check --scope "drive:file.upload"
```
The actual granted scope name is `drive:file:upload` (with double colons). The `drive:file.upload` (with a dot) format that lark-cli sometimes suggests is incorrect and will report as missing even when the scope is present.

**Alternative non-blocking:** Just wait ~30 seconds after user approves, then retry the original command — lark-cli auto-refreshes token once device flow completes. But prefer the blocking approach above — it's more reliable.

### Fix 3: Clean Stale Device Codes (if needed)
If many expired device code files accumulate in `~/.lark-cli/cache/auth_login_scopes/`, delete them:
```bash
rm ~/.lark-cli/cache/auth_login_scopes/*.json
```

Then restart from Fix 2.

### Fix 4: Verify Success
```bash
lark-cli auth list
# Should show user token with scopes

lark-cli auth check --scope "im:message drive:file.upload"
# Should return: {"ok": true}
```

Then retry the original command (e.g., `lark-cli im +chat-search --as user ...`).

## Common Pitfalls

| Symptom | Cause | Fix |
|---------|-------|-----|
| `need_user_authorization` after device code | User didn't approve, or device code expired | Generate new device code, ensure user clicks approval |
| `protocol mismatch` / `socks5:` errors | Proxy interfering with OAuth callbacks | Set `LARK_CLI_NO_PROXY=1` or unset `ALL_PROXY` |
| `unknown flag: --format` on some commands | lark-cli version < 1.0.0 | Upgrade: `npm install -g @larksuite/cli@latest` |
| `identity: "bot"` despite `--as user` | `strictMode: bot` in config | `lark-cli config strict-mode user` |
| `drive:file.upload` shown as missing despite successful auth | Scope name format mismatch — actual scope is `drive:file:upload` (colons) | Use `lark-cli auth check --scope "drive:file:upload"` with colons, not dots |

## Quick Reference Commands
```bash
# Check status
lark-cli auth list
lark-cli config show

# Fix config (one-time)
lark-cli config default-as user
lark-cli config strict-mode user

# Authorize (when needed)
export LARK_CLI_NO_PROXY=1
lark-cli auth login --no-wait --domain drive,im
# → Send verification_url to user, then IMMEDIATELY:
lark-cli auth login --device-code "<code>" --domain drive,im  # blocks until done

# Verify scopes (use colons, NOT dots)
lark-cli auth check --scope "drive:file:upload"
```

## Related
- Skill: `lark-cli-usage` — general lark-cli command reference (includes message format rules and --as user requirements)
- Skill: `lark-cli-update` — version management and upgrade troubleshooting