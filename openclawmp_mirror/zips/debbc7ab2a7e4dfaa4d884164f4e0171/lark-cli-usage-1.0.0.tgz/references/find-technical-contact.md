## When to Use

Use this skill when you need to identify who is responsible for a specific technical task (e.g., device flashing, demo deployment, test environment setup) but don't know the person's name or exact group membership.

## Approach Overview

This is an **investigative multi-hop process** that requires:

1. **Identify relevant group chats** (not just searching contacts directly)
2. **Extract message history** to find people who discussed the topic
3. **Cross-reference** group membership, tenant keys, and organizational context
4. **Verify** the person is actually in relevant groups and has the right expertise
5. **Handle incomplete information** when direct contact search fails

## Step-by-Step Workflow

### Step 1: Find Relevant Group Chats

Start with group chat searches, not contact searches:

```bash
# Search for likely relevant groups
lark-cli im +chat-search --query "体验测试" --as user
lark-cli im +chat-search --query "深圳" --as user
lark-cli im +chat-search --query "demo" --as user
```

**Key insight**: Technical infrastructure discussions often happen in specialized group chats (e.g., "AIOS体验测试群"), not in department-wide groups. The person responsible may NOT appear in direct contact search for technical keywords.

### Step 2: Identify Key Groups and Their Members

For each promising group, get the member list:

```bash
# Get members (use --page-all for complete list)
lark-cli im chat.members get --as user --params '{"chat_id":"<CHAT_ID>"}' --format table
```

**Watch for**: Group names that indicate focus (体验测试, demo, 部署, 刷机, ROM, 固件).

### Step 3: Search Message History for Technical Discussions

Search within relevant groups for past discussions about the task:

```bash
# Get recent messages
lark-cli im +chat-messages-list --chat-id "<CHAT_ID>" --page-size 100 --as user
```

**Look for**:
- Messages that explain procedures (flashing, signing, deployment)
- People offering to help or coordinating
- Questions about test environments/demo systems
- References to specific tools (pixel devices, ROM versions, APK signing)

**Extract**: Sender names, their statements about the task, and who they @mention.

### Step 4: Cross-Reference Multiple Data Points

When you identify a candidate (e.g., 黄成钟), verify through multiple angles:

```bash
# Check if they're in the relevant group
lark-cli im chat.members get ... | grep "<NAME>"

# Check their tenant_key matches relevant groups
# Compare: AIOS体验测试群 tenant_key vs. 深圳办公室大群 tenant_key

# Get their user details
lark-cli contact +get-user --user-id "<OPEN_ID>" --as user --format json
```

**Important**: A person might have been a group creator/organizer but later removed from membership — they may still be the right contact through private message.

### Step 5: Identify Backup Contacts

From message history, identify secondary contacts who also discussed the topic:

- People who asked for help (they may know who actually helps)
- People who provided SOPs or documentation links
- People who mentioned specific tools/versions

### Step 6: Verify Location/Relevance (If Needed)

If the task specifies a location (e.g., "Shenzhen"), confirm:

1. The person is in a Shenzhen-based group (深圳办公室大群)
2. Their tenant_key matches Shenzhen groups
3. They're mentioned in Shenzhen-relevant contexts

## Common Pitfalls and Solutions

### Pitfall 1: Contact search returns no results for technical keywords
**Why**: Technical terms (刷机, 固件, ROM) may not be in user names or profiles.
**Solution**: Search group chats instead; look for people who discussed these topics in messages.

### Pitfall 2: JSON parsing errors with `--format json`
**Why**: Some API responses have unusual structure or empty results.
**Solution**: Switch to `--format table` or inspect raw output. Use string matching (`'黄成钟' in output`) instead of JSON parsing when needed.

### Pitfall 3: Pagination issues with lark-cli
**Wrong**: `--page-size` on `chat.members get` (doesn't exist)
**Correct**: `--page-all` flag to auto-paginate, or inspect multi-page output manually.

### Pitfall 4: Cannot access external group member lists
**Error**: `API error: [232033] The operator or invited bots does NOT have the authority to manage external chats.`
**Solution**: Skip external groups; focus on internal groups you can access.

### Pitfall 5: Candidate not in current group members
**Observation**: Person appears in message history but not current member list.
**Inference**: They may have been removed but were the original responsible person. Still valid contact via private message.

## Example: Finding the Flashing Contact

From actual usage:

1. **Found group**: "AIOS体验测试群" (`oc_a230cccea86841ca23cf19fc4a92ee29`)
2. **Found key message** (2026-01-30, from 黄成钟):
   > "现在的版本，特别涉及gui-agent，是需要刷机和安装带系统签名的APK的...建议是你想看的时候找人帮忙搞一台pixel机子，环境和版本先给你弄好了。"
3. **Cross-referenced**: 
   - 黄成钟 created the group and set its purpose
   - He @mentioned Michael about flashing
   - Others @him about test environment coordination
4. **Confirmed location**: Same tenant_key (`1b06dacf3b9e575e`) as Shenzhen office group
5. **Conclusion**: 黄成钟 (open_id: `ou_5b665c611aa9627d94369f7a589db524`) is the contact
6. **Backup**: 刘胜转发过SOP并提到ROM版本，可能是具体执行者

## Command Reference

```bash
# Search users (limited)
lark-cli contact +search-user --query "<KEYWORD>" --as user --format json

# Get specific user info
lark-cli contact +get-user --user-id "<OPEN_ID>" --as user --format json

# Search group chats
lark-cli im +chat-search --query "<KEYWORD>" --as user --format json

# Get group members
lark-cli im chat.members get --as user --params '{"chat_id":"<CHAT_ID>"}' --format table --page-all

# Get group messages
lark-cli im +chat-messages-list --chat-id "<CHAT_ID>" --page-size 100 --as user

# Get group info
lark-cli im chat.get --as user --params '{"chat_id":"<CHAT_ID>"}' --format json
```

## Decision Logic

When deciding who to recommend:

1. **Primary**: Person who **explained the process** (demonstrates expertise)
2. **Secondary**: Person who **coordinates/schedules** (has authority)
3. **Tertiary**: Person who **asked for the service** (may know who provides it)

If only one person appears in both message content and coordination roles, they're the clear contact.