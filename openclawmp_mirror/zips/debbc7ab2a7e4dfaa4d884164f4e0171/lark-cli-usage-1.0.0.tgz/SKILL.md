---
name: lark-cli-usage
description: Working with lark-cli (Feishu/Lark CLI) — search chats, find users, send messages, command structure quirks
triggers:
  - lark-cli
  - feishu
  - lark
  - im messages
---

# lark-cli Usage

## When to Use
Use this skill for any task involving lark-cli (Feishu/Lark command-line tool) including:
- Searching for chats or contacts
- Sending messages to users or groups
- Managing group members
- Querying chat information

## Command Structure Quirks
**Important**: lark-cli uses mixed syntax:
- Some subcommands use `+` prefix: `+chat-search`, `+messages-send`
- Some use dot notation: `chat.members get`, `messages-send`
- Parameters often passed via `--params` JSON flag, not direct CLI flags
- Always use `--as user` to operate as the logged-in user identity

### ⚠️ CRITICAL: strictMode Overrides --as Flag
The config's `strictMode` setting **overrides** any `--as` flag you pass on the command line:

| strictMode | Effect |
|------------|--------|
| `bot` | ALL calls forced to bot identity, even with `--as user` |
| `user` | ALL calls forced to user identity, even with `--as bot` |
| `auto` (default) | Respects `--as` flag |

**Symptoms:**
```bash
lark-cli im +chat-search --as user ...
# Returns: {"identity": "user", "error": {"type": "api_error", "message": "need_user_authorization"}}
```
Even though you passed `--as user`, the call is still user identity but **no user token exists** — because strictMode forced user identity but you never logged in as user.

**Fix:**
```bash
# Check current strictMode
lark-cli config show

# Switch to user mode (one-time)
lark-cli config default-as user    # sets default identity
lark-cli config strict-mode user   # allows user operations

# Then authorize if needed (see "Handle Permission Errors" below)
```

**Why this happens:** Hermes binds lark-cli with `strictMode: bot` by default for security. You must explicitly switch to `user` mode and complete OAuth before user operations work.

### 📋 Image Upload Permission Diagnosis (2026-04-24 Discovery)
**Actual permission needed for images:** `im:resource:upload` (NOT `drive:file.upload`)

**Check your current scopes:**
```bash
lark-cli auth scopes
```

**Look for these in output:**
- ✅ `im:resource:upload` — allows image upload (both `--image` and markdown URL pre-fetch)
- ✅ `im:resource` — base resource permission (may be sufficient)
- ❌ Missing both → images will fail with `Unauthorized` or `image_key not found`

**Workaround if missing `im:resource:upload`:**
1. Use emoji/plain text instead of images (immediate, no permissions needed)
2. Request app upgrade to add `im:resource:upload` scope via Feishu open platform
3. Use external image host that doesn't require pre-fetch (limited — Lark pre-fetches URLs client-side anyway)

**Why markdown image URLs still fail without permission:**
```bash
lark-cli im +messages-send --as user --chat-id <cid> --markdown '![alt](https://example.com/img.jpg)'
# stderr: "uploading image from URL: example.com/img.jpg"
# error: "required one of these privileges: [im:resource:upload, im:resource]"
```
Lark client pre-downloads and re-uploads all image URLs through the API, triggering the same permission check as `--image`.

## Find a User's Open ID

### Preferred: Direct User Search (Recommended)
Use `contact +search-user` to search the company directory/contacts directly. This works for any user in the tenant, regardless of group chat membership.

```bash
lark-cli contact +search-user --query "用户名关键词" --as user --format json

# Extract open_id from results (field: open_id)
lark-cli contact +search-user --query "Rui" --as user --format json | python3 -c \
  "import sys, json; data=json.load(sys.stdin); [print(f\\\"{u.get('name','')}: {u.get('open_id','')}\\\") for u in data.get('users',[])]"
```

### Fallback: Via Group Chat Membership
Only use if direct search fails. Search group chats the user is in, then extract their open_id.

```bash
# 1. Find a chat the user is in
lark-cli im +chat-search --query "关键词" --as user

# 2. Get members of that chat (note: --params JSON, not --chat-id)
lark-cli im chat.members get --as user --params '{"chat_id":"<chat_id>"}' --format json

# 3. Extract open_id (field: member_id)
lark-cli im chat.members get --as user --params '{"chat_id":"<chat_id>"}' --format json | python3 -c \
  "import sys, json; data=json.load(sys.stdin); [print(f\\\"{m.get('name','')}: {m.get('member_id','')}\\\\\\\") for m in data.get('items',[])]"
```

**Note**:
- `contact +search-user` is the **preferred method** — covers all tenant users
- `+chat-search` only searches group chats, not direct messages
- In member list responses, `member_id` is the user's open_id

### ⚠️ "open_id cross app" Error
If `contact +search-user` finds a user but sending a message fails with `HTTP 400: open_id cross app`, it means the `open_id` belongs to a different app/tenant context than your current token.

**Symptoms:**
```bash
lark-cli im +messages-send --as user --user-id "ou_xxxx" --text "test"
# Returns: {"ok": false, "error": {"type": "api_error", "code": 99992361, "message": "HTTP 400: open_id cross app"}}
```

**Fix methods (try in order):**

**Method A: Use the auth flow's returned open_id (fastest)**
When you run `lark-cli auth login --device-code <code>` and it completes successfully, the output shows:
```
OK: 授权成功! 用户: 张隆强 (ou_01b6490246a7a1d984796493275ddd15)
```
This `open_id` is guaranteed valid for your current app/tenant context. Save it for future use.

**Method B: Get open_id from group membership**
```bash
# Find a group chat where the user is a member
lark-cli im +chat-search --query "群名" --as user --format json

# Get members and extract their actual open_id for your tenant
lark-cli im chat.members get --as user --params '{"chat_id":"oc_xxx"}' --format json | \
  python3 -c "import sys, json; data=json.load(sys.stdin); \
  [print(f\\\\\"{m['name']}: {m['member_id']}\\\\\") for m in data.get('items',[])]"
```

**Why this happens:** Users can have different `open_id` values across different apps/tenants. The `contact +search-user` result may show an `open_id` from a different app context. The group member list always returns the `open_id` valid for your current tenant. The auth flow's success message returns the tenant-correct open_id directly.

## Send a Direct Message

### Format Requirements (MANDATORY)
All messages sent via `--as user` must include:
1. **Disclaimer**: `*（本条消息由张隆强的Hermes代发）*` (italic, with parentheses)
2. **Markdown for multi-line**: Use `--markdown` to preserve line breaks
3. **Key points in bold**: Wrap important content with `**`
4. **@ mentions in groups**: Use structured format `<at user_id="ou_xxx">姓名</at>`

```bash
# Single-line direct message (no newlines needed)
lark-cli im +messages-send --as user --user-id <open_id> --text "消息内容"

# Multi-line group message with @mention and bold
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  $'**重点内容**\n详情如下：\n\n<at user_id="ou_xxx">姓名</at> 请确认\n\n*（本条消息由张隆强的Hermes代发）*'
```

**Critical**: Disclaimer must be on its own line at the end. Use `--markdown` for any message with multiple lines to ensure line breaks render correctly.

## Message Tone and Audience

### Message Composition Principles
When sending messages as the user (with `--as user`), consider the audience:

**For Peers/Team Members:**
- Friendly but professional
- Can use mild humor if appropriate to context
- Keep it concise and actionable

**For New Leaders/Managers:**
- **Avoid excessive flattery** — comes across as insecure or insincere
- **Be concise and professional** — state identity, express willingness, ask for guidance
- **Focus on collaboration** — "我会全力配合您的工作安排" is good; "请您多指导" can sound deferential but acceptable in Chinese context if not overdone
- **Bad example (too sycophantic):** "欢迎加入！很高兴接下来向您汇报工作，后续我会全力配合您的工作安排，请您多指导" — too many exclamation points, overly eager
- **Better example (balanced):** "你好，我是张隆强。听说您来带团队，很高兴接下来向您汇报，我会全力配合您的工作安排。" — direct, professional, no excessive praise

**Template for new leader announcement:**
```
@<LeaderName> 你好，我是<你的名字>。接下来向您汇报工作，我会全力配合您的工作安排。

*（本条消息由张隆强的Hermes代发）*
```

**For External/Client Communications:**
- More formal, avoid slang
- Explicit value statements
- Clear next steps

### @Mention Format in Group Chats
```bash
# Format: <at user_id="ou_xxx">Display Name</at>
# Use the user's actual open_id from contact search
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  '<at user_id="ou_333311bc7d65b56626beea49018f48af">Jack Zhu</at> 您好，消息内容'
```

**Note:** `<at>` tag only works in group chats, not in 1:1 DMs. In DMs, just use normal text.

### Multi-line Message Formatting
Use `--markdown` flag to preserve line breaks in group chats:
```bash
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  $'Line 1\nLine 2\nLine 3\n\n*（本条消息由张隆强的Hermes代发）*'
```

Without `--markdown`, the message becomes a single line. Use `--text` for single-line messages only.

## Send a Group Chat Message with @
```bash
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  $'<at user_id="ou_xxx">姓名</at> 消息内容\n\n*（本条消息由张隆强的Hermes代发）*'
```

**Note:** `<at>` tag only works in group chats, not in 1:1 DMs.

### ⚠️ Bash Quoting: Newlines in --markdown

**在 bash 中，`\n` 只有在 `$'...'`（ANSI-C 引号）中才是真正的换行符。**

```bash
'第一行\n第二行'    # ❌ 字面文本，显示为 "第一行\n第二行"
"第一行\n第二行"    # ❌ 字面文本，bash 双引号不解析 \n
$'第一行\n第二行'   # ✅ 真正的换行符
```

**所有含换行的 --markdown 消息必须用 `$'...'` 写法。**

### ⚠️ Bash `&` 字符在单引号中仍会触发后台进程

**尽管在单引号内，`&` 仍被 bash 解释为后台命令分隔符。**

```bash
# ❌ 失败 — bash 将 `&` 视为后台命令
lark-cli im +messages-send --as user --user-id "ou_xxx" --markdown 'Plan & Replan'

# ✅ 正确 — 替换 & 为 "and" 或转义
lark-cli im +messages-send --as user --user-id "ou_xxx" --markdown 'Plan and Replan'
```

**解决方案：** 在 --markdown 的字符串中用 `and` 替代 `&`，或将内容写入文件后通过 `@file` 传入。

### Proper Multi-line Message Format

When you need @mention, content (text/emoji), and disclaimer all in **one message**:

```bash
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  $'<at user_id="ou_xxx">姓名</at> 消息正文\n\n**重点加粗**\n更多内容...\n\n*（本条消息由张隆强的Hermes代发）*'
```

**Format rules:**
- Use `$'...\n...'` for multi-line (single quotes produce literal `\n`)
- `<at>` tag goes inline at the start of the message
- Disclaimer on its own last line, italicized with `*...*`
- Bold important content with `**...**`
- Links on separate lines (optional but clean)

**Correct example:**
```bash
lark-cli im +messages-send --as user --chat-id oc_d2c64625eefd31cf8b6ad12cbb409b32 --markdown \
  $'<at user_id="ou_5d879b7ebc70ef6ffc889ac0f50428ae">胡泰东</at> 看我发的迪迦奥特曼表情！🤖✨🚀\n\n| 符号 | 表情 |\n|------|------|\n| 迪迦 | 🦸 |\n| 点赞 | 👍 |\n\n*（本条消息由张隆强的Hermes代发）*'
```

### Image-in-Message Fallback (When `im:resource:upload` Missing)
If you lack image upload permission, use emoji/unicode symbols instead:

```bash
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  '<at user_id="ou_xxx">姓名</at> 表情符号替代：🦸👍✨\n\n*（本条消息由张隆强的Hermes代发）*'
```

**Why emoji works:** Pure text requires no special permissions; `im:message.send_as_user` scope covers it.

## Search Chats by Name
```bash
lark-cli im +chat-search --query "群名关键词" --as user --format json
```

## Version & Permissions

### Check Version
```bash
lark-cli --version   # Should be 1.0.0+
```
**Notice**: The skill documentation mentions v1.0.14 as the version when certain changes were introduced. Your actual installed version may be newer. Always run `lark-cli --version` to check your current version.

### Diagnose Image Upload Permissions (Quick Check)
```bash
# Step 1: List all current scopes
lark-cli auth scopes --format json | python3 -c "
import sys, json
data = json.load(sys.stdin)
scopes = data.get('userScopes', [])
need = ['im:resource:upload', 'im:resource', 'im:message.send_as_user']
for s in need:
    status = '✅' if s in scopes else '❌ MISSING'
    print(f'{s}: {status}')
"

# Step 2: If im:resource:upload is missing, generate re-auth link
lark-cli auth login --no-wait --scope "im:resource:upload im:resource im:message.send_as_user"
```

**Expected output when missing `im:resource:upload`:**
```
stderr: "required one of these privileges under the user identity: [im:resource:upload, im:resource]"
rc: 1
```

**Common confusion:** `im:resource` (read-only) ≠ `im:resource:upload` (write/upload). Both must be granted.

### 授权诊断

权限诊断和授权详见专门的 skill：`lark-cli-user-auth-troubleshooting`

快速检查：
```bash
# 检查 token 状态
lark-cli auth list
lark-cli config show
lark-cli auth check --scope "drive:file:upload"   # 注意用冒号 drive:file:upload
```

### OAuth URL Format Pitfall
When manually constructing authorization URLs, **use comma-separated scopes**:

```bash
# ✅ Correct — comma-separated
scope=drive:file.upload,im:message

# ❌ Wrong — space-separated causes "invalid_scope" error
scope=drive:file.upload im:message
```

**Why:** The `/open-apis/authen/v1/authorize` endpoint expects comma-separated scope values. URL-encoded, this becomes `drive%3Afile.upload%2Cim%3Amessage` (note the `%2C` for comma).
## Send Images

### Direct Image Upload Requirements (v1.0.14+)
```bash
# --image requires:
# 1. Relative path within current directory (not absolute like /tmp/xxx)
# 2. Permission: im:resource:upload (NOT drive:file.upload)
# 3. File must exist in current working directory

cd /path/to/image_dir
lark-cli im +messages-send --as user --chat-id <chat_id> --image ./filename.png
```

**If image upload fails with "image_key not found" or "Unauthorized":**
- The user token lacks `im:resource:upload` scope (common default)
- Re-authorize with `im:resource:upload` scope added to app, or use workarounds below

### ⚠️ Markdown `![alt](URL)` 图片不会渲染（已验证）

**即使 `ok=true`，图片也不会出现在消息中。**

实测验证（2026-04-24，公网图 + 飞书 CDN 图均测试）：
- lark-cli 会从 URL 下载并上传到飞书服务器
- 返回 `ok=true`
- 但消息内容只显示空白（`\n\n` 而非图片）
- 飞书客户端中同样不可见

```bash
# ❌ 看起来发送成功，但图片不会渲染
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  $'![alt](https://example.com/image.jpg)\n\n文字'
```

**结论：`![alt](url)` 在 lark-cli 中不可用。图 + 文字必须分两条发：`--image` 发图，再用 `--markdown` $'...' 发文字。**

### 授权流程（Device Code Flow）

权限诊断和授权请使用专门的 skill：`lark-cli-user-auth-troubleshooting`，包含：

- `--as user` 报 `need_user_authorization` 的诊断
- 设备码阻塞授权流程（`--no-wait` + `--device-code`）
- Token 丢失/持久化问题的处理
- `drive:file:upload` scope 命名陷阱（冒号 vs 点号）

**核心原则**：生成 `verification_url` 后，**立即运行阻塞命令** `lark-cli auth login --device-code <code> --domain drive,im` 等待用户授权。不要只看 URL 就退出，否则授权码作废。

### 本地表情库管理

```bash
~/Pictures/hermes-emotes/
├── ultraman/                    # 奥特曼系列
├── meme/                        # 通用 meme
├── custom/                      # 自定义生成（AIGC）
├── descriptions.json            # 所有表情的描述和适用场景
└── *.jpg / *.png
```

**发送流程（图+文字必须分两条）：**
```bash
# 1. 拷贝到 agent 工作目录（--image 相对路径从 ~/.hermes/ 解析）
cp ~/Pictures/hermes-emotes/表情名.jpg ~/.hermes/hermes_send_img.jpg

# 2. 发送图片（单独发）
lark-cli im +messages-send --as user --chat-id <chat_id> --image ./hermes_send_img.jpg

# 3. 配文（单独发）
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  $'<at user_id="ou_xxx">姓名</at> **配文**\n\n*（本条消息由张隆强的Hermes代发）*'
```

⚠️ **路径坑点**：`--image` 相对路径从 lark-cli 进程工作目录解析（Hermes 下为 `~/.hermes/`），拷到 `~/.hermes/` 再用 `./` 最可靠。

⚠️ **互斥限制**：`--image`/`--file`/`--video`/`--audio` 与 `--text`/`--markdown`/`--content` 互斥，不能同一条消息发。

### Fallback: Use Emoji/Unicode (No Permission Needed)
When image upload isn't available, emoji characters work in any text/markdown message:

```bash
lark-cli im +messages-send --as user --chat-id <chat_id> --markdown \
  '<at user_id="ou_xxx">姓名</at> 表情替代：🦸👍✨🚀\n\n*（本条消息由张隆强的Hermes代发）*'
```

**Supported:** All standard Unicode emoji (no special permissions). Works in both `--text` and `--markdown`.

## Create Feishu/Lark Documents

Use `docs +create` to create new wiki documents in Feishu.

### Required Scopes

Creating documents requires **two permission scopes** — missing either will fail:

```bash
# Both needed when using --wiki-space
docx:document:create
wiki:node:create
```

**Authorize both at once:**
```bash
lark-cli auth login --scope "docx:document:create wiki:node:create" --no-wait
# → Have user open verification_url and approve
# → Then complete with:
lark-cli auth login --device-code <code>
```

⚠️ **`auth login` does NOT support `--as user`** — it always works with the current config identity.  
Always use `auth login` without `--as` flag.

### Usage

```bash
# 1. Prepare markdown content in a file in the current directory
#    --markdown @file requires RELATIVE path only
cp /tmp/my-doc.md ./my-doc.md

# 2. Create the document
lark-cli docs +create \
  --title "My Document Title" \
  --markdown @./my-doc.md \
  --wiki-space my_library \
  --as user
```

**Critical constraints:**
- `--markdown @file` only works with **relative paths** within cwd. Absolute paths like `/tmp/doc.md` fail with `--file must be a relative path`
- Copy the file to cwd first: `cp /tmp/doc.md ./ && lark-cli docs +create --markdown @./doc.md ...`
- `--format json` is **NOT** supported on `docs +create` (it IS on `docs +fetch`)
- `--wiki-space my_library` targets the personal wiki space; omit to create a standalone doc

### On Success

Returns JSON with the document URL:
```json
{
  "ok": true,
  "data": {
    "node_token": "GDCFwlCHwinx4pkNgU7cZtbanJ9",
    "url": "https://zyql.feishu.cn/wiki/GDCFwlCHwinx4pkNgU7cZtbanJ9"
  }
}
```

### ⚠️ Cannot Update Existing Docs — Create New Version Instead

`lark-cli` does **not** support updating an existing Feishu wiki document. To iterate on a doc, create a new one with an incremented version suffix in the title:

```bash
# First version
lark-cli docs +create --title "PRD V1.0" --markdown @./prd.md --wiki-space my_library --as user

# After edits — create V1.1
cp /tmp/prd-v2.md ./prd-v2.md
lark-cli docs +create --title "PRD V1.1" --markdown @./prd-v2.md --wiki-space my_library --as user
```

Each creation returns a new `doc_url` with a new token. The old doc remains accessible at its original URL.

## Update / Upgrade lark-cli

lark-cli 可能通过 npm、pip、brew 安装，更新命令取决于实际安装方式。

### 诊断安装方式
```bash
which lark-cli                    # 查路径
ls -la $(which lark-cli)          # 查符号链接指向
file $(which lark-cli)            # 查文件类型
```

**判断规则：**
- 路径含 `node_modules/@larksuite/cli` → **npm**
- 路径含 `site-packages` → **pip**
- Homebrew keg 符号链接 → **brew**

### 按安装方式更新

```bash
# npm（最常见）
npm view @larksuite/cli version   # 查最新版本
npm install -g @larksuite/cli@latest

# pip
pip3 install --upgrade lark-cli

# brew
brew upgrade lark-cli
```

### 更新常见坑
- `pip3 install --upgrade` 报 "Missing dependencies for SOCKS support" → ALL_PROXY 干扰，试 `LARK_CLI_NO_PROXY=1`
- `brew upgrade` 报 "No available formula" → 实际是 npm 安装的
- 多种安装方式共存时 `which -a lark-cli` 查看所有实例，PATH 靠前的优先

### 更新后验证
```bash
lark-cli --version
lark-cli contact +search-user --query "test" --as user  # 快速功能测试
```

## Common Pitfalls
- `--chat-id` flag doesn't exist on `chat.members`; use `--params '{"chat_id":"..."}'`
- `+chat-messages-list` uses `--page-size` (1-50), **NOT** `--limit`. Using `--limit` errors with "unknown flag"
- `+chats-list` shows help, not actual chat list — use `+chat-search`
- Member list may be paginated; add `--page-all` to fetch all
- Response JSON differs: `contact +search-user` returns `users[].open_id`, `chat.members get` returns `items[].member_id`
- Group chat send requires `im:chat:read` permission — ensure scope granted
- CLI special characters (like `@`, URLs) may need quoting or escaping
- **Image upload error "image_key not found"**: means missing `drive:file.upload` scope — re-authorize with full drive scope
- **"open_id cross app" error** (code 99992361): the `open_id` from `contact +search-user` may belong to a different app/tenant context; use group member list (`chat.members get`) to get the correct tenant-specific `open_id`
- **Proxy interference**: if network calls fail or time out, try `LARK_CLI_NO_PROXY=1` environment variable to bypass proxy: `LARK_CLI_NO_PROXY=1 lark-cli im +chat-search --query "..." --as user`

## Read Feishu/Lark Documents

### Fetch Document Content
Use `docs +fetch` to read wiki pages and documents. This works for both public and permissioned documents (as long as the logged-in user has access).

```bash
# Basic fetch (JSON output)
lark-cli docs +fetch --doc "<document_url_or_token>" --as user

# Pretty-printed output for readability
lark-cli docs +fetch --doc "<document_url_or_token>" --as user --format pretty

# Extract specific content with jq
lark-cli docs +fetch --doc "<token>" --as user --format json \
  --jq '.content.body'  # extract body text
```

**Document identifiers:**
- Full URL: `https://zyql.feishu.cn/wiki/Ct9IwVHENiTS1OkTID1c3FzGnKg`
- Token only: `Ct9IwVHENiTS1OkTID1c3FzGnKg` (extract from URL after `/wiki/`)
- Both formats work with `--doc`

**Important notes:**
- Use `--as user` to read as the logged-in user (required for permissioned docs)
- `--format pretty` renders tables and markdown in human-readable form
- Output includes Lark-specific tags (`<lark-table>`, `<mention-user>`, `<mention-doc>`)
- Proxy environment variables (ALL_PROXY, etc.) affect CLI network requests

### Extract Mentions from Document Content
Documents often contain `<mention-user>` tags. Extract user IDs for follow-up actions:

```bash
# Fetch and extract all mentioned user IDs
lark-cli docs +fetch --doc "<token>" --as user --format json \
  --jq '.content.body | scan("<mention-user id=\"([^\"]+)\"/>") | .[]' \
  | sort -u
```

Or use Python for more robust parsing:
```python
import re, subprocess, json
result = subprocess.run([
  'lark-cli', 'docs', '+fetch',
  '--doc', '<token>', '--as', 'user', '--format', 'json'
], capture_output=True, text=True)
data = json.loads(result.stdout)
content = data.get('content', {}).get('body', '')
user_ids = re.findall(r'<mention-user id="([^"]+)"', content)
print(set(user_ids))
```

**Output:** Set of `open_id` values (e.g., `ou_333311bc7d65b56626beea49018f48af`) to use in @mentions or contact lookups.

### Compare Document Versions
When multiple version URLs exist, fetch both and compare to identify changes:

```bash
# Fetch both versions
lark-cli docs +fetch --doc "Ct9IwVHENiTS1OkTID1c3FzGnKg" --as user --format json > /tmp/doc_v1.json
lark-cli docs +fetch --doc "V1c2wEYr7idd5Ck9oXVcEtxYn02" --as user --format json > /tmp/doc_v2.json

# Compare key fields (mentions, priority, owner assignments)
jq '.content.body' /tmp/doc_v1.json > /tmp/v1_body.txt
jq '.content.body' /tmp/doc_v2.json > /tmp/v2_body.txt
diff -u /tmp/v1_body.txt /tmp/v2_body.txt | less
```

**Version tokens:** The path segment after `/wiki/` is the document token. Different tokens = different wiki pages (not versions of same page). Check if one page references another via `<mention-doc>` tags.

### Common Pitfalls
- **Login page returned** — user not authenticated or token expired; run `lark-cli auth status` and re-login if needed
- **Permission denied** — the logged-in user lacks read access to the document; request access from document owner
- **Empty output** — document may be very large; use `--limit`/`--offset` for pagination or `--jq` to filter specific sections
- **Proxy interference** — if requests fail, try `LARK_CLI_NO_PROXY=1` to bypass proxy

## Verification
After sending, check response contains `"ok": true` and a `message_id`. If failed, read `error.message` for clues (permission, rate-limit, invalid parameter).

## Best Practices
1. **Always check version first** if behavior seems off: `lark-cli --version`
2. **Find users with `contact +search-user` first**, not via group member lists
3. **Use `--dry-run`** to preview before sending
4. **Test in a private group first** before blasting large channels
5. **Avoid duplicate sends** — prepare complete message (including @ and disclaimer) before sending
6. **Keep messages concise** — markdown formatting for clarity, not long walls of text
7. **Log message_id** for traceability

## 进阶专题索引（references/ 子文件）

以下专题文档包含完整的操作流程和诊断步骤，按需用 `skill_view(name="lark-cli-usage", file_path="references/<文件名>.md")` 加载：

| 文件 | 场景 | 何时加载 |
|------|------|----------|
| `feishu-gateway-diagnostics.md` | Hermes Gateway 飞书 WebSocket 连接失败、收不到消息 | Gateway 启动后无法收发飞书消息时 |
| `feishu-handover-document-consolidation.md` | 交接文档散落在多处，需要系统性发现、收集、建索引 | 接手新项目/新人交接时 |
| `find-technical-contact.md` | 多约束条件找人（地域×职级×职责交叉验证） | 需要找到特定技术联系人但信息模糊时 |
| `lark-cli-user-auth-troubleshooting.md` | `--as user` 报 need_user_authorization、token 丢失 | 授权相关报错时 |
| `lark-message-delivery-audit.md` | 验证消息是否真的发出去了，补救未送达消息 | 对消息投递有疑问或需要审计时 |
| `multi-cli-feishu-dispatch.md` | 调度 Codex/Kimi/Cursor CLI 并行执行飞书任务 | 需要多 AI agent 并行处理飞书办公任务时 |
| `wiki-table-ownership-investigation.md` | 从 wiki 表格和聊天记录中查找 feature owner | 需求表中 owner 为空或不明确时 |
