# GitHub 开源项目贡献者信息收集

> 基于小跃（StepFun）的 github-contributor-sourcing skill 提炼，适配 OpenClaw Agent 工具链。

## 适用场景

- 需要联系某开源项目的核心贡献者（招聘/合作）
- 分析某技术领域的活跃开发者
- 从开源项目反查公司人才分布

## 核心流程

```
确定目标项目（GitHub repo）
    ↓
获取全量贡献者名单（API/Git）
    ↓
逐人补全档案（邮箱/公司/LinkedIn）
    ↓
质量验证 + 输出结构化数据
```

---

## Step 1. 获取贡献者名单

### 方法 A：GitHub API（推荐，快速）

```bash
# 获取贡献者列表（每页100，最多500人）
curl -H "Accept: application/vnd.github.v3+json" \
  "https://api.github.com/repos/{owner}/{repo}/contributors?per_page=100&page=1"
```

返回字段：`login`（用户名）、`contributions`（提交次数）、`html_url`

**限制**：未认证 60次/小时，认证 5000次/小时，最多返回前500名。

### 方法 B：Git shortlog（最完整）

```bash
# 克隆仓库
git clone https://github.com/{owner}/{repo}.git
cd {repo}

# 获取所有贡献者（含邮箱）
git shortlog -sne --all
```

输出示例：`1141  Huamin Li <huamin.li@example.com>`

**优势**：覆盖全部历史贡献者，含 commit 邮箱。
**劣势**：邮箱可能是 noreply 隐私保护地址。

### 方法 C：GitHub 网页（Top 100 详细档案）

访问 `https://github.com/{owner}/{repo}/graphs/contributors`，逐个点击头像收集个人信息。

**适合**：小规模高质量需求。

---

## Step 2. 获取真实邮箱（核心技巧）

### 🔑 .patch 文件法（绕过 GitHub 隐私保护）

GitHub 的 noreply 邮箱保护只在 web 界面生效。通过 `.patch` 文件可以获取 commit 中的真实邮箱。

**操作步骤**：

1. 访问用户在目标项目的 commit 列表：
   ```
   https://github.com/{owner}/{repo}/commits?author={username}
   ```

2. 点开任意一个具体 commit（必须进入 commit 详情页，看到代码 diff）

3. 在 commit URL 末尾加 `.patch`：
   ```
   https://github.com/{owner}/{repo}/commit/{hash}.patch
   ```

4. 在 `.patch` 文件中查找邮箱字段：

| 字段 | 优先级 | 说明 |
|------|--------|------|
| **Signed-off-by** | ✅ 最优先 | 通常是真实工作邮箱 |
| **Co-authored-by** | 🟡 次选 | 协作者邮箱 |
| **From** | ❌ 最低 | 通常是 noreply 隐私保护邮箱 |

**示例 .patch 内容**：
```
From: username <12345+username@users.noreply.github.com>  ← 隐私保护
...
Signed-off-by: Real Name <real@company.com>               ← 真实邮箱！
```

**⚠️ 常见错误**：
- 不要在 commits 列表页 URL 后加 `.patch`，必须在具体 commit 页面
- 不要只看 `From` 字段，优先看 `Signed-off-by`
- 如果一个 commit 没有，多试几个不同的 commit

### 其他邮箱获取方式

- **GitHub Profile bio**：部分用户在简介中留有邮箱
- **个人网站**：从 Profile 中的 website 链接找联系方式
- **论文 PDF**：学术型开发者的论文通常有邮箱

---

## Step 3. 补全完整档案

### GitHub Profile 信息采集

访问 `https://github.com/{username}`，采集：

| 字段 | 来源 |
|------|------|
| 真实姓名 | Profile name |
| 公司/组织 | Profile company（`@公司名` 格式）|
| 位置 | Profile location |
| 个人简介 | Bio |
| 个人网站 | Blog/website |
| 社交链接 | Twitter/X、LinkedIn 等 |

### LinkedIn 补全

搜索引擎查询：`"{真实姓名}" "{公司名}" site:linkedin.com`

### 身份验证要点

- **Display Name ≠ Username**：GitHub 显示名可能是真名、昵称或用户名，不能直接当 username 用
- **同名区分**：通过 repos/contributions 确认是目标项目的贡献者
- **Bot 过滤**：`dependabot[bot]`、`github-actions[bot]` 等自动标记跳过

---

## Step 4. 批量执行策略

### GitHub API 批量获取用户详情

```bash
# 获取用户详细信息
curl -H "Accept: application/vnd.github.v3+json" \
  "https://api.github.com/users/{username}"
```

返回：`name`、`company`、`location`、`bio`、`blog`、`email`（如果公开）

### 执行节奏

- API 调用间隔：1-2 秒（认证后限流宽松）
- 网页访问间隔：5-10 秒
- .patch 文件获取：3-5 秒间隔
- 每处理 50 人休息 2 分钟

### 优先级排序

| 优先级 | 目标 | 说明 |
|--------|------|------|
| 🔴 高 | Top 100 贡献者 | 核心开发者，最有价值 |
| 🟡 中 | 101-300 名 | 活跃贡献者 |
| 🟢 低 | 300 名以后 | 偶尔贡献者 |

---

## 输出字段 Schema

```json
{
  "github_username": "sroy745",
  "real_name": "Sourashis Roy",
  "commits": 845,
  "email": "sroy@company.com",
  "email_source": "signed-off-by",
  "email_confidence": "high",
  "company": "Company Name",
  "location": "San Francisco, CA",
  "bio": "Distributed Systems Engineer",
  "website": "https://example.com",
  "linkedin": "in/sourashis-roy",
  "github_url": "https://github.com/sroy745",
  "verified_contributor": true,
  "data_source": "github-patch"
}
```

---

## 邮箱类型识别

| 类型 | 特征 | 价值 |
|------|------|------|
| 工作邮箱 | `@company.com` | ✅ 最有价值，可直接联系 |
| 个人邮箱 | `@gmail.com` / `@qq.com` | 🟡 可用，但不如工作邮箱 |
| 学校邮箱 | `@xxx.edu.cn` | 🟡 可能已失效（毕业后） |
| 隐私保护 | `@users.noreply.github.com` | ❌ 无法联系，需要用 .patch 法 |

---

## 与 talent-mapping 整合

本文档作为 talent-mapping skill 的**数据源扩展**：

- **talent-mapping Step 2**（获取成员名单）：GitHub Org 和项目贡献者属于此步
- **talent-mapping Step 3**（信息补全）：.patch 邮箱法是邮箱补全的强力手段
- **卡片 Schema 兼容**：输出字段可直接映射到 `references/card-schema.md` 定义的人才卡片

---

*提炼自"小跃"GitHub Contributor Sourcing 实战经验（2000+ 贡献者处理）*
