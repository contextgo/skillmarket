# 数据源评估与代码模板

## 各渠道有效性评估

| 渠道 | 命中率 | 适用场景 | 注意事项 |
|------|--------|---------|---------|
| 实验室主页 | 70-90% | 校招，获取完整名单 | 部分 JS 渲染需浏览器 |
| 导师个人主页 | 60-80% | 校招，补全去向 | 更新频率不一 |
| GitHub Org | 40-60% | 校招+社招，活跃开发者 | 仅覆盖代码贡献者 |
| 论文作者追踪 | 30-50% | 全场景，学术型人才 | 耗时较长 |
| Google Scholar | 30-40% | 补全学术档案 | 反爬严格 |
| Semantic Scholar | 20-40% | 身份确认+论文追踪 | 免费 API，质量稳定 |
| LinkedIn | 30-50% | 就业信息补全 | 中国区访问受限 |
| 脉脉 | 20-40% | 国内就业信息 | 需登录态+浏览器 |

---

## API 调用模板

### Semantic Scholar 作者搜索

```bash
# 搜索作者
curl "https://api.semanticscholar.org/graph/v1/author/search?query={name}&fields=name,affiliations,papers,externalIds,homepage"

# 获取作者论文列表
curl "https://api.semanticscholar.org/graph/v1/author/{authorId}/papers?fields=title,year,venue,authors"
```

**限流策略**：
- 免费 API：100 请求/5 分钟
- 遇到 429 等待 30 秒
- 建议间隔 5-10 秒

### DBLP 作者搜索

```bash
curl "https://dblp.org/search/author/api?q={name}&format=json&h=10"
```

### arXiv 论文搜索

```bash
# 按作者搜索
curl "http://export.arxiv.org/api/query?search_query=au:{name}&max_results=10&sortBy=submittedDate&sortOrder=descending"
```

### GitHub API

```bash
# 查组织成员
curl "https://api.github.com/orgs/{org}/members?per_page=100"

# 查仓库贡献者
curl "https://api.github.com/repos/{owner}/{repo}/contributors?per_page=100"

# 查用户信息
curl "https://api.github.com/users/{username}"
```

**限流**：未认证 60 次/小时，认证 5000 次/小时

---

## 批量搜索 Python 模板

### 人类节奏搜索器

```python
import time, random, json

def human_pace_search(names, search_func, delay_range=(8, 15)):
    """模拟人类节奏的批量搜索"""
    results = {}
    for i, name in enumerate(names):
        print(f"[{i+1}/{len(names)}] Searching: {name}")
        try:
            result = search_func(name)
            results[name] = result
        except Exception as e:
            print(f"  Error: {e}")
            results[name] = {"error": str(e)}
        
        # 人类节奏等待
        wait = random.uniform(*delay_range)
        print(f"  Waiting {wait:.1f}s...")
        time.sleep(wait)
        
        # 每 20 个多等一会
        if (i + 1) % 20 == 0:
            long_wait = random.uniform(30, 60)
            print(f"  Long break: {long_wait:.0f}s")
            time.sleep(long_wait)
    
    return results
```

### 实验室主页抓取模板

```python
def fetch_lab_page(url, retry=True):
    """人类速度访问实验室主页"""
    wait = random.randint(15, 30)
    time.sleep(wait)
    
    # 使用 web_fetch 或 curl
    resp = web_fetch(url)
    
    if not resp or "404" in resp:
        if retry:
            time.sleep(60)
            return fetch_lab_page(url, retry=False)
        return None
    
    return resp
```

### 邮箱格式验证

```python
import re

def validate_email(email, school=None):
    """验证邮箱格式和学校匹配"""
    if not email or not re.match(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$', email):
        return False, "invalid_format"
    
    # 学校邮箱域名映射（示例）
    edu_domains = {
        "清华": ["tsinghua.edu.cn"],
        "北大": ["pku.edu.cn"],
        "浙大": ["zju.edu.cn"],
        "复旦": ["fudan.edu.cn"],
        "上交": ["sjtu.edu.cn"],
        # ... 按需添加
    }
    
    if school and school in edu_domains:
        domain = email.split("@")[1]
        if any(d in domain for d in edu_domains[school]):
            return True, "high"  # edu 邮箱匹配学校
    
    return True, "medium"
```

### LinkedIn URL 验证

```python
def validate_linkedin(url):
    """验证 LinkedIn URL 格式"""
    if not url:
        return False, "empty"
    
    patterns = [
        r'https?://(?:www\.)?linkedin\.com/in/[\w-]+/?',
        r'https?://(?:www\.)?linkedin\.com/pub/[\w-]+',
    ]
    
    for p in patterns:
        if re.match(p, url):
            return True, "valid_format"
    
    return False, "invalid_format"
```

---

## 数据清洗常见 Pattern

### 公司名清洗（排除误匹配）

```python
# 这些是搜索引擎来源网站，不是公司
NOISE_COMPANIES = {
    "知乎", "CSDN", "新浪", "搜狐", "百度百科", "微博",
    "GitHub", "Google Scholar", "ResearchGate", "arXiv",
    "LinkedIn", "脉脉", "Boss直聘"
}

def clean_company(company, school=None):
    """清洗公司字段"""
    if not company:
        return None, "low"
    
    # 排除搜索来源网站
    if company in NOISE_COMPANIES:
        return None, "noise"
    
    # 排除母校被误标
    if school and school in company:
        return None, "school_as_company"
    
    return company, "medium"
```

---

*模板仅供参考，实际使用时根据 Agent 可用工具调整*
