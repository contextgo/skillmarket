# 人才卡片字段定义

## 完整字段 Schema

| 字段 | 类型 | 必填 | 说明 |
|------|------|------|------|
| 姓名 | string | ✅ | 中文全名 |
| 英文名 | string | ✅ | 论文中使用的英文名 |
| 学校 | string | ✅ | 最高学历院校（优先博士） |
| 实验室 | string | ✅ | 导师姓名 + 实验室名称 |
| 学位 | string | ✅ | 博士/硕士/本科 |
| 毕业年份 | int | ✅ | YYYY（推断标 "~2024"） |
| 研究方向 | string | ✅ | 主方向标签 |
| 代表论文 | string | 推荐 | 最高价值论文标题 + venue |
| 当前就职单位 | string | ✅ | 企业/高校/研究院 |
| 当前职位 | string | 推荐 | 研究员/工程师/博后/教授 |
| 邮箱 | string | 推荐 | 公开学术邮箱 |
| 个人主页 | URL | 推荐 | 个人网站/学校主页 |
| google_scholar | URL | 推荐 | Google Scholar profile |
| linkedin | URL | 推荐 | LinkedIn 公开主页 |
| github | URL | 推荐 | GitHub 主页 |
| 备注 | string | - | 信息来源、不确定标注 |

## 置信度字段

每个关键字段附带 `_confidence` 标签：

| 字段 | 置信度字段 |
|------|-----------|
| 当前就职单位 | company_confidence |
| 邮箱 | email_confidence |
| linkedin | linkedin_confidence |
| 毕业年份 | grad_year_confidence |

置信度值：`high` / `medium` / `low`

## JSON 模板

```json
{
  "姓名": "张三",
  "英文名": "San Zhang",
  "学校": "清华大学",
  "实验室": "某某实验室",
  "学位": "博士",
  "毕业年份": 2024,
  "研究方向": "大语言模型/知识图谱",
  "代表论文": "Paper Title (ACL 2024)",
  "当前就职单位": "某AI公司",
  "当前职位": "研究员",
  "company_confidence": "high",
  "邮箱": "zhangsan@example.edu.cn",
  "email_confidence": "high",
  "个人主页": "https://zhangsan.github.io",
  "google_scholar": "https://scholar.google.com/citations?user=xxx",
  "linkedin": "https://linkedin.com/in/san-zhang",
  "linkedin_confidence": "medium",
  "github": "https://github.com/zhangsan",
  "Semantic_Scholar_ID": "12345678",
  "DBLP": "https://dblp.org/pid/xx/xxxx",
  "毕业年份_confidence": "high",
  "备注": "就职信息来自2025年论文affiliation"
}
```

## 置信度判定标准

### high（高可信）
- 2025-2026 年论文 affiliation 明确标注
- 本人社交媒体自述（LinkedIn/GitHub bio）
- edu 邮箱与学校匹配
- 官网/实验室主页明确列出

### medium（中可信）
- 2023-2024 年论文 affiliation
- 实验室主页标注（可能未更新）
- 交叉验证（多来源一致但非直接证据）
- 从毕业时间推算的年份

### low（低可信）
- 搜索引擎推断结果
- 间接来源（他人提及）
- 超过 2 年未更新的信息
- 同名匹配但未完全确认

---

*使用时根据实际数据来源如实标注，宁可标 low 也不虚标 high*
