---
name: dependency-check
description: 依赖检查助手。用于检查项目依赖漏洞、更新版本、管理依赖关系。当需要检查依赖安全、更新依赖时触发。
---

# 依赖检查助手

## 依赖检查清单

### Java (Maven)
```bash
# 检查依赖版本
mvn dependency:tree
mvn dependency:list

# 检查依赖漏洞
mvn org.owasp:dependency-check-maven:check

# 检查可更新版本
mvn versions:display-dependency-updates
mvn versions:display-plugin-updates

# 生成依赖报告
mvn dependency:report
```

### Node.js (npm)
```bash
# 检查依赖版本
npm list
npm list --depth=0

# 检查漏洞
npm audit
npm audit --audit-level=high

# 检查可更新版本
npm outdated

# 更新依赖
npm update
npm update <package-name>
```

### Python
```bash
# 检查依赖
pip list

# 检查漏洞
pip-audit

# 检查可更新版本
pip list --outdated

# 更新依赖
pip-review --interactive
```

## 依赖安全报告模板

```markdown
# 依赖安全报告

项目：XXX
检查时间：YYYY-MM-DD
检查工具：XXX

---

## 概览

| 项目 | 数量 |
|------|------|
| 依赖总数 | XX |
| 直接依赖 | XX |
| 间接依赖 | XX |
| 高危漏洞 | XX |
| 中危漏洞 | XX |
| 低危漏洞 | XX |

---

## 高危漏洞

| 漏洞ID | 依赖 | 版本 | CVE | 描述 | 修复建议 |
|--------|------|------|-----|------|----------|
| V1 | xxx | 1.0.0 | CVE-xxxx-xxxx | xxx | 升级到1.0.1 |

---

## 依赖清单

### 直接依赖
| 包名 | 版本 | 用途 | 许可证 |
|------|------|------|--------|
| spring-boot | 2.7.0 | Web框架 | Apache 2.0 |
| mysql-connector | 8.0.30 | 数据库驱动 | GPL |
```

## 依赖更新流程

```markdown
## 依赖更新流程

### 1. 评估阶段
- [ ] 检查变更日志
- [ ] 检查兼容性
- [ ] 评估风险

### 2. 测试阶段
- [ ] 单元测试
- [ ] 集成测试
- [ ] 回归测试

### 3. 更新阶段
- [ ] 更新依赖版本
- [ ] 提交代码
- [ ] 合并到主分支

### 4. 监控阶段
- [ ] 监控线上指标
- [ ] 监控错误率
```

## 版本号规范

```markdown
## 语义化版本（SemVer）

版本格式：主版本.次版本.修订号

- 主版本（MAJOR）：不兼容的重大变更
- 次版本（MINOR）：向后兼容的功能新增
- 修订号（PATCH）：向后兼容的问题修复

## 版本兼容性

| 更新类型 | 兼容性 | 示例 |
|----------|--------|------|
| Patch更新 | 100%兼容 | 1.0.0 → 1.0.1 |
| Minor更新 | 向后兼容 | 1.0.0 → 1.1.0 |
| Major更新 | 不兼容 | 1.0.0 → 2.0.0 |

## 依赖版本锁定

### 建议版本策略
- 生产依赖：锁定主版本号（~1.0.0）
- 开发依赖：锁定次版本号（^1.1.0）
- 禁止使用：最新（latest）
```

## 常用依赖检查命令

```bash
#!/bin/bash
# 依赖检查脚本

echo "=== 依赖检查报告 ==="
echo "检查时间：$(date)"
echo ""

# Java检查
if [ -f "pom.xml" ]; then
    echo "【Java依赖检查】"
    mvn org.owasp:dependency-check-maven:check -q
    echo ""
fi

# Node.js检查
if [ -f "package.json" ]; then
    echo "【Node.js依赖检查】"
    npm audit --audit-level=high
    echo ""
fi

# Python检查
if [ -f "requirements.txt" ]; then
    echo "【Python依赖检查】"
    pip-audit
    echo ""
fi

echo "=== 检查完成 ==="
```
