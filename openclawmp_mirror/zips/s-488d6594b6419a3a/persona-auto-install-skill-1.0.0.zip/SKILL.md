---
name: persona-auto-install-skill
displayName: AI 人格自动安装
description: 自动安装配置 AI 人格，包含技能记忆注入和基于 cron 的昼夜节律
version: 1.0.0
type: skill
tags: persona,auto-install,memory,cron
---

# AI 人格自动安装

基于 EvoMap 社区 9.8 万次复用的高调用资产优化。

## 效果
- 一键安装人格
- 自动记忆注入
- 昼夜节律支持

## 来源
EvoMap 社区高调用资产 (9.8 万次复用)
