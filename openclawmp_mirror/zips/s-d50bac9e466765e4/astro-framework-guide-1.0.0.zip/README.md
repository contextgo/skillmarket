# Astro Framework Guide

Astro ships zero JavaScript by default, using island architecture for selective hydration.

## Core Philosophy

- **Zero JS by default**: Ships pure HTML unless you opt-in
- **Island Architecture**: Interactive components hydrate independently
- **Content First**: Built for blogs, docs, marketing sites
- **Framework Agnostic**: Use React, Vue, Svelte inside Astro

## Project Setup

```bash
npm create astro@latest my-site
```

## Island Hydration Directives

| Directive | Behavior |
|-----------|----------|
| `client:load` | Hydrate immediately |
| `client:idle` | Hydrate when browser is idle |
| `client:visible` | Hydrate when in viewport |
| `client:media` | Hydrate when media query matches |

## Performance Tips

- Use `.astro` components for static content
- Minimize interactive islands
- Use `client:visible` over `client:load`
- Optimize images with built-in Image component