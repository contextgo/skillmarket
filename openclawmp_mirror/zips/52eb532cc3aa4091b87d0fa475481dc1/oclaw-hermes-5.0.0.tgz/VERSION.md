# oclaw-hermes 版本历史

## v3.9.0 (2026-04-12)

### 新增功能
- **Perplexity 桥接器 v1.0**: 集成 Perplexity AI 实时搜索能力
  - 实时搜索: 获取最新互联网信息
  - 深度研究: 多源信息综合分析
  - 引用溯源: 所有回答附带来源链接
  - 事实核查: 验证信息准确性
  - 多源对比: 对比不同来源观点
  - 流式搜索: 实时返回搜索结果
  - 多模型支持: sonar/sonar-pro/sonar-reasoning
- **Platform 统一控制器 v3.1**: 升级为五平台
  - 新增 Perplexity 平台 API
  - 统一的搜索/研究/核查接口
  - 增强的 CLI 支持

### 架构升级
- 从六位一体 → **七位一体** (+ Perplexity)
- OpenClaw × Hermes × DeerFlow × Swarm × Perplexity × 服务设计 × Norman Mailer

### 文件变更
- 新增: `scripts/perplexity_bridge.py` v1.0 (350+ 行)
- 更新: `scripts/bridge.py` v3.0 → v3.1
- 更新: `SKILL.md` v3.8.1 → v3.9.0
- 更新: `VERSION.md` 版本历史

---

## v3.8.1 (2026-04-12)

### 平台更新
- **OpenClaw 平台**: 更新到 openclawmp.stepfun.com
  - 所有文档和配置已同步更新
  - CLI 工具已配置新 endpoint
  - Token: sk_8536157f2304245f70fb8e3a8e27f3cb4ca8d4d27f285f68

### 文件变更
- 更新: `SKILL.md` - 平台 endpoint 配置
- 更新: `README.md` - 平台链接
- 更新: `VERSION.md` - 版本历史

---

## v3.8.0 (2026-04-12)

### 新增功能
- **Platform 统一控制器 v3.0**: 四平台统一接口
  - 完整集成 Hermes 记忆系统 API
  - 完整集成 DeerFlow 研究/代码/多智能体 API
  - 完整集成 Swarm 多智能体协作 API
  - 统一的状态检查和功能发现
- **增强的命令行接口**: 支持所有平台的 CLI 操作
  - `bridge.py status` - 查看平台状态
  - `bridge.py hermes store/retrieve/evolve` - 记忆操作
  - `bridge.py deerflow research/code` - 研究/代码执行
  - `bridge.py swarm execute/route` - 多智能体任务

### 架构升级
- 从基础桥接升级到**统一平台控制器**
- 懒加载模式：各平台客户端按需初始化
- 完整的错误处理和可用性检查

### 文件变更
- 重写: `scripts/bridge.py` v2.0 → v3.0 (400+ 行)
- 更新: `VERSION.md` 版本历史

---

## v3.7.0 (2026-04-11)

### 新增功能
- **Swarm 桥接器 v1.0**: 集成 OpenAI Swarm 核心能力
  - AgentRegistry: 智能体注册中心
  - ContextManager: 上下文管理和传递
  - FunctionRouter: 函数调用路由
  - SwarmOrchestrator: 多智能体执行编排
- **超能力工作流增强**: 4个超能力工作流全面集成 Swarm
- **异步 Swarm 接口**: `async_swarm_run`, `async_swarm_create_agent`

### 架构升级
- 从五位一体升级到**六位一体架构**
- 新增 Swarm 能力模块到工作流编排器
- 默认提供 4 个 Swarm 智能体 (researcher/coder/analyst/reviewer)

### 文件变更
- 新增: `scripts/swarm_bridge.py` (850+ 行)
- 新增: `SWARM_INTEGRATION.md` 文档
- 更新: `workflow_orchestrator.py` v3.6 → v3.7
- 更新: `SKILL.md` 版本号和文档

---

## v3.6.0 (2026-04-11)

### 新增功能
- **DeerFlow 桥接器 v1.0**: 集成 DeerFlow 四大核心能力
  - DeepResearchChain: 深度研究链
  - CodeSandbox: 代码沙箱执行
  - MultiAgentCollaboration: 多智能体协作
  - ToolOrchestrator: 工具调用编排
- **超能力工作流**: 4种超能力工作流
  - hyper_research: 超研究
  - hyper_creation: 超创造
  - hyper_evolution: 超进化
  - hyper_analysis: 超分析
- **异步 DeerFlow 接口**: `async_deep_research`, `async_execute_code`

### 文件变更
- 新增: `scripts/deerflow_bridge.py`
- 更新: `workflow_orchestrator.py` v3.5 → v3.6

---

## v3.5.0 (2026-04-XX)

### 新增功能
- **FAISS 加速**: 向量检索速度提升 62 倍
- **智能缓存**: 热点查询缓存，命中率 >82%
- **自适应参数**: 根据场景动态调优
- **执行模式提取**: 自动识别成功模式
- **超能力工作流框架**: 整合 Hermes/DeerFlow/Swarm

### 性能提升
| 指标 | v3.4 | v3.5 | 提升 |
|------|------|------|------|
| 向量检索 | 500ms | 8ms | 62x |
| 平均响应 | 126ms | 45ms | 2.8x |
| SLA合规率 | 33% | 91% | 2.8x |

---

## v3.4.0

### 新增功能
- Norman Mailer 叙事增强
- 超能力工作流框架
- 性能监控和优化

---

## v3.0.0

### 初始版本
- Hermes 七层记忆系统
- mflow v2.0 记忆流
- 技能自动生成
- 专家思维蒸馏

---

## 版本命名规则

- **主版本 (X.0.0)**: 架构级变更
- **次版本 (x.Y.0)**: 功能级更新
- **修订版本 (x.y.Z)**: Bug修复和优化

## 兼容性

| 版本 | OpenClaw | Hermes | DeerFlow | Swarm | Perplexity | Platform API | Endpoint |
|------|----------|--------|----------|-------|------------|--------------|----------|
| v3.9.0 | ✅ stepfun | ✅ | ✅ | ✅ | ✅ | ✅ 五平台 | openclawmp.stepfun.com |
| v3.8.1 | ✅ stepfun | ✅ | ✅ | ✅ | ❌ | ✅ 四平台 | openclawmp.stepfun.com |
| v3.8.0 | ✅ | ✅ | ✅ | ✅ | ❌ | ✅ 四平台 | openclawmp.cc |
| v3.7 | ✅ | ✅ | ✅ | ✅ | ❌ | ⚠️ 基础 | openclawmp.cc |
| v3.6 | ✅ | ✅ | ✅ | ⚠️ | ❌ | ❌ | openclawmp.cc |
| v3.5 | ✅ | ✅ | ⚠️ | ❌ | ❌ | ❌ | openclawmp.cc |
| v3.0 | ✅ | ✅ | ❌ | ❌ | ❌ | ❌ | openclawmp.cc |
