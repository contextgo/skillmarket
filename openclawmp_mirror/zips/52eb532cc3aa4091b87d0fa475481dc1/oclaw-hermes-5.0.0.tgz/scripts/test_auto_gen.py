#!/usr/bin/env python3
"""测试 Skill 自动生成器"""

import sys
sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from skill_auto_generator import SkillAutoGenerator

def main():
    print("=" * 80)
    print("Skill Auto Generator v3.2 - Test")
    print("=" * 80)
    
    generator = SkillAutoGenerator()
    
    # 模拟多次调用
    test_skill = "test-skill"
    test_queries = [
        "批量处理这些数据",
        "分析结果并生成报告",
        "自动执行定时任务"
    ]
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n[Call {i}]: {query}")
        result = generator.record_skill_call(
            skill_name=test_skill,
            query=query,
            context={"batch": True, "analysis": True},
            result_summary="执行成功",
            success=True,
            execution_time=2.5
        )
        print(f"   Current count: {result['call_count']}")
        if result.get('trigger_result'):
            print(f"   [TRIGGERED] Auto generation started!")
            print(f"   Generated files: {result['trigger_result'].get('generated_files', [])}")
    
    # 显示状态
    print("\n" + "=" * 80)
    print("Generation Status:")
    print("=" * 80)
    status = generator.get_generation_status()
    print(f"Total tasks: {status['total_tasks']}")
    print(f"Completed: {status['completed']}")
    print(f"Pending triggers: {generator.list_pending_skills()}")

if __name__ == "__main__":
    main()
