#!/usr/bin/env python3
"""
服务设计意图预测系统 v3.1
基于黄蔚服务设计理念的智能意图识别与场景预测

核心能力：
1. 用户意图精确预测 - 基于服务设计五层模型
2. 输出场景智能匹配 - 动线工具+用户旅程映射
3. 靶向向量记忆 - 结构化数据框架+沙箱管理
4. 快速决策支持 - 记忆驱动+经验复用
"""

import json
import hashlib
import numpy as np
from datetime import datetime
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum
import sys
sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from mflow_v2 import MFlowEngineV2, MemoryEntry

class IntentType(Enum):
    """服务设计五层意图类型"""
    STRATEGY = "strategy"           # 战略升维
    JOURNEY = "journey"             # 用户旅程设计
    CO_CREATION = "co_creation"     # 共创设计
    TOUCHPOINT = "touchpoint"       # 触点优化
    SYSTEM = "system"               # 系统重构
    GENERAL = "general"             # 通用咨询

class OutputScene(Enum):
    """输出场景类型"""
    CONSULTING = "consulting"       # 战略咨询报告
    BLUEPRINT = "blueprint"         # 服务蓝图
    JOURNEY_MAP = "journey_map"     # 用户旅程图
    PROTOTYPE = "prototype"         # 服务原型
    WORKSHOP = "workshop"           # 共创工作坊方案
    IMPLEMENTATION = "implementation"  # 落地方案

@dataclass
class IntentPrediction:
    """意图预测结果"""
    primary_intent: IntentType
    confidence: float
    secondary_intents: List[Tuple[IntentType, float]]
    user_profile: Dict[str, Any]
    predicted_scene: OutputScene
    scene_confidence: float
    touchpoints: List[str]
    stakeholders: List[str]
    
@dataclass
class StructuredMemory:
    """结构化记忆单元"""
    memory_id: str
    timestamp: str
    intent_type: str
    scene_type: str
    user_query: str
    context: Dict[str, Any]
    touchpoint_vector: np.ndarray
    stakeholder_vector: np.ndarray
    journey_stage: str
    business_value: float
    success_rate: float
    feedback_score: float
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            "memory_id": self.memory_id,
            "timestamp": self.timestamp,
            "intent_type": self.intent_type,
            "scene_type": self.scene_type,
            "user_query": self.user_query,
            "context": self.context,
            "touchpoint_vector": self.touchpoint_vector.tolist() if isinstance(self.touchpoint_vector, np.ndarray) else self.touchpoint_vector,
            "stakeholder_vector": self.stakeholder_vector.tolist() if isinstance(self.stakeholder_vector, np.ndarray) else self.stakeholder_vector,
            "journey_stage": self.journey_stage,
            "business_value": self.business_value,
            "success_rate": self.success_rate,
            "feedback_score": self.feedback_score
        }

class ServiceDesignIntentEngine:
    """
    服务设计意图预测引擎
    
    基于黄蔚服务设计理念：
    - 以用户为中心的深度洞察
    - 共创式设计
    - 整体性服务体验
    - CEO思维的服务设计
    - 服务设计战略升维
    """
    
    # 意图识别关键词映射
    INTENT_KEYWORDS = {
        IntentType.STRATEGY: [
            "战略", "商业模式", "增长", "转型", "升维", "指数级",
            "顶层设计", "全局", "系统", "重构", "创新", "突破"
        ],
        IntentType.JOURNEY: [
            "旅程", "动线", "体验", "流程", "触点", "端到端",
            "用户视角", "全流程", "服务流程", "用户路径"
        ],
        IntentType.CO_CREATION: [
            "共创", "协作", "参与", "工作坊", "利益相关者",
            "多方", "一起设计", "共同", "邀请", "共建"
        ],
        IntentType.TOUCHPOINT: [
            "触点", "界面", "APP", "网站", "门店", "客服",
            "优化", "改进", "提升", "满意度", "投诉"
        ],
        IntentType.SYSTEM: [
            "系统", "组织", "流程", "运营", "效率", "协同",
            "后端", "支撑", "机制", "架构", "整合"
        ]
    }
    
    # 场景匹配规则
    SCENE_RULES = {
        IntentType.STRATEGY: OutputScene.CONSULTING,
        IntentType.JOURNEY: OutputScene.JOURNEY_MAP,
        IntentType.CO_CREATION: OutputScene.WORKSHOP,
        IntentType.TOUCHPOINT: OutputScene.BLUEPRINT,
        IntentType.SYSTEM: OutputScene.IMPLEMENTATION,
        IntentType.GENERAL: OutputScene.CONSULTING
    }
    
    # 触点关键词库
    TOUCHPOINT_KEYWORDS = [
        "听说", "了解", "下载", "注册", "开户", "绑卡",
        "咨询", "预约", "到店", "等待", "办理", "使用",
        "支付", "售后", "评价", "复购", "推荐", "客服"
    ]
    
    # 利益相关者关键词库
    STAKEHOLDER_KEYWORDS = [
        "用户", "客户", "消费者", "员工", "一线", "导购",
        "客服", "销售", "技师", "管理层", "CEO", "老板",
        "合作伙伴", "供应商", "渠道", "政府", "监管"
    ]
    
    def __init__(self):
        self.memory_engine = MFlowEngineV2()
        self.structured_memories: List[StructuredMemory] = []
        self.sandbox: Dict[str, Any] = {}  # 沙箱环境
        self._load_structured_memories()
        
    def _load_structured_memories(self):
        """加载结构化记忆"""
        try:
            with open("structured_memory.json", "r", encoding="utf-8") as f:
                data = json.load(f)
                for item in data:
                    self.structured_memories.append(StructuredMemory(
                        memory_id=item["memory_id"],
                        timestamp=item["timestamp"],
                        intent_type=item["intent_type"],
                        scene_type=item["scene_type"],
                        user_query=item["user_query"],
                        context=item["context"],
                        touchpoint_vector=np.array(item["touchpoint_vector"]),
                        stakeholder_vector=np.array(item["stakeholder_vector"]),
                        journey_stage=item["journey_stage"],
                        business_value=item["business_value"],
                        success_rate=item["success_rate"],
                        feedback_score=item["feedback_score"]
                    ))
        except FileNotFoundError:
            self.structured_memories = []
            
    def _save_structured_memories(self):
        """保存结构化记忆"""
        data = [m.to_dict() for m in self.structured_memories]
        with open("structured_memory.json", "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def predict_intent(self, user_query: str, context: Dict = None) -> IntentPrediction:
        """
        预测用户意图
        
        基于服务设计五层模型进行意图识别
        """
        context = context or {}
        
        # 1. 关键词匹配计算意图分数
        intent_scores = {}
        for intent_type, keywords in self.INTENT_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in user_query)
            intent_scores[intent_type] = score / len(keywords) if keywords else 0
        
        # 2. 向量相似度检索历史记忆
        similar_memories = self._retrieve_similar_memories(user_query)
        for memory in similar_memories:
            intent_type = IntentType(memory.intent_type)
            intent_scores[intent_type] = intent_scores.get(intent_type, 0) + 0.3
        
        # 3. 确定主要意图和次要意图
        sorted_intents = sorted(intent_scores.items(), key=lambda x: x[1], reverse=True)
        primary_intent = sorted_intents[0][0] if sorted_intents[0][1] > 0 else IntentType.GENERAL
        confidence = min(sorted_intents[0][1] * 2, 1.0) if sorted_intents[0][1] > 0 else 0.5
        
        secondary_intents = [
            (intent, min(score * 2, 1.0)) 
            for intent, score in sorted_intents[1:3] 
            if score > 0
        ]
        
        # 4. 用户画像分析
        user_profile = self._analyze_user_profile(user_query, context)
        
        # 5. 预测输出场景
        predicted_scene = self.SCENE_RULES.get(primary_intent, OutputScene.CONSULTING)
        scene_confidence = confidence * 0.9
        
        # 6. 识别关键触点和利益相关者
        touchpoints = [tp for tp in self.TOUCHPOINT_KEYWORDS if tp in user_query]
        stakeholders = [sh for sh in self.STAKEHOLDER_KEYWORDS if sh in user_query]
        
        return IntentPrediction(
            primary_intent=primary_intent,
            confidence=confidence,
            secondary_intents=secondary_intents,
            user_profile=user_profile,
            predicted_scene=predicted_scene,
            scene_confidence=scene_confidence,
            touchpoints=touchpoints,
            stakeholders=stakeholders
        )
    
    def _retrieve_similar_memories(self, query: str, top_k: int = 3) -> List[StructuredMemory]:
        """检索相似的历史记忆"""
        if not self.structured_memories:
            return []
        
        # 简单的文本相似度计算
        query_words = set(query.lower().split())
        similarities = []
        
        for memory in self.structured_memories:
            memory_words = set(memory.user_query.lower().split())
            intersection = query_words & memory_words
            union = query_words | memory_words
            similarity = len(intersection) / len(union) if union else 0
            similarities.append((memory, similarity))
        
        similarities.sort(key=lambda x: x[1], reverse=True)
        return [m for m, s in similarities[:top_k] if s > 0.3]
    
    def _analyze_user_profile(self, query: str, context: Dict) -> Dict[str, Any]:
        """分析用户画像"""
        profile = {
            "role": "unknown",
            "industry": "unknown",
            "sophistication": "medium",
            "urgency": "normal"
        }
        
        # 角色识别
        if any(kw in query for kw in ["CEO", "老板", "管理层", "战略"]):
            profile["role"] = "executive"
            profile["sophistication"] = "high"
        elif any(kw in query for kw in ["设计师", "产品经理", "运营"]):
            profile["role"] = "practitioner"
        elif any(kw in query for kw in ["我们", "公司", "企业"]):
            profile["role"] = "business"
        
        # 行业识别
        industry_keywords = {
            "金融": ["银行", "保险", "金融", "支付"],
            "零售": ["零售", "电商", "门店", "导购"],
            "制造": ["制造", "工厂", "生产", "工业"],
            "医疗": ["医院", "医疗", "患者", "医生"],
            "科技": ["APP", "互联网", "数字化", "系统"]
        }
        for industry, keywords in industry_keywords.items():
            if any(kw in query for kw in keywords):
                profile["industry"] = industry
                break
        
        # 紧急程度
        if any(kw in query for kw in ["急", "马上", "尽快", " deadline"]):
            profile["urgency"] = "high"
        
        return profile
    
    def create_structured_memory(
        self,
        user_query: str,
        prediction: IntentPrediction,
        execution_result: Dict,
        feedback: Dict = None
    ) -> StructuredMemory:
        """
        创建结构化记忆
        
        将执行经验转化为可复用的结构化数据
        """
        memory_id = hashlib.md5(f"{user_query}_{datetime.now()}".encode()).hexdigest()[:16]
        
        # 生成触点向量
        touchpoint_vector = self._encode_touchpoints(prediction.touchpoints)
        
        # 生成利益相关者向量
        stakeholder_vector = self._encode_stakeholders(prediction.stakeholders)
        
        # 确定旅程阶段
        journey_stage = self._determine_journey_stage(prediction.touchpoints)
        
        # 计算商业价值
        business_value = execution_result.get("business_value", 0.5)
        
        # 计算成功率
        success_rate = 1.0 if execution_result.get("success", False) else 0.0
        
        # 反馈评分
        feedback_score = feedback.get("score", 0.5) if feedback else 0.5
        
        memory = StructuredMemory(
            memory_id=memory_id,
            timestamp=datetime.now().isoformat(),
            intent_type=prediction.primary_intent.value,
            scene_type=prediction.predicted_scene.value,
            user_query=user_query,
            context={
                "user_profile": prediction.user_profile,
                "secondary_intents": [(i.value, c) for i, c in prediction.secondary_intents],
                "touchpoints": prediction.touchpoints,
                "stakeholders": prediction.stakeholders
            },
            touchpoint_vector=touchpoint_vector,
            stakeholder_vector=stakeholder_vector,
            journey_stage=journey_stage,
            business_value=business_value,
            success_rate=success_rate,
            feedback_score=feedback_score
        )
        
        self.structured_memories.append(memory)
        self._save_structured_memories()
        
        return memory
    
    def _encode_touchpoints(self, touchpoints: List[str]) -> np.ndarray:
        """编码触点为向量"""
        vector = np.zeros(len(self.TOUCHPOINT_KEYWORDS))
        for tp in touchpoints:
            if tp in self.TOUCHPOINT_KEYWORDS:
                idx = self.TOUCHPOINT_KEYWORDS.index(tp)
                vector[idx] = 1.0
        return vector
    
    def _encode_stakeholders(self, stakeholders: List[str]) -> np.ndarray:
        """编码利益相关者为向量"""
        vector = np.zeros(len(self.STAKEHOLDER_KEYWORDS))
        for sh in stakeholders:
            if sh in self.STAKEHOLDER_KEYWORDS:
                idx = self.STAKEHOLDER_KEYWORDS.index(sh)
                vector[idx] = 1.0
        return vector
    
    def _determine_journey_stage(self, touchpoints: List[str]) -> str:
        """确定用户旅程阶段"""
        stage_keywords = {
            "awareness": ["听说", "了解"],
            "consideration": ["咨询", "预约", "下载"],
            "purchase": ["注册", "开户", "绑卡", "办理", "支付"],
            "retention": ["使用", "售后", "评价"],
            "advocacy": ["复购", "推荐"]
        }
        
        stage_scores = {stage: 0 for stage in stage_keywords}
        for tp in touchpoints:
            for stage, keywords in stage_keywords.items():
                if tp in keywords:
                    stage_scores[stage] += 1
        
        return max(stage_scores, key=stage_scores.get) if max(stage_scores.values()) > 0 else "unknown"
    
    def sandbox_execute(
        self,
        user_query: str,
        prediction: IntentPrediction
    ) -> Dict[str, Any]:
        """
        沙箱执行环境
        
        在隔离环境中测试执行策略
        """
        sandbox_id = hashlib.md5(f"{user_query}_{datetime.now()}".encode()).hexdigest()[:8]
        
        # 初始化沙箱
        self.sandbox[sandbox_id] = {
            "query": user_query,
            "prediction": {
                "intent": prediction.primary_intent.value,
                "confidence": prediction.confidence,
                "scene": prediction.predicted_scene.value
            },
            "touchpoints": prediction.touchpoints,
            "stakeholders": prediction.stakeholders,
            "execution_plan": self._generate_execution_plan(prediction),
            "status": "initialized",
            "results": {},
            "timestamp": datetime.now().isoformat()
        }
        
        # 模拟执行
        self.sandbox[sandbox_id]["status"] = "executing"
        
        # 基于意图类型生成模拟结果
        execution_plan = self.sandbox[sandbox_id]["execution_plan"]
        results = {
            "steps_completed": len(execution_plan),
            "estimated_business_value": np.random.uniform(0.6, 0.95),
            "risk_level": "low" if prediction.confidence > 0.7 else "medium",
            "recommendations": self._generate_recommendations(prediction)
        }
        
        self.sandbox[sandbox_id]["results"] = results
        self.sandbox[sandbox_id]["status"] = "completed"
        
        return {
            "sandbox_id": sandbox_id,
            "execution_results": results,
            "sandbox_state": self.sandbox[sandbox_id]
        }
    
    def _generate_execution_plan(self, prediction: IntentPrediction) -> List[Dict]:
        """生成执行计划"""
        plans = {
            IntentType.STRATEGY: [
                {"step": 1, "action": "战略现状分析", "agent": "expert"},
                {"step": 2, "action": "商业模式诊断", "agent": "research"},
                {"step": 3, "action": "服务设计战略制定", "agent": "expert"},
                {"step": 4, "action": "落地方案设计", "agent": "skill"}
            ],
            IntentType.JOURNEY: [
                {"step": 1, "action": "用户调研", "agent": "research"},
                {"step": 2, "action": "旅程地图绘制", "agent": "expert"},
                {"step": 3, "action": "痛点分析", "agent": "memory"},
                {"step": 4, "action": "优化方案设计", "agent": "skill"}
            ],
            IntentType.CO_CREATION: [
                {"step": 1, "action": "利益相关者识别", "agent": "memory"},
                {"step": 2, "action": "工作坊设计", "agent": "expert"},
                {"step": 3, "action": "共创执行", "agent": "lead"},
                {"step": 4, "action": "方案整合", "agent": "skill"}
            ],
            IntentType.TOUCHPOINT: [
                {"step": 1, "action": "触点审计", "agent": "browser"},
                {"step": 2, "action": "体验评估", "agent": "research"},
                {"step": 3, "action": "优化设计", "agent": "code"},
                {"step": 4, "action": "原型测试", "agent": "skill"}
            ],
            IntentType.SYSTEM: [
                {"step": 1, "action": "系统现状分析", "agent": "research"},
                {"step": 2, "action": "流程诊断", "agent": "memory"},
                {"step": 3, "action": "重构方案", "agent": "expert"},
                {"step": 4, "action": "实施计划", "agent": "skill"}
            ]
        }
        
        return plans.get(prediction.primary_intent, [
            {"step": 1, "action": "需求分析", "agent": "lead"},
            {"step": 2, "action": "方案设计", "agent": "expert"},
            {"step": 3, "action": "执行落地", "agent": "skill"}
        ])
    
    def _generate_recommendations(self, prediction: IntentPrediction) -> List[str]:
        """生成建议"""
        recommendations = []
        
        if prediction.primary_intent == IntentType.STRATEGY:
            recommendations = [
                "从全局系统角度审视商业模式",
                "识别指数级增长机会",
                "设计支撑战略的服务体系"
            ]
        elif prediction.primary_intent == IntentType.JOURNEY:
            recommendations = [
                "用'动线'工具拆解完整用户旅程",
                "识别关键痛点和机会点",
                "端到端优化而非单点改进"
            ]
        elif prediction.primary_intent == IntentType.CO_CREATION:
            recommendations = [
                "邀请所有利益相关者参与",
                "设计有效的共创工作坊",
                "让解决方案从参与者想法中生长"
            ]
        elif prediction.primary_intent == IntentType.TOUCHPOINT:
            recommendations = [
                "从用户视角审视每个触点",
                "确保前后端体验一致性",
                "关注商业价值的实现"
            ]
        else:
            recommendations = [
                "以用户为中心进行深度洞察",
                "考虑整体系统而非单点优化",
                "用商业价值衡量设计效果"
            ]
        
        return recommendations
    
    def target_retrieval(
        self,
        query_vector: np.ndarray,
        intent_filter: IntentType = None,
        min_success_rate: float = 0.7,
        top_k: int = 5
    ) -> List[StructuredMemory]:
        """
        靶向向量检索
        
        基于多维度向量相似度进行精准记忆检索
        """
        if not self.structured_memories:
            return []
        
        scored_memories = []
        
        for memory in self.structured_memories:
            # 过滤条件
            if intent_filter and memory.intent_type != intent_filter.value:
                continue
            if memory.success_rate < min_success_rate:
                continue
            
            # 计算综合相似度分数
            touchpoint_sim = self._cosine_similarity(
                query_vector[:len(self.TOUCHPOINT_KEYWORDS)],
                memory.touchpoint_vector
            )
            stakeholder_sim = self._cosine_similarity(
                query_vector[len(self.TOUCHPOINT_KEYWORDS):],
                memory.stakeholder_vector
            )
            
            # 加权综合分数
            composite_score = (
                touchpoint_sim * 0.4 +
                stakeholder_sim * 0.3 +
                memory.success_rate * 0.2 +
                memory.feedback_score * 0.1
            )
            
            scored_memories.append((memory, composite_score))
        
        # 排序并返回Top-K
        scored_memories.sort(key=lambda x: x[1], reverse=True)
        return [m for m, s in scored_memories[:top_k]]
    
    def _cosine_similarity(self, a: np.ndarray, b: np.ndarray) -> float:
        """计算余弦相似度"""
        norm_a = np.linalg.norm(a)
        norm_b = np.linalg.norm(b)
        if norm_a == 0 or norm_b == 0:
            return 0.0
        return float(np.dot(a, b) / (norm_a * norm_b))
    
    def quick_decision(
        self,
        user_query: str,
        context: Dict = None
    ) -> Dict[str, Any]:
        """
        快速决策支持
        
        基于记忆和经验快速给出决策建议
        """
        # 1. 意图预测
        prediction = self.predict_intent(user_query, context)
        
        # 2. 检索相关经验记忆
        query_vector = np.concatenate([
            self._encode_touchpoints(prediction.touchpoints),
            self._encode_stakeholders(prediction.stakeholders)
        ])
        
        relevant_memories = self.target_retrieval(
            query_vector,
            intent_filter=prediction.primary_intent,
            top_k=3
        )
        
        # 3. 沙箱预演
        sandbox_result = self.sandbox_execute(user_query, prediction)
        
        # 4. 整合决策建议
        decision = {
            "intent": {
                "type": prediction.primary_intent.value,
                "confidence": prediction.confidence,
                "description": self._get_intent_description(prediction.primary_intent)
            },
            "recommended_scene": {
                "type": prediction.predicted_scene.value,
                "confidence": prediction.scene_confidence
            },
            "user_profile": prediction.user_profile,
            "similar_experiences": [
                {
                    "query": m.user_query,
                    "success_rate": m.success_rate,
                    "business_value": m.business_value,
                    "key_learnings": m.context.get("key_learnings", [])
                }
                for m in relevant_memories
            ],
            "sandbox_preview": {
                "sandbox_id": sandbox_result["sandbox_id"],
                "estimated_value": sandbox_result["execution_results"]["estimated_business_value"],
                "risk_level": sandbox_result["execution_results"]["risk_level"]
            },
            "recommended_actions": sandbox_result["execution_results"]["recommendations"],
            "execution_plan": self._generate_execution_plan(prediction),
            "confidence_level": "high" if prediction.confidence > 0.8 else "medium" if prediction.confidence > 0.5 else "low"
        }
        
        return decision
    
    def _get_intent_description(self, intent: IntentType) -> str:
        """获取意图描述"""
        descriptions = {
            IntentType.STRATEGY: "服务设计战略升维 - 从全局系统角度重新审视商业模式",
            IntentType.JOURNEY: "用户旅程设计 - 用动线工具拆解端到端服务流程",
            IntentType.CO_CREATION: "共创式设计 - 邀请利益相关者共同参与设计",
            IntentType.TOUCHPOINT: "触点优化 - 从用户视角优化关键服务触点",
            IntentType.SYSTEM: "系统重构 - 优化组织流程和运营支撑体系",
            IntentType.GENERAL: "通用服务设计咨询"
        }
        return descriptions.get(intent, "未知意图")


def main():
    """主函数 - 测试服务设计意图预测系统"""
    engine = ServiceDesignIntentEngine()
    
    # 测试用例
    test_queries = [
        "我们想通过服务设计实现业务增长，需要战略升维",
        "银行APP用户满意度低，需要优化用户旅程",
        "如何设计一个共创工作坊来改进我们的服务",
        "门店服务体验不好，客户投诉很多",
        "公司各部门协作困难，需要系统重构"
    ]
    
    print("=" * 80)
    print("服务设计意图预测系统 v3.1 - 测试")
    print("=" * 80)
    
    for query in test_queries:
        print(f"\n[查询] {query}")
        print("-" * 80)
        
        # 快速决策
        decision = engine.quick_decision(query)
        
        print(f"[意图] {decision['intent']['type']} (置信度: {decision['intent']['confidence']:.2f})")
        print(f"[场景] {decision['recommended_scene']['type']}")
        print(f"[画像] {decision['user_profile']['role']} | {decision['user_profile']['industry']}")
        print(f"[等级] {decision['confidence_level']}")
        
        if decision['similar_experiences']:
            print(f"[经验] {len(decision['similar_experiences'])} 条")
        
        print(f"[沙箱] 预估价值 {decision['sandbox_preview']['estimated_value']:.2f}, 风险 {decision['sandbox_preview']['risk_level']}")
        
        print(f"\n[建议行动]:")
        for i, action in enumerate(decision['recommended_actions'], 1):
            print(f"   {i}. {action}")
    
    print("\n" + "=" * 80)
    print("测试完成!")


if __name__ == "__main__":
    main()
