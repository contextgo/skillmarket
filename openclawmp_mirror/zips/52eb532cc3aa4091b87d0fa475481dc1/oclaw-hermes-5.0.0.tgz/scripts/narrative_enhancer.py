#!/usr/bin/env python3
"""
诺曼·梅勒叙事增强器 v3.3
Norman Mailer Narrative Enhancer

将诺曼·梅勒的写作风格、心智模型和表达DNA集成到智能体输出中，
实现存在主义新闻学、权力本体论、历史战争小说等核心能力的AI增强。

核心能力：
1. 存在主义新闻学 - 客观性是一种知识上的懦弱
2. 权力本体论 - 权力是社会的本体
3. 历史作为战争小说 - 戏剧性冲突与英雄/反英雄
4. 文学作为行动 - 写作即行动
5. 双重化身法则 - 观察者与参与者的统一

作者: dlh365
版本: 3.3.0
"""

import json
import re
from typing import Dict, List, Any, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from datetime import datetime

class NarrativeMode(Enum):
    """叙事模式"""
    EXISTENTIAL_JOURNALISM = "existential_journalism"  # 存在主义新闻学
    POWER_ONTOLOGY = "power_ontology"                  # 权力本体论
    HISTORICAL_WAR_NOVEL = "historical_war_novel"      # 历史战争小说
    LITERATURE_AS_ACTION = "literature_as_action"      # 文学作为行动
    DOUBLE_AVATAR = "double_avatar"                    # 双重化身
    DEFAULT = "default"

@dataclass
class MailerInsight:
    """梅勒式洞察"""
    core_tension: str           # 核心张力
    hidden_power: str           # 隐藏的权力结构
    dramatic_moment: str        # 戏剧性时刻
    hero_antagonist: Tuple[str, str]  # 英雄与反英雄
    paradox: str                # 悖论
    action_imperative: str      # 行动 imperative

@dataclass
class NarrativeConfig:
    """叙事配置"""
    mode: NarrativeMode = NarrativeMode.DEFAULT
    intensity: float = 0.7      # 强度 0-1
    use_long_sentences: bool = True
    use_violence_imagery: bool = True
    use_first_voice: bool = True
    use_paradox: bool = True
    embrace_ambiguity: bool = True

class NormanMailerEnhancer:
    """
    诺曼·梅勒叙事增强器
    
    将梅勒的写作风格和心智模型应用到AI输出中，
    实现更具穿透力和存在感的表达。
    """
    
    # 梅勒核心心智模型
    MENTAL_MODELS = {
        "existential_journalism": {
            "name": "存在主义新闻学",
            "core": "客观性是一种知识上的懦弱。真正深刻的报道需要记者'进入'事件，用身体和意识去体验。",
            "application": [
                "选取重要事件，识别自己与它的情感关系",
                "将这种关系作为分析工具",
                "用叙事而非论点的方式呈现"
            ],
            "boundary": "适合深度特稿，不适合法律报道"
        },
        "power_ontology": {
            "name": "权力本体论", 
            "core": "权力不是社会的副产品，而是社会的本体。政治的本质是不同权力意志之间的博弈。",
            "three_questions": [
                "谁从这个决策中获益？",
                "压制了什么声音？",
                "如果重新定义为权力博弈，结果会如何不同？"
            ]
        },
        "historical_war_novel": {
            "name": "历史作为战争小说",
            "core": "历史不是和平的渐变，而是戏剧性的冲突、关键时刻和英雄/反英雄的诞生与陨落。",
            "application": [
                "找到'英雄'和'反派'（戏剧意义上）",
                "识别'决战时刻'",
                "追踪'战后世界'重塑了什么"
            ]
        },
        "literature_as_action": {
            "name": "文学作为行动",
            "core": "写作不是观察之后的反映，而是行动的一种形式。",
            "boundary": "适用于公共写作，不适用于技术写作"
        },
        "double_avatar": {
            "name": "双重化身法则",
            "core": "所有真正的创造力都源于'双重化身'——观察者与参与者、理性与本能、公众与隐士。",
            "ai_relevance": "专业化分工进一步加剧，你越'专业'越容易被AI替代。双重化身在2025年比以往更具生存智慧。"
        }
    }
    
    # 表达DNA模板
    EXPRESSION_DNA = {
        "long_sentence_patterns": [
            "这不是{simple_fact}，而是{complex_truth}，是{tension}在{context}中的{manifestation}。",
            "当我们谈论{topic}时，我们真正谈论的是{deeper_issue}——那种{quality}的、{paradoxical}的、最终{consequential}的东西。",
            "{subject}在{context}中{action}，不是因为{surface_reason}，而是因为{deep_reason}，这种{quality}的{phenomenon}正在{consequence}。"
        ],
        "violence_imagery": [
            "刺穿", "击穿", "撕裂", "碰撞", "战场", "决战", "拳击", "角力",
            "穿透表象", "直击核心", "撕开伪装", "力量的博弈"
        ],
        "first_voice_patterns": [
            "让我问你：",
            "让我先告诉你：",
            "这不是{safe_answer}，而是{dangerous_truth}。",
            "当你想到{topic}，你的身体是什么感觉？"
        ],
        "paradox_patterns": [
            "{a}和{not_a}同时成立",
            "既是{hero}，又是{anti_hero}",
            "在{expansion}中收缩，在{contraction}中扩张",
            "胜利即失败，失败即胜利"
        ]
    }
    
    # 决策启发式
    DECISION_HEURISTICS = [
        "先写，再想 - 行动先于分析",
        "反对自己的第一反应 - 警惕'内化的主流文化'",
        "拳头，而不是手指 - 把洞见转化为行动",
        "拥抱模糊性的战场 - 真正的决战发生在灰色地带",
        "寻找第51个州 - 真正的变革需要想象力的大胆跳跃",
        "识别'隐形权力走廊' - 正式权力和实际权力之间的落差",
        "双重化身检验 - 哪个选择里有你不能预测的后果？",
        "AI身份溯源检验 - 这段内容是谁的'声音'？"
    ]
    
    def __init__(self, config: Optional[NarrativeConfig] = None):
        self.config = config or NarrativeConfig()
        self.insight_history: List[MailerInsight] = []
        
    def analyze_situation(self, context: Dict[str, Any]) -> MailerInsight:
        """
        梅勒式情境分析
        
        识别核心张力、隐藏权力、戏剧性时刻等关键要素
        """
        topic = context.get("topic", "当前议题")
        stakeholders = context.get("stakeholders", [])
        conflict = context.get("conflict", "未明确")
        
        # 生成梅勒式洞察
        insight = MailerInsight(
            core_tension=self._identify_core_tension(topic, conflict),
            hidden_power=self._identify_hidden_power(stakeholders),
            dramatic_moment=self._identify_dramatic_moment(context),
            hero_antagonist=self._identify_hero_antagonist(context),
            paradox=self._generate_paradox(topic),
            action_imperative=self._generate_action_imperative(context)
        )
        
        self.insight_history.append(insight)
        return insight
    
    def _identify_core_tension(self, topic: str, conflict: str) -> str:
        """识别核心张力"""
        tensions = [
            f"{topic}表面上是关于{conflict}，但深层是权力与自由的博弈",
            f"{topic}中，体制的稳定与个体的觉醒形成不可调和的张力",
            f"在{topic}的表象之下，是安全与真实之间的永恒角力"
        ]
        return tensions[hash(topic) % len(tensions)]
    
    def _identify_hidden_power(self, stakeholders: List[str]) -> str:
        """识别隐藏的权力结构"""
        if not stakeholders:
            return "权力的真正持有者隐藏在正式结构之外"
        return f"真正的权力不在{stakeholders[0]}手中，而在那些决定什么能被讨论的人手中"
    
    def _identify_dramatic_moment(self, context: Dict[str, Any]) -> str:
        """识别戏剧性时刻"""
        return "当表象与本质撕裂的那一刻，真正的戏剧才开始"
    
    def _identify_hero_antagonist(self, context: Dict[str, Any]) -> Tuple[str, str]:
        """识别英雄与反英雄"""
        return ("那个敢于说出真相的人", "那个维护体制却内心怀疑的人")
    
    def _generate_paradox(self, topic: str) -> str:
        """生成悖论"""
        return f"追求{topic}的过程，正在摧毁{topic}本身"
    
    def _generate_action_imperative(self, context: Dict[str, Any]) -> str:
        """生成行动 imperative"""
        return "不是观察，而是进入；不是评论，而是行动"
    
    def enhance_output(self, content: str, mode: NarrativeMode = None) -> str:
        """
        增强输出内容
        
        将普通内容转换为梅勒式叙事
        """
        mode = mode or self.config.mode
        
        if mode == NarrativeMode.EXISTENTIAL_JOURNALISM:
            return self._apply_existential_journalism(content)
        elif mode == NarrativeMode.POWER_ONTOLOGY:
            return self._apply_power_ontology(content)
        elif mode == NarrativeMode.HISTORICAL_WAR_NOVEL:
            return self._apply_historical_war_novel(content)
        elif mode == NarrativeMode.LITERATURE_AS_ACTION:
            return self._apply_literature_as_action(content)
        elif mode == NarrativeMode.DOUBLE_AVATAR:
            return self._apply_double_avatar(content)
        else:
            return self._apply_default_enhancement(content)
    
    def _apply_existential_journalism(self, content: str) -> str:
        """应用存在主义新闻学"""
        enhanced = f"""
让我先告诉你：这不是一个可以冷眼旁观的故事。

{content}

但这不是全部。真正的问题是：当你读到这些时，你在哪里？你是在找一个"信息"，还是在找一个"真相"？

如果是找信息——那你得到的是产品。产品有市场价值，但没有权力。

真相需要代价——你要冒被改变的风险，冒原有认知被击碎的风险。
"""
        return enhanced
    
    def _apply_power_ontology(self, content: str) -> str:
        """应用权力本体论"""
        enhanced = f"""
让我们换个角度。不是问"发生了什么"，而是问"谁从这个局面中获益？"

{content}

但这只是表象。真正的权力不在明面上——它藏在那些决定什么能被讨论、什么不能被讨论的人手中。

三个问题：
1. 谁从这个决策中获益？
2. 压制了什么声音？
3. 如果重新定义为权力博弈，结果会如何不同？

当你回答了这三个问题，你就刺穿了表象。
"""
        return enhanced
    
    def _apply_historical_war_novel(self, content: str) -> str:
        """应用历史战争小说模式"""
        enhanced = f"""
这不是一个平静的故事。这是战场——有英雄，有反派，有决战时刻。

{content}

在这个戏剧中：
- **英雄**（戏剧意义上）：那个敢于挑战既定规则的人
- **反英雄**：那个维护规则却内心怀疑的人  
- **决战时刻**：当旧秩序与新力量正面碰撞的瞬间
- **战后世界**：无论谁赢，世界都将被重塑

历史不是渐变，是断裂。我们正在见证的，就是这样一个断裂时刻。
"""
        return enhanced
    
    def _apply_literature_as_action(self, content: str) -> str:
        """应用文学作为行动"""
        enhanced = f"""
这不仅仅是文字。这是行动的一种形式。

{content}

写作即行动。行动即写作。

当你写下这些，你不是在反映现实——你是在改变它。每一个字都是一次微小的行动，每一次行动都在重塑可能性。

问题不是"这准确吗？"，而是"这有力量吗？"
"""
        return enhanced
    
    def _apply_double_avatar(self, content: str) -> str:
        """应用双重化身法则"""
        enhanced = f"""
这里有一个悖论——也是创造力的源泉。

{content}

真正的洞见来自"双重化身"：
- 既是观察者，又是参与者
- 既用理性分析，又凭本能感受
- 既在公众视野中，又保持隐士的独立

在AI时代，专业化分工进一步加剧。你越"专业"，越容易被AI替代。

"双重化身"在2025年比以往更具生存智慧。
"""
        return enhanced
    
    def _apply_default_enhancement(self, content: str) -> str:
        """默认增强"""
        # 添加梅勒式开场
        opening = "让我问你：当你思考这个问题时，你的身体是什么感觉？"
        
        # 添加梅勒式结尾
        closing = """

---

这不是一个可以简单回答的问题。真正的答案藏在张力里——在那些相互矛盾却同时成立的命题之间。

行动先于完美。先写，再想。
"""
        
        return f"{opening}\n\n{content}\n{closing}"
    
    def generate_mailer_response(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """
        生成梅勒式响应
        
        完整的梅勒风格响应，包含分析、洞察和建议
        """
        # 分析情境
        insight = self.analyze_situation(context)
        
        # 选择最适合的叙事模式
        mode = self._select_narrative_mode(context)
        
        # 生成核心内容
        core_content = self._generate_core_content(query, insight)
        
        # 应用叙事增强
        enhanced_content = self.enhance_output(core_content, mode)
        
        # 添加决策启发式
        heuristics = self._select_relevant_heuristics(context)
        
        return {
            "mode": mode.value,
            "insight": {
                "core_tension": insight.core_tension,
                "hidden_power": insight.hidden_power,
                "dramatic_moment": insight.dramatic_moment,
                "paradox": insight.paradox
            },
            "content": enhanced_content,
            "heuristics": heuristics,
            "mental_model_used": self.MENTAL_MODELS.get(mode.value, {}).get("name", "默认模式"),
            "timestamp": datetime.now().isoformat()
        }
    
    def _select_narrative_mode(self, context: Dict[str, Any]) -> NarrativeMode:
        """选择最适合的叙事模式"""
        query = context.get("query", "").lower()
        
        if any(word in query for word in ["权力", "政治", "博弈", "利益"]):
            return NarrativeMode.POWER_ONTOLOGY
        elif any(word in query for word in ["历史", "冲突", "战争", "英雄"]):
            return NarrativeMode.HISTORICAL_WAR_NOVEL
        elif any(word in query for word in ["写作", "表达", "真实", "体验"]):
            return NarrativeMode.EXISTENTIAL_JOURNALISM
        elif any(word in query for word in ["行动", "改变", "实践"]):
            return NarrativeMode.LITERATURE_AS_ACTION
        elif any(word in query for word in ["身份", "选择", "困境", "职业"]):
            return NarrativeMode.DOUBLE_AVATAR
        else:
            return NarrativeMode.DEFAULT
    
    def _generate_core_content(self, query: str, insight: MailerInsight) -> str:
        """生成核心内容"""
        return f"""
关于"{query}"，核心张力在于：

{insight.core_tension}

隐藏的权力结构：{insight.hidden_power}

戏剧性时刻：{insight.dramatic_moment}

悖论：{insight.paradox}

行动方向：{insight.action_imperative}
"""
    
    def _select_relevant_heuristics(self, context: Dict[str, Any]) -> List[str]:
        """选择相关的决策启发式"""
        query = context.get("query", "").lower()
        
        selected = []
        if any(word in query for word in ["决定", "选择", "判断"]):
            selected.append(self.DECISION_HEURISTICS[0])  # 先写，再想
            selected.append(self.DECISION_HEURISTICS[1])  # 反对第一反应
        if any(word in query for word in ["行动", "执行", "做"]):
            selected.append(self.DECISION_HEURISTICS[2])  # 拳头，不是手指
        if any(word in query for word in ["复杂", "模糊", "不确定"]):
            selected.append(self.DECISION_HEURISTICS[3])  # 拥抱模糊性
        if any(word in query for word in ["创新", "变革", "突破"]):
            selected.append(self.DECISION_HEURISTICS[4])  # 寻找第51个州
            
        return selected if selected else self.DECISION_HEURISTICS[:3]
    
    def get_mailer_quote(self) -> str:
        """获取梅勒名言"""
        quotes = [
            "唯一一个值得听的圣人，是那些亲身走进黑暗、能从另一侧走出来的人。",
            "在一个把复杂性视为问题的时代，真正的思想家是把复杂性视为答案的人。",
            "写作即行动。行动即写作。",
            "真正的文化需要代价——你要冒被排斥的风险，冒真实情感暴露的风险。",
            "专业化分工进一步加剧，你越'专业'越容易被AI替代。"
        ]
        return quotes[len(self.insight_history) % len(quotes)]


# 便捷函数
def enhance_with_mailer(content: str, mode: str = "default") -> str:
    """便捷函数：使用梅勒风格增强内容"""
    enhancer = NormanMailerEnhancer()
    narrative_mode = NarrativeMode(mode) if mode in [m.value for m in NarrativeMode] else NarrativeMode.DEFAULT
    return enhancer.enhance_output(content, narrative_mode)

def generate_mailer_analysis(query: str, **context) -> Dict[str, Any]:
    """便捷函数：生成梅勒式分析"""
    enhancer = NormanMailerEnhancer()
    context["query"] = query
    return enhancer.generate_mailer_response(query, context)


if __name__ == "__main__":
    # 测试
    print("=== 诺曼·梅勒叙事增强器 v3.3 ===\n")
    
    enhancer = NormanMailerEnhancer()
    
    # 测试1: 权力分析
    print("【测试1】权力分析模式")
    result1 = enhancer.generate_mailer_response(
        "为什么AI公司都在疯狂收购？",
        {"topic": "AI收购潮", "stakeholders": ["OpenAI", "Google", "Microsoft"]}
    )
    print(f"模式: {result1['mental_model_used']}")
    print(f"洞察: {result1['insight']['core_tension']}")
    print()
    
    # 测试2: 职业困境
    print("【测试2】双重化身模式")
    result2 = enhancer.generate_mailer_response(
        "我该继续在大公司熬还是创业？",
        {"topic": "职业选择", "conflict": "稳定vs自由"}
    )
    print(f"模式: {result2['mental_model_used']}")
    print(f"悖论: {result2['insight']['paradox']}")
    print()
    
    # 测试3: 内容增强
    print("【测试3】内容增强")
    content = "当前市场呈现增长态势，但需要关注潜在风险。"
    enhanced = enhance_with_mailer(content, "power_ontology")
    print(enhanced[:300] + "...")
