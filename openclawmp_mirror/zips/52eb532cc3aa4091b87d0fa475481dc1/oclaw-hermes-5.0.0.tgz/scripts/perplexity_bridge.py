#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Perplexity 桥接器 v1.0.0

整合 Perplexity AI 的深度搜索与实时信息检索能力
to oclaw-hermes 六位一体架构

核心能力：
1. **实时搜索** - 获取最新互联网信息
2. **深度研究** - 多源信息综合分析
3. **引用溯源** - 所有回答附带来源链接
4. **多模型支持** - sonar/sonar-pro/sonar-reasoning

Author: ruiyongwang
Version: 1.0.0
"""

import os
import json
import asyncio
import aiohttp
from typing import Dict, List, Any, Optional, AsyncGenerator
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class PerplexityModel(Enum):
    """Perplexity 模型类型"""
    SONAR = "sonar"                          # 轻量级，快速响应
    SONAR_PRO = "sonar-pro"                  # 专业级，深度分析
    SONAR_REASONING = "sonar-reasoning"      # 推理型，复杂问题


class SearchMode(Enum):
    """搜索模式"""
    QUICK = "quick"           # 快速搜索，1-2句话
    STANDARD = "standard"     # 标准搜索，详细回答
    DEEP = "deep"             # 深度搜索，综合分析
    RESEARCH = "research"     # 研究模式，多轮迭代


@dataclass
class PerplexityResponse:
    """Perplexity 响应结构"""
    content: str
    citations: List[str]
    model: str
    usage: Dict[str, int]
    latency: float
    timestamp: datetime = field(default_factory=datetime.now)
    
    def to_dict(self) -> Dict:
        return {
            "content": self.content,
            "citations": self.citations,
            "model": self.model,
            "usage": self.usage,
            "latency": self.latency,
            "timestamp": self.timestamp.isoformat()
        }


@dataclass
class ResearchSession:
    """研究会话"""
    session_id: str
    topic: str
    queries: List[str]
    responses: List[PerplexityResponse]
    synthesized_report: str = ""
    created_at: datetime = field(default_factory=datetime.now)


class PerplexityBridge:
    """
    Perplexity AI 桥接器
    
    提供实时搜索、深度研究、引用溯源能力
    """
    
    API_BASE = "https://api.perplexity.ai"
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("PERPLEXITY_API_KEY")
        self.session = None
        self._research_sessions: Dict[str, ResearchSession] = {}
        
    async def _get_session(self) -> aiohttp.ClientSession:
        """获取 HTTP 会话"""
        if self.session is None or self.session.closed:
            self.session = aiohttp.ClientSession(
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                }
            )
        return self.session
    
    async def search(
        self,
        query: str,
        model: PerplexityModel = PerplexityModel.SONAR_PRO,
        mode: SearchMode = SearchMode.STANDARD,
        temperature: float = 0.2,
        max_tokens: int = 2000,
        return_citations: bool = True
    ) -> PerplexityResponse:
        """
        执行 Perplexity 搜索
        
        Args:
            query: 搜索查询
            model: 模型类型
            mode: 搜索模式
            temperature: 温度参数
            max_tokens: 最大 token 数
            return_citations: 是否返回引用
            
        Returns:
            PerplexityResponse: 搜索结果
        """
        if not self.api_key:
            raise ValueError("Perplexity API key not configured")
        
        session = await self._get_session()
        
        # 根据模式调整系统提示
        system_prompts = {
            SearchMode.QUICK: "Provide a concise, 1-2 sentence answer.",
            SearchMode.STANDARD: "Provide a comprehensive answer with relevant details.",
            SearchMode.DEEP: "Provide an in-depth analysis with multiple perspectives and sources.",
            SearchMode.RESEARCH: "Conduct thorough research. Synthesize information from multiple sources. Include citations."
        }
        
        payload = {
            "model": model.value,
            "messages": [
                {
                    "role": "system",
                    "content": system_prompts.get(mode, system_prompts[SearchMode.STANDARD])
                },
                {
                    "role": "user",
                    "content": query
                }
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "return_citations": return_citations
        }
        
        start_time = asyncio.get_event_loop().time()
        
        async with session.post(
            f"{self.API_BASE}/chat/completions",
            json=payload
        ) as response:
            if response.status != 200:
                error_text = await response.text()
                raise Exception(f"Perplexity API error: {response.status} - {error_text}")
            
            data = await response.json()
            latency = asyncio.get_event_loop().time() - start_time
            
            # 解析响应
            message = data["choices"][0]["message"]
            content = message["content"]
            citations = data.get("citations", [])
            usage = data.get("usage", {})
            
            return PerplexityResponse(
                content=content,
                citations=citations,
                model=model.value,
                usage=usage,
                latency=latency
            )
    
    async def deep_research(
        self,
        topic: str,
        sub_questions: List[str] = None,
        model: PerplexityModel = PerplexityModel.SONAR_REASONING
    ) -> ResearchSession:
        """
        执行深度研究
        
        Args:
            topic: 研究主题
            sub_questions: 子问题列表
            model: 模型类型
            
        Returns:
            ResearchSession: 研究会话
        """
        import uuid
        session_id = str(uuid.uuid4())[:8]
        
        # 生成子问题（如果没有提供）
        if not sub_questions:
            exploration = await self.search(
                query=f"What are the key aspects and sub-topics to research about: {topic}?",
                model=model,
                mode=SearchMode.DEEP
            )
            # 简单解析子问题（实际应用中可以更智能）
            sub_questions = [
                f"Overview of {topic}",
                f"Current trends in {topic}",
                f"Key challenges in {topic}",
                f"Future outlook for {topic}"
            ]
        
        responses = []
        for question in sub_questions:
            response = await self.search(
                query=question,
                model=model,
                mode=SearchMode.RESEARCH
            )
            responses.append(response)
        
        # 综合报告
        synthesis_prompt = f"""Based on the following research about "{topic}", 
        synthesize a comprehensive report with key findings and recommendations.
        
        Research points covered:
        """
        for i, (q, r) in enumerate(zip(sub_questions, responses)):
            synthesis_prompt += f"\n{i+1}. {q}: {r.content[:500]}..."
        
        synthesis = await self.search(
            query=synthesis_prompt,
            model=model,
            mode=SearchMode.DEEP
        )
        
        session = ResearchSession(
            session_id=session_id,
            topic=topic,
            queries=sub_questions,
            responses=responses,
            synthesized_report=synthesis.content
        )
        
        self._research_sessions[session_id] = session
        return session
    
    async def stream_search(
        self,
        query: str,
        model: PerplexityModel = PerplexityModel.SONAR_PRO
    ) -> AsyncGenerator[str, None]:
        """
        流式搜索
        
        Args:
            query: 搜索查询
            model: 模型类型
            
        Yields:
            str: 流式响应片段
        """
        if not self.api_key:
            raise ValueError("Perplexity API key not configured")
        
        session = await self._get_session()
        
        payload = {
            "model": model.value,
            "messages": [{"role": "user", "content": query}],
            "stream": True
        }
        
        async with session.post(
            f"{self.API_BASE}/chat/completions",
            json=payload
        ) as response:
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line.startswith('data: '):
                    data_str = line[6:]
                    if data_str == '[DONE]':
                        break
                    try:
                        data = json.loads(data_str)
                        delta = data["choices"][0].get("delta", {})
                        if "content" in delta:
                            yield delta["content"]
                    except:
                        pass
    
    async def fact_check(
        self,
        statement: str,
        model: PerplexityModel = PerplexityModel.SONAR_PRO
    ) -> Dict[str, Any]:
        """
        事实核查
        
        Args:
            statement: 待核查的陈述
            model: 模型类型
            
        Returns:
            Dict: 核查结果
        """
        query = f"""Fact-check this statement: "{statement}"
        
        Provide:
        1. Verification status (True/False/Partially True/Unverified)
        2. Explanation with sources
        3. Confidence level (High/Medium/Low)
        """
        
        response = await self.search(
            query=query,
            model=model,
            mode=SearchMode.DEEP
        )
        
        return {
            "statement": statement,
            "verification": response.content,
            "citations": response.citations,
            "model": model.value
        }
    
    async def compare_sources(
        self,
        query: str,
        sources: List[str] = None
    ) -> Dict[str, Any]:
        """
        多源对比分析
        
        Args:
            query: 查询主题
            sources: 指定来源列表
            
        Returns:
            Dict: 对比分析结果
        """
        source_filter = f" Focus on these sources: {', '.join(sources)}." if sources else ""
        
        comparison_query = f"""Compare different perspectives and sources on: {query}
        {source_filter}
        
        Provide:
        1. Key points of agreement
        2. Points of disagreement or controversy
        3. Unique insights from each source
        4. Overall consensus level
        """
        
        response = await self.search(
            query=comparison_query,
            model=PerplexityModel.SONAR_REASONING,
            mode=SearchMode.DEEP
        )
        
        return {
            "query": query,
            "comparison": response.content,
            "citations": response.citations,
            "sources_analyzed": len(response.citations)
        }
    
    def get_research_session(self, session_id: str) -> Optional[ResearchSession]:
        """获取研究会话"""
        return self._research_sessions.get(session_id)
    
    def list_research_sessions(self) -> List[Dict]:
        """列出所有研究会话"""
        return [
            {
                "session_id": s.session_id,
                "topic": s.topic,
                "queries_count": len(s.queries),
                "created_at": s.created_at.isoformat()
            }
            for s in self._research_sessions.values()
        ]
    
    async def close(self):
        """关闭连接"""
        if self.session and not self.session.closed:
            await self.session.close()
    
    def __enter__(self):
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        asyncio.run(self.close())


# ==================== 同步包装器 ====================

class PerplexityBridgeSync:
    """Perplexity 桥接器同步包装"""
    
    def __init__(self, api_key: Optional[str] = None):
        self._bridge = PerplexityBridge(api_key)
        self._loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self._loop)
    
    def search(self, *args, **kwargs) -> PerplexityResponse:
        """同步搜索"""
        return self._loop.run_until_complete(
            self._bridge.search(*args, **kwargs)
        )
    
    def deep_research(self, *args, **kwargs) -> ResearchSession:
        """同步深度研究"""
        return self._loop.run_until_complete(
            self._bridge.deep_research(*args, **kwargs)
        )
    
    def fact_check(self, *args, **kwargs) -> Dict:
        """同步事实核查"""
        return self._loop.run_until_complete(
            self._bridge.fact_check(*args, **kwargs)
        )
    
    def compare_sources(self, *args, **kwargs) -> Dict:
        """同步多源对比"""
        return self._loop.run_until_complete(
            self._bridge.compare_sources(*args, **kwargs)
        )
    
    def close(self):
        """关闭"""
        self._loop.run_until_complete(self._bridge.close())
        self._loop.close()


# ==================== 命令行测试 ====================

if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python perplexity_bridge.py <query>")
        print("Example: python perplexity_bridge.py 'Latest AI developments 2026'")
        sys.exit(1)
    
    query = " ".join(sys.argv[1:])
    
    bridge = PerplexityBridgeSync()
    try:
        print(f"🔍 Searching: {query}\n")
        result = bridge.search(query, mode=SearchMode.STANDARD)
        
        print(f"📊 Model: {result.model}")
        print(f"⏱️  Latency: {result.latency:.2f}s")
        print(f"📝 Tokens: {result.usage}\n")
        
        print("💡 Answer:")
        print(result.content)
        
        if result.citations:
            print(f"\n📚 Citations ({len(result.citations)}):")
            for i, citation in enumerate(result.citations[:5], 1):
                print(f"  {i}. {citation}")
    finally:
        bridge.close()
