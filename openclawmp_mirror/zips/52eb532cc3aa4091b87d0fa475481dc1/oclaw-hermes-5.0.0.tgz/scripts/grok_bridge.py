#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Grok 桥接器 v1.0

实现 xAI Grok 大语言模型的完整集成，提供：
- 实时对话：流式响应、多轮对话
- 图像理解：Grok-2-Vision 图像分析
- 代码生成：编程辅助、代码解释
- 长上下文：128K 上下文窗口支持
- 实时数据：通过 X 平台获取最新信息

Author: ruiyongwang
Version: 1.0.0
"""

import os
import json
import asyncio
import aiohttp
from typing import Dict, List, Any, Optional, AsyncGenerator, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum


class GrokModel(Enum):
    """Grok 模型类型"""
    GROK_2 = "grok-2"                          # 标准模型
    GROK_2_MINI = "grok-2-mini"                # 轻量级
    GROK_2_VISION = "grok-2-vision"            # 视觉理解
    GROK_BETA = "grok-beta"                    # Beta版本


class ResponseFormat(Enum):
    """响应格式"""
    TEXT = "text"
    JSON = "json_object"


@dataclass
class GrokMessage:
    """Grok 消息"""
    role: str  # system, user, assistant
    content: str
    name: Optional[str] = None
    images: List[str] = field(default_factory=list)  # base64 编码的图像
    
    def to_dict(self) -> Dict[str, Any]:
        msg = {"role": self.role, "content": self.content}
        if self.name:
            msg["name"] = self.name
        return msg


@dataclass
class GrokResponse:
    """Grok 响应"""
    content: str
    model: str
    usage: Dict[str, int]
    finish_reason: str
    created_at: datetime
    citations: List[str] = field(default_factory=list)  # 引用来源
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "content": self.content,
            "model": self.model,
            "usage": self.usage,
            "finish_reason": self.finish_reason,
            "created_at": self.created_at.isoformat(),
            "citations": self.citations
        }


@dataclass
class Conversation:
    """对话会话"""
    id: str
    messages: List[GrokMessage]
    model: GrokModel
    created_at: datetime
    updated_at: datetime
    metadata: Dict[str, Any] = field(default_factory=dict)


class GrokBridge:
    """
    Grok 桥接器
    
    提供与 xAI Grok API 的完整集成
    """
    
    API_BASE = "https://api.x.ai/v1"
    
    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or os.getenv("XAI_API_KEY")
        self.session: Optional[aiohttp.ClientSession] = None
        self.conversations: Dict[str, Conversation] = {}
        
    async def __aenter__(self):
        self.session = aiohttp.ClientSession()
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        if self.session:
            await self.session.close()
    
    def _get_headers(self) -> Dict[str, str]:
        """获取请求头"""
        return {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
    
    async def chat(
        self,
        messages: List[GrokMessage],
        model: GrokModel = GrokModel.GROK_2,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        stream: bool = False,
        response_format: Optional[ResponseFormat] = None
    ) -> Union[GrokResponse, AsyncGenerator[str, None]]:
        """
        对话接口
        
        Args:
            messages: 消息列表
            model: 模型类型
            temperature: 温度参数
            max_tokens: 最大token数
            stream: 是否流式输出
            response_format: 响应格式
            
        Returns:
            GrokResponse 或 异步生成器（流式）
        """
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        payload = {
            "model": model.value,
            "messages": [m.to_dict() for m in messages],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "stream": stream
        }
        
        if response_format:
            payload["response_format"] = {"type": response_format.value}
        
        if stream:
            return self._stream_chat(payload)
        
        async with self.session.post(
            f"{self.API_BASE}/chat/completions",
            headers=self._get_headers(),
            json=payload
        ) as response:
            if response.status != 200:
                error = await response.text()
                raise Exception(f"Grok API Error: {error}")
            
            data = await response.json()
            choice = data["choices"][0]
            
            return GrokResponse(
                content=choice["message"]["content"],
                model=data["model"],
                usage=data.get("usage", {}),
                finish_reason=choice.get("finish_reason", "stop"),
                created_at=datetime.fromtimestamp(data["created"]),
                citations=data.get("citations", [])
            )
    
    async def _stream_chat(self, payload: Dict[str, Any]) -> AsyncGenerator[str, None]:
        """流式对话"""
        async with self.session.post(
            f"{self.API_BASE}/chat/completions",
            headers=self._get_headers(),
            json=payload
        ) as response:
            if response.status != 200:
                error = await response.text()
                raise Exception(f"Grok API Error: {error}")
            
            async for line in response.content:
                line = line.decode('utf-8').strip()
                if line.startswith("data: "):
                    data_str = line[6:]
                    if data_str == "[DONE]":
                        break
                    try:
                        data = json.loads(data_str)
                        delta = data["choices"][0].get("delta", {})
                        if "content" in delta:
                            yield delta["content"]
                    except json.JSONDecodeError:
                        continue
    
    async def vision(
        self,
        image_url: str,
        prompt: str,
        model: GrokModel = GrokModel.GROK_2_VISION,
        max_tokens: int = 4096
    ) -> GrokResponse:
        """
        图像理解
        
        Args:
            image_url: 图像URL或base64编码
            prompt: 提示词
            model: 视觉模型
            max_tokens: 最大token数
            
        Returns:
            GrokResponse
        """
        messages = [
            GrokMessage(role="user", content=[
                {"type": "text", "text": prompt},
                {"type": "image_url", "image_url": {"url": image_url}}
            ])
        ]
        
        return await self.chat(messages, model=model, max_tokens=max_tokens)
    
    async def code_generate(
        self,
        description: str,
        language: str = "python",
        context: Optional[str] = None,
        temperature: float = 0.2
    ) -> GrokResponse:
        """
        代码生成
        
        Args:
            description: 代码描述
            language: 编程语言
            context: 上下文代码
            temperature: 温度参数（低温度更确定）
            
        Returns:
            GrokResponse
        """
        system_msg = GrokMessage(
            role="system",
            content=f"You are an expert {language} programmer. Generate clean, well-documented code."
        )
        
        user_content = f"Generate {language} code for: {description}"
        if context:
            user_content += f"\n\nContext:\n```\n{context}\n```"
        
        user_msg = GrokMessage(role="user", content=user_content)
        
        return await self.chat(
            [system_msg, user_msg],
            model=GrokModel.GROK_2,
            temperature=temperature
        )
    
    async def code_explain(
        self,
        code: str,
        language: str = "python",
        detail_level: str = "medium"
    ) -> GrokResponse:
        """
        代码解释
        
        Args:
            code: 代码内容
            language: 编程语言
            detail_level: 详细程度 (brief/medium/detailed)
            
        Returns:
            GrokResponse
        """
        prompts = {
            "brief": "Briefly explain what this code does in one sentence:",
            "medium": "Explain this code's functionality, logic flow, and key components:",
            "detailed": "Provide a detailed analysis including functionality, logic flow, algorithm complexity, potential issues, and improvement suggestions:"
        }
        
        prompt = prompts.get(detail_level, prompts["medium"])
        
        messages = [
            GrokMessage(role="user", content=f"{prompt}\n\n```{language}\n{code}\n```")
        ]
        
        return await self.chat(messages)
    
    def create_conversation(
        self,
        model: GrokModel = GrokModel.GROK_2,
        system_prompt: Optional[str] = None
    ) -> str:
        """
        创建对话会话
        
        Args:
            model: 模型类型
            system_prompt: 系统提示词
            
        Returns:
            会话ID
        """
        import uuid
        conv_id = str(uuid.uuid4())
        
        messages = []
        if system_prompt:
            messages.append(GrokMessage(role="system", content=system_prompt))
        
        now = datetime.now()
        self.conversations[conv_id] = Conversation(
            id=conv_id,
            messages=messages,
            model=model,
            created_at=now,
            updated_at=now
        )
        
        return conv_id
    
    async def chat_in_conversation(
        self,
        conversation_id: str,
        user_message: str,
        stream: bool = False
    ) -> Union[GrokResponse, AsyncGenerator[str, None]]:
        """
        在会话中对话
        
        Args:
            conversation_id: 会话ID
            user_message: 用户消息
            stream: 是否流式
            
        Returns:
            GrokResponse 或 异步生成器
        """
        if conversation_id not in self.conversations:
            raise ValueError(f"Conversation {conversation_id} not found")
        
        conv = self.conversations[conversation_id]
        conv.messages.append(GrokMessage(role="user", content=user_message))
        
        response = await self.chat(conv.messages, model=conv.model, stream=stream)
        
        if not stream:
            conv.messages.append(GrokMessage(role="assistant", content=response.content))
            conv.updated_at = datetime.now()
        
        return response
    
    async def get_realtime_info(self, query: str) -> GrokResponse:
        """
        获取实时信息（通过 X 平台）
        
        Args:
            query: 查询内容
            
        Returns:
            GrokResponse
        """
        system_msg = GrokMessage(
            role="system",
            content="You have access to real-time information through X (Twitter). Provide current, up-to-date information."
        )
        
        user_msg = GrokMessage(
            role="user",
            content=f"Provide the latest information about: {query}. Include relevant recent events or developments."
        )
        
        return await self.chat([system_msg, user_msg], model=GrokModel.GROK_2)
    
    async def list_models(self) -> List[Dict[str, Any]]:
        """列出可用模型"""
        if not self.session:
            self.session = aiohttp.ClientSession()
        
        async with self.session.get(
            f"{self.API_BASE}/models",
            headers=self._get_headers()
        ) as response:
            if response.status != 200:
                error = await response.text()
                raise Exception(f"Grok API Error: {error}")
            
            data = await response.json()
            return data.get("data", [])
    
    def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        return {
            "available": bool(self.api_key),
            "api_key_configured": bool(self.api_key),
            "models": [m.value for m in GrokModel],
            "conversations_active": len(self.conversations),
            "session_active": self.session is not None
        }


class GrokBridgeSync:
    """
    Grok 同步桥接器（同步版本）
    
    为不支持异步的调用方提供同步接口
    """
    
    def __init__(self, api_key: Optional[str] = None):
        self.async_bridge = GrokBridge(api_key)
        self._loop = None
    
    def _get_loop(self):
        """获取事件循环"""
        try:
            return asyncio.get_event_loop()
        except RuntimeError:
            return asyncio.new_event_loop()
    
    def _run_async(self, coro):
        """运行异步协程"""
        loop = self._get_loop()
        return loop.run_until_complete(coro)
    
    def chat(
        self,
        messages: List[GrokMessage],
        model: GrokModel = GrokModel.GROK_2,
        **kwargs
    ) -> GrokResponse:
        """同步对话"""
        async def _chat():
            async with self.async_bridge as bridge:
                return await bridge.chat(messages, model, **kwargs)
        return self._run_async(_chat())
    
    def code_generate(self, description: str, **kwargs) -> GrokResponse:
        """同步代码生成"""
        async def _gen():
            async with self.async_bridge as bridge:
                return await bridge.code_generate(description, **kwargs)
        return self._run_async(_gen())
    
    def code_explain(self, code: str, **kwargs) -> GrokResponse:
        """同步代码解释"""
        async def _exp():
            async with self.async_bridge as bridge:
                return await bridge.code_explain(code, **kwargs)
        return self._run_async(_exp())
    
    def health_check(self) -> Dict[str, Any]:
        """健康检查"""
        return self.async_bridge.health_check()


# 便捷函数
def quick_chat(message: str, api_key: Optional[str] = None) -> str:
    """
    快速对话
    
    Args:
        message: 用户消息
        api_key: API密钥（可选，默认从环境变量读取）
        
    Returns:
        助手回复
    """
    bridge = GrokBridgeSync(api_key)
    messages = [GrokMessage(role="user", content=message)]
    response = bridge.chat(messages)
    return response.content


def quick_code(description: str, language: str = "python", api_key: Optional[str] = None) -> str:
    """
    快速代码生成
    
    Args:
        description: 代码描述
        language: 编程语言
        api_key: API密钥
        
    Returns:
        生成的代码
    """
    bridge = GrokBridgeSync(api_key)
    response = bridge.code_generate(description, language=language)
    return response.content


if __name__ == "__main__":
    # 测试
    print("Grok Bridge v1.0 - 测试模式")
    print("-" * 50)
    
    # 健康检查
    bridge = GrokBridge()
    health = bridge.health_check()
    print(f"健康检查: {health}")
    
    if health["available"]:
        print("\n✅ Grok API 已配置")
        
        # 异步测试
        async def test():
            async with GrokBridge() as bridge:
                # 简单对话
                messages = [GrokMessage(role="user", content="Hello, who are you?")]
                try:
                    response = await bridge.chat(messages)
                    print(f"\n对话测试:\n{response.content[:200]}...")
                except Exception as e:
                    print(f"\n对话测试失败: {e}")
        
        asyncio.run(test())
    else:
        print("\n⚠️ Grok API 未配置，请设置 XAI_API_KEY 环境变量")
