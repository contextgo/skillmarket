#!/usr/bin/env python3
"""
超能力工作流编排器 v3.7
Super Capability Workflow Orchestrator

解构并整合市面上三种主流智能体架构的核心能力：
1. **Hermes 架构** - 自进化记忆 + 技能蒸馏
2. **DeerFlow 架构** - LangGraph编排 + 深度研究链 + 代码沙箱 + 多智能体协作
3. **OpenAI Swarm 架构** - 轻量级多智能体 + 函数调用 + 上下文交接

形成统一的超能力工作流系统。

更新 v3.7:
- 集成 SwarmBridge，实现真正的 Swarm 多智能体协作
- 新增智能体注册中心、上下文管理、函数路由
- 超能力工作流现在可以调用 Swarm 能力

作者: dlh365
版本: 3.7.0
"""

import asyncio
import json
import hashlib
from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from concurrent.futures import ThreadPoolExecutor, as_completed
import sys
sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from mflow_v2 import MFlowEngineV2, MemoryEntry
from narrative_enhancer import NormanMailerEnhancer
from deerflow_bridge import (
    DeerFlowBridge, DeepResearchChain, CodeSandbox,
    MultiAgentCollaboration, ToolOrchestrator,
    ResearchDepth, CodeLanguage, ResearchReport
)
from swarm_bridge import (
    SwarmBridge, SwarmAgent, AgentFunction, SwarmExecution,
    SwarmMessage, HandoffEvent, HandoffStrategy
)

class WorkflowType(Enum):
    """工作流类型"""
    # Hermes 风格工作流
    MEMORY_EVOLUTION = "memory_evolution"      # 记忆进化
    SKILL_DISTILLATION = "skill_distillation"  # 技能蒸馏
    EXPERT_CLONING = "expert_cloning"          # 专家克隆
    
    # DeerFlow 风格工作流
    DEEP_RESEARCH = "deep_research"            # 深度研究
    CODE_EXECUTION = "code_execution"          # 代码执行
    MULTI_AGENT_CHAIN = "multi_agent_chain"    # 多智能体链
    TOOL_ORCHESTRATION = "tool_orchestration"  # 工具编排
    RESEARCH_WITH_CODE = "research_with_code"  # 研究+代码组合
    
    # Swarm 风格工作流
    LIGHTWEIGHT_SWARM = "lightweight_swarm"    # 轻量级群体
    FUNCTION_ROUTING = "function_routing"      # 函数路由
    CONTEXT_HANDOFF = "context_handoff"        # 上下文交接
    
    # 超能力组合工作流
    HYPER_RESEARCH = "hyper_research"          # 超研究（DeerFlow研究+Hermes记忆）
    HYPER_CREATION = "hyper_creation"          # 超创造（Swarm协作+技能蒸馏）
    HYPER_EVOLUTION = "hyper_evolution"        # 超进化（记忆进化+专家克隆）
    HYPER_ANALYSIS = "hyper_analysis"          # 超分析（研究+代码+多智能体）

@dataclass
class WorkflowStep:
    """工作流步骤"""
    step_id: str
    name: str
    capability_module: str      # 能力模块名称
    inputs: Dict[str, Any]
    outputs: List[str]
    dependencies: List[str] = field(default_factory=list)
    timeout: float = 60.0
    retry_count: int = 3
    
@dataclass
class WorkflowInstance:
    """工作流实例"""
    workflow_id: str
    workflow_type: WorkflowType
    steps: List[WorkflowStep]
    context: Dict[str, Any] = field(default_factory=dict)
    results: Dict[str, Any] = field(default_factory=dict)
    status: str = "pending"     # pending, running, completed, failed
    start_time: datetime = None
    end_time: datetime = None
    
    def __post_init__(self):
        if self.start_time is None:
            self.start_time = datetime.now()

# ==================== 能力模块库 ====================

class CapabilityModules:
    """
    能力模块库 - 解构三种架构的核心能力
    """
    
    # ===== Hermes 能力模块 =====
    
    @staticmethod
    def memory_layer_management(context: Dict) -> Dict:
        """
        记忆分层管理 (Hermes核心)
        
        七层记忆体系：
        - instant: 即时记忆
        - working: 工作记忆
        - short: 短期记忆
        - long: 长期记忆
        - skill: 技能记忆
        - expert: 专家记忆
        - graph: 图记忆
        """
        memory = MFlowEngineV2()
        
        operation = context.get("operation", "retrieve")
        layer = context.get("layer", "working")
        content = context.get("content", "")
        
        if operation == "store":
            entry = memory.add_fact({
                "layer": layer,
                "content": content,
                "importance": context.get("importance", 5.0),
                "source": context.get("source", "workflow")
            })
            return {"success": True, "memory_id": entry.get("id"), "layer": layer}
        
        elif operation == "retrieve":
            query = context.get("query", content)
            results = memory.retrieve_similar(query, layer=layer, top_k=context.get("top_k", 5))
            return {"success": True, "memories": results, "count": len(results)}
        
        elif operation == "evolve":
            # 记忆进化：整合短期记忆到长期记忆
            short_term = memory.retrieve_by_layer("short")
            consolidated = memory.consolidate_memories(short_term)
            return {"success": True, "consolidated": consolidated}
        
        return {"success": False, "error": "Unknown operation"}
    
    @staticmethod
    def skill_auto_generation(context: Dict) -> Dict:
        """
        技能自动生成 (Hermes核心)
        
        自动从使用模式中提取技能
        """
        from skill_auto_generator import SkillAutoGenerator
        
        generator = SkillAutoGenerator()
        
        trigger_skill = context.get("trigger_skill")
        call_records = context.get("call_records", [])
        
        # 模拟达到阈值
        for record in call_records:
            generator.record_skill_call(
                skill_name=record.get("skill_name", "unknown"),
                query=record.get("query", ""),
                context=record.get("context", {}),
                success=record.get("success", True)
            )
        
        return {
            "success": True,
            "generation_tasks": len(generator.generation_tasks),
            "pending_triggers": list(generator.pending_triggers)
        }
    
    @staticmethod
    def expert_thought_distillation(context: Dict) -> Dict:
        """
        专家思维蒸馏 (Hermes核心)
        
        六路并行采集 + 三重验证提炼
        """
        expert_name = context.get("expert_name", "unknown")
        source_materials = context.get("sources", [])
        
        # 六路并行采集
        collection_results = {
            "biography": CapabilityModules._collect_biography(expert_name),
            "interviews": CapabilityModules._collect_interviews(expert_name),
            "writings": CapabilityModules._collect_writings(expert_name),
            "decisions": CapabilityModules._collect_decisions(expert_name),
            "patterns": CapabilityModules._collect_patterns(expert_name),
            "contradictions": CapabilityModules._collect_contradictions(expert_name)
        }
        
        # 三重验证提炼
        distilled = {
            "mental_models": CapabilityModules._extract_mental_models(collection_results),
            "decision_heuristics": CapabilityModules._extract_heuristics(collection_results),
            "expression_dna": CapabilityModules._extract_expression(collection_results)
        }
        
        return {
            "success": True,
            "expert_name": expert_name,
            "distilled_components": distilled,
            "collection_coverage": len([v for v in collection_results.values() if v])
        }
    
    # ===== DeerFlow 能力模块（集成 DeerFlowBridge） =====
    
    @staticmethod
    def deep_research_chain(context: Dict) -> Dict:
        """
        深度研究链 (DeerFlow核心) - 集成 DeerFlowBridge
        
        多轮迭代研究，自动验证和扩展
        """
        bridge = DeerFlowBridge()
        
        # 异步执行研究
        topic = context.get("query", context.get("topic", ""))
        depth = context.get("depth", "standard")
        store_in_memory = context.get("store_in_memory", True)
        
        # 使用 asyncio 运行异步方法
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        report = loop.run_until_complete(
            bridge.deep_research(topic, depth, store_in_memory)
        )
        
        return {
            "success": True,
            "report_id": report.report_id,
            "topic": report.topic,
            "depth": report.depth.value,
            "summary": report.summary,
            "key_findings": report.key_findings,
            "recommendations": report.recommendations,
            "iterations": len(report.steps),
            "created_at": report.created_at.isoformat()
        }
    
    @staticmethod
    def code_sandbox_execution(context: Dict) -> Dict:
        """
        代码沙箱执行 (DeerFlow核心) - 集成 DeerFlowBridge
        
        安全隔离的代码执行环境
        """
        bridge = DeerFlowBridge()
        
        code = context.get("code", "")
        language = context.get("language", "python")
        timeout = context.get("timeout", 30.0)
        
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        result = loop.run_until_complete(
            bridge.execute_code(code, language, timeout)
        )
        
        return {
            "success": result.success,
            "execution_id": result.execution_id,
            "language": result.language.value,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "return_code": result.return_code,
            "execution_time": result.execution_time,
            "artifacts": result.artifacts
        }
    
    @staticmethod
    def multi_agent_collaboration(context: Dict) -> Dict:
        """
        多智能体协作 (DeerFlow核心) - 集成 DeerFlowBridge
        
        研究/分析/编码智能体协同工作
        """
        bridge = DeerFlowBridge()
        
        task = context.get("task", "")
        agents = context.get("agents", ["researcher", "analyst"])
        max_rounds = context.get("max_rounds", 5)
        
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        messages = loop.run_until_complete(
            bridge.multi_agent_task(task, agents, max_rounds)
        )
        
        return {
            "success": True,
            "task": task,
            "agents": agents,
            "rounds": len(messages),
            "conversation": [
                {
                    "agent": msg.agent_name,
                    "role": msg.role,
                    "content": msg.content,
                    "timestamp": msg.timestamp.isoformat()
                }
                for msg in messages
            ]
        }
    
    @staticmethod
    def tool_orchestration(context: Dict) -> Dict:
        """
        工具编排 (DeerFlow核心) - 集成 DeerFlowBridge
        
        搜索/浏览/代码执行工具链
        """
        bridge = DeerFlowBridge()
        
        tool_name = context.get("tool_name", "")
        parameters = context.get("parameters", {})
        
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        result = loop.run_until_complete(
            bridge.call_tool(tool_name, **parameters)
        )
        
        return {
            "success": result.error == "",
            "tool_name": result.tool_name,
            "parameters": result.parameters,
            "result": result.result,
            "error": result.error,
            "execution_time": result.execution_time
        }
    
    @staticmethod
    def research_with_code(context: Dict) -> Dict:
        """
        研究+代码组合 (DeerFlow核心) - 集成 DeerFlowBridge
        
        并行执行研究和代码分析
        """
        bridge = DeerFlowBridge()
        
        topic = context.get("topic", "")
        analysis_code = context.get("analysis_code", "")
        depth = context.get("depth", "standard")
        
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        combined = loop.run_until_complete(
            bridge.research_with_code(topic, analysis_code, depth)
        )
        
        report = combined["research_report"]
        code_result = combined["code_result"]
        
        return {
            "success": True,
            "topic": topic,
            "research": {
                "report_id": report.report_id,
                "summary": report.summary,
                "key_findings": report.key_findings,
                "iterations": len(report.steps)
            },
            "code_analysis": {
                "execution_id": code_result.execution_id,
                "success": code_result.success,
                "stdout": code_result.stdout,
                "stderr": code_result.stderr,
                "execution_time": code_result.execution_time
            },
            "combined_insights": combined["combined_insights"]
        }
    
    # ===== Swarm 能力模块（集成 SwarmBridge） =====
    
    @staticmethod
    def lightweight_agent_swarm(context: Dict) -> Dict:
        """
        轻量级智能体群体 (Swarm核心) - 集成 SwarmBridge
        
        简单、快速、可扩展的多智能体协作
        """
        bridge = SwarmBridge()
        
        task = context.get("task", "")
        agents = context.get("agents", [])
        starting_agent = context.get("starting_agent")
        max_turns = context.get("max_turns", 10)
        
        try:
            loop = asyncio.get_event_loop()
        except RuntimeError:
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
        
        execution = loop.run_until_complete(
            bridge.run(
                task=task,
                agents=agents if agents else None,
                starting_agent=starting_agent,
                context=context.get("initial_context"),
                max_turns=max_turns
            )
        )
        
        return {
            "success": True,
            "execution_id": execution.execution_id,
            "task": execution.task,
            "completed": execution.completed,
            "agent_count": len(set([m.agent for m in execution.messages if m.agent])),
            "message_count": len(execution.messages),
            "handoff_count": len(execution.handoffs),
            "active_agent": execution.active_agent,
            "result": execution.result,
            "execution_time": (execution.end_time - execution.start_time).total_seconds() if execution.end_time else 0,
            "conversation": [
                {
                    "role": msg.role,
                    "content": msg.content[:100] + "..." if len(msg.content) > 100 else msg.content,
                    "agent": msg.agent,
                    "timestamp": msg.timestamp.isoformat()
                }
                for msg in execution.messages[-10:]  # 最近10条
            ],
            "handoffs": [
                {
                    "from": h.from_agent,
                    "to": h.to_agent,
                    "reason": h.reason,
                    "strategy": h.strategy.value
                }
                for h in execution.handoffs
            ]
        }
    
    @staticmethod
    def function_call_routing(context: Dict) -> Dict:
        """
        函数调用路由 (Swarm核心) - 集成 SwarmBridge
        
        基于函数定义的动态路由
        """
        bridge = SwarmBridge()
        
        # 创建临时智能体进行路由测试
        test_agent = bridge.create_agent(
            name="router_test",
            description="路由测试智能体",
            instructions="根据用户意图路由到合适的函数",
            functions=context.get("functions", []),
            handoffs=context.get("handoffs", [])
        )
        
        # 获取路由决策
        intent = context.get("intent", "")
        available_agents = bridge.registry.list_agents()
        
        # 模拟路由决策
        routed_agent = None
        for agent_info in available_agents:
            if any(kw in intent.lower() for kw in agent_info.get("description", "").lower().split()):
                routed_agent = agent_info["name"]
                break
        
        return {
            "success": routed_agent is not None,
            "routed_agent": routed_agent,
            "intent": intent,
            "available_agents": [a["name"] for a in available_agents],
            "routing_logic": "description_matching"
        }
    
    @staticmethod
    def context_handoff(context: Dict) -> Dict:
        """
        上下文交接 (Swarm核心) - 集成 SwarmBridge
        
        智能体间的状态传递
        """
        bridge = SwarmBridge()
        
        from_agent = context.get("from_agent")
        to_agent = context.get("to_agent")
        handoff_context = context.get("context", {})
        strategy = context.get("strategy", "direct")
        
        # 创建上下文
        ctx_id = bridge.context_manager.create_context(
            execution_id=f"handoff_{from_agent}_{to_agent}",
            initial_data=handoff_context
        )
        
        # 执行交接
        event = HandoffEvent(
            from_agent=from_agent,
            to_agent=to_agent,
            reason=context.get("reason", "任务交接"),
            context=handoff_context,
            strategy=HandoffStrategy(strategy)
        )
        
        return {
            "success": True,
            "handoff_event": {
                "from": event.from_agent,
                "to": event.to_agent,
                "reason": event.reason,
                "strategy": event.strategy.value,
                "timestamp": event.timestamp.isoformat()
            },
            "context_id": ctx_id,
            "transferred_keys": list(handoff_context.keys()),
            "context_size": len(str(handoff_context))
        }
    
    @staticmethod
    def swarm_agent_management(context: Dict) -> Dict:
        """
        Swarm 智能体管理 (Swarm核心) - 集成 SwarmBridge
        
        动态智能体注册、发现和配置
        """
        bridge = SwarmBridge()
        operation = context.get("operation", "list")
        
        if operation == "create":
            agent = bridge.create_agent(
                name=context.get("name"),
                description=context.get("description"),
                instructions=context.get("instructions"),
                functions=context.get("functions", []),
                handoffs=context.get("handoffs", [])
            )
            return {
                "success": True,
                "operation": "create",
                "agent": {
                    "name": agent.name,
                    "description": agent.description,
                    "functions": [f.name for f in agent.functions],
                    "handoffs": agent.handoffs
                }
            }
        
        elif operation == "register":
            agent_def = context.get("agent")
            if agent_def:
                agent = SwarmAgent(**agent_def)
                success = bridge.registry.register(agent)
                return {"success": success, "operation": "register", "agent_name": agent.name}
            return {"success": False, "error": "No agent definition provided"}
        
        elif operation == "list":
            agents = bridge.registry.list_agents()
            return {
                "success": True,
                "operation": "list",
                "agent_count": len(agents),
                "agents": agents
            }
        
        elif operation == "find":
            capability = context.get("capability")
            agents = bridge.registry.find_agents_by_capability(capability)
            return {
                "success": True,
                "operation": "find",
                "capability": capability,
                "matching_agents": [a.name for a in agents]
            }
        
        return {"success": False, "error": f"Unknown operation: {operation}"}
    
    # ===== 辅助方法 =====
    
    @staticmethod
    def _collect_biography(expert: str) -> Dict:
        return {"source": "biography", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_interviews(expert: str) -> Dict:
        return {"source": "interviews", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_writings(expert: str) -> Dict:
        return {"source": "writings", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_decisions(expert: str) -> Dict:
        return {"source": "decisions", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_patterns(expert: str) -> Dict:
        return {"source": "patterns", "expert": expert, "data": {}}
    
    @staticmethod
    def _collect_contradictions(expert: str) -> Dict:
        return {"source": "contradictions", "expert": expert, "data": {}}
    
    @staticmethod
    def _extract_mental_models(collection: Dict) -> List[Dict]:
        return [{"model": f"model_{i}", "description": ""} for i in range(3)]
    
    @staticmethod
    def _extract_heuristics(collection: Dict) -> List[str]:
        return ["heuristic_1", "heuristic_2", "heuristic_3"]
    
    @staticmethod
    def _extract_expression(collection: Dict) -> Dict:
        return {"style": "analytical", "patterns": []}
    
    @staticmethod
    def _run_lightweight_agent(agent: str, task: str) -> Dict:
        return {"agent": agent, "task": task, "output": f"Result from {agent}"}
    
    @staticmethod
    def _aggregate_swarm_results(results: List[Dict]) -> Dict:
        return {"consensus": "aggregated", "divergence": []}
    
    @staticmethod
    def _calculate_function_match(func: Dict, intent: str, params: Dict) -> float:
        return 0.8
    
    @staticmethod
    def _map_parameters(func: Dict, params: Dict) -> Dict:
        return params
    
    @staticmethod
    def _adapt_context_for_agent(context: Dict, from_agent: str, to_agent: str) -> Dict:
        return context


# ==================== 超能力工作流 ====================

class HyperWorkflows:
    """
    超能力工作流 - 组合三种架构的优势
    """
    
    @staticmethod
    def hyper_research_workflow(context: Dict) -> Dict:
        """
        超研究工作流
        
        DeerFlow深度研究 + Hermes记忆进化 + Swarm轻量验证
        """
        modules = CapabilityModules()
        
        # Phase 1: DeerFlow深度研究
        research_result = modules.deep_research_chain(context)
        
        # Phase 2: Hermes记忆存储
        memory_result = modules.memory_layer_management({
            "operation": "store",
            "layer": "long",
            "content": json.dumps(research_result["summary"]),
            "importance": 8.0,
            "source": "hyper_research"
        })
        
        # Phase 3: Swarm轻量验证
        verification_result = modules.lightweight_agent_swarm({
            "agents": ["fact_checker", "bias_detector", "synthesizer"],
            "task": f"Verify research findings: {len(research_result['key_findings'])} facts"
        })
        
        return {
            "workflow": "hyper_research",
            "phases": {
                "research": research_result,
                "memory": memory_result,
                "verification": verification_result
            },
            "output": {
                "report_summary": research_result["summary"],
                "key_findings": research_result["key_findings"],
                "memory_id": memory_result.get("memory_id"),
                "verification_score": verification_result["successful_agents"] / 3
            }
        }
    
    @staticmethod
    def hyper_creation_workflow(context: Dict) -> Dict:
        """
        超创造工作流
        
        Swarm协作生成 + Hermes技能蒸馏 + DeerFlow代码执行
        """
        modules = CapabilityModules()
        
        # Phase 1: Swarm协作生成创意
        swarm_result = modules.lightweight_agent_swarm({
            "agents": ["ideator", "critic", "refiner"],
            "task": context.get("creation_task", "Generate creative solution")
        })
        
        # Phase 2: Hermes技能自动提取
        skill_result = modules.skill_auto_generation({
            "trigger_skill": "creative_generation",
            "call_records": [{"skill_name": "ideator", "query": context.get("creation_task"), "success": True}]
        })
        
        # Phase 3: DeerFlow代码实现
        code_result = modules.code_sandbox_execution({
            "code": swarm_result["aggregated_result"].get("implementation", "print('Hello World')"),
            "language": context.get("language", "python")
        })
        
        return {
            "workflow": "hyper_creation",
            "phases": {
                "generation": swarm_result,
                "skill_extraction": skill_result,
                "implementation": code_result
            },
            "output": {
                "creative_solution": swarm_result["aggregated_result"],
                "skill_generated": skill_result["generation_tasks"] > 0,
                "code_executed": code_result["success"]
            }
        }
    
    @staticmethod
    def hyper_evolution_workflow(context: Dict) -> Dict:
        """
        超进化工作流
        
        Hermes专家克隆 + DeerFlow多智能体链 + Swarm函数路由
        """
        modules = CapabilityModules()
        
        # Phase 1: Hermes专家克隆
        expert_result = modules.expert_thought_distillation({
            "expert_name": context.get("expert_name", "unknown"),
            "sources": context.get("sources", [])
        })
        
        # Phase 2: DeerFlow多智能体协作
        chain_result = modules.multi_agent_collaboration({
            "task": f"Apply expert model: {context.get('expert_name')}",
            "agents": ["researcher", "analyst"],
            "max_rounds": 3
        })
        
        # Phase 3: Swarm函数路由优化
        routing_result = modules.function_call_routing({
            "functions": context.get("available_functions", []),
            "intent": context.get("optimization_goal", "improve"),
            "parameters": {"expert_model": expert_result["distilled_components"]}
        })
        
        return {
            "workflow": "hyper_evolution",
            "phases": {
                "expert_cloning": expert_result,
                "execution": chain_result,
                "optimization": routing_result
            },
            "output": {
                "expert_model": expert_result["distilled_components"],
                "execution_rounds": chain_result["rounds"],
                "optimization_route": routing_result.get("routed_function")
            }
        }
    
    @staticmethod
    def hyper_analysis_workflow(context: Dict) -> Dict:
        """
        超分析工作流 (v3.6 新增)
        
        DeerFlow研究+代码+多智能体 + Hermes记忆 + Swarm验证
        """
        modules = CapabilityModules()
        
        topic = context.get("topic", "")
        analysis_code = context.get("analysis_code", "")
        
        # Phase 1: DeerFlow 研究+代码组合
        research_code_result = modules.research_with_code({
            "topic": topic,
            "analysis_code": analysis_code,
            "depth": context.get("depth", "standard")
        })
        
        # Phase 2: DeerFlow 多智能体深度分析
        multi_agent_result = modules.multi_agent_collaboration({
            "task": f"深度分析: {topic}",
            "agents": ["researcher", "analyst", "coder"],
            "max_rounds": 5
        })
        
        # Phase 3: Hermes 记忆存储
        memory_result = modules.memory_layer_management({
            "operation": "store",
            "layer": "long",
            "content": json.dumps({
                "topic": topic,
                "research_summary": research_code_result["research"]["summary"],
                "code_success": research_code_result["code_analysis"]["success"],
                "agent_insights": len(multi_agent_result["conversation"])
            }),
            "importance": 9.0,
            "source": "hyper_analysis"
        })
        
        # Phase 4: Swarm 验证
        verification_result = modules.lightweight_agent_swarm({
            "agents": ["validator", "critic", "synthesizer"],
            "task": f"验证分析结果: {topic}"
        })
        
        return {
            "workflow": "hyper_analysis",
            "phases": {
                "research_code": research_code_result,
                "multi_agent": multi_agent_result,
                "memory": memory_result,
                "verification": verification_result
            },
            "output": {
                "topic": topic,
                "research_iterations": research_code_result["research"]["iterations"],
                "code_success": research_code_result["code_analysis"]["success"],
                "agent_rounds": multi_agent_result["rounds"],
                "memory_id": memory_result.get("memory_id"),
                "verification_score": verification_result["successful_agents"] / 3
            }
        }


# ==================== 工作流编排器 ====================

class WorkflowOrchestrator:
    """
    工作流编排器 - 统一入口 (v3.7)
    
    整合三大架构核心能力：
    - Hermes: 自进化记忆 + 技能蒸馏
    - DeerFlow: 深度研究链 + 代码沙箱 + 多智能体协作
    - Swarm: 轻量级智能体 + 函数路由 + 上下文交接
    """
    
    WORKFLOW_REGISTRY = {
        # Hermes工作流
        WorkflowType.MEMORY_EVOLUTION: CapabilityModules.memory_layer_management,
        WorkflowType.SKILL_DISTILLATION: CapabilityModules.skill_auto_generation,
        WorkflowType.EXPERT_CLONING: CapabilityModules.expert_thought_distillation,
        
        # DeerFlow工作流（集成 DeerFlowBridge）
        WorkflowType.DEEP_RESEARCH: CapabilityModules.deep_research_chain,
        WorkflowType.CODE_EXECUTION: CapabilityModules.code_sandbox_execution,
        WorkflowType.MULTI_AGENT_CHAIN: CapabilityModules.multi_agent_collaboration,
        WorkflowType.TOOL_ORCHESTRATION: CapabilityModules.tool_orchestration,
        WorkflowType.RESEARCH_WITH_CODE: CapabilityModules.research_with_code,
        
        # Swarm工作流（集成 SwarmBridge）
        WorkflowType.LIGHTWEIGHT_SWARM: CapabilityModules.lightweight_agent_swarm,
        WorkflowType.FUNCTION_ROUTING: CapabilityModules.function_call_routing,
        WorkflowType.CONTEXT_HANDOFF: CapabilityModules.context_handoff,
        
        # 超能力工作流
        WorkflowType.HYPER_RESEARCH: HyperWorkflows.hyper_research_workflow,
        WorkflowType.HYPER_CREATION: HyperWorkflows.hyper_creation_workflow,
        WorkflowType.HYPER_EVOLUTION: HyperWorkflows.hyper_evolution_workflow,
        WorkflowType.HYPER_ANALYSIS: HyperWorkflows.hyper_analysis_workflow,
    }
    
    def __init__(self):
        self.memory = MFlowEngineV2()
        self.deerflow_bridge = DeerFlowBridge()
        self.swarm_bridge = SwarmBridge()
        self.execution_history: List[Dict] = []
        
    def execute(self, workflow_type: Union[str, WorkflowType], context: Dict) -> Dict:
        """
        执行工作流
        """
        if isinstance(workflow_type, str):
            workflow_type = WorkflowType(workflow_type)
        
        workflow_id = hashlib.md5(
            f"{workflow_type.value}_{datetime.now()}".encode()
        ).hexdigest()[:12]
        
        # 记录开始
        start_time = datetime.now()
        
        # 获取工作流函数
        workflow_func = self.WORKFLOW_REGISTRY.get(workflow_type)
        if not workflow_func:
            return {"success": False, "error": f"Unknown workflow: {workflow_type}"}
        
        # 执行
        try:
            result = workflow_func(context)
            result["workflow_id"] = workflow_id
            result["workflow_type"] = workflow_type.value
            result["execution_time"] = (datetime.now() - start_time).total_seconds()
            result["success"] = result.get("success", True)
        except Exception as e:
            result = {
                "success": False,
                "workflow_id": workflow_id,
                "workflow_type": workflow_type.value,
                "error": str(e),
                "execution_time": (datetime.now() - start_time).total_seconds()
            }
        
        # 记录历史
        self.execution_history.append({
            "workflow_id": workflow_id,
            "type": workflow_type.value,
            "timestamp": start_time.isoformat(),
            "success": result["success"]
        })
        
        # 存储到记忆
        from mflow_v2 import MemoryEntry
        self.memory.store(MemoryEntry(
            id=f"wf_{workflow_id}",
            layer="skill",
            content=json.dumps({
                "workflow": workflow_type.value,
                "context": str(context)[:200],
                "result_summary": "success" if result["success"] else "failed"
            }),
            source="workflow_orchestrator",
            importance=7.0
        ))
        
        return result
    
    def get_capabilities(self) -> Dict:
        """获取所有能力模块"""
        return {
            "hermes_modules": [
                "memory_layer_management",
                "skill_auto_generation", 
                "expert_thought_distillation"
            ],
            "deerflow_modules": [
                "deep_research_chain",
                "code_sandbox_execution",
                "multi_agent_collaboration",
                "tool_orchestration",
                "research_with_code"
            ],
            "swarm_modules": [
                "lightweight_agent_swarm",
                "function_call_routing",
                "context_handoff",
                "swarm_agent_management"
            ],
            "hyper_workflows": [
                "hyper_research",
                "hyper_creation",
                "hyper_evolution",
                "hyper_analysis"
            ]
        }
    
    def get_deerflow_capabilities(self) -> Dict:
        """获取 DeerFlow 桥接器能力"""
        return self.deerflow_bridge.get_capabilities()
    
    def get_swarm_capabilities(self) -> Dict:
        """获取 Swarm 桥接器能力"""
        return self.swarm_bridge.get_capabilities()
    
    def recommend_workflow(self, task_description: str) -> List[Dict]:
        """
        根据任务描述推荐工作流
        """
        recommendations = []
        
        # 关键词匹配
        keywords = {
            WorkflowType.HYPER_RESEARCH: ["研究", "分析", "调查", "报告"],
            WorkflowType.HYPER_CREATION: ["创建", "生成", "设计", "实现"],
            WorkflowType.HYPER_EVOLUTION: ["优化", "进化", "改进", "学习"],
            WorkflowType.HYPER_ANALYSIS: ["深度分析", "综合分析", "全面评估"],
            WorkflowType.DEEP_RESEARCH: ["深度", "详细", "全面", "调研"],
            WorkflowType.CODE_EXECUTION: ["代码", "执行", "运行", "编程"],
            WorkflowType.MULTI_AGENT_CHAIN: ["多智能体", "协作", "讨论"],
            WorkflowType.SKILL_DISTILLATION: ["技能", "自动化", "提取"],
            WorkflowType.RESEARCH_WITH_CODE: ["研究代码", "数据分析", "量化"],
        }
        
        for wf_type, kws in keywords.items():
            score = sum(1 for kw in kws if kw in task_description.lower())
            if score > 0:
                recommendations.append({
                    "workflow": wf_type.value,
                    "confidence": min(score / len(kws) + 0.3, 1.0),
                    "reason": f"匹配关键词: {[kw for kw in kws if kw in task_description.lower()]}"
                })
        
        return sorted(recommendations, key=lambda x: x["confidence"], reverse=True)[:3]
    
    async def async_deep_research(self, topic: str, depth: str = "standard") -> ResearchReport:
        """
        异步深度研究接口
        
        直接使用 DeerFlowBridge 进行深度研究
        """
        return await self.deerflow_bridge.deep_research(topic, depth)
    
    async def async_execute_code(self, code: str, language: str = "python") -> Dict:
        """
        异步代码执行接口
        """
        return await self.deerflow_bridge.execute_code(code, language)
    
    async def async_multi_agent_task(self, task: str, agents: List[str] = None) -> List:
        """
        异步多智能体协作接口 (DeerFlow)
        """
        return await self.deerflow_bridge.multi_agent_task(task, agents)
    
    # ===== Swarm 异步接口 =====
    
    async def async_swarm_run(self, task: str, starting_agent: str = "researcher", max_turns: int = 10) -> SwarmExecution:
        """
        异步 Swarm 执行接口
        
        直接使用 SwarmBridge 运行多智能体任务
        """
        return await self.swarm_bridge.run(task, starting_agent=starting_agent, max_turns=max_turns)
    
    async def async_swarm_create_agent(self, name: str, description: str, instructions: str, **kwargs) -> SwarmAgent:
        """
        异步创建 Swarm 智能体
        """
        return self.swarm_bridge.create_agent(name, description, instructions, **kwargs)
    
    async def async_swarm_agent_management(self, operation: str, **kwargs) -> Dict:
        """
        异步 Swarm 智能体管理
        """
        return CapabilityModules.swarm_agent_management({"operation": operation, **kwargs})


# 便捷函数
def create_orchestrator() -> WorkflowOrchestrator:
    """创建工作流编排器实例"""
    return WorkflowOrchestrator()

def execute_hyper_workflow(workflow_type: str, context: Dict) -> Dict:
    """便捷函数：执行超能力工作流"""
    orchestrator = WorkflowOrchestrator()
    return orchestrator.execute(workflow_type, context)

# 新增便捷函数
def deep_research(topic: str, depth: str = "standard") -> Dict:
    """便捷函数：深度研究"""
    orchestrator = WorkflowOrchestrator()
    return orchestrator.execute(WorkflowType.DEEP_RESEARCH, {
        "query": topic,
        "depth": depth
    })

def execute_code(code: str, language: str = "python") -> Dict:
    """便捷函数：执行代码"""
    orchestrator = WorkflowOrchestrator()
    return orchestrator.execute(WorkflowType.CODE_EXECUTION, {
        "code": code,
        "language": language
    })

def multi_agent_collaborate(task: str, agents: List[str] = None) -> Dict:
    """便捷函数：多智能体协作"""
    orchestrator = WorkflowOrchestrator()
    return orchestrator.execute(WorkflowType.MULTI_AGENT_CHAIN, {
        "task": task,
        "agents": agents or ["researcher", "analyst"]
    })


def test_deerflow_integration():
    """测试 DeerFlow 集成"""
    print("=" * 60)
    print("DeerFlow 集成测试")
    print("=" * 60)
    
    orchestrator = WorkflowOrchestrator()
    
    # 1. 测试深度研究
    print("\n[1/5] 测试深度研究工作流...")
    result = orchestrator.execute(WorkflowType.DEEP_RESEARCH, {
        "topic": "AI智能体架构发展趋势",
        "depth": "quick"
    })
    print(f"✅ 研究报告: {result.get('report_id', 'N/A')}")
    print(f"   主题: {result.get('topic', 'N/A')}")
    print(f"   轮数: {result.get('iterations', 0)}")
    
    # 2. 测试代码执行
    print("\n[2/5] 测试代码执行工作流...")
    code_result = orchestrator.execute(WorkflowType.CODE_EXECUTION, {
        "code": "print('Hello from DeerFlow Bridge!')",
        "language": "python"
    })
    print(f"✅ 代码执行: {'成功' if code_result.get('success') else '失败'}")
    print(f"   输出: {code_result.get('stdout', '').strip()}")
    
    # 3. 测试多智能体协作
    print("\n[3/5] 测试多智能体协作...")
    agent_result = orchestrator.execute(WorkflowType.MULTI_AGENT_CHAIN, {
        "task": "分析AI发展趋势",
        "agents": ["researcher", "analyst"],
        "max_rounds": 2
    })
    print(f"✅ 协作完成: {agent_result.get('rounds', 0)} 轮对话")
    
    # 4. 测试超分析工作流
    print("\n[4/5] 测试超分析工作流...")
    hyper_result = orchestrator.execute(WorkflowType.HYPER_ANALYSIS, {
        "topic": "智能体架构性能优化",
        "analysis_code": "data = {'performance': 95, 'efficiency': 88}\nprint(data)",
        "depth": "quick"
    })
    print(f"✅ 超分析完成")
    print(f"   研究迭代: {hyper_result.get('output', {}).get('research_iterations', 0)}")
    print(f"   代码成功: {hyper_result.get('output', {}).get('code_success', False)}")
    print(f"   智能体轮数: {hyper_result.get('output', {}).get('agent_rounds', 0)}")
    
    # 5. 显示能力列表
    print("\n[5/5] DeerFlow 能力列表")
    print("-" * 60)
    capabilities = orchestrator.get_deerflow_capabilities()
    for cap_name, cap_info in capabilities.items():
        print(f"\n📌 {cap_name}")
        print(f"   描述: {cap_info['description']}")
        if 'tools' in cap_info:
            print(f"   工具: {', '.join(cap_info['tools'])}")
        if 'agent_roles' in cap_info:
            print(f"   角色: {', '.join(cap_info['agent_roles'])}")
    
    print("\n" + "=" * 60)
    print("✅ DeerFlow 集成测试通过!")
    print("=" * 60)


def test_swarm_integration():
    """测试 Swarm 集成"""
    print("=" * 60)
    print("Swarm 集成测试")
    print("=" * 60)
    
    orchestrator = WorkflowOrchestrator()
    
    # 1. 测试智能体管理
    print("\n[1/4] 测试智能体管理...")
    agent_result = orchestrator.execute(WorkflowType.LIGHTWEIGHT_SWARM, {
        "task": "测试智能体系统",
        "max_turns": 3
    })
    print(f"✅ Swarm 执行: {agent_result.get('execution_id', 'N/A')}")
    print(f"   消息数: {agent_result.get('message_count', 0)}")
    print(f"   交接次数: {agent_result.get('handoff_count', 0)}")
    print(f"   是否完成: {agent_result.get('completed', False)}")
    
    # 2. 测试函数路由
    print("\n[2/4] 测试函数路由...")
    routing_result = orchestrator.execute(WorkflowType.FUNCTION_ROUTING, {
        "intent": "研究AI发展趋势",
        "functions": [
            {"name": "search", "description": "搜索信息"},
            {"name": "analyze", "description": "分析数据"},
            {"name": "code", "description": "编写代码"}
        ]
    })
    print(f"✅ 路由结果: {'成功' if routing_result.get('success') else '失败'}")
    print(f"   路由到: {routing_result.get('routed_agent', 'N/A')}")
    
    # 3. 测试上下文交接
    print("\n[3/4] 测试上下文交接...")
    handoff_result = orchestrator.execute(WorkflowType.CONTEXT_HANDOFF, {
        "from_agent": "researcher",
        "to_agent": "coder",
        "reason": "需要代码实现",
        "context": {
            "topic": "AI智能体架构",
            "research_findings": ["发现1", "发现2"],
            "requirements": ["要求1", "要求2"]
        },
        "strategy": "direct"
    })
    print(f"✅ 上下文交接: {handoff_result.get('handoff_event', {}).get('from', 'N/A')} -> {handoff_result.get('handoff_event', {}).get('to', 'N/A')}")
    print(f"   交接原因: {handoff_result.get('handoff_event', {}).get('reason', 'N/A')}")
    print(f"   传递键数: {len(handoff_result.get('transferred_keys', []))}")
    
    # 4. 显示 Swarm 能力
    print("\n[4/4] Swarm 能力列表")
    print("-" * 60)
    capabilities = orchestrator.get_swarm_capabilities()
    for cap_name, cap_info in capabilities.items():
        print(f"\n📌 {cap_name}")
        print(f"   描述: {cap_info['description']}")
        print(f"   特性: {', '.join(cap_info['features'])}")
    
    print("\n" + "=" * 60)
    print("✅ Swarm 集成测试通过!")
    print("=" * 60)


if __name__ == "__main__":
    print("=== 超能力工作流编排器 v3.7 ===\n")
    
    orchestrator = WorkflowOrchestrator()
    
    # 显示能力模块
    print("【能力模块矩阵】")
    caps = orchestrator.get_capabilities()
    for category, modules in caps.items():
        print(f"\n{category}:")
        for m in modules:
            print(f"  - {m}")
    
    # 运行 DeerFlow 集成测试
    print("\n")
    test_deerflow_integration()
    
    # 运行 Swarm 集成测试
    print("\n")
    test_swarm_integration()
    
    # 测试工作流推荐
    print("\n\n【测试】工作流推荐")
    recommendations = orchestrator.recommend_workflow("我需要深入研究一个复杂的技术问题并生成报告")
    for rec in recommendations:
        print(f"  - {rec['workflow']} (置信度: {rec['confidence']:.2f})")
