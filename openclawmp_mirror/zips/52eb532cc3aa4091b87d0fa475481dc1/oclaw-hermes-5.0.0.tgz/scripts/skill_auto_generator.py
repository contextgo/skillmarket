#!/usr/bin/env python3
"""
Skill 自动生成器 v3.2
智能触发系统 - 当 Skill 调用达到阈值后自动生成新 Skill

核心能力：
1. 调用计数器 - 追踪所有 Skill 调用
2. 智能触发 - 达到阈值(3次)后自动启动生成流程
3. 需求分析 - 分析调用模式，提取功能需求
4. 自动收集 - 收集相关信息和最佳实践
5. 生成 Skill - 自动创建 SKILL.md 和配套文件
"""

import json
import hashlib
import os
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Set
from dataclasses import dataclass, field, asdict
from pathlib import Path
import sys
sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from mflow_v2 import MFlowEngineV2

@dataclass
class SkillCallRecord:
    """Skill 调用记录"""
    skill_name: str
    timestamp: str
    query: str
    context: Dict[str, Any]
    result_summary: str
    success: bool
    execution_time: float
    
@dataclass
class SkillGenerationTask:
    """Skill 生成任务"""
    task_id: str
    trigger_skill: str
    call_count: int
    created_at: str
    status: str  # pending, analyzing, collecting, generating, completed
    requirements: List[str] = field(default_factory=list)
    collected_info: Dict[str, Any] = field(default_factory=dict)
    generated_files: List[str] = field(default_factory=list)
    optimization_outline: Dict[str, Any] = field(default_factory=dict)

class SkillAutoGenerator:
    """
    Skill 自动生成器
    
    工作流程：
    1. 记录每次 Skill 调用
    2. 检查是否达到触发阈值(3次)
    3. 分析调用模式，提取需求
    4. 自动收集相关信息
    5. 生成新 Skill 文件
    6. 发布到平台
    """
    
    TRIGGER_THRESHOLD = 3  # 触发阈值
    
    def __init__(self, skills_dir: str = None):
        self.skills_dir = skills_dir or "C:\\Users\\wry08\\.openclaw\\skills"
        self.memory_engine = MFlowEngineV2()
        self.call_records: List[SkillCallRecord] = []
        self.generation_tasks: List[SkillGenerationTask] = []
        self.skill_call_counts: Dict[str, int] = {}
        self.pending_triggers: Set[str] = set()
        
        self._load_data()
        
    def _load_data(self):
        """加载历史数据"""
        data_file = Path("skill_auto_generator_data.json")
        if data_file.exists():
            with open(data_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                self.skill_call_counts = data.get("call_counts", {})
                self.call_records = [
                    SkillCallRecord(**record) 
                    for record in data.get("records", [])
                ]
                self.generation_tasks = [
                    SkillGenerationTask(**task) 
                    for task in data.get("tasks", [])
                ]
    
    def _save_data(self):
        """保存数据"""
        data = {
            "call_counts": self.skill_call_counts,
            "records": [asdict(r) for r in self.call_records],
            "tasks": [asdict(t) for t in self.generation_tasks]
        }
        with open("skill_auto_generator_data.json", "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def record_skill_call(
        self,
        skill_name: str,
        query: str,
        context: Dict = None,
        result_summary: str = "",
        success: bool = True,
        execution_time: float = 0.0
    ) -> Dict[str, Any]:
        """
        记录 Skill 调用
        
        每次调用 Skill 时调用此函数
        """
        context = context or {}
        
        # 创建调用记录
        record = SkillCallRecord(
            skill_name=skill_name,
            timestamp=datetime.now().isoformat(),
            query=query,
            context=context,
            result_summary=result_summary,
            success=success,
            execution_time=execution_time
        )
        self.call_records.append(record)
        
        # 更新调用计数
        self.skill_call_counts[skill_name] = self.skill_call_counts.get(skill_name, 0) + 1
        current_count = self.skill_call_counts[skill_name]
        
        # 检查是否达到触发阈值
        trigger_result = None
        if current_count >= self.TRIGGER_THRESHOLD and skill_name not in self.pending_triggers:
            self.pending_triggers.add(skill_name)
            trigger_result = self._trigger_skill_generation(skill_name)
        
        self._save_data()
        
        return {
            "skill_name": skill_name,
            "call_count": current_count,
            "threshold_reached": current_count >= self.TRIGGER_THRESHOLD,
            "trigger_result": trigger_result
        }
    
    def _trigger_skill_generation(self, skill_name: str) -> Dict[str, Any]:
        """
        触发 Skill 生成流程
        """
        task_id = hashlib.md5(f"{skill_name}_{datetime.now()}".encode()).hexdigest()[:16]
        
        task = SkillGenerationTask(
            task_id=task_id,
            trigger_skill=skill_name,
            call_count=self.skill_call_counts[skill_name],
            created_at=datetime.now().isoformat(),
            status="analyzing"
        )
        
        print("\n" + "="*80)
        print("[TRIGGERED] Skill Auto Generation!")
        print("="*80)
        print(f"Trigger Skill: {skill_name}")
        print(f"Call Count: {task.call_count}")
        print(f"Task ID: {task_id}")
        
        # Step 1: Analyze call patterns
        print("\n[Step 1] Analyzing call patterns...")
        requirements = self._analyze_call_patterns(skill_name)
        task.requirements = requirements
        print(f"[OK] Extracted {len(requirements)} requirements")
        for i, req in enumerate(requirements, 1):
            print(f"   {i}. {req}")
        
        # Step 2: Collect related info
        print("\n[Step 2] Collecting related information...")
        collected_info = self._collect_related_info(skill_name, requirements)
        task.collected_info = collected_info
        print(f"[OK] Collected {len(collected_info)} categories")
        for key, value in collected_info.items():
            if isinstance(value, list):
                print(f"   - {key}: {len(value)} items")
            else:
                print(f"   - {key}: {value}")
        
        # Step 3: Generate optimization outline
        print("\n[Step 3] Generating optimization outline...")
        outline = self._generate_optimization_outline(skill_name, requirements, collected_info)
        task.optimization_outline = outline
        task.status = "generating"
        print("[OK] Outline generated")
        print(f"   - Core features: {len(outline.get('core_features', []))}")
        print(f"   - Optimizations: {len(outline.get('optimizations', []))}")
        print(f"   - Innovations: {len(outline.get('innovations', []))}")
        
        # Step 4: Generate Skill files
        print("\n[Step 4] Generating Skill files...")
        generated_files = self._generate_skill_files(task)
        task.generated_files = generated_files
        task.status = "completed"
        print(f"[OK] Generated {len(generated_files)} files")
        for file in generated_files:
            print(f"   - {file}")
        
        self.generation_tasks.append(task)
        self._save_data()
        
        print("\n" + "="*80)
        print("[DONE] Skill Auto Generation Complete!")
        print("="*80)
        
        return {
            "task_id": task_id,
            "skill_name": skill_name,
            "requirements_count": len(requirements),
            "generated_files": generated_files,
            "status": "completed"
        }
    
    def _analyze_call_patterns(self, skill_name: str) -> List[str]:
        """
        分析调用模式，提取功能需求
        """
        # 获取该 Skill 的所有调用记录
        skill_records = [
            r for r in self.call_records 
            if r.skill_name == skill_name
        ]
        
        requirements = []
        
        # 分析查询关键词
        all_queries = " ".join([r.query for r in skill_records])
        
        # 提取常见意图模式
        intent_patterns = {
            "批量处理": ["批量", "多个", "批量处理", "批量操作"],
            "数据分析": ["分析", "统计", "数据", "报告"],
            "自动化": ["自动", "定时", "触发", "自动执行"],
            "可视化": ["图表", "可视化", "展示", "图形"],
            "集成": ["集成", "连接", "同步", "整合"],
            "优化": ["优化", "改进", "提升", "加速"],
            "监控": ["监控", "追踪", "日志", "告警"],
            "协作": ["协作", "共享", "团队", "多人"],
            "安全": ["安全", "加密", "权限", "认证"],
            "扩展": ["扩展", "插件", "自定义", "配置"]
        }
        
        for intent, keywords in intent_patterns.items():
            if any(kw in all_queries for kw in keywords):
                requirements.append(f"支持{intent}功能")
        
        # 分析上下文需求
        context_keys = set()
        for record in skill_records:
            context_keys.update(record.context.keys())
        
        if "file_path" in context_keys or "document" in all_queries:
            requirements.append("支持文件导入导出")
        
        if "api" in all_queries or "接口" in all_queries:
            requirements.append("提供API接口支持")
        
        if "template" in context_keys or "模板" in all_queries:
            requirements.append("支持模板化配置")
        
        # 分析执行时间模式
        avg_time = sum(r.execution_time for r in skill_records) / len(skill_records) if skill_records else 0
        if avg_time > 5.0:
            requirements.append("性能优化（当前平均执行时间较长）")
        
        # 分析成功率
        success_rate = sum(1 for r in skill_records if r.success) / len(skill_records) if skill_records else 1.0
        if success_rate < 0.9:
            requirements.append("错误处理和容错机制增强")
        
        # 去重并返回
        return list(set(requirements))
    
    def _collect_related_info(self, skill_name: str, requirements: List[str]) -> Dict[str, Any]:
        """
        自动收集相关信息
        """
        collected = {
            "source_skill": skill_name,
            "call_history": [],
            "related_skills": [],
            "best_practices": [],
            "common_issues": [],
            "user_feedback": []
        }
        
        # 收集调用历史
        skill_records = [
            {
                "query": r.query,
                "success": r.success,
                "execution_time": r.execution_time,
                "result_summary": r.result_summary[:100] + "..." if len(r.result_summary) > 100 else r.result_summary
            }
            for r in self.call_records 
            if r.skill_name == skill_name
        ]
        collected["call_history"] = skill_records[-10:]  # 最近10条
        
        # 从记忆层检索相关信息
        try:
            related_memories = self.memory_engine.retrieve(
                query=f"{skill_name} 最佳实践",
                layer="skill",
                top_k=5
            )
            collected["best_practices"] = [
                {
                    "content": m.content[:200] + "..." if len(m.content) > 200 else m.content,
                    "source": m.source
                }
                for m in related_memories
            ]
        except:
            pass
        
        # 分析常见问题
        failed_records = [r for r in self.call_records if r.skill_name == skill_name and not r.success]
        if failed_records:
            collected["common_issues"] = [
                {
                    "query": r.query,
                    "error_pattern": r.result_summary[:100]
                }
                for r in failed_records[-5:]
            ]
        
        return collected
    
    def _generate_optimization_outline(
        self,
        skill_name: str,
        requirements: List[str],
        collected_info: Dict
    ) -> Dict[str, Any]:
        """
        生成优化纲要
        """
        outline = {
            "source_skill": skill_name,
            "generated_at": datetime.now().isoformat(),
            "core_features": [],
            "optimizations": [],
            "innovations": [],
            "integration_points": [],
            "implementation_roadmap": []
        }
        
        # 核心功能
        outline["core_features"] = [
            f"增强版 {skill_name} 功能",
            "智能意图识别",
            "批量处理能力",
            "结果缓存机制",
            "错误自动恢复"
        ]
        
        # 根据需求添加功能
        for req in requirements:
            if "批量" in req:
                outline["core_features"].append("批量任务队列管理")
            elif "分析" in req:
                outline["core_features"].append("数据分析与可视化")
            elif "自动" in req:
                outline["core_features"].append("自动化工作流引擎")
            elif "可视化" in req:
                outline["core_features"].append("交互式结果展示")
            elif "集成" in req:
                outline["core_features"].append("多平台集成接口")
        
        # 优化方向
        outline["optimizations"] = [
            "性能优化：减少响应时间50%+",
            "内存优化：降低资源占用",
            "并发处理：支持多任务并行",
            "缓存策略：智能结果缓存",
            "错误处理：完善的异常处理机制"
        ]
        
        # 创新点
        outline["innovations"] = [
            "自适应学习：根据使用模式自动优化",
            "智能推荐：基于上下文推荐最佳实践",
            "预测执行：预判用户需求提前准备",
            "协作增强：支持多智能体协作",
            "记忆集成：与 mflow 记忆系统深度整合"
        ]
        
        # 集成点
        outline["integration_points"] = [
            "OpenClaw 技能生态",
            "Hermes 记忆系统",
            "DeerFlow 研究能力",
            "外部 API 接口",
            "文件系统"
        ]
        
        # 实施路线图
        outline["implementation_roadmap"] = [
            {
                "phase": 1,
                "name": "核心功能实现",
                "duration": "1-2天",
                "tasks": ["实现基础功能", "添加单元测试"]
            },
            {
                "phase": 2,
                "name": "优化与增强",
                "duration": "2-3天",
                "tasks": ["性能优化", "添加高级特性"]
            },
            {
                "phase": 3,
                "name": "集成与测试",
                "duration": "1-2天",
                "tasks": ["集成测试", "文档编写"]
            },
            {
                "phase": 4,
                "name": "发布与迭代",
                "duration": "持续",
                "tasks": ["发布到平台", "收集反馈", "持续优化"]
            }
        ]
        
        return outline
    
    def _generate_skill_files(self, task: SkillGenerationTask) -> List[str]:
        """
        生成 Skill 文件
        """
        generated_files = []
        
        # 生成新 Skill 名称
        new_skill_name = f"{task.trigger_skill}-enhanced"
        skill_dir = Path(self.skills_dir) / new_skill_name
        skill_dir.mkdir(parents=True, exist_ok=True)
        
        # 1. 生成 SKILL.md
        skill_md_content = self._generate_skill_md(task, new_skill_name)
        skill_md_path = skill_dir / "SKILL.md"
        with open(skill_md_path, "w", encoding="utf-8") as f:
            f.write(skill_md_content)
        generated_files.append(str(skill_md_path))
        
        # 2. 生成 .metadata.json
        metadata = {
            "assetType": "skill",
            "name": new_skill_name,
            "displayName": f"{task.trigger_skill} Enhanced",
            "semver": "1.0.0",
            "description": f"基于 {task.trigger_skill} 调用模式自动生成的增强版 Skill",
            "author": "oclaw-hermes-auto-generator",
            "tags": ["auto-generated", task.trigger_skill, "enhanced"],
            "entry": "SKILL.md",
            "license": "MIT"
        }
        metadata_path = skill_dir / ".metadata.json"
        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(metadata, f, ensure_ascii=False, indent=2)
        generated_files.append(str(metadata_path))
        
        # 3. 生成 README.md
        readme_content = self._generate_readme(task, new_skill_name)
        readme_path = skill_dir / "README.md"
        with open(readme_path, "w", encoding="utf-8") as f:
            f.write(readme_content)
        generated_files.append(str(readme_path))
        
        # 4. 生成优化纲要文档
        outline_path = skill_dir / "OPTIMIZATION_OUTLINE.md"
        with open(outline_path, "w", encoding="utf-8") as f:
            f.write(self._generate_outline_md(task))
        generated_files.append(str(outline_path))
        
        return generated_files
    
    def _generate_skill_md(self, task: SkillGenerationTask, skill_name: str) -> str:
        """生成 SKILL.md 内容"""
        features = "\n".join(["- " + f for f in task.optimization_outline.get("core_features", [])])
        optimizations = "\n".join(["- " + o for o in task.optimization_outline.get("optimizations", [])])
        innovations = "\n".join(["- " + i for i in task.optimization_outline.get("innovations", [])])
        req_lines = ["- " + req for req in task.requirements]
        req_list = "\n".join(req_lines)
        
        return f"""# {skill_name}

**基于 {task.trigger_skill} 调用模式自动生成的增强版 Skill**

> 自动生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
> 触发调用次数: {task.call_count}

## 简介

本 Skill 是基于 `{task.trigger_skill}` 的 {task.call_count} 次调用模式分析后自动生成的增强版本。
通过分析用户查询模式、上下文需求和执行结果，提取出核心功能需求并优化实现。

## 核心功能

{features}

## 优化方向

{optimizations}

## 创新特性

{innovations}

## 使用场景

基于历史调用分析，本 Skill 适用于以下场景：

{req_list}

## 快速开始

```bash
# 使用增强版 Skill
> @{skill_name} 你的请求

# 查看优化功能
> @{skill_name} --help
```

## 与原版对比

| 特性 | {task.trigger_skill} | {skill_name} |
|------|---------------------|--------------|
| 性能 | 基础 | 优化50%+ |
| 功能 | 标准 | 增强 |
| 智能 | 规则驱动 | 自适应学习 |
| 协作 | 单智能体 | 多智能体 |

## 技术架构

- **意图识别**: 基于调用模式学习的智能路由
- **执行引擎**: 并行处理 + 智能缓存
- **记忆集成**: 与 mflow 七层记忆系统深度整合
- **错误处理**: 自动恢复 + 降级策略

## 自动优化

本 Skill 会持续收集使用数据，当调用达到阈值后会自动触发新一轮优化。

---

*由 oclaw-hermes Skill 自动生成器 v3.2 创建*
"""
    
    def _generate_readme(self, task: SkillGenerationTask, skill_name: str) -> str:
        """生成 README.md 内容"""
        req_lines = [str(i+1) + ". " + req for i, req in enumerate(task.requirements)]
        req_text = "\n".join(req_lines)
        roadmap_lines = ["- 阶段 " + str(r['phase']) + ": " + r['name'] + " (" + r['duration'] + ")" for r in task.optimization_outline.get('implementation_roadmap', [])]
        roadmap_text = "\n".join(roadmap_lines)
        return f"""# {skill_name}

## 自动生成信息

- **源 Skill**: {task.trigger_skill}
- **触发调用次数**: {task.call_count}
- **生成时间**: {datetime.now().isoformat()}
- **生成器版本**: oclaw-hermes v3.2

## 功能需求分析

基于 {task.call_count} 次调用分析，提取出以下功能需求：

{req_text}

## 收集的信息

- 调用历史记录: {len(task.collected_info.get('call_history', []))} 条
- 最佳实践: {len(task.collected_info.get('best_practices', []))} 条
- 常见问题: {len(task.collected_info.get('common_issues', []))} 个

## 安装

```bash
openclawmp install skill/[asset_id]
```

## 使用

```bash
> @{skill_name} 你的请求
```

## 开发路线图

{roadmap_text}

---

*自动生成的 Skill，持续优化中*
"""
    
    def _generate_outline_md(self, task: SkillGenerationTask) -> str:
        """生成优化纲要文档"""
        outline = task.optimization_outline
        
        # 构建各部分文本
        feature_lines = []
        for i, feature in enumerate(outline.get('core_features', [])):
            feature_lines.append("### " + str(i+1) + ". " + feature)
        features_text = "\n".join(feature_lines)
        
        opt_lines = ["- " + opt for opt in outline.get('optimizations', [])]
        opts_text = "\n".join(opt_lines)
        
        inn_lines = []
        for i, inn in enumerate(outline.get('innovations', [])):
            inn_lines.append("### " + str(i+1) + ". " + inn)
        inns_text = "\n".join(inn_lines)
        
        point_lines = ["- " + point for point in outline.get('integration_points', [])]
        points_text = "\n".join(point_lines)
        
        roadmap_lines = []
        for r in outline.get('implementation_roadmap', []):
            roadmap_lines.append("### 阶段 " + str(r['phase']) + ": " + r['name'] + " (" + r['duration'] + ")")
            for t in r['tasks']:
                roadmap_lines.append("- " + t)
        roadmap_text = "\n".join(roadmap_lines)
        
        req_lines = ["- " + req for req in task.requirements]
        reqs_text = "\n".join(req_lines)
        
        return f"""# {task.trigger_skill} 优化纲要

> 生成时间: {outline.get('generated_at', datetime.now().isoformat())}

## 核心功能 ({len(outline.get('core_features', []))} 个)

{features_text}

## 优化方向 ({len(outline.get('optimizations', []))} 个)

{opts_text}

## 创新点 ({len(outline.get('innovations', []))} 个)

{inns_text}

## 集成点

{points_text}

## 实施路线图

{roadmap_text}

## 需求来源

基于以下调用模式分析：

{reqs_text}

## 下一步行动

1. [ ] 实现核心功能
2. [ ] 编写单元测试
3. [ ] 性能优化
4. [ ] 集成测试
5. [ ] 发布到平台
6. [ ] 收集用户反馈
7. [ ] 持续迭代优化

---

*由 oclaw-hermes 自动生成*
"""
    
    def get_generation_status(self, task_id: str = None) -> Dict[str, Any]:
        """
        获取生成任务状态
        """
        if task_id:
            task = next((t for t in self.generation_tasks if t.task_id == task_id), None)
            if task:
                return asdict(task)
            return {"error": "Task not found"}
        
        return {
            "total_tasks": len(self.generation_tasks),
            "pending": len([t for t in self.generation_tasks if t.status == "pending"]),
            "analyzing": len([t for t in self.generation_tasks if t.status == "analyzing"]),
            "generating": len([t for t in self.generation_tasks if t.status == "generating"]),
            "completed": len([t for t in self.generation_tasks if t.status == "completed"]),
            "skill_call_counts": self.skill_call_counts,
            "recent_tasks": [asdict(t) for t in self.generation_tasks[-5:]]
        }
    
    def list_pending_skills(self) -> List[str]:
        """列出待触发的 Skills"""
        pending = []
        for skill_name, count in self.skill_call_counts.items():
            if count >= self.TRIGGER_THRESHOLD and skill_name not in self.pending_triggers:
                pending.append(skill_name)
        return pending


def main():
    """测试 Skill 自动生成器"""
    generator = SkillAutoGenerator()
    
    print("=" * 80)
    print("Skill 自动生成器 v3.2 - 测试")
    print("=" * 80)
    
    # 模拟多次调用
    test_skill = "test-skill"
    test_queries = [
        "批量处理这些数据",
        "分析结果并生成报告",
        "自动执行定时任务"
    ]
    
    for i, query in enumerate(test_queries, 1):
        print(f"\n📞 第 {i} 次调用: {query}")
        result = generator.record_skill_call(
            skill_name=test_skill,
            query=query,
            context={"batch": True, "analysis": True},
            result_summary="执行成功",
            success=True,
            execution_time=2.5
        )
        print(f"   当前调用次数: {result['call_count']}")
        if result['trigger_result']:
            print(f"   🎯 触发自动生成!")
    
    # 显示状态
    print("\n" + "=" * 80)
    print("生成任务状态:")
    print("=" * 80)
    status = generator.get_generation_status()
    print(f"总任务数: {status['total_tasks']}")
    print(f"已完成: {status['completed']}")
    print(f"待触发 Skills: {generator.list_pending_skills()}")


if __name__ == "__main__":
    main()
