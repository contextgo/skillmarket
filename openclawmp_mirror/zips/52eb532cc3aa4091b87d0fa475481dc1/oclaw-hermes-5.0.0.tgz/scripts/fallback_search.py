#!/usr/bin/env python3
"""
Fallback 搜索模块 - 无需 API Key

当 Perplexity API 不可用时，使用以下免费替代方案：
1. DuckDuckGo 搜索 (无需 API Key)
2. Bing 搜索 (免费额度)
3. SerpAPI (免费额度)
4. 本地缓存优先
"""

import os
import json
import asyncio
import aiohttp
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class SearchResult:
    """搜索结果"""
    title: str
    url: str
    snippet: str
    source: str  # 'duckduckgo', 'bing', 'cache', 'perplexity'
    timestamp: datetime


class FallbackSearchBridge:
    """
    降级搜索桥接器
    
    优先级:
    1. 本地缓存 (如果存在且未过期)
    2. Perplexity (如果配置了 API Key)
    3. DuckDuckGo (免费，无需 Key)
    4. 模拟搜索 (基于知识库)
    """
    
    def __init__(self, perplexity_key: Optional[str] = None):
        self.perplexity_key = perplexity_key or os.getenv("PERPLEXITY_API_KEY")
        self.cache_dir = os.path.expanduser("~/.oclaw-hermes/search_cache")
        os.makedirs(self.cache_dir, exist_ok=True)
        self.cache_ttl = timedelta(hours=24)  # 缓存24小时
        
    def _get_cache_key(self, query: str) -> str:
        """生成缓存键"""
        import hashlib
        return hashlib.md5(query.lower().encode()).hexdigest()
    
    def _get_cache_path(self, query: str) -> str:
        """获取缓存文件路径"""
        key = self._get_cache_key(query)
        return os.path.join(self.cache_dir, f"{key}.json")
    
    def _get_from_cache(self, query: str) -> Optional[List[SearchResult]]:
        """从缓存获取结果"""
        cache_path = self._get_cache_path(query)
        if not os.path.exists(cache_path):
            return None
        
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            # 检查缓存是否过期
            cached_time = datetime.fromisoformat(data['timestamp'])
            if datetime.now() - cached_time > self.cache_ttl:
                return None
            
            return [
                SearchResult(
                    title=r['title'],
                    url=r['url'],
                    snippet=r['snippet'],
                    source=r['source'],
                    timestamp=cached_time
                )
                for r in data['results']
            ]
        except:
            return None
    
    def _save_to_cache(self, query: str, results: List[SearchResult]):
        """保存结果到缓存"""
        cache_path = self._get_cache_path(query)
        data = {
            'query': query,
            'timestamp': datetime.now().isoformat(),
            'results': [
                {
                    'title': r.title,
                    'url': r.url,
                    'snippet': r.snippet,
                    'source': r.source
                }
                for r in results
            ]
        }
        try:
            with open(cache_path, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except:
            pass
    
    async def search_duckduckgo(self, query: str, max_results: int = 5) -> List[SearchResult]:
        """
        使用 DuckDuckGo 搜索 (无需 API Key)
        
        注意: DuckDuckGo 有速率限制，建议配合缓存使用
        """
        try:
            # 使用 duckduckgo-search 库
            from duckduckgo_search import DDGS
            
            results = []
            with DDGS() as ddgs:
                for r in ddgs.text(query, max_results=max_results):
                    results.append(SearchResult(
                        title=r.get('title', ''),
                        url=r.get('href', ''),
                        snippet=r.get('body', ''),
                        source='duckduckgo',
                        timestamp=datetime.now()
                    ))
            
            return results
        except ImportError:
            # 如果库未安装，返回空结果
            print("[INFO] duckduckgo-search not installed. Run: pip install duckduckgo-search")
            return []
        except Exception as e:
            print(f"[WARN] DuckDuckGo search failed: {e}")
            return []
    
    async def search_bing(self, query: str, max_results: int = 5) -> List[SearchResult]:
        """
        使用 Bing 搜索 (需要 API Key，但有免费额度)
        """
        bing_key = os.getenv("BING_SEARCH_API_KEY")
        if not bing_key:
            return []
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {"Ocp-Apim-Subscription-Key": bing_key}
                params = {"q": query, "count": max_results}
                
                async with session.get(
                    "https://api.bing.microsoft.com/v7.0/search",
                    headers=headers,
                    params=params
                ) as response:
                    if response.status != 200:
                        return []
                    
                    data = await response.json()
                    results = []
                    
                    for item in data.get("webPages", {}).get("value", []):
                        results.append(SearchResult(
                            title=item.get('name', ''),
                            url=item.get('url', ''),
                            snippet=item.get('snippet', ''),
                            source='bing',
                            timestamp=datetime.now()
                        ))
                    
                    return results
        except Exception as e:
            print(f"[WARN] Bing search failed: {e}")
            return []
    
    async def search_knowledge_base(self, query: str) -> List[SearchResult]:
        """
        基于本地知识库的模拟搜索
        
        当所有外部搜索都失败时使用
        """
        # 这里可以集成 Hermes 记忆系统
        # 从本地知识库检索相关信息
        
        # 示例：返回一些通用的知识库结果
        knowledge_results = [
            SearchResult(
                title="OpenClaw 官方文档",
                url="https://openclawmp.stepfun.com/docs",
                snippet="OpenClaw 是一个智能体平台，支持 Skills 开发和部署。",
                source='knowledge_base',
                timestamp=datetime.now()
            ),
            SearchResult(
                title="oclaw-hermes GitHub",
                url="https://github.com/ruiyongwang/oclaw-hermes",
                snippet="oclaw-hermes 是八位一体智能体架构，支持多平台集成。",
                source='knowledge_base',
                timestamp=datetime.now()
            )
        ]
        
        # 简单匹配（实际应用可以使用更智能的匹配算法）
        matched = [r for r in knowledge_results if query.lower() in r.title.lower() or query.lower() in r.snippet.lower()]
        return matched if matched else knowledge_results[:2]
    
    async def search(
        self,
        query: str,
        max_results: int = 5,
        use_cache: bool = True
    ) -> Dict[str, Any]:
        """
        智能搜索 - 自动选择最佳搜索源
        
        Args:
            query: 搜索查询
            max_results: 最大结果数
            use_cache: 是否使用缓存
            
        Returns:
            Dict: 包含搜索结果和元信息
        """
        start_time = asyncio.get_event_loop().time()
        
        # 1. 检查缓存
        if use_cache:
            cached = self._get_from_cache(query)
            if cached:
                return {
                    "success": True,
                    "results": [
                        {"title": r.title, "url": r.url, "snippet": r.snippet}
                        for r in cached
                    ],
                    "source": "cache",
                    "count": len(cached),
                    "latency": 0.01,
                    "cached": True
                }
        
        results = []
        source = "unknown"
        
        # 2. 尝试 Perplexity (如果配置了 Key)
        if self.perplexity_key:
            try:
                # 这里调用 PerplexityBridge
                from perplexity_bridge import PerplexityBridge
                bridge = PerplexityBridge(self.perplexity_key)
                response = await bridge.search(query)
                
                results = [SearchResult(
                    title="Perplexity Result",
                    url="",
                    snippet=response.content,
                    source='perplexity',
                    timestamp=datetime.now()
                )]
                source = "perplexity"
            except Exception as e:
                print(f"[WARN] Perplexity failed: {e}")
        
        # 3. 尝试 DuckDuckGo (免费)
        if not results:
            results = await self.search_duckduckgo(query, max_results)
            if results:
                source = "duckduckgo"
        
        # 4. 尝试 Bing
        if not results:
            results = await self.search_bing(query, max_results)
            if results:
                source = "bing"
        
        # 5. 回退到知识库
        if not results:
            results = await self.search_knowledge_base(query)
            source = "knowledge_base"
        
        # 保存到缓存
        if results and use_cache:
            self._save_to_cache(query, results)
        
        latency = asyncio.get_event_loop().time() - start_time
        
        return {
            "success": len(results) > 0,
            "results": [
                {"title": r.title, "url": r.url, "snippet": r.snippet}
                for r in results
            ],
            "source": source,
            "count": len(results),
            "latency": round(latency, 3),
            "cached": False
        }


# 同步包装函数
def search(query: str, max_results: int = 5) -> Dict[str, Any]:
    """同步搜索接口"""
    bridge = FallbackSearchBridge()
    return asyncio.run(bridge.search(query, max_results))


if __name__ == "__main__":
    # 测试
    result = search("OpenClaw 智能体平台")
    print(json.dumps(result, indent=2, ensure_ascii=False))
