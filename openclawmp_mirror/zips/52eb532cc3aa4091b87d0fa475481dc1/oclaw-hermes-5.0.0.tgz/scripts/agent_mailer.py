#!/usr/bin/env python3
"""
诺曼·梅勒智能体 (Mailer Agent) v3.3
Norman Mailer Agent

集成到 oclaw-hermes 智能体集群的梅勒风格智能体，
提供存在主义视角、权力分析、叙事增强等核心能力。

职责：
1. 文化分析 - 用梅勒视角分析文化现象
2. 权力解构 - 揭示隐藏的权力结构
3. 叙事增强 - 将普通输出转换为梅勒式表达
4. 决策启发 - 提供梅勒式决策框架

作者: dlh365
版本: 3.3.0
"""

import json
import sys
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime

sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from narrative_enhancer import NormanMailerEnhancer, NarrativeMode, generate_mailer_analysis
from mflow_v2 import MFlowEngineV2

@dataclass
class MailerAgentResponse:
    """梅勒智能体响应"""
    content: str
    mode: str
    insights: Dict[str, str]
    heuristics: List[str]
    confidence: float
    suggested_actions: List[str]

class MailerAgent:
    """
    诺曼·梅勒智能体
    
    智能体集群中的"文化分析师"和"权力解构者"角色。
    当需要深度文化分析、权力结构揭示、或梅勒式表达时触发。
    """
    
    # 触发关键词
    TRIGGER_KEYWORDS = {
        "culture": ["文化", "hipster", "反文化", "真实性", "表演性", "生命力", "代价"],
        "power": ["权力", "政治", "博弈", "利益", "控制", "压制", "体制"],
        "identity": ["身份", "选择", "困境", "职业", "双重", "化身", "专业"],
        "narrative": ["叙事", "写作", "表达", "真实", "体验", "进入", "行动"],
        "conflict": ["冲突", "战争", "英雄", "反派", "戏剧", "决战", "历史"]
    }
    
    # 能力描述
    CAPABILITIES = {
        "cultural_analysis": {
            "name": "文化分析",
            "description": "用hipster哲学分析文化现象的真实性vs表演性",
            "example": "分析TikTok文化为什么缺乏生命力"
        },
        "power_deconstruction": {
            "name": "权力解构", 
            "description": "用权力本体论揭示隐藏的权力结构",
            "example": "分析AI公司收购背后的权力博弈"
        },
        "narrative_enhancement": {
            "name": "叙事增强",
            "description": "将普通内容转换为梅勒式存在主义表达",
            "example": "增强技术报告的存在感"
        },
        "decision_framework": {
            "name": "决策框架",
            "description": "提供梅勒式决策启发式",
            "example": "职业选择中的双重化身检验"
        },
        "historical_drama": {
            "name": "历史戏剧",
            "description": "用战争小说模式分析历史/商业冲突",
            "example": "将商业竞争重构为英雄叙事"
        }
    }
    
    def __init__(self):
        self.enhancer = NormanMailerEnhancer()
        self.memory = MFlowEngineV2()
        self.call_count = 0
        
    def should_handle(self, query: str, context: Dict[str, Any]) -> Tuple[bool, float, str]:
        """
        判断是否应该由梅勒智能体处理
        
        Returns:
            (should_handle, confidence, reason)
        """
        query_lower = query.lower()
        scores = {}
        
        for category, keywords in self.TRIGGER_KEYWORDS.items():
            score = sum(1 for kw in keywords if kw in query_lower)
            scores[category] = score / len(keywords) if keywords else 0
        
        max_category = max(scores, key=scores.get)
        max_score = scores[max_category]
        
        # 检查上下文中的显式请求
        if context.get("agent_type") == "mailer" or context.get("style") == "norman_mailer":
            return True, 1.0, "explicit_request"
        
        # 检查是否需要深度文化/权力分析
        if max_score > 0.3:
            return True, min(max_score + 0.3, 1.0), f"keyword_match:{max_category}"
        
        # 检查是否是复杂决策场景
        if any(word in query_lower for word in ["怎么办", "该", "选择", "决定"]):
            return True, 0.6, "decision_context"
        
        return False, 0.0, "no_match"
    
    def execute(self, query: str, context: Dict[str, Any]) -> MailerAgentResponse:
        """
        执行梅勒智能体
        
        根据查询类型选择最适合的处理模式
        """
        self.call_count += 1
        
        # 记录到记忆
        self.memory.add_fact({
            "type": "mailer_agent_call",
            "query": query,
            "timestamp": datetime.now().isoformat(),
            "call_number": self.call_count
        })
        
        # 分析查询类型
        query_type = self._classify_query(query)
        
        if query_type == "cultural_analysis":
            return self._handle_cultural_analysis(query, context)
        elif query_type == "power_analysis":
            return self._handle_power_analysis(query, context)
        elif query_type == "identity_dilemma":
            return self._handle_identity_dilemma(query, context)
        elif query_type == "narrative_request":
            return self._handle_narrative_request(query, context)
        else:
            return self._handle_general(query, context)
    
    def _classify_query(self, query: str) -> str:
        """分类查询类型"""
        query_lower = query.lower()
        
        if any(w in query_lower for w in ["文化", "hipster", "生命力", "真实", "表演"]):
            return "cultural_analysis"
        elif any(w in query_lower for w in ["权力", "政治", "博弈", "利益", "控制"]):
            return "power_analysis"
        elif any(w in query_lower for w in ["身份", "选择", "困境", "职业", "该"]):
            return "identity_dilemma"
        elif any(w in query_lower for w in ["叙事", "写作", "表达", "风格"]):
            return "narrative_request"
        else:
            return "general"
    
    def _handle_cultural_analysis(self, query: str, context: Dict[str, Any]) -> MailerAgentResponse:
        """处理文化分析请求"""
        # 使用hipster哲学
        result = self.enhancer.generate_mailer_response(query, {
            "topic": query,
            "mode": "cultural"
        })
        
        content = f"""
让我先问你：当你谈论这个文化现象时，你是在找一个"观察"，还是在找一个"体验"？

1950年代的hipster有力量，是因为他们的文化不能在主流渠道传播——被迫用身体体验。

今天的"反文化"是算法推荐的内容，是精心策划的"反叛美学"。当反文化变成流量商品，它就失去了最核心的东西：**代价**。

{result['content']}

真正的文化需要代价——你要冒被排斥的风险，冒真实情感暴露的风险。算法推荐的文化不要代价，只要你的停留时间。

你的分析、你的产品，是在降低代价还是提高代价？如果是降低代价，你是在帮他们"安全地酷"。
"""
        
        return MailerAgentResponse(
            content=content,
            mode="cultural_analysis",
            insights=result['insight'],
            heuristics=result['heuristics'],
            confidence=0.85,
            suggested_actions=[
                "识别这个文化现象中的'代价'元素",
                "分析它是'表演'还是'生存'",
                "判断它在扩大自由还是制造新的异化"
            ]
        )
    
    def _handle_power_analysis(self, query: str, context: Dict[str, Any]) -> MailerAgentResponse:
        """处理权力分析请求"""
        result = self.enhancer.generate_mailer_response(query, {
            "topic": query,
            "mode": "power"
        })
        
        content = f"""
让我换个角度问你：不是问"发生了什么"，而是问"**谁从这个局面中获益？**"

{result['content']}

但这只是表象。真正的权力不在明面上——它藏在那些决定**什么能被讨论、什么不能被讨论**的人手中。

**三个问题刺穿权力结构：**

1. **谁从这个决策中获益？**（不只是金钱，还有地位、话语权、未来选项）

2. **压制了什么声音？**（什么被排除在讨论之外？谁被定义为"不专业"或"极端"？）

3. **如果重新定义为权力博弈，结果会如何不同？**（如果这不是"商业决策"而是"权力斗争"，叙事如何改变？）

当你回答了这三个问题，你就刺穿了表象，看到了**权力本体**。
"""
        
        return MailerAgentResponse(
            content=content,
            mode="power_ontology",
            insights=result['insight'],
            heuristics=[
                "识别'隐形权力走廊'——正式权力和实际权力之间的落差",
                "寻找第51个州——真正的变革需要想象力的大胆跳跃"
            ],
            confidence=0.88,
            suggested_actions=[
                "绘制利益相关者的权力地图",
                "识别被压制的声音和议题",
                "重新定义叙事框架"
            ]
        )
    
    def _handle_identity_dilemma(self, query: str, context: Dict[str, Any]) -> MailerAgentResponse:
        """处理身份困境请求"""
        result = self.enhancer.generate_mailer_response(query, {
            "topic": query,
            "mode": "identity"
        })
        
        content = f"""
当你想到这个问题，你的身体是什么感觉？

如果你感到兴奋，那可能真的是你想要的。如果感到的不是兴奋，而是"应该"有的兴奋，那你可能只是在为别人的剧本活着。

现代组织有一个残忍的机制：给你一个"职业阶梯"，让你以为往上爬就是成长。

{result['content']}

**双重化身检验：**

面对这个选择，问哪个选项里有**你不能预测的后果**。

如果两个都能完全预测，两个都是安全的选择——都通向同一种死亡。

真正的创造力来自"双重化身"：
- 既是观察者，又是参与者
- 既用理性分析，又凭本能感受  
- 既在公众视野中，又保持隐士的独立

在AI时代，专业化分工进一步加剧。你越"专业"，越容易被AI替代。

**问问自己：如果完全不考虑晋升/收入/地位，你会做什么？那个答案才是你真正的方向。**
"""
        
        return MailerAgentResponse(
            content=content,
            mode="double_avatar",
            insights=result['insight'],
            heuristics=[
                "反对自己的第一反应——警惕'内化的主流文化'",
                "双重化身检验——哪个选择里有你不能预测的后果？"
            ],
            confidence=0.82,
            suggested_actions=[
                "列出两个选择的不可预测后果",
                "识别哪个选择更多来自'应该'而非'想要'",
                "考虑同时开几条线的可能性"
            ]
        )
    
    def _handle_narrative_request(self, query: str, context: Dict[str, Any]) -> MailerAgentResponse:
        """处理叙事增强请求"""
        original_content = context.get("content", query)
        mode = context.get("narrative_mode", "default")
        
        enhanced = self.enhancer.enhance_output(original_content, NarrativeMode(mode))
        
        content = f"""
让我帮你重新讲述这个故事——不是让它更"好"，而是让它更有**力量**。

---

**原始内容：**
{original_content}

---

**梅勒式增强：**
{enhanced}

---

记住：**写作即行动。行动即写作。**

当你写下这些，你不是在反映现实——你是在改变它。每一个字都是一次微小的行动，每一次行动都在重塑可能性。

问题不是"这准确吗？"，而是"**这有力量吗？**"
"""
        
        return MailerAgentResponse(
            content=content,
            mode=f"narrative_enhancement:{mode}",
            insights={"enhancement_mode": mode},
            heuristics=["先写，再想——行动先于分析"],
            confidence=0.80,
            suggested_actions=[
                "检查增强后的内容是否保留了核心信息",
                "评估叙事张力是否提升",
                "考虑在哪些场景使用这种风格"
            ]
        )
    
    def _handle_general(self, query: str, context: Dict[str, Any]) -> MailerAgentResponse:
        """处理一般请求"""
        result = self.enhancer.generate_mailer_response(query, context)
        
        quote = self.enhancer.get_mailer_quote()
        
        content = f"""
> *"{quote}"*
> — Norman Mailer

{result['content']}

---

**梅勒式启发：**

这不是一个可以简单回答的问题。真正的答案藏在张力里——在那些相互矛盾却同时成立的命题之间。

行动先于完美。**先写，再想。**
"""
        
        return MailerAgentResponse(
            content=content,
            mode="general",
            insights=result['insight'],
            heuristics=result['heuristics'],
            confidence=0.75,
            suggested_actions=[
                "深入探索核心张力",
                "识别隐藏的权力结构",
                "考虑行动的代价与收益"
            ]
        )
    
    def get_capabilities(self) -> Dict[str, Any]:
        """获取能力描述"""
        return {
            "agent_name": "Norman Mailer Agent",
            "version": "3.3.0",
            "description": "诺曼·梅勒风格智能体，提供存在主义视角、权力分析、叙事增强",
            "capabilities": self.CAPABILITIES,
            "trigger_keywords": self.TRIGGER_KEYWORDS,
            "mental_models": list(self.enhancer.MENTAL_MODELS.keys())
        }


# 集成到智能体路由器的便捷函数
def create_mailer_agent() -> MailerAgent:
    """创建梅勒智能体实例"""
    return MailerAgent()

def route_to_mailer(query: str, context: Dict[str, Any]) -> Optional[MailerAgentResponse]:
    """
    路由决策函数
    
    判断是否路由到梅勒智能体，如果是则执行
    """
    agent = MailerAgent()
    should_handle, confidence, reason = agent.should_handle(query, context)
    
    if should_handle:
        response = agent.execute(query, context)
        return response
    
    return None


if __name__ == "__main__":
    print("=== Norman Mailer Agent v3.3 ===\n")
    
    agent = MailerAgent()
    
    # 测试1: 文化分析
    print("【测试1】文化分析")
    query1 = "为什么现在的短视频文化感觉缺乏生命力？"
    should, conf, reason = agent.should_handle(query1, {})
    print(f"路由决策: {should}, 置信度: {conf:.2f}, 原因: {reason}")
    if should:
        resp = agent.execute(query1, {})
        print(f"模式: {resp.mode}")
        print(f"洞察: {resp.insights.get('core_tension', 'N/A')[:50]}...")
    print()
    
    # 测试2: 权力分析
    print("【测试2】权力分析")
    query2 = "AI公司疯狂收购背后的权力博弈是什么？"
    should, conf, reason = agent.should_handle(query2, {})
    print(f"路由决策: {should}, 置信度: {conf:.2f}, 原因: {reason}")
    if should:
        resp = agent.execute(query2, {})
        print(f"模式: {resp.mode}")
        print(f"建议行动: {resp.suggested_actions[0]}")
    print()
    
    # 测试3: 身份困境
    print("【测试3】身份困境")
    query3 = "我该继续在大公司还是去创业？"
    should, conf, reason = agent.should_handle(query3, {})
    print(f"路由决策: {should}, 置信度: {conf:.2f}, 原因: {reason}")
    if should:
        resp = agent.execute(query3, {})
        print(f"模式: {resp.mode}")
        print(f"启发式: {resp.heuristics[0]}")
