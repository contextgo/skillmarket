#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
oclaw-hermes 桥接服务 - 核心控制器 v3.2

实现 OpenClaw × Hermes × DeerFlow × Swarm × Perplexity × Grok 六平台无缝协作

核心能力：
1. **OpenClaw** - Skill 生态与发布平台
2. **Hermes** - 自进化记忆系统与专家蒸馏
3. **DeerFlow** - 深度研究链、代码沙箱、多智能体协作
4. **Swarm** - 轻量级多智能体、函数路由、上下文交接
5. **Perplexity** - 实时搜索、深度研究、引用溯源
6. **Grok** - xAI大模型、实时对话、图像理解、代码生成

Author: ruiyongwang
Version: 3.2.0
"""

import os
import sys
import json
import subprocess
import asyncio
from typing import Dict, List, Any, Optional, Callable, Union
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum

# 添加脚本路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# 尝试导入扩展模块
try:
    from mflow_v2 import MFlowEngineV2, MemoryEntry
    HERMES_AVAILABLE = True
except ImportError:
    HERMES_AVAILABLE = False

try:
    from deerflow_bridge import (
        DeerFlowBridge, DeepResearchChain, CodeSandbox,
        MultiAgentCollaboration, ToolOrchestrator,
        ResearchDepth, CodeLanguage, ResearchReport
    )
    DEERFLOW_AVAILABLE = True
except ImportError:
    DEERFLOW_AVAILABLE = False

try:
    from swarm_bridge import (
        SwarmBridge, SwarmAgent, AgentFunction, SwarmExecution,
        SwarmMessage, HandoffEvent, HandoffStrategy
    )
    SWARM_AVAILABLE = True
except ImportError:
    SWARM_AVAILABLE = False

try:
    from perplexity_bridge import (
        PerplexityBridge, PerplexityBridgeSync,
        PerplexityModel, SearchMode,
        PerplexityResponse, ResearchSession
    )
    PERPLEXITY_AVAILABLE = True
except ImportError:
    PERPLEXITY_AVAILABLE = False

try:
    from grok_bridge import (
        GrokBridge, GrokBridgeSync,
        GrokModel, GrokMessage, GrokResponse,
        Conversation, ResponseFormat
    )
    GROK_AVAILABLE = True
except ImportError:
    GROK_AVAILABLE = False

try:
    from deerflow_hermes_executor import (
        DeerFlowHermesExecutor, ExecutionMode,
        AgentRole, ExecutionResult
    )
    EXECUTOR_AVAILABLE = True
except ImportError:
    EXECUTOR_AVAILABLE = False


class PlatformType(Enum):
    """平台类型"""
    OPENCLAW = "openclaw"
    HERMES = "hermes"
    DEERFLOW = "deerflow"
    SWARM = "swarm"
    PERPLEXITY = "perplexity"
    GROK = "grok"


@dataclass
class PlatformStatus:
    """平台状态"""
    name: str
    type: PlatformType
    connected: bool
    available: bool  # 模块是否可用
    version: str = ""
    error: str = ""
    details: Dict[str, Any] = field(default_factory=dict)
    capabilities: List[str] = field(default_factory=list)


@dataclass
class PlatformCapabilities:
    """平台能力汇总"""
    openclaw: Dict[str, Any] = field(default_factory=dict)
    hermes: Dict[str, Any] = field(default_factory=dict)
    deerflow: Dict[str, Any] = field(default_factory=dict)
    swarm: Dict[str, Any] = field(default_factory=dict)
    perplexity: Dict[str, Any] = field(default_factory=dict)
    grok: Dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            "openclaw": self.openclaw,
            "hermes": self.hermes,
            "deerflow": self.deerflow,
            "swarm": self.swarm,
            "perplexity": self.perplexity
        }


class OclawHermesBridge:
    """
    六平台桥接控制器
    
    整合 OpenClaw × Hermes × DeerFlow × Swarm × Perplexity × Grok 的核心能力
    """
    
    def __init__(self):
        # 环境配置
        self.openclaw_token = os.getenv("OPENCLAW_TOKEN")
        self.hermes_endpoint = os.getenv("HERMES_ENDPOINT", "http://localhost:8080")
        self.deerflow_url = os.getenv("DEERFLOW_URL", "http://localhost:2026")
        self.swarm_endpoint = os.getenv("SWARM_ENDPOINT", "http://localhost:2027")
        self.perplexity_api_key = os.getenv("PERPLEXITY_API_KEY")
        self.grok_api_key = os.getenv("XAI_API_KEY")
        
        # 初始化各平台客户端
        self._hermes_engine = None
        self._deerflow_bridge = None
        self._swarm_bridge = None
        self._perplexity_bridge = None
        self._grok_bridge = None
        
    # ==================== OpenClaw 平台 ====================
    
    def check_openclaw(self) -> PlatformStatus:
        """检查 OpenClaw 连接状态"""
        try:
            result = subprocess.run(
                ["openclawmp", "list"],
                capture_output=True, text=True, timeout=10
            )
            if result.returncode == 0:
                skills = len(result.stdout.strip().split('\n')) if result.stdout else 0
                return PlatformStatus(
                    name="OpenClaw",
                    type=PlatformType.OPENCLAW,
                    connected=True,
                    available=True,
                    version="v1.0.2",
                    details={"skills_installed": skills},
                    capabilities=["skill_install", "skill_publish", "skill_list"]
                )
            return PlatformStatus(
                name="OpenClaw", 
                type=PlatformType.OPENCLAW,
                connected=False, 
                available=True,
                error="CLI 错误"
            )
        except FileNotFoundError:
            return PlatformStatus(
                name="OpenClaw", 
                type=PlatformType.OPENCLAW,
                connected=False, 
                available=True,
                error="CLI 未安装"
            )
        except Exception as e:
            return PlatformStatus(
                name="OpenClaw", 
                type=PlatformType.OPENCLAW,
                connected=False, 
                available=True,
                error=str(e)
            )
    
    def openclaw_publish_skill(self, skill_path: str, slug: str = None, tags: List[str] = None) -> Dict:
        """发布 Skill 到 OpenClaw"""
        try:
            cmd = ["openclawmp", "publish", skill_path, "--yes"]
            if slug:
                cmd.extend(["--slug", slug])
            if tags:
                cmd.extend(["--tags", ",".join(tags)])
            
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ==================== Hermes 平台 ====================
    
    def check_hermes(self) -> PlatformStatus:
        """检查 Hermes 连接状态"""
        if not HERMES_AVAILABLE:
            return PlatformStatus(
                name="Hermes",
                type=PlatformType.HERMES,
                connected=False,
                available=False,
                error="mflow_v2 模块未安装"
            )
        
        try:
            # 尝试初始化记忆引擎
            engine = self._get_hermes_engine()
            is_ready = engine is not None
            
            return PlatformStatus(
                name="Hermes",
                type=PlatformType.HERMES,
                connected=is_ready,
                available=True,
                version="v2.0.0",
                details={"engine_ready": is_ready},
                capabilities=[
                    "memory_layer_management",
                    "memory_evolution",
                    "skill_distillation",
                    "expert_cloning",
                    "faiss_acceleration"
                ]
            )
        except Exception as e:
            return PlatformStatus(
                name="Hermes",
                type=PlatformType.HERMES,
                connected=False,
                available=True,
                error=str(e)
            )
    
    def _get_hermes_engine(self) -> Optional[MFlowEngineV2]:
        """获取 Hermes 记忆引擎（懒加载）"""
        if not HERMES_AVAILABLE:
            return None
        if self._hermes_engine is None:
            self._hermes_engine = MFlowEngineV2()
        return self._hermes_engine
    
    def hermes_store_memory(self, content: str, layer: str = "working", 
                           importance: float = 5.0, **kwargs) -> Dict:
        """存储记忆到 Hermes"""
        engine = self._get_hermes_engine()
        if not engine:
            return {"success": False, "error": "Hermes 不可用"}
        
        try:
            entry = engine.add_fact({
                "layer": layer,
                "content": content,
                "importance": importance,
                "source": kwargs.get("source", "platform"),
                **kwargs
            })
            return {"success": True, "memory_id": entry.get("id"), "layer": layer}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def hermes_retrieve_memory(self, query: str, layer: str = None, 
                               top_k: int = 5) -> Dict:
        """从 Hermes 检索记忆"""
        engine = self._get_hermes_engine()
        if not engine:
            return {"success": False, "error": "Hermes 不可用"}
        
        try:
            results = engine.retrieve_similar(query, layer=layer, top_k=top_k)
            return {"success": True, "memories": results, "count": len(results)}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def hermes_evolve_memories(self) -> Dict:
        """执行记忆进化"""
        engine = self._get_hermes_engine()
        if not engine:
            return {"success": False, "error": "Hermes 不可用"}
        
        try:
            short_term = engine.retrieve_by_layer("short")
            consolidated = engine.consolidate_memories(short_term)
            return {"success": True, "consolidated": consolidated}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ==================== DeerFlow 平台 ====================
    
    def check_deerflow(self) -> PlatformStatus:
        """检查 DeerFlow 连接状态"""
        if not DEERFLOW_AVAILABLE:
            return PlatformStatus(
                name="DeerFlow",
                type=PlatformType.DEERFLOW,
                connected=False,
                available=False,
                error="deerflow_bridge 模块未安装"
            )
        
        try:
            bridge = self._get_deerflow_bridge()
            is_ready = bridge is not None
            
            return PlatformStatus(
                name="DeerFlow",
                type=PlatformType.DEERFLOW,
                connected=is_ready,
                available=True,
                version="v1.0.0",
                details={"bridge_ready": is_ready},
                capabilities=[
                    "deep_research_chain",
                    "code_sandbox",
                    "multi_agent_collaboration",
                    "tool_orchestration",
                    "research_with_code"
                ]
            )
        except Exception as e:
            return PlatformStatus(
                name="DeerFlow",
                type=PlatformType.DEERFLOW,
                connected=False,
                available=True,
                error=str(e)
            )
    
    def _get_deerflow_bridge(self) -> Optional[DeerFlowBridge]:
        """获取 DeerFlow 桥接器（懒加载）"""
        if not DEERFLOW_AVAILABLE:
            return None
        if self._deerflow_bridge is None:
            self._deerflow_bridge = DeerFlowBridge()
        return self._deerflow_bridge
    
    def deerflow_deep_research(self, topic: str, depth: str = "standard",
                               max_iterations: int = 5) -> Dict:
        """执行 DeerFlow 深度研究"""
        bridge = self._get_deerflow_bridge()
        if not bridge:
            return {"success": False, "error": "DeerFlow 不可用"}
        
        try:
            depth_enum = ResearchDepth(depth)
            result = asyncio.run(bridge.deep_research(
                topic=topic,
                depth=depth_enum,
                max_iterations=max_iterations
            ))
            return {"success": True, "report": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def deerflow_execute_code(self, code: str, language: str = "python",
                              timeout: int = 30) -> Dict:
        """在 DeerFlow 代码沙箱中执行代码"""
        bridge = self._get_deerflow_bridge()
        if not bridge:
            return {"success": False, "error": "DeerFlow 不可用"}
        
        try:
            lang_enum = CodeLanguage(language)
            result = asyncio.run(bridge.execute_code(
                code=code,
                language=lang_enum,
                timeout=timeout
            ))
            return {
                "success": result.success,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "execution_time": result.execution_time
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def deerflow_multi_agent_task(self, task: str, agents: List[str] = None) -> Dict:
        """使用 DeerFlow 多智能体协作执行任务"""
        bridge = self._get_deerflow_bridge()
        if not bridge:
            return {"success": False, "error": "DeerFlow 不可用"}
        
        try:
            result = asyncio.run(bridge.multi_agent_collaboration(
                task=task,
                agent_types=agents or ["researcher", "analyst"]
            ))
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ==================== Swarm 平台 ====================
    
    def check_swarm(self) -> PlatformStatus:
        """检查 Swarm 连接状态"""
        if not SWARM_AVAILABLE:
            return PlatformStatus(
                name="Swarm",
                type=PlatformType.SWARM,
                connected=False,
                available=False,
                error="swarm_bridge 模块未安装"
            )
        
        try:
            bridge = self._get_swarm_bridge()
            is_ready = bridge is not None
            
            return PlatformStatus(
                name="Swarm",
                type=PlatformType.SWARM,
                connected=is_ready,
                available=True,
                version="v1.0.0",
                details={"bridge_ready": is_ready},
                capabilities=[
                    "agent_registry",
                    "context_management",
                    "function_routing",
                    "multi_agent_execution",
                    "handoff_strategies"
                ]
            )
        except Exception as e:
            return PlatformStatus(
                name="Swarm",
                type=PlatformType.SWARM,
                connected=False,
                available=True,
                error=str(e)
            )
    
    def _get_swarm_bridge(self) -> Optional[SwarmBridge]:
        """获取 Swarm 桥接器（懒加载）"""
        if not SWARM_AVAILABLE:
            return None
        if self._swarm_bridge is None:
            self._swarm_bridge = SwarmBridge()
        return self._swarm_bridge
    
    def swarm_execute(self, task: str, starting_agent: str = "researcher",
                      max_turns: int = 10) -> Dict:
        """使用 Swarm 执行多智能体任务"""
        bridge = self._get_swarm_bridge()
        if not bridge:
            return {"success": False, "error": "Swarm 不可用"}
        
        try:
            result = asyncio.run(bridge.execute(
                task=task,
                starting_agent=starting_agent,
                max_turns=max_turns
            ))
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def swarm_route_function(self, intent: str, functions: List[Dict] = None) -> Dict:
        """使用 Swarm 路由函数调用"""
        bridge = self._get_swarm_bridge()
        if not bridge:
            return {"success": False, "error": "Swarm 不可用"}
        
        try:
            result = asyncio.run(bridge.route_function(
                intent=intent,
                available_functions=functions or []
            ))
            return {"success": True, "routing": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def swarm_handoff(self, from_agent: str, to_agent: str, 
                      context: Dict) -> Dict:
        """使用 Swarm 执行智能体上下文交接"""
        bridge = self._get_swarm_bridge()
        if not bridge:
            return {"success": False, "error": "Swarm 不可用"}
        
        try:
            result = asyncio.run(bridge.handoff(
                from_agent=from_agent,
                to_agent=to_agent,
                context=context
            ))
            return {"success": True, "handoff": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ==================== Perplexity 平台 ====================
    
    def check_perplexity(self) -> PlatformStatus:
        """检查 Perplexity 连接状态"""
        if not PERPLEXITY_AVAILABLE:
            return PlatformStatus(
                name="Perplexity",
                type=PlatformType.PERPLEXITY,
                connected=False,
                available=False,
                error="perplexity_bridge 模块未安装"
            )
        
        try:
            has_key = bool(self.perplexity_api_key)
            
            return PlatformStatus(
                name="Perplexity",
                type=PlatformType.PERPLEXITY,
                connected=has_key,
                available=True,
                version="v1.0.0",
                details={"api_key_configured": has_key},
                capabilities=[
                    "real_time_search",
                    "deep_research",
                    "citation_tracking",
                    "fact_checking",
                    "multi_source_comparison",
                    "stream_search"
                ]
            )
        except Exception as e:
            return PlatformStatus(
                name="Perplexity",
                type=PlatformType.PERPLEXITY,
                connected=False,
                available=True,
                error=str(e)
            )
    
    def _get_perplexity_bridge(self) -> Optional[PerplexityBridgeSync]:
        """获取 Perplexity 桥接器（懒加载）"""
        if not PERPLEXITY_AVAILABLE:
            return None
        if self._perplexity_bridge is None:
            self._perplexity_bridge = PerplexityBridgeSync(self.perplexity_api_key)
        return self._perplexity_bridge
    
    # ==================== Grok 平台 ====================
    
    def check_grok(self) -> PlatformStatus:
        """检查 Grok 连接状态"""
        if not GROK_AVAILABLE:
            return PlatformStatus(
                name="Grok",
                type=PlatformType.GROK,
                connected=False,
                available=False,
                error="grok_bridge 模块未安装"
            )
        
        try:
            has_key = bool(self.grok_api_key)
            
            return PlatformStatus(
                name="Grok",
                type=PlatformType.GROK,
                connected=has_key,
                available=True,
                version="v1.0.0",
                details={"api_key_configured": has_key},
                capabilities=[
                    "real_time_chat",
                    "vision_understanding",
                    "code_generation",
                    "code_explanation",
                    "long_context",
                    "stream_response"
                ]
            )
        except Exception as e:
            return PlatformStatus(
                name="Grok",
                type=PlatformType.GROK,
                connected=False,
                available=True,
                error=str(e)
            )
    
    def _get_grok_bridge(self) -> Optional[GrokBridgeSync]:
        """获取 Grok 桥接器（懒加载）"""
        if not GROK_AVAILABLE:
            return None
        if self._grok_bridge is None:
            self._grok_bridge = GrokBridgeSync(self.grok_api_key)
        return self._grok_bridge
    
    def grok_chat(self, message: str, model: str = "grok-2", stream: bool = False) -> Dict:
        """执行 Grok 对话"""
        bridge = self._get_grok_bridge()
        if not bridge:
            return {"success": False, "error": "Grok 不可用"}
        
        try:
            messages = [GrokMessage(role="user", content=message)]
            model_enum = GrokModel(model)
            
            response = bridge.chat(messages, model=model_enum, stream=stream)
            
            if stream:
                return response
            
            return {"success": True, "result": response.to_dict()}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def grok_code_generate(self, description: str, language: str = "python") -> Dict:
        """Grok 代码生成"""
        bridge = self._get_grok_bridge()
        if not bridge:
            return {"success": False, "error": "Grok 不可用"}
        
        try:
            response = bridge.code_generate(description, language=language)
            return {"success": True, "result": response.to_dict()}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def grok_code_explain(self, code: str, language: str = "python") -> Dict:
        """Grok 代码解释"""
        bridge = self._get_grok_bridge()
        if not bridge:
            return {"success": False, "error": "Grok 不可用"}
        
        try:
            response = bridge.code_explain(code, language=language)
            return {"success": True, "result": response.to_dict()}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def grok_vision(self, image_path: str, prompt: str = "描述这张图片") -> Dict:
        """Grok 图像理解"""
        bridge = self._get_grok_bridge()
        if not bridge:
            return {"success": False, "error": "Grok 不可用"}
        
        try:
            import asyncio
            
            async def _vision():
                async with GrokBridge(self.grok_api_key) as grok:
                    return await grok.vision(image_path, prompt)
            
            loop = asyncio.new_event_loop()
            asyncio.set_event_loop(loop)
            response = loop.run_until_complete(_vision())
            loop.close()
            
            return {"success": True, "result": response.to_dict()}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ==================== DeerFlow × Hermes 执行引擎 ====================
    
    def _get_executor(self) -> Optional[DeerFlowHermesExecutor]:
        """获取 DeerFlow × Hermes 执行引擎（懒加载）"""
        if not EXECUTOR_AVAILABLE:
            return None
        if not hasattr(self, '_executor'):
            self._executor = DeerFlowHermesExecutor()
        return self._executor
    
    def execute_advanced(self, query: str, mode: str = None) -> Dict:
        """
        使用 DeerFlow × Hermes 执行引擎执行任务
        
        这是最先进的智能体执行模式，结合：
        - DeerFlow 多智能体协作
        - Hermes 记忆驱动上下文
        - 自适应任务分解
        
        Args:
            query: 任务描述
            mode: 执行模式 (research/code/analysis/creative/planning/conversation)
                 不指定则自动检测
        
        Returns:
            Dict: 执行结果
        """
        executor = self._get_executor()
        if not executor:
            return {"success": False, "error": "DeerFlow × Hermes 执行引擎不可用"}
        
        try:
            # 解析模式
            mode_map = {
                "research": ExecutionMode.RESEARCH,
                "code": ExecutionMode.CODE,
                "analysis": ExecutionMode.ANALYSIS,
                "creative": ExecutionMode.CREATIVE,
                "planning": ExecutionMode.PLANNING,
                "conversation": ExecutionMode.CONVERSATION
            }
            execution_mode = mode_map.get(mode) if mode else None
            
            # 执行
            import asyncio
            result = asyncio.run(executor.execute(query, execution_mode))
            
            return {
                "success": True,
                "result": {
                    "output": result.result,
                    "execution_time": result.execution_time,
                    "agents_involved": [r.value for r in result.agents_involved],
                    "memory_accessed": result.memory_accessed,
                    "reasoning_chain": result.reasoning_chain
                },
                "mode": result.agents_involved[0].value if result.agents_involved else "unknown"
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def execute_research(self, topic: str) -> Dict:
        """执行深度研究 (DeerFlow × Hermes 模式)"""
        return self.execute_advanced(topic, mode="research")
    
    def execute_code(self, requirement: str) -> Dict:
        """执行代码生成 (DeerFlow × Hermes 模式)"""
        return self.execute_advanced(requirement, mode="code")
    
    def execute_analysis(self, query: str) -> Dict:
        """执行分析任务 (DeerFlow × Hermes 模式)"""
        return self.execute_advanced(query, mode="analysis")
    
    def perplexity_search(self, query: str, mode: str = "standard",
                          model: str = "sonar-pro", use_fallback: bool = True) -> Dict:
        """
        执行 Perplexity 搜索 (支持 Fallback)
        
        Args:
            query: 搜索查询
            mode: 搜索模式
            model: 模型类型
            use_fallback: 当 Perplexity 不可用时是否使用 Fallback 搜索
        """
        bridge = self._get_perplexity_bridge()
        
        # 尝试 Perplexity
        if bridge:
            try:
                model_enum = PerplexityModel(model)
                mode_enum = SearchMode(mode)
                
                result = bridge.search(
                    query=query,
                    model=model_enum,
                    mode=mode_enum
                )
                return {"success": True, "result": result.to_dict(), "source": "perplexity"}
            except Exception as e:
                if not use_fallback:
                    return {"success": False, "error": str(e), "source": "perplexity"}
                # 继续尝试 Fallback
        
        # Fallback 搜索 (无需 API Key)
        if use_fallback and FALLBACK_SEARCH_AVAILABLE:
            try:
                fallback = FallbackSearchBridge()
                result = asyncio.run(fallback.search(query))
                return {
                    "success": result.get("success", False),
                    "result": result,
                    "source": result.get("source", "fallback"),
                    "fallback": True
                }
            except Exception as e:
                return {"success": False, "error": f"Fallback 搜索失败: {e}", "source": "none"}
        
        return {"success": False, "error": "Perplexity 不可用且 Fallback 未启用", "source": "none"}
    
    def perplexity_deep_research(self, topic: str, 
                                  sub_questions: List[str] = None) -> Dict:
        """执行 Perplexity 深度研究"""
        bridge = self._get_perplexity_bridge()
        if not bridge:
            return {"success": False, "error": "Perplexity 不可用"}
        
        try:
            session = bridge.deep_research(
                topic=topic,
                sub_questions=sub_questions
            )
            return {
                "success": True,
                "session": {
                    "session_id": session.session_id,
                    "topic": session.topic,
                    "queries": session.queries,
                    "synthesized_report": session.synthesized_report,
                    "created_at": session.created_at.isoformat()
                }
            }
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def perplexity_fact_check(self, statement: str) -> Dict:
        """使用 Perplexity 进行事实核查"""
        bridge = self._get_perplexity_bridge()
        if not bridge:
            return {"success": False, "error": "Perplexity 不可用"}
        
        try:
            result = bridge.fact_check(statement)
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    def perplexity_compare_sources(self, query: str, 
                                    sources: List[str] = None) -> Dict:
        """使用 Perplexity 进行多源对比"""
        bridge = self._get_perplexity_bridge()
        if not bridge:
            return {"success": False, "error": "Perplexity 不可用"}
        
        try:
            result = bridge.compare_sources(query, sources)
            return {"success": True, "result": result}
        except Exception as e:
            return {"success": False, "error": str(e)}
    
    # ==================== 统一接口 ====================
    
    def status(self) -> Dict[str, Any]:
        """获取所有平台的完整状态"""
        openclaw = self.check_openclaw()
        hermes = self.check_hermes()
        deerflow = self.check_deerflow()
        swarm = self.check_swarm()
        perplexity = self.check_perplexity()
        grok = self.check_grok()
        
        return {
            "openclaw": {
                "connected": openclaw.connected,
                "available": openclaw.available,
                "version": openclaw.version,
                "capabilities": openclaw.capabilities,
                "details": openclaw.details
            },
            "hermes": {
                "connected": hermes.connected,
                "available": hermes.available,
                "version": hermes.version,
                "capabilities": hermes.capabilities,
                "details": hermes.details
            },
            "deerflow": {
                "connected": deerflow.connected,
                "available": deerflow.available,
                "version": deerflow.version,
                "capabilities": deerflow.capabilities,
                "details": deerflow.details
            },
            "swarm": {
                "connected": swarm.connected,
                "available": swarm.available,
                "version": swarm.version,
                "capabilities": swarm.capabilities,
                "details": swarm.details
            },
            "perplexity": {
                "connected": perplexity.connected,
                "available": perplexity.available,
                "version": perplexity.version,
                "capabilities": perplexity.capabilities,
                "details": perplexity.details
            },
            "grok": {
                "connected": grok.connected,
                "available": grok.available,
                "version": grok.version,
                "capabilities": grok.capabilities,
                "details": grok.details
            },
            "summary": {
                "all_connected": all([
                    openclaw.connected,
                    hermes.connected,
                    deerflow.connected,
                    swarm.connected,
                    perplexity.connected,
                    grok.connected
                ]),
                "available_count": sum([
                    openclaw.available,
                    hermes.available,
                    deerflow.available,
                    swarm.available,
                    perplexity.available,
                    grok.available
                ]),
                "connected_count": sum([
                    openclaw.connected,
                    hermes.connected,
                    deerflow.connected,
                    swarm.connected,
                    perplexity.connected,
                    grok.connected
                ])
            }
        }
    
    def get_capabilities(self) -> PlatformCapabilities:
        """获取所有平台的详细能力"""
        status = self.status()
        
        return PlatformCapabilities(
            openclaw={
                "status": status["openclaw"],
                "commands": ["publish", "install", "list", "oauth"],
                "features": ["skill_management", "version_control", "tagging"]
            },
            hermes={
                "status": status["hermes"],
                "memory_layers": ["instant", "working", "short", "long", "skill", "expert", "graph"],
                "features": ["faiss_acceleration", "memory_evolution", "skill_distillation"]
            },
            deerflow={
                "status": status["deerflow"],
                "research_depths": ["quick", "standard", "deep", "exhaustive"],
                "features": ["deep_research", "code_sandbox", "multi_agent", "tool_orchestration"]
            },
            swarm={
                "status": status["swarm"],
                "default_agents": ["researcher", "coder", "analyst", "reviewer"],
                "features": ["agent_registry", "function_routing", "context_handoff", "multi_agent"]
            },
            perplexity={
                "status": status["perplexity"],
                "models": ["sonar", "sonar-pro", "sonar-reasoning"],
                "search_modes": ["quick", "standard", "deep", "research"],
                "features": ["real_time_search", "citation_tracking", "fact_checking", "multi_source_comparison"]
            },
            grok={
                "status": status["grok"],
                "models": ["grok-2", "grok-2-mini", "grok-2-vision", "grok-beta"],
                "features": ["real_time_chat", "vision_understanding", "code_generation", "code_explanation", "long_context"],
                "context_window": "128K"
            }
        )


def main():
    """命令行入口"""
    import argparse
    parser = argparse.ArgumentParser(
        description="oclaw-hermes 桥接服务 v3.2 - 六平台统一控制器",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
示例:
  python bridge.py status                           # 查看所有平台状态
  python bridge.py hermes store "关键信息"          # 存储记忆
  python bridge.py deerflow research "主题"         # 深度研究
  python bridge.py swarm execute "任务"             # 多智能体执行
  python bridge.py perplexity search "查询"         # 实时搜索
  python bridge.py perplexity research "主题"       # 深度研究
  python bridge.py grok chat "你好"                 # Grok对话
  python bridge.py grok code "生成快速排序"         # Grok代码生成
        """
    )
    
    subparsers = parser.add_subparsers(dest="command", help="可用命令")
    
    # status 命令
    status_parser = subparsers.add_parser("status", help="查看平台状态")
    status_parser.add_argument("--platform", choices=["openclaw", "hermes", "deerflow", "swarm", "perplexity", "grok", "all"],
                               default="all", help="指定平台")
    
    # hermes 命令
    hermes_parser = subparsers.add_parser("hermes", help="Hermes 记忆操作")
    hermes_sub = hermes_parser.add_subparsers(dest="hermes_action")
    
    hermes_store = hermes_sub.add_parser("store", help="存储记忆")
    hermes_store.add_argument("content", help="记忆内容")
    hermes_store.add_argument("--layer", default="working", help="记忆层")
    hermes_store.add_argument("--importance", type=float, default=5.0, help="重要性")
    
    hermes_retrieve = hermes_sub.add_parser("retrieve", help="检索记忆")
    hermes_retrieve.add_argument("query", help="查询内容")
    hermes_retrieve.add_argument("--layer", help="指定记忆层")
    hermes_retrieve.add_argument("--top-k", type=int, default=5, help="返回数量")
    
    hermes_evolve = hermes_sub.add_parser("evolve", help="执行记忆进化")
    
    # deerflow 命令
    deerflow_parser = subparsers.add_parser("deerflow", help="DeerFlow 研究操作")
    deerflow_sub = deerflow_parser.add_subparsers(dest="deerflow_action")
    
    deerflow_research = deerflow_sub.add_parser("research", help="深度研究")
    deerflow_research.add_argument("topic", help="研究主题")
    deerflow_research.add_argument("--depth", choices=["quick", "standard", "deep", "exhaustive"],
                                   default="standard", help="研究深度")
    deerflow_research.add_argument("--iterations", type=int, default=5, help="最大迭代次数")
    
    deerflow_code = deerflow_sub.add_parser("code", help="执行代码")
    deerflow_code.add_argument("code", help="代码内容")
    deerflow_code.add_argument("--language", choices=["python", "bash", "javascript", "typescript"],
                               default="python", help="代码语言")
    
    # swarm 命令
    swarm_parser = subparsers.add_parser("swarm", help="Swarm 多智能体操作")
    swarm_sub = swarm_parser.add_subparsers(dest="swarm_action")
    
    swarm_execute = swarm_sub.add_parser("execute", help="执行任务")
    swarm_execute.add_argument("task", help="任务描述")
    swarm_execute.add_argument("--agent", default="researcher", help="起始智能体")
    swarm_execute.add_argument("--max-turns", type=int, default=10, help="最大轮数")
    
    swarm_route = swarm_sub.add_parser("route", help="函数路由")
    swarm_route.add_argument("intent", help="意图描述")
    
    # perplexity 命令
    perplexity_parser = subparsers.add_parser("perplexity", help="Perplexity 搜索操作")
    perplexity_sub = perplexity_parser.add_subparsers(dest="perplexity_action")
    
    perplexity_search = perplexity_sub.add_parser("search", help="实时搜索")
    perplexity_search.add_argument("query", help="搜索查询")
    perplexity_search.add_argument("--mode", choices=["quick", "standard", "deep", "research"],
                                   default="standard", help="搜索模式")
    perplexity_search.add_argument("--model", choices=["sonar", "sonar-pro", "sonar-reasoning"],
                                   default="sonar-pro", help="模型类型")
    
    perplexity_research = perplexity_sub.add_parser("research", help="深度研究")
    perplexity_research.add_argument("topic", help="研究主题")
    perplexity_research.add_argument("--questions", nargs="+", help="子问题列表")
    
    perplexity_factcheck = perplexity_sub.add_parser("factcheck", help="事实核查")
    perplexity_factcheck.add_argument("statement", help="待核查陈述")
    
    perplexity_compare = perplexity_sub.add_parser("compare", help="多源对比")
    perplexity_compare.add_argument("query", help="查询主题")
    perplexity_compare.add_argument("--sources", nargs="+", help="指定来源")
    
    # grok 命令
    grok_parser = subparsers.add_parser("grok", help="Grok AI 操作")
    grok_sub = grok_parser.add_subparsers(dest="grok_action")
    
    grok_chat = grok_sub.add_parser("chat", help="对话")
    grok_chat.add_argument("message", help="消息内容")
    grok_chat.add_argument("--model", choices=["grok-2", "grok-2-mini", "grok-2-vision"],
                           default="grok-2", help="模型类型")
    grok_chat.add_argument("--stream", action="store_true", help="流式输出")
    
    grok_code = grok_sub.add_parser("code", help="代码生成")
    grok_code.add_argument("description", help="代码描述")
    grok_code.add_argument("--language", default="python", help="编程语言")
    
    grok_explain = grok_sub.add_parser("explain", help="代码解释")
    grok_explain.add_argument("code", help="代码内容")
    grok_explain.add_argument("--language", default="python", help="编程语言")
    
    grok_vision = grok_sub.add_parser("vision", help="图像理解")
    grok_vision.add_argument("image", help="图像路径或URL")
    grok_vision.add_argument("--prompt", default="描述这张图片", help="提示词")
    
    # execute 命令 (DeerFlow × Hermes 执行引擎)
    execute_parser = subparsers.add_parser("execute", help="DeerFlow × Hermes 智能体执行")
    execute_parser.add_argument("query", help="任务描述")
    execute_parser.add_argument("--mode", "-m",
                               choices=["research", "code", "analysis", "creative", "planning", "conversation"],
                               help="执行模式 (不指定则自动检测)")
    execute_parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")
    
    args = parser.parse_args()
    
    if not args.command:
        parser.print_help()
        return
    
    bridge = OclawHermesBridge()
    
    # status 命令
    if args.command == "status":
        if args.platform == "all":
            status = bridge.status()
            print(json.dumps(status, indent=2, ensure_ascii=False, default=str))
        else:
            check_method = getattr(bridge, f"check_{args.platform}")
            status = check_method()
            print(json.dumps({
                "name": status.name,
                "connected": status.connected,
                "available": status.available,
                "version": status.version,
                "capabilities": status.capabilities,
                "details": status.details
            }, indent=2, ensure_ascii=False))
    
    # hermes 命令
    elif args.command == "hermes":
        if args.hermes_action == "store":
            result = bridge.hermes_store_memory(
                content=args.content,
                layer=args.layer,
                importance=args.importance
            )
            print(json.dumps(result, indent=2, ensure_ascii=False))
        
        elif args.hermes_action == "retrieve":
            result = bridge.hermes_retrieve_memory(
                query=args.query,
                layer=args.layer,
                top_k=args.top_k
            )
            print(json.dumps(result, indent=2, ensure_ascii=False))
        
        elif args.hermes_action == "evolve":
            result = bridge.hermes_evolve_memories()
            print(json.dumps(result, indent=2, ensure_ascii=False))
    
    # deerflow 命令
    elif args.command == "deerflow":
        if args.deerflow_action == "research":
            result = bridge.deerflow_deep_research(
                topic=args.topic,
                depth=args.depth,
                max_iterations=args.iterations
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        
        elif args.deerflow_action == "code":
            result = bridge.deerflow_execute_code(
                code=args.code,
                language=args.language
            )
            print(json.dumps(result, indent=2, ensure_ascii=False))
    
    # swarm 命令
    elif args.command == "swarm":
        if args.swarm_action == "execute":
            result = bridge.swarm_execute(
                task=args.task,
                starting_agent=args.agent,
                max_turns=args.max_turns
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        elif args.swarm_action == "route":
            result = bridge.swarm_route_function(intent=args.intent)
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    
    # perplexity 命令
    elif args.command == "perplexity":
        if args.perplexity_action == "search":
            result = bridge.perplexity_search(
                query=args.query,
                mode=args.mode,
                model=args.model
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        
        elif args.perplexity_action == "research":
            result = bridge.perplexity_deep_research(
                topic=args.topic,
                sub_questions=args.questions
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        
        elif args.perplexity_action == "factcheck":
            result = bridge.perplexity_fact_check(statement=args.statement)
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        
        elif args.perplexity_action == "compare":
            result = bridge.perplexity_compare_sources(
                query=args.query,
                sources=args.sources
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    
    # grok 命令
    elif args.command == "grok":
        if args.grok_action == "chat":
            result = bridge.grok_chat(
                message=args.message,
                model=args.model,
                stream=args.stream
            )
            if args.stream:
                for chunk in result:
                    print(chunk, end="", flush=True)
                print()
            else:
                print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        
        elif args.grok_action == "code":
            result = bridge.grok_code_generate(
                description=args.description,
                language=args.language
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        
        elif args.grok_action == "explain":
            result = bridge.grok_code_explain(
                code=args.code,
                language=args.language
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        
        elif args.grok_action == "vision":
            result = bridge.grok_vision(
                image_path=args.image,
                prompt=args.prompt
            )
            print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
    
    # execute 命令 (DeerFlow × Hermes 执行引擎)
    elif args.command == "execute":
        result = bridge.execute_advanced(
            query=args.query,
            mode=args.mode
        )
        
        if result.get("success"):
            output = result.get("result", {})
            print(f"✅ 执行完成")
            print(f"⏱️  耗时: {output.get('execution_time', 0):.2f}s")
            print(f"🤖 智能体: {', '.join(output.get('agents_involved', []))}")
            print(f"🧠 记忆层: {', '.join(output.get('memory_accessed', []))}")
            
            if args.verbose:
                print(f"\n📝 推理链:")
                for step in output.get('reasoning_chain', []):
                    print(f"  - {step}")
            
            print(f"\n📊 结果:")
            print(json.dumps(output.get('output'), indent=2, ensure_ascii=False))
        else:
            print(f"❌ 执行失败: {result.get('error')}")


if __name__ == "__main__":
    main()
