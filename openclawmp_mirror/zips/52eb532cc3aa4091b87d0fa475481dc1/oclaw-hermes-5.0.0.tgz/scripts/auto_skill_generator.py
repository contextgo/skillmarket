#!/usr/bin/env python3
"""
自动Skill生成器 v3.0
基于mflow记忆体中的执行经验，自动生成可复用的Skills

核心流程：
1. 监控执行模式
2. 识别可复用模式
3. 自动生成Skill
4. 测试验证
5. 发布到OpenClaw
"""

import json
import hashlib
import re
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path
import sys
sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from mflow_v2 import MFlowEngineV2, MemoryEntry

class AutoSkillGenerator:
    """自动Skill生成器"""
    
    def __init__(self):
        self.memory_engine = MFlowEngineV2()
        self.output_dir = Path.home() / ".openclaw" / "skills" / "auto_generated"
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # 生成阈值
        self.thresholds = {
            "min_execution_count": 3,      # 最少执行3次才生成
            "min_success_rate": 0.8,       # 成功率至少80%
            "min_similarity": 0.7,         # 模式相似度阈值
            "max_skill_age_days": 30       # 技能有效期
        }
    
    def analyze_and_generate(self) -> List[Dict]:
        """
        分析记忆并生成Skills
        
        流程:
        1. 从技能记忆层检索执行模式
        2. 识别高频、高成功率的模式
        3. 生成Skill定义
        4. 创建Skill文件
        """
        print("[AUTO-SKILL] 开始分析执行模式...")
        
        # 1. 检索执行模式
        patterns = self._extract_patterns()
        print(f"[AUTO-SKILL] 发现 {len(patterns)} 个潜在模式")
        
        # 2. 筛选可生成Skill的模式
        qualified_patterns = self._filter_qualified_patterns(patterns)
        print(f"[AUTO-SKILL] {len(qualified_patterns)} 个模式满足生成条件")
        
        # 3. 生成Skills
        generated_skills = []
        for pattern in qualified_patterns:
            skill = self._generate_skill(pattern)
            if skill:
                generated_skills.append(skill)
                print(f"[AUTO-SKILL] 生成Skill: {skill['name']}")
        
        # 4. 保存Skills
        for skill in generated_skills:
            self._save_skill(skill)
        
        return generated_skills
    
    def _extract_patterns(self) -> List[Dict]:
        """从记忆层提取执行模式"""
        patterns = []
        
        # 从技能记忆检索
        skill_memories = self.memory_engine.retrieve(
            query="execution_pattern",
            layer="skill",
            top_k=50
        )
        
        for memory in skill_memories:
            try:
                content = json.loads(memory.get("content", "{}"))
                if content.get("type") == "auto_generated_pattern":
                    patterns.append({
                        "id": memory["id"],
                        "intent": content.get("intent"),
                        "agents_pattern": content.get("agents_pattern", []),
                        "execution_count": memory.get("metadata", {}).get("execution_count", 1),
                        "success_rate": content.get("success_rate", 0),
                        "avg_time": content.get("avg_execution_time", 0),
                        "timestamp": memory["timestamp"]
                    })
            except:
                continue
        
        return patterns
    
    def _filter_qualified_patterns(self, patterns: List[Dict]) -> List[Dict]:
        """筛选满足生成条件的模式"""
        qualified = []
        
        for pattern in patterns:
            # 检查执行次数
            if pattern["execution_count"] < self.thresholds["min_execution_count"]:
                continue
            
            # 检查成功率
            if pattern["success_rate"] < self.thresholds["min_success_rate"]:
                continue
            
            # 检查是否已生成
            if self._is_already_generated(pattern["intent"]):
                continue
            
            qualified.append(pattern)
        
        return qualified
    
    def _is_already_generated(self, intent: str) -> bool:
        """检查该意图是否已生成Skill"""
        skill_name = f"auto_{intent}_workflow"
        skill_path = self.output_dir / skill_name
        return skill_path.exists()
    
    def _generate_skill(self, pattern: Dict) -> Optional[Dict]:
        """基于模式生成Skill定义"""
        intent = pattern["intent"]
        agents = pattern["agents_pattern"]
        
        skill_name = f"auto_{intent}_workflow"
        skill_id = hashlib.md5(skill_name.encode()).hexdigest()[:16]
        
        # 生成Skill内容
        skill = {
            "name": skill_name,
            "version": "1.0.0",
            "description": f"自动生成的{intent}处理工作流，基于{pattern['execution_count']}次成功执行",
            "generated": {
                "at": datetime.now().isoformat(),
                "from_pattern": pattern["id"],
                "execution_count": pattern["execution_count"],
                "success_rate": pattern["success_rate"]
            },
            "trigger": {
                "intents": [intent],
                "keywords": self._extract_keywords(intent),
                "confidence_threshold": 0.75
            },
            "workflow": {
                "agents": agents,
                "execution_mode": "parallel",
                "max_workers": len(agents)
            },
            "optimization": {
                "avg_execution_time": pattern["avg_time"],
                "estimated_efficiency_gain": f"{len(agents) * 15}%"
            }
        }
        
        return skill
    
    def _extract_keywords(self, intent: str) -> List[str]:
        """从意图提取关键词"""
        keyword_map = {
            "research": ["研究", "分析", "调查", "了解", "探索"],
            "code": ["代码", "编程", "实现", "开发", "写"],
            "browser": ["搜索", "查找", "浏览", "获取", "查"],
            "skill": ["使用", "调用", "执行", "运行"],
            "expert": ["角度", "视角", "建议", "看法"],
            "mediation": ["调解", "纠纷", "争议", "仲裁"],
            "cost": ["造价", "成本", "预算", "估算"],
            "project": ["项目", "管理", "进度", "工期"]
        }
        
        return keyword_map.get(intent, [intent])
    
    def _save_skill(self, skill: Dict):
        """保存Skill到文件系统"""
        skill_name = skill["name"]
        skill_dir = self.output_dir / skill_name
        skill_dir.mkdir(exist_ok=True)
        
        # 保存metadata
        metadata_file = skill_dir / ".metadata.json"
        with open(metadata_file, "w", encoding="utf-8") as f:
            json.dump({
                "name": skill_name,
                "version": skill["version"],
                "description": skill["description"],
                "author": "auto_generator",
                "tags": ["auto_generated", skill["trigger"]["intents"][0], "workflow"]
            }, f, ensure_ascii=False, indent=2)
        
        # 保存SKILL.md
        skill_md = skill_dir / "SKILL.md"
        skill_md.write_text(self._generate_skill_md(skill), encoding="utf-8")
        
        # 保存workflow定义
        workflow_file = skill_dir / "workflow.json"
        with open(workflow_file, "w", encoding="utf-8") as f:
            json.dump(skill, f, ensure_ascii=False, indent=2)
        
        print(f"[AUTO-SKILL] Skill已保存: {skill_dir}")
    
    def _generate_skill_md(self, skill: Dict) -> str:
        """生成SKILL.md内容"""
        intent = skill["trigger"]["intents"][0]
        agents = ", ".join(skill["workflow"]["agents"])
        
        return f"""# {skill['name']}

> 自动生成的Skill，基于{skill['generated']['execution_count']}次成功执行经验

## 简介

{skill['description']}

### 生成信息

- **生成时间**: {skill['generated']['at']}
- **成功率**: {skill['generated']['success_rate']*100:.1f}%
- **平均执行时间**: {skill['optimization']['avg_execution_time']:.2f}s
- **效率提升**: {skill['optimization']['estimated_efficiency_gain']}

## 触发条件

### 意图识别

- **主要意图**: {intent}
- **置信度阈值**: {skill['trigger']['confidence_threshold']}

### 关键词

{', '.join(skill['trigger']['keywords'])}

## 执行工作流

### 并行智能体

{agents}

### 执行模式

**并行执行** - {len(skill['workflow']['agents'])}个智能体同时工作

## 使用示例

```bash
> 使用 {skill['name']} 处理 [任务描述]
```

## 优化建议

此Skill基于实际执行数据自动生成，建议：
1. 监控执行效果
2. 收集用户反馈
3. 定期更新优化

---

*自动生成于 {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}*
"""
    
    def publish_skills(self) -> List[str]:
        """
        发布生成的Skills到OpenClaw
        
        Returns:
            已发布的Skill ID列表
        """
        published = []
        
        for skill_dir in self.output_dir.iterdir():
            if not skill_dir.is_dir():
                continue
            
            metadata_file = skill_dir / ".metadata.json"
            if not metadata_file.exists():
                continue
            
            # 这里调用openclawmp publish命令
            # 实际实现需要根据OpenClaw CLI调整
            print(f"[AUTO-SKILL] 准备发布: {skill_dir.name}")
            published.append(skill_dir.name)
        
        return published
    
    def get_skill_stats(self) -> Dict:
        """获取自动生成的Skill统计"""
        stats = {
            "total_generated": 0,
            "by_intent": {},
            "avg_success_rate": 0,
            "total_executions": 0
        }
        
        for skill_dir in self.output_dir.iterdir():
            if not skill_dir.is_dir():
                continue
            
            workflow_file = skill_dir / "workflow.json"
            if workflow_file.exists():
                try:
                    with open(workflow_file, "r", encoding="utf-8") as f:
                        skill = json.load(f)
                    
                    stats["total_generated"] += 1
                    intent = skill["trigger"]["intents"][0]
                    stats["by_intent"][intent] = stats["by_intent"].get(intent, 0) + 1
                    stats["total_executions"] += skill["generated"]["execution_count"]
                except:
                    continue
        
        if stats["total_generated"] > 0:
            stats["avg_success_rate"] = stats["total_executions"] / stats["total_generated"]
        
        return stats

# 便捷函数
def generate_skills_from_experience():
    """从经验生成Skills"""
    generator = AutoSkillGenerator()
    return generator.analyze_and_generate()

def publish_auto_skills():
    """发布自动生成的Skills"""
    generator = AutoSkillGenerator()
    return generator.publish_skills()

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="自动Skill生成器")
    parser.add_argument("command", choices=["generate", "publish", "stats"])
    
    args = parser.parse_args()
    
    generator = AutoSkillGenerator()
    
    if args.command == "generate":
        skills = generator.analyze_and_generate()
        print(f"\n生成了 {len(skills)} 个Skills:")
        for skill in skills:
            print(f"  - {skill['name']}")
    
    elif args.command == "publish":
        published = generator.publish_skills()
        print(f"\n发布了 {len(published)} 个Skills")
    
    elif args.command == "stats":
        stats = generator.get_skill_stats()
        print(json.dumps(stats, ensure_ascii=False, indent=2))
