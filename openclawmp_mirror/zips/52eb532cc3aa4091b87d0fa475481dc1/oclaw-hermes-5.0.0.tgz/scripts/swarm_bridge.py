#!/usr/bin/env python3
"""
Swarm 桥接器模块 v1.0
Swarm Bridge Module

将 OpenAI Swarm 的完整能力深度集成到 oclaw-hermes 中：
1. **轻量级多智能体** - 极简智能体定义和协作
2. **函数调用路由** - 智能体间通过函数调用交接
3. **上下文传递** - 无缝上下文管理和传递
4. **智能体注册中心** - 动态智能体发现和管理
5. **执行追踪** - 完整的调用链追踪

作者: dlh365
版本: 1.0.0
"""

import asyncio
import json
import hashlib
from typing import Dict, List, Any, Optional, Callable, Union, AsyncGenerator
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from concurrent.futures import ThreadPoolExecutor
import sys
sys.path.insert(0, 'C:\\Users\\wry08\\.openclaw\\skills\\oclaw-hermes\\scripts')

from mflow_v2 import MFlowEngineV2, MemoryEntry

# ==================== 数据模型 ====================

class HandoffStrategy(Enum):
    """交接策略"""
    DIRECT = "direct"           # 直接交接
    CONDITIONAL = "conditional" # 条件交接
    BROADCAST = "broadcast"     # 广播交接
    ROUTED = "routed"           # 路由交接

@dataclass
class AgentFunction:
    """智能体可调用的函数"""
    name: str
    description: str
    parameters: Dict[str, Any]
    handler: Callable = None
    
@dataclass
class SwarmAgent:
    """Swarm 智能体定义"""
    name: str
    description: str
    instructions: str
    functions: List[AgentFunction] = field(default_factory=list)
    handoffs: List[str] = field(default_factory=list)  # 可交接给的智能体
    model: str = "gpt-4"
    temperature: float = 0.7
    
    def add_function(self, func: AgentFunction):
        """添加函数"""
        self.functions.append(func)
    
    def add_handoff(self, agent_name: str):
        """添加可交接的智能体"""
        if agent_name not in self.handoffs:
            self.handoffs.append(agent_name)

@dataclass
class SwarmMessage:
    """Swarm 消息"""
    role: str  # system, user, assistant, function
    content: str
    name: Optional[str] = None  # function name
    function_call: Optional[Dict] = None
    agent: Optional[str] = None  # 发送消息的智能体
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()

@dataclass
class HandoffEvent:
    """交接事件"""
    from_agent: str
    to_agent: str
    reason: str
    context: Dict[str, Any] = field(default_factory=dict)
    strategy: HandoffStrategy = HandoffStrategy.DIRECT
    timestamp: datetime = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now()

@dataclass
class SwarmExecution:
    """Swarm 执行记录"""
    execution_id: str
    task: str
    messages: List[SwarmMessage] = field(default_factory=list)
    handoffs: List[HandoffEvent] = field(default_factory=list)
    active_agent: str = ""
    completed: bool = False
    result: Any = None
    start_time: datetime = None
    end_time: datetime = None
    
    def __post_init__(self):
        if self.start_time is None:
            self.start_time = datetime.now()

# ==================== Swarm 核心能力 ====================

class AgentRegistry:
    """
    智能体注册中心
    
    Swarm 核心能力：动态智能体发现和管理
    """
    
    def __init__(self):
        self.agents: Dict[str, SwarmAgent] = {}
        self.agent_capabilities: Dict[str, List[str]] = {}
        self.mflow = MFlowEngineV2()
        
    def register(self, agent: SwarmAgent) -> bool:
        """
        注册智能体
        
        Args:
            agent: 智能体定义
            
        Returns:
            bool: 是否注册成功
        """
        if agent.name in self.agents:
            return False
            
        self.agents[agent.name] = agent
        
        # 提取能力标签
        capabilities = []
        for func in agent.functions:
            capabilities.append(func.name)
        self.agent_capabilities[agent.name] = capabilities
        
        # 存储到记忆
        self.mflow.store(MemoryEntry(
            id=f"swarm_agent_{agent.name}",
            layer="skill",
            content=json.dumps({
                "type": "swarm_agent",
                "name": agent.name,
                "description": agent.description,
                "capabilities": capabilities,
                "handoffs": agent.handoffs
            }),
            source="swarm_bridge",
            importance=7.0,
            metadata={"tags": ["swarm", "agent", agent.name]}
        ))
        
        return True
    
    def unregister(self, agent_name: str) -> bool:
        """注销智能体"""
        if agent_name in self.agents:
            del self.agents[agent_name]
            del self.agent_capabilities[agent_name]
            return True
        return False
    
    def get_agent(self, name: str) -> Optional[SwarmAgent]:
        """获取智能体"""
        return self.agents.get(name)
    
    def find_agents_by_capability(self, capability: str) -> List[SwarmAgent]:
        """根据能力查找智能体"""
        results = []
        for name, capabilities in self.agent_capabilities.items():
            if capability in capabilities:
                results.append(self.agents[name])
        return results
    
    def list_agents(self) -> List[Dict]:
        """列出所有智能体"""
        return [
            {
                "name": name,
                "description": agent.description,
                "functions": [f.name for f in agent.functions],
                "handoffs": agent.handoffs
            }
            for name, agent in self.agents.items()
        ]

class ContextManager:
    """
    上下文管理器
    
    Swarm 核心能力：无缝上下文管理和传递
    """
    
    def __init__(self):
        self.contexts: Dict[str, Dict[str, Any]] = {}
        self.shared_memory: Dict[str, Any] = {}
        
    def create_context(self, execution_id: str, initial_data: Dict = None) -> str:
        """
        创建执行上下文
        
        Args:
            execution_id: 执行ID
            initial_data: 初始数据
            
        Returns:
            str: 上下文ID
        """
        context_id = f"ctx_{execution_id}"
        self.contexts[context_id] = {
            "execution_id": execution_id,
            "data": initial_data or {},
            "created_at": datetime.now(),
            "access_count": 0
        }
        return context_id
    
    def get_context(self, context_id: str) -> Optional[Dict]:
        """获取上下文"""
        ctx = self.contexts.get(context_id)
        if ctx:
            ctx["access_count"] += 1
        return ctx
    
    def update_context(self, context_id: str, data: Dict) -> bool:
        """更新上下文"""
        if context_id in self.contexts:
            self.contexts[context_id]["data"].update(data)
            return True
        return False
    
    def share_data(self, key: str, value: Any):
        """共享数据到全局内存"""
        self.shared_memory[key] = {
            "value": value,
            "timestamp": datetime.now()
        }
    
    def get_shared(self, key: str) -> Any:
        """获取共享数据"""
        entry = self.shared_memory.get(key)
        return entry["value"] if entry else None
    
    def transfer_context(
        self,
        from_context: str,
        to_context: str,
        keys: List[str] = None
    ) -> Dict:
        """
        在上下文之间传递数据
        
        Args:
            from_context: 源上下文ID
            to_context: 目标上下文ID
            keys: 要传递的键列表，None表示全部
            
        Returns:
            Dict: 传递的数据
        """
        source = self.contexts.get(from_context, {}).get("data", {})
        target = self.contexts.get(to_context, {}).get("data", {})
        
        if keys is None:
            transferred = source.copy()
        else:
            transferred = {k: source.get(k) for k in keys if k in source}
        
        target.update(transferred)
        return transferred

class FunctionRouter:
    """
    函数路由器
    
    Swarm 核心能力：智能体间通过函数调用交接
    """
    
    def __init__(self, registry: AgentRegistry):
        self.registry = registry
        self.routes: Dict[str, Dict[str, Any]] = {}
        self.execution_history: List[Dict] = []
        
    def register_route(
        self,
        from_agent: str,
        to_agent: str,
        condition: Callable = None,
        transform: Callable = None
    ):
        """
        注册路由规则
        
        Args:
            from_agent: 源智能体
            to_agent: 目标智能体
            condition: 路由条件函数
            transform: 消息转换函数
        """
        route_key = f"{from_agent}->{to_agent}"
        self.routes[route_key] = {
            "from": from_agent,
            "to": to_agent,
            "condition": condition,
            "transform": transform
        }
    
    async def route(
        self,
        message: SwarmMessage,
        current_agent: str,
        context: Dict
    ) -> Optional[str]:
        """
        路由消息到下一个智能体
        
        Args:
            message: 当前消息
            current_agent: 当前智能体
            context: 执行上下文
            
        Returns:
            Optional[str]: 目标智能体名称，None表示不路由
        """
        agent = self.registry.get_agent(current_agent)
        if not agent:
            return None
        
        # 检查显式交接
        if message.function_call:
            func_name = message.function_call.get("name", "")
            if func_name.startswith("handoff_to_"):
                target = func_name.replace("handoff_to_", "")
                if target in agent.handoffs:
                    return target
        
        # 检查条件路由
        for route_key, route in self.routes.items():
            if route["from"] == current_agent:
                if route["condition"] is None or route["condition"](message, context):
                    return route["to"]
        
        # 默认：检查消息内容是否提到其他智能体
        for handoff_agent in agent.handoffs:
            if handoff_agent.lower() in message.content.lower():
                return handoff_agent
        
        return None
    
    def create_handoff_function(self, target_agent: str) -> AgentFunction:
        """
        创建交接函数
        
        Args:
            target_agent: 目标智能体名称
            
        Returns:
            AgentFunction: 交接函数定义
        """
        return AgentFunction(
            name=f"handoff_to_{target_agent}",
            description=f"将任务交接给 {target_agent} 处理",
            parameters={
                "type": "object",
                "properties": {
                    "reason": {
                        "type": "string",
                        "description": "交接原因"
                    },
                    "context": {
                        "type": "object",
                        "description": "需要传递的上下文"
                    }
                },
                "required": ["reason"]
            },
            handler=lambda reason, context=None: {
                "status": "handoff",
                "target": target_agent,
                "reason": reason,
                "context": context or {}
            }
        )

class SwarmOrchestrator:
    """
    Swarm 编排器
    
    核心编排逻辑，协调多个智能体协作完成任务
    """
    
    def __init__(self):
        self.registry = AgentRegistry()
        self.context_manager = ContextManager()
        self.router = FunctionRouter(self.registry)
        self.executions: Dict[str, SwarmExecution] = {}
        self.mflow = MFlowEngineV2()
        
    async def execute(
        self,
        task: str,
        starting_agent: str,
        context: Dict = None,
        max_turns: int = 10
    ) -> SwarmExecution:
        """
        执行 Swarm 任务
        
        Args:
            task: 任务描述
            starting_agent: 起始智能体
            context: 初始上下文
            max_turns: 最大轮数
            
        Returns:
            SwarmExecution: 执行记录
        """
        execution_id = hashlib.md5(f"{task}_{datetime.now()}".encode()).hexdigest()[:12]
        
        # 创建执行记录
        execution = SwarmExecution(
            execution_id=execution_id,
            task=task,
            active_agent=starting_agent
        )
        self.executions[execution_id] = execution
        
        # 创建上下文
        context_id = self.context_manager.create_context(execution_id, context)
        
        # 添加初始消息
        execution.messages.append(SwarmMessage(
            role="user",
            content=task
        ))
        
        # 执行循环
        current_agent_name = starting_agent
        
        for turn in range(max_turns):
            agent = self.registry.get_agent(current_agent_name)
            if not agent:
                execution.messages.append(SwarmMessage(
                    role="system",
                    content=f"错误: 智能体 '{current_agent_name}' 不存在"
                ))
                break
            
            # 模拟智能体处理（实际应调用LLM）
            response = await self._process_agent_turn(
                agent=agent,
                messages=execution.messages,
                context=self.context_manager.get_context(context_id)
            )
            
            response.agent = current_agent_name
            execution.messages.append(response)
            
            # 检查是否需要交接
            next_agent = await self.router.route(
                response,
                current_agent_name,
                self.context_manager.get_context(context_id)
            )
            
            if next_agent and next_agent != current_agent_name:
                # 记录交接
                handoff = HandoffEvent(
                    from_agent=current_agent_name,
                    to_agent=next_agent,
                    reason="函数调用路由" if response.function_call else "内容匹配",
                    context={"turn": turn}
                )
                execution.handoffs.append(handoff)
                current_agent_name = next_agent
                execution.active_agent = next_agent
                
                # 添加系统消息
                execution.messages.append(SwarmMessage(
                    role="system",
                    content=f"[系统] 任务已交接给 {next_agent}",
                    agent="system"
                ))
            
            # 检查是否完成
            if self._is_complete(response):
                execution.completed = True
                execution.result = response.content
                break
        
        execution.end_time = datetime.now()
        
        # 存储执行记录到记忆
        self.mflow.store(MemoryEntry(
            id=f"swarm_exec_{execution_id}",
            layer="long",
            content=json.dumps({
                "type": "swarm_execution",
                "execution_id": execution_id,
                "task": task,
                "agents_involved": list(set([m.agent for m in execution.messages if m.agent])),
                "handoffs": len(execution.handoffs),
                "completed": execution.completed
            }),
            source="swarm_orchestrator",
            importance=6.0,
            metadata={"tags": ["swarm", "execution", execution_id]}
        ))
        
        return execution
    
    async def _process_agent_turn(
        self,
        agent: SwarmAgent,
        messages: List[SwarmMessage],
        context: Dict
    ) -> SwarmMessage:
        """处理智能体回合"""
        # 模拟智能体响应（实际应调用LLM API）
        last_message = messages[-1] if messages else None
        
        # 检查是否需要调用函数
        if agent.functions and "调用" in (last_message.content if last_message else ""):
            func = agent.functions[0]
            return SwarmMessage(
                role="assistant",
                content=f"我将调用 {func.name} 来处理这个请求",
                function_call={
                    "name": func.name,
                    "arguments": json.dumps({"query": last_message.content if last_message else ""})
                }
            )
        
        # 检查是否需要交接
        for handoff in agent.handoffs:
            if handoff.lower() in (last_message.content if last_message else "").lower():
                return SwarmMessage(
                    role="assistant",
                    content=f"我需要将这个问题交接给 {handoff} 处理",
                    function_call={
                        "name": f"handoff_to_{handoff}",
                        "arguments": json.dumps({"reason": "专业领域匹配"})
                    }
                )
        
        # 普通响应
        return SwarmMessage(
            role="assistant",
            content=f"[{agent.name}] 已收到请求，正在处理: '{last_message.content if last_message else ''}'..."
        )
    
    def _is_complete(self, message: SwarmMessage) -> bool:
        """检查是否完成任务"""
        completion_markers = ["完成", "done", "finished", "结束", "总结"]
        return any(marker in message.content.lower() for marker in completion_markers)
    
    def get_execution(self, execution_id: str) -> Optional[SwarmExecution]:
        """获取执行记录"""
        return self.executions.get(execution_id)
    
    def create_default_agents(self):
        """创建默认智能体集合"""
        # 研究智能体
        researcher = SwarmAgent(
            name="researcher",
            description="深度研究专家",
            instructions="你是一个研究专家，擅长信息收集和分析。当遇到需要编码实现的问题时，交接给 coder。",
            handoffs=["coder", "analyst"]
        )
        researcher.add_function(AgentFunction(
            name="search",
            description="搜索信息",
            parameters={"type": "object", "properties": {"query": {"type": "string"}}}
        ))
        self.registry.register(researcher)
        
        # 编码智能体
        coder = SwarmAgent(
            name="coder",
            description="代码实现专家",
            instructions="你是一个编码专家，擅长算法和工程实现。当需要分析结果时，交接给 analyst。",
            handoffs=["analyst", "researcher"]
        )
        coder.add_function(AgentFunction(
            name="write_code",
            description="编写代码",
            parameters={"type": "object", "properties": {"language": {"type": "string"}, "task": {"type": "string"}}}
        ))
        self.registry.register(coder)
        
        # 分析智能体
        analyst = SwarmAgent(
            name="analyst",
            description="数据分析专家",
            instructions="你是一个分析专家，擅长模式识别和洞察提取。当研究不足时，交接给 researcher。",
            handoffs=["researcher", "reviewer"]
        )
        self.registry.register(analyst)
        
        # 审查智能体
        reviewer = SwarmAgent(
            name="reviewer",
            description="质量审查专家",
            instructions="你是一个审查专家，负责验证和评估结果质量。",
            handoffs=[]
        )
        self.registry.register(reviewer)
        
        # 注册路由
        self.router.register_route("researcher", "coder", 
            condition=lambda msg, ctx: "代码" in msg.content or "实现" in msg.content)
        self.router.register_route("coder", "analyst",
            condition=lambda msg, ctx: "分析" in msg.content or "结果" in msg.content)

# ==================== Swarm 桥接器主类 ====================

class SwarmBridge:
    """
    Swarm 桥接器
    
    统一接口访问 Swarm 的所有核心能力
    """
    
    def __init__(self):
        self.orchestrator = SwarmOrchestrator()
        self.registry = self.orchestrator.registry
        self.context_manager = self.orchestrator.context_manager
        
    def register_agent(self, agent: SwarmAgent) -> bool:
        """
        注册智能体
        
        Args:
            agent: 智能体定义
            
        Returns:
            bool: 是否成功
        """
        return self.registry.register(agent)
    
    def create_agent(
        self,
        name: str,
        description: str,
        instructions: str,
        functions: List[Dict] = None,
        handoffs: List[str] = None
    ) -> SwarmAgent:
        """
        创建智能体
        
        Args:
            name: 智能体名称
            description: 描述
            instructions: 系统指令
            functions: 函数定义列表
            handoffs: 可交接的智能体
            
        Returns:
            SwarmAgent: 创建的智能体
        """
        agent = SwarmAgent(
            name=name,
            description=description,
            instructions=instructions,
            handoffs=handoffs or []
        )
        
        if functions:
            for func_def in functions:
                agent.add_function(AgentFunction(
                    name=func_def["name"],
                    description=func_def.get("description", ""),
                    parameters=func_def.get("parameters", {})
                ))
        
        self.registry.register(agent)
        return agent
    
    async def run(
        self,
        task: str,
        agents: List[str] = None,
        starting_agent: str = None,
        context: Dict = None,
        max_turns: int = 10
    ) -> SwarmExecution:
        """
        运行 Swarm 任务
        
        Args:
            task: 任务描述
            agents: 参与智能体列表（None使用所有已注册）
            starting_agent: 起始智能体（None使用第一个）
            context: 初始上下文
            max_turns: 最大轮数
            
        Returns:
            SwarmExecution: 执行记录
        """
        # 如果没有指定智能体，使用默认
        if not self.registry.list_agents():
            self.orchestrator.create_default_agents()
        
        if starting_agent is None:
            agents_list = self.registry.list_agents()
            if agents_list:
                starting_agent = agents_list[0]["name"]
            else:
                raise ValueError("没有可用的智能体")
        
        return await self.orchestrator.execute(
            task=task,
            starting_agent=starting_agent,
            context=context,
            max_turns=max_turns
        )
    
    def add_handoff(self, from_agent: str, to_agent: str):
        """
        添加智能体间交接关系
        
        Args:
            from_agent: 源智能体
            to_agent: 目标智能体
        """
        agent = self.registry.get_agent(from_agent)
        if agent:
            agent.add_handoff(to_agent)
            # 添加交接函数
            handoff_func = self.router.create_handoff_function(to_agent)
            agent.add_function(handoff_func)
    
    def get_capabilities(self) -> Dict:
        """获取 Swarm 能力列表"""
        return {
            "agent_registry": {
                "description": "智能体注册和管理",
                "features": ["register", "unregister", "find_by_capability", "list"]
            },
            "context_management": {
                "description": "上下文管理和传递",
                "features": ["create", "update", "transfer", "share"]
            },
            "function_routing": {
                "description": "函数调用路由",
                "features": ["register_route", "route", "handoff"]
            },
            "execution_orchestration": {
                "description": "执行编排",
                "features": ["execute", "track", "multi_agent"]
            }
        }
    
    @property
    def router(self):
        return self.orchestrator.router

# ==================== 便捷函数 ====================

async def run_swarm(task: str, starting_agent: str = "researcher") -> SwarmExecution:
    """便捷函数：运行 Swarm 任务"""
    bridge = SwarmBridge()
    return await bridge.run(task, starting_agent=starting_agent)

def create_agent(name: str, description: str, instructions: str) -> SwarmAgent:
    """便捷函数：创建智能体"""
    bridge = SwarmBridge()
    return bridge.create_agent(name, description, instructions)

# ==================== 测试 ====================

async def test_swarm_bridge():
    """测试 Swarm 桥接器"""
    print("=" * 60)
    print("Swarm 桥接器测试")
    print("=" * 60)
    
    bridge = SwarmBridge()
    
    # 1. 测试智能体注册
    print("\n[1/5] 测试智能体注册...")
    bridge.orchestrator.create_default_agents()
    agents = bridge.registry.list_agents()
    print(f"✅ 已注册 {len(agents)} 个智能体:")
    for agent in agents:
        print(f"   - {agent['name']}: {agent['description']}")
    
    # 2. 测试智能体查找
    print("\n[2/5] 测试智能体查找...")
    researcher = bridge.registry.get_agent("researcher")
    if researcher:
        print(f"✅ 找到 researcher: {researcher.description}")
        print(f"   函数: {[f.name for f in researcher.functions]}")
        print(f"   可交接: {researcher.handoffs}")
    
    # 3. 测试上下文管理
    print("\n[3/5] 测试上下文管理...")
    ctx_id = bridge.context_manager.create_context("test_exec", {"topic": "AI测试"})
    bridge.context_manager.update_context(ctx_id, {"step": 1})
    ctx = bridge.context_manager.get_context(ctx_id)
    print(f"✅ 上下文创建: {ctx_id}")
    print(f"   数据: {ctx['data']}")
    
    # 4. 测试 Swarm 执行
    print("\n[4/5] 测试 Swarm 执行...")
    execution = await bridge.run(
        task="研究AI发展趋势并编写示例代码",
        starting_agent="researcher",
        max_turns=5
    )
    print(f"✅ 执行完成: {execution.execution_id}")
    print(f"   消息数: {len(execution.messages)}")
    print(f"   交接次数: {len(execution.handoffs)}")
    print(f"   是否完成: {execution.completed}")
    
    # 显示对话流程
    print("\n   对话流程:")
    for msg in execution.messages[-5:]:  # 显示最后5条
        agent_tag = f"[{msg.agent}]" if msg.agent else ""
        print(f"   {agent_tag} {msg.role}: {msg.content[:50]}...")
    
    # 5. 获取能力列表
    print("\n[5/5] 获取能力列表...")
    capabilities = bridge.get_capabilities()
    print("✅ Swarm 核心能力:")
    for cap_name, cap_info in capabilities.items():
        print(f"\n📌 {cap_name}")
        print(f"   描述: {cap_info['description']}")
        print(f"   特性: {', '.join(cap_info['features'])}")
    
    print("\n" + "=" * 60)
    print("✅ 所有测试通过!")
    print("=" * 60)

if __name__ == "__main__":
    asyncio.run(test_swarm_bridge())
