# oclaw-hermes 七层记忆架构详解

> **记忆的层次，决定了智能的深度。**

## 架构概览

```
┌─────────────────────────────────────────────────────────────────┐
│                        七层记忆金字塔                            │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│     ┌─────────┐                                                 │
│     │  Graph  │  图记忆层 - 实体关系网络 (永久)                  │
│     │  图记忆  │  知识图谱、关联推理、关系导航                    │
│     └────┬────┘                                                 │
│          │                                                      │
│     ┌────┴────┐                                                 │
│     │ Expert  │  专家记忆层 - 蒸馏思维 (永久)                    │
│     │ 专家记忆 │  决策模式、心智模型、价值观边界                  │
│     └────┬────┘                                                 │
│          │                                                      │
│     ┌────┴────┐                                                 │
│     │  Skill  │  技能记忆层 - 使用经验 (永久)                    │
│     │ 技能记忆 │  Skill调用记录、最佳实践、参数优化               │
│     └────┬────┘                                                 │
│          │                                                      │
│     ┌────┴────┐                                                 │
│     │  Long   │  长期记忆层 - 持久知识 (永久)                    │
│     │ 长期记忆 │  用户偏好、项目背景、重要事实                    │
│     └────┬────┘                                                 │
│          │                                                      │
│     ┌────┴────┐                                                 │
│     │  Short  │  短期记忆层 - 近期会话 (7天)                     │
│     │ 短期记忆 │  会话摘要、高频访问、跨会话上下文                │
│     └────┬────┘                                                 │
│          │                                                      │
│     ┌────┴────┐                                                 │
│     │ Working │  工作记忆层 - 推理状态 (2小时)                   │
│     │ 工作记忆 │  中间计算结果、临时状态、多步推理                │
│     └────┬────┘                                                 │
│          │                                                      │
│     ┌────┴────┐                                                 │
│     │ Instant │  即时记忆层 - 当前会话 (1小时)                   │
│     │ 即时记忆 │  对话上下文、当前意图、实时状态                  │
│     └─────────┘                                                 │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

---

## Layer 1: Instant 即时记忆

### 定义
当前会话的实时上下文，保持对话的连贯性和即时响应能力。

### 生命周期
- **TTL**: 1小时
- **触发清理**: 会话结束或超时

### 存储内容
```python
instant_memory = {
    "session_id": "sess_20260411_223000",
    "turns": [
        {"role": "user", "content": "启动hermes桥接", "timestamp": "..."},
        {"role": "assistant", "content": "桥接已启动...", "timestamp": "..."},
        {"role": "user", "content": "同步所有记忆", "timestamp": "..."}
    ],
    "current_intent": "memory_sync",
    "context_variables": {
        "bridge_status": "active",
        "last_skill": "oclaw-hermes"
    }
}
```

### 使用场景
| 场景 | 示例 |
|------|------|
| 指代消解 | "**它**是什么？" → 指代前文提到的对象 |
| 意图延续 | "**继续**刚才的研究" |
| 状态保持 | "**取消**上一步操作" |
| 上下文补全 | 省略主语的简短回复 |

### 代码示例
```python
# 存储即时记忆
entry = MemoryEntry(
    layer="instant",
    content="用户请求同步记忆，当前会话ID: sess_20260411_223000",
    ttl=3600,
    metadata={"session_id": "sess_20260411_223000", "turn": 5}
)
engine.store(entry)

# 检索即时记忆
context = engine.retrieve("当前会话", layer="instant", top_k=3)
```

---

## Layer 2: Working 工作记忆

### 定义
复杂任务的推理中间状态，支持多步骤思考和计算过程的临时存储。

### 生命周期
- **TTL**: 2小时
- **触发清理**: 任务完成或超时

### 存储内容
```python
working_memory = {
    "task_id": "research_001",
    "steps": [
        {"step": 1, "status": "completed", "result": "问题分解完成"},
        {"step": 2, "status": "in_progress", "partial_result": "..."}
    ],
    "intermediate_results": {
        "sub_questions": ["...", "..."],
        "collected_data": [...],
        "partial_analysis": "..."
    }
}
```

### 使用场景
| 场景 | 示例 |
|------|------|
| 多步推理 | 研究任务的问题分解 → 信息收集 → 综合分析 |
| 中间计算 | 造价估算的中间计算结果 |
| 状态机 | 调解流程的当前阶段 |
| 临时缓存 | API调用结果缓存 |

### 代码示例
```python
# 存储工作记忆
entry = MemoryEntry(
    layer="working",
    content="研究任务进行中，已完成问题分解，正在收集信息",
    ttl=7200,
    metadata={
        "task_id": "research_001",
        "step": 2,
        "total_steps": 5
    }
)
engine.store(entry)

# 任务完成后迁移到长期记忆
if task_completed:
    engine.migrate_to_long_term(task_id)
```

---

## Layer 3: Short 短期记忆

### 定义
最近7天的会话摘要和高频访问信息，支持跨会话的上下文恢复。

### 生命周期
- **TTL**: 7天
- **触发清理**: 过期自动清理，重要内容迁移到长期记忆

### 存储内容
```python
short_memory = {
    "date": "2026-04-11",
    "sessions": [
        {
            "session_id": "sess_20260411_223000",
            "summary": "用户启动了hermes桥接，同步了记忆，进行了建设工程商事调解研究",
            "key_topics": ["hermes", "memory_sync", "construction_mediation"],
            "skills_used": ["oclaw-hermes", "cn-construction-mediation"]
        }
    ],
    "frequent_queries": ["记忆同步", "Skill调用"],
    "user_preferences": {
        "preferred_output_format": "markdown",
        "language": "zh-CN"
    }
}
```

### 使用场景
| 场景 | 示例 |
|------|------|
| 跨会话恢复 | "**昨天**我研究的那个话题" |
| 习惯学习 | 发现用户偏好Markdown格式 |
| 热点追踪 | 高频查询的主题自动提升重要性 |
| 会话预热 | 新会话开始时加载相关上下文 |

### 自动整合机制
```python
def consolidate_short_to_long():
    """将高访问短期记忆整合到长期记忆"""
    short_memories = engine.retrieve_by_layer("short")
    
    for memory in short_memories:
        if memory.access_count >= 3 or memory.importance >= 7:
            # 提取核心事实
            facts = extract_core_facts(memory.content)
            
            # 存储到长期记忆
            engine.store(MemoryEntry(
                layer="long",
                content=facts,
                importance=memory.importance
            ))
            
            # 可选：从短期记忆删除或标记
```

---

## Layer 4: Long 长期记忆

### 定义
持久化的知识和用户画像，不随时间衰减，构成用户的核心知识库。

### 生命周期
- **TTL**: 永久
- **管理策略**: 定期去重、冲突检测、版本更新

### 存储内容
```python
long_memory = {
    "user_profile": {
        "name": "王老师",
        "domain": "工程咨询",
        "expertise": ["造价", "招标", "调解", "项目管理"],
        "preferred_skills": ["cn-construction-mediation", "cn-cost-control"]
    },
    "project_contexts": {
        "current_project": {
            "name": "某综合体造价咨询",
            "phase": "招标阶段",
            "key_stakeholders": [...]
        }
    },
    "important_facts": [
        "用户关注建设工程商事调解领域",
        "用户偏好结构化输出",
        "用户经常使用大师系列Skills"
    ]
}
```

### 使用场景
| 场景 | 示例 |
|------|------|
| 用户画像 | 自动识别用户专业领域和偏好 |
| 项目跟踪 | 长期项目的持续上下文 |
| 知识积累 | 研究结果的持久化存储 |
| 个性化推荐 | 基于历史偏好推荐Skills |

### 冲突解决
```python
def resolve_memory_conflicts(new_fact, existing_facts):
    """检测和解决记忆冲突"""
    for existing in existing_facts:
        similarity = semantic_similarity(new_fact, existing)
        
        if similarity > 0.9:
            # 高度相似，更新版本
            update_memory(existing.id, new_fact)
        elif similarity > 0.7:
            # 可能冲突，标记待审核
            flag_for_review(new_fact, existing)
        else:
            # 新事实，直接存储
            store_new_fact(new_fact)
```

---

## Layer 5: Skill 技能记忆

### 定义
Skill调用的使用经验、最佳实践和参数优化记录，实现Skill的自我进化。

### 生命周期
- **TTL**: 永久
- **管理策略**: 持续累积、成功率统计、参数优化

### 存储内容
```python
skill_memory = {
    "skill_name": "cn-construction-mediation",
    "usage_stats": {
        "total_calls": 45,
        "success_rate": 0.95,
        "avg_response_time": 1200  # ms
    },
    "best_practices": [
        {
            "scenario": "工程款纠纷",
            "optimal_params": {"detail_level": "high", "include_cases": True},
            "success_indicator": 0.98
        }
    ],
    "common_patterns": [
        "用户常问调解流程",
        "用户常问调解协议模板",
        "用户常问司法确认程序"
    ],
    "improvement_suggestions": [
        "建议增加调解员选择指南",
        "建议增加调解费用计算器"
    ]
}
```

### Skill-记忆双向增强
```
┌─────────────────────────────────────────────────────────┐
│                   Skill-Memory 循环                      │
├─────────────────────────────────────────────────────────┤
│                                                         │
│   用户调用 Skill ──▶ 执行 Skill ──▶ 返回结果            │
│        │                              │                 │
│        │                              │                 │
│        │    ┌──────────────────┐     │                 │
│        └───▶│  提取使用经验    │◀────┘                 │
│             │  • 输入参数      │                         │
│             │  • 执行时长      │                         │
│             │  • 成功/失败     │                         │
│             │  • 用户反馈      │                         │
│             └────────┬─────────┘                         │
│                      │                                  │
│                      ▼                                  │
│             ┌──────────────────┐                        │
│             │  存储到Skill记忆  │                        │
│             └────────┬─────────┘                        │
│                      │                                  │
│   新请求 ◀───────────┘                                  │
│   检索相关Skill                                         │
│   基于历史成功率推荐                                    │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

### 代码示例
```python
# 自动记录Skill调用
class SkillTracker:
    def on_skill_call(self, skill_name, params, result, duration):
        entry = MemoryEntry(
            layer="skill",
            content=f"Skill调用: {skill_name}",
            metadata={
                "skill_name": skill_name,
                "params": params,
                "success": result.success,
                "duration_ms": duration
            },
            importance=7 if result.success else 5
        )
        engine.store(entry)
        
        # 更新Skill统计
        self.update_skill_stats(skill_name, result.success, duration)

# 基于记忆推荐Skill
def recommend_skills(query, context):
    # 检索相关Skill记忆
    skill_memories = engine.retrieve(query, layer="skill", top_k=5)
    
    # 按成功率排序
    ranked = sorted(
        skill_memories,
        key=lambda x: x.metadata.get("success_rate", 0),
        reverse=True
    )
    
    return [m.metadata["skill_name"] for m in ranked]
```

---

## Layer 6: Expert 专家记忆

### 定义
通过专家蒸馏提取的思维模式、决策启发式和价值观边界，形成可复用的专家视角。

### 生命周期
- **TTL**: 永久
- **管理策略**: 版本控制、持续更新、局限性声明

### 存储内容
```python
expert_memory = {
    "expert_name": "wittgenstein",
    "distilled_at": "2026-04-01",
    "version": "1.0.0",
    
    "mental_models": [
        {
            "name": "语言游戏",
            "description": "意义即用法，语言的意义在于使用",
            "application": "分析概念混淆和沟通障碍"
        },
        {
            "name": "哲学治疗",
            "description": "哲学是澄清思想的活动，不是理论构建",
            "application": "识别和消解伪问题"
        }
    ],
    
    "decision_heuristics": [
        {
            "scenario": "概念混淆",
            "heuristic": "追问具体用法，而非抽象定义",
            "example": "当有人说'公平'时，问'在什么具体情境下使用这个词'"
        }
    ],
    
    "value_boundaries": {
        "will_do": ["澄清概念", "消解伪问题", "分析语言用法"],
        "wont_do": ["构建抽象理论体系", "给出绝对真理"],
        "anti_patterns": ["过度概括", "脱离语境的定义"]
    },
    
    "honesty_boundaries": [
        "我的分析基于语言哲学视角",
        "对于超出语言分析的问题，我的视角可能不适用",
        "我的建议应与其他专业意见结合使用"
    ]
}
```

### 使用场景
| 场景 | 示例 |
|------|------|
| 专家会诊 | "用马斯克的'第一性原理'分析这个问题" |
| 视角切换 | "从巴菲特的角度评估这个投资机会" |
| 决策辅助 | "芒格会如何分析这个风险？" |
| 思维训练 | "维特根斯坦会如何看待这个争论？" |

### 专家蒸馏流程
```python
class ExpertDistiller:
    def distill(self, expert_name, sources):
        """
        六路并行采集 + 三重验证提炼 + 六层提取
        """
        # 六路采集
        data = {
            "books": self.collect_books(expert_name),
            "interviews": self.collect_interviews(expert_name),
            "social": self.collect_social(expert_name),
            "criticism": self.collect_criticism(expert_name),
            "decisions": self.collect_decisions(expert_name),
            "timeline": self.collect_timeline(expert_name)
        }
        
        # 三重验证
        validated = self.three_way_validation(data)
        
        # 六层提取
        expert_memory = {
            "expression_dna": self.extract_layer1(validated),
            "knowledge_system": self.extract_layer2(validated),
            "mental_models": self.extract_layer3(validated),
            "decision_heuristics": self.extract_layer4(validated),
            "value_boundaries": self.extract_layer5(validated),
            "honesty_boundaries": self.extract_layer6(validated)
        }
        
        # 存储到专家记忆层
        engine.store(MemoryEntry(
            layer="expert",
            content=json.dumps(expert_memory),
            metadata={"expert_name": expert_name}
        ))
```

---

## Layer 7: Graph 图记忆

### 定义
实体关系网络，以图结构存储知识，支持关联推理和复杂查询。

### 生命周期
- **TTL**: 永久
- **管理策略**: 持续扩展、关系权重更新、子图提取

### 存储结构
```python
graph_memory = {
    "entities": [
        {"id": "e1", "name": "商事调解", "type": "concept"},
        {"id": "e2", "name": "建设工程", "type": "domain"},
        {"id": "e3", "name": "商事调解条例", "type": "regulation"},
        {"id": "e4", "name": "cn-construction-mediation", "type": "skill"},
        {"id": "e5", "name": "王老师", "type": "user"}
    ],
    
    "relations": [
        {"source": "e5", "target": "e2", "type": "关注", "weight": 0.9},
        {"source": "e2", "target": "e1", "type": "包含", "weight": 0.8},
        {"source": "e1", "target": "e3", "type": "依据", "weight": 1.0},
        {"source": "e4", "target": "e1", "type": "处理", "weight": 0.95},
        {"source": "e5", "target": "e4", "type": "使用", "weight": 0.85}
    ]
}
```

### 图查询示例
```python
# 查询: "王老师关注领域的相关法规"
def query_related_regulations(user_name, depth=2):
    """
    图推理查询
    
    路径1: 王老师 → 关注 → 建设工程 → 包含 → 商事调解 → 依据 → 商事调解条例
    路径2: 王老师 → 使用 → cn-construction-mediation → 处理 → 商事调解 → 依据 → 商事调解条例
    """
    
    # 起始节点
    start = find_entity(name=user_name)
    
    # BFS遍历
    results = []
    visited = set()
    queue = [(start, 0)]
    
    while queue:
        node, d = queue.pop(0)
        
        if d > depth:
            break
            
        if node.type == "regulation":
            results.append(node)
            
        for neighbor in get_neighbors(node):
            if neighbor.id not in visited:
                visited.add(neighbor.id)
                queue.append((neighbor, d + 1))
    
    return results

# 执行查询
regulations = query_related_regulations("王老师")
# 结果: [商事调解条例, 人民调解法, 民事诉讼法...]
```

### 图可视化
```
用户关注领域知识图谱:

                    ┌─────────────┐
                    │   王老师    │
                    └──────┬──────┘
                           │
           ┌───────────────┼───────────────┐
           │               │               │
           ▼               ▼               ▼
    ┌─────────────┐ ┌─────────────┐ ┌─────────────┐
    │  建设工程   │ │   造价咨询   │ │  项目管理   │
    └──────┬──────┘ └─────────────┘ └─────────────┘
           │
     ┌─────┴─────┐
     │           │
     ▼           ▼
┌─────────┐ ┌─────────┐
│ 商事调解 │ │ 工程造价 │
└────┬────┘ └─────────┘
     │
     │ 依据
     ▼
┌─────────────┐
│ 商事调解条例 │
└─────────────┘
```

---

## 七层记忆交互

### 跨层检索
```python
def cross_layer_retrieve(query, context):
    """
    跨层联合检索，综合各层信息
    """
    results = {
        "instant": engine.retrieve(query, layer="instant", top_k=2),
        "working": engine.retrieve(query, layer="working", top_k=1),
        "short": engine.retrieve(query, layer="short", top_k=3),
        "long": engine.retrieve(query, layer="long", top_k=2),
        "skill": engine.retrieve(query, layer="skill", top_k=2),
        "expert": engine.retrieve(query, layer="expert", top_k=1),
        "graph": graph_engine.query(query, depth=2)
    }
    
    # 按相关性和重要性排序
    return merge_and_rank(results)
```

### 记忆流动
```
┌─────────────────────────────────────────────────────────────┐
│                        记忆流动方向                          │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│   Instant ──▶ (整合) ──▶ Short ──▶ (提炼) ──▶ Long         │
│      │                      │                      │        │
│      │ (重要)              │ (常用)              │ (专业)  │
│      ▼                      ▼                      ▼        │
│   Working                Skill                  Expert      │
│      │                      │                      │        │
│      └──────────────────────┴──────────────────────┘        │
│                            │                                │
│                            ▼                                │
│                          Graph                              │
│                      (实体关系网络)                          │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

---

## 性能优化

### 分层存储策略
| 层级 | 存储介质 | 索引方式 | 查询优化 |
|------|----------|----------|----------|
| Instant | 内存 | 哈希表 | O(1) |
| Working | 内存 | 哈希表 | O(1) |
| Short | SQLite | B+树 + FTS | O(log n) |
| Long | SQLite + 向量DB | HNSW | O(log n) |
| Skill | SQLite | B+树 | O(log n) |
| Expert | SQLite + 向量DB | HNSW | O(log n) |
| Graph | 图数据库 | 邻接索引 | O(1) ~ O(n) |

### 缓存策略
```python
class MemoryCache:
    def __init__(self):
        self.l1_cache = {}  # Instant + Working (内存)
        self.l2_cache = {}  # Short (LRU)
        self.l3_store = None  # Long + Skill + Expert + Graph (磁盘)
    
    def get(self, key):
        # L1 查询
        if key in self.l1_cache:
            return self.l1_cache[key]
        
        # L2 查询
        if key in self.l2_cache:
            # 提升到L1
            self.l1_cache[key] = self.l2_cache[key]
            return self.l2_cache[key]
        
        # L3 查询
        value = self.l3_store.query(key)
        self.l2_cache[key] = value
        return value
```

---

**七层记忆，构建智能的基石。** 🧠
