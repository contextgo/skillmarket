# 基金估值助手 - 使用说明

**当前版本：v2.1**（营销优化 | 2026-03-19）  
**作者：** 龙小策 🐉

---

## 🎉 v2.1 新增 - 智能盯盘监控

在 v2.0 的 Web 实时监控基础上，新增 **新闻爬取 + 技术分析 + 信号生成** 的全链路盯盘功能：

### 🚀 核心新特性

| 特性 | 说明 |
|------|------|
| **新闻爬取** | RSS + 政策公告自动抓取（新浪财经、东方财富、Gov.cn）|
| **情绪分析** | 基于关键词的新闻情感打分（-1.0 ~ +1.0） |
| **技术指标** | MA/趋势判断/均线位置，多时间维度分析 |
| **信号生成** | 5级信号（STRONG_BUY, BUY, HOLD, SELL, STRONG_SELL） |
| **操作建议** | 结合技术+情绪给出买入/卖出/持有的置信度与理由 |
| **缓存优化** | 新闻结果 15 分钟缓存，减少重复网络请求 |
| **通知推送** | 支持邮件、Webhook、WebSocket 多渠道通知 |

### 📦 新增文件

- `fund_valuation/monitor.py` - 监控引擎（新闻、技术分析、信号）
- CLI 扩展：`fund-monitor`, `fund-monitor-watch`, `fund-signals`, `fund-news`
- Web API 扩展：`/api/monitor/run`, `/api/monitor/report`, `/api/monitor/notify`
- `Dockerfile` + `docker-compose.yml` - 容器化部署
- 健康检查 API: `GET /health`
- 系统统计 API: `GET /api/stats`

---

## 🚀 快速开始

### 1. 安装依赖

**基础 CLI 模式：**
```bash
pip install akshare typer rich pandas
```

**完整功能（含 Web UI）：**
```bash
pip install -r requirements.txt
```

### 2. 配置基金

如果你已有 `data/fund_holdings.json`，直接运行 **upgrade_check.py** 自动修复：

```bash
python upgrade_check.py
```

它会：
- 自动归一化权重
- 添加 159525 配置（如果缺失）
- 补充 `last_nav`
- 检查依赖

如果要从头配置，编辑 `data/fund_holdings.json`：

```json
{
  "funds": {
    "159525": {
      "name": "红利低波ETF",
      "code": "159525",
      "holdings": [
        {"code": "601288", "name": "农业银行", "weight": 0.15},
        {"code": "601398", "name": "工商银行", "weight": 0.12}
        // ... 更多持仓
      ],
      "last_nav": 1.0850,
      "thresholds": {"low": -0.03, "high": 0.03}
    }
  }
}
```

**重要：**
- `holdings` 权重总和可以不为 1.0，系统会自动归一化（v2.0 起）
- `last_nav` 建议填写昨日净值，如果留空会尝试自动获取（可能失败）
- `thresholds` 阈值设为小数（-0.03 = -3%）

**v2.0 新功能：**
- 配置文件热重载：修改 `data/fund_holdings.json` 后，运行中的 CLI/Web 会自动重新加载
- 权重自动归一化：如果权重总和不等于 1.0，系统自动按比例调整
- 两级缓存：内存 + 文件缓存，减少重复请求
- 历史记录：每次估算结果自动保存，可后续分析

---

## 🔄 升级到 v2.0（老用户必看）

如果你之前使用 v1.0，请运行升级检查：

```bash
cd ~/.openclaw/workspace/fund-valuation-skill
python upgrade_check.py
```

该工具会：
- ✅ 自动修复权重归一化
- ✅ 补充缺失的 `last_nav`
- ✅ 添加 159525 红利低波ETF 配置（如果缺失）
- ✅ 检查依赖完整性
- ✅ 生成升级报告

升级后，**无需修改任何代码**，直接使用新命令即可。

---

## 🌐 v2.0 Web 界面完整指南

### 启动 Web 服务

```bash
# 方式一：console script（安装后）
fund-valuation-web --port 8080

# 方式二：直接运行模块
python -m fund_valuation.web --port 8080 --host 0.0.0.0

# 方式三：Docker（推荐用于生产环境）
docker-compose up -d
# 访问 http://localhost:8080
```

### v2.0 Web 四大模块

1. **监控面板（Dashboard）**
   - 实时估值展示（WebSocket 每 5 秒推送）
   - 四个统计卡片：监控基金数、上涨/下跌数量、预警触发
   - 表格显示：昨日净值、估算净值、涨跌幅、状态、阈值、主要持仓
   - 颜色标识：绿色上涨、红色下跌、黄色预警
   - 操作：查看历史图表、删除基金

2. **历史分析（History）**
   - Chart.js 折线图展示近 7 天估值走势
   - 统计指标：平均波动率、最大涨幅、最大跌幅
   - 按基金切换查看不同历史数据
   - 数据来源：`data/history/fund_*.jsonl`

3. **配置管理（Config）**
   - 表格列出所有已配置基金
   - 查看持仓数量、当前阈值
   - 删除基金配置
   - 实际的基金增改在主面板完成（添加按钮）

4. **邮件通知（Settings）**
   - SMTP 服务器配置
   - 多收件人支持（逗号分隔）
   - TLS 开关
   - 密码字段安全传输

### WebSocket 实时推送

- 连接地址：`ws://localhost:8080/ws`
- 推送频率：每 5 秒一次批量更新
- 消息格式：
```json
{
  "type": "batch_update",
  "timestamp": "2026-03-13T20:30:00",
  "data": [
    {
      "type": "fund_update",
      "fund_code": "159525",
      "fund_name": "红利低波ETF",
      "estimated_nav": 1.0923,
      "change_pct": 1.23,
      "timestamp": "20:30:00"
    }
  ]
}
```
- 自动重连：断开后 3 秒自动重连

### REST API 参考

| 端点 | 方法 | 描述 |
|------|------|------|
| `/` | GET | Web 主页 |
| `/health` | GET | 健康检查（版本、缓存、连接数）|
| `/api/stats` | GET | 系统统计 |
| `/api/funds` | GET | 基金列表 |
| `/api/funds` | POST | 新增基金 |
| `/api/funds/{code}` | GET | 单基金详情 |
| `/api/funds/{code}` | PUT | 更新配置 |
| `/api/funds/{code}` | DELETE | 删除基金 |
| `/api/funds/{code}/estimate` | POST | 手动触发估值 |
| `/api/funds/{code}/history?days=7` | GET | 历史数据 |
| `/api/email/config` | GET | 邮件配置 |
| `/api/email/config` | POST | 保存邮件配置 |
| `/ws` | WebSocket | 实时推送 |

---

## 🐳 Docker 部署

### 环境要求

- Docker 20.10+
- Docker Compose v2.0+（或使用 `docker compose`）

### 快速启动

```bash
cd /path/to/fund-valuation-skill
docker-compose up -d

# 查看日志
docker-compose logs -f fund-valuation-web

# 停止服务
docker-compose down

# 更新镜像
docker-compose pull && docker-compose up -d
```

### 自定义配置

编辑 `docker-compose.yml`：

```yaml
services:
  fund-valuation-web:
    ports:
      - "8080:8080"  # 主机:容器端口映射
    volumes:
      - /host/path/data:/app/data  # 持久化数据目录
    environment:
      - TZ=Asia/Shanghai  # 时区设置
```

### 数据持久化

- 数据文件：`./data` 目录挂载到容器 `/app/data`
- 包含：`fund_holdings.json`、`email_config.json`、`history/`、`cache/`
- **重要**：务必挂载 `./data`，否则容器重启后配置丢失

### 网络与安全

- 默认桥接网络 `fund-net`
- 仅暴露 8080 端口，其余内部通信
- 生产环境建议添加反向代理（Nginx/Traefik）和 HTTPS

---

---

## 🔍 智能盯盘监控（v2.1+）

除了估值计算，助手现在可以**自动爬取新闻、分析走势、生成交易信号**，提供更智能的决策支持。

### 功能概览

| 命令 | 功能 | 描述 |
|------|------|------|
| `fund-monitor` | 执行监控 | 分析所有配置基金的新闻+技术，生成信号报告 |
| `fund-monitor-watch` | 定时监控 | 每隔指定时间自动运行 `monitor` |
| `fund-signals` | 查看信号 | 从报告读取最新交易信号 |
| `fund-news` | 查看新闻 | 显示抓取到的相关财经新闻 |

### 监控流程

```bash
# 1. 首次运行监控（生成初始报告）
python -m fund_valuation.cli monitor

# 2. 查看信号
python -m fund_valuation.cli signals --limit 10

# 3. 查看某基金详细新闻
python -m fund_valuation.cli news 110011 --count 10

# 4. 定时监控（每30分钟一次，后台运行）
python -m fund_valuation.cli monitor-watch --interval 1800
```

### 信号说明

系统生成 5 级信号：

| 信号 | 图标 | 触发条件（示例） | 操作建议 |
|------|------|------------------|----------|
| STRONG_BUY | 🔥 | 技术强+情绪强+低位 | 重仓买入 |
| BUY | 📈 | 短期向上+情绪非负 | 小仓位买入或持有 |
| HOLD | ⏸️ | 震荡不明 | 继续持有等待 |
| SELL | 📉 | 短期向下+情绪负 | 减仓或观望 |
| STRONG_SELL | ❄️ | 连续下行+利空 | 清仓或大幅减仓 |

**信号置信度**：0~1，越高表示确定性越强

### 技术指标

监控会自动计算：

- **短期趋势**：近5个净值点相对方向（up/down/sideways）
- **中期趋势**：近20个净值点相对方向
- **MA5/MA20**：5日、20日移动平均
- **相对均线位置**：当前净值相对于 MA20 的偏差（%）

### 新闻与情绪

- **爬取来源**：RSS（新浪财经、东方财富）、Gov.cn 政策公告
- **相关性过滤**：基于基金名称和关键词（"基金"、"股市"）筛选
- **情绪分析**：基于正面/负面关键词匹配，生成 -1.0 ~ +1.0 的分数
- **缓存**：结果缓存 15 分钟，避免重复请求

### Web API

如果 Web 服务已启动，还可通过 API 调用：

```bash
# 手动触发监控
curl -X POST http://localhost:8080/api/monitor/run

# 获取报告
curl http://localhost:8080/api/monitor/report

# 获取最新信号列表
curl http://localhost:8080/api/monitor/signals?limit=5

# 获取基金新闻
curl http://localhost:8080/api/monitor/news/110011?count=10

# 发送邮件通知（配合 monitor run 使用）
curl -X POST http://localhost:8080/api/monitor/notify \
  -d '{"fund_code":"110011","channels":["email"]}'
```

### 配置选项

监控行为可通过环境变量微调（可选）：

- `FUND_NEWS_SOURCES`：自定义 RSS 源列表（JSON 格式）
- `FUND_SENTIMENT_THRESHOLD`：情绪阈值（默认 ±0.1）
- `FUND_TECH_LONG_MA`：长期均线周期（默认 20 天）
- `FUND_MONITOR_CACHE_TTL`：新闻缓存秒数（默认 900）

示例：
```bash
export FUND_NEWS_SOURCES='[
  {"type":"rss","url":"https://finance.sina.com.cn/stock/rss/","keywords":["基金","股市"]}
]'
```

---

## 📈 缓存系统详解

### CLI 命令行

```bash
# 单基金查询
python -m fund_valuation.cli --fund 110011

# 所有配置的基金
python -m fund_valuation.cli --all

# 持续观察模式（每 5 分钟刷新）
python -m fund_valuation.cli --watch --interval 300

# 设置临时阈值（覆盖配置）
python -m fund_valuation.cli --fund 110011 --threshold -0.02,0.02
```

### Web 监控面板（推荐！✨）

```bash
# 启动 Web 服务（默认端口 8080）
fund-valuation-web --port 8080
# 或：python -m fund_valuation.web --port 8080
```

然后访问：**http://localhost:8080**

**Web 功能：**
- 实时刷新估值（5秒间隔）
- 阈值预警颜色高亮（黄色⚠️/红色🚨）
- 响应式设计（手机/平板/PC 全适配）
- 在线邮件配置界面

---

## 📧 邮件通知

### 配置方式

**方式一：Web 界面配置（推荐）**
1. 启动 Web 服务
2. 进入"邮件配置"页面
3. 填写 SMTP 信息
4. 保存即可

**方式二：手动编辑**
在 Web 中首次保存后，会生成 `data/email_config.json`，可手动修改：

```json
{
  "smtp_host": "smtp.gmail.com",
  "smtp_port": 587,
  "smtp_user": "your-email@gmail.com",
  "smtp_password": "your-app-password",
  "from_email": "your-email@gmail.com",
  "to_emails": ["receiver@example.com"],
  "use_tls": true
}
```

> **注意**：Gmail 需要使用 "App Password"（应用专用密码），而非登录密码。

### 触发规则
- 当估算涨跌幅 < `thresholds.low` 或 > `thresholds.high`
- 每次估值完成后自动检查并发送
- 邮件包含当前净值、涨跌幅、阈值对比

---

## 🔧 高级配置

### 多用户/多设备部署

```bash
# 设置监听地址和端口
fund-valuation-web --host 0.0.0.0 --port 8080

# 使用 systemd 或 supervisor 管理后台运行
# 示例 systemd unit:
# [Unit]
# Description=Fund Valuation Web
# After=network.target
#
# [Service]
# User=youruser
# WorkingDirectory=/path/to/fund-valuation-skill
# ExecStart=/usr/bin/python -m fund_valuation.web --port 8080
# Restart=always
#
# [Install]
# WantedBy=multi-user.target
```

### 持仓信息自动更新

当前版本需手动更新持仓（基金季报发布后）：
1. 访问天天基金网页版获取最新持仓
2. 更新 `data/fund_holdings.json` 中的 `holdings` 和 `last_nav`
3. 重启服务（Web 热重载配置，无需重启）

---

## 📊 数据源说明

| 数据类型 | 来源 | 更新频率 |
|---------|------|---------|
| 基金最新净值 | 天天基金 | 每日收盘后 |
| 基金持仓 | 天天基金季报 | 季度更新（需手动维护） |
| 股票实时行情 | akshare（新浪/东方财富） | 秒级（API 限制） |

**估算精度**：持仓信息越新、越完整，估算越准确。建议每季度至少更新一次持仓。

---

## 💾 缓存系统 v1.0

v2.0 引入智能缓存，减少重复网络请求，提升响应速度。

### 缓存层级

1. **内存缓存（默认）**
   - TTL: 60 秒（股票价格）、300 秒（基金持仓）
   - 进程内共享，重启失效

2. **文件缓存（自动启用）**
   - 位置：`data/cache/stock/`、`data/cache/fund/`
   - Pickle 序列化存储
   - TTL: 60-600 秒（不同类型）

3. **Redis 缓存（可选）**
   - 如需跨进程共享，设置 `REDIS_URL` 环境变量
   - 自动降级：Redis 不可用则退回内存+文件

### 性能影响

- 首次查询：完整网络请求（约 1-3 秒/基金）
- 缓存命中：< 50ms
- 批量查询：并发处理，显著提速

---

## ⚠️ 合规声明

- 本工具仅为**个人估算参考**，不提供任何投资建议
- 估算净值可能与实际净值存在偏差，请以基金公司官方公布为准
- 用户需自行承担投资风险
- 请勿用于高频交易或自动化交易决策
- 使用 akshare 获取数据时，请遵守相关服务条款

---

## 🐛 故障排除

### 问题：akshare 无法获取数据
- 检查网络连接
- 尝试更换数据源（如 `akshare.stock_zh_a_spot_em()` 可能受限制）
- 考虑使用代理或备用 API

### 问题：邮件发送失败
- 检查 SMTP 配置（端口、TLS）
- Gmail 需开启 "App Password" 并关闭两步验证
- 查看日志：`logging` 默认输出到控制台

### 问题：Web 页面无法访问
- 确认端口未被占用：`lsof -i:8080`
- 防火墙/安全组是否放行端口
- 尝试 `--host 0.0.0.0` 绑定所有接口

---

## 📁 配置文件

- `data/fund_holdings.json` - 基金持仓和阈值配置
- `data/email_config.json` - 邮件通知配置（Web 保存后生成）
- `data/cache.db` - 数据缓存（SQLite，自动清理）

---

## 💰 SaaS 订阅服务（v3.0 - 多租户架构）

为了让更多用户便捷使用，我们从 v3.0 开始提供 **SaaS 订阅服务**，基于多租户架构，支持 Auth0 认证、Stripe 支付、PostgreSQL 数据隔离。

### ✨ v3.0 核心特性

- ✅ 用户注册/登录（Auth0 Universal Login）
- ✅ 多租户数据隔离（每个用户独立基金配置）
- ✅ Stripe 订阅支付（免费试用 14 天）
- ✅ 实时 WebSocket 推送（按用户隔离）
- ✅ 免费版限制 5 个基金，Basic 版 50 个，Pro 版无限制
- ✅ 邮件通知功能（Basic/Pro）
- ✅ Vercel + Railway 生产级部署就绪

### 🚀 快速启动（本地）

**前置要求：**
- PostgreSQL 15+（本地或 Docker）
- Auth0 租户（免费）
- Stripe 测试账户（可选，如需支付功能）

```bash
# 1. 安装所有依赖
pip install -r requirements.txt

# 2. 配置环境变量
cp .env.development .env
# 编辑 .env，填入 AUTH0_* 和 DATABASE_URL

# 3. 启动数据库（Docker）
docker-compose -f docker-compose.saas.yml up postgres -d

# 4. 初始化数据库 + 迁移旧数据
python migrate_to_saas.py

# 5. 启动 SaaS 服务
uvicorn fund_valuation.web_saas:app --reload --port 8080
```

访问：http://localhost:8080

### ☁️ 生产部署（Vercel + Railway）

**架构：**
- **后端 + API + Web：** Vercel Serverless Functions（FastAPI）
- **数据库：** Railway PostgreSQL
- **认证：** Auth0
- **支付：** Stripe
- **邮件：** Resend / SendGrid

**部署步骤：**

1. **Fork 本项目并 Vercel 导入**
   ```bash
   vercel --prod
   ```

2. **配置 Railway PostgreSQL**
   ```bash
   railway login
   railway init
   railway add postgres
   ```

3. **设置环境变量（Vercel Dashboard）**
   ```
   DATABASE_URL=<从 Railway 复制的 DATABASE_URL>
   AUTH0_DOMAIN=...
   AUTH0_API_AUDIENCE=...
   AUTH0_CLIENT_ID=...
   STRIPE_SECRET_KEY=...
   STRIPE_WEBHOOK_SECRET=...
   ```

4. **运行数据库迁移（在 Vercel 容器内或本地）**
   ```bash
   # 本地（连接 Railway DB）
   DATABASE_URL=<railway_url> python migrate_to_saas.py
   ```

5. **配置 Auth0 回调 URL**
   ```
   https://your-app.vercel.app/auth/callback
   ```

6. **配置 Stripe Webhook**
   - 端点：`https://your-app.vercel.app/api/stripe/webhook`
   - 事件：`checkout.session.completed`, `customer.subscription.updated`

详细部署文档：`DEPLOYMENT_SAAS.md`（待补充）

### 💵 定价策略

| 版本 | 价格 | 基金限制 | 历史数据 | 邮件通知 | API |
|------|------|----------|----------|----------|-----|
| 免费 | ¥0 | 5个 | 30天 | ❌ | ❌ |
| Basic | ¥19/月 | 50个 | 完整 | ✅ 周报 | ❌ |
| Pro | ¥79/月 | 无限制 | 完整 | ✅ 实时 | ✅ |

试用期：14天（所有付费版）

### 🔄 从 v2.x 迁移

旧版用户数据可以使用 `migrate_to_saas.py` 迁移到新数据库，所有数据将归属为 admin 用户。

```bash
# 迁移旧持仓配置
python migrate_to_saas.py
```

---

## 🙏 致谢

- [akshare](https://github.com/akfamily/akshare) - 免费开源财经数据接口
- [FastAPI](https://fastapi.tiangolo.com/) - 现代 Python Web 框架
- [Typer](https://typer.tiangolo.com/) - CLI 构建神器
- [Bootstrap](https://getbootstrap.com/) - 响应式 CSS 框架

---

## 📘 v2.0 升级指南（快速参考）

### 新命令（推荐使用）

```bash
# 查询单只
python cli_v2.py single 159525

# 查询所有
python cli_v2.py all

# 监控模式
python cli_v2.py watch --interval 600

# 查看历史
python cli_v2.py history 159525 --days 30

# 检查/升级配置
python upgrade_check.py
```

### Web 服务（v2.0 增强）

```bash
uvicorn web_v2:app --reload --port 8081
# 访问 http://localhost:8081
```

**新功能：**
- ✅ 实时状态卡片（配置热重载）
- ✅ 历史趋势图表（ECharts）
- ✅ 持仓贡献可视化
- ✅ 异常告警推送

---

**升级已完成！现在就试试 `python cli_v2.py all` 吧！** 🚀
