#!/usr/bin/env bash
# 基金估值助手 - 快速启动脚本
# 适用于 Linux/macOS，Windows 用户请使用 WSL 或手动执行命令

set -e  # 遇到错误立即退出

echo "================================"
echo "基金估值助手 - Quick Start"
echo "================================"
echo ""

# 1. 检查 Python
echo "🔍 检查 Python 环境..."
if ! command -v python3 &> /dev/null; then
    echo "❌ 未找到 python3，请先安装 Python 3.10+"
    exit 1
fi
echo "✅ Python 版本: $(python3 --version)"
echo ""

# 2. 安装依赖
echo "📦 安装依赖（可能需要几分钟）..."
pip3 install -r requirements.txt
echo "✅ 依赖安装完成"
echo ""

# 3. 检查配置文件
echo "📁 检查配置文件..."
if [ ! -f "data/fund_holdings.json" ]; then
    echo "⚠️  未找到基金配置文件，复制示例..."
    cp data/test_fund_holdings.json data/fund_holdings.json
    echo "✅ 示例配置已复制到 data/fund_holdings.json"
    echo "   请编辑该文件添加你的基金"
else
    echo "✅ 配置文件已存在"
fi
echo ""

# 4. 启动服务
echo "🚀 启动 Web 服务..."
echo "   端口: 8080"
echo "   访问: http://localhost:8080"
echo "   按 Ctrl+C 停止"
echo ""
echo "================================"
echo ""

uvicorn fund_valuation.web:app --host 0.0.0.0 --port 8080
