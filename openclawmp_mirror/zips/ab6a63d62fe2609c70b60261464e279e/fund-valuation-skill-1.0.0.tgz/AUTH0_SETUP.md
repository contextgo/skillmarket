# Auth0 快速配置指南

**时间：** 2026-03-19  
**目标：** 5 分钟完成 Auth0 应用配置

---

## 📋 步骤 1：注册并创建租户

1. 访问 https://auth0.com
2. Sign up（使用 GitHub 或邮箱）
3. 创建租户（Tenant）：`fund-valuation`（例如：fund-valuation.auth0.com）
4. 记录你的 **Domain**（后续称为 `AUTH0_DOMAIN`）

---

## 🎯 步骤 2：创建应用

在 Dashboard → **Applications** → **Create Application**

- **Name:** Fund Valuation API
- **Application Type:** Single Page Application
- **Click:** Create

等待创建完成。

---

## 🔧 步骤 3：应用设置

进入应用详情 → **Settings** 页面

### 3.1 Allowed Callback URLs
```
http://localhost:8080/auth/callback
http://localhost:8080/callback
https://fund-valuation.vercel.app/callback
https://your-custom-domain.com/callback
```

### 3.2 Allowed Logout URLs
```
http://localhost:8080
https://fund-valuation.vercel.app
https://your-custom-domain.com
```

### 3.3 Allowed Web Origins
```
http://localhost:8080
https://fund-valuation.vercel.app
https://your-custom-domain.com
```

### 3.4 Token Endpoint Authentication Method
`POST` (默认)

---

## 🌐 步骤 4：创建 API

Dashboard → **Applications** → **Create API**

- **Name:** Fund Valuation API
- **Identifier:** `https://api.fund-valuation.pro`（或你的域名）**← 记下来，AUTH0_API_AUDIENCE**
- **Signing Algorithm:** RS256

---

## 🔑 步骤 5：获取凭证

### 应用凭证（SPA 应用）
在应用 Settings 页面找到：
- **Domain:** 填入 `AUTH0_DOMAIN`
- **Client ID:** 填入 `AUTH0_CLIENT_ID`
- **Client Secret:** 填入 `AUTH0_CLIENT_SECRET`（仅在需要服务端调用时）

### API 凭证
在 API Settings 页面：
- **Audience:** 已设置为 `https://api.fund-valuation.pro`
- **Signing Secret:** 无需，我们只用公钥验证

---

## 📁 步骤 6：添加数据库连接（可选，如需自定义登录页）

Dashboard → **Authentication** → **Database** → **Create DB Connection**

- **Name:** fund-valuation-db
- **Strategy:** Username-Password-Authentication

配置：
- **Requires Username:** 关闭（支持邮箱登录）
- **Password Policy:** 默认
- **Brute-force protection:** 开启

创建后，进入连接设置：
- **Default Directory:** 选择刚创建的连接
- **Enabled Database Connections:** 勾选

---

## 🎨 步骤 7：自定义登录页（可选）

Dashboard → **Branding** → **Universal Login** → **Customize Universal Login**

- 选择 **New Experience** 或 **Classic**
- 上传 Logo（可选）
- 设置主色调：`#1890ff`（蓝色）

---

## 🧪 步骤 8：测试

1. 本地启动 FastAPI 应用：
```bash
cd fund-valuation-skill
uvicorn fund_valuation.web:app --reload --port 8080
```

2. 访问 `http://localhost:8080/auth/login`（需要实现登录端点）

3. 应该重定向到 Auth0 登录页：
   ```
   https://your-domain.auth0.com/authorize?
     audience=https://api.fund-valuation.pro&
     response_type=token&
     client_id=YOUR_CLIENT_ID&
     redirect_uri=http://localhost:8080/auth/callback
   ```

4. 登录成功后，浏览器 URL 变为：
   ```
   http://localhost:8080/auth/callback#access_token=xxx&...
   ```

5. 提取 `access_token` 并用 `curl` 测试：
```bash
curl -H "Authorization: Bearer YOUR_TOKEN" http://localhost:8080/api/funds
```

预期：返回 200 和基金列表（如果用户已注册）

---

## ⚙️ 环境变量配置

在部署环境设置：

```bash
# .env.local (Vercel / /)
AUTH0_DOMAIN=fund-valuation.auth0.com
AUTH0_API_AUDIENCE=https://api.fund-valuation.pro
AUTH0_CLIENT_ID=your_client_id_here
# Auth0 前端不需要 Client Secret（SPA 应用）

# 数据库
DATABASE_URL=postgresql://username:password@host:port/fund_valuation

# Stripe（下一步配置）
STRIPE_SECRET_KEY=sk_live_xxx
STRIPE_WEBHOOK_SECRET=whsec_xxx
```

---

## 🐛 常见问题

### Q1: Invalid signature 'Signature verification failed'
**原因：** audience 不匹配  
**解决：** 确保 `AUTH0_API_AUDIENCE` 与 API Identifier 完全一致

### Q2: Token is expired
**原因：** Access Token 有效期太短（默认 24h）  
**解决：** Dashboard → Applications → Settings →继续 \# 在"Advanced Settings" → "OAuth" 中延长 Token 有效期

### Q3: 403 forbidden ( insufficient_scope)
**原因：** Scope 不够  
**解决：** 在 API → Settings → Scopes 添加 `read:funds` `write:funds` 等（或使用默认 openid profile email）

### Q4: 用户首次登录后无法识别
**原因：** 未在数据库中自动创建用户记录  
**解决：** 在 API 端点中使用 `get_current_user_id` 依赖，它会自动创建

---

## 📚 参考链接

- [Auth0 Quickstart for API](https://auth0.com/docs/quickstart/backend/python-fastapi)
- [JWT.io Debugger](https://jwt.io/) - 调试 Token 内容
- [Auth0 Rules](https://auth0.com/docs/rules) - 自定义用户注册逻辑

---

**下一步：** 配置完成后，修改 `web.py` 集成认证中间件和 DataManager
