# ⚡ 基金估值助手 - 5分钟快速入门

> 本指南帮助你在 5 分钟内启动并运行基金估值助手。无需深度学习，Follow me!

---

## 📋 前置要求

- ✅ Python 3.10 或更高版本
- ✅ 能访问公网（用于拉取股票行情）
- ✅ 512MB 以上内存
- ⏱️ 预计耗时：5-10 分钟

---

## 🔧 Step 1: 克隆/准备代码

如果你已经克隆了仓库，跳过此步。

```bash
cd ~/projects  # 或你的工作目录
git clone <your-repo-url> fund-valuation-skill
cd fund-valuation-skill
```

---

## 📦 Step 2: 一键安装依赖

最简单的方式：使用 quickstart.sh 脚本

```bash
# macOS/Linux
./quickstart.sh

# Windows (WSL 或 Git Bash)
bash quickstart.sh
```

脚本会自动：
- ✅ 检查 Python 版本
- ✅ 安装 requirements.txt 所有依赖
- ✅ 复制示例配置
- ✅ 启动 Web 服务

**手动方式（如果脚本失败）：**
```bash
# 1. 安装依赖
pip3 install -r requirements.txt

# 2. 复制配置
cp data/test_fund_holdings.json data/fund_holdings.json
```

---

## 🎯 Step 3: 添加你的基金（可选）

示例配置已包含 3 只基金：
- `159525` 红利低波ETF
- `110011` 易方达优质精选混合
- `161725` 招商中证白酒指数

如果想添加自己的基金：

1. 打开 `data/fund_holdings.json`
2. 复制一个现有基金块，修改：
   - `fund_code` (基金代码，如 `110020`)
   - `name` (基金名称)
   - `holdings` (重仓股，从天天基金网复制)
   - `last_nav` (昨日净值，可选)
   - `thresholds` (预警阈值，如 `-0.03, 0.03`)

**如何获取基金持仓？**
1. 访问 [天天基金网](https://fund.eastmoney.com/)
2. 搜索基金代码 → 进入详情页 → "持仓" 标签
3. 复制前 10 大重仓股（股票代码、名称、占比）
4. 粘贴到 `holdings` 数组，确保权重总和 ≈ 1.0

---

## 🚀 Step 4: 启动服务

### 方式 A: Web 面板（推荐！）

```bash
# 启动 Web 界面（在项目根目录）
uvicorn fund_valuation.web:app --host 0.0.0.0 --port 8080
```

输出类似：
```
INFO:     Started server process [12345]
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8080 (Press CTRL+C to quit)
```

打开浏览器访问：**http://localhost:8080**

你会看到：
- 📊 实时估算净值
- 📈 涨跌幅百分比
- 🔔 阈值预警高亮
- 📜 历史图表（近30天）

### 方式 B: CLI 命令行

```bash
# 查看所有基金
python -m fund_valuation.cli all

# 持续观察模式（每5分钟刷新）
python -m fund_valuation.cli watch --interval 300

# 查看单只基金
python -m fund_valuation.cli single 110011
```

---

## 🔌 Step 5: 配置邮件通知（可选）

如果你想收到估值预警邮件：

1. 启动 Web 服务，访问 `http://localhost:8080`
2. 点击导航栏 "邮件设置"
3. 填写 SMTP 配置：

| 邮箱 | SMTP 服务器 | 端口 | 备注 |
|------|-------------|------|------|
| Gmail | `smtp.gmail.com` | 587 | 需开启 "App Password" |
| QQ | `smtp.qq.com` | 465 | 需授权码 |
| 163 | `smtp.163.com` | 465 | 需授权码 |

4. 填写收件人邮箱（可多个，逗号分隔）
5. 点击 "保存配置"

测试：返回首页，等待估值波动或手动修改阈值触发。

---

## 🐳 Docker 部署（高级）

如果习惯用 Docker：

```bash
# 1. 构建镜像
docker build -t fund-valuation .

# 2. 运行（持久化数据卷）
docker run -d \
  -p 8080:8080 \
  -v $(pwd)/data:/app/data \
  -v $(pwd)/logs:/app/logs \
  --name fund-valuation \
  fund-valuation

# 3. 查看日志
docker logs -f fund-valuation
```

访问 `http://localhost:8080` 即可。

---

## 🔍 验证是否成功

运行以下命令检查：

```bash
# 1. CLI 测试
python -m fund_valuation.cli --version
# 输出: 2.0.0 ✅

# 2. Web 健康检查
curl http://localhost:8080/health
# 输出: {"status":"ok","version":"2.0.0",...} ✅

# 3. 查看基金列表
curl http://localhost:8080/api/funds
# 输出: [{"fund_code":"159525",...}] ✅
```

如果都成功，恭喜你已搞定！🎉

---

## 🆘 遇到问题？

### 问题：`ModuleNotFoundError: No module named 'akshare'`
**解决：** 重新运行 `pip3 install -r requirements.txt`

### 问题：Web 页面无法访问
**解决：** 确认端口 8080 未被占用：`lsof -i:8080`，或改用其他端口：
```bash
uvicorn fund_valuation.web:app --port 8888
```

### 问题：akshare 数据获取失败
**解决：**
- 检查网络（是否需要代理）
- 某些数据源受限制，可尝试更换 akshare 版本
- 查看详细日志：`uvicorn fund_valuation.web:app --log-level debug`

### 问题：估算净值偏差大
**原因：** 持仓权重未总和 ≈ 1.0 或昨日净值未更新  
**解决：**
- 调整 holdings 权重总和接近 1.0
- 更新 `last_nav` 为最新值（天天基金网查询）

---

## 📚 下一步

- 📖 阅读完整 [SKILL.md](./SKILL.md) 了解所有功能
- 🐛 遇到 Bug？在 [水产市场 Issues](https://openclawmp.cc/asset/s-4295fec80f74a531) 提交
- ⭐ 觉得好用？给个 Star 鼓励一下！
- 💬 加入社区讨论：[Moltbook](https://www.moltbook.com)

---

**祝你投资顺利！** 🎯
