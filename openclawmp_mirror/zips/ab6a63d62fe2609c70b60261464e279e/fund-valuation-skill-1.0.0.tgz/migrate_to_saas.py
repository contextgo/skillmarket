#!/usr/bin/env python3
"""数据迁移工具：从旧版 JSON 迁移到 PostgreSQL 多租户数据库"""

import os
import sys
import json
from pathlib import Path

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

from fund_valuation.models import (
    Base, User, FundConfig, get_db, init_db,
    DataMigrator
)
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

def main():
    """执行迁移"""
    print("=" * 60)
    print("基金估值助手 SaaS 数据迁移工具")
    print("=" * 60)
    
    # 1. 初始化数据库（创建表）
    print("\n[1/4] 正在初始化数据库表...")
    try:
        init_db()
        print("✅ 数据库表创建完成")
    except Exception as e:
        print(f"❌ 数据库表创建失败: {e}")
        sys.exit(1)
    
    # 2. 创建 admin 用户
    print("\n[2/4] 检查并创建 admin 用户...")
    db_gen = get_db()
    db = next(db_gen)
    try:
        admin_email = "admin@fund-valuation.local"
        admin = db.query(User).filter(User.email == admin_email).first()
        if not admin:
            admin = User(
                email=admin_email,
                auth0_user_id=None,
                plan="pro",
            )
            db.add(admin)
            db.commit()
            db.refresh(admin)
            print(f"✅ admin 用户创建成功 (id={admin.id})")
        else:
            print(f"✅ admin 用户已存在 (id={admin.id})")
    except Exception as e:
        db.rollback()
        print(f"❌ admin 用户创建失败: {e}")
        sys.exit(1)
    
    # 3. 迁移旧数据
    print("\n[3/4] 正在迁移旧版 JSON 数据...")
    old_config_path = Path(__file__).parent / "data" / "fund_holdings.json"
    if not old_config_path.exists():
        print(f"⚠️  旧配置文件不存在: {old_config_path}")
        print("   跳过迁移（全新安装）")
    else:
        DataMigrator.migrate_from_json(str(old_config_path), admin.id)
    
    # 4. 统计输出
    print("\n[4/4] 迁移完成，统计信息：")
    fund_count = db.query(FundConfig).filter(FundConfig.user_id == admin.id).count()
    print(f"   admin 用户的基金数量: {fund_count}")
    
    if admin.auth0_user_id:
        print(f"   Auth0 ID: {admin.auth0_user_id}")
    else:
        print(f"   ⚠️  Auth0 ID 未绑定（首次登录后将自动绑定）")
    
    print("\n" + "=" * 60)
    print("迁移完成！请执行以下后续步骤：")
    print("1. 配置环境变量（.env 文件）")
    print("2. 测试 API: curl -H 'Authorization: Bearer xxx' http://localhost:8080/api/funds")
    print("3. 启动服务: uvicorn fund_valuation.web_saas:app --reload --port 8080")
    print("=" * 60)
    
    db.close()

if __name__ == "__main__":
    main()
