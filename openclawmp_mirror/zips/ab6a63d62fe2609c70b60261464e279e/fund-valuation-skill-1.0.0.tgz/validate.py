#!/usr/bin/env python3
"""基金估值助手 - 快速验证脚本"""

import sys
import json
from pathlib import Path

print("=" * 50)
print("基金估值助手 - 快速验证")
print("=" * 50)

# 1. 检查配置文件
config_path = Path("data/fund_holdings.json")
if config_path.exists():
    with open(config_path) as f:
        config = json.load(f)
    fund_count = len(config.get("funds", {}))
    print(f"✅ 配置文件存在，包含 {fund_count} 只基金")
else:
    print("❌ 配置文件缺失")
    sys.exit(1)

# 2. 检查核心模块可导入
try:
    from fund_valuation.core import estimate_fund_value
    print("✅ 核心估值模块可导入")
except Exception as e:
    print(f"❌ 核心模块导入失败: {e}")
    sys.exit(1)

# 3. 检查 Web 模块
try:
    from fund_valuation.web import create_web_app
    app = create_web_app()
    print("✅ Web 应用模块可创建")
except Exception as e:
    print(f"❌ Web 模块创建失败: {e}")
    sys.exit(1)

# 4. 健康检查（如果服务已启动）
try:
    import requests
    r = requests.get("http://127.0.0.1:8080/health", timeout=2)
    if r.status_code == 200:
        print("✅ Web 服务运行中")
    else:
        print("⚠️  Web 服务响应异常")
except:
    print("ℹ️  Web 服务未启动（正常，可手动启动）")

print("\n🎯 下一步：")
print("   uvicorn fund_valuation.web:app --reload --port 8080")
print("   然后访问 http://localhost:8080")
print("=" * 50)
