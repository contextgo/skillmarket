#!/bin/bash
# 基金估值助手 v2.0 - 一键安装脚本

set -e

cd "$(dirname "$0")"

echo "=== 基金估值助手 v2.0 依赖安装 ==="
echo ""

# 创建虚拟环境
if [ ! -d "venv" ]; then
    echo "创建 Python 虚拟环境..."
    python3 -m venv venv
fi

source venv/bin/activate

echo "升级 pip..."
pip install --upgrade pip

echo "安装依赖（使用清华镜像）..."
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple -r requirements.txt

echo ""
echo "✅ 依赖安装完成！"
echo ""
echo "下一步："
echo "1. 补充 159525 的 last_nav（昨日净值）"
echo "   编辑 data/fund_holdings.json，找到 159525 项，添加："
echo '     "last_nav": 1.0850'
echo ""
echo "2. 测试运行："
echo "   source venv/bin/activate  # 如果还没激活"
echo "   python cli_v2.py all"
echo ""
echo "3. 实时监控："
echo "   python cli_v2.py watch --interval 600"
echo ""
