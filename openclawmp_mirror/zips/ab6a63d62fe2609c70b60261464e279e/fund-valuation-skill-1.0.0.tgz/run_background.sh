#!/bin/bash
# 基金估值助手 v2.0 - 后台运行脚本
# 用法：bash run_background.sh

set -e

cd "$(dirname "$0")"

# 激活虚拟环境
source venv/bin/activate

# 输出文件（带时间戳）
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
LOG_FILE="logs/run_${TIMESTAMP}.log"
RESULT_FILE="logs/result_${TIMESTAMP}.txt"

# 确保 logs 目录存在
mkdir -p logs

echo "=== 基金估值助手 v2.0 后台运行 started at $(date) ===" | tee -a "$LOG_FILE"
echo "输出将保存到: $LOG_FILE" | tee -a "$LOG_FILE"
echo ""

# 检查 159525 的 last_nav 是否缺失
if grep -q '"159525"' data/fund_holdings.json && grep -q '"last_nav"' data/fund_holdings.json; then
    echo "✅ 159525 配置: last_nav 已设置" | tee -a "$LOG_FILE"
else
    echo "⚠️  警告: 159525 缺失 last_nav，查询可能失败！" | tee -a "$LOG_FILE"
    echo "   请编辑 data/fund_holdings.json 补充后重试。" | tee -a "$LOG_FILE"
fi

echo "开始执行批量查询（首次可能需要 60-90 秒）..." | tee -a "$LOG_FILE"
echo ""

# 执行查询（完整输出到日志）
python cli_v2.py all --sort change 2>&1 | tee -a "$LOG_FILE"

# 提取关键结果（生成简化文本）
echo "" | tee -a "$LOG_FILE"
echo "=== 关键结果摘要 ===" | tee -a "$RESULT_FILE"
echo "执行时间: $(date)" | tee -a "$RESULT_FILE"
echo "" | tee -a "$RESULT_FILE"

# 从日志中提取表格部分（最后 20 行通常包含结果表）
tail -n 30 "$LOG_FILE" | grep -E '│|代码|名称|净值|涨跌幅' | head -n 10 >> "$RESULT_FILE" 2>/dev/null || true

echo "" | tee -a "$RESULT_FILE"
echo "完整日志: $LOG_FILE" | tee -a "$RESULT_FILE"
echo "摘要文件: $RESULT_FILE" | tee -a "$RESULT_FILE"
echo ""
echo "✅ 执行完成！" | tee -a "$LOG_FILE"
echo "查看结果：cat $RESULT_FILE"
echo "查看完整日志：tail -f $LOG_FILE"
