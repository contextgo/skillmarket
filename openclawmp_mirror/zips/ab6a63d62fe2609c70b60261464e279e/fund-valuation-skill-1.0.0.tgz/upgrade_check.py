#!/usr/bin/env python3
"""
基金估值助手 - 问题诊断与自动升级工具 v2.0

运行：python upgrade_check.py
功能：
1. 扫描现有配置，发现常见问题
2. 自动修复已知 bug（权重归一化、last_nav 缺失等）
3. 添加缺失的持仓配置（如 159525）
4. 生成升级报告
"""

import json
import sys
from pathlib import Path
from datetime import datetime
from typing import Dict

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent))

def load_config(path: str = "data/fund_holdings.json") -> Dict:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def save_config(config: Dict, path: str = "data/fund_holdings.json"):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

def check_and_fix():
    print("🔍 基金估值助手 - 问题诊断与升级 v2.0")
    print("=" * 50)
    
    config_path = "data/fund_holdings.json"
    if not Path(config_path).exists():
        print(f"❌ 配置文件不存在: {config_path}")
        return
    
    config = load_config(config_path)
    funds = config.get('funds', {})
    
    issues = []
    fixes = []
    
    # 1. 检查每个基金配置
    for code, fund in list(funds.items()):
        print(f"\n📊 检查基金 {code} - {fund.get('name')}")
        
        # 问题1: 缺失 last_nav
        if 'last_nav' not in fund or not fund['last_nav']:
            issues.append(f"{code}: 缺失 last_nav（昨日净值）")
            fixes.append(f"  建议：从天天基金查询 {code} 的昨日净值并填入")
        
        # 问题2: 持仓权重检查
        holdings = fund.get('holdings', [])
        if holdings:
            total_weight = sum(h.get('weight', 0) for h in holdings)
            if abs(total_weight - 1.0) > 0.05:  # 偏差超过5%
                issues.append(f"{code}: 持仓权重总和 {total_weight:.3f} ≠ 1.0")
                
                # 自动归一化
                print(f"  ⚠️  权重总和不等于1，自动归一化...")
                for h in holdings:
                    if total_weight > 0:
                        h['weight'] = h.get('weight', 0) / total_weight
                fund['holdings'] = holdings
                funds[code] = fund
                fixes.append(f"  ✅ {code}: 权重已归一化（原总和 {total_weight:.3f}）")
        else:
            issues.append(f"{code}: 无持仓配置")
        
        # 问题3: 阈值缺失或格式错误
        thresholds = fund.get('thresholds', {})
        if 'low' not in thresholds:
            thresholds['low'] = -0.03
            issues.append(f"{code}: 缺失低阈值，已默认 -3%")
        if 'high' not in thresholds:
            thresholds['high'] = 0.03
            issues.append(f"{code}: 缺失高阈值，已默认 +3%")
        fund['thresholds'] = thresholds
        
        print(f"  ✅ 检查完成：{len(holdings)} 只持仓，阈值 ±{thresholds['high']*100:.1f}%")
    
    # 2. 检查是否需要添加 159525
    if "159525" not in funds:
        issues.append("缺少 159525 红利低波ETF 配置")
        print("\n➕ 自动添加 159525 红利低波ETF 配置...")
        
        # 添加简化配置（前12大权重股）
        funds["159525"] = {
            "name": "红利低波ETF",
            "code": "159525",
            "holdings": [
                {"code": "601288", "name": "农业银行", "weight": 0.15},
                {"code": "601398", "name": "工商银行", "weight": 0.12},
                {"code": "601988", "name": "中国银行", "weight": 0.10},
                {"code": "601939", "name": "建设银行", "weight": 0.10},
                {"code": "601328", "name": "交通银行", "weight": 0.08},
                {"code": "601166", "name": "兴业银行", "weight": 0.08},
                {"code": "600000", "name": "浦发银行", "weight": 0.07},
                {"code": "600036", "name": "招商银行", "weight": 0.07},
                {"code": "000002", "name": "万科A", "weight": 0.08},
                {"code": "601088", "name": "中国神华", "weight": 0.07},
                {"code": "600900", "name": "长江电力", "weight": 0.05},
                {"code": "600519", "name": "贵州茅台", "weight": 0.03}
            ],
            "thresholds": {"low": -0.03, "high": 0.03},
            "notes": "红利低波ETF（159525），跟踪中证红利低波动指数。权重为简化估算。"
        }
        # 自动归一化（保险起见）
        total = sum(h['weight'] for h in funds["159525"]['holdings'])
        if abs(total - 1.0) > 0.01:
            for h in funds["159525"]['holdings']:
                h['weight'] /= total
        fixes.append("  ✅ 已添加 159525 配置（12只持仓，权重归一化）")
    
    # 3. 检查依赖
    try:
        import akshare
        print("\n📦 依赖检查: akshare 已安装")
    except ImportError:
        issues.append("akshare 未安装，请运行: pip install akshare")
        print("  ❌ akshare 未安装")
    
    # 4. 保存修复后的配置
    config['funds'] = funds
    save_config(config)
    
    # 5. 生成报告
    print("\n" + "=" * 50)
    print("📋 诊断报告")
    print("=" * 50)
    
    if issues:
        print(f"发现 {len(issues)} 个问题：")
        for i, issue in enumerate(issues, 1):
            print(f"  {i}. {issue}")
    else:
        print("✅ 未发现明显问题")
    
    if fixes:
        print(f"\n🛠️  已自动修复 {len(fixes)} 项：")
        for fix in fixes:
            print(fix)
    
    print(f"\n📁 配置文件已更新: {config_path}")
    print("\n🚀 下一步：")
    print("  1. 安装依赖: pip install -r requirements.txt")
    print("  2. 运行测试: python -m fund_valuation.cli --fund 159525")
    print("  3. 或启动 Web: uvicorn web:app --reload --port 8081")
    print("\n✨ 新功能：配置热重载已启用，修改配置文件后无需重启 CLI")

if __name__ == "__main__":
    check_and_fix()
