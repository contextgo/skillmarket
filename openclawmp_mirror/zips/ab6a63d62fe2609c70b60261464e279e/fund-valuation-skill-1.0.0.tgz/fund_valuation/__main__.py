"""基金估值助手 - 主入口"""

from .cli import app

if __name__ == "__main__":
    app()