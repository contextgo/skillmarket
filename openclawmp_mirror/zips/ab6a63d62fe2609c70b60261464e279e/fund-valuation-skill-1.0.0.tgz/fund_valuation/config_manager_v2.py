"""
配置管理器 v2.0 - 支持热重载和文件监听

自动监视 fund_holdings.json 变化，无需重启服务
"""

import json
import logging
from pathlib import Path
from typing import Dict, Any, Optional
from datetime import datetime
import time

logger = logging.getLogger(__name__)

class ConfigManager:
    """配置管理器（热重载 + 文件监听）"""
    
    def __init__(self, config_path: str = "data/fund_holdings.json"):
        self.config_path = Path(config_path)
        self._config: Dict = {}
        self._last_modified = 0
        self._observers = []  # 回调函数列表
        self._load_initial()
    
    def _load_initial(self):
        """首次加载"""
        if self.config_path.exists():
            self._config = self._read_config()
            self._last_modified = self.config_path.stat().st_mtime
        else:
            self._config = {"funds": {}}
            logger.warning(f"配置文件不存在: {self.config_path}")
    
    def _read_config(self) -> Dict:
        """读取配置文件"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            logger.error(f"读取配置失败: {e}")
            return {"funds": {}}
    
    def get_config(self, fund_code: Optional[str] = None) -> Dict:
        """
        获取配置（自动热重载）
        
        如果文件已修改，自动重新加载
        """
        if self.config_path.exists():
            current_mtime = self.config_path.stat().st_mtime
            if current_mtime > self._last_modified:
                logger.info(f"检测到配置文件变更，重新加载 ({datetime.now().strftime('%H:%M:%S')})")
                old_config = self._config
                self._config = self._read_config()
                self._last_modified = current_mtime
                self._notify_observers(old_config, self._config)
        
        if fund_code:
            return self._config.get('funds', {}).get(fund_code, {})
        return self._config
    
    def reload(self):
        """强制重载"""
        self._last_modified = 0  # 强制检测
        self.get_config()
    
    def add_observer(self, callback):
        """添加配置变更观察者"""
        self._observers.append(callback)
    
    def _notify_observers(self, old_config: Dict, new_config: Dict):
        """通知所有观察者"""
        for callback in self._observers:
            try:
                callback(old_config, new_config)
            except Exception as e:
                logger.error(f"配置观察者回调失败: {e}")

    def set_fund_config(self, fund_code: str, fund_config: Dict):
        """动态更新单只基金配置（不写文件，仅内存）"""
        if 'funds' not in self._config:
            self._config['funds'] = {}
        self._config['funds'][fund_code] = fund_config
        logger.info(f"内存中更新基金 {fund_code} 配置")

    def save_to_file(self, path: Optional[str] = None):
        """将当前内存配置保存到文件"""
        target = Path(path or self.config_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        with open(target, 'w', encoding='utf-8') as f:
            json.dump(self._config, f, ensure_ascii=False, indent=2)
        logger.info(f"配置已保存: {target}")
