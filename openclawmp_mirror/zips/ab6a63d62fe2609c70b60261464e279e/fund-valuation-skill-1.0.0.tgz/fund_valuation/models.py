"""数据库模型和数据管理（PostgreSQL + SQLAlchemy）"""

import os
from datetime import datetime
from typing import Optional, Dict, List, Any
from sqlalchemy import (
    Column, Integer, String, Boolean, DateTime, JSON, ForeignKey, Enum as SQLAEnum
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from sqlalchemy import create_engine
import enum

# 数据库连接
DATABASE_URL = os.getenv("DATABASE_URL", "postgresql://postgres:postgres@localhost/fund_valuation")

Base = declarative_base()


class UserPlan(enum.Enum):
    """用户订阅计划"""
    FREE = "free"
    BASIC = "basic"
    PRO = "pro"


class SubscriptionStatus(enum.Enum):
    """订阅状态"""
    ACTIVE = "active"
    CANCELED = "canceled"
    PAST_DUE = "past_due"
    INCOMPLETE = "incomplete"
    TRIALING = "trialing"


class User(Base):
    """用户表"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=True)  # Auth0 用户可为空
    auth0_user_id = Column(String, unique=True, nullable=True)  # Auth0 ID
    plan_type = Column(SQLAEnum(UserPlan), default=UserPlan.FREE, nullable=False)
    stripe_customer_id = Column(String, unique=True, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关系
    fund_configs = relationship("FundConfig", back_populates="owner", cascade="all, delete-orphan")
    subscriptions = relationship("Subscription", back_populates="user", cascade="all, delete-orphan")
    email_configs = relationship("EmailConfig", back_populates="user", cascade="all, delete-orphan")


class Subscription(Base):
    """订阅表"""
    __tablename__ = "subscriptions"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    stripe_subscription_id = Column(String, unique=True, nullable=False)
    status = Column(SQLAEnum(SubscriptionStatus), default=SubscriptionStatus.ACTIVE, nullable=False)
    price_id = Column(String, nullable=False)  # Stripe Price ID
    current_period_end = Column(DateTime, nullable=False)  # 续费截止
    cancel_at_period_end = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)

    # 关系
    user = relationship("User", back_populates="subscriptions")


class FundConfig(Base):
    """基金配置表（多租户）"""
    __tablename__ = "fund_configs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    fund_code = Column(String, index=True, nullable=False)  # 基金代码
    name = Column(String, nullable=False)  # 基金名称
    holdings = Column(JSON, default=list)  # 持仓列表：[{"code": "000001", "name": "...", "weight": 0.5}]
    last_nav = Column(Integer, nullable=True)  # 最新净值（放大10000倍存储）
    thresholds = Column(JSON, default=dict)  # 阈值：{"high": 1.05, "low": 0.95}
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 复合索引：user_id + fund_code 唯一
    __table_args__ = (
        # 确保每个用户的基金代码唯一
        # SQLAlchemy 会在 migrate 时自动创建唯一约束
        {},
    )

    # 关系
    owner = relationship("User", back_populates="fund_configs")


class EmailConfig(Base):
    """邮件配置表（Pro 用户专属）"""
    __tablename__ = "email_configs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    smtp_host = Column(String, nullable=False)
    smtp_port = Column(Integer, default=587)
    smtp_user = Column(String, nullable=False)
    smtp_password = Column(String, nullable=False)  # 加密存储
    from_email = Column(String, nullable=False)
    to_emails = Column(JSON, default=list)  # 收件人列表
    enabled = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # 关系
    user = relationship("User", back_populates="email_configs")


# 引擎和会话
engine = create_engine(DATABASE_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)


def init_db():
    """初始化数据库（创建所有表）"""
    Base.metadata.create_all(bind=engine)


def get_db():
    """获取数据库会话（依赖注入用）"""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# 数据迁移工具
class DataMigrator:
    """从旧版 JSON 文件迁移到数据库"""

    @staticmethod
    def migrate_from_json(json_path: str, admin_user_id: int = 1):
        """
        从旧版 fund_holdings.json 迁移数据

        Args:
            json_path: 旧配置文件路径
            admin_user_id: 管理员用户ID（所有旧数据归属该用户）
        """
        import json

        db = SessionLocal()
        try:
            with open(json_path, 'r', encoding='utf-8') as f:
                old_data = json.load(f)

            funds = old_data.get("funds", {})
            for fund_code, config in funds.items():
                # 检查是否已存在
                existing = db.query(FundConfig).filter(
                    FundConfig.user_id == admin_user_id,
                    FundConfig.fund_code == fund_code
                ).first()
                if existing:
                    continue

                fund = FundConfig(
                    user_id=admin_user_id,
                    fund_code=fund_code,
                    name=config.get("name", ""),
                    holdings=config.get("holdings", []),
                    last_nav=config.get("last_nav"),
                    thresholds=config.get("thresholds", {}),
                    is_active=config.get("is_active", True),
                )
                db.add(fund)

            db.commit()
            print(f"[MIGRATE] 成功迁移 {len(funds)} 个基金配置到用户 {admin_user_id}")
        except Exception as e:
            db.rollback()
            print(f"[MIGRATE] 失败: {e}")
            raise
        finally:
            db.close()


if __name__ == "__main__":
    # 测试：初始化数据库
    print("正在创建数据库表...")
    init_db()
    print("✓ 数据库初始化完成")
