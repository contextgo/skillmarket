"""配置管理模块"""

import json
import os
from pathlib import Path
from typing import Dict, List, Any

DATA_DIR = Path(__file__).parent.parent / "data"
CONFIG_FILE = DATA_DIR / "fund_holdings.json"


class ConfigManager:
    """管理基金配置和持仓数据"""

    def __init__(self, config_path: str = None):
        self.config_path = Path(config_path) if config_path else CONFIG_FILE
        self.data_dir = self.config_path.parent
        self.data_dir.mkdir(exist_ok=True)
        self._config = self._load()

    def _load(self) -> Dict[str, Any]:
        """加载配置文件"""
        if self.config_path.exists():
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {"funds": {}}

    def save(self):
        """保存配置到文件"""
        with open(self.config_path, 'w', encoding='utf-8') as f:
            json.dump(self._config, f, ensure_ascii=False, indent=2)

    def get_fund(self, fund_code: str) -> Dict[str, Any]:
        """获取单个基金配置"""
        return self._config["funds"].get(fund_code)

    def list_funds(self) -> List[str]:
        """列出所有基金代码"""
        return list(self._config["funds"].keys())

    def add_or_update_fund(self, fund_code: str, **kwargs):
        """添加或更新基金配置"""
        if "funds" not in self._config:
            self._config["funds"] = {}
        self._config["funds"][fund_code] = kwargs
        self.save()

    def remove_fund(self, fund_code: str):
        """移除基金"""
        if fund_code in self._config["funds"]:
            del self._config["funds"][fund_code]
            self.save()

    @property
    def all_funds(self) -> Dict[str, Dict[str, Any]]:
        """获取所有基金配置"""
        return self._config.get("funds", {})


# 全局配置管理器实例
_config_mgr = None


def get_config_manager() -> ConfigManager:
    """获取全局配置管理器实例"""
    global _config_mgr
    if _config_mgr is None:
        _config_mgr = ConfigManager()
    return _config_mgr