"""邮件通知模块"""

import os
import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import List, Optional
from pydantic import BaseModel, EmailStr

logger = logging.getLogger(__name__)


class EmailConfig(BaseModel):
    """邮件配置"""
    smtp_host: str
    smtp_port: int
    smtp_user: str
    smtp_password: str
    from_email: EmailStr
    to_emails: List[EmailStr]
    use_tls: bool = True
    subject_prefix: str = "[基金估值助手]"


class EmailNotifier:
    """邮件通知器"""

    def __init__(self, config: EmailConfig):
        self.config = config

    def send(self, subject: str, body: str, html: bool = False) -> bool:
        """发送邮件"""
        try:
            msg = MIMEMultipart('alternative' if html else 'related')
            msg['From'] = self.config.from_email
            msg['To'] = ', '.join(self.config.to_emails)
            msg['Subject'] = f"{self.config.subject_prefix} {subject}"

            if html:
                msg.attach(MIMEText(body, 'html', 'utf-8'))
            else:
                msg.attach(MIMEText(body, 'plain', 'utf-8'))

            with smtplib.SMTP(self.config.smtp_host, self.config.smtp_port) as server:
                if self.config.use_tls:
                    server.starttls()
                server.login(self.config.smtp_user, self.config.smtp_password)
                server.send_message(msg)

            logger.info(f"邮件发送成功: {subject}")
            return True

        except Exception as e:
            logger.error(f"邮件发送失败: {e}")
            return False


def format_fund_alert_email(fund_code: str, fund_config: dict, result: dict, change_pct: float) -> str:
    """格式化基金预警邮件内容（HTML）"""
    fund_name = fund_config.get('name', fund_code)
    last_nav = result.get('last_nav', 0)
    estimated_nav = result.get('estimated_nav', 0)
    thresholds = fund_config.get('thresholds', {})
    low_thr = thresholds.get('low', -0.03)
    high_thr = thresholds.get('high', 0.03)

    direction = "📈 上涨" if change_pct > 0 else "📉 下跌"
    status_text = "超过阈值" if change_pct > high_thr else "低于阈值"

    html = f"""
    <html>
    <body style="font-family: Arial, sans-serif; background: #f5f5f5; padding: 20px;">
      <div style="max-width: 600px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px;">
        <h2 style="color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px;">
          🐟 基金估值预警
        </h2>
        <p style="color: #666;">检测到基金估值超出设定阈值，请注意：</p>

        <div style="background: #f8f9fa; padding: 15px; border-radius: 4px; margin: 15px 0;">
          <h3 style="margin: 0 0 10px 0; color: #495057;">
            {fund_name} ({fund_code})
          </h3>
          <table style="width: 100%; border-collapse: collapse;">
            <tr>
              <td style="padding: 8px; border: 1px solid #dee2e6;">昨日净值</td>
              <td style="padding: 8px; border: 1px solid #dee2e6; text-align: right;">{last_nav:.4f}</td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #dee2e6;">估算净值</td>
              <td style="padding: 8px; border: 1px solid #dee2e6; text-align: right; font-weight: bold; color: {'green' if change_pct > 0 else 'red'};">
                {estimated_nav:.4f} ({change_pct:+.2f}%)
              </td>
            </tr>
            <tr>
              <td style="padding: 8px; border: 1px solid #dee2e6;">预警阈值</td>
              <td style="padding: 8px; border: 1px solid #dee2e6; text-align: right;">
                {low_thr:.1%} ~ {high_thr:.1%}
              </td>
            </tr>
            <tr style="background: #fff3cd;">
              <td style="padding: 8px; border: 1px solid #ffeaa7; font-weight: bold; color: #856404;">
                状态
              </td>
              <td style="padding: 8px; border: 1px solid #ffeaa7; text-align: right; font-weight: bold; color: #856404;">
                {direction} - {status_text}
              </td>
            </tr>
          </table>
        </div>

        <p style="color: #6c7578; font-size: 12px;">
          更新时间：{result.get('timestamp', '未知')}<br>
          本邮件由基金估值助手自动发送，请根据实际情况做出投资决策。
        </p>
      </div>
    </body>
    </html>
    """
    return html