"""
数据源模块 v2.0 - 增强容错和缓存

改进：
- 多级缓存（内存 + 文件）
- 数据源降级策略
- 异步支持（预留）
"""

import logging
import time
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from pathlib import Path
import pickle
import akshare as ak
import pandas as pd

logger = logging.getLogger(__name__)

class CacheManager:
    """两级缓存：内存 + 文件（支持TTL）"""
    
    def __init__(self, cache_dir: str = "data/cache", ttl_seconds: int = 300):
        self.cache_dir = Path(cache_dir)
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl = ttl_seconds
        self._memory_cache = {}  # key -> (data, timestamp)
    
    def get(self, key: str):
        """获取缓存数据"""
        # 先查内存
        if key in self._memory_cache:
            data, ts = self._memory_cache[key]
            if time.time() - ts < self.ttl:
                return data
            else:
                del self._memory_cache[key]
        
        # 查文件缓存
        cache_file = self.cache_dir / f"{key}.pkl"
        if cache_file.exists():
            try:
                with open(cache_file, 'rb') as f:
                    data, ts = pickle.load(f)
                if time.time() - ts < self.ttl:
                    # 回填内存
                    self._memory_cache[key] = (data, ts)
                    return data
                else:
                    cache_file.unlink(missing_ok=True)
            except Exception as e:
                logger.warning(f"读取缓存失败 {key}: {e}")
        
        return None
    
    def set(self, key: str, data):
        """设置缓存"""
        ts = time.time()
        self._memory_cache[key] = (data, ts)
        cache_file = self.cache_dir / f"{key}.pkl"
        try:
            with open(cache_file, 'wb') as f:
                pickle.dump((data, ts), f)
        except Exception as e:
            logger.warning(f"写入缓存失败 {key}: {e}")


class EnhancedStockDataSource:
    """增强股票数据源 - 多源容错"""
    
    def __init__(self, cache_ttl: int = 60):
        self.cache = CacheManager(cache_dir="data/cache/stock", ttl_seconds=cache_ttl)
    
    def get_stock_realtime(self, stock_codes: List[str]) -> Dict[str, Dict]:
        """批量获取股票实时行情（带缓存和容错）"""
        results = {}
        
        # 先尝试从缓存批量获取
        missing_codes = []
        for code in stock_codes:
            cached = self.cache.get(f"stock:{code}")
            if cached:
                results[code] = cached
            else:
                missing_codes.append(code)
        
        if not missing_codes:
            return results
        
        logger.info(f"缓存未命中，需实时获取 {len(missing_codes)} 只股票")
        
        # 单只获取（避免全市场接口超时）
        for code in missing_codes:
            try:
                data = self._fetch_single_stock(code)
                if data:
                    results[code] = data
                    self.cache.set(f"stock:{code}", data)
                else:
                    results[code] = None
            except Exception as e:
                logger.warning(f"获取 {code} 失败: {e}")
                results[code] = None
        
        return results
    
    def _fetch_single_stock(self, stock_code: str) -> Optional[Dict]:
        """获取单只股票行情（尝试多个接口）"""
        # 尝试 1: 沪深京A股实时行情（akshare）
        try:
            df = ak.stock_zh_a_spot_em()
            row = df[df['代码'] == stock_code]
            if not row.empty:
                r = row.iloc[0]
                return {
                    'price': float(r['最新价']),
                    'prev_close': float(r['昨收']),
                    'change_pct': float(r['涨跌幅']),
                    'name': r['名称']
                }
        except Exception as e:
            logger.debug(f"ak.stock_zh_a_spot_em 获取 {stock_code} 失败: {e}")
        
        # 尝试 2: 个股当日分时（akshare 备选）
        try:
            df = ak.stock_zh_a_hist(symbol=stock_code, period="daily", start_date=(datetime.now()-timedelta(days=1)).strftime("%Y%m%d"))
            if not df.empty:
                latest = df.iloc[-1]
                change = (latest['收盘'] - latest['开盘']) / latest['开盘'] * 100
                return {
                    'price': float(latest['收盘']),
                    'prev_close': float(latest['开盘']),
                    'change_pct': round(change, 2),
                    'name': stock_code  # 无名称
                }
        except Exception as e:
            logger.debug(f"ak.stock_zh_a_hist 获取 {stock_code} 失败: {e}")
        
        # 失败
        return None


class EnhancedFundDataSource:
    """增强基金数据源"""
    
    def __init__(self):
        self.stock_ds = EnhancedStockDataSource()
        self.cache = CacheManager(cache_dir="data/cache/fund", ttl_seconds=600)  # 10分钟
    
    def get_fund_holdings(self, fund_code: str) -> List[Dict]:
        """获取基金持仓（带缓存）"""
        cache_key = f"holdings:{fund_code}"
        cached = self.cache.get(cache_key)
        if cached:
            logger.info(f"使用缓存持仓数据 {fund_code}")
            return cached
        
        try:
            # 从天天基金获取持仓
            df = ak.fund_hold_em(symbol=fund_code)
            holdings = []
            for _, row in df.iterrows():
                holdings.append({
                    'code': str(row['股票代码']),
                    'name': str(row['股票名称']),
                    'weight': float(row['持仓占比'].rstrip('%')) / 100.0
                })
            
            # 缓存
            self.cache.set(cache_key, holdings)
            return holdings
        except Exception as e:
            logger.error(f"获取基金 {fund_code} 持仓失败: {e}")
            raise
    
    def get_fund_nav(self, fund_code: str, date: str = None) -> Optional[float]:
        """获取基金最新净值"""
        cache_key = f"nav:{fund_code}:{date or 'latest'}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            return cached
        
        try:
            df = ak.fund_open_fund_info_em(symbol=fund_code)
            df = df.sort_values('净值日期', ascending=False)
            latest = df.iloc[0]
            nav = float(latest['单位净值'])
            
            # 缓存
            self.cache.set(cache_key, nav)
            return nav
        except Exception as e:
            logger.warning(f"获取基金 {fund_code} 净值失败: {e}")
            return None
    
    def get_stock_changes(self, stock_codes: List[str]) -> Dict[str, float]:
        """获取股票涨跌幅（批量）"""
        quotes = self.stock_ds.get_stock_realtime(stock_codes)
        changes = {}
        for code, data in quotes.items():
            if data:
                changes[code] = data['change_pct'] / 100.0
            else:
                changes[code] = 0.0  # 缺失数据视为0
        return changes
