"""多租户数据管理器"""

import os
from typing import Optional, Dict, List, Any
from datetime import datetime
from sqlalchemy.orm import Session
from .models import (
    Base, User, FundConfig, EmailConfig, Subscription,
    UserPlan, get_db, DataMigrator
)


class DataManager:
    """数据访问层（多租户）"""

    def __init__(self, db: Session = None):
        """初始化数据管理器
        
        Args:
            db: SQLAlchemy Session，如果为 None 则自动创建
        """
        self._db = db
        self._own_session = db is None

        if self._own_session:
            self._db = next(get_db())

    def __del__(self):
        """清理会话"""
        if self._own_session and self._db:
            self._db.close()

    # ---------- 用户管理 ----------
    def create_user(self, email: str, auth0_user_id: Optional[str] = None,
                    plan: UserPlan = UserPlan.FREE,
                    stripe_customer_id: Optional[str] = None) -> User:
        """创建用户"""
        user = User(
            email=email,
            auth0_user_id=auth0_user_id,
            plan_type=plan,
            stripe_customer_id=stripe_customer_id,
        )
        self._db.add(user)
        self._db.commit()
        self._db.refresh(user)
        return user

    def get_user_by_email(self, email: str) -> Optional[User]:
        """通过邮箱获取用户"""
        return self._db.query(User).filter(User.email == email).first()

    def get_user_by_auth0_id(self, auth0_id: str) -> Optional[User]:
        """通过 Auth0 ID 获取用户"""
        return self._db.query(User).filter(User.auth0_user_id == auth0_id).first()

    def get_user_by_id(self, user_id: int) -> Optional[User]:
        """通过 ID 获取用户"""
        return self._db.query(User).filter(User.id == user_id).first()

    def upgrade_user_plan(self, user_id: int, plan: UserPlan) -> bool:
        """升级用户计划"""
        user = self.get_user_by_id(user_id)
        if not user:
            return False
        user.plan_type = plan
        user.updated_at = datetime.utcnow()
        self._db.commit()
        return True

    # ---------- 基金配置 ----------
    def list_funds(self, user_id: int) -> List[FundConfig]:
        """列出用户的所有基金"""
        return self._db.query(FundConfig).filter(
            FundConfig.user_id == user_id,
            FundConfig.is_active == True
        ).all()

    def get_fund(self, user_id: int, fund_code: str) -> Optional[FundConfig]:
        """获取单个基金配置"""
        return self._db.query(FundConfig).filter(
            FundConfig.user_id == user_id,
            FundConfig.fund_code == fund_code,
            FundConfig.is_active == True
        ).first()

    def add_fund(self, user_id: int, fund_code: str, name: str,
                 holdings: List[dict] = None, last_nav: Optional[int] = None,
                 thresholds: Optional[dict] = None) -> FundConfig:
        """添加基金配置"""
        # 检查用户配额
        user = self.get_user_by_id(user_id)
        if not user:
            raise ValueError(f"用户 {user_id} 不存在")

        if user.plan_type == UserPlan.FREE:
            count = self._db.query(FundConfig).filter(
                FundConfig.user_id == user_id,
                FundConfig.is_active == True
            ).count()
            if count >= 5:
                raise PermissionError("免费版最多支持5个基金，请升级")

        fund = FundConfig(
            user_id=user_id,
            fund_code=fund_code,
            name=name,
            holdings=holdings or [],
            last_nav=last_nav,
            thresholds=thresholds or {},
            is_active=True,
        )
        self._db.add(fund)
        self._db.commit()
        self._db.refresh(fund)
        return fund

    def update_fund(self, user_id: int, fund_code: str, **kwargs) -> Optional[FundConfig]:
        """更新基金配置"""
        fund = self.get_fund(user_id, fund_code)
        if not fund:
            return None

        for key, value in kwargs.items():
            if hasattr(fund, key):
                setattr(fund, key, value)
        fund.updated_at = datetime.utcnow()
        self._db.commit()
        self._db.refresh(fund)
        return fund

    def remove_fund(self, user_id: int, fund_code: str) -> bool:
        """删除基金（软删除）"""
        fund = self.get_fund(user_id, fund_code)
        if not fund:
            return False
        fund.is_active = False
        self._db.commit()
        return True

    def get_fund_count(self, user_id: int) -> int:
        """获取用户有效基金数量"""
        return self._db.query(FundConfig).filter(
            FundConfig.user_id == user_id,
            FundConfig.is_active == True
        ).count()

    # ---------- 邮件配置 ----------
    def get_email_config(self, user_id: int) -> Optional[EmailConfig]:
        """获取用户邮件配置"""
        return self._db.query(EmailConfig).filter(
            EmailConfig.user_id == user_id,
            EmailConfig.enabled == True
        ).first()

    def save_email_config(self, user_id: int, smtp_host: str, smtp_port: int,
                          smtp_user: str, smtp_password: str, from_email: str,
                          to_emails: List[str]) -> EmailConfig:
        """保存邮件配置"""
        # 检查用户计划（Pro 专属）
        user = self.get_user_by_id(user_id)
        if user and user.plan_type not in (UserPlan.BASIC, UserPlan.PRO):
            raise PermissionError("邮件功能需要 Basic 或 Pro 订阅")

        # 删除旧配置
        old = self._db.query(EmailConfig).filter(EmailConfig.user_id == user_id).first()
        if old:
            self._db.delete(old)

        config = EmailConfig(
            user_id=user_id,
            smtp_host=smtp_host,
            smtp_port=smtp_port,
            smtp_user=smtp_user,
            smtp_password=smtp_password,  # TODO: 加密
            from_email=from_email,
            to_emails=to_emails,
            enabled=True,
        )
        self._db.add(config)
        self._db.commit()
        self._db.refresh(config)
        return config

    # ---------- 订阅管理 ----------
    def create_or_update_subscription(self, user_id: int, stripe_subscription_id: str,
                                      status: SubscriptionStatus, price_id: str,
                                      current_period_end: datetime,
                                      cancel_at_period_end: bool = False) -> Subscription:
        """创建或更新订阅"""
        sub = self._db.query(Subscription).filter(
            Subscription.stripe_subscription_id == stripe_subscription_id
        ).first()

        if sub:
            sub.status = status
            sub.current_period_end = current_period_end
            sub.cancel_at_period_end = cancel_at_period_end
        else:
            sub = Subscription(
                user_id=user_id,
                stripe_subscription_id=stripe_subscription_id,
                status=status,
                price_id=price_id,
                current_period_end=current_period_end,
                cancel_at_period_end=cancel_at_period_end,
            )
            self._db.add(sub)

        self._db.commit()
        self._db.refresh(sub)
        return sub

    def get_active_subscription(self, user_id: int) -> Optional[Subscription]:
        """获取用户活跃订阅"""
        return self._db.query(Subscription).filter(
            Subscription.user_id == user_id,
            Subscription.status == SubscriptionStatus.ACTIVE
        ).first()

    # ---------- 迁移 ----------
    @staticmethod
    def migrate_from_old_config(json_path: str, admin_email: str = "admin@example.com"):
        """
        从旧版 JSON 文件迁移
        
        创建 admin 用户并归属所有旧数据
        """
        db = DataManager()  # 新建会话
        try:
            # 查找或创建 admin 用户
            admin = db.get_user_by_email(admin_email)
            if not admin:
                admin = db.create_user(admin_email, plan=UserPlan.PRO)
                print(f"[MIGRATE] 创建 admin 用户: id={admin.id}")

            # 执行迁移
            DataMigrator.migrate_from_json(json_path, admin.id)
            print("[MIGRATE] 迁移完成")
        finally:
            db.close()


# 全局数据管理器（用于兼容旧代码）
_data_manager: Optional[DataManager] = None


def get_data_manager() -> DataManager:
    """获取全局数据管理器"""
    global _data_manager
    if _data_manager is None:
        _data_manager = DataManager()
    return _data_manager


def get_db_data_manager(db: Session) -> DataManager:
    """创建绑定到特定 db session 的 DataManager"""
    return DataManager(db=db)
