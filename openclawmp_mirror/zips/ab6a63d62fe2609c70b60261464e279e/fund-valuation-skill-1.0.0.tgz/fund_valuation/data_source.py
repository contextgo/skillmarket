"""数据源模块 - 获取股票行情和基金持仓"""

import logging
from typing import Dict, List, Optional
import akshare as ak
import pandas as pd
import time

logger = logging.getLogger(__name__)


class DataSourceError(Exception):
    """数据源异常"""
    pass


class StockDataSource:
    """股票行情数据源"""

    def __init__(self, cache_seconds: int = 30):
        self.cache_seconds = cache_seconds
        self._cache = {}  # (code, timestamp) -> data

    def get_stock_realtime(self, stock_codes: List[str]) -> Dict[str, Dict]:
        """批量获取股票实时行情"""
        results = {}
        for code in stock_codes:
            try:
                results[code] = self._get_single_stock(code)
            except Exception as e:
                logger.warning(f"获取股票 {code} 失败: {e}")
                results[code] = None
        return results

    def _get_single_stock(self, stock_code: str) -> Dict:
        """获取单只股票行情（带缓存）"""
        now = time.time()
        cache_key = (stock_code, now // self.cache_seconds)

        if cache_key in self._cache:
            return self._cache[cache_key]

        # 尝试从 akshare 获取 A股实时行情
        try:
            # 所有 A股行情
            df = ak.stock_zh_a_spot_em()
            row = df[df['代码'] == stock_code]
            if not row.empty:
                data = {
                    'price': float(row['最新价'].iloc[0]),
                    'prev_close': float(row['昨收'].iloc[0]),
                    'change_pct': float(row['涨跌幅'].iloc[0]),
                    'name': row['名称'].iloc[0]
                }
                self._cache[cache_key] = data
                return data
        except Exception as e:
            logger.debug(f"akshare 获取 {stock_code} 失败: {e}")

        # 降级：模拟数据（仅测试用，不用于生产）
        raise DataSourceError(f"无法获取股票 {stock_code} 的实时数据")


class FundDataSource:
    """基金数据源"""

    def __init__(self):
        self._stock_ds = StockDataSource()

    def get_fund_holdings(self, fund_code: str) -> List[Dict]:
        """
        获取基金持仓
        返回 List[{'code': str, 'name': str, 'weight': float}]
        """
        try:
            # 使用天天基金接口
            df = ak.fund_hold_em(symbol=fund_code)
            holdings = []
            for _, row in df.iterrows():
                holdings.append({
                    'code': str(row['股票代码']),
                    'name': str(row['股票名称']),
                    'weight': float(row['持仓占比'].rstrip('%')) / 100.0
                })
            return holdings
        except Exception as e:
            logger.error(f"获取基金 {fund_code} 持仓失败: {e}")
            raise DataSourceError(f"无法获取基金 {fund_code} 的持仓数据")

    def get_fund_nav(self, fund_code: str, date: str = None) -> Optional[float]:
        """
        获取基金最新净值
        date 格式：YYYY-MM-DD，默认最新
        """
        try:
            df = ak.fund_open_fund_info_em(symbol=fund_code)
            # 按日期排序，取最新
            df = df.sort_values('净值日期', ascending=False)
            latest = df.iloc[0]
            return float(latest['单位净值'])
        except Exception as e:
            logger.warning(f"获取基金 {fund_code} 净值失败: {e}")
            return None

    def get_stock_changes(self, stock_codes: List[str]) -> Dict[str, float]:
        """获取股票当日涨跌幅（加权平均用）"""
        quotes = self._stock_ds.get_stock_realtime(stock_codes)
        changes = {}
        for code, data in quotes.items():
            if data:
                changes[code] = data['change_pct'] / 100.0  # 转为小数
        return changes


def estimate_fund_value(
    fund_config: Dict,
    data_source: Optional[FundDataSource] = None
) -> Dict[str, any]:
    """
    估算基金净值

    公式：估算净值 ≈ 昨日单位净值 × (1 + Σ(持仓权重 × 股票涨跌幅))

    返回 Dict:
        estimated_nav: float
        change_pct: float (估算涨跌幅)
        holdings_impact: List[{'code', 'name', 'weight', 'change', 'contribution'}]
        last_nav: float
        error: Optional[str]
    """
    if data_source is None:
        data_source = FundDataSource()

    result = {
        'estimated_nav': None,
        'change_pct': None,
        'holdings_impact': [],
        'last_nav': None,
        'error': None
    }

    try:
        # 1. 获取昨日净值
        last_nav = fund_config.get('last_nav')
        if not last_nav:
            fund_code = fund_config.get('fund_code', 'Unknown')
            last_nav = data_source.get_fund_nav(fund_code)
            if not last_nav:
                raise ValueError("无法获取昨日净值，请在配置中手动指定 last_nav")

        result['last_nav'] = last_nav

        # 2. 获取持仓
        holdings = fund_config.get('holdings', [])
        if not holdings:
            raise ValueError("基金配置缺少持仓信息")

        # 3. 获取所有持仓股票的涨跌幅
        stock_codes = [h['code'] for h in holdings]
        stock_changes = data_source.get_stock_changes(stock_codes)

        # 4. 计算加权涨跌幅
        weighted_change = 0.0
        total_weight = 0.0
        holdings_impact = []

        for h in holdings:
            code = h['code']
            name = h['name']
            weight = h.get('weight', 0.0)
            change = stock_changes.get(code, 0.0)  # 缺失则视为 0%

            contribution = weight * change
            weighted_change += contribution
            total_weight += weight

            holdings_impact.append({
                'code': code,
                'name': name,
                'weight': weight,
                'change': change,
                'contribution': contribution
            })

        # 权重归一化（防止持仓和不等于 1）
        if total_weight > 0:
            weighted_change = weighted_change / total_weight

        result['holdings_impact'] = holdings_impact

        # 5. 估算今日净值
        estimated_nav = last_nav * (1 + weighted_change)
        result['estimated_nav'] = round(estimated_nav, 4)
        result['change_pct'] = round(weighted_change * 100, 2)

        return result

    except Exception as e:
        logger.exception("估值计算失败")
        result['error'] = str(e)
        return result