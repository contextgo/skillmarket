"""
核心估值引擎 v2.0 - 升级版

基金净值估算公式：
   估算净值 = 昨日单位净值 × (1 + Σ(持仓权重 × 股票实时涨跌幅))

改进：
- 权重自动归一化
- 多数据源容错
- 历史数据保存
- 异常处理增强
"""

from typing import Dict, Any, Optional, List
import time
import logging
from datetime import datetime
from pathlib import Path
import json

logger = logging.getLogger(__name__)

# 历史数据存储路径（相对项目根目录）
HISTORY_DIR = Path("data/history")
HISTORY_DIR.mkdir(parents=True, exist_ok=True)

def normalize_weights(holdings: List[Dict]) -> List[Dict]:
    """
    归一化持仓权重，使其总和为 1.0

    输入： holdings = [{'weight': 0.3}, {'weight': 0.5}, ...]
    输出： 修改原列表，使权重总和=1.0
    """
    total = sum(h.get('weight', 0) for h in holdings)
    if total <= 0:
        raise ValueError("持仓权重总和无意义")
    
    if abs(total - 1.0) > 0.01:  # 允许小误差
        logger.info(f"持仓权重总和 {total:.3f}，自动归一化到 1.0")
        for h in holdings:
            h['weight'] = h.get('weight', 0) / total
    
    return holdings

def save_estimation_history(fund_code: str, result: Dict):
    """保存估算历史到 JSONL 文件"""
    history_file = HISTORY_DIR / f"fund_{fund_code}.jsonl"
    record = {
        "timestamp": datetime.now().isoformat(),
        "fund_code": fund_code,
        "last_nav": result.get('last_nav'),
        "estimated_nav": result.get('estimated_nav'),
        "change_pct": result.get('change_pct'),
        "error": result.get('error')
    }
    with open(history_file, 'a', encoding='utf-8') as f:
        f.write(json.dumps(record, ensure_ascii=False) + "\n")

def estimate_fund_value(
    fund_config: Dict,
    data_source: Optional[Any] = None
) -> Dict[str, Any]:
    """
    估算基金净值（v2.0）

    改进：
    - 权重归一化（防止放大误差）
    - 多数据源降级
    - 历史自动保存
    - 更详细的错误信息

    返回 Dict:
        estimated_nav: float
        change_pct: float
        last_nav: float
        holdings_impact: List[Dict]
        data_source_used: str
        warning: Optional[str]
        error: Optional[str]
    """
    result = {
        'estimated_nav': None,
        'change_pct': None,
        'holdings_impact': [],
        'last_nav': None,
        'data_source_used': None,
        'warning': None,
        'error': None
    }

    try:
        # 1. 获取昨日净值（优先用配置，其次自动获取）
        last_nav = fund_config.get('last_nav')
        if not last_nav:
            if data_source:
                last_nav = data_source.get_fund_nav(fund_config.get('code', 'Unknown'))
            if not last_nav:
                raise ValueError("无法获取昨日净值，请在配置中手动指定 last_nav")
        result['last_nav'] = last_nav

        # 2. 获取持仓并归一化
        holdings = fund_config.get('holdings', [])
        if not holdings:
            raise ValueError("基金配置缺少持仓信息")
        
        holdings = normalize_weights(holdings)

        # 3. 获取股票涨跌幅（容错：部分股票失败不影响整体）
        if data_source:
            stock_changes = data_source.get_stock_changes([h['code'] for h in holdings])
        else:
            # 无数据源，使用 0 变化（保守）
            stock_changes = {h['code']: 0.0 for h in holdings}
            result['warning'] = "无股票数据源，使用 0% 变化估算"

        # 4. 计算加权涨跌幅
        weighted_change = 0.0
        holdings_impact = []

        for h in holdings:
            code = h['code']
            name = h['name']
            weight = h.get('weight', 0.0)
            change = stock_changes.get(code, 0.0)

            contribution = weight * change
            weighted_change += contribution

            holdings_impact.append({
                'code': code,
                'name': name,
                'weight': round(weight, 4),
                'change': round(change, 4),
                'contribution': round(contribution, 4)
            })

        result['holdings_impact'] = sorted(
            holdings_impact, 
            key=lambda x: abs(x['contribution']), 
            reverse=True
        )[:10]  # 只保留前10大贡献

        # 5. 估算净值
        estimated_nav = last_nav * (1 + weighted_change)
        result['estimated_nav'] = round(estimated_nav, 4)
        result['change_pct'] = round(weighted_change * 100, 2)

        if data_source:
            result['data_source_used'] = data_source.__class__.__name__

        # 6. 保存历史
        try:
            save_estimation_history(fund_config.get('code', 'unknown'), result)
        except Exception as e:
            logger.warning(f"保存历史失败: {e}")

        return result

    except Exception as e:
        logger.exception("估值计算失败")
        result['error'] = str(e)
        return result
