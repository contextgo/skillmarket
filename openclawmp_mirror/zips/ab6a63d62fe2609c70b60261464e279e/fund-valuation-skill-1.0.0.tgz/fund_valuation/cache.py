"""
智能缓存系统 v1.0 - 减少重复网络请求

特性：
- 内存缓存（TTL自动过期）
- 可选 Redis 后端（进程间共享）
- 缓存键：基金净值、股票价格、涨跌幅
- 自动降级：Redis 不可用则退回内存缓存
"""

import time
import logging
import pickle
from typing import Any, Optional, Dict
from datetime import datetime, timedelta
from pathlib import Path

logger = logging.getLogger(__name__)

class MemoryCache:
    """纯内存缓存（默认）"""

    def __init__(self, default_ttl: int = 60):
        self._store: Dict[str, tuple] = {}  # key -> (value, expire_at)
        self.default_ttl = default_ttl

    def get(self, key: str) -> Optional[Any]:
        if key not in self._store:
            return None
        value, expire_at = self._store[key]
        if time.time() > expire_at:
            del self._store[key]
            return None
        return value

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        expire_at = time.time() + (ttl or self.default_ttl)
        self._store[key] = (value, expire_at)

    def delete(self, key: str):
        self._store.pop(key, None)

    def clear(self):
        self._store.clear()

    def stats(self) -> Dict:
        now = time.time()
        valid = sum(1 for _, exp in self._store.values() if now <= exp)
        return {
            "type": "memory",
            "total": len(self._store),
            "valid": valid,
            "expired": len(self._store) - valid
        }

class RedisCache:
    """Redis 缓存（可选）"""

    def __init__(self, redis_url: str = "redis://localhost:6379/0", default_ttl: int = 60):
        self.redis_url = redis_url
        self.default_ttl = default_ttl
        self._client = None
        self._connected = False
        try:
            import redis
            self._client = redis.from_url(redis_url, decode_responses=False)
            self._client.ping()
            self._connected = True
            logger.info(f"✅ Redis 缓存已连接: {redis_url}")
        except ImportError:
            logger.warning("⚠️  redis-py 未安装，Redis 缓存不可用")
        except Exception as e:
            logger.warning(f"⚠️  Redis 连接失败，降级到内存缓存: {e}")
            self._connected = False

    def get(self, key: str) -> Optional[Any]:
        if not self._connected:
            return None
        try:
            data = self._client.get(key)
            if data is None:
                return None
            return pickle.loads(data)
        except Exception as e:
            logger.warning(f"Redis get 失败: {e}")
            return None

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        if not self._connected:
            return
        try:
            ttl = ttl or self.default_ttl
            data = pickle.dumps(value)
            self._client.setex(key, ttl, data)
        except Exception as e:
            logger.warning(f"Redis set 失败: {e}")

    def delete(self, key: str):
        if not self._connected:
            return
        try:
            self._client.delete(key)
        except Exception:
            pass

    def clear(self):
        if not self._connected:
            return
        try:
            self._client.flushdb()
        except Exception:
            pass

    def stats(self) -> Dict:
        if not self._connected:
            return {"type": "redis", "connected": False}
        try:
            info = self._client.info()
            return {
                "type": "redis",
                "connected": True,
                "redis_version": info.get('redis_version'),
                "used_memory_human": info.get('used_memory_human'),
                "total_keys": self._client.dbsize()
            }
        except Exception as e:
            return {"type": "redis", "connected": False, "error": str(e)}

class SmartCache:
    """智能缓存代理（自动降级）"""

    def __init__(self, redis_url: Optional[str] = None, default_ttl: int = 60):
        # 尝试使用 Redis，失败则退回内存
        if redis_url:
            self._backend = RedisCache(redis_url, default_ttl)
            if not self._backend._connected:
                logger.info("🔄 Redis 不可用，切换至内存缓存")
                self._backend = MemoryCache(default_ttl)
        else:
            self._backend = MemoryCache(default_ttl)

    def get(self, key: str) -> Optional[Any]:
        return self._backend.get(key)

    def set(self, key: str, value: Any, ttl: Optional[int] = None):
        self._backend.set(key, value, ttl)

    def delete(self, key: str):
        self._backend.delete(key)

    def clear(self):
        self._backend.clear()

    def stats(self) -> Dict:
        return self._backend.stats()

# 全局缓存实例
_cache: Optional[SmartCache] = None

def init_cache(redis_url: Optional[str] = None, default_ttl: int = 60) -> SmartCache:
    """初始化全局缓存"""
    global _cache
    _cache = SmartCache(redis_url, default_ttl)
    logger.info(f"📦 缓存系统初始化完成: {_cache.stats()}")
    return _cache

def get_cache() -> SmartCache:
    """获取全局缓存实例"""
    global _cache
    if _cache is None:
        _cache = SmartCache()
    return _cache

def cache_key_fund_nav(fund_code: str) -> str:
    """基金净值缓存键"""
    return f"fund_nav:{fund_code}"

def cache_key_stock_change(stock_code: str) -> str:
    """股票涨跌幅缓存键"""
    return f"stock_change:{stock_code}"

def cache_key_fund_holdings(fund_code: str) -> str:
    """基金持仓缓存键"""
    return f"fund_holdings:{fund_code}"
