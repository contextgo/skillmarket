"""Auth0 认证集成"""

import os
import httpx
from fastapi import Request, HTTPException, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import jwt, jwk
from typing import Dict, Any

# Auth0 配置
AUTH0_DOMAIN = os.getenv("AUTH0_DOMAIN")
AUTH0_API_AUDIENCE = os.getenv("AUTH0_API_AUDIENCE")
AUTH0_ALGORITHMS = ["RS256"]

security = HTTPBearer()


class Auth0Handler:
    """Auth0 JWT 验证处理器"""

    def __init__(self):
        if not AUTH0_DOMAIN:
            raise ValueError("AUTH0_DOMAIN 环境变量未设置")
        self.jwks_url = f"https://{AUTH0_DOMAIN}/.well-known/jwks.json"
        self.jwks_client = jwt.PyJWKClient(self.jwks_url)

    async def verify_token(self, token: str) -> Dict[str, Any]:
        """
        验证 JWT token 并返回 payload
        
        Args:
            token: JWT token (不带 'Bearer ' 前缀)
            
        Returns:
            解码的 payload
            
        Raises:
            HTTPException: token 无效或过期
        """
        try:
            # 获取 signing key
            signing_key = self.jwks_client.get_signing_key_from_jwt(token)

            # 验证 token
            payload = jwt.decode(
                token,
                key=signing_key.key,
                algorithms=AUTH0_ALGORITHMS,
                audience=AUTH0_API_AUDIENCE,
                issuer=f"https://{AUTH0_DOMAIN}/",
            )
            return payload
        except jwt.ExpiredSignatureError:
            raise HTTPException(status_code=401, detail="Token 已过期")
        except jwt.JWTClaimsError as e:
            raise HTTPException(status_code=401, detail=f"Token 声明无效: {str(e)}")
        except Exception as e:
            raise HTTPException(status_code=401, detail=f"Token 验证失败: {str(e)}")


# 全局认证处理器
_auth0_handler: Optional[Auth0Handler] = None


def get_auth0_handler() -> Auth0Handler:
    """获取 Auth0 处理器（单例）"""
    global _auth0_handler
    if _auth0_handler is None:
        _auth0_handler = Auth0Handler()
    return _auth0_handler


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    auth0_handler: Auth0Handler = Depends(get_auth0_handler)
) -> Dict[str, Any]:
    """
    依赖注入：获取当前认证用户
    
    Returns:
        payload 包含：sub (Auth0 user_id), email, email_verified 等
    """
    token = credentials.credentials
    payload = await auth0_handler.verify_token(token)
    
    # 提取关键信息
    user_info = {
        "auth0_user_id": payload.get("sub"),
        "email": payload.get("email"),
        "email_verified": payload.get("email_verified", False),
        "name": payload.get("name"),
        "picture": payload.get("picture"),
    }
    return user_info


async def get_current_user_id(
    user_info: Dict[str, Any] = Depends(get_current_user),
    db = Depends(get_db)  # type: ignore
) -> int:
    """
    获取用户在本地数据库的 ID
    
    如果用户不存在则自动创建（首次登录）
    """
    from .data_manager import get_db_data_manager
    
    data_mgr = get_db_data_manager(db)
    email = user_info["email"]
    auth0_id = user_info["auth0_user_id"]
    
    user = data_mgr.get_user_by_auth0_id(auth0_id)
    if not user:
        # 首次登录，创建用户
        user = data_mgr.create_user(
            email=email,
            auth0_user_id=auth0_id,
            plan="free"
        )
    
    return user.id


# ---------- Web 路由辅助 ----------
def require_plan(min_plan: UserPlan):
    """
    权限装饰器：要求最低订阅等级
    
    Usage:
        @app.get("/api/pro")
        async def pro_endpoint(user_id: int = Depends(require_plan(UserPlan.BASIC))):
            ...
    """
    async def check_plan(
        user_id: int = Depends(get_current_user_id),
        db = Depends(get_db)  # type: ignore
    ):
        from .data_manager import get_db_data_manager
        from .models import UserPlan
        
        data_mgr = get_db_data_manager(db)
        user = data_mgr.get_user_by_id(user_id)
        
        if not user:
            raise HTTPException(status_code=404, detail="用户不存在")
        
        # 枚举比较
        plan_order = [UserPlan.FREE, UserPlan.BASIC, UserPlan.PRO]
        if plan_order.index(user.plan_type) < plan_order.index(min_plan):
            raise HTTPException(
                status_code=402,  # Payment Required
                detail=f"需要 {min_plan.value} 或更高订阅，当前: {user.plan_type.value}"
            )
        
        return user_id
    
    return check_plan
