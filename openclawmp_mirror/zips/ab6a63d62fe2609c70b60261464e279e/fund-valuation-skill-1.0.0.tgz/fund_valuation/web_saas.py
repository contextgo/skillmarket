"""Web 监控界面 v3.0 - SaaS 多租户版 (FastAPI + Auth0 + Stripe)"""

import os
import json
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, HTTPException, Depends
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from pydantic import BaseModel, EmailStr
import uvicorn
from jose import jwt

from .models import (
    UserPlan, SubscriptionStatus, Base, init_db, get_db,
    DataMigrator, get_db_data_manager
)
from .data_manager import DataManager
from .auth import get_auth0_handler, get_current_user, get_current_user_id
from .core import estimate_fund_value, FundDataSource
from .email import EmailNotifier, EmailConfig, format_fund_alert_email
from .cache import get_cache

logger = logging.getLogger(__name__)

# 安全器
security = HTTPBearer()

# ============ 数据模型 ============

class FundUpdate(BaseModel):
    """基金更新请求"""
    name: str
    holdings: List[dict]
    last_nav: Optional[float] = None
    thresholds: Optional[dict] = None


class FundResponse(BaseModel):
    """基金响应"""
    id: int
    fund_code: str
    name: str
    holdings: List[dict]
    last_nav: Optional[float] = None
    thresholds: dict
    is_active: bool
    created_at: datetime
    updated_at: datetime


class UserProfile(BaseModel):
    """用户信息"""
    id: int
    email: str
    plan: str
    fund_count: int
    subscription_status: Optional[str] = None


class CheckoutSessionRequest(BaseModel):
    """创建结账会话请求"""
    price_id: str  # Stripe Price ID (price_basic_19 或 price_pro_79)
    success_url: str = "https://fund-valuation.vercel.app/dashboard?success=1"
    cancel_url: str = "https://fund-valuation.vercel.app/pricing?canceled=1"


# ============ 主应用类 ============

class FundValuationSaaS:
    """SaaS 版基金估值助手 v3.0"""

    def __init__(self, port: int = 8080):
        self.port = port
        self.data_source = FundDataSource()
        self.cache = get_cache()
        self._websocket_clients: Dict[int, List[WebSocket]] = {}  # user_id -> [websockets]
        self._push_task: Optional[asyncio.Task] = None
        self.app = self._create_app()

    def _get_template_context(self, user_id: Optional[int] = None) -> Dict:
        """获取模板公共上下文"""
        ctx = {
            "app_name": "基金估值助手 SaaS",
            "current_year": datetime.now().year,
        }
        if user_id:
            ctx["user_id"] = user_id
        return ctx

    def _create_app(self) -> FastAPI:
        """创建 FastAPI 应用"""
        app = FastAPI(title="基金估值助手 SaaS", version="3.0.0")

        # 静态文件和模板
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        templates_dir = os.path.join(base_dir, 'templates')
        static_dir = os.path.join(base_dir, 'static')
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
        templates = Jinja2Templates(directory=templates_dir)

        # ============ Auth0 认证路由 ============

        @app.get("/auth/login")
        async def login(request: Request):
            """重定向到 Auth0 授权页面"""
            redirect_uri = "http://localhost:8080/auth/callback"
            # 如果生产环境，使用 Vercel 域名
            if os.getenv("VERCEL_URL"):
                redirect_uri = f"https://{os.getenv('VERCEL_URL')}/auth/callback"
            
            auth_url = (
                f"https://{os.getenv('AUTH0_DOMAIN')}/authorize?"
                f"audience={os.getenv('AUTH0_API_AUDIENCE')}&"
                f"response_type=token&"
                f"client_id={os.getenv('AUTH0_CLIENT_ID')}&"
                f"redirect_uri={redirect_uri}&"
                f"scope=openid%20profile%20email"
            )
            return RedirectResponse(auth_url)

        @app.get("/auth/logout")
        async def logout(request: Request):
            """注销：清除本地 token 并重定向到 Auth0 注销"""
            # 清除本地 token（浏览器端）
            response = RedirectResponse(f"https://{os.getenv('AUTH0_DOMAIN')}/v2/logout?")
            response.delete_cookie(key="access_token")
            return response

        @app.get("/auth/callback")
        async def auth_callback(request: Request):
            """
            Auth0 回调（处理 SPA implicit flow）
            实际 token 在 URL hash 中由前端处理，这里仅返回页面
            """
            return templates.TemplateResponse(
                "saas_callback.html",
                self._get_template_context()
            )

        @app.get("/auth/register")
        async def register(request: Request, plan: str = "free"):
            """重定向到 Auth0 注册页（使用 Universal Login）"""
            # Auth0 支持 signup 直接配置，这里简化处理，用相同 login 链接（Auth0 开启注册）
            redirect_uri = f"http://localhost:8080/auth/callback?plan={plan}"
            auth_url = (
                f"https://{os.getenv('AUTH0_DOMAIN')}/authorize?"
                f"audience={os.getenv('AUTH0_API_AUDIENCE')}&"
                f"response_type=token&"
                f"client_id={os.getenv('AUTH0_CLIENT_ID')}&"
                f"redirect_uri={redirect_uri}&"
                f"scope=openid%20profile%20email"
            )
            return RedirectResponse(auth_url)

        # ============ Web 路由 ============

        @app.get("/", response_class=HTMLResponse)
        async def homepage(request: Request):
            """首页（公开，但提供登录按钮）"""
            return templates.TemplateResponse(
                "saas_index.html",
                self._get_template_context()
            )

        @app.get("/dashboard", response_class=HTMLResponse)
        async def dashboard(request: Request, user_id: int = Depends(get_current_user_id)):
            """仪表盘（需登录）"""
            # 获取用户信息和基金列表
            db = DataManager()
            user = db.get_user_by_id(user_id)
            if not user:
                raise HTTPException(404, "用户不存在")

            funds = db.list_funds(user_id)
            fund_count = len(funds)

            return templates.TemplateResponse(
                "saas_dashboard.html",
                self._get_template_context(user_id) | {
                    "email": user.email,
                    "plan": user.plan_type.value,
                    "fund_count": fund_count,
                    "funds": funds,
                }
            )

        @app.get("/pricing", response_class=HTMLResponse)
        async def pricing_page(request: Request):
            """定价页面（公开）"""
            return templates.TemplateResponse(
                "saas_pricing.html",
                self._get_template_context()
            )

        @app.post("/api/stripe/create-checkout-session")
        async def create_checkout_session(
            req: CheckoutSessionRequest,
            user_id: int = Depends(get_current_user_id)
        ):
            """创建 Stripe Checkout 会话"""
            import stripe
            stripe.api_key = os.getenv("STRIPE_SECRET_KEY")
            if not stripe.api_key:
                raise HTTPException(500, "STRIPE_SECRET_KEY 未配置")

            db = DataManager()
            user = db.get_user_by_id(user_id)
            if not user or not user.stripe_customer_id:
                # 创建 Stripe Customer
                customer = stripe.Customer.create(
                    email=user.email,
                    metadata={"user_id": user_id}
                )
                user.stripe_customer_id = customer.id
                db._db.commit()

            session = stripe.checkout.Session.create(
                customer=user.stripe_customer_id,
                line_items=[{
                    "price": req.price_id,
                    "quantity": 1,
                }],
                mode="subscription",
                success_url=req.success_url,
                cancel_url=req.cancel_url,
                allow_promotion_codes=True,
            )
            return {"sessionId": session.id, "url": session.url}

        @app.post("/api/stripe/webhook")
        async def stripe_webhook(request: Request):
            """处理 Stripe Webhook（需验证签名）"""
            payload = await request.body()
            sig_header = request.headers.get("stripe-signature")
            endpoint_secret = os.getenv("STRIPE_WEBHOOK_SECRET")

            try:
                import stripe
                event = stripe.Webhook.construct_event(
                    payload, sig_header, endpoint_secret
                )
            except Exception as e:
                raise HTTPException(400, f"Webhook 验证失败: {e}")

            # 处理事件
            event_type = event["type"]
            data = event["data"]["object"]

            if event_type == "checkout.session.completed":
                # 订阅结账完成
                session = data
                customer_id = session.get("customer")
                subscription_id = session.get("subscription")

                db = DataManager()
                user = db._db.query(User).filter(
                    User.stripe_customer_id == customer_id
                ).first()
                if user:
                    # 获取订阅详情并更新
                    sub = stripe.Subscription.retrieve(subscription_id)
                    db.create_or_update_subscription(
                        user_id=user.id,
                        stripe_subscription_id=sub.id,
                        status=SubscriptionStatus(sub.status),
                        price_id=sub["items"]["data"][0]["price"]["id"],
                        current_period_end=datetime.fromtimestamp(sub.current_period_end),
                        cancel_at_period_end=sub.cancel_at_period_end,
                    )
                    # 升级用户 Plan
                    if "price_basic_19" in sub["items"]["data"][0]["price"]["id"]:
                        user.plan_type = UserPlan.BASIC
                    elif "price_pro_79" in sub["items"]["data"][0]["price"]["id"]:
                        user.plan_type = UserPlan.PRO
                    db._db.commit()

            elif event_type == "customer.subscription.updated":
                # 订阅更新（续费/取消）
                sub = stripe.Subscription.retrieve(data["id"])
                db = DataManager()
                subscription = db._db.query(Subscription).filter(
                    Subscription.stripe_subscription_id == sub.id
                ).first()
                if subscription:
                    db.create_or_update_subscription(
                        user_id=subscription.user_id,
                        stripe_subscription_id=sub.id,
                        status=SubscriptionStatus(sub.status),
                        price_id=sub["items"]["data"][0]["price"]["id"],
                        current_period_end=datetime.fromtimestamp(sub.current_period_end),
                        cancel_at_period_end=sub.cancel_at_period_end,
                    )

            return {"status": "success"}

        # ============ API 端点（需认证） ============

        @app.get("/api/user/profile", response_model=UserProfile)
        async def get_profile(user_id: int = Depends(get_current_user_id)):
            """获取当前用户信息"""
            db = DataManager()
            user = db.get_user_by_id(user_id)
            if not user:
                raise HTTPException(404, "用户不存在")

            fund_count = db.get_fund_count(user_id)
            sub = db.get_active_subscription(user_id)

            return UserProfile(
                id=user.id,
                email=user.email,
                plan=user.plan_type.value,
                fund_count=fund_count,
                subscription_status=sub.status.value if sub else None,
            )

        @app.get("/api/funds", response_model=List[FundResponse])
        async def list_funds(user_id: int = Depends(get_current_user_id)):
            """获取用户基金列表"""
            db = DataManager()
            funds = db.list_funds(user_id)
            return [
                FundResponse(
                    id=f.id,
                    fund_code=f.fund_code,
                    name=f.name,
                    holdings=f.holdings,
                    last_nav=f.last_nav,
                    thresholds=f.thresholds,
                    is_active=f.is_active,
                    created_at=f.created_at,
                    updated_at=f.updated_at,
                )
                for f in funds
            ]

        @app.post("/api/funds")
        async def create_fund(
            fund_code: str,
            update: FundUpdate,
            user_id: int = Depends(get_current_user_id)
        ):
            """添加/更新基金"""
            db = DataManager()
            try:
                fund = db.add_fund(
                    user_id=user_id,
                    fund_code=fund_code,
                    name=update.name,
                    holdings=update.holdings,
                    last_nav=int(update.last_nav * 10000) if update.last_nav else None,
                    thresholds=update.thresholds or {},
                )
                return {"success": True, "fund_id": fund.id}
            except PermissionError as e:
                raise HTTPException(status_code=402, detail=str(e))

        @app.delete("/api/funds/{fund_code}")
        async def delete_fund(fund_code: str, user_id: int = Depends(get_current_user_id)):
            """删除基金"""
            db = DataManager()
            success = db.remove_fund(user_id, fund_code)
            if not success:
                raise HTTPException(404, "基金不存在")
            return {"success": True}

        @app.websocket("/ws")
        async def websocket_endpoint(websocket: WebSocket, token: str):
            """WebSocket 推送（通过 query 参数 token）"""
            try:
                # 验证 token 并获取数据库 user_id
                auth0_handler = get_auth0_handler()
                payload = await auth0_handler.verify_token(token)
                auth0_user_id = payload.get("sub")
                
                # 通过 auth0_user_id 查数据库获取 user.id
                db = DataManager()
                user = db.get_user_by_auth0_id(auth0_user_id)
                if not user:
                    await websocket.close(code=4001, reason="用户未注册")
                    return
                
                user_id = user.id
            except Exception as e:
                await websocket.close(code=4001, reason=f"认证失败: {str(e)}")
                return

            await websocket.accept()
            # 注册 client
            if user_id not in self._websocket_clients:
                self._websocket_clients[user_id] = []
            self._websocket_clients[user_id].append(websocket)

            try:
                while True:
                    data = await websocket.receive_text()
                    if data == "ping":
                        await websocket.send_json({"type": "pong"})
            except WebSocketDisconnect:
                if user_id in self._websocket_clients and websocket in self._websocket_clients[user_id]:
                    self._websocket_clients[user_id].remove(websocket)

        @app.on_event("startup")
        async def startup_event():
            """启动时初始化"""
            # 创建数据库表（如果不存在）
            try:
                init_db()
                logger.info("✅ 数据库表初始化完成")
            except Exception as e:
                logger.error(f"数据库初始化失败: {e}")

            # 启动后台推送任务
            self._push_task = asyncio.create_task(self._background_push())

        @app.on_event("shutdown")
        async def shutdown_event():
            """关闭时清理"""
            if self._push_task:
                self._push_task.cancel()

        return app

    async def _background_push(self):
        """WebSocket 后台推送任务"""
        logger.info("📡 WebSocket 推送任务已启动")
        while True:
            try:
                await asyncio.sleep(5)
                # 为每个用户推送其基金数据
                for user_id, clients in self._websocket_clients.items():
                    if not clients:
                        continue
                    db = DataManager()
                    funds = db.list_funds(user_id)
                    if not funds:
                        continue

                    updates = []
                    for fund in funds:
                        result = estimate_fund_value({
                            "fund_code": fund.fund_code,
                            "name": fund.name,
                            "holdings": fund.holdings,
                            "last_nav": fund.last_nav,
                            "thresholds": fund.thresholds,
                        }, self.data_source)
                        if result.get('error') is None:
                            updates.append({
                                "type": "fund_update",
                                "fund_code": fund.fund_code,
                                "fund_name": fund.name,
                                "estimated_nav": result.get('estimated_nav'),
                                "change_pct": result.get('change_pct'),
                                "timestamp": datetime.now().strftime("%H:%M:%S")
                            })

                    if updates:
                        message = {
                            "type": "batch_update",
                            "data": updates,
                            "timestamp": datetime.now().isoformat()
                        }
                        # 广播给该用户所有客户端
                        dead_clients = []
                        for ws in clients:
                            try:
                                await ws.send_json(message)
                            except Exception:
                                dead_clients.append(ws)
                        for ws in dead_clients:
                            clients.remove(ws)

            except asyncio.CancelledError:
                logger.info("📡 WebSocket 推送任务已停止")
                break
            except Exception as e:
                logger.error(f"推送任务异常: {e}")

    def run(self):
        """启动服务器"""
        uvicorn.run(self.app, host="0.0.0.0", port=self.port)


def create_web_app(port: int = 8080) -> FastAPI:
    """创建应用实例"""
    web = FundValuationSaaS(port=port)
    return web.app


def run_app(port: int = 8080):
    """启动服务器"""
    web = FundValuationSaaS(port=port)
    web.run()


if __name__ == "__main__":
    import asyncio
    run_app()
