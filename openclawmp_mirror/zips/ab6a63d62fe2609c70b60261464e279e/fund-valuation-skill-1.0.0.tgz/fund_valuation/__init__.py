"""基金估值助手 - 实时估算基金净值"""

__version__ = "2.0.0"
__author__ = "龙小策"

from .cli import app
from .core import estimate_fund_value
from .config import ConfigManager, get_config_manager
from .data_source import FundDataSource, StockDataSource, DataSourceError

__all__ = [
    'app',
    'estimate_fund_value',
    'ConfigManager',
    'get_config_manager',
    'FundDataSource',
    'StockDataSource',
    'DataSourceError',
]