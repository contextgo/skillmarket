"""
核心估值引擎

基金净值估算公式：
   估算净值 = 昨日单位净值 × (1 + Σ(持仓权重 × 股票实时涨跌幅))

简化处理：不考虑现金、债券等非股票资产的影响（假设股票占比100%）。
如需更精确，可加入仓位调整系数。
"""

from typing import Dict, Any, Optional
from .data_source import FundDataSource, estimate_fund_value

# 直接导出
__all__ = ['estimate_fund_value']