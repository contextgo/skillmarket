"""Web 监控界面 v2.0 - FastAPI 应用（支持 WebSocket 推送 + 配置管理 + 历史图表）"""

import os
import json
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from fastapi import FastAPI, Request, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from pydantic import BaseModel
import uvicorn

from .config import ConfigManager, get_config_manager
from .core import estimate_fund_value, FundDataSource
from .email import EmailNotifier, EmailConfig, format_fund_alert_email
from .cache import get_cache

logger = logging.getLogger(__name__)

# 数据模型
class FundConfigUpdate(BaseModel):
    """基金配置更新"""
    name: str
    holdings: List[dict]
    last_nav: float
    thresholds: Optional[dict] = None


class EmailConfigUpdate(BaseModel):
    """邮件配置更新"""
    smtp_host: str
    smtp_port: int
    smtp_user: str
    smtp_password: str
    from_email: str
    to_emails: List[str]
    enabled: bool = True


class FundValuationWeb:
    """Web 应用主类 v2.0"""

    def __init__(self, config_mgr: Optional[ConfigManager] = None, port: int = 8080):
        self.config_mgr = config_mgr or get_config_manager()
        self.port = port
        self.data_source = FundDataSource()
        self.email_notifier: Optional[EmailNotifier] = None
        self.email_config_file = os.path.join(
            self.config_mgr.data_dir, 'email_config.json'
        )
        self._load_email_config()
        self._websocket_clients: List[WebSocket] = []
        self._push_task: Optional[asyncio.Task] = None
        self.app = self._create_app()
        self.cache = get_cache()

    def _load_email_config(self):
        """加载邮件配置"""
        if os.path.exists(self.email_config_file):
            try:
                with open(self.email_config_file, 'r') as f:
                    data = json.load(f)
                self.email_config = EmailConfig(**data)
                self.email_notifier = EmailNotifier(self.email_config)
            except Exception as e:
                logger.warning(f"加载邮件配置失败: {e}")
                self.email_notifier = None
        else:
            self.email_notifier = None

    def _save_email_config(self, config: EmailConfig):
        """保存邮件配置"""
        os.makedirs(self.config_mgr.data_dir, exist_ok=True)
        with open(self.email_config_file, 'w') as f:
            json.dump(config.dict(), f, indent=2)
        self.email_config = config
        self.email_notifier = EmailNotifier(config)

    def _create_app(self) -> FastAPI:
        """创建 FastAPI 应用 v2.0"""
        app = FastAPI(title="基金估值助手 v2.0", version="2.0.0")

        # 静态文件和模板
        base_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        templates_dir = os.path.join(base_dir, 'templates')
        static_dir = os.path.join(base_dir, 'static')

        os.makedirs(templates_dir, exist_ok=True)
        os.makedirs(static_dir, exist_ok=True)

        app.mount("/static", StaticFiles(directory=static_dir), name="static")
        templates = Jinja2Templates(directory=templates_dir)

        @app.on_event("startup")
        async def startup_event():
            """启动时开启推送任务"""
            self._push_task = asyncio.create_task(self._background_push())

        @app.on_event("shutdown")
        async def shutdown_event():
            """关闭时取消推送任务"""
            if self._push_task:
                self._push_task.cancel()

        @app.get("/", response_class=HTMLResponse)
        async def index(request: Request):
            """主页 - 新版监控面板（v2.0）"""
            return templates.TemplateResponse("index_v2.html", {"request": request})

        @app.get("/health", response_class=JSONResponse)
        async def health_check():
            """健康检查端点"""
            cache_stats = self.cache.stats()
            return {
                "status": "healthy",
                "timestamp": datetime.now().isoformat(),
                "version": "2.0.0",
                "cache": cache_stats,
                "clients_connected": len(self._websocket_clients),
                "uptime_seconds": int(asyncio.get_event_loop().time())
            }

        @app.get("/api/stats")
        async def get_system_stats():
            """系统统计：缓存、连接数等"""
            return {
                "cache": self.cache.stats(),
                "websocket_clients": len(self._websocket_clients),
                "config_funds_count": len(self.config_mgr.get_config().get('funds', {})),
            }

        @app.get("/api/funds")
        async def list_funds():
            """获取所有基金列表（含配置）"""
            funds = self.config_mgr.list_funds()
            result = []
            for code in funds:
                cfg = self.config_mgr.get_fund(code)
                if cfg:
                    cfg_with_code = dict(cfg)
                    cfg_with_code['fund_code'] = code
                    result.append(cfg_with_code)
            return {"funds": result, "count": len(result)}

        @app.get("/api/funds/{fund_code}/history")
        async def get_fund_history(fund_code: str, days: int = 7):
            """获取基金历史估值数据（用于图表）"""
            history_file = os.path.join(self.config_mgr.data_dir, 'history', f'fund_{fund_code}.jsonl')
            if not os.path.exists(history_file):
                return {"history": [], "message": "暂无历史数据"}

            records = []
            with open(history_file, 'r', encoding='utf-8') as f:
                for line in f:
                    try:
                        records.append(json.loads(line.strip()))
                    except:
                        continue

            # 按时间倒序取最近 N 天
            records.sort(key=lambda x: x['timestamp'], reverse=True)
            recent = records[:days * 100]  # 假设每天约100次更新

            # 反转回时间正序（方便图表绘制）
            recent.reverse()

            return {
                "fund_code": fund_code,
                "history": recent,
                "count": len(recent)
            }

        @app.post("/api/funds/{fund_code}/estimate")
        async def estimate_fund(fund_code: str):
            """单基金估值"""
            fund_config = self.config_mgr.get_fund(fund_code)
            if not fund_config:
                raise HTTPException(status_code=404, detail="未找到该基金配置")

            fund_config_with_code = dict(fund_config)
            fund_config_with_code['fund_code'] = fund_code

            result = estimate_fund_value(fund_config_with_code, self.data_source)
            result['timestamp'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            result['fund_code'] = fund_code
            result['fund_name'] = fund_config.get('name', fund_code)

            # 检查是否触发预警（并发送邮件）
            if result.get('error') is None and self.email_notifier:
                change_pct = result.get('change_pct', 0.0) / 100.0
                thresholds = fund_config.get('thresholds', {})
                low_thr = thresholds.get('low', -0.03)
                high_thr = thresholds.get('high', 0.03)

                if change_pct < low_thr or change_pct > high_thr:
                    # 发送预警邮件
                    html = format_fund_alert_email(
                        fund_code, fund_config, result, change_pct
                    )
                    subject = f"{'超过' if change_pct > high_thr else '低于'}阈值"
                    self.email_notifier.send(subject, html, html=True)

            return result

        @app.post("/api/funds/{fund_code}")
        async def update_fund(fund_code: str, update: FundConfigUpdate):
            """更新基金配置（内存 + 文件）"""
            current = self.config_mgr.get_fund(fund_code) or {}
            current.update(update.dict())
            self.config_mgr.add_or_update_fund(fund_code, **current)
            self.config_mgr.save_to_file()
            # 通知 WebSocket 客户端刷新配置
            await self._broadcast({"type": "config_updated", "fund_code": fund_code})
            return {"success": True, "message": "配置已保存"}

        @app.delete("/api/funds/{fund_code}")
        async def delete_fund(fund_code: str):
            """删除基金配置"""
            self.config_mgr.remove_fund(fund_code)
            self.config_mgr.save_to_file()
            await self._broadcast({"type": "fund_deleted", "fund_code": fund_code})
            return {"success": True, "message": "已删除"}

        @app.post("/api/funds")
        async def create_fund(fund_code: str, fund_config: FundConfigUpdate):
            """新增基金"""
            self.config_mgr.add_or_update_fund(fund_code, **fund_config.dict())
            self.config_mgr.save_to_file()
            await self._broadcast({"type": "fund_added", "fund_code": fund_code})
            return {"success": True, "message": "已添加"}

        @app.get("/api/email/config")
        async def get_email_config():
            """获取邮件配置（隐藏密码）"""
            if not self.email_config:
                return {"enabled": False}
            return {
                "enabled": True,
                "smtp_host": self.email_config.smtp_host,
                "smtp_port": self.email_config.smtp_port,
                "smtp_user": self.email_config.smtp_user,
                "from_email": self.email_config.from_email,
                "to_emails": self.email_config.to_emails,
                "use_tls": self.email_config.use_tls,
            }

        @app.post("/api/email/config")
        async def set_email_config(config: EmailConfigUpdate):
            """设置邮件配置"""
            full_config = EmailConfig(
                smtp_host=config.smtp_host,
                smtp_port=config.smtp_port,
                smtp_user=config.smtp_user,
                smtp_password=config.smtp_password,
                from_email=config.from_email,
                to_emails=config.to_emails,
                use_tls=config.use_tls,
            )
            self._save_email_config(full_config)
            return {"success": True, "enabled": config.enabled}

        # === 监控相关 API ===

        @app.post("/api/monitor/run")
        async def run_monitor():
            """手动触发监控分析"""
            try:
                from .monitor import monitor_fund, MonitorCache, export_monitor_report, SignalType
                from .config_manager_v2 import load_config
            except ImportError as e:
                raise HTTPException(status_code=500, detail=f"监控模块未加载: {e}")
            
            config = load_config()
            funds = config.get("funds", {})
            if not funds:
                return {"success": False, "message": "未配置基金"}
            
            cache = MonitorCache()
            signals = []
            
            for code, fund_config in funds.items():
                signal = monitor_fund(
                    fund_code=code,
                    fund_name=fund_config.get("name", code),
                    user_config=config,
                    cache=cache
                )
                if signal:
                    signals.append(signal)
            
            report_path = Path(self.config_mgr.data_dir) / "monitor_report.json"
            export_monitor_report(signals, report_path)
            
            return {
                "success": True,
                "funds_monitored": len(funds),
                "signals_generated": len(signals),
                "report_path": str(report_path)
            }

        @app.get("/api/monitor/report")
        async def get_monitor_report():
            """获取最新监控报告"""
            report_path = Path(self.config_mgr.data_dir) / "monitor_report.json"
            if not report_path.exists():
                raise HTTPException(status_code=404, detail="未找到监控报告")
            
            with open(report_path, 'r', encoding='utf-8') as f:
                report = json.load(f)
            
            return report

        @app.get("/api/monitor/signals")
        async def get_signals(limit: int = 10):
            """获取最新信号列表"""
            report = await get_monitor_report()
            signals = report.get("signals", [])[-limit:]
            
            # 转换 SignalType enum 为字符串
            for s in signals:
                if "signal_type" in s and hasattr(s["signal_type"], "value"):
                    s["signal_type"] = s["signal_type"].value
            
            return {"signals": signals}

        @app.post("/api/monitor/notify")
        async def send_signal_notification(
            fund_code: str,
            signal_type: str,
            channels: List[str] = ["email"]
        ):
            """
            发送信号通知
            
            channels: ["email", "webhook", "websocket"]
            """
            try:
                from .monitor import MonitorCache, MonitorSignal, SignalType
                from datetime import datetime
            except ImportError:
                raise HTTPException(status_code=500, detail="监控模块未加载")
            
            # 读取最新报告
            report_path = Path(self.config_mgr.data_dir) / "monitor_report.json"
            if not report_path.exists():
                raise HTTPException(status_code=404, detail="请先运行监控生成报告")
            
            with open(report_path, 'r', encoding='utf-8') as f:
                report = json.load(f)
            
            # 查找指定基金信号
            signal_data = None
            for s in report.get("signals", []):
                if s["fund_code"] == fund_code:
                    signal_data = s
                    break
            
            if not signal_data:
                raise HTTPException(status_code=404, detail=f"未找到基金 {fund_code} 的信号")
            
            # 重构 MonitorSignal 对象
            signal = MonitorSignal(
                fund_code=signal_data["fund_code"],
                signal_type=SignalType(signal_data["signal_type"]),
                confidence=signal_data["confidence"],
                reasons=signal_data["reasons"],
                current_nav=signal_data["current_nav"],
                estimated_nav=signal_data.get("estimated_nav"),
                trend_short=signal_data["trend_short"],
                trend_medium=signal_data["trend_medium"],
                news_sentiment=signal_data["news_sentiment"],
                suggested_action=signal_data["suggested_action"],
                created_at=datetime.fromisoformat(signal_data["created_at"])
            )
            
            # 格式化通知文本
            from .monitor import format_signal_for_notification
            notification_text = format_signal_for_notification(signal)
            
            results = []
            
            # Email 通知
            if "email" in channels and self.email_notifier:
                try:
                    subject = f"📊 {fund_code} 监控信号: {signal.signal_type.value.upper()}"
                    self.email_notifier.send(
                        subject=subject,
                        body=notification_text,
                        to_emails=None  # 使用配置的默认收件人
                    )
                    results.append({"channel": "email", "status": "sent"})
                except Exception as e:
                    results.append({"channel": "email", "status": "failed", "error": str(e)})
            
            # Webhook 通知（简单实现，可扩展）
            if "webhook" in channels:
                webhook_url = os.getenv("FUND_WEBHOOK_URL")
                if webhook_url:
                    try:
                        resp = requests.post(webhook_url, json={
                            "fund_code": fund_code,
                            "signal": signal.signal_type.value,
                            "text": notification_text
                        }, timeout=10)
                        results.append({"channel": "webhook", "status": "sent" if resp.status_code == 200 else "failed"})
                    except Exception as e:
                        results.append({"channel": "webhook", "status": "failed", "error": str(e)})
            
            # WebSocket 实时推送
            if "websocket" in channels:
                # 这里需要广播给所有连接的客户端
                # 实际推送由后台任务处理，此处只记录意图
                results.append({"channel": "websocket", "status": "scheduled"})
            
            return {
                "success": True,
                "fund_code": fund_code,
                "signal": signal.signal_type.value,
                "notifications": results
            }

        @app.get("/api/monitor/news/{fund_code}")
        async def get_fund_news(fund_code: str, count: int = 5):
            """获取基金相关新闻（缓存优先）"""
            try:
                from .monitor import MonitorCache, fetch_fund_news_for_fund
                from .config_manager_v2 import load_config
                from datetime import datetime
            except ImportError:
                raise HTTPException(status_code=500, detail="监控模块未加载")
            
            config = load_config()
            if fund_code not in config.get("funds", {}):
                raise HTTPException(status_code=404, detail="基金未配置")
            
            fund_name = config["funds"][fund_code].get("name", fund_code)
            cache = MonitorCache()
            
            cached = cache.get(fund_code, "news")
            if cached:
                # 缓存有效期内
                return {
                    "fund_code": fund_code,
                    "cached": True,
                    "cached_at": cached["cached_at"],
                    "news": cached["items"]
                }
            
            # 实时抓取
            news_items = fetch_fund_news_for_fund(fund_name, max_items=count)
            result_items = []
            for item in news_items:
                result_items.append({
                    "title": item.title,
                    "summary": item.summary,
                    "source": item.source,
                    "url": item.url,
                    "published_at": item.published_at.isoformat(),
                    "sentiment": item.sentiment,
                    "relevance": item.relevance
                })
            
            return {
                "fund_code": fund_code,
                "cached": False,
                "generated_at": datetime.now().isoformat(),
                "news": result_items
            }

        @app.websocket("/ws")
        async def websocket_endpoint(websocket: WebSocket):
            """WebSocket 端点：主动推送估值更新"""
            await websocket.accept()
            self._websocket_clients.append(websocket)
            logger.info(f"WebSocket 客户端连接，当前 {len(self._websocket_clients)} 个")
            try:
                # 发送初始欢迎消息
                await websocket.send_json({
                    "type": "connected",
                    "message": "已连接到基金估值推送服务",
                    "timestamp": datetime.now().isoformat()
                })
                # 保持连接（推送由后台任务负责）
                while True:
                    data = await websocket.receive_text()
                    # 可处理客户端ping
                    if data == "ping":
                        await websocket.send_json({"type": "pong"})
            except WebSocketDisconnect:
                if websocket in self._websocket_clients:
                    self._websocket_clients.remove(websocket)
                logger.info(f"WebSocket 断开，剩余 {len(self._websocket_clients)} 个")
            except Exception as e:
                logger.error(f"WebSocket 错误: {e}")
                if websocket in self._websocket_clients:
                    self._websocket_clients.remove(websocket)

        return app

    async def _background_push(self):
        """后台推送任务：定期计算并推送估算数据给所有 WebSocket 客户端"""
        logger.info("📡 WebSocket 推送任务已启动")
        while True:
            try:
                await asyncio.sleep(5)  # 每5秒推送一次

                # 获取所有基金
                funds = self.config_mgr.list_funds()
                if not funds:
                    continue

                updates = []
                for code in funds:
                    fund_config = self.config_mgr.get_fund(code)
                    if not fund_config:
                        continue
                    fund_config_with_code = dict(fund_config)
                    fund_config_with_code['fund_code'] = code
                    result = estimate_fund_value(fund_config_with_code, self.data_source)
                    if result.get('error') is None:
                        updates.append({
                            "type": "fund_update",
                            "fund_code": code,
                            "fund_name": fund_config.get('name', code),
                            "estimated_nav": result.get('estimated_nav'),
                            "change_pct": result.get('change_pct'),
                            "timestamp": datetime.now().strftime("%H:%M:%S")
                        })

                if updates:
                    await self._broadcast({
                        "type": "batch_update",
                        "data": updates,
                        "timestamp": datetime.now().isoformat()
                    })

            except asyncio.CancelledError:
                logger.info("📡 WebSocket 推送任务已停止")
                break
            except Exception as e:
                logger.error(f"推送任务异常: {e}")

    async def _broadcast(self, message: dict):
        """广播消息给所有 WebSocket 客户端"""
        if not self._websocket_clients:
            return
        dead_clients = []
        for ws in self._websocket_clients:
            try:
                await ws.send_json(message)
            except Exception:
                dead_clients.append(ws)
        # 清理死连接
        for ws in dead_clients:
            self._websocket_clients.remove(ws)

    def run(self):
        """启动 Web 服务器"""
        uvicorn.run(self.app, host="0.0.0.0", port=self.port)


def create_web_app(port: int = 8080) -> FastAPI:
    """创建 Web 应用实例"""
    web = FundValuationWeb(port=port)
    return web.app


def run_app(port: int = 8080):
    """启动 Web 服务器 (console script entry point)"""
    web = FundValuationWeb(port=port)
    web.run()


if __name__ == "__main__":
    import asyncio
    run_app()