"""命令行接口"""

import json
import logging
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich import print as rprint
import time

from .config import get_config_manager
from .core import estimate_fund_value, FundDataSource

app = typer.Typer(help="🐟 基金估值助手 - 实时估算基金净值")
console = Console()

# 设置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)


def format_percent(value: float) -> str:
    """格式化百分比"""
    sign = "+" if value >= 0 else ""
    return f"{sign}{value:.2f}%"


def render_fund_result(fund_code: str, fund_config: dict, result: dict) -> Table:
    """渲染单只基金结果"""
    last_nav = result.get('last_nav', 0)
    estimated_nav = result.get('estimated_nav', 0)
    change_pct = result.get('change_pct', 0.0)

    tbl = Table(show_header=False, box=None, padding=(0, 2))
    tbl.add_column("Key", style="bold cyan")
    tbl.add_column("Value")

    tbl.add_row("基金代码", f"{fund_code} - {fund_config.get('name', 'Unknown')}")
    tbl.add_row("昨日净值", f"{last_nav:.4f}" if last_nav else "N/A")
    tbl.add_row("估算净值", f"{estimated_nav:.4f}")

    # 涨跌幅颜色
    change_str = format_percent(change_pct) if change_pct else "N/A"
    change_color = "green" if change_pct >= 0 else "red"
    tbl.add_row("估算涨跌幅", f"[{change_color}]{change_str}[/{change_color}]")

    # 阈值状态
    thresholds = fund_config.get('thresholds', {})
    low_thr = thresholds.get('low', -3.0)  # 默认 -3%
    high_thr = thresholds.get('high', 3.0)  # 默认 +3%
    status = "✅ 正常"
    status_color = "green"
    if change_pct and change_pct < low_thr:
        status = f"⚠️ 低于阈值 ({format_percent(low_thr)})"
        status_color = "yellow"
    elif change_pct and change_pct > high_thr:
        status = f"🚨 超过阈值 ({format_percent(high_thr)})"
        status_color = "red"
    tbl.add_row("状态", f"[{status_color}]{status}[/{status_color}]")

    tbl.add_row("更新时间", time.strftime("%Y-%m-%d %H:%M:%S"))

    # 贡献度前3
    if result.get('holdings_impact'):
        impacts = sorted(result['holdings_impact'], key=lambda x: abs(x['contribution']), reverse=True)[:3]
        contrib_str = ", ".join([
            f"{imp['name']}({imp['code']}) {format_percent(imp['change']*100)}"
            for imp in impacts
        ])
        tbl.add_row("主要持仓", contrib_str)

    return tbl


def estimate_single_fund(fund_code: str, config_mgr, ds: FundDataSource) -> Optional[dict]:
    """估算单只基金"""
    fund_config = config_mgr.get_fund(fund_code)
    if not fund_config:
        console.print(f"[red]错误：未找到基金 {fund_code} 的配置[/red]")
        return None

    # 补充 fund_code
    fund_config['fund_code'] = fund_code

    result = estimate_fund_value(fund_config, ds)
    return result


@app.command()
def main(
    fund: Optional[str] = typer.Argument(None, help="基金代码，如 110011"),
    all_funds: bool = typer.Option(False, "--all", "-a", help="估算所有配置的基金"),
    watch: bool = typer.Option(False, "--watch", "-w", help="持续观察模式"),
    interval: int = typer.Option(300, "--interval", "-i", help="刷新间隔（秒）"),
    config: Optional[Path] = typer.Option(None, "--config", "-c", help="配置文件路径"),
    threshold: Optional[str] = typer.Option(None, "--threshold", "-t", help="临时阈值，格式: low,high (如 -0.02,0.02)"),
):
    """
    🐟 基金估值助手

    实时估算基金净值，帮助决策是否在下班前赎回或加仓。

    使用示例:
        fund-valuation 110011                    # 查询单只基金
        fund-valuation --all                     # 查询所有基金
        fund-valuation --all --watch             # 持续监控
        fund-valuation 110011 --threshold -0.02,0.02  # 设置 ±2% 阈值
    """
    # 加载配置
    config_mgr = get_config_manager()
    if config:
        config_mgr = ConfigManager(config)

    ds = FundDataSource()

    def run_once():
        """运行一次估值"""
        console.clear()

        # 标题
        title = f"🐟 基金估值助手 v1.0.0 | {time.strftime('%Y-%m-%d %H:%M:%S')}"
        console.print(Panel(title, style="bold blue"))

        # 确定要查询的基金列表
        if fund:
            codes = [fund]
        elif all_funds:
            codes = config_mgr.list_funds()
        else:
            # 都没有指定，显示帮助
            console.print("[yellow]请指定基金代码或使用 --all 参数[/yellow]")
            console.print("\n示例: fund-valuation 110011")
            raise typer.Exit()

        if not codes:
            console.print("[yellow]未配置任何基金[/yellow]")
            return

        # 处理阈值覆盖
        if threshold:
            try:
                low_str, high_str = threshold.split(',')
                override_thresholds = {'low': float(low_str), 'high': float(high_str)}
            except Exception:
                console.print("[red]阈值格式错误，应为: low,high (例如 -0.02,0.02)[/red]")
                override_thresholds = None
        else:
            override_thresholds = None

        # 估算每只基金
        for code in codes:
            fund_config = config_mgr.get_fund(code)
            if not fund_config:
                console.print(f"[red]跳过: 未找到基金 {code} 配置[/red]")
                continue

            # 应用阈值覆盖
            if override_thresholds:
                if 'thresholds' not in fund_config:
                    fund_config['thresholds'] = {}
                fund_config['thresholds'].update(override_thresholds)

            result = estimate_single_fund(code, config_mgr, ds)

            if result:
                # 有错误
                if result.get('error'):
                    console.print(f"[red]基金 {code} 计算失败: {result['error']}[/red]")
                    continue

                # 渲染结果
                table = render_fund_result(code, fund_config, result)
                console.print(table)
                console.print()  # 空行

    # 运行模式
    if watch:
        try:
            while True:
                run_once()
                console.print(f"[dim]💤 {interval} 秒后刷新... (Ctrl+C 退出)[/dim]")
                time.sleep(interval)
        except KeyboardInterrupt:
            console.print("\n[yellow]已停止监控[/yellow]")
    else:
        run_once()


if __name__ == "__main__":
    app()