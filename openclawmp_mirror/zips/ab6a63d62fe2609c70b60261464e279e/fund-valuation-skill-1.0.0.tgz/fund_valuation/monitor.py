"""
基金盯盘监控模块 (v2.0)
功能：自动爬取基金相关新闻、政策，分析走势，生成交易提醒
"""

import requests
import feedparser
from bs4 import BeautifulSoup
from typing import List, Dict, Any, Optional
from datetime import datetime, timedelta
import time
import json
from pathlib import Path
import logging
from dataclasses import dataclass, asdict
from enum import Enum
import re

logger = logging.getLogger(__name__)

# === 数据模型 ===

class SignalType(Enum):
    STRONG_BUY = "strong_buy"
    BUY = "buy"
    HOLD = "hold"
    SELL = "sell"
    STRONG_SELL = "strong_sell"

@dataclass
class NewsItem:
    """新闻条目"""
    title: str
    summary: str
    source: str
    url: str
    published_at: datetime
    sentiment: float  # -1.0 (负面) 到 1.0 (正面)
    relevance: float  # 0-1, 相关性分数

@dataclass
class MonitorSignal:
    """监控信号"""
    fund_code: str
    signal_type: SignalType
    confidence: float  # 0-1
    reasons: List[str]
    current_nav: float
    estimated_nav: Optional[float]
    trend_short: str  # up/down/sideways
    trend_medium: str
    news_sentiment: float
    suggested_action: str
    created_at: datetime

# === 新闻源配置 ===

NEWS_SOURCES = {
    "sina_finance": {
        "type": "rss",
        "url": "https://finance.sina.com.cn/stock/rss/",
        "keywords": ["基金", "股市", "政策"]
    },
    "eastmoney": {
        "type": "rss",
        "url": "https://feed.mix.sina.com.cn/api/roll/get?pageid=153&lid=2509&k=&num=50&page=1&callback=",
        "keywords": ["基金", "净值", "估值"]
    },
    "gov.cn": {
        "type": "policy",
        "url": "http://www.gov.cn/zhengce/",
        "keywords": ["金融", "证券", "基金", "资本市场"]
    }
}

# === 新闻爬取 ===

def fetch_rss_news(source_config: Dict, max_items: int = 20) -> List[NewsItem]:
    """从 RSS 源抓取新闻"""
    items = []
    try:
        feed = feedparser.parse(source_config["url"])
        keywords = source_config.get("keywords", [])
        
        for entry in feed.entries[:max_items]:
            title = entry.get("title", "")
            summary = entry.get("summary", entry.get("description", ""))
            link = entry.get("link", "")
            
            # 提取发布时间
            published = entry.get("published_parsed")
            if published:
                published_dt = datetime(*published[:6])
            else:
                published_dt = datetime.now()
            
            # 相关性检查
            relevance = 0.0
            if keywords:
                text = (title + " " + summary).lower()
                hits = sum(1 for kw in keywords if kw.lower() in text)
                relevance = min(hits / len(keywords), 1.0) if keywords else 1.0
            
            if relevance < 0.2:
                continue  # 相关性过低跳过
            
            # 简单情绪分析（基于关键词匹配）
            sentiment = simple_sentiment_analysis(title + " " + summary)
            
            items.append(NewsItem(
                title=title,
                summary=summary[:200],
                source=source_config["type"],
                url=link,
                published_at=published_dt,
                sentiment=sentiment,
                relevance=relevance
            ))
    except Exception as e:
        logger.error(f"RSS抓取失败 {source_config['url']}: {e}")
    
    return items

def simple_sentiment_analysis(text: str) -> float:
    """基于关键词的简单情绪分析（-1 到 1）"""
    text_lower = text.lower()
    
    positive_words = ["上涨", "利好", "增长", "提升", "突破", "机会", "买入", "推荐", "强势", "反弹"]
    negative_words = ["下跌", "利空", "下滑", "风险", "暴跌", "清盘", "赎回", "卖", "减持", "亏损"]
    
    pos_count = sum(1 for w in positive_words if w in text_lower)
    neg_count = sum(1 for w in negative_words if w in text_lower)
    
    total = pos_count + neg_count
    if total == 0:
        return 0.0
    
    return (pos_count - neg_count) / total

def fetch_policy_news() -> List[NewsItem]:
    """爬取政策信息"""
    items = []
    for source_name, config in NEWS_SOURCES.items():
        if config.get("type") == "policy":
            try:
                resp = requests.get(config["url"], timeout=10)
                soup = BeautifulSoup(resp.content, 'html.parser')
                
                # 简单抓取最近的政策公告（需要根据实际网页结构优化）
                links = soup.find_all('a', href=True, limit=10)
                for link in links:
                    title = link.get_text(strip=True)
                    href = link['href']
                    if not href.startswith('http'):
                        href = "http://www.gov.cn/zhengce/" + href
                    
                    # 相关性检查
                    keywords = config.get("keywords", [])
                    relevance = 0.0
                    if keywords:
                        text = title.lower()
                        hits = sum(1 for kw in keywords if kw.lower() in text)
                        relevance = min(hits / len(keywords), 1.0)
                    
                    if relevance < 0.3:
                        continue
                    
                    items.append(NewsItem(
                        title=title,
                        summary="政策公告",
                        source="gov.cn",
                        url=href,
                        published_at=datetime.now(),
                        sentiment=0.0,  # 政策中性
                        relevance=relevance
                    ))
            except Exception as e:
                logger.error(f"政策抓取失败: {e}")
    return items

# === 技术分析 ===

def calculate_technical_indicators(nav_history: List[float]) -> Dict[str, Any]:
    """
    计算技术指标
    
    输入：净值历史列表（按时间顺序，最近的在最后）
    返回：字典包含各种指标
    """
    if len(nav_history) < 5:
        return {"error": "历史数据不足"}
    
    current = nav_history[-1]
    prev = nav_history[-2]
    
    # 短期趋势（近5个点）
    short_len = min(5, len(nav_history))
    short_trend = (current - nav_history[-short_len]) / nav_history[-short_len] * 100
    
    # 中期趋势（近20个点）
    medium_len = min(20, len(nav_history))
    medium_trend = (current - nav_history[-medium_len]) / nav_history[-medium_len] * 100
    
    # 简单移动平均
    ma5 = sum(nav_history[-5:]) / 5 if len(nav_history) >= 5 else current
    ma20 = sum(nav_history[-20:]) / 20 if len(nav_history) >= 20 else current
    
    # 判断趋势方向
    def trend_desc(val: float) -> str:
        if val > 2.0:
            return "up"
        elif val < -2.0:
            return "down"
        else:
            return "sideways"
    
    return {
        "current": current,
        "change_pct": (current - prev) / prev * 100,
        "short_trend_pct": short_trend,
        "medium_trend_pct": medium_trend,
        "trend_short": trend_desc(short_trend),
        "trend_medium": trend_desc(medium_trend),
        "ma5": ma5,
        "ma20": ma20,
        "position_to_ma": (current - ma20) / ma20 * 100 if ma20 else 0
    }

# === 信号生成 ===

SIGNAL_RULES = {
    # 强烈买入：短期+中期上行 + 新闻正面 + 估值低位
    "strong_buy": {
        "trend_short": "up",
        "trend_medium": "up",
        "sentiment_threshold": 0.2,
        "position_to_ma_max": -5.0  # 相对于20日均线下浮不超过5%
    },
    # 买入：短期上行或中期上行 + 新闻中性偏正面
    "buy": {
        "trend_short": "up",
        "sentiment_threshold": 0.0,
        "position_to_ma_max": 2.0
    },
    # 卖出：短期+中期下行 + 新闻负面
    "sell": {
        "trend_short": "down",
        "trend_medium": "down",
        "sentiment_threshold": -0.1
    },
    # 强烈卖出：连续下行 + 重大利空
    "strong_sell": {
        "trend_short": "down",
        "trend_medium": "down",
        "sentiment_threshold": -0.3,
        "position_to_ma_min": -10.0  # 已跌破均线10%
    }
}

def generate_signal(
    fund_code: str,
    tech_indicators: Dict[str, Any],
    news_items: List[NewsItem],
    user_config: Dict[str, Any]
) -> MonitorSignal:
    """
    生成交易信号
    
    基于技术指标 + 新闻情绪 + 用户配置
    """
    current_nav = tech_indicators.get("current", 0)
    estimated_nav = user_config.get("last_estimation", {}).get("estimated_nav", current_nav)
    
    # 新闻情绪综合
    avg_sentiment = sum(n.sentiment * n.relevance for n in news_items) / \
                   sum(n.relevance for n in news_items) if news_items else 0.0
    
    reasons = []
    signal_score = 0.0
    
    # 规则评估
    tech_short = tech_indicators.get("trend_short", "sideways")
    tech_medium = tech_indicators.get("trend_medium", "sideways")
    position_ma = tech_indicators.get("position_to_ma", 0)
    
    # 买入信号条件
    if tech_short == "up" and tech_medium == "up" and avg_sentiment > 0.2 and position_ma < -5:
        signal_type = SignalType.STRONG_BUY
        signal_score = 0.9
        reasons.append("短期+中期趋势向上，技术面强势")
        reasons.append(f"新闻情绪正面（{avg_sentiment:.2f}）")
        reasons.append(f"相对于均线低位（{position_ma:.1f}%）")
        suggested_action = f"建议买入，预估仓位：{user_config.get('max_position_pct', 20)}%"
    
    elif tech_short == "up" and avg_sentiment >= 0:
        signal_type = SignalType.BUY
        signal_score = 0.7
        reasons.append("短期趋势向上")
        if avg_sentiment > 0:
            reasons.append("市场情绪正面")
        suggested_action = "建议小仓位买入或持有"
    
    # 卖出信号条件
    elif tech_short == "down" and tech_medium == "down" and avg_sentiment < -0.3 and position_ma < -10:
        signal_type = SignalType.STRONG_SELL
        signal_score = 0.9
        reasons.append("短期+中期趋势向下，技术面疲软")
        reasons.append(f"新闻情绪负面（{avg_sentiment:.2f}）")
        reasons.append(f"跌破均线幅度较大（{position_ma:.1f}%）")
        suggested_action = "建议清仓或大幅减仓"
    
    elif tech_short == "down" and avg_sentiment < 0:
        signal_type = SignalType.SELL
        signal_score = 0.7
        reasons.append("短期趋势走弱")
        if avg_sentiment < 0:
            reasons.append("负面新闻较多")
        suggested_action = "建议减仓或观望"
    
    # 持有
    else:
        signal_type = SignalType.HOLD
        signal_score = 0.5
        reasons.append("趋势震荡，方向不明")
        reasons.append(f"新闻情绪中性（{avg_sentiment:.2f}）")
        suggested_action = "建议持有等待明确信号"
    
    return MonitorSignal(
        fund_code=fund_code,
        signal_type=signal_type,
        confidence=signal_score,
        reasons=reasons,
        current_nav=current_nav,
        estimated_nav=estimated_nav,
        trend_short=tech_short,
        trend_medium=tech_medium,
        news_sentiment=avg_sentiment,
        suggested_action=suggested_action,
        created_at=datetime.now()
    )

# === 缓存管理 ===

class MonitorCache:
    """监控结果缓存（避免重复计算）"""
    
    def __init__(self, cache_dir: Path = Path("data/monitor_cache")):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
    
    def get(self, fund_code: str, cache_key: str) -> Optional[Dict]:
        cache_file = self.cache_dir / f"{fund_code}_{cache_key}.json"
        if cache_file.exists():
            with open(cache_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                # 缓存有效期 15 分钟
                cached_time = datetime.fromisoformat(data["cached_at"])
                if datetime.now() - cached_time < timedelta(minutes=15):
                    return data
        return None
    
    def set(self, fund_code: str, cache_key: str, data: Dict):
        cache_file = self.cache_dir / f"{fund_code}_{cache_key}.json"
        data["cached_at"] = datetime.now().isoformat()
        with open(cache_file, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

# === 主监控流程 ===

def monitor_fund(
    fund_code: str,
    fund_name: str,
    user_config: Dict[str, Any],
    cache: Optional[MonitorCache] = None
) -> Optional[MonitorSignal]:
    """
    单基金完整监控流程
    
    步骤：
    1. 读取净值历史（从 config_manager 获取）
    2. 计算技术指标
    3. 爬取相关新闻
    4. 生成交易信号
    5. 缓存结果
    6. 返回信号
    """
    try:
        # 1. 获取配置和历史数据
        from .core_v2 import estimate_fund_value
        from .config import get_config_manager
        
        config_mgr = get_config_manager()
        fund_config = config_mgr.get_fund(fund_code)
        if not fund_config:
            logger.error(f"基金 {fund_code} 未在配置中")
            return None
        
        # 读取历史数据（用于技术分析）
        history_file = Path("data/history") / f"fund_{fund_code}.jsonl"
        nav_history = []
        if history_file.exists():
            with open(history_file, 'r', encoding='utf-8') as f:
                for line in f:
                    rec = json.loads(line)
                    if "estimated_nav" in rec:
                        nav_history.append(rec["estimated_nav"])
        
        if len(nav_history) < 5:
            logger.warning(f"历史数据不足，跳过技术分析: {fund_code}")
            return None
        
        # 2. 计算技术指标
        tech_indicators = calculate_technical_indicators(nav_history)
        if "error" in tech_indicators:
            return None
        
        # 3. 爬取新闻（带缓存）
        if cache:
            news_cache_key = "news"
            cached_news = cache.get(fund_code, news_cache_key)
            if cached_news:
                news_items = [NewsItem(**n) for n in cached_news["items"]]
            else:
                # 抓取相关新闻（基于基金名称关键词）
                news_items = fetch_fund_news_for_fund(fund_name, max_items=10)
                cache.set(fund_code, news_cache_key, {"items": [asdict(n) for n in news_items]})
        else:
            news_items = fetch_fund_news_for_fund(fund_name, max_items=10)
        
        # 4. 获取最新估值（用于当前净值）
        estimation = estimate_fund_value(fund_config)
        current_nav = estimation.get("estimated_nav", nav_history[-1] if nav_history else 0)
        user_config["last_estimation"] = estimation
        
        # 5. 生成信号
        signal = generate_signal(
            fund_code=fund_code,
            tech_indicators=tech_indicators,
            news_items=news_items,
            user_config={**user_config, "fund_name": fund_name}
        )
        signal.current_nav = current_nav
        signal.estimated_nav = estimation.get("estimated_nav")
        
        return signal
    
    except Exception as e:
        logger.error(f"监控失败 {fund_code}: {e}", exc_info=True)
        return None

def fetch_fund_news_for_fund(fund_name: str, max_items: int = 10) -> List[NewsItem]:
    """
    针对特定基金抓取相关新闻
    使用通用关键词 + 基金名称
    """
    # 构建关键词：基金名称 + 常见相关词
    keywords = [fund_name, "基金", "股市", "行情"]
    all_items = []
    
    # 使用通用RSS源（可扩展）
    for source_name, config in NEWS_SOURCES.items():
        if config["type"] == "rss":
            try:
                items = fetch_rss_news(config, max_items=max_items)
                # 进一步筛选：包含基金名称或相关词
                for item in items:
                    text = (item.title + " " + item.summary).lower()
                    if any(kw.lower() in text for kw in keywords):
                        all_items.append(item)
            except Exception as e:
                logger.debug(f"源 {source_name} 抓取失败: {e}")
    
    # 去重（按标题）
    unique_items = []
    seen_titles = set()
    for item in all_items:
        if item.title not in seen_titles:
            seen_titles.add(item.title)
            unique_items.append(item)
    
    return unique_items[:max_items]

# === 导出监控报告 ===

def export_monitor_report(signals: List[MonitorSignal], output_path: Path = Path("data/monitor_report.json")):
    """导出监控报告（JSON）"""
    report = {
        "generated_at": datetime.now().isoformat(),
        "signals": [asdict(s) for s in signals]
    }
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        json.dump(report, f, ensure_ascii=False, indent=2)
    return report

def format_signal_for_notification(signal: MonitorSignal) -> str:
    """将信号格式化为通知文本（邮件/Webhook）"""
    emoji_map = {
        SignalType.STRONG_BUY: "🔥",
        SignalType.BUY: "📈",
        SignalType.HOLD: "⏸️",
        SignalType.SELL: "📉",
        SignalType.STRONG_SELL: "❄️"
    }
    emoji = emoji_map.get(signal.signal_type, "📊")
    
    text = f"""
{emoji} {signal.fund_code} 监控信号：{signal.signal_type.value.upper()}

📊 当前净值：{signal.current_nav:.4f}
📈 预估值：{signal.estimated_nav if signal.estimated_nav else 'N/A'}
📊 信号置信度：{signal.confidence:.0%}
📰 新闻情绪：{signal.news_sentiment:.2f}
📅 趋势：短期 {signal.trend_short} / 中期 {signal.trend_medium}

💡 建议操作：
{signal.suggested_action}

📝 原因分析：
{chr(10).join('- ' + r for r in signal.reasons)}

生成时间：{signal.created_at.strftime('%Y-%m-%d %H:%M:%S')}
"""
    return text.strip()
