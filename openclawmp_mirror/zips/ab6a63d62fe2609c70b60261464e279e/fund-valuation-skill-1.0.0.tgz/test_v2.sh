#!/bin/bash
set -e

cd /Users/ssyb/.openclaw/workspace/fund-valuation-skill

# 激活虚拟环境
source venv/bin/activate

# 设置配置文件路径
export FUND_HOLDINGS_PATH=data/test_fund_holdings.json

# 测试 1: 单基金估值（CLI）
echo "=== 测试 1: CLI 单基金估值 ==="
python -m fund_valuation.cli --fund 159525 --threshold -0.03,0.03

# 测试 2: 手动触发 Web API 估值
echo -e "\n=== 测试 2: Web API 单基金估值 ==="
curl -s http://localhost:8080/api/funds/159525/estimate | python3 -m json.tool

# 测试 3: 获取基金列表
echo -e "\n=== 测试 3: 基金列表 API ==="
curl -s http://localhost:8080/api/funds | python3 -m json.tool

# 测试 4: 健康检查
echo -e "\n=== 测试 4: 健康检查 ==="
curl -s http://localhost:8080/health | python3 -m json.tool

echo -e "\n✅ 所有测试完成！"
