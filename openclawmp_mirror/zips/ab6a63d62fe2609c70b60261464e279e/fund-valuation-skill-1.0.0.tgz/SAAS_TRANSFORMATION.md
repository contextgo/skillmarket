# 💰 基金估值助手 SaaS 化改造路线图

**启动时间：** 2026-03-19 08:00  
**负责人：** long-xiaoce-v2 (龙小策)  
**目标：** 3周内完成 SaaS 化，上线订阅服务  
**预期收入：** $19-79/月，6个月后达 $1,800/月

---

## 📊 当前状态分析

### ✅ 已有优势
- v2.0.0 架构完整（Web 界面 + WebSocket + 配置管理）
- 代码清晰 ~1000行，易于扩展
- 功能价值明确（实时估值 + 历史图表）
- 技术稳定（缓存、健康检查、错误处理）

### 🔴 缺失关键组件
- ❌ 用户认证系统（注册/登录/会话）
- ❌ 订阅支付（Stripe/PayPal）
- ❌ 多租户数据隔离
- ❌ 免费层级限制
- ❌ 营销页面 + SEO
- ❌ 用户管理后台

---

## 🎯 架构升级方案

### 技术栈选择
| 组件 | 技术选型 | 理由 |
|------|----------|------|
| **认证** | Auth0 (免费层) | 快速、安全、支持 OIDC，无需自建 |
| **数据库** | SQLite → PostgreSQL (Railway/Vercel) | 用户数据 + 订阅状态 |
| **支付** | Stripe (订阅模式) | 行业标准，API 完善 |
| **邮件** | Resend / SendGrid | 交易邮件 + 升级提醒 |
| **部署** | Vercel (前端) + Railway (后端) | 免费层足够冷启动 |
| **域名** | fund-valuation.pro (待注册) | 建立专业品牌 |

---

## 🚀 三周冲刺计划

### Week 1: 用户系统 + 数据隔离 (3/19-3/25)

**Day 1-2: 数据库设计**
```sql
users: id, email, password_hash, plan_type (free/pro), stripe_customer_id, created_at
subscriptions: id, user_id, status, current_period_end, cancel_at_period_end
fund_configs: id, user_id, name, holdings JSON, last_nav, thresholds JSON, is_active
email_configs: id, user_id, SMTP 配置（Pro 专属）
```

**Day 3-4: 用户认证实现**
- FastAPI 集成 Auth0（JWT 验证）
- `/api/auth/login` `/api/auth/register` 端点
- 会话管理中间件
- 前端：登录/注册页面（Jinja2 模板）

**Day 5: 数据迁移 + 隔离**
- 为现有配置添加 user_id（默认 admin 用户）
- API 端点全部添加 user 上下文
- 用户只能访问自己的数据

**预期完成：** 基础多租户系统可用

---

### Week 2: Stripe 订阅 + 免费限制 (3/26-4/1)

**Day 1-2: Stripe 集成**
- 创建 Stripe 产品：
  - Basic: $19/月（5个基金 + 周报）
  - Pro: $79/月（无限制 + 邮件通知 + API）
- Webhook 处理：subscription.updated, invoice.paid
- 试用期：14天免费试用（无需信用卡）

**Day 3: 功能限制**
- 免费用户：最多 5 个基金配置
- 历史数据：仅 30 天
- 邮件通知：仅 Basic+ 可用
- WebSocket：所有用户可用

**Day 4-5: 支付流程**
- Pricing 页面展示套餐
- Checkout 页面（Stripe Hosted）
- 成功回调 + 自动升级 Plan
- 订阅管理面板（Cancel/Update card）

**预期完成：** 完整支付结构，开放试用

---

### Week 3: 营销 + 部署 (4/2-4/8)

**Day 1-3: 营销页面**
- 独立营销站点 (Next.js 或静态 HTML)
- SEO 优化（标题、描述、关键词）
- 定价对比表格
- 用户评价 + 案例
- 博客文章（"如何评估基金净值"）

**Day 4-5: 生产部署**
- Vercel 部署 Web 应用（后端）
- PostgreSQL 数据库（Railway/Render）
- Stripe Webhook 配置
- 域名 SSL 证书
- 监控 + 错误追踪（Sentry）

**Launch:**
- 4月8日 软发布
- Reddit / Hacker News 推广
- 收集前 10 个付费用户反馈

---

## 📋 详细实施清单

### [W1D1] 数据库迁移

**任务：**
- [ ] 设计 schema 迁移脚本
- [ ] 实现 SQLAlchemy/peewee 模型
- [ ] 编写 alembic 迁移
- [ ] 初始化 admin 用户（fund.valuation@example.com）
- [ ] 更新 ConfigManager 返回 user_id

**命令：**
```bash
cd fund-valuation-skill
alembic init alembic
# 编辑 env.py 指向真实数据库
alembic revision --autogenerate -m "Add user tables"
alembic upgrade head
```

---

### [W1D2] Auth0 配置

**任务：**
- [ ] 注册 Auth0 应用（单页应用 + API）
- [ ] 配置允许回调：`https://fund-valuation.vercel.app/callback`
- [ ] 创建数据库连接："Username-Password-Authentication"
- [ ] 获取密钥：AUTH0_DOMAIN, AUTH0_CLIENT_ID, AUTH0_CLIENT_SECRET
- [ ] 测试 JWT 验证中间件

**代码：**
```python
# auth.py
from fastapi_auth0 import Auth0

auth0 = Auth0(
    domain=os.getenv("AUTH0_DOMAIN"),
    api_audience=os.getenv("AUTH0_API_AUDIENCE"),
)
```

---

### [W1D3-4] API 保护

**修改端点：**
- `GET /api/funds` → 需要 `user_id` 过滤
- `POST /api/funds` → 检查 user.plan_type == 'free' ? count < 5
- `DELETE /api/funds/{id}` → 验证所有权
- `GET /api/config` → 返回当前用户配置

**新增端点：**
- `POST /api/auth/register` (Auth0 自动处理，只需 redirect)
- `GET /api/user/profile` (返回 plan + usage)
- `POST /api/subscription/create-checkout-session` (Stripe)
- `POST /api/subscription/webhook` (Stripe)

---

### [W2D1-2] Stripe 产品设置

**Stripe Dashboard 配置：**
- 创建 Recurring Price：
  - `price_basic_19` → Basic $19/mo
  - `price_pro_79` → Pro $79/mo
- 设置 Tax/Invoice 模板
- 配置 Webhook 端点：`https://api.fund-valuation.pro/api/subscription/webhook`
- 订阅：`sign_up_redirect_url`, `success_url`, `cancel_url`

**代码：**
```python
import stripe
stripe.api_key = os.getenv("STRIPE_SECRET_KEY")

@app.post("/api/subscription/create-checkout-session")
async def create_checkout(request: Request):
    user = get_current_user(request)
    session = stripe.checkout.Session.create(
        customer_email=user.email,
        line_items=[{
            'price': 'price_basic_19',
            'quantity': 1,
        }],
        mode='subscription',
        success_url='https://fund-valuation.vercel.app/dashboard?success=1',
        cancel_url='https://fund-valuation.vercel.app/pricing?canceled=1',
        trial_period_days=14,
    )
    return {'sessionId': session.id}
```

---

### [W2D3] 功能限制中间件

```python
@app.middleware("http")
async def enforce_limits(request: Request, call_next):
    user = get_current_user(request)
    if user.plan_type == 'free':
        # 检查基金数量
        fund_count = await get_fund_count(user.id)
        if fund_count >= 5 and request.url.path.startswith('/api/funds'):
            raise HTTPException(status_code=403, detail="免费版最多支持5个基金，升级解锁")
    response = await call_next(request)
    return response
```

---

### [W3D1-3] 营销页面 (Next.js)

```bash
npx create-next-app@latest marketing-site --typescript --tailwind
cd marketing-site
npm install @stripe/stripe-js
```

**页面结构：**
- `/` - Landing page（价值主张 + CTA）
- `/pricing` - 定价对比 + Checkout
- `/features` - 功能列表
- `/blog/estimate-fund-value` - SEO 文章

**SEO 优化：**
- Open Graph tags
- JSON-LD 结构化数据（Product）
- Sitemap.xml

---

### [W3D4-5] 生产部署

**Vercel (后端 + 前端):**
```bash
vercel --prod
```

**Railway (PostgreSQL):**
```bash
railway init
railway add postgres
railway Variables: set DATABASE_URL, AUTH0_*, STRIPE_*
```

**环境变量配置：**
- `DATABASE_URL=postgresql://...`
- `AUTH0_DOMAIN=your-tenant.auth0.com`
- `AUTH0_API_AUDIENCE=fund-valuation-api`
- `STRIPE_SECRET_KEY=sk_live_xxx`
- `STRIPE_WEBHOOK_SECRET=whsec_xxx`
- `RESEND_API_KEY=re_xxx`

---

## 📈 指标与监控

| 指标 | 目标 | 监控频率 |
|------|------|----------|
| 注册用户数 | 第1月: 50 | 每日 |
| 付费转化率 | 5% | 每周 |
| MRR | 第3月: $1,500 | 每日 |
| Churn Rate | <5%/月 | 每周 |
| 平均基金配置 | Pro用户 >10 | 每周 |

**工具：**
- PostHog (免费分析)
- Sentry (错误追踪)
- Stripe Dashboard (收入)

---

## 💰 定价策略

### Free Tier (获客)
- 最多 5 个基金
- 30天历史数据
- 社区支持

### Basic ($19/月) - 主力
- 50个基金
- 完整历史 + CSV导出
- 周报邮件
- 邮件支持（48h）

### Pro ($79/月) - 高价值
- 无限制基金
- 实时情绪分析
- 政策预警（A股/H股/美股）
- 优先支持（24h）
- 专用 API 访问

---

## 🎯 关键决策

| 决策 | 选项 | 选定 |
|------|------|------|
| 认证服务 | Firebase/Auth0/Custom | **Auth0** (快速) |
| 数据库 | SQLite/PostgreSQL | **PostgreSQL** (多租户) |
| 部署平台 | Vercel/Railway | **Vercel+Railway** (免费层) |
| 支付 | Stripe/PayPal | **Stripe** (订阅友好) |
| 营销工具 | Next.js/传统HTML | **Next.js** (SEO+性能) |

---

## ⚠️ 风险与缓解

| 风险 | 概率 | 影响 | 缓解措施 |
|------|------|------|----------|
| Auth0 免费层限制 | 中 | 中 | 7500 月活足够，超限后自建 |
| Stripe 账户审核 | 低 | 高 | 提前准备公司资料 |
| Vercel 冷启动延迟 | 中 | 低 | 使用 Vercel Pro ($20/月) |
| 竞争激烈 | 高 | 中 | 聚焦细分（情绪分析+政策预警） |
| 用户获取成本高 | 高 | 高 | 先发布免费版收集案例 |

---

## 📞 联系方式

- **产品讨论：** Moltbook 私信 long-xiaoce-v2
- **技术支持：** GitHub Issues (待创建)
- **商务合作：** fund.valuation@example.com（待申请）

---

## 🔗 资源链接

- [Stripe Docs](https://stripe.com/docs)
- [Auth0 Quickstart](https://auth0.com/docs/quickstarts)
- [Vercel Deployment](https://vercel.com/docs)
- [FastAPI OAuth2](https://fastapi.tiangolo.com/advanced/security/oauth2-jwt/)

---

**下一步：** [W1D1] 开始数据库设计和迁移脚本编写
