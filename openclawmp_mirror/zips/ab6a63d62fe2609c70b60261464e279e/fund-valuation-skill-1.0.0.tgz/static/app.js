// 基金估值助手前端逻辑

document.addEventListener('DOMContentLoaded', function() {
    const app = {
        config: {
            refreshInterval: 5000, // 5秒刷新
            apiBase: window.location.origin
        },
        state: {
            funds: [],
            lastUpdate: null
        },

        init() {
            this.bindEvents();
            this.loadEmailConfig();
            this.fetchFunds();
            setInterval(() => this.fetchFunds(), this.config.refreshInterval);
        },

        bindEvents() {
            // 刷新按钮
            document.getElementById('btn-refresh').addEventListener('click', () => {
                this.fetchFunds();
            });

            // 导航切换
            document.getElementById('nav-dashboard').addEventListener('click', (e) => {
                e.preventDefault();
                this.showDashboard();
            });
            document.getElementById('nav-config').addEventListener('click', (e) => {
                e.preventDefault();
                this.showConfig();
            });

            // 邮件配置表单
            document.getElementById('email-config-form').addEventListener('submit', (e) => {
                this.saveEmailConfig(e);
            });
        },

        async fetchFunds() {
            try {
                const response = await fetch('/api/funds');
                const data = await response.json();
                this.state.funds = data.funds;
                this.renderFunds();
                this.updateStatus('已连接', 'success');
            } catch (error) {
                console.error('获取基金列表失败:', error);
                this.updateStatus('连接失败', 'danger');
            }
        },

        async estimateFund(fundCode) {
            try {
                const response = await fetch(`/api/funds/${fundCode}/estimate`, { method: 'POST' });
                const result = await response.json();
                this.updateFundRow(fundCode, result);
            } catch (error) {
                console.error(`估算基金 ${fundCode} 失败:`, error);
            }
        },

        renderFunds() {
            const tbody = document.querySelector('#funds-table tbody');
            tbody.innerHTML = '';

            if (this.state.funds.length === 0) {
                tbody.innerHTML = '<tr><td colspan="8" class="text-center text-muted">暂无配置的基金</td></tr>';
                return;
            }

            this.state.funds.forEach(fund => {
                const tr = document.createElement('tr');
                tr.dataset.code = fund.fund_code;
                
                // 阈值显示
                const thresholds = fund.thresholds || { low: -0.03, high: 0.03 };
                const thresholdsDisplay = `${(thresholds.low * 100).toFixed(1)}% ~ ${(thresholds.high * 100).toFixed(1)}%`;

                // 主要持仓（取权重前三）
                const topHoldings = (fund.holdings || [])
                    .sort((a, b) => b.weight - a.weight)
                    .slice(0, 3)
                    .map(h => `${h.name}(${h.code})`)
                    .join(', ');

                tr.innerHTML = `
                    <td><strong>${fund.name}</strong></td>
                    <td><code>${fund.fund_code}</code></td>
                    <td>${fund.last_nav || '--'}</td>
                    <td class="estimated-nav">--</td>
                    <td class="change-pct">--</td>
                    <td class="status"><span class="badge bg-secondary">等待估算</span></td>
                    <td><small class="text-muted thresholds-display">${thresholdsDisplay}</small></td>
                    <td><small>${topHoldings || '未配置'}</small></td>
                `;

                tbody.appendChild(tr);

                // 触发估值请求（并轮询更新）
                setTimeout(() => this.estimateFund(fund.fund_code), fund.fund_code.length * 100);
            });
        },

        updateFundRow(fundCode, result) {
            const tr = document.querySelector(`tr[data-code="${fundCode}"]`);
            if (!tr) return;

            if (result.error) {
                tr.querySelector('.estimated-nav').textContent = '错误';
                tr.querySelector('.change-pct').textContent = result.error.substring(0, 20);
                tr.querySelector('.status').innerHTML = '<span class="badge bg-danger">错误</span>';
                return;
            }

            const estimatedNav = result.estimated_nav;
            const changePct = result.change_pct;
            const thresholds = result.thresholds || { low: -0.03, high: 0.03 };

            // 数值
            tr.querySelector('.estimated-nav').textContent = estimatedNav.toFixed(4);
            
            const changeTd = tr.querySelector('.change-pct');
            changeTd.textContent = `${changePct > 0 ? '+' : ''}${changePct.toFixed(2)}%`;
            changeTd.className = `change-pct ${changePct >= 0 ? 'change-positive' : 'change-negative'}`;

            // 状态
            const statusBadge = tr.querySelector('.status .badge');
            if (changePct >= thresholds.high) {
                statusBadge.textContent = '超过阈值 🚨';
                statusBadge.className = 'badge bg-danger';
                tr.classList.add('alert-danger');
            } else if (changePct <= thresholds.low) {
                statusBadge.textContent = '低于阈值 ⚠️';
                statusBadge.className = 'badge bg-warning text-dark';
                tr.classList.add('alert-warning');
            } else {
                statusBadge.textContent = '正常 ✅';
                statusBadge.className = 'badge bg-success';
                tr.classList.remove('alert-warning', 'alert-danger');
            }

            this.state.lastUpdate = new Date();
            document.getElementById('last-update').textContent = 
                `最后更新: ${this.state.lastUpdate.toLocaleTimeString()}`;
        },

        updateStatus(text, type) {
            const el = document.getElementById('system-status');
            el.textContent = text;
            el.className = `badge bg-${type}`;
        },

        showDashboard() {
            document.getElementById('funds-container').classList.remove('d-none');
            document.getElementById('config-container').classList.add('d-none');
            document.getElementById('nav-dashboard').classList.add('active');
            document.getElementById('nav-config').classList.remove('active');
        },

        showConfig() {
            document.getElementById('funds-container').classList.add('d-none');
            document.getElementById('config-container').classList.remove('d-none');
            document.getElementById('nav-dashboard').classList.remove('active');
            document.getElementById('nav-config').classList.add('active');
            this.loadEmailConfig();
        },

        async loadEmailConfig() {
            try {
                const response = await fetch('/api/email/config');
                const data = await response.json();
                const form = document.getElementById('email-config-form');
                if (data.enabled) {
                    form.smtp_host.value = data.smtp_host || '';
                    form.smtp_port.value = data.smtp_port || 587;
                    form.smtp_user.value = data.smtp_user || '';
                    form.from_email.value = data.from_email || '';
                    form.to_emails.value = (data.to_emails || []).join(', ');
                    form.use_tls.value = data.use_tls !== false;
                }
            } catch (error) {
                console.error('加载邮件配置失败:', error);
            }
        },

        async saveEmailConfig(e) {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);
            const config = {
                smtp_host: formData.get('smtp_host'),
                smtp_port: parseInt(formData.get('smtp_port')),
                smtp_user: formData.get('smtp_user'),
                smtp_password: formData.get('smtp_password'),
                from_email: formData.get('from_email'),
                to_emails: formData.get('to_emails').split(',').map(email => email.trim()).filter(Boolean),
                use_tls: formData.get('use_tls') === 'true',
                enabled: true
            };

            try {
                const response = await fetch('/api/email/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(config)
                });
                const result = await response.json();
                const statusDiv = document.getElementById('email-status');
                if (result.success) {
                    statusDiv.innerHTML = '<div class="alert alert-success">配置已保存！测试邮件功能稍后开启。</div>';
                } else {
                    statusDiv.innerHTML = '<div class="alert alert-danger">保存失败</div>';
                }
            } catch (error) {
                console.error('保存邮件配置失败:', error);
            }
        }
    };

    window.app = app;
    app.init();
});