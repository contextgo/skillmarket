// 基金估值助手 v2.0 前端逻辑（WebSocket + 配置管理 + 图表）

document.addEventListener('DOMContentLoaded', function() {
    const app = {
        config: {
            refreshInterval: 5000,
            apiBase: window.location.origin,
            wsUrl: `ws://${window.location.host}/ws`
        },
        state: {
            funds: new Map(), // fund_code -> fund data
            ws: null,
            historyChart: null,
            currentHistoryFund: null
        },

        init() {
            this.bindEvents();
            this.connectWebSocket();
            this.fetchFunds();
            this.startHeartbeat();
        },

        bindEvents() {
            // 导航
            document.getElementById('nav-dashboard').addEventListener('click', (e) => {
                e.preventDefault();
                this.showDashboard();
            });
            document.getElementById('nav-history').addEventListener('click', (e) => {
                e.preventDefault();
                this.showHistory();
            });
            document.getElementById('nav-config').addEventListener('click', (e) => {
                e.preventDefault();
                this.showConfig();
            });
            document.getElementById('nav-settings').addEventListener('click', (e) => {
                e.preventDefault();
                this.showSettings();
            });

            // 刷新按钮
            document.getElementById('btn-refresh').addEventListener('click', () => {
                this.fetchFunds();
            });

            // 邮件配置
            document.getElementById('email-config-form').addEventListener('submit', (e) => {
                this.saveEmailConfig(e);
            });

            // 添加基金
            document.getElementById('btn-submit-add-fund').addEventListener('click', () => {
                this.submitAddFund();
            });
        },

        connectWebSocket() {
            try {
                this.state.ws = new WebSocket(this.config.wsUrl);
                this.state.ws.onopen = () => {
                    console.log('✅ WebSocket 已连接');
                    document.getElementById('ws-status').textContent = '📡 WebSocket: 已连接';
                    document.getElementById('ws-status').className = 'text-success';
                };
                this.state.ws.onclose = () => {
                    console.log('❌ WebSocket 断开');
                    document.getElementById('ws-status').textContent = '📡 WebSocket: 断开';
                    document.getElementById('ws-status').className = 'text-danger';
                    // 3秒后重连
                    setTimeout(() => this.connectWebSocket(), 3000);
                };
                this.state.ws.onerror = (error) => {
                    console.error('WebSocket 错误:', error);
                };
                this.state.ws.onmessage = (event) => {
                    this.handleWSMessage(JSON.parse(event.data));
                };
            } catch (e) {
                console.error('WebSocket 连接失败:', e);
            }
        },

        handleWSMessage(msg) {
            switch (msg.type) {
                case 'connected':
                    console.log('欢迎消息:', msg.message);
                    break;
                case 'batch_update':
                    this.applyBatchUpdates(msg.data);
                    break;
                case 'config_updated':
                case 'fund_added':
                case 'fund_deleted':
                    this.fetchFunds(); // 配置变更，重新拉取基金列表
                    break;
                case 'pong':
                    // 忽略
                    break;
            }
        },

        applyBatchUpdates(updates) {
            let changedCount = 0;
            updates.forEach(u => {
                if (u.type === 'fund_update') {
                    const old = this.state.funds.get(u.fund_code);
                    if (!old || old.change_pct !== u.change_pct) {
                        this.state.funds.set(u.fund_code, {
                            code: u.fund_code,
                            name: u.fund_name,
                            estimated_nav: u.estimated_nav,
                            change_pct: u.change_pct,
                            timestamp: u.timestamp
                        });
                        this.updateFundRow(u);
                        changedCount++;
                    }
                }
            });
            if (changedCount > 0) {
                this.updateSummary();
                this.updateLastUpdateTime();
            }
        },

        async fetchFunds() {
            try {
                const response = await fetch('/api/funds');
                const data = await response.json();
                
                // 重置 Map
                this.state.funds.clear();
                data.funds.forEach(fund => {
                    this.state.funds.set(fund.fund_code, {
                        code: fund.fund_code,
                        name: fund.name,
                        last_nav: fund.last_nav,
                        holdings: fund.holdings,
                        thresholds: fund.thresholds || { low: -0.03, high: 0.03 }
                    });
                });

                this.renderFunds();
                this.updateSummary();
                this.updateStatus('已连接', 'success');
            } catch (error) {
                console.error('获取基金列表失败:', error);
                this.updateStatus('连接失败', 'danger');
            }
        },

        renderFunds() {
            const tbody = document.querySelector('#funds-table tbody');
            tbody.innerHTML = '';

            if (this.state.funds.size === 0) {
                tbody.innerHTML = '<tr><td colspan="9" class="text-center text-muted">暂无配置的基金，请点击"添加基金"按钮</td></tr>';
                return;
            }

            this.state.funds.forEach(fund => {
                const tr = document.createElement('tr');
                tr.dataset.code = fund.code;
                
                // 阈值显示
                const thresholds = fund.thresholds || { low: -0.03, high: 0.03 };
                const thresholdsDisplay = `${(thresholds.low * 100).toFixed(1)}% ~ ${(thresholds.high * 100).toFixed(1)}%`;

                // 主要持仓
                const topHoldings = (fund.holdings || [])
                    .sort((a, b) => b.weight - a.weight)
                    .slice(0, 3)
                    .map(h => `${h.name}`)
                    .join(', ');

                tr.innerHTML = `
                    <td><strong>${fund.name}</strong></td>
                    <td><code>${fund.code}</code></td>
                    <td>${fund.last_nav ? fund.last_nav.toFixed(4) : '--'}</td>
                    <td class="estimated-nav">等待数据...</td>
                    <td class="change-pct">--</td>
                    <td class="status"><span class="badge bg-secondary">等待</span></td>
                    <td><small class="text-muted thresholds-display">${thresholdsDisplay}</small></td>
                    <td><small>${topHoldings || '无'}</small></td>
                    <td>
                        <button class="btn btn-sm btn-outline-primary me-1" data-action="history" title="历史分析">
                            <i class="bi bi-graph-up"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-danger" data-action="delete" title="删除">
                            <i class="bi bi-trash"></i>
                        </button>
                    </td>
                `;

                // 绑定操作按钮
                tr.querySelector('[data-action="history"]').addEventListener('click', () => {
                    this.loadHistory(fund.code, fund.name);
                    this.showHistory();
                });
                tr.querySelector('[data-action="delete"]').addEventListener('click', () => {
                    if (confirm(`确定删除基金 ${fund.code} ${fund.name} 吗？`)) {
                        this.deleteFund(fund.code);
                    }
                });

                tbody.appendChild(tr);
            });
        },

        updateFundRow(fundCode, data) {
            const tr = document.querySelector(`tr[data-code="${fundCode}"]`);
            if (!tr) return;

            if (data.error) {
                tr.querySelector('.estimated-nav').textContent = '错误';
                tr.querySelector('.change-pct').textContent = '错误';
                tr.querySelector('.status').innerHTML = '<span class="badge bg-danger">错误</span>';
                return;
            }

            const estimatedNav = data.estimated_nav;
            const changePct = data.change_pct;
            const thresholds = data.thresholds || { low: -0.03, high: 0.03 };

            tr.querySelector('.estimated-nav').textContent = estimatedNav.toFixed(4);
            
            const changeTd = tr.querySelector('.change-pct');
            changeTd.textContent = `${changePct > 0 ? '+' : ''}${changePct.toFixed(2)}%`;
            changeTd.className = `change-pct ${changePct >= 0 ? 'text-success' : 'text-danger'}`;

            const statusBadge = tr.querySelector('.status .badge');
            if (changePct >= thresholds.high) {
                statusBadge.textContent = '超阈值 🚨';
                statusBadge.className = 'badge bg-danger';
                tr.classList.add('table-warning');
            } else if (changePct <= thresholds.low) {
                statusBadge.textContent = '低于阈值 ⚠️';
                statusBadge.className = 'badge bg-warning text-dark';
                tr.classList.add('table-warning');
            } else {
                statusBadge.textContent = '正常 ✅';
                statusBadge.className = 'badge bg-success';
                tr.classList.remove('table-warning');
            }

            this.updateLastUpdateTime();
        },

        updateSummary() {
            let total = this.state.funds.size;
            let up = 0, down = 0, alertCount = 0;
            
            this.state.funds.forEach(fund => {
                if (fund.change_pct > 0) up++;
                if (fund.change_pct < 0) down++;
                const thresholds = fund.thresholds || { low: -0.03, high: 0.03 };
                if (fund.change_pct <= thresholds.low || fund.change_pct >= thresholds.high) {
                    alertCount++;
                }
            });

            document.getElementById('total-funds').textContent = total;
            document.getElementById('up-count').textContent = up;
            document.getElementById('down-count').textContent = down;
            document.getElementById('alert-count').textContent = alertCount;
        },

        updateLastUpdateTime() {
            const now = new Date();
            document.getElementById('last-update').textContent = 
                `最后更新: ${now.toLocaleTimeString()}`;
        },

        updateStatus(text, type) {
            const el = document.getElementById('system-status');
            el.textContent = text;
            el.className = `badge bg-${type}`;
        },

        showDashboard() {
            document.getElementById('dashboard-container').classList.remove('d-none');
            document.getElementById('history-container').classList.add('d-none');
            document.getElementById('config-container').classList.add('d-none');
            document.getElementById('settings-container').classList.add('d-none');
            
            document.getElementById('nav-dashboard').classList.add('active');
            document.getElementById('nav-history').classList.remove('active');
            document.getElementById('nav-config').classList.remove('active');
            document.getElementById('nav-settings').classList.remove('active');
        },

        showHistory() {
            document.getElementById('dashboard-container').classList.add('d-none');
            document.getElementById('history-container').classList.remove('d-none');
            document.getElementById('config-container').classList.add('d-none');
            document.getElementById('settings-container').classList.add('d-none');
            
            document.getElementById('nav-dashboard').classList.remove('active');
            document.getElementById('nav-history').classList.add('active');
            document.getElementById('nav-config').classList.remove('active');
            document.getElementById('nav-settings').classList.remove('active');
        },

        showConfig() {
            document.getElementById('dashboard-container').classList.add('d-none');
            document.getElementById('history-container').classList.add('d-none');
            document.getElementById('config-container').classList.remove('d-none');
            document.getElementById('settings-container').classList.add('d-none');
            
            document.getElementById('nav-dashboard').classList.remove('active');
            document.getElementById('nav-history').classList.remove('active');
            document.getElementById('nav-config').classList.add('active');
            document.getElementById('nav-settings').classList.remove('active');

            this.fetchConfigTable();
        },

        showSettings() {
            document.getElementById('dashboard-container').classList.add('d-none');
            document.getElementById('history-container').classList.add('d-none');
            document.getElementById('config-container').classList.add('d-none');
            document.getElementById('settings-container').classList.remove('d-none');
            
            document.getElementById('nav-dashboard').classList.remove('active');
            document.getElementById('nav-history').classList.remove('active');
            document.getElementById('nav-config').classList.remove('active');
            document.getElementById('nav-settings').classList.add('active');

            this.loadEmailConfig();
        },

        async loadHistory(fundCode, fundName) {
            this.state.currentHistoryFund = { code: fundCode, name: fundName };
            try {
                const response = await fetch(`/api/funds/${fundCode}/history?days=7`);
                const data = await response.json();
                this.renderHistoryChart(data.history, fundName);
            } catch (error) {
                console.error('获取历史数据失败:', error);
                alert('获取历史数据失败，请稍后重试');
            }
        },

        renderHistoryChart(history, fundName) {
            const ctx = document.getElementById('history-chart').getContext('2d');
            
            if (this.state.historyChart) {
                this.state.historyChart.destroy();
            }

            const labels = history.map(r => {
                const d = new Date(r.timestamp);
                return `${d.month+1}/${d.date()} ${d.getHours()}:${d.getMinutes().toString().padStart(2, '0')}`;
            });
            const values = history.map(r => r.estimated_nav);
            const changePcts = history.map(r => r.change_pct);

            // 计算统计指标
            const meanChange = changePcts.reduce((a,b)=>a+b,0) / changePcts.length;
            const variance = changePcts.reduce((sum, p) => sum + Math.pow(p - meanChange, 2), 0) / changePcts.length;
            const volatility = Math.sqrt(variance).toFixed(2);
            const maxGain = Math.max(...changePcts).toFixed(2);
            const maxLoss = Math.min(...changePcts).toFixed(2);

            document.getElementById('stat-volatility').textContent = `${volatility}%`;
            document.getElementById('stat-max-gain').textContent = `${maxGain}%`;
            document.getElementById('stat-max-loss').textContent = `${maxLoss}%`;

            this.state.historyChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: labels,
                    datasets: [{
                        label: `${fundName} - 估算净值`,
                        data: values,
                        borderColor: 'rgb(75, 192, 192)',
                        tension: 0.1,
                        fill: false
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: { position: 'top' },
                        title: { display: true, text: `${fundName} 近期估值走势` }
                    },
                    scales: {
                        y: { beginAtZero: false }
                    }
                }
            });
        },

        async fetchConfigTable() {
            try {
                const response = await fetch('/api/funds');
                const data = await response.json();
                const tbody = document.querySelector('#config-table tbody');
                tbody.innerHTML = '';

                data.funds.forEach(fund => {
                    const tr = document.createElement('tr');
                    const holdingsCount = (fund.holdings || []).length;
                    const thresholds = fund.thresholds || { low: -0.03, high: 0.03 };
                    tr.innerHTML = `
                        <td><code>${fund.fund_code}</code></td>
                        <td>${fund.name}</td>
                        <td>${holdingsCount} 只</td>
                        <td>${(thresholds.low*100).toFixed(1)}% ~ ${(thresholds.high*100).toFixed(1)}%</td>
                        <td>
                            <button class="btn btn-sm btn-outline-danger" data-delete="${fund.fund_code}">删除</button>
                        </td>
                    `;
                    tr.querySelector(`[data-delete="${fund.fund_code}"]`).addEventListener('click', () => {
                        if (confirm(`删除 ${fund.fund_code} 的配置？`)) {
                            this.deleteFund(fund.fund_code);
                        }
                    });
                    tbody.appendChild(tr);
                });
            } catch (error) {
                console.error('获取配置失败:', error);
            }
        },

        async deleteFund(fundCode) {
            try {
                const response = await fetch(`/api/funds/${fundCode}`, { method: 'DELETE' });
                const result = await response.json();
                if (result.success) {
                    this.fetchFunds();
                    if (document.getElementById('config-container').classList.contains('d-none') === false) {
                        this.fetchConfigTable();
                    }
                } else {
                    alert('删除失败');
                }
            } catch (error) {
                console.error('删除基金失败:', error);
                alert('删除失败');
            }
        },

        async submitAddFund() {
            const form = document.getElementById('add-fund-form');
            const formData = new FormData(form);
            const fundCode = formData.get('fund_code').trim();
            const name = formData.get('name').trim();
            const last_nav = parseFloat(formData.get('last_nav'));
            const holdings = JSON.parse(formData.get('holdings') || '[]');
            const low_threshold = parseFloat(formData.get('low_threshold')) / 100;
            const high_threshold = parseFloat(formData.get('high_threshold')) / 100;

            if (!fundCode || !name || isNaN(last_nav)) {
                alert('请填写完整信息');
                return;
            }

            try {
                const response = await fetch('/api/funds', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        name,
                        holdings,
                        last_nav,
                        thresholds: { low: low_threshold, high: high_threshold }
                    })
                });
                const result = await response.json();
                if (result.success) {
                    bootstrap.Modal.getInstance(document.getElementById('addFundModal')).hide();
                    form.reset();
                    this.fetchFunds();
                    alert('基金添加成功！');
                } else {
                    alert('添加失败');
                }
            } catch (error) {
                console.error('添加基金失败:', error);
                alert('添加失败');
            }
        },

        async loadEmailConfig() {
            try {
                const response = await fetch('/api/email/config');
                const data = await response.json();
                const form = document.getElementById('email-config-form');
                if (data.enabled) {
                    form.smtp_host.value = data.smtp_host || '';
                    form.smtp_port.value = data.smtp_port || 587;
                    form.smtp_user.value = data.smtp_user || '';
                    form.from_email.value = data.from_email || '';
                    form.to_emails.value = (data.to_emails || []).join(', ');
                    form.use_tls.value = data.use_tls !== false;
                }
            } catch (error) {
                console.error('加载邮件配置失败:', error);
            }
        },

        async saveEmailConfig(e) {
            e.preventDefault();
            const form = e.target;
            const formData = new FormData(form);
            const config = {
                smtp_host: formData.get('smtp_host'),
                smtp_port: parseInt(formData.get('smtp_port')),
                smtp_user: formData.get('smtp_user'),
                smtp_password: formData.get('smtp_password'),
                from_email: formData.get('from_email'),
                to_emails: formData.get('to_emails').split(',').map(email => email.trim()).filter(Boolean),
                use_tls: formData.get('use_tls') === 'true',
                enabled: true
            };

            try {
                const response = await fetch('/api/email/config', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(config)
                });
                const result = await response.json();
                const statusDiv = document.getElementById('email-status');
                if (result.success) {
                    statusDiv.innerHTML = '<div class="alert alert-success">✅ 邮件配置已保存，阈值触发时将发送预警邮件。</div>';
                } else {
                    statusDiv.innerHTML = '<div class="alert alert-danger">❌ 保存失败，请检查配置。</div>';
                }
            } catch (error) {
                console.error('保存邮件配置失败:', error);
                statusDiv.innerHTML = '<div class="alert alert-danger">❌ 网络错误。</div>';
            }
        },

        startHeartbeat() {
            // 每30秒发送ping保持连接（可选）
            setInterval(() => {
                if (this.state.ws && this.state.ws.readyState === WebSocket.OPEN) {
                    this.state.ws.send('ping');
                }
            }, 30000);
        }
    };

    window.app = app;
    app.init();
});
