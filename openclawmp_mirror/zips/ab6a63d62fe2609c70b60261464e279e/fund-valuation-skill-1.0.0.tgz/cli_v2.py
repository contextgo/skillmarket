#!/usr/bin/env python3
"""
基金估值助手 CLI v2.0 - 增强版
支持：配置热重载、历史查询、监控模式
"""

import sys
import time
import logging
from pathlib import Path
from datetime import datetime
import json

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.live import Live
from rich import print as rprint

# 添加项目路径
sys.path.insert(0, str(Path(__file__).parent.parent))

from fund_valuation.config_manager_v2 import ConfigManager
from fund_valuation.data_source_v2 import EnhancedFundDataSource
from fund_valuation.core_v2 import estimate_fund_value

app = typer.Typer(help="🐟 基金估值助手 v2.0 - 智能监控")
console = Console()

# 日志配置
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(name)s: %(message)s',
    datefmt='%H:%M:%S'
)
logger = logging.getLogger(__name__)

# 全局配置管理器
config_mgr = ConfigManager()

def format_percent(value: float) -> str:
    """格式化百分比"""
    sign = "+" if value >= 0 else ""
    return f"{sign}{value:.2f}%"

def render_fund_result(fund_code: str, fund_config: dict, result: dict) -> Panel:
    """渲染单只基金结果面板"""
    last_nav = result.get('last_nav', 0)
    estimated_nav = result.get('estimated_nav', 0)
    change_pct = result.get('change_pct', 0.0)

    content = f"""
[bold cyan]基金代码:[/bold cyan] {fund_code} - {fund_config.get('name', 'Unknown')}
[bold cyan]昨日净值:[/bold cyan] {last_nav:.4f if last_nav else 'N/A'}
[bold cyan]估算净值:[/bold cyan] {estimated_nav:.4f if estimated_nav else 'N/A'}
[bold cyan]估算涨跌幅:[/bold cyan] {'[green]' if change_pct >= 0 else '[red]'}{format_percent(change_pct)}[/]
[bold cyan]状态:[/bold cyan] {'✅ 正常' if abs(change_pct) < 3 else '⚠️ 波动'}
[bold cyan]更新时间:[/bold cyan] {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""

    # 主要持仓贡献
    impacts = result.get('holdings_impact', [])[:3]
    if impacts:
        contrib_lines = []
        for imp in impacts:
            sign = "+" if imp['contribution'] >= 0 else ""
            contrib_lines.append(f"{imp['name']}({imp['code']}) {sign}{imp['change']*100:.2f}%")
        content += f"[bold cyan]主要持仓:[/bold cyan] {', '.join(contrib_lines)}"
    
    # 数据源
    ds = result.get('data_source_used', 'unknown')
    content += f"\n[bold cyan]数据源:[/bold cyan] {ds}"
    
    # 警告
    if result.get('warning'):
        content += f"\n[yellow]⚠️  {result['warning']}[/yellow]"
    
    # 错误
    if result.get('error'):
        content += f"\n[red]❌ 错误: {result['error']}[/red]"

    return Panel(content, title=f"📊 {fund_config.get('name', '基金')}", border_style="blue")

@app.command()
def single(
    fund_code: str = typer.Argument(..., help="基金代码，如 159525"),
    verbose: bool = typer.Option(False, "--verbose", "-v")
):
    """查询单只基金估值"""
    console.rule(f"[bold blue]基金估值助手 v2.0[/bold blue]")
    
    # 加载配置（自动热重载）
    fund_config = config_mgr.get_config(fund_code)
    if not fund_config:
        console.print(f"[red]❌ 未找到基金 {fund_code} 的配置[/red]")
        console.print("请先编辑 data/fund_holdings.json 添加配置")
        raise typer.Exit(1)
    
    # 数据源
    ds = EnhancedFundDataSource()
    
    # 计算
    result = estimate_fund_value(fund_config, ds)
    
    # 渲染
    panel = render_fund_result(fund_code, fund_config, result)
    console.print(panel)
    
    # 详细数据
    if verbose:
        console.print("\n[bold]完整持仓贡献：[/bold]")
        table = Table(show_header=True)
        table.add_column("代码")
        table.add_column("名称")
        table.add_column("权重")
        table.add_column("涨跌幅")
        table.add_column("贡献")
        for imp in result.get('holdings_impact', []):
            table.add_row(
                imp['code'],
                imp['name'],
                f"{imp['weight']:.2%}",
                f"{imp['change']*100:+.2f}%",
                f"{imp['contribution']*100:+.2f}%"
            )
        console.print(table)

@app.command()
def all(
    sort_by: str = typer.Option("change", "--sort", "-s", help="排序字段: change, nav, code"),
    threshold: float = typer.Option(3.0, "--threshold", "-t", help="预警阈值 %")
):
    """查询所有配置的基金"""
    console.rule(f"[bold blue]批量查询 - 共 {len(config_mgr.get_config().get('funds', {}))} 只基金[/bold blue]")
    
    config = config_mgr.get_config()
    funds = config.get('funds', {})
    
    ds = EnhancedFundDataSource()
    results = []
    
    with console.status("[bold green]计算中...", spinner="dots") as status:
        for code, fund_config in funds.items():
            status.update(f"处理 {code} - {fund_config.get('name', 'Unknown')}")
            result = estimate_fund_value(fund_config, ds)
            results.append({
                'code': code,
                'name': fund_config.get('name', 'Unknown'),
                'last_nav': result.get('last_nav'),
                'estimated_nav': result.get('estimated_nav'),
                'change_pct': result.get('change_pct', 0),
                'status': result.get('error') is None
            })
            time.sleep(0.1)  # 友好输出
    
    # 排序
    if sort_by == "change":
        results.sort(key=lambda x: abs(x['change_pct']), reverse=True)
    elif sort_by == "nav":
        results.sort(key=lambda x: x.get('estimated_nav') or 0, reverse=True)
    else:
        results.sort(key=lambda x: x['code'])
    
    # 表格输出
    table = Table(title="基金估值概览")
    table.add_column("代码")
    table.add_column("名称")
    table.add_column("昨日净值")
    table.add_column("估算净值")
    table.add_column("涨跌幅")
    table.add_column("状态")
    
    for r in results:
        change_str = format_percent(r['change_pct'])
        change_color = "green" if r['change_pct'] >= 0 else "red"
        status_icon = "✅" if r['status'] else "❌"
        table.add_row(
            r['code'],
            r['name'][:10],
            f"{r['last_nav']:.4f}" if r['last_nav'] else "N/A",
            f"{r['estimated_nav']:.4f}" if r['estimated_nav'] else "N/A",
            f"[{change_color}]{change_str}[/]",
            status_icon
        )
    
    console.print(table)
    
    # 预警统计
    warnings = [r for r in results if abs(r['change_pct']) > threshold and r['status']]
    if warnings:
        console.print(f"\n[yellow]⚠️  以下基金涨跌幅超过 {threshold:.1f}%：[/yellow]")
        for w in warnings:
            console.print(f"  {w['code']} {w['name']}: {format_percent(w['change_pct'])}")

@app.command()
def watch(
    fund_code: str = typer.Argument(None, help="基金代码，不指定则监控所有"),
    interval: int = typer.Option(300, "--interval", "-i", help="刷新间隔(秒)")
):
    """持续观察模式（实时刷新）"""
    console.rule("[bold blue]观察模式 - 按 Ctrl+C 退出[/bold blue]")
    
    try:
        while True:
            console.clear()
            console.print(f"\n[bold]⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/bold]\n")
            
            if fund_code:
                single(fund_code, verbose=False)
            else:
                all(sort_by="change", threshold=3.0)
            
            time.sleep(interval)
    except KeyboardInterrupt:
        console.print("\n[yellow]已退出观察模式[/yellow]")

@app.command()
def history(
    fund_code: str = typer.Argument(..., help="基金代码"),
    days: int = typer.Option(7, "--days", "-d", help="查看最近几天")
):
    """查看历史估算记录"""
    history_file = Path(f"data/history/fund_{fund_code}.jsonl")
    if not history_file.exists():
        console.print(f"[yellow]⚠️  暂无历史数据: {history_file}[/yellow]")
        return
    
    records = []
    with open(history_file, 'r', encoding='utf-8') as f:
        for line in f:
            records.append(json.loads(line.strip()))
    
    # 按时间倒序
    records.sort(key=lambda x: x['timestamp'], reverse=True)
    recent = records[:days]
    
    table = Table(title=f"{fund_code} 近期估算历史")
    table.add_column("时间")
    table.add_column("昨日净值")
    table.add_column("估算净值")
    table.add_column("涨跌幅")
    
    for r in recent:
        ts = datetime.fromisoformat(r['timestamp']).strftime('%m-%d %H:%M')
        change_str = format_percent(r.get('change_pct', 0))
        table.add_row(
            ts,
            f"{r.get('last_nav', 0):.4f}",
            f"{r.get('estimated_nav', 0):.4f}",
            change_str
        )
    
    console.print(table)
    console.print(f"\n共 {len(recent)} 条记录，总计 {len(records)} 条")

# ============================================
# 🚀 新增：监控与盯盘功能（v2.0+） - 基于 monitor.py
# ============================================

@app.command()
def monitor(
    fund_code: str = typer.Argument(None, help="基金代码，不指定则监控所有配置的基金"),
    output: Path = typer.Option("data/monitor_report.json", "--output", "-o", help="输出报告路径")
):
    """
    🚨 执行基金监控（新闻 + 技术分析 + 信号生成）
    
    示例:
        fund-monitor                   # 监控所有基金
        fund-monitor 161725            # 仅监控指定基金
        fund-monitor --output report.json
    """
    try:
        from fund_valuation.monitor import (
            monitor_fund, MonitorCache, export_monitor_report, format_signal_for_notification
        )
        from fund_valuation.config import get_config_manager
    except ImportError as e:
        console.print(f"[red]❌ 导入监控模块失败: {e}[/red]")
        console.print("[yellow]请确保已安装依赖: pip install feedparser beautifulsoup4[/yellow]")
        raise typer.Exit(1)
    
    console.print("[bold magenta]🔍 开始基金监控分析...[/bold magenta]\n")
    
    # 加载配置
    config_mgr = get_config_manager()
    funds = config_mgr.all_funds
    if not funds:
        console.print("[yellow]⚠️  配置中未找到基金，请先运行 `fund-config add` 添加[/yellow]")
        raise typer.Exit(1)
    
    # 要监控的基金列表
    target_codes = [fund_code] if fund_code else list(funds.keys())
    console.print(f"监控基金数量: {len(target_codes)}\n")
    
    # 初始化缓存
    cache = MonitorCache()
    
    signals = []
    for code in target_codes:
        if code not in funds:
            console.print(f"[yellow]⚠️  跳过未知基金: {code}[/yellow]")
            continue
        
        fund_config = funds[code]
        fund_name = fund_config.get("name", code)
        
        console.print(f"[cyan]分析中: {code} - {fund_name}[/cyan]")
        
        signal = monitor_fund(
            fund_code=code,
            fund_name=fund_name,
            user_config={},  # 通过 config_mgr 传递
            cache=cache
        )
        
        if signal:
            signals.append(signal)
            # 打印简要信号
            signal_type_icon = {
                "strong_buy": "🔥",
                "buy": "📈",
                "hold": "⏸️",
                "sell": "📉",
                "strong_sell": "❄️"
            }.get(signal.signal_type.value, "📊")
            
            console.print(f"  {signal_type_icon} 信号: {signal.signal_type.value.upper()} (置信度 {signal.confidence:.0%})")
            console.print(f"     当前净值: {signal.current_nav:.4f}, 预估值: {signal.estimated_nav:.4f if signal.estimated_nav else 'N/A'}")
            console.print(f"     操作建议: {signal.suggested_action[:80]}...")
        else:
            console.print(f"  ⚪ 暂无信号（数据不足或分析失败）")
        
        console.print()  # 空行
    
    # 导出报告
    if signals:
        report = export_monitor_report(signals, output)
        console.print(f"[green]✅ 监控报告已保存: {output}[/green]\n")
        
        # 打印总结
        from fund_valuation.monitor import SignalType
        summary_table = Table(title="信号统计")
        summary_table.add_column("信号类型", style="cyan")
        summary_table.add_column("数量", justify="right")
        for st in SignalType:
            count = sum(1 for s in signals if s.signal_type == st)
            if count > 0:
                summary_table.add_row(st.value, str(count))
        console.print(summary_table)
    else:
        console.print("[yellow]未生成任何监控信号[/yellow]")

@app.command()
def monitor_watch(
    interval: int = typer.Option(3600, "--interval", "-i", help="监控间隔(秒)", min=60)
):
    """
    ⏳ 定时监控模式（每隔指定时间自动运行一次 monitor）
    
    示例:
        fund-monitor-watch --interval 1800   # 每30分钟监控一次
    """
    console.rule("[bold blue]定时监控模式 - 按 Ctrl+C 退出[/bold blue]")
    
    try:
        while True:
            console.clear()
            console.print(f"\n[bold]🔁 监控轮次: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}[/bold]\n")
            
            # 执行监控（不指定 fund_code = 全部）
            # 使用 subprocess 调用更干净
            import subprocess
            result = subprocess.run(
                [sys.executable, str(Path(__file__).parent / "cli_v2.py"), "monitor"],
                capture_output=True,
                text=True
            )
            console.print(result.stdout)
            if result.stderr:
                console.print(f"[red]{result.stderr}[/red]")
            
            console.print(f"\n[dim]下次监控: {datetime.now() + timedelta(seconds=interval)} ({interval}秒后)[/dim]\n")
            console.print("[yellow]按 Ctrl+C 退出监控模式[/]\n")
            
            time.sleep(interval)
            
    except KeyboardInterrupt:
        console.print("\n[green]✅ 已退出监控模式[/green]")

@app.command()
def signals(
    limit: int = typer.Option(10, "--limit", "-l", help="显示最近N条信号")
):
    """
    📰 查看最新监控信号（从报告中读取）
    """
    try:
        from fund_valuation.monitor import SignalType
    except ImportError:
        console.print("[red]监控模块未加载[/red]")
        return
    
    report_file = Path("data/monitor_report.json")
    if not report_file.exists():
        console.print("[yellow]⚠️  未找到监控报告，请先运行 `fund-monitor`[/yellow]")
        raise typer.Exit(1)
    
    with open(report_file, 'r', encoding='utf-8') as f:
        report = json.load(f)
    
    signals_data = report.get("signals", [])
    if not signals_data:
        console.print("[yellow]报告中无信号数据[/yellow]")
        return
    
    console.print(f"[bold]最新 {min(limit, len(signals_data))} 条监控信号[/bold]\n")
    
    for sig in signals_data[-limit:][::-1]:
        signal_type_icon = {
            "strong_buy": "🔥",
            "buy": "📈",
            "hold": "⏸️",
            "sell": "📉",
            "strong_sell": "❄️"
        }.get(sig["signal_type"], "📊")
        
        console.print(Panel.fit(
            f"""[bold]{sig['fund_code']}[/bold] - {sig['signal_type'].upper()}
[green]置信度: {sig['confidence']:.0%}[/green]
[cyan]当前净值: {sig['current_nav']:.4f}[/cyan]
[magenta]建议: {sig['suggested_action'][:100]}...[/magenta]""",
            title=f"{signal_type_icon} {sig['fund_code']}",
            border_style="blue"
        ))
        console.print()

@app.command()
def news(
    fund_code: str = typer.Argument(..., help="基金代码"),
    count: int = typer.Option(5, "--count", "-c", help="显示條数")
):
    """
    📰 查看抓取到的相关新闻
    """
    try:
        from fund_valuation.monitor import MonitorCache, fetch_fund_news_for_fund
        from fund_valuation.config_manager_v2 import load_config
        from datetime import datetime
    except ImportError as e:
        console.print(f"[red]❌ 导入失败: {e}[/red]")
        raise typer.Exit(1)
    
    config = load_config()
    if fund_code not in config.get("funds", {}):
        console.print(f"[red]基金 {fund_code} 未配置[/red]")
        raise typer.Exit(1)
    
    fund_name = config["funds"][fund_code].get("name", fund_code)
    cache = MonitorCache()
    
    # 尝试从缓存读取
    cached = cache.get(fund_code, "news")
    if cached:
        news_items = [type('NewsItem', (), n) for n in cached["items"]]
        console.print(f"[dim]（来自缓存，{datetime.now() - datetime.fromisoformat(cached['cached_at']).replace(tzinfo=None)}前更新）[/dim]\n")
    else:
        with console.status(f"[bold green]正在抓取 {fund_name} 相关新闻..."):
            news_items = fetch_fund_news_for_fund(fund_name, max_items=count)
    
    if not news_items:
        console.print("[yellow]未找到相关新闻[/yellow]")
        return
    
    for item in news_items:
        sentiment_str = f"{item.sentiment:+.2f}" if hasattr(item, 'sentiment') else "0.00"
        sentiment_color = "green" if float(sentiment_str) > 0.1 else "red" if float(sentiment_str) < -0.1 else "yellow"
        
        console.print(Panel(
            f"""[bold]{item.title}[/bold]
[dim]{item.source} · {item.published_at.strftime('%m-%d %H:%M')}[/dim]
{item.summary}
[sentiment_color]情感: {sentiment_str}[/sentiment_color]  [dim]相关性: {getattr(item, 'relevance', 1):.0%}[/dim]
[link]{item.url}[/link]""",
            title="📰 新闻",
            border_style="blue"
        ))
        console.print()

if __name__ == "__main__":
    app()
