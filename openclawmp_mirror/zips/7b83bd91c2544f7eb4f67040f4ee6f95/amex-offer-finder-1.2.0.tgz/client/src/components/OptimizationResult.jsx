/**
 * Optimization Result Component
 * 展示优化计算结果
 */
function OptimizationResult({ path, currency = '$', isBest = false }) {
    if (!path) return null

    const {
        name,
        description,
        type,
        steps,
        rewards,
        totalValue,
        complexity,
        risk,
        notes
    } = path

    // 风险等级颜色
    const riskColors = {
        low: 'var(--accent-green)',
        medium: 'var(--accent-yellow)',
        high: 'var(--accent-red)'
    }

    // 复杂度图标
    const complexityIcons = ['⭐', '⭐⭐', '⭐⭐⭐', '⭐⭐⭐⭐', '⭐⭐⭐⭐⭐']

    return (
        <div className={`path-container ${isBest ? 'best-path' : ''}`}>
            {/* Header */}
            <div className="path-header" style={{
                background: isBest
                    ? 'linear-gradient(135deg, var(--accent-green) 0%, #059669 100%)'
                    : 'linear-gradient(135deg, var(--amex-blue) 0%, var(--amex-blue-dark) 100%)'
            }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-md)' }}>
                    <div className="path-rank">
                        {type === 'direct' ? '📍' : type === 'channel' ? '🎯' : '🎁'}
                    </div>
                    <div>
                        <div style={{ fontWeight: 600, color: 'white' }}>{name}</div>
                        <div style={{ fontSize: '0.75rem', color: 'rgba(255,255,255,0.7)' }}>
                            {description}
                        </div>
                    </div>
                </div>
                <div className="path-value">
                    <div className="path-value-amount">{currency}{totalValue.toFixed(2)}</div>
                    <div className="path-value-label">总价值</div>
                </div>
            </div>

            {/* Steps */}
            <div className="path-steps">
                {steps && steps.map((step, index) => (
                    <div key={index} className="path-step">
                        <div className="path-step-number">{index + 1}</div>
                        <div className="path-step-content">
                            <div className="path-step-action">{step.action}</div>
                            <div className="path-step-amount">
                                {currency}{step.amount?.toFixed(2)}
                                {step.url && (
                                    <a
                                        href={step.url}
                                        target="_blank"
                                        rel="noopener noreferrer"
                                        style={{ marginLeft: 'var(--spacing-sm)' }}
                                    >
                                        🔗
                                    </a>
                                )}
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            {/* Rewards */}
            <div className="path-rewards">
                {rewards.amexPoints > 0 && (
                    <span className="reward-tag highlight">
                        💳 {rewards.amexPoints.toLocaleString()} Amex积分
                    </span>
                )}
                {rewards.cashback > 0 && (
                    <span className="reward-tag highlight">
                        💰 {currency}{rewards.cashback.toFixed(2)} 返现
                    </span>
                )}
                {rewards.channelPoints > 0 && (
                    <span className="reward-tag">
                        ⭐ {rewards.channelPoints.toLocaleString()} 渠道积分
                    </span>
                )}
                {rewards.giftCardDiscount > 0 && (
                    <span className="reward-tag highlight">
                        🎁 {rewards.giftCardDiscount}% 礼品卡折扣
                    </span>
                )}
                <span className="reward-tag">
                    📊 复杂度: {complexityIcons[complexity - 1]}
                </span>
                <span className="reward-tag" style={{ color: riskColors[risk] }}>
                    ⚠️ 风险: {risk === 'low' ? '低' : risk === 'medium' ? '中' : '高'}
                </span>
            </div>

            {/* Notes */}
            {notes && notes.length > 0 && (
                <div style={{
                    padding: 'var(--spacing-md) var(--spacing-lg)',
                    fontSize: '0.75rem',
                    color: 'var(--text-muted)',
                    borderTop: '1px solid var(--bg-tertiary)'
                }}>
                    {notes.map((note, index) => (
                        <div key={index} style={{ marginBottom: 'var(--spacing-xs)' }}>
                            ℹ️ {note}
                        </div>
                    ))}
                </div>
            )}
        </div>
    )
}

export default OptimizationResult
