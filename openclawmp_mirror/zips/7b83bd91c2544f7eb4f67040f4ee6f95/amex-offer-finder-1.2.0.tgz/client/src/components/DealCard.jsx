/**
 * Deal Card Component
 * 展示单个优惠信息
 */
function DealCard({ deal }) {
    const {
        title,
        description,
        source,
        url,
        region,
        category,
        discount,
        isNew,
        createdAt
    } = deal

    // 格式化来源名称
    const sourceLabels = {
        ozbargain: 'Ozbargain',
        reddit: 'Reddit',
        pointhacks: 'Point Hacks',
        aff: 'AFF',
        flyertea: '飞客茶馆',
        wowanka: '我玩卡',
        xiaohongshu: '小红书',
        weibo: '微博'
    }

    // 格式化类别
    const categoryLabels = {
        amex_offer: 'Amex优惠',
        gift_card: '礼品卡',
        cashback: '返现',
        points_bonus: '积分活动',
        other: '其他'
    }

    // 格式化时间
    const formatTime = (dateString) => {
        const date = new Date(dateString)
        const now = new Date()
        const diffMs = now - date
        const diffMins = Math.floor(diffMs / 60000)
        const diffHours = Math.floor(diffMs / 3600000)
        const diffDays = Math.floor(diffMs / 86400000)

        if (diffMins < 60) return `${diffMins}分钟前`
        if (diffHours < 24) return `${diffHours}小时前`
        if (diffDays < 7) return `${diffDays}天前`
        return date.toLocaleDateString('zh-CN')
    }

    return (
        <article className="card deal-card">
            {/* Header */}
            <div className="card-header">
                <div style={{ display: 'flex', gap: 'var(--spacing-xs)', flexWrap: 'wrap' }}>
                    <span className={`deal-badge ${region.toLowerCase()}`}>
                        {region === 'AU' ? '🇦🇺' : '🇨🇳'}
                    </span>
                    {isNew && <span className="deal-badge new">NEW</span>}
                    {discount && discount > 0 && (
                        <span className="deal-badge discount">{discount}% OFF</span>
                    )}
                </div>
                <span className="deal-source">
                    {sourceLabels[source] || source}
                </span>
            </div>

            {/* Title */}
            <h3 className="card-title" style={{
                marginBottom: 'var(--spacing-sm)',
                display: '-webkit-box',
                WebkitLineClamp: 2,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden'
            }}>
                {title}
            </h3>

            {/* Description */}
            {description && (
                <p className="card-content" style={{
                    display: '-webkit-box',
                    WebkitLineClamp: 3,
                    WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                    marginBottom: 'var(--spacing-md)'
                }}>
                    {description}
                </p>
            )}

            {/* Footer */}
            <div style={{
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                marginTop: 'auto',
                paddingTop: 'var(--spacing-md)',
                borderTop: '1px solid var(--bg-tertiary)'
            }}>
                <div style={{ display: 'flex', gap: 'var(--spacing-sm)', alignItems: 'center' }}>
                    <span style={{
                        fontSize: '0.75rem',
                        color: 'var(--text-muted)',
                        background: 'var(--bg-tertiary)',
                        padding: '2px 8px',
                        borderRadius: 'var(--radius-sm)'
                    }}>
                        {categoryLabels[category] || category}
                    </span>
                    <span style={{ fontSize: '0.75rem', color: 'var(--text-muted)' }}>
                        {formatTime(createdAt)}
                    </span>
                </div>

                <a
                    href={url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn btn-outline btn-sm"
                >
                    查看 →
                </a>
            </div>
        </article>
    )
}

export default DealCard
