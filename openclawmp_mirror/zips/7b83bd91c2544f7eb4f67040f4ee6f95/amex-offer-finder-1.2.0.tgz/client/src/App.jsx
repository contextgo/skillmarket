import { BrowserRouter, Routes, Route, NavLink } from 'react-router-dom'
import Dashboard from './pages/Dashboard'
import Optimizer from './pages/Optimizer'
import Settings from './pages/Settings'
import InfoBoard from './pages/InfoBoard'
import './App.css'

function App() {
    return (
        <BrowserRouter>
            <div className="app-container">
                {/* Sidebar */}
                <aside className="sidebar">
                    <div className="logo">
                        <div className="logo-icon">A</div>
                        <div>
                            <div className="logo-text">Amex Finder</div>
                            <div className="logo-subtitle">积分价值最大化</div>
                        </div>
                    </div>

                    <nav>
                        <ul className="nav-menu">
                            <li className="nav-item">
                                <NavLink to="/" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                    <span className="nav-icon">📊</span>
                                    <span>Dashboard</span>
                                </NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink to="/optimizer" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                    <span className="nav-icon">🧮</span>
                                    <span>优化器</span>
                                </NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink to="/info-board" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                    <span className="nav-icon">📱</span>
                                    <span>信息板</span>
                                </NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink to="/settings" className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}>
                                    <span className="nav-icon">⚙️</span>
                                    <span>设置</span>
                                </NavLink>
                            </li>
                        </ul>
                    </nav>

                    <div className="sidebar-footer">
                        <div className="crawl-status">
                            <span className="status-dot"></span>
                            <span className="status-text">自动监控中</span>
                        </div>
                    </div>
                </aside>

                {/* Main Content */}
                <main className="main-content">
                    <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/optimizer" element={<Optimizer />} />
                        <Route path="/info-board" element={<InfoBoard />} />
                        <Route path="/settings" element={<Settings />} />
                    </Routes>
                </main>
            </div>
        </BrowserRouter>
    )
}

export default App

