import { useState } from 'react'
import OptimizationResult from '../components/OptimizationResult'

const API_BASE = '/api'

// 常用商家列表
const popularMerchants = {
    AU: [
        'Woolworths', 'Coles', 'JB Hi-Fi', 'Amazon Australia',
        'Bunnings', 'Myer', 'David Jones', 'Uber', 'The Good Guys'
    ],
    CN: [
        '京东', '天猫', '淘宝', '星巴克', '盒马', '叮咚买菜'
    ]
}

function Optimizer() {
    const [formData, setFormData] = useState({
        merchant: '',
        amount: '',
        region: 'AU'
    })
    const [result, setResult] = useState(null)
    const [loading, setLoading] = useState(false)
    const [error, setError] = useState(null)

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (!formData.merchant || !formData.amount) {
            setError('请填写商家名称和消费金额')
            return
        }

        setLoading(true)
        setError(null)

        try {
            const response = await fetch(`${API_BASE}/optimize`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            })
            const data = await response.json()

            if (data.success) {
                setResult(data.data)
            } else {
                setError(data.error || '优化失败')
            }
        } catch (err) {
            setError('无法连接后端服务。请确保后端已启动: node src/index.js')
        } finally {
            setLoading(false)
        }
    }

    const handleMerchantClick = (merchant) => {
        setFormData({ ...formData, merchant })
    }

    const currency = formData.region === 'CN' ? '¥' : '$'

    return (
        <div className="optimizer fade-in">
            {/* Page Header */}
            <header className="page-header">
                <div>
                    <h1 className="page-title">🧮 积分优化器</h1>
                    <p className="page-description">
                        计算最优的礼品卡购买路径，最大化您的积分价值
                    </p>
                </div>
            </header>

            {/* Optimizer Form */}
            <div className="card" style={{ marginBottom: 'var(--spacing-xl)' }}>
                <form onSubmit={handleSubmit}>
                    <div className="grid grid-3">
                        {/* Region */}
                        <div className="form-group">
                            <label className="form-label">消费地区</label>
                            <select
                                className="form-input form-select"
                                value={formData.region}
                                onChange={(e) => setFormData({ ...formData, region: e.target.value, merchant: '' })}
                            >
                                <option value="AU">🇦🇺 澳洲 (AUD)</option>
                                <option value="CN">🇨🇳 中国 (CNY)</option>
                            </select>
                        </div>

                        {/* Merchant */}
                        <div className="form-group">
                            <label className="form-label">商家名称</label>
                            <input
                                type="text"
                                className="form-input"
                                placeholder="例如: Woolworths, JB Hi-Fi"
                                value={formData.merchant}
                                onChange={(e) => setFormData({ ...formData, merchant: e.target.value })}
                            />
                        </div>

                        {/* Amount */}
                        <div className="form-group">
                            <label className="form-label">消费金额 ({currency})</label>
                            <input
                                type="number"
                                className="form-input"
                                placeholder="例如: 100"
                                value={formData.amount}
                                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                                min="1"
                            />
                        </div>
                    </div>

                    {/* Popular Merchants */}
                    <div style={{ marginBottom: 'var(--spacing-lg)' }}>
                        <label className="form-label">常用商家</label>
                        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 'var(--spacing-sm)' }}>
                            {popularMerchants[formData.region].map(merchant => (
                                <button
                                    key={merchant}
                                    type="button"
                                    className={`filter-chip ${formData.merchant === merchant ? 'active' : ''}`}
                                    onClick={() => handleMerchantClick(merchant)}
                                >
                                    {merchant}
                                </button>
                            ))}
                        </div>
                    </div>

                    {error && (
                        <div style={{
                            color: 'var(--accent-red)',
                            marginBottom: 'var(--spacing-md)',
                            padding: 'var(--spacing-md)',
                            background: 'rgba(239, 68, 68, 0.1)',
                            borderRadius: 'var(--radius-md)'
                        }}>
                            ⚠️ {error}
                        </div>
                    )}

                    <button
                        type="submit"
                        className="btn btn-primary"
                        disabled={loading}
                        style={{ width: '100%', padding: 'var(--spacing-md)' }}
                    >
                        {loading ? '🔄 计算中...' : '🚀 计算最优路径'}
                    </button>
                </form>
            </div>

            {/* Results */}
            {result && (
                <div className="fade-in">
                    <h2 style={{ marginBottom: 'var(--spacing-lg)', color: 'var(--text-primary)' }}>
                        📊 优化结果 - {result.merchant} ({currency}{result.amount})
                    </h2>

                    {/* Best Path */}
                    {result.bestPath && (
                        <div style={{ marginBottom: 'var(--spacing-xl)' }}>
                            <h3 style={{
                                marginBottom: 'var(--spacing-md)',
                                color: 'var(--accent-green)',
                                display: 'flex',
                                alignItems: 'center',
                                gap: 'var(--spacing-sm)'
                            }}>
                                🏆 最优路径
                                {result.bestPath.savingsPercent > 0 && (
                                    <span className="deal-badge new">
                                        节省 {result.bestPath.savingsPercent}%
                                    </span>
                                )}
                            </h3>
                            <OptimizationResult path={result.bestPath} currency={currency} isBest />
                        </div>
                    )}

                    {/* Alternative Paths */}
                    {result.alternativePaths && result.alternativePaths.length > 0 && (
                        <div>
                            <h3 style={{ marginBottom: 'var(--spacing-md)', color: 'var(--text-secondary)' }}>
                                📋 其他路径
                            </h3>
                            <div className="grid grid-2">
                                {result.alternativePaths.map((path, index) => (
                                    <OptimizationResult key={index} path={path} currency={currency} />
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}

            {/* Tips */}
            <div className="card" style={{ marginTop: 'var(--spacing-xl)', background: 'var(--bg-tertiary)' }}>
                <h3 style={{ marginBottom: 'var(--spacing-md)', color: 'var(--text-primary)' }}>
                    💡 使用技巧
                </h3>
                <ul style={{ color: 'var(--text-secondary)', lineHeight: 2, paddingLeft: 'var(--spacing-lg)' }}>
                    <li>通过Cashrewards或ShopBack购买礼品卡可获得额外返现</li>
                    <li>部分礼品卡（如Myer、Coles）可以在店内购买其他礼品卡，实现"套娃"</li>
                    <li>使用Amex信用卡购买礼品卡仍可获得MR积分</li>
                    <li>关注Ozbargain和飞客茶馆获取最新礼品卡折扣信息</li>
                    <li>在设置中可以自定义各积分体系的价值估算</li>
                </ul>
            </div>
        </div>
    )
}

export default Optimizer
