import { useState, useEffect } from 'react'

const API_BASE = '/api'

// 积分体系列表
const pointsSystems = [
    { id: 'amex_mr', name: 'Amex Membership Rewards', shortName: 'Amex MR' },
    { id: 'qantas', name: 'Qantas Frequent Flyer', shortName: 'Qantas' },
    { id: 'velocity', name: 'Velocity Frequent Flyer', shortName: 'Velocity' },
    { id: 'asia_miles', name: 'Asia Miles', shortName: 'Asia Miles' },
    { id: 'flybuys', name: 'Flybuys', shortName: 'Flybuys' },
    { id: 'woolworths_rewards', name: 'Woolworths Everyday Rewards', shortName: 'WW Rewards' }
]

// 卡等级定义
const cardTiers = [
    { id: 1, name: 'Essential/绿卡', color: '#00A651', icon: '💚' },
    { id: 2, name: 'Gold/金卡', color: '#FFD700', icon: '💛' },
    { id: 3, name: 'Platinum/白金卡', color: '#A0A0A0', icon: '🤍' },
    { id: 4, name: 'Centurion/百夫长', color: '#1C1C1C', icon: '🖤' }
]

// 默认设置
const defaultSettings = {
    cardTier: 3,  // 默认白金卡
    pointsValues: {
        amex_mr: { AUD: 0.012, CNY: 0.055 },
        qantas: { AUD: 0.015, CNY: 0.070 },
        velocity: { AUD: 0.016, CNY: 0.075 },
        asia_miles: { AUD: 0.025, CNY: 0.12 },
        flybuys: { AUD: 0.005, CNY: 0.023 },
        woolworths_rewards: { AUD: 0.01, CNY: 0.046 }
    },
    notifications: {
        enabled: true,
        minDiscount: 5
    },
    crawlInterval: 30,
    regions: ['AU', 'CN']
}

function Settings() {
    const [settings, setSettings] = useState(defaultSettings)
    const [loading, setLoading] = useState(true)
    const [saving, setSaving] = useState(false)
    const [message, setMessage] = useState(null)
    const [apiError, setApiError] = useState(false)

    // 加载设置
    const loadSettings = async () => {
        try {
            const response = await fetch(`${API_BASE}/settings`)
            if (!response.ok) throw new Error('API error')
            const data = await response.json()
            if (data.success) {
                setSettings({ ...defaultSettings, ...data.data })
                setApiError(false)
            }
        } catch (error) {
            console.error('Failed to load settings:', error)
            setApiError(true)
            // 使用默认设置
            setSettings(defaultSettings)
        } finally {
            setLoading(false)
        }
    }

    useEffect(() => {
        loadSettings()
    }, [])

    // 保存设置
    const handleSave = async () => {
        setSaving(true)
        try {
            const response = await fetch(`${API_BASE}/settings`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(settings)
            })
            const data = await response.json()
            if (data.success) {
                setMessage({ type: 'success', text: '✅ 设置已保存' })
                setTimeout(() => setMessage(null), 3000)
            }
        } catch (error) {
            setMessage({ type: 'error', text: '❌ 保存失败' })
        } finally {
            setSaving(false)
        }
    }

    // 更新积分价值
    const updatePointsValue = (systemId, currency, value) => {
        const newSettings = { ...settings }
        if (!newSettings.pointsValues[systemId]) {
            newSettings.pointsValues[systemId] = {}
        }
        newSettings.pointsValues[systemId][currency] = parseFloat(value) || 0
        setSettings(newSettings)
    }

    // 测试通知
    const handleTestNotification = async () => {
        try {
            await fetch(`${API_BASE}/notifications/test`, { method: 'POST' })
            setMessage({ type: 'success', text: '🔔 测试通知已发送' })
            setTimeout(() => setMessage(null), 3000)
        } catch (error) {
            setMessage({ type: 'error', text: '❌ 通知发送失败' })
        }
    }

    if (loading) {
        return (
            <div className="loading">
                <div className="loading-spinner"></div>
                <p style={{ marginTop: 'var(--spacing-md)' }}>加载设置...</p>
            </div>
        )
    }

    return (
        <div className="settings fade-in">
            {/* Page Header */}
            <header className="page-header">
                <div>
                    <h1 className="page-title">⚙️ 设置</h1>
                    <p className="page-description">自定义积分价值和通知偏好</p>
                </div>
                <button
                    className="btn btn-primary"
                    onClick={handleSave}
                    disabled={saving}
                >
                    {saving ? '保存中...' : '💾 保存设置'}
                </button>
            </header>

            {/* API Error Warning */}
            {apiError && (
                <div style={{
                    padding: 'var(--spacing-md)',
                    marginBottom: 'var(--spacing-lg)',
                    borderRadius: 'var(--radius-md)',
                    background: 'rgba(245, 158, 11, 0.2)',
                    color: 'var(--accent-yellow)',
                    border: '1px solid var(--accent-yellow)'
                }}>
                    ⚠️ 无法连接后端服务。请确保后端已启动: <code>node src/index.js</code>
                </div>
            )}

            {/* Message */}
            {message && (
                <div style={{
                    padding: 'var(--spacing-md)',
                    marginBottom: 'var(--spacing-lg)',
                    borderRadius: 'var(--radius-md)',
                    background: message.type === 'success' ? 'rgba(16, 185, 129, 0.2)' : 'rgba(239, 68, 68, 0.2)',
                    color: message.type === 'success' ? 'var(--accent-green)' : 'var(--accent-red)'
                }}>
                    {message.text}
                </div>
            )}

            {/* Card Tier Selection */}
            <div className="card" style={{ marginBottom: 'var(--spacing-xl)' }}>
                <h3 style={{ marginBottom: 'var(--spacing-lg)', color: 'var(--text-primary)' }}>
                    💳 我的Amex卡等级
                </h3>
                <p style={{ marginBottom: 'var(--spacing-lg)', color: 'var(--text-muted)' }}>
                    选择您持有的Amex卡等级，系统将为您过滤适用的优惠
                </p>

                <div style={{ display: 'flex', gap: 'var(--spacing-md)', flexWrap: 'wrap' }}>
                    {cardTiers.map(tier => (
                        <button
                            key={tier.id}
                            onClick={() => setSettings({ ...settings, cardTier: tier.id })}
                            style={{
                                flex: '1',
                                minWidth: '140px',
                                padding: 'var(--spacing-md)',
                                border: settings.cardTier === tier.id
                                    ? `3px solid ${tier.color}`
                                    : '2px solid var(--border-color)',
                                borderRadius: 'var(--radius-md)',
                                background: settings.cardTier === tier.id
                                    ? `${tier.color}15`
                                    : 'var(--bg-tertiary)',
                                cursor: 'pointer',
                                transition: 'all 0.2s',
                                transform: settings.cardTier === tier.id ? 'scale(1.02)' : 'scale(1)'
                            }}
                        >
                            <div style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>{tier.icon}</div>
                            <div style={{
                                fontWeight: settings.cardTier === tier.id ? 600 : 400,
                                color: settings.cardTier === tier.id ? tier.color : 'var(--text-primary)'
                            }}>
                                {tier.name}
                            </div>
                            {settings.cardTier === tier.id && (
                                <div style={{
                                    marginTop: '0.5rem',
                                    fontSize: '0.8rem',
                                    color: 'var(--accent-green)'
                                }}>
                                    ✓ 已选择
                                </div>
                            )}
                        </button>
                    ))}
                </div>
            </div>

            {/* Points Values */}
            <div className="card" style={{ marginBottom: 'var(--spacing-xl)' }}>
                <h3 style={{ marginBottom: 'var(--spacing-lg)', color: 'var(--text-primary)' }}>
                    💰 积分价值估算
                </h3>
                <p style={{ marginBottom: 'var(--spacing-lg)', color: 'var(--text-muted)' }}>
                    设置每个积分的货币价值（每分价值），用于计算路径的总价值
                </p>

                <div className="grid grid-2">
                    {pointsSystems.map(system => (
                        <div key={system.id} style={{
                            background: 'var(--bg-tertiary)',
                            padding: 'var(--spacing-md)',
                            borderRadius: 'var(--radius-md)'
                        }}>
                            <div style={{ marginBottom: 'var(--spacing-md)', fontWeight: 500 }}>
                                {system.shortName}
                            </div>
                            <div style={{ display: 'flex', gap: 'var(--spacing-md)' }}>
                                <div style={{ flex: 1 }}>
                                    <label className="form-label">AUD</label>
                                    <input
                                        type="number"
                                        className="form-input"
                                        value={settings.pointsValues?.[system.id]?.AUD || 0}
                                        onChange={(e) => updatePointsValue(system.id, 'AUD', e.target.value)}
                                        step="0.001"
                                        min="0"
                                    />
                                </div>
                                <div style={{ flex: 1 }}>
                                    <label className="form-label">CNY</label>
                                    <input
                                        type="number"
                                        className="form-input"
                                        value={settings.pointsValues?.[system.id]?.CNY || 0}
                                        onChange={(e) => updatePointsValue(system.id, 'CNY', e.target.value)}
                                        step="0.001"
                                        min="0"
                                    />
                                </div>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Notification Settings */}
            <div className="card" style={{ marginBottom: 'var(--spacing-xl)' }}>
                <h3 style={{ marginBottom: 'var(--spacing-lg)', color: 'var(--text-primary)' }}>
                    🔔 通知设置
                </h3>

                <div className="form-group">
                    <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-md)', cursor: 'pointer' }}>
                        <input
                            type="checkbox"
                            checked={settings.notifications?.enabled !== false}
                            onChange={(e) => setSettings({
                                ...settings,
                                notifications: { ...settings.notifications, enabled: e.target.checked }
                            })}
                            style={{ width: 20, height: 20 }}
                        />
                        <span>启用桌面通知</span>
                    </label>
                </div>

                <div className="form-group">
                    <label className="form-label">最低折扣阈值 (%)</label>
                    <input
                        type="number"
                        className="form-input"
                        value={settings.notifications?.minDiscount || 0}
                        onChange={(e) => setSettings({
                            ...settings,
                            notifications: { ...settings.notifications, minDiscount: parseInt(e.target.value) || 0 }
                        })}
                        min="0"
                        max="100"
                        style={{ maxWidth: 200 }}
                    />
                    <p style={{ marginTop: 'var(--spacing-xs)', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                        只有折扣达到此阈值的优惠才会发送通知
                    </p>
                </div>

                <button className="btn btn-secondary" onClick={handleTestNotification}>
                    📤 发送测试通知
                </button>
            </div>

            {/* Crawl Settings */}
            <div className="card" style={{ marginBottom: 'var(--spacing-xl)' }}>
                <h3 style={{ marginBottom: 'var(--spacing-lg)', color: 'var(--text-primary)' }}>
                    🕷️ 爬取设置
                </h3>

                <div className="form-group">
                    <label className="form-label">爬取间隔 (分钟)</label>
                    <input
                        type="number"
                        className="form-input"
                        value={settings.crawlInterval || 30}
                        onChange={(e) => setSettings({
                            ...settings,
                            crawlInterval: parseInt(e.target.value) || 30
                        })}
                        min="5"
                        max="1440"
                        style={{ maxWidth: 200 }}
                    />
                    <p style={{ marginTop: 'var(--spacing-xs)', color: 'var(--text-muted)', fontSize: '0.875rem' }}>
                        自动搜索新优惠的时间间隔
                    </p>
                </div>

                <div className="form-group">
                    <label className="form-label">监控地区</label>
                    <div style={{ display: 'flex', gap: 'var(--spacing-lg)' }}>
                        <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)', cursor: 'pointer' }}>
                            <input
                                type="checkbox"
                                checked={settings.regions?.includes('AU')}
                                onChange={(e) => {
                                    const regions = e.target.checked
                                        ? [...(settings.regions || []), 'AU']
                                        : (settings.regions || []).filter(r => r !== 'AU')
                                    setSettings({ ...settings, regions })
                                }}
                            />
                            <span>🇦🇺 澳洲</span>
                        </label>
                        <label style={{ display: 'flex', alignItems: 'center', gap: 'var(--spacing-sm)', cursor: 'pointer' }}>
                            <input
                                type="checkbox"
                                checked={settings.regions?.includes('CN')}
                                onChange={(e) => {
                                    const regions = e.target.checked
                                        ? [...(settings.regions || []), 'CN']
                                        : (settings.regions || []).filter(r => r !== 'CN')
                                    setSettings({ ...settings, regions })
                                }}
                            />
                            <span>🇨🇳 中国</span>
                        </label>
                    </div>
                </div>
            </div>

            {/* About */}
            <div className="card" style={{ background: 'var(--bg-tertiary)' }}>
                <h3 style={{ marginBottom: 'var(--spacing-md)', color: 'var(--text-primary)' }}>
                    ℹ️ 关于
                </h3>
                <p style={{ color: 'var(--text-secondary)' }}>
                    <strong>Amex Deal Finder</strong> v1.0.0
                </p>
                <p style={{ color: 'var(--text-muted)', marginTop: 'var(--spacing-sm)' }}>
                    帮助您发现散落在互联网上的Amex优惠，并计算最优的礼品卡购买路径，最大化积分价值。
                </p>
                <div style={{ marginTop: 'var(--spacing-lg)', display: 'flex', gap: 'var(--spacing-md)', flexWrap: 'wrap' }}>
                    <a href="https://www.ozbargain.com.au" target="_blank" rel="noopener" className="btn btn-outline btn-sm">
                        Ozbargain
                    </a>
                    <a href="https://www.pointhacks.com.au" target="_blank" rel="noopener" className="btn btn-outline btn-sm">
                        Point Hacks
                    </a>
                    <a href="https://www.flyertea.com" target="_blank" rel="noopener" className="btn btn-outline btn-sm">
                        飞客茶馆
                    </a>
                </div>
            </div>
        </div>
    )
}

export default Settings
