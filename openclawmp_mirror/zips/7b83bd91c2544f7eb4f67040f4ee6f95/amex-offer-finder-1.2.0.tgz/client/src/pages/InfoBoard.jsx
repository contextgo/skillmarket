import { useState, useEffect } from 'react';
import axios from 'axios';
import './InfoBoard.css';

const API_BASE = 'http://localhost:3001/api';

function InfoBoard() {
    const [posts, setPosts] = useState([]);
    const [loading, setLoading] = useState(false);
    const [fetchingPosts, setFetchingPosts] = useState(false);
    const [loginStatus, setLoginStatus] = useState(false);
    const [showLoginModal, setShowLoginModal] = useState(false);
    const [cookieInput, setCookieInput] = useState('');
    const [error, setError] = useState(null);
    const [lastFetch, setLastFetch] = useState(null);

    useEffect(() => {
        loadPosts();
        checkStatus();
    }, []);

    const checkStatus = async () => {
        try {
            const response = await axios.get(`${API_BASE}/xiaohongshu/status`);
            if (response.data.success) {
                setLoginStatus(response.data.data.loggedIn);
                setLastFetch(response.data.data.lastFetch);
            }
        } catch (err) {
            console.error('Failed to check status:', err);
        }
    };

    const loadPosts = async () => {
        setLoading(true);
        try {
            const response = await axios.get(`${API_BASE}/xiaohongshu`);
            if (response.data.success) {
                setPosts(response.data.data);
                setLoginStatus(response.data.loginStatus);
            }
        } catch (err) {
            setError('加载失败');
        } finally {
            setLoading(false);
        }
    };

    const handleLogin = async () => {
        if (!cookieInput.trim()) {
            alert('请输入Cookie');
            return;
        }

        try {
            const response = await axios.post(`${API_BASE}/xiaohongshu/login`, {
                cookies: cookieInput
            });
            if (response.data.success) {
                setLoginStatus(true);
                setShowLoginModal(false);
                setCookieInput('');
                alert('登录成功！');
            }
        } catch (err) {
            alert('登录失败: ' + (err.response?.data?.error || err.message));
        }
    };

    const handleFetchPosts = async () => {
        setFetchingPosts(true);
        try {
            const response = await axios.post(`${API_BASE}/xiaohongshu/fetch`);
            if (response.data.success) {
                alert(`获取成功！新增 ${response.data.data.added} 条，更新 ${response.data.data.updated} 条`);
                loadPosts();
                checkStatus();
            }
        } catch (err) {
            alert('获取失败: ' + (err.response?.data?.error || err.message));
        } finally {
            setFetchingPosts(false);
        }
    };

    const handleVote = async (postId, helpful) => {
        try {
            await axios.post(`${API_BASE}/xiaohongshu/vote`, { postId, helpful });
            loadPosts();
        } catch (err) {
            console.error('Vote failed:', err);
        }
    };

    return (
        <div className="info-board">
            <div className="board-header">
                <h1>📱 信息板 - 小红书</h1>
                <p className="subtitle">
                    ⚠️ 此板块内容来自小红书，可能包含未验证信息，仅供参考
                </p>
            </div>

            <div className="board-actions">
                {!loginStatus ? (
                    <button className="btn-login" onClick={() => setShowLoginModal(true)}>
                        🔑 登录小红书
                    </button>
                ) : (
                    <>
                        <button
                            className="btn-fetch"
                            onClick={handleFetchPosts}
                            disabled={fetchingPosts}
                        >
                            {fetchingPosts ? '⏳ 获取中...' : '🔄 获取最新内容'}
                        </button>
                        <span className="login-status">✅ 已登录</span>
                        {lastFetch && (
                            <span className="last-fetch">
                                上次获取: {new Date(lastFetch).toLocaleString()}
                            </span>
                        )}
                    </>
                )}
            </div>

            {error && <div className="error-banner">{error}</div>}

            {loading ? (
                <div className="loading">加载中...</div>
            ) : posts.length === 0 ? (
                <div className="empty-state">
                    <p>暂无内容</p>
                    <p>请先登录小红书并获取内容</p>
                </div>
            ) : (
                <div className="posts-grid">
                    {posts.map(post => (
                        <div key={post.id} className="post-card">
                            <div className="post-header">
                                <span className="unverified-badge">⚠️ 未验证</span>
                                <span className={`category-badge ${post.category}`}>
                                    {post.category === 'gift_card' ? '🎁 礼品卡' :
                                        post.category === 'cashback' ? '💰 返现' :
                                            post.category === 'points_bonus' ? '✈️ 积分' :
                                                post.category === 'amex_offer' ? '💳 Amex' :
                                                    post.category === 'hotel' ? '🏨 酒店' : '📌 其他'}
                                </span>
                            </div>

                            <h3 className="post-title">
                                <a href={post.url} target="_blank" rel="noopener noreferrer">
                                    {post.title || '无标题'}
                                </a>
                            </h3>

                            {post.description && (
                                <p className="post-desc">{post.description.slice(0, 150)}...</p>
                            )}

                            <div className="post-meta">
                                <span className="author">👤 {post.author || '未知'}</span>
                                <span className="likes">❤️ {post.likeCount || 0}</span>
                                <span className="keyword">🏷️ {post.keyword}</span>
                            </div>

                            <div className="post-votes">
                                <button
                                    className="btn-helpful"
                                    onClick={() => handleVote(post.id, true)}
                                >
                                    👍 有用 ({post.helpful || 0})
                                </button>
                                <button
                                    className="btn-not-helpful"
                                    onClick={() => handleVote(post.id, false)}
                                >
                                    👎 无用 ({post.notHelpful || 0})
                                </button>
                            </div>
                        </div>
                    ))}
                </div>
            )}

            {/* 登录弹窗 */}
            {showLoginModal && (
                <div className="modal-overlay" onClick={() => setShowLoginModal(false)}>
                    <div className="modal-content" onClick={e => e.stopPropagation()}>
                        <h2>🔑 登录小红书</h2>
                        <p>请按以下步骤获取Cookie：</p>
                        <ol className="login-steps">
                            <li>在浏览器中打开 <a href="https://www.xiaohongshu.com" target="_blank" rel="noopener noreferrer">小红书网页版</a></li>
                            <li>登录您的账号</li>
                            <li>按F12打开开发者工具</li>
                            <li>进入 Application {">"} Cookies</li>
                            <li>复制所有Cookie值（或使用插件导出）</li>
                        </ol>
                        <textarea
                            placeholder="粘贴Cookie..."
                            value={cookieInput}
                            onChange={(e) => setCookieInput(e.target.value)}
                            rows={5}
                        />
                        <div className="modal-actions">
                            <button className="btn-cancel" onClick={() => setShowLoginModal(false)}>
                                取消
                            </button>
                            <button className="btn-confirm" onClick={handleLogin}>
                                确认登录
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}

export default InfoBoard;
