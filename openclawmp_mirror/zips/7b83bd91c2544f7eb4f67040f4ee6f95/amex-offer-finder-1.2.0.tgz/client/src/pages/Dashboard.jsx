import { useState, useEffect } from 'react'
import DealCard from '../components/DealCard'

const API_BASE = '/api'

function Dashboard() {
    const [deals, setDeals] = useState([])
    const [loading, setLoading] = useState(true)
    const [crawlStatus, setCrawlStatus] = useState(null)
    const [filters, setFilters] = useState({
        region: 'all',
        category: 'all'
    })
    const [refreshing, setRefreshing] = useState(false)
    const [apiError, setApiError] = useState(false)

    // 加载优惠数据
    const loadDeals = async () => {
        try {
            const params = new URLSearchParams()
            if (filters.region !== 'all') params.append('region', filters.region)
            if (filters.category !== 'all') params.append('category', filters.category)
            params.append('limit', '50')

            const response = await fetch(`${API_BASE}/deals?${params}`)
            if (!response.ok) throw new Error('API error')
            const data = await response.json()

            if (data.success) {
                setDeals(data.data)
                setApiError(false)
            }
        } catch (error) {
            console.error('Failed to load deals:', error)
            setApiError(true)
        } finally {
            setLoading(false)
        }
    }

    // 加载爬虫状态
    const loadCrawlStatus = async () => {
        try {
            const response = await fetch(`${API_BASE}/crawl/status`)
            if (!response.ok) throw new Error('API error')
            const data = await response.json()
            if (data.success) {
                setCrawlStatus(data.data)
            }
        } catch (error) {
            console.error('Failed to load crawl status:', error)
        }
    }

    // 手动刷新
    const handleRefresh = async () => {
        setRefreshing(true)
        try {
            const response = await fetch(`${API_BASE}/crawl`, { method: 'POST' })
            if (!response.ok) throw new Error('API error')
            const data = await response.json()
            if (data.success) {
                setApiError(false)
                await loadDeals()
                await loadCrawlStatus()
            }
        } catch (error) {
            console.error('Refresh failed:', error)
            setApiError(true)
        } finally {
            setRefreshing(false)
        }
    }

    useEffect(() => {
        loadDeals()
        loadCrawlStatus()
    }, [filters])

    // 统计数据
    const stats = {
        total: deals.length,
        new: deals.filter(d => d.isNew).length,
        au: deals.filter(d => d.region === 'AU').length,
        cn: deals.filter(d => d.region === 'CN').length
    }

    return (
        <div className="dashboard fade-in">
            {/* Page Header */}
            <header className="page-header">
                <div>
                    <h1 className="page-title">优惠中心</h1>
                    <p className="page-description">
                        发现最新的Amex优惠和礼品卡折扣
                        {crawlStatus?.lastRun && (
                            <span> · 上次更新: {new Date(crawlStatus.lastRun).toLocaleString('zh-CN')}</span>
                        )}
                    </p>
                </div>
                <button
                    className={`btn btn-primary ${refreshing ? 'pulse' : ''}`}
                    onClick={handleRefresh}
                    disabled={refreshing}
                >
                    {refreshing ? '🔄 刷新中...' : '🔄 立即刷新'}
                </button>
            </header>

            {/* API Error Warning */}
            {apiError && (
                <div style={{
                    padding: 'var(--spacing-md)',
                    marginBottom: 'var(--spacing-lg)',
                    borderRadius: 'var(--radius-md)',
                    background: 'rgba(245, 158, 11, 0.2)',
                    color: 'var(--accent-yellow)',
                    border: '1px solid var(--accent-yellow)'
                }}>
                    ⚠️ 无法连接后端服务。请确保后端已启动: <code>node src/index.js</code>
                </div>
            )}

            {/* Stats */}
            <div className="grid grid-4" style={{ marginBottom: 'var(--spacing-xl)' }}>
                <div className="stat-card">
                    <div className="stat-value">{stats.total}</div>
                    <div className="stat-label">总优惠数</div>
                </div>
                <div className="stat-card">
                    <div className="stat-value" style={{ color: 'var(--accent-green)' }}>{stats.new}</div>
                    <div className="stat-label">新发现</div>
                </div>
                <div className="stat-card">
                    <div className="stat-value">🇦🇺 {stats.au}</div>
                    <div className="stat-label">澳洲优惠</div>
                </div>
                <div className="stat-card">
                    <div className="stat-value">🇨🇳 {stats.cn}</div>
                    <div className="stat-label">中国优惠</div>
                </div>
            </div>

            {/* Filters */}
            <div className="filters">
                <span style={{ color: 'var(--text-muted)', marginRight: 'var(--spacing-sm)' }}>地区:</span>
                {['all', 'AU', 'CN'].map(region => (
                    <button
                        key={region}
                        className={`filter-chip ${filters.region === region ? 'active' : ''}`}
                        onClick={() => setFilters({ ...filters, region })}
                    >
                        {region === 'all' ? '全部' : region === 'AU' ? '🇦🇺 澳洲' : '🇨🇳 中国'}
                    </button>
                ))}

                <span style={{ color: 'var(--text-muted)', marginLeft: 'var(--spacing-md)', marginRight: 'var(--spacing-sm)' }}>类型:</span>
                {[
                    { value: 'all', label: '全部' },
                    { value: 'amex_offer', label: 'Amex优惠' },
                    { value: 'gift_card', label: '礼品卡' },
                    { value: 'cashback', label: '返现' },
                    { value: 'points_bonus', label: '积分活动' }
                ].map(cat => (
                    <button
                        key={cat.value}
                        className={`filter-chip ${filters.category === cat.value ? 'active' : ''}`}
                        onClick={() => setFilters({ ...filters, category: cat.value })}
                    >
                        {cat.label}
                    </button>
                ))}
            </div>

            {/* Deals Grid */}
            {loading ? (
                <div className="loading">
                    <div className="loading-spinner"></div>
                    <p style={{ marginTop: 'var(--spacing-md)' }}>加载中...</p>
                </div>
            ) : deals.length === 0 ? (
                <div className="empty-state">
                    <div className="empty-state-icon">📭</div>
                    <h3>暂无优惠</h3>
                    <p>点击"立即刷新"开始搜索优惠</p>
                </div>
            ) : (
                <div className="grid grid-3">
                    {deals.map((deal, index) => (
                        <DealCard key={deal.id || index} deal={deal} />
                    ))}
                </div>
            )}
        </div>
    )
}

export default Dashboard
