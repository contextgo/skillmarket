#!/usr/bin/env node
/**
 * Skill 安装后自动运行的钩子脚本
 * OpenClaw 安装 skill 后自动执行
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.join(__dirname, '..');

console.log('🎉 Amex Offer Finder Skill 安装完成！\n');

// 检查是否需要运行安装
const nodeModulesExists = fs.existsSync(path.join(rootDir, 'node_modules'));
const clientNodeModulesExists = fs.existsSync(path.join(rootDir, 'client', 'node_modules'));

if (!nodeModulesExists || !clientNodeModulesExists) {
  console.log('📦 检测到依赖未安装，正在自动安装...\n');
  console.log('💡 提示: 如果安装失败，请手动运行:');
  console.log('   npm install');
  console.log('   cd client && npm install\n');
  
  try {
    // 尝试自动安装
    if (!nodeModulesExists) {
      console.log('⏳ 安装后端依赖...');
      execSync('npm install', { cwd: rootDir, stdio: 'inherit' });
    }
    
    if (!clientNodeModulesExists) {
      console.log('⏳ 安装前端依赖...');
      execSync('npm install', { cwd: path.join(rootDir, 'client'), stdio: 'inherit' });
    }
    
    console.log('\n✅ 依赖安装完成！');
  } catch (err) {
    console.log('\n⚠️  自动安装失败，请手动运行上述命令。');
  }
} else {
  console.log('✅ 依赖已安装');
}

// 创建 .env 文件
if (!fs.existsSync(path.join(rootDir, '.env'))) {
  if (fs.existsSync(path.join(rootDir, '.env.example'))) {
    fs.copyFileSync(
      path.join(rootDir, '.env.example'),
      path.join(rootDir, '.env')
    );
    console.log('✅ 已创建 .env 配置文件');
  }
}

console.log('\n🚀 启动命令:');
console.log('   npm run dev     # 同时启动前后端');
console.log('   npm run server  # 仅启动后端');
console.log('\n📖 使用说明: 请查看 SKILL.md');
