#!/bin/bash
# Amex Offer Finder - 自动安装脚本
# 在任何 OpenClaw 环境自动配置

set -e

echo "🚀 Amex Offer Finder 自动安装脚本"
echo "======================================"
echo ""

# 获取脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

cd "$PROJECT_DIR"

# 1. 运行环境检查
echo "📋 步骤 1/4: 检查环境..."
node scripts/check-env.js || exit 1

echo ""
echo "📦 步骤 2/4: 安装后端依赖..."
npm install

echo ""
echo "📦 步骤 3/4: 安装前端依赖..."
cd client
npm install
cd ..

echo ""
echo "⚙️  步骤 4/4: 创建配置文件..."
if [ ! -f ".env" ]; then
    cp .env.example .env
    echo "✅ 已创建 .env 文件 (请根据需要修改配置)"
else
    echo "⚠️  .env 文件已存在，跳过创建"
fi

echo ""
echo "======================================"
echo "✅ 安装完成！"
echo ""
echo "启动命令:"
echo "  npm run dev     # 同时启动前后端"
echo "  npm run server  # 仅启动后端"
echo ""
echo "访问地址:"
echo "  前端: http://localhost:3000"
echo "  API:  http://localhost:3001/api"
echo ""
