#!/usr/bin/env node
/**
 * Amex Offer Finder - 环境检查脚本
 * 在任何 OpenClaw 环境安装时自动检查依赖
 */

import { execSync } from 'child_process';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.join(__dirname, '..');

// 颜色输出
const colors = {
  reset: '\x1b[0m',
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m'
};

function log(message, type = 'info') {
  const color = type === 'success' ? colors.green : 
                type === 'error' ? colors.red : 
                type === 'warning' ? colors.yellow : colors.blue;
  console.log(`${color}${message}${colors.reset}`);
}

// 检查命令是否存在
function checkCommand(command) {
  try {
    execSync(`which ${command}`, { stdio: 'pipe' });
    return true;
  } catch {
    return false;
  }
}

// 检查 Node.js 版本
function checkNodeVersion() {
  try {
    const version = process.version;
    const major = parseInt(version.slice(1).split('.')[0]);
    return { ok: major >= 18, version, major };
  } catch (e) {
    return { ok: false, version: 'unknown', major: 0 };
  }
}

// 检查 npm 版本
function checkNpmVersion() {
  try {
    const output = execSync('npm --version', { encoding: 'utf8', stdio: 'pipe' });
    const version = output.trim();
    const major = parseInt(version.split('.')[0]);
    return { ok: major >= 9, version, major };
  } catch {
    return { ok: false, version: 'unknown', major: 0 };
  }
}

// 主检查函数
async function checkEnvironment() {
  log('🔍 检查 Amex Offer Finder 运行环境...\n', 'info');
  
  const checks = {
    node: { name: 'Node.js', required: '18+' },
    npm: { name: 'npm', required: '9+' },
    git: { name: 'Git', required: '可选' }
  };
  
  let allPassed = true;
  
  // 1. 检查 Node.js
  log('1. 检查 Node.js...', 'info');
  const nodeCheck = checkNodeVersion();
  if (nodeCheck.ok) {
    log(`   ✅ Node.js ${nodeCheck.version} (满足要求 ${checks.node.required})`, 'success');
  } else {
    log(`   ❌ Node.js ${nodeCheck.version} (需要 ${checks.node.required})`, 'error');
    log('   💡 请访问 https://nodejs.org 下载安装 Node.js 18+', 'warning');
    allPassed = false;
  }
  
  // 2. 检查 npm
  log('\n2. 检查 npm...', 'info');
  const npmCheck = checkNpmVersion();
  if (npmCheck.ok) {
    log(`   ✅ npm ${npmCheck.version} (满足要求 ${checks.npm.required})`, 'success');
  } else {
    log(`   ❌ npm ${npmCheck.version} (需要 ${checks.npm.required})`, 'error');
    log('   💡 npm 通常随 Node.js 一起安装', 'warning');
    allPassed = false;
  }
  
  // 3. 检查 Git
  log('\n3. 检查 Git...', 'info');
  if (checkCommand('git')) {
    try {
      const gitVersion = execSync('git --version', { encoding: 'utf8' }).trim();
      log(`   ✅ ${gitVersion} (可选)`, 'success');
    } catch {
      log('   ⚠️  Git 检查失败 (可选)', 'warning');
    }
  } else {
    log('   ⚠️  Git 未安装 (可选，用于更新)', 'warning');
  }
  
  // 4. 检查目录权限
  log('\n4. 检查目录权限...', 'info');
  try {
    const testFile = path.join(rootDir, '.write-test');
    fs.writeFileSync(testFile, '');
    fs.unlinkSync(testFile);
    log('   ✅ 目录可写入', 'success');
  } catch (e) {
    log('   ❌ 目录无写入权限', 'error');
    allPassed = false;
  }
  
  // 5. 检查端口可用性
  log('\n5. 检查默认端口 (3001)...', 'info');
  try {
    const net = await import('net');
    const server = net.createServer();
    await new Promise((resolve, reject) => {
      server.listen(3001, () => {
        server.close();
        resolve();
      });
      server.on('error', reject);
    });
    log('   ✅ 端口 3001 可用', 'success');
  } catch {
    log('   ⚠️  端口 3001 被占用 (可在 .env 中修改 PORT)', 'warning');
  }
  
  // 总结
  log('\n' + '='.repeat(50), 'info');
  if (allPassed) {
    log('✅ 环境检查通过！可以安装依赖并运行。', 'success');
    log('\n下一步:', 'info');
    log('  npm install', 'info');
    log('  cd client && npm install && cd ..', 'info');
    log('  npm run dev', 'info');
  } else {
    log('❌ 环境检查未通过，请解决上述问题后再试。', 'error');
    process.exit(1);
  }
}

// 运行检查
checkEnvironment().catch(err => {
  log(`\n❌ 检查过程出错: ${err.message}`, 'error');
  process.exit(1);
});
