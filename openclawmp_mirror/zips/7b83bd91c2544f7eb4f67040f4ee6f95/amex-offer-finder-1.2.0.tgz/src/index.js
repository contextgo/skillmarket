import express from 'express';
import cors from 'cors';
import cron from 'node-cron';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

import { initDatabase, getSettings } from './data/database.js';
import apiRoutes from './api/routes.js';
import { getCrawlerManager } from './crawlers/CrawlerManager.js';
import { getNotificationManager } from './notifications/NotificationManager.js';
import { getOptimizer } from './optimizer/GiftCardOptimizer.js';
import { seedDatabase } from './data/seed.js';
import { getConfig } from './utils/config.js';
import logger from './utils/logger.js';
import { rateLimiter, securityHeaders, corsOptions, errorHandler } from './middleware/security.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// 加载并验证配置
const config = getConfig();
const PORT = config.PORT;
const IS_DEV = config.NODE_ENV === 'development';

const app = express();

// 安全中间件
app.use(securityHeaders);
app.use(cors(corsOptions));
app.use(express.json({ limit: '10mb' }));
app.use(rateLimiter);

// API路由
app.use('/api', apiRoutes);

// 静态文件服务（仅生产环境，且dist目录存在时）
const distPath = path.join(__dirname, '../client/dist');
if (fs.existsSync(distPath)) {
    app.use(express.static(distPath));

    // SPA回退
    app.get('*', (req, res) => {
        if (!req.path.startsWith('/api')) {
            res.sendFile(path.join(distPath, 'index.html'));
        }
    });
} else if (!IS_DEV) {
    console.log('⚠️ Warning: client/dist not found. Run "npm run build" in client folder for production.');
}

/**
 * 启动应用
 */
async function start() {
    logger.info('🚀 Starting Amex Deal Finder', {
        version: '1.0.1',
        nodeEnv: config.NODE_ENV,
        port: PORT
    });

    try {
        // 1. 初始化数据库
        logger.info('📦 Initializing database...');
        await initDatabase();

        // 2. 加载种子数据
        logger.info('🌱 Loading seed data...');
        await seedDatabase();

        // 3. 初始化优化器
        logger.info('⚙️ Initializing optimizer...');
        await getOptimizer();

        // 4. 初始化通知管理器
        logger.info('🔔 Initializing notification manager...');
        const notificationManager = getNotificationManager();
        notificationManager.initialize();

        // 5. 启动HTTP服务器
        app.listen(PORT, () => {
            logger.info('✅ Server started', {
                url: `http://localhost:${PORT}`,
                api: `http://localhost:${PORT}/api`
            });
        });

        // 6. 设置定时爬取任务
        setupCronJobs();

        // 7. 首次运行爬虫（延迟启动）
        setTimeout(async () => {
            logger.info('🕷️ Running initial crawl...');
            const startTime = Date.now();
            const manager = getCrawlerManager();

            try {
                const result = await manager.runAll();
                const duration = Date.now() - startTime;

                logger.metric('initial_crawl', duration, 'ms', {
                    dealsAdded: result.stats.added,
                    dealsUpdated: result.stats.updated,
                    errors: result.stats.errors
                });

                if (result.stats.added > 0) {
                    await notificationManager.notifyNewDeals();
                }
            } catch (error) {
                logger.error('Initial crawl failed', { error: error.message });
            }
        }, 5000);

    } catch (error) {
        logger.error('❌ Failed to start', { error: error.message, stack: error.stack });
        process.exit(1);
    }
}

// API 路由
app.use('/api', apiRoutes);

// 静态文件服务（仅生产环境，且dist目录存在时）
const distPath = path.join(__dirname, '../client/dist');
if (fs.existsSync(distPath)) {
    app.use(express.static(distPath));

    // SPA回退
    app.get('*', (req, res) => {
        if (!req.path.startsWith('/api')) {
            res.sendFile(path.join(distPath, 'index.html'));
        }
    });
} else if (!IS_DEV) {
    logger.warn('client/dist not found. Run "npm run build" in client folder for production.');
}

// 全局错误处理中间件
app.use(errorHandler);

/**
 * 设置定时任务
 */
function setupCronJobs() {
    const intervalMinutes = config.CRAWL_INTERVAL;

    logger.info('⏰ Setting up scheduled crawl', { intervalMinutes });

    // 定时爬取
    cron.schedule(`*/${intervalMinutes} * * * *`, async () => {
        logger.info('⏰ Scheduled crawl starting...');
        const startTime = Date.now();

        try {
            const manager = getCrawlerManager();
            const result = await manager.runAll();
            const duration = Date.now() - startTime;

            logger.metric('scheduled_crawl', duration, 'ms', {
                dealsAdded: result.stats.added,
                dealsUpdated: result.stats.updated,
                errors: result.stats.errors
            });

            if (result.stats.added > 0 && config.NOTIFICATIONS_ENABLED) {
                const notificationManager = getNotificationManager();
                await notificationManager.notifyNewDeals();
            }
        } catch (error) {
            logger.error('Scheduled crawl failed', { error: error.message });
        }
    });
}

// 优雅退出
process.on('SIGINT', () => {
    logger.info('👋 Shutting down gracefully...');
    process.exit(0);
});

process.on('SIGTERM', () => {
    logger.info('👋 Shutting down gracefully...');
    process.exit(0);
});

// 未捕获异常处理
process.on('uncaughtException', (error) => {
    logger.error('Uncaught Exception', { error: error.message, stack: error.stack });
    process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
    logger.error('Unhandled Rejection', { reason, promise });
});

// 启动
start();
