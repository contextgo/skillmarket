/**
 * 安全中间件
 */

import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import { getConfig } from '../utils/config.js';
import logger from '../utils/logger.js';

const config = getConfig();

/**
 * Rate Limiting 中间件
 */
export const rateLimiter = rateLimit({
    windowMs: config.RATE_LIMIT_WINDOW * 60 * 1000, // 分钟转毫秒
    max: config.RATE_LIMIT_MAX,
    message: {
        success: false,
        error: 'Too many requests, please try again later.',
        retryAfter: Math.ceil(config.RATE_LIMIT_WINDOW * 60)
    },
    standardHeaders: true,
    legacyHeaders: false,
    handler: (req, res, next, options) => {
        logger.warn('Rate limit exceeded', {
            ip: req.ip,
            path: req.path,
            method: req.method
        });
        res.status(429).json(options.message);
    }
});

/**
 * 更严格的 API rate limit
 */
export const apiRateLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, // 15分钟
    max: 100,
    message: {
        success: false,
        error: 'API rate limit exceeded'
    }
});

/**
 * Helmet 安全头
 */
export const securityHeaders = helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'"],
            scriptSrc: ["'self'"],
            imgSrc: ["'self'", "data:", "https:"],
            connectSrc: ["'self'"]
        }
    },
    crossOriginEmbedderPolicy: false // 允许嵌入
});

/**
 * CORS 配置
 */
export const corsOptions = {
    origin: (origin, callback) => {
        // 开发环境允许所有来源
        if (config.NODE_ENV === 'development') {
            callback(null, true);
            return;
        }

        // 生产环境只允许特定来源
        const allowedOrigins = [
            'http://localhost:3000',
            'http://localhost:5173' // Vite 默认端口
        ];

        if (!origin || allowedOrigins.includes(origin)) {
            callback(null, true);
        } else {
            logger.warn('CORS blocked', { origin });
            callback(new Error('Not allowed by CORS'));
        }
    },
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
};

/**
 * 请求验证中间件
 */
export function validateRequest(schema) {
    return (req, res, next) => {
        const errors = [];

        for (const [field, rules] of Object.entries(schema)) {
            const value = req.body[field];

            if (rules.required && (value === undefined || value === null)) {
                errors.push(`${field} is required`);
                continue;
            }

            if (value !== undefined) {
                if (rules.type === 'number' && typeof value !== 'number') {
                    errors.push(`${field} must be a number`);
                }
                if (rules.type === 'string' && typeof value !== 'string') {
                    errors.push(`${field} must be a string`);
                }
                if (rules.min !== undefined && value < rules.min) {
                    errors.push(`${field} must be >= ${rules.min}`);
                }
                if (rules.max !== undefined && value > rules.max) {
                    errors.push(`${field} must be <= ${rules.max}`);
                }
                if (rules.enum && !rules.enum.includes(value)) {
                    errors.push(`${field} must be one of [${rules.enum.join(', ')}]`);
                }
            }
        }

        if (errors.length > 0) {
            logger.warn('Request validation failed', {
                errors,
                path: req.path,
                body: req.body
            });
            return res.status(400).json({
                success: false,
                errors
            });
        }

        next();
    };
}

/**
 * 错误处理中间件
 */
export function errorHandler(err, req, res, next) {
    logger.error('Request error', {
        error: err.message,
        stack: err.stack,
        path: req.path,
        method: req.method,
        ip: req.ip
    });

    // 不要泄露内部错误详情给客户端
    const statusCode = err.statusCode || 500;
    const message = statusCode === 500
        ? 'Internal server error'
        : err.message;

    res.status(statusCode).json({
        success: false,
        error: message
    });
}
