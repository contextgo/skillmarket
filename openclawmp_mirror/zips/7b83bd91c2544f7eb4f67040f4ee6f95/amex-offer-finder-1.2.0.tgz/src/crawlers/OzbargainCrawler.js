import axios from 'axios';
import * as cheerio from 'cheerio';
import { createDeal, DealSource } from '../models/Deal.js';
import { withRetry, withTimeout } from '../utils/retry.js';
import logger from '../utils/logger.js';
import { getConfig } from '../utils/config.js';

/**
 * Ozbargain爬虫 - 使用RSS Feed（绕过Cloudflare）
 */
export class OzbargainCrawler {
    constructor() {
        this.name = 'Ozbargain';
        this.baseUrl = 'https://www.ozbargain.com.au';
        this.region = 'AU';

        this.client = axios.create({
            headers: {
                'User-Agent': 'Mozilla/5.0 (compatible; AmexDealFinder/1.0; +http://localhost)',
                'Accept': 'application/rss+xml, application/xml, text/xml',
            },
            timeout: 30000
        });

        // RSS Feed URLs - 这些不会被Cloudflare阻止
        this.rssFeeds = [
            '/deals/feed',
            '/tag/credit-cards/feed',
            '/tag/gift-cards/feed'
        ];
    }

    async crawl() {
        const deals = [];
        const config = getConfig();

        logger.crawler(this.name, 'Starting crawl', {
            feeds: this.rssFeeds.length,
            timeout: config.CRAWL_TIMEOUT
        });

        for (const feedPath of this.rssFeeds) {
            try {
                const url = `${this.baseUrl}${feedPath}`;
                logger.crawler(this.name, 'Fetching RSS', { url });

                // 使用重试和超时机制
                const response = await withRetry(
                    () => withTimeout(
                        this.client.get(url),
                        config.CRAWL_TIMEOUT,
                        `Request to ${url} timed out`
                    ),
                    {
                        maxRetries: config.MAX_RETRIES,
                        baseDelay: 1000,
                        onRetry: (error, attempt) => {
                            logger.warn(`Retry ${attempt} for ${url}`, {
                                error: error.message,
                                crawler: this.name
                            });
                        }
                    }
                );

                const feedDeals = this.parseRssFeed(response.data, feedPath);
                deals.push(...feedDeals);

                logger.crawler(this.name, 'Feed parsed', {
                    feed: feedPath,
                    dealsFound: feedDeals.length
                });

                // 礼貌延迟
                await this.sleep(1000);
            } catch (error) {
                logger.error(`Failed to fetch ${feedPath}`, {
                    error: error.message,
                    crawler: this.name,
                    feed: feedPath
                });
            }
        }

        const uniqueDeals = this.deduplicateDeals(deals);
        logger.crawler(this.name, 'Crawl completed', {
            totalFound: deals.length,
            uniqueDeals: uniqueDeals.length
        });

        return uniqueDeals;
    }

    parseRssFeed(xml, feedPath) {
        const $ = cheerio.load(xml, { xmlMode: true });
        const deals = [];
        const isTagFeed = feedPath.includes('/tag/');

        $('item').each((i, element) => {
            try {
                const $el = $(element);

                const title = this.cleanText($el.find('title').text());
                const url = $el.find('link').text().trim();
                const descriptionHtml = $el.find('description').text();
                const description = this.cleanText(cheerio.load(descriptionHtml).text()).slice(0, 500);
                const pubDate = $el.find('pubDate').text().trim();

                // 提取categories
                const categories = [];
                $el.find('category').each((j, cat) => {
                    categories.push($(cat).text().trim());
                });

                // 提取ozb:meta数据
                const $meta = $el.find('ozb\\:meta, meta');
                const votesPos = parseInt($meta.attr('votes-pos')) || 0;
                const expiryDate = $meta.attr('expiry');

                // 检查相关性 - 标签feed抓取所有，其他只抓相关的
                const fullText = `${title} ${description}`.toLowerCase();
                if (!isTagFeed && !this.isAmexRelated(fullText) && !fullText.includes('gift card')) {
                    return;
                }

                const deal = createDeal({
                    id: this.generateDealId('ozbargain', url.split('/').pop() || String(i)),
                    title,
                    description,
                    source: DealSource.OZBARGAIN,
                    url,
                    region: 'AU',
                    category: this.categorize(fullText),
                    discount: this.extractDiscount(fullText),
                    createdAt: pubDate ? new Date(pubDate).toISOString() : new Date().toISOString(),
                    expiryDate: expiryDate || null,
                    isActive: true,
                    tags: categories.slice(0, 5)
                });
                deal.votes = votesPos;
                deals.push(deal);
            } catch (error) {
                this.logError('Failed to parse RSS item', error);
            }
        });

        return deals;
    }

    cleanText(text) { return text ? text.replace(/\s+/g, ' ').trim() : ''; }

    isAmexRelated(text) {
        const keywords = ['amex', 'american express', 'membership rewards', '美国运通'];
        return keywords.some(kw => text.toLowerCase().includes(kw));
    }

    extractDiscount(text) {
        const patterns = [/(\d+(?:\.\d+)?)\s*%\s*off/i, /save\s*(\d+(?:\.\d+)?)\s*%/i];
        for (const pattern of patterns) {
            const match = text.match(pattern);
            if (match) return parseFloat(match[1]);
        }
        return null;
    }

    categorize(text) {
        const lower = text.toLowerCase();
        if (lower.includes('gift card')) return 'gift_card';
        if (lower.includes('cashback') || lower.includes('cash back')) return 'cashback';
        if (lower.includes('bonus') || lower.includes('points')) return 'points_bonus';
        if (lower.includes('amex') || lower.includes('american express')) return 'amex_offer';
        if (lower.includes('credit card')) return 'amex_offer';
        return 'other';
    }

    generateDealId(source, id) {
        return `${source}_${String(id).replace(/[^a-zA-Z0-9]/g, '').slice(0, 20)}`;
    }

    deduplicateDeals(deals) {
        const seen = new Set();
        return deals.filter(deal => {
            if (seen.has(deal.url)) return false;
            seen.add(deal.url);
            return true;
        });
    }

    sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
    log(msg) { console.log(`[${this.name}] ${msg}`); }
    logError(msg, err) { console.error(`[${this.name}] ${msg}:`, err?.message || err); }
}

export default OzbargainCrawler;
