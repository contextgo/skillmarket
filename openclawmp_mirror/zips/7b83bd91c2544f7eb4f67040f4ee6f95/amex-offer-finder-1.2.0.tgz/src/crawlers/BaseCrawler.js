import axios from 'axios';
import * as cheerio from 'cheerio';

/**
 * 基础爬虫类
 * 提供通用的HTTP请求和HTML解析方法
 */
export class BaseCrawler {
    constructor(name, baseUrl, region = 'AU') {
        this.name = name;
        this.baseUrl = baseUrl;
        this.region = region;
        this.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-AU,en;q=0.9,zh-CN;q=0.8,zh;q=0.7'
        };
        this.timeout = 30000;
        this.retryCount = 3;
        this.retryDelay = 2000;
    }

    /**
     * 发送HTTP GET请求
     * @param {string} url 
     * @param {Object} options 
     * @returns {Promise<string>}
     */
    async fetch(url, options = {}) {
        const fullUrl = url.startsWith('http') ? url : `${this.baseUrl}${url}`;

        for (let attempt = 1; attempt <= this.retryCount; attempt++) {
            try {
                const response = await axios.get(fullUrl, {
                    headers: { ...this.headers, ...options.headers },
                    timeout: this.timeout,
                    ...options
                });
                return response.data;
            } catch (error) {
                console.error(`[${this.name}] Fetch attempt ${attempt} failed for ${fullUrl}:`, error.message);

                if (attempt < this.retryCount) {
                    await this.sleep(this.retryDelay * attempt);
                } else {
                    throw error;
                }
            }
        }
    }

    /**
     * 发送HTTP GET请求并返回JSON
     * @param {string} url 
     * @param {Object} options 
     * @returns {Promise<Object>}
     */
    async fetchJson(url, options = {}) {
        const fullUrl = url.startsWith('http') ? url : `${this.baseUrl}${url}`;

        for (let attempt = 1; attempt <= this.retryCount; attempt++) {
            try {
                const response = await axios.get(fullUrl, {
                    headers: {
                        ...this.headers,
                        'Accept': 'application/json',
                        ...options.headers
                    },
                    timeout: this.timeout,
                    ...options
                });
                return response.data;
            } catch (error) {
                console.error(`[${this.name}] JSON fetch attempt ${attempt} failed:`, error.message);

                if (attempt < this.retryCount) {
                    await this.sleep(this.retryDelay * attempt);
                } else {
                    throw error;
                }
            }
        }
    }

    /**
     * 解析HTML内容
     * @param {string} html 
     * @returns {cheerio.CheerioAPI}
     */
    parseHtml(html) {
        return cheerio.load(html);
    }

    /**
     * 抽象方法：爬取数据
     * 子类必须实现此方法
     * @returns {Promise<Object[]>}
     */
    async crawl() {
        throw new Error('crawl() method must be implemented by subclass');
    }

    /**
     * 判断是否与Amex相关
     * @param {string} text 
     * @returns {boolean}
     */
    isAmexRelated(text) {
        const keywords = [
            'amex', 'american express', 'membership rewards',
            'amex offer', 'amex platinum', 'amex gold',
            'amex探索卡', '美国运通', '百夫长'
        ];
        const lowerText = text.toLowerCase();
        return keywords.some(keyword => lowerText.includes(keyword));
    }

    /**
     * 判断内容类别
     * @param {string} text 
     * @returns {string}
     */
    categorize(text) {
        const lowerText = text.toLowerCase();

        if (lowerText.includes('gift card') || lowerText.includes('礼品卡') || lowerText.includes('购物卡')) {
            return 'gift_card';
        }
        if (lowerText.includes('cashback') || lowerText.includes('cash back') || lowerText.includes('返现')) {
            return 'cashback';
        }
        if (lowerText.includes('bonus point') || lowerText.includes('积分') || lowerText.includes('points')) {
            return 'points_bonus';
        }
        if (lowerText.includes('amex offer') || lowerText.includes('american express')) {
            return 'amex_offer';
        }

        return 'other';
    }

    /**
     * 提取折扣百分比
     * @param {string} text 
     * @returns {number | null}
     */
    extractDiscount(text) {
        // 匹配 "20% off", "20%折扣", "打8折" 等
        const patterns = [
            /(\d+(?:\.\d+)?)\s*%\s*(?:off|discount|折扣|返)/i,
            /(\d+(?:\.\d+)?)\s*%/,
            /打(\d)折/
        ];

        for (const pattern of patterns) {
            const match = text.match(pattern);
            if (match) {
                let discount = parseFloat(match[1]);
                // 处理 "打8折" = 20% off
                if (pattern.source.includes('打') && discount < 10) {
                    discount = (10 - discount) * 10;
                }
                return discount;
            }
        }

        return null;
    }

    /**
     * 清理文本
     * @param {string} text 
     * @returns {string}
     */
    cleanText(text) {
        return text
            .replace(/\s+/g, ' ')
            .replace(/\n+/g, ' ')
            .trim();
    }

    /**
     * 睡眠函数
     * @param {number} ms 
     * @returns {Promise<void>}
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * 生成Deal ID
     * @param {string} source 
     * @param {string} identifier 
     * @returns {string}
     */
    generateDealId(source, identifier) {
        return `${source}_${identifier}`.replace(/[^a-zA-Z0-9_]/g, '_');
    }

    /**
     * 日志输出
     * @param {string} message 
     */
    log(message) {
        console.log(`[${this.name}] ${message}`);
    }

    /**
     * 错误日志
     * @param {string} message 
     * @param {Error} error 
     */
    logError(message, error) {
        console.error(`[${this.name}] ${message}:`, error?.message || error);
    }
}

export default BaseCrawler;
