import BaseCrawler from './BaseCrawler.js';
import { createDeal, DealSource } from '../models/Deal.js';

/**
 * Point Hacks爬虫
 * 抓取澳洲积分攻略网站的优惠信息
 */
export class PointHacksCrawler extends BaseCrawler {
    constructor() {
        super('PointHacks', 'https://www.pointhacks.com.au', 'AU');
    }

    /**
     * 爬取优惠信息
     * @returns {Promise<Object[]>}
     */
    async crawl() {
        const deals = [];

        try {
            // 抓取主要页面
            const pages = [
                '/deals/',
                '/credit-cards/american-express/',
                '/guides/gift-cards/'
            ];

            for (const page of pages) {
                try {
                    const html = await this.fetch(page);
                    const pageDeals = this.parseDealsPage(html, page);
                    deals.push(...pageDeals);
                    await this.sleep(1500);
                } catch (error) {
                    this.logError(`Failed to fetch ${page}`, error);
                }
            }

            this.log(`Found ${deals.length} deals`);
        } catch (error) {
            this.logError('Crawl failed', error);
        }

        return this.deduplicateDeals(deals);
    }

    /**
     * 解析优惠页面
     * @param {string} html 
     * @param {string} pageUrl 
     * @returns {Object[]}
     */
    parseDealsPage(html, pageUrl) {
        const $ = this.parseHtml(html);
        const deals = [];

        // Point Hacks文章列表
        $('article, .deal-card, .post-card, .entry').each((i, element) => {
            try {
                const $el = $(element);

                // 提取标题和链接
                const $title = $el.find('h2 a, h3 a, .entry-title a, a.title');
                let title = this.cleanText($title.text());
                let url = $title.attr('href');

                // 备用选择器
                if (!title) {
                    const $altTitle = $el.find('a').first();
                    title = this.cleanText($altTitle.text());
                    url = $altTitle.attr('href');
                }

                if (!title || !url) return;

                // 过滤与Amex/礼品卡无关的内容
                const fullText = this.cleanText($el.text());
                if (!this.isAmexRelated(fullText) &&
                    !fullText.toLowerCase().includes('gift card') &&
                    !fullText.toLowerCase().includes('bonus points')) {
                    return;
                }

                // 完整URL
                if (!url.startsWith('http')) {
                    url = `${this.baseUrl}${url}`;
                }

                // 提取描述
                const $description = $el.find('.excerpt, .summary, .entry-content p').first();
                const description = this.cleanText($description.text()).slice(0, 500);

                // 提取日期
                const $date = $el.find('time, .date, .post-date');
                const dateText = $date.attr('datetime') || $date.text();

                const deal = createDeal({
                    id: this.generateDealId('pointhacks', url.split('/').filter(Boolean).pop() || String(i)),
                    title,
                    description: description || title,
                    source: DealSource.POINTHACKS,
                    url,
                    region: 'AU',
                    category: this.categorize(title + ' ' + description),
                    discount: this.extractDiscount(fullText),
                    createdAt: this.parseDate(dateText),
                    isActive: true,
                    tags: this.extractTags($el, $)
                });

                deals.push(deal);
            } catch (error) {
                this.logError('Failed to parse article', error);
            }
        });

        return deals;
    }

    /**
     * 提取标签
     * @param {cheerio.Cheerio} $el 
     * @param {cheerio.CheerioAPI} $ 
     * @returns {string[]}
     */
    extractTags($el, $) {
        const tags = [];
        $el.find('.tag, .category, a[rel="tag"]').each((i, el) => {
            const tag = $(el).text().trim();
            if (tag && !tags.includes(tag)) {
                tags.push(tag);
            }
        });
        return tags;
    }

    /**
     * 解析日期
     * @param {string} dateText 
     * @returns {string}
     */
    parseDate(dateText) {
        if (!dateText) {
            return new Date().toISOString();
        }

        try {
            const date = new Date(dateText);
            if (!isNaN(date.getTime())) {
                return date.toISOString();
            }
        } catch (e) {
            // 忽略解析错误
        }

        return new Date().toISOString();
    }

    /**
     * 去重
     * @param {Object[]} deals 
     * @returns {Object[]}
     */
    deduplicateDeals(deals) {
        const seen = new Set();
        return deals.filter(deal => {
            if (seen.has(deal.url)) {
                return false;
            }
            seen.add(deal.url);
            return true;
        });
    }
}

export default PointHacksCrawler;
