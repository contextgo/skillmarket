import axios from 'axios';
import * as cheerio from 'cheerio';

/**
 * 小红书爬虫
 * 使用用户Session（Cookie）获取小红书内容
 * 需要用户先在浏览器中登录并提供Cookie
 */
export class XiaohongshuCrawler {
    constructor() {
        this.name = '小红书';
        this.baseUrl = 'https://www.xiaohongshu.com';
        this.region = 'CN';
        this.cookies = null;
    }

    /**
     * 设置用户Cookie
     * @param {string} cookies - 从浏览器获取的Cookie字符串
     */
    setCookies(cookies) {
        this.cookies = cookies;
        this.client = axios.create({
            headers: {
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json, text/plain, */*',
                'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
                'Cookie': cookies,
                'Referer': 'https://www.xiaohongshu.com/',
                'Origin': 'https://www.xiaohongshu.com',
            },
            timeout: 30000
        });
    }

    /**
     * 检查是否已设置Cookie
     */
    hasCookies() {
        return !!this.cookies;
    }

    /**
     * 搜索内容
     * @param {string[]} keywords - 搜索关键词
     */
    async crawl(keywords = ['Amex优惠', '美国运通', '白金卡权益', '礼品卡折扣']) {
        if (!this.hasCookies()) {
            this.log('No cookies set. Please login first.');
            return [];
        }

        const posts = [];

        try {
            for (const keyword of keywords) {
                try {
                    const searchPosts = await this.searchKeyword(keyword);
                    posts.push(...searchPosts);
                    await this.sleep(3000 + Math.random() * 2000);
                } catch (error) {
                    this.logError(`Failed to search "${keyword}"`, error);
                }
            }

            this.log(`Found ${posts.length} posts`);
        } catch (error) {
            this.logError('Crawl failed', error);
        }

        return this.deduplicatePosts(posts);
    }

    /**
     * 搜索单个关键词
     * @param {string} keyword 
     */
    async searchKeyword(keyword) {
        const posts = [];

        try {
            // 小红书搜索API
            const searchUrl = `${this.baseUrl}/api/sns/web/v1/search/notes`;

            const response = await this.client.post(searchUrl, {
                keyword,
                page: 1,
                page_size: 20,
                search_id: this.generateSearchId(),
                sort: 'general',
                note_type: 0
            });

            if (response.data?.data?.items) {
                for (const item of response.data.data.items) {
                    const note = item.note_card;
                    if (!note) continue;

                    const post = {
                        id: `xhs_${note.note_id}`,
                        noteId: note.note_id,
                        title: note.title || '',
                        description: note.desc || '',
                        author: note.user?.nickname || '',
                        authorId: note.user?.user_id || '',
                        cover: note.cover?.url || '',
                        likeCount: note.interact_info?.liked_count || 0,
                        url: `https://www.xiaohongshu.com/explore/${note.note_id}`,
                        source: 'xiaohongshu',
                        keyword,
                        category: this.categorize(note.title + ' ' + (note.desc || '')),
                        requiredTier: this.inferTier(note.title + ' ' + (note.desc || ''))
                    };

                    posts.push(post);
                }
            }
        } catch (error) {
            // 如果搜索API失败，尝试解析HTML页面
            this.logError(`Search API failed for "${keyword}", trying HTML parse`, error);
            const htmlPosts = await this.searchKeywordHtml(keyword);
            posts.push(...htmlPosts);
        }

        return posts;
    }

    /**
     * HTML方式搜索（备用方案）
     */
    async searchKeywordHtml(keyword) {
        const posts = [];

        try {
            const url = `${this.baseUrl}/search_result?keyword=${encodeURIComponent(keyword)}&source=web_search_result_notes`;
            const response = await this.client.get(url);
            const $ = cheerio.load(response.data);

            // 解析搜索结果
            $('section.note-item, div.note-item, a[href*="/explore/"]').each((i, el) => {
                const $el = $(el);
                const title = $el.find('.title, .note-title').text().trim();
                const href = $el.attr('href') || $el.find('a').attr('href');

                if (title && href) {
                    const noteId = href.match(/explore\/([a-zA-Z0-9]+)/)?.[1];
                    if (noteId) {
                        posts.push({
                            id: `xhs_${noteId}`,
                            noteId,
                            title,
                            description: '',
                            author: $el.find('.author, .nickname').text().trim(),
                            url: `https://www.xiaohongshu.com/explore/${noteId}`,
                            source: 'xiaohongshu',
                            keyword,
                            category: this.categorize(title)
                        });
                    }
                }
            });
        } catch (error) {
            this.logError('HTML search failed', error);
        }

        return posts;
    }

    /**
     * 生成搜索ID
     */
    generateSearchId() {
        return Math.random().toString(36).substring(2, 15);
    }

    /**
     * 分类
     */
    categorize(text) {
        const lower = text.toLowerCase();
        if (lower.includes('礼品卡') || lower.includes('购物卡') || lower.includes('gift card')) return 'gift_card';
        if (lower.includes('返现') || lower.includes('cashback')) return 'cashback';
        if (lower.includes('积分') || lower.includes('里程') || lower.includes('points')) return 'points_bonus';
        if (lower.includes('amex') || lower.includes('运通')) return 'amex_offer';
        if (lower.includes('酒店') || lower.includes('fhr')) return 'hotel';
        return 'other';
    }

    /**
     * 推断所需卡等级
     */
    inferTier(text) {
        const lower = text.toLowerCase();
        if (lower.includes('百夫长') || lower.includes('centurion') || lower.includes('黑卡')) return 'centurion';
        if (lower.includes('白金') || lower.includes('platinum')) return 'platinum_plus';
        if (lower.includes('金卡') || lower.includes('gold')) return 'gold_plus';
        return 'all';
    }

    /**
     * 去重
     */
    deduplicatePosts(posts) {
        const seen = new Set();
        return posts.filter(post => {
            if (seen.has(post.id)) return false;
            seen.add(post.id);
            return true;
        });
    }

    sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
    log(msg) { console.log(`[${this.name}] ${msg}`); }
    logError(msg, err) { console.error(`[${this.name}] ${msg}:`, err?.message || err); }
}

// 单例
let xiaohongshuCrawler = null;

export function getXiaohongshuCrawler() {
    if (!xiaohongshuCrawler) {
        xiaohongshuCrawler = new XiaohongshuCrawler();
    }
    return xiaohongshuCrawler;
}

export default XiaohongshuCrawler;
