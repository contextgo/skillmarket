import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import * as cheerio from 'cheerio';

// 添加stealth插件以绕过反爬虫检测
puppeteer.use(StealthPlugin());

/**
 * 基于Puppeteer的爬虫基类
 * 使用真实浏览器绕过反爬虫保护
 */
export class PuppeteerCrawler {
    constructor(name, baseUrl, region = 'AU') {
        this.name = name;
        this.baseUrl = baseUrl;
        this.region = region;
        this.browser = null;
        this.page = null;
    }

    /**
     * 初始化浏览器
     */
    async initBrowser() {
        if (!this.browser) {
            console.log(`[${this.name}] Launching browser...`);
            this.browser = await puppeteer.launch({
                headless: 'new',
                args: [
                    '--no-sandbox',
                    '--disable-setuid-sandbox',
                    '--disable-dev-shm-usage',
                    '--disable-accelerated-2d-canvas',
                    '--no-first-run',
                    '--no-zygote',
                    '--disable-gpu',
                    '--window-size=1920,1080'
                ]
            });
            this.page = await this.browser.newPage();

            // 设置视窗大小
            await this.page.setViewport({ width: 1920, height: 1080 });

            // 设置User-Agent
            await this.page.setUserAgent(
                'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
            );

            // 设置额外HTTP头
            await this.page.setExtraHTTPHeaders({
                'Accept-Language': 'en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            });
        }
        return this.page;
    }

    /**
     * 关闭浏览器
     */
    async closeBrowser() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
            this.page = null;
        }
    }

    /**
     * 访问页面并获取HTML
     * @param {string} url 
     * @param {number} waitTime 等待时间(ms)
     * @returns {Promise<string>}
     */
    async fetchPage(url, waitTime = 3000) {
        const page = await this.initBrowser();
        const fullUrl = url.startsWith('http') ? url : `${this.baseUrl}${url}`;

        console.log(`[${this.name}] Fetching: ${fullUrl}`);

        try {
            await page.goto(fullUrl, {
                waitUntil: 'networkidle2',
                timeout: 30000
            });

            // 等待页面内容加载
            await this.sleep(waitTime);

            // 滚动页面以触发懒加载
            await page.evaluate(() => {
                window.scrollTo(0, document.body.scrollHeight / 2);
            });
            await this.sleep(1000);

            // 获取HTML
            const html = await page.content();
            return html;
        } catch (error) {
            console.error(`[${this.name}] Failed to fetch ${fullUrl}:`, error.message);
            throw error;
        }
    }

    /**
     * 解析HTML
     * @param {string} html 
     * @returns {cheerio.CheerioAPI}
     */
    parseHtml(html) {
        return cheerio.load(html);
    }

    /**
     * 清理文本
     * @param {string} text 
     * @returns {string}
     */
    cleanText(text) {
        if (!text) return '';
        return text.replace(/\s+/g, ' ').trim();
    }

    /**
     * 睡眠函数
     * @param {number} ms 
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    /**
     * 判断是否Amex相关
     * @param {string} text 
     * @returns {boolean}
     */
    isAmexRelated(text) {
        const keywords = [
            'amex', 'american express', 'membership rewards',
            '美国运通', '运通卡', '百夫长'
        ];
        const lowerText = text.toLowerCase();
        return keywords.some(kw => lowerText.includes(kw));
    }

    /**
     * 提取折扣
     * @param {string} text 
     * @returns {number|null}
     */
    extractDiscount(text) {
        const patterns = [
            /(\d+(?:\.\d+)?)\s*%\s*off/i,
            /(\d+(?:\.\d+)?)\s*%\s*discount/i,
            /(\d+(?:\.\d+)?)\s*折/,
            /save\s*(\d+(?:\.\d+)?)\s*%/i
        ];
        for (const pattern of patterns) {
            const match = text.match(pattern);
            if (match) {
                return parseFloat(match[1]);
            }
        }
        return null;
    }

    /**
     * 分类
     * @param {string} text 
     * @returns {string}
     */
    categorize(text) {
        const lower = text.toLowerCase();
        if (lower.includes('gift card') || lower.includes('礼品卡') || lower.includes('购物卡')) {
            return 'gift_card';
        }
        if (lower.includes('cashback') || lower.includes('返现') || lower.includes('cash back')) {
            return 'cashback';
        }
        if (lower.includes('bonus') || lower.includes('积分') || lower.includes('points')) {
            return 'points_bonus';
        }
        if (lower.includes('amex') || lower.includes('american express') || lower.includes('运通')) {
            return 'amex_offer';
        }
        return 'other';
    }

    /**
     * 生成Deal ID
     * @param {string} source 
     * @param {string} identifier 
     * @returns {string}
     */
    generateDealId(source, identifier) {
        const clean = String(identifier).replace(/[^a-zA-Z0-9]/g, '').slice(0, 20);
        return `${source}_${clean}`;
    }

    /**
     * 日志
     * @param {string} message 
     */
    log(message) {
        console.log(`[${this.name}] ${message}`);
    }

    /**
     * 错误日志
     * @param {string} message 
     * @param {Error} error 
     */
    logError(message, error) {
        console.error(`[${this.name}] ${message}:`, error?.message || error);
    }
}

export default PuppeteerCrawler;
