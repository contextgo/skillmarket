import BaseCrawler from './BaseCrawler.js';
import { createDeal, DealSource } from '../models/Deal.js';

/**
 * Reddit爬虫
 * 通过Reddit JSON API抓取相关subreddit的帖子
 */
export class RedditCrawler extends BaseCrawler {
    constructor() {
        super('Reddit', 'https://www.reddit.com', 'AU');
        this.subreddits = [
            { name: 'amex', region: 'AU' },
            { name: 'churningaustralia', region: 'AU' },
            { name: 'AusFinance', region: 'AU' },
            { name: 'churning', region: 'AU' }  // 通用积分讨论
        ];
    }

    /**
     * 爬取所有相关subreddit
     * @returns {Promise<Object[]>}
     */
    async crawl() {
        const allDeals = [];

        for (const subreddit of this.subreddits) {
            try {
                const deals = await this.crawlSubreddit(subreddit.name, subreddit.region);
                allDeals.push(...deals);
                await this.sleep(2000); // Reddit API rate limiting
            } catch (error) {
                this.logError(`Failed to crawl r/${subreddit.name}`, error);
            }
        }

        this.log(`Found ${allDeals.length} deals from Reddit`);
        return allDeals;
    }

    /**
     * 爬取单个subreddit
     * @param {string} subredditName 
     * @param {string} region 
     * @returns {Promise<Object[]>}
     */
    async crawlSubreddit(subredditName, region) {
        const deals = [];

        try {
            // Reddit JSON API
            const url = `https://www.reddit.com/r/${subredditName}/search.json?q=amex+OR+%22gift+card%22+OR+%22american+express%22&restrict_sr=1&sort=new&limit=50`;

            const data = await this.fetchJson(url);

            if (!data?.data?.children) {
                return deals;
            }

            for (const child of data.data.children) {
                const post = child.data;

                // 过滤掉低质量帖子
                if (post.score < 1 || post.removed_by_category) {
                    continue;
                }

                const fullText = `${post.title} ${post.selftext || ''}`;

                // 只要与Amex或礼品卡相关的帖子
                if (!this.isAmexRelated(fullText) &&
                    !fullText.toLowerCase().includes('gift card') &&
                    !fullText.toLowerCase().includes('points')) {
                    continue;
                }

                const deal = createDeal({
                    id: this.generateDealId('reddit', post.id),
                    title: this.cleanText(post.title),
                    description: this.cleanText(post.selftext || '').slice(0, 500),
                    source: DealSource.REDDIT,
                    url: `https://www.reddit.com${post.permalink}`,
                    region,
                    category: this.categorize(fullText),
                    discount: this.extractDiscount(fullText),
                    createdAt: new Date(post.created_utc * 1000).toISOString(),
                    isActive: !post.archived,
                    tags: [subredditName, ...(post.link_flair_text ? [post.link_flair_text] : [])]
                });

                // 添加Reddit特有元数据
                deal.score = post.score;
                deal.numComments = post.num_comments;
                deal.subreddit = subredditName;

                deals.push(deal);
            }

        } catch (error) {
            this.logError(`Failed to fetch r/${subredditName}`, error);
        }

        return deals;
    }

    /**
     * 搜索特定关键词
     * @param {string} query 
     * @returns {Promise<Object[]>}
     */
    async search(query) {
        const deals = [];

        try {
            const encodedQuery = encodeURIComponent(query);
            const url = `https://www.reddit.com/search.json?q=${encodedQuery}&sort=new&limit=25`;

            const data = await this.fetchJson(url);

            if (data?.data?.children) {
                for (const child of data.data.children) {
                    const post = child.data;

                    if (post.score < 1) continue;

                    const deal = createDeal({
                        id: this.generateDealId('reddit', post.id),
                        title: this.cleanText(post.title),
                        description: this.cleanText(post.selftext || '').slice(0, 500),
                        source: DealSource.REDDIT,
                        url: `https://www.reddit.com${post.permalink}`,
                        region: 'AU',
                        category: this.categorize(post.title),
                        createdAt: new Date(post.created_utc * 1000).toISOString(),
                        isActive: true,
                        tags: [post.subreddit]
                    });

                    deals.push(deal);
                }
            }

        } catch (error) {
            this.logError('Search failed', error);
        }

        return deals;
    }
}

export default RedditCrawler;
