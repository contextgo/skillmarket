import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { createDeal, DealSource } from '../models/Deal.js';
import { withRetry } from '../utils/retry.js';
import logger from '../utils/logger.js';

puppeteer.use(StealthPlugin());

/**
 * 我玩卡爬虫 - 使用 Puppeteer 绕过防护
 */
export class WowankaCrawler {
    constructor() {
        this.name = '我玩卡';
        this.baseUrl = 'https://www.wowanka.com';
        this.region = 'CN';
        this.browser = null;

        // 目标版块
        this.sections = [
            { fid: 48, name: '信用卡优惠' },
            { fid: 50, name: '积分兑换' },
        ];
    }

    async init() {
        if (!this.browser) {
            this.browser = await puppeteer.launch({
                headless: 'new',
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            });
        }
    }

    async crawl() {
        await this.init();
        const deals = [];

        logger.crawler(this.name, 'Starting crawl', { sections: this.sections.length });

        for (const section of this.sections) {
            try {
                const sectionDeals = await withRetry(
                    () => this.crawlSection(section),
                    {
                        maxRetries: 2,
                        baseDelay: 3000,
                        onRetry: (err, attempt) => {
                            logger.warn(`Retry ${attempt} for section ${section.fid}`, {
                                error: err.message,
                                crawler: this.name
                            });
                        }
                    }
                );
                deals.push(...sectionDeals);
            } catch (error) {
                logger.error(`Failed to crawl section ${section.fid}`, {
                    error: error.message,
                    crawler: this.name
                });
            }
        }

        // 也尝试搜索关键词
        try {
            const searchDeals = await this.crawlSearch('amex');
            deals.push(...searchDeals);
        } catch (error) {
            logger.error('Search crawl failed', { error: error.message, crawler: this.name });
        }

        logger.crawler(this.name, 'Crawl completed', { dealsFound: deals.length });
        return this.deduplicateDeals(deals);
    }

    async crawlSection(section) {
        const page = await this.browser.newPage();
        const deals = [];

        try {
            const url = `${this.baseUrl}/forum-${section.fid}-1.html`;
            logger.crawler(this.name, 'Fetching section', { url, section: section.name });

            await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });

            // 等待帖子列表
            await page.waitForSelector('tbody[id^="normalthread_"], .threadlist', { timeout: 10000 });

            const posts = await page.evaluate(() => {
                const results = [];
                const rows = document.querySelectorAll('tbody[id^="normalthread_"], tbody[id^="stickthread_"]');

                rows.forEach(row => {
                    const titleEl = row.querySelector('a.s.xst, th a.xst, .subject a');
                    const timeEl = row.querySelector('td.by em, .date, time');
                    const authorEl = row.querySelector('td.by cite a');

                    if (titleEl) {
                        results.push({
                            title: titleEl.textContent.trim(),
                            url: titleEl.href,
                            time: timeEl ? timeEl.textContent.trim() : '',
                            author: authorEl ? authorEl.textContent.trim() : ''
                        });
                    }
                });

                return results;
            });

            for (const post of posts) {
                if (!this.isRelevantPost(post.title)) continue;

                const deal = createDeal({
                    id: this.generateDealId('wowanka', post.url),
                    title: this.cleanText(post.title),
                    description: this.cleanText(post.title),
                    source: DealSource.WOWANKA,
                    url: post.url,
                    region: 'CN',
                    category: this.categorize(post.title),
                    discount: this.extractDiscount(post.title),
                    createdAt: this.parseDate(post.time),
                    isActive: true,
                    tags: ['我玩卡', section.name],
                    author: post.author
                });

                deals.push(deal);
            }

            logger.crawler(this.name, 'Section parsed', {
                section: section.name,
                postsFound: posts.length,
                dealsFound: deals.length
            });

        } catch (error) {
            logger.error(`Error crawling section ${section.fid}`, {
                error: error.message,
                crawler: this.name
            });
        } finally {
            await page.close();
        }

        return deals;
    }

    async crawlSearch(keyword) {
        const page = await this.browser.newPage();
        const deals = [];

        try {
            const searchUrl = `${this.baseUrl}/search.php?mod=forum&searchid=&orderby=lastpost&ascdesc=desc&searchsubmit=yes&kw=${encodeURIComponent(keyword)}`;
            logger.crawler(this.name, 'Searching', { keyword, url: searchUrl });

            await page.goto(searchUrl, { waitUntil: 'networkidle2', timeout: 30000 });

            // 等待搜索结果
            await page.waitForSelector('.threadlist, .search-result', { timeout: 10000 });

            const posts = await page.evaluate(() => {
                const results = [];
                const items = document.querySelectorAll('.threadlist li, .search-result li, tbody[id^="normalthread_"]');

                items.forEach(item => {
                    const titleEl = item.querySelector('a.s.xst, .subject a, h3 a');
                    const timeEl = item.querySelector('.date, time, em');

                    if (titleEl) {
                        results.push({
                            title: titleEl.textContent.trim(),
                            url: titleEl.href,
                            time: timeEl ? timeEl.textContent.trim() : ''
                        });
                    }
                });

                return results;
            });

            for (const post of posts.slice(0, 20)) { // 限制搜索结果数量
                const deal = createDeal({
                    id: this.generateDealId('wowanka_search', post.url),
                    title: this.cleanText(post.title),
                    description: this.cleanText(post.title),
                    source: DealSource.WOWANKA,
                    url: post.url,
                    region: 'CN',
                    category: this.categorize(post.title),
                    discount: this.extractDiscount(post.title),
                    createdAt: this.parseDate(post.time),
                    isActive: true,
                    tags: ['我玩卡', '搜索']
                });

                deals.push(deal);
            }

            logger.crawler(this.name, 'Search completed', {
                keyword,
                resultsFound: posts.length,
                dealsFound: deals.length
            });

        } catch (error) {
            logger.error('Search error', { error: error.message, crawler: this.name });
        } finally {
            await page.close();
        }

        return deals;
    }

    isRelevantPost(text) {
        if (!text) return false;
        const keywords = [
            'amex', '美国运通', '运通', '百夫长', 'ae',
            '礼品卡', '购物卡', '返现', 'cashback',
            '积分', '里程', 'mr积分', 'amex积分',
            '白金卡', '金卡', '信用卡', '刷卡',
            '羊毛', '优惠', '折扣', '活动'
        ];
        const lowerText = text.toLowerCase();
        return keywords.some(kw => lowerText.includes(kw));
    }

    cleanText(text) {
        return text ? text.replace(/\s+/g, ' ').trim() : '';
    }

    extractDiscount(text) {
        const match = text.match(/(\d+(?:\.\d+)?)\s*折/);
        if (match) return parseFloat(match[1]) * 10;

        const percentMatch = text.match(/(\d+(?:\.\d+)?)\s*%/);
        if (percentMatch) return parseFloat(percentMatch[1]);

        return null;
    }

    categorize(text) {
        const lower = text.toLowerCase();
        if (lower.includes('礼品卡') || lower.includes('购物卡')) return 'gift_card';
        if (lower.includes('返现') || lower.includes('cashback')) return 'cashback';
        if (lower.includes('积分') || lower.includes('里程')) return 'points_bonus';
        if (lower.includes('amex') || lower.includes('运通') || lower.includes('ae')) return 'amex_offer';
        return 'other';
    }

    parseDate(dateText) {
        if (!dateText) return new Date().toISOString();

        const now = new Date();

        if (dateText.includes('昨天')) {
            now.setDate(now.getDate() - 1);
            return now.toISOString();
        }
        if (dateText.includes('前天')) {
            now.setDate(now.getDate() - 2);
            return now.toISOString();
        }

        const daysAgo = dateText.match(/(\d+)\s*天前/);
        if (daysAgo) {
            now.setDate(now.getDate() - parseInt(daysAgo[1]));
            return now.toISOString();
        }

        const hoursAgo = dateText.match(/(\d+)\s*小时前/);
        if (hoursAgo) {
            now.setHours(now.getHours() - parseInt(hoursAgo[1]));
            return now.toISOString();
        }

        try {
            const date = new Date(dateText.replace(/-/g, '/'));
            if (!isNaN(date.getTime())) {
                return date.toISOString();
            }
        } catch (e) {
            // ignore
        }

        return now.toISOString();
    }

    generateDealId(source, url) {
        const match = url.match(/tid=(\d+)/);
        const id = match ? match[1] : String(Date.now());
        return `${source}_${id}`;
    }

    deduplicateDeals(deals) {
        const seen = new Set();
        return deals.filter(deal => {
            const key = deal.url || deal.title;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    async close() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }
}

export default WowankaCrawler;
