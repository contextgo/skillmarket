import BaseCrawler from './BaseCrawler.js';
import { createDeal, DealSource } from '../models/Deal.js';

/**
 * Australian Frequent Flyer爬虫
 * 抓取澳洲最大常旅客论坛的优惠信息
 */
export class AFFCrawler extends BaseCrawler {
    constructor() {
        super('AustralianFrequentFlyer', 'https://www.australianfrequentflyer.com.au', 'AU');
    }

    /**
     * 爬取优惠信息
     * @returns {Promise<Object[]>}
     */
    async crawl() {
        const deals = [];

        try {
            // 搜索相关版块
            const sections = [
                '/community/forums/credit-cards.32/',
                '/community/forums/deals-offers.47/',
                '/community/search/?q=amex&o=date',
                '/community/search/?q=gift+card&o=date'
            ];

            for (const section of sections) {
                try {
                    const html = await this.fetch(section);
                    const pageDeals = this.parseForumPage(html);
                    deals.push(...pageDeals);
                    await this.sleep(2000);
                } catch (error) {
                    this.logError(`Failed to fetch ${section}`, error);
                }
            }

            this.log(`Found ${deals.length} deals`);
        } catch (error) {
            this.logError('Crawl failed', error);
        }

        return this.deduplicateDeals(deals);
    }

    /**
     * 解析论坛页面（XenForo结构）
     * @param {string} html 
     * @returns {Object[]}
     */
    parseForumPage(html) {
        const $ = this.parseHtml(html);
        const deals = [];

        // XenForo论坛结构
        $('.structItem, .discussionListItem, article.message').each((i, element) => {
            try {
                const $el = $(element);

                // 提取标题和链接
                const $title = $el.find('.structItem-title a, h3.title a, a[data-preview-url]');
                const title = this.cleanText($title.first().text());
                let url = $title.first().attr('href');

                if (!title) return;

                // 过滤无关帖子
                const fullText = this.cleanText($el.text());
                if (!this.isAmexRelated(fullText) &&
                    !fullText.toLowerCase().includes('gift card') &&
                    !fullText.toLowerCase().includes('credit card')) {
                    return;
                }

                // 完整URL
                if (url && !url.startsWith('http')) {
                    url = `${this.baseUrl}${url}`;
                }

                // 提取描述
                const $snippet = $el.find('.structItem-snippet, .snippet');
                const description = this.cleanText($snippet.text()).slice(0, 500);

                // 提取时间
                const $time = $el.find('time, .structItem-startDate a');
                const timeText = $time.attr('datetime') || $time.text();

                // 提取回复数
                const $replies = $el.find('.structItem-cell--meta dd, .stats .major');
                const replies = parseInt($replies.first().text()) || 0;

                const pathParts = url?.split('/') || [];
                const postId = pathParts[pathParts.length - 1]?.replace(/[^0-9]/g, '') || String(i);

                const deal = createDeal({
                    id: this.generateDealId('aff', postId),
                    title,
                    description: description || title,
                    source: DealSource.AFF,
                    url: url || this.baseUrl,
                    region: 'AU',
                    category: this.categorize(title + ' ' + description),
                    discount: this.extractDiscount(fullText),
                    createdAt: this.parseDate(timeText),
                    isActive: true,
                    tags: this.extractTags($el, $)
                });

                deal.replies = replies;

                deals.push(deal);
            } catch (error) {
                this.logError('Failed to parse thread', error);
            }
        });

        return deals;
    }

    /**
     * 提取标签
     * @param {cheerio.Cheerio} $el 
     * @param {cheerio.CheerioAPI} $ 
     * @returns {string[]}
     */
    extractTags($el, $) {
        const tags = ['AFF'];
        $el.find('.tagItem, .label').each((i, el) => {
            const tag = $(el).text().trim();
            if (tag && !tags.includes(tag)) {
                tags.push(tag);
            }
        });
        return tags;
    }

    /**
     * 解析日期
     * @param {string} dateText 
     * @returns {string}
     */
    parseDate(dateText) {
        if (!dateText) {
            return new Date().toISOString();
        }

        // 处理相对时间
        const now = new Date();

        if (dateText.includes('Today') || dateText.includes('今天')) {
            return now.toISOString();
        }
        if (dateText.includes('Yesterday') || dateText.includes('昨天')) {
            now.setDate(now.getDate() - 1);
            return now.toISOString();
        }

        const minutesMatch = dateText.match(/(\d+)\s*minutes?\s*ago/i);
        if (minutesMatch) {
            now.setMinutes(now.getMinutes() - parseInt(minutesMatch[1]));
            return now.toISOString();
        }

        const hoursMatch = dateText.match(/(\d+)\s*hours?\s*ago/i);
        if (hoursMatch) {
            now.setHours(now.getHours() - parseInt(hoursMatch[1]));
            return now.toISOString();
        }

        try {
            const date = new Date(dateText);
            if (!isNaN(date.getTime())) {
                return date.toISOString();
            }
        } catch (e) {
            // 忽略
        }

        return new Date().toISOString();
    }

    /**
     * 去重
     * @param {Object[]} deals 
     * @returns {Object[]}
     */
    deduplicateDeals(deals) {
        const seen = new Set();
        return deals.filter(deal => {
            if (seen.has(deal.url)) {
                return false;
            }
            seen.add(deal.url);
            return true;
        });
    }
}

export default AFFCrawler;
