/**
 * 测试RSS Feed爬虫
 * 运行: node src/crawlers/test-rss.js
 */

import { OzbargainCrawler } from './OzbargainCrawler.js';
import { FlyerteaCrawler } from './FlyerteaCrawler.js';

async function testOzbargain() {
    console.log('===== Testing Ozbargain (RSS Feed) =====\n');
    const crawler = new OzbargainCrawler();

    try {
        const deals = await crawler.crawl();
        console.log(`\n✅ Found ${deals.length} deals from Ozbargain RSS\n`);

        if (deals.length > 0) {
            console.log('Sample deals:');
            deals.slice(0, 5).forEach((deal, i) => {
                console.log(`${i + 1}. ${deal.title.slice(0, 70)}...`);
                console.log(`   Category: ${deal.category}, Votes: ${deal.votes || 0}`);
            });
        }
    } catch (error) {
        console.error('❌ Ozbargain test failed:', error);
    }
}

async function testFlyertea() {
    console.log('\n===== Testing Flyertea (RSS Feed) =====\n');
    const crawler = new FlyerteaCrawler();

    try {
        const deals = await crawler.crawl();
        console.log(`\n✅ Found ${deals.length} deals from Flyertea RSS\n`);

        if (deals.length > 0) {
            console.log('Sample deals:');
            deals.slice(0, 5).forEach((deal, i) => {
                console.log(`${i + 1}. ${deal.title.slice(0, 50)}...`);
            });
        }
    } catch (error) {
        console.error('❌ Flyertea test failed:', error);
    }
}

async function main() {
    console.log('🚀 Testing RSS Feed crawlers...\n');

    await testOzbargain();
    await testFlyertea();

    console.log('\n🏁 Test complete!');
}

main().catch(console.error);
