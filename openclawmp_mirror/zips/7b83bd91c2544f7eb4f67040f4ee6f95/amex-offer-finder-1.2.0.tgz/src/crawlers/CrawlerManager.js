import { OzbargainCrawler } from './OzbargainCrawler.js';
import { RedditCrawler } from './RedditCrawler.js';
import { PointHacksCrawler } from './PointHacksCrawler.js';
import { FlyerteaCrawler } from './FlyerteaCrawler.js';
import { WowankaCrawler } from './WowankaCrawler.js';
import { AFFCrawler } from './AFFCrawler.js';
import { upsertDeals, logCrawl, getSettings } from '../data/database.js';

/**
 * 爬虫管理器
 * 协调所有爬虫的运行和数据存储
 */
export class CrawlerManager {
    constructor() {
        this.crawlers = {
            ozbargain: new OzbargainCrawler(),
            reddit: new RedditCrawler(),
            pointhacks: new PointHacksCrawler(),
            aff: new AFFCrawler(),
            flyertea: new FlyerteaCrawler(),
            wowanka: new WowankaCrawler()
        };

        this.isRunning = false;
        this.lastRun = null;
        this.runStats = {
            total: 0,
            added: 0,
            updated: 0,
            errors: 0
        };
    }

    /**
     * 运行所有爬虫
     * @param {Object} options 
     * @returns {Promise<Object>}
     */
    async runAll(options = {}) {
        if (this.isRunning) {
            console.log('⚠️ Crawlers are already running');
            return { status: 'already_running' };
        }

        this.isRunning = true;
        this.runStats = { total: 0, added: 0, updated: 0, errors: 0 };

        console.log('🕷️ Starting all crawlers...');
        const startTime = Date.now();

        const settings = getSettings();
        const enabledRegions = settings.regions || ['AU', 'CN'];

        const results = [];

        for (const [name, crawler] of Object.entries(this.crawlers)) {
            // 检查区域过滤
            if (!enabledRegions.includes(crawler.region)) {
                console.log(`⏭️ Skipping ${name} (region ${crawler.region} not enabled)`);
                continue;
            }

            try {
                console.log(`🔍 Running ${name}...`);
                const deals = await crawler.crawl();

                if (deals.length > 0) {
                    const { added, updated } = await upsertDeals(deals);

                    this.runStats.total += deals.length;
                    this.runStats.added += added;
                    this.runStats.updated += updated;

                    results.push({
                        source: name,
                        found: deals.length,
                        added,
                        updated,
                        status: 'success'
                    });

                    await logCrawl(name, { found: deals.length, added, updated, status: 'success' });
                } else {
                    results.push({
                        source: name,
                        found: 0,
                        status: 'no_results'
                    });
                }

            } catch (error) {
                console.error(`❌ ${name} failed:`, error.message);
                this.runStats.errors++;

                results.push({
                    source: name,
                    status: 'error',
                    error: error.message
                });

                await logCrawl(name, { status: 'error', error: error.message });
            }

            // 爬虫之间等待
            await this.sleep(3000);
        }

        const duration = Date.now() - startTime;
        this.lastRun = new Date().toISOString();
        this.isRunning = false;

        console.log(`✅ Crawl completed in ${(duration / 1000).toFixed(1)}s`);
        console.log(`   Total: ${this.runStats.total}, Added: ${this.runStats.added}, Updated: ${this.runStats.updated}, Errors: ${this.runStats.errors}`);

        return {
            status: 'completed',
            duration,
            stats: this.runStats,
            results,
            timestamp: this.lastRun
        };
    }

    /**
     * 运行单个爬虫
     * @param {string} crawlerName 
     * @returns {Promise<Object>}
     */
    async runOne(crawlerName) {
        const crawler = this.crawlers[crawlerName];
        if (!crawler) {
            throw new Error(`Crawler not found: ${crawlerName}`);
        }

        console.log(`🔍 Running ${crawlerName}...`);

        try {
            const deals = await crawler.crawl();

            if (deals.length > 0) {
                const { added, updated } = await upsertDeals(deals);

                await logCrawl(crawlerName, { found: deals.length, added, updated, status: 'success' });

                return {
                    source: crawlerName,
                    found: deals.length,
                    added,
                    updated,
                    status: 'success'
                };
            }

            return {
                source: crawlerName,
                found: 0,
                status: 'no_results'
            };

        } catch (error) {
            console.error(`❌ ${crawlerName} failed:`, error.message);
            await logCrawl(crawlerName, { status: 'error', error: error.message });

            return {
                source: crawlerName,
                status: 'error',
                error: error.message
            };
        }
    }

    /**
     * 获取爬虫状态
     * @returns {Object}
     */
    getStatus() {
        return {
            isRunning: this.isRunning,
            lastRun: this.lastRun,
            stats: this.runStats,
            crawlers: Object.keys(this.crawlers).map(name => ({
                name,
                region: this.crawlers[name].region
            }))
        };
    }

    /**
     * 获取可用爬虫列表
     * @returns {string[]}
     */
    getCrawlerNames() {
        return Object.keys(this.crawlers);
    }

    /**
     * 睡眠函数
     * @param {number} ms 
     * @returns {Promise<void>}
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// 单例实例
let managerInstance = null;

/**
 * 获取CrawlerManager单例
 * @returns {CrawlerManager}
 */
export function getCrawlerManager() {
    if (!managerInstance) {
        managerInstance = new CrawlerManager();
    }
    return managerInstance;
}

export default CrawlerManager;
