import puppeteer from 'puppeteer-extra';
import StealthPlugin from 'puppeteer-extra-plugin-stealth';
import { createDeal, DealSource } from '../models/Deal.js';
import { withRetry } from '../utils/retry.js';
import logger from '../utils/logger.js';

puppeteer.use(StealthPlugin());

/**
 * 飞客茶馆爬虫 - 使用 Puppeteer 绕过防护
 */
export class FlyerteaCrawler {
    constructor() {
        this.name = '飞客茶馆';
        this.baseUrl = 'https://www.flyertea.com';
        this.region = 'CN';
        this.browser = null;
        this.page = null;

        // 目标版块
        this.sections = [
            { fid: 44, name: '信用卡论坛' },
            { fid: 33, name: '羊毛专区' },
            { fid: 287, name: '大陆信用卡' },
        ];
    }

    async init() {
        if (!this.browser) {
            this.browser = await puppeteer.launch({
                headless: 'new',
                args: ['--no-sandbox', '--disable-setuid-sandbox']
            });
        }
    }

    async crawl() {
        await this.init();
        const deals = [];

        logger.crawler(this.name, 'Starting crawl', { sections: this.sections.length });

        for (const section of this.sections) {
            try {
                const sectionDeals = await withRetry(
                    () => this.crawlSection(section),
                    {
                        maxRetries: 2,
                        baseDelay: 3000,
                        onRetry: (err, attempt) => {
                            logger.warn(`Retry ${attempt} for section ${section.fid}`, {
                                error: err.message,
                                crawler: this.name
                            });
                        }
                    }
                );
                deals.push(...sectionDeals);
            } catch (error) {
                logger.error(`Failed to crawl section ${section.fid}`, {
                    error: error.message,
                    crawler: this.name
                });
            }
        }

        logger.crawler(this.name, 'Crawl completed', { dealsFound: deals.length });
        return this.deduplicateDeals(deals);
    }

    async crawlSection(section) {
        const page = await this.browser.newPage();
        const deals = [];

        try {
            const url = `${this.baseUrl}/forum-${section.fid}-1.html`;
            logger.crawler(this.name, 'Fetching section', { url, section: section.name });

            await page.goto(url, { waitUntil: 'networkidle2', timeout: 30000 });

            // 等待帖子列表加载
            await page.waitForSelector('tbody[id^="normalthread_"], .threadlist', { timeout: 10000 });

            // 提取帖子数据
            const posts = await page.evaluate(() => {
                const results = [];
                const rows = document.querySelectorAll('tbody[id^="normalthread_"], tbody[id^="stickthread_"]');

                rows.forEach(row => {
                    const titleEl = row.querySelector('a.s.xst, th a.xst');
                    const timeEl = row.querySelector('td.by em, .date');
                    const authorEl = row.querySelector('td.by cite a');

                    if (titleEl) {
                        results.push({
                            title: titleEl.textContent.trim(),
                            url: titleEl.href,
                            time: timeEl ? timeEl.textContent.trim() : '',
                            author: authorEl ? authorEl.textContent.trim() : ''
                        });
                    }
                });

                return results;
            });

            for (const post of posts) {
                if (!this.isRelevantPost(post.title)) continue;

                const deal = createDeal({
                    id: this.generateDealId('flyertea', post.url),
                    title: this.cleanText(post.title),
                    description: this.cleanText(post.title),
                    source: DealSource.FLYERTEA,
                    url: post.url,
                    region: 'CN',
                    category: this.categorize(post.title),
                    discount: this.extractDiscount(post.title),
                    createdAt: this.parseDate(post.time),
                    isActive: true,
                    tags: ['飞客茶馆', section.name],
                    author: post.author
                });

                deals.push(deal);
            }

            logger.crawler(this.name, 'Section parsed', {
                section: section.name,
                postsFound: posts.length,
                dealsFound: deals.length
            });

        } catch (error) {
            logger.error(`Error crawling section ${section.fid}`, {
                error: error.message,
                crawler: this.name
            });
        } finally {
            await page.close();
        }

        return deals;
    }

    isRelevantPost(text) {
        if (!text) return false;
        const keywords = [
            'amex', '美国运通', '运通', '百夫长', 'ae',
            '礼品卡', '购物卡', '返现', 'cashback',
            '积分', '里程', 'mr积分', 'amex积分',
            '白金卡', '金卡', '信用卡', '刷卡',
            '羊毛', '优惠', '折扣', '活动'
        ];
        const lowerText = text.toLowerCase();
        return keywords.some(kw => lowerText.includes(kw));
    }

    cleanText(text) {
        return text ? text.replace(/\s+/g, ' ').trim() : '';
    }

    extractDiscount(text) {
        const match = text.match(/(\d+(?:\.\d+)?)\s*折/);
        if (match) return parseFloat(match[1]) * 10;

        const percentMatch = text.match(/(\d+(?:\.\d+)?)\s*%/);
        if (percentMatch) return parseFloat(percentMatch[1]);

        return null;
    }

    categorize(text) {
        const lower = text.toLowerCase();
        if (lower.includes('礼品卡') || lower.includes('购物卡')) return 'gift_card';
        if (lower.includes('返现') || lower.includes('cashback')) return 'cashback';
        if (lower.includes('积分') || lower.includes('里程')) return 'points_bonus';
        if (lower.includes('amex') || lower.includes('运通') || lower.includes('ae')) return 'amex_offer';
        return 'other';
    }

    parseDate(dateText) {
        if (!dateText) return new Date().toISOString();

        const now = new Date();

        if (dateText.includes('昨天')) {
            now.setDate(now.getDate() - 1);
            return now.toISOString();
        }
        if (dateText.includes('前天')) {
            now.setDate(now.getDate() - 2);
            return now.toISOString();
        }

        const daysAgo = dateText.match(/(\d+)\s*天前/);
        if (daysAgo) {
            now.setDate(now.getDate() - parseInt(daysAgo[1]));
            return now.toISOString();
        }

        try {
            const date = new Date(dateText.replace(/-/g, '/'));
            if (!isNaN(date.getTime())) {
                return date.toISOString();
            }
        } catch (e) {
            // ignore
        }

        return now.toISOString();
    }

    generateDealId(source, url) {
        const match = url.match(/tid=(\d+)/);
        const id = match ? match[1] : String(Date.now());
        return `${source}_${id}`;
    }

    deduplicateDeals(deals) {
        const seen = new Set();
        return deals.filter(deal => {
            const key = deal.url || deal.title;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });
    }

    async close() {
        if (this.browser) {
            await this.browser.close();
            this.browser = null;
        }
    }
}

export default FlyerteaCrawler;
