import express from 'express';
import {
    getDeals,
    getNewDeals,
    markAllDealsAsRead,
    getSettings,
    updateSettings,
    updatePointsValue,
    getGiftCards,
    getXiaohongshuPosts,
    upsertXiaohongshuPosts,
    voteXiaohongshuPost
} from '../data/database.js';
import { getCrawlerManager } from '../crawlers/CrawlerManager.js';
import { getXiaohongshuCrawler } from '../crawlers/XiaohongshuCrawler.js';
import { getOptimizer } from '../optimizer/GiftCardOptimizer.js';
import { getNotificationManager } from '../notifications/NotificationManager.js';
import { CardTierDetails, isDealAvailableForTier } from '../models/AmexCardTier.js';

const router = express.Router();

// ============ Deals API ============

/**
 * GET /api/deals
 * 获取优惠列表
 */
router.get('/deals', (req, res) => {
    try {
        const filters = {
            region: req.query.region,
            category: req.query.category,
            source: req.query.source,
            isActive: req.query.active === 'true' ? true : req.query.active === 'false' ? false : undefined,
            isNew: req.query.new === 'true' ? true : undefined,
            minDiscount: req.query.minDiscount ? parseInt(req.query.minDiscount) : undefined,
            search: req.query.search,
            limit: req.query.limit ? parseInt(req.query.limit) : 50,
            offset: req.query.offset ? parseInt(req.query.offset) : 0
        };

        const deals = getDeals(filters);

        res.json({
            success: true,
            data: deals,
            count: deals.length,
            filters
        });
    } catch (error) {
        console.error('Error fetching deals:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * GET /api/deals/new
 * 获取新优惠
 */
router.get('/deals/new', (req, res) => {
    try {
        const deals = getNewDeals();
        res.json({
            success: true,
            data: deals,
            count: deals.length
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * POST /api/deals/read
 * 标记所有为已读
 */
router.post('/deals/read', async (req, res) => {
    try {
        await markAllDealsAsRead();
        res.json({ success: true });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ Crawl API ============

/**
 * POST /api/crawl
 * 手动触发爬虫
 */
router.post('/crawl', async (req, res) => {
    try {
        const manager = getCrawlerManager();
        const result = await manager.runAll();

        // 发送通知
        const notificationManager = getNotificationManager();
        if (result.stats.added > 0) {
            await notificationManager.notifyNewDeals();
        }

        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        console.error('Crawl error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * POST /api/crawl/:source
 * 触发单个爬虫
 */
router.post('/crawl/:source', async (req, res) => {
    try {
        const manager = getCrawlerManager();
        const result = await manager.runOne(req.params.source);

        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * GET /api/crawl/status
 * 获取爬虫状态
 */
router.get('/crawl/status', (req, res) => {
    try {
        const manager = getCrawlerManager();
        const status = manager.getStatus();

        res.json({
            success: true,
            data: status
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ Optimizer API ============

/**
 * POST /api/optimize
 * 计算最优购买路径
 */
router.post('/optimize', async (req, res) => {
    try {
        const { merchant, amount, region = 'AU' } = req.body;

        if (!merchant || !amount) {
            return res.status(400).json({
                success: false,
                error: 'Missing required fields: merchant, amount'
            });
        }

        const optimizer = await getOptimizer();
        const result = optimizer.quickOptimize(merchant, parseFloat(amount), region);

        res.json({
            success: true,
            data: result
        });
    } catch (error) {
        console.error('Optimize error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * POST /api/optimize/batch
 * 批量计算
 */
router.post('/optimize/batch', async (req, res) => {
    try {
        const { purchases } = req.body;

        if (!purchases || !Array.isArray(purchases)) {
            return res.status(400).json({
                success: false,
                error: 'purchases must be an array'
            });
        }

        const optimizer = await getOptimizer();
        const results = optimizer.batchOptimize(purchases);

        res.json({
            success: true,
            data: results
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ Gift Cards API ============

/**
 * GET /api/giftcards
 * 获取礼品卡列表
 */
router.get('/giftcards', (req, res) => {
    try {
        const filters = {
            region: req.query.region
        };
        const giftCards = getGiftCards(filters);

        res.json({
            success: true,
            data: giftCards,
            count: giftCards.length
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ Settings API ============

/**
 * GET /api/settings
 * 获取设置
 */
router.get('/settings', (req, res) => {
    try {
        const settings = getSettings();
        res.json({
            success: true,
            data: settings
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * PUT /api/settings
 * 更新设置
 */
router.put('/settings', async (req, res) => {
    try {
        const newSettings = await updateSettings(req.body);

        // 更新通知管理器
        const notificationManager = getNotificationManager();
        notificationManager.setEnabled(newSettings.notifications?.enabled !== false);

        res.json({
            success: true,
            data: newSettings
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * PUT /api/settings/points/:systemId
 * 更新积分价值
 */
router.put('/settings/points/:systemId', async (req, res) => {
    try {
        await updatePointsValue(req.params.systemId, req.body);
        const settings = getSettings();

        res.json({
            success: true,
            data: settings.pointsValues
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ Notification API ============

/**
 * POST /api/notifications/test
 * 测试通知
 */
router.post('/notifications/test', async (req, res) => {
    try {
        const notificationManager = getNotificationManager();
        await notificationManager.test();

        res.json({ success: true, message: 'Test notification sent' });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

// ============ Health Check ============

/**
 * GET /api/health
 * 健康检查
 */
router.get('/health', (req, res) => {
    res.json({
        success: true,
        status: 'healthy',
        timestamp: new Date().toISOString()
    });
});

// ============ Card Tier API ============

/**
 * GET /api/card-tiers
 * 获取卡等级列表
 */
router.get('/card-tiers', (req, res) => {
    res.json({
        success: true,
        data: CardTierDetails
    });
});

// ============ Xiaohongshu API ============

/**
 * GET /api/xiaohongshu
 * 获取小红书内容
 */
router.get('/xiaohongshu', (req, res) => {
    try {
        const posts = getXiaohongshuPosts();
        const settings = getSettings();
        const userTier = settings.cardTier || 3;

        // 按卡等级过滤
        let filteredPosts = posts;
        if (req.query.filterByTier === 'true') {
            filteredPosts = posts.filter(p => isDealAvailableForTier(p, userTier));
        }

        // 按时间排序
        filteredPosts.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        res.json({
            success: true,
            data: filteredPosts,
            count: filteredPosts.length,
            loginStatus: getXiaohongshuCrawler().hasCookies()
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * POST /api/xiaohongshu/login
 * 设置小红书Cookie（用户从浏览器获取）
 */
router.post('/xiaohongshu/login', async (req, res) => {
    try {
        const { cookies } = req.body;

        if (!cookies) {
            return res.status(400).json({
                success: false,
                error: 'Missing cookies parameter'
            });
        }

        const crawler = getXiaohongshuCrawler();
        crawler.setCookies(cookies);

        // 保存到设置
        await updateSettings({
            xiaohongshu: {
                enabled: true,
                cookies,
                lastFetch: null
            }
        });

        res.json({
            success: true,
            message: 'Xiaohongshu cookies set successfully'
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * POST /api/xiaohongshu/fetch
 * 获取小红书内容（使用已设置的Cookie）
 */
router.post('/xiaohongshu/fetch', async (req, res) => {
    try {
        const crawler = getXiaohongshuCrawler();

        // 检查是否有Cookie
        const settings = getSettings();
        if (settings.xiaohongshu?.cookies && !crawler.hasCookies()) {
            crawler.setCookies(settings.xiaohongshu.cookies);
        }

        if (!crawler.hasCookies()) {
            return res.status(400).json({
                success: false,
                error: 'Not logged in. Please set cookies first via /api/xiaohongshu/login'
            });
        }

        const keywords = req.body.keywords || ['Amex优惠', '美国运通白金卡', '礼品卡折扣', '信用卡羊毛'];
        const posts = await crawler.crawl(keywords);

        // 保存到数据库
        const result = await upsertXiaohongshuPosts(posts);

        // 更新最后获取时间
        await updateSettings({
            xiaohongshu: {
                ...settings.xiaohongshu,
                lastFetch: new Date().toISOString()
            }
        });

        res.json({
            success: true,
            data: {
                posts: posts.length,
                added: result.added,
                updated: result.updated
            }
        });
    } catch (error) {
        console.error('Xiaohongshu fetch error:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * POST /api/xiaohongshu/vote
 * 投票内容是否有用
 */
router.post('/xiaohongshu/vote', async (req, res) => {
    try {
        const { postId, helpful } = req.body;

        if (!postId || helpful === undefined) {
            return res.status(400).json({
                success: false,
                error: 'Missing postId or helpful parameter'
            });
        }

        const post = await voteXiaohongshuPost(postId, helpful);

        res.json({
            success: true,
            data: post
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

/**
 * GET /api/xiaohongshu/status
 * 获取小红书登录状态
 */
router.get('/xiaohongshu/status', (req, res) => {
    try {
        const settings = getSettings();
        const crawler = getXiaohongshuCrawler();

        res.json({
            success: true,
            data: {
                loggedIn: crawler.hasCookies() || !!settings.xiaohongshu?.cookies,
                lastFetch: settings.xiaohongshu?.lastFetch,
                postsCount: getXiaohongshuPosts().length
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: error.message });
    }
});

export default router;

