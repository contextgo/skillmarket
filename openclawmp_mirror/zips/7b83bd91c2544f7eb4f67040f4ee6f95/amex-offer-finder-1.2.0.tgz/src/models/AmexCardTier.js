/**
 * Amex卡等级系统
 * 定义不同卡等级及其可用的优惠类型
 */

// 卡等级定义
export const AmexCardTier = {
    ESSENTIAL: 1,      // 绿卡/Essential
    GOLD: 2,           // 金卡/Rose Gold
    PLATINUM: 3,       // 白金卡
    CENTURION: 4       // 百夫长/黑卡
};

// 卡等级详情
export const CardTierDetails = {
    [AmexCardTier.ESSENTIAL]: {
        id: 'essential',
        name: 'Essential/绿卡',
        nameEn: 'Essential',
        nameCn: '绿卡',
        level: 1,
        color: '#00A651',
        description: '基础会员权益',
        benefits: ['Amex Offers', '基础积分']
    },
    [AmexCardTier.GOLD]: {
        id: 'gold',
        name: 'Gold/金卡',
        nameEn: 'Gold',
        nameCn: '金卡',
        level: 2,
        color: '#FFD700',
        description: '金卡专属权益',
        benefits: ['Amex Offers', '金卡优惠', '餐饮返现', '机场贵宾厅(部分)']
    },
    [AmexCardTier.PLATINUM]: {
        id: 'platinum',
        name: 'Platinum/白金卡',
        nameEn: 'Platinum',
        nameCn: '白金卡',
        level: 3,
        color: '#E5E4E2',
        description: '白金卡尊享权益',
        benefits: ['Amex Offers', '金卡优惠', '白金专属', 'FHR酒店', '机场贵宾厅', 'Uber Credits']
    },
    [AmexCardTier.CENTURION]: {
        id: 'centurion',
        name: 'Centurion/百夫长',
        nameEn: 'Centurion',
        nameCn: '百夫长/黑卡',
        level: 4,
        color: '#1C1C1C',
        description: '最高等级权益',
        benefits: ['全部权益', '黑卡专属', '私人助理', '顶级酒店权益']
    }
};

// 优惠适用等级标签
export const DealTierTags = {
    ALL: 'all',                    // 所有卡适用
    GOLD_PLUS: 'gold_plus',        // 金卡及以上
    PLATINUM_PLUS: 'platinum_plus', // 白金及以上
    CENTURION_ONLY: 'centurion'    // 仅百夫长
};

/**
 * 检查优惠是否适用于指定卡等级
 * @param {Object} deal - 优惠信息
 * @param {number} userCardTier - 用户卡等级
 * @returns {boolean}
 */
export function isDealAvailableForTier(deal, userCardTier) {
    const dealTier = deal.requiredTier || DealTierTags.ALL;

    switch (dealTier) {
        case DealTierTags.ALL:
            return true;
        case DealTierTags.GOLD_PLUS:
            return userCardTier >= AmexCardTier.GOLD;
        case DealTierTags.PLATINUM_PLUS:
            return userCardTier >= AmexCardTier.PLATINUM;
        case DealTierTags.CENTURION_ONLY:
            return userCardTier >= AmexCardTier.CENTURION;
        default:
            return true;
    }
}

/**
 * 从文本推断优惠所需卡等级
 * @param {string} text 
 * @returns {string}
 */
export function inferDealTier(text) {
    const lower = text.toLowerCase();

    if (lower.includes('centurion') || lower.includes('百夫长') || lower.includes('黑卡')) {
        return DealTierTags.CENTURION_ONLY;
    }
    if (lower.includes('platinum') || lower.includes('白金')) {
        return DealTierTags.PLATINUM_PLUS;
    }
    if (lower.includes('gold') || lower.includes('金卡')) {
        return DealTierTags.GOLD_PLUS;
    }

    return DealTierTags.ALL;
}

export default {
    AmexCardTier,
    CardTierDetails,
    DealTierTags,
    isDealAvailableForTier,
    inferDealTier
};
