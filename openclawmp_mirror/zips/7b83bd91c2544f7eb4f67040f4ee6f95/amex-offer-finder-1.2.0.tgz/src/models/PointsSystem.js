/**
 * 积分体系模型
 * 支持多种积分体系和自定义价值估算
 */

/**
 * @typedef {Object} PointsSystem
 * @property {string} id - 唯一标识符
 * @property {string} name - 积分体系名称
 * @property {string} shortName - 缩写
 * @property {Object} valuePerPoint - 每积分价值
 * @property {number} valuePerPoint.AUD - 每积分价值 (澳元)
 * @property {number} valuePerPoint.CNY - 每积分价值 (人民币)
 * @property {string[]} transferPartners - 转换伙伴
 * @property {Object} transferRatios - 转换比例
 */

/**
 * 预定义的积分体系
 */
export const PointsSystems = {
    AMEX_MR: {
        id: 'amex_mr',
        name: 'American Express Membership Rewards',
        shortName: 'Amex MR',
        valuePerPoint: {
            AUD: 0.012,  // 1 MR ≈ 1.2澳分
            CNY: 0.055   // 1 MR ≈ 5.5分人民币
        },
        transferPartners: ['Qantas', 'Velocity', 'Asia Miles', 'KrisFlyer', 'Emirates Skywards'],
        transferRatios: {
            'Qantas': 2,      // 2 MR = 1 Qantas Point (AU)
            'Velocity': 2,    // 2 MR = 1 Velocity Point (AU)
            'AsiaMiles': 1,   // 1 MR = 1 Asia Mile
            'KrisFlyer': 1,   // 1 MR = 1 KrisFlyer Mile
            'Skywards': 1     // 1 MR = 1 Skywards Mile
        }
    },

    QANTAS: {
        id: 'qantas',
        name: 'Qantas Frequent Flyer',
        shortName: 'Qantas',
        valuePerPoint: {
            AUD: 0.015,
            CNY: 0.070
        },
        transferPartners: ['Woolworths Rewards'],
        transferRatios: {}
    },

    VELOCITY: {
        id: 'velocity',
        name: 'Velocity Frequent Flyer',
        shortName: 'Velocity',
        valuePerPoint: {
            AUD: 0.016,
            CNY: 0.075
        },
        transferPartners: [],
        transferRatios: {}
    },

    ASIA_MILES: {
        id: 'asia_miles',
        name: 'Asia Miles',
        shortName: 'Asia Miles',
        valuePerPoint: {
            AUD: 0.025,
            CNY: 0.12
        },
        transferPartners: [],
        transferRatios: {}
    },

    FLYBUYS: {
        id: 'flybuys',
        name: 'Flybuys',
        shortName: 'Flybuys',
        valuePerPoint: {
            AUD: 0.005,  // 1 Flybuys ≈ 0.5澳分
            CNY: 0.023
        },
        transferPartners: ['Velocity'],
        transferRatios: {
            'Velocity': 2000  // 2000 Flybuys = 870 Velocity Points
        }
    },

    WOOLWORTHS_REWARDS: {
        id: 'woolworths_rewards',
        name: 'Woolworths Everyday Rewards',
        shortName: 'WW Rewards',
        valuePerPoint: {
            AUD: 0.01,
            CNY: 0.046
        },
        transferPartners: ['Qantas'],
        transferRatios: {
            'Qantas': 2000  // 2000 WW = 1000 Qantas Points
        }
    }
};

/**
 * 积分价值计算器类
 */
export class PointsCalculator {
    constructor(customValues = {}) {
        this.systems = { ...PointsSystems };
        // 应用自定义价值
        for (const [systemId, values] of Object.entries(customValues)) {
            if (this.systems[systemId]) {
                this.systems[systemId].valuePerPoint = {
                    ...this.systems[systemId].valuePerPoint,
                    ...values
                };
            }
        }
    }

    /**
     * 获取积分的货币价值
     * @param {string} systemId - 积分体系ID
     * @param {number} points - 积分数量
     * @param {'AUD' | 'CNY'} currency - 货币类型
     * @returns {number}
     */
    getValue(systemId, points, currency = 'AUD') {
        const system = this.systems[systemId] || this.systems.AMEX_MR;
        return points * (system.valuePerPoint[currency] || 0);
    }

    /**
     * 计算积分转换价值
     * @param {string} fromSystem - 源积分体系
     * @param {string} toSystem - 目标积分体系
     * @param {number} points - 积分数量
     * @returns {{convertedPoints: number, ratio: number} | null}
     */
    calculateTransfer(fromSystem, toSystem, points) {
        const from = this.systems[fromSystem];
        if (!from || !from.transferRatios[toSystem]) {
            return null;
        }
        const ratio = from.transferRatios[toSystem];
        return {
            convertedPoints: points / ratio,
            ratio
        };
    }

    /**
     * 更新自定义积分价值
     * @param {string} systemId 
     * @param {'AUD' | 'CNY'} currency 
     * @param {number} value 
     */
    updateValue(systemId, currency, value) {
        if (this.systems[systemId]) {
            this.systems[systemId].valuePerPoint[currency] = value;
        }
    }

    /**
     * 获取所有积分体系
     * @returns {Object}
     */
    getAllSystems() {
        return this.systems;
    }
}

export default PointsCalculator;
