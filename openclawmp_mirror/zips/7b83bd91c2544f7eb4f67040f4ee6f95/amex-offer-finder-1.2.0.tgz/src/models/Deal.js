/**
 * Deal数据模型
 * 表示从各个来源抓取的优惠信息
 */

/**
 * @typedef {Object} Deal
 * @property {string} id - 唯一标识符
 * @property {string} title - 优惠标题
 * @property {string} description - 优惠描述
 * @property {string} source - 来源 ('ozbargain' | 'pointhacks' | 'flyertea' | 'reddit' | 'aff' | 'wowanka')
 * @property {string} url - 原文链接
 * @property {'AU' | 'CN'} region - 地区
 * @property {string} category - 类别 ('amex_offer' | 'gift_card' | 'cashback' | 'points_bonus' | 'other')
 * @property {number} [discount] - 折扣百分比 (可选)
 * @property {number} [pointsMultiplier] - 积分倍数 (可选)
 * @property {number} [cashbackRate] - 返现比例 (可选)
 * @property {string} [expiryDate] - 过期日期 (可选)
 * @property {string} createdAt - 抓取时间
 * @property {boolean} isActive - 是否有效
 * @property {boolean} isNew - 是否为新发现
 * @property {string[]} [tags] - 标签
 */

/**
 * 创建新的Deal对象
 * @param {Partial<Deal>} data 
 * @returns {Deal}
 */
export function createDeal(data) {
    return {
        id: data.id || generateId(),
        title: data.title || '',
        description: data.description || '',
        source: data.source || 'unknown',
        url: data.url || '',
        region: data.region || 'AU',
        category: data.category || 'other',
        discount: data.discount || null,
        pointsMultiplier: data.pointsMultiplier || null,
        cashbackRate: data.cashbackRate || null,
        expiryDate: data.expiryDate || null,
        createdAt: data.createdAt || new Date().toISOString(),
        isActive: data.isActive !== false,
        isNew: data.isNew !== false,
        tags: data.tags || []
    };
}

/**
 * 生成唯一ID
 * @returns {string}
 */
function generateId() {
    return `deal_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}

/**
 * Deal类别枚举
 */
export const DealCategory = {
    AMEX_OFFER: 'amex_offer',      // Amex官方或合作优惠
    GIFT_CARD: 'gift_card',        // 礼品卡折扣
    CASHBACK: 'cashback',          // 返现活动
    POINTS_BONUS: 'points_bonus',  // 积分加速
    OTHER: 'other'                 // 其他
};

/**
 * 数据来源枚举
 */
export const DealSource = {
    OZBARGAIN: 'ozbargain',
    POINTHACKS: 'pointhacks',
    AFF: 'aff',                    // Australian Frequent Flyer
    REDDIT: 'reddit',
    FLYERTEA: 'flyertea',          // 飞客茶馆
    WOWANKA: 'wowanka',            // 我玩卡
    XIAOHONGSHU: 'xiaohongshu',    // 小红书
    WEIBO: 'weibo'                 // 微博
};

/**
 * 地区枚举
 */
export const Region = {
    AU: 'AU',
    CN: 'CN'
};
