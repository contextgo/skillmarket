/**
 * 礼品卡渠道模型
 * 表示可以购买礼品卡的渠道及其返利信息
 */

/**
 * @typedef {Object} PurchaseChannel
 * @property {string} name - 渠道名称 (如 'Cashrewards', 'ShopBack')
 * @property {number} cashbackRate - 返现比例 (百分比)
 * @property {number} [pointsRate] - 积分比例 (每$1)
 * @property {string} [pointsType] - 积分类型 (如 'Qantas', 'Velocity')
 * @property {string} url - 渠道链接
 * @property {boolean} acceptsAmex - 是否接受Amex支付
 */

/**
 * @typedef {Object} GiftCard
 * @property {string} id - 唯一标识符
 * @property {string} name - 礼品卡名称 (如 'JB Hi-Fi', 'Woolworths', '京东卡')
 * @property {string} merchant - 商家名称
 * @property {'AU' | 'CN'} region - 地区
 * @property {PurchaseChannel[]} purchaseChannels - 购买渠道列表
 * @property {string[]} usableAt - 可使用的商家
 * @property {number} [currentDiscount] - 当前折扣 (百分比)
 * @property {boolean} canBuyOtherGiftCards - 是否可以用来购买其他礼品卡
 */

/**
 * 创建礼品卡对象
 * @param {Partial<GiftCard>} data 
 * @returns {GiftCard}
 */
export function createGiftCard(data) {
    return {
        id: data.id || `gc_${Date.now()}`,
        name: data.name || '',
        merchant: data.merchant || data.name || '',
        region: data.region || 'AU',
        purchaseChannels: data.purchaseChannels || [],
        usableAt: data.usableAt || [data.merchant || data.name],
        currentDiscount: data.currentDiscount || 0,
        canBuyOtherGiftCards: data.canBuyOtherGiftCards || false
    };
}

/**
 * 澳洲购买渠道
 */
export const AUChannels = {
    CASHREWARDS: {
        name: 'Cashrewards',
        url: 'https://www.cashrewards.com.au',
        acceptsAmex: true
    },
    SHOPBACK: {
        name: 'ShopBack',
        url: 'https://www.shopback.com.au',
        acceptsAmex: true
    },
    EVERYDAY_REWARDS: {
        name: 'Woolworths Everyday Rewards',
        url: 'https://www.woolworthsrewards.com.au',
        acceptsAmex: true
    },
    FLYBUYS: {
        name: 'Flybuys',
        url: 'https://www.flybuys.com.au',
        acceptsAmex: false  // Flybuys主要通过Coles消费获得
    },
    PREZZEE: {
        name: 'Prezzee',
        url: 'https://www.prezzee.com.au',
        acceptsAmex: true
    },
    GIFT_CARDS_ON_SALE: {
        name: 'Gift Cards on Sale',
        url: 'https://www.giftcardsonsale.com.au',
        acceptsAmex: true
    }
};

/**
 * 中国购买渠道
 */
export const CNChannels = {
    JD: {
        name: '京东',
        url: 'https://www.jd.com',
        acceptsAmex: false  // 一般不接受Amex
    },
    TMALL: {
        name: '天猫',
        url: 'https://www.tmall.com',
        acceptsAmex: false
    },
    BANK_MALL: {
        name: '银行积分商城',
        url: '',
        acceptsAmex: false  // 用积分兑换
    }
};

/**
 * 计算通过某渠道购买礼品卡的总价值
 * @param {number} amount - 购买金额
 * @param {PurchaseChannel} channel - 购买渠道
 * @param {number} giftCardDiscount - 礼品卡折扣 (百分比)
 * @param {number} amexPointsPerDollar - Amex每消费$1获得的积分
 * @returns {{totalValue: number, cashback: number, points: number, effectiveAmount: number}}
 */
export function calculateChannelValue(amount, channel, giftCardDiscount = 0, amexPointsPerDollar = 1) {
    const effectiveAmount = amount * (1 + giftCardDiscount / 100);
    const cashback = amount * (channel.cashbackRate / 100);
    const amexPoints = channel.acceptsAmex ? amount * amexPointsPerDollar : 0;
    const channelPoints = channel.pointsRate ? amount * channel.pointsRate : 0;

    return {
        totalValue: effectiveAmount + cashback,
        cashback,
        amexPoints,
        channelPoints,
        effectiveAmount
    };
}
