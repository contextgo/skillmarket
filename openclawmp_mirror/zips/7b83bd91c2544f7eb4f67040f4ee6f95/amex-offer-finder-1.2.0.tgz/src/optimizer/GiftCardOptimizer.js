import { getGiftCards, getSettings } from '../data/database.js';
import { PointsCalculator, PointsSystems } from '../models/PointsSystem.js';

/**
 * 礼品卡套娃路径优化器
 * 计算最优购买路径以最大化积分价值
 */
export class GiftCardOptimizer {
    constructor() {
        this.pointsCalculator = null;
        this.giftCards = [];
        this.amexPointsPerDollar = 1; // Amex白金卡基础积分率
    }

    /**
     * 初始化优化器
     */
    async initialize() {
        const settings = getSettings();
        this.pointsCalculator = new PointsCalculator(settings.pointsValues);
        this.giftCards = getGiftCards();
    }

    /**
     * 计算最优购买路径
     * @param {Object} params
     * @param {number} params.amount - 消费金额
     * @param {string} params.merchant - 目标商家
     * @param {'AUD' | 'CNY'} params.currency - 货币
     * @param {string} params.region - 地区 ('AU' | 'CN')
     * @returns {Object[]} 排序后的购买路径
     */
    optimize({ amount, merchant, currency = 'AUD', region = 'AU' }) {
        const paths = [];

        // 路径1: 直接消费
        const directPath = this.calculateDirectPurchase(amount, currency);
        paths.push(directPath);

        // 找到目标商家的礼品卡
        const merchantGiftCards = this.findGiftCardsForMerchant(merchant, region);

        // 路径2: 通过各渠道购买礼品卡
        for (const giftCard of merchantGiftCards) {
            for (const channel of giftCard.purchaseChannels) {
                const channelPath = this.calculateChannelPath(amount, giftCard, channel, currency);
                paths.push(channelPath);
            }
        }

        // 路径3: 套娃路径（通过中间礼品卡）
        const nestingPaths = this.calculateNestingPaths(amount, merchant, region, currency);
        paths.push(...nestingPaths);

        // 按总价值排序
        paths.sort((a, b) => b.totalValue - a.totalValue);

        // 添加排名
        paths.forEach((path, index) => {
            path.rank = index + 1;
            path.savingsVsDirect = path.totalValue - directPath.totalValue;
            path.savingsPercent = ((path.totalValue - directPath.totalValue) / amount * 100).toFixed(2);
        });

        return paths;
    }

    /**
     * 计算直接消费路径
     * @param {number} amount 
     * @param {string} currency 
     * @returns {Object}
     */
    calculateDirectPurchase(amount, currency) {
        const amexPoints = amount * this.amexPointsPerDollar;
        const pointsValue = this.pointsCalculator.getValue('amex_mr', amexPoints, currency);

        return {
            type: 'direct',
            name: '直接刷卡消费',
            description: `使用Amex直接消费，获得${amexPoints}积分`,
            steps: [
                { action: '使用Amex卡消费', amount, currency }
            ],
            cost: amount,
            rewards: {
                amexPoints,
                cashback: 0,
                otherPoints: 0
            },
            pointsValue,
            totalValue: amount + pointsValue,
            complexity: 1, // 复杂度评分 (1-5)
            risk: 'low',
            notes: []
        };
    }

    /**
     * 计算通过渠道购买礼品卡的路径
     * @param {number} amount 
     * @param {Object} giftCard 
     * @param {Object} channel 
     * @param {string} currency 
     * @returns {Object}
     */
    calculateChannelPath(amount, giftCard, channel, currency) {
        // Amex积分（如果渠道接受Amex）
        const amexPoints = channel.acceptsAmex ? amount * this.amexPointsPerDollar : 0;
        const amexPointsValue = this.pointsCalculator.getValue('amex_mr', amexPoints, currency);

        // 返现
        const cashback = amount * (channel.cashbackRate / 100);

        // 渠道积分（如Qantas, Velocity等）
        const channelPoints = channel.pointsRate ? amount * channel.pointsRate : 0;
        let channelPointsValue = 0;
        if (channel.pointsType && channelPoints > 0) {
            channelPointsValue = this.pointsCalculator.getValue(
                channel.pointsType.toLowerCase(),
                channelPoints,
                currency
            );
        }

        // 礼品卡折扣
        const giftCardDiscount = giftCard.currentDiscount || 0;
        const effectiveAmount = amount * (1 + giftCardDiscount / 100);

        const totalValue = effectiveAmount + cashback + amexPointsValue + channelPointsValue;

        return {
            type: 'channel',
            name: `通过${channel.name}购买${giftCard.name}`,
            description: `先通过${channel.name}购买${giftCard.name}，再到商家消费`,
            steps: [
                {
                    action: `在${channel.name}购买${giftCard.name}`,
                    amount,
                    currency,
                    url: channel.url
                },
                {
                    action: `使用${giftCard.name}消费`,
                    amount: effectiveAmount,
                    currency
                }
            ],
            cost: amount,
            rewards: {
                amexPoints,
                cashback,
                channelPoints,
                giftCardDiscount
            },
            pointsValue: amexPointsValue + channelPointsValue,
            totalValue,
            complexity: 2,
            risk: channel.acceptsAmex ? 'low' : 'medium',
            notes: channel.acceptsAmex ? [] : ['此渠道不接受Amex支付，无法获得Amex积分']
        };
    }

    /**
     * 计算套娃路径（二级或多级礼品卡）
     * @param {number} amount 
     * @param {string} targetMerchant 
     * @param {string} region 
     * @param {string} currency 
     * @returns {Object[]}
     */
    calculateNestingPaths(amount, targetMerchant, region, currency) {
        const paths = [];

        // 找到可以购买其他礼品卡的礼品卡
        const intermediaryCards = this.giftCards.filter(
            gc => gc.region === region && gc.canBuyOtherGiftCards
        );

        // 找到目标商家的礼品卡
        const targetCards = this.findGiftCardsForMerchant(targetMerchant, region);

        for (const intermediary of intermediaryCards) {
            for (const target of targetCards) {
                // 避免循环
                if (intermediary.id === target.id) continue;

                // 检查是否可以用中间礼品卡购买目标礼品卡
                if (this.canPurchaseWith(target, intermediary)) {
                    for (const channel of intermediary.purchaseChannels) {
                        if (!channel.acceptsAmex) continue; // 只考虑接受Amex的渠道

                        const nestingPath = this.calculateNestingPath(
                            amount, intermediary, target, channel, currency
                        );
                        paths.push(nestingPath);
                    }
                }
            }
        }

        return paths;
    }

    /**
     * 计算具体的套娃路径
     */
    calculateNestingPath(amount, intermediaryCard, targetCard, channel, currency) {
        // 第一步：购买中间礼品卡
        const amexPoints = amount * this.amexPointsPerDollar;
        const amexPointsValue = this.pointsCalculator.getValue('amex_mr', amexPoints, currency);
        const cashback1 = amount * (channel.cashbackRate / 100);

        // 第二步：用中间礼品卡购买目标礼品卡
        // 假设中间礼品卡有2%的折扣优势
        const intermediaryDiscount = intermediaryCard.currentDiscount || 0;
        const step2Amount = amount * (1 + intermediaryDiscount / 100);

        // 目标礼品卡折扣
        const targetDiscount = targetCard.currentDiscount || 0;
        const effectiveAmount = step2Amount * (1 + targetDiscount / 100);

        const totalCashback = cashback1;
        const totalValue = effectiveAmount + totalCashback + amexPointsValue;

        return {
            type: 'nesting',
            name: `套娃: ${channel.name} → ${intermediaryCard.name} → ${targetCard.name}`,
            description: `先购买${intermediaryCard.name}，再用它购买${targetCard.name}`,
            steps: [
                {
                    action: `在${channel.name}购买${intermediaryCard.name}`,
                    amount,
                    currency,
                    url: channel.url
                },
                {
                    action: `使用${intermediaryCard.name}购买${targetCard.name}`,
                    amount: step2Amount,
                    currency
                },
                {
                    action: `使用${targetCard.name}消费`,
                    amount: effectiveAmount,
                    currency
                }
            ],
            cost: amount,
            rewards: {
                amexPoints,
                cashback: totalCashback,
                intermediaryDiscount,
                targetDiscount
            },
            pointsValue: amexPointsValue,
            totalValue,
            complexity: 4,
            risk: 'medium',
            notes: [
                '套娃路径需要多步操作',
                '部分商家可能限制礼品卡购买礼品卡',
                '请确认各礼品卡的使用条款'
            ]
        };
    }

    /**
     * 根据商家查找适用的礼品卡
     * @param {string} merchant 
     * @param {string} region 
     * @returns {Object[]}
     */
    findGiftCardsForMerchant(merchant, region) {
        const lowerMerchant = merchant.toLowerCase();
        return this.giftCards.filter(gc => {
            if (gc.region !== region) return false;

            // 检查商家名称匹配
            if (gc.merchant.toLowerCase().includes(lowerMerchant)) return true;
            if (lowerMerchant.includes(gc.merchant.toLowerCase())) return true;

            // 检查可用商家列表
            for (const usable of gc.usableAt) {
                if (usable.toLowerCase().includes(lowerMerchant)) return true;
                if (lowerMerchant.includes(usable.toLowerCase())) return true;
            }

            return false;
        });
    }

    /**
     * 检查是否可以用一张礼品卡购买另一张
     * @param {Object} targetCard 
     * @param {Object} purchaseCard 
     * @returns {boolean}
     */
    canPurchaseWith(targetCard, purchaseCard) {
        // 简化逻辑：假设Myer/David Jones/Coles可以购买其他礼品卡
        const canBuyGiftCards = ['myer', 'david jones', 'coles', 'woolworths'];
        return canBuyGiftCards.some(name =>
            purchaseCard.merchant.toLowerCase().includes(name)
        );
    }

    /**
     * 快速计算：给定商家的最优路径
     * @param {string} merchant 
     * @param {number} amount 
     * @param {string} region 
     * @returns {Object}
     */
    quickOptimize(merchant, amount, region = 'AU') {
        const currency = region === 'CN' ? 'CNY' : 'AUD';
        const paths = this.optimize({ amount, merchant, currency, region });

        return {
            merchant,
            amount,
            currency,
            bestPath: paths[0],
            alternativePaths: paths.slice(1, 4),
            directPath: paths.find(p => p.type === 'direct')
        };
    }

    /**
     * 批量计算多个商家
     * @param {Object[]} purchases 
     * @returns {Object[]}
     */
    batchOptimize(purchases) {
        return purchases.map(p => this.quickOptimize(p.merchant, p.amount, p.region));
    }
}

// 单例
let optimizerInstance = null;

/**
 * 获取优化器实例
 * @returns {Promise<GiftCardOptimizer>}
 */
export async function getOptimizer() {
    if (!optimizerInstance) {
        optimizerInstance = new GiftCardOptimizer();
        await optimizerInstance.initialize();
    }
    return optimizerInstance;
}

export default GiftCardOptimizer;
