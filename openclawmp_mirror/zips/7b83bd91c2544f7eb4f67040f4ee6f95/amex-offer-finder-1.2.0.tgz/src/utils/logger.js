/**
 * 结构化日志系统
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.join(__dirname, '../..');
const logsDir = path.join(rootDir, 'logs');

// 确保日志目录存在
if (!fs.existsSync(logsDir)) {
    fs.mkdirSync(logsDir, { recursive: true });
}

const LOG_LEVELS = {
    ERROR: 0,
    WARN: 1,
    INFO: 2,
    DEBUG: 3
};

const currentLevel = LOG_LEVELS[process.env.LOG_LEVEL?.toUpperCase()] ?? LOG_LEVELS.INFO;

/**
 * 写入日志文件
 */
function writeToFile(filename, data) {
    const filepath = path.join(logsDir, filename);
    const line = JSON.stringify(data) + '\n';
    fs.appendFileSync(filepath, line);
}

/**
 * 格式化日志数据
 */
function formatLog(level, message, meta = {}) {
    return {
        timestamp: new Date().toISOString(),
        level,
        message,
        ...meta,
        pid: process.pid
    };
}

/**
 * 打印到控制台
 */
function printToConsole(data) {
    const colors = {
        ERROR: '\x1b[31m',
        WARN: '\x1b[33m',
        INFO: '\x1b[32m',
        DEBUG: '\x1b[36m',
        reset: '\x1b[0m'
    };

    const color = colors[data.level] || '';
    const time = new Date(data.timestamp).toLocaleTimeString();
    console.log(`${color}[${time}] [${data.level}] ${data.message}${colors.reset}`);

    if (data.error && data.level === 'ERROR') {
        console.error(data.error);
    }
}

export const logger = {
    error(message, meta = {}) {
        if (currentLevel >= LOG_LEVELS.ERROR) {
            const data = formatLog('ERROR', message, meta);
            printToConsole(data);
            writeToFile('error.log', data);
            writeToFile('combined.log', data);
        }
    },

    warn(message, meta = {}) {
        if (currentLevel >= LOG_LEVELS.WARN) {
            const data = formatLog('WARN', message, meta);
            printToConsole(data);
            writeToFile('combined.log', data);
        }
    },

    info(message, meta = {}) {
        if (currentLevel >= LOG_LEVELS.INFO) {
            const data = formatLog('INFO', message, meta);
            printToConsole(data);
            writeToFile('combined.log', data);
        }
    },

    debug(message, meta = {}) {
        if (currentLevel >= LOG_LEVELS.DEBUG) {
            const data = formatLog('DEBUG', message, meta);
            printToConsole(data);
        }
    },

    // 性能指标记录
    metric(name, value, unit = 'ms', meta = {}) {
        this.info(`Metric: ${name}`, {
            metric: name,
            value,
            unit,
            ...meta
        });
    },

    // 爬虫专用日志
    crawler(crawlerName, action, meta = {}) {
        this.info(`[${crawlerName}] ${action}`, {
            crawler: crawlerName,
            action,
            ...meta
        });
    }
};

export default logger;
