/**
 * 配置验证和管理
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const rootDir = path.join(__dirname, '../..');

// 配置项定义
export const configSchema = {
    PORT: {
        type: 'number',
        default: 3001,
        min: 1024,
        max: 65535,
        description: '服务器端口'
    },
    NODE_ENV: {
        type: 'string',
        default: 'development',
        enum: ['development', 'production', 'test'],
        description: '运行环境'
    },
    CRAWL_INTERVAL: {
        type: 'number',
        default: 30,
        min: 5,
        max: 1440,
        description: '爬取间隔(分钟)'
    },
    CRAWL_TIMEOUT: {
        type: 'number',
        default: 30000,
        min: 5000,
        max: 120000,
        description: '爬虫超时(毫秒)'
    },
    MAX_RETRIES: {
        type: 'number',
        default: 3,
        min: 0,
        max: 10,
        description: '最大重试次数'
    },
    NOTIFICATIONS_ENABLED: {
        type: 'boolean',
        default: true,
        description: '是否启用桌面通知'
    },
    RATE_LIMIT_WINDOW: {
        type: 'number',
        default: 15,
        min: 1,
        max: 60,
        description: 'Rate limit窗口(分钟)'
    },
    RATE_LIMIT_MAX: {
        type: 'number',
        default: 100,
        min: 10,
        max: 1000,
        description: 'Rate limit最大请求数'
    }
};

/**
 * 解析配置值
 */
function parseValue(value, schema) {
    if (value === undefined || value === '') {
        return schema.default;
    }

    switch (schema.type) {
        case 'number':
            const num = parseInt(value, 10);
            if (isNaN(num)) {
                throw new Error(`Invalid number: ${value}`);
            }
            return num;
        case 'boolean':
            return value === 'true' || value === '1' || value === true;
        case 'string':
        default:
            return value;
    }
}

/**
 * 验证配置值
 */
function validateValue(key, value, schema) {
    const errors = [];

    // 类型检查
    if (schema.type === 'number' && typeof value !== 'number') {
        errors.push(`${key}: expected number, got ${typeof value}`);
    }

    // 范围检查
    if (schema.min !== undefined && value < schema.min) {
        errors.push(`${key}: ${value} < minimum ${schema.min}`);
    }
    if (schema.max !== undefined && value > schema.max) {
        errors.push(`${key}: ${value} > maximum ${schema.max}`);
    }

    // 枚举检查
    if (schema.enum && !schema.enum.includes(value)) {
        errors.push(`${key}: ${value} not in [${schema.enum.join(', ')}]`);
    }

    return errors;
}

/**
 * 加载并验证配置
 */
export function loadConfig() {
    const config = {};
    const errors = [];

    // 加载 .env 文件
    const envPath = path.join(rootDir, '.env');
    if (fs.existsSync(envPath)) {
        const envContent = fs.readFileSync(envPath, 'utf8');
        envContent.split('\n').forEach(line => {
            const match = line.match(/^([^#=]+)=(.*)$/);
            if (match) {
                const [, key, value] = match;
                process.env[key.trim()] = value.trim();
            }
        });
    }

    // 解析和验证每个配置项
    for (const [key, schema] of Object.entries(configSchema)) {
        try {
            const rawValue = process.env[key];
            const value = parseValue(rawValue, schema);
            const validationErrors = validateValue(key, value, schema);

            if (validationErrors.length > 0) {
                errors.push(...validationErrors);
            } else {
                config[key] = value;
            }
        } catch (err) {
            errors.push(`${key}: ${err.message}`);
        }
    }

    // 如果有错误，打印并退出
    if (errors.length > 0) {
        console.error('❌ Configuration errors:');
        errors.forEach(err => console.error(`   - ${err}`));
        process.exit(1);
    }

    return config;
}

/**
 * 获取配置 (带缓存)
 */
let cachedConfig = null;

export function getConfig() {
    if (!cachedConfig) {
        cachedConfig = loadConfig();
    }
    return cachedConfig;
}

/**
 * 重新加载配置
 */
export function reloadConfig() {
    cachedConfig = loadConfig();
    return cachedConfig;
}
