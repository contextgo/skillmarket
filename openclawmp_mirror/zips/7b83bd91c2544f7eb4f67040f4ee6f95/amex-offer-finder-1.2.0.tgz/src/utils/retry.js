/**
 * 带指数退避的重试工具
 */

export async function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * 带重试的异步函数执行
 * @param {Function} fn - 要执行的函数
 * @param {Object} options - 配置选项
 * @param {number} options.maxRetries - 最大重试次数 (默认3)
 * @param {number} options.baseDelay - 基础延迟毫秒 (默认1000)
 * @param {number} options.maxDelay - 最大延迟毫秒 (默认30000)
 * @param {Function} options.onRetry - 重试时的回调 (error, attempt) => void
 * @returns {Promise<any>}
 */
export async function withRetry(fn, options = {}) {
    const {
        maxRetries = 3,
        baseDelay = 1000,
        maxDelay = 30000,
        onRetry = null
    } = options;

    let lastError;

    for (let attempt = 0; attempt <= maxRetries; attempt++) {
        try {
            return await fn();
        } catch (error) {
            lastError = error;

            if (attempt === maxRetries) {
                throw new Error(
                    `Failed after ${maxRetries + 1} attempts: ${error.message}`
                );
            }

            // 指数退避: 1s, 2s, 4s, 8s...
            const delay = Math.min(
                baseDelay * Math.pow(2, attempt),
                maxDelay
            );

            if (onRetry) {
                onRetry(error, attempt + 1);
            }

            console.log(`  ⏳ Retry ${attempt + 1}/${maxRetries} after ${delay}ms...`);
            await sleep(delay);
        }
    }

    throw lastError;
}

/**
 * 带超时的 Promise
 * @param {Promise} promise - 原始 Promise
 * @param {number} timeoutMs - 超时毫秒
 * @param {string} message - 超时错误信息
 */
export async function withTimeout(promise, timeoutMs, message = 'Operation timed out') {
    const timeoutPromise = new Promise((_, reject) => {
        setTimeout(() => reject(new Error(message)), timeoutMs);
    });

    return Promise.race([promise, timeoutPromise]);
}
