import notifier from 'node-notifier';
import path from 'path';
import { fileURLToPath } from 'url';
import { getNewDeals, markAllDealsAsRead, getSettings } from '../data/database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 通知管理器
 * 处理桌面通知的发送和管理
 */
export class NotificationManager {
    constructor() {
        this.enabled = true;
        this.queue = [];
        this.isProcessing = false;
        this.notificationDelay = 3000; // 通知间隔
    }

    /**
     * 初始化通知管理器
     */
    initialize() {
        const settings = getSettings();
        this.enabled = settings.notifications?.enabled !== false;
        console.log(`🔔 Notifications ${this.enabled ? 'enabled' : 'disabled'}`);
    }

    /**
     * 发送单条通知
     * @param {Object} options 
     */
    send(options) {
        if (!this.enabled) return Promise.resolve();

        return new Promise((resolve) => {
            try {
                notifier.notify(
                    {
                        title: options.title || 'Amex Deal Finder',
                        message: options.message,
                        sound: options.sound !== false,
                        wait: false,
                        timeout: 10,
                        // Windows特定配置
                        appID: 'Amex Deal Finder',
                        // macOS特定配置
                        contentImage: options.image,
                        open: options.url
                    },
                    (err, response, metadata) => {
                        if (err) {
                            console.log('Notification skipped (error):', err.message || err);
                            resolve(null); // 不拒绝，只是跳过
                        } else {
                            resolve(response);
                        }
                    }
                );
            } catch (error) {
                // 捕获所有错误，防止崩溃
                console.log('Notification system error:', error.message || error);
                resolve(null);
            }
        });
    }

    /**
     * 发送新优惠通知
     * @param {Object} deal 
     */
    async sendDealNotification(deal) {
        const regionEmoji = deal.region === 'AU' ? '🇦🇺' : '🇨🇳';
        const discountText = deal.discount ? ` (${deal.discount}% off)` : '';

        await this.send({
            title: `${regionEmoji} 新优惠发现!`,
            message: `${deal.title}${discountText}`,
            url: deal.url
        });
    }

    /**
     * 检查并发送新优惠通知
     * @returns {Promise<number>} 发送的通知数量
     */
    async notifyNewDeals() {
        if (!this.enabled) return 0;

        const settings = getSettings();
        const minDiscount = settings.notifications?.minDiscount || 0;
        const enabledCategories = settings.notifications?.categories || [];

        const newDeals = getNewDeals();

        if (newDeals.length === 0) return 0;

        // 过滤符合条件的优惠
        const notifyDeals = newDeals.filter(deal => {
            // 检查折扣阈值
            if (minDiscount > 0 && (deal.discount || 0) < minDiscount) {
                return false;
            }
            // 检查类别
            if (enabledCategories.length > 0 && !enabledCategories.includes(deal.category)) {
                return false;
            }
            return true;
        });

        if (notifyDeals.length === 0) {
            await markAllDealsAsRead();
            return 0;
        }

        // 限制通知数量，避免刷屏
        const maxNotifications = 5;
        const dealsToNotify = notifyDeals.slice(0, maxNotifications);

        // 如果有很多新优惠，发送汇总通知
        if (notifyDeals.length > maxNotifications) {
            await this.send({
                title: '🎉 发现多个新优惠!',
                message: `共有 ${notifyDeals.length} 个新优惠，点击查看详情`,
                url: 'http://localhost:3000'
            });
        } else {
            // 逐个发送通知
            for (const deal of dealsToNotify) {
                await this.sendDealNotification(deal);
                await this.sleep(this.notificationDelay);
            }
        }

        await markAllDealsAsRead();
        return notifyDeals.length;
    }

    /**
     * 发送系统通知
     * @param {string} title 
     * @param {string} message 
     */
    async sendSystemNotification(title, message) {
        await this.send({
            title: `⚙️ ${title}`,
            message
        });
    }

    /**
     * 发送爬虫完成通知
     * @param {Object} stats 
     */
    async sendCrawlCompleteNotification(stats) {
        if (stats.added > 0) {
            await this.send({
                title: '🕷️ 爬取完成',
                message: `发现 ${stats.added} 个新优惠，共 ${stats.total} 个结果`,
                url: 'http://localhost:3000'
            });
        }
    }

    /**
     * 测试通知
     */
    async test() {
        await this.send({
            title: '🔔 测试通知',
            message: 'Amex Deal Finder 通知功能正常工作！'
        });
    }

    /**
     * 启用/禁用通知
     * @param {boolean} enabled 
     */
    setEnabled(enabled) {
        this.enabled = enabled;
        console.log(`🔔 Notifications ${this.enabled ? 'enabled' : 'disabled'}`);
    }

    /**
     * 睡眠函数
     * @param {number} ms 
     */
    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }
}

// 单例
let notificationManager = null;

/**
 * 获取通知管理器实例
 * @returns {NotificationManager}
 */
export function getNotificationManager() {
    if (!notificationManager) {
        notificationManager = new NotificationManager();
    }
    return notificationManager;
}

export default NotificationManager;
