import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import { Low } from 'lowdb';
import { JSONFile } from 'lowdb/node';
import { existsSync, mkdirSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));

/**
 * 数据库初始化
 * 使用LowDB进行轻量级JSON存储
 */

// 默认数据结构
const defaultData = {
    deals: [],
    giftCards: [],
    xiaohongshuPosts: [],  // 小红书内容独立存储
    settings: {
        cardTier: 3,  // 默认白金卡 (1=Essential, 2=Gold, 3=Platinum, 4=Centurion)
        pointsValues: {
            amex_mr: { AUD: 0.012, CNY: 0.055 },
            qantas: { AUD: 0.015, CNY: 0.070 },
            velocity: { AUD: 0.016, CNY: 0.075 },
            asia_miles: { AUD: 0.025, CNY: 0.12 },
            flybuys: { AUD: 0.005, CNY: 0.023 },
            woolworths_rewards: { AUD: 0.01, CNY: 0.046 }
        },
        notifications: {
            enabled: true,
            minDiscount: 5,  // 最小折扣通知阈值
            categories: ['amex_offer', 'gift_card', 'cashback', 'points_bonus']
        },
        crawlInterval: 30,  // 爬取间隔（分钟）
        regions: ['AU', 'CN'],
        xiaohongshu: {
            enabled: false,
            cookies: null,
            lastFetch: null
        }
    },
    crawlHistory: [],
    lastUpdated: null
};

let db = null;

/**
 * 初始化数据库
 * @returns {Promise<Low>}
 */
export async function initDatabase() {
    const dataDir = join(__dirname, '../../data');

    // 确保data目录存在
    if (!existsSync(dataDir)) {
        mkdirSync(dataDir, { recursive: true });
    }

    const dbPath = join(dataDir, 'db.json');
    const adapter = new JSONFile(dbPath);
    db = new Low(adapter, defaultData);

    // 读取数据
    await db.read();

    // 如果是空数据库，写入默认数据
    if (!db.data) {
        db.data = defaultData;
        await db.write();
    }

    console.log('📦 Database initialized at:', dbPath);
    return db;
}

/**
 * 获取数据库实例
 * @returns {Low}
 */
export function getDatabase() {
    if (!db) {
        throw new Error('Database not initialized. Call initDatabase() first.');
    }
    return db;
}

// ============ Deals 操作 ============

/**
 * 添加或更新Deal
 * @param {Object} deal 
 */
export async function upsertDeal(deal) {
    const existingIndex = db.data.deals.findIndex(d => d.id === deal.id || d.url === deal.url);

    if (existingIndex >= 0) {
        // 更新现有deal
        db.data.deals[existingIndex] = { ...db.data.deals[existingIndex], ...deal, isNew: false };
    } else {
        // 添加新deal
        deal.isNew = true;
        db.data.deals.push(deal);
    }

    await db.write();
    return deal;
}

/**
 * 批量添加Deals
 * @param {Object[]} deals 
 * @returns {Promise<{added: number, updated: number}>}
 */
export async function upsertDeals(deals) {
    let added = 0, updated = 0;

    for (const deal of deals) {
        const existingIndex = db.data.deals.findIndex(d => d.id === deal.id || d.url === deal.url);

        if (existingIndex >= 0) {
            db.data.deals[existingIndex] = { ...db.data.deals[existingIndex], ...deal, isNew: false };
            updated++;
        } else {
            deal.isNew = true;
            db.data.deals.push(deal);
            added++;
        }
    }

    db.data.lastUpdated = new Date().toISOString();
    await db.write();

    return { added, updated };
}

/**
 * 获取所有Deals
 * @param {Object} filters - 过滤条件
 * @returns {Object[]}
 */
export function getDeals(filters = {}) {
    let deals = db.data.deals;

    if (filters.region) {
        deals = deals.filter(d => d.region === filters.region);
    }
    if (filters.category) {
        deals = deals.filter(d => d.category === filters.category);
    }
    if (filters.source) {
        deals = deals.filter(d => d.source === filters.source);
    }
    if (filters.isActive !== undefined) {
        deals = deals.filter(d => d.isActive === filters.isActive);
    }
    if (filters.isNew !== undefined) {
        deals = deals.filter(d => d.isNew === filters.isNew);
    }
    if (filters.minDiscount) {
        deals = deals.filter(d => (d.discount || 0) >= filters.minDiscount);
    }
    if (filters.search) {
        const searchLower = filters.search.toLowerCase();
        deals = deals.filter(d =>
            d.title.toLowerCase().includes(searchLower) ||
            d.description.toLowerCase().includes(searchLower)
        );
    }

    // 按创建时间倒序
    deals.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

    // 分页
    if (filters.limit) {
        const offset = filters.offset || 0;
        deals = deals.slice(offset, offset + filters.limit);
    }

    return deals;
}

/**
 * 获取新Deals（用于通知）
 * @returns {Object[]}
 */
export function getNewDeals() {
    return db.data.deals.filter(d => d.isNew);
}

/**
 * 标记所有Deals为已读
 */
export async function markAllDealsAsRead() {
    db.data.deals.forEach(d => { d.isNew = false; });
    await db.write();
}

// ============ 设置操作 ============

/**
 * 获取设置
 * @returns {Object}
 */
export function getSettings() {
    return db.data.settings;
}

/**
 * 更新设置
 * @param {Object} newSettings 
 */
export async function updateSettings(newSettings) {
    db.data.settings = { ...db.data.settings, ...newSettings };
    await db.write();
    return db.data.settings;
}

/**
 * 更新积分价值
 * @param {string} systemId 
 * @param {Object} values 
 */
export async function updatePointsValue(systemId, values) {
    if (!db.data.settings.pointsValues[systemId]) {
        db.data.settings.pointsValues[systemId] = {};
    }
    db.data.settings.pointsValues[systemId] = {
        ...db.data.settings.pointsValues[systemId],
        ...values
    };
    await db.write();
}

// ============ 礼品卡操作 ============

/**
 * 获取礼品卡列表
 * @param {Object} filters 
 * @returns {Object[]}
 */
export function getGiftCards(filters = {}) {
    let cards = db.data.giftCards;

    if (filters.region) {
        cards = cards.filter(c => c.region === filters.region);
    }

    return cards;
}

/**
 * 添加或更新礼品卡
 * @param {Object} giftCard 
 */
export async function upsertGiftCard(giftCard) {
    const existingIndex = db.data.giftCards.findIndex(c => c.id === giftCard.id);

    if (existingIndex >= 0) {
        db.data.giftCards[existingIndex] = { ...db.data.giftCards[existingIndex], ...giftCard };
    } else {
        db.data.giftCards.push(giftCard);
    }

    await db.write();
}

// ============ 爬取历史 ============

/**
 * 记录爬取历史
 * @param {string} source 
 * @param {Object} result 
 */
export async function logCrawl(source, result) {
    db.data.crawlHistory.push({
        source,
        timestamp: new Date().toISOString(),
        ...result
    });

    // 只保留最近100条记录
    if (db.data.crawlHistory.length > 100) {
        db.data.crawlHistory = db.data.crawlHistory.slice(-100);
    }

    await db.write();
}

// ============ 小红书内容操作 ============

/**
 * 获取小红书内容
 * @returns {Object[]}
 */
export function getXiaohongshuPosts() {
    return db.data.xiaohongshuPosts || [];
}

/**
 * 添加或更新小红书内容
 * @param {Object} post 
 */
export async function upsertXiaohongshuPost(post) {
    if (!db.data.xiaohongshuPosts) {
        db.data.xiaohongshuPosts = [];
    }

    const existingIndex = db.data.xiaohongshuPosts.findIndex(p => p.id === post.id);

    if (existingIndex >= 0) {
        db.data.xiaohongshuPosts[existingIndex] = {
            ...db.data.xiaohongshuPosts[existingIndex],
            ...post,
            updatedAt: new Date().toISOString()
        };
    } else {
        post.createdAt = new Date().toISOString();
        post.verified = false;  // 默认未验证
        post.helpful = 0;       // 有用投票
        post.notHelpful = 0;    // 无用投票
        db.data.xiaohongshuPosts.push(post);
    }

    await db.write();
    return post;
}

/**
 * 批量添加小红书内容
 * @param {Object[]} posts 
 */
export async function upsertXiaohongshuPosts(posts) {
    if (!db.data.xiaohongshuPosts) {
        db.data.xiaohongshuPosts = [];
    }

    let added = 0, updated = 0;

    for (const post of posts) {
        const existingIndex = db.data.xiaohongshuPosts.findIndex(p => p.id === post.id);

        if (existingIndex >= 0) {
            db.data.xiaohongshuPosts[existingIndex] = {
                ...db.data.xiaohongshuPosts[existingIndex],
                ...post,
                updatedAt: new Date().toISOString()
            };
            updated++;
        } else {
            post.createdAt = new Date().toISOString();
            post.verified = false;
            post.helpful = 0;
            post.notHelpful = 0;
            db.data.xiaohongshuPosts.push(post);
            added++;
        }
    }

    await db.write();
    return { added, updated };
}

/**
 * 投票小红书内容
 * @param {string} postId 
 * @param {boolean} isHelpful 
 */
export async function voteXiaohongshuPost(postId, isHelpful) {
    const post = db.data.xiaohongshuPosts?.find(p => p.id === postId);
    if (post) {
        if (isHelpful) {
            post.helpful = (post.helpful || 0) + 1;
        } else {
            post.notHelpful = (post.notHelpful || 0) + 1;
        }
        await db.write();
    }
    return post;
}

export default {
    initDatabase,
    getDatabase,
    upsertDeal,
    upsertDeals,
    getDeals,
    getNewDeals,
    markAllDealsAsRead,
    getSettings,
    updateSettings,
    updatePointsValue,
    getGiftCards,
    upsertGiftCard,
    logCrawl,
    getXiaohongshuPosts,
    upsertXiaohongshuPost,
    upsertXiaohongshuPosts,
    voteXiaohongshuPost
};
