import { readFileSync, existsSync } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { upsertGiftCard, getDatabase } from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * 加载种子数据到数据库
 */
export async function seedDatabase() {
    const db = getDatabase();

    // 只在礼品卡数据为空时加载
    if (db.data.giftCards.length === 0) {
        await loadGiftCards();
        console.log('   ✓ Gift cards loaded');
    }

    return true;
}

/**
 * 加载礼品卡种子数据
 */
async function loadGiftCards() {
    const seedPath = path.join(__dirname, 'seed/giftcards.json');

    if (!existsSync(seedPath)) {
        console.warn('   ⚠️ Gift cards seed file not found');
        return;
    }

    try {
        const data = JSON.parse(readFileSync(seedPath, 'utf-8'));

        for (const giftCard of data) {
            await upsertGiftCard(giftCard);
        }
    } catch (error) {
        console.error('   ❌ Failed to load gift cards:', error.message);
    }
}

export default seedDatabase;
