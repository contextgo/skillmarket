# Amex Offer Finder Skill

> 帮助 Amex 白金卡用户发现优惠并计算最优礼品卡购买路径以最大化积分价值。

## When to Use

Use this skill when the user wants to:
- 查找 Amex 相关优惠（澳洲/中国）
- 计算礼品卡购买的最优路径
- 获取积分最大化策略
- 监控新优惠并接收通知

## Prerequisites

- Node.js 18+
- npm 9+
- Amex 信用卡（可选，用于实际使用）

## Installation

### 方式 1: 自动安装（推荐）

```bash
# 克隆项目
git clone <repository-url> amex-offer-finder
cd amex-offer-finder

# 运行自动安装脚本（检查环境 + 安装依赖）
npm run setup
```

### 方式 2: 手动安装

```bash
# 克隆项目
git clone <repository-url> amex-offer-finder
cd amex-offer-finder

# 检查环境
npm run check-env

# 安装后端依赖
npm install

# 安装前端依赖
cd client && npm install && cd ..
```

### 环境要求

| 依赖 | 版本 | 检查命令 |
|------|------|---------|
| Node.js | 18+ | `node --version` |
| npm | 9+ | `npm --version` |

如果环境检查失败，脚本会提示你如何修复。
```

## Configuration

创建 `.env` 文件（**不会被打包，需用户自行配置**）：

```bash
# 可选：自定义端口
PORT=3001
NODE_ENV=development
```

## Usage

### 启动服务

```bash
# 方式1: 同时启动前后端（推荐）
npm run dev

# 方式2: 分别启动
# Terminal 1 - 后端
npm run server

# Terminal 2 - 前端
cd client && npm run dev
```

### 访问

- 前端界面: http://localhost:3000
- API 接口: http://localhost:3001/api

## API Endpoints

### 优惠相关

```bash
# 获取优惠列表
curl http://localhost:3001/api/deals

# 按地区过滤
curl "http://localhost:3001/api/deals?region=AU"

# 按类别过滤
curl "http://localhost:3001/api/deals?category=gift_card"

# 获取新优惠
curl http://localhost:3001/api/deals/new

# 标记所有为已读
curl -X POST http://localhost:3001/api/deals/read
```

### 爬虫控制

```bash
# 运行所有爬虫
curl -X POST http://localhost:3001/api/crawl

# 运行单个爬虫
curl -X POST http://localhost:3001/api/crawl/ozbargain

# 获取爬虫状态
curl http://localhost:3001/api/crawl/status
```

### 优化器

```bash
# 计算最优路径
curl -X POST http://localhost:3001/api/optimize \
  -H "Content-Type: application/json" \
  -d '{
    "merchant": "Woolworths",
    "amount": 100,
    "region": "AU"
  }'

# 批量计算
curl -X POST http://localhost:3001/api/optimize/batch \
  -H "Content-Type: application/json" \
  -d '{
    "merchants": [
      {"name": "Woolworths", "amount": 100},
      {"name": "Coles", "amount": 50}
    ],
    "region": "AU"
  }'
```

### 设置

```bash
# 获取设置
curl http://localhost:3001/api/settings

# 更新设置
curl -X PUT http://localhost:3001/api/settings \
  -H "Content-Type: application/json" \
  -d '{
    "crawlInterval": 30,
    "notificationsEnabled": true
  }'

# 更新积分价值
curl -X PUT http://localhost:3001/api/settings/points/amex \
  -H "Content-Type: application/json" \
  -d '{"valueAud": 0.012, "valueCny": 0.055}'
```

## Data Sources

### 澳洲 🇦🇺
- **Ozbargain** - 澳洲最大的优惠分享网站
- **Point Hacks** - 澳洲积分攻略网站
- **Australian Frequent Flyer** - 澳洲常旅客论坛
- **Reddit** - r/amex, r/churningaustralia

### 中国 🇨🇳
- **飞客茶馆** - 中国最大常旅客论坛
- **我玩卡** - 信用卡研究论坛

## Points Valuation (Default)

| 积分体系 | AUD | CNY |
|----------|-----|-----|
| Amex MR | 0.012 | 0.055 |
| Qantas | 0.015 | 0.070 |
| Velocity | 0.016 | 0.075 |
| Asia Miles | 0.025 | 0.120 |

可在设置页面自定义。

## Project Structure

```
amex-offer-finder/
├── src/
│   ├── index.js              # 主入口
│   ├── api/routes.js         # API 路由
│   ├── crawlers/             # 爬虫模块
│   ├── data/                 # 数据层
│   ├── models/               # 数据模型
│   ├── notifications/        # 通知系统
│   └── optimizer/            # 优化引擎
└── client/                   # React 前端
    └── src/
        ├── pages/            # 页面组件
        └── components/       # UI 组件
```

## Features

- 🕷️ **自动爬取优惠** - 从多个来源自动搜索 Amex 相关优惠
- 🧮 **积分优化器** - 计算最优礼品卡购买路径
- 🎁 **套娃计算** - 支持多级礼品卡叠加策略
- 🔔 **桌面通知** - 新优惠即时推送
- 💰 **自定义估值** - 自定义各积分体系的分值

## License

MIT License
