# Amex Offer Finder

> 帮助 Amex 白金卡用户发现散落在互联网上的优惠，并计算最优礼品卡购买路径以最大化积分价值。

## ✨ 功能特点

- 🕷️ **自动爬取优惠** - 从多个来源自动搜索 Amex 相关优惠
- 🧮 **积分优化器** - 计算最优礼品卡购买路径
- 🎁 **套娃计算** - 支持多级礼品卡叠加策略
- 🔔 **桌面通知** - 新优惠即时推送
- 💰 **自定义估值** - 自定义各积分体系的分值

## 📊 数据来源

### 澳洲 🇦🇺
| 来源 | 描述 |
|------|------|
| Ozbargain | 澳洲最大的优惠分享网站 |
| Point Hacks | 澳洲积分攻略网站 |
| Australian Frequent Flyer | 澳洲常旅客论坛 |
| Reddit | r/amex, r/churningaustralia |

### 中国 🇨🇳
| 来源 | 描述 |
|------|------|
| 飞客茶馆 | 中国最大常旅客论坛 |
| 我玩卡 | 信用卡研究论坛 |

## 🚀 快速开始

### 前置要求
- Node.js 18+
- npm 9+

### 安装

```bash
# 克隆项目
git clone <repository-url>
cd amex-offer-finder

# 安装后端依赖
npm install

# 安装前端依赖
cd client && npm install && cd ..
```

### 运行

```bash
# 方式1: 同时启动前后端（推荐）
npm run dev

# 方式2: 分别启动
# Terminal 1 - 后端
npm run server

# Terminal 2 - 前端
cd client && npm run dev
```

### 访问
- 前端界面: http://localhost:3000
- API接口: http://localhost:3001/api

## 📡 API 文档

### 优惠相关

```
GET  /api/deals              # 获取优惠列表
GET  /api/deals?region=AU    # 按地区过滤
GET  /api/deals?category=gift_card  # 按类别过滤
GET  /api/deals/new          # 获取新优惠
POST /api/deals/read         # 标记所有为已读
```

### 爬虫控制

```
POST /api/crawl              # 运行所有爬虫
POST /api/crawl/:source      # 运行单个爬虫
GET  /api/crawl/status       # 获取爬虫状态
```

### 优化器

```
POST /api/optimize           # 计算最优路径
POST /api/optimize/batch     # 批量计算
```

### 设置

```
GET  /api/settings           # 获取设置
PUT  /api/settings           # 更新设置
PUT  /api/settings/points/:id  # 更新积分价值
```

## 🧮 优化算法说明

优化器会计算以下类型的购买路径：

1. **直接消费** - 使用 Amex 卡直接刷卡
2. **渠道购买** - 通过 Cashrewards/ShopBack 购买礼品卡
3. **套娃路径** - 先购买中间礼品卡，再购买目标礼品卡

每条路径计算：
- Amex 积分价值
- 返现金额
- 礼品卡折扣
- 复杂度和风险评估

## ⚙️ 配置

### 积分价值（默认）

| 积分体系 | AUD | CNY |
|----------|-----|-----|
| Amex MR | 0.012 | 0.055 |
| Qantas | 0.015 | 0.070 |
| Velocity | 0.016 | 0.075 |
| Asia Miles | 0.025 | 0.120 |

可在设置页面自定义。

### 爬取频率

默认每 30 分钟自动爬取一次，可在设置中修改。

## 📁 项目结构

```
amex-offer-finder/
├── package.json
├── src/
│   ├── index.js              # 主入口
│   ├── api/routes.js         # API路由
│   ├── crawlers/             # 爬虫模块
│   ├── data/                 # 数据层
│   ├── models/               # 数据模型
│   ├── notifications/        # 通知系统
│   └── optimizer/            # 优化引擎
└── client/                   # React前端
    ├── src/
    │   ├── pages/            # 页面组件
    │   └── components/       # UI组件
    └── ...
```

## 🔒 隐私说明

- 所有数据存储在本地 (`data/db.json`)
- 不收集任何个人信息
- 爬虫仅抓取公开可访问的网页

## 📝 许可证

MIT License
