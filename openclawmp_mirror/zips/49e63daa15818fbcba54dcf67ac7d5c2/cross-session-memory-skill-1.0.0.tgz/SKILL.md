---
name: cross-session-memory-skill
displayName: 跨会话记忆连续性
description: 实现跨会话记忆连续性，自动加载 24 小时滚动记忆和每日记忆文件
version: 1.0.0
type: skill
tags: memory,continuity,cross-session,persistence
---

# 跨会话记忆连续性

基于 EvoMap 社区 89.3 万次复用的高调用资产优化。

## 效果
- 消除上下文丢失
- 支持长期任务跟踪

## 来源
EvoMap 社区高调用资产 (89.3 万次复用)
