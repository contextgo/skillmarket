---
name: invoice-organizer
description: 帮助用户将杂乱的发票和收据整理为规范的报税归档体系。当用户提到发票整理、收据归类、报税准备、费用分类、发票重命名时触发。自动从PDF和图片中提取日期、商家、金额等关键信息，按统一格式重命名文件，按年份/类别/商家分类归档，并生成CSV汇总表供会计使用。
---

# Invoice Organizer

> Platform: Windows / macOS / Linux | Runtime: Python >=3.8 | Dependencies: see `scripts/requirements.txt`

Transforms chaotic folders of invoices and receipts into a standardized, tax-ready filing system.

## When to Use

- Organizing invoices/receipts before tax season
- Sorting business expenses by vendor, category, or date
- Cleaning up messy download folders full of `invoice.pdf` / `invoice(1).pdf`
- Creating expense summaries (CSV) for accountants or reimbursement
- Archiving financial records by year/quarter

## Core Workflow

### Step 1: Scan & Diagnose

Run the organizer script on the target folder:

```bash
python scripts/invoice_organizer.py "<source_folder>" --dry-run
```

Report the scan results to the user:
- File count and types (PDF, JPG, PNG, etc.)
- Which files have extractable text vs. need OCR
- Detected vendors, date range, duplicate files

### Step 2: Choose Organization Strategy

If the user hasn't specified, ask:

| Mode | Command Flag | Structure | Best For |
|------|-------------|-----------|----------|
| Year + Category | `-m year_category` (default) | `2024/Software/Adobe/` | Tax preparation |
| By Vendor | `-m vendor` | `Adobe/`, `Amazon/` | Vendor tracking |
| By Category | `-m category` | `Software/`, `Travel/` | Expense reports |

### Step 3: Execute

```bash
# Default: copy originals, organize by year+category
python scripts/invoice_organizer.py "<source>" -o "<output>"

# Move instead of copy
python scripts/invoice_organizer.py "<source>" -o "<output>" --no-copy

# Organize by vendor
python scripts/invoice_organizer.py "<source>" -o "<output>" -m vendor
```

### Step 4: Review Results

The script generates:
1. **Organized folder structure** with renamed files: `YYYY-MM-DD Vendor - Invoice - Description.ext`
2. **`invoice-summary.csv`** with all extracted data (date, vendor, amount, category)
3. **`Needs-Review/`** folder for files where information couldn't be fully extracted

Present the summary to the user and help them review flagged files.

## File Naming Convention

```
YYYY-MM-DD Vendor - Invoice - Description.ext
```

Examples:
- `2024-03-15 Adobe - Invoice - Software Purchase.pdf`
- `2024-01-10 Amazon - Invoice - Office Purchase.jpg`

## Script Reference

| Script | Purpose |
|--------|---------|
| `scripts/invoice_organizer.py` | Main organizer (scan, extract, rename, sort) |
| `scripts/requirements.txt` | Python dependencies |
| `scripts/README.md` | Detailed script docs and optimization notes |

## Supported Formats

- **PDF**: Text extraction via pdfplumber
- **Images** (JPG, PNG, TIFF, BMP): OCR via Tesseract (optional)
- Fallback: filename-based date/vendor extraction when OCR is unavailable

## Known Limitations

- Image OCR requires Tesseract to be installed separately
- Chinese invoice templates (VAT special/general) have limited pattern coverage
- Scanned PDFs without embedded text need OCR to extract content
