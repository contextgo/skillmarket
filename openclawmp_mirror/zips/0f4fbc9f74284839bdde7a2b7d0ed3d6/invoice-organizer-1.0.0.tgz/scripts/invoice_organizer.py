#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
发票智能整理脚本 (Invoice Organizer)
自动整理发票/收据，提取关键信息，标准化重命名，分类归档

平台：跨平台（Windows/macOS/Linux）
运行时：Python >=3.8
依赖：pip install pdfplumber pillow pytesseract pandas openpyxl
      OCR 需额外安装 Tesseract: https://github.com/tesseract-ocr/tesseract

用法：
    python invoice_organizer.py <源文件夹> [-o 输出目录] [-m 组织方式] [--dry-run] [--no-copy]
"""

import os
import sys
import re
import io
import shutil
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Optional, Dict, List, Tuple
from dataclasses import dataclass, asdict
import csv

# 修复 Windows 终端 emoji/中文输出问题
if sys.platform == 'win32':
    try:
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass

# 可选依赖
try:
    import pdfplumber
    HAS_PDF = True
except ImportError:
    HAS_PDF = False

try:
    from PIL import Image
    import pytesseract
    HAS_OCR = True
except ImportError:
    HAS_OCR = False

try:
    import pandas as pd
    HAS_PANDAS = True
except ImportError:
    HAS_PANDAS = False


SUPPORTED_EXTENSIONS = {'.pdf', '.jpg', '.jpeg', '.png', '.tif', '.tiff', '.bmp'}


@dataclass
class InvoiceInfo:
    """发票信息数据类"""
    original_file: str
    original_ext: str = ""
    date: Optional[str] = None
    vendor: Optional[str] = None
    invoice_number: Optional[str] = None
    amount: Optional[str] = None
    currency: str = ""
    description: Optional[str] = None
    category: Optional[str] = None
    new_filename: Optional[str] = None
    new_path: Optional[str] = None
    status: str = "pending"
    notes: str = ""


class InvoiceOrganizer:
    """发票整理器主类"""

    VENDOR_CATEGORIES = {
        # 软件/订阅
        "adobe": "Software", "microsoft": "Software", "google": "Software",
        "apple": "Software", "github": "Software", "jetbrains": "Software",
        "slack": "Software", "zoom": "Software", "aws": "Software",
        "azure": "Software", "notion": "Software", "figma": "Software",
        "openai": "Software", "chatgpt": "Software",
        # 电商/办公
        "amazon": "Office", "京东": "Office", "淘宝": "Office",
        "天猫": "Office", "staples": "Office", "得力": "Office",
        "拼多多": "Office",
        # 云服务
        "阿里云": "Services", "腾讯云": "Services", "华为云": "Services",
        "netlify": "Services", "vercel": "Services", "stripe": "Services",
        "paypal": "Services", "cloudflare": "Services",
        # 差旅
        "携程": "Travel", "去哪儿": "Travel", "飞猪": "Travel",
        "airbnb": "Travel", "uber": "Travel", "滴滴": "Travel",
        "铁路": "Travel", "航空": "Travel", "booking": "Travel",
        # 餐饮
        "美团": "Meals", "饿了么": "Meals", "星巴克": "Meals",
        "肯德基": "Meals", "麦当劳": "Meals", "starbucks": "Meals",
        # 通信
        "中国移动": "Telecom", "中国联通": "Telecom", "中国电信": "Telecom",
    }

    DATE_PATTERNS = [
        r'(\d{4}[-/\.]\d{1,2}[-/\.]\d{1,2})',
        r'(\d{4}年\d{1,2}月\d{1,2}日?)',
        r'(\d{1,2}[-/]\d{1,2}[-/]\d{4})',
        r'(\d{8})',
    ]

    AMOUNT_PATTERNS = [
        r'(?:Amount\s*Due|Total|Amount|合计|总计|价税合计|金额|应付|实付)[：:\s]*[￥¥\$]?\s*(\d{1,3}(?:,\d{3})*\.?\d{0,2})',
        r'[￥¥\$]\s*(\d{1,3}(?:,\d{3})*\.\d{2})',
        r'(\d+(?:\.\d{2})?)\s*元',
    ]

    INVOICE_NUMBER_PATTERNS = [
        r'(?:发票号码?|发票代码|Invoice\s*#?|Invoice\s*Number|订单号|Order\s*#?)[：:\s]*([A-Za-z0-9\-]+)',
    ]

    def __init__(self, source_dir: str, output_dir: str = None,
                 organize_by: str = "year_category",
                 copy_originals: bool = True):
        self.source_dir = Path(source_dir).resolve()
        self.output_dir = Path(output_dir).resolve() if output_dir else self.source_dir / "Invoices"
        self.organize_by = organize_by
        self.copy_originals = copy_originals

        self.invoices: List[InvoiceInfo] = []
        self.duplicates: List[Tuple[str, str]] = []
        self.file_hashes: Dict[str, str] = {}

        self._tesseract_available = False
        if HAS_OCR:
            self._setup_tesseract()

    def _setup_tesseract(self):
        """检测并配置 Tesseract"""
        if os.name == 'nt':
            candidates = [
                r"C:\Program Files\Tesseract-OCR\tesseract.exe",
                r"C:\Program Files (x86)\Tesseract-OCR\tesseract.exe",
            ]
            for tp in candidates:
                if os.path.exists(tp):
                    pytesseract.pytesseract.tesseract_cmd = tp
                    self._tesseract_available = True
                    return

        # 尝试调用 tesseract 检测是否在 PATH 中
        try:
            import subprocess
            result = subprocess.run(['tesseract', '--version'],
                                    capture_output=True, timeout=5)
            self._tesseract_available = (result.returncode == 0)
        except Exception:
            self._tesseract_available = False

    def scan_files(self) -> List[Path]:
        """扫描源文件夹中的所有发票文件（含子目录）"""
        files = []
        for f in self.source_dir.rglob('*'):
            if f.is_file() and f.suffix.lower() in SUPPORTED_EXTENSIONS:
                # 排除输出目录中的文件
                try:
                    f.relative_to(self.output_dir)
                    continue
                except ValueError:
                    pass
                files.append(f)

        files = sorted(set(files))
        print(f"[scan] Found {len(files)} invoice files")
        return files

    def compute_file_hash(self, filepath: Path) -> str:
        """计算 MD5 用于去重"""
        h = hashlib.md5()
        with open(filepath, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()

    def check_duplicate(self, filepath: Path) -> Optional[str]:
        """返回重复文件的原始路径，无重复返回 None"""
        fhash = self.compute_file_hash(filepath)
        if fhash in self.file_hashes:
            return self.file_hashes[fhash]
        self.file_hashes[fhash] = str(filepath)
        return None

    def extract_text_from_pdf(self, filepath: Path) -> str:
        if not HAS_PDF:
            return ""
        try:
            text = ""
            with pdfplumber.open(filepath) as pdf:
                for page in pdf.pages:
                    t = page.extract_text()
                    if t:
                        text += t + "\n"
            return text
        except Exception as e:
            print(f"  [warn] PDF read failed {filepath.name}: {e}", file=sys.stderr)
            return ""

    def extract_text_from_image(self, filepath: Path) -> str:
        if not HAS_OCR or not self._tesseract_available:
            return ""
        try:
            image = Image.open(filepath)
            text = pytesseract.image_to_string(image, lang='chi_sim+eng')
            return text
        except Exception as e:
            print(f"  [warn] OCR failed {filepath.name}: {e}", file=sys.stderr)
            return ""

    def extract_text(self, filepath: Path) -> str:
        suffix = filepath.suffix.lower()
        if suffix == '.pdf':
            return self.extract_text_from_pdf(filepath)
        elif suffix in SUPPORTED_EXTENSIONS - {'.pdf'}:
            return self.extract_text_from_image(filepath)
        return ""

    def normalize_date(self, date_str: str) -> Optional[str]:
        if not date_str:
            return None

        cleaned = date_str.strip()
        cleaned = re.sub(r'[年月]', '-', cleaned)
        cleaned = re.sub(r'[日号]', '', cleaned)
        cleaned = cleaned.replace('/', '-').replace('.', '-')

        formats = ['%Y-%m-%d', '%m-%d-%Y', '%d-%m-%Y', '%Y%m%d']
        for fmt in formats:
            try:
                dt = datetime.strptime(cleaned, fmt)
                if 2000 <= dt.year <= 2099:
                    return dt.strftime('%Y-%m-%d')
            except ValueError:
                continue
        return None

    def extract_date(self, text: str, filepath: Path) -> Optional[str]:
        # 从文本提取
        for pattern in self.DATE_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                result = self.normalize_date(match.group(1))
                if result:
                    return result

        # 从文件名提取
        fname = filepath.stem
        for pattern in self.DATE_PATTERNS:
            match = re.search(pattern, fname)
            if match:
                result = self.normalize_date(match.group(1))
                if result:
                    return result

        # 最后回退到文件修改日期
        try:
            mtime = os.path.getmtime(filepath)
            return datetime.fromtimestamp(mtime).strftime('%Y-%m-%d')
        except Exception:
            return None

    def extract_vendor(self, text: str, filepath: Path) -> str:
        """从文本和文件名推断商家"""
        # 先尝试从已知商家关键词匹配（优先）
        combined = (text + " " + filepath.stem).lower()
        for key in sorted(self.VENDOR_CATEGORIES.keys(), key=len, reverse=True):
            if key.lower() in combined:
                return key.title() if key.isascii() else key

        # 从文件名中提取商家（文件名通常更可靠）
        fname = filepath.stem
        # 排除常见前缀
        prefixes = ['付款单', '凭证', '副本', '发票', '导出', '已付款', '待报销', 
                    '微信截图', '报销单', '收据', '新建', '未命名', '结算单', 
                    '订单', '财务凭证', '账单', '_']
        cleaned_fname = fname
        for prefix in prefixes:
            if cleaned_fname.startswith(prefix):
                cleaned_fname = cleaned_fname[len(prefix):]
        
        # 提取下划线分隔的商家名
        parts = re.split(r'[_\d]', cleaned_fname)
        for part in parts:
            part = part.strip()
            if 2 <= len(part) <= 20 and part not in ['财务', '电子版', '扫描版', '归档', '待报销', '已付款', '副本', '终稿']:
                # 检查是否是已知商家
                for key in self.VENDOR_CATEGORIES.keys():
                    if key in part:
                        return key.title() if key.isascii() else key
                return part[:25]

        # 从文本前几行提取候选（备用）
        lines = [l.strip() for l in text.split('\n') if l.strip()]
        # 排除购买方/销售方等通用字段
        exclude = {'invoice', 'receipt', 'total', 'amount', 'date',
                    '发票', '收据', '总计', '金额', '日期', '税', '价',
                    '购买方', '销售方', '名称', 'name', 'address', '电话',
                    '纳税人识别号', '开户行', '账号', '地址', '电话'}
        for line in lines[:15]:
            if 2 < len(line) < 40:
                # 排除包含"名称："的行（通常是购买方或销售方标签）
                if '名称' in line and ('购买' in line or '销售' in line):
                    continue
                if not any(w in line.lower() for w in exclude):
                    vendor = re.sub(r'[<>:"/\\|?*#]', '', line).strip()
                    if len(vendor) > 1:
                        return vendor[:25]

        return "Unknown"

    def extract_amount(self, text: str) -> Tuple[Optional[str], str]:
        """返回 (金额, 货币符号)"""
        for pattern in self.AMOUNT_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                raw = match.group(1).replace(',', '')
                try:
                    val = f"{float(raw):.2f}"
                    # 推断货币
                    full = match.group(0)
                    if '$' in full:
                        return val, "USD"
                    elif any(c in full for c in '￥¥元'):
                        return val, "CNY"
                    return val, ""
                except ValueError:
                    pass
        return None, ""

    def extract_invoice_number(self, text: str) -> Optional[str]:
        for pattern in self.INVOICE_NUMBER_PATTERNS:
            match = re.search(pattern, text, re.IGNORECASE)
            if match:
                return match.group(1).strip()[:30]
        return None

    def get_category(self, vendor: str) -> str:
        v = vendor.lower()
        for key, cat in self.VENDOR_CATEGORIES.items():
            if key.lower() in v:
                return cat
        return "Other"

    def generate_filename(self, info: InvoiceInfo) -> str:
        """生成标准化文件名，保留原始扩展名"""
        date = info.date or "Unknown-Date"
        vendor = info.vendor or "Unknown"
        desc = info.description or "Invoice"
        ext = info.original_ext or ".pdf"

        # 过滤掉包含"名称"的无效商家名（通常是购买方信息）
        if '名称' in vendor or vendor == "Unknown":
            vendor = "其他"

        # 清理非法字符
        vendor = re.sub(r'[<>:"/\\|?*]', '-', vendor).strip()[:20]
        desc = re.sub(r'[<>:"/\\|?*]', '-', desc).strip()[:30]

        return f"{date} {vendor} - Invoice - {desc}{ext}"

    def process_file(self, filepath: Path) -> InvoiceInfo:
        """处理单个文件，提取信息并生成标准文件名"""
        info = InvoiceInfo(
            original_file=str(filepath),
            original_ext=filepath.suffix.lower()
        )

        # 去重
        dup = self.check_duplicate(filepath)
        if dup:
            info.status = "duplicate"
            info.notes = f"Duplicate of: {dup}"
            self.duplicates.append((str(filepath), dup))
            return info

        # 提取文本
        text = self.extract_text(filepath)

        # 提取各项信息
        info.date = self.extract_date(text, filepath)
        info.vendor = self.extract_vendor(text, filepath)
        info.amount, info.currency = self.extract_amount(text)
        info.invoice_number = self.extract_invoice_number(text)
        info.category = self.get_category(info.vendor)
        info.description = f"{info.category} Purchase"

        # 生成文件名（无论是否信息完整都生成）
        info.new_filename = self.generate_filename(info)

        # 判断状态
        if not text and filepath.suffix.lower() != '.pdf':
            info.status = "needs_review"
            reasons = ["No text extracted"]
            if not self._tesseract_available:
                reasons.append("Tesseract not installed")
            info.notes = "; ".join(reasons)
        elif info.vendor == "Unknown":
            info.status = "needs_review"
            info.notes = "Vendor not identified"
        else:
            info.status = "success"

        return info

    def organize(self, dry_run: bool = False) -> Dict:
        """执行整理流程"""
        print("\n" + "=" * 60)
        print("Invoice Organizer")
        print("=" * 60)

        files = self.scan_files()
        if not files:
            print("[error] No invoice files found")
            return {"total": 0}

        # 环境检查提示
        if not HAS_PDF:
            print("[warn] pdfplumber not installed, PDF extraction disabled")
        if not self._tesseract_available:
            print("[info] Tesseract not available, image OCR disabled (filename-based fallback active)")

        print(f"\n[process] Processing {len(files)} files...")
        for i, fp in enumerate(files, 1):
            print(f"  [{i}/{len(files)}] {fp.name}")
            info = self.process_file(fp)
            self.invoices.append(info)

        if dry_run:
            self._print_preview()
            return self._generate_stats()

        print(f"\n[organize] Creating directory structure...")
        self._create_directories()

        stats = self._generate_stats()
        self._generate_csv()
        self._print_report(stats)

        return stats

    def _print_preview(self):
        """预览模式输出"""
        print("\n--- DRY RUN PREVIEW ---")
        for info in self.invoices:
            status_tag = f"[{info.status}]"
            if info.status == "duplicate":
                print(f"  {status_tag:15} {Path(info.original_file).name} (skip)")
            else:
                print(f"  {status_tag:15} {Path(info.original_file).name}")
                print(f"  {'':15} -> {info.new_filename}")
                if info.notes:
                    print(f"  {'':15}    Note: {info.notes}")
        print(f"\nTotal: {len(self.invoices)} | "
              f"Success: {sum(1 for i in self.invoices if i.status == 'success')} | "
              f"Review: {sum(1 for i in self.invoices if i.status == 'needs_review')} | "
              f"Duplicate: {sum(1 for i in self.invoices if i.status == 'duplicate')}")

    def _get_quarter(self, date_str: str) -> str:
        """从日期字符串获取季度 (Q1-Q4)"""
        if not date_str or len(date_str) < 7:
            return "Unknown"
        try:
            month = int(date_str.split('-')[1])
            if 1 <= month <= 3:
                return "Q1"
            elif 4 <= month <= 6:
                return "Q2"
            elif 7 <= month <= 9:
                return "Q3"
            else:
                return "Q4"
        except (ValueError, IndexError):
            return "Unknown"

    def _create_directories(self):
        """创建目录结构并复制/移动文件"""
        review_dir = self.output_dir / "Needs-Review"

        for info in self.invoices:
            if info.status in ("duplicate", "error"):
                continue

            if info.status == "needs_review":
                target_dir = review_dir
            elif self.organize_by == "year_quarter_category":
                # 年份→季度→类别 三层结构
                year = info.date[:4] if info.date and len(info.date) >= 4 else "Unknown"
                quarter = self._get_quarter(info.date)
                target_dir = self.output_dir / year / quarter / (info.category or "Other")
            elif self.organize_by == "year_category":
                year = info.date[:4] if info.date and len(info.date) >= 4 else "Unknown"
                target_dir = self.output_dir / year / (info.category or "Other") / (info.vendor or "Unknown")
            elif self.organize_by == "vendor":
                target_dir = self.output_dir / (info.vendor or "Unknown")
            elif self.organize_by == "category":
                target_dir = self.output_dir / (info.category or "Other")
            else:
                target_dir = self.output_dir

            target_dir.mkdir(parents=True, exist_ok=True)

            src = Path(info.original_file)
            # 确保有文件名
            fname = info.new_filename or src.name
            dst = target_dir / fname

            # 处理目标文件名冲突
            counter = 1
            while dst.exists():
                stem = Path(fname).stem
                ext = Path(fname).suffix
                dst = target_dir / f"{stem} ({counter}){ext}"
                counter += 1

            try:
                if self.copy_originals:
                    shutil.copy2(src, dst)
                else:
                    shutil.move(str(src), str(dst))
                info.new_path = str(dst)
                rel = dst.relative_to(self.output_dir)
                print(f"  [ok] {src.name} -> {rel}")
            except Exception as e:
                info.status = "error"
                info.notes = f"File operation failed: {e}"
                print(f"  [fail] {src.name}: {e}", file=sys.stderr)

    def _generate_stats(self) -> Dict:
        stats = {
            "total": len(self.invoices),
            "success": sum(1 for i in self.invoices if i.status == "success"),
            "needs_review": sum(1 for i in self.invoices if i.status == "needs_review"),
            "duplicates": sum(1 for i in self.invoices if i.status == "duplicate"),
            "errors": sum(1 for i in self.invoices if i.status == "error"),
        }

        amounts = []
        for i in self.invoices:
            if i.amount:
                try:
                    amounts.append(float(i.amount))
                except ValueError:
                    pass
        stats["total_amount"] = sum(amounts) if amounts else 0

        dates = [i.date for i in self.invoices if i.date]
        stats["date_range"] = f"{min(dates)} ~ {max(dates)}" if dates else "N/A"

        vendors = set(i.vendor for i in self.invoices if i.vendor and i.vendor != "Unknown")
        stats["unique_vendors"] = len(vendors)

        return stats

    def _generate_csv(self):
        csv_path = self.output_dir / "invoice-summary.csv"
        with open(csv_path, 'w', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f)
            writer.writerow(['Date', 'Vendor', 'Invoice Number', 'Description',
                             'Amount', 'Currency', 'Category', 'File Path',
                             'Status', 'Notes'])
            for info in self.invoices:
                writer.writerow([
                    info.date, info.vendor, info.invoice_number,
                    info.description, info.amount, info.currency,
                    info.category, info.new_path, info.status, info.notes
                ])
        print(f"\n[csv] Generated: {csv_path}")

    def _print_report(self, stats: Dict):
        print("\n" + "=" * 60)
        print("ORGANIZATION COMPLETE")
        print("=" * 60)
        print(f"""
  Processed:      {stats['total']} files
  Organized:      {stats['success']}
  Needs review:   {stats['needs_review']}
  Duplicates:     {stats['duplicates']}
  Errors:         {stats['errors']}
  Date range:     {stats['date_range']}
  Total amount:   {stats['total_amount']:.2f}
  Vendors:        {stats['unique_vendors']}

  Output:  {self.output_dir}
  CSV:     {self.output_dir / 'invoice-summary.csv'}
""")

        review_list = [i for i in self.invoices if i.status == "needs_review"]
        if review_list:
            print("  Files needing review:")
            for i in review_list[:10]:
                print(f"    - {Path(i.original_file).name}: {i.notes}")
            if len(review_list) > 10:
                print(f"    ... and {len(review_list) - 10} more")


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description='Invoice Organizer - Auto-organize invoices and receipts',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""Examples:
  %(prog)s ~/Desktop/receipts
  %(prog)s ~/Desktop/receipts -o ~/Documents/Invoices
  %(prog)s ~/Desktop/receipts -m vendor --dry-run
  %(prog)s ~/Desktop/receipts --no-copy
"""
    )
    parser.add_argument('source_dir', help='Source directory containing invoice files')
    parser.add_argument('-o', '--output', help='Output directory (default: <source>/Invoices)')
    parser.add_argument('-m', '--mode',
                        choices=['year_quarter_category', 'year_category', 'vendor', 'category'],
                        default='year_quarter_category',
                        help='Organization mode (default: year_quarter_category)')
    parser.add_argument('--no-copy', action='store_true',
                        help='Move files instead of copying (destructive)')
    parser.add_argument('--dry-run', action='store_true',
                        help='Preview only, no file operations')

    args = parser.parse_args()

    if not os.path.isdir(args.source_dir):
        print(f"[error] Source directory not found: {args.source_dir}", file=sys.stderr)
        sys.exit(1)

    if args.dry_run:
        print("[mode] DRY RUN - no files will be moved/copied")

    organizer = InvoiceOrganizer(
        source_dir=args.source_dir,
        output_dir=args.output,
        organize_by=args.mode,
        copy_originals=not args.no_copy
    )

    organizer.organize(dry_run=args.dry_run)


if __name__ == "__main__":
    main()
