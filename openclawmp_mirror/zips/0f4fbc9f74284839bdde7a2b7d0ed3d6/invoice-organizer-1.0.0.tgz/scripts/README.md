# Invoice Organizer Script

## Quick Start

```bash
# Install dependencies
pip install pdfplumber pillow pytesseract pandas openpyxl

# Optional: Install Tesseract for image OCR
# Windows: https://github.com/UB-Mannheim/tesseract/wiki
# macOS:   brew install tesseract
# Linux:   sudo apt install tesseract-ocr tesseract-ocr-chi-sim
```

## Usage

```bash
# Basic: organize invoices (copies originals, sorts by year+category)
python invoice_organizer.py "C:\Users\me\Desktop\receipts"

# Specify output directory
python invoice_organizer.py "C:\Users\me\Desktop\receipts" -o "D:\Invoices"

# Organize by vendor
python invoice_organizer.py "C:\Users\me\Desktop\receipts" -m vendor

# Preview mode (no file operations)
python invoice_organizer.py "C:\Users\me\Desktop\receipts" --dry-run

# Move files instead of copying
python invoice_organizer.py "C:\Users\me\Desktop\receipts" --no-copy
```

## Output Structure

```
Invoices/
├── 2024/
│   ├── Software/
│   │   └── Adobe/
│   │       └── 2024-03-15 Adobe - Invoice - Software Purchase.pdf
│   ├── Office/
│   │   └── Amazon/
│   │       └── 2024-02-10 Amazon - Invoice - Office Purchase.jpg
│   └── Travel/
│       └── 携程/
│           └── 2024-04-20 携程 - Invoice - Travel Purchase.pdf
├── Needs-Review/
│   └── (files with incomplete info)
└── invoice-summary.csv
```

## Supported Vendors

| Category | Vendors |
|----------|---------|
| Software | Adobe, Microsoft, Google, Apple, GitHub, JetBrains, Slack, Zoom, AWS, Notion, Figma, OpenAI |
| Office | Amazon, Staples, 京东, 淘宝, 天猫, 得力, 拼多多 |
| Services | Stripe, PayPal, 阿里云, 腾讯云, 华为云, Netlify, Vercel, Cloudflare |
| Travel | 携程, 去哪儿, 飞猪, Airbnb, Uber, 滴滴, Booking |
| Meals | 美团, 饿了么, 星巴克, 肯德基, 麦当劳 |
| Telecom | 中国移动, 中国联通, 中国电信 |

Unrecognized vendors are categorized as "Other".

## Troubleshooting

**PDF text extraction returns empty**: The PDF may be scanned (image-based). Install Tesseract for OCR support.

**Chinese text garbled in CSV**: The CSV uses UTF-8-BOM encoding. Open with Excel directly or import with UTF-8 encoding.

**Tesseract not found on Windows**: Download from the link above, install, then either add to PATH or the script auto-detects common install locations.
