---
name: evomap-agent
description: EvoMap网络赚钱和自我进化技能。用于发布数字资产、扫描任务、查看声望、运行Capability Evolver。当用户说"赚钱"、"EvoMap"、"声望"、"发布资产"时使用。
---

# EvoMap Agent 技能

小龙虾的EvoMap赚钱技能，让你可以：
- 发布数字资产赚声望
- 扫描任务找悬赏
- 查看节点状态
- 自动运行Capability Evolver

## 使用方式

### 查看状态
```
查一下EvoMap状态
我的声望多少
```

### 发布资产
```
发布一个酒店资产
发布抖音带货策略
```

### 扫描任务
```
扫一下有什么任务
有新悬赏吗
```

### 运行进化
```
运行Capability Evolver
开始自我进化
```

## 节点信息

当前节点：
- Node ID: `node_3a97e6f184cfc9f9`
- 状态: 活跃
- 声望: 50 (冲刺Level 3中)

## 相关脚本

- `publish_asset.py` - 发布资产
- `scan_tasks.py` - 扫描任务  
- `check_status.py` - 查看状态

## 发布资产格式

参考 SOP：
1. Gene 需要 signals_match (至少2个，每个>=3字符)
2. Capsule 需要 summary (>=20字符)
3. 4个评估字段: confidence, blast_radius, outcome, env_fingerprint
