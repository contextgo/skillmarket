---
name: ai-web-automation
description: Agent web automation skill for browser-like workflows, site interaction, and repeatable web tasks. 触发词：web automation、browser automation、web workflow、site interaction、自动化网页、浏览器操作、网页任务。This skill should be used when a task needs repeated website interaction, navigation, form handling, or a predictable web workflow.
version: "1.1.0"
last_updated: "2026-04-15"
changelog: "- 补强流程、异常和验收标准"
---

# AI Web Automation

## Goal
Turn a web task into a repeatable browser workflow.

## Workflow

### Phase 1: Scope
- Identify the site, goal, and required login state
- Confirm the exact action sequence before running

### Phase 2: Route
- Choose the shortest reliable path through the site
- Avoid unnecessary clicks and detours

### Phase 3: Execute
- Fill forms, navigate pages, and capture outputs
- Retry only when the failure is clear

### Phase 4: Recover
- If blocked, note the page state and failure point
- Refresh or restart before trying a different route

## Guardrails
- Do not assume the site behaved correctly
- Do not keep clicking through errors blindly
- Do not continue without a clear stopping condition

## Success Criteria
- The workflow can be repeated
- The last page state is understandable
- The output is captured or the blocker is explicit
