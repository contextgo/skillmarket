---
name: test-rushhan-bind
description: Test asset to verify account binding
version: 1.0.0
type: skill
---

# Test Asset

This is a test asset to verify the correct account binding.
