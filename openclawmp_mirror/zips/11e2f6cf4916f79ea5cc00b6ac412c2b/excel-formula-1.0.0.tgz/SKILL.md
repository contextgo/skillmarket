---
name: excel-formula
description: Excel公式助手。用于常用Excel函数公式、模板公式、数据处理技巧。当需要写Excel公式、处理表格数据时触发。
---

# Excel公式助手

## 常用函数速查

### 数学统计函数
```excel
=SUM(A1:A10)           // 求和
=AVERAGE(A1:A10)       // 平均值
=COUNT(A1:A10)         // 计数（数字）
=COUNTA(A1:A10)        // 计数（非空）
=MAX(A1:A10)           // 最大值
=MIN(A1:A10)           // 最小值
=ROUND(A1,2)           // 四舍五入
=SUMIF(A1:A10,">60")   // 条件求和
=AVERAGEIF(A1:A10,">60") // 条件平均
```

### 查找引用函数
```excel
=VLOOKUP(A1,B:C,2,FALSE)  // 垂直查找
=INDEX(A1:C10,2,3)         // 返回指定位置值
=MATCH("张三",A1:A10,0)     // 查找位置
=XLOOKUP(A1,B:C,2)          // 现代查找（365）
=HLOOKUP(A1,1:3,2,FALSE)   // 水平查找
=INDIRECT("A"&B1)           // 间接引用
```

### 条件逻辑函数
```excel
=IF(A1>=60,"及格","不及格")           // 条件判断
=IF(AND(A1>0,B1>0),"合法","非法")     // 多条件AND
=IF(OR(A1>100,B1>100),"超限","正常")  // 多条件OR
=IFERROR(A1/B1,0)                    // 错误处理
=IFS(A1>=90,"A",A1>=80,"B",TRUE,"C") // 多条件判断
=SWITCH(A1,"甲","A","乙","B",TRUE,"C") // 枚举判断
```

### 文本函数
```excel
=LEFT(A1,3)                 // 提取左侧
=RIGHT(A1,4)                // 提取右侧
=MID(A1,2,3)                // 提取中间
=LEN(A1)                    // 文本长度
=TRIM(A1)                   // 删除空格
=UPPER(A1)                  // 转大写
=LOWER(A1)                  // 转小写
=CONCAT(A1,"-",B1)          // 文本合并
=TEXTJOIN("-",TRUE,A1:C1)   // 分隔符合并
=SUBSTITUTE(A1,"旧","新")   // 文本替换
=FIND("关键词",A1)          // 查找位置
```

### 日期函数
```excel
=TODAY()                    // 今天日期
=NOW()                      // 现在时间
=YEAR(A1)                   // 年份
=MONTH(A1)                  // 月份
=DAY(A1)                    // 日期
=WEEKDAY(A1,2)              // 星期几(1-7)
=DATEDIF(A1,B1,"Y")         // 日期差（年）
=DATEDIF(A1,B1,"M")         // 日期差（月）
=DATEDIF(A1,B1,"D")         // 日期差（天）
=EDATE(A1,3)                // 日期加减月
=EOMONTH(A1,0)              // 月末日期
=WORKDAY(A1,5)              // 工作日加减
```

## 实用公式模板

### 成绩评级
```excel
=IF(A1>=90,"A",IF(A1>=80,"B",IF(A1>=60,"C","D")))
// 或
=IFS(A1>=90,"A",A1>=80,"B",A1>=60,"C",TRUE,"D")
```

### 达成率计算
```excel
=IF(B1=0,"-",A1/B1)                    // 避免除零
=ROUND(A1/B1,2)                         // 保留2位小数
=TEXT(A1/B1,"0%")                        // 百分比格式
```

### 条件计数
```excel
=COUNTIF(A1:A10,">=60")                 // 及格人数
=COUNTIFS(A1:A10,"男",B1:B10,">=60")    // 多条件计数
=SUMPRODUCT((A1:A10>=60)*(B1:B10="男")) // 数组计数
```

### 条件求和
```excel
=SUMIF(A1:A10,"产品A",B1:B10)           // 条件求和
=SUMIFS(C1:C10,A1:A10,"产品A",B1:B10,">=100") // 多条件
```

### 数据去重计数
```excel
=SUMPRODUCT(1/COUNTIF(A1:A10,A1:A10))  // 不重复计数
```

### 查找匹配
```excel
=VLOOKUP(E1,A:C,3,FALSE)                // 基本查找
=INDEX(B:B,MATCH(E1,A:A,0))             // INDEX+MATCH
=XLOOKUP(E1,A:A,B:B,"未找到")           // 365新函数
```

### 多条件查找
```excel
=INDEX(C:C,MATCH(1,(A:A=E1)*(B:B=F1),0))  // 数组公式
```

### 提取不重复列表
```excel
=UNIQUE(A1:A10)                         // 365新函数
```

## 数组公式

### 数组基础
```excel
Ctrl+Shift+Enter  // 输入数组公式
// 公式两边会出现{}

=SUM((A1:A10>60)*(B1:B10))             // 满足条件1的B列求和
=FILTER(A1:C10,B1:B10>=60)              // 筛选满足条件的行
=SORT(A1:B10,2,-1)                       // 按第2列降序排列
```

## 数据处理模板

### 排名公式
```excel
=RANK(A1,A$1:A$10)                      // 降序排名
=RANK.AVG(A1,A$1:A$10)                  // 平均排名
=RANK.EQ(A1,A$1:A$10,1)                 // 升序排名
```

### 百分比计算
```excel
=ROW(A1)/COUNTA(A$1:A$10)               // 序号百分比
=A1/SUM(A$1:A$10)                       // 占比
=PERCENTRANK(A$1:A$10,A1)               // 百分位排名
```

### 数据验证
```excel
=ISNUMBER(A1)                           // 是否数字
=ISTEXT(A1)                             // 是否文本
=ISBLANK(A1)                            // 是否空白
=ISERROR(A1)                            // 是否错误
=AND(A1>=0,A1<=100)                     // 范围验证
```

## 常见问题解决

| 问题 | 公式 |
|------|------|
| 文本数字转数值 | =A1*1 或 =VALUE(A1) |
| 数值转文本 | =TEXT(A1,"0") |
| 去除空格 | =TRIM(A1) |
| 多列合并 | =CONCAT(A1:C1) |
| 按分隔符合并 | =TEXTJOIN(",",TRUE,A1:C1) |
