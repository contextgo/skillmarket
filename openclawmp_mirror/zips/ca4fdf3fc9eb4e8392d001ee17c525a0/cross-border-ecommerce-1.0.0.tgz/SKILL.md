---
name: cross-border-ecommerce
description: 跨境电商运营工具集，提供 Amazon/Shopify/eBay 多平台商品列表优化、竞品分析、评论情感分析、FBA费用计算、关键词研究、库存管理、定价策略等完整运营工具链。
---

# 跨境电商运营工具集

本技能提供一套完整的跨境电商运营指令，涵盖从商品上架优化到利润分析的全链路工具。支持 Amazon（US/JP/EU）、Shopify、eBay 等主流平台，提供可执行的 API 调用、计算公式和分析框架。

---

## 目录

1. [平台连接与认证](#1-平台连接与认证)
2. [Amazon 商品列表优化](#2-amazon-商品列表优化)
3. [竞品价格追踪与分析](#3-竞品价格追踪与分析)
4. [评论情感分析](#4-评论情感分析)
5. [FBA 费用计算与利润分析](#5-fba-费用计算与利润分析)
6. [关键词研究与优化](#6-关键词研究与优化)
7. [商品图片合规检查](#7-商品图片合规检查)
8. [库存管理与补货建议](#8-库存管理与补货建议)
9. [市场趋势分析](#9-市场趋势分析)
10. [多平台对比分析](#10-多平台对比分析)
11. [汇率转换与定价策略](#11-汇率转换与定价策略)
12. [运营数据仪表板框架](#12-运营数据仪表板框架)

---

## 1. 平台连接与认证

### 1.1 Amazon SP-API 认证

```bash
# Amazon Selling Partner API 认证流程
# Step 1: 获取 LWA (Login with Amazon) Access Token
LWA_ACCESS_TOKEN=$(curl -s -X POST https://api.amazon.com/auth/o2/token \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -d "grant_type=refresh_token" \
    -d "refresh_token=${LWA_REFRESH_TOKEN}" \
    -d "client_id=${SP_API_CLIENT_ID}" \
    -d "client_secret=${SP_API_CLIENT_SECRET}" | jq -r .access_token)

# Step 2: 获取受限操作 Token（Reports API 等）
RESTRICTED_TOKEN=$(curl -s -X POST https://sellingpartnerapi-na.amazon.com/tokens/2021-03-01/restrictedDataToken \
    -H "x-amz-access-token: ${LWA_ACCESS_TOKEN}" \
    -H "x-amz-date: $(date -u +%Y%m%dT%H%M%SZ)" \
    -H "Content-Type: application/json" \
    -d '{
        "restrictedResources": [
            {
                "method": "GET",
                "path": "/reports/2021-06-30/reports",
                "dataElements": ["salesAndTrafficByDate"]
            }
        ]
    }' | jq -r .restrictedDataToken)
```

### 1.2 Shopify API 认证

```bash
# Shopify Admin API (REST)
SHOPIFY_TOKEN="${SHOPIFY_ACCESS_TOKEN}"
SHOP_DOMAIN="${SHOP}.myshopify.com"

# 获取店铺信息
curl -s "https://${SHOP_DOMAIN}/admin/api/2024-01/shop.json" \
    -H "X-Shopify-Access-Token: ${SHOPIFY_TOKEN}" | jq .
```

### 1.3 eBay API 认证

```bash
# eBay OAuth2 Token
EBAY_TOKEN=$(curl -s -X POST https://api.ebay.com/identity/v1/oauth2/token \
    -H "Content-Type: application/x-www-form-urlencoded" \
    -H "Authorization: Basic $(echo -n "${EBAY_APP_ID}:${EBAY_CERT}" | base64)" \
    -d "grant_type=client_credentials&scope=https://api.ebay.com/oauth/api_scope" \
    | jq -r .access_token)
```

---

## 2. Amazon 商品列表优化

### 2.1 标题优化规则

```
标题优化黄金公式：
[品牌名] + [核心关键词] + [产品特征/卖点] + [材质/规格] + [适用范围] + [颜色/变体]

标题规则：
- 长度：200 字符以内（推荐 150-180 字符）
- 首字母大写（介词/冠词除外）
- 不使用特殊符号（!@#$%^&*）
- 不使用促销语（Best Seller, Free Shipping）
- 核心关键词前置
- 每个词都有搜索价值，无冗余
- 编号用阿拉伯数字（用 5 而非 Five）
```

```bash
# 标题评分函数（Agent 使用）
evaluate_title() {
    local title=$1
    local score=0
    local feedback=""

    # 长度检查（150-180 最优）
    local len=${#title}
    if (( len >= 150 && len <= 180 )); then
        (( score += 25 )); feedback+="✅ 长度最优 (${len}字符)\n"
    elif (( len > 180 )); then
        (( score += 15 )); feedback+="⚠️ 标题过长 (${len}字符)，可能被截断\n"
    elif (( len >= 100 )); then
        (( score += 20 )); feedback+="✅ 长度可接受 (${len}字符)\n"
    else
        (( score += 5 )); feedback+="❌ 标题过短 (${len}字符)，浪费关键词空间\n"
    fi

    # 关键词检查
    local word_count=$(echo "$title" | wc -w)
    if (( word_count >= 10 && word_count <= 25 )); then
        (( score += 20 )); feedback+="✅ 关键词密度合理 (${word_count}词)\n"
    fi

    # 特殊字符检查
    if echo "$title" | rg -q '[!@#$%^&*]'; then
        feedback+="❌ 包含特殊符号，可能导致搜索降权\n"
    else
        (( score += 10 )); feedback+="✅ 无特殊符号\n"
    fi

    # 促销语检查
    if echo "$title" | rg -qi '(free shipping|best seller|hot sale|discount|100%)'; then
        feedback+="❌ 包含促销语，违反Amazon政策\n"
    else
        (( score += 10 )); feedback+="✅ 无违规促销语\n"
    fi

    # 大写检查
    local upper_count=$(echo "$title" | rg -o '[A-Z]' | wc -l)
    local total_alpha=$(echo "$title" | rg -o '[a-zA-Z]' | wc -l)
    local upper_ratio=$(echo "scale=2; $upper_count / $total_alpha * 100" | bc)
    feedback+="📊 大写字母占比: ${upper_ratio}%\n"

    echo "标题评分: ${score}/65"
    echo "$feedback"
}

# 使用示例
evaluate_title "Premium Wireless Bluetooth Earbuds Noise Cancelling Headphones IPX7 Waterproof Sports Earphones with Microphone 40H Playtime for iPhone Android Running Workout - Black"
```

### 2.2 Bullet Points (五点描述) 优化

```
五点描述优化规则：
- 每条不超过 500 字符（推荐 200-300 字符）
- 5 条完整使用
- 每条以大写核心卖点开头
- 包含关键产品参数（尺寸、材质、兼容性等）
- 结构：核心卖点 → 详细说明 → 用户收益
- 不重复标题中的内容
- 第 1-2 条放最大卖点
- 最后 1-2 条放保修和包装信息
```

```bash
# 五点描述评分
evaluate_bullets() {
    local bullet1=$1 bullet2=$2 bullet3=$3 bullet4=$4 bullet5=$5
    local score=0

    for i in 1 2 3 4 5; do
        local text=$(eval echo \$bullet${i})
        local len=${#text}

        # 长度检查
        if (( len > 0 && len <= 300 )); then
            (( score += 16 ))
            echo "✅ Bullet $i: ${len}字符 - 长度合适"
        elif (( len > 300 && len <= 500 )); then
            (( score += 12 ))
            echo "⚠️ Bullet $i: ${len}字符 - 偏长"
        elif (( len > 500 )); then
            (( score += 5 ))
            echo "❌ Bullet $i: ${len}字符 - 超过500字符限制"
        elif (( len == 0 )); then
            echo "❌ Bullet $i: 未填写"
        fi

        # 大写开头检查
        local first_char=$(echo "$text" | cut -c1)
        if [[ "$first_char" =~ [A-Z] ]]; then
            (( score += 4 ))
        else
            echo "⚠️ Bullet $i: 未以大写字母开头"
        fi
    done

    echo "五点描述总分: ${score}/100"
}
```

### 2.3 后台搜索词 (Backend Keywords) 优化

```
后台搜索词规则：
- 总长度不超过 249 字节（注意字节，非字符）
- 不重复标题和五点中的词
- 使用单数形式（用 shoe 而非 shoes）
- 用空格分隔，不用逗号
- 不使用品牌名和 ASIN
- 不使用主观词（best, amazing, cheapest）
- 不重复同一词的不同变体
- 使用同义词和相关词
```

```bash
# 检查后台搜索词字节长度
check_backend_keywords() {
    local keywords=$1
    local byte_len=$(echo -n "$keywords" | wc -c)
    local word_count=$(echo "$keywords" | wc -w)

    echo "后台搜索词分析："
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "内容: $keywords"
    echo "字符数: ${#keywords}"
    echo "字节数: $byte_len / 249 (限制)"
    echo "词数: $word_count"

    if (( byte_len > 249 )); then
        echo "❌ 超出字节限制！需要截断。"
        echo "建议截断版本: $(echo "$keywords" | cut -c1-200)"
    else
        echo "✅ 字节数合规"
        echo "剩余可用字节: $((249 - byte_len))"
    fi

    # 检查重复词
    echo ""
    echo "词频分析："
    echo "$keywords" | tr ' ' '\n' | sort | uniq -c | sort -rn | head -10
}

# 使用示例
check_backend_keywords "bluetooth earbuds wireless headphone sport running gym workout noise canceling waterproof ipx7 earphone charging case microphone hands free call bass"
```

### 2.4 描述 (Description / A+ Content) 优化

```
产品描述优化规则：
- A+ Content 优先（品牌注册卖家）
- 描述长度：2000 字符以内
- 第一段：核心产品介绍和核心卖点
- 中间段落：详细功能说明（配合排版）
- 最后段落：包装清单和售后承诺
- 使用 HTML 标签增强排版（<br>, <b>, <ul>, <li>）
- 包含场景描述和使用方法
- 嵌入关键词但保持自然阅读
```

---

## 3. 竞品价格追踪与分析

### 3.1 通过 Web 抓取获取竞品价格

```bash
# Amazon 商品页面价格抓取（使用 curl + 正则提取）
fetch_amazon_price() {
    local asin=$1
    local marketplace=$2  # com, co.jp, co.uk, de, fr

    local domain="www.amazon.${marketplace}"
    local url="https://${domain}/dp/${asin}"

    local html=$(curl -s -L \
        -H "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36" \
        -H "Accept-Language: en-US,en;q=0.9" \
        -H "Accept: text/html" \
        "$url")

    # 提取当前价格
    local price=$(echo "$html" | rg -oP '(?:class="a-offscreen"|id="priceblock_ourprice"|id="priceblock_dealprice")[^>]*>\s*\K[^<]+' | head -1)

    # 提取标题
    local title=$(echo "$html" | rg -oP '<title[^>]*>\K[^<]+' | head -1)

    # 提取评分
    local rating=$(echo "$html" | rg -oP 'a-icon-star a-star-\K[0-9]+' | head -1)
    local review_count=$(echo "$html" | rg -oP '[0-9,]+ ratings' | head -1)

    # 提取排名
    local bsr=$(echo "$html" | rg -oP '#\K[0-9,]+ in \w+(?: & \w+)?' | head -1)

    echo "=== 竞品分析: $asin ==="
    echo "标题: $title"
    echo "价格: $price"
    echo "评分: ${rating}/5 (${review_count})"
    echo "BSR排名: #$bsr"
    echo "时间: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
}

# 使用示例
fetch_amazon_price "B0BSHF7WHW" "com"
```

### 3.2 竞品价格数据库结构

```json
{
    "price_tracker": {
        "competitor_products": [
            {
                "asin": "B0BSHF7WHW",
                "marketplace": "com",
                "title": "Competitor Wireless Earbuds",
                "price_history": [
                    {"date": "2024-01-15", "price": 29.99, "currency": "USD"},
                    {"date": "2024-01-14", "price": 29.99, "currency": "USD"},
                    {"date": "2024-01-13", "price": 34.99, "currency": "USD"},
                    {"date": "2024-01-12", "price": 39.99, "currency": "USD"}
                ],
                "current_price": 29.99,
                "price_30d_min": 24.99,
                "price_30d_max": 39.99,
                "price_30d_avg": 31.99,
                "price_trend": "decreasing",
                "rating": 4.5,
                "review_count": 12450,
                "bsr_category": "Electronics > Earbuds",
                "bsr_rank": 245
            }
        ]
    }
}
```

### 3.3 价格分析框架

```bash
# 竞品价格对比分析
analyze_price_position() {
    local my_price=$1
    local competitor_min=$2
    local competitor_max=$3
    local competitor_avg=$4

    echo "=== 价格定位分析 ==="
    echo "我的价格: \$${my_price}"
    echo "竞品最低: \$${competitor_min}"
    echo "竞品最高: \$${competitor_max}"
    echo "竞品均价: \$${competitor_avg}"

    local price_range=$((competitor_max - competitor_min))
    local my_position=$(echo "scale=2; ($my_price - $competitor_min) / $price_range * 100" | bc)

    echo ""
    echo "价格定位: ${my_position}%（0%=最低价，100%=最高价）"

    # 定价策略建议
    echo ""
    echo "=== 定价策略建议 ==="

    if (( $(echo "$my_price < $competitor_min" | bc -l) )); then
        echo "⚠️ 你的价格低于所有竞品最低价"
        echo "   风险: 可能引发价格战，利润空间极低"
        echo "   建议: 检查利润率是否为正，考虑提升产品差异化"
    elif (( $(echo "$my_price < $competitor_avg" | bc -l) )); then
        echo "✅ 你的价格低于市场均价"
        echo "   优势: 有价格竞争力"
        echo "   注意: 确保仍能维持合理利润"
    elif (( $(echo "$my_price < $competitor_avg * 1.1" | bc -l) )); then
        echo "✅ 你的价格接近市场均价"
        echo "   策略: 依靠评价和 Listing 质量竞争"
    elif (( $(echo "$my_price < $competitor_max" | bc -l) )); then
        echo "⚠️ 你的价格高于市场均价"
        echo "   要求: 必须有明显的差异化卖点"
        echo "   建议: 突出品质、功能或服务优势"
    else
        echo "❌ 你的价格远高于竞品最高价"
        echo "   风险: 转化率可能极低"
        echo "   建议: 重新评估定价或增加产品附加值"
    fi

    # 价格弹性估算
    local price_diff=$(echo "scale=2; ($my_price - $competitor_avg) / $competitor_avg * 100" | bc)
    echo ""
    echo "与均价偏差: ${price_diff}%"
    echo "预估影响: 价格每高出均价1%，销量可能下降2-5%"
    echo "预估销量影响: 约 $(echo "scale=0; $price_diff * 3.5" | bc)%"
}
```

### 3.4 批量竞品追踪

```bash
# 批量追踪竞品价格变化
track_competitors() {
    local asin_list=$1  # 文件路径，每行一个 ASIN
    local output_file=$2

    echo "[\n" > "$output_file"

    local first=true
    while IFS= read -r asin; do
        [ -z "$asin" ] && continue
        [ "$first" = false ] && echo "," >> "$output_file"
        first=false

        # 获取价格数据（实际环境中替换为真实抓取）
        local price=$(fetch_amazon_price "$asin" "com" 2>/dev/null | rg '价格:' | rg -oP '[0-9.]+')

        echo "  {" >> "$output_file"
        echo "    \"asin\": \"${asin}\"," >> "$output_file"
        echo "    \"price\": ${price:-0}," >> "$output_file"
        echo "    \"tracked_at\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"" >> "$output_file"
        echo -n "  }" >> "$output_file"
    done < "$asin_list"

    echo "\n]" >> "$output_file"
    echo "追踪完成，结果保存到: $output_file"
}
```

---

## 4. 评论情感分析

### 4.1 评论抓取

```bash
# 获取 Amazon 商品评论
fetch_reviews() {
    local asin=$1
    local marketplace=$2
    local star_filter=$3  # all, 1, 2, 3, 4, 5

    local domain="www.amazon.${marketplace}"

    curl -s "https://${domain}/product-reviews/${asin}/ref=cm_cr_dp_d_show_all_btm?ie=UTF8&reviewerType=all_reviews&sortBy=recent&pageNumber=1&starRating=${star_filter}" \
        -H "User-Agent: Mozilla/5.0" \
        -H "Accept-Language: en-US,en;q=0.9"
}
```

### 4.2 情感分析框架

Agent 对评论进行结构化情感分析时，应使用以下框架：

```json
{
    "review_analysis": {
        "product_asin": "B0XXXXXXXXX",
        "analysis_date": "2024-01-15",
        "total_reviews_analyzed": 150,
        "overall_sentiment": {
            "positive_pct": 72,
            "neutral_pct": 15,
            "negative_pct": 13
        },
        "star_distribution": {
            "5_star": 58,
            "4_star": 18,
            "3_star": 9,
            "2_star": 7,
            "1_star": 8
        },
        "feature_sentiment": {
            "sound_quality": {"sentiment": "positive", "score": 0.85, "mentions": 89},
            "comfort": {"sentiment": "positive", "score": 0.78, "mentions": 65},
            "battery_life": {"sentiment": "mixed", "score": 0.55, "mentions": 72},
            "noise_canceling": {"sentiment": "positive", "score": 0.70, "mentions": 45},
            "microphone": {"sentiment": "negative", "score": 0.35, "mentions": 38},
            "build_quality": {"sentiment": "positive", "score": 0.72, "mentions": 55},
            "connectivity": {"sentiment": "negative", "score": 0.40, "mentions": 30}
        },
        "key_positive_themes": [
            {"theme": "音质出色", "frequency": 45, "representative_quotes": ["音质超出预期", "低音效果非常好"]},
            {"theme": "佩戴舒适", "frequency": 32, "representative_quotes": ["长时间佩戴也不痛", "硅胶耳套很软"]},
            {"theme": "续航持久", "frequency": 28, "representative_quotes": ["一周充一次就够了"]}
        ],
        "key_negative_themes": [
            {"theme": "通话质量差", "frequency": 20, "representative_quotes": ["通话时对方听不清", "风大时完全不行"]},
            {"theme": "连接不稳定", "frequency": 15, "representative_quotes": ["偶尔断连", "切换设备后需要重新配对"]},
            {"theme": "充电盒松动", "frequency": 8, "representative_quotes": ["盖子很松，容易打开"]}
        ],
        "improvement_suggestions": [
            {
                "priority": "high",
                "area": "麦克风通话质量",
                "current_issue": "通话降噪不足，对方听不清",
                "suggested_action": "升级麦克风阵列或增加通话降噪算法",
                "potential_impact": "预计可减少15%的差评"
            },
            {
                "priority": "medium",
                "area": "蓝牙连接稳定性",
                "current_issue": "运动时偶尔断连",
                "suggested_action": "优化蓝牙5.3连接管理",
                "potential_impact": "预计可减少8%的差评"
            }
        ]
    }
}
```

### 4.3 评论分析输出报告

```
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📋 评论分析报告 - ASIN: B0XXXXXXXXX
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

📊 整体情感分布
┌─────────┬────────┬──────────┐
│ 情感    │ 数量   │ 占比     │
├─────────┼────────┼──────────┤
│ 积极    │ 108    │ ██████ 72% │
│ 中性    │  23    │ ██ 15%    │
│ 消极    │  19    │ █ 13%     │
└─────────┴────────┴──────────┘

⭐ 星级分布
★★★★★ 58%  ████████████████████
★★★★☆ 18%  ███████
★★★☆☆  9%  ███
★★☆☆☆  7%  ██
★☆☆☆☆  8%  ██

✅ TOP 3 优点
1. 音质出色 (45次提及) - ⭐⭐⭐⭐⭐
2. 佩戴舒适 (32次提及) - ⭐⭐⭐⭐
3. 续航持久 (28次提及) - ⭐⭐⭐⭐

❌ TOP 3 缺点
1. 通话质量差 (20次提及) - ⚠️ 需重点改进
2. 连接不稳定 (15次提及) - ⚠️ 中等优先级
3. 充电盒松动 (8次提及)  - 低优先级

💡 产品改进建议
[HIGH] 优化麦克风通话质量 → 预计减少 15% 差评
[MED]  提升蓝牙连接稳定性 → 预计减少 8% 差评
```

---

## 5. FBA 费用计算与利润分析

### 5.1 Amazon FBA 费用计算器

```bash
# FBA 费用完整计算
calculate_fba_profit() {
    local selling_price=$1     # 售价 (USD)
    local product_cost=$2      # 产品成本 (USD)
    local shipping_to_fba=$3   # 头程运费 (USD)
    local product_weight_oz=$4 # 产品重量 (盎司)
    local product_length=$5    # 产品长度 (英寸)
    local product_width=$6     # 产品宽度 (英寸)
    local product_height=$7    # 产品高度 (英寸)
    local monthly_storage=$8   # 月仓储费预估 (USD)
    local prep_fee=$9          # 贴标预处理费 (USD)
    local category=$10         # 类别 (electronics, home, clothing...)

    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "📊 FBA 利润分析报告"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    # 尺寸等级判定（标准）
    local volume=$(echo "scale=2; $product_length * $product_width * $product_height" | bc)
    local weight_lbs=$(echo "scale=2; $product_weight_oz / 16" | bc)

    local size_tier="Standard"
    if (( $(echo "$product_length > 18 || $product_width > 14 || $product_height > 8" | bc -l) )); then
        size_tier="Large Standard"
    fi
    if (( $(echo "$volume > 1728 || $weight_lbs > 20" | bc -l) )); then
        size_tier="Small Oversize"
    fi

    echo "📦 尺寸等级: $size_tier"

    # 销售佣金（按品类）
    local referral_fee
    case $category in
        electronics) referral_fee=$(echo "scale=2; $selling_price * 0.08" | bc) ;;
        home) referral_fee=$(echo "scale=2; $selling_price * 0.15" | bc) ;;
        clothing) referral_fee=$(echo "scale=2; $selling_price * 0.17" | bc) ;;
        *) referral_fee=$(echo "scale=2; $selling_price * 0.15" | bc) ;;
    esac

    # FBA 配送费（标准小件 2024 费率）
    local fulfillment_fee
    if (( $(echo "$product_weight_oz <= 4" | bc -l) )); then
        fulfillment_fee=3.22
    elif (( $(echo "$product_weight_oz <= 8" | bc -l) )); then
        fulfillment_fee=3.47
    elif (( $(echo "$product_weight_oz <= 12" | bc -l) )); then
        fulfillment_fee=3.87
    elif (( $(echo "$product_weight_oz <= 16" | bc -l) )); then
        fulfillment_fee=4.75
    else
        fulfillment_fee=5.60
    fi

    # 其他费用
    local closing_fee=0.45  # 非媒介类
    local storage_fee=$monthly_storage

    # 总成本计算
    local total_fees=$(echo "scale=2; $referral_fee + $fulfillment_fee + $closing_fee + $storage_fee + $prep_fee" | bc)
    local total_cost=$(echo "scale=2; $product_cost + $shipping_to_fba + $total_fees" | bc)
    local profit=$(echo "scale=2; $selling_price - $total_cost" | bc)
    local margin=$(echo "scale=1; $profit / $selling_price * 100" | bc)
    local roi=$(echo "scale=1; $profit / ($product_cost + $shipping_to_fba) * 100" | bc)

    # 输出结果
    echo ""
    echo "💰 收入"
    echo "   售价:                    \$${selling_price}"
    echo ""
    echo "📉 费用明细"
    echo "   产品成本:                \$${product_cost}"
    echo "   头程运费:                \$${shipping_to_fba}"
    echo "   销售佣金 (15%):          \$${referral_fee}"
    echo "   FBA 配送费:              \$${fulfillment_fee}"
    echo "   交易手续费:              \$${closing_fee}"
    echo "   月仓储费:                \$${storage_fee}"
    echo "   预处理费:                \$${prep_fee}"
    echo "   ─────────────────────────────────"
    echo "   总费用:                  \$${total_cost}"
    echo ""
    echo "📊 利润指标"
    echo "   单件利润:                \$${profit}"
    echo "   利润率:                  ${margin}%"
    echo "   ROI:                     ${roi}%"

    # 健康度评估
    echo ""
    if (( $(echo "$margin >= 30" | bc -l) )); then
        echo "✅ 利润健康 - 利润率 ≥ 30%"
    elif (( $(echo "$margin >= 20" | bc -l) )); then
        echo "⚠️ 利润一般 - 利润率 20-30%，建议优化成本"
    elif (( $(echo "$margin >= 10" | bc -l) )); then
        echo "⚠️ 利润偏低 - 利润率 10-20%，存在风险"
    else
        echo "❌ 利润危险 - 利润率 < 10%，需要立即调整"
    fi

    # 盈亏平衡点
    local break_even=$(echo "scale=2; $total_cost / (1 - 0.15 - $closing_fee / $selling_price)" | bc)
    echo ""
    echo "📈 盈亏平衡售价: \$${break_even}"
}

# 使用示例：售价39.99，成本8，头程2，重量1.5oz，小尺寸产品
calculate_fba_profit 39.99 8.00 2.00 1.5 2.0 1.5 1.0 0.30 0.50 electronics
```

### 5.2 利润敏感性分析

```bash
# 分析售价变动对利润的影响
sensitivity_analysis() {
    local base_price=$1
    local base_cost=$2
    local referral_rate=$3  # 如 0.15

    echo "💰 利润敏感性分析"
    echo "基准售价: \$${base_price}"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "售价\t\t利润\t\t利润率\t\tROI"

    for pct in -20 -15 -10 -5 0 5 10 15 20; do
        local price=$(echo "scale=2; $base_price * (1 + $pct / 100)" | bc)
        local revenue=$price
        local referral=$(echo "scale=2; $price * $referral_rate" | bc)
        local fba_fee=3.47
        local other_fees=$(echo "scale=2; $referral + $fba_fee + 0.45 + 0.30 + 0.50" | bc)
        local total_cost=$(echo "scale=2; $base_cost + $other_fees" | bc)
        local profit=$(echo "scale=2; $price - $total_cost" | bc)
        local margin=$(echo "scale=1; $profit / $price * 100" | bc)
        local roi=$(echo "scale=1; $profit / $base_cost * 100" | bc)

        printf "\$%-8.2f\t\$%-8.2f\t%-8s%%\t%-8s%%\n" "$price" "$profit" "$margin" "$roi"
    done
}
```

### 5.3 广告 ACOS/TACOS 计算

```bash
# 广告成本分析
calculate_ad_metrics() {
    local ad_spend=$1        # 广告花费 (USD)
    local ad_sales=$2        # 广告带来的销售额 (USD)
    local total_sales=$3     # 总销售额 (USD)

    local acos=$(echo "scale=2; $ad_spend / $ad_sales * 100" | bc)
    local tacos=$(echo "scale=2; $ad_spend / $total_sales * 100" | bc)

    echo "📊 广告效率分析"
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo "广告花费:     \$${ad_spend}"
    echo "广告销售额:   \$${ad_sales}"
    echo "总销售额:     \$${total_sales}"
    echo ""
    echo "ACOS:   ${acos}% (广告花费 / 广告销售额)"
    echo "TACOS:  ${tacos}% (广告花费 / 总销售额)"

    echo ""
    echo "健康度评估："
    if (( $(echo "$acos <= 20" | bc -l) )); then
        echo "✅ ACOS 优秀 (≤20%)"
    elif (( $(echo "$acos <= 30" | bc -l) )); then
        echo "⚠️ ACOS 一般 (20-30%)，可优化"
    else
        echo "❌ ACOS 偏高 (>30%)，需要调整广告策略"
    fi
}
```

---

## 6. 关键词研究与优化

### 6.1 Amazon 关键词研究流程

```
关键词研究五步法：
1. 种子词收集：从产品属性、功能、场景出发
2. 关键词扩展：使用工具和平台获取相关词
3. 搜索量评估：估算各关键词的搜索量
4. 竞争度分析：评估排名难度
5. 关键词筛选：综合搜索量和竞争度选择最优词
```

### 6.2 关键词评分模型

```json
{
    "keyword_scoring": {
        "model": {
            "name": "综合关键词价值评分",
            "formula": "keyword_value = search_volume_score * (1 / competition_score) * relevance_score * conversion_score",
            "dimensions": {
                "search_volume": {
                    "weight": 0.35,
                    "scoring": {
                        "high (10000+/月)": 10,
                        "medium (3000-10000/月)": 7,
                        "low (1000-3000/月)": 5,
                        "very_low (<1000/月)": 2
                    }
                },
                "competition": {
                    "weight": 0.25,
                    "scoring": {
                        "low (首页无大品牌)": 9,
                        "medium (部分品牌)": 6,
                        "high (全部品牌)": 3,
                        "very_high (Amazon自营)": 1
                    }
                },
                "relevance": {
                    "weight": 0.25,
                    "scoring": {
                        "exact_match": 10,
                        "core_feature": 8,
                        "related_use_case": 6,
                        "loosely_related": 3
                    }
                },
                "conversion": {
                    "weight": 0.15,
                    "scoring": {
                        "buying_intent (buy, best, top)": 10,
                        "specific_need (waterproof, wireless)": 8,
                        "researching (review, vs, comparison)": 5,
                        "informational (how to, what is)": 3
                    }
                }
            }
        }
    }
}
```

### 6.3 关键词矩阵构建

```json
{
    "keyword_matrix": {
        "product_name": "无线蓝牙耳机",
        "marketplace": "com",
        "keywords": [
            {
                "keyword": "wireless earbuds",
                "search_volume_est": 246000,
                "competition": "high",
                "relevance": "exact_match",
                "intent": "buying",
                "value_score": 7.2,
                "current_rank": 45,
                "opportunity": "需要提升自然排名"
            },
            {
                "keyword": "bluetooth earbuds waterproof",
                "search_volume_est": 44000,
                "competition": "medium",
                "relevance": "core_feature",
                "intent": "buying",
                "value_score": 8.1,
                "current_rank": 22,
                "opportunity": "有潜力进入首页"
            },
            {
                "keyword": "wireless earbuds for running",
                "search_volume_est": 22000,
                "competition": "medium",
                "relevance": "related_use_case",
                "intent": "buying",
                "value_score": 7.8,
                "current_rank": null,
                "opportunity": "未排名，建议在Listing中加入"
            },
            {
                "keyword": "earbuds with long battery life",
                "search_volume_est": 12000,
                "competition": "low",
                "relevance": "core_feature",
                "intent": "buying",
                "value_score": 8.5,
                "current_rank": null,
                "opportunity": "低竞争高价值，重点优化"
            }
        ]
    }
}
```

### 6.4 Listing 关键词布局检查

```bash
# 检查关键词是否在 Listing 各位置出现
check_keyword_placement() {
    local keyword=$1
    local title=$2
    local bullets=$3
    local description=$4
    local backend=$5

    echo "=== 关键词布局检查: \"${keyword}\" ==="

    # 标题检查
    if echo "$title" | rg -qi "$keyword"; then
        echo "✅ 标题中包含"
    else
        echo "❌ 标题中缺失 — 建议：在前 80 字符内加入"
    fi

    # Bullet 检查
    if echo "$bullets" | rg -qi "$keyword"; then
        echo "✅ 五点描述中包含"
    else
        echo "⚠️ 五点描述中缺失 — 建议：在相关 Bullet 中自然融入"
    fi

    # 描述检查
    if echo "$description" | rg -qi "$keyword"; then
        echo "✅ 产品描述中包含"
    else
        echo "⚠️ 产品描述中缺失"
    fi

    # 后台搜索词检查
    if echo "$backend" | rg -qi "$keyword"; then
        echo "✅ 后台搜索词中包含"
    else
        echo "❌ 后台搜索词中缺失 — 必须加入"
    fi
}
```

---

## 7. 商品图片合规检查

### 7.1 Amazon 图片要求检查清单

```bash
check_image_compliance() {
    local image_path=$1
    local position=$2  # main, pt1, pt2, aplus

    # 获取图片信息
    local width=$(identify -format "%w" "$image_path" 2>/dev/null || echo "unknown")
    local height=$(identify -format "%h" "$image_path" 2>/dev/null || echo "unknown")
    local format=$(identify -format "%m" "$image_path" 2>/dev/null || echo "unknown")
    local size_kb=$(stat -f%z "$image_path" 2>/dev/null || stat -c%s "$image_path" 2>/dev/null || echo "unknown")
    local size_mb=$(echo "scale=2; $size_kb / 1048576" | bc)
    local has_alpha=$(identify -format "%A" "$image_path" 2>/dev/null || echo "unknown")

    echo "=== 图片合规检查 ==="
    echo "文件: $(basename $image_path)"
    echo "位置: $position"

    # 格式检查
    if [[ "$format" =~ ^(JPEG|JPG|PNG|GIF|TIFF)$ ]]; then
        echo "✅ 格式: $format"
    else
        echo "❌ 格式: $format (不支持，需为 JPEG/PNG/GIF/TIFF)"
    fi

    # 尺寸检查
    case $position in
        main)
            # 主图必须 ≥ 1000x1000，推荐 ≥ 2000x2000
            if (( width >= 1000 && height >= 1000 )); then
                echo "✅ 最小尺寸: ${width}x${height} (≥1000x1000)"
            else
                echo "❌ 最小尺寸: ${width}x${height} (需要 ≥1000x1000)"
            fi
            if (( width >= 2000 && height >= 2000 )); then
                echo "✅ 支持缩放: 是 (Zoom可用)"
            fi
            # 主图比例检查
            local ratio=$(echo "scale=2; $width / $height" | bc)
            if (( $(echo "$ratio >= 0.9 && $ratio <= 1.1" | bc -l) )); then
                echo "✅ 比例: ${ratio}:1 (接近正方形)"
            else
                echo "⚠️ 比例: ${ratio}:1 (建议1:1正方形)"
            fi
            # 主图必须纯白背景
            echo "⚠️ 主图背景: 需人工确认纯白背景"
            # 主图不允许有文字
            echo "⚠️ 主图文字: 需人工确认无文字和水印"
            ;;
        pt*|a_plus)
            if (( width >= 1000 && height >= 1000 )); then
                echo "✅ 最小尺寸: ${width}x${height}"
            else
                echo "❌ 最小尺寸: ${width}x${height} (需要 ≥1000x1000)"
            fi
            ;;
    esac

    # 文件大小
    if (( $(echo "$size_mb < 10" | bc -l) )); then
        echo "✅ 文件大小: ${size_mb}MB (<10MB)"
    else
        echo "❌ 文件大小: ${size_mb}MB (需要 <10MB)"
    fi

    # 色彩模式检查
    echo "ℹ️ 颜色模式: 建议 sRGB"
}
```

---

## 8. 库存管理与补货建议

### 8.1 库存监控模型

```json
{
    "inventory_management": {
        "product": {
            "asin": "B0XXXXXXXXX",
            "sku": "SKU-001",
            "current_inventory": 350,
            "daily_sales_velocity": 15,
            "sales_velocity_7d_avg": 14.5,
            "sales_velocity_30d_avg": 16.2,
            "in_transit": 200,
            "days_of_supply": 23,
            "reorder_point": 500,
            "safety_stock": 100,
            "lead_time_days": 45,
            "reorder_recommendation": {
                "should_reorder": true,
                "urgency": "medium",
                "suggested_quantity": 800,
                "reason": "预计 23 天后断货，考虑头程 45 天，应立即补货"
            }
        }
    }
}
```

### 8.2 补货计算公式

```bash
# 计算建议补货量
calculate_reorder() {
    local current_inv=$1
    local daily_velocity=$2
    local lead_time=$3           # 补货周期（天）
    local safety_stock=$4        # 安全库存
    local seasonality_factor=$5  # 季节因子（1.0 = 无季节性）

    local adjusted_velocity=$(echo "scale=2; $daily_velocity * $seasonality_factor" | bc)
    local lead_time_demand=$(echo "scale=0; $adjusted_velocity * $lead_time" | bc)
    local reorder_point=$(echo "scale=0; $lead_time_demand + $safety_stock" | bc)
    local reorder_qty=$(echo "scale=0; $reorder_point - $current_inv" | bc)
    local days_until_stockout=$(echo "scale=0; $current_inv / $daily_velocity" | bc)

    echo "=== 补货分析 ==="
    echo "当前库存: ${current_inv} 件"
    echo "日均销量: ${daily_velocity} 件"
    echo "季节因子: ${seasonality_factor}"
    echo "调整后日均: ${adjusted_velocity} 件"
    echo "补货周期: ${lead_time} 天"
    echo "安全库存: ${safety_stock} 件"
    echo ""
    echo "补货点: ${reorder_point} 件"
    echo "预计断货: ${days_until_stockout} 天后"
    echo ""

    if (( reorder_qty > 0 )); then
        echo "🚨 需要补货: ${reorder_qty} 件"

        if (( days_until_stockout < lead_time )); then
            echo "⚠️ 紧急: 补货周期(${lead_time}天) > 预计断货时间(${days_until_stockout}天)"
            echo "   建议: 考虑空运补货或启动紧急采购"
        elif (( days_until_stockout < lead_time * 1.5 )); then
            echo "⚠️ 中等优先级: 接近需要下单"
            echo "   建议: 本周内完成下单"
        else
            echo "✅ 可以正常下单"
        fi
    else
        echo "✅ 库存充足，暂不需要补货"
    fi
}
```

---

## 9. 市场趋势分析

### 9.1 趋势分析框架

```json
{
    "market_trend_analysis": {
        "market": "Wireless Earbuds - US",
        "period": "2024-Q1",
        "market_size": {
            "estimated_value": "$8.2B",
            "yoy_growth": "+18.5%",
            "trend": "growing"
        },
        "top_trending_keywords": [
            {"keyword": "ai noise cancelling earbuds", "growth": "+350%", "momentum": "accelerating"},
            {"keyword": "earbuds with heart rate monitor", "growth": "+200%", "momentum": "accelerating"},
            {"keyword": "anc earbuds under 50", "growth": "+150%", "momentum": "stable"},
            {"keyword": "gaming earbuds low latency", "growth": "+120%", "momentum": "stable"},
            {"keyword": "transparent earbuds", "growth": "+95%", "momentum": "decelerating"}
        ],
        "emerging_features": [
            {"feature": "AI 通话降噪", "adoption_rate": "25%", "growth": "+40% QoQ"},
            {"feature": "空间音频", "adoption_rate": "35%", "growth": "+25% QoQ"},
            {"feature": "健康监测", "adoption_rate": "8%", "growth": "+60% QoQ"},
            {"feature": "可拆卸摄像头", "adoption_rate": "3%", "growth": "new"}
        ],
        "price_trend": {
            "average_price": "$68",
            "qoq_change": "-5%",
            "premium_segment": "$150-300",
            "mid_range": "$50-150",
            "budget": "$15-50",
            "trend": "中端市场竞争加剧，价格下行"
        },
        "seasonal_pattern": {
            "peak_months": ["November", "December", "July (Prime Day)"],
            "low_months": ["January", "February", "September"],
            "strategy": "Q2 备货，Q3 加广告，Q4 主攻促销"
        }
    }
}
```

### 9.2 机会识别评分

```
市场机会评分模型：

opportunity_score = (market_growth * 0.3) + (keyword_trend * 0.2) +
                    (competition_gap * 0.25) + (profitability * 0.15) +
                    (seasonal_alignment * 0.1)

评分标准：
- 90-100: 极佳机会，立即行动
- 70-89: 良好机会，值得投入
- 50-69: 一般机会，谨慎评估
- 30-49: 风险较高，不建议进入
- 0-29: 不推荐
```

---

## 10. 多平台对比分析

### 10.1 Amazon vs Shopify vs eBay 对比

```json
{
    "platform_comparison": {
        "amazon": {
            "strengths": ["自然流量大", "FBA物流省心", "Buy Box机制", "Prime会员池"],
            "weaknesses": ["佣金高(15%)", "竞争激烈", "规则严格", "品牌控制弱"],
            "best_for": ["已有供应链", "价格有优势", "标品类目", "追求规模"],
            "fees": {
                "referral_fee": "8-17%",
                "fba_fee": "$3.22-5.60+",
                "storage_fee": "$0.56-0.87/cu ft/month",
                "ad_fee": "CPC $0.50-3.00"
            }
        },
        "shopify": {
            "strengths": ["品牌自主", "无佣金", "客户数据自有", "设计自由"],
            "weaknesses": ["需自建流量", "需自管物流", "技术门槛", "起步慢"],
            "best_for": ["品牌建设", "差异化产品", "复购型产品", "长期经营"],
            "fees": {
                "monthly_plan": "$29-299",
                "payment_fee": "2.9% + $0.30",
                "app_cost": "$0-200/月",
                "ad_cost": "自控预算"
            }
        },
        "ebay": {
            "strengths": ["拍卖模式", "二手市场", "国际覆盖", "免开店费"],
            "weaknesses": ["手续费高", "买家保护偏买方", "界面老旧", "流量下降"],
            "best_for": ["二手/中古", "稀缺品", "收藏品", "清库存"],
            "fees": {
                "listing_fee": "$0.35/listing",
                "final_value_fee": "10-15%",
                "payment_fee": "2.9% + $0.30",
                "store_fee": "$4.95-349.95/月"
            }
        }
    }
}
```

### 10.2 多平台定价策略

```bash
# 多平台定价建议
multi_platform_pricing() {
    local base_cost=$1      # 产品成本
    local target_margin=$2  # 目标利润率 (如 30 表示 30%)

    echo "=== 多平台定价建议 ==="
    echo "产品成本: \$${base_cost}"
    echo "目标利润率: ${target_margin}%"
    echo ""

    # Amazon 定价（15%佣金 + FBA费$3.50 + 其他$1.50）
    local amazon_price=$(echo "scale=2; ($base_cost + 3.50 + 1.50) / (1 - 0.15 - ${target_margin}/100)" | bc)
    local amazon_profit=$(echo "scale=2; $amazon_price * (1 - 0.15) - $base_cost - 5.00" | bc)
    echo "Amazon:     \$${amazon_price} (利润 \$${amazon_profit})"

    # Shopify 定价（2.9%+0.30支付费 + 月费分摊$2）
    local shopify_price=$(echo "scale=2; ($base_cost + 2.30) / (1 - 0.029 - ${target_margin}/100)" | bc)
    local shopify_profit=$(echo "scale=2; $shopify_price * (1 - 0.029) - $base_cost - 2.00" | bc)
    echo "Shopify:    \$${shopify_price} (利润 \$${shopify_profit})"

    # eBay 定价（12.5%终值费 + 支付费2.9%+0.30 + 上架费分摊$0.50）
    local ebay_price=$(echo "scale=2; ($base_cost + 0.80) / (1 - 0.125 - 0.029 - ${target_margin}/100)" | bc)
    local ebay_profit=$(echo "scale=2; $ebay_price * (1 - 0.125 - 0.029) - $base_cost - 0.50" | bc)
    echo "eBay:       \$${ebay_price} (利润 \$${ebay_profit})"

    echo ""
    echo "💡 建议: Amazon 定价可略低（走量），Shopify 定价可略高（品牌溢价）"
}
```

---

## 11. 汇率转换与定价策略

### 11.1 汇率获取与转换

```bash
# 获取实时汇率
get_exchange_rate() {
    local from=$1  # 源货币 (USD, CNY, EUR, GBP, JPY)
    local to=$2    # 目标货币

    local rate=$(curl -s "https://open.er-api.com/v6/latest/${from}" | jq -r ".rates.${to}")
    echo "${from} → ${to}: ${rate}"

    return $rate
}

# 跨币种利润计算
calculate_cross_currency_profit() {
    local selling_price=$1      # 外币售价
    local currency=$2           # 售价货币
    local cost_cny=$3           # 人民币成本
    local exchange_rate=$4      # 汇率

    local selling_cny=$(echo "scale=2; $selling_price * $exchange_rate" | bc)
    local platform_fee=$(echo "scale=2; $selling_price * 0.15" | bc)
    local platform_fee_cny=$(echo "scale=2; $platform_fee * $exchange_rate" | bc)
    local fba_fee_cny=$(echo "scale=2; 3.50 * $exchange_rate" | bc)
    local profit_cny=$(echo "scale=2; $selling_cny - $cost_cny - $platform_fee_cny - $fba_fee_cny" | bc)
    local margin=$(echo "scale=1; $profit_cny / $selling_cny * 100" | bc)

    echo "=== 跨币种利润计算 ==="
    echo "售价: ${currency} ${selling_price} = ¥${selling_cny} (汇率: ${exchange_rate})"
    echo "成本: ¥${cost_cny}"
    echo "平台佣金: ${currency} ${platform_fee} = ¥${platform_fee_cny}"
    echo "FBA配送费: ¥${fba_fee_cny}"
    echo "━━━━━━━━━━━━━━━━━━━━━━"
    echo "利润: ¥${profit_cny}"
    echo "利润率: ${margin}%"

    # 汇率风险评估
    echo ""
    local safe_rate=$(echo "scale=4; $exchange_rate * 0.97" | bc)
    local profit_at_safe=$(echo "scale=2; ($selling_price * $safe_rate) - $cost_cny - ($platform_fee * $safe_rate) - ($fba_fee_cny)" | bc)
    echo "⚠️ 汇率波动3%时利润: ¥${profit_at_safe}"

    local danger_rate=$(echo "scale=4; $exchange_rate * 0.94" | bc)
    local profit_at_danger=$(echo "scale=2; ($selling_price * $danger_rate) - $cost_cny - ($platform_fee * $danger_rate) - ($fba_fee_cny)" | bc)
    echo "🔴 汇率波动6%时利润: ¥${profit_at_danger}"

    if (( $(echo "$profit_at_danger < 0" | bc -l) )); then
        echo "🚨 汇率下跌6%即亏损！建议："
        echo "   1. 提高售价至少 $(echo "scale=0; ($cost_cny + $platform_fee_cny + $fba_fee_cny) / $danger_rate" | bc) ${currency}"
        echo "   2. 或锁定汇率（远期结售汇）"
        echo "   3. 或降低成本"
    fi
}
```

### 11.2 汇率对冲建议

```
汇率风险管理策略：

1. 即期对冲：大额采购时锁定当期汇率
2. 远期合约：与银行签订远期结售汇协议
3. 自然对冲：收入与支出使用相同币种
4. 多币种定价：根据汇率波动定期调整售价
5. 安全边际：定价时预留 5-10% 的汇率缓冲

建议规则：
- 利润率 > 30%：汇率风险可控
- 利润率 20-30%：预留 3% 汇率缓冲
- 利润率 10-20%：必须进行汇率对冲
- 利润率 < 10%：不建议在汇率波动大的市场经营
```

---

## 12. 运营数据仪表板框架

### 12.1 核心 KPI 指标

```json
{
    "dashboard_kpis": {
        "sales_metrics": {
            "total_revenue": "总销售额",
            "total_orders": "总订单数",
            "average_order_value": "平均客单价",
            "conversion_rate": "转化率",
            "unit_session_percentage": "单位会话百分比"
        },
        "profitability_metrics": {
            "gross_profit": "毛利润",
            "profit_margin": "利润率",
            "acos": "广告销售成本比",
            "tacos": "总广告销售成本比",
            "roas": "广告回报率"
        },
        "traffic_metrics": {
            "sessions": "会话数",
            "page_views": "页面浏览量",
            "organic_traffic_pct": "自然流量占比",
            "paid_traffic_pct": "广告流量占比",
            "external_traffic_pct": "站外流量占比"
        },
        "inventory_metrics": {
            "sell_through_rate": "售罄率",
            "inventory_turnover": "库存周转率",
            "days_of_supply": "可售天数",
            "lost_sales": "缺货损失"
        },
        "customer_metrics": {
            "review_rating": "评分",
            "review_count": "评论数",
            "repeat_purchase_rate": "复购率",
            "return_rate": "退货率"
        }
    }
}
```

### 12.2 数据报告模板

```
═══════════════════════════════════════
   📊 每日运营数据简报
   日期: 2024-01-15
═══════════════════════════════════════

💰 销售概览
├── 销售额:     $2,847.50 (+12.3% vs 昨日)
├── 订单数:     89 单
├── 客单价:     $32.00
└── 转化率:     14.2%

📈 广告表现
├── 广告花费:   $312.00
├── 广告销售额: $1,423.75
├── ACOS:       21.9%
└── TACOS:      11.0%

📦 库存状态
├── 库存总量:   2,350 件
├── 平均可售:   26 天
├── 预警产品:   2 个（< 7天）
└── 在途:       800 件

⭐ 评论概览
├── 新增评论:   12 条
├── 平均评分:   4.3/5
├── 差评:       1 条 (需关注)
└── 回复率:     100%

⚡ 待办事项
1. SKU-003 库存不足 (5天)，需紧急补货
2. ASIN B0XXX 新差评，需分析原因
3. ACOS 超过目标 (21.9% > 20%)，优化关键词
```
