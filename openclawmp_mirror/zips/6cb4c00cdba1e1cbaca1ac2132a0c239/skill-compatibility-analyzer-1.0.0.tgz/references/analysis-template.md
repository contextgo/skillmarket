# Detailed Analysis Template

## Template Instructions

Use this template for systematic compatibility analysis. Copy and fill in each section with concrete information.

---

# Compatibility Analysis Template: [NEW SKILL NAME]

**Analysis Date**: [YYYY-MM-DD]
**Analyst**: [Agent Name]
**Context**: [Brief description of why this analysis is needed]

---

## Executive Summary

### Overall Recommendation
**Decision**: [Select one: ✅ Proceed / ⚠️ Pilot First / ❌ Defer / 🔄 Conditional Integration]

### Key Findings
- **Total Score**: [X/30]
- **Synergy Potential**: [X/10]
- **Risk Factors**: [X/10] (Higher = fewer risks)
- **ROI Certainty**: [X/10]

### Critical Conflicts Identified
1. [Conflict 1]: [Severity: High/Medium/Low] - [Brief description]
2. [Conflict 2]: [Severity] - [Brief description]
3. ...

### Recommendation Rationale
[2-3 sentence summary of why this decision was made]

---

## Phase 1: Existing Skills Inventory

### Active Skills List

| Skill Name | Layer | Version | Resource Usage | Dependencies |
|------------|-------|---------|---------------|--------------|
| [Skill 1] | [data/model/tool/workflow/infra] | [version] | [CPU/GPU/Memory] | [packages] |
| [Skill 2] | [layer] | [version] | [usage] | [packages] |
| ... | ... | ... | ... | ... |

### Skill Layer Categorization

**Data Layer** (Token optimization, memory management, compression):
- [Skill A]: [Purpose]
- [Skill B]: [Purpose]

**Model Layer** (Neural architectures, embeddings):
- [Skill C]: [Purpose]

**Tool Layer** (APIs, file operations, external services):
- [Skill D]: [Purpose]

**Workflow Layer** (Task planning, execution):
- [Skill E]: [Purpose]

**Infrastructure Layer** (GPU, storage, networking):
- [Skill F]: [Purpose]

### Resource Baseline

**Token Consumption**:
- Typical conversation: [X]K tokens
- With memory retrieval: [Y]K tokens
- Peak usage scenarios: [Z]K tokens

**Compute Resources**:
- CPU: [typical usage]
- GPU: [usage if applicable]
- Memory: [RAM usage]
- Storage: [disk space used]

**Latency Profile**:
- Average response time: [X seconds]
- P95 latency: [Y seconds]
- P99 latency: [Z seconds]

---

## Phase 2: New Skill Analysis

### Core Capabilities

**Purpose**: [What problem does this skill solve?]

**Key Features**:
1. [Feature 1]: [Description]
2. [Feature 2]: [Description]
3. ...

**Use Cases**:
- [Use case 1]: [Description]
- [Use case 2]: [Description]

### Technical Requirements

**Dependencies**:
- Python packages: [list]
- System libraries: [list]
- External services: [list]

**Hardware Requirements**:
- CPU: [minimum/suggested]
- GPU: [if applicable]
- RAM: [minimum/suggested]
- Storage: [disk space needed]

**Configuration Needs**:
- Config files: [list and purpose]
- Environment variables: [list]
- API keys: [if needed]

### Operational Characteristics

**Training Requirements**:
- Training data: [type and size]
- Training time: [typical duration]
- Training frequency: [how often]
- Training resources: [GPU/CPU needs]

**Inference Characteristics**:
- Inference latency: [typical time]
- Batch vs online: [which mode]
- Resource consumption: [CPU/GPU during inference]

**Maintenance Needs**:
- Update frequency: [how often]
- Bug fixes: [common issues]
- Monitoring: [what to track]

---

## Phase 3: Conflict Matrix

### Dimension-by-Dimension Analysis

| Dimension | Existing Skills | New Skill | Conflict Type | Impact Level | Notes |
|-----------|---------------|-----------|--------------|--------------|-------|
| **Working Layer** | [Layer(s) of existing] | [Layer of new] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Tech Stack** | [Technologies used] | [Technologies of new] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Dependencies** | [Packages and versions] | [Packages and versions] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Resource Usage - CPU** | [Pattern] | [Pattern] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Resource Usage - GPU** | [Pattern] | [Pattern] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Resource Usage - Memory** | [Pattern] | [Pattern] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Resource Usage - Storage** | [Pattern] | [Pattern] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Latency** | [Real-time/Batch] | [Real-time/Batch] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Maintenance** | [Update pattern] | [Update pattern] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |
| **Scenarios** | [Use cases] | [Use cases] | [No/Potential/Actual] | [Low/Medium/High] | [Details] |

### Conflict Type Definitions

**✅ No Conflict**:
- Independent technologies or different layers
- Can coexist without modification
- Example: Data layer skill + model layer skill

**⚠️ Potential Conflict**:
- May need adjustment, prioritization, or resource allocation
- Not a hard conflict but requires attention
- Example: Two GPU-intensive skills needing scheduling

**❌ Actual Conflict**:
- Direct incompatibility that must be resolved
- Cannot proceed without changes
- Example: Same technology but incompatible versions

### Impact Level Definitions

**Low Impact**:
- Cosmetic issues or minor inconvenience
- Can be worked around easily
- No operational disruption

**Medium Impact**:
- Requires workflow changes or resource allocation
- May need configuration adjustments
- Some operational disruption during integration

**High Impact**:
- Blocks deployment
- Requires major refactoring
- Significant operational disruption

---

## Phase 4: Compatibility Assessment

### Synergy Potential [Score X/10]

**Positive Impacts**:
1. [Benefit 1]: [How it enhances existing capabilities]
2. [Benefit 2]: [How it improves performance/accuracy/efficiency]
3. [Benefit 3]: [New use cases it enables]

**Rationale for Score**:
- Score 0-2: Minimal synergy, no clear benefits
- Score 3-5: Moderate synergy, some benefits but uncertain
- Score 6-8: Strong synergy, clear benefits in specific scenarios
- Score 9-10: Excellent synergy, significant benefits across many scenarios

**Final Score**: [X/10]
**Justification**: [2-3 sentences explaining the score]

---

### Risk Factors [Score X/10]

**Note**: Higher score = fewer/milder risks

**Potential Risks**:
1. [Risk 1]: [Description + mitigation]
2. [Risk 2]: [Description + mitigation]
3. [Risk 3]: [Description + mitigation]

**Risk Categories**:

**Training Overhead**:
- [Risk level]: Low/Medium/High
- [Impact]: [Description]
- [Mitigation]: [Strategy]

**Resource Competition**:
- [Risk level]: Low/Medium/High
- [Impact]: [Description]
- [Mitigation]: [Strategy]

**Deployment Complexity**:
- [Risk level]: Low/Medium/High
- [Impact]: [Description]
- [Mitigation]: [Strategy]

**Maintenance Burden**:
- [Risk level]: Low/Medium/High
- [Impact]: [Description]
- [Mitigation]: [Strategy]

**Compatibility Unknowns**:
- [Risk level]: Low/Medium/High
- [Impact]: [Description]
- [Mitigation]: [Strategy]

**Ecosystem Maturity**:
- [Risk level]: Low/Medium/High
- [Impact]: [Description]
- [Mitigation]: [Strategy]

**Rationale for Score**:
- Score 0-2: High risk, significant obstacles
- Score 3-5: Medium-high risk, notable obstacles
- Score 6-8: Medium-low risk, manageable obstacles
- Score 9-10: Low risk, minimal obstacles

**Final Score**: [X/10]
**Justification**: [2-3 sentences explaining the score]

---

### ROI Certainty [Score X/10]

**Benefits Analysis**:

**Quantifiable Benefits** (if applicable):
- [Metric 1]: [Current value] → [Expected value] (+[X]%)
- [Metric 2]: [Current value] → [Expected value] (+[Y]%)
- [Metric 3]: [Current value] → [Expected value] (+[Z]%)

**Qualitative Benefits**:
1. [Benefit 1]: [Description]
2. [Benefit 2]: [Description]
3. ...

**Cost Analysis**:

**Development Costs**:
- Time: [X hours/days]
- Resources: [CPU/GPU hours, storage, etc.]
- Personnel: [if applicable]

**Operational Costs**:
- Ongoing maintenance: [time per week/month]
- Resource consumption: [ongoing costs]
- Updates and upgrades: [frequency and cost]

**Timeline Analysis**:
- Implementation time: [X days/weeks]
- Time to first benefit: [Y days/weeks]
- Break-even point: [Z months]

**Confidence Assessment**:
- Benefit estimates: [Low/Medium/High confidence]
- Cost estimates: [Low/Medium/High confidence]
- Timeline estimates: [Low/Medium/High confidence]
- Overall confidence: [Low/Medium/High]

**Rationale for Score**:
- Score 0-2: Highly uncertain, little confidence in ROI
- Score 3-5: Uncertain, moderate confidence
- Score 6-8: Reasonably certain, good confidence
- Score 9-10: Highly certain, strong confidence

**Final Score**: [X/10]
**Justification**: [2-3 sentences explaining the score]

---

### Total Score: [X/30]

**Scoring Guide**:
- 25-30: ✅ Proceed with confidence
- 20-24: ⚠️ Pilot in controlled environment
- <20: ❌ Defer until conditions improve

---

## Phase 5: Recommendation

### Decision: [Proceed / Pilot First / Defer / Conditional Integration]

### Rationale

[Provide a detailed justification for the recommendation, referencing key findings from the analysis.]

**Key Factors**:
- [Factor 1]: [Impact on decision]
- [Factor 2]: [Impact on decision]
- [Factor 3]: [Impact on decision]

### Next Steps

**If Proceeding**:
1. [Step 1]: [Description + owner + timeline]
2. [Step 2]: [Description + owner + timeline]
3. [Step 3]: [Description + owner + timeline]

**If Piloting**:
1. [Define pilot scope]: [What to test, success criteria]
2. [Set up pilot environment]: [Isolation, monitoring]
3. [Execute pilot]: [Timeline, measurements]
4. [Evaluate results]: [Decision criteria]

**If Deferring**:
1. [Document rationale]: [Why deferring]
2. [Monitor conditions]: [What to watch for]
3. [Schedule re-assessment]: [When to review]
4. [Identify triggers]: [What would change the decision]

**If Conditional**:
1. [Define conditions]: [Prerequisites for integration]
2. [Address conditions]: [Plan to meet them]
3. [Re-evaluate**: [When to reassess]

---

## Phase 6: Risk Mitigation (If Proceeding or Piloting)

### Mitigation Strategies

**Resource Isolation**:
- [Strategy 1]: [Description + implementation plan]
- [Strategy 2]: [Description + implementation plan]

**Incremental Rollout**:
- [Phase 1]: [Scope + criteria]
- [Phase 2]: [Scope + criteria]
- [Phase 3]: [Scope + criteria]

**Rollback Preparedness**:
- [Integration points]: [List]
- [Backward compatibility]: [How maintained]
- [Rollback triggers]: [When to roll back]
- [Rollback procedure]: [Steps]

**Monitoring and Alerting**:
- [Metric 1]: [Threshold + action]
- [Metric 2]: [Threshold + action]
- [Metric 3]: [Threshold + action]

### Timeline

**Week 1**: [Activities]
**Week 2**: [Activities]
**Week 3**: [Activities]
**Week 4**: [Activities]

### Success Criteria

**Quantitative**:
- [Metric 1]: [Target value]
- [Metric 2]: [Target value]
- [Metric 3]: [Target value]

**Qualitative**:
- [Criterion 1]: [Description]
- [Criterion 2]: [Description]
- [Criterion 3]: [Description]

---

## Appendix

### Stakeholder Feedback

[If applicable, include feedback from relevant stakeholders]

### Alternative Options Considered

1. [Alternative 1]: [Description + why rejected/chosen]
2. [Alternative 2]: [Description + why rejected/chosen]
3. ...

### References

- [Document 1]: [Link or citation]
- [Document 2]: [Link or citation]
- ...

### Additional Notes

[Any other relevant information not covered above]

---

**Analysis Completed**: [YYYY-MM-DD]
**Analyst Signature**: [Agent Name]
**Version**: [1.0 / 1.1 / ...]
