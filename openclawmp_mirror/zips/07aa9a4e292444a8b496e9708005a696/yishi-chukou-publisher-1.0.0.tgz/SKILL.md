---
name: yishi-chukou-publisher
displayName: 意识出口公众号发布体系
description: "意识出口公众号的完整内容发布体系，涵盖选题→写作→富格式→审校→封面图→HTML→发布全流程。当用户要写公众号文章、发布内容、生成封面图、转HTML排版时调用。适配AI Agent/产品/工作流等科技观察类内容。"
version: 1.0.0
---

# 意识出口公众号发布体系

公众号「意识出口」的完整内容发布链路，从选题到发布一条龙。

## 触发词

- 「写一篇公众号」「写文章」「写一篇」
- 「生成封面图」「转HTML」「发布到公众号」
- 「审校一下」「降低AI味」

---

## 标准发布流程（5步）

```
Step1: yishi-chukou-writer 写初稿（四层自检）
Step2: wechat-writer 富格式插入
Step3: humanizer 快扫 → huashu-proofreading 三遍深度审校
Step4: 封面图生成（四层fallback）
Step5: baoyu-markdown-to-html 输出 HTML → 手动复制到公众号后台
```

详见 `references/workflow.md`

---

## 快速上手

**最常见场景**：用户给主题 → 直接全流程走完

```
你: "帮我写一篇关于MCP协议的文章"

→ Step1: 加载 yishi-chukou-writer，按意识出口风格写初稿
→ Step2: 读 rich-formats.md，判断加哪些富格式元素
→ Step3: humanizer 快扫 → 三遍审校
→ Step4: 生成封面图
→ Step5: 输出 HTML，告知可直接复制到公众号后台
```

---

## 文章风格核心规则（必须遵守）

- **无小标题**：不用「PART 01」「一、二、三」，一口气顺下去
- **禁用标点**：无冒号「：」、无破折号「——」、无双引号「""」，用「」
- **禁用词**：说白了、意味着什么、本质上、换句话说、不可否认、综上所述、首先其次最后、值得注意的是、不难发现
- **口语化**：一句话独立成段制造断裂感，口语化转场高频出现
- **字数**：不低于2500字，目标3500字

完整风格规范见 `references/style-rules.md`

---

## 封面图生成链路（四层fallback）

| 层级 | 方法 | 依赖 | 特点 |
|------|------|------|------|
| L1 | `baoyu-cover-image` | API Key | AI 5维度，创意型 |
| L2 | `article-cover-generator` | API Key | AI fallback |
| L3 | `s5_cover_html.mjs` | Puppeteer（本地） | 无API，文字精确，<3秒 |
| L4 | SVG文件 | 无依赖 | 最终兜底 |

- 尺寸：900×383px（公众号标准 2.35:1）
- 风格：深色科技风，深蓝黑背景 + 赛博朋克元素

---

## 富格式元素（wechat-writer 负责插入）

写完初稿后，判断哪些段落需要加富格式，加格式不改文字：

| 元素 | 语法 | 适用场景 |
|------|------|---------|
| 任务清单 | `- [x]` / `- [ ]` | 步骤、清单 |
| 键盘键 | `<kbd>Ctrl</kbd>` | 快捷键、命令 |
| 脚注 | `[^1]` | 引用、来源 |
| 代码块 | ` ```lang ` | 代码示例 |
| 引用块 | `>` | 重要引用 |
| Emoji语义 | 💡⚠️✅❌📌 | 语义标注 |

完整规范见 `references/rich-formats.md`

---

## HTML 发布

使用 `baoyu-markdown-to-html` 或 `wenyan` 渲染：

- 主题：lapis（冷蓝色清爽风，默认）
- 输出：Markdown → 微信兼容 HTML
- 发布方式：手动复制到公众号后台（稳定）

> ⚠️ API 模式（baoyu-post-to-wechat）已废弃，动态 IP 导致 40164 报错频发，不再使用。

---

## 公众号信息

- 账号：意识出口（订阅号）
- AppID：wx8d35c16134afcd25
- **IP 白名单**：需在公众号后台手动添加当前出口 IP

---

## 参考文件

| 文件 | 内容 |
|------|------|
| `references/workflow.md` | 完整5步发布流程详解 |
| `references/style-rules.md` | 意识出口写作风格规范 |
| `references/rich-formats.md` | 富格式元素写作规范（从wechat-writer同步） |
