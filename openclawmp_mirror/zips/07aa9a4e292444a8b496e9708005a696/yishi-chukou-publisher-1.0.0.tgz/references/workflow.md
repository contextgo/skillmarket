# 意识出口公众号发布完整流程

## 5步发布流程

### Step 1：写初稿（yishi-chukou-writer）

**触发**：用户给主题或素材

加载 yishi-chukou-writer skill，按以下规则写作：

1. **HKR 选题质检**
   - H (Happy)：有趣、有悬念，让人想点开
   - K (Knowledge)：有信息量，看完能学到东西
   - R (Resonance)：戳中情绪，让人"对对对我也这么想"
   - S级选题三项兼备，及格至少两项

2. **写作规则**
   - 无小标题（PART 01等），一口气顺下
   - 无冒号「：」无破折号「——」无双引号「""」
   - 禁用词：说白了、意味着什么、本质上、换句话说
   - 一句话独立成段制造断裂感
   - 字数不低于 2500 字，目标 3500 字

3. **四层自检**
   - L1：禁用词/标点检查
   - L2：风格一致性检查
   - L3：内容质量检查
   - L4：活人感检查（有没有第一人称体验、有没有情绪波动）

---

### Step 2：富格式插入（wechat-writer）

**触发**：初稿完成后

读 `references/rich-formats.md`，判断哪些位置需要加富格式：

- 步骤/流程 → 任务清单 `- [ ]`
- 快捷键/命令 → 键盘键 `<kbd>`
- 引用/来源 → 脚注 `[^1]`
- 代码示例 → 代码块 ` ```lang `
- 重要引言 → 引用块 `>`
- 状态对比 → 状态表格

**原则**：wechat-writer 只加格式，不改文字内容。

---

### Step 3：审校（两遍）

**第一遍：humanizer 快扫**

规则引擎，3秒出结果，覆盖：
- 90+ 中英 inflation 词汇清理
- 句式模板检测（不是…而是…、一方面…另一方面…）
- 结尾模板清理
- emoji 滥用清理

**第二遍：huashu-proofreading 三遍深度改**

三遍方法论：
1. 事实与逻辑：可核查信息有来源，逻辑无跳跃
2. 语言与去AI味：减少引号冒号破折号，把表达落到具体动作
3. 完读率与节奏：删重复观点，合并相邻段落，结尾用细节收束

**触发时机**：用户说「审校」「降低AI味」「太AI了」「自然一些」

---

### Step 4：封面图生成

**四层 fallback 链**：

```
L1: baoyu-cover-image（AI 5维度，依赖API Key）
  ↓ 失败
L2: article-cover-generator（AI fallback，依赖API Key）
  ↓ 失败
L3: s5_cover_html.mjs（Puppeteer本地截图，无API依赖）
  ↓ 失败
L4: SVG文件（最终兜底，用户手动另存PNG）
```

**规格**：
- 尺寸：900×383px（公众号标准 2.35:1）
- 风格：深色科技风（深蓝黑 #0a1628 + 亮青 #00d4ff）
- L3 HTML封面关键：HTML含 `id="capture-container"`，装饰用 `position:absolute`

**注意**：
- 微信封面图必须用本地文件路径上传，不接受远程URL
- thumb_media_id 必须是永久素材，不能用临时素材

---

### Step 5：HTML输出与发布

**渲染工具**：`baoyu-markdown-to-html`（bun）或 `wenyan`

- 默认主题：lapis（冷蓝色清爽风）
- 有效主题：`default, grace, modern, simple, lapis`

**发布方式**（手动复制，最稳定）：
1. 生成 HTML 文件
2. 告知老大：「HTML 已生成，可直接复制到公众号后台」
3. 老大手动复制到公众号编辑器，发布

> ⚠️ 不走 API 自动发布，因动态 IP 频繁触发 40164 报错。

---

## 常见问题

### API 报 40164 错误
当前出口 IP 不在公众号 IP 白名单，临时处理：
1. 执行 `_check_ip.ps1` 查当前 IP
2. 到公众号后台「开发→基本配置→IP白名单」添加
3. 或直接走手动复制方案（推荐）

### 封面图 Puppeteer 截图为空白
- 检查 HTML 是否含 `id="capture-container"`
- 装饰元素必须用 `position:absolute`，不能用 `position:fixed`

### wechat-writer 富格式没生效
- 确认读取了 `references/rich-formats.md`
- Mermaid图/LaTeX公式需截图，不能直接渲染为微信图片
