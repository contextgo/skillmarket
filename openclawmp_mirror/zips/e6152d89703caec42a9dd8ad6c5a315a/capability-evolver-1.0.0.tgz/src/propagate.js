/**
 * 跨技能传播功能集成模块
 * 调用 Python 实现的传播功能
 */

const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');

/**
 * 传播单个LRN到相关技能
 * @param {string} lrnId - LRN编号，如 "LRN-088"
 * @param {string} mode - 模式：'dry-run' | 'review' | 'auto'
 * @returns {boolean} - 是否成功
 */
function propagateExperience(lrnId, mode = 'review') {
  const scriptPath = path.join(__dirname, '..', 'core', 'propagate_mvp.py');
  
  // 检查脚本是否存在
  if (!fs.existsSync(scriptPath)) {
    console.error(`❌ 传播脚本不存在: ${scriptPath}`);
    return false;
  }
  
  // 构建命令
  const cmd = `python "${scriptPath}" --propagate ${lrnId} --${mode}`;
  
  console.log(`\n=== 跨技能传播 ===`);
  console.log(`LRN: ${lrnId}`);
  console.log(`模式: ${mode}`);
  console.log();
  
  try {
    // 执行Python脚本
    const output = execSync(cmd, { 
      encoding: 'utf-8',
      stdio: 'inherit'  // 直接输出到控制台
    });
    
    return true;
  } catch (error) {
    console.error(`❌ 传播失败: ${error.message}`);
    return false;
  }
}

/**
 * 批量传播多个LRN
 * @param {string[]} lrnIds - LRN编号数组
 * @param {string} mode - 模式
 * @returns {object} - 结果统计 {success: number, failed: number}
 */
function batchPropagate(lrnIds, mode = 'review') {
  const results = {
    success: 0,
    failed: 0,
    details: []
  };
  
  console.log(`\n=== 批量传播 ===`);
  console.log(`总计: ${lrnIds.length} 个LRN`);
  console.log();
  
  for (const lrnId of lrnIds) {
    const success = propagateExperience(lrnId, mode);
    if (success) {
      results.success++;
      results.details.push({ lrnId, status: 'success' });
    } else {
      results.failed++;
      results.details.push({ lrnId, status: 'failed' });
    }
  }
  
  console.log(`\n=== 批量传播完成 ===`);
  console.log(`成功: ${results.success}/${lrnIds.length}`);
  console.log(`失败: ${results.failed}/${lrnIds.length}`);
  
  return results;
}

/**
 * 列出可传播的LRN
 * 扫描LEARNINGS.md，找出P0/P1优先级或包含Pattern-Key的LRN
 */
function listPropagatable() {
  const learningsPath = path.join(
    process.env.XIAOYUE_WORKSPACE || 'D:\\XiaoYue_Workspace',
    '.learnings',
    'LEARNINGS.md'
  );
  
  if (!fs.existsSync(learningsPath)) {
    console.error(`❌ LEARNINGS.md 不存在: ${learningsPath}`);
    return [];
  }
  
  const content = fs.readFileSync(learningsPath, 'utf-8');
  
  // 匹配LRN条目
  const lrnPattern = /## (LRN-\d+) \[(\d{4}-\d{2}-\d{2})\] (.+?)[\n\r]/g;
  const propagatable = [];
  
  let match;
  while ((match = lrnPattern.exec(content)) !== null) {
    const lrnId = match[1];
    const date = match[2];
    const title = match[3];
    
    // 提取该LRN的完整内容（到下一个##或文件结尾）
    const startIndex = match.index;
    const nextMatch = content.indexOf('\n## ', startIndex + 1);
    const endIndex = nextMatch === -1 ? content.length : nextMatch;
    const lrnContent = content.substring(startIndex, endIndex);
    
    // 检查是否符合传播条件
    const isPriority = /Priority.*?(P0|P1)/.test(lrnContent);
    const hasPatternKey = /Pattern-Key/.test(lrnContent);
    
    if (isPriority || hasPatternKey) {
      const priorityMatch = lrnContent.match(/Priority.*?(P\d)/);
      const priority = priorityMatch ? priorityMatch[1] : 'P2';
      
      propagatable.push({
        lrnId,
        date,
        title,
        priority,
        hasPatternKey
      });
    }
  }
  
  return propagatable;
}

/**
 * 打印可传播的LRN列表
 */
function printPropagatable() {
  const list = listPropagatable();
  
  console.log(`\n=== 可传播的LRN ===`);
  console.log(`总计: ${list.length} 个\n`);
  
  if (list.length === 0) {
    console.log('未找到符合条件的LRN（P0/P1优先级或包含Pattern-Key）');
    return;
  }
  
  console.log('┌────────────┬────────────┬──────┬────────────┬────────────────────┐');
  console.log('│ LRN编号    │ 日期       │ 优先级│ Pattern-Key│ 标题               │');
  console.log('├────────────┼────────────┼──────┼────────────┼────────────────────┤');
  
  for (const item of list) {
    const lrnId = item.lrnId.padEnd(10);
    const date = item.date;
    const priority = item.priority.padEnd(4);
    const hasKey = item.hasPatternKey ? '✓'.padEnd(10) : ''.padEnd(10);
    const title = item.title.length > 18 ? item.title.substring(0, 15) + '...' : item.title.padEnd(18);
    
    console.log(`│ ${lrnId} │ ${date} │ ${priority} │ ${hasKey} │ ${title} │`);
  }
  
  console.log('└────────────┴────────────┴──────┴────────────┴────────────────────┘');
}

module.exports = {
  propagateExperience,
  batchPropagate,
  listPropagatable,
  printPropagatable
};
