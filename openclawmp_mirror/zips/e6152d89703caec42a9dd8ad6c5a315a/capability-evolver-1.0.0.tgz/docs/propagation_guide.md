# 跨技能传播功能详细指南

> capability-evolver v2.0 新增功能  
> 本文档提供跨技能传播功能的详细说明

## 目录

- [核心架构](#核心架构)
- [L1 经验提取器](#l1-经验提取器)
- [L2 受体匹配器](#l2-受体匹配器)
- [L3 应用执行器](#l3-应用执行器)
- [验证层](#验证层)
- [用户交互示例](#用户交互示例)
- [数据结构](#数据结构)
- [性能目标](#性能目标)
- [最佳实践](#最佳实践)

## 核心架构

```
┌─────────────────────────────────────────────────────────────┐
│                    进化→传播数据流                           │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  进化阶段（现有）                                            │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  LEARNINGS.md → evolution_scan.py → 进化方案         │   │
│  │       ↓                                              │   │
│  │  执行进化 → 更新技能 → 写入 LRN-XXX                  │   │
│  └─────────────────────────────────────────────────────┘   │
│                         │                                   │
│                         ↓ 触发传播检查                       │
│                                                             │
│  传播阶段（新增）                                            │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  L1 提取器: LRN-XXX → ExperienceKernel               │   │
│  │       ↓                                              │   │
│  │  L2 匹配器: Kernel + SKILL_INDEX → 匹配列表          │   │
│  │       ↓                                              │   │
│  │  L3 执行器: 应用到目标技能 → 备份 → 验证             │   │
│  │       ↓                                              │   │
│  │  写入传播日志 → 更新 monitor.json                    │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## L1 经验提取器

**职责**：从 LRN 中提取结构化经验核

**输入**：LRN-XXX 编号  
**输出**：ExperienceKernel 对象

```python
class ExperienceKernel:
    lrn_id: str           # LRN-088
    source_skill: str     # user-preferences
    domain: str          # workflow
    tags: List[str]      # ["启动序列", "防幻觉"]
    priority: str        # P0/P1/P2
    problem: str         # 问题描述
    solution: str        # 解决方案
    pattern_key: str     # 可选的模式标识
    created_at: datetime
```

**提取流程**：
1. 读取 LEARNINGS.md，定位 LRN-XXX 条目
2. 解析 frontmatter（Category, Priority, Pattern-Key）
3. 解析正文内容，提取 Problem/Solution
4. 生成经验核对象
5. 缓存到 KernelCache (TTL=1h)

## L2 受体匹配器

**职责**：为目标技能匹配相关经验

**匹配算法**：
```
匹配分 = Σ(权重i × 匹配度i)

权重分配：
- Domain匹配: 0.4
- Tags重叠: 0.3
- 关键词相似: 0.2
- 使用频率: 0.1

阈值：
- 高相关: score >= 0.7
- 中相关: 0.4 <= score < 0.7
- 低相关: score < 0.4 (过滤)
```

**输出**：按匹配分排序的技能列表

## L3 应用执行器

**职责**：将经验应用到目标技能

**支持动作**：

| 动作 | 说明 | 示例 |
|------|------|------|
| `APPEND` | 追加到现有章节 | 向 ## 最佳实践 追加 |
| `INSERT` | 插入新章节 | 新增 ## 跨技能经验 |
| `MODIFY` | 修改现有内容 | 更新配置示例 |
| `CREATE` | 创建新文件 | 新建子技能文档 |
| `DEPRECATE` | 标记废弃 | 添加 @deprecated |

**事务管理**：
```python
class PropagationTransaction:
    def begin(self):      # 创建备份
    def execute(self):    # 执行动作
    def commit(self):     # 确认提交
    def rollback(self):   # 回滚恢复
```

## 验证层

**四层验证**：

1. **语法验证**：Markdown/frontmatter 格式正确
2. **结构验证**：章节层级、链接完整性
3. **内容验证**：无重复、无冲突
4. **功能验证**：dry-run 模拟执行

**冲突检测**：
- T1: 同一位置多次修改
- T2: 多个kernel目标同一位置
- T3: 修改内容与现有内容语义冲突（相似度>0.8）
- T4: 跨技能循环依赖

## 用户交互示例

### 单个LRN传播

```
$ node index.js --propagate LRN-088 --review

📋 经验核摘要
   来源: user-preferences
   领域: workflow
   标签: [启动序列, 防幻觉]
   优先级: P0
   摘要: 每次对话前必须执行启动序列...

🎯 匹配到 6 个相关技能:
   ┌────┬─────────────────────┬────────┬────────┐
   │ 序号 │ 技能名称            │ 匹配分 │ 动作   │
   ├────┼─────────────────────┼────────┼────────┤
   │ 1  │ proactive-agent     │ 0.92   │ APPEND │
   │ 2  │ self-improvement    │ 0.85   │ APPEND │
   │ 3  │ multi-agent-collab  │ 0.78   │ INSERT │
   │ 4  │ langgraph-multi-agent│ 0.72  │ APPEND │
   │ 5  │ planning-with-files │ 0.65   │ APPEND │
   │ 6  │ skill-workshop      │ 0.58   │ APPEND │
   └────┴─────────────────────┴────────┴────────┘

⚠️  检测到 1 个潜在冲突:
   • proactive-agent: 已存在相似内容 (相似度 0.82)

请选择操作:
   [1-6] 查看单个技能详情
   [a]   全部应用
   [c]   取消
   [s]   跳过冲突项后应用
   
> s

✅ 传播完成摘要:
   成功: 5/6
   跳过: 1 (proactive-agent 已存在相似内容)
   失败: 0
   备份位置: C:\Users\Field\.stepfun\skills\.evolver\backups\propagate_20260319_143022\
```

### 进化+传播一体化

```
$ node index.js --evolve-and-propagate

=== 阶段1: 进化扫描 ===
扫描到 3 个待进化项...
[E-029] user-preferences: Token超标
[E-030] proactive-agent: 依赖缺失
[E-031] self-improvement: 格式不规范

执行进化? [y/n] y

=== 阶段2: 进化执行 ===
[E-029] 完成 ✓
[E-030] 完成 ✓
[E-031] 完成 ✓

写入学习记录: LRN-089, LRN-090, LRN-091

=== 阶段3: 传播检查 ===
[LRN-089] P0优先级，检查传播...
  匹配到 4 个相关技能

[LRN-090] P1优先级，检查传播...
  匹配到 2 个相关技能

[LRN-091] P2优先级，跳过传播

是否执行传播? [y/n] y

=== 阶段4: 传播执行 ===
[LRN-089] → 4 个技能 ✓
[LRN-090] → 2 个技能 ✓

📊 总结:
   进化: 3 个技能
   传播: 6 个技能
   新增LRN: 3 条
   传播记录: 2 条
```

## 数据结构

### monitor.json 扩展

```json
{
  "monitored_skills": [...],
  "evolution_history": [...],
  "propagation_history": [
    {
      "id": "PROP-20260319-001",
      "kernel_id": "LRN-088",
      "timestamp": "2026-03-19T14:30:22Z",
      "status": "completed",
      "targets": [
        {
          "skill": "proactive-agent",
          "action": "APPEND",
          "status": "success",
          "backup": "proactive-agent.bak.20260319_143022",
          "diff_lines": 12
        }
      ]
    }
  ],
  "next_propagation_id": 2
}
```

### 传播日志

`D:\XiaoYue_Workspace\.learnings\propagation_log.yaml`

```yaml
records:
  - id: "PROP-20260319-001"
    kernel_id: "LRN-088"
    timestamp: "2026-03-19T14:30:22Z"
    status: "completed"
    targets:
      - skill: "proactive-agent"
        action: "APPEND"
        status: "success"
        backup: "proactive-agent.bak.20260319_143022"
        diff_lines: +12
```

### Pattern-Key 映射规则

`C:\Users\Field\.stepfun\skills\capability-evolver\config\domain_map.yaml`

```yaml
pattern_domain_map:
  skill-consolidation:
    domains: [automation, general]
    description: "技能整合相关经验"
  
  archive-before-delete:
    domains: [automation, document, general]
    description: "删除前归档的最佳实践"
  
  skill-must-be-chinese:
    domains: ['*']
    description: "技能中文化要求"
  
  token-budget:
    domains: ['*']
    description: "Token预算管理"
  
  security:
    domains: [automation, code]
    description: "安全相关最佳实践"
  
  timeout-handling:
    domains: [search, social, general]
    description: "超时处理策略"
```

## 性能目标

| 指标 | 目标 | 说明 |
|------|------|------|
| 单技能传播 | <2s | 提取→匹配→执行→验证 |
| 10技能批量 | <10s | 含缓存命中 |
| 索引查询 | <50ms | SKILL_INDEX 检索 |
| 缓存命中率 | >80% | Kernel + Index |

## 最佳实践

1. **首次使用先 dry-run**：`node index.js --propagate LRN-XXX --dry-run`
2. **批量传播分批确认**：避免一次性修改过多技能
3. **定期清理备份**：保留策略自动执行，无需手动干预
4. **冲突时优先跳过**：相似度>0.8时建议跳过，避免重复内容
5. **进化+传播一体化**：使用 `--evolve-and-propagate` 实现完整闭环

## 安全与回滚

**备份策略**：
```
备份目录: C:\Users\Field\.stepfun\skills\.evolver\backups\propagate_YYYYMMDD_HHMMSS\
├── manifest.json          # 备份清单
├── proactive-agent.bak    # 原文件
├── self-improvement.bak   # 原文件
└── ...

保留策略:
- 最近7天: 全部保留
- 7-30天: 每天保留最新
- 30天后: 自动清理
```

**回滚命令**：
```bash
# 查看可回滚的操作
node index.js --list-rollbacks

# 回滚指定传播
node index.js --rollback PROP-20260319-001

# 回滚到指定时间点
node index.js --rollback-to 2026-03-19T14:30:00Z
```

## 与 WF-CrossSkill 的关系

**功能迁移**：
- ✅ Pattern-Key匹配逻辑 → L2匹配器
- ✅ 同类技能检查 → SKILL_INDEX
- ✅ 建议生成 → L3执行器
- ✅ 累积推送 → monitor.json

**功能增强**：
- ✅ 自动执行（原WF-CrossSkill仅建议）
- ✅ 事务管理（备份+回滚）
- ✅ 4层验证
- ✅ 完整CLI交互

**废弃流程**：
- WF-CrossSkill 工作流（`p0_03_wf_crossskill.py`）已废弃
- 核心逻辑已迁移至 capability-evolver
- 原脚本已归档至 `D:\XiaoYue_Workspace\archives\deprecated_workflows\`
