---
name: capability-evolver
description: "AI Agent 的自我进化引擎。分析运行时历史记录以识别改进点，并应用协议约束的进化。支持自动日志分析、自我修复、GEP 协议、跨技能传播和一键进化。触发：'能力进化'、'自我进化'、'技能进化'、'capability evolver'、'evolve'、'/evolve'"
metadata:
  version: "2.0"
  updated: "2026-03-19"
  changelog: "v2.0: 整合跨技能传播功能（Cross-Skill Propagation），新增L1-L3传播模块，扩展GEP周期至8阶段，废弃WF-CrossSkill工作流"
tags: [meta, ai, self-improvement, core, propagation]
---

# 能力进化器 v2.0

**"进化不是可选的。适应或淘汰。"**

**能力进化器**是一个元技能，允许 Agent 检查自身的运行时历史，识别失败或低效之处，并自主编写新代码或更新自身记忆以提升性能。v2.0 整合了**跨技能传播功能**，实现"单技能进化 → 经验传播 → 生态系统进化"的完整闭环。

## 功能特性

- **自动日志分析**：自动扫描记忆和历史文件中的错误和模式
- **自我修复**：检测崩溃并建议补丁
- **GEP 协议**：标准化的进化流程，可复用资产
- **跨技能传播**：将进化经验自动传播到相关技能（新增）
- **一键进化**：只需运行 `/evolve`（或 `node index.js`）

## 使用方式

### 标准运行（默认：审查模式）
运行进化循环。**默认启用 `--review` 模式**，Agent 会在应用更改前暂停并请求人工确认。这是推荐的安全运行方式。
```bash
node index.js
```

> **安全优先原则：** `--review` 是默认模式而非 `--auto`，这是刻意的设计。进化本质上是自我修改，必须经过人工确认。只有在充分信任进化方案且变更范围可控时，才应使用 `--auto`。

### 自动化模式（需显式 opt-in）
如果你确认要跳过人工审查并立即执行更改，必须显式传入 `--auto` 标志。**请谨慎使用**，仅在充分信任进化方案时启用。
```bash
node index.js --auto
```

### 审查模式（显式声明，与默认行为相同）
等同于默认行为，显式声明审查模式。
```bash
node index.js --review
```

### 持续进化守护模式
要在无限循环中运行（例如通过 cron 或后台进程），使用 `--loop` 标志。
```bash
node index.js --loop
```

> **持续进化理念：** 进化不应是一次性事件，而是持续运行的守护进程。`--loop` 模式定期扫描日志和学习记录，在发现可改进点时自动生成方案（仍需人工确认）。适合设置为每日定时任务。

### 跨技能传播命令（v2.0 新增）

```bash
# 查看可传播的经验
node index.js --list-propagatable

# 预览传播效果（推荐先执行）
node index.js --propagate LRN-088 --dry-run

# 人工确认模式（默认）
node index.js --propagate LRN-088 --review

# 全自动模式（谨慎使用）
node index.js --propagate LRN-088 --auto

# 批量传播
node index.js --batch-propagate LRN-088,LRN-089,LRN-090

# 进化+传播一体化（推荐）
node index.js --evolve-and-propagate
```

## 配置

进化器的核心配置均为本地文件，无需外部服务注册：

- **监控配置**：`C:\Users\Field\.stepfun\skills\.evolver\monitor.json`（技能状态追踪）
- **学习记录**：`D:\XiaoYue_Workspace\.learnings\LEARNINGS.md`（进化信号来源）
- **扫描脚本**：`D:\XiaoYue_Workspace\scripts\evolution_scan.py`（自动化扫描）
- **进化方案归档**：`D:\XiaoYue_Workspace\projects\skill_analysis\`（跨会话引用）
- **传播日志**：`D:\XiaoYue_Workspace\.learnings\propagation_log.yaml`（传播历史记录，v2.0新增）
- **传播配置**：`C:\Users\Field\.stepfun\skills\capability-evolver\config\propagate.yaml`（传播规则，v2.0新增）

## 与其他技能的协同

- **+ self-improvement**：进化器分析 self-improvement 记录的错误和学习，自动生成改进方案
- **+ skill-workshop**：skill-workshop 生成的新技能自动注册到进化器的监控列表；当技能积累 3 条以上学习记录时，进化器标记该技能为"待更新"
- **审计日志**：每次执行进化时，自动在 LEARNINGS.md 中写入 `[EVOLUTION]` 类型条目，格式：`## EVO-XXX [日期] 进化标题`，记录进化目标、变更内容、影响范围

## GEP 协议

GEP（Generalized Evolution Protocol）是标准化的进化流程，确保进化可复用、可追溯。

### GEP 进化周期

GEP 不是独立于上述命令的新流程，而是对每次进化运行的**方法论注解**——无论用 `node index.js` 还是手动进化，都应遵循这个周期：

```
感知 → 诊断 → 方案 → 审查 → 执行 → 验证 → 记录
  │       │       │       │       │       │       │
  │       │       │       │       │       │       └─ 写入学习记录（LEARNINGS.md）
  │       │       │       │       │       └─ 验证 Done Criteria（不是"看起来对了"而是"可测试地对了"）
  │       │       │       │       └─ 原子性执行，可回滚（每个变更独立，失败不影响其他）
  │       │       │       └─ 人工确认（--review 默认）或自动（--auto 显式）
  │       │       └─ 生成具体变更方案（改哪个文件、改哪一行、改成什么）
  │       └─ 识别根因而非症状（"为什么出错"而非"哪里出错"）
  └─ 扫描日志/记忆/历史中的异常信号
```

### 进化执行纪律（来自实战经验）

**DAG 依赖管理（LRN-022）**：多个进化动作并行执行时，必须先建立 DAG 依赖关系图，按拓扑排序确定执行顺序。同一批次内的动作必须相互独立——不能出现动作 A 的输出被动作 B 覆盖，或动作 C 依赖动作 D 尚未完成的结果。

**ROI 排序分批（LRN-043）**：进化动作按投入产出比分三批执行：批次1（高ROI）= 修复阻塞性问题（Token超标、格式违规、版本不一致）；批次2（中ROI）= 修复机制性问题（分工不清、状态过时、经验未回流）；批次3（低ROI）= 功能增强（新模板、新预设）。每个批次执行前需用户确认。

**大型 JSON 操作规避（LRN-067）**：对 monitor.json 等大型结构化文件（>500行或>15KB），应使用 Python 脚本通过 `json.load()` → 修改 → `json.dumps()` → 写回的方式操作，而非依赖 Edit 工具的文本替换（可能静默失败）。

### 自动日志分析模式

进化器可自动扫描以下来源识别改进点：

| 来源 | 扫描内容 | 触发条件 |
|------|---------|---------|
| LEARNINGS.md | 重复出现的错误模式 | 同一 Pattern-Key 出现 ≥3 次 |
| 对话历史 | 用户纠正、任务失败 | 关键词匹配（"不对"、"错了"、"应该是"） |
| 技能健康检查 | Token 超标、依赖缺失 | 健康检查脚本输出 |
| monitor.json | 技能使用频率异常 | 30天未使用或错误率 >20% |

### 进化资产复用

GEP 产出的进化方案可作为模板复用：
- **瘦身模板** — 适用于所有 Token 超标的技能
- **中文化模板** — 适用于所有英文技能的本地化
- **依赖检查模板** — 适用于所有有外部依赖的技能

### 进化成果共享理念

虽然我们不使用 EvoMap 网络，但其核心理念值得保留：每次进化产出的方案、模板、学习记录都是**可复用资产**。当前通过以下方式实现共享：
- 进化方案记录在 `D:\XiaoYue_Workspace\projects\skill_analysis\` 下，可跨会话引用
- 学习记录（LEARNINGS.md）是所有进化的知识沉淀
- monitor.json 追踪技能状态，为下次进化提供输入

## 技能监控配置

进化器通过监控配置文件追踪技能状态。该文件位于 `C:\Users\Field\.stepfun\skills\.evolver\monitor.json`（如不存在则自动创建）。

### monitor.json Schema 定义（E-CEV-001）

```json
{
  "monitored_skills": [
    {
      "name": "string — 技能名称（必填）",
      "description": "string — 技能简述",
      "path": "string — 技能目录绝对路径",
      "created_at": "string — ISO 8601 时间戳",
      "skill_type": "string — 生成类|分析类|工具类|元技能",
      "status": "string — active|pending_update|deprecated",
      "learning_count": "number — 关联的学习记录条数",
      "last_evolution": "string — 最后一次进化的日期",
      "evolution_ids": ["string — 关联的进化方案编号列表"]
    }
  ],
  "last_scan": "string — 最后一次扫描时间",
  "next_evolution_id": "number — 下一个进化方案的自增编号"
}
```

**编号管理**：进化方案编号从 `next_evolution_id` 读取，使用后自增+1写回。

### 进化方案审查标准（E-CEV-002）

进化方案在应用前必须通过以下4条审查标准（默认审查模式下由用户确认）：

| # | 标准 | 说明 | 不通过则 |
|---|------|------|---------|
| 1 | **不删除现有功能** | 进化方案不能导致任何已有功能丧失 | 拒绝方案 |
| 2 | **不引入新外部依赖** | 不能要求安装新的 API Key、CLI 工具或服务注册 | 拒绝或标记为"需用户确认" |
| 3 | **Token 预算达标** | 修改后的 SKILL.md ≤ 16000 bytes | 要求先瘦身再应用 |
| 4 | **安全审查通过** | 不包含危险命令（rm/del/Remove-Item等）、不泄露数据到外部 | 拒绝方案 |

### 状态流转

```
技能生成 → 注册监控（skill-workshop 写入配置）→ status: active
         ↓
    运行中使用 → 产生学习记录 → learning_count += 1
         ↓
    learning_count >= 3 → pending_update: true
         ↓
    用户选择"立即更新" → skill-workshop 执行更新 → pending_update: false, learning_count: 0
```

### 扫描逻辑

进化器定期（或手动触发）执行以下操作：
1. 读取 `D:\XiaoYue_Workspace\.learnings\LEARNINGS.md`
2. 解析每条学习记录，提取关联的技能名称（通过 Pattern-Key 或上下文推断）
3. 更新对应技能的 `learning_count` 和 `last_learning_at`
4. 当 `learning_count >= update_threshold` 时，设置 `pending_update: true`
5. 将待更新技能列表输出到监控配置的 `pending_updates` 字段

### 与 skill-workshop 的接口

**skill-workshop → capability-evolver（注册）**
- 触发时机：技能生成完成、打包后
- 操作：调用进化器的注册接口，写入技能元数据
- 数据：name, description, path, created_at, skill_type

**capability-evolver → skill-workshop（提示）**
- 触发时机：用户进入 skill-workshop 的技能管理阶段
- 操作：skill-workshop 读取进化器的监控配置，检查 `pending_updates`
- 展示：待更新技能列表，包含 learning_count 和问题摘要

**skill-workshop → capability-evolver（更新确认）**
- 触发时机：用户选择"立即更新"并完成更新后
- 操作：调用进化器的更新确认接口
- 效果：重置 `learning_count: 0`, `pending_update: false`, `status: "updated"`

## 进化方案编号管理（E-012 新增）

进化方案使用全局递增编号 `E-{序号}`，格式为 E-001、E-002...

### 编号规则
- 每轮进化生成的方案项使用连续编号
- 编号不可重复，新一轮进化从上一轮最大编号 +1 开始
- 当前已使用编号：E-001 ~ E-028
- 下次进化起始编号：E-029

### 进化摘要自动追加
每轮进化完成后，**必须**将以下信息追加到 monitor.json 的 `evolution_history` 数组中：

```json
{
  "date": "ISO 8601 时间戳",
  "action": "batch_update | single_fix | cleanup",
  "evolution_range": "E-xxx ~ E-xxx",
  "skills_updated": ["技能名列表"],
  "details": "进化摘要描述"
}
```

### 废弃技能清理流程（E-010）
当技能被标记为 `deprecated` 时：
1. 在 SKILL.md 顶部添加废弃声明
2. 从 monitor.json 的 `monitored_skills` 中移除（或保留 status: deprecated 供审计）
3. 如有归档需求，移动到 `D:\XiaoYue_Workspace\archives\deprecated_skills\`

### 扫描脚本
进化扫描脚本位于 `D:\XiaoYue_Workspace\scripts\evolution_scan.py`（v2.0），支持：
- 精确匹配 LRN/ERR/FR 编号格式
- 技能使用覆盖率统计
- 自动更新 daily_status.md
- 待解决记录检查

快速运行：
```bash
cmd /c "D:\XiaoYue_Workspace\python_env\python312\python.exe D:\XiaoYue_Workspace\scripts\evolution_scan.py"
```

## 跨技能传播功能（v2.0 新增）

**跨技能传播**（Cross-Skill Propagation）是 v2.0 的核心新功能，将进化经验自动传播到相关技能，实现"单技能进化 → 经验传播 → 生态系统进化"的完整闭环。

### 核心理念

当某个技能产生重要经验（如 LRN-088）时，该经验可能对其他相关技能同样有价值。传播功能自动识别这些关联，将经验结构化提取并应用到目标技能，避免经验孤岛。

### 三层架构

- **L1 提取器**：从 LRN 中提取结构化经验核（ExperienceKernel）
- **L2 匹配器**：4维度匹配算法（Domain 0.4 + Tags 0.3 + 关键词 0.2 + 使用频率 0.1），阈值≥0.4
- **L3 执行器**：支持 APPEND/INSERT/MODIFY/CREATE/DEPRECATE 五种动作，含事务管理（备份→应用→验证→回滚）

### 自动触发

进化完成后，自动检查新写入的 LRN：
- 优先级为 P0/P1，或
- 包含 Pattern-Key

符合条件则提取经验核，匹配相关技能，默认审查模式询问用户确认。

### 快速开始

```bash
# 预览传播效果（推荐先执行）
node index.js --propagate LRN-088 --dry-run

# 执行传播（人工确认）
node index.js --propagate LRN-088 --review

# 进化+传播一体化（推荐）
node index.js --evolve-and-propagate
```

### 数据存储

- **传播日志**：`D:\XiaoYue_Workspace\.learnings\propagation_log.yaml`
- **传播历史**：`monitor.json` 的 `propagation_history` 字段
- **Pattern映射**：`config/domain_map.yaml`（继承自WF-CrossSkill）

### 与 WF-CrossSkill 的关系

WF-CrossSkill 工作流已废弃，核心逻辑已迁移至本模块：
- Pattern-Key匹配 → L2匹配器
- 建议生成 → L3执行器
- 功能增强：自动执行、事务管理、4层验证、完整CLI

### 详细文档

完整的架构说明、数据结构、交互示例、性能目标和最佳实践，请参阅：  
`C:\Users\Field\.stepfun\skills\capability-evolver\docs\propagation_guide.md`
