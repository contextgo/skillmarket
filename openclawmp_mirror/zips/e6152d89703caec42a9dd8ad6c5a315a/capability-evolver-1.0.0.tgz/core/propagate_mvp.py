#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
跨技能传播原型 (Propagation MVP)
最小可用版本，用于验证核心流程

使用方法:
  python propagate_mvp.py --propagate LRN-088 --dry-run
  python propagate_mvp.py --propagate LRN-088 --review
"""

import sys
import os
import argparse
import json
import yaml
from pathlib import Path

# 添加模块路径
sys.path.insert(0, str(Path(__file__).parent))

from propagate.extractor import ExperienceExtractor, ExperienceKernel


class SimpleMatcher:
    """简化的L2匹配器"""
    
    def __init__(self, domain_map_path: str, skill_index_path: str):
        self.domain_map = self._load_domain_map(domain_map_path)
        self.skill_index = self._load_skill_index(skill_index_path)
    
    def _load_domain_map(self, path: str) -> dict:
        """加载domain_map.yaml"""
        with open(path, 'r', encoding='utf-8') as f:
            return yaml.safe_load(f)
    
    def _load_skill_index(self, path: str) -> list:
        """加载SKILL_INDEX"""
        if not os.path.exists(path):
            # 如果不存在，返回模拟数据
            return [
                {'name': 'proactive-agent', 'domain': 'automation', 'tags': ['workflow', 'automation']},
                {'name': 'self-improvement', 'domain': 'meta', 'tags': ['learning', 'meta']},
                {'name': 'planning-with-files', 'domain': 'automation', 'tags': ['planning', 'workflow']},
            ]
        
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data.get('skills', [])
    
    def match(self, kernel: ExperienceKernel, threshold: float = 0.4) -> list:
        """
        匹配目标技能
        
        Returns:
            List of {'skill_name': str, 'score': float, 'action': str, 'reason': str}
        """
        matches = []
        
        for skill in self.skill_index:
            score = self._calculate_score(kernel, skill)
            if score >= threshold:
                matches.append({
                    'skill_name': skill['name'],
                    'score': score,
                    'action': self._suggest_action(score),
                    'reason': self._explain_match(kernel, skill, score)
                })
        
        # 按分数排序
        matches.sort(key=lambda x: -x['score'])
        return matches
    
    def _calculate_score(self, kernel: ExperienceKernel, skill: dict) -> float:
        """计算匹配分数（简化版）"""
        score = 0.0
        
        # Domain匹配 (权重 0.4)
        skill_domain = skill.get('domain', 'general')
        if kernel.domain == skill_domain:
            score += 0.4
        elif skill_domain == 'general' or kernel.domain == 'general':
            score += 0.3  # general domain 给予较高基础分
        
        # Tags重叠 (权重 0.3)
        skill_tags = set(skill.get('tags', []))
        kernel_tags = set(kernel.tags)
        if skill_tags and kernel_tags:
            overlap = len(skill_tags & kernel_tags)
            score += 0.3 * (overlap / len(skill_tags))
        
        # 优先级加成 (P0/P1优先)
        if kernel.priority == 'P0':
            score += 0.2  # P0优先级给予更高权重
        elif kernel.priority == 'P1':
            score += 0.1
        
        return min(score, 1.0)
    
    def _suggest_action(self, score: float) -> str:
        """根据分数建议动作"""
        if score >= 0.7:
            return 'APPEND'
        elif score >= 0.5:
            return 'INSERT'
        else:
            return 'APPEND'
    
    def _explain_match(self, kernel: ExperienceKernel, skill: dict, score: float) -> str:
        """解释匹配原因"""
        reasons = []
        
        if kernel.domain == skill.get('domain'):
            reasons.append(f"Domain匹配({kernel.domain})")
        
        skill_tags = set(skill.get('tags', []))
        kernel_tags = set(kernel.tags)
        overlap = skill_tags & kernel_tags
        if overlap:
            reasons.append(f"Tags重叠({', '.join(list(overlap)[:2])})")
        
        if kernel.priority in ['P0', 'P1']:
            reasons.append(f"高优先级({kernel.priority})")
        
        return ' + '.join(reasons) if reasons else '一般相关'


def print_kernel_summary(kernel: ExperienceKernel):
    """打印经验核摘要"""
    print("\n📋 经验核摘要")
    print(f"   来源: {kernel.source_skill}")
    print(f"   领域: {kernel.domain}")
    print(f"   标签: {kernel.tags}")
    print(f"   优先级: {kernel.priority}")
    print(f"   摘要: {kernel.solution[:100]}...")


def print_matches_table(matches: list):
    """打印匹配结果表格"""
    print("\n🎯 匹配到 {} 个相关技能:".format(len(matches)))
    print("   ┌────┬─────────────────────┬────────┬────────┐")
    print("   │ 序号 │ 技能名称            │ 匹配分 │ 动作   │")
    print("   ├────┼─────────────────────┼────────┼────────┤")
    
    for i, match in enumerate(matches, 1):
        skill_name = match['skill_name'].ljust(19)
        score = f"{match['score']:.2f}".rjust(6)
        action = match['action'].ljust(6)
        print(f"   │ {i:2d} │ {skill_name} │ {score} │ {action} │")
    
    print("   └────┴─────────────────────┴────────┴────────┘")


def main():
    parser = argparse.ArgumentParser(description='跨技能传播原型')
    parser.add_argument('--propagate', required=True, help='LRN编号，如 LRN-088')
    parser.add_argument('--dry-run', action='store_true', help='预览模式，不执行实际传播')
    parser.add_argument('--review', action='store_true', help='审查模式，需要人工确认')
    parser.add_argument('--auto', action='store_true', help='自动模式，直接执行')
    
    args = parser.parse_args()
    
    # 路径配置
    learnings_path = r'D:\XiaoYue_Workspace\.learnings\LEARNINGS.md'
    domain_map_path = r'C:\Users\Field\.stepfun\skills\capability-evolver\config\domain_map.yaml'
    skill_index_path = r'D:\XiaoYue_Workspace\.learnings\SKILL_INDEX_v4.1.json'
    
    print(f"\n=== 跨技能传播原型 (MVP) ===")
    print(f"模式: {'DRY-RUN' if args.dry_run else ('REVIEW' if args.review else 'AUTO')}")
    print(f"目标: {args.propagate}\n")
    
    # Step 1: 提取经验核
    print("Step 1: 提取经验核...")
    extractor = ExperienceExtractor(learnings_path)
    kernel = extractor.extract(args.propagate)
    
    if not kernel:
        print(f"❌ 未找到 {args.propagate}")
        return 1
    
    print(f"✓ 经验核提取成功")
    print_kernel_summary(kernel)
    
    # Step 2: 匹配目标技能
    print("\nStep 2: 匹配目标技能...")
    matcher = SimpleMatcher(domain_map_path, skill_index_path)
    matches = matcher.match(kernel, threshold=0.4)
    
    if not matches:
        print("❌ 未找到匹配的技能（阈值≥0.4）")
        return 0
    
    print(f"✓ 匹配完成")
    print_matches_table(matches)
    
    # Step 3: 显示详细信息
    print("\n📄 匹配详情:")
    for i, match in enumerate(matches, 1):
        print(f"\n[{i}] {match['skill_name']}")
        print(f"    匹配分: {match['score']:.2f}")
        print(f"    建议动作: {match['action']}")
        print(f"    匹配原因: {match['reason']}")
    
    # Step 4: 执行传播（模拟）
    if args.dry_run:
        print("\n✅ DRY-RUN 模式，预览完成，未执行实际传播")
        return 0
    
    if args.review:
        print("\n请选择操作:")
        print("   [a] 全部应用")
        print("   [c] 取消")
        print("   [1-{}] 查看单个技能详情".format(len(matches)))
        
        choice = input("\n> ").strip().lower()
        
        if choice == 'c':
            print("❌ 已取消")
            return 0
        elif choice == 'a':
            print("\n✅ 模拟传播完成（实际执行需要L3模块）")
            print(f"   成功: {len(matches)}/{len(matches)}")
            print(f"   跳过: 0")
            print(f"   失败: 0")
            return 0
        else:
            print("❌ 无效选择")
            return 1
    
    if args.auto:
        print("\n✅ 模拟传播完成（实际执行需要L3模块）")
        print(f"   成功: {len(matches)}/{len(matches)}")
        return 0
    
    return 0


if __name__ == '__main__':
    sys.exit(main())
