#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
L1 经验提取器 (Experience Extractor)
从 LRN 中提取结构化经验核（ExperienceKernel）
"""

import re
import os
from datetime import datetime
from typing import Optional, Dict, List
from dataclasses import dataclass, asdict
import json

@dataclass
class ExperienceKernel:
    """经验核数据结构"""
    lrn_id: str                    # LRN-088
    source_skill: str              # user-preferences
    domain: str                    # workflow
    tags: List[str]                # ["启动序列", "防幻觉"]
    priority: str                  # P0/P1/P2
    problem: str                   # 问题描述
    solution: str                  # 解决方案
    pattern_key: Optional[str]     # 可选的模式标识
    created_at: str                # ISO 8601 时间戳
    category: str                  # best_practice/correction/...
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return asdict(self)
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False, indent=2)
    
    def to_markdown(self) -> str:
        """转换为Markdown格式，用于插入目标技能"""
        md = f"""
### 经验引用: {self.lrn_id}

> **来源**: {self.source_skill}  
> **领域**: {self.domain}  
> **优先级**: {self.priority}  
> **分类**: {self.category}

**问题**:
{self.problem}

**解决方案**:
{self.solution}

**相关标签**: {', '.join(self.tags)}
"""
        if self.pattern_key:
            md += f"\n**模式标识**: `{self.pattern_key}`\n"
        
        return md


class ExperienceExtractor:
    """经验提取器"""
    
    def __init__(self, learnings_path: str):
        """
        初始化提取器
        
        Args:
            learnings_path: LEARNINGS.md 文件路径
        """
        self.learnings_path = learnings_path
        self.cache = {}  # 简单的内存缓存
        self.cache_ttl = 3600  # 1小时
    
    def extract(self, lrn_id: str, use_cache: bool = True) -> Optional[ExperienceKernel]:
        """
        提取经验核
        
        Args:
            lrn_id: LRN编号，如 "LRN-088"
            use_cache: 是否使用缓存
        
        Returns:
            ExperienceKernel对象，如果未找到则返回None
        """
        # 检查缓存
        if use_cache and lrn_id in self.cache:
            cached_kernel, cached_time = self.cache[lrn_id]
            if (datetime.now() - cached_time).seconds < self.cache_ttl:
                return cached_kernel
        
        # 读取LEARNINGS.md
        if not os.path.exists(self.learnings_path):
            raise FileNotFoundError(f"LEARNINGS.md not found: {self.learnings_path}")
        
        with open(self.learnings_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # 定位LRN条目
        lrn_entry = self._locate_lrn_entry(content, lrn_id)
        if not lrn_entry:
            return None
        
        # 解析经验核
        kernel = self._parse_lrn_entry(lrn_entry, lrn_id)
        
        # 缓存
        if use_cache:
            self.cache[lrn_id] = (kernel, datetime.now())
        
        return kernel
    
    def _locate_lrn_entry(self, content: str, lrn_id: str) -> Optional[str]:
        """
        定位LRN条目
        
        Args:
            content: LEARNINGS.md完整内容
            lrn_id: LRN编号
        
        Returns:
            LRN条目内容，如果未找到则返回None
        """
        # 匹配LRN条目（从## LRN-XXX开始，到下一个##或文件结尾）
        pattern = rf'## ({re.escape(lrn_id)}) \[(\d{{4}}-\d{{2}}-\d{{2}})\] (.+?)(?=\n## |\Z)'
        match = re.search(pattern, content, re.DOTALL)
        
        if not match:
            return None
        
        return match.group(0)
    
    def _parse_lrn_entry(self, entry: str, lrn_id: str) -> ExperienceKernel:
        """
        解析LRN条目
        
        Args:
            entry: LRN条目内容
            lrn_id: LRN编号
        
        Returns:
            ExperienceKernel对象
        """
        # 提取标题和日期
        title_match = re.search(rf'## {re.escape(lrn_id)} \[(\d{{4}}-\d{{2}}-\d{{2}})\] (.+)', entry)
        date = title_match.group(1) if title_match else datetime.now().strftime('%Y-%m-%d')
        title = title_match.group(2).strip() if title_match else ""
        
        # 提取Category
        category_match = re.search(r'-\s*\*\*Category\*\*:\s*`(\w+)`', entry)
        category = category_match.group(1) if category_match else 'unknown'
        
        # 提取Priority
        priority_match = re.search(r'-\s*\*\*Priority\*\*:\s*(P\d)', entry)
        priority = priority_match.group(1) if priority_match else 'P2'
        
        # 提取Pattern-Key（如果有）
        pattern_key = None
        pattern_match = re.search(r'-\s*\*\*Pattern-Key\*\*:\s*`([^`]+)`', entry)
        if pattern_match:
            pattern_key = pattern_match.group(1)
        
        # 提取Learning内容（作为solution）
        learning_match = re.search(r'-\s*\*\*Learning\*\*:\s*(.+?)(?=\n-\s*\*\*|\Z)', entry, re.DOTALL)
        solution = learning_match.group(1).strip() if learning_match else title
        
        # 提取问题描述（如果有"为什么重要"或"问题"章节）
        problem = ""
        problem_patterns = [
            r'\*\*为什么重要\*\*:\s*(.+?)(?=\n\*\*|\Z)',
            r'\*\*问题\*\*:\s*(.+?)(?=\n\*\*|\Z)',
            r'\*\*背景\*\*:\s*(.+?)(?=\n\*\*|\Z)'
        ]
        for pattern in problem_patterns:
            match = re.search(pattern, entry, re.DOTALL)
            if match:
                problem = match.group(1).strip()
                break
        
        if not problem:
            problem = f"触发学习记录 {lrn_id} 的问题场景"
        
        # 推断source_skill和domain
        source_skill = self._infer_source_skill(entry, title)
        domain = self._infer_domain(entry, category)
        
        # 提取tags
        tags = self._extract_tags(entry, title, category)
        
        return ExperienceKernel(
            lrn_id=lrn_id,
            source_skill=source_skill,
            domain=domain,
            tags=tags,
            priority=priority,
            problem=problem,
            solution=solution,
            pattern_key=pattern_key,
            created_at=f"{date}T00:00:00Z",
            category=category
        )
    
    def _infer_source_skill(self, entry: str, title: str) -> str:
        """推断来源技能"""
        # 常见技能名称模式
        skill_patterns = [
            r'user-preferences',
            r'capability-evolver',
            r'self-improvement',
            r'skill-workshop',
            r'proactive-agent',
            r'planning-with-files'
        ]
        
        for pattern in skill_patterns:
            if re.search(pattern, entry, re.IGNORECASE) or re.search(pattern, title, re.IGNORECASE):
                return pattern
        
        return 'general'
    
    def _infer_domain(self, entry: str, category: str) -> str:
        """推断领域"""
        # 基于category映射
        category_domain_map = {
            'best_practice': 'general',
            'correction': 'automation',
            'project_milestone': 'automation',
            'architecture_insight': 'meta',
            'performance': 'automation'
        }
        
        if category in category_domain_map:
            return category_domain_map[category]
        
        # 基于关键词推断
        if re.search(r'workflow|工作流|自动化', entry, re.IGNORECASE):
            return 'workflow'
        elif re.search(r'document|文档|报告', entry, re.IGNORECASE):
            return 'document'
        elif re.search(r'search|搜索|检索', entry, re.IGNORECASE):
            return 'search'
        
        return 'general'
    
    def _extract_tags(self, entry: str, title: str, category: str) -> List[str]:
        """提取标签"""
        tags = []
        
        # 从标题提取关键词
        title_keywords = re.findall(r'[\u4e00-\u9fa5]{2,}|[a-zA-Z]{3,}', title)
        tags.extend(title_keywords[:3])  # 最多3个
        
        # 添加category作为tag
        tags.append(category)
        
        # 去重
        tags = list(dict.fromkeys(tags))
        
        return tags


# 示例用法
if __name__ == '__main__':
    learnings_path = r'D:\XiaoYue_Workspace\.learnings\LEARNINGS.md'
    extractor = ExperienceExtractor(learnings_path)
    
    # 提取LRN-088
    kernel = extractor.extract('LRN-088')
    
    if kernel:
        print("=== 经验核提取成功 ===")
        print(kernel.to_json())
        print("\n=== Markdown格式 ===")
        print(kernel.to_markdown())
    else:
        print("未找到LRN-088")
