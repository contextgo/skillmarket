const { printPropagatable } = require('./src/propagate');

console.log('测试传播功能集成...\n');
printPropagatable();
