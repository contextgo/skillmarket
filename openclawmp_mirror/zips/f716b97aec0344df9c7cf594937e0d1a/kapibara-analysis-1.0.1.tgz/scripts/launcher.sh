#!/bin/bash
# 卡皮巴拉分析技能调度器
# 由 OpenClaw skill command 通过 exec 工具调用
# 用法由 skill command 的 command-arg-mode 决定

SKILL_DIR="/root/.openclaw/agents/redquinn/workspace/skills/kapibara-analysis/scripts"
ENV_FILE="/root/.openclaw/agents/redquinn/workspace/.env"

# 加载环境变量（问财API Key）
if [ -f "$ENV_FILE" ]; then
    export IWENCAI_API_KEY=$(grep IWENCAI_API_KEY "$ENV_FILE" | cut -d'=' -f2)
fi

# 如果没有，从 ~/.bashrc 加载
if [ -z "$IWENCAI_API_KEY" ]; then
    export IWENCAI_API_KEY=$(grep -m1 "IWENCAI_API_KEY" ~/.bashrc | cut -d'=' -f2- | tr -d '"' | tr -d "'")
fi

# 执行分析脚本，传递所有参数
exec python3 "$SKILL_DIR/run_analysis.py" "$@"
