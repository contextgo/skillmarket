#!/usr/bin/env python3
"""
卡皮巴拉股票分析 - 命令行入口
用法: python3 run_analysis.py <股票名称或代码> [股票名称或代码...]

示例:
  python3 run_analysis.py 平安银行
  python3 run_analysis.py 比亚迪 宁德时代 中国平安
"""
import sys
import json
import urllib.request
import os
import time

# ============ 加载系统环境变量（兼容非登录Shell）============
def _load_env():
    """从 /etc/environment 和 /etc/profile.d/ 加载环境变量，兼容exec调用的非登录Shell"""
    for _path in ["/etc/environment", "/etc/profile.d/wencai-env.sh"]:
        try:
            with open(_path) as f:
                for _line in f:
                    _line = _line.strip()
                    if _line and not _line.startswith('#') and '=' in _line:
                        _parts = _line.split('=', 1)
                        _key = _parts[0].strip()
                        _val = _parts[1].strip().strip('"').strip("'")
                        if _key not in os.environ:
                            os.environ[_key] = _val
        except Exception:
            pass

_load_env()

# ============ 问财 API 配置 ============
IWENCAI_API_KEY = os.environ.get("IWENCAI_API_KEY", "")
IWENCAI_BASE_URL = os.environ.get("IWENCAI_BASE_URL", "https://openapi.iwencai.com")

def wencai_query(query, limit=5):
    """调用问财 API"""
    if not IWENCAI_API_KEY:
        return {"error": "IWENCAI_API_KEY not set"}
    url = f"{IWENCAI_BASE_URL}/v1/query2data"
    headers = {
        "Authorization": f"Bearer {IWENCAI_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {"query": query, "page": "1", "limit": str(limit), "is_cache": "1"}
    try:
        data = json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(url, data=data, headers=headers, method="POST")
        with urllib.request.urlopen(req, timeout=15) as resp:
            result = json.loads(resp.read().decode("utf-8"))
            return result.get("datas", [])
    except Exception as e:
        return [{"error": str(e)}]

def get_price(code_or_name):
    """获取最新价格"""
    data = wencai_query(f"{code_or_name}最新价格")
    if data and "error" not in data[0]:
        return data[0]
    return {}

def get_financial(code_or_name):
    """获取财务数据"""
    roe_data = wencai_query(f"{code_or_name}ROE 资产负债率")
    pe_data = wencai_query(f"{code_or_name}市盈率 市净率")
    profit_data = wencai_query(f"{code_or_name}营业收入 净利润")
    cash_data = wencai_query(f"{code_or_name}经营性现金流")
    eps_data = wencai_query(f"{code_or_name}每股收益")

    result = {}
    for d in [roe_data, pe_data, profit_data, cash_data, eps_data]:
        if d and "error" not in d[0]:
            result.update(d[0])
    return result

def get_market(code_or_name):
    """获取市场数据"""
    funds_data = wencai_query(f"{code_or_name}主力净流入")
    macd_data = wencai_query(f"{code_or_name}MACD RSI")
    return {**(funds_data[0] if funds_data and "error" not in funds_data[0] else {}),
            **(macd_data[0] if macd_data and "error" not in macd_data[0] else {})}

def kelly_formula(entry, stop, win_rate=0.4, odds=1.0):
    """凯利公式"""
    b = odds
    p = win_rate
    q = 1 - p
    f_star = (b * p - q) / b
    return max(0, f_star)

def position_size(account, risk_pct, entry, stop):
    """头寸公式"""
    risk_amount = account * risk_pct
    risk_per_share = abs(entry - stop)
    if risk_per_share == 0:
        return 0
    return int(risk_amount / risk_per_share)

def analyze_stock(code_or_name, account=500000):
    """分析单只股票"""
    print(f"\n{'='*60}")
    print(f"  卡皮巴拉分析 · {code_or_name}")
    print(f"{'='*60}")

    price_data = get_price(code_or_name)
    if not price_data or "error" in price_data:
        print(f"❌ 无法获取价格数据: {code_or_name}")
        return None

    code = price_data.get("股票代码", code_or_name)
    price = price_data.get("收盘价[20260417]",
               price_data.get("最新价", 0))
    name = price_data.get("股票简称", code_or_name)

    print(f"📊 代码: {code} | 价格: ¥{price}")

    # 并行获取
    financial = get_financial(code_or_name)
    market = get_market(code_or_name)

    pe = financial.get("最新市盈率ttm", 0)
    pb = financial.get("最新市净率", 0)
    roe = financial.get("净资产收益率[20251231]", financial.get("净资产收益率[20250930]", 0))
    debt = financial.get("资产负债率[20251231]", financial.get("资产负债率[20250930]", 0))
    revenue = financial.get("营业收入", 0)
    profit = financial.get("归母净利润", 0)
    fund_flow = market.get("主力资金流向", 0)
    rsi = market.get("rsi[20260417]", market.get("rsi", 0))
    macd_val = market.get("macd[20260417]", market.get("macd", 0))

    # 打印数据
    print(f"\n📈 估值: PE={pe:.1f} PB={pb:.2f}")
    print(f"💰 财务: ROE={roe:.2f}% 负债率={debt:.1f}%")
    print(f"💵 收入: 营收={revenue/1e8:.1f}亿 净利={profit/1e8:.2f}亿")
    print(f"📉 资金: 主力净流入={fund_flow/1e8:.2f}亿 RSI={rsi:.1f} MACD={macd_val:.3f}")

    # 判断逻辑
    issues = []
    if pe > 100:
        issues.append(f"PE={pe:.0f}倍严重偏高")
    if rsi > 80:
        issues.append(f"RSI={rsi:.0f}超买")
    if fund_flow < -1e8:
        issues.append(f"主力净流出{-fund_flow/1e8:.1f}亿")

    # 评分
    score = 50
    if pe > 150: score -= 25
    elif pe > 60: score -= 15
    elif pe > 30: score -= 5
    if roe < 5: score -= 15
    elif roe < 10: score -= 5
    if rsi > 85: score -= 20
    elif rsi > 75: score -= 10
    if fund_flow > 0: score += 10
    if debt > 70: score -= 10
    score = max(0, min(100, score))

    # 仓位
    stop_price = price * 0.95
    win_rate = 0.4
    b = 0.08 / 0.05  # 简单盈亏比
    kelly = kelly_formula(price, stop_price, win_rate, b)
    lots = position_size(account, 0.02, price, stop_price)

    verdict = "✅ 可参与" if score >= 55 and kelly > 0 else "❌ 不参与"

    print(f"\n🏆 综合评分: {score}/100")
    print(f"📋 问题: {', '.join(issues) if issues else '无明显问题'}")
    print(f"💼 凯利仓位: {kelly*100:.1f}% → {lots}股")
    print(f"🛡️ 止损: ¥{stop_price:.2f}")
    print(f"⛔ 结论: {verdict}")

    return {
        "name": name,
        "code": code,
        "price": price,
        "score": score,
        "kelly_pct": kelly * 100,
        "lots": lots,
        "stop": stop_price,
        "verdict": verdict,
        "issues": issues,
        "data": {
            "pe": pe, "pb": pb, "roe": roe, "debt": debt,
            "revenue": revenue, "profit": profit,
            "fund_flow": fund_flow, "rsi": rsi, "macd": macd_val
        }
    }

def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(1)

    stocks = sys.argv[1:]
    results = []
    for s in stocks:
        r = analyze_stock(s)
        if r:
            results.append(r)
        time.sleep(0.5)

    if results:
        print(f"\n{'='*60}")
        print("  📋 汇总")
        print(f"{'='*60}")
        print(f"{'股票':<12} {'代码':<12} {'评分':<6} {'凯利仓位':<8} {'结论'}")
        print("-" * 60)
        for r in results:
            print(f"{r['name']:<10} {r['code']:<12} {r['score']}/100 {r['kelly_pct']:.1f}%    {r['verdict']}")

        # 输出 JSON 供后续处理
        print(f"\n[JSON_OUTPUT]")
        print(json.dumps(results, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
