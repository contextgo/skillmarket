# ClickHouse Analytics Pipeline

## Table Engine Selection

| Engine | Use Case | Feature |
|--------|----------|---------|
| MergeTree | Base | Ordered, partitioned |
| ReplicatedMergeTree | Cluster | Auto replication |
| ReplacingMergeTree | Dedup | Keep latest version |
| AggregatingMergeTree | Pre-aggregate | Materialized results |

## Data Import

### Real-time: Kafka Engine
Use materialized view to auto-consume from Kafka topics.

### Batch: INSERT FROM FILE
Use clickhouse-client for bulk CSV import.

## Query Optimization
- ORDER BY matching query patterns (most important)
- Partition pruning with WHERE on partition key
- Materialized views for pre-computation (10-100x speedup)
- Sampling with SAMPLE 0.1 for quick estimates

## Monitoring
- Query latency P99 < 1s
- Write throughput > 100MB/s
- Disk usage < 80%
- Replication lag < 10s