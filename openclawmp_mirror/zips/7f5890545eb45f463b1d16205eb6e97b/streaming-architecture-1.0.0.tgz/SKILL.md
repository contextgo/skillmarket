---
name: streaming-architecture
description: "Streaming data architecture patterns - real-time event processing with Kafka, Redis Streams, and server-sent events"
version: 1.0.0
tags: ["streaming", "real-time", "kafka", "redis", "architecture"]
---

# Streaming Architecture Guide

Streaming architecture processes data in real-time as events arrive, enabling low-latency responses and continuous data pipelines.

## Core Patterns

### 1. Event Sourcing
Store every state change as an immutable event:
```
OrderCreated → PaymentProcessed → OrderShipped → OrderDelivered
```

### 2. CQRS (Command Query Responsibility Segregation)
Separate write and read models:
- **Write side**: Append-only event log
- **Read side**: Materialized views (projections)

### 3. Stream Processing
Process events as they flow through the pipeline:
- **Filtering**: Drop irrelevant events
- **Enrichment**: Join with reference data
- **Aggregation**: Window-based computations
- **Routing**: Send to different sinks

## Kafka Producer/Consumer

```python
# Producer
from kafka import KafkaProducer
producer = KafkaProducer(bootstrap_servers='localhost:9092')
producer.send('orders', key=b'order-1', value=json.dumps(order))

# Consumer
from kafka import KafkaConsumer
consumer = KafkaConsumer('orders', bootstrap_servers='localhost:9092')
for message in consumer:
    process_event(json.loads(message.value))
```

## Redis Streams

```python
import redis
r = redis.Redis()

# Produce
r.xadd('events', {'type': 'click', 'user': '123'})

# Consume (consumer group)
r.xgroup_create('events', 'analytics', id='0', mkstream=True)
events = r.xreadgroup('analytics', 'worker-1', {'events': '>'}, count=10)
```

## Server-Sent Events (SSE)

```python
# Flask SSE endpoint
@app.route('/stream')
def stream():
    def generate():
        for event in event_source:
            yield f"data: {json.dumps(event)}\n\n"
    return Response(generate(), mimetype='text/event-stream')
```

## Best Practices

- Use consumer groups for parallel processing
- Implement dead letter queues for failed events
- Design for idempotency (events may replay)
- Monitor consumer lag (production vs consumption rate)
- Use schema registry for event validation
