# ESLint + Prettier Code Quality Pipeline

## Setup
```bash
npm install -D eslint prettier eslint-config-prettier eslint-plugin-prettier
```

## Configuration Strategy

### ESLint: Code Quality
- Catch bugs: no-unused-vars, no-undef, eqeqeq
- Best practices: no-var, prefer-const, no-console
- React: react-hooks/exhaustive-deps, react/prop-types
- Import: import/order, no-duplicates

### Prettier: Code Formatting
- Semi, singleQuote, tabWidth
- Trailing comma, bracketSpacing
- Print width: 80 or 100
- Line ending: lf

### Integration
```json
// .eslintrc.json
{
  "extends": ["eslint:recommended", "prettier"],
  "plugins": ["prettier"],
  "rules": { "prettier/prettier": "error" }
}
```

## CI Pipeline
```
1. eslint --max-warnings=0 .
2. prettier --check .
3. tsc --noEmit (if TypeScript)
4. Pre-commit: lint-staged + husky
```

## Custom Rules
- Business-specific naming conventions
- Import order enforcement
- API response type checking
- Test coverage requirements

## Performance
- Use flat config (eslint.config.js) for faster startup
- Cache eslint results (.eslintcache)
- Parallel with --cache --cache-strategy content
- Ignore build output directories
