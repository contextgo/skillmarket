---
name: news-to-asset-pipeline
description: "Convert breaking news and market signals into publishable knowledge assets automatically"
version: 1.0.0
tags: ["content", "automation", "publishing", "pipeline"]
---

# News-to-Asset Pipeline

A systematic pipeline for converting real-time news and market signals into structured, publishable knowledge assets for OpenClaw marketplace.

## Pipeline Overview

```
News Sources → Signal Extraction → Asset Generation → Quality Check → Publish
     │                │                  │                │              │
  RSS/API          Pattern Match      Template Fill     Ethics Review    Marketplace
  Web Fetch        Confidence Score    Structured MD    Duplicate Check   API Call
```

## Step 1: News Collection

### Multi-Source Aggregation
```python
NEWS_SOURCES = {
    "crypto": ["CoinDesk", "CryptoSlate", "The Block", "Decrypt"],
    "macro": ["Reuters", "Bloomberg", "CNBC", "Financial Times"],
    "geopolitical": ["BBC World", "Al Jazeera", "AP News"],
    "regulatory": ["SEC.gov", "CFTC.gov", "Federal Reserve"],
    "tech": ["TechCrunch", "Ars Technica", "Wired"],
}
```

### Collection Methods (Priority Order)
1. **RSS Feeds** — Free, reliable, structured
2. **Exa API** — Semantic search, good for niche topics
3. **web_fetch** — Direct page scraping, fallback
4. **web_search** — Last resort, rate-limited

## Step 2: Signal Extraction

### Pattern Matching
```
For each news article:
1. Extract: entities (people, orgs, countries), numbers ($ amounts, %), dates
2. Match against: known market categories (crypto, oil, rates, geopolitics)
3. Score confidence: how strong is the signal? (0-100%)
4. Classify impact: bullish / bearish / neutral
5. Assign urgency: P0 (immediate) / P1 (this week) / P2 (monitoring)
```

### Signal Categories
| Category | Example Signal | Asset Type |
|----------|---------------|------------|
| Rate Decision | FOMC meeting tomorrow | Experience |
| Geopolitical | Hormuz closure, oil >$100 | Experience |
| Regulatory | SEC-CFTC MOU signed | Experience |
| Market Structure | BlackRock ETHB launch | Experience |
| Trade Policy | Section 301 investigations | Experience |
| Technical | BTC breaks key resistance | Experience |
| New Product | Exchange listing, new ETF | Experience |

## Step 3: Asset Generation

### Template System

Use structured templates that ensure consistent quality:

```markdown
# [Title]: [Signal Summary]

## Background
[Context from news: what happened, when, key facts]

## Key Metrics
[Table of relevant numbers, before/after comparison]

## Analysis
[Why this matters, cause-effect chain, implications]

## Trading Signals
[Bullish signals with conditions]
[Bearish signals with conditions]

## Agent Integration
[Monitoring checklist, cron schedule, data sources]

## Lessons Learned
[Actionable takeaways, historical parallels]
```

### Naming Convention
```
Format: {topic}-{specific-subject}
Examples:
- fomc-rate-decision-agent-playbook
- strait-of-hormuz-closure-crypto-impact
- sec-cftc-joint-regulation-crypto
- trade-war-section-301-crypto
```

## Step 4: Quality Check

### Automated Checks
```
[ ] File exists and is non-empty (>500 chars)
[ ] Has proper title (# heading)
[ ] Contains at least one data table
[ ] No hardcoded API keys or secrets
[ ] No duplicate of existing published asset
[ ] Tags are appropriate
[ ] No ethics violations (scraping instructions, etc.)
```

### Ethics Review
- ❌ No "how to hack" or "how to circumvent" content
- ❌ No scraping instructions that violate ToS
- ❌ No content promoting illegal activities
- ✅ Analysis and education focused
- ✅ Trading frameworks (not financial advice)
- ✅ Regulatory and compliance guidance

### Duplicate Detection
Before publishing, check against existing assets:
```bash
openclawmp search "{asset-name}" 
# If similar asset exists, skip or differentiate
```

## Step 5: Publishing

### Packaging
```bash
# Always use zip format (tar.gz has parsing issues on server)
cd /path/to/asset/
zip -r /tmp/{asset-name}.zip . -x "*.git*" -x "node_modules/*" -x "*.DS_Store"
```

### Publishing
```bash
# Via API (most reliable)
curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
  -H "Authorization: Bearer ${OPENCLAWMP_TOKEN}" \
  -H "X-Device-ID: ${DEVICE_ID}" \
  -F "package=@/tmp/{asset-name}.zip" \
  -F 'metadata={"name":"{asset-name}","type":"experience","version":"1.0.0","description":"{one-line description}","tags":["{tag1}","{tag2}"]}'
```

## Batch Processing

### Optimal Batch Size
- **6-9 assets per batch** — balances API rate limits with throughput
- **Mix of types** — Experiences (from news) + Skills (from capabilities)
- **Stagger timing** — Don't publish all at once, space 30-60s apart

### Error Handling
```
On publish failure:
- duplicate_asset: Skip (already published)
- ethics_violation: Review and fix content
- auth_error: Check API key/device ID
- server_error: Retry after 60s (exponential backoff)
- missing_package: Check zip file integrity
```

## Performance Metrics

### Track These KPIs
| Metric | Target | Current |
|--------|--------|---------|
| Assets per batch | 6-9 | 9 |
| Success rate | >80% | 100% (recent) |
| Time per asset | <5 min | ~2 min |
| News-to-asset latency | <4 hours | ~3 hours |
| Duplicate rate | <20% | ~25% |

## Scaling Strategy

1. **Increase news sources** — Add more RSS feeds, APIs
2. **Improve signal extraction** — Better NLP pattern matching
3. **Automate quality checks** — Reduce manual review
4. **Batch optimization** — Find optimal batch size/timing
5. **Content diversification** — Skills, plugins, triggers (not just experiences)
