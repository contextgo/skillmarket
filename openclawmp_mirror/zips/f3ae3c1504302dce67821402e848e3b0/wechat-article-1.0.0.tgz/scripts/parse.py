#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
WeChat Article Parser - Claude Code Skill
解析微信公众号文章的全文内容（支持动态加载内容）
"""

import os
import re
import json
import logging
import argparse
import subprocess
import sys
from datetime import datetime
from typing import Optional, Dict, List

import requests
from bs4 import BeautifulSoup

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# 请求头，模拟移动端访问
HEADERS = {
    'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Connection': 'keep-alive',
}


def install_system_dependencies() -> bool:
    """安装 Playwright 所需的系统依赖（Linux/Debian）"""
    logger.info("正在安装系统依赖...")
    
    packages = [
        'libnspr4', 'libnss3', 'libatk1.0-0', 'libatk-bridge2.0-0',
        'libcups2', 'libdrm2', 'libdbus-1-3', 'libxkbcommon0',
        'libxcomposite1', 'libxdamage1', 'libxfixes3', 'libxrandr2',
        'libgbm1', 'libasound2', 'libpango-1.0-0', 'libcairo2', 'libatspi2.0-0',
    ]
    
    try:
        is_root = os.geteuid() == 0 if hasattr(os, 'geteuid') else False
        
        if is_root:
            cmd = ['apt-get', 'install', '-y'] + packages
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
            if result.returncode == 0:
                logger.info("✓ 系统依赖安装成功")
                return True
            return False
        else:
            cmd = ['sudo', 'apt-get', 'install', '-y'] + packages
            try:
                result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)
                if result.returncode == 0:
                    logger.info("✓ 系统依赖安装成功")
                    return True
            except FileNotFoundError:
                pass
    except Exception as e:
        logger.warning(f"安装系统依赖时出错: {e}")
    return False


def check_and_install_dependencies() -> bool:
    """检测并自动安装 Playwright 依赖"""
    try:
        from playwright.sync_api import sync_playwright
        logger.info("✓ Playwright 已安装")
        
        try:
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                browser.close()
            logger.info("✓ Playwright 浏览器可用")
            return True
        except Exception as e:
            error_msg = str(e)
            if "Host system is missing dependencies" in error_msg or "libnspr4" in error_msg:
                logger.warning("缺少系统依赖，正在尝试安装...")
                if install_system_dependencies():
                    try:
                        with sync_playwright() as p:
                            browser = p.chromium.launch(headless=True)
                            browser.close()
                        logger.info("✓ Playwright 浏览器可用")
                        return True
                    except:
                        pass
            
            logger.info("正在安装 Playwright 浏览器...")
            try:
                result = subprocess.run(
                    [sys.executable, '-m', 'playwright', 'install', 'chromium'],
                    capture_output=True, text=True, timeout=300
                )
                if result.returncode == 0:
                    logger.info("✓ Playwright 浏览器安装成功")
                    try:
                        with sync_playwright() as p:
                            browser = p.chromium.launch(headless=True)
                            browser.close()
                        return True
                    except:
                        if install_system_dependencies():
                            try:
                                with sync_playwright() as p:
                                    browser = p.chromium.launch(headless=True)
                                    browser.close()
                                return True
                            except:
                                pass
                return False
            except:
                return False
    except ImportError:
        logger.warning("Playwright 未安装，尝试自动安装...")
        install_system_dependencies()
        
        try:
            result = subprocess.run(
                [sys.executable, '-m', 'pip', 'install', 'playwright'],
                capture_output=True, text=True, timeout=120
            )
            if result.returncode == 0:
                logger.info("✓ Playwright 安装成功，正在安装浏览器...")
                install_result = subprocess.run(
                    [sys.executable, '-m', 'playwright', 'install', 'chromium'],
                    capture_output=True, text=True, timeout=300
                )
                if install_result.returncode == 0:
                    logger.info("✓ Playwright 浏览器安装成功")
                    try:
                        with sync_playwright() as p:
                            browser = p.chromium.launch(headless=True)
                            browser.close()
                        return True
                    except:
                        if install_system_dependencies():
                            try:
                                with sync_playwright() as p:
                                    browser = p.chromium.launch(headless=True)
                                    browser.close()
                                return True
                            except:
                                pass
        except:
            pass
    return False


class WechatArticleParser:
    """微信公众号文章解析器"""
    
    def __init__(self):
        self.session = requests.Session()
        self.session.headers.update(HEADERS)
    
    def parse_url(self, url: str, use_browser: bool = True) -> Optional[Dict]:
        try:
            if use_browser:
                return self._parse_with_browser(url)
            else:
                return self._parse_with_requests(url)
        except Exception as e:
            logger.error(f"解析失败: {e}")
            if use_browser:
                logger.info("浏览器方式失败，尝试降级到requests方式...")
                return self._parse_with_requests(url)
            return None
    
    def _parse_with_requests(self, url: str) -> Optional[Dict]:
        """使用 requests 解析文章"""
        try:
            logger.info(f"正在请求文章: {url}")
            response = self.session.get(url, timeout=30)
            response.raise_for_status()
            response.encoding = 'utf-8'
            
            soup = BeautifulSoup(response.text, 'html.parser')
            result = {}
            
            og_title = soup.find('meta', property='og:title')
            h1 = soup.find('h1', id='activity-name')
            result['title'] = og_title['content'] if og_title else (h1.get_text(strip=True) if h1 else "")
            
            author_elem = soup.find('meta', property='og:article:author') or \
                         soup.find('a', class_='rich_media_meta rich_media_meta_link rich_media_meta_nickname')
            result['author'] = author_elem['content'] if author_elem and author_elem.get('content') else \
                              (author_elem.get_text(strip=True) if author_elem else "")
            
            og_image = soup.find('meta', property='og:image')
            result['cover'] = og_image['content'] if og_image else ""
            
            og_desc = soup.find('meta', property='og:description')
            result['digest'] = og_desc['content'] if og_desc else ""
            
            content_elem = soup.find('div', id='js_content') or soup.find('div', class_='rich_media_content')
            
            if content_elem:
                for tag in content_elem.find_all(['script', 'style', 'form']):
                    tag.decompose()
                result['content'] = str(content_elem)
                result['text'] = content_elem.get_text(separator='\n', strip=True)
                result['images'] = []
                for img in content_elem.find_all('img'):
                    img_url = img.get('data-src') or img.get('src') or img.get('data-w-src', '')
                    if img_url:
                        result['images'].append(img_url)
            else:
                result['content'] = ""
                result['text'] = "（需要使用浏览器模式获取完整内容）"
                result['images'] = []
            
            return result if result.get('title') else None
        except:
            return None
    
    def _parse_with_browser(self, url: str) -> Optional[Dict]:
        """使用 Playwright 浏览器自动化解析文章"""
        try:
            from playwright.sync_api import sync_playwright
            
            logger.info(f"正在使用浏览器解析文章: {url}")
            
            with sync_playwright() as p:
                browser = p.chromium.launch(headless=True)
                context = browser.new_context(
                    user_agent='Mozilla/5.0 (iPhone; CPU iPhone OS 16_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Mobile/15E148 Safari/604.1',
                    viewport={'width': 390, 'height': 844}
                )
                page = context.new_page()
                
                page.route("**/*", lambda route: route.continue_() if not any(
                    route.request.url.endswith(ext) for ext in ['.png', '.jpg', '.jpeg', '.gif', '.svg', '.ico']
                ) else route.abort())
                
                page.goto(url, wait_until='networkidle', timeout=60000)
                page.wait_for_selector('#js_content, .rich_media_content', timeout=30000)
                
                result = {}
                
                title_elem = page.query_selector('h1#activity-name') or page.query_selector('meta[property="og:title"]')
                if title_elem:
                    if title_elem.get_attribute('property'):
                        result['title'] = title_elem.get_attribute('content') or ""
                    else:
                        result['title'] = title_elem.inner_text() or ""
                else:
                    result['title'] = ""
                
                author_elem = page.query_selector('a.rich_media_meta.rich_media_meta_link.rich_media_meta_nickname') or \
                             page.query_selector('meta[property="og:article:author"]')
                if author_elem:
                    if author_elem.get_attribute('property'):
                        result['author'] = author_elem.get_attribute('content') or ""
                    else:
                        result['author'] = author_elem.inner_text() or ""
                else:
                    result['author'] = ""
                
                cover_elem = page.query_selector('meta[property="og:image"]')
                result['cover'] = cover_elem.get_attribute('content') if cover_elem else ""
                
                desc_elem = page.query_selector('meta[property="og:description"]')
                result['digest'] = desc_elem.get_attribute('content') if desc_elem else ""
                
                content_elem = page.query_selector('#js_content') or page.query_selector('.rich_media_content')
                if content_elem:
                    page.evaluate('''() => {
                        const scripts = document.querySelectorAll('#js_content script, #js_content style, #js_content form');
                        scripts.forEach(el => el.remove());
                    }''')
                    result['content'] = content_elem.inner_html()
                    result['text'] = content_elem.inner_text()
                    result['images'] = []
                    for img in content_elem.query_selector_all('img'):
                        img_url = img.get_attribute('data-src') or img.get_attribute('src') or ""
                        if img_url:
                            result['images'].append(img_url)
                else:
                    result['content'] = ""
                    result['text'] = ""
                    result['images'] = []
                
                browser.close()
                return result if result.get('title') else None
        except:
            return None
    
    def save_article(self, article_data: Dict, output_path: str, format: str = 'txt') -> bool:
        try:
            os.makedirs(os.path.dirname(output_path), exist_ok=True)
            
            if format == 'json':
                with open(output_path, 'w', encoding='utf-8') as f:
                    json.dump(article_data, f, ensure_ascii=False, indent=2)
            elif format == 'html':
                html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <title>{article_data.get('title', '微信公众号文章')}</title>
    <style>
        body {{ font-family: sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; line-height: 1.8; }}
        h1 {{ font-size: 1.5em; }}
        .author {{ color: #666; font-size: 0.9em; margin-bottom: 20px; }}
        .content img {{ max-width: 100%; height: auto; }}
    </style>
</head>
<body>
    <h1>{article_data.get('title', '')}</h1>
    <div class="author">{article_data.get('author', '')}</div>
    <div class="content">{article_data.get('content', '')}</div>
</body>
</html>"""
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(html)
            else:
                with open(output_path, 'w', encoding='utf-8') as f:
                    f.write(f"标题: {article_data.get('title', '')}\n")
                    if article_data.get('author'):
                        f.write(f"作者: {article_data['author']}\n")
                    if article_data.get('digest'):
                        f.write(f"摘要: {article_data['digest']}\n")
                    f.write("\n" + "=" * 50 + "\n\n")
                    f.write(article_data.get('text', article_data.get('content', '')))
            
            logger.info(f"文章已保存到: {output_path}")
            return True
        except Exception as e:
            logger.error(f"保存失败: {e}")
            return False
    
    def print_article(self, article_data: Dict):
        print("\n" + "=" * 60)
        print(f"📌 标题: {article_data.get('title', '未获取到')}")
        if article_data.get('author'):
            print(f"👤 作者: {article_data['author']}")
        if article_data.get('digest'):
            print(f"📝 摘要: {article_data['digest']}")
        print("=" * 60)
        
        text = article_data.get('text', '')
        print(text[:5000])
        if len(text) > 5000:
            print(f"\n... (内容过长，已截断显示前5000字符)")


def resolve_output_path(output_arg: str = None, format: str = 'txt') -> str:
    """解析输出路径，确保文件保存在 generate/ 目录"""
    script_dir = os.path.dirname(os.path.abspath(__file__))
    skill_dir = os.path.dirname(script_dir)
    generate_dir = os.path.join(skill_dir, 'generate')
    
    os.makedirs(generate_dir, exist_ok=True)
    
    if output_arg:
        output_path = output_arg
        if os.path.basename(output_path) == output_path:
            output_path = os.path.join(generate_dir, output_path)
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"article_{timestamp}.{format}"
        output_path = os.path.join(generate_dir, filename)
    
    return output_path


def main():
    parser = argparse.ArgumentParser(description='微信公众号文章解析器')
    parser.add_argument('url', help='微信公众号文章链接')
    parser.add_argument('-o', '--output', help='输出文件名')
    parser.add_argument('-f', '--format', choices=['txt', 'html', 'json'], default='txt')
    parser.add_argument('-v', '--verbose', action='store_true')
    parser.add_argument('--no-browser', action='store_true')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    use_browser = not args.no_browser
    if use_browser:
        logger.info("正在检测依赖...")
        playwright_available = check_and_install_dependencies()
        if not playwright_available:
            logger.warning("自动安装 Playwright 失败，将使用 requests 方式")
            use_browser = False
    
    wechat_parser = WechatArticleParser()
    
    if use_browser:
        logger.info("使用浏览器模式解析（可获取完整内容）...")
    else:
        logger.info("使用快速模式解析...")
    
    article_data = wechat_parser.parse_url(args.url, use_browser=use_browser)
    
    if not article_data:
        print("❌ 文章解析失败，请检查链接是否正确")
        return 1
    
    wechat_parser.print_article(article_data)
    
    output_path = resolve_output_path(args.output, args.format)
    success = wechat_parser.save_article(article_data, output_path, args.format)
    
    return 0 if success else 1


if __name__ == "__main__":
    exit(main())
