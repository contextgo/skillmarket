---
name: wechat-article
description: Parse and extract full content from WeChat public account articles. Returns title, author, digest, and full text content.
homepage: https://github.com/mateolim/ShellProject
metadata: {"clawdbot":{"emoji":"📱","requires":{"bins":["python3"],"env":[]}}}
---

# WeChat Article Parser

Parse and extract full content from WeChat (Weixin) public account articles.

## Parse Article

```bash
python3 {baseDir}/scripts/parse.py "https://mp.weixin.qq.com/s/xxxxx"
```

## Parse and Save

```bash
# Save as JSON (recommended for full data)
python3 {baseDir}/scripts/parse.py "链接" -o article.json -f json

# Save as text
python3 {baseDir}/scripts/parse.py "链接" -o article.txt

# Save as HTML with styling
python3 {baseDir}/scripts/parse.py "链接" -o article.html -f html
```

## Options

- `-o <file>`: Output filename (saved to generate/ directory)
- `-f <format>`: Output format - `txt` (default), `html`, or `json`
- `-v`: Verbose mode - show detailed logs
- `--no-browser`: Use requests mode only (faster but may miss full content)

## Notes

- Uses Playwright headless browser to handle dynamic JavaScript content
- Automatically installs dependencies if missing
- Works on servers without GUI (Debian, Armbian, etc.)
- JSON output includes: title, author, digest, cover, content (HTML), text, images
- Files are saved to `generate/` directory (gitignored)
