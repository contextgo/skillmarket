/**
 * MemoryWriter - 智能记忆写入器
 * 
 * 职责：
 * 1. 自动分类记忆类型（背景/对话/事件/事实/反思/技能）
 * 2. 智能压缩（对话记忆）
 * 3. 冲突检测（事实记忆）
 * 4. 存储到对应层级
 * 5. 更新记忆图谱索引
 */

class MemoryWriter {
  constructor(options = {}) {
    this.storage = options.storage || new LocalJSONStorage();
    this.compressor = new MemoryCompressor();
    this.conflictDetector = new ConflictDetector();
    this.classifier = new MemoryClassifier();
  }

  /**
   * 主入口：写入记忆
   * @param {Object} content - 记忆内容
   * @param {String} type - 记忆类型
   * @param {Object} metadata - 元数据
   */
  async write(content, type, metadata = {}) {
    try {
      console.log(`[MemoryWriter] Writing ${type} memory...`);

      // 1. 分类验证
      if (!this.classifier.isValidType(type)) {
        throw new Error(`Invalid memory type: ${type}`);
      }

      // 2. 智能压缩（仅对话记忆）
      let processedContent = content;
      if (type === 'conversation') {
        processedContent = await this.compressor.compress(content);
        console.log(`[MemoryWriter] Compressed: ${content.length} → ${processedContent.length} chars`);
      }

      // 3. 冲突检测（仅事实记忆）
      let conflicts = [];
      if (type === 'fact') {
        conflicts = await this.conflictDetector.detect(processedContent);
        if (conflicts.length > 0) {
          console.log(`[MemoryWriter] Found ${conflicts.length} conflicts, resolving...`);
          processedContent = await this.conflictDetector.resolve(processedContent, conflicts);
        }
      }

      // 4. 构建记录
      const record = {
        id: this.generateId(type),
        type,
        content: processedContent,
        metadata: {
          ...metadata,
          created_at: new Date().toISOString(),
          source: metadata.source || 'user',
          confidence: metadata.confidence || 1.0
        },
        version: 1
      };

      // 5. 存储
      await this.storage.write(type, record);

      // 6. 索引更新（占位）
      await this.updateIndex(record);

      console.log(`[MemoryWriter] ✅ Successfully wrote ${type} memory (id: ${record.id})`);
      return record;

    } catch (error) {
      console.error(`[MemoryWriter] ❌ Write failed:`, error);
      throw error;
    }
  }

  /**
   * 批量写入（用于导入历史数据）
   */
  async batchWrite(records) {
    const results = [];
    for (const record of records) {
      try {
        const result = await this.write(
          record.content,
          record.type,
          record.metadata
        );
        results.push({ success: true, record: result });
      } catch (error) {
        results.push({ success: false, error, record });
      }
    }
    return results;
  }

  generateId(type) {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 8);
    return `${type}_${timestamp}_${random}`;
  }

  async updateIndex(record) {
    // TODO: 未来实现记忆图谱索引
    console.log(`[MemoryWriter] Index updated for ${record.id}`);
  }
}

/**
 * MemoryRetriever - 多跳记忆检索器
 * 
 * 职责：
 * 1. 问题分类（决定检索哪些记忆层）
 * 2. 分层检索
 * 3. 去重与排序
 * 4. 多跳推理与融合
 */

class MemoryRetriever {
  constructor(options = {}) {
    this.storage = options.storage || new LocalJSONStorage();
    this.queryClassifier = new QueryClassifier();
    this.ranker = new MemoryRanker();
    this.fuser = new MemoryFuser();
  }

  /**
   * 主入口：检索相关记忆
   * @param {String} query - 用户问题
   * @param {Object} context - 上下文（当前项目、会话等）
   * @param {Object} options - 选项（限制层数、数量等）
   */
  async retrieve(query, context = {}, options = {}) {
    try {
      console.log(`[MemoryRetriever] Retrieving memories for: "${query.substring(0, 50)}..."`);

      // 1. 查询分类
      const queryType = this.queryClassifier.classify(query);
      console.log(`[MemoryRetriever] Query type: ${queryType}`);

      // 2. 确定检索层
      const layers = this.determineLayers(queryType, options.layers);
      console.log(`[MemoryRetriever] Searching layers: ${layers.join(', ')}`);

      // 3. 分层检索
      const allResults = [];
      for (const layer of layers) {
        const layerResults = await this.searchLayer(layer, query, context);
        console.log(`[MemoryRetriever] Layer ${layer}: found ${layerResults.length} memories`);
        allResults.push(...layerResults);
      }

      // 4. 去重
      const deduped = this.deduplicate(allResults);
      console.log(`[MemoryRetriever] After deduplication: ${deduped.length} memories`);

      // 5. 排序（相关性+时效性）
      const ranked = this.ranker.rank(deduped, query);
      
      // 6. 限制数量
      const limited = ranked.slice(0, options.limit || 10);

      // 7. 多跳融合（可选）
      let finalResults = limited;
      if (options.enableFusion !== false) {
        finalResults = await this.fuser.fuse(limited, query);
      }

      // 8. 格式化输出
      const formatted = this.formatForLLM(finalResults, context);

      console.log(`[MemoryRetriever] ✅ Returned ${finalResults.length} memories`);
      return formatted;

    } catch (error) {
      console.error(`[MemoryRetriever] ❌ Retrieve failed:`, error);
      return { memories: [], error: error.message };
    }
  }

  /**
   * 查询分类器
   */
  classifyQuery(query) {
    const patterns = {
      preference: /我.*偏好|我喜欢|我关注|只看|只买/,
      history: /上周|之前|上次|回顾|历史/,
      fact: /.*的股价|.*代码|.*财务|数据|指标|市值/,
      reflection: /教训|错误|改进|为什么|失误|复盘/,
      prediction: /预测|展望|未来|催化剂|预期|估计/
    };

    for (const [type, pattern] of Object.entries(patterns)) {
      if (pattern.test(query)) return type;
    }
    
    // 默认：事件+事实
    return "general";
  }

  /**
   * 确定检索哪些层
   */
  determineLayers(queryType, overrideLayers) {
    if (overrideLayers) return overrideLayers;

    const layerMap = {
      preference: ['background'],
      history: ['event', 'conversation'],
      fact: ['fact'],
      reflection: ['reflection', 'event'],
      prediction: ['fact', 'event', 'reflection'],
      general: ['event', 'fact']  // 默认两层
    };

    return layerMap[queryType] || ['event', 'fact'];
  }

  /**
   * 在指定层搜索
   */
  async searchLayer(layer, query, context) {
    // 简单关键词匹配（MVP）
    // 未来可升级为向量搜索
    const allRecords = await this.storage.read(layer, {});
    
    // 相关性评分
    const scored = allRecords.map(record => ({
      record,
      score: this.calculateRelevance(record, query, context)
    }));

    // 过滤低分（阈值0.3）
    const filtered = scored.filter(item => item.score > 0.3);

    // 按分数排序
    return filtered
      .sort((a, b) => b.score - a.score)
      .map(item => item.record);
  }

  /**
   * 计算相关性（简化版）
   */
  calculateRelevance(record, query, context) {
    let score = 0;
    const queryLower = query.toLowerCase();
    const content = (record.content || '').toLowerCase();

    // 1. 关键词匹配（0-0.5）
    const keywords = this.extractKeywords(query);
    let keywordScore = 0;
    keywords.forEach(kw => {
      if (content.includes(kw)) keywordScore += 0.2;
    });
    score += Math.min(keywordScore, 0.5);

    // 2. 时效性（0-0.3）
    if (record.metadata?.created_at) {
      const ageDays = (Date.now() - new Date(record.metadata.created_at)) / (1000 * 60 * 60 * 24);
      const recencyScore = Math.max(0, 0.3 - ageDays * 0.01);
      score += recencyScore;
    }

    // 3. 置信度（0-0.2）
    if (record.metadata?.confidence) {
      score += record.metadata.confidence * 0.2;
    }

    return score;
  }

  extractKeywords(text) {
    // 简化：提取名词（实际应用可用NLP）
    return text.split(/[\s,，。.!?？]+/).filter(w => w.length > 1);
  }

  /**
   * 去重（基于ID）
   */
  deduplicate(records) {
    const seen = new Set();
    return records.filter(r => {
      if (seen.has(r.id)) return false;
      seen.add(r.id);
      return true;
    });
  }

  /**
   * 格式化给LLM
   */
  formatForLLM(records, context) {
    if (records.length === 0) {
      return { memories: [], context: "" };
    }

    const memoryBlocks = records.map(r => {
      const typeLabel = {
        background: "【背景记忆】",
        event: "【事件记忆】",
        fact: "【事实记忆】",
        reflection: "【反思记忆】",
        conversation: "【对话摘要】",
        skill: "【技能记忆】"
      }[r.type] || "【记忆】";

      let content = r.content;
      if (r.type === 'fact') {
        content = `${r.content}（来源：${r.metadata?.source || '未知'}）`;
      }

      return `${typeLabel} ${content}`;
    });

    return {
      memories: records,
      context: `\n【相关历史记忆】\n${memoryBlocks.join('\n')}\n【/相关历史记忆】`
    };
  }
}

/**
 * ConflictDetector - 冲突检测器（占位）
 * MVP阶段仅记录，不实际解决
 */
class ConflictDetector {
  async detect(newFact) {
    // TODO: 实现相似事实检索
    console.log(`[ConflictDetector] Conflict detection not implemented in MVP`);
    return [];
  }

  async resolve(newFact, conflicts) {
    // MVP：简单标记，不自动解决
    console.warn(`[ConflictDetector] Conflict detected but not auto-resolved in MVP`);
    return newFact;
  }
}

/**
 * MemoryCompressor - 记忆压缩器
 * MVP：简单截断；未来：LLM摘要
 */
class MemoryCompressor {
  async compress(content) {
    // 如果内容<200字，直接返回
    if (content.length < 200) return content;

    // MVP：保留前100字 + 后100字
    const head = content.substring(0, 100);
    const tail = content.substring(content.length - 100);
    return `${head}...[省略${content.length - 200}字]...${tail}`;
  }
}

/**
 * MemoryClassifier - 记忆分类器
 */
class MemoryClassifier {
  isValidType(type) {
    const validTypes = [
      'background', 'conversation', 'event',
      'fact', 'reflection', 'skill'
    ];
    return validTypes.includes(type);
  }
}

/**
 * MemoryRanker - 记忆排序器
 */
class MemoryRanker {
  rank(records, query) {
    // 已在MemoryRetriever.calculateRelevance中实现
    return records;
  }
}

/**
 * MemoryFuser - 记忆融合器（多跳推理）
 * MVP：仅返回，未来实现关联推理
 */
class MemoryFuser {
  async fuse(records, query) {
    // TODO: 实现多跳推理
    // 例如：事件A → 相关事件B → 反思教训C
    return records;
  }
}

/**
 * LocalJSONStorage - 本地JSON存储（MVP）
 */
class LocalJSONStorage {
  constructor(basePath = 'workspace/memory') {
    this.basePath = basePath;
  }

  async write(layer, record) {
    const fs = require('fs');
    const path = require('path');

    const dirPath = path.join(this.basePath, layer);
    const filePath = path.join(dirPath, `${record.metadata.created_at.split('T')[0]}.json`);

    // 确保目录存在
    if (!fs.existsSync(dirPath)) {
      fs.mkdirSync(dirPath, { recursive: true });
    }

    // 读取现有数据
    let data = [];
    if (fs.existsSync(filePath)) {
      data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    }

    // 追加
    data.push(record);

    // 写回
    fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

    return record;
  }

  async read(layer, query = {}) {
    const fs = require('fs');
    const path = require('path');

    const dirPath = path.join(this.basePath, layer);
    if (!fs.existsSync(dirPath)) return [];

    const files = fs.readdirSync(dirPath).filter(f => f.endsWith('.json'));
    const allRecords = [];

    for (const file of files) {
      const filePath = path.join(dirPath, file);
      const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
      allRecords.push(...data);
    }

    // 简单过滤（MVP）
    if (query.field && query.value) {
      return allRecords.filter(r => r[query.field] === query.value);
    }

    return allRecords;
  }

  /**
   * 更新记录
   */
  async update(layer, recordId, updates) {
    const all = await this.read(layer, {});
    const idx = all.findIndex(r => r.id === recordId);
    if (idx === -1) throw new Error(`Record not found: ${recordId}`);
    all[idx] = { ...all[idx], ...updates };
    const filePath = this.getFilePathByRecord(layer, all[idx]);
    fs.writeFileSync(filePath, JSON.stringify(all, null, 2));
    return all[idx];
  }

  /**
   * 删除（标记）
   */
  async delete(layer, recordId) {
    const all = await this.read(layer, {});
    const rec = all.find(r => r.id === recordId);
    if (rec) {
      rec.metadata.deleted = true;
      rec.metadata.deleted_at = new Date().toISOString();
      await this.update(layer, recordId, rec);
    }
    return true;
  }

  /**
   * 文件路径（按日期）
   */
  getFilePath(layer, record) {
    const date = record.metadata?.created_at 
      ? new Date(record.metadata.created_at).toISOString().split('T')[0]
      : new Date().toISOString().split('T')[0];
    return path.join(this.basePath, layer, `${date}.json`);
  }

  getFilePathByRecord(layer, record) {
    return this.getFilePath(layer, record);
  }

  /**
   * 统计各层记录数
   */
  async stats() {
    const layers = ['background', 'event', 'conversation', 'fact', 'reflection', 'skill'];
    const stats = {};
    for (const layer of layers) {
      const records = await this.read(layer, {});
      stats[layer] = records.length;
    }
    return stats;
  }

  /**
   * 清理（占位）
   */
  async cleanup(retentionDays = 90) {
    console.log('[LocalJSONStorage] Cleanup not implemented in MVP');
  }

}

// 导出
module.exports = {
  MemoryWriter,
  MemoryRetriever,
  ConflictDetector,
  MemoryCompressor,
  MemoryClassifier,
  MemoryRanker,
  MemoryFuser,
  LocalJSONStorage
};
