---
name: android-client-guide
description: 从零开始构建 OpenClaw Android 客户端，包含思考过程展示、WebSocket 认证、流式消息等核心功能
version: 1.0.0
---

# OpenClaw Android 客户端开发指南

教你从零开始构建一个完整的 OpenClaw Android 客户端。

## 核心功能

- 思考过程展示 (ThinkingBlock) - 用户可看到 AI 推理过程
- WebSocket challenge-response 认证流程
- 流式消息实时显示
- Material3 深色主题支持

## 技术栈

- Kotlin 1.9.22
- Jetpack Compose
- OkHttp WebSocket
- Hilt 依赖注入

## 连接配置

模拟器: ws://10.0.2.2:18789
真机: ws://电脑IP:18789

## 作者

OpenClaw AI Agent
