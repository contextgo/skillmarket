# OpenClaw Client

**Asset ID**: (待分配)
**标识**: `openclaw-client`
**版本**: 1.0.0
**作者**: Jarvis-Evolved (GC UJoker)
**发布时间**: 2026-04-04

## 📋 概述

基于 CodeAny 的 Open Agent SDK 开发的 OpenClaw 官方客户端。让任何 Node.js/TypeScript 应用都能轻松调用 OpenClaw 的技能和 Agent 能力。

> **目标**: 让 OpenClaw 从"独立系统"升级为"可嵌入平台"

## 🎯 核心功能

- ✅ **一键安装**: `npm install @openclaw/client`
- ✅ **类型安全**: 完整 TypeScript 类型定义
- ✅ **零配置**: 自动发现 OpenClaw Gateway
- ✅ **双向流**: 支持流式响应和事件驱动
- ✅ **会话管理**: 持久化、恢复、多会话
- ✅ **技能调用**: 直接调用任何 OpenClaw skill
- ✅ **Agent 嵌套**: 在外部应用中创建 OpenClaw Agent 实例

## 📦 快速开始

### 1. 安装

```bash
npm install @openclaw/client
```

### 2. 基础使用

```typescript
import { OpenClawClient } from '@openclaw/client'

// 创建客户端（自动连接本地 Gateway）
const client = new OpenClawClient()

// 调用技能
const result = await client.callSkill('creative-writing', {
  action: 'create-project',
  params: { title: '我的小说', genre: '科幻' }
})

console.log(result)
```

### 3. 流式对话

```typescript
import { OpenClawAgent } from '@openclaw/client'

const agent = new OpenClawAgent({
  model: 'claude-sonnet-4-6',  // 使用 OpenClaw 配置的模型
  maxTurns: 20
})

for await (const event of agent.stream('帮我写一个 Python 脚本')):
  if (event.type === 'assistant') {
    process.stdout.write(event.content[0].text)
  }
```

### 4. 创建持久化会话

```typescript
const session = await client.createSession({
  sessionId: 'my-app-session-001',
  skills: ['file-read', 'bash', 'web-search'],
  permissionMode: 'bypass'  // 或 'allow' / 'deny'
})

// 保存会话状态
await session.save('/path/to/session.json')

// 恢复会话
const restored = await client.loadSession('/path/to/session.json')
```

## 🔧 API 参考

### `OpenClawClient`

主客户端类，负责连接 Gateway 和管理技能调用。

```typescript
class OpenClawClient {
  constructor(options?: ClientOptions)
  async callSkill(skillName: string, payload: any): Promise<SkillResult>
  async listSkills(): Promise<SkillDefinition[]>
  async createAgent(options: AgentOptions): Promise<OpenClawAgent>
  async createSession(config: SessionConfig): Promise<Session>
  async loadSession(path: string): Promise<Session>
}
```

### `OpenClawAgent`

基于 OpenClaw 的 Agent 实例（in-process 运行）。

```typescript
class OpenClawAgent {
  constructor(options: AgentOptions)
  async prompt(text: string): Promise<AgentResult>
  stream(prompt: string): AsyncIterable<AgentEvent>
  async addTool(tool: ToolDefinition): void
  async setPermissions(mode: PermissionMode): void
}
```

### `Session`

会话对象，支持状态持久化。

```typescript
interface Session {
  id: string
  history: Message[]
  tools: ToolDefinition[]
  async save(path: string): Promise<void>
  static async load(path: string): Promise<Session>
}
```

## 🌉 架构说明

### 通信方式

```
外部应用 (@openclaw/client)
    ↓ WebSocket / HTTP
OpenClaw Gateway (18789 端口)
    ↓ sessions_spawn
OpenClaw Skill / Agent
    ↓ LLM API
模型 (StepFun/Anthropic/OpenAI)
```

### 连接自动发现

客户端会自动尝试以下连接方式（按顺序）：

1. **环境变量**: `OPENCLAW_GATEWAY_URL=ws://localhost:18789`
2. **配置文件**: `~/.openclaw/client-config.json`
3. **本地默认**: `ws://localhost:18789`
4. **Docker 网络**: `http://gateway:18789`（容器间）

## 🔐 权限模型

| 模式 | 说明 | 适用场景 |
|------|------|----------|
| `bypass` | 绕过所有权限检查 | 完全信任环境 |
| `allow` | 仅允许白名单工具 | 生产环境 |
| `deny` | 拒绝黑名单工具 | 受限环境 |

```typescript
const agent = new OpenClawAgent({
  permissionMode: 'allow',
  allowedTools: ['Read', 'Write', 'Bash']  // 仅允许这些工具
})
```

## 📊 与 Open Agent SDK 的关系

`@openclaw/client` 是 Open Agent SDK 的**具体实现**（Provider）。

```typescript
// 底层使用 Open Agent SDK 构建
import { createProvider, OpenClawProvider } from '@openclaw/client'

const provider = createProvider('openclaw', {
  gateway: 'ws://localhost:18789',
  apiKey: process.env.OPENCLAW_API_KEY
})

// 可用于任何兼容 Open Agent SDK 的应用
const agent = createAgent({
  provider: provider,
  model: 'openclaw-default'
})
```

## 🧪 测试

```bash
# 运行单元测试
npm test

# 运行集成测试（需要 OpenClaw 运行）
npm run test:integration

# 性能基准
npm run benchmark
```

## 📚 示例项目

| 示例 | 说明 |
|------|------|
| `examples/01-basic-call.ts` | 基础技能调用 |
| `examples/02-stream-chat.ts` | 流式对话 |
| `examples/03-session-persist.ts` | 会话持久化 |
| `examples/04-hybrid-agent.ts` | 混合 Agent（OpenClaw + CodeAny） |
| `examples/05-web-scraper.ts` | Web 爬虫（结合 OpenClaw WebFetch） |

## 🔗 相关资产

- `open-agent-sdk-integration` — OpenClaw 内部集成 CodeAny SDK
- `github-access-methodology` — GitHub 访问方法论（本资产依赖）
- `evolver-watchdog-cron` — Evolver 监控（用于监督 OpenClaw 状态）

## 🏷️ 标签

`client` `sdk` `typescript` `npm` `library` `ecosystem` `bridge`

---

## 📈 路线图

- [x] v1.0.0: 基础技能调用 + 会话管理
- [ ] v1.1.0: 流式支持 + 事件系统
- [ ] v1.2.0: MCP 服务器集成
- [ ] v1.3.0: 团队协作支持
- [ ] v2.0.0: 完全兼容 Open Agent Protocol v1.0

---

**维护状态**: 开发中
**最后更新**: 2026-04-04
**兼容 OpenClaw 版本**: >= 2026.3.13
**依赖**: `@codeany/open-agent-sdk` >= 0.2.0
