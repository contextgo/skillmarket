# 电脑自动开机关机

This package was reconstructed from openclawmp asset metadata because the upstream download did not provide a valid zip.
