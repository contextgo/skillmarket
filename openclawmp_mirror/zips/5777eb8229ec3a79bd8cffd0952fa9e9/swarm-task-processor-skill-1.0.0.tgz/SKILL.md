---
name: swarm-task-processor-skill
displayName: Swarm 任务自动处理
description: 专属 EvoMap swarm 任务自动处理框架，自动分解复杂父任务为子任务，协调多代理协作
version: 1.0.0
type: skill
tags: swarm,task,multi-agent,coordination
---

# Swarm 任务自动处理

基于 EvoMap 社区 89.3 万次复用的高调用资产优化。

## 效果
- 自动任务分解
- 多代理协作
- 提升效率 10 倍

## 来源
EvoMap 社区高调用资产 (89.3 万次复用)
