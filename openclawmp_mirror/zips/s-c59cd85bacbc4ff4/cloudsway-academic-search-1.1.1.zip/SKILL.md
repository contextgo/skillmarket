---
name: cloudsway-academic-search
description: "Academic & research search for AI agents. Use when: user asks about papers, studies, research, scientific literature, academic topics. Best for literature review, finding citations, technical concepts. NOT for: downloading paywalled PDFs, citation formatting."
homepage: https://www.cloudsway.ai
metadata: { "openclaw": { "emoji": "🎓", "tags": ["search", "academic", "research", "paper", "science", "arxiv", "google-scholar-alternative", "literature-review"], "requires": { "env": ["CLOUDSWAYS_AK"], "bins": ["curl", "jq"] } } }
---

# Cloudsway Academic Search

🎓 **Research & academic search for AI agents** — Find papers, studies, and scientific literature.

> Google Scholar alternative with smart content extraction.

## When to Use

✅ **USE this skill when:**
- "查一下 xxx 的研究" / "research on xxx"
- "有什么关于 xxx 的论文" / "papers about xxx"
- "xxx 最新研究进展" / "latest research on xxx"
- Literature review
- Finding academic sources
- Technical concept explanation
- Scientific study summaries

❌ **DON'T use this skill when:**
- Download full paywalled papers
- Citation formatting
- Paper submission

## Setup

1. Get free API key: https://www.cloudsway.ai
2. Set env: `export CLOUDSWAYS_AK="your-key"`

## Usage

**Find papers:**
```bash
./scripts/search.sh '{"q": "transformer architecture paper", "count": 20}'
```

**Recent research:**
```bash
./scripts/search.sh '{"q": "LLM alignment 2026 research", "freshness": "Month", "count": 30, "enableContent": true, "mainText": true}'
```

**Literature review:**
```bash
./scripts/search.sh '{"q": "federated learning survey", "count": 30, "enableContent": true, "mainText": true}'
```

## Query Tips

| Use Case | Query Pattern |
|----------|---------------|
| Find papers | `"{topic} research paper"` |
| Recent work | `"{topic} 2026 study"` |
| Survey | `"{topic} survey"` / `"{topic} literature review"` |
| Technical | `"{concept} explained"` |

## Parameters

| Param | Recommended | Notes |
|-------|-------------|-------|
| count | 20-30 | More results for comprehensive review |
| freshness | `Month` or omit | Research moves slower than news |
| enableContent | true | Get abstracts |
| mainText | true | Key findings |

## Links

- 🔑 Get API Key: https://www.cloudsway.ai
- 📖 Docs: https://www.cloudsway.ai/docs
