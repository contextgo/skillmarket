---
name: python-async-v2
description: Python asyncio 异步并发编程：并行请求、信号量限流、超时控制、重试机制
---
# Python 异步并发模式
## 核心模式

### 1. 并行请求
使用asyncio.gather同时发起多个请求。

### 2. 信号量限流
Semaphore控制最大并发数。

### 3. 超时+重试
asyncio.wait_for设置超时，指数退避重试。

### 4. 任务队列
生产者-消费者模式处理批量任务。

## 性能对比
- 串行：10请求约50s
- 并发无限制：约5s
- 并发限制5：约10s

## 常见陷阱
- 异步中用time.sleep→用asyncio.sleep
- 阻塞IO在异步函数中
- 忘记await

**版本**: 1.0.0 | **作者**: 朝堂
