---
name: config-management
description: 配置管理助手。用于管理配置文件、配置变更、配置版本、环境配置。当需要管理配置、处理配置变更时触发。
---

# 配置管理助手

## 配置分类

| 类型 | 说明 | 示例 |
|------|------|------|
| 应用配置 | 运行时参数 | 超时、开关 |
| 环境配置 | 不同环境差异 | Dev/Staging/Prod |
| 基础设施配置 | 系统配置 | 数据库、缓存 |
| 秘钥配置 | 敏感信息 | API Key、密码 |

## 配置管理规范

```markdown
## 配置管理原则

### 1. 环境隔离
- Dev环境：本地开发
- Test环境：测试使用
- Staging环境：预发布
- Production环境：生产

### 2. 配置集中
所有配置通过配置中心管理，禁止硬编码

### 3. 配置版本化
所有配置变更记录版本，支持回滚

### 4. 配置权限
- 查看权限：所有人
- 修改权限：按环境分级
- 生产配置：需审批
```

## 配置中心设计

### 配置模型
```json
{
  "app": "order-service",
  "env": "production",
  "namespace": "default",
  "config": {
    "datasource": {
      "url": "jdbc:mysql://db:3306/order",
      "username": "${DB_USERNAME}",
      "password": "${DB_PASSWORD}"
    },
    "redis": {
      "host": "${REDIS_HOST}",
      "port": "${REDIS_PORT}"
    },
    "feature_flags": {
      "new_payment": true,
      "ai_recommendation": false
    }
  },
  "version": 12,
  "updated_at": "2024-01-01 10:00:00",
  "updated_by": "admin"
}
```

### 配置分类存储
```
配置中心
├── order-service
│   ├── development
│   ├── test
│   ├── staging
│   └── production
├── user-service
│   ├── development
│   ├── test
│   ├── staging
│   └── production
└── shared
    └── common-config
```

## 配置变更流程

```markdown
## 配置变更流程

1. 创建变更单
   ↓
2. 开发环境测试
   ↓
3. 测试环境验证
   ↓
4. 审批（生产环境）
   ↓
5. 灰度发布
   ↓
6. 全量生效
   ↓
7. 监控验证
```

### 配置变更检查清单
- [ ] 变更必要性评估
- [ ] 回滚方案准备
- [ ] 变更影响分析
- [ ] 测试验证
- [ ] 灰度策略
- [ ] 监控告警

## 敏感配置管理

```markdown
## 秘钥管理

### 1. 使用加密
- 配置加密存储
- 运行时解密
- 传输使用HTTPS

### 2. 权限控制
- 最小权限原则
- 操作审计
- 定期轮换

### 3. 密钥轮换
| 类型 | 轮换周期 |
|------|----------|
| API Key | 90天 |
| 数据库密码 | 30天 |
| 证书 | 到期前30天 |

### 4. 密钥存储
```yaml
# 使用Vault管理密钥
apiVersion: v1
kind: Secret
metadata:
  name: db-credentials
type: Opaque
stringData:
  username: admin
  password: ${vault:secret/db#password}
```
```

## 配置模板

### Spring Boot配置
```yaml
# application.yml
spring:
  application:
    name: order-service
  profiles:
    active: ${ENV:dev}
  datasource:
    url: jdbc:mysql://${DB_HOST}:${DB_PORT}/${DB_NAME}
    username: ${DB_USERNAME}
    password: ${DB_PASSWORD}
  redis:
    host: ${REDIS_HOST}
    port: ${REDIS_PORT}
    password: ${REDIS_PASSWORD}

# 环境特定配置
---
spring:
  config:
    activate:
      on-profile: production
  datasource:
    url: jdbc:mysql://${DB_HOST_PROD}:${DB_PORT}/${DB_NAME}
```

### 配置中心（Apollo）
```xml
<!-- Apollo配置 -->
<dependency>
    <groupId>com.ctrip.framework.apollo</groupId>
    <artifactId>apollo-client</artifactId>
    <version>2.1.0</version>
</dependency>

# application.yml
apollo:
  bootstrap:
    enabled: true
    namespaces: application,common
  meta: ${APOLLO_META}
  app-id: ${APOLLO_APP_ID}
```

## 配置版本管理

```markdown
## 配置版本记录

| 版本 | 变更内容 | 变更人 | 变更时间 | 回滚 |
|------|----------|--------|----------|------|
| v12 | 新增支付超时配置 | @admin | 2024-01-01 | 回滚 |
| v11 | 调整缓存过期时间 | @dev | 2023-12-28 | - |
| v10 | 新增特征开关 | @dev | 2023-12-20 | 回滚 |

### 版本对比
```diff
- timeout: 3000
+ timeout: 5000
  maxRetries: 3
```

## 配置审计

| 检查项 | 频率 | 执行人 |
|--------|------|--------|
| 配置合规性 | 每月 | 安全团队 |
| 秘钥轮换 | 每季度 | 运维团队 |
| 配置一致性 | 每周 | 测试团队 |
| 权限审计 | 每季度 | 合规团队 |
