# 行业投资分析框架

## 🚀 快速部署指南

### 1. 环境要求
- Python 3.8+
- 基本数据分析库 (numpy, pandas)
- 配置文件支持 (yaml, json)

### 2. 安装步骤
```bash
# 克隆或复制技能文件夹
cp -r .codebuddy/skills/industry-analysis-framework /your/project/path/

# 安装依赖 (可选)
pip install numpy pandas pyyaml
```

### 3. 基本配置
```python
# 在您的项目中创建配置文件 config.yaml
analysis_config:
  data_sources:
    market_data: "local_database"  # 或 "api_service"
    update_frequency: "weekly"
  
  output_formats:
    - "json"
    - "html_report"
    - "investment_summary"
  
  notification_settings:
    email_alerts: true
    weekly_summary: true
```

## 🧪 测试验证

### 1. 运行示例测试
```bash
cd .codebuddy/skills/industry-analysis-framework/examples
python commercial_space_example.py
```

### 2. 验证输出
运行示例后应该看到:
- ✅ 数据收集完成
- ✅ 行业分析完成  
- ✅ 投资评估完成
- ✅ 投资决策生成
- ✅ 结果保存成功

### 3. 自定义测试
```python
# 测试自定义行业分析
from scripts.industry_analyzer import IndustryAnalyzer

# 测试新能源行业
analyzer = IndustryAnalyzer(industry="新能源汽车")
results = analyzer.run_complete_analysis()

# 验证结果结构
assert "data" in results
assert "analysis" in results  
assert "evaluation" in results
assert "decision" in results
print("✅ 测试通过!")
```

## 🔧 集成到现有系统

### 1. 作为独立模块
```python
# 在现有投资系统中导入
from industry_analysis_framework import IndustryAnalyzer

def analyze_investment_opportunity(industry):
    """分析投资机会"""
    analyzer = IndustryAnalyzer(industry=industry)
    return analyzer.run_complete_analysis()

# 使用
results = analyze_investment_opportunity("人工智能")
```

### 2. 作为决策支持系统
```python
# 集成到投资决策流程
class InvestmentDecisionSystem:
    def __init__(self):
        from industry_analysis_framework import IndustryAnalyzer
        self.analyzer = IndustryAnalyzer
    
    def evaluate_industry(self, industry, investment_amount):
        """评估行业投资价值"""
        analysis = self.analyzer(industry).run_complete_analysis()
        
        # 结合投资金额进行决策
        recommendation = self._adjust_for_investment_size(
            analysis, investment_amount
        )
        
        return recommendation
```

### 3. 作为定期报告生成器
```python
# 自动生成行业分析报告
def generate_industry_reports(industries):
    """为多个行业生成分析报告"""
    reports = []
    
    for industry in industries:
        analyzer = IndustryAnalyzer(industry=industry)
        results = analyzer.run_complete_analysis()
        
        report = format_report(results, industry)
        reports.append(report)
    
    return reports

# 定期执行
schedule.every().monday.at("09:00").do(
    generate_industry_reports, 
    ["商业航天", "新能源汽车", "人工智能"]
)
```

## 📊 性能优化

### 1. 数据缓存
```python
# 启用数据缓存加速分析
analyzer = IndustryAnalyzer(
    industry="商业航天",
    enable_cache=True,
    cache_ttl=86400  # 缓存24小时
)
```

### 2. 并行处理
```python
# 并行分析多个行业
from concurrent.futures import ThreadPoolExecutor

def analyze_multiple_industries(industries):
    """并行分析多个行业"""
    with ThreadPoolExecutor(max_workers=3) as executor:
        futures = {
            executor.submit(IndustryAnalyzer(ind).run_complete_analysis): ind 
            for ind in industries
        }
        
        results = {}
        for future in futures:
            industry = futures[future]
            try:
                results[industry] = future.result()
            except Exception as e:
                print(f"分析 {industry} 时出错: {e}")
        
        return results
```

### 3. 增量更新
```python
# 只更新变化的数据
analyzer = IndustryAnalyzer(industry="商业航天")
results = analyzer.run_incremental_update(
    last_update_date="2025-03-01",
    update_fields=["market_size", "policy_changes"]
)
```

## 🛠️ 维护和更新

### 1. 定期维护任务
```bash
# 每月执行的维护脚本
python scripts/maintenance.py --task cleanup_old_data
python scripts/maintenance.py --task update_templates
python scripts/maintenance.py --task optimize_database
```

### 2. 版本升级
```python
# 检查并升级框架版本
from industry_analysis_framework import check_for_updates

if check_for_updates():
    print("发现新版本，正在升级...")
    upgrade_framework()
    print("升级完成!")
```

### 3. 备份和恢复
```bash
# 备份分析数据和配置
python scripts/backup.py --backup-path ./backups/

# 从备份恢复
python scripts/restore.py --backup-file ./backups/backup_20250313.zip
```

## 🔍 故障排除

### 常见问题及解决方案

#### 问题1: 数据收集失败
```
错误: 无法连接到数据源
解决方案:
1. 检查网络连接
2. 验证API密钥
3. 使用备用数据源
```

#### 问题2: 分析结果异常
```
错误: 分析结果超出合理范围
解决方案:
1. 检查输入数据质量
2. 验证分析参数设置
3. 重新运行数据验证
```

#### 问题3: 性能问题
```
错误: 分析时间过长
解决方案:
1. 启用数据缓存
2. 优化数据库查询
3. 使用增量更新
```

#### 问题4: 依赖问题
```
错误: 缺少必要的库
解决方案:
1. 运行 pip install -r requirements.txt
2. 检查Python版本兼容性
3. 重新安装依赖
```

## 📈 监控和日志

### 1. 启用详细日志
```python
import logging

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('industry_analysis.log'),
        logging.StreamHandler()
    ]
)

# 在分析器中启用日志
analyzer = IndustryAnalyzer(
    industry="商业航天",
    enable_logging=True,
    log_level="INFO"
)
```

### 2. 性能监控
```python
# 监控分析性能
from scripts.monitoring import PerformanceMonitor

monitor = PerformanceMonitor()

with monitor.track("complete_analysis"):
    results = analyzer.run_complete_analysis()

# 查看性能报告
report = monitor.generate_report()
print(f"分析耗时: {report['complete_analysis']['duration']:.2f}秒")
```

### 3. 错误追踪
```python
# 错误追踪和报告
try:
    results = analyzer.run_complete_analysis()
except Exception as e:
    # 记录错误详情
    error_details = {
        "timestamp": datetime.now().isoformat(),
        "industry": analyzer.industry,
        "error_type": type(e).__name__,
        "error_message": str(e),
        "stack_trace": traceback.format_exc()
    }
    
    # 保存错误报告
    save_error_report(error_details)
    
    # 发送警报
    send_alert(f"行业分析失败: {analyzer.industry}")
```

## 🎯 最佳实践

### 1. 数据质量优先
```python
# 始终验证数据质量
def ensure_data_quality(data):
    """确保数据质量"""
    checks = [
        check_completeness(data),
        check_consistency(data),
        check_timeliness(data),
        check_accuracy(data)
    ]
    
    if all(checks):
        return data
    else:
        raise DataQualityError("数据质量不达标")
```

### 2. 定期更新分析
```python
# 建立定期分析计划
def schedule_regular_analysis():
    """安排定期分析"""
    industries_to_monitor = [
        "商业航天",
        "新能源汽车", 
        "人工智能",
        "生物医药"
    ]
    
    # 每周分析
    for industry in industries_to_monitor:
        analyzer = IndustryAnalyzer(industry=industry)
        analyzer.run_complete_analysis()
```

### 3. 结果验证和反馈
```python
# 验证分析结果并收集反馈
def validate_and_collect_feedback(results):
    """验证结果并收集反馈"""
    
    # 验证逻辑一致性
    if not validate_logic_consistency(results):
        return {"status": "failed", "reason": "逻辑不一致"}
    
    # 与实际表现对比
    performance_comparison = compare_with_actual_performance(results)
    
    # 收集用户反馈
    feedback = collect_user_feedback(results)
    
    return {
        "status": "success",
        "validation": performance_comparison,
        "feedback": feedback
    }
```

## 📞 技术支持

### 获取帮助
- 📚 查看详细文档: `docs/` 目录
- 🐛 报告问题: 提交Issue到项目仓库
- 💬 社区讨论: 加入用户交流群
- 📧 邮件支持: support@industry-analysis.com

### 贡献指南
欢迎贡献代码、改进建议或使用案例:
1. Fork项目仓库
2. 创建功能分支
3. 提交更改
4. 创建Pull Request

---

**版本**: 1.0  
**最后更新**: 2025年3月13日  
**状态**: ✅ 生产就绪