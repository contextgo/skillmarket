#!/usr/bin/env python3
"""
商业航天行业分析示例
展示如何使用行业分析框架
"""

import sys
import os

# 添加技能路径
sys.path.append(os.path.join(os.path.dirname(__file__), "../scripts"))

from industry_analyzer import IndustryAnalyzer

def run_commercial_space_analysis():
    """运行商业航天行业分析示例"""
    
    print("="*80)
    print("🚀 商业航天行业分析示例")
    print("="*80)
    
    # 创建分析器
    analyzer = IndustryAnalyzer(
        industry="商业航天",
        framework_version="1.0"
    )
    
    # 运行完整分析
    results = analyzer.run_complete_analysis(save_results=True)
    
    # 详细分析结果展示
    print("\n📊 详细分析结果:")
    print("-"*40)
    
    # 市场分析结果
    market_analysis = results["analysis"]["market_analysis"]
    print("1. 市场规模分析:")
    print(f"   • 市场阶段: {market_analysis.get('market_stage', '未知')}")
    print(f"   • 预测增长率: {market_analysis.get('growth_rate', 0):.1f}%")
    print(f"   • 市场潜力: {market_analysis.get('market_potential', 0):.2f}万亿元")
    
    # 投资评估结果
    growth_assessment = results["evaluation"]["growth_assessment"]
    risk_assessment = results["evaluation"]["risk_assessment"]
    print("\n2. 投资评估:")
    print(f"   • 成长性评分: {growth_assessment.get('growth_score', 0):.1f}/100")
    print(f"   • 成长性等级: {growth_assessment.get('growth_level', '未知')}")
    print(f"   • 风险评分: {risk_assessment.get('overall_risk_score', 0):.1f}/100")
    print(f"   • 风险等级: {risk_assessment.get('risk_level', '未知')}")
    
    # 投资决策结果
    recommendation = results["decision"]["investment_recommendation"]
    overall = recommendation.get("overall_assessment", {})
    print("\n3. 投资决策:")
    print(f"   • 投资吸引力: {overall.get('attractiveness_score', 0):.1f}/100")
    print(f"   • 吸引力等级: {overall.get('attractiveness_level', '未知')}")
    
    # ETF推荐
    etfs = recommendation.get("etf_recommendations", [])
    if etfs:
        print(f"\n4. ETF推荐:")
        for i, etf in enumerate(etfs[:3], 1):
            print(f"   {i}. {etf.get('name', '未知')}")
            print(f"      推荐等级: {etf.get('recommendation_level', '未知')}")
            print(f"      建议仓位: {etf.get('suggested_allocation', '未知')}")
    
    # 投资策略
    portfolio = results["decision"]["portfolio_allocation"]
    timing = results["decision"]["timing_strategy"]
    risk = results["decision"]["risk_management"]
    
    print("\n5. 投资策略:")
    print(f"   • 核心仓位: {portfolio.get('core_allocation', 0)}%")
    print(f"   • 卫星仓位: {portfolio.get('satellite_allocation', 0)}%")
    print(f"   • 现金仓位: {portfolio.get('cash_allocation', 0)}%")
    print(f"   • 进入策略: {timing.get('entry_strategy', '未指定')}")
    print(f"   • 退出策略: {timing.get('exit_strategy', '未指定')}")
    print(f"   • 止损设置: {risk.get('stop_loss', 0)}%")
    print(f"   • 仓位限制: {risk.get('position_limit', 0)}%")
    
    # 保存建议
    print("\n💡 投资建议总结:")
    print("-"*40)
    
    attractiveness = overall.get('attractiveness_score', 0)
    if attractiveness >= 80:
        print("✅ 强烈推荐投资")
        print("   建议积极配置，把握行业成长机会")
    elif attractiveness >= 70:
        print("✅ 推荐投资")
        print("   建议适度配置，分享行业增长红利")
    elif attractiveness >= 60:
        print("🟡 谨慎投资")
        print("   建议小仓位试探，关注风险控制")
    elif attractiveness >= 50:
        print("🟡 观察为主")
        print("   建议少量配置，等待更明确信号")
    else:
        print("🔴 暂不投资")
        print("   建议观望，等待更好的投资机会")
    
    # 后续行动建议
    print("\n📅 后续行动建议:")
    print("1. 定期(每季度)更新行业数据")
    print("2. 跟踪ETF资金流向和市场表现")
    print("3. 关注政策变化和技术突破")
    print("4. 根据市场变化调整投资策略")
    
    print("\n" + "="*80)
    print("✅ 示例分析完成!")
    print("="*80)
    
    return results

def demonstrate_framework_features():
    """演示框架功能"""
    
    print("\n" + "="*80)
    print("🛠️ 框架功能演示")
    print("="*80)
    
    analyzer = IndustryAnalyzer(industry="演示行业")
    
    # 演示分步执行
    print("\n1. 分步执行演示:")
    print("-"*20)
    
    print("📊 第一步: 数据收集")
    data = analyzer.collect_data()
    print(f"   收集到 {len(data)} 个数据集")
    
    print("🔍 第二步: 行业分析")
    analysis = analyzer.analyze_industry(data)
    print(f"   完成 {len(analysis)} 个维度分析")
    
    print("📈 第三步: 投资评估")
    evaluation = analyzer.evaluate_investment(analysis)
    print(f"   完成投资价值评估")
    
    print("🎯 第四步: 投资决策")
    decision = analyzer.make_decision(evaluation, data)
    print(f"   生成投资决策方案")
    
    # 演示框架优势
    print("\n2. 框架优势:")
    print("-"*20)
    advantages = [
        "✅ 系统性分析: 从数据到决策的全流程覆盖",
        "✅ 标准化流程: 确保分析质量和一致性",
        "✅ 可复用性: 快速应用于不同行业分析",
        "✅ 持续进化: 内置反馈优化机制",
        "✅ 知识沉淀: 自动积累分析经验和数据"
    ]
    
    for advantage in advantages:
        print(f"   {advantage}")
    
    # 演示使用场景
    print("\n3. 使用场景:")
    print("-"*20)
    scenarios = [
        "📊 新行业研究: 快速了解行业投资价值",
        "📈 投资决策: 生成科学的投资方案",
        "🔄 组合优化: 优化多行业投资组合",
        "📋 定期跟踪: 监控行业变化和投资表现",
        "🎓 经验积累: 建立个人行业研究能力"
    ]
    
    for scenario in scenarios:
        print(f"   {scenario}")
    
    print("\n" + "="*80)
    print("✅ 框架功能演示完成!")
    print("="*80)

if __name__ == "__main__":
    # 运行示例分析
    results = run_commercial_space_analysis()
    
    # 演示框架功能
    demonstrate_framework_features()
    
    # 保存完整结果
    output_file = "commercial_space_analysis_results.json"
    try:
        import json
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(results, f, ensure_ascii=False, indent=2)
        print(f"\n📁 完整分析结果已保存至: {output_file}")
    except Exception as e:
        print(f"\n⚠️  保存结果时出错: {e}")
    
    print("\n🎉 示例运行完成!")
    print("💡 您可以:")
    print("   1. 修改代码分析其他行业")
    print("   2. 扩展数据收集功能")
    print("   3. 优化评估模型")
    print("   4. 集成到您的投资决策流程中")