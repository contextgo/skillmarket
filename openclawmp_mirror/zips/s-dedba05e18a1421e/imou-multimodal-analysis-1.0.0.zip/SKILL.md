---
name: imou-multimodal-analysis
displayName: 乐橙AI智能分析
version: 1.0.0
description: >
  乐橙（Imou）设备通道实时抓图AI智能场景分析。支持：人形检测、抽烟检测、玩手机检测、工装检测与离岗检测（需预先配置工装模板）、
  货架检测、垃圾检测、热力图数据统计、人脸检测；检测目标库的创建/分页查询/删除及库内目标注册/查询/删除。
  适用于：乐橙AI分析、人形检测、抽烟检测、玩手机检测、工装离岗检测、货架检测、垃圾检测、热力图、人脸检测、检测目标库管理等场景。
metadata:
  {
    "openclaw":
      {
        "emoji": "🤖",
        "requires": { "env": ["IMOU_APP_ID", "IMOU_APP_SECRET"], "pip": ["requests"] },
        "primaryEnv": "IMOU_APP_ID",
        "install":
          [
            { "id": "python-requests", "kind": "pip", "package": "requests", "label": "安装 requests 依赖" }
          ]
      }
  }
---

# 🤖 乐橙AI智能分析

对乐橙设备通道实时抓图（或任意图片URL）进行AI智能场景分析：人形检测、抽烟检测、玩手机检测、工装合规与离岗检测（需预先配置工装库）、货架检测、垃圾溢出检测、热力图统计、人脸分析。同时支持检测目标库和目标的管理（创建/查询/删除库；添加/查询/删除目标）。

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install requests
```

### 2. 配置环境变量（必填）

```bash
export IMOU_APP_ID="你的应用ID"
export IMOU_APP_SECRET="你的应用密钥"
export IMOU_BASE_URL="API基础地址"
```

**API 基础地址说明：**

| 区域 | 数据中心 | 基础地址 |
|------|---------|---------|
| 中国大陆 | — | `https://openapi.lechange.cn` |
| 海外 | 东亚 | `https://openapi-sg.easy4ip.com:443` |
| 海外 | 中欧 | `https://openapi-fk.easy4ip.com:443` |
| 海外 | 美西 | `https://openapi-or.easy4ip.com:443` |

**如何获取 App ID 和 App Secret：**
- 访问 [乐橙开放平台](https://open.imou.com) 注册开发者账号
- 进入「应用管理」-「应用信息」获取 `appId` 和 `appSecret`

**注意**：AI 接口为增值能力，如需使用请向乐橙申请开通权限。

### 3. 运行命令

**图片分析（支持设备通道抓图 URL 或任意可访问图片 URL）：**

```bash
# 人形检测
python3 {baseDir}/scripts/multimodal_analysis.py analyze HUMAN "https://example.com/snapshot.jpg"

# 抽烟检测
python3 {baseDir}/scripts/multimodal_analysis.py analyze SMOKING "https://example.com/snapshot.jpg"

# 玩手机检测
python3 {baseDir}/scripts/multimodal_analysis.py analyze PHONE "https://example.com/snapshot.jpg"

# 工装检测（可选 repositoryId 和 threshold）
python3 {baseDir}/scripts/multimodal_analysis.py analyze WEAR "https://example.com/snapshot.jpg" [--repository-id 库ID] [--threshold 0.8]

# 离岗检测（需要工装库ID）
python3 {baseDir}/scripts/multimodal_analysis.py analyze ABSENCE "https://example.com/snapshot.jpg" --repository-id 库ID [--threshold 0.8]

# 货架检测
python3 {baseDir}/scripts/multimodal_analysis.py analyze SHELF "https://example.com/snapshot.jpg"

# 垃圾检测
python3 {baseDir}/scripts/multimodal_analysis.py analyze TRASH "https://example.com/snapshot.jpg"

# 热力图（threshold 必填；可选排除库ID）
python3 {baseDir}/scripts/multimodal_analysis.py analyze HEATMAP "https://example.com/snapshot.jpg" --threshold 0.8 [--exclude-repos ID1,ID2]

# 人脸分析
python3 {baseDir}/scripts/multimodal_analysis.py analyze FACE "https://example.com/snapshot.jpg"
```

**检测目标库和目标管理：**

```bash
# 创建检测库（face: 人脸 | human: 人形/工装）
python3 {baseDir}/scripts/multimodal_analysis.py repo create "我的工装库" human

# 查询库列表（分页）
python3 {baseDir}/scripts/multimodal_analysis.py repo list [--page 1] [--page-size 20]

# 删除库
python3 {baseDir}/scripts/multimodal_analysis.py repo delete 库ID

# 添加目标到库（图片URL 或 base64）
python3 {baseDir}/scripts/multimodal_analysis.py target add 库ID "目标名称" "https://image.url" [--type url]
python3 {baseDir}/scripts/multimodal_analysis.py target add 库ID "目标名称" "BASE64数据" --type base64

# 查询库内目标
python3 {baseDir}/scripts/multimodal_analysis.py target list 库ID [--page 1] [--page-size 20]

# 删除库内目标
python3 {baseDir}/scripts/multimodal_analysis.py target delete 库ID 目标ID
```

## ✨ 功能特性

1. **人形检测**：检测图片中是否含有人形
2. **抽烟检测**：检测图片中是否有人正在抽烟
3. **玩手机检测**：检测图片中是否有人正在使用手机
4. **工装检测**：检测人员是否穿着合规工装（可选工装库和阈值）
5. **离岗检测**：检测是否有人擅离职守（需预先配置工装库）
6. **货架检测**：检测货架状态（如空/满）
7. **垃圾检测**：检测垃圾是否溢出
8. **热力图**：获取区域热力图统计数据（threshold 必填；可选排除库ID以过滤特定人员如工作人员，仅统计有效客户）
9. **人脸分析**：人脸检测/分析
10. **检测目标库**：创建（人脸/人形）、分页查询、删除
11. **库内目标**：添加（URL 或 Base64）、分页查询、删除

## 📡 请求标识

所有请求都会携带请求头 `Client-Type: OpenClaw`，用于平台识别。

## 📚 API 参考文档

| 接口 | 文档地址 |
|-----|---------|
| AI 能力概述 | https://open.imou.com/document/pages/f1b9a3/ |
| 开发规范 | https://open.imou.com/document/pages/c20750/ |
| 获取 accessToken | https://open.imou.com/document/pages/fef620/ |
| 人形检测 | https://open.imou.com/document/pages/93rflk/ |
| 抽烟检测 | https://open.imou.com/document/pages/kf70sq/ |
| 玩手机检测 | https://open.imou.com/document/pages/jf78o9/ |
| 工装检测 | https://open.imou.com/document/pages/2jisd8/ |
| 离岗检测 | https://open.imou.com/document/pages/29dicv/ |
| 货架检测 | https://open.imou.com/document/pages/2oud87/ |
| 垃圾溢出检测 | https://open.imou.com/document/pages/cdmfd6/ |
| 热力图检测 | https://open.imou.com/document/pages/fdjfg9/ |
| 人脸分析 | https://open.imou.com/document/pages/28d7ug/ |
| 创建AI检测库 | https://open.imou.com/document/pages/34ff11/ |
| 分页查询检测库 | https://open.imou.com/document/pages/5e8222/ |
| 删除检测库 | https://open.imou.com/document/pages/5esi8a/ |
| 添加检测目标 | https://open.imou.com/document/pages/ikdf78/ |
| 查询检测目标 | https://open.imou.com/document/pages/278dkj/ |
| 删除检测目标 | https://open.imou.com/document/pages/odty82/ |

更多请求/响应格式详见 `references/imou-ai-api.md`

## 💡 使用提示

- **Token 有效期**：每次运行自动获取，有效期3天。如需跨运行缓存，请自行实现过期处理逻辑
- **图片输入**：`type` "0" 表示图片 URL，"1" 表示 Base64。抓图 URL 可以是设备通道实时预览封面 URL（如来自 imou-device-video 技能的 `liveList` / `bindDeviceLive` 返回的 streams[].coverUrl）或任意可访问的图片 URL
- **工装/离岗**：先创建人形类型的库，添加工装目标图片，然后将 `repositoryId` 传给工装检测和离岗检测
- **热力图**：`threshold` 取值范围 (0,1]。使用 `excludeRepositoryIds` 排除已匹配的工装人员（如工作人员），仅统计有效客户
- **检测区域**：可选参数；最多3个区域，每个区域3-6个点（归一化坐标 0-1）。省略则分析整张图片

## 🔒 数据流向说明

| 数据 | 发送至 | 用途 |
|-----|-------|-----|
| appId, appSecret | 乐橙开放平台 | 获取 accessToken |
| accessToken, 图片URL或Base64, repositoryId, threshold 等 | 乐橙开放平台 | AI 检测及目标库/目标管理 |

所有请求仅发送至配置的 `IMOU_BASE_URL`（乐橙官方API），不涉及第三方。
