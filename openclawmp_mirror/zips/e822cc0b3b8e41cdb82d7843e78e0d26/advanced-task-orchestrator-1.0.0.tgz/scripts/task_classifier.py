#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
"""
任务分类器 - 根据任务复杂度、工具需求、链路长度进行分级
"""

import json
import sys
from typing import Dict, Literal

TaskLevel = Literal["simple", "medium", "complex"]
ToolRequirement = Literal["none", "required"]


def classify_task(
    request: str,
    has_files: bool = False,
    file_count: int = 0,
    estimated_steps: int = 0
) -> Dict:
    """
    对任务进行分类
    
    Args:
        request: 用户原始请求
        has_files: 是否包含文件
        file_count: 文件数量
        estimated_steps: 预估步骤数
    
    Returns:
        {
            "level": "simple" | "medium" | "complex",
            "requires_tools": bool,
            "requires_agent": bool,
            "reasoning": str
        }
    """
    
    # 复杂度指标
    complexity_score = 0
    
    # 1. 请求长度和复杂度
    if len(request) > 200:
        complexity_score += 1
    if any(kw in request for kw in ["开发", "设计", "完整", "系统", "工具", "项目"]):
        complexity_score += 2
    if any(kw in request for kw in ["分析", "比较", "评估", "优化"]):
        complexity_score += 1
    
    # 2. 文件因素
    if has_files:
        if file_count > 5:
            complexity_score += 2
        elif file_count > 1:
            complexity_score += 1
    
    # 3. 预估步骤
    if estimated_steps > 5:
        complexity_score += 2
    elif estimated_steps > 2:
        complexity_score += 1
    
    # 4. 工具需求判断
    requires_tools = any(kw in request for kw in [
        "文件", "文件夹", "读取", "写入", "分析", "生成",
        "代码", "开发", "执行", "运行", "安装"
    ])
    
    requires_agent = complexity_score >= 3 or estimated_steps > 3
    
    # 确定等级
    if complexity_score >= 4 or estimated_steps > 5:
        level = "complex"
    elif complexity_score >= 2 or estimated_steps > 2:
        level = "medium"
    else:
        level = "simple"
    
    reasoning = f"复杂度评分: {complexity_score}, 预估步骤: {estimated_steps}, 需要工具: {requires_tools}"
    
    return {
        "level": level,
        "requires_tools": requires_tools,
        "requires_agent": requires_agent,
        "reasoning": reasoning
    }


def main():
    if len(sys.argv) < 2:
        print("Usage: python task_classifier.py '<request>' [has_files] [file_count] [estimated_steps]")
        sys.exit(1)
    
    request = sys.argv[1]
    has_files = sys.argv[2].lower() == "true" if len(sys.argv) > 2 else False
    file_count = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    estimated_steps = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    
    result = classify_task(request, has_files, file_count, estimated_steps)
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
