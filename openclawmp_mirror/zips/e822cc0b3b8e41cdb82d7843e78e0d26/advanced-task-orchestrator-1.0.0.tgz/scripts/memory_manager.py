#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
分层记忆管理器
管理短期、中期、长期记忆
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path


class MemoryManager:
    """分层记忆管理器"""
    
    def __init__(self, base_path: str = "memory"):
        self.base_path = Path(base_path)
        self.base_path.mkdir(exist_ok=True)
        
        # 三层记忆文件
        self.short_term_file = self.base_path / "short_term.json"
        self.medium_term_file = self.base_path / "medium_term.json"
        self.long_term_file = self.base_path / "long_term.json"
        
        # 初始化记忆文件
        self._init_memory_files()
    
    def _init_memory_files(self):
        """初始化记忆文件"""
        for file_path in [self.short_term_file, self.medium_term_file, self.long_term_file]:
            if not file_path.exists():
                with open(file_path, 'w', encoding='utf-8') as f:
                    json.dump([], f, ensure_ascii=False, indent=2)
    
    def _read_memory(self, file_path: Path) -> List[Dict]:
        """读取记忆"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError):
            return []
    
    def _write_memory(self, file_path: Path, data: List[Dict]):
        """写入记忆"""
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    def write_short_term(self, request: str, reasoning: str, response: str):
        """写入短期记忆（当前对话）"""
        memory = self._read_memory(self.short_term_file)
        entry = {
            "timestamp": datetime.now().isoformat(),
            "type": "short_term",
            "request": request,
            "reasoning": reasoning,
            "response": response
        }
        memory.append(entry)
        # 只保留最近 50 条
        memory = memory[-50:]
        self._write_memory(self.short_term_file, memory)
        return entry
    
    def write_medium_term(self, task_plan: str, execution_process: str, 
                          results: str, reflection: str):
        """写入中期记忆（任务级别）"""
        memory = self._read_memory(self.medium_term_file)
        entry = {
            "timestamp": datetime.now().isoformat(),
            "type": "medium_term",
            "task_plan": task_plan,
            "execution_process": execution_process,
            "results": results,
            "reflection": reflection
        }
        memory.append(entry)
        # 只保留最近 100 条
        memory = memory[-100:]
        self._write_memory(self.medium_term_file, memory)
        return entry
    
    def write_long_term(self, task_decomposition: str, full_execution: str,
                        reflection_results: str, success_case: str,
                        optimization_experience: str):
        """写入长期记忆（跨会话）"""
        memory = self._read_memory(self.long_term_file)
        entry = {
            "timestamp": datetime.now().isoformat(),
            "type": "long_term",
            "task_decomposition": task_decomposition,
            "full_execution": full_execution,
            "reflection_results": reflection_results,
            "success_case": success_case,
            "optimization_experience": optimization_experience
        }
        memory.append(entry)
        # 长期记忆保留更多
        memory = memory[-200:]
        self._write_memory(self.long_term_file, memory)
        return entry
    
    def search_similar_tasks(self, query: str, level: str = "all") -> List[Dict]:
        """
        搜索相似任务
        
        Args:
            query: 查询关键词
            level: "short", "medium", "long", "all"
        
        Returns:
            匹配的记忆条目列表
        """
        results = []
        
        files = []
        if level in ["short", "all"]:
            files.append(("short", self.short_term_file))
        if level in ["medium", "all"]:
            files.append(("medium", self.medium_term_file))
        if level in ["long", "all"]:
            files.append(("long", self.long_term_file))
        
        for mem_type, file_path in files:
            memory = self._read_memory(file_path)
            for entry in memory:
                # 简单关键词匹配
                entry_str = json.dumps(entry, ensure_ascii=False)
                if query.lower() in entry_str.lower():
                    entry["_memory_type"] = mem_type
                    results.append(entry)
        
        # 按时间倒序
        results.sort(key=lambda x: x.get("timestamp", ""), reverse=True)
        return results[:10]  # 返回最近 10 条
    
    def get_recent_context(self, count: int = 5) -> List[Dict]:
        """获取最近的短期记忆作为上下文"""
        memory = self._read_memory(self.short_term_file)
        return memory[-count:]


def main():
    if len(sys.argv) < 2:
        print("Usage: python memory_manager.py <command> [args...]")
        print("Commands:")
        print("  write_short <request> <reasoning> <response>")
        print("  write_medium <task_plan> <execution> <results> <reflection>")
        print("  write_long <decomposition> <execution> <reflection> <success> <optimization>")
        print("  search <query> [level]")
        print("  recent [count]")
        sys.exit(1)
    
    command = sys.argv[1]
    manager = MemoryManager()
    
    if command == "write_short" and len(sys.argv) >= 5:
        result = manager.write_short_term(sys.argv[2], sys.argv[3], sys.argv[4])
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "write_medium" and len(sys.argv) >= 6:
        result = manager.write_medium_term(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5])
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "write_long" and len(sys.argv) >= 7:
        result = manager.write_long_term(sys.argv[2], sys.argv[3], sys.argv[4], sys.argv[5], sys.argv[6])
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "search" and len(sys.argv) >= 3:
        level = sys.argv[3] if len(sys.argv) > 3 else "all"
        results = manager.search_similar_tasks(sys.argv[2], level)
        print(json.dumps(results, ensure_ascii=False, indent=2))
    
    elif command == "recent":
        count = int(sys.argv[2]) if len(sys.argv) > 2 else 5
        results = manager.get_recent_context(count)
        print(json.dumps(results, ensure_ascii=False, indent=2))
    
    else:
        print("Invalid command or arguments")
        sys.exit(1)


if __name__ == "__main__":
    main()
