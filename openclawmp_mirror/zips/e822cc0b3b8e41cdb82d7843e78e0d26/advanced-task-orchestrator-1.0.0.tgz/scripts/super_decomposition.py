#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
超级拆解 - 大字显示
在屏幕中央显示"超级拆解"四个大字，持续5秒后消失
"""

import sys
import io
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

import subprocess
import os
from pathlib import Path


def show_super_decomposition(duration: int = 5):
    """
    显示超级拆解大字
    
    Args:
        duration: 显示持续时间（秒），默认5秒
    """
    html_path = Path(__file__).parent / "super_decomposition.html"
    
    if not html_path.exists():
        print("[错误] 找不到动画文件")
        return False
    
    # 构建 URL
    url = f"file:///{html_path.absolute()}?duration={duration * 1000}"
    
    try:
        # 使用 Chrome/Edge 浏览器，后台运行
        # --start-fullscreen: 全屏
        # --new-window: 新窗口
        # --app: 应用模式（无地址栏）
        
        # 尝试查找 Chrome 或 Edge
        chrome_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
        ]
        
        browser_path = None
        for path in chrome_paths:
            if os.path.exists(path):
                browser_path = path
                break
        
        if browser_path:
            cmd = [
                browser_path,
                "--start-fullscreen",
                "--new-window",
                "--app=" + url
            ]
        else:
            # 回退到默认浏览器
            import webbrowser
            webbrowser.open(url, new=1)
            print(f"[超级拆解] 动画已启动（{duration}秒后自动消失）")
            return True
        
        # 后台运行，不显示控制台窗口
        subprocess.Popen(
            cmd,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0
        )
        
        print(f"[超级拆解] 动画已启动（{duration}秒后自动消失）")
        return True
        
    except Exception as e:
        print(f"[错误] 无法启动动画: {e}")
        return False


def main():
    if len(sys.argv) > 1:
        try:
            duration = int(sys.argv[1])
        except ValueError:
            duration = 5
    else:
        duration = 5
    
    show_super_decomposition(duration)


if __name__ == "__main__":
    main()
