#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
反思校验器
执行实时反思校验，核对操作结果与预期目标的一致性
"""

import json
import sys
from typing import Dict, List


class ReflectionValidator:
    """反思校验器"""
    
    def __init__(self):
        self.checklist = []
    
    def validate_operation(self, operation: str, expected_result: str, 
                          actual_result: str, context: Dict = None) -> Dict:
        """
        校验操作结果
        
        Args:
            operation: 执行的操作
            expected_result: 预期结果
            actual_result: 实际结果
            context: 上下文信息
        
        Returns:
            {
                "success": bool,
                "consistency_score": float,  # 0-1
                "compliance_check": bool,
                "risk_assessment": str,
                "recommendations": [str],
                "needs_retry": bool
            }
        """
        result = {
            "success": False,
            "consistency_score": 0.0,
            "compliance_check": True,
            "risk_assessment": "low",
            "recommendations": [],
            "needs_retry": False
        }
        
        # 1. 一致性检查
        if expected_result and actual_result:
            # 简单字符串匹配（实际应使用语义相似度）
            if expected_result.lower() in actual_result.lower():
                result["consistency_score"] = 1.0
                result["success"] = True
            elif actual_result.lower() in expected_result.lower():
                result["consistency_score"] = 0.8
                result["success"] = True
            else:
                # 部分匹配
                common_words = set(expected_result.lower().split()) & set(actual_result.lower().split())
                total_words = set(expected_result.lower().split()) | set(actual_result.lower().split())
                if total_words:
                    result["consistency_score"] = len(common_words) / len(total_words)
                    result["success"] = result["consistency_score"] > 0.5
        
        # 2. 合规性检查
        risk_keywords = ["错误", "失败", "异常", "报错", "error", "fail", "exception"]
        if any(kw in str(actual_result).lower() for kw in risk_keywords):
            result["compliance_check"] = False
            result["risk_assessment"] = "high"
            result["recommendations"].append("检测到错误或异常，建议检查执行过程")
            result["needs_retry"] = True
        
        # 3. 风险评估
        if not result["success"]:
            result["risk_assessment"] = "medium"
            result["recommendations"].append("结果与预期不一致，建议重新执行")
            result["needs_retry"] = True
        
        # 4. 添加上下文分析
        if context:
            if context.get("timeout", False):
                result["recommendations"].append("操作超时，建议增加超时时间或优化操作")
                result["needs_retry"] = True
            
            if context.get("permission_error", False):
                result["recommendations"].append("权限不足，建议检查权限配置")
                result["needs_retry"] = False  # 权限问题重试无用
        
        return result
    
    def validate_task_completion(self, task_plan: Dict, execution_log: List[Dict]) -> Dict:
        """
        校验任务完成度
        
        Args:
            task_plan: 任务计划
            execution_log: 执行日志
        
        Returns:
            {
                "completed": bool,
                "completion_rate": float,
                "failed_steps": [str],
                "overall_assessment": str
            }
        """
        total_steps = len(task_plan.get("subtasks", []))
        completed_steps = sum(1 for log in execution_log if log.get("success", False))
        failed_steps = [log.get("step") for log in execution_log if not log.get("success", False)]
        
        completion_rate = completed_steps / total_steps if total_steps > 0 else 0
        
        return {
            "completed": completion_rate >= 0.9,  # 90% 完成度视为完成
            "completion_rate": completion_rate,
            "failed_steps": failed_steps,
            "overall_assessment": "success" if completion_rate >= 0.9 else "partial" if completion_rate >= 0.5 else "failed"
        }
    
    def generate_reflection_report(self, task_name: str, validations: List[Dict]) -> Dict:
        """
        生成反思报告
        
        Returns:
            {
                "task_name": str,
                "overall_success": bool,
                "validation_results": [Dict],
                "lessons_learned": [str],
                "improvement_suggestions": [str]
            }
        """
        all_success = all(v.get("success", False) for v in validations)
        
        lessons = []
        suggestions = []
        
        for v in validations:
            if not v.get("success", False):
                lessons.append(f"操作 '{v.get('operation')}' 未达到预期结果")
                suggestions.extend(v.get("recommendations", []))
        
        if all_success:
            lessons.append("任务执行顺利，所有操作均达到预期")
            suggestions.append("继续保持当前执行策略")
        
        return {
            "task_name": task_name,
            "overall_success": all_success,
            "validation_results": validations,
            "lessons_learned": lessons,
            "improvement_suggestions": list(set(suggestions))  # 去重
        }


def main():
    if len(sys.argv) < 2:
        print("Usage: python reflection_validator.py <command> [args...]")
        print("Commands:")
        print("  validate <operation> <expected> <actual> [context_json]")
        print("  check_completion <task_plan_json> <execution_log_json>")
        sys.exit(1)
    
    command = sys.argv[1]
    validator = ReflectionValidator()
    
    if command == "validate" and len(sys.argv) >= 5:
        context = json.loads(sys.argv[5]) if len(sys.argv) > 5 else None
        result = validator.validate_operation(sys.argv[2], sys.argv[3], sys.argv[4], context)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    elif command == "check_completion" and len(sys.argv) >= 4:
        task_plan = json.loads(sys.argv[2])
        execution_log = json.loads(sys.argv[3])
        result = validator.validate_task_completion(task_plan, execution_log)
        print(json.dumps(result, ensure_ascii=False, indent=2))
    
    else:
        print("Invalid command or arguments")
        sys.exit(1)


if __name__ == "__main__":
    main()
