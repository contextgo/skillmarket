#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HTN (Hierarchical Task Network) 规划器
将复杂任务分解为原子任务，并显示猪猪侠超级拆解动画
"""

import json
import sys
import subprocess
import os
from typing import List, Dict, Literal
from dataclasses import dataclass, asdict
from enum import Enum


class TaskType(Enum):
    COMPOUND = "compound"  # 复合任务，需要继续分解
    PRIMITIVE = "primitive"  # 原子任务，可直接执行


@dataclass
class Task:
    name: str
    type: str  # TaskType value
    action: str = None  # 原子任务的操作
    subtasks: List = None  # 复合任务的子任务
    preconditions: List[str] = None
    effects: List[str] = None
    
    def to_dict(self):
        result = {
            "name": self.name,
            "type": self.type,
        }
        if self.action:
            result["action"] = self.action
        if self.subtasks:
            result["subtasks"] = [t.to_dict() if isinstance(t, Task) else t for t in self.subtasks]
        if self.preconditions:
            result["preconditions"] = self.preconditions
        if self.effects:
            result["effects"] = self.effects
        return result


class HTNPlanner:
    """HTN 分层任务网络规划器"""
    
    def __init__(self):
        self.methods = {}  # 任务分解方法库
    
    def decompose(self, task: Task, depth: int = 0, max_depth: int = 5) -> Task:
        """
        递归分解任务
        
        Args:
            task: 待分解的任务
            depth: 当前深度
            max_depth: 最大深度
        
        Returns:
            分解后的任务树
        """
        if depth >= max_depth:
            # 达到最大深度，转为原子任务
            task.type = TaskType.PRIMITIVE.value
            return task
        
        if task.type == TaskType.PRIMITIVE.value:
            return task
        
        # 查找分解方法
        if task.name in self.methods:
            method = self.methods[task.name]
            task.subtasks = method(task)
        
        # 递归分解子任务
        if task.subtasks:
            for i, subtask in enumerate(task.subtasks):
                if isinstance(subtask, Task):
                    task.subtasks[i] = self.decompose(subtask, depth + 1, max_depth)
        
        return task
    
    def build_dag(self, task: Task) -> Dict:
        """
        从任务树构建 DAG 有向无环图
        
        Returns:
            {
                "nodes": [任务列表],
                "edges": [(前置, 后继)],
                "parallel_groups": [[可并行任务]]
            }
        """
        nodes = []
        edges = []
        
        def traverse(t: Task, parent=None):
            node_id = t.name
            nodes.append({
                "id": node_id,
                "type": t.type,
                "action": t.action
            })
            
            if parent:
                edges.append((parent, node_id))
            
            if t.subtasks:
                for subtask in t.subtasks:
                    if isinstance(subtask, Task):
                        traverse(subtask, node_id)
        
        traverse(task)
        
        # 识别可并行任务组（同一层的子任务）
        parallel_groups = []
        
        def find_parallel(t: Task):
            if t.subtasks and len(t.subtasks) > 1:
                group = [st.name for st in t.subtasks if isinstance(st, Task)]
                if len(group) > 1:
                    parallel_groups.append(group)
                for subtask in t.subtasks:
                    if isinstance(subtask, Task):
                        find_parallel(subtask)
        
        find_parallel(task)
        
        return {
            "nodes": nodes,
            "edges": edges,
            "parallel_groups": parallel_groups
        }
    
    def add_method(self, task_name: str, method_func):
        """添加任务分解方法"""
        self.methods[task_name] = method_func


def create_file_analysis_task(folder_path: str) -> Task:
    """创建文件分析任务的 HTN"""
    
    # 定义分解方法
    def decompose_analyze_files(task):
        return [
            Task("安全检测", TaskType.PRIMITIVE.value, action="security_scan"),
            Task("创建工作区", TaskType.PRIMITIVE.value, action="create_workspace"),
            Task("拉取资源", TaskType.COMPOUND.value, subtasks=[
                Task("遍历文件夹", TaskType.PRIMITIVE.value, action="list_files"),
                Task("读取文件内容", TaskType.PRIMITIVE.value, action="read_files"),
            ]),
            Task("文件语义嵌入", TaskType.PRIMITIVE.value, action="embed_semantics"),
            Task("生成报告", TaskType.PRIMITIVE.value, action="generate_report"),
        ]
    
    planner = HTNPlanner()
    planner.add_method("分析文件夹", decompose_analyze_files)
    
    root = Task("分析文件夹", TaskType.COMPOUND.value)
    root = planner.decompose(root)
    
    return root


def show_super_decomposition_animation(task_name: str, duration: int = 5):
    """
    显示超级拆解大字动画
    在屏幕中央显示"超级拆解"四个大字，持续指定秒后消失
    """
    script_path = os.path.join(os.path.dirname(__file__), "super_decomposition.py")
    
    try:
        # 使用 subprocess 启动动画（非阻塞）
        subprocess.Popen(
            [sys.executable, script_path, str(duration)],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=subprocess.CREATE_NEW_CONSOLE if sys.platform == 'win32' else 0
        )
        print(f"[超级拆解] 正在拆解任务: {task_name}")
    except Exception as e:
        print(f"动画启动失败: {e}")


def main():
    if len(sys.argv) < 2:
        print("Usage: python htn_planner.py '<task_name>' [folder_path] [--show-animation]")
        sys.exit(1)
    
    task_name = sys.argv[1]
    folder_path = None
    show_animation = "--show-animation" in sys.argv
    
    for arg in sys.argv[2:]:
        if not arg.startswith("--"):
            folder_path = arg
    
    if task_name == "分析文件夹" and folder_path:
        task = create_file_analysis_task(folder_path)
    else:
        # 通用任务
        planner = HTNPlanner()
        root = Task(task_name, TaskType.COMPOUND.value)
        root = planner.decompose(root)
        task = root
    
    # 显示超级拆解动画
    if show_animation:
        show_super_decomposition_animation(task_name, duration=5)
    
    # 构建 DAG
    planner = HTNPlanner()
    dag = planner.build_dag(task)
    
    result = {
        "task_tree": task.to_dict(),
        "dag": dag
    }
    
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
