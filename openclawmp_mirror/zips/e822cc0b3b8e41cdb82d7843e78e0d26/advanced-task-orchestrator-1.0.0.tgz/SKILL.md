---
name: advanced-task-orchestrator
displayName: 任务の---超!级!!拆!!!解!!!!
description: |
  这个skill可以把你的巨型任务以万钧之力拆开，步步为营！
  
  多重记忆保护让您对agent无比放心，反思验证更是让您舒心省力！确保任务全速前进！
  
  核心能力：
  - ⚡ 超级拆解动画 - 任务拆解时全屏大字动画
  - 🧠 HTN 分层任务网络 - 复杂任务递归分解
  - 📊 DAG 依赖图构建 - 智能调度执行顺序
  - 💾 三层记忆管理 - 短期/中期/长期记忆沉淀
  - 🔍 实时反思校验 - 确保执行质量
  - 📁 多模态文件处理 - 图片/文件夹/多文件解析
  
  Use when: 需要处理复杂任务、多步骤工作流、任务拆解、记忆管理
---

# 任务の---超!级!!拆!!!解!!!! (Advanced Task Orchestrator)

## 核心目标

修复 Step 原生 Assistant/Stepclaw 的任务拆分缺陷，实现：
1. 用户请求全生命周期的标准化处理
2. 多模态文件解析
3. 模型动态路由
4. 分级任务拆解与可靠执行
5. 全周期分层记忆管理

## 执行流程

### 一、请求入口与前置处理流程

#### 触发条件
用户发起任意请求时，立即启动本 Skill 全流程。

#### 第一步：读取分层记忆库
```python
# 读取历史数据
memory_search(query="同类任务执行案例")
memory_search(query="用户偏好数据")
memory_search(query="模型配置历史")
```

#### 第二步：请求标准化处理
- 统一语义表达格式
- 剔除无效冗余信息
- 补全基础语义上下文

#### 第三步：文件包含判断

**分支 1：请求包含文件资源**

1. **图片文件判断**
   - 若为图片：图像理解 → 图片语义提取 → 进入文件夹判断
   - 若为非图片：直接进入文件夹判断

2. **文件夹包含判断**
   - 若为文件夹：安全检测 → 创建工作区 → 拉取全部资源 → 文件语义嵌入
   - 若不为文件夹：进入多文件判断

3. **多文件判断**
   - 若为多文件：安全检测 → 创建工作区 → 文件语义嵌入
   - 若为单文件：安全检测 → 直接解析 → 文件语义嵌入
   - ⚠️ **注意**：使用阅读工具时，Number 浮点数转换为 int32 整数再注入

4. **完成后**：进入模型调度流程

**分支 2：请求不包含文件资源**

1. 安全分级检查（内容合规性与风险等级判定）
2. 自然语言语义整理（补全逻辑、明确需求边界）
3. 完成后进入模型调度流程

---

### 二、模型调度与推理优化流程

#### 第一步：确认工具可用性
```python
# 检查所需工具
sessions_list()  # 查看可用会话
agents_list()    # 查看可用 agents
```

#### 第二步：确认 LLM 状态
```python
session_status()  # 检查当前模型状态
```

#### 第三步：任务分级判断

基于以下维度将任务分为 4 类：
- 需求复杂度
- 是否需要工具/Agent 调用
- 任务链路长度

| 维度 | 简单 | 中等 | 复杂 |
|------|------|------|------|
| 复杂度 | 单步、明确 | 多步、较明确 | 多阶段、模糊 |
| 工具调用 | 不需要 | 需要 | 需要 |
| 链路长度 | 1-2 步 | 3-5 步 | 5+ 步 |

---

### 三、分级任务执行核心流程

#### 分支 1：简单/中等难度 · 无需 Agent 调用

```
用户请求
    ↓
调用弱/中等能力 LLM 直接推理
    ↓
生成完整回答
    ↓
短期记忆沉淀（请求、推理、回答）
    ↓
输出结果 → 结束
```

**记忆写入**：
```python
# 短期记忆（当前对话）
write(file_path="memory/short_term.json", content={...})
```

---

#### 分支 2：简单/中等难度 · 需要 Agent 调用

```
用户请求
    ↓
启动 HTN 规划器 → 原子化任务拆解
    ↓
需求清晰度校验
    ├── 不清晰 → 询问用户 → 重新拆解
    └── 清晰 → 继续
    ↓
构建 DAG 依赖图（执行顺序、依赖、并行规则）
    ↓
环境感知监听（系统状态、工具可用性、权限、资源）
    ↓
环境适配 + 工具准备 + 权限校验
    ↓
决策最优执行方式 → 调度工具/能力执行
    ↓
实时反思校验（中等能力 LLM）
    ↓
操作成功性校验
    ├── 成功 → 中期记忆沉淀 → 输出结果 → 结束
    └── 失败 → HTN 重规划 → 重新执行（循环直至成功）
```

**关键步骤详解**：

**1. HTN 任务拆解**
```python
# 复合任务 → 子任务 → 原子任务
task_hierarchy = {
    "task": "主任务",
    "subtasks": [
        {"name": "子任务1", "type": "compound", "subtasks": [...]},
        {"name": "子任务2", "type": "primitive", "action": "..."}
    ]
}
```

**2. DAG 构建**
```python
# 有向无环图
dag = {
    "nodes": ["task1", "task2", "task3"],
    "edges": [("task1", "task2"), ("task2", "task3")],  # task1 → task2 → task3
    "parallel_groups": [["task1", "task2"]]  # 可并行
}
```

**3. 实时反思校验**
```python
# 执行中同步反思
sessions_spawn(
    task="反思当前操作：结果是否符合预期？有无异常风险？",
    runtime="subagent",
    timeoutSeconds=30
)
```

**4. 记忆写入**：
```python
# 中期记忆（任务级别）
write(file_path="memory/medium_term.json", content={
    "task_plan": "...",
    "execution_process": "...",
    "results": "...",
    "reflection": "..."
})
```

---

#### 分支 3：复杂难度 · 无需 Agent 调用

```
用户请求
    ↓
Chain-of-Thought 思维链推理
    ↓
异步研讨机制（多模型交叉校验、优化、风险排查）
    ↓
提示注入安全检测 + 内容合规校验
    ↓
生成结构化最终回答
    ↓
长期记忆沉淀（需求、推理全流程、研讨结果、回答）
    ↓
输出结果 → 结束
```

**记忆写入**：
```python
# 长期记忆（跨会话）
write(file_path="memory/long_term.json", content={...})
```

---

#### 分支 4：复杂难度 · 需要 Agent 调用

```
用户请求
    ↓
强能力 LLM + HTN 联合拆解
    ├── 分层、分阶段原子化
    ├── 明确总目标、阶段里程碑
    ├── 原子任务、依赖关系、风险预案
    ↓
需求清晰度校验
    ├── 不清晰 → 询问用户 → 重新联合拆解
    └── 清晰 → 继续
    ↓
检索分层记忆库 → 召回同类案例 → 优化方案
    ↓
构建全链路 DAG（顺序、依赖、并行、里程碑）
    ↓
异步研讨机制 → 交叉校验、风险评估、路径优化
    ↓
全链路环境适配 + 工具链调度 + 权限校验 + 异常监控
    ↓
分阶段执行 → 调度工具/能力/Agent
    ↓
全流程实时反思校验（强能力 LLM）
    ↓
操作成功性校验
    ├── 成功 → 长期记忆沉淀 → 输出结果 → 结束
    └── 失败 → HTN 重规划 → 重新执行（循环直至成功）
```

**记忆写入**：
```python
# 长期记忆（完整任务档案）
write(file_path="memory/long_term.json", content={
    "task_decomposition": "...",
    "full_execution": "...",
    "reflection_results": "...",
    "success_case": "...",
    "optimization_experience": "..."
})
```

---

## 记忆管理架构

### 三层记忆体系

| 层级 | 范围 | 存储位置 | 用途 |
|------|------|---------|------|
| **短期记忆** | 当前对话 | `memory/short_term.json` | 当前上下文、临时数据 |
| **中期记忆** | 任务级别 | `memory/medium_term.json` | 任务历史、执行案例 |
| **长期记忆** | 跨会话 | `memory/long_term.json` | 用户偏好、成功案例 |

### 记忆写入时机

```python
# 短期记忆：每次对话后
if task_completed:
    append_to_short_term(request, reasoning, response)

# 中期记忆：任务执行成功后
if task_success and used_agent:
    append_to_medium_term(plan, process, results, reflection)

# 长期记忆：复杂任务完成后
if complex_task_completed:
    append_to_long_term(full_context)
```

---

## 模型路由策略

### 模型选择矩阵

| 任务类型 | 推荐模型 | 原因 |
|---------|---------|------|
| 简单问答 | stepfun/step-alpha | 快速、准确 |
| 中等复杂度 | stepfun/step-alpha | 平衡性能 |
| 复杂推理 | stepfun/step-alpha + reasoning | 深度思考 |
| 视觉任务 | stepfun/vision-model | 多模态 |
| 代码任务 | ACP (Agent Coding Protocol) | 专业编码 |

### 动态路由逻辑

```python
def route_model(task_complexity, requires_tools, task_length):
    if task_complexity == "simple" and not requires_tools:
        return "stepfun/step-alpha"
    elif task_complexity == "medium" and requires_tools:
        return "stepfun/step-alpha"  # 可能启用 reasoning
    elif task_complexity == "complex":
        return "stepfun/step-alpha"  # 启用 reasoning
    else:
        return "stepfun/step-alpha"
```

---

## 使用示例

### 示例 1：简单任务（直接推理）

```
用户：今天天气怎么样？

执行流程：
1. 读取记忆库（获取位置偏好）
2. 标准化请求
3. 无文件 → 安全检测 → 语义整理
4. 任务分级：简单、无需工具
5. 调用弱 LLM → 生成回答
6. 短期记忆沉淀
7. 输出结果
```

### 示例 2：中等复杂度 + Agent 调用

```
用户：分析这个文件夹中的所有 Excel 文件，生成汇总报告

执行流程：
1. 读取记忆库
2. 标准化请求
3. 包含文件夹 → 安全检测 → 创建工作区 → 拉取资源
4. 任务分级：中等、需要工具
5. HTN 拆解：
   - 读取所有 Excel 文件
   - 解析数据结构
   - 汇总统计
   - 生成报告
6. 构建 DAG
7. 环境感知
8. 调度执行
9. 实时反思
10. 中期记忆沉淀
11. 输出结果
```

### 示例 3：复杂任务 + Agent 调用

```
用户：帮我开发一个完整的项目管理工具，包括前端界面、后端 API 和数据库设计

执行流程：
1. 读取记忆库（召回同类开发案例）
2. 标准化请求
3. 无文件 → 安全检测 → 语义整理
4. 任务分级：复杂、需要工具
5. 强 LLM + HTN 联合拆解：
   - 阶段 1：需求分析
   - 阶段 2：数据库设计
   - 阶段 3：后端 API 开发
   - 阶段 4：前端界面开发
   - 阶段 5：集成测试
6. 需求清晰度校验
7. 检索记忆库优化方案
8. 构建全链路 DAG
9. 异步研讨机制
10. 全链路准备
11. 分阶段执行
12. 全流程反思
13. 长期记忆沉淀
14. 输出结果
```

---

## 错误处理与重试

### HTN 重规划机制

```python
def htn_replan(failure_reason, reflection_result):
    # 分析失败原因
    # 调整任务拆解方案
    # 更新执行路径
    # 重新执行
    pass
```

### 重试策略

| 失败类型 | 策略 |
|---------|------|
| 临时错误 | 立即重试（最多 3 次）|
| 权限错误 | 请求用户授权 |
| 资源不足 | 等待后重试或降级 |
| 逻辑错误 | HTN 重规划 |

---

## 最佳实践

1. **始终先读取记忆库** - 利用历史经验
2. **严格任务分级** - 避免过度设计或设计不足
3. **及时记忆沉淀** - 每次任务后更新记忆
4. **充分反思校验** - 确保执行质量
5. **优雅失败处理** - HTN 重规划而非简单重试

---

## 参考

- HTN (Hierarchical Task Network) 规划
- DAG (Directed Acyclic Graph) 任务调度
- Chain-of-Thought 推理
- 分层记忆管理系统
