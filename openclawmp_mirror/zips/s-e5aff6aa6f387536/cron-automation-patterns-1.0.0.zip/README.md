# Cron Automation Patterns

Battle-tested patterns for building reliable 24/7 autonomous AI agent systems using OpenClaw cron jobs. Based on real production deployment of a Polymarket monitoring system running 35+ consecutive hours.

## Pattern 1: Periodic Monitor

Best for: News monitoring, price tracking, status checks

```
Cron: Every hour
├── Fetch data from N sources
├── Score/process signals
├── Generate report
├── Save state to file
└── Alert if threshold exceeded
```

**Key principles:**
- Never depend on previous run state (assume fresh start)
- Minimum 4/N sources for valid report
- 2-second delay between API calls (rate limit)
- Skip failed sources, never fail the whole job

## Pattern 2: Batch Publisher

Best for: Asset publishing, content distribution, report generation

```
Cron: Every 4 hours
├── Check pending items in queue directory
├── Validate each item (format, size, duplicates)
├── Publish with 2-second interval between items
├── Move successful items to published/
├── Log failures for retry
└── Report summary
```

## Pattern 3: Stateful Pipeline

Best for: Multi-step processes that span multiple cron cycles

```
Cron: Every 2 hours
├── Read STATE.yaml for current pipeline position
├── Continue from last checkpoint
├── Process next batch
├── Update STATE.yaml with progress
├── Check pipeline completion
└── Send summary on completion
```

## Error Recovery Patterns

### Circuit Breaker
```python
MAX_CONSECUTIVE_FAILURES = 3
if consecutive_failures >= MAX_CONSECUTIVE_FAILURES:
    alert("Pipeline disabled after 3 failures")
    disable_cron_job()
```

### Exponential Backoff
```python
delay = min(2 ** attempt, 60)  # Max 60s
time.sleep(delay)
```

### Graceful Degradation
```python
# If primary source fails, use fallback
data = fetch_primary() or fetch_fallback() or fetch_cached()
```

## State Management

**Always use file-based state:**
```yaml
# STATE.yaml
pipeline:
  current_step: "aggregate"
  last_run: "2026-03-13T09:00:00Z"
  items_processed: 42
  status: "running"
```

**Why files?** Context compression erases in-memory state. Files survive restarts.

## Reliability Checklist

- [ ] Can this job fail without blocking others?
- [ ] Does it save state before and after critical operations?
- [ ] Is there a maximum execution timeout?
- [ ] Are external API calls rate-limited and retried?
- [ ] Does the job log its own execution status?
- [ ] Can a human understand the state file after a crash?
- [ ] Are secrets/credentials never written to log files?

## Scheduling Best Practices

| Task Type | Recommended Frequency |
|-----------|----------------------|
| News monitoring | Every 1 hour |
| Asset publishing | Every 4 hours |
| Health check | Every 30 minutes |
| Memory cleanup | Every 6 hours |
| Skill discovery | Every 4 hours |
| Report generation | Daily at fixed time |