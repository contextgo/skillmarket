"""
小红书主站登录模块

目标：获取主站互动权限（评论/点赞/收藏）
关键点：必须在同一个浏览器会话里生成二维码并等待扫码成功。
"""

import json
import os
import sys
import time
from typing import Dict, Any, Optional, Tuple

from .client import XiaohongshuClient, DEFAULT_COOKIE_PATH

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(SKILL_DIR, 'data')
MAIN_QRCODE_PATH = os.path.join(DATA_DIR, 'main_qrcode.png')
DEFAULT_MAIN_STATE_PATH = os.path.expanduser('~/.xiaohongshu/main_storage_state.json')


class MainSiteLoginAction:
    def __init__(self, client: XiaohongshuClient):
        self.client = client

    def open_login_modal(self):
        self.client.navigate('https://www.xiaohongshu.com/explore')
        time.sleep(4)

    def capture_qrcode(self) -> Optional[str]:
        page = self.client.page
        os.makedirs(DATA_DIR, exist_ok=True)
        selectors = [
            'img.qrcode-img',
            'img[src^="data:image"]',
            'canvas',
        ]
        for sel in selectors:
            try:
                loc = page.locator(sel).first
                if loc.count() > 0 and loc.is_visible():
                    loc.screenshot(path=MAIN_QRCODE_PATH)
                    print(f'主站二维码已保存到: {MAIN_QRCODE_PATH}', file=sys.stderr)
                    return MAIN_QRCODE_PATH
            except Exception:
                pass
        return None

    def is_logged_in(self) -> Tuple[bool, Optional[str]]:
        page = self.client.page
        try:
            body = page.locator('body').inner_text()[:3000]
        except Exception:
            body = ''
        blocked = [
            '马上登录即可',
            '登录后评论',
            '登录继续查看该笔记',
            '登录查看全部评论内容',
        ]
        is_logged = not any(x in body for x in blocked)
        return is_logged, page.url

    def wait_for_login(self, timeout: int = 180) -> bool:
        start = time.time()
        while time.time() - start < timeout:
            ok, _ = self.is_logged_in()
            if ok:
                self.client._save_cookies()
                return True
            time.sleep(2)
        return False


def login_main(
    headless: bool = True,
    cookie_path: str = DEFAULT_COOKIE_PATH,
    storage_state_path: str = DEFAULT_MAIN_STATE_PATH,
    timeout: int = 180,
) -> Dict[str, Any]:
    client = XiaohongshuClient(
        headless=headless,
        cookie_path=cookie_path,
        storage_state_path=storage_state_path,
    )
    try:
        client.start()
        action = MainSiteLoginAction(client)
        action.open_login_modal()

        ok, url = action.is_logged_in()
        if ok:
            client._save_cookies()
            return {
                'status': 'logged_in',
                'qrcode_path': None,
                'storage_state_path': storage_state_path,
                'url': url,
                'message': '主站已登录',
            }

        qr = action.capture_qrcode()
        if not qr:
            return {
                'status': 'error',
                'message': '获取主站二维码失败',
            }

        success = action.wait_for_login(timeout=timeout)
        if success:
            return {
                'status': 'logged_in',
                'qrcode_path': None,
                'storage_state_path': storage_state_path,
                'url': client.page.url,
                'message': '主站扫码登录成功',
            }

        return {
            'status': 'timeout',
            'qrcode_path': qr,
            'storage_state_path': storage_state_path,
            'message': '主站扫码超时',
        }
    finally:
        client.close()


def check_main_login(
    headless: bool = True,
    cookie_path: str = DEFAULT_COOKIE_PATH,
    storage_state_path: str = DEFAULT_MAIN_STATE_PATH,
) -> Dict[str, Any]:
    client = XiaohongshuClient(
        headless=headless,
        cookie_path=cookie_path,
        storage_state_path=storage_state_path,
    )
    try:
        client.start()
        action = MainSiteLoginAction(client)
        action.open_login_modal()
        ok, url = action.is_logged_in()
        return {
            'is_logged_in': ok,
            'url': url,
            'storage_state_path': storage_state_path,
        }
    finally:
        client.close()
