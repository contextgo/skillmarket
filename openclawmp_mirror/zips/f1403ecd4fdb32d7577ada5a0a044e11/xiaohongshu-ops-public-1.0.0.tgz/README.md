# xiaohongshu-ops-public

小红书浏览、发帖与互动自动化技能。

## 这是什么

这是一个基于 Python + Playwright 的 OpenClaw Skill，用于操作小红书（xiaohongshu / rednote），覆盖两类核心场景：

1. **创作者后台发帖**
   - 图文发布
   - Markdown 渲染后发布
   - 视频发布

2. **主站互动操作**
   - 主站扫码登录
   - 评论帖子
   - 点赞 / 收藏 / 取消点赞 / 取消收藏

## 适用场景

当 Agent 需要在小红书上执行以下任务时使用：
- 搜索笔记
- 获取帖子详情
- 查看用户主页
- 发布图文/视频笔记
- 在主站评论别人帖子
- 做点赞、收藏等互动操作

## 核心特点

- 支持 **创作者后台** 与 **主站互动** 两套登录态
- 支持 **Firefox** 浏览器内核（在 Linux 无头环境更稳定）
- 支持保存并复用 **storage state**，便于主站评论链路稳定执行
- 包含 CLI 入口，可直接用 `python -m scripts ...` 调用

## 安装依赖

在技能目录下执行：

```bash
pip install -r requirements.txt
playwright install chromium firefox
```

Linux/WSL 环境可额外执行：

```bash
playwright install-deps chromium firefox
```

## 常用命令

### 创作者后台登录 / 发帖

```bash
python -m scripts qrcode --headless=false
python -m scripts check-login
python -m scripts publish --title "标题" --content "正文" --images ./a.jpg --auto-publish
```

### 主站互动登录 / 评论

```bash
python -m scripts main-login --headless=true
python -m scripts check-main-login --headless=true
python -m scripts comment --url "完整笔记URL" --storage-state ~/.xiaohongshu/main_storage_state.json --content "评论内容"
```

## 已验证经验

- Firefox 在当前 Linux 无头环境下比 Chromium 更稳
- 创作者后台登录态与主站互动登录态需要分开维护
- 主站扫码登录后，建议优先复用 `storage_state` 做后续评论互动

## 注意

- 请遵守小红书平台规则与当地法律法规
- 频繁互动可能触发平台风控，请控制节奏
- 登录态会过期，需要视情况重新扫码
