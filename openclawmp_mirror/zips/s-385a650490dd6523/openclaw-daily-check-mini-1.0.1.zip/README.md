# OpenClaw Daily Check Mini

## 目标

用最短路径完成一次 OpenClaw 健康巡检，快速判断系统是否可用，并给出下一步动作。

## 适用场景

- 网关疑似不稳定
- 消息回复延迟或无回复
- 每日例行运维检查

## 执行步骤

1. 执行 `openclaw gateway status`
2. 执行 `openclaw health`
3. 若服务模式不可用，执行 `openclaw gateway run --force`
4. 再次执行 `openclaw gateway status` 验证恢复结果

## 输出格式

- 结论
- 依据
- 风险
- 执行步骤