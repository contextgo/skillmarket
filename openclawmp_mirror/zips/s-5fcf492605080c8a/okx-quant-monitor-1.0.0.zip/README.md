# OKX量化交易监控

实时监控OKX网格交易机器人状态，自动获取大盘数据。

## 前提条件

1. 安装OKX CLI：
```bash
npm install -g @okx_ai/okx-trade-cli
```

2. 配置Demo API：
```bash
# 在 ~/.okx/config.toml 中配置
[default]
api_key = "3e4f7c74-7aa2-450f-9bb8-7ff602ed25c6"
secret_key = "1C289154EBEDEAE9170A596D0521CC19"
passphrase = "Tongqiuran@1234"
demo = true
```

## 常用命令

### 启动网格交易机器人
```bash
export OKX_API_KEY="3e4f7c74-7aa2-450f-9bb8-7ff602ed25c6"
export OKX_SECRET_KEY="1C289154EBEDEAE9170A596D0521CC19"
export OKX_PASSPHRASE="Tongqiuran@1234"

# 创建BTC-USDT网格机器人
npx okx --demo bot grid create --instId BTC-USDT --algoOrdType grid --maxPx 75000 --minPx 65000 --gridNum 10 --quoteSz 1000
```

### 查看机器人状态
```bash
npx okx --demo bot grid orders --algoOrdType grid
```

### 停止机器人
```bash
npx okx --demo bot grid stop --algoId 机器人ID --algoOrdType grid --instId BTC-USDT
```

### 获取大盘数据
```bash
npx okx --demo market ticker BTC-USDT
npx okx --demo market ticker ETH-USDT
npx okx --demo market ticker SOL-USDT
```

### 查看账户余额
```bash
npx okx --demo account balance
```

## 监控脚本

位置：`~/.openclaw/scripts/okx-monitor.sh`

运行：
```bash
~/.openclaw/scripts/okx-monitor.sh
```

## 策略说明

### 网格交易策略
- 价格范围：65000-75000 USDT
- 网格数：10
- 方向：做多
- 适用场景：震荡行情

### 定时监控
- 频率：每5分钟
- 内容：大盘数据、机器人状态、账户余额

## 风险提示

- 模拟交易，仅供测试
- 网格交易适用于震荡行情
- 趋势行情可能导致亏损
- 请谨慎设置止盈止损