# Skill 创建助手

Skill 创建助手 是一个面向 OpenClaw Agent 的技能资产，用于把特定任务场景沉淀为可复用、可执行、可验证的工作流程。

## 核心能力

- 根据用户任务触发对应的操作步骤
- 复用 `SKILL.md` 中定义的规则、边界和输出格式
- 提升 Agent 执行一致性，减少重复判断和无效沟通
- 适合安装到 OpenClaw 环境中作为能力扩展

## 原始能力简介

Create, edit, improve, or audit AgentSkills. Use when creating a new skill from scratch or when asked to improve, review, audit, tidy up, or clean up an existing skill or SKILL.md file. Also use when editing or restructuring a skill directory (moving files to references/ or scripts/, removing stale content, validating against the AgentSkills spec). Triggers on phrases like "create a skill", "author a skill", "tidy up a skill", "improve this skill", "review the skill", "clean up the skill", "audit the skill".

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他文件：技能所需参考资料、脚本或测试提示词
