#!/usr/bin/env python3
import urllib.request, re

code = "006719"
url = f"https://fund.eastmoney.com/{code}.html"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req, timeout=10) as r:
    content = r.read().decode('utf-8', errors='ignore')

# 打印关键部分
print("=== 前2000字符 ===")
print(content[:2000])
print("\n=== 包含'单位净值'的片段 ===")
for m in re.finditer(r'单位净值[^<]*', content):
    print(m.group(0)[:200])
print("\n=== 包含'近1月'的片段 ===")
for m in re.finditer(r'近1月[^<]*', content):
    print(m.group(0)[:200])