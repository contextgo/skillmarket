#!/usr/bin/env python3
"""
Fund Analysis Skill: 基金对比
用法: compare_funds.py <基金代码1> <基金代码2>
"""

import sys
import subprocess
import re

def get_fund_data(code):
    """获取基金数据（调用 query_fund.py 并解析输出）"""
    try:
        result = subprocess.run(
            ['python3', '/root/.openclaw/workspace/skills/fund-analysis/scripts/query_fund.py', code],
            capture_output=True,
            text=True,
            timeout=15
        )
        if result.returncode != 0:
            return None
        return result.stdout
    except Exception as e:
        print(f"❌ 查询 {code} 失败: {e}")
        return None

def parse_fund_info(output):
    """从 query_fund 输出中提取结构化信息"""
    info = {
        'code': '',
        'name': '',
        'nav': '',
        'day_growth': '',
        'returns': {},
        'top10_ratio': '',
        'turnover': ''
    }

    lines = output.split('\n')
    for line in lines:
        line = line.strip()
        # 基金代码
        if line.startswith('基金代码:'):
            info['code'] = line.split(':', 1)[1].strip()
        # 基金名称
        elif line.startswith('基金名称:'):
            info['name'] = line.split(':', 1)[1].strip()
        # 单位净值
        elif line.startswith('单位净值:'):
            info['nav'] = line.split(':', 1)[1].strip()
        # 日增长
        elif line.startswith('日增长:'):
            info['day_growth'] = line.split(':', 1)[1].strip()
        # 业绩表现
        elif '近1周' in line or '近1月' in line or '近3月' in line or '近6月' in line or '今年来' in line or '近1年' in line or '近3年' in line:
            parts = line.split()
            if len(parts) >= 2:
                period = parts[0].strip()
                value = parts[1].strip()
                if value != '--':
                    info['returns'][period] = value
        # 前十大
        elif line.startswith('前十大持仓占比:'):
            info['top10_ratio'] = line.split(':', 1)[1].strip()
        # 换手率
        elif line.startswith('基金换手率:'):
            info['turnover'] = line.split(':', 1)[1].strip()

    return info

def format_comparison(fund1, fund2):
    """格式化对比输出"""
    print(f"\n{'='*80}")
    print(f"📊 基金对比报告")
    print('='*80)

    # 基本信息对比
    print(f"\n{'项目':<15} {fund1['code']:<15} {fund2['code']:<15} {'差异':<10}")
    print('-'*80)
    print(f"{'基金名称':<15} {fund1['name'][:12]:<15} {fund2['name'][:12]:<15} {'':<10}")
    print(f"{'单位净值':<15} {fund1['nav']:<15} {fund2['nav']:<15} {calc_diff(fund1['nav'], fund2['nav']):<10}")
    print(f"{'日增长':<15} {fund1['day_growth']:<15} {fund2['day_growth']:<15} {calc_diff(fund1['day_growth'], fund2['day_growth']):<10}")
    print(f"{'前十大占比':<15} {fund1['top10_ratio']:<15} {fund2['top10_ratio']:<15} {'':<10}")
    print(f"{'换手率':<15} {fund1['turnover']:<15} {fund2['turnover']:<15} {'':<10}")

    # 业绩对比
    print(f"\n{'业绩表现对比':<40}")
    print('-'*80)
    periods = ['近1周', '近1月', '近3月', '近6月', '今年来', '近1年', '近3年']
    print(f"{'周期':<10} {fund1['code']:<15} {fund2['code']:<15} {'差异':<15} {'领先方':<10}")
    print('-'*80)
    for period in periods:
        v1 = fund1['returns'].get(period, '--')
        v2 = fund2['returns'].get(period, '--')
        diff = '--'
        leader = '--'
        if v1 != '--' and v2 != '--':
            diff = calc_diff(v1, v2)
            # 判断谁领先
            try:
                n1 = float(v1.strip('%'))
                n2 = float(v2.strip('%'))
                if n1 > n2:
                    leader = fund1['code']
                elif n2 > n1:
                    leader = fund2['code']
            except:
                pass
        print(f"{period:<10} {v1:<15} {v2:<15} {diff:<15} {leader:<10}")

    print(f"\n{'='*80}")
    print("💡 提示：收益率均为百分比，差异 = 左 - 右")
    print("="*80)

def calc_diff(val1, val2):
    """计算两个百分比数值的差异"""
    try:
        if val1 == '--' or val2 == '--':
            return '--'
        n1 = float(val1.strip('%'))
        n2 = float(val2.strip('%'))
        diff = n1 - n2
        sign = '+' if diff > 0 else ''
        return f"{sign}{diff:.2f}%"
    except:
        return '--'

def main():
    if len(sys.argv) != 3:
        print("用法: compare_funds.py <基金代码1> <基金代码2>")
        print("示例: compare_funds.py 006719 000001")
        sys.exit(1)

    code1, code2 = sys.argv[1], sys.argv[2]

    print(f"🔍 查询基金 {code1} 和 {code2} 进行对比...")

    # 查询两个基金
    output1 = get_fund_data(code1)
    output2 = get_fund_data(code2)

    if not output1:
        print(f"❌ 无法获取基金 {code1} 的数据")
        sys.exit(1)
    if not output2:
        print(f"❌ 无法获取基金 {code2} 的数据")
        sys.exit(1)

    # 解析
    fund1 = parse_fund_info(output1)
    fund2 = parse_fund_info(output2)

    if not fund1['name'] or not fund2['name']:
        print("❌ 解析数据失败")
        sys.exit(1)

    # 输出对比
    format_comparison(fund1, fund2)

if __name__ == '__main__':
    main()