#!/usr/bin/env python3
"""
Fund Analysis Skill: 批量查询基金
用法: batch_query.py <基金代码1> [<基金代码2> ...]
"""

import sys
import subprocess
import time

def batch_query(codes):
    """批量查询多个基金"""
    results = []
    for code in codes:
        print(f"\n{'='*60}")
        print(f"查询基金: {code}")
        print('='*60)
        try:
            result = subprocess.run(
                ['python3', '/root/.openclaw/workspace/skills/fund-analysis/scripts/query_fund.py', code],
                capture_output=True,
                text=True,
                timeout=15
            )
            if result.returncode == 0:
                print(result.stdout)
                results.append({'code': code, 'output': result.stdout, 'status': 'success'})
            else:
                print(f"❌ 查询失败: {result.stderr}")
                results.append({'code': code, 'error': result.stderr, 'status': 'failed'})
        except subprocess.TimeoutExpired:
            print(f"⏰ 查询超时: {code}")
            results.append({'code': code, 'error': 'Timeout', 'status': 'failed'})
        except Exception as e:
            print(f"❌ 异常: {e}")
            results.append({'code': code, 'error': str(e), 'status': 'failed'})

        time.sleep(1)  # 避免请求过快

    # 汇总摘要
    print(f"\n{'='*60}")
    print("📊 批量查询摘要")
    print('='*60)
    success_count = sum(1 for r in results if r['status'] == 'success')
    print(f"成功: {success_count}/{len(codes)}")
    for r in results:
        status_icon = "✅" if r['status'] == 'success' else "❌"
        print(f"{status_icon} {r['code']}")

    return results

def main():
    if len(sys.argv) < 2:
        print("用法: batch_query.py <基金代码1> [<基金代码2> ...]")
        print("示例: batch_query.py 006719 000001 110022")
        sys.exit(1)

    codes = sys.argv[1:]
    if len(codes) > 10:
        print("⚠️  一次最多查询10个基金，建议分批查询")
        confirm = input("是否继续? (y/N): ").strip().lower()
        if confirm != 'y':
            sys.exit(0)

    batch_query(codes)

if __name__ == '__main__':
    main()