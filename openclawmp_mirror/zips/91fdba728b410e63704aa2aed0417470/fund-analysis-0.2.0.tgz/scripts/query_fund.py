#!/usr/bin/env python3
"""
Fund Analysis Skill: 查询基金信息
用法: query_fund.py <基金代码>
"""

import sys
import re
from datetime import datetime

def fetch_fund_data(fund_code):
    """从天天基金网抓取基金数据"""
    import urllib.request

    url = f"https://fund.eastmoney.com/{fund_code}.html"
    try:
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
            }
        )
        with urllib.request.urlopen(req, timeout=10) as response:
            return response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"❌ 抓取失败: {e}", file=sys.stderr)
        return None

def extract_info(content):
    """从HTML中提取基金信息"""
    info = {
        'code': '',
        'name': '',
        'nav': '',
        'day_growth': '',
        'returns': {},
        'top10_ratio': '',
        'turnover': ''
    }

    # 基金名称
    name_match = re.search(r'<title>([^<]+?)基金[^<]*</title>', content)
    if name_match:
        info['name'] = name_match.group(1).strip()
        info['name'] = re.sub(r'\(\d+\)', '', info['name']).strip()

    # 单位净值
    nav_match = re.search(r'class="ui-font-large[^>]*>([\d]+\.[\d]+)</span>', content)
    if nav_match:
        info['nav'] = nav_match.group(1)

    # 日增长率
    day_growth_match = re.search(r'class="ui-font-middle[^>]*>([+-]?[\d]+\.[\d]+%)</span>', content)
    if day_growth_match:
        info['day_growth'] = day_growth_match.group(1)

    # 各期收益率 - 从业绩表现表格中提取
    # 查找类似 "近1月：-7.58%" 的文本（不含HTML标签）
    # 先去掉HTML标签，保留纯文本
    text_content = re.sub(r'<[^>]+>', ' ', content)  # 替换所有HTML标签为空格
    text_content = re.sub(r'\s+', ' ', text_content)  # 压缩空白

    periods = ['近1周', '近1月', '近3月', '近6月', '今年来', '近1年', '近3年']
    for period in periods:
        # 匹配 "近1月：-7.58%" 或 "近1月 -7.58%" 等
        pattern = f"{period}[：: -]*([+-]?[\d]+\.[\d]+%)"
        match = re.search(pattern, text_content)
        if match:
            info['returns'][period] = match.group(1)
        else:
            info['returns'][period] = '--'

    # 前十大持仓占比
    top10_match = re.search(r'前十[^0-9%]*([\d]+\.[\d]+%)', content)
    if top10_match:
        info['top10_ratio'] = top10_match.group(1)

    # 换手率
    turnover_match = re.search(r'基金换手率[^0-9%]*([\d]+\.[\d]+%)', content)
    if turnover_match:
        info['turnover'] = turnover_match.group(1)

    return info

def format_output(info):
    """格式化输出"""
    print(f"🔍 基金查询结果")
    print(f"==================")
    print(f"基金代码: {info.get('code', '--')}")
    print(f"基金名称: {info.get('name', '--')}")
    print(f"单位净值: {info.get('nav', '--')}")
    print(f"日增长: {info.get('day_growth', '--')}")
    print()
    print(f"📈 业绩表现")
    print(f"------------------")
    for period in ['近1周', '近1月', '近3月', '近6月', '今年来', '近1年', '近3年']:
        ret = info['returns'].get(period, '--')
        print(f"{period:<6} {ret:>8}")
    print()
    print(f"📌 持仓与风险")
    print(f"------------------")
    if info['top10_ratio']:
        print(f"前十大持仓占比: {info['top10_ratio']}")
    else:
        print(f"前十大持仓占比: (未找到)")
    if info['turnover']:
        print(f"基金换手率: {info['turnover']}")
    print()
    print(f"💡 风险提示")
    print(f"------------------")
    print(f"1. 历史业绩不预示未来表现")
    print(f"2. 投资基金需仔细阅读基金合同和招募说明书")
    print(f"3. 市场有风险，投资需谨慎")
    print()
    print(f"📝 数据来源: 天天基金网 (东方财富)")
    print(f"查询时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

def main():
    if len(sys.argv) < 2:
        print("用法: query_fund.py <基金代码>")
        print("示例: query_fund.py 006719")
        sys.exit(1)

    fund_code = sys.argv[1]
    print(f"🔍 查询基金 {fund_code}...")
    print(f"📡 正在从天天基金网抓取数据...")

    content = fetch_fund_data(fund_code)
    if not content:
        print(f"❌ 未找到该基金，请检查代码是否正确")
        sys.exit(1)

    info = extract_info(content)
    info['code'] = fund_code
    format_output(info)

if __name__ == '__main__':
    main()