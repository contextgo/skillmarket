#!/bin/bash
# Fund Analysis Skill: 查询基金信息
# 用法: query_fund.sh <基金代码>

set -e

if [ $# -lt 1 ]; then
  echo "用法: $0 <基金代码>"
  echo "示例: $0 006719"
  exit 1
fi

FUND_CODE="$1"
URL="https://fund.eastmoney.com/${FUND_CODE}.html"

echo "🔍 查询基金 ${FUND_CODE}..."
echo "📡 正在从天天基金网抓取数据..."

# 抓取网页
CONTENT=$(openclaw web fetch "$URL" --maxChars 20000 2>/dev/null || curl -s "$URL")

if [ -z "$CONTENT" ] || echo "$CONTENT" | grep -q "404 Not Found"; then
  echo "❌ 未找到该基金，请检查代码是否正确"
  exit 1
fi

# 提取基金名称
NAME=$(echo "$CONTENT" | grep -oP '<title>[^<]*' | head -1 | sed 's/^<title>//' | sed 's/_基金[^_]*$//' | sed 's/基金净值.*$//' | xargs)
if [ -z "$NAME" ]; then
  NAME=$(echo "$CONTENT" | grep -oP '基金名称[^<]*<[^>]*>[^<]*' | head -1 | sed -n 's/.*>\([^<]*\)<.*/\1/p' | xargs)
fi

# 提取单位净值
NAV=$(echo "$CONTENT" | grep -oP '单位净值[^0-9]*[0-9]+\.[0-9]+' | head -1 | grep -o '[0-9]\+\.[0-9]\+')
if [ -z "$NAV" ]; then
  NAV=$(echo "$CONTENT" | grep -oP '最新净值[^0-9]*[0-9]+\.[0-9]+' | head -1 | grep -o '[0-9]\+\.[0-9]\+')
fi

# 提取日增长率
DAY_GROWTH=$(echo "$CONTENT" | grep -oP '日增长率[^0-9%-]*[+-]?[0-9]+\.[0-9]+%' | head -1 | grep -o '[+-]?[0-9]\+\.[0-9]\+%')
if [ -z "$DAY_GROWTH" ]; then
  DAY_GROWTH=$(echo "$CONTENT" | grep -oP '增长率[^0-9%-]*[+-]?[0-9]+\.[0-9]+%' | head -1 | grep -o '[+-]?[0-9]\+\.[0-9]\+%')
fi

# 提取各期收益率
PERIODS=("近1周" "近1月" "近3月" "近6月" "今年来" "近1年" "近3年")
RETURNS=()

for period in "${PERIODS[@]}"; do
  ret=$(echo "$CONTENT" | grep -oP "${period}[^0-9%-]*[+-]?[0-9]+\.[0-9]+%" | head -1 | grep -o '[+-]?[0-9]\+\.[0-9]\+%')
  if [ -z "$ret" ]; then
    ret="--"
  fi
  RETURNS+=("$ret")
done

# 提取前十大持仓（简化）
echo ""
echo "📊 基金查询结果"
echo "=================="
echo "基金代码: $FUND_CODE"
echo "基金名称: $NAME"
echo "单位净值: $NAV"
echo "日增长: $DAY_GROWTH"
echo ""
echo "📈 业绩表现"
echo "------------------"
for i in "${!PERIODS[@]}"; do
  printf "%-6s %8s\n" "${PERIODS[$i]}" "${RETURNS[$i]}"
done

echo ""
echo "📌 持仓与风险"
echo "------------------"
# 尝试提取前十大占比
TOP10=$(echo "$CONTENT" | grep -oP '前十[^0-9]*[0-9]+\.[0-9]+%' | head -1 | grep -o '[0-9]\+\.[0-9]\+%')
if [ -n "$TOP10" ]; then
  echo "前十大持仓占比: $TOP10"
else
  echo "前十大持仓占比: (未找到)"
fi

# 提取换手率
TURNOVER=$(echo "$CONTENT" | grep -oP '基金换手率[^0-9]*[0-9]+\.[0-9]+%' | head -1 | grep -o '[0-9]\+\.[0-9]\+%')
if [ -n "$TURNOVER" ]; then
  echo "基金换手率: $TURNOVER"
fi

echo ""
echo "💡 风险提示"
echo "------------------"
echo "1. 历史业绩不预示未来表现"
echo "2. 投资基金需仔细阅读基金合同和招募说明书"
echo "3. 市场有风险，投资需谨慎"
echo ""
echo "📝 数据来源: 天天基金网 (东方财富)"
echo "查询时间: $(date '+%Y-%m-%d %H:%M:%S')"