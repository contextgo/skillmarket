#!/usr/bin/env python3
import urllib.request, re

code = "006719"
url = f"https://fund.eastmoney.com/{code}.html"
req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
with urllib.request.urlopen(req, timeout=10) as r:
    content = r.read().decode('utf-8', errors='ignore')

# 找包含 "1.6367" 的行
for m in re.finditer(r'1\.6\d{3,4}', content):
    start = max(0, m.start() - 50)
    end = min(len(content), m.end() + 100)
    snippet = content[start:end]
    print(f"Found: {m.group(0)}")
    print(f"Context: {snippet}\n")