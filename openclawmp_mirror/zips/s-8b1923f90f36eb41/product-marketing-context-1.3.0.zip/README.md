# AI代理的营销技能

专注于营销任务的AI代理技能集合。为希望AI编码代理帮助进行转化优化、文案写作、SEO、分析和增长工程的技术营销人员和创始人构建。与Claude Code、OpenAI Codex、Cursor、Windsurf以及支持[Agent Skills规范](https://agentskills.io)的任何代理一起工作。

由[Corey Haines](https://corey.co?ref=marketingskills)构建。需要实际帮助？查看[Conversion Factory](https://conversionfactory.co?ref=marketingskills) — Corey的转化优化、落地页和增长策略机构。想了解更多营销知识？订阅[Swipe Files](https://swipefiles.com?ref=marketingskills)。想要一个使用这些技能作为你CMO的自主AI代理？试试[Magister](https://magistermarketing.com?ref=marketingskills)。

终端和编码代理新手？查看配套指南[面向营销人员的编码](https://codingformarketers.com?ref=marketingskills)。

**欢迎贡献！** 找到了改进技能的方法或想添加新技能？[提交PR](#contributing)。

遇到问题或有疑问？[提交问题](https://github.com/coreyhaines31/marketingskills/issues) — 我们很乐意提供帮助。

## 什么是技能？

技能是markdown文件，为AI代理提供特定任务的专业知识和工作流程。当您将这些添加到项目中时，您的代理可以识别您何时在进行营销任务，并应用正确的框架和最佳实践。

## 技如何协同工作

技能相互引用并建立在共享上下文的基础上。`product-marketing-context`技能是基础 — 其他所有技能都会先检查它，以了解您的产品、受众和定位，然后再执行任何操作。

```
                            ┌──────────────────────────────────────┐
                            │      产品营销上下文                   │
                            │    (首先被所有其他技能读取)            │
                            └──────────────────┬───────────────────┘
                                               │
    ┌──────────────┬─────────────┬─────────────┼─────────────┬──────────────┬──────────────┐
    ▼              ▼             ▼             ▼             ▼              ▼              ▼
┌──────────┐ ┌──────────┐ ┌──────────┐ ┌────────────┐ ┌──────────┐ ┌─────────────┐ ┌───────────┐
│  SEO &   │ │   CRO    │ │Content & │ │  Paid &    │ │ Growth & │ │  Sales &    │ │ Strategy  │
│ Content  │ │          │ │   Copy   │ │Measurement │ │Retention │ │    GTM      │ │           │
├──────────┤ ├──────────┤ ├──────────┤ ├────────────┤ ├──────────┤ ├─────────────┤ ├───────────┤
│seo-audit │ │page-cro  │ │copywritng│ │paid-ads    │ │referral  │ │revops       │ │mktg-ideas │
│ai-seo    │ │signup-cro│ │copy-edit │ │ad-creative │ │free-tool │ │sales-enable │ │mktg-psych │
│site-arch │ │onboard   │ │cold-email│ │ab-test     │ │churn-    │ │launch       │ │           │
│programm  │ │form-cro  │ │email-seq │ │analytics   │ │ prevent  │ │pricing      │ │           │
│schema    │ │popup-cro │ │social    │ │            │ │          │ │competitor   │ │           │
│content   │ │paywall   │ │          │ │            │ │          │ │             │ │           │
└────┬─────┘ └────┬─────┘ └────┬─────┘ └─────┬──────┘ └────┬─────┘ └──────┬──────┘ └─────┬─────┘
     │            │            │              │             │              │              │
     └────────────┴─────┬──────┴──────────────┴─────────────┴──────────────┴──────────────┘
                        │
         技能相互交叉引用：
           copywriting ↔ page-cro ↔ ab-test-setup
           revops ↔ sales-enablement ↔ cold-email
           seo-audit ↔ schema-markup ↔ ai-seo
```

请查看每个技能的**相关技能**部分以获取完整的依赖关系图。

## 可用技能

<!-- SKILLS:START -->
| 技能 | 描述 |
|-------|-------------|
| [ab-test-setup](skills/ab-test-setup/) | 当用户想要计划、设计或实施A/B测试或实验时使用。当用户提到"A/B..."时也使用。 |
| [ad-creative](skills/ad-creative/) | 当用户想要生成、迭代或扩展广告创意时使用——标题、描述、主要文本或完整广告... |
| [ai-seo](skills/ai-seo/) | 当用户想要为AI搜索引擎优化内容，被LLM引用，或出现在AI生成的答案中时使用... |
| [analytics-tracking](skills/analytics-tracking/) | 当用户想要设置、改进或审核分析跟踪和测量时使用。当用户提到...时也使用。 |
| [churn-prevention](skills/churn-prevention/) | 当用户想要减少流失率，构建取消流程，设置保留优惠，恢复失败的付款，或... |
| [cold-email](skills/cold-email/) | 撰写能获得回复的B2B冷邮件和后续序列。当用户想要撰写冷 Outreach 邮件时使用... |
| [competitor-alternatives](skills/competitor-alternatives/) | 当用户想要为SEO和销售支持创建竞争对手比较或替代页面时使用。当... |
| [content-strategy](skills/content-strategy/) | 当用户想要计划内容策略，决定创建什么内容，或确定要涵盖的主题时使用。也... |
| [copy-editing](skills/copy-editing/) | 当用户想要编辑、审查或改进现有的营销文案时使用。当用户提到"edit this"... |
| [copywriting](skills/copywriting/) | 当用户想要为任何页面撰写、重写或改进营销文案时使用——包括首页、落地页... |
| [email-sequence](skills/email-sequence/) | 当用户想要创建或优化电子邮件序列、滴灌活动、自动化电子邮件流程或生命周期电子邮件... |
| [form-cro](skills/form-cro/) | 当用户想要优化任何非注册/注册的表单时使用——包括潜在客户获取表单、联系表单... |
| [free-tool-strategy](skills/free-tool-strategy/) | 当用户想要计划、评估或构建用于营销目的的免费工具时使用——潜在客户生成、SEO价值或... |
| [launch-strategy](skills/launch-strategy/) | 当用户想要计划产品发布、功能公告或发布策略时使用。当用户... |
| [marketing-ideas](skills/marketing-ideas/) | 当用户需要为其SaaS或软件产品提供营销创意、灵感或策略时使用。当... |
| [marketing-psychology](skills/marketing-psychology/) | 当用户想要将心理学原理、心智模型或行为科学应用于营销时使用。当... |
| [onboarding-cro](skills/onboarding-cro/) | 当用户想要优化注册后的引导、用户激活、首次运行体验或价值实现时间时使用。也... |
| [page-cro](skills/page-cro/) | 当用户想要优化、改进或增加任何营销页面的转化率时使用——包括首页、落地... |
| [paid-ads](skills/paid-ads/) | 当用户需要帮助处理Google Ads、Meta(Facebook/Instagram)、LinkedIn、Twitter/X...上的付费广告活动时使用。 |
| [paywall-upgrade-cro](skills/paywall-upgrade-cro/) | 当用户想要创建或优化应用内付费墙、升级屏幕、向上销售模态框或功能门限时使用。也... |
| [popup-cro](skills/popup-cro/) | 当用户想要创建或优化用于转化目的的弹出窗口、模态框、覆盖层、滑入式窗口或横幅时使用。也... |
| [pricing-strategy](skills/pricing-strategy/) | 当用户需要帮助制定定价决策、包装或货币化策略时使用。当用户提到...时也使用。 |
| [product-marketing-context](skills/product-marketing-context/) | 当用户想要创建或更新其产品营销上下文文档时使用。当用户提到... |
| [programmatic-seo](skills/programmatic-seo/) | 当用户想要使用模板和数据大规模创建SEO驱动的页面时使用。当用户提到... |
| [referral-program](skills/referral-program/) | 当用户想要创建、优化或分析推荐计划、联盟计划或口碑策略时使用... |
| [revops](skills/revops/) | 当用户需要帮助处理收入运营、潜在客户生命周期管理或营销到销售交接流程时使用... |
| [sales-enablement](skills/sales-enablement/) | 当用户想要创建销售支持材料、演示文稿、单页文档、异议处理文档或演示脚本时使用。也... |
| [schema-markup](skills/schema-markup/) | 当用户想要在其网站上添加、修复或优化架构标记和结构化数据时使用。当用户... |
| [seo-audit](skills/seo-audit/) | 当用户想要审核、审查或诊断其网站上的SEO问题时使用。当用户提到"SEO"... |
| [signup-flow-cro](skills/signup-flow-cro/) | 当用户想要优化注册、注册、账户创建或试用激活流程时使用。当用户... |
| [site-architecture](skills/site-architecture/) | 当用户想要计划、映射或重新设计其网站的页面层次结构、导航、URL结构或内部... |
| [social-content](skills/social-content/) | 当用户需要帮助为LinkedIn、Twitter/X、Instagram...创建、安排或优化社交媒体内容时使用。 |
<!-- SKILLS:END -->

## 安装

### 选项 1：CLI 安装（推荐）

使用 [npx skills](https://github.com/vercel-labs/skills) 直接安装技能：

```bash
# 安装所有技能
npx skills add coreyhaines31/marketingskills

# 安装特定技能
npx skills add coreyhaines31/marketingskills --skill page-cro copywriting

# 列出可用技能
npx skills add coreyhaines31/marketingskills --list
```

这会自动安装到你的 `.agents/skills/` 目录（并为 Claude Code 兼容性创建到 `.claude/skills/` 的符号链接）。

### 选项 2：Claude Code 插件

通过 Claude Code 的内置插件系统安装：

```bash
# 添加市场
/plugin marketplace add coreyhaines31/marketingskills

# 安装所有营销技能
/plugin install marketing-skills
```

### 选项 3：克隆并复制

克隆整个仓库并复制技能文件夹：

```bash
git clone https://github.com/coreyhaines31/marketingskills.git
cp -r marketingskills/skills/* .agents/skills/
```

### 选项 4：Git 子模块

作为子模块添加以便于更新：

```bash
git submodule add https://github.com/coreyhaines31/marketingskills.git .agents/marketingskills
```

然后从 `.agents/marketingskills/skills/` 引用技能。

### 选项 5：分叉并自定义

1. 分叉此仓库
2. 根据你的特定需求自定义技能
3. 将你的分叉克隆到你的项目中

### 选项 6：SkillKit（多代理）

使用 [SkillKit](https://github.com/rohitg00/skillkit) 在多个 AI 代理（Claude Code、Cursor、Copilot 等）中安装技能：

```bash
# 安装所有技能
npx skillkit install coreyhaines31/marketingskills

# 安装特定技能
npx skillkit install coreyhaines31/marketingskills --skill page-cro copywriting

# 列出可用技能
npx skillkit install coreyhaines31/marketingskills --list
```

## 从 v1.0 升级

技能现在使用 `.agents/` 而不是 `.claude/` 来存储产品营销上下文文件。移动你现有的上下文文件：

```bash
mkdir -p .agents
mv .claude/product-marketing-context.md .agents/product-marketing-context.md
```

技能仍然会检查 `.claude/` 作为后备，所以如果你不迁移也不会有任何问题。

## 使用方法

安装后，只需让你的代理帮助处理营销任务：

```
"帮我优化这个落地页以提高转化率"
→ 使用 page-cro 技能

"为我的 SaaS 写首页文案"
→ 使用 copywriting 技能

"设置注册的 GA4 跟踪"
→ 使用 analytics-tracking 技能

"创建一个 5 封邮件的欢迎序列"
→ 使用 email-sequence 技能
```

你也可以直接调用技能：

```
/page-cro
/email-sequence
/seo-audit
```

## 技能分类

### 转化优化
- `page-cro` - 任何营销页面
- `signup-flow-cro` - 注册流程
- `onboarding-cro` - 注册后激活
- `form-cro` - 线索捕获表单
- `popup-cro` - 模态框和覆盖层
- `paywall-upgrade-cro` - 应用内升级时刻

### 内容与文案
- `copywriting` - 营销页面文案
- `copy-editing` - 编辑和润色现有文案
- `cold-email` - B2B 冷邮件和序列
- `email-sequence` - 自动化邮件流程
- `social-content` - 社交媒体内容

### SEO 与发现
- `seo-audit` - 技术和页面 SEO
- `ai-seo` - AI 搜索优化 (AEO, GEO, LLMO)
- `programmatic-seo` - 规模化页面生成
- `site-architecture` - 页面层级、导航、URL 结构
- `competitor-alternatives` - 比较和替代页面
- `schema-markup` - 结构化数据

### 付费与分发
- `paid-ads` - Google、Meta、LinkedIn 广告活动
- `ad-creative` - 批量广告创意生成和迭代
- `social-content` - 社交媒体排期和策略

### 测量与测试
- `analytics-tracking` - 事件跟踪设置
- `ab-test-setup` - 实验设计

### 留存
- `churn-prevention` - 取消流程、挽留优惠、催收、付款恢复

### 增长工程
- `free-tool-strategy` - 营销工具和计算器
- `referral-program` - 推荐和联盟计划

### 策略与变现
- `marketing-ideas` - 140 个 SaaS 营销创意
- `marketing-psychology` - 心理模型和心理学
- `launch-strategy` - 产品发布和公告
- `pricing-strategy` - 定价、包装和变现

### 销售与收入运营
- `revops` - 潜在客户生命周期、评分、路由、管道管理
- `sales-enablement` - 销售演示文稿、单页文档、异议文档、演示脚本

## 贡献

找到了改进技能的方法？有新技能建议？欢迎提交 PR 和问题！

请参阅 [CONTRIBUTING.md](CONTRIBUTING.md) 了解添加或改进技能的指南。

## 许可证

[MIT](LICENSE) - 随意使用这些内容。