---
name: content-generation-agent
description: "内容生成代理 - 使用deepseek-v3.1:671b-cloud生成报告、文案、代码等内容。当用户要求写报告、生成文案、编写代码时使用此技能。"
homepage: 
metadata: { "openclaw": { "emoji": "✍️", "requires": { "models": ["deepseek-v3.1:671b-cloud"] } } }
---

# Content Generation Agent Skill

内容生成代理，使用deepseek-v3.1:671b-cloud生成内容。

## When to Use

✅ **USE this skill when:**

- 用户要求"写报告"、"生成报告"
- 用户要求"写文案"、"生成文案"
- 用户要求"写代码"、"帮我编程"
- 用户要求"创建"、"生成"
- 用户要求"总结"、"概述"

## Input

- 内容类型（报告/文案/代码等）
- 具体要求

## Output

生成的内容

## Implementation

```python
import requests
import json

def generate_content(prompt):
    url = "http://localhost:11434/api/generate"
    payload = {
        "model": "deepseek-v3.1:671b-cloud",
        "prompt": prompt,
        "stream": False
    }
    
    resp = requests.post(url, json=payload, timeout=60)
    return resp.json()["response"]
```

## Notes

- 模型：deepseek-v3.1:671b-cloud
- 支持报告生成、文案创作、代码编写
