#!/usr/bin/env python3
"""
内容生成代理工具
用法: python3 content_tool.py <生成请求>
"""

import sys
import requests
import json

MODEL = "deepseek-v3.1:671b-cloud"
OLLAMA_URL = "http://localhost:11434/api/generate"

def generate_content(prompt):
    """调用deepseek生成内容"""
    
    payload = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False
    }
    
    try:
        resp = requests.post(OLLAMA_URL, json=payload, timeout=120)
        result = resp.json()
        return result.get("response", "错误：无响应")
    except Exception as e:
        return f"错误：{e}"

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 content_tool.py <生成请求>")
        print("示例: python3 content_tool.py '写一篇关于BTC的分析报告'")
        sys.exit(1)
    
    prompt = " ".join(sys.argv[1:])
    
    print(f"✍️ 正在生成: {prompt}")
    print("-" * 50)
    
    result = generate_content(prompt)
    print(result)
