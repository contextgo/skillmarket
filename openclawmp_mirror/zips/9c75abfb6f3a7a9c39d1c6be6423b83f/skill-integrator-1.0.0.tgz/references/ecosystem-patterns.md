# 技能生态建设经验模式

> 来源：archives/skill_ecosystem（2026-03-11 归档）
> 回流时间：2026-03-13

## 与 skill-integrator 相关的核心模式

### 模式1：Hub路由整合模式
当同一领域存在3个以上技能时，建立统一入口Hub而非合并技能：
- Hub负责意图识别和路由分发，子技能保持独立
- 子技能 description 中标注"建议通过Hub调用"
- Hub 的 description 中列出所有子技能名称和"自动调度"字样
- 已验证案例：visual-hub（9个视觉技能）、unified-market-research（4个研究技能）、unified-humanizer（3个人性化技能）
- **整合决策标准**：功能重叠>60%→合并；功能互补→Hub路由；无关联→保持独立

### 模式2：分批渐进式整合
一次性整合多个技能风险过高，应分批执行：
- 低风险先行（视觉类、工具类），高风险后置（核心技能、协作类）
- 每批完成后验证，确认无副作用再进入下一批
- 回滚计划前置：每个操作都有对应的恢复路径

### 模式3：废弃技能的价值萃取
删除技能前必须完成价值萃取，避免知识丢失：
1. 提取可复用的模式和知识 → 写入目标技能的 references/
2. 归档备份 → archives/deprecated_skills/
3. 清理所有引用 → WORKSPACE_MAP、trust-registry、INDEX 等
4. 验证删除 → 确认目录不存在、无残留引用

### 模式4：SKILL.md 瘦身整合标准
整合时需同步控制文件大小：
- 目标：≤12KB（约3000 token）
- 骨架放 SKILL.md，详细规范放 references/
- 检查工具：check_skill_sizes.py
- 超标技能需在整合方案中同步规划瘦身

### 模式5：信任分级与整合的关系
整合操作需参考信任注册表：
- Tier 0（元技能）整合需用户逐行审核确认
- Tier 2（高风险）整合前需完整三层安全审查
- 降级操作（如 capability-evolver）需用户确认
