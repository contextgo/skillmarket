#!/usr/bin/env pwsh
# 文档转语音脚本
# 支持 Word、PDF、TXT、Markdown 格式

param(
    [Parameter(Mandatory=$true, Position=0)]
    [string]$InputPath,
    
    [Parameter()]
    [string]$OutputPath,
    
    [Parameter()]
    [ValidateSet("female-default", "female-warm", "male-default", "male-deep", "child")]
    [string]$Voice = "female-default",
    
    [Parameter()]
    [ValidateRange(0.5, 2.0)]
    [double]$Speed = 1.0,
    
    [Parameter()]
    [ValidateSet("mp3", "wav", "m4a")]
    [string]$Format = "mp3",
    
    [Parameter()]
    [int]$SegmentMinutes = 0,
    
    [Parameter()]
    [switch]$Batch,
    
    [Parameter()]
    [string]$OutputDir
)

# 配置
$ConfigFile = "$env:USERPROFILE\.stepclaw\skills\document-to-speech\config.json"
if (Test-Path $ConfigFile) {
    $Config = Get-Content $ConfigFile | ConvertFrom-Json
    if (-not $Voice -and $Config.defaultVoice) { $Voice = $Config.defaultVoice }
    if (-not $Speed -and $Config.defaultSpeed) { $Speed = $Config.defaultSpeed }
    if (-not $Format -and $Config.defaultFormat) { $Format = $Config.defaultFormat }
    if (-not $OutputDir -and $Config.outputDir) { $OutputDir = $Config.outputDir }
}

# 检查依赖
function Check-Dependencies {
    $deps = @("step-tts", "docx", "pdf")
    foreach ($dep in $deps) {
        $depPath = "$env:USERPROFILE\.stepclaw\skills\$dep"
        if (-not (Test-Path $depPath)) {
            Write-Warning "依赖技能未安装: $dep"
            Write-Host "安装命令: openclawmp install skill/@stepfun-ai/$dep" -ForegroundColor Yellow
        }
    }
}

# 提取文本内容
function Extract-Text {
    param([string]$FilePath)
    
    $ext = [System.IO.Path]::GetExtension($FilePath).ToLower()
    $text = ""
    
    switch ($ext) {
        ".docx" {
            # 使用 docx 技能读取
            $docxSkill = "$env:USERPROFILE\.stepclaw\skills\docx"
            if (Test-Path $docxSkill) {
                # 这里调用 docx 技能提取文本
                Write-Host "读取 Word 文档: $FilePath" -ForegroundColor Cyan
                # 简化处理：使用 pandoc 或其他工具
                try {
                    $text = & pandoc -f docx -t plain $FilePath 2>$null
                } catch {
                    Write-Warning "无法读取 Word 文档，请确保安装 pandoc"
                }
            }
        }
        ".pdf" {
            # 使用 pdf 技能读取
            Write-Host "读取 PDF 文档: $FilePath" -ForegroundColor Cyan
            try {
                # 使用 pdftotext 或其他工具
                $text = & pdftotext -raw $FilePath - 2>$null
            } catch {
                Write-Warning "无法读取 PDF 文档，请确保安装 pdftotext"
            }
        }
        ".txt" {
            Write-Host "读取 TXT 文件: $FilePath" -ForegroundColor Cyan
            $text = Get-Content $FilePath -Raw -Encoding UTF8
        }
        ".md" {
            Write-Host "读取 Markdown 文件: $FilePath" -ForegroundColor Cyan
            $content = Get-Content $FilePath -Raw -Encoding UTF8
            # 简单移除 Markdown 标记
            $text = $content -replace '#+ ', '' -replace '\*+', '' -replace '`', ''
        }
        default {
            throw "不支持的文件格式: $ext"
        }
    }
    
    return $text
}

# 清理文本（电商优化）
function Optimize-Text {
    param([string]$Text)
    
    # 优化价格朗读
    $Text = $Text -replace '(\d+)元', '$1元'
    $Text = $Text -replace '(\d+)\.00', '$1元'
    
    # 优化百分比
    $Text = $Text -replace '(\d+)%', '$1百分之'
    
    # 移除多余空白
    $Text = $Text -replace '\s+', ' '
    
    # 移除 URL
    $Text = $Text -replace 'https?://\S+', ''
    
    return $Text.Trim()
}

# 分段处理
function Split-Text {
    param(
        [string]$Text,
        [int]$MaxChars = 2000
    )
    
    $segments = @()
    $currentSegment = ""
    $sentences = $Text -split '(?<=[。！？.!?])'
    
    foreach ($sentence in $sentences) {
        if (($currentSegment.Length + $sentence.Length) -gt $MaxChars) {
            if ($currentSegment) {
                $segments += $currentSegment.Trim()
            }
            $currentSegment = $sentence
        } else {
            $currentSegment += $sentence
        }
    }
    
    if ($currentSegment) {
        $segments += $currentSegment.Trim()
    }
    
    return $segments
}

# 转换为语音
function Convert-ToSpeech {
    param(
        [string]$Text,
        [string]$OutputFile,
        [string]$Voice,
        [double]$Speed
    )
    
    Write-Host "正在合成语音..." -ForegroundColor Green
    
    # 调用 step-tts 技能
    $ttsScript = "$env:USERPROFILE\.stepclaw\skills\step-tts\scripts\tts.sh"
    
    if (Test-Path $ttsScript) {
        # 保存文本到临时文件
        $tempText = "$env:TEMP\tts_input_$(Get-Random).txt"
        $Text | Out-File -FilePath $tempText -Encoding UTF8
        
        # 调用 TTS
        & bash $ttsScript --input $tempText --output $OutputFile --voice $Voice --speed $Speed
        
        Remove-Item $tempText -ErrorAction SilentlyContinue
    } else {
        Write-Warning "TTS 脚本未找到，请确保已安装 step-tts 技能"
        # 模拟输出
        "TTS output placeholder" | Out-File $OutputFile
    }
}

# 主函数
function Main {
    Check-Dependencies
    
    if ($Batch) {
        # 批量处理
        $files = Get-ChildItem $InputPath -Include *.docx, *.pdf, *.txt, *.md -Recurse
        foreach ($file in $files) {
            Write-Host "处理: $($file.Name)" -ForegroundColor Yellow
            
            $outputName = [System.IO.Path]::GetFileNameWithoutExtension($file.Name) + ".$Format"
            if ($OutputDir) {
                $outPath = Join-Path $OutputDir $outputName
            } else {
                $outPath = Join-Path $file.DirectoryName $outputName
            }
            
            try {
                $text = Extract-Text $file.FullName
                $optimizedText = Optimize-Text $text
                Convert-ToSpeech $optimizedText $outPath $Voice $Speed
                Write-Host "✅ 完成: $outPath" -ForegroundColor Green
            } catch {
                Write-Error "❌ 失败: $($file.Name) - $_"
            }
        }
    } else {
        # 单文件处理
        if (-not (Test-Path $InputPath)) {
            throw "文件不存在: $InputPath"
        }
        
        if (-not $OutputPath) {
            $fileName = [System.IO.Path]::GetFileNameWithoutExtension($InputPath)
            $OutputPath = Join-Path (Get-Location) "$fileName.$Format"
        }
        
        $text = Extract-Text $InputPath
        $optimizedText = Optimize-Text $text
        
        if ($SegmentMinutes -gt 0) {
            # 分段输出
            $segments = Split-Text $optimizedText ($SegmentMinutes * 300)
            for ($i = 0; $i -lt $segments.Count; $i++) {
                $segmentFile = $OutputPath -replace "\.$Format$", "_part$($i+1).$Format"
                Convert-ToSpeech $segments[$i] $segmentFile $Voice $Speed
                Write-Host "✅ 分段 $($i+1)/$($segments.Count): $segmentFile" -ForegroundColor Green
            }
        } else {
            Convert-ToSpeech $optimizedText $OutputPath $Voice $Speed
            Write-Host "✅ 完成: $OutputPath" -ForegroundColor Green
        }
    }
}

# 执行
Main
