---
name: document-to-speech
display-name: 文档转语音
version: 1.0.0
description: 将 Word、PDF、TXT 等文档转换为语音，让电商文章可以听。支持批量转换、语音选择、语速调节等功能。
author: your-name
tags: tts, audio, document, pdf, word, txt, ecommerce
category: audio
---

# 文档转语音

将 Word、PDF、TXT 等文档转换为语音，让电商文章可以听。

## 功能特点

- 📄 **多格式支持**: Word (.docx)、PDF (.pdf)、TXT (.txt)、Markdown (.md)
- 🔊 **语音合成**: 基于阶跃星辰 TTS，支持多种音色
- ⚡ **批量转换**: 支持文件夹批量处理
- 🎵 **语音选择**: 多种音色可选（男声、女声、情感风格）
- ⏱️ **语速调节**: 支持调整语速（0.5x - 2.0x）
- 📁 **分段输出**: 长文档自动分段，方便收听

## 使用方法

### 单文件转换

```bash
# 转换 Word 文档
/document-to-speech E:\\文章\\产品介绍.docx

# 转换 PDF 文档
/document-to-speech E:\\文章\\市场报告.pdf

# 转换 TXT 文件
/document-to-speech E:\\文章\\新闻.txt
```

### 批量转换

```bash
# 转换整个文件夹
/document-to-speech --batch E:\\文章\\

# 指定输出格式
/document-to-speech --batch E:\\文章\\ --format mp3
```

### 高级选项

```bash
# 选择语音（男声/女声/情感）
/document-to-speech 文章.docx --voice female-warm

# 调整语速
/document-to-speech 文章.docx --speed 1.2

# 指定输出文件名
/document-to-speech 文章.docx --output 文章语音版.mp3

# 长文档分段（每段10分钟）
/document-to-speech 文章.docx --segment 10
```

## 语音选项

| 语音 ID | 类型 | 描述 |
|---------|------|------|
| `female-default` | 女声 | 标准女声，清晰自然 |
| `female-warm` | 女声 | 温暖女声，适合故事 |
| `male-default` | 男声 | 标准男声，专业稳重 |
| `male-deep` | 男声 | 低沉男声，适合新闻 |
| `child` | 童声 | 活泼童声，适合儿童内容 |

## 电商文章优化

针对电商文章的特殊优化：

- 🏷️ **商品标签**: 自动强调商品名称和价格
- 💰 **价格朗读**: 优化价格数字的朗读方式
- 📊 **数据表格**: 表格内容转换为流畅描述
- 🖼️ **图片描述**: 提取图片 alt 文本并描述

## 输出格式

- **MP3**: 默认格式，兼容性好
- **WAV**: 无损音质，文件较大
- **M4A**: Apple 设备友好

## 示例

### 转换电商产品介绍

```bash
/document-to-speech \\
  "E:\\电商文章\\新款手机产品介绍.docx" \\
  --voice female-warm \\
  --speed 1.1 \\
  --output "手机产品介绍-语音版.mp3"
```

### 批量转换营销文章

```bash
/document-to-speech \\
  --batch "E:\\营销文章\\" \\
  --voice male-default \\
  --format mp3 \\
  --output-dir "E:\\语音文章\\"
```

## 依赖

- 已安装 `step-tts` 技能（阶跃星辰语音合成）
- 已安装 `docx` 技能（Word 文档读取）
- 已安装 `pdf` 技能（PDF 文档读取）

## 配置

在 `~/.stepclaw/skills/document-to-speech/config.json` 中配置默认选项：

```json
{
  "defaultVoice": "female-default",
  "defaultSpeed": 1.0,
  "defaultFormat": "mp3",
  "segmentDuration": 10,
  "outputDir": "~/语音输出"
}
```

## 注意事项

1. **API 密钥**: 需要配置 StepFun API 密钥
2. **文件大小**: 大文件转换可能需要较长时间
3. **网络要求**: 需要联网进行语音合成
4. **版权合规**: 请确保有权利转换目标文档
