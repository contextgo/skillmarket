# 文档转语音 (Document to Speech)

将 Word、PDF、TXT 等文档转换为语音，让电商文章可以听。

## 功能

- 📄 支持 Word (.docx)、PDF (.pdf)、TXT (.txt)、Markdown (.md)
- 🔊 基于阶跃星辰 TTS，多种音色可选
- ⚡ 批量转换文件夹
- 🎵 语速调节 (0.5x - 2.0x)
- 📁 长文档自动分段

## 快速开始

### 转换单个文档

```powershell
# Word 转语音
./scripts/convert.ps1 "E:\文章\产品介绍.docx"

# PDF 转语音
./scripts/convert.ps1 "E:\文章\市场报告.pdf" -Voice male-default

# 指定输出
./scripts/convert.ps1 "文章.txt" -OutputPath "文章语音.mp3" -Speed 1.2
```

### 批量转换

```powershell
./scripts/convert.ps1 "E:\文章\" -Batch -OutputDir "E:\语音\" -Voice female-warm
```

## 电商优化

针对电商文章的特殊处理：
- 价格数字优化朗读
- 商品名称强调
- 表格内容流畅描述

## 依赖

- step-tts 技能
- docx 技能（Word 读取）
- pdf 技能（PDF 读取）
- pandoc（可选，Word 转换）
- pdftotext（可选，PDF 转换）

## 安装

```bash
openclawmp install skill/@your-name/document-to-speech
```

## 配置

编辑 `config.json` 自定义默认选项。
