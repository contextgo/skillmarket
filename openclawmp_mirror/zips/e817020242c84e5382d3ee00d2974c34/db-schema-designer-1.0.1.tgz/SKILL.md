---
name: db-schema-designer
description: 智能数据库架构设计工具，从业务需求自动生成关系型/NoSQL表结构，含索引优化、迁移脚本和性能分析
---

# 数据库Schema设计器

## 使用场景

当用户需要以下操作时使用本技能：
- 从业务需求设计数据库表结构
- 设计或优化数据库索引策略
- 生成数据迁移脚本（DDL/DML）
- 分析查询性能瓶颈
- 微服务数据库拆分设计
- 关系型数据库与 NoSQL 选型建议

## 设计流程

### 步骤 1：需求分析

收集用户的业务需求信息：
- 核心业务实体有哪些（用户、订单、商品等）
- 实体之间的关系（一对多、多对多、归属、继承）
- 预估数据量级（千级/万级/百万级/亿级）
- 读写比例（读多写少/读写均衡/写密集）
- 查询模式（主键查询、范围查询、聚合查询、全文搜索）
- 数据一致性要求（强一致/最终一致）
- 是否需要分库分表

### 步骤 2：数据库选型

根据需求特征推荐数据库类型：

| 场景 | 推荐数据库 | 理由 |
|------|-----------|------|
| 结构化数据 + 强一致 + 关联查询 | PostgreSQL | 完整 ACID、丰富索引、JSON 支持 |
| 高并发 OLTP + 简单查询 | MySQL | 成熟生态、高性能读写 |
| 灵活 Schema + 文档存储 | MongoDB | 无固定表结构、嵌套文档 |
| 缓存 + 会话 + 排行榜 | Redis | 内存级性能、丰富数据结构 |
| 时序数据 + IoT | TimescaleDB / InfluxDB | 时间分区、高效聚合 |
| 图关系 + 社交网络 | Neo4j | 原生图存储、高效遍历 |

### 步骤 3：Schema 生成

#### 关系型数据库输出格式

```sql
-- =============================================
-- 表名：users（用户表）
-- 描述：存储平台注册用户的基本信息
-- 预估数据量：100万+
-- =============================================

CREATE TABLE users (
    id              BIGINT          PRIMARY KEY AUTO_INCREMENT,
    username        VARCHAR(50)     NOT NULL COMMENT '用户名，4-50字符，唯一',
    email           VARCHAR(255)    NOT NULL COMMENT '邮箱地址，唯一',
    password_hash   VARCHAR(255)    NOT NULL COMMENT 'bcrypt 哈希密码',
    nickname        VARCHAR(100)    NULL COMMENT '显示昵称',
    avatar_url      VARCHAR(500)    NULL COMMENT '头像 URL',
    status          TINYINT         NOT NULL DEFAULT 1 COMMENT '状态: 0=禁用 1=正常 2=待验证',
    role            VARCHAR(20)     NOT NULL DEFAULT 'user' COMMENT '角色: admin/user/editor',
    created_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    deleted_at      TIMESTAMP       NULL COMMENT '软删除标记',

    -- 索引
    UNIQUE KEY uk_username (username),
    UNIQUE KEY uk_email (email),
    KEY idx_status_created (status, created_at),
    KEY idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  COMMENT='用户基本信息表';
```

#### NoSQL (MongoDB) 输出格式

```javascript
// =============================================
// 集合名：users
// 描述：用户文档模型
// =============================================

// 推荐索引
db.users.createIndex({ username: 1 }, { unique: true });
db.users.createIndex({ email: 1 }, { unique: true });
db.users.createIndex({ status: 1, created_at: -1 });

// 文档结构
{
  _id: ObjectId("..."),
  username: "string, 必填, 唯一, 4-50字符",
  email: "string, 必填, 唯一",
  passwordHash: "string, 必填, bcrypt",
  nickname: "string, 可选",
  avatarUrl: "string, 可选",
  status: "number, 默认1, 0=禁用 1=正常 2=待验证",
  role: "string, 默认'user', admin|user|editor",
  preferences: {
    language: "string, 默认'zh-CN'",
    theme: "string, 默认'light'",
    notifications: {
      email: "boolean, 默认true",
      push: "boolean, 默认true"
    }
  },
  createdAt: ISODate("..."),
  updatedAt: ISODate("...")
}
```

### 步骤 4：索引优化

根据查询模式设计索引策略：

- **主键索引**：自增 ID vs UUID vs 雪花 ID 的选择建议
- **唯一索引**：业务唯一约束字段（用户名、邮箱、订单号）
- **联合索引**：按查询条件频率和选择性排序，遵循最左前缀原则
- **覆盖索引**：避免回表查询的高频查询优化
- **函数索引**：JSON 字段查询、时间格式化查询的索引策略
- **全文索引**：文本搜索场景的索引方案
- **分区策略**：时间范围分区、哈希分区的适用场景

索引设计原则：
- 单表索引数量建议不超过 5-7 个
- 区分度低的字段不适合单独建索引（如性别、状态）
- WHERE / ORDER BY / GROUP BY 中的字段优先建索引
- 多表 JOIN 时，被驱动表的关联字段必须有索引

### 步骤 5：迁移脚本

生成完整的数据库迁移脚本：

```sql
-- 迁移: 001_create_users_table.up.sql
-- 创建时间: 2026-04-15
-- 描述: 创建用户表及初始索引

BEGIN;

CREATE TABLE users (...);
CREATE TABLE user_profiles (...);
CREATE TABLE user_settings (...);

-- 初始数据
INSERT INTO roles (name, description) VALUES
    ('admin', '系统管理员'),
    ('user', '普通用户'),
    ('editor', '内容编辑');

COMMIT;

-- 回滚: 001_create_users_table.down.sql
DROP TABLE IF EXISTS user_settings;
DROP TABLE IF EXISTS user_profiles;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;
```

### 步骤 6：ER 关系描述

生成实体关系图的文本描述：

```
ER 关系图:

┌─────────────┐       ┌──────────────┐       ┌─────────────┐
│   users     │ 1───N │   orders     │ N───1 │   products  │
│─────────────│       │──────────────│       │─────────────│
│ id (PK)     │       │ id (PK)      │       │ id (PK)     │
│ username    │       │ user_id (FK) │       │ name        │
│ email       │       │ product_id   │       │ price       │
│ ...         │       │ total_amount │       │ stock       │
└─────────────┘       │ status       │       │ category_id │
                      └──────────────┘       └──────┬──────┘
                             │                       │
                      ┌──────┴──────┐       ┌──────┴──────┐
                      │order_items  │       │ categories  │
                      │─────────────│       │─────────────│
                      │ order_id FK │       │ id (PK)     │
                      │ product_id  │       │ name        │
                      │ quantity    │       │ parent_id   │
                      │ unit_price  │       └─────────────┘
                      └─────────────┘
```

## 高级设计模式

### 分库分表策略
- 垂直拆分：按业务模块拆分到不同数据库
- 水平拆分：按用户 ID 哈希 / 时间范围 / 地域分片
- 分片键选择原则：数据均匀分布、查询高频字段、避免跨片查询

### 读写分离
- 主从复制架构设计
- 主从延迟处理策略
- 读写路由规则设计

### 多租户设计
- 共享数据库共享 Schema（tenant_id 字段隔离）
- 共享数据库独立 Schema（每个租户一个 Schema）
- 独立数据库（每个租户一个数据库）
- 各方案的优缺点和适用场景对比

## 性能分析

为用户提供查询性能优化建议：
- EXPLAIN 执行计划分析（type、key、rows、Extra）
- 慢查询优化方案
- N+1 查询问题识别与解决
- 批量操作优化策略
- 连接池配置建议
