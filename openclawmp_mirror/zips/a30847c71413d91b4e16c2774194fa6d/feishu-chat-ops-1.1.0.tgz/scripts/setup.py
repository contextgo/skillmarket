#!/usr/bin/env python3
"""
feishu-chat-ops 配置检测工具
龙虾在执行任何操作前先运行此脚本，检测凭证是否就绪
"""
import json, os, sys, requests
from pathlib import Path

CRED_FILE = Path(__file__).parent.parent / '.credentials' / 'config.json'

def load_config():
    """从文件或环境变量读取配置"""
    if CRED_FILE.exists():
        return json.loads(CRED_FILE.read_text())
    # 兼容环境变量
    app_id = os.environ.get('FEISHU_APP_ID')
    app_secret = os.environ.get('FEISHU_APP_SECRET')
    if app_id and app_secret:
        return {'app_id': app_id, 'app_secret': app_secret}
    return None

def test_config(cfg):
    """测试凭证是否有效"""
    try:
        r = requests.post(
            'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
            json={'app_id': cfg['app_id'], 'app_secret': cfg['app_secret']},
            timeout=10
        )
        data = r.json()
        return data.get('code') == 0, data.get('msg', '')
    except Exception as e:
        return False, str(e)

def save_config(app_id, app_secret):
    """保存凭证到文件"""
    CRED_FILE.parent.mkdir(parents=True, exist_ok=True)
    CRED_FILE.write_text(json.dumps({
        'app_id': app_id,
        'app_secret': app_secret
    }, indent=2))
    CRED_FILE.chmod(0o600)

def main():
    cfg = load_config()

    if cfg:
        ok, msg = test_config(cfg)
        if ok:
            print("STATUS:ready")
            print(f"APP_ID:{cfg['app_id']}")
            return 0
        else:
            print(f"STATUS:invalid")
            print(f"ERROR:{msg}")
            print("HINT:凭证无效，请重新配置。运行: python3 setup.py --set <AppID> <AppSecret>")
            return 1
    else:
        print("STATUS:not_configured")
        print("HINT:需要配置飞书应用凭证")
        print("GUIDE:")
        print("  1. 打开飞书开放平台: https://open.feishu.cn/")
        print("  2. 进入「我的应用」→ 选择你的应用（或新建一个）")
        print("  3. 点击「凭证与基础信息」，复制 App ID 和 App Secret")
        print("  4. 在应用「权限管理」中开启：im:chat、im:chat:create、im:chat.member:write")
        print("  5. 把 App ID 和 App Secret 告诉我，我来完成配置")
        return 2

if __name__ == '__main__':
    # 支持命令行直接设置：python3 setup.py --set <AppID> <AppSecret>
    if len(sys.argv) == 4 and sys.argv[1] == '--set':
        app_id = sys.argv[2]
        app_secret = sys.argv[3]
        save_config(app_id, app_secret)
        ok, msg = test_config({'app_id': app_id, 'app_secret': app_secret})
        if ok:
            print(f"✅ 配置成功！App ID: {app_id}")
            print("STATUS:ready")
        else:
            print(f"❌ 配置已保存，但验证失败: {msg}")
            print("   请检查 App ID / App Secret 是否正确，以及飞书应用是否已发布")
            sys.exit(1)
    else:
        sys.exit(main())
