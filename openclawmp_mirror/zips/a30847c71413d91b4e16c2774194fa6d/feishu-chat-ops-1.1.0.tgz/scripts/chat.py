#!/usr/bin/env python3
"""
飞书群聊管理脚本
凭证通过环境变量传入，不硬编码
"""
import requests, json, sys, os, argparse

CRED_FILE = os.path.join(os.path.dirname(__file__), '..', '.credentials', 'config.json')

def get_config():
    # 优先读凭证文件
    cred_path = os.path.normpath(CRED_FILE)
    if os.path.exists(cred_path):
        with open(cred_path) as f:
            cfg = json.load(f)
        return cfg['app_id'], cfg['app_secret']
    # 兼容环境变量
    app_id = os.environ.get('FEISHU_APP_ID')
    app_secret = os.environ.get('FEISHU_APP_SECRET')
    if app_id and app_secret:
        return app_id, app_secret
    print("STATUS:not_configured")
    print("❌ 尚未配置飞书凭证，请先运行: python3 skills/feishu-chat-ops/scripts/setup.py")
    sys.exit(2)

def get_token(app_id, app_secret):
    r = requests.post(
        'https://open.feishu.cn/open-apis/auth/v3/tenant_access_token/internal',
        json={'app_id': app_id, 'app_secret': app_secret}
    )
    data = r.json()
    if not data.get('tenant_access_token'):
        print(f"❌ 获取 token 失败: {data}")
        sys.exit(1)
    return data['tenant_access_token']

def create_chat(name, description='', owner_id=None, member_open_ids=None):
    """创建群聊"""
    app_id, app_secret = get_config()
    token = get_token(app_id, app_secret)
    headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

    body = {'name': name}
    if description:
        body['description'] = description
    if owner_id:
        body['owner_id'] = owner_id

    r = requests.post('https://open.feishu.cn/open-apis/im/v1/chats',
                      headers=headers, json=body)
    resp = r.json()
    if resp.get('code') != 0:
        print(f"❌ 创建群失败: {resp.get('msg')} (code={resp.get('code')})")
        sys.exit(1)

    chat_id = resp['data']['chat_id']
    print(f"✅ 群已创建: {name}")
    print(f"   chat_id: {chat_id}")

    # 拉人进群
    if member_open_ids:
        r2 = requests.post(
            f'https://open.feishu.cn/open-apis/im/v1/chats/{chat_id}/members',
            headers=headers,
            params={'member_id_type': 'open_id'},
            json={'id_list': member_open_ids}
        )
        resp2 = r2.json()
        if resp2.get('code') == 0:
            print(f"✅ 已邀请 {len(member_open_ids)} 人进群")
        else:
            print(f"⚠️  邀请失败: {resp2.get('msg')}")

    return chat_id

def list_chats():
    """列出机器人所在的群"""
    app_id, app_secret = get_config()
    token = get_token(app_id, app_secret)
    headers = {'Authorization': f'Bearer {token}'}

    r = requests.get('https://open.feishu.cn/open-apis/im/v1/chats',
                     headers=headers, params={'page_size': 20})
    resp = r.json()
    if resp.get('code') != 0:
        print(f"❌ 获取群列表失败: {resp}")
        sys.exit(1)

    chats = resp['data'].get('items', [])
    if not chats:
        print("（机器人未加入任何群）")
        return

    print(f"机器人所在群（共 {len(chats)} 个）：")
    for c in chats:
        print(f"  {c.get('name', '未命名')} → {c['chat_id']}")

def search_user(token, keyword):
    """按名字/手机/邮箱搜索用户，返回 open_id 列表"""
    headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}
    r = requests.post(
        'https://open.feishu.cn/open-apis/search/v1/user',
        headers=headers,
        params={'user_id_type': 'open_id', 'page_size': 10},
        json={'query': keyword}
    )
    resp = r.json()
    if resp.get('code') != 0:
        return []
    items = resp.get('data', {}).get('items', [])
    results = []
    for item in items:
        name = item.get('name', '')
        open_id = item.get('open_id', '')
        dept = item.get('department_path', [''])[0] if item.get('department_path') else ''
        results.append({'name': name, 'open_id': open_id, 'dept': dept})
    return results

def add_members(chat_id, open_ids, member_type='user'):
    """向群里添加成员（用户或机器人）"""
    app_id, app_secret = get_config()
    token = get_token(app_id, app_secret)
    headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}

    if member_type == 'bot':
        # 添加机器人（app_id）
        id_type = 'app_id'
    else:
        id_type = 'open_id'

    r = requests.post(
        f'https://open.feishu.cn/open-apis/im/v1/chats/{chat_id}/members',
        headers=headers,
        params={'member_id_type': id_type},
        json={'id_list': open_ids}
    )
    resp = r.json()
    if resp.get('code') == 0:
        print(f"✅ 已添加 {len(open_ids)} 个{'机器人' if member_type == 'bot' else '成员'}到群 {chat_id}")
    else:
        print(f"❌ 添加失败: {resp.get('msg')} (code={resp.get('code')})")

def invite_by_name(chat_id, keyword):
    """按名字搜索用户并邀请进群"""
    app_id, app_secret = get_config()
    token = get_token(app_id, app_secret)

    print(f"🔍 搜索用户: {keyword}")
    users = search_user(token, keyword)

    if not users:
        print(f"❌ 未找到用户: {keyword}")
        print("   请直接提供 open_id，用: python3 chat.py add <chat_id> <open_id>")
        return

    if len(users) == 1:
        u = users[0]
        print(f"找到用户: {u['name']} ({u['dept']})")
        add_members(chat_id, [u['open_id']])
    else:
        print(f"找到 {len(users)} 个匹配用户：")
        for i, u in enumerate(users):
            print(f"  {i+1}. {u['name']} ({u['dept']}) — {u['open_id']}")
        print("请用 open_id 精确邀请: python3 chat.py add <chat_id> <open_id>")

def delete_chat(chat_id):
    """解散群"""
    app_id, app_secret = get_config()
    token = get_token(app_id, app_secret)
    headers = {'Authorization': f'Bearer {token}'}

    r = requests.delete(f'https://open.feishu.cn/open-apis/im/v1/chats/{chat_id}',
                        headers=headers)
    resp = r.json()
    if resp.get('code') == 0:
        print(f"✅ 群 {chat_id} 已解散")
    else:
        print(f"❌ 解散失败: {resp.get('msg')}")

def main():
    parser = argparse.ArgumentParser(description='飞书群聊管理工具')
    sub = parser.add_subparsers(dest='cmd')

    # create
    p_create = sub.add_parser('create', help='创建群聊')
    p_create.add_argument('name', help='群名称')
    p_create.add_argument('--desc', default='', help='群描述')
    p_create.add_argument('--owner', default=None, help='群主 open_id（可选）')
    p_create.add_argument('--members', nargs='+', help='邀请成员 open_id 列表')

    # list
    sub.add_parser('list', help='列出机器人所在群')

    # add
    p_add = sub.add_parser('add', help='添加成员到群（by open_id）')
    p_add.add_argument('chat_id', help='群 chat_id')
    p_add.add_argument('open_ids', nargs='+', help='成员 open_id 列表')
    p_add.add_argument('--bot', action='store_true', help='添加的是机器人（用 app_id）')

    # invite
    p_invite = sub.add_parser('invite', help='按名字搜索并邀请用户进群')
    p_invite.add_argument('chat_id', help='群 chat_id')
    p_invite.add_argument('name', help='用户姓名关键词')

    # addbot
    p_addbot = sub.add_parser('addbot', help='添加机器人到群（by app_id）')
    p_addbot.add_argument('chat_id', help='群 chat_id')
    p_addbot.add_argument('app_ids', nargs='+', help='机器人的 app_id 列表')

    # delete
    p_del = sub.add_parser('delete', help='解散群')
    p_del.add_argument('chat_id', help='群 chat_id')

    args = parser.parse_args()

    if args.cmd == 'create':
        create_chat(args.name, args.desc, args.owner, args.members)
    elif args.cmd == 'list':
        list_chats()
    elif args.cmd == 'add':
        add_members(args.chat_id, args.open_ids, 'bot' if args.bot else 'user')
    elif args.cmd == 'invite':
        invite_by_name(args.chat_id, args.name)
    elif args.cmd == 'addbot':
        add_members(args.chat_id, args.app_ids, 'bot')
    elif args.cmd == 'delete':
        delete_chat(args.chat_id)
    else:
        parser.print_help()

if __name__ == '__main__':
    main()
