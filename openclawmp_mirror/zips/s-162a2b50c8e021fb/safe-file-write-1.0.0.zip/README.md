# Safe File Write

Handle file write operations safely with automatic fallbacks for permission and path constraints.

## Quick Start

```bash
# Write to workspace (always works)
safe-write ~/.openclaw/workspace/file.txt "content"

# Write to home directory with fallback
safe-write ~/.config/app/config.json '{"key": "value"}' --fallback /tmp/

# Force exec for paths outside workspace
safe-write /etc/app.conf "content" --use-exec
```

## Common Operations

### Basic Write (Workspace-safe)

```bash
# Standard write within workspace
echo "content" > ~/.openclaw/workspace/notes.txt
```

### Write with Fallback

```bash
# Try primary location, fallback to workspace if fails
safe-write ~/.someapp/config.json '{"setting": true}' \
  --fallback ~/.openclaw/workspace/.someapp/
```

### Create Directory Structure

```bash
# Ensure directory exists with proper permissions
mkdir -p ~/.openclaw/workspace/backups/$(date +%Y/%m)
```

### Copy with Permission Handling

```bash
# Copy file, fallback to workspace if dest fails
cp config.json ~/.openclaw/workspace/backup/ 2>/dev/null || \
  cp config.json /tmp/backup-config.json
```

## Best Practices

### Always Use Workspace for Persistent Data

```bash
# ✅ Good - guaranteed to work
echo '{"token": "xxx"}' > ~/.openclaw/workspace/configs/api.json

# ❌ Risky - might fail outside workspace
echo '{"token": "xxx"}' > ~/.someapp/config.json
```

### Check Before Write

```bash
# Check if path is writable
test -w ~/.targetdir/ && write_path=~/.targetdir/ || write_path=~/.openclaw/workspace/
echo "data" > "${write_path}file.txt"
```

### Handle External Paths with Exec

For paths outside workspace that must be written:

```bash
# Use exec for paths outside workspace
exec "mkdir -p ~/.external/path && echo 'data' > ~/.external/path/file"
```

## Troubleshooting

| Error | Solution |
|-------|----------|
| `Path escapes workspace root` | Use `exec` or write to `~/.openclaw/workspace/` |
| `Permission denied` | Check with `ls -la`, use `chmod` or fallback path |
| `No such file or directory` | Create parent dirs first with `mkdir -p` |

## Related

- Use `exec` for paths outside workspace
- Use `~/.openclaw/workspace/` for guaranteed writable location