# Slack 操作

## 概述

使用 `slack` 进行回应、管理置顶、发送/编辑/删除消息以及获取成员信息。该工具使用为 Clawdbot 配置的机器人令牌。

## 需要收集的输入

- `channelId` 和 `messageId`（Slack 消息时间戳，例如 `1712023032.1234`）。
- 对于回应，需要一个 `emoji`（Unicode 或 `:name:` 格式）。
- 对于发送消息，需要一个 `to` 目标（`channel:<id>` 或 `user:<id>`）和 `content`。

消息上下文行包含可直接重用的 `slack message id` 和 `channel` 字段。

## 操作

### 操作组

| 操作组 | 默认值 | 备注 |
| --- | --- | --- |
| reactions | enabled | 回应 + 列出回应 |
| messages | enabled | 读取/发送/编辑/删除 |
| pins | enabled | 置顶/取消置顶/列出 |
| memberInfo | enabled | 成员信息 |
| emojiList | enabled | 自定义表情列表 |

### 对消息进行回应

```json
{
  "action": "react",
  "channelId": "C123",
  "messageId": "1712023032.1234",
  "emoji": "✅"
}
```

### 列出回应

```json
{
  "action": "reactions",
  "channelId": "C123",
  "messageId": "1712023032.1234"
}
```

### 发送消息

```json
{
  "action": "sendMessage",
  "to": "channel:C123",
  "content": "Hello from Clawdbot"
}
```

### 编辑消息

```json
{
  "action": "editMessage",
  "channelId": "C123",
  "messageId": "1712023032.1234",
  "content": "Updated text"
}
```

### 删除消息

```json
{
  "action": "deleteMessage",
  "channelId": "C123",
  "messageId": "1712023032.1234"
}
```

### 读取最近消息

```json
{
  "action": "readMessages",
  "channelId": "C123",
  "limit": 20
}
```

### 置顶消息

```json
{
  "action": "pinMessage",
  "channelId": "C123",
  "messageId": "1712023032.1234"
}
```

### 取消置顶消息

```json
{
  "action": "unpinMessage",
  "channelId": "C123",
  "messageId": "1712023032.1234"
}
```

### 列出置顶项目

```json
{
  "action": "listPins",
  "channelId": "C123"
}
```

### 成员信息

```json
{
  "action": "memberInfo",
  "userId": "U123"
}
```

### 表情列表

```json
{
  "action": "emojiList"
}
```

## 可以尝试的用法

- 使用 ✅ 进行回应以标记已完成的任务。
- 置顶关键决策或每周状态更新。