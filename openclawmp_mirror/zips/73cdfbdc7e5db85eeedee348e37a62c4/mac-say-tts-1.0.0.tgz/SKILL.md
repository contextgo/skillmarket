---
name: mac-say-tts
description: 使用 Mac 内置 say 命令进行文字转语音输出
---

# Mac Say TTS Skill

使用Mac系统自带的say命令进行语音输出。

## When to Use

当需要语音回复时使用此skill。

## Implementation

```bash
#!/bin/bash
say "$TEXT"
```

## 使用方式

在回复时调用:
```bash
/Users/macair/.openclaw/workspace/scripts/tts-say.sh "要朗读的文字"
```

## 可用声音

```bash
say -v ?
```

## 设置自动朗读

可以在每次回复后自动调用say命令。
