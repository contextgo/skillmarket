#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小红书自动化发布主脚本
支持命令行参数和配置文件
"""

import argparse
import json
import os
import sys
import time
from typing import List, Dict, Optional
import requests

class XHSAutoPublisher:
    """小红书自动化发布器"""
    
    def __init__(self, mcp_url: str = "http://localhost:18060/mcp", 
                 cookies_path: Optional[str] = None):
        self.mcp_url = mcp_url
        self.cookies_path = cookies_path or os.path.expanduser("~/.xiaohongshu/cookies.json")
        self.session_id = None
        self.request_id = 1
        
    def initialize_session(self) -> bool:
        """初始化MCP会话"""
        print("初始化MCP会话...")
        
        init_payload = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": "initialize",
            "params": {
                "protocolVersion": "2024-11-05",
                "capabilities": {},
                "clientInfo": {"name": "xhs-auto-publisher", "version": "1.0.0"}
            }
        }
        
        self.request_id += 1
        
        try:
            response = requests.post(self.mcp_url, headers={"Content-Type": "application/json"}, 
                                   json=init_payload, timeout=10)
            if response.status_code == 200:
                self.session_id = response.headers.get('Mcp-Session-Id')
                if self.session_id:
                    print(f"初始化成功，Session ID: {self.session_id}")
                    
                    # 发送initialized通知
                    notify_payload = {
                        "jsonrpc": "2.0",
                        "method": "notifications/initialized",
                        "params": {}
                    }
                    
                    notify_headers = {"Content-Type": "application/json", 
                                     "Mcp-Session-Id": self.session_id}
                    
                    requests.post(self.mcp_url, headers=notify_headers, 
                                json=notify_payload, timeout=5)
                    print("已发送initialized通知")
                    
                    return True
                else:
                    print("错误: 未收到Session ID")
                    return False
            else:
                print(f"初始化失败: {response.status_code}")
                return False
        except Exception as e:
            print(f"初始化异常: {e}")
            return False
    
    def call_mcp_tool(self, tool_name: str, arguments: Dict) -> Dict:
        """调用MCP工具"""
        if not self.session_id:
            raise ValueError("未初始化，请先调用initialize_session()")
        
        payload = {
            "jsonrpc": "2.0",
            "id": self.request_id,
            "method": "tools/call",
            "params": {
                "name": tool_name,
                "arguments": arguments
            }
        }
        
        self.request_id += 1
        
        headers = {"Content-Type": "application/json", 
                  "Mcp-Session-Id": self.session_id}
        
        try:
            response = requests.post(self.mcp_url, headers=headers, 
                                   json=payload, timeout=120)
            return response.json()
        except Exception as e:
            return {"error": str(e)}
    
    def check_login_status(self) -> bool:
        """检查登录状态"""
        print("检查登录状态...")
        result = self.call_mcp_tool("check_login_status", {})
        
        if "result" in result:
            result_data = result["result"]
            if isinstance(result_data, dict):
                content = result_data.get("content", {})
                if isinstance(content, dict):
                    is_error = content.get("isError", False)
                    if not is_error:
                        print("登录状态检查成功")
                        return True
            print(f"登录状态响应: {result_data}")
        elif "error" in result:
            error = result["error"]
            print(f"检查登录失败: {error}")
        
        return False
    
    def publish_note(self, title: str, content: str, 
                    image_paths: List[str], tags: List[str] = None) -> Dict:
        """发布小红书笔记"""
        print(f"发布笔记: {title}")
        print(f"内容: {content[:50]}...")
        print(f"图片: {len(image_paths)}张")
        
        # 验证图片文件
        valid_images = []
        for img_path in image_paths:
            if os.path.exists(img_path):
                valid_images.append(img_path)
                print(f"  找到图片: {os.path.basename(img_path)}")
            else:
                print(f"  图片不存在: {img_path}")
        
        if not valid_images:
            return {"error": "没有有效的图片文件"}
        
        # 准备发布参数
        publish_args = {
            "title": title,
            "content": content,
            "images": valid_images
        }
        
        if tags:
            publish_args["tags"] = tags
        
        print("正在发布，请等待...")
        start_time = time.time()
        
        result = self.call_mcp_tool("publish_content", publish_args)
        
        elapsed = time.time() - start_time
        print(f"发布完成，耗时: {elapsed:.2f}秒")
        
        return result
    
    def publish(self, title: str, content: str, 
               image_paths: List[str], tags: List[str] = None) -> bool:
        """完整的发布流程"""
        # 1. 初始化
        if not self.initialize_session():
            return False
        
        # 2. 检查登录（可选）
        # self.check_login_status()
        
        # 3. 发布
        result = self.publish_note(title, content, image_paths, tags)
        
        if "result" in result:
            result_data = result["result"]
            if isinstance(result_data, dict):
                content_data = result_data.get("content", {})
                if isinstance(content_data, list) and len(content_data) > 0:
                    text = content_data[0].get("text", "")
                    if "发布成功" in text or "PostID" in text:
                        print("发布成功!")
                        print(f"发布结果: {text}")
                        return True
                    else:
                        print(f"发布结果: {text}")
                else:
                    print(f"发布结果: {content_data}")
            return True
        elif "error" in result:
            error = result["error"]
            print(f"发布失败: {error}")
            return False
        
        return False

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="小红书自动化发布工具")
    parser.add_argument("--title", required=True, help="笔记标题")
    parser.add_argument("--content", required=True, help="笔记内容")
    parser.add_argument("--images", nargs="+", required=True, help="图片路径列表")
    parser.add_argument("--tags", nargs="+", help="标签列表")
    parser.add_argument("--mcp-url", default="http://localhost:18060/mcp", 
                       help="MCP服务URL")
    parser.add_argument("--cookies-path", help="cookies文件路径")
    parser.add_argument("--config", help="配置文件路径")
    
    args = parser.parse_args()
    
    # 如果有配置文件，优先使用
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        title = config.get("title", args.title)
        content = config.get("content", args.content)
        images = config.get("images", args.images)
        tags = config.get("tags", args.tags)
        mcp_url = config.get("mcp_url", args.mcp_url)
        cookies_path = config.get("cookies_path", args.cookies_path)
    else:
        title = args.title
        content = args.content
        images = args.images
        tags = args.tags
        mcp_url = args.mcp_url
        cookies_path = args.cookies_path
    
    print("=" * 60)
    print("小红书自动化发布工具")
    print("=" * 60)
    
    # 创建发布器
    publisher = XHSAutoPublisher(mcp_url=mcp_url, cookies_path=cookies_path)
    
    # 执行发布
    success = publisher.publish(title, content, images, tags)
    
    print("=" * 60)
    if success:
        print("[SUCCESS] 发布成功!")
        print("请检查小红书App确认发布结果")
        return 0
    else:
        print("[ERROR] 发布失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())