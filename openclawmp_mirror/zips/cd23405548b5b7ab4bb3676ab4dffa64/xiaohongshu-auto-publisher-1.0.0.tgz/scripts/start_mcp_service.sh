#!/bin/bash
# 启动小红书MCP服务脚本

set -e

echo "小红书MCP服务启动脚本"
echo "========================"

# 检查是否已安装MCP服务
MCP_BIN="./xiaohongshu-mcp-windows-amd64.exe"
MCP_DIR="./xiaohongshu-mcp"

if [ -f "$MCP_BIN" ]; then
    echo "找到MCP服务可执行文件: $MCP_BIN"
elif [ -d "$MCP_DIR" ] && [ -f "$MCP_DIR/xiaohongshu-mcp-windows-amd64.exe" ]; then
    MCP_BIN="$MCP_DIR/xiaohongshu-mcp-windows-amd64.exe"
    echo "找到MCP服务可执行文件: $MCP_BIN"
else
    echo "未找到MCP服务可执行文件"
    echo "请从以下位置下载:"
    echo "1. GitHub Releases: https://github.com/xpzouying/xiaohongshu-mcp/releases"
    echo "2. 或使用提供的下载链接"
    
    read -p "是否要下载MCP服务? (y/n): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        echo "正在下载MCP服务..."
        # 这里可以添加下载逻辑
        echo "请手动下载并放置到当前目录"
        exit 1
    else
        exit 1
    fi
fi

# 检查端口是否被占用
PORT=18060
if netstat -ano | grep ":$PORT " > /dev/null; then
    echo "端口 $PORT 已被占用"
    echo "正在查找占用进程..."
    
    PID=$(netstat -ano | grep ":$PORT " | awk '{print $5}' | head -1)
    if [ ! -z "$PID" ]; then
        echo "进程PID: $PID"
        read -p "是否要终止进程 $PID? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            taskkill //F //PID $PID
            echo "进程已终止"
            sleep 2
        else
            echo "请手动释放端口或修改配置"
            exit 1
        fi
    fi
fi

# 启动MCP服务
echo "启动MCP服务..."
echo "命令: $MCP_BIN -headless=false"
echo "日志文件: mcp_service.log"

# 启动服务并记录日志
"$MCP_BIN" -headless=false > mcp_service.log 2>&1 &
MCP_PID=$!

echo "MCP服务已启动，PID: $MCP_PID"
echo "等待服务初始化..."

# 等待服务启动
sleep 5

# 检查服务是否运行
if ps -p $MCP_PID > /dev/null; then
    echo "MCP服务运行正常"
    echo "服务URL: http://localhost:$PORT/mcp"
    echo ""
    echo "使用说明:"
    echo "1. 查看日志: tail -f mcp_service.log"
    echo "2. 停止服务: kill $MCP_PID"
    echo "3. 测试连接: curl http://localhost:$PORT/health"
    
    # 保存PID到文件
    echo $MCP_PID > mcp_service.pid
    echo "PID已保存到: mcp_service.pid"
else
    echo "MCP服务启动失败"
    echo "请查看日志文件: mcp_service.log"
    exit 1
fi

echo ""
echo "服务启动完成!"
echo "现在可以运行测试: python scripts/test_publish.py"