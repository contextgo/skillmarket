#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小红书cookies设置工具
"""

import argparse
import json
import os
import sys

def parse_cookie_string(cookie_str: str) -> list:
    """解析cookie字符串为对象列表"""
    cookies = []
    
    for item in cookie_str.split('; '):
        if '=' in item:
            name, value = item.split('=', 1)
            
            cookie_obj = {
                "name": name.strip(),
                "value": value.strip(),
                "domain": ".xiaohongshu.com",
                "path": "/",
                "expires": -1,
                "size": len(value.strip()),
                "httpOnly": False,
                "secure": False,
                "session": True,
                "sameSite": "Lax"
            }
            cookies.append(cookie_obj)
    
    return cookies

def save_cookies(cookies: list, output_path: str) -> bool:
    """保存cookies到文件"""
    try:
        # 创建目录
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # 保存为JSON
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(cookies, f, ensure_ascii=False, indent=2)
        
        print(f"cookies已保存到: {output_path}")
        print(f"包含 {len(cookies)} 个cookie")
        
        return True
    except Exception as e:
        print(f"保存失败: {e}")
        return False

def test_cookies_format(file_path: str) -> bool:
    """测试cookies格式是否正确"""
    if not os.path.exists(file_path):
        print(f"文件不存在: {file_path}")
        return False
    
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        if isinstance(data, list):
            print("格式正确: cookie数组")
            print(f"包含 {len(data)} 个cookie")
            
            # 显示前几个cookie
            print("\n前3个cookie:")
            for i, cookie in enumerate(data[:3]):
                name = cookie.get("name", "未知")
                value = cookie.get("value", "")
                print(f"  {i+1}. {name} = {value[:30]}...")
            
            return True
        else:
            print(f"格式错误: 应该是数组，但是 {type(data)}")
            return False
            
    except Exception as e:
        print(f"读取失败: {e}")
        return False

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="小红书cookies设置工具")
    parser.add_argument("--cookie", help="cookie字符串")
    parser.add_argument("--cookie-file", help="包含cookie字符串的文件")
    parser.add_argument("--output", default="~/.xiaohongshu/cookies.json", 
                       help="输出文件路径")
    parser.add_argument("--test", action="store_true", 
                       help="测试cookies格式")
    parser.add_argument("--list", action="store_true", 
                       help="列出cookies")
    
    args = parser.parse_args()
    
    # 展开输出路径
    output_path = os.path.expanduser(args.output)
    
    print("=" * 60)
    print("小红书cookies设置工具")
    print("=" * 60)
    
    # 测试模式
    if args.test:
        print("测试cookies格式...")
        success = test_cookies_format(output_path)
        return 0 if success else 1
    
    # 列出模式
    if args.list and os.path.exists(output_path):
        test_cookies_format(output_path)
        return 0
    
    # 获取cookie字符串
    cookie_str = None
    
    if args.cookie:
        cookie_str = args.cookie
    elif args.cookie_file and os.path.exists(args.cookie_file):
        with open(args.cookie_file, 'r', encoding='utf-8') as f:
            cookie_str = f.read().strip()
    else:
        # 交互式输入
        print("请输入cookie字符串（从浏览器开发者工具获取）:")
        print("格式: name1=value1; name2=value2; ...")
        print("输入'quit'退出")
        
        lines = []
        while True:
            line = input("> ")
            if line.lower() == 'quit':
                return 0
            if line.strip():
                lines.append(line.strip())
                if ';' in line:  # 假设以分号结束
                    break
        
        cookie_str = ' '.join(lines)
    
    if not cookie_str:
        print("错误: 未提供cookie字符串")
        return 1
    
    print(f"cookie字符串长度: {len(cookie_str)} 字符")
    print(f"前50字符: {cookie_str[:50]}...")
    
    # 解析cookies
    cookies = parse_cookie_string(cookie_str)
    
    if not cookies:
        print("错误: 无法解析cookie字符串")
        return 1
    
    print(f"成功解析 {len(cookies)} 个cookie")
    
    # 保存cookies
    success = save_cookies(cookies, output_path)
    
    print("=" * 60)
    if success:
        print("[SUCCESS] cookies设置完成")
        print(f"文件位置: {output_path}")
        print("\n使用说明:")
        print("1. 确保MCP服务已启动")
        print("2. 运行测试: python scripts/test_publish.py")
        print("3. 开始发布: python scripts/publish_xhs.py")
        return 0
    else:
        print("[ERROR] cookies设置失败")
        return 1

if __name__ == "__main__":
    sys.exit(main())