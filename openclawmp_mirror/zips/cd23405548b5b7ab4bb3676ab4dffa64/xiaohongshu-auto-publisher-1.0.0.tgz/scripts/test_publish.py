#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
小红书发布测试脚本
"""

import argparse
import json
import os
import sys
from publish_xhs import XHSAutoPublisher

def test_basic_functionality(mcp_url: str, cookies_path: str) -> bool:
    """测试基本功能"""
    print("测试基本功能...")
    
    publisher = XHSAutoPublisher(mcp_url=mcp_url, cookies_path=cookies_path)
    
    # 测试初始化
    if not publisher.initialize_session():
        print("初始化失败")
        return False
    
    print("初始化成功")
    return True

def test_publish_simple(mcp_url: str, cookies_path: str, 
                       test_images: list) -> bool:
    """测试简单发布"""
    print("\n测试简单发布...")
    
    publisher = XHSAutoPublisher(mcp_url=mcp_url, cookies_path=cookies_path)
    
    # 使用测试图片
    valid_images = []
    for img_path in test_images:
        if os.path.exists(img_path):
            valid_images.append(img_path)
            print(f"  使用图片: {os.path.basename(img_path)}")
        else:
            print(f"  图片不存在: {img_path}")
    
    if not valid_images:
        print("错误: 没有测试图片")
        return False
    
    # 测试发布
    title = "自动化发布测试"
    content = "这是自动化发布测试 #测试 #小红书 #自动化"
    
    success = publisher.publish(title, content, valid_images)
    
    return success

def create_test_images() -> list:
    """创建测试图片路径列表"""
    # 尝试在当前目录查找测试图片
    test_dirs = [
        ".",
        "test_images",
        "../test_images",
        os.path.join(os.path.dirname(__file__), "..", "test_images")
    ]
    
    test_images = []
    image_names = ["test1.png", "test2.jpg", "sample.png", "cover.png"]
    
    for test_dir in test_dirs:
        for img_name in image_names:
            img_path = os.path.join(test_dir, img_name)
            if os.path.exists(img_path):
                test_images.append(img_path)
    
    # 如果没有找到，创建占位符
    if not test_images:
        print("警告: 未找到测试图片")
        print("请创建测试图片或指定--images参数")
    
    return test_images

def main():
    """命令行入口"""
    parser = argparse.ArgumentParser(description="小红书发布测试脚本")
    parser.add_argument("--mcp-url", default="http://localhost:18060/mcp", 
                       help="MCP服务URL")
    parser.add_argument("--cookies-path", help="cookies文件路径")
    parser.add_argument("--images", nargs="+", help="测试图片路径")
    parser.add_argument("--skip-publish", action="store_true", 
                       help="跳过实际发布测试")
    parser.add_argument("--config", help="测试配置文件")
    
    args = parser.parse_args()
    
    print("=" * 60)
    print("小红书发布测试")
    print("=" * 60)
    
    # 加载配置
    mcp_url = args.mcp_url
    cookies_path = args.cookies_path
    
    if args.config and os.path.exists(args.config):
        with open(args.config, 'r', encoding='utf-8') as f:
            config = json.load(f)
        
        mcp_url = config.get("mcp_url", mcp_url)
        cookies_path = config.get("cookies_path", cookies_path)
    
    # 获取测试图片
    if args.images:
        test_images = args.images
    else:
        test_images = create_test_images()
    
    print(f"MCP URL: {mcp_url}")
    print(f"Cookies路径: {cookies_path or '默认'}")
    print(f"测试图片: {len(test_images)}张")
    
    # 测试1: 基本功能
    print("\n[测试1] 基本功能测试")
    basic_ok = test_basic_functionality(mcp_url, cookies_path)
    
    if not basic_ok:
        print("基本功能测试失败")
        return 1
    
    print("基本功能测试通过")
    
    # 测试2: 发布测试（可选）
    if not args.skip_publish and test_images:
        print("\n[测试2] 发布功能测试")
        publish_ok = test_publish_simple(mcp_url, cookies_path, test_images)
        
        if publish_ok:
            print("发布功能测试通过")
        else:
            print("发布功能测试失败（但基本功能正常）")
    else:
        print("\n[跳过] 发布功能测试")
        publish_ok = True
    
    print("=" * 60)
    print("测试总结:")
    
    if basic_ok and publish_ok:
        print("[SUCCESS] 所有测试通过!")
        print("\n技能已准备就绪，可以开始使用:")
        print("1. 设置cookies: python scripts/setup_cookies.py")
        print("2. 发布笔记: python scripts/publish_xhs.py")
        print("3. 查看帮助: python scripts/publish_xhs.py --help")
        return 0
    elif basic_ok:
        print("[PARTIAL] 基本功能正常，发布功能需要调整")
        print("\n可能的问题:")
        print("1. cookies可能已过期")
        print("2. MCP服务未正确启动")
        print("3. 图片格式不支持")
        return 0
    else:
        print("[ERROR] 基本功能测试失败")
        print("\n请检查:")
        print("1. MCP服务是否运行")
        print("2. 网络连接是否正常")
        print("3. 防火墙设置")
        return 1

if __name__ == "__main__":
    sys.exit(main())