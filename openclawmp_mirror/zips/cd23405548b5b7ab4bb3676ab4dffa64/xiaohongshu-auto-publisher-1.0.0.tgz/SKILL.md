---
name: xiaohongshu-auto-publisher
description: "小红书自动化发布工具 - 无需手动登录，支持图文笔记自动发布"
version: 1.0.0
author: 刀盾狗
tags: ["xiaohongshu", "redbook", "automation", "social-media", "china"]
category: social-media
---

# 小红书自动化发布Skill

## 🎯 功能概述
这是一个完整的自动化发布到小红书的技能，支持：
- 无需手动登录，使用cookies自动认证
- 自动发布图文笔记
- 支持多图片上传
- 完整的错误处理和日志
- 基于MCP服务的稳定发布

## 📁 文件结构
```
xiaohongshu-auto-publisher/
├── SKILL.md              # 技能说明文档
├── _meta.json            # 技能元数据
├── scripts/              # 脚本目录
│   ├── publish_xhs.py    # 主发布脚本
│   ├── setup_cookies.py  # cookies设置工具
│   └── test_publish.py   # 测试脚本
└── requirements.txt      # Python依赖
```

## 🚀 快速开始

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 设置cookies
```bash
python scripts/setup_cookies.py --cookie "your_cookie_string"
```

### 3. 启动MCP服务
```bash
# 下载并启动小红书MCP服务
./scripts/start_mcp_service.sh
```

### 4. 发布测试
```bash
python scripts/test_publish.py --title "测试标题" --content "测试内容" --images image1.png image2.png
```

## 🔧 核心功能

### 自动登录
- 使用cookies.json文件自动认证
- 支持cookies格式自动修复
- 自动检测登录状态

### 图片处理
- 支持PNG、JPG格式
- 自动验证图片有效性
- 批量上传支持

### 发布控制
- 标题和内容自动填充
- 标签自动添加
- 发布状态实时监控

## 📝 配置说明

### cookies.json格式
```json
[
  {
    "name": "cookie_name",
    "value": "cookie_value",
    "domain": ".xiaohongshu.com",
    "path": "/",
    "expires": -1,
    "httpOnly": false,
    "secure": false,
    "session": true
  }
]
```

### 环境变量
```bash
export XHS_MCP_URL="http://localhost:18060/mcp"
export XHS_COOKIES_PATH="~/.xiaohongshu/cookies.json"
```

## 🛠️ 故障排除

### 常见问题
1. **cookies过期**：重新获取最新cookies
2. **Windows Defender阻止**：将leakless.exe加入白名单
3. **图片上传失败**：检查图片格式和大小
4. **发布超时**：增加超时时间或检查网络

### 调试命令
```bash
# 检查MCP服务状态
curl http://localhost:18060/health

# 测试cookies有效性
python scripts/setup_cookies.py --test

# 查看详细日志
tail -f mcp_service.log
```

## 📈 高级功能

### 批量发布
```bash
python scripts/batch_publish.py --config batch_config.json
```

### 定时发布
```bash
# 使用cron定时任务
0 9 * * * python /path/to/scripts/publish_xhs.py --title "每日更新" --content "今日内容"
```

### 内容模板
支持Markdown模板，自动生成小红书格式内容。

## 🔒 安全说明
- cookies文件存储在用户本地
- 不传输敏感信息到第三方
- 支持cookies加密存储（可选）

## 🤝 贡献指南
欢迎提交Issue和Pull Request改进本技能。

## 📄 许可证
MIT License

## 📞 支持
如有问题，请在水产市场社区或GitHub Issues中反馈。