# 小红书自动化发布工具

一个完整的自动化发布到小红书的OpenClaw技能，支持无需手动登录、自动发布图文笔记。

## ✨ 特性

- ✅ **无需手动登录** - 使用cookies自动认证
- ✅ **自动发布** - 支持标题、内容、多图片
- ✅ **错误处理** - 完整的错误处理和日志
- ✅ **跨平台** - 支持Windows、macOS、Linux
- ✅ **简单配置** - 命令行和配置文件支持

## 🚀 快速开始

### 安装
```bash
# 使用水产市场社区安装
curl -sL https://openclawmp.cc/api/v1/assets/s-65623b82a16d719e/download -o /tmp/_oc_pkg.zip && unzip -oq /tmp/_oc_pkg.zip -d ~/.openclaw/skills/openclawmp && rm /tmp/_oc_pkg.zip
```

### 基本使用
```bash
# 1. 设置cookies
python scripts/setup_cookies.py --cookie "your_cookie_string"

# 2. 启动MCP服务
./scripts/start_mcp_service.sh

# 3. 发布笔记
python scripts/publish_xhs.py --title "测试标题" --content "测试内容" --images image1.png image2.png
```

## 📖 详细文档

### 1. 获取Cookies
从浏览器开发者工具获取小红书cookies：
1. 登录小红书网页版
2. 打开开发者工具 (F12)
3. 进入Application/Storage/Cookies
4. 复制所有cookies字符串

### 2. 配置Cookies
```bash
# 交互式设置
python scripts/setup_cookies.py

# 或直接提供
python scripts/setup_cookies.py --cookie "a1=xxx; webId=xxx; ..."
```

### 3. MCP服务
需要下载并运行小红书MCP服务：
- 下载地址: https://github.com/xpzouying/xiaohongshu-mcp/releases
- 默认端口: 18060

### 4. 发布笔记
```bash
# 基本发布
python scripts/publish_xhs.py --title "标题" --content "内容" --images img1.png img2.png

# 添加标签
python scripts/publish_xhs.py --title "标题" --content "内容 #标签1 #标签2" --images img.png

# 使用配置文件
python scripts/publish_xhs.py --config publish_config.json
```

## 🔧 配置文件示例

### publish_config.json
```json
{
  "title": "测试发布",
  "content": "这是测试内容 #测试 #小红书",
  "images": ["image1.png", "image2.png"],
  "tags": ["测试", "小红书"],
  "mcp_url": "http://localhost:18060/mcp",
  "cookies_path": "~/.xiaohongshu/cookies.json"
}
```

### 环境变量
```bash
export XHS_MCP_URL="http://localhost:18060/mcp"
export XHS_COOKIES_PATH="~/.xiaohongshu/cookies.json"
```

## 🛠️ 故障排除

### 常见问题

#### 1. Cookies过期
```
错误: cookies可能已过期
解决: 重新获取最新cookies
```

#### 2. Windows Defender阻止
```
错误: leakless.exe被阻止
解决: 将leakless.exe加入Windows Defender白名单
```

#### 3. 图片上传失败
```
错误: 图片格式不支持
解决: 使用PNG或JPG格式，确保文件大小合适
```

#### 4. 发布超时
```
错误: 发布超时
解决: 增加超时时间或检查网络连接
```

### 调试命令
```bash
# 检查MCP服务状态
curl http://localhost:18060/health

# 测试cookies格式
python scripts/setup_cookies.py --test

# 查看详细日志
tail -f mcp_service.log
```

## 📈 高级用法

### 批量发布
创建批量发布脚本：
```python
# batch_publish.py
import json
from publish_xhs import XHSAutoPublisher

with open('batch_config.json', 'r') as f:
    batch = json.load(f)

publisher = XHSAutoPublisher()
for item in batch:
    publisher.publish(item['title'], item['content'], item['images'])
```

### 定时发布
使用cron定时任务：
```bash
# 每天上午9点发布
0 9 * * * cd /path/to/skill && python scripts/publish_xhs.py --config daily_post.json
```

### 集成到OpenClaw
在OpenClaw中直接调用：
```python
# 在你的OpenClaw脚本中
from skills.xiaohongshu_auto_publisher.scripts.publish_xhs import XHSAutoPublisher

publisher = XHSAutoPublisher()
publisher.publish("标题", "内容", ["image.png"])
```

## 🤝 贡献

欢迎提交Issue和Pull Request改进本技能。

### 开发环境
```bash
# 克隆仓库
git clone https://github.com/your-repo/xiaohongshu-auto-publisher.git

# 安装开发依赖
pip install -r requirements.txt

# 运行测试
python scripts/test_publish.py
```

## 📄 许可证

MIT License

## 📞 支持

如有问题，请：
1. 查看[故障排除](#故障排除)部分
2. 在水产市场社区反馈
3. 提交GitHub Issue

## 🙏 致谢

- 感谢小红书MCP服务开发者
- 感谢OpenClaw社区
- 感谢所有贡献者