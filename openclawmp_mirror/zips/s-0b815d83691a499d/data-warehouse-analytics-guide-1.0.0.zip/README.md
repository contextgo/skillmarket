# Data Warehouse Analytics Guide

## Overview
从零构建数据仓库和分析管线，涵盖数据建模、ETL流程、BI可视化。

## Data Warehouse Architecture

```
Sources → Staging → Data Mart → BI Layer
  ↓          ↓          ↓          ↓
Raw Data  Cleaned    Aggregated   Dashboards
```

## Dimensional Modeling

### Star Schema
```
Fact Table: sales_fact
├── dim_date (date_key → date_id)
├── dim_product (product_key → product_id)
├── dim_customer (customer_key → customer_id)
└── dim_store (store_key → store_id)
```

### Key Patterns
- **Slowly Changing Dimensions (SCD Type 2)**: Track history with effective dates
- **Conformed Dimensions**: Share dimensions across marts
- **Junk Dimensions**: Group low-cardinality flags

## ETL Pipeline

### dbt Transformation (Recommended)
```sql
-- models/staging/stg_orders.sql
WITH source AS (
    SELECT * FROM {{ source('raw', 'orders') }}
),
cleaned AS (
    SELECT
        order_id,
        customer_id,
        DATE(created_at) AS order_date,
        amount,
        status
    FROM source
    WHERE status != 'cancelled'
)
SELECT * FROM cleaned
```

### Airflow Orchestration
```python
# Schedule daily ETL at 6 AM
with DAG('daily_etl', schedule_interval='0 6 * * *') as dag:
    extract = PythonOperator(task_id='extract', python_callable=extract_data)
    transform = BashOperator(task_id='transform', bash_command='dbt run')
    load = PythonOperator(task_id='load', python_callable=load_to_warehouse)
    
    extract >> transform >> load
```

## BI Best Practices

1. **Dashboard Design**: Lead with KPIs, drill-down for details
2. **Performance**: Pre-aggregate at hourly/daily granularity
3. **Freshness**: SLA for data latency (real-time vs batch)
4. **Governance**: Column-level lineage, data quality tests

## Tool Stack Comparison

| Tool | Best For | Cost |
|------|---------|------|
| Apache Spark | Large-scale batch | $$$ |
| dbt + Snowflake | Cloud analytics | $$ |
| DuckDB + dbt | Local/small-medium | Free |
| ClickHouse | Real-time analytics | $ |
| Trino/Presto | Cross-source queries | $$ |