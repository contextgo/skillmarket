#!/usr/bin/env python3
"""
课表日历生成脚本
输入：JSON 配置文件
输出：.ics 日历文件
"""

import json
import sys
import uuid
import argparse
from datetime import datetime, timedelta


def parse_weeks(spec):
    """解析周次字符串，如 '3-12,15,17-18' -> [3,4,...,12,15,17,18]"""
    weeks = []
    for part in spec.replace("，", ",").split(","):
        part = part.strip()
        if not part:
            continue
        if "-" in part:
            a, b = part.split("-", 1)
            weeks.extend(range(int(a.strip()), int(b.strip()) + 1))
        else:
            weeks.append(int(part))
    return sorted(set(weeks))


def week_day_to_date(semester_start, week, weekday):
    """
    计算第 week 周星期 weekday 的日期
    semester_start: 第一周周日的日期 (datetime)
    weekday: 1=周一, 2=周二, ..., 6=周六, 7=周日
    """
    if weekday == 7:
        offset = 0
    else:
        offset = weekday
    return semester_start + timedelta(weeks=week - 1, days=offset)


def format_dt(dt):
    return dt.strftime("%Y%m%dT%H%M%S")


def generate_ics(config):
    semester_start = datetime.strptime(config["semester_start"], "%Y-%m-%d")
    periods = config["periods"]
    holidays = {datetime.strptime(d, "%Y-%m-%d") for d in config.get("holidays", [])}
    makeup_days = {
        datetime.strptime(item["date"], "%Y-%m-%d"): item["weekday"]
        for item in config.get("makeup_days", [])
    }
    courses = config["courses"]

    events = []

    # 正常课程
    for c in courses:
        subject = c["subject"]
        cls = c["class"]
        weekday = c["weekday"]
        period = c["period"]
        room = c["room"]
        weeks = parse_weeks(c["weeks"]) if isinstance(c["weeks"], str) else c["weeks"]

        start_time_str, end_time_str = periods[period]
        sh, sm = map(int, start_time_str.split(":"))
        eh, em = map(int, end_time_str.split(":"))

        for week in weeks:
            date = week_day_to_date(semester_start, week, weekday)
            date_only = datetime(date.year, date.month, date.day)

            if date_only in holidays:
                continue

            dt_start = date.replace(hour=sh, minute=sm)
            dt_end = date.replace(hour=eh, minute=em)
            events.append((subject, cls, room, dt_start, dt_end))

    # 调休补课
    for makeup_date, target_weekday in makeup_days.items():
        delta = (makeup_date - semester_start).days
        week = delta // 7 + 1

        for c in courses:
            if c["weekday"] != target_weekday:
                continue
            weeks = parse_weeks(c["weeks"]) if isinstance(c["weeks"], str) else c["weeks"]
            if week not in weeks:
                continue

            period = c["period"]
            start_time_str, end_time_str = periods[period]
            sh, sm = map(int, start_time_str.split(":"))
            eh, em = map(int, end_time_str.split(":"))

            dt_start = makeup_date.replace(hour=sh, minute=sm)
            dt_end = makeup_date.replace(hour=eh, minute=em)
            events.append((c["subject"], c["class"], c["room"], dt_start, dt_end))

    # 生成 ICS
    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//OpenClaw//Course Calendar//CN",
        "CALSCALE:GREGORIAN",
        "X-WR-CALNAME:课程表",
        "X-WR-TIMEZONE:Asia/Shanghai",
        "BEGIN:VTIMEZONE",
        "TZID:Asia/Shanghai",
        "BEGIN:STANDARD",
        "DTSTART:19700101T000000",
        "TZOFFSETFROM:+0800",
        "TZOFFSETTO:+0800",
        "END:STANDARD",
        "END:VTIMEZONE",
    ]

    for subject, cls, room, dt_start, dt_end in sorted(events, key=lambda x: x[3]):
        uid = str(uuid.uuid4())
        lines.extend([
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTART;TZID=Asia/Shanghai:{format_dt(dt_start)}",
            f"DTEND;TZID=Asia/Shanghai:{format_dt(dt_end)}",
            f"SUMMARY:{subject} - {cls}",
            f"LOCATION:{room}",
            f"DESCRIPTION:科目：{subject}\\n班级：{cls}\\n教室：{room}",
            "STATUS:CONFIRMED",
            "END:VEVENT",
        ])

    lines.append("END:VCALENDAR")
    return "\r\n".join(lines), len(events)


def main():
    parser = argparse.ArgumentParser(description="课表日历生成器")
    parser.add_argument("--config", required=True, help="JSON 配置文件路径")
    parser.add_argument("--output", required=True, help="输出 .ics 文件路径")
    args = parser.parse_args()

    with open(args.config, encoding="utf-8") as f:
        config = json.load(f)

    ics_content, event_count = generate_ics(config)

    with open(args.output, "w", encoding="utf-8") as f:
        f.write(ics_content)

    print(f"✅ 已生成: {args.output}")
    print(f"📅 共 {event_count} 个日历事件")


if __name__ == "__main__":
    main()
