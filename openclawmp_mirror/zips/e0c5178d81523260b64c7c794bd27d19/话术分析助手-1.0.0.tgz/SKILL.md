---
name: 话术分析助手
displayName: 话术分析助手
description: 分析视频/直播话术，提取开场白、互动技巧、转化话术，给出优化建议。
version: 1.0.0
author: OpenClaw Edu
tags: [education, video, analysis, speech, optimization]
category: education
---

# 话术分析助手

分析视频直播话术。

## 功能

- 视频转文字
- 话术结构分析
- 开场白提取
- 互动技巧识别
- 转化话术分析

## 使用

```
@话术分析助手 分析这段直播回放，提取话术技巧
```
