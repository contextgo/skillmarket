---
name: imou-device-video
displayName: 乐橙视频与录像
version: 1.0.0
description: >
  乐橙（Imou）设备视频与录像技能。支持获取实时预览 HLS 流地址（供 OpenClaw 下载、播放、录制）；
  查询本地录像或云录像片段信息；按时间区间获取云录像/本地录像 HLS 回放地址。
  适用于：乐橙实时预览、直播地址、HLS流、本地录像、云录像、录像回放等场景。
metadata:
  {
    "openclaw":
      {
        "emoji": "📹",
        "requires": { "env": ["IMOU_APP_ID", "IMOU_APP_SECRET"], "pip": ["requests"] },
        "primaryEnv": "IMOU_APP_ID",
        "install":
          [
            { "id": "python-requests", "kind": "pip", "package": "requests", "label": "安装 requests 依赖" }
          ]
      }
  }
---

# 📹 乐橙视频与录像

获取乐橙设备通道的实时 HLS 流地址、本地/云录像片段、录像回放 HLS 地址。支持 OpenClaw 下载、播放、录制。

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install requests
```

### 2. 配置环境变量（必填）

```bash
export IMOU_APP_ID="你的应用ID"
export IMOU_APP_SECRET="你的应用密钥"
export IMOU_BASE_URL="API基础地址"
```

**API 基础地址说明：**

| 区域 | 数据中心 | 基础地址 |
|------|---------|---------|
| 中国大陆 | — | `https://openapi.lechange.cn` |
| 海外 | 东亚 | `https://openapi-sg.easy4ip.com:443` |
| 海外 | 中欧 | `https://openapi-fk.easy4ip.com:443` |
| 海外 | 美西 | `https://openapi-or.easy4ip.com:443` |

**如何获取 App ID 和 App Secret：**
- 访问 [乐橙开放平台](https://open.imou.com) 注册开发者账号
- 进入「应用管理」-「应用信息」获取 `appId` 和 `appSecret`

### 3. 运行命令

```bash
# 获取设备通道实时预览 HLS 地址（自动创建直播；如返回 LV1001，则从直播列表获取）
python3 {baseDir}/scripts/device_video.py live 设备ID 通道ID [--stream-id 0|1]

# 查询指定时间段的本地或云录像片段
python3 {baseDir}/scripts/device_video.py record-clips 设备ID 通道ID --begin "yyyy-MM-dd HH:mm:ss" --end "yyyy-MM-dd HH:mm:ss" [--local|--cloud] [--count 100] [--query-range 1-100]

# 获取指定时间段的录像回放 HLS 地址（本地或云录像）
python3 {baseDir}/scripts/device_video.py playback-hls 设备ID 通道ID --begin "yyyy-MM-dd HH:mm:ss" --end "yyyy-MM-dd HH:mm:ss" --record-type localRecord|cloudRecord [--stream-id 0|1]
```

## ✨ 功能特性

1. **实时预览 HLS**：选择设备+通道，获取实时预览 HLS 地址。支持 OpenClaw 下载、播放、录制。如绑定返回 LV1001（直播已存在），则查询直播列表返回现有 HLS 地址
2. **录像片段查询**：选择设备+通道，获取指定时间段（开始/结束）的本地或云录像片段列表
3. **录像回放 HLS**：选择设备+通道，获取指定时间段的本地或云录像 HLS 回放地址；支持 OpenClaw 下载、播放、录制。回放地址有效期有限，获取后请尽快使用

## 📡 请求标识

所有请求都会携带请求头 `Client-Type: OpenClaw`，用于平台识别。

## 📚 API 参考文档

| 接口 | 文档地址 |
|-----|---------|
| 开发规范 | https://open.imou.com/document/pages/c20750/ |
| 获取 accessToken | https://open.imou.com/document/pages/fef620/ |
| 创建设备直播（bindDeviceLive） | https://open.imou.com/document/pages/1bc396/ |
| 创建设备录像 HLS | https://open.imou.com/document/pages/185646/ |
| 获取直播列表（liveList） | https://open.imou.com/document/pages/b0e047/ |
| 查询本地录像 | https://open.imou.com/document/pages/396dce/ |
| 查询云录像 | https://open.imou.com/document/pages/8e0e35/ |

更多请求/响应格式详见 `references/imou-video-api.md`

## 💡 使用提示

- **Token 有效期**：每次运行自动获取，有效期3天
- **直播流**：`--stream-id 0` 为主码流，`1` 为子码流。如 API 返回 LV1001，脚本会自动回退到 liveList 查询同设备/通道/码流的现有 HLS
- **录像片段**：`--local` 使用 queryLocalRecords（参数 `count`，最大100；部分设备限制为32）。`--cloud` 使用 queryCloudRecords（参数 `queryRange` 如 `1-100`）。分页时以上一条的 endTime 作为下一条的 beginTime
- **回放 HLS**：时间格式 `yyyy-MM-dd HH:mm:ss`；不支持跨天。录像类型 `localRecord` 或 `cloudRecord`。获取后请尽快使用，地址会过期

## 🔒 数据流向说明

| 数据 | 发送至 | 用途 |
|-----|-------|-----|
| appId, appSecret | 乐橙开放平台 | 获取 accessToken |
| accessToken, deviceId, channelId 等 | 乐橙开放平台 | 实时预览、录像片段查询、回放 HLS |

所有请求仅发送至配置的 `IMOU_BASE_URL`（乐橙官方API），不涉及第三方。
