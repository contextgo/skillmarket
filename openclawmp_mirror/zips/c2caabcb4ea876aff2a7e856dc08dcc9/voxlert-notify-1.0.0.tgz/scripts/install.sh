#!/bin/bash
# Voxlert Notify — automated installer for OpenClaw
# Installs voxlert CLI + OpenClaw plugin, creates default config.
set -euo pipefail

EXTENSIONS_DIR="${HOME}/.openclaw/extensions/voxlert"
VOXLERT_CONFIG_DIR="${HOME}/.voxlert"
VOXLERT_CONFIG="${VOXLERT_CONFIG_DIR}/config.json"
SKILL_DIR="$(cd "$(dirname "$0")/.." && pwd)"
FALLBACK_AUDIO_DIR="${HOME}/.voxlert/cache/fallback"

echo "=== Voxlert Notify Installer ==="

# Step 1: Install voxlert CLI
if command -v voxlert &>/dev/null; then
  echo "[✓] voxlert CLI already installed: $(which voxlert)"
else
  echo "[→] Installing voxlert CLI via npm..."
  npm install -g @settinghead/voxlert
  if command -v voxlert &>/dev/null; then
    echo "[✓] voxlert CLI installed: $(which voxlert)"
  else
    echo "[✗] Failed to install voxlert. Ensure npm global bin is on PATH."
    exit 1
  fi
fi

# Step 2: Create default config if not exists
if [ -f "$VOXLERT_CONFIG" ]; then
  echo "[✓] Config exists: $VOXLERT_CONFIG"
else
  echo "[→] Creating default config..."
  mkdir -p "$VOXLERT_CONFIG_DIR"
  
  # Detect TTS backend
  TTS_BACKEND="none"
  TTS_URL=""
  if curl -sf http://localhost:8880/health &>/dev/null; then
    TTS_BACKEND="qwen3-tts"
    TTS_URL="http://localhost:8880"
    echo "[✓] Detected Qwen3-TTS on port 8880"
  elif curl -sf http://localhost:8779/health &>/dev/null; then
    TTS_BACKEND="chatterbox"
    TTS_URL="http://localhost:8779"
    echo "[✓] Detected Chatterbox on port 8779"
  else
    echo "[i] No TTS backend detected. Will use fallback audio phrases."
  fi

  cat > "$VOXLERT_CONFIG" << CONFIGEOF
{
  "voicePack": "adjutant",
  "tts": {
    "backend": "${TTS_BACKEND}",
    "url": "${TTS_URL}"
  },
  "llm": {
    "provider": "",
    "apiKey": "",
    "model": ""
  },
  "categories": {
    "task.complete": true,
    "task.error": true
  },
  "volume": 0.8
}
CONFIGEOF
  echo "[✓] Config created: $VOXLERT_CONFIG"
fi

# Step 3: Install OpenClaw plugin
echo "[→] Installing OpenClaw plugin..."
mkdir -p "$EXTENSIONS_DIR"

# Write plugin manifest
cat > "${EXTENSIONS_DIR}/openclaw.plugin.json" << 'PLUGINJSON'
{
  "id": "voxlert",
  "name": "Voxlert Notify",
  "description": "Speak when OpenClaw agent runs complete using Voxlert character voices.",
  "configSchema": {
    "type": "object",
    "additionalProperties": false,
    "properties": {
      "minDurationSeconds": {
        "type": "number",
        "default": 0,
        "description": "Only notify for runs lasting at least this many seconds (0 = always notify)"
      },
      "enabled": {
        "type": "boolean",
        "default": true,
        "description": "Master switch for Voxlert notifications"
      }
    }
  }
}
PLUGINJSON

# Write plugin code (with pre-generated audio + macOS 'say' fallback)
cat > "${EXTENSIONS_DIR}/index.ts" << 'PLUGINTS'
import { spawn, execSync } from "child_process";
import { appendFileSync, mkdirSync, readFileSync, existsSync, readdirSync } from "fs";
import { join } from "path";
import { homedir } from "os";

const HOOK_DEBUG_LOG = join(homedir(), ".voxlert", "hook-debug.log");
const VOXLERT_CONFIG = join(homedir(), ".voxlert", "config.json");
const FALLBACK_AUDIO_DIR = join(homedir(), ".voxlert", "cache", "fallback");

const FALLBACK_PHRASES = {
  "task.complete": [
    "Mission complete",
    "Job's done",
    "Objective secured",
    "Target neutralized",
    "All systems nominal",
    "Task execution verified",
    "Operation successful",
    "Standing by for orders",
  ],
  "task.error": [
    "Warning, anomaly detected",
    "Error encountered",
    "System malfunction",
    "Something went wrong",
    "Failure reported",
  ],
};

function debugLog(msg, data) {
  try {
    mkdirSync(join(homedir(), ".voxlert"), { recursive: true });
    const line =
      data !== undefined
        ? `[${new Date().toISOString()}] [voxlert-plugin] ${msg} ${JSON.stringify(data)}\n`
        : `[${new Date().toISOString()}] [voxlert-plugin] ${msg}\n`;
    appendFileSync(HOOK_DEBUG_LOG, line);
  } catch { /* best-effort */ }
}

function pickRandom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function isTtsAvailable() {
  try {
    const cfg = JSON.parse(readFileSync(VOXLERT_CONFIG, "utf-8"));
    const backend = cfg.tts_backend || cfg.tts?.backend || "none";
    if (backend === "none" || !backend) return false;
    const url = cfg.qwen_tts_url || cfg.tts?.url || "http://localhost:8100";
    try {
      execSync(`curl -sf --max-time 1 ${url}/health`, { stdio: "ignore" });
      return true;
    } catch {
      return false;
    }
  } catch {
    return false;
  }
}

function getCachedAudioFiles(prefix) {
  try {
    if (!existsSync(FALLBACK_AUDIO_DIR)) return [];
    return readdirSync(FALLBACK_AUDIO_DIR)
      .filter(f => f.startsWith(prefix) && (f.endsWith(".mp3") || f.endsWith(".wav")))
      .map(f => join(FALLBACK_AUDIO_DIR, f));
  } catch {
    return [];
  }
}

function playAudioFile(filePath) {
  if (!existsSync(filePath)) return;
  const cmd = process.platform === "darwin" ? "afplay" : "ffplay";
  const args = process.platform === "darwin"
    ? [filePath]
    : ["-nodisp", "-autoexit", "-loglevel", "quiet", filePath];
  debugLog("playing cached audio", { filePath });
  const child = spawn(cmd, args, { stdio: "ignore", detached: true });
  child.on("error", (err) => { debugLog("audio play error", { message: err.message }); });
  child.unref();
}

function sayFallback(phrase) {
  if (process.platform !== "darwin") return;
  debugLog("say fallback", { phrase });
  const child = spawn("say", ["-r", "180", phrase], { stdio: "ignore", detached: true });
  child.on("error", (err) => { debugLog("say spawn error", { message: err.message }); });
  child.unref();
}

export default function register(api) {
  api.on(
    "agent_end",
    async (event, ctx) => {
      const config = api.config?.plugins?.entries?.voxlert?.config ?? {};
      if (config.enabled === false) return;

      const minDurationSeconds = Number(config.minDurationSeconds) || 0;
      const startedAt = event?.startedAt ?? event?.context?.startedAt;
      const endedAt = event?.endedAt ?? event?.context?.endedAt;
      if (
        minDurationSeconds > 0 &&
        typeof startedAt === "number" &&
        typeof endedAt === "number"
      ) {
        const durationMs = endedAt - startedAt;
        if (durationMs < minDurationSeconds * 1000) return;
      }

      let lastAssistantMessage = "";
      const messages = event?.messages ?? event?.context?.messages ?? [];
      if (Array.isArray(messages) && messages.length > 0) {
        const last = messages[messages.length - 1];
        if (last?.content ?? last?.text) {
          lastAssistantMessage = String(last.content ?? last.text).slice(0, 2000);
        }
      }
      if (!lastAssistantMessage && event?.context?.sessionEntry) {
        lastAssistantMessage = String(event.context.sessionEntry).slice(0, 2000);
      }

      const cwd =
        event?.context?.workspaceDir ??
        event?.context?.workspace ??
        ctx?.workspaceDir ??
        ctx?.workspace ??
        "";

      const payload = {
        hook_event_name: "Stop",
        source: "openclaw",
        cwd: typeof cwd === "string" ? cwd : "",
        last_assistant_message: lastAssistantMessage || undefined,
      };

      debugLog("agent_end: attempting voxlert hook", payload);

      // Priority 1: Full TTS server
      const ttsUp = isTtsAvailable();
      if (ttsUp) {
        debugLog("TTS available, using voxlert hook");
        const child = spawn("voxlert", ["hook"], {
          stdio: ["pipe", "ignore", "ignore"],
          detached: true,
        });
        child.on("error", (err) => { debugLog("voxlert spawn error", { message: err.message }); });
        child.stdin.write(JSON.stringify(payload));
        child.stdin.end();
        child.unref();
        return;
      }

      // Priority 2: Pre-generated audio cache
      const cachedFiles = getCachedAudioFiles("complete_");
      if (cachedFiles.length > 0) {
        const audioFile = pickRandom(cachedFiles);
        debugLog("Using cached audio", { audioFile });
        playAudioFile(audioFile);
        return;
      }

      // Priority 3: macOS 'say' (last resort)
      const category = "task.complete";
      const phrases = FALLBACK_PHRASES[category] || FALLBACK_PHRASES["task.complete"];
      const phrase = pickRandom(phrases);
      debugLog("No cached audio, using say fallback", { category, phrase });
      sayFallback(phrase);
    },
    { priority: 0 }
  );
}
PLUGINTS

echo "[✓] Plugin installed to: $EXTENSIONS_DIR"

# Step 4: Install pre-generated audio files
if [ -d "${SKILL_DIR}/assets/fallback" ]; then
  echo "[→] Installing pre-generated audio files..."
  mkdir -p "$FALLBACK_AUDIO_DIR"
  cp "${SKILL_DIR}/assets/fallback/"*.mp3 "$FALLBACK_AUDIO_DIR/" 2>/dev/null || true
  count=$(ls "$FALLBACK_AUDIO_DIR/"*.mp3 2>/dev/null | wc -l | tr -d ' ')
  echo "[✓] ${count} audio files installed to: $FALLBACK_AUDIO_DIR"
else
  echo "[i] No bundled audio files found. Will use macOS 'say' as fallback."
fi

# Step 5: Run non-interactive setup (registers voice packs, detects TTS)
if command -v voxlert &>/dev/null; then
  echo "[→] Running voxlert setup (non-interactive)..."
  voxlert setup --yes 2>/dev/null || echo "[i] Setup completed with warnings (non-critical)"
  echo "[✓] Voice packs registered, config updated"
fi

echo ""
echo "=== Installation Complete ==="
echo ""
echo "Next steps:"
echo "  1. Restart OpenClaw gateway:  openclaw gateway restart"
echo "  2. Agent tasks will now speak on completion (pre-generated TTS audio)"
echo ""
echo "Optional upgrades:"
echo "  - Start Qwen3-TTS for game character voices (Apple Silicon / NVIDIA):"
echo "    cd \$(npm root -g)/@settinghead/voxlert/qwen3-tts-server"
echo "    pip install -r requirements.txt && python server.py"
echo "  - Set LLM for dynamic phrases:"
echo "    voxlert config set llm.provider openrouter"
echo "    voxlert config set llm.apiKey <your-key>"
