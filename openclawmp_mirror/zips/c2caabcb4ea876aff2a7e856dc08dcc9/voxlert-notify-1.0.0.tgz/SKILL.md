---
name: voxlert-notify
description: Voice notifications for OpenClaw agent runs. When a task completes, plays a sci-fi military voice line (pre-generated with gpt-4o-mini-tts). Works out of the box on macOS — no TTS server needed. Optional upgrade to full game character voices (StarCraft Adjutant, GLaDOS, etc.) with local TTS.
---

# Voxlert Notify

Voice notifications for OpenClaw agent runs. When an agent task completes, a sci-fi military voice line plays through your speakers — "Mission complete", "Target neutralized", "Standing by for orders", etc.

**Works out of the box** — includes 8 pre-generated audio files (gpt-4o-mini-tts). No API keys, no TTS server, no GPU needed.

## Installation

```bash
bash "$(dirname "$0")/scripts/install.sh"
openclaw gateway restart
```

That's it. Your agent will now speak when tasks finish.

## What It Does

- Listens for `agent_end` events (subagent tasks, cron jobs, isolated sessions)
- Plays a random voice line from 8 pre-generated sci-fi military phrases
- Audio plays via `afplay` (macOS) or `ffplay` (Linux)

## Audio Playback Priority

1. **TTS Server** (if running) → Full voxlert experience with game character voices
2. **Pre-generated audio** (bundled) → Plays cached mp3 files ← default
3. **macOS `say`** (last resort) → System TTS fallback

## Configuration

**Only notify for long tasks** (skip short ones):
```json
{
  "plugins": {
    "entries": {
      "voxlert": {
        "config": {
          "minDurationSeconds": 30
        }
      }
    }
  }
}
```

**Disable entirely:**
```json
{
  "plugins": {
    "entries": {
      "voxlert": {
        "config": {
          "enabled": false
        }
      }
    }
  }
}
```

## Optional: Full Voice Experience

For game character voices (StarCraft Adjutant, SHODAN, GLaDOS, C&C EVA):

```bash
# Start Qwen3-TTS server (Apple Silicon / NVIDIA GPU)
cd "$(npm root -g)/@settinghead/voxlert/qwen3-tts-server"
pip install -r requirements.txt
python server.py

# Change voice pack
voxlert pack list
voxlert pack use sc1-adjutant
```

## Troubleshooting

- **No sound**: Check `~/.voxlert/cache/fallback/` has mp3 files. Run `afplay ~/.voxlert/cache/fallback/complete_0.mp3` to test.
- **Debug logs**: `tail -f ~/.voxlert/hook-debug.log`
- **Plugin not loading**: `openclaw gateway restart`

## Uninstall

```bash
rm -rf ~/.openclaw/extensions/voxlert
rm -rf ~/.voxlert/cache/fallback
openclaw gateway restart
```

## References

- Voxlert: https://github.com/settinghead/voxlert
