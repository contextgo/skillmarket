---
name: slack-team-collab
description: Slack 团队协作技能。用于发送消息、管理频道、线程回复、文件上传、反应表情等。触发场景：(1) 用户要求发送 Slack 消息 (2) 通知团队成员 (3) 在 Slack 频道发布公告 (4) 上传文件到 Slack (5) 管理 Slack 频道或用户。
---

# Slack 团队协作

Slack 消息渠道适配器，支持团队间实时协作。

## 快速开始

### 发送消息

```bash
# 发送到频道
message action=send channel=slack target="#general" message="团队会议 10 分钟后开始"

# 发送到私信
message action=send channel=slack target="@username" message="请查收最新报告"

# 回复线程
message action=send channel=slack target="#general" message="同意这个方案" thread_id="1234567890.123456"
```

### 添加反应

```bash
# 添加 emoji 反应
message action=react channel=slack message_id="1234567890.123456" emoji="thumbsup"
```

### 上传文件

```bash
# 上传文件
message action=send channel=slack target="#reports" media="/path/to/report.pdf" caption="本月财务报告"
```

## 配置要求

### 1. 创建 Slack App

1. 访问 https://api.slack.com/apps
2. 点击 "Create New App"
3. 选择 "From scratch"
4. 输入 App Name 和选择 Workspace

### 2. 配置 OAuth & Permissions

**Bot Token Scopes（必需）：**

| Scope | 用途 |
|-------|------|
| `chat:write` | 发送消息 |
| `channels:read` | 读取频道列表 |
| `channels:history` | 读取频道历史 |
| `groups:read` | 读取私有频道 |
| `im:read` | 读取私信列表 |
| `im:history` | 读取私信历史 |
| `users:read` | 读取用户信息 |
| `reactions:write` | 添加反应 |
| `files:write` | 上传文件 |

### 3. 安装到 Workspace

1. 在 "OAuth & Permissions" 页面点击 "Install to Workspace"
2. 授权应用
3. 复制 **Bot User OAuth Token** (`xoxb-xxx` 格式)

### 4. 配置 OpenClaw

```bash
openclaw configure --section channels
```

添加 Slack 配置：

```json
{
  "slack": {
    "botToken": "xoxb-your-token-here",
    "signingSecret": "your-signing-secret"
  }
}
```

或通过环境变量：

```bash
export SLACK_BOT_TOKEN="xoxb-your-token-here"
export SLACK_SIGNING_SECRET="your-signing-secret"
```

## 常用操作

### 发送格式化消息

```bash
# Markdown 格式
message action=send channel=slack target="#general" message="*重要通知*\n• 项目 A 已完成\n• 项目 B 进行中"
```

### 定时提醒

结合 Cron 实现定时通知：

```bash
openclaw cron add \
  --name "Daily Standup Reminder" \
  --cron "0 9 * * 1-5" \
  --message "发送 Slack 消息提醒站会" \
  --announce
```

### 多频道广播

```bash
# 同时发送到多个频道
for channel in "#engineering" "#product" "#design"; do
  message action=send channel=slack target="$channel" message="新版本已发布"
done
```

## 最佳实践

### 1. 消息格式

- 使用 `*粗体*` 强调重点
- 使用 `_斜体_` 表示备注
- 使用 `` `代码` `` 标记命令或变量
- 使用 `>` 引用内容

### 2. 线程回复

对于频道内的讨论，优先使用线程回复保持频道整洁：

```bash
message action=send channel=slack target="#general" message="我的看法是..." thread_id="parent_message_ts"
```

### 3. @ 提及

- `@channel` — 通知所有频道成员
- `@here` — 通知当前在线成员
- `@user` — 提及特定用户

### 4. 文件分享

上传文件时添加描述性 caption：

```bash
message action=send channel=slack target="#docs" media="/reports/q3.pdf" caption="Q3 财报 - 收入增长 25%"
```

## 错误处理

| 错误 | 原因 | 解决方案 |
|------|------|---------|
| `channel_not_found` | 频道不存在或无权限 | 检查频道名称，确保 Bot 已加入频道 |
| `not_in_channel` | Bot 未加入频道 | 邀请 Bot 到频道：`/invite @BotName` |
| `invalid_auth` | Token 无效 | 检查 Bot Token 是否正确 |
| `missing_scope` | 缺少权限范围 | 在 App 管理页面添加所需 Scope |

## 安全建议

1. **不要硬编码 Token** — 使用环境变量或配置文件
2. **限制 Scope** — 只申请必需的权限
3. **轮换 Token** — 定期重新生成 Bot Token
4. **审计日志** — 定期检查 Slack App 的访问日志

## 参考资料

- [Slack API 文档](https://api.slack.com/docs)
- [消息格式化指南](https://api.slack.com/reference/surfaces/formatting)
- [Block Kit Builder](https://app.slack.com/block-kit-builder)

## 相关技能

- **qqbot-cron** — QQ Bot 定时提醒
- **feishu-doc** — 飞书文档操作
