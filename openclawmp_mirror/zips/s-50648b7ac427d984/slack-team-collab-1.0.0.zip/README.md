# Slack 团队协作技能

<div align="center">

**Slack Team Collaboration Skill for AI Agents**

[![OpenClaw](https://img.shields.io/badge/OpenClaw-Skill-blue)](https://openclaw.ai)
[![License](https://img.shields.io/badge/License-MIT-green.svg)](LICENSE)

</div>

## 📖 简介

这是一个为 OpenClaw Agent 设计的 Slack 团队协作技能包。它让 AI Agent 能够：

- 📤 发送消息到 Slack 频道和私信
- 🧵 线程回复
- 📁 上传文件
- 😀 添加反应表情
- 📢 广播通知

## 🚀 快速开始

### 安装

```bash
# 通过水产市场安装
openclawmp install skill/slack-team-collab

# 或手动安装
git clone https://github.com/your-username/slack-team-collab.git
cp -r slack-team-collab ~/.openclaw/skills/
```

### 配置

1. **创建 Slack App**
   - 访问 https://api.slack.com/apps
   - 创建新 App，选择 "From scratch"

2. **配置 OAuth Scopes**
   ```
   chat:write       # 发送消息
   channels:read    # 读取频道
   files:write      # 上传文件
   reactions:write  # 添加反应
   ```

3. **安装到 Workspace**
   - 获取 Bot User OAuth Token (`xoxb-xxx`)
   - 配置 OpenClaw：
     ```bash
     export SLACK_BOT_TOKEN="xoxb-your-token"
     ```

## 📝 使用示例

### 发送消息

```bash
message action=send channel=slack target="#general" message="团队会议 10 分钟后开始"
```

### 上传文件

```bash
message action=send channel=slack target="#reports" media="/path/to/report.pdf" caption="本月财报"
```

### 添加反应

```bash
message action=react channel=slack message_id="1234567890.123456" emoji="thumbsup"
```

## 📁 文件结构

```
slack-team-collab/
├── SKILL.md                 # 核心技能文档
├── manifest.json            # 技能元数据
├── scripts/
│   ├── send_message.py      # 发送消息脚本
│   └── upload_file.py       # 上传文件脚本
├── references/
│   └── api-reference.md     # Slack API 参考
└── assets/
    └── message-templates.json # 消息模板
```

## 🔧 功能特性

| 功能 | 描述 |
|------|------|
| 发送消息 | 支持文本、Markdown、Block Kit |
| 线程回复 | 在特定消息下回复 |
| 文件上传 | 支持各种文件类型 |
| 反应表情 | 添加 emoji 反应 |
| 消息模板 | 预设常用消息格式 |

## 🔐 安全建议

- ✅ 使用环境变量存储 Token
- ✅ 只申请必需的 OAuth Scopes
- ✅ 定期轮换 Token
- ✅ 审计 API 访问日志

## 📚 相关链接

- [OpenClaw 文档](https://docs.openclaw.ai)
- [Slack API 文档](https://api.slack.com/docs)
- [Block Kit Builder](https://app.slack.com/block-kit-builder)

## 📄 许可证

MIT License

---

<div align="center">

Made with ❤️ by 白羊

</div>
