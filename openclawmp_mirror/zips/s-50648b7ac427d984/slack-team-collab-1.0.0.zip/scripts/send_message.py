#!/usr/bin/env python3
"""
Slack 消息发送脚本

用法:
    python send_message.py --channel "#general" --message "Hello"
    python send_message.py --channel "#general" --message "Hello" --thread-ts "1234567890.123456"
    python send_message.py --channel "#general" --message "Hello" --blocks '[{"type":"section","text":{"type":"mrkdwn","text":"*Bold*"}}]'
"""

import argparse
import json
import os
import sys
from urllib.request import Request, urlopen
from urllib.error import HTTPError


def send_slack_message(
    channel: str,
    text: str,
    thread_ts: str = None,
    blocks: list = None,
    unfurl_links: bool = True,
    unfurl_media: bool = True,
) -> dict:
    """发送 Slack 消息"""

    token = os.environ.get("SLACK_BOT_TOKEN")
    if not token:
        raise ValueError("SLACK_BOT_TOKEN 环境变量未设置")

    url = "https://slack.com/api/chat.postMessage"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json; charset=utf-8",
    }

    payload = {
        "channel": channel,
        "text": text,
        "unfurl_links": unfurl_links,
        "unfurl_media": unfurl_media,
    }

    if thread_ts:
        payload["thread_ts"] = thread_ts

    if blocks:
        payload["blocks"] = blocks

    req = Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers)

    try:
        with urlopen(req) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as e:
        error_body = e.read().decode("utf-8")
        return {"ok": False, "error": f"HTTP {e.code}: {error_body}"}


def main():
    parser = argparse.ArgumentParser(description="发送 Slack 消息")
    parser.add_argument("--channel", "-c", required=True, help="目标频道 (如 #general)")
    parser.add_argument("--message", "-m", required=True, help="消息内容")
    parser.add_argument("--thread-ts", "-t", help="线程父消息时间戳")
    parser.add_argument("--blocks", "-b", help="Block Kit JSON (字符串)")
    parser.add_argument("--no-unfurl-links", action="store_true", help="禁用链接预览")
    parser.add_argument("--no-unfurl-media", action="store_true", help="禁用媒体预览")

    args = parser.parse_args()

    blocks = json.loads(args.blocks) if args.blocks else None

    result = send_slack_message(
        channel=args.channel,
        text=args.message,
        thread_ts=args.thread_ts,
        blocks=blocks,
        unfurl_links=not args.no_unfurl_links,
        unfurl_media=not args.no_unfurl_media,
    )

    if result.get("ok"):
        print(f"✅ 消息已发送到 {args.channel}")
        print(f"   ts: {result.get('ts')}")
    else:
        print(f"❌ 发送失败: {result.get('error')}")
        sys.exit(1)


if __name__ == "__main__":
    main()
