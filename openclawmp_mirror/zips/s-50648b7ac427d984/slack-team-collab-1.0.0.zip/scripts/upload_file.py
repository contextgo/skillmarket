#!/usr/bin/env python3
"""
Slack 文件上传脚本

用法:
    python upload_file.py --channel "#general" --file report.pdf
    python upload_file.py --channel "#general" --file report.pdf --title "Q3 Report" --comment "本月财报"
"""

import argparse
import json
import mimetypes
import os
import sys
from urllib.request import Request, urlopen
from urllib.error import HTTPError


def upload_slack_file(
    channel: str,
    file_path: str,
    title: str = None,
    comment: str = None,
    thread_ts: str = None,
) -> dict:
    """上传文件到 Slack"""

    token = os.environ.get("SLACK_BOT_TOKEN")
    if not token:
        raise ValueError("SLACK_BOT_TOKEN 环境变量未设置")

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"文件不存在: {file_path}")

    # 使用 files.upload API (multipart/form-data)
    url = "https://slack.com/api/files.upload"

    filename = os.path.basename(file_path)
    mime_type = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

    with open(file_path, "rb") as f:
        file_content = f.read()

    # 构建 multipart/form-data
    boundary = "----SlackFileUploadBoundary"
    body_parts = []

    # 添加文件
    body_parts.append(
        f'--{boundary}\r\n'
        f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
        f'Content-Type: {mime_type}\r\n\r\n'.encode("utf-8")
    )
    body_parts.append(file_content)
    body_parts.append(b'\r\n')

    # 添加频道
    body_parts.append(
        f'--{boundary}\r\n'
        f'Content-Disposition: form-data; name="channels"\r\n\r\n'
        f'{channel}\r\n'.encode("utf-8")
    )

    # 添加标题
    if title:
        body_parts.append(
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="title"\r\n\r\n'
            f'{title}\r\n'.encode("utf-8")
        )

    # 添加注释
    if comment:
        body_parts.append(
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="initial_comment"\r\n\r\n'
            f'{comment}\r\n'.encode("utf-8")
        )

    # 添加线程
    if thread_ts:
        body_parts.append(
            f'--{boundary}\r\n'
            f'Content-Disposition: form-data; name="thread_ts"\r\n\r\n'
            f'{thread_ts}\r\n'.encode("utf-8")
        )

    body_parts.append(f'--{boundary}--\r\n'.encode("utf-8"))

    body = b"".join(body_parts)

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": f"multipart/form-data; boundary={boundary}",
    }

    req = Request(url, data=body, headers=headers)

    try:
        with urlopen(req) as response:
            return json.loads(response.read().decode("utf-8"))
    except HTTPError as e:
        error_body = e.read().decode("utf-8")
        return {"ok": False, "error": f"HTTP {e.code}: {error_body}"}


def main():
    parser = argparse.ArgumentParser(description="上传文件到 Slack")
    parser.add_argument("--channel", "-c", required=True, help="目标频道 (如 #general)")
    parser.add_argument("--file", "-f", required=True, help="文件路径")
    parser.add_argument("--title", "-t", help="文件标题")
    parser.add_argument("--comment", "-m", help="文件注释/描述")
    parser.add_argument("--thread-ts", help="线程父消息时间戳")

    args = parser.parse_args()

    result = upload_slack_file(
        channel=args.channel,
        file_path=args.file,
        title=args.title,
        comment=args.comment,
        thread_ts=args.thread_ts,
    )

    if result.get("ok"):
        file_info = result.get("file", {})
        print(f"✅ 文件已上传到 {args.channel}")
        print(f"   文件名: {file_info.get('name')}")
        print(f"   文件ID: {file_info.get('id')}")
        print(f"   permalink: {file_info.get('permalink')}")
    else:
        print(f"❌ 上传失败: {result.get('error')}")
        sys.exit(1)


if __name__ == "__main__":
    main()
