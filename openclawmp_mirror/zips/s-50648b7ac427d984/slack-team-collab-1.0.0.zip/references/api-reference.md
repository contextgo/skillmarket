# Slack API 参考

## 核心 API 端点

### chat.postMessage

发送消息到频道、私信或多人群聊。

**URL**: `https://slack.com/api/chat.postMessage`

**方法**: POST

**必需参数**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `channel` | string | 频道 ID 或名称 (如 `C1234567890` 或 `#general`) |
| `text` | string | 消息文本内容 |

**可选参数**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `thread_ts` | string | 线程父消息的时间戳 |
| `blocks` | array | Block Kit 块数组 |
| `attachments` | array | 附件数组 |
| `unfurl_links` | boolean | 是否展开链接预览 |
| `unfurl_media` | boolean | 是否展开媒体预览 |
| `reply_broadcast` | boolean | 是否在主频道显示线程回复通知 |
| `parse` | string | 解析模式 (`none`/`full`) |
| `link_names` | boolean | 是否自动链接 @用户名 和 #频道名 |

**响应**:

```json
{
  "ok": true,
  "channel": "C1234567890",
  "ts": "1234567890.123456",
  "message": {
    "bot_id": "B1234567890",
    "type": "message",
    "text": "Hello, world!",
    "user": "U1234567890",
    "ts": "1234567890.123456"
  }
}
```

---

### files.upload

上传文件到 Slack。

**URL**: `https://slack.com/api/files.upload`

**方法**: POST (multipart/form-data)

**必需参数**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `file` | file | 要上传的文件 |
| `channels` | string | 目标频道 ID (逗号分隔多个) |

**可选参数**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `title` | string | 文件标题 |
| `initial_comment` | string | 文件注释/描述 |
| `thread_ts` | string | 线程父消息时间戳 |
| `filename` | string | 文件名 (默认使用上传文件名) |

---

### reactions.add

添加 emoji 反应到消息。

**URL**: `https://slack.com/api/reactions.add`

**方法**: POST

**必需参数**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `channel` | string | 频道 ID |
| `name` | string | emoji 名称 (不带 `:`) |
| `timestamp` | string | 消息时间戳 |

**示例**:

```json
{
  "channel": "C1234567890",
  "name": "thumbsup",
  "timestamp": "1234567890.123456"
}
```

---

### conversations.list

获取频道列表。

**URL**: `https://slack.com/api/conversations.list`

**方法**: GET

**可选参数**:

| 参数 | 类型 | 说明 |
|------|------|------|
| `types` | string | 频道类型 (`public_channel`, `private_channel`, `mpim`, `im`) |
| `exclude_archived` | boolean | 是否排除已归档频道 |
| `limit` | integer | 返回数量限制 |

---

### users.list

获取用户列表。

**URL**: `https://slack.com/api/users.list`

**方法**: GET

---

## 认证

所有 API 请求需要在 Header 中携带 Bot Token:

```
Authorization: Bearer xoxb-your-token-here
```

---

## 消息格式化

### 基本格式

| 语法 | 效果 |
|------|------|
| `*bold*` | **bold** |
| `_italic_` | *italic* |
| `~strikethrough~` | ~~strikethrough~~ |
| `` `code` `` | `code` |
| ````code block```` | 多行代码块 |
| `> quote` | 引用块 |

### 链接

```
<https://example.com|显示文本>
```

### 提及

| 语法 | 效果 |
|------|------|
| `<@U1234567890>` | @用户名 |
| `<#C1234567890>` | #频道名 |
| `<!channel>` | @channel |
| `<!here>` | @here |
| `<!everyone>` | @everyone |

---

## Block Kit

### 常用块类型

#### Section

```json
{
  "type": "section",
  "text": {
    "type": "mrkdwn",
    "text": "*标题*\n描述内容"
  }
}
```

#### Actions (按钮)

```json
{
  "type": "actions",
  "elements": [
    {
      "type": "button",
      "text": {
        "type": "plain_text",
        "text": "点击"
      },
      "action_id": "button_click"
    }
  ]
}
```

#### Divider

```json
{
  "type": "divider"
}
```

#### Image

```json
{
  "type": "image",
  "image_url": "https://example.com/image.png",
  "alt_text": "图片描述"
}
```

#### Context

```json
{
  "type": "context",
  "elements": [
    {
      "type": "mrkdwn",
      "text": "由 *Bot* 发布"
    }
  ]
}
```

---

## 错误码

| 错误 | 说明 |
|------|------|
| `channel_not_found` | 频道不存在或无权限 |
| `not_in_channel` | Bot 未加入该频道 |
| `invalid_auth` | Token 无效或已过期 |
| `missing_scope` | 缺少所需权限范围 |
| `ratelimited` | 请求频率超限 |
| `invalid_arguments` | 参数格式错误 |
| `message_not_found` | 消息不存在 |
| `cannot_find_thread` | 线程不存在 |
| `file_not_found` | 文件不存在 |

---

## 速率限制

- 每分钟每个方法约 20-100 次请求
- 收到 `429 Too Many Requests` 时检查 `Retry-After` Header
- 建议实现指数退避重试

---

## Webhook

### Incoming Webhook

用于简单推送消息:

```bash
curl -X POST -H 'Content-type: application/json' \
--data '{"text":"Hello, World!"}' \
https://hooks.slack.com/services/T00000000/B00000000/XXXXXXXXXXXXXXXXXXXXXXXX
```
