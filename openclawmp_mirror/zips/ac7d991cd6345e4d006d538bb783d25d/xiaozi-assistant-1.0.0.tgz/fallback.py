"""
失败恢复策略
"""

from typing import Dict, Any, List
from enum import Enum
import logging

logger = logging.getLogger(__name__)

class FailureType(Enum):
    """失败类型"""
    ELEMENT_NOT_FOUND = "element_not_found"
    ELEMENT_OBSTRUCTED = "element_obstructed"
    LOGIN_EXPIRED = "login_expired"
    ANTI_CRAWLER = "anti_crawler"
    TIMEOUT = "timeout"
    UNKNOWN = "unknown"

class RecoveryStrategy:
    """
    恢复策略
    """
    
    @staticmethod
    def get_strategy(failure_type: FailureType) -> List[str]:
        """获取对应策略"""
        strategies = {
            FailureType.ELEMENT_NOT_FOUND: ["wait", "scroll", "refresh", "retry"],
            FailureType.ELEMENT_OBSTRUCTED: ["scroll", "wait", "click_alternative"],
            FailureType.LOGIN_EXPIRED: ["relogin", "use_cookie", "skip"],
            FailureType.ANTI_CRAWLER: ["random_delay", "rotate_ip", "reduce_speed"],
            FailureType.TIMEOUT: ["retry", "increase_timeout", "simplify_action"],
            FailureType.UNKNOWN: ["screenshot", "report", "skip"],
        }
        return strategies.get(failure_type, ["report"])
    
    @staticmethod
    def classify_failure(error: str) -> FailureType:
        """分类失败原因"""
        error_lower = error.lower()
        
        if "not found" in error_lower or "cannot find" in error_lower:
            return FailureType.ELEMENT_NOT_FOUND
        elif "obstructed" in error_lower or "covered" in error_lower:
            return FailureType.ELEMENT_OBSTRUCTED
        elif "login" in error_lower or "auth" in error_lower:
            return FailureType.LOGIN_EXPIRED
        elif "captcha" in error_lower or "block" in error_lower:
            return FailureType.ANTI_CRAWLER
        elif "timeout" in error_lower:
            return FailureType.TIMEOUT
        else:
            return FailureType.UNKNOWN


class FallbackChain:
    """
    兜底链执行器
    """
    
    def __init__(self):
        self.strategies = RecoveryStrategy()
    
    async def execute_with_fallback(
        self,
        action: callable,
        *args,
        **kwargs
    ) -> Dict:
        """带兜底的执行"""
        try:
            result = await action(*args, **kwargs)
            return {"success": True, "result": result}
        except Exception as e:
            failure_type = self.strategies.classify_failure(str(e))
            strategies = self.strategies.get_strategy(failure_type)
            
            for strategy in strategies:
                try:
                    logger.info(f"Trying strategy: {strategy}")
                    # 执行恢复策略
                    result = await self._apply_strategy(strategy, action, *args, **kwargs)
                    if result.get("success"):
                        return result
                except Exception:
                    continue
            
            return {"success": False, "error": str(e), "type": failure_type.value}
    
    async def _apply_strategy(self, strategy: str, action, *args, **kwargs) -> Dict:
        """应用策略"""
        if strategy == "retry":
            return await action(*args, **kwargs)
        elif strategy == "wait":
            import asyncio
            await asyncio.sleep(2)
            return await action(*args, **kwargs)
        elif strategy == "screenshot":
            return {"success": False, "strategy": "screenshot"}
        
        return {"success": False}
