"""
智能 API 网关 - 脱敏版
功能: 多API自动路由 + 故障转移
"""

# ===== 配置 (请替换为你的 API Keys) =====
PROVIDERS = [
    {"name": "infiniteai", "endpoint": "https://api.infiniteai.cc/v1/chat/completions", 
     "api_key": "YOUR_API_KEY_HERE", "priority": 0,
     "models": ["gpt-5", "gpt-5-codex", "gpt-5.1", "gpt-5.2", "gpt-5.3-codex"]},
    
    {"name": "stephecurry", "endpoint": "https://stephecurry.asia/v1/chat/completions",
     "api_key": "YOUR_API_KEY_HERE", "priority": 1,
     "models": ["gpt-5", "gpt-5-codex", "gpt-5.2", "gemini-2.5-flash", "gemini-2.5-pro"]},
    
    {"name": "wzw", "endpoint": "https://wzw.pp.ua/v1/chat/completions",
     "api_key": "YOUR_API_KEY_HERE", "priority": 2,
     "models": ["claude-opus-4-5", "claude-sonnet-4-5", "claude-3-5-haiku"]},
    
    # ... 更多 providers
]

# ===== 任务路由 =====
TASK_ROUTES = {
    "default": {"preferred": ["gpt-5", "gpt-5-codex"], "fallback": ["claude-opus-4-5"]},
    "coding": {"preferred": ["kimi-for-coding", "gpt-5-codex"], "fallback": ["claude-sonnet"]},
    "reasoning": {"preferred": ["gpt-5.3-codex"], "fallback": ["gpt-5.2-codex"]},
    "writing": {"preferred": ["claude-sonnet-4-5"], "fallback": ["gpt-5"]},
    "cheap": {"preferred": ["deepseek-chat"], "fallback": ["gpt-4o-mini"]},
}

# 完整代码见源文件
# 此为精简版脱敏展示
