"""
增强工具箱整合入口
统一接口调用三层记忆、HTTP重试、健康监控
"""

from .memory_tier import MemorySystem, get_memory_system
from .http_retry import HTTPRetry, get_http_retry, with_retry
from .health_monitor import HealthMonitor, get_health_monitor, HealthStatus

# 版本
__version__ = "2.0.0"

class EnhancedToolkit:
    """
    增强工具箱 - 统一入口
    整合: 记忆 + HTTP + 监控
    """
    
    def __init__(self):
        self.memory = get_memory_system()
        self.http = get_http_retry()
        self.health = get_health_monitor()
    
    # ===== 记忆接口 =====
    def remember(self, key: str, value: str, tier: str = "L1"):
        """记忆存储"""
        self.memory.set(key, value, tier)
    
    def recall(self, key: str) -> str:
        """记忆读取"""
        return self.memory.get(key)
    
    def search_memory(self, query: str) -> dict:
        """语义搜索"""
        return self.memory.search(query)
    
    def log(self, content: str):
        """记录日记"""
        self.memory.append_daily(content)
    
    # ===== HTTP 接口 =====
    async def fetch(self, url: str, **kwargs) -> requests.Response:
        """带重试的 HTTP 请求"""
        import requests
        return await self.http.call_async(requests.get, url, **kwargs)
    
    # ===== 健康接口 =====
    async def health_check(self) -> dict:
        """健康检查"""
        report = await self.health.check_all()
        return {
            "status": report.status.value,
            "message": report.message,
            "checks": {k: v.value for k, v in report.checks.items()}
        }


# 全局实例
_toolkit = None

def get_toolkit() -> EnhancedToolkit:
    """获取增强工具箱"""
    global _toolkit
    if _toolkit is None:
        _toolkit = EnhancedToolkit()
    return _toolkit
