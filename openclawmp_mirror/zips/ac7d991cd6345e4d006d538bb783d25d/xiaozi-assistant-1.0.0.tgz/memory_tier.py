"""
三层记忆系统 + 语义搜索
L1: 工作记忆 (当前会话)
L2: 会话记忆 (24h滚动)
L3: 长期记忆 (MEMORY.md)
"""

import os
import json
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional, List, Dict

WORKSPACE = Path("/Users/apple/.openclaw/workspace")
MEMORY_DIR = WORKSPACE / "memory"

class MemoryTier:
    """单层记忆"""
    
    def __init__(self, name: str, ttl_seconds: int = 3600):
        self.name = name
        self.ttl = ttl_seconds
        self.cache: Dict[str, tuple] = {}  # key -> (value, timestamp)
    
    def get(self, key: str) -> Optional[str]:
        if key in self.cache:
            value, ts = self.cache[key]
            if time.time() - ts < self.ttl:
                return value
            del self.cache[key]
        return None
    
    def set(self, key: str, value: str):
        self.cache[key] = (value, time.time())
    
    def clear(self):
        self.cache.clear()


class MemorySystem:
    """
    三层记忆系统
    L1: 工作记忆 - 当前会话实时数据
    L2: 会话记忆 - 24小时滚动日记
    L3: 长期记忆 - MEMORY.md 精选
    """
    
    def __init__(self):
        # L1: 工作记忆 (TTL: 1小时)
        self.l1 = MemoryTier("L1_WORK", ttl_seconds=3600)
        # L2: 会话记忆 (TTL: 24小时)
        self.l2 = MemoryTier("L2_SESSION", ttl_seconds=86400)
        # L3: 长期记忆 (从文件加载)
        self.l3_content = self._load_l3()
    
    def _load_l3(self) -> str:
        """加载长期记忆"""
        memory_file = WORKSPACE / "MEMORY.md"
        if memory_file.exists():
            return memory_file.read_text()
        return ""
    
    def _get_daily_file(self, date: str = None) -> Path:
        """获取每日记忆文件"""
        if date is None:
            date = datetime.now().strftime("%Y-%m-%d")
        return MEMORY_DIR / f"{date}.md"
    
    # ===== L1 操作 =====
    def work_get(self, key: str) -> Optional[str]:
        """L1 读取"""
        return self.l1.get(key)
    
    def work_set(self, key: str, value: str):
        """L1 写入"""
        self.l1.set(key, value)
    
    # ===== L2 操作 =====
    def session_get(self, key: str) -> Optional[str]:
        """L2 读取"""
        return self.l2.get(key)
    
    def session_set(self, key: str, value: str):
        """L2 写入"""
        self.l2.set(key, value)
    
    def append_daily(self, content: str):
        """追加到今日日记"""
        daily_file = self._get_daily_file()
        daily_file.parent.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now().strftime("%H:%M")
        entry = f"\n### {timestamp} - {content}\n"
        
        if daily_file.exists():
            daily_file.write_text(daily_file.read_text() + entry)
        else:
            daily_file.write_text(f"# {datetime.now().date()}\n" + entry)
        
        # 同时写入 L2 缓存
        self.session_set(f"daily_{daily_file.stem}", content)
    
    # ===== L3 操作 =====
    def longterm_get(self) -> str:
        """L3 读取"""
        return self._load_l3()
    
    def longterm_update(self, content: str):
        """L3 更新"""
        memory_file = WORKSPACE / "MEMORY.md"
        memory_file.write_text(content)
        self.l3_content = content
    
    # ===== 语义搜索 =====
    def search(self, query: str) -> Dict[str, any]:
        """
        语义搜索 (简化版)
        优先搜索 L1 -> L2 -> L3
        """
        results = {"l1": [], "l2": [], "l3": []}
        
        # 简化搜索: 关键词匹配
        query_lower = query.lower()
        
        # L1 搜索
        for key, (value, _) in self.l1.cache.items():
            if query_lower in key.lower() or query_lower in value.lower():
                results["l1"].append({"key": key, "value": value})
        
        # L2 搜索
        for key, (value, _) in self.l2.cache.items():
            if query_lower in key.lower() or query_lower in value.lower():
                results["l2"].append({"key": key, "value": value})
        
        # L3 搜索
        if query_lower in self.l3_content.lower():
            # 找到匹配段落
            lines = self.l3_content.split('\n')
            for i, line in enumerate(lines):
                if query_lower in line.lower():
                    results["l3"].append({
                        "line": i,
                        "content": line.strip()
                    })
        
        return results
    
    # ===== 统一接口 =====
    def get(self, key: str) -> Optional[str]:
        """统一读取接口 (L1 -> L2 -> L3)"""
        # 先查 L1
        val = self.work_get(key)
        if val:
            return val
        
        # 再查 L2
        val = self.session_get(key)
        if val:
            return val
        
        return None
    
    def set(self, key: str, value: str, tier: str = "L1"):
        """统一写入接口"""
        if tier == "L1":
            self.work_set(key, value)
        elif tier == "L2":
            self.session_set(key, value)
        elif tier == "L3":
            self.longterm_update(value)


# 全局实例
_memory_system = None

def get_memory_system() -> MemorySystem:
    """获取全局记忆系统实例"""
    global _memory_system
    if _memory_system is None:
        _memory_system = MemorySystem()
    return _memory_system
