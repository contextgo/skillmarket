"""
HTTP 重试高级版
特性: 指数退避 + 超时控制 + 连接池复用 + 自动重试
"""

import time
import asyncio
from typing import Callable, Any, Optional
from functools import wraps
import logging

logger = logging.getLogger(__name__)

class HTTPRetry:
    """
    HTTP 重试控制器
    支持: 指数退避、连接池、超时控制
    """
    
    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 30.0,
        exponential_base: float = 2.0,
        timeout: float = 30.0
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.exponential_base = exponential_base
        self.timeout = timeout
        
        # 连接池 (简化版)
        self._pools: dict = {}
    
    def _calculate_delay(self, attempt: int) -> float:
        """计算指数退避延迟"""
        delay = self.base_delay * (self.exponential_base ** attempt)
        return min(delay, self.max_delay)
    
    def _should_retry(self, error: Exception) -> bool:
        """判断是否应该重试"""
        retryable_errors = (
            ConnectionError,
            TimeoutError,
            OSError,
        )
        return isinstance(error, retryable_errors)
    
    async def _async_call(
        self,
        func: Callable,
        *args,
        **kwargs
    ) -> Any:
        """异步调用 + 重试"""
        last_error = None
        
        for attempt in range(self.max_retries + 1):
            try:
                # 执行异步调用
                if asyncio.iscoroutinefunction(func):
                    result = await asyncio.wait_for(
                        func(*args, **kwargs),
                        timeout=self.timeout
                    )
                else:
                    result = await asyncio.wait_for(
                        asyncio.to_thread(func, *args, **kwargs),
                        timeout=self.timeout
                    )
                return result
                
            except Exception as e:
                last_error = e
                
                if not self._should_retry(e):
                    logger.error(f"Non-retryable error: {e}")
                    raise
                
                if attempt < self.max_retries:
                    delay = self._calculate_delay(attempt)
                    logger.warning(
                        f"Attempt {attempt + 1} failed: {e}. "
                        f"Retrying in {delay:.1f}s..."
                    )
                    await asyncio.sleep(delay)
                else:
                    logger.error(f"All {self.max_retries} retries exhausted")
        
        raise last_error
    
    def _sync_call(
        self,
        func: Callable,
        *args,
        **kwargs
    ) -> Any:
        """同步调用 + 重试"""
        import requests
        
        last_error = None
        
        for attempt in range(self.max_retries + 1):
            try:
                # 使用 session 复用连接
                session = self._get_session()
                return session.request(
                    *args,
                    **kwargs,
                    timeout=self.timeout
                )
                
            except Exception as e:
                last_error = e
                
                if not self._should_retry(e):
                    raise
                
                if attempt < self.max_retries:
                    delay = self._calculate_delay(attempt)
                    logger.warning(
                        f"Attempt {attempt + 1} failed. "
                        f"Retrying in {delay:.1f}s..."
                    )
                    time.sleep(delay)
                else:
                    raise
        
        raise last_error
    
    def _get_session(self) -> 'requests.Session':
        """获取复用连接池"""
        import requests
        
        if 'default' not in self._pools:
            self._pools['default'] = requests.Session()
            # 配置连接池
            adapter = requests.adapters.HTTPAdapter(
                pool_connections=10,
                pool_maxsize=20,
                max_retries=0  # 我们自己控制重试
            )
            self._pools['default'].mount('http://', adapter)
            self._pools['default'].mount('https://', adapter)
        
        return self._pools['default']
    
    def call(self, func: Callable, *args, **kwargs) -> Any:
        """同步调用入口"""
        return self._sync_call(func, *args, **kwargs)
    
    async def call_async(self, func: Callable, *args, **kwargs) -> Any:
        """异步调用入口"""
        return await self._async_call(func, *args, **kwargs)


# 装饰器方式使用
def with_retry(
    max_retries: int = 3,
    base_delay: float = 1.0,
    timeout: float = 30.0
):
    """重试装饰器"""
    retry = HTTPRetry(
        max_retries=max_retries,
        base_delay=base_delay,
        timeout=timeout
    )
    
    def decorator(func: Callable):
        @wraps(func)
        def wrapper(*args, **kwargs):
            return retry.call(func, *args, **kwargs)
        
        @wraps(func)
        async def async_wrapper(*args, **kwargs):
            return await retry.call_async(func, *args, **kwargs)
        
        # 返回合适的包装器
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return wrapper
    
    return decorator


# 全局实例
_http_retry = None

def get_http_retry() -> HTTPRetry:
    """获取全局 HTTP 重试实例"""
    global _http_retry
    if _http_retry is None:
        _http_retry = HTTPRetry()
    return _http_retry
