"""
自愈健康监控系统
特性: 健康检查 + 自动修复 + 告警
"""

import time
import asyncio
import subprocess
from typing import Callable, Dict, List, Optional, Any
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
import logging

logger = logging.getLogger(__name__)

class HealthStatus(Enum):
    """健康状态"""
    HEALTHY = "healthy"
    DEGRADED = "degraded"
    UNHEALTHY = "unhealthy"
    UNKNOWN = "unknown"

@dataclass
class HealthCheck:
    """健康检查项"""
    name: str
    check_func: Callable[[], bool]
    critical: bool = False
    interval_seconds: int = 60
    retry_count: int = 3

@dataclass
class HealthReport:
    """健康报告"""
    status: HealthStatus
    checks: Dict[str, HealthStatus]
    timestamp: datetime = field(default_factory=datetime.now)
    message: str = ""

class HealthMonitor:
    """
    自愈健康监控系统
    功能:
    - 定期健康检查
    - 失败自动重试/修复
    - 状态告警
    """
    
    def __init__(self):
        self.checks: Dict[str, HealthCheck] = {}
        self.status = HealthStatus.UNKNOWN
        self.last_report: Optional[HealthReport] = None
        
        # 修复动作映射
        self.fixes: Dict[str, Callable[[], bool]] = {}
        
        # 运行状态
        self._running = False
        self._tasks: List[asyncio.Task] = []
    
    def register_check(
        self,
        name: str,
        check_func: Callable[[], bool],
        critical: bool = False,
        interval_seconds: int = 60,
        retry_count: int = 3
    ):
        """注册健康检查"""
        self.checks[name] = HealthCheck(
            name=name,
            check_func=check_func,
            critical=critical,
            interval_seconds=interval_seconds,
            retry_count=retry_count
        )
        logger.info(f"Registered health check: {name}")
    
    def register_fix(self, name: str, fix_func: Callable[[], bool]):
        """注册修复动作"""
        self.fixes[name] = fix_func
        logger.info(f"Registered fix: {name}")
    
    def _run_check(self, check: HealthCheck) -> HealthStatus:
        """执行单个检查"""
        try:
            result = check.check_func()
            return HealthStatus.HEALTHY if result else HealthStatus.UNHEALTHY
        except Exception as e:
            logger.error(f"Check {check.name} error: {e}")
            return HealthStatus.UNKNOWN
    
    def _attempt_fix(self, check_name: str) -> bool:
        """尝试修复"""
        if check_name in self.fixes:
            try:
                logger.info(f"Attempting fix for {check_name}...")
                return self.fixes[check_name]()
            except Exception as e:
                logger.error(f"Fix {check_name} failed: {e}")
        return False
    
    async def check_all(self) -> HealthReport:
        """执行所有检查"""
        results = {}
        has_critical_failure = False
        
        for name, check in self.checks.items():
            status = self._run_check(check)
            results[name] = status
            
            # 关键检查失败
            if status == HealthStatus.UNHEALTHY and check.critical:
                has_critical_failure = True
                
                # 尝试修复
                if self._attempt_fix(name):
                    # 修复后重新检查
                    time.sleep(1)
                    recheck = self._run_check(check)
                    results[name] = recheck
        
        # 综合状态
        if has_critical_failure:
            status = HealthStatus.UNHEALTHY
        elif any(s == HealthStatus.UNHEALTHY for s in results.values()):
            status = HealthStatus.DEGRADED
        else:
            status = HealthStatus.HEALTHY
        
        report = HealthReport(
            status=status,
            checks=results,
            message=f"{sum(1 for s in results.values() if s == HealthStatus.HEALTHY)}/{len(results)} checks passed"
        )
        
        self.last_report = report
        return report
    
    async def start_monitoring(self):
        """启动监控循环"""
        self._running = True
        
        while self._running:
            try:
                report = await self.check_all()
                
                if report.status == HealthStatus.UNHEALTHY:
                    logger.warning(f"Health check failed: {report.message}")
                    # 这里可以添加告警通知
                
                # 等待下次检查
                await asyncio.sleep(60)
                
            except Exception as e:
                logger.error(f"Monitor loop error: {e}")
                await asyncio.sleep(10)
    
    def stop(self):
        """停止监控"""
        self._running = False
        for task in self._tasks:
            task.cancel()


# 预设检查函数
def check_gateway_health() -> bool:
    """检查 Gateway 是否健康"""
    try:
        import requests
        resp = requests.get("http://127.0.0.1:18789/health", timeout=5)
        return resp.status_code == 200
    except:
        return False

def check_disk_space() -> bool:
    """检查磁盘空间"""
    try:
        import shutil
        stat = shutil.disk_usage("/")
        # 大于 5GB 认为健康
        return stat.free > 5 * 1024**3
    except:
        return False

def restart_gateway() -> bool:
    """重启 Gateway"""
    try:
        subprocess.run(
            ["openclaw", "gateway", "restart"],
            capture_output=True,
            timeout=30
        )
        time.sleep(3)
        return check_gateway_health()
    except:
        return False


# 全局实例
_health_monitor = None

def get_health_monitor() -> HealthMonitor:
    """获取全局健康监控实例"""
    global _health_monitor
    if _health_monitor is None:
        _health_monitor = HealthMonitor()
        # 注册默认检查
        _health_monitor.register_check(
            "gateway",
            check_gateway_health,
            critical=True,
            interval_seconds=60
        )
        _health_monitor.register_check(
            "disk",
            check_disk_space,
            critical=False,
            interval_seconds=300
        )
        # 注册修复动作
        _health_monitor.register_fix("gateway", restart_gateway)
    return _health_monitor
