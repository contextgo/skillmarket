---
name: marketplace-helper
displayName: 水产市场发布助手
description: 封装 openclawmp 发布流程：自动版本递增、安全扫描、发布审批摘要。token 存储在本地 ~/.openclaw/hub-credentials.json，不写入 skill。
version: 1.0.0
tags: ["openclawmp", "marketplace", "publish", "automation"]
---

# 水产市场发布助手

## 安全声明

⚠️ **token 不会打包进 skill，永远只存在本地凭证文件。**

## token 管理

- 本地凭证路径：`~/.openclaw/hub-credentials.json`
- 发布前检查：`openclawmp login`
- 如需写入：`openclawmp oauth <token>`（需用户主动提供）

## 发布流程

当用户说"帮我发布 XXX"时，执行以下链路：

```
1. 确认资产目录路径
2. 安全扫描（不打包，不上传）
3. 质量评分（如有 quality-rubric.md）
4. 生成审批摘要
5. 等待用户确认「发布」
6. 版本递增（semver +1）
7. 执行发布
```

## 安全扫描规则

| 类型 | 模式 |
|---|---|
| API Key | `sk-`、`ghp_`、`xoxb-` 等 |
| 密码/Secret | `password=`、`SECRET_KEY` 等 |
| 个人信息 | 手机号、邮箱 |
| 内部标识 | 飞书 `ou_`、app_id 等 |

命中时在摘要中 ⚠️ 标注，不硬拦截。

## 发布命令

```bash
openclawmp publish <path> --asset-id <assetId> --yes
```

## 典型触发语

- "帮我发布 XXX"
- "发布这个 skill"
- "发布到水产市场"

## 返回格式

发布成功后返回：
- assetId
- 新版本号
- 安装命令
- 安审状态
