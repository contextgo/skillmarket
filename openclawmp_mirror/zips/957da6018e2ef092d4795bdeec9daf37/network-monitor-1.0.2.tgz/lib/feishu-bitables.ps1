# Feishu Bitable Library v2 - Network Monitor
# Token 从 OpenClaw 加密存储读取（通过配置文件中的 app_id 定位）
# UTF-8 BOM free

$script:FeishuConfig = $null
$script:UserTokenCache = @{token=$null; expire_at=0}
$script:TableFieldMappings = @{}

function Get-OpenClawUserToken {
    if ($script:FeishuConfig.user_access_token) {
        return $script:FeishuConfig.user_access_token
    }
    
    $nowMs = [DateTime]::UtcNow.Ticks
    if ($script:UserTokenCache.token -and $script:UserTokenCache.expire_at -gt $nowMs) {
        return $script:UserTokenCache.token
    }
    
    $appId = $script:FeishuConfig.app_id
    if (-not $appId) {
        Write-Warning "No app_id configured in feishu settings"
        return $null
    }
    
    $decryptScript = @"
const{readFileSync,existsSync}=require('fs');
const{createDecipheriv}=require('crypto');
const path=require('path'),os=require('os');
const d=path.join(process.env.LOCALAPPDATA||path.join(os.homedir(),'AppData','Local'),'openclaw-feishu-uat');
const mk=path.join(d,'master.key');
const fs=require('fs');
let encFile='';
try{
const files=fs.readdirSync(d);
for(const f of files){
if(f.startsWith('${appId}_ou_')&&f.endsWith('.enc')){encFile=path.join(d,f);break;}
}
}catch{}
if(!encFile||!existsSync(mk)){process.exit(1);}
try{
const k=readFileSync(mk),e=readFileSync(encFile);
const iv=e.subarray(0,12),tag=e.subarray(12,28),c=e.subarray(28);
const x=createDecipheriv('aes-256-gcm',k,iv);x.setAuthTag(tag);
const td=JSON.parse(Buffer.concat([x.update(c),x.final()]).toString('utf8'));
console.log(JSON.stringify({token:td.accessToken||td.access_token,expireAt:td.expiresAt||td.expire_at||0}));
}catch(e){process.exit(1);}
"@
    
    $nodeScript = "$env:TEMP\decrypt_uat_$PID.js"
    $decryptScript | Out-File -FilePath $nodeScript -Encoding UTF8 -Width 200
    
    try {
        $output = & node $nodeScript 2>$null
        Remove-Item $nodeScript -ErrorAction SilentlyContinue
        if ($output) {
            $data = $output | ConvertFrom-Json
            $token = $data.token
            $expireAt = $data.expireAt
            if ($token -and $token.Length -gt 10) {
                $bufferMs = 5 * 60 * 1000
                $script:UserTokenCache.token = $token
                $script:UserTokenCache.expire_at = ($expireAt - $bufferMs) * 10000
                return $token
            }
        }
    } catch {}
    Remove-Item $nodeScript -ErrorAction SilentlyContinue
    return $null
}

function Initialize-FeishuBitable {
    param([string]$ConfigPath)
    $configJson = Get-Content -Path $ConfigPath -Raw -Encoding UTF8
    $config = $configJson | ConvertFrom-Json
    $script:FeishuConfig = $config.feishu
    if (-not $script:FeishuConfig.enabled) { return $false }
    if (-not $script:FeishuConfig.bitable_app_token) {
        Write-Warning "Missing bitable_app_token in config"
        return $false
    }
    
    $token = Get-OpenClawUserToken
    if (-not $token) {
        Write-Warning "Could not get user token from OpenClaw encrypted storage"
        return $false
    }
    
    if ($config.feishu.field_maps) {
        $script:TableFieldMappings = @{}
        foreach ($tbl in $config.feishu.field_maps.PSObject.Properties.Name) {
            $script:TableFieldMappings[$tbl] = $config.feishu.field_maps.$tbl
        }
        Write-Host "Loaded field mappings for $($script:TableFieldMappings.Count) tables"
    }
    
    return $true
}

function Invoke-FeishuApi {
    param(
        [Parameter(Mandatory=$false)]
        [ValidateSet("GET","POST","PUT","DELETE","PATCH")]
        [string]$Method = "GET",
        [Parameter(Mandatory=$true)]
        [string]$ApiPath,
        [object]$Body = $null,
        [string]$Token = $null
    )
    
    if (-not $Token) { $Token = Get-OpenClawUserToken }
    if (-not $Token) { return @{success=$false; code=-1; msg="No token"} }
    
    $url = "https://open.feishu.cn/open-apis" + $ApiPath
    $hdrs = @{"Authorization" = "Bearer $Token"; "Content-Type" = "application/json; charset=utf-8"}
    
    try {
        $bodyStr = if ($Body) { $Body | ConvertTo-Json -Compress -Depth 10 } else { $null }
        
        switch ($Method.ToUpper()) {
            "GET"    { $raw = if ($bodyStr) { Invoke-RestMethod -Uri $url -Method Get -Headers $hdrs -Body ([System.Text.Encoding]::UTF8.GetBytes($bodyStr)) -TimeoutSec 20 } else { Invoke-RestMethod -Uri $url -Method Get -Headers $hdrs -TimeoutSec 20 } }
            "POST"   { $raw = Invoke-RestMethod -Uri $url -Method Post -Headers $hdrs -Body ([System.Text.Encoding]::UTF8.GetBytes($bodyStr)) -TimeoutSec 20 }
            "PUT"    { $raw = Invoke-RestMethod -Uri $url -Method Put -Headers $hdrs -Body ([System.Text.Encoding]::UTF8.GetBytes($bodyStr)) -TimeoutSec 20 }
            "DELETE" { $raw = Invoke-RestMethod -Uri $url -Method Delete -Headers $hdrs -TimeoutSec 20 }
            "PATCH"  { $raw = Invoke-RestMethod -Uri $url -Method Patch -Headers $hdrs -Body ([System.Text.Encoding]::UTF8.GetBytes($bodyStr)) -TimeoutSec 20 }
        }
        
        if ($null -ne $raw) {
            $ok = $false
            $cd = $null; $mg = $null; $dt = $null
            if ($raw.PSObject.Properties.Name -contains "code") { $cd = $raw.code }
            if ($raw.PSObject.Properties.Name -contains "msg") { $mg = $raw.msg }
            if ($raw.PSObject.Properties.Name -contains "data") { $dt = $raw.data }
            if ($dt -and $dt.PSObject.Properties.Name -contains "record") { $dt = $dt.record }
            if ($cd -eq 0) { $ok = $true }
            return @{success=$ok; code=$cd; msg=$mg; data=$dt}
        }
        return @{success=$false; code=-2; msg="Empty response"}
    } catch {
        $ex = $_.Exception
        $errCode = -1; $errMsg = $ex.Message
        if ($ex.Response) {
            $status = [int]$ex.Response.StatusCode
            $stream = $ex.Response.GetResponseStream()
            $stream.Position = 0
            $rdr = [System.IO.StreamReader]::new($stream)
            $bodyText = $rdr.ReadToEnd(); $rdr.Close()
            try {
                $j = $bodyText | ConvertFrom-Json
                $errCode = if ($j.code) { $j.code } else { $status }
                $errMsg = if ($j.msg) { $j.msg } else { $bodyText }
            } catch {
                $errCode = $status; $errMsg = $bodyText
            }
        }
        return @{success=$false; code=$errCode; msg=$errMsg}
    }
}

function New-FeishuRecord {
    param([string]$TableId, [hashtable]$Fields)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    if ($script:TableFieldMappings -and $script:TableFieldMappings[$TableId]) {
        $maps = $script:TableFieldMappings[$TableId]
        $mapped = @{}
        foreach ($key in $Fields.Keys) {
            $chinese = $maps[$key]
            if ($chinese) { $mapped[$chinese] = $Fields[$key] } else { $mapped[$key] = $Fields[$key] }
        }
        $Fields = $mapped
    }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "POST" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records" -Body @{fields=$Fields}
    
    if (-not $result.success) {
        Write-Warning "Create record failed: $($result.msg) (code $($result.code))"
        return $null
    }
    return $result.data.record
}

function Get-FeishuRecords {
    param([string]$TableId, [string]$ViewId = "", [int]$PageSize = 50, [string]$PageToken = "")
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $path = "/bitable/v1/apps/$appToken/tables/$TableId/records/search"
    
    $q = @{page_size=$PageSize; fields=@()}
    if ($ViewId) { $q.view_id = $ViewId }
    if ($PageToken) { $q.page_token = $PageToken }
    
    $result = Invoke-FeishuApi -Method "POST" -ApiPath $path -Body $q
    
    if (-not $result.success) {
        Write-Warning "Get records failed: $($result.msg)"
        return $null
    }
    return $result.data
}

function Update-FeishuRecord {
    param([string]$TableId, [string]$RecordId, [hashtable]$Fields)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    if ($script:TableFieldMappings -and $script:TableFieldMappings[$TableId]) {
        $maps = $script:TableFieldMappings[$TableId]
        $mapped = @{}
        foreach ($key in $Fields.Keys) {
            $chinese = $maps[$key]
            if ($chinese) { $mapped[$chinese] = $Fields[$key] } else { $mapped[$key] = $Fields[$key] }
        }
        $Fields = $mapped
    }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "PUT" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records/$RecordId" -Body @{fields=$Fields}
    
    if (-not $result.success) {
        Write-Warning "Update record failed: $($result.msg)"
        return $null
    }
    return $result.data.record
}

function Delete-FeishuRecord {
    param([string]$TableId, [string]$RecordId)
    if (-not $script:FeishuConfig) { throw "Call Initialize-FeishuBitable first" }
    
    $appToken = $script:FeishuConfig.bitable_app_token
    $result = Invoke-FeishuApi -Method "DELETE" -ApiPath "/bitable/v1/apps/$appToken/tables/$TableId/records/$RecordId"
    
    if (-not $result.success) {
        Write-Warning "Delete record failed: $($result.msg)"
        return $false
    }
    return $true
}
