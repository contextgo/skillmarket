﻿[CmdletBinding()]
param(
    [switch]$RunOnce,
    [switch]$AsService,
    [int]$Interval = 30,
    [switch]$History,
    [string]$Device,
    [int]$Days = 7,
    [switch]$TestAlert
)

. (Join-Path $PSScriptRoot "..\lib\snmp-helper.ps1")
. (Join-Path $PSScriptRoot "..\lib\feishu-bitables.ps1")

$configPath = Join-Path $PSScriptRoot "..\config\settings.json"
$configJson = Get-Content -Path $configPath -Raw -Encoding UTF8
$config = $configJson | ConvertFrom-Json

if ($TestAlert) {
    Write-Host "Sending test alert..."

    if (-not $config.feishu.enabled) {
        Write-Host "Feishu integration disabled."
        exit 0
    }

    if (-not (Initialize-FeishuBitable -ConfigPath $configPath)) {
        Write-Host "Failed to initialize Feishu."
        exit 1
    }

    # Use PascalCase field names (must match Feishu Bitable field names exactly)
    $testRecord = @{
        DeviceName = "Test Device"
        IPAddress = "127.0.0.1"
        Status = "WARNING"
        AlertMessage = "This is a test alert from DymasEye"
        Timestamp = (Get-Date).ToString("yyyy-MM-dd HH:mm:ss")
        PingLatency = "1ms"
    }

    $result = New-FeishuRecord -TableId $config.feishu.device_table_id -Fields $testRecord

    if ($result) {
        Write-Host "SUCCESS: Test alert sent (Record ID: $($result.record_id))"
        exit 0
    } else {
        Write-Host "FAILED: Could not send test alert"
        exit 1
    }
}

if ($History) {
    Write-Host "Fetching $Days days history for $Device..."
    exit 0
}

function Check-Device {
    param($target)

    $result = [PSCustomObject]@{
        Name = $target.name
        IP = $target.ip
        Timestamp = Get-Date
        PingSuccess = $false
        PingMs = $null
        PortResults = @()
        SNMPData = $null
        SSLCheck = $null
        Status = "UNKNOWN"
        Message = ""
    }

    $ping = Test-Ping -IP $target.ip -Timeout 1000
    $result.PingSuccess = $ping.Success
    $result.PingMs = $ping.Time

    if (-not $ping.Success) {
        $result.Status = "CRITICAL"
        $result.Message = "Ping failed"
        return $result
    }

    foreach ($port in $target.ports) {
        $portResult = @{Port=$port; Open=$false; Service=""}
        try {
            $tcp = New-Object Net.Sockets.TcpClient
            $iar = $tcp.BeginConnect($target.ip, $port, $null, $null)
            $success = $iar.AsyncWaitHandle.WaitOne(1000, $false)
            if ($success) {
                $portResult.Open = $true
                switch ($port) {
                    22 { $portResult.Service = "SSH" }
                    80 { $portResult.Service = "HTTP" }
                    443 { $portResult.Service = "HTTPS" }
                }
            }
            $tcp.EndConnect($iar) | Out-Null
            $tcp.Close()
        } catch { }
        $result.PortResults += $portResult
    }

    $closed = $result.PortResults | Where-Object { -not $_.Open }
    if ($closed.Count -gt 0) {
        $result.Status = "CRITICAL"
        $result.Message = "Ports closed: $($closed.Port -join ',')"
        return $result
    }

    if (-not $target.ping_only -and $target.snmp_community) {
        try {
            $snmp = Get-SNMPData -IP $target.ip -Community $target.snmp_community -Version $target.snmp_version -Oids $target.snmp_oids
            $result.SNMPData = $snmp
        } catch { $result.SNMPData = $null }
    }

    if ($target.ssl_check -and $target.ports -contains 443) {
        try {
            $ssl = Test-SSLExpiry -Hostname $target.ip -Port 443
            $result.SSLCheck = $ssl
            if ($ssl.DaysLeft -lt $target.ssl_expiry_days_threshold) {
                if ($result.Status -ne "CRITICAL") {
                    $result.Status = "WARNING"
                    $result.Message = "SSL expiring in $($ssl.DaysLeft) days"
                }
            }
        } catch {
            $result.SSLCheck = $null
            if ($result.Status -eq "UNKNOWN") {
                $result.Status = "WARNING"
                $result.Message = "SSL check failed: $($_.Exception.Message)"
            }
        }
    }

    if ($result.Status -eq "UNKNOWN") {
        $result.Status = "OK"
        $result.Message = "All checks passed"
    }

    return $result
}

function Send-Alert {
    param($result)

    if (-not $config.feishu.enabled -or -not $config.feishu.device_table_id) {
        Write-Host "[ALERT] $($result.Name) - $($result.Status): $($result.Message)"
        return
    }

    try {
        if (-not (Initialize-FeishuBitable -ConfigPath $configPath)) {
            Write-Warning "Failed to init Feishu for alert"
            return
        }

        $fields = @{
            DeviceName = $result.Name
            IPAddress = $result.IP
            Status = $result.Status
            AlertMessage = $result.Message
            Timestamp = $result.Timestamp.ToString("yyyy-MM-dd HH:mm:ss")
            PingLatency = if ($result.PingSuccess) { "$($result.PingMs)ms" } else { "timeout" }
        }

        $record = New-FeishuRecord -TableId $config.feishu.device_table_id -Fields $fields
        if ($record) {
            Write-Host "[ALERT] Sent to Feishu: $($result.Name) - $($result.Status)"
        } else {
            Write-Warning "Failed to send alert"
        }
    } catch {
        Write-Warning "Alert exception: $_"
    }
}

function Save-History {
    param($result)

    if (-not $config.feishu.enabled -or -not $config.feishu.history_table_id) {
        Write-Host "[HISTORY] $($result.Name) status: $($result.Status)"
        return
    }

    try {
        if (-not (Initialize-FeishuBitable -ConfigPath $configPath)) {
            Write-Warning "Failed to init Feishu for history"
            return
        }

        $fields = @{
            DeviceName = $result.Name
            IPAddress = $result.IP
            Status = $result.Status
            PingLatency = if ($result.PingSuccess) { "$($result.PingMs)ms" } else { "timeout" }
            Timestamp = $result.Timestamp.ToString("yyyy-MM-dd HH:mm:ss")
        }

        $record = New-FeishuRecord -TableId $config.feishu.history_table_id -Fields $fields
        if ($record) {
            Write-Verbose "History saved"
        } else {
            Write-Warning "Failed to save history"
        }
    } catch {
        Write-Warning "History exception: $_"
    }
}

function Main-Loop {
    Write-Host "Network Monitor Started"
    Write-Host "Interval: $Interval minutes"
    Write-Host "Devices: $($config.targets.Count)"

    while ($true) {
        $startTime = Get-Date

        Write-Host "`n=== $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') Check started ==="

        foreach ($target in $config.targets) {
            Write-Host "Checking: $($target.name) ($($target.ip))"
            $result = Check-Device -target $target

            $icons = @{OK="[OK]"; WARNING="[WARN]"; CRITICAL="[CRIT]"; UNKNOWN="[?]"}
            $icon = $icons[$result.Status]
            Write-Host "$icon $($result.Name): $($result.Status) - $($result.Message)"

            if ($result.Status -in @("WARNING","CRITICAL")) {
                Send-Alert -result $result
            }

            if ($config.history.enabled -and $config.feishu.history_table_id) {
                Save-History -result $result
            }
        }

        if ($RunOnce) {
            Write-Host "`nTest completed (-RunOnce mode)"
            break
        }

        $endTime = Get-Date
        $elapsed = ($endTime - $startTime).TotalSeconds
        $sleepSeconds = [int]($Interval * 60) - [int]$elapsed

        if ($sleepSeconds -gt 0) {
            Write-Host "Sleeping $sleepSeconds seconds..."
            Start-Sleep -Seconds $sleepSeconds
        } else {
            Write-Host "Skipping sleep (overrun)"
        }
    }
}

Main-Loop
