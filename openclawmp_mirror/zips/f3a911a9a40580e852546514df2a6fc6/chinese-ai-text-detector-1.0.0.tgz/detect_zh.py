#!/usr/bin/env python3
"""检测中文 AI 写作特征"""
import json
import re
import sys
from pathlib import Path
from dataclasses import dataclass, field

SCRIPT_DIR = Path(__file__).parent
PATTERNS = json.loads((SCRIPT_DIR / "patterns_zh.json").read_text())

@dataclass
class DetectionResultZH:
    summary_talks: list = field(default_factory=list)      # 总结性套话
    transition_talks: list = field(default_factory=list)   # 过渡性套话
    fake_authority: list = field(default_factory=list)     # 虚假权威
    exaggeration: list = field(default_factory=list)       # 夸大其词
    empty_modifier: list = field(default_factory=list)     # 空洞修饰
    parallelism: list = field(default_factory=list)        # 排比金句
    chatbot_patterns: list = field(default_factory=list)   # Chatbot痕迹
    filler_zh: list = field(default_factory=list)          # 填充短语
    knowledge_cutoff: list = field(default_factory=list)   # 知识截止
    markdown_leak: list = field(default_factory=list)      # Markdown泄露
    total_issues: int = 0
    ai_probability: str = "low"
    char_count: int = 0

def find_matches(text: str, patterns: list) -> list:
    matches = []
    for p in patterns:
        count = text.count(p)
        if count > 0:
            matches.append((p, count))
    return sorted(matches, key=lambda x: -x[1])

def detect_zh(text: str) -> DetectionResultZH:
    r = DetectionResultZH()
    r.char_count = len(text)
    
    zh_chars = len(re.findall(r'[\u4e00-\u9fff]', text))
    
    r.summary_talks = find_matches(text, PATTERNS["chinese_high_signals"]["总结性套话"])
    r.transition_talks = find_matches(text, PATTERNS["chinese_high_signals"]["过渡性套话"])
    r.fake_authority = find_matches(text, PATTERNS["chinese_high_signals"]["虚假权威"])
    r.exaggeration = find_matches(text, PATTERNS["chinese_high_signals"]["夸大其词"])
    r.empty_modifier = find_matches(text, PATTERNS["chinese_high_signals"]["空洞修饰"])
    r.parallelism = find_matches(text, PATTERNS["chinese_high_signals"]["排比金句"])
    r.chatbot_patterns = find_matches(text, PATTERNS["chinese_high_signals"]["chatbot_patterns"])
    r.filler_zh = find_matches(text, PATTERNS["chinese_high_signals"]["ai_filler_zh"])
    r.knowledge_cutoff = find_matches(text, PATTERNS["chinese_high_signals"]["knowledge_cutoff_zh"])
    r.markdown_leak = find_matches(text, PATTERNS["chinese_high_signals"]["markdown_leak_zh"])
    
    r.total_issues = (
        sum(c for _, c in r.summary_talks) * 2 +
        sum(c for _, c in r.transition_talks) +
        sum(c for _, c in r.fake_authority) * 2 +
        sum(c for _, c in r.exaggeration) +
        sum(c for _, c in r.empty_modifier) +
        sum(c for _, c in r.parallelism) * 3 +
        sum(c for _, c in r.chatbot_patterns) * 3 +
        sum(c for _, c in r.filler_zh) +
        sum(c for _, c in r.knowledge_cutoff) * 3 +
        sum(c for _, c in r.markdown_leak) * 2
    )
    
    density = r.total_issues / max(zh_chars, 1) * 100
    if r.chatbot_patterns or r.knowledge_cutoff:
        r.ai_probability = "very high"
    elif density > 5 or r.total_issues > 20:
        r.ai_probability = "high"
    elif density > 2 or r.total_issues > 10:
        r.ai_probability = "medium"
    return r

def print_report(r: DetectionResultZH):
    icons = {"very high": "🔴", "high": "🟠", "medium": "🟡", "low": "🟢"}
    print(f"\n{'='*60}")
    print(f"中文 AI 文本检测 - {r.total_issues} 个问题 ({r.char_count} 字)")
    print(f"AI 概率: {icons.get(r.ai_probability, '')} {r.ai_probability.upper()}")
    print(f"{'='*60}\n")
    
    def print_section(title: str, items: list, weight: str = ""):
        if not items:
            return
        print(f"【{title}】{weight}")
        for phrase, count in items:
            replacements = PATTERNS.get("chinese_replacements", {})
            if phrase in replacements:
                print(f"  • \"{phrase}\" → \"{replacements[phrase]}\": {count}次")
            else:
                print(f"  • \"{phrase}\": {count}次")
        print()
    
    print_section("⚠️ Chatbot痕迹（高权重）", r.chatbot_patterns, "×3")
    print_section("⚠️ 知识截止痕迹（高权重）", r.knowledge_cutoff, "×3")
    print_section("排比金句（高权重）", r.parallelism, "×3")
    print_section("总结性套话（中权重）", r.summary_talks, "×2")
    print_section("虚假权威（中权重）", r.fake_authority, "×2")
    print_section("过渡性套话", r.transition_talks)
    print_section("夸大其词", r.exaggeration)
    print_section("空洞修饰", r.empty_modifier)
    print_section("填充短语", r.filler_zh)
    print_section("Markdown泄露", r.markdown_leak)
    
    if r.total_issues == 0:
        print("✓ 未检测到明显的 AI 模式。\n")

def main():
    import argparse
    parser = argparse.ArgumentParser(description="检测中文 AI 写作特征")
    parser.add_argument("input", nargs="?", help="输入文件（或从stdin读取）")
    parser.add_argument("--json", "-j", action="store_true", help="JSON 输出")
    args = parser.parse_args()
    
    text = Path(args.input).read_text(encoding="utf-8") if args.input else sys.stdin.read()
    result = detect_zh(text)
    
    if args.json:
        print(json.dumps({
            "total_issues": result.total_issues,
            "char_count": result.char_count,
            "ai_probability": result.ai_probability,
        }, indent=2, ensure_ascii=False))
    else:
        print_report(result)

if __name__ == "__main__":
    main()
