---
name: chinese-ai-text-detector
description: "中文 AI 文本检测与改写工具。检测9类中文AI写作特征（套话、虚假权威、夸大其词、chatbot痕迹等），给出替换建议和AI概率评分。支持自动改写。触发：'检测AI'、'去AI痕迹'、'文本优化'、'文本改写'"
version: "1.1.0"
---

# 中文 AI 文本检测与改写工具

检测中文文本中的 AI 写作特征，并自动改写为更自然的表达。

## 快速使用

### 检测模式
```bash
# 检测文本文件
python3 {baseDir}/scripts/detect_zh.py input.txt

# 从 stdin 输入
echo "你的文本" | python3 {baseDir}/scripts/detect_zh.py

# JSON 输出
python3 {baseDir}/scripts/detect_zh.py --json input.txt
```

### 改写模式
```bash
# 直接改写并输出
python3 {baseDir}/scripts/transform_zh.py input.txt

# 显示原文和改写的差异对比
python3 {baseDir}/scripts/transform_zh.py --diff input.txt

# 保存到文件
python3 {baseDir}/scripts/transform_zh.py input.txt -o output.txt
```

## 检测类型（9类）

| 类型 | 示例 | 权重 |
|------|------|------|
| 总结性套话 | 值得注意的是、综上所述 | ×2 |
| 虚假权威 | 研究表明、专家指出 | ×2 |
| 过渡性套话 | 在这个背景下、从某种意义上说 | ×1 |
| 夸大其词 | 极大地、显著地 | ×1 |
| 空洞修饰 | 全方位、多层次 | ×1 |
| 排比金句 | 不仅...而且...还 | ×3 |
| Chatbot痕迹 | 希望这对你有帮助 | ×3 |
| 填充短语 | 在某种程度上、客观来说 | ×1 |
| 知识截止痕迹 | 根据我的知识 | ×3 |

## 替换建议（自动改写时应用）

- "值得注意的是" → "说白了"
- "综上所述" → "所以"
- "不可否认" → "确实"
- "极大地" → "大幅"
- "研究表明" → 直接删除或给出具体来源
- Chatbot痕迹 → 直接删除

## 工作原理

基于维基百科"AI写作迹象"指南，针对中文特有的9种AI写作模式进行检测。每个模式有不同权重，最终计算AI概率（low/medium/high/very high）。
