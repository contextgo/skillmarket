#!/usr/bin/env python3
"""中文 AI 文本改写工具 - 修复检测到的问题"""
import json
import re
import sys
from pathlib import Path

SCRIPT_DIR = Path(__file__).parent
PATTERNS = json.loads((SCRIPT_DIR / "patterns_zh.json").read_text())

def transform_zh(text: str) -> str:
    """将中文 AI 文本改写为更自然的表达"""
    result = text
    
    # 1. 替换总结性套话
    replacements = PATTERNS.get("chinese_replacements", {})
    for old, new in replacements.items():
        result = result.replace(old, new)
    
    # 2. 删除 chatbot 痕迹（整句删除）
    chatbot_patterns = PATTERNS["chinese_high_signals"]["chatbot_patterns"]
    for pattern in chatbot_patterns:
        result = re.sub(re.escape(pattern) + r'[。！？]?\s*', '', result)
    
    # 3. 删除知识截止痕迹
    cutoff_patterns = PATTERNS["chinese_high_signals"]["knowledge_cutoff_zh"]
    for pattern in cutoff_patterns:
        result = re.sub(re.escape(pattern) + r'[^\n]*\n?', '', result)
    
    # 4. 清理多余空行
    result = re.sub(r'\n{3,}', '\n\n', result)
    
    # 5. 清理首尾空格
    result = result.strip()
    
    return result

def main():
    import argparse
    parser = argparse.ArgumentParser(description="改写中文 AI 文本")
    parser.add_argument("input", nargs="?", help="输入文件（或从stdin读取）")
    parser.add_argument("-o", "--output", help="输出文件")
    parser.add_argument("--diff", action="store_true", help="显示差异")
    args = parser.parse_args()
    
    text = Path(args.input).read_text(encoding="utf-8") if args.input else sys.stdin.read()
    transformed = transform_zh(text)
    
    if args.diff:
        print("=== 原文 ===")
        print(text)
        print("\n=== 改写后 ===")
        print(transformed)
    elif args.output:
        Path(args.output).write_text(transformed, encoding="utf-8")
        print(f"已保存到: {args.output}")
    else:
        print(transformed)

if __name__ == "__main__":
    main()
