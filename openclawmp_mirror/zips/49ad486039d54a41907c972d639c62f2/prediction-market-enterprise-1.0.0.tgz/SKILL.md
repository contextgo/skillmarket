---
name: prediction-market-enterprise
description: 预测市场与区块链数据分析 — 查询分析 Polymarket、Metaculus 等预测市场数据，进行概率分析、期望值计算、市场趋势追踪与风险评估
---

# 预测市场与区块链数据分析平台

## 概述

本技能提供预测市场与区块链数据的全方位分析能力。支持 Polymarket、Metaculus 等主流预测市场的数据查询与分析，涵盖概率分析、期望值计算、市场趋势追踪、投资组合模拟、链上数据分析等功能，为决策者提供数据驱动的洞察。

---

## 核心能力

### 1. 预测市场数据查询

#### 1.1 Polymarket API 数据获取

Polymarket 是全球最大的去中心化预测市场平台。以下是通过公开 API 获取数据的方法：

```python
import json
import urllib.request
import urllib.parse
from datetime import datetime

class PolymarketAPI:
    """Polymarket 公开数据 API 客户端"""
    
    BASE_URL = "https://gamma-api.polymarket.com"
    CLOB_API = "https://clob.polymarket.com"
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (compatible; AnalysisBot/1.0)',
            'Accept': 'application/json',
        }
    
    def _request(self, url, params=None):
        """通用请求方法"""
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers=self.headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            print(f"请求失败: {e}")
            return None
    
    def get_markets(self, limit=20, offset=0, active=True, closed=False):
        """获取市场列表
        
        参数:
            limit: 返回数量
            offset: 偏移量
            active: 是否仅活跃市场
            closed: 是否包含已关闭市场
        """
        params = {
            'limit': limit,
            'offset': offset,
            'closed': str(closed).lower(),
            'active': str(active).lower(),
        }
        
        data = self._request(f"{self.BASE_URL}/markets", params)
        
        if not data:
            return []
        
        markets = []
        for m in data:
            markets.append({
                'id': m.get('id'),
                'question': m.get('question'),
                'description': m.get('description', '')[:200],
                'outcomes': m.get('outcomes', []),
                'outcomePrices': m.get('outcomePrices', []),
                'volume': float(m.get('volume', 0)),
                'liquidity': float(m.get('liquidity', 0)),
                'startDate': m.get('startDate'),
                'endDate': m.get('endDate'),
                'image': m.get('image'),
                'category': m.get('category'),
                'slug': m.get('slug'),
            })
        
        return markets
    
    def get_market_by_slug(self, slug):
        """通过 slug 获取市场详情"""
        return self._request(f"{self.BASE_URL}/markets/{slug}")
    
    def get_market_events(self, slug):
        """获取市场事件历史"""
        return self._request(f"{self.BASE_URL}/events/{slug}/markets")
    
    def get_orderbook(self, token_id):
        """获取市场订单簿"""
        return self._request(f"{self.CLOB_API}/book", {'token_id': token_id})
    
    def search_markets(self, query, limit=10):
        """搜索市场"""
        params = {'query': query, 'limit': limit}
        return self._request(f"{self.BASE_URL}/markets", params)


# 使用示例
api = PolymarketAPI()

# 获取热门市场
markets = api.get_markets(limit=10)
for m in markets:
    print(f"📋 {m['question']}")
    print(f"   概率: {m['outcomePrices']}")
    print(f"   成交量: ${m['volume']:,.0f}")
    print(f"   流动性: ${m['liquidity']:,.0f}")
    print()

# 搜索特定市场
results = api.search_markets("2024 election")
```

#### 1.2 Metaculus API 数据获取

```python
class MetaculusAPI:
    """Metaculus 预测平台 API 客户端"""
    
    BASE_URL = "https://www.metaculus.com/api2"
    
    def __init__(self):
        self.headers = {
            'User-Agent': 'Mozilla/5.0 (compatible; AnalysisBot/1.0)',
            'Accept': 'application/json',
        }
    
    def _request(self, endpoint, params=None):
        """通用请求方法"""
        url = f"{self.BASE_URL}{endpoint}"
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers=self.headers)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            print(f"请求失败: {e}")
            return None
    
    def get_questions(self, status='open', order_by='-activity', limit=20):
        """获取预测问题列表
        
        参数:
            status: 'open' | 'closed' | 'resolved'
            order_by: 排序字段
            limit: 返回数量
        """
        params = {
            'status': status,
            'order_by': order_by,
            'limit': limit,
        }
        return self._request("/questions/", params)
    
    def get_question(self, question_id):
        """获取问题详情"""
        return self._request(f"/questions/{question_id}/")
    
    def get_community_predictions(self, question_id):
        """获取社区预测数据"""
        return self._request(f"/questions/{question_id}/community-prediction/")


# 使用示例
metaculus = MetaculusAPI()

# 获取活跃问题
questions = metaculus.get_questions(limit=10)
if questions and 'results' in questions:
    for q in questions['results']:
        title = q.get('title', 'N/A')
        community_pred = q.get('community_prediction', {})
        print(f"❓ {title}")
        if isinstance(community_pred, dict):
            for label, value in community_pred.items():
                print(f"   {label}: {value:.1%}")
        print()
```

---

### 2. 概率分析与期望值计算

#### 2.1 概率分析引擎

```python
import math
from dataclasses import dataclass
from typing import List, Optional

@dataclass
class MarketOutcome:
    """市场结果"""
    name: str
    probability: float  # 0.0 - 1.0
    true_probability: Optional[float] = None  # 你估计的真实概率

@dataclass
class ExpectedValueResult:
    """期望值分析结果"""
    outcome_name: str
    market_probability: float
    estimated_probability: float
    edge: float  # 你的优势
    kelly_fraction: float  # 凯利公式建议的下注比例
    expected_return: float  # 期望收益率
    recommendation: str  # 操作建议

class ProbabilityAnalyzer:
    """概率分析与期望值计算引擎"""
    
    @staticmethod
    def calculate_edge(market_prob, estimated_prob):
        """计算边际优势
        
        参数:
            market_prob: 市场定价概率
            estimated_prob: 你估计的真实概率
        返回:
            edge: 正值表示你有优势
        """
        return estimated_prob - market_prob
    
    @staticmethod
    def calculate_expected_value(market_prob, estimated_prob, stake=1.0):
        """计算期望值
        
        参数:
            market_prob: 市场赔率（需要支付的价格）
            estimated_prob: 你估计的真实概率
            stake: 投入金额
        返回:
            期望收益（正值为正期望）
        """
        # 如果事件发生：赢得 (1/market_prob - 1) * stake
        # 如果事件未发生：损失 stake
        win_amount = (1.0 / market_prob - 1.0) * stake
        ev = estimated_prob * win_amount - (1 - estimated_prob) * stake
        return ev
    
    @staticmethod
    def kelly_criterion(market_prob, estimated_prob):
        """凯利公式计算最优下注比例
        
        凯利公式: f* = (bp - q) / b
        其中 b = 赔率 - 1, p = 赢的概率, q = 输的概率
        
        参数:
            market_prob: 市场概率（买入价格）
            estimated_prob: 你估计的获胜概率
        返回:
            建议下注比例（0-1），负值表示不建议下注
        """
        b = (1.0 / market_prob) - 1.0  # 净赔率
        p = estimated_prob
        q = 1.0 - estimated_prob
        
        kelly = (b * p - q) / b
        return kelly
    
    @staticmethod
    def analyze_binary_market(question, market_prob, your_prob, bankroll=10000):
        """分析二元市场
        
        参数:
            question: 市场问题
            market_prob: 市场价格 (0-1)
            your_prob: 你估计的概率 (0-1)
            bankroll: 总资金
        """
        edge = ProbabilityAnalyzer.calculate_edge(market_prob, your_prob)
        ev = ProbabilityAnalyzer.calculate_expected_value(market_prob, your_prob, stake=1.0)
        kelly = ProbabilityAnalyzer.kelly_criterion(market_prob, your_prob)
        
        # 半凯利（更保守的策略）
        half_kelly = kelly / 2
        suggested_stake = half_kelly * bankroll
        
        # 操作建议
        if edge < 0.01:
            recommendation = "⏸️ 边际优势不足，不建议交易"
        elif edge < 0.05:
            recommendation = f"🟡 小幅优势，建议小额投入 ${suggested_stake:.0f}"
        elif edge < 0.15:
            recommendation = f"🟢 中等优势，建议投入 ${suggested_stake:.0f}"
        else:
            recommendation = f"🟢 显著优势，建议投入 ${suggested_stake:.0f}"
        
        return ExpectedValueResult(
            outcome_name=question,
            market_probability=market_prob,
            estimated_probability=your_prob,
            edge=edge,
            kelly_fraction=kelly,
            expected_return=ev,
            recommendation=recommendation,
        )
    
    @staticmethod
    def analyze_multi_outcome_market(question, outcomes: List[MarketOutcome], bankroll=10000):
        """分析多元结果市场
        
        参数:
            question: 市场问题
            outcomes: 结果列表
            bankroll: 总资金
        """
        results = []
        
        for outcome in outcomes:
            if outcome.true_probability is None:
                continue
            
            market_p = outcome.probability
            est_p = outcome.true_probability
            
            edge = est_p - market_p
            ev = ProbabilityAnalyzer.calculate_expected_value(market_p, est_p)
            kelly = ProbabilityAnalyzer.kelly_criterion(market_p, est_p)
            
            results.append({
                'outcome': outcome.name,
                'market_prob': market_p,
                'your_prob': est_p,
                'edge': edge,
                'kelly': kelly,
                'ev': ev,
            })
        
        # 找出最佳下注
        if results:
            best = max(results, key=lambda x: x['edge'])
            if best['edge'] > 0.01:
                suggestion = f"💡 最佳下注: {best['outcome']} (优势 {best['edge']:.1%}, 凯利 {best['kelly']:.1%})"
            else:
                suggestion = "⏸️ 所有结果均无显著优势，不建议交易"
        else:
            suggestion = "ℹ️ 需要提供你估计的概率才能分析"
        
        return results, suggestion


# === 使用示例 ===
analyzer = ProbabilityAnalyzer()

# 二元市场分析
result = analyzer.analyze_binary_market(
    question="BTC 在 2025 年底突破 $150K",
    market_prob=0.35,  # 市场定价 35%
    your_prob=0.45,    # 你认为 45%
    bankroll=10000
)
print(f"市场问题: {result.outcome_name}")
print(f"市场概率: {result.market_probability:.1%}")
print(f"你的估计: {result.estimated_probability:.1%}")
print(f"边际优势: {result.edge:.1%}")
print(f"凯利比例: {result.kelly_fraction:.1%}")
print(f"期望收益: ${result.expected_return:.2f} / $1 投入")
print(f"建议: {result.recommendation}")
```

#### 2.2 贝叶斯概率更新

```python
class BayesianUpdater:
    """贝叶斯概率更新器 — 基于新证据更新预测"""
    
    @staticmethod
    def update(prior, likelihood_positive, likelihood_negative, evidence_positive=True):
        """贝叶斯定理更新概率
        
        参数:
            prior: 先验概率 P(H)
            likelihood_positive: 阳性似然 P(E|H)
            likelihood_negative: 阴性似然 P(E|~H)
            evidence_positive: 是否观察到阳性证据
        返回:
            后验概率 P(H|E)
        """
        if evidence_positive:
            numerator = prior * likelihood_positive
            denominator = numerator + (1 - prior) * (1 - likelihood_negative)
        else:
            numerator = prior * (1 - likelihood_positive)
            denominator = numerator + (1 - prior) * likelihood_negative
        
        return numerator / denominator
    
    @staticmethod
    def sequential_update(prior, evidence_list):
        """顺序更新多个证据
        
        参数:
            prior: 初始先验概率
            evidence_list: 证据列表，每项为 (likelihood_positive, likelihood_negative, observed)
        """
        current_prob = prior
        
        for i, (lp, ln, observed) in enumerate(evidence_list, 1):
            new_prob = BayesianUpdater.update(current_prob, lp, ln, observed)
            change = new_prob - current_prob
            direction = "↑" if change > 0 else "↓"
            print(f"  证据 {i}: {current_prob:.1%} → {new_prob:.1%} ({direction}{abs(change):.1%})")
            current_prob = new_prob
        
        return current_prob


# 使用示例
updater = BayesianUpdater()

# 示例：BTC 价格预测的贝叶斯更新
print("📊 BTC 在 2025 年底突破 $150K 的概率更新")
print("─" * 50)

prior = 0.35  # 先验概率（市场定价）

# 新证据及其似然度
evidence = [
    # (P(证据|事件发生), P(证据|事件未发生), 是否观察到)
    (0.7, 0.3, True),   # ETF 持续净流入
    (0.8, 0.2, True),   # 减半效应开始显现
    (0.4, 0.5, False),  # 宏观经济不确定性
    (0.6, 0.3, True),   # 机构持仓增加
    (0.5, 0.4, True),   # 技术面突破关键阻力位
]

posterior = updater.sequential_update(prior, evidence)
print(f"\n最终后验概率: {posterior:.1%} (先验: {prior:.1%})")
print(f"市场定价: {prior:.1%}, 你的估计: {posterior:.1%}")
print(f"边际优势: {(posterior - prior) * 100:.1f}%")
```

---

### 3. 市场趋势追踪与历史分析

#### 3.1 市场趋势分析

```python
from collections import defaultdict
from datetime import datetime, timedelta

class MarketTrendAnalyzer:
    """市场趋势追踪与分析"""
    
    def __init__(self):
        self.price_history = defaultdict(list)
        self.volume_history = defaultdict(list)
    
    def record_price(self, market_id, price, volume, timestamp=None):
        """记录市场价格快照"""
        timestamp = timestamp or datetime.now().isoformat()
        self.price_history[market_id].append({
            'timestamp': timestamp,
            'price': price,
            'volume': volume,
        })
    
    def calculate_volatility(self, market_id, window=7):
        """计算价格波动率
        
        参数:
            market_id: 市场 ID
            window: 时间窗口（天）
        返回:
            历史波动率
        """
        history = self.price_history[market_id]
        if len(history) < 2:
            return 0.0
        
        prices = [h['price'] for h in history]
        returns = []
        for i in range(1, len(prices)):
            if prices[i-1] > 0:
                returns.append((prices[i] - prices[i-1]) / prices[i-1])
        
        if not returns:
            return 0.0
        
        mean = sum(returns) / len(returns)
        variance = sum((r - mean) ** 2 for r in returns) / len(returns)
        return math.sqrt(variance)
    
    def calculate_sharpe_ratio(self, market_id, risk_free_rate=0.05):
        """计算夏普比率
        
        参数:
            market_id: 市场 ID
            risk_free_rate: 无风险利率（年化）
        返回:
            夏普比率
        """
        history = self.price_history[market_id]
        if len(history) < 2:
            return 0.0
        
        prices = [h['price'] for h in history]
        returns = []
        for i in range(1, len(prices)):
            if prices[i-1] > 0:
                returns.append((prices[i] - prices[i-1]) / prices[i-1])
        
        if not returns:
            return 0.0
        
        mean_return = sum(returns) / len(returns)
        std_return = math.sqrt(sum((r - mean_return) ** 2 for r in returns) / len(returns))
        
        if std_return == 0:
            return 0.0
        
        # 年化处理（假设每日数据）
        annualized_return = mean_return * 365
        annualized_vol = std_return * math.sqrt(365)
        
        return (annualized_return - risk_free_rate) / annualized_vol
    
    def detect_trend(self, market_id, short_window=3, long_window=7):
        """趋势检测（简单移动平均线交叉）
        
        返回:
            'bullish' | 'bearish' | 'neutral'
        """
        history = self.price_history[market_id]
        if len(history) < long_window:
            return 'neutral'
        
        prices = [h['price'] for h in history]
        
        short_ma = sum(prices[-short_window:]) / short_window
        long_ma = sum(prices[-long_window:]) / long_window
        
        diff = short_ma - long_ma
        if diff > 0.02:
            return 'bullish'
        elif diff < -0.02:
            return 'bearish'
        else:
            return 'neutral'
    
    def generate_summary(self, market_id):
        """生成市场摘要"""
        history = self.price_history[market_id]
        if not history:
            return None
        
        prices = [h['price'] for h in history]
        volumes = [h['volume'] for h in history]
        
        return {
            'current_price': prices[-1],
            'price_change': prices[-1] - prices[0] if len(prices) > 1 else 0,
            'price_change_pct': ((prices[-1] - prices[0]) / prices[0] * 100) if prices[0] > 0 else 0,
            'max_price': max(prices),
            'min_price': min(prices),
            'avg_price': sum(prices) / len(prices),
            'total_volume': sum(volumes),
            'volatility': self.calculate_volatility(market_id),
            'trend': self.detect_trend(market_id),
            'sharpe_ratio': self.calculate_sharpe_ratio(market_id),
            'data_points': len(prices),
        }
```

---

### 4. 投资组合模拟与风险管理

#### 4.1 投资组合模拟

```python
import random

@dataclass
class Position:
    """持仓"""
    market_id: str
    question: str
    outcome: str
    buy_price: float  # 买入价格
    quantity: float    # 数量（YES shares）
    cost: float        # 投入成本
    current_price: Optional[float] = None
    pnl: Optional[float] = None

class PortfolioSimulator:
    """投资组合模拟器"""
    
    def __init__(self, initial_capital=10000):
        self.capital = initial_capital
        self.initial_capital = initial_capital
        self.positions: List[Position] = []
        self.realized_pnl = 0
    
    def buy(self, market_id, question, outcome, price, allocation_pct):
        """买入持仓
        
        参数:
            market_id: 市场 ID
            question: 市场问题
            outcome: 买入的结果
            price: 当前价格
            allocation_pct: 分配资金比例 (0-1)
        """
        cost = self.capital * allocation_pct
        if cost > self.capital:
            cost = self.capital
        
        quantity = cost / price
        
        position = Position(
            market_id=market_id,
            question=question,
            outcome=outcome,
            buy_price=price,
            quantity=quantity,
            cost=cost,
        )
        
        self.positions.append(position)
        self.capital -= cost
        
        return position
    
    def update_prices(self, price_updates):
        """更新持仓价格
        
        参数:
            price_updates: {market_id: current_price}
        """
        for pos in self.positions:
            if pos.market_id in price_updates:
                pos.current_price = price_updates[pos.market_id]
                pos.pnl = (pos.current_price - pos.buy_price) * pos.quantity
        
    def simulate_resolution(self, market_id, winning_outcome, payout=1.0):
        """模拟市场结算
        
        参数:
            market_id: 市场 ID
            winning_outcome: 获胜结果
            payout: 每股派息
        """
        for pos in self.positions:
            if pos.market_id != market_id:
                continue
            
            if pos.outcome == winning_outcome:
                # 赢了
                winnings = pos.quantity * payout
                self.realized_pnl += winnings - pos.cost
                self.capital += winnings
            else:
                # 输了
                self.realized_pnl -= pos.cost
        
        # 移除已结算的持仓
        self.positions = [p for p in self.positions if p.market_id != market_id]
    
    def get_portfolio_summary(self):
        """获取投资组合摘要"""
        total_unrealized = sum(p.pnl or 0 for p in self.positions)
        total_invested = sum(p.cost for p in self.positions)
        total_value = self.capital + total_invested + total_unrealized
        
        return {
            'initial_capital': self.initial_capital,
            'available_capital': self.capital,
            'invested': total_invested,
            'unrealized_pnl': total_unrealized,
            'realized_pnl': self.realized_pnl,
            'total_pnl': total_unrealized + self.realized_pnl,
            'total_value': total_value,
            'total_return': (total_value - self.initial_capital) / self.initial_capital * 100,
            'num_positions': len(self.positions),
            'positions': self.positions,
        }
    
    def monte_carlo_simulation(self, market_id, current_price, volatility,
                                num_simulations=10000, time_steps=30):
        """蒙特卡洛模拟价格路径
        
        参数:
            market_id: 市场 ID
            current_price: 当前价格
            volatility: 日波动率
            num_simulations: 模拟次数
            time_steps: 时间步数（天）
        """
        final_prices = []
        
        for _ in range(num_simulations):
            price = current_price
            for _ in range(time_steps):
                # 几何布朗运动
                drift = 0  # 假设无漂移（预测市场概率围绕均值波动）
                shock = random.gauss(0, 1)
                price = price * math.exp(
                    (drift - 0.5 * volatility ** 2) + volatility * shock
                )
                # 预测市场价格限制在 [0, 1]
                price = max(0.01, min(0.99, price))
            
            final_prices.append(price)
        
        final_prices.sort()
        
        return {
            'mean': sum(final_prices) / len(final_prices),
            'median': final_prices[len(final_prices) // 2],
            'std': math.sqrt(sum((p - sum(final_prices)/len(final_prices))**2 
                                  for p in final_prices) / len(final_prices)),
            'percentile_5': final_prices[int(len(final_prices) * 0.05)],
            'percentile_95': final_prices[int(len(final_prices) * 0.95)],
            'prob_below_0_5': sum(1 for p in final_prices if p < 0.5) / len(final_prices),
            'prob_above_0_5': sum(1 for p in final_prices if p >= 0.5) / len(final_prices),
            'simulations': num_simulations,
        }
```

---

### 5. 链上数据分析

#### 5.1 公开区块链 API 查询

```python
class OnChainAnalyzer:
    """链上数据分析器"""
    
    # 公开 API 端点（无需 API Key）
    ETHERSCAN_API = "https://api.etherscan.io/api"
    DUNE_API = "https://api.dune.com/api/v1"
    
    def get_eth_price(self):
        """获取 ETH 当前价格"""
        url = "https://api.coingecko.com/api/v3/simple/price"
        params = {'ids': 'ethereum', 'vs_currencies': 'usd'}
        data = self._public_request(url, params)
        if data and 'ethereum' in data:
            return data['ethereum']['usd']
        return None
    
    def get_token_info(self, token_symbol):
        """获取代币信息"""
        url = "https://api.coingecko.com/api/v3/coins/markets"
        params = {
            'vs_currency': 'usd',
            'ids': self._symbol_to_id(token_symbol),
            'order': 'market_cap_desc',
            'sparkline': 'false',
        }
        data = self._public_request(url, params)
        return data
    
    def get_defi_tvl(self):
        """获取 DeFi TVL（总锁仓量）"""
        url = "https://api.llama.fi/v2/chains"
        data = self._public_request(url)
        return data
    
    def get_gas_price(self):
        """获取当前 Gas 价格"""
        url = f"{self.ETHERSCAN_API}"
        params = {
            'module': 'gastracker',
            'action': 'gasoracle',
            'apikey': 'YourApiKeyToken'  # 使用免费 API key
        }
        data = self._public_request(url, params)
        return data
    
    def _public_request(self, url, params=None):
        """公开请求（无认证）"""
        if params:
            url = f"{url}?{urllib.parse.urlencode(params)}"
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (compatible; AnalysisBot/1.0)',
            'Accept': 'application/json',
        })
        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                return json.loads(resp.read().decode('utf-8'))
        except Exception as e:
            return None
    
    @staticmethod
    def _symbol_to_id(symbol):
        """代币符号转 CoinGecko ID"""
        mapping = {
            'BTC': 'bitcoin', 'ETH': 'ethereum', 'SOL': 'solana',
            'MATIC': 'matic-network', 'AVAX': 'avalanche-2',
            'DOT': 'polkadot', 'LINK': 'chainlink', 'UNI': 'uniswap',
            'AAVE': 'aave', 'MKR': 'maker',
        }
        return mapping.get(symbol.upper(), symbol.lower())


# 使用示例
onchain = OnChainAnalyzer()

# 获取 ETH 价格
eth_price = onchain.get_eth_price()
print(f"ETH 价格: ${eth_price}")

# 获取 DeFi TVL
tvl_data = onchain.get_defi_tvl()
if tvl_data:
    print("\n🔝 DeFi 链上 TVL 排名:")
    for chain in sorted(tvl_data, key=lambda x: x.get('totalLockups', 0), reverse=True)[:10]:
        name = chain.get('name', 'N/A')
        tvl = chain.get('totalLockups', 0)
        print(f"  {name}: ${tvl:,.0f}")
```

---

### 6. 情感分析

```python
class MarketSentimentAnalyzer:
    """市场情感分析器"""
    
    # 关键词情感词典（简化版）
    BULLISH_KEYWORDS = [
        'bullish', 'breakout', 'rally', 'surge', 'moon', 'pump',
        'adoption', 'institutional', 'upgrade', 'halving', 'demand',
        'growth', 'record', ' ATH ', 'all-time high', 'uptrend',
        'buy', 'accumulate', 'long', '看涨', '突破', '上涨', '创新高'
    ]
    
    BEARISH_KEYWORDS = [
        'bearish', 'crash', 'dump', 'correction', 'recession',
        'ban', 'regulation', 'hack', 'exploit', 'sell-off',
        'decline', 'drop', 'fall', 'downgrade', 'downtrend',
        'sell', 'short', 'bear', '看跌', '暴跌', '下跌', '崩盘'
    ]
    
    @classmethod
    def analyze_text(cls, text):
        """分析文本情感
        
        返回:
            sentiment_score: -1.0 到 1.0
            category: 'bullish' | 'bearish' | 'neutral'
        """
        text_lower = text.lower()
        
        bullish_score = sum(1 for kw in cls.BULLISH_KEYWORDS if kw.lower() in text_lower)
        bearish_score = sum(1 for kw in cls.BEARISH_KEYWORDS if kw.lower() in text_lower)
        
        total = bullish_score + bearish_score
        if total == 0:
            return 0.0, 'neutral'
        
        sentiment = (bullish_score - bearish_score) / total
        
        if sentiment > 0.2:
            category = 'bullish'
        elif sentiment < -0.2:
            category = 'bearish'
        else:
            category = 'neutral'
        
        return sentiment, category
    
    @classmethod
    def analyze_multiple_sources(cls, texts):
        """分析多个来源的综合情感"""
        scores = []
        for text in texts:
            score, _ = cls.analyze_text(text)
            scores.append(score)
        
        if not scores:
            return 0.0, 'neutral', 0
        
        avg_score = sum(scores) / len(scores)
        
        if avg_score > 0.2:
            category = 'bullish'
        elif avg_score < -0.2:
            category = 'bearish'
        else:
            category = 'neutral'
        
        confidence = sum(abs(s) for s in scores) / len(scores)
        
        return avg_score, category, confidence
```

---

### 7. 风险评估框架

```python
class RiskAssessmentFramework:
    """风险评估框架"""
    
    RISK_FACTORS = {
        'market_risk': {
            'description': '市场价格波动风险',
            'weight': 0.3,
            'indicators': ['volatility', 'liquidity', 'market_trend'],
        },
        'information_risk': {
            'description': '信息不对称风险',
            'weight': 0.25,
            'indicators': ['source_reliability', 'data_freshness', 'consensus_level'],
        },
        'execution_risk': {
            'description': '交易执行风险',
            'weight': 0.15,
            'indicators': ['slippage', 'liquidity_depth', 'fee_impact'],
        },
        'counterparty_risk': {
            'description': '对手方风险',
            'weight': 0.15,
            'indicators': ['platform_reputation', 'smart_contract_risk', 'settlement_risk'],
        },
        'regulatory_risk': {
            'description': '监管合规风险',
            'weight': 0.15,
            'indicators': ['jurisdiction', 'legal_status', 'compliance_history'],
        },
    }
    
    @classmethod
    def assess_market_risk(cls, market_data):
        """评估单个市场的综合风险
        
        参数:
            market_data: 包含 volatility, liquidity, volume 等指标的字典
        返回:
            risk_score: 0-100 (越高越危险)
            risk_level: 'LOW' | 'MEDIUM' | 'HIGH' | 'EXTREME'
        """
        risk_score = 0
        
        # 波动率风险
        volatility = market_data.get('volatility', 0)
        if volatility > 0.3:
            risk_score += 25
        elif volatility > 0.15:
            risk_score += 15
        else:
            risk_score += 5
        
        # 流动性风险
        liquidity = market_data.get('liquidity', 0)
        if liquidity < 1000:
            risk_score += 25
        elif liquidity < 10000:
            risk_score += 15
        else:
            risk_score += 5
        
        # 市场成熟度
        volume = market_data.get('volume', 0)
        if volume < 5000:
            risk_score += 20
        elif volume < 50000:
            risk_score += 10
        else:
            risk_score += 3
        
        # 时间风险（距离结算时间越近不确定性越低）
        days_to_end = market_data.get('days_to_end', 30)
        if days_to_end > 180:
            risk_score += 15
        elif days_to_end > 90:
            risk_score += 10
        else:
            risk_score += 5
        
        # 结果数量风险
        outcomes = market_data.get('num_outcomes', 2)
        if outcomes > 5:
            risk_score += 15
        elif outcomes > 2:
            risk_score += 8
        else:
            risk_score += 3
        
        # 归一化到 0-100
        risk_score = min(100, risk_score)
        
        if risk_score < 25:
            level = 'LOW'
        elif risk_score < 50:
            level = 'MEDIUM'
        elif risk_score < 75:
            level = 'HIGH'
        else:
            level = 'EXTREME'
        
        return risk_score, level
    
    @classmethod
    def get_position_sizing(cls, risk_score, bankroll, max_risk_pct=0.05):
        """基于风险评分计算建议仓位大小
        
        参数:
            risk_score: 风险评分 (0-100)
            bankroll: 总资金
            max_risk_pct: 最大风险敞口比例
        """
        if risk_score >= 75:
            # 高风险：最多投入 1% 资金
            allocation = 0.01
            recommendation = "⚠️ 极高风险，仅建议极小额投入或观望"
        elif risk_score >= 50:
            # 中高风险：最多投入 2.5%
            allocation = 0.025
            recommendation = "🟡 中高风险，建议小额试探性投入"
        elif risk_score >= 25:
            # 中等风险：最多投入 5%
            allocation = 0.05
            recommendation = "🟢 中等风险，可适度投入"
        else:
            # 低风险：最多投入 10%
            allocation = 0.10
            recommendation = "✅ 低风险，可考虑较大投入"
        
        allocation = min(allocation, max_risk_pct)
        suggested_amount = bankroll * allocation
        
        return {
            'risk_score': risk_score,
            'suggested_allocation': allocation,
            'suggested_amount': suggested_amount,
            'recommendation': recommendation,
        }
```

---

### 8. 市场比较仪表板

```python
def generate_market_comparison_report(markets_data):
    """生成市场比较报告
    
    参数:
        markets_data: 市场数据列表，每个元素包含 name, probability, volume, liquidity
    """
    print("=" * 80)
    print("📊 预测市场比较仪表板")
    print("=" * 80)
    print(f"{'市场':<40} {'概率':>8} {'成交量':>12} {'流动性':>12}")
    print("-" * 80)
    
    total_volume = 0
    for m in markets_data:
        name = m['name'][:38]
        prob = f"{m['probability']:.1%}"
        volume = f"${m.get('volume', 0):,.0f}"
        liquidity = f"${m.get('liquidity', 0):,.0f}"
        total_volume += m.get('volume', 0)
        print(f"{name:<40} {prob:>8} {volume:>12} {liquidity:>12}")
    
    print("-" * 80)
    print(f"{'总计':<40} {'':>8} {f'${total_volume:,.0f}':>12}")
    print()
    
    # 概率分布分析
    probs = [m['probability'] for m in markets_data]
    avg_prob = sum(probs) / len(probs)
    high_confidence = sum(1 for p in probs if p > 0.8)
    medium_confidence = sum(1 for p in probs if 0.4 <= p <= 0.8)
    uncertain = sum(1 for p in probs if p < 0.4)
    
    print("📈 概率分布:")
    print(f"  高置信度 (>80%):  {high_confidence} 个市场")
    print(f"  中等置信度 (40-80%): {medium_confidence} 个市场")
    print(f"  低置信度 (<40%):  {uncertain} 个市场")
    print(f"  平均概率: {avg_prob:.1%}")
    print()
    
    # 高成交量市场
    sorted_by_volume = sorted(markets_data, key=lambda x: x.get('volume', 0), reverse=True)
    print("🔥 高成交量市场 (Top 5):")
    for i, m in enumerate(sorted_by_volume[:5], 1):
        print(f"  {i}. {m['name'][:50]} — ${m.get('volume', 0):,.0f}")


# 使用示例
markets = [
    {'name': 'BTC > $150K by 2025', 'probability': 0.35, 'volume': 5200000, 'liquidity': 120000},
    {'name': 'ETH > $10K by 2025', 'probability': 0.22, 'volume': 3800000, 'liquidity': 95000},
    {'name': 'US Federal Rate Cut in 2025', 'probability': 0.78, 'volume': 8900000, 'liquidity': 250000},
    {'name': 'AI Startup IPO by 2025', 'probability': 0.15, 'volume': 2100000, 'liquidity': 45000},
    {'name': 'Global Recession in 2025', 'probability': 0.12, 'volume': 6700000, 'liquidity': 180000},
]
generate_market_comparison_report(markets)
```

---

### 9. 关键分析公式参考

#### 9.1 期望值公式
```
EV = P(win) × Payout - P(lose) × Stake

其中:
- P(win) = 你估计的获胜概率
- Payout = 赔率 × Stake
- P(lose) = 1 - P(win)
- Stake = 投入金额
```

#### 9.2 凯利公式
```
f* = (b × p - q) / b

其中:
- f* = 最优资金比例
- b = 净赔率 (odds - 1)
- p = 获胜概率
- q = 失败概率 (1 - p)

半凯利（更保守）: f*/2
四分之一凯利（极保守）: f*/4
```

#### 9.3 贝叶斯更新
```
P(H|E) = P(E|H) × P(H) / P(E)

其中:
- P(H|E) = 观察证据 E 后的后验概率
- P(E|H) = 似然度（假设 H 为真时观察到 E 的概率）
- P(H) = 先验概率
- P(E) = 观察到 E 的总概率
```

#### 9.4 夏普比率
```
Sharpe Ratio = (Rp - Rf) / σp

其中:
- Rp = 投资组合收益率
- Rf = 无风险利率
- σp = 收益率标准差
```

---

## 使用指南

当用户请求预测市场分析时，按以下步骤操作：

1. **确定分析目标**：明确要分析的市场、资产或事件。
2. **获取市场数据**：通过 API 获取当前市场价格和交易数据。
3. **概率分析**：使用概率分析引擎计算边际优势和期望值。
4. **风险评估**：使用风险评估框架评估整体风险水平。
5. **仓位建议**：基于凯利公式和风险评分给出仓位建议。
6. **生成报告**：输出结构化的分析报告。

---

## 常见场景示例

### 场景 1：分析 Polymarket 市场
```
帮我分析 Polymarket 上"BTC 2025年底价格"相关市场的概率和期望值。
```

### 场景 2：投资组合模拟
```
我有 $10,000 资金，想在以下 3 个市场分配：市场A (35% 概率)、市场B (60%)、市场C (25%)。请模拟最优分配方案。
```

### 场景 3：风险对冲分析
```
分析这组市场的相关性，帮我构建一个低风险的投资组合。
```

### 场景 4：链上数据追踪
```
获取当前 DeFi TVL 排名和 ETH Gas 价格，分析市场趋势。
```
