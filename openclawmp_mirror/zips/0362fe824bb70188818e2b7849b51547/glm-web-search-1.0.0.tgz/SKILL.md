---
name: glm-web-search
displayName: GLM 智谱AI 联网搜索
description: 使用智谱AI Web Search API进行联网搜索，返回结构化搜索结果。支持多种搜索引擎，中文支持优秀。
homepage: https://open.bigmodel.cn
---

# GLM 智谱AI 联网搜索

> 使用智谱AI官方Web Search API，真正的AI联网搜索！

## 为什么选择 GLM 搜索？

| 方案 | 费用 | 中文支持 | 稳定性 |
|------|------|----------|--------|
| Perplexity | $20/月 | 一般 | 好 |
| Tavily | 免费额度有限 | 一般 | 好 |
| **GLM search_std** | **0.01元/次** | **非常好** | **好** |
| **GLM search_pro** | **0.03元/次** | **非常好** | **好** |

## 搜索引擎

| 编码 | 特性 | 价格 |
|------|------|------|
| `search_std` | 基础版(智谱自研)，日常查询 | 0.01元/次 |
| `search_pro` | 高级版，多引擎协作，准确率更高 | 0.03元/次 |
| `search_pro_sogou` | 搜狗引擎，覆盖腾讯生态 | 0.05元/次 |
| `search_pro_quark` | 夸克引擎，精准垂直内容 | 0.05元/次 |

## 环境要求

- Node.js 18+
- 智谱AI API Key

## 认证方式

### 方式1：环境变量（推荐）

```bash
export ZHIPU_API_KEY="your-api-key"
```

### 方式2：配置文件

在 OpenClaw 配置中添加：

```json
{
  "skills": {
    "entries": {
      "glm-web-search": {
        "enabled": true,
        "apiKey": "your-api-key"
      }
    }
  }
}
```

### 获取API Key

1. 访问 https://open.bigmodel.cn/
2. 注册账号（新用户有免费额度）
3. 进入控制台 → API Keys
4. 创建新API Key

## 快速开始

### 基本搜索

```bash
node {baseDir}/scripts/search.mjs "Python 异步编程教程"
```

### 指定结果数量

```bash
node {baseDir}/scripts/search.mjs "AI新闻" -n 5
```

### 使用基础版引擎（更便宜）

```bash
node {baseDir}/scripts/search.mjs "查询内容" --engine search_std
```

### 筛选域名

```bash
node {baseDir}/scripts/search.mjs "Python教程" --domain github.com
```

### 筛选时间（pd=今天, pw=本周, pm=本月, py=本年）

```bash
node {baseName}/scripts/search.mjs "AI新闻" --recent pw
```

### 输出JSON

```bash
node {baseDir}/scripts/search.mjs "查询内容" --json
```

## 参数说明

| 参数 | 说明 | 默认值 |
|------|------|--------|
| `-n <数量>` | 返回结果数量 (1-50) | 10 |
| `--json` | 输出原始JSON | false |
| `--engine` | 搜索引擎 (search_std/search_pro) | search_pro |
| `--domain` | 限定域名 | - |
| `--recent` | 时间范围 (pd/pw/pm/py) | - |

## 注意事项

1. **免费额度**: 新用户有免费额度，个人使用基本够用
2. **查询长度**: 建议控制在200字符以内
3. **中文优先**: 对中文内容搜索效果非常好
4. **合理使用**: 免费额度有限，避免频繁调用

---

*基于智谱AI官方Web Search API*
