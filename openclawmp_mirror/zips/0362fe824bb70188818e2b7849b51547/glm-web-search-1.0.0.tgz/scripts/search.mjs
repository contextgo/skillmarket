#!/usr/bin/env node

/**
 * GLM 智谱AI 联网搜索
 * 使用智谱AI官方Web Search API
 * 文档: https://docs.bigmodel.cn/api-reference/工具API/网络搜索
 */

function usage() {
  console.error(`Usage: search.mjs "query" [options]
Options:
  -n <count>        Number of results (1-50, default: 10)
  --json            Output raw JSON
  --engine <name>  search_std | search_pro (default: search_pro)
  --domain <domain> Filter by domain (optional)
  --recent <days>  Recent days: pd/pw/pm/py (optional)`);
  process.exit(2);
}

const args = process.argv.slice(2);
if (args.length === 0 || args[0] === '-h' || args[0] === '--help') usage();

// 环境变量或参数获取API Key
const API_KEY = process.env.ZHIPU_API_KEY || process.env.ZHIPU_API_KEY;

let query = args[0];
let maxResults = 10;
let outputJson = false;
let searchEngine = 'search_pro';
let domainFilter = '';
let recentFilter = '';

for (let i = 1; i < args.length; i++) {
  const a = args[i];
  if (a === '-n') {
    maxResults = parseInt(args[i + 1] || '10', 10);
    i++;
    continue;
  }
  if (a === '--json') {
    outputJson = true;
    continue;
  }
  if (a === '--engine' && args[i + 1]) {
    searchEngine = args[i + 1];
    i++;
    continue;
  }
  if (a === '--domain' && args[i + 1]) {
    domainFilter = args[i + 1];
    i++;
    continue;
  }
  if (a === '--recent' && args[i + 1]) {
    recentFilter = args[i + 1];
    i++;
    continue;
  }
}

if (!API_KEY) {
  console.error('错误: 请设置 ZHIPU_API_KEY 环境变量');
  console.error('获取API Key: https://open.bigmodel.cn/usercenter/apikeys');
  process.exit(1);
}

// 调用智谱AI Web Search API
import https from 'https';

const postData = JSON.stringify({
  search_query: query,
  count: Math.min(maxResults, 50),
  search_engine: searchEngine,
  ...(domainFilter && { search_domain_filter: domainFilter }),
  ...(recentFilter && { search_recency_filter: recentFilter }),
  content_size: 'high'
});

const options = {
  hostname: 'open.bigmodel.cn',
  path: '/api/paas/v4/web_search',
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${API_KEY}`,
    'Content-Type': 'application/json',
    'Content-Length': Buffer.byteLength(postData)
  }
};

const req = https.request(options, (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => {
    try {
      const result = JSON.parse(data);
      
      if (outputJson) {
        console.log(JSON.stringify(result, null, 2));
        return;
      }
      
      if (result.error) {
        console.error('API错误:', result.error.message);
        process.exit(1);
      }
      
      const items = result.search_result || [];
      console.log(`🔍 搜索: ${query}\n`);
      console.log(`引擎: ${searchEngine === 'search_pro' ? '高级版(pro)' : '基础版(std)'}\n`);
      console.log('---');
      
      items.forEach((item, i) => {
        console.log(`\n${i + 1}. ${item.title}`);
        console.log(`   📎 ${item.link}`);
        if (item.content) {
          console.log(`   ${item.content.substring(0, 150)}...`);
        }
        if (item.publish_date) {
          console.log(`   📅 ${item.publish_date}`);
        }
      });
      
      console.log(`\n\n共 ${items.length} 条结果`);
      
    } catch (e) {
      console.error('解析失败:', e.message);
      console.error('原始数据:', data);
    }
  });
});

req.on('error', (e) => {
  console.error('请求错误:', e.message);
  process.exit(1);
});

req.write(postData);
req.end();
