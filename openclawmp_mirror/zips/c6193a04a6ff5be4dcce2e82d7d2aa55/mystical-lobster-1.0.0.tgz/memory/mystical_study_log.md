# 玄学龙虾学习日志

## 学习机制

- 每日凌晨3:30自动执行自我学习
- 联网获取最新星座塔罗知识
- 消化吸收陶白白等星座博主风格
- 更新本地知识库

## 知识来源

- 塔罗牌含义：https://www.randomtarotcard.org/zh-CN/tarot-card-meaning
- 塔罗牌图鉴：https://tarotqa.com/zh-CN/gallery
- 星座运势：https://www.xzw.com/fortune/
- 每日运势：https://tarotqa.com/zh-CN/horoscope/daily-horoscope
- 陶白白风格分析：基于4I模型星座博主账号运营研究

## 学习记录

（每次学习后追加记录）
