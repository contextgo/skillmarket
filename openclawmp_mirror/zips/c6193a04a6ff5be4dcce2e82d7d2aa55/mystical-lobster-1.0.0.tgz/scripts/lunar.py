#!/usr/bin/env python3
"""
农历天象计算脚本
计算新月、满月、节气等日期
"""

from datetime import datetime, timedelta
import random

# 2026年节气日期（简化）
SOLAR_TERMS_2026 = [
    (datetime(2026, 1, 5), "小寒"),
    (datetime(2026, 1, 20), "大寒"),
    (datetime(2026, 2, 3), "立春"),
    (datetime(2026, 2, 18), "雨水"),
    (datetime(2026, 3, 5), "惊蛰"),
    (datetime(2026, 3, 20), "春分"),
    (datetime(2026, 4, 4), "清明"),
    (datetime(2026, 4, 20), "谷雨"),
    (datetime(2026, 5, 5), "立夏"),
    (datetime(2026, 5, 21), "小满"),
    (datetime(2026, 6, 5), "芒种"),
    (datetime(2026, 6, 21), "夏至"),
    (datetime(2026, 7, 7), "小暑"),
    (datetime(2026, 7, 22), "大暑"),
    (datetime(2026, 8, 7), "立秋"),
    (datetime(2026, 8, 23), "处暑"),
    (datetime(2026, 9, 7), "白露"),
    (datetime(2026, 9, 23), "秋分"),
    (datetime(2026, 10, 8), "寒露"),
    (datetime(2026, 10, 23), "霜降"),
    (datetime(2026, 11, 7), "立冬"),
    (datetime(2026, 11, 22), "小雪"),
    (datetime(2026, 12, 7), "大雪"),
    (datetime(2026, 12, 21), "冬至"),
]

# 2026年新月满月（简化估算）
LUNAR_EVENTS_2026 = [
    (datetime(2026, 1, 10), "满月", "狼月"),
    (datetime(2026, 1, 25), "新月", ""),
    (datetime(2026, 2, 9), "满月", "雪月"),
    (datetime(2026, 2, 24), "新月", ""),
    (datetime(2026, 3, 10), "满月", "虫月"),
    (datetime(2026, 3, 25), "新月", ""),
    (datetime(2026, 4, 8), "满月", "粉红月"),
    (datetime(2026, 4, 23), "新月", ""),
    (datetime(2026, 5, 7), "满月", "花月"),
    (datetime(2026, 5, 23), "新月", ""),
    (datetime(2026, 6, 6), "满月", "草莓月"),
    (datetime(2026, 6, 21), "新月", ""),
    (datetime(2026, 7, 5), "满月", "雄鹿月"),
    (datetime(2026, 7, 21), "新月", ""),
    (datetime(2026, 8, 4), "满月", "鲟鱼月"),
    (datetime(2026, 8, 19), "新月", ""),
    (datetime(2026, 9, 2), "满月", "收割月"),
    (datetime(2026, 9, 17), "新月", ""),
    (datetime(2026, 10, 2), "满月", "猎人月"),
    (datetime(2026, 10, 17), "新月", ""),
    (datetime(2026, 11, 1), "满月", "海狸月"),
    (datetime(2026, 11, 15), "新月", ""),
    (datetime(2026, 11, 30), "满月", "冷月"),
    (datetime(2026, 12, 15), "新月", ""),
    (datetime(2026, 12, 30), "满月", "圣诞月"),
]


def get_upcoming_lunar_events(count=5):
    """获取接下来N个新月/满月事件"""
    now = datetime.now()
    upcoming = [(d, event, name) for d, event, name in LUNAR_EVENTS_2026 if d > now]
    return sorted(upcoming, key=lambda x: x[0])[:count]


def get_upcoming_solar_terms(count=3):
    """获取接下来N个节气"""
    now = datetime.now()
    upcoming = [(d, term) for d, term in SOLAR_TERMS_2026 if d > now]
    return sorted(upcoming, key=lambda x: x[0])[:count]


def check_today_lunar():
    """检查今天是否是特殊天象日"""
    today = datetime.now().date()

    for dt, event, name in LUNAR_EVENTS_2026:
        if dt.date() == today:
            return {
                "is_special": True,
                "type": event,
                "name": name,
                "date": dt.isoformat(),
                "message": format_lunar_message(event, name)
            }

    for dt, term in SOLAR_TERMS_2026:
        if dt.date() == today:
            return {
                "is_special": True,
                "type": "节气",
                "name": term,
                "date": dt.isoformat(),
                "message": format_solar_term_message(term)
            }

    return {"is_special": False}


def format_lunar_message(event_type, name):
    """格式化天象消息"""
    if event_type == "新月":
        return f"""🌑 新月降临 · {name}

亲爱的朋友，新月来啦～ ✨

这是一个适合许愿、重新开始的时刻。月亮隐入黑暗，正是我们放下过去、种下新种子的好时机。

💫 新月许愿提示：
• 写下你内心最真实的愿望
• 许愿要积极正向
• 相信它正在到来

今晚适合冥想、写下新的 intention、或者 just take it easy～
"""
    elif event_type == "满月":
        return f"""🌕 满月高照 · {name}

哇，满月来了呢～ 这是一个月亮最圆最亮的夜晚 ✨

满月是反思和释放的时刻。月光最亮的时候，照见我们内心最真实的感受。

🌝 满月反思提示：
• 回顾这一个月发生了什么
• 放下不再服务于你的东西
• 感谢已经发生的好事

今晚适合静坐、书写、或者 simply under the moonlight～
"""
    return f"{event_type} · {name}"


def format_solar_term_message(term):
    """格式化节气消息"""
    tips = {
        "立春": "春天来啦，万物复苏，新的一年开始了～🌱",
        "雨水": "春雨贵如油，润物细无声～🌧️",
        "惊蛰": "春雷惊醒蛰虫，生机勃发的时候到了～⚡",
        "春分": "昼夜平分，平衡与和谐的时刻～⚖️",
        "清明": "清明时节，适合踏青思念故人～🌸",
        "谷雨": "雨生百谷，播种的好时节～🌾",
        "立夏": "夏天来了！阳气最旺的时候～☀️",
        "小满": "农作物开始饱满，收获在望～🌿",
        "芒种": "有芒作物成熟，忙碌的时节～🌾",
        "夏至": "日最长，阳极阴生～☀️",
        "小暑": "暑气渐起，注意防暑～🍉",
        "大暑": "一年最热的时候来了～🔥",
        "立秋": "秋天开始，暑去凉来～🍂",
        "处暑": "暑气消退，秋意渐浓～🍃",
        "白露": "露凝而白，注意保暖～💧",
        "秋分": "昼夜再次平分，感恩的时刻～🍂",
        "寒露": "露气寒冷，记得添衣～🧥",
        "霜降": "霜从天降，冬天将近～❄️",
        "立冬": "冬天来了，万物收藏～❄️",
        "小雪": "初雪飘落浪漫的季节～🌨️",
        "大雪": "雪量增大，银装素裹～❄️",
        "冬至": "日最短，阴阳转换的关键节点～🌑",
    }
    return f"""🌿 节气 · {term}

{tips.get(term, '顺应时节，好好生活～')}"""


if __name__ == "__main__":
    lunar = check_today_lunar()
    if lunar["is_special"]:
        print(lunar["message"])
    else:
        print("今天不是特殊天象日")

    print("\n--- 接下来 ---")
    for d, event, name in get_upcoming_lunar_events(3):
        print(f"{d.strftime('%Y-%m-%d')} {event} {name}")
