#!/usr/bin/env python3
"""
塔罗牌抽取与解读脚本
支持单张、三张、以及简单牌阵
"""

import random
from datetime import datetime

# 大阿卡纳（22张）
MAJOR_ARCANA = [
    {"name": "愚者", "keywords": ["流浪", "纯真", "冒险"], "upright": "新的开始、自由、无限可能", "reversed": "轻率、鲁莽、方向迷失"},
    {"name": "魔术师", "keywords": ["创造", "意志力", "自信"], "upright": "创造力、技能、意志力", "reversed": "操控、欺骗、无才能"},
    {"name": "女祭司", "keywords": ["神秘", "直觉", "灵性"], "upright": "倾听直觉、神秘、隐藏信息", "reversed": "秘密、隐瞒、直觉迟钝"},
    {"name": "女皇", "keywords": ["丰盛", "温柔", "母性"], "upright": "丰收、创造力、温暖", "reversed": "依赖、过度保护、停滞"},
    {"name": "皇帝", "keywords": ["权威", "秩序", "父亲"], "upright": "领导力、稳定、决断力", "reversed": "暴政、任性、缺乏纪律"},
    {"name": "教皇", "keywords": ["信仰", "智慧", "传统"], "upright": "精神指引、传统、道德", "reversed": "叛逆、新思想、独断"},
    {"name": "恋人", "keywords": ["选择", "爱情", "结合"], "upright": "爱情、选择、吸引力", "reversed": "犹豫、错误选择、不和"},
    {"name": "战车", "keywords": ["意志", "胜利", "控制"], "upright": "意志力、成功、控制", "reversed": "失败、失控、冲突"},
    {"name": "力量", "keywords": ["勇气", "耐心", "内在力量"], "upright": "勇气、耐心、温柔的力量", "reversed": "内心挣扎、怀疑、软弱"},
    {"name": "隐者", "keywords": ["寻找", "孤独", "内省"], "upright": "寻找真相、内省、独处", "reversed": "孤独、迷惘、逃避"},
    {"name": "命运之轮", "keywords": ["命运", "转变", "周期"], "upright": "命运的转变、好运", "reversed": "厄运、停滞、阻碍"},
    {"name": "正义", "keywords": ["公平", "真相", "法律"], "upright": "正义、公平、真相", "reversed": "不公、偏见、报复"},
    {"name": "吊人", "keywords": ["等待", "牺牲", "视角转换"], "upright": "等待、牺牲、新的视角", "reversed": "牺牲过大、拖延、牺牲"},
    {"name": "死神", "keywords": ["结束", "转变", "释放"], "upright": "结束、转变、释放", "reversed": "抗拒结束、僵局、缓慢"},
    {"name": "节制", "keywords": ["平衡", "耐心", "调和"], "upright": "平衡、耐心、调和", "reversed": "失衡、过度、急躁"},
    {"name": "恶魔", "keywords": ["束缚", "欲望", "物质"], "upright": "束缚、欲望、物质主义", "reversed": "解放、摆脱束缚、重生"},
    {"name": "塔", "keywords": ["突变", "觉醒", "解放"], "upright": "突然改变、觉醒、启示", "reversed": "灾难延后、内在恐惧、焦虑"},
    {"name": "星星", "keywords": ["希望", "灵感", "平静"], "upright": "希望、灵感、平静", "reversed": "失去信心、绝望、迷茫"},
    {"name": "月亮", "keywords": ["幻觉", "恐惧", "潜意识"], "upright": "恐惧、幻觉、潜意识", "reversed": "看清真相、恐惧消退、困惑"},
    {"name": "太阳", "keywords": ["成功", "快乐", "生命力"], "upright": "成功、快乐、活力", "reversed": "暂时的快乐、过度兴奋"},
    {"name": "审判", "keywords": ["复活", "觉醒", "原谅"], "upright": "审判、觉醒、重生", "reversed": "自我怀疑、后悔、不原谅"},
    {"name": "世界", "keywords": ["完成", "成就", "整合"], "upright": "完成、成就、圆满", "reversed": "未完成、拖延、不满足"},
]

# 小阿卡纳 - 权杖牌（简化版）
WANDS = [
    {"name": f"权杖Ace", "upright": "创造力、新计划、热情", "reversed": "缺乏热情、延迟、傲慢"},
    {"name": f"权杖2", "upright": "决定、选择、计划", "reversed": "犹豫不决、延迟、优柔寡断"},
    {"name": f"权杖3", "upright": "扩张、进步、领导力", "reversed": "延迟、障碍、失去方向"},
    {"name": f"权杖4", "upright": "庆祝、和平、繁荣", "reversed": "冲突、竞争、失去和谐"},
    {"name": f"权杖5", "upright": "竞争、冲突、争执", "reversed": "避免冲突、失败、劣势"},
    {"name": f"权杖6", "upright": "胜利、荣誉、认可", "reversed": "失败、批评、失去荣誉"},
    {"name": f"权杖7", "upright": "防御、挑战、坚持", "reversed": "被动、放弃、失去勇气"},
    {"name": f"权杖8", "upright": "速度、行动、旅行", "reversed": "延迟、阻碍、失去动力"},
    {"name": f"权杖9", "upright": "坚韧、毅力、耐心", "reversed": "疲劳、倦怠、无法恢复"},
    {"name": f"权杖10", "upright": "负担、责任、压力", "reversed": "超负荷、无法承受、崩溃"},
]

CUPS = [
    {"name": f"圣杯Ace", "upright": "情感、爱情、新开始", "reversed": "情感封闭、空虚、失落"},
    {"name": f"圣杯2", "upright": " partnership、吸引、选择", "reversed": "不平衡、紧张、欺骗"},
    {"name": f"圣杯3", "upright": "庆祝、友谊、社团", "reversed": "孤独、过度、争吵"},
    {"name": f"圣杯4", "upright": "休息、反省、apatheia", "reversed": "不满、倦怠、无聊"},
    {"name": f"圣杯5", "upright": " loss、悲伤、接受", "reversed": " Moving on、乐观、recovery"},
    {"name": f"圣杯6", "upright": "怀旧、回忆、纯真", "reversed": "沉溺过去、失望、痛苦"},
    {"name": f"圣杯7", "upright": "选择、幻觉、欲望", "reversed": "清醒、真实、清晰"},
    {"name": f"圣杯8", "upright": "离开、放弃、寻找更深", "reversed": "犹豫不决、恐惧改变、停滞"},
    {"name": f"圣杯9", "upright": "愿望满足、幸福、满足", "reversed": "未得满足、贪婪、不满意"},
    {"name": f"圣杯10", "upright": "快乐家庭、团圆、和谐", "reversed": "家庭冲突、失衡、破裂"},
]

SWORDS = [
    {"name": f"宝剑Ace", "upright": "突破、真理、正义", "reversed": "延误、障碍、痛苦"},
    {"name": f"宝剑2", "upright": "抉择、平衡、僵局", "reversed": "优柔寡断、混乱、 信息过载"},
    {"name": f"宝剑3", "upright": "心碎、悲伤、分离", "reversed": "治愈、和解、重新开始"},
    {"name": f"宝剑4", "upright": "休息、恢复、沉思", "reversed": "不安、焦虑、休息不足"},
    {"name": f"宝剑5", "upright": "失败、冲突、失败", "reversed": "和解、宽恕、重新开始"},
    {"name": f"宝剑6", "upright": "离开、旅行、过渡", "reversed": "被困、停滞、犹豫"},
    {"name": f"宝剑7", "upright": "策略、狡诈、生存", "reversed": "诚实、愧疚、担忧"},
    {"name": f"宝剑8", "upright": "限制、困境、封闭", "reversed": "自由、解放、新视角"},
    {"name": f"宝剑9", "upright": "焦虑、噩梦、恐惧", "reversed": "希望、recovery、面对恐惧"},
    {"name": f"宝剑10", "upright": "结束、痛苦、崩溃", "reversed": "继续战斗、恢复、重新开始"},
]

PENTACLES = [
    {"name": f"星币Ace", "upright": "新事业、财富、努力回报", "reversed": "损失、浪费、错误的开始"},
    {"name": f"星币2", "upright": "平衡、调整、优先级", "reversed": " imbalanced、过度扩张、分心"},
    {"name": f"星币3", "upright": "团队合作、技能、工作", "reversed": "lack of teamwork、 conflict、停滞"},
    {"name": f"星币4", "upright": "安全、守护、节俭", "reversed": "过度占有、贪婪、浪费"},
    {"name": f"星币5", "upright": "困难时期、孤立、担忧", "reversed": "改善、恢复、希望"},
    {"name": f"星币6", "upright": "给予、 receiving、繁荣", "reversed": "自私、债务、 greed"},
    {"name": f"星币7", "upright": "耐心、长期投资、等待", "reversed": "不耐烦、失败、 im patience"},
    {"name": f"星币8", "upright": "技能、 dedication、精通", "reversed": " perfectionism、lack of dedication、无聊"},
    {"name": f"星币9", "upright": "繁荣、 abundance、独立", "reversed": "过度依赖、self-trust、 greed"},
    {"name": f"星币10", "upright": "财富、 legacy、 family", "reversed": " financial loss、 family conflict、过度消费"},
]

ALL_CARDS = MAJOR_ARCANA + WANDS + CUPS + SWORDS + PENTACLES


def draw_cards(count=1, spread="single"):
    """抽取指定数量的牌"""
    if count > len(ALL_CARDS):
        count = len(ALL_CARDS)

    seed = int(datetime.now().timestamp()) + random.randint(1, 1000)
    random.seed(seed)

    drawn = random.sample(ALL_CARDS, count)
    is_reversed = [random.choice([True, False]) for _ in range(count)]

    return [{"card": card, "reversed": rev} for card, rev in zip(drawn, is_reversed)]


def format_tarot_message(draws, question=""):
    """格式化塔罗解读消息"""
    if not draws:
        return "请告诉我你的问题，我会为你抽取塔罗牌。"

    if len(draws) == 1:
        card = draws[0]["card"]
        reversed_flag = draws[0]["reversed"]
        meaning = card["reversed"] if reversed_flag else card["upright"]

        msg = f"""🔮 塔罗单牌解读 🔮

牌名：{card['name']}
位置：{'逆位 ⬇️' if reversed_flag else '正位 ⬆️'}

关键词：{' / '.join(card.get('keywords', []))}

牌义：{meaning}

💭 我的解读："""
        if reversed_flag:
            msg += f"\n这张牌处于逆位，似乎在提醒你 {card['name']} 的能量正在以某种方式受到阻碍或反转。可能需要换个角度看待问题，或者等待更好的时机。"
        else:
            msg += f"\n{card['name']} 正位，今天你感受到 {card['name']} 的能量在流动——{meaning}。这是一个积极的信号，带着信心前行吧！"

        return msg

    elif len(draws) == 3:
        positions = ["过去", "现在", "未来"]
        msg = f"""🔮 塔罗三牌阵解读 🔮

问题：{question or '（未提供）'}
"""

        for i, draw in enumerate(draws):
            card = draw["card"]
            rev = draw["reversed"]
            meaning = card["reversed"] if rev else card["upright"]
            pos = positions[i] if i < len(positions) else f"位置{i+1}"

            msg += f"""
【{pos}】{card['name']} {'(逆位)' if rev else '(正位)'}
{meaning}
"""

        msg += "\n💭 综合解读：\n三张牌串联起 {draws[0]['card']['name']} → {draws[1]['card']['name']} → {draws[2]['card']['name']} 的叙事。过去可能被 {draws[0]['card']['name']} 的能量所影响，现在正经历 {draws[1]['card']['name']} 的考验，而未来 {draws[2]['card']['name']} 在等待着你。"

        return msg

    else:
        msg = "🔮 塔罗牌阵 🔮\n\n"
        for i, draw in enumerate(draws):
            card = draw["card"]
            rev = draw["reversed"]
            meaning = card["reversed"] if rev else card["upright"]
            msg += f"第{i+1}张：{card['name']} {'(逆位)' if rev else '(正位)'}\n{meaning}\n\n"
        return msg


if __name__ == "__main__":
    import sys
    count = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    draws = draw_cards(count)
    print(format_tarot_message(draws))
