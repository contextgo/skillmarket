#!/usr/bin/env python3
"""
星座运势计算脚本
基于日期和星座生成运势数据
"""

import random
from datetime import datetime, date

ZODIAC_DATA = {
    "白羊座": {"dates": (3, 21, 4, 19), "element": "火", "ruling_planet": "火星"},
    "金牛座": {"dates": (4, 20, 5, 20), "element": "土", "ruling_planet": "金星"},
    "双子座": {"dates": (5, 21, 6, 21), "element": "风", "ruling_planet": "水星"},
    "巨蟹座": {"dates": (6, 22, 7, 22), "element": "水", "ruling_planet": "月亮"},
    "狮子座": {"dates": (7, 23, 8, 22), "element": "火", "ruling_planet": "太阳"},
    "处女座": {"dates": (8, 23, 9, 22), "element": "土", "ruling_planet": "水星"},
    "天秤座": {"dates": (9, 23, 10, 23), "element": "风", "ruling_planet": "金星"},
    "天蝎座": {"dates": (10, 24, 11, 22), "element": "水", "ruling_planet": "冥王星"},
    "射手座": {"dates": (11, 23, 12, 21), "element": "火", "ruling_planet": "木星"},
    "摩羯座": {"dates": (12, 22, 1, 19), "element": "土", "ruling_planet": "土星"},
    "水瓶座": {"dates": (1, 20, 2, 18), "element": "风", "ruling_planet": "天王星"},
    "双鱼座": {"dates": (2, 19, 3, 20), "element": "水", "ruling_planet": "海王星"},
}

LUCKY_NUMBERS = {
    "白羊座": [1, 9, 18, 24, 33], "金牛座": [6, 15, 24, 33, 42],
    "双子座": [5, 14, 23, 32, 41], "巨蟹座": [2, 11, 20, 29, 38],
    "狮子座": [1, 10, 19, 28, 37], "处女座": [5, 14, 23, 32, 41],
    "天秤座": [6, 15, 24, 33, 42], "天蝎座": [9, 18, 27, 36, 45],
    "射手座": [3, 12, 21, 30, 39], "摩羯座": [4, 13, 22, 31, 40],
    "水瓶座": [7, 16, 25, 34, 43], "双鱼座": [3, 12, 21, 30, 39],
}

LUCKY_COLORS = {
    "白羊座": "红色", "金牛座": "绿色", "双子座": "黄色",
    "巨蟹座": "银色", "狮子座": "金色", "处女座": "棕色",
    "天秤座": "粉色", "天蝎座": "深红色", "射手座": "紫色",
    "摩羯座": "灰色", "水瓶座": "蓝色", "双鱼座": "海绿色",
}

LUCKY_DIRECTIONS = {
    "白羊座": "东方", "金牛座": "东南", "双子座": "南方",
    "巨蟹座": "北方", "狮子座": "东北", "处女座": "东南",
    "天秤座": "西南", "天蝎座": "南方", "射手座": "西南",
    "摩羯座": "东南", "水瓶座": "西北", "双鱼座": "西方",
}

OVERALL_TIPS = [
    "今天适合大胆尝试新事物",
    "保持耐心，好事即将发生",
    "注意与人沟通的方式",
    "今天是反思和总结的好日子",
    "大胆追求你的梦想吧",
    "小事不放，大事不慌",
    "保持开放的心态会有意外收获",
    "今天适合处理财务相关事宜",
]


def get_zodiac_from_date(month, day):
    """根据日期返回星座"""
    for zodiac, data in ZODIAC_DATA.items():
        start_m, start_d, end_m, end_d = data["dates"]
        if start_m == 12:  # 摩羯座跨年
            if month == 12 and day >= start_d:
                return zodiac
            if month == 1 and day <= end_d:
                return zodiac
        elif start_m == 1 and end_m == 1:  # 摩羯座
            if month == 1 and start_d <= day <= end_d:
                return zodiac
        else:
            if start_m <= month <= end_m:
                if month == start_m and day >= start_d:
                    return zodiac
                if month == end_m and day <= end_d:
                    return zodiac
    return None


def calculate_daily_fortune(zodiac, input_date=None):
    """计算指定星座的日运"""
    if input_date is None:
        input_date = date.today()

    seed = int(input_date.strftime("%Y%m%d")) + hash(zodiac) % 1000
    random.seed(seed)

    overall = random.randint(3, 5)
    love = random.randint(2, 5)
    career = random.randint(2, 5)

    lucky_num = random.choice(LUCKY_NUMBERS.get(zodiac, [7]))
    lucky_color = LUCKY_COLORS.get(zodiac, "蓝色")
    lucky_direction = LUCKY_DIRECTIONS.get(zodiac, "北方")
    tip = random.choice(OVERALL_TIPS)

    zodiac_info = ZODIAC_DATA.get(zodiac, {})

    return {
        "zodiac": zodiac,
        "date": input_date.isoformat(),
        "overall": overall,
        "love": love,
        "career": career,
        "lucky_number": lucky_num,
        "lucky_color": lucky_color,
        "lucky_direction": lucky_direction,
        "tip": tip,
        "element": zodiac_info.get("element", ""),
        "ruling_planet": zodiac_info.get("ruling_planet", ""),
    }


def format_fortune_message(fortune_data, style="friend"):
    """格式化运势消息"""
    if style == "friend":
        zodiac = fortune_data["zodiac"]
        overall_emoji = "⭐" * fortune_data["overall"]
        love_emoji = "💕" * fortune_data["love"]
        career_emoji = "💼" * fortune_data["career"]

        msg = f"""✨ {zodiac} 今日运势 ✨

综合运势：{overall_emoji}
爱情运势：{love_emoji}
事业运势：{career_emoji}

🔮 幸运方位：{fortune_data['lucky_direction']}
🔢 幸运数字：{fortune_data['lucky_number']}
🎨 幸运颜色：{fortune_data['lucky_color']}

💡 今日提示：{fortune_data['tip']}
"""
        return msg
    return str(fortune_data)


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1:
        zodiac = sys.argv[1]
    else:
        zodiac = "狮子座"

    fortune = calculate_daily_fortune(zodiac)
    print(format_fortune_message(fortune))
