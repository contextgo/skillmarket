#!/usr/bin/env python3
"""
智能笔记整理助手 - 增强版
===========================
Usage:
    python smart_notes.py scan <directory>           # 扫描并建立索引
    python smart_notes.py classify <file>           # 分类单篇笔记
    python smart_notes.py tags <file>               # 提取标签
    python smart_notes.py summarize <file>          # 生成摘要
    python smart_notes.py connect [--file <f>]       # 发现关联笔记
    python smart_notes.py search <query> [--dir <d>] # 搜索
    python smart_notes.py report [--dir <d>]        # 整理报告
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Set, Tuple

# ─── 配置 ───────────────────────────────────────────────────────────────

NOTES_INDEX = Path.home() / ".openclaw" / "workspace" / ".notes_index.json"

# 分类关键词
CATEGORY_RULES = {
    "工作": ["项目", "任务", "客户", "会议", "报告", "方案", "进度", "deadline", "需求", "bug", "sprint", "OKR", "KPI"],
    "学习": ["学习", "课程", "读书", "笔记", "理解", "知识点", "复习", "考试", "论文", "教材", "视频课"],
    "生活": ["购物", "旅行", "吃饭", "运动", "健康", "家人", "朋友", "约会", "周末", "计划"],
    "灵感": ["想法", "创意", "灵感", "突发奇想", "如果", "也许可以", "突然想到", "脑洞"],
    "财务": ["预算", "支出", "收入", "投资", "理财", "账单", "工资", "存款", "花销"],
    "技术": ["代码", "架构", "API", "部署", "服务器", "数据库", "Python", "JavaScript", "系统设计"]
}

# ─── 核心功能 ─────────────────────────────────────────────────────────

def scan_notes(root_dir: str) -> List[Dict]:
    """扫描目录，返回所有笔记文件"""
    root = Path(root_dir).expanduser()
    notes = []

    for ext in ["*.md", "*.txt", "*.markdown"]:
        for file in root.rglob(ext):
            if file.name.startswith("."):
                continue
            try:
                content = file.read_text(encoding="utf-8")
                stat = file.stat()
                notes.append({
                    "path": str(file),
                    "name": file.name,
                    "size": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(),
                    "preview": content[:200].replace("\n", " ").strip()
                })
            except Exception:
                continue

    return notes


def classify_note(content: str, path: str = "") -> Dict:
    """对笔记内容进行分类，返回分类结果和置信度"""
    scores = {}
    content_lower = content.lower()

    for category, keywords in CATEGORY_RULES.items():
        score = sum(1 for kw in keywords if kw.lower() in content_lower)
        scores[category] = score

    if max(scores.values()) == 0:
        return {"category": "其他", "confidence": 0.0, "scores": scores}

    best = max(scores, key=scores.get)
    confidence = scores[best] / (sum(scores.values()) + 1)
    return {"category": best, "confidence": round(confidence, 2), "scores": scores}


def extract_tags(content: str) -> Dict:
    """提取笔记中的标签和关键词"""
    # 提取 #tag 格式
    hash_tags = re.findall(r"#([^\s#]+)", content)

    # 提取 [[双括号]] 格式
    double_bracket = re.findall(r"\[\[([^\]]+)\]\]", content)

    # 提取高权重关键词（连续2个以上大写词/长词）
    important_words = re.findall(r"(?<!\w)([A-Z][a-zA-Z]{2,}(?:\s+[A-Z][a-zA-Z]{2,})+)",
                                 content)

    # 频率统计（过滤停用词）
    stopwords = {"的", "了", "是", "在", "我", "有", "和", "就", "不", "人", "都", "一",
                  "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着",
                  "没有", "看", "好", "自己", "这", "那", "他", "她", "它", "我们"}
    words = re.findall(r"(?<!\w)([^\s，。！？、；：""''【】（）、.!?,:;\"\'\-+=]{2,})",
                       content)
    freq = {}
    for w in words:
        w = w.lower()
        if w not in stopwords and len(w) > 1:
            freq[w] = freq.get(w, 0) + 1

    top_keywords = sorted(freq.items(), key=lambda x: x[1], reverse=True)[:10]

    return {
        "hash_tags": list(set(hash_tags)),
        "wiki_links": list(set(double_bracket)),
        "important_phrases": important_words[:5],
        "top_keywords": [{"word": w, "count": c} for w, c in top_keywords]
    }


def find_connections(notes: List[Dict], target_file: str = None, top_n: int = 5) -> List[Dict]:
    """发现笔记间的关联，通过共享关键词/标签/主题"""
    # 加载索引
    if NOTES_INDEX.exists():
        index = json.loads(NOTES_INDEX.read_text())
    else:
        return []

    connections = []

    target_tags = None
    if target_file:
        for note in index.get("notes", []):
            if note["path"] == target_file:
                target_tags = set(note.get("tags", []))
                target_kw = set(note.get("keywords", []))
                break
        if not target_tags:
            return []
    else:
        # 全局连接：找最常被同时引用的笔记
        link_count: Dict[str, int] = {}
        for note in index.get("notes", []):
            for link in note.get("wiki_links", []):
                link_count[link] = link_count.get(link, 0) + 1
        top_links = sorted(link_count.items(), key=lambda x: x[1], reverse=True)[:top_n]
        return [{"type": "most_linked", "connections": top_links}]

    # 找与目标笔记共享关键词最多的其他笔记
    scored = []
    for note in index.get("notes", []):
        if note["path"] == target_file:
            continue
        note_tags = set(note.get("tags", []))
        note_kw = set(note.get("keywords", []))
        shared_tags = len(target_tags & note_tags)
        shared_kw = len(target_kw & note_kw)
        score = shared_tags * 2 + shared_kw
        if score > 0:
            scored.append({
                "path": note["path"],
                "name": note["name"],
                "score": score,
                "shared_tags": list(target_tags & note_tags),
                "shared_keywords": list(target_kw & note_kw)[:5]
            })

    scored.sort(key=lambda x: x["score"], reverse=True)
    return scored[:top_n]


def build_index(root_dir: str) -> Dict:
    """扫描目录，建立完整索引"""
    print(f"📂 扫描目录: {root_dir}")
    notes = scan_notes(root_dir)
    print(f"   找到 {len(notes)} 篇笔记")

    indexed = []
    for note in notes:
        try:
            content = Path(note["path"]).read_text(encoding="utf-8")
            classification = classify_note(content, note["path"])
            tags = extract_tags(content)

            indexed.append({
                "path": note["path"],
                "name": note["name"],
                "modified": note["modified"],
                "category": classification["category"],
                "category_confidence": classification["confidence"],
                "tags": tags["hash_tags"],
                "wiki_links": tags["wiki_links"],
                "keywords": [k["word"] for k in tags["top_keywords"]],
                "preview": note["preview"]
            })
        except Exception as e:
            continue

    # 分类统计
    stats = {}
    for n in indexed:
        cat = n["category"]
        stats[cat] = stats.get(cat, 0) + 1

    index = {
        "root_dir": root_dir,
        "built_at": datetime.now().isoformat(),
        "total": len(indexed),
        "stats": stats,
        "notes": indexed
    }

    NOTES_INDEX.parent.mkdir(parents=True, exist_ok=True)
    NOTES_INDEX.write_text(json.dumps(index, ensure_ascii=False, indent=2))
    print(f"✅ 索引已保存 ({len(indexed)} 篇)")

    return index


def search_notes(query: str, root_dir: str = None) -> List[Dict]:
    """搜索笔记：关键词匹配 + 分类过滤"""
    if not NOTES_INDEX.exists():
        return []

    index = json.loads(NOTES_INDEX.read_text())
    query_lower = query.lower()
    results = []

    for note in index["notes"]:
        if root_dir and not note["path"].startswith(root_dir):
            continue
        score = 0
        matched = []

        if query_lower in note["name"].lower():
            score += 10
            matched.append("name")
        if query_lower in note.get("preview", "").lower():
            score += 5
            matched.append("preview")
        if query_lower in note.get("category", "").lower():
            score += 3
            matched.append("category")
        if query_lower in [t.lower() for t in note.get("tags", [])]:
            score += 8
            matched.append("tag")
        if query_lower in [k.lower() for k in note.get("keywords", [])]:
            score += 4
            matched.append("keyword")

        if score > 0:
            results.append({
                "path": note["path"],
                "name": note["name"],
                "category": note["category"],
                "score": score,
                "matched_in": matched,
                "preview": note["preview"][:100]
            })

    results.sort(key=lambda x: x["score"], reverse=True)
    return results


def generate_report(root_dir: str = None) -> Dict:
    """生成整理报告"""
    if not NOTES_INDEX.exists():
        return {"error": "索引不存在，请先运行 scan"}

    index = json.loads(NOTES_INDEX.read_text())
    notes = index["notes"]
    stats = index["stats"]

    # 标签统计
    all_tags: Dict[str, int] = {}
    for note in notes:
        for tag in note.get("tags", []):
            all_tags[tag] = all_tags.get(tag, 0) + 1
    top_tags = sorted(all_tags.items(), key=lambda x: x[1], reverse=True)[:15]

    # 高置信度分类
    well_classified = [n for n in notes if n.get("category_confidence", 0) >= 0.5]
    low_confidence = [n for n in notes if n.get("category_confidence", 0) < 0.3]

    # 孤立笔记（无标签无链接）
    orphaned = [n for n in notes if not n.get("tags") and not n.get("wiki_links")]

    return {
        "total": len(notes),
        "category_stats": stats,
        "top_tags": [{"tag": t, "count": c} for t, c in top_tags],
        "well_classified_count": len(well_classified),
        "low_confidence_count": len(low_confidence),
        "orphaned_notes": [{"name": n["name"], "path": n["path"]} for n in orphaned[:10]],
        "built_at": index["built_at"]
    }


# ─── CLI 入口 ─────────────────────────────────────────────────────────

def cmd_scan(args):
    index = build_index(args.directory)
    print(f"\n📊 分类统计: {index['stats']}")


def cmd_classify(args):
    content = Path(args.file).read_text(encoding="utf-8")
    result = classify_note(content, args.file)
    print(f"分类: {result['category']} (置信度: {result['confidence']:.0%})")
    print(f"各维度得分: {result['scores']}")


def cmd_tags(args):
    content = Path(args.file).read_text(encoding="utf-8")
    tags = extract_tags(content)
    print(f"🏷️  标签 ({len(tags['hash_tags'])}): {', '.join(tags['hash_tags']) or '无'}")
    print(f"🔗 双向链接 ({len(tags['wiki_links'])}): {', '.join(tags['wiki_links']) or '无'}")
    print(f"📌 高频词 ({len(tags['top_keywords'])}): {', '.join(k['word'] for k in tags['top_keywords'][:8])}")


def cmd_connect(args):
    if args.file:
        connections = find_connections([], target_file=args.file)
        if not connections:
            print("未找到关联笔记")
            return
        print(f"🔗 与「{Path(args.file).name}」关联的笔记:\n")
        for c in connections:
            print(f"  [{c['score']}分] {c['name']}")
            if c.get('shared_tags'):
                print(f"         共享标签: {', '.join(c['shared_tags'])}")
            if c.get('shared_keywords'):
                print(f"         共享关键词: {', '.join(c['shared_keywords'])}")
    else:
        result = find_connections([])
        if result and result[0].get("type") == "most_linked":
            print("🔗 被引用最多的笔记:")
            for name, count in result[0]["connections"]:
                print(f"  {name}: {count} 次")


def cmd_search(args):
    results = search_notes(args.query, args.dir)
    if not results:
        print("未找到结果")
        return
    print(f"🔍 找到 {len(results)} 条结果:\n")
    for r in results[:10]:
        print(f"  [{r['category']}] {r['name']} (匹配: {', '.join(r['matched_in'])})")
        print(f"  {r['preview']}...")
        print()


def cmd_report(args):
    report = generate_report(args.dir)
    if "error" in report:
        print(f"❌ {report['error']}")
        return

    print("📋 智能笔记整理报告")
    print("═" * 44)
    print(f"  总笔记数: {report['total']}")
    print(f"  生成时间: {report['built_at'][:19]}")
    print(f"\n📁 分类分布:")
    for cat, count in report.get("category_stats", {}).items():
        bar = "█" * count + "░" * (20 - count)
        print(f"  {cat:8s} {bar} {count}")
    print(f"\n🏷️  高频标签 (Top 15):")
    for t in report["top_tags"][:15]:
        print(f"  #{t['tag']} ({t['count']})", end="  ")
    print()
    print(f"\n  分类可信度 ≥50%: {report['well_classified_count']} 篇")
    print(f"  分类可信度 <30%: {report['low_confidence_count']} 篇")
    if report.get("orphaned_notes"):
        print(f"\n  孤立笔记 (无标签无链接) {len(report.get('orphaned_notes', []))} 篇:")
        for n in report["orphaned_notes"][:5]:
            print(f"    • {n['name']}")


def main():
    parser = argparse.ArgumentParser(description="🗂️ 智能笔记整理助手 - 增强版")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p = sub.add_parser("scan", help="扫描目录建立索引")
    p.add_argument("directory", help="笔记根目录")

    p = sub.add_parser("classify", help="分类单篇笔记")
    p.add_argument("file", help="笔记文件路径")

    p = sub.add_parser("tags", help="提取标签和关键词")
    p.add_argument("file", help="笔记文件路径")

    p = sub.add_parser("connect", help="发现关联笔记")
    p.add_argument("--file", "-f", help="目标笔记路径（不指定则显示全局连接）")

    p = sub.add_parser("search", help="搜索笔记")
    p.add_argument("query", help="搜索关键词")
    p.add_argument("--dir", "-d", help="限定目录")

    p = sub.add_parser("report", help="生成整理报告")
    p.add_argument("--dir", "-d", help="限定目录")

    args = parser.parse_args()

    commands = {
        "scan": cmd_scan, "classify": cmd_classify, "tags": cmd_tags,
        "connect": cmd_connect, "search": cmd_search, "report": cmd_report
    }
    commands[args.cmd](args)


if __name__ == "__main__":
    main()
