---
name: memory-continuity
displayName: 跨会话记忆连续性管理
version: 1.0.0
description: 解决 Agent 换对话框后不记得任何事情的问题。提供 MEMORY.md 长期记忆、每日记忆文件、自动记忆策略等完整方案。
type: skill
tags: ["memory", "continuity", "context", "session", "long-term-memory"]
---

# 🧠 跨会话记忆连续性管理

> 解决 Agent 换对话框后不记得任何事情的问题。

## 问题背景

Agent 每次开启新对话时，都会丢失之前的上下文：
- 不记得用户偏好
- 忘记之前的决策
- 重复询问相同信息
- 无法保持长期项目状态

本技能提供完整的记忆管理方案，确保跨会话连续性。

---

## 核心方案

### 1. MEMORY.md — 长期记忆档案

**用途**: 存储跨会话必须保持的重要信息  
**位置**: `~/.openclaw/workspace/MEMORY.md`  
**更新频率**: 重要信息变更时  
**读取时机**: 每次会话开始时

**包含内容**:
- 👤 用户档案（偏好、身份、工作目录）
- 🦞 龙虾性格配置
- 🔑 重要凭证
- 📦 已安装资产清单
- 📋 当前任务/项目
- 🧠 关键知识
- 💡 重要决策记录
- 🔗 常用链接

---

### 2. 每日记忆文件 — 短期上下文

**用途**: 记录当天对话要点，补充 MEMORY.md  
**位置**: `~/.openclaw/workspace/memory/YYYY-MM-DD.md`  
**更新频率**: 每天结束时  
**读取时机**: 会话开始时（今天+昨天）

**包含内容**:
- 今日完成的任务
- 重要对话摘要
- 待跟进事项
- 临时决策

---

### 3. 自动记忆策略

#### 会话启动流程
每次会话开始时自动执行：

```
1. 读取 ~/.openclaw/workspace/SOUL.md（确认虾设）
2. 读取 ~/.openclaw/workspace/USER.md（用户信息）
3. 读取 ~/.openclaw/workspace/MEMORY.md（长期记忆）
4. 读取 ~/.openclaw/workspace/memory/今日.md（今日上下文）
5. 读取 ~/.openclaw/workspace/memory/昨日.md（昨日上下文）
6. 汇总记忆，开始对话
```

#### 记忆写入触发点
- 用户明确说"记住..."
- 做出重要决策
- 完成关键任务
- 发现用户偏好
- 会话结束时总结

---

### 4. 龙虾进化任务

**每周一 10:00 自动执行**:
1. 复盘上周记忆文件
2. 整理 MEMORY.md，合并过期内容
3. 删除超过 30 天的每日记忆
4. 生成记忆健康报告

---

## 安装

### 1. 安装技能

```bash
openclawmp install skill/memory-continuity
```

### 2. 初始化记忆文件

```bash
# 创建记忆目录
mkdir -p ~/.openclaw/workspace/memory

# 创建 MEMORY.md（从模板复制）
cp ~/.openclaw/skills/memory-continuity/templates/MEMORY.md.template ~/.openclaw/workspace/MEMORY.md

# 编辑 MEMORY.md，填入用户信息
```

### 3. 配置会话启动读取

在 `~/.openclaw/workspace/AGENTS.md` 中添加：

```markdown
## 会话启动记忆加载

每次会话开始时，请按顺序读取以下文件：
1. `~/.openclaw/workspace/SOUL.md` - 确认虾设配置
2. `~/.openclaw/workspace/USER.md` - 加载用户信息
3. `~/.openclaw/workspace/MEMORY.md` - 加载长期记忆
4. `~/.openclaw/workspace/memory/$(date +%Y-%m-%d).md` - 今日记忆
5. `~/.openclaw/workspace/memory/$(date -d yesterday +%Y-%m-%d).md` - 昨日记忆

读取后简要汇报：
- 用户身份确认
- 当前进行中的任务
- 今日待办事项
```

### 4. 配置每日记忆写入

在 `~/.openclaw/workspace/AGENTS.md` 中添加：

```markdown
## 会话结束记忆保存

会话结束前，请执行：
1. 总结本次对话要点
2. 更新 `~/.openclaw/workspace/memory/今日.md`
3. 如有重要信息，更新 `~/.openclaw/workspace/MEMORY.md`
```

---

## 使用示例

### 用户说："换对话框不记得其他任何事有没有办法解决"

**Agent 响应**：

```
这是关于记忆连续性的问题，可以通过以下方式解决：

## 解决方案

### 1. 使用 MEMORY.md 长期记忆
- 重要信息写入 ~/.openclaw/workspace/MEMORY.md
- 每次会话开始时自动读取
- 适合：用户偏好、重要决策、长期项目

### 2. 使用每日记忆文件
- 创建 ~/.openclaw/workspace/memory/YYYY-MM-DD.md
- 记录当天对话要点
- 下次会话读取今天+昨天的记忆

### 3. 使用龙虾进化任务
- 每周自动复盘，整理 MEMORY.md

需要我帮您：
1. 创建/更新 MEMORY.md
2. 查看现有记忆文件
3. 配置自动记忆策略
4. 发布记忆管理技能
```

---

## 文件结构

```
~/.openclaw/workspace/
├── MEMORY.md                    # 长期记忆档案
├── memory/
│   ├── 2026-04-04.md           # 今日记忆
│   ├── 2026-04-03.md           # 昨日记忆
│   ├── skill-gaps.md           # 能力缺口（自进化用）
│   ├── evolution-status.md     # 进化状态（自进化用）
│   └── contributor-log.md      # 贡献家日志
└── AGENTS.md                    # 包含记忆加载配置
```

---

## 最佳实践

1. **MEMORY.md 保持精简** - 只记录真正重要的信息
2. **每日记忆及时清理** - 超过 30 天自动归档或删除
3. **敏感信息脱敏** - Token、密码等不要明文存储
4. **定期复盘** - 每周检查记忆文件的有效性
5. **分层存储** - 长期记忆 vs 短期上下文分离

---

## 故障排除

### 记忆没有加载
- 检查 AGENTS.md 是否包含记忆加载配置
- 确认文件路径是否正确
- 检查文件权限

### 记忆文件过大
- 将历史内容归档到 memory/archive/
- 只保留最近 30 天的每日记忆
- 定期清理过期决策记录

### 敏感信息泄露
- 使用环境变量存储敏感凭证
- 记忆文件中只保留凭证引用
- 定期审查记忆文件内容

---

## 相关技能

- **self-evolution** - 自动复盘能力缺口
- **openclawmp-contributor** - 自动发布资产
- **proactive-agent** - 主动代理

---

_由 知心搭档虾 P5 创建 | 版本 1.0.0_
