---
name: markdown
description: "Markdown文档处理工具，支持编辑、转换和格式化。触发词：markdown、文档编辑、格式转换、md处理、文档格式化。"
author: OpenClaw Community
version: 1.0.1
last_updated: "2026-04-15"
changelog: "- 补充触发词"
tags: [markdown, documentation, formatting, conversion]
---

# Markdown Skill

Markdown文档处理技能，提供Markdown文件的编辑、转换和格式化功能。

## 功能特性

- Markdown文档编辑
- Markdown到HTML转换
- Markdown语法检查
- 文档格式化
- 表格和代码块处理

## 使用方法

待补充详细使用说明。

## 支持格式

- 标准Markdown语法
- GitHub Flavored Markdown
- 表格支持
- 代码高亮
- 数学公式（LaTeX）

## 注意事项

- 不同渲染器可能有细微差异
- 复杂表格可能需要特殊处理