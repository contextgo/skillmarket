---
name: commodity-market-signals
description: "大宗商品市场信号分析技能，涵盖石油、黄金、白银价格走势和预测"
version: 1.0.0
tags: [commodity, oil, gold, silver, market, forecast]
---

# 大宗商品市场信号分析

## 石油（Brent / WTI）

### 供需基本面
- **供给**：OPEC+ 产量决策 + 美国页岩油产量 + 战略储备释放
- **需求**：全球 GDP 增速 + 季节性需求（冬季取暖、夏季出行）
- **地缘溢价**：中东局势 + 霍尔木兹海峡风险

### 关键价格水平
| 水平 | 意义 |
|------|------|
| $80-85 | 正常区间 |
| $90-100 | 地缘溢价区间 |
| $100+ | 危机定价（历史上 2008/2011/2022） |
| $120+ | 严重危机（供应中断） |

### 实时数据源
```bash
# FRED API（免费）
curl -s "https://fred.stlouisfed.org/graph/fredgraph.csv?id=DCOILBRENTEU" | tail -1

# Yahoo Finance
curl -s "https://query1.finance.yahoo.com/v8/finance/chart/BZ=F" | jq
```

## 黄金

### 驱动因素
1. **实际利率**：利率上升 → 黄金承压（持有成本）
2. **美元强弱**：美元强 → 黄金弱
3. **避险需求**：战争/危机 → 黄金涨
4. **央行购买**：去美元化趋势支撑

### 当前观察（2026年3月）
- Gold $5,000+ 但连续两周下跌 → Silver 崩至 $83
- JP Morgan 上调预期至 $4,500 但实际价格更高
- 强美元 + Fed 零降息 = 短期看跌

## 白银

- 工业属性强（太阳能/电子）→ 受经济周期影响大
- Silver 崩跌是经济衰退的领先指标
-金银比扩大 → 市场恐慌

## 跨资产关联

```
War ↑ → Oil ↑↑ → Stocks ↓ → Gold ↑(初期)→↓(中期) → Crypto ↓(初期)→↑(反向)
Inflation ↑ → Gold ↑ → Rate ↑ → Stocks ↓ → Crypto ↓
Fear ↑ → Crypto Volatility ↑ → BTC(分化) → Altcoins ↓↓
```

## 信号组合判断

- Oil>100 + Gold>5000 + Fear<20 = 极端市场环境
- Oil>100 + Stocks<47000 = 滞胀风险
- Gold↓ + Silver↓ + USD↑ = 紧缩周期确认
