#!/usr/bin/env bash
set -euo pipefail

OUT_DIR="/sdcard/backup/skills"
STAMP="$(date +%Y%m%d%H%M)"
WORKSPACE="/root/.openclaw/workspace"
SRC_SKILLS_DIR="$WORKSPACE/skills"
RESTORE_DIR="$WORKSPACE/skill_backup"
TMP_BASE="/tmp/openclaw_skill_backup_${STAMP}"

mkdir -p "$OUT_DIR" "$TMP_BASE"

# 若 skill_backup 为空，则从 skills 目录恢复一份（兜底恢复）
if [ ! -d "$RESTORE_DIR" ] || [ -z "$(find "$RESTORE_DIR" -mindepth 1 -maxdepth 1 2>/dev/null)" ]; then
  mkdir -p "$RESTORE_DIR"
  if [ -d "$SRC_SKILLS_DIR" ]; then
    cp -a "$SRC_SKILLS_DIR/." "$RESTORE_DIR/"
  fi
fi

if [ ! -d "$SRC_SKILLS_DIR" ]; then
  echo "SKILL_BACKUP_OK total=0 changed=0"
  rm -rf "$TMP_BASE"
  exit 0
fi

TOTAL=0
CHANGED=0

for skill_path in "$SRC_SKILLS_DIR"/*; do
  [ -d "$skill_path" ] || continue
  skill_name="$(basename "$skill_path")"
  TOTAL=$((TOTAL + 1))

  tmp_dir="$TMP_BASE/$skill_name"
  pkg_root="$tmp_dir/${skill_name}_${STAMP}"
  tmp_zip="$tmp_dir/${skill_name}_${STAMP}.zip"
  mkdir -p "$pkg_root"

  # 每个 skill 单独打包，顶层目录为 skills/<skill_name>
  mkdir -p "$pkg_root/skills"
  cp -a "$skill_path" "$pkg_root/skills/$skill_name"

  python3 - <<'PY' "$pkg_root" "$tmp_zip"
import os, sys, zipfile
src_root, zip_path = sys.argv[1], sys.argv[2]
with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
    base_parent = os.path.dirname(src_root)
    for root, _, files in os.walk(src_root):
        for fn in files:
            full = os.path.join(root, fn)
            arcname = os.path.relpath(full, base_parent)
            zf.write(full, arcname)
PY

  cur_hash="$(python3 - <<'PY' "$tmp_zip"
import hashlib, sys
p = sys.argv[1]
h = hashlib.sha256()
with open(p, 'rb') as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b''):
        h.update(chunk)
print(h.hexdigest())
PY
)"

  latest_zip="$OUT_DIR/${skill_name}_latest.zip"
  latest_hash_file="$OUT_DIR/${skill_name}_latest.sha256"
  prev_hash=""
  if [ -f "$latest_hash_file" ]; then
    prev_hash="$(cat "$latest_hash_file" 2>/dev/null || true)"
  fi

  # 持续更新 latest
  cp -f "$tmp_zip" "$latest_zip"
  echo "$cur_hash" > "$latest_hash_file"

  # 内容变化才新增时间戳版本（按 skill 名命名）
  if [ "$cur_hash" != "$prev_hash" ]; then
    snapshot="$OUT_DIR/${skill_name}_${STAMP}.zip"
    cp -f "$tmp_zip" "$snapshot"
    CHANGED=$((CHANGED + 1))
    echo "UPDATED skill=$skill_name latest=$latest_zip snapshot=$snapshot"
  else
    echo "UPDATED skill=$skill_name latest=$latest_zip snapshot=SKIPPED"
  fi

  # 仅清理该 skill 的 7 天前历史
  python3 - <<'PY' "$OUT_DIR" "$skill_name"
import os, re, sys
from datetime import datetime, timedelta
out_dir, skill = sys.argv[1], sys.argv[2]
pattern = re.compile(rf"^{re.escape(skill)}_(\d{{12}})\.zip$")
cutoff = datetime.now() - timedelta(days=7)
for name in os.listdir(out_dir):
    m = pattern.match(name)
    if not m:
        continue
    ts = m.group(1)
    try:
        dt = datetime.strptime(ts, "%Y%m%d%H%M")
    except ValueError:
        continue
    if dt < cutoff:
        try:
            os.remove(os.path.join(out_dir, name))
            print(f"CLEANED {name}")
        except FileNotFoundError:
            pass
PY

done

rm -rf "$TMP_BASE"

echo "SKILL_BACKUP_OK total=$TOTAL changed=$CHANGED"