#!/usr/bin/env bash
set -euo pipefail

OUT_DIR="/sdcard/backup/workspace"
STAMP="$(date +%Y%m%d%H%M)"
TMP_DIR="/tmp/openclaw_workspace_backup_${STAMP}"
TMP_ZIP="$TMP_DIR/openclaw_workspace_backup_${STAMP}.zip"
LATEST_ZIP="$OUT_DIR/openclaw_workspace_backup_latest.zip"
LATEST_HASH_FILE="$OUT_DIR/openclaw_workspace_backup_latest.sha256"

mkdir -p "$OUT_DIR" "$TMP_DIR"

python3 - <<'PY' "$TMP_ZIP"
import os
import sys
import zipfile

zip_path = sys.argv[1]

sources = [
    ("/root/.openclaw/openclaw.json", "root/.openclaw/openclaw.json", False),
    ("/root/.openclaw/workspace", "root/.openclaw/workspace", True),
]

# 仅排除 .git（避免对象临时链接导致打包失败）；其余 workspace 内容均纳入
exclude_dir_names = {".git"}
exclude_file_suffixes = set()

with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
    for src, arc_base, is_dir in sources:
        if not os.path.exists(src):
            continue

        if not is_dir:
            if not os.path.islink(src):
                zf.write(src, arc_base)
            continue

        for root, dirs, files in os.walk(src, topdown=True, followlinks=False):
            dirs[:] = [
                d for d in dirs
                if d not in exclude_dir_names and not os.path.islink(os.path.join(root, d))
            ]

            for fn in files:
                full = os.path.join(root, fn)
                if os.path.islink(full):
                    continue
                if any(fn.endswith(suf) for suf in exclude_file_suffixes):
                    continue

                rel = os.path.relpath(full, src)
                arcname = os.path.join(arc_base, rel)
                zf.write(full, arcname)

print(zip_path)
PY

CUR_HASH="$(python3 - <<'PY' "$TMP_ZIP"
import hashlib, sys
p = sys.argv[1]
h = hashlib.sha256()
with open(p, 'rb') as f:
    for chunk in iter(lambda: f.read(1024 * 1024), b''):
        h.update(chunk)
print(h.hexdigest())
PY
)"

PREV_HASH=""
if [ -f "$LATEST_HASH_FILE" ]; then
  PREV_HASH="$(cat "$LATEST_HASH_FILE" 2>/dev/null || true)"
fi

# 1) 持续覆盖 latest
cp -f "$TMP_ZIP" "$LATEST_ZIP"
echo "$CUR_HASH" > "$LATEST_HASH_FILE"

# 2) 内容有变化才新增时间戳版本
CHANGED="0"
SNAPSHOT_PATH=""
if [ "$CUR_HASH" != "$PREV_HASH" ]; then
  SNAPSHOT_PATH="$OUT_DIR/openclaw_workspace_backup_${STAMP}.zip"
  cp -f "$TMP_ZIP" "$SNAPSHOT_PATH"
  CHANGED="1"
fi

# 3) 保留近7天时间戳版本
python3 - <<'PY' "$OUT_DIR"
import os, re, sys
from datetime import datetime, timedelta
out_dir = sys.argv[1]
pattern = re.compile(r"^openclaw_workspace_backup_(\d{12})\.zip$")
cutoff = datetime.now() - timedelta(days=7)
for name in os.listdir(out_dir):
    m = pattern.match(name)
    if not m:
        continue
    ts = m.group(1)
    try:
        dt = datetime.strptime(ts, "%Y%m%d%H%M")
    except ValueError:
        continue
    if dt < cutoff:
        try:
            os.remove(os.path.join(out_dir, name))
            print(f"CLEANED {name}")
        except FileNotFoundError:
            pass
PY

rm -rf "$TMP_DIR"

echo "WORKSPACE_BACKUP_OK changed=$CHANGED latest=$LATEST_ZIP snapshot=${SNAPSHOT_PATH:-SKIPPED}"