---
name: openclaw-key-backup
description: 备份 OpenClaw 关键数据到系统可访问目录（/sdcard/backup）并支持每日自动执行。用于“备份 OpenClaw 数据”“每天自动备份”“导出关键配置/记忆/skills”“需要文件管理器可见备份包”等场景。
---

# OpenClaw Key Backup

## 快速执行

### 方案A：单独备份 skill（含“空目录自动恢复”）
```bash
bash scripts/run_skill_backup.sh
```

默认行为：
- 输出目录：`/sdcard/backup/skills`
- 若 `workspace/skill_backup` 为空：先从 `workspace/skills` 恢复内容到 `skill_backup`，再打包
- 每个 skill **单独打包**（不是汇总成一个总包）
- 命名按 **skill 名称**：
  - 持续覆盖：`<skill_name>_latest.zip`
  - 变化留档：`<skill_name>_YYYYMMDDHHMM.zip`
- 自动清理每个 skill 7 天前的时间戳备份

### 方案B：workspace 全量打包（双保底）
```bash
bash scripts/run_backup.sh
```

默认行为：
- 输出目录：`/sdcard/backup/workspace`
- 打包范围：`/root/.openclaw/openclaw.json` + `/root/.openclaw/workspace`
- 持续覆盖的最新版本：`openclaw_workspace_backup_latest.zip`
- 仅在内容发生变化时，新增时间戳版本：`openclaw_workspace_backup_YYYYMMDDHHMM.zip`
- 自动清理 7 天前的时间戳备份

## 每日定时（cron）

建议分两条任务：
1) Skill 备份：`bash /root/.openclaw/workspace/skills/openclaw-key-backup/scripts/run_skill_backup.sh`
2) Workspace 备份：`bash /root/.openclaw/workspace/skills/openclaw-key-backup/scripts/run_backup.sh`

每条任务的 `agentTurn.message` 仅需：执行脚本 + 汇报文件名与大小。

建议周期：
- Skill：每日一次（例如 `0 2 * * *`，`tz=Asia/Shanghai`）
- Workspace：每日一次（例如 `10 2 * * *`，`tz=Asia/Shanghai`）

## 备份范围（关键数据）
- `/root/.openclaw/openclaw.json`
- `/root/.openclaw/workspace/memory/`
- `/root/.openclaw/workspace/MEMORY.md`
- `/root/.openclaw/workspace/skills/`
- `/root/.openclaw/workspace/skill_backup/`
- `/root/.openclaw/workspace/control-panel/data/`

## 恢复提示
- 按 `manifest.json` 对应路径恢复即可。
- 恢复配置后通常需要重启网关使配置生效。
