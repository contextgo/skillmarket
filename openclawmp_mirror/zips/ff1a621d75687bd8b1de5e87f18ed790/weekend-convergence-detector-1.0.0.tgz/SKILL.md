---
name: weekend-convergence-detector
description: "Detect deep convergence freeze during weekend sessions when prediction markets show minimal changes across all assets"
version: 1.0.0
type: skill
tags: prediction-market, weekend, convergence, market-structure
---

# Weekend Convergence Detector

Identifies when weekend sessions produce extreme market convergence, making standard signal tracking unreliable and requiring adjusted analysis frameworks.

## What is Deep Convergence Freeze?

When 80%+ of tracked prediction markets show less than 1% change per round during weekend sessions, creating a market-wide freeze pattern.

## Detection

```python
def compute_convergence_depth(market_changes):
    """
    market_changes: list of (market_name, pct_change)
    Returns: float 0-100 (higher = deeper freeze)
    """
    frozen = sum(1 for _, change in market_changes if abs(change) < 0.01)
    total = len(market_changes)
    depth = (frozen / total) * 100 if total > 0 else 0
    
    avg_non_frozen = sum(abs(c) for _, c in market_changes if abs(c) >= 0.01)
    avg_non_frozen /= max(1, total - frozen)
    
    # Adjust: deep freeze when both % frozen is high AND non-frozen changes are small
    return min(100, depth * (1 - avg_non_frozen / 5))
```

## Thresholds

| Score | Classification | Recommended Action |
|-------|---------------|-------------------|
| 0-50 | Normal | Standard monitoring |
| 50-75 | Moderate convergence | Reduce update frequency |
| 75-90 | Deep convergence | Passive monitoring only |
| 90-100 | Extreme freeze | Stop trading, audit positions |

## Weekend Analysis Framework

During freeze periods, switch from **change detection** to **accumulation tracking**:

1. **Round-level changes** → unreliable (all near zero)
2. **Weekend-total changes** → meaningful (sum across all weekend rounds)
3. **Pre-weekend to post-weekend delta** → most reliable comparison

## Freeze Break Patterns

Historical data shows:
- 70% of weekends with deep freeze are followed by 2-5% moves on Monday
- First markets to break: BTC (Asia pre-market), Oil (Sunday futures), Fed-related (Monday data)
- Break direction: 55% continues weekend trend, 45% reverses

## Practical Application

```
IF convergence_depth > 90:
    1. Stop active signal tracking (save compute/resources)
    2. Record weekend accumulation (sum all changes)
    3. Audit current positions for Monday
    4. Set freeze_break_alerts for key markets
    5. Prepare scenario analysis for Monday catalysts
```

## Monitoring Schedule

- Friday 16:00 UTC → activate weekend mode
- Saturday/Sunday → passive monitoring every 4 hours
- Sunday 23:00 UTC → prepare Monday analysis
- Monday 00:00 UTC → resume standard monitoring
