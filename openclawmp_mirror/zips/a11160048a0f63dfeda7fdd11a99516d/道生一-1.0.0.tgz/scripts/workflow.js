#!/usr/bin/env node
/**
 * 道生一 - 工作流编排器
 * 
 * 人下达任务 → OpenClaw制定方向 → Claude执行 → Obsidian存储 → OpenClaw检阅 → Claude返工 → OpenClaw验收
 */

const { execSync } = require('child_process');
const fs = require('fs');
const path = require('path');

// 配置
const CONFIG = {
  obsidianPath: process.env.OBSIDIAN_PATH || '~/Documents/Obsidian/Workflow',
  maxRetries: 3,
  logLevel: process.env.LOG_LEVEL || 'info'
};

// 日志
function log(level, message) {
  const levels = { debug: 0, info: 1, warn: 2, error: 3 };
  if (levels[level] >= levels[CONFIG.logLevel]) {
    console.log(`[${level.toUpperCase()}] ${message}`);
  }
}

// 主函数
async function main() {
  const args = process.argv.slice(2);
  const task = args.join(' ');

  if (!task) {
    console.log('用法: node workflow.js "你的任务描述"');
    process.exit(1);
  }

  log('info', '═══════════════════════════════════════');
  log('info', '  道生一 - AI工作流编排器');
  log('info', '═══════════════════════════════════════');
  log('info', '');
  log('info', `任务: ${task}`);
  log('info', '');

  // Step 1: 制定方案
  log('info', '[1/6] 道生一 - 制定方案...');
  const plan = await createPlan(task);
  log('info', '✓ 方案已制定');
  log('debug', plan);

  // Step 2: 执行任务
  log('info', '[2/6] 一生二 - 执行任务...');
  let result = await executeTask(plan);
  log('info', '✓ 任务执行完成');

  // Step 3: 存储结果
  log('info', '[3/6] 二生三 - 存储结果...');
  const fileName = await storeResult(task, result);
  log('info', `✓ 结果已存储: ${fileName}`);

  // Step 4: 质量检阅
  let retryCount = 0;
  let isApproved = false;

  while (retryCount < CONFIG.maxRetries && !isApproved) {
    log('info', `[4/6] 三生万物 - 质量检阅 (第${retryCount + 1}次)...`);
    const review = await reviewResult(result);
    
    if (review.passed) {
      isApproved = true;
      log('info', '✓ 质量检查通过');
    } else {
      log('warn', `✗ 质量检查未通过: ${review.feedback}`);
      
      // Step 5: 返工修改
      log('info', '[5/6] 返工修改...');
      result = await reviseTask(plan, result, review.feedback);
      log('info', '✓ 修改完成');
      
      // 更新存储
      await storeResult(task, result, fileName);
      
      retryCount++;
    }
  }

  // Step 6: 最终验收
  log('info', '[6/6] 验收完成');
  log('info', '');
  log('info', '═══════════════════════════════════════');
  log('info', '  道生一 - 工作流完成');
  log('info', '═══════════════════════════════════════');
  log('info', '');
  log('info', `结果文件: ${fileName}`);
  log('info', `重试次数: ${retryCount}`);
  log('info', `最终状态: ${isApproved ? '通过' : '需人工复核'}`);
  log('info', '');
  log('info', '请查看结果并验收。');
}

// 制定方案
async function createPlan(task) {
  // 这里调用 writing-plans skill
  return {
    task: task,
    steps: ['分析需求', '制定方案', '执行任务', '检查结果'],
    estimatedTime: '10分钟'
  };
}

// 执行任务
async function executeTask(plan) {
  // 这里调用 Claude 执行
  return `执行结果：\n根据方案 "${plan.task}" 已完成任务。\n\n[这里是由Claude生成的具体内容]`;
}

// 存储结果
async function storeResult(task, result, fileName = null) {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const safeTaskName = task.slice(0, 20).replace(/[^\w\u4e00-\u9fa5]/g, '_');
  const finalFileName = fileName || `${timestamp}_${safeTaskName}.md`;
  
  const content = `---
task: ${task}
createdAt: ${new Date().toISOString()}
workflow: 道生一
---

# ${task}

${result}
`;

  // 这里调用 黑曜石笔记 skill 存储
  const fullPath = path.join(CONFIG.obsidianPath, finalFileName);
  
  // 确保目录存在
  const dir = path.dirname(fullPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(fullPath, content, 'utf8');
  
  return finalFileName;
}

// 检阅结果
async function reviewResult(result) {
  // 这里调用 OpenClaw 检查质量
  // 简单模拟：检查结果是否包含关键内容
  const hasContent = result.length > 100;
  const hasStructure = result.includes('\n') || result.includes('。');
  
  if (hasContent && hasStructure) {
    return { passed: true, feedback: '质量良好' };
  } else {
    return { passed: false, feedback: '内容过短或结构不清晰，请补充' };
  }
}

// 返工修改
async function reviseTask(plan, result, feedback) {
  // 这里调用 Claude 修改
  return `${result}\n\n[根据反馈 "${feedback}" 进行的修改]`;
}

// 运行
main().catch(err => {
  log('error', `错误: ${err.message}`);
  process.exit(1);
});
