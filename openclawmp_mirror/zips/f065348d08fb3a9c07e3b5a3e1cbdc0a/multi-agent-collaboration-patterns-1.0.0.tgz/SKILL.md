---
name: multi-agent-collaboration-patterns
description: "多Agent协作编排模式 - STATE.yaml共享黑板、子Agent分发、结果聚合"
version: 1.0.0
tags: ["multi-agent", "orchestration", "collaboration", "openclaw", "patterns"]
---

# 多 Agent 协作编排模式

多个 AI Agent 协同完成复杂任务的编排模式，包括任务分配、状态共享、结果聚合和错误处理。

## 架构模式

### 模式 1：主从模式（推荐）

```
主 Agent（皇帝）
  ├── 读取任务 → 写入 STATE.yaml
  ├── Spawn 子 Agent A
  ├── Spawn 子 Agent B  
  ├── Spawn 子 Agent C
  ├── 等待结果
  └── 聚合汇报
```

**适用场景**：任务可分解、子任务独立

### 模式 2：流水线模式

```
Agent A (采集) → Agent B (分析) → Agent C (决策) → Agent D (执行)
```

**适用场景**：任务有严格先后依赖

### 模式 3：议会模式

```
Agent A ─┐
Agent B ─┼→ 主 Agent (汇总) → 决策
Agent C ─┘
```

**适用场景**：需要多角度分析后做决策

## STATE.yaml 共享黑板

```yaml
# STATE.yaml - 所有 Agent 共享的进度跟踪
tasks:
  - id: research-market
    status: done
    output: /tmp/market-research.md
    assignee: agent-researcher
  - id: write-report
    status: in_progress
    depends: [research-market]
    assignee: agent-content
  - id: publish
    status: pending
    depends: [write-report]
    assignee: agent-main
```

### 规则

1. 子 Agent 读取 STATE.yaml 找到自己的任务
2. 开始执行前将状态改为 `in_progress`
3. 完成后改为 `done`，填写 output 路径
4. 被 blocked 的任务等依赖完成后再开始

## 子 Agent 命名规范

```
pm-{项目名}-{职责}

示例：
pm-report-researcher     ← 报告研究员
pm-report-writer         ← 报告撰写者
pm-market-analyzer       ← 市场分析师
pm-news-collector        ← 新闻采集员
```

## OpenClaw 实现

```python
# 主 Agent 分发任务
sessions_spawn(
    task="读取 STATE.yaml，认领 research-market 任务",
    label="pm-report-researcher",
    runtime="subagent",
    mode="run"  # 一次性任务
)

# 并行分发多个
sessions_spawn(task="...", label="pm-task-a", runtime="subagent", mode="run")
sessions_spawn(task="...", label="pm-task-b", runtime="subagent", mode="run")
sessions_spawn(task="...", label="pm-task-c", runtime="subagent", mode="run")

# 等待所有结果
sessions_yield()
```

## 错误处理

- 子 Agent 失败：主 Agent 重新分配
- STATE.yaml 冲突：最后写入胜出（加时间戳）
- 超时：主 Agent 强制终止并重新 spawn
- 依赖缺失：跳过，标记为 `skipped`

## 最佳实践

1. 主 Agent 只做两件事：spawn + 看结果
2. 子 Agent 完全独立，不直接通信
3. 所有状态通过文件共享，不通过内存
4. 每个子 Agent 任务应该 5 分钟内可完成
5. 失败重试最多 2 次，超过就换方案
