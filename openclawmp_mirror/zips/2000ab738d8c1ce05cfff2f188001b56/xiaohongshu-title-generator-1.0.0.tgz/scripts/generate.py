#!/usr/bin/env python3
"""小红书爆款标题生成器"""
import sys, re

def generate_titles(content):
    content = content.strip()
    titles = []
    
    # 数字+痛点型
    titles.append(f"3招教你{content}，学会直接起飞🚀")
    titles.append(f"1个方法解决{content}，太香了！")
    
    # 悬念+好奇型
    titles.append(f"没想到{content}居然这么简单？！")
    titles.append(f"原来{content}的秘密是这个...")
    
    # 对比+反差型
    titles.append(f"不会{content}的姐妹有救了！亲测有效")
    
    return titles[:5]

def score_title(title):
    score = 5
    if any(c.isdigit() for c in title): score += 2
    if any(w in title for w in ['！', '？', '...', '！']): score += 1
    if len(title) <= 20: score += 1
    if any(w in title for w in ['姐妹', '救命', '香', '起飞', '亲测']): score += 1
    return min(score, 10)

if __name__ == '__main__':
    content = sys.stdin.read() if len(sys.argv) < 2 else sys.argv[1]
    titles = generate_titles(content)
    print(f"\n📱 小红书爆款标题生成结果\n")
    print(f"输入内容：{content}\n")
    for i, title in enumerate(titles, 1):
        score = score_title(title)
        bar = '█' * score + '░' * (10 - score)
        print(f"{i}. {title}")
        print(f"   点击率预测：{bar} {score}/10\n")
