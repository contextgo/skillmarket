#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
超级AI体 v2.2 集成学习系统
==========================
结合SQLite快速查询 + Markdown学习日志

进化时间: 2026-04-21
版本: v2.2
"""

import os
import sys
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Optional, List, Dict

# 添加原error_learning的导入路径
sys.path.insert(0, r"E:\阶跃AI文件输出\workspace")
from error_learning import ErrorLearningSystem, ErrorRecord

# 学习日志目录
LEARNINGS_DIR = Path(r"E:\阶跃AI文件输出\记忆系统\.learnings")


class IntegratedLearningSystem:
    """
    集成学习系统
    
    双轨制：
    1. SQLite (error_learning.db) - 快速查询、相似错误匹配
    2. Markdown (.learnings/) - 结构化记录、人工review、promote到AGENTS.md
    """
    
    def __init__(self):
        # SQLite系统（原有）
        self.sqlite_system = ErrorLearningSystem()
        
        # Markdown日志目录
        self.learnings_dir = LEARNINGS_DIR
        self.learnings_dir.mkdir(exist_ok=True)
    
    def record_error(self, task: str, error: str, solution: str, 
                    context: str = "", priority: str = "high",
                    area: str = "agent") -> Dict:
        """
        记录错误 - 双轨制
        
        同时记录到：
        1. SQLite（快速查询、相似匹配）
        2. Markdown（结构化日志、人工review）
        """
        # 1. 记录到SQLite
        sqlite_id = self.sqlite_system.record_error(task, error, solution, context)
        
        # 2. 记录到Markdown
        markdown_id = self._log_to_markdown(
            entry_type="ERR",
            summary=task,
            details=f"**错误:** {error}\n\n**解决:** {solution}",
            priority=priority,
            area=area,
            context=context
        )
        
        print(f"[OK] 错误已双轨记录:")
        print(f"    SQLite: {sqlite_id}")
        print(f"    Markdown: {markdown_id}")
        
        return {
            'sqlite_id': sqlite_id,
            'markdown_id': markdown_id
        }
    
    def record_learning(self, summary: str, details: str = "",
                       category: str = "correction",
                       priority: str = "medium", 
                       area: str = "agent",
                       source: str = "user_feedback") -> str:
        """
        记录学习/纠正
        
        只记录到Markdown（LEARNINGS.md）
        """
        return self._log_to_markdown(
            entry_type="LRN",
            summary=summary,
            details=details,
            category=category,
            priority=priority,
            area=area,
            source=source
        )
    
    def record_feature_request(self, capability: str, context: str = "",
                              complexity: str = "medium",
                              area: str = "agent") -> str:
        """
        记录功能请求
        
        只记录到Markdown（FEATURE_REQUESTS.md）
        """
        return self._log_to_markdown(
            entry_type="FEAT",
            summary=capability,
            details=context,
            complexity=complexity,
            priority="medium",
            area=area
        )
    
    def _log_to_markdown(self, entry_type: str, summary: str, 
                        details: str = "", category: str = "",
                        priority: str = "medium", area: str = "agent",
                        source: str = "", context: str = "",
                        complexity: str = "") -> str:
        """
        记录到Markdown文件
        """
        # 生成ID
        date_str = datetime.now().strftime("%Y%m%d")
        
        # 读取现有文件统计数量
        if entry_type == "LRN":
            file_path = self.learnings_dir / "LEARNINGS.md"
            seq = self._get_next_sequence(file_path, "LRN")
        elif entry_type == "ERR":
            file_path = self.learnings_dir / "ERRORS.md"
            seq = self._get_next_sequence(file_path, "ERR")
        elif entry_type == "FEAT":
            file_path = self.learnings_dir / "FEATURE_REQUESTS.md"
            seq = self._get_next_sequence(file_path, "FEAT")
        else:
            raise ValueError(f"Unknown entry type: {entry_type}")
        
        entry_id = f"{entry_type}-{date_str}-{seq:03d}"
        timestamp = datetime.now().isoformat()
        
        # 构建条目
        if entry_type == "LRN":
            entry = self._build_learning_entry(
                entry_id, timestamp, summary, details, category,
                priority, area, source
            )
        elif entry_type == "ERR":
            entry = self._build_error_entry(
                entry_id, timestamp, summary, details,
                priority, area, context
            )
        elif entry_type == "FEAT":
            entry = self._build_feature_entry(
                entry_id, timestamp, summary, details,
                complexity, area
            )
        
        # 追加到文件
        with open(file_path, "a", encoding="utf-8") as f:
            f.write(entry)
        
        return entry_id
    
    def _get_next_sequence(self, file_path: Path, prefix: str) -> int:
        """获取下一个序列号"""
        if not file_path.exists():
            return 1
        
        content = file_path.read_text(encoding="utf-8")
        date_str = datetime.now().strftime("%Y%m%d")
        
        # 统计今天已有的条目
        count = content.count(f"{prefix}-{date_str}-")
        return count + 1
    
    def _build_learning_entry(self, entry_id: str, timestamp: str,
                             summary: str, details: str, category: str,
                             priority: str, area: str, source: str) -> str:
        """构建学习条目"""
        return f"""
### [{entry_id}] {category}

**Logged**: {timestamp}
**Priority**: {priority}
**Status**: pending
**Area**: {area}

### Summary
{summary}

### Details
{details}

### Suggested Action
待补充

### Metadata
- Source: {source}
- Related Files: 
- Tags: 

---
"""
    
    def _build_error_entry(self, entry_id: str, timestamp: str,
                          summary: str, details: str,
                          priority: str, area: str, context: str) -> str:
        """构建错误条目"""
        return f"""
### [{entry_id}] {summary[:30]}

**Logged**: {timestamp}
**Priority**: {priority}
**Status**: pending
**Area**: {area}

### Summary
{summary}

### Error
{details}

### Context
- 环境: {context}

### Suggested Fix
待分析

### Metadata
- Reproducible: unknown
- Related Files: 

---
"""
    
    def _build_feature_entry(self, entry_id: str, timestamp: str,
                            summary: str, context: str,
                            complexity: str, area: str) -> str:
        """构建功能请求条目"""
        return f"""
### [{entry_id}] {summary[:30]}

**Logged**: {timestamp}
**Priority**: medium
**Status**: pending
**Area**: {area}

### Requested Capability
{summary}

### User Context
{context}

### Complexity Estimate
{complexity}

### Suggested Implementation
待设计

### Metadata
- Frequency: first_time
- Related Features: 

---
"""
    
    def suggest_solution(self, error: str) -> Optional[str]:
        """
        建议解决方案（使用SQLite快速查询）
        """
        return self.sqlite_system.suggest_solution(error)
    
    def find_similar_errors(self, error: str, limit: int = 3) -> List[Dict]:
        """
        查找相似错误（使用SQLite全文搜索）
        """
        return self.sqlite_system.find_similar_errors(error, limit)
    
    def get_stats(self) -> Dict:
        """获取统计信息"""
        sqlite_stats = self.sqlite_system.get_stats()
        
        # 统计Markdown文件
        markdown_counts = {}
        for file_name in ["LEARNINGS.md", "ERRORS.md", "FEATURE_REQUESTS.md"]:
            file_path = self.learnings_dir / file_name
            if file_path.exists():
                content = file_path.read_text(encoding="utf-8")
                # 统计条目数（通过### [ID]模式）
                count = content.count("### [")
                markdown_counts[file_name.replace(".md", "")] = count
        
        return {
            'sqlite': sqlite_stats,
            'markdown': markdown_counts
        }
    
    def promote_to_agents(self, entry_id: str, target_file: str = "AGENTS.md"):
        """
        将学习记录promote到AGENTS.md
        
        参数:
            entry_id: 条目ID (如 LRN-20260421-001)
            target_file: 目标文件 (AGENTS.md / SOUL.md / TOOLS.md)
        """
        # 解析entry_id
        prefix = entry_id.split("-")[0]
        
        if prefix == "LRN":
            file_path = self.learnings_dir / "LEARNINGS.md"
        elif prefix == "ERR":
            file_path = self.learnings_dir / "ERRORS.md"
        elif prefix == "FEAT":
            file_path = self.learnings_dir / "FEATURE_REQUESTS.md"
        else:
            print(f"[Error] 未知的entry_id格式: {entry_id}")
            return
        
        # 读取并找到条目
        if not file_path.exists():
            print(f"[Error] 文件不存在: {file_path}")
            return
        
        content = file_path.read_text(encoding="utf-8")
        
        # 查找条目并更新状态
        if entry_id in content:
            # 更新状态为promoted
            old_status = f"**Status**: pending"
            new_status = f"**Status**: promoted\n**Promoted To**: {target_file}"
            
            if old_status in content:
                content = content.replace(
                    f"### [{entry_id}]" + content.split(f"### [{entry_id}]")[1].split("---")[0].replace(old_status, new_status),
                    f"### [{entry_id}]" + content.split(f"### [{entry_id}]")[1].split("---")[0].replace(old_status, new_status)
                )
                
                with open(file_path, "w", encoding="utf-8") as f:
                    f.write(content)
                
                print(f"[OK] 条目 {entry_id} 已标记为promoted -> {target_file}")
            else:
                print(f"[Warning] 条目状态不是pending，无法promote")
        else:
            print(f"[Error] 未找到条目: {entry_id}")


# ========== 快捷函数 ==========

_learning_system = None

def _get_system():
    global _learning_system
    if _learning_system is None:
        _learning_system = IntegratedLearningSystem()
    return _learning_system

def record_error(task: str, error: str, solution: str, 
                context: str = "", priority: str = "high") -> Dict:
    """快捷记录错误"""
    return _get_system().record_error(task, error, solution, context, priority)

def record_learning(summary: str, details: str = "",
                   category: str = "correction",
                   priority: str = "medium") -> str:
    """快捷记录学习"""
    return _get_system().record_learning(summary, details, category, priority)

def record_feature(capability: str, context: str = "",
                  complexity: str = "medium") -> str:
    """快捷记录功能请求"""
    return _get_system().record_feature_request(capability, context, complexity)

def suggest_solution(error: str) -> Optional[str]:
    """快捷建议解决方案"""
    return _get_system().suggest_solution(error)


# ========== 测试 ==========

if __name__ == "__main__":
    print("=" * 60)
    print("IntegratedLearningSystem v2.2 集成测试")
    print("=" * 60)
    
    ils = IntegratedLearningSystem()
    
    # 测试1: 记录错误（双轨）
    print("\n[Test 1] 记录错误（双轨制）...")
    result = ils.record_error(
        task="测试任务：数据库连接",
        error="Connection refused: 无法连接到SQLite数据库",
        solution="检查文件路径是否存在，使用绝对路径，确保目录有写入权限",
        context="初始化学习系统",
        priority="high"
    )
    print(f"    SQLite ID: {result['sqlite_id']}")
    print(f"    Markdown ID: {result['markdown_id']}")
    
    # 测试2: 记录学习
    print("\n[Test 2] 记录学习...")
    learning_id = ils.record_learning(
        summary="应该使用双轨制记录错误",
        details="SQLite用于快速查询，Markdown用于人工review和promote",
        category="best_practice",
        priority="high"
    )
    print(f"    Learning ID: {learning_id}")
    
    # 测试3: 记录功能请求
    print("\n[Test 3] 记录功能请求...")
    feature_id = ils.record_feature(
        capability="自动promote学习记录到AGENTS.md",
        context="当学习记录被验证有效后，自动升级",
        complexity="medium"
    )
    print(f"    Feature ID: {feature_id}")
    
    # 测试4: 建议解决方案
    print("\n[Test 4] 建议解决方案...")
    suggestion = ils.suggest_solution("数据库连接失败")
    if suggestion:
        print(f"    建议: {suggestion[:80]}...")
    else:
        print("    没有找到相似错误")
    
    # 测试5: 统计
    print("\n[Test 5] 统计信息...")
    stats = ils.get_stats()
    print(f"    SQLite记录: {stats['sqlite']['total_errors_recorded']}")
    print(f"    Markdown记录: {stats['markdown']}")
    
    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)
