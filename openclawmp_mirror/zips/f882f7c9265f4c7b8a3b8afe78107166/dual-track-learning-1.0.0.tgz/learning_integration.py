#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
学习系统集成模块 - 供super_ai.py调用
=====================================
在出错/纠正时自动记录到学习系统

用法：
    from learning_integration import LearningLogger
    
    logger = LearningLogger()
    
    # 出错时自动记录
    try:
        do_something()
    except Exception as e:
        logger.log_error(
            task="执行任务",
            error=str(e),
            solution="待分析",
            context="上下文"
        )
    
    # 用户纠正时记录
    if user_corrected:
        logger.log_correction(
            original="原回答",
            correction="用户纠正",
            context="对话上下文"
        )
"""

import sys
import os
from pathlib import Path

# 添加技能系统路径
sys.path.insert(0, r"E:\阶跃AI文件输出\技能系统")

# 尝试导入集成学习系统
try:
    from integrated_learning import (
        IntegratedLearningSystem,
        record_error as _record_error,
        record_learning as _record_learning,
        record_feature as _record_feature,
        suggest_solution as _suggest_solution
    )
    INTEGRATED_AVAILABLE = True
except ImportError as e:
    print(f"[Warning] 集成学习系统未完全初始化: {e}")
    INTEGRATED_AVAILABLE = False


class LearningLogger:
    """
    学习日志记录器
    封装了集成学习系统的调用，提供简化的API
    """
    
    def __init__(self):
        self.system = None
        if INTEGRATED_AVAILABLE:
            try:
                self.system = IntegratedLearningSystem()
            except Exception as e:
                print(f"[Warning] 初始化学习系统失败: {e}")
    
    def log_error(self, task: str, error: str, solution: str = "",
                  context: str = "", priority: str = "high") -> dict:
        """
        记录错误（双轨制：SQLite + Markdown）
        
        参数:
            task: 任务描述
            error: 错误信息
            solution: 解决方案（如果已知）
            context: 上下文
            priority: 优先级 (high/medium/low)
        
        返回:
            {'sqlite_id': str, 'markdown_id': str} 或 None
        """
        if not self.system:
            print(f"[Learning] 错误记录（系统未初始化）: {task}")
            return None
        
        try:
            result = self.system.record_error(
                task=task,
                error=error,
                solution=solution or "待分析",
                context=context,
                priority=priority
            )
            return result
        except Exception as e:
            print(f"[Learning] 记录错误失败: {e}")
            return None
    
    def log_correction(self, original: str, correction: str,
                      context: str = "", priority: str = "medium") -> str:
        """
        记录用户纠正
        
        参数:
            original: 原回答/做法
            correction: 用户纠正内容
            context: 对话上下文
            priority: 优先级
        
        返回:
            记录ID 或 None
        """
        if not self.system:
            print(f"[Learning] 纠正记录（系统未初始化）")
            return None
        
        try:
            summary = f"用户纠正: {correction[:50]}"
            details = f"**原回答:** {original}\n\n**用户纠正:** {correction}"
            
            result = self.system.record_learning(
                summary=summary,
                details=details,
                category="correction",
                priority=priority,
                source="user_feedback"
            )
            return result
        except Exception as e:
            print(f"[Learning] 记录纠正失败: {e}")
            return None
    
    def log_knowledge_gap(self, topic: str, what_learned: str,
                         priority: str = "medium") -> str:
        """
        记录知识缺口（学到的新知识）
        
        参数:
            topic: 主题
            what_learned: 学到的内容
            priority: 优先级
        
        返回:
            记录ID 或 None
        """
        if not self.system:
            return None
        
        try:
            result = self.system.record_learning(
                summary=f"知识缺口: {topic}",
                details=what_learned,
                category="knowledge_gap",
                priority=priority,
                source="self_reflection"
            )
            return result
        except Exception as e:
            print(f"[Learning] 记录知识缺口失败: {e}")
            return None
    
    def log_best_practice(self, practice: str, details: str = "",
                         priority: str = "medium") -> str:
        """
        记录最佳实践
        
        参数:
            practice: 实践名称
            details: 详细说明
            priority: 优先级
        
        返回:
            记录ID 或 None
        """
        if not self.system:
            return None
        
        try:
            result = self.system.record_learning(
                summary=f"最佳实践: {practice}",
                details=details,
                category="best_practice",
                priority=priority,
                source="conversation"
            )
            return result
        except Exception as e:
            print(f"[Learning] 记录最佳实践失败: {e}")
            return None
    
    def log_feature_request(self, capability: str, context: str = "",
                           complexity: str = "medium") -> str:
        """
        记录功能请求
        
        参数:
            capability: 想要的功能
            context: 为什么需要
            complexity: 复杂度 (simple/medium/complex)
        
        返回:
            记录ID 或 None
        """
        if not self.system:
            return None
        
        try:
            result = self.system.record_feature_request(
                capability=capability,
                context=context,
                complexity=complexity
            )
            return result
        except Exception as e:
            print(f"[Learning] 记录功能请求失败: {e}")
            return None
    
    def suggest_solution(self, error: str) -> str:
        """
        建议解决方案（基于历史错误记录）
        
        参数:
            error: 当前错误信息
        
        返回:
            建议的解决方案，如果没有则返回None
        """
        if not self.system:
            return None
        
        try:
            return self.system.suggest_solution(error)
        except Exception as e:
            print(f"[Learning] 建议解决方案失败: {e}")
            return None
    
    def get_stats(self) -> dict:
        """
        获取学习系统统计
        
        返回:
            统计信息字典
        """
        if not self.system:
            return {"error": "系统未初始化"}
        
        try:
            return self.system.get_stats()
        except Exception as e:
            return {"error": str(e)}


# ========== 快捷函数（无需实例化）==========

_logger = None

def _get_logger():
    global _logger
    if _logger is None:
        _logger = LearningLogger()
    return _logger

def log_error(task: str, error: str, solution: str = "",
              context: str = "", priority: str = "high"):
    """快捷记录错误"""
    return _get_logger().log_error(task, error, solution, context, priority)

def log_correction(original: str, correction: str, context: str = ""):
    """快捷记录纠正"""
    return _get_logger().log_correction(original, correction, context)

def log_knowledge_gap(topic: str, what_learned: str):
    """快捷记录知识缺口"""
    return _get_logger().log_knowledge_gap(topic, what_learned)

def log_best_practice(practice: str, details: str = ""):
    """快捷记录最佳实践"""
    return _get_logger().log_best_practice(practice, details)

def log_feature_request(capability: str, context: str = ""):
    """快捷记录功能请求"""
    return _get_logger().log_feature_request(capability, context)

def suggest_solution(error: str):
    """快捷建议解决方案"""
    return _get_logger().suggest_solution(error)


# ========== 测试 ==========

if __name__ == "__main__":
    print("=" * 60)
    print("LearningIntegration 测试")
    print("=" * 60)
    
    # 测试快捷函数
    print("\n[Test 1] 记录错误...")
    result = log_error(
        task="测试集成学习系统",
        error="测试错误信息",
        solution="测试解决方案",
        context="集成测试"
    )
    print(f"    结果: {result}")
    
    print("\n[Test 2] 记录纠正...")
    result = log_correction(
        original="原回答",
        correction="用户纠正内容"
    )
    print(f"    结果: {result}")
    
    print("\n[Test 3] 获取统计...")
    stats = _get_logger().get_stats()
    print(f"    统计: {stats}")
    
    print("\n" + "=" * 60)
    print("测试完成!")
    print("=" * 60)
