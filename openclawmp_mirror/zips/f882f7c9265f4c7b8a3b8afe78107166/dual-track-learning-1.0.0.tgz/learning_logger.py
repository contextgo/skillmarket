#!/usr/bin/env python3
"""
学习记录工具 - 快速记录错误、纠正和功能请求
用法：
  python learning_logger.py learning "纠正内容" --category correction
  python learning_logger.py error "错误信息" --command "失败的命令"
  python learning_logger.py feature "功能描述" --complexity medium
"""

import sys
import argparse
from datetime import datetime
from pathlib import Path

LEARNINGS_DIR = Path("E:/阶跃AI文件输出/记忆系统/.learnings")

def generate_id(entry_type: str) -> str:
    """生成ID: TYPE-YYYYMMDD-XXX"""
    date_str = datetime.now().strftime("%Y%m%d")
    # 简化：使用001作为序列号（实际应该读取文件统计）
    return f"{entry_type.upper()}-{date_str}-001"

def log_learning(summary: str, category: str = "correction", 
                 priority: str = "medium", area: str = "agent",
                 details: str = "", source: str = "user_feedback"):
    """记录学习"""
    entry_id = generate_id("LRN")
    timestamp = datetime.now().isoformat()
    
    entry = f"""\n### [{entry_id}] {category}

**Logged**: {timestamp}
**Priority**: {priority}
**Status**: pending
**Area**: {area}

### Summary
{summary}

### Details
{details}

### Suggested Action
待补充

### Metadata
- Source: {source}
- Related Files: 
- Tags: 

---
"""
    
    file_path = LEARNINGS_DIR / "LEARNINGS.md"
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(entry)
    
    print(f"✅ 学习记录已添加: {entry_id}")
    return entry_id

def log_error(summary: str, error_msg: str = "", 
              command: str = "", area: str = "agent"):
    """记录错误"""
    entry_id = generate_id("ERR")
    timestamp = datetime.now().isoformat()
    
    entry = f"""\n### [{entry_id}] {summary[:30]}

**Logged**: {timestamp}
**Priority**: high
**Status**: pending
**Area**: {area}

### Summary
{summary}

### Error
```
{error_msg}
```

### Context
- Command: {command}

### Suggested Fix
待分析

### Metadata
- Reproducible: unknown
- Related Files: 

---
"""
    
    file_path = LEARNINGS_DIR / "ERRORS.md"
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(entry)
    
    print(f"✅ 错误记录已添加: {entry_id}")
    return entry_id

def log_feature(capability: str, context: str = "", 
                complexity: str = "medium", area: str = "agent"):
    """记录功能请求"""
    entry_id = generate_id("FEAT")
    timestamp = datetime.now().isoformat()
    
    entry = f"""\n### [{entry_id}] {capability[:30]}

**Logged**: {timestamp}
**Priority**: medium
**Status**: pending
**Area**: {area}

### Requested Capability
{capability}

### User Context
{context}

### Complexity Estimate
{complexity}

### Suggested Implementation
待设计

### Metadata
- Frequency: first_time
- Related Features: 

---
"""
    
    file_path = LEARNINGS_DIR / "FEATURE_REQUESTS.md"
    with open(file_path, "a", encoding="utf-8") as f:
        f.write(entry)
    
    print(f"✅ 功能请求已添加: {entry_id}")
    return entry_id

def main():
    parser = argparse.ArgumentParser(description="学习记录工具")
    parser.add_argument("type", choices=["learning", "error", "feature"],
                       help="记录类型")
    parser.add_argument("content", help="记录内容")
    parser.add_argument("--category", default="correction", help="学习类别")
    parser.add_argument("--priority", default="medium", help="优先级")
    parser.add_argument("--area", default="agent", help="领域")
    parser.add_argument("--command", help="失败的命令")
    parser.add_argument("--complexity", default="medium", help="复杂度")
    
    args = parser.parse_args()
    
    if args.type == "learning":
        log_learning(args.content, args.category, args.priority, args.area)
    elif args.type == "error":
        log_error(args.content, command=args.command or "", area=args.area)
    elif args.type == "feature":
        log_feature(args.content, complexity=args.complexity, area=args.area)

if __name__ == "__main__":
    main()
