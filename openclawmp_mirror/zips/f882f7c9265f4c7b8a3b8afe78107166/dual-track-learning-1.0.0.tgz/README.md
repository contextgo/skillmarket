# 双轨学习系统

AI Agent双轨学习系统：SQLite快速查询 + Markdown结构化记录

## 快速开始

```python
from learning_integration import LearningLogger

logger = LearningLogger()

# 记录错误
logger.log_error(
    task="生成报告",
    error="连接超时",
    solution="添加重试机制"
)

# 记录用户纠正
logger.log_correction(
    original="原回答",
    correction="用户纠正"
)
```

## 双轨架构

- **SQLite**: 快速查询、相似匹配
- **Markdown**: 结构化记录、人工review

详见 SKILL.md
