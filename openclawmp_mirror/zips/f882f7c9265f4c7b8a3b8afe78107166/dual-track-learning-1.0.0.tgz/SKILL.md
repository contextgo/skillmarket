---
name: dual-track-learning
description: AI Agent双轨学习系统，SQLite快速查询+Markdown结构化记录，自动记录错误、纠正和知识缺口
version: 1.0.0
author: 小跃
tags: [learning, memory, error-handling, improvement, agent]
---

# 双轨学习系统

AI Agent双轨学习系统，结合SQLite快速查询和Markdown结构化记录，实现持续改进。

## 双轨架构

| 轨道 | 用途 | 存储 |
|:---|:---|:---|
| **SQLite** | 快速查询、相似匹配 | `error_learning.db` |
| **Markdown** | 结构化记录、人工review | `.learnings/` 目录 |

## 核心功能

- 📝 **错误记录**：自动记录错误路径和解决方案
- 🔍 **相似匹配**：基于历史错误建议解决方案
- 📚 **知识缺口**：记录学到的新知识
- ✅ **最佳实践**：沉淀有效的工作方法
- 🎯 **功能请求**：追踪用户需求

## 文件结构

```
记忆系统/
├── .learnings/
│   ├── LEARNINGS.md      # 学习记录
│   ├── ERRORS.md         # 错误记录
│   └── FEATURE_REQUESTS.md  # 功能请求
└── error_learning.db     # SQLite数据库
```

## 使用方法

### 1. 基础用法

```python
from learning_integration import LearningLogger

logger = LearningLogger()

# 记录错误
logger.log_error(
    task="生成股票报告",
    error="akshare连接超时",
    solution="添加重试机制",
    context="盘前分析"
)

# 记录纠正
logger.log_correction(
    original="原回答",
    correction="用户纠正内容"
)

# 获取建议
suggestion = logger.suggest_solution("连接超时")
```

### 2. 快捷函数

```python
from learning_integration import log_error, log_correction

log_error(task="...", error="...", solution="...")
log_correction(original="...", correction="...")
```

### 3. 自动集成到Agent

```python
try:
    result = do_something()
except Exception as e:
    logger.log_error(
        task="任务描述",
        error=str(e),
        solution="待分析",
        context="上下文"
    )
```

## 记录格式

### 学习记录 (LEARNINGS.md)

```markdown
### [LRN-20260421-001] correction

**Logged**: 2026-04-21T14:30:00Z
**Priority**: medium
**Status**: pending
**Area**: agent

### Summary
用户纠正内容摘要

### Details
详细描述

### Metadata
- Source: user_feedback
- Related Files: 
```

### 错误记录 (ERRORS.md)

```markdown
### [ERR-20260421-001] 任务名

**Logged**: 2026-04-21T14:30:00Z
**Priority**: high
**Status**: pending

### Summary
错误简述

### Error
错误详情

### Suggested Fix
修复建议
```

## 状态流转

```
pending → resolved → promoted
   ↓
wont_fix
```

- **pending**: 待处理
- **resolved**: 已解决
- **promoted**: 已升级到AGENTS.md/SOUL.md
- **wont_fix**: 不处理

## 定期Review

### 每周Review清单

- [ ] 检查ERRORS.md中的pending错误
- [ ] 检查LEARNINGS.md中的pending学习
- [ ] 将验证有效的记录标记为resolved
- [ ] 将高价值学习promote到AGENTS.md

## 适用场景

- Agent自我改进
- 错误模式学习
- 用户反馈追踪
- 知识管理
- 最佳实践沉淀

## 技术说明

- SQLite：全文搜索、相似匹配
- Markdown：人工可读、版本控制友好
- ID格式：`TYPE-YYYYMMDD-XXX`

## 版本历史

- v1.0.0 (2026-04-21): 初始版本，双轨架构
