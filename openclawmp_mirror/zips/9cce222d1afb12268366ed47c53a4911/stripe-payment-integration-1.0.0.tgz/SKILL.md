---
name: stripe-payment-integration
description: Stripe integration: one-time payments, subscriptions, webhooks, refunds for SaaS
---

# Stripe Payment Integration Guide

## One-Time Payment

### Checkout Session Flow
Create Session → Redirect to Stripe → Payment complete → Webhook → Update order

## Subscription Management

### Lifecycle
Create → Trial → First charge → Auto-renew → Cancel → End date

### Billing Models
- Fixed: Standard pricing
- Tiered: Tiered pricing
- Usage-based: Per-seat + usage
- Hybrid: Combined

## Webhook Events (Must Handle)
| Event | Action |
|-------|--------|
| checkout.session.completed | Payment success |
| invoice.payment_succeeded | Renewal |
| invoice.payment_failed | Payment failed → Dunning |
| customer.subscription.deleted | Cancellation |
| charge.refunded | Refund |

### Security
- Verify webhook signatures
- Idempotent processing
- Async handling (fast 200, background logic)

## Refunds
- Partial: refund(amount=xxx)
- Full: refund()
- Auto: prorate on subscription cancel

## Best Practices
- Never store API key on client
- Use Stripe.js Elements for card data
- PCI compliance via Stripe
- HTTPS for webhook endpoints

