# 向量记忆系统 - Docker + ChromaDB 方案

基于 Docker 运行 ChromaDB 的生产级向量记忆系统。

## 🚀 快速开始

### 1. 安装 Docker（首次）

```bash
chmod +x install_docker_chroma.sh
./install_docker_chroma.sh
```

**安装内容**:
- Docker Engine
- Docker Compose
- ChromaDB 容器

### 2. 启动 ChromaDB

```bash
docker compose up -d
```

**验证**:
```bash
curl http://localhost:8000/api/v1/heartbeat
# 预期输出: {"nanosecond heartbeat": 1234567890}
```

### 3. 运行测试

```bash
python3 scripts/test_chroma_docker.py
```

**测试内容**:
- ✅ 连接测试
- ✅ 创建集合
- ✅ 添加记忆
- ✅ 搜索记忆

---

## 📦 使用示例

### 添加记忆

```bash
python3 scripts/chroma_add.py \
  --content "Ethereum $5,000 信号连续 10 轮保持高置信度 (63.5%)" \
  --type "signal" \
  --importance 5 \
  --tags "polymarket,ethereum,signal"
```

**输出**:
```
✅ 记忆已添加到 ChromaDB
   ID: mem_20260313102530_1234
   类型: signal
   重要性: 5
   标签: polymarket, ethereum, signal
```

### 搜索记忆

```bash
python3 scripts/chroma_search.py \
  --query "Ethereum 价格信号" \
  --top-k 5
```

**输出**:
```
🔍 找到 3 条相关记忆:
================================================================================

[1] 相似度: 0.892 | 重要性: 5/5
    ID: mem_20260313102530_1234
    类型: signal
    内容: Ethereum $5,000 信号连续 10 轮保持高置信度 (63.5%)...
    标签: polymarket, ethereum, signal
    时间: 2026-03-13T10:25:30
```

---

## 🏗️ 架构

```
┌─────────────────┐
│   OpenClaw      │
│   (Main Agent)  │
└────────┬────────┘
         │
         ├─→ L1 工作记忆 (上下文)
         │
         ├─→ L2 向量记忆 (ChromaDB)
         │     ├── Docker Container (Port 8000)
         │     ├── BERT Embeddings
         │     └── HNSW Index
         │
         └─→ L3 长期记忆 (MEMORY.md + EvoMap)
```

---

## 📊 对比方案

| 特性 | TF-IDF + SQLite | ChromaDB (Docker) |
|------|------------------|-------------------|
| **语义理解** | ⭐⭐⭐ (TF-IDF) | ⭐⭐⭐⭐⭐ (BERT) |
| **安装复杂度** | ⭐ (零依赖) | ⭐⭐⭐ (需 Docker) |
| **性能** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ (HNSW) |
| **搜索延迟** | ~100ms | ~50ms |
| **持久化** | SQLite 文件 | Docker Volume |
| **API** | CLI | REST API |
| **适用场景** | 轻量级 | 生产级 |

---

## 🔧 配置

### Docker Compose

```yaml
services:
  chromadb:
    image: chromadb/chroma:latest
    ports:
      - "8000:8000"
    volumes:
      - chromadb-data:/chroma/chroma
    environment:
      - ALLOW_RESET=TRUE
```

### 环境变量

```bash
# 自定义端口
export CHROMA_PORT=8000

# 自定义集合名称
export CHROMA_COLLECTION="openclaw_memory"
```

---

## 🐛 故障排查

### 问题 1: Docker 未启动

```bash
# 检查 Docker 状态
sudo systemctl status docker

# 启动 Docker
sudo systemctl start docker
```

### 问题 2: 端口被占用

```bash
# 检查端口占用
lsof -i :8000

# 修改 docker-compose.yml 中的端口
ports:
  - "8001:8000"  # 改为 8001
```

### 问题 3: 容器无法启动

```bash
# 查看日志
docker compose logs chromadb

# 重启容器
docker compose restart chromadb

# 重新创建容器
docker compose down
docker compose up -d
```

---

## 📚 相关资源

- **ChromaDB 文档**: https://docs.trychroma.com/
- **Docker 文档**: https://docs.docker.com/
- **集成测试**: `scripts/test_chroma_docker.py`
- **添加脚本**: `scripts/chroma_add.py`
- **搜索脚本**: `scripts/chroma_search.py`

---

**安装时间**: 2026-03-13
**维护者**: Chaotang (node_chaotang_1773048216)
