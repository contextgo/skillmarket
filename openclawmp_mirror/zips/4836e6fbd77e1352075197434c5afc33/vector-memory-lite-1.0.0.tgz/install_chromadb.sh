#!/bin/bash
# ChromaDB 向量记忆系统安装脚本
# 
# 用法:
#   chmod +x install_chromadb.sh
#   ./install_chromadb.sh

set -e

echo "🚀 ChromaDB 向量记忆系统安装脚本"
echo "=================================="

# 检查 pip
if ! command -v pip3 &> /dev/null && ! command -v pip &> /dev/null; then
    echo "❌ 错误: pip 未安装"
    echo ""
    echo "请先安装 pip:"
    echo "  Ubuntu/Debian: sudo apt-get install python3-pip python3-venv"
    echo "  macOS: brew install python3"
    echo "  Windows: python -m ensurepip"
    exit 1
fi

# 选择 pip 命令
if command -v pip3 &> /dev/null; then
    PIP_CMD="pip3"
else
    PIP_CMD="pip"
fi

echo "✅ 使用 $PIP_CMD"

# 检查虚拟环境
if [[ "$VIRTUAL_ENV" == "" ]]; then
    echo "⚠️  未在虚拟环境中"
    echo ""
    read -p "是否创建虚拟环境? (y/N): " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        VENV_DIR="$HOME/.openclaw/vector-memory-venv"
        echo "📦 创建虚拟环境: $VENV_DIR"
        python3 -m venv "$VENV_DIR"
        source "$VENV_DIR/bin/activate"
        PIP_CMD="$VENV_DIR/bin/pip"
        echo "✅ 虚拟环境已激活"
    else
        echo "⚠️  将安装到用户目录 (--user)"
        PIP_CMD="$PIP_CMD install --user"
    fi
fi

# 安装依赖
echo ""
echo "📦 安装依赖包..."
echo "  - chromadb"
echo "  - sentence-transformers"
echo "  - numpy"
echo ""

$PIP_CMD install --upgrade chromadb sentence-transformers numpy

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ 安装成功!"
    echo ""
    echo "📝 下一步:"
    echo "  1. 运行测试: python3 scripts/test_chromadb.py"
    echo "  2. 添加记忆: python3 scripts/chroma_add.py --content '...' "
    echo "  3. 搜索记忆: python3 scripts/chroma_search.py --query '...' "
    echo ""
    echo "📚 文档: https://docs.trychroma.com/"
else
    echo ""
    echo "❌ 安装失败"
    echo "   请检查网络连接和 pip 权限"
    exit 1
fi
