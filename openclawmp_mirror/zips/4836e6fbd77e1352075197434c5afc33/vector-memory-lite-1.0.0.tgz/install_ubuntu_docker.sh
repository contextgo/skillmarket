#!/bin/bash
# Ubuntu Docker + ChromaDB 一键安装脚本
#
# 用法:
#   chmod +x install_ubuntu_docker.sh
#   ./install_ubuntu_docker.sh

set -e

echo "🐳 Ubuntu Docker + ChromaDB 安装脚本"
echo "======================================"
echo ""

# 检查是否为 root
if [ "$EUID" -ne 0 ]; then
    echo "⚠️  需要 sudo 权限"
    echo "   请使用: sudo ./install_ubuntu_docker.sh"
    exit 1
fi

# 检查 Docker
if command -v docker &> /dev/null; then
    echo "✅ Docker 已安装"
    docker --version
    echo ""
else
    echo "📦 安装 Docker..."
    echo ""
    
    # 1. 更新包索引
    echo "[1/7] 更新包索引..."
    apt-get update
    
    # 2. 安装依赖
    echo "[2/7] 安装依赖..."
    apt-get install -y \
        ca-certificates \
        curl \
        gnupg \
        lsb-release
    
    # 3. 添加 Docker GPG key
    echo "[3/7] 添加 Docker GPG key..."
    mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    
    # 4. 添加 Docker 仓库
    echo "[4/7] 添加 Docker 仓库..."
    echo \
        "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # 5. 安装 Docker
    echo "[5/7] 安装 Docker..."
    apt-get update
    apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    
    # 6. 启动 Docker
    echo "[6/7] 启动 Docker 服务..."
    systemctl start docker
    systemctl enable docker
    
    # 7. 添加当前用户到 docker 组
    echo "[7/7] 添加用户到 docker 组..."
    CURRENT_USER=${SUDO_USER:-$USER}
    usermod -aG docker $CURRENT_USER
    
    echo ""
    echo "✅ Docker 安装完成"
    echo ""
fi

# 检查 Docker Compose
echo "📦 检查 Docker Compose..."
if docker compose version &> /dev/null; then
    echo "✅ Docker Compose 已安装"
    docker compose version
    echo ""
else
    echo "❌ Docker Compose 未安装"
    exit 1
fi

# 启动 ChromaDB
echo "🚀 启动 ChromaDB..."
cd "$(dirname "$0")"

if [ -f docker-compose.yml ]; then
    docker compose up -d
    
    echo ""
    echo "✅ ChromaDB 已启动"
    echo ""
    echo "📊 查看状态:"
    echo "   docker compose ps"
    echo ""
    echo "🔍 查看日志:"
    echo "   docker compose logs -f chromadb"
    echo ""
    echo "🛑 停止服务:"
    echo "   docker compose down"
    echo ""
    echo "🌐 API 端点:"
    echo "   http://localhost:8000"
    echo "   http://localhost:8000/api/v1/heartbeat (健康检查)"
    echo ""
    
    # 等待 ChromaDB 启动
    echo "⏳ 等待 ChromaDB 启动（约 30 秒）..."
    sleep 30
    
    # 测试连接
    echo ""
    echo "🧪 测试连接..."
    if curl -s http://localhost:8000/api/v1/heartbeat > /dev/null; then
        echo "✅ ChromaDB 连接成功"
    else
        echo "⚠️  ChromaDB 可能还在启动中，请稍后再试"
        echo "   手动测试: curl http://localhost:8000/api/v1/heartbeat"
    fi
else
    echo "❌ docker-compose.yml 未找到"
    exit 1
fi

echo ""
echo "📝 下一步:"
echo "  1. 注销并重新登录（应用 docker 组权限）"
echo "  2. 测试连接: curl http://localhost:8000/api/v1/heartbeat"
echo "  3. 运行集成测试: python3 scripts/test_chroma_docker.py"
echo "  4. 添加记忆: python3 scripts/chroma_add.py --content '...'"
echo ""
echo "✅ 安装完成！"
