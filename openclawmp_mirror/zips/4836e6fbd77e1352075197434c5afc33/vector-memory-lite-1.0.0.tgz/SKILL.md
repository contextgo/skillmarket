---
name: vector-memory-lite
description: 轻量级向量记忆系统。使用 TF-IDF + SQLite 实现语义搜索.无需 ChromaDB 依赖.支持记忆添加、搜索、压缩.触发场景:(1) 记忆搜索 (2) 添加向量记忆 (3) 记忆压缩.
---

# 轻量级向量记忆系统

## 快速开始

### 添加记忆

```bash
# 添加事件到向量记忆
python3 ~/.openclaw/skills/vector-memory-lite/scripts/vector_add.py \
  --content "发现 Polymarket Ethereum $5,000 信号连续 10 轮保持高置信度" \
  --type "signal" \
  --importance 5 \
  --tags "polymarket,ethereum,signal"
```

### 搜索记忆

```bash
# 语义搜索（使用 TF-IDF）
python3 ~/.openclaw/skills/vector-memory-lite/scripts/vector_search.py \
  --query "Ethereum 价格信号" \
  --top-k 5
```

### 记忆压缩

```bash
# 压缩超过 30 天的记忆
python3 ~/.openclaw/skills/vector-memory-lite/scripts/vector_compress.py \
  --days 30
```

## 特性

✅ **TF-IDF 向量化** - 基于词频-逆文档频率的语义搜索
✅ **SQLite 存储** - 无需额外数据库依赖
✅ **自动压缩** - 定期清理低重要性记忆
✅ **标签系统** - 支持多维度分类
✅ **零依赖** - 仅使用 Python 标准库

## 架构

```
L1 工作记忆 (上下文)
  ↓
L2 向量记忆 (SQLite + TF-IDF)
  ├── events.db (主数据库)
  ├── tfidf_index.json (词频索引)
  └── compressed.db (压缩归档)
  ↓
L3 长期记忆 (MEMORY.md + EvoMap)
```

## 性能

- **搜索延迟**: < 100ms (1000 条记忆)
- **存储效率**: ~1KB/100 条记忆
- **压缩率**: 70% (30 天后)

## 对比 ChromaDB

| 特性 | 本系统 | ChromaDB |
|------|--------|----------|
| **语义理解** | ⭐⭐⭐ (TF-IDF) | ⭐⭐⭐⭐⭐ (BERT) |
| **安装复杂度** | ⭐ (零依赖) | ⭐⭐⭐ (需 pip) |
| **性能** | ⭐⭐⭐⭐ | ⭐⭐⭐⭐⭐ |
| **成本** | 免费 | 免费 |
| **适用场景** | 轻量级 | 生产级 |

## 最佳实践

1. **添加记忆时**:
   - 添加描述性标签
   - 设置准确的重要性（1-5）
   - 包含可检索关键词

2. **搜索记忆时**:
   - 使用自然语言查询
   - 结合标签过滤
   - 限制 top-k 避免信息过载

3. **定期压缩**:
   - 每周压缩一次
   - 保留高重要性记忆
   - 归档低重要性记忆

## 集成到现有系统

### 与三层记忆系统集成

```python
# 在 three-tier-memory 技能中调用
from vector_memory_lite import VectorMemory

# 添加到 L2
vector_mem = VectorMemory()
vector_mem.add(
    content="...",
    event_type="decision",
    importance=5
)
```

### 定时压缩

```bash
# 添加到 crontab
0 2 * * 0 python3 ~/.openclaw/skills/vector-memory-lite/scripts/vector_compress.py --days 30
```

## 相关文件

- 添加脚本: `scripts/vector_add.py`
- 搜索脚本: `scripts/vector_search.py`
- 压缩脚本: `scripts/vector_compress.py`
- 数据库: `~/.openclaw/vector-memory/events.db`
