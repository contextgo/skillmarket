#!/usr/bin/env python3
"""
ChromaDB 向量记忆 - 搜索记忆

用法:
    python3 chroma_search.py --query "Ethereum 信号" --top-k 5
    python3 chroma_search.py --query "错误" --type "error" --top-k 10
"""

import argparse
import json
import sys

try:
    import requests
except ImportError:
    print("❌ 缺少依赖: requests")
    print("   安装: python3 -m pip install --user requests")
    sys.exit(1)

CHROMA_HOST = "http://localhost:8000"
COLLECTION_NAME = "openclaw_memory"


def search_memory(query, event_type=None, top_k=5):
    """搜索 ChromaDB 中的记忆"""
    
    url = f"{CHROMA_HOST}/api/v1/collections/{COLLECTION_NAME}/query"
    
    payload = {
        "query_texts": [query],
        "n_results": top_k
    }
    
    # 添加元数据过滤
    if event_type:
        payload["where"] = {"type": event_type}
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            if not data['ids'][0]:
                print("❌ 没有找到匹配的记忆")
                return
            
            print(f"\n🔍 找到 {len(data['ids'][0])} 条相关记忆:")
            print("=" * 80)
            
            for i, (id_, doc, metadata, distance) in enumerate(zip(
                data['ids'][0],
                data['documents'][0],
                data['metadatas'][0],
                data['distances'][0]
            ), 1):
                similarity = 1 - distance  # 转换为相似度
                importance = metadata.get('importance', 3)
                
                print(f"\n[{i}] 相似度: {similarity:.3f} | 重要性: {importance}/5")
                print(f"    ID: {id_}")
                print(f"    类型: {metadata.get('type')}")
                print(f"    内容: {doc[:100]}...")
                
                tags = metadata.get('tags', '')
                if tags:
                    print(f"    标签: {tags}")
                
                created_at = metadata.get('created_at', '')
                if created_at:
                    print(f"    时间: {created_at[:19]}")
        else:
            print(f"❌ 搜索失败: {response.status_code} - {response.text}")
    except requests.exceptions.ConnectionError:
        print("❌ 无法连接到 ChromaDB")
        print("   请确保 Docker 容器已启动:")
        print("   docker compose up -d")
    except Exception as e:
        print(f"❌ 搜索失败: {e}")


def main():
    parser = argparse.ArgumentParser(description="搜索 ChromaDB 记忆")
    parser.add_argument("--query", required=True, help="搜索查询")
    parser.add_argument("--type", help="事件类型过滤")
    parser.add_argument("--top-k", type=int, default=5, help="返回结果数量")
    
    args = parser.parse_args()
    
    search_memory(
        query=args.query,
        event_type=args.type,
        top_k=args.top_k
    )


if __name__ == "__main__":
    main()
