#!/usr/bin/env python3
"""
ChromaDB 向量记忆 - 添加记忆

用法:
    python3 chroma_add.py --content "..." --type "signal" --importance 5 --tags "tag1,tag2"
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

try:
    import requests
except ImportError:
    print("❌ 缺少依赖: requests")
    print("   安装: python3 -m pip install --user requests")
    sys.exit(1)

CHROMA_HOST = "http://localhost:8000"
COLLECTION_NAME = "openclaw_memory"


def ensure_collection():
    """确保集合存在"""
    url = f"{CHROMA_HOST}/api/v1/collections"
    
    try:
        # 尝试获取集合
        response = requests.get(f"{url}/{COLLECTION_NAME}", timeout=5)
        
        if response.status_code == 200:
            return True
        
        # 集合不存在，创建它
        payload = {
            "name": COLLECTION_NAME,
            "metadata": {
                "description": "OpenClaw 向量记忆系统",
                "created_at": datetime.now().isoformat()
            }
        }
        
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code in [200, 201]:
            print(f"✅ 集合 '{COLLECTION_NAME}' 已创建")
            return True
        else:
            print(f"❌ 创建集合失败: {response.status_code}")
            return False
    except Exception as e:
        print(f"❌ 连接失败: {e}")
        return False


def add_memory(content, event_type="event", importance=3, tags=None):
    """添加记忆到 ChromaDB"""
    
    # 确保集合存在
    if not ensure_collection():
        return None
    
    # 生成 ID
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    memory_id = f"mem_{timestamp}_{hash(content) % 10000:04d}"
    
    # 准备元数据
    metadata = {
        "type": event_type,
        "importance": importance,
        "tags": ",".join(tags) if tags else "",
        "created_at": datetime.now().isoformat()
    }
    
    # 添加到 ChromaDB
    url = f"{CHROMA_HOST}/api/v1/collections/{COLLECTION_NAME}/add"
    
    payload = {
        "ids": [memory_id],
        "documents": [content],
        "metadatas": [metadata]
    }
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code in [200, 201]:
            print(f"✅ 记忆已添加到 ChromaDB")
            print(f"   ID: {memory_id}")
            print(f"   类型: {event_type}")
            print(f"   重要性: {importance}")
            if tags:
                print(f"   标签: {', '.join(tags)}")
            return memory_id
        else:
            print(f"❌ 添加失败: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"❌ 添加失败: {e}")
        return None


def main():
    parser = argparse.ArgumentParser(description="添加记忆到 ChromaDB")
    parser.add_argument("--content", required=True, help="记忆内容")
    parser.add_argument("--type", default="event", help="事件类型")
    parser.add_argument("--importance", type=int, default=3, help="重要性 (1-5)")
    parser.add_argument("--tags", help="标签（逗号分隔）")
    
    args = parser.parse_args()
    
    # 解析标签
    tags = [t.strip() for t in args.tags.split(",")] if args.tags else None
    
    # 添加记忆
    add_memory(
        content=args.content,
        event_type=args.type,
        importance=args.importance,
        tags=tags
    )


if __name__ == "__main__":
    main()
