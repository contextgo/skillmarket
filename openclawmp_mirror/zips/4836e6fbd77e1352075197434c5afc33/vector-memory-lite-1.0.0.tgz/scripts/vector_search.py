#!/usr/bin/env python3
"""
轻量级向量记忆系统 - 搜索记忆

用法:
    python3 vector_search.py --query "Ethereum 信号" --top-k 5
    python3 vector_search.py --query "错误" --type "error" --top-k 10
"""

import argparse
import sqlite3
import json
import os
from pathlib import Path
from collections import Counter
import math

WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", Path.home() / ".openclaw" / "workspace"))
VECTOR_DIR = WORKSPACE / ".vector-memory"
DB_PATH = VECTOR_DIR / "events.db"
TFIDF_PATH = VECTOR_DIR / "tfidf_index.json"


class TFIDFVectorizer:
    """简单的 TF-IDF 向量化器"""
    
    def __init__(self):
        self.doc_count = 0
        self.word_doc_count = Counter()
        self.load_index()
    
    def load_index(self):
        """加载 TF-IDF 索引"""
        if TFIDF_PATH.exists():
            with open(TFIDF_PATH) as f:
                data = json.load(f)
                self.doc_count = data.get("doc_count", 0)
                self.word_doc_count = Counter(data.get("word_doc_count", {}))
    
    def tokenize(self, text):
        """简单分词"""
        words = text.lower().split()
        words = [w.strip(".,!?;:\"'()[]{}") for w in words]
        stopwords = {"的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一", "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着", "没有", "看", "好的", "the", "a", "an", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does", "did", "will", "would", "could", "should", "may", "might", "must", "shall", "can", "need", "dare", "ought", "used", "to", "of", "in", "for", "on", "with", "at", "by", "from", "as", "into", "through", "during", "before", "after", "above", "below", "between", "under", "again", "further", "then", "once"}
        return [w for w in words if w and w not in stopwords and len(w) > 1]
    
    def compute_tfidf(self, text):
        """计算 TF-IDF 向量"""
        words = self.tokenize(text)
        if not words:
            return {}
        
        word_count = Counter(words)
        total_words = len(words)
        tf = {word: count / total_words for word, count in word_count.items()}
        
        tfidf = {}
        for word, tf_value in tf.items():
            doc_freq = self.word_doc_count.get(word, 0) + 1
            idf = math.log((self.doc_count + 1) / doc_freq) + 1
            tfidf[word] = tf_value * idf
        
        return tfidf


def cosine_similarity(vec1, vec2):
    """计算余弦相似度"""
    # 获取所有词汇
    all_words = set(vec1.keys()) | set(vec2.keys())
    
    if not all_words:
        return 0.0
    
    # 计算点积和模
    dot_product = sum(vec1.get(word, 0) * vec2.get(word, 0) for word in all_words)
    norm1 = math.sqrt(sum(v ** 2 for v in vec1.values()))
    norm2 = math.sqrt(sum(v ** 2 for v in vec2.values()))
    
    if norm1 == 0 or norm2 == 0:
        return 0.0
    
    return dot_product / (norm1 * norm2)


def search(query, event_type=None, top_k=5, days=None):
    """搜索记忆"""
    # 计算查询向量
    tfidf = TFIDFVectorizer()
    query_vector = tfidf.compute_tfidf(query)
    
    # 从数据库加载记忆
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    sql = "SELECT id, type, content, importance, tags, tfidf_vector, created_at FROM vector_events WHERE compressed_at IS NULL"
    params = []
    
    if event_type:
        sql += " AND type = ?"
        params.append(event_type)
    
    if days:
        sql += " AND created_at >= datetime('now', ?)"
        params.append(f"-{days} days")
    
    sql += " ORDER BY importance DESC"
    
    cursor.execute(sql, params)
    results = cursor.fetchall()
    conn.close()
    
    # 计算相似度
    scored_results = []
    for row in results:
        event_id, type_, content, importance, tags, tfidf_json, created_at = row

        
        if tfidf_json:
            stored_vector = json.loads(tfidf_json)
            similarity = cosine_similarity(query_vector, stored_vector)
        else:
            similarity = 0.0
        
        scored_results.append({
            "id": event_id,
            "type": type_,
            "content": content,
            "importance": importance,
            "tags": json.loads(tags) if tags else [],
            "similarity": similarity,
            "created_at": created_at
        })
    
    # 排序并返回 top-k
    scored_results.sort(key=lambda x: (x["similarity"], x["importance"]), reverse=True)
    
    return scored_results[:top_k]


def main():
    parser = argparse.ArgumentParser(description="搜索向量记忆")
    parser.add_argument("--query", required=True, help="搜索查询")
    parser.add_argument("--type", help="事件类型过滤")
    parser.add_argument("--top-k", type=int, default=5, help="返回结果数量")
    parser.add_argument("--days", type=int, help="搜索天数范围")
    
    args = parser.parse_args()
    
    # 执行搜索
    results = search(
        query=args.query,
        event_type=args.type,
        top_k=args.top_k,
        days=args.days
    )
    
    if not results:
        print("❌ 没有找到匹配的记忆")
        return
    
    print(f"\n🔍 找到 {len(results)} 条相关记忆:")
    print("=" * 80)
    
    for i, result in enumerate(results, 1):
        print(f"\n[{i}] 相似度: {result['similarity']:.3f} | 重要性: {result['importance']}/5")
        print(f"    类型: {result['type']}")
        print(f"    内容: {result['content'][:100]}...")
        if result['tags']:
            print(f"    标签: {', '.join(result['tags'])}")
        print(f"    时间: {result['created_at']}")


if __name__ == "__main__":
    main()
