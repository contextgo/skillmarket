#!/usr/bin/env python3
"""
轻量级向量记忆系统 - 添加记忆

用法:
    python3 vector_add.py --content "..." --type "decision" --importance 5 --tags "tag1,tag2"
"""

import argparse
import sqlite3
import json
import os
from datetime import datetime
from pathlib import Path
from collections import Counter
import math

WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", Path.home() / ".openclaw" / "workspace"))
VECTOR_DIR = WORKSPACE / ".vector-memory"
DB_PATH = VECTOR_DIR / "events.db"
TFIDF_PATH = VECTOR_DIR / "tfidf_index.json"


class TFIDFVectorizer:
    """简单的 TF-IDF 向量化器"""
    
    def __init__(self):
        self.doc_count = 0
        self.word_doc_count = Counter()
        self.load_index()
    
    def load_index(self):
        """加载 TF-IDF 索引"""
        if TFIDF_PATH.exists():
            with open(TFIDF_PATH) as f:
                data = json.load(f)
                self.doc_count = data.get("doc_count", 0)
                self.word_doc_count = Counter(data.get("word_doc_count", {}))
    
    def save_index(self):
        """保存 TF-IDF 索引"""
        VECTOR_DIR.mkdir(parents=True, exist_ok=True)
        with open(TFIDF_PATH, "w") as f:
            json.dump({
                "doc_count": self.doc_count,
                "word_doc_count": dict(self.word_doc_count)
            }, f)
    
    def tokenize(self, text):
        """简单分词（基于空格和标点）"""
        # 转小写 + 分词
        words = text.lower().split()
        # 移除标点
        words = [w.strip(".,!?;:\"'()[]{}") for w in words]
        # 过滤停用词（简单版本）
        stopwords = {"的", "了", "在", "是", "我", "有", "和", "就", "不", "人", "都", "一", "一个", "上", "也", "很", "到", "说", "要", "去", "你", "会", "着", "没有", "看", "好的", "the", "a", "an", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does", "did", "will", "would", "could", "should", "may", "might", "must", "shall", "can", "need", "dare", "ought", "used", "to", "of", "in", "for", "on", "with", "at", "by", "from", "as", "into", "through", "during", "before", "after", "above", "below", "between", "under", "again", "further", "then", "once"}
        return [w for w in words if w and w not in stopwords and len(w) > 1]
    
    def compute_tfidf(self, text):
        """计算 TF-IDF 向量"""
        words = self.tokenize(text)
        if not words:
            return {}
        
        # TF (词频)
        word_count = Counter(words)
        total_words = len(words)
        tf = {word: count / total_words for word, count in word_count.items()}
        
        # IDF (逆文档频率)
        tfidf = {}
        for word, tf_value in tf.items():
            doc_freq = self.word_doc_count.get(word, 0) + 1  # +1 避免除零
            idf = math.log((self.doc_count + 1) / doc_freq) + 1
            tfidf[word] = tf_value * idf
        
        return tfidf
    
    def update_index(self, text):
        """更新 TF-IDF 索引"""
        words = set(self.tokenize(text))
        for word in words:
            self.word_doc_count[word] += 1
        self.doc_count += 1
        self.save_index()


class VectorMemory:
    """向量记忆系统"""
    
    def __init__(self):
        self.tfidf = TFIDFVectorizer()
        self.init_db()
    
    def init_db(self):
        """初始化数据库"""
        VECTOR_DIR.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS vector_events (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                type TEXT NOT NULL,
                content TEXT NOT NULL,
                importance INTEGER DEFAULT 3,
                tags TEXT,
                tfidf_vector TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                compressed_at TIMESTAMP
            )
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_type ON vector_events(type)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_importance ON vector_events(importance)
        """)
        
        cursor.execute("""
            CREATE INDEX IF NOT EXISTS idx_created_at ON vector_events(created_at)
        """)
        
        conn.commit()
        conn.close()
    
    def add(self, content, event_type="event", importance=3, tags=None):
        """添加记忆"""
        # 计算 TF-IDF 向量
        tfidf_vector = self.tfidf.compute_tfidf(content)
        
        # 更新索引
        self.tfidf.update_index(content)
        
        # 存储到数据库
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()
        
        cursor.execute("""
            INSERT INTO vector_events (type, content, importance, tags, tfidf_vector)
            VALUES (?, ?, ?, ?, ?)
        """, (
            event_type,
            content,
            importance,
            json.dumps(tags) if tags else None,
            json.dumps(tfidf_vector)
        ))
        
        event_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return event_id


def main():
    parser = argparse.ArgumentParser(description="添加向量记忆")
    parser.add_argument("--content", required=True, help="记忆内容")
    parser.add_argument("--type", default="event", help="事件类型")
    parser.add_argument("--importance", type=int, default=3, help="重要性 (1-5)")
    parser.add_argument("--tags", help="标签（逗号分隔）")
    
    args = parser.parse_args()
    
    # 解析标签
    tags = [t.strip() for t in args.tags.split(",")] if args.tags else None
    
    # 添加记忆
    memory = VectorMemory()
    event_id = memory.add(
        content=args.content,
        event_type=args.type,
        importance=args.importance,
        tags=tags
    )
    
    print(f"✅ 记忆已添加 (ID: {event_id})")
    print(f"   类型: {args.type}")
    print(f"   重要性: {args.importance}")
    if tags:
        print(f"   标签: {', '.join(tags)}")


if __name__ == "__main__":
    main()
