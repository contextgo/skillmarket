#!/usr/bin/env python3
"""
ChromaDB Docker 集成测试

用法:
    python3 test_chroma_docker.py
"""

import json
import sys
from pathlib import Path

# 检查依赖
try:
    import requests
except ImportError:
    print("❌ 缺少依赖: requests")
    print("   安装: python3 -m pip install --user requests")
    sys.exit(1)

CHROMA_HOST = "http://localhost:8000"


def test_connection():
    """测试 ChromaDB 连接"""
    print("🔍 测试 ChromaDB 连接...")
    
    try:
        response = requests.get(f"{CHROMA_HOST}/api/v1/heartbeat", timeout=5)
        if response.status_code == 200:
            print("✅ ChromaDB 连接成功")
            return True
        else:
            print(f"❌ ChromaDB 返回错误: {response.status_code}")
            return False
    except requests.exceptions.ConnectionError:
        print("❌ 无法连接到 ChromaDB")
        print("   请确保 Docker 容器已启动:")
        print("   docker compose up -d")
        return False
    except Exception as e:
        print(f"❌ 连接失败: {e}")
        return False


def test_create_collection():
    """测试创建集合"""
    print("\n📦 测试创建集合...")
    
    collection_name = "test_memory"
    
    # 创建集合
    url = f"{CHROMA_HOST}/api/v1/collections"
    payload = {
        "name": collection_name,
        "metadata": {"description": "测试记忆集合"}
    }
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code in [200, 201]:
            print(f"✅ 集合 '{collection_name}' 创建成功")
            return collection_name
        elif response.status_code == 409:
            print(f"ℹ️  集合 '{collection_name}' 已存在")
            return collection_name
        else:
            print(f"❌ 创建失败: {response.status_code} - {response.text}")
            return None
    except Exception as e:
        print(f"❌ 创建失败: {e}")
        return None


def test_add_memory(collection_name):
    """测试添加记忆"""
    print("\n💾 测试添加记忆...")
    
    url = f"{CHROMA_HOST}/api/v1/collections/{collection_name}/add"
    
    memories = [
        {
            "id": "mem_1",
            "text": "Ethereum $5,000 信号连续 10 轮保持高置信度",
            "metadata": {"type": "signal", "importance": 5}
        },
        {
            "id": "mem_2",
            "text": "代理服务连续 6 次失败，导致任务阻塞",
            "metadata": {"type": "error", "importance": 4}
        }
    ]
    
    for memory in memories:
        payload = {
            "ids": [memory["id"]],
            "documents": [memory["text"]],
            "metadatas": [memory["metadata"]]
        }
        
        try:
            response = requests.post(url, json=payload, timeout=10)
            
            if response.status_code in [200, 201]:
                print(f"✅ 记忆已添加: {memory['id']}")
            else:
                print(f"❌ 添加失败: {response.status_code} - {response.text}")
        except Exception as e:
            print(f"❌ 添加失败: {e}")


def test_search_memory(collection_name):
    """测试搜索记忆"""
    print("\n🔍 测试搜索记忆...")
    
    url = f"{CHROMA_HOST}/api/v1/collections/{collection_name}/query"
    
    payload = {
        "query_texts": ["Ethereum 价格信号"],
        "n_results": 3
    }
    
    try:
        response = requests.post(url, json=payload, timeout=10)
        
        if response.status_code == 200:
            data = response.json()
            
            print(f"✅ 找到 {len(data['ids'][0])} 条相关记忆:")
            
            for i, (id_, doc, metadata, distance) in enumerate(zip(
                data['ids'][0],
                data['documents'][0],
                data['metadatas'][0],
                data['distances'][0]
            ), 1):
                similarity = 1 - distance  # 转换为相似度
                print(f"\n[{i}] 相似度: {similarity:.3f}")
                print(f"    ID: {id_}")
                print(f"    内容: {doc[:60]}...")
                print(f"    类型: {metadata.get('type')}")
                print(f"    重要性: {metadata.get('importance')}")
        else:
            print(f"❌ 搜索失败: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ 搜索失败: {e}")


def main():
    print("🧪 ChromaDB Docker 集成测试")
    print("=" * 50)
    
    # 1. 测试连接
    if not test_connection():
        sys.exit(1)
    
    # 2. 测试创建集合
    collection_name = test_create_collection()
    if not collection_name:
        sys.exit(1)
    
    # 3. 测试添加记忆
    test_add_memory(collection_name)
    
    # 4. 测试搜索记忆
    test_search_memory(collection_name)
    
    print("\n" + "=" * 50)
    print("✅ 所有测试通过！ChromaDB Docker 集成正常工作")


if __name__ == "__main__":
    main()
