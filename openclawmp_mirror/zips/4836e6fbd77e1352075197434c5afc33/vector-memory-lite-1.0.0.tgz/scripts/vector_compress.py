#!/usr/bin/env python3
"""
轻量级向量记忆系统 - 压缩记忆

用法:
    python3 vector_compress.py --days 30
"""

import argparse
import sqlite3
import json
import os
from datetime import datetime, timedelta
from pathlib import Path

WORKSPACE = Path(os.environ.get("OPENCLAW_WORKSPACE", Path.home() / ".openclaw" / "workspace"))
VECTOR_DIR = WORKSPACE / ".vector-memory"
DB_PATH = VECTOR_DIR / "events.db"
COMPRESSED_PATH = VECTOR_DIR / "compressed.db"


def compress(days=30):
    """压缩超过指定天数的低重要性记忆"""
    if not DB_PATH.exists():
        print("❌ 记忆数据库不存在")
        return
    
    # 初始化压缩数据库
    conn_main = sqlite3.connect(DB_PATH)
    conn_compressed = sqlite3.connect(COMPRESSED_PATH)
    
    cursor_main = conn_main.cursor()
    cursor_compressed = conn_compressed.cursor()
    
    # 创建压缩表
    cursor_compressed.execute("""
        CREATE TABLE IF NOT EXISTS compressed_events (
            id INTEGER PRIMARY KEY,
            original_id INTEGER,
            type TEXT,
            content TEXT,
            importance INTEGER,
            tags TEXT,
            created_at TIMESTAMP,
            compressed_at TIMESTAMP
        )
    """)
    
    # 查找需要压缩的记忆
    threshold_date = (datetime.now() - timedelta(days=days)).isoformat()
    
    cursor_main.execute("""
        SELECT id, type, content, importance, tags, created_at
        FROM vector_events
        WHERE created_at < ?
        AND importance <= 3
        AND compressed_at IS NULL
    """, (threshold_date,))
    
    to_compress = cursor_main.fetchall()
    
    if not to_compress:
        print(f"✅ 没有需要压缩的记忆（{days} 天前，重要性 <= 3）")
        conn_main.close()
        conn_compressed.close()
        return
    
    # 压缩记忆
    compressed_count = 0
    for row in to_compress:
        event_id, type_, content, importance, tags, created_at = row
        
        # 移动到压缩数据库
        cursor_compressed.execute("""
            INSERT INTO compressed_events (original_id, type, content, importance, tags, created_at, compressed_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (event_id, type_, content, importance, tags, created_at, datetime.now().isoformat()))
        
        # 标记为已压缩
        cursor_main.execute("""
            UPDATE vector_events
            SET compressed_at = ?
            WHERE id = ?
        """, (datetime.now().isoformat(), event_id))
        
        compressed_count += 1
    
    conn_main.commit()
    conn_compressed.commit()
    conn_main.close()
    conn_compressed.close()
    
    print(f"✅ 已压缩 {compressed_count} 条记忆")
    print(f"   压缩条件: {days} 天前, 重要性 <= 3")
    print(f"   压缩后存储: {COMPRESSED_PATH}")


def main():
    parser = argparse.ArgumentParser(description="压缩向量记忆")
    parser.add_argument("--days", type=int, default=30, help="压缩超过多少天的记忆")
    
    args = parser.parse_args()
    
    compress(days=args.days)


if __name__ == "__main__":
    main()
