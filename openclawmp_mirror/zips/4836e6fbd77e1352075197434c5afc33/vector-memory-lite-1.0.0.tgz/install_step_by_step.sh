#!/bin/bash
# Ubuntu Docker 分步安装脚本（用户友好版）
#
# 这个脚本会分步执行，每一步都有清晰的输出

set -e

echo "🚀 Ubuntu Docker + ChromaDB 分步安装"
echo "======================================"
echo ""

# 步骤 1: 更新包索引
echo "📦 [步骤 1/9] 更新包索引..."
echo "   命令: sudo apt-get update"
echo ""
read -p "按 Enter 继续..."

sudo apt-get update

echo ""
echo "✅ 步骤 1 完成"
echo ""
sleep 2

# 步骤 2: 安装依赖
echo "📦 [步骤 2/9] 安装依赖..."
echo "   命令: sudo apt-get install -y ca-certificates curl gnupg lsb-release"
echo ""
read -p "按 Enter 继续..."

sudo apt-get install -y ca-certificates curl gnupg lsb-release

echo ""
echo "✅ 步骤 2 完成"
echo ""
sleep 2

# 步骤 3: 添加 Docker GPG key
echo "📦 [步骤 3/9] 添加 Docker GPG key..."
echo "   命令: curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg"
echo ""
read -p "按 Enter 继续..."

sudo mkdir -p /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg

echo ""
echo "✅ 步骤 3 完成"
echo ""
sleep 2

# 步骤 4: 添加 Docker 仓库
echo "📦 [步骤 4/9] 添加 Docker 仓库..."
echo "   命令: echo 'deb [arch=...]' | sudo tee /etc/apt/sources.list.d/docker.list"
echo ""
read -p "按 Enter 继续..."

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
  $(lsb_release -cs) stable" | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

echo ""
echo "✅ 步骤 4 完成"
echo ""
sleep 2

# 步骤 5: 更新包索引（包含 Docker 仓库）
echo "📦 [步骤 5/9] 更新包索引（包含 Docker 仓库）..."
echo "   命令: sudo apt-get update"
echo ""
read -p "按 Enter 继续..."

sudo apt-get update

echo ""
echo "✅ 步骤 5 完成"
echo ""
sleep 2

# 步骤 6: 安装 Docker
echo "📦 [步骤 6/9] 安装 Docker..."
echo "   命令: sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin"
echo ""
echo "⚠️  这一步会下载约 500MB 数据，需要几分钟"
read -p "按 Enter 继续..."

sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

echo ""
echo "✅ 步骤 6 完成"
echo ""
sleep 2

# 步骤 7: 启动 Docker
echo "🚀 [步骤 7/9] 启动 Docker 服务..."
echo "   命令: sudo systemctl start docker && sudo systemctl enable docker"
echo ""
read -p "按 Enter 继续..."

sudo systemctl start docker
sudo systemctl enable docker

echo ""
echo "✅ 步骤 7 完成"
echo ""
sleep 2

# 步骤 8: 添加用户到 docker 组
echo "👤 [步骤 8/9] 添加用户到 docker 组..."
echo "   命令: sudo usermod -aG docker $USER"
echo ""
read -p "按 Enter 继续..."

sudo usermod -aG docker $USER

echo ""
echo "✅ 步骤 8 完成"
echo ""
sleep 2

# 步骤 9: 启动 ChromaDB
echo "🚀 [步骤 9/9] 启动 ChromaDB..."
echo "   命令: docker compose up -d"
echo ""
read -p "按 Enter 继续..."

cd "$(dirname "$0")"
docker compose up -d

echo ""
echo "✅ 步骤 9 完成"
echo ""
sleep 5

# 测试连接
echo "🧪 测试 ChromaDB 连接..."
if curl -s http://localhost:8000/api/v1/heartbeat > /dev/null 2>&1; then
    echo "✅ ChromaDB 连接成功！"
    echo ""
    echo "📊 查看状态:"
    echo "   docker compose ps"
    echo ""
    echo "🌐 API 端点:"
    echo "   http://localhost:8000"
else
    echo "⚠️  ChromaDB 可能还在启动中，请稍后再试"
    echo "   手动测试: curl http://localhost:8000/api/v1/heartbeat"
fi

echo ""
echo "✅ 安装完成！"
echo ""
echo "📝 重要提醒:"
echo "  1. 注销并重新登录（应用 docker 组权限）"
echo "  2. 运行测试: python3 scripts/test_chroma_docker.py"
echo "  3. 添加记忆: python3 scripts/chroma_add.py --content '...'"
