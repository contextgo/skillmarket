#!/bin/bash
# Docker + ChromaDB 安装脚本（Ubuntu/WSL2）
#
# 用法:
#   chmod +x install_docker_chroma.sh
#   ./install_docker_chroma.sh

set -e

echo "🐳 Docker + ChromaDB 安装脚本"
echo "================================"

# 检查是否为 root
if [ "$EUID" -ne 0 ]; then
    echo "⚠️  需要 sudo 权限"
    SUDO="sudo"
else
    SUDO=""
fi

# 检查 Docker
if command -v docker &> /dev/null; then
    echo "✅ Docker 已安装"
    docker --version
else
    echo "📦 安装 Docker..."
    
    # 更新包索引
    $SUDO apt-get update
    
    # 安装依赖
    $SUDO apt-get install -y \
        ca-certificates \
        curl \
        gnupg \
        lsb-release
    
    # 添加 Docker GPG key
    $SUDO mkdir -p /etc/apt/keyrings
    curl -fsSL https://download.docker.com/linux/ubuntu/gpg | $SUDO gpg --dearmor -o /etc/apt/keyrings/docker.gpg
    
    # 添加 Docker 仓库
    echo \
        "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
        $(lsb_release -cs) stable" | $SUDO tee /etc/apt/sources.list.d/docker.list > /dev/null
    
    # 安装 Docker
    $SUDO apt-get update
    $SUDO apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
    
    # 启动 Docker
    $SUDO systemctl start docker
    $SUDO systemctl enable docker
    
    # 添加当前用户到 docker 组
    $SUDO usermod -aG docker $USER
    
    echo "✅ Docker 安装完成"
    echo "⚠️  请注销并重新登录以应用 docker 组权限"
fi

# 检查 Docker Compose
if docker compose version &> /dev/null; then
    echo "✅ Docker Compose 已安装"
    docker compose version
else
    echo "❌ Docker Compose 未安装"
    exit 1
fi

# 启动 ChromaDB
echo ""
echo "🚀 启动 ChromaDB..."
cd "$(dirname "$0")"

if [ -f docker-compose.yml ]; then
    $SUDO docker compose up -d
    echo "✅ ChromaDB 已启动"
    echo ""
    echo "📊 查看状态:"
    echo "   docker compose ps"
    echo ""
    echo "🔍 查看日志:"
    echo "   docker compose logs -f chromadb"
    echo ""
    echo "🛑 停止服务:"
    echo "   docker compose down"
    echo ""
    echo "🌐 API 端点:"
    echo "   http://localhost:8000"
    echo "   http://localhost:8000/api/v1/heartbeat (健康检查)"
else
    echo "❌ docker-compose.yml 未找到"
    exit 1
fi

echo ""
echo "📝 下一步:"
echo "  1. 测试连接: curl http://localhost:8000/api/v1/heartbeat"
echo "  2. 运行集成测试: python3 scripts/test_chroma_docker.py"
echo "  3. 添加记忆: python3 scripts/chroma_add.py --content '...'"
