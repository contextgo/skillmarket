#!/usr/bin/env python3
"""测试验证脚本 - 验证 skill 的核心功能"""
import sys
from pathlib import Path

SKILL_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(SKILL_DIR))

print("=" * 60)
print("Lark Message Manager - 组件测试")
print("=" * 60)
print()

# Test 1: 配置加载
print("[1/6] 测试配置加载...")
try:
    from scripts.config_loader import load_config
    config = load_config(str(SKILL_DIR / "config/config.example.yaml"))
    assert "monitor" in config
    assert "intents" in config
    assert "task_tracking" in config
    print("  ✅ 配置加载成功")
    print(f"  • 监控频道数: {len(config['monitor'].get('channels', []))}")
    print(f"  • 意图类型数: {len(config['intents'])}")
except Exception as e:
    print(f"  ❌ 配置加载失败: {e}")
    sys.exit(1)

# Test 2: 意图识别
print("\n[2/6] 测试意图识别...")
try:
    from scripts.intent_classifier import classify_intent

    test_cases = [
        ("那个客户问题怎么样了？", "事项跟进"),
        ("帮我记一下：周三前完成 API 文档", "任务创建"),
        ("张三的电话是多少？", "信息查询"),
        ("怎么配置服务器？", "模糊需求"),
        ("已经完成了", "状态更新"),
        ("随便说点什么", "其他")
    ]

    passed = 0
    for text, expected in test_cases:
        result = classify_intent(text, config["intents"])
        actual = result["type"]
        ok = actual == expected or (actual == "其他" and expected == "其他")
        status = "✅" if ok else "❌"
        if ok:
            passed += 1
        print(f"  {status} '{text[:20]}...' → {actual} (期望: {expected})")

    print(f"\n  📊 通过: {passed}/{len(test_cases)}")
except Exception as e:
    print(f"  ❌ 意图识别测试失败: {e}")
    sys.exit(1)

# Test 3: 任务跟踪器
print("\n[3/6] 测试任务跟踪器...")
try:
    import tempfile
    from scripts.task_tracker import TaskTracker

    with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
        temp_path = f.name

    tracker = TaskTracker(temp_path)

    # 创建任务
    tid = tracker.create_task("测试任务", "这是测试", assignee="测试员", priority="high")
    assert tid in tracker.tasks["tasks"]
    print(f"  ✅ 创建任务: {tid}")

    # 查找任务
    found = tracker.find_related(["测试", "任务"])
    assert len(found) > 0
    print(f"  ✅ 查找任务: 找到 {len(found)} 个")

    # 更新状态
    ok = tracker.update_status(tid, "进行中", note="开始处理")
    assert ok
    print(f"  ✅ 更新状态: 待处理 → 进行中")

    # 清理
    Path(temp_path).unlink(missing_ok=True)
    print(f"  ✅ 任务跟踪器基本功能正常")
except Exception as e:
    print(f"  ❌ 任务跟踪器测试失败: {e}")
    sys.exit(1)

# Test 4: 格式强制器
print("\n[4/6] 测试格式强制器...")
try:
    from scripts.format_enforcer import enforce_format, validate_before_send

    # 测试多行转换
    multiline = "步骤:\n1. 登录\n2. 修改\n3. 重启"
    formatted = enforce_format(multiline, "group", {}, {"format": "markdown", "signature": ""})
    assert "**" in formatted or "1." in formatted  # 应该被标记或保留
    print(f"  ✅ 多行格式化: 原始 {len(multiline)} 字符 → 格式化 {len(formatted)} 字符")

    # 测试链接
    link_text = "详情见 https://example.com/page"
    formatted = enforce_format(link_text, "group", {}, {"format": "markdown", "signature": ""})
    print(f"  ✅ 链接处理: 原始 → '{link_text}'")

    # 验证前检查
    issues = validate_before_send("测试消息 @张三", {})
    print(f"  ✅ 验证器可检测 {len(issues)} 个潜在问题")

except Exception as e:
    print(f"  ❌ 格式强制器测试失败: {e}")
    sys.exit(1)

# Test 5: 行动规划器
print("\n[5/6] 测试行动规划器...")
try:
    from scripts.action_planner import plan_action

    # 模糊需求场景
    intent_vague = {"type": "模糊需求", "name": "模糊需求", "confidence": 0.5}
    context_vague = {
        "current_message": {"text": "那个东西好了吗？"},
        "sender": {"name": "张三"},
        "mentioned_people": [],
        "channel": {"type": "group"}
    }
    plan = plan_action(intent_vague, context_vague, config)
    assert plan["reply_strategy"] == "clarify"
    print(f"  ✅ 模糊需求 → 澄清策略")

    # 事项跟进场景
    intent_track = {"type": "事项跟进", "name": "事项跟进", "confidence": 0.6}
    context_track = {
        "current_message": {"text": "客户问题进度如何？"},
        "sender": {"name": "李四"},
        "mentioned_people": [],
        "channel": {"type": "group"}
    }
    plan = plan_action(intent_track, context_track, config)
    assert plan["needs_investigation"] == True
    assert plan["reply_strategy"] == "track"
    print(f"  ✅ 事项跟进 → 调查策略")

except Exception as e:
    print(f"  ❌ 行动规划器测试失败: {e}")
    sys.exit(1)

# Test 6: 回复生成器
print("\n[6/6] 测试回复生成器...")
try:
    from scripts.responder import generate_reply

    # 澄清回复
    reply = generate_reply(
        intent_vague, context_vague,
        {"reply_strategy": "clarify", "investigation_steps": ["步骤1", "步骤2"]},
        config
    )
    assert "@" in reply or "需要" in reply or "明确" in reply
    print(f"  ✅ 澄清回复生成正常")

    # 调查中回复
    reply = generate_reply(
        intent_track, context_track,
        {"reply_strategy": "track", "needs_investigation": True, "investigation_steps": ["查任务", "问负责人"]},
        config
    )
    assert len(reply) > 10
    print(f"  ✅ 事项跟踪回复生成正常")

except Exception as e:
    print(f"  ❌ 回复生成器测试失败: {e}")
    sys.exit(1)

print()
print("=" * 60)
print("✅ 所有组件测试通过！")
print("=" * 60)
print()
print("下一步:")
print("  1. 编辑 config/config.yaml")
print("     • monitor.channels[0].id = 你的群聊ID")
print("     • response.test_chat_id = 你的测试群ID")
print("  2. 运行快速启动: bash scripts/quickstart.sh")
print("  3. 或手动测试: python3 scripts/message_agent_once.py --chat-query '群名' --dry-run")
print()
