#!/usr/bin/env python3
"""格式强制器 - 严格遵守消息格式规范"""
import re
from typing import Dict, List, Optional


def enforce_format(
    text: str,
    chat_type: str,  # "group" | "user"
    sender: Dict,
    config: Dict
) -> str:
    """
    强制消息格式符合规范

    规则:
    1. 群聊多行必须用 Markdown
    2. @ 必须使用结构化方式（不能手打 @姓名）
    3. 链接必须单行独立
    4. 发送前检查、发送后回读
    """
    formatted = text

    # ── 规则 1: 多行处理 ────────────────────────────────────
    if '\n' in formatted and chat_type == "group":
        # 群聊多行 → 必须用 Markdown
        formatted = convert_to_markdown(formatted)

    # ── 规则 2: @ 规范化 ─────────────────────────────────────
    # 检查是否有手打 @（如 "@张三"）但未使用结构化 at
    formatted = normalize_mentions(formatted, sender, chat_type)

    # ── 规则 3: 链接独立行 ───────────────────────────────────
    formatted = fix_links(formatted)

    # ── 规则 4: 长度限制 ─────────────────────────────────────
    max_len = config.get("max_length", 2000)
    if len(formatted) > max_len:
        formatted = formatted[:max_len - 3] + "..."

    # ── 规则 5: 签名添加 ─────────────────────────────────────
    signature = config.get("signature", "")
    if signature and signature not in formatted:
        formatted = f"{formatted}\n{signature}"

    return formatted


def convert_to_markdown(text: str) -> str:
    """转换为 Markdown 格式"""
    lines = text.split('\n')
    result = []

    for line in lines:
        stripped = line.strip()
        if not stripped:
            result.append("")
            continue

        # 列表项
        if stripped.startswith(('•', '-', '*', '1.', '2.', '3.')):
            result.append(stripped)
        # 标题-like
        elif stripped.endswith(':') and len(stripped) < 50:
            result.append(f"**{stripped}**")
        else:
            result.append(stripped)

    return '\n'.join(result)


def normalize_mentions(text: str, sender: Dict, chat_type: str) -> str:
    """
    规范化 @ 提及

    注意: lark-cli 的 post 格式支持 structured mentions
    这里做预处理：识别手打 @ 并标记需要结构化发送
    """
    # 检测手打 @姓名 模式
    pattern = r'@([^\s@]+)'
    matches = list(re.finditer(pattern, text))

    if matches and chat_type == "group":
        # 标记需要结构化 @（实际发送时需要转换为 post 格式）
        # 目前只是警告，实际需要改用 --markdown 和 post 格式
        # 在 lark-cli 中，post 格式的 @ 是独立的 block
        text = re.sub(
            pattern,
            lambda m: f"@{m.group(1)}",  # 暂时保持，需后续转换为 post
            text
        )

    return text


def fix_links(text: str) -> str:
    """确保链接单独成行"""
    # URL 正则（简化）
    url_pattern = r'https?://[^\s]+'

    lines = text.split('\n')
    result = []

    for line in lines:
        # 如果一行有多个内容且包含链接，拆分
        urls = re.findall(url_pattern, line)
        if len(urls) > 0 and len(line) > len(urls[0]) + 10:
            # 拆分链接到独立行
            parts = re.split(url_pattern, line)
            for i, part in enumerate(parts):
                if part.strip():
                    result.append(part.strip())
                if i < len(urls):
                    result.append(urls[i])
        else:
            result.append(line)

    return '\n'.join(result)


def validate_before_send(text: str, config: Dict) -> List[str]:
    """发送前验证，返回问题列表"""
    issues = []

    # 1. 检查 @ 格式
    if '@' in text:
        issues.append("包含 @ 提及，请确保使用结构化格式（群聊）")

    # 2. 检查换行
    if '\\n' in text or '\\\\n' in text:
        issues.append("包含转义换行符，应使用真实换行")

    # 3. 检查链接
    import re
    urls = re.findall(r'https?://[^\s]+', text)
    for url in urls:
        line_containing = [l for l in text.split('\n') if url in l]
        if any(len(l.strip()) > len(url) + 5 for l in line_containing):
            issues.append(f"链接 {url} 应与文本分开成独立行")

    # 4. 检查签名
    sig = config.get("signature", "")
    if sig and sig not in text:
        issues.append(f"缺少签名: {sig}")

    return issues


def post_process_verify(lark_client, sent_msg_id: str, expected_format: str) -> bool:
    """
    发送后回读验证（需要实现）
    - 拉取刚发送的消息
    - 检查渲染效果（换行、@、链接）
    - 异常则重发修正
    """
    # TODO: 实现回读验证
    return True
