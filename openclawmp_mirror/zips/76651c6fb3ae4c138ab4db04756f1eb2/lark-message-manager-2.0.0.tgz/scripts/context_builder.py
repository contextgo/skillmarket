#!/usr/bin/env python3
"""上下文构建器 - 收集消息、联系人、任务等上下文信息"""
import json
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any, Dict, List, Optional

from lark_client import LarkClient


def build_context(
    lark: LarkClient,
    current_msg: Dict,
    channel: Dict,
    config: Dict,
    task_tracker: Any
) -> Dict[str, Any]:
    """
    构建决策所需的完整上下文

    返回结构:
    {
        "current_message": {...},
        "sender": {name, open_id, ...},
        "channel": {type, name, id},
        "recent_history": [...],  # 最近相关消息
        "related_tasks": [...],   # 关联的任务
        "mentioned_people": [...], # 被@的人
        "thread_context": {...},  # 线程上下文（如果有）
        "project_context": {...}  # 项目相关信息
    }
    """
    context = {
        "current_message": current_msg,
        "sender": None,
        "channel": channel,
        "recent_history": [],
        "related_tasks": [],
        "mentioned_people": [],
        "thread_context": None,
        "project_context": {}
    }

    # 1. 获取发送者信息
    sender_id = current_msg.get("sender", {}).get("id")
    if sender_id:
        try:
            # 尝试获取联系人详情
            sender_info = lark.run(
                "contact", "+get-user",
                "--user-id", sender_id,
                "--format", "json"
            )
            context["sender"] = {
                "open_id": sender_id,
                "name": sender_info.get("data", {}).get("name", "未知"),
                "email": sender_info.get("data", {}).get("email", "")
            }
        except Exception:
            context["sender"] = {"open_id": sender_id, "name": "未知"}

    # 2. 获取近期对话历史（同一频道最近 N 条）
    try:
        if channel["type"] == "group":
            history = lark.fetch_messages(
                chat_id=channel["id"],
                limit=config["monitor"]["polling"].get("history_limit", 20)
            )
        else:
            history = lark.fetch_messages(
                user_open_id=channel["id"],
                limit=config["monitor"]["polling"].get("history_limit", 20)
            )

        # 过滤掉当前消息
        context["recent_history"] = [
            m for m in history
            if m.get("message_id") != current_msg.get("message_id")
        ][:10]  # 只保留最近 10 条
    except Exception as e:
        context["recent_history"] = []

    # 3. 提取被@的人
    context["mentioned_people"] = extract_mentions(current_msg)

    # 4. 查找关联任务（关键词匹配）
    task_keywords = extract_keywords(current_msg.get("text", ""))
    if task_keywords and config["task_tracking"]["enabled"]:
        context["related_tasks"] = task_tracker.find_related(task_keywords)

    # 5. 线程上下文（如果是线程回复）
    if current_msg.get("parent_id"):
        try:
            thread_msgs = lark.fetch_messages(
                chat_id=channel.get("id"),
                parent_id=current_msg["parent_id"],
                limit=5
            )
            context["thread_context"] = {
                "parent_id": current_msg["parent_id"],
                "messages": thread_msgs
            }
        except Exception:
            pass

    # 6. 项目上下文（从本地配置文件读取）
    context["project_context"] = load_project_context()

    return context


def extract_mentions(msg: Dict) -> List[Dict]:
    """从消息中提取被@的人"""
    mentions = []
    content = msg.get("content", "")

    # Lark 消息 content 可能是 JSON 字符串
    if isinstance(content, str):
        try:
            content = json.loads(content)
        except:
            pass

    # 从 text 字段或 mentions 字段提取
    if isinstance(content, dict):
        # 富文本格式
        for element in content.get("elements", []):
            if element.get("tag") == "at":
                mentions.append({
                    "type": "user",
                    "open_id": element.get("user_id", ""),
                    "name": element.get("user_name", "")
                })
        # 文本中的 @
        text = content.get("text", "")
        # 简单的 @ 提取（实际需要解析 Lark 的 @ 格式）
    else:
        # 纯文本中查找 @姓名（简化）
        import re
        text = str(content)
        at_pattern = r'@(\S+)'
        for match in re.finditer(at_pattern, text):
            mentions.append({"type": "text_mention", "name": match.group(1)})

    return mentions


def extract_keywords(text: str) -> List[str]:
    """从消息中提取可能的关键词（用于任务关联）"""
    # 简单的关键词提取：去除停用词，提取名词/专有名词
    stopwords = {"的", "了", "在", "是", "我", "你", "他", "她", "它", "们", "这", "那", "有", "和", "或", "与"}
    words = [w for w in text.split() if len(w) > 1 and w not in stopwords]
    return words[:5]  # 最多 5 个关键词


def load_project_context() -> Dict:
    """加载项目上下文（从本地文件）"""
    ctx_file = Path.home() / ".openclaw/context/projects.json"
    if ctx_file.exists():
        try:
            return json.loads(ctx_file.read_text())
        except:
            pass
    return {}
