#!/usr/bin/env bash
set -euo pipefail

PROFILE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --profile)
      PROFILE="$2"; shift 2;;
    -h|--help)
      cat <<'EOF'
Usage: auth_login_stable.sh [options]

稳定授权脚本 - 等待用户完成授权（不会提前退出）
Options:
  --profile <name>   lark-cli profile
EOF
      exit 0;;
    *)
      echo "Unknown arg: $1" >&2; exit 2;;
  esac
done

LARK=(lark-cli)
if [[ -n "$PROFILE" ]]; then
  LARK+=(--profile "$PROFILE")
fi

echo "[auth] 检查当前 token 状态..."
auth_json=$("${LARK[@]}" auth status 2>/tmp/lark_auth_status.log || echo '{}')
token_status=$(echo "$auth_json" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print(d.get('tokenStatus',''))" 2>/dev/null || echo "")

if [[ "$token_status" == "valid" ]]; then
  echo "[ok] token 已有效，无需重新授权"
  exit 0
fi

echo "[auth] token 无效或过期，开始授权流程..."

# 启动授权（输出授权链接）
echo "[auth] 获取授权链接..."
auth_output=$("${LARK[@]}" auth login --no-browser 2>&1 || true)

# 提取 URL
auth_url=$(echo "$auth_output" | grep -o 'https://[^ ]*' | head -1)

if [[ -z "$auth_url" ]]; then
  echo "[x] 无法获取授权链接"
  echo "    手动运行: lark-cli auth login"
  exit 1
fi

echo ""
echo "═══════════════════════════════════════════════════════════"
echo "  请在浏览器中打开以下链接完成授权:"
echo ""
echo "  $auth_url"
echo ""
echo "  授权后，按 Enter 键继续检查状态..."
echo "═══════════════════════════════════════════════════════════"
echo ""

# 等待用户按 Enter
read -r

# 循环检查直到成功或超时
echo "[auth] 检查授权状态..."
max_tries=30
try=0

while [[ $try -lt $max_tries ]]; do
  try=$((try + 1))

  auth_json=$("${LARK[@]}" auth status 2>/tmp/lark_auth_check.log || true)
  token_status=$(echo "$auth_json" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print(d.get('tokenStatus',''))" 2>/dev/null || echo "")

  if [[ "$token_status" == "valid" ]]; then
    echo "[✅] 授权成功！token 有效"
    echo "[info] 有效期至: $(echo "$auth_json" | python3 -c "import json,sys; d=json.loads(sys.stdin.read()); print(d.get('expiresAt','unknown'))" 2>/dev/null)"
    exit 0
  fi

  echo "  [${try}/${max_tries}] 状态: ${token_status:-unknown}，10秒后重试..."
  sleep 10
done

echo "[❌] 授权超时，请手动运行 lark-cli auth login 完成授权"
exit 1
