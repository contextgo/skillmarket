#!/usr/bin/env python3
"""
单次运行：监控→理解→处理→回复（一次闭环）

用法:
  python3 message_agent_once.py --chat-query "产品讨论群" --history-limit 50
  python3 message_agent_once.py --user-query "张三" --dry-run
"""
import argparse
import json
import sys
from pathlib import Path

# 添加 skill 目录
SKILL_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(SKILL_DIR))

from scripts.config_loader import load_config
from scripts.lark_client import LarkClient
from scripts.intent_classifier import classify_intent
from scripts.context_builder import build_context
from scripts.action_planner import plan_action
from scripts.task_tracker import TaskTracker
from scripts.responder import generate_reply
from scripts.format_enforcer import enforce_format, validate_before_send


def main():
    parser = argparse.ArgumentParser(description="Lark Message Manager - 单次运行")
    parser.add_argument("--profile", default=None, help="lark-cli profile")
    parser.add_argument("--config", default=str(SKILL_DIR / "config/config.yaml"),
                       help="配置文件路径")
    parser.add_argument("--dry-run", action="store_true", help="只模拟不发送")
    parser.add_argument("--verbose", "-v", action="store_true", help="详细输出")

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument("--chat-query", help="群聊名称关键词")
    group.add_argument("--user-query", help="联系人姓名")
    group.add_argument("--chat-id", help="直接指定群聊 ID")
    group.add_argument("--user-open-id", help="直接指定用户 open_id")

    parser.add_argument("--history-limit", type=int, default=50,
                       help="拉取最近消息数")
    args = parser.parse_args()

    # 1. 加载配置
    try:
        config = load_config(args.config)
    except Exception as e:
        print(f"❌ 配置加载失败: {e}")
        sys.exit(1)

    if args.dry_run:
        config["dry_run"] = True

    # 2. 初始化客户端
    lark = LarkClient(profile=args.profile, verbose=args.verbose)
    task_tracker = TaskTracker(config["task_tracking"]["storage_file"])

    # 3. 前置检查
    if not lark.is_ready():
        print("❌ lark-cli 未就绪，请先运行: bash scripts/preflight_check.sh")
        sys.exit(1)

    # 4. 解析目标频道
    target_channel = None
    if args.chat_query:
        chat_id, chat_name = lark.search_chat(args.chat_query)
        target_channel = {"type": "group", "id": chat_id, "name": chat_name}
    elif args.user_query:
        user_open_id, user_name = lark.search_user(args.user_query)
        target_channel = {"type": "user", "id": user_open_id, "name": user_name}
    elif args.chat_id:
        target_channel = {"type": "group", "id": args.chat_id, "name": "Unknown"}
    elif args.user_open_id:
        target_channel = {"type": "user", "id": args.user_open_id, "name": "Unknown"}

    print(f"📡 监控频道: {target_channel['name']} ({target_channel['type']})")

    # 5. 拉取消息
    try:
        messages = lark.fetch_messages(
            chat_id=target_channel["id"] if target_channel["type"] == "group" else None,
            user_open_id=target_channel["id"] if target_channel["type"] == "user" else None,
            limit=args.history_limit
        )
    except Exception as e:
        print(f"❌ 拉取消息失败: {e}")
        sys.exit(1)

    # 过滤可处理的消息
    processable = [m for m in messages if not lark.should_skip_message(m)]

    if not processable:
        print("📭 没有需要处理的新消息")
        sys.exit(0)

    # 只处理最新一条
    current_msg = processable[0]
    print(f"📨 处理消息: {current_msg.get('message_id')}")
    print(f"   发送者: {current_msg.get('sender', {}).get('name', '未知')}")
    print(f"   内容: {current_msg.get('text', '')[:100]}...")

    # 6. 意图识别
    intent = classify_intent(current_msg.get("text", ""), config["intents"])
    print(f"🎯 识别意图: {intent['name']} (置信度: {intent['confidence']:.2f})")

    # 7. 构建上下文
    context = build_context(
        lark, current_msg, target_channel, config, task_tracker
    )
    context["task_tracker"] = task_tracker  # 注入 tracker

    # 8. 行动规划
    action_plan = plan_action(intent, context, config)
    print(f"📋 行动方案: {action_plan['reply_strategy']}")

    if not action_plan["should_reply"]:
        print("ℹ️ 根据策略，本次不需要回复")
        sys.exit(0)

    # 9. 生成回复
    reply_text = generate_reply(intent, context, action_plan, config)

    # 10. 格式强制
    reply_text = enforce_format(
        reply_text,
        target_channel["type"],
        current_msg.get("sender", {}),
        config["response"]
    )

    # 11. 发送前验证
    issues = validate_before_send(reply_text, config["response"])
    if issues:
        print("⚠️ 格式问题:")
        for issue in issues:
            print(f"   - {issue}")
        if not config["dry_run"]:
            confirm = input("是否继续发送？(y/N): ").strip().lower()
            if confirm != 'y':
                print("已取消发送")
                sys.exit(0)

    # 12. 预览
    print("\n" + "="*50)
    print("📤 将要发送的消息:")
    print("-"*50)
    print(reply_text)
    print("="*50)

    # 13. 发送
    if not config["dry_run"]:
        try:
            result = lark.send_message(
                chat_id=target_channel["id"] if target_channel["type"] == "group" else None,
                user_open_id=target_channel["id"] if target_channel["type"] == "user" else None,
                text=reply_text
            )
            print(f"\n✅ 发送成功: {result}")
        except Exception as e:
            print(f"\n❌ 发送失败: {e}")
            sys.exit(1)
    else:
        print("\n💡 DRY-RUN 模式 - 未实际发送")

    # 14. 输出结果 JSON
    result_summary = {
        "channel": target_channel,
        "message_id": current_msg.get("message_id"),
        "intent": intent,
        "action_plan": action_plan,
        "reply_preview": reply_text[:200],
        "dry_run": config.get("dry_run", False)
    }

    print("\n📊 执行结果:")
    print(json.dumps(result_summary, ensure_ascii=False, indent=2))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
