#!/usr/bin/env python3
"""Lark 客户端封装"""
import json
import subprocess
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


class LarkClient:
    """lark-cli 的 Python 封装"""

    def __init__(self, profile: Optional[str] = None, verbose: bool = False):
        self.profile = profile
        self.verbose = verbose
        self.base_cmd = ["lark-cli"]
        if profile:
            self.base_cmd += ["--profile", profile]
        # 缓存当前用户信息（用于 @ 匹配）
        self._user_info: Optional[Dict] = None

    def run(self, *args, **kwargs) -> Any:
        """执行 lark-cli 命令"""
        cmd = self.base_cmd + list(args)
        if self.verbose:
            print(f"  🔧 {' '.join(cmd)}")

        result = subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            **kwargs
        )

        if result.returncode != 0:
            raise RuntimeError(f"lark-cli 失败: {result.stderr}")

        # 尝试解析 JSON
        output = result.stdout.strip()
        if output and output.startswith('{'):
            return json.loads(output)
        return output

    def is_ready(self) -> bool:
        """检查 lark-cli 是否已配置且 token 有效"""
        try:
            status = self.run("auth", "status")
            return status.get("tokenStatus") == "valid"
        except Exception:
            return False

    def fetch_messages(
        self,
        *,
        chat_id: Optional[str] = None,
        user_open_id: Optional[str] = None,
        limit: int = 50
    ) -> List[Dict]:
        """拉取消息"""
        cmd = ["im", "+chat-messages-list", "--page-size", str(limit), "--sort", "desc", "--format", "json"]
        if chat_id:
            cmd += ["--chat-id", chat_id]
        elif user_open_id:
            cmd += ["--user-id", user_open_id]
        else:
            raise ValueError("必须提供 chat_id 或 user_open_id")

        result = self.run(*cmd)
        return result.get("data", {}).get("messages", [])

    def send_message(
        self,
        *,
        chat_id: Optional[str] = None,
        user_open_id: Optional[str] = None,
        text: str,
        use_user_identity: bool = True
    ) -> Dict:
        """发送消息

        群聊和私聊都用 user 身份（lark-cli v1.0.14 已支持）。
        自动追加代发声明（如果末尾没有）。
        """
        # 验证身份参数（只支持 user 和 bot，但 user 已验证可在群聊使用）
        identity = "user" if use_user_identity else "bot"

        # 自动附加代发声明（如果末尾没有）
        if not text.endswith("*（本条消息由张隆强的Hermes代发）*"):
            text = text.rstrip() + "\n\n*（本条消息由张隆强的Hermes代发）*"

        cmd = ["im", "+messages-send", "--as", identity, "--text", text]
        if chat_id:
            cmd += ["--chat-id", chat_id]
        elif user_open_id:
            cmd += ["--user-id", user_open_id]

        return self.run(*cmd)

    def search_user(self, query: str) -> Tuple[str, str]:
        """搜索用户，返回 (open_id, name)"""
        result = self.run("contact", "+search-user", "--query", query, "--format", "json")
        users = result.get("data", {}).get("users", [])
        if not users:
            raise ValueError(f"未找到用户: {query}")

        # 精确匹配优先
        for u in users:
            if u.get("name", "").strip() == query.strip():
                return u.get("open_id"), u.get("name", "")

        return users[0].get("open_id"), users[0].get("name", "")

    def search_chat(self, query: str) -> Tuple[str, str]:
        """搜索群聊，返回 (chat_id, name)"""
        result = self.run("im", "+chat-search", "--query", query, "--format", "json")
        data = result.get("data", {})
        chats = data.get("items", []) or data.get("chats", [])
        if not chats:
            raise ValueError(f"未找到群聊: {query}")

        for c in chats:
            if (c.get("name", "").strip() == query.strip() or
                c.get("chat_name", "").strip() == query.strip()):
                cid = c.get("chat_id") or c.get("id")
                return cid, c.get("name", "") or c.get("chat_name", "")

        c = chats[0]
        cid = c.get("chat_id") or c.get("id")
        return cid, c.get("name", "") or c.get("chat_name", "")

    def get_self_info(self) -> Dict[str, str]:
        """获取当前用户信息"""
        status = self.run("auth", "status")
        return {
            "open_id": status.get("userOpenId", ""),
            "name": status.get("userName", ""),
            "email": status.get("userEmail", "")
        }

    def get_user_info(self) -> Dict[str, str]:
        """获取当前用户信息（缓存）"""
        if self._user_info is None:
            status = self.run("auth", "status")
            self._user_info = {
                "open_id": status.get("userOpenId", ""),
                "name": status.get("userName", ""),
                "email": status.get("userEmail", "")
            }
        return self._user_info

    def should_skip_message(
        self,
        msg: Dict,
        channel: Optional[Dict] = None
    ) -> bool:
        """
        判断消息是否应该跳过（不处理）

        过滤规则:
        1. 已删除、无内容、系统消息
        2. 自己发的消息
        3. 如果 channel.mention_required=True，必须 @当前用户
        4. 如果 channel.mention_required=False，检查是否命中关键词（可选）
        """
        if msg.get("deleted"):
            return True
        sender = msg.get("sender", {})
        # 跳过自己的消息
        if sender.get("id") == "self":
            return True
        # 跳过系统/应用消息
        if sender.get("sender_type") == "app":
            return True
        # 跳过无内容消息
        content = msg.get("content", "")
        if isinstance(content, str) and not content.strip():
            return True

        # ── @ 检测 ──────────────────────────────────────
        if channel and channel.get("mention_required", False):
            user_info = self.get_user_info()
            my_open_id = user_info["open_id"]
            # 从消息文本提取 @ 标记（<at user_id="...">）
            text = msg.get("text", "") or msg.get("content", "")
            if isinstance(text, dict):
                text = text.get("text", "")
            # 正则匹配 user_id
            import re
            pattern = rf'<at\s+user_id=["\']{re.escape(my_open_id)}["\']>'
            if not re.search(pattern, text, re.IGNORECASE):
                return True  # 未@当前用户，跳过

        return False

    def verify_in_test_chat(self, text: str, config: Dict) -> bool:
        """在测试群验证消息格式（@、换行等）"""
        test_chat_id = config["response"].get("test_chat_id")
        if not test_chat_id:
            return True  # 未配置测试群，跳过验证

        try:
            # 发送到测试群
            test_msg = f"[格式测试] {text}"
            self.send_message(chat_id=test_chat_id, text=test_msg)

            # TODO: 回读最近消息，验证渲染效果
            # 目前简化：假设发送成功即通过
            return True
        except Exception as e:
            print(f"⚠️ 测试群验证失败: {e}")
            return False
