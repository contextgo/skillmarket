#!/usr/bin/env python3
"""
Lark Message Manager Agent
智能飞书消息管理器 - 监控、理解、调查、跟进、回复
"""

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

# 添加 skill 目录到路径
SKILL_DIR = Path(__file__).parent.parent
sys.path.insert(0, str(SKILL_DIR))

from scripts.config_loader import load_config
from scripts.intent_classifier import classify_intent
from scripts.context_builder import build_context
from scripts.action_planner import plan_action
from scripts.task_tracker import TaskTracker
from scripts.responder import generate_reply
from scripts.format_enforcer import enforce_format
from scripts.lark_client import LarkClient


def run_cycle(config: Dict, lark: LarkClient, task_tracker: TaskTracker) -> Dict[str, Any]:
    """执行一次监控-处理-回复闭环"""
    result = {
        "cycle_start": time.time(),
        "channels_checked": 0,
        "messages_processed": 0,
        "actions_taken": [],
        "replies_sent": 0,
        "errors": []
    }

    for channel in config["monitor"]["channels"]:
        if not channel.get("enabled", True):
            continue

        try:
            # 1. 拉取最新消息
            messages = lark.fetch_messages(
                chat_id=channel["id"] if channel["type"] == "group" else None,
                user_open_id=channel["id"] if channel["type"] == "user" else None,
                limit=config["monitor"]["polling"]["history_limit"]
            )

            result["channels_checked"] += 1

            # 2. 筛选需要处理的消息（过滤已读、自己发的、系统消息）
            for msg in messages:
                if lark.should_skip_message(msg):
                    continue

                # 3. 意图识别
                # 某些消息字段里可能没有 text，仅有 content
                text_for_intent = msg.get("text")
                if isinstance(text_for_intent, dict):
                    text_for_intent = text_for_intent.get("text", "")
                if not text_for_intent:
                    content = msg.get("content")
                    if isinstance(content, dict):
                        text_for_intent = content.get("text", "")
                    else:
                        text_for_intent = content or ""
                intent = classify_intent(text_for_intent, config["intents"])

                # 4. 构建上下文（历史消息、联系人信息、相关任务）
                context = build_context(lark, msg, channel, config, task_tracker)

                # 5. 决策规划（是否需要回复？需要做什么调查？）
                action_plan = plan_action(intent, context, config)

                if action_plan["should_reply"]:
                    # 6. 生成回复
                    reply_text = generate_reply(intent, context, action_plan, config)

                    # 7. 格式强制验证与修复
                    reply_text = enforce_format(
                        reply_text,
                        channel["type"],
                        msg.get("sender", {}),
                        config["response"]
                    )

                    # 8. 测试群验证（如果是正式群聊）
                    if channel["type"] == "group" and config["response"].get("test_chat_id"):
                        test_ok = lark.verify_in_test_chat(reply_text, config)
                        if not test_ok:
                            result["errors"].append(f"格式验证失败，跳过发送到 {channel['name']}")
                            continue

                    # 9. 发送回复
                    if not config.get("dry_run"):
                        send_result = lark.send_message(
                            chat_id=channel["id"] if channel["type"] == "group" else None,
                            user_open_id=channel["id"] if channel["type"] == "user" else None,
                            text=reply_text
                        )
                        result["replies_sent"] += 1
                        result["actions_taken"].append({
                            "channel": channel["name"],
                            "intent": intent["name"],
                            "action": "reply_sent",
                            "message_id": msg.get("message_id")
                        })

                result["messages_processed"] += 1

        except Exception as e:
            result["errors"].append(f"{channel['name']}: {str(e)}")

    return result


def main():
    parser = argparse.ArgumentParser(description="Lark Message Manager Agent")
    parser.add_argument("--config", default=str(SKILL_DIR / "config/config.yaml"),
                       help="配置文件路径")
    parser.add_argument("--profile", default=None,
                       help="lark-cli profile 名称")
    parser.add_argument("--dry-run", action="store_true",
                       help="只模拟，不实际发送消息")
    parser.add_argument("--once", action="store_true",
                       help="运行一次后退出（测试用）")
    parser.add_argument("--verbose", "-v", action="store_true",
                       help="详细输出")
    args = parser.parse_args()

    # 1. 加载配置
    config = load_config(args.config)
    if args.dry_run:
        config["dry_run"] = True

    # 2. 初始化 Lark 客户端
    lark = LarkClient(profile=args.profile, verbose=args.verbose)

    # 3. 初始化任务跟踪器
    task_tracker = TaskTracker(config["task_tracking"]["storage_file"])

    # 4. 前置检查
    if not lark.is_ready():
        print("❌ lark-cli 未就绪，请先运行 preflight_check.sh")
        sys.exit(1)

    print(f"🚀 Lark Message Manager 启动")
    print(f"📡 监控频道: {len([c for c in config['monitor']['channels'] if c.get('enabled')])} 个")
    print(f"🔄 轮询间隔: {config['monitor']['polling']['interval_seconds']} 秒")

    # 5. 主循环
    try:
        while True:
            result = run_cycle(config, lark, task_tracker)

            if args.verbose:
                print(json.dumps(result, ensure_ascii=False, indent=2))

            if args.once:
                break

            interval = config["monitor"]["polling"]["interval_seconds"]
            time.sleep(interval)

    except KeyboardInterrupt:
        print("\n🛑 已停止")
    except Exception as e:
        print(f"❌ 错误: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
