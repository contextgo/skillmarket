#!/usr/bin/env python3
"""意图分类器 - 识别消息类型"""
import re
from typing import Dict, List, Optional


def normalize(text: str) -> str:
    """文本归一化"""
    text = re.sub(r'\s+', ' ', text).strip().lower()
    return text


def classify_intent(text: str, intent_configs: Dict) -> Dict:
    """
    识别消息意图

    返回: {
        "name": "意图名称",
        "type": "模糊需求|事项跟进|信息查询|任务创建|状态更新|其他",
        "confidence": 0.0-1.0,
        "keywords_matched": [],
        "needs_clarification": bool
    }
    """
    text_norm = normalize(text)

    # 意图优先级顺序（高优先级在前）
    intent_priority = {
        "任务创建": 5,
        "状态更新": 4,
        "事项跟进": 3,
        "信息查询": 2,
        "模糊需求": 1
    }

    best_match = {"name": "其他", "type": "其他", "confidence": 0.0, "keywords_matched": [], "priority": 0}

    for intent_name, config in intent_configs.items():
        keywords = config.get("keywords", [])
        matched = []

        for kw in keywords:
            if normalize(kw) in text_norm:
                matched.append(kw)

        if matched:
            # 置信度 = 匹配数 / 关键词总数
            confidence = len(matched) / max(len(keywords), 1)
            priority = intent_priority.get(intent_name, 0)

            if confidence > best_match["confidence"] or (confidence == best_match["confidence"] and priority > best_match["priority"]):
                best_match = {
                    "name": intent_name,
                    "type": intent_name,
                    "confidence": confidence,
                    "keywords_matched": matched,
                    "needs_clarification": config.get("need_context", False),
                    "priority": priority
                }

    # 默认启发式规则（当没有配置关键词时）
    if best_match["type"] == "其他":
        # 模糊需求模式（优先）
        if any(kw in text for kw in ["怎么", "如何", "怎么办", "帮忙", "看看", "那个", "东西", "有点问题"]):
            best_match = {
                "name": "模糊需求",
                "type": "模糊需求",
                "confidence": 0.5,
                "keywords_matched": [],
                "needs_clarification": True,
                "priority": 1
            }
        # 问号结尾 → 信息查询（降级）
        elif "?" in text or "？" in text:
            best_match = {
                "name": "信息查询",
                "type": "信息查询",
                "confidence": 0.6,
                "keywords_matched": ["?"],
                "needs_clarification": False,
                "priority": 2
            }
        # 其他模式...
        elif any(kw in text for kw in ["进度", "怎么样了", "完成", "跟进", "结果", "状态", "update"]):
            best_match = {
                "name": "事项跟进",
                "type": "事项跟进",
                "confidence": 0.5,
                "keywords_matched": [],
                "needs_clarification": False,
                "priority": 3
            }
        elif any(kw in text for kw in ["记一下", "创建", "新增", "添加", "remind"]):
            best_match = {
                "name": "任务创建",
                "type": "任务创建",
                "confidence": 0.5,
                "keywords_matched": [],
                "needs_clarification": False,
                "priority": 5
            }

    return best_match
