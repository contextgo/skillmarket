#!/usr/bin/env python3
"""任务跟踪器 - 管理待办事项状态"""
import json
import time
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional


class TaskTracker:
    """跟踪和管理任务状态"""

    def __init__(self, storage_path: str):
        self.storage_path = Path(storage_path).expanduser()
        self.storage_path.parent.mkdir(parents=True, exist_ok=True)
        self.tasks = self._load()

    def _load(self) -> Dict[str, Any]:
        """从文件加载任务"""
        if self.storage_path.exists():
            try:
                return json.loads(self.storage_path.read_text())
            except Exception:
                pass
        return {"tasks": {}, "metadata": {"version": "1.0", "last_updated": time.time()}}

    def _save(self):
        """保存到文件"""
        self.storage_path.write_text(
            json.dumps(self.tasks, ensure_ascii=False, indent=2),
            encoding='utf-8'
        )

    def find_related(self, keywords: List[str], limit: int = 3) -> List[Dict]:
        """根据关键词查找相关任务"""
        results = []
        for task_id, task in self.tasks.get("tasks", {}).items():
            # 计算匹配度
            score = 0
            task_text = (task.get("title", "") + " " + task.get("description", "")).lower()
            for kw in keywords:
                if kw.lower() in task_text:
                    score += 1

            if score > 0:
                results.append({
                    "id": task_id,
                    "title": task.get("title"),
                    "status": task.get("status"),
                    "assignee": task.get("assignee"),
                    "score": score
                })

        # 按匹配度排序
        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]

    def create_task(
        self,
        title: str,
        description: str = "",
        assignee: str = "",
        priority: str = "medium",
        due_date: Optional[str] = None
    ) -> str:
        """创建新任务"""
        task_id = f"TASK-{int(time.time())}"
        task = {
            "id": task_id,
            "title": title,
            "description": description,
            "assignee": assignee,
            "status": "待处理",
            "priority": priority,
            "created_at": datetime.now().isoformat(),
            "due_date": due_date,
            "updates": []
        }
        self.tasks["tasks"][task_id] = task
        self.tasks["metadata"]["last_updated"] = time.time()
        self._save()
        return task_id

    def update_status(
        self,
        task_id: str,
        status: str,
        note: str = "",
        by: str = "system"
    ) -> bool:
        """更新任务状态"""
        if task_id not in self.tasks["tasks"]:
            return False

        task = self.tasks["tasks"][task_id]
        old_status = task.get("status")
        task["status"] = status
        task["last_update"] = datetime.now().isoformat()

        # 记录更新历史
        task["updates"].append({
            "timestamp": datetime.now().isoformat(),
            "from": old_status,
            "to": status,
            "note": note,
            "by": by
        })

        self.tasks["metadata"]["last_updated"] = time.time()
        self._save()
        return True

    def get_task(self, task_id: str) -> Optional[Dict]:
        """获取单个任务详情"""
        return self.tasks.get("tasks", {}).get(task_id)

    def get_open_tasks(self, assignee: Optional[str] = None) -> List[Dict]:
        """获取未完成的任务"""
        tasks = self.tasks.get("tasks", {})
        open_tasks = []
        for tid, task in tasks.items():
            if task.get("status") not in ["已完成", "已关闭"]:
                if assignee is None or task.get("assignee") == assignee:
                    open_tasks.append({"id": tid, **task})
        return open_tasks

    def summarize_tasks(self, for_person: Optional[str] = None) -> str:
        """生成任务摘要文本"""
        tasks = self.get_open_tasks(for_person)
        if not tasks:
            return "当前没有待处理任务 ✅"

        lines = ["📋 待处理任务:"]
        for t in tasks:
            assignee = t.get("assignee", "未分配")
            lines.append(f"  • {t['id']}: {t['title']} [{t['status']}] → {assignee}")

        return "\n".join(lines)
