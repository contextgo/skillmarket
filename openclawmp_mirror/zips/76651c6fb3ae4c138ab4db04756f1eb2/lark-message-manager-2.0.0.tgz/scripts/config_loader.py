#!/usr/bin/env python3
"""配置加载器"""

from pathlib import Path
from typing import Dict

# 说明：当前运行环境可能未安装 PyYAML。
# 为了让 skill 在最小依赖下也能工作，这里提供一个降级方案：
# - 首选：yaml.safe_load
# - 失败：尝试把配置当作 JSON（你的 config.yaml 当前是 JSON 风格写法）
try:
    import yaml  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    yaml = None

import json

def expand_path(config: Dict, key_path: str) -> None:
    """展开配置中的路径（支持嵌套键，如 'task_tracking.storage_file'）"""
    parts = key_path.split('.')
    d = config
    for p in parts[:-1]:
        if p in d:
            d = d[p]
        else:
            return
    leaf_key = parts[-1]
    if leaf_key in d and d[leaf_key]:
        d[leaf_key] = str(Path(d[leaf_key]).expanduser())


def load_config(config_path: str) -> Dict:
    """加载 YAML 配置"""
    path = Path(config_path).expanduser()
    if not path.exists():
        raise FileNotFoundError(f"配置文件不存在: {path}")

    with open(path, 'r', encoding='utf-8') as f:
        raw = f.read()

    # 你的 config.yaml 实际上是 JSON 语法风格（使用双引号、逗号等）。
    # 因此这里做两级降级：
    # 1) 如果有 yaml 模块，则优先 yaml.safe_load
    # 2) 否则尝试 json.loads
    if yaml is not None:
        try:
            config = yaml.safe_load(raw) or {}
        except Exception:
            config = {}
    else:
        config = {}

    if not config:
        try:
            config = json.loads(raw)
        except Exception as e:
            raise RuntimeError(f"无法解析配置文件（既不是合法 YAML，也不是合法 JSON）: {path}; err={e}")


    # 路径展开
    expand_path(config, "task_tracking.storage_file")
    expand_path(config, "logging.file")

    return config
