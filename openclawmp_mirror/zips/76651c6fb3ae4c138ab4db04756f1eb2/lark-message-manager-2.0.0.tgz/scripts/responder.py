#!/usr/bin/env python3
"""回复生成器 - 根据意图和上下文生成回复"""
from typing import Any, Dict, List, Optional


def generate_reply(
    intent: Dict,
    context: Dict,
    action_plan: Dict,
    config: Dict
) -> str:
    """
    生成回复文本

    策略:
    - direct: 直接回答
    - clarify: 请求澄清（模糊需求）
    - investigate: 告知正在调查（先回复，调查完再跟进）
    - track: 汇报任务状态
    - confirm_create: 确认创建任务
    - acknowledge: 确认收到更新
    """
    strategy = action_plan["reply_strategy"]
    intent_name = intent["name"]

    # 获取消息原文
    original_text = context["current_message"].get("text", "")

    # ── 策略路由 ─────────────────────────────────────────────
    if strategy == "clarify":
        return _gen_clarify(intent_name, context, config)

    elif strategy == "track":
        return _gen_track_reply(context, config)

    elif strategy == "lookup":
        return _gen_lookup_reply(context, config)

    elif strategy == "confirm_create":
        return _gen_confirm_create(original_text, context, config)

    elif strategy == "acknowledge":
        return _gen_acknowledge(original_text, context, config)

    elif strategy == "direct_track":
        return _gen_direct_track(context, config)

    else:
        # 默认：直接回答（但需要先调查）
        if action_plan["needs_investigation"]:
            return _gen_investigating_reply(context, config)
        else:
            return _gen_direct_reply(original_text, config)


def _gen_clarify(intent_name: str, context: Dict, config: Dict) -> str:
    """生成澄清回复"""
    sender = context.get("sender", {})
    sender_name = sender.get("name", "你")

    questions = config["investigation"].get("clarification_questions", [])
    # 选择最相关的 2-3 个问题
    selected = questions[:2] if questions else [
        "能否具体说说是指哪个事项？",
        "涉及到的联系人是谁？"
    ]

    lines = [
        f"@{sender_name} 收到，我需要更明确一些以便准确处理：",
        ""
    ]
    for i, q in enumerate(selected, 1):
        lines.append(f"{i}. {q}")
    lines.append("")
    lines.append("（收到你的澄清后，我会立即跟进处理）")

    return "\n".join(lines)


def _gen_track_reply(context: Dict, config: Dict) -> str:
    """生成事项跟进回复"""
    sender = context.get("sender", {})
    sender_name = sender.get("name", "你")

    # 查找相关任务
    task_tracker = context.get("task_tracker")
    if task_tracker:
        related = task_tracker.find_related([], limit=3)
        if related:
            lines = [f"@{sender_name} 关于你问的事项，最新进展：", ""]
            for t in related:
                assignee = t.get("assignee", "未分配")
                lines.append(f"  • {t['id']}: {t['title']}")
                lines.append(f"    状态: {t['status']} | 负责人: {assignee}")
            return "\n".join(lines)

    return f"@{sender_name} 我已收到，正在查看相关事项进度，稍后同步你。"


def _gen_lookup_reply(context: Dict, config: Dict) -> str:
    """生成信息查询回复"""
    sender = context.get("sender", {})
    sender_name = sender.get("name", "你")

    return f"@{sender_name} 我正在查找相关信息，稍后同步你。"


def _gen_confirm_create(original: str, context: Dict, config: Dict) -> str:
    """生成任务创建确认"""
    sender = context.get("sender", {})
    sender_name = sender.get("name", "你")

    # 提取任务标题（简化：取第一句话）
    title = original.split('\n')[0][:50]

    return (
        f"@{sender_name} 收到，我将创建任务：\n\n"
        f"📌 {title}\n\n"
        f"确认后我会添加到任务跟踪列表。\n"
        f"（如需修改请告诉我具体内容）"
    )


def _gen_acknowledge(original: str, context: Dict, config: Dict) -> str:
    """生成状态更新确认"""
    sender = context.get("sender", {})
    sender_name = sender.get("name", "你")

    return f"@{sender_name} 收到更新，我已同步到任务跟踪列表。✅"


def _gen_direct_track(context: Dict, config: Dict) -> str:
    """直接汇报任务状态（已明确任务ID）"""
    task_tracker = context.get("task_tracker")
    if task_tracker:
        # 从上下文中提取任务ID
        task_id = extract_task_id(context["current_message"].get("text", ""))
        if task_id:
            task = task_tracker.get_task(task_id)
            if task:
                return (
                    f"📊 任务 {task_id} 状态:\n"
                    f"  标题: {task.get('title')}\n"
                    f"  状态: {task.get('status')}\n"
                    f"  负责人: {task.get('assignee', '未分配')}\n"
                    f"  最近更新: {task.get('last_update', '无')}"
                )

    return "已收到，正在查询该事项详情..."


def _gen_investigating_reply(context: Dict, config: Dict) -> str:
    """生成正在调查的回复"""
    sender = context.get("sender", {})
    sender_name = sender.get("name", "你")
    plan = context.get("action_plan", {})
    steps = plan.get("investigation_steps", [])

    if steps:
        steps_text = "\n".join([f"  • {s}" for s in steps[:3]])
        return (
            f"@{sender_name} 收到，正在处理中：\n\n"
            f"{steps_text}\n\n"
            f"处理完成后我会第一时间同步你。"
        )

    return f"@{sender_name} 收到，我正在处理，稍后同步进展。"


def _gen_direct_reply(original: str, config: Dict) -> str:
    """直接回复（无需调查的简单问题）"""
    # 这里可以集成 LLM 生成，暂时返回模板
    return (
        "收到你的问题。\n\n"
        "（当前为简化模式，实际部署时可配置 LLM 生成详细回答）"
    )


def extract_task_id(text: str) -> Optional[str]:
    """从文本中提取任务ID"""
    import re
    patterns = [r'#(\d+)', r'(TASK-\d+)', r'(issue-\d+)', r'(bug-\d+)']
    for p in patterns:
        match = re.search(p, text, re.IGNORECASE)
        if match:
            return match.group(1) if '(' not in p else match.group(1)
    return None
