#!/bin/bash
# Lark Message Manager - 快速启动指南
# 一键完成前置检查、配置、测试

set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROFILE="${LARK_PROFILE:-default}"

echo "═══════════════════════════════════════════════════════════"
echo "  Lark Message Manager - 快速启动"
echo "═══════════════════════════════════════════════════════════"
echo ""

# Step 1: 前置检查
echo "【1/4】前置检查..."
if ! bash "$SCRIPT_DIR/scripts/preflight_check.sh" --profile "$PROFILE"; then
  echo "❌ 前置检查失败，请解决上述问题后重试"
  exit 1
fi
echo "✅ 前置检查通过"
echo ""

# Step 2: 配置检查
echo "【2/4】配置文件检查..."
CONFIG_FILE="$SCRIPT_DIR/config/config.yaml"
if [ ! -f "$CONFIG_FILE" ]; then
  echo "⚠️ 配置文件不存在，从示例创建..."
  cp "$SCRIPT_DIR/config/config.example.yaml" "$CONFIG_FILE"
  echo "✅ 已创建配置文件，请编辑: $CONFIG_FILE"
  echo "   需要修改的项:"
  echo "   - monitor.channels[0].id (你的群聊 ID)"
  echo "   - response.test_chat_id (你的测试群 ID)"
  echo ""
  read -p "是否现在编辑配置文件？(y/N): " EDIT_CONF
  if [[ "$EDIT_CONF" =~ ^[Yy]$ ]]; then
    ${EDITOR:-nano} "$CONFIG_FILE"
  fi
else
  echo "✅ 配置文件存在: $CONFIG_FILE"
fi
echo ""

# Step 3: 单次测试（Dry-Run）
echo "【3/4】单次运行测试（Dry-Run）..."
echo "提示: 首次测试建议使用测试群，避免打扰正式群"
echo ""

# 获取配置中的频道
if command -v python3 &>/dev/null; then
  CHANNELS=$(python3 -c "
import yaml, sys
try:
    cfg = yaml.safe_load(open('$CONFIG_FILE'))
    for c in cfg.get('monitor', {}).get('channels', []):
        if c.get('enabled'):
            print(f\"{c.get('name', '')} | {c.get('id', '')} | {c.get('type', '')}\")
except Exception as e:
    print(f'ERROR: {e}', file=sys.stderr)
" 2>/dev/null || echo "ERROR")

  if [ "$CHANNELS" != "ERROR" ] && [ -n "$CHANNELS" ]; then
    echo "已配置的监控频道："
    echo "$CHANNELS" | while IFS='|' read -r name cid ctype; do
      echo "  • $name ($ctype)"
    done
    echo ""
  fi
fi

read -p "选择测试频道（输入群聊名称关键词，或直接回车跳过）: " TEST_QUERY

if [ -n "$TEST_QUERY" ]; then
  echo "正在运行 Dry-Run 测试..."
  python3 "$SCRIPT_DIR/scripts/message_agent_once.py" \
    --chat-query "$TEST_QUERY" \
    --dry-run \
    --verbose 2>&1 | head -100

  echo ""
  read -p "测试是否正常？(y/N): " TEST_OK
  if [[ ! "$TEST_OK" =~ ^[Yy]$ ]]; then
    echo "请检查配置和日志，修正后重试"
    exit 1
  fi
else
  echo "跳过测试，请稍后手动运行"
fi

echo ""

# Step 4: 启动说明
echo "【4/4】启动方式"
echo ""
echo "方式 A: 手动触发（按需运行）"
echo "  python3 scripts/message_agent_once.py --chat-query \"产品讨论群\""
echo ""
echo "方式 B: 定时任务（推荐）"
echo "  每 5 分钟检查一次："
echo "  hermes cron create \"*/5 * * * *\" -q \"python3 ~/.openclaw/skills/lark-message-manager/scripts/message_agent_once.py --chat-query '产品讨论群' --dry-run false\""
echo ""
echo "方式 C: 常驻进程"
echo "  nohup python3 scripts/message_agent.py --verbose > ~/.openclaw/logs/lark-manager.log 2>&1 &"
echo ""
echo "═══════════════════════════════════════════════════════════"
echo "✅ 快速启动完成！"
echo "═══════════════════════════════════════════════════════════"
