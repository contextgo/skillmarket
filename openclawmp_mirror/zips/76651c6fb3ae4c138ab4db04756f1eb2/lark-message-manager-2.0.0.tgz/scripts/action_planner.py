#!/usr/bin/env python3
"""行动规划器 - 决定需要做什么"""
from typing import Any, Dict, List, Optional


def plan_action(
    intent: Dict,
    context: Dict,
    config: Dict
) -> Dict[str, Any]:
    """
    根据意图和上下文，规划需要执行的动作

    返回: {
        "should_reply": bool,          # 是否应该回复
        "reply_strategy": str,         # 回复策略: direct | clarify | investigate
        "needs_investigation": bool,   # 是否需要主动调查
        "investigation_steps": [...],  # 调查步骤列表
        "needs_task_update": bool,     # 是否需要更新任务
        "requires_confirmation": bool, # 是否需要人工确认（安全敏感）
        "priority": str,              # 优先级: low | medium | high
        "estimated_effort": str        # 预估耗时: quick | medium | long
    }
    """
    plan = {
        "should_reply": True,
        "reply_strategy": "direct",
        "needs_investigation": False,
        "investigation_steps": [],
        "needs_task_update": False,
        "requires_confirmation": False,
        "priority": "medium",
        "estimated_effort": "quick"
    }

    intent_type = intent["type"]

    # ── 按意图类型制定策略 ──────────────────────────────────
    if intent_type == "模糊需求":
        plan["reply_strategy"] = "clarify"
        plan["needs_investigation"] = True
        plan["investigation_steps"] = [
            "查找历史消息中类似讨论",
            "识别未明确的关键要素（谁、什么项目、具体问题）",
            "准备澄清问题列表"
        ]
        plan["priority"] = "low"
        plan["estimated_effort"] = "quick"

    elif intent_type == "事项跟进":
        plan["reply_strategy"] = "track"
        plan["needs_investigation"] = True
        plan["investigation_steps"] = [
            "从任务存储中搜索相关事项（关键词匹配）",
            "检查事项负责人最近消息",
            "如有必要，私聊负责人确认进展",
            "汇总状态并回复"
        ]
        plan["needs_task_update"] = True
        plan["priority"] = "high"
        plan["estimated_effort"] = "medium"

    elif intent_type == "信息查询":
        plan["reply_strategy"] = "lookup"
        plan["needs_investigation"] = True
        plan["investigation_steps"] = [
            "搜索联系人数据库",
            "查找相关文档/知识库",
            "从历史消息中提取答案"
        ]
        plan["priority"] = "medium"
        plan["estimated_effort"] = "quick"

    elif intent_type == "任务创建":
        plan["reply_strategy"] = "confirm_create"
        plan["needs_investigation"] = False
        plan["requires_confirmation"] = True  # 创建任务需要确认
        plan["priority"] = "medium"
        plan["estimated_effort"] = "quick"

    elif intent_type == "状态更新":
        plan["reply_strategy"] = "acknowledge"
        plan["needs_investigation"] = False
        plan["needs_task_update"] = True
        plan["priority"] = "high"
        plan["estimated_effort"] = "quick"

    # ── 上下文调整 ──────────────────────────────────────────
    # 如果已被@，提高优先级
    if context.get("mentioned_people"):
        plan["priority"] = "high"

    # 如果是紧急关键词（"紧急"、" ASAP"等）
    urgent_words = ["紧急", "urgent", "asap", "立刻", "马上"]
    if any(w in context["current_message"].get("text", "").lower() for w in urgent_words):
        plan["priority"] = "high"
        plan["estimated_effort"] = "medium"

    # 如果已有明确任务ID，直接跟进
    if has_task_reference(context):
        plan["reply_strategy"] = "direct_track"
        plan["needs_investigation"] = True

    return plan


def has_task_reference(context: Dict) -> bool:
    """检查消息中是否提到了明确的任务标识"""
    text = context["current_message"].get("text", "").lower()
    # 任务编号模式：#123、TASK-456、issue-789
    import re
    patterns = [r'#\d+', r'task-\d+', r'issue-\d+', r'bug-\d+']
    for p in patterns:
        if re.search(p, text, re.IGNORECASE):
            return True
    return False
