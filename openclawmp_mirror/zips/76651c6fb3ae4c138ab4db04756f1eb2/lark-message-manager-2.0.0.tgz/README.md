# 智能飞书消息管理器

基于 `lark-auto-reply` 全面升级的智能飞书消息接管代理。不只是自动回复，而是理解、调查、跟进、闭环。

## 🎯 核心能力

- ✅ **意图识别**：自动识别模糊需求、事项跟进、信息查询、任务创建
- ✅ **上下文感知**：分析最近 10 条对话流，关联历史、联系人、任务状态
- ✅ **主动调查**：拉取历史、识别相关人、搜索任务、私聊确认、汇总回复
- ✅ **内置任务跟踪**：轻量级任务管理（待处理/进行中/待审核/已完成/已关闭）
- ✅ **格式强制验证**：代码级规范（Markdown转换、@结构化、链接独立行、前后验证、测试群闸门）
- ✅ **配置化管理**：YAML 配置文件，灵活调整监控策略

## 📋 版本历史

- **v2.0.0** (2026-04-23)：重大升级，基于 `lark-auto-reply` 完全重构为智能消息管理器，新增意图识别、上下文分析、主动调查、内置任务跟踪、代码级格式强制验证
- **v1.0.0** (2026-04-20)：首次独立发布，基于 lark-auto-reply 重构
- **v0.x** (2026-03-31)：原型阶段，验证核心流程

## 🆚 与 lark-auto-reply 的升级

| 维度 | lark-auto-reply | lark-message-manager |
|------|-----------------|---------------------|
| 触发方式 | 关键词匹配 | 意图理解 + 上下文 |
| 消息历史 | 只看最新 1 条 | 分析最近 10 条对话流 |
| 回复逻辑 | 硬编码模板 | 动态生成（基于上下文） |
| 模糊需求 | ❌ 无法处理 | ✅ 主动澄清 + 调查 |
| 事项跟进 | ❌ 无 | ✅ 内置任务跟踪器 |
| 格式规范 | 📝 仅文档说明 | ✅ 代码强制验证 |
| 监控配置 | 命令行参数 | ✅ YAML 配置文件 |

详细对比见 `SKILL.md`。

## 📦 前置条件

```bash
# 1. 确保 lark-cli 已安装并授权
lark-cli --version          # 应输出 1.0.0+
lark-cli auth status        # tokenStatus=valid
```

## 🚀 快速开始

### 单次测试（Dry-Run）

```bash
# 监控群聊（不实际发送）
python3 scripts/message_agent_once.py \
  --chat-query "产品讨论群" \
  --dry-run -v

# 监控私聊
python3 scripts/message_agent_once.py \
  --user-query "张三" \
  --dry-run
```

### 启动常驻进程

```bash
# 后台运行
nohup python3 scripts/message_agent.py --verbose > ~/.openclaw/logs/lark-manager.log 2>&1 &

# 或集成到 Hermes cron
hermes cron create "*/5 * * * *" -q \
  "python3 ~/.openclaw/skills/lark-message-manager/scripts/message_agent_once.py \
   --chat-query '产品讨论群' --dry-run false"
```

## ⚙️ 配置

编辑 `config/config.yaml`：

### monitor.channels - 监控频道列表
```yaml
monitor:
  channels:
    - id: "oc_xxxxx"
      name: "产品讨论群"
      type: group
      enabled: true
      keywords: ["需求", "问题", "进度"]
      priority: high
```

### polling - 轮询设置
```yaml
polling:
  interval_seconds: 300      # 轮询间隔（秒）
  history_limit: 50          # 每次拉取最近多少条
  max_conversations: 10      # 最大同时处理的对话数
```

### task_tracking - 任务跟踪
```yaml
task_tracking:
  enabled: true
  storage_file: "~/.openclaw/state/lark-tasks.json"
  auto_create_tasks: true
  status_fields: ["待处理", "进行中", "待审核", "已完成", "已关闭"]
```

### response - 回复格式
```yaml
response:
  format: markdown           # markdown | text
  require_at_check: true     # 强制检查 @ 格式
  test_chat_id: "oc_xxxxx"  # 测试群 ID（正式消息先发这里验证）
  signature: "（本条消息由 Hermes 助手代发）"
  max_length: 2000
  multi_line_policy: markdown # 群聊多行强制 markdown
```

完整配置参考 `config/config.example.yaml`。

## 📁 项目结构

```
lark-message-manager/
├── SKILL.md              # 技能完整文档
├── README.md             # 本文件（用户快速入门）
├── config/
│   ├── config.yaml       # 当前配置
│   └── config.example.yaml  # 配置模板
├── scripts/
│   ├── message_agent.py          # 主循环
│   ├── message_agent_once.py     # 单次运行脚本
│   ├── intent_classifier.py      # 意图识别
│   ├── context_builder.py        # 上下文聚合
│   ├── action_planner.py         # 决策引擎
│   ├── task_tracker.py           # 任务跟踪
│   ├── responder.py              # 回复生成
│   ├── format_enforcer.py        # 格式验证
│   ├── lark_client.py            # lark-cli 封装
│   ├── config_loader.py          # 配置加载
│   ├── preflight_check.sh        # 前置检查
│   ├── auth_login_stable.sh      # 稳定授权
│   └── quickstart.sh             # 快速启动
├── references/
│   └── requirements.md   # 需求说明
└── .metadata.json        # 资产元数据（用于发布）
```

## 🔄 工作流示例

### 场景：模糊需求 → 澄清 → 跟进

```
用户: "那个客户反馈的问题怎么样了？"

Agent 处理:
1️⃣ 识别意图: 事项跟进
2️⃣ 上下文收集:
   - 最近对话中"客户反馈"出现在 2 天前
   - 关联到任务 TASK-001 "客户A登录问题"
   - 负责人: 张三（@张三）
3️⃣ 调查:
   - 查看 TASK-001 状态: "进行中"
   - 私聊张三: "客户A问题今天能解决吗？"
   - 张三: "已经修复，待测试"
4️⃣ 回复群聊:
   @张三 已确认，客户A登录问题已修复，目前待测试环节。
   预计今天下午测试完成，完成后我会同步大家。
   （本条消息由 Hermes 助手代发）

✅ 闭环完成
```

## 🛡️ 安全与权限

- **最小权限原则**：使用 `--as user` 发送（以用户身份，不是 bot）
- **发送前确认**：高风险操作（创建任务、@所有人）需要二次确认
- **测试群闸门**：正式消息先在测试群验证渲染效果

## ⚠️ 重要注意事项

- **不要同时运行多个实例**（消息处理无锁，会重复处理）
- **去重依赖轮询间隔**：建议 `interval_seconds >= 300`
- **任务 ID 持久化**：`storage_file` 路径必须持久
- **格式验证限制**：@结构化转换需 Lark post 格式支持

## 📊 状态存储

```
~/.openclaw/state/
├── lark-tasks.json              # 任务跟踪数据
└── lark-auto-reply-cooldown.json  # （旧版遗留）
```

## 🔮 后续规划

- **V2.1**：LLM 意图分类、自动私聊调查、任务板集成、多轮对话上下文
- **V2.2**：文档检索（RAG）、日程集成、审批流

## 📞 问题反馈

检查清单：
1. `lark-cli auth status` → token 有效？
2. 配置文件路径正确？`--config` 参数
3. 频道 ID 正确？用 `lark-cli im +chat-search` 验证
4. 日志文件 `~/.openclaw/logs/lark-manager.log`

---

**继承自**: [lark-auto-reply](/skills/lark-auto-reply) (by 张隆强)  
**Skill ID**: `lark-message-manager`  
**Category**: `automation`, `bot`, `feishu`, `lark`, `message-manager`  
**Version**: 2.0.0  
**License**: MIT  
**Author**: Zhang Longqiang
