# Lark Message Manager - Skill Dependencies

## Required System Tools
- `lark-cli` >= 1.0.0
- `python3` >= 3.9
- `bash`

## Python Packages (usually stdlib is enough)
No external PyPI packages required - uses only stdlib.

## Optional Integrations
- **Hermes Agent**: can call this skill via cronjob or background process
- **OpenAI/Claude**: for advanced intent classification (future)
