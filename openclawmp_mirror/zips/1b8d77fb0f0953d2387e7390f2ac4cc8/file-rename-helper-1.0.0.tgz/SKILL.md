---
name: file-rename-helper
description: 文件批量重命名工具 | 按规则批量重命名文件，支持日期编号、序列号、替换、添加前缀后缀
---

# 文件批量重命名工具

按规则批量重命名文件和文件夹，支持日期格式、序列号、关键词替换、前缀后缀添加。

## 适用场景

- 照片/文档批量编号
- 合同/报告按日期重命名
- 统一文件命名规范
- 项目文件整理

## 重命名规则

| 规则类型 | 说明 | 示例 |
|----------|------|------|
| 序列号 | 按顺序编号 | photo_001.jpg |
| 日期 | 提取/添加日期 | 2026-03-15_报告.pdf |
| 替换 | 关键词替换 | 删除"最终版" |
| 前缀 | 添加统一前缀 | [电机]_图纸.pdf |
| 后缀 | 添加后缀 | 图纸_v2.pdf |
| 大小写 | 统一大小写 | 全部小写 |
| 去空格 | 去除空格/特殊字符 | - |

## 使用方法

```powershell
# 按序列号重命名
file-rename batch -i "C:\photos\*" -rule "seq" -prefix "IMG_" -start 1

# 日期+序列号
file-rename batch -i "C:\docs\*" -rule "date-seq" -prefix "合同_"

# 关键词替换
file-rename replace -i "C:\files\*" -old "最终版" -new ""

# 统一添加前缀
file-rename prefix -i "C:\drawings\*" -prefix "[电机]_"

# 预览模式（不实际修改）
file-rename batch -i "C:\photos\*" -rule "seq" -preview
```

### 对话式

```
用户：帮我把这份文件夹里所有文件重命名为"日期_序号_原名"格式
```
