/**
 * 文件批量重命名工具
 */

const fs = require('fs');
const path = require('path');

/**
 * 生成序列号
 */
function padNumber(n, width) {
  return String(n).padStart(width, '0');
}

/**
 * 从文件名提取日期
 */
function extractDate(fileName) {
  const patterns = [
    /(\d{4}[-_]\d{1,2}[-_]\d{1,2})/,
    /(\d{8})/,
    /(\d{4})(\d{2})(\d{2})/
  ];
  for (const p of patterns) {
    const m = fileName.match(p);
    if (m) return m[1];
  }
  return null;
}

/**
 * 按规则重命名单个文件
 */
function applyRule(filePath, rule, options = {}) {
  const dir = path.dirname(filePath);
  const ext = path.extname(filePath);
  const base = path.basename(filePath, ext);
  const date = new Date();
  const dateStr = `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
  
  let newBase = base;
  
  switch (rule) {
    case 'seq':
      newBase = `${options.prefix || ''}${padNumber(options.counter || 1, options.width || 3)}${options.suffix || ''}`;
      break;
    case 'date-seq':
      newBase = `${dateStr}_${padNumber(options.counter || 1, 3)}${options.suffix || ''}`;
      break;
    case 'prefix':
      newBase = `${options.prefix || ''}${base}`;
      break;
    case 'suffix':
      newBase = `${base}${options.suffix || ''}`;
      break;
    case 'replace':
      newBase = base.replace(new RegExp(options.old || '', 'g'), options.new || '');
      break;
    case 'lowercase':
      newBase = base.toLowerCase();
      break;
    case 'uppercase':
      newBase = base.toUpperCase();
      break;
    case 'date-first':
      newBase = `${dateStr}_${base}`;
      break;
    case 'strip':
      newBase = base.replace(/\s+/g, '').replace(/[<>:"/\\|?*]/g, '');
      break;
  }
  
  return path.join(dir, newBase + ext);
}

/**
 * 批量预览
 */
function previewBatch(inputPattern, rule, options = {}) {
  const glob = require('glob');
  const files = glob.sync(inputPattern);
  
  if (files.length === 0) {
    console.log(`未找到匹配的文件: ${inputPattern}`);
    return;
  }
  
  const results = [];
  files.forEach((file, i) => {
    const newPath = applyRule(file, rule, { ...options, counter: (options.start || 1) + i });
    results.push({ old: path.basename(file), new: path.basename(newPath), same: file === newPath });
  });
  
  console.log(`\n预览：共${files.length}个文件\n`);
  results.forEach((r, i) => {
    const status = r.same ? '  ──' : '✅ ';
    console.log(`${status} ${r.old} → ${r.new}`);
  });
  
  const changed = results.filter(r => !r.same).length;
  console.log(`\n变更：${changed}/${results.length}个文件`);
  
  return results;
}

/**
 * 批量执行重命名
 */
function executeBatch(inputPattern, rule, options = {}) {
  const glob = require('glob');
  const files = glob.sync(inputPattern);
  
  if (files.length === 0) {
    console.log(`未找到匹配的文件: ${inputPattern}`);
    return;
  }
  
  let counter = options.start || 1;
  const results = [];
  
  files.forEach(file => {
    const newPath = applyRule(file, rule, { ...options, counter });
    
    if (file !== newPath) {
      try {
        fs.renameSync(file, newPath);
        results.push({ old: path.basename(file), new: path.basename(newPath), ok: true });
        console.log(`✅ ${path.basename(file)} → ${path.basename(newPath)}`);
      } catch (e) {
        results.push({ old: path.basename(file), new: path.basename(newPath), ok: false, error: e.message });
        console.error(`❌ ${path.basename(file)}: ${e.message}`);
      }
    }
    counter++;
  });
  
  const success = results.filter(r => r.ok).length;
  console.log(`\n完成：${success}/${results.length}个文件重命名成功`);
  return results;
}

// CLI
const [,, cmd, ...argsList] = process.argv;

const ARGS = {};
for (let i = 0; i < argsList.length; i += 2) {
  if (argsList[i]?.startsWith('-')) {
    ARGS[argsList[i].replace(/^-+/, '')] = argsList[i + 1] || true;
  }
}

const COMMANDS = {
  preview: () => previewBatch(ARGS.i, ARGS.rule || 'seq', ARGS),
  batch: () => executeBatch(ARGS.i, ARGS.rule || 'seq', ARGS),
  replace: () => executeBatch(ARGS.i, 'replace', { old: ARGS.old, new: ARGS.new }),
  prefix: () => executeBatch(ARGS.i, 'prefix', { prefix: ARGS.prefix }),
  suffix: () => executeBatch(ARGS.i, 'suffix', { suffix: ARGS.suffix }),
};

if (COMMANDS[cmd]) {
  COMMANDS[cmd]();
} else {
  console.log(`
文件批量重命名工具
==================
用法:
  rename preview -i "*.jpg" -rule seq -prefix "IMG_" -start 1
  rename batch -i "*.jpg" -rule seq -prefix "IMG_"
  rename replace -i "*.txt" -old "旧" -new "新"
  rename prefix -i "*" -prefix "[前缀]_"
  rename suffix -i "*" -suffix "_v2"

规则:
  seq       序列号
  date-seq  日期+序列号
  prefix    添加前缀
  suffix    添加后缀
  replace   替换关键词
  lowercase 转小写
  uppercase 转大写
  strip     去除特殊字符/空格
`);
}

module.exports = { applyRule, previewBatch, executeBatch };
