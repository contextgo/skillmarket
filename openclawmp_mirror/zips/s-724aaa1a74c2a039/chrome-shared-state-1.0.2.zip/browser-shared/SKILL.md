---
name: browser-shared
description: 复用本地Chrome配置和登录状态的浏览器自动化技能
metadata: {"openclaw":{"requires":{"bins":["curl","python3"]}}}
---

# Browser Shared Skill

复用本地 Chrome 的配置、插件和登录状态，进行浏览器自动化操作。

## 快速开始

### 步骤1: 先在Chrome登录
在日常使用的Chrome浏览器里登录目标网站

### 步骤2: 运行启动脚本
```bash
~/.openclaw/browser/start-chrome-debug.sh
```

### 步骤3: 连接并操作（正确方式！）
```python
from playwright.sync_api import sync_playwright

with sync_playwright() as p:
    browser = p.chromium.connect_over_cdp("http://127.0.0.1:9222")
    
    # ✅ 正确：复用已有context，不要新建！
    ctx = browser.contexts[0]  # 使用第一个context
    page = ctx.new_page()      # 在已有context新建页面
    
    page.goto("https://目标网站.com")
    time.sleep(5)
    
    print(page.title())
    print(page.inner_text("body")[:1000])
```

## ⚠️ 关键注意事项

### ❌ 错误方式（会丢失登录状态）
```python
# 不要这样！
browser = p.chromium.connect_over_cdp("http://127.0.0.1:9222")
ctx = browser.new_context()  # 新建context = 丢失登录状态
page = ctx.new_page()
```

### ✅ 正确方式
```python
# 正确！
browser = p.chromium.connect_over_cdp("http://127.0.0.1:9222")
ctx = browser.contexts[0]   # 使用已有context
page = ctx.new_page()        # 在已有context新建页面
```

## 常用网站URL

| 网站 | URL |
|------|-----|
| MiniMax订阅 | https://platform.minimaxi.com/user-center/payment/coding-plan |
| 飞书 | https://www.feishu.cn/ |
| 知乎热榜 | https://www.zhihu.com/hot |
| Mini4K电影 | https://www.mini4k.com/ |
| 青云梯代理 | https://qytcc03.qingyunti.pro/ |
| GitHub | https://github.com/ |

## 命令行工具

### 启动浏览器
```bash
~/.openclaw/browser/start-chrome-debug.sh
```

### 检查状态
```bash
curl -s http://127.0.0.1:9222/json | python3 -c "import json,sys; d=json.load(sys.stdin); print(f'页面数: {len(d)}')"
```

### 查看页面列表
```bash
curl -s http://127.0.0.1:9222/json | python3 -m json.tool | grep -E '"title"|"url"'
```

## 已验证可用场景

- ✅ MiniMax (需要登录)
- ✅ 飞书 (需要登录)
- ✅ 知乎 (需要登录)
- ✅ 青云梯 (需要登录)
- ✅ GitHub (需要登录)
- ✅ Mini4K电影 (无需登录)

## 故障排除

### 问题: 登录态丢失
解决: 
1. 在Chrome登录网站
2. 重新运行: ~/.openclaw/browser/start-chrome-debug.sh

### 问题: 页面空白
解决: 增加等待时间 time.sleep(8)

### 问题: 连接失败
解决: 先运行启动脚本
