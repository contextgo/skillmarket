---
name: api-doc-generator
description: 智能API文档生成工具，从源码、OpenAPI规范或自然语言描述自动生成结构化API技术文档
---

# API文档自动生成器

## 使用场景

当用户需要以下操作时使用本技能：
- 从代码或描述生成 API 接口文档
- 将 OpenAPI/Swagger 规范转换为可读文档
- 为 API 端点生成多语言调用示例
- 编写或完善错误码说明和业务状态码定义
- 生成 API 版本变更记录（Changelog）
- 审查和优化现有 API 文档的完整性

## 支持的输入源

### 1. 源代码解析
从以下语言的源代码中提取 API 信息：
- **JavaScript/TypeScript**：Express/Koa/Fastify/NestJS 路由、JSDoc/TSDoc 注释
- **Python**：FastAPI/Flask/Django 路由、docstring 注释
- **Go**：net/http 路由、godoc 注释
- **Java**：Spring Boot `@RequestMapping` 系列注解、Javadoc
- **Rust**：axum/actix-web 路由、`///` 文档注释

### 2. 规范文件解析
直接解析标准化的 API 描述文件：
- OpenAPI 3.0 / 3.1 规范（YAML/JSON）
- Swagger 2.0 规范
- GraphQL Schema（SDL）
- gRPC Proto 文件
- Postman Collection（v2.1）

### 3. 自然语言描述
根据用户提供的接口描述文字生成文档：
- 接口名称、HTTP 方法和路径
- 请求参数和请求体结构
- 响应格式和状态码
- 业务说明和备注

## 文档生成规范

### 端点文档结构

每个 API 端点的文档必须包含以下部分：

```
## [HTTP方法] [路径] - [接口名称]

### 概述
简要描述该接口的功能和用途，包含 1-3 句话的业务说明。

### 请求

#### 请求头
| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| Authorization | string | 是 | Bearer Token 认证 |
| Content-Type | string | 是 | application/json |

#### 路径参数
| 参数名 | 类型 | 必填 | 说明 | 示例 |
|--------|------|------|------|------|
| id | string | 是 | 用户唯一标识 | "usr_12345" |

#### 查询参数
| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| page | integer | 否 | 1 | 页码 |
| size | integer | 否 | 20 | 每页数量（最大100） |

#### 请求体
```json
{
  "name": "string, 必填, 用户昵称，2-20字符",
  "email": "string, 必填, 邮箱地址",
  "role": "string, 可选, 用户角色: admin|user|guest"
}
```

### 响应

#### 成功响应 (200 OK)
```json
{
  "code": 0,
  "message": "success",
  "data": {
    "id": "usr_12345",
    "name": "张三",
    "email": "zhangsan@example.com",
    "created_at": "2026-04-15T10:30:00Z"
  }
}
```

#### 错误响应
| 状态码 | 错误码 | 说明 |
|--------|--------|------|
| 400 | INVALID_PARAMETER | 请求参数校验失败 |
| 401 | UNAUTHORIZED | 未认证或 Token 过期 |
| 403 | FORBIDDEN | 无权限访问该资源 |
| 404 | USER_NOT_FOUND | 用户不存在 |
| 429 | RATE_LIMITED | 请求频率超限 |
```

### 多语言调用示例

为每个端点自动生成以下语言的调用示例：
- cURL
- Python (requests)
- JavaScript (fetch / axios)
- Go (net/http)
- Java (OkHttp)

示例要求：
- 使用真实的参数值（非占位符）
- 包含请求头设置
- 包含错误处理逻辑
- Python 示例使用 f-string 或 format
- JavaScript 示例使用 async/await

## 代码生成流程

### 步骤 1：解析输入

根据输入类型选择解析策略：
- 代码文件：识别框架和路由定义，提取路由信息
- OpenAPI 文件：解析 paths、components、security 等节点
- 自然语言：通过结构化提问引导用户提供完整信息

### 步骤 2：信息补全

检查提取的 API 信息是否完整，缺失项向用户确认：
- 缺少请求参数类型 → 提示用户提供或推断合理类型
- 缺少响应示例 → 根据参数结构推断响应格式
- 缺少错误码定义 → 提供常见错误码模板
- 缺少认证方式 → 询问是否需要认证章节

### 步骤 3：文档生成

按照上述文档结构规范生成完整文档：
- 按业务模块分组端点
- 生成目录和快速导航
- 添加通用说明（认证方式、通用参数、通用响应格式）
- 生成多语言调用示例
- 创建错误码汇总表

### 步骤 4：质量检查

对生成的文档执行以下检查：
- 所有端点是否有完整的请求/响应示例
- 参数类型是否一致（代码中 string 但文档写 int）
- 状态码是否完整（至少覆盖 200/400/401/403/404/500）
- 示例数据是否合理（不使用 "foo"、"bar" 等无意义值）
- 多语言示例是否可执行

## 高级功能

### 版本变更记录生成

当用户提供新旧两版 API 规范时，自动生成变更记录：
- 新增端点
- 废弃端点
- 参数变更（新增/删除/类型变更/重命名）
- 响应结构变更
- 破坏性变更标注

### API 设计建议

根据 RESTful 最佳实践审查 API 设计：
- 路径命名是否使用名词复数（`/users` 而非 `/getUsers`）
- HTTP 方法是否语义正确（GET 不修改数据，POST 不用于查询）
- 是否合理使用状态码（201 创建、204 删除成功）
- 分页参数是否标准化（page/size 或 cursor）
- 是否需要 HATEOAS 链接
- 版本号策略建议（URL path vs Header）

### GraphQL Schema 文档化

对于 GraphQL API，生成以下文档：
- Schema 概览（类型、查询、变更、订阅统计）
- 每个 Type 的字段说明和类型定义
- 查询和变更的参数及返回类型
- 枚举值说明
- 权限和复杂度标注
- 分页连接类型说明

## 输出格式

- Markdown（默认，适合 Git 仓库和文档站）
- HTML（适合独立文档站部署）
- OpenAPI 3.1 YAML（反规范化输出）
- Postman Collection JSON
