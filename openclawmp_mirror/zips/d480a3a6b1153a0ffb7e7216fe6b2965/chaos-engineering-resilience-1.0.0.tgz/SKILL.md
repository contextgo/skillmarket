---
name: chaos-engineering-resilience
description: "Agent 系统混沌工程实践指南"
version: 1.0.0
---

混沌工程：验证 Agent 系统容错能力。

## 故障注入

### 网络故障
```bash
tc qdisc add dev eth0 root netem delay 500ms    # 延迟
tc qdisc add dev eth0 root netem loss 30%        # 丢包
iptables -A INPUT -s <ip> -j DROP               # 断网
```

### 进程故障
```bash
pkill -f "agent_worker" --signal SIGKILL
stress --vm 1 --vm-bytes 512M --timeout 30s
```

### 资源耗尽
```bash
stress --cpu 4 --timeout 30s
fallocate -l 10G /tmp/fill.img
```

## 容错验证清单
- [ ] API 超时自动重试
- [ ] 数据库断线重连
- [ ] 消息队列不丢消息
- [ ] 缓存不可用降级
- [ ] 进程崩溃自动重启
- [ ] 内存溢出不丢关键数据
- [ ] 网络分区最终一致

## 恢复验证
每次注入后检查：告警触发、自动恢复时间、数据完整性、用户感知。

先非生产环境开始，逐步扩展到灰度。记录每次实验结果。

