# 网络设备监控

监控内网网络设备和服务器状态，自动发现异常并推送告警。

## 功能

- **Ping 监控**：ICMP 连通性 + 延迟检测
- **SNMP 监控**：华为/H3C 等交换机 SNMP 数据采集
- **端口检测**：TCP 端口连通性检查
- **SSL 检查**：HTTPS 证书过期预警
- **历史记录**：状态变化记录，支持飞书多维表格
- **告警通知**：飞书消息即时通知

## 监控指标

| 指标 | 说明 | 阈值 |
|------|------|------|
| Ping 延迟 | ICMP 响应时间 | >1000ms 警告 |
| 端口连通性 | TCP 连接状态 | 不通 → 严重 |
| SNMP 可达 | 设备响应 SNMP query | 失败 → 严重 |
| SSL 证书剩余天数 | HTTPS 证书有效期 | <30天 → 警告 |

## 使用方法

```powershell
# 运行一次完整检查
.\scripts\monitor.ps1 -RunOnce

# 后台守护进程模式
.\scripts\monitor.ps1 -AsService -Interval 30

# 测试告警
.\scripts\monitor.ps1 -TestAlert
```

## 配置

编辑 `config/settings.json` 配置监控目标、SNMP 团体名、飞书通知参数。

## 版本历史

### v1.0.3 (2026-03-26)
- 改进：敏感信息配置项改为 `<placeholder>` 格式，用户一目了然

### v1.0.2 (2026-03-26)
- 安全修复：移除 config/settings.json 中硬编码的飞书 app_secret、access_token、SNMP 团体名
- 修复：feishu-bitables.ps1 不再硬编码 app_id，改为从配置文件读取

### v1.0.1
- 内部优化

## 依赖

- PowerShell 5.1+
- 可选：nmap（端口扫描）、OpenSSL（SSL 检查）
- 飞书多维表格（历史记录，可选）