# Feishu Card Schema 2.0 参考

## Header

```json
{
  "template": "<color>",
  "title": {"tag": "plain_text", "content": "标题"},
  "subtitle": {"tag": "plain_text", "content": "副标题"}
}
```

**可用颜色**：blue, wathet, turquoise, green, yellow, orange, red, carmine, violet, purple, indigo, grey

## Body Elements

### markdown — 富文本（最常用）
```json
{"tag": "markdown", "content": "**粗体** *斜体* ~~删除线~~\n- 列表项\n> 引用\n[链接](url)\n`代码`"}
```

支持的 markdown 子集：bold, italic, strikethrough, links, lists, blockquotes, inline code, code blocks（用 ``` 围栏）

### hr — 分割线
```json
{"tag": "hr"}
```

### column_set — 多列布局
```json
{
  "tag": "column_set",
  "flex_mode": "bisect",
  "columns": [
    {
      "tag": "column", "width": "weighted", "weight": 1,
      "elements": [{"tag": "markdown", "content": "左列"}]
    },
    {
      "tag": "column", "width": "weighted", "weight": 1,
      "elements": [{"tag": "markdown", "content": "右列"}]
    }
  ]
}
```

**flex_mode**: none（不换行）, bisect（二等分）, trisect（三等分）, flow（流式换行）

### image — 图片
```json
{"tag": "img", "img_key": "img_v3_xxx", "alt": {"tag": "plain_text", "content": "描述"}}
```
需先通过 upload API 获取 img_key。

### div — 文本块（带左侧图标）
```json
{
  "tag": "div",
  "text": {"tag": "lark_md", "content": "正文内容"},
  "icon": {"tag": "standard_icon", "token": "info-circle_outlined"}
}
```

## 完整卡片结构

```json
{
  "schema": "2.0",
  "config": {"wide_screen_mode": true},
  "header": {
    "template": "blue",
    "title": {"tag": "plain_text", "content": "标题"},
    "subtitle": {"tag": "plain_text", "content": "副标题"}
  },
  "body": {
    "elements": [
      {"tag": "markdown", "content": "内容"},
      {"tag": "hr"},
      {"tag": "markdown", "content": "更多内容"}
    ]
  }
}
```

## 常见踩坑

1. **content 必须二次序列化**：发送 API 的 `content` 字段值是 `json.dumps(card)` 后的字符串，不是对象
2. **Schema 2.0 不支持 `note` 标签**：用 markdown 斜体替代脚注效果
3. **卡片不支持 @人**：需要用普通消息实现 @
4. **shell 转义地狱**：用 Python 脚本发送，不要用 curl + 嵌套 JSON
5. **markdown 子集有限**：不支持表格、不支持 HTML、不支持 heading（用 **粗体** 替代）
6. **图片需 img_key**：不能直接用 URL，需要先 upload
