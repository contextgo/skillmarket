#!/usr/bin/env python3
"""
send_card.py — 飞书卡片消息发送脚本

Usage:
    python3 send_card.py --chat-id <chat_id> --card-file <card.json>
    python3 send_card.py --chat-id <chat_id> --card '<json_string>'
    echo '<json>' | python3 send_card.py --chat-id <chat_id> --stdin

Environment:
    FEISHU_APP_ID       — 飞书应用 App ID
    FEISHU_APP_SECRET   — 飞书应用 App Secret

    If not set, the script will attempt to read from OpenClaw config:
    ~/.openclaw/openclaw.json -> feishu.appId / feishu.appSecret
"""

import argparse
import json
import os
import sys
import urllib.request
import urllib.error

FEISHU_API = "https://open.feishu.cn"


def load_openclaw_feishu_config():
    """Try to load feishu credentials from OpenClaw config."""
    config_path = os.path.expanduser("~/.openclaw/openclaw.json")
    if not os.path.exists(config_path):
        return None, None
    try:
        with open(config_path) as f:
            config = json.load(f)
        # Try channels.feishu first, then top-level feishu
        feishu = config.get("channels", {}).get("feishu", {})
        if not feishu:
            feishu = config.get("feishu", {})
        return feishu.get("appId"), feishu.get("appSecret")
    except Exception:
        return None, None


def get_credentials():
    """Get app_id and app_secret from env or config."""
    app_id = os.environ.get("FEISHU_APP_ID")
    app_secret = os.environ.get("FEISHU_APP_SECRET")
    if not app_id or not app_secret:
        app_id, app_secret = load_openclaw_feishu_config()
    if not app_id or not app_secret:
        print("ERROR: FEISHU_APP_ID and FEISHU_APP_SECRET must be set", file=sys.stderr)
        sys.exit(1)
    return app_id, app_secret


def get_tenant_token(app_id, app_secret):
    """Obtain tenant_access_token."""
    url = f"{FEISHU_API}/open-apis/auth/v3/tenant_access_token/internal"
    payload = json.dumps({"app_id": app_id, "app_secret": app_secret}).encode()
    req = urllib.request.Request(url, data=payload, headers={"Content-Type": "application/json"})
    try:
        resp = json.loads(urllib.request.urlopen(req, timeout=10).read())
    except urllib.error.URLError as e:
        print(f"ERROR: Failed to get token: {e}", file=sys.stderr)
        sys.exit(1)
    if resp.get("code") != 0:
        print(f"ERROR: Token request failed: {resp}", file=sys.stderr)
        sys.exit(1)
    return resp["tenant_access_token"]


def send_card(token, chat_id, card_dict):
    """Send interactive card message to a chat."""
    url = f"{FEISHU_API}/open-apis/im/v1/messages?receive_id_type=chat_id"
    payload = json.dumps({
        "receive_id": chat_id,
        "msg_type": "interactive",
        "content": json.dumps(card_dict)  # 关键：card 必须二次序列化为字符串
    }).encode()
    req = urllib.request.Request(url, data=payload, headers={
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    })
    try:
        resp = json.loads(urllib.request.urlopen(req, timeout=15).read())
    except urllib.error.URLError as e:
        print(f"ERROR: Failed to send card: {e}", file=sys.stderr)
        sys.exit(1)
    if resp.get("code") != 0:
        print(f"ERROR: Send failed: {resp.get('msg', resp)}", file=sys.stderr)
        sys.exit(1)
    print(json.dumps(resp, indent=2, ensure_ascii=False))
    return resp


def main():
    parser = argparse.ArgumentParser(description="Send Feishu interactive card message")
    parser.add_argument("--chat-id", required=True, help="Target chat_id (oc_xxx)")
    parser.add_argument("--card-file", help="Path to card JSON file")
    parser.add_argument("--card", help="Card JSON as string argument")
    parser.add_argument("--stdin", action="store_true", help="Read card JSON from stdin")
    args = parser.parse_args()

    # Load card JSON
    if args.stdin:
        card_str = sys.stdin.read()
    elif args.card_file:
        with open(args.card_file) as f:
            card_str = f.read()
    elif args.card:
        card_str = args.card
    else:
        print("ERROR: Provide --card-file, --card, or --stdin", file=sys.stderr)
        sys.exit(1)

    try:
        card_dict = json.loads(card_str)
    except json.JSONDecodeError as e:
        print(f"ERROR: Invalid JSON: {e}", file=sys.stderr)
        sys.exit(1)

    app_id, app_secret = get_credentials()
    token = get_tenant_token(app_id, app_secret)
    send_card(token, args.chat_id, card_dict)


if __name__ == "__main__":
    main()
