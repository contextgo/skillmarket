---
name: feishu-send-file
description: "通过飞书 REST API 向群组或用户发送文件。适用于用户明确要求发送文件、附件或文档到飞书聊天/群组的场景。"
version: "1.0.1"
---

# 飞书发送文件技能

## 功能说明

本技能提供向飞书群聊或单聊发送文件的能力。支持多种文件类型（文档、图片、压缩包等），自动处理上传和发送流程。

## 使用场景

- 用户请求："把这个文件发到群里"
- 用户请求："send file to feishu"
- 用户请求："发个附件给张三"

## 触发词

中文：
- "发文件到飞书"
- "把这个文件发到群里"
- "发个附件"

英文：
- "send file to feishu"
- "send document to feishu group"

## 注意事项

**不发以下内容**：
- ❌ 文本消息 → 使用 `message` 工具
- ❌ 图片/截图 → 使用 `feishu-screenshot` 技能
- ❌ 文档读取 → 使用 `feishu-doc` 技能

## 技术细节

- 调用飞书 `im/v1/files` 上传接口
- 使用 `chat_id` 或 `open_id` 指定接收者
- 文件大小限制：100MB
- 支持格式：所有飞书支持的文件类型

## 示例调用

```
用户：把这个PDF发到项目群
Agent：调用 feishu-send-file，传入 chat_id=oc_xxx, file_path=/path/to/file.pdf
```

---

*文档版本：1.0.1*  
*最后更新：2026-04-01*
