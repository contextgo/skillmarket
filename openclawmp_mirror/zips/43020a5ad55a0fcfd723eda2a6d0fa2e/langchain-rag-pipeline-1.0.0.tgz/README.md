# LangChain RAG Pipeline

## Overview
Complete LangChain RAG (Retrieval-Augmented Generation) pipeline guide.

## Core Architecture

### 1. Document Loading & Splitting
- RecursiveCharacterTextSplitter(chunk_size=1000, overlap=200) for documents
- Language splitters for code (by function/class)
- MarkdownHeaderTextSplitter for tables

### 2. Embedding Models
| Model | Dimensions | Cost | Use Case |
|-------|-----------|------|----------|
| text-embedding-3-small | 1536 | Low | General |
| text-embedding-3-large | 3072 | Medium | High precision |
| BGE-M3 | 1024 | Free | Multilingual |

### 3. Vector Databases
- **Pinecone**: Managed, auto-scale
- **Chroma**: Local dev, zero config
- **Weaviate**: Hybrid search (vector + BM25)
- **Qdrant**: High performance, gRPC

### 4. Retrieval Strategies
- Basic: top-k similarity
- Advanced: MMR + multi-path recall
- High-end: Re-ranking + query rewriting

### 5. Generation
- stuff: Few docs, direct concat
- map_reduce: Many docs, batch process
- refine: Iterative, highest quality

## Performance Tips
- Embedding cache: reduce recomputation 80%
- Hybrid retrieval: vector + keyword, recall +30%
- Metadata filtering: scope by date/source/category
- Streaming: TTFB reduced 70%

## Common Issues
- Hallucination: chain-of-citation, force source attribution
- Long docs: hierarchical summary (summarize→chunk→embed)
- Multi-turn: ConversationBufferMemory + entity memory
