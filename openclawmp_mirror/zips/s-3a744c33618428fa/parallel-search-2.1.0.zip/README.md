metadata:
  {
    "openclaw":
      {
        "emoji": "🔎",
        "requires": { },
        "install": [],
      },
  }


# 并行整合搜索 v2.1

5通道并行搜索编排。本技能是 multi-search-engine + web-search-exa 的升级整合，加载后不需要再加载这两个技能。

**何时使用本技能**：当搜索需要≥2次工具调用、多源交叉验证、或需要并行加速时。如果只需要1次 WebSearch 就能回答，不需要加载本技能。

## 30秒决策速查

```
先判断：需要搜索吗？
│
├─ 不需要搜索（历史/定义/常识/编码概念/数学原理）→ 直接用知识回答，不调用任何工具
│
└─ 需要搜索 → 搜什么？
   ├─ 简单事实(1个明确答案) → WebSearch 1次，结束（不需要本技能）
   ├─ 需要确认/2-3个源     → WebSearch + Exa 并行2次
   ├─ 技术/代码             → WebSearch + CodeContext 并行2次
   ├─ 中文深度              → WebSearch×2 + WebFetch(百度+必应) + Exa(deep)，5-7次
   ├─ 英文深度              → WebSearch×2 + WebFetch(Google+Bing) + Exa(deep)，5-7次
   ├─ 全面研究              → 全通道多轮，10-40次
   ├─ 最新新闻              → WebSearch(时间过滤) + Exa(livecrawl) + WebFetch(头条URL)
   ├─ 隐私搜索              → WebFetch(DDG+Startpage+Brave URL)
   ├─ 数学/科学             → WebFetch(WolframAlpha URL)
   ├─ 微信/头条/需JS        → browser_use_desktop（单独一轮，不可并行）
   └─ 不确定                → WebSearch + Exa 各1次，看结果再决定
```

## 核心规则（必须遵守）

1. **先判断是否需要搜索**。历史事实、基本概念、编码知识、数学原理等不需要搜索，直接用知识回答
2. **每轮最多10个并行调用**，超出自动分轮
3. **孤立工具必须单独一轮**，不可与任何工具并行。孤立工具包括：`browser_use_desktop`、`Write`、`Edit`、`desktop_terminal_execute`
4. **通道A结果可级联触发通道B**，对高价值URL提取全文（级联条件见下文）
5. **充分性不足时最多补搜2轮**，避免无限循环
6. **L1查询不改写**，直接用原始查询；L2+按规则生成中英文变体

## 五通道速查表

| 通道 | 工具 | 核心能力 | 延迟 | 并行? | topk/参数建议 |
|------|------|----------|------|-------|-------------|
| **A** | `WebSearch(query, topk)` | 关键词搜索API，site:/filetype:运算符 | 2-4s | ✅ | L1:8, L2:10, L3:12, L4:16 |
| **B** | `WebFetch(url, prompt)` | URL全文提取 + 17引擎URL模板定向搜索 | 3-8s | ✅ | prompt按场景定制（见下文） |
| **C** | `mcp_exa_web_search_exa(query, ...)` | 语义搜索，auto/fast/deep，livecrawl，category | 2-5s | ✅ | 自然语言问句效果最好 |
| **D** | `mcp_exa_get_code_context_exa(query, tokensNum)` | GitHub/SO/Docs 代码片段+API用法 | 2-5s | ✅ | L1:3000, L2:5000, L3:10000, L4:20000 |
| **E** | `browser_use_desktop(task)` | JS渲染页面：微信搜索/头条/集思录 | 10-30s | ❌孤立 | 详细任务描述 |

## 执行流程

### Step 0: 是否需要搜索（前置判断，与系统搜索策略对齐）

**绝不搜索**（直接用知识回答）：
- 编码概念（Python的for循环、React hooks用法）
- 基本定义（三原色、光合作用）
- 既定事实（法国首都、地球到月球距离）
- 历史事件（二战结束时间、宪法签署日期）
- 数学概念（勾股定理、微积分基本定理）
- 创建项目（做一个网站克隆版）
- 闲聊（最近怎么样）

**立即搜索**（信息每天/周/月变化）：
- 实时数据（天气、股价、汇率）
- 最近事件结果（比赛结果、选举结果）
- 最新发布（新产品、新政策）

**可能搜索**（用知识回答，但提供搜索选项）：
- 每年变化的信息（年度排名、市场数据）
- 2025年1月后的事件

→ 判定为"绝不搜索"时，直接回答，**不进入后续Step**。

### Step 1: 意图分类（在脑中判断）

| 意图 | 识别关键词 | 默认通道 |
|------|-----------|---------|
| **FACT** | 疑问词+具体实体（需实时数据） | A |
| **NEWS** | 今天/最新/刚刚/breaking | A+B+C(livecrawl) |
| **RESEARCH** | 分析/研究/对比/趋势/市场/行业 | A+B+C |
| **TECH** | API/SDK/函数/报错/代码/编程 | A+D |
| **PRIVACY** | 隐私/无追踪/anonymous | B(DDG+Startpage) |
| **MATH** | 计算/公式/定理/方程（需计算引擎） | B(WolframAlpha) |
| **LOCAL** | 附近/本地/地址 | A+C |
| **RENDER** | 微信公众号/头条/集思录/小红书 | E(孤立)→A+C |

### Step 2: 复杂度评估

```
Score = 2×实体数 + 2×分析维度数 + 1×时间敏感度(0-3) + 2×深度关键词数

实体数：查询中的公司/产品/人物/技术名称数量（最低0）
分析维度数：需要分析的角度数（市场规模=1维，+竞争格局=2维，+趋势=3维...）
时间敏感度：不敏感=0, 周级=1, 日级=2, 小时级=3
深度关键词数："深入""全面""详细""综合""报告"等词的数量

L1(0-4分):  1-2次调用，1轮      → "今天天气" "最新汇率"
L2(5-8分):  3-5次调用，1-2轮    → "Python asyncio性能对比" "iPhone 16评测"
L3(9-13分): 6-8次调用，2-3轮    → "AI芯片市场竞争格局分析"
L4(14+分):  8-10次调用，3-5轮   → "深入研究全球AI芯片市场规模竞争趋势投资"
```

> **与v2.0的差异**：dimension_count权重从3降为2，entity_count最低从1降为0，使得简单查询（如"今天天气"：0实体+0维度+2时间=2分）能正确落入L1。

### Step 3: 查表获取通道组合

**通道激活决策矩阵（意图×复杂度→通道×次数）**：

| | L1 | L2 | L3 | L4 |
|---|---|---|---|---|
| **FACT** | A×1 | A×1+C×1 | A×2+C×1+B×2 | A×2+B×3+C×2 |
| **NEWS** | A×1+C×1 | A×1+B×2+C×1 | A×2+B×3+C×2 | A×3+B×4+C×2+E×1 |
| **RESEARCH** | A×1+C×1 | A×2+B×2+C×1 | A×3+B×3+C×2 | A×3+B×5+C×3 |
| **TECH** | D×1 | A×1+D×1+C×1 | A×1+D×2+C×1+B×1 | A×2+D×2+C×1+B×2 |
| **PRIVACY** | B×1 | B×2 | B×3 | B×3+C×1 |
| **MATH** | B×1 | B×1+A×1 | B×1+A×1+C×1 | B×1+A×2+C×1 |
| **LOCAL** | A×1 | A×1+C×1 | A×2+C×1+B×1 | A×2+B×2+C×2 |
| **RENDER** | E×1 | E×1→A×1+C×1 | E×1→A×2+B×2+C×1 | E×1→A×2+B×3+C×2 |

> RENDER类型：E先单独一轮执行（孤立工具），然后其他通道并行执行。

### Step 4: 查询改写（L2+才执行）

L1不改写，直接用原始查询。L2+按以下规则生成变体：

| 变体类型 | 生成方法 | 用于 |
|----------|---------|------|
| **中文关键词** | 原始查询拆分核心词 + 加年份"2025 2026" + 加意图后缀（研究→"市场规模 竞争格局"，新闻→"最新消息"） | 通道A |
| **英文翻译** | 翻译核心概念 + 加英文行业术语 | 通道A |
| **语义问句** | 转为完整自然语言问句："What is the current state and key trends of {topic}?" | 通道C (Exa) |
| **专项变体** | TECH→加"implementation example code"；NEWS→加时间限定；MATH→保持原样 | 通道D/B |

**改写示例**：
```
原始查询："AI芯片市场分析"
→ 中文变体1: "AI芯片 市场规模 2025 2026"
→ 中文变体2: "AI芯片 竞争格局 头部企业 市场份额"
→ 英文变体:  "AI chip semiconductor market size forecast 2026"
→ 语义问句:  "What is the current market size, competitive landscape, and growth forecast for AI chips in 2025-2026?"
```

### Step 5: 分轮并行执行

**分轮规则**：
1. 孤立工具(E/Write/Edit/terminal)单独成轮，放在最前
2. 其他工具按优先级填充，每轮不超过10个
3. L2+时，最后追加一个级联轮

**通道优先级**（高→低）：A(5) > C(4) = D(4) > B(3) > E(2)

**级联触发条件**（通道A结果→通道B全文提取）：
满足以下任一条件的URL值得级联：
- 来源域名属于 T1(政府/学术) 或 T2(权威媒体)
- snippet长度 > 200字，内容与查询高度相关
- 标题含"报告/分析/研究/白皮书/data/report/analysis/study"

### Step 6: 结果聚合

收到所有结果后：
1. **URL去重**：相同URL保留内容最丰富的版本（全文>片段>代码>数据）
2. **交叉验证**：同一事实≥2个通道确认→✅高可信；仅1个通道→⚠️待验证；通道间矛盾→❌需说明
3. **来源分级**：
   - T1(1.0分): .gov/.edu/arxiv/nature/SEC → 政府/学术/官方
   - T2(0.8分): reuters/bloomberg/wsj/xinhuanet → 权威媒体
   - T3(0.6分): gartner/mckinsey/statista/36kr → 咨询/行业
   - T4(0.3分): reddit/知乎/medium/论坛 → 社区/聚合
4. **时效排序**：新闻优先24h内，趋势优先3月内，事实不限时间

### Step 7: 充分性检查

如果结果明显不足（关键问题没回答/数据太少/只有单一来源），且还没补搜过2次：
→ 识别缺失维度 → 生成针对性补充查询 → 回到Step 3只激活缺失通道

## 17引擎URL模板（通道B使用）

通道B的独立模式：用 `WebFetch(url, prompt)` 直接访问引擎URL。

**⚠️ 调用前需要对query做URL编码**（空格→+，中文→%XX）。

| 场景 | 引擎URL | 访问方式 |
|------|---------|---------|
| 百度 | `https://www.baidu.com/s?wd={query}` | WebFetch |
| 必应中文 | `https://cn.bing.com/search?q={query}&ensearch=0` | WebFetch |
| 必应英文 | `https://cn.bing.com/search?q={query}&ensearch=1` | WebFetch |
| Google | `https://www.google.com/search?q={query}` | WebFetch |
| DuckDuckGo | `https://duckduckgo.com/html/?q={query}` | WebFetch |
| Startpage | `https://www.startpage.com/sp/search?query={query}` | WebFetch |
| Brave | `https://search.brave.com/search?q={query}` | WebFetch |
| WolframAlpha | `https://www.wolframalpha.com/input?i={query}` | WebFetch |
| 微信搜索 | `https://wx.sogou.com/weixin?type=2&query={query}` | ⚠️需browser(通道E) |
| 头条 | `https://so.toutiao.com/search?keyword={query}` | ⚠️需browser(通道E) |

Google时间过滤：URL末尾加 `&tbs=qdr:h`(1小时) `&tbs=qdr:d`(24h) `&tbs=qdr:w`(1周) `&tbs=qdr:m3`(3月)

### WebFetch prompt模板（按场景选择）

**搜索引擎结果页**：
```
提取搜索结果列表，每条包含：标题、URL链接、摘要、发布时间。忽略广告。返回前10条。
```

**全文提取（研究类）**：
```
提取关键数据点（市场规模、增长率、份额等数字）、主要观点、数据来源和时间。与"{query}"直接相关的段落优先。
```

**全文提取（新闻类）**：
```
提取核心事件(谁/什么/何时/何地/为何/如何)、关键引语、发布时间、相关背景。
```

**全文提取（技术类）**：
```
提取代码示例、API参数说明、版本兼容性、常见问题和解决方案。
```

## Exa参数速查（通道C）

| 场景 | type | numResults | livecrawl | category |
|------|------|-----------|-----------|----------|
| 快速 | fast | 3-5 | fallback | — |
| 标准 | auto | 8 | fallback | — |
| 深度 | deep | 10-15 | fallback | — |
| 实时新闻 | auto | 8 | **preferred** | — |
| 学术论文 | deep | 10 | fallback | **research paper** |
| 公司信息 | auto | 5 | fallback | **company** |
| 人物搜索 | auto | 5 | fallback | **people** |

> Exa对自然语言效果最好。避免关键词堆砌，用完整问句。
> category参数来自工具签名，可选值仅限上述三个。

## 降级策略（通道失败时）

| 主通道失败 | 降级到 |
|-----------|--------|
| A(WebSearch) | → B(WebFetch访问Google URL) + C(Exa) |
| B(WebFetch) | → C(Exa, livecrawl:preferred) |
| C(Exa MCP) | → A(WebSearch多次) + B(多引擎URL) |
| D(Code MCP) | → A(WebSearch, site:github.com 和 site:stackoverflow.com) |
| E(Browser) | → B(WebFetch尝试) → 标记需用户手动访问 |

## 完整并行调用示例

### 示例1: L1简单搜索（1次调用，不需要本技能）

```
WebSearch(query="今天上海天气", topk=8)
```

### 示例2: L2标准搜索（3次并行）

```
# 同一轮并行发出：
WebSearch(query="Python asyncio vs threading 性能对比 2025", topk=10)
mcp_exa_web_search_exa(query="When should I use asyncio vs threading in Python and what are the performance differences?", numResults=8, type="auto")
mcp_exa_get_code_context_exa(query="Python asyncio threading benchmark comparison example", tokensNum=5000)
```

### 示例3: L4深度研究（多轮）

```
# 第1轮并行（≤10次）：
WebSearch(query="AI芯片 市场规模 2025 2026", topk=16)
WebSearch(query="AI芯片 竞争格局 头部企业 市场份额", topk=16)
WebSearch(query="AI chip semiconductor market size forecast 2026", topk=16)
WebFetch(url="https://www.baidu.com/s?wd=AI%E8%8A%AF%E7%89%87+%E5%B8%82%E5%9C%BA%E8%A7%84%E6%A8%A1", prompt="提取搜索结果列表...")
WebFetch(url="https://cn.bing.com/search?q=AI%E8%8A%AF%E7%89%87+%E7%AB%9E%E4%BA%89%E6%A0%BC%E5%B1%80&ensearch=0", prompt="提取搜索结果列表...")
mcp_exa_web_search_exa(query="What is the current market size, competitive landscape, and growth forecast for AI chips in 2025-2026?", numResults=12, type="deep")
mcp_exa_web_search_exa(query="AI semiconductor competitive landscape NVIDIA AMD Intel market share", numResults=8, type="deep", category="company")
mcp_exa_web_search_exa(query="AI chip technology trends investment opportunities 2025", numResults=8, type="deep", category="research paper")
WebFetch(url="https://www.google.com/search?q=AI+chip+market+2026&tbs=qdr:m3", prompt="提取搜索结果列表...")

# 第2轮级联（对第1轮高价值URL提取全文）：
WebFetch(url="T1/T2来源URL_1", prompt="提取关键数据点...")
WebFetch(url="T1/T2来源URL_2", prompt="提取竞争格局数据...")
WebFetch(url="含报告/分析的URL_3", prompt="提取技术趋势...")
```

### 示例4: 含通道E的搜索（分2轮）

```
# 第1轮（孤立，通道E单独执行）：
browser_use_desktop(task="打开 https://wx.sogou.com/weixin?type=2&query=大模型落地 ，提取前10条结果和前3篇全文")

# 第2轮（并行，其他通道）：
WebSearch(query="大模型落地 应用案例 2026", topk=10)
mcp_exa_web_search_exa(query="大语言模型企业落地实践最新案例", numResults=8, type="auto", livecrawl="preferred")
```

## 与其他技能的关系

- **multi-search-engine**：本技能已整合其17引擎URL模板和搜索策略，加载本技能后**不需要再加载**
- **web-search-exa**：本技能已整合其Exa参数策略，加载本技能后**不需要再加载**
- **unified-market-research**：上游调用者。其数据采集步骤可使用本技能的并行搜索替代单一WebSearch