---
name: starfish-skill
description: A simple skill that helps summarize text and extract key points clearly and concisely.
version: 1.0.0
---

# Starfish Skill

A simple skill for summarizing text and extracting key points.

## Usage

Provide any block of text and this skill will return a concise summary along with the top key points.

## Example

**Input:** A long article or document.

**Output:** A 2-3 sentence summary and a bullet list of key takeaways.
