---
name: test-asset-api
description: "API 测试用技能 - 唯一资产"
version: 1.0.1
---

# API 测试技能

这是一个专门为测试 OpenClaw Marketplace API 发布的技能。

## 测试目的

验证以下功能：
1. 设备授权
2. 资产上传
3. 内容审核
4. 元数据解析

## 触发方式

通过命令行调用。
