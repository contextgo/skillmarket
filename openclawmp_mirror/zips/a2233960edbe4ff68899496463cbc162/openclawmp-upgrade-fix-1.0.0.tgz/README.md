# OpenClawMP Upgrade Fix

一个 OpenClaw Skill，用于诊断和修复 openclawmp CLI 升级过程中的配置问题。

## 功能

- 🔍 **版本检测** - 自动检测当前 CLI 版本
- ⚡ **升级检查** - 判断是否需要升级
- 🔧 **自动修复** - 一键修复常见升级问题
- ✅ **配置验证** - 验证升级后的配置是否正确
- 📦 **配置迁移** - 自动迁移旧配置到新位置

## 安装

### 方式一：直接克隆到 skills 目录

```bash
git clone <repository-url> ~/.stepclaw/workspace/skills/openclawmp-upgrade-fix
```

### 方式二：手动下载

1. 下载本 Skill 的压缩包
2. 解压到 `~/.stepclaw/workspace/skills/openclawmp-upgrade-fix/`

## 使用方法

### 快速开始

在 OpenClaw 对话中直接询问：

```
帮我检查 openclawmp CLI 是否需要升级
```

或

```
修复我的 openclawmp 配置问题
```

### 手动运行修复脚本

**Windows (PowerShell):**
```powershell
~/.stepclaw/workspace/skills/openclawmp-upgrade-fix/scripts/fix-upgrade.ps1
```

**macOS/Linux (Bash):**
```bash
~/.stepclaw/workspace/skills/openclawmp-upgrade-fix/scripts/fix-upgrade.sh
```

## 解决的问题

### 版本 0.1.4 → 1.0.2+ 升级问题

| 问题 | 说明 | 修复方式 |
|------|------|----------|
| `oauth` 命令不存在 | 旧版本没有 oauth 命令 | 升级到 1.0.0+ |
| API 端点错误 | openclawmp.cc → openclawmp.stepfun.com | 自动更新配置 |
| 配置位置变更 | ~/.openclaw/ → ~/.stepclaw/ | 自动迁移配置 |
| 认证失效 | Token 需要重新获取 | 重新运行 oauth login |

## 诊断流程

Skill 会按以下顺序进行诊断：

1. **检测 CLI 版本** - 判断是否已升级
2. **检查配置位置** - 确认配置文件在新位置
3. **验证 API 端点** - 确保使用正确的服务器地址
4. **测试 OAuth 命令** - 检查认证功能是否正常
5. **验证连接状态** - 测试与服务器的连接

## 修复步骤

### 自动修复（推荐）

运行修复脚本后，会自动执行：

1. 备份现有配置
2. 升级 CLI 到最新版本
3. 迁移配置到新位置
4. 更新 API 端点
5. 提示重新认证

### 手动修复

如需手动修复，请参考 `SKILL.md` 中的详细步骤。

## 验证修复结果

修复完成后，运行以下命令验证：

```bash
# 1. 检查版本（应显示 1.0.2+）
openclawmp --version

# 2. 检查 oauth 命令
openclawmp oauth --help

# 3. 检查 API 端点
openclawmp config get api.endpoint
# 应输出: https://openclawmp.stepfun.com

# 4. 测试连接
openclawmp status
```

## 常见问题

### Q: 运行脚本时提示权限不足

**A:** 在 Windows 上以管理员身份运行 PowerShell，或在 macOS/Linux 上使用 `sudo`。

### Q: 升级后仍然无法使用 oauth 命令

**A:** 尝试完全卸载后重新安装：
```bash
npm uninstall -g @stepfun/openclawmp
npm install -g @stepfun/openclawmp@latest
```

### Q: 配置文件迁移后数据丢失

**A:** 检查备份文件是否存在于：
- Windows: `%USERPROFILE%\.openclaw\config.json.backup`
- macOS/Linux: `~/.openclaw/config.json.backup`

### Q: 如何回滚到旧版本？

**A:** 
```bash
npm install -g @stepfun/openclawmp@0.1.4
```

## 文件结构

```
openclawmp-upgrade-fix/
├── SKILL.md              # 详细的诊断和修复流程
├── README.md             # 本文件
└── scripts/
    ├── fix-upgrade.ps1   # Windows PowerShell 修复脚本
    └── fix-upgrade.sh    # macOS/Linux Bash 修复脚本
```

## 更新日志

### v1.0.0
- 初始版本
- 支持 0.1.4 → 1.0.2+ 升级诊断
- 提供自动修复脚本

## 贡献

欢迎提交 Issue 和 PR！

## 许可证

MIT License
