#!/bin/bash
# OpenClawMP CLI 升级修复脚本 (macOS/Linux Bash)
# 用于诊断和修复 openclawmp CLI 从 0.1.4 升级到 1.0.2+ 的配置问题

set -e

# 颜色输出
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# 输出函数
info() { echo -e "${CYAN}[INFO]${NC} $1"; }
success() { echo -e "${GREEN}[OK]${NC} $1"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; }

# 参数解析
DRY_RUN=false
SKIP_BACKUP=false
FORCE=false

while [[ $# -gt 0 ]]; do
    case $1 in
        --dry-run)
            DRY_RUN=true
            shift
            ;;
        --skip-backup)
            SKIP_BACKUP=true
            shift
            ;;
        --force)
            FORCE=true
            shift
            ;;
        *)
            shift
            ;;
    esac
done

# 路径配置
OLD_CONFIG_DIR="$HOME/.openclaw"
OLD_CONFIG_FILE="$OLD_CONFIG_DIR/config.json"
NEW_CONFIG_DIR="$HOME/.stepclaw"
NEW_CONFIG_FILE="$NEW_CONFIG_DIR/openclaw.json"
BACKUP_FILE="$OLD_CONFIG_DIR/config.json.backup.$(date +%Y%m%d_%H%M%S)"

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  OpenClawMP CLI 升级修复工具${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# 1. 检测当前 CLI 版本
info "正在检测 CLI 版本..."
CURRENT_VERSION=""
if command -v openclawmp &> /dev/null; then
    VERSION_OUTPUT=$(openclawmp --version 2>/dev/null || true)
    if [[ $VERSION_OUTPUT =~ ([0-9]+\.[0-9]+\.[0-9]+) ]]; then
        CURRENT_VERSION="${BASH_REMATCH[1]}"
        success "当前版本: $CURRENT_VERSION"
    fi
else
    warn "openclawmp 命令未找到"
fi

# 2. 检查是否需要升级
NEEDS_UPGRADE=false
if [[ -n "$CURRENT_VERSION" ]]; then
    MAJOR=$(echo "$CURRENT_VERSION" | cut -d. -f1)
    MINOR=$(echo "$CURRENT_VERSION" | cut -d. -f2)
    PATCH=$(echo "$CURRENT_VERSION" | cut -d. -f3)
    
    if [[ $MAJOR -lt 1 ]] || ([[ $MAJOR -eq 1 && $MINOR -eq 0 && $PATCH -lt 2 ]]); then
        NEEDS_UPGRADE=true
        warn "当前版本较旧，建议升级到 1.0.2+"
    else
        success "版本已是最新或较新"
    fi
else
    NEEDS_UPGRADE=true
fi

# 3. 检查配置文件
info "检查配置文件..."
HAS_OLD_CONFIG=false
HAS_NEW_CONFIG=false

if [[ -f "$OLD_CONFIG_FILE" ]]; then
    HAS_OLD_CONFIG=true
    warn "发现旧配置文件: $OLD_CONFIG_FILE"
fi

if [[ -f "$NEW_CONFIG_FILE" ]]; then
    HAS_NEW_CONFIG=true
    success "发现新配置文件: $NEW_CONFIG_FILE"
fi

# 4. 检查 npm
info "检查 npm 环境..."
if command -v npm &> /dev/null; then
    NPM_VERSION=$(npm --version)
    success "npm 版本: $NPM_VERSION"
else
    error "npm 未安装或不在 PATH 中"
    exit 1
fi

# 干运行模式
if [[ "$DRY_RUN" == true ]]; then
    echo ""
    echo -e "${YELLOW}========================================${NC}"
    echo -e "${YELLOW}  干运行模式 - 未执行任何更改${NC}"
    echo -e "${YELLOW}========================================${NC}"
    exit 0
fi

# 5. 执行升级
if [[ "$NEEDS_UPGRADE" == true ]] || [[ "$FORCE" == true ]]; then
    echo ""
    info "开始升级 CLI..."
    
    if npm install -g @stepfun/openclawmp@latest; then
        success "CLI 升级完成"
    else
        error "升级失败"
        exit 1
    fi
else
    info "跳过升级步骤"
fi

# 6. 备份旧配置
if [[ "$HAS_OLD_CONFIG" == true ]] && [[ "$SKIP_BACKUP" == false ]]; then
    echo ""
    info "备份旧配置..."
    if cp "$OLD_CONFIG_FILE" "$BACKUP_FILE"; then
        success "配置已备份到: $BACKUP_FILE"
    else
        error "备份失败"
        exit 1
    fi
fi

# 7. 迁移配置
if [[ "$HAS_OLD_CONFIG" == true ]]; then
    echo ""
    info "迁移配置到新位置..."
    
    # 创建新配置目录
    mkdir -p "$NEW_CONFIG_DIR"
    
    # 检查 jq 是否可用
    if command -v jq &> /dev/null; then
        # 使用 jq 更新配置
        jq '.api.endpoint = "https://openclawmp.stepfun.com"' "$OLD_CONFIG_FILE" > "$NEW_CONFIG_FILE"
        success "配置已迁移并更新 API 端点"
    else
        # 简单复制并提示手动更新
        cp "$OLD_CONFIG_FILE" "$NEW_CONFIG_FILE"
        warn "jq 未安装，配置已复制但未自动更新 API 端点"
        warn "请手动编辑 $NEW_CONFIG_FILE 将 api.endpoint 改为 https://openclawmp.stepfun.com"
    fi
    
    success "配置已迁移到: $NEW_CONFIG_FILE"
fi

# 8. 验证修复结果
echo ""
info "验证修复结果..."

# 检查版本
if command -v openclawmp &> /dev/null; then
    NEW_VERSION=$(openclawmp --version 2>/dev/null || true)
    success "新版本: $NEW_VERSION"
    
    # 检查 oauth 命令
    if openclawmp oauth --help &> /dev/null; then
        success "oauth 命令可用"
    else
        warn "oauth 命令可能不可用"
    fi
    
    # 检查配置
    API_ENDPOINT=$(openclawmp config get api.endpoint 2>/dev/null || true)
    if [[ "$API_ENDPOINT" == "https://openclawmp.stepfun.com" ]]; then
        success "API 端点配置正确"
    else
        warn "API 端点配置可能不正确: $API_ENDPOINT"
    fi
else
    warn "无法验证 - openclawmp 命令不可用"
fi

# 9. 完成提示
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  修复完成！${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo "下一步操作："
echo "  1. 运行 'openclawmp oauth login' 重新登录"
echo "  2. 运行 'openclawmp status' 测试连接"
echo ""
echo "如有问题，可以恢复备份："
echo "  cp '$BACKUP_FILE' '$OLD_CONFIG_FILE'"
echo ""
