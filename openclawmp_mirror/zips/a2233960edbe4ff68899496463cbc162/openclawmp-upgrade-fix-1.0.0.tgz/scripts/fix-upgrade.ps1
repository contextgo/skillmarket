# OpenClawMP CLI 升级修复脚本 (Windows PowerShell)
# 用于诊断和修复 openclawmp CLI 从 0.1.4 升级到 1.0.2+ 的配置问题

param(
    [switch]$DryRun,
    [switch]$SkipBackup,
    [switch]$Force
)

$ErrorActionPreference = "Stop"

# 颜色输出函数
function Write-Info { param($Message) Write-Host "[INFO] $Message" -ForegroundColor Cyan }
function Write-Success { param($Message) Write-Host "[OK] $Message" -ForegroundColor Green }
function Write-Warning { param($Message) Write-Host "[WARN] $Message" -ForegroundColor Yellow }
function Write-Error { param($Message) Write-Host "[ERROR] $Message" -ForegroundColor Red }

# 路径配置
$OldConfigDir = "$env:USERPROFILE\.openclaw"
$OldConfigFile = "$OldConfigDir\config.json"
$NewConfigDir = "$env:USERPROFILE\.stepclaw"
$NewConfigFile = "$NewConfigDir\openclaw.json"
$BackupFile = "$OldConfigDir\config.json.backup.$(Get-Date -Format 'yyyyMMdd_HHmmss')"

Write-Host "========================================" -ForegroundColor Blue
Write-Host "  OpenClawMP CLI 升级修复工具" -ForegroundColor Blue
Write-Host "========================================" -ForegroundColor Blue
Write-Host ""

# 1. 检测当前 CLI 版本
Write-Info "正在检测 CLI 版本..."
$CurrentVersion = $null
try {
    $versionOutput = & openclawmp --version 2>$null
    if ($versionOutput -match '(\d+\.\d+\.\d+)') {
        $CurrentVersion = $matches[1]
        Write-Success "当前版本: $CurrentVersion"
    }
} catch {
    Write-Warning "无法获取版本信息，CLI 可能未安装"
}

# 2. 检查是否需要升级
$NeedsUpgrade = $false
if ($CurrentVersion) {
    $versionParts = $CurrentVersion -split '\.'
    $major = [int]$versionParts[0]
    $minor = [int]$versionParts[1]
    
    if ($major -lt 1 -or ($major -eq 1 -and $minor -eq 0 -and $versionParts[2] -lt 2)) {
        $NeedsUpgrade = $true
        Write-Warning "当前版本较旧，建议升级到 1.0.2+"
    } else {
        Write-Success "版本已是最新或较新"
    }
} else {
    $NeedsUpgrade = $true
}

# 3. 检查旧配置是否存在
$HasOldConfig = Test-Path $OldConfigFile
$HasNewConfig = Test-Path $NewConfigFile

Write-Info "检查配置文件..."
if ($HasOldConfig) {
    Write-Warning "发现旧配置文件: $OldConfigFile"
}
if ($HasNewConfig) {
    Write-Success "发现新配置文件: $NewConfigFile"
}

# 4. 检查 npm 是否可用
Write-Info "检查 npm 环境..."
try {
    $npmVersion = & npm --version 2>$null
    Write-Success "npm 版本: $npmVersion"
} catch {
    Write-Error "npm 未安装或不在 PATH 中"
    exit 1
}

# 如果是 DryRun 模式，到此结束
if ($DryRun) {
    Write-Host ""
    Write-Host "========================================" -ForegroundColor Yellow
    Write-Host "  干运行模式 - 未执行任何更改" -ForegroundColor Yellow
    Write-Host "========================================" -ForegroundColor Yellow
    exit 0
}

# 5. 执行升级
if ($NeedsUpgrade -or $Force) {
    Write-Host ""
    Write-Info "开始升级 CLI..."
    
    try {
        & npm install -g @stepfun/openclawmp@latest
        Write-Success "CLI 升级完成"
    } catch {
        Write-Error "升级失败: $_"
        exit 1
    }
} else {
    Write-Info "跳过升级步骤"
}

# 6. 备份旧配置
if ($HasOldConfig -and -not $SkipBackup) {
    Write-Host ""
    Write-Info "备份旧配置..."
    try {
        Copy-Item $OldConfigFile $BackupFile -Force
        Write-Success "配置已备份到: $BackupFile"
    } catch {
        Write-Error "备份失败: $_"
        exit 1
    }
}

# 7. 迁移配置
if ($HasOldConfig) {
    Write-Host ""
    Write-Info "迁移配置到新位置..."
    
    try {
        # 创建新配置目录
        if (-not (Test-Path $NewConfigDir)) {
            New-Item -ItemType Directory -Force -Path $NewConfigDir | Out-Null
        }
        
        # 读取旧配置
        $config = Get-Content $OldConfigFile | ConvertFrom-Json
        
        # 更新 API 端点
        if ($config.api) {
            $config.api.endpoint = "https://openclawmp.stepfun.com"
            Write-Success "API 端点已更新为: https://openclawmp.stepfun.com"
        } else {
            $config | Add-Member -NotePropertyName api -NotePropertyValue @{ endpoint = "https://openclawmp.stepfun.com" }
        }
        
        # 保存到新位置
        $config | ConvertTo-Json -Depth 10 | Set-Content $NewConfigFile
        Write-Success "配置已迁移到: $NewConfigFile"
        
    } catch {
        Write-Error "配置迁移失败: $_"
        exit 1
    }
}

# 8. 验证修复结果
Write-Host ""
Write-Info "验证修复结果..."

# 检查版本
$NewVersion = & openclawmp --version 2>$null
Write-Success "新版本: $NewVersion"

# 检查 oauth 命令
try {
    $oauthHelp = & openclawmp oauth --help 2>$null
    Write-Success "oauth 命令可用"
} catch {
    Write-Warning "oauth 命令可能不可用"
}

# 检查配置
try {
    $apiEndpoint = & openclawmp config get api.endpoint 2>$null
    if ($apiEndpoint -eq "https://openclawmp.stepfun.com") {
        Write-Success "API 端点配置正确"
    } else {
        Write-Warning "API 端点配置可能不正确: $apiEndpoint"
    }
} catch {
    Write-Warning "无法验证 API 端点配置"
}

# 9. 完成提示
Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  修复完成！" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "下一步操作："
Write-Host "  1. 运行 'openclawmp oauth login' 重新登录"
Write-Host "  2. 运行 'openclawmp status' 测试连接"
Write-Host ""
Write-Host "如有问题，可以恢复备份："
Write-Host "  Copy-Item '$BackupFile' '$OldConfigFile' -Force"
Write-Host ""
