# openclawmp-upgrade-fix

OpenClawMP CLI 升级诊断与修复 Skill

## 描述

帮助用户诊断和修复 openclawmp CLI 从旧版本（如 0.1.4）升级到新版本（如 1.0.2+）时遇到的配置问题。

## 适用场景

- CLI 版本升级后命令不可用
- API 端点配置错误（openclawmp.cc → openclawmp.stepfun.com）
- 配置文件位置变更导致的问题
- OAuth 认证失败
- 升级后无法正常使用 openclawmp 功能

## 诊断流程

### 1. 检测当前 CLI 版本

```bash
# 检查 CLI 版本
openclawmp --version
# 或
openclawmp -v
```

**预期输出：**
- 旧版本：0.1.x
- 新版本：1.0.2+

### 2. 检查配置文件位置

**旧版本配置位置：**
- Windows: `%USERPROFILE%\.openclaw\config.json`
- macOS/Linux: `~/.openclaw/config.json`

**新版本配置位置：**
- Windows: `%USERPROFILE%\.stepclaw\openclaw.json`
- macOS/Linux: `~/.stepclaw/openclaw.json`

### 3. 检查 API 端点配置

```bash
# 查看当前配置中的 API 端点
openclawmp config get api.endpoint
```

**正确配置：**
- 旧端点：`https://api.openclawmp.cc`（需要更新）
- 新端点：`https://openclawmp.stepfun.com`

### 4. 检查 OAuth 配置

```bash
# 检查是否有 oauth 命令
openclawmp oauth --help
```

**注意：** oauth 命令仅在 1.0.0+ 版本中可用

## 修复流程

### 方案 A：自动修复（推荐）

运行自动修复脚本：

```bash
# Windows PowerShell
~/.stepclaw/workspace/skills/openclawmp-upgrade-fix/scripts/fix-upgrade.ps1

# macOS/Linux Bash
~/.stepclaw/workspace/skills/openclawmp-upgrade-fix/scripts/fix-upgrade.sh
```

### 方案 B：手动修复步骤

#### 步骤 1：备份旧配置

```bash
# Windows
Copy-Item "$env:USERPROFILE\.openclaw\config.json" "$env:USERPROFILE\.openclaw\config.json.backup"

# macOS/Linux
cp ~/.openclaw/config.json ~/.openclaw/config.json.backup
```

#### 步骤 2：升级 CLI

```bash
# 使用 npm 升级
npm install -g @stepfun/openclawmp

# 或使用指定版本
npm install -g @stepfun/openclawmp@latest
```

#### 步骤 3：迁移配置

```bash
# Windows PowerShell
$oldConfig = "$env:USERPROFILE\.openclaw\config.json"
$newConfigDir = "$env:USERPROFILE\.stepclaw"
$newConfig = "$newConfigDir\openclaw.json"

# 创建新配置目录
New-Item -ItemType Directory -Force -Path $newConfigDir

# 复制并更新配置
if (Test-Path $oldConfig) {
    $config = Get-Content $oldConfig | ConvertFrom-Json
    # 更新 API 端点
    if ($config.api -and $config.api.endpoint) {
        $config.api.endpoint = "https://openclawmp.stepfun.com"
    }
    $config | ConvertTo-Json -Depth 10 | Set-Content $newConfig
}

# macOS/Linux Bash
mkdir -p ~/.stepclaw
if [ -f ~/.openclaw/config.json ]; then
    # 使用 jq 或直接编辑更新 API 端点
    jq '.api.endpoint = "https://openclawmp.stepfun.com"' ~/.openclaw/config.json > ~/.stepclaw/openclaw.json
fi
```

#### 步骤 4：重新认证

```bash
# 使用新的 oauth 命令重新登录
openclawmp oauth login
```

#### 步骤 5：验证修复

```bash
# 检查版本
openclawmp --version

# 检查配置
openclawmp config list

# 测试 API 连接
openclawmp status
```

## 常见问题

### Q1: 升级后提示 "oauth 命令不存在"

**原因：** 旧版本 CLI 没有 oauth 命令

**解决：**
1. 确认已升级到 1.0.0+
2. 运行 `openclawmp --version` 确认版本
3. 如果版本正确但仍无 oauth，尝试重新安装：`npm install -g @stepfun/openclawmp@latest`

### Q2: 提示 "API endpoint not found" 或连接失败

**原因：** 配置中仍使用旧 API 端点

**解决：**
```bash
# 手动设置正确的 API 端点
openclawmp config set api.endpoint https://openclawmp.stepfun.com
```

### Q3: 升级后配置丢失

**原因：** 配置存储位置变更

**解决：** 按照"迁移配置"步骤手动迁移旧配置

### Q4: npm 安装失败或权限错误

**解决：**
```bash
# 使用管理员权限（Windows）
# 或使用 npx 临时运行
npx @stepfun/openclawmp@latest --version

# macOS/Linux 使用 sudo
sudo npm install -g @stepfun/openclawmp
```

## 验证清单

修复完成后，确认以下检查项：

- [ ] `openclawmp --version` 显示 1.0.2+
- [ ] `openclawmp oauth --help` 正常显示帮助
- [ ] `openclawmp config get api.endpoint` 显示 `https://openclawmp.stepfun.com`
- [ ] `openclawmp status` 成功连接到服务器
- [ ] 配置文件位于正确的位置（`~/.stepclaw/openclaw.json`）

## 回滚方案

如果升级后出现问题，可以回滚到旧版本：

```bash
# 安装指定旧版本
npm install -g @stepfun/openclawmp@0.1.4

# 恢复旧配置
cp ~/.openclaw/config.json.backup ~/.openclaw/config.json
```

## 相关资源

- OpenClawMP 官方文档
- 水产市场平台：https://openclawmp.stepfun.com
- npm 包页面：https://www.npmjs.com/package/@stepfun/openclawmp
