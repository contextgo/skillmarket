#!/usr/bin/env python3
"""
基金实时盯盘工具 - 基础版
使用 AKShare 免费获取基金数据，推送到钉钉群
"""

import json
import requests
import akshare as ak
from datetime import datetime

# ============ 用户配置区 ============
# 钉钉机器人配置
DINGTALK_WEBHOOK = "https://oapi.dingtalk.com/robot/send?access_token=abd04f8394afdb2b97afdf831a863b8717b7eb9c2badd2c0f6276ff9255a43b1"

# 要盯盘的基金列表
# 格式: {"基金代码": {"name": "基金名称", "cost": "持仓成本(可选)", "amount": "持仓金额", "profit": "持仓收益"}}
FUNDS = {
    "010612": {"name": "国富恒瑞债券A", "cost": None, "amount": 28767.92, "profit": 5480.45},
    "017193": {"name": "基金待查", "cost": None, "amount": 11181.90, "profit": 1181.90},
    "022365": {"name": "基金待查", "cost": None, "amount": 25592.97, "profit": 592.97},
    "018123": {"name": "永赢数字经济智选混合发起C", "cost": None, "amount": 7275.22, "profit": 275.22},
    "161226": {"name": "国投瑞银白银期货(LOF)A", "cost": None, "amount": 993.87, "profit": -6.13},
    "007910": {"name": "基金待查", "cost": None, "amount": 4980.91, "profit": -19.09},
    "015395": {"name": "基金待查", "cost": None, "amount": 2510.94, "profit": -489.06},
}
# =====================================


def get_fund_valuation(fund_code):
    """获取基金实时估值"""
    try:
        # 使用 AKShare 获取基金实时估值
        # 这里使用天天基金网的估算数据
        url = f"http://fundgz.1234567.com.cn/js/{fund_code}.js"
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        response = requests.get(url, headers=headers, timeout=10)
        
        # 解析返回的 JSONP 数据
        data_text = response.text
        if "jsonpgz" in data_text:
            json_str = data_text.replace("jsonpgz(", "").replace(");", "")
            data = json.loads(json_str)
            return {
                "code": fund_code,
                "name": data.get("name", ""),
                "nav": float(data.get("dwjz", 0)),  # 昨日净值
                "estimate": float(data.get("gsz", 0)),  # 估算净值
                "growth": float(data.get("gszzl", 0)),  # 估算涨跌幅
                "time": data.get("gztime", "")
            }
        return None
    except Exception as e:
        print(f"获取基金 {fund_code} 数据失败: {e}")
        return None


def format_fund_message(fund_data, amount=None, profit=None):
    """格式化基金信息为钉钉消息"""
    if not fund_data:
        return ""
    
    code = fund_data["code"]
    name = fund_data["name"]
    nav = fund_data["nav"]
    estimate = fund_data["estimate"]
    growth = fund_data["growth"]
    time = fund_data["time"]
    
    # 涨跌颜色 emoji
    if growth > 0:
        emoji = "📈"
        growth_str = f"+{growth}%"
    elif growth < 0:
        emoji = "📉"
        growth_str = f"{growth}%"
    else:
        emoji = "➖"
        growth_str = "0.00%"
    
    # 计算当前市值和当日盈亏
    market_info = ""
    if amount and amount > 0:
        # 当前市值 = 持仓金额 * (1 + 涨跌幅/100)
        current_value = amount * (1 + growth / 100)
        daily_profit = amount * growth / 100
        
        # 累计盈亏信息
        total_profit_str = ""
        if profit is not None:
            profit_emoji = "🟢" if profit >= 0 else "🔴"
            total_profit_str = f"\n💹 累计收益: {profit_emoji} {profit:,.2f}元"
        
        market_info = f"""
💰 持仓金额: {amount:,.2f}元
📊 当前市值: {current_value:,.2f}元
📈 当日盈亏: {"🟢+" if daily_profit >= 0 else "🔴"}{daily_profit:,.2f}元{total_profit_str}"""
    
    message = f"""
{emoji} **{name}** ({code})
━━━━━━━━━━━━━━
💵 昨日净值: {nav}
📊 估算净值: {estimate}
📈 今日涨跌: {growth_str}{market_info}
"""
    return message


def send_dingtalk_message(content, webhook=DINGTALK_WEBHOOK):
    """发送消息到钉钉群"""
    headers = {"Content-Type": "application/json"}
    
    # 构建钉钉消息体
    message = {
        "msgtype": "markdown",
        "markdown": {
            "title": "基金实时估值",
            "text": content
        }
    }
    
    try:
        response = requests.post(
            webhook,
            headers=headers,
            json=message,
            timeout=10
        )
        result = response.json()
        if result.get("errcode") == 0:
            print("✅ 钉钉消息发送成功")
            return True
        else:
            print(f"❌ 钉钉消息发送失败: {result}")
            return False
    except Exception as e:
        print(f"❌ 发送钉钉消息出错: {e}")
        return False


def main():
    """主函数"""
    print("=" * 50)
    print("📊 基金实时盯盘工具启动")
    print(f"⏰ 当前时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 50)
    
    # 收集所有基金信息
    all_messages = []
    all_messages.append(f"## 📊 基金实时估值报告\n\n🕐 **报告时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n💡 **关键词**: 基金盯盘通知")
    
    for code, info in FUNDS.items():
        print(f"\n🔍 正在查询: {code} {info.get('name', '')}")
        fund_data = get_fund_valuation(code)
        
        if fund_data:
            message = format_fund_message(
                fund_data, 
                amount=info.get("amount"), 
                profit=info.get("profit")
            )
            all_messages.append(message)
            print(f"✅ 获取成功: {fund_data['name']}")
        else:
            print(f"❌ 获取失败: {code}")
            all_messages.append(f"\n❌ **{info.get('name', code)}** 数据获取失败\n")
    
    # 合并所有消息
    full_message = "\n---\n".join(all_messages)
    
    # 添加汇总信息
    full_message += "\n---\n"
    full_message += f"\n🕐 **更新时间**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
    
    # 计算汇总数据
    total_cost = sum(info.get("amount", 0) for info in FUNDS.values())
    total_market = sum(
        info.get("amount", 0) * (1 + get_fund_valuation(code).get("growth", 0) / 100) 
        if get_fund_valuation(code) else info.get("amount", 0)
        for code, info in FUNDS.items()
    )
    total_daily_profit = total_market - total_cost
    total_profit = sum(info.get("profit", 0) for info in FUNDS.values())
    
    full_message += f"\n## 📊 持仓汇总\n"
    full_message += f"💰 总成本: {total_cost:,.2f}元\n"
    full_message += f"📊 总市值: {total_market:,.2f}元\n"
    full_message += f"📈 当日盈亏: {'🟢+' if total_daily_profit >= 0 else '🔴'}{total_daily_profit:,.2f}元\n"
    full_message += f"💹 累计收益: {'🟢+' if total_profit >= 0 else '🔴'}{total_profit:,.2f}元\n"
    
    # 发送钉钉消息
    print("\n📤 正在发送钉钉消息...")
    send_dingtalk_message(full_message)
    
    print("\n✨ 基金盯盘完成!")


if __name__ == "__main__":
    main()
