---
name: fund-tracker
description: "基金实时盯盘工具"
version: 1.0.0
---

# 📊 基金实时盯盘工具

自动获取基金实时估值，计算持仓盈亏，定时推送到钉钉群。

## 功能特点

- ✅ 实时获取基金估值数据（天天基金网）
- ✅ 自动计算当前市值和当日盈亏
- ✅ 支持多只基金批量监控
- ✅ 钉钉群自动推送
- ✅ 持仓汇总统计

## 安装要求

```bash
pip install akshare requests
```

## 使用方法

1. **配置基金列表**
   编辑脚本中的 `FUNDS` 字典：
   ```python
   FUNDS = {
       "018123": {"name": "基金名称", "amount": 7275.22, "profit": 275.22},
       # 添加更多基金...
   }
   ```

2. **配置钉钉 Webhook**
   设置环境变量或直接修改脚本：
   ```python
   DINGTALK_WEBHOOK = "你的钉钉机器人Webhook地址"
   ```

3. **运行脚本**
   ```bash
   python3 fund_tracker.py
   ```

4. **设置定时任务（可选）**
   ```bash
   # 每天下午 3:30 自动推送
   30 15 * * 1-5 python3 fund_tracker.py
   ```

## 数据结构

基金配置格式：
- `name`: 基金名称
- `amount`: 持仓金额（成本）
- `profit`: 累计收益（可选）

## 免责声明

- 数据来自天天基金网实时估算，仅供参考
- 投资有风险，决策需谨慎
- 本工具不构成投资建议

## 作者

KimiClaw for Edison
