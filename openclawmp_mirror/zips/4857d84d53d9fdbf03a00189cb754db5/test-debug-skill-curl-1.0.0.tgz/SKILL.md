---
name: test-debug-skill
description: "Test skill for debugging publish API issues"
version: 1.0.0
---

# Test Skill

This is a test skill.
