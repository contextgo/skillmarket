# -*- coding: utf-8 -*-
"""
A股午盘复盘脚本 - 支持TuShare Pro和东方财富数据源
"""
import tushare as ts
import requests
import pandas as pd
from datetime import datetime

# TuShare Pro Token - 请从环境变量获取
import os
TUSHARE_TOKEN = os.getenv('TUSHARE_TOKEN', '')

def get_tushare_data(trade_date):
    """从TuShare Pro获取数据"""
    pro = ts.pro_api(TUSHARE_TOKEN)
    results = {}
    
    # 1. 主要指数行情
    indices = ['000001.SH', '399001.SZ', '399006.SZ', '000688.SH', '000016.SH', '000300.SH']
    index_data = []
    for idx in indices:
        try:
            df = pro.index_daily(ts_code=idx, trade_date=trade_date)
            if not df.empty:
                row = df.iloc[0]
                index_data.append({
                    'code': idx,
                    'close': row['close'],
                    'change': row['change'],
                    'pct_chg': row['pct_chg'],
                    'amount': row['amount'] / 100000  # 转换为亿
                })
        except:
            pass
    results['indices'] = index_data
    
    # 2. 指数估值指标
    try:
        df = pro.index_dailybasic(trade_date=trade_date, fields='ts_code,trade_date,pe,pb,turnover_rate')
        if not df.empty:
            results['valuation'] = df.to_dict('records')
    except:
        results['valuation'] = []
    
    # 3. 个股资金流向 TOP10
    try:
        stock_money = pro.moneyflow(start_date=trade_date, end_date=trade_date)
        if not stock_money.empty:
            stock_money = stock_money.sort_values('net_mf_amount', ascending=False)
            results['stock_flow'] = stock_money.head(10).to_dict('records')
        else:
            results['stock_flow'] = []
    except:
        results['stock_flow'] = []
    
    return results

def get_eastmoney_data():
    """从东方财富获取实时数据"""
    headers = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)'}
    results = {}
    
    try:
        # 主要指数
        url = 'https://push2.eastmoney.com/api/qt/ulist.np/get?fltt=2&invt=2&fields=f12,f13,f14,f2,f3,f4,f5,f6,f20,f21&secids=1.000001,0.399001,0.399006,1.000688,1.000016&ut=fa5fd1943c7b386f172d6893dbfba10b'
        resp = requests.get(url, headers=headers, timeout=10)
        data = resp.json()
        if data.get('data') and data['data'].get('diff'):
            results['indices_em'] = data['data']['diff']
    except:
        results['indices_em'] = []
    
    return results

def generate_report(trade_date=None):
    """生成复盘报告"""
    if trade_date is None:
        trade_date = datetime.now().strftime('%Y%m%d')
    
    # 获取数据
    tushare_data = get_tushare_data(trade_date)
    eastmoney_data = get_eastmoney_data()
    
    # 生成报告
    report = []
    report.append(f"# A股午盘复盘报告 - {trade_date}")
    report.append("=" * 60)
    
    # 指数行情
    report.append("\n## 主要指数行情")
    if tushare_data.get('indices'):
        for idx in tushare_data['indices']:
            report.append(f"- {idx['code']}: 收盘{idx['close']:.2f} ({idx['change']:+.2f}, {idx['pct_chg']:+.2f}%) 成交额{idx['amount']:.0f}亿")
    
    # 估值指标
    report.append("\n## 指数估值")
    if tushare_data.get('valuation'):
        for v in tushare_data['valuation'][:5]:
            report.append(f"- {v['ts_code']}: PE={v.get('pe', 'N/A')}, PB={v.get('pb', 'N/A')}, 换手率={v.get('turnover_rate', 'N/A')}%")
    
    # 个股资金流向
    report.append("\n## 个股净流入 TOP10")
    if tushare_data.get('stock_flow'):
        for i, stock in enumerate(tushare_data['stock_flow'][:10], 1):
            report.append(f"{i:2d}. {stock['ts_code']}: 净流入{stock['net_mf_amount']/10000:.1f}万元")
    
    report.append("\n" + "=" * 60)
    report.append(f"报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return '\n'.join(report)

if __name__ == '__main__':
    import sys
    trade_date = sys.argv[1] if len(sys.argv) > 1 else None
    print(generate_report(trade_date))
