# -*- coding: utf-8 -*-
"""
A股早盘选股策略 - 基于竞价数据和技术指标筛选涨停潜力股
JWZZ (竞价王中王) 指标 >= 95 的选股策略

使用前请设置环境变量:
export TUSHARE_TOKEN='your_token_here'
"""
import tushare as ts
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import os

# 从环境变量获取Token
TUSHARE_TOKEN = os.getenv('TUSHARE_TOKEN', '')

def calculate_jwzz_score(stock_data, daily_data):
    """
    计算JWZZ (竞价王中王) 指标
    综合考量：
    1. 竞价涨幅 (0-30分)
    2. 竞价量比 (0-25分)
    3. 竞价换手率 (0-20分)
    4. 昨日封板强度 (0-15分)
    5. 流通市值适中度 (0-10分)
    """
    score = 0
    details = {}
    
    # 1. 竞价涨幅评分
    if 'open' in stock_data and 'pre_close' in stock_data:
        open_chg = (stock_data['open'] - stock_data['pre_close']) / stock_data['pre_close'] * 100
        if open_chg >= 9.5:
            score += 30
            details['open_chg'] = f"{open_chg:.2f}% (+30分)"
        elif open_chg >= 5:
            score += 20
            details['open_chg'] = f"{open_chg:.2f}% (+20分)"
        elif open_chg >= 2:
            score += 10
            details['open_chg'] = f"{open_chg:.2f}% (+10分)"
        else:
            details['open_chg'] = f"{open_chg:.2f}% (0分)"
    
    # 2. 竞价量比评分
    if 'volume_ratio' in stock_data:
        vr = stock_data['volume_ratio']
        if vr >= 10:
            score += 25
            details['volume_ratio'] = f"{vr:.2f} (+25分)"
        elif vr >= 5:
            score += 20
            details['volume_ratio'] = f"{vr:.2f} (+20分)"
        elif vr >= 2:
            score += 15
            details['volume_ratio'] = f"{vr:.2f} (+15分)"
        elif vr >= 1:
            score += 10
            details['volume_ratio'] = f"{vr:.2f} (+10分)"
        else:
            details['volume_ratio'] = f"{vr:.2f} (0分)"
    
    # 3. 竞价换手率评分
    if 'turnover_rate' in stock_data:
        tr = stock_data['turnover_rate']
        if tr >= 5:
            score += 20
            details['turnover_rate'] = f"{tr:.2f}% (+20分)"
        elif tr >= 2:
            score += 15
            details['turnover_rate'] = f"{tr:.2f}% (+15分)"
        elif tr >= 1:
            score += 10
            details['turnover_rate'] = f"{tr:.2f}% (+10分)"
        else:
            details['turnover_rate'] = f"{tr:.2f}% (0分)"
    
    # 4. 昨日表现评分
    if daily_data is not None and not daily_data.empty:
        yesterday = daily_data.iloc[0]
        if yesterday.get('pct_chg', 0) >= 9.5:
            score += 15
            details['yesterday'] = "昨日涨停 (+15分)"
        elif yesterday.get('pct_chg', 0) >= 5:
            score += 10
            details['yesterday'] = f"昨日涨{yesterday.get('pct_chg', 0):.2f}% (+10分)"
        else:
            details['yesterday'] = f"昨日涨{yesterday.get('pct_chg', 0):.2f}% (0分)"
    
    # 5. 流通市值评分
    if 'circ_mv' in stock_data:
        cmv = stock_data['circ_mv'] / 10000
        if 10 <= cmv <= 100:
            score += 10
            details['circ_mv'] = f"{cmv:.1f}亿 (+10分，适中)"
        elif cmv < 10:
            score += 5
            details['circ_mv'] = f"{cmv:.1f}亿 (+5分，偏小)"
        else:
            details['circ_mv'] = f"{cmv:.1f}亿 (0分，偏大)"
    
    return score, details

def get_pre_market_data(trade_date):
    """获取竞价数据"""
    pro = ts.pro_api(TUSHARE_TOKEN)
    try:
        df = pro.daily_basic(trade_date=trade_date, fields='ts_code,close,open,turnover_rate,volume_ratio,circ_mv')
        return df
    except Exception as e:
        print(f"获取竞价数据失败: {e}")
        return pd.DataFrame()

def get_yesterday_data(trade_date):
    """获取昨日行情数据"""
    pro = ts.pro_api(TUSHARE_TOKEN)
    yesterday = (datetime.strptime(trade_date, '%Y%m%d') - timedelta(days=1)).strftime('%Y%m%d')
    try:
        df = pro.daily(trade_date=yesterday, fields='ts_code,close,pct_chg,vol')
        return df
    except:
        return pd.DataFrame()

def select_stocks(trade_date=None, min_score=95):
    """早盘选股主函数"""
    if trade_date is None:
        trade_date = datetime.now().strftime('%Y%m%d')
    
    if not TUSHARE_TOKEN:
        print("错误: 请设置环境变量 TUSHARE_TOKEN")
        return []
    
    print(f"[{trade_date}] 早盘选股启动 (JWZZ >= {min_score})")
    print("=" * 60)
    
    today_data = get_pre_market_data(trade_date)
    yesterday_data = get_yesterday_data(trade_date)
    
    if today_data.empty:
        print("当日数据暂不可用，请稍后重试")
        return []
    
    results = []
    for _, row in today_data.iterrows():
        ts_code = row['ts_code']
        yd = yesterday_data[yesterday_data['ts_code'] == ts_code] if not yesterday_data.empty else None
        score, details = calculate_jwzz_score(row.to_dict(), yd)
        
        if score >= min_score:
            results.append({
                'ts_code': ts_code,
                'jwzz_score': score,
                'open': row.get('open', 0),
                'close': row.get('close', 0),
                'details': details
            })
    
    results.sort(key=lambda x: x['jwzz_score'], reverse=True)
    return results

def generate_selection_report(trade_date=None, min_score=95):
    """生成选股报告"""
    if trade_date is None:
        trade_date = datetime.now().strftime('%Y%m%d')
    
    stocks = select_stocks(trade_date, min_score)
    
    report = []
    report.append(f"# 早盘选股报告 - {trade_date}")
    report.append(f"## 筛选条件: JWZZ指标 >= {min_score}")
    report.append("=" * 60)
    
    if not stocks:
        report.append("\n暂无符合条件的股票")
    else:
        report.append(f"\n共筛选出 {len(stocks)} 只股票:\n")
        for i, stock in enumerate(stocks[:20], 1):
            report.append(f"\n### {i}. {stock['ts_code']} (JWZZ: {stock['jwzz_score']}分)")
            report.append(f"- 开盘价: {stock['open']:.2f}")
            report.append(f"- 昨日收盘: {stock['close']:.2f}")
            report.append("- 得分详情:")
            for key, value in stock['details'].items():
                report.append(f"  - {key}: {value}")
    
    report.append("\n" + "=" * 60)
    report.append(f"报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    report.append("\n风险提示: 本选股结果仅供参考，不构成投资建议")
    
    return '\n'.join(report)

if __name__ == '__main__':
    import sys
    trade_date = sys.argv[1] if len(sys.argv) > 1 else None
    min_score = int(sys.argv[2]) if len(sys.argv) > 2 else 95
    print(generate_selection_report(trade_date, min_score))
