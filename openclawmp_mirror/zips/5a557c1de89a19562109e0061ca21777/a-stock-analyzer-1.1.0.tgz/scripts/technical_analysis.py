# -*- coding: utf-8 -*-
"""
A股技术分析与板块分析模块
"""
import tushare as ts
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# TuShare Pro Token - 请从环境变量获取
import os
TUSHARE_TOKEN = os.getenv('TUSHARE_TOKEN', '')

def get_technical_indicators(ts_code, trade_date, days=20):
    """计算技术指标"""
    pro = ts.pro_api(TUSHARE_TOKEN)
    
    # 获取历史数据
    end_date = trade_date
    start_date = (datetime.strptime(trade_date, '%Y%m%d') - timedelta(days=days*2)).strftime('%Y%m%d')
    df = pro.daily(ts_code=ts_code, start_date=start_date, end_date=end_date)
    
    if df.empty or len(df) < days:
        return None
    
    df = df.sort_values('trade_date')
    
    # 计算MA均线
    df['ma5'] = df['close'].rolling(window=5).mean()
    df['ma10'] = df['close'].rolling(window=10).mean()
    df['ma20'] = df['close'].rolling(window=20).mean()
    
    # 计算MACD
    exp1 = df['close'].ewm(span=12, adjust=False).mean()
    exp2 = df['close'].ewm(span=26, adjust=False).mean()
    df['macd_dif'] = exp1 - exp2
    df['macd_dea'] = df['macd_dif'].ewm(span=9, adjust=False).mean()
    df['macd_bar'] = 2 * (df['macd_dif'] - df['macd_dea'])
    
    # 计算RSI
    delta = df['close'].diff()
    gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
    loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
    rs = gain / loss
    df['rsi'] = 100 - (100 / (1 + rs))
    
    # 计算KDJ
    low_min = df['low'].rolling(window=9).min()
    high_max = df['high'].rolling(window=9).max()
    df['k'] = 100 * (df['close'] - low_min) / (high_max - low_min)
    df['d'] = df['k'].rolling(window=3).mean()
    df['j'] = 3 * df['k'] - 2 * df['d']
    
    # 计算布林带
    df['boll_mid'] = df['close'].rolling(window=20).mean()
    df['boll_std'] = df['close'].rolling(window=20).std()
    df['boll_up'] = df['boll_mid'] + 2 * df['boll_std']
    df['boll_down'] = df['boll_mid'] - 2 * df['boll_std']
    
    return df.iloc[-1].to_dict()

def get_sector_analysis(trade_date):
    """板块分析"""
    pro = ts.pro_api(TUSHARE_TOKEN)
    results = {}
    
    try:
        # 行业资金流向
        money = pro.moneyflow_industry(start_date=trade_date, end_date=trade_date)
        if not money.empty:
            money = money.sort_values('net_mf_amount', ascending=False)
            results['top_sectors'] = money.head(10).to_dict('records')
            results['bottom_sectors'] = money.tail(10).to_dict('records')
    except:
        pass
    
    try:
        # 概念资金流向
        concept = pro.moneyflow_concept(start_date=trade_date, end_date=trade_date)
        if not concept.empty:
            concept = concept.sort_values('net_mf_amount', ascending=False)
            results['top_concepts'] = concept.head(10).to_dict('records')
    except:
        pass
    
    return results

def get_limit_up_analysis(trade_date):
    """涨停分析"""
    pro = ts.pro_api(TUSHARE_TOKEN)
    results = {}
    
    try:
        # 涨停股票
        limit_up = pro.limit_list(trade_date=trade_date, limit_type='U')
        results['limit_up_count'] = len(limit_up)
        if len(limit_up) > 0:
            results['limit_up_stocks'] = limit_up.head(20).to_dict('records')
    except:
        results['limit_up_count'] = 0
    
    try:
        # 跌停股票
        limit_down = pro.limit_list(trade_date=trade_date, limit_type='D')
        results['limit_down_count'] = len(limit_down)
    except:
        results['limit_down_count'] = 0
    
    return results

def get_market_sentiment(trade_date):
    """市场情绪分析"""
    pro = ts.pro_api(TUSHARE_TOKEN)
    
    try:
        # 获取每日指标
        df = pro.daily_basic(trade_date=trade_date, fields='ts_code,close,turnover_rate,pe_ttm,pb')
        
        if df.empty:
            return {}
        
        sentiment = {
            'avg_turnover': df['turnover_rate'].mean(),
            'median_pe': df['pe_ttm'].median(),
            'median_pb': df['pb'].median(),
            'high_turnover_count': len(df[df['turnover_rate'] > 10]),
            'total_stocks': len(df)
        }
        
        return sentiment
    except:
        return {}

def generate_full_report(trade_date=None):
    """生成完整分析报告"""
    if trade_date is None:
        trade_date = datetime.now().strftime('%Y%m%d')
    
    from market_review import get_tushare_data
    
    report = []
    report.append(f"# A股完整复盘报告 - {trade_date}")
    report.append("=" * 60)
    
    # 基础行情
    basic_data = get_tushare_data(trade_date)
    
    report.append("\n## 一、主要指数行情")
    if basic_data.get('indices'):
        for idx in basic_data['indices']:
            report.append(f"- {idx['code']}: 收盘{idx['close']:.2f} ({idx['change']:+.2f}, {idx['pct_chg']:+.2f}%) 成交额{idx['amount']:.0f}亿")
    
    # 板块分析
    report.append("\n## 二、板块资金流向")
    sector_data = get_sector_analysis(trade_date)
    if sector_data.get('top_sectors'):
        report.append("\n### 净流入TOP10行业")
        for i, s in enumerate(sector_data['top_sectors'][:10], 1):
            report.append(f"{i:2d}. {s['industry_name']}: 净流入{s['net_mf_amount']/10000:.1f}万元")
    
    # 涨停分析
    report.append("\n## 三、涨跌停统计")
    limit_data = get_limit_up_analysis(trade_date)
    report.append(f"- 涨停: {limit_data.get('limit_up_count', 0)}只")
    report.append(f"- 跌停: {limit_data.get('limit_down_count', 0)}只")
    
    # 市场情绪
    report.append("\n## 四、市场情绪")
    sentiment = get_market_sentiment(trade_date)
    if sentiment:
        report.append(f"- 平均换手率: {sentiment.get('avg_turnover', 0):.2f}%")
        report.append(f"- 中位数PE: {sentiment.get('median_pe', 0):.2f}")
        report.append(f"- 高换手股票数(>10%): {sentiment.get('high_turnover_count', 0)}只")
    
    report.append("\n" + "=" * 60)
    report.append(f"报告生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return '\n'.join(report)

if __name__ == '__main__':
    import sys
    trade_date = sys.argv[1] if len(sys.argv) > 1 else None
    print(generate_full_report(trade_date))
