# 🔷 Semantic Router v7.9 - 任务匹配型自动模型路由 🔷

**水产市场**: https://openclawmp.cc
**版本**: 7.9.0 (生产环境)
**作者**: halfmoon82

## 🎯 核心功能

根据对话内容自动选择最合适的模型：
- **开发任务** → Intelligence池（推荐：claude-opus-4-6, qwen3-coder-plus）
- **信息查询** → Highspeed池（推荐：claude-haiku-4-5, qwen3-max）
- **内容创作** → Humanities池（推荐：claude-sonnet-4-6, qwen3.5-plus）

**四层识别**：系统过滤 → 关键词 → 指示词 → 语义相似度
**五分支路由**：A/B/B+/C/C-auto 精准匹配不同场景
**全自动 Fallback**：主力挂了自动切备用

---

## 🚀 快速安装

### 1. 安装技能
```bash
openclawmp install skill/@u-1ae1349f59bf4d699db7/semantic-router
```

### 2. 配置三池模型
编辑 `~/.openclaw/workspace/.lib/pools.json`：
```json
{
  "Intelligence": {
    "primary": "your-provider/claude-opus-4-6",
    "fallback_1": "qianwen/qwen3-coder-plus"
  },
  "Highspeed": {
    "primary": "your-provider/claude-haiku-4-5",
    "fallback_1": "qianwen/qwen3-max"
  },
  "Humanities": {
    "primary": "your-provider/claude-sonnet-4-6",
    "fallback_1": "qianwen/qwen3.5-plus"
  }
}
```

### 3. 启用自动路由
```bash
openclaw config set hooks.internal.entries.semantic-router-auto.enabled true
openclaw gateway restart
```

### 4. 测试验证
```bash
python3 ~/.openclaw/skills/semantic-router/scripts/semantic_check.py \
  "帮我写个Python爬虫" "Highspeed"
```

---

## 📚 配置说明

### 三池模型架构

| 池名 | 用途 |
|------|------|
| Intelligence | 开发、编程、复杂任务 |
| Highspeed | 查询、检索、快速响应 |
| Humanities | 写作、翻译、内容生成 |

### 配置流程

1. **环境检测** - 检查现有模型配置，避免冲突
2. **三池配置** - 为每个池配置 primary + fallback 模型
3. **启用 Hook** - 开启自动路由功能
4. **Cron 隔离**（可选）- 隔离后台任务，避免会话重置

**详细配置指南**：参见 [CONFIGURATION_GUIDE.md](./CONFIGURATION_GUIDE.md)（包含7个常见坑）

---

## 🎓 核心概念

### 五分支路由决策

| 分支 | 触发条件 | 动作 |
|------|--------|------|
| **A** | 关键词完全匹配 | 直接切到目标池 |
| **B** | 指示词（延续） | 保持当前模型 |
| **B+** | 中等关联度 | 保持 + 警告话题漂移 |
| **C** | 新任务关键词 | 切换模型，不重置会话 |
| **C-auto** | 低关联度 | 重置会话 + 切换模型 |

### 两步判断法

**Step 1: 关键词检测**
```
"帮我写个爬虫" → 关键词 "写" + "爬虫" → Intelligence
"查一下天气" → 关键词 "查" + "天气" → Highspeed
```

**Step 2: 上下文评分**（当 Step 1 无结果时）
```
相似度 ≥ 0.55 → B 分支（延续）
相似度 0.35~0.55 → B+ 分支（延续但警告）
相似度 < 0.35 → C-auto 分支（重置）
```

---

## ⚠️ 常见问题

### Q: Cron Job 导致会话重置？
A: 使用隔离会话：
```bash
openclaw cron update {job_id} \
  --patch '{"sessionKey": null, "sessionTarget": "isolated"}'
```

### Q: 模型没有自动切换？
A: 检查 Hook 是否启用：
```bash
openclaw config get hooks.internal.entries.semantic-router-auto.enabled
```

### Q: 如何自定义关键词？
A: 编辑 `~/.openclaw/workspace/.lib/tasks.json`

---

## 📖 完整文档

- **QUICKSTART.md** - 5分钟快速配置
- **CONFIGURATION_GUIDE.md** - 完整配置指南（7个常见坑）
- **README_v7.6.3.md** - 生产部署指南

---

## 📝 许可与支持

- **许可证**: MIT
- **作者**: halfmoon82
- **反馈**: 在水产市场提交 issue

---

**Powered by halfmoon82** 🔷