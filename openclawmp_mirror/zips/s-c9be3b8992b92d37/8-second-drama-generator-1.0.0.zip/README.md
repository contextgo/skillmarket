# 8秒短剧生成器

> 自动生成8秒短剧的完整剧本和AI视频提示词

## 功能

- 根据主题自动生成剧情
- 设计4个镜头的分镜
- 生成完整中文提示词
- 提供音效和音乐建议

## 使用方法

```bash
# 生成温情短剧
openclaw skill run 8-second-drama --theme "温情" --emotion "感人"

# 生成搞笑短剧
openclaw skill run 8-second-drama --theme "搞笑" --emotion "反转"

# 生成悬疑短剧
openclaw skill run 8-second-drama --theme "悬疑" --emotion "紧张"
```

## 支持主题

- 温情、爱情、亲情
- 搞笑、喜剧、反转
- 悬疑、惊悚、紧张
- 科幻、奇幻、未来
- 动作、冒险、刺激

## 输出示例

```markdown
# 8秒短剧：《倒霉的魔术师》

## 剧情概要
魔术师表演时出糗的搞笑故事

## 分镜提示词

### 镜头1（0-2秒）：魔术师登场
极特写：魔术师自信眼神...

### 镜头2（2-4秒）：开始表演
中景：魔术箱开始冒烟...

### 镜头3（4-6秒）：意外发生
特写：箱子剧烈抖动...

### 镜头4（6-8秒）：尴尬结局
全景：魔术师从旁边爬出...
```

## 安装

```bash
openclaw skill install 8-second-drama-generator
```