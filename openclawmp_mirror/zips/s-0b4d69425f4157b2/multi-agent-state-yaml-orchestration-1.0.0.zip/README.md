# Multi-Agent STATE.yaml 编排模式

使用共享的 STATE.yaml 文件作为"进度黑板"，实现多 Agent 之间的任务分配、进度追踪和协作编排。主 Agent 只做战略决策，不亲自执行任务。

## 核心思路

传统多 Agent 模式中，主 Agent 充当"交通警察"——接收任务、分配、收集结果、协调。这导致主 Agent 的 context 被大量协调信息占满。

STATE.yaml 模式将状态外化到文件：
- Agent 不需要记住谁在做什么（STATE.yaml 里写了）
- Agent 崩溃恢复不需要从聊天历史恢复（STATE.yaml 是 source of truth）
- 新 Agent 加入不需要 lengthy context（读 STATE.yaml 即可）

## STATE.yaml 结构

```yaml
# 任务全局状态
project: "Weekly Market Report"
created_at: "2026-03-13T20:00:00Z"
updated_at: "2026-03-13T20:30:00Z"
status: "in_progress"

tasks:
  research-competitors:
    name: "研究竞争对手分析"
    status: "pending"          # pending | in_progress | done | blocked
    assignee: "pm-report-researcher"
    priority: 1                # 数字越小优先级越高
    depends_on: []             # 依赖的任务 ID
    output: null               # 完成后的产出路径
    started_at: null
    completed_at: null

  write-report:
    name: "撰写市场报告"
    status: "pending"
    assignee: "pm-report-writer"
    priority: 2
    depends_on: ["research-competitors"]
    output: null
    started_at: null
    completed_at: null

  format-pdf:
    name: "生成 PDF 版本"
    status: "pending"
    assignee: "pm-report-formatter"
    priority: 3
    depends_on: ["write-report"]
    output: null
    started_at: null
    completed_at: null

results: {}
errors: []
```

## 工作流程

```
1. 主 Agent 创建 STATE.yaml（所有任务 status: pending）
2. 子 Agent 读取 STATE.yaml → 找到自己能做的最高优先级任务
3. 子 Agent 将 status 改为 in_progress，开始执行
4. 完成后 status 改为 done，填写 output 路径
5. 主 Agent 定期检查 STATE.yaml，调整优先级或分配新任务
```

## 命名规范

- **子会话 label**：`pm-{项目名}-{职责}`
  - 例：`pm-report-researcher`、`pm-report-writer`
- **Task ID**：`{动词}-{名词}`
  - 例：`research-competitors`、`write-report`、`format-pdf`

## 主 Agent 职责

主 Agent（皇帝）只做两件事：
1. **spawn 子 Agent** — 分配任务
2. **看结果** — 验收产出

不亲自执行任务，不充当"交通警察"。

## 子 Agent 行为规范

```
1. 读取 STATE.yaml
2. 找到 assignee === 自己 且 status === pending 且所有 depends_on 已 done 的任务
3. 如果找到：
   a. 将 status 改为 in_progress
   b. 设置 started_at
   c. 提交 git（变更历史 = 审计日志）
   d. 执行任务
   e. 将 status 改为 done
   f. 填写 output 路径
   g. 设置 completed_at
   h. 提交 git
4. 如果没找到：
   - 通知主 Agent "无可用任务"
```

## 并行执行策略

- 独立任务（无 depends_on）→ 同时 spawn 多个 Agent
- 依赖任务 → 等 depends_on 全部 done 后再 spawn
- 阻塞任务 → 设置 status: blocked，记录阻塞原因

## Git Checkpoint

每次 STATE.yaml 变更都提交 git：

```bash
git add STATE.yaml
git commit -m "state: {task_id} → {new_status}"
```

好处：
- 完整的变更历史
- 支持回滚
- Agent 崩溃后可从任意 checkpoint 恢复

## 故障恢复

如果某个子 Agent 超时或崩溃：
1. 检查 STATE.yaml 中的 started_at
2. 如果超过阈值（如 30 分钟）仍为 in_progress
3. 重置为 pending（或标记为 failed）
4. 重新分配或 spawn 新 Agent

## 适用场景

- 需要并行执行多个独立子任务
- 任务有依赖关系（DAG）
- 需要长时间运行的 Agent
- 主 Agent context 窗口有限
- 需要崩溃恢复能力

## 优势

| 对比项 | 传统模式 | STATE.yaml 模式 |
|--------|---------|----------------|
| Context 占用 | 高（记忆所有状态） | 低（状态在文件中） |
| 崩溃恢复 | 困难（从聊天历史恢复） | 简单（读 STATE.yaml） |
| 新 Agent 加入 | 需要 lengthy context | 读 STATE.yaml 即可 |
| 可审计性 | 低（信息分散） | 高（git 变更历史） |
| 并行度 | 受限于主 Agent | 天然支持 |