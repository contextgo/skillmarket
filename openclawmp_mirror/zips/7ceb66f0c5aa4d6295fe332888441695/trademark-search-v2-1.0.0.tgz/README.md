# trademark-search

商标查询工具，支持**中国（CNIPA）**、**美国（USPTO）**和**国际（WIPO）**三个商标数据库的可注册性查询。通过网络搜索实现——商标数据库均屏蔽自动化直连请求。

## 安装

将 `trademark-search` 文件夹复制到 agent 的 skills 目录下即可。

## 功能

- 查询中国/美国/国际商标注册状态
- 近似商标检索（音近/形近/义近）
- 自动判断目标市场推荐对应数据库
- 尼斯分类45类完整参考，准确定位检索类别
- 商标申请流程指引（中国CNIPA + 美国USPTO）

## 使用示例

### 中文品牌查询
> "帮我查一下'牧云'在中国能注册商标吗？打算做茶饮品牌"

### 英文品牌查询（美国市场）
> "Can I use 'NovaPay' for a fintech app in the US?"

### 驰名品牌查询
> "查一下'海底捞'的商标保护范围"

### 已注册号查询
> "查一下美国商标注册号 5678901 的状态"

### 国际商标
> "我想在中国和美国同时注册'CloudMind'，怎么查"

## 数据来源

所有数据库均通过 `web_search` 访问（直连被屏蔽）：

**中国：**
- CNIPA 商标局 — wsjs.cnipa.gov.cn（官方，需登录）
- 企查查/天眼查 — 第三方聚合，含商标信息

**美国：**
- USPTO Trademark Search — tmsearch.uspto.gov
- USPTO TSDR — tsdr.uspto.gov（状态查询）
- Trademarkia — trademarkia.com（第三方，搜索引擎已索引）

**国际：**
- WIPO Global Brand Database — branddb.wipo.int（马德里体系）

## 免责声明

本工具提供的查询结果仅供参考，不构成法律意见。商标可注册性受多种因素影响（近似度、混淆可能性、商品/服务类别等），正式申请前请咨询专业商标代理人。

## 许可证

MIT
