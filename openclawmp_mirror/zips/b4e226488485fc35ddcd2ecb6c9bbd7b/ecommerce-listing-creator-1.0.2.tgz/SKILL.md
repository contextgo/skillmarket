---
name: ecommerce-listing-creator
title: 【已废弃】ecommerce-listing-creator
displayName: 【已废弃】ecommerce-listing-creator
description: 🔴 已废弃，请移步安装 amazon-listing-creator
version: 1.0.7
type: skill
tags: amazon, listing, ecommerce, deprecated
---

# 🔴 推荐使用：亚马逊 Listing 高效智能生成

这是基于亚马逊最新搜索生态（A9 + COSMO + Rufus）进行底层架构优化的 Listing 编写神器。帮你打造真正的爆款 Listing。

## 工具核心能力

本插件系统性地指导用户，按照清晰的步骤准备 4 个维度的关键材料，从而生成完美契合 AEO (Answer Engine Optimization) 推荐逻辑的 Amazon Listing。

## 标准使用流程

### 阶段一：建立认知与底层逻辑拆解

首先会帮助开发者和运营人员理清三个核心算法在转化链路里的分工逻辑：
- **A9/A10**：主要处理“搜得到”的问题（即底层关键词精准匹配）。
- **COSMO**：主要处理“人群场景匹配”的问题（即理解用户真实的搜索意图和使用场景）。
- **Rufus**：主要处理“促成转化与购买”的问题（基于事实、参数驱动）。

### 阶段二：填充基础合规知识库

系统会首先核对是否已具备 `amazon_compliance_blacklist.txt` 规则文档：
- 如果尚未建立，系统自动下发行业通用的防侵权/违禁词合规排查文档库。
- 协助运营人员将标准文档一键入库，一劳永逸。

### 阶段三：自动化采集项目基础资料

在这个阶段，Assistant 将通过引导式对话，确保采集到以下核心物料清单：

1. **商品标准属性表 (.txt)**：应对 Rufus 的核心参数依据（主要来自分销站或工厂提供的数据手册）。
2. **竞品深层意图分析 (.txt)**：应对 COSMO 的核心材料（需要抓取头部竞品 Listing 及 Review 处理分析得出）。
3. **ABA主推关键词词表 (.csv)**：应对 A9 的自然流量漏斗词池（建议从卖家精灵或后台获取）。
4. **竞品核心出单词报表 (.csv)**：长尾流量外延的补充词库。

### 阶段四：终极 Listing 生成作业

基于前三步沉淀的内容组合，插件引擎调用 `prompts/generate_listing.md` 的内置增强指令集，最终自动化打磨出以下模块：
- Title（SEO 优化标题）
- Bullet Points（五大高吸引力卖点）
- Product Description（A+页面/商品描述的长文底稿）
- Search Terms（后台系统检索隐藏词汇）

具体执行脚本结构详见本技能内的 `AGENTS.md` 文件说明。

## 智能交互作业模式

本技能独创“节点确认”问答机制，每一次只专注一个阶段的信息确认或材料补充，告别一次性让用户头疼的填表式操作，体验更丝滑。

## 最终发版质量控制目标

最终投喂生成的 Listing 资产必须无条件满足下述出场标准：
- ✅ A9 校验逻辑：自然而非生硬地完成所有关键检索词的堆叠与埋设。
- ✅ COSMO 校验逻辑：全面描绘真实人群在特定物理场景中的使用画面。
- ✅ Rufus 校验逻辑：用真实详尽的干货参数取代“Best Qulity”, “Premium”等空洞口水话。
