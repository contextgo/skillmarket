# Research Project Manager

Multi-stage research workflow automation with state machine. Supports **collecting → analyzing → publishing** pipeline, designed for real-time geopolitical monitoring and structured intelligence report generation.

## 适用场景

- 实时监控美伊战争、中东局势等地缘政治热点
- 自动化采集-分析-写作多阶段工作流
- 定时生成结构化情报报告（OSINT标准）
- 多信源交叉验证的信息整合

## 核心能力

### 三阶段流水线

| 阶段 | 执行者 | 职责 |
|------|--------|------|
| **Collector** | 采集 agent | 滚动抓取最新报道，自动去重，更新状态文件 |
| **Analyzer** | 分析 agent | 汇总原始材料，提取关键发现，判断证据强度 |
| **Writer** | 写作 agent | 按七模块标准结构生成报告，写入飞书文档 |

### 状态机管理

`.state.json` 控制 phase 流转：
- `collecting` → `analyzing` → `writing_pending` → `reviewing` →（下一轮）`collecting`
- 每个阶段的状态独立记录，支持断点续跑

### 报告标准结构（七模块）

1. **一句话结论（Bottom Line）** + 决策者今日需关注
2. **已确认事实**（ISO时间戳 + 地理精确 + 证据标签）
3. **信息缺口**（Gaps & Disputes，可选）
4. **各方态势评估**（含历史行为参考）
5. **预测**（三段 Horizon + 概率阈值 + 关键依据）
6. **终局场景树**（无转折点可省略）
7. **Watchlist**（量化触发条件 + 影响 + 建议动作）

### 信源四级分级

| Tier | 类型 | 处理 |
|------|------|------|
| Tier 1 | 官方声明、多源交叉验证 | 直接 Confirmed |
| Tier 2 | 主流通讯社、权威智库 | 两家及以上一致则升 Tier1 |
| Tier 3 | 单一专业媒体、战争研究账号 | Single-party claim |
| Tier 4 | 匿名官员、非公开来源 | 仅用于 Speculative |

## 工作目录结构

```
{project_root}/
├── .state.json          # 状态机（phase/version/文档链接）
├── README.md             # 项目说明
├── knowledge_base/       # 背景知识、事件时间线、预警信号库
├── raw/                  # 原始报道（按日期命名）
├── drafts/               # 分析报告草稿
└── tasks/
    ├── collector_task.md  # 采集 prompt
    ├── analyzer_task.md   # 分析 prompt
    └── writer_task.md     # 写作 prompt（v3.1）
```

## 快速开始

### 1. 初始化项目

创建项目目录和初始状态文件：

```bash
mkdir my-research && cd my-research
cat > .state.json << 'EOF'
{
  "project": "项目名称",
  "root": "./",
  "phase": "collecting",
  "iteration": 0,
  "documents": {}
}
EOF
```

### 2. 配置信源

编辑 `knowledge_base/背景知识.md`，列出监控对象和优先信源。

### 3. 启动采集

触发 collector agent，传入：
- 项目目录路径
- 上次采集时间（用于计算增量窗口）

### 4. 等待流水线

Collector → Analyzer → Writer 自动接力，每轮完成后更新 `.state.json`。

### 5. 获取报告

最终报告写入飞书文档（`.state.json` 中记录链接），摘要卡片推送至指定群组。

## 依赖工具

- **飞书**（feishu）: 文档写入、摘要推送
- **ollama_web_search/fetch**: 新闻采集
- **subagent**: 多阶段任务调度

## 关键配置

| 字段 | 说明 |
|------|------|
| `phase` | 当前流水线阶段 |
| `iteration` | 轮次计数（每次+1） |
| `documents.feishu_id` | 飞书文档 ID |
| `last_collection` | 上次采集时间（ISO 8601） |
| `last_document` | 上次文档更新时间 |

## 版本历史

- **v3.1**（2026-04-24）: 综合阿飞+DeepSeek反馈，置信度加数值阈值，信息缺口可选，Watchlist量化
- **v3.0**（2026-04-23）: 七模块标准化，预测过期提醒，闭环学习机制
- **v2.0**（2026-04-22）: 飞书文档支持，四段式结构
