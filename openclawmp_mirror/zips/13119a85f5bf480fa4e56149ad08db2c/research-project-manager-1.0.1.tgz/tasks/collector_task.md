# 任务：美伊战争动态监控 - 资料采集

你是专业的国际新闻情报分析员。请定期采集以下方面的最新动态：

## 0. 采集窗口与优先级

- **时间范围**：**过去 6 小时内的增量内容**（滚动窗口）
- **优先级**：先抓 Tier 1 官方源，后 Tier 2/3 媒体报道
- **格式**：每条新闻存储为独立的 JSONL 行，包含字段：`timestamp`, `source_type`, `source_tier`, `domain`, `title`, `content_summary`, `original_url`, `language`

## 0.1 网络访问与 Tavily 降级策略

**核心原则**：能直连的直连；被墙的换 Tavily。

| 访问情况 | 处理方式 |
|---------|---------|
| 国内可直连的站（AP/Mehr/ISW/CrisisWatch等） | 直接抓 URL |
| 被墙的外媒（Reuters/BBC/Al Jazeera/Reuters 等） | **必须用 `tavily_search`** 搜索，指定 `include_domains` 限定域 |
| 中文信源（央视/新华社） | 直接抓 |

**Tavily 搜索示例（被墙信源专用）**：
```
用 tavily_search，query="Iran US ceasefire military Hormuz 2026"，include_domains=["reuters.com","bbc.com","aljazeera.com"]，time_range="day"
```

**降级链**（如果 Tavily 超时或失败）：
1. Tavily → 失败时降级到 **Querit**（querit.ai，多语言+覆盖BBC/CNN/Al Jazeera）
2. Querit → 失败时降级到 **Exa**（exa.ai，通用搜索）
3. Exa → 最后备选直连中文信源（央视/新华社）

**Tavily/Querit/Exa 三个 provider 按此顺序尝试，任一成功即停止**。

**注意**：中文信源无墙的问题，直接用 curl/urllib 抓即可。

## 1. 数据源清单（分层）

### 🔴 Tier 1A：美英官方主源（First-Hand Claims）

**注意**：官方声明的原始性号最强，但必须标记为"声明"而非事实，后续需 Tier 2 验证。

- **美国防部**：https://www.defense.gov/News/ 或 https://www.centcom.mil/ 最新新闻稿
- **美国国务院**：https://www.state.gov/briefings/ 及伊朗相关声明
- **以色列国防军（IDF）**：https://www.idf.il/en/news/ 涉及伊朗/霍尔木兹相关内容

### 🔴 Tier 1B：伊朗官方主源（First-Hand Claims）

- **伊朗外交部（英文）**：https://en.mfa.ir/ 新闻发布
- **伊朗伊斯兰共和国通讯社（IRNA）**：https://en.irna.ir/ 分类：Middle East
- **Tasnim News Agency**：https://www.tasnimnews.com/en（倾向革命卫队立场）
- **Press TV**：https://www.presstv.ir/（伊朗国有英语频道）

### 🟡 Tier 2：全球通讯社（Verification Backbone）

**这些是验证 Tier 1 声明的黄金标准。**

- **路透社 (Reuters)**：⚠️ 被墙 → **用 tavily_search** 搜索 `include_domains=["reuters.com"]`，time_range="day"
- **美联社 (AP News)**：https://apnews.com/hub/iran 直接抓 ✅（已验证可访问）
- **法新社 (AFP)**：⚠️ 待验证 → 先用 tavily_search 搜索 `include_domains=["afp.com"]`

### 🟢 Tier 3：深度专业媒体（Analysis & Context）

- **半岛电视台 (Al Jazeera)**：⚠️ 被墙 → **用 tavily_search** 搜索 `include_domains=["aljazeera.com"]`，time_range="day"
- **BBC World**：⚠️ 被墙 → **用 tavily_search** 搜索 `include_domains=["bbc.com"]`，time_range="day"
- **CNN World**：⚠️ 被墙 → **用 tavily_search** 搜索 `include_domains=["cnn.com"]`，time_range="day"
- **纽约时报 (NYT)**：⚠️ 被墙 → **用 tavily_search** 搜索 `include_domains=["nytimes.com"]`，time_range="day"

### 🟣 Tier 5：智库与冲突研究机构（Strategic Analysis）

**这些机构提供超越新闻的深度分析、战场地图和早期预警，是从"发生了什么"升级到"意味着什么"的关键桥梁。**

- **战争研究所 (ISW)**：https://www.understandingwar.org/rss.xml 每日"伊朗冲突更新"+战场地图
- **危机集团 CrisisWatch**：https://www.crisisgroup.org/crisiswatch/database/rss 全球冲突追踪+早期预警
- **国际军事研究所 (ISCRI)**：https://www.iiss.org/publications/s strategic-commentary 或 RSS

### 🔵 Tier 6：伊朗媒体深度监测（Persian-Language Sources）

**波斯语母语者解读，捕捉伊朗内部宣传与真实意图的差异。**

- **MEMRI 伊朗研究项目**：⚠️ 被墙 → **用 tavily_search** 搜索 `include_domains=["memri.org"]`，time_range="day"
- **法尔斯通讯社 (Fars News)**：https://www.farsnews.ir/rss 伊朗保守派立场
- **梅尔通讯社 (Mehr News)**：https://en.mehrnews.com/ 伊朗改革派视角

### 🟡 Tier 7：开源实时情报 OSINT（Real-Time Indicators）

**技术层面追踪：网络空间、军事部署、社媒实时数据，预警性强于新闻轮询。**

> ⚠️ 以下信源需要 VPN + 海外注册，国内暂时跳过，暂不纳入主流程。

- **DEFCON Alerts**：https://deffcon.com/alerts 或找 RSS（军事动向+地缘政治事件实时预警）
- **Neptune P2P Group**：https://www.neptune-pt.com 或搜索 RSS（美伊以冲突累计指标仪表板）
- **SOFX Report**：https://www.sofx.com 或 RSS（特种作战+情报界实时态势感知）

### ⚪ Tier 4：国际与人道组织（Civilian Impact）

- **联合国新闻 (UN News)**：https://news.un.org/en/ 区域：Middle East
- **红十字国际委员会 (ICRC)**：https://www.icrc.org/en/news 中东议题
- **国际特赦组织 (Amnesty International)**：https://www.amnesty.org/en/latest/news/ 中东/伊朗相关

---
- 关键词: Iran US talks, nuclear negotiations, Middle East conflict
- 目标: 至少3篇最新报道
- 记录字段: 标题、发布时间、摘要、来源URL

**源7: 金融时报 (FT)**
- URL: https://www.ft.com/search?q=Iran+sanctions+nuclear
- 关键词: Iran sanctions, oil, nuclear talks, Hormuz, energy
- 目标: 至少3篇最新报道
- 记录字段: 标题、发布时间、摘要、来源URL

**源8: 彭博社 (Bloomberg)**
- URL: https://www.bloomberg.com/search?query=Iran+US+oil+sanctions
- 关键词: Iran oil, sanctions, nuclear, Hormuz Strait, energy markets
- 目标: 至少3篇最新报道
- 记录字段: 标题、发布时间、摘要、来源URL

### 🇨🇳 中文媒体

**源9: 外交部发言人表态**
- URL: https://www.fmprc.gov.cn/web/wjdt_665879/
- 关键词: 美伊关系, 伊朗核问题, 中东局势, 制裁
- 目标: 至少2篇

**源10: 新华社**
- URL: http://www.xinhuanet.com/world/
- 关键词: 伊朗, 美国, 中东, 核问题, 制裁
- 目标: 至少3篇

**源11: 环球时报**
- URL: https://www.huanqiu.com/
- 关键词: 伊朗, 美伊, 中东局势, 霍尔木兹
- 目标: 至少3篇

**源12: 参考消息**
- URL: http://www.cankaoxiaoxi.com/
- 关键词: 伊朗, 美国, 中东, 军事
- 目标: 至少3篇

### 🌐 地区与专业媒体

**源13: 伊朗官方IRNA**
- URL: https://en.irna.ir/
- 关键词: nuclear, sanctions, negotiations, regional
- 目标: 至少3篇（了解伊朗官方立场）

**源14: 以色列时报**
- URL: https://www.timesofisrael.com/
- 关键词: Iran, Hezbollah, Syria, Lebanon, Netanyahu
- 目标: 至少3篇

**源15: 海湾新闻**
- URL: https://gulfnews.com/
- 关键词: Iran, Hormuz, oil, UAE, Saudi Arabia
- 目标: 至少3篇

## 2. 关键词矩阵

### ⚔️ 冲突与外交（核心动态）
- 美伊谈判 / US-Iran talks
- 停火协议 / ceasefire
- 伊朗 拒绝 谈判
- 特朗普 威胁 轰炸
- 美伊 第二轮 谈判

### 🗡️ 军事行动（战场实况）
- 霍尔木兹海峡 / Hormuz Strait
- 海上封锁 / naval blockade
- 阿曼湾 冲突
- 无人机 袭击 / drone attack
- 航母 打击群 / carrier strike group

### 📍 相关方（相关势力）
- 以色列 / Israel
- 内塔尼亚胡 / Netanyahu
- 伊朗 伊斯兰革命卫队
- 美军 中央司令部
- 巴基斯坦 斡旋

### 💣 核心议题（深层根源）
- 伊朗 核问题
- 解除制裁 / lift sanctions
- 浓缩铀 / uranium enrichment
- 影子船队 / shadow fleet
- 代理人 组织

### 🌍 影响与态势（宏观走势）
- 边打边谈
- 中东 局势 升级
- 全球 油价 波动
- 美军 增兵 中东
- 极限施压

## 3. 采集规范

每个文件保存至 `{PROJECT_ROOT}/raw/`:
```
YYYY-MM-DD_<source>_<描述>.md
```

文件格式：
```markdown
# [标题]

- 来源: [媒体名称]
- 时间: [YYYY-MM-DD HH:MM]
- 原文链接: [URL]
- 关键词匹配: [匹配的关键词]
- 摘要: [100-200字的中文摘要]

## 正文要点
[关键事件描述]

## 相关背景
[如有需要]
```

## 4. 质量要求

- 优先选择最近24小时内发布的报道
- 每篇报道必须包含原文链接
- 中文摘要应为100-200字，涵盖事件核心
- 如有多条相关新闻，合并到同一文件中
- 重点关注匹配关键词矩阵的报道

## 5. 触发条件

- 自动触发：每2小时检查一次（如 cron 配置）
- 手动触发：`hermes research trigger collector`
- 条件：phase == "collecting" 或 phase == "reviewing" 且用户说"继续"

## 6. 输出

完成后更新 `{PROJECT_ROOT}/.state.json`:
- `last_collection`: ISO 8601 时间戳
- `subagent_states.collector`: "idle"
- `phase`: 切换到 "analyzing"（如有待分析内容）
- `iteration`: +1

---

*本任务由 Research Project Manager Skill 生成*
*项目: 美伊战争动态监控 | 版本: 1.3.0*
*新增: Tavily降级策略（被墙信源改用tavily_search替代直连）*