# nano-pdf

使用 `nano-pdf` 通过自然语言指令对PDF的特定页面应用编辑。

## 快速开始

```bash
nano-pdf edit deck.pdf 1 "Change the title to 'Q3 Results' and fix the typo in the subtitle"
```

注意事项：
- 页码是基于0还是基于1，取决于工具的版本/配置；如果结果看起来差了一页，尝试使用另一种方式重试。
- 在发送输出PDF之前，始终进行合理性检查。