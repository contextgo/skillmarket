---
name: intelligent-project-manager
description: '智能项目管理助手 - 自动化任务分配、进度跟踪、风险预警、资源优化'
version: 1.0.0
type: skill
tags: ['project-management', 'automation', 'tracking', 'risk', 'resource']
---

# 智能项目管理助手

> 自动化任务分配、进度跟踪、风险预警、资源优化

## 核心功能

- 📋 智能任务分配
- 📊 实时进度跟踪
- ⚠️ 风险自动预警
- 📈 资源优化建议
- 📅 智能排期

## 使用方法

```bash
# 创建项目计划
openclaw skill run project-manager --action "create" --name "产品迭代V2.0"

# 分配任务
openclaw skill run project-manager --action "assign" --task "开发登录功能" --to "张三"

# 跟踪进度
openclaw skill run project-manager --action "track" --project "产品迭代V2.0"

# 风险检查
openclaw skill run project-manager --action "risk" --project "产品迭代V2.0"
```

## 功能模块

### 1. 任务管理
- 自动任务分解
- 智能优先级排序
- 依赖关系分析
- 工时估算

### 2. 进度跟踪
- 甘特图生成
- 燃尽图分析
- 里程碑监控
- 延迟预警

### 3. 风险管理
- 风险自动识别
- 影响评估
- 应对策略
- 风险矩阵

### 4. 资源优化
- 负载均衡
- 技能匹配
- 成本优化
- 资源利用率

## 输出示例

```markdown
# 项目报告：产品迭代V2.0

## 概览
- 进度：65% ✅
- 预算：¥120K / ¥150K
- 风险：2个中风险 ⚠️
- 延期：0天

## 任务状态
| 任务 | 负责人 | 状态 | 进度 | 截止日期 |
|------|--------|------|------|----------|
| 需求分析 | 张三 | ✅ | 100% | 3月15日 |
| UI设计 | 李四 | 🔄 | 80% | 3月20日 |
| 后端开发 | 王五 | 🔄 | 60% | 3月25日 |
| 测试 | 赵六 | ⏳ | 0% | 3月30日 |

## 风险预警
⚠️ **中风险**：UI设计延期2天
- 影响：后端开发可能延期
- 建议：增加设计师资源

## 建议
1. 优先完成UI设计，避免阻塞后端
2. 提前准备测试环境
3. 考虑增加1名测试人员
```

## 安装

```bash
openclaw skill install intelligent-project-manager
```

---

**让项目管理更智能、更高效！**
