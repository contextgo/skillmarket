---
name: structured-logging-for-agents
description: "Structured logging patterns for AI agents that produce machine-parseable logs for debugging, auditing, and self-monitoring"
version: 1.0.0
tags: ["logging", "monitoring", "debugging", "agent-ops", "observability"]
---

# Structured Logging for AI Agents

Logging patterns designed specifically for AI agents. Unlike traditional application logs, agent logs need to capture reasoning chains, tool interactions, decision points, and external state changes in a format that supports both human debugging and automated self-monitoring.

## Why Agent Logging is Different

Traditional logs capture events. Agent logs must capture:
- **Intent**: What the agent was trying to do
- **Context**: What information was available
- **Decision**: What it chose to do and why
- **Outcome**: What happened
- **Learning**: What it learned for next time

## Log Format Specification

### Base Log Entry

```json
{
  "ts": "2026-03-15T03:55:00Z",
  "session": "main",
  "phase": "execution",
  "step": "polymarket-sniper-round-13",
  "level": "INFO",
  "event": "market_analysis_complete",
  "data": {
    "market": "us-iran-conflict",
    "signal_strength": 0.82,
    "sources_checked": 57,
    "action_taken": "alert_user"
  },
  "tokens_used": 4500,
  "duration_ms": 2300
}
```

### Required Fields

| Field | Description | Example |
|-------|-------------|---------|
| ts | ISO 8601 timestamp | 2026-03-15T03:55:00Z |
| session | Session identifier | main, sub-agent-research |
| phase | Workflow phase | planning, execution, review |
| step | Current step within phase | round-13, task-3 |
| level | Severity | DEBUG, INFO, WARN, ERROR |
| event | What happened | tool_call, decision, error |
| data | Event-specific payload | Any JSON |
| tokens_used | LLM tokens consumed | 4500 |
| duration_ms | Operation duration | 2300 |

## Log Categories

### 1. Decision Logs (Most Important)

Capture every significant decision with rationale:
```json
{"event": "decision", "data": {
  "trigger": "user_requested_price_check",
  "options_considered": ["api_direct", "browser_scrape", "cache_lookup"],
  "chosen": "cache_lookup",
  "rationale": "data_fresh_within_5min",
  "confidence": 0.9
}}
```

### 2. Tool Interaction Logs

Every tool call and result:
```json
{"event": "tool_call", "data": {
  "tool": "web_search",
  "params": {"query": "US Iran latest"},
  "result_status": "success",
  "result_summary": "17 results, top signal: Kharg Island strike"
}}
```

### 3. Error and Recovery Logs

Errors and how they were handled:
```json
{"event": "error_recovery", "data": {
  "error": "API_402_PAYMENT_REQUIRED",
  "action": "fallback_to_google_news",
  "outcome": "success_with_reduced_coverage",
  "degraded": true
}}
```

### 4. Self-Monitoring Logs

Agent observing its own behavior:
```json
{"event": "self_monitor", "data": {
  "metric": "context_usage_percent",
  "value": 72,
  "threshold": 70,
  "action": "flush_completed_tasks"
}}
```

## Log Rotation and Retention

- **Active logs**: Current session, append-only
- **Daily archives**: Compressed, moved to logs/archive/YYYY-MM-DD.jsonl.gz
- **Retention**: 30 days of detailed logs, 1 year of summaries
- **Storage budget**: ~100MB/day for active agent, ~3GB/month

## Automated Self-Audit

Agent can query its own logs to:
- Count errors in the last 24 hours
- Identify recurring failure patterns
- Calculate average task completion time
- Detect context usage trends
- Generate daily summaries for the user
