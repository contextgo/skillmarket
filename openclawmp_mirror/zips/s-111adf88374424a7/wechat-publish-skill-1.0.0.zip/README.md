# 微信公众号发布技能

Markdown 一键转为微信公众号排版 HTML，并通过 API 发布到草稿箱。

## 功能特性

- Markdown 转微信兼容 HTML（内联样式）
- 加粗文本用兄弟 `<span>` 渲染（绕过微信 API 过滤）
- 指定锚点位置插入图片和说明文字
- 一键复制按钮，支持手动粘贴工作流
- API 发布：上传图片 + 创建草稿一步完成
- 自定义排版：可用任意微信文章链接作为排版参考
- 仅排版模式：预览不发布

## 快速开始

### 安装

将 `wechat-publish` 文件夹复制到 `~/.claude/skills/`：

```bash
cp -r wechat-publish ~/.claude/skills/
```

或从 `.skill` 文件安装：

```bash
unzip wechat-publish.skill -d ~/.claude/skills/wechat-publish
```

### 使用方法

对 Claude 说：

```
帮我把这篇文章发布到微信公众号
```

Claude 会自动：
1. 读取你的 Markdown 文件
2. 转为微信公众号排版 HTML
3. 展示预览
4. 通过 API 发布到草稿箱

### 仅排版（不发布）

```
帮我把这篇文章做公众号排版
```

## 自定义排版

默认使用简洁风格（15px 两端对齐、居中 H2 标题、淡色引用边框）。

用已有公众号文章的排版风格：

```
用这篇文章的排版风格：https://mp.weixin.qq.com/s/xxxxx
```

也可手动创建 `style.json` 配置文件，只写需要覆盖的字段，未指定的字段使用默认值。

## 前置条件

### 微信 API 凭证

创建 `~/.baoyu-skills/.env`：

```
WECHAT_APP_ID=你的_app_id
WECHAT_APP_SECRET=你的_app_secret
```

在 [mp.weixin.qq.com](https://mp.weixin.qq.com) > 设置 > 基本配置 中获取。

### IP 白名单

在公众号后台 > 设置 > 基本配置 > IP 白名单 中添加你的服务器 IP。

### Node.js

需要 Node.js（v14+），无需 npm 依赖——所有脚本仅使用内置模块。

## 脚本说明

| 脚本 | 用途 |
|------|------|
| `convert_md_to_wechat.js` | Markdown 转微信 HTML（内联样式）|
| `prepare_api_html.js` | 提取文章内容，替换 base64 图片 |
| `publish_to_wechat.js` | 上传图片并发布到微信草稿箱 |
| `extract_style.js` | 从微信文章 URL 提取排版配置 |

## 已知限制

- **原创声明**无法通过 API 设置，需在公众号后台手动开启
- **加粗文本**必须使用兄弟 `<span>` 元素（转换器自动处理）
- **Base64 图片**不被微信上传 API 支持，流水线会自动转为本地文件路径

## 许可证

MIT
