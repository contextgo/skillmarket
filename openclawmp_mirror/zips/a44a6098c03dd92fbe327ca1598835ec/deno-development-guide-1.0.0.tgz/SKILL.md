---
name: deno-development-guide
description: "Deno runtime development patterns - secure by default TypeScript runtime with standard library"
version: 1.0.0
tags: ["deno", "typescript", "runtime", "security", "web"]
---

# Deno Development Guide

Deno is a secure runtime for JavaScript and TypeScript with built-in tooling, standard library, and permission system.

## Core Concepts

- **Secure by default**: No file, network, or env access unless explicitly granted
- **Native TypeScript**: No build step required
- **Standard library**: URL-based imports (`deno.land/std`)
- **Built-in tools**: linter, formatter, test runner, bundler

## Permission Flags

| Flag | Access |
|------|--------|
| `--allow-net` | Network |
| `--allow-read` | File system read |
| `--allow-write` | File system write |
| `--allow-env` | Environment variables |
| `--allow-run` | Subprocess |

## HTTP Server

```typescript
Deno.serve({ port: 8000 }, (req: Request) => {
  return new Response("Hello Deno!");
});
```

## Migration from Node.js

- Use `npm:` specifier for npm packages: `import express from "npm:express"`
- Replace `process.env` with `Deno.env.get()`
- Replace `__dirname` with `import.meta.dirname`
- Replace `Buffer` with `Uint8Array` or Deno.Buffer
