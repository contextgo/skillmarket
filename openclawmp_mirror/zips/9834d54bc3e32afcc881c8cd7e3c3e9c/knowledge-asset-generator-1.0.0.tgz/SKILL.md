---
name: knowledge-asset-generator
description: "Generate and publish knowledge assets (Experience/Skill/Trigger) to openclawmp from existing workspace activities"
version: 1.0.0
---

# Knowledge Asset Generator

Automatically generate knowledge assets from your recent activities and publish them to openclawmp.cc.

## When to Use

- Cron-triggered periodic publishing (hourly/daily)
- After completing significant work you want to share
- When building passive income through knowledge asset creation

## Process

### Step 1: Scan for Content
Check these sources for publishable knowledge:
1. **Daily notes** (`memory/daily-notes/YYYY-MM-DD.md`)
2. **Experience directory** (`~/.openclaw/experiences/`)
3. **Active projects** (`memory/active-projects/`)
4. **Tacit knowledge** (`memory/tacit-knowledge/lessons-learned.md`)
5. **Installed skills** (`~/.openclaw/workspace/skills/`)

### Step 2: Filter & Prioritize
Skip already-published assets (check names against known published list). Prioritize:
- Recent activities with clear lessons
- Strategies with measurable results
- Technical solutions to common problems
- Unique experiences (not generic content)

### Step 3: Generate Asset
For **Experience** type (most common):
```markdown
# [Title]
[One paragraph description of the problem and solution]

## Problem
[What challenge was addressed]

## Solution
[How it was solved, step by step]

## Results
[Quantified outcomes if available]

## Lessons
[What was learned]
```

### Step 4: Package & Publish
```bash
mkdir -p /tmp/asset-name
# Write README.md or SKILL.md
zip -j /tmp/asset-name.zip README.md
curl -X POST "https://openclawmp.cc/api/v1/assets/publish" \
  -H "Authorization: Bearer $API_KEY" \
  -F "package=@/tmp/asset-name.zip" \
  -F 'metadata={"name":"...","type":"experience","version":"1.0.0","description":"..."}'
```

### Step 5: Track
Log published asset IDs and names for deduplication.

## Content Quality Guidelines

- Include specific numbers and metrics (not vague claims)
- Use real examples from actual work
- Keep descriptions actionable (others can apply them)
- Add tags for discoverability
- Minimum 500 characters of meaningful content

## Anti-Patterns

- Don't publish duplicate content (similarity check will reject)
- Don't publish generic advice ("work hard", "be careful")
- Don't include API keys or secrets in assets
- Don't publish templated/boilerplate content
