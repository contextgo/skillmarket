# AI 投资组合管理器与加密货币交易助手

> 自动化管理您的投资组合，智能分析市场数据，助您做出更明智的投资决策

## 概述

本工作流将 OpenClaw 打造成一个智能投资助手，帮你：

- 实时追踪加密货币和股票投资组合
- 自动分析市场趋势和价格走势
- 设置价格警报和自动交易策略
- 生成每日/每周投资报告
- 智能再平衡建议

## 核心功能

### 1. 投资组合追踪

- 支持多交易所整合（Coinbase, Binance, Kraken 等）
- 股票组合追踪（通过 yfinance）
- 实时估值和盈亏计算
- 历史表现分析

### 2. 市场智能分析

- 价格走势预测（基于技术指标）
- 市场情绪分析
- 新闻驱动的市场影响评估
- 链上数据分析（针对加密货币）

### 3. 自动化交易策略

- 网格交易策略
- 趋势跟随策略
- 均值回归策略
- 止损/止盈自动执行

### 4. 投资报告生成

- 每日投资摘要
- 周度/月度报告
- 税务相关报表
- 绩效归因分析

### 5. 价格警报系统

- 多渠道通知（Telegram, Discord, 邮件）
- 自定义警报规则
- 智能警报（避免虚假突破）

## 所需技能

### 必需技能

- `postgres` 或 SQLite — 本地投资组合数据库
- Cron 任务 — 定时更新和报告
- `web_fetch` 或 `coinGecko` — 获取加密货币价格数据
- `yfinance` — 获取股票数据
- Telegram/Discord 集成 — 推送通知

### 可选技能

- `ccxt` — 交易所 API 集成
- ` TradingView` — 高级图表分析
- Slack 集成 — 团队协作

## 设置指南

### 步骤 1：配置数据库

创建投资组合数据库：

```sql
-- 投资组合表
CREATE TABLE portfolios (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    total_value DECIMAL(20, 2) DEFAULT 0
);

-- 持仓表
CREATE TABLE holdings (
    id SERIAL PRIMARY KEY,
    portfolio_id INTEGER REFERENCES portfolios(id),
    symbol TEXT NOT NULL,
    asset_type TEXT NOT NULL,
    quantity DECIMAL(20, 8) NOT NULL,
    avg_buy_price DECIMAL(20, 8),
    exchange TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- 价格历史表
CREATE TABLE price_history (
    id SERIAL PRIMARY KEY,
    symbol TEXT NOT NULL,
    price DECIMAL(20, 8) NOT NULL,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- 交易记录表
CREATE TABLE transactions (
    id SERIAL PRIMARY KEY,
    portfolio_id INTEGER REFERENCES portfolios(id),
    symbol TEXT NOT NULL,
    action TEXT NOT NULL,
    quantity DECIMAL(20, 8) NOT NULL,
    price DECIMAL(20, 8) NOT NULL,
    timestamp TIMESTAMPTZ DEFAULT NOW()
);

-- 警报表
CREATE TABLE alerts (
    id SERIAL PRIMARY KEY,
    symbol TEXT NOT NULL,
    condition TEXT NOT NULL,
    threshold DECIMAL(20, 8) NOT NULL,
    triggered BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 步骤 2：配置通知渠道

创建一个 Telegram 主题用于投资更新：

```
# investment-updates — 投资组合更新和警报
```

### 步骤 3：初始化提示词

告诉你的 OpenClaw：

```text
你是一个智能投资组合管理器。请按照以下配置进行设置：

## 投资组合配置

1. 我关注的资产：
   - 加密货币：BTC, ETH, SOL, AVAX, ARB
   - 股票：AAPL, NVDA, TSLA, MSFT, GOOGL

2. 我的投资组合数据库位置：
   ~/investment/portfolio.db

3. 更新频率：
   - 价格数据：每 15 分钟
   - 投资组合估值：每小时
   - 每日报告：每天早上 9 AM
   - 每周报告：每周一早上 9 AM

## 警报规则

当以下情况发生时通知我：
- 任何持仓价格变动超过 5%
- 单日盈亏超过 10%
- 市场重大新闻（通过 RSS 监控）

## 报告格式

每日报告应包含：
1. 当前投资组合总价值
2. 24 小时盈亏（金额和百分比）
3. 各持仓表现
4. 今日重要市场新闻摘要
5. 是否有需要关注的警报

## 安全规则

1. 绝对不要执行超过 $100 的单笔交易（除非我明确授权）
2. 在执行任何交易前请求确认
3. 记录所有交易决策的原因
4. 每周生成交易审计报告
```

## 使用示例

### 日常查询

```
"我的投资组合现在怎么样？"
→ 返回当前估值、盈亏、各持仓表现

"BTC 近期表现如何？"
→ 返回 BTC 技术分析、支撑位/阻力位、情绪指标

"有什么需要我注意的吗？"
→ 返回活跃警报、市场新闻、重要价格变动
```

### 交易操作

```
"买入 0.1 BTC"
→ 检查余额 → 请求确认 → 执行交易 → 记录

"设置 BTC 价格警报，跌破 60000 美元时通知我"
→ 创建警报 → 确认设置成功
```

## 风险提示

⚠️ **重要提醒**

- 本工具仅供信息和辅助决策使用
- 不构成投资建议
- 自动交易功能需谨慎使用
- 投资有风险，入市需谨慎

## 相关资源

- [CoinGecko API](https://www.coingecko.com/en/api)
- [yfinance Python 库](https://pypi.org/project/yfinance/)
- [CCXT 交易所库](https://docs.ccxt.com/)

---
*本 README 由 OpenClaw 资产市场提供*