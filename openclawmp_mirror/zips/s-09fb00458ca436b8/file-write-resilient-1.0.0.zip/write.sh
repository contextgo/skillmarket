#!/bin/bash
# 文件写入容错机制

set -euo pipefail

# 配置
readonly PRIMARY_PATH="${RESILIENT_WRITE_PRIMARY:-/root/.openclaw/workspace/memory}"
readonly FALLBACK_PATHS=(
  "${RESILIENT_WRITE_FALLBACK1:-/tmp/openclaw-memory}"
  "${RESILIENT_WRITE_FALLBACK2:-./memory}"
  "${RESILIENT_WRITE_FALLBACK3:-/var/tmp/agent-memory}"
)
readonly MAX_RETRIES="${RESILIENT_WRITE_RETRIES:-3}"
readonly RETRY_DELAY="${RESILIENT_WRITE_DELAY:-1}"

# 日志函数
log_info() { echo "[INFO] $*" >&2; }
log_error() { echo "[ERROR] $*" >&2; }

# 检查目录可写
check_writable() {
  local dir="$1"
  [[ -d "$dir" ]] && [[ -w "$dir" ]]
}

# 确保目录存在
ensure_dir() {
  local dir="$1"
  if [[ ! -d "$dir" ]]; then
    mkdir -p "$dir" 2>/dev/null || return 1
  fi
  check_writable "$dir"
}

# 原子写入
atomic_write() {
  local target="$1"
  local content="$2"
  local tmpfile="${target}.tmp.$$"
  
  # 写入临时文件
  if ! echo "$content" > "$tmpfile" 2>/dev/null; then
    rm -f "$tmpfile" 2>/dev/null || true
    return 1
  fi
  
  # 同步到磁盘（确保数据落盘）
  sync "$tmpfile" 2>/dev/null || true
  
  # 原子重命名
  if mv "$tmpfile" "$target" 2>/dev/null; then
    return 0
  else
    rm -f "$tmpfile" 2>/dev/null || true
    return 1
  fi
}

# 主写入函数
resilient_write() {
  local target_path="$1"
  local content="$2"
  local attempts=0
  
  # 构建候选路径列表
  local candidates=()
  candidates+=("$target_path")
  
  # 如果原始路径是绝对路径，添加备用路径版本
  if [[ "$target_path" == /* ]]; then
    local filename
    filename=$(basename "$target_path")
    for fallback in "${FALLBACK_PATHS[@]}"; do
      candidates+=("${fallback}/${filename}")
    done
  fi
  
  # 尝试每个候选路径
  for candidate in "${candidates[@]}"; do
    attempts=$((attempts + 1))
    log_info "尝试写入 ($attempts): $candidate"
    
    local dir
    dir=$(dirname "$candidate")
    
    # 确保目录存在
    if ! ensure_dir "$dir"; then
      log_error "无法创建/访问目录: $dir"
      continue
    fi
    
    # 尝试写入（带重试）
    local retry=0
    while [[ $retry -lt $MAX_RETRIES ]]; do
      if atomic_write "$candidate" "$content"; then
        # 验证写入
        if [[ -f "$candidate" ]] && [[ -s "$candidate" ]]; then
          log_info "写入成功: $candidate"
          echo "$candidate"  # 输出实际写入的路径
          return 0
        fi
      fi
      
      retry=$((retry + 1))
      if [[ $retry -lt $MAX_RETRIES ]]; then
        log_info "重试 $retry/$MAX_RETRIES..."
        sleep "$RETRY_DELAY"
      fi
    done
    
    log_error "路径失败: $candidate"
  done
  
  log_error "所有路径均写入失败"
  return 1
}

# 如果是直接执行
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  if [[ $# -lt 2 ]]; then
    echo "用法: $0 <文件路径> <内容>"
    exit 1
  fi
  resilient_write "$1" "$2"
fi
