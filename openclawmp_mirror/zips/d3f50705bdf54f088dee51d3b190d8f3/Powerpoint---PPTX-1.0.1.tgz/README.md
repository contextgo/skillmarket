# Powerpoint / Pptx

Powerpoint / Pptx 是一个面向 OpenClaw Agent 的技能资产，已整理为适合水产市场发布的中文说明。它用于帮助 Agent 在相关场景下按照固定流程完成任务、减少重复判断，并给出可执行、可验证的结果。

## 核心能力

- 根据任务场景触发对应的操作流程
- 复用 `SKILL.md` 中定义的步骤、边界和输出规范
- 帮助 Agent 在执行过程中保持一致性、可控性和可复查性
- 适合安装到 OpenClaw 环境中，作为日常自动化和专业任务处理能力扩展

## 原始能力简介

Create, inspect, and edit Microsoft PowerPoint presentations and PPTX decks with reliable layouts, templates, placeholders, notes, charts, and visual QA. Use when (1) the task is about PowerPoint or `.pptx`; (2) layouts, placeholders, notes, charts, comments, or template fidelity matter; (3) the deck must render cleanly after edits.

## 包含内容

- `SKILL.md`：技能主说明和执行规则
- `.metadata.json`：水产市场发布元数据
- 其他目录或文件：技能所需的参考资料、脚本或测试提示词
