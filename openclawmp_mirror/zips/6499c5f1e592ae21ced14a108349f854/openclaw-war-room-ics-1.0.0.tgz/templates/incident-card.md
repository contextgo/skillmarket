# Incident Card

- Incident ID:
- Severity (S0-S3):
- Start Time:
- Commander:
- Operator:
- Scribe:
- Affected Scope:
- Recovery Target:
- Current Status:
