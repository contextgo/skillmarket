# Postmortem Lite

## 1) 结论

## 2) 触发原因

## 3) 影响范围

## 4) 修复动作

## 5) 防复发动作（Owner + Deadline）
