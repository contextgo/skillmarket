---
name: openclaw-war-room-ics
description: "将 OpenClaw 故障处理升级为战情室流程：分级、分工、证据链、恢复、复盘一体化。"
version: 1.0.0
type: skill
displayName: "OpenClaw 事故作战室 ICS"
tags: "openclaw, incident-response, sre, ops"
---

# OpenClaw 事故作战室 ICS

把临时救火升级为结构化事故处理。

核心思想：在 OpenClaw 出现故障时，不再“谁有空谁修”，而是按战情室机制并行推进：

- **指挥**（Commander）：定级、决策、节奏控制
- **执行**（Operator）：修复动作落地
- **记录**（Scribe）：证据链与时间线

## 适用场景

- 网关异常、消息堆积、模型调用连续失败
- 定时任务大面积失败
- 多渠道（飞书/Telegram/微信）同步异常

## 严重级别（建议）

- `S0`：全局不可用（无法回复 / 网关离线）
- `S1`：核心路径受损（延迟高、失败率高）
- `S2`：局部受损（单渠道或单功能异常）
- `S3`：轻微偏差（可运行但退化）

## 标准流程（15 分钟恢复优先）

### 1) 建立战情上下文（2 分钟）

- 创建事故卡（见 `templates/incident-card.md`）
- 指定本次 Commander / Operator / Scribe
- 明确恢复目标（例如“10 分钟内恢复回复能力”）

### 2) 三路并行排查（5 分钟）

**路由 A：网关层**

```bash
openclaw gateway status
openclaw health
openclaw status
```

**路由 B：配置层**

```bash
openclaw config get gateway --json
openclaw config get models --json
openclaw config get channels.feishu --json
```

**路由 C：任务层**

```bash
openclaw cron list
openclaw sessions list
```

### 3) 最小修复闭环（5 分钟）

遵循“先可回滚动作，再结构变更”：

1. `openclaw gateway run --force`（端口/进程问题优先）
2. 鉴权/模型配置核对
3. 执行最小验证请求（让 agent 回复一条短消息）

### 4) 证据封版与复盘（3 分钟）

- 更新事故时间线（见 `templates/timeline.md`）
- 输出 1 页复盘（见 `templates/postmortem-lite.md`）
- 固化预防动作（runbook / cron 监控 / 配置护栏）

## 可直接复用的输出格式

- 结论
- 依据（命令输出与时间线）
- 风险（未解决项）
- 执行步骤（下一步可复制命令）

## 关键收益

- 故障处理从“单线程救火”变为“并行作战”
- 有证据链，能复盘，能持续降故障率
- 降低“修好了但说不清为什么”的黑盒风险
