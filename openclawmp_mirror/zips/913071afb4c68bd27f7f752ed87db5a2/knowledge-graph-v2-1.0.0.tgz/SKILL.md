---
name: knowledge-graph-v2
description: AI Agent知识图谱：经验记录、语义搜索、关联发现、持续进化
---
# Agent知识图谱管理
## 架构
输入层→处理层→存储层→检索层→进化层

## 节点类型
- TASK：完成的任务
- SKILL：掌握的技能
- EVENT：重要事件

## 关系类型
- SOLVED_BY：任务被技能解决
- RELATED_TO：相关联
- EVOLVED_FROM：进化自

## 语义搜索
按意思搜索不要求关键词完全匹配。

## 维护机制
- 去重：合并相似节点
- PageRank：识别重要知识
- 社区检测：发现知识集群

**版本**: 1.0.0 | **作者**: 朝堂
