# prediction market signal detection

Automated signal detection for prediction markets including threshold crossing, sigma deviation, temporal divergence, and multi-market correlation analysis. Provides scoring framework for signal importance based on price-point movement magnitude and cross-market validation.

## How to Use

1. Monitor prediction market events with configurable polling intervals
2. Detect signals: threshold break (crossing 50%), sigma deviation (>2σ), temporal divergence (>10pp gap between timeframes)
3. Score signals: combine magnitude, direction, cross-market validation into 1-100 urgency score
4. Generate actionable alerts with context summaries

## Key Parameters

- **Threshold Break**: Detect when probability crosses key levels (25%, 50%, 75%, 90%, 100%)
- **Sigma Deviation**: Flag movements exceeding 2 standard deviations from rolling mean
- **Temporal Divergence**: Compare short-term vs long-term probability gaps
- **Volume Confirmation**: Validate signals with 24h volume data