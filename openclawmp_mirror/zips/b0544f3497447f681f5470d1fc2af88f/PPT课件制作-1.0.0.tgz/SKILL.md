---
name: PPT课件制作
displayName: PPT课件制作
description: 将教案转换为精美PPT课件，自动设计版式、配色、动画。
version: 1.0.0
author: OpenClaw Edu
tags: [education, ppt, courseware, design, teaching]
category: education
---

# PPT课件制作

教案转精美PPT。

## 功能

- 内容结构化
- 自动版式设计
- 专业配色方案
- 适度动画效果
- 教学逻辑优化

## 使用

```
@PPT课件制作 将这份教案转换为精美PPT
```
