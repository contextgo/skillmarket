#!/usr/bin/env python3
"""
Rabbit 每日新闻源-AI 采集脚本

输入:  sources.json
输出:  digest.json + digest.md

特点:
- 支持 RSS/Atom + GitHub Releases
- 简单去重与评分
- 失败源降级记录（不中断全流程）
"""

from __future__ import annotations

import argparse
import datetime as dt
import email.utils
import json
import re
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from urllib.parse import urlparse
import xml.etree.ElementTree as ET

import requests

UTC = dt.timezone.utc

GROUP_WEIGHT = {
    "official": 4,
    "engineering": 3,
    "research": 3,
    "community": 2,
}

KEYWORDS = [
    "gpt",
    "claude",
    "gemini",
    "qwen",
    "llama",
    "mistral",
    "agent",
    "reasoning",
    "benchmark",
    "release",
    "paper",
    "open source",
    "开源",
    "发布",
    "论文",
]


@dataclass
class Source:
    name: str
    url: str
    stype: str
    group: str
    notes: str = ""


@dataclass
class Item:
    title: str
    url: str
    source: str
    group: str
    published: Optional[str]
    score: int
    reasons: List[str]


def now_utc() -> dt.datetime:
    return dt.datetime.now(UTC)


def parse_datetime(text: Optional[str]) -> Optional[dt.datetime]:
    if not text:
        return None
    t = text.strip()
    if not t:
        return None

    # RFC2822
    try:
        d = email.utils.parsedate_to_datetime(t)
        if d:
            return d.astimezone(UTC)
    except Exception:
        pass

    # ISO 8601
    t2 = t.replace("Z", "+00:00")
    try:
        d = dt.datetime.fromisoformat(t2)
        if d.tzinfo is None:
            d = d.replace(tzinfo=UTC)
        return d.astimezone(UTC)
    except Exception:
        return None


def norm_title(title: str) -> str:
    t = title.lower().strip()
    t = re.sub(r"\s+", " ", t)
    t = re.sub(r"[^\w\u4e00-\u9fff ]+", "", t)
    return t


def _safe_text(elem: Optional[ET.Element]) -> str:
    return (elem.text or "").strip() if elem is not None else ""


def parse_rss_atom(xml_text: str, src: Source) -> List[Dict[str, Any]]:
    out: List[Dict[str, Any]] = []
    try:
        root = ET.fromstring(xml_text)
    except Exception:
        return out

    tag = root.tag.lower()

    # RSS 2.0
    if tag.endswith("rss") or "rss" in tag:
        channel = root.find("channel")
        if channel is None:
            return out
        for item in channel.findall("item"):
            title = _safe_text(item.find("title"))
            link = _safe_text(item.find("link"))
            pub = _safe_text(item.find("pubDate")) or _safe_text(item.find("dc:date"))
            if title and link:
                out.append({"title": title, "url": link, "published": pub})
        return out

    # Atom
    ns = {"a": "http://www.w3.org/2005/Atom"}
    entries = root.findall("a:entry", ns)
    if not entries:
        entries = root.findall("entry")

    for e in entries:
        title = _safe_text(e.find("a:title", ns)) or _safe_text(e.find("title"))
        link = ""
        lk = e.find("a:link", ns) or e.find("link")
        if lk is not None:
            link = (lk.attrib.get("href") or "").strip() or _safe_text(lk)
        pub = (
            _safe_text(e.find("a:updated", ns))
            or _safe_text(e.find("updated"))
            or _safe_text(e.find("a:published", ns))
            or _safe_text(e.find("published"))
        )
        if title and link:
            out.append({"title": title, "url": link, "published": pub})

    return out


def get_path(data: Any, dotted: str) -> Any:
    cur = data
    for key in dotted.split("."):
        if isinstance(cur, dict) and key in cur:
            cur = cur[key]
        else:
            return None
    return cur


def parse_generic_json(data: Any, src: Source, cfg: Dict[str, Any]) -> List[Dict[str, Any]]:
    """json 源通用解析器：
    需要 source 配置中提供:
    - listPath
    - titleField
    - linkField
    - dateField (optional)
    """
    out: List[Dict[str, Any]] = []
    list_path = cfg.get("listPath")
    title_field = cfg.get("titleField", "title")
    link_field = cfg.get("linkField", "url")
    date_field = cfg.get("dateField", "published")

    rows = get_path(data, list_path) if list_path else data
    if not isinstance(rows, list):
        return out

    for row in rows:
        if not isinstance(row, dict):
            continue
        title = str(get_path(row, title_field) if "." in title_field else row.get(title_field, "")).strip()
        link = str(get_path(row, link_field) if "." in link_field else row.get(link_field, "")).strip()
        pub = str(get_path(row, date_field) if "." in date_field else row.get(date_field, "")).strip()
        if title and link:
            out.append({"title": title, "url": link, "published": pub})
    return out


def fetch_source(session: requests.Session, src: Source, cfg: Dict[str, Any], timeout: int) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    try:
        r = session.get(src.url, timeout=timeout, headers={"User-Agent": "RabbitAIDigest/1.0"})
        if r.status_code != 200:
            return [], f"HTTP {r.status_code}"

        if src.stype in {"rss", "atom"}:
            items = parse_rss_atom(r.text, src)
            return items, None

        if src.stype == "json":
            try:
                data = r.json()
            except Exception:
                return [], "JSON 解析失败"
            items = parse_generic_json(data, src, cfg)
            return items, None

        if src.stype == "github_releases":
            # github_releases 由独立逻辑处理，不走这里
            return [], None

        return [], f"不支持的 source type: {src.stype}"
    except Exception as e:
        return [], str(e)


def fetch_github_releases(session: requests.Session, repo: str, timeout: int) -> Tuple[List[Dict[str, Any]], Optional[str]]:
    url = f"https://api.github.com/repos/{repo}/releases?per_page=5"
    try:
        r = session.get(url, timeout=timeout, headers={"User-Agent": "RabbitAIDigest/1.0"})
        if r.status_code != 200:
            return [], f"HTTP {r.status_code}"
        arr = r.json()
        if not isinstance(arr, list):
            return [], "GitHub 返回非数组"
        out = []
        for x in arr:
            if not isinstance(x, dict):
                continue
            title = (x.get("name") or x.get("tag_name") or "").strip()
            link = (x.get("html_url") or "").strip()
            pub = (x.get("published_at") or x.get("created_at") or "").strip()
            if title and link:
                out.append({"title": f"{repo}: {title}", "url": link, "published": pub})
        return out, None
    except Exception as e:
        return [], str(e)


def is_fresh_enough(published: Optional[str], hours: int, multiplier: int = 3) -> bool:
    d = parse_datetime(published)
    if d is None:
        return True
    age_h = (now_utc() - d).total_seconds() / 3600
    return age_h <= hours * multiplier


def score_item(title: str, group: str, published: Optional[str], hours: int, source_name: str) -> Tuple[int, List[str]]:
    score = 0
    reasons: List[str] = []

    gw = GROUP_WEIGHT.get(group, 1)
    score += gw
    reasons.append(f"group+{gw}")

    d = parse_datetime(published)
    if d is not None:
        age_h = (now_utc() - d).total_seconds() / 3600
        if age_h <= hours:
            score += 3
            reasons.append("fresh+3")
        elif age_h <= hours * 2:
            score += 1
            reasons.append("fresh+1")

    t = title.lower()
    kw_hits = sum(1 for k in KEYWORDS if k in t)
    if kw_hits > 0:
        bonus = min(kw_hits, 3)
        score += bonus
        reasons.append(f"kw+{bonus}")

    if "github" in source_name.lower() or "release" in source_name.lower():
        score += 1
        reasons.append("release+1")

    return score, reasons


def to_md(items: List[Item], failed: List[dict], stats: Dict[str, Any], generated_at: str, out_path: Path) -> None:
    lines: List[str] = []
    lines.append(f"# Rabbit 每日新闻源-AI 摘要\n")
    lines.append(f"- 生成时间(UTC): {generated_at}")
    lines.append(f"- 源总数: {stats['sourcesTotal']} | 成功: {stats['sourcesOk']} | 失败: {stats['sourcesFailed']}")
    lines.append(f"- 原始条目: {stats['itemsRaw']} | 去重后: {stats['itemsDeduped']}")
    lines.append("")
    lines.append("## Top 新闻")
    lines.append("")
    lines.append("| # | score | source | published(UTC) | title |")
    lines.append("|---:|---:|---|---|---|")

    for i, it in enumerate(items, start=1):
        p = it.published or "-"
        t = it.title.replace("|", " ")
        u = it.url
        lines.append(f"| {i} | {it.score} | {it.source} | {p} | [{t}]({u}) |")

    if failed:
        lines.append("")
        lines.append("## 失败源")
        lines.append("")
        for f in failed:
            lines.append(f"- {f['name']} ({f['url']}): {f['error']}")

    out_path.write_text("\n".join(lines), encoding="utf-8")


def load_config(path: Path) -> Dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        raise RuntimeError(f"配置读取失败: {path} => {e}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Rabbit 每日新闻源-AI 采集器")
    parser.add_argument("--sources", default="", help="sources json 路径")
    parser.add_argument("--hours", type=int, default=24, help="时效窗口（小时）")
    parser.add_argument("--top", type=int, default=30, help="输出前 N 条")
    parser.add_argument("--timeout", type=int, default=16, help="请求超时秒数")
    parser.add_argument("--out-dir", default="", help="输出目录")

    args = parser.parse_args()

    base_dir = Path(__file__).resolve().parents[1]
    src_path = Path(args.sources) if args.sources else (base_dir / "references" / "rabbit-ai-news-sources.json")
    out_dir = Path(args.out_dir) if args.out_dir else (Path.cwd() / "reports" / "rabbit-ai-news")
    out_dir.mkdir(parents=True, exist_ok=True)

    cfg = load_config(src_path)
    src_rows = cfg.get("sources") or []
    gh_rows = cfg.get("github_releases") or []
    max_per_source = int(cfg.get("maxItemsPerSource", 60))

    sources: List[Source] = []
    for s in src_rows:
        try:
            sources.append(
                Source(
                    name=str(s.get("name", "")).strip(),
                    url=str(s.get("url", "")).strip(),
                    stype=str(s.get("type", "rss")).strip().lower(),
                    group=str(s.get("group", "community")).strip().lower(),
                    notes=str(s.get("notes", "")).strip(),
                )
            )
        except Exception:
            continue

    session = requests.Session()

    raw_items: List[Item] = []
    failed_sources: List[dict] = []
    ok_sources = 0

    for src in sources:
        if not src.name or not src.url:
            failed_sources.append({"name": src.name or "(unknown)", "url": src.url or "", "error": "source 配置缺失"})
            continue
        items, err = fetch_source(session, src, cfg, timeout=args.timeout)
        if err:
            failed_sources.append({"name": src.name, "url": src.url, "error": err})
            continue

        ok_sources += 1
        for x in items[:max_per_source]:
            title = str(x.get("title", "")).strip()
            link = str(x.get("url", "")).strip()
            pub = str(x.get("published", "")).strip() or None
            if not title or not link:
                continue
            if not is_fresh_enough(pub, args.hours):
                continue
            score, reasons = score_item(title, src.group, pub, args.hours, src.name)
            raw_items.append(
                Item(
                    title=title,
                    url=link,
                    source=src.name,
                    group=src.group,
                    published=pub,
                    score=score,
                    reasons=reasons,
                )
            )

    # GitHub releases
    for row in gh_rows:
        repo = str(row.get("repo", "")).strip()
        if not repo or "/" not in repo:
            failed_sources.append({"name": f"github:{repo or '(unknown)'}", "url": "", "error": "repo 格式错误"})
            continue
        src_name = f"GitHub Releases ({repo})"
        items, err = fetch_github_releases(session, repo, timeout=args.timeout)
        if err:
            failed_sources.append({"name": src_name, "url": f"https://github.com/{repo}", "error": err})
            continue

        ok_sources += 1
        for x in items[: max(3, min(max_per_source, 8))]:
            title = str(x.get("title", "")).strip()
            link = str(x.get("url", "")).strip()
            pub = str(x.get("published", "")).strip() or None
            if not title or not link:
                continue
            if not is_fresh_enough(pub, args.hours, multiplier=8):
                continue
            score, reasons = score_item(title, "engineering", pub, args.hours, src_name)
            raw_items.append(
                Item(
                    title=title,
                    url=link,
                    source=src_name,
                    group="engineering",
                    published=pub,
                    score=score,
                    reasons=reasons,
                )
            )

    # 去重（按标准化标题）
    dedup: Dict[str, Item] = {}
    merged: Dict[str, List[str]] = {}
    for it in raw_items:
        k = norm_title(it.title)
        if not k:
            continue
        if k not in dedup or it.score > dedup[k].score:
            dedup[k] = it
        merged.setdefault(k, [])
        if it.source not in merged[k]:
            merged[k].append(it.source)

    final_items: List[Item] = []
    for k, it in dedup.items():
        sources_merged = merged.get(k, [])
        if len(sources_merged) >= 2:
            it.score += 2
            it.reasons.append("multi_source+2")
        final_items.append(it)

    final_items.sort(key=lambda x: x.score, reverse=True)
    final_items = final_items[: max(args.top, 1)]

    generated_at = now_utc().isoformat()
    stats = {
        "sourcesTotal": len(sources) + len(gh_rows),
        "sourcesOk": ok_sources,
        "sourcesFailed": len(failed_sources),
        "itemsRaw": len(raw_items),
        "itemsDeduped": len(dedup),
    }

    out_json = out_dir / "digest.json"
    out_md = out_dir / "digest.md"

    payload = {
        "generatedAt": generated_at,
        "windowHours": args.hours,
        "stats": stats,
        "failedSources": failed_sources,
        "items": [
            {
                "title": x.title,
                "url": x.url,
                "source": x.source,
                "group": x.group,
                "published": x.published,
                "score": x.score,
                "reasons": x.reasons,
            }
            for x in final_items
        ],
    }
    out_json.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    to_md(final_items, failed_sources, stats, generated_at, out_md)

    print("DONE")
    print(f"- json: {out_json}")
    print(f"- md  : {out_md}")
    print(f"- stats: {stats}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except KeyboardInterrupt:
        print("Interrupted", file=sys.stderr)
        raise SystemExit(130)
