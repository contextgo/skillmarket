# sources.json 结构

```json
{
  "meta": {"name": "Rabbit 每日新闻源-AI"},
  "maxItemsPerSource": 40,
  "sources": [
    {
      "name": "OpenAI News",
      "url": "https://openai.com/news/rss.xml",
      "type": "rss",
      "group": "official",
      "notes": "可选说明"
    }
  ],
  "github_releases": [
    {"repo": "openai/openai-python"}
  ]
}
```

- `type` 支持：`rss` / `atom` / `json`
- `group` 建议：`official` / `engineering` / `research` / `community`
- `maxItemsPerSource`：单源最多保留条数（默认 60）
