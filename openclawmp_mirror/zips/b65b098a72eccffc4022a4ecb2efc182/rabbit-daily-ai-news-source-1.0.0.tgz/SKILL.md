---
name: rabbit-daily-ai-news-source
description: 采集 Rabbit 每日新闻源-AI（多源 AI 新闻）并生成日报。用于用户提到“Rabbit每日新闻源-AI”“AI 每日新闻采集”“多源 AI 新闻汇总/日报”时。执行脚本抓取 RSS/Atom 与 GitHub Releases，去重、评分并输出 digest.md + digest.json。
---

# Rabbit 每日新闻源-AI 采集 Skill

执行多源采集，产出可读日报与结构化数据。

## 输入

- 来源配置：`references/rabbit-ai-news-sources.json`
- 可选参数：
  - `--hours` 时效窗口（默认 24）
  - `--top` 输出条数（默认 30）
  - `--out-dir` 输出目录

## 执行命令

```bash
python3 market-assets/rabbit-daily-ai-news-source/scripts/collect_rabbit_ai_news.py \
  --sources market-assets/rabbit-daily-ai-news-source/references/rabbit-ai-news-sources.json \
  --hours 24 \
  --top 30 \
  --out-dir reports/rabbit-ai-news
```

## 输出

- `reports/rabbit-ai-news/digest.md`：人类可读日报
- `reports/rabbit-ai-news/digest.json`：结构化结果（可二次处理）

## 规则

1. 先采集，再去重，再评分，再输出。
2. 源失败不终止全流程；在 `failedSources` 明确记录。
3. 评分优先级：来源分组 > 时效性 > 关键词 > 多源交叉命中。
4. 输出默认按 score 降序。

## 调整建议

- 需要贴近你个人偏好时，只改 `rabbit-ai-news-sources.json`，不改脚本。
- 需要更激进筛选时，缩短 `--hours` 或减少 `--top`。
